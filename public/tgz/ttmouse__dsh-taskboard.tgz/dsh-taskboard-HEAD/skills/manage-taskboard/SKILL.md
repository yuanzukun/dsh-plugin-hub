---
name: manage-taskboard
description: Manage taskboard projects, issues, comments, and status transitions through the dsh-taskboard HTTP API (localhost:47825). Use when the agent needs to track a new requirement, inspect project work, create or update issues, add progress notes, claim a task, record completion, or coordinate concurrent updates. The API is the single interface of the dsh-taskboard plugin — no taskctl, no CLI.
---

# Manage Taskboard

Use the dsh-taskboard HTTP API for every project, issue, and comment operation. Base URL: `http://127.0.0.1:47825` (loopback, no auth). Read [references/api.md](references/api.md) before choosing an endpoint or field.

## Command-line only (no browser tools)

All operations and verification in this skill are **command-line / HTTP API only**. Do not use browser tools (`browser_*`), do not open the GUI or a web page to verify anything. Verify by:
- re-reading task state via the API (`GET /api/tasks/<id>`),
- running build/typecheck scripts and checking the produced artifacts,
- checking what the running server actually serves (`curl` the served index.html/assets and compare hashes).

## Attribution rule

Every mutation (move, comment, relation) must declare its actor — otherwise
the board records the change as the local user (本地用户). Send the agent
identity headers on every write:

Percent-encode `X-Taskboard-Agent-Name` (Node Latin-1 header quirk). Plain Chinese in a JS DB write is fine.

```sh
TASKCTL_AGENT_NAME_ENC=$(python3 -c 'import os,urllib.parse; print(urllib.parse.quote(os.environ.get("TASKCTL_AGENT_NAME","DSH Agent"), safe=""))')
# Example for 豆皮: %E8%B1%86%E7%9A%AE
-H "X-Taskboard-Client: taskctl" \
-H "X-Taskboard-Agent-Id: ${TASKCTL_AGENT_ID:-dsh-agent}" \
-H "X-Taskboard-Agent-Name: $TASKCTL_AGENT_NAME_ENC"
```

Reads may omit them. The recorded actor becomes the AI Agent, and the change
is attributed correctly in the activity feed.

## Conversation linking (threadId)

Every write should also carry `threadId` — the agent's own DSH session id —
so the task gets a "打开会话" link back to the conversation that executed it.

Discover your session id from the run's patch overlay: the launch command
passes `--patch <file>`; that file contains a `- session: <sessionId>` line:

```sh
PATCH=$(echo "$*" | grep -oE '\-\-patch [^ ]+' | awk '{print $2}')
SID=$(grep -E '^\s*- session:' "$PATCH" | awk '{print $3}')
```

When the id is found, include it in move/comment bodies:
`{"version": 1, "status": "in_progress", "threadId": "<sessionId>"}`.
If no id is discoverable, omit it (the task simply gets no conversation link).

## Concurrency rule (non-negotiable)

Every write response returns the task's current `version`. Every mutation must carry the version from the **latest read** (`GET /api/tasks/<id>`). A `version` mismatch means someone else updated the task — re-read, reconcile, and retry with the fresh version. Never write without a version; never overwrite a newer state.

## Workflow

1. Search for an existing issue before creating one. List the project's issues (`GET /api/tasks?projectId=<id>`), compare identifiers, titles, descriptions, and status.
   - If an issue already tracks the same requirement, append the new requirement or acceptance detail to that issue without discarding its existing scope.
   - If the work depends on, blocks, is blocked by, or is closely related to another issue, add the matching issue relation.
   - Use a parent/sub-issue relation when one requirement is a contained part of a larger issue. A child has one parent; a parent may have many sub-issues.
   - Create a new issue only when no existing issue reasonably tracks the requirement.
   - Do not create, append, or relate a tiny or trivial request that does not benefit from durable tracking.
2. Before executing an issue, read the latest issue content (`GET /api/tasks/<id>`) and all comments (`GET /api/tasks/<id>/comments`). Treat comments as part of the current requirements, especially when completed work has been returned for changes.
   - In a description or comment, `![alt](/api/attachments/<id>/content)` marks an inline image at that exact position in the text. When understanding that image is necessary, download it (e.g. `curl -o /tmp/attachment <base>/api/attachments/<id>/content`) and inspect the saved file with an available image-viewing tool.
3. Create or update issues with `POST /api/tasks` / `POST /api/tasks/<id>/move`; consume their JSON output. Issues created through the API belong to the project you pass in `projectId`.
4. To claim a `todo` issue, move it to `in_progress` (`POST /api/tasks/<id>/move` with `{"version": <latest>, "status": "in_progress"}`) before starting implementation. If the claim reports a version conflict, or a fresh read shows the status changed, skip the issue and do not implement it.
5. Include the latest `version` on every concurrent update (move, comment, relation, archive), using the version returned by the most recent read.
6. Before requesting review, verify the requested work and acceptance criteria using only the command line and HTTP API (per "Command-line only" above) — never with browser tools.
7. After implementation and self-verification, add a comment summarizing the key changes, verification, result, and remaining risks (`POST /api/tasks/<id>/comments` with `{"body": "..."}`); then move the issue to `in_review` with the latest version. Never move it directly to `done`.
8. Move an issue from `in_review` to `done` only when the user explicitly confirms acceptance or explicitly asks to mark it complete. Self-verification alone is not sufficient.
9. Move work that cannot continue to `blocked`, and work that will not continue to `canceled`.

For version conflicts outside the initial claim, read the issue again, reconcile the newer state, and retry with its current version.

## Woken by a comment (评论即执行)

When a human comments on an issue that is `in_review` or `blocked`, the host starts one round right away — no waiting for the next scheduled claim. That round's prompt already names the issue and quotes the comment:

1. Read the issue (`GET /api/tasks/<id>`) and all its comments (plus attachments) first.
2. Treat that comment as the task: change the plan, rework the implementation, or answer and continue.
3. Finish with **one** summary comment (key changes / verification / remaining risks) and move the issue back to `in_review`; move it to `blocked` with the reason when you genuinely cannot continue.
4. Handle only that issue — do not pick another, create new issues, or reorder anything.

A comment landing while you are still working is delivered to you as one more message when the current turn ends; treat it the same way.

## Question card (asking the human to choose)

When you need a decision, list the answers in a fenced block inside your comment — the board renders them as buttons, and clicking one posts that answer as the human's comment (which starts the next round):

````text
```taskboard-options
["按 A 方案改", "按 B 方案改"]
```
````

Keep it to 2–4 genuinely distinct options and write the question itself outside the block. Once a later comment exists the card is marked stale.
