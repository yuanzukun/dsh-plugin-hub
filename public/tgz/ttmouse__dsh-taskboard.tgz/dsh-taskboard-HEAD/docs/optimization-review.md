# 优化审查记录

> 本文档由 ZCode 定时优化审查任务自动维护：定期扫描近期改动，聚焦最近修改的文件输出有代码依据的优化点。已有条目不重复记录，修复后请在对应条目标注「已修复（日期）」。

最近更新：2026-10-24 22:37

## 2026-10-24 22:37（间隔 25 天合并审查）

旧发现核验（2026-10-24）：三条均已修复——tmp/ 已进 .gitignore:20；PLUGIN_ID 已由 build.mjs 单源持有并经 esbuild banner 注入（build.mjs:22、:63-73）；data-taskboard-shell-css 冗余属性已删（client 现只用 data-plugin-css）。本轮新发现如下（subagent 审查 77daa4d..93bfb91 八个提交 + 未提交改动）。

- [中] web/src/App.tsx:1346-1369 — 「飞行卡」兜底动画的配套 CSS 从未入库，`.task-card-ghost`/`.is-flying` 在整个 web/src 中零定义，该功能完全不生效
  证据：App.tsx:1349 `ghost.className = "task-card-ghost"`，随后依赖 `is-flying` 触发过渡；但 `grep -rn "task-card-ghost" web/src/` 仅命中 App.tsx 这一处，styles.css 中 `is-flying` 为 0。该字符串由 7a2f475（-140）引入，而该提交对 styles.css 只新增了 `.global-view-button`。JS 未内联 `position`，创建出的 div 是 body 流末尾的无样式块级元素——「飞向目标列」退化为页面底部闪现裸文本 420ms，还可能引发滚动条闪动。
  为什么改：该分支恰好负责「目标列折叠/卡片无可见落点」这个最需要方向感的场景，现在等于没做，且死类名误导后续维护。
  怎么改：styles.css 补 `.task-card-ghost { position: fixed; z-index: ...; transition: left/top/width/height/opacity .38s ease; pointer-events: none; ... }`（rect 是视口坐标须用 fixed）；或把样式全部内联并删类名。

- [中] plugin/src/client/index.tsx:330-346 — 拖拽条用 400ms `setInterval` 轮询 iframe DOM，而 SPA 既有的事件通道 `taskboard:drag-region` 无任何消费者
  证据：index.tsx:341 `setInterval(sync, 400)`；全仓 grep `taskboard:drag-region` 只有发布端（App.tsx:1497、1508，带 ResizeObserver + resize），plugin 侧两个 message 监听（:727、:781）不消费它。
  为什么改：常驻轮询每 400ms 做一次跨文档查询；SPA 头部布局一变，覆盖条最长滞后 400ms 才对齐，期间可能压在 iframe 头部新出现的可点元素上吞点击。
  怎么改：PanelFrame 监听 `taskboard:drag-region`，payload 已是 iframe 视口坐标 rect，直接映射；轮询删掉或降级为兜底。

- [中] 仓库根目录（29 个文件）— 一次性验证截图已提交入库，约 2.6MB 永久占用
  证据：`git ls-files` 命中 29 个根目录 PNG（issue106~137 系列、`.i78-compare.png`、`.assets-*` 等），合计 2.6MB；仓库已有 docs/screenshots/ 作配图位置（5 张正常归档），.gitignore 也有 `/*-proof.png` 先例，但每次提 issue 后截图随手入库（-134、-137 等提交各带 1 张）。
  为什么改：一次性对比截图对仓库无长期价值，却进入每个 clone 的工作区与历史，根目录噪音持续增长。
  怎么改：确认 README/docs 无引用后 `git rm`（或 `git mv` 进 docs/screenshots/）；.gitignore 加 `/issue*.png`、`.i78-*.png`、`.assets-*.png` 防再入库。

- [低] server/app.mjs:532-557（未提交）— `decodeTaskboardDisplayName` 的百分号启发式有两处边角：含字面 `%` 的原始 UTF-8 名字直接 400，混排名字被静默改写
  证据：`if (/%[0-9A-Fa-f]{2}/.test(rawName)) { return decoded; }` 前置判定，但 `decodeURIComponent(rawName)` 在判定之前已执行——名字含字面 `%`（如「完成度 80%」）时抛 URIError 走 400，latin1→utf8 恢复分支永远走不到；原始字节混字面 `%C3%A9` 的名字会被整串按编码路径解码产生 mojibake。
  为什么改：该函数的目标就是兜住 skills/curl 直发原始 UTF-8 的场景，含 `%` 的标题会无声失败或记错名。
  怎么改：改 round-trip 判定——decode 成功且 `encodeURIComponent(decoded) === rawName` 才认定编码路径；否则含非 ASCII 字节先走恢复，恢复结果含 U+FFFD 再 400。

## 2026-09-29 03:09

本轮范围：plugin/package.json（0.5.0→0.5.1）、plugin/src/client/index.ts（style 归属修复，已验证与 build.mjs 注册 id 一致，改动干净）、新增 tmp/ 目录。

- [中] .gitignore:4 — 根目录 `tmp/`（含约 1.5MB 截图和调试脚本）未被忽略，处于未跟踪裸奔状态
  证据：`git status --short` 显示 `?? tmp/`；.gitignore 只写了 `.tmp/`，没有 `tmp/`；目录内有 `crop-*.png` 六张（约 670KB）、`probe-out/`（含多张 `round-*.png`）、`probe.mjs`、`verify-claim.mjs` 等调试产物（9 月 12-13 日）。
  为什么改：`git add -A` 一把就会把调试截图和一次性脚本提交进仓库；且 `.tmp/` 与 `tmp/` 一字之差，很容易以为已经覆盖了。
  怎么改：在根 .gitignore 加一行 `/tmp/`；或者把目录内容挪进已被忽略的 `.tmp/`，顺带消除与 `.tmp/` 的命名混淆。

- [低] plugin/src/client/index.ts:188 vs plugin/scripts/build.mjs:22 — `PLUGIN_ID` 在两处硬编码，靠注释约束同步
  证据：index.ts 新增 `const PLUGIN_ID = '@ttmouse/dsh-taskboard'`，注释说明它与 build.mjs 第 22 行注册进 `window.__ModuleLoader__.load` 的 id 必须一致，但没有任何机制保证；build.mjs 并没有读 package.json。
  为什么改：两个来源一旦漂移，`removeOwnedStyles`/`claimStyles` 的归属 key 对不上，会复发这次修的「style 被别的插件认领后丢失」问题，而且是静默复发。
  怎么改：让 build.mjs 从 `package.json` 读 `name` 作为单一来源，并通过 esbuild `define`（如 `__PLUGIN_ID__`）注入到 client 代码；index.ts 引用该常量而非重复字面量。

- [低] plugin/src/client/index.ts:205-207 — 同一个 style 标签挂了三个属性，其中两个值完全相同，旧的已属冗余
  证据：`tag.dataset.plugin`、`tag.dataset.pluginCss = tagId`、`tag.dataset.taskboardShellCss = tagId` 三行连续；`data-taskboard-shell-css` 全仓库只剩 203 行自查重这一处使用，注释也说官方约定就是 `data-plugin` + `data-plugin-css` 两个。
  为什么改：查重选择器可以直接用 `style[data-plugin-css="${tagId}"]`，省掉一个同值属性；少一个属性就少一处两套标记不同步的可能。
  怎么改：确认 DSH 宿主对 `data-plugin-css` 的用法后，把 203 行的选择器换成 `data-plugin-css`，删除 `data-taskboard-shell-css` 一行（若无其他外部依赖此属性）。
