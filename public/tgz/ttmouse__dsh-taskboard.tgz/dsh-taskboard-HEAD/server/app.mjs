import { randomUUID } from "node:crypto";
import { execFile, spawn } from "node:child_process";
import { readdirSync, readFileSync } from "node:fs";
import { appendFile, mkdir, readFile, readdir, rename, stat, unlink, writeFile } from "node:fs/promises";
import { createServer } from "node:http";
import { isIP } from "node:net";
import os from "node:os";
import path from "node:path";
import { Readable } from "node:stream";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";

import {
  DEFAULT_PROJECT_ID,
  TASK_STATUSES,
  isTaskPriority,
  isTaskStatus,
} from "../shared/domain.mjs";
import { normalizeWorkflowSnapshot } from "../shared/workflow-control-flow.mjs";
import { computeNextRun, parseRoutineYaml, serializeRoutine } from "../shared/routines-yaml.mjs";
import { aiEngineEnv } from "./ai-chat-catalog.mjs";
import { AiChatService } from "./ai-chat.mjs";
import { createCloudConfigStore } from "./cloud-config.mjs";
import {
  CloudProxyError,
  createCloudProxy,
  isLocalCompanionRoute,
} from "./cloud-proxy.mjs";
import { ApiError, TaskboardDatabase } from "./database.mjs";

const PROJECT_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const execFileAsync = promisify(execFile);
const JSON_BODY_LIMIT = 1024 * 1024;
const ATTACHMENT_BODY_LIMIT = 25 * 1024 * 1024;
const AI_CHAT_TURN_BODY_LIMIT = 25 * 1024 * 1024;
const AI_CHAT_ATTACHMENT_LIMIT = 10;
const AI_CHAT_SKILL_MARKER = "\uFFFC";
const INLINE_ATTACHMENT_TYPES = new Set([
  "application/pdf",
  "image/avif",
  "image/gif",
  "image/jpeg",
  "image/png",
  "image/webp",
  "text/plain",
]);
const PROJECT_ID_PATTERN = /^[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?$/;
const TRUSTED_EMBED_ORIGINS = new Set(["app://-"]);
const CODEX_AGENT_ACTOR = {
  type: "agent",
  id: "dsh-agent",
  name: "AI Agent",
  avatarUrl: null,
};

/**
 * Statuses where the board is *waiting for the human* — a comment there is an
 * instruction ("do it again / keep going"), so the host is asked to run one
 * round for that task right away instead of waiting for the next sweep.
 *
 * `todo` is deliberately NOT in this set: an issue that was never started is a
 * note, and a comment on it must not spend a run. `in_progress` is not in it
 * either: a run is already live and picks the comment up at its next turn.
 */
const DISPATCH_GATE_STATUSES = new Set(["in_review", "blocked"]);
const CONTENT_TYPES = new Map([
  [".css", "text/css; charset=utf-8"],
  [".html", "text/html; charset=utf-8"],
  [".ico", "image/x-icon"],
  [".jpeg", "image/jpeg"],
  [".jpg", "image/jpeg"],
  [".js", "text/javascript; charset=utf-8"],
  [".json", "application/json; charset=utf-8"],
  [".map", "application/json; charset=utf-8"],
  [".png", "image/png"],
  [".svg", "image/svg+xml"],
  [".webp", "image/webp"],
  [".woff", "font/woff"],
  [".woff2", "font/woff2"],
]);

function sendJson(response, status, value, headers = {}) {
  const body = JSON.stringify(value);
  response.writeHead(status, {
    "cache-control": "no-store",
    "content-length": Buffer.byteLength(body),
    "content-type": "application/json; charset=utf-8",
    ...headers,
  });
  response.end(body);
}

function sendEmpty(response, status, headers = {}) {
  response.writeHead(status, { "cache-control": "no-store", ...headers });
  response.end();
}

function toFetchRequest(request) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(request.headers)) {
    if (Array.isArray(value)) {
      for (const entry of value) headers.append(name, entry);
    } else if (value !== undefined) {
      headers.set(name, value);
    }
  }
  const init = { method: request.method, headers };
  if (request.method !== "GET" && request.method !== "HEAD") {
    init.body = Readable.toWeb(request);
    init.duplex = "half";
  }
  return new Request(`http://127.0.0.1${request.url}`, init);
}

async function sendFetchResponse(response, upstream) {
  response.statusCode = upstream.status;
  response.statusMessage = upstream.statusText;
  for (const [name, value] of upstream.headers) {
    if (
      name === "connection"
      || name === "content-encoding"
      || name === "content-length"
      || name === "set-cookie"
      || name === "transfer-encoding"
    ) {
      continue;
    }
    response.setHeader(name, value);
  }
  const cookies = upstream.headers.getSetCookie?.() ?? [];
  if (cookies.length > 0) response.setHeader("set-cookie", cookies);
  if (!upstream.body) {
    response.end();
    return;
  }
  await new Promise((resolve, reject) => {
    const body = Readable.fromWeb(upstream.body);
    body.once("error", reject);
    response.once("finish", resolve);
    body.pipe(response);
  });
}

function normalizeHostname(hostname) {
  return hostname.toLowerCase().replace(/^\[|\]$/g, "");
}

function isTrustedNetworkHost(hostname) {
  const host = normalizeHostname(hostname);
  if (host === "localhost" || host === "::1" || host.endsWith(".local")) return true;
  if (isIP(host) === 4) {
    const octets = host.split(".").map(Number);
    return octets[0] === 127
      || octets[0] === 10
      || (octets[0] === 172 && octets[1] >= 16 && octets[1] <= 31)
      || (octets[0] === 192 && octets[1] === 168)
      || (octets[0] === 169 && octets[1] === 254);
  }
  if (isIP(host) === 6) {
    return host.startsWith("fc")
      || host.startsWith("fd")
      || /^fe[89ab]/.test(host);
  }
  return false;
}

function assertTrustedNetworkRequest(request) {
  let host;
  try {
    host = new URL(`http://${request.headers.host ?? ""}`).hostname;
  } catch {
    throw new ApiError(403, "INVALID_HOST", "Request Host must be local or private");
  }
  if (!isTrustedNetworkHost(host)) {
    throw new ApiError(403, "INVALID_HOST", "Request Host must be local or private");
  }

  const origin = request.headers.origin;
  if (!origin) return;
  if (TRUSTED_EMBED_ORIGINS.has(origin)) return;
  let originHost;
  try {
    originHost = new URL(origin).hostname;
  } catch {
    throw new ApiError(403, "INVALID_ORIGIN", "Request Origin must be local or private");
  }
  if (!isTrustedNetworkHost(originHost)) {
    throw new ApiError(403, "INVALID_ORIGIN", "Request Origin must be local or private");
  }
}

function assertLoopbackRequest(request) {
  const address = request.socket.remoteAddress;
  if (
    address !== "127.0.0.1"
    && address !== "::1"
    && address !== "::ffff:127.0.0.1"
  ) {
    throw new ApiError(403, "LOCAL_ONLY", "This endpoint is only available on this device");
  }
}

function assertPlainObject(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new ApiError(400, "INVALID_BODY", "Request body must be a JSON object");
  }
}

function assertAllowedKeys(value, allowed) {
  const unknown = Object.keys(value).filter((key) => !allowed.has(key));
  if (unknown.length > 0) {
    throw new ApiError(400, "UNKNOWN_FIELD", `Unknown field${unknown.length === 1 ? "" : "s"}: ${unknown.join(", ")}`);
  }
}

function assertAllowedQuery(searchParams, allowed, routeLabel) {
  for (const key of searchParams.keys()) {
    if (!allowed.has(key)) {
      throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", `${routeLabel} does not accept query parameter '${key}'`);
    }
    if (searchParams.getAll(key).length !== 1) {
      throw new ApiError(400, "INVALID_QUERY_PARAMETER", `Query parameter '${key}' cannot be repeated`);
    }
  }
}

function assertNoQuery(searchParams, routeLabel) {
  assertAllowedQuery(searchParams, new Set(), routeLabel);
}

function decodeRouteSegment(value, name) {
  let decoded;
  try {
    decoded = decodeURIComponent(value);
  } catch {
    throw new ApiError(400, "INVALID_PATH", `${name} contains invalid encoding`);
  }
  if (!decoded || decoded.length > 256 || decoded.includes("\0")) {
    throw new ApiError(400, "INVALID_PATH", `${name} is invalid`);
  }
  return decoded;
}

function isLoopbackAddress(value) {
  if (typeof value !== "string") return false;
  const address = value.toLowerCase().split("%", 1)[0];
  return address === "::1"
    || address === "127.0.0.1"
    || address.startsWith("127.")
    || address === "::ffff:127.0.0.1"
    || address.startsWith("::ffff:127.");
}

function assertAiLoopbackRequest(request) {
  if (!isLoopbackAddress(request.socket.remoteAddress)) {
    throw new ApiError(403, "LOCAL_AI_LOOPBACK_REQUIRED", "Local AI routes are only available from this device");
  }
}

function stringField(value, name, { required = false, nullable = false, maxLength }) {
  if (value === undefined) {
    if (required) {
      throw new ApiError(400, "INVALID_FIELD", `'${name}' is required`);
    }
    return undefined;
  }
  if (nullable && value === null) {
    return null;
  }
  if (typeof value !== "string") {
    throw new ApiError(400, "INVALID_FIELD", `'${name}' must be a string${nullable ? " or null" : ""}`);
  }
  const normalized = value.trim();
  if (required && normalized.length === 0) {
    throw new ApiError(400, "INVALID_FIELD", `'${name}' cannot be empty`);
  }
  if (normalized.length > maxLength) {
    throw new ApiError(400, "INVALID_FIELD", `'${name}' cannot exceed ${maxLength} characters`);
  }
  return normalized;
}

function pathField(value, name) {
  const normalized = stringField(value, name, { nullable: true, maxLength: 4096 });
  if (normalized === "") {
    throw new ApiError(400, "INVALID_FIELD", `'${name}' cannot be empty`);
  }
  if (normalized?.includes("\0")) {
    throw new ApiError(400, "INVALID_FIELD", `'${name}' cannot contain null bytes`);
  }
  return normalized;
}

function parseDueDate(value, name = "dueDate") {
  const date = stringField(value, name, { nullable: true, maxLength: 10 });
  if (date !== null && date !== undefined && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    throw new ApiError(400, "INVALID_FIELD", `'${name}' must use YYYY-MM-DD`);
  }
  return date;
}

function parseDevelopmentContext(value) {
  if (value === null) return null;
  assertPlainObject(value);
  if (value.type === "branch") {
    assertAllowedKeys(value, new Set(["type", "branch"]));
    return {
      type: "branch",
      branch: stringField(value.branch, "developmentContext.branch", { required: true, maxLength: 512 }),
    };
  }
  if (value.type === "worktree") {
    assertAllowedKeys(value, new Set(["type", "path", "branch"]));
    const worktreePath = stringField(value.path, "developmentContext.path", { required: true, maxLength: 4096 });
    if (worktreePath.includes("\0")) {
      throw new ApiError(400, "INVALID_FIELD", "'developmentContext.path' cannot contain null bytes");
    }
    return {
      type: "worktree",
      path: worktreePath,
      branch: stringField(value.branch ?? null, "developmentContext.branch", { nullable: true, maxLength: 512 }),
    };
  }
  throw new ApiError(400, "INVALID_FIELD", "'developmentContext.type' must be branch or worktree");
}

function parseRecurrence(value) {
  if (value === null) return null;
  assertPlainObject(value);
  assertAllowedKeys(value, new Set(["interval", "unit"]));
  if (!Number.isSafeInteger(value.interval) || value.interval < 1 || value.interval > 365) {
    throw new ApiError(400, "INVALID_FIELD", "'recurrence.interval' must be an integer from 1 to 365");
  }
  if (!["day", "week", "month", "year"].includes(value.unit)) {
    throw new ApiError(400, "INVALID_FIELD", "'recurrence.unit' must be day, week, month, or year");
  }
  return { interval: value.interval, unit: value.unit };
}

function parseVersion(value) {
  if (!Number.isSafeInteger(value) || value < 1) {
    throw new ApiError(400, "INVALID_FIELD", "'version' must be a positive integer");
  }
  return value;
}

function parseWorkflowVersion(value) {
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new ApiError(400, "INVALID_FIELD", "'version' must be a non-negative integer");
  }
  return value;
}

function parseWorkflowWorkspace(value) {
  assertPlainObject(value);
  assertAllowedKeys(value, new Set(["version", "tabs", "activeWorkflowId", "snapshots"]));
  if (value.version !== 1) {
    throw new ApiError(400, "INVALID_FIELD", "'workspace.version' must be 1");
  }
  if (!Array.isArray(value.tabs) || value.tabs.length === 0 || value.tabs.length > 100) {
    throw new ApiError(400, "INVALID_FIELD", "'workspace.tabs' must contain 1 to 100 workflows");
  }
  const tabs = value.tabs.map((tab, index) => {
    assertPlainObject(tab);
    assertAllowedKeys(tab, new Set(["id", "name"]));
    return {
      id: stringField(tab.id, `workspace.tabs[${index}].id`, { required: true, maxLength: 128 }),
      name: stringField(tab.name, `workspace.tabs[${index}].name`, { required: true, maxLength: 120 }),
    };
  });
  if (new Set(tabs.map((tab) => tab.id)).size !== tabs.length) {
    throw new ApiError(400, "INVALID_FIELD", "'workspace.tabs' ids must be unique");
  }
  const activeWorkflowId = stringField(value.activeWorkflowId, "workspace.activeWorkflowId", {
    required: true,
    maxLength: 128,
  });
  if (!tabs.some((tab) => tab.id === activeWorkflowId)) {
    throw new ApiError(400, "INVALID_FIELD", "'workspace.activeWorkflowId' must reference a workflow tab");
  }
  assertPlainObject(value.snapshots);
  const snapshots = {};
  for (const tab of tabs) {
    const snapshot = value.snapshots[tab.id];
    assertPlainObject(snapshot);
    assertAllowedKeys(snapshot, new Set(["nodes", "edges", "flow", "selectedNodeId"]));
    if (!Array.isArray(snapshot.nodes) || snapshot.nodes.length > 10_000) {
      throw new ApiError(400, "INVALID_FIELD", `'workspace.snapshots.${tab.id}.nodes' must be an array`);
    }
    if (snapshot.flow === undefined && (!Array.isArray(snapshot.edges) || snapshot.edges.length > 20_000)) {
      throw new ApiError(400, "INVALID_FIELD", `'workspace.snapshots.${tab.id}.edges' must be an array`);
    }
    if (snapshot.flow !== undefined && snapshot.edges !== undefined) {
      throw new ApiError(400, "INVALID_FIELD", `'workspace.snapshots.${tab.id}' cannot contain both 'flow' and 'edges'`);
    }
    const selectedNodeId = stringField(
      snapshot.selectedNodeId ?? null,
      `workspace.snapshots.${tab.id}.selectedNodeId`,
      { nullable: true, maxLength: 256 },
    );
    try {
      snapshots[tab.id] = normalizeWorkflowSnapshot({
        nodes: snapshot.nodes,
        edges: snapshot.edges,
        flow: snapshot.flow,
        selectedNodeId,
      });
    } catch (error) {
      throw new ApiError(
        400,
        "INVALID_FIELD",
        `'workspace.snapshots.${tab.id}' is not a valid workflow: ${error.message}`,
      );
    }
  }
  return { version: 1, tabs, activeWorkflowId, snapshots };
}

function parseWorkflowWorkspaceSave(body) {
  assertPlainObject(body);
  assertAllowedKeys(body, new Set(["version", "workspace"]));
  return {
    version: parseWorkflowVersion(body.version),
    workspace: parseWorkflowWorkspace(body.workspace),
  };
}

function parseSortOrder(value) {
  if (typeof value !== "number" || !Number.isFinite(value) || Math.abs(value) > 1_000_000_000_000) {
    throw new ApiError(400, "INVALID_FIELD", "'sortOrder' must be a finite number between -1000000000000 and 1000000000000");
  }
  return value;
}

function parseLabels(value) {
  if (!Array.isArray(value) || value.length > 20) {
    throw new ApiError(400, "INVALID_FIELD", "'labels' must be an array with at most 20 entries");
  }
  const labels = value.map((label) => {
    if (typeof label !== "string") {
      throw new ApiError(400, "INVALID_FIELD", "Every label must be a string");
    }
    const normalized = label.trim();
    if (normalized.length === 0 || normalized.length > 64) {
      throw new ApiError(400, "INVALID_FIELD", "Labels must contain 1 to 64 characters");
    }
    return normalized;
  });
  if (new Set(labels).size !== labels.length) {
    throw new ApiError(400, "INVALID_FIELD", "Labels must be unique");
  }
  return labels;
}

function parseStatus(value, fallback) {
  const result = value ?? fallback;
  if (!isTaskStatus(result)) {
    throw new ApiError(400, "INVALID_FIELD", `'status' must be one of: ${TASK_STATUSES.join(", ")}`);
  }
  return result;
}

function parsePriority(value, fallback) {
  const result = value ?? fallback;
  if (!isTaskPriority(result)) {
    throw new ApiError(400, "INVALID_FIELD", "'priority' must be none, urgent, high, medium, or low");
  }
  return result;
}

function slugify(value) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 64);
}

function validateProjectId(value, { required = true } = {}) {
  const id = stringField(value, "id", { required, maxLength: 64 });
  if (id !== undefined && !PROJECT_ID_PATTERN.test(id)) {
    throw new ApiError(400, "INVALID_FIELD", "'id' must be a lowercase slug containing letters, numbers, or hyphens");
  }
  return id;
}

function parseProjectCreate(body) {
  assertPlainObject(body);
  assertAllowedKeys(body, new Set(["id", "name", "workspacePath"]));
  const name = stringField(body.name, "name", { required: true, maxLength: 120 });
  const id = validateProjectId(body.id ?? slugify(name));
  if (!id) {
    throw new ApiError(400, "INVALID_FIELD", "Project name must contain at least one letter or number when 'id' is omitted");
  }
  const workspacePath = stringField(body.workspacePath ?? null, "workspacePath", { nullable: true, maxLength: 4096 });
  if (workspacePath === "") {
    throw new ApiError(400, "INVALID_FIELD", "'workspacePath' cannot be empty");
  }
  if (workspacePath?.includes("\0")) {
    throw new ApiError(400, "INVALID_FIELD", "'workspacePath' cannot contain null bytes");
  }
  return { id, name, workspacePath };
}

/** Parse a project update body (PUT /api/projects/:id): name and/or workspacePath. */
function parseProjectUpdate(body) {
  assertPlainObject(body);
  assertAllowedKeys(body, new Set(["name", "workspacePath"]));
  const result = {};
  if (body.name !== undefined) {
    result.name = stringField(body.name, "name", { required: true, maxLength: 120 });
  }
  if (body.workspacePath !== undefined) {
    const workspacePath = stringField(body.workspacePath, "workspacePath", { nullable: true, maxLength: 4096 });
    if (workspacePath === "") {
      throw new ApiError(400, "INVALID_FIELD", "'workspacePath' cannot be empty");
    }
    if (workspacePath?.includes("\0")) {
      throw new ApiError(400, "INVALID_FIELD", "'workspacePath' cannot contain null bytes");
    }
    result.workspacePath = workspacePath;
  }
  return result;
}

function parseThreadId(value) {
  if (value === undefined) return undefined;
  return stringField(value, "threadId", { required: true, maxLength: 256 });
}

function requestHeader(request, name) {
  const value = request.headers[name];
  return Array.isArray(value) ? value[0] : value;
}


/**
 * Decode an agent/user display-name header.
 * Web UI sends encodeURIComponent; curl/skills often send raw UTF-8 octets.
 * Node exposes raw UTF-8 header bytes as Latin-1 code units — recover them.
 */
function decodeTaskboardDisplayName(rawName, invalidMessage) {
  let decoded;
  try {
    decoded = decodeURIComponent(rawName);
  } catch {
    throw new ApiError(400, "INVALID_ACTOR", invalidMessage);
  }
  // Percent-encoded path (web UI): trust decodeURIComponent result as-is.
  if (/%[0-9A-Fa-f]{2}/.test(rawName)) {
    return decoded;
  }
  // Raw UTF-8 header path: Latin-1 code units → original UTF-8 bytes → text.
  try {
    const recovered = Buffer.from(decoded, "latin1").toString("utf8");
    if (recovered !== decoded && !recovered.includes("\uFFFD")) {
      return recovered;
    }
  } catch {
    // Already real Unicode / latin1 path failed — keep decoded.
  }
  return decoded;
}

function agentActorFromRequest(request) {
  const rawId = requestHeader(request, "x-taskboard-agent-id");
  const rawName = requestHeader(request, "x-taskboard-agent-name");
  if (rawId === undefined && rawName === undefined) return null;
  if (rawId === undefined || rawName === undefined) {
    throw new ApiError(400, "INVALID_ACTOR", "Agent identity requires both an ID and name");
  }
  const id = stringField(rawId, "X-Taskboard-Agent-Id", { required: true, maxLength: 96 });
  if (!/^[a-z0-9](?:[a-z0-9._-]*[a-z0-9])?$/.test(id)) {
    throw new ApiError(400, "INVALID_ACTOR", "Agent ID contains unsupported characters");
  }
  const decodedName = decodeTaskboardDisplayName(rawName, "Agent name is not valid URL-encoded text");
  const name = stringField(decodedName, "X-Taskboard-Agent-Name", { required: true, maxLength: 120 });
  return { type: "agent", id, name, avatarUrl: null };
}

function actorFromRequest(request) {
  if (request.headers["x-taskboard-client"] === "taskctl") {
    return agentActorFromRequest(request) ?? CODEX_AGENT_ACTOR;
  }

  const rawId = requestHeader(request, "x-taskboard-user-id");
  const rawName = requestHeader(request, "x-taskboard-user-name");
  const rawAvatarUrl = requestHeader(request, "x-taskboard-user-avatar");
  if (rawId === undefined && rawName === undefined && rawAvatarUrl === undefined) {
    return { type: "user", id: "local-user", name: "本地用户", avatarUrl: null };
  }
  if (rawId === undefined || rawName === undefined) {
    throw new ApiError(400, "INVALID_ACTOR", "User identity requires both an ID and name");
  }

  const id = stringField(rawId, "X-Taskboard-User-Id", { required: true, maxLength: 96 });
  if (!/^[a-z0-9](?:[a-z0-9._-]*[a-z0-9])?$/.test(id)) {
    throw new ApiError(400, "INVALID_ACTOR", "User ID contains unsupported characters");
  }
  const decodedName = decodeTaskboardDisplayName(rawName, "User name is not valid URL-encoded text");
  const name = stringField(decodedName, "X-Taskboard-User-Name", { required: true, maxLength: 120 });

  let avatarUrl = null;
  if (rawAvatarUrl !== undefined) {
    const value = stringField(rawAvatarUrl, "X-Taskboard-User-Avatar", { required: true, maxLength: 2048 });
    let parsed;
    try {
      parsed = new URL(value);
    } catch {
      throw new ApiError(400, "INVALID_ACTOR", "User avatar URL is invalid");
    }
    if (!["http:", "https:"].includes(parsed.protocol)) {
      throw new ApiError(400, "INVALID_ACTOR", "User avatar URL must use HTTP or HTTPS");
    }
    avatarUrl = parsed.toString();
  }
  return { type: "user", id, name, avatarUrl };
}

function parseAssigneeTarget(value) {
  if (value === undefined) return undefined;
  if (value !== "current-user" && value !== "codex-agent") {
    throw new ApiError(400, "INVALID_FIELD", "'assigneeTarget' must be current-user or codex-agent");
  }
  return value;
}

function resolveAssignee(target, actor) {
  if (target === undefined) return actor;
  if (target === "codex-agent") return CODEX_AGENT_ACTOR;
  if (actor.type !== "user") {
    throw new ApiError(400, "INVALID_FIELD", "'current-user' requires a user request identity");
  }
  return actor;
}

function parseWorkflowId(value) {
  const workflowId = stringField(value, "workflowId", { nullable: true, maxLength: 128 });
  if (workflowId === "") {
    throw new ApiError(400, "INVALID_FIELD", "'workflowId' cannot be empty");
  }
  return workflowId;
}

function parseTaskCreate(body) {
  assertPlainObject(body);
  assertAllowedKeys(body, new Set([
    "projectId", "title", "description", "status", "priority", "labels", "sortOrder", "threadId",
    "assigneeTarget", "workflowId", "developmentContext", "startDate", "dueDate", "recurrence",
  ]));
  const projectId = validateProjectId(body.projectId ?? DEFAULT_PROJECT_ID);
  const task = {
    projectId,
    title: stringField(body.title, "title", { required: true, maxLength: 240 }),
    description: stringField(body.description ?? "", "description", { maxLength: 100_000 }),
    status: parseStatus(body.status, "todo"),
    priority: parsePriority(body.priority, "none"),
    labels: body.labels === undefined ? [] : parseLabels(body.labels),
    sortOrder: body.sortOrder === undefined ? undefined : parseSortOrder(body.sortOrder),
    threadId: parseThreadId(body.threadId),
    assigneeTarget: parseAssigneeTarget(body.assigneeTarget),
    workflowId: parseWorkflowId(body.workflowId ?? null),
    developmentContext: parseDevelopmentContext(body.developmentContext ?? null),
    startDate: parseDueDate(body.startDate ?? null, "startDate"),
    dueDate: parseDueDate(body.dueDate ?? null),
    recurrence: parseRecurrence(body.recurrence ?? null),
  };
  if (task.recurrence && !task.dueDate) {
    throw new ApiError(400, "INVALID_FIELD", "A recurring issue requires 'dueDate'");
  }
  return task;
}

function parseTaskPatch(body) {
  assertPlainObject(body);
  assertAllowedKeys(body, new Set([
    "version", "title", "description", "status", "priority", "labels", "threadId",
    "assigneeTarget", "workflowId", "developmentContext", "startDate", "dueDate", "recurrence",
  ]));
  const version = parseVersion(body.version);
  const threadId = parseThreadId(body.threadId);
  const assigneeTarget = parseAssigneeTarget(body.assigneeTarget);
  const changes = {};
  if (body.title !== undefined) changes.title = stringField(body.title, "title", { required: true, maxLength: 240 });
  if (body.description !== undefined) changes.description = stringField(body.description, "description", { maxLength: 100_000 });
  if (body.status !== undefined) changes.status = parseStatus(body.status);
  if (body.priority !== undefined) changes.priority = parsePriority(body.priority);
  if (body.labels !== undefined) changes.labels = parseLabels(body.labels);
  if (body.workflowId !== undefined) changes.workflowId = parseWorkflowId(body.workflowId);
  if (body.developmentContext !== undefined) changes.developmentContext = parseDevelopmentContext(body.developmentContext);
  if (body.startDate !== undefined) changes.startDate = parseDueDate(body.startDate, "startDate");
  if (body.dueDate !== undefined) changes.dueDate = parseDueDate(body.dueDate);
  if (body.recurrence !== undefined) changes.recurrence = parseRecurrence(body.recurrence);
  if (changes.recurrence && body.dueDate === null) {
    throw new ApiError(400, "INVALID_FIELD", "A recurring issue requires 'dueDate'");
  }
  if (Object.keys(changes).length === 0 && assigneeTarget === undefined) {
    throw new ApiError(400, "INVALID_BODY", "PATCH requires at least one task field");
  }
  return { version, changes, threadId, assigneeTarget };
}

function parseMove(body) {
  assertPlainObject(body);
  assertAllowedKeys(body, new Set(["version", "status", "sortOrder", "threadId"]));
  return {
    version: parseVersion(body.version),
    status: parseStatus(body.status),
    sortOrder: body.sortOrder === undefined ? undefined : parseSortOrder(body.sortOrder),
    threadId: parseThreadId(body.threadId),
  };
}

/**
 * True when the project workspace is a git repo with uncommitted changes —
 * the precondition for the visible「处理中 → 提交 → done」handoff on human
 * confirm.
 */
async function hasWorkspaceChanges(project) {
  if (!project?.workspacePath) return false;
  try {
    const { stdout } = await execFileAsync("git", ["-C", project.workspacePath, "status", "--porcelain"]);
    return stdout.trim() !== "";
  } catch {
    return false;
  }
}

/**
 * Auto-commit when a human confirms completion (move to done): commit the
 * project workspace changes with the issue identifier in the message so every
 * confirmed issue leaves a traceable commit. Returns true when a commit was
 * actually created; false when there was nothing to commit, the workspace is
 * not a git repo, or git failed (all logged, never thrown). The commit is
 * workspace-wide (add -A): the server cannot tell which files belong to
 * which issue.
 */
async function autoCommitOnDone(project, task) {
  if (!project?.workspacePath) return false;
  const message = `${task.identifier} ${task.title}`.slice(0, 200);
  try {
    await execFileAsync("git", ["-C", project.workspacePath, "add", "-A"]);
    const { stdout } = await execFileAsync("git", ["-C", project.workspacePath, "commit", "-m", message]);
    console.log(`auto-commit ${task.identifier}: ${stdout.trim().split("\n")[0]}`);
    return true;
  } catch (error) {
    const reason = String(error.stderr ?? error.message ?? "").trim().split("\n")[0] || "git failed";
    console.log(`auto-commit ${task.identifier}: skipped (${reason})`);
    return false;
  }
}

function parseArchive(body) {
  assertPlainObject(body);
  assertAllowedKeys(body, new Set(["version", "threadId"]));
  return { version: parseVersion(body.version), threadId: parseThreadId(body.threadId) };
}

function parseIssueRelationType(value) {
  if (!["parent", "blocks", "blocked_by", "related"].includes(value)) {
    throw new ApiError(
      400,
      "INVALID_FIELD",
      "'relation type' must be parent, blocks, blocked_by, or related",
    );
  }
  return value;
}

function parseCommentCreate(body) {
  assertPlainObject(body);
  assertAllowedKeys(body, new Set(["body", "threadId"]));
  return {
    body: stringField(body.body ?? "", "body", { maxLength: 100_000 }),
    threadId: parseThreadId(body.threadId),
  };
}

function parseCommentPatch(body) {
  assertPlainObject(body);
  assertAllowedKeys(body, new Set(["version", "body", "threadId"]));
  if (body.body === undefined) {
    throw new ApiError(400, "INVALID_FIELD", "'body' is required");
  }
  return {
    version: parseVersion(body.version),
    body: stringField(body.body, "body", { maxLength: 100_000 }),
    threadId: parseThreadId(body.threadId),
  };
}

function parseAttachmentHeaders(request) {
  const encodedFilename = request.headers["x-taskboard-filename"];
  if (typeof encodedFilename !== "string") {
    throw new ApiError(400, "INVALID_FILENAME", "X-Taskboard-Filename is required");
  }
  let filename;
  try {
    filename = decodeURIComponent(encodedFilename).trim();
  } catch {
    throw new ApiError(400, "INVALID_FILENAME", "Attachment filename contains invalid encoding");
  }
  if (
    filename.length === 0
    || filename.length > 240
    || filename === "."
    || filename === ".."
    || /[\u0000-\u001f\u007f/\\]/.test(filename)
  ) {
    throw new ApiError(400, "INVALID_FILENAME", "Attachment filename is invalid");
  }

  const rawContentType = request.headers["content-type"];
  const contentType = typeof rawContentType === "string"
    ? rawContentType.split(";", 1)[0].trim().toLowerCase()
    : "application/octet-stream";
  if (contentType.length === 0 || contentType.length > 200 || !/^[!#$%&'*+.^_`|~0-9a-z-]+\/[!#$%&'*+.^_`|~0-9a-z-]+$/.test(contentType)) {
    throw new ApiError(415, "UNSUPPORTED_MEDIA_TYPE", "Attachment Content-Type is invalid");
  }
  return { filename, contentType };
}

async function readBody(request, limit, tooLargeMessage) {
  const declaredLength = Number(request.headers["content-length"] ?? 0);
  if (Number.isFinite(declaredLength) && declaredLength > limit) {
    throw new ApiError(413, "BODY_TOO_LARGE", tooLargeMessage);
  }

  const chunks = [];
  let length = 0;
  for await (const chunk of request) {
    length += chunk.length;
    if (length > limit) {
      throw new ApiError(413, "BODY_TOO_LARGE", tooLargeMessage);
    }
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function readJson(
  request,
  limit = JSON_BODY_LIMIT,
  tooLargeMessage = "Request body cannot exceed 1 MiB",
) {
  const contentType = request.headers["content-type"]?.split(";", 1)[0].trim().toLowerCase();
  if (contentType !== "application/json") {
    throw new ApiError(415, "UNSUPPORTED_MEDIA_TYPE", "Content-Type must be application/json");
  }
  const body = await readBody(request, limit, tooLargeMessage);
  const length = body.length;
  if (length === 0) {
    throw new ApiError(400, "INVALID_JSON", "Request body cannot be empty");
  }
  try {
    return JSON.parse(body.toString("utf8"));
  } catch {
    throw new ApiError(400, "INVALID_JSON", "Request body must contain valid JSON");
  }
}

async function assertEmptyRequestBody(request, routeLabel) {
  const body = await readBody(request, JSON_BODY_LIMIT, "Request body cannot exceed 1 MiB");
  if (body.length > 0) {
    throw new ApiError(400, "INVALID_BODY", `${routeLabel} does not accept a request body`);
  }
}

function parseTaskFilters(searchParams) {
  const allowed = new Set(["projectId", "status", "archived", "threadId"]);
  for (const key of searchParams.keys()) {
    if (!allowed.has(key)) {
      throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", `Unknown query parameter '${key}'`);
    }
    if (searchParams.getAll(key).length !== 1) {
      throw new ApiError(400, "INVALID_QUERY_PARAMETER", `Query parameter '${key}' cannot be repeated`);
    }
  }

  const projectIdValue = searchParams.get("projectId");
  const statusValue = searchParams.get("status");
  const archived = searchParams.get("archived") ?? "false";
  if (statusValue !== null && !isTaskStatus(statusValue)) {
    throw new ApiError(400, "INVALID_QUERY_PARAMETER", "Invalid task status");
  }
  if (!new Set(["true", "false", "all"]).has(archived)) {
    throw new ApiError(400, "INVALID_QUERY_PARAMETER", "'archived' must be true, false, or all");
  }
  const projectId = projectIdValue === null ? undefined : validateProjectId(projectIdValue);
  const threadIdValue = searchParams.get("threadId");
  if (threadIdValue !== null && (threadIdValue === "" || threadIdValue.length > 256)) {
    throw new ApiError(400, "INVALID_QUERY_PARAMETER", "Invalid task threadId filter");
  }
  return { projectId, status: statusValue ?? undefined, archived, threadId: threadIdValue ?? undefined };
}

/**
 * Permission preset id. The built-in codex sandboxes are the historical set,
 * but a host engine may offer its own presets (the DSH engine mirrors the
 * host's permission picker, including `auto` and configured names), so the
 * request layer only enforces the shape and the engine's catalog decides
 * whether a value is actually selectable.
 */
function parseAiSandbox(value) {
  if (value === undefined) return undefined;
  const sandbox = stringField(value, "sandbox", { maxLength: 64 });
  if (sandbox === "") {
    throw new ApiError(400, "INVALID_SANDBOX", "'sandbox' cannot be empty");
  }
  return sandbox;
}

function parseAiSetting(value, name, maxLength) {
  const setting = stringField(value, name, { maxLength });
  if (setting === "") {
    throw new ApiError(400, "INVALID_FIELD", `'${name}' cannot be empty`);
  }
  return setting;
}

function parseAiThreadCreate(body) {
  assertPlainObject(body);
  assertAllowedKeys(body, new Set([
    "projectId",
    "issueId",
    "title",
    "model",
    "reasoningEffort",
    "sandbox",
  ]));
  return {
    projectId: validateProjectId(body.projectId),
    issueId: parseAiSetting(body.issueId, "issueId", 128),
    title: parseAiSetting(body.title, "title", 160),
    model: parseAiSetting(body.model, "model", 128),
    reasoningEffort: parseAiSetting(body.reasoningEffort, "reasoningEffort", 64),
    sandbox: parseAiSandbox(body.sandbox),
  };
}

function parseAiThreadPatch(body) {
  assertPlainObject(body);
  assertAllowedKeys(body, new Set(["title", "model", "reasoningEffort", "sandbox"]));
  const input = {};
  if (body.title !== undefined) input.title = parseAiSetting(body.title, "title", 160);
  if (body.model !== undefined) input.model = parseAiSetting(body.model, "model", 128);
  if (body.reasoningEffort !== undefined) {
    input.reasoningEffort = parseAiSetting(body.reasoningEffort, "reasoningEffort", 64);
  }
  if (body.sandbox !== undefined) input.sandbox = parseAiSandbox(body.sandbox);
  if (Object.keys(input).length === 0) {
    throw new ApiError(400, "INVALID_BODY", "PATCH requires at least one thread setting");
  }
  return input;
}

function parseAiSkillIds(value) {
  if (value === undefined) return undefined;
  if (!Array.isArray(value) || value.length > 20) {
    throw new ApiError(400, "INVALID_FIELD", "'skillIds' must be an array with at most 20 entries");
  }
  const skillIds = value.map((skillId, index) => (
    stringField(skillId, `skillIds[${index}]`, { required: true, maxLength: 256 })
  ));
  return skillIds;
}

function parseAiAttachments(value) {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > AI_CHAT_ATTACHMENT_LIMIT) {
    throw new ApiError(
      400,
      "INVALID_ATTACHMENT",
      `'attachments' must be an array with at most ${AI_CHAT_ATTACHMENT_LIMIT} files`,
    );
  }
  return value.map((attachment, index) => {
    assertPlainObject(attachment);
    assertAllowedKeys(attachment, new Set(["filename", "contentType", "dataBase64"]));
    const filename = stringField(attachment.filename, `attachments[${index}].filename`, {
      required: true,
      maxLength: 240,
    });
    if (/[\u0000-\u001f\u007f/\\]/.test(filename)) {
      throw new ApiError(
        400,
        "INVALID_ATTACHMENT",
        `'attachments[${index}].filename' is invalid`,
      );
    }
    const contentType = stringField(
      attachment.contentType,
      `attachments[${index}].contentType`,
      { required: true, maxLength: 256 },
    ).toLowerCase();
    const dataBase64 = stringField(
      attachment.dataBase64,
      `attachments[${index}].dataBase64`,
      { required: true, maxLength: AI_CHAT_TURN_BODY_LIMIT },
    );
    if (
      dataBase64.length % 4 !== 0
      || !/^[A-Za-z0-9+/]+={0,2}$/.test(dataBase64)
    ) {
      throw new ApiError(
        400,
        "INVALID_ATTACHMENT",
        `'attachments[${index}].dataBase64' must contain valid base64`,
      );
    }
    const data = Buffer.from(dataBase64, "base64");
    if (data.length === 0 || data.toString("base64") !== dataBase64) {
      throw new ApiError(
        400,
        "INVALID_ATTACHMENT",
        `'attachments[${index}].dataBase64' must contain valid base64`,
      );
    }
    return { filename, contentType, data, size: data.length };
  });
}

function parseAiTurn(body) {
  assertPlainObject(body);
  assertAllowedKeys(body, new Set([
    "message",
    "skillIds",
    "dangerFullAccessConfirmed",
    "attachments",
  ]));
  if (
    body.dangerFullAccessConfirmed !== undefined
    && typeof body.dangerFullAccessConfirmed !== "boolean"
  ) {
    throw new ApiError(400, "INVALID_FIELD", "'dangerFullAccessConfirmed' must be a boolean");
  }
  const message = stringField(body.message ?? "", "message", { maxLength: 100_000 });
  const skillIds = parseAiSkillIds(body.skillIds) ?? [];
  if (message.split(AI_CHAT_SKILL_MARKER).length - 1 !== skillIds.length) {
    throw new ApiError(400, "INVALID_FIELD", "'skillIds' must match the Skill markers in 'message'");
  }
  const attachments = parseAiAttachments(body.attachments);
  if (message === "" && attachments.length === 0) {
    throw new ApiError(
      400,
      "INVALID_MESSAGE",
      "A message or at least one attachment is required",
    );
  }
  return {
    message,
    skillIds,
    dangerFullAccessConfirmed: body.dangerFullAccessConfirmed,
    attachments,
  };
}

class EventHub {
  constructor() {
    this.clients = new Set();
    /** In-process listeners (the plugin host lives in this process). */
    this.listeners = new Set();
    this.keepAlive = setInterval(() => {
      for (const response of this.clients) response.write(": keep-alive\n\n");
    }, 20_000);
    this.keepAlive.unref();
  }

  connect(request, response) {
    response.writeHead(200, {
      connection: "keep-alive",
      "cache-control": "no-cache, no-transform",
      "content-type": "text/event-stream; charset=utf-8",
      "x-accel-buffering": "no",
    });
    response.write(": connected\n\n");
    this.clients.add(response);
    request.once("close", () => this.clients.delete(response));
  }

  /**
   * Subscribe to every emitted event from inside this process — the board
   * server runs in the plugin host, so the host can react to a user action
   * (a comment) without polling. Listener errors never break the HTTP reply.
   * @param listener - receives the same event object SSE clients get.
   * @returns idempotent unsubscribe.
   */
  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  emit(type, value) {
    const event = {
      type,
      projectId: value.projectId ?? value.project?.id ?? value.task?.projectId,
      taskId: value.task?.id ?? value.comment?.taskId ?? value.attachment?.taskId,
      ...value,
      at: new Date().toISOString(),
    };
    const message = `event: ${type}\ndata: ${JSON.stringify(event)}\n\n`;
    for (const response of this.clients) response.write(message);
    for (const listener of this.listeners) {
      try {
        listener(event);
      } catch (error) {
        console.error("taskboard event listener failed:", error);
      }
    }
  }

  close() {
    clearInterval(this.keepAlive);
    for (const response of this.clients) response.end();
    this.clients.clear();
    this.listeners.clear();
  }
}

async function serveStatic(request, response, pathname, staticDirectory) {
  if (request.method !== "GET" && request.method !== "HEAD") return false;
  let decodedPath;
  try {
    decodedPath = decodeURIComponent(pathname);
  } catch {
    throw new ApiError(400, "INVALID_PATH", "URL path contains invalid encoding");
  }
  if (decodedPath.includes("\0")) {
    throw new ApiError(400, "INVALID_PATH", "URL path is invalid");
  }

  const root = path.resolve(staticDirectory);
  const relativePath = decodedPath === "/" ? "index.html" : decodedPath.replace(/^\/+/, "");
  let filename = path.resolve(root, relativePath);
  if (filename !== root && !filename.startsWith(`${root}${path.sep}`)) {
    throw new ApiError(400, "INVALID_PATH", "URL path is outside the static directory");
  }

  let fileStats;
  try {
    fileStats = await stat(filename);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  if (!fileStats?.isFile() && !path.extname(relativePath)) {
    filename = path.join(root, "index.html");
    try {
      fileStats = await stat(filename);
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
  }
  if (!fileStats?.isFile()) return false;

  const body = await readFile(filename);
  const headers = {
    "cache-control": path.basename(filename) === "index.html" ? "no-store" : "public, max-age=31536000, immutable",
    "content-length": body.length,
    "content-type": CONTENT_TYPES.get(path.extname(filename).toLowerCase()) ?? "application/octet-stream",
  };
  response.writeHead(200, headers);
  response.end(request.method === "HEAD" ? undefined : body);
  return true;
}

function methodNotAllowed(response, allowed) {
  sendJson(response, 405, {
    error: { code: "METHOD_NOT_ALLOWED", message: `Allowed methods: ${allowed.join(", ")}` },
  }, { allow: allowed.join(", ") });
}

function codexProjectRoot(state, projectId) {
  if (!projectId || !state || typeof state !== "object") return null;
  const project = state["local-projects"]?.[projectId];
  const root = Array.isArray(project?.rootPaths) ? project.rootPaths[0] : null;
  return typeof root === "string" && root.trim() ? root : null;
}

async function readCodexProjectWorkspaces(codexStatePath) {
  try {
    const state = JSON.parse(await readFile(codexStatePath, "utf8"));
    const projects = state["local-projects"];
    if (!projects || typeof projects !== "object" || Array.isArray(projects)) return {};
    return Object.fromEntries(Object.keys(projects).flatMap((projectId) => {
      const root = codexProjectRoot(state, projectId);
      return root ? [[projectId, root]] : [];
    }));
  } catch {
    return {};
  }
}

function latestThreadCwd(value, threadId) {
  const matches = [];
  const stack = [value];
  while (stack.length > 0) {
    const candidate = stack.pop();
    if (!candidate || typeof candidate !== "object") continue;
    if (candidate.conversationId === threadId && typeof candidate.cwd === "string" && candidate.cwd.trim()) {
      matches.push(candidate);
    }
    stack.push(...(Array.isArray(candidate) ? candidate : Object.values(candidate)));
  }
  matches.sort((left, right) => Number(right.updatedAtMs ?? 0) - Number(left.updatedAtMs ?? 0));
  return matches[0]?.cwd ?? null;
}

async function resolveProjectWorkspace(project, codexProjectId, codexThreadId, codexStatePath, codexProcessesPath) {
  try {
    const state = JSON.parse(await readFile(codexStatePath, "utf8"));
    const assignment = state["thread-project-assignments"]?.[codexThreadId];
    const root = codexProjectRoot(state, project.id)
      ?? codexProjectRoot(state, codexProjectId)
      ?? codexProjectRoot(state, assignment?.projectId)
      ?? (typeof assignment?.cwd === "string" ? assignment.cwd : null);
    if (root) return root;
  } catch {}
  if (project.workspacePath) return project.workspacePath;
  if (!codexThreadId) return null;
  try {
    const processes = JSON.parse(await readFile(codexProcessesPath, "utf8"));
    return latestThreadCwd(processes, codexThreadId);
  } catch {
    return null;
  }
}

function parseWorktrees(output) {
  const contexts = [];
  for (const block of output.trim().split(/\n\s*\n/)) {
    if (!block) continue;
    let worktreePath = "";
    let branch = null;
    for (const line of block.split("\n")) {
      if (line.startsWith("worktree ")) worktreePath = line.slice(9);
      if (line.startsWith("branch refs/heads/")) branch = line.slice(18);
    }
    if (worktreePath) contexts.push({ type: "worktree", path: worktreePath, branch });
  }
  return contexts;
}

async function scanDevelopmentContexts(workspacePath) {
  if (!workspacePath) return { workspacePath: null, contexts: [] };
  try {
    const rootResult = await execFileAsync("git", ["-C", workspacePath, "rev-parse", "--show-toplevel"], {
      timeout: 4_000,
      maxBuffer: 1024 * 1024,
    });
    const root = rootResult.stdout.trim();
    const [branchesResult, worktreesResult] = await Promise.all([
      execFileAsync("git", ["-C", root, "for-each-ref", "--format=%(refname:short)", "refs/heads"], {
        timeout: 4_000,
        maxBuffer: 1024 * 1024,
      }),
      execFileAsync("git", ["-C", root, "worktree", "list", "--porcelain"], {
        timeout: 4_000,
        maxBuffer: 1024 * 1024,
      }),
    ]);
    const branches = branchesResult.stdout.split("\n").map((branch) => branch.trim()).filter(Boolean);
    return {
      workspacePath: root,
      contexts: [
        ...branches.map((branch) => ({ type: "branch", branch })),
        ...parseWorktrees(worktreesResult.stdout),
      ],
    };
  } catch {
    return { workspacePath, contexts: [] };
  }
}

async function discoverSkills(codexExecutable, workspacePath) {
  const entries = await new Promise((resolve, reject) => {
    const child = spawn(codexExecutable, ["app-server", "--stdio"], {
      cwd: workspacePath,
      env: aiEngineEnv(),
      stdio: ["pipe", "pipe", "ignore"],
    });
    let settled = false;
    let buffer = "";
    const timeout = setTimeout(() => {
      finish(new Error("Timed out while reading AI engine skills"));
    }, 10_000);

    function finish(error, value) {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      child.stdin.end();
      child.kill("SIGTERM");
      if (error) reject(error);
      else resolve(value);
    }

    function send(message) {
      child.stdin.write(`${JSON.stringify(message)}\n`);
    }

    function handleMessage(message) {
      if (message?.id === 1) {
        if (message.error) {
          finish(new Error("AI engine app-server rejected initialization"));
          return;
        }
        send({ method: "initialized" });
        send({
          id: 2,
          method: "skills/list",
          params: { cwds: [workspacePath], forceReload: false },
        });
        return;
      }
      if (message?.id !== 2) return;
      if (message.error) {
        finish(new Error("AI engine app-server could not list skills"));
        return;
      }
      finish(null, Array.isArray(message.result?.data) ? message.result.data : []);
    }

    child.stdout.setEncoding("utf8");
    child.stdout.on("data", (chunk) => {
      buffer += chunk;
      let newlineIndex = buffer.indexOf("\n");
      while (newlineIndex >= 0) {
        const line = buffer.slice(0, newlineIndex).trim();
        buffer = buffer.slice(newlineIndex + 1);
        if (line) {
          try {
            handleMessage(JSON.parse(line));
          } catch {}
        }
        newlineIndex = buffer.indexOf("\n");
      }
    });
    child.stdin.on("error", (error) => finish(error));
    child.once("error", (error) => finish(error));
    child.once("exit", (code, signal) => {
      if (!settled) {
        finish(new Error(`AI engine app-server exited before listing skills (${signal || code})`));
      }
    });
    child.once("spawn", () => {
      send({
        id: 1,
        method: "initialize",
        params: {
          clientInfo: { name: "codex-taskboard", version: "0.1.0" },
          capabilities: { experimentalApi: true },
        },
      });
    });
  });

  const unique = new Map();
  for (const entry of entries) {
    if (!Array.isArray(entry?.skills)) continue;
    for (const skill of entry.skills) {
      if (
        !skill
        || typeof skill !== "object"
        || skill.enabled === false
        || typeof skill.name !== "string"
        || !skill.name.trim()
      ) {
        continue;
      }
      const id = skill.name.trim();
      if (unique.has(id)) continue;
      const displayName = typeof skill.interface?.displayName === "string"
        ? skill.interface.displayName.trim()
        : "";
      unique.set(id, {
        id,
        label: displayName || id,
        description: typeof skill.description === "string" ? skill.description.trim() : "",
        path: typeof skill.path === "string" ? skill.path.trim() : "",
        scope: ["user", "repo", "system", "admin"].includes(skill.scope)
          ? skill.scope
          : "user",
      });
    }
  }
  return [...unique.values()].sort((left, right) => left.label.localeCompare(right.label));
}

async function discoverMcpServers(codexExecutable) {
  const result = await execFileAsync(codexExecutable, ["mcp", "list", "--json"], {
    env: aiEngineEnv(),
    timeout: 8_000,
    maxBuffer: 2 * 1024 * 1024,
  });
  const entries = JSON.parse(result.stdout);
  if (!Array.isArray(entries)) throw new Error("AI engine returned an invalid MCP server list");
  return entries
    .filter((entry) => (
      entry
      && typeof entry === "object"
      && typeof entry.name === "string"
      && entry.name.trim()
      && entry.enabled !== false
    ))
    .map((entry) => ({
      id: entry.name.trim(),
      label: entry.name.trim(),
      transport: typeof entry.transport?.type === "string"
        ? entry.transport.type
        : "unknown",
    }))
    .sort((left, right) => left.label.localeCompare(right.label));
}

async function discoverWorkflowCapabilities(resolved, workspacePath) {
  const [skills, mcpServers] = await Promise.all([
    discoverSkills(resolved.codexExecutable, workspacePath),
    discoverMcpServers(resolved.codexExecutable),
  ]);
  return { skills, mcpServers };
}

export function resolveServerOptions(options = {}) {
  const configuredDataDirectory = options.dataDirectory ?? process.env.CODEX_TASKBOARD_DATA_DIR;
  const dataDirectory = configuredDataDirectory
    ? path.resolve(configuredDataDirectory)
    : path.join(PROJECT_ROOT, ".data");
  const codexHome = process.env.CODEX_HOME || path.join(os.homedir(), ".codex");
  return {
    dataDirectory,
    databasePath: options.databasePath ?? path.join(dataDirectory, "taskboard.sqlite"),
    attachmentsDirectory: options.attachmentsDirectory ?? path.join(dataDirectory, "attachments"),
    cloudConfigPath: options.cloudConfigPath ?? path.join(dataDirectory, "cloud-companion.json"),
    staticDirectory: options.staticDirectory ?? path.join(PROJECT_ROOT, "dist", "web"),
    skillPath: options.skillPath ?? path.join(PROJECT_ROOT, "skills", "manage-taskboard", "SKILL.md"),
    routinesDirectory: options.routinesDirectory ?? process.env.CODEX_TASKBOARD_ROUTINES_DIR ?? null,
    routinesProjectDir: options.routinesProjectDir
      ?? process.env.DSH_ROUTINES_PROJECT_DIR
      ?? discoverRoutinesProjectDir() ?? null,
    routinesDaemonLabel: options.routinesDaemonLabel
      ?? process.env.DSH_ROUTINES_DAEMON_LABEL
      ?? discoverRoutinesDaemonLabel() ?? null,
    codexExecutable: options.codexExecutable ?? process.env.CODEX_EXECUTABLE ?? "codex",
    codexStatePath: options.codexStatePath
      ?? path.join(codexHome, ".codex-global-state.json"),
    codexProcessesPath: options.codexProcessesPath
      ?? path.join(codexHome, "process_manager", "chat_processes.json"),
  };
}

/** Scan ~/Library/LaunchAgents for a dsh-routines agent and return its WorkingDirectory. */
function discoverRoutinesProjectDir() {
  const agent = findRoutinesLaunchAgent();
  return agent?.workingDirectory ?? null;
}

/** Scan ~/Library/LaunchAgents for a dsh-routines agent and return its Label. */
function discoverRoutinesDaemonLabel() {
  const agent = findRoutinesLaunchAgent();
  return agent?.label ?? null;
}

/**
 * Locate the launchd agent that runs the dsh-routines scheduler (the process
 * that owns <projectDir>/.dsh/routines/state.json). The scheduler decides its
 * state path from its own working directory (projectDir), which is the
 * agent's WorkingDirectory — not the board's routines directory. Parse the
 * plist textually (macOS-only; env overrides exist for other setups).
 * @returns {{label: string, workingDirectory: string} | null}
 */
function findRoutinesLaunchAgent() {
  try {
    const agentsDir = path.join(os.homedir(), "Library", "LaunchAgents");
    const files = readdirSyncSafe(agentsDir);
    for (const file of files) {
      if (!file.endsWith(".plist")) continue;
      if (!/dsh|routine/i.test(file)) continue;
      const text = readFileSyncSafe(path.join(agentsDir, file));
      if (text === null) continue;
      const label = /<key>Label<\/key>\s*<string>([^<]+)<\/string>/.exec(text)?.[1];
      const workingDirectory = /<key>WorkingDirectory<\/key>\s*<string>([^<]+)<\/string>/.exec(text)?.[1];
      const argv = /<key>ProgramArguments<\/key>[\s\S]*?<\/array>/.exec(text)?.[0] ?? "";
      const runsRoutines = /routines/.test(argv) || /dsh/.test(argv);
      if (label && workingDirectory && runsRoutines) {
        return { label, workingDirectory };
      }
    }
  } catch {
    // Not macOS or no agents dir: env overrides are the fallback.
  }
  return null;
}

function readdirSyncSafe(dir) {
  try {
    return readdirSync(dir);
  } catch {
    return [];
  }
}

function readFileSyncSafe(file) {
  try {
    return readFileSync(file, "utf8");
  } catch {
    return null;
  }
}

export function resolvePort(value = process.env.CODEX_TASKBOARD_PORT ?? "47824") {
  const port = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error("CODEX_TASKBOARD_PORT must be an integer between 1 and 65535");
  }
  return port;
}

export function resolveHost(value = process.env.CODEX_TASKBOARD_HOST ?? "0.0.0.0") {
  const host = String(value).trim();
  if (host !== "127.0.0.1" && host !== "0.0.0.0") {
    throw new Error("CODEX_TASKBOARD_HOST must be 127.0.0.1 or 0.0.0.0");
  }
  return host;
}

/** Latest run record per routine name, from a routines `runs/` directory. */
async function readRoutineRuns(runsDirectory) {
  const byRoutine = new Map();
  let files;
  try {
    files = await readdir(runsDirectory);
  } catch {
    return byRoutine;
  }
  for (const file of files) {
    if (!file.startsWith("run-") || !file.endsWith(".json")) continue;
    try {
      const record = JSON.parse(await readFile(path.join(runsDirectory, file), "utf8"));
      if (typeof record.routine !== "string" || record.routine === "") continue;
      const existing = byRoutine.get(record.routine);
      if (!existing || (record.startedAt ?? 0) > (existing.startedAt ?? 0)) {
        byRoutine.set(record.routine, record);
      }
    } catch {
      // Skip unparsable run records.
    }
  }
  return byRoutine;
}

/** Latest run record for one routine from its cwd-local runs dir, or null. */
async function latestRoutineRun(cwd, name) {
  if (typeof cwd !== "string" || cwd === "") return null;
  const byName = await readRoutineRuns(path.join(cwd, ".dsh", "routines", "runs"));
  return byName.get(name) ?? null;
}

/**
 * List ALL run records for one routine (newest first), merged from the global
 * routines runs dir and the per-cwd runs dir. Powers the automation panel's
 * run-history tab.
 */
async function listRoutineRuns(routinesDirectory, cwd, name, limit = 30) {
  const records = [];
  const dirs = [
    routinesDirectory ? path.join(routinesDirectory, "runs") : null,
    typeof cwd === "string" && cwd !== "" ? path.join(cwd, ".dsh", "routines", "runs") : null,
  ].filter(Boolean);
  for (const dir of [...new Set(dirs)]) {
    let files;
    try {
      files = await readdir(dir);
    } catch {
      continue;
    }
    for (const file of files) {
      if (!file.startsWith("run-") || !file.endsWith(".json")) continue;
      try {
        const record = JSON.parse(await readFile(path.join(dir, file), "utf8"));
        if (record.routine === name) records.push(record);
      } catch {
        // Skip unparsable run records.
      }
    }
  }
  records.sort((a, b) => (b.startedAt ?? 0) - (a.startedAt ?? 0));
  return records.slice(0, limit);
}

/**
 * List routines: parsed YAML fields plus the latest run record per routine.
 * Claim routines are virtual — their on/off state lives in the board DB, so
 * `paused` is reported as the inverse of the claim automation switch (the
 * YAML itself is always paused so the external ops runner skips it).
 * @param claimSwitch - optional (routineName) => automation.enabled lookup.
 * @param routinesProjectDir - scheduler working dir whose state.json owns the
 *   authoritative paused list for non-claim routines (dsh-routines ignores the
 *   YAML `paused` key; pause/resume lives in <projectDir>/.dsh/routines/state.json).
 */
async function listRoutines(routinesDirectory, claimSwitch, routinesProjectDir) {
  if (!routinesDirectory) return { routinesDirectory: null, routines: [] };
  let files;
  try {
    files = await readdir(routinesDirectory);
  } catch {
    return { routinesDirectory, routines: [] };
  }
  const runs = await readRoutineRuns(path.join(routinesDirectory, "runs"));
  const statePaused = await readRoutinesStatePaused(routinesProjectDir);
  const now = Date.now();
  const routines = [];
  for (const file of files) {
    if (!file.endsWith(".yaml")) continue;
    try {
      const text = await readFile(path.join(routinesDirectory, file), "utf8");
      const parsed = parseRoutineYaml(text);
      if (!parsed.name) continue;
      // dsh-routines writes run records under <routine cwd>/.dsh/routines/runs
      // (per-project), so fall back there for project-scoped routines.
      const run = runs.get(parsed.name)
        ?? await latestRoutineRun(parsed.cwd, parsed.name);
      const { raw, unknownKeys, ...fields } = parsed;
      const entry = {
        ...fields,
        nextRunAt: computeNextRun(parsed.schedule, now),
        lastRun: run ? {
          status: run.status ?? null,
          startedAt: run.startedAt ?? null,
          finishedAt: run.finishedAt ?? null,
          durationMs: run.durationMs ?? null,
          exitCode: run.exitCode ?? null,
          error: run.error ?? null,
          digest: run.digest ?? null,
          sessionId: run.sessionId ?? null,
          check: run.check ?? null,
        } : null,
        raw,
        unknownKeys,
      };
      if (claimSwitch) {
        const claimEnabled = claimSwitch(parsed.name);
        if (claimEnabled !== undefined) {
          // Claim routine: its on/off switch IS the board automation record.
          entry.paused = !claimEnabled;
        } else if (statePaused) {
          // Non-claim routine: the dsh-routines scheduler only honours the
          // paused set in its state.json (YAML `paused` is not part of its
          // schema), so report the authoritative state.
          entry.paused = statePaused.has(parsed.name);
        }
      }
      routines.push(entry);
    } catch {
      // Skip unparsable routine files.
    }
  }
  routines.sort((a, b) => String(a.name).localeCompare(String(b.name)));
  return { routinesDirectory, routines };
}

/**
 * Read the dsh-routines paused set from the scheduler's state.json.
 * The scheduler owns `<projectDir>/.dsh/routines/state.json` and decides
 * pause purely from its `paused` list — YAML `paused` keys are ignored.
 * @returns {Promise<Set<string> | null>} - null when the project dir is
 *   unknown or the state file cannot be read (caller falls back to YAML).
 */
async function readRoutinesStatePaused(routinesProjectDir) {
  if (!routinesProjectDir) return null;
  try {
    const text = await readFile(
      path.join(routinesProjectDir, ".dsh", "routines", "state.json"),
      "utf8",
    );
    const parsed = JSON.parse(text);
    const paused = Array.isArray(parsed?.paused) ? parsed.paused : [];
    return new Set(paused.filter((name) => typeof name === "string"));
  } catch {
    return null;
  }
}

/**
 * Persist a routine's paused state in the dsh-routines scheduler's
 * state.json (the only paused control the external runner honours), then
 * restart the scheduler daemon so it re-reads the file. The daemon loads
 * state.json once at boot and never watches it, so a restart is required
 * for the toggle to take effect.
 * @param name - routine name.
 * @param paused - desired paused flag.
 * @param routinesProjectDir - scheduler working dir (owner of state.json).
 * @param daemonLabel - launchd label to kickstart, or null to skip restart.
 * @returns true when the state file was written.
 */
async function applyRoutinesPaused(name, paused, routinesProjectDir, daemonLabel) {
  if (!routinesProjectDir) return false;
  const statePath = path.join(routinesProjectDir, ".dsh", "routines", "state.json");
  let state;
  try {
    state = JSON.parse(await readFile(statePath, "utf8"));
  } catch {
    state = { paused: [], lastRunAt: {} };
  }
  const pausedList = Array.isArray(state.paused) ? state.paused.filter((n) => typeof n === "string") : [];
  const next = paused
    ? (pausedList.includes(name) ? pausedList : [...pausedList, name])
    : pausedList.filter((n) => n !== name);
  state.paused = next;
  if (typeof state.lastRunAt !== "object" || state.lastRunAt === null) state.lastRunAt = {};
  await mkdir(path.dirname(statePath), { recursive: true });
  const tmp = `${statePath}.tmp-${process.pid}`;
  await writeFile(tmp, `${JSON.stringify(state, null, 2)}\n`, "utf8");
  try {
    await rename(tmp, statePath);
  } catch (error) {
    await unlink(tmp).catch(() => {});
    throw error;
  }
  if (daemonLabel) kickstartRoutinesDaemon(daemonLabel);
  return true;
}

/** Restart the launchd agent running the dsh-routines scheduler (best-effort). */
function kickstartRoutinesDaemon(daemonLabel) {
  try {
    const domain = process.platform === "darwin" ? `gui/${os.userInfo().uid}` : `user/${os.userInfo().uid}`;
    const child = spawn("launchctl", ["kickstart", "-k", `${domain}/${daemonLabel}`], {
      detached: true,
      stdio: "ignore",
    });
    child.unref();
  } catch {
    // Restart failure leaves the state file updated; it applies on the next
    // scheduler boot. Never break the API for a daemon hiccup.
  }
}

/**
 * Fire-and-forget manual run: the ops-profile `dsh routines run` CLI executes
 * the routine as a one-shot (its own scheduler instance only launches this
 * run, never ticks), so the board's 「测试执行」 stays non-blocking. The run
 * record lands in the routines runs/ directory.
 * @param name - the routine name to run now.
 */
function spawnRoutineRun(name) {
  try {
    const child = spawn("dsh", ["--profile", "ops", "routines", "run", name], {
      detached: true,
      stdio: "ignore",
      env: process.env,
    });
    child.unref();
  } catch {
    // Spawn failures surface via the missing run record; never break the API.
  }
}

/** Validate a routine name (safe filename stem). */
function parseRoutineName(value) {
  const name = stringField(value, "name", { required: true, maxLength: 64 });
  if (!/^[a-z0-9][a-z0-9_-]*$/.test(name)) {
    throw new ApiError(400, "INVALID_FIELD", "'name' must be a lowercase slug of letters, numbers, hyphens, or underscores");
  }
  return name;
}

/** Reserved stem of claim-routine names (taskboard-claim-<projectId prefix>). */
const CLAIM_ROUTINE_PREFIX = "taskboard-claim-";

/**
 * Claim conversation id stem: `claim-<projectId 前 8>-<随机 8>`, minted by the
 * host half. The prefix lets the board reject a fixed-session target that is
 * not one of this project's own claim rounds.
 */
const CLAIM_SESSION_PREFIX = "claim-";

/** Resolve a claim-routine name to its project record, or null. */
function claimProjectByName(database, name) {
  if (!name.startsWith(CLAIM_ROUTINE_PREFIX)) return null;
  const prefix = name.slice(CLAIM_ROUTINE_PREFIX.length);
  return database.listProjects().find((p) => p.id.startsWith(prefix)) ?? null;
}

/**
 * The claim automation switch state for a routine name, or undefined when the
 * name is not a claim routine (or its project is gone). Claim routines are
 * virtual: the YAML is always paused (external runner skips it) and the
 * switch lives in the board DB, so the routines page must read it from here.
 */
function claimAutomationEnabled(database, name) {
  const project = claimProjectByName(database, name);
  if (!project) return undefined;
  try {
    return database.getProjectAutomation(project.id).enabled;
  } catch {
    return undefined;
  }
}

/** Parse a deliver list (strings like "file" / "chatnode"). */
function parseDeliverList(value) {
  if (!Array.isArray(value) || value.length === 0) {
    throw new ApiError(400, "INVALID_FIELD", "'deliver' must be a non-empty array of strings");
  }
  const out = [];
  for (const item of value) {
    if (typeof item !== "string" || item.length === 0 || item.length > 32) {
      throw new ApiError(400, "INVALID_FIELD", "'deliver' entries must be short strings");
    }
    out.push(item);
  }
  return out;
}

export function createTaskboardServer(options = {}) {
  const resolved = resolveServerOptions(options);
  const database = new TaskboardDatabase(resolved.databasePath);
  const events = new EventHub();
  const cloudConfig = options.cloudConfigStore ?? createCloudConfigStore({
    configPath: resolved.cloudConfigPath,
  });
  const cloudProxy = createCloudProxy({
    configStore: cloudConfig,
    fetch: options.remoteFetch ?? globalThis.fetch,
    resolveDevelopmentContext: async (projectId, context) => {
      if (!context.branch) return null;
      const config = await cloudConfig.read();
      const workspacePath = config.projectMappings[projectId];
      if (!workspacePath) return null;
      const result = await scanDevelopmentContexts(workspacePath);
      return result.contexts.find((candidate) => (
        candidate.type === "worktree" && candidate.branch === context.branch
      )) ?? null;
    },
  });
  const aiChat = new AiChatService({
    database,
    codexExecutable: resolved.codexExecutable,
    codexStatePath: resolved.codexStatePath,
    manageTaskboardSkillPath: resolved.skillPath,
    // Host-injected turn engine (the DSH plugin runs turns on in-process DSH
    // sessions); absent for the standalone server, which keeps the codex engine.
    agentEngine: options.agentEngine,
  });
  const aiEventResponses = new Set();

  const server = createServer(async (request, response) => {
    response.setHeader("x-content-type-options", "nosniff");
    response.setHeader("referrer-policy", "no-referrer");
    try {
      assertTrustedNetworkRequest(request);
      const url = new URL(request.url, "http://127.0.0.1");
      const pathname = url.pathname;
      const isLocalAiRoute = pathname === "/api/local/ai" || pathname.startsWith("/api/local/ai/");
      if (isLocalAiRoute) {
        assertAiLoopbackRequest(request);
      } else if (pathname.startsWith("/api/local/")) {
        assertLoopbackRequest(request);
      }
      const isMachineCapabilityRoute = pathname === "/api/meta"
        || pathname === "/api/device-workspaces"
        || pathname === "/api/workflow-capabilities"
        || /^\/api\/projects\/[^/]+\/development-contexts$/.test(pathname);
      const capabilityCloudConfig = isMachineCapabilityRoute
        ? await cloudConfig.read()
        : null;
      if (capabilityCloudConfig?.remoteUrl) assertLoopbackRequest(request);

      if (pathname === "/health") {
        if (request.method !== "GET") return methodNotAllowed(response, ["GET"]);
        return sendJson(response, 200, { status: "ok" });
      }

      if (pathname === "/api/local/cloud-session") {
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "Cloud session routes do not accept query parameters");
        }
        if (request.method === "GET") {
          const config = await cloudConfig.read();
          return sendJson(response, 200, config.remoteUrl
            ? {
              mode: "cloud",
              remoteUrl: config.remoteUrl,
              actorName: config.actorName,
              authenticated: true,
            }
            : { mode: "local", authenticated: false });
        }
        if (request.method === "PUT") {
          const body = await readJson(request);
          assertPlainObject(body);
          assertAllowedKeys(body, new Set(["remoteUrl", "actorName", "sharedKey"]));
          try {
            const config = await cloudConfig.configure({
              remoteUrl: body.remoteUrl,
              actorName: body.actorName,
              sharedKey: body.sharedKey,
            });
            return sendJson(response, 200, {
              mode: "cloud",
              remoteUrl: config.remoteUrl,
              actorName: config.actorName,
              authenticated: true,
            });
          } catch (error) {
            throw new ApiError(400, error.code ?? "INVALID_CLOUD_CONFIG", error.message);
          }
        }
        if (request.method === "DELETE") {
          await cloudConfig.clearCloud();
          return sendJson(response, 200, { mode: "local", authenticated: false });
        }
        return methodNotAllowed(response, ["GET", "PUT", "DELETE"]);
      }

      const projectMappingRoute = pathname.match(/^\/api\/local\/project-mappings\/([^/]+)$/);
      if (projectMappingRoute) {
        if (request.method !== "PUT") return methodNotAllowed(response, ["PUT"]);
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "Project mapping routes do not accept query parameters");
        }
        let projectId;
        try {
          projectId = decodeURIComponent(projectMappingRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Project id contains invalid encoding");
        }
        validateProjectId(projectId);
        const body = await readJson(request);
        assertPlainObject(body);
        assertAllowedKeys(body, new Set(["workspacePath"]));
        const workspacePath = pathField(body.workspacePath, "workspacePath");
        if (!workspacePath || !path.isAbsolute(workspacePath)) {
          throw new ApiError(400, "INVALID_FIELD", "'workspacePath' must be absolute");
        }
        await cloudConfig.setProjectWorkspace(projectId, workspacePath);
        return sendJson(response, 200, { projectId, workspacePath });
      }

      if (pathname === "/api/meta") {
        if (request.method !== "GET") return methodNotAllowed(response, ["GET"]);
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "GET /api/meta does not accept query parameters");
        }
        return sendJson(response, 200, {
          manageTaskboardSkillPath: resolved.skillPath,
          capabilities: { localAiChat: isLoopbackAddress(request.socket.remoteAddress) },
          ...(capabilityCloudConfig?.remoteUrl
            ? {
              mode: "cloud",
              realtime: { transport: "poll", intervalMs: 2000 },
              localCapabilities: { available: true },
            }
            : {}),
        });
      }

      if (pathname === "/api/local/ai/catalog") {
        if (request.method !== "GET") return methodNotAllowed(response, ["GET"]);
        assertAllowedQuery(url.searchParams, new Set(["projectId"]), "GET /api/local/ai/catalog");
        const projectId = validateProjectId(url.searchParams.get("projectId") ?? undefined);
        return sendJson(response, 200, await aiChat.getCatalog(projectId));
      }

      if (pathname === "/api/local/ai/threads") {
        assertNoQuery(url.searchParams, "/api/local/ai/threads");
        if (request.method === "GET") {
          return sendJson(response, 200, { threads: await aiChat.listThreads() });
        }
        if (request.method === "POST") {
          const thread = await aiChat.createThread(parseAiThreadCreate(await readJson(request)));
          return sendJson(response, 201, { thread });
        }
        return methodNotAllowed(response, ["GET", "POST"]);
      }

      const aiThreadEventsRoute = pathname.match(/^\/api\/local\/ai\/threads\/([^/]+)\/events$/);
      if (aiThreadEventsRoute) {
        if (request.method !== "GET") return methodNotAllowed(response, ["GET"]);
        assertNoQuery(url.searchParams, "GET /api/local/ai/threads/:id/events");
        const threadId = decodeRouteSegment(aiThreadEventsRoute[1], "Thread id");
        await aiChat.getThreadSnapshot(threadId);
        response.writeHead(200, {
          connection: "keep-alive",
          "cache-control": "no-cache, no-transform",
          "content-type": "text/event-stream; charset=utf-8",
          "x-accel-buffering": "no",
        });
        aiEventResponses.add(response);
        const unsubscribe = aiChat.subscribe(threadId, (event) => {
          const type = event?.type === "ai.run" ? "ai.run" : "ai.event";
          response.write(`event: ${type}\ndata: ${JSON.stringify(event)}\n\n`);
        });
        response.write(": connected\n\n");
        response.write('event: ai.event\ndata: {"type":"ai.event"}\n\n');
        const keepAlive = setInterval(() => response.write(": keep-alive\n\n"), 20_000);
        keepAlive.unref();
        request.once("close", () => {
          clearInterval(keepAlive);
          unsubscribe();
          aiEventResponses.delete(response);
        });
        return;
      }

      const aiThreadTurnRoute = pathname.match(/^\/api\/local\/ai\/threads\/([^/]+)\/turns$/);
      if (aiThreadTurnRoute) {
        if (request.method !== "POST") return methodNotAllowed(response, ["POST"]);
        assertNoQuery(url.searchParams, "POST /api/local/ai/threads/:id/turns");
        const threadId = decodeRouteSegment(aiThreadTurnRoute[1], "Thread id");
        const run = await aiChat.startTurn(
          threadId,
          parseAiTurn(await readJson(
            request,
            AI_CHAT_TURN_BODY_LIMIT,
            "AI chat turn body cannot exceed 25 MiB",
          )),
        );
        return sendJson(response, 202, { run });
      }

      const aiThreadRoute = pathname.match(/^\/api\/local\/ai\/threads\/([^/]+)$/);
      if (aiThreadRoute) {
        assertNoQuery(url.searchParams, "/api/local/ai/threads/:id");
        const threadId = decodeRouteSegment(aiThreadRoute[1], "Thread id");
        if (request.method === "GET") {
          return sendJson(response, 200, await aiChat.getThreadSnapshot(threadId));
        }
        if (request.method === "PATCH") {
          const thread = await aiChat.updateThread(threadId, parseAiThreadPatch(await readJson(request)));
          return sendJson(response, 200, { thread });
        }
        if (request.method === "DELETE") {
          await assertEmptyRequestBody(request, "DELETE /api/local/ai/threads/:id");
          await aiChat.deleteThread(threadId);
          return sendEmpty(response, 204);
        }
        return methodNotAllowed(response, ["GET", "PATCH", "DELETE"]);
      }

      const aiInterruptRoute = pathname.match(/^\/api\/local\/ai\/runs\/([^/]+)\/interrupt$/);
      if (aiInterruptRoute) {
        if (request.method !== "POST") return methodNotAllowed(response, ["POST"]);
        assertNoQuery(url.searchParams, "POST /api/local/ai/runs/:id/interrupt");
        const runId = decodeRouteSegment(aiInterruptRoute[1], "Run id");
        await assertEmptyRequestBody(request, "POST /api/local/ai/runs/:id/interrupt");
        const run = await aiChat.interrupt(runId);
        return sendJson(response, 200, { run });
      }

      if (pathname === "/api/device-workspaces") {
        if (request.method !== "GET") return methodNotAllowed(response, ["GET"]);
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "GET /api/device-workspaces does not accept query parameters");
        }
        return sendJson(response, 200, {
          workspaces: await readCodexProjectWorkspaces(resolved.codexStatePath),
        });
      }

      if (pathname === "/api/workflow-capabilities") {
        if (request.method !== "GET") return methodNotAllowed(response, ["GET"]);
        const unknownQuery = [...url.searchParams.keys()].filter((key) => key !== "workspacePath");
        if (unknownQuery.length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", `Unknown query parameter: ${unknownQuery[0]}`);
        }
        const workspacePath = stringField(
          url.searchParams.get("workspacePath") ?? null,
          "workspacePath",
          { nullable: true, maxLength: 4096 },
        );
        if (workspacePath?.includes("\0")) {
          throw new ApiError(400, "INVALID_FIELD", "'workspacePath' cannot contain null bytes");
        }
        if (workspacePath && !path.isAbsolute(workspacePath)) {
          throw new ApiError(400, "INVALID_FIELD", "'workspacePath' must be absolute");
        }
        return sendJson(
          response,
          200,
          await discoverWorkflowCapabilities(resolved, workspacePath ?? PROJECT_ROOT),
        );
      }

      let currentCloudConfig = null;
      if (pathname.startsWith("/api/")) {
        currentCloudConfig = await cloudConfig.read();
        if (currentCloudConfig.remoteUrl) {
          assertLoopbackRequest(request);
          if (!isLocalCompanionRoute(pathname)) {
            return sendFetchResponse(
              response,
              await cloudProxy.forward(toFetchRequest(request)),
            );
          }
        }
      }

      if (pathname === "/api/projects") {
        if (request.method === "GET") {
          if ([...url.searchParams.keys()].length > 0) {
            throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "GET /api/projects does not accept query parameters");
          }
          return sendJson(response, 200, { projects: database.listProjects() });
        }
        if (request.method === "POST") {
          const project = database.createProject(parseProjectCreate(await readJson(request)));
          events.emit("project.created", { project });
          return sendJson(response, 201, { project });
        }
        return methodNotAllowed(response, ["GET", "POST"]);
      }

      const projectByIdRoute = pathname.match(/^\/api\/projects\/([^/]+)$/);
      if (projectByIdRoute && (request.method === "PUT" || request.method === "DELETE")) {
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", `${request.method} /api/projects/:id does not accept query parameters`);
        }
        let projectId;
        try {
          projectId = decodeURIComponent(projectByIdRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_FIELD", "Invalid project id in URL path");
        }
        if (request.method === "DELETE") {
          // Workspace-sync removal: only workspace-managed projects (guarded
          // inside deleteWorkspaceProject); 'local' and temp-* are refused.
          const removed = database.deleteWorkspaceProject(validateProjectId(projectId));
          events.emit("project.deleted", { project: removed });
          return sendJson(response, 200, { deleted: removed.id });
        }
        const project = database.updateProject(validateProjectId(projectId), parseProjectUpdate(await readJson(request)));
        events.emit("project.updated", { project });
        return sendJson(response, 200, { project });
      }

      const workflowWorkspaceRoute = pathname.match(/^\/api\/projects\/([^/]+)\/workflow-workspace$/);
      if (workflowWorkspaceRoute) {
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "Workflow workspace routes do not accept query parameters");
        }
        let projectId;
        try {
          projectId = decodeURIComponent(workflowWorkspaceRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Project id contains invalid encoding");
        }
        validateProjectId(projectId);
        if (request.method === "GET") {
          return sendJson(response, 200, { workflow: database.getWorkflowWorkspace(projectId) });
        }
        if (request.method === "PUT") {
          const input = parseWorkflowWorkspaceSave(await readJson(request));
          const workflow = database.saveWorkflowWorkspace(projectId, input.version, input.workspace);
          events.emit("workflow.updated", {
            projectId,
            workflowVersion: workflow.version,
          });
          return sendJson(response, 200, { workflow });
        }
        return methodNotAllowed(response, ["GET", "PUT"]);
      }

      const developmentContextsRoute = pathname.match(/^\/api\/projects\/([^/]+)\/development-contexts$/);
      if (developmentContextsRoute) {
        if (request.method !== "GET") return methodNotAllowed(response, ["GET"]);
        const unknownQuery = [...url.searchParams.keys()].filter((key) => (
          !["codexProjectId", "codexThreadId", "workspacePath"].includes(key)
        ));
        if (unknownQuery.length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", `Unknown query parameter: ${unknownQuery[0]}`);
        }
        let projectId;
        try {
          projectId = decodeURIComponent(developmentContextsRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Project id contains invalid encoding");
        }
        validateProjectId(projectId);
        const project = currentCloudConfig.remoteUrl
          ? {
            id: projectId,
            workspacePath: currentCloudConfig.projectMappings[projectId] ?? null,
          }
          : database.getProject(projectId);
        if (!project) throw new ApiError(404, "PROJECT_NOT_FOUND", `Project '${projectId}' does not exist`);
        const codexProjectId = stringField(url.searchParams.get("codexProjectId") ?? null, "codexProjectId", {
          nullable: true,
          maxLength: 128,
        });
        const codexThreadId = stringField(url.searchParams.get("codexThreadId") ?? null, "codexThreadId", {
          nullable: true,
          maxLength: 256,
        });
        const deviceWorkspacePath = stringField(
          url.searchParams.get("workspacePath") ?? null,
          "workspacePath",
          { nullable: true, maxLength: 4096 },
        );
        if (deviceWorkspacePath?.includes("\0")) {
          throw new ApiError(400, "INVALID_FIELD", "'workspacePath' cannot contain null bytes");
        }
        const workspacePath = deviceWorkspacePath ?? await resolveProjectWorkspace(
          project,
          codexProjectId,
          codexThreadId,
          resolved.codexStatePath,
          resolved.codexProcessesPath,
        );
        return sendJson(response, 200, await scanDevelopmentContexts(workspacePath));
      }

      const projectAutomationRoute = pathname.match(/^\/api\/projects\/([^/]+)\/automation$/);
      if (projectAutomationRoute) {
        if (request.method !== "POST" && request.method !== "GET") {
          return methodNotAllowed(response, ["GET", "POST"]);
        }
        let projectId;
        try {
          projectId = decodeURIComponent(projectAutomationRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Project id contains invalid encoding");
        }
        validateProjectId(projectId);
        const project = database.getProject(projectId);
        if (!project) {
          throw new ApiError(404, "NOT_FOUND", `Project '${projectId}' not found`);
        }
        if (request.method === "GET") {
          if ([...url.searchParams.keys()].length > 0) {
            throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "GET /api/projects/:id/automation does not accept query parameters");
          }
          return sendJson(response, 200, {
            automation: database.getProjectAutomation(projectId),
          });
        }
        const body = await readJson(request);
        assertPlainObject(body);
        assertAllowedKeys(body, new Set(["enabled", "intervalMinutes", "automationModel", "sessionMode", "sessionId", "sessionTurns"]));
        if (typeof body.enabled !== "boolean") {
          throw new ApiError(400, "INVALID_FIELD", "'enabled' must be a boolean");
        }
        const enabled = body.enabled;
        if (!Number.isInteger(body.intervalMinutes ?? 10)
          || (body.intervalMinutes ?? 10) < 5
          || (body.intervalMinutes ?? 10) > 60) {
          throw new ApiError(400, "INVALID_FIELD", "'intervalMinutes' must be an integer between 5 and 60");
        }
        const intervalMinutes = body.intervalMinutes ?? 10;
        if (enabled && !project.workspacePath) {
          throw new ApiError(400, "INVALID_FIELD", "workspacePath is required to enable automation (project must map to a DSH workspace)");
        }
        const automationModel = body.automationModel === undefined
          ? undefined
          : stringField(body.automationModel, "automationModel", { nullable: true, maxLength: 128 });
        // Claim conversation binding: 'fixed' points every round at one of this
        // project's own claim conversations — never an arbitrary session, and
        // never one belonging to another project.
        let sessionMode;
        if (body.sessionMode !== undefined) {
          sessionMode = stringField(body.sessionMode, "sessionMode", { required: true, maxLength: 16 });
          if (sessionMode !== "new" && sessionMode !== "fixed" && sessionMode !== "task") {
            throw new ApiError(400, "INVALID_FIELD", "'sessionMode' must be 'new', 'fixed' or 'task'");
          }
        }
        const sessionId = body.sessionId === undefined
          ? undefined
          : stringField(body.sessionId, "sessionId", { nullable: true, maxLength: 128 });
        if (sessionId) {
          const prefix = `${CLAIM_SESSION_PREFIX}${projectId.slice(0, 8)}-`;
          if (!sessionId.startsWith(prefix)) {
            throw new ApiError(400, "INVALID_FIELD", `'sessionId' must be one of this project's claim conversations (${prefix}…)`);
          }
        }
        const currentAutomation = database.getProjectAutomation(projectId);
        if ((sessionMode ?? currentAutomation.sessionMode) === "fixed"
          && !(sessionId ?? currentAutomation.sessionId)) {
          throw new ApiError(400, "INVALID_FIELD", "'sessionId' is required when 'sessionMode' is 'fixed'");
        }
        let sessionTurns;
        if (body.sessionTurns !== undefined) {
          if (!Number.isInteger(body.sessionTurns) || body.sessionTurns < 0) {
            throw new ApiError(400, "INVALID_FIELD", "'sessionTurns' must be a non-negative integer");
          }
          sessionTurns = body.sessionTurns;
        }
        const automation = database.setProjectAutomation(projectId, {
          enabled,
          intervalMinutes,
          model: automationModel,
          sessionMode,
          sessionId,
          sessionTurns,
        });
        events.emit("project.automation", { projectId, automation });
        return sendJson(response, 200, { automation });
      }

      // Candidate conversations for the fixed-session setting: this project's
      // own claim rounds, one row per conversation (newest first).
      const claimSessionsRoute = pathname.match(/^\/api\/projects\/([^/]+)\/claim-sessions$/);
      if (claimSessionsRoute && request.method === "GET") {
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "GET /api/projects/:id/claim-sessions does not accept query parameters");
        }
        const projectId = decodeURIComponent(claimSessionsRoute[1]);
        validateProjectId(projectId);
        const project = database.getProject(projectId);
        if (!project) {
          throw new ApiError(404, "NOT_FOUND", `Project '${projectId}' not found`);
        }
        const routineName = `${CLAIM_ROUTINE_PREFIX}${projectId.slice(0, 12)}`;
        const runs = await listRoutineRuns(resolved.routinesDirectory, project.workspacePath ?? null, routineName, 100);
        const bySession = new Map();
        for (const run of runs) {
          if (typeof run.sessionId !== "string" || run.sessionId === "") continue;
          const known = bySession.get(run.sessionId);
          if (known) {
            known.rounds += 1;
            continue;
          }
          bySession.set(run.sessionId, {
            sessionId: run.sessionId,
            startedAt: run.startedAt ?? null,
            status: run.status ?? null,
            rounds: 1,
            digest: typeof run.digest === "string" ? run.digest.slice(0, 160) : null,
          });
        }
        return sendJson(response, 200, { sessions: [...bySession.values()].slice(0, 20) });
      }

      // Claim model catalog: written by the host half from ctx.llm.listModels()
      // into models.json in the data directory (fallback: empty catalog).
      if (pathname === "/api/automation/models") {
        if (request.method !== "GET") return methodNotAllowed(response, ["GET"]);
        let catalog = { providers: [], updatedAt: null };
        try {
          const raw = await readFile(path.join(resolved.dataDirectory, "models.json"), "utf8");
          const parsed = JSON.parse(raw);
          if (parsed && typeof parsed === "object" && Array.isArray(parsed.providers)) catalog = parsed;
        } catch {
          // models.json missing or unparsable: serve the empty catalog.
        }
        return sendJson(response, 200, catalog);
      }

      // dsh-routines store listing: routine YAMLs plus the latest run record
      // per routine (the routines view in the board reads this).
      if (pathname === "/api/routines") {
        if (request.method === "GET") {
          if ([...url.searchParams.keys()].length > 0) {
            throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "GET /api/routines does not accept query parameters");
          }
          return sendJson(response, 200, await listRoutines(
            resolved.routinesDirectory,
            (name) => claimAutomationEnabled(database, name),
            resolved.routinesProjectDir,
          ));
        }
        if (request.method === "POST") {
          if (!resolved.routinesDirectory) {
            throw new ApiError(400, "ROUTINES_UNAVAILABLE", "No routines directory configured");
          }
          const body = await readJson(request);
          assertPlainObject(body);
          assertAllowedKeys(body, new Set([
            "name", "schedule", "timezone", "prompt", "cwd", "profile",
            "overlap", "timeoutMin", "deliver",
          ]));
          const name = parseRoutineName(body.name);
          if (name.startsWith(CLAIM_ROUTINE_PREFIX)) {
            throw new ApiError(409, "RESERVED_NAME", "Routine names starting with 'taskboard-claim-' are reserved for claim automations");
          }
          const routine = {
            name,
            schedule: stringField(body.schedule, "schedule", { required: true, maxLength: 128 }),
            timezone: stringField(body.timezone ?? "", "timezone", { nullable: true, maxLength: 64 }) ?? "",
            prompt: stringField(body.prompt, "prompt", { required: true, maxLength: 100_000 }),
            cwd: stringField(body.cwd ?? "", "cwd", { nullable: true, maxLength: 4096 }) ?? "",
            profile: stringField(body.profile ?? "", "profile", { nullable: true, maxLength: 64 }) ?? "",
            overlap: stringField(body.overlap ?? "", "overlap", { nullable: true, maxLength: 32 }) ?? "",
            timeoutMin: body.timeoutMin === undefined ? "" : String(body.timeoutMin),
            deliver: body.deliver === undefined ? ["file"] : parseDeliverList(body.deliver),
          };
          const file = path.join(resolved.routinesDirectory, `${name}.yaml`);
          try {
            await stat(file);
            throw new ApiError(409, "ROUTINE_EXISTS", `Routine '${name}' already exists`);
          } catch (error) {
            if (error instanceof ApiError) throw error;
          }
          await mkdir(resolved.routinesDirectory, { recursive: true });
          await writeFile(file, serializeRoutine(routine), "utf8");
          return sendJson(response, 201, { routine: { name, file } });
        }
        return methodNotAllowed(response, ["GET", "POST"]);
      }

      const routineRunRoute = pathname.match(/^\/api\/routines\/([^/]+)\/run$/);
      if (routineRunRoute && request.method === "POST") {
        const name = parseRoutineName(decodeURIComponent(routineRunRoute[1]));
        if (name.startsWith(CLAIM_ROUTINE_PREFIX)) {
          // Claim routines execute only in-process in the GUI host. A handler
          // verdict of false means the round was skipped/blocked by a gate or
          // its project is gone — never fall through to the external ops
          // runner, which would launch an un-gated headless claim that
          // executes work the gates just refused to authorize.
          if (!options.routinesRunHandler) {
            throw new ApiError(409, "CLAIM_ROUTINE_NO_RUNNER",
              "Claim routines run in-process in the DSH host; this server has no in-process runner");
          }
          // The in-process runner reports where the request actually went:
          // "queued" means a live round took it and this one runs after — that
          // is not the same as "started", and the panel must not claim success.
          const handled = await options.routinesRunHandler(name);
          // Three explicit verdicts: "queued" (a live round took it),
          // "started"/true (it is running now), "skipped"/false (a gate
          // refused). A truthy string like "skipped" must not read as success.
          const claimMode = handled === "queued"
            ? "queued"
            : handled === "started" || handled === true
              ? "in-process"
              : "gated";
          return sendJson(response, 202, {
            started: claimMode === "gated" ? null : name,
            mode: claimMode,
          });
        }
        if (options.routinesRunHandler) {
          // In-process handler (plain routines can still opt into the host).
          const handled = await options.routinesRunHandler(name);
          if (handled) return sendJson(response, 202, { started: name, mode: "in-process" });
        }
        spawnRoutineRun(name);
        return sendJson(response, 202, { started: name, mode: "external" });
      }

      // Run history for one routine (automation panel's run-records tab):
      // merge global + per-cwd runs dirs, newest first.
      const routineRunsRoute = pathname.match(/^\/api\/routines\/([^/]+)\/runs$/);
      if (routineRunsRoute && request.method === "GET") {
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "GET /api/routines/:name/runs does not accept query parameters");
        }
        const name = parseRoutineName(decodeURIComponent(routineRunsRoute[1]));
        let cwd = null;
        if (resolved.routinesDirectory) {
          try {
            const parsed = parseRoutineYaml(
              await readFile(path.join(resolved.routinesDirectory, `${name}.yaml`), "utf8"),
            );
            if (typeof parsed.cwd === "string" && parsed.cwd !== "") cwd = parsed.cwd;
          } catch {
            // Unknown yaml (e.g. claim routines): fall back to the project map.
          }
        }
        if (!cwd) {
          const claimProject = claimProjectByName(database, name);
          if (claimProject?.workspacePath) cwd = claimProject.workspacePath;
        }
        const runs = await listRoutineRuns(resolved.routinesDirectory, cwd, name);
        return sendJson(response, 200, { runs });
      }

      const routineStopRoute = pathname.match(/^\/api\/routines\/([^/]+)\/stop$/);
      if (routineStopRoute && request.method === "POST") {
        const name = parseRoutineName(decodeURIComponent(routineStopRoute[1]));
        if (options.routinesStopHandler) {
          const stopped = await options.routinesStopHandler(name);
          return sendJson(response, 200, { stopped: stopped || null });
        }
        return sendJson(response, 404, { error: "No stop handler" });
      }

      const routineByNameRoute = pathname.match(/^\/api\/routines\/([^/]+)$/);
      if (routineByNameRoute && resolved.routinesDirectory) {
        const name = parseRoutineName(decodeURIComponent(routineByNameRoute[1]));
        const file = path.join(resolved.routinesDirectory, `${name}.yaml`);
        const claimProject = claimProjectByName(database, name);
        if (request.method === "PUT") {
          const body = await readJson(request);
          assertPlainObject(body);
          if (claimProject) {
            // Virtual routine: its on/off switch IS the claim automation
            // switch. A direct YAML write would be reverted by the next
            // reconcile (and paused:false would let the external ops runner
            // double-execute the claim), so translate the toggle into the
            // project automation record.
            if (typeof body.raw === "string") {
              throw new ApiError(409, "CLAIM_ROUTINE_READONLY",
                "Claim routines are controlled by the project's claim switch; use the automation menu instead");
            }
            assertAllowedKeys(body, new Set(["paused"]));
            const current = database.getProjectAutomation(claimProject.id);
            const enabled = body.paused === undefined ? !current.enabled : !Boolean(body.paused);
            const automation = database.setProjectAutomation(claimProject.id, { enabled });
            events.emit("project.automation", { projectId: claimProject.id, automation });
            return sendJson(response, 200, { updated: name });
          }
          if (typeof body.raw === "string") {
            // Full-text edit: preserve whatever the user wrote.
            await writeFile(file, body.raw, "utf8");
            return sendJson(response, 200, { updated: name });
          }
          assertAllowedKeys(body, new Set([
            "schedule", "timezone", "prompt", "cwd", "profile",
            "overlap", "timeoutMin", "deliver", "paused",
          ]));
          const current = parseRoutineYaml(await readFile(file, "utf8").catch(() => ""));
          const routine = {
            name,
            schedule: stringField(body.schedule ?? current.schedule, "schedule", { required: true, maxLength: 128 }),
            timezone: stringField(body.timezone ?? current.timezone ?? "", "timezone", { nullable: true, maxLength: 64 }) ?? "",
            prompt: stringField(body.prompt ?? current.prompt, "prompt", { required: true, maxLength: 100_000 }),
            cwd: stringField(body.cwd ?? current.cwd ?? "", "cwd", { nullable: true, maxLength: 4096 }) ?? "",
            profile: stringField(body.profile ?? current.profile ?? "", "profile", { nullable: true, maxLength: 64 }) ?? "",
            overlap: stringField(body.overlap ?? current.overlap ?? "", "overlap", { nullable: true, maxLength: 32 }) ?? "",
            timeoutMin: body.timeoutMin === undefined
              ? String(current.timeoutMin ?? "")
              : String(body.timeoutMin),
            deliver: body.deliver === undefined
              ? (Array.isArray(current.deliver) ? current.deliver : ["file"])
              : parseDeliverList(body.deliver),
            paused: body.paused === undefined ? Boolean(current.paused) : Boolean(body.paused),
          };
          await writeFile(file, serializeRoutine(routine), "utf8");
          // dsh-routines only honours paused state in its state.json (the YAML
          // key is not part of its schema), so mirror the toggle there and
          // restart the scheduler daemon so it re-reads the file.
          if (body.paused !== undefined) {
            await applyRoutinesPaused(
              name,
              Boolean(body.paused),
              resolved.routinesProjectDir,
              resolved.routinesDaemonLabel,
            );
          }
          return sendJson(response, 200, { updated: name });
        }
        if (request.method === "DELETE") {
          if (claimProject) {
            throw new ApiError(409, "CLAIM_ROUTINE_READONLY",
              "Claim routines are managed by the board's claim switch; turn the switch off instead");
          }
          try {
            await unlink(file);
          } catch (error) {
            if (error.code === "ENOENT") {
              throw new ApiError(404, "ROUTINE_NOT_FOUND", `Routine '${name}' does not exist`);
            }
            throw error;
          }
          return sendJson(response, 200, { deleted: name });
        }
        return methodNotAllowed(response, ["PUT", "DELETE"]);
      }

      // 测试执行：manual trigger through the ops-profile routines CLI,
      const claimRunRoute = pathname.match(/^\/api\/projects\/([^/]+)\/claim-run$/);
      if (claimRunRoute && request.method === "POST") {
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "POST /api/projects/:id/claim-run does not accept query parameters");
        }
        let projectId;
        try {
          projectId = decodeURIComponent(claimRunRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Project id contains invalid encoding");
        }
        validateProjectId(projectId);
        if (!database.getProject(projectId)) {
          throw new ApiError(404, "NOT_FOUND", `Project '${projectId}' not found`);
        }
        // Host claim sweeper stamps its run here (fire-and-forget kick).
        database.updateProjectLastClaimAt(projectId);
        return sendJson(response, 200, { stamped: projectId });
      }

      if (pathname === "/api/tasks") {
        if (request.method === "GET") {
          return sendJson(response, 200, { tasks: database.listTasks(parseTaskFilters(url.searchParams)) });
        }
        if (request.method === "POST") {
          const actor = actorFromRequest(request);
          const { assigneeTarget, ...input } = parseTaskCreate(await readJson(request));
          const task = database.createTask({
            ...input,
            actor,
            assignee: resolveAssignee(assigneeTarget, actor),
          });
          events.emit("task.created", { task });
          return sendJson(response, 201, { task });
        }
        return methodNotAllowed(response, ["GET", "POST"]);
      }

      if (pathname === "/api/events") {
        if (request.method !== "GET") return methodNotAllowed(response, ["GET"]);
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "GET /api/events does not accept query parameters");
        }
        events.connect(request, response);
        return;
      }

      const taskRelationRoute = pathname.match(
        /^\/api\/tasks\/([^/]+)\/relations\/([^/]+)\/([^/]+)$/,
      );
      if (taskRelationRoute) {
        let taskId;
        let type;
        let relatedTaskId;
        try {
          taskId = decodeURIComponent(taskRelationRoute[1]);
          type = decodeURIComponent(taskRelationRoute[2]);
          relatedTaskId = decodeURIComponent(taskRelationRoute[3]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Issue relation path contains invalid encoding");
        }
        if (
          taskId.length === 0
          || taskId.length > 128
          || relatedTaskId.length === 0
          || relatedTaskId.length > 128
        ) {
          throw new ApiError(400, "INVALID_PATH", "Issue relation task id is invalid");
        }
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "Issue relation routes do not accept query parameters");
        }
        const relationType = parseIssueRelationType(type);
        if (request.method === "POST") {
          const { version, threadId } = parseArchive(await readJson(request));
          const result = database.addTaskRelation(
            taskId,
            version,
            relationType,
            relatedTaskId,
            threadId,
            actorFromRequest(request),
          );
          events.emit("task.relation.updated", result);
          return sendJson(response, 200, result);
        }
        if (request.method === "DELETE") {
          const { version, threadId } = parseArchive(await readJson(request));
          const result = database.removeTaskRelation(
            taskId,
            version,
            relationType,
            relatedTaskId,
            threadId,
            actorFromRequest(request),
          );
          events.emit("task.relation.updated", result);
          return sendJson(response, 200, result);
        }
        return methodNotAllowed(response, ["POST", "DELETE"]);
      }

      const taskActivitiesRoute = pathname.match(/^\/api\/tasks\/([^/]+)\/activities$/);
      if (taskActivitiesRoute) {
        let taskId;
        try {
          taskId = decodeURIComponent(taskActivitiesRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Task id contains invalid encoding");
        }
        if (taskId.length === 0 || taskId.length > 128) {
          throw new ApiError(400, "INVALID_PATH", "Task id is invalid");
        }
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "Activity routes do not accept query parameters");
        }
        if (request.method === "GET") {
          return sendJson(response, 200, { activities: database.listTaskActivities(taskId) });
        }
        return methodNotAllowed(response, ["GET"]);
      }

      const taskCommentsRoute = pathname.match(/^\/api\/tasks\/([^/]+)\/comments$/);
      if (taskCommentsRoute) {
        let taskId;
        try {
          taskId = decodeURIComponent(taskCommentsRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Task id contains invalid encoding");
        }
        if (taskId.length === 0 || taskId.length > 128) {
          throw new ApiError(400, "INVALID_PATH", "Task id is invalid");
        }
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "Comment routes do not accept query parameters");
        }
        if (request.method === "GET") {
          return sendJson(response, 200, { comments: database.listComments(taskId) });
        }
        if (request.method === "POST") {
          const comment = database.createComment(taskId, {
            ...parseCommentCreate(await readJson(request)),
            actor: actorFromRequest(request),
          });
          const task = database.getTask(taskId);
          events.emit("comment.created", { comment, task });
          // 评论即执行: a human comment on a board that is waiting for the human
          // is an instruction, not a note — ask the host (same process) to run
          // one round for this task now. Agent comments never trigger this
          // (loop guard), and neither do queued/never-started issues.
          if (comment.authorType === "user" && DISPATCH_GATE_STATUSES.has(task.status)) {
            events.emit("task.dispatch-requested", { task, comment });
          }
          return sendJson(response, 201, { comment });
        }
        return methodNotAllowed(response, ["GET", "POST"]);
      }

      const commentRoute = pathname.match(/^\/api\/comments\/([^/]+)$/);
      if (commentRoute) {
        let id;
        try {
          id = decodeURIComponent(commentRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Comment id contains invalid encoding");
        }
        if (id.length === 0 || id.length > 128) {
          throw new ApiError(400, "INVALID_PATH", "Comment id is invalid");
        }
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "Comment routes do not accept query parameters");
        }
        if (request.method === "PATCH") {
          const patch = parseCommentPatch(await readJson(request));
          const comment = database.updateComment(id, patch.version, patch.body, patch.threadId);
          const task = database.getTask(comment.taskId);
          events.emit("comment.updated", { comment, task });
          return sendJson(response, 200, { comment });
        }
        if (request.method === "DELETE") {
          const { version } = parseArchive(await readJson(request));
          const comment = database.deleteComment(id, version);
          for (const attachment of comment.attachments) {
            try {
              await unlink(path.join(resolved.attachmentsDirectory, attachment.id));
            } catch (error) {
              if (error.code !== "ENOENT") throw error;
            }
          }
          const task = database.getTask(comment.taskId);
          events.emit("comment.deleted", { comment, task });
          return sendEmpty(response, 204);
        }
        return methodNotAllowed(response, ["PATCH", "DELETE"]);
      }

      const commentAttachmentsRoute = pathname.match(/^\/api\/comments\/([^/]+)\/attachments$/);
      if (commentAttachmentsRoute) {
        let commentId;
        try {
          commentId = decodeURIComponent(commentAttachmentsRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Comment id contains invalid encoding");
        }
        if (commentId.length === 0 || commentId.length > 128) {
          throw new ApiError(400, "INVALID_PATH", "Comment id is invalid");
        }
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "Attachment routes do not accept query parameters");
        }
        if (request.method === "GET") {
          return sendJson(response, 200, { attachments: database.listCommentAttachments(commentId) });
        }
        if (request.method === "POST") {
          const comment = database.getComment(commentId);
          if (!comment) throw new ApiError(404, "COMMENT_NOT_FOUND", `Comment '${commentId}' does not exist`);
          const metadata = parseAttachmentHeaders(request);
          const body = await readBody(request, ATTACHMENT_BODY_LIMIT, "Attachment cannot exceed 25 MiB");
          const id = randomUUID();
          await mkdir(resolved.attachmentsDirectory, { recursive: true });
          const storagePath = path.join(resolved.attachmentsDirectory, id);
          await writeFile(storagePath, body, { flag: "wx" });
          let attachment;
          try {
            attachment = database.createCommentAttachment(commentId, { id, ...metadata, size: body.length });
          } catch (error) {
            await unlink(storagePath);
            throw error;
          }
          const task = database.getTask(comment.taskId);
          events.emit("attachment.created", { attachment, comment: database.getComment(commentId), task });
          return sendJson(response, 201, { attachment });
        }
        return methodNotAllowed(response, ["GET", "POST"]);
      }

      const taskAttachmentsRoute = pathname.match(/^\/api\/tasks\/([^/]+)\/attachments$/);
      if (taskAttachmentsRoute) {
        let taskId;
        try {
          taskId = decodeURIComponent(taskAttachmentsRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Task id contains invalid encoding");
        }
        if (taskId.length === 0 || taskId.length > 128) {
          throw new ApiError(400, "INVALID_PATH", "Task id is invalid");
        }
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "Attachment routes do not accept query parameters");
        }
        if (request.method === "GET") {
          return sendJson(response, 200, { attachments: database.listAttachments(taskId) });
        }
        if (request.method === "POST") {
          const task = database.getTask(taskId);
          if (!task) throw new ApiError(404, "TASK_NOT_FOUND", `Task '${taskId}' does not exist`);
          const metadata = parseAttachmentHeaders(request);
          const body = await readBody(request, ATTACHMENT_BODY_LIMIT, "Attachment cannot exceed 25 MiB");
          const id = randomUUID();
          await mkdir(resolved.attachmentsDirectory, { recursive: true });
          const storagePath = path.join(resolved.attachmentsDirectory, id);
          await writeFile(storagePath, body, { flag: "wx" });
          let attachment;
          try {
            attachment = database.createAttachment(taskId, { id, ...metadata, size: body.length });
          } catch (error) {
            await unlink(storagePath);
            throw error;
          }
          events.emit("attachment.created", { attachment, task });
          return sendJson(response, 201, { attachment });
        }
        return methodNotAllowed(response, ["GET", "POST"]);
      }

      const attachmentContentRoute = pathname.match(/^\/api\/attachments\/([^/]+)\/content$/);
      if (attachmentContentRoute) {
        let id;
        try {
          id = decodeURIComponent(attachmentContentRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Attachment id contains invalid encoding");
        }
        if (id.length === 0 || id.length > 128) {
          throw new ApiError(400, "INVALID_PATH", "Attachment id is invalid");
        }
        // Read-only content route: tolerate and ignore query parameters.
        // The web client retries transient image failures by re-requesting
        // this URL, and cache-busting params from any bundle generation
        // must degrade to a normal 200, never a 400 (the response is
        // `no-store`, so params change nothing about freshness).
        if (request.method !== "GET" && request.method !== "HEAD") {
          return methodNotAllowed(response, ["GET", "HEAD"]);
        }
        const attachment = database.getAttachment(id);
        if (!attachment) throw new ApiError(404, "ATTACHMENT_NOT_FOUND", `Attachment '${id}' does not exist`);
        const body = await readFile(path.join(resolved.attachmentsDirectory, attachment.id));
        // Temporary access log for issue 09582F74F86A-105: proves whether a
        // client-side attachment request actually reaches this server.
        appendFile(
          path.join(os.homedir(), ".dsh", "storages", "dsh-taskboard", "attachment-access.log"),
          `${new Date().toISOString()} ${request.method} id=${id} status=200 ua=${String(request.headers["user-agent"] ?? "-").slice(0, 120)}\n`,
          () => {},
        );
        const encodedFilename = encodeURIComponent(attachment.filename).replace(/['()*]/g, (character) => (
          `%${character.charCodeAt(0).toString(16).toUpperCase()}`
        ));
        const canOpenInline = INLINE_ATTACHMENT_TYPES.has(attachment.contentType);
        response.writeHead(200, {
          "cache-control": "private, no-store",
          "content-disposition": `${canOpenInline ? "inline" : "attachment"}; filename*=UTF-8''${encodedFilename}`,
          "content-length": body.length,
          "content-security-policy": "sandbox; default-src 'none'",
          "content-type": canOpenInline ? attachment.contentType : "application/octet-stream",
        });
        response.end(request.method === "HEAD" ? undefined : body);
        return;
      }

      const attachmentRoute = pathname.match(/^\/api\/attachments\/([^/]+)$/);
      if (attachmentRoute) {
        let id;
        try {
          id = decodeURIComponent(attachmentRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Attachment id contains invalid encoding");
        }
        if (id.length === 0 || id.length > 128) {
          throw new ApiError(400, "INVALID_PATH", "Attachment id is invalid");
        }
        if ([...url.searchParams.keys()].length > 0) {
          throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "Attachment routes do not accept query parameters");
        }
        if (request.method !== "DELETE") return methodNotAllowed(response, ["DELETE"]);
        const attachment = database.getAttachment(id);
        if (!attachment) throw new ApiError(404, "ATTACHMENT_NOT_FOUND", `Attachment '${id}' does not exist`);
        try {
          await unlink(path.join(resolved.attachmentsDirectory, attachment.id));
        } catch (error) {
          if (error.code !== "ENOENT") throw error;
        }
        database.deleteAttachment(id);
        const task = database.getTask(attachment.taskId);
        events.emit("attachment.deleted", { attachment, task });
        return sendEmpty(response, 204);
      }

      const taskRoute = pathname.match(/^\/api\/tasks\/([^/]+)(?:\/(archive|restore|move|dispatch|cancel))?$/);
      if (taskRoute) {
        let id;
        try {
          id = decodeURIComponent(taskRoute[1]);
        } catch {
          throw new ApiError(400, "INVALID_PATH", "Task id contains invalid encoding");
        }
        if (id.length === 0 || id.length > 128) {
          throw new ApiError(400, "INVALID_PATH", "Task id is invalid");
        }
        const action = taskRoute[2];
        if (!action && request.method === "GET") {
          if ([...url.searchParams.keys()].length > 0) {
            throw new ApiError(400, "UNKNOWN_QUERY_PARAMETER", "GET /api/tasks/:id does not accept query parameters");
          }
          const task = database.getTask(id);
          if (!task) throw new ApiError(404, "TASK_NOT_FOUND", `Task '${id}' does not exist`);
          return sendJson(response, 200, { task });
        }
        if (!action && request.method === "PATCH") {
          const { version, changes, threadId, assigneeTarget } = parseTaskPatch(await readJson(request));
          if (assigneeTarget !== undefined) {
            changes.assignee = resolveAssignee(assigneeTarget, actorFromRequest(request));
          }
          const task = database.updateTask(id, version, changes, threadId, actorFromRequest(request));
          events.emit("task.updated", { task });
          return sendJson(response, 200, { task });
        }
        if (action === "move" && request.method === "POST") {
          const move = parseMove(await readJson(request));
          // 人类在任务详情点「确认完成」（→ done）且工作区确有未提交改动
          // 时，不瞬间落 done（todos.dev 式的可见承接）：先落「处理中」，
          // 服务端把项目工作区修改提交到 Git，提交做完才移入 done。无工作
          // 区或无改动走常规路径直接落 done。提交失败只记日志，完成不受阻。
          const existing = move.status === "done" ? database.getTask(id) : null;
          const project = existing && !existing.archivedAt ? database.getProject(existing.projectId) : null;
          if (existing && (await hasWorkspaceChanges(project))) {
            const processing = database.moveTask(id, move.version, "in_progress", undefined, move.threadId, actorFromRequest(request));
            events.emit("task.moved", { task: processing });
            await autoCommitOnDone(project, processing);
            const final = database.moveTask(id, processing.version, "done", move.sortOrder, move.threadId, actorFromRequest(request));
            events.emit("task.moved", { task: final });
            return sendJson(response, 200, { task: final });
          }
          const task = database.moveTask(id, move.version, move.status, move.sortOrder, move.threadId, actorFromRequest(request));
          events.emit("task.moved", { task });
          return sendJson(response, 200, { task });
        }
        if (action === "archive" && request.method === "POST") {
          const { version, threadId } = parseArchive(await readJson(request));
          const task = database.archiveTask(id, version, threadId, actorFromRequest(request));
          events.emit("task.archived", { task });
          return sendJson(response, 200, { task });
        }
        if (action === "restore" && request.method === "POST") {
          const { version, threadId } = parseArchive(await readJson(request));
          const task = database.restoreTask(id, version, threadId, actorFromRequest(request));
          events.emit("task.restored", { task });
          return sendJson(response, 200, { task });
        }
        // 干一轮：零输入、全状态的显式派发（评论派发的等待人工门控不适用于它）。
        // 执行发生在插件进程的事件订阅里（与看板服务同进程，毫秒级接管）；
        // 轮次租约是互斥与「Agent 进行中」显示的唯一依据（见 ADR-0001）。
        if (action === "dispatch" && request.method === "POST") {
          const task = database.getTask(id);
          if (!task) throw new ApiError(404, "TASK_NOT_FOUND", `Task '${id}' does not exist`);
          if (task.archivedAt) {
            throw new ApiError(409, "TASK_ARCHIVED", `Task '${task.identifier}' is archived — restore it before dispatching`);
          }
          if (database.hasActiveDispatch(id)) {
            throw new ApiError(409, "DISPATCH_BUSY", `Task '${task.identifier}' already has a live round`);
          }
          events.emit("task.dispatch-requested", { task, comment: null });
          return sendJson(response, 202, { task, dispatch: { started: true } });
        }
        if (action === "dispatch" && request.method === "GET") {
          const task = database.getTask(id);
          if (!task) throw new ApiError(404, "TASK_NOT_FOUND", `Task '${id}' does not exist`);
          return sendJson(response, 200, { dispatch: { busy: database.hasActiveDispatch(id) } });
        }
        // 取消一轮：人不必等 60 分钟租约过期才能纠正跑错方向的一轮。
        // 停止动作由宿主的事件订阅执行（轮次在插件进程里跑）；这里只判定
        // 「有没有活轮次」，没有就回 409，让人知道这一下点空了。
        if (action === "cancel" && request.method === "POST") {
          const task = database.getTask(id);
          if (!task) throw new ApiError(404, "TASK_NOT_FOUND", `Task '${id}' does not exist`);
          const lease = database.getDispatchLease(id);
          if (!lease || !database.hasActiveDispatch(id)) {
            throw new ApiError(409, "NOT_RUNNING", `Task '${task.identifier}' has no live round to cancel`);
          }
          events.emit("task.round-cancel-requested", { task, sessionId: lease.sessionId });
          return sendJson(response, 202, { task, canceled: { sessionId: lease.sessionId } });
        }
        return methodNotAllowed(response, action ? ["POST"] : ["GET", "PATCH"]);
      }

      if (pathname.startsWith("/api/")) {
        throw new ApiError(404, "NOT_FOUND", "API route not found");
      }
      if (await serveStatic(request, response, pathname, resolved.staticDirectory)) return;
      throw new ApiError(404, "NOT_FOUND", "Resource not found");
    } catch (error) {
      if (response.headersSent) {
        response.destroy(error);
        return;
      }
      if (error instanceof ApiError) {
        const payload = { error: { code: error.code, message: error.message } };
        if (error.details !== undefined) payload.error.details = error.details;
        sendJson(response, error.status, payload);
        return;
      }
      if (error instanceof CloudProxyError) {
        const payload = { error: { code: error.code, message: error.message } };
        if (error.details !== undefined) payload.error.details = error.details;
        sendJson(response, error.status, payload);
        return;
      }
      console.error(error);
      sendJson(response, 500, { error: { code: "INTERNAL_ERROR", message: "Internal server error" } });
    }
  });

  let listening = false;
  return {
    database,
    aiChat,
    events,
    server,
    options: resolved,
    async listen({ host = "127.0.0.1", port = resolvePort() } = {}) {
      if (host !== "127.0.0.1" && host !== "0.0.0.0") {
        throw new Error("Taskboard server must bind to 127.0.0.1 or 0.0.0.0");
      }
      await new Promise((resolve, reject) => {
        const onError = (error) => {
          server.off("listening", onListening);
          reject(error);
        };
        const onListening = () => {
          server.off("error", onError);
          resolve();
        };
        server.once("error", onError);
        server.once("listening", onListening);
        server.listen(port, host);
      });
      listening = true;
      return server.address();
    },
    async close() {
      const serverClosed = listening
        ? new Promise((resolve, reject) => {
            server.close((error) => error ? reject(error) : resolve());
          })
        : Promise.resolve();
      events.close();
      for (const response of aiEventResponses) response.end();
      aiEventResponses.clear();
      await aiChat.close();
      await serverClosed;
      listening = false;
      database.close();
    },
  };
}
