/**
 * Form controller for the Headroom settings card: stages field drafts and
 * writes them through the plugin's own config form only on save. Mirrors the harness's
 * CardForm pattern (draft staging, presence-marked overrides, host read-back)
 * without importing the internal ui-settings-plugins form machinery.
 */

import type { ConfigForm } from '@deepseek-ai/dsh-client-ui-settings/client'
import { createSnapshotStore, type SnapshotStore } from '@deepseek-ai/dsh-client-store'

/**
 * Profile row id owning this plugin's config form. Spelled here rather than
 * imported: a client package must not depend on a Host package.
 */
export const HEADROOM_ENTRY_ID = 'dsh-headroom'

/** The live field behind each control, as a path inside the plugin's Config. */
const FIELD_PATHS: Record<HeadroomTextField | 'autoInstall' | 'resultCompressionEnabled', readonly string[]> = {
  command: ['headroom', 'command'],
  pythonPath: ['headroom', 'pythonPath'],
  uvCommand: ['headroom', 'uvCommand'],
  port: ['headroom', 'port'],
  baseUrl: ['headroom', 'baseUrl'],
  autoInstall: ['headroom', 'autoInstall'],
  resultCompressionEnabled: ['resultCompression', 'enabled'],
  thresholdChars: ['resultCompression', 'thresholdChars'],
}

/** JSON-shaped value a field write carries. */
type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue }

/** The flat settings view the card edits, backed by the entry's config form. */
export interface HeadroomFormScope {
  getSnapshot(): {
    status: 'loading' | 'ready' | 'unavailable'
    value: HeadroomSettings | undefined
    writable: boolean
  }
  subscribe(listener: () => void): () => void
  set(field: HeadroomTextField | 'autoInstall' | 'resultCompressionEnabled', value: unknown): Promise<boolean>
  unset(field: HeadroomTextField | 'autoInstall' | 'resultCompressionEnabled'): Promise<boolean>
}

/** Project the entry's Config onto the flat settings the card renders. */
function projectSettings(value: unknown): HeadroomSettings | undefined {
  if (value === null || typeof value !== 'object') return undefined
  const root = value as { headroom?: Record<string, unknown>; resultCompression?: Record<string, unknown> }
  const headroom = root.headroom ?? {}
  const compression = root.resultCompression ?? {}
  return {
    command: textValue(headroom.command),
    pythonPath: textValue(headroom.pythonPath),
    uvCommand: textValue(headroom.uvCommand),
    port: typeof headroom.port === 'number' ? headroom.port : undefined,
    baseUrl: textValue(headroom.baseUrl),
    autoInstall: typeof headroom.autoInstall === 'boolean' ? headroom.autoInstall : undefined,
    resultCompressionEnabled: typeof compression.enabled === 'boolean' ? compression.enabled : undefined,
    resultCompressionThresholdChars: typeof compression.thresholdChars === 'number'
      ? compression.thresholdChars
      : undefined,
  }
}

/**
 * Bind the card's flat settings view to the plugin's own config form.
 * @param form - the shared form of the entry this plugin is mounted as.
 * @returns the view the card controller edits through.
 */
export function headroomFormScope(form: ConfigForm<Record<string, unknown>>): HeadroomFormScope {
  return {
    getSnapshot: () => {
      const snapshot = form.getSnapshot()
      return { status: snapshot.status, value: projectSettings(snapshot.value), writable: snapshot.writable }
    },
    subscribe: listener => form.subscribe(listener),
    set: (field, value) => form.mutate([{ op: 'set', path: [...FIELD_PATHS[field]], value: value as JsonValue }]),
    unset: field => form.mutate([{ op: 'unset', path: [...FIELD_PATHS[field]] }]),
  }
}

/** The section fields the card edits; mirrored from the host declaration. */
export interface HeadroomSettings {
  command?: string
  pythonPath?: string
  uvCommand?: string
  port?: number
  baseUrl?: string
  autoInstall?: boolean
  resultCompressionEnabled?: boolean
  resultCompressionThresholdChars?: number
}

/** What the card renders. */
export interface HeadroomCardState {
  /** False while the namespace is not served to this client; the card renders nothing. */
  available: boolean
  /** Whether the Host document accepts writes. */
  writable: boolean
  /** Whether the form holds edits a save would write. */
  dirty: boolean
  /** Whether any staged draft is invalid, which blocks the save. */
  invalid: boolean
  /** Whether a save is crossing the wire. */
  saving: boolean
  /** Whether the last save did not land as staged. */
  failed: boolean
  command: string
  pythonPath: string
  uvCommand: string
  port: string
  baseUrl: string
  autoInstall: boolean
  resultCompressionEnabled: boolean
  thresholdChars: string
  thresholdInvalid: boolean
}

/** Editable text fields of the card. */
export type HeadroomTextField = 'command' | 'pythonPath' | 'uvCommand' | 'port' | 'baseUrl' | 'thresholdChars'

/** The registration-side face the card's slot entry injects. */
export interface HeadroomCardFace {
  hooks: {
    /** Card snapshot bound by the renderer as useHeadroomCard. */
    headroomCard: SnapshotStore<HeadroomCardState>
  }
  /** Stage one text field's draft. */
  edit: (field: HeadroomTextField, text: string) => void
  /** Stage the auto-install switch's opposite state. */
  toggleAutoInstall: () => void
  /** Stage the tool-result compression switch's opposite state. */
  toggleResultCompression: () => void
  /** Write every staged edit, then re-seed from what the Host accepted. */
  save: () => void
  /** Drop every staged edit. */
  discard: () => void
}

function textValue(value: unknown): string {
  return typeof value === 'string' ? value : ''
}

function numberText(value: unknown): string {
  return typeof value === 'number' ? String(value) : ''
}

export class HeadroomCardController {
  private readonly staged = new Map<HeadroomTextField, string>()
  private saving = false
  private failed = false
  private readonly store: SnapshotStore<HeadroomCardState>
  private readonly stopWatch: () => void

  constructor(private readonly scope: HeadroomFormScope) {
    this.store = createSnapshotStore(this.projection())
    this.stopWatch = scope.subscribe(() => { this.publish() })
  }

  /** Unsubscribe from the settings scope; call when the owning fiber unloads. */
  dispose(): void {
    this.stopWatch()
  }

  private projection(): HeadroomCardState {
    const snapshot = this.scope.getSnapshot()
    const value = snapshot.value
    return {
      available: snapshot.status === 'ready',
      writable: snapshot.writable,
      dirty: this.staged.size > 0,
      invalid: this.stagedPortInvalid() || this.stagedThresholdInvalid(),
      saving: this.saving,
      failed: this.failed,
      command: this.draft('command', textValue(value?.command)),
      pythonPath: this.draft('pythonPath', textValue(value?.pythonPath)),
      uvCommand: this.draft('uvCommand', textValue(value?.uvCommand)),
      port: this.draft('port', numberText(value?.port)),
      baseUrl: this.draft('baseUrl', textValue(value?.baseUrl)),
      autoInstall: value?.autoInstall ?? true,
      resultCompressionEnabled: value?.resultCompressionEnabled ?? true,
      thresholdChars: this.draft('thresholdChars', numberText(value?.resultCompressionThresholdChars)),
      thresholdInvalid: this.stagedThresholdInvalid(),
    }
  }

  private draft(field: HeadroomTextField, stored: string): string {
    return this.staged.get(field) ?? stored
  }

  private stagedPortInvalid(): boolean {
    const port = this.staged.get('port')
    if (port === undefined) return false
    const trimmed = port.trim()
    if (trimmed === '') return false
    const parsed = Number(trimmed)
    return !Number.isInteger(parsed) || parsed < 1 || parsed > 65535
  }

  private stagedThresholdInvalid(): boolean {
    const threshold = this.staged.get('thresholdChars')
    if (threshold === undefined) return false
    const trimmed = threshold.trim()
    if (trimmed === '') return false
    const parsed = Number(trimmed)
    return !Number.isInteger(parsed) || parsed < 1
  }

  private publish(): void {
    this.store.set(this.projection())
  }

  private stage(field: HeadroomTextField, text: string): void {
    this.staged.set(field, text)
    this.failed = false
    this.publish()
  }

  private async commit(): Promise<void> {
    const writes: Array<Promise<unknown>> = []
    for (const [field, text] of this.staged) {
      const trimmed = text.trim()
      if (field === 'port' || field === 'thresholdChars') {
        if (trimmed === '') writes.push(this.scope.unset(field))
        else writes.push(this.scope.set(field, Number(trimmed)))
      } else if (trimmed === '') {
        writes.push(this.scope.unset(field))
      } else {
        writes.push(this.scope.set(field, trimmed))
      }
    }
    await Promise.all(writes)
  }

  /**
   * Write every staged edit, then re-seed from the Host's accepted state.
   * A failed save keeps its drafts so the user can correct them.
   */
  private async save(): Promise<void> {
    if (this.staged.size === 0 || this.saving || this.stagedPortInvalid() || this.stagedThresholdInvalid()) return
    this.saving = true
    this.failed = false
    this.publish()
    try {
      await this.commit()
      this.staged.clear()
    } catch {
      this.failed = true
    } finally {
      this.saving = false
      this.publish()
    }
  }

  /** Build the face the card's slot registration injects. */
  inject(): HeadroomCardFace {
    return {
      hooks: { headroomCard: this.store },
      edit: (field, text) => this.stage(field, text),
      toggleAutoInstall: () => {
        this.failed = false
        void this.scope.set('autoInstall', !(this.scope.getSnapshot().value?.autoInstall ?? true))
      },
      toggleResultCompression: () => {
        this.failed = false
        void this.scope.set(
          'resultCompressionEnabled',
          !(this.scope.getSnapshot().value?.resultCompressionEnabled ?? true),
        )
      },
      save: () => { void this.save() },
      discard: () => {
        if (this.staged.size === 0 && !this.failed) return
        this.staged.clear()
        this.failed = false
        this.publish()
      },
    }
  }
}
