# -*- coding: utf-8 -*-
import sys, io, zipfile, re, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

def default_tmpl():
    here = os.path.dirname(os.path.abspath(__file__))
    local = os.path.join(os.path.dirname(here), 'assets', 'ref_math_model.docx')
    return local if os.path.exists(local) else 'ref_math_model.docx'

for path in (sys.argv[1:] or [default_tmpl()]):
    print(f'===== {path} =====')
    z = zipfile.ZipFile(path)
    st = z.read('word/styles.xml').decode('utf-8')
    for m in re.finditer(r'<w:style[^>]*>(.*?)</w:style>', st, re.S):
        body = m.group(1)
        nm = re.search(r'<w:name w:val="([^"]+)"', body)
        if nm and nm.group(1).startswith('heading'):
            numPr = re.search(r'<w:numPr>.*?</w:numPr>', body, re.S)
            print(f' name={nm.group(1)} numPr={"YES" if numPr else "no"}')
    print()