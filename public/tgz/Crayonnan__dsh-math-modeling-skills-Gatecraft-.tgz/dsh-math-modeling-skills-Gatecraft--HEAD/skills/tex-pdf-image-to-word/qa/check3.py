# -*- coding: utf-8 -*-
import docx, re

d = docx.Document(r'NIPT_paper_v7_final.docx')

for p in d.paragraphs:
    if '关键词' in p.text:
        print('关键词段落:', p.text[:80])
        for r in p.runs[:4]:
            print('  run:', r.text[:20], '| bold:', r.bold)
    if p.text.strip().startswith('NIPT检测时点'):
        print('标题段落样式:', p.style.name, '| 对齐:', p.alignment)
        for r in p.runs[:3]:
            rpr = r._r.find('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}rPr')
            print('  run:', r.text[:12], '| bold:', r.bold, '| rPr:', (rpr.xml[:220] if rpr is not None else None))
        break

t = d.tables[0]
xml = t._tbl.xml
print('表1 有 tblBorders:', 'w:tblBorders' in xml)
m = re.search(r'<w:tblBorders>.*?</w:tblBorders>', xml, re.S)
print('表1 borders XML:', (m.group(0)[:300] if m else 'NONE'))
st = d.styles['Normal']
rpr = st.element.rPr
print('Normal rPr:', rpr.xml[:400] if rpr is not None else 'None')

bp = d.styles['Body Text'].element
print('BodyText style element:', bp.xml[:300])
