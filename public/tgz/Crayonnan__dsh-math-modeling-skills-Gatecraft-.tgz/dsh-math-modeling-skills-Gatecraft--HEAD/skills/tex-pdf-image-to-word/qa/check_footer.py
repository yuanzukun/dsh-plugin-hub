# -*- coding: utf-8 -*-
import docx
d = docx.Document(r'NIPT_paper_v7_final.docx')
f = d.sections[0].footer
xml = f.paragraphs[0]._p.xml
print('PAGE 域:', 'PAGE' in xml)
print('fldChar 数:', xml.count('fldChar'))
print('居中:', 'w:jc w:val="center"' in xml)
print('页码段落完整:', 'w:instrText' in xml and 'PAGE' in xml)
