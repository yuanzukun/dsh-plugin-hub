# -*- coding: utf-8 -*-
import sys, io, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import docx
from docx import Document

def default_tmpl():
    here = os.path.dirname(os.path.abspath(__file__))
    local = os.path.join(os.path.dirname(here), 'assets', 'ref_math_model.docx')
    return local if os.path.exists(local) else 'ref_math_model.docx'

path = sys.argv[1] if len(sys.argv) > 1 else default_tmpl()
d = Document(path)
print('=== 模板基准标题段落 ===')
for p in d.paragraphs:
    if p.style.name.startswith('Heading') or '标题' in p.style.name:
        print(f'[{p.style.name}] {p.text.strip()[:50]}')
print()
print('=== 模板基准 正文段落样式名称集合 ===')
from collections import Counter
c = Counter(p.style.name for p in d.paragraphs if p.text.strip())
for k, v in c.items():
    print(k, v)