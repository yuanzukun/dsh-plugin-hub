# -*- coding: utf-8 -*-
"""文本级校验：两个 PDF 的章节/图表标题/公式编号是否全部存在"""
import fitz, re, io

src = fitz.open(r'NIPT_paper_v7_final.pdf')
wrd = fitz.open(r'NIPT_paper_v7_final_from_word.pdf')

def all_text(doc):
    return '\n'.join(p.get_text() for p in doc)

st = all_text(src)
wt = all_text(wrd)

out = io.open('render/text_compare.txt', 'w', encoding='utf-8')

# 1. section 标题（docx 转换出的编号形式）
sections = ['问题重述', '问题分析', '符号说明', '模型假设', '数据收集与预处理',
            'Y染色体浓度影响因素建模', 'BMI分层的最佳检测孕周', '个性化检测时点优化',
            '胎儿异常判定', '模型评价与推广', '附录', '公式推导']
out.write('=== 章节标题存在性 ===\n')
for s in sections:
    out.write(f'{"OK " if s in wt else "MISS"} Word: {s}\n')

# 2. 图表编号
caps = re.findall(r'(?:表|图)\s*\d+\.\d+', st)
def numkey(x):
    a, b = re.search(r'(\d+)\.(\d+)', x).groups()
    return (int(a), int(b))
uniq = sorted(set(caps), key=numkey)
out.write('\n=== 源PDF图表编号 ===\n' + ' '.join(uniq) + '\n')
caps_w = re.findall(r'(?:表|图)\s*\d+\.\d+', wt)
uniq_w = sorted(set(caps_w), key=numkey)
out.write('=== Word-PDF图表编号 ===\n' + ' '.join(uniq_w) + '\n')
missing = [c for c in uniq if c not in set(caps_w)]
out.write(f'\n缺失(仅源有): {missing if missing else "无"}\n')

# 3. 公式编号
eq_src = sorted(set(re.findall(r'\((\d+\.\d+)\)', st)), key=lambda x: (int(x.split('.')[0]), int(x.split('.')[1])))
eq_wrd = sorted(set(re.findall(r'\((\d+\.\d+)\)', wt)), key=lambda x: (int(x.split('.')[0]), int(x.split('.')[1])))
out.write(f'\n源PDF公式编号: {eq_src}\n')
out.write(f'Word公式编号: {eq_wrd}\n')

# 4. 分页偏移量化：找 11 个 section 标题在两边 PDF 中的页码
out.write('\n=== 分页映射（section标题页码）===\n')
for s in ['问题重述', '问题分析', '符号说明', '模型假设', '数据收集与预处理', '问题一',
          '问题二', '问题三', '问题四', '模型评价与推广', '附录']:
    def find_page(doc, pat):
        for i, p in enumerate(doc):
            if re.search(pat, p.get_text()):
                return i + 1
        return None
    ps = find_page(src, s)
    pw = find_page(wrd, s)
    if ps is None or pw is None:
        out.write(f'{s}: src p{ps} | wrd p{pw} | 未找到\n')
    else:
        out.write(f'{s}: src p{ps} | wrd p{pw} | 偏移 {pw - ps:+d}\n')

# 5. 尾部代码块（附录最后一项）
tail_s = st.strip()[-80:].replace('\n', ' ')
tail_w = wt.strip()[-80:].replace('\n', ' ')
out.write(f'\n源PDF末尾: {tail_s}\n')
out.write(f'Word末尾: {tail_w}\n')
out.close()
print('done')
