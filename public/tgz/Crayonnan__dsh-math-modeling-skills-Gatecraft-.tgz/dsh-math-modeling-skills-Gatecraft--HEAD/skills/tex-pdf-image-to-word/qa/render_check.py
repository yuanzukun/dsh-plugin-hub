# -*- coding: utf-8 -*-
import fitz
doc = fitz.open('NIPT_paper_v7_stage1.pdf')
print('pages:', len(doc))
targets = [0, 1, 2, 3, 4]
for i in targets:
    if i < len(doc):
        pix = doc[i].get_pixmap(dpi=100)
        pix.save(f'render_p{i+1}.png')
        print(f'p{i+1} saved')
t = doc[0].get_text()
print('=== p1 text (first 800 chars) ===')
print(t[:800])