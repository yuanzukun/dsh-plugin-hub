# -*- coding: utf-8 -*-
import sys, io, zipfile, re, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

def default_tmpl():
    here = os.path.dirname(os.path.abspath(__file__))
    local = os.path.join(os.path.dirname(here), 'assets', 'ref_math_model.docx')
    return local if os.path.exists(local) else 'ref_math_model.docx'

path = sys.argv[1] if len(sys.argv) > 1 else default_tmpl()
z = zipfile.ZipFile(path)
names = z.namelist()
print('numbering.xml' in names)
num = z.read('word/numbering.xml').decode('utf-8')
nums = dict(re.findall(r'<w:num w:numId="(\d+)"[^>]*>\s*<w:abstractNumId w:val="(\d+)"/>', num))
ab = dict(re.findall(r'<w:abstractNum w:abstractNumId="(\d+)">(.*?)</w:abstractNum>', num, re.S))
print('numId->abstractNum:', nums)
for aid, body in ab.items():
    fmts = re.findall(r'<w:lvl w:ilvl="(\d+)"[^>]*>.*?<w:numFmt w:val="([^"]+)"[^>]*/>.*?<w:lvlText w:val="([^"]*)"', body, re.S)
    if fmts:
        print(f' abstract {aid}: {fmts[:4]}')
