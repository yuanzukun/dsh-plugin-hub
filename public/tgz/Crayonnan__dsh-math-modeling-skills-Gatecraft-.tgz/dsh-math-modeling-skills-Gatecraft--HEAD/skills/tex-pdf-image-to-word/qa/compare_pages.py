# -*- coding: utf-8 -*-
import os, sys, base64, mimetypes
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from openai import OpenAI

API_KEY = os.environ.get("SILICONFLOW_API_KEY")
if not API_KEY:
    sys.exit("错误：未设置 SILICONFLOW_API_KEY 环境变量（申请地址 https://cloud.siliconflow.cn/me/models）")
MODEL = "Qwen/Qwen3-VL-32B-Instruct"
BASE_URL = "https://api.siliconflow.cn/v1"
client = OpenAI(api_key=API_KEY, base_url=BASE_URL)

PROMPT = """你是文档版式对比专家。我给出同一论文的两页渲染图：图1是原始 LaTeX 编译的 PDF 页面，图2是转换生成的 Word 文档页面（可能页码或分页略有偏移）。
请对比两页：
1. 内容是否一致（文字/公式/表格/图片是否缺失或多余）
2. 公式是否显示正常（不是乱码/不是 LaTeX 源码）
3. 表格/图片是否错位或溢出页面
4. 版式差异（字体、对齐、间距）
请用中文输出：先给出"结论"（一致/基本一致/有差异），再列出具体差异点（若有）。只输出分析本身。"""

def encode_image(path):
    mime, _ = mimetypes.guess_type(path)
    with open(path, "rb") as f:
        return f"data:{mime or 'image/png'};base64,{base64.b64encode(f.read()).decode()}"

pairs = [
    ('render/src_p1.png', 'render/wrd_p1.png', '第1页 标题+摘要'),
    ('render/src_p10.png', 'render/wrd_p10.png', '第10页 公式+表格'),
    ('render/src_p16.png', 'render/wrd_p16.png', '第16页 问题二图表'),
    ('render/src_p21.png', 'render/wrd_p21.png', '第21页 问题四ROC+表格'),
]
out = open('render/compare_report.txt', 'w', encoding='utf-8')
for s, w, desc in pairs:
    resp = client.chat.completions.create(
        model=MODEL,
        messages=[{"role": "user", "content": [
            {"type": "text", "text": PROMPT},
            {"type": "image_url", "image_url": {"url": encode_image(s)}},
            {"type": "image_url", "image_url": {"url": encode_image(w)}}]}],
        temperature=0.1, max_tokens=3000)
    txt = resp.choices[0].message.content
    out.write(f'===== {desc} =====\n{txt}\n\n')
    out.flush()
    print(f'{desc} done')
out.close()
print('ALL DONE')
