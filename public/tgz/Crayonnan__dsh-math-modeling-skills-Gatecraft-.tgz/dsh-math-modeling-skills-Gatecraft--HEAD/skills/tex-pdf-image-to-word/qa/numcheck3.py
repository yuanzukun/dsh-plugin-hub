# -*- coding: utf-8 -*-
import sys, io, zipfile, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

for path in (r'NIPT_paper_v7_stage1.docx', r'ref_math_model.docx'):
    print(f'===== {path} =====')
    z = zipfile.ZipFile(path)
    if 'word/numbering.xml' not in z.namelist():
        print('no numbering.xml'); continue
    num = z.read('word/numbering.xml').decode('utf-8')
    nums = dict(re.findall(r'<w:num w:numId="(\d+)"[^>]*>\s*<w:abstractNumId w:val="(\d+)"/>', num))
    ab = dict(re.findall(r'<w:abstractNum w:abstractNumId="(\d+)">(.*?)</w:abstractNum>', num, re.S))
    for nid, aid in sorted(nums.items(), key=lambda x: int(x[0])):
        body = ab.get(aid, '')
        fmts = re.findall(r'<w:lvl w:ilvl="(\d+)"[^>]*>.*?<w:numFmt w:val="([^"]+)"[^>]*/>.*?<w:lvlText w:val="([^"]*)"', body, re.S)
        print(f' numId={nid} -> abstract {aid}: {fmts[:3]}')
