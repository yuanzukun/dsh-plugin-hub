# -*- coding: utf-8 -*-
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import docx
from docx.oxml.ns import qn

d = docx.Document('NIPT_paper_v7_stage1.docx')
for sname in ('Heading 1', 'Heading 2', 'Heading 3'):
    st = d.styles[sname]
    pPr = st.element.find(qn('w:pPr'))
    numPr = pPr.find(qn('w:numPr')) if pPr is not None else None
    if numPr is not None:
        numId = numPr.find(qn('w:numId'))
        ilvl = numPr.find(qn('w:ilvl'))
        print(f'{sname}: numId={numId.get(qn("w:val")) if numId is not None else None} ilvl={ilvl.get(qn("w:val")) if ilvl is not None else None}')
    else:
        print(f'{sname}: no numPr')
