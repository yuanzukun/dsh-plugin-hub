# -*- coding: utf-8 -*-
import docx, io
from docx.oxml.ns import qn

d = docx.Document(r'NIPT_paper_v7_final.docx')
out = io.open('check_content2.txt', 'w', encoding='utf-8')

full_math = []
for p in d.paragraphs:
    if '$' in p.text or '5.1展示了' in p.text or '表' in p.text and '灵敏度' in p.text:
        out.write(f'[{p.style.name}] {p.text[:110]}\n')

body = d.element.body
omaths = body.findall('.//' + qn('m:oMath'))
out.write(f'\n总 oMath: {len(omaths)}\n')
big = [o for o in omaths if len(o.findall(qn('m:oMathPara'))) == 0]
# 提取独立公式(oMathPara)的文本
paras = body.findall('.//' + qn('m:oMathPara'))
out.write(f'独立公式: {len(paras)}\n')
for i, op in enumerate(paras):
    ts = op.findall('.//' + qn('m:t'))
    txt = ''.join(t.text or '' for t in ts)
    out.write(f'  公式{i+1}: {txt[:80]}\n')
out.close()
print('done')
