# -*- coding: utf-8 -*-
"""检查转换后的 docx 结构完整性"""
import docx
from docx.oxml.ns import qn

d = docx.Document(r'NIPT_paper_v7_final.docx')

paras = d.paragraphs
tables = d.tables
body = d.element.body
oMath = body.findall('.//' + qn('m:oMath'))
imgs = body.findall('.//' + qn('w:drawing'))

print(f'段落数: {len(paras)}')
print(f'表格数: {len(tables)}')
print(f'OMML公式数: {len(oMath)}')
print(f'图片数: {len(imgs)}')

from collections import Counter
styles = Counter(p.style.name for p in paras)
print('段落样式分布:', dict(styles))

h1 = [p.text for p in paras if p.style.name == 'Heading 1']
print('H1 标题:')
for t in h1: print('  -', t[:50])

caps = [p.text[:60] for p in paras if p.style.name == 'Caption']
print('Caption 段落:')
for t in caps: print('  -', t)

for i, tb in enumerate(tables[:3]):
    print(f'表{i+1}: {len(tb.rows)}行 x {len(tb.columns)}列 | 首行: {[c.text[:12] for c in tb.rows[0].cells]}')
