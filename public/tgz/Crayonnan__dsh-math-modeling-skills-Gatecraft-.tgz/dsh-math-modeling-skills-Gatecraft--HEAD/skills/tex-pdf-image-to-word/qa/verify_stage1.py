# -*- coding: utf-8 -*-
import docx, re
from docx import Document
from docx.oxml.ns import qn

d = Document(r'NIPT_paper_v7_stage1.docx')

print('=== 标题段落（样式 + 文本 + numPr + pageBreakBefore） ===')
for p in d.paragraphs:
    if p.style.name.startswith('Heading'):
        pPr = p._p.find(qn('w:pPr'))
        num = pPr.find(qn('w:numPr')) if pPr is not None else None
        pb = pPr.find(qn('w:pageBreakBefore')) if pPr is not None else None
        print(f"[{p.style.name}] num={num is not None} pb={pb is not None} | {p.text.strip()[:40]}")

print()
print('=== 正文段落样式分布（前100段抽样） ===')
from collections import Counter
c = Counter(p.style.name for p in d.paragraphs if p.text.strip())
print(c)

print()
print('=== 技术路线行 ===')
for p in d.paragraphs:
    if '技术路线' in p.text:
        print(repr(p.text[:120]))

print()
print('=== 参考文献条目开头 ===')
seen = 0
for p in d.paragraphs:
    m = re.match(r'^\[(\d+)\]', p.text.strip())
    if m:
        print(f"[{p.style.name}] {p.text.strip()[:60]}")
        seen += 1
        if seen >= 5: break

print()
print('=== 列表项（List Paragraph）样例 ===')
for p in d.paragraphs:
    if p.style.name == 'List Paragraph':
        print(repr(p.text[:50]))