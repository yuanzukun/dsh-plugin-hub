# -*- coding: utf-8 -*-
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import fitz, re
doc = fitz.open('NIPT_paper_v7_stage1.pdf')
full = '\n'.join(doc[i].get_text() for i in range(len(doc)))

for kw in ['问题重述', '模型建立', '数据收集', '参考文献', '附录', '符号说明', '模型的检验', '模型的评价与推广']:
    for m in re.finditer(re.escape(kw), full):
        s = max(0, m.start() - 20)
        e = m.end() + 20
        print(f'[{kw}] ctx: {repr(full[s:e].replace(chr(10), " "))}')
        break

print()
print('=== A 公式编号附近 ===')
for m in re.finditer(r'A\.\d', full):
    s = max(0, m.start()-20); e = m.end()+20
    print(repr(full[s:e].replace(chr(10), ' ')))

print()
print('=== 参考文献/附录所在页 - 找标题页 ===')
# 找"参考文献"所在页与前一页
for i in range(len(doc)):
    t = doc[i].get_text()
    if '参考文献' in t:
        print(f"参考文献 appears on p{i+1}")
    if '附录' in t and '附表' not in t:
        print(f"附录 appears on p{i+1}")