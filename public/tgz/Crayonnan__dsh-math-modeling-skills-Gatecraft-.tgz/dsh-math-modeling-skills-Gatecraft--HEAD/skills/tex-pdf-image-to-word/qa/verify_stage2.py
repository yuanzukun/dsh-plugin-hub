# -*- coding: utf-8 -*-
import docx
from docx import Document
from docx.oxml.ns import qn

d = Document(r'NIPT_paper_v7_stage1.docx')

print('=== 带段落级 numPr 的段落（列表项） ===')
for i, p in enumerate(d.paragraphs):
    pPr = p._p.find(qn('w:pPr'))
    if pPr is not None and pPr.find(qn('w:numPr')) is not None:
        txt = p.text.strip()
        print(f"{i} [{p.style.name}] {txt[:60]}")

print()
print('=== 非空 Body Text / First Paragraph 残留 ===')
for i, p in enumerate(d.paragraphs):
    txt = p.text.strip()
    if txt and p.style.name in ('Body Text', 'First Paragraph'):
        print(f"{i} [{p.style.name}] {txt[:60]}")

print()
print('=== 参考文献条目样式与前20字 ===')
for i, p in enumerate(d.paragraphs):
    txt = p.text.strip()
    if txt.startswith('[1]') or txt.startswith('[2]'):
        pPr = p._p.find(qn('w:pPr'))
        ind = pPr.find(qn('w:ind')) if pPr is not None else None
        fl = ind.get(qn('w:firstLineChars')) if ind is not None else None
        print(f"{i} [{p.style.name}] firstLine={fl} {txt[:40]}")

print()
print('=== 关键词/摘要/标题段落 ===')
for i, p in enumerate(d.paragraphs):
    txt = p.text.strip()
    if txt.startswith('关键词') or txt.startswith('摘'):
        print(f"{i} [{p.style.name}] {txt[:40]}")