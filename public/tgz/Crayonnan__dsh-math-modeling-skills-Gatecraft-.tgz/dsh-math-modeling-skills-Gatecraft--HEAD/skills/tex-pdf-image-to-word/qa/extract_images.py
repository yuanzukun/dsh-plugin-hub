# -*- coding: utf-8 -*-
"""从 PDF 提取内嵌图片，按 tex 引用顺序命名"""
import fitz

doc = fitz.open(r'NIPT_paper_v7_final.pdf')
names = [
    'fig_eda_distributions.png', 'fig_spearman_heatmap.png',
    'fig_q1_model_fits.png', 'fig_model_comparison_v2.png',
    'fig_residual_diag.png', 'fig_sensitivity_v2.png',
    'fig_q2_combined.png', 'fig_q3_individualized.png', 'fig_q4_roc.png',
]

imgs = []
for pno in range(len(doc)):
    for img in doc[pno].get_images(full=True):
        xref = img[0]
        pix = fitz.Pixmap(doc, xref)
        imgs.append((pno, xref, pix.width, pix.height))

print('found images:', len(imgs))
for i, (pno, xref, w, h) in enumerate(imgs):
    pix = fitz.Pixmap(doc, xref)
    if pix.n - pix.alpha >= 4:
        pix = fitz.Pixmap(fitz.csRGB, pix)
    if i < len(names):
        pix.save(names[i])
        print(f'[{i}] p{pno} xref{xref} {w}x{h} -> {names[i]}')
    else:
        print(f'[{i}] p{pno} xref{xref} {w}x{h} (extra, skipped)')
