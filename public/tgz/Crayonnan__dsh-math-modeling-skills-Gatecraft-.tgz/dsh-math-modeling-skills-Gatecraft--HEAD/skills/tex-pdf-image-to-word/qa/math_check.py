# -*- coding: utf-8 -*-
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import docx
from docx import Document
from docx.oxml.ns import qn
from lxml import etree

d = Document('NIPT_paper_v7_stage1.docx')
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
M = '{http://schemas.openxmlformats.org/officeDocument/2006/math}'

# 找含"强正相关"的段落，检查其内部 run 与 math 元素
for p in d.paragraphs:
    if '强正相关' in p.text:
        xml = etree.tostring(p._p, encoding='unicode')
        has_math = '<m:oMath' in xml
        # 提取所有 w:t 文本节点片段，标记公式区间
        frag = []
        for el in p._p.iter():
            tag = el.tag
            if tag == qn('w:t') and el.text:
                frag.append(('T', el.text[:20]))
            elif tag.endswith('}oMath'):
                frag.append(('MATH', ''))
        print('has_math:', has_math)
        print('frag:', frag)
        break

print()
print('=== 全文含裸希腊字母的文本 run（非公式内） ===')
import re
GREEK = 'αβγρσεμλΣβρ'
cnt = 0
for p in d.paragraphs:
    for run in p.runs:
        if any(ch in run.text for ch in GREEK):
            print(f'[{p.style.name}] {run.text[:40]}')
            cnt += 1
            if cnt > 15: break
    if cnt > 15: break
if cnt == 0: print('(无裸希腊字母 run)')

print()
print('=== OMML 公式段落数 ===')
n = 0
for p in d.paragraphs:
    if p._p.findall(f'{M}oMathPara'):
        n += 1
print(n)