# -*- coding: utf-8 -*-
import docx, io, sys
from docx.oxml.ns import qn

d = docx.Document(r'NIPT_paper_v7_final.docx')
out = io.open('check_content.txt', 'w', encoding='utf-8')

paras = d.paragraphs
for i, p in enumerate(paras[:120]):
    t = p.text.strip()
    if not t:
        continue
    style = p.style.name
    tag = 'OMML' if p._element.findall('.//' + qn('m:oMath')) else ''
    out.write(f'[{i}] {style} {tag} {t[:90]}\n')

body = d.element.body
oMathPara = body.findall('.//' + qn('m:oMathPara'))
out.write(f'\n=== 独立公式(oMathPara): {len(oMathPara)} ===\n')

for i, tb in enumerate(d.tables):
    out.write(f'\n=== 表{i+1}: {len(tb.rows)}行 x {len(tb.columns)}列 ===\n')
    for r in tb.rows[:2]:
        out.write(' | '.join(c.text[:16].replace('\n', ' ') for c in r.cells) + '\n')

out.close()
print('done')
