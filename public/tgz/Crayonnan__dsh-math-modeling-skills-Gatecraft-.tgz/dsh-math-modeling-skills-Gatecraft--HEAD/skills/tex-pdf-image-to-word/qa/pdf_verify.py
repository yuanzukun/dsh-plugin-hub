# -*- coding: utf-8 -*-
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import fitz, re
doc = fitz.open('NIPT_paper_v7_stage1.pdf')
full = '\n'.join(doc[i].get_text() for i in range(len(doc)))

def wfind(pat, label, n=4):
    print(f'--- {label} ---')
    cnt = 0
    for m in re.finditer(pat, full, re.M):
        s = max(0, m.start() - 30)
        print(repr(full[s:m.end() + 60].replace('\n', ' ')))
        cnt += 1
        if cnt >= n: break
    if cnt == 0: print('(none)')

wfind(r'^\s*1\s*问题重述', '一级标题自动编号')
wfind(r'^\s*\d+\.\d+\s*\S+', '二级标题自动编号', 3)
wfind(r'技术路线', '技术路线')
wfind(r'\(\d+\.\d+\)', '公式编号', 3)
wfind(r'^\[\d+\]', '参考文献条目', 3)
wfind(r'^\s*[A-C]\.\d+', '附录公式编号', 3)
wfind(r'摘\s*要', '摘要标题')
wfind(r'关键词', '关键词')
wfind(r'^\s*\d+\s*$', '页码', 2)
wfind(r'\*\*', '残留markdown星号')

print()
print('=== 各页首行（检查分页/标题位置） ===')
for i in range(len(doc)):
    t = doc[i].get_text().strip().split('\n')
    first = t[0][:30] if t else ''
    print(f'p{i+1}: {first}')