# -*- coding: utf-8 -*-
import sys, io, zipfile, re, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

def default_tmpl():
    here = os.path.dirname(os.path.abspath(__file__))
    local = os.path.join(os.path.dirname(here), 'assets', 'ref_math_model.docx')
    return local if os.path.exists(local) else 'ref_math_model.docx'

def heading_numpr(path):
    z = zipfile.ZipFile(path)
    st = z.read('word/styles.xml').decode('utf-8')
    out = {}
    for m in re.finditer(r'<w:style[^>]*w:styleId="(Heading[123])"[^>]*>(.*?)</w:style>', st, re.S):
        sid, body = m.group(1), m.group(2)
        nm = re.search(r'<w:name w:val="([^"]+)"', body)
        numPr = re.search(r'<w:numPr>\s*<w:ilvl w:val="(\d+)"/>\s*<w:numId w:val="(\d+)"/>', body)
        out[sid] = (nm.group(1) if nm else '', numPr.groups() if numPr else None)
    return out

paths = sys.argv[1:] or [default_tmpl()]
for path in paths:
    print(f'===== {path} =====')
    for sid, (nm, np) in heading_numpr(path).items():
        print(f' {sid} ({nm}): numPr={np}')