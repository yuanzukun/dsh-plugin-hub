# -*- coding: utf-8 -*-
import re
lines = open(r'NIPT_paper_v7_final.tex', encoding='utf-8').read().splitlines()
sec = [0, 0, 0]
appendix = False
in_code = False
for i, ln in enumerate(lines, 1):
    s = ln.strip()
    if re.match(r'^\\begin\{lstlisting\}', s):
        in_code = True
    if re.match(r'^\\end\{lstlisting\}', s):
        in_code = False
        continue
    if in_code:
        continue
    if re.match(r'^\\appendix', s):
        appendix = True
    m = re.match(r'^\\(subsub|sub)?section\{([^}]*)\}', s)
    if m:
        if m.group(1) == 'subsub':
            lv = 2
        elif m.group(1) == 'sub':
            lv = 1
        else:
            lv = 0
        sec[lv] += 1
        for k in range(lv + 1, 3):
            sec[k] = 0
        pre = 'A' if (appendix and lv == 0) else '.'.join(str(x) for x in sec if x > 0)
        print(f'{i}: [{pre}] {s[:70]}')
