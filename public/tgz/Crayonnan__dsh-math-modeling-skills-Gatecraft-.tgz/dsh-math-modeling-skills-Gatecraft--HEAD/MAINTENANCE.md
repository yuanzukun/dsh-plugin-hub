# MAINTENANCE — 数学建模模式维护手册

> 本文件面向**维护者**：说明「数学建模模式」是什么、如何改、如何验证、如何发布。
> 面向用户的安装与使用说明见 `README.md`（中文）/ `README.en.md`（英文）。

---

## 1. 什么是「数学建模模式」

「数学建模模式」是 GateCraft 插件在 DeepSeek Harness 中提供的一个 **agent preset**（`presets/math-modeling/`）+ **9 个 skill** 的组合。选中该模式后，粘贴一道竞赛题即可自动进入五阶段流水线：

```
读题 → 数据结构探索(EDA五问) → 建模与验证 → 灵敏度/统计诊断 → 国奖范式写作 → 验收
         （每个阶段门：报告通过自检才放行下一阶段）
```

核心纪律（贯穿所有 skill）：

| 纪律 | 含义 |
|---|---|
| **阶段门** | 每阶段报告必须通过自检才能前进；失败迭代 2-3 轮并记录「改动→效果→指标」 |
| **报告先行** | 论文每句必须来自阶段报告事实；范文句子只作样例，不抄模板 |
| **数值纪律** | 论文每个数字只许来自 `reports/` 报告或代码输出；改脚本重跑后做零漂移核对 |
| **批判性验证** | 外部指南逐条核实、第三方结论重算、结果对照文献基准 |

---

## 2. 目录结构（真源）

```
gatecraft/
├── skills/                          ← 9 个 skill（每个目录一个 SKILL.md）
│   ├── competition-workflow/        ← 总控：五阶段流水线 + 阶段门
│   ├── guozhan-paper/               ← 国奖写作范式（2023-2025 获奖论文提炼）
│   ├── vision-ocr/                  ← OCR 读题/读范文（Qwen3-VL，env 密钥）
│   ├── sensitivity-analysis/        ← 灵敏度分析引擎
│   ├── statistical-diagnosis/       ← 统计诊断流水线
│   ├── math-modeling-paper/         ← 论文内容规范与诊断润色
│   ├── math-paper-template/         ← LaTeX 排版工程
│   ├── tex-pdf-image-to-word/       ← 论文转 Word（含 scripts/ 与 qa/）
│   └── paper-gate/                  ← 交付强制验收层（docgate 引擎）
├── assets/                          ← 与 skills 同步的共享资产
│   ├── docgate.py                   ← paper-gate 执行引擎（13 项检查）
│   ├── paper-gate-rules.yaml        ← 检查阈值/词表参数化配置
│   ├── optimization-playbook.md     ← 优化求解/验证决策表
│   ├── figure-playbook.md           ← 流程图与图件模板
│   ├── prompt-pack.md               ← 14 条实战提示词
│   ├── official-paper-format.md     ← 官方《论文模版-说明版》全量提炼
│   ├── huashubei-writing-guide.md   ← 华数杯写作指南全本
│   ├── flowchart_gen.py             ← 规格→drawio 生成器
│   └── ocr_batch.py                 ← 并发 OCR
├── presets/math-modeling/           ← DSH preset（agent.cordis.yml + preset.yml）
├── index.js                         ← bundle 入口（扫描 skills/*/SKILL.md 注册到 ctx.skills）
├── cordis.patch.yml                 ← cordis patch（注册 gatecraft 组件）
├── package.json                     ← dsh.bundle 声明 + npm files 白名单
├── README.md / README.en.md         ← 用户文档（生成时保持与代码一致！）
└── MAINTENANCE.md                   ← 本文件
```

---

## 3. 维护与更新流程

### 3.1 修改已有 skill

1. 只改 `skills/<name>/SKILL.md`（或 `assets/` 里的对应文件）。
2. 如果改的是规则/阈值，优先改 `assets/paper-gate-rules.yaml` 或创建新的参数文件，不要硬编码。
3. **写任何数模规则前先定层级再定语气**：【事实】/【不变量】可以硬（且尽量落到 `docgate.py`），【观察】与手艺判断只能写成"样本中常见 + 以当届模板为准"或"常见误区 / 推荐-不推荐 / 自查问句"。三层定义与判据的唯一说明处在 `skills/paper-gate/SKILL.md` 的「规则分级约定」。跳过这一步是历史上所有口径漂移的起点。
4. 查阅型内容（决策树、清单、实证语料）放该 skill 的 `references/` 子目录，SKILL.md 里留一行指针 + 顶部「何时读哪个文件」表。**不要放 `assets/` 的子目录**——`sync.ps1` 对 assets 是非递归拷贝，子目录会静默漏分发。
5. 提交前跑第 4 节验证清单。

### 3.2 新增 skill

1. 建目录 `skills/<new-name>/SKILL.md`。
2. **SKILL.md 首行必须是 YAML frontmatter**（`---` 开头）：

   ```markdown
   ---
   name: new-name
   description: 一句话说明。触发词：……；产出：……
   ---
   ```

   ⚠️ **历史教训**：`paper-gate` 曾因缺 frontmatter 导致 `index.js` 加载即抛错（`gatecraft: ... missing YAML frontmatter`），整个 bundle 起不来。**name 必须与目录名一致**（合法字符：小写字母/数字/连字符）。
3. 若有共享资产，放 `assets/`（skill 内用 `../../assets/xxx.md` 引用，相对路径在 5 个目标一致）。
4. 更新 `package.json` 的 `files` 白名单（无需——白名单按目录列？见 3.4），更新 README 的 skill 列表与计数。
5. 跑验证。

### 3.3 删除 skill

1. `git rm -r skills/<name>`。
2. **同步更新**：`README.md`/`README.en.md` 的 skill 列表与计数（描述必须与代码一致——维护者会核对数字）。
3. 检查其他 skill 是否仍引用它（无死引用）。

### 3.4 版本与分发

- `package.json` 的 `files` 白名单**精确列出 9 个 skill 目录**（不要用宽泛的 `skills`——防止 `qa/` 调试残渣、`agents/openai.yaml` 等混入）。
- 发布时 bump `version`（如 0.2.0 → 0.3.0）。
- 分发载体：GitHub 仓库本身（`dsh plugin add Crayonnan/dsh-math-modeling-skills-Gatecraft-`）。不强制 npm 发布。

### 3.5 密钥约定（铁律）

- **任何 API key 一律从环境变量读取，绝不硬编码在仓库文件里**：

  ```python
  API_KEY = os.environ.get("SILICONFLOW_API_KEY")   # ✅ 正确
  if not API_KEY: sys.exit("未设置 SILICONFLOW_API_KEY ...")
  # ❌ 禁止 API_KEY = os.environ.get(..., "sk-xxxx")  内置默认值
  ```

- 当前生效 key 存在用户级环境变量 `SILICONFLOW_API_KEY`（本机 `setx` 设置）。
- **key 一旦进过 git 历史即视为泄露**：必须立即轮换（SiliconFlow 控制台重置），只改文件而不换 key 是无效止血。
- 本文件故意不写 key 明文。

### 3.6 个人路径（铁律）

- 仓库文件不得出现作者机器路径（`C:\Users\...`、`E:\...\<your-path>`、`Desktop\2025...`）——用 `~`、`os.path.expanduser`、argv 参数、`tempfile` 代替。
- 验证：`git grep -n -E "(E:\\windows_ext|C:\\Users\\<you>|Desktop\\2025)"` 应为空。

---

## 4. 提交前验证清单（每次修改后必跑）

```powershell
# 1. bundle 加载验证（9 个 skill 都能被 index.js 接受）
node --input-type=module -e "
const m = await import('./index.js');
const rs = [];
m.apply({ skills: { registerProvider: p => rs.push(p) } });
const p = rs[0]();
const list = await p.list({ signal: { throwIfAborted(){} } });
console.log('skills:', list.length, list.map(s => s.name).join(', '));
if (list.length !== 9) process.exit(1);
"

# 2. Python 语法检查（改过的 .py）
python -m py_compile skills/tex-pdf-image-to-word/scripts/vision_qwen.py assets/docgate.py

# 3. 密钥/路径零残留
git grep -nIE "sk-[A-Za-z0-9]{20,}|ghp_[A-Za-z0-9]{36}|AIza[0-9A-Za-z_-]{35}"   # 应为空：任何真实密钥形态
git grep -nIE "API_KEY\s*=\s*[\"']sk-"                                          # 应为空：key 只能从 env 读
git log --all -p | grep -oE "sk-[A-Za-z0-9]{20,}" | sort -u                       # 应为空：历史里也没漏过
git grep -n -E "(E:\\windows_ext|C:\\Users\\<you>|Desktop\\2025|<your-id>)"  # 应为空

# 4. docgate 判级回归（改过 docgate.py / rules.yaml / 夹具才需要，但跑一遍很便宜）
python tests/test_docgate.py   # 20/20；含判级基线锁定（脏文档 5 FAIL + 5 WARN）与 yaml severity 覆写测试

# 5. 打包范围
npm pack --dry-run   # 应只含 9 skill + assets + presets，无 qa 调试残渣外的意外文件
```

---

## 5. 常见陷阱（都踩过）

| 陷阱 | 后果 | 对策 |
|---|---|---|
| SKILL.md 缺 frontmatter | bundle 加载即崩 | 新 skill 必带 `--- name/description ---` |
| README 声称数量与实际不符 | awesome 维护者打回 | 每次增删 skill 同步数字 |
| key 硬编码进 skill 正文 | 插件分发=公开泄密 | 一律 env 读取 |
| 个人路径写进文件 | 用户在异机无法运行 | 可移植写法 |
| `files` 用宽泛目录 | 调试残渣随包分发 | 精确白名单 |
| 只改 LaTeX 版不重跑 docgate | 提交版与校验版不一致 | 工件唯一性：以最终提交文件为准 |
