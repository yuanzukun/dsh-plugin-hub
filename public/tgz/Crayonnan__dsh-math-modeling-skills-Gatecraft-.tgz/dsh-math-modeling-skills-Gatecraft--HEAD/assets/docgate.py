#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
docgate.py — 数模论文交付前机械检查器（paper-gate skill 的执行引擎）
=====================================================================
用法:
    python docgate.py <paper.docx|paper.tex> [--config paper-gate-rules.yaml]
                      [--out REPORT.md] [--pdf paper.pdf] [--results RESULTS_REPORT.md]
                      [--problem problem.txt]

设计原则（详见 skills/paper-gate/SKILL.md「规则分级约定」）:
  - 以最终提交工件为唯一验收对象; FAIL 修复后重跑, 误报豁免须落盘登记。
  - FAIL 只覆盖两类: 客观事实错误 + 可机械验证的真实性问题。
    篇幅/结构形态/文风属手艺判断, 一律 WARN 交人工裁决。
  - 规则阈值与判级全部来自 --config yaml(severity 段); 本文件不含任何赛事专名,
    也不硬编码判级字面量——删掉 yaml 的 severity 段即回落到内置默认。
  - 检查项 v1 共 13 项:
      恒 FAIL   01图片几何 02编号对账 12变量解释完整性 13重述原创度
      分级      03AI痕迹(文献区FAIL/正文WARN) 05声明白名单(有--results才FAIL)
                08文字校对(fail级模式FAIL/warn级模式WARN) 10格式合规(页边距FAIL/页数WARN)
      走 severity 06篇幅均衡 07跨章重复 09结构模板
      恒 WARN   04摘要对账的数量级哨兵部分 11语言去AI化
                (11b: 仅当 yaml style.buzzwords_fail 非空时才发 FAIL)
"""
import argparse
import json
import re
import sys
import datetime
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import yaml

EMU_PER_CM = 360000.0
TWIPS_PER_CM = 567.0


# ----------------------------------------------------------------------
# 基础数据结构
# ----------------------------------------------------------------------
class F:
    """一条检查发现。severity: FAIL / WARN / SKIP / INFO"""

    def __init__(self, cid, severity, title, details=None):
        self.cid, self.severity, self.title = cid, severity, title
        self.details = details or []

    def line(self):
        return "[%s] %s" % (self.severity, self.title)


class IR:
    """文档中间表示——两个后端(docx/tex)都产出此结构, 检查器只认它"""

    def __init__(self):
        self.kind = None
        self.full_text = ""            # 全文(含表格文本)
        self.paragraphs = []           # [(idx, style, text)] docx专用
        self.chapters = []             # [(title, start, end, text)] H1章
        self.problem_chapters = {}     # {title: char_count}
        self.abstract_text = ""
        self.conclusion_text = ""
        self.figures = []              # [(anchor_idx, w_cm, h_cm)] docx only
        self.captions_fig = []         # [(no, idx)]
        self.captions_tab = []
        self.refs_fig = set()
        self.refs_tab = set()
        self.eq_numbers = []           # [(no, idx)]
        self.fig_order_violations = [] # [msg] 图题在图之前的反序
        self.ai_appendix_range = None  # (start,end) 字符区间
        self.bib_range = None
        self.restatement_text = ""
        self.margins_cm = None         # dict or None
        self.page_count = None
        self.analysis_chapter_text = ""  # "问题分析"章, 供空洞词检测


def norm_no(prefix, raw):
    """编号归一化: '6-1'/'6.1' -> '6-1' (前缀分册: 图/表/式各自独立)"""
    return prefix + re.sub(r"[.\uFF0E]", "-", raw.strip())


CAPTION_FIG_RE = re.compile(r"^图\s*(\d+(?:[-.]\d+)?)")
CAPTION_TAB_RE = re.compile(r"^表\s*(\d+(?:[-.]\d+)?)")
REF_RE = re.compile(r"(图|表)\s*(\d+(?:[-.]\d+)?)")
EQNUM_RE = re.compile(r"\((\d+(?:\.\d+)?)\)")


# ----------------------------------------------------------------------
# docx 后端
# ----------------------------------------------------------------------
def load_docx(path):
    import docx
    from docx.oxml.ns import qn

    doc = docx.Document(str(path))
    ir = IR()
    ir.kind = "docx"

    paras = doc.paragraphs
    texts = []
    for i, p in enumerate(paras):
        t = p.text.strip()
        style = p.style.name if p.style else ""
        ir.paragraphs.append((i, style, t))
        texts.append(p.text.rstrip())  # 保留原始长度供字符偏移计算

    # 段落 i 在 full_text 中的字符起点(供章节→字符区间换算)
    offsets = []
    acc = 0
    for t in texts:
        offsets.append(acc)
        acc += len(t) + 1
    ir.para_offsets = offsets

    # 表格文本并入全文(AI名/错字可能藏在表内); 并按文档顺序记录每表所属 H1 章
    from docx.text.paragraph import Paragraph as _Para
    tbl_texts = []
    tbl_chapters = []          # 第k个表格所属的 H1 章名
    cur_h1_name = ""
    h1_style_names = set()
    for child in doc.element.body.iterchildren():
        if child.tag == qn("w:p"):
            p = _Para(child, doc)
            stl = p.style.name if p.style else ""
            if "Heading 1" in stl and p.text.strip():
                cur_h1_name = p.text.strip()
        elif child.tag == qn("w:tbl"):
            row0 = []
            tbl_chapters.append(cur_h1_name)
            # 取该表全部文本
            buf = []
            from docx.table import Table as _Tbl
            for row in _Tbl(child, doc).rows:
                for c in row.cells:
                    buf.append(c.text)
                    row0.append(c.text.strip())
            texts_blob = "\n".join(buf)
            tbl_texts.append(texts_blob)

    ir.tbl_chapters = tbl_chapters
    # 表格 blob 内每个表的字符区间(供位置→章节判定)
    tacc = 0
    tbl_spans = []
    for k, blob in enumerate(tbl_texts):
        start = len("\n".join(texts)) + 1 + tacc
        tbl_spans.append((start, start + len(blob), tbl_chapters[k]))
        tacc += len(blob) + 1
    ir.tbl_spans = tbl_spans

    ir.full_text = "\n".join(texts + ["\n".join(tbl_texts)])
    ir.para_text_total = len("\n".join(texts))  # 段落区字符总量(表格区起点)

    # 版心
    try:
        sec = doc.sections[0]
        w = sec.page_width.twips if sec.page_width else None
        l = sec.left_margin.twips if sec.left_margin else 0
        r = sec.right_margin.twips if sec.right_margin else 0
        ir.content_width_cm = (w - l - r) / TWIPS_PER_CM if w else None
        ir.margins_cm = {
            "top": sec.top_margin.cm if sec.top_margin else None,
            "bottom": sec.bottom_margin.cm if sec.bottom_margin else None,
            "left": sec.left_margin.cm if sec.left_margin else None,
            "right": sec.right_margin.cm if sec.right_margin else None,
        }
    except Exception:
        ir.content_width_cm = None
        ir.margins_cm = None

    # 图片几何 + 锚点
    for i, p in enumerate(paras):
        for d in p._p.iter(qn("w:drawing")):
            ext = d.find(".//" + qn("wp:extent"))
            if ext is not None:
                wcm = int(ext.get("cx")) / EMU_PER_CM
                hcm = int(ext.get("cy")) / EMU_PER_CM
                ir.figures.append((i, round(wcm, 1), round(hcm, 1)))

    # 章节切分(H1)
    h1_idx = [(i, t) for i, st, t in ir.paragraphs
              if ("Heading 1" in st) and t]
    ranges = []
    for k, (i, t) in enumerate(h1_idx):
        j = h1_idx[k + 1][0] if k + 1 < len(h1_idx) else len(paras)
        ranges.append((t, i, j))
    ir.h1_ranges = ranges

    def chapter_text(a, b):
        return "\n".join(t for _, _, t in ir.paragraphs[a:b] if t)

    ir.chapters = [(t, a, b, chapter_text(a, b)) for t, a, b in ranges]

    # 关键章节定位
    def find_h1(kw):
        for t, a, b, _ in ir.chapters:
            if kw in t:
                return (a, b)
        return None

    abs_r = find_h1("摘要") or (0, min(40, len(paras)))
    ir.abstract_text = chapter_text(*abs_r)
    conc_r = find_h1("评价") or find_h1("结论") or find_h1("展望")
    ir.conclusion_text = chapter_text(*conc_r) if conc_r else ""
    ana_r = find_h1("问题分析") or find_h1("分析")
    ir.analysis_chapter_text = chapter_text(*ana_r) if ana_r else ""
    rest_r = find_h1("重述")
    ir.restatement_text = chapter_text(*rest_r) if rest_r else ""

    ai_kw = None
    bib_kw = None
    for t, a, b in ranges:
        if ("AI" in t.upper() and ("附录" in t or "使用" in t or "声明" in t)) \
           or ("使用详情" in t):
            ai_kw = (a, b)
        if "参考文献" in t:
            bib_kw = (a, b)
    # 段落索引区间 → full_text 字符区间(表格文本追加在段落区之后, 其偏移必然
    # 落在 [para_text_total, len(full_text)); 附录AI节含表格, 故终点延伸到全文末尾)
    def to_char_span(span):
        if not span:
            return None
        a, b = span
        ca = ir.para_offsets[a]
        cb = ir.para_offsets[b - 1] + len(texts[b - 1]) + 1 if b > a else ca
        return (ca, max(cb, ca))

    ir.ai_appendix_range = to_char_span(ai_kw)
    if ai_kw and ai_kw[1] >= len(paras) - 2:  # AI附录是最后几章时, 覆盖其后的全部内容
        ir.ai_appendix_range = (ir.para_offsets[ai_kw[0]], len(ir.full_text))
    ir.bib_range = to_char_span(bib_kw)

    # 问题X章
    prob_re = re.compile(r"^问题[一二三四五六七八九十1-9]")
    for t, a, b, txt in ir.chapters:
        if prob_re.match(t):
            ir.problem_chapters[t] = len(txt.replace("\n", ""))

    # 图表题注与引用、公式号、图序
    fig_idx_set = {fi[0] for fi in ir.figures}
    prev_was_figure = False
    for i, st, t in ir.paragraphs:
        has_fig = i in fig_idx_set
        if not t:
            prev_was_figure = prev_was_figure or has_fig
            continue
        mF, mT = CAPTION_FIG_RE.match(t), CAPTION_TAB_RE.match(t)
        is_caption = bool(mF or mT) and len(t) <= 60
        if mF and is_caption:
            ir.captions_fig.append((norm_no("图", mF.group(1)), i))
            if not prev_was_figure and not has_fig:
                ir.fig_order_violations.append(
                    "P%d 图题「%s」之前未见图片段(先题后图反序或图片为浮动锚定)" % (i, t[:30]))
            prev_was_figure = False
        elif mT and is_caption:
            ir.captions_tab.append((norm_no("表", mT.group(1)), i))
            prev_was_figure = False
        else:
            for pre, no in REF_RE.findall(t):
                (ir.refs_fig if pre == "图" else ir.refs_tab).add(norm_no(pre, no))
        prev_was_figure = prev_was_figure or has_fig

    for i, st, t in ir.paragraphs:
        tt = t.strip()
        # 仅"独立编号段"(纯公式号, 允许空白/tab)计入重号检测; 行内引用(如 式(6.2))不算
        m_eq = re.fullmatch(r"[\s\u3000\t]*[(（](\d+(?:\.\d+)?)[)）][\s\u3000\t]*", t)
        if m_eq:
            ir.eq_numbers.append((m_eq.group(1), i))
            continue
        for no in EQNUM_RE.findall(t):
            if "." in no:  # 行内出现的公式号仅登记供检索, 不判重
                pass

    return ir


# ----------------------------------------------------------------------
# tex 后端(精简: 编号对账/AI痕迹/文风/公式号/文字校对)
# ----------------------------------------------------------------------
def load_tex(path):
    src = Path(path).read_text(encoding="utf-8", errors="replace")
    ir = IR()
    ir.kind = "tex"
    plain = re.sub(r"%.*", "", src)
    ir.full_text = re.sub(r"\\[a-zA-Z]+(\[[^\]]*\])?(\{[^}]*\})*", " ", plain)

    cap_iter = re.finditer(
        r"\\caption\{[^}]*?(图|表)\s*(\d+(?:[-.]\d+)?)[^}]*\}", plain)
    for m in cap_iter:
        no = norm_no(m.group(1), m.group(2))
        (ir.captions_fig if m.group(1) == "图" else ir.captions_tab).append((no, m.start()))
    for m in re.finditer(r"(?:图|表)~?\\?ref\{([^}]*)\}", plain):
        pass  # label 体系下引用与 caption 自动一致, v1 不做 label 解析
    for m in REF_RE.findall(re.sub(r"\\caption\{[^}]*\}", "", plain)):
        pass
    for m in EQNUM_RE.findall(plain):
        if "." in m:
            ir.eq_numbers.append((m, 0))
    # 手写编号引用(图~N / 表~N)
    body_wo_cap = re.sub(r"\\caption\{[^}]*\}", "", plain)
    for pre, no in REF_RE.findall(body_wo_cap):
        (ir.refs_fig if pre == "图" else ir.refs_tab).add(norm_no(pre, no))

    ir.abstract_text = ""
    m = re.search(r"\\begin\{abstract\}(.*?)\\end\{abstract\}", plain, re.S)
    if m:
        ir.abstract_text = m.group(1)
    return ir


# ----------------------------------------------------------------------
# 检查器
# ----------------------------------------------------------------------
class DocGate:
    def __init__(self, ir, cfg, pdf=None, results=None, problem=None):
        self.ir, self.cfg = ir, cfg
        self.pdf, self.results, self.problem = pdf, results, problem
        self.findings = []

    def add(self, cid, sev, title, details=None):
        self.findings.append(F(cid, sev, title, details))

    def sev(self, key, default):
        """手艺判断类检查的判级来自 yaml `severity` 段; 删掉该段即回落到 default。"""
        v = (self.cfg.get("severity") or {}).get(key)
        return str(v).upper() if v else default

    # ---- 01 图片几何 -------------------------------------------------
    def chk_geometry(self):
        ir = self.ir
        if ir.kind != "docx":
            self.add("01", "SKIP", "tex 后端不做渲染级几何检查(v2)", [])
            return
        if not ir.figures:
            self.add("01", "WARN", "未检测到任何内嵌图片", [])
            return
        limit_w = None
        if getattr(ir, "content_width_cm", None):
            limit_w = ir.content_width_cm - self.cfg["layout"]["margin_safety_cm"]
        bad_w, bad_h = [], []
        for idx, w, h in ir.figures:
            tag = "P%d %.1fcm×%.1fcm" % (idx, w, h)
            if limit_w and w > limit_w:
                bad_w.append("%s 超宽上限%.1fcm" % (tag, limit_w))
            if h > self.cfg["layout"]["figure_max_height_cm"]:
                bad_h.append("%s 纵高超%.0fcm" % (tag, self.cfg["layout"]["figure_max_height_cm"]))
        det = bad_w + bad_h
        if det:
            self.add("01", "FAIL",
                     "插图几何超限 ×%d (超宽%d, 纵高%d)" % (len(det), len(bad_w), len(bad_h)), det)
        else:
            self.add("01", "INFO", "全部 %d 张图几何合规" % len(ir.figures), [])

    # ---- 02 编号对账 -------------------------------------------------
    def chk_numbering(self):
        ir = self.ir
        det = []
        for capl, refs, name in [
                (ir.captions_fig, ir.refs_fig, "图"),
                (ir.captions_tab, ir.refs_tab, "表")]:
            nos = [n for n, _ in capl]
            dup = sorted({n for n in nos if nos.count(n) > 1})
            undef = sorted(refs - set(nos)) if nos else []
            unused = sorted(set(nos) - refs) if nos and ir.kind == "docx" else []
            if dup:
                det += ["%s题注重号: %s" % (name, ",".join(dup))]
            if undef:
                det += ["%s正文引用了不存在的编号: %s" % (name, ",".join(undef))]
            if unused:
                det += ["%s题注未被正文引用(可能漏引或编号体系脱节): %s"
                        % (name, ",".join(unused[:12]))]
        eqs = [n for n, _ in ir.eq_numbers]
        dup_eq = sorted({n for n in eqs if eqs.count(n) > 1})
        if dup_eq:
            det += ["公式编号重复: " + ",".join(dup_eq)]
        if ir.kind == "docx":
            for msg in ir.fig_order_violations:
                det.append(msg)
        if det:
            self.add("02", "FAIL", "图表式编号体系问题 ×%d" % len(det), det)
        else:
            self.add("02", "INFO", "编号对账通过", [])

    # ---- 03 AI 痕迹 --------------------------------------------------
    def chk_ai(self):
        ir, cfg = self.ir, self.cfg["ai_scan"]
        names = cfg["tool_names"]
        text = ir.full_text

        def is_ai_chapter(name):
            u = name.upper()
            return ("AI" in u and ("附录" in name or "使用" in name or "声明" in name)) \
                or "使用详情" in name

        def zone_of(pos):
            """返回 ('exclude'|'bib'|'body', 章名)"""
            if pos < getattr(ir, "para_text_total", 0):
                if ir.ai_appendix_range and \
                        ir.ai_appendix_range[0] <= pos < ir.ai_appendix_range[1]:
                    return ("exclude", "")
                if ir.bib_range and ir.bib_range[0] <= pos < ir.bib_range[1]:
                    return ("bib", "")
                return ("body", "")
            for a, b, ch in getattr(ir, "tbl_spans", []):
                if a <= pos < b:
                    if is_ai_chapter(ch):
                        return ("exclude", ch)
                    if "参考文献" in ch:
                        return ("bib", ch)
                    return ("body", ch)
            return ("body", "")

        hits_body, hits_bib = [], []
        for name in names:
            for m in re.finditer(re.escape(name), text, re.I):
                zone, ch = zone_of(m.start())
                tag = "%s @%s" % (name, ch or "偏移%d" % m.start())
                ctx = text[max(0, m.start() - 18):m.start() + 22].replace("\n", "")
                if zone == "bib":
                    hits_bib.append("%s @文献区 …%s…" % (name, ctx))
                elif zone == "body":
                    hits_body.append("%s …%s…" % (tag, ctx))
        if hits_bib:
            # 官方明文: AI 工具不得列为参考文献条目 → 恒为 FAIL, 不受 severity 影响
            self.add("03", "FAIL", "AI工具名混入参考文献区 ×%d" % len(hits_bib),
                     ["文献条目须是真实可核的出版物, AI 使用情况只放附录声明节: "
                      + "; ".join(sorted(set(hits_bib)))])
        if hits_body:
            ctx = list(dict.fromkeys(hits_body))[:8]
            self.add("03", self.sev("ai_trace_body", "WARN"),
                     "正文命中AI工具名 ×%d" % len(hits_body),
                     ctx + ["人工判断: 是附录 AI 声明的正文残留, 还是确属方法论引用;"
                            " 需披露的使用情况集中到附录 AI 声明节更稳妥"])
        if not (hits_bib or hits_body):
            self.add("03", "INFO", "AI痕迹扫描通过(附录豁免区已排除)", [])

    # ---- 04 摘要对账 + 数量级哨兵 ------------------------------------
    def chk_abstract(self):
        ir = self.ir
        det, warns = [], []
        abs_nums = set(re.findall(r"-?\d+\.(?:\d+)|-?\d+", ir.abstract_text))
        body = ir.full_text[len(ir.abstract_text):] if ir.abstract_text else ir.full_text
        orphan = [n for n in abs_nums
                  if float(n) not in (0,) and n not in body
                  and n.replace("-", "") not in body.replace("-", "")]
        orphan = [n for n in orphan if abs(float(n)) >= 3][:15]
        if orphan:
            warns.append("摘要中以下数字未在正文找到(须能映射到正文表格/报告): "
                         + ", ".join(orphan))
        trig = self.cfg["magnitude"]["ratio_trigger"]
        win = self.cfg["magnitude"]["explain_window_chars"]
        unit = r"(?:[万亿千百])?(?:[个元吨时%兆瓦]|兆瓦时|千瓦时|万千瓦|个百分点|倍|台|个|次|米|秒)*"
        pat = re.compile(
            r"由\s*(-?[\d.,]+)\s*(" + unit + r")\s*"
            r"(降至|提升至|增至|上升到|下降到|改善为|压缩至|减少至)\s*(-?[\d.,]+)"
            r"\s*(" + unit + r")?")
        for m in pat.finditer(ir.abstract_text + "\n" + ir.conclusion_text):
            try:
                a, b = abs(float(m.group(1).replace(",", ""))), abs(float(m.group(4).replace(",", "")))
            except ValueError:
                continue
            # 单位不一致(如 万吨→吨)时, 换算后仍超阈值同样要报
            u1, u2 = m.group(2) or "", m.group(5) or ""
            scale = 1.0
            if "万" in u1 and "万" not in u2:
                scale *= 10000.0
            if "千" in u1 and "千" not in u2:
                scale *= 1000.0
            if b > 0 and a > 0 and max(a * scale, b) / min(a * scale, b) > trig:
                seg = (ir.abstract_text + "\n" + ir.conclusion_text)[m.end():m.end() + win]
                has_expl = bool(re.search(r"因|由于|源于|机制|归因|口径", seg))
                msg = ("数量级跳变 %s%s %s %s%s (>×%d)%s" %
                       (m.group(1), u1 or "(无单位)", m.group(3), m.group(4), u2 or "(无单位)",
                        trig,
                       "，邻近已有机制解释句" if has_expl else
                       "，且窗口内无『因/由于/机制』类解释句——评委将怀疑单位错误"))
                (warns if has_expl else det).append(msg)
        if det or warns:
            self.add("04", "FAIL" if det else "WARN",
                     "摘要对账/数量级哨兵: %d FAIL, %d WARN" % (len(det), len(warns)), det + warns)
        else:
            self.add("04", "INFO", "摘要数字均可映射, 无数量级裸跳变", [])

    # ---- 05 声明白名单 ------------------------------------------------
    def chk_declaration(self):
        ir, cfg = self.ir, self.cfg["declaration"]
        scope = ir.abstract_text + "\n" + ir.conclusion_text
        claims = []
        for c in cfg["strong_claims"]:
            for _ in re.finditer(re.escape(c), scope):
                claims.append(c)
                break
        if not claims:
            self.add("05", "INFO", "摘要/结论无强最优性断言", [])
            return
        ev_src = Path(self.results).read_text(encoding="utf-8", errors="replace") \
            if self.results and Path(self.results).exists() else ""
        fails, warns = [], []
        for c in sorted(set(claims)):
            if ev_src:
                ok = any(e.lower() in ev_src.lower() for e in cfg["evidence_markers"])
                # 提供了证据报告却找不到佐证 → 声明强度越权, 真阻断
                (fails if not ok else warns).append(
                    "强断言「%s」在 RESULTS_REPORT 中无证据标记(%s)"
                    % (c, "/".join(cfg["evidence_markers"][:4])))
            else:
                # 未提供报告无法核验 → 不武断拦截, 但必须提示补跑 G1
                warns.append("强断言「%s」: 未提供 --results, 无法核验证据等级"
                             "(措辞不得高于证据; 请按 paper-gate G1 生成 DECLARATION_WHITELIST)" % c)
        if fails:
            self.add("05", "FAIL", "声明强度越权(有证据报告可查而未获佐证) ×%d" % len(fails), fails + warns)
        elif warns:
            self.add("05", "WARN", "声明强度需人工核对证据等级 ×%d" % len(warns), warns)
        else:
            self.add("05", "INFO", "强断言均有 RESULTS_REPORT 佐证", [])

    # ---- 06 篇幅均衡 ---------------------------------------------------
    def chk_balance(self):
        ir, cfg = self.ir, self.cfg["balance"]
        pat = re.compile(self.cfg["structure"]["problem_title_pattern"])
        probs = {k: v for k, v in ir.problem_chapters.items() if pat.match(k)}
        if len(probs) < cfg["min_problem_chapters"]:
            self.add("06", "SKIP", "问题章识别不足(%d), 跳过均衡审计" % len(probs), [])
            return
        vals = sorted(probs.values())
        med = vals[len(vals) // 2]
        floor = med * cfg["word_count_ratio"]
        thin = {k: v for k, v in probs.items() if v < floor}
        det = ["各问题章字数: " + ", ".join("%s=%d" % kv for kv in probs.items())]
        if thin:
            det += ["低于中位数×%.2f(=%d字): %s" %
                    (cfg["word_count_ratio"], floor,
                     ", ".join("%s=%d" % kv for kv in thin.items()))]
            det += ["人工判断: 最薄的一问是内容真缺(求解流程/中间量/结果解读没写), "
                    "还是题目本身分量就轻。字数比是信号不是目标——"
                    "为消除本条告警而加字属负优化"]
            self.add("06", self.sev("balance", "WARN"),
                     "篇幅失衡提示: %d 个问题章偏薄" % len(thin), det)
        else:
            self.add("06", "INFO", "四问篇幅均衡(中位数 %d 字)" % med, det)

    # ---- 07 跨章重复 ----------------------------------------------------
    def chk_duplicate(self):
        ir, cfg = self.ir, self.cfg["duplicate"]
        chs = [(t, txt) for t, _, _, txt in ir.chapters if len(txt) > 200]
        pairs, total = [], 0
        for i in range(len(chs)):
            for j in range(i + 1, len(chs)):
                ta, tb = chs[i][1], chs[j][1]
                short, long_ = (ta, tb) if len(ta) < len(tb) else (tb, ta)
                sents = [s.strip() for s in re.split(r"[。;;！？\n]", short)
                         if len(s.strip()) >= 12]
                seen = set()
                for s in sents:
                    if s in long_ and s not in seen:
                        seen.add(s)
                        total += len(s)
                        if len(pairs) < cfg["max_report_pairs"]:
                            pairs.append("%s ↔ %s: 「%s…」(%d字)" %
                                         (chs[i][0][:12], chs[j][0][:12], s[:28], len(s)))
        heavy = cfg.get("heavy_total_chars")
        if pairs and heavy and total > heavy:
            lvl, tag = self.sev("duplicate", "WARN"), "重度"
        elif pairs:
            lvl, tag = "WARN", "轻度"
        else:
            lvl = None
        if lvl:
            self.add("07", lvl, "跨章内容%s重复: 累计 %d 字 / %d 对" % (tag, total, len(pairs)),
                     pairs + ["降重属风格取舍: 判断是同一结论在两处各写一遍(宜合并), "
                              "还是后问复用前问的模型构件(宜改为交叉引用而非重述)"])
        else:
            self.add("07", "INFO", "无显著跨章重复", [])

    # ---- 08 文字校对 -----------------------------------------------------
    def chk_typo(self):
        ir, cfg = self.ir, self.cfg["typo"]
        fails, warns = [], []
        for pat in cfg["fail_patterns"]:
            for m in re.finditer(pat, ir.full_text):
                fails.append("…%s…" % ir.full_text[max(0, m.start() - 18):m.end() + 12].replace("\n", ""))
        for pat, note in cfg.get("warn_patterns", []):
            for m in re.finditer(pat, ir.full_text):
                warns.append("「%s」%s @…%s…" % (m.group(0), note,
                             ir.full_text[max(0, m.start() - 14):m.end() + 14].replace("\n", "")))
        fails = list(dict.fromkeys(fails))[:15]
        warns = list(dict.fromkeys(warns))[:10]
        if fails or warns:
            self.add("08", "FAIL" if fails else "WARN",
                     "文字校对: %d 处确定性错误, %d 处可疑" % (len(fails), len(warns)),
                     ["FAIL: " + x for x in fails] + ["WARN: " + x for x in warns])
        else:
            self.add("08", "INFO", "文字校对通过", [])

    # ---- 09 结构模板 + 空洞词 ---------------------------------------------
    def chk_structure(self):
        ir, cfg = self.ir, self.cfg["structure"]
        warns = []
        h1_titles = [t for t, _, _, _ in ir.chapters]
        if not any("假设" in t for t in h1_titles):
            warns.append("缺少『模型假设』一级章节(各赛事模板通常都列此章)")
        if not any("符号" in t for t in h1_titles):
            warns.append("缺少『符号说明』章节")
        style = cfg.get("assumption_style", "numbered")
        hyp_txt = ""
        for t, _, _, txt in ir.chapters:
            if "假设" in t:
                hyp_txt = txt
                break
        if hyp_txt and style == "numbered":
            n_num = len(re.findall(r"假设\s*\d+", hyp_txt))
            if n_num == 0:
                warns.append("assumption_style=numbered 但假设章未用『假设N：』编号格式"
                             "(样式以当届官方模板为准; 与模板一致则可忽略本条)")
            elif not (4 <= n_num <= 8):
                warns.append("假设条数=%d, 样本常见4-8条"
                             "(条数服务于覆盖面——每条假设是否都在正文被引用并影响结论, 比条数重要)" % n_num)
        if cfg.get("each_problem_needs_check_section", True):
            prob_re = re.compile(cfg["problem_title_pattern"])
            h1_titles = [t for t, _, _, _ in ir.chapters]
            check_h1 = re.compile(r"检验|验证")
            for k, (t, a, b, txt) in enumerate(ir.chapters):
                if not prob_re.match(t):
                    continue
                # 序号(问题一/问题1)用于匹配紧随其后的独立"同问检验章"
                seq = re.match(r"(问题[一二三四五六七八九十1-9])", t).group(1)
                has_inline = bool(re.search(r"检验|验证|复算", txt))
                has_sibling = (k + 1 < len(ir.chapters)
                               and ir.chapters[k + 1][0].startswith(seq)
                               and check_h1.search(ir.chapters[k + 1][0]))
                if not (has_inline or has_sibling):
                    warns.append("「%s」未见检验/验证表述(正文内与紧随的『%s检验』章都没找到)"
                                 "——可能真缺检验闭环, 也可能换了措辞(稳健性/对照/回代), 请人工确认"
                                 % (t, seq))
        hollow = [w for w in self.cfg["style"]["buzzwords_warn"]]
        if ir.analysis_chapter_text:
            hits = {w: len(re.findall(w, ir.analysis_chapter_text)) for w in hollow}
            hits = {k: v for k, v in hits.items() if v > 0}
            if sum(hits.values()) >= 5:
                warns.append("问题分析章 AI 套话命中 %s——请核对是否空泛堆砌而未回答"
                             "'要解决什么/为何引入变量/目标与约束'" % hits)
        if cfg.get("check_h3_for_compound", True) and ir.kind == "docx":
            h3_total = sum(1 for _, st, _ in ir.paragraphs if "Heading 3" in st)
            if h3_total == 0:
                warns.append("全文无三级标题: 若某问含≥2个异质模型(预测+调度等), "
                             "拆子小节更清楚(X.2.1预测模型 / X.2.2调度模型); 单一模型的多个步骤不必拆")
        if warns:
            self.add("09", self.sev("structure", "WARN"),
                     "结构形态提示 ×%d" % len(warns), warns)
        else:
            self.add("09", "INFO", "结构模板通过", [])

    # ---- 10 格式合规 -------------------------------------------------------
    def chk_format(self):
        ir, cfg = self.ir, self.cfg
        det, warns, notes = [], [], []
        if getattr(ir, "margins_cm", None):
            notes.append("实测页边距(cm): %s" %
                         {k: round(v, 2) for k, v in ir.margins_cm.items() if v})
        want = cfg["layout"].get("margins_cm")
        if want and ir.margins_cm:
            for side, val in want.items():
                got = ir.margins_cm.get(side)
                if got and abs(got - val) > 0.05:
                    det.append("页边距 %s=%.2fcm ≠ 要求 %.2fcm" % (side, got, val))
        if self.pdf:
            try:
                from pypdf import PdfReader
                n = len(PdfReader(self.pdf).pages)
                ir.page_count = n
                notes.append("PDF 总页数=%d（含附录）" % n)
                mx = cfg["pages"].get("max_main_pages")
                # 篇幅哲学: 内容完整性优先于页数——超限只 WARN 提示压缩冗余,
                # 不做 FAIL 硬阻断(砍检验闭环换页数是负优化)
                if mx and n > mx:
                    warns.append("PDF 总页数 %d > 配置上限 %d —— 建议压缩冗余描述"
                                 "(重复段/过长图/啰嗦学术化表述), 不要删检验闭环与关键数值; "
                                 "若赛事官方有硬性页数要求请更新 yaml pages 段" % (n, mx))
            except Exception as e:
                notes.append("PDF 页数读取失败: %s" % e)
        else:
            notes.append("页数检查: 未提供 --pdf, SKIP(docx 不含分页信息)")
        if det:
            self.add("10", "FAIL", "格式合规问题 ×%d" % len(det), det + notes)
        else:
            self.add("10", "INFO", "格式合规通过", notes)
        if warns:
            self.add("10w", "WARN", "篇幅提示 ×%d" % len(warns), warns)

    # ---- 11 语言去AI化 --------------------------------------------------------
    def chk_style(self):
        ir, cfg = self.ir, self.cfg["style"]
        text, det = ir.full_text, []
        n_chars = max(1, len(text))
        if n_chars < cfg.get("style_min_chars", 1500):
            self.add("11", "SKIP", "文本仅 %d 字(<%d), 密度统计不显著"
                     % (n_chars, cfg["style_min_chars"]), [])
            return
        semis = text.count("；") + text.count(";")
        density = semis / n_chars * 1000
        if density > cfg["semicolon_per_1000"]:
            det.append("分号密度 %.1f/千字 > 阈值 %.1f —— 中文AI文风特征, "
                       "通常是把三四个论点压进一句的产物, 拆成短句与逗号分层更清楚"
                       % (density, cfg["semicolon_per_1000"]))
        compound = re.findall(r"[\u4e00-\u9fa5A-Za-z]{2,10}[—–]{1,2}[\u4e00-\u9fa5A-Za-z]{2,10}[—–]{1,2}[\u4e00-\u9fa5A-Za-z]{2,10}", text)
        if len(compound) > cfg["compound_word_min"]:
            det.append("三段组合词出现 %d 次 > 参考上限 %d (示例: %s) —— 生硬组合词宜拆开叙述"
                       % (len(compound), cfg["compound_word_min"], "、".join(compound[:4])))
        bw_hits = {}
        for w in cfg["buzzwords_warn"]:
            n = len(re.findall(re.escape(w), text))
            if n:
                bw_hits[w] = n
        heavy = {k: v for k, v in bw_hits.items() if v > 3}
        if heavy:
            det.append("AI高频套话超量: %s —— 换成具体动作与量化表述(注意别换成另一批套话)" % heavy)
        if det:
            self.add("11", "WARN", "语言去AI化: %d 项触线" % len(det), det)
        else:
            self.add("11", "INFO", "文风检查通过(分号密度 %.1f/千字)" % density, [])

        # buzzwords_fail 是显式选择: 默认空表; 填了词就真拦
        # (此前它名为 fail 却只发 WARN, 配置与行为不一致)
        banned = [w for w in (cfg.get("buzzwords_fail") or [])
                  if re.search(re.escape(w), text)]
        if banned:
            self.add("11b", "FAIL", "命中 yaml 显式禁用话术 ×%d" % len(banned),
                     ["「%s」" % w for w in banned]
                     + ["本项由 style.buzzwords_fail 配置, 默认空表即不生效——"
                        "填入即表示该赛事明文禁用这些话术"])

    # ---- 12 变量解释完整性 ------------------------------------------------------
    def chk_variables(self):
        ir = self.ir
        det = []
        for pat in self.cfg["variables"]["empty_explain_patterns"]:
            for m in re.finditer(pat, ir.full_text):
                det.append("空解释残骸 @…%s… —— 公式对象的符号未进入文本流, "
                           "读者看不到变量含义; 修复: 用 OMML/文本补齐『其中 α 为…』"
                           % ir.full_text[max(0, m.start() - 16):m.end() + 20].replace("\n", ""))
        det = list(dict.fromkeys(det))[:10]
        if det:
            self.add("12", "FAIL", "变量解释完整性: %d 处空解释" % len(det), det)
        else:
            self.add("12", "INFO", "未发现空解释残骸(注意: OLE公式语义正确性仍需人工对读代码)", [])

    # ---- 13 重述原创度 ------------------------------------------------------------
    def chk_restatement(self):
        ir, cfg = self.ir, self.cfg["restatement"]
        if not (self.problem and ir.restatement_text):
            self.add("13", "SKIP", "未提供 --problem 题面文本或文中无重述章", [])
            return
        prob = Path(self.problem).read_text(encoding="utf-8", errors="replace")
        n = cfg["ngram"]
        grams = {prob[i:i + n] for i in range(len(prob) - n + 1)}
        hit = sum(1 for i in range(len(ir.restatement_text) - n + 1)
                  if ir.restatement_text[i:i + n] in grams)
        ratio = hit / max(1, len(ir.restatement_text) - n + 1)
        if ratio > cfg["overlap_threshold"]:
            self.add("13", "FAIL", "问题重述与原题 n-gram 重合率 %.1f%% > %.0f%%——须自组织语言"
                     % (ratio * 100, cfg["overlap_threshold"] * 100),
                     ["提示: 重述只保留『需解决什么』的转述, 删除背景复述与原句"])
        else:
            self.add("13", "INFO", "重述原创度 %.1f%% 合规" % (ratio * 100), [])

    # ---- 汇总 -----------------------------------------------------------------------
    def run(self):
        for fn in [self.chk_geometry, self.chk_numbering, self.chk_ai,
                   self.chk_abstract, self.chk_declaration, self.chk_balance,
                   self.chk_duplicate, self.chk_typo, self.chk_structure,
                   self.chk_format, self.chk_style, self.chk_variables,
                   self.chk_restatement]:
            try:
                fn()
            except Exception as e:
                self.add(fn.__name__, "WARN", "检查器异常: %r" % (e,))
        return self.report()

    def report(self):
        n_fail = sum(1 for f in self.findings if f.severity == "FAIL")
        n_warn = sum(1 for f in self.findings if f.severity == "WARN")
        n_skip = sum(1 for f in self.findings if f.severity == "SKIP")
        verdict = "REJECTED — 存在 %d 项 FAIL(事实错误或真实性问题), 修复后重跑" % n_fail if n_fail \
            else ("PASS with %d warnings — 手艺判断项待人工裁决" % n_warn if n_warn else "PASS")
        L = []
        L.append("# DocGate 验收报告\n")
        L.append("- 工件: `%s` (%s)" % (getattr(self.ir, "kind", "?"), self._src))
        L.append("- 时间: %s" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        L.append("- **结论: %s**" % verdict)
        L.append("- 阻断能力声明: 仅 FAIL 项阻断提交, 且 FAIL 只覆盖客观事实错误与真实性问题;"
                 " 本报告含 %d 项 SKIP(条件不足未检查)与 %d 项 WARN(篇幅/结构/文风等手艺判断,"
                 " 人工裁决), 均不自动拦截\n"
                 % (n_skip, n_warn))
        order = {"FAIL": 0, "WARN": 1, "INFO": 2, "SKIP": 3}
        for f in sorted(self.findings, key=lambda x: order[x.severity]):
            L.append("## [%s] %s · %s" % (f.cid, f.severity, f.title))
            for d in f.details:
                L.append("- %s" % d)
            L.append("")
        L.append("---\n*规则真源: skills/paper-gate/SKILL.md · 阈值: assets/paper-gate-rules.yaml*")
        return "\n".join(L), n_fail, n_warn

    _src = "?"


# ----------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="DocGate 数模论文交付检查器")
    ap.add_argument("file")
    ap.add_argument("--config", default=str(Path(__file__).with_name("paper-gate-rules.yaml")))
    ap.add_argument("--out", default=None)
    ap.add_argument("--pdf", default=None)
    ap.add_argument("--results", default=None)
    ap.add_argument("--problem", default=None)
    a = ap.parse_args()

    cfg = yaml.safe_load(Path(a.config).read_text(encoding="utf-8"))
    path = Path(a.file)
    if path.suffix.lower() == ".docx":
        ir = load_docx(path)
    elif path.suffix.lower() in (".tex",):
        ir = load_tex(path)
    else:
        print("unsupported file type: %s" % path.suffix)
        sys.exit(2)

    gate = DocGate(ir, cfg, pdf=a.pdf, results=a.results, problem=a.problem)
    gate._src = str(path)
    md, n_fail, n_warn = gate.run()
    out = Path(a.out) if a.out else Path(cfg["report"]["out_default"])
    out.write_text(md, encoding="utf-8")
    print("DocGate -> %s | FAIL=%d WARN=%d" % (out, n_fail, n_warn))
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
