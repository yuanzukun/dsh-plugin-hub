# GateCraft

English | [中文](README.md)

> A gated math-modeling skill suite (9 skills + a DSH preset) for DeepSeek Harness. **No mindless end-to-end automation** — the agent solves and verifies; you think and decide at every stage gate, producing modeling results with your own taste.

## What's Inside

- **9 skills**: `competition-workflow` (five-stage pipeline: stage reports / EDA five questions / verification triad) · `guozhan-paper` (award-paper writing patterns) · `vision-ocr` (problem & reference-paper reading) · `sensitivity-analysis` · `statistical-diagnosis` · `math-modeling-paper` (paper content) · `math-paper-template` (LaTeX typesetting) · `tex-pdf-image-to-word` (convert to Word) · `paper-gate` (delivery acceptance layer + the single source of the repo-wide constraint-tier convention)
- **Loaded on demand**: `competition-workflow/references/` (model-selection decision tree, pre-submission self-check) and `guozhan-paper/references/` (award-paper evidence corpus, page-level samples and counterexamples) stay out of the resident context until needed.
- **assets**: `optimization-playbook` (optimization solve/verify decision tables) · `figure-playbook` (flowchart & figure templates) · `prompt-pack` (14 battle-tested prompts) · `flowchart_gen.py` (spec → drawio generator) · `ocr_batch.py` (concurrent OCR) · `docgate.py` (paper-gate engine) · `official-paper-format.md` (official format source)
- **DSH preset**: `presets/math-modeling/` — paste a contest problem and the workflow starts automatically

## Install

```sh
dsh plugin add Crayonnan/dsh-math-modeling-skills-Gatecraft-
```

Optional: copy `presets/math-modeling/` to `${DSH_HOME:-$HOME}/.dsh/.agent-presets/math-modeling/`, then pick "数学建模模式" in a new session.

## Usage

> Run the competition-workflow pipeline on the problem at [path/attachment].

Flow: read the problem (verify external guides + literature) → data-structure exploration (EDA five questions) → modeling (coherence chain + flowchart spec) → solving (verification triad) → sensitivity / diagnosis → seven-part writing → `docgate.py` mechanical check + human self-check. Stage reports give every downstream number its source; whether to keep iterating or record a limitation honestly is your call.

## Delivery acceptance (`paper-gate` + `docgate.py`)

13 mechanical checks over docx (OOXML) and tex, run against **the file you actually submit**. `FAIL` is now reserved for objectively wrong facts and truthfulness problems (broken cross-references, abstract numbers absent from the body, figures overflowing the text block, empty variable-explanation residue, restatement too close to the prompt); proportionality, structure shape, repetition and prose style report `WARN` for human judgment. Severities live in `paper-gate-rules.yaml`, so changing a contest means editing config, not the script.

## Philosophy

- **Hard constraints only for facts and truthfulness** — official rules, engineering constraints and mechanically verifiable consistency get imperative language, and ideally live in `docgate.py` rather than prose. Craft judgments (length, sentence form, which test to run) are written as "common pitfall + recommended/not-recommended + self-check question". For a strong model, dressing a craft disagreement as a blocking condition doesn't make it stricter; it just invites gaming the metric.
- **Stage reports are not approval gates** — their job is to give the next stage's numbers a source. 2-3 iterations per sub-question is usually enough; log "change → effect → metric" each round.
- **Report first**: every sentence in the paper is derived from facts in the stage reports; sample sentences are never copied
- **Number discipline**: every number traces to a report or code output; zero-drift re-check after reruns
- **Critical verification**: verify external guides item by item, recompute third-party claims, benchmark results against literature
- **Taste from patterns**: the four coherence requirements (R1-R4) each carry "criterion + positive sample (with page) + counterexample (with page)"; award-paper sentences serve as samples, not templates

## Vision (for text-only agents)

Default channel: SiliconFlow `Qwen3-VL` (API key required via env var `SILICONFLOW_API_KEY`, sign up at [cloud.siliconflow.cn/me/models](https://cloud.siliconflow.cn/me/models)). No key is bundled with the plugin — set the env var before use. Local alternative: `qwen-mm-plugins`. Or point `ocr_batch.py` at your own OpenAI-compatible vision model via `BASE_URL`/`MODEL`. Without any vision channel, flowcharts still pass QA through the "spec → drawio/PNG → OCR read-back" loop (`figure-playbook` §4).

## Scope

Battle-tested on **statistical-analysis and optimization/decision problems** (the typical "C" problem). Mechanism/physics-simulation (A) and graph/engineering (B) problems are untested — extend the checklists yourself and contribute back.

## With MathModelAgent

Division of labor, not duplication: its solvers serve as a backend (`mma_exec_python` hooks are pre-reserved), GateCraft is the orchestration & QC layer — **thinking, pivoting and deep participation happen at the stage gates**.

## Layout

```
skills/         9 skills (competition-workflow is the orchestrator)
assets/         playbooks / prompt-pack / docgate.py / generators (synced with skills)
presets/        math-modeling (DSH preset)
index.js + cordis.patch.yml + package.json   dsh bundle packaging
```

## Creation Story (expand)

<details>
<summary>Four papers · three upgrade rounds · every checklist item comes from a real failure or a real award</summary>

**Origin.** The 2023 CUMCM paper C228 (national first prize) shows "coherence" comes from four mechanisms: positioning statements, model-choice motivation chains, the three-part result explanation, and explicit reuse declarations. Our 2026 Huashu Cup C paper proved solving depth can clear the prize bar while figure cross-references go wrong, transition paragraphs go missing, and scope clauses never enter the body. The TipDM Cup C and Greater Bay Area Cup B papers (two second prizes) complete the defect list with seven classes: abstract-body number drift (the "1.87%/99.2%" figures exist nowhere in the body), internally inconsistent table columns, 29 mixed "图表N" captions, leftover "[GPT-5, OpenAI]" annotations, entropy weighting over n=2, AUC reported on 5 positive samples, and misused BH-FDR. The 2025 paper C023 (national first prize, later journal-published) sets the benchmark: seven-part structure per question, two-layer flowcharts, diagnose-before-modeling. GateCraft is the solidification of all these lessons.

**Round 1**: C228's coherence → the R1-R4 requirements + rigor language rules; added stage 0.5 data-structure exploration (EDA five questions, each finding tagged "→ which model design it decides"). A smoke test on the real dataset caught two scope errors in our own paper on the spot.

**Round 2**: the seven defect classes → abstract three-way reconciliation / table-column self-consistency / AI-trace scanning / method-sample-size matching; C023 → seven-part structure + two-layer flowchart spec. Second-hand analyses were verified item by item against primary sources ("PSO grouping", "figures 1-1~1-5", "21.3/28.6" all falsified). OCR accelerated from serial 32B to 8B default + 32B recheck + 4-thread concurrency: 84 pages in ~12 minutes (~6×).

**Round 3**: two full session logs → 14 battle-tested prompts distilled into prompt-pack (each with "when / template / criterion / measured effect").

**Gotchas**: the flowchart QA loop (spec JSON → generator → OCR read-back; κ→k needs Greek-Latin normalization); the DSH preset mount validation discovered `tool-cordis` registers process-global providers — two cordis-family presets cannot coexist in one process, so the preset ships without self-modification tools; the open-source audit separates the private repo from the release snapshot, which passes "no keys / no personal paths / no paper extracts" checks before archiving.

</details>

## License

MIT. Contributions follow one format: `requirement / decidable criterion / positive sample (with page) / counterexample (with page)` — every checklist item must come from a real failure or a real award.
