#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""DocGate 最小回归测试：夹具应产出预期退出码与检查项。
用法: python tests/test_docgate.py   (在仓库根目录或任意位置)
依赖: 先 python -m pip install PyYAML python-docx Pillow
"""
import subprocess
import sys
import tempfile
import os
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
DOC = REPO / "assets" / "docgate.py"
FIX = REPO / "tests" / "make_fixtures.py"

sys.path.insert(0, str(REPO / "tests"))
import make_fixtures  # noqa: E402


def run(docx_path, out_md):
    r = subprocess.run(
        [sys.executable, str(DOC), str(docx_path), "--out", out_md],
        capture_output=True, text=True)
    report = Path(out_md).read_text(encoding="utf-8")
    return r.returncode, report


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    return cond


def sev_of(report):
    """从报告标题行提取 [(cid, severity)], 用于锁定判级基线。"""
    import re
    return re.findall(r"^## \[(\w+)\] (FAIL|WARN|INFO|SKIP) ·", report, re.M)


def main():
    tmp = tempfile.mkdtemp()
    clean = os.path.join(tmp, "pass_clean.docx")
    dirt = os.path.join(tmp, "fail_dirty.docx")
    make_fixtures.build(clean, False)
    make_fixtures.build(dirt, True)

    ok = True

    # --- 夹具1: 干净文档 -> exit 0, 无 FAIL ---
    code, rep_clean = run(clean, os.path.join(tmp, "r_pass.md"))
    ok &= check("clean exits 0", code == 0)
    ok &= check("clean 无 FAIL", not [c for c, s in sev_of(rep_clean) if s == "FAIL"])

    # --- 夹具2: 脏文档 -> exit 1, 关键检查项命中 ---
    code, rep = run(dirt, os.path.join(tmp, "r_fail.md"))
    ok &= check("dirty exits 1", code == 1)
    ok &= check("[02] 编号对账 FAIL(引用图9/表1不存在)", "[02] FAIL" in rep)
    ok &= check("[03] AI痕迹 FAIL(文献区 DeepSeek)", "混入参考文献区" in rep)
    ok &= check("[04] 数量级哨兵(300万吨→5吨)", "数量级跳变" in rep)
    ok &= check("[05] 强断言无证据报告时 WARN 不误杀", "[05] WARN" in rep)
    ok &= check("[08] 文字校对 FAIL(双标点/空解释占位)", "[08] FAIL" in rep)
    ok &= check("阻断能力声明存在于报告头", "阻断能力声明" in rep)

    # --- 夹具3: 提供无佐证的 results 报告 -> [05] 应升格 FAIL ---
    fake_results = os.path.join(tmp, "RESULTS.md")
    open(fake_results, "w", encoding="utf-8").write("# RESULTS\n\n无任何证据内容。\n")
    r = subprocess.run(
        [sys.executable, str(DOC), str(dirt),
         "--results", fake_results, "--out", os.path.join(tmp, "r_fail2.md")],
        capture_output=True, text=True)
    rep2 = Path(os.path.join(tmp, "r_fail2.md")).read_text(encoding="utf-8")
    ok &= check("[05] 有报告但无佐证 -> 升格 FAIL", "[05] FAIL" in rep2)

    # --- severity 分级: 手艺判断降 WARN, 但必须仍以 WARN 出现(不是消失) ---
    ok &= check("[06] 篇幅均衡 降为 WARN", "[06] WARN" in rep)
    ok &= check("[09] 结构模板 降为 WARN", "[09] WARN" in rep)
    ok &= check("[06] 不再以 FAIL 阻断", "[06] FAIL" not in rep)
    ok &= check("[09] 不再以 FAIL 阻断", "[09] FAIL" not in rep)
    ok &= check("[03] 拆分: 文献区命中仍 FAIL", "[03] FAIL" in rep)
    ok &= check("[03] 拆分: 正文命中降 WARN", "[03] WARN" in rep)

    # --- severity 必须走 yaml 数据(改配置即改判级, 无需改 Python) ---
    import shutil
    import yaml
    cfg_src = REPO / "assets" / "paper-gate-rules.yaml"
    cfg_alt = Path(tmp) / "rules_balance_fail.yaml"
    shutil.copy(cfg_src, cfg_alt)
    data = yaml.safe_load(cfg_alt.read_text(encoding="utf-8"))
    data.setdefault("severity", {})["balance"] = "fail"
    cfg_alt.write_text(yaml.safe_dump(data, allow_unicode=True), encoding="utf-8")
    subprocess.run(
        [sys.executable, str(DOC), str(dirt), "--config", str(cfg_alt),
         "--out", os.path.join(tmp, "r_sev.md")],
        capture_output=True, text=True)
    rep3 = Path(os.path.join(tmp, "r_sev.md")).read_text(encoding="utf-8")
    ok &= check("yaml severity.balance=fail -> [06] 升回 FAIL", "[06] FAIL" in rep3)

    # --- 判级基线锁定(约束分级改造后重标定的基线) ---
    # 这里变红 = 有检查项被挪了判级, 或从报告里消失了(降级必须仍以 WARN 出现)
    fail_dirty = sorted({c for c, s in sev_of(rep) if s == "FAIL"})
    warn_dirty = sorted({c for c, s in sev_of(rep) if s == "WARN"})
    warn_clean = sorted({c for c, s in sev_of(rep_clean) if s == "WARN"})
    ok &= check("基线 dirty FAIL = 02,03,04,08,12 (实得 %s)" % ",".join(fail_dirty),
                fail_dirty == ["02", "03", "04", "08", "12"])
    ok &= check("基线 dirty WARN = 01,03,05,06,09 (实得 %s)" % ",".join(warn_dirty),
                warn_dirty == ["01", "03", "05", "06", "09"])
    ok &= check("基线 clean WARN = 04,09 (实得 %s)" % ",".join(warn_clean),
                warn_clean == ["04", "09"])

    print("\n%s" % ("ALL TESTS PASSED" if ok else "SOME TESTS FAILED"))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
