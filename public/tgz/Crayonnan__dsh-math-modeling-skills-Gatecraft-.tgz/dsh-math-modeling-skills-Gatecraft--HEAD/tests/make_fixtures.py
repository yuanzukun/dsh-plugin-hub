#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成 DocGate 回归夹具：pass_clean.docx(应 0 FAIL) / fail_dirty.docx(应多 FAIL)
用法: python make_fixtures.py <输出目录>
"""
import sys
import os
import tempfile
import docx
from docx.shared import Cm
from PIL import Image


def build(out_path, dirty):
    d = docx.Document()
    tmpimg = os.path.join(tempfile.mkdtemp(), "f.png")
    # dirty 用超宽画布比例模拟大尺寸图; 插入宽度才是判定依据
    Image.new("RGB", (900, 400), "white").save(tmpimg)

    d.add_heading("摘要", level=1)
    if dirty:
        d.add_paragraph(
            "本文研究调度问题。针对问题一建立模型求解，成本由300万吨降至5吨；"
            "所求调度方案为全局最优。针对问题二，效率提升10.5%。")
    else:
        d.add_paragraph(
            "本文研究一般优化问题。针对问题一，采用模型A求解，成本下降12.3%；"
            "针对问题二，采用模型B求解，延迟效率提升8.5%，因容量重分配所致。")
    d.add_paragraph("关键词：优化；调度；检验")

    d.add_heading("问题重述", level=1)
    d.add_paragraph("题目要求建立模型解决两个子问题并给出方案与检验。")

    d.add_heading("模型的假设", level=1)
    for i in range(1, 5):
        d.add_paragraph("假设%d：系统参数在调度期内保持恒定。" % i)

    d.add_heading("符号说明", level=1)
    t = d.add_table(rows=2, cols=3)
    t.style = "Table Grid"
    for j, h in enumerate(["符号", "说明", "单位"]):
        t.rows[0].cells[j].text = h
    for j, v in enumerate(["x", "决策变量", "个"]):
        t.rows[1].cells[j].text = v

    # ---- 问题一 ----
    d.add_heading("问题一：基础优化", level=1)
    if dirty:
        d.add_paragraph("本问以最小化总成本为目标，目标函数如下，")
        d.add_paragraph("(1.1)")
        d.add_paragraph("其中、、分别为任务变量与系数。约束如下，")
        d.add_paragraph("(1.1)")
        d.add_paragraph("求解得到方案，，结果满意。")
    else:
        d.add_paragraph("本问以最小化总成本为目标，目标函数如下，")
        d.add_paragraph("(1.1)")
        d.add_paragraph("其中 x 为开工变量取值0或1，c 为单位成本系数。约束如下，")
        d.add_paragraph("(1.2)")
        p = d.add_paragraph()
        p.add_run().add_picture(tmpimg, width=Cm(12))
        d.add_paragraph("图 1-1方案对比")
        d.add_paragraph("求解采用分支定界，最优性间隙为百分之二。方案对比如图1-1所示，"
                        "结果如表1-1所示。")
    d.add_heading("问题一检验", level=1)
    d.add_paragraph("对解进行可行性回代，全部约束零违例；独立复算一致。")

    # ---- 问题二 ----
    d.add_heading("问题二：扩展调度", level=1)
    if dirty:
        d.add_paragraph("本问扩展迁移决策。如表1所示，结果很好。")
        d.add_paragraph("表 1-1指标")
    else:
        d.add_paragraph("本问引入跨区迁移决策，承袭式(1.1)，新增带宽约束。"
                        "贪心构造加局部搜索求解，块级精确对照间隙百分之二。"
                        "结果如表1-1所示。")
        d.add_paragraph("表 1-1两问指标汇总")
    t2 = d.add_table(rows=2, cols=2)
    t2.style = "Table Grid"
    t2.rows[0].cells[0].text = "方案"
    t2.rows[0].cells[1].text = "净成本/元"
    t2.rows[1].cells[0].text = "优化后"
    t2.rows[1].cells[1].text = "-5"
    d.add_heading("问题二检验", level=1)
    d.add_paragraph("五个到达块逐一重解混合整数规划，块级间隙均不高于百分之二。")

    # ---- 问题三（dirty 时过薄制造篇幅失衡已难: 三问中位数门槛, 这里保持均衡结构）----
    d.add_heading("问题三：联合优化", level=1)
    if dirty:
        d.add_paragraph("本问联合前两问。参考文献DeepSeek-V4辅助了计算。"
                        "如图9所示效果很好，细节略。")
    else:
        d.add_paragraph("本问统一前两问的决策变量做联合权衡，交替迭代五轮后各轮改善量"
                        "单调递减并满足终止准则。检验方面，压力场景下全部约束保持可行，"
                        "灵敏度验证表明结论稳健。")
    d.add_heading("参考文献", level=1)
    if dirty:
        d.add_paragraph("[1] 张三, 优化方法, 出版社, 2024.")
        d.add_paragraph("[2] DeepSeek, DeepSeek-V4, 深度求索, 2025.")
    else:
        d.add_paragraph("[1] 张三, 优化方法, 出版社, 2024.")

    d.save(out_path)


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp()
    os.makedirs(out, exist_ok=True)
    clean = os.path.join(out, "pass_clean.docx")
    dirt = os.path.join(out, "fail_dirty.docx")
    build(clean, False)
    build(dirt, True)
    print(clean)
    print(dirt)
