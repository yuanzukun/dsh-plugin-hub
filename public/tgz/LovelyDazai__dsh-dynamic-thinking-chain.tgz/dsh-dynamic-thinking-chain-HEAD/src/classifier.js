/**
 * dynamic-thinking-chain — 难度评分与推理等级映射(纯逻辑, 无副作用, 可单测)。
 *
 * 核心思想: 把「当前这一步在做什么」量化成 0~1 的难度分, 再映射到
 * DeepSeek 的推理等级 off / low / high / max:
 *   - 大任务的「规划/拆分」步 → 抬分(至少 planningMinLevel)
 *   - 拆出来的小任务 → 按小任务自己的文本长度 + 关键词打分
 *   - 工具报错(调试中) → 抬分, 出错越多思考越深
 *   - 子代理(subagent) → 按它收到的子任务描述独立打分
 */

/** DeepSeek 支持的推理等级, 从低到高。 */
export const EFFORTS = ['off', 'low', 'high', 'max']

/** 所有默认配置。 */
export const DEFAULTS = Object.freeze({
  enabled: true,
  /** 基础难度分(普通执行类步骤的起点)。 */
  baseScore: 0.18,
  /** 难度分 < offThreshold → 完全关闭思考(只对极琐碎的小任务)。0 表示永不 off。
   * 注意: DeepSeek 会话中途关闭思考会触发 INVALID_REQUEST(reasoning_content 必须传回),
   * 因此 off 只会在会话第一条请求(尚无助手思考内容)时使用, 见 index.js。 */
  offThreshold: 0,
  /** 难度分 < lowThreshold → low。 */
  lowThreshold: 0.30,
  /** 难度分 < highThreshold → high, 否则 max。 */
  highThreshold: 0.60,
  /** 规划/拆分步骤的加分。 */
  planningBias: 0.18,
  /** 规划/拆分步骤的最低等级(low/high/max)。 */
  planningMinLevel: 'high',
  /** 每个工具错误的加分。 */
  errorBias: 0.18,
  /** 工具错误加分的上限。 */
  maxErrorBias: 0.34,
  /** 子代理(subagent)的加分。 */
  depthBias: 0.05,
  /** 任务文本长度加分阶梯(取命中的最大一档)。 */
  lengthSteps: [
    { chars: 120, bias: 0.04 },
    { chars: 500, bias: 0.10 },
    { chars: 2000, bias: 0.18 },
  ],
  /** 困难关键词: 每个命中 +hardWeight, 累计不超过 hardCap。 */
  hardWeight: 0.22,
  hardCap: 0.45,
  /** 中等关键词: 每个命中 +mediumWeight, 累计不超过 mediumCap。 */
  mediumWeight: 0.10,
  mediumCap: 0.20,
  /** 简单关键词: 每个命中 -easyWeight, 累计最多减 easyCap。 */
  easyWeight: 0.08,
  easyCap: 0.25,
  /** 参与打分的最长任务文本(字符)。 */
  maxTextChars: 4000,
  /** 调试: 设 true 才用 console.log 输出每次决策细节(默认静默)。 */
  debug: false,

  /** 困难任务关键词(设计/排查/性能/并发/安全/算法/迁移/论文...)。 */
  hardKeywords: [
    '设计', 'design', '架构', 'architecture', '方案', '重构', 'refactor',
    '迁移', 'migrat', '兼容', 'compatib', '排查', '根因', 'root cause',
    'troubleshoot', '调试', 'debug', '性能', 'performance', '优化', 'optimiz',
    '瓶颈', 'bottleneck', '并发', 'concurren', '多线程', 'multithread',
    'thread', '异步', 'async', '死锁', 'deadlock', '竞态', 'race',
    '内存泄漏', 'memory leak', '泄漏', 'leak', '分布式', 'distributed',
    '集群', 'cluster', '微服务', 'microservice', '大数据', '大规模', 'large-scale',
    '高可用', '容灾', '容错', 'fault-toleran', '幂等', 'idempoten', '回滚', 'rollback',
    '事务', 'transaction', '一致性', 'consisten', '压测', 'load test', '基准', 'benchmark',
    '安全', 'security', '漏洞', 'vulnerab', '注入', 'injection', '加密', 'encrypt',
    '鉴权', '认证', 'auth', '审计', 'audit', '审查', 'review',
    '算法', 'algorithm', '复杂度', 'complexity', '递归', 'recursion',
    '动态规划', 'dynamic programming', '图论', 'graph', '机器学习',
    '训练', '微调', 'fine-tun', '量化', 'quantiz', '深度学习', '神经网络',
    'neural', '推理优化', 'RAG', '检索增强', '向量', 'embedding',
    '编译', 'compil', '解析器', 'parser', '正则', 'regex', '状态机',
    'state machine', '语法树', 'AST', '字节码', 'bytecode', '汇编', 'assembly',
    '逆向', 'reverse', '脱壳', '内核', 'kernel', '驱动', 'driver', '底层', 'low-level',
    '网络协议', 'protocol', '抓包', 'packet', '证明', '定理', 'theorem', '推导', 'derive',
    '论文', 'thesis', 'paper', '考试', 'exam', '精读', '答辩',
    '从零实现', 'from scratch', '完整实现', '生产级', 'production',
    '全栈', 'full-stack', '端到端', 'end-to-end', 'e2e',
    '复杂', 'complex', '棘手', 'tricky', '困难', 'difficult', '严谨', 'rigorous',
    '原理', '机制', 'mechanism', '分析', 'analyz', '剖析', '定位', 'locate',
    '诊断', 'diagnos', '隔离', 'isolation', '缓存一致性', '跨进程', '进程间',
    'ipc', '序列化', 'serializ',
  ],
  /** 中等任务关键词(修改/查询/测试/部署/解释...)。 */
  mediumKeywords: [
    '修改', 'modify', '调整', 'adjust', '更新', 'update', '升级', 'upgrade',
    '增加', '添加', '新增', 'add', '删除', '移除', 'remove', 'delete',
    '替换', 'replace', '重命名', 'rename', '移动', 'move',
    '修复', 'fix', '修补', 'patch', '完善', '增强', 'enhance', '扩展', 'extend',
    '封装', '抽取', '提取', 'extract', '拆分', '合并', 'merge', '整合', 'integrat',
    '查询', '搜索', '检索', '查找', 'search', 'query', 'find', '读取', 'read', '浏览', 'browse',
    '总结', '概括', '归纳', 'summar', '整理', 'organiz', '梳理',
    '翻译', 'translate', '转换', 'convert', '解析', 'parse', '格式化', 'format',
    '生成', 'generate', '导出', 'export', '导入', 'import',
    '测试', 'test', '验证', 'verify', '检查', 'check', '对比', 'compare',
    '统计', 'count', '收集', 'collect', '文档', 'document', '注释', 'comment', '说明',
    '配置', 'configure', '部署', 'deploy', '安装', 'install', '环境', 'environment',
    '依赖', 'dependen', '编写', '实现', 'implement', '开发', 'develop', '构建', 'build',
    '报错', '错误', 'error', '失败', 'fail', '异常', 'exception', '问题', 'issue',
    '怎么', '为什么', '如何', '原因', 'cause', 'bug', '缺陷', 'defect',
    '崩溃', 'crash', '超时', 'timeout', '日志', 'log', '监控', 'monitor',
    '重启', 'restart', '备份', 'backup', '恢复', 'restore', '清理', 'clean',
    '规范', 'convention', '风格', 'style',
  ],
  /** 简单任务关键词(命中会降分)。 */
  easyKeywords: [
    '简单', 'simpl', '轻松', '快速', 'quick', '随便', '随意', '小改', 'minor',
    '一行', 'one-line', '单行', '最小', 'minimal', '轻量', 'lightweight',
    '简版', '简化', '演示', 'demo', '打印', 'print', 'hello',
    '复制粘贴', 'copy-paste', '照着', '照抄', '模仿',
    '越简单越好', '不要过度设计', '随便写', '草稿', 'draft', '占位', 'placeholder',
    '一句话', 'one sentence', '简述', 'brief', '大概', '差不多',
    '名字', '命名', '起名', '标题', 'title',
  ],
})

/** 从等级名取档位序号。 */
export function rankLevel(level) {
  const index = EFFORTS.indexOf(level)
  return index < 0 ? 0 : index
}

const isFiniteNumber = (value) => typeof value === 'number' && Number.isFinite(value)
const clamp01 = (value) => Math.min(1, Math.max(0, value))
const toInt = (value, fallback) => (Number.isSafeInteger(value) && value > 0 ? value : fallback)
const toStrArray = (value, fallback) => (Array.isArray(value)
  ? [...new Set(value.filter((item) => typeof item === 'string' && item.length > 0))]
  : [...fallback])

/**
 * 合并用户配置与默认值: 未知键忽略、类型错误回退默认、数值夹紧。
 * 返回的 cfg 对象是决策期唯一使用的配置快照。
 */
export function resolveConfig(raw) {
  const src = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {}
  const d = DEFAULTS
  const num = (key, min, max) => {
    const value = src[key]
    return isFiniteNumber(value) ? Math.min(max, Math.max(min, clamp01(value))) : d[key]
  }
  const lengthSteps = Array.isArray(src.lengthSteps)
    ? src.lengthSteps
      .filter((step) => step && isFiniteNumber(step.chars) && step.chars > 0 && isFiniteNumber(step.bias))
      .map((step) => ({ chars: Math.floor(step.chars), bias: clamp01(step.bias) }))
      .sort((a, b) => b.chars - a.chars)
    : d.lengthSteps
  const planningMinLevel = EFFORTS.includes(src.planningMinLevel) && src.planningMinLevel !== 'off'
    ? src.planningMinLevel
    : d.planningMinLevel
  const cfg = {
    enabled: typeof src.enabled === 'boolean' ? src.enabled : d.enabled,
    baseScore: num('baseScore', 0, 1),
    offThreshold: num('offThreshold', 0, 1),
    lowThreshold: num('lowThreshold', 0, 1),
    highThreshold: num('highThreshold', 0, 1),
    planningBias: num('planningBias', 0, 1),
    planningMinLevel,
    errorBias: num('errorBias', 0, 1),
    maxErrorBias: num('maxErrorBias', 0, 1),
    depthBias: num('depthBias', 0, 1),
    lengthSteps,
    hardWeight: num('hardWeight', 0, 1),
    hardCap: num('hardCap', 0, 1),
    mediumWeight: num('mediumWeight', 0, 1),
    mediumCap: num('mediumCap', 0, 1),
    easyWeight: num('easyWeight', 0, 1),
    easyCap: num('easyCap', 0, 1),
    maxTextChars: toInt(src.maxTextChars, d.maxTextChars),
    debug: typeof src.debug === 'boolean' ? src.debug : d.debug,
    hardKeywords: toStrArray(src.hardKeywords, d.hardKeywords),
    mediumKeywords: toStrArray(src.mediumKeywords, d.mediumKeywords),
    easyKeywords: toStrArray(src.easyKeywords, d.easyKeywords),
  }
  // 保证阈值顺序: off <= low <= high
  cfg.offThreshold = Math.min(cfg.offThreshold, cfg.lowThreshold)
  cfg.lowThreshold = Math.min(cfg.lowThreshold, cfg.highThreshold)
  return cfg
}

const REGEX_SPECIAL = /[.*+?^$()|[]\]/g
const escapeRegex = (text) => text.replace(REGEX_SPECIAL, '\$&')
const SHORT_ASCII = /^[a-z]{1,4}$/

/** 把一个关键词编译成匹配器(短英文用词边界, 其余用子串)。 */
function compileKeyword(keyword) {
  const kw = keyword.toLowerCase().replace(/s+/g, ' ').trim()
  if (kw.length === 0) return null
  if (SHORT_ASCII.test(kw)) return { re: new RegExp('\b' + escapeRegex(kw)), kw }
  return { re: null, kw, needle: kw }
}

const matcherCache = new WeakMap()
function matchersFor(keywords) {
  let cached = matcherCache.get(keywords)
  if (!cached) {
    cached = keywords.map(compileKeyword).filter(Boolean)
    matcherCache.set(keywords, cached)
  }
  return cached
}

/** 在规范化(小写、空白折叠)文本上统计某个关键词档位命中的不同关键词个数。 */
function hitCount(matchers, text) {
  let hits = 0
  for (const matcher of matchers) {
    if (matcher.re ? matcher.re.test(text) : text.includes(matcher.needle)) hits++
  }
  return hits
}

const fold = (text) => text.replace(/s+/g, ' ')

/**
 * 对一步任务打分。
 * @param {object} cfg  resolveConfig 的返回值
 * @param {object} input { text, errorCount, depth, planning }
 * @returns {{score: number, reasons: string[], level: string, planning: boolean}}
 */
export function scoreTask(cfg, input = {}) {
  const text = fold(String(input.text ?? '').slice(0, cfg.maxTextChars)).toLowerCase()
  const reasons = []
  let score = cfg.baseScore
  reasons.push('base ' + score.toFixed(2))

  // 长度阶梯: 只取命中的最大一档
  for (const step of cfg.lengthSteps) {
    if (text.length >= step.chars) {
      score += step.bias
      reasons.push('length>=' + step.chars + ' +' + step.bias.toFixed(2))
      break
    }
  }

  // 关键词三档
  const hard = hitCount(matchersFor(cfg.hardKeywords), text)
  if (hard > 0) {
    const gain = Math.min(hard * cfg.hardWeight, cfg.hardCap)
    score += gain
    reasons.push('hard x' + hard + ' +' + gain.toFixed(2))
  }
  const medium = hitCount(matchersFor(cfg.mediumKeywords), text)
  if (medium > 0) {
    const gain = Math.min(medium * cfg.mediumWeight, cfg.mediumCap)
    score += gain
    reasons.push('medium x' + medium + ' +' + gain.toFixed(2))
  }
  const easy = hitCount(matchersFor(cfg.easyKeywords), text)
  if (easy > 0) {
    const gain = Math.min(easy * cfg.easyWeight, cfg.easyCap)
    score -= gain
    reasons.push('easy x' + easy + ' -' + gain.toFixed(2))
  }

  // 错误信号
  const errors = Math.max(0, Number(input.errorCount) || 0)
  if (errors > 0) {
    const gain = Math.min(errors * cfg.errorBias, cfg.maxErrorBias)
    score += gain
    reasons.push('errors x' + errors + ' +' + gain.toFixed(2))
  }

  // 子代理
  if (Number(input.depth) > 0) {
    score += cfg.depthBias
    reasons.push('subagent +' + cfg.depthBias.toFixed(2))
  }

  // 规划/拆分步
  if (input.planning) {
    score += cfg.planningBias
    reasons.push('planning +' + cfg.planningBias.toFixed(2))
  }

  score = clamp01(score)
  return { score: Math.round(score * 100) / 100, reasons, level: effortForScore(cfg, score) }
}

/** 难度分 → 推理等级。 */
export function effortForScore(cfg, score) {
  if (cfg.offThreshold > 0 && score < cfg.offThreshold) return 'off'
  if (score < cfg.lowThreshold) return 'low'
  if (score < cfg.highThreshold) return 'high'
  return 'max'
}

/**
 * 完整决策: 打分 → 分级 → 规划步保底。
 * @returns {{score: number, level: string, reasons: string[]}}
 */
export function classifyStep(cfg, input = {}) {
  const { score, reasons, level } = scoreTask(cfg, input)
  let final = level
  if (input.planning && score >= cfg.lowThreshold && rankLevel(level) < rankLevel(cfg.planningMinLevel)) {
    final = cfg.planningMinLevel
    reasons.push('planning floor -> ' + final)
  }
  return { score, level: final, reasons }
}

/**
 * 在模型实际支持的等级里挑一个: 优先同级, 否则取不高于目标的最接近档,
 * 再退而取高于目标的最近档; 模型不支持推理时返回 undefined。
 */
export function pickSupported(level, efforts) {
  if (!Array.isArray(efforts) || efforts.length === 0) return undefined
  if (efforts.includes(level)) return level
  const want = rankLevel(level)
  for (let i = want; i >= 0; i--) if (efforts.includes(EFFORTS[i])) return EFFORTS[i]
  for (let i = want + 1; i < EFFORTS.length; i++) if (efforts.includes(EFFORTS[i])) return EFFORTS[i]
  return undefined
}
