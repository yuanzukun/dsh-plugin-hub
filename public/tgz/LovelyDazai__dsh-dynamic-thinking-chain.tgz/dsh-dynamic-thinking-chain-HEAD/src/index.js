/**
 * dynamic-thinking-chain — DSH 插件入口。
 *
 * 挂点: agent/request waterfall(prepend, 最外层)。每次模型请求前:
 *   1. 从 agent 会话事件里收集「当前子任务」信号:
 *      - todo/write   → dsh 拆分出来的任务清单, 取 in_progress 的小任务
 *      - user/message → 最新的人类指令(主任务 / 新指令)
 *      - tool/result  → 工具报错次数(调试信号)
 *      - turn/step    → 是否是本会话第一步(规划/拆分大任务)
 *      - options.subagentDepth → 是否是子代理(大任务拆出的小代理)
 *   2. classifier 打分 → 映射 off/low/high/max
 *   3. 用 llm.resolveModelInfo 校验模型真实支持的等级后改写 reasoningEffort
 *   4. 任何一步失败都原样放行(插件永远不能弄坏请求)
 *
 * 安全性:
 *   - 不声明 inject(除 Settings 段外不依赖任何服务在挂载期存在)
 *   - 决策期服务全部惰性获取, 失败即放弃改写
 *   - 模型不支持推理时不注入等级, 避免 UNSUPPORTED_REASONING_EFFORT
 */
import { resolveConfig, classifyStep, pickSupported, EFFORTS } from './classifier.js'

export const name = 'dynamic-thinking-chain'
export const inject = []

/** 每个 (provider, model) 的支持等级查询缓存。 */
const supportCache = new Map()

export function apply(ctx, config) {
  // 配置快照引用: 设置面板写入时整体替换 cfg, 决策期永远读最新。
  const liveRef = { cfg: resolveConfig(config) }

  // 可选: 注册设置面板段(需要 schemastery + dsh-settings 两个包时可拿到 GUI 设置)。
  tryInstallSettingsSection(ctx, liveRef)

  // 增量跟踪每个会话的信号(user 任务文本 / todo 小任务 / 工具错误)。
  ctx.on('session/event', trackEvent)

  // agent/request 是每次模型请求前的配置瀑布; prepend 保证我们是最外层,
  // 即 next() 之后拿到的是最终路由(含会话模型选择的默认 max), 我们再按难度改写。
  ctx.on('agent/request', async (payload, next) => {
    const resolved = await next()
    try {
      const cfg = liveRef.cfg
      if (!cfg.enabled) return resolved
      const agent = payload && payload.agent
      const session = agent && agent.session
      if (!session) return resolved
      const provider = resolved && resolved.provider
      const model = resolved && resolved.model
      if (!provider || !model) return resolved

      const { decision, signals } = classifyRequest(agent, payload, stateFor(session), cfg)
      const efforts = await supportedEfforts(ctx, provider, model, payload && payload.signal)
      if (!efforts) return resolved
      const chosen = pickSupported(decision.level, efforts)
      if (!chosen) return resolved
      if (cfg.debug) {
        console.log('[dtc-debug] t' + payload.turn + '/s' + payload.step
          + (signals.activeCount ? ' active=' + signals.activeCount : '')
          + ' text=' + JSON.stringify(String(signals.text).slice(0, 90))
          + ' errs=' + signals.errorCount
          + ' depth=' + signals.depth
          + ' planning=' + signals.planning
          + ' score=' + decision.score + ' => ' + chosen
          + ' (current=' + String(resolved.reasoningEffort) + ')'
          + ' [' + decision.reasons.join(' | ') + ']')
      }
      if (chosen === resolved.reasoningEffort) return resolved

      return { ...resolved, reasoningEffort: chosen }
    } catch (error) {
      warnOnce(ctx, 'decision failed, keeping original config: ' + String(error && error.message || error))
      return resolved
    }
  }, { prepend: true })
}

let warnedOnce = false
function warnOnce(ctx, message) {
  if (warnedOnce) return
  warnedOnce = true
  try {
    ctx.logger.warn('[dynamic-thinking-chain] ' + message)
  } catch {
    // 日志不可用时静默
  }
}

// ---------------------------------------------------------------------------
// 信号收集
// ---------------------------------------------------------------------------

/** 从消息里提取纯文本(兼容 string 与 content block 数组)。 */
function extractText(message) {
  const content = message && message.content
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return ''
  let out = ''
  for (const block of content) {
    if (block && block.type === 'text' && typeof block.text === 'string') {
      out += block.text + '\n'
    }
  }
  return out
}

/** 判断一个 tool/result 事件是否失败。 */
function isErrorResult(data) {
  if (!data) return false
  const message = data.message
  if (data.isError === true || (message && message.isError === true)) return true
  if (Array.isArray(message && message.content)) {
    for (const block of message.content) {
      if (block && block.type === 'tool-result' && block.isError === true) return true
    }
  }
  return false
}

/**
 * 每个会话的增量信号状态, 由 session/event 维护。
 *
 * 为什么不用「往回扫会话事件」: 会话内存事件里包含大量流式 chunk 与表面
 * 消息(单次请求可积累数百条), 从尾部扫固定窗口会永远扫不到几轮之前的
 * 任务文本。增量跟踪每条事件恰好处理一次, 与事件总量无关。
 */
const states = new Map()

/** 取一份 todo 清单里所有 in_progress 条目的文本。 */
function activeTodoTexts(todos) {
  if (!Array.isArray(todos)) return ''
  const active = []
  for (const todo of todos) {
    if (todo && todo.status === 'in_progress' && typeof todo.content === 'string') active.push(todo.content)
  }
  return active.join('\n')
}

function stateFor(session) {
  const id = session && session.id
  if (!id) return null
  let state = states.get(id)
  if (!state) {
    state = {
      userText: '',   // 最新的人类/子代理任务文本
      todoText: '',   // 当前 in_progress 小任务文本(拼接, 仅用于日志预览)
      todos: [],      // 最新一份 todo 清单(来自 todo/write)
      hasAssistant: false, // 是否已出现过助手回复(off 只允许在第一条请求)
      pendingErrors: 0, // 上一次模型回复之后出现的工具错误数
      cumErrors: 0,   // 本会话累计工具错误数
    }
    if (states.size > 512) {
      const oldest = states.keys().next().value
      if (oldest !== undefined) states.delete(oldest)
    }
    states.set(id, state)
  }
  return state
}

/**
 * 每次会话事件都增量更新信号状态。
 * 工具错误计数在 assistant/message 处清零: 下一次模型请求要处理的,
 * 就是上一次回复之后的那些工具结果。
 */
function trackEvent(session, event) {
  try {
    const state = stateFor(session)
    if (!state || !event) return
    const type = event.type
    if (type === 'todo/write') {
      state.todos = Array.isArray(event.data && event.data.todos) ? event.data.todos : []
      state.todoText = activeTodoTexts(state.todos)
    } else if (type === 'user/message') {
      const kind = event.data && event.data.source ? event.data.source.kind : undefined
      const isTask = kind === 'user' || (typeof kind === 'string' && kind.startsWith('subagent'))
      if (isTask) state.userText = extractText(event.data)
    } else if (type === 'tool/result') {
      if (isErrorResult(event.data)) {
        state.pendingErrors++
        state.cumErrors++
      }
    } else if (type === 'assistant/message') {
      state.hasAssistant = true
      state.pendingErrors = 0
    }
  } catch {
    // 信号跟踪失败只影响打分, 不影响请求
  }
}

/**
 * 从增量状态里读出当前请求的难度信号, 并完成打分。
 *
 * 有进行中的小任务(todo)时: 每个 in_progress 小任务单独打分, 取最难的那个
 * —— 当前步可能同时推进多个小任务, 推理等级应匹配其中最难的一个。
 * 没有 todo 时: 用最新的人类任务文本。
 */
function classifyRequest(agent, payload, state, cfg) {
  const depth = Number(agent && agent.options && agent.options.subagentDepth) > 0 ? 1 : 0
  // 错误信号 = 本次回复之后的错误 + 历史错误的追加(最多再算 1 个)
  const errorCount = state
    ? Math.min(state.pendingErrors + (state.cumErrors >= 2 && state.pendingErrors === 0 ? 1 : 0), 4)
    : 0
  // 本会话第一步 = 规划/拆分大任务的步骤(子代理除外: 它收到的本身就是小任务)
  const planning = payload.turn === 1 && payload.step === 1 && depth === 0

  if (state && Array.isArray(state.todos)) {
    const active = []
    for (const todo of state.todos) {
      if (todo && todo.status === 'in_progress' && typeof todo.content === 'string') active.push(todo.content)
    }
    if (active.length > 0) {
      let best = null
      for (const todoText of active) {
        const decision = classifyStep(cfg, {
          text: todoText.slice(0, cfg.maxTextChars),
          errorCount,
          depth,
          planning: false,
        })
        if (!best || decision.score > best.score) best = { ...decision, text: todoText }
      }
      const signals = {
        text: best ? best.text.slice(0, cfg.maxTextChars) : '',
        errorCount,
        depth,
        planning: false,
        activeCount: active.length,
      }
      return { decision: clampOff(best, state, cfg), signals }
    }
  }

  const text = state ? (state.userText || '').slice(0, cfg.maxTextChars) : ''
  const decision = classifyStep(cfg, { text, errorCount, depth, planning })
  return { decision: clampOff(decision, state, cfg), signals: { text, errorCount, depth, planning, activeCount: 0 } }
}

/**
 * off 的安全护栏: DeepSeek 会话中途关闭思考会触发
 * INVALID_REQUEST(reasoning_content 必须传回), 所以 off 只允许出现在
 * 会话第一条请求(尚无助手思考内容)。其余情况退回到 low。
 */
function clampOff(decision, state, cfg) {
  if (!decision || decision.level !== 'off') return decision
  if (cfg.offThreshold <= 0) return { ...decision, level: 'low', reasons: [...decision.reasons, 'off disabled -> low'] }
  if (state && state.hasAssistant) return { ...decision, level: 'low', reasons: [...decision.reasons, 'mid-session off blocked -> low'] }
  return decision
}

// ---------------------------------------------------------------------------
// 模型能力校验
// ---------------------------------------------------------------------------

/**
 * 查询模型支持的推理等级集合, 结果按 (provider, model) 永久缓存。
 * 拿不到(无 llm 服务 / 适配器拒绝 / 模型无 reasoning)时返回 null。
 */
function supportedEfforts(ctx, provider, model, signal) {
  const key = provider + '\u0000' + model
  let entry = supportCache.get(key)
  if (entry === undefined) {
    entry = (async () => {
      try {
        const llm = typeof ctx.get === 'function' ? ctx.get('llm') : undefined
        if (!llm || typeof llm.resolveModelInfo !== 'function') return null
        const info = await llm.resolveModelInfo(provider, model, signal)
        const efforts = info && info.reasoning && Array.isArray(info.reasoning.efforts)
          ? info.reasoning.efforts.map((effort) => effort.id)
          : []
        return efforts.length > 0 ? efforts : null
      } catch {
        return null
      }
    })()
    supportCache.set(key, entry)
  }
  return entry
}

// ---------------------------------------------------------------------------
// 设置面板
// ---------------------------------------------------------------------------

/**
 * 可选设置面板: 动态 import schemastery + dsh-settings, 装不上就静默跳过。
 * 即使没有设置面板, 插件照常工作(配置走 cordis.patch.yml)。
 */
function tryInstallSettingsSection(ctx, liveRef) {
  try {
    Promise.resolve().then(async () => {
      try {
        const [{ default: Schema }, settings] = await Promise.all([
          import('@deepseek-ai/schemastery'),
          import('@deepseek-ai/dsh-settings'),
        ])
        if (!Schema || !settings || !settings.installSettingsSection || !settings.settingsNamespace) return
        const stepSchema = Schema.object({
          chars: Schema.number().step(1).min(1).default(120),
          bias: Schema.number().min(0).max(1).default(0.04),
        })
        const schema = Schema.object({
          enabled: Schema.boolean().default(true),
          baseScore: Schema.number().min(0).max(1).default(0.18),
          offThreshold: Schema.number().min(0).max(1).default(0),
          lowThreshold: Schema.number().min(0).max(1).default(0.30),
          highThreshold: Schema.number().min(0).max(1).default(0.60),
          planningBias: Schema.number().min(0).max(1).default(0.18),
          planningMinLevel: Schema.union(EFFORTS.slice(1)).default('high'),
          errorBias: Schema.number().min(0).max(1).default(0.18),
          maxErrorBias: Schema.number().min(0).max(1).default(0.34),
          depthBias: Schema.number().min(0).max(1).default(0.05),
          lengthSteps: Schema.array(stepSchema).default([
            { chars: 120, bias: 0.04 },
            { chars: 500, bias: 0.10 },
            { chars: 2000, bias: 0.18 },
          ]),
          hardWeight: Schema.number().min(0).max(1).default(0.22),
          hardCap: Schema.number().min(0).max(1).default(0.45),
          mediumWeight: Schema.number().min(0).max(1).default(0.10),
          mediumCap: Schema.number().min(0).max(1).default(0.20),
          easyWeight: Schema.number().min(0).max(1).default(0.08),
          easyCap: Schema.number().min(0).max(1).default(0.25),
          maxTextChars: Schema.number().step(1).min(100).default(4000),
          debug: Schema.boolean().default(false),
          hardKeywords: Schema.array(Schema.string()).default([]),
          mediumKeywords: Schema.array(Schema.string()).default([]),
          easyKeywords: Schema.array(Schema.string()).default([]),
        })
        settings.installSettingsSection(ctx, settings.settingsNamespace('dynamic-thinking-chain'), schema, liveRef.cfg, {
          setSource: (source) => {
            try {
              liveRef.cfg = resolveConfig(source())
            } catch {
              // 设置值非法时保持旧配置
            }
          },
          onChange: () => {},
        })
      } catch {
        // 设置面板不可用(缺包/无 settings 服务), 静默跳过
      }
    })
  } catch {
    // 同上
  }
}
