import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  DEFAULTS,
  resolveConfig,
  classifyStep,
  effortForScore,
  pickSupported,
  rankLevel,
  scoreTask,
  EFFORTS,
} from '../src/classifier.js'

const cfg = resolveConfig({})

test('基础配置解析: 默认值 + 阈值顺序修正', () => {
  assert.equal(cfg.enabled, true)
  assert.equal(cfg.planningMinLevel, 'high')
  assert.ok(cfg.offThreshold <= cfg.lowThreshold)
  assert.ok(cfg.lowThreshold <= cfg.highThreshold)
  const bad = resolveConfig({ lowThreshold: 9, highThreshold: 0.1, baseScore: 'x', unknownKey: 1 })
  assert.equal(bad.lowThreshold, 0.1) // 被 highThreshold 夹下来
  assert.equal(bad.baseScore, DEFAULTS.baseScore) // 非法类型回退默认
})

test('琐碎任务 → off/low', () => {
  const simple = classifyStep(cfg, { text: '打印 hello world' })
  assert.ok(['off', 'low'].includes(simple.level))
  const trivial = classifyStep(cfg, { text: '给这个文件起个名字' })
  assert.ok(trivial.score < cfg.lowThreshold)
  assert.ok(['off', 'low'].includes(trivial.level))
})

test('中等任务 → high', () => {
  const medium = classifyStep(cfg, { text: '帮我修改一下这个 Python 脚本, 增加一个函数并写单元测试' })
  assert.equal(medium.level, 'high')
})

test('困难任务 → max', () => {
  const hard = classifyStep(cfg, {
    text: '设计一个高并发的分布式缓存系统, 要求线程安全、幂等、容错, 并给出架构方案和压测基准',
  })
  assert.equal(hard.level, 'max')
})

test('调试中(工具报错)抬分', () => {
  const base = classifyStep(cfg, { text: '运行这个脚本' })
  const withErrors = classifyStep(cfg, { text: '运行这个脚本', errorCount: 2 })
  assert.ok(withErrors.score > base.score)
  assert.ok(rankLevel(withErrors.level) >= rankLevel(base.level))
})

test('规划/拆分步保底 high 且抬分', () => {
  const planning = classifyStep(cfg, { text: '创建一个包含前端、后端和数据库的完整项目', planning: true })
  assert.equal(planning.level, 'high')
  assert.ok(planning.score > 0.3)
})

test('短英文关键词按词边界匹配: prefix 不算 fix', () => {
  const text = 'add a prefix to this variable'
  // 'fix' 不应命中 'prefix'
  const result = scoreTask(cfg, { text })
  const hard = cfg.hardKeywords.length
  assert.ok(hard > 0)
  // 'add' 命中 medium, 'prefix' 不该命中 'fix' 也不该命中 'print'
  assert.ok(result.score < 0.4)
})

test('effortForScore 阈值映射', () => {
  const c = resolveConfig({ offThreshold: 0.1, lowThreshold: 0.3, highThreshold: 0.6 })
  assert.equal(effortForScore(c, 0.05), 'off')
  assert.equal(effortForScore(c, 0.2), 'low')
  assert.equal(effortForScore(c, 0.5), 'high')
  assert.equal(effortForScore(c, 0.9), 'max')
})

test('pickSupported 回退策略', () => {
  assert.equal(pickSupported('max', ['off', 'low', 'high', 'max']), 'max')
  assert.equal(pickSupported('max', ['off', 'low']), 'low')
  assert.equal(pickSupported('low', ['high', 'max']), 'high')
  assert.equal(pickSupported('high', []), undefined)
  assert.equal(pickSupported('high', null), undefined)
})

test('EFFORTS 顺序与 rankLevel', () => {
  assert.deepEqual(EFFORTS, ['off', 'low', 'high', 'max'])
  assert.equal(rankLevel('low'), 1)
  assert.equal(rankLevel('unknown'), 0)
})

test('配置可自定义关键词与阈值', () => {
  const custom = resolveConfig({
    highThreshold: 0.5,
    easyKeywords: ['打印'],
    hardKeywords: [],
  })
  const result = classifyStep(custom, { text: '打印一行日志' })
  assert.ok(result.score < custom.highThreshold)
})
