# dynamic-thinking-chain

让 DeepSeek 模型「按任务难度自动思考」的 DSH 插件。

DSH 会把一个大任务拆成很多小任务（`todo_write` 清单、子代理）。这个插件在**每一次模型请求之前**，根据**当前正在做的那个小任务**的难度，自动选择最合适的推理等级：

| 等级 | 含义 | 什么时候用 |
| --- | --- | --- |
| `max` | 最深思考 | 规划/拆分大任务、算法、并发、安全、排查调试 |
| `high` | 较深思考 | 写函数、单元测试、改代码、写文档 |
| `low` | 轻度思考 | 打印 Hello World、改个名字这类琐碎小任务 |
| `off` | 关闭思考 | 默认禁用（DeepSeek 限制，见下方说明） |

简单的活少想省 token，难的活深想保证质量——这就是「动态思维链」。

## 效果演示

一次真实运行里，一个大任务被拆成 4 个小任务，插件给每步分配了不同的推理等级：

```text
[规划/拆分整个任务]    => max
[创建 hello.py]        => low
[二分查找 + 单元测试]  => high
[线程安全计数器]       => max
[写 README]            => high
```

## 安装

打包后用 `dsh plugin` 装进某个 profile：

```bash
cd dynamic-thinking-chain
npm pack   # 生成 dynamic-thinking-chain-0.1.2.tgz

dsh plugin --profile desktop add file:D:/workplace/dynamic-thinking-chain/dynamic-thinking-chain-0.1.2.tgz
```

装完重启对应界面：桌面版「退出后台运行」再打开；`dsh web` 重启 web 进程。

卸载：`dsh plugin --profile desktop remove dynamic-thinking-chain`。

## 配置（可选，默认开箱即用）

在 `C:\Users\<你>\.dsh\profiles\<profile>\cordis.patch.yml` 里覆盖：

```yaml
- id: dynamic-thinking-chain
  config:
    enabled: true        # 总开关，设 false 彻底关闭
    lowThreshold: 0.30   # 难度分 < 0.30 → low
    highThreshold: 0.60  # 难度分 < 0.60 → high，否则 max
    planningMinLevel: high  # 拆分步的最低等级
    debug: false         # 设 true 才在控制台打印每次决策细节
```

常用配置项（完整列表见 `src/classifier.js` 的 `DEFAULTS`）：

- **打分**：`baseScore`（基础分）、`lengthSteps`（文本长度阶梯）、`hardWeight/hardCap`、`mediumWeight/mediumCap`、`easyWeight/easyCap`、`planningBias`、`errorBias/maxErrorBias`、`depthBias`
- **关键词**：`hardKeywords` / `mediumKeywords` / `easyKeywords`（数组，可完全自定义；命中“简单”类词会降分）
- **日志**：`debug`（默认 `false`，静默；设 `true` 打印每次决策的难度分和理由）

> 插件默认**不打日志**。想看它每步怎么决策，把 `debug: true` 放进上面的 config；出错时才会打印一条 warning。

## 常见问题

**1. 装了没效果？**
插件只会对「支持推理等级」的模型生效。先确认当前会话选的模型是 DeepSeek（如 `deepseek-v4-pro`、`deepseek-v4-flash`）；其他模型（比如 stepfun、普通对话模型）会被自动跳过、保持原样。

**2. 为什么默认不用 `off`？**
DeepSeek 的规则：会话中途关闭思考会报 `INVALID_REQUEST`（上一轮的 `reasoning_content` 必须传回）。所以 `offThreshold` 默认是 `0`（永不开 `off`）；即使你手动调大，插件也只会在会话**第一条请求**允许 `off`，之后自动退到 `low`。

**3. 想固定某一档、不要动态？**
把 `enabled: false`，或者在 DSH 界面右上角的模型选择里手动固定推理等级即可（本插件只在“动态”这件事上接管）。

## 原理（30 秒版）

1. 插件监听每次模型请求前的 `agent/request` 瀑布，只改 `reasoningEffort` 一个字段。
2. 难度来自当前会话信号：`todo_write` 里 `in_progress` 的小任务文本、最新的人类指令、工具报错次数、是否是第一步/子代理。
3. 打分 → 映射到 `off/low/high/max` → 用 `llm.resolveModelInfo` 确认模型支持该等级 → 写入请求。
4. 任何一步出错都原样放行，插件永远不会把请求弄坏。

## 开发

```bash
npm test   # 运行单元测试（打分、分级、等级回退）
```

插件本体零运行时依赖；profile 里有 `@deepseek-ai/schemastery` 和 `@deepseek-ai/dsh-settings` 时会自动注册 GUI 设置面板，否则自动跳过。

## 许可证

MIT
