import { readFile } from 'node:fs/promises'
import { basename, dirname, resolve } from 'node:path'
import { transform } from 'lightningcss'
import { defineConfig } from 'tsdown'

const id = 'dsh-translator'
const virtualPrefix = '\0dsh-translator-css:'
const virtualSuffix = '.mjs'
const external = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-web-react',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-runtime/client',
]

export default defineConfig({
  name: `${id}/client`,
  entry: { client: 'src/client/index.tsx' },
  outDir: 'lib',
  format: 'cjs',
  platform: 'browser',
  target: 'es2022',
  dts: false,
  clean: false,
  sourcemap: true,
  deps: {
    neverBundle: external,
    alwaysBundle: (specifier: string) => external.includes(specifier) ? undefined : true,
  },
  plugins: [{
    name: 'dsh-translator-css-modules',
    resolveId(source: string, importer: string | undefined) {
      if (!source.endsWith('.module.css')) return null
      const file = importer ? resolve(dirname(importer), source) : resolve(source)
      return virtualPrefix + file + virtualSuffix
    },
    async load(virtualId: string) {
      if (!virtualId.startsWith(virtualPrefix)) return null
      const file = virtualId.slice(virtualPrefix.length, -virtualSuffix.length)
      this.addWatchFile(file)
      const result = transform({
        filename: file,
        code: await readFile(file),
        cssModules: { pattern: '[hash]_[local]' },
        minify: true,
      })
      const classMap: Record<string, string> = {}
      for (const [local, value] of Object.entries(result.exports ?? {})) classMap[local] = value.name
      const styleId = `${id}/${basename(file)}`
      return [
        `const css = ${JSON.stringify(result.code.toString())};`,
        `const styleId = ${JSON.stringify(styleId)};`,
        'if (typeof document !== "undefined" && !document.querySelector(`style[data-plugin-css="${styleId}"]`)) {',
        '  const element = document.createElement("style");',
        `  element.dataset.plugin = ${JSON.stringify(id)};`,
        '  element.dataset.pluginCss = styleId;',
        '  element.textContent = css;',
        '  document.head.appendChild(element);',
        '}',
        `export default ${JSON.stringify(classMap)};`,
      ].join('\n')
    },
  }],
  outputOptions: {
    entryFileNames: 'client.js',
    banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify(id)}, factory: (require) => {`,
    footer: 'return module.exports; } });',
    intro: 'var module = { exports: {} }; var exports = module.exports;',
  },
})
