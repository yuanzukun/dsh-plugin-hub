/**
 * A focused translation persona for DeepSeek Harness.
 *
 * The plugin contributes one complete prompt section, so installed profiles
 * behave as a translation application instead of a general coding agent.
 * @module dsh-translator
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { buildTranslatorPrompt, OUTPUT_MODES, TRANSLATION_STYLES, type OutputMode, type TranslationStyle, type TranslatorOptions } from './prompt.js';
import { buildTranslationRequest, parseGlossary, type TranslationRequestOptions } from './request.js';
export { buildTranslationRequest, buildTranslatorPrompt, OUTPUT_MODES, parseGlossary, TRANSLATION_STYLES };
export type { OutputMode, TranslationRequestOptions, TranslationStyle, TranslatorOptions };
/** Cordis plugin name. */
export declare const name = "translator";
/** The prompt registry this plugin contributes to. */
export declare const inject: string[];
/** User-configurable translation defaults. */
export interface Config {
    /** Source language name or `auto` for language detection. */
    sourceLanguage?: string;
    /** Default target language name. */
    targetLanguage?: string;
    /** Default translation register. */
    style?: TranslationStyle;
    /** Return only translated text or a bilingual pairing. */
    outputMode?: OutputMode;
    /** Preserve the source document's markup and layout. */
    preserveFormatting?: boolean;
    /** Translate comments and docstrings while leaving code untouched. */
    translateCodeComments?: boolean;
    /** Exact source-term to target-term preferences. */
    glossary?: Record<string, string>;
    /** Extra deployment-specific translation requirements. */
    customInstructions?: string;
    /** Retain workspace and other dynamic runtime snapshots. */
    includeRuntimeContext?: boolean;
}
/** Runtime schema used by Cordis for validation and defaults. */
export declare const Config: z<Config>;
/** Register the complete translator persona. */
export declare function apply(ctx: Context, config: Config): void;
