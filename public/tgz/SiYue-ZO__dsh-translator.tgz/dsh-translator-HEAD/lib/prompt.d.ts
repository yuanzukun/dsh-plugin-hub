/** Supported default translation styles. */
export declare const TRANSLATION_STYLES: readonly ["natural", "professional", "academic", "technical", "literal"];
/** Supported default output layouts. */
export declare const OUTPUT_MODES: readonly ["target-only", "bilingual"];
export type TranslationStyle = typeof TRANSLATION_STYLES[number];
export type OutputMode = typeof OUTPUT_MODES[number];
/** Fully resolved options used to build the translator persona. */
export interface TranslatorOptions {
    sourceLanguage: string;
    targetLanguage: string;
    style: TranslationStyle;
    outputMode: OutputMode;
    preserveFormatting: boolean;
    translateCodeComments: boolean;
    glossary: Record<string, string>;
    customInstructions: string;
}
/** Build the complete, stable system prompt installed by the plugin. */
export declare function buildTranslatorPrompt(options: TranslatorOptions): string;
