import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** Services consumed by the browser half. */
export declare const inject: string[];
/** Replace dsh's central conversation surface with the translation workspace. */
export declare function apply(ctx: ClientContext): void;
