import type { OutputMode, TranslationStyle } from './prompt.js';
/** Per-request controls used by the native translation workspace. */
export interface TranslationRequestOptions {
    sourceLanguage: string;
    targetLanguage: string;
    style: TranslationStyle;
    outputMode: OutputMode;
    preserveFormatting: boolean;
    glossary: Record<string, string>;
    customInstructions: string;
}
/**
 * Build a strict, self-contained prompt for one translation job.
 *
 * The source is JSON encoded so line breaks, markup, and instruction-looking
 * content remain an explicit data value rather than becoming prompt syntax.
 */
export declare function buildTranslationRequest(text: string, options: TranslationRequestOptions): string;
/** Parse a human-editable `source = target` glossary. */
export declare function parseGlossary(value: string): Record<string, string>;
