import { useEffect, useMemo, useRef, useState } from 'react'
import type {
  AssistantBlock, ConversationSnapshot, ClientContext, SessionId,
} from '@deepseek-ai/dsh-client-runtime/client'
import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
import { buildTranslationRequest, parseGlossary } from '../request.js'
import type { OutputMode, TranslationStyle } from '../prompt.js'
import styles from './translator.module.css'

const STORAGE_SETTINGS = 'dsh-translator.settings.v1'
const STORAGE_HISTORY = 'dsh-translator.history.v1'
const HISTORY_LIMIT = 100

const LANGUAGES = [
  ['auto', '自动检测'],
  ['Simplified Chinese', '简体中文'],
  ['Traditional Chinese', '繁體中文'],
  ['English', 'English'],
  ['Japanese', '日本語'],
  ['Korean', '한국어'],
  ['French', 'Français'],
  ['German', 'Deutsch'],
  ['Spanish', 'Español'],
  ['Portuguese', 'Português'],
  ['Italian', 'Italiano'],
  ['Russian', 'Русский'],
  ['Arabic', 'العربية'],
] as const

const STYLES: ReadonlyArray<[TranslationStyle, string]> = [
  ['natural', '自然'],
  ['professional', '专业'],
  ['academic', '学术'],
  ['technical', '技术'],
  ['literal', '直译'],
]

interface Settings {
  sourceLanguage: string
  targetLanguage: string
  style: TranslationStyle
  outputMode: OutputMode
  preserveFormatting: boolean
  glossaryText: string
  customInstructions: string
  autoCopy: boolean
}

interface HistoryItem {
  id: string
  source: string
  result: string
  sourceLanguage: string
  targetLanguage: string
  style: TranslationStyle
  createdAt: number
}

interface PendingJob {
  id: string
  baselineSeq: number
  source: string
  settings: Settings
  accepted: boolean
}

interface TranslatorInjected {
  send: (prompt: string) => Promise<{ ok: true } | { ok: false; message: string }>
  cancel: () => Promise<{ ok: true } | { ok: false; message: string }>
  startSession: () => void
}

type TranslatorProps = PropsRuntime<'conversation'> & InjectFace<TranslatorInjected>

const DEFAULT_SETTINGS: Settings = {
  sourceLanguage: 'auto',
  targetLanguage: 'Simplified Chinese',
  style: 'natural',
  outputMode: 'target-only',
  preserveFormatting: true,
  glossaryText: '',
  customInstructions: '',
  autoCopy: false,
}

/** Services consumed by the browser half. */
export const inject = ['slots', 'sessions', 'workspaces']

/** Replace dsh's central conversation surface with the translation workspace. */
export function apply(ctx: ClientContext): void {
  ctx.slots.inject('conversation', () => ctx.slots.register({
    name: 'conversation',
    priority: -100,
    inject: (sessionId: SessionId | undefined): TranslatorInjected => ({
      send: async (prompt) => {
        if (!sessionId) return { ok: false, message: '请先创建一个翻译会话' }
        const session = ctx.sessions.binding(sessionId)?.session
        if (!session) return { ok: false, message: '翻译会话尚未就绪' }
        const result = await session.prompt([{ type: 'text', text: prompt }], 'queue')
        return result.ok ? { ok: true } : { ok: false, message: result.error.message }
      },
      cancel: async () => {
        if (!sessionId) return { ok: false, message: '没有可停止的翻译' }
        const session = ctx.sessions.binding(sessionId)?.session
        if (!session) return { ok: false, message: '翻译会话尚未就绪' }
        const result = await session.cancel()
        return result.ok ? { ok: true } : { ok: false, message: result.error.message }
      },
      startSession: () => { ctx.workspaces.startSession() },
    }),
  }, TranslatorWorkspace))
}

function TranslatorWorkspace({ useSession, sessionId, send, cancel, startSession }: TranslatorProps) {
  const snapshot = useSession(value => value)
  const [settings, setSettings] = useStoredState(STORAGE_SETTINGS, DEFAULT_SETTINGS)
  const [history, setHistory] = useStoredState<HistoryItem[]>(STORAGE_HISTORY, [])
  const [source, setSource] = useState('')
  const [output, setOutput] = useState('')
  const [pending, setPending] = useState<PendingJob | null>(null)
  const [error, setError] = useState('')
  const [showSettings, setShowSettings] = useState(false)
  const [showHistory, setShowHistory] = useState(false)
  const [historyQuery, setHistoryQuery] = useState('')
  const fileInput = useRef<HTMLInputElement>(null)

  const finalAnswer = useMemo(
    () => pending && snapshot ? assistantAfter(snapshot, pending.baselineSeq) : null,
    [pending, snapshot],
  )
  const streamingAnswer = useMemo(
    () => snapshot?.partial ? textFromBlocks(snapshot.partial.blocks) : '',
    [snapshot?.partial],
  )
  const displayedOutput = pending && streamingAnswer ? streamingAnswer : output
  const busy = pending !== null || snapshot?.running === true

  useEffect(() => {
    if (!pending || !finalAnswer) return
    const result = textFromBlocks(finalAnswer.blocks).trim()
    if (!result) return
    setOutput(result)
    setHistory(items => [{
      id: pending.id,
      source: pending.source,
      result,
      sourceLanguage: pending.settings.sourceLanguage,
      targetLanguage: pending.settings.targetLanguage,
      style: pending.settings.style,
      createdAt: Date.now(),
    }, ...items.filter(item => item.id !== pending.id)].slice(0, HISTORY_LIMIT))
    if (pending.settings.autoCopy) void copyText(result).catch(() => undefined)
    setPending(null)
  }, [finalAnswer, pending, setHistory])

  useEffect(() => {
    if (!pending || !snapshot) return
    const failure = snapshot.promptError?.error.message ?? snapshot.lastAgentError
    if (failure) {
      setError(failure)
      setPending(null)
    }
  }, [pending, snapshot])

  const translate = async () => {
    if (!source.trim()) return setError('请输入要翻译的内容')
    const text = source
    if (!sessionId || !snapshot) return setError('请先创建一个翻译会话')
    if (busy) return
    setError('')
    setOutput('')
    const job: PendingJob = {
      id: globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random()}`,
      baselineSeq: latestAssistantSeq(snapshot),
      source: text,
      settings: { ...settings },
      accepted: false,
    }
    setPending(job)
    const result = await send(buildTranslationRequest(text, {
      sourceLanguage: settings.sourceLanguage,
      targetLanguage: settings.targetLanguage,
      style: settings.style,
      outputMode: settings.outputMode,
      preserveFormatting: settings.preserveFormatting,
      glossary: parseGlossary(settings.glossaryText),
      customInstructions: settings.customInstructions,
    }))
    if (!result.ok) {
      setError(result.message)
      setPending(null)
      return
    }
    setPending(current => current?.id === job.id ? { ...current, accepted: true } : current)
  }

  const stop = async () => {
    const result = await cancel()
    if (!result.ok) setError(result.message)
    else {
      if (streamingAnswer) setOutput(streamingAnswer)
      setPending(null)
    }
  }

  const swapLanguages = () => {
    setSettings(current => ({
      ...current,
      sourceLanguage: current.targetLanguage,
      targetLanguage: current.sourceLanguage === 'auto' ? 'English' : current.sourceLanguage,
    }))
    setSource(displayedOutput)
    setOutput(source)
  }

  const visibleHistory = history.filter(item => {
    const query = historyQuery.trim().toLocaleLowerCase()
    return !query || `${item.source}\n${item.result}`.toLocaleLowerCase().includes(query)
  })

  return <main className={styles.app}>
    <header className={styles.header}>
      <div className={styles.brand}>
        <span className={styles.logo}><Icon name="translate" /></span>
        <div><strong>DSH Translator</strong><span>由当前 dsh 模型驱动</span></div>
      </div>
      <div className={styles.headerActions}>
        <button className={styles.ghostButton} onClick={() => setShowHistory(value => !value)} aria-pressed={showHistory}>
          <Icon name="history" />历史 <span className={styles.badge}>{history.length}</span>
        </button>
        <button className={styles.ghostButton} onClick={() => setShowSettings(value => !value)} aria-pressed={showSettings}>
          <Icon name="settings" />设置
        </button>
      </div>
    </header>

    {showSettings && <SettingsPanel settings={settings} onChange={setSettings} />}

    <section className={styles.languageBar} aria-label="翻译语言">
      <label><span>源语言</span><select value={settings.sourceLanguage} onChange={event => setSettings(value => ({ ...value, sourceLanguage: event.target.value }))}>{LANGUAGES.map(language => <option key={language[0]} value={language[0]}>{language[1]}</option>)}</select></label>
      <button className={styles.swapButton} onClick={swapLanguages} title="互换语言和内容" aria-label="互换语言和内容"><Icon name="swap" /></button>
      <label><span>目标语言</span><select value={settings.targetLanguage} onChange={event => setSettings(value => ({ ...value, targetLanguage: event.target.value }))}>{LANGUAGES.filter(language => language[0] !== 'auto').map(language => <option key={language[0]} value={language[0]}>{language[1]}</option>)}</select></label>
    </section>

    <section className={styles.editorGrid}>
      <article className={styles.editorPanel}>
        <div className={styles.panelHead}><span>原文</span><div>
          <button onClick={() => void pasteText().then(setSource).catch(reason => setError(String(reason)))} title="粘贴"><Icon name="paste" /></button>
          <button onClick={() => fileInput.current?.click()} title="导入文本文件"><Icon name="upload" /></button>
          <button onClick={() => { setSource(''); setOutput(''); setError('') }} title="清空"><Icon name="trash" /></button>
        </div></div>
        <textarea
          value={source}
          onChange={event => setSource(event.target.value)}
          onKeyDown={event => { if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') { event.preventDefault(); void translate() } }}
          placeholder="输入或粘贴要翻译的内容…\n\nCtrl / ⌘ + Enter 开始翻译"
          spellCheck={false}
          aria-label="原文"
        />
        <div className={styles.panelFoot}><span>{countText(source)}</span><span>{settings.preserveFormatting ? '保留格式' : '自然排版'}</span></div>
        <input ref={fileInput} className={styles.hiddenInput} type="file" accept="text/*,.md,.csv,.json,.html,.xml" onChange={event => void readFile(event, setSource, setError)} />
      </article>

      <article className={`${styles.editorPanel} ${styles.resultPanel}`}>
        <div className={styles.panelHead}><span>译文 {pending && <em>正在生成…</em>}</span><div>
          <button onClick={() => speak(displayedOutput, settings.targetLanguage)} disabled={!displayedOutput} title="朗读"><Icon name="speaker" /></button>
          <button onClick={() => void downloadText(displayedOutput, settings.targetLanguage)} disabled={!displayedOutput} title="下载"><Icon name="download" /></button>
          <button onClick={() => void copyText(displayedOutput).catch(reason => setError(String(reason)))} disabled={!displayedOutput} title="复制"><Icon name="copy" /></button>
        </div></div>
        <textarea className={pending ? styles.streaming : ''} value={displayedOutput} readOnly placeholder={sessionId ? '译文会在这里流式出现' : '创建翻译会话后即可开始'} aria-label="译文" />
        <div className={styles.panelFoot}><span>{countText(displayedOutput)}</span><span>{settings.outputMode === 'target-only' ? '仅译文' : '双语对照'}</span></div>
      </article>
    </section>

    <section className={styles.actionRow}>
      <div className={styles.status}>{error ? <span className={styles.error}><Icon name="alert" />{error}</span> : <span>{sessionId ? '翻译就绪' : '需要一个 dsh 会话'}</span>}</div>
      {!sessionId
        ? <button className={styles.primaryButton} onClick={startSession}><Icon name="plus" />创建翻译会话</button>
        : busy
          ? <button className={styles.stopButton} onClick={() => void stop()}><Icon name="stop" />停止翻译</button>
          : <button className={styles.primaryButton} onClick={() => void translate()} disabled={!source.trim()}><Icon name="spark" />开始翻译</button>}
    </section>

    {showHistory && <HistoryPanel
      history={visibleHistory}
      query={historyQuery}
      onQuery={setHistoryQuery}
      onUse={item => { setSource(item.source); setOutput(item.result); setSettings(value => ({ ...value, sourceLanguage: item.sourceLanguage, targetLanguage: item.targetLanguage, style: item.style })); setShowHistory(false) }}
      onDelete={id => setHistory(items => items.filter(item => item.id !== id))}
      onClear={() => setHistory([])}
      onClose={() => setShowHistory(false)}
    />}
  </main>
}

function SettingsPanel({ settings, onChange }: { settings: Settings; onChange: (value: Settings | ((current: Settings) => Settings)) => void }) {
  return <section className={styles.settingsPanel}>
    <div className={styles.settingGroup}><label>翻译风格<select value={settings.style} onChange={event => onChange(value => ({ ...value, style: event.target.value as TranslationStyle }))}>{STYLES.map(style => <option key={style[0]} value={style[0]}>{style[1]}</option>)}</select></label></div>
    <div className={styles.settingGroup}><label>输出模式<select value={settings.outputMode} onChange={event => onChange(value => ({ ...value, outputMode: event.target.value as OutputMode }))}><option value="target-only">仅译文</option><option value="bilingual">双语对照</option></select></label></div>
    <label className={styles.switchLabel}><input type="checkbox" checked={settings.preserveFormatting} onChange={event => onChange(value => ({ ...value, preserveFormatting: event.target.checked }))} /><span />保留原文格式</label>
    <label className={styles.switchLabel}><input type="checkbox" checked={settings.autoCopy} onChange={event => onChange(value => ({ ...value, autoCopy: event.target.checked }))} /><span />完成后自动复制</label>
    <label className={styles.wideSetting}>术语表 <small>每行一条：原文 = 译文</small><textarea value={settings.glossaryText} onChange={event => onChange(value => ({ ...value, glossaryText: event.target.value }))} placeholder="DeepSeek Harness = DeepSeek Harness" /></label>
    <label className={styles.wideSetting}>附加要求<textarea value={settings.customInstructions} onChange={event => onChange(value => ({ ...value, customInstructions: event.target.value }))} placeholder="例如：面向 8 岁儿童，使用易懂表达" /></label>
  </section>
}

function HistoryPanel(props: { history: HistoryItem[]; query: string; onQuery: (value: string) => void; onUse: (item: HistoryItem) => void; onDelete: (id: string) => void; onClear: () => void; onClose: () => void }) {
  return <aside className={styles.historyPanel}>
    <div className={styles.historyHead}><div><strong>翻译历史</strong><span>仅保存在当前浏览器</span></div><button onClick={props.onClose}><Icon name="close" /></button></div>
    <div className={styles.searchBox}><Icon name="search" /><input value={props.query} onChange={event => props.onQuery(event.target.value)} placeholder="搜索原文或译文" /></div>
    <div className={styles.historyList}>{props.history.length === 0 ? <div className={styles.emptyHistory}><Icon name="history" /><span>暂无翻译历史</span></div> : props.history.map(item => <article key={item.id} onClick={() => props.onUse(item)} tabIndex={0} onKeyDown={event => { if (event.key === 'Enter') props.onUse(item) }}>
      <div><span>{languageLabel(item.sourceLanguage)} → {languageLabel(item.targetLanguage)}</span><time>{new Date(item.createdAt).toLocaleString()}</time></div>
      <p>{item.source}</p><p>{item.result}</p>
      <button onClick={event => { event.stopPropagation(); props.onDelete(item.id) }} title="删除"><Icon name="trash" /></button>
    </article>)}</div>
    {props.history.length > 0 && <button className={styles.clearHistory} onClick={props.onClear}>清空当前历史</button>}
  </aside>
}

function useStoredState<T>(key: string, fallback: T): [T, (value: T | ((current: T) => T)) => void] {
  const [value, setValue] = useState<T>(() => {
    try {
      const stored = localStorage.getItem(key)
      if (!stored) return fallback
      const parsed = JSON.parse(stored) as T
      return Array.isArray(fallback)
        ? parsed
        : typeof fallback === 'object' && fallback !== null
          ? { ...fallback, ...parsed }
          : parsed
    } catch { return fallback }
  })
  const update = (next: T | ((current: T) => T)) => setValue(current => {
    const resolved = typeof next === 'function' ? (next as (value: T) => T)(current) : next
    try { localStorage.setItem(key, JSON.stringify(resolved)) } catch { /* storage is best-effort */ }
    return resolved
  })
  return [value, update]
}

function assistantAfter(snapshot: ConversationSnapshot, seq: number) {
  for (let index = snapshot.nodes.length - 1; index >= 0; index -= 1) {
    const node = snapshot.nodes[index]
    if (node?.kind === 'assistant' && node.seq > seq) return node
  }
  return null
}

function latestAssistantSeq(snapshot: ConversationSnapshot): number {
  return snapshot.nodes.reduce((seq, node) => node.kind === 'assistant' ? Math.max(seq, node.seq) : seq, -1)
}

function textFromBlocks(blocks: readonly AssistantBlock[]): string {
  return blocks.filter((block): block is Extract<AssistantBlock, { kind: 'text' }> => block.kind === 'text').map(block => block.text).join('')
}

function countText(value: string): string {
  const characters = [...value].length
  const words = value.trim() ? value.trim().split(/\s+/u).length : 0
  return `${characters.toLocaleString()} 字符 · ${words.toLocaleString()} 词`
}

function languageLabel(value: string): string {
  return LANGUAGES.find(language => language[0] === value)?.[1] ?? value
}

async function copyText(value: string): Promise<void> {
  if (!value) return
  await navigator.clipboard.writeText(value)
}

async function pasteText(): Promise<string> {
  return navigator.clipboard.readText()
}

async function readFile(event: React.ChangeEvent<HTMLInputElement>, onRead: (value: string) => void, onError: (value: string) => void) {
  const file = event.target.files?.[0]
  event.target.value = ''
  if (!file) return
  if (file.size > 2_000_000) return onError('文件超过 2 MB，请分段翻译')
  try { onRead(await file.text()) } catch (reason) { onError(`无法读取文件：${String(reason)}`) }
}

async function downloadText(value: string, language: string) {
  if (!value) return
  const url = URL.createObjectURL(new Blob([value], { type: 'text/plain;charset=utf-8' }))
  const link = document.createElement('a')
  link.href = url
  link.download = `translation-${language.toLowerCase().replace(/\s+/gu, '-')}.txt`
  link.click()
  URL.revokeObjectURL(url)
}

function speak(value: string, language: string) {
  if (!value || !('speechSynthesis' in window)) return
  window.speechSynthesis.cancel()
  const utterance = new SpeechSynthesisUtterance(value)
  utterance.lang = ({
    'Simplified Chinese': 'zh-CN', 'Traditional Chinese': 'zh-TW', English: 'en-US', Japanese: 'ja-JP',
    Korean: 'ko-KR', French: 'fr-FR', German: 'de-DE', Spanish: 'es-ES', Portuguese: 'pt-PT',
    Italian: 'it-IT', Russian: 'ru-RU', Arabic: 'ar-SA',
  } as Record<string, string>)[language] ?? ''
  window.speechSynthesis.speak(utterance)
}

function Icon({ name }: { name: string }) {
  const paths: Record<string, React.ReactNode> = {
    translate: <><path d="M4 5h7M7.5 3v2c0 4-2 7-5 9"/><path d="M4 9c1 2 3 4 6 5M13 19l4-10 4 10M14.5 16h5"/></>,
    history: <><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/></>,
    swap: <><path d="m7 7-3 3 3 3M4 10h16M17 17l3-3-3-3"/></>,
    paste: <><path d="M9 5h6v3H9zM9 5a3 3 0 0 1 6 0"/><path d="M7 6H5v15h14V6h-2"/></>,
    upload: <><path d="M12 3v12M8 7l4-4 4 4"/><path d="M4 14v6h16v-6"/></>,
    trash: <><path d="M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14M10 11v6M14 11v6"/></>,
    speaker: <><path d="M5 9H2v6h3l5 4V5L5 9Z"/><path d="M14 9a4 4 0 0 1 0 6M17 6a8 8 0 0 1 0 12"/></>,
    download: <><path d="M12 3v12M8 11l4 4 4-4"/><path d="M4 19h16"/></>,
    copy: <><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></>,
    alert: <><path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5M12 17h.01"/></>,
    plus: <path d="M12 5v14M5 12h14"/>,
    stop: <rect x="6" y="6" width="12" height="12" rx="2"/>,
    spark: <><path d="m12 3 1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5L12 3Z"/><path d="m19 16 .7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z"/></>,
    close: <path d="M5 5l14 14M19 5 5 19"/>,
    search: <><circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/></>,
  }
  return <svg viewBox="0 0 24 24" aria-hidden="true">{paths[name]}</svg>
}
