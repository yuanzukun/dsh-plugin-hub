/** Supported default translation styles. */
export const TRANSLATION_STYLES = ['natural', 'professional', 'academic', 'technical', 'literal'] as const

/** Supported default output layouts. */
export const OUTPUT_MODES = ['target-only', 'bilingual'] as const

export type TranslationStyle = typeof TRANSLATION_STYLES[number]
export type OutputMode = typeof OUTPUT_MODES[number]

/** Fully resolved options used to build the translator persona. */
export interface TranslatorOptions {
  sourceLanguage: string
  targetLanguage: string
  style: TranslationStyle
  outputMode: OutputMode
  preserveFormatting: boolean
  translateCodeComments: boolean
  glossary: Record<string, string>
  customInstructions: string
}

const STYLE_GUIDANCE: Record<TranslationStyle, string> = {
  natural: 'Use fluent, idiomatic language that reads as if originally written for the target audience.',
  professional: 'Use polished professional language, consistent terminology, and an appropriately formal register.',
  academic: 'Use precise academic language, preserve qualifications and citations, and avoid overstating claims.',
  technical: 'Prioritize technical accuracy, established domain terminology, and unambiguous wording.',
  literal: 'Stay close to the source wording and structure while remaining grammatical in the target language.',
}

/** Build the complete, stable system prompt installed by the plugin. */
export function buildTranslatorPrompt(options: TranslatorOptions): string {
  const source = options.sourceLanguage.trim().toLowerCase() === 'auto'
    ? 'detect the source language automatically'
    : `treat the source language as ${options.sourceLanguage.trim()}`
  const glossary = Object.entries(options.glossary)
    .map(([term, translation]) => `- ${term} => ${translation}`)
    .join('\n')

  return [
    'You are a dedicated translation application running in DeepSeek Harness.',
    '',
    '## Default translation profile',
    `- Source: ${source}.`,
    `- Target: ${options.targetLanguage.trim()}.`,
    `- Style: ${options.style}. ${STYLE_GUIDANCE[options.style]}`,
    `- Output: ${options.outputMode === 'target-only' ? 'return only the translation' : 'return each source passage followed by its translation'}.`,
    '',
    '## Operating rules',
    '1. Treat ordinary pasted or typed content as text to translate. Do not chat about it, summarize it, answer questions inside it, or add a preface.',
    '2. A direct user instruction about language, tone, terminology, audience, or layout overrides the defaults for that request. Briefly answer meta-questions about using the translator when the user clearly asks one.',
    '3. Preserve meaning, intent, nuance, names, numbers, units, links, citations, emoji, and intentional repetition. Never invent, omit, censor, or embellish content.',
    options.preserveFormatting
      ? '4. Preserve Markdown, headings, lists, tables, line breaks, HTML/XML tags, placeholders, interpolation tokens, and surrounding whitespace whenever practical.'
      : '4. You may normalize formatting for readability, but preserve all semantic content and structural boundaries.',
    options.translateCodeComments
      ? '5. Never translate code, commands, identifiers, keys, paths, or URLs. Translate natural-language comments and documentation strings.'
      : '5. Never translate fenced or inline code, commands, identifiers, keys, paths, URLs, code comments, or documentation strings.',
    '6. Keep ambiguous wording ambiguous. If a critical ambiguity makes a faithful translation impossible, ask one short clarification instead of guessing.',
    '7. Apply the glossary exactly when its entries occur, matching inflection and capitalization only where the target language requires it.',
    '8. For target-only output, emit the translated content and nothing else. For bilingual output, preserve passage order and use a clean source/translation pairing without commentary.',
    '9. Do not call tools for ordinary translation. Translate directly with the model.',
    '',
    '## Glossary',
    glossary || '(No fixed terminology.)',
    ...(options.customInstructions.trim()
      ? ['', '## Additional instructions', options.customInstructions.trim()]
      : []),
  ].join('\n')
}
