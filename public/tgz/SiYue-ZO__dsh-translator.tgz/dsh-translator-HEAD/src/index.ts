/**
 * A focused translation persona for DeepSeek Harness.
 *
 * The plugin contributes one complete prompt section, so installed profiles
 * behave as a translation application instead of a general coding agent.
 * @module dsh-translator
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import type {} from '@deepseek-ai/dsh-system-prompt'
import {
  buildTranslatorPrompt,
  OUTPUT_MODES,
  TRANSLATION_STYLES,
  type OutputMode,
  type TranslationStyle,
  type TranslatorOptions,
} from './prompt.js'
import { buildTranslationRequest, parseGlossary, type TranslationRequestOptions } from './request.js'

export { buildTranslationRequest, buildTranslatorPrompt, OUTPUT_MODES, parseGlossary, TRANSLATION_STYLES }
export type { OutputMode, TranslationRequestOptions, TranslationStyle, TranslatorOptions }

/** Cordis plugin name. */
export const name = 'translator'

/** The prompt registry this plugin contributes to. */
export const inject = ['systemPrompt']

/** User-configurable translation defaults. */
export interface Config {
  /** Source language name or `auto` for language detection. */
  sourceLanguage?: string
  /** Default target language name. */
  targetLanguage?: string
  /** Default translation register. */
  style?: TranslationStyle
  /** Return only translated text or a bilingual pairing. */
  outputMode?: OutputMode
  /** Preserve the source document's markup and layout. */
  preserveFormatting?: boolean
  /** Translate comments and docstrings while leaving code untouched. */
  translateCodeComments?: boolean
  /** Exact source-term to target-term preferences. */
  glossary?: Record<string, string>
  /** Extra deployment-specific translation requirements. */
  customInstructions?: string
  /** Retain workspace and other dynamic runtime snapshots. */
  includeRuntimeContext?: boolean
}

/** Runtime schema used by Cordis for validation and defaults. */
export const Config: z<Config> = z.object({
  sourceLanguage: z.string().default('auto'),
  targetLanguage: z.string().default('Simplified Chinese'),
  style: z.union([...TRANSLATION_STYLES]).default('natural'),
  outputMode: z.union([...OUTPUT_MODES]).default('target-only'),
  preserveFormatting: z.boolean().default(true),
  translateCodeComments: z.boolean().default(false),
  glossary: z.dict(String).default({}),
  customInstructions: z.string().default(''),
  includeRuntimeContext: z.boolean().default(false),
})

/** Register the complete translator persona. */
export function apply(ctx: Context, config: Config): void {
  const resolved = config as Required<Config>
  assertNonBlank('sourceLanguage', resolved.sourceLanguage)
  assertNonBlank('targetLanguage', resolved.targetLanguage)

  ctx.systemPrompt.section({
    name: 'app:translator',
    order: 0,
    text: buildTranslatorPrompt(resolved),
    complete: true,
  })
  if (!resolved.includeRuntimeContext) ctx.systemPrompt.suppressRuntimeContext()
}

function assertNonBlank(field: string, value: string): void {
  if (value.trim().length === 0) throw new Error(`dsh-translator: ${field} must not be blank`)
}
