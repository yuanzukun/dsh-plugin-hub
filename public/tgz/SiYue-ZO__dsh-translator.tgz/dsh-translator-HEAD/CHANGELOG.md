# Changelog

All notable changes to this project will be documented here.

## 0.2.0 — 2026-08-13

- Added a native two-pane dsh Web translation workspace.
- Added streaming output, stop, swap, copy, paste, speech, download, and file import.
- Added 12 languages, five styles, bilingual mode, formatting controls, and per-request requirements.
- Added a searchable 100-entry browser-local history and persistent UI settings.
- Added editable glossary parsing and JSON-isolated source prompts.
- Added a dsh-compatible Client bundle, CSS Modules, responsive layout, and Client type declarations.

## 0.1.0 — 2026-08-13

- Initial DeepSeek Harness bundle.
- Automatic source-language detection and configurable target language.
- Natural, professional, academic, technical, and literal styles.
- Target-only and bilingual output modes.
- Formatting, code, glossary, and custom-instruction controls.
