<div align="center">

# DSH Translator

**Turn DeepSeek Harness into a real AI translation application.**

[![DeepSeek Harness](https://img.shields.io/badge/DeepSeek-Harness-4D6BFE?style=flat-square)](https://github.com/deepseek-ai/deepseek-harness)
[![CI](https://img.shields.io/github/actions/workflow/status/SiYue-ZO/dsh-translator/ci.yml?style=flat-square&label=CI)](https://github.com/SiYue-ZO/dsh-translator/actions/workflows/ci.yml)
[![License](https://img.shields.io/badge/license-MIT-16a34a?style=flat-square)](LICENSE)

[中文](README.md) · [Install](#install) · [Features](#features) · [Architecture](#architecture)

</div>

---

DSH Translator is a native [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) plugin. It replaces the central chat surface with a two-pane translation workspace: choose languages, paste text, watch the result stream in, then copy, speak, download, or revisit it from history.

It introduces no translation API of its own. Translation uses the model selected in dsh and retains its credentials, sessions, and streaming transport.

> This release targets the dsh `0.1.0-rc.6` Web profile.

## Features

- Automatic source-language detection and configurable target language
- Native two-pane editor with a responsive mobile layout
- 12 common languages and one-click language/content swap
- Streaming result display with stop support
- Natural, professional, academic, technical, and literal styles
- Target-only and bilingual output modes
- Character/word counts and `Ctrl / ⌘ + Enter`
- Paste, copy, browser speech, and `.txt` download
- Text/Markdown/CSV/JSON/HTML/XML import up to 2 MB
- Searchable local history for the latest 100 translations
- Markdown, tables, HTML/XML tags, links, and placeholder preservation
- Editable terminology glossary and per-request requirements
- Optional copy-on-completion
- JSON-encoded untrusted source content to resist instruction-like source text
- No additional service or API key

## Install

> dsh is currently a developer preview. Use Node.js 22.19+ or 24+, with `dsh` and `pnpm` available.

Install the bundle into the official `web` profile:

```sh
dsh plugin --profile web add github:SiYue-ZO/dsh-translator
dsh web
```

Open the URL printed in the terminal (by default `http://127.0.0.1:3080`) and create a session. The translation workspace appears in the center column.

For a local checkout:

```sh
git clone https://github.com/SiYue-ZO/dsh-translator.git
cd dsh-translator
npm install
npm run check
dsh plugin --profile web add .
dsh web
```

Uninstall with:

```sh
dsh plugin --profile web remove dsh-translator
```

## Use

Choose source and target languages, paste the source, and select **Translate**. The button becomes **Stop translation** while the model is generating.

The source toolbar supports clipboard paste, text-file import, and clear. The result toolbar supports speech, download, and copy. Settings contain style, bilingual mode, formatting preservation, glossary entries in `source = target` form, and custom requirements. Browser settings and history remain in local storage.

## Configure

Defaults live in [`cordis.patch.yml`](cordis.patch.yml). A later dsh patch can override the row by `id`. dsh replaces a row's entire `config` rather than deep-merging it, so repeat every field in an override:

```yaml
- id: translator
  config:
    sourceLanguage: auto
    targetLanguage: Japanese
    style: professional
    outputMode: bilingual
    preserveFormatting: true
    translateCodeComments: false
    glossary:
      DeepSeek Harness: DeepSeek Harness
      agent: エージェント
      plugin: プラグイン
    customInstructions: 'Japanese punctuation must use the full-width style.'
    includeRuntimeContext: false
```

Apply it for one launch:

```sh
dsh --profile web --patch ./translator.override.yml
```

| Field | Default | Meaning |
| --- | --- | --- |
| `sourceLanguage` | `auto` | A source language name, or automatic detection |
| `targetLanguage` | `Simplified Chinese` | Default target language |
| `style` | `natural` | `natural`, `professional`, `academic`, `technical`, or `literal` |
| `outputMode` | `target-only` | `target-only` or `bilingual` |
| `preserveFormatting` | `true` | Preserve markup and layout where practical |
| `translateCodeComments` | `false` | Translate comments and docstrings |
| `glossary` | `{}` | Exact source-to-target term preferences |
| `customInstructions` | `''` | Additional translation rules |
| `includeRuntimeContext` | `false` | Include dynamic workspace context in model requests |

## Architecture

The Host half registers a complete translation persona through dsh/Cordis. The Web half occupies dsh's native `conversation` slot and calls `SessionFace.prompt/cancel`, preserving dsh's selected model and streaming pipeline. Dynamic workspace context is disabled by default.

Each translation creates a request with its own language, style, glossary, and layout controls. Source text is placed in a JSON string explicitly marked as untrusted data so instruction-like content is translated rather than followed. History and UI preferences stay in browser local storage.

## Develop

```sh
npm install
npm run check
npm pack --dry-run
```

`npm run build` compiles the Host entry, Client types, and dsh-compatible `lib/client.js`. Tests cover the persona, request isolation, glossary parsing, and Cordis registration.

## Limitations

- Quality, context length, and language coverage depend on the selected model.
- This release targets text and plain-text files; it does not parse PDF, DOCX, images, or audio.
- History is browser-local and disappears if site storage is cleared.
- dsh is a developer preview, so future breaking API changes may require an update.

## License

[MIT](LICENSE) © 2026 SiYue-ZO
