<#
.SYNOPSIS
  构建本插件（类型检查 + 打包浏览器 bundle）。

.DESCRIPTION
  本仓库通过目录联接（junction）挂入 DeepSeek Harness monorepo 的
  packages/client/ui-knowledge-cards，构建使用 monorepo 内的
  tsdown 预设与 tsconfig 引用。tsc 的 project references 按路径字符串
  解析，必须从 monorepo 真实路径执行；本脚本自动解析联接目标并切换。

  `pnpm run bundle` 可以直接在仓库路径执行（pnpm 会 realpath），
  但 `tsc -b` 不行--所以统一用本脚本。

.EXAMPLE
  ./scripts/build.ps1            # tsc -b + bundle
  ./scripts/build.ps1 -Watch     # tsc -b + watch 模式
#>
param([switch]$Watch)

# 注意：不设 $ErrorActionPreference = 'Stop' -- pnpm 的 stderr 横幅会被
# PowerShell 升级为终止错误；这里改用退出码判断。

# 解析本脚本所在的包根目录（兼容 junction 视图与物理路径两种调用方式）
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pkgRoot = Split-Path -Parent $scriptDir
$item = Get-Item $pkgRoot -Force
$physical = if ($item.LinkType -eq 'Junction') { $item.Target } else { $pkgRoot }

if (-not (Test-Path (Join-Path $physical '..\tsdown.client.ts'))) {
    throw "未找到 monorepo 构建预设（$physical 的上级缺 tsdown.client.ts）- 请确认 junction 指向 DSH checkout 的 packages/client/ui-knowledge-cards"
}

Write-Host "==> 构建于 $physical"
Push-Location $physical
try {
    pnpm exec tsc -b
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    if ($Watch) {
        pnpm run watch
    } else {
        pnpm run bundle
        if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    }
} finally {
    Pop-Location
}
