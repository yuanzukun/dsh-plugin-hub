<#
.SYNOPSIS
  一条命令完成版本对齐发布：GitHub tag + npm 版本同号同源。

.DESCRIPTION
  版本对齐机制（本脚本的执行顺序就是保证）：
    仓库 package.json 的 "version" 是唯一事实源
      -> 写入新版本号
      -> 构建（lib/ 与该版本同源）
      -> 提交 + 打 tag v<版本>
      -> 推送 GitHub（tag 指向该版本的确切提交）
      -> pnpm publish（npm 从同一提交打包，files 字段决定内容）
    最终：git tag v<x.y.z> == npm 版本 x.y.z == 该提交里的 package.json version

  npm 版本不可变、不可覆盖：发布失败直接重跑（版本号只有 npm 接受后才算占用）；
  发布成功后发现问题 -> 修完 bump 下一个版本号重来。

.EXAMPLE
  ./scripts/release.ps1 -Version 0.1.3                # 完整发布
  ./scripts/release.ps1 -Version 0.1.3 -SkipPublish   # 只发 GitHub，不发 npm
#>
param(
    [Parameter(Mandatory = $true)]
    [string]$Version,
    [switch]$SkipPublish
)

$pkgName = '@wangxueqi/dsh-client-ui-knowledge-cards'
$tag = "v$Version"

# ── 校验 ─────────────────────────────────────────────────────────────────────
if ($Version -notmatch '^\d+\.\d+\.\d+(-[\w.]+)?$') {
    throw "版本号格式无效: $Version（期望如 0.1.2）"
}

Write-Host "==> 检查 npm 上 $Version 是否已存在..."
$existing = pnpm view "$pkgName@$Version" version 2>$null
if ($LASTEXITCODE -eq 0 -and $existing) {
    throw "npm 上已存在 $pkgName@$Version（版本不可覆盖）-- 请换一个版本号"
}
Write-Host "    可用 ✓"

Write-Host "==> 检查本地 tag $tag 是否已存在..."
if (git rev-parse -q --verify "refs/tags/$tag" 2>$null) {
    throw "本地已存在 tag $tag -- 请换一个版本号"
}

# ── 1. 写入版本号（唯一事实源）──────────────────────────────────────────────
Write-Host "==> package.json version -> $Version"
$pkgPath = Join-Path (Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)) 'package.json'
$raw = [System.IO.File]::ReadAllText($pkgPath)
$updated = $raw -replace '"version"\s*:\s*"[^"]*"', ('"version": "' + $Version + '"')
if ($updated -eq $raw -and ($raw -notmatch '"version"\s*:\s*"' + [regex]::Escape($Version) + '"')) {
    throw 'package.json 中未找到 version 字段'
}
# 显式无 BOM 的 UTF-8（Set-Content 在部分 PowerShell 版本会写 BOM，tsdown 不容忍）
[System.IO.File]::WriteAllText($pkgPath, $updated, [System.Text.UTF8Encoding]::new($false))

# ── 2. 构建（lib/ 与该版本同源）────────────────────────────────────────────
Write-Host "==> 构建..."
$buildScript = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'build.ps1'
& $buildScript
if ($LASTEXITCODE -ne 0) { throw "构建失败" }

# ── 3. 提交 + 打 tag ────────────────────────────────────────────────────────
Write-Host "==> git 提交 + tag $tag"
git add .
if ($LASTEXITCODE -ne 0) { throw "git add 失败" }
git commit -m "release: $tag"
if ($LASTEXITCODE -ne 0) { throw "git commit 失败" }
git tag $tag
if ($LASTEXITCODE -ne 0) { throw "git tag 失败" }

# ── 4. 推送 GitHub ─────────────────────────────────────────────────────────
Write-Host "==> 推送 GitHub（含 tag）..."
git push origin main --tags
if ($LASTEXITCODE -ne 0) {
    Write-Warning "GitHub 推送失败。tag 已建在本地；网络恢复后执行："
    Write-Warning "  git push origin main --tags"
    Write-Warning "npm 先不要发（保持 tag 先于 npm 的顺序）。"
    exit 1
}

# ── 5. 发布 npm ────────────────────────────────────────────────────────────
if ($SkipPublish) {
    Write-Host "==> 已跳过 npm 发布（-SkipPublish）。后续手动执行："
    Write-Host "  pnpm publish --no-git-checks"
    exit 0
}

Write-Host "==> pnpm publish..."
pnpm publish --no-git-checks
if ($LASTEXITCODE -ne 0) {
    Write-Warning "npm 发布失败。修复问题后从同一提交直接重跑（无需换版本号）："
    Write-Warning "  pnpm publish --no-git-checks"
    exit 1
}

# ── 6. 验证 ────────────────────────────────────────────────────────────────
Write-Host "==> 验证..."
Start-Sleep -Seconds 2
$published = pnpm view "$pkgName@$Version" version 2>$null
if ($LASTEXITCODE -eq 0 -and $published -eq $Version) {
    Write-Host ""
    Write-Host "发布完成，版本已对齐："
    Write-Host "  GitHub tag : $tag"
    Write-Host "  npm 版本   : $Version"
    Write-Host "  用户安装   : dsh plugin --profile web add $pkgName"
    Write-Host "              dsh plugin --profile web add github:wangxueqi00/dsh-client-ui-knowledge-cards#$tag"
} else {
    Write-Warning "npm 上暂时查不到 $Version（registry 可能有延迟，稍后用 pnpm view $pkgName versions 确认）"
}
