import { clientBundle } from '../tsdown.client.ts'

const base = clientBundle('@wangxueqi/dsh-client-ui-knowledge-cards', ['lib/types/index.js', 'lib/types/invariant.js'])

// Mermaid must be inlined into the single-file client bundle: the DSH module
// loader's require() only answers declared externals, so the code-split
// chunks produced by dynamic import('mermaid') (and mermaid's own internal
// lazy diagram imports) cannot be fetched at runtime — rendering silently
// falls back to raw text. inlineDynamicImports folds every dynamic import
// back into lib/client.js.
export default (args: Parameters<typeof base>[0]) => {
  const configs = base(args)
  for (const config of configs) {
    if (typeof config === 'object' && config !== null && 'name' in config && config.name === '@wangxueqi/dsh-client-ui-knowledge-cards/client') {
      config.outputOptions = { ...(config.outputOptions ?? {}), inlineDynamicImports: true }
    }
  }
  return configs
}
