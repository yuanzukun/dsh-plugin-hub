export interface MermaidDiagramProps {
    /** Mermaid chart code. */
    chart: string;
    /** Callback receiving the rendered SVG string (for download). */
    onSvgReady?: (svg: string | undefined) => void;
}
export declare function MermaidDiagram({ chart, onSvgReady }: MermaidDiagramProps): import("react").JSX.Element;
//# sourceMappingURL=MermaidDiagram.d.ts.map