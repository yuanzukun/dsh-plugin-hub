import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client';
import type { CardsKey } from '../locales.ts';
/** Full props: framework kit + locale + injected send + close callback. */
export interface CardDialogProps {
    useSession: <T>(selector: (snapshot: import('@deepseek-ai/dsh-client-runtime/client').ConversationSnapshot) => T) => T;
    sessionId: SessionId;
    t: (key: CardsKey, params?: Record<string, string>) => string;
    send: (text: string) => Promise<void>;
    loadOlder: () => Promise<void>;
    onClose: () => void;
}
export declare function CardDialog({ useSession, sessionId, t, send, loadOlder, onClose }: CardDialogProps): import("react").JSX.Element;
//# sourceMappingURL=CardDialog.d.ts.map