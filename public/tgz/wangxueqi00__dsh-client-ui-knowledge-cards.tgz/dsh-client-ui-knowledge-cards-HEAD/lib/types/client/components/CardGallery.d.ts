import type { KnowledgeCard } from '../card-generator.ts';
import type { CardsKey } from '../locales.ts';
export interface CardGalleryProps {
    cards: readonly KnowledgeCard[];
    loading: boolean;
    t: (key: CardsKey, params?: Record<string, string>) => string;
    onRegenerate: (card: KnowledgeCard) => void;
    onRegenerateAll: () => void;
    onClose: () => void;
}
export declare function CardGallery({ cards, loading, t, onRegenerate, onRegenerateAll, onClose }: CardGalleryProps): import("react").JSX.Element;
//# sourceMappingURL=CardGallery.d.ts.map