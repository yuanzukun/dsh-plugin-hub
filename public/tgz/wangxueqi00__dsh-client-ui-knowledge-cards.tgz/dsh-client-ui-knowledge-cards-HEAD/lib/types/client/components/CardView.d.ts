import type { KnowledgeCard } from '../card-generator.ts';
import type { CardsKey } from '../locales.ts';
export interface CardViewProps {
    card: KnowledgeCard;
    /** Currently selected download format (controlled). */
    format: string;
    /** Called when the user picks a different format. */
    onFormatChange: (cardId: string, format: string) => void;
    /** Locale translation seat. */
    t: (key: CardsKey, params?: Record<string, string>) => string;
    /** Regenerate this card. */
    onRegenerate: (card: KnowledgeCard) => void;
}
export declare function CardView({ card, format, onFormatChange, t, onRegenerate }: CardViewProps): import("react").JSX.Element;
//# sourceMappingURL=CardView.d.ts.map