import type { InjectFace, PropsRuntime, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import { NS, type CardsKey } from '../locales.ts';
/** Injected: a send callback bound to this session's conversation service. */
export interface CardButtonInjected {
    send: (text: string) => Promise<void>;
    loadOlder: () => Promise<void>;
}
/** Full props: framework kit + locale + injected sender. */
export type CardButtonProps = PropsRuntime<'conversation.session.header.actions'> & PropsLocale<typeof NS> & InjectFace<CardButtonInjected>;
export declare function CardButton(props: CardButtonProps): import("react").JSX.Element;
export { NS };
export type { CardsKey };
//# sourceMappingURL=CardButton.d.ts.map