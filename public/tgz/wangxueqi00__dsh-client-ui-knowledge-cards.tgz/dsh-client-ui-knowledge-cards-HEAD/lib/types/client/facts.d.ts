/**
 * Session-level facts extracted from conversation turns.
 *
 * Timeline and checklist cards are built deterministically from this facts
 * store rather than by re-summarizing the raw conversation each time. Facts
 * are parsed from the Agent's ```facts JSON block, merged across generations
 * (deduplicated by text), and turned into Mermaid timeline / Markdown
 * checklist content on the client.
 */
import type { KnowledgeCard } from './card-generator.ts';
/** A single timeline event. */
export interface FactEvent {
    /** Optional time label, e.g. "2026-08-21". */
    at?: string;
    /** Event description. */
    text: string;
}
/** A single action item. */
export interface FactTodo {
    /** Action text. */
    text: string;
    /** Whether it is completed. */
    done?: boolean;
}
/** A single conclusion / quote-worthy sentence. */
export interface FactConclusion {
    /** Conclusion text. */
    text: string;
}
/** The complete fact set for one session. */
export interface SessionFacts {
    events: FactEvent[];
    todos: FactTodo[];
    conclusions: FactConclusion[];
}
/** An empty fact set. */
export declare function emptyFacts(): SessionFacts;
/**
 * Parse the first ```facts JSON block from an Agent response.
 * Returns null when no block is present or the JSON is malformed.
 */
export declare function parseFactsFromText(text: string): SessionFacts | null;
/** Merge two fact sets, deduplicating by normalized text. */
export declare function mergeFacts(prev: SessionFacts, next: SessionFacts): SessionFacts;
/** Build Mermaid `timeline` source from facts. */
export declare function factsToTimelineMermaid(facts: SessionFacts): string;
/** Build Markdown checklist content from facts. */
export declare function factsToChecklistMarkdown(facts: SessionFacts): string;
/** Build a timeline card from facts. */
export declare function buildTimelineCard(facts: SessionFacts, topic: string, sourceTurns: readonly number[]): KnowledgeCard;
/** Build a checklist card from facts. */
export declare function buildChecklistCard(facts: SessionFacts, topic: string, sourceTurns: readonly number[]): KnowledgeCard;
//# sourceMappingURL=facts.d.ts.map