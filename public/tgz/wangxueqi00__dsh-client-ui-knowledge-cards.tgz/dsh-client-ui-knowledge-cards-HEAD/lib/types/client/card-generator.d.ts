/**
 * Card type definitions, theme color mapping, and Agent-directive builders.
 *
 * The Agent (LLM) generates cards via conversation.send() — this module
 * constructs the prompt directives and defines the data shapes the browser
 * parses back from the Agent's ```card JSON code blocks.
 *
 * Timeline and checklist cards are generated differently: the Agent first
 * emits a ```facts JSON block (see facts.ts), and the client deterministically
 * builds the timeline/checklist cards from those facts. This keeps those two
 * "whole-history" card types stable, deduplicated and incrementally mergeable.
 */
import type { TurnContent } from './card-data-collector.ts';
import type { SessionFacts } from './facts.ts';
/** Supported knowledge-card visual types. */
export type CardType = 'concept' | 'flowchart' | 'comparison' | 'summary' | 'mindmap' | 'quote' | 'checklist' | 'timeline' | 'faq';
/** A single generated knowledge card. */
export interface KnowledgeCard {
    /** Stable runtime id (crypto.randomUUID). */
    id: string;
    /** Visual layout type. */
    type: CardType;
    /** Card heading. */
    title: string;
    /** Card body: Markdown text or Mermaid code (for flowchart/mindmap/timeline). */
    content: string;
    /** Source conversation turns. */
    sourceTurns: readonly number[];
    /** Topic this card belongs to. */
    topic: string;
}
/** A topic detected by auto-split or defined by manual turn selection. */
export interface Topic {
    /** Display title. */
    title: string;
    /** Turn numbers covered by this topic. */
    turns: readonly number[];
    /** One-line summary. */
    summary: string;
}
/** Theme color per card type — low-saturation, textured, not flashy. */
export interface CardTheme {
    /** Primary accent color. */
    theme: string;
    /** Light background tint. */
    bg: string;
    /** Border color. */
    border: string;
    /** Emoji icon. */
    icon: string;
    /** Short label (localized externally, but a stable fallback here). */
    label: string;
}
/** Color mapping: each card type gets its own restrained accent. */
export declare const CARD_THEMES: Record<CardType, CardTheme>;
/** All card types in display order. */
export declare const ALL_CARD_TYPES: readonly CardType[];
/** Whether a card type is rendered through the Mermaid renderer. */
export declare function isMermaidCardType(type: CardType): boolean;
/**
 * Build the /generate-cards directive sent to the Agent.
 *
 * For timeline/checklist the prompt asks the Agent for a ```facts block
 * first; the client then builds those two cards deterministically from the
 * merged facts (see facts.ts). All other types are emitted by the Agent as
 * ```card blocks as before.
 */
export declare function buildGenerateCardsPrompt(topic: Topic, turns: readonly TurnContent[], cardTypes: readonly CardType[], existingFacts?: SessionFacts, factsTurns?: readonly TurnContent[]): string;
/**
 * Build the /split-topics directive for auto topic detection.
 */
export declare function buildSplitTopicsPrompt(turns: readonly TurnContent[]): string;
/**
 * Build the /regenerate-card directive for a single card.
 */
export declare function buildRegenerateCardPrompt(card: KnowledgeCard): string;
//# sourceMappingURL=card-generator.d.ts.map