/**
 * Parses Agent output (assistant message text) to extract structured card
 * and topic JSON from fenced code blocks.
 *
 * The Agent emits ```card and ```topics code blocks per the systemPrompt
 * guidance; this module finds and validates them.
 */
import type { KnowledgeCard, Topic } from './card-generator.ts';
/**
 * Parse all ```card JSON blocks from a text string.
 * Returns KnowledgeCard[] with runtime ids assigned.
 */
export declare function parseCardsFromText(text: string, sourceTurns?: readonly number[], topic?: string): KnowledgeCard[];
/**
 * Parse all ```topics JSON blocks from a text string.
 * Returns Topic[].
 */
export declare function parseTopicsFromText(text: string): Topic[];
/**
 * Parse a single regenerated card from text (the first ```card block).
 */
export declare function parseRegeneratedCard(text: string, original: KnowledgeCard): KnowledgeCard | null;
/**
 * Check if the text contains the knowledge-cards-generated marker.
 */
export declare function hasGenerationMarker(text: string): boolean;
//# sourceMappingURL=card-parser.d.ts.map