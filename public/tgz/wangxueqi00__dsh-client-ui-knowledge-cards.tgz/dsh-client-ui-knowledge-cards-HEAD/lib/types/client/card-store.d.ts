/**
 * Module-level card store: persists knowledge cards across dialog open/close.
 *
 * CardButton (always mounted) monitors the conversation and pushes parsed
 * cards here; CardDialog reads from here so closing the dialog does not lose
 * state or stop background generation.
 */
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client';
import type { KnowledgeCard, CardType } from './card-generator.ts';
import { type SessionFacts } from './facts.ts';
type CardListener = (cards: KnowledgeCard[]) => void;
type StatusListener = (status: GenerationStatus) => void;
/** A pending card-generation request (types + source range). */
export interface PendingRequest {
    types: readonly CardType[];
    topic: string;
    /** Turn numbers used for model-rendered cards (manual selection or all). */
    sourceTurns: readonly number[];
    /** Turn numbers used for facts extraction (whole history for timeline/checklist). */
    factsTurns: readonly number[];
}
export type GenerationStatus = {
    phase: 'idle';
} | {
    phase: 'generating';
    sessionId: SessionId;
} | {
    phase: 'ready';
    sessionId: SessionId;
    count: number;
} | {
    phase: 'error';
    sessionId: SessionId;
    message: string;
};
export declare function getCards(sessionId: SessionId): KnowledgeCard[];
export declare function setCards(sessionId: SessionId, cards: KnowledgeCard[]): void;
export declare function updateCard(sessionId: SessionId, card: KnowledgeCard): void;
export declare function subscribeCards(sessionId: SessionId, fn: CardListener): () => void;
export declare function getStatus(sessionId: SessionId): GenerationStatus;
export declare function setStatus(sessionId: SessionId, status: GenerationStatus): void;
export declare function subscribeStatus(sessionId: SessionId, fn: StatusListener): () => void;
export declare function getLastCheckedSeq(sessionId: SessionId): number;
export declare function setLastCheckedSeq(sessionId: SessionId, seq: number): void;
export declare function getWaitingFor(sessionId: SessionId): 'cards' | 'topics' | 'regenerate' | null;
export declare function setWaitingFor(sessionId: SessionId, val: 'cards' | 'topics' | 'regenerate' | null): void;
export declare function getRegeneratingId(sessionId: SessionId): string | null;
export declare function setRegeneratingId(sessionId: SessionId, id: string | null): void;
export declare function setPendingRequest(sessionId: SessionId, request: PendingRequest): void;
export declare function getPendingRequest(sessionId: SessionId): PendingRequest | null;
export declare function clearPendingRequest(sessionId: SessionId): void;
export declare function getFacts(sessionId: SessionId): SessionFacts;
export declare function setFacts(sessionId: SessionId, facts: SessionFacts): void;
export declare function mergeFacts(sessionId: SessionId, facts: SessionFacts): SessionFacts;
/**
 * Record the current latest assistant seq so we only look at messages after this.
 */
export declare function recordCurrentSeq(sessionId: SessionId, nodes: readonly {
    kind: string;
    seq: number;
}[]): void;
export {};
//# sourceMappingURL=card-store.d.ts.map