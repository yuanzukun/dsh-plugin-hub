/**
 * Knowledge-cards plugin, browser half: registers the header action button
 * into the conversation session header, with an injected send callback that
 * routes /generate-cards directives to the session's agent conversation.
 *
 * All policy lives here - the topic splitting mode, card type selection,
 * Agent output parsing, and download - so composing this plugin out of
 * cordis.yml removes the entire surface at zero cost.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type CardsKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Knowledge-cards copy: button, dialog, gallery, card actions. */
        'cards': CardsKey;
    }
}
export { CardButton } from './components/CardButton.tsx';
export type { CardButtonInjected } from './components/CardButton.tsx';
export { collectTurns, type TurnContent } from './card-data-collector.ts';
export { type KnowledgeCard, type Topic, type CardType, CARD_THEMES, ALL_CARD_TYPES, } from './card-generator.ts';
export { parseCardsFromText, parseTopicsFromText, hasGenerationMarker } from './card-parser.ts';
export { downloadAsMarkdown, downloadAsHtml, downloadAsSvg } from './download.ts';
export { getCards, subscribeCards, getStatus, subscribeStatus, type GenerationStatus } from './card-store.ts';
/** Required services for the header-action registration. */
export declare const inject: string[];
/**
 * Client plugin body: register dictionaries and the header action button.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map