/**
 * Conversation data collector: extracts turn-by-turn text from the
 * ConversationSnapshot for card generation.
 *
 * Data path (verified by source exploration):
 *   snapshot.nodes: ConversationNode[]  ← direct node array, no chat.nodes hop
 *   UserMessageNode.content: ContentBlock[] ← filter type==='text' -> .text
 *   AssistantMessageNode.blocks: AssistantBlock[] ← filter kind==='text' -> .text
 *   AssistantMessageNode.turn: number ← turn id
 */
import type { ConversationSnapshot, AssistantBlock } from '@deepseek-ai/dsh-client-runtime/client';
/** One conversation turn's collected text. */
export interface TurnContent {
    /** Turn number (from AssistantMessageNode.turn). */
    turn: number;
    /** Node sequence number for ordering. */
    seq: number;
    /** User's prompt text, or null. */
    userText: string | null;
    /** Assistant response text blocks (one per step). */
    assistantTexts: string[];
    /** Reasoning text blocks (optional, usually excluded from cards). */
    reasoningTexts: string[];
    /** Tool call names for context. */
    toolCalls: string[];
    /** Timestamp of the latest message in this turn. */
    timestamp: number;
}
/**
 * Collect all conversation turns from a session snapshot.
 *
 * User messages have no `turn` field, so they attach to the nearest following
 * assistant turn by seq proximity. A user message before any assistant message
 * gets its own pseudo-turn keyed by seq.
 */
export declare function collectTurns(snapshot: ConversationSnapshot): TurnContent[];
/**
 * Merge a turn's text into a single string for prompt building.
 */
export declare function turnToText(tc: TurnContent): string;
/**
 * Whether the session has older history that can be loaded.
 */
export declare function needsLoadOlder(snapshot: ConversationSnapshot): boolean;
/**
 * Extract text blocks from an assistant message's blocks array.
 * Used by the parser to scan Agent card output.
 */
export declare function getAssistantTextBlocks(blocks: readonly AssistantBlock[]): string[];
//# sourceMappingURL=card-data-collector.d.ts.map