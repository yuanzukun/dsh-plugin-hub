/**
 * Mermaid diagram renderer with a custom low-saturation theme that matches
 * the card visual quality: light node fills, themed borders, muted lines.
 *
 * Mermaid is loaded dynamically so it never affects the initial bundle size.
 */
/**
 * Render a Mermaid diagram into a container element.
 * On parse error, shows the raw code as a fallback.
 */
export declare function renderMermaid(code: string, container: HTMLElement): Promise<string | undefined>;
/** Render Mermaid and return the SVG string (for download). */
export declare function mermaidToSvg(code: string): Promise<string | undefined>;
//# sourceMappingURL=mermaid-renderer.d.ts.map