/**
 * Card download utilities: export a KnowledgeCard as Markdown, standalone
 * HTML (inline CSS + Mermaid CDN), or SVG (Mermaid flowchart only).
 *
 * The standalone HTML preserves the on-screen card's visual quality:
 * low-saturation theme colors, rounded corners, soft shadows.
 */
import type { KnowledgeCard } from './card-generator.ts';
/**
 * Download card as a Markdown file.
 */
export declare function downloadAsMarkdown(card: KnowledgeCard): void;
/**
 * Download card as a JSON file (raw structured data).
 */
export declare function downloadAsJson(card: KnowledgeCard): void;
/**
 * Download card as a plain-text file (no Markdown formatting).
 */
export declare function downloadAsText(card: KnowledgeCard): void;
/**
 * Download card as a standalone HTML file with inline card CSS.
 * For flowchart/mindmap types, Mermaid CDN is loaded to render the diagram.
 */
export declare function downloadAsHtml(card: KnowledgeCard): void;
/**
 * Download a card as SVG.
 *
 * Mermaid cards (flowchart/mindmap/timeline) use the rendered Mermaid SVG.
 * Markdown cards (concept/comparison/summary/quote/checklist/faq) are
 * rendered into a self-contained SVG text card by buildCardSvg().
 *
 * The input may come from `mermaid.render()` (well-formed) or from
 * `svgEl.outerHTML` (HTML serialization: `<br>` unclosed, which breaks
 * XML parsers when the browser opens the .svg file). normalizeSvgXml
 * parses tolerantly as HTML and re-serializes through XMLSerializer so
 * the downloaded file is always well-formed standalone XML.
 */
export declare function downloadAsSvg(card: KnowledgeCard, svgContent?: string): Promise<void>;
/**
 * Render a non-Mermaid card into a self-contained SVG card.
 * Mirrors the on-screen card visual: rounded card, theme top bar, themed
 * header background, badge, title, and styled body lines.
 */
export declare function buildCardSvg(card: KnowledgeCard): string;
//# sourceMappingURL=download.d.ts.map