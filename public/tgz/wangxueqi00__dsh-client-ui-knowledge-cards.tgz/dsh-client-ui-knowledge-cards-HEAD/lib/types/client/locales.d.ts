/** `cards` namespace dictionaries for the knowledge-cards plugin. */
/** Dictionary namespace owned by this plugin. */
export declare const NS = "cards";
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'button.label': string;
    'button.tooltip': string;
    'dialog.title': string;
    'dialog.turns': string;
    'dialog.turn': string;
    'dialog.cardTypes': string;
    'dialog.type.concept': string;
    'dialog.type.flowchart': string;
    'dialog.type.comparison': string;
    'dialog.type.summary': string;
    'dialog.type.mindmap': string;
    'dialog.type.quote': string;
    'dialog.type.checklist': string;
    'dialog.type.timeline': string;
    'dialog.type.faq': string;
    'dialog.selectAll': string;
    'dialog.deselectAll': string;
    'dialog.generate': string;
    'dialog.cancel': string;
    'dialog.generating': string;
    'dialog.noTurns': string;
    'dialog.range.title': string;
    'dialog.range.selected': string;
    'dialog.range.all': string;
    'dialog.range.loading': string;
    'dialog.range.allHint': string;
    'dialog.range.timelineHint': string;
    'gallery.title': string;
    'gallery.empty': string;
    'gallery.downloadAll': string;
    'gallery.hint': string;
    'gallery.regenerateAll': string;
    'gallery.close': string;
    'card.download': string;
    'card.download.md': string;
    'card.download.html': string;
    'card.download.svg': string;
    'card.download.json': string;
    'card.download.txt': string;
    'card.download.btn': string;
    'card.regenerate': string;
    'card.type.concept': string;
    'card.type.flowchart': string;
    'card.type.comparison': string;
    'card.type.summary': string;
    'card.type.mindmap': string;
    'card.type.quote': string;
    'card.type.checklist': string;
    'card.type.timeline': string;
    'card.type.faq': string;
    'card.source': string;
    'notice.generated': string;
    'notice.regenerating': string;
    'notice.regenerated': string;
    'notice.parseError': string;
    'notice.generationComplete': string;
    'badge.cards': string;
};
/** English dictionary (same key set). */
export declare const en: Record<CardsKey, string>;
/** Union of this namespace's dictionary keys. */
export type CardsKey = keyof typeof zh;
//# sourceMappingURL=locales.d.ts.map