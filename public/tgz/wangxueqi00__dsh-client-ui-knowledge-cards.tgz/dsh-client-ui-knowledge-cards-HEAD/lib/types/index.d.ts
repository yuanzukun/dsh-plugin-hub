/**
 * Knowledge-cards plugin, node half: registers the system-prompt guidance that
 * teaches the Agent to respond to `/generate-cards` and `/split-topics`
 * directives with structured card/topic JSON the browser half renders.
 *
 * The browser half ships via exports["./client"], discovered through the
 * package.json dsh.client declaration.
 */
import type { Context } from '@deepseek-ai/cordis';
/** Services required for the model guidance. */
export declare const inject: string[];
/**
 * Register model guidance for the card renderer shipped by this package.
 * @param ctx - host context carrying the system-prompt registry.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map