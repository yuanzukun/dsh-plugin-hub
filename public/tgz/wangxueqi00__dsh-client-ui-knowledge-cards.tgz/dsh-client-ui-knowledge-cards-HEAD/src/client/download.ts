/**
 * Card download utilities: export a KnowledgeCard as Markdown, standalone
 * HTML (inline CSS + Mermaid CDN), or SVG (Mermaid flowchart only).
 *
 * The standalone HTML preserves the on-screen card's visual quality:
 * low-saturation theme colors, rounded corners, soft shadows.
 */

import type { KnowledgeCard } from './card-generator.ts'
import { CARD_THEMES, isMermaidCardType } from './card-generator.ts'

/** Escape HTML special characters. */
function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

/** Sanitize a string into a safe filename. */
function safeFilename(title: string): string {
  return title.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').trim() || 'card'
}

/** Trigger a browser download from a Blob. */
function downloadBlob(content: string, mime: string, filename: string): void {
  const blob = new Blob([content], { type: `${mime};charset=utf-8` })
  const url = URL.createObjectURL(blob)
  triggerDownload(url, filename)
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

/** Trigger a browser download from a URL. */
function triggerDownload(url: string, filename: string): void {
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.style.display = 'none'
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
}

/**
 * Download card as a Markdown file.
 */
export function downloadAsMarkdown(card: KnowledgeCard): void {
  const lines: string[] = [
    `# ${card.title}`,
    '',
    `> 类型: ${card.type} | 来源: Turn ${card.sourceTurns.join(', ')}`,
    '',
    card.content,
    '',
  ]
  downloadBlob(lines.join('\n'), 'text/markdown', `${safeFilename(card.title)}.md`)
}

/**
 * Download card as a JSON file (raw structured data).
 */
export function downloadAsJson(card: KnowledgeCard): void {
  const data = {
    id: card.id,
    type: card.type,
    title: card.title,
    content: card.content,
    sourceTurns: card.sourceTurns,
  }
  downloadBlob(JSON.stringify(data, null, 2), 'application/json', `${safeFilename(card.title)}.json`)
}

/**
 * Download card as a plain-text file (no Markdown formatting).
 */
export function downloadAsText(card: KnowledgeCard): void {
  const lines: string[] = [
    card.title,
    '',
    `Type: ${card.type}`,
    `Source: Turn ${card.sourceTurns.join(', ')}`,
    '',
    card.content,
    '',
  ]
  downloadBlob(lines.join('\n'), 'text/plain', `${safeFilename(card.title)}.txt`)
}

/**
 * Download card as a standalone HTML file with inline card CSS.
 * For flowchart/mindmap types, Mermaid CDN is loaded to render the diagram.
 */
export function downloadAsHtml(card: KnowledgeCard): void {
  const t = CARD_THEMES[card.type]
  const isMermaid = isMermaidCardType(card.type)
  const filename = `${safeFilename(card.title)}.html`

  const html = buildStandaloneHtml(card, t, isMermaid)
  downloadBlob(html, 'text/html', filename)
}

/**
 * Download a card as SVG.
 *
 * Mermaid cards (flowchart/mindmap/timeline) use the rendered Mermaid SVG.
 * Markdown cards (concept/comparison/summary/quote/checklist/faq) are
 * rendered into a self-contained SVG text card by buildCardSvg().
 *
 * The input may come from `mermaid.render()` (well-formed) or from
 * `svgEl.outerHTML` (HTML serialization: `<br>` unclosed, which breaks
 * XML parsers when the browser opens the .svg file). normalizeSvgXml
 * parses tolerantly as HTML and re-serializes through XMLSerializer so
 * the downloaded file is always well-formed standalone XML.
 */
export async function downloadAsSvg(card: KnowledgeCard, svgContent?: string): Promise<void> {
  const svg = isMermaidCardType(card.type)
    ? (svgContent === undefined ? undefined : normalizeSvgXml(svgContent))
    : buildCardSvg(card)

  if (svg === undefined) return

  const filename = `${safeFilename(card.title)}.svg`
  downloadBlob(svg, 'image/svg+xml', filename)
}

/**
 * Render a non-Mermaid card into a self-contained SVG card.
 * Mirrors the on-screen card visual: rounded card, theme top bar, themed
 * header background, badge, title, and styled body lines.
 */
export function buildCardSvg(card: KnowledgeCard): string {
  const t = CARD_THEMES[card.type]
  const width = 720
  const cardX = 20
  const cardY = 20
  const cardWidth = width - cardX * 2
  const padX = 40
  const headerHeight = 44
  const titleSize = 20
  const lineSize = 15
  const lineHeight = 23
  const maxWidthUnits = 44

  const badge = `${t.icon} ${t.label}`
  const bodyLines = markdownToStyledLines(card.content)
    .flatMap((line) => wrapStyledLine(line, maxWidthUnits))

  const headerBottom = cardY + 4 + headerHeight
  const badgeY = cardY + 28
  const titleY = headerBottom + 32
  const bodyStartY = titleY + 28
  const bodyHeight = Math.max(1, bodyLines.length) * lineHeight
  const svgHeight = bodyStartY + bodyHeight + 24
  const cardHeight = svgHeight - cardY * 2

  const parts: string[] = [
    `<?xml version="1.0" encoding="UTF-8"?>`,
    `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${svgHeight}" viewBox="0 0 ${width} ${svgHeight}">`,
    `<rect x="${cardX}" y="${cardY}" width="${cardWidth}" height="${cardHeight}" rx="12" fill="#ffffff" stroke="${t.border}" stroke-width="1"/>`,
    `<rect x="${cardX}" y="${cardY}" width="${cardWidth}" height="4" rx="2" fill="${t.theme}"/>`,
    `<rect x="${cardX}" y="${cardY + 4}" width="${cardWidth}" height="${headerHeight}" fill="${t.bg}"/>`,
    `<text x="${padX}" y="${badgeY}" font-size="12" font-weight="600" fill="${t.theme}">${escapeXml(badge)}</text>`,
    `<text x="${padX}" y="${titleY}" font-size="${titleSize}" font-weight="600" fill="#1a1a2e">${escapeXml(card.title)}</text>`,
  ]

  bodyLines.forEach((line, i) => {
    const y = bodyStartY + i * lineHeight
    const style = lineStyle(line.kind, t.theme)
    parts.push(`<text x="${padX}" y="${y}" font-size="${lineSize}" ${style}>${escapeXml(line.text)}</text>`)
  })

  parts.push('</svg>')
  return parts.join('\n')
}

/** SVG attributes for a styled body line. */
function lineStyle(kind: LineKind, theme: string): string {
  if (kind === 'heading') {
    return `fill="${theme}" font-weight="600"`
  }
  if (kind === 'quote') {
    return `fill="#555" font-style="italic"`
  }
  if (kind === 'code') {
    return `fill="#333" font-family="Consolas, 'Courier New', monospace"`
  }
  return `fill="#333"`
}

/** Escape XML special characters in text content. */
function escapeXml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;')
}

/** Body line kinds that carry different visual styles in SVG export. */
type LineKind = 'heading' | 'list' | 'quote' | 'code' | 'plain'

/** A body line with its Markdown-derived visual kind. */
interface StyledLine {
  text: string
  kind: LineKind
}

/**
 * Convert Markdown-ish card content into styled body lines for SVG export.
 * Keeps enough structure to preserve heading/quote/code styling.
 */
function markdownToStyledLines(md: string): StyledLine[] {
  const out: StyledLine[] = []
  let inCode = false

  for (const rawLine of md.split('\n')) {
    const line = rawLine.trim()

    if (line.startsWith('```')) {
      inCode = !inCode
      continue
    }
    if (inCode) {
      out.push({ text: line, kind: 'code' })
      continue
    }
    if (line === '') {
      out.push({ text: '', kind: 'plain' })
      continue
    }

    // Markdown table separator row
    if (/^\|?[\s:|-]+\|?$/.test(line) && line.includes('-')) continue
    if (line.startsWith('|') && line.endsWith('|')) {
      const cells = line.slice(1, -1).split('|').map((c) => c.trim()).filter((c) => c !== '')
      out.push({ text: cells.join('  '), kind: 'plain' })
      continue
    }

    if (/^#{1,6}\s+/.test(line)) {
      out.push({ text: line.replace(/^#{1,6}\s+/, ''), kind: 'heading' })
      continue
    }

    if (/^[-*]\s+\[[ xX]\]\s+/.test(line)) {
      const done = /^[-*]\s+\[[xX]\]/.test(line)
      out.push({
        text: line.replace(/^[-*]\s+\[[ xX]\]\s+/, done ? '☑ ' : '☐ '),
        kind: 'list',
      })
      continue
    }
    if (/^[-*+]\s+/.test(line)) {
      out.push({ text: line.replace(/^[-*+]\s+/, '• '), kind: 'list' })
      continue
    }
    if (/^\d+[.)]\s+/.test(line)) {
      out.push({ text: `• ${line.replace(/^\d+[.)]\s+/, '')}`, kind: 'list' })
      continue
    }
    if (line.startsWith('>')) {
      out.push({ text: line.replace(/^>\s?/, ''), kind: 'quote' })
      continue
    }

    out.push({ text: line, kind: 'plain' })
  }

  return out
}

/** Wrap a styled line, preserving its kind across wrapped fragments. */
function wrapStyledLine(line: StyledLine, maxUnits: number): StyledLine[] {
  if (line.text === '') return [line]
  return wrapText(line.text, maxUnits).map((text) => ({ text, kind: line.kind }))
}

/** Wrap a line into visual units (CJK glyph ≈ 1, ASCII ≈ 0.55). */
function wrapText(line: string, maxUnits: number): string[] {
  if (line === '') return ['']
  const chars = [...line]
  const out: string[] = []
  let current = ''
  let width = 0

  for (const ch of chars) {
    const code = ch.codePointAt(0) ?? 0
    const w = code > 0x2e7f ? 1 : 0.55
    if (width + w > maxUnits && current !== '') {
      out.push(current)
      current = ch
      width = w
    } else {
      current += ch
      width += w
    }
  }
  if (current !== '') out.push(current)
  return out
}

/**
 * Normalize an SVG string into well-formed standalone XML.
 * HTML-style input (outerHTML output with unclosed void tags) is parsed
 * by the tolerant HTML parser, then re-serialized by XMLSerializer which
 * emits self-closing tags and proper namespace declarations.
 */
function normalizeSvgXml(svg: string): string {
  try {
    const htmlDoc = new DOMParser().parseFromString(svg, 'text/html')
    const svgEl = htmlDoc.querySelector('svg')
    if (svgEl === null) return svg
    const xml = new XMLSerializer().serializeToString(svgEl)
    return `<?xml version="1.0" encoding="UTF-8"?>\n${xml}`
  } catch {
    return svg
  }
}

/**
 * Build a complete standalone HTML document for one card.
 * Inline CSS mirrors the on-screen CardView visual quality.
 */
function buildStandaloneHtml(
  card: KnowledgeCard,
  t: typeof CARD_THEMES[keyof typeof CARD_THEMES],
  isMermaid: boolean,
): string {
  const mermaidScript = isMermaid
    ? `<script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>`
    : ''
  const mermaidInit = isMermaid
    ? `<script>mermaid.initialize({startOnLoad:true,theme:'base',themeVariables:{primaryColor:'${t.bg}',primaryTextColor:'#1a1a2e',primaryBorderColor:'${t.theme}',lineColor:'#5B6B7E',fontSize:'13px',borderRadius:6}});</script>`
    : ''
  const bodyContent = isMermaid
    ? `<div class="mermaid">${escapeHtml(card.content)}</div>`
    : renderSimpleMarkdown(card.content)

  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(card.title)}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;background:#f5f6f8;display:flex;justify-content:center;padding:40px 20px;min-height:100vh}
.card{--theme:${t.theme};--bg:${t.bg};--border:${t.border};width:100%;max-width:680px;border-radius:10px;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.08),0 0 0 1px rgba(0,0,0,.04);overflow:hidden}
.topBar{height:3px;background:var(--theme)}
.header{display:flex;align-items:center;gap:8px;padding:10px 16px 8px;background:var(--bg);border-bottom:1px solid var(--border)}
.badge{font-size:11px;font-weight:600;color:var(--theme);background:rgba(255,255,255,.7);padding:2px 8px;border-radius:4px}
.source{margin-left:auto;font-size:11px;color:#999}
.title{padding:8px 16px 6px;font-size:15px;font-weight:600;color:#1a1a2e}
.body{padding:14px 16px 16px;font-size:13.5px;line-height:1.65;color:#333}
.body h1,.body h2,.body h3{color:var(--theme);font-size:14px;font-weight:600;margin:12px 0 6px}
.body ul,.body ol{padding-left:18px;margin:6px 0}
.body li{margin:3px 0}
.body code{background:var(--bg);color:var(--theme);padding:1px 5px;border-radius:3px;font-size:12.5px}
.body table{width:100%;border-collapse:collapse;margin:8px 0;font-size:13px}
.body th{background:var(--bg);color:var(--theme);font-weight:600;padding:6px 10px;text-align:left;border-bottom:2px solid var(--border)}
.body td{padding:6px 10px;border-bottom:1px solid #f0f0f0}
.body blockquote{border-left:3px solid var(--theme);margin:8px 0;padding:4px 12px;background:var(--bg);color:#555}
.mermaid{text-align:center}
@media (prefers-color-scheme:dark){
body{background:#1a1a26}
.card{background:#262635;box-shadow:0 2px 8px rgba(0,0,0,.3)}
.header{background:rgba(255,255,255,.04)}
.badge{background:rgba(255,255,255,.08)}
.title{color:#D5D5E0}
.body{color:#C0C0CC}
.body td{border-bottom-color:rgba(255,255,255,.06)}
}
</style>
${mermaidScript}
</head>
<body>
<div class="card">
<div class="topBar"></div>
<div class="header">
<span class="badge">${t.icon} ${t.label}</span>
<span class="source">Turn ${card.sourceTurns.join(', ')}</span>
</div>
<div class="title">${escapeHtml(card.title)}</div>
<div class="body">${bodyContent}</div>
</div>
${mermaidInit}
</body>
</html>`
}

/** Minimal Markdown-to-HTML for export (headings, lists, tables, code, blockquote). */
function renderSimpleMarkdown(md: string): string {
  const lines = md.split('\n')
  let html = ''
  let inList = false
  let inTable = false

  for (const line of lines) {
    const trimmed = line.trim()

    // Table row
    if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
      if (inList) { html += '</ul>'; inList = false }
      if (!inTable) { html += '<table>'; inTable = true }
      const cells = trimmed.slice(1, -1).split('|').map(c => c.trim())
      const isSeparator = cells.every(c => /^[-:]+$/.test(c))
      if (isSeparator) {
        // Skip separator row, add th border via CSS
      } else if (html.lastIndexOf('<tr>') > html.lastIndexOf('</tr>') && html.includes('<th>')) {
        // Body row
        html += '<tr>' + cells.map(c => `<td>${escapeHtml(c)}</td>`).join('') + '</tr>'
      } else {
        // Header row
        html += '<tr>' + cells.map(c => `<th>${escapeHtml(c)}</th>`).join('') + '</tr>'
      }
      continue
    } else if (inTable) {
      html += '</table>'
      inTable = false
    }

    // Heading
    if (trimmed.startsWith('### ')) {
      if (inList) { html += '</ul>'; inList = false }
      html += `<h3>${escapeHtml(trimmed.slice(4))}</h3>`
    } else if (trimmed.startsWith('## ')) {
      if (inList) { html += '</ul>'; inList = false }
      html += `<h2>${escapeHtml(trimmed.slice(3))}</h2>`
    } else if (trimmed.startsWith('# ')) {
      if (inList) { html += '</ul>'; inList = false }
      html += `<h1>${escapeHtml(trimmed.slice(2))}</h1>`
    }
    // List item
    else if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
      if (!inList) { html += '<ul>'; inList = true }
      html += `<li>${escapeHtml(trimmed.slice(2))}</li>`
    }
    // Blockquote
    else if (trimmed.startsWith('> ')) {
      if (inList) { html += '</ul>'; inList = false }
      html += `<blockquote>${escapeHtml(trimmed.slice(2))}</blockquote>`
    }
    // Empty line
    else if (trimmed === '') {
      if (inList) { html += '</ul>'; inList = false }
    }
    // Paragraph
    else {
      if (inList) { html += '</ul>'; inList = false }
      html += `<p>${escapeHtml(trimmed)}</p>`
    }
  }

  if (inList) html += '</ul>'
  if (inTable) html += '</table>'
  return html
}
