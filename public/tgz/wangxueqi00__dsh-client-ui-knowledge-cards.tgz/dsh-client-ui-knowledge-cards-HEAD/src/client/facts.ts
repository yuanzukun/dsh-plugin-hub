/**
 * Session-level facts extracted from conversation turns.
 *
 * Timeline and checklist cards are built deterministically from this facts
 * store rather than by re-summarizing the raw conversation each time. Facts
 * are parsed from the Agent's ```facts JSON block, merged across generations
 * (deduplicated by text), and turned into Mermaid timeline / Markdown
 * checklist content on the client.
 */

import type { KnowledgeCard } from './card-generator.ts'

/** A single timeline event. */
export interface FactEvent {
  /** Optional time label, e.g. "2026-08-21". */
  at?: string
  /** Event description. */
  text: string
}

/** A single action item. */
export interface FactTodo {
  /** Action text. */
  text: string
  /** Whether it is completed. */
  done?: boolean
}

/** A single conclusion / quote-worthy sentence. */
export interface FactConclusion {
  /** Conclusion text. */
  text: string
}

/** The complete fact set for one session. */
export interface SessionFacts {
  events: FactEvent[]
  todos: FactTodo[]
  conclusions: FactConclusion[]
}

/** An empty fact set. */
export function emptyFacts(): SessionFacts {
  return { events: [], todos: [], conclusions: [] }
}

/**
 * Parse the first ```facts JSON block from an Agent response.
 * Returns null when no block is present or the JSON is malformed.
 */
export function parseFactsFromText(text: string): SessionFacts | null {
  const match = /```facts\s*\n?([\s\S]*?)```/.exec(text)
  if (match === null) return null

  try {
    const raw = JSON.parse(match[1]!.trim()) as {
      events?: unknown
      todos?: unknown
      conclusions?: unknown
    }

    const facts = emptyFacts()

    if (Array.isArray(raw.events)) {
      for (const item of raw.events) {
        if (typeof item === 'object' && item !== null) {
          const e = item as FactEvent
          if (typeof e.text === 'string' && e.text.trim() !== '') {
            const event: FactEvent = { text: e.text.trim() }
            const at = typeof e.at === 'string' ? e.at.trim() : ''
            if (at !== '') event.at = at
            facts.events.push(event)
          }
        }
      }
    }

    if (Array.isArray(raw.todos)) {
      for (const item of raw.todos) {
        if (typeof item === 'object' && item !== null) {
          const t = item as FactTodo
          if (typeof t.text === 'string' && t.text.trim() !== '') {
            facts.todos.push({ text: t.text.trim(), done: t.done === true })
          }
        }
      }
    }

    if (Array.isArray(raw.conclusions)) {
      for (const item of raw.conclusions) {
        if (typeof item === 'object' && item !== null) {
          const c = item as FactConclusion
          if (typeof c.text === 'string' && c.text.trim() !== '') {
            facts.conclusions.push({ text: c.text.trim() })
          }
        }
      }
    }

    return facts
  } catch {
    return null
  }
}

/** Normalize text for deduplication keys. */
function norm(s: string): string {
  return s.trim().toLowerCase()
}

/** Merge two fact sets, deduplicating by normalized text. */
export function mergeFacts(prev: SessionFacts, next: SessionFacts): SessionFacts {
  return {
    events: dedupe([...prev.events, ...next.events], (e) => norm(e.text)),
    todos: dedupe([...prev.todos, ...next.todos], (t) => norm(t.text)),
    conclusions: dedupe([...prev.conclusions, ...next.conclusions], (c) => norm(c.text)),
  }
}

/** Deduplicate by a string key, preserving first occurrence. */
function dedupe<T>(items: T[], key: (item: T) => string): T[] {
  const seen = new Set<string>()
  const out: T[] = []
  for (const item of items) {
    const k = key(item)
    if (k === '' || seen.has(k)) continue
    seen.add(k)
    out.push(item)
  }
  return out
}

/** Build Mermaid `timeline` source from facts. */
export function factsToTimelineMermaid(facts: SessionFacts): string {
  const events = [...facts.events].sort((a, b) => (a.at ?? '').localeCompare(b.at ?? ''))
  const lines = ['timeline', '    title 事件时间线']
  if (events.length === 0) {
    lines.push('    暂无 : 暂无事件')
    return lines.join('\n')
  }
  for (const e of events) {
    const period = (e.at ?? '').trim() === '' ? '未标注时间' : e.at!.trim()
    lines.push(`    ${cleanMermaid(period)} : ${cleanMermaid(e.text)}`)
  }
  return lines.join('\n')
}

/** Build Markdown checklist content from facts. */
export function factsToChecklistMarkdown(facts: SessionFacts): string {
  if (facts.todos.length === 0) return '- [ ] 暂无行动项'
  return facts.todos
    .map((t) => `- [${t.done === true ? 'x' : ' '}] ${t.text.trim()}`)
    .join('\n')
}

/** Build a timeline card from facts. */
export function buildTimelineCard(
  facts: SessionFacts,
  topic: string,
  sourceTurns: readonly number[],
): KnowledgeCard {
  return {
    id: crypto.randomUUID(),
    type: 'timeline',
    title: `${topic} · 时间线`,
    content: factsToTimelineMermaid(facts),
    sourceTurns: [...sourceTurns],
    topic,
  }
}

/** Build a checklist card from facts. */
export function buildChecklistCard(
  facts: SessionFacts,
  topic: string,
  sourceTurns: readonly number[],
): KnowledgeCard {
  return {
    id: crypto.randomUUID(),
    type: 'checklist',
    title: `${topic} · 行动清单`,
    content: factsToChecklistMarkdown(facts),
    sourceTurns: [...sourceTurns],
    topic,
  }
}

/** Collapse whitespace inside a Mermaid label. */
function cleanMermaid(s: string): string {
  return s.replace(/\s+/g, ' ').trim()
}
