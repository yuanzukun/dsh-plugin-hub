/**
 * Card type definitions, theme color mapping, and Agent-directive builders.
 *
 * The Agent (LLM) generates cards via conversation.send() — this module
 * constructs the prompt directives and defines the data shapes the browser
 * parses back from the Agent's ```card JSON code blocks.
 *
 * Timeline and checklist cards are generated differently: the Agent first
 * emits a ```facts JSON block (see facts.ts), and the client deterministically
 * builds the timeline/checklist cards from those facts. This keeps those two
 * "whole-history" card types stable, deduplicated and incrementally mergeable.
 */

import type { TurnContent } from './card-data-collector.ts'
import type { SessionFacts } from './facts.ts'

/** Supported knowledge-card visual types. */
export type CardType =
  | 'concept' | 'flowchart' | 'comparison' | 'summary' | 'mindmap'
  | 'quote' | 'checklist' | 'timeline' | 'faq'

/** A single generated knowledge card. */
export interface KnowledgeCard {
  /** Stable runtime id (crypto.randomUUID). */
  id: string
  /** Visual layout type. */
  type: CardType
  /** Card heading. */
  title: string
  /** Card body: Markdown text or Mermaid code (for flowchart/mindmap/timeline). */
  content: string
  /** Source conversation turns. */
  sourceTurns: readonly number[]
  /** Topic this card belongs to. */
  topic: string
}

/** A topic detected by auto-split or defined by manual turn selection. */
export interface Topic {
  /** Display title. */
  title: string
  /** Turn numbers covered by this topic. */
  turns: readonly number[]
  /** One-line summary. */
  summary: string
}

/** Theme color per card type — low-saturation, textured, not flashy. */
export interface CardTheme {
  /** Primary accent color. */
  theme: string
  /** Light background tint. */
  bg: string
  /** Border color. */
  border: string
  /** Emoji icon. */
  icon: string
  /** Short label (localized externally, but a stable fallback here). */
  label: string
}

/** Color mapping: each card type gets its own restrained accent. */
export const CARD_THEMES: Record<CardType, CardTheme> = {
  concept:    { theme: '#4A6FA5', bg: '#EEF2F8', border: '#D5DEEC', icon: '💡', label: 'concept' },
  flowchart:  { theme: '#3A8E7A', bg: '#E8F2EE', border: '#CFE4DA', icon: '🔀', label: 'flowchart' },
  comparison: { theme: '#B8863E', bg: '#F6F0E3', border: '#E6D9BE', icon: '⚖️', label: 'comparison' },
  summary:    { theme: '#5B6B7E', bg: '#EDF0F4', border: '#D3DAE3', icon: '📋', label: 'summary' },
  mindmap:    { theme: '#7B5EA7', bg: '#F0EBF6', border: '#DDD0EA', icon: '🧠', label: 'mindmap' },
  quote:      { theme: '#C25B4A', bg: '#F7EBE8', border: '#E8CFC8', icon: '❝', label: 'quote' },
  checklist:  { theme: '#2F7D6D', bg: '#E6F1ED', border: '#C8DFD6', icon: '✅', label: 'checklist' },
  timeline:   { theme: '#9A6B2F', bg: '#F4EEE2', border: '#E2D4B8', icon: '🕒', label: 'timeline' },
  faq:        { theme: '#3D6E8E', bg: '#E8F0F5', border: '#CFE0EA', icon: '❓', label: 'faq' },
}

/** All card types in display order. */
export const ALL_CARD_TYPES: readonly CardType[] = [
  'concept', 'flowchart', 'comparison', 'summary', 'mindmap',
  'quote', 'checklist', 'timeline', 'faq',
]

/** Whether a card type is rendered through the Mermaid renderer. */
export function isMermaidCardType(type: CardType): boolean {
  return type === 'flowchart' || type === 'mindmap' || type === 'timeline'
}

/**
 * Build the /generate-cards directive sent to the Agent.
 *
 * For timeline/checklist the prompt asks the Agent for a ```facts block
 * first; the client then builds those two cards deterministically from the
 * merged facts (see facts.ts). All other types are emitted by the Agent as
 * ```card blocks as before.
 */
export function buildGenerateCardsPrompt(
  topic: Topic,
  turns: readonly TurnContent[],
  cardTypes: readonly CardType[],
  existingFacts?: SessionFacts,
  factsTurns: readonly TurnContent[] = turns,
): string {
  const needsFacts = cardTypes.includes('timeline') || cardTypes.includes('checklist')
  const cardTypesToGenerate = cardTypes.filter((t) => t !== 'timeline' && t !== 'checklist')

  // When facts and cards read the same turn set, share one content section;
  // otherwise feed facts the whole history and cards the selected range.
  const sharedTurns = factsTurns === turns
  const contentSection = sharedTurns && (needsFacts || cardTypesToGenerate.length > 0)
    ? `\n## 对话内容:\n${formatTurns(turns)}\n`
    : ''
  const factsSection = !sharedTurns && needsFacts
    ? `\n## 事实抽取来源（全部历史）:\n${formatTurns(factsTurns)}\n`
    : ''
  const cardSection = !sharedTurns && cardTypesToGenerate.length > 0
    ? `\n## 对话内容:\n${formatTurns(turns)}\n`
    : ''

  const factsDirective = needsFacts ? buildFactsDirective(existingFacts) : ''
  const cardDirective = cardTypesToGenerate.length > 0
    ? buildCardDirective(cardTypesToGenerate)
    : '本次只需从对话中提取 facts 事实，不需要输出卡片。'

  return `/generate-cards

## 话题: ${topic.title}
${topic.summary}${factsSection}${cardSection}${contentSection}
## 要求:
${factsDirective}${cardDirective}`
}

/** Render turn contents into the prompt body. */
function formatTurns(turns: readonly TurnContent[]): string {
  return turns.map((t) => {
    const parts: string[] = [`### Turn ${t.turn}`]
    if (t.userText) parts.push(`用户: ${t.userText}`)
    if (t.assistantTexts.length > 0) parts.push(`助手: ${t.assistantTexts.join('\n')}`)
    if (t.toolCalls.length > 0) parts.push(`工具调用: ${t.toolCalls.join(', ')}`)
    return parts.join('\n')
  }).join('\n\n')
}

/** Build the ```facts extraction directive (only when timeline/checklist requested). */
function buildFactsDirective(existingFacts?: SessionFacts): string {
  const existing = existingFacts !== undefined
    && (existingFacts.events.length > 0 || existingFacts.todos.length > 0 || existingFacts.conclusions.length > 0)

  const existingJson = existing
    ? `\n已有的历史事实（请合并去重，不要重复输出）:\n${JSON.stringify(existingFacts, null, 2)}\n`
    : ''

  return `请先从上述对话中抽取结构化事实，并输出一个 \`\`\`facts 代码块，JSON 格式:
{"events":[{"at":"时间（可为空）","text":"事件"}],"todos":[{"text":"行动项","done":false}],"conclusions":[{"text":"结论/金句"}]}
${existingJson}
要求：events 按时间从早到晚排序；todos 合并去重并保留完成状态；conclusions 每条一句话。
`
}

/** Build the ```card generation directive for the given model-rendered types. */
function buildCardDirective(types: readonly CardType[]): string {
  const typesList = types.join(', ')
  const typeUnion = types.join('|')

  return `请生成以下类型的知识卡片: ${typesList}
只生成以上列出的类型，不要生成其他类型；如果某个类型没有合适内容，可以省略该类型，不要用其他类型代替。
每张卡片用 \`\`\`card 代码块包裹 JSON 输出，格式:
{"type":"${typeUnion}","title":"标题","content":"内容"}
流程图用 Mermaid flowchart 语法，对比表用 Markdown 表格，概念卡用标题+列表。
quote 引用卡：每条用 > 引用块，可附来源。
faq 问答卡：用「## 问题」加「答案」的形式。
`
}

/**
 * Build the /split-topics directive for auto topic detection.
 */
export function buildSplitTopicsPrompt(turns: readonly TurnContent[]): string {
  const turnsText = turns.map((t) => {
    const userLine = t.userText ? `用户: ${t.userText.slice(0, 200)}` : '(无用户文本)'
    const asstLine = t.assistantTexts.length > 0
      ? `助手: ${t.assistantTexts[0]!.slice(0, 200)}`
      : '(无助手回复)'
    return `Turn ${t.turn}: ${userLine} | ${asstLine}`
  }).join('\n')

  return `/split-topics

## 对话轮次:
${turnsText}

请分析话题边界，用 \`\`\`topics 代码块输出 JSON 数组:
[{"title":"话题名","turns":[1,2],"summary":"一句话描述"}]
按连续轮次分组。`
}

/**
 * Build the /regenerate-card directive for a single card.
 */
export function buildRegenerateCardPrompt(card: KnowledgeCard): string {
  return `/regenerate-card

重新生成以下卡片，保持类型不变但可以换一个角度或更精炼:
类型: ${card.type}
原标题: ${card.title}
原内容: ${card.content}

请输出一张新的 \`\`\`card JSON。`
}
