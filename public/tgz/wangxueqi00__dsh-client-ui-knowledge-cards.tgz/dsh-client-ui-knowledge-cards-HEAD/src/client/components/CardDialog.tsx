/**
 * CardDialog: the main interaction surface for generating knowledge cards.
 *
 * The user picks a turn scope and card types, then sends /generate-cards.
 * After generation, switches to CardGallery view. Reads cards from the
 * module-level card-store (not local state), so closing the dialog does
 * NOT stop background generation or lose parsed cards.
 */
import { useState, useCallback, useRef, useEffect } from 'react'
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type { CardsKey } from '../locales.ts'
import { collectTurns } from '../card-data-collector.ts'
import {
  type KnowledgeCard, type Topic, type CardType,
  ALL_CARD_TYPES, CARD_THEMES,
  buildGenerateCardsPrompt, buildRegenerateCardPrompt,
} from '../card-generator.ts'
import {
  getCards, subscribeCards, setCards,
  getStatus, subscribeStatus, setStatus,
  setWaitingFor,
  recordCurrentSeq,
  setRegeneratingId,
  updateCard, getFacts, setPendingRequest,
} from '../card-store.ts'
import { factsToTimelineMermaid, factsToChecklistMarkdown } from '../facts.ts'
import { CardGallery } from './CardGallery.tsx'
import css from './CardDialog.module.css'

/** Full props: framework kit + locale + injected send + close callback. */
export interface CardDialogProps {
  useSession: <T,>(selector: (snapshot: import('@deepseek-ai/dsh-client-runtime/client').ConversationSnapshot) => T) => T
  sessionId: SessionId
  t: (key: CardsKey, params?: Record<string, string>) => string
  send: (text: string) => Promise<void>
  loadOlder: () => Promise<void>
  onClose: () => void
}

/** Turn source scope: manual selection or the whole loaded history. */
type Range = 'selected' | 'all'

export function CardDialog({ useSession, sessionId, t, send, loadOlder, onClose }: CardDialogProps) {
  // ===== Collect turns from snapshot =====
  const turns = useSession((s) => collectTurns(s))

  // Snapshot ref: use the turns selector result to keep it in sync
  // (turns changes when nodes change, so the ref stays current)
  const snapshotRef = useRef<import('@deepseek-ai/dsh-client-runtime/client').ConversationSnapshot | null>(null)
  useSession((s) => { snapshotRef.current = s; return s.nodes.length })

  // ===== Read cards & status from module store =====
  const [cards, setCardsState] = useState<KnowledgeCard[]>(() => getCards(sessionId))
  const [status, setStatusState] = useState(() => getStatus(sessionId))

  useEffect(() => {
    const unsubCards = subscribeCards(sessionId, (c) => setCardsState([...c]))
    const unsubStatus = subscribeStatus(sessionId, (s) => setStatusState(s))
    return () => { unsubCards(); unsubStatus() }
  }, [sessionId])

  // ===== Local UI state =====
  const [selectedTurns, setSelectedTurns] = useState<Set<number>>(new Set())
  const [selectedTypes, setSelectedTypes] = useState<Set<CardType>>(new Set(ALL_CARD_TYPES))
  const [range, setRange] = useState<Range>('selected')
  const [loadingHistory, setLoadingHistory] = useState(false)

  const generating = status.phase === 'generating'
  const hasCards = cards.length > 0
  // Show gallery if we have cards OR if generation is happening (loading state)
  const showGallery = hasCards || generating

  // ===== Toggle helpers =====
  const toggleTurn = useCallback((turn: number) => {
    setSelectedTurns((prev) => {
      const next = new Set(prev)
      if (next.has(turn)) next.delete(turn)
      else next.add(turn)
      return next
    })
  }, [])

  const selectAllTurns = useCallback(() => {
    setSelectedTurns(new Set(turns.map((tc) => tc.turn)))
  }, [turns])

  const deselectAllTurns = useCallback(() => {
    setSelectedTurns(new Set())
  }, [])

  const toggleType = useCallback((type: CardType) => {
    setSelectedTypes((prev) => {
      const next = new Set(prev)
      if (next.has(type)) next.delete(type)
      else next.add(type)
      return next
    })
  }, [])

  // ===== History loading =====
  /**
   * Pull older history pages until the snapshot reports no more history.
   * After each page we wait for the snapshot (via useSession) to reflect the
   * change before asking for the next page.
   */
  const loadAllHistory = useCallback(async () => {
    let rounds = 0
    while (rounds < 60) {
      const snap = snapshotRef.current
      if (snap === null || snap === undefined || !snap.hasMore || snap.loadingOlder) return
      const prevLen = snap.nodes.length

      await loadOlder()

      await new Promise<void>((resolve) => {
        const started = Date.now()
        const tick = () => {
          const s = snapshotRef.current
          if (s === null || s === undefined) { resolve(); return }
          if (s.nodes.length !== prevLen || !s.hasMore) { resolve(); return }
          if (Date.now() - started > 8000) { resolve(); return }
          setTimeout(tick, 40)
        }
        tick()
      })
      rounds++
    }
  }, [loadOlder])

  // ===== Generate =====
  const handleGenerate = useCallback(async () => {
    const types = [...selectedTypes]
    const hasFactsTypes = types.includes('timeline') || types.includes('checklist')
    const needAllHistory = range === 'all' || hasFactsTypes

    // Whole-history scope: pull every older page before collecting turns.
    if (needAllHistory) {
      setLoadingHistory(true)
      try {
        await loadAllHistory()
      } finally {
        setLoadingHistory(false)
      }
    }

    const snapshot = snapshotRef.current
    const allTurns = snapshot !== null && snapshot !== undefined ? collectTurns(snapshot) : turns
    const sourceTurns = range === 'all'
      ? allTurns
      : turns.filter((tc) => selectedTurns.has(tc.turn))
    const factsTurns = hasFactsTypes ? allTurns : sourceTurns

    if (sourceTurns.length === 0) return

    // Record current latest seq so CardButton only looks at messages after this
    if (snapshot !== null && snapshot !== undefined) {
      recordCurrentSeq(sessionId, snapshot.nodes)
    }

    const topic: Topic = {
      title: '对话总结',
      turns: sourceTurns.map((tc) => tc.turn),
      summary: '',
    }

    // Remember what we asked for so the background monitor can build
    // timeline/checklist cards deterministically from the parsed facts.
    setPendingRequest(sessionId, {
      types,
      topic: topic.title,
      sourceTurns: sourceTurns.map((tc) => tc.turn),
      factsTurns: factsTurns.map((tc) => tc.turn),
    })

    const prompt = buildGenerateCardsPrompt(topic, sourceTurns, types, getFacts(sessionId), factsTurns)
    setWaitingFor(sessionId, 'cards')
    setStatus(sessionId, { phase: 'generating', sessionId })
    await send(prompt)
  }, [turns, selectedTurns, selectedTypes, range, loadAllHistory, send, sessionId])

  // ===== Regenerate =====
  const handleRegenerate = useCallback(async (card: KnowledgeCard) => {
    // Timeline/checklist cards are rebuilt deterministically from the facts
    // store — no Agent round-trip required.
    if (card.type === 'timeline' || card.type === 'checklist') {
      const facts = getFacts(sessionId)
      const content = card.type === 'timeline'
        ? factsToTimelineMermaid(facts)
        : factsToChecklistMarkdown(facts)
      updateCard(sessionId, { ...card, content })
      setStatus(sessionId, { phase: 'ready', sessionId, count: getCards(sessionId).length })
      return
    }

    const snapshot = snapshotRef.current
    if (snapshot !== null && snapshot !== undefined) {
      recordCurrentSeq(sessionId, snapshot.nodes)
    }

    const prompt = buildRegenerateCardPrompt(card)
    setWaitingFor(sessionId, 'regenerate')
    setRegeneratingId(sessionId, card.id)
    setStatus(sessionId, { phase: 'generating', sessionId })
    await send(prompt)
  }, [send, sessionId])

  const handleRegenerateAll = useCallback(() => {
    if (cards.length > 0) void handleRegenerate(cards[0]!)
  }, [cards, handleRegenerate])

  // ===== Render: Gallery view (cards exist or generating) =====
  if (showGallery) {
    return (
      <div className={css.overlay} onClick={onClose}>
        <div
          className={`${css.panel} ${css.panelWide}`}
          onClick={(e) => e.stopPropagation()}
        >
          <div className={css.header}>
            <span className={css.headerTitle}>{t('gallery.title')}</span>
            {generating && <span className={css.generatingHint}>{t('dialog.generating')}</span>}
            <button className={css.closeIcon} onClick={onClose}>✕</button>
          </div>
          <CardGallery
            cards={cards}
            loading={generating}
            t={t}
            onRegenerate={handleRegenerate}
            onRegenerateAll={handleRegenerateAll}
            onClose={onClose}
          />
          {/* Config button: go back to config to generate more */}
          <div className={css.galleryFooter}>
            <button className={css.footerBtn} onClick={() => {
              setCards(sessionId, [])
              setStatus(sessionId, { phase: 'idle' })
              setCardsState([])
            }}>
              {t('dialog.generate')}
            </button>
          </div>
        </div>
      </div>
    )
  }

  // ===== Render: Config view =====
  return (
    <div className={css.overlay} onClick={onClose}>
      <div className={css.panel} onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className={css.header}>
          <span className={css.headerTitle}>{t('dialog.title')}</span>
          <button className={css.closeIcon} onClick={onClose}>✕</button>
        </div>

        {/* Body */}
        <div className={css.body}>
          {turns.length === 0 ? (
            <div className={css.turnEmpty}>{t('dialog.noTurns')}</div>
          ) : (
            <>
              {/* Scope selector */}
              <div className={css.section}>
                <div className={css.sectionTitle}>{t('dialog.range.title')}</div>
                <div className={css.modeRow}>
                  <button
                    className={`${css.modeBtn} ${range === 'selected' ? css.modeBtnActive : ''}`}
                    onClick={() => setRange('selected')}
                  >
                    {t('dialog.range.selected')}
                  </button>
                  <button
                    className={`${css.modeBtn} ${range === 'all' ? css.modeBtnActive : ''}`}
                    onClick={() => setRange('all')}
                  >
                    {t('dialog.range.all')}
                  </button>
                </div>
                {loadingHistory && (
                  <div className={css.turnEmpty}>{t('dialog.range.loading')}</div>
                )}
                {range === 'all' && !loadingHistory && (
                  <div className={css.turnEmpty}>{t('dialog.range.allHint')}</div>
                )}
              </div>

              {/* Turn selector (selected scope) */}
              {range === 'selected' && (
                <div className={css.section}>
                  <div className={css.sectionTitle}>
                    {t('dialog.turns')} ({selectedTurns.size}/{turns.length})
                    <span className={css.sectionActions}>
                      <button className={css.sectionActionBtn} onClick={selectAllTurns}>
                        {t('dialog.selectAll')}
                      </button>
                      <button className={css.sectionActionBtn} onClick={deselectAllTurns}>
                        {t('dialog.deselectAll')}
                      </button>
                    </span>
                  </div>
                  <div className={css.turnList}>
                    {turns.map((tc) => (
                      <label
                        key={tc.turn}
                        className={`${css.turnItem} ${selectedTurns.has(tc.turn) ? css.turnItemSelected : ''}`}
                      >
                        <input
                          type="checkbox"
                          className={css.turnCheckbox}
                          checked={selectedTurns.has(tc.turn)}
                          onChange={() => toggleTurn(tc.turn)}
                        />
                        <div className={css.turnContent}>
                          <div className={css.turnLabel}>
                            {t('dialog.turn')} {tc.turn}
                          </div>
                          <div className={css.turnPreview}>
                            {tc.userText ?? tc.assistantTexts[0] ?? '(empty)'}
                          </div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {/* Card type selector */}
              <div className={css.section}>
                <div className={css.sectionTitle}>
                  {t('dialog.cardTypes')} ({selectedTypes.size})
                </div>
                <div className={css.typeChips}>
                  {ALL_CARD_TYPES.map((type) => {
                    const theme = CARD_THEMES[type]
                    const active = selectedTypes.has(type)
                    return (
                      <button
                        key={type}
                        className={`${css.typeChip} ${active ? css.typeChipActive : ''}`}
                        style={active ? {
                          background: theme.theme,
                          borderColor: theme.theme,
                        } : undefined}
                        onClick={() => toggleType(type)}
                      >
                        {theme.icon} {t(`dialog.type.${type}` as CardsKey)}
                      </button>
                    )
                  })}
                </div>
                {(selectedTypes.has('timeline') || selectedTypes.has('checklist')) && (
                  <div className={css.turnEmpty}>{t('dialog.range.timelineHint')}</div>
                )}
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        {turns.length > 0 && (
          <div className={css.footer}>
            <button className={`${css.footerBtn} ${css.footerCancel}`} onClick={onClose}>
              {t('dialog.cancel')}
            </button>
            <button
              className={`${css.footerBtn} ${css.footerGenerate}`}
              onClick={() => void handleGenerate()}
              disabled={generating || loadingHistory || selectedTypes.size === 0
                || (range === 'selected' ? selectedTurns.size === 0 : turns.length === 0)}
            >
              {generating ? t('dialog.generating') : t('dialog.generate')}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
