/**
 * CardView: renders one knowledge card with its theme colors, Markdown or
 * Mermaid content, and action buttons (download / regenerate).
 *
 * Download uses a native <select> for format choice (controlled by the
 * parent CardGallery so batch download can reuse each card's selection).
 * Format options are filtered per card type: the SVG option only appears
 * on Mermaid cards (flowchart / mindmap) once the diagram has rendered.
 */
import { useState, useCallback } from 'react'
import { MarkdownText } from '@deepseek-ai/dsh-client-ui-primitives'
import type { KnowledgeCard, CardType } from '../card-generator.ts'
import { CARD_THEMES, isMermaidCardType } from '../card-generator.ts'
import { MermaidDiagram } from './MermaidDiagram.tsx'
import {
  downloadAsMarkdown, downloadAsHtml, downloadAsSvg,
  downloadAsJson, downloadAsText, buildCardSvg,
} from '../download.ts'
import type { CardsKey } from '../locales.ts'
import css from './CardView.module.css'

export interface CardViewProps {
  card: KnowledgeCard
  /** Currently selected download format (controlled). */
  format: string
  /** Called when the user picks a different format. */
  onFormatChange: (cardId: string, format: string) => void
  /** Locale translation seat. */
  t: (key: CardsKey, params?: Record<string, string>) => string
  /** Regenerate this card. */
  onRegenerate: (card: KnowledgeCard) => void
}

/** Theme lookup with localized label. */
function useTheme(type: CardType, t: CardViewProps['t']) {
  const base = CARD_THEMES[type]
  const labelKey = `card.type.${base.label}` as CardsKey
  return { ...base, label: t(labelKey) }
}

export function CardView({ card, format, onFormatChange, t, onRegenerate }: CardViewProps) {
  const theme = useTheme(card.type, t)
  const isMermaid = isMermaidCardType(card.type)
  const [mermaidSvg, setMermaidSvg] = useState<string | undefined>(undefined)

  // Markdown cards get a deterministic SVG; Mermaid cards render via Mermaid.
  const svgContent = isMermaid ? mermaidSvg : buildCardSvg(card)

  const styleVars = {
    '--card-theme': theme.theme,
    '--card-bg': theme.bg,
    '--card-border': theme.border,
  } as React.CSSProperties

  const handleSvgReady = useCallback((svg: string | undefined) => {
    setMermaidSvg(svg)
  }, [])

  const handleDownload = useCallback(() => {
    if (format === 'md') downloadAsMarkdown(card)
    else if (format === 'html') downloadAsHtml(card)
    else if (format === 'json') downloadAsJson(card)
    else if (format === 'txt') downloadAsText(card)
    else if (format === 'svg' && svgContent !== undefined) {
      downloadAsSvg(card, svgContent).catch((err) => {
        console.error('[cards] SVG download failed:', err)
      })
    }
  }, [format, card, svgContent])

  return (
    <div className={css.card} style={styleVars} data-card-id={card.id}>
      <div className={css.topBar} />
      <div className={css.header}>
        <span className={css.typeBadge}>
          {theme.icon} {theme.label}
        </span>
        <span className={css.source}>
          {t('card.source')} Turn {card.sourceTurns.join(', ')}
        </span>
      </div>
      <div className={css.title}>{card.title}</div>
      <div className={css.body}>
        {isMermaid ? (
          <MermaidDiagram chart={card.content} onSvgReady={handleSvgReady} />
        ) : (
          <MarkdownText
            text={card.content}
            codeLabels={{ copyLabel: t('card.download.md'), copiedLabel: '✓' }}
          />
        )}
      </div>
      <div className={css.actions}>
        <select
          className={css.formatSelect}
          value={format}
          onChange={(e) => onFormatChange(card.id, e.target.value)}
        >
          <option value="md">{t('card.download.md')}</option>
          <option value="html">{t('card.download.html')}</option>
          <option value="json">{t('card.download.json')}</option>
          <option value="txt">{t('card.download.txt')}</option>
          {svgContent !== undefined && (
            <option value="svg">{t('card.download.svg')}</option>
          )}
        </select>
        <button className={css.actBtn} onClick={handleDownload}>
          ⬇ {t('card.download.btn')}
        </button>
        <button
          className={`${css.actBtn} ${css.regenerate}`}
          onClick={() => onRegenerate(card)}
        >
          ↻ {t('card.regenerate')}
        </button>
      </div>
    </div>
  )
}
