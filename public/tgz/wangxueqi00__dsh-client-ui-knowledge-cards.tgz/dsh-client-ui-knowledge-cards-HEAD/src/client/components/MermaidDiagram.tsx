/**
 * MermaidDiagram: renders a Mermaid chart inside a card with lazy loading
 * and graceful fallback on parse errors.
 */
import { useEffect, useRef, useState } from 'react'
import { renderMermaid } from '../mermaid-renderer.ts'
import css from './MermaidDiagram.module.css'

export interface MermaidDiagramProps {
  /** Mermaid chart code. */
  chart: string
  /** Callback receiving the rendered SVG string (for download). */
  onSvgReady?: (svg: string | undefined) => void
}

/** Loading dot component. */
function Loading() {
  return (
    <div className={css.loading}>
      <div className={css.spinner} />
      <span>渲染图表中...</span>
    </div>
  )
}

export function MermaidDiagram({ chart, onSvgReady }: MermaidDiagramProps) {
  const ref = useRef<HTMLDivElement>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (ref.current === null) return
    setLoading(true)
    void renderMermaid(chart, ref.current).then((svg) => {
      setLoading(false)
      onSvgReady?.(svg)
    })
  }, [chart, onSvgReady])

  return (
    <div className={css.container}>
      {loading && <Loading />}
      <div ref={ref} style={{ display: loading ? 'none' : 'block' }} />
    </div>
  )
}
