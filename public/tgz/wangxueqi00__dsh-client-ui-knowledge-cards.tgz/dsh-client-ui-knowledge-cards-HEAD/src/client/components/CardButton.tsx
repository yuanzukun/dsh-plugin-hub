/**
 * CardButton: the header action that opens the CardDialog.
 * Registered into the `conversation.session.header.actions` list slot.
 *
 * CardButton is ALWAYS mounted (it lives in the session header), so it
 * monitors the conversation in the background: when the Agent emits card
 * JSON the button parses it into the module-level card-store, shows a
 * badge, and fires a browser notification. Closing the dialog does not
 * stop generation - CardButton keeps watching.
 */
import { useState, useCallback, useRef, useEffect } from 'react'
import type { InjectFace, PropsRuntime, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots'
import { NS, type CardsKey } from '../locales.ts'
import { CardDialog } from './CardDialog.tsx'
import {
  getCards, subscribeCards,
  getStatus, subscribeStatus,
  getWaitingFor, setWaitingFor, setLastCheckedSeq, getLastCheckedSeq,
  setCards, updateCard, setStatus,
  setRegeneratingId, getRegeneratingId,
  getPendingRequest, getFacts, mergeFacts,
  type GenerationStatus,
} from '../card-store.ts'
import { parseCardsFromText, parseTopicsFromText, parseRegeneratedCard } from '../card-parser.ts'
import { getAssistantTextBlocks } from '../card-data-collector.ts'
import {
  parseFactsFromText, buildTimelineCard, buildChecklistCard,
} from '../facts.ts'
import type { KnowledgeCard } from '../card-generator.ts'
import css from './CardButton.module.css'

/** Injected: a send callback bound to this session's conversation service. */
export interface CardButtonInjected {
  send: (text: string) => Promise<void>
  loadOlder: () => Promise<void>
}

/** Full props: framework kit + locale + injected sender. */
export type CardButtonProps =
  PropsRuntime<'conversation.session.header.actions'>
  & PropsLocale<typeof NS>
  & InjectFace<CardButtonInjected>

export function CardButton(props: CardButtonProps) {
  const { t, sessionId, send, loadOlder, useSession } = props
  const [open, setOpen] = useState(false)
  const [cardCount, setCardCount] = useState(() => getCards(sessionId).length)
  const [status, setStatusState] = useState<GenerationStatus>(() => getStatus(sessionId))

  // Snapshot ref: kept updated by the useSession selector below.
  // We use a separate useSession call returning a primitive (nodes.length)
  // to trigger re-renders, and a second one to keep the ref in sync.
  const snapshotRef = useRef<import('@deepseek-ai/dsh-client-runtime/client').ConversationSnapshot | null>(null)

  // Primitive triggers: these cause re-render when the conversation changes.
  // nodeCount changes when new messages arrive; running changes when the
  // Agent starts/stops generating. Both guarantee the useEffect below fires.
  const nodeCount = useSession((s) => s.nodes.length)
  const running = useSession((s) => s.running)

  // Keep snapshotRef in sync: we re-use nodeCount's selector result as a
  // dependency so React always re-runs this selector when nodes change.
  // Returning a primitive (not null) ensures useSyncExternalStore calls
  // the selector on every store change, keeping the ref current.
  const _snapLen = useSession((s) => {
    snapshotRef.current = s
    return s.nodes.length
  })

  // ===== Background monitor: runs in useEffect, not in the selector =====
  useEffect(() => {
    const waiting = getWaitingFor(sessionId)
    if (waiting === null) return

    // Still running? Wait for the turn to complete.
    if (running) return

    const snapshot = snapshotRef.current
    if (snapshot === null) return

    // Find the latest assistant message after lastCheckedSeq
    const lastSeq = getLastCheckedSeq(sessionId)
    const newAssistantNodes = [...snapshot.nodes]
      .filter((n): n is Extract<typeof n, { kind: 'assistant' }> => n.kind === 'assistant')
      .filter((n) => n.seq > lastSeq)

    const latestAssistant = newAssistantNodes
      .sort((a, b) => b.seq - a.seq)[0]

    if (latestAssistant === undefined) return

    const textBlocks = getAssistantTextBlocks(latestAssistant.blocks)
    const fullText = textBlocks.join('\n')

    if (waiting === 'topics') {
      const parsed = parseTopicsFromText(fullText)
      if (parsed.length > 0) {
        setWaitingFor(sessionId, null)
        setStatus(sessionId, { phase: 'idle' })
      }
    } else if (waiting === 'cards') {
      const pending = getPendingRequest(sessionId)
      const parsed = parseCardsFromText(fullText, pending?.sourceTurns ?? [], pending?.topic ?? '')

      // Merge any facts the Agent emitted for timeline/checklist generation.
      const facts = parseFactsFromText(fullText)
      if (facts !== null) mergeFacts(sessionId, facts)

      // Build timeline/checklist cards deterministically from the merged facts.
      const built: KnowledgeCard[] = []
      if (pending !== null) {
        const merged = getFacts(sessionId)
        if (pending.types.includes('timeline')) {
          built.push(buildTimelineCard(merged, pending.topic, pending.factsTurns))
        }
        if (pending.types.includes('checklist')) {
          built.push(buildChecklistCard(merged, pending.topic, pending.factsTurns))
        }
      }

      const allCards = [...built, ...parsed]
      if (allCards.length > 0) {
        setCards(sessionId, allCards)
        setWaitingFor(sessionId, null)
        setStatus(sessionId, { phase: 'ready', sessionId, count: allCards.length })
        fireNotification(t('notice.generationComplete'))
      } else {
        // No cards found: could be a partial/streaming state or the Agent
        // responded without card JSON. Reset after checking to avoid
        // being stuck in "generating" forever.
        // We keep waiting until the next snapshot change, but if the
        // assistant message is complete (not running) and has no cards,
        // it's likely a failed generation.
        setLastCheckedSeq(sessionId, latestAssistant.seq)
        setWaitingFor(sessionId, null)
        setStatus(sessionId, { phase: 'idle' })
      }
    } else if (waiting === 'regenerate') {
      const existingCards = getCards(sessionId)
      const regenId = getRegeneratingId(sessionId) ?? ''
      const target = existingCards.find((c) => c.id === regenId)
      if (target !== undefined) {
        const regenerated = parseRegeneratedCard(fullText, target)
        if (regenerated !== null) {
          updateCard(sessionId, regenerated)
          setWaitingFor(sessionId, null)
          setRegeneratingId(sessionId, null)
          setStatus(sessionId, { phase: 'ready', sessionId, count: existingCards.length })
          fireNotification(t('notice.regenerated'))
        }
      }
    }

    setLastCheckedSeq(sessionId, latestAssistant.seq)
  }, [nodeCount, running, _snapLen, sessionId, t])

  // Subscribe to store changes (badge + status display)
  useEffect(() => {
    const unsubCards = subscribeCards(sessionId, (cards) => setCardCount(cards.length))
    const unsubStatus = subscribeStatus(sessionId, (s) => setStatusState(s))
    return () => { unsubCards(); unsubStatus() }
  }, [sessionId])

  const generating = status.phase === 'generating'
  const handleClick = useCallback(() => setOpen(true), [])

  return (
    <>
      <button
        className={`${css.button} ${generating ? css.buttonGenerating : ''}`}
        onClick={handleClick}
        title={t('button.tooltip')}
      >
        <span className={`${css.icon} ${generating ? css.iconSpin : ''}`}>🎴</span>
        {t('button.label')}
        {cardCount > 0 && !generating && (
          <span className={css.badge}>{cardCount}</span>
        )}
        {generating && (
          <span className={css.badgeGenerating}>
            <span className={css.dot} />
          </span>
        )}
      </button>
      {open && (
        <CardDialog
          useSession={useSession}
          sessionId={sessionId}
          t={t}
          send={send}
          loadOlder={loadOlder}
          onClose={() => setOpen(false)}
        />
      )}
    </>
  )
}

/** Fire a browser notification (silent fallback if denied). */
function fireNotification(message: string): void {
  try {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('🎴 知识卡片', { body: message })
    }
  } catch { /* ignore */ }
}

export { NS }
export type { CardsKey }
