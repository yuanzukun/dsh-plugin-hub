/**
 * CardGallery: tab-based layout grouped by card type.
 *
 * Each tab shows cards of one type (concept, flowchart, comparison,
 * summary, mindmap). All tab panes stay mounted (inactive ones are
 * hidden with visibility, not unmounted) so PNG/SVG capture works for
 * cards in any tab, and tab switching is instant with no re-render of
 * Mermaid diagrams.
 *
 * Per-card download format lives here (lifted state): each CardView
 * selects its own format, and "Download all" downloads every card in
 * its individually chosen format.
 */
import { useState, useCallback, useMemo } from 'react'
import type { KnowledgeCard, CardType } from '../card-generator.ts'
import { ALL_CARD_TYPES, CARD_THEMES, isMermaidCardType } from '../card-generator.ts'
import {
  downloadAsMarkdown, downloadAsHtml, downloadAsSvg,
  downloadAsJson, downloadAsText, buildCardSvg,
} from '../download.ts'
import { CardView } from './CardView.tsx'
import type { CardsKey } from '../locales.ts'
import css from './CardGallery.module.css'

export interface CardGalleryProps {
  cards: readonly KnowledgeCard[]
  loading: boolean
  t: (key: CardsKey, params?: Record<string, string>) => string
  onRegenerate: (card: KnowledgeCard) => void
  onRegenerateAll: () => void
  onClose: () => void
}

export function CardGallery({ cards, loading, t, onRegenerate, onRegenerateAll, onClose }: CardGalleryProps) {
  // Group cards by type
  const grouped = useMemo(() => {
    const map = new Map<CardType, KnowledgeCard[]>()
    for (const type of ALL_CARD_TYPES) map.set(type, [])
    for (const card of cards) {
      const list = map.get(card.type)
      if (list !== undefined) list.push(card)
    }
    return map
  }, [cards])

  // Types that actually have cards
  const activeTypes = useMemo(
    () => ALL_CARD_TYPES.filter((type) => (grouped.get(type) ?? []).length > 0),
    [grouped],
  )

  const [activeTab, setActiveTab] = useState<CardType | null>(null)
  const currentTab = activeTab ?? activeTypes[0] ?? null

  // Per-card download format (lifted from CardView so batch download can
  // use each card's individual selection).
  const [formats, setFormats] = useState<Record<string, string>>({})
  const setCardFormat = useCallback((id: string, fmt: string) => {
    setFormats((prev) => ({ ...prev, [id]: fmt }))
  }, [])

  /**
   * Download one card in the given format.
   * SVG locates the rendered <svg> via data-card-id (all tab panes stay
   * mounted, so cards in hidden tabs are reachable too).
   */
  const downloadCard = useCallback(async (card: KnowledgeCard, fmt: string): Promise<void> => {
    if (fmt === 'md') downloadAsMarkdown(card)
    else if (fmt === 'html') downloadAsHtml(card)
    else if (fmt === 'json') downloadAsJson(card)
    else if (fmt === 'txt') downloadAsText(card)
    else if (fmt === 'svg') {
      if (isMermaidCardType(card.type)) {
        const el = document.querySelector(`[data-card-id="${card.id}"]`)
        const svgEl = el?.querySelector('svg')
        if (svgEl !== null && svgEl !== undefined) {
          await downloadAsSvg(card, svgEl.outerHTML)
        }
      } else {
        await downloadAsSvg(card, buildCardSvg(card))
      }
    }
  }, [])

  /** Download every card in its own selected format (defaults to MD). */
  const handleDownloadAll = useCallback(async () => {
    for (const card of cards) {
      try {
        await downloadCard(card, formats[card.id] ?? 'md')
      } catch (err) {
        // One failing card (e.g. PNG capture blocked) must not abort the batch.
        console.error('[cards] download failed:', card.title, err)
      }
    }
  }, [cards, formats, downloadCard])

  // ===== Loading state =====
  if (loading && cards.length === 0) {
    return (
      <div className={css.gallery}>
        <div className={css.toolbar}>
          <span className={css.toolbarTitle}>{t('gallery.title')}</span>
          <button className={`${css.toolbarBtn} ${css.closeBtn}`} onClick={onClose}>
            {t('gallery.close')}
          </button>
        </div>
        <div className={css.loading}>
          <div className={css.loadingDots}>
            <span /><span /><span />
          </div>
          <span>{t('dialog.generating')}</span>
        </div>
      </div>
    )
  }

  // ===== Empty state =====
  if (cards.length === 0) {
    return (
      <div className={css.gallery}>
        <div className={css.toolbar}>
          <span className={css.toolbarTitle}>{t('gallery.title')}</span>
          <button className={`${css.toolbarBtn} ${css.closeBtn}`} onClick={onClose}>
            {t('gallery.close')}
          </button>
        </div>
        <div className={css.empty}>
          <span className={css.emptyIcon}>📭</span>
          <span>{t('gallery.empty')}</span>
        </div>
      </div>
    )
  }

  // ===== Tab view =====
  return (
    <div className={css.gallery}>
      {/* Tab bar */}
      <div className={css.tabBar}>
        {activeTypes.map((type) => {
          const theme = CARD_THEMES[type]
          const count = (grouped.get(type) ?? []).length
          const isActive = currentTab === type
          return (
            <button
              key={type}
              className={`${css.tab} ${isActive ? css.tabActive : ''}`}
              style={isActive ? { borderBottomColor: theme.theme, color: theme.theme } : undefined}
              onClick={() => setActiveTab(type)}
            >
              <span className={css.tabIcon}>{theme.icon}</span>
              <span>{t(`card.type.${type}` as CardsKey)}</span>
              <span className={css.tabCount}>{count}</span>
            </button>
          )
        })}
        <button className={`${css.toolbarBtn} ${css.closeBtn}`} onClick={onClose}>
          {t('gallery.close')}
        </button>
      </div>

      {/* Toolbar: batch actions only (per-card format lives on each card) */}
      <div className={css.toolbar}>
        <span className={css.toolbarHint}>{t('gallery.hint')}</span>
        <button className={css.toolbarBtn} onClick={() => void handleDownloadAll()}>
          ⬇ {t('gallery.downloadAll')}
        </button>
        <button className={css.toolbarBtn} onClick={onRegenerateAll}>
          {t('gallery.regenerateAll')}
        </button>
      </div>

      {/* Tab panes: ALL rendered; inactive ones hidden via visibility so
          PNG/SVG DOM capture works for cards in any tab. */}
      <div className={css.tabContent}>
        {activeTypes.map((type) => (
          <div
            key={type}
            className={`${css.tabPane} ${type === currentTab ? '' : css.tabPaneHidden}`}
          >
            {(grouped.get(type) ?? []).map((card) => (
              <CardView
                key={card.id}
                card={card}
                format={formats[card.id] ?? 'md'}
                onFormatChange={setCardFormat}
                t={t}
                onRegenerate={onRegenerate}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}
