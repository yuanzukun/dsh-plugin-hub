/**
 * Mermaid diagram renderer with a custom low-saturation theme that matches
 * the card visual quality: light node fills, themed borders, muted lines.
 *
 * Mermaid is loaded dynamically so it never affects the initial bundle size.
 */

/** Mermaid theme variables matching the card design system. */
const CARD_MERMAID_THEME = {
  theme: 'base' as const,
  themeVariables: {
    primaryColor: '#EEF2F8',
    primaryTextColor: '#1a1a2e',
    primaryBorderColor: '#4A6FA5',
    lineColor: '#5B6B7E',
    secondaryColor: '#EDF0F4',
    tertiaryColor: '#F6F0E3',
    background: '#ffffff',
    fontSize: '13px',
    fontFamily: 'system-ui, -apple-system, "Segoe UI", sans-serif',
    borderRadius: 6,
  },
  flowchart: {
    curve: 'basis' as const,
    padding: 12,
  },
}

let mermaidLoaded: Promise<typeof import('mermaid')['default']> | null = null

/** Lazy-load mermaid once. */
async function loadMermaid(): Promise<typeof import('mermaid')['default']> {
  if (mermaidLoaded === null) {
    mermaidLoaded = import('mermaid').then((m) => m.default)
  }
  return mermaidLoaded
}

/** Counter for unique render IDs (avoids DOM id collisions). */
let renderCounter = 0

/**
 * Render a Mermaid diagram into a container element.
 * On parse error, shows the raw code as a fallback.
 */
export async function renderMermaid(
  code: string,
  container: HTMLElement,
): Promise<string | undefined> {
  try {
    const mermaid = await loadMermaid()
    mermaid.initialize({ startOnLoad: false, ...CARD_MERMAID_THEME })
    const id = `mmd-${Date.now()}-${renderCounter++}`
    const { svg } = await mermaid.render(id, code)
    container.innerHTML = svg
    return svg
  } catch {
    // Fallback: show raw mermaid code in a code block
    container.innerHTML = `<pre style="font-size:12px;color:#666;background:#f5f5f5;padding:10px;border-radius:6px;overflow:auto">${escapeHtml(code)}</pre>`
    return undefined
  }
}

/** Render Mermaid and return the SVG string (for download). */
export async function mermaidToSvg(code: string): Promise<string | undefined> {
  try {
    const mermaid = await loadMermaid()
    mermaid.initialize({ startOnLoad: false, ...CARD_MERMAID_THEME })
    const id = `mmd-svg-${Date.now()}-${renderCounter++}`
    const { svg } = await mermaid.render(id, code)
    return svg
  } catch {
    return undefined
  }
}

/** Escape HTML for fallback display. */
function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}
