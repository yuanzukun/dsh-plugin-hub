/**
 * Module-level card store: persists knowledge cards across dialog open/close.
 *
 * CardButton (always mounted) monitors the conversation and pushes parsed
 * cards here; CardDialog reads from here so closing the dialog does not lose
 * state or stop background generation.
 */
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type { KnowledgeCard, CardType } from './card-generator.ts'
import { emptyFacts, mergeFacts as mergeFactsFn, type SessionFacts } from './facts.ts'

type CardListener = (cards: KnowledgeCard[]) => void
type StatusListener = (status: GenerationStatus) => void

/** A pending card-generation request (types + source range). */
export interface PendingRequest {
  types: readonly CardType[]
  topic: string
  /** Turn numbers used for model-rendered cards (manual selection or all). */
  sourceTurns: readonly number[]
  /** Turn numbers used for facts extraction (whole history for timeline/checklist). */
  factsTurns: readonly number[]
}

export type GenerationStatus =
  | { phase: 'idle' }
  | { phase: 'generating'; sessionId: SessionId }
  | { phase: 'ready'; sessionId: SessionId; count: number }
  | { phase: 'error'; sessionId: SessionId; message: string }

const cardMap = new Map<SessionId, KnowledgeCard[]>()
const cardListeners = new Map<SessionId, Set<CardListener>>()
const statusMap = new Map<SessionId, GenerationStatus>()
const statusListeners = new Map<SessionId, Set<StatusListener>>()

// Track the last assistant seq we've checked per session
const lastCheckedSeqMap = new Map<SessionId, number>()
// What we're waiting for: 'cards' | 'topics' | 'regenerate' | null
const waitingForMap = new Map<SessionId, 'cards' | 'topics' | 'regenerate' | null>()
const regeneratingIdMap = new Map<SessionId, string | null>()
// Pending generation request (types + source range) per session
const pendingMap = new Map<SessionId, PendingRequest>()
// Incrementally merged session facts per session
const factsMap = new Map<SessionId, SessionFacts>()

export function getCards(sessionId: SessionId): KnowledgeCard[] {
  return cardMap.get(sessionId) ?? []
}

export function setCards(sessionId: SessionId, cards: KnowledgeCard[]): void {
  cardMap.set(sessionId, cards)
  const set = cardListeners.get(sessionId)
  if (set !== undefined) for (const fn of set) fn(cards)
}

export function updateCard(sessionId: SessionId, card: KnowledgeCard): void {
  const prev = cardMap.get(sessionId) ?? []
  const next = prev.map((c) => (c.id === card.id ? card : c))
  setCards(sessionId, next)
}

export function subscribeCards(sessionId: SessionId, fn: CardListener): () => void {
  let set = cardListeners.get(sessionId)
  if (set === undefined) {
    set = new Set()
    cardListeners.set(sessionId, set)
  }
  set.add(fn)
  return () => { set!.delete(fn) }
}

export function getStatus(sessionId: SessionId): GenerationStatus {
  return statusMap.get(sessionId) ?? { phase: 'idle' }
}

export function setStatus(sessionId: SessionId, status: GenerationStatus): void {
  statusMap.set(sessionId, status)
  const set = statusListeners.get(sessionId)
  if (set !== undefined) for (const fn of set) fn(status)
}

export function subscribeStatus(sessionId: SessionId, fn: StatusListener): () => void {
  let set = statusListeners.get(sessionId)
  if (set === undefined) {
    set = new Set()
    statusListeners.set(sessionId, set)
  }
  set.add(fn)
  return () => { set!.delete(fn) }
}

export function getLastCheckedSeq(sessionId: SessionId): number {
  return lastCheckedSeqMap.get(sessionId) ?? 0
}

export function setLastCheckedSeq(sessionId: SessionId, seq: number): void {
  lastCheckedSeqMap.set(sessionId, seq)
}

export function getWaitingFor(sessionId: SessionId): 'cards' | 'topics' | 'regenerate' | null {
  return waitingForMap.get(sessionId) ?? null
}

export function setWaitingFor(sessionId: SessionId, val: 'cards' | 'topics' | 'regenerate' | null): void {
  waitingForMap.set(sessionId, val)
}

export function getRegeneratingId(sessionId: SessionId): string | null {
  return regeneratingIdMap.get(sessionId) ?? null
}

export function setRegeneratingId(sessionId: SessionId, id: string | null): void {
  regeneratingIdMap.set(sessionId, id)
}

export function setPendingRequest(sessionId: SessionId, request: PendingRequest): void {
  pendingMap.set(sessionId, request)
}

export function getPendingRequest(sessionId: SessionId): PendingRequest | null {
  return pendingMap.get(sessionId) ?? null
}

export function clearPendingRequest(sessionId: SessionId): void {
  pendingMap.delete(sessionId)
}

export function getFacts(sessionId: SessionId): SessionFacts {
  return factsMap.get(sessionId) ?? emptyFacts()
}

export function setFacts(sessionId: SessionId, facts: SessionFacts): void {
  factsMap.set(sessionId, facts)
}

export function mergeFacts(sessionId: SessionId, facts: SessionFacts): SessionFacts {
  const merged = mergeFactsFn(getFacts(sessionId), facts)
  factsMap.set(sessionId, merged)
  return merged
}

/**
 * Record the current latest assistant seq so we only look at messages after this.
 */
export function recordCurrentSeq(
  sessionId: SessionId,
  nodes: readonly { kind: string; seq: number }[],
): void {
  const lastAsst = [...nodes]
    .filter((n) => n.kind === 'assistant')
    .sort((a, b) => b.seq - a.seq)[0]
  if (lastAsst !== undefined) setLastCheckedSeq(sessionId, lastAsst.seq)
}
