/**
 * Conversation data collector: extracts turn-by-turn text from the
 * ConversationSnapshot for card generation.
 *
 * Data path (verified by source exploration):
 *   snapshot.nodes: ConversationNode[]  ← direct node array, no chat.nodes hop
 *   UserMessageNode.content: ContentBlock[] ← filter type==='text' -> .text
 *   AssistantMessageNode.blocks: AssistantBlock[] ← filter kind==='text' -> .text
 *   AssistantMessageNode.turn: number ← turn id
 */

import { extractMarkdownPlainText } from '@deepseek-ai/dsh-client-ui-primitives'
import type { ConversationSnapshot, AssistantBlock } from '@deepseek-ai/dsh-client-runtime/client'

/** One conversation turn's collected text. */
export interface TurnContent {
  /** Turn number (from AssistantMessageNode.turn). */
  turn: number
  /** Node sequence number for ordering. */
  seq: number
  /** User's prompt text, or null. */
  userText: string | null
  /** Assistant response text blocks (one per step). */
  assistantTexts: string[]
  /** Reasoning text blocks (optional, usually excluded from cards). */
  reasoningTexts: string[]
  /** Tool call names for context. */
  toolCalls: string[]
  /** Timestamp of the latest message in this turn. */
  timestamp: number
}

/**
 * Collect all conversation turns from a session snapshot.
 *
 * User messages have no `turn` field, so they attach to the nearest following
 * assistant turn by seq proximity. A user message before any assistant message
 * gets its own pseudo-turn keyed by seq.
 */
export function collectTurns(snapshot: ConversationSnapshot): TurnContent[] {
  const nodes = snapshot.nodes
  const turns = new Map<number, TurnContent>()
  let pendingUser: { seq: number; text: string; time: number } | null = null

  for (const node of nodes) {
    // User message
    if (node.kind === 'user') {
      const text = extractUserText(node)
      if (text !== null) {
        pendingUser = { seq: node.seq, text, time: node.time }
      }
      continue
    }

    // Assistant message
    if (node.kind === 'assistant') {
      const turnId = node.turn
      let tc = turns.get(turnId)
      if (tc === undefined) {
        tc = emptyTurn(turnId, node.seq, node.time)
        turns.set(turnId, tc)
      }

      // Attach pending user text to this turn
      if (pendingUser !== null) {
        tc.userText = pendingUser.text
        tc.seq = pendingUser.seq
        pendingUser = null
      }

      // Extract assistant blocks
      for (const block of node.blocks) {
        if (block.kind === 'text') {
          tc.assistantTexts.push(extractMarkdownPlainText(block.text))
        } else if (block.kind === 'reasoning') {
          tc.reasoningTexts.push(block.text)
        } else if (block.kind === 'tool-call') {
          tc.toolCalls.push(block.name)
        }
      }
      tc.timestamp = Math.max(tc.timestamp, node.time)
      continue
    }

    // Other node kinds (command, compaction, etc.) flush pending user
    if (pendingUser !== null && pendingUser.text.trim() !== '') {
      const pseudoTurn = pendingUser.seq
      if (!turns.has(pseudoTurn)) {
        turns.set(pseudoTurn, {
          turn: pseudoTurn,
          seq: pendingUser.seq,
          userText: pendingUser.text,
          assistantTexts: [],
          reasoningTexts: [],
          toolCalls: [],
          timestamp: pendingUser.time,
        })
      }
      pendingUser = null
    }
  }

  // Flush trailing pending user
  if (pendingUser !== null && pendingUser.text.trim() !== '') {
    const pseudoTurn = pendingUser.seq
    if (!turns.has(pseudoTurn)) {
      turns.set(pseudoTurn, {
        turn: pseudoTurn,
        seq: pendingUser.seq,
        userText: pendingUser.text,
        assistantTexts: [],
        reasoningTexts: [],
        toolCalls: [],
        timestamp: pendingUser.time,
      })
    }
  }

  return [...turns.values()].sort((a, b) => a.turn - b.turn)
}

/** Extract plain text from a user message's ContentBlock[]. */
function extractUserText(node: { content: unknown }): string | null {
  const blocks = node.content as readonly { type: string; text?: string }[]
  if (!Array.isArray(blocks)) return null
  const texts = blocks
    .filter((b) => b.type === 'text' && typeof b.text === 'string')
    .map((b) => b.text!)
  return texts.length > 0 ? texts.join('\n') : null
}

/** Create an empty TurnContent. */
function emptyTurn(turn: number, seq: number, time: number): TurnContent {
  return {
    turn,
    seq,
    userText: null,
    assistantTexts: [],
    reasoningTexts: [],
    toolCalls: [],
    timestamp: time,
  }
}

/**
 * Merge a turn's text into a single string for prompt building.
 */
export function turnToText(tc: TurnContent): string {
  const parts: string[] = []
  if (tc.userText) parts.push(`用户: ${tc.userText}`)
  if (tc.assistantTexts.length > 0) parts.push(`助手: ${tc.assistantTexts.join('\n')}`)
  if (tc.toolCalls.length > 0) parts.push(`工具调用: ${tc.toolCalls.join(', ')}`)
  return parts.join('\n')
}

/**
 * Whether the session has older history that can be loaded.
 */
export function needsLoadOlder(snapshot: ConversationSnapshot): boolean {
  return snapshot.hasMore && !snapshot.loadingOlder
}

/**
 * Extract text blocks from an assistant message's blocks array.
 * Used by the parser to scan Agent card output.
 */
export function getAssistantTextBlocks(blocks: readonly AssistantBlock[]): string[] {
  return blocks
    .filter((b): b is Extract<AssistantBlock, { kind: 'text' }> => b.kind === 'text')
    .map((b) => b.text)
}
