/**
 * Knowledge-cards plugin, browser half: registers the header action button
 * into the conversation session header, with an injected send callback that
 * routes /generate-cards directives to the session's agent conversation.
 *
 * All policy lives here - the topic splitting mode, card type selection,
 * Agent output parsing, and download - so composing this plugin out of
 * cordis.yml removes the entire surface at zero cost.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type { IConversation } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import { CardButton } from './components/CardButton.tsx'
import type { CardButtonInjected } from './components/CardButton.tsx'
import { en, NS, zh, type CardsKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** Knowledge-cards copy: button, dialog, gallery, card actions. */
    'cards': CardsKey
  }
}

export { CardButton } from './components/CardButton.tsx'
export type { CardButtonInjected } from './components/CardButton.tsx'
export { collectTurns, type TurnContent } from './card-data-collector.ts'
export {
  type KnowledgeCard, type Topic, type CardType,
  CARD_THEMES, ALL_CARD_TYPES,
} from './card-generator.ts'
export { parseCardsFromText, parseTopicsFromText, hasGenerationMarker } from './card-parser.ts'
export { downloadAsMarkdown, downloadAsHtml, downloadAsSvg } from './download.ts'
export { getCards, subscribeCards, getStatus, subscribeStatus, type GenerationStatus } from './card-store.ts'

/** Required services for the header-action registration. */
export const inject = ['slots', 'locale', 'sessions']

/**
 * Client plugin body: register dictionaries and the header action button.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'ui-knowledge-cards: dictionaries')

  // Use ctx.inject to create a session-scoped context where we can bind
  // a send callback to each session's conversation service.
  ctx.inject(['slots', 'sessions'], (scope: ClientContext) => {
    const sessions = scope.sessions

    scope.slots.inject(
      'conversation.session.header.actions',
      () => scope.slots.register({
        name: 'conversation.session.header.actions',
        id: 'knowledge-cards',
        order: 100,
        locale: NS,
        inject: (sessionId: SessionId): CardButtonInjected => {
          const actx = sessions.scope(sessionId)
          if (actx === undefined) {
            throw new Error(`ui-knowledge-cards: session "${String(sessionId)}" resolved no scope`)
          }
          const conversation = actx.get('conversation') as IConversation | undefined
          if (conversation === undefined) {
            throw new Error(`ui-knowledge-cards: session "${String(sessionId)}" has no conversation`)
          }
          return {
            send: (text: string) => conversation.send(text),
            loadOlder: () => conversation.loadOlder(),
          }
        },
      }, CardButton),
    )
  })
}
