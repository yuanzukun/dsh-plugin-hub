/**
 * Parses Agent output (assistant message text) to extract structured card
 * and topic JSON from fenced code blocks.
 *
 * The Agent emits ```card and ```topics code blocks per the systemPrompt
 * guidance; this module finds and validates them.
 */

import type { KnowledgeCard, Topic, CardType } from './card-generator.ts'

/** Valid card type strings for validation. */
const VALID_CARD_TYPES = new Set<CardType>([
  'concept', 'flowchart', 'comparison', 'summary', 'mindmap',
  'quote', 'checklist', 'timeline', 'faq',
])

/**
 * Parse all ```card JSON blocks from a text string.
 * Returns KnowledgeCard[] with runtime ids assigned.
 */
export function parseCardsFromText(
  text: string,
  sourceTurns: readonly number[] = [],
  topic = '',
): KnowledgeCard[] {
  const cards: KnowledgeCard[] = []
  // Match ```card\n{...}```
  const cardRegex = /```card\s*\n([\s\S]*?)```/g
  let match: RegExpExecArray | null

  while ((match = cardRegex.exec(text)) !== null) {
    const jsonStr = match[1]!.trim()
    try {
      const parsed = JSON.parse(jsonStr) as { type?: string; title?: string; content?: string }
      if (!isValidCardType(parsed.type) || typeof parsed.title !== 'string' || typeof parsed.content !== 'string') {
        continue
      }
      cards.push({
        id: crypto.randomUUID(),
        type: parsed.type as CardType,
        title: parsed.title,
        content: parsed.content,
        sourceTurns: [...sourceTurns],
        topic,
      })
    } catch {
      // Skip malformed JSON
    }
  }

  return cards
}

/**
 * Parse all ```topics JSON blocks from a text string.
 * Returns Topic[].
 */
export function parseTopicsFromText(text: string): Topic[] {
  const topics: Topic[] = []
  const topicRegex = /```topics\s*\n([\s\S]*?)```/g
  let match: RegExpExecArray | null

  while ((match = topicRegex.exec(text)) !== null) {
    const jsonStr = match[1]!.trim()
    try {
      const parsed = JSON.parse(jsonStr) as unknown
      if (!Array.isArray(parsed)) continue

      for (const item of parsed) {
        const t = item as { title?: unknown; turns?: unknown; summary?: unknown }
        if (typeof t.title !== 'string' || !Array.isArray(t.turns)) continue
        topics.push({
          title: t.title,
          turns: t.turns.filter((n): n is number => typeof n === 'number'),
          summary: typeof t.summary === 'string' ? t.summary : '',
        })
      }
    } catch {
      // Skip malformed JSON
    }
  }

  return topics
}

/**
 * Parse a single regenerated card from text (the first ```card block).
 */
export function parseRegeneratedCard(text: string, original: KnowledgeCard): KnowledgeCard | null {
  const cards = parseCardsFromText(text, original.sourceTurns, original.topic)
  if (cards.length === 0) return null
  // Use the first parsed card but keep the original id for in-place replacement
  return { ...cards[0]!, id: original.id }
}

/**
 * Check if the text contains the knowledge-cards-generated marker.
 */
export function hasGenerationMarker(text: string): boolean {
  return text.includes('<!-- knowledge-cards-generated -->')
}

/** Check if a string is a valid card type. */
function isValidCardType(value: unknown): value is CardType {
  return typeof value === 'string' && VALID_CARD_TYPES.has(value as CardType)
}
