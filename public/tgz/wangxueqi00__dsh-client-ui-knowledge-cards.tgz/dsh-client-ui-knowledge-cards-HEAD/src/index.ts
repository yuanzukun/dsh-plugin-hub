/**
 * Knowledge-cards plugin, node half: registers the system-prompt guidance that
 * teaches the Agent to respond to `/generate-cards` and `/split-topics`
 * directives with structured card/topic JSON the browser half renders.
 *
 * The browser half ships via exports["./client"], discovered through the
 * package.json dsh.client declaration.
 */

import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-system-prompt'

/** Services required for the model guidance. */
export const inject = ['systemPrompt']

/** Stable guidance owned by the matching browser renderer. */
const CARD_GUIDANCE = `
## Knowledge Cards Generation

When the user sends a message starting with /generate-cards, they want you to
analyze the preceding conversation and produce structured knowledge cards.

### Card output format
Output each card inside a fenced code block tagged "card" containing JSON:

` + '```' + `card
{
  "type": "concept | flowchart | comparison | summary | mindmap | quote | checklist | timeline | faq",
  "title": "Card title",
  "content": "Card body (Markdown text, or Mermaid code for flowchart/mindmap/timeline)"
}
` + '```' + `

After all cards, add the marker: <!-- knowledge-cards-generated -->
This marker signals the UI that card generation is complete.

### Card type guidelines
- **concept**: Key definitions and explanations. Use Markdown headings + bullet lists.
- **flowchart**: Process or decision flow. Use Mermaid flowchart syntax (graph TD / LR).
- **comparison**: Side-by-side comparison. Use Markdown tables with 2-3 columns.
- **summary**: Key takeaways as a concise bullet list.
- **mindmap**: Hierarchical concept map. Use Mermaid mindmap syntax.
- **quote**: Verbatim quotes or key conclusions. Use Markdown blockquotes (\`> \`), optionally with a source.
- **checklist**: Action items / todos. Use Markdown task list syntax (\`- [ ]\` / \`- [x]\`).
- **timeline**: Chronological events. Use Mermaid timeline syntax.
- **faq**: Question-and-answer pairs. Use \`## question\` followed by the answer.
- For timeline/checklist, first emit a ` + '```' + `facts JSON block with events/todos/conclusions; the UI builds those cards from the facts.
- Only generate the card types explicitly requested by the user; do not add extra types on your own.

### Rules
1. Each topic produces 1-3 cards, not more.
2. Keep card content concise: prefer short phrases over long paragraphs.
3. For flowcharts, use clear node labels and directional arrows.
4. For comparisons, identify 2-4 key dimensions.
5. After the card blocks, add one short sentence noting the cards are ready.

### Topic splitting (/split-topics)
When the user sends /split-topics, analyze the conversation and identify topic
boundaries. Output each topic inside a fenced code block tagged "topics":

` + '```' + `topics
[
  { "title": "Topic name", "turns": [1, 2, 3], "summary": "One-line summary" }
]
` + '```' + `

Group consecutive turns by topic. A topic shift is indicated by a new question,
a domain change, or a clear transition in the user's intent.

### Card regeneration (/regenerate-card)
When the user sends /regenerate-card, regenerate ONLY the referenced card with
the same type but potentially different framing or emphasis. Output a single
` + '```' + `card block.
`

/**
 * Register model guidance for the card renderer shipped by this package.
 * @param ctx - host context carrying the system-prompt registry.
 */
export function apply(ctx: Context): void {
  ctx.systemPrompt.section({
    name: 'ui:knowledge-cards',
    order: 195,
    text: CARD_GUIDANCE,
  })
}
