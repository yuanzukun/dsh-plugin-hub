# 自进化主链路从未通电（2026-09-24 取证）

> ✅ **已通电（2026-09-29 06:20Z 实跑取证）** —— 走的是 driver 自有 commit 路径（B 方案），
> **不是** `mutator.commit`。
>
> 决定性证据（`evolution-cycle` 实跑一轮）：
>
> | 判据 | 结果 |
> |---|---|
> | `git status --porcelain` | **`M bin/plugin-check.sh`** —— 改动**留在仓库**，不是回滚后的 clean |
> | `.agint-preimage/` | +1 条 `bin__plugin-check.sh__2026-09-29T07-19-59-845Z.bak`（写入前已备份） |
> | `agint_mutator.proposals` | 5 → 6 |
> | `evolution_queryFailures` | 本轮**无** `evolution-commit-rejected` 记录（前两轮都有） |
> | `bash -n`（v0.2.9 验证器） | 通过 |
>
> 即完整走通：**提案 → LLM 编辑 → 幻觉闸门 → 写入仓库（带 preimage）→ 写入后验证
> → policy 批准 → 落盘**。
>
> ⚠️ **仍不确定的一点**：`policyDecision` 的具体值拿不到 —— cron 持久化只写 `keys` 不写值
> （`agint_cron.json` 的 `lastResultSummary`），event-bus 又收不到 driver 事件（T1 影子期）。
> 只能从「改动落盘」反推它**不是** REJECT/ABSTAIN，**是 AUTO_DEPLOY 还是 PENDING_REVIEW 未取证**。
> 这属于可观测性缺口，已记在下方待办。
>
> ⚠️ 另：`mutator.commit` 至今**全仓仍无生产调用点**。本条通电**不代表** A 方案
> （统一到 mutator.commit）已完成 —— 它需要给 FROZEN 的 `PromptMutationPayloadSchema` 加
> `targetPath`，触发 L0 变更（人类多签 + 7 天影子 + major 版本），**未做**。
>
> ### 2026-10-31 复核：真正的问题不在「没人调 commit」，而在它旁边的状态机被契约错配废掉了
>
> 顺着「commit 零调用」往下查，查出三个此前没人写下来的事实：
>
> 1. **`table.entries()` 返回 `[key,value]` 元组迭代器**（`dsh-storage-domain` 0.2.1-rc.3
>    `KvTableImpl.entries()`），而 mutator 6 处当扁平对象用。Node 22 的 Iterator Helpers
>    让 `.find/.some` 在迭代器上**存在且不抛** ⇒ `e.id` 恒 undefined ⇒ 全部静默。
>    ⇒ `propose` 的唯一约束、`recordExternalCommit` 的幂等与**状态推进**、`rollback` 的
>    两次查表，四个功能一起失效；A5（2026-10-03）那句「driver 产出的 commit 从此可被
>    `mutator.rollback` 回滚」**从未成立**。已修（mutator 0.6.12），并同步把 8 个测试文件的
>    mock 改成真实契约 —— 原 mock 返回扁平数组，正是它让这个 bug 绿了三个月（K115）。
> 2. **存量 8 条 proposal 全部停在 `PENDING`**（尽管 `commits` 表里 8 条一一对应、
>    全 `AUTO_DEPLOY`）。修复后唯一约束真的会拦，故已按 `commit.policyDecision` 回填为
>    `COMMITTED` 并重启生效（2026-10-31，8/8；备份 `/tmp/agint_mutator.before-backfill.json`）。
> 3. **门禁此前看不见这类问题**：`check-wiring` 的查 A 只判到「名字有没人提」，一旦被
>    伞键 `ctx.get('agint.mutator')` 覆盖就落 `NAMESPACE_ONLY`、**不判 FAIL**。
>    已新增**查 A2 DEAD_METHOD**（只认调用形态，不认名字出现过）+ `docs/wiring-baseline.json`
>    ratchet，存量 13 条认账、新增即红。
>
> **因此对 A 方案的判断随之改变**：`mutator.commit` 的边际收益比 2026-09-29 那次评估时更小
> —— 记账、可回滚凭据、写入后验证（`verifyTargetFile` 比 `runSandbox` 更准）driver 都有了，
> 只剩「提案状态机 + `metrics_log`」两样；而接过去仍要解决 `deriveTargetPath` 只认三种固定
> 路径（实测 8 条 commit 目标 **0 条**算得对）与 `diffStrategy` 语义（driver 传
> `unified_diff` = 整文件覆盖，8/8 全是该值，直接接会整份覆盖 SKILL.md）。故维持 B 方案，
> 并把「`mutator.commit` 的 write 路径未启用」写进 manifest 描述，避免下一个人以为它在跑。

> ### ⭐ 2026-11-06 复核：主链路已**彻底**通电 —— 10 次真实 commit，无一滞留 PENDING
>
> 上面那个「`policyDecision` 拿不到」的可观测性缺口，**现在补上了** ——
> 不是靠推断，是靠 `commits` 表本身。
>
> | 判据 | 2026-11-06 实读 |
> |---|---|
> | `agint_mutator.proposals` | **10 条**，状态分布 `{COMMITTED: 10}` —— 无一条滞留 PENDING |
> | `agint_mutator.commits` | **10 条**，`policyDecision` 分布 `{AUTO_DEPLOY: 9, PENDING_REVIEW: 1}` |
> | `agint_population` 存储域 | **存在**（2026-09-24 时根本不存在） |
> | 总线 `evolution.mutation.committed` | **10 条**，source 全部为 `agint-evolution-driver` |
> | 总线该主题的时间跨度 | 2026-10-04T12:09Z → **2026-11-02T16:29:39Z**（最近一次） |
>
> ⇒ **「AUTO_DEPLOY 还是 PENDING_REVIEW 未取证」这个悬念有答案了：两者都有（9:1）。**
> 这也顺带说明 2026-10-31 那次「8 条存量全部停在 PENDING」的回填是对的 ——
> 现在 10 条全是 COMMITTED，说明修复后的唯一约束**真的在拦**，而且没把状态机卡死。
>
> ⇒ **`mutator.commit` 依然全仓无生产调用点**（A 方案未做），这一点没变。
> 维持 B 方案的决定依然成立 —— 且现在多了一条支持它的证据：
> driver 侧的 `commits` 表 10 条齐全，说明 driver 自己的**记账、preimage、
> 写入后验证**三件套都已经在生产跑住了。
>
> ⚠️ **两处仍未取证，不得含糊**：
> ① 总线里那 10 条 `evolution.mutation.committed` 的**最早一条是 10-04**，
>    而本文 §「已通电」那次实跑是 **09-29** ⇒ 那一次的事件**不在总线里**
>    （本文当时用的判据是 `git status` + preimage，本就不是总线判据，两者不矛盾）。
> ② `agint_mutator.metrics_log` 至今 **0 条** ⇒ 提案状态机这一格仍未接上。

## 📌 三轮实跑踩到的坑（全部是「单测全绿也照样漏掉」的真实案例）

| 版本 | 问题 | 发现方式 |
|---|---|---|
| v0.2.7 | commit 绕过整个 D-QAF，只做写入前闸门 | 读代码 + grep 调用点 |
| v0.2.8 | 验证器选错：`sandbox.runSmoke` 是**插件结构冒烟**（校验 package.json/exports），对任意仓库文件恒返回 `package-json-missing` | **真实 cron 跑** |
| v0.2.8 | `node --check` 对 ESM **漏检**：`.js` 里 `export const a = ;` 退出码 0（`.mjs` 才是 1）——而仓库几乎所有 `lib/*.js` 都是 ESM | **写单测时实测** |
| v0.2.9 | policy 契约错配：`computeComposite` 只认 `d.key`，`name`-only ⇒ `weights[undefined]=0` ⇒ `den===0` ⇒ 恒 REJECT | **真实 cron 跑 + 查 failure_pattern** |

> 共同教训：**mock 要复读契约，不是复读被测代码的期望**。v0.2.8 的 T25 用
> `policy.decide: async () => ({ kind: 'AUTO_DEPLOY' })` 固定返回值，字段名写错也照样绿。
> 改成复刻真实契约（无 `key` → REJECT）后，去掉 `key` 立刻变红。

> 📜 历史归档（2026-09-27，v0.8.6）与 2026-09-24 原始取证快照见文末。

## ⭐ 2026-09-29 根因定性：不是「没接通」，是架构分叉

2026-09-27 的 VERSION 记为「四判据全中」，2026-09-29 复核只复现了前两环。根因查清了：

```
agint-evolution-driver.runOnce()
   ├─ mutator.propose()      ✅ 提案落盘
   ├─ mutator.validate()     ✅
   ├─ population.ingest()    ✅ variant 落盘（stage=PENDING_REVIEW）
   └─ commitToRepo()         ← 走自己的落盘路径，不经过 mutator.commit
        ├─ COMMIT_DENYLIST / oldText 唯一性 / preimage 备份   ← 只有「写入前闸门」
        └─ 直接发 evolution.mutation.committed               ← 没有「写入后验证」
             └─> sandbox.runSmoke 从不被调用 ⇒ sandbox.passed/failed 恒 0
             └─> policy.decide 从不被调用
             └─> mutator.commits 表永远 0 条
```

`mutator.commit()` 本身是完整的（preimage 5 MB 备份 + SHA-256 防篡改 + sandbox → policy →
REJECT/ABSTAIN 自动恢复），但**全仓没有任何代码调用它**。真正在跑的 `commitToRepo()` 绕开了
整个 D-QAF —— 这正是 AGENTS.md 明令禁止的「绕过 D-QAF 任意阶段直接部署」。

顺带查实两个此前存疑的点：

1. `mutator.commits` 恒 0 **与 mutator 域是否通电无关**。域早于 2026-09-27 就落盘了，
   断的是 commit 这一环，不是域。
2. `agint_qualitySandbox` / `agint_qualityPolicy` 两个 Service **一直存在**
   （`plugins/agint-quality-sandbox/lib/index.js:364`、`plugins/agint-quality/agint-quality-policy/lib/index.js:322`），
   从来不是「依赖缺失」，只是没人调。

## ✅ 2026-09-29 处置：driver v0.2.7 补写入后验证（老板拍板 B 方案）

commit `7e8bffc`。原 A 方案（统一到 `mutator.commit`）经核对后**不可行**：

- `mutator.generatePostimage` 对 `PROMPT_MUTATION` 直接 `return p.newText` 当**整份文件内容**，
  而 driver 是 `text.replace(oldText, newText)` **局部替换** —— 直接接线会把 SKILL.md
  整份覆盖成一个小节。
- `mutator.deriveTargetPath` 硬编码 `plugins/{pluginId}/prompts/{promptId}.md`，
  对 driver 的 skill / repo 目标**全部算错**。
- 修这两处要给 FROZEN 的 `PromptMutationPayloadSchema` 加 `targetPath` ⇒ 触发 **L0 变更**
  （人类多签 + 7 天影子模式 + major 版本）。

顺带发现一个**独立的契约 bug**：`diffStrategy` 在 FROZEN 枚举里声明了
`unified_diff`（局部替换语义），但全插件 30 处引用**无一处消费它**，
`generatePostimage` 永远整文件覆盖。待单独修。

> ✅ **已修（mutator v0.6.7，2026-09-29）**：两值全部实装，零 FROZEN 变更。
> 更正一点：本段初稿把 `unified_diff` 理解为「局部替换语义」是**反的** —— 全仓 30 处
> 调用（driver:582、eval 场景、各测试）无一例外把 `unified_diff` 当「newText 即完整
> 内容」的标记用，无一处传真正的补丁文本。故接线语义定为：`unified_diff` = 整文件
> 覆盖（与既有用法逐字节兼容，30 处调用零迁移）；`line_replace`（缺省默认）= oldText
> 局部替换，oldText 缺失或不唯一即 throw（fail-closed）。详见 mutator CHANGELOG 0.6.7。

### v0.2.7 做了什么

| | 改动前 | v0.2.7 后 |
|---|---|---|
| 写入前闸门 | denylist / oldText 唯一性 / preimage | 不变 |
| 写入后验证 | ❌ 无 | `sandbox.runSmoke` → `policy.decide` |
| 决策为拒 | — | 从 `.agint-preimage/*.bak` 回滚，发 `rolledback` |
| 验证通道缺失 | 照写（无验证） | ⛔ **fail-closed，根本不写**，发 `commit-skipped` |
| 事件留痕 | `committed` | 增 `policyDecision` / `sandboxOk`；新增 `rolledback` / `commit-skipped` |

**为什么这样就能通电**：`agint-quality-sandbox` 的 `runSmoke()` 内部**自己发布**
`sandbox.passed` / `sandbox.failed`（`lib/index.js:230`，另有 `test/runSmoke-publish.test.mjs`
专门防漏接线回归）。所以 driver 调一次 `runSmoke`，事件就产生；
`agint-diagnosis` 早已订阅 `sandbox.failed`（`lib/index.js:463-487`），
`analyzeFailedSmoke` 这条断了两年的支路即被唤醒。

### 尚未验证

改动已部署到双副本（mirror + bundle，各留 8 份 `.bak-` 备份），
**宿主尚未重启**，`sandbox.*` 仍为 0 条。重启 + 跑一次 `evolution-cycle` 后才能确认通电；
若届时收到的是 `commit-skipped` 而非 `committed`，说明 sandbox/policy Service 在运行时
未就绪，需回头查 Service 挂载（不是继续等）。

> 📜 历史归档（2026-09-27，v0.8.6）：`agint-evolution-driver` v0.2.0–v0.2.4 上线后，
> 主链路于 18:30 端到端首次跑通，VERSION v0.8.6 记为「四判据全中」。
> 2026-09-29 复核：前两环可复现，**后两环（committed 事件、smoke 验证）在当前数据里未取到证**，
> 且已查明根因是 driver 的 commitToRepo 绕过 mutator.commit。状态由「已解决」下调为「半通电」。
>
> 建档人：智（自动盘点取证）｜判据脚本：`bin/check-wiring.mjs`｜自测：`bin/check-wiring.test.mjs`

---

## 一、事实

### 1.1 存储域通电检查（查 D）

插件用 `defineDomain({ name: 'agint_xxx' })` 声明独占存储域；存储域是**首次写入才落盘**的。
所以 `$DSH_HOME/storages/agint_xxx.json` 存不存在，就是这个插件有没有真跑过的**外部可观测判据**
—— 不需要进宿主进程，看磁盘就知道。

`$DSH_HOME/storages/` 实读（**2026-09-29 复核**，取代下方 09-24 原表）：

判据：`node bin/check-wiring.mjs --json` → `domains.energized` 共 **16** 个。

| 状态 | 数量 | 域 |
| --- | --- | --- |
| ✅ 已通电 | 16 | abtest / compress_guard / cron / curator / diagnosis / event_bus / evolution / evolve / input_gateway / memory_provider / metrics / mount / **mutator** / **population** / rules / skill_autocreate |
| 从未通电 | 0（未豁免） | —— 2026-09-29 起 `agint_curriculum` 按「上游 self-model 无待练域导致的连带空转」豁免 |
| 豁免 | 2 | `agint_search`（按需调用）/ `agint_curriculum`（连带空转） |

> 两处口径提醒，避免下次又按旧表下结论：
> 1. `self_model` / `skill_graph` / `trajectory` 三个域**在磁盘上有文件**
>    （5618 B / 1195 B / 4065 B），但**不在上面 16 个里** —— 查 D 的正则只认
>    `name: 'agint_xxx'` 字面量，这三个插件没用字面量声明，故扫描器没发现它们。
>    也就是说「已通电 16」是**扫描口径**，不等于「磁盘上有文件的域总数」。
> 2. 2026-09-24 原表（见下）写「已通电 13」却列了 16 个名字，**原表本身数量与列表即不符**，
>    引用时请以本表为准。

> 2026-09-24 原表（保留供对照）：已通电 13、`agint_mutator` / `agint_population` /
> `agint_curriculum` 三个未通电、`agint_search` 豁免。
> 其中 `agint_mutator` 与 `agint_population` 已于 09-27 前后通电，见文首复核块。

### 1.2 服务调用点检查（查 A）

光看磁盘还不够（也可能是写了但被清了）。交叉验证：**全仓生产代码里，这些服务的引用数为 0。**

`agint.mutator.*` 全仓生产零引用：
`propose` / `validate` / `commit` / `rollback` / `attributionDriven` / `dreamRandom` /
`evolutionReversed` / `limits` / `checkLimit` / `io` / `publishMountRequest`

`agint.population.*` 全仓生产零引用：
`ingest` / `promote` / `cull` / `fixate` / `rollback` / `recordEvaluation` /
`config` / `updateConfig` / `limits` / `checkLimit` / `publishProposed` / `publishMountRequest`

唯一"引用"是它们自己的 `ctx.provide(...)` 那一行。
工具侧也没开入口：`mutator/lib/tools.js` 只暴露 `stats` / `logMetric`，
`population/lib/tools.js` 只暴露 `stats` / `evaluate` —— **AI 也调不到 propose/commit/cull**。

---

## 二、⭐ 因果链：一条断链拖垮一整片

这不是两个孤立的死插件，是**一条链的第一环没接**：

```
agint-mutator 从未通电
   └─> agint.mutator.commit 从不执行
         └─> sandbox.runSmoke 从不被调用        （mutator/lib/index.js:596 是唯一调用点）
               └─> sandbox.passed / sandbox.failed 恒 0
                     └─> agint-diagnosis 的 analyzeFailedSmoke 订阅永远收不到消息
   └─> agint.population 拿不到 commit 产物
         └─> 种群选择 / 晋升 / 淘汰全部空转
```

**这解释了文档 §6.12 那个悬案**：2026-09-21 修了 `runSmoke` 接线（commit `1e0d9d0`），
但生产里 `sandbox.*` 至今仍是 0 条。
**修的是接线，可上游从来不跑** —— 接线修得再对也不会有数据。

> ⛔ 教训：**修「下游没数据」之前，先确认「上游有没有在跑」。**
> 否则会像这次一样，修完仍然 0 条，然后归因为"还没触发"，白等三年。

---

## 三、为什么四天没人发现

1. **K63 只盘到「服务级空壳」，没盘「插件级空转」。**
   K63 的三步法是「列 provide → 找生产调用点 → 对账数据」，粒度停在单个服务上。
   而这里的问题粒度是**整个插件**：插件挂载了、服务注册了、测试绿了，但插件从未运行。
2. **「挂载了 ≠ 跑过」这条既有教训没有被延伸到存储域层。**
   之前的判据是「到生产存储里核实有没有数据行」—— 这次是**连存储文件都没有**，
   说明比"有表没数据"还早一个阶段。
3. **每个 Sprint 都把责任推给了下一个 Sprint。**
   `docs/plugins/agint-mutator.md:113` 白纸黑字写着
   「Sprint 9 population manager | **未来消费方**（本 sprint 不写消费端）」。
   于是 mutator 等 population 来消费，population 等别人来调它 —— **谁都没接**。
   > ⛔ 「未来消费方」是一个会自我延续的死结：每个 sprint 都可以合理地把自己标成"等下游"。
   > **写"未来消费方"时必须同时写下"由谁、在什么时机来接"，否则等于永久挂起。**

---

## 四、处置选项（待老板拍板）

| 档 | 做法 | 代价 | 我的看法 |
| --- | --- | --- | --- |
| **A. 通电** | 给 mutator / population 一个真实触发点（cron 作业或 dream/evaluate 联动），让闭环真跑起来 | 新增一条需要维护的自主变更路径；**会真的去改代码**，需要沙箱/回滚兜底 | 这是 AGINT 存在的理由。但**必须先想清楚"谁批准一次真实变异"**，否则等于让 AI 随意改自己 |
| **B. 降级为库** | 承认当前不做自主代码变更，把 mutator/population 标记为「能力储备」，从 patch 里摘掉或保留不挂 | 少一层复杂度；但"自进化"这个卖点要改口径 | 诚实，但等于砍掉 P7/P7.5 的一条主线 |
| **C. 维持现状** | 继续挂着，不动 | 零成本 | ⛔ 不建议：它们现在**只产生误导**（面板上挂着、文档里写着，实际是死的） |

> **倾向：先回答一个前置问题 —— AGINT 到底要不要「自主改自己的代码」？**
> 要 → 档 A，且必须先有沙箱 + 自动回滚 + 人工否决口（记忆第七条：可回滚 > 可审批）。
> 不要 → 档 B，把口径改干净，别让两个死引擎继续占着"自进化"的叙事。

---

## 五、已固化成门禁（不会再腐坏）

- `bin/check-wiring.mjs` —— 四查：A 空壳服务 / B 主题接线 / C 生产数据对账 / **D 存储域通电**。
  `--json` 给 CI，`--strict` 让"从未触发"也算失败，退出码 0/1/2。
- `bin/check-wiring.test.mjs` —— 门禁自测（12 项）。**测的不是能不能跑，是判据对不对**：
  已知健康的链路不许被误报（防误报回归）、豁免必须真生效、
  以及"mutator/population 尚未通电"这条状态断言 —— **修好后这里会红，提醒你回来改文档与豁免**。
- `docs/wiring-exemptions.json` —— 豁免清单，每条必须写 `reason` + `evidence` + `since`，
  缺任一条不许加。带 `unblockWhen` 的（如 `sandbox.*`）在上游通电后必须复查。

> 之前这类盘点结论写进文档就开始腐坏（09-20 记的 3 个空壳服务，到 09-24 已处理了 2 个，
> 文档却还写着未处理）。**现在判据是脚本，跑一次 3 秒，不再依赖人肉 grep 和记忆。**

---

## 六、关联

- `docs/known-limitations/event-bus-shadow-publish-gap.md` —— K63 的原型；本文是它的**上游根因**
- K77 / 文档 §6.14 —— 外部直写生产存储不算落库（本次查 D 依赖该结论：磁盘文件是可信判据）
- `docs/plugins/agint-mutator.md:113` —— "未来消费方"死结的出处

---

## 七、2026-09-24 修复进展（未完 —— 差一次重启）

### 7.1 根因层已修：5 个 umbrella 键

`fcc9a76` 给 5 个插件补了命名空间键（纯加法，全名子键一个没动）：
`agint.eventBus` / `agint.diagnosis` / `agint.mutator` / `agint.population` / `agint.selfModel`。

**判据变化**：`bin/verify-umbrella.mjs` 用 mock ctx 真跑 `apply()`，不再靠 grep 证伪。
当前 bundle + mirror 双位置 **10/10 PASS**，两条真实依赖链已通电：
`agint-mutator → agint.eventBus.publish/subscribe`（此前必降级到 `ctx.emitEvent`）、
`agint-population → agint.mutator`（此前 `softDep` 恒空）。

### 7.2 ⚠ 尚未生效 —— 部署晚于 boot

| 时间 (UTC+8) | 事件 |
|---|---|
| 09-24 00:35 | 宿主 boot（pid 4860，见 `.agint-restart/marker.json`）|
| 09-24 02:20 | umbrella 键 6 个文件部署到 bundle + 镜像位 |
| 09-24 08:40 | metrics / dreamCounters 补齐部署 |

**部署晚于启动 ⇒ 当前宿主进程里跑的仍是旧代码**，
`verify-umbrella` 全绿只能证明"磁盘上的字节码是对的"，证明不了"进程加载的是它"。
→ **必须再重启一次**，之后按 §7.3 验收。

这条险些漏掉：门禁、自测、以及"已重启"这句话当时全部看起来正常。
固化判据见同批新增的门禁**查 H**（`check-wiring.mjs`）——仓库与部署位 191 个 lib 文件逐 hash 比对，
待上线清单直接输出，专治"改了没上线"的静默失败。

### 7.3 重启后验收清单

1. `bin/check-wiring.mjs` → PASS（0 硬缺口，查 H 报"已全部同步"）
2. `bin/verify-umbrella.mjs` → 10/10 PASS
3. 隔一段时间后复查 Topics 计数：
   - `mount.requested / mount.succeeded` 是否**从 0 变成非 0**（此前因缺 umbrella 键全降级）
   - `agint_mount` / `agint_population` 域文件是否出现（此前查 D 判 DEAD）
4. 若 3 仍为 0：说明还有下游触发链条没通，回到本文 §二重新盘点 —— 别直接认定"修好了"
