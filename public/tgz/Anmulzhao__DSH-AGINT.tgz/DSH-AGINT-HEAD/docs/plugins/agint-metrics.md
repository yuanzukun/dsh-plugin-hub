# agint-metrics

> 进化指标：客观可度量的进化信号，按 kv 时间序列写。
>
> v0.2 起新增 HARM 维度作为质量子维度。

## 职责

- 提供 `agint.metrics` host Service
- 提供 `metrics_*` model 工具（collect / summary / series）
- 独占 `agint_metrics` storage domain
- 每日由 `cron.metrics-collect` 触发

## 指标清单

> 口径真源是 `plugins/agint-metrics/lib/metrics.js` 的 `METRIC_DEFS`（基础 15 + 扩展 4 = 19）。
> 下表是面向人的导读，其中若干行早于当前 `METRIC_DEFS`（生产存储实测只有 27 个 key，
> 见 `agint_metrics.json`），以 `METRIC_DEFS` 为准。

| key | 来源 | delta 含义 |
|---|---|---|
| `cron.staleOverdue` | agint.cron | + = 更多任务过期未跑（2026-11-08 拆维度） |
| `cron.staleInactive` | agint.cron | + = 更多任务久未活动（> 2 个调度周期） |
| `cron.staleJobs` | agint.cron | ⛔ 已弃用：上面两者的并集汇总，只作旧看板兜底 |
| `cron.overdue` | agint.cron | + = 错过的窗口 |
| `rules.adherencePct` | agint.rules | - = 改善 |
| `rules.denyHits` | agint.rules | + = 命中变多（不一定坏） |
| `wiki.brokenLinks` | agint.wiki | + = 变坏 |
| `wiki.orphans` | agint.wiki | + = 变坏 |
| `memory.bloat` | agint.memory | + = 膨胀 |
| `memory.coverage` | agint.memory | - = 变坏 |
| `dream.sweepCount` | agint.dream | 健康度信号 |
| `dream.promotedCount` | agint.dream | 学习量信号 |
| `tools.usageTotal` | agint.toolStats | 活跃度 |
| `quality.harm` | agint.qualityEvaluator | + = 改善（综合 HARM 趋势） |
| `quality.evaluatedCount` | agint.qualityEvaluator | 周评估任务数 |
| `quality.rollbackRate` | agint.evolve | 进化回滚率 |
| `quality.manualInterventionRate` | agint.evolve | 人工干预率 |

> **v0.3 计划**：新增 `quality.baselinePassRate`、`quality.deployCountLastWeek` 等更多健康度指标。

## 采集策略

- 懒解析：metrics_collect 不依赖任何一个 plugin；缺失源跳过
- 写 kv 时间序列：每个 key 每天一行
- delta = 最新值 - 上一次值

## 模型接口

- `metrics_collect` 跑一次快照（写入 storage）
- `metrics_summary` 看最新值 + delta
- `metrics_series <key> --days 30` 看趋势

## 与其他插件的关系

- **`agint.cron`**：metrics-collect job 每日触发
- **`agint.evolve`**：复盘报告引用 metrics 数据
- **`agint.qualityEvaluator`**（v0.2）：HARM 子维度从这里采集
- **所有插件**：metrics 从它们的 Service 懒读取

## 测试

`test/metrics.test.js`：delta 计算 + series 序列化。

## 文件

```
lib/index.js    Cordis apply()：注册 agint.metrics + 收集器
lib/metrics.js  指标定义 + 懒采集逻辑
lib/tools.js    metrics_* model 工具
test/metrics.test.js
```
