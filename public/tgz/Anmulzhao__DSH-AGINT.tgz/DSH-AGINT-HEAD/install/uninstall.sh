#!/usr/bin/env bash
# AGINT 卸载脚本（v0.2 — 安全左移版）
#
# 移除 install.sh 装入的内容。默认保留 .agint-backups/ 目录，可手动清理。
#
# ## 用法
#   install/uninstall.sh                   # 默认：全量卸载（profile=web）
#   install/uninstall.sh --profile=desktop # 卸载指定 profile 的部署（2026-10-08 新增）
#   install/uninstall.sh --dry-run         # 只打印会改什么
#   install/uninstall.sh --list-backups    # 列所有备份
#   install/uninstall.sh --restore         # 从备份选一个回滚（交互式）
#   install/uninstall.sh --restore=AGINT-PRESETS-20260820-200139  # 指定备份回滚
#   install/uninstall.sh --purge-backups   # 删除所有 .agint-backups/
#
# ## 行为
#   patch 中只删 AGINT 仓库声明的 agint-* id 段；用户在 dsh patch 里手写的
#   非 agint-* 配置原样保留。

set -uo pipefail

# ⛔ 2026-09-29 修坑：与 install.sh 同源。
# 本脚本 3 处 python heredoc 的 print 带 ✓ / ↻ / ⚠；中文 Windows 上 python 的
# stdout 是 GBK，打印非 ASCII 符号抛 UnicodeEncodeError。
# 本脚本更隐蔽的一处：L~194 `ids=$(python3 … <<'PY' | tr -d '\r')` ——
# python 崩溃时退出码被管道末端的 tr 吞掉，ids 静默变空 ⇒ 「无插件可删」假象，
# 卸载看起来成功，实际什么都没删。这里同样以环境变量一次性覆盖所有 python 调用。
export PYTHONIOENCODING=utf-8

# ── 参数 ────────────────────────────────────────────────────────────────────
DRY_RUN=0
LIST_BACKUPS=0
RESTORE=""
PURGE_BACKUPS=0
# 目标 profile 名。2026-10-08 参数化：install.sh 已支持装进 desktop，
# 卸载必须能对称指向同一 profile，否则「装得 clean，卸不干净」。
PROFILE_NAME="${AGINT_PROFILE:-web}"
for arg in "$@"; do
  case "$arg" in
    --dry-run)       DRY_RUN=1 ;;
    --list-backups)  LIST_BACKUPS=1 ;;
    --restore)       RESTORE="interactive" ;;
    --restore=*)     RESTORE="${arg#--restore=}" ;;
    --purge-backups) PURGE_BACKUPS=1 ;;
    --profile=*)     PROFILE_NAME="${arg#--profile=}" ;;
    --profile)
      echo "[AGINT] ✗ --profile 需要值：写 --profile=<名>（例如 --profile=desktop）" >&2
      exit 2
      ;;
    -h|--help)
      sed -n '2,18p' "$0"
      exit 0
      ;;
    *)
      echo "[AGINT] ✗ 未知参数: $arg" >&2
      exit 2
      ;;
  esac
done

# 与 install.sh 同一道闸：profile 名会拼进路径，先挡空串 / 斜杠 / ..
case "$PROFILE_NAME" in
  ''|*/*|*..*|*' '*|*[!A-Za-z0-9._-]*)
    echo "[AGINT] ✗ profile 名非法: '$PROFILE_NAME'（只允许字母数字 . _ -）" >&2
    exit 2
    ;;
esac

AGINT_HOME="${AGINT_HOME:-$(cd "$(dirname "$0")/.." && pwd)}"
DSH_HOME="${DSH_HOME:-$HOME/.dsh}"

if command -v realpath >/dev/null 2>&1; then
  AGINT_HOME="$(realpath "$AGINT_HOME")"
  DSH_HOME="$(realpath -m "$DSH_HOME")"
fi

PRESETS_DST="$DSH_HOME/.agent-presets"
# 目标 profile 根：与 install.sh 的 PROFILE_ROOT 同一规则（2026-10-08 参数化）
PROFILE_ROOT="$DSH_HOME/profiles/$PROFILE_NAME"
PLUGINS_DST="$PROFILE_ROOT/plugins"
PATCH_DST="$PROFILE_ROOT/cordis.patch.yml"
PATCH_SRC="$AGINT_HOME/profile-patches/web/cordis.patch.yml"

# 2026-09-24：bundle 形态（AGINT 的主载体）
BUNDLE_NAME="@agint/host"
BUNDLE_DST="$DSH_HOME/.agint-bundle"
BUNDLE_PLUGINS_DST="$BUNDLE_DST/plugins"
# 2026-10-01 起 bundle 实体在 .agint-bundle/，node_modules 下是它的一条软链
BUNDLE_LINK="$PROFILE_ROOT/node_modules/$BUNDLE_NAME"
PROFILE_MANIFEST="$PROFILE_ROOT/package.json"

BACKUP_DIR="$DSH_HOME/.agint-backups"

log() { echo "[AGINT] $*"; }
warn() { echo "[AGINT] ⚠ $*" >&2; }
die()  { echo "[AGINT] ✗ $*" >&2; exit 1; }

log "AGINT_HOME = $AGINT_HOME"
log "DSH_HOME   = $DSH_HOME"
log "PROFILE    = $PROFILE_NAME（部署位 $PROFILE_ROOT）"
log ""

# ── --list-backups ─────────────────────────────────────────────────────────
if [ "$LIST_BACKUPS" = "1" ]; then
  if [ ! -d "$BACKUP_DIR" ]; then
    log "备份目录不存在: $BACKUP_DIR"
    exit 0
  fi
  log "备份目录: $BACKUP_DIR"
  # 列所有 .tar.gz，按 mtime 倒序，附 size 和 ISO 时间
  find "$BACKUP_DIR" -maxdepth 1 -name 'agint-*.tar.gz' -type f -printf '%T@ %TY-%Tm-%TdT%TH:%TM:%TS %s %p\n' \
    | sort -rn \
    | awk '{ ts=$2; size=$3; path=$4; sub(/.*\//,"",path); printf "  %s  %8d  %s\n", ts, size, path }'
  exit 0
fi

# ── --purge-backups ────────────────────────────────────────────────────────
if [ "$PURGE_BACKUPS" = "1" ]; then
  if [ ! -d "$BACKUP_DIR" ]; then
    log "备份目录不存在: $BACKUP_DIR"
    exit 0
  fi
  count=$(find "$BACKUP_DIR" -maxdepth 1 -name 'agint-*.tar.gz' -type f | wc -l | tr -d ' ')
  if [ "$DRY_RUN" = "1" ]; then
    log "[DRY] 将删除 $count 个备份文件"
    exit 0
  fi
  rm -f "$BACKUP_DIR"/agint-*.tar.gz
  log "✓ 删除 $count 个备份文件"
  exit 0
fi

# ── --restore ──────────────────────────────────────────────────────────────
restore_from_backup() {
  local archive="$1"
  if [ ! -f "$archive" ]; then die "备份不存在: $archive"; fi

  log "从备份恢复: $archive"
  log ""
  # --force-local：Git Bash/MSYS 下 $archive 形如 C:/...，tar 会把「C:」当远程主机
  #   （与 install.sh 备份同坑，2026-09-28 修）。
  tar --force-local -tzf "$archive" | head -5
  log "  ..."

  if [ "$DRY_RUN" = "1" ]; then
    log "[DRY] 备份恢复未执行"
    return
  fi

  # 解到 archive 同级目录（archive 是绝对路径，-C 到其父目录）
  local parent
  parent="$(dirname "$archive")"
  tar --force-local -xzf "$archive" -C "$parent"
  log "✓ 已从 $archive 恢复"
}

if [ -n "$RESTORE" ]; then
  if [ ! -d "$BACKUP_DIR" ]; then die "备份目录不存在: $BACKUP_DIR"; fi
  if [ "$RESTORE" = "interactive" ]; then
    echo ""
    log "可选备份（最新在前）："
    mapfile -t backups < <(find "$BACKUP_DIR" -maxdepth 1 -name 'agint-*.tar.gz' -type f -printf '%T@ %p\n' | sort -rn | awk '{print $2}')
    if [ "${#backups[@]}" -eq 0 ]; then die "无备份可选"; fi
    for i in "${!backups[@]}"; do
      printf "  [%d] %s\n" "$((i+1))" "$(basename "${backups[$i]}")"
    done
    echo ""
    read -rp "[AGINT] 选哪个备份回滚？(1-${#backups[@]}，直接回车取消) " choice
    case "$choice" in
      ""|q|quit) log "已取消"; exit 0 ;;
      *)
        if ! [[ "$choice" =~ ^[0-9]+$ ]] || [ "$choice" -lt 1 ] || [ "$choice" -gt "${#backups[@]}" ]; then
          die "无效选择"
        fi
        restore_from_backup "${backups[$((choice-1))]}"
        ;;
    esac
  else
    # 指定文件名（basename 或绝对路径）
    if [ -f "$RESTORE" ]; then
      restore_from_backup "$RESTORE"
    elif [ -f "$BACKUP_DIR/$RESTORE" ]; then
      restore_from_backup "$BACKUP_DIR/$RESTORE"
    else
      die "找不到备份: $RESTORE（试试 --list-backups）"
    fi
  fi
  exit 0
fi

# ── 默认：全量卸载 ─────────────────────────────────────────────────────────
log "1/3 移除 presets"
# 只卸本仓产出的 agint。三个子 preset（agint-blockchain / agint-investor /
# agint-ops）自 2026-10-26 起由独立仓 agint-presets 铺装，卸载也归它的
# install/uninstall.sh —— 在这里顺手删掉别人的东西，重装框架时就会莫名其妙
# 少三个 preset，而且看不出是谁删的。
for name in agint; do
  dst="$PRESETS_DST/$name"
  if [ -d "$dst" ]; then
    if [ "$DRY_RUN" = "1" ]; then
      log "   ✓ 删除 (dry): $dst"
    else
      rm -rf "$dst"
      log "   ✓ 删除 $dst"
    fi
  else
    log "   ↻ $dst 不存在，跳过"
  fi
done

log ""
log "2/3 移除 plugins"
if [ -f "$PATCH_SRC" ]; then
  # ⚠ Windows 坑：python 在 Windows 上把 print 的 '\n' 翻成 '\r\n'，命令替换
  #   只吃掉结尾 \n ⇒ 每个 id 尾部残留 '\r' ⇒ `[ -d "...agint-x\r" ]` 恒假
  #   ⇒ 卸载脚本"静默跳过所有插件"（症状：全部打印「不存在，跳过」）。
  #   故必须 `| tr -d '\r'`。
  ids=$(python3 - "$PATCH_SRC" <<'PY' | tr -d '\r'
import sys, re
with open(sys.argv[1], encoding='utf-8') as f:
    text = f.read()
for m in re.finditer(r'^    - id: (agint-[a-z0-9-]+)', text, re.M):
    bid = m.group(1)
    if bid == 'agint-quality-contract':
        top = 'agint-quality'
    else:
        top = bid
    print(top)
PY
  )
  for top in $ids; do
    for base in "$PLUGINS_DST" "$BUNDLE_PLUGINS_DST"; do
      dst="$base/$top"
      if [ -d "$dst" ]; then
        if [ "$DRY_RUN" = "1" ]; then
          log "   ✓ 删除 (dry): $dst"
        else
          rm -rf "$dst"
          log "   ✓ 删除 $dst"
        fi
      else
        log "   ↻ $dst 不存在，跳过"
      fi
    done
  done
else
  log "   ↻ 仓库 patch 不存在，跳过 plugin 移除（请手动清理）"
fi

log ""
log "2.5/3 移除 bundle 本体（$BUNDLE_DST）"
if [ -L "$BUNDLE_LINK" ]; then
  if [ "$DRY_RUN" = "1" ]; then
    log "   ✓ 删除软链 (dry): $BUNDLE_LINK"
  else
    rm -f "$BUNDLE_LINK"
    log "   ✓ 删除软链 $BUNDLE_LINK"
  fi
elif [ -d "$BUNDLE_LINK" ]; then
  # 2026-10-01 之前的旧部署位：node_modules 下是一整份实体目录
  if [ "$DRY_RUN" = "1" ]; then
    log "   ✓ 删除旧部署目录 (dry): $BUNDLE_LINK"
  else
    rm -rf "$BUNDLE_LINK"
    log "   ✓ 删除旧部署目录 $BUNDLE_LINK"
  fi
fi
if [ -d "$BUNDLE_DST" ]; then
  # profile.json 是 2026-10-08 加的「安装到哪个 profile」事实文件（install.sh 3.7）。
  # ⛔ 卸载必须删它：留着会让没 ctx 的代码路径（agint-dream 等）继续以为 AGINT 装在
  #    那个 profile 上，而实体已经不在了 —— 一个指向已卸载目标的"事实"，比没有更糟。
  for item in plugins cordis.patch.yml package.json profile.json; do
    if [ -e "$BUNDLE_DST/$item" ]; then
      if [ "$DRY_RUN" = "1" ]; then
        log "   ✓ 删除 (dry): $BUNDLE_DST/$item"
      else
        rm -rf "$BUNDLE_DST/$item"
        log "   ✓ 删除 $BUNDLE_DST/$item"
      fi
    fi
  done
  # ⛔ 绝不 rm -rf 这个 node_modules：里面是 → dsh 安装目录的 junction，
  #    rm -rf 会跟进目标，把 dsh 自己的 266 个包一起删掉。
  #    留着无害：bundles 列表摘掉 @agint/host 后就不会再加载它。
  if [ -d "$BUNDLE_DST/node_modules" ]; then
    log "   ⊘ 保留 $BUNDLE_DST/node_modules（junction，删它会连坐 dsh 自身的包）"
  fi
else
  log "   ↻ $BUNDLE_DST 不存在，跳过"
fi

log ""
log "2.6/3 从 dsh.profile.bundles 摘掉 $BUNDLE_NAME，并清掉 dependencies 条目"
if [ -f "$PROFILE_MANIFEST" ]; then
  if [ "$DRY_RUN" = "1" ]; then
    log "   ✓ 摘除 (dry): $BUNDLE_NAME @ $PROFILE_MANIFEST"
  else
    cp -f "$PROFILE_MANIFEST" "$PROFILE_MANIFEST.bak-agint-uninstall-$(date +%Y%m%d-%H%M%S)"
    python3 - "$(winpath "$PROFILE_MANIFEST")" "$BUNDLE_NAME" <<'PY' || warn "profile 清单改写失败，请手动移除（备份已留）"
import sys, json, io
path, name = sys.argv[1], sys.argv[2]
data = json.loads(io.open(path, encoding='utf-8').read())
changed = []
bundles = (data.get('dsh') or {}).get('profile', {}).get('bundles')
if isinstance(bundles, list) and name in bundles:
    data['dsh']['profile']['bundles'] = [b for b in bundles if b != name]
    changed.append('bundles')
# 2026-10-01 新增的依赖声明：不摘的话 pnpm 会继续认为 bundle 该存在于
# node_modules，下次 install_bundle 又会把它"装"回来。
deps = data.get('dependencies')
if isinstance(deps, dict) and name in deps:
    del deps[name]
    changed.append('dependencies')
if not changed:
    print(f"[AGINT]   ↻ 清单中无 {name}，跳过")
    sys.exit(0)
io.open(path, 'w', encoding='utf-8', newline='\n').write(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
print(f"[AGINT]   ✓ 已摘除 {name}（{', '.join(changed)}）")
PY
  fi
else
  log "   ↻ $PROFILE_MANIFEST 不存在，跳过"
fi

log ""
log "3/3 摘除 patch 中的 agint-* 段"
if [ -f "$PATCH_DST" ]; then
  python3 - "$PATCH_SRC" "$PATCH_DST" "$BACKUP_DIR" "$DRY_RUN" <<'PY'
import sys, re, os, shutil, datetime, tarfile
patch_src, patch_dst, backup_dir, dry_run = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4] == "1"

if not os.path.exists(patch_src):
    print("[AGINT]   ↻ 仓库 patch 不存在，跳过 patch 清理")
    sys.exit(0)

with open(patch_src, encoding='utf-8') as f:
    src_text = f.read()

agint_ids = [m.group(1) for m in re.finditer(r'^    - id: (agint-[a-z0-9-]+)', src_text, re.M)]
if not agint_ids:
    print("[AGINT]   ↻ 仓库 patch 无 agint-* id，跳过")
    sys.exit(0)

with open(patch_dst, encoding='utf-8') as f:
    dst_text = f.read()

# 先备份到中央目录（如果存在）
if not dry_run and not os.path.exists(backup_dir):
    os.makedirs(backup_dir, exist_ok=True)

# 用 [AGINT-removed] 注释掉整段
removed = 0
for bid in agint_ids:
    pat = re.compile(rf'(?ms)^(    - id: {re.escape(bid)}\s*\n(?:      [^\n]*\n)*)')
    new_text, n = pat.subn('# [AGINT-removed] \\1', dst_text)
    if n:
        dst_text = new_text
        removed += n

if removed:
    if dry_run:
        print(f"[DRY]   注释 (dry): {removed} 个 agint-* insert 段（未写文件）")
        sys.exit(0)
    # 备份到中央目录
    ts = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    archive = os.path.join(backup_dir, f"agint-patch-{ts}.tar.gz")
    parent = os.path.dirname(patch_dst)
    base = os.path.basename(patch_dst)
    with tarfile.open(archive, 'w:gz') as tf:
        tf.add(os.path.join(parent, base), arcname=base)
    print(f"[AGINT]   备份: {patch_dst} → {archive}")
    with open(patch_dst, 'w', encoding='utf-8') as f:
        f.write(dst_text)
    print(f"[AGINT]   ✓ 注释了 {removed} 个 agint-* insert 段")
else:
    print("[AGINT]   ↻ dsh patch 中未找到 agint-* 段，无需清理")
PY
fi

log ""
log "✅ 卸载完成"
log "下一步：重启 profile '$PROFILE_NAME' 对应的 dsh 客户端（web: dsh web；desktop: 重开桌面版）"
log ""
log "提示：备份还在 $BACKUP_DIR，用 --list-backups 查看，--restore 回滚"
