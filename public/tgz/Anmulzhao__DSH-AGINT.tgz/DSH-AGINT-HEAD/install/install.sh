#!/usr/bin/env bash
# AGINT 安装脚本（v0.2 — 安全左移版）
#
# 把 AGINT 仓库内容铺到 $DSH_HOME，对应 preset / bundle-plugin / bundle-patch
# 三个注入点（外加一处兼容镜像位）。目标 profile 由 --profile 指定，默认 web。
#
# ## 交付形态（2026-09-24 起）
#   $DSH_HOME/.agent-presets/<id>/                      ← agint preset 的定义文件
#        （三个子 preset agint-blockchain / agint-investor / agint-ops 已于 2026-10-26
#          拆到独立私有仓 agint-presets，本安装器不再产出，也不碰它们）
#   $DSH_HOME/.agent-presets/node_modules               ← preset 裸包名解析入口
#   $DSH_HOME/.agint-deps/dsh-runtime/                  ← AGINT 自带 dsh 运行时（依赖树实体）
#        ├── package.json       name=@deepseek-ai/dsh（验真身用）
#        ├── lib/               dsh CLI + profile-boot
#        └── node_modules/      @deepseek-ai/* 与第三方包（三个解析入口的真实目标）
#   $DSH_HOME/.agint-bundle/                            ← the bundle 的实体（主载体）
#        ├── cordis.patch.yml   挂载行（insert 行 name 相对本目录解析）
#        ├── package.json       dsh.bundle.patch 声明
#        ├── plugins/           agint-* 插件
#        └── node_modules/@deepseek-ai  官方包解析入口
#   $DSH_HOME/profiles/<profile>/node_modules/@agint/host  ← 指向上面那个目录的 symlink
#   $DSH_HOME/profiles/<profile>/plugins/                  ← 兼容镜像位（AGINT 自身代码按此路径找插件）
#   $DSH_HOME/profiles/<profile>/cordis.patch.yml          ← ⛔ 只读：AGINT 不再写它（写了 = 双重挂载）
#
# ⛔ 为什么 bundle 实体不在 node_modules 里（2026-10-01 修，AGINT 自毁坑）：
#   dsh 的 plugin_manager 每次 install_bundle / remove_bundle 都会在 profile 目录
#   跑一次 `pnpm add|remove`，而 pnpm 会**剪掉 package.json 里没声明的包**。
#   AGINT 的 bundle 当初是 rsync 一整份目录到 profiles/web/node_modules/@agint/host/，
#   只在 dsh.profile.bundles 里注册、**没进 dependencies** ⇒ 任何一次插件热插拔
#   （包括 AGINT 自己用 plugin_manager 装东西）都会把整个 bundle 删掉，症状是
#   「AGINT 从 preset 列表里凭空消失、37 个插件全没了、host 一声不吭」。
#   修法：实体挪到 .agint-bundle/，node_modules/@agint/host 改成 symlink，并且把
#   "@agint/host": "link:<实体目录>" 写进 profile 的 dependencies —— pnpm 认账的
#   条目它不剪，dsh 的 createRequire 解析照旧穿过 symlink 找到 package.json。
# 幂等：已存在则备份 + 同步，不破坏用户已有内容（非 agint-* 段原样保留）。
#
# ## 安全设计（§5.2 安全左移 + docs/security-boundary.md）
#   1. 前置：跑 install/agint-security-checks.sh，任意 fail → 退出
#   2. 复制：优先 rsync（--no-links + exclude 列表），无 rsync 时回退 python3
#      copytree，两者都禁止跟随 symlink（AGINT 仓内 node_modules 全是
#      symlink，会污染 $DSH_HOME 树）。实现见 safe_rsync()
#   3. 备份：中央目录 $DSH_HOME/.agint-backups/，保留最近 10 个，超限删最老
#   4. 回滚：trap EXIT 跟踪 partial install 状态；失败时还原
#   5. 装后：静态校验（YAML 解析 / package.json 存在 / preset cordis.yml 存在）
#
# ## 参数
#   --profile=<名>  目标 dsh profile 名（默认 web）。装到 desktop 就写 --profile=desktop。
#                   目标目录必须是 $DSH_HOME/profiles/<名>/ 且已有 package.json。
#                   作用范围（2026-10-08 补全，缺任何一项都会「装完零报错但能力不全」）：
#                     · 4 处部署路径（profile 根下的 bundle 链 / 清单 / 插件镜像 / patch）
#                     · 传给 agint-zod-bootstrap.sh 的 MIRROR 位
#                     · 1.3  preset 工具行锚定 bundle 主挂载源 + 逐条核验（agint 单套）
#                            ① 不随 profile 变 —— 一份 preset 文件服务所有 profile，
#                              按 profile 改写会让先装的端工具全指空且零报错
#                     · 2.6  部署位 manifest.json 的 read:profiles/<名>/plugins 权限声明重写
#                     · 3.7  安装事实文件 $DSH_HOME/.agint-bundle/profile.json
#   --dry-run  只打印会改什么，不写任何文件
#   --force    跳过 AGINT_HOME 是否为 git 仓的检查（用于 CI）
#   --no-check 跳过 agint-security-checks.sh 前置检查（仅 dev 用）
#   -h|--help  帮助
#
# ## 备份与回滚
#   备份目录：$DSH_HOME/.agint-backups/agint-{presets,plugins,patch}-TS.tar.gz
#   uninstall.sh 支持从备份列表选一个回滚
#
# ## 已知限制
#   - bundle patch 是**整份复制**（不再与 profile 级 patch 做段合并）；
#     python3 仍用于：残留段检测 + 装后 YAML 语法校验
#   - 无 rsync 环境（Windows）走 python3 回退：--delete 语义靠 stage+换入实现，
#     换入前 dst 的旧内容仍在盘上，异常中断时可从 $DSH_HOME/.agint-backups 恢复

set -uo pipefail  # 注意：不加 -e，因为我们要收集失败后 trap 回滚

# ⛔ 2026-09-29 修坑：python3 子进程 stdout 强制 UTF-8。
# 本脚本 4 处 python heredoc 的 print 里带 ✓ / ✗ / ↻ / ⚠ 等符号；中文 Windows 上
# python 的 stdout 编码是 GBK，打印 U+2713 直接抛 UnicodeEncodeError
# （'gbk' codec can't encode character '\u2713'），**非零退出**。
# 致命之处在于它伪装成业务故障：install.sh:560 的残留检测本来 hits=0（干净），
# 却在紧随其后的 print("✓ …") 上崩掉 → `|| die` 触发 → 报「profile 级 patch 仍含
# AGINT 挂载段」，把人引向完全错误的修复方向（去删本来正确的 profile patch）。
# 同一坑在 uninstall.sh 也中招：python 输出喂给 shell 变量时崩溃，会被管道吞掉
# 退出码，导致「静默跳过全部插件删除」。
# 这里用环境变量而非 sys.stdout.reconfigure()：不依赖 Python 版本，且对
# `-c` 单行调用与 heredoc 块一视同仁。
export PYTHONIOENCODING=utf-8

# ── 参数 ────────────────────────────────────────────────────────────────────
DRY_RUN=0
FORCE=0
SKIP_CHECK=0
# 目标 dsh profile 名。2026-10-08 参数化（原写死 web）：老板要把 AGINT 装进
# desktop profile —— 会话实际跑在哪个 profile，bundle 就得注册在哪个 profile，
# 否则「装完零报错但智进不可见」。
PROFILE_NAME="${AGINT_PROFILE:-web}"
for arg in "$@"; do
  case "$arg" in
    --dry-run)      DRY_RUN=1 ;;
    --force)        FORCE=1 ;;
    --no-check)     SKIP_CHECK=1 ;;
    --profile=*)    PROFILE_NAME="${arg#--profile=}" ;;
    --profile)
      echo "[AGINT] ✗ --profile 需要值：写 --profile=<名>（例如 --profile=desktop）" >&2
      exit 2
      ;;
    -h|--help)
      sed -n '2,66p' "$0"
      exit 0
      ;;
    *)
      echo "[AGINT] ✗ 未知参数: $arg" >&2
      exit 2
      ;;
  esac
done

# profile 名只允许 [A-Za-z0-9._-]：它会拼进路径，必须在任何路径拼接之前挡住
# 空串 / `/` / `..`，否则 --profile=../../x 能写到 $DSH_HOME 树外。
case "$PROFILE_NAME" in
  ''|*/*|*..*|*' '*)
    echo "[AGINT] ✗ profile 名非法: '$PROFILE_NAME'（只允许字母数字 . _ -）" >&2
    exit 2
    ;;
  *[!A-Za-z0-9._-]*)
    echo "[AGINT] ✗ profile 名非法: '$PROFILE_NAME'（只允许字母数字 . _ -）" >&2
    exit 2
    ;;
esac

# ── 路径 ────────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AGINT_HOME="${AGINT_HOME:-$(cd "$SCRIPT_DIR/.." && pwd)}"
DSH_HOME="${DSH_HOME:-$HOME/.dsh}"

# realpath 校验一次（防 symlink 逃逸）
if command -v realpath >/dev/null 2>&1; then
  AGINT_HOME="$(realpath "$AGINT_HOME")"
  DSH_HOME="$(realpath -m "$DSH_HOME")"
fi

# 拒绝路径含 ..
for v in AGINT_HOME DSH_HOME; do
  case "${!v}" in
    *..*)
      echo "[AGINT] ✗ $v 含 '..'：${!v}（拒绝以防路径遍历）" >&2
      exit 1
      ;;
  esac
done

# ── MSYS → Windows 路径转换 ──────────────────────────────────────────────────
# Git Bash 下 $AGINT_HOME 形如 /d/DSH/project/DSH-AGINT（MSYS 路径）。
# 这个路径 bash 内部能用，但传给 **Windows 原生** 解释器（本机的 python3.exe）
# 会被当成不存在的相对路径——典型症状是 python 报 FileNotFoundError，
# 而同一个文件 ls 明明存在。node 也是同理（见 2026-09-03 笔记）。
#
# 不做平台硬编码猜测，直接拿 SCRIPT_DIR 探一次：python 认得就用原样，
# 认不得就判定为「需要 Windows 路径」，后续统一过 cygpath -w。
PYTHON_NEEDS_WINPATH=0
if command -v cygpath >/dev/null 2>&1 && command -v python3 >/dev/null 2>&1; then
  if ! python3 -c 'import os,sys; sys.exit(0 if os.path.isdir(sys.argv[1]) else 1)' \
      "$SCRIPT_DIR" 2>/dev/null; then
    PYTHON_NEEDS_WINPATH=1
  fi
fi

# winpath <path> → 按探测结果决定是否转成 Windows 形式
#
# 用 `cygpath -m`（输出 C:/Users/... 正斜杠）而不是 `-w`（输出 C:\Users\...）。
# 区别很要命：-w 的反斜杠一旦被嵌进 Python 字符串字面量，`\U` / `\x` 就会被
# 当成 Unicode / 十六进制转义，路径当场变形（Windows 上 \Users 是必踩的）。
# -m 的正斜杠在 argv 和字符串字面量里都安全，Windows 版 python/node 都认。
winpath() {
  if [ "$PYTHON_NEEDS_WINPATH" = "1" ] && command -v cygpath >/dev/null 2>&1; then
    cygpath -m "$1" 2>/dev/null || printf '%s' "$1"
  else
    printf '%s' "$1"
  fi
}

PRESETS_SRC="$AGINT_HOME/presets"
PLUGINS_SRC="$AGINT_HOME/plugins"

# ── 2026-09-24：AGINT 改以 dsh **bundle** 形态交付 ──────────────────────────
# 挂载层 = 仓库根 cordis.patch.yml（package.json 里 dsh.bundle.patch 指向它）
# 插件   = 仓库根 plugins/
# 部署位 = $DSH_HOME/.agint-bundle/（实体）+ profiles/<PROFILE_NAME>/node_modules/@agint/host
#         （symlink，且必须在 profile 的 dependencies 里声明，见文件头）
# profile-patches/web/cordis.patch.yml 已**不再写入** profile 级 patch，
# 仅保留为「卸载时的 id 清单源」（uninstall.sh 依赖它）。
BUNDLE_PATCH_SRC="$AGINT_HOME/cordis.patch.yml"
BUNDLE_MANIFEST_SRC="$AGINT_HOME/package.json"
PATCH_SRC="$AGINT_HOME/profile-patches/web/cordis.patch.yml"

# 目标 profile 根。bundle 实体（$DSH_HOME/.agint-bundle）与 profile 无关；
# 只有 4 条路径跟着 profile 名走。
PROFILE_ROOT="$DSH_HOME/profiles/$PROFILE_NAME"

BUNDLE_NAME="@agint/host"
BUNDLE_DST="$DSH_HOME/.agint-bundle"
BUNDLE_PLUGINS_DST="$BUNDLE_DST/plugins"
BUNDLE_PATCH_DST="$BUNDLE_DST/cordis.patch.yml"
BUNDLE_MANIFEST_DST="$BUNDLE_DST/package.json"
# dsh 解析 bundle 只认这一个位置（app-boot resolveBundleDir → profile 目录下的
# node_modules/<name>）；实体放别处时，这里必须是指过去的 symlink。
BUNDLE_LINK="$PROFILE_ROOT/node_modules/$BUNDLE_NAME"

# profile 清单：dsh.profile.bundles 的注册位。
# ⛔ 不注册 = bundle 目录与 patch 都在，但 dsh 根本不加载它，**零报错**（见步骤 3.5）
PROFILE_MANIFEST="$PROFILE_ROOT/package.json"

PRESETS_DST="$DSH_HOME/.agent-presets"
# 兼容位（与 bundle 同源、同一次 sync）：AGINT 自身代码（agint-dream/lib/
# quality-bridge.js）与 preset 的 tools 行按 <此路径>/<plugin-id> 定位插件。
# 2026-10-26：子 preset 拆到 agint-presets 独立仓，它们的 tools 行仍指向这里。
PLUGINS_DST="$PROFILE_ROOT/plugins"
# 只读：用于「AGINT 挂载段残留」检测，不再由本脚本写入
PROFILE_PATCH_DST="$PROFILE_ROOT/cordis.patch.yml"

# 目标 profile 必须已被 dsh 初始化过。否则 3.5 步只能 warn 后跳过，
# 而「bundle 没进 dsh.profile.bundles」的表现正是「装完像没装、零报错」——
# 在这里挡掉比让老板装完才发现好。
if [ ! -f "$PROFILE_MANIFEST" ]; then
  echo "[AGINT] ✗ 目标 profile 不存在或未初始化：$PROFILE_ROOT" >&2
  echo "[AGINT]   期望文件：$PROFILE_MANIFEST" >&2
  echo "[AGINT]   先让 dsh 用 --profile $PROFILE_NAME 启动一次（生成 profile），或用 --profile=<已存在的profile>" >&2
  echo "[AGINT]   现有 profile：" >&2
  ls -1 "$DSH_HOME/profiles" 2>/dev/null | sed 's/^/[AGINT]     /' >&2
  exit 1
fi

BACKUP_DIR="$DSH_HOME/.agint-backups"
BACKUP_KEEP=10

# ── 日志 ────────────────────────────────────────────────────────────────────
log() {
  if [ "$DRY_RUN" = "1" ]; then
    echo "[DRY]   $*"
  else
    echo "[AGINT] $*"
  fi
}
warn() { echo "[AGINT] ⚠ $*" >&2; }
die()  { echo "[AGINT] ✗ $*" >&2; exit 1; }

# ── 定位本机的 @deepseek-ai/dsh 安装目录 ───────────────────────────────────
#
# ⛔ 2026-10-07 修：`npm root -g` 单入口定位在 nvm 机器上必然失效。
#   症状：install 跑到 mirror 解析卫兵时打「未能定位 dsh 自带官方包」并
#   **静默跳过**——本批刚加的 1.45 卫兵（防 dsh-tools stub 事故复发）
#   在这类机器上等于没上线，防线是空的。
#   根因：`npm root -g` 跟着 PATH 里的**第一个** npm 走。本机 PATH 优先是
#   WorkBuddy 自带 npm ⇒ 它答 `/opt/apps/workbuddy/resources/runtime/...`，
#   那里没有 dsh；而 dsh 实际在 nvm 前缀下。**问错了 npm，不是 dsh 没装。**
#
# 解法：候选化 + 逐个验明真身（读 package.json 且 name 匹配），
#   并把「dsh 可执行文件反推」放在 npm 之前——正在跑的那个 dsh 最可信。
#   对齐 bin/check-dsh-compat.mjs 的 dshRootCandidates()，避免两处各猜一套。
locate_dsh_dir() {
  local c resolved

  # ① 环境变量显式指定（最高优先，与 check-dsh-compat 一致）
  #    ⚠️ 显式指定**同样要验真身**（对齐 check-dsh-compat 的 findDshRoot，
  #    它对 DSH_ROOT 也会核对 pkg.name）。否则用户指错目录时会得到一个
  #    「存在但根本不是 dsh」的路径，后续三处入口全建到错误目标上，
  #    症状比定位失败更隐蔽（失败有 warn，错指则静默建错链）。
  if [ -n "${DSH_ROOT:-}" ] && [ -f "$DSH_ROOT/package.json" ] \
     && grep -q '"@deepseek-ai/dsh"' "$DSH_ROOT/package.json" 2>/dev/null; then
    printf '%s' "$DSH_ROOT"; return 0
  fi

  # ② 从 dsh 可执行文件反推：<prefix>/bin/dsh → <prefix>/lib/node_modules/@deepseek-ai/dsh
  #    取 PATH 里所有 dsh，第一个能验明真身的即采用（认的是「在跑的那个」）
  local dsh_bin
  dsh_bin="$(command -v dsh 2>/dev/null || true)"
  if [ -z "$dsh_bin" ]; then
    # dsh 不在 PATH 时兜底扫 nvm 各版本目录（.nvm/versions/node/*/bin/dsh）
    local nb
    for nb in "$HOME"/.nvm/versions/node/*/bin/dsh; do
      [ -x "$nb" ] && { dsh_bin="$nb"; break; }
    done
  fi
  if [ -n "$dsh_bin" ]; then
    # ⚠️ 不要对 shim 直接 readlink -f：npm 的 bin/dsh 是软链，解析后落到
    #   <pkg>/lib/bin.js（真实 js 入口），比 npm 布局深两层，反推会算错。
    #   故按 npm 固定布局 <prefix>/bin → <prefix>/lib/node_modules 走，
    #   再拿 readlink -f 的结果补一次（应对非 npm 布局的手工软链）。
    local prefix resolved
    prefix="$(cd "$(dirname "$dsh_bin")/.." 2>/dev/null && pwd)"
    for resolved in "$prefix/lib/node_modules/@deepseek-ai/dsh" \
                   "$(cd "$(dirname "$(readlink -f "$dsh_bin" 2>/dev/null || printf '%s' "$dsh_bin")")/../.." 2>/dev/null && pwd)/lib/node_modules/@deepseek-ai/dsh"; do
      if [ -f "$resolved/package.json" ] \
         && grep -q '"@deepseek-ai/dsh"' "$resolved/package.json" 2>/dev/null; then
        printf '%s' "$resolved"; return 0
      fi
    done
  fi

  # ③ AGINT 自带 dsh 运行时（2026-10-08 新增，§2「解析根缺失」的解法）
  #    $DSH_HOME/.agint-deps/dsh-runtime 由运维一次性铺好，版本锁死，随 $DSH_HOME 走。
  #
  #    ⛔ 为什么必须排在 `npm root -g` 之前：npm root -g 跟随 PATH 里的**首个** npm，
  #    而本机 PATH 首个 npm 是托管那份（前缀在沙箱），答出来的目录里根本没有 dsh
  #    —— 2026-10-08 实测，正是它造成「解析根缺失 + 零报错」的静默降级。
  #    自带这份不受 PATH / npm 前缀 / 全局环境任何影响，是桌面端唯一稳定的解析根。
  #
  #    ⛔ 为什么不能反过来依赖「本机全局装过 dsh」：2026-10-08 卸载全局 dsh 后
  #    留下 697 MB 残留并把三个 junction 变成悬空链接，故障当场复发。自带即免疫。
  for c in "$DSH_HOME/.agint-deps/dsh-runtime"; do
    if [ -f "$c/package.json" ] && grep -q '"@deepseek-ai/dsh"' "$c/package.json" 2>/dev/null; then
      printf '%s' "$c"; return 0
    fi
  done

  # ④ npm root -g（跟随 PATH 首个 npm，可能答错，故放最后兜底）
  for c in "$(npm root -g 2>/dev/null)/@deepseek-ai/dsh"; do
    if [ -f "$c/package.json" ] && grep -q '"@deepseek-ai/dsh"' "$c/package.json" 2>/dev/null; then
      printf '%s' "$c"; return 0
    fi
  done

  # ⑤ 常见硬编码前缀
  for c in "/usr/local/lib/node_modules/@deepseek-ai/dsh" \
           "/usr/lib/node_modules/@deepseek-ai/dsh" \
           "$AGINT_HOME/node_modules/@deepseek-ai/dsh"; do
    if [ -f "$c/package.json" ] && grep -q '"@deepseek-ai/dsh"' "$c/package.json" 2>/dev/null; then
      printf '%s' "$c"; return 0
    fi
  done

  return 1
}

log "AGINT_HOME = $AGINT_HOME"
log "DSH_HOME   = $DSH_HOME"
log "PROFILE    = $PROFILE_NAME（部署位 $PROFILE_ROOT）"
log ""

# ── 前置安全检查 ────────────────────────────────────────────────────────────
if [ "$SKIP_CHECK" != "1" ]; then
  log "0/4 运行安全检查（install/agint-security-checks.sh）"
  if ! AGINT_HOME="$AGINT_HOME" DSH_HOME="$DSH_HOME" bash "$SCRIPT_DIR/agint-security-checks.sh"; then
    die "安全检查失败，加 --no-check 跳过（仅 dev 用）"
  fi
  log ""
fi

# ── 前置业务检查 ────────────────────────────────────────────────────────────
[ -d "$PRESETS_SRC" ] || die "presets 源缺失: $PRESETS_SRC"
[ -d "$PLUGINS_SRC" ] || die "plugins 源缺失: $PLUGINS_SRC"
[ -f "$BUNDLE_PATCH_SRC" ]    || die "bundle patch 源缺失: $BUNDLE_PATCH_SRC"
[ -f "$BUNDLE_MANIFEST_SRC" ] || die "bundle 清单源缺失: $BUNDLE_MANIFEST_SRC"
[ -f "$PATCH_SRC" ]   || die "patch 源缺失（卸载 id 清单仍依赖它）: $PATCH_SRC"
[ -d "$DSH_HOME" ]    || die "$DSH_HOME 不存在，请先初始化 dsh（web 跑一次 'dsh web'；desktop 启动一次桌面版）"

if [ "$FORCE" != "1" ] && [ ! -d "$AGINT_HOME/.git" ]; then
  die "AGINT_HOME 不是 git 仓库（$AGINT_HOME），加 --force 跳过"
fi

# rsync 不再是硬依赖：macOS/Linux 有则优先用（增量快），
# Windows / 精简容器没有 rsync 时回退到 python3 同步（见 safe_rsync 的 fallback 分支）。
command -v python3 >/dev/null 2>&1 || die "需要 python3（patch 合并 + 无 rsync 时的文件同步用）"

# ── partial-install 跟踪 + EXIT trap ────────────────────────────────────────
# 任何 step 标 "done=1" 后失败，trap 会按顺序 reverse 回滚。
PARTIAL_STEPS=()  # 每个元素："<reverse_action>|<args>"
register_step() {
  # register_step "<reverse_action>|<args...>"
  PARTIAL_STEPS+=("$1")
}

rollback() {
  local rc=$?
  # ⛔ rc=0 = **正常跑完**，不是失败。`trap rollback EXIT` 在成功退出时同样触发 ——
  #    少了这一句守卫，安装成功的那一次会把刚铺好的 presets / plugins 全部删掉
  #    （2026-09-24 最小复现：脚本 rc=0 退出，却打印「安装失败，开始回滚 (rc=0)」并删目录）。
  if [ "$rc" -eq 0 ] || [ "${#PARTIAL_STEPS[@]}" -eq 0 ] || [ "$DRY_RUN" = "1" ]; then
    return
  fi
  warn "安装失败，开始回滚 (rc=$rc)..."
  # reverse 顺序执行回滚
  for ((i=${#PARTIAL_STEPS[@]}-1; i>=0; i--)); do
    local step="${PARTIAL_STEPS[$i]}"
    IFS='|' read -r action args <<< "$step"
    case "$action" in
      rm_dst)
        if [ -e "$args" ]; then rm -rf "$args" && warn "  ✓ 已删除: $args"; fi
        ;;
      restore_backup)
        if [ -e "$args.bak-current" ]; then
          rm -rf "$args" && mv "$args.bak-current" "$args" && warn "  ✓ 已恢复: $args"
        fi
        ;;
    esac
  done
}
trap rollback EXIT

# ── 成功收尾：清回滚标记 ────────────────────────────────────────────────────
# 安装正常跑完时调用：把 backup() 留下的 `<file>.bak-current` 清掉（否则安装位里
# 会残留一份旧内容副本），并清空回滚栈 —— rollback 另有 rc=0 守卫，这里是双保险。
commit_install() {
  [ "${#PARTIAL_STEPS[@]}" -gt 0 ] || return 0
  local step action target
  for step in "${PARTIAL_STEPS[@]}"; do
    IFS='|' read -r action target <<< "$step"
    if [ "$action" = "restore_backup" ] && [ -e "$target.bak-current" ]; then
      rm -f "$target.bak-current" && log "   清理回滚标记: $target.bak-current"
    fi
  done
  PARTIAL_STEPS=()
}

# ── 备份函数：中央备份目录 + 数量上限 ────────────────────────────────────────
ensure_backup_dir() {
  if [ "$DRY_RUN" = "1" ]; then
    log "   备份目录 (dry): $BACKUP_DIR"
    return
  fi
  mkdir -p "$BACKUP_DIR"
}

backup() {
  # backup <component-name> <target-path>
  # - 在 $BACKUP_DIR 建 tar.gz（含 target 当时完整快照）
  # - 注册回滚步骤：rm_dst 删掉新装的，回滚到 tar 内容
  local component="$1"
  local target="$2"
  if [ ! -e "$target" ]; then
    log "   备份跳过: $target 不存在（首次安装）"
    return
  fi
  local ts
  ts="$(date +%Y%m%d-%H%M%S)"
  local archive="$BACKUP_DIR/agint-${component}-${ts}.tar.gz"
  if [ "$DRY_RUN" = "1" ]; then
    log "   备份 (dry): $target → $archive"
    return
  fi
  # 把 target 父目录 + basename 一起打包，便于精确还原路径
  local parent
  parent="$(dirname "$target")"
  local base
  base="$(basename "$target")"
  # --force-local：Git Bash/MSYS 下 $archive 形如 C:/Users/...，GNU tar 会把
  #   「C:」误判为远程主机（报 "Cannot connect to C: resolve failed"）——
  #   该选项强制含冒号路径按本地文件处理；Linux 上无副作用（2026-09-28 实测坑）。
  (cd "$parent" && tar --force-local -czf "$archive" "$base") || die "备份失败: $target → $archive"
  log "   备份: $target → $archive"

  # 回滚标记：rollback 的 restore_backup 分支就是靠 `<target>.bak-current` 还原的
  # （tar 只作历史留档 / 人工恢复，路径带时间戳，回滚逻辑不解析它）。
  # ⚠️ 只对**文件**建标记：目录类（presets/<id>）的还原语义是 rm_dst「删掉新装的」，
  #    原内容在 tar 里；安装成功后由 commit_install 清掉这些标记。
  if [ -f "$target" ]; then
    cp -f "$target" "$target.bak-current" || die "写回滚标记失败: $target.bak-current"
  fi

  # 注册回滚：从 target 删除 + 把 archive 解到原位
  register_step "restore_backup|$target"

  # 数量上限：保留最近 BACKUP_KEEP 个对应 component 备份，超限删最老
  prune_old_backups "$component"
}

prune_old_backups() {
  # prune_old_backups <component>
  local component="$1"
  if [ "$DRY_RUN" = "1" ]; then return; fi
  # 列所有匹配 component 的备份，按 mtime 倒序，删超出 KEEP 的
  local files=()
  while IFS= read -r f; do
    [ -n "$f" ] && files+=("$f")
  done < <(find "$BACKUP_DIR" -maxdepth 1 -name "agint-${component}-*.tar.gz" -type f -printf '%T@ %p\n' 2>/dev/null | sort -rn | awk '{print $2}')
  local n="${#files[@]}"
  if [ "$n" -gt "$BACKUP_KEEP" ]; then
    for ((i=BACKUP_KEEP; i<n; i++)); do
      rm -f "${files[$i]}" && log "   旧备份清理: ${files[$i]}"
    done
  fi
}

# ── 复制函数：rsync + --no-links + exclude ──────────────────────────────────
safe_rsync() {
  # safe_rsync <src_dir> <dst_dir>
  #
  # 语义等价于 `rsync -a --no-links --delete`：
  #   - -a        ：保留权限/时间戳（两个后端都保留 mtime+mode）
  #   - --no-links：软链整个跳过，不复制也不跟随
  #                 （AGINT 仓内 node_modules 全是软链，跟过去会污染 $DSH_HOME 树）
  #   - --delete  ：dst 完全镜像 src（src 里没有的，dst 里删掉）
  #
  # 后端选择：
  #   1) rsync 存在 → 用 rsync（macOS 自带 / Linux 常见，增量快）
  #   2) 否则       → python3 shutil.copytree（Windows 兜底）
  #      --delete 语义用「先 stage 到 dst.tmp，整体成功后换入」实现，
  #      比逐项 diff 更可靠，也顺带保证了换入的原子性。
  if [ "$DRY_RUN" = "1" ]; then
    log "   sync (dry): $1/ → $2/"
    return
  fi
  if command -v rsync >/dev/null 2>&1; then
    # ⚠️ 排除表有**两个副本**：这里的 --exclude 与下方 python heredoc 里的
    #    EXCLUDE_NAMES / EXCLUDE_GLOBS 必须语义等价——改这里必须同步改那边
    #    （python 侧 ignore() 递归生效，等价于 rsync 不带锚定的目录名模式）。
    rsync -a --no-links --delete \
      --exclude='.git/' \
      --exclude='.git' \
      --exclude='node_modules/' \
      --exclude='node_modules' \
      --exclude='eval/node_modules/' \
      --exclude='*.bak-*' \
      --exclude='*.bundle' \
      "$1/" "$2/" \
      || die "rsync 失败: $1 → $2"
  else
    python3 - "$(winpath "$1")" "$(winpath "$2")" <<'PY' || die "python 同步失败: $1 → $2"
import os, sys, shutil, fnmatch, time

src, dst = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])

# 与上面 rsync 分支的 --exclude 列表保持一致（排除表有两个副本，改这里必须同步改 rsync 那份）
EXCLUDE_NAMES  = {'.git', 'node_modules'}
EXCLUDE_GLOBS  = ('*.bundle', '*.bak-*')

# 2026-10-08：受限环境（例如带「批量删除护栏」的托管 shell，一次删 >50 个文件
# 就整条命令失败）下用 AGINT_RSYNC_NO_DELETE=1 强制零删除。
# ⛔ 为什么不能只靠下面的 except PermissionError：那类护栏**不是** Python 异常，
#   它在进程外层直接让命令失败，rmtree 根本没机会抛出可被捕获的 PermissionError。
#   故必须在「要不要删」这一步之前就决定。
# 代价：--delete 语义丢失，dst 内 src 已删除的文件会残留。
# 取舍与 rmtree 失败时一致 —— 「装不动」比「残留旧文件」更糟。
NO_DELETE = os.environ.get('AGINT_RSYNC_NO_DELETE') == '1'

def ignore(path, names):
    drop = set()
    for n in names:
        if n in EXCLUDE_NAMES:                                  drop.add(n)
        elif any(fnmatch.fnmatch(n, g) for g in EXCLUDE_GLOBS):  drop.add(n)
        # --no-links：软链整个跳过（目录软链尤其危险，会整棵跟过去）
        elif os.path.islink(os.path.join(path, n)):              drop.add(n)
    return drop

tmp = dst + '.tmp'
if os.path.exists(tmp):
    if NO_DELETE:
        # 不删旧 stage：换个名字避开，让它自然过期（同样是为了零删除）
        tmp = dst + '.tmp-' + time.strftime('%Y%m%d-%H%M%S')
    else:
        shutil.rmtree(tmp)
os.makedirs(tmp, exist_ok=True)  # 同 rsync 分支：中间层缺失时 os.makedirs 负责补
shutil.copytree(src, tmp, ignore=ignore, dirs_exist_ok=True)

# 兜底清扫：copytree 的 ignore 已挡掉绝大多数软链，这里再扫一遍确保零残留
for root, dirnames, filenames in os.walk(tmp):
    for n in list(dirnames) + filenames:
        p = os.path.join(root, n)
        if os.path.islink(p):
            os.unlink(p)

# --delete 语义：stage 成功后整体换入。
# ⚠ dsh 运行时 chokidar 会锁 dst，rmtree 必 PermissionError(WinError 5)。
#   捕获后退化为「覆盖式同步」：只把 tmp 的文件写进 dst（dirs_exist_ok=True），
#   不删目录、不清旧实体。代价是 dst 内 src 已删除的文件会残留（--delete 语义丢失）——
#   这是「装不动」与「残留旧文件」之间的取舍，优先保证安装能完成。
mode = 'replace'
if os.path.exists(dst):
    if NO_DELETE:
        mode = 'overwrite'
        sys.stderr.write(f"WARN safe_rsync: AGINT_RSYNC_NO_DELETE=1，跳过删除，覆盖式同步（旧文件会残留）: {dst}\n")
    else:
        try:
            shutil.rmtree(dst)
        except PermissionError as e:
            mode = 'overwrite'
            sys.stderr.write(f"WARN safe_rsync: dst 被占用（{e.__class__.__name__}），退化覆盖式同步（不删旧文件）: {dst}\n")

if mode == 'replace':
    # ⚠ Windows 上 os.rename 会偶发 PermissionError(WinError 5)：dst 刚被 rmtree 删掉，
    #   杀软 / Windows 索引器会在这一瞬间重新持有它的句柄。
    #   2026-10-08 实测咬过两次；此处一旦抛出，整个安装 die 并回滚（前面所有步骤白做）。
    #   故先重试 6 次（共约 3 秒），仍失败则退化覆盖式同步 —— 与 rmtree 失败同一档降级，
    #   优先保证安装能完成（代价：--delete 语义丢失，dst 内 src 已删的文件会残留）。
    renamed = False
    last_err = None
    for _ in range(6):
        try:
            os.rename(tmp, dst)
            renamed = True
            break
        except PermissionError as e:
            last_err = e
            time.sleep(0.5)
    if not renamed:
        sys.stderr.write(
            f"WARN safe_rsync: rename 被占用（重试 6 次仍 {last_err.__class__.__name__}），"
            f"退化覆盖式同步（不删旧文件）: {dst}\n")
        mode = 'overwrite'

if mode == 'overwrite':
    shutil.copytree(tmp, dst, ignore=ignore, dirs_exist_ok=True)
    # 覆盖式同样要挡软链：再扫一遍 dst，清掉跟进来的符号链接
    for root, dirnames, filenames in os.walk(dst):
        for n in list(dirnames) + filenames:
            p = os.path.join(root, n)
            if os.path.islink(p):
                try:
                    os.unlink(p)
                except OSError:
                    pass
    if NO_DELETE:
        pass  # 零删除模式：保留 stage 目录，避免触发批量删除护栏（会自然过期）
    else:
        try:
            shutil.rmtree(tmp)
        except OSError:
            pass
PY
  fi
}

# ── manifest 比较：忽略 profile 名差异 ──────────────────────────────────────
#
# 用法：manifest_same_modulo_profile <仓库 manifest> <部署位 manifest> → 退出 0 = 实质一致
#
# 为什么不能直接 cmp（2026-10-08）：仓库模板写 `profiles/web/plugins`（默认 profile），
# 步骤 2.6 会把部署位改写成 `profiles/$PROFILE_NAME/plugins`。逐字节比 ⇒ 装到任何
# 非 web profile 时本项恒红，把「正常参数化」误报成「旧版残留/漂移」。
# 归一化只吃掉 profile 名这一段，其余任何差异（版本 / 权限 / 字段增删）照样判红 ——
# 这是**修正比较口径**，不是放宽校验。
manifest_same_modulo_profile() {
  python3 - "$(winpath "$1")" "$(winpath "$2")" <<'PY'
import re, sys

PAT = re.compile(r'(profiles/)[A-Za-z0-9._-]+(/plugins)')


def norm(path):
    try:
        text = open(path, encoding='utf-8').read()
    except OSError as e:
        print(f'[AGINT]   ! manifest 读不动（{e}）：{path}')
        return None
    return PAT.sub(lambda m: m.group(1) + '<PROFILE>' + m.group(2), text)


a, b = norm(sys.argv[1]), norm(sys.argv[2])
if a is None or b is None:
    sys.exit(1)
if a != b:
    print('[AGINT]   ! manifest 在 profile 段之外存在差异')
    sys.exit(1)
sys.exit(0)
PY
}

# ── 0.4 dsh 运行检测（信息性，不阻断）─────────────────────────────────────────
# dsh 在跑时 chokidar 会锁插件目录文件，令 rmtree 失败。真正的安全网是 safe_rsync
# 的覆盖式退化分支（见上）；本检测只负责「能认出来就提前提醒一声」，认不出也不误报。
# pgrep 在 Windows Git Bash 常缺失，缺失即静默跳过——不假装检测过。
detect_dsh_running() {
  command -v pgrep >/dev/null 2>&1 || return 0
  if pgrep -x dsh >/dev/null 2>&1 || pgrep -if 'dsh-app-boot|dsh/bin/dsh' >/dev/null 2>&1; then
    warn "检测到 dsh 进程疑似在运行。"
    warn "  建议先停 dsh 再装以避免文件锁；不停也行 —— safe_rsync 会自动退化为覆盖式同步。"
  fi
  return 0
}
detect_dsh_running

# ── 0.5 确保中央备份目录存在 ─────────────────────────────────────────────────
# backup() 里 tar -czf 打开的是 $BACKUP_DIR 下的文件，目录不存在会直接
# "Cannot open: No such file or directory"。首次安装时它还没建，必须先建出来。
ensure_backup_dir

# ── 1. 安装 presets ─────────────────────────────────────────────────────────
log "1/4 同步 presets → $PRESETS_DST"
mkdir -p "$PRESETS_DST"
for src in "$PRESETS_SRC"/*/; do
  [ -d "$src" ] || continue
  name="$(basename "$src")"
  dst="$PRESETS_DST/$name"
  backup "presets" "$dst"
  safe_rsync "$src" "$dst"
  if [ "$DRY_RUN" != "1" ]; then register_step "rm_dst|$dst"; fi
  log "   ✓ $name"
done

# ── 1.3 preset 工具行锚定 bundle 主挂载源并逐条核验 ─────────────────────────
#
# ⛔ 为什么必须有这一步（2026-10-08，装 desktop 的硬阻挡点）：
#   presets/agint/agent.cordis.yml 里 <id>/lib/tools.js 的声明行写的是相对路径，
#   从部署位 $DSH_HOME/.agent-presets/agint/ 解析出去。仓库模板当初写死
#   `../../profiles/web/plugins/…`，装到 desktop 而不改 ⇒ 这些行全部指向一个
#   不存在（或没装 AGINT）的目录 ⇒ **模型可见的工具全缺，且没有任何一行报错**
#   （preset 加载失败不落日志）。
#
# 🔁 2026-10-26 换锚：从「按 --profile 改写」改为「锚 .agint-bundle/plugins」
#   原因：preset 文件全局只有一份（$DSH_HOME/.agent-presets/agint/），却被**所有**
#   profile 共用。按 profile 改写 ⇒ 装 web 再装 desktop 会把 web 的 25 行全部指空，
#   于是同一时刻只可能有一端是好的，失败表现依旧是「零报错、工具莫名消失」。
#   .agint-bundle/plugins 是 dsh bundle 形态的**主挂载源**（见上方「部署位」说明；
#   profiles/<p>/plugins 只是它的兼容镜像位）。锚在这里，路径里不含 profile 名，
#   装一次两端同时成立。
#   附带收益：preset 的 tools.js 与服务插件指向同一份物理文件 ⇒ 不会出现两个模块
#   实例、模块级状态不共享的问题（check-wiring「查 E」点名的双实例风险）。
#
# 为什么在 rsync **之后**：步骤 1 的 safe_rsync 带 --delete，会把部署位整份镜像回
#   仓库模板。这一步必须在它之后，否则当次改完、下次重装又退回模板。
#
# 为什么只认 agint 一个目录：2026-10-26 起子 preset 迁到 agint-presets 独立仓，
#   各仓管各自的部署位，本安装器不越界去改别的仓库铺进来的 preset。
#
# 幂等：历史部署里的旧写法（../../profiles/<名>/plugins/）会被迁移过来；已经是
#   新锚点的文件不会被改动。
rewrite_preset_profile_refs() {
  [ "$DRY_RUN" = "1" ] && {
    log "   [DRY] 把 preset 工具行统一锚到 ../../.agint-bundle/plugins/，并逐条核验目标存在"
    return 0
  }
  # 锚点是 bundle 主挂载源，由步骤 1/2 铺出来。不在就别假装改成功。
  [ -d "$BUNDLE_PLUGINS_DST" ] || {
    warn "工具行锚点不存在：$BUNDLE_PLUGINS_DST —— preset 的工具会全缺"
    return 1
  }
  python3 - "$(winpath "$PRESETS_DST")" "$(winpath "$DSH_HOME")" <<'PY' || warn "preset 工具行锚定/核验未通过（工具会缺，或历史部署未迁移）"
import os, re, sys

presets_dst, dsh_home = sys.argv[1], sys.argv[2]
legacy = re.compile(r'\.\./\.\./profiles/[A-Za-z0-9._-]+/plugins/')
anchor = '../../.agint-bundle/plugins/'
row = re.compile(r'^\s*name:\s*(\.\./\.\./\.agint-bundle/plugins/\S+)\s*$', re.M)

path = os.path.join(presets_dst, 'agint', 'agent.cordis.yml')
if not os.path.isfile(path):
    print(f'[AGINT]   ✗ 缺 {path}', file=sys.stderr)
    sys.exit(1)

text = open(path, encoding='utf-8').read()
new_text, migrated = legacy.subn(anchor, text)
if migrated:
    open(path, 'w', encoding='utf-8', newline='').write(new_text)
    text = new_text
    print(f'[AGINT]   ↻ agint: 迁移 {migrated} 行旧写法 → {anchor}')

base = os.path.join(dsh_home, '.agent-presets', 'agint')
rels = row.findall(text)
missing = []
for rel in rels:
    target = os.path.normpath(os.path.join(base, rel))
    if not os.path.isfile(target):
        missing.append((rel, target))

if missing:
    print(f'[AGINT]   ✗ {len(missing)} 个工具目标不存在（共 {len(rels)} 行工具声明）：', file=sys.stderr)
    for rel, target in missing:
        print(f'      {rel}\n        → {target}', file=sys.stderr)
    print('[AGINT]   bundle 主挂载源没铺全，先确认步骤 1/2 成功。', file=sys.stderr)
    sys.exit(1)

print(f'[AGINT]   ✓ agint: {len(rels)} 行工具全部指向 bundle 主挂载源且目标存在')
PY
}
rewrite_preset_profile_refs

# ── 1.1 preset 依赖解析入口（dsh ≥ 0.1.7 必需）────────────────────────────────
#
# 0.1.7 起 preset 不再靠「扫 .agent-presets/ 目录」发现，必须在 composition 里声明。
# 我们用 `cordis:include` 复用 .agent-presets/<id>/agent.cordis.yml（保持单一事实源）。
#
# ⚠ 代价（2026-09-23 影子环境实测）：include 会把子条目的 baseUrl 设成「被读文件
#   所在目录」= .agent-presets/<id>/，于是 preset 里所有**裸包名**
#   （@deepseek-ai/dsh-persona / dsh-tool-fs / dsh-tool-web …）都从该目录向上解析，
#   而它天然没有 node_modules ⇒ 官方插件行全部 `never started` ⇒ registry 判定
#   broken ⇒ **UI 只显示「加载失败」，真实原因不落日志**（agint 实测 23 条）。
#
# 修法：在 presets **父目录**放一个解析入口 → dsh 安装目录的 node_modules（那里有
#   276 个包，含全部官方 preset 依赖）。子目录向上第一级就命中。
#   ⛔ 不能放进 .agent-presets/<id>/ 里 —— 步骤 1 的 safe_rsync 带 --delete，
#      下次重装会把 preset 目录整个镜像一遍，入口当场消失（症状复活）。
#
# 失败只 warn 不阻断：dsh < 0.1.7 压根不注册 preset，缺它无影响；
# 手工补一条 `mklink /J` 即可恢复。
# 摘除一个「可能是 junction / symlink / 实体目录」的解析入口。
# ⛔ Windows junction 必须先走 cmd rmdir（只摘链、不下钻）；rm -rf 对 MSYS 里的
#   junction 行为不可靠，误下钻会删掉真包（10-06 事故教训）。
# 返回 0 = 该路径已不存在。
remove_module_entry() {
  local p="$1"
  [ -L "$p" ] || [ -e "$p" ] || return 0
  if [ -L "$p" ]; then
    rm -f "$p" 2>/dev/null
  elif command -v cmd >/dev/null 2>&1; then
    cmd //c "rmdir /Q \"$(cygpath -w "$p" 2>/dev/null || printf '%s' "$p")\"" >/dev/null 2>&1 || true
  fi
  [ -L "$p" ] || [ -e "$p" ] || return 0
  rm -rf "$p" 2>/dev/null || true
  ! [ -L "$p" ] && ! [ -e "$p" ]
}

ensure_preset_module_entry() {
  local link="$PRESETS_DST/node_modules" target
  target="$(locate_dsh_dir)/node_modules"
  if [ -z "$target" ] || [ ! -d "$target" ]; then
    warn "未能定位 dsh 的 node_modules（DSH_ROOT / dsh 可执行文件 / npm root -g 均失败），跳过 preset 解析入口。"
    warn "  dsh ≥ 0.1.7 上智进 preset 会显示「加载失败」。手工补："
    warn "    mklink /J \"$link\" \"<npm root -g>\\@deepseek-ai\\dsh\\node_modules\""
    return 0
  fi
  # ⛔ 2026-10-08 修：「入口存在」不等于「入口健康」。
  #   悬空 junction/symlink 对 [ -d ] 返回 FALSE（看着像「不存在」），
  #   但链接实体依然在 ⇒ mklink /J 与 ln -s 双双因「文件已存在」失败，
  #   于是入口永远停在那个死链接上，官方包裸 import 全挂（实测 27/35 失败），
  #   而日志只留一句「创建失败」，极易被当成偶发而放过。
  #   故：先命中 -L/-e 判健康，不健康就摘除再重建（对齐 mirror 卫兵的严谨度）。
  if [ -L "$link" ] || [ -e "$link" ]; then
    if [ -d "$link" ]; then
      log "   ✓ preset 解析入口已存在且健康（$link）"
      return 0
    fi
    warn "preset 解析入口存在但目标不可达（悬空），先摘除再重建：$link"
    if ! remove_module_entry "$link"; then
      warn "  摘除失败，preset 解析入口保持原样（官方插件行会 never started）。"
      return 0
    fi
  fi
  if [ "$DRY_RUN" = "1" ]; then
    log "   [DRY] 建 preset 解析入口 $link → $target"
    return 0
  fi
  if command -v cmd >/dev/null 2>&1; then
    # Windows：junction（普通权限可建，symlink 需要管理员/开发者模式）
    local wl wt
    wl="$(cygpath -w "$link" 2>/dev/null || printf '%s' "$link")"
    wt="$(cygpath -w "$target" 2>/dev/null || printf '%s' "$target")"
    if cmd //c "mklink /J \"$wl\" \"$wt\"" >/dev/null 2>&1; then
      log "   ✓ preset 解析入口已建立（junction）"
      return 0
    fi
  fi
  if ln -s "$target" "$link" 2>/dev/null; then
    log "   ✓ preset 解析入口已建立（symlink）"
    return 0
  fi
  warn "preset 解析入口创建失败（$link → $target）。dsh ≥ 0.1.7 上智进会显示「加载失败」。"
}
ensure_preset_module_entry

# ── 1.2 bundle 内解析入口（bundle 形态必需）──────────────────────────────────
#
# bundle 里的插件用**裸包名** import 官方包（@deepseek-ai/dsh-storage-domain /
# dsh-tools / dsh-cordis …）。bundle 包自己不带依赖（刻意不写 dependencies，
# 避免 pnpm 去 registry 找 @agint/host），所以必须在包内给一条解析入口。
#
# 修法：<bundle>/node_modules/@deepseek-ai → dsh 安装目录的 node_modules/@deepseek-ai
#   （266+ 个官方包）。⛔ 必须链在**包内**：profile 层的 node_modules 不参与包内解析。
#   与 preset 入口同一个坑：safe_rsync 排除 node_modules，否则下次 sync 被删。
#
# 失败只 warn 不阻断：真正的后果是 bundle 层被 dsh 跳过
# （stderr 打 `skipping profile bundle "@agint/host"`），届时按上面提示手工补链。
ensure_bundle_module_entry() {
  local link="$BUNDLE_DST/node_modules/@deepseek-ai" target
  target="$(locate_dsh_dir)/node_modules/@deepseek-ai"
  if [ -z "$target" ] || [ ! -d "$target" ]; then
    warn "未能定位 dsh 的 node_modules（DSH_ROOT / dsh 可执行文件 / npm root -g 均失败），跳过 bundle 解析入口。"
    warn "  bundle 插件的官方包 import 会失败。手工补："
    warn "    mklink /J \"$BUNDLE_DST\\node_modules\\@deepseek-ai\" \"<npm root -g>\\@deepseek-ai\\dsh\\node_modules\\@deepseek-ai\""
    return 0
  fi
  # 同 ensure_preset_module_entry：悬空入口必须摘除再重建，否则 mklink/ln 双双失败，
  # 入口永远停在死链接上（2026-10-08 实测，bundle 插件 import 27/35 失败即此因）。
  if [ -L "$link" ] || [ -e "$link" ]; then
    if [ -d "$link" ]; then
      log "   ✓ bundle 解析入口已存在且健康（$link）"
      return 0
    fi
    warn "bundle 解析入口存在但目标不可达（悬空），先摘除再重建：$link"
    if ! remove_module_entry "$link"; then
      warn "  摘除失败，bundle 解析入口保持原样（bundle 插件官方包 import 会失败）。"
      return 0
    fi
  fi
  if [ "$DRY_RUN" = "1" ]; then
    log "   [DRY] 建 bundle 解析入口 $link → $target"
    return 0
  fi
  mkdir -p "$BUNDLE_DST/node_modules"
  if command -v cmd >/dev/null 2>&1; then
    local wl wt
    wl="$(cygpath -w "$link" 2>/dev/null || printf '%s' "$link")"
    wt="$(cygpath -w "$target" 2>/dev/null || printf '%s' "$target")"
    if cmd //c "mklink /J \"$wl\" \"$wt\"" >/dev/null 2>&1; then
      log "   ✓ bundle 解析入口已建立（junction）"
      return 0
    fi
  fi
  if ln -s "$target" "$link" 2>/dev/null; then
    log "   ✓ bundle 解析入口已建立（symlink）"
    return 0
  fi
  warn "bundle 解析入口创建失败（$link → $target）。"
}
ensure_bundle_module_entry

# ── 1.45 mirror 位解析卫兵（2026-10-06 dsh-tools stub 事故修）────────────────
#
# 兼容镜像位 $PLUGINS_DST 里的 AGINT 插件仍按**裸包名** import 官方包
# （@deepseek-ai/dsh-tools / cordis / dsh-storage-domain），解析走
# $PLUGINS_DST/node_modules/@deepseek-ai/<pkg>。
#
# ⛔ 2026-10-06 容器事故（gzsx dsh-agint）：该位置曾有一份手写的 0.0.0-stub
#   （defineTool 恒等函数 + main 指向 stub 的 index.js）→
#   valueSchemaSpecToJsonSchema 从不执行 → required 严格校验裸奔 →
#   agint preset 挂载必炸（25 插件 / 136 工具全灭）。
#   官方 npm tarball 从无顶层 index.js；stub 是部署调试期手工放入的
#   （物证：$DSH_HOME/.agint-backups/2026-10-06-dsh-tools-stub/stub-package/）。
#
# 本步保证：mirror 位这三个名字要么不存在、要么解析到 dsh 自带**真包**；
# 任何 0.0.0-stub 一律替换为指向真包的链接。幂等；失败仅 warn 不阻断。
# 与 1.1/1.2 同一坑族：safe_rsync 排除 node_modules ⇒ rsync 分支下本步产物
# 能活过步骤 2；python 回退分支（无 rsync）会整树换入删掉 ⇒ 4.6 有 post-plugin 复跑。
# 从 mirror 位真 import 一次 dsh-tools：能不能 import 才是「依赖树完整」的判据。
# 没有 node ⇒ 跳过自检（不阻断）：没有 node 时装出来的包也用不了，但别在这里卡死。
# 2026-10-21：这是「三包名单不够」那次的判据来源 —— dsh-tools 自己 import 失败，
#   它的每个使用者（preset 的 25 个工具行）也都失败。
mirror_dsh_tools_importable() {
  local base="$1"
  command -v node >/dev/null 2>&1 || return 0
  [ -e "$base/dsh-tools/lib/index.js" ] || return 1
  node --input-type=module -e "import { pathToFileURL } from 'node:url'; import(pathToFileURL(process.argv[1]).href).then(() => process.exit(0)).catch(() => process.exit(1));" "$base/dsh-tools/lib/index.js" >/dev/null 2>&1
}

ensure_mirror_module_entry() {
  local base="$PLUGINS_DST/node_modules/@deepseek-ai" target name link
  target="$(locate_dsh_dir)/node_modules/@deepseek-ai"
  # 定位不到就跳过（不阻断）：locate_dsh_dir 内部已做多候选 + 验明真身，
  # 含 10-06 容器那种「npm root -g 指向错误前缀」的兜底。
  if [ -z "$target" ] || [ ! -d "$target/dsh-tools" ]; then
    warn "未能定位 dsh 自带官方包（DSH_ROOT / dsh 可执行文件 / npm root -g / 常见前缀均失败），跳过 mirror 解析卫兵。"
    warn "  ⚠️ dsh-tools stub 事故的防线在本机未生效，preset 挂载可能整体炸（症状：工具全灭）。"
    warn "  手工补：ln -s <dsh>/node_modules/@deepseek-ai $base"
    return 0
  fi
  if [ "$DRY_RUN" = "1" ]; then
    log "   [DRY] mirror 解析卫兵：$base → $target"
    return 0
  fi
  # 拓扑分派（2026-10-06 教训：scope 目录可能是 symlink，逐包操作会穿透到
  # dsh 自带树、搬走/覆盖真包 ⇒ symlink 拓扑下只允许整链级操作，禁逐包 rm/mv）
  if [ -L "$base" ]; then
    # 整 scope 已是链接：健康判定 = 解析后三入口都有真包 lib/index.js
    if [ -e "$base/dsh-tools/lib/index.js" ] && [ -e "$base/cordis/lib/index.js" ] \
       && [ -e "$base/dsh-storage-domain/lib/index.js" ]; then
      log "   ✓ mirror 位 @deepseek-ai 整链 → 真包树（$base）"
      return 0
    fi
    rm -f "$base"
    if ln -s "$target" "$base" 2>/dev/null; then
      log "   ✓ mirror 位 @deepseek-ai 链接已重指 → $target"
      return 0
    fi
    warn "mirror 位 @deepseek-ai 重指失败（$base → $target）。"
    return 0
  fi
  # 实体目录拓扑：逐包卫兵
  mkdir -p "$base"
  local rebuilt=0
  for name in dsh-tools cordis dsh-storage-domain; do
    link="$base/$name"
    # 已就绪判定：解析目标存在、有 lib/index.js、且不是 0.0.0-stub
    if [ -e "$link/lib/index.js" ] && ! grep -q '"0.0.0-stub"' "$link/package.json" 2>/dev/null; then
      continue
    fi
    if [ ! -d "$target/$name" ]; then
      warn "dsh 自带包里也没有 $name，mirror 位 $name 保持原样。"
      continue
    fi
    # 删除旧条目。⛔ 顺序敏感：Windows 上 junction 必须先走 cmd rmdir（只摘链
    #   不下钻）；rm -rf 对 MSYS 里的 junction 行为不可靠，误下钻会删掉真包
    #   （10-06 事故处理中「误删真包」的教训）。
    if [ -L "$link" ]; then
      rm -f "$link"
    elif [ -d "$link" ]; then
      if command -v cmd >/dev/null 2>&1; then
        cmd //c "rmdir /Q \"$(cygpath -w "$link" 2>/dev/null || printf '%s' "$link")\"" >/dev/null 2>&1 || true
      fi
      [ -e "$link" ] && rm -rf "$link"
    fi
    if command -v cmd >/dev/null 2>&1; then
      local wl wt
      wl="$(cygpath -w "$link" 2>/dev/null || printf '%s' "$link")"
      wt="$(cygpath -w "$target/$name" 2>/dev/null || printf '%s' "$target/$name")"
      if cmd //c "mklink /J \"$wl\" \"$wt\"" >/dev/null 2>&1; then
        log "   ✓ mirror 位 $name 已重建（junction → 真包）"
        rebuilt=$((rebuilt+1))
        continue
      fi
    fi
    if ln -s "$target/$name" "$link" 2>/dev/null; then
      log "   ✓ mirror 位 $name 已重建（symlink → 真包）"
      rebuilt=$((rebuilt+1))
    else
      warn "mirror 位 $name 重建失败（$link → $target/$name）。preset 挂载会报 required 校验错。"
    fi
  done
  # 全量清查：mirror 位不允许任何 0.0.0-stub 存活（防同一手法再放别的包）
  local stubbed
  stubbed="$(grep -l '"0.0.0-stub"' "$base"/*/package.json 2>/dev/null || true)"
  if [ -n "$stubbed" ]; then
    warn "mirror 位仍检出 0.0.0-stub 包（不在上述三名内，未自动替换，请人工核查）："
    warn "$stubbed"
  fi
  # 终态判定（诚实日志：重建 0 个 ≠ 三个都就绪，必须真验存在性）
  local ok=1 bad=""
  for name in dsh-tools cordis dsh-storage-domain; do
    [ -e "$base/$name/lib/index.js" ] || { ok=0; bad="$bad $name"; }
  done
  if [ "$ok" = 1 ]; then
    log "   ✓ mirror 位三入口均解析到真包（dsh-tools / cordis / dsh-storage-domain）"
  else
    warn "mirror 位以下入口未就绪（缺 lib/index.js）：$bad —— preset 挂载会报 required 校验错。"
  fi

  # ⛔ 2026-10-21 补：上面的「三包名单」是**下限**，不是充分条件。
  #
  # 实测事故：本机 mirror 位只有那三个包，而 dsh-tools@0.2.1-rc.2 的 lib/index.js
  #   还裸 import `@deepseek-ai/dsh-scope`（**它自己的 package.json 里都没声明
  #   这个依赖**）⇒ dsh-tools 自己 import 就失败 ⇒ mirror 位的 **25 个工具行
  #   import 全炸**（ERR_MODULE_NOT_FOUND）⇒ 智进 preset 挂得上、但一个 agint
  #   工具都没有，**界面没有任何报错**。
  #   症状与 10-06 的 dsh-tools stub 事故同族（工具全灭、界面不报错），
  #   差别只在根因（那次是 stub，这次是依赖树不全）。
  #
  # 修法：判据从「名单里有这三个」改成「**dsh-tools 能不能 import**」。
  # 不过就把整个 scope 换成指向 dsh 官方 scope 的**整链链接**（与 bundle 位同形），
  # 一次性给全 306 个官方包，后续 dsh 升级新增依赖也不会再缺。
  if [ "$DRY_RUN" != "1" ] && [ "$ok" = 1 ]; then
    if ! mirror_dsh_tools_importable "$base"; then
      warn "  mirror 位 dsh-tools 自身依赖解析不到（三包名单不够）→ 改用整链链接"
      # 摘 scope 目录。⛔ 只摘这一层，且先摘内部 junction，
      #   绝不让 rm -rf 穿透到 dsh 官方树（10-06 / 10-18 两次事故的教训）。
      if [ -L "$base" ]; then
        rm -f "$base"
      else
        find "$base" -maxdepth 2 -type l -exec rm -f {} \; 2>/dev/null || true
        rm -rf "$base"
      fi
      mkdir -p "$(dirname "$base")"
      local wl wt
      wl="$(cygpath -w "$base" 2>/dev/null || printf '%s' "$base")"
      wt="$(cygpath -w "$target" 2>/dev/null || printf '%s' "$target")"
      if cmd //c "mklink /J \"$wl\" \"$wt\"" >/dev/null 2>&1; then
        log "   ✓ mirror 位 @deepseek-ai 整链 → $target（306 个官方包，依赖树完整）"
      elif ln -s "$target" "$base" 2>/dev/null; then
        log "   ✓ mirror 位 @deepseek-ai 整链（symlink）→ $target"
      else
        warn "mirror 位整链重建失败（$base → $target）—— preset 工具行可能 import 失败。"
      fi
    fi
  fi
}
ensure_mirror_module_entry

# ── 1.5 zod bootstrap（必须在 plugin 同步之前）───────────────────────────────
# 见 install/agint-zod-bootstrap.sh。
# 顺序约束：步骤 2 用 safe_rsync --delete 把 plugins/agint-quality/node_modules/zod
# 清掉（仓源没有），所以 zod 必须先放进 host，再让 plugin 同步覆盖。
# 失败仅 warn，不阻断（用户可手动跑）。
# 同时在 2.7 段保留一份兜底（post-plugin 位置，见 2.7 段注释：非 rsync 机器的
# 整树换入会清掉本段产物，届时由 2.7 段补回）。
if [ "$DRY_RUN" != "1" ]; then
  if AGINT_PROFILE="$PROFILE_NAME" DSH_HOME="$DSH_HOME" bash "$SCRIPT_DIR/agint-zod-bootstrap.sh" >/dev/null 2>&1; then
    log "   ✓ zod bootstrap OK（pre-plugin）"
  else
    warn "zod bootstrap 失败（agint-quality-* plugin 启动时会找不到 zod）。手动跑：AGINT_PROFILE=$PROFILE_NAME bash $SCRIPT_DIR/agint-zod-bootstrap.sh"
  fi
else
  log "   ⊘ 跳过 zod bootstrap（dry-run）"
fi

# ── 2. 安装 plugins ─────────────────────────────────────────────────────────
log "2/4 同步 plugins → $PLUGINS_DST"
mkdir -p "$PLUGINS_DST"
for src in "$PLUGINS_SRC"/agint-*/; do
  [ -d "$src" ] || continue
  name="$(basename "$src")"
  dst="$PLUGINS_DST/$name"
  backup "plugins" "$dst"
  safe_rsync "$src" "$dst"
  if [ "$DRY_RUN" != "1" ]; then register_step "rm_dst|$dst"; fi
  log "   ✓ $name"
done

# 2026-10-29：`plugins/_shared` **不是插件**（目录下没有 manifest.json），但三个插件的
# 测试替身都从 `../../_shared/test-stub-dsh-tools.mjs` 取同一份契约 ⇒ 必须跟着一起铺。
# ⛔ 漏掉它的后果（实测 2026-10-29）：仓库侧测试 31/31、63/63 全绿，而**部署位**
# evolve 红 2 条、input-gateway 红 1 条（ERR_MODULE_NOT_FOUND）—— 门禁的 smoke 是在
# 部署位跑的，于是「仓库绿、部署红」这种最难查的不一致就出现了。
if [ -d "$PLUGINS_SRC/_shared" ]; then
  dst="$PLUGINS_DST/_shared"
  backup "plugins" "$dst"
  safe_rsync "$PLUGINS_SRC/_shared" "$dst"
  if [ "$DRY_RUN" != "1" ]; then register_step "rm_dst|$dst"; fi
  log "   ✓ _shared（非插件的共用测试资产）"
fi

# ── 2.5 镜像到 bundle 部署位（dsh bundle 形态的主挂载源）─────────────────────
# 为什么同一份源铺两处：
#   · bundle patch 的 insert 行按「本 patch 文件所在目录」解析（app-boot
#     anchorInsertedPluginNames）⇒ 插件必须在 <bundle>/plugins/ 下；
#   · 而 AGINT 自身代码按老路径定位插件（agint-dream/lib/quality-bridge.js 用
#     $DSH_HOME/profiles/<profile>/plugins/<id>），各 preset 的 tools 行同理 ⇒ 保留兼容位。
#   两处同源、同一次 sync，天然一致，不引入漂移。
log "2.5/4 镜像到 bundle → $BUNDLE_PLUGINS_DST"
# ⛔ 必须建到 plugins 这一层：rsync 3.1.3 只建 dst 的最后一级，中间目录缺失就
#    `mkdir ... failed: No such file or directory (2)` + code 11（python3 后端
#    走 os.makedirs，会自动补中间层——两个后端在这里的行为不对称）。
mkdir -p "$BUNDLE_PLUGINS_DST"
for src in "$PLUGINS_SRC"/agint-*/; do
  [ -d "$src" ] || continue
  name="$(basename "$src")"
  safe_rsync "$src" "$BUNDLE_PLUGINS_DST/$name"
  log "   ✓ $name"
done

# 同上：bundle 位也要有 `_shared`（preset 工具行锚在这里，插件测试也在这里跑）。
if [ -d "$PLUGINS_SRC/_shared" ]; then
  safe_rsync "$PLUGINS_SRC/_shared" "$BUNDLE_PLUGINS_DST/_shared"
  log "   ✓ _shared（非插件的共用测试资产）"
fi

# ── 2.6 部署位引用重写：把 profiles/web 改成目标 profile ─────────────────────
#
# 与 1.3 同源，但作用在**插件部署位**。当前唯一命中是 agint-family-panel 的
# manifest.json：`permissions.fs` 里声明 `"read:profiles/web/plugins"`。
# 该声明是 dsh 的静态权限白名单 —— 装到 desktop 后插件读的是 profiles/desktop/plugins，
# 声明与实际路径不符 ⇒ 读被拒 ⇒ 面板源整体 state:error（**静默降级**）。
#
# 为什么用「扫全部部署位 manifest」而不是只改那一个文件：权限声明这类机器相关字面量
# 以后还会出现，固定文件名会让第二处再次静默漏改。扫到 0 处时**要吵一声**（见下），
# 「扫了 0 项」往往是正则没匹配上，不是真的没有。
rewrite_deployed_profile_refs() {
  local roots=("$PLUGINS_DST" "$BUNDLE_PLUGINS_DST")
  if [ "$DRY_RUN" = "1" ]; then
    log "   [DRY] 将把部署位 manifest 里的 profiles/*/plugins 改指 $PROFILE_NAME"
    return 0
  fi
  python3 - "$(winpath "$PLUGINS_DST")" "$(winpath "$BUNDLE_PLUGINS_DST")" "$PROFILE_NAME" <<'PY' || warn "部署位 manifest 权限重写失败（装到非 web profile 时相关插件会读不到数据）"
import os, re, sys, glob, json

mirror, bundle, profile = sys.argv[1], sys.argv[2], sys.argv[3]
pat = re.compile(r'(profiles/)[A-Za-z0-9._-]+(/plugins)')
total_files = 0
total_hits = 0
for root in (mirror, bundle):
    if not os.path.isdir(root):
        print(f'[AGINT]   ! 部署位不存在，跳过：{root}')
        continue
    for path in sorted(glob.glob(os.path.join(root, '*', 'manifest.json'))):
        try:
            text = open(path, encoding='utf-8').read()
        except OSError as e:
            print(f'[AGINT]   ! 读不动 {path}: {e}')
            continue
        new_text, n = pat.subn(lambda m: m.group(1) + profile + m.group(2), text)
        if n == 0:
            continue
        # 改写前后都得是合法 JSON：宁可少改一个文件，也不要写坏一份 manifest
        try:
            json.loads(new_text)
        except json.JSONDecodeError as e:
            print(f'[AGINT]   ✗ 改后不是合法 JSON，放弃改写 {path}: {e}')
            continue
        open(path, 'w', encoding='utf-8', newline='').write(new_text)
        total_files += 1
        total_hits += n
        print(f'[AGINT]   ✓ {os.path.basename(os.path.dirname(path))}/manifest.json：{n} 处 → profiles/{profile}/plugins')
if total_hits == 0:
    print('[AGINT]   · 部署位 manifest 里没有 profiles/*/plugins 声明（确认过是 0 处则可忽略；'
          '若你预期应有，检查这里扫的路径对不对）')
else:
    print(f'[AGINT]   ✓ 部署位 manifest 合计重写 {total_hits} 处（{total_files} 个文件）→ profiles/{profile}/plugins')
PY
}
rewrite_deployed_profile_refs

# ── 2.7 同步后模块 bootstrap（zod + mirror 解析卫兵）────────────────────────
# ⛔ 2026-10-27 排序修复：原 4.5/4.6 段把这两个 bootstrap 放在「4d 冒烟 + die」
#   之后，但在**无 rsync** 的机器上步骤 2 走 python 回退分支，safe_rsync 用
#   「整树换入」（rmtree(dst) + rename）把 bundle plugins 整目录重铺，
#   会清掉 1.5 段刚铺进 plugins/agint-quality/node_modules 的 zod（mirror 位在
#   $PLUGINS_DST/node_modules/@deepseek-ai，比被清子树高一级，不受影响）。于是 4d 冒烟时
#   这 4 个 quality 插件相对路径 zod import
#   全挂 → die 回滚，而本该补救的 4.5/4.6 排在 die 之后永远跑不到。
#   修法：把 zod + mirror 这两个 post-plugin bootstrap 移到「步骤 2 同步之后、
#   4d 冒烟之前」，与 1.5/1.45 形成「pre-plugin 主 + post-plugin 兜底」双保险。
#   rsync 分支（--exclude node_modules 保活 zod）下 2.7 幂等跳过，无副作用。
#   zod 源搜索缺口同步在 agint-zod-bootstrap.sh 补了 .agint-deps / .agint-bundle。
log "2.7/4 同步后模块 bootstrap（zod + mirror）"
if [ "$DRY_RUN" != "1" ]; then
  if AGINT_PROFILE="$PROFILE_NAME" DSH_HOME="$DSH_HOME" bash "$SCRIPT_DIR/agint-zod-bootstrap.sh" >/dev/null 2>&1; then
    log "   ✓ zod bootstrap OK（post-plugin 兜底）"
  else
    warn "zod bootstrap 失败（agint-quality-* plugin 启动时会找不到 zod）。手动跑：AGINT_PROFILE=$PROFILE_NAME bash $SCRIPT_DIR/agint-zod-bootstrap.sh"
  fi
  ensure_mirror_module_entry
else
  log "   ⊘ 跳过同步后模块 bootstrap（dry-run）"
fi

# ── 3. 同步 bundle 挂载层（patch + 清单 + 解析入口）─────────────────────────
# 2026-09-24 起 AGINT 的挂载行住在 **bundle 层**，不再写 profile 级 patch：
# 官方口径 profile 级 patch 优先级高于 bundle 层，两边都写 = 同一批 id 重复挂载。
log "3/4 同步 bundle 挂载层 → $BUNDLE_PATCH_DST"
mkdir -p "$BUNDLE_DST"
backup "patch" "$BUNDLE_PATCH_DST"

# 3a. 抓取模板值与本机已存在的 override（**都必须在 cp 之前**）。
#     背景：cordis.patch.yml 是**两机共用的模板**。机器私有绝对路径按 AGENTS.md:16
#     红线不入库，早期靠「各机手改 $DSH_HOME 侧副本（HOME override）」解决；实测事故
#     （2026-10-04 20:30）：另一会话 deploy family-panel 0.2.3 时，下面这行 `cp -f`
#     把生效位整文件覆盖回模板值，麒麟机 override 被**静默**冲掉（事后生效位与仓库
#     模板 md5 完全相同）⇒ frozen-anchor 每日 10:30 重新硬失败。
#     现在模板改用 `!!js` 加载时求值（见仓库 cordis.patch.yml 两处 repoRoot），于是：
#       模板值是 `!!js…`  ⇒ **不保留**：表达式才是本机真值来源，强行保留会把
#                        旧字面量钉死、让 AGINT_REPO_ROOT 逃生口失效（本条即那次事故的
#                        同类隐患：机制被静默冻结）。
#       模板值是字面量    ⇒ 保留本机 override（老模板/未来新增的机器私有键仍受保护）。
#     只认 agint-evolution-driver 段里那一处 repoRoot；要扩到别的机器私有键时，
#     在下面两个正则里各加一条即可。
patch_read_repo_root() {  # $1=文件 → 打印该文件 agint-evolution-driver 段的 repoRoot 原值（无则空）
  python3 - "$(winpath "$1")" <<'PY' 2>/dev/null || true
import re, sys
try:
    text = open(sys.argv[1], encoding='utf-8').read()
except OSError:
    sys.exit(0)
# 只在 agint-evolution-driver 这个 - id: 块内找，别处同名键不误伤
m = re.search(r'-\s+id:\s+agint-evolution-driver\b(?:(?!-\s+id:).)*?repoRoot:\s*(\S[^\n]*)', text, re.S)
print(m.group(1).strip() if m else '')
PY
}
PATCH_TPL_REPO_ROOT=""
[ -f "$BUNDLE_PATCH_SRC" ] && PATCH_TPL_REPO_ROOT="$(patch_read_repo_root "$BUNDLE_PATCH_SRC")"
PATCH_KEPT_REPO_ROOT=""
[ -f "$BUNDLE_PATCH_DST" ] && PATCH_KEPT_REPO_ROOT="$(patch_read_repo_root "$BUNDLE_PATCH_DST")"

cp -f "$BUNDLE_PATCH_SRC"    "$BUNDLE_PATCH_DST"    || die "bundle patch 复制失败: $BUNDLE_PATCH_SRC"

# 3a-bis. 展开 `__DSH_HOME__` 占位符 → 本机真实路径。
#     为什么需要（dsh 0.2.0-rc.2 实测，AGINT 0.11.0 模板踩坑）：
#       cordis:include 用 new URL(config.path, ctx.baseUrl) 解析 include 路径
#       （cordis-plugin-include/lib/index.js:123），而 dsh 把 ctx.baseUrl 定为
#       **本层配置文件所在目录**（dsh-app-boot/lib/index.js:4070）——bundle 层的
#       preset 声明行因此按 $DSH_HOME/.agint-bundle/ 解析，不是 profile 根。
#       模板里写死 `../../.agent-presets/…` 会落到 file:///.agent-presets/…
#       （文件系统根，不存在）⇒ `agent-preset/invalid: … config file not found`
#       ⇒ agint / agint-blockchain / agint-investor / agint-ops 四个 preset
#         永远不注册，UI 里只剩 standard/ptc/minimal/cordis。
#         （2026-10-26 注：当时是四个。后三个已迁出到 agint-presets 独立仓，
#          本仓现在只有 agint 一条声明，成因与修法不变。）
#     为什么用占位符而不是直接写绝对路径：
#       ① include 的 path 禁止 `!!js`（app-boot:3041
#          "include path must be literal; config expressions are not evaluated"）；
#       ② cordis.patch.yml 是**两机共用模板**（见 3a 段事故记录），机器私有绝对
#          路径按 AGENTS.md:16 红线不入库。
#     本步骤与 3a/3b 同构：模板给占位符，装脚本按 $DSH_HOME 求真值。
if grep -q '__DSH_HOME__' "$BUNDLE_PATCH_DST" 2>/dev/null; then
  if [ "$DRY_RUN" = "1" ]; then
    log "   [DRY] 将把 __DSH_HOME__ 展开为：$DSH_HOME"
  else
    python3 - "$(winpath "$BUNDLE_PATCH_DST")" "$DSH_HOME" <<'PY' \
      || die "bundle patch 的 __DSH_HOME__ 展开失败"
import re, sys
path, home = sys.argv[1], sys.argv[2].rstrip('/')
text = open(path, encoding='utf-8').read()
# 只替换 `path:` 键上的占位符。注释里也会出现 __DSH_HOME__（K83 说明段举例
# 引用了旧写法的 ../../.agent-presets/…），那些是文档不是配置，替换掉会
# 让注释指向与自身描述不符的路径。
pattern = re.compile(r'(^\s*path:\s*)__DSH_HOME__', re.M)
new_text, n = pattern.subn(lambda m: m.group(1) + 'file://' + home, text)
if n == 0:
    print('[AGINT]   ! 没有 `path:` 行含 __DSH_HOME__，未改动')
    sys.exit(0)
open(path, 'w', encoding='utf-8', newline='').write(new_text)
print(f"[AGINT]   ✓ 展开 __DSH_HOME__ → file://{home}（{n} 处 preset include 路径）")
PY
  fi
else
  log "   ✓ 模板无 __DSH_HOME__ 占位符（老模板，无需展开）"
fi

# 3b. 写回 override（模板是 `!!js` 表达式时不写回，见上方注释）。
case "$PATCH_TPL_REPO_ROOT" in
  '!!js'*)
    log "   ✓ 模板用 !!js 求值 repoRoot，不做保留（各机加载时自算，逃生口 AGINT_REPO_ROOT 有效）"
    ;;
  *)
    if [ -n "$PATCH_KEPT_REPO_ROOT" ]; then
      if [ "$DRY_RUN" = "1" ]; then
        log "   [DRY] 将保留本机 repoRoot override：$PATCH_KEPT_REPO_ROOT"
      else
        python3 - "$(winpath "$BUNDLE_PATCH_DST")" "$PATCH_KEPT_REPO_ROOT" <<'PY' \
          || warn "保留 repoRoot override 失败（槽里是模板值，frozen-anchor 等依赖本机路径的 job 会失败）"
import re, sys
path, keep = sys.argv[1], sys.argv[2]
text = open(path, encoding='utf-8').read()
m = re.search(r'(-\s+id:\s+agint-evolution-driver\b(?:(?!-\s+id:).)*?repoRoot:\s*)(\S[^\n]*)', text, re.S)
if not m:
    print('[AGINT]   ! 模板里没有 repoRoot 行，本机 override 未写回')
    sys.exit(0)
if m.group(2).strip() == keep:
    sys.exit(0)          # 这台机本来就没 override（值与模板相同）⇒ 不动、不吵
open(path, 'w', encoding='utf-8', newline='').write(
    text[:m.start(2)] + keep + text[m.end(2):])
print(f'[AGINT]   ✓ 保留本机 repoRoot override：{keep}（模板值「{m.group(2).strip()}」已让位）')
PY
      fi
    fi
    ;;
esac

cp -f "$BUNDLE_MANIFEST_SRC" "$BUNDLE_MANIFEST_DST" || die "bundle package.json 复制失败: $BUNDLE_MANIFEST_SRC"

# bundle 内解析入口：插件用裸包名 import 的官方包（@deepseek-ai/dsh-*）必须能在
# 包内解析到（zod 之外的全部）。链到 dsh 安装目录的 node_modules。
# ⛔ 必须链在包内，且 safe_rsync 排除 node_modules，否则下次 sync 被 --delete 删掉。
ensure_bundle_module_entry

# 残留检测：profile 级 patch 若还留着 agint-* **挂载段** → 会与 bundle 层重复挂载。
# 直接失败，不"打包带过"。
#
# ⚠️ 2026-10-23 修误报（旧版把本机 override 也当挂载段，本机部署被硬挡了 19 天）：
#    旧判据是「出现 `- id: agint-*` 就算」，但 profile 级 patch 里合法存在的是
#    **config-only 按 id 深合并**的本机 override（repoRoot / recordMode /
#    observation_period_days 等，各机各配、不入库）。它们不带 name/path/main，
#    cordis 找不到插件实体 ⇒ 不产生第二个实例，不是双重挂载。
#    证据有两条：① 本脚本自己的成功提示语写的是「只剩本机本地覆盖」——
#       「只剩」意味着 override 本该留下，旧正则却把它当残留；② profile patch 内
#       agint-skill-autocreate 段注释写明「config-only 按 id 深合并（先例：
#       agint-trajectory / agint-cron）」。
#    新判据：段内出现 name / path / main / entry / plugin 之一才算真挂载段。
#     sibling 键缩进 = id 行前导空白 + 2（`- ` 两字符），据此排除 config: 底下的同名嵌套键。
if [ -f "$PROFILE_PATCH_DST" ]; then
  python3 - "$(winpath "$PROFILE_PATCH_DST")" <<'PY' || die "profile 级 patch 仍含 AGINT 挂载段（会上双重挂载）。挂载段 = 带 name/path/main 入口键的段；config-only 的本机 override 不拦。备份在 .agint-backups/"
import re, sys
text = open(sys.argv[1], encoding='utf-8').read()
SEG = re.compile(r'^(\s*)-\s+id:\s+(agint-[a-z0-9-]+)\s*(?:#.*)?$')
MOUNT_KEYS = ('name', 'path', 'main', 'entry', 'plugin')

def indent_of(ln):
    return len(ln) - len(ln.lstrip(' '))

hits, overrides = [], []
cur_id, key_indent, cur_mount = None, None, False

def close():
    global cur_id, cur_mount
    if cur_id is None:
        return
    (hits if cur_mount else overrides).append(cur_id)
    cur_id, cur_mount = None, False

for ln in text.split('\n'):
    m = SEG.match(ln)
    if m:
        close()
        cur_id, key_indent, cur_mount = m.group(2), len(m.group(1)) + 2, False
        continue
    if cur_id is None or ln.strip() == '':
        continue
    ind = indent_of(ln)
    if ind <= key_indent - 2:          # 回到段级或更外层 ⇒ 本段结束
        close()
        continue
    if ind == key_indent and ln.strip().split(':', 1)[0] in MOUNT_KEYS:
        cur_mount = True
close()

if hits:
    print(f"[AGINT]   ✗ profile 级 patch 残留 {len(hits)} 个 AGINT 挂载段（如 {', '.join(hits[:5])} ...）")
    sys.exit(1)
if overrides:
    print(f"[AGINT]   ✓ profile 级 patch 无 AGINT 挂载段（{len(overrides)} 个 config-only 本机 override 按 id 深合并，放行：{', '.join(overrides)}）")
else:
    print("[AGINT]   ✓ profile 级 patch 无 AGINT 挂载段（只剩本机本地覆盖）")
PY
fi

if [ "$DRY_RUN" != "1" ]; then
  # 注册 patch 回滚：删当前 + 从 backup_dir 最新 patch 备份恢复
  register_step "restore_backup|$BUNDLE_PATCH_DST"
fi

# ── 3.5 注册 bundle 到 profile 清单（dsh.profile.bundles + dependencies）──────
# 与 uninstall.sh 2.6「摘除」对称。⛔ 少这一步：bundle 目录在、patch 在，
# 但 dsh 根本不加载它 —— 现象是「装完像没装」，**且没有任何报错**。
# 幂等：已注册则只打印跳过，不重写文件。
#
# ⛔ dependencies 里那一项是 2026-10-01 新增的，**不是冗余**：plugin_manager 每次
# 装/卸 bundle 都在 profile 目录跑 pnpm，pnpm 会剪掉没声明的包。bundle 实体
# 改成 symlink 之后，声明这一项才让它免于被剪（详见文件头）。
log "3.5/4 注册 bundle 到 profile 清单（dsh.profile.bundles + dependencies）"
if [ ! -f "$PROFILE_MANIFEST" ]; then
  warn "  跳过：$PROFILE_MANIFEST 不存在（该 profile 还没被 dsh 初始化过？）"
  warn "  手工补救：在 dsh.profile.bundles 里加上 $BUNDLE_NAME"
elif [ "$DRY_RUN" = "1" ]; then
  log "   注册 (dry): $BUNDLE_NAME @ $PROFILE_MANIFEST"
else
  backup "profile-manifest" "$PROFILE_MANIFEST"
  python3 - "$(winpath "$PROFILE_MANIFEST")" "$BUNDLE_NAME" "link:$BUNDLE_DST" <<'PY' || warn "profile 清单注册失败，请手工把 $BUNDLE_NAME 加入 dsh.profile.bundles（备份见 $BACKUP_DIR）"
import sys, json, io
path, name, spec = sys.argv[1], sys.argv[2], sys.argv[3]
data = json.loads(io.open(path, encoding='utf-8').read())
profile = data.setdefault('dsh', {}).setdefault('profile', {})
changed = []
bundles = profile.get('bundles')
if bundles is None:
    profile['bundles'] = [name]
    changed.append('bundles+')
elif not isinstance(bundles, list):
    print(f"[AGINT]   ✗ dsh.profile.bundles 不是数组（{type(bundles).__name__}），拒绝改写，请手工修")
    sys.exit(1)
elif name not in bundles:
    bundles.append(name)  # 追加末尾 = 优先级最低；官方 bundle 在前
    changed.append('bundles+')
deps = data.setdefault('dependencies', {})
if not isinstance(deps, dict):
    print(f"[AGINT]   ✗ dependencies 不是对象（{type(deps).__name__}），拒绝改写，请手工修")
    sys.exit(1)
if deps.get(name) != spec:
    deps[name] = spec
    changed.append('dependencies')
if not changed:
    print(f"[AGINT]   ↻ {name} 已注册（bundles + dependencies），跳过")
    sys.exit(0)
io.open(path, 'w', encoding='utf-8', newline='\n').write(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
print(f"[AGINT]   ✓ 已更新 {', '.join(changed)}：bundles = {', '.join(profile['bundles'])}，dependencies[{name}] = {spec}")
PY
fi

# ── 3.6 materialize node_modules/@agint/host 软链 ────────────────────────────
# dsh 解析 bundle 的唯一位置是 profiles/<profile>/node_modules/<name>，实体在
# $DSH_HOME/.agint-bundle/ ⇒ 这里必须有一条指过去的链接。3.5 已把
# "link:<实体目录>" 写进 dependencies，pnpm 下次跑会认领这条链接；本步只保证
# 「装完当下 dsh 就能看见 bundle」，不依赖 pnpm 被调用过。
log "3.6/4 建立 bundle 解析软链 → $BUNDLE_LINK"
ensure_bundle_link() {
  local link="$BUNDLE_LINK" target="$BUNDLE_DST"
  if [ -L "$link" ]; then
    local cur; cur="$(readlink "$link")"
    if [ "$cur" = "$target" ]; then
      log "   ✓ 软链已就位（$link → $target）"
      return 0
    fi
    log "   ↻ 软链指向已变（$cur → $target），重建"
    rm -f "$link"
  elif [ -e "$link" ]; then
    # 2026-10-01 前的旧部署位：一整份实体目录。让位给软链（内容已由 BUNDLE_DST 持有）。
    log "   ↻ $link 是旧部署留下的实体目录，移入 .agint-bundle 后改为软链"
    if [ "$DRY_RUN" != "1" ]; then
      backup "bundle-legacy" "$link"
      rm -rf "$link"
    fi
  fi
  [ "$DRY_RUN" = "1" ] && { log "   [DRY] 建软链 $link → $target"; return 0; }
  mkdir -p "$(dirname "$link")"
  # -n：已存在同名链接时覆盖，不动实体目录
  ln -sfn "$target" "$link" 2>/dev/null \
    && log "   ✓ 软链已建立（$link → $target）" \
    || warn "软链建立失败：$link → $target。dsh 会因解析不到 $BUNDLE_NAME 跳过整个 bundle。"
}

# ── 3.7 写「安装到哪个 profile」事实文件 ─────────────────────────────────────
#
# 产物：$DSH_HOME/.agint-bundle/profile.json  ← {"profile":"<名>","updatedAt":"<ISO>"}
#
# 为什么需要它（2026-10-08 实测，desktop 适配的关键一环）：
#   dsh 的 DSH_PROFILE / DSH_PROFILE_DIR 是 **shell 调用注册表**的内置键 —— 每次 bash /
#   pwsh 子进程执行时由 collect() 现构造，**从不写进 process.env**（asar 里
#   `process.env[DSH_*] =` 赋值 0 命中）。插件主进程因此读不到 profile 名，只能靠
#   ① cordis ctx 的 profileContext（权威，但只在有 ctx 的地方拿得到）
#   ② 本文件（AGINT 自己写的安装事实，任何进程都能读）
#   agint-dream 等**拿不到 ctx 的代码路径**靠它兜底，避免静默回落 web。
#
# ⛔ 放在 bundle 实体目录而不是 profile 目录：bundle 实体与 profile 无关（只注册到
#    profile 的 node_modules），这里只有一个值 = **最近一次安装的目标 profile**。
# ── 3.6 收尾：真正建立软链（函数定义在上面一行，调用在这里）──────────────────
ensure_bundle_link

write_profile_fact() {
  local out="$BUNDLE_DST/profile.json"
  if [ "$DRY_RUN" = "1" ]; then
    log "   [DRY] 写安装事实 $out ← {\"profile\":\"$PROFILE_NAME\"}"
    return 0
  fi
  mkdir -p "$BUNDLE_DST" || { warn "创建 $BUNDLE_DST 失败，跳过安装事实写入"; return 0; }
  python3 - "$(winpath "$out")" "$PROFILE_NAME" <<'PY' || warn "安装事实文件写入失败（无 ctx 的代码路径会回落 web）"
import json, sys, datetime
path, profile = sys.argv[1], sys.argv[2]
payload = {
    "profile": profile,
    "updatedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
}
open(path, 'w', encoding='utf-8', newline='\n').write(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
print(f'[AGINT]   ✓ 安装事实：profile = {profile}（{path}）')
PY
}
write_profile_fact

# ── 4. 装后静态校验 ─────────────────────────────────────────────────────────
log "4/4 装后静态校验"
if [ "$DRY_RUN" = "1" ]; then
  log "   跳过（dry-run）"
else
  failed=0
  # 4a. bundle patch YAML 能被 python yaml.safe_load 解析（剥离 !!js 等自定义 tag 后）
  python3 - "$(winpath "$BUNDLE_PATCH_DST")" <<'PY' || failed=$((failed+1))
import sys, re
try:
    import yaml
except ImportError:
    print("[AGINT]   ⚠ python3-yaml 未装，跳过 patch YAML 校验（pip install pyyaml 可启用）")
    sys.exit(0)
text = open(sys.argv[1], encoding='utf-8').read()
# 剥离 dsh 自定义 tag（!!js 表达式：!!js expr 或 !!js/function ...），仅做语法检查
# dsh 实际写法两种：!!js (expr) 或 !!js/function ...；原 regex r"!!js/\w+" 不覆盖前者
stripped = re.sub(r"!!js(/\w+)?", "", text)
try:
    yaml.safe_load(stripped)
    print("[AGINT]   ✓ patch YAML 语法 OK")
except yaml.YAMLError as e:
    print(f"[AGINT]   ✗ patch YAML 语法错误: {e}")
    sys.exit(1)
PY

  # 4b. 每个 active plugin 含 package.json
  # glob 'agint-*' 会包含 '.bak-*' 历史备份目录和子模块目录（agint-quality-contract /
  # agint-quality-eval 等通过相对路径引用父模块，没有自己的 package.json）。
  # dsh loader 对缺 package.json 的 plugin 子模块用 MODULE_TYPELESS fallback 处理，
  # 不是 fatal 错——只 warn 不计入失败。备份目录直接跳过。
  for plugin in "$PLUGINS_DST"/agint-*; do
    [ -d "$plugin" ] || continue
    name="$(basename "$plugin")"
    # 跳过 .bak-* 历史备份
    case "$name" in
      *.bak-*) continue ;;
    esac
    if [ -f "$plugin/package.json" ]; then
      log "   ✓ plugin $name 有 package.json"
    else
      warn "plugin $name 缺 package.json（MODULE_TYPELESS 警告，dsh loader fallback，非 fatal）"
      # 不计入 failed：plugin 子模块（通过相对路径引用父模块）无需自己的 package.json
    fi
  done

  # 4b2. manifest.json 同步校验（evolve 提案 cbda60d3，2026-09-07 处理）
  # 背景：2026-09-04 sync 核对发现 host 端插件缺 manifest.json，plugin-check /
  # mountOrder 校验全失明。v0.2 的 safe_rsync 是整目录同步、本应带上 manifest，
  # 但 agint-event-bus 仍出现过 host manifest 停在旧版（08-29）的情况——
  # 说明只靠"同步应该会带上"不够，装后必须显式校验。
  # 规则：仓库有 manifest.json 的插件，host 必须存在且与仓库一致。
  #
  # ⚠️ 2026-10-08：比较前先做 **profile 段归一化**。仓库模板里写 `profiles/web/plugins`
  #   （默认 profile），而步骤 2.6 会把部署位改写成 `profiles/$PROFILE_NAME/plugins`。
  #   直接 cmp 逐字节比 ⇒ 装到任何非 web profile 时本项**恒红**，把「正常参数化」
  #   报成「旧版残留」。归一化后只比**除 profile 段以外**的内容：任何真实漂移
  #   （版本、权限、字段增删）依旧会红。这是收紧比较口径，不是放宽校验。
  for plugin in "$PLUGINS_SRC"/agint-*/; do
    [ -f "$plugin/manifest.json" ] || continue
    name="$(basename "$plugin")"
    host_m="$PLUGINS_DST/$name/manifest.json"
    if [ ! -f "$host_m" ]; then
      warn "plugin $name 仓库有 manifest.json 但 host 缺失（plugin-check 将失明）"
      failed=$((failed+1))
    elif ! manifest_same_modulo_profile "$plugin/manifest.json" "$host_m"; then
      warn "plugin $name host manifest 与仓库不一致（profile 段之外的内容有差异，疑似旧版残留）"
      failed=$((failed+1))
    fi
  done

  # 4c. 本仓产出的 preset 含 agent.cordis.yml
  # 2026-10-26：只查 agint。子 preset（agint-blockchain / agint-investor /
  # agint-ops）已迁到 agint-presets 独立仓，完整性归那边的安装器校验 ——
  # 这里若沿用 agint-* 通配，会把别人铺进来的目录一起判成自己的，越界。
  for preset in "$PRESETS_DST"/agint; do
    [ -d "$preset" ] || continue
    name="$(basename "$preset")"
    # 跳过 .bak-* 历史备份
    case "$name" in
      *.bak-*) continue ;;
    esac
    if [ -f "$preset/agent.cordis.yml" ]; then
      log "   ✓ preset $name 有 agent.cordis.yml"
    else
      warn "preset $name 缺 agent.cordis.yml"
      failed=$((failed+1))
    fi
  done

  # 4d. **裸 import 冒烟**（2026-10-01 新增）：每个 bundle 插件真跑一次
  #     `import(<bundle>/plugins/<…>)`。
  #     为什么必须在这里：dsh 的 boot 期只会打一行
  #     `agint-memory (…): failed to import` 就继续，**不报缺哪个包**；
  #     而「装完 → 重启 → 发现 11 个插件挂了 → 才知道是 zod 解析不到」这条路
  #     要绕一整圈才知道根因。哈希一致 / YAML 合法都不等于代码能 import
  #     （K78 教训：文件一致 ≠ 代码可用）。本步把那个圈砍掉。
  #
  #     条目来源 = **bundle patch 里 `name: ./plugins/…` 的真实声明**
  #     （`^[[:space:]]*name:` 开头，注释行天然不匹配），不是 glob 目录：
  #     agint-quality-eval / -contract / -policy / -report 是 agint-quality 的
  #     **嵌套子模块**（./plugins/agint-quality/agint-quality-eval/lib/index.js），
  #     顶层 `agint-*` glob 扫不到它们。
  if command -v node >/dev/null 2>&1; then
    smoke_fail=0; smoke_n=0
    while IFS= read -r entry; do
      [ -n "$entry" ] || continue
      full="$BUNDLE_DST/${entry#./}"
      smoke_n=$((smoke_n+1))
      if [ ! -f "$full" ]; then
        warn "patch 声明的插件入口不存在：$entry"
        smoke_fail=$((smoke_fail+1)); continue
      fi
      # 2026-10-07 N9：路径改走 pathToFileURL——旧写法 'file://$full' 直接内插，
      # 含空格/特殊字符的 DSH_HOME 会碎（winpath 换算后的路径不保证无空格）。
      if ! node --input-type=module -e "await import((await import('node:url')).pathToFileURL(process.argv[1]).href)" "$full" >/dev/null 2>&1; then
        warn "插件 import 失败：$entry — $(node --input-type=module -e "await import((await import('node:url')).pathToFileURL(process.argv[1]).href)" "$full" 2>&1 | grep -oE "(Cannot find package '[^']*'|Error \[ERR_[A-Z_]+\])" | head -1)"
        smoke_fail=$((smoke_fail+1))
      fi
    done < <(grep -oE '^[[:space:]]*name:[[:space:]]*\./plugins/[^ ]*\.js' "$BUNDLE_PATCH_DST" \
             | sed -E 's/^[[:space:]]*name:[[:space:]]*//' | sort -u)
    if [ "$smoke_n" -eq 0 ]; then
      warn "未能从 bundle patch 解析出任何插件入口，冒烟未执行"
      failed=$((failed+1))
    elif [ "$smoke_fail" -gt 0 ]; then
      warn "插件 import 冒烟：$smoke_fail/$smoke_n 失败（上面已打印根因）"
      failed=$((failed+1))
    else
      log "   ✓ 插件 import 冒烟全通（$smoke_n 个声明入口）"
    fi
  else
    warn "未找到 node，跳过插件 import 冒烟"
  fi

  if [ "$failed" -gt 0 ]; then
    die "装后校验失败 $failed 项（已自动回滚）"
  fi
fi

# ── 4.5 / 4.6 已上移 ────────────────────────────────────────────────────────
# 原 4.5（zod 兜底）与 4.6（mirror 解析卫兵复跑）于 2026-10-27 上移到 **2.7 段**
# （步骤 2 同步之后、4d 冒烟之前）。原因：无 rsync 机器步骤 2 的 python 回退分支
# 整树换入会清掉这两个 bootstrap 的产物，而原 4.5/4.6 排在 4d 冒烟的 die 之后，
# 永远来不及补救 ⇒ quality 插件 import 冒烟必挂、安装必回滚。详见 2.7 段注释。

# ── 4.55 zstd bootstrap（修复 agint-dream sweep ENOENT）─────────────────────
# 背景：sweep.js 第 111 行用 `execFile('zstd', ...)` 读 session.jsonl.zstd。
# DSH 沙箱镜像（Debian / Ubuntu）按最小化原则装了 libzstd1 但跳过 zstd CLI
# （Priority: optional），sweep 每晚 ENOENT 静默失败（2026-09-12 教训）。
# 镜像层不主动装（保持精简），由本脚本在 install 阶段兜底。
# 失败仅 warn，不阻断（与 zod bootstrap 同策略）。
if [ "$DRY_RUN" != "1" ]; then
  if bash "$SCRIPT_DIR/agint-zstd-bootstrap.sh" >/dev/null 2>&1; then
    log "   ✓ zstd bootstrap OK"
  else
    warn "zstd bootstrap 失败（agint-dream nightly sweep 会 ENOENT）。手动跑：bash $SCRIPT_DIR/agint-zstd-bootstrap.sh"
  fi
else
  log "   ⊘ 跳过 zstd bootstrap（dry-run）"
fi

# ── 4.6 AGENTS.md 本机实况自动同步（evolve 提案 95d78c05 · 阶段 1）───────────
# 探测本机 host 实况（插件装载 / preset tool rows / skills / patch 段 / cron），
# 回写仓库 AGENTS.md 文末 sentinel 围栏块。失败仅 warn，不阻断安装。
if [ "$DRY_RUN" != "1" ]; then
  if command -v node >/dev/null 2>&1; then
    if node "$SCRIPT_DIR/../bin/agents-local-state.mjs"; then
      log "   ✓ AGENTS.md 本机实况已同步"
    else
      warn "AGENTS.md 本机实况同步失败（可手动跑：node bin/agents-local-state.mjs）"
    fi
  else
    warn "未找到 node，跳过 AGENTS.md 本机实况同步（手动：node bin/agents-local-state.mjs）"
  fi
else
  log "   ⊘ 跳过 AGENTS.md 本机实况同步（dry-run）"
fi

# 装成功 → 清空 partial-steps（trap 不再回滚）
PARTIAL_STEPS=()
trap - EXIT

# ── 4.7 ~~防御性补装 dsh-workflow-worker-thread~~ 已下线（2026-09-29）────
# 历史包袱：AGINT preset 曾在 2026-09-20 硬引用 @deepseek-ai/dsh-workflow-worker-thread
# （0.0.1-rc.3 发布候选，dsh 官方不携带），导致 4 个 preset 全部「加载失败」。
# 根因已修：presets/*.yml 三处全部改用 dsh 默认的 @deepseek-ai/dsh-workflow-ptc
# （stable，随 dsh 官方 deps 携带）。
#
# 本步骤原为「防御性补装旧包」的兜底，2026-09-29 下线，理由三条：
#   1. 补装对象已不存在——dsh 0.1.7-rc.2 官方 deps 只有 dsh-workflow-ptc，
#      worker-thread 是 dsh 0.0.1 时代的 RC 包，当前 dsh 不带。
#   2. preset 不再依赖它——三个 preset 引用的 ptc 走 include baseUrl 向上解析到
#      dsh 官方包，补装一个不受 dsh 版本管理的包救不了任何真实故障。
#   3. 换成 ptc 补装同样不可取——`pnpm add <pkg>` 不带版本号会拉 npm 最新版，
#      与本机 dsh 版本漂移；比留着旧引用更糟。
#
# 若日后确有插件真依赖某个 dsh 未携带的包，正确做法是带精确版本号补装
# （`pnpm add @deepseek-ai/<pkg>@<dsh同版本>`），并同步登记进 VERSION 兼容矩阵。

# 安装成功收尾：清掉回滚标记（rollback 的 rc=0 守卫已保证不会误回滚，这里是清理动作）
if [ "$DRY_RUN" != "1" ]; then
  commit_install
fi

log ""
log "✅ 安装完成"
log ""
log "下一步："
log "  1. 重启目标 profile：$PROFILE_NAME（bundle 层与 profile 层都不热更新）："
if [ "$PROFILE_NAME" = "web" ]; then
  log "       dsh web"
else
  log "       退出并重开使用 profile '$PROFILE_NAME' 的 dsh 客户端（desktop 即桌面版）"
fi
log "  2. 验证 bundle 真的被认（三步都要看）："
log "       ① profile 清单里有它：grep '@agint/host' $PROFILE_MANIFEST"
log "       ② 软链在位：ls -l $BUNDLE_LINK"
log "       ③ stderr 不出现 'skipping profile bundle \"@agint/host\"'"
log "          （出现即 bundle 层被跳过，按上文提示补 node_modules 解析入口）"
log "  3. 在浏览器里新建会话，确认 agint preset 可选、工具齐全"
log ""
log "回滚方式："
log "  install/uninstall.sh                # 全量卸载"
log "  install/uninstall.sh --restore      # 从备份选一个回滚"
