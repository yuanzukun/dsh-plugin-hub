/**
 * agint-evolve unit tests — pure findingsFromSnapshot() + buildReport().
 * Run: node --test packages/agint-evolve/test/
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { findingsFromSnapshot, buildReport } from '../lib/report.js';

const healthySnapshot = {
  collectedAt: '2026-08-17T03:45:00.000Z',
  memory: { total: 17, byType: { lesson: 8, decision: 5, preference: 1, pattern: 3 }, byLevel: { L1: 12 }, avgConfidence: 0.62 },
  wiki: { checked: 7, brokenLinks: [], contradictions: [], orphans: [], healthy: true },
  cron: { healthy: true, issues: [], jobs: [{ id: 'memory-decay' }, { id: 'wiki-lint' }, { id: 'evolve-review' }] },
  rules: { totals: { hits: 10, denies: 0, asks: 0, advisories: 10 }, fired: [], lintIssues: [] },
};

test('healthy snapshot yields a single ok finding', () => {
  const findings = findingsFromSnapshot(healthySnapshot);
  assert.equal(findings.length, 1);
  assert.equal(findings[0].level, 'ok');
  assert.equal(findings[0].key, 'all.healthy');
});

test('stale cron job surfaces as a warn finding', () => {
  const snapshot = {
    ...healthySnapshot,
    cron: {
      healthy: false,
      issues: [{ id: 'memory-decay', reason: 'overdue by 30240 min' }],
      jobs: [],
    },
  };
  const findings = findingsFromSnapshot(snapshot);
  const stale = findings.find((f) => f.key === 'cron.stale');
  assert.ok(stale, 'expected a cron.stale finding');
  assert.equal(stale.level, 'warn');
  assert.match(stale.message, /memory-decay/);
});

// 2026-11-08（提案 cdf41d63）：久未活动维度。过期通道没覆盖的那些必须单独报出来
// ——「从没跑过」的 job 只在久未活动维度里可见。
test('久未活动且未被过期通道覆盖的 job 单独报一条', () => {
  const snapshot = {
    ...healthySnapshot,
    cron: {
      healthy: true,
      issues: [],
      staleInactive: [{ id: 'never-run', reason: 'inactive for 3 days (period 1 d)' }],
      jobs: [],
    },
  };
  const findings = findingsFromSnapshot(snapshot);
  const inactive = findings.find((f) => f.key === 'cron.staleInactive');
  assert.ok(inactive, 'expected a cron.staleInactive finding');
  assert.equal(inactive.level, 'warn');
  assert.match(inactive.message, /never-run/);
});

test('两个维度都命中的 job 只报一条（不制造重复告警）', () => {
  const snapshot = {
    ...healthySnapshot,
    cron: {
      healthy: false,
      issues: [{ id: 'both', reason: 'overdue by 30240 min' }],
      staleInactive: [{ id: 'both', reason: 'inactive for 21 days (period 7 d)' }],
      jobs: [],
    },
  };
  const findings = findingsFromSnapshot(snapshot);
  assert.equal(findings.filter((f) => f.key === 'cron.stale').length, 1);
  assert.equal(findings.filter((f) => f.key === 'cron.staleInactive').length, 0, '过期通道已覆盖的不重复报');
});

test('wiki problems surface as warn/info findings', () => {
  const snapshot = {
    ...healthySnapshot,
    wiki: {
      checked: 7,
      brokenLinks: [{ from: 'a.md', target: 'b.md' }],
      contradictions: ['c.md'],
      orphans: ['d.md', 'e.md'],
      healthy: false,
    },
  };
  const findings = findingsFromSnapshot(snapshot);
  assert.equal(findings.find((f) => f.key === 'wiki.brokenLinks').level, 'warn');
  assert.equal(findings.find((f) => f.key === 'wiki.contradictions').level, 'warn');
  assert.equal(findings.find((f) => f.key === 'wiki.orphans').level, 'info');
  assert.match(findings.find((f) => f.key === 'wiki.orphans').message, /2 个/);
});

test('rule redundancy and gate blocking produce findings', () => {
  const snapshot = {
    ...healthySnapshot,
    rules: {
      totals: { hits: 10, denies: 2, asks: 1, advisories: 7 },
      fired: [],
      lintIssues: [{ ruleId: 'a', kind: 'duplicate-pattern' }],
    },
  };
  const findings = findingsFromSnapshot(snapshot);
  const lint = findings.find((f) => f.key === 'rules.lint');
  assert.equal(lint.level, 'warn');
  assert.match(lint.message, /1 个/);
  const blocked = findings.find((f) => f.key === 'rules.blocked');
  assert.equal(blocked.level, 'info');
  assert.match(blocked.message, /3\/10/);
});

test('no gate activity is reported as an info finding', () => {
  const snapshot = {
    ...healthySnapshot,
    rules: { totals: { hits: 0, denies: 0, asks: 0, advisories: 0 }, fired: [], lintIssues: [] },
  };
  const findings = findingsFromSnapshot(snapshot);
  const noActivity = findings.find((f) => f.key === 'rules.noActivity');
  assert.ok(noActivity);
  assert.equal(noActivity.level, 'info');
});

test('memory bloat and low confidence produce findings', () => {
  const bloat = findingsFromSnapshot({ ...healthySnapshot, memory: { total: 80, byType: {}, avgConfidence: 0.5 } });
  assert.equal(bloat.find((f) => f.key === 'memory.bloat').level, 'info');

  const lowConf = findingsFromSnapshot({ ...healthySnapshot, memory: { total: 5, byType: {}, avgConfidence: 0.3 } });
  assert.equal(lowConf.find((f) => f.key === 'memory.confidence').level, 'warn');
});

test('worsening count metrics produce trend warnings; adherence improvement does not', () => {
  const snapshot = {
    ...healthySnapshot,
    metrics: {
      asOf: '2026-08-17T03:45:00.000Z',
      count: 2,
      metrics: [
        { key: 'cron.staleJobs', label: '失效任务', value: 2, unit: 'count', ts: 'x', delta: 1 },       // worsening
        { key: 'rules.adherencePct', label: '遵守率', value: 90, unit: 'pct', ts: 'x', delta: 5 },      // improving
      ],
    },
  };
  const findings = findingsFromSnapshot(snapshot);
  assert.ok(findings.find((f) => f.key === 'trend.cron.staleJobs'), 'expected trend.cron.staleJobs');
  assert.ok(!findings.find((f) => f.key === 'trend.rules.adherencePct'), 'adherencePct is not a worsening trend');
});

test('buildReport renders all sections with routing rules', () => {
  const findings = findingsFromSnapshot(healthySnapshot);
  const md = buildReport({ date: '2026-08-17', snapshot: healthySnapshot, findings, notes: '本周关注门禁噪音' });
  assert.match(md, /^# 智进周复盘 2026-08-17/m);
  assert.match(md, /## 一、数据快照/);
  assert.match(md, /## 二、自动发现/);
  assert.match(md, /## 三、改进提案/);
  assert.match(md, /## 四、备注/);
  assert.match(md, /本周关注门禁噪音/);
  assert.match(md, /路由规范/);
  assert.match(md, /教训.*agint-memory/s);
  assert.match(md, /知识.*agint-wiki/s);
  assert.match(md, /\| 记忆 \|/);
  assert.match(md, /\| 规则门禁 \|/);
});

test('buildReport renders A10 eventBus rows (sync subscriptions + deadletter rate)', () => {
  const snapshot = {
    ...healthySnapshot,
    metrics: {
      asOf: '2026-08-30T00:00:00.000Z',
      count: 2,
      metrics: [
        { key: 'eventBus.syncSubscriptions', label: 'sync 订阅数', value: 1, unit: 'count', ts: 'x', delta: 0 },
        { key: 'eventBus.deadletterRate', label: '死信率', value: 1.5, unit: '', ts: 'x', delta: 0, meta: JSON.stringify({ deadletterCount: 3, publishedCount: 200 }) },
      ],
    },
  };
  const md = buildReport({ date: '2026-08-30', snapshot, findings: [], notes: '' });
  assert.match(md, /Event Bus sync 订阅数/);
  assert.match(md, /1 个（上限 3）/);
  assert.match(md, /Event Bus 死信率/);
  assert.match(md, /1\.5%/);
  assert.match(md, /死信 3 \/ 发布 200/);
});

test('buildReport handles a fully unavailable snapshot', () => {
  const findings = findingsFromSnapshot({});
  assert.equal(findings[0].key, 'all.healthy');
  const md = buildReport({ date: '2026-08-17', snapshot: {}, findings, notes: '' });
  assert.match(md, /数据源.*全部不可用/s);
});

test('buildReport always emits a 哲学对齐检查 section (v0.2 强制)', () => {
  // 设计文档承诺：每个复盘报告必须有 ## 五、哲学对齐检查 段。
  // 测试覆盖三个场景：有 notes / 无 notes / 纯空 snapshot。
  for (const opts of [
    { date: '2026-09-07', snapshot: healthySnapshot, findings: findingsFromSnapshot(healthySnapshot), notes: '本周重点' },
    { date: '2026-09-07', snapshot: healthySnapshot, findings: findingsFromSnapshot(healthySnapshot), notes: '' },
    { date: '2026-09-07', snapshot: {}, findings: findingsFromSnapshot({}), notes: '' },
  ]) {
    const md = buildReport(opts);
    assert.match(md, /## 五、哲学对齐检查/, `expected 哲学对齐检查 section in ${opts.date} (notes=${JSON.stringify(opts.notes)})`);
    // 五大锚点必须出现
    for (const anchor of ['简洁', '安全', '真实', '靠谱', '主动']) {
      assert.match(md, new RegExp(`\\*\\*${anchor}\\*\\*`), `missing anchor ${anchor}`);
    }
    // 收口结论
    assert.match(md, /收口结论/);
    // 引导文档指针
    assert.match(md, /evolution-philosophy-checkpoints\.md/);
  }
});


// ── v0.7.2（2026-09-29）：外部信号与多源输入 ───────────────────────────

const gatewaySnapshot = {
  ...healthySnapshot,
  inputGateway: {
    channelCount: 4,
    channels: [
      { channelId: 'self-observation', channelType: 'self-observation', enabled: true, counters: { fetchCount: 2, signalsEmitted: 0, signalsFiltered: 0, securityFlagged: 0, securityDropped: 0 } },
      { channelId: 'external-git', channelType: 'external', enabled: true, counters: { fetchCount: 3, signalsEmitted: 3, signalsFiltered: 0, securityFlagged: 0, securityDropped: 0 } },
      { channelId: 'adversarial', channelType: 'adversarial', enabled: true, counters: { fetchCount: 3, signalsEmitted: 0, signalsFiltered: 5, securityFlagged: 1, securityDropped: 0 } },
      { channelId: 'cross-agent', channelType: 'cross-agent', enabled: true, counters: { fetchCount: 1, signalsEmitted: 2, signalsFiltered: 0, securityFlagged: 0, securityDropped: 0 } },
    ],
    security: { action: 'flag', ruleCount: 8, checkedTypes: ['external', 'adversarial', 'cross-agent'] },
  },
};

test('findingsFromSnapshot: 长期 0 信号 channel 提示上游链空转', () => {
  const findings = findingsFromSnapshot(gatewaySnapshot);
  assert.ok(findings.find((f) => f.key === 'gateway.silent.self-observation'), 'self-observation fetched 2 次 0 信号');
  assert.ok(findings.find((f) => f.key === 'gateway.silent.adversarial'), 'adversarial fetched 3 次 0 信号');
  assert.ok(!findings.find((f) => f.key === 'gateway.silent.external-git'), 'external-git 有产出不应提示');
});

test('findingsFromSnapshot: security 命中 → warn 发现', () => {
  const findings = findingsFromSnapshot(gatewaySnapshot);
  const sec = findings.find((f) => f.key === 'gateway.security');
  assert.ok(sec, 'expected gateway.security finding');
  assert.equal(sec.level, 'warn');
  assert.match(sec.message, /命中 1 条/);
});

test('buildReport: 渲染外部信号章节（二·A）', () => {
  const md = buildReport({ date: '2026-09-29', snapshot: gatewaySnapshot, findings: [], notes: '' });
  assert.match(md, /## 二·A、外部信号与多源输入/);
  assert.match(md, /\| cross-agent \|/);
  assert.match(md, /action=flag，规则 8 条/);
  assert.match(md, /命中 1 \/ 丢 0/);
});

test('buildReport: 网关不可用 → 章节如实标注', () => {
  const md = buildReport({ date: '2026-09-29', snapshot: { ...healthySnapshot }, findings: [], notes: '' });
  assert.match(md, /## 二·A、外部信号与多源输入/);
  assert.match(md, /输入网关未挂载或不可用/);
});
