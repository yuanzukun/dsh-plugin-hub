/**
 * agint-event-bus v0.7.0 — Cordis 入口
 *
 * 对外 3 Service（设计稿 Sprint12 §A1-A3）：
 *   agint.eventBus.publish   (input | envelope) → PublishResult
 *   agint.eventBus.subscribe (Subscription + handler) → Unsubscribe
 *   agint.eventBus.inspect   (filter) → EventLogEntry[]
 *
 * 监听：tools/post-execute（占位，便于未来挂 event-bus 上 audit trace）
 *
 * 资源管理（AGENTS.md 红线 / PLUGIN-SPEC 维度 5）：
 *   - 订阅表 / ring buffer 在 dispose 时由 disposeBus 清空
 *   - 监听器 dispose 由 ctx.on 自动管理
 *   - 不持有 ambient timer；delivery 内的 setTimeoutPromise 必须 caller dispose
 *
 * 不变量：
 *   - 不主动 evaluate self；评估走 agint.qualityEval 跨插件（self-evaluation forbidden）
 *   - sync 全局上限 3（yaml constraints）；超出即抛
 */
import { publish, subscribe, inspect, inspectSummary, metricsSnapshot, subscriptionsSummary, deliveryByTopic, deliveryHistory, disposeBus } from './bus.js';
import { listDeadletters, sweepExpiredDeadletters } from './deadletter.js';
import type { EventEnvelope } from './envelope.js';
import type { EventBusContext, EventLogEntry, InspectFilter, Handler, PublishResult, Subscription, Unsubscribe } from './types.js';

const name = 'agint-event-bus';
// fix-20260904: 打破 cordis 循环依赖（与 deployed lib/index.js 同步）。
//   原 ['storageDomain', 'agint.evolution'] 与 agint-evolution-memory 互为
//   provider/consumer，导致 8 个插件永久 PENDING、dsh web 启动即抛
//   "plugin tree failed to load"。运行期 agint.evolution 仅为可选 ctx.get
//   软降级（logBuffered 影子写入），不声明为硬依赖也不影响功能。
const inject = ['storageDomain'];

/** sync 订阅硬上限（设计稿 §A2.6 + schema yaml constraints） */
export const SYNC_GLOBAL_LIMIT = 3;

/**
 * Cordis apply(ctx)。
 *
 * ctx 期望能力（host 平面提供；缺失时软降级）：
 *   - ctx.storageDomain.open({name: 'agint_event_bus'}) ⇒ {table('events') / table('deadletter') / close}
 *   - ctx.get('agint.evolution').logBuffered ⇒ 复用 EvolutionLogBuffer
 *   - ctx.get('agint.qualitySandbox').pendingReview ⇒ sync 超时降级
 *   - ctx.get('agint.metrics').inc ⇒ 健康度计数
 *   - ctx.on / ctx.effect / ctx.provide ⇒ cordis 基础
 */
function apply(ctx: any, _config: any = {}) {
  const disposers: Array<() => void> = [];

  // ── lifecycle: dispose 时清订阅表 + ring buffer ──
  ctx.effect(() => () => {
    try { disposeBus(); } catch { /* ignore */ }
    for (const d of disposers) {
      try { d(); } catch { /* ignore */ }
    }
  });

  // ── 构造 EventBusContext 适配层（连接 host 平面到模块函数） ──
  const busCtx: EventBusContext = {
    tables: {
      events: stubTable(),
      deadletter: stubTable(),
    },
    logBuffered: async (entry) => {
      const evo = typeof ctx.get === 'function' ? ctx.get('agint.evolution') : null;
      if (evo?.logBuffered) return evo.logBuffered(entry);
    },
    pendingReview: async (input) => {
      const qs = typeof ctx.get === 'function' ? ctx.get('agint.qualitySandbox') : null;
      if (qs?.pendingReview) return qs.pendingReview(input);
    },
    metrics: (key, delta) => {
      const m = typeof ctx.get === 'function' ? ctx.get('agint.metrics') : null;
      if (m?.inc) return m.inc(key, delta);
    },
  };

  // ── 打开 storageDomain（事件表 + 死信表；失败软降级为 stub） ──
  let storageHandle: { close?: () => void } | null = null;
  try {
    storageHandle = ctx.storageDomain.open({
      name: 'agint_event_bus',
      schemaVersion: 1,
      atomic: 'json',
    }) ?? null;
    if (storageHandle && typeof storageHandle === 'object') {
      // dsh-storage-domain 的真实句柄：通过 table(name) 拿 handle
      const tblEvents = (storageHandle as any).table?.('events');
      const tblDead = (storageHandle as any).table?.('deadletter');
      if (tblEvents && tblDead) {
        busCtx.tables = { events: tblEvents, deadletter: tblDead };
      }
      disposers.push(() => {
        try { storageHandle?.close?.(); } catch { /* ignore */ }
      });
    }
  } catch {
    // 软降级：保留 stub（事件仅落在内存 ring + deadletter stub；不影响契约）
  }

  // ── 死信 reaper（2026-10-07 补，与 lib/index.js 同步）────────────────────
  // 「7 天保留」此前只写 ttl 字段、全仓无消费者——纸面约定，死信表无界增长。
  // 启动清一轮 + 每 24h 一轮；ctx.effect 保证 dispose 清 timer（PLUGIN-SPEC 维度 5）。
  const DEADLETTER_SWEEP_INTERVAL_MS = 24 * 60 * 60 * 1000;
  const sweepOnce = () => {
    void sweepExpiredDeadletters(busCtx).catch(() => { });
  };
  sweepOnce();
  const sweepTimer = setInterval(sweepOnce, DEADLETTER_SWEEP_INTERVAL_MS);
  ctx.effect(() => clearInterval(sweepTimer));

  // ── 注册 3 Service ──
  ctx.provide('agint.eventBus.publish', (input: unknown): Promise<PublishResult> =>
    publish(busCtx, input as EventEnvelope | import('./envelope.js').PublishInput),
  );
  ctx.provide('agint.eventBus.subscribe', (rawSub: unknown, handler: Handler): Unsubscribe =>
    subscribe(rawSub as Subscription, handler),
  );
  ctx.provide('agint.eventBus.inspect', (filter: unknown): EventLogEntry[] =>
    inspect((filter ?? {}) as InspectFilter),
  );
  ctx.provide('agint.eventBus.inspectSummary', (filter: unknown) =>
    inspectSummary((filter ?? {}) as InspectFilter),
  );
  // Sprint 13 / s12-09 断言②：死信可查询（辅助 Service，不进 FROZEN 3 Service 列表）。
  // 运维 / 排障 / 仪表盘需要列出 DLQ 内容；底层 listDeadletters 在 v0.7.0 已实现
  // 但未挂到 ctx，本 Sprint 补齐出口。软降级：读失败返回空数组。
  ctx.provide('agint.eventBus.deadletters', async () => {
    try { return await listDeadletters(busCtx); } catch { return []; }
  });
  // 订阅 → 投递对差（评审 3.3 缺口，2026-10-04 补）：只读出口，给家族面板 v2 与
  // 排障用。此前订阅表是模块级 Map 且无查询接口，该判据只能标 unknown。
  // ⚠️ 计数只覆盖本进程生命周期（重启清零），面板须照此口径措辞，不得说「从来没有流量」。
  ctx.provide('agint.eventBus.subscriptions', () => subscriptionsSummary());
  // topic → 投递聚合（评审 3.3 缺口，2026-10-05 补）：解决面板事件链表
  // 「一行一 topic、投递列却拿不到数」的口径错位。只读出口，给家族面板 v2 与排障用。
  // ⚠️ 口径：ring 窗口内（本进程 + 最近 2000 条发布），重启清零。
  //   `ring.full === true` 时更早的投递记录已被 FIFO 淘汰，面板须照此措辞。
  ctx.provide('agint.eventBus.deliveryByTopic', () => deliveryByTopic());
  // 跨重启口径的同名聚合（评审 3.3 方案 A，2026-10-05 补）：读 events 表 ⇒ 全历史有效。
  // **但 2026-10-05 之前的存量行没有 deliveries 字段，永远补不回** —— 故每行带
  // `coverage`（full / partial / legacyOnly），legacyOnly 的投递数是 unknown 不报数。
  ctx.provide('agint.eventBus.deliveryHistory', async () => {
    try { return await deliveryHistory(busCtx); }
    catch (err) {
      return {
        generatedAt: new Date().toISOString(),
        scope: 'events-table' as const,
        state: 'error' as const,
        reason: err instanceof Error ? err.message : String((err as unknown) ?? 'unknown'),
        scanned: 0,
        withDeliveries: 0,
        legacyRows: 0,
        totals: { rows: 0, delivered: 0, deadLettered: 0, deliveryAttempts: 0 },
        topics: [],
        unknownDeliveryTopics: [],
      };
    }
  });
  // ── umbrella 键（2026-09-24 补）───────────────────────────────────────────
  // cordis 的 service store 是**扁平的**：provide('agint.eventBus.publish') 之后，
  // ctx.get('agint.eventBus') 恒为 undefined，且不报错。后果是全仓每个消费方都得
  // 自己写「先试全名、再试伞键」的回退链，漏写一处就静默降级 —— agint-mount 的
  // 10 处 mount.* 发布曾因此全部降级到 ctx.emitEvent，生产 0 条（2026-09-20 取证）。
  // 补 umbrella 键是纯加法：全名子键不动，已有回退链先试全名、命中即返回，不受影响。
  // ⚠️ 与 lib/index.js 同步维护（lib 是本文件的 tsc 产物，K78）。
  ctx.provide('agint.eventBus', {
    publish: (input: unknown): Promise<PublishResult> =>
      publish(busCtx, input as EventEnvelope | import('./envelope.js').PublishInput),
    subscribe: (rawSub: unknown, handler: Handler): Unsubscribe =>
      subscribe(rawSub as Subscription, handler),
    inspect: (filter: unknown): EventLogEntry[] => inspect((filter ?? {}) as InspectFilter),
    inspectSummary: (filter: unknown) => inspectSummary((filter ?? {}) as InspectFilter),
    deadletters: async () => {
      try { return await listDeadletters(busCtx); } catch { return []; }
    },
    metricsSnapshot: async () => metricsSnapshot(busCtx),
    subscriptions: () => subscriptionsSummary(),
    deliveryByTopic: () => deliveryByTopic(),
    deliveryHistory: async () => {
      try { return await deliveryHistory(busCtx); }
      catch (err) {
        return {
          generatedAt: new Date().toISOString(),
          scope: 'events-table' as const,
          state: 'error' as const,
          reason: err instanceof Error ? err.message : String((err as unknown) ?? 'unknown'),
          scanned: 0,
          withDeliveries: 0,
          legacyRows: 0,
          totals: { rows: 0, delivered: 0, deadLettered: 0, deliveryAttempts: 0 },
          topics: [],
          unknownDeliveryTopics: [],
        };
      }
    },
  });

  ctx.provide('agint.eventBus.metricsSnapshot', async () => {
    // A10 尾巴（Sprint 13 / s12-09 收口）：死信率分子 + 分母 + sync 订阅数。
    // 分母 publishedCount 由 bus.ts 维护 —— v0.7.0 缺失导致
    // metrics.js 的 eventBus.deadletterRate 恒为 0 或直接不 push。
    // 实现下沉到 bus.metricsSnapshot（可单测）；软降级→0。
    return metricsSnapshot(busCtx);
  });

  // 注意：不要在此注册 tools/post-execute 空监听。该事件是 waterfall：
  // 监听器必须调用 next() 并返回其结果，否则瀑布结果为 undefined，
  // dsh-tools 读取 decision.kind 时抛 "Cannot read properties of undefined
  // (reading 'kind')"，导致所有 preset 的全部工具调用失败。
  // event-bus 不消费工具结果，因此不监听该事件。
}

/** 最小 TableHandle stub（host storageDomain 不可用时兜底；smoke / 单元测试可用） */
function stubTable() {
  const m = new Map<string, unknown>();
  return {
    get: async (id: string) => m.get(id) ?? null,
    put: async (id: string, value: unknown) => { m.set(id, value); },
    delete: async (id: string) => { m.delete(id); },
    entries: () => m.entries(),
    size: async () => m.size,
  };
}

export const Config = {};
export { apply, inject, name };
