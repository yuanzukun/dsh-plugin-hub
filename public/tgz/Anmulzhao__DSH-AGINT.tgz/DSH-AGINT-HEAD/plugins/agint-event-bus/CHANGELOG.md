# Changelog — agint-event-bus

## 0.8.0 (2026-11-02) — B1：把宿主的两类事件接进总线（domain/changed + workflow/end）

**一句话**：AGINT 自称「事件总线驱动的自进化系统」，但宿主给 82 个事件我们只接了 6 个，
全是工具流水线与会话 —— **进化闭环最该看的两类信号一条没接**。本版接上其中两类。

**为什么是这两条**（不是凑数）：
- `domain/changed` —— 24 个 storage 域里任何一个被写，宿主都在**持久化确认之后**发一条
  （"emitted once per write strictly after the backend acknowledged durability"）。
  在此之前，AGINT 的派生状态（面板、self-model 快照）只能靠全量重扫或 cron 兜，
  「提案台账昨晚被谁改过」这种问题在总线上一片空白。
- `workflow/end` —— preset 已经挂了 `dsh-tool-workflow` / `dsh-workflow-ptc`，
  但工作流跑过什么从未进入总线 ⇒ trajectory / 进化记忆无法留档。

**设计约束（写死在 `lib/host-bridge.js` 头注释，改前先读）**：
| # | 约束 | 为什么 |
|---|---|---|
| H1 | 绝不阻塞宿主 | `domain/changed` 处在写路径尾部，listener 里 await 会把存储写入拖成 O(总线投递) |
| H2 | 绝不把异常抛回宿主 | 桥接一抛，某次域写入就失败 —— 这是本项目最不能犯的错。抛错一律吞掉并计数 |
| H3 | 白名单，不做全量 | 24 个域里 5 个是高频写（event_bus / metrics / input_gateway / cron / restart），全接会把总线淹掉、events 表撑爆 |
| H4 | 不携带 value | `DomainChangedPut` 带整行数据；要看内容的下游自己去读（事实 = 变了；内容 = 自取） |
| H5 | 可关 | `Config.hostBridge: false` 整体关掉。接的是**别人的**事件源，量级由宿主决定不由我们决定 |

**白名单 7 个域**（判据：写入代表「系统的实质状态变了」）：
`agint_evolve` / `agint_evolution` / `agint_self_model` / `agint_population` /
`agint_rules` / `agint_mount` / `agint_curriculum`

**产物**：
- 新 topic `input.signal.host.domain-changed` / `input.signal.host.workflow-end`，
  命名沿用 `input.signal.<频道>.<类型>`，与 C2/C3/C4/C5 同构。
- `Config` 从 `z.object({})` 变为 `{ hostBridge?: boolean }`（唯一新增字段，optional）。
- manifest `spec.cordis.events` 登记 `domain/changed` 与 `workflow/end`（原本只有 `tools/post-execute`）。

**⛔ 两个刻意不做的事**：
1. **不做节流**。节流会让计数失真，而 metrics 侧正是靠计数看「哪天突然停写」。
   用白名单控制量级，比用节流掩盖量级更诚实。
2. **不做判读**。宿主事件是事实，桥接只做格式转换。要不要因此做某事由订阅者各自决定。

**⚠️ 门禁可见性的坑（踩了并修好）**：`bin/verify-event-topics.mjs` 靠
`/topic\s*:\s*['"]…['"]/` 逐行扫源码。第一版把 publish 的 topic 写成引用 `HOST_TOPICS` 常量
⇒ 两条新主题对门禁**不可见**，门禁照样报绿（假绿，正是本项目反复被咬的形态）。
现改为字面量，并加用例钉死「常量值必须同时以 `topic: '<字面量>'` 出现在源码里」。

**顺带发现的清单漂移**：跑 `verify-event-topics.mjs --update` 时，清单被**误删 5 条**
（`input.signal.external.repo-diff` / `mount.requested` / `policy.rolledback` /
`sandbox.failed` / `skill-autocreate.rolled-back`）—— 它们代码里都还在，
只是写法不在扫描器的三种形式内。已手工补回并在清单 `note` 里留警示；
清单从 47 条增至 **58 条**（补登历史漏登 9 条 + 新增 2 条）。

**验收（2026-11-02 实跑）**：
- `node --test test/host-bridge.test.mjs` → **12/12 通过**（新文件，含 3 条 H2 红线用例）
- **阴性对照**：移除 `domain/changed` listener 体内的 catch → 测试文件整体崩（pass 0 / fail 1），
  恢复即绿 —— 证明 H2 的 catch 是必要的，不是装饰
- `node test/smoke.mjs` → 10/10
- `bin/plugin-check.sh plugins/agint-event-bus` → EXIT 0 / FAIL 0
- `node bin/check-wiring.mjs` → **PASS**（0 硬缺口；新 topic 有订阅者，未新增 NO_SUBSCRIBER）
- `node bin/verify-event-topics.mjs` → EXIT 0，「代码里所有 topic 都在事实清单中」

**部署后的两个追加修正（同日，同一批未发版；0.8.0 一并生效）**：
1. **过滤要留痕**：首版被白名单过滤时静默 return ⇒ 「没订阅上」与「订阅上了但全被过滤」
   在外部完全同形。改为首次过滤时 `inc('eventBus.hostDomainIgnored')`，让两者可区分。
2. **但留痕不能压垮观测表**：实测非白名单写入 **5.5 次/秒**，逐条 inc 会让 metrics 表
   每天涨 40 万行。改为**采样**（首次 + 每 100 次），并在注释里写清「这个数字要回答的是
   『订阅活着没有』，不是『忽略了多少条』」。
3. 顺带补上 `agint-metrics` 缺失的 `inc()`（见该插件 1.1.4）—— 没有它，上面两步全是空写。

**生产实测（部署后 25 秒内行数零增长）**：`eventBus.hostDomainIgnored` 2511 行保持不变，
总行数 3671 不变 —— 采样生效；而桥接仍在接收事件（内存计数在涨）。

---

## 0.7.3 (2026-10-05) — manifest 契约对齐代码：删 `agint.memory` 悬空声明，补两个实际取用的服务

**起因**：家族面板 0.2.4 起把「manifest 声明消费（`consumes` ∪ `optionalInject`）里、代码从不取用」
的键判为悬空声明（判据与实证见 `plugins/agint-family-panel/CHANGELOG.md` 0.2.4）。

- 删 `agint.memory`：它自 v0.7.0 骨架提交就在 optionalInject，而 `lib/index.js:73-78` 的 ctx 能力
  文档只列 `agint.evolution` / `agint.qualitySandbox` / `agint.metrics`，只字未提 memory；
  全 lib 也没有任何 memory 取用点 ⇒ 未清理的占位声明。总线是纯基础设施层
  （manifest 自述「不承载进化语义」），硬补线等于每条 envelope 双写一份记忆，无设计支撑。
- 补两个**漏声明**（方向相反的同一类错，代码取了却没写进契约）：`lib/index.js:107` 取
  `agint.qualitySandbox`（sync 超时降级 pendingReview）、`lib/index.js:112` 取 `agint.metrics`
  （健康度计数）。

**影响**：纯契约文档，无运行时代码改动。`optionalInject` 不改变本机注入行为
（agint 插件取服务一律走 `ctx.get`，关键依赖不靠 optionalInject —— 见 `lib/index.js:102` 的软降级写法）。

**另记（不顺手改）**：`package.json` 版本位是 0.7.1、`manifest.json` 是 0.7.2，本次只动 manifest
那份 → 0.7.3。两处本就不一致，留到有 TS 构建窗口时对齐；现在盲改 package.json 会把宿主自报版本带偏。

## 0.7.2 (2026-09-27) — 事件记录顶层补 topic/source + EventEnvelope zod schema 补全（提案 0f91c868 / 932486d6）

> 起因（两个提案，合并一次改）：
> ① 外部工具按 topic / source 过滤事件必须拆 `value.envelope`（envelope 才是真身）——
>    events 表 record 此前只有 `{ envelope, payloadPreview, occurredAt, traceId }`；
> ② 工具返回的 zod schema 只声明了 envelope / payloadPreview / occurredAt / traceId 4 个字段，
>    实际 envelope 含 7 个（id / topic / version / occurredAt / source / traceId / payload）——
>    调用方读 `source` 做 topic 路由会拿到 undefined。

### 改动

1. **events 表 record 顶层补 `topic` / `source` 冗余标量**（`src/bus.ts` + `lib/bus.js` 成对修改）：
   - 写入时 `topic: envelope.topic`、`source: envelope.source` —— 存储文件可直读，外部工具不再拆 envelope
   - `lib/index.js` 的 `EventRecordSchema` 声明为 **optional**（兼容存量 1155 条无此字段的记录）
   - **方案决策**：保留 hashtable 存储形状（dsh-storage-domain 的 KV 契约；改数组 = 破坏全仓存储域
     统一格式，且仓库内零按数组读取方），否决提案方案 A（改数组）/ B（补索引文件）
2. **EventEnvelope zod schema 补全**（`src/schemas.ts` + `lib/schemas.js` 成对修改）：
   - 顶层 7 required（id / topic / version / occurredAt / source / traceId / payload）+ correlationId optional，
     与 `schemas/event-bus.schema.yaml` 的 FROZEN 字面**对齐**（yaml 自 v0.7.0 起一直声明 8 字段，
     zod 落后 = schema 不一致缺陷，非契约变更 ⇒ yaml 无需改）
   - **source 改 enum 已否决**（子提案 932486d6 建议）：strict enum 会让未来任何新插件的 publish 被
     静默拒绝（accepted:false 不报错），正是本项目反复被咬的静默失败模式；改为 `KNOWN_EVENT_SOURCES`
     冻结快照清单（文档化防 typo，**非白名单**，新 source 上线往清单补一行即可）
3. 新增 `test/event-record-shape.test.mjs`（2 例）：publish 落库 record 顶层带 topic/source 且与
   envelope 交叉一致；envelope 7 字段全在（子提案关心 source/id/version 可达性）；KNOWN_EVENT_SOURCES
   导出为冻结数组。

### 验收

- `event-record-shape` 2/2 + `a9-a10` 4/4 + `event-write-visibility` 3/3 + `smoke` 10/10 +
  `t2-sync-drill` 1/1（须 cwd=仓库根）—— 合计 **20/20**，零回归。
- 兼容性：存量 1155 条无顶层 topic/source，optional schema 放行；读旧记录仍需拆 envelope
  （不回填，避免对生产存储做大规模写操作）。

### ⚠️ 注意

- `lib/index.js` 与 `src/index.ts` 存在**既有漂移**（src 还是旧版 storageDomain.open API 形态）：
  `EventRecordSchema` **只存在于 lib/index.js**，勿跑 `npm run build` 覆盖（build 会用旧 src 生成缺
  topic/source 的 schema）。本次所有改动均 **src 与 lib 成对手改**，未跑 build。
- 宿主部署位（容器 `/dsh/profiles/web`）待下一次 dsh 部署时同步仓库变更（仓库惯例）。

## 2026-09-26 — events 表写入失败不再静默

### 背景

`publish` 的顺序是「**先分发订阅者、再写 events 表**」（`src/bus.ts` 的 publish 尾部）。
写表失败此前只打一个内部 metric（`eventBus.eventWriteFailed`），**不打日志、不进快照**。

后果：事件已经在 handler 里跑过了，但 `events` 表里查不到 —— 排查时看起来像
"总线上什么都没发生"。2026-09-26 的诊断自激环正是被这层静默隐藏了很久
（`events` 表里 `diagnosis.completed` 只有 6 条，而 mutator 计数器显示收到数万次）。

### 修复

- 写表失败改为 **可见**：`console.warn`（**限流**：首条 + 每 100 条一条，避免存储风暴期刷爆日志）
- 新增计数 `eventWriteFailedCount`：经 `eventWriteFailedCounter()` 与
  `metricsSnapshot().eventWriteFailedCount` 暴露
- `disposeBus()` 一并重置该计数
- 新增 `test/event-write-visibility.test.mjs`（3 例）：告警可见 / 限流不吞计数 /
  失败**不击穿**投递与 publish 返回
- `src/bus.ts` 与 `lib/bus.js` 成对修改（本插件是 tsc 产物，只改 lib 会被下次 build 静默回退）

## 0.7.1 (2026-09-23) — topic 正则首段放宽：修一条自建成起即死的契约冲突

> 起因：预演场（影子 home + AGINT 挂载）首跑即抓到 `agint-skill-graph` 订阅失败。
> 追下去发现不是一处订阅写错，而是 **topic 命名约定与 FROZEN 正则的系统性冲突**。

### 缺陷是什么（三层，一层比一层深）

**第一层 —— 正则自身不一致。** 首段 `[a-z][a-z0-9]*`（**禁**连字符），
后续段 `[a-z][a-z0-9-]*`（**允许**连字符）。同一字段两套规则，无设计论证。

**第二层 —— 两份人类签字的契约互相冲突，从未交叉校验。**
`设计-P0-1-技能自动创建机制.md`（第 414-426 行）有**明文事件契约表**，规定 topic 名就是
`skill-autocreate.candidate-created` / `.released` / `.rolled-back` 等；而 FROZEN schema
把首段连字符判非法。⇒ 受影响的 topic 共 **17 个**：
`skill-autocreate.*`(14) + `skill-graph.updated` + `compress-guard.{blocked,checkpointed}`(2)。

**第三层 —— 静默失败，这才是它能活这么久的原因。**
- 发布侧：`bus.js` 的 `publish()` **不抛错**，校验失败只返回 `{accepted:false}`；
  而 `skill-autocreate` 的 `publishEvent` 不看返回值，一律 `return true` ⇒ **零日志**。
- 订阅侧：`validateSubscription` 抛错被启动日志淹没。
- 雪上加霜：`skill-graph` 是一次传整个 topics 数组，**1 个非法项 ⇒ 11 个 topic 全被拒**，
  连 `curator.*` / `trajectory.recorded` 等 8 个完全合法的也一起收不到。

### 决定性取证

| 证据 | 结果 |
|---|---|
| 生产存储 `agint_event_bus.json` | 941 条事件 / 12 种 topic，**`skill-autocreate`/`skill-graph`/`compress-guard` 命中数 = 0** |
| 同一存储的合法 topic | `evolution`(219) / `memory`(498) / `curator`(12) 正常落库 ⇒ 排除「存储没写」 |
| skill-autocreate 是否真跑过 | skills_root 里 **11 个自动生成的技能**（09-16~09-18）⇒ 排除「插件没跑」 |
| 12 种既有 topic 的首段 | **无一首段含连字符** ⇒ 正则不是 bug，它在正确执行 |
| 全仓非法 topic 的出现处 | 仅上述 3 个插件 + 设计稿 ⇒ 影响面收敛 |

⇒ 定性：**不是插件违反约定，而是契约冲突**；且历史落库为 0 ⇒ 改命名**无历史数据兼容负担**。

### 改动

1. **三处同步**修改 `TopicSchema.pattern` 首段 `[a-z][a-z0-9]*` → `[a-z][a-z0-9-]*`（与后续段同规则）：
   | # | 文件 | 角色 |
   |---|---|---|
   | 1 | `schemas/event-bus.schema.yaml` | **单一事实源** |
   | 2 | `src/schemas.ts` | tsc 输入 |
   | 3 | `lib/schemas.js` | 运行时真正加载的产物 |
   ⇒ **少改一处 = 修复被静默回退**：只改产物不重编译，下次 `npm run build` 会覆盖回旧正则；
   只改 src 不重编译，产物不更新（本次不重编译，避免 tsc 顺带覆盖 `lib/index.js` 等已有漂移文件）。
2. `schemas/event-bus.schema.yaml` 头部：补「变更记录」段 + 记两条新发现 ——
   ① **yaml 自述冻结「字段清单」、CHANGELOG 自述冻结「字段 + 字面正则」，两份冻结声明口径不一致**
   （今后引用冻结范围需两份都看，取更严者）；
   ② **`src/` 与 `lib/` 已存在格式级漂移**（同文件缩进不同、`lib/tools.js` 在 src 无对应源），
   属既有债务，本次只做内容同步、不动格式。
3. 未改发布/订阅调用方（`publishEvent` 不检查 `accepted` 的静默问题见「仍待修」）。

### ⚠️ L0 状态（需人工复核）

按 CHANGELOG 的冻结口径，本 pattern 属 FROZEN ⇒ 严格流程应走
「人类多签 + 7 天影子 + major 版本」。**本次按「修契约冲突缺陷」先行落地，L0 手续未补。**
理由：缺陷使 17 个 topic 自建成起 100% 失效，且放宽是**向后兼容超集**（旧合法值全部仍合法）；
版本按仓库惯例走 patch（同 `agint-skill-autocreate` 修缺陷先例），未走 major。**待老板裁定是否补流程。**

### 验收（硬证据）

- **预演场红/绿对照**（影子 home，`DSH_HOME=.dsh-probe`，不碰生产存储）：
  | 用例 | 修复前 | 修复后 |
  |---|---|---|
  | publish 线上真实 topic `skill-autocreate.candidate-created` | `accepted:false` | `accepted:true` + 磁盘 onDisk=true |
  | subscribe 那 3 个 topic | **抛错** | OK |
  | 端到端投递（handler 真收到） | 链断 | `deliveredTo:[...]` ✓ |
- **三处字面一致性校验 23/23 PASS**（新增，`D:/DSH/_probe/verify_topic_pattern_sync.mjs`）：
  yaml ≡ src ≡ lib ≡ **宿主 lib** 四处正则字面完全相同；10 个应接受的 topic 全接受、
  6 个应拒绝的（`invalid` / 大写 / 下划线 / 前后导点 / 5 段）全拒绝。
  ⇒ 这条是防「下次 build 静默回退修复」的守门。
- **生产存储零回归**：941 条 / 12 种真数据在新 pattern 下全部仍合法；非法样本 `invalid`（无段分隔符）仍非法。
- **宿主部署位冒烟 14/14 PASS**（直接 import 部署位那份字节 ＋ 生产真数据）。
- 既有测试无回归：`smoke` 10/10、`a9-a10` 4/4、`t2-sync-drill` 1/1（须 cwd=仓库根，属该脚本前提）。
- 生产存储 `storages/` 454 文件两次运行**零改动** ⇒ 预演场隔离成立。

### 仍待修

- **`publishEvent` 不检查 `accepted`** —— 校验失败静默丢弃，是本缺陷潜伏这么久的根因。
  同属 K51「可观测 > 可审批」要防的形态，应改为失败落 audit / 至少 warn。
- **`subscribe()` 全数组原子拒绝** —— 1 个非法 topic 连坐 8 个合法 topic。
  宜改为逐项校验 + 部分成功 + 明确告警。
- **落库时机竞态**（预演场顺带抓到）：`publish` 在存储表就绪前调用，`ctx.tables.events.put()`
  抛错被 `catch { }` 静默吞 ⇒ `accepted:true` 但磁盘无行（K77 同一形态）。
  **「发布成功」与「落库成功」是两件事**，需显式区分或串行化。

## 0.7.0 (2026-08-29) — Sprint 12 骨架交付

### FROZEN: EventEnvelope schema + Subscription.mode enum

> **冻结范围**（v0.7.0 发版日生效；变更走 L0 治理）：
> - `schemas/event-bus.schema.yaml` 顶层字段 + 字面正则
> - `Subscription.mode` enum: `sync | async`
> - `Subscription.reason` 仅在 `mode=sync` 时 `minLength ≥ 1`（空字符串硬抛错）

**冻结字段**（EventEnvelope 8 字段）：
- `id` — UUIDv4（总线或发布方生成）
- `topic` — 匹配 `^[a-z][a-z0-9]*(\.[a-z][a-z0-9-]*){1,3}$`
- `version` — integer ≥ 1
- `occurredAt` — ISO date-time（发布方记"事件发生"时间）
- `source` — 发布方插件名（与 cordis plugin name 对齐）
- `traceId` — 缺失时由总线生成 `crypto.randomUUID()`；同 traceId 内对同订阅者保序
- `correlationId` — 可选（关联上游事件因果链）
- `payload` — topic 自有 schema（**不冻结**；正交演进由发布方维护）

**冻结字段**（Subscription 5 字段）：
- `subscriber` — 订阅方插件名
- `topics` — array of topic（精确匹配；wildcard 留 v0.8+ 评估）
- `mode` — `sync | async`
- `reason` — 仅 sync 必填；空字符串硬抛错
- `timeoutMs` — 10000ms 默认；sync 模式超时降级 `PENDING_REVIEW`
- `retry` — `{maxAttempts: 3, backoffMs: 500}` 默认

### 新增

- 3 cordis Service（`agint.eventBus.publish` / `agint.eventBus.subscribe` / `agint.eventBus.inspect`）
- 8 个 src 模块：`envelope.ts` / `schemas.ts` / `types.ts` / `delivery.ts` / `deadletter.ts` / `observability.ts` / `bus.ts` / `index.ts`
- `RingBuffer`（2000 capacity；FIFO 淘汰）
- `deliverAsync` + `deliverSync`（指数退避封顶 8000ms）
- `recordDeadletter`（id 格式 `${envelope.id}:${sub.id}`；7 天 TTL）
- `mock EventBusContext` 测试支架
- 10 用例 smoke 覆盖 FROZEN 契约 + 多订阅者隔离 + sync 超时降级

### 全局约束（yaml `constraints`）

| 字段 | 值 | 含义 |
|---|---|---|
| `syncSubscriptionGlobalLimit` | 3 | 全系统 sync 订阅 ≤ 3（policy-boundary 专属） |
| `deadLetterRetentionMs` | 604800000 | 死信保留 7 天 |
| `ringBufferCapacity` | 2000 | inspect 内存视图上限 |

### 不变量

- mountOrder = 50（晚于 mount / 早于 audit 类）
- 存储域独占：`agint_event_bus`（不写 `agint_event_log`）
- `permissions.network = []`（不发起外部请求）
- 不持有 ambient timer（退避走 `setTimeoutPromise` + `ctx.effect` disposer）
- 不调 `agint.qualityEvaluator`（self-evaluate forbidden）

### 待办（v0.8+）

- [ ] wildcard topic 支持（`evolution.*`）
- [ ] per-trace fence（v0.7.0 简化版：FIFO 由 delivery 主循环自然实现）
- [ ] 死信衰减 / 重新入队接口
- [ ] `recordEvent` 兼容层（mount 已预留 `tools/post-execute` 占位）
