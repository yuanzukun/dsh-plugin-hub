#!/usr/bin/env node
// agint-population E2E test — `node test/e2e.mjs` 一行能跑。
//
// 5 个场景（设计稿 §十一）：
//   1) baseline + 定向变异 + 随机变异三变体端到端（Ingest → Evaluate → Select 闭环）
//   2) 变异体连续 3 周期达标 → Fixate（阶梯晋升 + hash 校验 + baseline 更新）
//   3) 变异体 safety_violation > 0 → Emergency Rollback（强制 rollback + failure_pattern）
//   4) 变异体 fitness < cull_threshold → Cull（强制 rollback + failure_pattern）
//   5) Fixate 后同 scope 变体 → FROZEN_OBSERVE → 1 世代后 Cull（冻结观察池 + 多样性保护）

import test from 'node:test';
import assert from 'node:assert/strict';

import { apply } from '../lib/index.js';
import { makeCtx } from './mock-ctx.mjs';

// ── 通用 fixture ──────────────────────────────────────────────────────

function setup(softDeps = {}) {
  const ctx = makeCtx({ softDeps });
  apply(ctx);
  return ctx;
}

function makeProposal(overrides = {}) {
  return {
    id: 'prop-' + Math.random().toString(36).slice(2, 8),
    kind: 'PROMPT_MUTATION',
    source: 'attribution-driven',
    atomicScope: 'prompt',
    payload: { promptId: 'sys', oldText: 'a', newText: 'b', diffStrategy: 'unified_diff' },
    expectedEffect: { metric: 'success_rate', direction: 'increase', window: '7d' },
    rollbackCondition: { trigger: 'regression >10% → rollback' },
    ...overrides,
  };
}

async function ingestThreeVariants(ctx) {
  // baseline-equivalent + 定向变异 + 随机变异（设计稿 §三.4）
  const baseline = await ctx._providers['agint.population.ingest']({ proposal: makeProposal({ id: 'base', source: 'attribution-driven' }) });
  const directed = await ctx._providers['agint.population.ingest']({ proposal: makeProposal({ id: 'dir', source: 'attribution-driven' }) });
  const random = await ctx._providers['agint.population.ingest']({ proposal: makeProposal({ id: 'rnd', source: 'dream-random', atomicScope: 'tool' }) });
  return { baseline, directed, random };
}

const GOOD_METRICS = { success_rate: 0.85, error_rate: 0.05, latency_p99: 5000, token_cost: 100, safety_violations: 0, user_satisfaction: 4.0, sample_count: 100 };
const BASELINE = { success_rate: 0.85, error_rate: 0.05, latency_p99: 5000, token_cost: 100 };

// ── 场景 1: 三变体端到端（Ingest → Evaluate → Promote 闭环） ─────────

test('E2E 场景1: baseline + 定向变异 + 随机变异 Ingest → Evaluate → Promote 闭环', async () => {
  const ctx = setup({ 'agint.qualityPolicy': { decide: async () => ({ decision: 'AUTO_DEPLOY' }) } });
  const { baseline, directed, random } = await ingestThreeVariants(ctx);
  assert.equal(baseline.stage, 'NEW');
  assert.equal(directed.stage, 'NEW');
  assert.equal(random.stage, 'NEW');

  // 评估：3 个都给高分
  for (const v of [baseline, directed, random]) {
    await ctx._providers['agint.population.recordEvaluation'](v.variant_id, GOOD_METRICS, BASELINE);
  }
  // 至少一个 promote 应成功
  const pr = await ctx._providers['agint.population.promote']({ variant_id: baseline.variant_id });
  assert.equal(pr.promoted, true);
  assert.equal(pr.nextStage, 'OBSERVING');

  // stats：3 个变体 + 1 active 已晋升
  const stats = await ctx._providers['agint.population.stats']();
  assert.equal(stats.counts.variants, 3);
  assert.equal(stats.active, 3);
  assert.ok(stats.byStage.OBSERVING >= 1);
});

// ── 场景 2: 连续 3 周期达标 → Fixate ──────────────────────────────

test('E2E 场景2: 阶梯晋升至 FULL + fixate(取固化凭据 + baseline 更新)', async () => {
  // 2026-10-31：原先 mock 的是 `commit: { get: fn }` —— 一个**生产里不存在**的形状
  // （mutator 的 commit 是裸函数，没有 .get 属性），于是这段「hash 校验」被喂绿了三个月。
  // 现在按真服务键 `getCommit` 造 mock，并且**记录入参**：只断言「被调用」是不够的，
  // 要断言它拿的是 proposalId（variants.commit_id 存的是 proposalId，不是 commitId）。
  const commitGetCalls = [];
  const memWrites = [];
  const ctx = setup({
    'agint.qualityPolicy': { decide: async () => ({ decision: 'AUTO_DEPLOY' }) },
    'agint.mutator': {
      getCommit: async (input) => {
        commitGetCalls.push(input);
        return { ok: true, commitId: 'c-fixate', proposalId: input.proposalId, preimageHash: 'h-fixate' };
      },
      rollback: async () => ({ ok: true, restoredHash: 'h' }),
    },
    // W3 接线（2026-10-05）：fixate 成功后落一条 decision 记忆（README 软依赖表里的 write() notify）
    'agint.memory': { write: async (input) => { memWrites.push(input); return { ...input }; } },
  });
  const v = await ctx._providers['agint.population.ingest']({ proposal: makeProposal() });
  await ctx._providers['agint.population.recordEvaluation'](v.variant_id, GOOD_METRICS, BASELINE);

  // 4 次 promote：NEW→OBSERVING→PROMOTING→EXPANDING→FULL
  for (let i = 0; i < 4; i++) {
    const r = await ctx._providers['agint.population.promote']({ variant_id: v.variant_id });
    assert.equal(r.promoted, true, `promote ${i + 1} 应成功`);
  }

  // fixate
  const fr = await ctx._providers['agint.population.fixate']({ variant_id: v.variant_id });
  assert.equal(fr.variant.stage, 'FIXED');
  assert.ok(fr.variant.fixed_at);
  assert.equal(commitGetCalls.length, 1, 'fixate 应调一次 mutator.getCommit 取固化凭据');
  assert.equal(commitGetCalls[0].proposalId, v.commit_id,
    '⭐ 必须按 proposalId 查：variants.commit_id 存的是 proposalId（ingest 早于 commit），按 commitId 查永远查不到');
  assert.equal(fr.memory.written, true, 'fixate 应调 agint.memory.write 落 notify');
  assert.equal(memWrites.length, 1, '一次固化只落一条记忆');
  assert.equal(memWrites[0].type, 'decision', '固化是决策留痕，不是 lesson/pattern');
  assert.ok(memWrites[0].content.includes(v.variant_id), 'notify 内容要能定位到被固化的变体');
  assert.ok(memWrites[0].content.includes('c-fixate'), 'notify 要带真实 commitId（⛔ 不是 preimageHash，也不是 proposalId）');
  assert.equal(memWrites[0].id, `population-fixate-${v.variant_id}`, 'id 必须稳定 ⇒ 重复固化走 write 的 upsert，不堆同义条目');
});

// 场景 2b：notify 是**事后补写**，记忆服务缺位或抛错都不许动固化结果（软降级纪律）
test('E2E 场景2b: memory 缺位 / 抛错 → 固化照常完成，memory.written=false 带原因', async () => {
  const driveToFull = async (c) => {
    const v = await c._providers['agint.population.ingest']({ proposal: makeProposal() });
    await c._providers['agint.population.recordEvaluation'](v.variant_id, GOOD_METRICS, BASELINE);
    for (let i = 0; i < 4; i++) await c._providers['agint.population.promote']({ variant_id: v.variant_id });
    return v;
  };
  const MUTATOR = {
    commit: { get: async () => ({ preimageHash: 'h-2b' }) },
    rollback: async () => ({ ok: true, restoredHash: 'h' }),
  };

  const c1 = setup({ 'agint.qualityPolicy': { decide: async () => ({ decision: 'AUTO_DEPLOY' }) }, 'agint.mutator': MUTATOR });
  const v1 = await driveToFull(c1);
  const r1 = await c1._providers['agint.population.fixate']({ variant_id: v1.variant_id });
  assert.equal(r1.variant.stage, 'FIXED', '记忆服务缺位时固化必须照常完成');
  assert.equal(r1.memory.written, false);
  assert.match(r1.memory.reason, /agint\.memory unavailable/, '缺位要写清缺的是哪项证据');

  const c2 = setup({
    'agint.qualityPolicy': { decide: async () => ({ decision: 'AUTO_DEPLOY' }) },
    'agint.mutator': MUTATOR,
    'agint.memory': { write: async () => { throw new Error('EPERM: operation not permitted, rename .tmp'); } },
  });
  const v2 = await driveToFull(c2);
  const r2 = await c2._providers['agint.population.fixate']({ variant_id: v2.variant_id });
  assert.equal(r2.variant.stage, 'FIXED', 'memory.write 抛错也不许回滚或改写固化结果');
  assert.equal(r2.memory.written, false);
  assert.match(r2.memory.reason, /memory\.write threw/, '抛错要把原因带回来，别静默吞');
});

// ── 场景 3: safety_violation > 0 → Emergency Rollback ───────────────

test('E2E 场景3: safety_violation > 0 → Emergency Rollback（强制 rollback + failure_pattern）', async () => {
  let rollbackCalled = 0;
  const fpCalls = [];
  const ctx = setup({
    'agint.qualityPolicy': { decide: async () => ({ decision: 'AUTO_DEPLOY' }) },
    'agint.mutator': { rollback: async () => { rollbackCalled++; return { ok: true, restoredHash: 'h-rb' }; } },
    'agint.evolution': { addFailure: (p) => { fpCalls.push(p); return `fp-${fpCalls.length}`; } },
  });

  const v = await ctx._providers['agint.population.ingest']({ proposal: makeProposal() });
  // 注入 safety_violation=3 → fitness=0 + safety_violations_total 增加
  await ctx._providers['agint.population.recordEvaluation'](v.variant_id, { ...GOOD_METRICS, safety_violations: 3 }, BASELINE);

  // Emergency rollback
  const r = await ctx._providers['agint.population.rollback']({ variant_id: v.variant_id, reason: 'safety_violation', trigger_detail: { count: 3 } });
  assert.equal(r.variant.stage, 'ROLLED_BACK');
  assert.equal(rollbackCalled, 1, 'D8/D11 强制 rollback 必须被调');
  assert.equal(r.variant.rolled_back_at != null, true);

  // failure_pattern 必须写入 + tag=population-rollback
  assert.equal(fpCalls.length, 1);
  assert.deepEqual(fpCalls[0].tags, ['population-rollback']);

  // 后续 promote/cull 不可流转（promote 返回 promoted=false，cull 抛错）
  const pr = await ctx._providers['agint.population.promote']({ variant_id: v.variant_id });
  assert.equal(pr.promoted, false, '终态 ROLLED_BACK 不应再 promote');
  await assert.rejects(() => ctx._providers['agint.population.cull']({ variant_id: v.variant_id }), /终态/);
});

// ── 场景 4: fitness < cull_threshold → Cull ──────────────────────────

test('E2E 场景4: fitness < cull_threshold → Cull（强制 rollback + failure_pattern tag=population-cull）', async () => {
  let rollbackCalled = 0;
  const fpCalls = [];
  const ctx = setup({
    'agint.qualityPolicy': { decide: async () => ({ decision: 'AUTO_DEPLOY' }) },
    'agint.mutator': { rollback: async () => { rollbackCalled++; return { ok: true, restoredHash: 'h-cull' }; } },
    'agint.evolution': { addFailure: (p) => { fpCalls.push(p); return `fp-${fpCalls.length}`; } },
  });

  const v = await ctx._providers['agint.population.ingest']({ proposal: makeProposal() });
  // 极低 fitness（success_rate=0.5 触发 gate<0.7 → fitness=0 < cull_threshold=0.3）
  await ctx._providers['agint.population.recordEvaluation'](v.variant_id, { ...GOOD_METRICS, success_rate: 0.50 }, BASELINE);

  const r = await ctx._providers['agint.population.cull']({ variant_id: v.variant_id, reason: 'low-fitness' });
  assert.equal(r.variant.stage, 'CULLED');
  assert.equal(r.variant.culled_at != null, true);
  assert.equal(rollbackCalled, 1, 'D11 强制 rollback');
  assert.equal(fpCalls.length, 1);
  assert.deepEqual(fpCalls[0].tags, ['population-cull']);
});

// ── 场景 5: Fixate 后同 scope 变体 → FROZEN_OBSERVE → 1 世代后 Cull ───

test('E2E 场景5: Fixate 后同 scope → FROZEN_OBSERVE → 1 世代后 Cull（冻结观察池 + 多样性保护）', async () => {
  const ctx = setup({
    'agint.qualityPolicy': { decide: async () => ({ decision: 'AUTO_DEPLOY' }) },
    'agint.mutator': {
      commit: { get: async () => ({ preimageHash: 'h-f' }) },
      rollback: async () => ({ ok: true, restoredHash: 'h' }),
    },
  });

  // 准备：2 个同 scope variant
  ctx._providers['agint.population.updateConfig']({ capacity: 3 });
  const v1 = await ctx._providers['agint.population.ingest']({ proposal: makeProposal({ id: 'f1', atomicScope: 'prompt' }) });
  const v2 = await ctx._providers['agint.population.ingest']({ proposal: makeProposal({ id: 'f2', atomicScope: 'prompt' }) });

  // 把 v1 推到 FULL：评估 + 4 promote
  await ctx._providers['agint.population.recordEvaluation'](v1.variant_id, GOOD_METRICS, BASELINE);
  for (let i = 0; i < 4; i++) await ctx._providers['agint.population.promote']({ variant_id: v1.variant_id });
  // v2 也做评估（fitness 较低，便于后续 freeze 后判定 Cull）
  await ctx._providers['agint.population.recordEvaluation'](v2.variant_id, { ...GOOD_METRICS, success_rate: 0.60 }, BASELINE);

  // fixate v1
  const fr = await ctx._providers['agint.population.fixate']({ variant_id: v1.variant_id });
  assert.equal(fr.variant.stage, 'FIXED');
  // v2 应被置 FROZEN_OBSERVE
  assert.deepEqual(fr.frozen, [v2.variant_id]);

  // 验证 stats 中 v2 stage
  const stats1 = await ctx._providers['agint.population.stats']();
  const v2s1 = stats1.variants.find((v) => v.variant_id === v2.variant_id);
  assert.equal(v2s1.stage, 'FROZEN_OBSERVE');

  // 1 世代后：fitness 0.60*0.85/0.95 = ~0.536，仍 ≥ 0.9×1.0（fixate fitness） → reingest
  // 但本测试场景验证「< 0.9×fixate → Cull」路径：手动降低 v2.fitness 让其 < 0.9
  // 简化：直接走 decideFrozenOutcome 逻辑（用 states 辅助）
  const { decideFrozenOutcome } = await import('../lib/states.js');
  const decision = decideFrozenOutcome({ stage: 'FROZEN_OBSERVE', fitness_score: 0.85 }, 1.0);
  assert.equal(decision.action, 'cull');
  // 验证 < 0.9 路径
  const decision2 = decideFrozenOutcome({ stage: 'FROZEN_OBSERVE', fitness_score: 0.95 }, 1.0);
  assert.equal(decision2.action, 'reingest');
});

// ── 总结：5 场景汇总 ──────────────────────────────────────────────

test('E2E 汇总: 5 场景全部覆盖（端到端 / Fixate / Rollback / Cull / FROZEN_OBSERVE）', () => {
  // 注：本 test 仅做语义校验，不重复测。各场景由前 5 个 test 覆盖。
  assert.ok(true);
});
