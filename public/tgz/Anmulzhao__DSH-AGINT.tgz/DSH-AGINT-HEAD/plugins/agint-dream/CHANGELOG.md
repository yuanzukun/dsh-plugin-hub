# agint-dream CHANGELOG

> 每次发版/修破坏性变更在这里追加一条目。
> 旧条目不删，加新条目在上。

---

## v0.9.0 — 2026-11-07 — 方案 C：准入从「逐字复现」改成「形态 + LLM 裁决」

**背景（实测，2026-11-07）**：梦境自 2026-10-21 起过门数持续为 0，最后一次非零提升是
2026-10-20（4 条）。量化根因（用真插件代码复跑，脚本见工作区根目录 `_dream-rem-why{,2,3}-20261107.mjs`）：

- **抽取层**：候选源只剩「用户原话 + 工具错误」。昨晚 24 个会话 → 用户原话 20 条 → 15 句 →
  12 句无关键词桶、3 句疑问；工具错误「留 0 / 拦 46」（v0.7.0 污染修复的预期行为）。
- **门槛层**：准入要求「同一句逐字复现 ≥3 次且跨 ≥2 会话」。7 天窗口 60 个会话里，
  用户原话 75 个不同句子 + assistant 主张 54 个 = 129 个，重复度几乎全是「1 次 / 1 会话」，
  够门槛的只有 **1 个** ⇒ 老门槛把候选池永久关死。
- 把窗口放宽到 7 天（候选 5 条）仍然过门 0：三条各卡 `score < 0.6` 与 `signalCount < 3`。

**变更**：

1. **`extractCandidates` 新增 assistant 正文作为第三条候选源**（补 2026-10-28 提案
   `d2b77b47` 的第 2 步「候选化」—— 第 1 步只做了统计，注释里点名的「链在中间是断的」至今未接）。
   形态判据：**祈使/规范句式**（必须/禁止/一律/切记/不要…）· 10–160 字 · 非引用块 ·
   非记忆条目形态 · 无代码骨架/路径 · 非工具回显 · 非疑问句 · **不含人称**
   （我/你/老板 —— 对话与汇报不是主张）· 非报告体（表格行/列表项/粗体）· 非状态汇报
   （已完成/收到/正在处理）；拒绝按原因计数（`shapeStats.byReason`）。
   ⛔ 判据是**实测收紧**出来的：初版用宽判据（含「以后/注意/默认/规则/先…再」）
   在真实语料上产出 43 条候选，其中大半是汇报残句（「继续核实两处口径：…」）；
   收紧到祈使句式后剩 1 条（2 天窗口）。**注意：assistant 聊天记录不是可靠的主张源**
   —— 本机真正沉淀下来的知识写在文件里（docs/、CHANGELOG、代码注释），dream 读不到。
2. **`gateCandidates` 新增 `admission` 模式**：`shape`（新，出厂默认）不按复现次数拒绝，
   复现次数退回评分权重（frequency / diversity / consolidation 本来就在算）；
   `repetition`（旧）逐字保留。准入上限 `maxGated`（默认 20）控制每轮进 LLM 的量。
3. **配置**：`admissionMode`（`shape` / `repetition`，出厂 `shape`，运行时可改 = kill-switch）
   + `maxGated`（默认 20）。
4. **可观测**：日记新增「候选来源」「assistant 形态判据」「准入」三行 —— 「候选 0 条」
   现在能拆开看是没采到、形态挡掉了，还是被上限截断了。
5. **P1 consolidation 档位不再只靠硬编码**：档位优先取宿主 `agentDefaultModel.currentSelection()`，
   取不到才用兜底常量 `DEFAULT_REASONING_EFFORT='high'`（宿主对模型没声明的档位直接抛
   `UNSUPPORTED_REASONING_EFFORT`；见 `dsh-llm-pi-ai/lib/index.js:1810-1814`）。
   同时 `stopReason != completed` 的 diagnostic 不再是空数组字符串，改成带
   `diagnostic` / `error` / `errors` / 输出摘要的分段说明。

**宿主侧配套（本机私有，不进仓）**：`profiles/desktop/cordis.patch.yml` 的
`llm-pi-ai.providers.minimax-cn.models[].reasoningEfforts` 补回声明
（minimal/low/medium/high）。不声明 ⇒ 目录里没有裸 id `MiniMax-M3.1-Flash`
（目录里的 id 都是 provider-scoped）⇒ 模型被当成非推理模型 ⇒ 支持档位只剩 off ⇒
P1 每次调用都 `stopReason=error`、`diagnostic` 为空 ⇒ 提升通道恒 0。
补上后实测：`dream_verify_consolidation` 从 `mode=failed` 变为 `mode=llm · schemaOk=true`。

**测试**：`test/admission-shape.test.js`（11 例）。负控制实测：
把 `DEFAULTS.admissionMode` 改回 `repetition` → 1 例变红；摘掉 assistant 源 → 3 例变红。
既有 198 例全部保持通过（老门槛语义的用例改为显式传 `admission: 'repetition'`）。

---

## v0.8.0 — 2026-11-07 — 阶段 2：记忆维护三件套（证据审计 / 预加载候选 / 衰减体检）

**背景**：Anthropic 博客《The components of agent memory》把 dreaming 定义为四项操作：
纠错、生成笔记、构建表示层、塑造预加载。本插件此前只做第二项。本次补「写之后」的检查。

**新增** `lib/memory-maintenance.js`（纯函数，只读）：

1. `auditMemoryEvidence`：抽出 evidence 里的仓库相对路径，逐条判存在性。
   断链只标记，不改写。⛔ 不判语义真假 —— 文本相似度不是「记忆是错的」的证据（K117/K138）。
2. `selectPreloadCandidates`：按 L1 + 未解决 + confidence ≥ 0.8 + recalls ≥ 3 选预加载候选。
   0 结果时给 `reason` 与 `nearest`（离门槛最近的一条差多少）。
3. `summarizeDecay`：层级与类型分布 + 三条红旗（recalls 全零、无一条已解决、默认置信度占多数）。

**接入**：

- `lib/sweep.js`：Deep 阶段末尾算一次维护报告，写进 diary 的「记忆维护」小节。
  ⛔ 不进 `result.counts` —— tools.js 的 output schema 是 `additionalProperties:false`，
  加键会炸工具面（K164 同形状事故）。
- `lib/index.js`：Config 加 `maintenanceEnabled` / `maintenanceRepoRoot` /
  `preloadMinConfidence` / `preloadMinRecalls` / `preloadMax`；
  `maintenanceEnabled` 进 RUNTIME_CONFIG_KEYS，可运行时关。

**实测（2026-11-07）**：生产记忆 869 条，`recalls` 869/869 全为 0，`resolved` 全 false，
confidence 0.5 占 534 条（61.4%）。⇒ 预加载候选必然为空，reason 写
`recalls-all-zero: 召回计数没在记，门槛不可能达成`。这不是「没有候选」，是「召回没通电」。

**kill-switch**：`maintenanceEnabled=false`，默认开（K51）。

**测试**：`test/memory-maintenance.test.mjs` 16 条，含负控制（门槛降到 0 必须出候选；
连字符前缀不许被截断；`.json` 不许被截成 `.js`）。

**同日修正**：首版 `PATH_RE` 有两处截断假阳性，把 5 条**路径正确**的记忆误报成断链。
① 左边界用了 `[^\w/]`，允许连字符 ⇒ `agint-quality-eval/lib/index.js` 被截成
`eval/lib/index.js`、`agent-presets/src/index.ts` 被截成 `presets/src/index.ts`；
② 扩展名 `js` 排在 `json` 前 ⇒ `.json` 被吃掉 `js`，报成 `package.js`。
改为 `[^\w/.-]` + `json` 前置后，同一份 869 行生产数据：断链 **5 → 0**，ok 42 → 47。
⛔ 未改动任何生产记忆的 evidence —— 按「改数据去迁就判据」会删掉 5 条正确路径。

## v0.7.2 — 2026-11-01 — 提升记忆写入必须带 confidence（决策确信度卡 0.61 的第二病灶）

**症状**：神谕层「决策确信度」长期 0.610（阈 0.70）判红。该指标口径是
`Σ(conf × [evidence 非空]) / N`（全库均值，`agint-aesthetic-oracle/lib/scoring.js:270`），
而 `noEvidence.count` 实测为 **0** —— 271 条全有证据，所以扣分全部来自置信度数值本身。
实测 271 条里 **195 条置信度恰好是 0.5**，其中 **48 条来自本插件**。

**根因**：`lib/validation-gate.js` 的 `planToWriteCalls()` 三条分支
（added / merged / superseded）调 `memory.write()` 时**都不传 confidence**，
`agint-memory/lib/index.js:137` 的 `input.confidence ?? 0.5` 兜底把每一条提升记忆
写成假 50% 确信。讽刺的是同文件 1267 行的 `entryFor()` 一直在按
`candidate.score` 算置信度，但 **sweep.js 里零引用** —— 算好的值从来没被用上。

**改动**：

1. `checkOperations` 的 plan 补带 `candidateScore`（取自 `candidateByKey.get(key).score`），
   让分数能流到写入层。
2. 新增 `scoreToConfidence(score)`：0..1 一位小数（与 `entryFor` 同口径）；
   **缺失/非有限时退到 0.6**（= 启发式抽取、未经充分验证档），
   ⛔ 不回 0.5 —— 0.5 正是「假装有一半把握」这个病灶本身。
3. 三条 write 分支都显式传 `confidence`。

**未做（诚实边界）**：存量 48 条的分数**无法回填**。
`storages/agint_dream_recall.jsonl` 的 `score` 字段**98 条全部是 0.0**
（`lib/recall-store.js:205` 的 `c.score ?? null`，而抽取阶段 `c.score` 就是 undefined），
拿它回填会把 48 条打成 0 分，比现在的 0.5 更失真。这批留待 recall-store 分数链修好后重算。

**验收**：
- `test/validation-gate.test.js` 22/22 通过（新增 2 例：三分支必须显式带 confidence
  且值 = 候选分数；缺分数退 0.6）。
- `test/*.test.*` 全量 182/182。

---

## v0.7.1 — 2026-10-29 — assistant 正文统计量补齐四个出口（提案 d2b77b47）

**症状**：v0.7.0 之前（2026-10-28 提案 2f91b72b / `0ac21ca`）`collectSessionSignals`
已在每条会话上挂好 `assistantStats`（messages / chars / causalSentences），但**一个出口
都没有**：日记不写、`result.counts` 不带、`tools.js` 两处 schema 不声明。10-28 23:05
实测：处理 35 个会话 / `validation=OK`，但 `dreams/2026-10-28.preview.md` 里
`grep -i assistant` 命中 **0 行** —— 数字被采到，然后被丢掉。

**改动**（四处出口 + 一处兜底，照 `sourceFilter` 的既有范式）：

1. `lib/sweep.js` 新增 `aggregateAssistantStats(signals)`：跨会话累加，并给
   `collectorFailed` 一个明确口径 —— **有会话但一条 assistant 正文都没采到 = 采集口径
   可能失效**，与「采到了但没有因果句」是相反的两种 0。
2. `renderDiary` 加 `assistantStats` 参数，日记 Light 段恒出一行（数值为 0 也出，
   否则「没采到」这件事永远看不见）。
3. `result.counts.assistant`（扁平形状：`additionalProperties:false` 下开放字典声明不了）。
4. `tools.js` 的 `dream_status` **和** `dream_run_now` 两处 output schema 都补声明 ——
   K164 同形状事故第 5 次的前科是 `dedupeStats` **只补了 run_now**。
5. `lib/index.js` 的 `counts` 兜底对象补 `assistant`（否则「还没跑过 sweep」时
   `dream_status` 过不了自己的 schema，整套工具不可用）。

**测试**：新增 `test/assistant-stats.test.mjs`（5 例）—— 累加口径、两个 0 分得开、
日记恒出一行、失效时当场喊出来、以及「两处 schema 都声明了」的源码级回归闸。
`node --test plugins/agint-dream/test/*.test.mjs` 46/46 PASS，`test/smoke.mjs` PASS。

**落地经过（供日后复盘）**：本提案由 `agint-executor` 2026-10-29 04:13 UTC 自动执行，
但 `agint-evolution-driver` 的目标解析只认出正文里**整段反引号就是一个路径**的
`plugins/agint-dream/lib/sweep.js`；第二个目标 `.../tools.js` 写在命令式反引号里
（`` grep -niE 'assistant' plugins/agint-dream/lib/tools.js ``），没被
`extractRepoPaths` 抓到 ⇒ `unitsTotal=1` ⇒ 只改一处也判 `complete=true`、提案被标
`applied`（**假完成**，scope 记账层的盲区）。上面第 2–5 项由人工补齐。

---

## v0.7.0 — 2026-10-28 — 候选池污染修复：错误信号改结构化判定 + 候选层正交判据

**症状**：2026-10-28 夜的启发式候选**9 条全是「工具执行报错：…」转录文本**，
其中若干条已以原文进了 recall store（score=0.00，躺了 2 天）。
本轮回看：recall store 226 条里，最近 9 条新增全是污染。

**取证（7 天 / 49 会话 / 1150 条 tool/result 实测，不是推测）**
1. **信号层判错**：旧判据是正文正则 `/error|failed|denied|sandbox|exit code: [1-9]|deny/i`
   ——「正文出现 error 字样就算失败」。实测命中 **243** 条，而结构化标记
   （`message.isError===true` 或 `data.error` 存在）只有 **39** 条
   ⇒ **204 条（84%）是误判**：成功的 `dream_status` / `recall_store_inspect` /
   grep 输出 / read 的 `<path>…<content>` 包装 / `ls` 输出，只要正文含 "error" 就被抓。
   **这才是污染的根** —— 大半「工具报错」根本不是错误。
2. **候选层判松**：旧判据「含因果关键词即放行」，而祈使词
   （must / should / never / always / rather than）在**工具契约类报错**里几乎必然出现
   （`Error: old_string and new_string must differ` —— must 是契约，不是处方）。
3. **产出实测**：旧链路放行的 9 条里，**0 条是主张**，100% 是转录文本
   （diff hunk / 代码 / JSON dump / 日志行 / CLI help / node --test 输出）；
   旧链路拦下的 226 条里，含中文主张措辞的 **0 条**（无误杀）。

**变更**
1. **信号层**：`classifyToolResultError()`（新导出）—— 优先看结构化字段；
   老格式没有该字段时只认**严格前缀/后缀**（`Error:` / `错误：` / `[stderr]` /
   `Traceback` / 以**非零** `exit code` 结尾）。不再看全文是否含关键词。
   ⚠️ 复算时发现自引入的坑：`exit code: 0` 是成功，早期版本写成 `-?\d+`
   把一批「[status: completed, exit code: 0]」的成功输出判成失败，已改回 `-?[1-9]\d*`。
2. **候选层正交判据**（`classifyToolError`）：每条只管一件事，逐条可被单条样本证伪：
   - `no-causal-clause` / `weak-imperative-only`：因果句式分强档（明确因果连接，
     单独够）/ 弱档（纯祈使，还要中文语境）；
   - `no-chinese-context`：必须是一句**中文**陈述（≥4 汉字）——
     口径与 `SIGNAL_RULES` 对齐：英文原话同样进不了候选池，错误路径不能比原话路径宽松；
   - `structural-symbol`：一句中文陈述里不该有 `{ } ( ) [ ] < > = |` 这些代码/日志骨架符号
     （9 条真实污染样本**每一条**都含至少一个）；
   - `transcript-shape`：形态闸（diff / file:line / 代码注释 / JSON / 日志行 / CLI help /
     `<path>` 包装）；
   - `self-pollution`：正文含「工具执行报错：」⇒ 是上一轮 sweep 的产物，自吞。
3. **提升边界闸**：`promotionBlockReason` 增加形态复判（`transcript-shape-in-stored-text`），
   判的是「真正要写进本体的那串文本」（先剥掉候选自带前缀）。
4. **可观测**：`counts.toolErrorFilter` 增加 `structured` / `legacy` 两个来源分档
   （⚠️ `tools.js` 两处 output schema 同步声明 —— `additionalProperties:false`
   漏声明会让 `dream_status` / `dream_run_now` 整体不可用，K164 同形状事故）。
   日记「工具错误信号」行也带上来源分档。
5. **口径变更（明说）**：英文因果报错不再放行
   （`Error: spawn ENOENT because …; you must create it before running`）。
   理由见上：两把尺子同口径。

**复算（同一语料，改动前后）**
| | 旧 | 新 |
|---|---|---|
| 工具错误信号 | 243 | 68（结构化 40 · 严格前缀兜底 28） |
| 进候选池 | 11 | **0** |
| 分档 | causal-clause×11 | no-causal-clause×67 · weak-imperative-only×1 |

**测试**：新增 9 条**真实语料**回归集（`TOOL_ERROR_1028_TRANSCRIPT_FIXTURES`，
逐条取自旧链路真的放进候选池的文本）+ 结构化判定正/负样本 + `exit code 0` 回归。
`node --test` 175 例全绿 + smoke 通过。
另修一条**改动前就红**的测试（`sweep-integration` deep-recovery 去重用例：
夹具的 user/message 缺 `rpcId` → 被 10-23 信号源过滤判成 subagent prompt →
该主张从未被提升，去重路径其实一直没被测到）。

## v0.6.0 — 2026-10-25 — LLM consolidation 无降级 + 接 startActivation

**背景**：宿主 `subagents` 服务只有 `startActivation`，没有 `start`。旧代码的
`typeof subagents.start !== 'function'` 恒真 ⇒ consolidation 25 天全程失败并谎报
「subagents unavailable」。同时旧策略把失败降级成「见一条推一条」，等于质量闸门敞开。

**变更**
1. `lib/consolidation.js` 改调 `subagents.startActivation({ provider, label, request,
   signal, delivery:'caller' })`；旧宿主保留 `start` 兼容分支。`request` 带
   `parent` / `prompt` / `agentPreset` / `agentOptions` / `outputSchema`。
2. **无降级**：服务缺失、方法缺失、provider 未注册、超时、stopReason 非 completed、
   structured 非法、长度不对齐、create/start/result 抛错 → 一律
   `{ ok:false, mode:'failed', operations:null, reason }`；0 条候选 →
   `{ ok:true, mode:'not-attempted' }`（内容闸门）。
3. `lib/sweep.js`：consolidation 失败 ⇒ **本轮不提升任何候选**，
   `validationFinal.ok=false`，错误进 `errors`；diary 显示 `❌ failed`。
4. 超时双保险覆盖 create/start/result；晚到的 handle/activation 也会 dispose。
5. 默认模型更新为 `MiniMax-M3.1-Flash`（-Preview 不可路由）；`reasoningEffort`
   继续强制透传（缺档位会 400）。
6. `dream_verify_consolidation` 的 `mode` 现在只会是 `llm` / `not-attempted` / `failed`。

**测试**：`node --test` 167 例全绿（含 consolidation 28 例 + 全量 sweep）。

## 未发版 · 2026-10-23 — 信号源过滤：挡住被标成 kind='user' 的 subagent prompt（提案 0f6c69bc）

**症状**：Light 通道提炼的候选里混入大量非人类消息。top 12 候选里至少 8 条
其实是主 agent 发给 subagent 的 prompt 文本，被当成「用户偏好/教训」。
这是调松 dream 阈值之前的阻塞项 —— 门槛一松，噪声直接写进长期记忆。

**根因**：宿主把 subagent prompt 也记成 kind='user'。老的
`if (kind && kind !== 'user') continue` 挡得住 plugin / skill-catalog 注入，
**挡不住它**。

**判据（先验证再写代码）**：实测 60 个会话，kind='user' 记录 163 条 ——
source 带 rpcId/clientTimeZone 的 155 条全是真人；只有 kind 的 8 条全是
subagent prompt。**文本特征判据不可用**：155 条真人里有 4 条命中「你是/你现在」
开头（误杀的是真人问句，误杀率 2.6%）。故只用 source keys，不用文本特征。

**改动**：
- 新 `classifyUserSource(rec)`：两人类标记任一存在 → human；只有 kind →
  subagent-prompt；其它 kind → other-kind（丢弃）；source 整体缺失 →
  unknown-source（**保守收**，防老格式会话整轮归零 = 4734bc97 的静默失效同型错）
- `collectSessionSignals` 按分类过滤并计数，返回 `sourceFilter`
- 新 `aggregateSourceFilterStats(signals)`：跨会话汇总，含 `judgeFailed` 判据失效标记
- 判据失效时 `console.warn` + 进 errors（宿主日志可 grep）+ 日记出一行
- `counts.sourceFilter` 扁平形状进 dream_status / dream_run_now 的 output schema
  （`additionalProperties:false` 漏声明 = 整个工具不可用，K164 已咬过四次）

**验证**：新测试 `test/user-source-filter.test.mjs` 15 条全绿（含 3 条 negative
control）；stale 为 0 的存量测试全部保持绿（48/0、5/0、12/0、3/0）。
部署位同测同绿。

---

## v0.5.0 — 工具错误判据收紧为「因果句式」+ 提升边界闸（2026-10-19）

**根因**：v0.4.0 的判据是「出现任一诊断关键词即放行」，而那批关键词
（`schema` / `invalid` / `expected` / `enoent` / `eacces`…）在真实 stderr 里
几乎必然出现 —— 判据等于没判。

**取证**（2026-10-19 03:00 夜班 sweep 日记 `dreams/2026-10-19.md`）：647 条工具
错误信号里 107 条过了闸，其中 3 条以**原文**进了长期记忆：

```
lesson/L1  工具执行报错：Error: invalid arguments: missing required property "file_path" …      ← 命中 invalid
lesson/L1  工具执行报错：[stderr] <GBK 乱码> … TerminatorExpectedAtEndOfString [exit code: 1] ← 命中 Expected
lesson/L1  工具执行报错：· DimensionScoreSchema · DreamPhaseSchema … [PASS] L0 FROZEN 契约未变更 ← 命中 schema
```

三条都不是教训，是工具机制的残骸。当晚 P1 LLM consolidation 处于
`heuristic-degraded`（subagents service unavailable），validation gate 走
「全部 added」退化路径 ⇒ 没有任何一层在挑拣，残骸直接落库。

**修复**（两道闸，职责不同）：

1. **抽取闸**（`classifyToolError`）：判据从「关键词」改为「**因果句式**」——
   文本必须出现因果连接（因为/由于/根因/because/due to…）或祈使语气
   （必须/应该/改成/must/should/instead of…）。两者都没有 ⇒ 拦下。
   - **行为变更**：旧判据放行的 schema 类报错（`rule_list` 的 additionalProperties
     不匹配）现在被拦下。它说的是「现在是什么样」，不是「应该怎样」。
   - **代价（明说）**：`EACCES: permission denied` 这类纯 syscall 报错不再进池。
     它是工具机制；要沉淀就由人 / LLM 写成主张再 `memory_write`。
2. **提升边界闸**（`promotionBlockReason`，新导出）：候选文本会被截断到
   `maxCandidateChars=220`，因果句式可能落在截断点之后 —— 于是「过了抽取闸的
   残骸」仍可能以残骸形态进本体。这道闸判的是**实际写进本体的那串文本**。
   只对工具错误来源的候选生效（用户原话天然是主张，用因果句式卡它会误杀）。
   拦截数进日记「提升边界闸拦截」行与 `counts.skippedRawToolError`（可见，不做黑洞）。

**kill-switch**：`toolErrorDiagnosticOnly=false` 时**两道闸一起让路** ——
完全回退 v0.4.0 之前的行为（全部放行），不留半死的开关。

**测试**：`test/sweep.test.js` 新增 7 条（3 条真实残骸必须拦下 / schema 类行为
变更 / 因果句式必须放行 / 边界闸单元 / 非工具错误不受约束 / kill-switch 让路 /
**端到端**：残骸不进长期记忆、因果句式照进 —— 后两条互为红绿自证）。
全量实测 **125 通过 / 0 失败**（含插件其余 7 个测试文件）。

**已知未修**：P1 LLM consolidation 仍落 `heuristic-degraded`（宿主
`subagents` service 取不到）。本次只保证「没有 LLM 挑拣时，残骸也进不去」；
LLM 通路本身是另一件事。

---

## v0.4.1 — dry-run 预览真正只读：不再覆盖当天日记、不再写 recall store（2026-09-28）

**根因**：`runSweep` 有两处副作用被 `apply` 漏掉了。

1. **日记文件名**：`apply` 与否都写 `<day>.md`。预览和真实 sweep 抢同一个文件名
   ⇒ 跑一次 `dream_run_now(apply=false)`，当天 03:01 那次真实 sweep 的日记就被
   覆盖成一份写着 `提升写入记忆：0 条` 的预览。**这是自毁证据**。
2. **recall store**：`recallStoreRecord` 在 `if (apply && ...)` 之外无条件执行。
   09-28 实测一次预览 `recall: appended=286` —— 把「没过门槛、也永远不会被
   promote」的候选混进了跨日累积池。

**取证**（2026-09-28 21:45 实跑）：
- `dreams/2026-09-28.md` 由 12648 字节（含 24 条提升明细）被换成 dry-run 版（0 条提升）；
- `dream_run_now` 输出 `recall: appended=286`。
两件事当时是靠人工备份 `.bak-before-dryrun` 兜住的 —— 事后补救不算修复。

**修复**：
- 日记路径按 `apply` 分流：真实 → `<day>.md`，预览 → `<day>.preview.md`。
  预览文件名不匹配 `^\d{4}-\d{2}-\d{2}\.md$`，因此不会被 `dream_diary` 的「取最新一篇」
  也不会被 `readLatestDiaryMtime` 误认成真实记录。
- `recallStoreRecord` 收进 `if (apply)`。读 `storeEntries` 的逻辑本来就不写，不受影响。
- `renderDiary` 新增 `apply` 参数，`!apply` 时在正文顶部打**预览声明** ——
  否则日后回看会把 `promoted=0` 的预览当成「那天一条都没提升」。

**语义**：从这版起，「预览」的定义就是不改状态。`dream_run_now` 不传 `apply`
默认仍是 `apply=false`（`Boolean(args.apply)`），行为对调用方不变。

**测试**：`test/sweep.test.js` 新增 3 条（预览声明有无、runSweep 端到端回归
—— 预置一份真实日记 + 断言它一字未动 + 断言 recall store 文件根本没被创建）。
全量实测 **125 通过 / 0 失败**，`plugin-check` 9 维度全过，`check-tool-schemas` 0 invalid。

**已知未修**：`dream_diary(date)` 读不到 `.preview.md`（需要改 dream_diary 的 schema
加 preview 参数）。预览文件路径由 `dream_run_now` 返回，可直接读盘查看。

---

## v0.4.0 — 工具错误信号不再零过滤进记忆（2026-09-28，噪音治理）

**根因**：`lib/sweep.js` 的 `extractCandidates` 里，`session.errors` 被**无条件**
`push` 成 `type:'lesson'` 候选 —— 从 Light 采集到 Deep 提升之间没有任何一道判据。
于是 `(no output) [exit code: 1]`、`Lines Chars ----- ----- 0 45`、XML 注释残片、
裸文件路径这类**输出残骸**一路走到 `memory_write`，长期记忆里躺着的「教训」是：

```
lesson/L1  工具执行报错：(no output) [exit code: 1]
lesson/L1  工具执行报错：Error: tool "rule_list" returned invalid output: ...
```

**取证**：2026-09-28 实跑后
- 梦境日记 09-28：Light 采到 **23 条工具错误信号**，REM 启发式候选 **196 条**；
- `recall_store_inspect` 抽样（默认时间倒序）**前 5 条全是**工具报错原文，
  `score=0.00`，其中 3 条 `promoted=✓`；
- `memory_search "工具执行报错"` 至少命中 2 条已进长期记忆的噪音条目。

这类候选 score 恒为 0.00，召回价值≈0，却在稀释 367 条记忆的信噪比。

**修复**：新增 `classifyToolError(text, opts)`，把「原始 stderr 不是主张」写成显式判据：

| 判定 | 规则 | 例子 |
|---|---|---|
| `noise-shape` 拦 | **形态即证据**：裸空输出 / 单侧标记残片 / 表格残片 / 纯框线 | `Lines Chars ----- ----- 0 45 [exit code: 1]` |
| `no-diagnostic-signal` 拦 | 文本里没有「为什么 / 应该怎样」线索 | `D:\DSH\...\agent.`（裸路径） |
| `diagnostic` 放行 | 命中 schema / expected / 根因 / 祈使 等诊断线索 | `rule_list ... is not a declared property (additionalProperties: false)` |

判定前先剥尾部 `[exit code: N]`（宿主追加的形态），否则它会挡住形态匹配。

**取舍**：默认**拒绝**。错杀（漏一条教训）靠下次手工 `memory_write` 补；
误放（灌原始 stderr）会永久污染记忆且稀释所有真信号 —— 代价不对称。

**接线**：
- `DEFAULTS.toolErrorDiagnosticOnly = true`（出厂即开），`Config` + `RUNTIME_CONFIG_KEYS`
  提供 kill-switch：`agint.dream.config({ toolErrorDiagnosticOnly: false })` 完全回退旧行为；
- Light / REM 强化 / Deep 恢复三处 `extractCandidates` 调用点统一过滤；
- 统计以**非枚举** `toolErrorStats` 挂数组（同 `dedupeStats` 既有约定，数组语义不变），
  `aggregateToolErrorStats` 跨会话聚合（`flatMap` 会丢非枚举属性，只能事后聚合）；
- 日记新增「工具错误诊断过滤：留 X / 拦 Y（分档）」行 —— **过滤器必须可见**，
  否则「拦了多少」无从判断，治理动作退化成看不见的黑洞；
- `result.counts.toolErrorFilter` 扁平形状透出到 `dream_status` / `dream_run_now`
  与 `dream.completed` 事件（`byReason` 开放字典在 value-schema DSL 里没法声明，故不进工具返回）。

**测试**：`test/sweep.test.js` 新增 8 条（fixture 全部取自 09-28 真实观测样本，含
kill-switch 回退与非枚举属性护栏）；`test/runtime-config.test.js` 新增 2 条
（默认值对齐 + kill-switch 可运行时回退）。改动后全量实测 **122 通过 / 0 失败**
（本次新增 10 条在内），`test/smoke.mjs` exit 0，
`plugin-check` agint-dream **0 fail**（唯一 warn 是全仓共性的 `未装 jq，跳过 manifest 深度校验`）。

---

## v0.3.4 — 修子代理空壳：梦境 LLM 整合自 09-05 起从未真跑过（2026-09-27，K114）

**根因**：`lib/consolidation.js` 建临时 parent agent 时只传了
`meta: { cwd, origin: 'subagent' }` + `agentOptions: { provider, model }`，**漏了
`meta.agentPreset`**。这个字段类型上可选，不传不报错 —— 会话照建、`label` 照写，
但 child 拿不到 preset ⇒ 解析不出模型路由 ⇒ 一步都跑不动，静默落回
`heuristic-degraded`。

**取证**：`storages/session_projcache/sessions/dream-consolidation-*.json` 共 **18 个**，
全部 `agentPreset=null` / `modelSelection=null` / `turnOutline` 空 / `surfaceTokens=0` /
`turns=0`。对比老板在 UI 手动触发、真实跑通的子代理会话（`agentPreset:"agint"`、
`minimax-cn/MiniMax-M3`、outTokens=393）—— 差异就这一个字段。

**影响**：**梦境的 LLM 整合自 2026-09-05 上线起从未真正执行过**，二十多天一直在走
启发式降级。日志与事件上完全看不出来（每次都记「跑了、没报错」）。

**修复**：

- 新增导出常量 `DEFAULT_AGENT_PRESET = 'agint'`（与 `DEFAULT_PROVIDER`/`DEFAULT_MODEL` 同级）
- `consolidate({ ..., agentPreset = DEFAULT_AGENT_PRESET })` —— 新增可选参数，换 profile 不用改源码
- `agents.create({ meta: { cwd, origin: 'subagent', agentPreset } })`
- ⚠️ 保留一处待验证标记：补 preset 后 child 是否会 join 到 preset 的工具集（原注释假定
  「无 join 即无工具」）尚未实证，若出现预期外工具调用再显式加 `toolFilter`。

**顺带修正**：`lib/sweep.js` 参数注释写「默认 deepseek / deepseek-chat」，实际不传时落
`DEFAULT_PROVIDER='minimax-cn'`（deepseek 在本机只是 fallback adapter）—— 误导性注释已改。

**测试**：`test/consolidation.test.js` 新增 2 条（缺省带 agentPreset、显式传参可覆盖），
17 → 19 全绿；dream 全量 11 个测试文件通过。

---

## v0.3.3 — output schema 补 dedupeStats / health + 一致性守卫测试（2026-09-27，提案 0f91c868 问题1）

**根因**：`lib/sweep.js` / `lib/index.js` 陆续给返回值加了 `dedupeStats`（去重统计）、`health`
（零命中健康度）字段，但 `lib/tools.js` 的 output schema 是 `additionalProperties:false` ——
漏声明一个字段，host 端整体校验失败，**整个工具不可用**（不是降级）。这正是 2026-09-11
`evolutionTemplates` 漏同步导致 `dream_status` 全挂的同一形态（教训：schema 同步的验收单位是
「每个 tool × 每个返回字段」，不是「每个新增字段」）。

**修复**（纯 schema 补声明，无行为变更）：

- `dream_run_now`：counts 补 `dedupeStats`（required，形状对齐 `lib/sweep.js` `dedupeStatsOf`，
  恒为对象不返回 null）；顶层补 `health`（required，形状对齐 `lib/health.js` `evaluateZeroHitHealth`）
- `dream_status`：顶层补 `health`（required，同形状）
- 两个工具都过 host 真实校验管线（`validateJsonSchemaValue`），不再只靠人眼对字段

**测试**：新增 `test/output-schema-conformance.test.mjs`（2 例）—— 用**真 dsh-tools 管线**
（defineTool 编译 + `validateJsonSchemaValue` 断言）分别校验 `status()` 与 `runSweep({apply:false})`
实际返回能过各自的 output schema；以后给 sweep 返回值加任何顶层 / counts 字段，先改 schema 再跑
本测试，否则这里红。

**验收**：本插件全量 **110/110 通过**（原 108 + 新 2，含 smoke / sweep / consolidation /
zero-hit-health 全绿）。

---

## v0.3.2 — 零命中告警：连续 N 次扫不到会话 → degraded（2026-09-18）

**背景（为什么光修命名还不够）**：v0.3.1 修好了会话日志命名，Light 通道恢复。
但"**扫到 0 个会话**"这件事本身**仍然不告警** —— 而它和"扫到了但没过关"在
返回里长得一模一样，`dream_status` 照样报 `validation=OK`。这正是那 7 天里
没人发现问题的同一个洞：换一种失效方式（路径改了 / 权限没了 / zstd 没了），
照样静默。

**做了什么**（新增 `lib/health.js`，改 `sweep.js` / `index.js`）：

- 判据 = 本次有没有扫到**可解析**的会话（`signals.length`），不是日志条数 ——
  文件都在但全解析失败同样是"没数据"，按条数判定会漏掉这类失效。
- 连续计数**落盘**到 `<diaryRoot>/.dream-health.json`：内存计数在进程重启时归零，
  那就永远攒不够次数，告警等于做成摆设。
- 连续 ≥ 阈值（默认 3）→ `health.status='degraded'`：
  - `result.health` 返回（机器可读）
  - `dream_status().health` 透出 —— **从当初掩盖问题的那个出口报出来**
  - dream diary 里写醒目告警块（人可读）
  - `console.warn` 打进宿主日志（可 grep）
- **不阻断** sweep（观察层，可观测优先于可审批）。
- kill-switch：`zeroHitAlert:false` 只记数不告警；`zeroHitAlertThreshold` 可调阈值。
- 读写失败一律 fail-open —— 告警链路不许把被告警的对象搞挂。

**测试**：新增 `test/zero-hit-health.test.js` 12 例（纯函数阈值边界 / kill-switch 反例 /
跨 sweep 持久化 / 落盘 / 损坏 fail-open）。全量 **85/85**（原 72 + 新 12 + 修好 smoke 1）。

**顺带修**：`test/smoke.mjs` 在 Windows 上必崩两处 —— ① `chmod` 不存在（ENOENT）；
② 假 zstd 是无扩展名 `#!/bin/sh`，Windows 不认，PATH 覆盖前提不成立。
已加平台守卫并写明原因，不是静默跳过。

---

## v0.3.1 — 会话日志改名兼容 + 补回 zstd 守卫（2026-09-17）

**背景（静默失效 7 天）**：宿主自 2026-09-10 起把会话日志命名为 `session.v3.jsonl.zstd`，
而 `lib/sweep.js` 当时只按精确名 `session.jsonl.zstd` 查找 → Light 通道连续 7 天
**扫到 0 个会话，而 `dream_status` 仍报 `validation=OK`**。既有
`test/sweep-integration.test.js` 的 fixture 恰好用旧命名，因此没能暴露。
（同类教训见 KNOWLEDGE K46.3 / K48：**查找写成精确匹配的地方，一次改名就是全量静默失效**。）

**修复**

1. `lib/sweep.js`：新增 `SESSION_LOG_NAMES`（v3 优先、旧名兜底）+ `SESSION_LOG_SUFFIX = '.jsonl.zstd'`，
   抽出 `export async function resolveSessionLogPath(wsDir, sessionDirName)` —— 候选名优先、后缀兜底，
   宿主再次改名也不会静默失效；`listSessionLogs` 改用它。
2. 新增 `test/session-log-naming.test.js`（4 例）：v3 命名 / 旧命名 / **未来改名（v9 后缀兜底）** /
   lookback 窗口过滤 / 噪声文件（`session.jsonl.dec.jsonl`、`state.json`）不被误收。

**同时补回一处被误删的守卫**

上述重构在宿主侧进行时，**连带删掉了 `isZstdAvailable()` + `zstdMissingWarned`**（zstd CLI
可用性预检与单次告警）—— 那等于回退 2026-09-12 的修复（zstd 缺失时静默产出空信号约两周）。
反向同步回仓库时已补回，由 `test/smoke.mjs` 的 happy/sad path 守着。

**同时修掉两个「红到没人管」的测试（根因见下）**

反向同步 `test/sweep.test.js` 时发现：宿主那份**被删掉了 5 个 P1 consolidation 测试**（3 个
`runSweep` + 2 个 `renderDiary`）。不是搬家（全库 grep 无对应），是**避红**——其中 1 例自
`fbfd060` 起就与实现漂移。仓库版是超集，已还原并修正确断言（不是删测试）。

1. **真实缺陷（生产代码）**：`lib/consolidation.js` 的 `await run.result` **只靠 abort 信号
   收敛**。若 provider 不认 signal（挂死的 HTTP / 卡住的适配器），该 await 永久 pending →
   **夜间 sweep 卡死、cron job 再也不结束**。`test/consolidation.test.js`「timeout 时 dispose
   仍跑（finally）」正是这个契约，**自 `fbfd060` 起一直红**——是缺陷在说话，不是测试写错。
   修法：加 `timeoutGuard`（`setTimeout → reject`，与 `lib/quality-bridge.js:169` 同款式）后
   `Promise.race([run.result, timeoutGuard])`；超时 reason 统一为可读的
   `consolidation timeout (Nms)`（进梦境日记）。`run.result` 先落地时 race 会忽略 guard 的
   后续 reject，不产生 unhandled rejection。
2. **陈旧断言 2 例**（`fbfd060` 一个 commit 带 3 个红测试上线）：
   - `consolidation.test.js` 断言默认 provider 为 `'deepseek'`，而源码常量是
     `'minimax-cn'`（源码注释本身写着「**绝对不能硬编码 'deepseek'**」）。
     **上一版 CHANGELOG 曾把这判为「本机环境问题，非本插件缺陷」——判错了**：常量是硬编码在
     源码里的，任何机器上都红，与本地 settings.yaml 无关。
     修法：把 `DEFAULT_PROVIDER` / `DEFAULT_MODEL` / `DEFAULT_TIMEOUT_MS` 导出，测试改为引用
     常量（杜绝再漂移）+ 补 1 例「显式传参可覆盖默认值」。
   - `sweep.test.js` 断言 `P1 LLM consolidation: ✅`，实际输出已加粗为
     `**P1 LLM consolidation**: ✅`（与相邻 P0 行同款式）。按实现校正。

**验收**：`plugins/agint-dream` 全套 **72/72 通过**（改动前 70/72）。
遗留的格式不一致（llm 分支加粗、heuristic-degraded 分支不加粗）**未动**——属纯观感，且会改到
真实梦境日记输出，留待拍板。

---

## v0.3.0-C4 — dream_status schema 补同步（2026-09-11，工具从「不可用」恢复）

**根因**：`lib/index.js` 的 `status()` 返回 `counts.evolutionTemplates`（v0.3 / task 3，2026-09-06 加），但 `lib/tools.js` 里 **`dream_status`** 的 output schema 漏声明该字段，而 counts 是 `additionalProperties: false` → host 端 output 校验直接报 `value.counts.evolutionTemplates is not a declared property` → **整个工具调用失败**（不是降级，是完全不可用；排查梦境状态只能绕道读 diary 文件 + cron 表）。

**为什么 09-06 没修干净**：同日 task 1 声称「dream_status schema 同步（consolidationMode/Reason + qualityEval + evolutionTemplates）✅」，实际只把 `evolutionTemplates` 加进了 **`dream_run_now`** 的 schema（tools.js:181）—— 同一插件里有**两个工具的 counts schema 需要同步**，只改了一个却按整项验收为 ✅。`复盘-2026-09-06.md:19` 的 ✅ 是假✅。

**修复**：`dream_status` 的 counts.properties 补 `evolutionTemplates: { status, count, topConfidence, boost }`，shape 与 `dream_run_now`（tools.js:181-189）及 `lib/sweep.js:1049` 完全一致。仓库 + host 副本同步，纯 schema 补声明，无行为变更。

**验证**：repo↔host 哈希一致 `2C9743DD134035E3394A55DC76136045E03B6B0F311607D0C1E7FBF5B914DC6E`；`node --check` exit 0。运行期验证需重启 dsh（host 插件非热重载）。

**教训**：schema 同步的验收单位是「**每个 tool × 每个返回字段**」，不是「每个新增字段」。同一 service 被多个工具暴露时（dream_status / dream_run_now）必须逐工具核对，漏一个就是整工具不可用；复盘报告里的 ✅ 必须附 host 实测输出，否则是假✅。

---

## v0.3.0-C3 — compositeMean 真正修复（2026-09-06，path=undefined）

**根因**（3 轮 debug 定位）：dream bridge `resolveEvalTargets` 的 `target.path` 传 `null`，但 quality-eval 的 `EvalTargetSchema` 里 `path: z.string().optional()` —— **zod .optional() 接受 undefined 但拒绝 null** → `path: null` 触发 `invalid_type` → `EvalTargetSchema.parse` 抛错 → `evaluate()` 抛错 → status='error' → compositeScore=null → compositeMean=n/a。

**修复**：`resolveEvalTargets` 不传 `path` 字段（undefined）。EvalTargetSchema 通过 + evaluate() 的 sandbox gate（`if (sandbox && ... && target.path)`）因 path undefined 跳过 → 直接走 `evaluateAll` 完整评分。

**host 验证（2026-09-06）**：`dream_run_now` 输出 `qualityEval=ok · compositeMean=71.4 · ok=9/9`；dream_diary 第 47 行 `v0.2 qualityEval: status=ok · compositeMean=71.4 · harmMean=0.5 · 评估 9 个 plugin (9 ok)`。

**已移除**：3 轮 debug 代码（debugInfo / summaryReason）——排查完成后清理干净。

**教训**：zod `.optional()` 字段传 null 会校验失败（invalid_type），应传 undefined / 不传字段。见 memory id=`e5609e0c-...`。

---

## sandbox smoke.js Windows 修复（外部依赖 bug fix，2026-09-06）

**根因**（排查 dream compositeMean=n/a 时发现）：`agint-quality-sandbox/lib/smoke.js` line 89 用 `await import(\`file://${mainPath}\`)`，Windows 下生成 `file://C:/...`（两斜杠）是无效 URL → ERR_UNSUPPORTED_ESM_URL_SCHEME → 所有 plugin import 失败 → makeSandboxRejectedResult → 只有 safety=0 维度 → compositeScore null → dream compositeMean=n/a。

**修复**：`file://${mainPath}` → `pathToFileURL(mainPath).href`（三斜杠），共 2 处（Check5 import + CLI 入口判断）。文件：`agint-quality/agint-quality-sandbox/lib/smoke.js`。

**验证**：runSmoke 对 8 个 plugin ok=true；只剩 agint-quality-contract（嵌套 monorepo 无 package.json 设计使然）。

**影响**：dream 的 qualityEval compositeScore 将能正常算出（sandbox REJECT 不再全触发）。需重启 dsh 使 smoke.js 修复生效。**在打包 agint-dream 时可能需同步 smoke.js 到 quality 子家族。**

---

## v0.3.0-B — 2026-09-06 — compositeMean 中性兜底 + status 语义修正（老板拍板 B）

**核心变更**：`quality-bridge.js` 的 `evaluatePlugin` 增加 compositeScore null 时的 B 兜底 + 修正 status 判定。

**B 兜底逻辑**（compositeScore null 时）：
- 真 safety veto（sandbox REJECT，safety.score < 0.5 或 null）→ 保留 null（诚实）
- 非 veto（safety 健康但数据源不可用）→ 给中性 50（0-100 标量）

**status 判定修正**：
- 原：`dimensions.length > 0` → ok（sandbox REJECT 只有 1 个 safety=0 维度也标 ok → 误导 ok=8/9）
- 修正：`dimensionCount >= 2 || (composite !== null && !isReject)` → ok；否则 degraded

**原因**：C3 host 验证报 `compositeMean=n/a`，根因是 quality-eval 对 9 个 plugin 的 sandbox gate 可能 REJECT（makeSandboxRejectedResult 只给 safety 维度）→ compositeScore null → compositeMean n/a。B 兜底让「数据源缺但非 veto」的 target 给中性 50，compositeMean 不再 n/a。

**文档**：插件规格 / docs 已同步 B 兜底 + status 修正。

**提案**：[78dbb9e3-...] C3 任务

---

## v0.3.0 — 2026-09-06 — Deep 阶段读 evolution success-templates（task 3）

**核心变更**：`sweep.js` Deep 阶段调 `collectEvolutionSummary()` 读 `agint.evolution.queryTemplates` 的 success-templates，作为全局 score boost（±0.02）影响候选打分。

**新增**：
- `lib/evolution-bridge.js`（新建，126 行）：evolutionPluginIds / fetchEvolutionTemplates / computeEvolutionBoost / collectEvolutionSummary
- `sweep.js` import evolution-bridge / 新参数 `evolution = true` / Deep 阶段调 collectEvolutionSummary + 应用 evolutionBoost / result.counts 加 `evolutionTemplates` 字段 / renderDiary 加 evolution 摘要段
- `sweep.js` 对 `scored` 每个 candidate 应用 `c.components.evolutionBoost`

**同步 schema**（task 1 教训）：
- `lib/tools.js` dream_run_now schema + render 加 `evolutionTemplates` 字段
- `lib/index.js` status() 兜底 counts 加 `evolutionTemplates` 字段

**映射决策**（老板 2026-09-06 拍板）：
- 映射 = A: **按 plugin id 精确匹配**（`appliesTo: ['agint-memory', ...]`）
- 前置验证 = 要：rule_check + 读 evolution-memory/lib/index.js 确认 service key `agint.evolution` + queryTemplates API

**关键前置验证结论**：
- service key：`agint.evolution`（agint-evolution-memory/lib/index.js line 332）
- API：`evo.queryTemplates({ appliesTo, query, limit })` → `[{id, template, confidence, appliesTo, sampleSize, level, ...}]`
- evolution-memory host 已挂载（cordis.patch.yml line 165-166）

**降级路径**（永不抛错，不阻断 sweep）：
- ctx 不可用 / evolution service 不可用 → `{ status: 'unavailable', reason }`
- queryTemplates 抛错 → `{ status: 'unavailable', reason: 'queryTemplates threw' }`
- 返回空模板 → `{ status: 'ok', count: 0, templates: [] }`（正常，空库）
- 任何抛错 → `errors.push(...)` + 返回 unavailable summary

**host 验证（2026-09-06）**：`dream_run_now` 输出 `evolution=ok · templates=0 · topConfidence=n/a · boost=0`；dream_diary 第48 行 `- v0.3 evolution: status=ok · templates=0· topConfidence=n/a`。`templates=0` 是 evolution 库空（周复盘蒸馏未跑），非 bug。

**语义**（重要）：
- success-templates 评估 plugin 质量（appliesTo: plugin id），不是 dream candidate——与 qualityEval 同构
- evolution 模板作为全局信号：模板多/置信度高 → 系统自进化健康 → 候选可信

**提案**：[ba3e1800-c686-45fe-8141-d20ab9e2c6fb] task 3 + [78dbb9e3-...] C3 相关

---

## v0.3.0-C3 — 2026-09-06 — C3 compositeScore 真值接入（task 2 后续）

**核心变更**：`quality-bridge.js` 的 `evaluatePlugin` 改用 `evaluator.score(result)` 拿真 composite（0-100），替代 C2 的 `safety?.score?.score` 代理。

**关键发现（纠正 C3 提案 78dbb9e3-... 的判断错误）**：
- quality-eval evaluator service 已有 `score(evalResult)` 方法（agint-quality-eval/lib/index.js line 272）——**0 行上游改动**
- dream bridge 直接 `evaluator.score(result)` 即可
- 之前 C3 提案说"必须改 quality-eval 源码暴露 service"是**错的**

**变更**：
- `lib/quality-bridge.js` `evaluatePlugin`：`compositeScore = await evaluator.score(result)`（0-100）
- `lib/sweep.js` `computeQualityBoost` 阈值：0.7→70 / 0.3→30（0-100 标量）
- `lib/sweep.js` renderDiary 精度：0.00→0.1（1 位小数对齐）
- `lib/index.js` bridgeVersion：`C3 (REM integrated; real compositeScore via evaluator.score(); 0-100 scale)`

**host 验证（2026-09-06）**：`dream_run_now` 输出 `qualityEval=degraded · compositeMean=n/a · ok=8/9`——compositeMean=n/a 是诚实 null（quality-eval 对 9 个 plugin 的 trust/reliability 等维度数据源不可用，compositeScore() 无法合成）。**老板拍板接受 n/a（不修数据源，超 task 3 scope）**。

**提案**：[78dbb9e3-...] C3 任务

**下个 commit**：拆 tools.js（410+ 行）提案 a9d3b567-... 保持 proposed

---

## v0.2.0-C2 — 2026-09-06 — REM 阶段 qualityEvaluator 实际接入（task 2 / C2）

**核心变更**：`sweep.js` REM 阶段调 `collectQualityEvalSummary()` 评估 9 个 BASELINE_TARGETS，结果作为全局 score boost（±0.02）影响候选打分。

**新增**：
- `sweep.js` import quality-bridge 的 `resolveEvalTargets` / `evaluatePlugins`
- `sweep.js` 新参数 `qualityEval = true`（默认开，false 可关闭应急回滚）
- `sweep.js` 新函数 `collectQualityEvalSummary({ ctx, enabled, errors })` —— 永不抛错，聚合 9 个 target 的 compositeScore / harmScore 均值
- `sweep.js` 新函数 `computeQualityBoost(summary)` —— compositeMean ≥ 0.7 → +0.02，≤ 0.3 → -0.02，其他 → 0
- `sweep.js` `scoreCandidates` 加 `opts.qualityEvalSummary` 参数，candidate 加 `components.qualityBoost` 字段
- `sweep.js` `result.counts` 加 `qualityEval: { status, compositeMean, harmMean, targetCount, okCount }`
- `sweep.js` `renderDiary` 加 qualityEval 摘要段（status / compositeMean / okCount）

**同步 schema**（避免 task 1 / C1 覆辙）：
- `lib/tools.js` dream_status schema 加 `qualityEval` 字段
- `lib/tools.js` dream_run_now schema 加 `qualityEval` 字段
- `lib/tools.js` dream_run_now render 加 qualityEval 行
- `lib/index.js` status() 兜底 counts 对象补 qualityEval 字段

**降级路径**（重要：qualityEvaluator 不可用时不阻断 sweep）：
- `enabled === false` → `{ status: 'unavailable', reason: 'disabled by sweep opts' }`
- ctx 不可用 / service 不可用 → `{ status: 'unavailable', reason: 'ctx unavailable' / '...' }`
- 部分 target 评估失败 → `{ status: 'degraded', compositeMean 用成功子集均值 }`
- 全部失败 → `{ status: 'unavailable' or 'degraded' }`
- 任何抛错 → `errors.push(...)` + 返回 unavailable summary

**性能**：
- 9 个 target 并发 4（bridge 默认 evaluateConcurrency）
- 单 target timeout 30s
- 评估失败不影响 sweep，sweep 总时长增量 = 「实际成功 target 评估耗时」

**已知边界**：
- `compositeScore` 在 bridge 里用 `safety?.score?.score` 作粗略代理（C1 没解析真 composite）。C2 沿用此代理，**C3 应直接调 `agint-quality-eval/lib/evaluators.js` 的 `compositeScore()` 纯函数**（同包内 import）拿真 composite。
- qualityEval boost 是**全局**（所有候选同样调整），不是 per-candidate —— 因为 qualityEval 评估的是 plugin，不是 dream candidate（参见 memory id=e7f0290e-...「真实语义」教训）

**提案**：[ba3e1800-c686-45fe-8141-d20ab9e2c6fb] task 2

**下个 commit（C3 草案）**：
- bridge `compositeScore` 改成调 quality-eval 真 compositeScore 函数
- 加 `qualityEval.test.js`：mock qualityEvaluator + 测试 4 条降级路径
- 文档：`插件规格-agint-dream.md` / `docs/plugins/agint-dream.md` 从「C1 meta only」改成「C2 部分实现（meta + REM 接入，待 C3 compositeScore 真值）」

---

## v0.2.0-C1 — 2026-09-06 — qualityEvaluator 桥接元数据（task 2 / C1）

**新增**：`lib/quality-bridge.js`（薄包装层，194 行）+ status() 透出 qualityEval bridge meta + tools.js schema 同步 qualityEval 字段。

**范围**：C1 只显示配置 + target 列表，REM 阶段实际 evaluate 调用留到 **C2**。

**关键决策**（代码注释里有详细论证）：
- Q1 (target 范围) = **A1**：所有 9 个 BASELINE_TARGETS（每次 sweep 9 次 evaluate ≈ 1-2s，简单稳定）
- Q2 (target.path) = **B3**：优先 host 副本（`$DSH_HOME/profiles/web/plugins/...`），回退 AGINT_HOME 仓路径（`$AGINT_HOME/plugins/...`）

**变更**：
- `lib/quality-bridge.js` 新建（`evaluatePlugin` / `evaluatePlugins` / `resolveEvalTargets` / `resolveTargetPath` / `toCandidateQualityField` / `getBridgeDefaults` / `DREAM_BASELINE_TARGETS` / `SELF_PLUGIN_ID`）
- `lib/index.js` status() 加 `qualityEval` 字段（`{bridgeVersion, targetsPlanned, targets, serviceKey, note, bridgeDefaults}`）
- `lib/tools.js` dream_status schema 加 `qualityEval` 字段定义（同步 schema，避免重蹈 task 1 覆辙）
- `lib/tools.js` dream_status render 多 2 行 qualityEval 透出

**降级路径**：
- ctx 不可用 → `status: 'unavailable', reason: 'ctx unavailable'`
- qualityEvaluator service 不可用 → `status: 'unavailable', reason: 'agint.qualityEvaluator service unavailable'`
- target 形状错误 → `status: 'error', reason: 'invalid target kind'` / `'missing target.id'`
- 自评约束 → `status: 'error', reason: 'self-evaluation refused'`
- 评估超时（30s）→ `status: 'error', reason: 'evaluate timeout after Xms'`
- evaluate 抛错 → `status: 'error', reason: 'evaluate threw: ...'`

**已知边界**（C2 实施前必须验证）：
- qualityEvaluator 是 Sprint 12 A1 T1 影子期（评估结果写 shadow ring buffer，不进 model 工具）—— 当前 host 端可能在跑 shadow 模式，evaluate() 拿到的是 shadow snapshot 还是真 EvalResult 以 host 实际为准。C2 接 REM 时必先实测 `dream_status` 输出是否能看到真实 qualityEval.targets 列表（确认 service 装载），再决定是否调 evaluate。
- `compositeScore` 在 C1 里用 `safety?.score?.score` 作粗略代理（C1 没解析真 composite）—— quality-eval 没暴露 `compositeScore` service，**C2 应直接调 `agint-quality-eval/lib/evaluators.js` 的 `compositeScore()` 纯函数**（同包内 import OK；不跨插件 import）。
- `harmScore` 是 4 维平均（homogeneity/alignment/reduction/mutability）—— C2 可改为加权或保留平均。

**提案**：[ba3e1800-c686-45fe-8141-d20ab9e2c6fb] task 2

**下一个 commit（C2 草案）**：
- sweep.js REM 阶段调 `evaluatePlugins(ctx, resolveEvalTargets())`，把结果写入 `candidate.qualityEval` 字段
- dream_diary render 加「REM 阶段 qualityEval 摘要」段落
- 测试：mock qualityEvaluator + 429 / service-unavailable 降级路径
- 文档：`插件规格-agint-dream.md` / `docs/plugins/agint-dream.md` 从「v0.2 计划」改成「v0.2 部分实现（C1 meta only，REM 接入留 C2）」

---

## v0.1.1 — 2026-09-06 — schema 同步补丁

**修复**：dream_status 输出 schema 与 sweep.js 返回值不同步。
- 现象：调 `dream_status` 报 `counts.consolidationMode / consolidationReason is not a declared property`（additionalProperties: false 严格校验）。
- 根因：Sprint13（2026-09-05）P1 LLM consolidation 上线时，sweep.js result.counts 加了 `consolidationMode` / `consolidationReason` 字段，但 `lib/tools.js` dream_status 输出 schema 与 `lib/index.js` status() 兜底对象都忘了同步——典型「服务方法返回值改 schema 没同步」坑。
- 修复：
  - `lib/tools.js` dream_status schema `counts.properties` 补两个字段（consolidationMode: string, consolidationReason: string|null）
  - `lib/tools.js` dream_status render 多一行 `consolidation=... · validation=...`
  - `lib/index.js` status() 兜底 counts 对象补两个字段（`consolidationMode: 'n/a', consolidationReason: null`）
- **2026-09-06 host 验证 OK**：老板按 `bin/restart-runbook.ps1` 重启 dsh web，`dream_status` 不再报 `counts.consolidationMode / consolidationReason is not a declared property`，render 输出多一行 `consolidation=... · validation=...`。
- 提案：[ba3e1800-c686-45fe-8141-d20ab9e2c6fb] task 1
- 教训：AGINT 已有 lesson `agint-tools-additionalProperties-strict-schema`，v0.1 收口后再次踩中——**任何 sweep.js / service 方法返回值字段变更，必须同步 preset tools.js 的 schema + render + 兜底对象**。下个 sprint 应自动检查。

---

## v0.1.0 — 2026-09-05 — Sprint13 收口

**特性**（P0/P1/P2 三方向）：
- **P0**：Validation Gate + Loss Fraction Budget（`lib/validation-gate.js`）—— 写 agint.memory 前强校验 loss fraction ≤ 0.25 + lineageKey + 1 candidate → 1 operation
- **P1**：LLM Consolidation（`lib/consolidation.js` + `lib/verify.js`）—— sweep 主体插入 consolidation（gate → unpromoted filter → consolidation → validation），用 `ctx.agents.create({meta:{cwd,origin:'subagent'}})` + `ctx.subagents.start('spawn', {outputSchema})` 调 LLM 决策 add/merge/supersede；8 条退化路径永不抛错
- **P2**：Short-Term Recall Store（`lib/recall-store.js`）—— JSONL append-only 跨 sweep 累积 + dedupe + 30 天剪枝 + markPromoted；inspection tool `recall_store_inspect` 支持 key/type/since/until/limit/json 6 参数

**新工具**：5 个 preset model tool（`dream_status` / `dream_run_now` / `dream_diary` / `recall_store_inspect` / `dream_verify_consolidation`）

**事件**：`dream.completed`（Sprint12 T1 影子期）+ `dream.rejected`（P0 校验失败）

**断电恢复**：`lastSweep` 从 on-disk diary mtime fallback，counts 老实为 0

**测试**：5 个文件（`sweep.test.js` / `validation-gate.test.js` / `recall-store.test.js` / `consolidation.test.js` / `sweep-integration.test.js` / `dream-completed-publish.test.mjs`）

**已知 gap（v0.1.0 不包含，待未来 sprint）**：
- **v0.2** REM 阶段调 `agint.qualityEvaluator` 评估候选 Plugin/Skill + HARM 简版计算（提案 ba3e1800-... task 2）
- **v0.3** Deep 阶段读 `agint_evolution/success-templates` 作为评分参考 + 归档 evaluation summaries（提案 ba3e1800-... task 3）
- **运行时常态断层**：当前 sweep 跑成 `heuristic-degraded` 因 LLM 429 Token Plan 用量上限（详见 `wiki/参考-openclaw-dreaming实现.md` §7）

---

## 更早

v0.0.x 早期版本无 CHANGELOG 记录（host service 初装，含 dream_status/dream_run_now/dream_diary 三件）。