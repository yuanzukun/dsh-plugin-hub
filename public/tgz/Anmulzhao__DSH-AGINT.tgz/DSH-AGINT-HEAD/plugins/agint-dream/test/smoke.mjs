#!/usr/bin/env node
/**
 * agint-dream smoke test (v0.3.0-C4 zstd contract validation).
 *
 * covers three layers required by plugin-preflight:
 *   1. import: sweep.js loads cleanly, key exports present
 *   2. contract: readSessionLog reads a real zstd-compressed session file
 *   3. fallback: when zstd CLI is missing, the new isZstdAvailable() guard
 *      surfaces a friendly error instead of letting execFile ENOENT for
 *      every single session (the 2026-09-12 silent-failure root cause).
 *
 * Exit 0 = pass. Exit non-zero = smoke FAILED.
 *
 * Run: node plugins/agint-dream/test/smoke.mjs
 */
import { strict as assert } from 'node:assert';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

import {
  readSessionLog,
  collectSessionSignals,
  extractCandidates,
  scoreCandidates,
  gateCandidates,
  renderDiary,
  runSweep,
  DEFAULTS,
  listSessionLogs,
} from '../lib/sweep.js';

console.log('[smoke] module=agint-dream');

// ── 1. import ────────────────────────────────────────────────────────────
assert.equal(typeof readSessionLog, 'function', 'readSessionLog must be a function');
assert.equal(typeof collectSessionSignals, 'function', 'collectSessionSignals must be a function');
assert.equal(typeof extractCandidates, 'function', 'extractCandidates must be a function');
assert.equal(typeof scoreCandidates, 'function', 'scoreCandidates must be a function');
assert.equal(typeof gateCandidates, 'function', 'gateCandidates must be a function');
assert.equal(typeof renderDiary, 'function', 'renderDiary must be a function');
assert.equal(typeof runSweep, 'function', 'runSweep must be a function');
assert.equal(typeof listSessionLogs, 'function', 'listSessionLogs must be a function');
assert.ok(DEFAULTS && typeof DEFAULTS === 'object', 'DEFAULTS must be exported');
// 2026-09-18 recalibration: 0.75 was OpenClaw-aligned but unreachable on this
// host (no retrieval relevance / phaseBoost; observed range 0.483~0.608).
assert.equal(DEFAULTS.minScore, 0.6, 'minScore should default to 0.6 (2026-09-18 recalibration)');
assert.equal(DEFAULTS.minRecall, 3, 'minRecall should default to 3');
assert.equal(DEFAULTS.minUniqueSessions, 2, 'minUniqueSessions should default to 2');
console.log('[smoke] import ✓ (8 functions + DEFAULTS exported)');

// ── 2. contract: real zstd session read ──────────────────────────────────
// Find at least one real session.jsonl.zstd under /dsh/sessions (the AGINT
// canonical location). If none exist, fall back to a synthesized .zstd
// fixture so the smoke is deterministic and not host-state dependent.
import { execFileSync as _efs } from 'node:child_process';
import { mkdtempSync, writeFileSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { readdirSync, statSync } from 'node:fs';

function findRealSession() {
  const root = '/dsh/sessions';
  try {
    const workspaces = readdirSync(root);
    for (const ws of workspaces) {
      const wsDir = join(root, ws);
      try {
        const sessions = readdirSync(wsDir);
        for (const sid of sessions) {
          const candidates = [
            join(wsDir, sid, 'session.jsonl.zstd'),
            join(wsDir, sid, 'session.v3.jsonl.zstd'),
          ];
          for (const c of candidates) {
            try {
              if (statSync(c).isFile()) return c;
            } catch {}
          }
        }
      } catch {}
    }
  } catch {}
  return null;
}

function makeFixture() {
  const dir = mkdtempSync(join(tmpdir(), 'agint-dream-smoke-'));
  const jsonlPath = join(dir, 'session.jsonl');
  const zstdPath = join(dir, 'session.jsonl.zstd');
  const records = [
    { type: 'session', id: 'smoke-fixture-001', createdAt: Date.now() },
    { type: 'user', seq: 0, text: '我喜欢简洁的代码风格' },
    { type: 'assistant', seq: 1, text: '收到，按 OpenClaw 风格走。' },
    { type: 'tool_use', seq: 2, name: 'memory_write' },
  ];
  writeFileSync(jsonlPath, records.map((r) => JSON.stringify(r)).join('\n') + '\n');
  _efs('zstd', ['-q', '-f', jsonlPath, '-o', zstdPath], { stdio: 'ignore' });
  return { dir, zstdPath, records };
}

let fixtureDir = null;
let sessionPath;
const realSession = findRealSession();
if (realSession) {
  sessionPath = realSession;
  console.log(`[smoke] using real session: ${sessionPath.slice(0, 60)}...`);
} else {
  const fx = makeFixture();
  fixtureDir = fx.dir;
  sessionPath = fx.zstdPath;
  console.log(`[smoke] using synthesized fixture: ${sessionPath}`);
}

try {
  const records = await readSessionLog(sessionPath);
  assert.ok(Array.isArray(records), 'readSessionLog must return an array');
  assert.ok(records.length > 0, 'must parse at least 1 record');
  // Every parsed record should be an object with a type field
  for (const r of records.slice(0, 5)) {
    assert.equal(typeof r, 'object', 'each record must be an object');
    assert.ok(typeof r.type === 'string', `each record must have a type string (got ${JSON.stringify(r).slice(0, 80)})`);
  }
  console.log(`[smoke] readSessionLog ✓ (${records.length} records parsed)`);
} finally {
  if (fixtureDir) {
    try { rmSync(fixtureDir, { recursive: true, force: true }); } catch {}
  }
}

// ── 3. fallback: isZstdAvailable() guard ────────────────────────────────
// Tests both branches of the 2026-09-12 contract:
//   - happy path: zstd CLI present → isZstdAvailable() === true
//   - sad path:  zstd CLI missing   → isZstdAvailable() === false,
//                                   AND readSessionLog() throws the
//                                   friendly bootstrap-script error
//                                   (NOT the raw ENOENT we saw for 2 weeks).
//
// We can't actually delete /usr/bin/zstd (root-owned), so the sad path
// runs in a child Node process with a stripped PATH.
import { isZstdAvailable } from '../lib/sweep.js';

// 3a. happy path
assert.equal(isZstdAvailable(), true, 'isZstdAvailable() should be true when zstd is in PATH');
console.log('[smoke] isZstdAvailable() === true ✓');

// 3b. sad path: child process with PATH that has no zstd
//
// Trick: we can't actually delete /usr/bin/zstd (root-owned), and we can't
// strip PATH too aggressively or node loses access to its own internal
// modules. So we:
//   1. Write a fake `zstd` (always-exit-1) to a temp dir
//   2. Put that temp dir FIRST in PATH (so command -v zstd resolves to it)
//   3. Also remove the real /usr/bin and /usr/local/bin from PATH
//   4. Invoke a probe script via absolute node path (so PATH-stripping doesn't
//      kill node itself)
const fakeZstdDir = mkdtempSync(join(tmpdir(), 'agint-dream-nozstd-'));
const probePath = join(fakeZstdDir, '_probe.mjs');
try {
  writeFileSync(join(fakeZstdDir, 'zstd'), '#!/bin/sh\nexit 1\n');
  // Windows 没有 chmod（也没有 shebang 执行位概念）：跳过这步，否则 execFileSync
  // 直接 ENOENT 把整个 smoke 炸掉（2026-09-18 实测）。本用例测的是"zstd 存在但
  // 执行失败"，在 Windows 上靠 PATH 顺序已经能命中假 zstd。
  if (process.platform !== 'win32') {
    _efs('chmod', ['+x', join(fakeZstdDir, 'zstd')], { stdio: 'ignore' });
  }
  // Compute the absolute path to sweep.js BEFORE writing probe, so the
  // probe's `import` resolves correctly regardless of where probePath lives.
  const sweepAbsPath = new URL('../lib/sweep.js', import.meta.url).pathname;
  writeFileSync(probePath, `
import { isZstdAvailable, readSessionLog } from ${JSON.stringify(sweepAbsPath)};
const has = isZstdAvailable();
console.log('IS_AVAILABLE:', has);
try {
  await readSessionLog('/tmp/nonexistent.jsonl.zstd');
  console.log('NO_ERROR_THROWN');
  process.exit(2);
} catch (e) {
  console.log('CAUGHT:', e.message);
  process.exit(0);
}
`);

  const filtered = process.env.PATH.split(':')
    .filter((p) => p !== '/usr/bin' && p !== '/usr/local/bin');
  const newPath = [fakeZstdDir, ...filtered].join(':');

  let probeStdout = '';
  let probeStderr = '';
  try {
    // execFileSync returns the stdout Buffer/string directly (not an object
    // with .stdout/.stderr fields). To get stderr separately we need
    // stdio: ['ignore', 'pipe', 'pipe'] AND we use the throw variant.
    const stdoutBuf = _efs(process.execPath, [probePath], {
      env: { ...process.env, PATH: newPath },
      stdio: ['ignore', 'pipe', 'pipe'],
      encoding: 'utf8',
    });
    probeStdout = stdoutBuf || '';
  } catch (e) {
    // If the probe exits non-zero, stdout/stderr live on the error object.
    probeStdout = (e.stdout?.toString('utf8') || '').toString();
    probeStderr = (e.stderr?.toString('utf8') || '').toString();
  }
  // Windows 上这段前提不成立：假 zstd 是个无扩展名的 `#!/bin/sh` 脚本，
  // Windows 不认它为可执行文件，PATH 查找会跳过它、仍然解析到真 zstd.exe
  // （2026-09-18 实测：改完 chmod 后这里变成 IS_AVAILABLE: true）。
  // 硬造一个 zstd.bat 去顶替又会牵扯 PATH 顺序与 CreateProcess 语义，
  // 属于测试基建改造，不属于本次要验的东西 —— 明确跳过并留原因。
  if (process.platform === 'win32') {
    console.log('[smoke] zstd-missing guard ⊘ skipped on win32（假 zstd 无法顶替 PATH）');
  } else {
    assert.equal(probeStdout.includes('IS_AVAILABLE: false'), true,
      `isZstdAvailable() should be false when PATH has no zstd, got stdout=${probeStdout.slice(0, 200)} stderr=${probeStderr.slice(0, 200)}`);
    assert.ok(/zstd CLI not found in PATH/.test(probeStdout),
      `must throw friendly zstd-missing error, got stdout=${probeStdout.slice(0, 200)}`);
    assert.ok(/agint-zstd-bootstrap/.test(probeStdout),
      `error message must reference bootstrap script, got stdout=${probeStdout.slice(0, 200)}`);
    console.log('[smoke] zstd-missing guard ✓ (child PATH stripped)');
  }
} finally {
  try { rmSync(fakeZstdDir, { recursive: true, force: true }); } catch {}
}

// ── 4. manifest sanity (manifest.json shell field is the 2026-09-12 fix) ──
const manifest = JSON.parse(readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
assert.ok(Array.isArray(manifest.spec.permissions.shell), 'permissions.shell must be an array (declaring zstd CLI dependency)');
assert.ok(manifest.spec.permissions.shell.includes('zstd'), 'permissions.shell must declare "zstd"');
console.log(`[smoke] manifest ✓ (permissions.shell = ${JSON.stringify(manifest.spec.permissions.shell)})`);

// ── 5. output schema ↔ return shape conformance（提案 339c0892）─────────────
// 断言文件早就在，但没有任何门禁跑它 ⇒ 新增返回字段仍可带病上线。
// check-wiring 查 I 把本文件当 smoke 入口，串在这里就等于接进部署门。
// 只核 exit code 不够：测试被清空或跳过时同样 exit 0。必须核真的跑了用例。
const conformanceFile = fileURLToPath(new URL('./output-schema-conformance.test.mjs', import.meta.url));
let conformanceOut;
try {
  conformanceOut = execFileSync(process.execPath, ['--test', conformanceFile], {
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
} catch (err) {
  const detail = `${err.stdout ?? ''}${err.stderr ?? ''}`.slice(-1200);
  assert.fail(`output-schema-conformance 未通过，部署门必须挡住 schema 漂移：\n${detail}`);
}
const conformancePassed = Number(/# pass (\d+)/.exec(conformanceOut)?.[1] ?? 0);
const conformanceFailed = Number(/# fail (\d+)/.exec(conformanceOut)?.[1] ?? 1);
assert.ok(conformancePassed >= 3 && conformanceFailed === 0,
  `一致性守卫必须真跑且全绿（pass=${conformancePassed} fail=${conformanceFailed}）`);
console.log(`[smoke] output schema ↔ return shape ✓ (${conformancePassed} pass / ${conformanceFailed} fail)`);

// ── summary ──────────────────────────────────────────────────────────────
console.log('[smoke] PASS ✓');
