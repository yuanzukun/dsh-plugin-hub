/**
 * agint-dream: unit tests for the LLM consolidation module (P1).
 * Run with: node --test packages/agint-dream/test/consolidation.test.js
 *
 * 设计见 AGINT/计划-agint-dream升级三方向.md P1 段。
 * 关键不变量（2026-10-25 无降级）：
 *   1. ctx 不可用 / 服务不可用 → ok:false + mode='failed' + reason 解释
 *   2. gated 为空 → ok:true + mode='not-attempted' + operations=null（内容闸门）
 *   3. subagent 拿到 structured output 后 → mode='llm' + operations 对齐 gated.length
 *   4. subagent stopReason !== 'completed' → ok:false + mode='failed'
 *   5. structured.operations.length !== gated.length → ok:false + mode='failed'
 *   6. 不抛异常 —— 失败用 ok:false 表达，sweep 据此跳过提升（⛔ 不回退启发式）
 *   7. buildConsolidationPrompt 是纯函数，输出包含所有 gated 候选 + existing 内容
 *   8. CONSOLIDATION_OUTPUT_SCHEMA 满足 DSH assertObjectJsonSchema 的子集
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  consolidate,
  buildConsolidationPrompt,
  CONSOLIDATION_OUTPUT_SCHEMA,
  DEFAULT_PROVIDER,
  DEFAULT_MODEL,
  DEFAULT_AGENT_PRESET,
  DEFAULT_REASONING_EFFORT,
} from '../lib/consolidation.js';

// ── 纯函数：buildConsolidationPrompt ──────────────────────────────────────

// 2026-09-21（方案 B 分级去重，proposals/agint-dream-dedupe-lineage.md §4.2）：
// 带 dedupeSuspicion 的候选必须把「疑似重复对象」显式写给模型 —— 这是 gate 与
// LLM 之间的契约：gate 只标不判，判定权在 LLM。提示不得退化成"直接 merge"的指令。
test('buildConsolidationPrompt: dedupeSuspicion 候选带出疑似对象 + 三分支指引', () => {
  const gated = [
    { key: 'k1', text: '索引化方案用于长期投资', type: 'decision', score: 0.8, signalCount: 7, uniqueDays: 2,
      dedupeSuspicion: { kind: 'similarity', similarity: 0.6667, againstId: 'mem-42' } },
    { key: 'k2', text: '一条干净的候选', type: 'lesson', score: 0.79, signalCount: 7, uniqueDays: 2 },
  ];
  const prompt = buildConsolidationPrompt(gated, [], '2026-09-21');
  // 疑似对象必须点名（id + 相似度 + 判据种类）
  assert.match(prompt, /dedupe-suspicion: similarity similarity=67% against existing entry id=mem-42/);
  // 三分支指引：merge / supersede / add
  assert.match(prompt, /same claim → action "merged"/);
  assert.match(prompt, /\(or "superseded" if the existing entry is now wrong\)/);
  assert.match(prompt, /merely similar wording → action "added"/);
  // 干净的候选不得被打标（防误伤）
  assert.equal((prompt.match(/dedupe-suspicion/g) ?? []).length, 1, '只有带标记的候选出现该字段');
  // 契约语气：是「证据」不是「指令」
  assert.match(prompt, /did NOT\s+auto-drop it/);
});

test('buildConsolidationPrompt: 无 dedupeSuspicion 时输出与旧版逐字一致（不引入噪音）', () => {
  const gated = [{ key: 'k1', text: '一条候选', type: 'lesson', score: 0.8 }];
  const prompt = buildConsolidationPrompt(gated, [], '2026-09-21');
  assert.doesNotMatch(prompt, /dedupe-suspicion/);
  assert.match(prompt, /### Candidate 1 \[key: k1\] type=lesson score=0.80/);
});

test('buildConsolidationPrompt: 列出所有 gated 候选 + existing 内容 + 输出指令', () => {
  const gated = [
    { key: 'c1', text: '禁止在生产环境 rm -rf', type: 'lesson', score: 0.85, sessionKey: 's1', signalCount: 4, uniqueDays: 2 },
    { key: 'c2', text: '老板是创造者，反馈优先级最高', type: 'preference', score: 0.82, sessionKey: 's2', signalCount: 3, uniqueDays: 1 },
  ];
  const existing = [
    { id: 'e1', type: 'lesson', content: '禁止 rm -rf 系统文件', lineageKey: 'safety/rm-rf' },
  ];
  const out = buildConsolidationPrompt(gated, existing, '2026-09-05');
  // 候选 1:1 列出
  assert.match(out, /禁止在生产环境 rm -rf/);
  assert.match(out, /老板是创造者/);
  assert.match(out, /Candidate 1 \[key: c1\]/);
  assert.match(out, /Candidate 2 \[key: c2\]/);
  // existing 列出
  assert.match(out, /禁止 rm -rf 系统文件/);
  // 2026-09-21：existing 以 fenced block 给出，content 独立成块，
  // `(id=...)` 头部不得与 content 混在同一行（否则模型会照抄前缀 → 整批被拒）
  assert.match(out, /```text/);
  assert.ok(
    !/^\(id=e1, type=lesson[^\n]*\)\s*禁止 rm -rf 系统文件/m.test(out),
    'id/type 头部不得与 content 混排在同一行',
  );
  // 头部信息改为注释行保留可追溯性
  assert.match(out, /<!-- id=e1 type=lesson \[lineage=safety\/rm-rf\] -->/);
  // 输出约束
  assert.match(out, /Operations array length MUST equal 2/);
});

test('buildConsolidationPrompt: 空 gated 输出约束 0', () => {
  const out = buildConsolidationPrompt([], [], '2026-09-05');
  assert.match(out, /Operations array length MUST equal 0/);
});

// ── Schema 子集自检（不调 DSH assert，但保证形态正确） ──────────────────────

test('CONSOLIDATION_OUTPUT_SCHEMA: 是 object-root，且 operations 是 array of object', () => {
  assert.equal(CONSOLIDATION_OUTPUT_SCHEMA.type, 'object');
  assert.ok(CONSOLIDATION_OUTPUT_SCHEMA.properties.operations);
  assert.equal(CONSOLIDATION_OUTPUT_SCHEMA.properties.operations.type, 'array');
  const opItem = CONSOLIDATION_OUTPUT_SCHEMA.properties.operations.items;
  assert.equal(opItem.type, 'object');
  // required 必须存在
  assert.deepEqual(opItem.required, ['candidateKey', 'action', 'priorEntries']);
  // 必须是 DSH 子集：boolean additionalProperties
  assert.equal(opItem.additionalProperties, false);
  assert.equal(CONSOLIDATION_OUTPUT_SCHEMA.additionalProperties, false);
  // 顶层 required
  assert.deepEqual(CONSOLIDATION_OUTPUT_SCHEMA.required, ['operations']);
});

// ── 退化路径 ─────────────────────────────────────────────────────────────

test('consolidate: gated 为空 → not-attempted（内容闸门，不是失败）', async () => {
  const result = await consolidate({
    ctx: { get: () => ({}) },
    gated: [],
    existing: [],
    day: '2026-09-05',
  });
  assert.equal(result.ok, true);
  assert.equal(result.mode, 'not-attempted');
  assert.equal(result.operations, null);
  assert.match(result.reason, /no gated/);
});

test('consolidate: ctx 不可用 → failed, operations=null, reason 解释', async () => {
  const result = await consolidate({
    ctx: null,
    gated: [{ key: 'c1', text: '某条候选', type: 'lesson', score: 0.8 }],
    existing: [],
    day: '2026-09-05',
  });
  assert.equal(result.ok, false);
  assert.equal(result.mode, 'failed');
  assert.equal(result.operations, null);
  assert.match(result.reason, /ctx unavailable/);
});

test('consolidate: ctx.get("agents") 返回 null → failed, reason 解释', async () => {
  const ctx = { get: (name) => name === 'subagents' ? { startActivation: () => {} } : null };
  const result = await consolidate({
    ctx,
    gated: [{ key: 'c1', text: '某条候选', type: 'lesson', score: 0.8 }],
    existing: [],
    day: '2026-09-05',
  });
  assert.equal(result.ok, false);
  assert.equal(result.mode, 'failed');
  assert.equal(result.operations, null);
  assert.match(result.reason, /agents service unavailable/);
});

test('consolidate: spawn provider 未注册 → failed, reason 解释', async () => {
  const ctx = {
    get: (name) => {
      if (name === 'agents') return { create: () => {} };
      if (name === 'subagents') return { startActivation: () => {}, getProvider: () => null };
      return null;
    },
  };
  const result = await consolidate({
    ctx,
    gated: [{ key: 'c1', text: '某条候选', type: 'lesson', score: 0.8 }],
    existing: [],
    day: '2026-09-05',
  });
  assert.equal(result.ok, false);
  assert.equal(result.mode, 'failed');
  assert.equal(result.operations, null);
  assert.match(result.reason, /spawn provider not registered/);
});

// ── 成功路径（用 mock subagent 注入） ────────────────────────────────────

function makeMockCtx({ runResult, throwOnCreate = false, throwOnStart = false, legacy = false }) {
  const calls = { createArgs: null, startArgs: null, disposed: [] };
  const handle = {
    agent: { id: 'mock-parent' },
    dispose: async () => { calls.disposed.push('handle'); },
  };
  const agents = {
    create: async (opts) => {
      calls.createArgs = opts;
      if (throwOnCreate) throw new Error('mock create failed');
      return handle;
    },
  };
  const run = {
    childId: 'mock-child',
    result: Promise.resolve(runResult),
    dispose: async () => { calls.disposed.push('activation'); },
  };
  const subagents = {
    getProvider: (name) => name === 'spawn' ? { name: 'spawn' } : null,
    ...(legacy
      ? {
        start: async (name, req) => {
          calls.startArgs = { provider: name, request: req, legacy: true };
          if (throwOnStart) throw new Error('mock start failed');
          return run;
        },
      }
      : {
        startActivation: async (spec) => {
          calls.startArgs = spec;
          if (throwOnStart) throw new Error('mock start failed');
          return run;
        },
      }),
  };
  return {
    ctx: { get: (n) => n === 'agents' ? agents : n === 'subagents' ? subagents : null },
    calls,
  };
}

test('consolidate: subagent 返回 llm structured → mode=llm, operations 对齐', async () => {
  const gated = [
    { key: 'c1', text: '禁止 rm -rf', type: 'lesson', score: 0.85 },
    { key: 'c2', text: '老板是创造者', type: 'preference', score: 0.82 },
  ];
  const operations = [
    { candidateKey: 'c1', action: 'added', priorEntries: [] },
    { candidateKey: 'c2', action: 'merged', priorEntries: ['老板 = 创造者'], lineageKey: 'identity/boss' },
  ];
  const { ctx, calls } = makeMockCtx({
    runResult: {
      output: [],
      structured: { operations, reasoning: 'merge c2 into existing identity entry' },
      stopReason: 'completed',
    },
  });
  const result = await consolidate({ ctx, gated, existing: [], day: '2026-09-05' });
  assert.equal(result.ok, true);
  assert.equal(result.mode, 'llm');
  assert.deepEqual(result.operations, operations);
  // verify subagent called with right shape
  // 断言模块默认值本身，而不是硬编码 provider 名：默认值来自 settings.yaml 实测值，
  // 会随部署变化（fbfd060 起这里硬编码 'deepseek'，源码却是 'minimax-cn'，红了很久）。
  assert.equal(calls.createArgs.agentOptions.provider, DEFAULT_PROVIDER);
  assert.equal(calls.createArgs.agentOptions.model, DEFAULT_MODEL);
  // 显式传参必须能覆盖默认值（不传 provider/model 时才会落到上面两个常量）
  {
    const { ctx: c2, calls: k2 } = makeMockCtx({
      runResult: {
        output: [],
        structured: { operations: [{ candidateKey: 'c1', action: 'added', priorEntries: [] }] },
        stopReason: 'completed',
      },
    });
    await consolidate({
      ctx: c2,
      gated: [{ key: 'c1', text: '禁止 rm -rf', type: 'lesson', score: 0.85 }],
      existing: [],
      day: '2026-09-05',
      provider: 'explicit-provider',
      model: 'explicit-model',
    });
    assert.equal(k2.createArgs.agentOptions.provider, 'explicit-provider');
    assert.equal(k2.createArgs.agentOptions.model, 'explicit-model');
  }
  assert.equal(calls.startArgs.provider, 'spawn');
  assert.equal(calls.startArgs.delivery, 'caller');
  assert.equal(calls.startArgs.request.parent.id, 'mock-parent');
  assert.equal(calls.startArgs.request.agentPreset, DEFAULT_AGENT_PRESET);
  assert.ok(calls.startArgs.request.outputSchema, 'outputSchema must be passed in request');
  // activation + handle disposed in finally
  assert.ok(calls.disposed.includes('activation'));
  assert.ok(calls.disposed.includes('handle'));
});

test('consolidate: stopReason !== completed → failed, operations=null', async () => {
  const { ctx } = makeMockCtx({
    runResult: { output: [], structured: { operations: [] }, stopReason: 'error', diagnostic: 'LLM timeout' },
  });
  const result = await consolidate({
    ctx,
    gated: [{ key: 'c1', text: '某条', type: 'lesson', score: 0.8 }],
    existing: [],
    day: '2026-09-05',
  });
  assert.equal(result.ok, false);
  assert.equal(result.mode, 'failed');
  assert.equal(result.operations, null);
  assert.match(result.reason, /stopReason=error/);
});

test('consolidate: structured.operations 长度不对齐 → failed', async () => {
  const { ctx } = makeMockCtx({
    runResult: {
      output: [],
      structured: { operations: [{ candidateKey: 'c1', action: 'added', priorEntries: [] }] },
      stopReason: 'completed',
    },
  });
  const result = await consolidate({
    ctx,
    gated: [
      { key: 'c1', text: '某条1', type: 'lesson', score: 0.8 },
      { key: 'c2', text: '某条2', type: 'preference', score: 0.8 },
    ],
    existing: [],
    day: '2026-09-05',
  });
  assert.equal(result.ok, false);
  assert.equal(result.mode, 'failed');
  assert.equal(result.operations, null);
  assert.match(result.reason, /operations length mismatch/);
});

test('consolidate: structured 缺失 → failed', async () => {
  const { ctx } = makeMockCtx({
    runResult: { output: [], stopReason: 'completed' }, // 没有 structured
  });
  const result = await consolidate({
    ctx,
    gated: [{ key: 'c1', text: '某条', type: 'lesson', score: 0.8 }],
    existing: [],
    day: '2026-09-05',
  });
  assert.equal(result.ok, false);
  assert.equal(result.mode, 'failed');
  assert.match(result.reason, /structured output invalid/);
});

// ── 子代理空壳根因回归（2026-09-27，K114）──────────────────────────────────
// 病灶：agents.create() 未传 meta.agentPreset ⇒ child 会话 agentPreset=null、
// modelSelection=null、turn 空、surfaceTokens=0 —— 不报错，但一步都跑不动，
// 静默落回 heuristic-degraded（该回退已于 2026-10-25 删除）。18 个 dream-consolidation-* 会话全是这么死的。
// 这两条断言是唯一能挡住它复发的防线：mock 层不会替我们发现"会话建了但没跑"。
test('consolidate: agents.create 必带 meta.agentPreset（缺省 = DEFAULT_AGENT_PRESET）', async () => {
  const { ctx, calls } = makeMockCtx({
    runResult: {
      output: [],
      structured: { operations: [{ candidateKey: 'c1', action: 'added', priorEntries: [] }] },
      stopReason: 'completed',
    },
  });
  await consolidate({
    ctx,
    gated: [{ key: 'c1', text: '禁止 rm -rf', type: 'lesson', score: 0.85 }],
    existing: [],
    day: '2026-09-27',
  });
  assert.equal(calls.createArgs.meta.agentPreset, DEFAULT_AGENT_PRESET, '缺 agentPreset ⇒ 空壳子代理');
  assert.equal(calls.createArgs.meta.origin, 'subagent');
  assert.ok(calls.createArgs.meta.cwd, 'cwd 缺失会让 child persona 的 {{cwd}} throw');
});

test('consolidate: agentPreset 显式传参可覆盖默认（换 profile 不用改源码）', async () => {
  const { ctx, calls } = makeMockCtx({
    runResult: {
      output: [],
      structured: { operations: [{ candidateKey: 'c1', action: 'added', priorEntries: [] }] },
      stopReason: 'completed',
    },
  });
  await consolidate({
    ctx,
    gated: [{ key: 'c1', text: '禁止 rm -rf', type: 'lesson', score: 0.85 }],
    existing: [],
    day: '2026-09-27',
    agentPreset: 'agint-other',
  });
  assert.equal(calls.createArgs.meta.agentPreset, 'agint-other');
});

test('consolidate: agents.create 抛错 → failed, 不向外抛', async () => {
  const { ctx } = makeMockCtx({ throwOnCreate: true });
  const result = await consolidate({
    ctx,
    gated: [{ key: 'c1', text: '某条', type: 'lesson', score: 0.8 }],
    existing: [],
    day: '2026-09-05',
  });
  assert.equal(result.ok, false);
  assert.equal(result.mode, 'failed');
  assert.match(result.reason, /mock create failed/);
});

test('consolidate: subagents.start 抛错 → failed, 不向外抛', async () => {
  const { ctx } = makeMockCtx({ throwOnStart: true });
  const result = await consolidate({
    ctx,
    gated: [{ key: 'c1', text: '某条', type: 'lesson', score: 0.8 }],
    existing: [],
    day: '2026-09-05',
  });
  assert.equal(result.ok, false);
  assert.equal(result.mode, 'failed');
  assert.match(result.reason, /mock start failed/);
});

test('consolidate: provider/model 参数被透传到 create', async () => {
  const { ctx, calls } = makeMockCtx({
    runResult: { output: [], structured: { operations: [] }, stopReason: 'completed' },
  });
  await consolidate({
    ctx,
    gated: [{ key: 'c1', text: '某条', type: 'lesson', score: 0.8 }],
    existing: [],
    day: '2026-09-05',
    provider: 'custom-provider',
    model: 'custom-model-v2',
  });
  assert.equal(calls.createArgs.agentOptions.provider, 'custom-provider');
  assert.equal(calls.createArgs.agentOptions.model, 'custom-model-v2');
});

// 2026-10-07 回归测试：这条在修复前是**红的**（agentOptions 里没有 reasoningEffort 键）。
// 为什么必须有它：DEFAULT_MODEL=MiniMax-M3.1-Flash-Preview 强制 adaptive thinking，
// 不传 reasoningEffort → 子代理 thinking 关闭 → provider 返 400
// （"requires adaptive thinking; thinking.type=\"disabled\" ... is not allowed (2013)"）
// → consolidation 恒失败 → promoted 恒 0 →
//   agint-ov-strategy 的 dream 投影被 `promoted <= 0` 门槛永远挡死。
// 旧测试只断言 provider/model 透传，两者修复前后都绿 ⇒ 抓不到这个 bug。
test('consolidate: reasoningEffort 必须透传（不传则模型拒收）', async () => {
  const { ctx, calls } = makeMockCtx({
    runResult: { output: [], structured: { operations: [] }, stopReason: 'completed' },
  });
  // 默认档：必须等于 DEFAULT_REASONING_EFFORT，且与 DEFAULT_MODEL 配套
  await consolidate({
    ctx,
    gated: [{ key: 'c1', text: '某条', type: 'lesson', score: 0.8 }],
    existing: [],
    day: '2026-10-07',
  });
  assert.equal(calls.createArgs.agentOptions.reasoningEffort, DEFAULT_REASONING_EFFORT);
  // 显式覆盖：调用方能改档（sweep.js 目前不传，走默认）
  const ctx2 = makeMockCtx({
    runResult: { output: [], structured: { operations: [] }, stopReason: 'completed' },
  });
  await consolidate({
    ctx: ctx2.ctx,
    gated: [{ key: 'c1', text: '某条', type: 'lesson', score: 0.8 }],
    existing: [],
    day: '2026-10-07',
    reasoningEffort: 'low',
  });
  assert.equal(ctx2.calls.createArgs.agentOptions.reasoningEffort, 'low');
});

test('consolidate: timeout 时 dispose 仍跑（finally）', async () => {
  // mock：result 永不 resolve，触发 abort
  let aborted = false;
  const ctx = {
    get: (n) => {
      if (n === 'agents') {
        return {
          create: async () => ({
            agent: { id: 'mock' },
            dispose: async () => { aborted = true; },
          }),
        };
      }
      if (n === 'subagents') {
        return {
          getProvider: () => ({ name: 'spawn' }),
          start: async () => ({
            // never resolves、也永不因 abort 而 settle —— 模拟「provider 不认
            // signal」（挂死的 HTTP / 卡住的适配器）。consolidate 必须靠自身的
            // timeoutGuard 收敛，否则夜间 sweep 会永久 pending（fbfd060 起此例
            // 一直是红的，即该缺陷真实存在）。
            result: new Promise(() => {}),
            dispose: async () => {},
          }),
        };
      }
      return null;
    },
  };
  const result = await consolidate({
    ctx,
    gated: [{ key: 'c1', text: '某条', type: 'lesson', score: 0.8 }],
    existing: [],
    day: '2026-09-05',
    timeoutMs: 50,
  });
  // 50ms timeout → result never resolved → 走 timeout 路径
  // 这里我们只验证：consolidate 不挂死、不抛错、最终返回 failed
  assert.equal(result.ok, false);
  assert.equal(result.mode, 'failed');
  assert.equal(result.operations, null);
  assert.match(result.reason, /consolidation timeout \(50ms\)/, '超时原因必须可读（进梦境日记）');
  assert.equal(aborted, true, 'handle.dispose must run in finally');
});
