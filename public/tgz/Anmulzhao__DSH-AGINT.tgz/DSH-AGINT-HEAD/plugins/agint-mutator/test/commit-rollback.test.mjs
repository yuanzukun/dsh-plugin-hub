#!/usr/bin/env node
// agint-mutator / commit + rollback unit test — `node test/commit-rollback.test.mjs` 一行能跑。
// Sprint 8 #4：commit 7 步 + rollback 5 步闭环（哈希校验 + 文件落点表 + mutation.* 事件）。
// 设计：tmpdir 隔离文件系统；mock sandbox + policy + diagnosis/evolution；≥8 用例。

import test from 'node:test';
import assert from 'node:assert/strict';
import * as plugin from '../lib/index.js';
import { mkdtempSync, writeFileSync, readFileSync, existsSync, rmSync, mkdirSync } from 'node:fs';
import { join, isAbsolute, resolve } from 'node:path';
import { tmpdir } from 'node:os';

const { LIMITS } = plugin;

// ── fixtures ────────────────────────────────────────────────────────
const FIX = {
  prompt: { source: 'attribution-driven', failureId: 'f-p', rootCause: 'PROMPT_DEFICIENCY',
    expectedEffect: 'baseline 通过率 >= 95% 在 7 天', rollbackCondition: 'regression -> rollback', atomicScope: 'prompt',
    promptPayload: { promptId: 'sys-prompt', oldText: 'old prompt', newText: 'new prompt', diffStrategy: 'unified_diff' } },
  tool: { source: 'attribution-driven', failureId: 'f-t', rootCause: 'TOOL_GAP',
    expectedEffect: 'tool OK >= 80% within 7 天', rollbackCondition: 'harm >10% rollback', atomicScope: 'tool',
    toolPayload: { toolName: 'fetch-weather-api', signature: 'fetch_weather(c) -> P<W>', stubs: ['happy returns sample', 'sad returns error'], intent: '补天气工具' } },
  strategy: { source: 'evolution-reversed', failureId: 'f-s', rootCause: 'PLANNING_FAILURE',
    expectedEffect: 'reorder OK >= 80% within 7 天', rollbackCondition: 'manual rollback after 3 failures', atomicScope: 'strategy',
    strategyPayload: { strategyId: 'default-strategy', oldSteps: ['fetch_context', 'plan_subtasks', 'execute', 'verify'], newSteps: ['plan_subtasks', 'fetch_context', 'execute', 'verify'], ordering: 'replace' } },
};
const clone = (x) => JSON.parse(JSON.stringify(x));

// ── helpers ────────────────────────────────────────────────────────

function makeEnv({ sandboxOk = true, sandboxReason, policyDecision = 'AUTO_DEPLOY', policyReason, writePreimage = true } = {}) {
  const workdir = mkdtempSync(join(tmpdir(), 'agint-mutator-'));
  // pre-write prompt file content + strategies JSON
  if (writePreimage) {
    mkdirSync(join(workdir, 'plugins', 'agint-mutator', 'prompts'), { recursive: true });
    mkdirSync(join(workdir, 'plugins', 'agint-mutator', 'strategies'), { recursive: true });
    writeFileSync(join(workdir, 'plugins', 'agint-mutator', 'prompts', 'sys-prompt.md'), 'OLD prompt content');
    writeFileSync(join(workdir, 'plugins', 'agint-mutator', 'strategies', 'default-strategy.json'), JSON.stringify({ strategyId: 'default-strategy', ordering: 'before', steps: ['fetch_context', 'plan_subtasks', 'execute', 'verify'] }, null, 2));
  }
  const tables = { proposals: new Map(), commits: new Map(), findings: new Map(), metrics_log: new Map() };
  const services = {};
  // ⛔ 路径形状守门（v0.6.6）：记录 sandbox 实际收到的 target.path。
  //   相对路径会被 sandbox 内部 `resolve(target.path)` 按 process.cwd() 解析 ——
  //   验的就不是 commit 写的那个文件（2026-09-29 driver 真实事故同源）。
  //   mock 原样回显 target.path，别的断言都绿，正是这类 bug 藏身之处。
  const sandboxSaw = [];
  const mockSandbox = {
    runSmoke: async ({ target }) => {
      sandboxSaw.push(target.path);
      return {
        target: { path: target.path, name: target.name },
        ok: sandboxOk, mode: 'in-process', exitCode: sandboxOk ? 0 : 1,
        stdout: '', stderr: '', checks: [{ name: 'mock-smoke', ok: sandboxOk, detail: 'mock' }],
        reason: sandboxReason,
        durationMs: 1,
      };
    },
  };
  const policySaw = { current: null };
  // v0.6.5：mock 复刻 policy 真实入参契约（K115 教训泛化）——dimensions 缺 key → REJECT unknown-veto；
  // score.veto=true → REJECT。不复刻入参形状 = 字段名写错也照样绿（driver v0.2.8 同根因）。
  const mockPolicy = {
    decide: async ({ results }) => {
      const r = results?.[0] ?? null;
      policySaw.current = r;
      const dims = r?.dimensions ?? [];
      const keyed = dims.some((d) => d?.key === 'safety') && dims.some((d) => d?.key === 'trust');
      if (!keyed) {
        return { kind: 'REJECT', score: 0, reason: 'unknown-veto', triggeredBy: ['undefined:unknown-veto'], decidedAt: new Date().toISOString(), policyId: 'mock@v0' };
      }
      const vetoed = dims.filter((d) => d?.score?.veto === true);
      if (vetoed.length > 0) {
        return { kind: 'REJECT', score: 0, reason: 'policy-reject:veto-or-low-composite', triggeredBy: vetoed.map((d) => `${d.key}:veto`), decidedAt: new Date().toISOString(), policyId: 'mock@v0' };
      }
      return {
        kind: policyDecision, score: 80, reason: policyReason || `mock-policy-${policyDecision}`,
        triggeredBy: [], decidedAt: new Date().toISOString(), policyId: 'mock@v0',
      };
    },
    detectFalseHarmony: async () => ({}),
    setThresholds: async () => ({}),
    health: () => ({ serviceAvailable: true }),
    config: {},
  };
  plugin.apply({
    storageDomain: { open: async () => ({
      table: (name) => {
        const s = tables[name] || (tables[name] = new Map());
        return {
          entries: () => [...s.entries()][Symbol.iterator](),
          put: async (id, v) => { s.set(id, v); },
          close: async () => {},
        };
      },
      close: async () => {},
    }) },
    get: (n) => {
      if (n === 'agint.qualitySandbox') return mockSandbox;
      if (n === 'agint.qualityPolicy') return mockPolicy;
      if (n === 'agint.diagnosis') return { annotate: async () => [], report: async () => ({}) };
      if (n === 'agint.evolution') return { queryFailures: async () => [] };
      return null;
    },
    provide: (n, f) => { services[n] = f; },
    effect: () => () => {},
  });
  return { services, tables, workdir, policySaw, sandboxSaw, cleanup: () => rmSync(workdir, { recursive: true, force: true }) };
}

/**
 * ⛔ 路径形状守门（v0.6.6）。
 *
 * 这类 bug 最阴的地方在于：**所有别的断言都是绿的**。commit 写对了文件、
 * policy 判对了、返回 ok:true —— 只有 sandbox 验的对象是错的。
 * 2026-09-29 driver 的真实事故就是这么一路走到生产 policy.decide 才被拒的。
 *
 * 判据：sandbox 收到的 target.path 必须是绝对路径，且以 env.workdir（= repoRoot）为前缀。
 * 后者比 isAbsolute 更强 —— 它锁的是「拼的基准是 repoRoot，不是 cwd」。
 */
function assertSandboxGotAbsoluteTarget(sandboxSaw, workdir) {
  assert.ok(sandboxSaw.length > 0, 'sandbox.runSmoke 一次都没被调用');
  for (const p of sandboxSaw) {
    assert.ok(isAbsolute(p), `传给 runSmoke 的必须是绝对路径，实际是 ${JSON.stringify(p)} —— 相对路径会被 sandbox 按 cwd 解析（2026-09-29 事故）`);
    assert.ok(p.startsWith(resolve(workdir)), `路径必须以 repoRoot=${workdir} 为基准拼，实际是 ${JSON.stringify(p)} —— 说明依赖了 cwd`);
  }
}

async function proposeAndCommit(fix, env, extra = {}) {
  const { services } = env;
  // Sprint 8 #4：targetPlugin 通过 propose() 透传 → 内部 _targetPlugin 字段；commit 读内部字段
  const p = await services['agint.mutator.propose']({
    ...clone(fix),
    targetPlugin: 'agint-mutator',
  });
  const c = await services['agint.mutator.commit']({
    proposalId: p.id,
    repoRoot: env.workdir,
    ...extra,
  });
  return { proposal: p, commit: c };
}

// ── commit happy path：3 类 mutation 各 1 ───────────────────────────

test('commit happy PROMPT_MUTATION: sandbox ok + policy AUTO_DEPLOY → mutation.success + status=COMMITTED', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    const { commit: c } = await proposeAndCommit(FIX.prompt, env);
    assert.equal(c.ok, true);
    assert.ok(c.commitId.length > 0);
    assert.ok(c.postimageHash.length > 0);
    assert.equal(c.policyDecision, 'AUTO_DEPLOY');
    // 文件已写
    const written = readFileSync(join(env.workdir, 'plugins/agint-mutator/prompts/sys-prompt.md'), 'utf8');
    assert.equal(written, 'new prompt'); // payload.newText
    // commits 表写入
    assert.equal(env.tables.commits.size, 1);
    // metrics_log 写入 mutation.success
    const metricsLog = Array.from(env.tables.metrics_log.values());
    assert.equal(metricsLog.length, 1);
    assert.equal(metricsLog[0].eventType, 'mutation.success');
    assert.equal(metricsLog[0].policyDecision, 'AUTO_DEPLOY');
    // proposals.status='COMMITTED'
    const proposal = Array.from(env.tables.proposals.values()).find((p) => p.status === 'COMMITTED');
    assert.ok(proposal, 'should have a COMMITTED proposal');
  } finally { env.cleanup(); }
});

test('commit happy TOOL_SYNTHESIS: 新建文件 + sandbox ok + AUTO_DEPLOY', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    const { commit: c } = await proposeAndCommit(FIX.tool, env);
    assert.equal(c.ok, true);
    assert.equal(c.policyDecision, 'AUTO_DEPLOY');
    // 文件新建
    const absTool = join(env.workdir, 'plugins/agint-mutator/tools/fetch-weather-api.js');
    assert.ok(existsSync(absTool));
    const written = readFileSync(absTool, 'utf8');
    assert.ok(written.includes('Auto-generated tool: fetch-weather-api'));
    assert.ok(written.includes('happy returns sample'));
    // commits 表写入
    assert.equal(env.tables.commits.size, 1);
    // audit 字段有 sandboxResult='ok'
    const commitEntry = Array.from(env.tables.commits.values())[0];
    assert.equal(commitEntry.audit.sandboxResult, 'ok');
    assert.equal(commitEntry.preimageContent, ''); // TOOL_SYNTHESIS preimageContent 为空（文件原本不存在）
    // ⛔ commit 侧路径形状（v0.6.6）
    assertSandboxGotAbsoluteTarget(env.sandboxSaw, env.workdir);
    // metrics_log mutation.success
    assert.equal(Array.from(env.tables.metrics_log.values())[0].eventType, 'mutation.success');
  } finally { env.cleanup(); }
});

test('commit happy STRATEGY_REWRITE: 整文件替换 + sandbox ok + PENDING_REVIEW', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'PENDING_REVIEW' });
  try {
    const { commit: c } = await proposeAndCommit(FIX.strategy, env);
    assert.equal(c.ok, true);
    assert.equal(c.policyDecision, 'PENDING_REVIEW');
    // 文件已替换为新 steps
    const written = JSON.parse(readFileSync(join(env.workdir, 'plugins/agint-mutator/strategies/default-strategy.json'), 'utf8'));
    assert.deepEqual(written.steps, ['plan_subtasks', 'fetch_context', 'execute', 'verify']);
    assert.equal(written.ordering, 'replace');
    // metrics_log mutation.success + policyDecision='PENDING_REVIEW'
    const ml = Array.from(env.tables.metrics_log.values())[0];
    assert.equal(ml.eventType, 'mutation.success');
    assert.equal(ml.policyDecision, 'PENDING_REVIEW');
  } finally { env.cleanup(); }
});

// ── commit policy REJECT 路径：恢复 preimage + mutation.failure + status=REJECTED ──

test('commit policy REJECT：sandbox ok 但 policy 拒 → mutation.failure + REJECTED + preimage 恢复', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'REJECT', policyReason: 'low-trust' });
  try {
    // 先把原始 prompt 内容存一份（事后比对）
    const original = readFileSync(join(env.workdir, 'plugins/agint-mutator/prompts/sys-prompt.md'), 'utf8');
    // propose 后 commit 应当抛错（policy REJECT）
    await assert.rejects(async () => {
      await proposeAndCommit(FIX.prompt, env);
    }, /policyDecision=REJECT/);
    // 文件应当恢复为旧内容
    const restored = readFileSync(join(env.workdir, 'plugins/agint-mutator/prompts/sys-prompt.md'), 'utf8');
    assert.equal(restored, original, 'preimage 应当恢复');
    // commits 表还是写了一份（commit 表先写后判定）
    assert.ok(env.tables.commits.size >= 1, 'commit entry 落了，便于审计');
    // proposal.status='REJECTED'
    const proposal = Array.from(env.tables.proposals.values()).find((p) => p.status === 'REJECTED');
    assert.ok(proposal, 'proposal.status 应该 REJECTED');
    // metrics_log mutation.failure
    const failed = Array.from(env.tables.metrics_log.values()).find((m) => m.eventType === 'mutation.failure');
    assert.ok(failed, 'mutation.failure 应该被写入');
    assert.equal(failed.policyDecision, 'REJECT');
    // audit.rollbackTrigger = 原 rollbackCondition 字符串
    const commitEntry = Array.from(env.tables.commits.values())[0];
    assert.equal(commitEntry.audit.rollbackTrigger, 'regression -> rollback');
  } finally { env.cleanup(); }
});

// ── rollback happy path：3 类 mutation 各 1 ─────────────────────────

test('rollback happy PROMPT_MUTATION：commit 后 rollback → file 还原', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    const original = readFileSync(join(env.workdir, 'plugins/agint-mutator/prompts/sys-prompt.md'), 'utf8');
    const { commit: c } = await proposeAndCommit(FIX.prompt, env);
    const written = readFileSync(join(env.workdir, 'plugins/agint-mutator/prompts/sys-prompt.md'), 'utf8');
    assert.notEqual(written, original);
    // rollback
    const rb = await env.services['agint.mutator.rollback']({
      commitId: c.commitId, repoRoot: env.workdir,
    });
    assert.equal(rb.ok, true);
    // restoredHash 应等于 preimageHash
    assert.equal(rb.restoredHash, c.preimageHash);
    // 文件还原
    const restored = readFileSync(join(env.workdir, 'plugins/agint-mutator/prompts/sys-prompt.md'), 'utf8');
    assert.equal(restored, original);
    // proposal.status = 'ROLLED_BACK'
    const proposal = Array.from(env.tables.proposals.values())[0];
    assert.equal(proposal.status, 'ROLLED_BACK');
    // metrics_log mutation.rollback
    const rbMetric = Array.from(env.tables.metrics_log.values()).find((m) => m.eventType === 'mutation.rollback');
    assert.ok(rbMetric);
    // ⛔ commit 与 rollback **两次**调用都必须收到绝对路径（v0.6.6）
    //    两处曾各自传相对 targetPath，而正确答案 absTarget 就在各自上一行
    assert.equal(env.sandboxSaw.length, 2, `预期 commit + rollback 各调一次 runSmoke，实际 ${env.sandboxSaw.length} 次`);
    assertSandboxGotAbsoluteTarget(env.sandboxSaw, env.workdir);
  } finally { env.cleanup(); }
});

test('rollback happy TOOL_SYNTHESIS：commit 后 rollback → 文件应 unlink（回到不存在）', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY', writePreimage: false });
  try {
    const { commit: c } = await proposeAndCommit(FIX.tool, env);
    const absTool = join(env.workdir, 'plugins/agint-mutator/tools/fetch-weather-api.js');
    assert.ok(existsSync(absTool), 'commit 后文件存在');
    // rollback
    const rb = await env.services['agint.mutator.rollback']({
      commitId: c.commitId, repoRoot: env.workdir,
    });
    assert.equal(rb.ok, true);
    assert.equal(rb.restoredHash, c.preimageHash);
    // 文件应已删除
    assert.ok(!existsSync(absTool), 'TOOL_SYNTHESIS rollback 后文件应 unlink');
    // metrics_log mutation.rollback
    const rbMetric = Array.from(env.tables.metrics_log.values()).find((m) => m.eventType === 'mutation.rollback');
    assert.ok(rbMetric);
  } finally { env.cleanup(); }
});

test('rollback happy STRATEGY_REWRITE：commit 后 rollback → JSON 还原', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    const original = readFileSync(join(env.workdir, 'plugins/agint-mutator/strategies/default-strategy.json'), 'utf8');
    const { commit: c } = await proposeAndCommit(FIX.strategy, env);
    const written = readFileSync(join(env.workdir, 'plugins/agint-mutator/strategies/default-strategy.json'), 'utf8');
    assert.notEqual(written, original);
    // rollback
    const rb = await env.services['agint.mutator.rollback']({
      commitId: c.commitId, repoRoot: env.workdir,
    });
    assert.equal(rb.ok, true);
    assert.equal(rb.restoredHash, c.preimageHash);
    // JSON 还原
    const restored = JSON.parse(readFileSync(join(env.workdir, 'plugins/agint-mutator/strategies/default-strategy.json'), 'utf8'));
    assert.deepEqual(restored, JSON.parse(original));
  } finally { env.cleanup(); }
});

// ── rollback 失败语义：preimageContent 篡改 → 抛错 + findings ────────

test('rollback 失败：篡改 commits.preimageContent → SHA-256 不匹配 + 写 findings + 抛错', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    const { commit: c } = await proposeAndCommit(FIX.prompt, env);
    // 篡改 commits.preimageContent（模拟外部攻击 / 数据漂移）
    const commitEntry = Array.from(env.tables.commits.values())[0];
    commitEntry.preimageContent = 'tampered content';
    env.tables.commits.set(commitEntry.id, commitEntry);
    // rollback 必抛错
    await assert.rejects(
      () => env.services['agint.mutator.rollback']({ commitId: c.commitId, repoRoot: env.workdir }),
      /SHA-256 校验失败/,
    );
    // 写 findings 表
    const finding = Array.from(env.tables.findings.values()).find((f) => /SHA-256/.test(f.message));
    assert.ok(finding, '应该写一条 SHA-256 校验失败 finding');
    assert.equal(finding.severity, 'error');
    // proposal.status 应当仍为 COMMITTED（rollback 失败未走完 5 步）
    const proposal = Array.from(env.tables.proposals.values())[0];
    assert.equal(proposal.status, 'COMMITTED');
  } finally { env.cleanup(); }
});

// ── 软依赖缺失硬抛：mutation 关键路径不静默 ────────────────────────

test('commit 软依赖缺失抛错：agint.qualitySandbox=null 时 commit 不静默', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  // 重写 ctx.get 让 sandbox 不可用
  const workdir = env.workdir;
  rmSync(workdir, { recursive: true, force: true });
  // 直接用最小 ctx 调 propose + 注入空 sandbox
  const tables = { proposals: new Map(), commits: new Map(), findings: new Map(), metrics_log: new Map() };
  const services = {};
  plugin.apply({
    storageDomain: { open: async () => ({
      table: (name) => {
        const s = tables[name] || (tables[name] = new Map());
        return {
          entries: () => [...s.entries()][Symbol.iterator](),
          put: async (id, v) => { s.set(id, v); },
          close: async () => {},
        };
      }, close: async () => {},
    }) },
    get: (n) => {
      // 关键：所有软依赖都 null
      return null;
    },
    provide: (n, f) => { services[n] = f; },
    effect: () => () => {},
  });
  const propose = services['agint.mutator.propose'];
  // 走 tool 路径，避开 diagnosis，但 commit 时 sandbox+policy 都 null
  let p;
  try {
    p = await propose({ ...clone(FIX.tool), targetPlugin: 'agint-mutator' });
  } catch (err) {
    // evolution 也被 null，可能 propose 直接挂
    if (/agint\.evolution/.test(err.message)) return; // 符合预期（关键路径不静默）
    throw err;
  }
  await assert.rejects(
    () => services['agint.mutator.commit']({ proposalId: p.id, repoRoot: '/tmp' }),
    /agint\.qualitySandbox 服务不可用/,
  );
});

// ── MutationStatus 状态机迁移验证（直接读 proposals 表） ────────────

test('状态机：propose=PENDING → commit policy AUTO_DEPLOY 后 → COMMITTED', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    // propose 后 status='PENDING'
    const { proposal: p1 } = await proposeAndCommit(FIX.prompt, env);
    assert.equal(p1.status, 'PENDING');
    // commit 后通过查 tables 验证状态已改成 'COMMITTED'
    const stored = Array.from(env.tables.proposals.values()).find((p) => p.id === p1.id);
    assert.equal(stored.status, 'COMMITTED');
  } finally { env.cleanup(); }
});

test('状态机：rollback 后 status='+'ROLLED_BACK', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    const { commit: c } = await proposeAndCommit(FIX.tool, env);
    const proposal = Array.from(env.tables.proposals.values())[0];
    assert.equal(proposal.status, 'COMMITTED');
    await env.services['agint.mutator.rollback']({ commitId: c.commitId, repoRoot: env.workdir });
    const rolled = Array.from(env.tables.proposals.values())[0];
    assert.equal(rolled.status, 'ROLLED_BACK');
  } finally { env.cleanup(); }
});

test('LIMITS.COMMITS=50 守门生效', () => {
  // 直接断言 schema 值
  assert.equal(LIMITS.COMMITS, 50);
  assert.equal(LIMITS.PREIMAGE_BYTES, 5 * 1024 * 1024);
});

// ── Sprint 10 #5：rollback 向后兼容断言（4 个新可选字段） ────────

test('兼容：rollback FROZEN 字段 { ok, restoredHash } 仍然成立', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    const { commit: c } = await proposeAndCommit(FIX.prompt, env);
    const rb = await env.services['agint.mutator.rollback']({
      commitId: c.commitId, repoRoot: env.workdir,
    });
    // Sprint 8 FROZEN 契约：ok=true, restoredHash 等于 commit 时记的 preimageHash
    assert.equal(rb.ok, true);
    assert.equal(rb.restoredHash, c.preimageHash);
  } finally { env.cleanup(); }
});

test('兼容：rollback 新增可选字段 rollbackTransactionId 存在', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    const { commit: c } = await proposeAndCommit(FIX.prompt, env);
    const rb = await env.services['agint.mutator.rollback']({
      commitId: c.commitId, repoRoot: env.workdir,
    });
    assert.ok(rb.rollbackTransactionId, 'rollbackTransactionId 应存在');
    assert.equal(typeof rb.rollbackTransactionId, 'string');
    assert.ok(rb.rollbackTransactionId.length > 0);
  } finally { env.cleanup(); }
});

test('兼容：rollback 新增可选字段 preimageHashAtStart 存在', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    const { commit: c } = await proposeAndCommit(FIX.prompt, env);
    const rb = await env.services['agint.mutator.rollback']({
      commitId: c.commitId, repoRoot: env.workdir,
    });
    assert.ok(rb.preimageHashAtStart, 'preimageHashAtStart 应存在');
    assert.equal(typeof rb.preimageHashAtStart, 'string');
    assert.equal(rb.preimageHashAtStart.length, 64, 'SHA-256 hex 应 64 字符');
  } finally { env.cleanup(); }
});

// ── v0.6.5：commit synthEval 契约（K115 教训泛化 —— mock 复刻 policy 真实入参形状） ────

test('commit synthEval 契约：dimensions 必须带 key（policy 实读 d.key；缺 key 必红）', async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    await proposeAndCommit(FIX.prompt, env);
    const r = env.policySaw.current;
    assert.ok(r, 'policy 应收到 synthEval');
    const dims = r.dimensions ?? [];
    assert.deepEqual(dims.map((d) => d.key), ['safety', 'trust'], 'dimensions.key 必须为 safety/trust');
    assert.deepEqual(dims.map((d) => d.name), ['safety', 'trust'], 'name 并存（兼容旧读取方，与 driver v0.2.9 同一契约）');
  } finally { env.cleanup(); }
});

test('commit synthEval 契约：sandbox 失败分支同样带 key + veto 语义', async () => {
  const env = makeEnv({ sandboxOk: false, policyDecision: 'AUTO_DEPLOY' });
  try {
    // sandbox ok=false → veto:true → 契约 mock 返回 REJECT → commit 抛错回滚
    await assert.rejects(async () => {
      await proposeAndCommit(FIX.prompt, env);
    }, /policyDecision=REJECT/);
    const r = env.policySaw.current;
    assert.ok(r, 'policy 应收到 synthEval（失败路径）');
    assert.deepEqual((r.dimensions ?? []).map((d) => d.key), ['safety', 'trust']);
    assert.ok((r.dimensions ?? []).every((d) => d.score.veto === true), '失败路径 veto 语义');
    // preimage 已恢复
    const restored = readFileSync(join(env.workdir, 'plugins/agint-mutator/prompts/sys-prompt.md'), 'utf8');
    assert.equal(restored, 'OLD prompt content');
  } finally { env.cleanup(); }
});

// ── diffStrategy 消费（v0.6.7）─────────────────────────────────────────
//
// `DiffStrategySchema` 声明了 unified_diff | line_replace，但 generatePostimage
// 一直只 return p.newText 整文件覆盖 —— 两个值**都没有消费**，契约形同虚设
// （docs/known-limitations/evolution-main-chain-not-energized.md:84 记过，一直没修）。
//
// 这一组是**消费方的判据**：全部 fixture 都用 unified_diff，所以上面 17 例全绿
// **并不能证明** line_replace 真的工作。必须单独测它，否则修了等于没修。

test("diffStrategy='line_replace'：只替换 oldText 那一段，文件其余部分逐字保留", async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    // preimage = 'OLD prompt content'（makeEnv 写入）。构造 oldText 命中其中的片段。
    const fix = {
      source: 'attribution-driven', failureId: 'f-lr', rootCause: 'PROMPT_DEFICIENCY',
      expectedEffect: 'baseline 通过率 >= 95% 在 7 天', rollbackCondition: 'regression -> rollback',
      atomicScope: 'prompt',
      promptPayload: { promptId: 'sys-prompt', oldText: 'OLD', newText: 'FRESH', diffStrategy: 'line_replace' },
    };
    const { commit: c } = await proposeAndCommit(fix, env);
    assert.equal(c.ok, true);
    const written = readFileSync(join(env.workdir, 'plugins/agint-mutator/prompts/sys-prompt.md'), 'utf8');
    // ⛔ 核心判据：局部替换，不是整文件覆盖
    assert.equal(written, 'FRESH prompt content',
      `line_replace 必须只换掉 oldText 那一段，实际写入：${JSON.stringify(written)}`);
    assert.ok(written.includes('prompt content'),
      'line_replace 把文件其余内容也弄丢了 —— 那就退化成整文件覆盖，这个字段仍然没意义');
  } finally { env.cleanup(); }
});

test("diffStrategy='unified_diff'：newText 视为完整内容，行为与历史逐字节一致", async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    const { commit: c } = await proposeAndCommit(FIX.prompt, env);   // fixture 用 unified_diff
    assert.equal(c.ok, true);
    const written = readFileSync(join(env.workdir, 'plugins/agint-mutator/prompts/sys-prompt.md'), 'utf8');
    // 历史行为 = return p.newText = 'new prompt'。这个断言锁的是「兼容性」，不是「正确性」。
    assert.equal(written, 'new prompt',
      'unified_diff 的历史行为是整文件覆盖；改它会让 30 处现有调用全部静默失败');
  } finally { env.cleanup(); }
});

test("diffStrategy='line_replace' 且 oldText 不在 preimage 里 ⇒ 必须 throw，不得整文件覆盖", async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    const fix = {
      source: 'attribution-driven', failureId: 'f-miss', rootCause: 'PROMPT_DEFICIENCY',
      expectedEffect: 'baseline 通过率 >= 95% 在 7 天', rollbackCondition: 'regression -> rollback',
      atomicScope: 'prompt',
      // preimage 是 'OLD prompt content'，这里给一个根本不存在的片段
      promptPayload: { promptId: 'sys-prompt', oldText: '这段文字不在文件里', newText: 'X', diffStrategy: 'line_replace' },
    };
    await assert.rejects(
      () => proposeAndCommit(fix, env),
      /找不到 oldText/,
      'oldText 找不到时必须 fail-closed：宁可不写，也不能把「改一段」变成「换掉整个文件」',
    );
    // ⛔ 文件必须原封不动
    const after = readFileSync(join(env.workdir, 'plugins/agint-mutator/prompts/sys-prompt.md'), 'utf8');
    assert.equal(after, 'OLD prompt content', 'throw 之后文件被改了 —— 失败路径没有 fail-closed');
  } finally { env.cleanup(); }
});

test("diffStrategy='line_replace' 且 oldText 出现多次 ⇒ 必须 throw，不猜哪一处", async () => {
  const env = makeEnv({ sandboxOk: true, policyDecision: 'AUTO_DEPLOY' });
  try {
    // 让 oldText 在 preimage 中出现两次
    writeFileSync(join(env.workdir, 'plugins/agint-mutator/prompts/sys-prompt.md'), 'A-A-B', 'utf8');
    const fix = {
      source: 'attribution-driven', failureId: 'f-dup', rootCause: 'PROMPT_DEFICIENCY',
      expectedEffect: 'baseline 通过率 >= 95% 在 7 天', rollbackCondition: 'regression -> rollback',
      atomicScope: 'prompt',
      promptPayload: { promptId: 'sys-prompt', oldText: 'A', newText: 'Z', diffStrategy: 'line_replace' },
    };
    await assert.rejects(() => proposeAndCommit(fix, env), /出现多次/,
      'oldText 不唯一时必须拒绝 —— 猜错一处就改了错误的地方');
    const after = readFileSync(join(env.workdir, 'plugins/agint-mutator/prompts/sys-prompt.md'), 'utf8');
    assert.equal(after, 'A-A-B', '拒绝后文件被改了');
  } finally { env.cleanup(); }
});