# Changelog — agint-mount

## 0.7.2 (2026-10-06) — 供料失败可见性（立项 B-2）

- health-probe / rollback 两处 `catch {}` 静默吞 ⇒ `catch (err) + console.warn`。
  mount 的失败模式此前从未进 failure_pattern 且无人知（category 越界抛错被吞）；
  配合 evolution-memory 0.6.14 归一化后，`mount`→`integration` 映射开始真实产行。
- 28/28 测试过。

## 0.7.1 (2026-10-05) — 实装 mount → population.ingest（此前只在文档里，被面板判为悬空声明）

**起因**：家族面板 0.2.4 起把「manifest 声明消费（`consumes` ∪ `optionalInject`）里、代码从不取用」
的键列为悬空声明。本插件的 `agint.population.ingest` 被点名，但这条与另外三条不同 ——
**它有设计依据**：`README.md:168`「mount → population｜`agint.population.ingest`（仅 SMOKE PASS 后调用）｜
新个体标记 `origin=synthesized`」，wiki `Sprint11-设计稿.md:169` 同源，初始 commit 起 dependencies 就含
`agint-population >=0.6.2`。老板拍「补接线」，本次实装。

### 新增（Added）

- `resolvePopulationIngest(ctx)`（导出）：按四种形态试解析 —— `ctx.get('agint.population.ingest')` /
  `ctx.getService('agint.population.ingest')` / `ctx.get('agint.population').ingest`（bind）/
  `ctx.getService('agint.population').ingest`（bind）。为什么不能只认一种：本文件里
  `resolveBusPublish` 上面那段注释记着 event-bus 那起事故 —— 只认伞键导致 10 处 `mount.*` 发布
  静默降级、生产存储 0 条、测试还全绿。agint-population 同时 provide 子键与裸键，两种都得试。
- `recordSynthesizedVariant(ctx, proposal, ticketId)`（导出，**软失败**）：SMOKE PASS 之后投 ingest，
  `source` 缺省时补 `'synthesized'`（自带 source 时尊重原归属，不覆盖）。
  三条自挡：服务缺位 / proposal 非法 / **proposal 缺 `expectedEffect` 或 `rollbackCondition`** ——
  最后一条必须前置挡：`agint-population/lib/index.js:134-146` 对这两个字段硬要求非空，缺了必抛错
  并顺带写一条 failure_pattern，等于挂载侧制造假失败样本。
- 调用点：`mountRequest` 里 SMOKE 通过后、4 态判定之前。返回体 `MountResult` 新增可选字段
  **`population: { ingested, variantId?, reason?, ticketId }`**（`src/types.ts`），
  `RESTART_REQUESTED` 与 `ACTIVATED` 两条返回带上它。
- **不改挂载结果**：登记失败只 `console.warn` 带原因，绝不抛错、绝不回滚 —— 产物已过 SMOKE，
  种群留痕是事后对账的事。

### 同步与版本

- `src/orchestrator.ts` 与 `src/types.ts` 同步改（K78：lib 是 tsc 产物）。⚠️ **本机无 TypeScript**
  （`command -v tsc` 空、三处 node_modules 均无 typescript），所以 lib 那份是按现有产物风格手写镜像，
  **未经 tsc 验证**；下次在有编译器的机器上 build 前需复核，别把这次改动当已编译产物对待。
- 版本位对齐：manifest 原 0.6.5、package.json 原 0.7.0（c1152b2「v0.7.0 真重启」只升了 package.json），
  两处本就不一致 → 一并对齐到 **0.7.1**。

### 测试

- 新增 `test/population-ingest.test.mjs`：4 条解析形态（含裸键必须 bind，否则 `this` 丢）+
  6 条软失败纪律（缺位 / 正常带 origin / 尊重原 source / 缺字段自挡且**不得**调到 ingest /
  ingest 抛错带回原因 / 非法 proposal）⇒ `ℹ tests 10 / pass 10 / fail 0`。
- 回归：`test/smoke.mjs` 12/12、`test/bus-resolve.test.mjs` 6/6。
- 家族面板 `test/q3-verdicts.test.mjs` 的悬空声明冻结集合随本次清空（仓库位 0 条）。

## 2026-09-20 — 事件总线接线（方案 A / A4）：修 bus 服务解析 + 补 hmr.settled 发布方

**⚠️ 修复一个长期静默故障**：`mountEventBusPublish` 取 bus 用的是
`ctx.getService('agint.eventBus')`（**伞键**），而 `agint-event-bus` 用 spec.provides 注册的
是**三个分服务名**（`agint.eventBus.publish` / `.subscribe` / `.inspect`），**伞键不存在**
→ publish 恒 `undefined` → 10 处 `mount.*` 发布全部静默降级到 `ctx.emitEvent`。
与生产「mount.requested / succeeded / failed / restart-* 合计 0 条」完全吻合。

- 新增 `resolveBusPublish()` / `resolveBusSubscribe()`：三形态探测
  （分服务名 → `getService` 伞键 → `ctx.get` 伞键），取到伞键时 bind 防丢 this
- `awaitHmrSettleBus()` settle 成功后补发 `hmr.settled`（该 topic 此前只有占位订阅、无发布方）
- src（TS 源码）与 lib（dsh 实际加载）**两边同步**修改
- 新增 `test/bus-resolve.test.mjs`（6 项）；既有 smoke 12/12 通过

> 教训：「有 10 处调用点」≠「调用成功」。数调用点只证明有人喊，不证明有人应。

> 所有破环性变更必须写入本文件。变更流程：FROZEN schema（`mount-result.schema.yaml` + `MountResultSchema` + `ContractCheckSchema`）修改走 L0 治理（人类多签 + 7 天影子 + major 版本），其它按 semver。

---

## v0.7.0 — 4 态路径真重启（2026-09-16）

**变更（2026-09-16）**：4 态路径（plugin 声明新 npm 依赖）从「假重启」改为「真重启 dsh」。

- `requestRestart()` 由写 sentinel.lease 占位改为调 `agint.restart.request({ confirm: true, force: false })` 真重启；`agint.restart` 不可用时软降级写 sentinel lease（v0.6.5 兼容）。
- 删去 `waitSentinelLease()`（原 `setTimeout(1000)` 假等待）。
- 顺序调整：重启被接受后**先写 patch.yml（趁旧进程还活着）再让当前进程退出**；HMR settle + ACTIVATED 由**新 dsh 启动钩子 `mountResumeOnBoot`** 跨进程续接（旧进程没加载新 plugin，原地等必然失败）。
- tickets 表加 `restartRequestId` / `restartResultFile` / `restartMode` 三字段（zod schema 加 optional，schemaVersion 维持 1，向后兼容旧记录）。
- 重启被拒（cooldown/tripped）→ 标 `ROLLED_BACK`（非 `DISABLED`）；新 dsh 启动钩子里重启失败 → 撤 patch 行 + `ROLLED_BACK`；plugin 代码本身有问题 → `DISABLED`。
- `mount.request` 对 4 态 plugin 现返回 `phase: 'RESTART_REQUESTED'`（旧行为假返回 `ACTIVATED`）；真正 `ACTIVATED` 由新 dsh 启动钩子推进后落地。
- 新增事件 `mount.restart-requested` / `mount.restart-completed` / `mount.restart-failed`（复用 `mountEventBusPublish` 双轨通道）。

**风险**：P0（触及重启链路 + 跨进程状态续接）。未做环形依赖（mountOrder 40 < restart 50，重启调用走 `getService('agint.restart')` 懒取，不硬 inject）。

**关联**：`proposals/agint-mount-integrate-restart.md`；姊妹提案 `proposals/agint-restart-rollback.md`。

---

## v0.7.1-draft — 撤回：restart_detect 改独立插件 agint-restart

**本节变更（2026-09-10）**：v0.7.1-draft 原本尝试在 `agint-mount` 内加 `agint.mount.restart_detect` 服务。

**老板 review 后判定**：重启检测是 DSH host 通用能力，**不属于 mount 编排业务**。`agint.mount.*` 命名限制了其它插件消费；持久化借 agint_mount 域触发 L0 治理边界争议；活动追踪反向耦合到 mount 事件源。

**行动**：
- 本节代码（orchestrator.ts / lib/orchestrator.js / lib/index.js / manifest.json / smoke case 13-16 / README 第 4 service 入口）**已回退**到 v0.6.6
- 重启检测能力改独立插件 `plugins/agint-restart/`（scope 与 `dsh-resume-on-restart` 1:1：进程级重启检测 + 信息性消息投递 + 优雅关闭钩子）
- mount 仓库文件从 host 副本全量回退到 v0.6.6/0.7.0 原状

**回退原因详见老板批语 + `D:\DSH\project\research\dsh-resume-on-restart\ANALYSIS-2.md` §6 "新插件" 段。**

---

## v0.6.6 — 2026-09-04 — ticketId optional + 跨平台 smoke fix

**修复 + 增强**（patch bump；不破环 FROZEN schema / 不动 mount.* 状态机）。

### 修复（Fixed）

- **`agint.mount.status` ticketId 改 optional**（`lib/orchestrator.js:328` → `lib/orchestrator.js:z.string().min(1).optional()`）：
  - 不传 ticketId → 返回 `{mode:'list', count, pending:[...]}` 列出所有非终态 tickets
    （终态 `HEALTHY` / `ROLLED_BACK` 不列；非终态 `PREPARED/INSTALLED/RESTART_REQUESTED/ACTIVATED/DISABLED` 全列）
  - 传 ticketId → 返回 `{mode:'single', ...ticket, probeStats, createdAt}`（向后兼容 envelope 增加 `mode` 字段）
  - **来源**：`tools.js` 注释早在 2026-09-04 就提出 host-side zod 改 optional 是 host-side 修复路径，本次落地

- **`agint.mount.rollback` ticketId 改 optional**（dry-run listing）：
  - 不传 ticketId → 返回 `{mode:'list', dryRun:true, reason, count, rollbackable:[...], noop:[...]}`
    **不写 storage、不发 `mount.failed` 事件、不动状态机**——纯只读 preview
  - 传 ticketId → 走原回滚流程（向后兼容 envelope 增加 `mode` 字段）
  - **设计意图**：rollback 是人类否决权入口；"先看哪些可以回滚"是合理的只读探查需求；
    但必须 dry-run 隔离，绝不能因为缺 ticketId 而批量回滚

### 修复（Fixed — smoke）

- **`test/smoke.mjs` case 8**：跨平台临时目录。`/tmp` 在 Windows 下被 mkdir 解析为盘符根 EPERM；
  改为 `os.tmpdir()`（`node:os`）。这让 case 8 真正跑真 `lib/orchestrator.js` 而非 stub——之前的 stub
  兜底掩盖了 Windows smoke 永远走 stub 的事实。

### 新增（Added）

- **smoke case 11**：`mount.status` 不传 ticketId → 列表模式断言（4 个非终态列出，HEALTHY/ROLLED_BACK 不列）
- **smoke case 12**：`mount.rollback` 不传 ticketId → dry-run listing 断言（不写不触发；events 数组为空）

### 红线遵守

- ✅ 不修改 `mount-result.schema.yaml` FROZEN 字段（mount.status / mount.rollback 不是 MountResult 子集，是独立 service 签名）
- ✅ 不触碰 `agint_meta` 存储域
- ✅ 不破坏既有 18 个插件
- ✅ 不动 mount.* 状态机语义（终态判定集合 `TERMINAL` / `ROLLBACKABLE` / `NOOP` 与 smoke 的 `TERMINAL_PHASES` 严格一致）
- ✅ dry-run 模式明确隔离（events.length === 0，phase 未被改写）

### 验证

- ✅ `node test/smoke.mjs` — **12/12 用例契约层验证全过**（10 原有 + 2 新增）
- ⏳ `bin/plugin-check.sh plugins/agint-mount` — 待老板跑（lint 模式不阻断）

### 不在本 patch

| 范围 | 责任方 | 备注 |
|---|---|---|
| 工具层批量补 Batch 1（mount_status / mount_rollback preset row） | 待老板走 `bin/safe-update.sh restart` 后生效 | 本次不动 preset 文件 |
| `mount.request` ticketId 改 optional | **不做** | mount.request 是写操作入口，必须给完整输入 |
| 真实 dsh HMR 探针（替代 probeStaging stub） | Sprint 11 第 2 周 codex-D | 与本 patch 无关 |

---

## v0.7.0 — 未发布 — Sprint 12

### 调研（Investigated）

- **mount 健康探针信号源**（B5）：调研 dsh 是否暴露可注入的真实心跳接口，用于替换
  `src/health-probe.ts` 的 mock 心跳（`probeStaging` stub）。

  **结论：dsh v0.1.1-rc.2 暂未暴露显式心跳 service。保留 mock fallback，`health-probe.ts` 行为不变。**

  **语义原话不变**：连续成功 ≥ 3 次 → `HEALTHY`；**失败 ≥ 2 → DISABLE**（不删除 plugin；保留现场供归因）。
  探针函数仍由 `probeFn` 注入，默认 `probeStaging` stub；本次不改 `manifest.json` 的 `optionalInject`
  （不硬猜不存在的服务名）。

  **调研证据**（4 路交叉验证，均为空）：

  1. `grep -rlniE "heartbeat|readiness|liveness|keepalive|\bpulse\b" --exclude-dir=node_modules .`
     于 `@deepseek-ai/dsh@0.1.1-rc.2` 包根 → **0 命中**（`lib/` 仅 5 个 bundle 文件，无心跳符号）。
  2. 展开到真实运行时 `node_modules/@deepseek-ai/dsh-*`（187 个包）同 grep → 53 个文件命中，
     **逐一核验后全部是 JSDoc 散文，无任何 API/service**。代表性证据：
     - `dsh-agent/lib/types/index.d.ts:204` — `presence is neither liveness proof nor authorization`
     - `dsh-client-connection/lib/types/client/connection.d.ts:55` — `Re-read both mutable liveness guards…`
     - `dsh-client-runtime/lib/types/client/sessions/service.d.ts:370` — `The one aliveness predicate…`
     - `dsh-session/lib/types/types.d.ts:354` — `NOT a liveness signal about other…`
     - `dsh-session-telemetry-otel/lib/types/index.d.ts:38` — `keepAlive` 仅为 OTel SDK 传输选项
  3. 活运行时 Inspect `Service.listService`（host）→ **55 个 service 全表**，
     无 `host.heartbeat` / `health.heartbeat` / `core.pulse`，无任何 health/liveness/readiness 类 service。
  4. 活运行时 Inspect `Event.listEvents`（host）→ **53 个 event 全表**，同样无心跳/健康类事件
     （最接近的仅 `agent/status` 的 idle⇄running，语义是 agent 忙闲，非进程存活探针）。

  **回归条件**：待 dsh 暴露稳定心跳 service 后回归本项——届时在 `manifest.json` 的
  `optionalInject` 加该服务名，`health-probe.ts` 改用该接口，且**必须保留 mock fallback**
  （service 不可用时只 log 一行 warning 降级为 mock，**不得立即 DISABLE**）。

---

## v0.6.5 — 2026-08-26 — Sprint 11 收口

**首次发版**（codex-A 子任务 #1 交付物）。

### 新增（Added）

- **3 个 Service**（设计稿 §4.1）：
  - `agint.mount.request` — 受理挂载请求（proposal + verdict）→ 三段式事务编排 → MountResult
  - `agint.mount.status` — 查询 ticket 当前阶段 + 探针历史
  - `agint.mount.rollback` — 显式回滚（人类否决权入口）

- **三段式事务**（`src/orchestrator.ts`，设计稿 ADR-11-3）：
  - `PREPARE`：产物写入 `~/.dsh/profiles/web/plugins/<id>/`
  - `SMOKE`：调 `agint.qualitySandbox.runVerify / runExplore`；沙箱不可用 → decision 降级 `PENDING_REVIEW`（红线：不 AUTO_DEPLOY）
  - `ACTIVATE`：两段式 commit（spike 决策）

- **4 态状态机**（spike 决策后扩，区别于 Sprint 11 设计稿字面）：
  - 3 态路径（A：plugin 只用 dsh 已闭包内依赖）：`PREPARED → ACTIVATED → HEALTHY / DISABLED`
  - 4 态路径（B：plugin 声明新 npm 依赖）：`PREPARED → INSTALLED → RESTART_REQUESTED → ACTIVATED → HEALTHY / DISABLED`

- **两段式 commit**（`src/patch.ts`，spike 决策红线）：
  - 写 patch.yml 前先 atomic backup `.bak-<timestamp>`
  - HMR apply 成功后再删 `.bak-*`
  - HMR apply 失败 → agint-mount 自己从 backup 恢复 YAML + dispose 新 entry
  - 原因：`EntryGroup.update()` 只回滚 memory tree，不回滚磁盘 YAML

- **健康探针**（`src/health-probe.ts`，设计稿 ADR-11-3）：
  - 连续成功 ≥ 3 → `HEALTHY`
  - 连续失败 ≥ 2 → `DISABLE`（不删除 plugin；保留现场供归因）
  - 探针函数由 `agint.probeFn` Service 注入；默认 `probeStaging` stub

- **3 张数据表**（`src/storage.ts`，独占 `agint_mount` 域）：
  - `tickets` (≤200) — 事务票据 + 当前 phase + 探针统计
  - `probe_history` (≤2000) — 探针历史
  - `rollback_log` (≤200) — 回滚留痕（含 stage 倒序动作）

- **对外事件语义命名**（`mount.requested` / `mount.succeeded` / `mount.failed`，设计稿 ADR-11-1）：
  - Sprint 11 点对点发到 `agint.evolution.recordEvent`（软依赖失败不阻断）
  - Sprint 12 Event Bus 替换 transport（仅换传输层）

- **FROZEN `mount-result.schema.yaml`**（设计稿 §4.2）：
  - 7 值 phase enum（含 INSTALLED / RESTART_REQUESTED）
  - contractCheck 三布尔（signatureDiff / domainIsolation / dependencyWhitelist）
  - frozenness: L0 — Sprint 11 内禁改

- **L0 隔离 hook 留位**（`src/orchestrator.ts`）：
  - `l0IsolationCheck(proposal, verdict) → { signatureDiff, domainIsolation, dependencyWhitelist }`
  - 默认 noop + TODO 注释；真正实现由 codex-B 注入（ctx.getService('agint.l0IsolationCheck')）
  - 任一 L0 检查失败 → 拒挂载（设计稿 ADR-11-4）

- **`bin/agint-mount.sh` SOP 衔接**：本插件不挂顶层 `cordis.patch.yml`；首次发版仅仓库 commit，由老板走 `bin/agint-mount.sh new plugins/agint-mount` 挂载（AGENTS.md 红线）。

### 红线遵守

- ✅ 不触碰 `agint_meta` 存储域（manifest.storage.domains = `["agint_mount"]`）
- ✅ 不破坏既有 18 个插件（新建独立插件，不修改任何既有源码）
- ✅ Sprint 11 内不修改 `mount-result.schema.yaml` FROZEN 字段
- ✅ 不抢活：不写 L0 隔离规则实现、不写 fixture 测试变异、不写 e2e 场景

### 不在本 Sprint（本插件的代码骨架边界）

| 范围 | 责任方 | 备注 |
|---|---|---|
| L0 隔离规则组（`agint-quality-static` 加 l0-isolation） | codex-B | orchestrator 留 hook；本 Sprint 不实装 |
| fixture 测试变异（`fixture-echo-tool` / `fixture-bad-deps`） | codex-C | 放 `fixtures/mount/`，永不进真实锦标赛 |
| 8 个 e2e 场景（S11-01 ~ S11-08） | codex-D | `eval/scenarios/` |
| 真实 dsh HMR 探针（替代 `probeStaging` stub） | codex-D | Sprint 11 第 2 周接入 |
| `dsh.profilesDir` Service | 红线 | 不使用；从 `process.env.DSH_HOME` 拼路径 |
| 客户端 HMR | 独立机制 `dsh-client-hmr` | Sprint 11 范围外；留痕到 ROADMAP |

### 验证

- ✅ `bin/plugin-check.sh plugins/agint-mount` — 8 维度清单（lint 模式不阻断；contract/storage/deps/permissions/lifecycle/tests/docs/changelog 全齐）
- ✅ `node test/smoke.mjs` — 10 用例契约层验证（FROZEN phase 7 值 / MountResult required / contractCheck 三布尔 / storage spec / LIMITS / manifest 8 维度 / YAML schema / mock mountRequest 端到端 / rollback 倒序 / 红线自检）
- ✅ `grep -r agint_meta plugins/agint-mount/` — 0 命中（不触碰禁域）

### 偏离设计稿

| 偏离 | 偏离原因 | 老板拍板风险 |
|------|---------|-------------|
| **状态机 3 态 → 4 态**（增加 INSTALLED / RESTART_REQUESTED） | Sprint 11 第 1 周 dsh 热加载 spike 结论：plugin 声明新 npm 依赖时无法 pure-HMR，必须 `pnpm install` + sentinel restart | **已采纳 spike 决策**（boss 拍板） |
| **probe 函数抽象 + 默认 stub**（`probeStaging`） | 真实 dsh 探针路径需 dsh HMR 心跳暴露，Sprint 11 第 2 周由 codex-D 接入 | **0 风险**：hook 接口已声明，迁移只换 Service 注入 |
| **`mount.failed` 走点对点 evolution.recordEvent** 而非 Event Bus | Sprint 12 才有 Event Bus；当前最小实现 | **0 风险**：事件语义命名已对齐 Sprint 12 |
| **orchestrator 内 `sleep 1s` 替代 `waitSentinelLease` 真实等待** | Sprint 11 骨架阶段；真实等待需 dsh Sentinel API | **0 风险**：默认 `__AGINT_MOUNT_TEST_NO_LEASE_WAIT__=true` 跳过；生产 dsh 注入 |
| **L0 隔离 hook 默认全 true**（不阻断） | 真正实现由 codex-B 注入；Sprint 11 骨架阶段不阻塞 | **0 风险**：hook 接口已声明；TODO 注释明示 |

---

*下一步：老板 review 后由 `bin/agint-mount.sh new plugins/agint-mount` 走 lint → 拍快照 → patch → 重启 → smoke 挂载。*
