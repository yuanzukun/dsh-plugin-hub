/**
 * agint-metrics unit tests — pure computeMetrics() against fake sources.
 * Run: node --test packages/agint-metrics/test/
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { computeMetrics, METRIC_DEFS, UNCOLLECTED } from '../lib/metrics.js';

const fakeCron = {
  health: () => ({
    healthy: false,
    issues: [{ id: 'memory-decay', reason: 'overdue by 30240 min' }],
    // 2026-11-08（提案 cdf41d63）：health() 现在给两个失效维度。
    staleOverdue: [{ id: 'memory-decay', reason: 'overdue by 30240 min' }],
    staleInactive: [{ id: 'wiki-lint', reason: 'inactive for 21 days (period 7 d)' }],
    jobs: [
      { id: 'memory-decay', overdueMs: 30240 * 60_000 },
      { id: 'wiki-lint', overdueMs: 0 },
      { id: 'evolve-review', overdueMs: 0 },
    ],
  }),
};

const fakeRules = {
  audit: () => ({
    rules: [],
    totals: { hits: 10, denies: 1, asks: 1, advisories: 8 },
  }),
  lint: async () => [{ ruleId: 'a', kind: 'duplicate-pattern' }, { ruleId: 'b', kind: 'invalid-pattern' }],
};

const fakeWiki = {
  lint: async () => ({
    checked: 7,
    brokenLinks: [{ from: 'a.md', target: 'b.md' }],
    contradictions: ['c.md'],
    orphans: ['d.md'],
    healthy: false,
  }),
};

const fakeMemory = {
  stats: async () => ({
    total: 17,
    byType: { lesson: 8, decision: 5, preference: 1, pattern: 3 },
    byLevel: { L1: 12, L2: 3, L3: 2 },
    avgConfidence: 0.62,
  }),
};

test('METRIC_DEFS covers the computable PLAN metrics', () => {
  const keys = METRIC_DEFS.map((d) => d.key);
  for (const k of ['cron.staleJobs', 'cron.staleOverdue', 'cron.staleInactive', 'cron.maxOverdueDays',
    'rules.hits', 'rules.blocked', 'rules.adherencePct', 'rules.lintIssues', 'wiki.brokenLinks',
    'wiki.contradictions', 'wiki.orphans', 'memory.total', 'memory.avgConfidence']) {
    assert.ok(keys.includes(k), `missing metric key ${k}`);
  }
});

test('UNCOLLECTED honestly lists the session-log metrics', () => {
  const keys = UNCOLLECTED.map((d) => d.key);
  assert.ok(keys.includes('flattery.rate'));
  assert.ok(keys.includes('tasks.stepsMedian'));
});

test('computeMetrics with all sources returns expected values', async () => {
  const recs = await computeMetrics({ cron: fakeCron, rules: fakeRules, wiki: fakeWiki, memory: fakeMemory });
  const byKey = new Map(recs.map((r) => [r.key, r]));

  // cron
  assert.equal(byKey.get('cron.staleJobs').value, 2, 'staleJobs = 两个维度的并集（memory-decay + wiki-lint）');
  assert.equal(byKey.get('cron.staleOverdue').value, 1, '过期未跑维度');
  assert.equal(byKey.get('cron.staleInactive').value, 1, '久未活动维度');
  assert.equal(byKey.get('cron.maxOverdueDays').value, 21); // 30240 min = 21 days
  // rules
  assert.equal(byKey.get('rules.hits').value, 10);
  assert.equal(byKey.get('rules.blocked').value, 2);
  assert.equal(byKey.get('rules.adherencePct').value, 80); // (10-2)/10
  assert.equal(byKey.get('rules.lintIssues').value, 2);
  // wiki
  assert.equal(byKey.get('wiki.brokenLinks').value, 1);
  assert.equal(byKey.get('wiki.contradictions').value, 1);
  assert.equal(byKey.get('wiki.orphans').value, 1);
  // memory
  assert.equal(byKey.get('memory.total').value, 17);
  assert.equal(byKey.get('memory.avgConfidence').value, 0.62);
});

test('computeMetrics skips rules.adherencePct when there is no gate activity', async () => {
  const quietRules = {
    audit: () => ({ rules: [], totals: { hits: 0, denies: 0, asks: 0, advisories: 0 } }),
    lint: async () => [],
  };
  const recs = await computeMetrics({ cron: fakeCron, rules: quietRules });
  const keys = recs.map((r) => r.key);
  assert.ok(!keys.includes('rules.adherencePct'), 'adherencePct must be omitted when hits === 0');
  assert.ok(keys.includes('rules.blocked'));
});

test('computeMetrics tolerates missing / unhealthy sources', async () => {
  const recs = await computeMetrics({});
  assert.equal(recs.length, 0);

  const broken = {
    cron: { health: () => { throw new Error('boom'); } },
    rules: { audit: () => { throw new Error('boom'); } },
    wiki: { lint: async () => { throw new Error('boom'); } },
    memory: { stats: async () => { throw new Error('boom'); } },
  };
  const recs2 = await computeMetrics(broken);
  assert.equal(recs2.length, 0);
});

test('computeMetrics handles sync and async source methods uniformly', async () => {
  const mixed = {
    cron: { health: () => ({ healthy: true, issues: [], jobs: [] }) },
    rules: { audit: () => ({ rules: [], totals: { hits: 3, denies: 0, asks: 0, advisories: 3 } }), lint: () => [] },
    wiki: { lint: async () => ({ checked: 0, brokenLinks: [], contradictions: [], orphans: [], healthy: true }) },
    memory: { stats: () => ({ total: 0, byType: {}, byLevel: {}, avgConfidence: 0 }) },
    eventBus: { metricsSnapshot: async () => ({ deadletterCount: 0, syncSubscriptions: 0 }) },
    // Day 0 扩展 source：全健康 ⇒ 每个可算 key（含 4 个新 key）都应出现
    skillAutocreate: { stats: () => ({ candidates: { total: 0, byStatus: {} } }) },
    evolution: { getLogRange: () => [] },
    skillsFs: { measure: () => ({ totalBytes: 0, fileCount: 0, roots: ['fake-root'], missingRoots: [] }) },
  };
  const recs = await computeMetrics(mixed);
  assert.equal(recs.length, METRIC_DEFS.length); // every computable key present
  const byKey = new Map(recs.map((r) => [r.key, r]));
  assert.equal(byKey.get('rules.adherencePct').value, 100);
  assert.equal(byKey.get('memory.avgConfidence').value, 0);
});

// ── cron 失效两维度（提案 cdf41d63，2026-11-08）──────────────────────────
describe('cron 失效两维度', () => {
  test('两个维度分开采集，staleJobs 是并集（去重）', async () => {
    const cron = {
      health: () => ({
        healthy: false,
        issues: [{ id: 'a' }],
        staleOverdue: [{ id: 'a' }, { id: 'b' }],
        staleInactive: [{ id: 'b' }, { id: 'c' }],
        jobs: [],
      }),
    };
    const recs = await computeMetrics({ cron });
    const byKey = new Map(recs.map((r) => [r.key, r]));
    assert.equal(byKey.get('cron.staleOverdue').value, 2);
    assert.equal(byKey.get('cron.staleInactive').value, 2);
    // 并集 = {a, b, c} —— b 两个维度都命中只算一次
    assert.equal(byKey.get('cron.staleJobs').value, 3, 'staleJobs 必须是并集去重，不是两个数相加');
  });

  test('旧宿主没有新字段时回落 issues（不静默变 0）', async () => {
    const cron = { health: () => ({ healthy: false, issues: [{ id: 'a' }, { id: 'b' }], jobs: [] }) };
    const recs = await computeMetrics({ cron });
    const byKey = new Map(recs.map((r) => [r.key, r]));
    assert.equal(byKey.get('cron.staleOverdue').value, 2, '没有 staleOverdue 时回落 issues 的条数');
    assert.equal(byKey.get('cron.staleInactive').value, 0, '没有 staleInactive 时记 0，不是不产出该 key');
    assert.equal(byKey.get('cron.staleJobs').value, 2);
  });

  test('两个维度都必须落表（否则看板读不到，等于没拆）', async () => {
    const recs = await computeMetrics({ cron: fakeCron });
    const keys = recs.map((r) => r.key);
    assert.ok(keys.includes('cron.staleOverdue'));
    assert.ok(keys.includes('cron.staleInactive'));
  });
});
