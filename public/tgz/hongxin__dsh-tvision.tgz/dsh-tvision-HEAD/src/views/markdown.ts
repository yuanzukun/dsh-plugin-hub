/**
 * Markdown rendering for the transcript: blocks, inline spans, and a
 * segment-aware wrapper.
 *
 * An agent's prose is markdown whether the transcript likes it or not — the
 * models emit headings, lists, emphasis, and code spans by habit — and
 * rendering the markers literally (`**bold**` with its asterisks) reads as
 * broken. This module turns a text piece into styled rows, following the
 * conventions terminal renderers converged on (pi's TUI, glamour, Claude
 * Code): structure is expressed with attributes — bold, underline — because
 * attributes survive every skin, and colour is spent where it says something
 * (an inline code span wears the palette's code colour, not an inverse bar; a
 * heading wears the palette's heading colour with a descending attribute
 * ladder, because a bold lead-in in the body must never outrank a heading).
 *
 * Two properties are load-bearing:
 *
 * - **Streaming safety.** Every marker is only consumed when its closing
 *   partner has arrived; a half-streamed `**bold` renders literally and
 *   becomes bold one chunk later. No partial state, no flicker.
 * - **The wrapper never lies about width.** Wrapping operates on grapheme
 *   clusters carrying styles, with the same kinsoku (禁則) and CJK rules the
 *   plain-text wrapper honours — a wide glyph is never split, closing
 *   punctuation never opens a line.
 * @module dsh-tvision/views/markdown
 */

import type { Style } from '../kit/cell.ts'
import type { ResolvedPalette } from '../kit/skin.ts'
import { NO_LINE_END, NO_LINE_START, splitUnits, spreadCjkLatin, textWidth } from '../kit/text.ts'

/** One styled run of text; consecutive runs with equal style are merged. */
export interface MdSeg {
  readonly text: string
  readonly style: Style
  /**
   * Marks a run whose characters are data — an inline code span — and which
   * must therefore reach the screen verbatim: no CJK/Latin seam dressing.
   */
  readonly verbatim?: true
}

/** One visual row: the plain text (search and snapshots read this) and runs. */
export interface MdRow {
  readonly text: string
  readonly segments: readonly MdSeg[]
}

/**
 * Render a markdown text as wrapped, styled rows.
 * @param text - The markdown source (a text piece; fences arrive only if the
 * caller did not split them — a stray fence line passes through literally).
 * @param width - The column budget for the body.
 * @param base - The body style spans compose over.
 * @param palette - The active skin, for the quote and task-marker roles.
 * @returns One row per visual line.
 */
export function markdownRows(
  text: string,
  width: number,
  base: Style,
  palette: ResolvedPalette,
): MdRow[] {
  if (width <= 0) return [{ text: '', segments: [{ text: '', style: base }] }]
  const rows: MdRow[] = []
  // Reference definitions may sit after their uses, so the targets are a
  // whole-document scan the inline pass consults.
  const references = collectReferenceTargets(text)
  for (const block of parseBlocks(text)) {
    // A heading is a break in the prose; give it a blank line of air unless
    // it opens the text, where a leading blank would float it off the top.
    if (block.kind === 'heading' && rows.length > 0) {
      rows.push({ text: '', segments: [{ text: '', style: base }] })
    }
    rows.push(...blockRows(block, width, base, palette, references))
  }
  return rows
}

/* ------------------------------------------------------------------ */
/* Block parsing                                                       */
/* ------------------------------------------------------------------ */

/** A parsed block-level element. */
type Block =
  | { kind: 'heading'; level: number; text: string }
  | { kind: 'hr' }
  | { kind: 'quote'; lines: string[] }
  | { kind: 'list'; items: ListItem[] }
  | { kind: 'table'; header: string[]; align: TableAlign[]; rows: string[][] }
  | { kind: 'paragraph'; text: string }

/** A table column's alignment, read off the delimiter row GFM-style. */
type TableAlign = 'left' | 'center' | 'right'

/**
 * The narrowest a table column may be squeezed before the grid stops reading
 * as a table. Below this the records stack instead — a five-column grid carved
 * into forty cells is a screen of fragments, not a table.
 */
const MIN_TABLE_COLUMN = 10

/** The rendered width of the column separator, ` │ `. */
const TABLE_GAP = 3

/** One list item: its marker (rendered), its content lines, and children. */
interface ListItem {
  /** The rendered marker, e.g. `• `, `1. `, `✓ `; width aligns continuations. */
  readonly marker: string
  readonly markerStyle: Style | 'task-done' | 'task-todo' | 'plain'
  /** Content lines of this item (already stripped of the source marker). */
  readonly lines: string[]
  /** Nested list items beneath this one; filled during parsing. */
  children: ListItem[]
}

/**
 * Split markdown source into blocks.
 *
 * Deliberately small: paragraphs, headings, rules, quotes, lists (with
 * nesting by two-space indent and task items), and GFM tables. A pipe row
 * without its delimiter is not a table yet and stays paragraph text, which
 * is also the streaming rule: the header renders as prose until the
 * delimiter arrives.
 * @param text - The markdown source.
 * @returns Blocks in document order.
 */
export function parseBlocks(text: string): Block[] {
  const lines = text.replace(/\r\n?/gu, '\n').split('\n')
  const blocks: Block[] = []
  let index = 0
  while (index < lines.length) {
    const line = lines[index] ?? ''
    if (line.trim() === '') {
      index++
      continue
    }
    const heading = /^(#{1,6})\s+(.*)$/u.exec(line)
    if (heading !== null) {
      blocks.push({ kind: 'heading', level: heading[1]?.length ?? 1, text: heading[2] ?? '' })
      index++
      continue
    }
    if (/^\s{0,3}(-{3,}|\*{3,}|_{3,})\s*$/u.test(line) && !isSetextUnderline(lines, index)) {
      blocks.push({ kind: 'hr' })
      index++
      continue
    }
    // A link-reference definition renders nothing; its target is collected
    // for the inline pass, so `[text][1]` resolves wherever it appears.
    if (REFERENCE_DEFINITION.test(line)) {
      index++
      continue
    }
    if (line.startsWith('>')) {
      const quoted: string[] = []
      while (index < lines.length) {
        const current = lines[index] ?? ''
        if (current.startsWith('>')) {
          quoted.push(current.replace(/^>\s?/u, ''))
          index++
          continue
        }
        // Lazy continuation: a non-blank, non-marker line extends the quote.
        if (current.trim() !== '' && !isBlockStart(current)) {
          quoted.push(current)
          index++
          continue
        }
        break
      }
      blocks.push({ kind: 'quote', lines: quoted })
      continue
    }
    if (isListMarker(line)) {
      const [items, next] = parseList(lines, index, '')
      blocks.push({ kind: 'list', items })
      index = next
      continue
    }
    const table = parseTable(lines, index)
    if (table !== undefined) {
      blocks.push(table.block)
      index = table.next
      continue
    }
    // Paragraph: until a blank line or the start of another block. A setext
    // underline closes the paragraph as a heading — `Sub\n---` is an h2, not
    // prose followed by a stray rule, which is what the web renders and what
    // the literal markers otherwise leave on screen.
    const paragraph: string[] = [line]
    index++
    while (index < lines.length) {
      const current = lines[index] ?? ''
      if (isSetextUnderline(lines, index)) {
        blocks.push({
          kind: 'heading',
          level: (current ?? '').trim().startsWith('=') ? 1 : 2,
          text: paragraph.join(' '),
        })
        index++
        paragraph.length = 0
        break
      }
      if (current.trim() === '' || isBlockStart(current) || isTableStart(lines, index)) break
      paragraph.push(current)
      index++
    }
    if (paragraph.length > 0) {
      blocks.push({ kind: 'paragraph', text: joinParagraph(paragraph) })
    }
  }
  return blocks
}

/**
 * Whether the line at `index` is a setext underline for the paragraph text
 * above it: up to three spaces, then only `=` or only `-`.
 *
 * Checked by the rule branch too, so a `---` under a paragraph is a heading
 * and not a rule — the two readings are ambiguous in the source and GFM
 * resolves them the same way.
 * @param lines - The whole document.
 * @param index - The candidate underline line.
 * @returns True when the line underlines the preceding paragraph.
 */
function isSetextUnderline(lines: readonly string[], index: number): boolean {
  if (index <= 0) return false
  const previous = lines[index - 1] ?? ''
  if (previous.trim() === '') return false
  const current = lines[index] ?? ''
  return /^\s{0,3}(={3,}|-{3,})\s*$/u.test(current)
}

/**
 * Join paragraph lines, honouring hard breaks.
 *
 * A trailing backslash or two trailing spaces mean what they say in GFM — the
 * break is visible — and everything else flows together with a space, which is
 * how the web reflows soft-wrapped source.
 * @param lines - The paragraph's source lines.
 * @returns The joined text with hard breaks kept as `\n`.
 */
function joinParagraph(lines: readonly string[]): string {
  let out = ''
  for (const line of lines) {
    if (out === '') {
      out = line
      continue
    }
    // The break marker belongs to the line ABOVE the break: two trailing
    // spaces or a backslash there end the line, and the next line starts
    // below it rather than flowing on.
    const hard = /[ \t]{2,}$|\\$/u.test(out)
    // Trailing whitespace is insignificant once the hard-break test has had
    // its say, and keeping it would leave double spaces at the join.
    const above = hard ? out.replace(/([ \t]{2,}|\\)$/u, '') : out.replace(/[ \t]+$/u, '')
    out = `${above}${hard ? '\n' : ' '}${line.replace(/[ \t]+$/u, '')}`
  }
  return out
}

/** A link-reference definition line: `[label]: destination "optional title"`. */
const REFERENCE_DEFINITION = /^ {0,3}\[([^\]]+)\]:\s*(\S+)(?:\s+"[^"]*")?\s*$/u

/**
 * Collect the document's link-reference definitions.
 *
 * Definitions may appear after their uses, so this is a whole-document scan
 * the inline pass consults; while a message streams, a reference whose
 * definition has not arrived renders literally and self-heals exactly when
 * the definition does — the same documented deviation the web's incremental
 * renderer carries.
 * @param text - The markdown source.
 * @returns Normalised label (lowercased) to destination.
 */
export function collectReferenceTargets(text: string): Map<string, string> {
  const targets = new Map<string, string>()
  for (const line of text.split('\n')) {
    const match = REFERENCE_DEFINITION.exec(line)
    if (match === null) continue
    const label = match[1]?.trim().toLowerCase()
    const url = match[2]
    if (label !== undefined && label !== '' && url !== undefined) targets.set(label, url)
  }
  return targets
}

/** Whether a line begins a construct the paragraph loop must yield to. */
function isBlockStart(line: string): boolean {
  return /^(#{1,6})\s/u.test(line)
    || /^\s{0,3}(-{3,}|\*{3,}|_{3,})\s*$/u.test(line)
    || line.startsWith('>')
    || isListMarker(line)
}

/** Whether a line opens a list item at any of the accepted indents. */
function isListMarker(line: string): boolean {
  return /^(-|\*|\+)\s\S/u.test(line) || /^\d{1,3}\.\s\S/u.test(line)
}

/** Split one table row into cells; outer pipes optional, `\|` is v1-out. */
function splitTableRow(line: string): string[] {
  let body = line.trim()
  if (body.startsWith('|')) body = body.slice(1)
  if (body.endsWith('|')) body = body.slice(0, -1)
  return body.split('|').map(cell => cell.trim())
}

/** Read one delimiter cell's alignment; undefined when it is not a delimiter. */
function delimiterAlign(cell: string): TableAlign | undefined {
  if (!/^:?-+:?$/u.test(cell) || !cell.includes('-')) return undefined
  if (cell.startsWith(':') && cell.endsWith(':')) return 'center'
  if (cell.endsWith(':')) return 'right'
  return 'left'
}

/** Whether the line pair at `index` opens a table (header row + delimiter). */
function isTableStart(lines: readonly string[], index: number): boolean {
  return parseTable(lines, index) !== undefined
}

/**
 * Parse a GFM table starting at `index`: a header pipe-row, a delimiter row
 * (`---`, `:---`, `---:`, `:---:` per cell), then consecutive pipe-rows.
 * The column counts must agree; anything else is not a table and stays
 * paragraph text, which keeps half-streamed tables honest — the header
 * renders as prose until its delimiter arrives.
 * @param lines - The document lines.
 * @param index - The candidate header row.
 * @returns The block and the index of the first line after the table.
 */
function parseTable(lines: readonly string[], index: number): { block: Block; next: number } | undefined {
  const headerLine = lines[index] ?? ''
  if (!headerLine.includes('|')) return undefined
  const delimiterLine = lines[index + 1] ?? ''
  if (!delimiterLine.includes('|') || !delimiterLine.includes('-')) return undefined
  const header = splitTableRow(headerLine)
  const delimiter = splitTableRow(delimiterLine)
  if (header.length !== delimiter.length || header.length === 0) return undefined
  const align: TableAlign[] = []
  for (const cell of delimiter) {
    const alignment = delimiterAlign(cell)
    if (alignment === undefined) return undefined
    align.push(alignment)
  }
  const rows: string[][] = []
  let cursor = index + 2
  while (cursor < lines.length) {
    const line = lines[cursor] ?? ''
    if (line.trim() === '' || !line.includes('|')) break
    const cells = splitTableRow(line)
    rows.push(cells.slice(0, header.length))
    cursor++
  }
  return { block: { kind: 'table', header, align, rows }, next: cursor }
}

/**
 * Parse a list (and its nested lists) starting at `index`.
 * @param lines - The document lines.
 * @param index - The first item's line.
 * @param depth - The nesting level, for two-space indent accounting.
 * @returns The items and the index of the first line after the list.
 */
function parseList(lines: string[], index: number, indent: string): [ListItem[], number] {
  const items: ListItem[] = []
  while (index < lines.length) {
    const line = lines[index] ?? ''
    if (line.trim() === '') {
      // A blank line ends the list unless the next non-blank line continues
      // it (loose list); look ahead one line.
      const after = lines[index + 1] ?? ''
      if (after.startsWith(indent) && (isListMarker(after.slice(indent.length)) || after.slice(indent.length).startsWith(' '))) {
        index++
        continue
      }
      break
    }
    if (!line.startsWith(indent)) break
    const rest = line.slice(indent.length)
    const marker = /^([*+-])\s(\S.*)$/u.exec(rest)
    const ordered = /^(\d{1,3}\.)\s(\S.*)$/u.exec(rest)
    if (marker === null && ordered === null) {
      // Continuation of the previous item, or the end of this list.
      if (rest.startsWith(' ') && items.length > 0) {
        const item = items[items.length - 1]
        if (item !== undefined) item.lines.push(rest.trim())
        index++
        continue
      }
      break
    }
    const rawMarker = marker?.[1] ?? ordered?.[1] ?? ''
    let content = marker?.[2] ?? ordered?.[2] ?? ''
    // Task list: `[x] `/`[ ] ` immediately after the bullet.
    const task = /^\[([ xX])\]\s+(.*)$/u.exec(content)
    let itemMarker = ordered !== null ? `${rawMarker} ` : '• '
    let taskState: 'task-done' | 'task-todo' | undefined
    if (marker !== null && task !== null) {
      taskState = (task[1] ?? ' ').toLowerCase() === 'x' ? 'task-done' : 'task-todo'
      content = task[2] ?? ''
      itemMarker = taskState === 'task-done' ? '✓ ' : '· '
    }
    const item: ListItem = {
      marker: itemMarker,
      markerStyle: taskState ?? 'plain',
      lines: [content],
      children: [],
    }
    items.push(item)
    index++
    // Nested list: the next line is indented deeper than this level — by
    // however much the writer chose (two spaces under a bullet, three under
    // `1. `); the nested run's own indent becomes its level's indent.
    {
      const nextLine = lines[index] ?? ''
      const nestedIndent = /^[ ]+/u.exec(nextLine)?.[0] ?? ''
      if (nextLine.trim() !== '' && nestedIndent.length > indent.length
        && isListMarker(nextLine.slice(nestedIndent.length))) {
        const [children, next] = parseList(lines, index, nestedIndent)
        const target = items[items.length - 1]
        if (target !== undefined) target.children = children
        index = next
      }
    }
  }
  return [items, index]
}

/* ------------------------------------------------------------------ */
/* Inline parsing                                                      */
/* ------------------------------------------------------------------ */

/**
 * Parse inline markdown into styled segments.
 *
 * Recognises `**bold**`, `*italic*` / `_italic_` (word-bounded), `` `code` ``
 * (the code colour, no background — a colour reads as emphasis, an inverse
 * bar reads as a highlighter swung at every mention), `~~strike~~` (strictly
 * spaced or word-bound content), and `[text](url)`. Every construct requires
 * its closing partner to have arrived, so a half-streamed marker renders
 * literally.
 * @param text - The source line, markers included.
 * @param base - The style segments compose over.
 * @param code - The palette's code style; its foreground colour is adopted.
 * @returns Styled segments covering the whole line.
 */
export function parseInline(
  text: string,
  base: Style,
  code: Style,
  references: ReadonlyMap<string, string> = new Map(),
): MdSeg[] {
  const segments: MdSeg[] = []
  // The scanning cursor over the raw source; plain text between constructs
  // accumulates in `pending`.
  let cursor = 0
  let pending = ''
  const flush = (style: Style): void => {
    if (pending === '') return
    segments.push({ text: pending, style })
    pending = ''
  }
  const source = text
  while (cursor < source.length) {
    const rest = source.slice(cursor)
    // Inline code: shortest `...` span; no nesting inside.
    if (rest.startsWith('`')) {
      const close = rest.indexOf('`', 1)
      if (close > 0) {
        flush(base)
        // Code characters are data: no CJK seam, no further parsing. Only
        // the foreground changes — the background stays the body's, so the
        // span reads as a colour and not as a block of highlighter.
        segments.push({ text: rest.slice(1, close), style: { ...base, fg: code.fg }, verbatim: true })
        cursor += close + 1
        continue
      }
    }
    // Bold, then italic on the single-character markers.
    if (rest.startsWith('**')) {
      const span = matchSpan(rest, '**')
      if (span !== undefined) {
        flush(base)
        segments.push(...parseInline(span, { ...base, bold: true }, code, references))
        cursor += span.length + 4
        continue
      }
    }
    if (rest.startsWith('~~')) {
      // Strict: inner content must not be empty, all-tilde, or
      // space-flanked tilde runs — `~~~` and `~~ ~~` stay literal.
      const span = matchSpan(rest, '~~')
      if (span !== undefined && !/^~+$/u.test(span.trim()) && span.trim() !== '') {
        flush(base)
        segments.push(...parseInline(span, { ...base, strike: true }, code, references))
        cursor += span.length + 4
        continue
      }
    }
    // An image is not a link wearing a hat: the web renders the picture, and
    // the terminal's honest equivalent is a named placeholder rather than the
    // source's literal bang and destination.
    const image = /^!\[([^\]\n]{0,120})\]\(([^()\s]{1,400})(?:\s+"[^"]*")?\)/u.exec(rest)
    if (image !== null) {
      const alt = image[1]?.trim() ?? ''
      flush(base)
      segments.push({ text: alt === '' ? '[img]' : `[img: ${alt}]`, style: { ...base, fg: code.fg } })
      cursor += image[0].length
      continue
    }
    // An autolink's angle brackets are syntax, not content: the web shows the
    // bare destination as the link.
    const autolink = /^<(https?:\/\/[^>\s]{3,400})>/u.exec(rest)
    if (autolink !== null) {
      flush(base)
      segments.push({ text: autolink[1] ?? '', style: base })
      cursor += autolink[0].length
      continue
    }
    const inline = /^\[([^\]\n]{1,200})\]\(([^()\s]{1,400})(?:\s+"[^"]*")?\)/u.exec(rest)
    if (inline !== null) {
      const label = inline[1] ?? ''
      const url = inline[2] ?? ''
      flush(base)
      segments.push(...linkSegments(label, url, base, code, references))
      cursor += inline[0].length
      continue
    }
    // A reference link resolves against the document's definitions; one whose
    // definition has not arrived stays literal and self-heals when it does —
    // the same streaming deviation the web's renderer documents.
    const reference = /^\[([^\]\n]{1,200})\]\[([^\]\n]{0,200})\]/u.exec(rest)
    if (reference !== null) {
      const label = reference[1] ?? ''
      const named = (reference[2]?.trim() || label).toLowerCase()
      const url = references.get(named)
      if (url !== undefined) {
        flush(base)
        segments.push(...linkSegments(label, url, base, code, references))
        cursor += reference[0].length
        continue
      }
    }
    const shortcut = /^\[([^\]\n]{2,80})\]/u.exec(rest)
    if (shortcut !== null && references.has((shortcut[1] ?? '').toLowerCase())) {
      const label = shortcut[1] ?? ''
      flush(base)
      segments.push(...linkSegments(label, references.get(label.toLowerCase()) ?? '', base, code, references))
      cursor += shortcut[0].length
      continue
    }
    if (rest.startsWith('*') || (rest.startsWith('_') && !/\w|$/u.test(source[cursor - 1] ?? ''))) {
      const marker = rest[0] ?? ''
      const span = matchSpan(rest, marker, source[cursor - 1])
      if (span !== undefined) {
        flush(base)
        segments.push(...parseInline(span, { ...base, italic: true }, code, references))
        cursor += span.length + 2
        continue
      }
    }
    pending += source[cursor]
    cursor += 1
  }
  flush(base)
  // The CJK/Latin seam is display dressing; code runs are data and keep their
  // characters exactly as the model wrote them.
  return segments.map(segment =>
    segment.verbatim === true
      ? segment
      : { ...segment, text: spreadCjkLatin(segment.text) }
  )
}

/**
 * Match a closing-delimited span at the start of `rest`.
 * @param rest - The remaining source, starting at the opener.
 * @param opener - The delimiter, e.g. `**`.
 * @param before - The character before the opener (flanking check).
 * @param closeIndexHint - Precomputed close position, when the caller found one.
 * @returns The span's inner content, or undefined when unclosed.
 */
function matchSpan(rest: string, opener: string, before?: string, closeIndexHint?: number): string | undefined {
  const close = closeIndexHint ?? rest.indexOf(opener, opener.length)
  if (close < opener.length) return undefined
  const inner = rest.slice(opener.length, close)
  if (inner === '') return undefined
  // Delimiters need a non-space inner flank on both sides — `a * b * c` is
  // not emphasis — and `_` only at word boundaries.
  if (opener === '_' || opener === '*') {
    if (before !== undefined && /\w/u.test(before) && opener === '_') return undefined
    if (inner.startsWith(' ') || inner.endsWith(' ')) return undefined
  }
  return inner
}

/* ------------------------------------------------------------------ */
/* Blocks to rows                                                      */
/* ------------------------------------------------------------------ */

/** Render one block as rows. */
/**
 * Rows for one block.
 * @param block - The block to render.
 * @param width - The column budget.
 * @param base - The body style.
 * @param palette - The active skin.
 * @param references - The document's link-reference targets, consulted by the
 * inline pass; empty when a caller has none.
 * @returns One row per visual line.
 */
function blockRows(
  block: Block,
  width: number,
  base: Style,
  palette: ResolvedPalette,
  references: ReadonlyMap<string, string>,
): MdRow[] {
  switch (block.kind) {
    case 'heading': {
      // The ladder is one colour descending by attribute: `##` underlines as
      // a section, `###` stands plain, the rare deeper level dims. Two
      // properties are the point — the heading must outrank any bold lead-in
      // in the body beneath it, which another weight of body white could
      // never do, and the markers themselves are dropped, because a literal
      // `###` on screen reads as unparsed markup rather than as a level.
      const style = block.level <= 2
        ? { ...palette.heading, underline: true }
        : block.level === 3
          ? palette.heading
          : { ...palette.heading, dim: true }
      return wrapSegments(parseInline(block.text, style, palette.code, references), width).map(toRow)
    }
    case 'hr':
      return [{ text: '─'.repeat(width), segments: [{ text: '─'.repeat(width), style: base }] }]
    case 'quote': {
      const quoteStyle = { ...palette.reasoning, italic: true }
      const rows: MdRow[] = []
      for (const line of block.lines) {
        const inner = wrapSegments(parseInline(line, quoteStyle, palette.code, references), Math.max(1, width - 2))
        for (const line2 of inner) {
          rows.push({
            text: `│ ${line2.map(seg => seg.text).join('')}`,
            segments: [{ text: '│ ', style: palette.reasoning }, ...line2],
          })
        }
      }
      return rows
    }
    case 'paragraph':
      // A hard break inside the paragraph is a real line break; each stretch
      // between breaks wraps on its own.
      return block.text.split('\n').flatMap(stretch =>
        wrapSegments(parseInline(stretch, base, palette.code, references), width).map(toRow))
    case 'table':
      return tableRows(block, width, base, palette, references)
    case 'list':
      return listRows(block.items, width, base, palette, references, 0)
    /* c8 ignore next 2 -- the union is exhaustive. */
    default:
      return []
  }
}

/** Render list items (recursively) with hanging indents. */
function listRows(
  items: readonly ListItem[],
  width: number,
  base: Style,
  palette: ResolvedPalette,
  references: ReadonlyMap<string, string>,
  depth: number,
): MdRow[] {
  const rows: MdRow[] = []
  const indent = '  '.repeat(depth)
  for (const item of items) {
    const markerStyle = item.markerStyle === 'task-done'
      ? palette.toolSuccess
      : item.markerStyle === 'task-todo'
        ? palette.bodyText
        : base
    const room = Math.max(1, width - textWidth(indent) - textWidth(item.marker))
    const hang = ' '.repeat(textWidth(item.marker))
    // Each logical line wraps to `room` columns; the first visual row of the
    // first logical line carries the marker, every later visual row hangs by
    // the marker's width so content stays aligned.
    for (const [lineIndex, line] of item.lines.entries()) {
      const wrapped = wrapSegments(parseInline(line, base, palette.code, references), room)
      for (const [wrapIndex, segs] of wrapped.entries()) {
        const carriesMarker = lineIndex === 0 && wrapIndex === 0
        const prefixText = carriesMarker ? `${indent}${item.marker}` : `${indent}${hang}`
        const prefixSegs: MdSeg[] = carriesMarker
          ? [{ text: indent, style: base }, { text: item.marker, style: markerStyle }]
          : [{ text: prefixText, style: base }]
        rows.push({
          text: `${prefixText}${segs.map(segment => segment.text).join('')}`,
          segments: mergeSegs([...prefixSegs, ...segs]),
        })
      }
    }
    if (item.children.length > 0) rows.push(...listRows(item.children, width, base, palette, references, depth + 1))
  }
  return rows
}

/* ------------------------------------------------------------------ */
/* Tables                                                              */
/* ------------------------------------------------------------------ */

/**
 * Render a table: a grid when the measure can hold the columns, stacked cards
 * when it cannot.
 *
 * This is the one place the transcript buys real tabular reading — a model's
 * comparison of five options against three criteria carries meaning only
 * when the columns line up. The strategy follows what terminal renderers
 * (Claude Code among them) converged on: measure every column to its widest
 * cell, pad each cell to that width respecting the delimiter row's
 * alignment, and separate columns with a dim `│`.
 *
 * Two rules decide the layout, and the first one is not negotiable:
 *
 * - **No cell is ever cut.** A cell wider than the measure is wrapped inside
 *   its column, so a record grows a line instead of losing characters. The
 *   earlier fixed 24-column cap kept more tables in grid form by truncating
 *   their cells, which is exactly what a reader sees as "the text is cut".
 * - **A grid that would turn to mush stacks instead.** Columns shrink, but
 *   only down to {@link MIN_TABLE_COLUMN}; past that the records are worth
 *   more than the grid, and the pairing becomes one card per record.
 * @param block - The parsed table.
 * @param width - The body measure in columns.
 * @param base - The body style.
 * @param palette - The active skin, for the code and dim roles.
 * @returns One row per visual line.
 */
function tableRows(
  block: { header: string[]; align: TableAlign[]; rows: string[][] },
  width: number,
  base: Style,
  palette: ResolvedPalette,
  references: ReadonlyMap<string, string>,
): MdRow[] {
  // Cells parse in full and are measured after parsing, because links expand
  // (`label` → `label (url)`) and the seam dressing adds thin spaces — a cap
  // applied to the source text would measure the wrong string.
  const parseCell = (cell: string, style: Style): MdSeg[] =>
    parseInline(cell, style, palette.code, references)
  const headerSegs = block.header.map(cell => parseCell(cell, { ...base, bold: true }))
  const rowSegs = block.rows.map(row =>
    block.header.map((_name, column) => parseCell(row[column] ?? '', base)))
  const columnWidths = block.header.map((_name, column) => {
    let widest = textWidth(segsText(headerSegs[column] ?? []))
    for (const row of rowSegs) widest = Math.max(widest, textWidth(segsText(row[column] ?? [])))
    return widest
  })
  const gaps = TABLE_GAP * (block.header.length - 1)
  const naturalWidth = columnWidths.reduce((sum, w) => sum + w, 0)
  // A table that fits renders one line per record, exactly as it was written.
  if (naturalWidth + gaps <= width) {
    return alignedTableRows(headerSegs, rowSegs, block.align, columnWidths, base)
  }
  // It does not fit at its natural width: shrink the long columns and wrap
  // their cells, so the grid survives and every character is still shown.
  const fitted = fitTableColumns(columnWidths, width - gaps)
  if (fitted !== undefined) {
    return wrappedTableRows(headerSegs, rowSegs, block.align, fitted, base)
  }
  return stackedTableRows(headerSegs, rowSegs, base, width)
}

/**
 * Shrink a table's columns to a total budget, keeping every one of them wide
 * enough to read.
 *
 * The widest column gives way first — that is where the measure is being
 * spent and where a wrap costs the reader least — until the total fits.
 * Short columns (a status word, a count) keep their natural width.
 * @param widths - Natural column widths.
 * @param budget - Columns available for the cells, gaps already removed.
 * @returns The fitted widths, or undefined when even the floors do not fit.
 */
function fitTableColumns(widths: readonly number[], budget: number): number[] | undefined {
  if (budget <= 0) return undefined
  const floors = widths.map(width => Math.min(width, MIN_TABLE_COLUMN))
  if (floors.reduce((sum, width) => sum + width, 0) > budget) return undefined
  const fitted = [...widths]
  let total = fitted.reduce((sum, width) => sum + width, 0)
  // Bounded: every pass removes at least one column from the total, and the
  // floor sum is already known to fit.
  while (total > budget) {
    let widest = 0
    for (let column = 1; column < fitted.length; column++) {
      if ((fitted[column] ?? 0) > (fitted[widest] ?? 0)) widest = column
    }
    const current = fitted[widest] ?? 0
    const floor = floors[widest] ?? 0
    if (current <= floor) return undefined
    const reduce = Math.min(current - floor, total - budget)
    fitted[widest] = current - reduce
    total -= reduce
  }
  return fitted
}

/** The joined plain text of a segment list, as a row's `text` will read it. */
function segsText(segments: readonly MdSeg[]): string {
  return segments.map(segment => segment.text).join('')
}

/**
 * Pad a cell's segments to the column width. Padding lands on the first or
 * last segment (or both, for centre) so the row's plain text still measures
 * exactly the column arithmetic. An empty cell pads to blank spaces in the
 * given style.
 */
function padCell(segments: readonly MdSeg[], width: number, align: TableAlign, fill: Style): MdSeg[] {
  const pad = Math.max(0, width - textWidth(segsText(segments)))
  if (segments.length === 0) return [{ text: ' '.repeat(width), style: fill }]
  const out = [...segments]
  if (pad === 0) return out
  const lead = align === 'right' ? pad : align === 'center' ? Math.floor(pad / 2) : 0
  const trail = pad - lead
  if (lead > 0) {
    const first = out[0]!
    out[0] = { text: `${' '.repeat(lead)}${first.text}`, style: first.style }
  }
  if (trail > 0) {
    const last = out[out.length - 1]!
    out[out.length - 1] = { text: `${last.text}${' '.repeat(trail)}`, style: last.style }
  }
  return out
}

/** The dim rule under a header: column dashes joined at the crossings. */
function ruleRow(columnWidths: readonly number[], base: Style): MdRow {
  const dim = { ...base, dim: true }
  const segments: MdSeg[] = []
  columnWidths.forEach((width, column) => {
    if (column > 0) segments.push({ text: '─┼─', style: dim })
    segments.push({ text: '─'.repeat(width), style: dim })
  })
  return toRow(mergeSegs(segments))
}

/** The aligned grid: header, a dim rule, then rows with dim separators. */
function alignedTableRows(
  headerSegs: MdSeg[][],
  rowSegs: readonly MdSeg[][][],
  align: readonly TableAlign[],
  columnWidths: readonly number[],
  base: Style,
): MdRow[] {
  const rows: MdRow[] = []
  const dim = { ...base, dim: true }
  const separator: MdSeg = { text: ' │ ', style: dim }
  const joinCells = (cells: readonly MdSeg[][]): MdRow => {
    const segments: MdSeg[] = []
    cells.forEach((cell, column) => {
      if (column > 0) segments.push(separator)
      segments.push(...padCell(cell, columnWidths[column] ?? 0, align[column] ?? 'left', base))
    })
    return toRow(mergeSegs(segments))
  }
  rows.push(joinCells(headerSegs))
  rows.push(ruleRow(columnWidths, base))
  for (const row of rowSegs) rows.push(joinCells(row))
  return rows
}

/**
 * The wrapped grid: the same columns, with cells that overflow the measure
 * wrapped onto continuation lines instead of cut.
 *
 * One record occupies as many visual lines as its tallest cell needs; the
 * other cells pad on the blank lines so the `│` separators stay in one
 * column down the record. No character is dropped, which is the whole point.
 * @param headerSegs - The header cells, parsed.
 * @param rowSegs - The body cells, parsed.
 * @param align - Per-column alignment from the delimiter row.
 * @param columnWidths - The fitted column widths.
 * @param base - The body style.
 * @returns One row per visual line.
 */
function wrappedTableRows(
  headerSegs: MdSeg[][],
  rowSegs: readonly MdSeg[][][],
  align: readonly TableAlign[],
  columnWidths: readonly number[],
  base: Style,
): MdRow[] {
  const rows: MdRow[] = []
  const dim = { ...base, dim: true }
  const separator: MdSeg = { text: ' │ ', style: dim }
  const renderRecord = (cells: readonly MdSeg[][]): void => {
    const wrapped = columnWidths.map((columnWidth, column) =>
      wrapSegments(cells[column] ?? [], Math.max(1, columnWidth)))
    const height = wrapped.reduce((tallest, lines) => Math.max(tallest, lines.length), 1)
    for (let lineIndex = 0; lineIndex < height; lineIndex++) {
      const segments: MdSeg[] = []
      columnWidths.forEach((columnWidth, column) => {
        if (column > 0) segments.push(separator)
        const line = wrapped[column]?.[lineIndex] ?? []
        segments.push(...padCell(line, columnWidth, align[column] ?? 'left', base))
      })
      rows.push(toRow(mergeSegs(segments)))
    }
  }
  renderRecord(headerSegs)
  rows.push(ruleRow(columnWidths, base))
  for (const record of rowSegs) renderRecord(record)
  return rows
}

/** The stacked cards: one `header: value` block per record. */
function stackedTableRows(
  headerSegs: MdSeg[][],
  rowSegs: readonly MdSeg[][][],
  base: Style,
  width: number,
): MdRow[] {
  const rows: MdRow[] = []
  const blank: MdRow = { text: '', segments: [{ text: '', style: base }] }
  // The name column is the headers', not the values': cards align on the
  // field names, and a wide value must not indent every label.
  const nameWidth = Math.max(1, ...headerSegs.map(names => textWidth(segsText(names))))
  for (const [record, row] of rowSegs.entries()) {
    if (record > 0) rows.push(blank)
    headerSegs.forEach((nameSegs, column) => {
      const name = padCell(nameSegs, nameWidth, 'right', base)
      const label: MdSeg = { text: ': ', style: { ...base, dim: true } }
      const used = nameWidth + 2
      const room = Math.max(1, width - used)
      const wrapped = wrapSegments(row[column] ?? [], room)
      wrapped.forEach((line, index) => {
        const segments = [
          ...(index === 0 ? [...name, label] : [{ text: ' '.repeat(used), style: base }]),
          ...line,
        ]
        rows.push(toRow(mergeSegs(segments)))
      })
    })
  }
  return rows
}

/**
 * The segments for one rendered link.
 *
 * The label is parsed as markdown — `[**bold**](url)` bolds — and the
 * destination is shown beside it, which is the terminal's stand-in for the
 * web's clickable text: the URL is the affordance a terminal has.
 * @param label - The link text, markers included.
 * @param url - The resolved destination.
 * @param base - The style the label composes over.
 * @param code - The palette's code style, for nested spans.
 * @param references - The document's reference targets, for nested links.
 * @returns Segments covering the whole rendered link.
 */
function linkSegments(
  label: string,
  url: string,
  base: Style,
  code: Style,
  references: ReadonlyMap<string, string>,
): MdSeg[] {
  const bare = label === url || url === ''
  const shown = bare ? label : `${label} (${url})`
  // The label keeps its nested markers; the shown URL is plain text, so a URL
  // containing asterisks is never re-parsed as emphasis.
  const head = parseInline(bare ? shown : label, base, code, references)
  if (bare) return head
  // Merge the shown URL into the label's last run when their styles match, so
  // a plain link stays one segment — the same coalescing the wrapper applies,
  // kept here because parseInline's output is its own contract.
  const last = head[head.length - 1]
  if (last !== undefined && last.style.fg === base.fg && last.style.bg === base.bg
    && last.style.bold === base.bold && last.style.italic === base.italic
    && last.style.strike === base.strike && last.style.underline === base.underline
    && last.verbatim !== true) {
    return [...head.slice(0, -1), { text: `${last.text} (${url})`, style: last.style }]
  }
  return [...head, { text: ` (${url})`, style: base }]
}

/* ------------------------------------------------------------------ */
/* Segment-aware wrapping                                              */
/* ------------------------------------------------------------------ */

/** One grapheme cluster with its width and style. */
interface Unit {
  readonly text: string
  readonly width: number
  readonly style: Style
}

/**
 * Wrap styled segments to a column budget with the same discipline the
 * plain-text wrapper follows: word boundaries when there are any, hard cut
 * with kinsoku pull-back when a run has none, wide glyphs never split.
 * @param segments - The styled source.
 * @param width - The column budget.
 * @returns One segment list per visual line, equal styles merged.
 */
export function wrapSegments(segments: readonly MdSeg[], width: number): MdSeg[][] {
  if (width <= 0) return [segments.slice()]
  const units: Unit[] = []
  for (const segment of segments) {
    for (const unit of splitUnits(segment.text)) {
      units.push({ text: unit.text, width: unit.width, style: segment.style })
    }
  }
  const lines: Unit[][] = []
  let line: Unit[] = []
  let lineW = 0
  let index = 0
  while (index < units.length) {
    const unit = units[index]
    if (unit === undefined) break
    if (isWhitespace(unit.text)) {
      // A whitespace run carries onto the current line (and counts toward its
      // width); at a line start it is dropped, which is what makes a break
      // clean. The break itself below additionally trims a trailing run.
      const held: Unit[] = []
      while (index < units.length) {
        const probe = units[index]
        if (probe === undefined || !isWhitespace(probe.text)) break
        held.push(probe)
        index++
      }
      if (line.length > 0) {
        line.push(...held)
        lineW += sumWidth(held)
      }
      continue
    }
    // A word: the maximal run of non-whitespace units.
    const word: Unit[] = []
    let wordW = 0
    while (index < units.length) {
      const probe = units[index]
      if (probe === undefined || isWhitespace(probe.text)) break
      word.push(probe)
      wordW += probe.width
      index++
    }
    if (line.length > 0 && lineW + wordW > width) {
      // A wrapped line never shows its trailing break-space.
      lines.push(trimTrailingSpace(line))
      line = []
      lineW = 0
      // Re-attempt the word on the fresh line (index already advanced past it).
      if (wordW > width) {
        let rest = word
        while (sumWidth(rest) > width) {
          const head = cutUnits(rest, width)
          if (head.length === 0) break
          lines.push(head)
          rest = rest.slice(head.length)
        }
        line = rest
        lineW = sumWidth(rest)
      } else {
        line = word
        lineW = wordW
      }
      continue
    }
    if (wordW > width) {
      // A word too wide even alone: hard cut with kinsoku, from anywhere.
      let rest = word
      if (line.length > 0) {
        lines.push(line)
        line = []
        lineW = 0
      }
      while (sumWidth(rest) > width) {
        const head = cutUnits(rest, width)
        if (head.length === 0) break
        lines.push(head)
        rest = rest.slice(head.length)
      }
      line = rest
      lineW = sumWidth(rest)
      continue
    }
    line.push(...word)
    lineW += wordW
  }
  if (line.length > 0) lines.push(line)
  if (lines.length === 0) lines.push([])
  return lines.map(line => mergeSegs(line.map(unit => ({ text: unit.text, style: unit.style }))))
}

/** A copy of the line without its trailing whitespace units. */
function trimTrailingSpace(line: readonly Unit[]): Unit[] {
  let end = line.length
  while (end > 0 && isWhitespace(line[end - 1]?.text ?? '')) end--
  return line.slice(0, end)
}

/** Whether a cluster is breakable whitespace. */
function isWhitespace(text: string): boolean {
  return text === ' ' || text === '\t'
}

/** Sum the column widths of units. */
function sumWidth(units: readonly Unit[]): number {
  let total = 0
  for (const unit of units) total += unit.width
  return total
}

/**
 * The longest prefix a hard cut may take, guaranteed to make progress.
 *
 * The kinsoku pull-back can legitimately leave nothing to cut — a run of
 * closing punctuation at the break, or a wide glyph in a one-column budget —
 * and a cut that takes nothing would spin the wrapper on the same slice
 * forever. The leading cluster then goes on a line of its own and the painter
 * clips it, which loses at most the one column no layout could have given it.
 * @param units - The remaining units.
 * @param width - The column budget.
 * @returns At least one unit whenever the input is non-empty.
 */
function cutUnits(units: readonly Unit[], width: number): Unit[] {
  const head = takeUnitsKinsoku(units, width)
  if (head.length > 0) return head
  const first = units[0]
  return first === undefined ? [] : [first]
}

/**
 * Take the longest prefix of units that fits `width`, pulling back whole
 * clusters so closing punctuation never opens a line and opening brackets
 * never end one — the unit-level mirror of the plain-text cutter.
 */
function takeUnitsKinsoku(units: readonly Unit[], width: number): Unit[] {
  let count = 0
  let used = 0
  while (count < units.length) {
    const unit = units[count]
    if (unit === undefined || used + unit.width > width) break
    used += unit.width
    count++
  }
  for (;;) {
    const nextStart = units[count]?.text ?? ''
    if (count < units.length && NO_LINE_START.has(nextStart)) {
      if (count === 0) break
      count--
      continue
    }
    const lastEnd = units[count - 1]?.text ?? ''
    if (count > 0 && NO_LINE_END.has(lastEnd)) {
      count--
      if (count === 0) break
      continue
    }
    break
  }
  return units.slice(0, count)
}

/** Merge adjacent segments with equal style; equality is field-by-field. */
function mergeSegs(segments: readonly MdSeg[]): MdSeg[] {
  const out: MdSeg[] = []
  for (const segment of segments) {
    const last = out[out.length - 1]
    if (last !== undefined && styleEqual(last.style, segment.style)) {
      out[out.length - 1] = { text: last.text + segment.text, style: last.style }
      continue
    }
    out.push(segment)
  }
  return out
}

/** Field-by-field style equality (the renderer's own comparator). */
function styleEqual(a: Style, b: Style): boolean {
  return a.fg === b.fg && a.bg === b.bg && a.bold === b.bold && a.dim === b.dim
    && a.italic === b.italic && a.underline === b.underline && a.blink === b.blink
    && a.inverse === b.inverse && a.strike === b.strike
}

/** An MdRow from a wrapped line of segments. */
function toRow(segments: readonly MdSeg[]): MdRow {
  return { text: segments.map(segment => segment.text).join(''), segments }
}
