/**
 * The modal questions the harness asks, in one place.
 *
 * Kept out of `app.ts` because the application is already the largest module and
 * because these have a hard requirement worth isolating: **every question must
 * settle**. A promise that never resolves wedges an agent turn, and the ways to
 * leak one are not obvious — an Escape, a system box, an aborted signal, a
 * second dialog opened over the first. So the settle-once rule lives in
 * {@link Dialog} and the callers here only ever await.
 *
 * The approval path is the one with real consequences. DSH fails *closed*: with
 * nobody answering, every gated tool call is denied and the model is told there
 * is no approval channel. That makes this a functional requirement rather than
 * a nicety, and it is why the four outcomes below are the harness's own
 * vocabulary rather than anything invented here.
 * @module dsh-tvision/app/questions
 */

import type { DialogSpec, DialogResult } from '../views/dialogs.ts'

/** The harness's closed approval vocabulary. */
export type ApprovalOutcome = 'allowed-once' | 'rejected' | 'cancelled' | 'unavailable'

/** An approval request, as the waterfall delivers it. */
export interface ApprovalAsk {
  readonly toolName: string
  readonly reason?: string
  readonly signal?: AbortSignal
}

/** One structured question, as `ask_user_question` delivers it. */
export interface QuestionAsk {
  readonly id: string
  readonly question: string
  readonly header?: string
  readonly detail?: string
  readonly options?: readonly { label: string; description?: string }[]
  readonly multiSelect?: boolean
}

/** The answer shape `ask_user_question` expects back. */
export interface QuestionsAnswer {
  readonly answers: { id: string; selected: string[]; custom?: string }[]
}

/** The one thing this module needs from the application. */
export interface AskHost {
  /**
   * Put a modal question and wait for the answer.
   * @param spec - The question, detail, and choices.
   * @param signal - Optional lifetime; aborting dismisses.
   * @returns Everything the dialog settled with; `value` is undefined when
   * it was dismissed.
   */
  ask(spec: DialogSpec, signal?: AbortSignal): Promise<DialogResult>
}

/** The sentinel a multi-select question uses for "I am finished choosing". */
const DONE = '\u0000done'
/** The sentinel a single-select question uses for "I do not want to answer". */
const CANCEL = '\u0000cancel'
/** The sentinel for the free-text answer, which reopens with an input. */
const OTHER = '\u0000other'
/** The sentinel the free-text dialog uses for "send what was typed". */
const SEND = '\u0000send'

/**
 * Build the approval dialog.
 * @param request - The tool and reason.
 * @returns The dialog specification.
 */
export function approvalSpec(request: ApprovalAsk): DialogSpec {
  const question = request.reason === undefined
    ? `Allow ${request.toolName} to run?`
    : `${request.toolName}: ${request.reason}`
  return {
    title: 'Approval required',
    question,
    detail: [
      'The agent asked to run a tool that needs your decision.',
      '',
      `tool: ${request.toolName}`,
      ...(request.reason === undefined ? [] : ['', `reason: ${request.reason}`]),
      '',
      'Y allows this call only. The grant is one-shot by design: the harness',
      'records the decision in the session log and asks again next time.',
      '',
      'N, Escape, or closing this window refuses the call, and the model is',
      'told it was denied.',
    ].join('\n'),
    letterKeys: true,
    choices: [
      {
        value: 'allow',
        label: 'Allow once',
        detail: 'Run this one call; ask again next time.',
      },
      {
        value: 'deny',
        label: 'Deny',
        detail: 'Refuse; the model is told the call was denied.',
        dangerous: true,
      },
    ],
  }
}

/**
 * Ask for an approval decision.
 * @param host - The application's modal hook.
 * @param request - The tool and reason.
 * @returns The harness's outcome.
 */
export async function askApproval(host: AskHost, request: ApprovalAsk): Promise<ApprovalOutcome> {
  // The signal can abort *while the dialog is up*, which is what the second
  // check exists for. Reading it through a helper keeps the compiler from
  // treating that read as unreachable after the first one.
  const signal = request.signal
  const aborted = (): boolean => signal?.aborted === true
  if (aborted()) return 'cancelled'
  const value = (await host.ask(approvalSpec(request), signal)).value
  // An abort during the dialog is a withdrawal rather than a refusal, and the
  // harness records the two differently in its audit log.
  if (aborted()) return 'cancelled'
  if (value === 'allow') return 'allowed-once'
  if (value === 'deny') return 'rejected'
  return 'cancelled'
}

/** A call a breakpoint rule stopped, as the desktop asks about it. */
export interface BreakpointAsk {
  readonly toolName: string
  /** The call's one-line label — the same text the transcript card shows. */
  readonly label: string
  /** The rule's pattern, as typed. */
  readonly pattern: string
  readonly signal?: AbortSignal
}

/**
 * Build the breakpoint dialog.
 * @param request - The call, its label, and the rule that stopped it.
 * @returns The dialog specification.
 */
export function breakpointSpec(request: BreakpointAsk): DialogSpec {
  return {
    title: 'Breakpoint',
    question: `${request.toolName} stopped by ${request.pattern}`,
    detail: [
      'A rule you set stopped this call before it ran.',
      '',
      `tool: ${request.toolName}`,
      ...(request.label === '' ? [] : ['', `call: ${request.label}`]),
      '',
      'Y runs this one call; the rule asks again next time.',
      'a also covers every later call matching this rule, this session.',
      'n, Escape, or closing this window refuses the call, and the model is',
      'told it was denied.',
    ].join('\n'),
    letterKeys: true,
    choices: [
      {
        value: 'allow',
        label: 'Run once',
        detail: 'Run this call; the rule asks again next time.',
      },
      {
        value: 'always',
        label: 'Always this session',
        detail: 'Run it and stop asking for this rule this session.',
        letter: 'a',
      },
      {
        value: 'deny',
        label: 'Deny',
        detail: 'Refuse; the model is told the call was denied.',
        dangerous: true,
      },
    ],
  }
}

/**
 * Ask for a breakpoint decision.
 * @param host - The application's modal hook.
 * @param request - The call, its label, and the rule that stopped it.
 * @returns The decision: run once, grant the session, or refuse.
 */
export async function askBreakpoint(
  host: AskHost,
  request: BreakpointAsk,
): Promise<'allow' | 'always' | 'deny'> {
  // Dismissal and abort both refuse: a breakpoint is a stop the user asked
  // for, so the call must not slip through because its dialog went away.
  const value = (await host.ask(breakpointSpec(request), request.signal)).value
  if (value === 'allow') return 'allow'
  if (value === 'always') return 'always'
  return 'deny'
}

/**
 * Build the dialog for one question.
 *
 * A multi-select question is asked repeatedly — each answer toggles an option
 * and reopens the list with the chosen ones ticked and a `Done` row added — so
 * the widget layer needs no multi-select mode of its own.
 * @param question - The question.
 * @param chosen - Options chosen so far.
 * @returns The dialog specification.
 */
export function questionSpec(question: QuestionAsk, chosen: readonly string[]): DialogSpec {
  const choices: DialogSpec['choices'][number][] = (question.options ?? []).map(option => ({
    value: option.label,
    label: chosen.includes(option.label) ? `✓ ${option.label}` : option.label,
    ...(option.description === undefined ? {} : { detail: option.description }),
  }))
  // The free-text out; the option-count below must not count it.
  const optionCount = choices.length
  choices.push({ value: OTHER, label: 'Other…', detail: 'Answer with your own text.' })
  if (question.multiSelect === true) {
    // A multi-select always has a way out: `Done` once something is ticked, and
    // on an optionless question immediately, because an unanswerable window is
    // worse than a trivial one.
    if (chosen.length > 0) {
      choices.push({ value: DONE, label: `Done (${chosen.length} chosen)`, isDefault: true })
    } else if (optionCount === 0) {
      choices.push({ value: DONE, label: 'Done', isDefault: true })
    }
  } else if (optionCount === 0) {
    // A free-form question with no options: the only useful answer is to
    // decline, and saying so is better than an empty window.
    choices.push({ value: CANCEL, label: 'No answer', dangerous: true })
  } else {
    choices.push({ value: CANCEL, label: 'Cancel', dangerous: true })
  }
  return {
    title: question.header ?? 'Question',
    question: question.question,
    ...(question.detail === undefined ? {} : { detail: question.detail }),
    choices,
  }
}

/**
 * Ask a batch of structured questions, in order.
 * @param host - The application's modal hook.
 * @param questions - The questions.
 * @returns The answer to hand back to the harness.
 */
export async function askQuestions(
  host: AskHost,
  questions: readonly QuestionAsk[],
): Promise<QuestionsAnswer> {
  const answers: { id: string; selected: string[]; custom?: string }[] = []
  for (const question of questions) {
    const chosen: string[] = []
    let custom: string | undefined
    if (question.multiSelect === true) {
      // Repeated passes: each choice toggles and reopens until Done, or until
      // a free-text answer settles the whole question with the ticks kept.
      for (;;) {
        const value = (await host.ask(questionSpec(question, chosen))).value
        if (value === undefined || value === CANCEL || value === DONE) break
        if (value === OTHER) {
          const text = await askOtherText(host, question)
          if (text !== undefined) custom = text
          break
        }
        const index = chosen.indexOf(value)
        if (index >= 0) chosen.splice(index, 1)
        else chosen.push(value)
      }
    } else {
      const value = (await host.ask(questionSpec(question, chosen))).value
      if (value === OTHER) custom = await askOtherText(host, question)
      else if (value !== undefined && value !== CANCEL) chosen.push(value)
    }
    answers.push({ id: question.id, selected: chosen, ...(custom === undefined ? {} : { custom }) })
  }
  return { answers }
}

/**
 * Ask the free-text half of an Other… answer.
 * @param host - The application's modal hook.
 * @param question - The question being answered, for the title.
 * @returns The typed text, or undefined when sent empty or cancelled — an
 * empty free-text answer is no answer, and the harness reads it that way.
 */
async function askOtherText(host: AskHost, question: QuestionAsk): Promise<string | undefined> {
  const result = await host.ask({
    title: question.header ?? 'Question',
    question: 'Type your answer',
    input: { placeholder: 'Your answer — Enter sends it' },
    choices: [
      { value: SEND, label: 'Send', isDefault: true },
      { value: CANCEL, label: 'Cancel', dangerous: true },
    ],
  })
  if (result.value !== SEND) return undefined
  const text = result.input?.trim()
  return text === undefined || text === '' ? undefined : text
}

/** The sentinel values, exposed so the tests can assert on them. */
export const QUESTION_SENTINELS = Object.freeze({ done: DONE, cancel: CANCEL, other: OTHER, send: SEND })
