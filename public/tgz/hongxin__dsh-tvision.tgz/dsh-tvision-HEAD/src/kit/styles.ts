/**
 * Style-to-SGR translation and the attribute patch that keeps the emitted byte
 * stream small.
 *
 * A style is a record; a terminal wants a flat SGR parameter list. This module
 * owns that translation and the incremental logic around it: it can compute a
 * *patch* (the escapes needed to turn one style into another), which is what
 * lets the renderer emit two or three parameters for a colour change instead of
 * resetting and restating the whole style per cell.
 * @module dsh-tvision/kit/styles
 */

import { PALETTE_LIMIT } from './cell.ts'
import type { AnsiColor, Color, RgbColor, Style, StyleInput } from './cell.ts'

/**
 * Parameters that turn every attribute off and reset both colours to the
 * terminal default. Emitted whenever the target style is empty, and used as
 * the anchor for a full restate.
 */
export const SGR_RESET = '\u001B[0m'

/**
 * Split a 24-bit colour into its channels.
 * @param value - `0xRRGGBB`.
 * @returns The three channels, 0–255.
 */
function channels(value: RgbColor): [number, number, number] {
  return [(value >> 16) & 0xFF, (value >> 8) & 0xFF, value & 0xFF]
}

/**
 * The SGR parameters that set one colour slot.
 *
 * A colour's number means one of two things depending on where it came from:
 * a skin's own value is 24-bit RGB (and RGB can be numerically small — the
 * Borland blue `0x0000A8` is 168 decimal), while `resolveStyle`'s output on a
 * non-truecolour terminal carries a 256-palette *index*. The `[16, 256)` range
 * is therefore read as indices or as RGB according to `downgraded`, which the
 * renderer sets from whether it resolved the style it is emitting. Getting
 * this wrong one way reinterprets the index as near-black RGB; the other way
 * paints the whole desktop the cube colour of index 168 — pink.
 * @param color - The colour, or undefined for the terminal default.
 * @param layer - Whether this is the foreground or the background.
 * @param downgraded - Whether values in `[16, 256)` are palette indices (the
 * output of `resolveStyle`) rather than 24-bit values that happen to be small.
 * @returns Parameter list without the `ESC [` or `m`.
 */
function colorParams(color: Color, layer: 'fg' | 'bg', downgraded: boolean): string {
  if (color === undefined) return layer === 'fg' ? '39' : '49'
  if (downgraded && color >= PALETTE_LIMIT && color < 256) {
    // It must be emitted as `38;5;N`: the 24-bit form would reinterpret the
    // index as an RGB value (index 37 became RGB(0,0,37), a near-black), and
    // the 30-37/90-107 forms below only exist for the sixteen theme-remapped
    // colours.
    return `${layer === 'fg' ? 38 : 48};5;${color}`
  }
  if (color >= PALETTE_LIMIT) {
    const [r, g, b] = channels(color)
    // Always the explicit 24-bit form. The palette form would be shorter, but it
    // would also let the terminal's theme pick the colour, which is the one
    // thing a skin exists to decide.
    return `${layer === 'fg' ? 38 : 48};2;${r};${g};${b}`
  }
  const index = color as AnsiColor
  // 30-37/40-47 for the base eight, 90-97/100-107 for the bright eight.
  return index < 8
    ? String((layer === 'fg' ? 30 : 40) + index)
    : String((layer === 'fg' ? 90 : 100) + (index - 8))
}

/**
 * The attribute SGR parameters a style sets, plus the parameters that clear
 * the ones it does not. Emitting both directions is what makes a patch safe:
 * a cell that is no longer bold must actively turn bold off, because nothing
 * else will.
 * @param style - The style to describe.
 * @returns On and off parameter lists.
 */
function attrParams(style: Style): { on: string[]; active: boolean[] } {
  // Positionally parallel to ATTR_ENABLE_CODES: `on` holds the SGR parameters
  // that turn each attribute on, `active` says whether it is on at all. The
  // "off" direction is derived from `active` by position, because a flat
  // parameter list cannot express it (bold and dim share the code 22).
  const on: string[] = []
  const active: boolean[] = []
  for (let index = 0; index < ATTR_ENABLE_CODES.length; index++) {
    const enabled = (style as Record<string, boolean | undefined>)[ATTR_NAMES[index] ?? ''] === true
    active.push(enabled)
    if (enabled) on.push(ATTR_ENABLE_CODES[index] ?? '')
  }
  return { on, active }
}

/** Attribute names, positionally parallel to {@link ATTR_ENABLE_CODES}. */
const ATTR_NAMES = ['bold', 'dim', 'italic', 'underline', 'blink', 'inverse', 'strike'] as const

/** SGR parameters that turn each attribute on, positionally parallel to {@link ATTR_NAMES}. */
const ATTR_ENABLE_CODES = ['1', '2', '3', '4', '5', '7', '9'] as const

/**
 * SGR parameters that turn each attribute off, positionally parallel to
 * {@link ATTR_NAMES}. Bold and dim share 22, which is why they cannot be
 * looked up by parameter value.
 */
const ATTR_OFF_CODES = ['22', '22', '23', '24', '25', '27', '29'] as const

/**
 * The complete SGR sequence for a style, written from a clean slate.
 * @param style - The style to encode.
 * @param downgraded - Whether the style's `[16, 256)` colours are palette
 * indices (see the colour-space note on `colorParams`); a renderer emitting
 * resolved styles passes `true`, one emitting raw skin colours passes `false`.
 * @returns An escape sequence ending in `m`, or `''` for a wholly empty style.
 */
export function styleToSgr(style: Style, downgraded = true): string {
  if (isEmptyStyle(style)) return SGR_RESET
  const { on } = attrParams(style)
  const fg = colorParams(style.fg, 'fg', downgraded)
  const bg = colorParams(style.bg, 'bg', downgraded)
  // `0` first, so nothing has to be turned off explicitly: a full restate is
  // cheaper to reason about than to optimise, and it is emitted once per style
  // *change*, not once per cell.
  return `\u001B[0;${[...on, fg, bg].join(';')}m`
}

/**
 * Whether a style has no effect at all.
 * @param style - The style to test.
 * @returns True when nothing would be emitted for it.
 */
export function isEmptyStyle(style: Style): boolean {
  return style.fg === undefined
    && style.bg === undefined
    && style.bold === undefined
    && style.dim === undefined
    && style.italic === undefined
    && style.underline === undefined
    && style.blink === undefined
    && style.inverse === undefined
    && style.strike === undefined
}

/**
 * The escape sequence that turns `from` into `to` with the fewest parameters.
 *
 * Attributes are always restated in full (there are only seven and the
 * parameter list stays short), while a colour is emitted only when it actually
 * changed. Callers that pass the style currently active on the wire get a
 * correct patch; passing `undefined` yields a full restate.
 * @param from - The style the terminal is currently in.
 * @param to - The style the next cell needs.
 * @param downgraded - Whether the styles' `[16, 256)` colours are palette
 * indices (see {@link colorParams}); both styles share one terminal, so one
 * flag governs the pair.
 * @returns An escape sequence, or `''` when nothing has to change.
 */
export function stylePatch(from: Style | undefined, to: Style, downgraded = true): string {
  if (from === undefined) return styleToSgr(to, downgraded)
  const { on, active } = attrParams(to)
  const params: string[] = []
  if (from.fg !== to.fg) params.push(colorParams(to.fg, 'fg', downgraded))
  if (from.bg !== to.bg) params.push(colorParams(to.bg, 'bg', downgraded))
  // Order matters and is not cosmetic: SGR parameters take effect left to
  // right, and bold and dim share the reset code 22. Emitting `2;22` would set
  // dim and then immediately cancel it, so every "off" must precede every "on".
  const previous = attrParams(from)
  for (let index = 0; index < ATTR_NAMES.length; index++) {
    // The previous style had it on and the new one does not, so it has to be
    // turned off explicitly or the rest of the row inherits it.
    if (previous.active[index] === true && active[index] !== true) {
      params.push(ATTR_OFF_CODES[index] ?? '0')
    }
  }
  params.push(...on)
  // De-duplicate: two attributes can share a parameter (bold and dim are both
  // 22 when turning off), and repeating one is wasteful if harmless.
  const unique = [...new Set(params)]
  if (unique.length === 0) return ''
  return `\u001B[${unique.join(';')}m`
}

/**
 * Normalise a partial style input into a concrete style, filling absent
 * attribute slots with `false` so {@link styleEquals} can compare by value.
 * @param input - The partial style.
 * @returns A fully-specified style.
 */
export function normalizeStyle(input: StyleInput | undefined): Style {
  if (input === undefined) return {}
  const { fg, bg } = input
  return {
    fg,
    bg,
    bold: input.bold === true,
    dim: input.dim === true,
    italic: input.italic === true,
    underline: input.underline === true,
    blink: input.blink === true,
    inverse: input.inverse === true,
    strike: input.strike === true,
  }
}
