/**
 * Markdown renderer tests.
 *
 * The pins are the design table: every block type, every inline construct,
 * the streaming-safety rule (an unclosed marker renders literally), and the
 * wrapper's width invariants — kinsoku with styled spans, CJK seam, wide
 * glyphs never split — swept across the realistic width range.
 */
import { describe, expect, it } from 'vitest'
import { markdownRows, parseBlocks, parseInline, wrapSegments } from '../src/views/markdown.ts'
import { TURBO_VISION, resolvePalette } from '../src/kit/skin.ts'
import { splitUnits, textWidth } from '../src/kit/text.ts'

const palette = resolvePalette(TURBO_VISION)
const base = palette.bodyText
const code = palette.code
const rowsOf = (text: string, width = 60): string[] => markdownRows(text, width, base, palette).map(row => row.text)

describe('block parsing', () => {
  it('headings drop their markers at every level', () => {
    expect(rowsOf('# Ship it')).toEqual(['Ship it'])
    expect(rowsOf('## Ship it')).toEqual(['Ship it'])
    expect(rowsOf('### Deep')).toEqual(['Deep'])
    expect(rowsOf('#### Deeper')).toEqual(['Deeper'])
  })

  it('headings descend by attribute on the heading colour', () => {
    const [h2] = markdownRows('## One', 60, base, palette)
    const [h3] = markdownRows('### Two', 60, base, palette)
    const [h4] = markdownRows('#### Three', 60, base, palette)
    expect(h2?.segments[0]?.style).toMatchObject({ fg: palette.heading.fg, bold: true, underline: true })
    expect(h3?.segments[0]?.style).toMatchObject({ fg: palette.heading.fg, bold: true })
    expect(h3?.segments[0]?.style.underline).toBeUndefined()
    expect(h4?.segments[0]?.style).toMatchObject({ fg: palette.heading.fg, bold: true, dim: true })
  })

  it('a heading mid-text gains a blank line before it; an opening one does not', () => {
    expect(rowsOf('body first\n\n## One')).toEqual(['body first', '', 'One'])
    expect(rowsOf('## One\n\nbody')).toEqual(['One', 'body'])
  })

  it('rules render to the measure under all three spellings', () => {
    for (const rule of ['---', '***', '___']) {
      expect(rowsOf(rule, 40)).toEqual(['─'.repeat(40)])
    }
  })

  it('quotes take a bar, lose two columns, and keep it across wraps', () => {
    const rows = rowsOf('> quoted line that is long enough to wrap at this width for sure', 30)
    expect(rows.length).toBeGreaterThan(1)
    for (const row of rows) expect(row.startsWith('│ ')).toBe(true)
  })

  it('a lazy continuation line joins the quote', () => {
    const blocks = parseBlocks('> first\nstill the quote')
    expect(blocks).toEqual([{ kind: 'quote', lines: ['first', 'still the quote'] }])
  })

  it('lists: bullets, ordered alignment, nesting, and task items', () => {
    const rows = rowsOf('- one\n- two\n  - nested\n1. first\n2. second\n- [x] done\n- [ ] todo')
    expect(rows).toEqual(['• one', '• two', '  • nested', '1. first', '2. second', '✓ done', '· todo'])
  })

  it('a two-space-after-marker list line is a paragraph, not an item', () => {
    expect(rowsOf('-  two spaces')).toEqual(['-  two spaces'])
  })

  it('continuation lines hang under the content, marker-width aligned', () => {
    const rows = rowsOf('- a fairly long item that will wrap at this narrow measure', 24)
    expect(rows[0]).toMatch(/^• /u)
    for (const row of rows.slice(1)) {
      expect(row.startsWith('  ')).toBe(true)
      expect(row.startsWith('  •')).toBe(false)
    }
    const ordered = rowsOf('1. a fairly long item that will wrap here ok', 24)
    expect(ordered[0]).toMatch(/^1\. /u)
    expect(ordered[1]?.startsWith('   ')).toBe(true)
  })

  it('a pipe row without its delimiter stays paragraph text', () => {
    expect(rowsOf('a | b')).toEqual(['a | b'])
  })

  it('a table renders with truly aligned columns', () => {
    const rows = rowsOf('| module | role |\n|---|---|\n| kit | the substrate |\n| app | the desktop |')
    expect(rows).toEqual([
      'module │ role         ',
      '───────┼──────────────',
      'kit    │ the substrate',
      'app    │ the desktop  ',
    ])
    // The delimiter row's alignment is honoured: right pads left, centre splits.
    const aligned = rowsOf('| count | name |\n|---:|:---:|\n| 7 | x |')
    expect(aligned[2]).toBe('    7 │  x  ')
  })

  it('a table stacks field-per-record when the measure cannot hold it', () => {
    // Aligned this wants 6+3+9 = 18 columns; 17 cannot hold it, so the
    // pairing survives as one card per record instead of wrapping into mush.
    const rows = rowsOf('| module | role |\n|---|---|\n| kit | substrate |', 17)
    expect(rows).toEqual(['module: kit', '  role: substrate'])
  })

  it('a cell that fits the measure is shown in full', () => {
    const rows = markdownRows(
      '| name | notes |\n|---|---|\n| `x` | a-very-long-cell-that-will-not-fit |',
      60, base, palette,
    )
    // The cell is 33 columns in a 60-column measure: nothing to cut, and the
    // old fixed 24-column cap used to end it in an ellipsis anyway.
    expect(rows[2]?.text).toBe('x    │ a-very-long-cell-that-will-not-fit')
    expect(rows[2]?.segments?.some(segment => segment.style.fg === code.fg)).toBe(true)
  })

  it('a cell wider than the measure wraps inside its column instead of being cut', () => {
    const rows = rowsOf('| name | notes |\n|---|---|\n| `x` | a-very-long-cell-that-will-not-fit |', 24)
    expect(rows.join('')).not.toContain('…')
    // The value continues on a continuation line, still under its own column.
    expect(rows[2]).toBe('x    │ a-very-long-cell-')
    expect(rows[3]).toBe('     │ that-will-not-fit')
    for (const row of rows) expect(textWidth(row)).toBeLessThanOrEqual(24)
  })

  it('a wide status table keeps every value when the window is narrow', () => {
    // The shape a real answer takes: a two-column status table whose values
    // are longer than the narrow window. Every one of them must survive.
    const table = [
      '| 维度 | 状态与证据 |',
      '|---|---|',
      '| 版本 | `0.6.0`（package.json、src/version.ts 与 CHANGELOG 三处一致） |',
      '| 分支 | `main`，与本地记录的 `origin/main` 同步，工作区干净 |',
    ].join('\n')
    const rows = rowsOf(table, 40)
    expect(rows.join('')).not.toContain('…')
    // Read the value column back across the continuation lines. A hard cut can
    // land mid-word, so only the re-joined column proves the characters made
    // it to the screen.
    const valueColumn = rows
      .filter(row => row.includes('│ '))
      .map(row => row.slice(row.indexOf('│ ') + 2))
      .join('')
    for (const token of ['0.6.0', 'package.json', 'src/version.ts', 'CHANGELOG', '三处一致', 'origin/main', '工作区干净']) {
      expect(valueColumn, token).toContain(token)
    }
    for (const row of rows) expect(textWidth(row)).toBeLessThanOrEqual(40)
  })

  it('a header without its delimiter yet renders as prose (streaming rule)', () => {
    expect(rowsOf('| a | b |')).toEqual(['| a | b |'])
  })

  it('a bare emoji in a cell costs one column, not two — the \u2604 case', () => {
    // The weather-table bug: rows with a bare BMP emoji drifted one cell
    // left of rows without one, because the emoji measured two columns
    // while the terminal rendered one.
    const rows = rowsOf('| sky | k |\n|---|---|\n| \u2604rain | a |\n| overcast | bb |')
    expect(rows[2]).toBe('\u2604rain    │ a ')
    expect(rows[3]).toBe('overcast │ bb')
    // Both rows' separators sit at the same column: 8+3+2.
    expect(rows[2]?.indexOf('\u2502')).toBe(rows[3]?.indexOf('\u2502'))
  })

  it('CJK cells measure two columns each', () => {
    const rows = rowsOf('| 模块 | 职责 |\n|---|---|\n| kit | 底座 |')
    expect(rows[0]).toBe('模块 │ 职责')
    // 'kit' pads to the header's four columns.
    expect(rows[2]).toBe('kit  │ 底座')
  })

  it('leading and trailing blank lines collapse', () => {
    expect(rowsOf('\n\nhello\n\n')).toEqual(['hello'])
  })
})

describe('inline parsing', () => {
  it('bold, italic, code, and strike compose over the base', () => {
    const segments = parseInline('**b** *i* `c` ~~s~~', base, code)
    const byFlag = segments.map(segment => ({
      bold: segment.style.bold === true,
      italic: segment.style.italic === true,
      code: segment.style.fg === code.fg,
      strike: segment.style.strike === true,
      inverse: segment.style.inverse === true,
    }))
    expect(byFlag).toContainEqual({ bold: true, italic: false, code: false, strike: false, inverse: false })
    expect(byFlag).toContainEqual({ bold: false, italic: true, code: false, strike: false, inverse: false })
    expect(byFlag).toContainEqual({ bold: false, italic: false, code: true, strike: false, inverse: false })
    expect(byFlag).toContainEqual({ bold: false, italic: false, code: false, strike: true, inverse: false })
  })

  it('nesting composes: bold containing italic and code', () => {
    const segments = parseInline('**b *i* `c`**', base, code)
    expect(segments.some(s => s.style.bold === true && s.style.italic === true)).toBe(true)
    expect(segments.some(s => s.style.bold === true && s.style.fg === code.fg)).toBe(true)
  })

  it('unclosed markers render literally — the streaming rule', () => {
    expect(parseInline('**oops', base, code)).toEqual([{ text: '**oops', style: base }])
    expect(parseInline('a `unclosed', base, code).map(s => s.text).join('')).toBe('a `unclosed')
    expect(parseInline('[t](u', base, code)).toEqual([{ text: '[t](u', style: base }])
  })

  it('mid-expression asterisks and underscores stay literal', () => {
    expect(parseInline('a * b * c', base, code)).toEqual([{ text: 'a * b * c', style: base }])
    expect(parseInline('snake_case_word', base, code)).toEqual([{ text: 'snake_case_word', style: base }])
  })

  it('strike is strict: tilde-only and empty spans stay literal', () => {
    expect(parseInline('~~ ~~', base, code)).toEqual([{ text: '~~ ~~', style: base }])
    expect(parseInline('~~~~', base, code)).toEqual([{ text: '~~~~', style: base }])
    // A real strike still works.
    expect(parseInline('~~gone~~', base, code)[0]?.style.strike).toBe(true)
  })

  it('links render text plainly, and the url only when it differs', () => {
    expect(parseInline('[DeepSeek](https://deepseek.com)', base, code))
      .toEqual([{ text: 'DeepSeek (https://deepseek.com)', style: base }])
    expect(parseInline('[x](x)', base, code)).toEqual([{ text: 'x', style: base }])
  })

  it('code spans are data: no CJK seam inside', () => {
    const segments = parseInline('`中文x`', base, code)
    expect(segments[0]?.text).toBe('中文x')
    expect(segments[0]?.style.fg).toBe(code.fg)
    expect(segments[0]?.verbatim).toBe(true)
  })
})

describe('the segment-aware wrapper', () => {
  it('wraps on words, drops break-spaces, and never exceeds the budget', () => {
    const lines = wrapSegments([{ text: 'one two three four five six seven', style: base }], 10)
    for (const line of lines) {
      const text = line.map(segment => segment.text).join('')
      expect(textWidth(text)).toBeLessThanOrEqual(10)
      expect(text).not.toMatch(/^\s/u)
      expect(text).not.toMatch(/\s$/u)
    }
    expect(lines.map(line => line.map(segment => segment.text).join(''))).toEqual(['one two', 'three four', 'five six', 'seven'])
  })

  it('never splits a wide glyph across lines', () => {
    const lines = wrapSegments([{ text: '一二三四五六七八九十', style: base }], 7)
    for (const line of lines) {
      for (const segment of line) {
        for (const unit of splitUnits(segment.text)) expect(unit.width).not.toBe(0)
      }
    }
    expect(lines.map(line => line.map(segment => segment.text).join(''))).toEqual(['一二三', '四五六', '七八九十'.slice(0, 3), '七八九十'.slice(3)])
  })

  it('honours kinsoku with styled spans across the realistic width range', () => {
    const paragraph = '这个解析器把整个文档读入内存之后才开始输出第一个token，所以首token的延迟不会低于整个文件的读取时间。正确的做法是边读边切词。'
    for (let width = 20; width <= 78; width++) {
      const lines = wrapSegments(parseInline(paragraph, { ...base, bold: true }, code), width)
      for (const line of lines) {
        const text = line.map(segment => segment.text).join('')
        expect(textWidth(text), `width ${width}`).toBeLessThanOrEqual(width)
        expect(text, `width ${width}: line starts with closing punctuation`).not.toMatch(/^[，。、！？；：）」』…]/u)
      }
    }
  })

  it('a hard cut that fits no cluster still advances', () => {
    // One wide glyph in a one-column budget used to empty the cut; the
    // wrapper then re-cut the same slice forever and the app froze.
    expect(wrapSegments([{ text: '中中', style: base }], 1)
      .map(line => line.map(segment => segment.text).join(''))).toEqual(['中', '中'])
    // The same no-progress path from the kinsoku pull-back: the break sits
    // right before closing punctuation, so the cut pulls itself back to empty.
    expect(wrapSegments([{ text: '……', style: base }], 1)
      .map(line => line.map(segment => segment.text).join(''))).toEqual(['…', '…'])
  })

  it('equal adjacent styles merge into one segment', () => {
    const lines = wrapSegments([
      { text: 'one ', style: base },
      { text: 'two', style: base },
    ], 20)
    expect(lines[0]).toEqual([{ text: 'one two', style: base }])
  })

  it('rows carry the plain text and the segments in agreement', () => {
    const rows = markdownRows('# Title\n\nbody **here**', 60, base, palette)
    for (const row of rows) {
      expect(row.text).toBe(row.segments.map(segment => segment.text).join(''))
    }
    expect(rows.map(row => row.text)).toEqual(['Title', 'body here'])
  })
})

describe('web parity — constructs the web profile renders structured', () => {
  // The web client renders full GFM (micromark). These pin the constructs an
  // agent actually emits where the terminal idiom can match it, each named
  // for what the web does with the same source.

  it('a setext underline is a heading, not prose or a stray rule', () => {
    // The web renders `Title\n=====` as an h1; before this was fixed the
    // paragraph loop joined the marker into the text (`Title =====`) and a
    // `---` underline came out as a horizontal rule under one word.
    expect(rowsOf('Title\n=====\nbody')[0]).toBe('Title')
    expect(rowsOf('Sub\n---\nbody')[0]).toBe('Sub')
    // And the heading ladder still applies: a setext heading is styled.
    const [h1] = markdownRows('Title\n=====', 60, base, palette)
    expect(h1?.segments[0]?.style.bold).toBe(true)
  })

  it('a rule between paragraphs is still a rule', () => {
    // A setext underline needs a paragraph above it; alone between blanks it
    // is what it always was.
    const rows = rowsOf('one\n\n---\n\ntwo')
    expect(rows.some(row => /^─+$/.test(row))).toBe(true)
    expect(rows[0]).toBe('one')
    expect(rows.at(-1)).toBe('two')
  })

  it('an image renders as a named placeholder, not a literal bang', () => {
    // The web shows the picture; a terminal cannot, so it names the picture
    // instead of leaking the source syntax.
    expect(rowsOf('before ![logo](https://x/y.png) after')).toContain('before [img: logo] after')
    expect(rowsOf('a ![](https://x/y.png) b')).toContain('a [img] b')
  })

  it('a link title is dropped from the rendering', () => {
    expect(rowsOf('[text](https://x.com "the title")')).toContain('text (https://x.com)')
  })

  it('a label keeps its own markdown inside a link', () => {
    const rows = markdownRows('[**bold** and `code`](https://x.com)', 60, base, palette)
    const segs = rows[0]?.segments ?? []
    expect(rows[0]?.text).toBe('bold and code (https://x.com)')
    expect(segs.some(seg => seg.style.bold === true && seg.text.includes('bold'))).toBe(true)
    // The shown URL is plain text: a URL full of asterisks is never emphasis.
    const star = markdownRows('[x](https://a.com/*b*/*c*)', 60, base, palette)
    expect(star[0]?.text).toBe('x (https://a.com/*b*/*c*)')
    expect((star[0]?.segments ?? []).every(seg => seg.style.bold !== true)).toBe(true)
  })

  it('a reference link resolves against its definition, wherever it sits', () => {
    expect(rowsOf('see [the docs][1] here\n\n[1]: https://x.com')).toEqual(['see the docs (https://x.com) here'])
    // The definition renders nothing at all.
    expect(rowsOf('[1]: https://x.com')).toEqual([])
  })

  it('a reference whose definition has not arrived stays literal', () => {
    // The streaming rule the web's incremental renderer also documents: an
    // unresolved reference renders as source and self-heals when the
    // definition lands.
    expect(rowsOf('see [the docs][1] here')).toContain('see [the docs][1] here')
  })

  it('a shortcut reference resolves when its label is defined', () => {
    expect(rowsOf('see [docs] now\n\n[docs]: https://x.com')).toEqual(['see docs (https://x.com) now'])
    // Undefined, it is ordinary bracketed text.
    expect(rowsOf('see [docs] now')).toEqual(['see [docs] now'])
  })

  it('an autolink drops its angle brackets', () => {
    expect(rowsOf('see <https://example.com> now')).toContain('see https://example.com now')
  })

  it('a hard break breaks: two trailing spaces or a backslash', () => {
    expect(rowsOf('line1  \nline2')).toEqual(['line1', 'line2'])
    expect(rowsOf('line1\\\nline2')).toEqual(['line1', 'line2'])
    // A single trailing space is nothing.
    expect(rowsOf('line1 \nline2')).toEqual(['line1 line2'])
  })

  it('a CJK-strong span closes before CJK punctuation, as the web extends it', () => {
    // The web ships a micromark extension exactly because CommonMark will not
    // close `**…**` when CJK follows punctuation without whitespace; the
    // scanner here is deliberately looser, so the same source bolds.
    const rows = markdownRows('他说**不行**，然后走了', 60, base, palette)
    expect(rows[0]?.text).toBe('他说不行，然后走了')
    expect((rows[0]?.segments ?? []).some(seg => seg.style.bold === true)).toBe(true)
  })

  it('a footnote reference stays literal — a documented deviation', () => {
    // The web collects footnotes into a section. A transcript rarely carries
    // them and a terminal has no good idiom for the section, so the source is
    // shown as written — reference and definition both.
    expect(rowsOf('claim[^1] here\n\n[^1]: the note')).toEqual(['claim[^1] here', '[^1]: the note'])
  })

  it('raw html stays literal — a documented deviation', () => {
    expect(rowsOf('before <b>bold</b> after')).toEqual(['before <b>bold</b> after'])
  })
})
