#!/usr/bin/env node
/**
 * A scripted DeepSeek Messages endpoint, for testing the real profile.
 *
 * The last untestable seam used to be the wire: everything below the HTTP
 * request is the harness's own code, and exercising it against the real API
 * costs tokens and determinism. This server speaks the exact protocol
 * dsh-llm-deepseek speaks (verified against its adapter source):
 *
 * - POST {baseURL}/v1/messages with `stream: true`, Anthropic-style SSE
 *   frames (`message_start`, `content_block_start` for `thinking` / `text` /
 *   `tool_use`, `content_block_delta` for `text_delta` / `thinking_delta` /
 *   `input_json_delta`, `message_delta` carrying the stop reason and usage,
 *   `message_stop`), and the stream simply ends;
 * - usage in `message_start` and the closing `message_delta`, with the
 *   cache columns the token meter reads.
 *
 * The reply is chosen from the last user message, so a pty script drives the
 * scenario by typing. Scripted turns live in TURNS below; add one, type its
 * keyword, assert on what the desktop drew.
 */
import { createServer } from 'node:http'

const PORT = Number(process.env.PORT ?? 8931)
// Cosmetic slow-motion for recordings: adds this many ms to every streamed
// chunk, so a screen capture sampling at ~4 fps actually catches the stream.
// Zero by default — the wire rung keeps its real timing.
const SLOW = Number(process.env.MOCK_SLOW_MS ?? 0)

/** One scripted reply, streamed chunk by chunk with realistic delays. */
const TURNS = [
  {
    // match: the user's message contains this substring
    match: 'wire-reasoner',
    reasoning: 'The user asked for the scripted reasoner turn. Answer in Chinese, mention the seam, and stop.',
    content: '这是来自本地 mock 端点的回复：整条真实链路（dsh → cordis → agent-loop → llm 适配器 → tvision）都被穿过了，没有花一分钱 token。中英混排像 wire-test 一样自然。',
    usage: { prompt_tokens: 120, completion_tokens: 48, total_tokens: 168 },
  },
  {
    // A markdown reply, so L3 exercises the renderer end to end: heading,
    // bold/italic/code spans, a list, and a quote.
    match: 'wire-markdown',
    reasoning: 'The user asked for markdown. Emit every construct the transcript renders.',
    content: '## The streaming fix\n\nThe parser now reads **chunk by chunk** — *every* `drain(buffer)` call emits complete tokens.\n\n1. read a chunk\n2. drain complete tokens\n3. hold a partial fence\n\n> A fence that straddles a boundary is the hard part.\n',
    usage: { prompt_tokens: 190, completion_tokens: 60, total_tokens: 250 },
  },
  {
    // A background bash job: returns immediately with a jobId, leaving the
    // Jobs window holding a live row the harness's registry drives.
    match: 'wire-job',
    reasoning: 'The user asked for the background job turn. Start a sleep in the background.',
    toolCall: { id: 'call_mock_sleep', name: 'bash', arguments: '{"command":"sleep 60","run_in_background":true,"description":"Sleep in the background"}' },
    followupContent: 'The sleep is running in the background; the Jobs window holds it.',
    usage: { prompt_tokens: 210, completion_tokens: 28, total_tokens: 238 },
  },
  {
    match: 'wire-tool',
    reasoning: 'The user asked for the tool turn. Call bash with a harmless echo.',
    toolCall: { id: 'call_mock_echo', name: 'bash', arguments: '{"command":"echo wire-tool-ok","description":"Echo the marker"}' },
    // The second request, after the tool result is fed back, gets this.
    followupContent: 'The command printed wire-tool-ok. Tool round trip complete.',
    usage: { prompt_tokens: 200, completion_tokens: 30, total_tokens: 230 },
  },
  {
    // Held by the breakpoint rule the wire script sets first; y lets it run.
    match: 'wire-break',
    reasoning: 'The user set a breakpoint on this call. Make it, and the hold becomes visible.',
    toolCall: { id: 'call_mock_break', name: 'bash', arguments: '{"command":"echo wire-break-ok","description":"Echo the marker"}' },
    followupContent: '## Round trip complete\n\nThe breakpoint held the call, ran it once on approval, and the echo landed.',
    usage: { prompt_tokens: 205, completion_tokens: 32, total_tokens: 237 },
  },
  {
    // Plan mode: the model presents its plan for review. The review rides
    // the user-questions waterfall with the plan markdown in the question's
    // detail; a free-text answer comes back as the tool result the model
    // has to answer for, which is what the wire script pins.
    match: 'wire-plan-exit',
    reasoning: 'The plan is ready. Present it for review.',
    toolCall: {
      id: 'call_mock_plan',
      name: 'exit_plan_mode',
      arguments: '{"plan":"# Stream the parser\\n\\nThe fix, in order:\\n\\n1. drain complete tokens per chunk\\n2. hold partial fences\\n3. keep the tests green"}',
    },
    followupContent: 'The plan was approved; carrying it out from this step.',
    usage: { prompt_tokens: 260, completion_tokens: 34, total_tokens: 294 },
  },
  {
    // The delegated child's own request: a fresh context whose user message
    // is the delegated prompt. Must precede wire-sub in the array — the
    // prompt contains that keyword too, and the scan takes array order.
    match: 'wire-sub-child',
    reasoning: 'I am the delegated child. Answer briefly.',
    content: 'delegated-done: the child finished its scoped task.',
    usage: { prompt_tokens: 60, completion_tokens: 12, total_tokens: 72 },
  },
  {
    // Delegation: the parent calls the composed subagent tool (continuable,
    // so the result is the immediate child-id and the child's reply arrives
    // later as the settlement notice). The child's own request and the
    // settlement followup both land on the first turn below — their last
    // user message carries no keyword — which keeps the scenario
    // deterministic end to end.
    match: 'wire-sub',
    reasoning: 'The user wants delegation offloaded. Call the subagent tool.',
    toolCall: {
      id: 'call_mock_sub',
      name: 'subagent',
      arguments: '{"prompt":"wire-sub-child: say delegated-done","description":"Delegate a scoped reply"}',
    },
    followupContent: 'The subagent settled and its reply is folded back.',
    usage: { prompt_tokens: 240, completion_tokens: 30, total_tokens: 270 },
  },
  {
    // The attachment round trip: the profile's /attach admits a file through
    // the real dsh-attachment store, the next message carries it as a durable
    // file part, and the adapter resolves it to model-visible handle text —
    // which is what the last user message on the wire contains.
    match: 'wire-attach',
    reasoning: 'The user attached a file. Confirm the handle text made the file model-visible.',
    content: 'The attachment rode the message as a durable file part; the file is model-visible. Round trip complete.',
    usage: { prompt_tokens: 230, completion_tokens: 30, total_tokens: 260 },
  },
  {
    // The same rule, refused this time: the denial is the tool result the
    // model has to answer for, which is the whole point of a breakpoint.
    match: 'wire-deny',
    reasoning: 'The same breakpoint again. Make the call; expect the refusal.',
    toolCall: { id: 'call_mock_break2', name: 'bash', arguments: '{"command":"echo wire-break-deny","description":"Echo the marker"}' },
    followupContent: 'The call was refused at the breakpoint — the denial came back as the tool result, and the model saw it.',
    usage: { prompt_tokens: 210, completion_tokens: 34, total_tokens: 244 },
  },
]

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

/** Which scripted turns have already emitted their tool call. */
const emittedTool = new Set()

/**
 * Slice text into fixed-size code-point chunks, losslessly.
 *
 * A `/g` regex like /.{1,12}(\s|$)/gu silently SKIPS spans that contain no
 * whitespace within reach — the gap between matches never enters the result —
 * which corrupted the CJK reply mid-stream. Streaming must never drop what it
 * was asked to send.
 */
function chunk(text, size) {
  const units = Array.from(text)
  const out = []
  for (let index = 0; index < units.length; index += size) {
    out.push(units.slice(index, index + size).join(''))
  }
  return out
}

/** The text of one Messages-format message, joined across content blocks. */
function messageText(message) {
  const content = message?.content
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return ''
  return content.map((block) => {
    if (typeof block?.text === 'string') return block.text
    if (block?.type === 'tool_result') return JSON.stringify(block.content ?? '')
    if (block?.type === 'tool_use') return block.name ?? ''
    return ''
  }).join(' ')
}

/** Stream one scripted turn as Messages SSE. */
async function streamTurn(turn, res, model) {
  const send = (payload) => res.write(`data: ${JSON.stringify(payload)}\n\n`)
  let index = 0
  send({
    type: 'message_start',
    message: { model, usage: { input_tokens: turn.usage.prompt_tokens } },
  })
  const openBlock = (content_block) => {
    send({ type: 'content_block_start', index, content_block })
    return index++
  }
  if (turn.reasoning !== undefined) {
    openBlock({ type: 'thinking', thinking: '' })
    for (const piece of chunk(turn.reasoning, 24)) {
      send({ type: 'content_block_delta', index: index - 1, delta: { type: 'thinking_delta', thinking: piece } })
      await sleep(15 + SLOW)
    }
    send({ type: 'content_block_stop', index: index - 1 })
  }
  if (turn.toolCall !== undefined) {
    const block = openBlock({ type: 'tool_use', id: turn.toolCall.id, name: turn.toolCall.name, input: {} })
    // The arguments JSON arrives as fragmented partial_json deltas — exactly
    // how the real API streams a call — and the adapter reassembles them.
    for (const piece of chunk(turn.toolCall.arguments, 20)) {
      send({ type: 'content_block_delta', index: block, delta: { type: 'input_json_delta', partial_json: piece } })
      await sleep(10 + SLOW)
    }
    send({ type: 'content_block_stop', index: block })
  }
  const content = turn.content ?? turn.followupContent
  if (content !== undefined) {
    const block = openBlock({ type: 'text', text: '' })
    for (const piece of chunk(content, 12)) {
      send({ type: 'content_block_delta', index: block, delta: { type: 'text_delta', text: piece } })
      await sleep(12 + SLOW)
    }
    send({ type: 'content_block_stop', index: block })
  }
  send({
    type: 'message_delta',
    delta: { stop_reason: turn.toolCall !== undefined && content === undefined ? 'tool_use' : 'end_turn' },
    usage: {
      output_tokens: turn.usage.completion_tokens,
      cache_read_input_tokens: 96,
    },
  })
  send({ type: 'message_stop' })
  res.end()
}

const server = createServer(async (req, res) => {
  if (req.method === 'GET' && req.url === '/models') {
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end(JSON.stringify({ object: 'list', data: [{ id: 'deepseek-reasoner' }, { id: 'deepseek-chat' }] }))
    return
  }
  if (req.method !== 'POST' || !req.url.startsWith('/v1/messages')) {
    res.writeHead(404).end()
    return
  }
  const body = await new Promise((resolve) => {
    let text = ''
    req.on('data', (chunkPart) => { text += chunkPart })
    req.on('end', () => resolve(text))
  })
  const request = JSON.parse(body)
  const messages = request.messages ?? []
  // The Messages protocol rides tool results, mode notices, and injections in
  // user messages, so "the last user message" is not one thing. The keyword
  // the script typed sits in the newest user message that matches a turn;
  // scan from the end and take the first hit, so a fresh prompt always beats
  // stale history.
  let turn = TURNS[0]
  let lastText = ''
  for (const message of [...messages].reverse()) {
    if (message.role !== 'user') continue
    const text = messageText(message)
    const hit = TURNS.find((candidate) => text.includes(candidate.match))
    if (hit !== undefined) {
      turn = hit
      lastText = text
      break
    }
    if (lastText === '') lastText = text
  }
  // A tool turn's *second* request answers with prose. Detecting that from the
  // message shape misfires when a LATER turn runs after an earlier one already
  // used a tool — the harness feeds the whole conversation back every time —
  // so the server remembers which turn's call it already emitted instead.
  const followup = turn.followupContent !== undefined && emittedTool.has(turn.match)
  const chosen = followup
    ? { ...turn, reasoning: undefined, toolCall: undefined, content: turn.followupContent }
    : turn
  if (turn.toolCall !== undefined && !followup) emittedTool.add(turn.match)
  // A marker for the wire rung: free-text answers ride back as tool results,
  // which the one-line request log does not show.
  if (body.includes('tighten the fence case')) console.log('[mock-llm] feedback-tighten seen in request')
  if (body.includes('stopped by a tvision breakpoint')) console.log('[mock-llm] breakpoint-refusal seen in request')
  console.log(`[mock-llm] ${req.url} model=${request.model} tools=${(request.tools ?? []).length} ` +
    `roles=${messages.map((message) => message.role).join(',')} ` +
    `turn="${turn.match}" followup=${followup} last="${lastText.slice(0, 40).replace(/\n/g, ' ')}"`)
  res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache' })
  await streamTurn(chosen, res, request.model)
})

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[mock-llm] listening on http://127.0.0.1:${PORT}`)
})
