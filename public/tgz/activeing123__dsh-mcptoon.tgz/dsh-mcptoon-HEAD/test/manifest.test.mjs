import assert from 'node:assert/strict'
import { existsSync, readFileSync } from 'node:fs'
import test from 'node:test'

import { apply, config, diagnose, diagnoseAsync, name, overrideHint } from '../lib/index.js'

const root = new URL('../', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')
const pkg = JSON.parse(readFileSync(root + 'package.json', 'utf8'))
const patch = readFileSync(root + 'cordis.patch.yml', 'utf8')
const readmeEn = readFileSync(root + 'README.md', 'utf8')
const readmeZh = readFileSync(root + 'README.zh.md', 'utf8')

// The only externally citable measurement. Anything else is a withdrawn
// truncation artifact and has caused incidents before.
const CANONICAL = '71,929 -> 581 tokens across 255 tools (-99.2%, measured)'
const BANNED = ['99.8', '90,804', '117 tokens', '123 tokens', 'by 97%', '97% fewer']

const found = { found: true, path: '/usr/bin/mcptoon', version: 'mcptoon 0.7.14' }
const missing = { found: false, error: 'ENOENT' }
const probeFound = async () => found

test('package.json declares itself as a DSH bundle', () => {
  assert.equal(pkg.name, 'dsh-mcptoon')
  assert.equal(pkg.dsh.bundle.patch, './cordis.patch.yml')
  assert.ok(pkg.files.includes('cordis.patch.yml'), 'patch must ship in the tarball')
  assert.ok(pkg.files.includes('bin/doctor.mjs'), 'the doctor CLI must ship too')
  assert.ok(pkg.keywords.includes('dsh-plugin'), 'the catalog filters on this topic/keyword')
})

test('bundle patch mounts the official MCP client against mcptoon serve', () => {
  assert.match(patch, /^- insert:\s*$/m, 'the bundle must only insert, never rewrite others')
  assert.match(patch, /name:\s*'@deepseek-ai\/dsh-mcp-client'/, 'must reuse the official bridge')
  assert.match(patch, /serverName:\s*mcptoon/)
  assert.match(patch, /transport:\s*stdio/)
})

test('stdio command follows the hard-won rule: bare executable + args array', () => {
  const command = /command:\s*(\S+)/.exec(patch)[1].replace(/^['"]|['"]$/g, '')
  assert.ok(!command.includes(' '), `command must not contain spaces (got ${command})`)
  assert.doesNotMatch(patch, /npx -y/, 'a spaced shell string here would break on Windows paths')
  assert.match(patch, /args:\s*\['serve'\]/, 'arguments belong in an array')
})

test('canonical measurement is present and no withdrawn figure reappears', () => {
  for (const [label, text] of [['README.md', readmeEn], ['README.zh.md', readmeZh]]) {
    assert.ok(text.includes(CANONICAL) || text.includes(CANONICAL.replace('->', '→')), `${label} lost the canonical claim`)
    for (const banned of BANNED) {
      assert.ok(!text.includes(banned), `${label} contains banned claim: ${banned}`)
      assert.ok(!patch.includes(banned), `patch comment contains banned claim: ${banned}`)
    }
  }
})

test('diagnose() reports ready when the CLI resolves', () => {
  const report = diagnose({ probe: () => found })
  assert.equal(report.ok, true)
  assert.match(report.hint, /mcptoon 0.7.14/)
})

test('diagnose() tells the user how to pin an absolute path when it does not', () => {
  const report = diagnose({ probe: () => missing })
  assert.equal(report.ok, false)
  assert.match(report.hint, /not found/)
  assert.match(report.hint, /args: \['serve'\]/)
})

test('the override hint always keeps arguments in an array', () => {
  assert.match(overrideHint('/x/mcptoon'), /command: '\/x\/mcptoon'/)
  assert.match(overrideHint(), /<absolute path to mcptoon\.exe>/)
  assert.match(overrideHint(), /never bake them into one spaced shell string/i)
})

test('diagnoseAsync() resolves the same shapes without blocking', async () => {
  assert.equal((await diagnoseAsync({ probe: probeFound })).ok, true)
  assert.match((await diagnoseAsync({ probe: async () => missing })).hint, /pip install mcptoon/)
})

test('apply() logs a self-check and never throws on a half-built host context', async () => {
  const calls = []
  const logger = { info: m => calls.push(['info', m]), warn: m => calls.push(['warn', m]) }
  await apply({ config, logger })
  assert.equal(calls.length, 1)
  assert.match(calls[0][1], /\[dsh-mcptoon\]/)
  await assert.doesNotReject(() => apply({}))
  await assert.doesNotReject(() => apply(undefined))
})

test('apply() honours doctor: false', async () => {
  const calls = []
  await apply({ config: { doctor: false }, logger: { info: m => calls.push(m), warn: m => calls.push(m) } })
  assert.equal(calls.length, 0)
})

test('the doctor CLI ships and is wired into package bin', () => {
  assert.equal(pkg.bin['dsh-mcptoon-doctor'], 'bin/doctor.mjs')
  assert.ok(existsSync(root + 'bin/doctor.mjs'))
})

test('plugin metadata matches the package name', () => {
  assert.equal(name, pkg.name)
})
