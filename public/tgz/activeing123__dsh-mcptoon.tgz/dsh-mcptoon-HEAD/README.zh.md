# dsh-mcptoon

> [English](README.md) | 中文

一个 DeepSeek Harness 插件包（bundle）：一条命令把
[mcptoon](https://pypi.org/project/mcptoon/) 挂成 MCP server，让宿主 Agent 的
MCP 工具发现环节走 mcptoon 的压缩视图，而不再为每一轮重复支付完整的 JSON schema。

**在 255 个工具的工作区实测：工具发现 71,929 → 581 tokens across 255 tools (-99.2%, measured)。**编码无损——mcptoon 只改变工具定义的传输方式，不改变内容。

## 装完你会得到什么

模型侧看到 `mcp__mcptoon__<tool>`（与其它 MCP 宿主一致的「服务器限定名」），
而你原本已经配好的所有 MCP server，都被代理在这一条 stdio 连接后面。

## 安装

```sh
dsh plugin --profile web add github:activeing123/dsh-mcptoon
```

包上 npm 之后可以写成：

```sh
dsh plugin --profile web add dsh-mcptoon
```

然后重启 profile；改配置也可靠 HMR 热替换（同名 `serverName` 会重连桥接，不用重启进程）。

## 前置要求

- Python 3.9+，且 mcptoon CLI 在 `PATH` 上：`pip install mcptoon`（零依赖，秒装）。
- 升级前先看一眼版本：更稳的写法是 `pip install "mcptoon==<你审过的版本>"`，
  而不是无条件 `--upgrade`。

## 桥接没起来怎么办

这个 bundle 在激活时会自检并打一行提示。若显示 `not ready`，说明 `command`
指不到可执行文件——Windows 上很常见：`pip` 把 `mcptoon.exe` 装到解释器同级目录，
而那个目录常常不在 `PATH` 上，路径里还带空格（`C:\Program Files\...`）。

先拿到绝对路径：

```sh
python -c "import shutil;print(shutil.which('mcptoon'))"
```

然后在你自己 profile 的 `cordis.patch.yml` 里覆盖——**`command` 只放一个可执行文件，
参数一律进 `args` 数组，绝不要写成带空格的整串命令行**：

```yaml
- id: mcp-mcptoon
  name: '@deepseek-ai/dsh-mcp-client'
  config:
    serverName: mcptoon
    transport: stdio
    command: 'C:\Program Files\Python312\Scripts\mcptoon.exe'
    args: ['serve']
```

不启动应用也能核对最终配置：

```sh
dsh --profile web --dump-config | grep -A6 mcp-mcptoon
```

## 它是怎么工作的

本包是一个 *bundle*：`package.json` 里声明 `dsh.bundle.patch`，指向的补丁文件向
profile 的插件列表里插入一个条目——即官方 `@deepseek-ai/dsh-mcp-client` 桥接插件
的一个实例，配置为 `mcptoon serve`。这个包只做 `insert`，**不会改写任何不属于它的条目**。

## 和 Claude Code 插件的关系

mcptoon 在上游仓库里同时提供了 Claude Code 插件（`plugin.json` + `SKILL.md` +
`.mcp.json`），那是第一次把「MCP 管理 + 压缩」做成可安装插件的形态。**本 DSH bundle
是第二种宿主包装，不代表任何一方给出官方支持或背书。**

## 许可

Apache-2.0。mcptoon 本体在 [activeing123/mcptoon](https://github.com/activeing123/mcptoon)，
通过 PyPI 分发。
