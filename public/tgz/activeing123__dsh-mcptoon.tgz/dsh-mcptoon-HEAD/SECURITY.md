# Security policy

## What this package actually does

- It contains **no network code of its own**. The only runtime action is a
  one-shot `mcptoon --version` probe at activation, which exists purely to print
  a helpful message when the CLI is missing.
- The real behaviour comes from `cordis.patch.yml`, which registers an instance
  of the official `@deepseek-ai/dsh-mcp-client` bridge. That bridge spawns
  `mcptoon serve` as a **local stdio child process** — no port is opened, no
  remote endpoint is contacted by this bundle.
- Upstream credentials stay wherever you configured them. mcptoon proxies the MCP
  servers you already have; it does not collect, transmit, or store secrets.

## Supply-chain notes (read this if you automate installs)

- The patch intentionally ships `command: mcptoon`, i.e. **whoever is on `PATH`
  wins**. If you need determinism, override with an absolute path (run
  `dsh-mcptoon-doctor`) and consider pinning the Python package you install:
  `pip install "mcptoon==<reviewed version>"` rather than an open-ended
  `pip install --upgrade mcptoon`.
- Version pinning cuts both ways: a pinned version is immutable but goes stale,
  so pin only what you have reviewed and keep an upgrade path.
- mcptoon is a zero-dependency Python package (CI enforces an empty
  `dependencies` list), which keeps its install-time attack surface small.

## Reporting a vulnerability

Open a private security advisory on
[activeing123/dsh-mcptoon](https://github.com/activeing123/dsh-mcptoon/security/advisories/new).
Please do not file a public issue for an unresolved vulnerability.
