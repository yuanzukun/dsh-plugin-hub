# dsh-mcptoon

> English | [中文](README.zh.md)

A [DeepSeek Harness](https://github.com/deepseek-ai) plugin bundle that mounts
[mcptoon](https://pypi.org/project/mcptoon/) as an MCP server in one command, so
the host agent discovers its MCP tools through mcptoon's compressed view instead
of paying full JSON schemas on every turn.

**Measured on a 255-tool workspace: tool discovery drops 71,929 -> 581 tokens across 255 tools (-99.2%, measured).** The encoding is lossless — `mcptoon` only
changes how tool definitions travel, never what they say.

## What you get

After installing, the model sees `mcp__mcptoon__<tool>` — the same
server-qualified naming other MCP hosts use — and every upstream MCP server you
have already configured is proxied behind that single stdio connection.

## Install

```sh
dsh plugin --profile web add github:activeing123/dsh-mcptoon
```

Or, once the package is on npm:

```sh
dsh plugin --profile web add dsh-mcptoon
```

Then restart the profile (or rely on HMR: editing the entry reconnects the bridge
without a process restart).

## Requirements

- Python 3.9+ with the mcptoon CLI on `PATH`: `pip install mcptoon` (zero
  dependencies, installs in seconds).
- Review the version before you upgrade: `pip install "mcptoon==<reviewed>"` is
  the safer default than an unconditional `--upgrade`.

## If the bridge does not come up

The bundle prints a self-check line at activation. When it says `not ready`, the
CLI is not where `command` points — common on Windows, where `pip` installs
`mcptoon.exe` next to an interpreter that is not on `PATH`, often under a path
containing a space (`C:\Program Files\...`).

Get the absolute path — the bundled doctor prints the exact override block:

```sh
npx dsh-mcptoon-doctor          # or: node bin/doctor.mjs inside a checkout
python -c "import shutil;print(shutil.which('mcptoon'))"
```

Then override in your profile's own `cordis.patch.yml` — **one executable in
`command`, arguments in the `args` array, never a spaced shell string**:

```yaml
- id: mcp-mcptoon
  name: '@deepseek-ai/dsh-mcp-client'
  config:
    serverName: mcptoon
    transport: stdio
    command: 'C:\Program Files\Python312\Scripts\mcptoon.exe'
    args: ['serve']
```

Sanity-check the composed profile without booting the app:

```sh
dsh --profile web --dump-config | grep -A6 mcp-mcptoon
```

## How it works

This package is a *bundle*: its `package.json` declares
`dsh.bundle.patch`, and the patch file it points at inserts one entry into the
profile's plugin list — an instance of the official
`@deepseek-ai/dsh-mcp-client` bridge configured for `mcptoon serve`. The bundle
only ever `insert`s; it never rewrites entries it does not own.

## Relationship to the Claude Code plugin

mcptoon also ships a Claude Code plugin (`plugin.json` + `SKILL.md` +
`.mcp.json`) in the upstream repository. That packaging was the first to bundle
MCP management and compression as an installable plugin. **This DSH bundle is a
second host wrapper, not an endorsement or official support statement from
either project.**

## License

Apache-2.0. mcptoon itself lives in [activeing123/mcptoon](https://github.com/activeing123/mcptoon)
and is distributed on PyPI.
