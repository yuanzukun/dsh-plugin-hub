# Changelog

All notable changes to this project are documented in this file.

## 0.1.0 — 2026-09-16

First release.

- Bundle manifest (`dsh.bundle.patch`) that inserts one MCP bridge entry into a
  DSH profile: `@deepseek-ai/dsh-mcp-client` configured as `mcptoon serve`
  (stdio, `serverName: mcptoon`).
- Insert-only patch policy: the bundle never rewrites entries it does not own.
- Activation self-check (`apply()` → `diagnose()`) that tells the user how to
  pin an absolute `command` when `mcptoon` is not on `PATH` — the usual failure
  mode on Windows, where the Scripts directory sits under `C:\Program Files`.
- Manifest tests guarding: the bundle declaration, the patch shape, the
  "bare executable + args array" rule, and the single canonical measurement
  (other figures have been withdrawn and must not reappear).
- Bilingual README (en / zh) with install, override, and `--dump-config`
  verification steps.
