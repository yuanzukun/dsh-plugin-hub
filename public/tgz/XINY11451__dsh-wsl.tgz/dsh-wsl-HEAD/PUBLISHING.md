# Publishing

Maintainer notes for releasing this plugin. Four channels carry the same commit
and they are not interchangeable.

| Channel | What it is | What ships it |
|---|---|---|
| GitHub Release asset | what the plugin market installs from | `.github/workflows/release.yml`, on a `v*` tag |
| npm | the package `dsh-wsl-tool` | the same workflow, as its last step |
| Catalog entry | the listing line and the install command the market shows | a PR to `awesome-dsh-plugin/awesome-dsh-plugin` |
| Your working profile | the copy DSH actually loads | `npm run sync`, then a DSH restart |

## The name split is deliberate

The npm package is **`dsh-wsl-tool`**, not `dsh-wsl`. The registry answers

```
403 Forbidden - PUT https://registry.npmjs.org/dsh-wsl -
Package name too similar to existing package is-wsl
```

for the repository name. A name policy is not a permission problem: no token, no
2FA bypass, and no scope changes it, and the name stays unclaimable. The
repository, the plugin (`tool-wsl`), and the market listing keep the `dsh-wsl`
name.

Nothing else depends on that name, because `cordis.patch.yml` names its entry by
**relative path**:

```yaml
- insert:
    - id: tool-wsl
      name: './index.js'
```

DSH anchors a relative `name:` beside the patch file that declared it
(`anchorInsertedPluginNames` in `@deepseek-ai/dsh-app-boot`), so this row loads
this bundle's own `index.js` whatever the install folder is called —
`node_modules/dsh-wsl-tool` from npm, `node_modules/dsh-wsl` in a local `file:`
profile. A bare package name would resolve in only one of those layouts, and
would silently couple this file to the registry name. `test/smoke.mjs` asserts
both that the entry stays relative and that it resolves.

## Release checklist

1. Green locally:

   ```sh
   npm test                                           # shim backend, real WSL
   DSH_SUBPROCESS_LOCAL=/path/to/dsh/node_modules npm run test:real
   ```

   **`test:real` silently SKIPS when `DSH_SUBPROCESS_LOCAL` is unset** — it prints one
   `skipped:` line and exits 0, so a green chain is not evidence that it ran. Read the output
   (or check for `REAL SEAM: all checks passed`), not just the exit code.

   On the **desktop build** the modules it needs live inside `app.asar`, which is not a
   directory Node can import from, and the profile's own `node_modules` holds only
   `schemastery`/`cosmokit`. Extract the tree once and point the variable at it:

   ```sh
   # dsh/node_modules from the app bundle -> a real directory
   node scripts/pull-asar-dir.mjs "$DSH_DESKTOP/resources/app.asar" /tmp/dsh-mods dsh/node_modules
   DSH_SUBPROCESS_LOCAL=/tmp/dsh-mods/dsh/node_modules npm run test:real
   ```

   (Any extractor will do; the point is a `node_modules` containing `@deepseek-ai/*`.)

2. Bump, sync, commit, tag, push:

   ```sh
   npm version <x.y.z> --no-git-tag-version
   npm run sync                 # into the profile copy DSH loads
   git add -A && git commit -m "..."
   git tag -a v<x.y.z> -m "..."
   git push origin main && git push origin v<x.y.z>
   ```

   `npm run sync` defaults to
   `%USERPROFILE%/.dsh/profiles/desktop/node_modules/dsh-wsl` — the folder the
   profile's dependency key created, which need not match the npm name. Pass a
   path to target another profile. Restart DSH afterwards: the plugin is imported
   once at load. A patch change (the tool row, or the sidebar terminal override)
   is read at composition time, so it needs that restart too.

   **Then prove the schema really builds from the installed copy**, because this
   is the one failure the tools survive:

   ```sh
   cd ~/.dsh/profiles/desktop/node_modules/dsh-wsl
   node -e "import('./index.js').then(m => console.log(typeof m.Config, JSON.stringify(m.Config({}))))"
   ```

   It must print `function` and the resolved defaults. If it prints `undefined`,
   the plugin declares no `Config`, the platform has no schema to project, the
   entry's config status stays `absent` and the sidebar panel renders without a
   single switch while every tool keeps working. The fragile step is the
   interop hop: `@deepseek-ai/schemastery` exports its builder as the **default**
   export, so `const { Schema } = await import(...)` silently yields `undefined`
   (see `lib/schema.js`, and the regression test that pins the picking).

3. The tag runs the pipeline. The order is deliberate — the release asset goes
   **first** because it is the market's critical path, then npm, so a failing npm
   publish fails the run loudly without withholding the release.

   The build step asks `npm pack --silent` for the tarball name (it follows
   `package.json`, so it is `dsh-wsl-tool-<version>.tgz`) and copies it to
   `dsh-wsl.tgz`, which is the fixed name the catalog's URL points at. Never
   rename that copy: the market install breaks the moment the asset is not called
   `dsh-wsl.tgz`, and `--latest` is what keeps `releases/latest` resolving to it.

4. Verify each channel.

   **CI** — a check annotation is readable anonymously, unlike the job log:

   ```sh
   curl -s "https://api.github.com/repos/XINY11451/dsh-wsl/actions/runs?per_page=5"
   curl -s "https://api.github.com/repos/XINY11451/dsh-wsl/check-runs/<id>/annotations"
   ```

   A successful publish leaves `published <version> to npm`; a failure leaves
   `npm publish failed: <the npm error lines>`, which is why the workflow turns
   npm's stderr into `::error::` instead of only printing it.

   **npm**:

   ```sh
   curl -s https://registry.npmjs.org/dsh-wsl-tool      # dist-tags.latest
   npm view dsh-wsl-tool version --registry https://registry.npmjs.org
   ```

   Fetching `dist.tarball` and unpacking it is the honest check — it proves the
   artifact, not just the metadata. Scripted requests to `npmjs.com`'s HTML hit a
   Cloudflare challenge; the registry API is the source of truth.

   All of the above in one command, waiting for the run when it is still going:

   ```sh
   node scripts/verify-release.mjs 1.12.2              # waits for the tag's workflow
   node scripts/verify-release.mjs 1.12.2 --no-wait    # check only
   ```

   It reports the release tag, the asset's size/sha256 and version, `dist-tags.latest`,
   whether the version is on npm at all, and whether the asset and the npm tarball are
   byte-identical — and exits non-zero on any mismatch, so it can gate a script. It needs
   the same proxy the rest of the machine needs for `github.com` (see the header of the
   script for the exact environment).

   Two things make a published release look unpublished, so rule them out before
   believing a negative:

   - **A green run is not proof that npm was published.** The `Publish to npm`
     step exits 0 with a warning when `NPM_TOKEN` is absent, so the run stays
     green while npm is skipped. Ask the jobs API whether the step really ran —
     a real run has `started_at`; a skipped one has `conclusion: skipped` and no
     timestamp — and ask the registry what actually handles the version
     (`time[<version>]` on the packument).

   - **A failing `npm whoami` says nothing about the release.** A stale token in
     `~/.npmrc` only means that machine cannot publish by hand; CI has its own
     credential. Release state lives in the three artifacts — the tag's commit,
     the release asset, and the registry tarball — so compare their bytes rather
     than your credentials.

   Expect the registry's caches to lag a publish by minutes, and to lag
   *inconsistently*: the full packument, the abbreviated (install) packument,
   `/-/package/<name>/dist-tags` and the tarball URL each cache separately, so one
   endpoint can already report the new version while `npm install` still answers
   `404` for its tarball. Re-query instead of concluding the publish failed, and
   cache-bust the tarball URL (`?cb=<random>`) to tell a stale negative entry apart
   from an artifact that is genuinely missing.

   **Market asset** (this is what users install, and it is independent of npm):

   ```sh
   curl -sL -o /tmp/a.tgz https://github.com/XINY11451/dsh-wsl/releases/latest/download/dsh-wsl.tgz
   tar -xzOf /tmp/a.tgz package/package.json | grep '"version"'
   ```

   **Catalog**: the catalog's generated data is at
   <https://awesome-dsh-plugin.com/plugins.json> — look up `dsh-wsl` and read
   `npm`, `version`, `downloads`, `install`, `tarball`.

## The catalog entry

The listing lives at `data/plugins/XINY11451__dsh-wsl.yml` in
`awesome-dsh-plugin/awesome-dsh-plugin`, one file per plugin. Only
`description.en` is required; `description.zh` is optional. Edit it through a
one-file PR (the web UI's pencil button forks and proposes the change).

Two of its keys are hand-written and must stay:

- `tarball:` — the fixed release URL above. It is what the market's `install`
  command points at today.
- `url` / `name` / `category` — `category: wsl`.

Everything else about the entry is **generated** and must never be written by
hand: `npm`, `version`, `downloads`, `screenshots`, and `install`. In particular
`scripts/probe-npm.mjs` reads `package.json`'s `name` from the repository's
`HEAD`, then accepts the package only when the registry document's
`versions[latest].repository.url` contains `<owner>/<repo>`
(case-insensitively — that check is what stops name squatting). So keep
`repository` in `package.json` accurate, or the catalog stops discovering the npm
package. "Not published" verdicts are re-probed daily, so a freshly published
version can take a day to appear; when it does, `install` switches from the
tarball URL to `dsh plugin --profile web add dsh-wsl-tool`.

## Market screenshots

The catalog's `screenshots` array is **generated from this repository**, not written
by hand: `screenshots.json` lists repo-relative paths and the site turns each one
into `https://raw.githubusercontent.com/XINY11451/dsh-wsl/HEAD/<path>`. That has two
consequences worth remembering:

- **Changing a preview is a commit here, not a listing PR.** The listing file's
  hand-written keys are `url`, `name`, `category`, `tarball` and `description`;
  everything else (including `screenshots`) is generated and must not be written by
  hand. Only the description needs a PR against `awesome-dsh-plugin`.
- **Replacing a file in place does NOT refresh the preview.** Two caches are keyed on
  the exact URL string and neither revalidates the bytes: dsh-market loads images
  through the `images.weserv.nl` proxy (`?url=<the raw URL>&h=<height>&we=1` — see its
  `client/client.js`), and the DSH desktop webview keeps its own HTTP disk cache under
  `%APPDATA%\@deepseek-ai\dsh-desktop\Cache\Cache_Data`. A redesign committed over the
  same path therefore keeps serving the previous image for as long as those copies
  live. The 2026-10-05 preview did exactly that: the mode-picker screenshot (with
  `WSL Dev` ticked) was replaced in place at `assets/screenshot-1.png`, and the listing
  went on showing it. **Ship a preview under a new filename** — add the file, point
  `screenshots.json` and the README embed at it, and retire the old path.
  Retiring it costs one day of transition: the catalog's `screenshots` array is
  generated from this repository and published about once a day, so a client still
  holding the previous catalog requests the old URL after the file is gone and finds
  nothing. Keep the old file until the next catalog publish when that URL is worth
  keeping alive; delete it in the same change when the point is to retire the URL
  (as here), accepting the empty slot until the rebuild.

The preview is rendered from `assets/market-preview.html` (the editable source of
truth) with headless Edge, under a **new filename each redesign** — the name is what
defeats the caches, so the render target changes with the design:

```powershell
$out = Join-Path $PWD 'assets\market-preview-<new>.png'
$url = 'file:///' + ($PWD.Path -replace '\\','/') + '/assets/market-preview.html'
& 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe' --headless=new `
  --disable-gpu --hide-scrollbars --force-device-scale-factor=2 `
  --window-size=1280,800 --virtual-time-budget=4000 `
  --user-data-dir="$env:TEMP\edge-shot" --screenshot="$out" $url
```

Two things the renderer demands: `--screenshot` must be an **absolute** path (Edge
resolves it against its own working directory, and a relative one fails with
"Failed to write file … 系统找不到指定的路径"), and `--headless=new` needs a moment
before the file appears. It renders 2560×1600 (1280×800 at 2×) in a few seconds with
no browser window; `--user-data-dir` keeps it away from the user's real Edge profile.
Edit the HTML, re-run, commit the PNG, and point `screenshots.json` plus the README
embed at the new name: no build step, no design tool.

## Things that bite

- **A tag event runs the workflow from the tag's commit.** To change the
  pipeline you must commit *and cut a new tag*; re-running an old run reuses the
  workflow it was created with, and moving a tag is not a fix.
- **Job logs need authentication; annotations do not.** There is no `gh` and no
  `GITHUB_TOKEN` on the maintainer machine, so anything that must be diagnosable
  without a credential belongs in an annotation.
- **An interactive `npm publish` asks for a one-time password** and cannot be
  driven from an unattended run. CI authenticates with a granular token that may
  bypass 2FA, stored as the `NPM_TOKEN` secret; with the secret absent the step
  skips with a notice instead of failing. Now that the package exists, OIDC
  trusted publishing is the better replacement.
- **`publishConfig.registry` in `package.json` wins** over a developer's
  `~/.npmrc` mirror, so a mirror configured for reads cannot intercept a publish.
- **The profile's dependency key is not the package name** (`dsh-wsl` versus
  `dsh-wsl-tool`). Do not "fix" that by hand: the profile is managed by pnpm, and
  its `pnpm-lock.yaml`, `node_modules/.modules.yaml`, and
  `node_modules/.package-map.json` all record the key. The relative patch entry
  means the difference costs nothing.
- **Short unscoped names ending in `-wsl` are a minefield.** `dsh-wsl` collides
  with `is-wsl`; longer suffixed names such as `dsh-wsl-workspace` are published
  by other authors and pass. Prefer npm's suggestion (a scope) or a clearly
  suffixed name, and check the registry before tagging.
