// @dsh-external/dsh-default-workspace — host half
//
// DeepSeek Harness blocks a new conversation until a workspace directory has been
// selected. On a fresh profile the workspace registry is empty, so the web GUI
// lands on the workspace-picker hero and there is nothing to select.
//
// This plugin removes that dead-end: at boot it resolves a default workspace
// directory, creates it if missing, and registers it with `ctx.workspaceRegistry`.
// The runtime's existing "recent workspace" fallback then connects it, so a new
// conversation starts immediately.
//
// Idempotent and minimal-footprint:
//   - no-op when the registry already has workspaces (unless `always` is set);
//   - re-registering the same path is a no-op (the registry reuses the record);
//   - failure is logged as a warning and never fails the whole boot.
//
// Zero runtime dependencies: it only imports Node built-ins and consumes the
// `workspaceRegistry` service the web bundle already provides.

import { mkdir } from "node:fs/promises";
import { homedir } from "node:os";
import { isAbsolute, join } from "node:path";

export const name = "default-workspace";
export const inject = ["workspaceRegistry"];

/** Expand a leading `~` (and `~\`) against the OS home directory. */
function expandHome(path) {
  if (path === "~") return homedir();
  if (path.startsWith("~/") || path.startsWith("~\\")) {
    return join(homedir(), path.slice(2));
  }
  return path;
}

/** Resolve the default workspace directory, honoring config → env → built-in default. */
function resolvePath(config) {
  const configured = config?.path;
  if (typeof configured === "string" && configured.trim() !== "") {
    const value = expandHome(configured.trim());
    return isAbsolute(value) ? value : join(process.cwd(), value);
  }

  const env = process.env.DSH_DEFAULT_WORKSPACE;
  if (typeof env === "string" && env.trim() !== "") {
    return expandHome(env.trim());
  }

  const home = process.env.DSH_HOME || join(homedir(), ".dsh");
  return join(home, "workspaces", "default");
}

/** Resolve the display title, honoring config → built-in default. */
function resolveTitle(config) {
  const title = config?.title;
  if (typeof title === "string" && title.trim() !== "") return title.trim();
  return "Default";
}

export async function apply(ctx, config) {
  const registry = ctx.workspaceRegistry;
  try {
    // Minimal footprint: leave an already-populated registry alone unless the
    // operator explicitly asked for `always`.
    if (!config?.always && registry.list().length > 0) return;

    const path = resolvePath(config);
    const title = resolveTitle(config);

    await mkdir(path, { recursive: true });
    const workspace = await registry.create(path, title);

    ctx.logger.info(
      `default-workspace: "${title}" ready at ${workspace.path}`,
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    ctx.logger.warn(
      `default-workspace: could not ensure a default workspace: ${message}`,
    );
  }
}
