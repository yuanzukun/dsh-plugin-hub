// @dsh-external/dsh-default-workspace — client half
//
// Adds a "不在工作区中对话 / Chat without a workspace" entry to the new-session
// workspace picker menu. Selecting it starts a session that is NOT attached to
// any workspace: its cwd falls back to the host's default working directory
// (`process.cwd()`), and it shows up as "Ungrouped" in the sidebar.
//
// The picker menu is a React-rendered portal with no official injection slot,
// so this half contributes the extra row at the DOM level (the same approach
// the shipped dsh-navbar plugin uses). It is kept robust with a MutationObserver:
// any re-render that drops the row is re-injected on the next frame.
window.__ModuleLoader__.load({
  id: "@dsh-external/dsh-default-workspace",
  factory: (require) => {
    var module = { exports: {} };

    // The picker's footer "Add workspace" labels (both locales the picker ships).
    const ADD_LABELS = ["添加工作区…", "Add workspace…"];
    // Marker on the injected wrapper so re-scans and cleanup can find it.
    const ATTR = "data-dsh-no-workspace";

    function isAddWorkspaceButton(button) {
      if (button.getAttribute("role") !== "menuitem") return false;
      const text = (button.textContent || "").trim();
      return ADD_LABELS.includes(text);
    }

    function findAddButton(menu) {
      const buttons = menu.querySelectorAll('button[role="menuitem"]');
      for (const button of buttons) {
        if (isAddWorkspaceButton(button)) return button;
      }
      return null;
    }

    function pickerMenus() {
      const out = [];
      for (const menu of document.querySelectorAll('div[role="menu"]')) {
        if (findAddButton(menu) !== null) out.push(menu);
      }
      return out;
    }

    async function startWithoutWorkspace(ctx) {
      try {
        // No workspaceId and no cwd: the host defaults the session cwd to its
        // own process.cwd() and skips workspace attachment → an ungrouped session.
        const sessionId = await ctx.sessions.create({});
        ctx.sessions.open(sessionId);
      } catch (error) {
        console.error(
          "dsh-default-workspace: failed to start a workspace-less conversation:",
          error,
        );
      }
    }

    function inject(menu, ctx) {
      const addButton = findAddButton(menu);
      if (addButton === null) return;
      const addWrap = addButton.parentElement;
      if (addWrap === null) return;
      const container = addWrap.parentElement;
      if (container === null) return;
      if (container.querySelector(`[${ATTR}]`) !== null) return; // already injected

      const isZh = (addButton.textContent || "").indexOf("工作区") !== -1;
      const labelText = isZh ? "不在工作区中对话" : "Chat without a workspace";

      // Clone the "Add workspace" row so the injected row inherits the native
      // menu-item styling (hashed CSS classes), then swap in our own label.
      const clone = addWrap.cloneNode(true);
      clone.setAttribute(ATTR, "");
      const button = clone.querySelector('button[role="menuitem"]');
      if (button === null) return;
      button.removeAttribute("disabled");

      const labelSpan = button.querySelector("span:last-child");
      const labelClass = labelSpan !== null ? labelSpan.className : "";
      button.textContent = "";
      const label = document.createElement("span");
      if (labelClass !== "") label.className = labelClass;
      label.textContent = labelText;
      button.appendChild(label);

      button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        startWithoutWorkspace(ctx);
      });

      addWrap.insertAdjacentElement("afterend", clone);
    }

    module.exports = {
      name: "default-workspace-client",
      inject: ["sessions", "workspaces"],
      apply(ctx) {
        let scheduled = false;
        const sweep = () => {
          if (scheduled) return;
          scheduled = true;
          requestAnimationFrame(() => {
            scheduled = false;
            for (const menu of pickerMenus()) inject(menu, ctx);
          });
        };

        const observer = new MutationObserver(sweep);
        observer.observe(document.body, { childList: true, subtree: true });
        sweep();

        return () => {
          observer.disconnect();
          for (const el of document.querySelectorAll(`[${ATTR}]`)) {
            if (el.parentElement !== null) el.remove();
          }
        };
      },
    };

    return module.exports;
  },
});
