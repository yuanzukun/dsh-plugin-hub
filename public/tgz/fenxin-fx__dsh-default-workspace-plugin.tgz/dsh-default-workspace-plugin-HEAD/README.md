<h1 align="center">dsh-default-workspace</h1>

<p align="center">
  A <a href="https://github.com/deepseek-ai/deepseek">DeepSeek Harness</a> plugin — start a new conversation without selecting a workspace.
</p>

<p align="center">
  <img alt="license" src="https://badgen.net/badge/license/MIT/green">
</p>

Out of the box, DeepSeek Harness will not let a conversation start until a workspace directory has been selected. On a fresh profile the workspace registry is empty, so the web GUI lands on the workspace-picker hero and there is nothing to pick.

This plugin removes that dead-end in two ways, from one package:

1. **Node half** — at boot it resolves a default workspace directory, creates it if missing, and registers it. The runtime's existing "recent workspace" fallback then connects it, so a brand-new profile opens straight into a conversation.
2. **Client half** — it adds a **"Chat without a workspace"** (`不在工作区中对话`) entry to the new-session workspace picker. Selecting it starts a session with **no workspace**: its working directory falls back to the host's `process.cwd()` and the session shows up as *Ungrouped* in the sidebar.

## What it does

| Behaviour | Detail |
| --- | --- |
| Auto-provision | Creates and registers a default workspace on first boot |
| No-workspace option | Adds a "Chat without a workspace" row to the workspace picker |
| Zero footprint | Auto-provision is a no-op when workspaces already exist (unless `always: true`) |
| Idempotent | Re-registering the same path reuses the existing record |
| Non-fatal | A failure is logged as a warning and never fails the boot |
| Zero dependencies | Imports only Node built-ins / browser APIs; no build step |

The default directory is `<DSH_HOME>/workspaces/default` (or `~/.dsh/workspaces/default` when `DSH_HOME` is unset). It can be overridden per-deployment with a config row, or globally with the `DSH_DEFAULT_WORKSPACE` environment variable.

## Install

Recommended — one line from the git source (no build runs on install, since the source is committed directly):

```sh
# HTTPS git source. The `github:` shorthand is rewritten to SSH by pnpm and
# fails on machines without SSH keys — use the explicit git+https form.
dsh plugin --profile web add "git+https://github.com/fenxin-fx/dsh-default-workspace.git#main"
```

Other options:

- From a local checkout:
  ```sh
  git clone https://github.com/fenxin-fx/dsh-default-workspace.git
  cd dsh-default-workspace
  dsh plugin --profile web add .
  ```

**First install needs a web restart** for the node half to take effect; the client half arrives per-request, so later upgrades only need a browser refresh. The plugin can be enabled/disabled under Settings → Plugins (package id `@dsh-external/dsh-default-workspace`).

## Configuration

Overrides live on the plugin's config row in the profile `cordis.patch.yml` (the `cordis.patch.yml` shipped by this package shows the full template). Precedence is `config.path` → `DSH_DEFAULT_WORKSPACE` → `<DSH_HOME>/workspaces/default`.

| Key | Type | Default | Meaning |
| --- | --- | --- | --- |
| `path` | string | `<DSH_HOME>/workspaces/default` | Default workspace directory; `~` expands to the OS home, a relative path resolves against the process cwd |
| `title` | string | `Default` | Display title for the workspace |
| `always` | boolean | `false` | `true` always ensures the workspace, even when others already exist |

```yaml
- insert:
    - id: default-workspace
      name: '@dsh-external/dsh-default-workspace'
      config:
        path: 'C:\my\scratch'
        title: 'Scratch'
        always: false
```

Or set the environment variable before launching:

```sh
DSH_DEFAULT_WORKSPACE="$HOME/projects/scratch" dsh web
```

## Usage

Install, restart the web profile, and go — no commands, no tools. A brand-new profile opens directly into a conversation in the default workspace, and the workspace picker on a new session offers **"Chat without a workspace"** to start an ungrouped conversation instead.

## Development

There is no build step: both halves ship as plain JavaScript.

```
src/index.mjs        — the node half (ensure + register the default workspace)
src/client/index.js  — the client half (the "Chat without a workspace" picker entry)
cordis.patch.yml     — the bundle patch that mounts the node half
```

## How it works

- The node half calls `ctx.workspaceRegistry.create(path, title)` after `mkdir -p`; `create` is idempotent and prepends only new records.
- The client half injects the extra row into the picker menu at the DOM level (the picker exposes no official slot), cloning the "Add workspace" row for native styling and re-injecting via a `MutationObserver` on re-render.
- The no-workspace session is created with `ctx.sessions.create({})` — no `workspaceId`, so the host defaults the cwd to `process.cwd()` and skips workspace attachment.

## License

[MIT](LICENSE)
