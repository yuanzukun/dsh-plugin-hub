<h1 align="center">dsh-default-workspace</h1>

<p align="center">
  DeepSeek Harness 插件：不选择工作区也能直接开始新对话。
</p>

<p align="center">
  <img alt="license" src="https://badgen.net/badge/license/MIT/green">
</p>

DeepSeek Harness 默认要求先选择一个工作区目录才能开始对话。全新安装时工作区注册表是空的，Web 界面会停在「工作区选择」引导页，而那里没有任何可选项——新对话被卡死。

本插件从一个包内用两种方式消除这个死胡同：

1. **Node half** —— 启动时解析默认工作区目录、不存在则创建、并注册进注册表。运行时已有的「最近工作区」回退逻辑随后自动连接它，全新 profile 直接进入对话。
2. **Client half** —— 在新对话的工作区选择器里新增一条 **「不在工作区中对话」**。点击后开启一个**不属于任何工作区**的会话：其工作目录回退为宿主的 `process.cwd()`，并在侧边栏显示为「未分组」。

## 能力

| 行为 | 说明 |
| --- | --- |
| 自动供给 | 首次启动时创建并注册一个默认工作区 |
| 无工作区选项 | 在工作区选择器中新增「不在工作区中对话」 |
| 零侵入 | 已有工作区时自动供给默认不动作（除非 `always: true`） |
| 幂等 | 重复注册同一路径会复用已有记录 |
| 不致命 | 失败只记 warning，绝不让整个启动失败 |
| 零依赖 | 仅用 Node 内建模块 / 浏览器 API，无构建步骤 |

默认目录是 `<DSH_HOME>/workspaces/default`（`DSH_HOME` 未设置时为 `~/.dsh/workspaces/default`）。可用配置项按部署覆盖，或用 `DSH_DEFAULT_WORKSPACE` 环境变量全局覆盖。

## 安装

**推荐：git 源一行安装**（源码直接入库，安装时不触发构建）：

```sh
# 首选 HTTPS git 源；`github:` 简写会被 pnpm 解析为 SSH，无密钥环境会失败
dsh plugin --profile web add "git+https://github.com/fenxin-fx/dsh-default-workspace.git#main"
```

其它方式：

- 本地目录（有源码时）：
  ```sh
  git clone https://github.com/fenxin-fx/dsh-default-workspace.git
  cd dsh-default-workspace
  dsh plugin --profile web add .
  ```

**首次安装需重启 web** 才生效（Node half 在启动时运行）；Client half 按请求读取，后续升级刷新页面即可。设置页「插件」面板可停用/启用（包名 `@dsh-external/dsh-default-workspace`）。

## 配置

覆盖项写在 profile `cordis.patch.yml` 里该插件的 config 行（本包自带的 `cordis.patch.yml` 里有完整模板）。优先级为 `config.path` → `DSH_DEFAULT_WORKSPACE` → `<DSH_HOME>/workspaces/default`。

| 键 | 类型 | 默认值 | 含义 |
| --- | --- | --- | --- |
| `path` | string | `<DSH_HOME>/workspaces/default` | 默认工作区目录；`~` 展开为系统主目录，相对路径相对进程 cwd |
| `title` | string | `Default` | 工作区显示名 |
| `always` | boolean | `false` | 为 `true` 时始终确保该工作区存在（即使已有其它工作区） |

```yaml
- insert:
    - id: default-workspace
      name: '@dsh-external/dsh-default-workspace'
      config:
        path: 'C:\my\scratch'
        title: 'Scratch'
        always: false
```

或启动前设置环境变量：

```sh
DSH_DEFAULT_WORKSPACE="$HOME/projects/scratch" dsh web
```

## 使用

安装、重启 web 即可，无命令、无工具。全新 profile 会直接进入默认工作区中的对话；新对话的工作区选择器里则多出「不在工作区中对话」，点击即开启一个未分组会话。

## 开发

无需构建：两半均以纯 JavaScript 直接发布。

```
src/index.mjs        — Node half（确保并注册默认工作区）
src/client/index.js  — Client half（选择器里的「不在工作区中对话」入口）
cordis.patch.yml     — 挂载 Node half 的 bundle patch
```

## 原理

- Node half 先 `mkdir -p`，再调用 `ctx.workspaceRegistry.create(path, title)`；`create` 幂等且只把新记录放到列表前。
- Client half 在 DOM 层把新增行注入选择器菜单（选择器没有官方扩展 slot），克隆「添加工作区」那行来复用原生样式，并用 `MutationObserver` 在重渲染后重新注入。
- 无工作区会话用 `ctx.sessions.create({})` 创建——不传 `workspaceId`，宿主把 cwd 回退为 `process.cwd()` 且不挂载到任何工作区。

## 许可

MIT（见 [LICENSE](LICENSE)）。
