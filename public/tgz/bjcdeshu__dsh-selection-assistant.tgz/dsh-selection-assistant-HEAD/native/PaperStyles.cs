using System;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using T = DshSelectionAssistant.PaperTheme;

namespace DshSelectionAssistant {
  // Quiet Paper control library. Window-local resources only; the application
  // dictionary and the Legacy/Claude styles stay untouched.
  internal static class PaperStyles {
    static string ButtonTemplate(int radius) {
      return @"<ControlTemplate TargetType='Button'>
        <Grid SnapsToDevicePixels='True'>
          <Border x:Name='chrome' CornerRadius='" + radius + @"' Background='{TemplateBinding Background}' BorderBrush='{TemplateBinding BorderBrush}' BorderThickness='{TemplateBinding BorderThickness}'/>
          <Border x:Name='wash' CornerRadius='" + radius + @"' Background='Transparent'/>
          <ContentPresenter Margin='{TemplateBinding Padding}' HorizontalAlignment='{TemplateBinding HorizontalContentAlignment}' VerticalAlignment='{TemplateBinding VerticalContentAlignment}' RecognizesAccessKey='True'/>
        </Grid>
        <ControlTemplate.Triggers>
          <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='wash' Property='Background' Value='{DynamicResource PHover}'/></Trigger>
          <Trigger Property='IsPressed' Value='True'><Setter TargetName='wash' Property='Background' Value='{DynamicResource PPressed}'/></Trigger>
          <Trigger Property='IsEnabled' Value='False'><Setter Property='Opacity' Value='0.4'/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate>";
    }

    const string Head = @"<ResourceDictionary xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>
  <Style x:Key='PFocus'>
    <Setter Property='Control.Template'><Setter.Value><ControlTemplate>
      <Border Margin='-3' CornerRadius='10' BorderThickness='2' BorderBrush='{DynamicResource PAccent}' SnapsToDevicePixels='True'/>
    </ControlTemplate></Setter.Value></Setter>
  </Style>";

    static string Markup() {
      return Head + @"
  <Style TargetType='Button'>
    <Setter Property='Foreground' Value='{DynamicResource PInk}'/>
    <Setter Property='Background' Value='Transparent'/>
    <Setter Property='BorderBrush' Value='Transparent'/>
    <Setter Property='BorderThickness' Value='0'/>
    <Setter Property='Padding' Value='10,0'/>
    <Setter Property='MinHeight' Value='28'/>
    <Setter Property='FontSize' Value='13'/>
    <Setter Property='Cursor' Value='Hand'/>
    <Setter Property='HorizontalContentAlignment' Value='Center'/>
    <Setter Property='VerticalContentAlignment' Value='Center'/>
    <Setter Property='FocusVisualStyle' Value='{StaticResource PFocus}'/>
    <Setter Property='Template'><Setter.Value>" + ButtonTemplate(8) + @"</Setter.Value></Setter>
  </Style>
  <Style x:Key='PIconButton' TargetType='Button' BasedOn='{StaticResource {x:Type Button}}'>
    <Setter Property='Width' Value='28'/><Setter Property='Height' Value='28'/><Setter Property='Padding' Value='0'/>
    <Setter Property='Foreground' Value='{DynamicResource PInk2}'/>
  </Style>
  <Style x:Key='PTextButton' TargetType='Button' BasedOn='{StaticResource {x:Type Button}}'>
    <Setter Property='Height' Value='28'/><Setter Property='Padding' Value='8,0,10,0'/><Setter Property='FontSize' Value='12'/>
    <Setter Property='Foreground' Value='{DynamicResource PInk2}'/>
  </Style>
  <Style x:Key='PPrimary' TargetType='Button' BasedOn='{StaticResource {x:Type Button}}'>
    <Setter Property='Height' Value='32'/><Setter Property='Padding' Value='14,0'/>
    <Setter Property='Background' Value='{DynamicResource PAccentStrong}'/><Setter Property='Foreground' Value='{DynamicResource POnAccent}'/>
  </Style>
  <Style x:Key='POutline' TargetType='Button' BasedOn='{StaticResource {x:Type Button}}'>
    <Setter Property='Height' Value='32'/><Setter Property='Padding' Value='14,0'/>
    <Setter Property='BorderBrush' Value='{DynamicResource PLineStrong}'/><Setter Property='BorderThickness' Value='1'/>
  </Style>
  <Style x:Key='PToolbarButton' TargetType='Button' BasedOn='{StaticResource {x:Type Button}}'>
    <Setter Property='Height' Value='28'/><Setter Property='Padding' Value='7,0,9,0'/>
    <Setter Property='Template'><Setter.Value>" + ButtonTemplate(7) + @"</Setter.Value></Setter>
  </Style>

  <Style TargetType='TextBox'>
    <Setter Property='Foreground' Value='{DynamicResource PInk}'/>
    <Setter Property='Background' Value='{DynamicResource PSurface}'/>
    <Setter Property='BorderBrush' Value='{DynamicResource PLineStrong}'/>
    <Setter Property='BorderThickness' Value='1'/>
    <Setter Property='Padding' Value='10,6'/>
    <Setter Property='FontSize' Value='13'/>
    <Setter Property='CaretBrush' Value='{DynamicResource PInk}'/>
    <Setter Property='SelectionBrush' Value='{DynamicResource PAccent}'/>
    <Setter Property='FocusVisualStyle' Value='{x:Null}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='TextBox'>
      <!-- TextBox applies Padding to its text view itself; binding it here too doubles the inset. -->
      <Border x:Name='chrome' CornerRadius='8' Background='{TemplateBinding Background}' BorderBrush='{TemplateBinding BorderBrush}' BorderThickness='{TemplateBinding BorderThickness}' SnapsToDevicePixels='True'>
        <ScrollViewer x:Name='PART_ContentHost' Focusable='False'/>
      </Border>
      <ControlTemplate.Triggers>
        <Trigger Property='IsKeyboardFocusWithin' Value='True'><Setter TargetName='chrome' Property='BorderBrush' Value='{DynamicResource PAccent}'/></Trigger>
        <Trigger Property='IsEnabled' Value='False'><Setter Property='Opacity' Value='0.5'/></Trigger>
      </ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style TargetType='RichTextBox'>
    <Setter Property='SelectionBrush' Value='{DynamicResource PAccent}'/>
    <Setter Property='CaretBrush' Value='{DynamicResource PInk}'/>
    <Setter Property='FocusVisualStyle' Value='{x:Null}'/>
  </Style>

  <Style TargetType='ComboBox'>
    <Setter Property='Foreground' Value='{DynamicResource PInk}'/>
    <Setter Property='FontSize' Value='13'/>
    <Setter Property='MinHeight' Value='32'/>
    <Setter Property='Padding' Value='11,0,30,0'/>
    <Setter Property='Cursor' Value='Hand'/>
    <Setter Property='FocusVisualStyle' Value='{StaticResource PFocus}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='ComboBox'>
      <Grid>
        <ToggleButton Focusable='False' ClickMode='Press' IsChecked='{Binding IsDropDownOpen, RelativeSource={RelativeSource TemplatedParent}, Mode=TwoWay}'>
          <ToggleButton.Template><ControlTemplate TargetType='ToggleButton'>
            <Grid>
              <Border CornerRadius='8' Background='{DynamicResource PSurface}' BorderBrush='{DynamicResource PLineStrong}' BorderThickness='1' SnapsToDevicePixels='True'/>
              <Border x:Name='wash' CornerRadius='8' Background='Transparent'/>
              <TextBlock Text='&#xE70D;' FontFamily='Segoe Fluent Icons, Segoe MDL2 Assets' FontSize='10' HorizontalAlignment='Right' VerticalAlignment='Center' Margin='0,1,12,0' Foreground='{DynamicResource PMuted}'/>
            </Grid>
            <ControlTemplate.Triggers><Trigger Property='IsMouseOver' Value='True'><Setter TargetName='wash' Property='Background' Value='{DynamicResource PHover}'/></Trigger></ControlTemplate.Triggers>
          </ControlTemplate></ToggleButton.Template>
        </ToggleButton>
        <ContentPresenter Margin='{TemplateBinding Padding}' VerticalAlignment='Center' HorizontalAlignment='Left' Content='{TemplateBinding SelectionBoxItem}' ContentTemplate='{TemplateBinding SelectionBoxItemTemplate}' IsHitTestVisible='False'/>
        <Popup x:Name='PART_Popup' Placement='Bottom' VerticalOffset='2' HorizontalOffset='-8' IsOpen='{TemplateBinding IsDropDownOpen}' AllowsTransparency='True' Focusable='False' PopupAnimation='Fade'>
          <Grid Margin='8,2,8,14'>
            <Border CornerRadius='10' Background='{DynamicResource POverlay}'><Border.Effect><DropShadowEffect BlurRadius='14' ShadowDepth='3' Direction='270' Opacity='0.16'/></Border.Effect></Border>
            <Border CornerRadius='10' Background='{DynamicResource POverlay}' BorderBrush='{DynamicResource PLine}' BorderThickness='1' Padding='4' MinWidth='{Binding ActualWidth, RelativeSource={RelativeSource TemplatedParent}}'>
              <ScrollViewer MaxHeight='280' CanContentScroll='True'><ItemsPresenter KeyboardNavigation.DirectionalNavigation='Contained'/></ScrollViewer>
            </Border>
          </Grid>
        </Popup>
      </Grid>
      <ControlTemplate.Triggers><Trigger Property='IsEnabled' Value='False'><Setter Property='Opacity' Value='0.45'/></Trigger></ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style TargetType='ComboBoxItem'>
    <Setter Property='Foreground' Value='{DynamicResource PInk}'/>
    <Setter Property='FontSize' Value='13'/>
    <Setter Property='MinHeight' Value='32'/>
    <Setter Property='Padding' Value='10,0'/>
    <Setter Property='FocusVisualStyle' Value='{x:Null}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='ComboBoxItem'>
      <Border x:Name='item' CornerRadius='6' Background='Transparent' Padding='{TemplateBinding Padding}' MinHeight='{TemplateBinding MinHeight}'>
        <Grid>
          <ContentPresenter VerticalAlignment='Center' Margin='0,0,24,0'/>
          <TextBlock x:Name='check' Text='&#xE73E;' FontFamily='Segoe Fluent Icons, Segoe MDL2 Assets' FontSize='12' HorizontalAlignment='Right' VerticalAlignment='Center' Foreground='{DynamicResource PAccentText}' Visibility='Collapsed'/>
        </Grid>
      </Border>
      <ControlTemplate.Triggers>
        <Trigger Property='IsHighlighted' Value='True'><Setter TargetName='item' Property='Background' Value='{DynamicResource PHover}'/></Trigger>
        <Trigger Property='IsSelected' Value='True'><Setter TargetName='check' Property='Visibility' Value='Visible'/></Trigger>
      </ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>

  <Style TargetType='CheckBox'>
    <Setter Property='Foreground' Value='{DynamicResource PInk}'/>
    <Setter Property='FontSize' Value='13'/>
    <Setter Property='Cursor' Value='Hand'/>
    <Setter Property='VerticalContentAlignment' Value='Center'/>
    <Setter Property='FocusVisualStyle' Value='{StaticResource PFocus}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='CheckBox'>
      <Grid Background='Transparent'>
        <Grid.ColumnDefinitions><ColumnDefinition Width='*'/><ColumnDefinition Width='Auto'/></Grid.ColumnDefinitions>
        <ContentPresenter VerticalAlignment='Center' RecognizesAccessKey='True'/>
        <Border x:Name='track' Grid.Column='1' Width='36' Height='20' CornerRadius='10' Background='Transparent' BorderBrush='{DynamicResource PMuted}' BorderThickness='1.5' VerticalAlignment='Center' SnapsToDevicePixels='True'>
          <Ellipse x:Name='knob' Width='10' Height='10' Fill='{DynamicResource PInk2}' HorizontalAlignment='Left' VerticalAlignment='Center' Margin='4,0,0,0'/>
        </Border>
      </Grid>
      <ControlTemplate.Triggers>
        <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='track' Property='BorderBrush' Value='{DynamicResource PInk2}'/></Trigger>
        <Trigger Property='IsChecked' Value='True'>
          <Setter TargetName='track' Property='Background' Value='{DynamicResource PAccentStrong}'/>
          <Setter TargetName='track' Property='BorderBrush' Value='{DynamicResource PAccentStrong}'/>
          <Setter TargetName='knob' Property='Fill' Value='{DynamicResource POnAccent}'/>
          <Setter TargetName='knob' Property='Width' Value='14'/><Setter TargetName='knob' Property='Height' Value='14'/>
          <Setter TargetName='knob' Property='HorizontalAlignment' Value='Right'/><Setter TargetName='knob' Property='Margin' Value='0,0,1.5,0'/>
        </Trigger>
        <Trigger Property='IsEnabled' Value='False'><Setter Property='Opacity' Value='0.45'/></Trigger>
      </ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>

  <Style x:Key='PSettingsTabs' TargetType='TabControl'>
    <Setter Property='TabStripPlacement' Value='Left'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='TabControl'>
      <Grid KeyboardNavigation.TabNavigation='Local'>
        <Grid.ColumnDefinitions><ColumnDefinition Width='176'/><ColumnDefinition Width='*'/></Grid.ColumnDefinitions>
        <Border Background='{DynamicResource PSunken}' BorderBrush='{DynamicResource PLine}' BorderThickness='0,0,1,0' CornerRadius='11,0,0,11'>
          <DockPanel>
            <TextBlock DockPanel.Dock='Top' Text='设置' FontSize='14' FontWeight='SemiBold' FontFamily='Segoe UI, Microsoft YaHei UI' Foreground='{DynamicResource PInk}' Margin='22,20,0,16'/>
            <StackPanel IsItemsHost='True' Margin='10,0,10,10' KeyboardNavigation.TabIndex='0'/>
          </DockPanel>
        </Border>
        <ContentPresenter Grid.Column='1' x:Name='PART_SelectedContentHost' ContentSource='SelectedContent' Margin='0,0,0,60' KeyboardNavigation.TabIndex='1'/>
      </Grid>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style TargetType='TabItem'>
    <Setter Property='Foreground' Value='{DynamicResource PInk2}'/>
    <Setter Property='FontSize' Value='13'/>
    <Setter Property='Cursor' Value='Hand'/>
    <Setter Property='FocusVisualStyle' Value='{StaticResource PFocus}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='TabItem'>
      <Border x:Name='tab' Height='34' CornerRadius='7' Padding='12,0' Margin='0,0,0,2' Background='Transparent'>
        <ContentPresenter ContentSource='Header' VerticalAlignment='Center' RecognizesAccessKey='True'/>
      </Border>
      <ControlTemplate.Triggers>
        <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='tab' Property='Background' Value='{DynamicResource PHover}'/></Trigger>
        <Trigger Property='IsSelected' Value='True'><Setter TargetName='tab' Property='Background' Value='{DynamicResource PPressed}'/><Setter Property='Foreground' Value='{DynamicResource PInk}'/></Trigger>
      </ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style x:Key='PSegment' TargetType='RadioButton'>
    <Setter Property='Foreground' Value='{DynamicResource PInk2}'/>
    <Setter Property='FontSize' Value='13'/>
    <Setter Property='Height' Value='28'/>
    <Setter Property='MinWidth' Value='64'/>
    <Setter Property='Cursor' Value='Hand'/>
    <Setter Property='FocusVisualStyle' Value='{StaticResource PFocus}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='RadioButton'>
      <Border x:Name='seg' CornerRadius='6' Background='Transparent' BorderBrush='Transparent' BorderThickness='1' Padding='14,0'>
        <ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Center'/>
      </Border>
      <ControlTemplate.Triggers>
        <Trigger Property='IsMouseOver' Value='True'><Setter Property='Foreground' Value='{DynamicResource PInk}'/></Trigger>
        <Trigger Property='IsChecked' Value='True'><Setter TargetName='seg' Property='Background' Value='{DynamicResource PSurface}'/><Setter TargetName='seg' Property='BorderBrush' Value='{DynamicResource PLine}'/><Setter Property='Foreground' Value='{DynamicResource PInk}'/></Trigger>
      </ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>

  <Style TargetType='Slider'>
    <Setter Property='Focusable' Value='True'/>
    <Setter Property='FocusVisualStyle' Value='{x:Null}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='Slider'>
      <Grid Height='22' Background='Transparent'>
        <Border Height='4' CornerRadius='2' Background='{DynamicResource PLineStrong}' VerticalAlignment='Center'/>
        <Track x:Name='PART_Track' Orientation='Horizontal' Minimum='{TemplateBinding Minimum}' Maximum='{TemplateBinding Maximum}' Value='{Binding Value, RelativeSource={RelativeSource TemplatedParent}, Mode=TwoWay}'>
          <Track.DecreaseRepeatButton><RepeatButton Command='{x:Static Slider.DecreaseLarge}' Focusable='False'>
            <RepeatButton.Template><ControlTemplate TargetType='RepeatButton'><Grid Background='Transparent'><Border Height='4' CornerRadius='2' Background='{DynamicResource PAccent}' VerticalAlignment='Center'/></Grid></ControlTemplate></RepeatButton.Template>
          </RepeatButton></Track.DecreaseRepeatButton>
          <Track.IncreaseRepeatButton><RepeatButton Command='{x:Static Slider.IncreaseLarge}' Focusable='False'>
            <RepeatButton.Template><ControlTemplate TargetType='RepeatButton'><Border Background='Transparent'/></ControlTemplate></RepeatButton.Template>
          </RepeatButton></Track.IncreaseRepeatButton>
          <Track.Thumb><Thumb Focusable='False' Width='16' Height='16'>
            <Thumb.Template><ControlTemplate TargetType='Thumb'>
              <Grid>
                <Ellipse x:Name='halo' Fill='{DynamicResource PAccentTint}' Margin='-3' Visibility='Collapsed'/>
                <Ellipse Fill='White' Stroke='#40000000' StrokeThickness='1'/>
              </Grid>
              <ControlTemplate.Triggers>
                <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='halo' Property='Visibility' Value='Visible'/></Trigger>
                <Trigger Property='IsDragging' Value='True'><Setter TargetName='halo' Property='Visibility' Value='Visible'/></Trigger>
              </ControlTemplate.Triggers>
            </ControlTemplate></Thumb.Template>
          </Thumb></Track.Thumb>
        </Track>
      </Grid>
      <ControlTemplate.Triggers><Trigger Property='IsKeyboardFocused' Value='True'><Setter TargetName='PART_Track' Property='Opacity' Value='1'/></Trigger></ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>

  <Style TargetType='ScrollBar'>
    <Setter Property='Width' Value='10'/><Setter Property='MinWidth' Value='0'/><Setter Property='Background' Value='Transparent'/><Setter Property='Focusable' Value='False'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='ScrollBar'>
      <Grid Background='Transparent'>
        <Track x:Name='PART_Track' IsDirectionReversed='True' Orientation='{TemplateBinding Orientation}' Minimum='{TemplateBinding Minimum}' Maximum='{TemplateBinding Maximum}' ViewportSize='{TemplateBinding ViewportSize}' Value='{Binding Value, RelativeSource={RelativeSource TemplatedParent}, Mode=TwoWay}'>
          <Track.DecreaseRepeatButton><RepeatButton x:Name='decrease' Command='{x:Static ScrollBar.PageUpCommand}' Focusable='False'><RepeatButton.Template><ControlTemplate TargetType='RepeatButton'><Border Background='Transparent'/></ControlTemplate></RepeatButton.Template></RepeatButton></Track.DecreaseRepeatButton>
          <Track.Thumb><Thumb x:Name='thumb' MinHeight='24' Focusable='False'><Thumb.Template><ControlTemplate TargetType='Thumb'>
            <Border x:Name='grip' Background='{DynamicResource PMuted}' CornerRadius='3' Margin='2' Opacity='0.32'/>
            <ControlTemplate.Triggers><Trigger Property='IsMouseOver' Value='True'><Setter TargetName='grip' Property='Opacity' Value='0.6'/></Trigger><Trigger Property='IsDragging' Value='True'><Setter TargetName='grip' Property='Opacity' Value='0.75'/></Trigger></ControlTemplate.Triggers>
          </ControlTemplate></Thumb.Template></Thumb></Track.Thumb>
          <Track.IncreaseRepeatButton><RepeatButton x:Name='increase' Command='{x:Static ScrollBar.PageDownCommand}' Focusable='False'><RepeatButton.Template><ControlTemplate TargetType='RepeatButton'><Border Background='Transparent'/></ControlTemplate></RepeatButton.Template></RepeatButton></Track.IncreaseRepeatButton>
        </Track>
      </Grid>
      <ControlTemplate.Triggers>
        <Trigger Property='Orientation' Value='Horizontal'>
          <Setter Property='Width' Value='Auto'/><Setter Property='Height' Value='10'/>
          <Setter TargetName='PART_Track' Property='IsDirectionReversed' Value='False'/>
          <Setter TargetName='thumb' Property='MinHeight' Value='0'/><Setter TargetName='thumb' Property='MinWidth' Value='24'/>
          <Setter TargetName='decrease' Property='Command' Value='{x:Static ScrollBar.PageLeftCommand}'/><Setter TargetName='increase' Property='Command' Value='{x:Static ScrollBar.PageRightCommand}'/>
        </Trigger>
        <Trigger Property='IsEnabled' Value='False'><Setter TargetName='thumb' Property='Opacity' Value='0'/></Trigger>
      </ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>

  <Style TargetType='ToolTip'>
    <Setter Property='Foreground' Value='{DynamicResource PSurface}'/>
    <Setter Property='Background' Value='{DynamicResource PInk}'/>
    <Setter Property='FontSize' Value='12'/>
    <Setter Property='Padding' Value='8,5'/>
    <Setter Property='HasDropShadow' Value='False'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='ToolTip'>
      <Border CornerRadius='6' Background='{TemplateBinding Background}' Padding='{TemplateBinding Padding}' SnapsToDevicePixels='True'>
        <ContentPresenter TextElement.Foreground='{TemplateBinding Foreground}'/>
      </Border>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
</ResourceDictionary>";
    }

    internal static ResourceDictionary Resources() {
      var resources = (ResourceDictionary)System.Windows.Markup.XamlReader.Parse(Markup());
      resources["PInk"] = T.Ink; resources["PInk2"] = T.InkSecondary; resources["PMuted"] = T.Muted; resources["PFaint"] = T.Faint;
      resources["PSurface"] = T.Surface; resources["PSunken"] = T.Sunken; resources["POverlay"] = T.Overlay;
      resources["PHover"] = T.Hover; resources["PPressed"] = T.Pressed; resources["PLine"] = T.Line; resources["PLineStrong"] = T.LineStrong;
      resources["PAccent"] = T.Accent; resources["PAccentText"] = T.AccentText; resources["PAccentStrong"] = T.AccentStrong;
      resources["PAccentTint"] = T.AccentTint; resources["POnAccent"] = T.OnAccent; resources["PDanger"] = T.Danger;
      // Generic keys consumed by the shared LanguagePicker / OpacityControl.
      // "Accent" is used for text there, so it maps to the readable AccentText.
      resources["Ink"] = T.Ink; resources["Muted"] = T.Muted; resources["Surface"] = T.Overlay; resources["Soft"] = T.Sunken;
      resources["Line"] = T.Line; resources["Hover"] = T.Hover; resources["Accent"] = T.AccentText; resources["Tint"] = T.AccentTint;
      resources["PaperDesign"] = true;
      return resources;
    }

    // Window defaults for every Paper window.
    internal static void Prepare(Window window, ResourceDictionary resources) {
      window.Resources.MergedDictionaries.Add(resources);
      window.FontFamily = T.UiFont; window.FontSize = T.Body; window.Foreground = T.Ink;
    }

    // Two empty silhouettes carry the shadows; text never sits under an Effect.
    // Keeps the shared WindowShell contract (alpha-1 gutter, SetContentOpacity).
    internal static Visuals.WindowShell Shell(UIElement child, double radius, double gutter, bool compact = false) {
      var shell = new Visuals.WindowShell { Margin = new Thickness(gutter), UseLayoutRounding = true, SnapsToDevicePixels = true };
      var shadows = new Grid { IsHitTestVisible = false, CacheMode = new BitmapCache() };
      shadows.Children.Add(Silhouette(radius, compact ? 9 : 14, compact ? 2 : 3, T.ShadowAmbient));
      shadows.Children.Add(Silhouette(radius, compact ? 2 : 3, 1, T.ShadowKey));
      shell.Children.Add(shadows);
      shell.Face = new Border {
        Background = T.Surface, BorderBrush = T.Edge, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(radius),
        Child = child, UseLayoutRounding = true, SnapsToDevicePixels = true
      };
      shell.Children.Add(shell.Face); shell.SetContentOpacity(1); return shell;
    }
    static Border Silhouette(double radius, double blur, double depth, ThemeNumber strength) {
      var effect = new DropShadowEffect { BlurRadius = blur, ShadowDepth = depth, Direction = 270, Color = Colors.Black, RenderingBias = RenderingBias.Quality };
      BindingOperations.SetBinding(effect, DropShadowEffect.OpacityProperty, new Binding("Value") { Source = strength });
      return new Border { Background = T.Surface, CornerRadius = new CornerRadius(radius), IsHitTestVisible = false, Effect = effect };
    }

    internal static TextBlock Text(string text, double size, Brush color, bool wrap = false) {
      var block = new TextBlock { Text = text, FontSize = size, Foreground = color, VerticalAlignment = VerticalAlignment.Center };
      if (wrap) { block.TextWrapping = TextWrapping.Wrap; block.LineHeight = Math.Round(size * 1.45); block.LineStackingStrategy = LineStackingStrategy.BlockLineHeight; }
      else { block.TextWrapping = TextWrapping.NoWrap; block.TextTrimming = TextTrimming.CharacterEllipsis; }
      return block;
    }
    internal static TextBlock Strong(string text, double size) {
      var block = Text(text, size, T.Ink); block.FontFamily = T.StrongFont; block.FontWeight = FontWeights.SemiBold; return block;
    }

    static Button Make(string styleKey, object content, Action click, string help) {
      var button = new Button { Content = content };
      button.SetResourceReference(FrameworkElement.StyleProperty, styleKey);
      if (help != null) { button.ToolTip = help; button.SetValue(AutomationProperties.NameProperty, help); }
      button.Click += delegate { if (click != null) click(); };
      return button;
    }
    internal static Button IconButton(string glyph, Action click, string help, double glyphSize = 16) {
      return Make("PIconButton", Glyphs.Icon(glyph, glyphSize), click, help);
    }
    internal static Button IconButton(FrameworkElement icon, Action click, string help) {
      return Make("PIconButton", icon, click, help);
    }
    internal static StackPanel Label(string glyph, string text, double glyphSize = 14) {
      var row = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
      var icon = Glyphs.Icon(glyph, glyphSize); icon.Margin = new Thickness(0, 0, 6, 0); row.Children.Add(icon);
      row.Children.Add(new TextBlock { Text = text, VerticalAlignment = VerticalAlignment.Center });
      return row;
    }
    internal static Button TextButton(string glyph, string text, Action click, string help) {
      return Make("PTextButton", Label(glyph, text, 13), click, help);
    }
    internal static Button Primary(object content, Action click, string help) { return Make("PPrimary", content, click, help); }
    internal static Button Outline(object content, Action click, string help) { return Make("POutline", content, click, help); }
    internal static Button Plain(object content, Action click, string help) { return Make("PTextButton", content, click, help); }
    internal static Button ToolbarButton(string glyph, string text, Action click, string help) {
      var row = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
      var icon = Glyphs.Icon(glyph, 15, T.InkSecondary); icon.Margin = new Thickness(0, 0, 5, 0); row.Children.Add(icon);
      row.Children.Add(new TextBlock { Text = text, FontSize = 13, VerticalAlignment = VerticalAlignment.Center });
      return Make("PToolbarButton", row, click, help);
    }

    internal static Border Hairline(bool vertical = false) {
      var line = new Border { Background = T.Line, SnapsToDevicePixels = true, IsHitTestVisible = false };
      if (vertical) line.Width = 1; else line.Height = 1;
      return line;
    }

    // Wheel events reach the outer reading scroller once the inner box cannot scroll.
    internal static void ForwardWheel(System.Windows.Controls.Primitives.TextBoxBase inner, ScrollViewer outer) {
      inner.PreviewMouseWheel += delegate(object sender, MouseWheelEventArgs e) {
        bool up = e.Delta > 0;
        bool innerCanScroll = inner.ExtentHeight > inner.ViewportHeight + 1 &&
          (up ? inner.VerticalOffset > 0 : inner.VerticalOffset + inner.ViewportHeight < inner.ExtentHeight - 1);
        if (innerCanScroll) return;
        e.Handled = true;
        outer.RaiseEvent(new MouseWheelEventArgs(e.MouseDevice, e.Timestamp, e.Delta) { RoutedEvent = UIElement.MouseWheelEvent, Source = inner });
      };
    }
  }
}
