using System.ComponentModel;
using System.Windows;
using System.Windows.Media;

namespace DshSelectionAssistant {
  // Numeric theme value that sealed effects/styles can bind to (shadow strength).
  internal sealed class ThemeNumber : INotifyPropertyChanged {
    public double Value { get; private set; }
    public event PropertyChangedEventHandler PropertyChanged;
    internal ThemeNumber(double value) { Value = value; }
    internal void Set(double value) { Value = value; if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Value")); }
  }

  // "Quiet Paper" design tokens: accepted daily design and isolated demos.
  // Independent Paper* theme keys: never touches the Legacy or Claude brushes.
  // Base values follow the installed dsh-claude-style (canvas #ffffff/#191919,
  // ink #161616, accent #d97757); low-emphasis text is darkened where the
  // original tertiary grey would fall below 4.5:1 on its surface.
  internal static class PaperTheme {
    internal static readonly SolidColorBrush Ink = Theme.Brush("PaperInk", "#161616");
    internal static readonly SolidColorBrush InkSecondary = Theme.Brush("PaperInk2", "#4F4A4B");
    internal static readonly SolidColorBrush Muted = Theme.Brush("PaperMuted", "#70686A");
    internal static readonly SolidColorBrush Faint = Theme.Brush("PaperFaint", "#91888A");
    internal static readonly SolidColorBrush Surface = Theme.Brush("PaperSurface", "#FFFFFF");
    internal static readonly SolidColorBrush Sunken = Theme.Brush("PaperSunken", "#F8F7F7");
    internal static readonly SolidColorBrush Overlay = Theme.Brush("PaperOverlay", "#FFFFFF");
    internal static readonly SolidColorBrush Hover = Theme.Brush("PaperHover", "#0F161616");
    internal static readonly SolidColorBrush Pressed = Theme.Brush("PaperPressed", "#1A161616");
    internal static readonly SolidColorBrush Line = Theme.Brush("PaperLine", "#E9E9E9");
    internal static readonly SolidColorBrush LineStrong = Theme.Brush("PaperLineStrong", "#D9D5D6");
    internal static readonly SolidColorBrush Edge = Theme.Brush("PaperEdge", "#E4E2E2");
    internal static readonly SolidColorBrush Accent = Theme.Brush("PaperAccent", "#D97757");
    internal static readonly SolidColorBrush AccentText = Theme.Brush("PaperAccentText", "#B95836");
    internal static readonly SolidColorBrush AccentStrong = Theme.Brush("PaperAccentStrong", "#B95836");
    internal static readonly SolidColorBrush AccentTint = Theme.Brush("PaperAccentTint", "#1FD97757");
    internal static readonly SolidColorBrush OnAccent = Theme.Brush("PaperOnAccent", "#FFFFFF");
    internal static readonly SolidColorBrush Danger = Theme.Brush("PaperDanger", "#B3412E");
    internal static readonly SolidColorBrush DangerTint = Theme.Brush("PaperDangerTint", "#12B3412E");
    internal static readonly SolidColorBrush Success = Theme.Brush("PaperSuccess", "#2E7D4F");
    internal static readonly SolidColorBrush Skeleton = Theme.Brush("PaperSkeleton", "#EEECEC");
    internal static readonly ThemeNumber ShadowKey = new ThemeNumber(0.10);
    internal static readonly ThemeNumber ShadowAmbient = new ThemeNumber(0.11);

    // Latin glyphs from Segoe UI (Variable on Windows 11), CJK falls back to YaHei UI.
    internal static readonly FontFamily UiFont = new FontFamily("Segoe UI Variable Text, Segoe UI, Microsoft YaHei UI");
    // Static Segoe faces for SemiBold text; avoids synthetic emboldening of the variable face.
    internal static readonly FontFamily StrongFont = new FontFamily("Segoe UI, Microsoft YaHei UI");
    internal static readonly FontFamily MonoFont = new FontFamily("Consolas, Microsoft YaHei UI");
    // One switch for the reading surfaces (result document, quick input).
    internal static readonly TextFormattingMode ReadingFormatting = TextFormattingMode.Ideal;

    internal const double Caption = 11, Meta = 12, Body = 13, Title = 14, PageTitle = 18;
    internal const double ReadingLineHeight = 1.6;

    // Prevent beforefieldinit: ApplyTheme may run before any brush is read.
    static PaperTheme() { }

    internal static void Apply(bool dark) {
      Theme.Set("PaperInk", dark ? "#EDEBEB" : "#161616");
      Theme.Set("PaperInk2", dark ? "#CFC8CA" : "#4F4A4B");
      Theme.Set("PaperMuted", dark ? "#A69EA0" : "#70686A");
      Theme.Set("PaperFaint", dark ? "#7E7678" : "#91888A");
      Theme.Set("PaperSurface", dark ? "#191919" : "#FFFFFF");
      Theme.Set("PaperSunken", dark ? "#1F1F1F" : "#F8F7F7");
      Theme.Set("PaperOverlay", dark ? "#282828" : "#FFFFFF");
      Theme.Set("PaperHover", dark ? "#14FFFFFF" : "#0F161616");
      Theme.Set("PaperPressed", dark ? "#21FFFFFF" : "#1A161616");
      Theme.Set("PaperLine", dark ? "#17FFFFFF" : "#E9E9E9");
      Theme.Set("PaperLineStrong", dark ? "#29FFFFFF" : "#D9D5D6");
      Theme.Set("PaperEdge", dark ? "#1FFFFFFF" : "#E4E2E2");
      Theme.Set("PaperAccent", "#D97757");
      Theme.Set("PaperAccentText", dark ? "#E08A6C" : "#B95836");
      Theme.Set("PaperAccentStrong", "#B95836");
      Theme.Set("PaperAccentTint", dark ? "#33D97757" : "#1FD97757");
      Theme.Set("PaperOnAccent", "#FFFFFF");
      Theme.Set("PaperDanger", dark ? "#EE8E7B" : "#B3412E");
      Theme.Set("PaperDangerTint", dark ? "#1FEE8E7B" : "#12B3412E");
      Theme.Set("PaperSuccess", dark ? "#7CC897" : "#2E7D4F");
      Theme.Set("PaperSkeleton", dark ? "#2A2A2A" : "#EEECEC");
      ShadowKey.Set(dark ? 0.42 : 0.10);
      ShadowAmbient.Set(dark ? 0.48 : 0.11);
    }
  }
}
