using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Shapes;

namespace DshSelectionAssistant {
  // System icon fonts (Windows 11 Fluent, Windows 10 MDL2). Nothing is downloaded.
  // Each glyph keeps a Visuals path fallback for trimmed systems without either font.
  internal static class Glyphs {
    internal static readonly FontFamily Family = new FontFamily("Segoe Fluent Icons, Segoe MDL2 Assets");
    internal const string Translate = "\uE8C1", Explain = "\uE82F", Summarize = "\uEA37";
    internal const string Copy = "\uE8C8", Paste = "\uE77F", Clear = "\uE75C";
    internal const string Pin = "\uE718", Pinned = "\uE842", Retry = "\uE72C", Stop = "\uE73B";
    internal const string Settings = "\uE713", Close = "\uE8BB", Minimize = "\uE921";
    internal const string Down = "\uE70D", Up = "\uE70E", Check = "\uE73E", Warning = "\uE7BA", Info = "\uE946";

    static readonly Dictionary<string, string> Fallbacks = new Dictionary<string, string> {
      { Translate, "translate" }, { Explain, "explain" }, { Summarize, "summarize" }, { Copy, "copy" }, { Paste, "paste" },
      { Clear, "clear" }, { Pin, "pin" }, { Pinned, "pinOff" }, { Retry, "refresh" }, { Stop, "stop" }, { Settings, "settings" },
      { Close, "close" }, { Minimize, "minus" }, { Down, "chevron" }, { Up, "chevronUp" }, { Check, "check" }, { Warning, "more" }, { Info, "more" }
    };
    static GlyphTypeface[] Faces;

    static bool Available(string glyph) {
      if (Faces == null) {
        var found = new List<GlyphTypeface>();
        foreach (string name in new[] { "Segoe Fluent Icons", "Segoe MDL2 Assets" }) {
          GlyphTypeface face;
          try {
            if (new Typeface(new FontFamily(name), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal).TryGetGlyphTypeface(out face)) found.Add(face);
          } catch { }
        }
        Faces = found.ToArray();
      }
      foreach (var face in Faces) if (face.CharacterToGlyphMap.ContainsKey(glyph[0])) return true;
      return false;
    }

    internal static string ActionGlyph(string action) { return action == "explain" ? Explain : action == "summarize" ? Summarize : Translate; }

    // Foreground is inherited from the hosting control unless given explicitly.
    internal static FrameworkElement Icon(string glyph, double size = 16, Brush color = null) {
      if (!Available(glyph)) {
        string path; if (!Fallbacks.TryGetValue(glyph, out path)) path = "more";
        var fallback = (FrameworkElement)Visuals.Icon(path, size, color); return fallback;
      }
      var text = new TextBlock {
        Text = glyph, FontFamily = Family, FontSize = size, IsHitTestVisible = false,
        VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center,
        TextAlignment = TextAlignment.Center, LineHeight = size, LineStackingStrategy = LineStackingStrategy.BlockLineHeight
      };
      TextOptions.SetTextFormattingMode(text, TextFormattingMode.Display);
      if (color != null) text.Foreground = color;
      return text;
    }

    // The opacity droplet has no good system glyph: drawn at its final 16-DIP
    // size (no Viewbox stroke scaling) with the same visual weight as Fluent.
    internal static FrameworkElement Droplet(Brush color = null) {
      var path = new Path {
        Data = Geometry.Parse("M8,1.8 C6.9,4.1 3.8,7 3.8,9.9 A4.2,4.2 0 0 0 12.2,9.9 C12.2,7 9.1,4.1 8,1.8 Z M6,10.2 A2.1,2.1 0 0 0 8,12.2"),
        StrokeThickness = 1.15, StrokeLineJoin = PenLineJoin.Round, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round,
        Fill = Brushes.Transparent, IsHitTestVisible = false
      };
      if (color != null) path.Stroke = color;
      else path.SetBinding(Shape.StrokeProperty, new Binding("Foreground") {
        RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Control), 1), FallbackValue = PaperTheme.InkSecondary
      });
      var canvas = new Canvas { Width = 16, Height = 16, IsHitTestVisible = false, VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center };
      canvas.Children.Add(path); return canvas;
    }
  }
}
