using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using T = DshSelectionAssistant.PaperTheme;

namespace DshSelectionAssistant {
  // Quiet Paper selection toolbar: icon + short label, equal weight, real drag
  // handle, no-activate window. Placement still uses Native.PlaceToolbar.
  internal static class PaperToolbar {
    internal const double Gutter = 8;
    internal static void Attach(Window toolbar, Action<string> choose, Action settings, Action drag) {
      var resources = PaperStyles.Resources();
      PaperStyles.Prepare(toolbar, resources);
      var row = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(2), Background = Brushes.Transparent };
      var grip = new Border { Width = 14, Height = 28, Background = Brushes.Transparent, Cursor = Cursors.SizeAll, ToolTip = "拖动浮条", Child = Dots() };
      grip.SetValue(AutomationProperties.NameProperty, "拖动浮条");
      grip.MouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs e) { e.Handled = true; drag(); };
      row.Children.Add(grip);
      row.Children.Add(PaperStyles.ToolbarButton(Glyphs.Translate, "翻译", delegate { choose("translate"); }, "翻译"));
      row.Children.Add(PaperStyles.ToolbarButton(Glyphs.Explain, "解释", delegate { choose("explain"); }, "解释"));
      row.Children.Add(PaperStyles.ToolbarButton(Glyphs.Summarize, "总结", delegate { choose("summarize"); }, "总结"));
      row.Children.Add(new Border { Width = 1, Height = 16, Background = T.Line, Margin = new Thickness(4, 0, 4, 0), VerticalAlignment = VerticalAlignment.Center });
      var preferences = PaperStyles.IconButton(Glyphs.Settings, settings, "设置 / 暂停", 14);
      preferences.Foreground = T.Muted; row.Children.Add(preferences);
      // Gaps between buttons also drag; buttons handle their own presses.
      row.MouseLeftButtonDown += delegate { drag(); };
      var shell = PaperStyles.Shell(row, 10, Gutter, true);
      toolbar.Content = shell;
      shell.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
      toolbar.Width = Math.Ceiling(shell.DesiredSize.Width); toolbar.Height = Math.Ceiling(shell.DesiredSize.Height);
    }
    static UIElement Dots() {
      var canvas = new Canvas { Width = 6, Height = 12, Opacity = 0.7, IsHitTestVisible = false, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
      for (int y = 0; y < 3; y++) for (int x = 0; x < 2; x++) {
        var dot = new Ellipse { Width = 2, Height = 2, Fill = T.Muted };
        Canvas.SetLeft(dot, x * 4); Canvas.SetTop(dot, y * 5); canvas.Children.Add(dot);
      }
      return canvas;
    }
  }

  internal partial class Program {
    static double ToolbarGutter { get { return Paper ? PaperToolbar.Gutter : 6; } }

    // Paper settings: four pages in a left-navigation TabControl. Every original
    // field keeps its type and static slot so SaveSettings / PopulateModels and
    // the demo tab commands work unchanged; nothing saves automatically.
    static void ShowSettingsPaper() {
      var resources = PaperStyles.Resources();
      Settings = WindowBase(760, 600, false, true);
      Settings.Title = "DSH 划词助手 · 设置";
      Settings.WindowStartupLocation = WindowStartupLocation.CenterScreen;
      Settings.MinWidth = 580; Settings.MinHeight = 480; Settings.ResizeMode = ResizeMode.CanResize;
      PaperStyles.Prepare(Settings, resources);
      Settings.Closed += delegate { Settings = null; SettingsTabs = null; SettingsStatus = null; SaveButton = null; ModelBox = null; PromptBoxes.Clear(); ClearPendingSave(); };
      var root = new Grid();

      SettingsTabs = new TabControl();
      SettingsTabs.SetResourceReference(FrameworkElement.StyleProperty, "PSettingsTabs");
      SettingsTabs.SetValue(AutomationProperties.NameProperty, "设置分类");

      // 常规
      var general = Page("常规");
      var listening = Group(general, "划词");
      EnabledBox = new CheckBox { IsChecked = Bool(Config, "enabled") };
      Row(listening, "启用全局划词", "关闭后自动划词与 Ctrl+Alt+D 都会停止；快捷翻译仍可使用。", EnabledBox);
      TriggerBox = Combo("选中文字自动出现工具条", "仅使用 Ctrl+Alt+D 呼出工具条"); TriggerBox.SelectedIndex = Str(Config, "trigger") == "hotkey" ? 1 : 0;
      Row(listening, "触发方式", "自动模式下也可以用 Ctrl+Alt+D 手动呼出。", Fixed(TriggerBox, 216));
      var output = Group(general, "输出");
      LanguageBox = new LanguagePicker("自动中英互译 / 中文解释与总结", resources); LanguageBox.UsePaper(false, null);
      LanguageBox.SetValue(Str(Config, "targetLanguage", "auto"));
      Row(output, "输出语言", "翻译默认中英互译，解释与总结默认中文。", Fixed(LanguageBox, 248));
      var quick = Group(general, "快捷翻译");
      QuickHotkeyBox = Combo("Ctrl+Alt+T", "Ctrl+Shift+T", "Alt+Shift+T", "关闭快捷键");
      QuickHotkeyBox.SelectedIndex = Str(Config, "quickHotkey", "Ctrl+Alt+T") == "none" ? 3 : Math.Max(0, QuickHotkeyBox.Items.IndexOf(Str(Config, "quickHotkey", "Ctrl+Alt+T")));
      Row(quick, "快捷键", "也可以双击托盘图标打开快捷翻译。", Fixed(QuickHotkeyBox, 168));
      var look = Group(general, "外观");
      ThemeBox = Combo("跟随系统", "浅色", "深色"); ThemeBox.SelectedIndex = Str(Config, "theme") == "dark" ? 2 : Str(Config, "theme") == "light" ? 1 : 0;
      Row(look, "主题", "跟随系统时会随 Windows 深浅色自动切换。", Fixed(ThemeBox, 168));
      SettingsTabs.Items.Add(Tab("常规", general));

      // 模型
      var model = Page("模型");
      var catalog = Group(model, "模型");
      ModelBox = Combo("跟随 DSH 默认模型");
      Stacked(catalog, "模型目录", "跟随 DSH 全局默认模型，或从目录中选择。这里不会复制 API Key。", ModelBox);
      var route = Group(model, "手动路由");
      ProviderBox = Edit(Str(Config, "provider")); ModelIdBox = Edit(Str(Config, "model"));
      Stacked(route, "提供方 route ID", "留空则跟随上方选择或默认模型。", ProviderBox);
      Stacked(route, "模型 ID", "需与提供方成对填写。", ModelIdBox);
      var pairHint = PaperStyles.Text("提供方与模型 ID 需要成对填写，保存时以宿主校验为准。", T.Meta, T.Danger, true);
      pairHint.Margin = new Thickness(16, 0, 16, 12); pairHint.Visibility = Visibility.Collapsed; route.Children.Add(pairHint);
      TextChangedEventHandler pair = delegate {
        bool one = string.IsNullOrWhiteSpace(ProviderBox.Text) != string.IsNullOrWhiteSpace(ModelIdBox.Text);
        pairHint.Visibility = one ? Visibility.Visible : Visibility.Collapsed;
      };
      ProviderBox.TextChanged += pair; ModelIdBox.TextChanged += pair;
      ModelBox.SelectionChanged += delegate { var item = ModelBox.SelectedItem as ComboBoxItem; if (item == null || ProviderBox == null) return; var selected = item.Tag as Dictionary<string, object>; ProviderBox.Text = Str(selected, "provider"); ModelIdBox.Text = Str(selected, "model"); };
      PopulateModels(); SettingsTabs.Items.Add(Tab("模型", model));

      // 提示词: one editor at a time; all three boxes stay alive for SaveSettings.
      var prompts = new DockPanel { Margin = new Thickness(28, 22, 24, 8), LastChildFill = true };
      var promptsTitle = PaperStyles.Text("提示词", T.PageTitle, T.Ink); promptsTitle.Margin = new Thickness(0, 0, 0, 6);
      DockPanel.SetDock(promptsTitle, Dock.Top); prompts.Children.Add(promptsTitle);
      var promptsIntro = PaperStyles.Text("可使用 {{targetLanguage}}；留空即恢复默认。选区会单独作为资料提交，不拼进系统指令。", T.Meta, T.Muted, true);
      promptsIntro.Margin = new Thickness(0, 0, 0, 14); DockPanel.SetDock(promptsIntro, Dock.Top); prompts.Children.Add(promptsIntro);
      var segments = new Border { Background = T.Sunken, BorderBrush = T.Line, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(8), Padding = new Thickness(2), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 0, 0, 12) };
      var segmentRow = new StackPanel { Orientation = Orientation.Horizontal }; segments.Child = segmentRow;
      DockPanel.SetDock(segments, Dock.Top); prompts.Children.Add(segments);
      var editorTools = new DockPanel { Margin = new Thickness(0, 10, 0, 0), LastChildFill = false };
      DockPanel.SetDock(editorTools, Dock.Bottom); prompts.Children.Add(editorTools);
      var editors = new Grid(); prompts.Children.Add(editors);
      var values = Obj(Config, "prompts");
      TextBox visible = null;
      foreach (var pairInfo in new[] { new[] { "translate", "翻译" }, new[] { "explain", "解释" }, new[] { "summarize", "总结" } }) {
        var box = Edit(Str(values, pairInfo[0]), true, double.NaN);
        box.Margin = new Thickness(0); box.Padding = new Thickness(14, 12, 14, 12); box.MinHeight = 160;
        box.VerticalAlignment = VerticalAlignment.Stretch; box.FontSize = 13;
        TextBlock.SetLineHeight(box, 21); TextBlock.SetLineStackingStrategy(box, LineStackingStrategy.MaxHeight);
        box.SetValue(AutomationProperties.NameProperty, pairInfo[1] + "提示词");
        PromptBoxes[pairInfo[0]] = box; editors.Children.Add(box);
        var segment = new RadioButton { Content = pairInfo[1], GroupName = "paper-prompts", IsChecked = visible == null };
        segment.SetResourceReference(FrameworkElement.StyleProperty, "PSegment");
        segment.SetValue(AutomationProperties.NameProperty, "编辑" + pairInfo[1] + "提示词");
        var target = box;
        box.Visibility = visible == null ? Visibility.Visible : Visibility.Collapsed;
        if (visible == null) visible = box;
        segment.Checked += delegate { foreach (UIElement child in editors.Children) child.Visibility = child == target ? Visibility.Visible : Visibility.Collapsed; visible = target; };
        segmentRow.Children.Add(segment);
      }
      var insert = PaperStyles.Outline("插入 {{targetLanguage}}", delegate {
        if (visible == null) return;
        visible.SelectedText = "{{targetLanguage}}"; visible.CaretIndex = visible.SelectionStart + visible.SelectionLength; visible.SelectionLength = 0; visible.Focus();
      }, "在光标处插入目标语言变量");
      insert.FontSize = 12; insert.Height = 30; DockPanel.SetDock(insert, Dock.Left); editorTools.Children.Add(insert);
      var reset = PaperStyles.Plain("清空并恢复默认", delegate { if (visible != null) { visible.Clear(); visible.Focus(); } }, "清空当前提示词；保存后使用默认提示词");
      reset.Margin = new Thickness(8, 0, 0, 0); DockPanel.SetDock(reset, Dock.Left); editorTools.Children.Add(reset);
      var promptsTab = new TabItem { Header = "提示词", Content = prompts }; promptsTab.SetValue(AutomationProperties.NameProperty, "提示词");
      SettingsTabs.Items.Add(promptsTab);

      // 隐私与取词
      var privacy = Page("隐私与取词");
      var intro = PaperStyles.Text("选中时仅在本机暂存文字；点击翻译、解释或总结后，才发给 DSH 中配置的模型服务。插件不创建聊天会话、不保存原文或译文，不读取周围段落。模型服务及 DSH 的诊断策略另行适用。", T.Body, T.InkSecondary, true);
      intro.LineHeight = 21; intro.Margin = new Thickness(0, 0, 0, 6); privacy.Children.Add(intro);
      var caution = PaperStyles.Text("暂停会停止取词钩子。黑名单用于排除密码管理器、终端等应用，但不能保证识别所有敏感输入。请勿在敏感内容上调用 AI。", T.Meta, T.Muted, true);
      privacy.Children.Add(caution);
      var clip = Group(privacy, "剪贴板");
      ClipboardBox = new CheckBox { IsChecked = Bool(Config, "clipboardFallback") };
      Row(clip, "允许剪贴板兜底", "可能模拟 Ctrl+C 并短暂接触剪贴板。默认关闭；PDF 或特殊控件取不到时再尝试。不需要管理员权限，也不跨越提权窗口。", ClipboardBox);
      var blocked = Group(privacy, "应用黑名单");
      object blockedApps; string list = Config.TryGetValue("blockedApps", out blockedApps) && blockedApps is object[] ? string.Join("\n", ((object[])blockedApps).Select(Convert.ToString).ToArray()) : "";
      BlockedBox = Edit(list, true, 176); BlockedBox.FontFamily = T.MonoFont; BlockedBox.FontSize = 12.5;
      Stacked(blocked, "进程文件名", "每行一个，例如 WindowsTerminal.exe。", BlockedBox);
      SettingsTabs.Items.Add(Tab("隐私与取词", privacy));
      root.Children.Add(SettingsTabs);

      // Footer: status only when it means something; Cancel / Save.
      var footer = new DockPanel { Height = 60, Margin = new Thickness(176 + 28, 0, 20, 0), VerticalAlignment = VerticalAlignment.Bottom, LastChildFill = true };
      var buttons = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
      var cancel = PaperStyles.Outline("取消", delegate { Settings.Close(); }, "取消"); buttons.Children.Add(cancel);
      SaveButton = PaperStyles.Primary("保存", SaveSettings, "保存设置"); SaveButton.Margin = new Thickness(8, 0, 0, 0); SaveButton.MinWidth = 72; buttons.Children.Add(SaveButton);
      DockPanel.SetDock(buttons, Dock.Right); footer.Children.Add(buttons);
      SettingsStatus = PaperStyles.Text("", T.Meta, T.Muted); footer.Children.Add(SettingsStatus);
      root.Children.Add(footer);
      var close = PaperStyles.IconButton(Glyphs.Close, delegate { Settings.Close(); }, "关闭设置", 10);
      close.HorizontalAlignment = HorizontalAlignment.Right; close.VerticalAlignment = VerticalAlignment.Top; close.Margin = new Thickness(0, 10, 10, 0);
      root.Children.Add(close);
      // Blank areas near the top drag the window; controls keep their own presses.
      root.MouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs e) {
        if (e.ChangedButton == MouseButton.Left && e.GetPosition(root).Y < 56) Settings.DragMove();
      };

      Settings.Content = PaperStyles.Shell(root, 12, 10);
      Native.EnableResize(Settings, 10, null);
      Settings.PreviewKeyDown += delegate(object sender, KeyEventArgs e) {
        if (e.Key != Key.Escape) return;
        if (LanguageBox != null && LanguageBox.IsPopupOpen) { LanguageBox.ClosePopup(); LanguageBox.Focus(); }
        else Settings.Close();
        e.Handled = true;
      };
      Settings.Show(); Send("settings-get");
    }

    static StackPanel Page(string title) {
      var page = new StackPanel { Margin = new Thickness(28, 22, 24, 24) };
      var heading = PaperStyles.Text(title, T.PageTitle, T.Ink); heading.Margin = new Thickness(0, 0, 0, 6); page.Children.Add(heading);
      return page;
    }
    static TabItem Tab(string title, StackPanel page) {
      var scroll = new ScrollViewer { Content = page, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, CanContentScroll = false, Focusable = false };
      scroll.SetValue(AutomationProperties.NameProperty, title + "设置内容");
      var tab = new TabItem { Header = title, Content = scroll }; tab.SetValue(AutomationProperties.NameProperty, title); return tab;
    }
    // One level of grouping: a single rounded container with hairline rows.
    static StackPanel Group(StackPanel page, string heading) {
      var label = PaperStyles.Text(heading, T.Meta, T.Muted); label.Margin = new Thickness(2, 18, 0, 8); page.Children.Add(label);
      var rows = new StackPanel();
      page.Children.Add(new Border { Background = T.Surface, BorderBrush = T.Line, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(10), Child = rows, SnapsToDevicePixels = true });
      return rows;
    }
    static FrameworkElement Fixed(FrameworkElement control, double width) { control.Width = width; return control; }
    static StackPanel RowText(string title, string description) {
      var text = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 16, 0) };
      text.Children.Add(PaperStyles.Text(title, T.Body, T.Ink));
      if (!string.IsNullOrEmpty(description)) { var help = PaperStyles.Text(description, T.Meta, T.Muted, true); help.Margin = new Thickness(0, 3, 0, 0); text.Children.Add(help); }
      return text;
    }
    static void Separate(StackPanel rows) { if (rows.Children.Count > 0) rows.Children.Add(PaperStyles.Hairline()); }
    static void Label(FrameworkElement control, string title, string description) {
      if (control is ComboBox) control.MinHeight = 32;
      if (string.IsNullOrEmpty(AutomationProperties.GetName(control))) control.SetValue(AutomationProperties.NameProperty, title);
      control.SetValue(AutomationProperties.HelpTextProperty, string.IsNullOrEmpty(description) ? title : description);
    }
    // Title + description left, control right.
    static void Row(StackPanel rows, string title, string description, FrameworkElement control) {
      Separate(rows);
      var grid = new Grid { MinHeight = 56, Margin = new Thickness(16, 10, 16, 10) };
      grid.ColumnDefinitions.Add(new ColumnDefinition()); grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
      grid.Children.Add(RowText(title, description));
      control.Margin = new Thickness(0); control.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(control, 1);
      Label(control, title, description); grid.Children.Add(control); rows.Children.Add(grid);
    }
    // Title + description above a full-width control.
    static void Stacked(StackPanel rows, string title, string description, FrameworkElement control) {
      Separate(rows);
      var panel = new StackPanel { Margin = new Thickness(16, 12, 16, 14) };
      var text = RowText(title, description); text.Margin = new Thickness(0, 0, 0, 10); panel.Children.Add(text);
      control.Margin = new Thickness(0); Label(control, title, description); panel.Children.Add(control); rows.Children.Add(panel);
    }
  }
}
