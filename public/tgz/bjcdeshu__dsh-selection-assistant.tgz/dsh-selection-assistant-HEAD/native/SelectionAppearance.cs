using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace DshSelectionAssistant {
  // Demo-only palette shared by the approved selection design and phase-two
  // quick/settings previews. Never replace the application's legacy brushes.
  internal static class SelectionAppearance {
    internal static readonly SolidColorBrush Ink = Theme.Brush("ClaudeInk", "#262626");
    internal static readonly SolidColorBrush Muted = Theme.Brush("ClaudeMuted", "#737373");
    internal static readonly SolidColorBrush Surface = Theme.Brush("ClaudeSurface", "#FFFFFF");
    internal static readonly SolidColorBrush Soft = Theme.Brush("ClaudeSoft", "#F4F2F3");
    internal static readonly SolidColorBrush Line = Theme.Brush("ClaudeLine", "#E9E9E9");
    internal static readonly SolidColorBrush Hover = Theme.Brush("ClaudeHover", "#F2F2F2");
    internal static readonly SolidColorBrush Accent = Theme.Brush("ClaudeAccent", "#D97757");
    internal static readonly SolidColorBrush Tint = Theme.Brush("ClaudeTint", "#FAEEE9");
    // Prevent beforefieldinit: the theme watcher may call ApplyTheme before a
    // preview window has read any brush field.
    static SelectionAppearance() { }

    internal static void ApplyTheme(bool dark) {
      Theme.Set("ClaudeInk", dark ? "#E3E3E3" : "#262626");
      Theme.Set("ClaudeMuted", dark ? "#A3A3A3" : "#737373");
      Theme.Set("ClaudeSurface", dark ? "#191919" : "#FFFFFF");
      Theme.Set("ClaudeSoft", dark ? "#282626" : "#F4F2F3");
      Theme.Set("ClaudeLine", dark ? "#333131" : "#E9E9E9");
      Theme.Set("ClaudeHover", dark ? "#323232" : "#F2F2F2");
      Theme.Set("ClaudeTint", dark ? "#3B2B25" : "#FAEEE9");
    }

    const string ScrollMarkup = @"
<ResourceDictionary xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>
  <Style TargetType='ScrollBar'>
    <Setter Property='Width' Value='8'/><Setter Property='MinWidth' Value='0'/><Setter Property='Background' Value='Transparent'/><Setter Property='Focusable' Value='False'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='ScrollBar'>
      <Grid Background='Transparent'>
        <Track Name='PART_Track' IsDirectionReversed='True' Orientation='{TemplateBinding Orientation}' Minimum='{TemplateBinding Minimum}' Maximum='{TemplateBinding Maximum}' ViewportSize='{TemplateBinding ViewportSize}' Value='{Binding Value, RelativeSource={RelativeSource TemplatedParent}, Mode=TwoWay}'>
          <Track.DecreaseRepeatButton><RepeatButton Name='decrease' Command='{x:Static ScrollBar.PageUpCommand}' Focusable='False'>
            <RepeatButton.Template><ControlTemplate TargetType='RepeatButton'><Border Background='Transparent'/></ControlTemplate></RepeatButton.Template>
          </RepeatButton></Track.DecreaseRepeatButton>
          <Track.Thumb><Thumb Name='thumb' MinHeight='18' Focusable='False'>
            <Thumb.Template><ControlTemplate TargetType='Thumb'>
              <Border Name='grip' Background='{DynamicResource Muted}' CornerRadius='3' Margin='1' Opacity='0.36'/>
              <ControlTemplate.Triggers><Trigger Property='IsMouseOver' Value='True'><Setter TargetName='grip' Property='Opacity' Value='0.65'/></Trigger><Trigger Property='IsDragging' Value='True'><Setter TargetName='grip' Property='Opacity' Value='0.8'/></Trigger></ControlTemplate.Triggers>
            </ControlTemplate></Thumb.Template>
          </Thumb></Track.Thumb>
          <Track.IncreaseRepeatButton><RepeatButton Name='increase' Command='{x:Static ScrollBar.PageDownCommand}' Focusable='False'>
            <RepeatButton.Template><ControlTemplate TargetType='RepeatButton'><Border Background='Transparent'/></ControlTemplate></RepeatButton.Template>
          </RepeatButton></Track.IncreaseRepeatButton>
        </Track>
      </Grid>
      <ControlTemplate.Triggers>
        <Trigger Property='Orientation' Value='Horizontal'>
          <Setter Property='Width' Value='Auto'/><Setter Property='Height' Value='8'/>
          <Setter TargetName='PART_Track' Property='IsDirectionReversed' Value='False'/>
          <Setter TargetName='thumb' Property='MinHeight' Value='0'/><Setter TargetName='thumb' Property='MinWidth' Value='18'/>
          <Setter TargetName='decrease' Property='Command' Value='{x:Static ScrollBar.PageLeftCommand}'/><Setter TargetName='increase' Property='Command' Value='{x:Static ScrollBar.PageRightCommand}'/>
        </Trigger>
        <Trigger Property='IsEnabled' Value='False'><Setter TargetName='thumb' Property='Opacity' Value='0'/></Trigger>
      </ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
</ResourceDictionary>";

    internal static ResourceDictionary Resources() {
      var resources = (ResourceDictionary)System.Windows.Markup.XamlReader.Parse(ScrollMarkup);
      resources["Ink"] = Ink; resources["Muted"] = Muted; resources["Surface"] = Surface;
      resources["Soft"] = Soft; resources["Line"] = Line; resources["Hover"] = Hover; resources["Accent"] = Accent; resources["Tint"] = Tint;
      resources[typeof(Button)] = Visuals.ButtonStyle(Ink, Hover, Accent, 8, false);
      var input = new Style(typeof(TextBox));
      input.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(9)));
      input.Setters.Add(new Setter(Control.BorderBrushProperty, Line));
      input.Setters.Add(new Setter(Control.ForegroundProperty, Ink));
      input.Setters.Add(new Setter(Control.BackgroundProperty, Surface));
      input.Setters.Add(new Setter(Control.FontSizeProperty, 13.0));
      input.Setters.Add(new Setter(TextBox.CaretBrushProperty, Ink));
      input.Setters.Add(new Setter(TextBox.SelectionBrushProperty, Tint));
      input.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(1)));
      input.Setters.Add(new Setter(Control.FocusVisualStyleProperty, null));
      var inputTemplate = new ControlTemplate(typeof(TextBox));
      var chrome = new FrameworkElementFactory(typeof(Border), "inputChrome");
      chrome.SetValue(Border.CornerRadiusProperty, new CornerRadius(8));
      foreach (var property in new DependencyProperty[] { Border.BackgroundProperty, Border.BorderBrushProperty, Border.BorderThicknessProperty, Border.PaddingProperty }) {
        chrome.SetBinding(property, new System.Windows.Data.Binding(property.Name) { RelativeSource = new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.TemplatedParent) });
      }
      var content = new FrameworkElementFactory(typeof(ScrollViewer), "PART_ContentHost"); chrome.AppendChild(content); inputTemplate.VisualTree = chrome;
      var focus = new Trigger { Property = UIElement.IsKeyboardFocusWithinProperty, Value = true };
      focus.Setters.Add(new Setter(Border.BorderBrushProperty, Accent, "inputChrome")); inputTemplate.Triggers.Add(focus);
      var disabled = new Trigger { Property = UIElement.IsEnabledProperty, Value = false };
      disabled.Setters.Add(new Setter(UIElement.OpacityProperty, 0.45)); inputTemplate.Triggers.Add(disabled);
      input.Setters.Add(new Setter(Control.TemplateProperty, inputTemplate));
      resources[typeof(TextBox)] = input;
      var tip = new Style(typeof(ToolTip));
      tip.Setters.Add(new Setter(Control.ForegroundProperty, Ink));
      tip.Setters.Add(new Setter(Control.BackgroundProperty, Surface));
      tip.Setters.Add(new Setter(Control.BorderBrushProperty, Line));
      resources[typeof(ToolTip)] = tip;
      return resources;
    }

    internal static Visuals.WindowShell Toolbar(Action<string> choose, Action settings, Action drag) {
      var row = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center };
      var grip = new Border { Width = 22, Height = 30, Child = Visuals.Icon("handle", 12, Muted), Cursor = Cursors.SizeAll, ToolTip = "拖动浮条" };
      grip.SetValue(System.Windows.Automation.AutomationProperties.NameProperty, "拖动浮条");
      grip.MouseLeftButtonDown += delegate { drag(); }; row.Children.Add(grip);
      foreach (string action in new string[] { "translate", "explain", "summarize" }) {
        string selected = action;
        var button = Visuals.IconButton(action, delegate { choose(selected); }, action == "translate" ? "翻译" : action == "explain" ? "解释" : "总结", 32);
        button.Content = Visuals.Icon(action, 15);
        if (action == "translate") { button.Foreground = Accent; button.Background = Tint; }
        row.Children.Add(button);
      }
      row.Children.Add(new Border { Width = 1, Height = 14, Background = Line, Margin = new Thickness(4, 0, 4, 0) });
      var preferences = Visuals.IconButton("settings", settings, "设置 / 暂停", 28); preferences.Content = Visuals.Icon("settings", 15); row.Children.Add(preferences);
      var shell = Visuals.Shell(row, 0, 12, 6, 8, Surface, Line);
      shell.Resources.MergedDictionaries.Add(Resources()); return shell;
    }
  }
}
