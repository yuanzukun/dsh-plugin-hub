using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using P = DshSelectionAssistant.Program;

namespace DshSelectionAssistant {
  internal sealed class OpacityControl {
    internal event Action<double> Changed;
    internal readonly Button Button;
    readonly Window Owner;
    readonly Popup Flyout;
    readonly Slider Slider;
    readonly TextBlock ValueLabel;
    internal double Percent { get { return Slider.Value; } }
    internal bool IsPopupOpen { get { return Flyout.IsOpen; } }

    internal OpacityControl(Window owner, ResourceDictionary resources = null, bool paper = false) {
      Owner = owner;
      Brush ink = resources == null ? P.Ink : (Brush)resources["Ink"], muted = resources == null ? P.Muted : (Brush)resources["Muted"], accent = resources == null ? P.Accent : (Brush)resources["Accent"];
      if (paper) {
        // Quiet Paper: compact horizontal popover. Same Slider, events and API.
        Button = PaperStyles.IconButton(Glyphs.Droplet(), Toggle, "透明度");
        var panel = new StackPanel { Width = 208 };
        if (resources != null) panel.Resources.MergedDictionaries.Add(resources);
        var head = new DockPanel { LastChildFill = true, Margin = new Thickness(2, 0, 2, 4) };
        ValueLabel = PaperStyles.Text("100%", PaperTheme.Body, PaperTheme.Ink); DockPanel.SetDock(ValueLabel, Dock.Right); head.Children.Add(ValueLabel);
        head.Children.Add(PaperStyles.Text("不透明度", PaperTheme.Meta, PaperTheme.Muted)); panel.Children.Add(head);
        Slider = new Slider { Minimum = 20, Maximum = 100, Value = 100, Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 6),
          SmallChange = 1, LargeChange = 10, IsSnapToTickEnabled = false, IsMoveToPointEnabled = true };
        Slider.SetValue(System.Windows.Automation.AutomationProperties.NameProperty, "窗口不透明度");
        Slider.ValueChanged += delegate { OnSlider(); };
        panel.Children.Add(Slider);
        var reset = PaperStyles.Plain("恢复 100%", delegate { Slider.Value = 100; }, "恢复完全不透明");
        reset.HorizontalAlignment = HorizontalAlignment.Right; reset.Margin = new Thickness(0, 0, -6, -2); panel.Children.Add(reset);
        Flyout = new Popup { PlacementTarget = Button, Placement = PlacementMode.Bottom, HorizontalOffset = -186, VerticalOffset = 2, AllowsTransparency = true,
          StaysOpen = false, PopupAnimation = SystemParameters.ClientAreaAnimation ? PopupAnimation.Fade : PopupAnimation.None };
        var face = new Border { Padding = new Thickness(14, 10, 14, 10), Child = panel };
        var shell = PaperStyles.Shell(face, 10, 10, true);
        shell.Face.Background = PaperTheme.Overlay;
        Flyout.Child = shell;
        Wire(owner, panel); return;
      }
      Button = Visuals.IconButton("opacity", Toggle, "透明度", 26);
      var body = new StackPanel { Width = 96 };
      if (resources != null) body.Resources.MergedDictionaries.Add(resources);
      var label = P.Text("不透明度", 11, muted); label.HorizontalAlignment = HorizontalAlignment.Center; body.Children.Add(label);
      ValueLabel = P.Text("100%", 13, ink); ValueLabel.HorizontalAlignment = HorizontalAlignment.Center; body.Children.Add(ValueLabel);
      Slider = new Slider { Minimum = 20, Maximum = 100, Value = 100, Orientation = Orientation.Vertical,
        Width = 28, Height = 120, Margin = new Thickness(0, 6, 0, 10), SmallChange = 1, LargeChange = 10,
        IsSnapToTickEnabled = false, IsMoveToPointEnabled = true, Foreground = accent };
      Slider.SetValue(System.Windows.Automation.AutomationProperties.NameProperty, "窗口不透明度");
      Slider.ValueChanged += delegate {
        var shell = Owner.Content as Visuals.WindowShell;
        if (shell != null) shell.SetContentOpacity(Slider.Value / 100.0);
        ValueLabel.Text = Math.Round(Slider.Value) + "%";
        Button.ToolTip = "透明度 · " + Math.Round(Slider.Value) + "% 不透明";
        if (Changed != null) Changed(Slider.Value);
      };
      body.Children.Add(Slider);
      var restore = P.Button("恢复 100%", delegate { Slider.Value = 100; }, "恢复完全不透明");
      restore.FontSize = 11; restore.Padding = new Thickness(4, 5, 4, 5); body.Children.Add(restore);
      Flyout = new Popup { PlacementTarget = Button, Placement = PlacementMode.Bottom, AllowsTransparency = true,
        StaysOpen = false, PopupAnimation = SystemParameters.ClientAreaAnimation ? PopupAnimation.Fade : PopupAnimation.None,
        Child = Visuals.Shell(body, 8, 8, 8, 10, resources == null ? null : (Brush)resources["Surface"], resources == null ? null : (Brush)resources["Line"]) };
      Flyout.Opened += delegate { Slider.Focus(); };
      owner.IsVisibleChanged += delegate { if (!owner.IsVisible) Close(); };
      owner.LocationChanged += delegate { Close(); };
      owner.SizeChanged += delegate { Close(); };
      owner.Closed += delegate { Close(); };
      body.PreviewKeyDown += delegate(object sender, KeyEventArgs e) {
        if (e.Key == Key.Escape) { Close(); Button.Focus(); e.Handled = true; }
      };
    }
    void Toggle() { Flyout.IsOpen = !Flyout.IsOpen; }
    // Paper path: identical opacity/notification semantics to the original handler.
    void OnSlider() {
      var shell = Owner.Content as Visuals.WindowShell;
      if (shell != null) shell.SetContentOpacity(Slider.Value / 100.0);
      ValueLabel.Text = Math.Round(Slider.Value) + "%";
      Button.ToolTip = "透明度 · " + Math.Round(Slider.Value) + "% 不透明";
      if (Changed != null) Changed(Slider.Value);
    }
    void Wire(Window owner, FrameworkElement body) {
      Flyout.Opened += delegate { Slider.Focus(); };
      owner.IsVisibleChanged += delegate { if (!owner.IsVisible) Close(); };
      owner.LocationChanged += delegate { Close(); };
      owner.SizeChanged += delegate { Close(); };
      owner.Closed += delegate { Close(); };
      body.PreviewKeyDown += delegate(object sender, KeyEventArgs e) {
        if (e.Key == Key.Escape) { Close(); Button.Focus(); e.Handled = true; }
      };
    }
    internal void Close() { Flyout.IsOpen = false; }
    internal void SetPercent(double value) { Slider.Value = Math.Max(20, Math.Min(100, value)); }
  }
}
