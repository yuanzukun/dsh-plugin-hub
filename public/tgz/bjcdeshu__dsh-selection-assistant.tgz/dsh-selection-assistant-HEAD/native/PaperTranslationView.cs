using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using T = DshSelectionAssistant.PaperTheme;

namespace DshSelectionAssistant {
  internal enum PaperRunState { Idle, Submitting, Waiting, Streaming, Done, Stopped, Failed, Truncated }

  // Controls are created and wired by TranslationWindow (business events stay
  // there). The view only arranges them and renders state; it never sends.
  internal sealed class PaperParts {
    internal Window Window; internal bool Quick;
    internal TextBox Input; internal RichTextBox Result;
    internal TextBlock Status, Title, Count, Route;
    internal LanguagePicker Language;
    internal Button Stop, Translate, Retry, Copy, Pin, Opacity, Minimize, Close, RouteButton, Paste, Clear, SourceToggle;
    internal ContentControl ActionIcon;
    // Produced by the view.
    internal Border SourceBox; internal FrameworkElement EmptyResult, Placeholder, Header; internal TextBlock EmptyText;
    internal UIElement Root;
  }

  internal sealed class PaperTranslationView {
    readonly PaperParts P;
    internal ScrollViewer Scroller; // selection only: one reading scroller for source + result
    TextBlock SourceLabel, SourceSummary; ContentControl SourceChevron;
    Ellipse Dot; FrameworkElement Skeleton; Border ErrorBlock, Alert; TextBlock ErrorText, AlertText;
    Grid Panes; Border SourcePane, ResultPane, Divider; int Layout = -1;
    bool SkeletonRunning, DotRunning; string RetryKey, CopyKey;

    internal PaperTranslationView(PaperParts parts) {
      P = parts;
      if (P.Quick) BuildQuick(); else BuildSelection();
    }

    FrameworkElement Header(UIElement caption) {
      var header = new DockPanel { Height = 44, Margin = new Thickness(16, 0, 8, 0), LastChildFill = true, Background = Brushes.Transparent };
      var controls = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
      controls.Children.Add(P.Pin); controls.Children.Add(P.Opacity);
      controls.Children.Add(new Border { Width = 8 });
      controls.Children.Add(P.Minimize); controls.Children.Add(P.Close);
      DockPanel.SetDock(controls, Dock.Right); header.Children.Add(controls);
      header.Children.Add(caption);
      P.Header = header; return header;
    }

    // Status line: [dot] text. The text itself is the shared Status block.
    FrameworkElement StatusLine() {
      Dot = new Ellipse { Width = 6, Height = 6, Fill = T.Accent, Margin = new Thickness(2, 1, 7, 0), VerticalAlignment = VerticalAlignment.Center, Visibility = Visibility.Collapsed };
      var line = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 6, 0) };
      line.Children.Add(Dot); line.Children.Add(P.Status); return line;
    }

    FrameworkElement EmptyState(bool quick) {
      var host = new Grid { VerticalAlignment = VerticalAlignment.Top, IsHitTestVisible = false };
      var bars = new StackPanel { Margin = new Thickness(0, 6, 0, 0) };
      foreach (double width in new[] { 1.0, 0.92, 0.58 }) {
        var bar = new Border { Height = 10, CornerRadius = new CornerRadius(5), Background = T.Skeleton, Margin = new Thickness(0, 0, 0, 12), HorizontalAlignment = HorizontalAlignment.Left };
        double share = width;
        host.SizeChanged += delegate { bar.Width = Math.Max(40, host.ActualWidth * share); };
        bars.Children.Add(bar);
      }
      Skeleton = bars; host.Children.Add(bars);
      ErrorBlock = MakeAlert(out ErrorText); ErrorBlock.Margin = new Thickness(0, 2, 0, 0);
      host.Children.Add(ErrorBlock);
      P.EmptyText = new TextBlock { FontSize = T.Body, Foreground = T.Muted, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0) };
      host.Children.Add(P.EmptyText);
      P.EmptyResult = host; return host;
    }
    // Error note: tinted block with icon; never only a grey footer line.
    static Border MakeAlert(out TextBlock text) {
      text = new TextBlock { FontSize = T.Body, Foreground = T.Ink, TextWrapping = TextWrapping.Wrap, LineHeight = 20, LineStackingStrategy = LineStackingStrategy.BlockLineHeight, VerticalAlignment = VerticalAlignment.Center };
      var row = new DockPanel { LastChildFill = true };
      var icon = Glyphs.Icon(Glyphs.Warning, 16, T.Danger); icon.Margin = new Thickness(0, 2, 10, 0); icon.VerticalAlignment = VerticalAlignment.Top;
      DockPanel.SetDock(icon, Dock.Left); row.Children.Add(icon); row.Children.Add(text);
      return new Border { Background = T.DangerTint, CornerRadius = new CornerRadius(8), Padding = new Thickness(12, 10, 14, 10), Child = row, Visibility = Visibility.Collapsed };
    }

    // ---- Selection result ------------------------------------------------
    void BuildSelection() {
      var caption = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
      caption.Children.Add(P.ActionIcon); caption.Children.Add(P.Title);
      P.Language.Margin = new Thickness(10, 0, 0, 0); caption.Children.Add(P.Language);

      var root = new DockPanel { LastChildFill = true };
      var header = Header(caption); DockPanel.SetDock(header, Dock.Top); root.Children.Add(header);

      // One-line source summary; the whole row toggles the full source.
      var summary = new Grid();
      summary.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
      summary.ColumnDefinitions.Add(new ColumnDefinition());
      summary.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
      SourceLabel = PaperStyles.Text("原文", T.Meta, T.Muted); SourceLabel.Margin = new Thickness(0, 0, 10, 0); summary.Children.Add(SourceLabel);
      SourceSummary = PaperStyles.Text("", T.Meta, T.Muted); Grid.SetColumn(SourceSummary, 1); summary.Children.Add(SourceSummary);
      SourceChevron = new ContentControl { Content = Glyphs.Icon(Glyphs.Down, 10, T.Muted), Margin = new Thickness(10, 1, 0, 0), Focusable = false, IsHitTestVisible = false };
      Grid.SetColumn(SourceChevron, 2); summary.Children.Add(SourceChevron);
      P.SourceToggle.Content = summary; P.SourceToggle.HorizontalContentAlignment = HorizontalAlignment.Stretch;
      P.SourceToggle.Padding = new Thickness(8, 0, 10, 0); P.SourceToggle.Height = 30; P.SourceToggle.Margin = new Thickness(12, 0, 12, 0);
      DockPanel.SetDock(P.SourceToggle, Dock.Top); root.Children.Add(P.SourceToggle);
      P.Input.TextChanged += delegate { SourceSummary.Text = Regex.Replace(P.Input.Text.Length > 400 ? P.Input.Text.Substring(0, 400) : P.Input.Text, @"\s+", " ").Trim(); };

      var footer = new DockPanel { Height = 44, Margin = new Thickness(12, 0, 10, 4), LastChildFill = true };
      var actions = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
      actions.Children.Add(P.Stop); actions.Children.Add(P.Retry); actions.Children.Add(P.Copy);
      DockPanel.SetDock(actions, Dock.Right); footer.Children.Add(actions);
      DockPanel.SetDock(P.RouteButton, Dock.Left); footer.Children.Add(P.RouteButton);
      footer.Children.Add(StatusLine());
      DockPanel.SetDock(footer, Dock.Bottom); root.Children.Add(footer);

      var flow = new StackPanel { Margin = new Thickness(20, 8, 20, 12) };
      P.Input.Foreground = T.InkSecondary; P.Input.FontSize = T.Body;
      TextBlock.SetLineHeight(P.Input, 20); TextBlock.SetLineStackingStrategy(P.Input, LineStackingStrategy.BlockLineHeight);
      P.SourceBox = new Border { Background = T.Sunken, CornerRadius = new CornerRadius(8), Padding = new Thickness(12, 10, 12, 10), Margin = new Thickness(0, 0, 0, 16), Child = P.Input, Visibility = Visibility.Collapsed };
      flow.Children.Add(P.SourceBox);
      var resultHost = new Grid { MinHeight = 28 };
      P.Result.Margin = new Thickness(-4, 0, -4, 0);
      resultHost.Children.Add(P.Result); resultHost.Children.Add(EmptyState(false));
      flow.Children.Add(resultHost);
      Alert = MakeAlert(out AlertText); Alert.Margin = new Thickness(0, 14, 0, 0); flow.Children.Add(Alert);
      Scroller = new ScrollViewer { Content = flow, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Focusable = false, CanContentScroll = false };
      Scroller.SetValue(AutomationProperties.NameProperty, "结果内容");
      root.Children.Add(Scroller);
      PaperStyles.ForwardWheel(P.Result, Scroller); PaperStyles.ForwardWheel(P.Input, Scroller);
      // One reading surface must not hide a long source inside a second clipped
      // editor. The fixed disclosure row remains available to collapse it.
      P.Input.VerticalScrollBarVisibility = ScrollBarVisibility.Disabled;
      P.Input.MaxHeight = double.PositiveInfinity;
      P.Placeholder = new Border();
      P.Root = root;
    }

    // ---- Quick translate -------------------------------------------------
    void BuildQuick() {
      var caption = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
      caption.Children.Add(P.ActionIcon); caption.Children.Add(P.Title);
      var root = new DockPanel { LastChildFill = true };
      var header = Header(caption); DockPanel.SetDock(header, Dock.Top); root.Children.Add(header);
      var rule = PaperStyles.Hairline(); DockPanel.SetDock(rule, Dock.Top); root.Children.Add(rule);

      // Source pane: input and its primary action belong together.
      var source = new DockPanel { LastChildFill = true };
      var sourceHead = new DockPanel { Height = 40, Margin = new Thickness(16, 0, 8, 0), LastChildFill = true };
      var tools = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
      tools.Children.Add(P.Paste); tools.Children.Add(P.Clear);
      DockPanel.SetDock(tools, Dock.Right); sourceHead.Children.Add(tools);
      sourceHead.Children.Add(PaperStyles.Text("原文", T.Meta, T.Muted));
      DockPanel.SetDock(sourceHead, Dock.Top); source.Children.Add(sourceHead);
      var sourceFoot = new DockPanel { Height = 52, Margin = new Thickness(16, 0, 12, 0), LastChildFill = true };
      var submit = new Grid { VerticalAlignment = VerticalAlignment.Center };
      submit.Children.Add(P.Translate); submit.Children.Add(P.Stop);
      DockPanel.SetDock(submit, Dock.Right); sourceFoot.Children.Add(submit);
      sourceFoot.Children.Add(P.Count);
      DockPanel.SetDock(sourceFoot, Dock.Bottom); source.Children.Add(sourceFoot);
      var placeholder = new StackPanel { IsHitTestVisible = false };
      var hint = new TextBlock { Text = "输入或粘贴要翻译的文字", Foreground = T.Muted, TextWrapping = TextWrapping.Wrap };
      hint.SetBinding(TextBlock.FontSizeProperty, new System.Windows.Data.Binding("FontSize") { Source = P.Input });
      placeholder.Children.Add(hint);
      placeholder.Children.Add(new TextBlock { Text = "Ctrl+V 粘贴 · Ctrl+Enter 翻译", FontSize = T.Meta, Foreground = T.Muted, Margin = new Thickness(0, 6, 0, 0) });
      P.Placeholder = placeholder;
      var inputHost = new Grid { Margin = new Thickness(16, 2, 10, 0) };
      inputHost.Children.Add(P.Input); inputHost.Children.Add(placeholder);
      source.Children.Add(inputHost);
      SourcePane = new Border { Background = T.Sunken, Child = source };

      // Result pane: language, result, and what to do with it.
      var result = new DockPanel { LastChildFill = true };
      var resultHead = new DockPanel { Height = 40, Margin = new Thickness(8, 0, 8, 0), LastChildFill = false };
      P.Language.VerticalAlignment = VerticalAlignment.Center; resultHead.Children.Add(P.Language);
      DockPanel.SetDock(resultHead, Dock.Top); result.Children.Add(resultHead);
      var resultFoot = new DockPanel { Height = 52, Margin = new Thickness(10, 0, 10, 0), LastChildFill = true };
      var actions = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
      actions.Children.Add(P.Retry); actions.Children.Add(P.Copy);
      DockPanel.SetDock(actions, Dock.Right); resultFoot.Children.Add(actions);
      DockPanel.SetDock(P.RouteButton, Dock.Left); resultFoot.Children.Add(P.RouteButton);
      resultFoot.Children.Add(StatusLine());
      DockPanel.SetDock(resultFoot, Dock.Bottom); result.Children.Add(resultFoot);
      Alert = MakeAlert(out AlertText); Alert.Margin = new Thickness(16, 6, 12, 0);
      DockPanel.SetDock(Alert, Dock.Bottom); result.Children.Add(Alert);
      var resultHost = new Grid { Margin = new Thickness(16, 2, 10, 0) };
      P.Result.Margin = new Thickness(-4, 0, 0, 0);
      resultHost.Children.Add(P.Result); resultHost.Children.Add(EmptyState(true));
      result.Children.Add(resultHost);
      ResultPane = new Border { Background = T.Surface, Child = result };

      Divider = PaperStyles.Hairline(true);
      Panes = new Grid();
      Panes.Children.Add(SourcePane); Panes.Children.Add(Divider); Panes.Children.Add(ResultPane);
      root.Children.Add(Panes);
      P.Window.SizeChanged += delegate { ArrangePanes(); };
      ArrangePanes();
      P.Root = root;
    }

    // Side by side when wide, stacked when narrow. Same control instances,
    // so the caret, selection and undo history of the input are preserved.
    void ArrangePanes() {
      double width = P.Window.ActualWidth > 0 ? P.Window.ActualWidth : P.Window.Width;
      int layout = width < 700 ? 1 : 0;
      if (layout == Layout) return; Layout = layout;
      Panes.RowDefinitions.Clear(); Panes.ColumnDefinitions.Clear();
      if (layout == 0) {
        Panes.ColumnDefinitions.Add(new ColumnDefinition());
        Panes.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        Panes.ColumnDefinitions.Add(new ColumnDefinition());
        Place(SourcePane, 0, 0); Place(Divider, 0, 1); Place(ResultPane, 0, 2);
        Divider.Width = 1; Divider.Height = double.NaN;
        SourcePane.CornerRadius = new CornerRadius(0, 0, 0, 11); ResultPane.CornerRadius = new CornerRadius(0, 0, 11, 0);
      } else {
        Panes.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        Panes.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        Panes.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        Place(SourcePane, 0, 0); Place(Divider, 1, 0); Place(ResultPane, 2, 0);
        Divider.Height = 1; Divider.Width = double.NaN;
        SourcePane.CornerRadius = new CornerRadius(0); ResultPane.CornerRadius = new CornerRadius(0, 0, 11, 11);
      }
    }
    static void Place(UIElement element, int row, int column) { Grid.SetRow(element, row); Grid.SetColumn(element, column); }

    // ---- State presentation ----------------------------------------------
    internal void SetAction(string action) {
      P.ActionIcon.Content = Glyphs.Icon(Glyphs.ActionGlyph(action), 15, T.InkSecondary);
      P.Language.Prefix = action == "translate" ? "译为" : "输出";
    }
    internal void SetSourceExpanded(bool expanded) {
      SourceSummary.Visibility = expanded ? Visibility.Hidden : Visibility.Visible;
      SourceLabel.Text = expanded ? "收起原文" : "原文";
      SourceChevron.Content = Glyphs.Icon(expanded ? Glyphs.Up : Glyphs.Down, 10, T.Muted);
    }
    internal void SetPinned(bool pinned) {
      P.Pin.Content = Glyphs.Icon(pinned ? Glyphs.Pinned : Glyphs.Pin, 15);
    }
    internal void SetCopied(bool copied) {
      string key = copied ? "copied" : "copy"; if (key == CopyKey) return; CopyKey = key;
      P.Copy.Content = PaperStyles.Label(copied ? Glyphs.Check : Glyphs.Copy, copied ? "已复制" : "复制", 13);
      if (copied) P.Copy.Foreground = T.Success; else P.Copy.ClearValue(Control.ForegroundProperty);
    }

    internal void Apply(PaperRunState state, string status, bool hasAnswer, bool hasInput, string pendingLanguage) {
      bool busy = state == PaperRunState.Submitting || state == PaperRunState.Waiting || state == PaperRunState.Streaming;
      bool failed = state == PaperRunState.Failed;
      if (P.Quick) P.Translate.Visibility = busy ? Visibility.Collapsed : Visibility.Visible;
      P.Copy.Visibility = hasAnswer && !busy ? Visibility.Visible : Visibility.Collapsed;
      if (failed && hasInput) P.Retry.Visibility = Visibility.Visible;

      string retryKey = pendingLanguage == null ? "" : pendingLanguage;
      if (retryKey != RetryKey) {
        RetryKey = retryKey;
        P.Retry.Content = PaperStyles.Label(Glyphs.Retry, pendingLanguage == null ? "重试" : "以 " + pendingLanguage + " 重新生成", 13);
        if (pendingLanguage == null) P.Retry.ClearValue(Control.ForegroundProperty); else P.Retry.Foreground = T.AccentText;
      }

      bool showError = failed && !hasAnswer;
      Dot.Visibility = busy ? Visibility.Visible : Visibility.Collapsed;
      Dot.Fill = T.Accent;
      SetPulse(Dot, busy, ref DotRunning, 0.35);
      P.Status.Foreground = failed ? T.Danger : T.Muted;
      bool quiet = (state == PaperRunState.Done && status == "已完成") || failed ||
        (state == PaperRunState.Idle && (string.IsNullOrEmpty(status) || status == "等待输入" || status == "输入或粘贴文字"));
      P.Status.Visibility = quiet ? Visibility.Collapsed : Visibility.Visible;
      Alert.Visibility = failed && hasAnswer ? Visibility.Visible : Visibility.Collapsed;
      AlertText.Text = status;

      Skeleton.Visibility = !hasAnswer && busy ? Visibility.Visible : Visibility.Collapsed;
      SetPulse(Skeleton, !hasAnswer && busy, ref SkeletonRunning, 0.45);
      ErrorBlock.Visibility = showError ? Visibility.Visible : Visibility.Collapsed;
      ErrorText.Text = status;
      bool idleText = !hasAnswer && !busy && !showError;
      P.EmptyText.Visibility = idleText ? Visibility.Visible : Visibility.Collapsed;
      if (idleText) P.EmptyText.Text = P.Quick ? "译文会显示在这里" : state == PaperRunState.Stopped ? "已停止，没有生成内容。" : status;
    }

    // Opacity pulse only while visible and only if the system allows animation.
    static void SetPulse(UIElement element, bool on, ref bool running, double low) {
      bool animate = on && Visuals.AnimationsEnabled && SystemParameters.ClientAreaAnimation;
      if (animate == running) return; running = animate;
      if (!animate) { element.BeginAnimation(UIElement.OpacityProperty, null); element.Opacity = 1; return; }
      element.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(1, low, new Duration(TimeSpan.FromMilliseconds(700))) {
        AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut }
      });
    }
  }
}
