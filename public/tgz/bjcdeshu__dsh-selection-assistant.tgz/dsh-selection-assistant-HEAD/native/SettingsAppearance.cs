using System;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using A = DshSelectionAssistant.SelectionAppearance;

namespace DshSelectionAssistant {
  // Only ShowSettingsPreview consumes these helpers. The application dictionary
  // and the installed settings window keep their original styles and brushes.
  internal static class SettingsAppearance {
    internal static ResourceDictionary Resources() {
      var resources = A.Resources();
      resources.MergedDictionaries.Add((ResourceDictionary)System.Windows.Markup.XamlReader.Parse(@"
<ResourceDictionary xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>
  <Style TargetType='CheckBox'>
    <Setter Property='Foreground' Value='{DynamicResource Ink}'/><Setter Property='FontSize' Value='13'/>
    <Setter Property='MinHeight' Value='26'/><Setter Property='VerticalContentAlignment' Value='Center'/>
    <Setter Property='FocusVisualStyle' Value='{x:Null}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='CheckBox'>
      <Grid Background='Transparent'>
        <Grid.ColumnDefinitions><ColumnDefinition Width='26'/><ColumnDefinition Width='*'/></Grid.ColumnDefinitions>
        <Border Name='box' Width='17' Height='17' VerticalAlignment='Center' HorizontalAlignment='Left' CornerRadius='4' BorderThickness='1' BorderBrush='{DynamicResource Line}' Background='{DynamicResource Surface}'>
          <Path Name='check' Data='M3,7 L6,10 L12,4' Stroke='White' StrokeThickness='1.8' StrokeStartLineCap='Round' StrokeEndLineCap='Round' Visibility='Collapsed'/>
        </Border>
        <ContentPresenter Grid.Column='1' VerticalAlignment='{TemplateBinding VerticalContentAlignment}' RecognizesAccessKey='True'/>
      </Grid>
      <ControlTemplate.Triggers>
        <Trigger Property='IsChecked' Value='True'><Setter TargetName='box' Property='Background' Value='{DynamicResource Accent}'/><Setter TargetName='box' Property='BorderBrush' Value='{DynamicResource Accent}'/><Setter TargetName='check' Property='Visibility' Value='Visible'/></Trigger>
        <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='box' Property='BorderBrush' Value='{DynamicResource Accent}'/></Trigger>
        <Trigger Property='IsKeyboardFocused' Value='True'><Setter TargetName='box' Property='BorderBrush' Value='{DynamicResource Accent}'/><Setter TargetName='box' Property='BorderThickness' Value='2'/></Trigger>
        <Trigger Property='IsEnabled' Value='False'><Setter Property='Opacity' Value='0.45'/></Trigger>
      </ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style TargetType='TabControl'>
    <Setter Property='Background' Value='{DynamicResource Surface}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='TabControl'>
      <DockPanel KeyboardNavigation.TabNavigation='Local'>
        <TabPanel IsItemsHost='True' DockPanel.Dock='Top' Margin='0,0,0,16' KeyboardNavigation.TabIndex='0'/>
        <ContentPresenter Name='PART_SelectedContentHost' ContentSource='SelectedContent' KeyboardNavigation.TabIndex='1'/>
      </DockPanel>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style TargetType='TabItem'>
    <Setter Property='Foreground' Value='{DynamicResource Muted}'/><Setter Property='FontSize' Value='13'/>
    <Setter Property='FocusVisualStyle' Value='{x:Null}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='TabItem'>
      <Border Name='tab' Background='Transparent' BorderBrush='Transparent' BorderThickness='1' CornerRadius='8' Padding='15,9' Margin='0,0,6,0'>
        <ContentPresenter ContentSource='Header' RecognizesAccessKey='True'/>
      </Border>
      <ControlTemplate.Triggers>
        <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='tab' Property='Background' Value='{DynamicResource Hover}'/></Trigger>
        <Trigger Property='IsSelected' Value='True'><Setter TargetName='tab' Property='Background' Value='{DynamicResource Tint}'/><Setter Property='Foreground' Value='{DynamicResource Accent}'/></Trigger>
        <Trigger Property='IsKeyboardFocused' Value='True'><Setter TargetName='tab' Property='BorderBrush' Value='{DynamicResource Accent}'/></Trigger>
      </ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
</ResourceDictionary>"));
      return resources;
    }

    internal static TextBlock Text(string text, double size = 13, Brush color = null) {
      return new TextBlock { Text = text, FontSize = size, Foreground = color ?? A.Ink, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 7) };
    }
    internal static UIElement Titlebar(Window window) {
      var header = new DockPanel { LastChildFill = true, Margin = new Thickness(22, 18, 14, 0) };
      var close = Visuals.IconButton("close", delegate { window.Close(); }, "关闭设置", 30);
      close.Foreground = A.Muted; close.VerticalAlignment = VerticalAlignment.Top;
      DockPanel.SetDock(close, Dock.Right); header.Children.Add(close);
      var caption = new StackPanel { Background = Brushes.Transparent, Margin = new Thickness(0, 0, 12, 0) };
      caption.SetValue(AutomationProperties.NameProperty, "拖动设置窗口");
      var title = Text("划词与翻译", 22); title.FontWeight = FontWeights.SemiBold; caption.Children.Add(title);
      caption.Children.Add(Text("翻译、解释与总结，使用你现有的 DSH 模型", 12, A.Muted));
      caption.MouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs e) { if (e.ChangedButton == MouseButton.Left) window.DragMove(); };
      header.Children.Add(caption); return header;
    }
    internal static StackPanel Section(StackPanel page, string title) {
      var body = new StackPanel();
      if (!string.IsNullOrEmpty(title)) { var heading = Text(title, 13); heading.FontWeight = FontWeights.SemiBold; heading.Margin = new Thickness(0, 0, 0, 12); body.Children.Add(heading); }
      page.Children.Add(new Border { Background = A.Surface, BorderBrush = A.Line, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(10), Padding = new Thickness(16), Margin = new Thickness(0, 0, 0, 12), Child = body });
      return body;
    }
    internal static void Field(StackPanel body, string label, FrameworkElement control) {
      var caption = Text(label, 12, A.Muted); caption.Margin = new Thickness(0, 2, 0, 6); body.Children.Add(caption);
      if (string.IsNullOrEmpty(AutomationProperties.GetName(control))) control.SetValue(AutomationProperties.NameProperty, label);
      control.SetValue(AutomationProperties.HelpTextProperty, label);
      control.Margin = new Thickness(0, 0, 0, 12); body.Children.Add(control);
    }
    internal static CheckBox Check(string label, bool value) {
      var box = new CheckBox { Content = new TextBlock { Text = label, TextWrapping = TextWrapping.Wrap }, IsChecked = value, Margin = new Thickness(0, 0, 0, 8) };
      box.SetValue(AutomationProperties.NameProperty, label); return box;
    }
    internal static TabItem Tab(string title, StackPanel page) {
      var scroll = new ScrollViewer { Content = page, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Padding = new Thickness(0, 0, 6, 0), CanContentScroll = false };
      scroll.SetValue(AutomationProperties.NameProperty, title + "设置内容");
      var tab = new TabItem { Header = title, Content = scroll }; tab.SetValue(AutomationProperties.NameProperty, title); return tab;
    }
  }
}
