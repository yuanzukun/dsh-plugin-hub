using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using T = DshSelectionAssistant.PaperTheme;

namespace DshSelectionAssistant {
  // Safe light-weight Markdown for the Paper reading surface: headings, lists
  // (hanging indent), quotes, bold, inline code, fenced code. No HTML, no links,
  // nothing is executed or opened. Raw text stays the copy source.
  internal static class MarkdownView {
    internal static FlowDocument NewDocument(double fontSize) {
      var doc = new FlowDocument {
        FontFamily = T.UiFont, FontSize = fontSize, Foreground = T.Ink, PagePadding = new Thickness(0),
        LineHeight = Math.Round(fontSize * T.ReadingLineHeight), LineStackingStrategy = LineStackingStrategy.MaxHeight,
        TextAlignment = TextAlignment.Left
      };
      TextOptionsFor(doc); return doc;
    }
    static void TextOptionsFor(FlowDocument doc) { TextOptions.SetTextFormattingMode(doc, T.ReadingFormatting); }

    internal static FlowDocument Render(string answer, double fontSize) {
      var doc = NewDocument(fontSize);
      double gap = Math.Round(fontSize * 0.6);
      List list = null; Paragraph code = null; bool fenced = false;
      foreach (string raw in (answer ?? "").Replace("\r", "").Split('\n')) {
        if (raw.TrimStart().StartsWith("```")) {
          if (!fenced) { code = CodeBlock(fontSize, gap); doc.Blocks.Add(code); list = null; fenced = true; }
          else { fenced = false; code = null; }
          continue;
        }
        if (fenced) {
          if (code.Inlines.Count > 0) code.Inlines.Add(new LineBreak());
          code.Inlines.Add(new Run(raw)); continue;
        }
        if (string.IsNullOrWhiteSpace(raw)) { list = null; continue; }

        var heading = Regex.Match(raw, @"^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$");
        if (heading.Success) {
          list = null; int level = heading.Groups[1].Value.Length;
          double size = level == 1 ? fontSize + 3 : level == 2 ? fontSize + 1.5 : fontSize;
          var p = new Paragraph { FontSize = size, FontWeight = FontWeights.SemiBold, FontFamily = T.StrongFont,
            LineHeight = Math.Round(size * 1.4), Margin = new Thickness(0, doc.Blocks.Count == 0 ? 0 : gap + 4, 0, Math.Round(gap * 0.6)) };
          Inline(p, heading.Groups[2].Value); doc.Blocks.Add(p); continue;
        }
        if (Regex.IsMatch(raw, @"^\s*([-*_])(\s*\1){2,}\s*$")) {
          list = null; doc.Blocks.Add(new Paragraph { Margin = new Thickness(0, gap, 0, gap), BorderBrush = T.Line, BorderThickness = new Thickness(0, 0, 0, 1), FontSize = 2, LineHeight = 2 });
          continue;
        }
        var bullet = Regex.Match(raw, @"^(\s*)([-*+]|[1-9][0-9]{0,2}[.)])\s+(.*)$");
        if (bullet.Success) {
          bool ordered = char.IsDigit(bullet.Groups[2].Value[0]);
          if (list == null || (list.MarkerStyle == TextMarkerStyle.Decimal) != ordered) {
            list = new List { MarkerStyle = ordered ? TextMarkerStyle.Decimal : TextMarkerStyle.Disc, Margin = new Thickness(0, 0, 0, gap),
              Padding = new Thickness(Math.Round(fontSize * 1.4), 0, 0, 0), MarkerOffset = Math.Round(fontSize * 0.5) };
            if (ordered) list.StartIndex = int.Parse(bullet.Groups[2].Value.TrimEnd('.', ')'));
            doc.Blocks.Add(list);
          }
          var item = new Paragraph { Margin = new Thickness(0, 0, 0, Math.Round(gap * 0.4)) };
          if (bullet.Groups[1].Value.Length >= 2) item.Margin = new Thickness(Math.Round(fontSize * 1.2), 0, 0, Math.Round(gap * 0.4));
          Inline(item, bullet.Groups[3].Value); list.ListItems.Add(new ListItem(item));
          continue;
        }
        list = null;
        var paragraph = new Paragraph { Margin = new Thickness(0, 0, 0, gap) };
        string line = raw;
        if (line.TrimStart().StartsWith(">")) {
          line = Regex.Replace(line, @"^\s*>\s?", "");
          paragraph.BorderBrush = T.LineStrong; paragraph.BorderThickness = new Thickness(2, 0, 0, 0);
          paragraph.Padding = new Thickness(12, 0, 0, 0); paragraph.Foreground = T.InkSecondary;
        }
        Inline(paragraph, line); doc.Blocks.Add(paragraph);
      }
      // Trailing spacing must not create an empty reading row.
      var last = doc.Blocks.LastBlock;
      if (last != null) last.Margin = new Thickness(last.Margin.Left, last.Margin.Top, last.Margin.Right, 0);
      return doc;
    }

    static Paragraph CodeBlock(double fontSize, double gap) {
      return new Paragraph {
        FontFamily = T.MonoFont, FontSize = Math.Max(12, fontSize - 2), LineHeight = Math.Round(Math.Max(12, fontSize - 2) * 1.5),
        Background = T.Sunken, Padding = new Thickness(12, 8, 12, 8), Margin = new Thickness(0, 2, 0, gap), Foreground = T.Ink
      };
    }

    static void Inline(Paragraph p, string line) {
      foreach (string part in Regex.Split(line, @"(\*\*[^*]+\*\*|`[^`]+`)")) {
        if (part.Length == 0) continue;
        if (part.Length >= 4 && part.StartsWith("**") && part.EndsWith("**")) p.Inlines.Add(new Bold(new Run(part.Substring(2, part.Length - 4))) { FontFamily = T.StrongFont });
        else if (part.Length >= 2 && part.StartsWith("`") && part.EndsWith("`")) p.Inlines.Add(new Run(" " + part.Substring(1, part.Length - 2) + " ") { FontFamily = T.MonoFont, Background = T.Hover });
        else p.Inlines.Add(new Run(part));
      }
    }
  }
}
