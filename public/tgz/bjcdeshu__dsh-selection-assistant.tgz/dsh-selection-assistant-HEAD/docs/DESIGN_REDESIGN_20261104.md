# Quiet Paper · 设计与维护说明

2026-11-04，源码版本 **0.2.0**。Paper 已通过本轮实际使用确认并成为日常默认；Legacy 与先前 Claude 设计保留作合成回归比较。

设计与 UI 主实现：**Antigravity / Claude Opus 5.5**。逻辑 review、回归、集成与维护：**DeepSeek Harness**。这是现有 WPF 的原生改造，不是网页重建或仅换配色。

## 设计原则与结构

- 正文优先，减少装饰性的盒中盒、标题栏与页脚占位；操作靠近它作用的内容。
- 统一字体、字形、控件尺度、圆角与状态反馈。界面采用系统 Segoe UI Variable / Segoe UI，中文回退雅黑；图标优先 Fluent / MDL2，缺字回退原矢量路径。没有捆绑或下载字体。
- 独立 `Paper*` 主题键和窗口局部资源；密封样式及弹层也随主题更新。采用中性色和小面积陶土色强调；主按钮白字对比度达到 4.5:1。
- 阴影由空的兄弟轮廓承载，文字不放在 Effect 的祖先下；保留透明窗口、原生缩放命中和尺寸/透明度恢复。

| 界面 | 当前结构 |
|---|---|
| 浮条 | 图标＋短标签，三个动作等权；真正的拖动区域、设置入口、no-activate；阴影 gutter8，现有放置算法保持 |
| 结果窗 | 紧凑标题及语言 chip；固定原文摘要，可展开完整源文；原文和正文共用单一滚动；模型/停止/重试/复制在阅读区边缘 |
| 快捷翻译 | 单一纸面双栏、细分隔线；提交/停止贴近输入，复制/重试贴近输出；窄窗上下排列，保留编辑器实例、选区和 undo |
| 设置 | 常规、模型、提示词、隐私与取词四页侧栏；所有既有字段保留；三个提示词编辑器通过分段切换，变量插入与恢复默认不自动保存 |
| 状态 | 提交/等待、流式、失败、停止、截断、复制反馈、语言已改待重试；变化不隐式提交请求 |

## 源码分工

- `DesignTokens.cs`：独立颜色、字体、尺度和可绑定阴影强度。
- `Glyphs.cs`：系统字形检测与矢量回退。
- `PaperStyles.cs`：局部控件模板、键盘焦点、菜单/滑块/滚动条和外壳。
- `PaperTranslationView.cs`：只负责布局与外观状态，不发送模型请求。
- `PaperSettings.cs`：四页设置与标签浮条，保留原设置字段及保存协议。
- `MarkdownView.cs`：安全轻量 FlowDocument 渲染，不执行 HTML、不导航链接。
- `TranslationWindow.cs` / `SelectionAssistant.cs`：既有业务状态机和事件接线，Paper 通过薄适配使用新视图。
- `LanguagePicker.cs` / `OpacityControl.cs`：复用原过滤、提交和 Escape 行为，增加局部 Paper 外观。

## 逻辑 review 后的修正

1. 设置只读刷新不显示保存成功。保存中的字段快照与宿主回包匹配，黑名单按现有 trim/去重语义归一；无关 GET 不确认或提前开放并发保存。失败和关闭释放快照。保存 payload 不改；这是观察值匹配，不是新增协议事务 ACK。
2. 完整源文参加外层滚动，不在内部限高截断。用户上滚阅读时不被流式追加拉回底部；已在底部时才跟随。
3. 有序列表保留起始编号；不支持的编号语法保留为普通文字。HTML/链接不执行，原始 Answer 仍是复制源。
4. 等待提交的请求可正确取消并呈现已停止，继续隔离迟到 Begin/delta/done。

## 维护边界

不改变 Host JS、取词组件、模型/提示词逻辑、依赖或设置 schema。选中、打开窗口、粘贴和改语言不会自动调模型；helper 不接收模型凭据，也不新增 HTTP listener。透明度、快捷键、路由、提示词、黑名单和已有窗口偏好保持。

未纳入本轮：结果窗内切换动作请求、自动高度改写用户高度语义、DWM/WebView 迁移、高对比完整映射及长时性能优化。不能以回归断言数量代替视觉与真实使用反馈。

## 运行与回归

```powershell
pnpm verify
pnpm build:native
pnpm verify:paper
pnpm demo:paper
```

完整原生检查还可执行 `scripts/verify-theme.mjs`、`verify-popup-keyboard.mjs`、`verify-toolbar-placement.mjs`、`verify-window-preferences.mjs`、`verify-claude-preview.mjs` 和 `verify-settings-preview.mjs`。详见 [验证记录](<VERIFICATION.md>)。

正常启动直接使用 Paper。合成比较保留 Legacy（`node scripts/demo.mjs`）、先前 Claude（加 `--claude-preview`）和当前 Paper（加 `--design=paper`）。合成模式不读取真实选区/剪贴板，不发模型请求，偏好写入使用隔离目录。

## 实际效果

![快捷翻译](<previews/paper-20261104/quick.png>)

[划词结果](<previews/paper-20261104/panel.png>) · [深色结果](<previews/paper-20261104/panel-dark.png>) · [窄窗](<previews/paper-20261104/quick-compact.png>) · [设置](<previews/paper-20261104/settings.png>) · [提示词](<previews/paper-20261104/settings-prompts.png>)

这些是 125% DPI 的真实 WPF 合成数据截图，不是生成式概念图。100/150/200% 的实机视觉与长期资源表现未作为本轮完成结论。
