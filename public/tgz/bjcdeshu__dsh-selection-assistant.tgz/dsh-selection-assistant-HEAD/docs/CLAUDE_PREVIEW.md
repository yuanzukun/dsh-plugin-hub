# Claude 风格过渡记录

早期界面通过局部中性色和强调色适配 Claude 主题；后续 Quiet Paper 将字体、系统字形、内容结构、控件尺度和状态交互统一重做。当前日常界面为 **Quiet Paper（0.2.0）**，不再是仅演示可用。

- 最新设计、维护边界与启动方式：[Quiet Paper](<DESIGN_REDESIGN_20261104.md>)。
- 自动化验证及覆盖限制：[验证记录](<VERIFICATION.md>)。
- 当前真实合成截图：[结果窗](<previews/paper-20261104/panel.png>)、[快捷翻译](<previews/paper-20261104/quick.png>)、[设置](<previews/paper-20261104/settings.png>)。

保留三种合成模式用于回归：`node scripts/demo.mjs`（Legacy）、`node scripts/demo.mjs --claude-preview`（先前 Claude）、`node scripts/demo.mjs --design=paper`（当前设计）。正常插件启动无需这些参数。
