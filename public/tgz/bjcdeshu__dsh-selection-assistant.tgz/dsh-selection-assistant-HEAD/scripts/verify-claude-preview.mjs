import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { copyFile, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { helperEnvironment } from '../src/environment.js';

// Compile the real native controls into an isolated STA fixture. Translation
// windows stay off-screen; popup/toolbar content is masked before first render
// because Windows may clamp those HWNDs onto a monitor. No desktop input,
// clipboard actions, model, selection hook, installed host or user state is used.
if (process.platform !== 'win32') throw new Error('Claude preview verification requires Windows');
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
// Do not call Program.Main: it owns tray/hotkey/input-loop startup. Verify its
// opt-in gate from source, then exercise actual controls in our own Application.
const program = await readFile(join(root, 'native', 'SelectionAssistant.cs'), 'utf8');
assert.match(program, /Demo\s*=\s*args\.Length\s*>\s*0\s*&&\s*args\[0\]\s*==\s*"--demo"\s*;/, 'demo remains explicit');
assert.match(program, /ClaudePreview\s*=\s*UseClaudeAppearance\(args\)\s*;/, 'startup delegates to the tested daily-default appearance gate');
const output = join(root, '.local', `claude-preview-verification-${Date.now()}`);
await mkdir(output, { recursive: true });
const source = join(output, 'ClaudePreviewVerification.cs');
const executable = join(output, 'ClaudePreviewVerification.exe');
await writeFile(source, String.raw`
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Threading;
using DshSelectionAssistant;
using P = DshSelectionAssistant.Program;

internal static class ClaudePreviewVerification {
  static int Checks, KeyboardCases, ToolbarCases;
  static readonly BindingFlags Instance = BindingFlags.Instance | BindingFlags.NonPublic;
  static readonly BindingFlags Static = BindingFlags.Static | BindingFlags.NonPublic;
  static readonly string[] Keys = { "Ink", "Muted", "Surface", "Soft", "Line", "Hover", "Accent", "Tint" };
  static readonly string[] LegacyLight = { "#1A1A1A", "#707070", "#FFFFFF", "#F5F5F5", "#E6E6E6", "#EFEFEF", "#159B68" };
  static readonly string[] LegacyDark = { "#E8E8E8", "#A3A3A3", "#1F1F1F", "#292929", "#3A3A3A", "#363636", "#32B580" };
  static readonly string[] PreviewLight = { "#262626", "#737373", "#FFFFFF", "#F4F2F3", "#E9E9E9", "#F2F2F2", "#D97757", "#FAEEE9" };
  static readonly string[] PreviewDark = { "#E3E3E3", "#A3A3A3", "#191919", "#282626", "#333131", "#323232", "#D97757", "#3B2B25" };
  static readonly List<TranslationWindow> Panels = new List<TranslationWindow>();
  static readonly List<Window> Toolbars = new List<Window>();
  static readonly StringWriter Messages = new StringWriter(CultureInfo.InvariantCulture);
  static void Check(bool value, string label) { Checks++; if (!value) throw new Exception(label); }
  static void Same(object actual, object expected, string label) { Check(Object.ReferenceEquals(actual, expected), label + " (actual=" + actual + ", expected=" + expected + ")"); }
  // Top-level WPF layout rounds to physical pixels: 530 DIPs can become
  // 530.4 on a 125% monitor. Colors and brush identity remain exact checks.
  static void Near(double actual, double expected, string label) {
    double tolerance = label.IndexOf("width", StringComparison.OrdinalIgnoreCase) >= 0 || label.IndexOf("height", StringComparison.OrdinalIgnoreCase) >= 0 ? 0.51 : 0.01;
    Check(Math.Abs(actual - expected) <= tolerance, label + ": expected " + expected + ", got " + actual);
  }
  static void PaintEquals(Brush actual, Brush expected, string label) {
    // A sealed WPF setter clones bound Freezables. Compare effective color here;
    // subsequent theme passes verify that the clone still follows its source.
    var a = actual as SolidColorBrush; var b = expected as SolidColorBrush;
    Check(a != null && b != null && a.Color == b.Color, label + " (actual=" + actual + ", expected=" + expected + ")");
  }
  static T Field<T>(object owner, string name) { return (T)owner.GetType().GetField(name, Instance).GetValue(owner); }
  static void SetField(object owner, string name, object value) { owner.GetType().GetField(name, Instance).SetValue(owner, value); }
  static T ProgramField<T>(string name) { return (T)typeof(P).GetField(name, Static).GetValue(null); }
  static void SetProgram(string name, object value) { typeof(P).GetField(name, Static).SetValue(null, value); }
  static void CallProgram(string name, params object[] values) { typeof(P).GetMethod(name, Static).Invoke(null, values); }
  static void Call(object owner, string name) { owner.GetType().GetMethod(name, Instance).Invoke(owner, null); }
  static void Drain() { Dispatcher.CurrentDispatcher.Invoke(DispatcherPriority.ApplicationIdle, new Action(delegate {})); }
  static void Apply(bool dark) { CallProgram("ApplyTheme", dark); Drain(); }
  static SolidColorBrush[] BrushesFor(Type type, int count) {
    var brushes = new SolidColorBrush[count];
    for (int i = 0; i < count; i++) brushes[i] = (SolidColorBrush)type.GetField(Keys[i], Static).GetValue(null);
    return brushes;
  }
  static void ColorsFor(Type type, SolidColorBrush[] originals, string[] colors) {
    for (int i = 0; i < colors.Length; i++) {
      var brush = (SolidColorBrush)type.GetField(Keys[i], Static).GetValue(null);
      Same(brush, originals[i], type.Name + "." + Keys[i] + " retains brush identity");
      Check(brush.Color == (Color)ColorConverter.ConvertFromString(colors[i]), type.Name + "." + Keys[i] + " exact " + colors[i]);
      Check(!brush.IsFrozen, type.Name + "." + Keys[i] + " stays mutable after styles seal");
    }
  }
  static TranslationWindow Panel(string surface) {
    var panel = new TranslationWindow(surface); Panels.Add(panel); return panel;
  }
  static void Offscreen(TranslationWindow panel) {
    panel.Window.Left = -10000; panel.Window.Top = -10000;
    panel.Window.ShowInTaskbar = false; panel.Window.ShowActivated = false;
    if (!panel.Window.IsVisible) panel.Window.Show();
    panel.Window.UpdateLayout(); Drain();
  }
  static Border Chrome(Button button) {
    button.ApplyTemplate();
    var chrome = (Border)button.Template.FindName("chrome", button);
    Check(chrome != null && button.Style.IsSealed && button.Template.IsSealed, "real production button style/template sealed");
    return chrome;
  }
  static void PanelPalette(TranslationWindow panel, bool preview) {
    Brush ink = preview ? SelectionAppearance.Ink : P.Ink;
    Brush muted = preview ? SelectionAppearance.Muted : P.Muted;
    Brush surface = preview ? SelectionAppearance.Surface : P.Surface;
    Brush line = preview ? SelectionAppearance.Line : P.Line;
    Brush soft = preview ? SelectionAppearance.Soft : P.Soft;
    Brush accent = preview ? SelectionAppearance.Accent : P.Accent;
    var shell = (Visuals.WindowShell)panel.Window.Content;
    Same(shell.Face.Background, surface, panel.Surface + " shell surface is scoped correctly");
    Same(shell.Face.BorderBrush, line, panel.Surface + " shell line is scoped correctly");
    Same(Field<TextBox>(panel, "Input").Foreground, ink, panel.Surface + " source ink");
    Same(Field<RichTextBox>(panel, "Result").Foreground, ink, panel.Surface + " result ink");
    Same(Field<RichTextBox>(panel, "Result").Document.Foreground, ink, panel.Surface + " document ink");
    Same(Field<TextBlock>(panel, "Title").Foreground, ink, panel.Surface + " title ink");
    foreach (string name in new string[] { "Status", "Route", "Count", "EmptyText" })
      Same(Field<TextBlock>(panel, name).Foreground, muted, panel.Surface + " " + name + " muted ink");
    Same(Field<ProgressBar>(panel, "Progress").Foreground, accent, panel.Surface + " progress accent");
    var source = Field<Border>(panel, "SourceBox");
    if (source != null) Same(source.Background, soft, panel.Surface + " source disclosure background");
    var pin = Field<Button>(panel, "Pin");
    PaintEquals(pin.Foreground, ink, panel.Surface + " implicit button style ink");
    Near(Chrome(pin).CornerRadius.TopLeft, preview ? 8 : 6, panel.Surface + " button radius");
    foreach (string key in new string[] { "Ink", "Muted", "Surface", "Soft", "Line", "Hover", "Accent" }) {
      object expected = (preview ? typeof(SelectionAppearance) : typeof(P)).GetField(key, Static).GetValue(null);
      Same(panel.Window.FindResource(key), expected, panel.Surface + " local " + key + " resource");
      Same(Application.Current.Resources[key], typeof(P).GetField(key, Static).GetValue(null), "application " + key + " remains legacy");
    }
    var language = Field<LanguagePicker>(panel, "Language");
    Same(language.Style, panel.Window.FindResource(typeof(Button)), panel.Surface + " derived language button uses correct scope");
    if (preview) Same(panel.Window.FindResource("Tint"), SelectionAppearance.Tint, "preview tint resource");
    else {
      Near(shell.Margin.Left, 10, "legacy shell gutter"); Near(shell.Face.CornerRadius.TopLeft, 8, "legacy shell radius");
      Near(((DropShadowEffect)((Border)shell.Children[0]).Effect).BlurRadius, 14, "legacy shell shadow");
      Same(language.Background, P.Soft, "legacy language button background unchanged");
    }
  }
  static Popup MaskPopup(object owner) {
    var popup = Field<Popup>(owner, "Flyout");
    // A Popup can be clamped onto the desktop even with an off-screen owner.
    // Mask only rendering; actual templates, layout, input routes and brushes run.
    popup.Child.OpacityMask = System.Windows.Media.Brushes.Transparent;
    popup.PopupAnimation = PopupAnimation.None; return popup;
  }
  static void Open(Button button) { button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)); Drain(); }
  static KeyEventArgs Escape(FrameworkElement target) {
    var source = PresentationSource.FromVisual(target);
    Check(source != null, "synthetic key target has a real presentation source");
    var key = new KeyEventArgs(Keyboard.PrimaryDevice, source, 0, Key.Escape) { RoutedEvent = UIElement.PreviewKeyDownEvent };
    target.RaiseEvent(key); Drain(); return key;
  }
  static void PopupPalette(TranslationWindow panel, bool preview) {
    var language = Field<LanguagePicker>(panel, "Language");
    var languagePopup = MaskPopup(language);
    Open(language); Check(language.IsPopupOpen, "language popup opens without submit");
    var edge = (Border)languagePopup.Child;
    Same(edge.Background, preview ? SelectionAppearance.Surface : P.Surface, "language flyout surface scope");
    Same(edge.BorderBrush, preview ? SelectionAppearance.Line : P.Line, "language flyout line scope");
    PaintEquals(Field<TextBox>(language, "Search").Foreground, preview ? SelectionAppearance.Ink : P.Ink, "language search ink scope");
    PaintEquals(Field<TextBox>(language, "Search").Background, preview ? SelectionAppearance.Surface : P.Surface, "language search surface scope");
    Same(Field<Button>(language, "Custom").Style, panel.Window.FindResource(typeof(Button)), "language custom button scope");
    language.ClosePopup(); Drain();
    var opacity = Field<OpacityControl>(panel, "Transparency");
    var opacityPopup = MaskPopup(opacity);
    Open(opacity.Button); Check(opacity.IsPopupOpen, "opacity popup opens without submit");
    var shell = (Visuals.WindowShell)opacityPopup.Child;
    Same(shell.Face.Background, preview ? SelectionAppearance.Surface : P.Surface, "opacity flyout surface scope");
    Same(shell.Face.BorderBrush, preview ? SelectionAppearance.Line : P.Line, "opacity flyout line scope");
    Same(Field<TextBlock>(opacity, "ValueLabel").Foreground, preview ? SelectionAppearance.Ink : P.Ink, "opacity value ink scope");
    Same(Field<Slider>(opacity, "Slider").Foreground, preview ? SelectionAppearance.Accent : P.Accent, "opacity slider accent scope");
    opacity.Close(); Drain();
  }
  static Dictionary<string, object> Message(string type, string id) {
    return new Dictionary<string, object> { { "type", type }, { "id", id }, { "text", "-late" }, { "message", "late failure" } };
  }
  static string Snapshot(TranslationWindow panel) {
    return new JavaScriptSerializer().Serialize(new { panel.Answer, panel.InputText, panel.RunId, panel.Busy,
      visible = panel.Window.IsVisible, status = Field<TextBlock>(panel, "Status").Text,
      document = new TextRange(Field<RichTextBox>(panel, "Result").Document.ContentStart, Field<RichTextBox>(panel, "Result").Document.ContentEnd).Text });
  }
  static void LateFrames(TranslationWindow panel, string id) {
    string before = Snapshot(panel);
    foreach (string type in new string[] { "started", "delta", "done", "failed", "input-error" }) panel.Receive(Message(type, id));
    Drain(); Check(Snapshot(panel) == before, "late started/delta/done/failed/error frames ignored after cancellation/close");
  }
  static void Disclosure(TranslationWindow panel) {
    var toggle = Field<Button>(panel, "SourceToggle"); var source = Field<Border>(panel, "SourceBox");
    Check(toggle != null && source != null, "selection owns a private source disclosure button and box");
    Check(!Field<bool>(panel, "SourceExpanded") && source.Visibility == Visibility.Collapsed, "source initially collapsed");
    panel.DemoInput("Synthetic source disclosure only");
    double width = panel.Window.Width, height = panel.Window.Height, opacity = panel.OpacityPercent;
    string messages = Messages.ToString();
    panel.DemoSource(); panel.Window.UpdateLayout();
    Check(Field<bool>(panel, "SourceExpanded") && source.Visibility == Visibility.Visible, "DemoSource expands actual source box");
    panel.DemoSource(); panel.Window.UpdateLayout();
    Check(!Field<bool>(panel, "SourceExpanded") && source.Visibility == Visibility.Collapsed, "DemoSource collapses actual source box");
    Check(panel.InputText == "Synthetic source disclosure only", "disclosure preserves source text");
    Check(Messages.ToString() == messages && !panel.Busy, "disclosure never submits a request");
    Near(panel.Window.Width, width, "disclosure preserves width"); Near(panel.Window.Height, height, "disclosure preserves height"); Near(panel.OpacityPercent, opacity, "disclosure preserves opacity");
  }
  static void KeyboardPriority(TranslationWindow panel) {
    var input = Field<TextBox>(panel, "Input");
    var language = Field<LanguagePicker>(panel, "Language");
    var opacity = Field<OpacityControl>(panel, "Transparency");
    MaskPopup(language); MaskPopup(opacity);
    for (int kind = 0; kind < 2; kind++) {
      var targets = kind == 0
        ? new FrameworkElement[] { Field<TextBox>(language, "Search"), language, input }
        : new FrameworkElement[] { Field<Slider>(opacity, "Slider"), opacity.Button, input };
      foreach (var target in targets) {
        Offscreen(panel); panel.StopRun(); panel.Original = "Synthetic keyboard source"; panel.DemoInput(panel.Original);
        Field<StringBuilder>(panel, "Buffer").Clear(); Call(panel, "ResetDocument"); Call(panel, "UpdateButtons");
        if (kind == 0) Open(language); else Open(opacity.Button);
        Check(kind == 0 ? language.IsPopupOpen : opacity.IsPopupOpen, "keyboard fixture opens actual flyout");
        // Seed a synthetic in-flight run after opening. This tests the popup-owner
        // tunnel/race without Begin(), which would reposition/activate the window.
        string id = "fixture-" + panel.Surface + "-" + (++KeyboardCases);
        panel.RunId = id; panel.Busy = true;
        double percent = panel.OpacityPercent; string value = language.Value;
        var first = Escape(target);
        Check(first.Handled && !language.IsPopupOpen && !opacity.IsPopupOpen, "first Esc closes only the flyout");
        Check(panel.Window.IsVisible && panel.Busy && panel.RunId == id, "flyout Esc preserves active run and owner window");
        Near(panel.OpacityPercent, percent, "flyout Esc retains opacity"); Check(language.Value == value, "flyout Esc retains language");
        panel.Receive(new Dictionary<string, object> { { "type", "delta" }, { "id", id }, { "text", "Synthetic continued frame" } });
        Check(panel.Answer == "Synthetic continued frame", "run accepts matching frame after popup-only Esc");
        var second = Escape(input);
        Check(second.Handled && panel.Window.IsVisible && !panel.Busy && panel.RunId == null, "second Esc stops run, not window");
        Check(panel.Answer == "Synthetic continued frame", "stopping preserves partial result");
        Check(!Field<DispatcherTimer>(panel, "RenderTimer").IsEnabled, "stop cancels pending render timer");
        LateFrames(panel, id);
        var third = Escape(input);
        Check(third.Handled && !panel.Window.IsVisible, "idle Esc closes the window"); LateFrames(panel, id);
      }
    }
  }
  static void PreviewScrolling() {
    var panel = Panel("quick"); Offscreen(panel); panel.DemoResize(640, 400);
    var text = new StringBuilder(); for (int i = 0; i < 120; i++) text.AppendLine("Synthetic multiline editor row " + i);
    panel.DemoInput(text.ToString()); panel.Window.UpdateLayout(); Drain();
    var input = Field<TextBox>(panel, "Input"); input.ApplyTemplate();
    var viewer = input.Template.FindName("PART_ContentHost", input) as ScrollViewer;
    Check(viewer != null && viewer.ScrollableHeight > 0, "rounded input preserves the actual scrolling content host");
    viewer.ScrollToBottom(); Drain(); Check(viewer.VerticalOffset > 0, "long quick source scrolls to bottom");
    viewer.ScrollToTop(); Drain(); Near(viewer.VerticalOffset, 0, "long quick source scrolls back to top");
    viewer.ApplyTemplate(); var bar = viewer.Template.FindName("PART_VerticalScrollBar", viewer) as ScrollBar;
    Check(bar != null && bar.IsVisible, "long editor exposes its real vertical scrollbar");
    Same(bar.Style, panel.Window.FindResource(typeof(ScrollBar)), "preview editor uses the scoped scrollbar style");
    Near(bar.ActualWidth, 8, "preview scrollbar is compact"); bar.ApplyTemplate();
    var track = bar.Template.FindName("PART_Track", bar) as Track;
    Check(track != null && track.Thumb != null && track.IncreaseRepeatButton != null && track.DecreaseRepeatButton != null, "scroll thumb and page controls survive restyling");
    Same(track.IncreaseRepeatButton.Command, ScrollBar.PageDownCommand, "vertical track keeps page-down command");
    Same(track.DecreaseRepeatButton.Command, ScrollBar.PageUpCommand, "vertical track keeps page-up command");
    ScrollBar.PageDownCommand.Execute(null, bar); Drain(); Check(viewer.VerticalOffset > 0, "styled scrollbar page command still scrolls editor");
    panel.Close();
  }
  static void ToolbarFit(bool preview) {
    P.ClaudePreview = preview; SetProgram("Toolbar", null);
    CallProgram("ShowToolbar", new Dictionary<string, object> { { "id", "fixture-toolbar-" + preview }, { "x", -10000 }, { "y", -10000 }, { "expiresMs", 30000 } });
    var toolbar = ProgramField<Window>("Toolbar"); Toolbars.Add(toolbar); Drain();
    Check(toolbar.IsVisible, "actual Program.ShowToolbar displays fixture HWND");
    var shell = (Visuals.WindowShell)toolbar.Content;
    Same(shell.OpacityMask, System.Windows.Media.Brushes.Transparent, "actual toolbar masked before first render");
    toolbar.Left = -10000; toolbar.Top = -10000; toolbar.UpdateLayout();
    Near(toolbar.Width, 184, "actual toolbar width unchanged"); Near(toolbar.Height, 48, "actual toolbar height unchanged");
    Check(shell.Margin == new Thickness(6), "actual toolbar keeps 6 DIP shadow gutter");
    Same(shell.Face.Background, preview ? SelectionAppearance.Surface : P.Surface, "actual toolbar surface scope");
    Same(shell.Face.BorderBrush, preview ? SelectionAppearance.Line : P.Line, "actual toolbar line scope");
    var row = shell.Face.Child as StackPanel;
    Check(row != null && row.Children.Count == 6, "actual toolbar has grip, three actions, separator and settings");
    double insetX = shell.Face.BorderThickness.Left + shell.Face.Padding.Left;
    double insetY = shell.Face.BorderThickness.Top + shell.Face.Padding.Top;
    Check(row.DesiredSize.Width <= shell.Face.ActualWidth - 2 * insetX + 0.75, "complete toolbar desired width fits available face");
    Check(row.DesiredSize.Height <= shell.Face.ActualHeight - 2 * insetY + 0.75, "complete toolbar desired height fits available face");
    int buttons = 0;
    foreach (FrameworkElement child in row.Children) {
      Rect bounds = child.TransformToAncestor(shell.Face).TransformBounds(new Rect(new Point(), child.RenderSize));
      Check(bounds.Left >= insetX - 0.75 && bounds.Top >= insetY - 0.75
        && bounds.Right <= shell.Face.ActualWidth - insetX + 0.75 && bounds.Bottom <= shell.Face.ActualHeight - insetY + 0.75,
        "actual toolbar control fits without clipping: " + child.GetType().Name);
      var button = child as Button;
      if (button != null) { buttons++; Near(Chrome(button).CornerRadius.TopLeft, preview ? 8 : 6, "actual toolbar scoped button radius"); }
    }
    Check(buttons == 4, "all four toolbar buttons fit");
    if (preview) {
      Same(((Button)row.Children[1]).Foreground, SelectionAppearance.Accent, "translate action uses terracotta accent");
      Same(((Button)row.Children[1]).Background, SelectionAppearance.Tint, "translate action uses preview tint");
    }
    CallProgram("HideToolbar", true); Check(!toolbar.IsVisible, "fixture toolbar dismisses normally"); ToolbarCases++;
    SetProgram("Toolbar", null);
  }
  [STAThread] static int Main() {
    TextWriter stdout = Console.Out;
    try {
      Check(P.UseClaudeAppearance(new string[0]), "normal native startup defaults to Claude without a flag");
      Check(P.UseClaudeAppearance(new string[] { "--state-file", "synthetic-state.json", "--icon-source", "synthetic-host.exe" }), "real companion argument shape defaults to Claude without reading files");
      Check(P.UseClaudeAppearance(new string[] { "--claude-preview" }), "normal startup remains Claude when an optional flag is present");
      Check(!P.UseClaudeAppearance(new string[] { "--demo", "synthetic-output" }), "legacy synthetic demo remains available");
      Check(P.UseClaudeAppearance(new string[] { "--demo", "synthetic-output", "--claude-preview" }), "Claude synthetic demo remains available");
      Console.SetOut(Messages);
      var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown }; SetProgram("App", app);
      P.Config = new Dictionary<string, object> { { "theme", "light" }, { "targetLanguage", "auto" }, { "enabled", true } };
      SetProgram("Demo", true); SetProgram("ToolbarTimer", new DispatcherTimer());
      Visuals.AnimationsEnabled = false; CallProgram("SetupStyles"); Apply(false);
      var flag = typeof(P).GetField("ClaudePreview", Static);
      Check(flag != null && flag.IsAssembly && flag.FieldType == typeof(bool), "preview flag is internal static bool");
      Check(typeof(TranslationWindow).GetField("Claude", Instance).IsInitOnly, "window preview scope is readonly");
      Check(typeof(TranslationWindow).GetField("SourceToggle", Instance).IsPrivate, "source disclosure button remains private");
      var legacyBrushes = BrushesFor(typeof(P), 7); var previewBrushes = BrushesFor(typeof(SelectionAppearance), 8);
      P.ClaudePreview = false;
      var legacySelection = Panel("selection"); var legacyQuick = Panel("quick");
      Offscreen(legacySelection); Offscreen(legacyQuick);
      Check(!legacySelection.Claude && !legacyQuick.Claude, "without preview flag both surfaces remain legacy");
      Near(legacySelection.Window.Width, 520, "legacy selection width"); Near(legacySelection.Window.Height, 420, "legacy selection height");
      Near(legacyQuick.Window.Width, 780, "legacy quick width"); Near(legacyQuick.Window.Height, 530, "legacy quick height");
      foreach (bool dark in new bool[] { false, true, false }) {
        Apply(dark); ColorsFor(typeof(P), legacyBrushes, dark ? LegacyDark : LegacyLight);
        PanelPalette(legacySelection, false); PanelPalette(legacyQuick, false);
      }
      P.ClaudePreview = true;
      var selection = Panel("selection"); var quick = Panel("quick"); var other = Panel("other");
      Check(selection.Claude && quick.Claude && !other.Claude, "phase-two preview covers selection and quick, never unknown surfaces");
      Check(!legacySelection.Claude && !legacyQuick.Claude, "enabling preview does not mutate existing window scope");
      Offscreen(selection); Offscreen(quick);
      P.Preferences = new WindowPreferences(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "window-state.json"));
      selection.DemoResize(612, 498); selection.DemoOpacity(81);
      quick.DemoResize(836, 588); quick.DemoOpacity(73); quick.DemoInput("Synthetic quick text retained through theme changes");
      object selectionContent = selection.Window.Content, quickContent = quick.Window.Content;
      var scoped = SelectionAppearance.Resources();
      for (int i = 0; i < Keys.Length; i++) Same(scoped[Keys[i]], previewBrushes[i], "preview dictionary owns " + Keys[i]);
      // First access to templates/styles is before the loop, so dark/light changes
      // must reach already-sealed WPF controls rather than constructing replacements.
      PanelPalette(selection, true); PanelPalette(quick, true); PopupPalette(selection, true); PopupPalette(quick, true);
      var identities = new object[] { Field<Button>(selection, "Pin").Style, Field<LanguagePicker>(selection, "Language").Style,
        Field<TextBox>(Field<LanguagePicker>(selection, "Language"), "Search").Style };
      for (int pass = 0; pass < 3; pass++) {
        bool dark = pass == 1; Apply(dark);
        ColorsFor(typeof(P), legacyBrushes, dark ? LegacyDark : LegacyLight);
        ColorsFor(typeof(SelectionAppearance), previewBrushes, dark ? PreviewDark : PreviewLight);
        PanelPalette(selection, true); PanelPalette(quick, true); PanelPalette(legacySelection, false);
        PopupPalette(selection, true); PopupPalette(quick, true);
        Same(selection.Window.Content, selectionContent, "theme changes reuse selection shell"); Same(quick.Window.Content, quickContent, "theme changes reuse quick shell");
        Same(Field<Button>(selection, "Pin").Style, identities[0], "theme changes reuse sealed preview button style");
        Same(Field<LanguagePicker>(selection, "Language").Style, identities[1], "theme changes reuse language style");
        Same(Field<TextBox>(Field<LanguagePicker>(selection, "Language"), "Search").Style, identities[2], "theme changes reuse popup search style");
        Near(selection.Window.Width, 612, "theme retains selection width"); Near(selection.Window.Height, 498, "theme retains selection height"); Near(selection.OpacityPercent, 81, "theme retains selection opacity");
        Near(quick.Window.Width, 836, "theme retains quick width"); Near(quick.Window.Height, 588, "theme retains quick height"); Near(quick.OpacityPercent, 73, "theme retains quick opacity");
        Near(((Visuals.WindowShell)selection.Window.Content).Opacity, 0.81, "selection content opacity retained");
        Near(((Visuals.WindowShell)quick.Window.Content).Opacity, 0.73, "quick content opacity retained");
        Check(quick.InputText == "Synthetic quick text retained through theme changes", "theme retains quick input");
      }
      Check(P.Preferences.Flush(), "fixture-only preferences flush");
      using (var restored = new WindowPreferences(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "window-state.json"))) {
        Near(restored.Get("selection").Width, 612, "selection size persisted"); Near(restored.Get("selection").Height, 498, "selection height persisted"); Near(restored.Get("selection").Opacity, 81, "selection opacity persisted");
        Near(restored.Get("quick").Width, 836, "quick size persisted"); Near(restored.Get("quick").Height, 588, "quick height persisted"); Near(restored.Get("quick").Opacity, 73, "quick opacity persisted");
      }
      Disclosure(selection);
      selection.DemoResize(380, 280); selection.DemoInput(new string('文', 300) + "\n" + new string('字', 300)); selection.DemoSource();
      selection.Window.UpdateLayout(); Drain();
      Check(Field<RichTextBox>(selection, "Result").ActualHeight >= 24, "minimum-size result retains a reading viewport with long source expanded");
      Check(Field<TextBox>(selection, "Input").ActualHeight <= 29, "compact source has its own bounded scrolling viewport");
      Check(Field<Button>(selection, "Pin").ActualWidth >= 24 && Field<Button>(selection, "Copy").ActualWidth >= 24, "minimum-size actions retain hit targets");
      selection.DemoSource(); selection.DemoResize(612, 498);
      quick.DemoResize(640, 400); quick.Window.UpdateLayout(); Drain();
      Check(Field<TextBox>(quick, "Input").ActualHeight >= 90, "minimum quick size keeps multiline editing viewport");
      Check(Field<RichTextBox>(quick, "Result").ActualHeight >= 90, "minimum quick size keeps readable output viewport");
      Check(Field<Button>(quick, "Translate").ActualWidth >= 70, "quick primary action retains a usable hit target");
      quick.DemoResize(836, 588);
      KeyboardPriority(selection); KeyboardPriority(quick);
      // Loaded precedes first render. Mask the actual production toolbar here;
      // ShowToolbar is allowed to run its real monitor placement without flashing UI.
      EventManager.RegisterClassHandler(typeof(Window), FrameworkElement.LoadedEvent, new RoutedEventHandler(delegate(object sender, RoutedEventArgs e) {
        var window = sender as Window;
        if (window != null && window.Title == "DSH Selection Toolbar") ((UIElement)window.Content).OpacityMask = System.Windows.Media.Brushes.Transparent;
      }));
      PreviewScrolling(); ToolbarFit(false); ToolbarFit(true);
      Check(ProgramField<Window>("Settings") == null, "verification never opens settings");
      Check(ProgramField<object>("Tray") == null && ProgramField<object>("HotkeyWindow") == null, "verification never initializes tray or hotkeys");
      int cancellations = 0;
      foreach (string line in Messages.ToString().Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)) {
        var message = new JavaScriptSerializer().DeserializeObject(line) as Dictionary<string, object>;
        string type = P.Str(message, "type");
        Check(type == "cancel" || type == "dismiss", "only fixture cancellation/dismiss messages emitted, not model/settings actions");
        if (type == "cancel") cancellations++;
      }
      Check(cancellations == KeyboardCases, "each active run cancelled exactly once, never by popup-only Esc");
      stdout.WriteLine(new JavaScriptSerializer().Serialize(new { result = "passed", checks = Checks, keyboardCases = KeyboardCases,
        toolbarCases = ToolbarCases, themeSequence = new string[] { "light", "dark", "light" },
        clipboardAccess = false, modelRequests = false, hostChanges = false, systemThemeChanged = false }));
      return 0;
    } catch (Exception error) { Console.Error.WriteLine(error.ToString()); return 1; }
    finally {
      P.Closing = true; var timer = ProgramField<DispatcherTimer>("ToolbarTimer"); if (timer != null) timer.Stop();
      foreach (var panel in Panels) { Field<LanguagePicker>(panel, "Language").ClosePopup(); Field<OpacityControl>(panel, "Transparency").Close(); panel.Window.Close(); }
      foreach (var toolbar in Toolbars) toolbar.Close();
      if (P.Preferences != null) P.Preferences.Dispose();
      Console.SetOut(stdout);
    }
  }
}
`, 'utf8');

const framework = join(process.env.WINDIR || 'C:\\Windows', 'Microsoft.NET', 'Framework64', 'v4.0.30319');
const references = ['System.dll', 'System.Core.dll', 'System.Xaml.dll', 'System.Web.Extensions.dll', 'System.Drawing.dll', 'System.Windows.Forms.dll', 'WPF/WindowsBase.dll', 'WPF/PresentationCore.dll', 'WPF/PresentationFramework.dll', 'WPF/UIAutomationClient.dll', 'WPF/UIAutomationTypes.dll'];
const run = (file, args) => new Promise((accept, reject) => {
  const child = spawn(file, args, { windowsHide: true, env: helperEnvironment(), stdio: ['ignore', 'pipe', 'pipe'] });
  let stdout = '', stderr = '', timedOut = false;
  child.stdout.on('data', chunk => stdout += chunk);
  child.stderr.on('data', chunk => stderr += chunk);
  const timer = setTimeout(() => { timedOut = true; child.kill(); }, 30000);
  child.once('error', error => { clearTimeout(timer); reject(error); });
  child.once('close', code => {
    clearTimeout(timer);
    if (timedOut) reject(new Error('Claude preview verification timed out'));
    else if (code === 0) accept(stdout);
    else reject(new Error(stderr || stdout || `Exited ${code}`));
  });
});
try {
  const sources = (await readdir(join(root, 'native'))).filter(name => name.endsWith('.cs')).sort().map(name => join(root, 'native', name));
  await run(join(framework, 'csc.exe'), ['/nologo', '/target:exe', '/main:ClaudePreviewVerification', '/utf8output', `/out:${executable}`, `/win32manifest:${join(root, 'native', 'app.manifest')}`, ...references.map(path => `/reference:${join(framework, path)}`), ...sources, source]);
  await copyFile(join(root, 'native', 'app.config'), executable + '.config');
  const result = JSON.parse((await run(executable, [])).trim());
  assert.equal(result.result, 'passed');
  assert.equal(result.keyboardCases, 12);
  assert.equal(result.toolbarCases, 2);
  await writeFile(join(output, 'result.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify({ ...result, report: join(output, 'result.json') }, null, 2));
} catch (error) {
  await writeFile(join(output, 'failure.txt'), String(error.stack || error) + '\n');
  throw error;
}
