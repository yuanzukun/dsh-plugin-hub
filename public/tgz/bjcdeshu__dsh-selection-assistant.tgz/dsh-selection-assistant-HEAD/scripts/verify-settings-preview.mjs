import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { copyFile, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { helperEnvironment } from '../src/environment.js';

// Compile all real native controls into a separate STA entry point, never
// Program.Main. Mask the settings content at Loaded (before the first render):
// Windows can clamp centered/translucent HWNDs onto a physical monitor. All
// settings, model catalog and save payloads below are synthetic fixture values.
if (process.platform !== 'win32') throw new Error('Settings preview verification requires Windows');
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const program = await readFile(join(root, 'native', 'SelectionAssistant.cs'), 'utf8');
assert.match(program, /ClaudePreview\s*=\s*UseClaudeAppearance\(args\)\s*;/);
assert.match(program, /if\s*\(ClaudePreview\)\s*\{\s*ShowSettingsPreview\(\);\s*return;\s*\}/);
assert.match(program, /if\s*\(Demo\s*&&\s*type\s*==\s*"demo-settings-tab"\)/);
const output = join(root, '.local', `settings-preview-verification-${Date.now()}`);
await mkdir(output, { recursive: true });
const source = join(output, 'SettingsPreviewVerification.cs');
const executable = join(output, 'SettingsPreviewVerification.exe');
await writeFile(source, String.raw`
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using DshSelectionAssistant;
using P = DshSelectionAssistant.Program;
using A = DshSelectionAssistant.SelectionAppearance;

internal static class SettingsPreviewVerification {
  static readonly BindingFlags Static = BindingFlags.Static | BindingFlags.NonPublic;
  static readonly BindingFlags Instance = BindingFlags.Instance | BindingFlags.NonPublic;
  static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
  static readonly StringWriter Messages = new StringWriter(CultureInfo.InvariantCulture);
  static readonly string[] Keys = { "Ink", "Muted", "Surface", "Soft", "Line", "Hover", "Accent" };
  static readonly List<object> Saves = new List<object>();
  static int Checks, TabCases, ReachabilityCases;
  static T Field<T>(string name) { return (T)typeof(P).GetField(name, Static).GetValue(null); }
  static T ChildField<T>(object owner, string name) { return (T)owner.GetType().GetField(name, Instance).GetValue(owner); }
  static void Set(string name, object value) { typeof(P).GetField(name, Static).SetValue(null, value); }
  static void Call(string name, params object[] args) { typeof(P).GetMethod(name, Static).Invoke(null, args); }
  static void Check(bool value, string label) { Checks++; if (!value) throw new Exception(label); }
  static void Same(object a, object b, string label) { Check(Object.ReferenceEquals(a, b), label); }
  static void Near(double a, double b, string label) { Check(Math.Abs(a-b) <= 0.51, label + ": " + a + " vs " + b); }
  static void Paint(Brush a, Brush b, string label) { Check(a is SolidColorBrush && b is SolidColorBrush && ((SolidColorBrush)a).Color == ((SolidColorBrush)b).Color, label + ": " + a + " vs " + b); }
  static void Drain() { Dispatcher.CurrentDispatcher.Invoke(DispatcherPriority.ApplicationIdle, new Action(delegate {})); }
  static void Apply(bool dark) { Call("ApplyTheme", dark); Drain(); }
  static Window Window { get { return Field<Window>("Settings"); } }
  static TabControl Tabs { get { return Field<TabControl>("SettingsTabs"); } }
  static Dictionary<string, TextBox> Prompts { get { return Field<Dictionary<string, TextBox>>("PromptBoxes"); } }
  static Dictionary<string, object> Config() {
    return new Dictionary<string, object> {
      { "enabled", false }, { "trigger", "hotkey" }, { "targetLanguage", "French" }, { "theme", "light" }, { "quickHotkey", "Alt+Shift+T" },
      { "provider", "fixture-provider" }, { "model", "fixture-model" }, { "clipboardFallback", false },
      { "blockedApps", new object[] { "fixture-secret.exe", "fixture-terminal.exe" } },
      { "prompts", new Dictionary<string, object> { { "translate", "Synthetic translate {{targetLanguage}}" }, { "explain", "Synthetic explanation" }, { "summarize", "Synthetic summary" } } }
    };
  }
  static object[] Catalog() {
    return new object[] {
      new Dictionary<string, object> { { "provider", "fixture-provider" }, { "model", "fixture-model" }, { "name", "Synthetic original" } },
      new Dictionary<string, object> { { "provider", "fixture-other" }, { "model", "fixture-second" }, { "name", "Synthetic second" } }
    };
  }
  static List<Dictionary<string, object>> TakeMessages() {
    var result = new List<Dictionary<string, object>>();
    foreach (string line in Messages.ToString().Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)) result.Add((Dictionary<string, object>)Json.DeserializeObject(line));
    Messages.GetStringBuilder().Clear(); return result;
  }
  static void OnlyRead() {
    var messages = TakeMessages(); Check(messages.Count == 1 && P.Str(messages[0], "type") == "settings-get" && messages[0].Count == 1, "opening/reopening sends exactly the normal settings-get, never settings-save");
  }
  static string Values() {
    var prompts = new Dictionary<string, object>(); foreach (var pair in Prompts) prompts[pair.Key] = pair.Value.Text;
    return Json.Serialize(new object[] { Field<CheckBox>("EnabledBox").IsChecked, Field<ComboBox>("TriggerBox").SelectedIndex,
      Field<LanguagePicker>("LanguageBox").Value, Field<ComboBox>("ThemeBox").SelectedIndex, Field<ComboBox>("QuickHotkeyBox").SelectedIndex,
      Field<TextBox>("ProviderBox").Text, Field<TextBox>("ModelIdBox").Text, Field<CheckBox>("ClipboardBox").IsChecked, Field<TextBox>("BlockedBox").Text, prompts });
  }
  static void InitialValues() {
    Check(Field<CheckBox>("EnabledBox").IsChecked == false && Field<ComboBox>("TriggerBox").SelectedIndex == 1, "listener and trigger values retained");
    Check(Field<LanguagePicker>("LanguageBox").Value == "French" && Field<ComboBox>("ThemeBox").SelectedIndex == 1, "language and theme values retained");
    Check(Field<ComboBox>("QuickHotkeyBox").SelectedIndex == 2, "shortcut value retained");
    Check(Field<TextBox>("ProviderBox").Text == "fixture-provider" && Field<TextBox>("ModelIdBox").Text == "fixture-model", "paired model-route edits retained");
    Check(Field<CheckBox>("ClipboardBox").IsChecked == false && Field<TextBox>("BlockedBox").Text == "fixture-secret.exe\nfixture-terminal.exe", "privacy values retained");
    Check(Prompts.Count == 3 && Prompts["translate"].Text == "Synthetic translate {{targetLanguage}}" && Prompts["explain"].Text == "Synthetic explanation" && Prompts["summarize"].Text == "Synthetic summary", "all three prompt editors retained");
  }
  static void DefaultValues() {
    Check(Field<CheckBox>("EnabledBox").IsChecked == false && Field<CheckBox>("ClipboardBox").IsChecked == false, "empty config keeps listening and clipboard disabled");
    Check(Field<ComboBox>("TriggerBox").SelectedIndex == 0 && Field<ComboBox>("ThemeBox").SelectedIndex == 0 && Field<ComboBox>("QuickHotkeyBox").SelectedIndex == 0, "empty config keeps auto trigger, system theme and Ctrl+Alt+T");
    Check(Field<LanguagePicker>("LanguageBox").Value == "auto" && Field<ComboBox>("ModelBox").SelectedIndex == 0, "empty config keeps auto language and host-default model");
    Check(Field<TextBox>("ProviderBox").Text == "" && Field<TextBox>("ModelIdBox").Text == "" && Field<TextBox>("BlockedBox").Text == "", "empty config retains empty route and blacklist editors");
    Check(Prompts.Count == 3 && Prompts["translate"].Text == "" && Prompts["explain"].Text == "" && Prompts["summarize"].Text == "", "empty config keeps all prompt editors available for default restoration");
  }
  static void Palette(bool preview) {
    var kind = preview ? typeof(A) : typeof(P);
    foreach (string key in Keys) {
      var expected = kind.GetField(key, Static).GetValue(null);
      Same(Window.FindResource(key), expected, "settings resource scope: " + key);
      Same(Application.Current.Resources[key], typeof(P).GetField(key, Static).GetValue(null), "application retains legacy resource: " + key);
    }
    Brush ink = preview ? A.Ink : P.Ink;
    Paint(Field<TextBox>("ProviderBox").Foreground, ink, "provider effective foreground follows scoped sealed style");
    Paint(Field<TextBox>("ProviderBox").Background, preview ? A.Surface : P.Surface, "provider effective surface follows scoped sealed style");
    Paint(Field<CheckBox>("EnabledBox").Foreground, ink, "checkbox follows scoped foreground");
    Paint(Field<ComboBox>("TriggerBox").Foreground, ink, "combo follows scoped foreground");
    Paint(Field<LanguagePicker>("LanguageBox").Foreground, ink, "derived language button follows scoped foreground");
    if (preview) {
      var shell = Window.Content as Visuals.WindowShell; Check(shell != null, "preview owns a shadow-safe shell");
      Same(shell.Face.Background, A.Surface, "preview shell uses shared surface"); Same(shell.Face.BorderBrush, A.Line, "preview shell uses shared line");
      Same(Window.Foreground, A.Ink, "preview overrides legacy WindowBase foreground locally");
      Near(shell.Margin.Left, 10, "preview shell gutter");
      Paint(Field<Button>("SaveButton").Background, A.Accent, "save remains terracotta"); Paint(Field<Button>("SaveButton").Foreground, Brushes.White, "save text remains white");
      Field<Button>("SaveButton").ApplyTemplate();
      var chrome = (Border)Field<Button>("SaveButton").Template.FindName("chrome", Field<Button>("SaveButton"));
      Near(chrome.CornerRadius.TopLeft, 8, "preview button radius");
      var provider = Field<TextBox>("ProviderBox"); provider.ApplyTemplate();
      Check(provider.Template.FindName("PART_ContentHost", provider) != null, "rounded textbox retains editing content host");
      Same(Field<LanguagePicker>("LanguageBox").Style, Window.FindResource(typeof(Button)), "language trigger uses scoped derived button style");
      var checkbox = Field<CheckBox>("EnabledBox"); checkbox.ApplyTemplate();
      var box = (Border)checkbox.Template.FindName("box", checkbox); Check(box != null, "preview checkbox uses local rounded template");
      Paint(box.BorderBrush, A.Line, "unchecked checkbox line follows theme");
      foreach (TextBox prompt in Prompts.Values) Paint(prompt.Foreground, A.Ink, "prompt effective ink follows theme");
      NoEffectsAboveText((DependencyObject)Window.Content);
    } else {
      Same(Window.Background, P.Surface, "legacy settings background unchanged"); Check(Window.Content is DockPanel, "legacy settings retains original dock layout");
      Check(Window.WindowStyle == WindowStyle.SingleBorderWindow && !Window.AllowsTransparency, "legacy native titlebar unchanged");
      Paint(Field<Button>("SaveButton").Background, P.Hover, "legacy save background unchanged");
    }
  }
  static void NoEffectsAboveText(DependencyObject root) {
    if (root is TextBlock || root is TextBox) {
      for (DependencyObject p = root; p != null; p = VisualTreeHelper.GetParent(p)) {
        var element = p as UIElement; Check(element == null || element.Effect == null, "no effect above settings text");
      }
    }
    for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++) NoEffectsAboveText(VisualTreeHelper.GetChild(root, i));
  }
  static void Tab(int index) {
    Call("Handle", new Dictionary<string, object> { { "type", "demo-settings-tab" }, { "index", index } });
    Drain(); Window.UpdateLayout(); Check(Tabs.SelectedIndex == index, "demo settings tab selects " + index); TabCases++;
    var scroll = ((TabItem)Tabs.Items[index]).Content as ScrollViewer;
    Check(scroll != null && scroll.ActualHeight > 100 && scroll.ActualWidth > 250, "selected tab retains a usable scrolling viewport");
    if (P.ClaudePreview) {
      var tab = (TabItem)Tabs.Items[index]; tab.ApplyTemplate();
      var border = (Border)tab.Template.FindName("tab", tab);
      Paint(border.Background, A.Tint, "selected tab background follows scoped tint"); Paint(tab.Foreground, A.Accent, "selected tab foreground follows scoped accent");
    }
  }
  static void Reach(FrameworkElement control, ScrollViewer scroll) {
    control.BringIntoView(); Drain(); Window.UpdateLayout();
    // Legacy keeps its stock 12pt checkbox (~15.1 DIP on this machine); only
    // the preview promises a 26 DIP minimum. Do not restyle legacy to satisfy a
    // new preview-size assumption, or change any existing regression fixture.
    double minimumHeight = control is CheckBox ? (P.ClaudePreview ? 26 : 14) : 17;
    // UseLayoutRounding can report 25.6 for a 26 DIP control at 125% DPI.
    Check(control.IsVisible && control.ActualHeight + 0.51 >= minimumHeight && control.ActualWidth + 0.51 >= 17, "control is present and has an accessible hit area: " + control.GetType().Name + " preview=" + P.ClaudePreview + " visible=" + control.IsVisible + " size=" + control.ActualWidth + "x" + control.ActualHeight);
    Rect bounds = control.TransformToAncestor(scroll).TransformBounds(new Rect(new Point(), control.RenderSize));
    Check(bounds.Left >= -1 && bounds.Right <= scroll.ActualWidth + 1 && bounds.Top >= -1 && bounds.Bottom <= scroll.ActualHeight + 1, "control can scroll fully into view: " + control.GetType().Name + " " + bounds + " viewport=" + scroll.ActualWidth + "x" + scroll.ActualHeight);
    if (P.ClaudePreview) Check(!string.IsNullOrEmpty(AutomationProperties.GetName(control)), "preview control retains an accessible name");
    ReachabilityCases++;
  }
  static void AllControlsReachable() {
    var controls = new FrameworkElement[][] {
      new FrameworkElement[] { Field<CheckBox>("EnabledBox"), Field<ComboBox>("TriggerBox"), Field<LanguagePicker>("LanguageBox"), Field<ComboBox>("ThemeBox"), Field<ComboBox>("QuickHotkeyBox"), Field<ComboBox>("ModelBox"), Field<TextBox>("ProviderBox"), Field<TextBox>("ModelIdBox") },
      new FrameworkElement[] { Prompts["translate"], Prompts["explain"], Prompts["summarize"] },
      new FrameworkElement[] { Field<CheckBox>("ClipboardBox"), Field<TextBox>("BlockedBox") }
    };
    for (int index = 0; index < 3; index++) {
      Tab(index); var scroll = (ScrollViewer)((TabItem)Tabs.Items[index]).Content;
      foreach (var control in controls[index]) Reach(control, scroll);
    }
    var save = Field<Button>("SaveButton");
    Rect bounds = save.TransformToAncestor(Window).TransformBounds(new Rect(new Point(), save.RenderSize));
    Check(bounds.Right <= Window.ActualWidth && bounds.Bottom <= Window.ActualHeight && bounds.Top > 0, "save stays reachable outside scrolling content");
  }
  static void DemoThemeSync() {
    string original = P.Str(P.Config, "theme"); int index = Field<ComboBox>("ThemeBox").SelectedIndex;
    P.Config["theme"] = "dark";
    Call("Handle", new Dictionary<string, object> { { "type", "demo-settings-tab" }, { "index", 0 } });
    Check(Field<ComboBox>("ThemeBox").SelectedIndex == index, "normal demo tab selection preserves unsaved theme selector");
    Call("Handle", new Dictionary<string, object> { { "type", "demo-settings-tab" }, { "index", 0 }, { "syncTheme", true } });
    Check(Field<ComboBox>("ThemeBox").SelectedIndex == 2, "explicit demo capture sync reflects synthetic dark config");
    Set("Demo", false); P.Config["theme"] = "light";
    Call("Handle", new Dictionary<string, object> { { "type", "demo-settings-tab" }, { "index", 1 }, { "syncTheme", true } });
    Check(Tabs.SelectedIndex == 0 && Field<ComboBox>("ThemeBox").SelectedIndex == 2, "demo capture theme sync is inert outside demo");
    Set("Demo", true); P.Config["theme"] = original;
    Call("Handle", new Dictionary<string, object> { { "type", "demo-settings-tab" }, { "index", 0 }, { "syncTheme", true } });
    Check(Field<ComboBox>("ThemeBox").SelectedIndex == index && TakeMessages().Count == 0, "demo sync restores synthetic theme selector without save/read/model messages");
  }
  static void CatalogEdits() {
    var provider = Field<TextBox>("ProviderBox"); var model = Field<TextBox>("ModelIdBox");
    provider.Text = "unsaved-route"; model.Text = "unsaved-model"; Call("PopulateModels");
    Check(provider.Text == "unsaved-route" && model.Text == "unsaved-model", "asynchronous catalog refresh does not wipe unsaved paired edits");
    var box = Field<ComboBox>("ModelBox"); box.SelectedIndex = 2;
    Check(provider.Text == "fixture-other" && model.Text == "fixture-second", "explicit catalog selection still changes route and model together");
    box.SelectedIndex = 0; Check(provider.Text == "" && model.Text == "", "explicit follow-default selection clears both route edits");
    Check(TakeMessages().Count == 0, "catalog population and explicit selection do not save or request a model");
  }
  static void LanguagePopup(bool preview) {
    var language = Field<LanguagePicker>("LanguageBox");
    var popup = ChildField<Popup>(language, "Flyout"); popup.Child.OpacityMask = Brushes.Transparent; popup.PopupAnimation = PopupAnimation.None;
    Tab(0); language.BringIntoView(); Drain(); language.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)); Drain();
    Check(language.IsPopupOpen, "language popup remains functional preview=" + preview + " surface=" + A.Surface.Color + " ownerVisible=" + Window.IsVisible + " controlVisible=" + language.IsVisible + " size=" + language.ActualWidth + "x" + language.ActualHeight);
    var edge = (Border)popup.Child;
    Same(edge.Background, preview ? A.Surface : P.Surface, "language popup retains correct local surface");
    Paint(ChildField<TextBox>(language, "Search").Foreground, preview ? A.Ink : P.Ink, "language search retains correct local ink");
    language.ClosePopup(); Drain(); Check(TakeMessages().Count == 0, "opening/closing language never saves or submits");
  }
  static void SaveExactly() {
    Field<ComboBox>("ThemeBox").SelectedIndex = 2; Field<ComboBox>("QuickHotkeyBox").SelectedIndex = 3;
    Field<CheckBox>("EnabledBox").IsChecked = true; Field<CheckBox>("ClipboardBox").IsChecked = true;
    Field<ComboBox>("TriggerBox").SelectedIndex = 0; Field<LanguagePicker>("LanguageBox").SetValue("Synthetic custom language");
    Field<TextBox>("ProviderBox").Text = "  synthetic-route  "; Field<TextBox>("ModelIdBox").Text = " synthetic-model ";
    Field<TextBox>("BlockedBox").Text = " fixture-one.exe \r\n\n  fixture-two.exe  \n ";
    Prompts["translate"].Text = "Synthetic custom {{targetLanguage}}"; Prompts["explain"].Text = ""; Prompts["summarize"].Text = "Synthetic summary\nsecond line";
    Check(TakeMessages().Count == 0, "editing controls alone emits no settings or model messages");
    Call("SaveSettings"); var messages = TakeMessages();
    Check(messages.Count == 1 && P.Str(messages[0], "type") == "settings-save" && messages[0].Count == 2, "save emits exactly one serialized settings-save");
    var patch = P.Obj(messages[0], "settings");
    var expected = new Dictionary<string, object> {
      { "theme", "dark" }, { "quickHotkey", "none" }, { "enabled", true }, { "clipboardFallback", true }, { "trigger", "auto" },
      { "targetLanguage", "Synthetic custom language" }, { "provider", "synthetic-route" }, { "model", "synthetic-model" },
      { "blockedApps", new string[] { "fixture-one.exe", "fixture-two.exe" } },
      { "prompts", new Dictionary<string, object> { { "translate", "Synthetic custom {{targetLanguage}}" }, { "explain", "" }, { "summarize", "Synthetic summary\nsecond line" } } }
    };
    Check(patch != null && patch.Count == expected.Count, "save payload contains all and only the original fields");
    foreach (var pair in expected) Check(patch.ContainsKey(pair.Key) && Json.Serialize(patch[pair.Key]) == Json.Serialize(pair.Value), "exact save value: " + pair.Key);
    Check(Field<TextBlock>("SettingsStatus").Text == "正在保存…" && !Field<Button>("SaveButton").IsEnabled, "save retains status and pending-button semantics");
    Saves.Add(patch);
  }
  static void Closed() {
    Window.Close(); Drain(); Check(Window == null && Tabs == null && Field<TextBlock>("SettingsStatus") == null && Field<Button>("SaveButton") == null && Field<ComboBox>("ModelBox") == null && Prompts.Count == 0, "close clears settings references and prompt editors");
    Check(TakeMessages().Count == 0, "close/cancel does not auto-save");
  }
  [STAThread] public static int Main() {
    TextWriter stdout = Console.Out; Console.SetOut(Messages);
    try {
      var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown }; Set("App", app); Set("Demo", true);
      Call("SetupStyles"); Set("Models", Catalog());
      EventManager.RegisterClassHandler(typeof(Window), FrameworkElement.LoadedEvent, new RoutedEventHandler(delegate(object sender, RoutedEventArgs args) {
        var window = sender as Window;
        if (window != null && window.Title == "DSH 划词助手 · 设置") {
          ((UIElement)window.Content).OpacityMask = Brushes.Transparent; window.ShowInTaskbar = false; window.Topmost = false; window.Left = -10000; window.Top = -10000;
        }
      }));
      var legacyButton = Application.Current.Resources[typeof(Button)]; var legacyTextbox = Application.Current.Resources[typeof(TextBox)];
      for (int mode = 0; mode < 2; mode++) {
        bool preview = mode == 1; P.Config = Config(); string originalConfig = Json.Serialize(P.Config); P.ClaudePreview = preview;
        Apply(false); P.ShowSettings(); Drain(); OnlyRead();
        Check(Window.IsVisible && ((UIElement)Window.Content).OpacityMask == Brushes.Transparent, "fixture settings masked before first render");
        Near(Window.Width, preview ? 600 : 560, "default width"); Near(Window.Height, preview ? 660 : 620, "default height");
        Near(Window.MinWidth, preview ? 480 : 440, "minimum width"); Near(Window.MinHeight, preview ? 500 : 480, "minimum height");
        Check(Tabs.Items.Count == 3, "all three functional tabs retained"); InitialValues();
        string initial = Values(); object content = Window.Content; object style = Field<TextBox>("ProviderBox").Style;
        P.ShowSettings(); Drain(); OnlyRead(); Same(Window.Content, content, "repeat open reuses existing settings window");
        for (int pass = 0; pass < 3; pass++) {
          Apply(pass == 1); Palette(preview); LanguagePopup(preview);
          for (int tab = 0; tab < 3; tab++) Tab(tab);
          Check(Values() == initial, "theme/tab transitions preserve every initial control value");
          Same(Window.Content, content, "theme transitions keep window content"); Same(Field<TextBox>("ProviderBox").Style, style, "theme transitions keep sealed textbox style");
          Check(TakeMessages().Count == 0, "theme/tab transitions never read/save/request");
        }
        Window.Width = Window.MinWidth; Window.Height = Window.MinHeight; Drain(); Window.UpdateLayout(); AllControlsReachable();
        Set("Demo", false); int selected = Tabs.SelectedIndex;
        Call("Handle", new Dictionary<string, object> { { "type", "demo-settings-tab" }, { "index", 0 } });
        Check(Tabs.SelectedIndex == selected && TakeMessages().Count == 0, "demo tab command is inert outside demo"); Set("Demo", true);
        DemoThemeSync(); CatalogEdits(); SaveExactly(); Check(Json.Serialize(P.Config) == originalConfig, "editing/save does not mutate configuration before host response");
        Closed(); Apply(true); P.ShowSettings(); Drain(); OnlyRead(); InitialValues(); Palette(preview);
        Near(Window.Width, preview ? 600 : 560, "reopened default width"); Near(Window.Height, preview ? 660 : 620, "reopened default height");
        Closed();
        P.Config = new Dictionary<string, object>(); Apply(false); P.ShowSettings(); Drain(); OnlyRead(); DefaultValues(); Closed();
        Same(Application.Current.Resources[typeof(Button)], legacyButton, "application button style remains unchanged"); Same(Application.Current.Resources[typeof(TextBox)], legacyTextbox, "application textbox style remains unchanged");
      }
      Check(Field<object>("Tray") == null && Field<object>("HotkeyWindow") == null && Field<object>("Appearance") == null && P.Preferences == null, "fixture never initializes tray, hotkeys, watcher, or preferences");
      stdout.WriteLine(Json.Serialize(new { result = "passed", checks = Checks, tabCases = TabCases, reachabilityCases = ReachabilityCases, syntheticSaves = Saves,
        themeSequence = new string[] { "light", "dark", "light" }, clipboardAccess = false, modelRequests = false, realSettingsReads = false, preferencesWritten = false }));
      return 0;
    } catch (Exception error) { Console.Error.WriteLine(error.ToString()); return 1; }
    finally { P.Closing = true; if (Window != null) Window.Close(); Console.SetOut(stdout); }
  }
}
`, 'utf8');

const framework = join(process.env.WINDIR || 'C:\\Windows', 'Microsoft.NET', 'Framework64', 'v4.0.30319');
const references = ['System.dll', 'System.Core.dll', 'System.Xaml.dll', 'System.Web.Extensions.dll', 'System.Drawing.dll', 'System.Windows.Forms.dll', 'WPF/WindowsBase.dll', 'WPF/PresentationCore.dll', 'WPF/PresentationFramework.dll', 'WPF/UIAutomationClient.dll', 'WPF/UIAutomationTypes.dll'];
const run = (file, args) => new Promise((accept, reject) => {
  const child = spawn(file, args, { windowsHide: true, env: helperEnvironment(), stdio: ['ignore', 'pipe', 'pipe'] });
  let stdout = '', stderr = '', timedOut = false;
  child.stdout.on('data', chunk => stdout += chunk);
  child.stderr.on('data', chunk => stderr += chunk);
  const timer = setTimeout(() => { timedOut = true; child.kill(); }, 30000);
  child.once('error', error => { clearTimeout(timer); reject(error); });
  child.once('close', code => {
    clearTimeout(timer);
    if (timedOut) reject(new Error('Settings preview verification timed out'));
    else if (code === 0) accept(stdout);
    else reject(new Error(stderr || stdout || `Exited ${code}`));
  });
});
try {
  const sources = (await readdir(join(root, 'native'))).filter(name => name.endsWith('.cs')).sort().map(name => join(root, 'native', name));
  await run(join(framework, 'csc.exe'), ['/nologo', '/target:exe', '/main:SettingsPreviewVerification', '/utf8output', `/out:${executable}`, `/win32manifest:${join(root, 'native', 'app.manifest')}`, ...references.map(path => `/reference:${join(framework, path)}`), ...sources, source]);
  await copyFile(join(root, 'native', 'app.config'), executable + '.config');
  const result = JSON.parse((await run(executable, [])).trim());
  assert.equal(result.result, 'passed');
  assert.equal(result.syntheticSaves.length, 2);
  assert.deepEqual(result.syntheticSaves[0], result.syntheticSaves[1], 'preview and legacy save payloads must be identical');
  assert.equal(result.reachabilityCases, 26);
  await writeFile(join(output, 'result.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify({ ...result, report: join(output, 'result.json') }, null, 2));
} catch (error) {
  await writeFile(join(output, 'failure.txt'), String(error.stack || error) + '\n');
  throw error;
}
