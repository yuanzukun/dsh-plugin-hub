import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdir, readdir, writeFile, copyFile } from 'node:fs/promises';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { helperEnvironment } from '../src/environment.js';

// Lead's independent functional review of the Opus UI. No Program.Main, tray
// visibility, hotkey registration, clipboard, provider, profile or user prefs.
if (process.platform !== 'win32') throw new Error('Paper review requires Windows');
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = join(root, '.local', 'paper-review-' + Date.now());
await mkdir(output, { recursive: true });
const source = join(output, 'PaperReview.cs'), exe = join(output, 'PaperReview.exe');
await writeFile(source, String.raw`
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Threading;
using DshSelectionAssistant;
using P = DshSelectionAssistant.Program;
using Forms = System.Windows.Forms;

internal static class PaperReview {
  const BindingFlags Flags = BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
  static int Checks;
  static readonly StringWriter Messages = new StringWriter();
  static T Field<T>(object obj, string key) { return (T)(obj == null ? typeof(P) : obj.GetType()).GetField(key, Flags).GetValue(obj); }
  static void Set(object obj, string key, object value) { (obj == null ? typeof(P) : obj.GetType()).GetField(key, Flags).SetValue(obj, value); }
  static object Call(object obj, string key, params object[] args) { return (obj == null ? typeof(P) : obj.GetType()).GetMethod(key, Flags).Invoke(obj, args); }
  static void Check(bool pass, string note) { Checks++; if (!pass) throw new Exception(note); }
  static void Drain() { Dispatcher.CurrentDispatcher.Invoke(DispatcherPriority.ApplicationIdle, new Action(delegate {})); }
  static void Show(TranslationWindow panel) {
    panel.Window.Left = -10000; panel.Window.Top = -10000; panel.Window.ShowInTaskbar = false; panel.Window.ShowActivated = false;
    ((UIElement)panel.Window.Content).OpacityMask = Brushes.Transparent;
    panel.Window.Show(); panel.Window.UpdateLayout(); Drain();
  }
  static Dictionary<string, object> Config() { return new Dictionary<string, object> { {"enabled", false}, {"theme", "light"}, {"targetLanguage", "auto"}, {"fontSize", 15}, {"maxChars", 12000} }; }
  static void Frame(Dictionary<string, object> config) { Call(null, "Handle", new Dictionary<string, object> { {"type", "settings"}, {"settings", config} }); }
  static Dictionary<string, object> LastSave() {
    var json = new JavaScriptSerializer(); Dictionary<string, object> result = null;
    foreach (string line in Messages.ToString().Split(new char[] {'\r','\n'}, StringSplitOptions.RemoveEmptyEntries)) {
      var value = json.DeserializeObject(line) as Dictionary<string, object>;
      if (value != null && P.Str(value, "type") == "settings-save") result = P.Obj(value, "settings");
    }
    Check(result != null, "save emits actual protocol patch"); return result;
  }
  static double Luminance(Color c) {
    Func<byte,double> f = delegate(byte b) { double n=b/255.0; return n<=0.04045 ? n/12.92 : Math.Pow((n+0.055)/1.055,2.4); };
    return 0.2126*f(c.R)+0.7152*f(c.G)+0.0722*f(c.B);
  }
  static double Contrast(SolidColorBrush a, SolidColorBrush b) { double x=Luminance(a.Color),y=Luminance(b.Color); return (Math.Max(x,y)+0.05)/(Math.Min(x,y)+0.05); }
  static void SettingsAcknowledgement() {
    Set(null,"SettingsStatus",new TextBlock { Text="" }); Set(null,"SaveButton",new Button());
    Set(null,"ThemeBox",P.Combo("system","light","dark")); Field<ComboBox>(null,"ThemeBox").SelectedIndex=1;
    Set(null,"QuickHotkeyBox",P.Combo("Ctrl+Alt+T","Ctrl+Shift+T","Alt+Shift+T","none"));
    Set(null,"EnabledBox",new CheckBox { IsChecked=true }); Set(null,"ClipboardBox",new CheckBox { IsChecked=false });
    Set(null,"TriggerBox",P.Combo("auto","hotkey"));
    var language=new LanguagePicker(); language.SetValue("auto"); Set(null,"LanguageBox",language);
    Set(null,"ProviderBox",new TextBox { Text="review-provider" }); Set(null,"ModelIdBox",new TextBox { Text="review-model" });
    Set(null,"BlockedBox",new TextBox { Text=" A.exe\nA.exe\nb.exe " });
    var prompts=Field<Dictionary<string,TextBox>>(null,"PromptBoxes"); prompts.Clear();
    prompts["translate"]=new TextBox { Text="Synthetic {{targetLanguage}}" }; prompts["explain"]=new TextBox { Text="" }; prompts["summarize"]=new TextBox { Text="Synthetic summary" };
    Frame(Config()); Check(Field<TextBlock>(null,"SettingsStatus").Text=="", "read-only refresh never reports saved");
    Call(null,"SaveSettings"); var patch=LastSave();
    Check(Field<bool>(null,"SavePending"),"save begins a pending acknowledgement");
    Check(!Field<Button>(null,"SaveButton").IsEnabled,"save disabled while pending");
    Frame(Config()); Check(Field<bool>(null,"SavePending"),"unrelated GET cannot acknowledge save");
    Check(Field<TextBlock>(null,"SettingsStatus").Text=="正在保存…", "unrelated GET retains saving state");
    Check(!Field<Button>(null,"SaveButton").IsEnabled,"unrelated GET cannot re-enable concurrent save");
    var json=new JavaScriptSerializer(); var ack=(Dictionary<string,object>)json.DeserializeObject(json.Serialize(patch));
    ack["blockedApps"]=new object[] {"A.exe","b.exe"}; ack["maxChars"]=12000;
    Check(P.SettingsMatchPatch(ack,ack),"exact full snapshot matches");
    Frame(ack); Check(!Field<bool>(null,"SavePending"),"normalized matching values acknowledge save");
    Check(Field<TextBlock>(null,"SettingsStatus").Text.Contains("已保存"),"matching acknowledgement reports saved");
    Check(Field<Button>(null,"SaveButton").IsEnabled,"matching acknowledgement re-enables save");
    Check(((object[])patch["blockedApps"]).Length==3,"outgoing save payload is not silently changed by ack normalization");
    Call(null,"SaveSettings"); Call(null,"Notice","Synthetic save failure");
    Check(!Field<bool>(null,"SavePending") && Field<object>(null,"PendingSettingsPatch")==null,"failure clears pending snapshot");
    Frame(ack); Check(Field<TextBlock>(null,"SettingsStatus").Text=="Synthetic save failure","later refresh cannot turn a failed save into success");
    Call(null,"SaveSettings"); Call(null,"ClearPendingSave");
    Check(Field<object>(null,"PendingSettingsPatch")==null,"close/reset releases pending snapshot");
    P.Config=Config();
  }
  static KeyEventArgs Escape(FrameworkElement target) {
    var e=new KeyEventArgs(Keyboard.PrimaryDevice,PresentationSource.FromVisual(target),0,Key.Escape) { RoutedEvent=Keyboard.PreviewKeyDownEvent };
    target.RaiseEvent(e); Drain(); return e;
  }
  static void PopupPriority(TranslationWindow panel) {
    var input=Field<TextBox>(panel,"Input"); var language=Field<LanguagePicker>(panel,"Language"); var opacity=Field<OpacityControl>(panel,"Transparency");
    var lp=Field<Popup>(language,"Flyout"); var op=Field<Popup>(opacity,"Flyout");
    ((UIElement)lp.Child).OpacityMask=Brushes.Transparent; ((UIElement)op.Child).OpacityMask=Brushes.Transparent;
    for(int kind=0;kind<2;kind++) {
      FrameworkElement[] targets=kind==0 ? new FrameworkElement[] {Field<TextBox>(language,"Search"),language,input} : new FrameworkElement[] {Field<Slider>(opacity,"Slider"),opacity.Button,input};
      foreach(var target in targets) {
        Show(panel); panel.StopRun(); var trigger=kind==0 ? (Button)language : opacity.Button;
        trigger.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)); Drain();
        Check(kind==0 ? language.IsPopupOpen : opacity.IsPopupOpen,"Paper flyout actually opens");
        panel.RunId="paper-popup"; panel.Busy=true;
        Check(Escape(target).Handled && !language.IsPopupOpen && !opacity.IsPopupOpen,"first Esc only dismisses Paper flyout");
        Check(panel.Busy && panel.RunId=="paper-popup" && panel.Window.IsVisible,"popup Esc preserves in-flight run");
        Check(Escape(input).Handled && !panel.Busy && panel.RunId==null && panel.Window.IsVisible,"second Esc stops but does not close");
        Check(Escape(input).Handled && !panel.Window.IsVisible,"idle Esc closes Paper window");
      }
    }
  }
  static void ActualSettingsView() {
    var config=Config(); config["provider"]="view-provider"; config["model"]="view-model";
    config["targetLanguage"]="French"; config["blockedApps"]=new object[] {"fixture.exe"};
    config["prompts"]=new Dictionary<string,object> {{"translate","T {{targetLanguage}}"},{"explain","E"},{"summarize","S"}};
    P.Config=config;
    EventManager.RegisterClassHandler(typeof(Window),FrameworkElement.LoadedEvent,new RoutedEventHandler(delegate(object sender,RoutedEventArgs e) {
      var w=sender as Window; if(w==null)return; w.Opacity=0; w.ShowInTaskbar=false; w.Left=-10000; w.Top=-10000;
    }));
    P.ShowSettings(); Drain(); var window=Field<Window>(null,"Settings"); var tabs=Field<TabControl>(null,"SettingsTabs");
    Check(window!=null && tabs.Items.Count==4,"actual Paper settings builds all four pages");
    for(int i=0;i<4;i++) { tabs.SelectedIndex=i; window.UpdateLayout(); Drain(); Check(tabs.SelectedContent!=null && ((FrameworkElement)tabs.SelectedContent).ActualHeight>0,"actual Paper page is reachable: "+i); }
    Check(Field<TextBox>(null,"ProviderBox").Text=="view-provider" && Field<TextBox>(null,"ModelIdBox").Text=="view-model","actual model controls retain configured route");
    Check(Field<LanguagePicker>(null,"LanguageBox").Value=="French","actual language field retains configured value");
    var prompts=Field<Dictionary<string,TextBox>>(null,"PromptBoxes"); Check(prompts.Count==3 && prompts["explain"].Text=="E" && prompts["summarize"].Text=="S","segmented prompt UI retains all three editors");
    Field<Button>(null,"SaveButton").RaiseEvent(new RoutedEventArgs(Button.ClickEvent)); var saved=LastSave();
    Check(P.Str(saved,"provider")=="view-provider" && P.Str(saved,"model")=="view-model" && P.Str(saved,"targetLanguage")=="French","actual Paper save button emits preserved values");
    Check(P.Str(P.Obj(saved,"prompts"),"translate")=="T {{targetLanguage}}","actual Paper save includes prompt editor content");
    window.Close(); Drain(); Check(Field<Window>(null,"Settings")==null && !Field<bool>(null,"SavePending") && Field<object>(null,"PendingSettingsPatch")==null,"closing actual settings clears save acknowledgement state");
  }
  static void MarkdownSafety() {
    foreach(string text in new string[] { "3. third\n4. fourth", "0. zero", "١. Arabic digit", "1000. literal", "999. last", new string((char)96,3)+"\n\n<unsafe>\n"+new string((char)96,3), "# Heading\n\n<script>not executable</script>\n[link](https://invalid.example)" }) {
      var doc=MarkdownView.Render(text,15); Check(doc!=null,"untrusted Markdown safely renders: "+text.Substring(0,Math.Min(12,text.Length)));
    }
    var ordered=MarkdownView.Render("3. third\n4. fourth",15).Blocks.FirstBlock as List;
    Check(ordered!=null && ordered.StartIndex==3,"ordered list preserves original starting number");
    var markup=MarkdownView.Render("<script>x</script>\n[link](https://invalid.example)",15);
    string plain=new TextRange(markup.ContentStart,markup.ContentEnd).Text;
    Check(plain.Contains("<script>x</script>") && plain.Contains("[link]"),"HTML and links remain literal inert text");
  }
  [STAThread] static int Main() {
    TextWriter stdout=Console.Out; TranslationWindow selection=null,quick=null; Forms.NotifyIcon tray=null;
    try {
      Console.SetOut(Messages); var app=new Application { ShutdownMode=ShutdownMode.OnExplicitShutdown }; Set(null,"App",app);
      Set(null,"Demo",true); P.ClaudePreview=true; P.Paper=true; P.Config=Config(); Visuals.AnimationsEnabled=false;
      Call(null,"SetupStyles"); Call(null,"ApplyTheme",false);
      Check(P.UsePaperDesign(new string[0]) && P.UsePaperDesign(new string[] {"--state-file","synthetic.json"}),"accepted Paper design is the normal daily default");
      Check(!P.UsePaperDesign(new string[] {"--demo","synthetic-output"}) && !P.UsePaperDesign(new string[] {"--demo","synthetic-output","--claude-preview"}),"archived comparison demos stay explicitly available");
      Check(P.UsePaperDesign(new string[] {"--demo","synthetic-output","--design=paper"}),"explicit isolated Paper startup works");
      MarkdownSafety();
      foreach(bool dark in new bool[] {false,true,false}) {
        Call(null,"ApplyTheme",dark); Drain();
        Check(Contrast(PaperTheme.Ink,PaperTheme.Surface)>=4.5,"reading contrast meets AA");
        Check(Contrast(PaperTheme.Muted,PaperTheme.Surface)>=4.5,"semantic muted text remains readable");
        Check(Contrast(PaperTheme.OnAccent,PaperTheme.AccentStrong)>=4.5,"primary button text meets AA");
      }
      selection=new TranslationWindow("selection"); quick=new TranslationWindow("quick"); Show(selection); Show(quick);
      Check(selection.Paper && quick.Paper,"both Paper surfaces actually constructed");
      foreach(bool dark in new bool[] {true,false}) {
        Call(null,"ApplyTheme",dark); Drain();
        Check(((SolidColorBrush)Field<TextBox>(quick,"Input").Foreground).Color==PaperTheme.Ink.Color,"existing Paper editor follows live theme");
        Check(((SolidColorBrush)Field<RichTextBox>(selection,"Result").Foreground).Color==PaperTheme.Ink.Color,"existing Paper result follows live theme");
      }
      var input=Field<TextBox>(quick,"Input"); quick.DemoInput("alpha beta"); input.AppendText(" gamma"); input.Select(2,4);
      string previous=input.Text; bool undo=input.CanUndo; quick.DemoResize(440,400); Drain();
      Check(Object.ReferenceEquals(input,Field<TextBox>(quick,"Input")),"responsive stacking reuses editor instance");
      Check(input.Text==previous && input.SelectionStart==2 && input.SelectionLength==4,"responsive layout retains text/caret selection");
      Check(input.CanUndo==undo,"responsive layout retains undo state");
      Check(input.ActualHeight>=40 && Field<RichTextBox>(quick,"Result").ActualHeight>=40,"compact stacked view retains both viewports");
      var source=Field<TextBox>(selection,"Input"); var longSource=new StringBuilder(); for(int i=0;i<120;i++)longSource.AppendLine("Synthetic full source row "+i);
      selection.DemoInput(longSource.ToString()); selection.DemoSource(); selection.Window.UpdateLayout(); Drain();
      Check(double.IsPositiveInfinity(source.MaxHeight) && source.VerticalScrollBarVisibility==ScrollBarVisibility.Disabled,"source does not create a clipped nested scrolling area");
      var view=Field<PaperTranslationView>(selection,"View"); var scroll=view.Scroller;
      Check(scroll!=null && scroll.ScrollableHeight>0,"full expanded source participates in outer scrolling");
      Check(source.Text.Contains("source row 119") && source.ActualHeight>scroll.ViewportHeight,"last source rows remain laid out rather than truncated");
      selection.DemoSource();
      var buffer=Field<StringBuilder>(selection,"Buffer"); buffer.Clear(); for(int i=0;i<100;i++)buffer.AppendLine("Synthetic output row "+i);
      Call(selection,"Paint",false); selection.Window.UpdateLayout(); Drain(); scroll.ScrollToEnd(); Drain();
      Check(scroll.ScrollableHeight>0 && scroll.VerticalOffset>0,"long result uses real outer scroll extent");
      scroll.ScrollToTop(); Drain(); buffer.AppendLine("new frame while user reads top"); Call(selection,"Paint",false); Drain();
      Check(scroll.VerticalOffset<1,"streaming does not yank a reader back to bottom");
      scroll.ScrollToEnd(); Drain(); buffer.AppendLine("following frame at bottom"); Call(selection,"Paint",false); Drain();
      Check(scroll.VerticalOffset+scroll.ViewportHeight>=scroll.ExtentHeight-2,"streaming follows only when already at bottom");
      quick.Clear(); quick.DemoInput("Synthetic manual input"); quick.Submit(); string pending=Field<string>(quick,"PendingId");
      Check(!string.IsNullOrEmpty(pending),"manual submit owns a pending ID"); quick.StopRun();
      Check(Field<string>(quick,"PendingId")==null && quick.RunId==null && !quick.Busy,"stop cancels an awaiting request");
      Check(Field<TextBlock>(quick,"Status").Text=="已停止","awaiting stop is represented honestly");
      quick.Receive(new Dictionary<string,object> {{"type","delta"},{"id",pending},{"text","MUST_NOT_APPEAR"}});
      Check(!quick.Answer.Contains("MUST_NOT_APPEAR"),"late frames cannot revive awaiting cancellation");
      quick.Close(); quick.Begin(new Dictionary<string,object> {{"id",pending},{"source","manual"},{"text","late"}});
      Check(!quick.Window.IsVisible,"late manual begin cannot reopen closed input");
      PopupPriority(quick); PopupPriority(selection);
      tray=new Forms.NotifyIcon {Visible=false}; Set(null,"Tray",tray); Set(null,"ToggleItem",new Forms.ToolStripMenuItem());
      SettingsAcknowledgement(); ActualSettingsView();
      Console.SetOut(stdout); Console.WriteLine(new JavaScriptSerializer().Serialize(new {result="passed",checks=Checks,clipboardAccess=false,modelRequests=false,realSettingsReads=false,preferencesWritten=false})); return 0;
    } catch(Exception error) { Console.SetOut(stdout); Console.Error.WriteLine(error.ToString()); return 1; }
    finally { P.Closing=true; if(selection!=null)selection.Window.Close(); if(quick!=null)quick.Window.Close(); if(tray!=null)tray.Dispose(); }
  }
}
`, 'utf8');
const framework=join(process.env.WINDIR || 'C:\\Windows','Microsoft.NET','Framework64','v4.0.30319');
const refs=['System.dll','System.Core.dll','System.Xaml.dll','System.Web.Extensions.dll','System.Drawing.dll','System.Windows.Forms.dll','WPF/WindowsBase.dll','WPF/PresentationCore.dll','WPF/PresentationFramework.dll','WPF/UIAutomationClient.dll','WPF/UIAutomationTypes.dll'];
const run=(file,args)=>new Promise((resolve,reject)=>{
  const child=spawn(file,args,{windowsHide:true,env:helperEnvironment(),stdio:['ignore','pipe','pipe']}); let text='',error='';
  child.stdout.on('data',b=>text+=b.toString()); child.stderr.on('data',b=>error+=b.toString());
  const timer=setTimeout(()=>{child.kill();reject(new Error('Paper review timed out'));},30000);
  child.once('error',e=>{clearTimeout(timer);reject(e);}); child.once('exit',code=>{clearTimeout(timer);code===0?resolve(text):reject(new Error(error||text||'Exit '+code));});
});
try {
  const files=(await readdir(join(root,'native'))).filter(n=>n.endsWith('.cs')).sort().map(n=>join(root,'native',n));
  await run(join(framework,'csc.exe'),['/nologo','/target:exe','/main:PaperReview','/utf8output','/out:'+exe,'/win32manifest:'+join(root,'native','app.manifest'),...refs.map(r=>'/reference:'+join(framework,r)),...files,source]);
  await copyFile(join(root,'native','app.config'),exe+'.config');
  const result=JSON.parse((await run(exe,[])).trim()); assert.equal(result.result,'passed');
  await writeFile(join(output,'result.json'),JSON.stringify(result,null,2)+'\n'); console.log(JSON.stringify({...result,report:join(output,'result.json')},null,2));
} catch(error) { await writeFile(join(output,'failure.txt'),String(error.stack||error)); throw error; }
