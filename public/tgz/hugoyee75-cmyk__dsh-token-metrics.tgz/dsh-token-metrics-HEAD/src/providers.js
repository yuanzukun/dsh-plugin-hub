import { existsSync, readdirSync, readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { createRequire } from 'node:module'
import { homedir as homedirPath } from 'node:os'

/**
 * 官方平台的余额与配额查询。
 *
 * 与 `balance.js` 里那套「中转站通用探测」不同：官方平台的接口各不相同，
 * 响应结构也没有统一标准，只能一家一个适配器。
 *
 * 两类结果：
 *
 *  1. **余额型**（DeepSeek / OpenRouter / SiliconFlow / Novita）
 *     给一个美元数额，页面显示 `余额 $12.34`。
 *
 *  2. **配额型**（Kimi / GLM 的 Coding Plan）
 *     给若干「时间窗口 + 已用/上限」，页面画进度条并显示重置时间，
 *     例如 `5-hour 40% used  2h 后重置`。
 *
 * 设计约束：不抛异常。查询失败只返回 `{ ok:false, error }`，
 * 因为余额是辅助信息，不该让整个页面挂掉。
 */

/** 平台识别：按 baseURL 的主机名匹配。顺序重要，更具体的放前面。 */
const HOST_PATTERNS = [
  { id: 'deepseek', test: /(^|\.)api\.deepseek\.com$/ },
  { id: 'kimi', test: /(^|\.)api\.kimi\.com$/ },
  { id: 'glm', test: /(^|\.)(open\.bigmodel\.cn|api\.z\.ai)$/ },
  { id: 'minimax', test: /(^|\.)api\.minimax\.(io|chat)$/ },
  { id: 'openrouter', test: /(^|\.)openrouter\.ai$/ },
  { id: 'siliconflow', test: /(^|\.)api\.siliconflow\.(cn|com)$/ },
  { id: 'novita', test: /(^|\.)api\.novita\.ai$/ },
  { id: 'stepfun', test: /(^|\.)api\.stepfun\.(ai|com)$/ },
  // 火山方舟（豆包）：余额在 /api/v3/billing/balance，需 AK/SK 或 API Key
  { id: 'volcano', test: /(^|\.)ark\.cn-beijing\.volces\.com$/ },
  // 阿里百炼（通义千问）：官方没有公开的余额接口，只识别以便给出准确说明
  { id: 'qwen', test: /(^|\.)dashscope(-intl)?\.aliyuncs\.com$/ },
  // 小米 MiMo：api 与 token-plan 两个域名。余额接口实测全部 404，
  // 识别它们是为了给出准确提示，而不是让用户对着 404 猜。
  { id: 'mimo', test: /(^|\.)(api|token-plan-cn)\.xiaomimimo\.com$/ },
  { id: 'anthropic', test: /(^|\.)api\.anthropic\.com$/ },
  { id: 'openai', test: /(^|\.)api\.openai\.com$/ },
  // 下面两个能识别但**不支持查询**，识别它们只是为了给出准确说明，
  // 而不是让用户对着一个含糊的 404 猜。
  // ChatGPT 订阅额度绑定在账号 OAuth token 上，API key 请求会返回 403；
  // Gemini 没有公开的配额接口。
  { id: 'codex', test: /(^|\.)(chatgpt\.com|chat\.openai\.com)$/ },
  { id: 'gemini', test: /(^|\.)(generativelanguage\.googleapis\.com|aistudio\.google\.com)$/ },
]

/**
 * 从 baseURL 识别官方平台。
 *
 * @returns {string|undefined} 平台 id；识别不出返回 undefined（走中转站探测）
 */
export function detectProvider(baseUrl) {
  if (typeof baseUrl !== 'string' || baseUrl === '') return undefined
  let host
  try {
    host = new URL(baseUrl.includes('://') ? baseUrl : `https://${baseUrl}`).hostname
  } catch {
    return undefined
  }
  for (const pattern of HOST_PATTERNS) {
    if (pattern.test.test(host)) return pattern.id
  }
  return undefined
}

/** 各平台的展示名，供页面标注。 */
export const PROVIDER_LABELS = {
  deepseek: 'DeepSeek',
  kimi: 'Kimi (Moonshot)',
  glm: '智谱 GLM',
  minimax: 'MiniMax',
  openrouter: 'OpenRouter',
  siliconflow: 'SiliconFlow',
  novita: 'Novita AI',
  stepfun: '阶跃星辰',
  volcano: '火山方舟（豆包）',
  qwen: '阿里百炼（通义千问）',
  mimo: '小米 MiMo',
  anthropic: 'Anthropic',
  openai: 'OpenAI',
  codex: 'ChatGPT (Codex)',
  gemini: 'Google Gemini',
}

/**
 * 从 pi-ai 的模型目录读取模型能力。
 *
 * 目录文件在 `@earendil-works/pi-ai/dist/providers/data/*.json`，每个模型带：
 *   - `reasoning`：是否推理模型
 *   - `thinkingLevelMap`：支持的思考档位（值为 null 表示该档不支持）
 *   - `contextWindow` / `maxTokens`：容量
 *   - `input`：接受的输入类型（text / image）
 *
 * 这些是权威数据，比让用户逐个手填准确得多，也省掉二次配置。
 *
 * 读取失败不抛异常——目录是可选增强，读不到就返回空映射，页面退回手填。
 */
export function loadModelCatalog({ dataDir, home } = {}) {
  const catalog = {}
  try {
    
    const dir = dataDir ?? findCatalogDir({ home })
    if (dir === null) return catalog
    for (const name of readdirSync(dir)) {
      if (!name.endsWith('.json') || name.startsWith('.')) continue
      let parsed
      try { parsed = JSON.parse(readFileSync(join(dir, name), 'utf8')) } catch { continue }
      // 结构：{ <api>: { 'chat:<id>': { id, reasoning, thinkingLevelMap, ... } } }
      for (const models of Object.values(parsed)) {
        if (models === null || typeof models !== 'object') continue
        for (const entry of Object.values(models)) {
          if (entry === null || typeof entry !== 'object' || typeof entry.id !== 'string') continue
          // 同一个 id 可能在多个 provider 下出现，合并时以「能力更全」的为准
          const existing = catalog[entry.id]
          const info = {
            reasoning: entry.reasoning === true,
            thinkingLevels: levelsFromMap(entry.thinkingLevelMap),
            contextWindow: numberOrUndefined(entry.contextWindow),
            maxTokens: numberOrUndefined(entry.maxTokens),
            input: Array.isArray(entry.input) ? entry.input : undefined,
          }
          catalog[entry.id] = existing === undefined ? info : mergeCapability(existing, info)
        }
      }
    }
  } catch { /* 目录不可读时返回空映射 */ }
  return catalog
}

/** 把 thinkingLevelMap 转成「支持哪些档位」。 */
function levelsFromMap(map) {
  if (map === null || map === undefined || typeof map !== 'object') return undefined
  // 值为 null 表示该档不支持；有非 null 值才算支持。
  // `off` 特殊：值为 'none' 之类也算支持（能关掉推理）。
  return Object.entries(map)
    .filter(([, wire]) => wire !== null && wire !== undefined)
    .map(([level]) => level)
}

/** 合并两个能力信息，取更完整的。 */
function mergeCapability(a, b) {
  return {
    reasoning: a.reasoning || b.reasoning,
    thinkingLevels: a.thinkingLevels ?? b.thinkingLevels,
    contextWindow: a.contextWindow ?? b.contextWindow,
    maxTokens: a.maxTokens ?? b.maxTokens,
    input: a.input ?? b.input,
  }
}

function numberOrUndefined(value) {
  const n = Number(value)
  return Number.isFinite(n) && n > 0 ? n : undefined
}

/**
 * 定位 pi-ai 的模型目录。
 *
 * 不能只靠 `createRequire` 从插件目录解析：pi-ai 装在 DSH profile 的
 * node_modules 下，插件目录里看不到它。所以按优先级依次尝试：
 *   1. 插件自己的解析路径
 *   2. `$DSH_HOME/profiles/<profile>/node_modules/...`
 *   3. `$DSH_HOME/node_modules/...`
 *
 * @param {object} [options]
 * @param {string} [options.home] DSH home，默认读环境变量
 * @returns {string|null}
 */
export function findCatalogDir({ home } = {}) {
  const candidates = []
  try {
    const requireFn = createRequire(import.meta.url)
    for (const spec of ['@earendil-works/pi-ai/package.json', 'pi-ai/package.json']) {
      try {
        candidates.push(join(dirname(requireFn.resolve(spec)), 'dist/providers/data'))
        break
      } catch { /* 换下一个 spec */ }
    }
  } catch { /* 无 createRequire */ }

  const root = home ?? process.env.DSH_HOME ?? join(homedirPath(), '.dsh')
  const rel = 'node_modules/@earendil-works/pi-ai/dist/providers/data'
  const profileName = process.env.DSH_PROFILE
  if (profileName !== undefined && profileName !== '') {
    candidates.push(join(root, 'profiles', profileName, rel))
  }
  // 环境变量没给 profile 时，直接扫 profiles 目录下的每个 profile。
  // 宿主不一定把 DSH_PROFILE 传进来，靠环境变量会漏。
  try {
    const profilesDir = join(root, 'profiles')
    if (existsSync(profilesDir)) {
      for (const name of readdirSync(profilesDir)) {
        const candidate = join(profilesDir, name, rel)
        if (existsSync(candidate)) candidates.push(candidate)
      }
    }
  } catch { /* 没有 profiles 目录 */ }
  candidates.push(join(root, rel))

  for (const candidate of candidates) {
    try { if (existsSync(candidate)) return candidate } catch { /* 继续 */ }
  }
  return null
}

//#region 工具

function num(value) {
  const n = Number(value)
  return Number.isFinite(n) ? n : undefined
}

/** 发一个 GET 并尽力解析 JSON；失败返回 undefined。 */
async function getJson(url, apiKey, fetchImpl, extraHeaders = {}, timeoutMs = 12_000) {
  const controller = typeof AbortController === 'function' ? new AbortController() : undefined
  const timer = controller === undefined ? undefined : setTimeout(() => controller.abort(), timeoutMs)
  try {
    const headers = {
      accept: 'application/json',
      'user-agent': 'dsh-token-metrics',
      ...extraHeaders,
    }
    if (typeof apiKey === 'string' && apiKey !== '') {
      headers.authorization = `Bearer ${apiKey}`
    }
    const response = await fetchImpl(url, { headers, signal: controller?.signal, redirect: 'error' })
    if (!response.ok) return { status: response.status }
    const body = await response.json().catch(() => undefined)
    return { status: response.status, body }
  } catch (error) {
    return { status: 0, error: error?.message ?? String(error) }
  } finally {
    if (timer !== undefined) clearTimeout(timer)
  }
}

/**
 * 把一个「已用 / 上限」窗口归一化成配额条目。
 *
 * `used` 与 `limit` 必须同单位。页面据此算百分比。
 */
function quota(label, used, limit, resetsAt, unit) {
  const usedNum = num(used)
  const limitNum = num(limit)
  if (usedNum === undefined && limitNum === undefined) return undefined
  return {
    label,
    used: usedNum,
    limit: limitNum,
    resetsAt: num(resetsAt),
    unit: typeof unit === 'string' ? unit : undefined,
  }
}

//#endregion

//#region 余额型适配器

/** DeepSeek：/user/balance 返回 balance_infos 数组。 */
async function probeDeepseek({ baseUrl, apiKey, fetchImpl }) {
  const origin = new URL(baseUrl.includes('://') ? baseUrl : `https://${baseUrl}`).origin
  const result = await getJson(`${origin}/user/balance`, apiKey, fetchImpl)
  if (result.body === undefined) {
    return { ok: false, error: result.error ?? `HTTP ${result.status}` }
  }
  const infos = Array.isArray(result.body.balance_infos) ? result.body.balance_infos : []
  // 优先取 USD，其次取第一条（有的账号只有 CNY）
  const usd = infos.find((entry) => String(entry?.currency ?? '').toUpperCase() === 'USD')
  const picked = usd ?? infos[0]
  const total = num(picked?.total_balance)
  if (total === undefined) return { ok: false, error: '响应里没有 total_balance' }
  return {
    ok: true,
    kind: 'balance',
    // 非美元的金额不做换算（汇率因平台而异），标注原始币种
    usd: String(picked?.currency ?? '').toUpperCase() === 'USD' ? total : undefined,
    raw: total,
    currency: String(picked?.currency ?? '').toUpperCase() || undefined,
    isAvailable: result.body.is_available !== false,
  }
}

/** OpenRouter：/api/v1/credits 返回 total_credits / total_usage。 */
async function probeOpenrouter({ baseUrl, apiKey, fetchImpl }) {
  const origin = new URL(baseUrl.includes('://') ? baseUrl : `https://${baseUrl}`).origin
  const result = await getJson(`${origin}/api/v1/credits`, apiKey, fetchImpl)
  const data = result.body?.data ?? result.body
  const total = num(data?.total_credits)
  const used = num(data?.total_usage)
  if (total === undefined) return { ok: false, error: result.error ?? '响应里没有 total_credits' }
  return {
    ok: true,
    kind: 'balance',
    usd: used === undefined ? total : total - used,
    usedUsd: used,
    limitUsd: total,
  }
}

/** SiliconFlow：返回 totalBalance（字符串金额）。 */
async function probeSiliconflow({ baseUrl, apiKey, fetchImpl }) {
  const origin = new URL(baseUrl.includes('://') ? baseUrl : `https://${baseUrl}`).origin
  // 官方接口在 /v1/user/info
  for (const path of ['/v1/user/info', '/user/info']) {
    const result = await getJson(`${origin}${path}`, apiKey, fetchImpl)
    const data = result.body?.data ?? result.body
    const total = num(data?.totalBalance ?? data?.balance)
    if (total !== undefined) {
      return { ok: true, kind: 'balance', usd: total, currency: 'CNY' }
    }
  }
  return { ok: false, error: '没有找到余额字段' }
}

/** Novita：/v1/user/balance 返回 balance_infos 或可用余额。 */
async function probeNovita({ baseUrl, apiKey, fetchImpl }) {
  const origin = new URL(baseUrl.includes('://') ? baseUrl : `https://${baseUrl}`).origin
  // Novita 的余额接口在 v3 下（实测自 CC Switch 的实现）
  for (const path of ['/v3/user/balance', '/v1/user/balance', '/user/balance']) {
    const result = await getJson(`${origin}${path}`, apiKey, fetchImpl)
    const body = result.body
    if (body === undefined) continue
    const infos = Array.isArray(body.balance_infos) ? body.balance_infos : []
    const usd = infos.find((entry) => String(entry?.currency ?? '').toUpperCase() === 'USD')
    const total = num(usd?.total_balance ?? body.balance ?? body.total_balance)
    if (total !== undefined) {
      return {
        ok: true, kind: 'balance',
        usd: usd !== undefined || !infos.length ? total : undefined,
        raw: total,
        currency: usd === undefined && infos.length ? String(infos[0]?.currency ?? '') : 'USD',
      }
    }
  }
  return { ok: false, error: '没有找到余额字段' }
}

/** 阶跃星辰：/v1/accounts 或 /user/balance。 */
async function probeStepfun({ baseUrl, apiKey, fetchImpl }) {
  const origin = new URL(baseUrl.includes('://') ? baseUrl : `https://${baseUrl}`).origin
  // 阶跃星辰的余额在 /v1/accounts 下（实测自 CC Switch 的实现）
  for (const path of ['/v1/accounts', '/v1/user/balance', '/user/balance']) {
    const result = await getJson(`${origin}${path}`, apiKey, fetchImpl)
    const data = result.body?.data ?? result.body
    const total = num(data?.balance ?? data?.total_balance)
    if (total !== undefined) {
      return { ok: true, kind: 'balance', usd: total, currency: 'CNY' }
    }
  }
  return { ok: false, error: '没有找到余额字段' }
}

/**
 * 火山方舟（豆包）：/api/v3/billing/balance。
 *
 * 实测该端点存在（无鉴权返回 401），返回结构未公开文档化，
 * 所以按多个可能的字段名尝试；都拿不到就明确说「没找到余额字段」，
 * 而不是编一个 0。
 */
async function probeVolcano({ baseUrl, apiKey, fetchImpl }) {
  const origin = new URL(baseUrl.includes('://') ? baseUrl : `https://${baseUrl}`).origin
  const candidate = [
    '/api/v3/billing/balance',
    '/api/v3/account/balance',
    '/api/v3/billing/account',
  ]
  for (const path of candidate) {
    const result = await getJson(`${origin}${path}`, apiKey, fetchImpl)
    if (result.body === undefined) continue
    const data = result.body?.data ?? result.body?.result ?? result.body
    const total = num(data?.balance ?? data?.available_balance ?? data?.total_balance ?? data?.remain)
    if (total !== undefined) {
      return { ok: true, kind: 'balance', usd: total, currency: 'CNY' }
    }
  }
  return { ok: false, error: '没有找到余额字段' }
}

//#endregion

//#region 配额型适配器

/**
 * 配额窗口名归一化。
 *
 * 不能只认写死的几个键：不同账号/版本会返回不同窗口（five_hour、
 * weekly_limit、monthly、甚至自定义名）。用写死白名单会静默丢限额——
 * 「只看得到 5 小时限额、看不到周限额」就是这么来的。
 */
const WINDOW_LABELS = {
  five_hour: '5-hour',
  five_hourly: '5-hour',
  hourly: 'Hourly',
  daily: 'Daily',
  weekly_limit: 'Weekly',
  weekly: 'Weekly',
  monthly: 'Monthly',
}

/** 把任意窗口标识（字符串或单键对象）转成展示名。 */
export function windowLabel(window) {
  if (window === undefined || window === null) return 'Quota'
  if (typeof window === 'string') return WINDOW_LABELS[window] ?? window
  if (typeof window === 'object') {
    const keys = Object.keys(window)
    if (keys.length === 0) return 'Quota'
    return WINDOW_LABELS[keys[0]] ?? keys[0]
  }
  return 'Quota'
}


/**
 * Kimi（Moonshot）Coding Plan：`/coding/v1/usages`。
 *
 * 响应里 `limits[]` 每项给出一个时间窗口：
 *   { detail: { remaining, resetTime }, window: { five_hour | weekly_limit } }
 * 或旧的扁平形态 `usage` / `limits`。这里两种都兼容。
 */
async function probeKimi({ baseUrl, apiKey, fetchImpl }) {
  const origin = new URL(baseUrl.includes('://') ? baseUrl : `https://${baseUrl}`).origin
  const result = await getJson(`${origin}/coding/v1/usages`, apiKey, fetchImpl)
  if (result.body === undefined) {
    return { ok: false, error: result.error ?? `HTTP ${result.status}` }
  }
  const body = result.body
  // 有的版本把数据包在 data 里
  const payload = body.data ?? body
  const quotas = []



  // 形态 A：limits 数组
  if (Array.isArray(payload.limits)) {
    for (const entry of payload.limits) {
      const detail = entry?.detail ?? entry
      const remaining = num(detail?.remaining)
      const limit = num(detail?.limit ?? detail?.total)
      // Kimi 只给 remaining 时，用 remaining 与「已用」推上限
      const used = num(detail?.used)
      const resetsAt = num(detail?.resetTime ?? detail?.resets_at)
      const q = quota(
        windowLabel(entry?.window),
        used ?? (remaining !== undefined && limit !== undefined ? limit - remaining : undefined),
        limit ?? (remaining !== undefined && used !== undefined ? remaining + used : undefined),
        resetsAt,
        detail?.unit,
      )
      if (q !== undefined) quotas.push(q)
    }
  }

  // 形态 B：usage 下平铺多个窗口。遍历全部键，避免漏掉未列举的窗口。
  const usage = payload.usage ?? payload
  if (usage !== null && typeof usage === 'object') {
    for (const [key, entry] of Object.entries(usage)) {
      if (entry === null || typeof entry !== 'object') continue
      const used = num(entry.used_value_usd ?? entry.used)
      const limit = num(entry.max_value_usd ?? entry.limit)
      const q = quota(
        WINDOW_LABELS[key] ?? key,
        used, limit,
        num(entry.resets_at ?? entry.resetTime),
        entry.unit ?? 'USD',
      )
      if (q !== undefined && !quotas.some((item) => item.label === q.label)) quotas.push(q)
    }
  }

  if (quotas.length === 0) {
    // 没有 Coding Plan 配额时，回退查按量计费余额。
    // 很多用户是「有充值、没订阅」，只查配额会误报「无订阅」而错过余额。
    const balance = await probeKimiBalance({ baseUrl, apiKey, fetchImpl })
    if (balance.ok === true) return balance
    // 明确的「没有订阅」比含糊的解析失败更有用
    if (String(body.msg ?? body.message ?? '').toLowerCase().includes('coding plan')) {
      return { ok: false, error: '该账号没有 Coding Plan 订阅，也没有可查的余额', noPlan: true }
    }
    return balance.ok === false && balance.error !== undefined
      ? balance
      : { ok: false, error: '响应里没有配额字段' }
  }
  return { ok: true, kind: 'quota', quotas }
}

/**
 * Kimi 按量计费余额：`/v1/users/me/balance`。
 *
 * 实测端点存在（无鉴权返回 401）。与 Coding Plan 配额是两套体系：
 * 订阅走窗口限流，充值余额按量扣减，两者可以同时存在。
 */
async function probeKimiBalance({ baseUrl, apiKey, fetchImpl }) {
  const origin = new URL(baseUrl.includes('://') ? baseUrl : `https://${baseUrl}`).origin
  const result = await getJson(`${origin}/v1/users/me/balance`, apiKey, fetchImpl)
  if (result.body === undefined) {
    return { ok: false, error: result.error ?? `HTTP ${result.status}` }
  }
  const data = result.body?.data ?? result.body
  const total = num(data?.available_balance ?? data?.balance ?? data?.total_balance)
  if (total === undefined) return { ok: false, error: '没有找到余额字段' }
  // 上游金额单位不确定，先按元处理；页面会标注币种
  return { ok: true, kind: 'balance', usd: total, currency: 'CNY' }
}

/**
 * 智谱 GLM Coding Plan：`/api/monitor/usage/quota/limit`。
 *
 * 返回形如 `{ code, msg, success, data: { limits: [...] } }`。
 * 账号没有 coding plan 时 `code` 非 0 并给出说明——那是有效信息，不是错误。
 */
async function probeGlm({ baseUrl, apiKey, fetchImpl }) {
  const origin = new URL(baseUrl.includes('://') ? baseUrl : `https://${baseUrl}`).origin
  // 用户可能填的是 /api/anthropic 这种子路径，配额接口在根下
  const result = await getJson(`${origin}/api/monitor/usage/quota/limit`, apiKey, fetchImpl)
  if (result.body === undefined) {
    return { ok: false, error: result.error ?? `HTTP ${result.status}` }
  }
  const body = result.body
  if (body.success === false || (body.code !== undefined && body.code !== 0 && body.code !== 200)) {
    const message = String(body.msg ?? body.message ?? '')
    return {
      ok: false,
      error: message === '' ? `平台返回 code=${body.code}` : message,
      noPlan: /coding plan|不存在/i.test(message),
    }
  }
  const data = body.data ?? body
  const quotas = []
  const list = Array.isArray(data?.limits) ? data.limits : Array.isArray(data) ? data : []
  for (const entry of list) {
    const rawLabel = entry?.type ?? entry?.window ?? entry?.label
    const used = num(entry?.used ?? entry?.current ?? entry?.usage)
    const limit = num(entry?.limit ?? entry?.total ?? entry?.max)
    const resetsAt = num(entry?.resetTime ?? entry?.resets_at ?? entry?.reset_time)
    const q = quota(windowLabel(rawLabel), used, limit, resetsAt, entry?.unit)
    if (q !== undefined) quotas.push(q)
  }
  if (quotas.length === 0) return { ok: false, error: '响应里没有配额字段' }
  return { ok: true, kind: 'quota', quotas }
}

/**
 * MiniMax：AFP usage。
 *
 * 响应外层有 `base_resp.status_code` 表示成败，业务数据在 `data` 里。
 */
async function probeMinimax({ baseUrl, apiKey, fetchImpl }) {
  const origin = new URL(baseUrl.includes('://') ? baseUrl : `https://${baseUrl}`).origin
  const result = await getJson(`${origin}/v1/usage`, apiKey, fetchImpl)
  if (result.body === undefined) {
    return { ok: false, error: result.error ?? `HTTP ${result.status}` }
  }
  const body = result.body
  const statusCode = num(body?.base_resp?.status_code)
  if (statusCode !== undefined && statusCode !== 0) {
    return {
      ok: false,
      error: String(body?.base_resp?.status_msg ?? `status_code=${statusCode}`),
    }
  }
  const data = body.data ?? body
  const quotas = []

  // limits 数组形态
  if (Array.isArray(data?.limits)) {
    for (const entry of data.limits) {
      const q = quota(
        windowLabel(entry?.type ?? entry?.window),
        num(entry?.used ?? entry?.current),
        num(entry?.limit ?? entry?.total),
        num(entry?.resetTime ?? entry?.resets_at),
        entry?.unit,
      )
      if (q !== undefined) quotas.push(q)
    }
  }

  // 平铺形态：遍历全部窗口键，不写死白名单
  if (quotas.length === 0 && data !== null && typeof data === 'object') {
    for (const [key, entry] of Object.entries(data)) {
      if (entry === null || typeof entry !== 'object') continue
      // 跳过明显的非窗口字段
      if (key === 'base_resp' || key === 'balance' || key === 'remaining') continue
      const q = quota(
        windowLabel(key),
        num(entry.used_value_usd ?? entry.used),
        num(entry.max_value_usd ?? entry.limit),
        num(entry.resets_at ?? entry.resetTime),
        entry.unit ?? 'USD',
      )
      if (q !== undefined) quotas.push(q)
    }
  }
  const balance = num(data?.balance ?? data?.remaining)
  if (quotas.length === 0) {
    if (balance !== undefined) return { ok: true, kind: 'balance', usd: balance }
    return { ok: false, error: '响应里没有余额或配额字段' }
  }
  return { ok: true, kind: 'quota', quotas }
}

//#endregion

/**
 * OpenAI 平台余额。
 *
 * 官方没有公开的「查询账户余额」接口，只有用量接口（需要 organization
 * admin key）。所以这里尝试 billing 端点，失败就明确说明需要什么权限。
 */
async function probeOpenai({ baseUrl, apiKey, fetchImpl }) {
  const origin = new URL(baseUrl.includes('://') ? baseUrl : `https://${baseUrl}`).origin
  // 用量接口：需要 sk-admin- 开头的组织密钥
  const result = await getJson(
    `${origin}/v1/organization/costs?start_time=${Math.floor(Date.now() / 1000) - 30 * 86400}`,
    apiKey, fetchImpl,
  )
  if (result.body !== undefined && Array.isArray(result.body.data)) {
    const usedUsd = result.body.data.reduce((total, bucket) => {
      const amount = num(bucket?.results?.[0]?.amount?.value) ?? 0
      return total + amount
    }, 0)
    return {
      ok: true, kind: 'quota',
      quotas: [quota('30-day', usedUsd, undefined, undefined, 'USD')].filter(Boolean),
    }
  }
  return {
    ok: false,
    error: result.status === 401 || result.status === 403
      ? '需要组织管理员密钥（sk-admin-）才能查询用量'
      : (result.error ?? `HTTP ${result.status}`),
  }
}

/**
 * 已知无法用 API key 查询余额的平台，以及原因。
 *
 * 这些平台的额度绑定在**账号登录态**（OAuth / 订阅）上，而不是 API key。
 * 用 key 去请求只会得到 403 或登录页——与其让用户以为「插件坏了」，
 * 不如直接说明为什么查不了。
 */
const UNSUPPORTED_REASONS = {
  // 阿里百炼没有公开的余额接口：控制台里的额度只在网页端可见
  qwen: '阿里百炼没有公开的余额查询接口，请到百炼控制台查看',
  mimo: '小米 MiMo 没有公开的余额查询接口（实测各候选端点均 404），请到 MiMo 控制台查看',
  codex: 'ChatGPT 订阅额度绑定在账号登录态上，API key 无法查询。请在 ChatGPT 官网查看用量。',
  gemini: 'Google 未提供公开的配额查询接口，API key 无法查询余额。',
}

/** 平台 id -> 探测函数。 */
const ADAPTERS = {
  deepseek: probeDeepseek,
  kimi: probeKimi,
  glm: probeGlm,
  minimax: probeMinimax,
  openrouter: probeOpenrouter,
  siliconflow: probeSiliconflow,
  novita: probeNovita,
  stepfun: probeStepfun,
  volcano: probeVolcano,
  openai: probeOpenai,
}

/**
 * 查询官方平台的余额或配额。
 *
 * 识别不出平台时返回 `{ ok:false, unsupported:true }`，调用方据此回退到
 * 中转站的通用探测（`probeBalance`）。
 */
export async function probeOfficial({ baseUrl, apiKey, fetchImpl, provider }) {
  const id = provider ?? detectProvider(baseUrl)
  if (id === undefined) return { ok: false, unsupported: true, error: '无法识别平台' }
  const adapter = ADAPTERS[id]
  if (adapter === undefined) {
    return {
      ok: false,
      unsupported: true,
      error: UNSUPPORTED_REASONS[id]
        ?? `${PROVIDER_LABELS[id] ?? id} 暂不支持余额查询`,
      provider: id,
      label: PROVIDER_LABELS[id] ?? id,
    }
  }
  const doFetch = fetchImpl ?? globalThis.fetch
  if (typeof doFetch !== 'function') return { ok: false, error: '当前环境没有 fetch', provider: id }
  try {
    const result = await adapter({ baseUrl, apiKey, fetchImpl: doFetch })
    return { ...result, provider: id, label: PROVIDER_LABELS[id] ?? id }
  } catch (error) {
    return { ok: false, error: error?.message ?? String(error), provider: id }
  }
}

/** 该平台是否支持查询（页面据此决定是否显示按钮）。 */
export function isSupportedProvider(baseUrl) {
  const id = detectProvider(baseUrl)
  return id !== undefined && ADAPTERS[id] !== undefined
}
