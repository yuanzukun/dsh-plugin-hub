/**
 * Plugin configuration for lark-agent-bridge.
 *
 * Every field can be supplied two ways:
 *   1. Inline in the profile's `cordis.patch.yml` (a `config:` block under the
 *      `lark-bridge` row), or
 *   2. Environment variables (the default, friendlier path for end users).
 *
 * The Config schema below is what dsh validates; `resolveConfig` fills any
 * unset field from `process.env` so a bare install works with just the two
 * Feishu app secrets and a DeepSeek key exported in the shell.
 *
 * @module lark-agent-bridge/config
 */

import Schema from '@deepseek-ai/schemastery'
import { parseAccessMode, type AccessMode } from './access-mode.js'
import { readCredentials } from './credentials.js'

/** Tenant selects the Feishu (feishu.cn) vs Lark (larksuite.com) open domain. */
export type LarkTenant = 'feishu' | 'lark'

export interface LarkBridgeConfig {
  /** Explicitly disable channel/registration side effects; default true. */
  enabled?: boolean
  /** Feishu/Lark app id (`cli_...`). Falls back to `LARK_APP_ID`. */
  appId?: string
  /** Feishu/Lark app secret. Falls back to `LARK_APP_SECRET`. */
  appSecret?: string
  /** Which open-platform domain to use. Falls back to `LARK_TENANT`, default `feishu`. */
  tenant?: LarkTenant
  /** DeepSeek provider route for created agents. Falls back to `DSH_LARK_PROVIDER`. */
  provider?: string
  /** DeepSeek model for created agents. Falls back to `DSH_LARK_MODEL`. */
  model?: string
  /**
   * Root directory under which each group's project folder is created:
   * `<workspaceRoot>/<chatId>`. Falls back to `DSH_LARK_WORKSPACE_ROOT`,
   * default `~/dsh-lark-workspaces`.
   */
  workspaceRoot?: string
  /** Whether the agent may act in direct messages. Falls back to `DSH_LARK_ALLOW_DM`, default true. */
  allowDm?: boolean
  /** In group chats, require an @-mention of the bot to trigger. Default true. */
  requireMention?: boolean
  /** Hard deadline for one agent turn. Default 10 minutes; env DSH_LARK_TURN_TIMEOUT_MS. */
  turnTimeoutMs?: number
  /**
   * Group chat ids (`oc_...`) allowed to drive the bot. Empty = no group
   * allowed (fail-closed). Falls back to `DSH_LARK_ALLOWED_CHATS`
   * (comma-separated).
   */
  allowedChats?: string[]
  /**
   * User open_ids allowed to drive the bot in DMs. Empty = no DM user
   * allowed (fail-closed). The app owner always passes regardless. Falls back
   * to `DSH_LARK_ALLOWED_USERS` (comma-separated).
   */
  allowedUsers?: string[]
  /**
   * How much of the host an agent may touch. `workspace` (default) mounts a
   * restricted preset (file editing, no shell/network/subagents);
   * `read-only` mounts a read/search-only preset; `full` mounts the
   * deployment default. Falls back to `DSH_LARK_ACCESS_MODE`.
   */
  accessMode?: AccessMode
  /**
   * Additional `/preset` tiers beyond the shipped three, as
   * `id:preset-name` pairs (e.g. an internal-only preset that stays out of
   * the public repo). Falls back to `DSH_LARK_EXTRA_PRESETS`
   * (`"id:name,id2:name2"`).
   */
  extraPresets?: Record<string, string>
  /**
   * Preset ids whose switch requires a successful host SSO check before
   * taking effect (fail-closed). Falls back to `DSH_LARK_SSO_GATED_PRESETS`.
   */
  ssoGatedPresets?: string[]
  /**
   * The command that proves host SSO, e.g. `corp-cli auth status` (argv
   * tokens). Unset = no SSO gate. Falls back to `DSH_LARK_SSO_CHECK_CMD`.
   */
  ssoCheckCmd?: string
  /**
   * Text that must appear in the SSO check's output (exit 0 AND marker).
   * Falls back to `DSH_LARK_SSO_OK_MARKER`, default `Authenticated`.
   */
  ssoOkMarker?: string
  /**
   * Per-tier model routes: `presetId:provider:model` pairs (e.g.
   * `internal:acme-provider:acme-model`). Chats pinned to that preset route
   * their agents through that provider/model, overriding the global default
   * but not a per-chat `/model`. The tier itself carries the SSO gate. Falls
   * back to `DSH_LARK_PRESET_MODELS`.
   */
  presetModels?: Record<string, { provider: string; model: string }>
}

export const Config: Schema<LarkBridgeConfig> = Schema.object({
  enabled: Schema.boolean().default(true),
  appId: Schema.string(),
  appSecret: Schema.string().role('secret'),
  tenant: Schema.union(['feishu', 'lark'] as const),
  provider: Schema.string(),
  model: Schema.string(),
  workspaceRoot: Schema.string(),
  allowDm: Schema.boolean(),
  requireMention: Schema.boolean(),
  turnTimeoutMs: Schema.number(),
  allowedChats: Schema.array(Schema.string()),
  allowedUsers: Schema.array(Schema.string()),
  accessMode: Schema.union(['read-only', 'workspace', 'full'] as const),
  extraPresets: Schema.dict(Schema.string()),
  ssoGatedPresets: Schema.array(Schema.string()),
  ssoCheckCmd: Schema.string(),
  ssoOkMarker: Schema.string(),
  presetModels: Schema.dict(Schema.object({ provider: Schema.string(), model: Schema.string() })),
})

/** The fully-resolved config after environment fallback; secrets are guaranteed present. */
export interface ResolvedConfig {
  appId: string
  appSecret: string
  tenant: LarkTenant
  provider?: string
  model?: string
  workspaceRoot: string
  allowDm: boolean
  requireMention: boolean
  turnTimeoutMs: number
  /** open_id of the app owner captured at registration, when known. */
  ownerId?: string
  allowedChats: string[]
  allowedUsers: string[]
  accessMode: AccessMode
  extraPresets: Record<string, string>
  ssoGatedPresets: string[]
  ssoCheckCmd?: string
  ssoOkMarker: string
  presetModels: Record<string, { provider: string; model: string }>
}

/** Read a boolean-ish env var (`1/true/yes/on` = true), returning `fallback` when unset. */
function envBool(value: string | undefined, fallback: boolean): boolean {
  if (value === undefined || value === '') return fallback
  return /^(1|true|yes|on)$/i.test(value)
}

/** Resolve a finite positive number from inline config or an env string. */
function positiveNumber(value: number | string | undefined, fallback: number): number {
  const parsed = typeof value === 'number' ? value : value === undefined ? NaN : Number(value)
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback
}

/**
 * Merge the validated plugin config with environment and saved-credential
 * fallbacks, returning `undefined` when the Feishu secrets are not yet
 * available anywhere. Precedence for the secrets: inline config → environment
 * variables → the file written by the registration wizard.
 *
 * Unlike {@link resolveConfig} this never throws on missing credentials: it is
 * the "have we been set up yet?" probe the plugin runs at boot, so a fresh
 * install can fall through to the auto-registration wizard instead of crashing.
 */
export function tryResolveConfig(config: LarkBridgeConfig): ResolvedConfig | undefined {
  const env = process.env
  const saved = readCredentials()
  const appId = config.appId ?? env.LARK_APP_ID ?? saved?.appId
  const appSecret = config.appSecret ?? env.LARK_APP_SECRET ?? saved?.appSecret
  if (!appId || !appSecret) return undefined
  const tenant = (config.tenant ?? env.LARK_TENANT ?? saved?.tenant ?? 'feishu') as LarkTenant
  const home = env.HOME ?? env.USERPROFILE ?? process.cwd()
  const configuredIdentity = config.appId !== undefined || config.appSecret !== undefined
  const envIdentity = env.LARK_APP_ID !== undefined || env.LARK_APP_SECRET !== undefined
  // A saved owner belongs to the saved app identity. Never carry that trust
  // across an inline/env credential override for a different app.
  const ownerId = configuredIdentity || envIdentity
    ? saved?.appId === appId && saved?.appSecret === appSecret ? saved.ownerId : undefined
    : saved?.ownerId
  return {
    appId,
    appSecret,
    tenant,
    provider: config.provider ?? env.DSH_LARK_PROVIDER,
    model: config.model ?? env.DSH_LARK_MODEL,
    workspaceRoot:
      config.workspaceRoot ?? env.DSH_LARK_WORKSPACE_ROOT ?? `${home}/dsh-lark-workspaces`,
    allowDm: config.allowDm ?? envBool(env.DSH_LARK_ALLOW_DM, true),
    requireMention: config.requireMention ?? envBool(env.DSH_LARK_REQUIRE_MENTION, true),
    turnTimeoutMs: positiveNumber(
      config.turnTimeoutMs ?? env.DSH_LARK_TURN_TIMEOUT_MS,
      10 * 60 * 1000,
    ),
    ownerId,
    // NOTE: schemastery materializes empty arrays/objects for absent list/dict
    // fields (e.g. `[]` for Schema.array, `{}` for Schema.dict), so a bare
    // `?? env` fallback is defeated by the empty default. Use emptiness-aware
    // resolution instead — an empty configured list means "use the env".
    allowedChats: hasItems(config.allowedChats)
      ? config.allowedChats
      : envList(env.DSH_LARK_ALLOWED_CHATS),
    allowedUsers: hasItems(config.allowedUsers)
      ? config.allowedUsers
      : envList(env.DSH_LARK_ALLOWED_USERS),
    accessMode: parseAccessMode(config.accessMode ?? env.DSH_LARK_ACCESS_MODE, 'workspace'),
    extraPresets: hasKeys(config.extraPresets)
      ? config.extraPresets
      : parsePresetPairs(env.DSH_LARK_EXTRA_PRESETS),
    ssoGatedPresets: hasItems(config.ssoGatedPresets)
      ? config.ssoGatedPresets
      : envList(env.DSH_LARK_SSO_GATED_PRESETS),
    ssoCheckCmd: config.ssoCheckCmd ?? env.DSH_LARK_SSO_CHECK_CMD,
    ssoOkMarker: config.ssoOkMarker ?? env.DSH_LARK_SSO_OK_MARKER ?? 'Authenticated',
    presetModels: hasKeys2(config.presetModels)
      ? config.presetModels
      : parsePresetModels(env.DSH_LARK_PRESET_MODELS),
  }
}

/** True only for a record with at least one key (typed for the preset-model map). */
function hasKeys2(
  record: Record<string, { provider: string; model: string }> | undefined,
): record is Record<string, { provider: string; model: string }> {
  return record !== undefined && Object.keys(record).length > 0
}

/** Parse `"presetId:provider:model,id2:provider2:model2"` into a record. */
function parsePresetModels(value: string | undefined): Record<string, { provider: string; model: string }> {
  const out: Record<string, { provider: string; model: string }> = {}
  if (value === undefined || value.trim() === '') return out
  for (const entry of value.split(',')) {
    const [presetId, provider, model] = entry.split(':').map(part => part.trim())
    if (presetId && provider && model) out[presetId] = { provider, model }
  }
  return out
}

/** True only for a list with at least one item. */
function hasItems(list: string[] | undefined): list is string[] {
  return list !== undefined && list.length > 0
}

/** True only for a record with at least one key. */
function hasKeys(record: Record<string, string> | undefined): record is Record<string, string> {
  return record !== undefined && Object.keys(record).length > 0
}

/** Parse `"id:presetName,id2:name2"` into a record (invalid pairs are dropped). */
function parsePresetPairs(value: string | undefined): Record<string, string> {
  const out: Record<string, string> = {}
  if (value === undefined || value.trim() === '') return out
  for (const pair of value.split(',')) {
    const [id, name] = pair.split(':').map(part => part.trim())
    if (id && name) out[id] = name
  }
  return out
}

/** Parse a comma-separated env list into a trimmed string array (empty when unset). */
function envList(value: string | undefined): string[] {
  if (value === undefined || value.trim() === '') return []
  return value
    .split(',')
    .map(item => item.trim())
    .filter(item => item.length > 0)
}

/**
 * Merge the validated plugin config with environment and saved-credential
 * fallbacks. Precedence for the Feishu secrets: inline config → environment
 * variables → the file written by the `lark-agent-register` wizard. Throws a
 * clear error if none supply them, so the failure surfaces at boot rather than
 * on the first inbound message.
 */
export function resolveConfig(config: LarkBridgeConfig): ResolvedConfig {
  const resolved = tryResolveConfig(config)
  if (resolved === undefined) {
    throw new Error(
      'lark-agent-bridge: missing Feishu credentials. Run the `lark-agent-register` wizard ' +
        'to create an app by QR, or set LARK_APP_ID and LARK_APP_SECRET ' +
        '(or appId/appSecret in the plugin config).',
    )
  }
  return resolved
}

/** The open-platform base URL for the selected tenant. */
export function domainFor(tenant: LarkTenant): string {
  return tenant === 'lark' ? 'https://open.larksuite.com' : 'https://open.feishu.cn'
}
