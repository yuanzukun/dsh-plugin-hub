#!/usr/bin/env pwsh
# setup.ps1 — Windows (PowerShell) one-command install of lark-agent-bridge (bundle mode).
# Mirror of scripts/setup.sh; idempotent (safe to re-run).
#
# What it does:
#   1. preflight: Node version / dsh availability
#   2. build the plugin if lib/ is missing
#   3. install the lark-workspace / lark-readonly presets
#   4. install the bridge + workspace tool through dsh plugin (preferred), or
#      link both into an already-initialized profile as a manual fallback
#   5. print next steps
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File scripts/setup.ps1   (Windows PowerShell 5.1)
#   pwsh scripts/setup.ps1                                       (PowerShell 7+)
#   $env:DSH_PROFILE = 'headless'; pwsh scripts/setup.ps1        (different profile)
#   $env:DSH_HOME = 'D:\...\.dsh'; pwsh scripts/setup.ps1        (custom dsh home)

$ErrorActionPreference = 'Stop'

$ProjectDir = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$DshHome = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $HOME '.dsh' }
$Profile = if ($env:DSH_PROFILE) { $env:DSH_PROFILE } else { 'web' }
$ProfileDir = Join-Path $DshHome (Join-Path 'profiles' $Profile)
$Manifest = Join-Path $ProfileDir 'package.json'
$Link = Join-Path $ProfileDir (Join-Path 'node_modules' '@bihangchi9/lark-agent-bridge')
$LarkToolLink = Join-Path $ProfileDir (Join-Path 'node_modules' 'dsh-tool-lark-cli')

Write-Host '==> lark-agent-bridge setup'
Write-Host "    project : $ProjectDir"
Write-Host "    profile : $ProfileDir"

# 1. Preflight: current declared DSH hosts require Node >=24.9.0.
$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) {
    Write-Error 'node not found in PATH. Install Node.js >=24.9.0 (https://nodejs.org).'
    exit 1
}
& node -e 'const [major, minor] = process.versions.node.split(".").map(Number); process.exit(major > 24 || (major === 24 && minor >= 9) ? 0 : 1)'
if ($LASTEXITCODE -ne 0) {
    Write-Error "node $(& node -v) is too old - declared dsh hosts need >=24.9.0."
    exit 1
}
Write-Host "    node    : $(& node -v) (ok)"

# Prefer dsh's official plugin manager. It owns profile initialization and can
# create shipped profiles (web/headless) on first use.
$DshCommand = Get-Command dsh -ErrorAction SilentlyContinue

# Without dsh we can only use the manual manifest fallback. Fail before build
# or preset copies if the profile is absent, leaving no partial installation.
if (-not $DshCommand -and -not (Test-Path $Manifest -PathType Leaf)) {
    Write-Error @"
dsh profile '$Profile' is not initialized yet.
The dsh command is not available, so setup cannot initialize it.
Install or expose dsh in PATH and re-run 'pnpm setup:win', or initialize the
profile separately before using the manual fallback.
"@
    exit 1
}
if ($DshCommand) {
    Write-Host "    dsh     : $($DshCommand.Source) (official plugin install)"
}
else {
    Write-Host '    profile : initialized (manual fallback)'
}

# 2. Build the bridge AND its shipped lark-cli tool if either entry is missing.
#    The workspace preset references dsh-tool-lark-cli, so both are mandatory.
$BridgeEntry = Join-Path $ProjectDir 'lib\index.js'
$LarkToolEntry = Join-Path $ProjectDir 'tools\lark-cli\lib\index.js'
if (-not (Test-Path $BridgeEntry) -or -not (Test-Path $LarkToolEntry)) {
    if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) {
        Write-Error 'pnpm not found in PATH - needed to build the plugin (or run "corepack enable").'
        exit 1
    }
    Write-Host '==> building plugin (pnpm install && pnpm build)'
    Push-Location $ProjectDir
    try {
        & pnpm install
        & pnpm build
        if ($LASTEXITCODE -ne 0) { throw "pnpm build failed with exit code $LASTEXITCODE" }
    }
    finally {
        Pop-Location
    }
}
else {
    Write-Host '    build  : lib/ present, skipping build'
}

# 2b. Hard gate: both entries MUST exist before registration.
foreach ($entry in @($BridgeEntry, $LarkToolEntry)) {
    if (-not (Test-Path $entry)) {
        Write-Error "$entry is missing after build. Not registering. Run 'pnpm install; pnpm build' and check for errors."
        exit 1
    }
}
Write-Host '    entries: bridge + dsh-tool-lark-cli present (ok)'
$LarkToolDir = Join-Path $ProjectDir 'tools\lark-cli'


# 3. Install the access-tier presets into the harness-home preset root
#    ($DSH_HOME\.agent-presets). dsh discovers presets there (uncached); without
#    them the workspace/read-only tiers fall back to the deployment default.
$PresetRoot = Join-Path $DshHome '.agent-presets'
$ShippedPresets = Join-Path $ProjectDir 'presets'
if (Test-Path $ShippedPresets) {
    New-Item -ItemType Directory -Force -Path $PresetRoot | Out-Null
    Copy-Item -Path (Join-Path $ShippedPresets '*') -Destination $PresetRoot -Recurse -Force
    Write-Host "==> presets installed: $PresetRoot\lark-workspace, $PresetRoot\lark-readonly"
}
else {
    Write-Host '    presets: none shipped in this checkout - skipping'
}

# 4. Install the workspace tool and bridge. The official plugin manager also
#    initializes missing profiles. The manual fallback links both packages and
#    updates an already-existing manifest.
$IsWindowsOs = $env:OS -eq 'Windows_NT'
if ($DshCommand) {
    Write-Host "==> installing workspace tool: dsh plugin --profile $Profile add link:$LarkToolDir"
    & $DshCommand.Source plugin --profile $Profile add "link:$LarkToolDir"
    if ($LASTEXITCODE -ne 0) { throw "dsh plugin failed with exit code $LASTEXITCODE" }
    Write-Host "==> registering bridge: dsh plugin --profile $Profile add link:$ProjectDir"
    & $DshCommand.Source plugin --profile $Profile add "link:$ProjectDir"
    if ($LASTEXITCODE -ne 0) { throw "dsh plugin failed with exit code $LASTEXITCODE" }
}
else {
    $ModulesDir = Split-Path $Link
    New-Item -ItemType Directory -Force -Path $ModulesDir | Out-Null
    if (Test-Path $Link) {
        $existing = Get-Item $Link -Force
        if ($existing.LinkType -ne 'Junction' -and $existing.LinkType -ne 'SymbolicLink') {
            Write-Error "$Link exists and is not a link - remove it first."
            exit 1
        }
    }
    else {
        if ($IsWindowsOs) {
            New-Item -ItemType Junction -Path $Link -Target $ProjectDir | Out-Null
        }
        else {
            New-Item -ItemType SymbolicLink -Path $Link -Target $ProjectDir | Out-Null
        }
    }
    if (-not (Test-Path $Link)) {
        Write-Error "link creation failed for $Link"
        exit 1
    }

    if (Test-Path $LarkToolLink) {
        $existingTool = Get-Item $LarkToolLink -Force
        if ($existingTool.LinkType -ne 'Junction' -and $existingTool.LinkType -ne 'SymbolicLink') {
            Write-Error "$LarkToolLink exists and is not a link - remove it first."
            exit 1
        }
    }
    else {
        if ($IsWindowsOs) {
            New-Item -ItemType Junction -Path $LarkToolLink -Target $LarkToolDir | Out-Null
        }
        else {
            New-Item -ItemType SymbolicLink -Path $LarkToolLink -Target $LarkToolDir | Out-Null
        }
    }
    if (-not (Test-Path $LarkToolLink)) {
        Write-Error "link creation failed for $LarkToolLink"
        exit 1
    }

    $pkg = Get-Content $Manifest -Raw | ConvertFrom-Json
    if ($null -eq $pkg.dependencies) {
        $pkg | Add-Member -NotePropertyName 'dependencies' -NotePropertyValue ([pscustomobject]@{})
    }
    $pkg.dependencies | Add-Member -NotePropertyName '@bihangchi9/lark-agent-bridge' -NotePropertyValue "link:$ProjectDir" -Force
    $pkg.dependencies | Add-Member -NotePropertyName 'dsh-tool-lark-cli' -NotePropertyValue "link:$LarkToolDir" -Force
    if ($null -eq $pkg.dsh) {
        $pkg | Add-Member -NotePropertyName 'dsh' -NotePropertyValue ([pscustomobject]@{})
    }
    if ($null -eq $pkg.dsh.profile) {
        $pkg.dsh | Add-Member -NotePropertyName 'profile' -NotePropertyValue ([pscustomobject]@{})
    }
    $bundles = @($pkg.dsh.profile.bundles)
    if ($bundles -notcontains '@bihangchi9/lark-agent-bridge') {
        $pkg.dsh.profile | Add-Member -NotePropertyName 'bundles' -NotePropertyValue @($bundles + '@bihangchi9/lark-agent-bridge') -Force
    }
    $json = $pkg | ConvertTo-Json -Depth 10
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Manifest, $json + [Environment]::NewLine, $utf8NoBom)
}

# 4b. Hard postcondition: both linked entries and the bundle registry must exist.
foreach ($entry in @(
    (Join-Path $Link 'lib\index.js'),
    (Join-Path $LarkToolLink 'lib\index.js')
)) {
    if (-not (Test-Path $entry)) {
        Write-Error "installation incomplete: $entry is missing"
        exit 1
    }
}
$check = Get-Content $Manifest -Raw | ConvertFrom-Json
if (@($check.dsh.profile.bundles) -notcontains '@bihangchi9/lark-agent-bridge') {
    Write-Error 'installation incomplete: lark-agent-bridge is not registered as a bundle'
    exit 1
}
Write-Host '==> verified bridge bundle + dsh-tool-lark-cli dependency'

Write-Host ''
Write-Host '==> Done. Next steps:'
Write-Host '  1. Start dsh - the bundle loads automatically, no --patch needed:'
Write-Host '     $env:DSH_PERMISSION_MODE = "danger-full-access"; dsh web'
Write-Host '  2. On first run, scan the QR code with the Feishu app, or open the URL'
Write-Host '     written to ~\.dsh-lark-bridge\register-url.txt in a browser.'
Write-Host '  3. Add the bot to a group chat (or DM it) and send /help.'
