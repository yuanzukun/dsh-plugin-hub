---
description: Red-team your current idea against your own vault history - finds contradictions, past failures, and flawed assumptions
category: thinking
triggers_en: ["challenge this", "grill me on this", "red team my idea", "stress test this"]
triggers_es: ["cuestiona esta idea", "ponme a prueba con esto", "haz de abogado del diablo con mi idea", "pon esto a prueba", "dime por qué esto no funcionaría"]
triggers_pt: ["desafie isto", "questione minha ideia", "faça um red team da minha ideia", "teste esta ideia"]
triggers_zh: ["挑战一下这个想法", "帮我找这个方案的问题", "站在反方审视它", "给这个想法做压力测试", "别客气地质疑我"]
---

Use the obsidian-second-brain skill. Execute `/obsidian-challenge $ARGUMENTS`:

The optional argument is the idea, belief, or plan to challenge. If not provided, infer the user's current position from conversation context.

1. Read `_CLAUDE.md` first if it exists in the vault root
2. Identify the user's current claim, plan, or assumption - either from the argument or from recent conversation
3. Extract the key premises behind that position
4. Search the vault for counter-evidence - spawn parallel subagents:
   - **Decisions agent**: search Key Decisions sections in project notes for past decisions that contradicted or reversed similar thinking
   - **Failures agent**: search dev logs, daily notes, and archives for past failures, regrets, or lessons learned related to this topic
   - **Contradictions agent**: search for notes where the user held the opposite position or flagged risks about this exact approach
5. Synthesize a structured "Red Team" analysis:
   - **Your position**: restate the claim clearly
   - **Counter-evidence from your vault**: cite specific notes, dates, and quotes
   - **Blind spots**: what the user might be ignoring based on their own history
   - **Verdict**: is this position consistent with past experience, or does the vault suggest caution?
6. Log the challenge in today's daily note under a Thinking section
7. Offer to save the full challenge report as a standalone note in the concepts/ideas folder (resolved per `references/folder-map.md`), `type: challenge`, thinking-tool schema in `references/ai-first-rules.md`

Do not be agreeable. The entire point is to pressure-test. Cite specific vault files. If you find nothing contradictory, say so honestly - but search thoroughly first.

---

**AI-first rule:** Every note created or updated by this command MUST follow `references/ai-first-rules.md` - `## For future Claude` preamble, rich frontmatter (`type`, `date`, `tags`, `ai-first: true`, plus type-specific fields), recency markers per external claim, mandatory `[[wikilinks]]` for every person/project/concept referenced, sources preserved verbatim with URLs inline, and confidence levels where applicable. If that path does not resolve from your working directory, search upward for it; if you still cannot read it, say so before writing rather than producing a note that silently skips the rule. The vault is for future-Claude retrieval - not human reading.

**Anti-fabrication:** Search exhaustively before claiming any note, person, or file is absent - false absence is the most common failure mode - and never invent facts, entities, or dates (mark unknowns as `TBD`). See the anti-fabrication and search-completeness hard rules in `references/ai-first-rules.md`.
