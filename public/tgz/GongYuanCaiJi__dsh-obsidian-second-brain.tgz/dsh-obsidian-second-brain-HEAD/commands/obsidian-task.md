---
description: Add a task to the right kanban board with inferred priority and due date
category: vault
trigger-mode: proactive
triggers_en: ["add task", "new todo", "track this", "remind me"]
triggers_es: ["añade una tarea", "nuevo pendiente", "haz seguimiento de esto", "recuérdamelo"]
triggers_pt: ["adicione uma tarefa", "novo a fazer", "acompanhe isto", "me lembre disto"]
triggers_zh: ["添加一个任务", "记个待办", "跟踪这件事", "提醒我处理这个", "把这件事放到看板"]
---

Use the obsidian-second-brain skill. Execute `/obsidian-task $ARGUMENTS`:

1. Read `_CLAUDE.md` first if it exists in the vault root
2. Parse the task from the argument, or pull from recent conversation context if no argument given
3. Infer: priority (🔴/🟡/🟢), due date, linked project, linked person
4. Search for the right kanban board - use `_CLAUDE.md` board list or search the boards folder (resolved per `references/folder-map.md`)
5. Add the task card to the correct column (`📋 This Week` or `📥 Backlog` depending on due date)
6. Create a task note in the tasks folder (resolved per `references/folder-map.md` - wiki-style `wiki/tasks/`, Obsidian-style `Tasks/`) if the task is substantial (more than a one-liner)
7. Link the task from the relevant project note and today's daily note

---

**AI-first rule:** Every note created or updated by this command MUST follow `references/ai-first-rules.md` - `## For future Claude` preamble, rich frontmatter (`type`, `date`, `tags`, `ai-first: true`, plus type-specific fields), recency markers per external claim, mandatory `[[wikilinks]]` for every person/project/concept referenced, sources preserved verbatim with URLs inline, and confidence levels where applicable. If that path does not resolve from your working directory, search upward for it; if you still cannot read it, say so before writing rather than producing a note that silently skips the rule. The vault is for future-Claude retrieval - not human reading.

**Anti-fabrication:** Search exhaustively before claiming any note, person, or file is absent - false absence is the most common failure mode - and never invent facts, entities, or dates (mark unknowns as `TBD`). See the anti-fabrication and search-completeness hard rules in `references/ai-first-rules.md`.
