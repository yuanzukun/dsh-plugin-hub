---
description: Deep-read an X (Twitter) post via Grok x_search - verbatim post, thread, TL;DR, claims, reply sentiment, voices to watch
category: research
triggers_en: ["read this x post", "deep read this tweet", "analyze this tweet", "read this thread"]
triggers_es: ["léeme este post de x", "profundiza en este tweet", "analiza este tweet", "léeme este hilo"]
triggers_pt: ["leia este post do x", "leitura profunda deste tweet", "analise este tweet", "leia esta thread"]
triggers_zh: ["读一下这条 X 帖子", "深入分析这条推文", "这条推文讲了什么", "梳理一下这串推文"]
---

Use the obsidian-second-brain skill. Execute `/x-read [url]`:

1. Resolve the URL from the user's argument. If no URL was given, ask: "Which X post URL?" Accept any URL containing `x.com/` or `twitter.com/`.

2. Run the script from the skill root (its absolute path was given at session start as **Skill root**; substitute it for `SKILL_ROOT`):
   ```bash
   uv run --directory "SKILL_ROOT" -m scripts.research.x_read "<url>"
   ```

3. The script prints a structured analysis (ORIGINAL POST, THREAD, TL;DR, KEY CLAIMS, REPLY SENTIMENT, NOTABLE COUNTER-ARGUMENTS, VOICES TO WATCH) and a one-line cost summary on stderr. Show the analysis to the user verbatim - don't paraphrase or summarize.

4. **Default save behavior: chat only.** Do NOT save the analysis to the vault automatically. The user must ask explicitly ("save this", "save to vault", "/obsidian-save") for it to be archived.

5. If the user asks to save: write an AI-first note to `Research/X-reads/YYYY-MM-DD - <slug>.md` in the vault, following the AI-first vault rule (Section 0 of `_CLAUDE.md`):
   - Frontmatter: `date`, `time`, `type: x-read`, `ai-first: true`, `post-url`, `post-author` (if known), `key-claims` (list), `tags`, `related-people` (wikilinks for any @ handles that map to known people in the vault), `cost-usd`
   - Body starts with a `## For future Claude` preamble section (2-3 sentences summarizing what this post is about and why it was saved)
   - Then the full structured analysis from the script

6. Plain English triggers that route to this command: "read this tweet", "read this X post", "what's in this tweet", "analyze this X link" - when followed by a URL.

7. If the script fails with a clear error (missing key, network down), surface the error message verbatim. The script handles retry on transient errors automatically.

---

**AI-first rule:** Every note created or updated by this command MUST follow `references/ai-first-rules.md` - `## For future Claude` preamble, rich frontmatter (`type`, `date`, `tags`, `ai-first: true`, plus type-specific fields), recency markers per external claim, mandatory `[[wikilinks]]` for every person/project/concept referenced, sources preserved verbatim with URLs inline, and confidence levels where applicable. If that path does not resolve from your working directory, search upward for it; if you still cannot read it, say so before writing rather than producing a note that silently skips the rule. The vault is for future-Claude retrieval - not human reading.

**Anti-fabrication:** Search exhaustively before claiming any note, person, or file is absent - false absence is the most common failure mode - and never invent facts, entities, or dates (mark unknowns as `TBD`). See the anti-fabrication and search-completeness hard rules in `references/ai-first-rules.md`.
