#!/bin/bash

set -e

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLAUDE_DIR="$HOME/.claude"
COMMANDS_DIR="$CLAUDE_DIR/commands"
SKILLS_DIR="$CLAUDE_DIR/skills"
CONFIG_DIR="$HOME/.config/obsidian-second-brain"
ENV_FILE="$CONFIG_DIR/.env"

echo "Installing obsidian-second-brain..."

# Create directories if needed
mkdir -p "$COMMANDS_DIR"
mkdir -p "$SKILLS_DIR"

# Detect platform once
case "$(uname -s)" in
  MINGW*|MSYS*|CYGWIN*) IS_WINDOWS=1 ;;
  *) IS_WINDOWS=0 ;;
esac

# Link commands into ~/.claude/commands/ (copy on Windows without Developer Mode)
echo "Installing slash commands..."
COMMANDS_COPIED=0
for file in "$SKILL_DIR/commands/"*.md; do
  name=$(basename "$file")
  dest="$COMMANDS_DIR/$name"
  if [ -e "$dest" ] || [ -L "$dest" ]; then
    echo "  skipping $name (already exists)"
  elif [ "$IS_WINDOWS" -eq 0 ]; then
    ln -s "$file" "$dest"
    echo "  linked $name"
  elif MSYS=winsymlinks:nativestrict ln -s "$file" "$dest" 2>/dev/null; then
    echo "  linked $name"
  else
    cp "$file" "$dest"
    COMMANDS_COPIED=1
    echo "  installed $name"
  fi
done
if [ "$COMMANDS_COPIED" -eq 1 ]; then
  echo "  (symlinks require Developer Mode - commands were copied; run update.sh to refresh)"
fi

# Link skill into ~/.claude/skills/
SKILL_LINK="$SKILLS_DIR/obsidian-second-brain"
if [ -e "$SKILL_LINK" ]; then
  echo "Skill already linked at $SKILL_LINK"
elif [ "$IS_WINDOWS" -eq 0 ]; then
  ln -s "$SKILL_DIR" "$SKILL_LINK"
  echo "Skill linked at $SKILL_LINK"
else
  if MSYS=winsymlinks:nativestrict ln -s "$SKILL_DIR" "$SKILL_LINK" 2>/dev/null; then
    echo "Skill linked at $SKILL_LINK"
  else
    echo "Symlink failed (requires Developer Mode). For the cleanest setup,"
    echo "clone the repo directly into the skills folder:"
    echo "  git clone https://github.com/eugeniughelbur/obsidian-second-brain ~/.claude/skills/obsidian-second-brain"
    echo "Then re-run install.sh from that location."
  fi
fi

# Register the SessionStart context hook so slash commands can locate the skill's
# bundled scripts. The plugin install wires this up automatically via its manifest;
# the skill install needs it in settings.json. Idempotent, safe to re-run.
echo "Registering session context hook..."
if command -v python3 >/dev/null 2>&1; then
  python3 "$SKILL_DIR/scripts/setup_settings_hook.py"
elif command -v python >/dev/null 2>&1; then
  python "$SKILL_DIR/scripts/setup_settings_hook.py"
else
  echo "  python not found - add this SessionStart hook to ~/.claude/settings.json manually:"
  echo "    python3 $HOME/.claude/skills/obsidian-second-brain/hooks/load_vault_context.py"
fi

# ── Research toolkit setup (optional) ──────────────────────────────
echo ""
echo "Research toolkit (optional): /x-read, /x-pulse, /research, /research-deep, /youtube"
echo "These commands need API keys for Grok (xAI) and Perplexity. YouTube key is optional."
echo ""
read -r -p "Set up research toolkit now? [y/N] " setup_research
setup_research=${setup_research:-N}

if [[ "$setup_research" =~ ^[Yy]$ ]]; then
  # Verify uv is available
  if ! command -v uv >/dev/null 2>&1; then
    case "$(uname -s)" in
      Darwin)               uv_hint="brew install uv" ;;
      Linux)                uv_hint="curl -LsSf https://astral.sh/uv/install.sh | sh" ;;
      MINGW*|MSYS*|CYGWIN*) uv_hint="powershell -c \"irm https://astral.sh/uv/install.ps1 | iex\"" ;;
      *)                    uv_hint="see https://docs.astral.sh/uv/getting-started/installation/" ;;
    esac
    echo "  ⚠️  'uv' not found. Install with: $uv_hint"
    echo "     Then re-run this installer to finish research toolkit setup."
  else
    echo "  Installing Python deps via uv..."
    (cd "$SKILL_DIR" && uv sync --quiet)
    echo "  Python deps ready."
  fi

  # Set up config dir + .env
  mkdir -p "$CONFIG_DIR"
  if [ -f "$ENV_FILE" ]; then
    echo "  $ENV_FILE already exists - leaving it untouched."
  else
    cp "$SKILL_DIR/.env.example" "$ENV_FILE"
    chmod 600 "$ENV_FILE"
    echo "  Created $ENV_FILE (permissions 600)."
  fi

  echo ""
  echo "  Now paste your API keys into: $ENV_FILE"
  echo "    XAI_API_KEY=          (https://console.x.ai)"
  echo "    PERPLEXITY_API_KEY=   (https://perplexity.ai/settings/api)"
  echo "    YOUTUBE_API_KEY=      (https://console.cloud.google.com - optional)"
  echo ""
  read -r -p "  Press Enter to open the file in your default editor (or Ctrl+C to skip)... " _
  # Pick a default opener if $EDITOR is unset. Original used `open` (macOS-only).
  default_editor=open
  case "$(uname -s)" in
    Linux)                default_editor=xdg-open ;;
    MINGW*|MSYS*|CYGWIN*) default_editor=notepad ;;
  esac
  ${EDITOR:-$default_editor} "$ENV_FILE"
fi

echo ""
echo "Done. Restart Claude Code to activate the commands."
echo ""
echo "Next steps:"
echo "  1. Run /obsidian-init to generate your vault's _CLAUDE.md"
echo "  2. (If research toolkit installed) Verify keys: cat $ENV_FILE"
