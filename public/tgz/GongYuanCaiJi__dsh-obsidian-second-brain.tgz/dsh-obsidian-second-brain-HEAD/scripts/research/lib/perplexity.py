"""Perplexity Sonar client. Uses the OpenAI-compatible /chat/completions endpoint."""

import re
import time
from typing import Any

import requests

from . import usage
from .config import PERPLEXITY_API_KEY, PERPLEXITY_DEEP_MODEL, PERPLEXITY_RESEARCH_MODEL

API_URL = "https://api.perplexity.ai/chat/completions"
MAX_RETRIES = 3
BACKOFF_SECONDS = (1, 3, 8)

# sonar-reasoning and sonar-deep-research wrap their internal deliberation in <think>...</think>.
# Strip it before returning to keep the output clean.
_THINK_BLOCK = re.compile(r"<think>.*?</think>\s*", re.DOTALL | re.IGNORECASE)


def call(prompt: str, *, model: str | None = None, deep: bool = False, max_tokens: int = 4000, command: str = "research") -> dict[str, Any]:
    model = model or (PERPLEXITY_DEEP_MODEL if deep else PERPLEXITY_RESEARCH_MODEL)
    headers = {
        "Authorization": f"Bearer {PERPLEXITY_API_KEY()}",
        "Content-Type": "application/json",
    }
    body = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens,
    }
    timeout = 300 if deep else 120

    last_err: Exception | None = None
    for attempt in range(MAX_RETRIES):
        try:
            r = requests.post(API_URL, json=body, headers=headers, timeout=timeout)
            if r.status_code == 200:
                data = r.json()
                text = data["choices"][0]["message"]["content"]
                text = _THINK_BLOCK.sub("", text)
                # Handle unclosed <think> (truncated mid-reasoning) - drop everything from it onward
                if "<think>" in text:
                    text = text.split("<think>")[0]
                text = text.strip()
                # An empty completion is a failure, and it has to be raised rather
                # than returned: every caller writes `result["text"]` straight into a
                # vault note, so returning "" saves an empty note under a real title
                # and never trips the fallback each call site already has. It happens
                # for a mundane reason - a reasoning model spends max_tokens on
                # reasoning first, so a budget it can exhaust leaves nothing visible
                # and still reports finish_reason "stop". No retry: when the cause is
                # the budget it is deterministic, and three more calls bill the input
                # again to produce the same nothing.
                if not text:
                    raise RuntimeError(
                        f"{model} returned an empty completion "
                        f"(completion_tokens={(data.get('usage') or {}).get('completion_tokens')}, "
                        f"finish_reason={data['choices'][0].get('finish_reason')}). "
                        f"With max_tokens={max_tokens}, the most likely cause is that the "
                        "allowance left no room for a visible answer - raise it."
                    )
                citations = data.get("citations") or data.get("search_results") or []
                # Record the paid call in the shared usage ledger (fail-soft;
                # log_call itself never raises). Token counts come from the
                # OpenAI-shaped `usage` block when present.
                u = data.get("usage") or {}
                in_tok = int(u.get("prompt_tokens") or 0)
                out_tok = int(u.get("completion_tokens") or 0)
                usage.log_call(
                    command, model, in_tok, out_tok,
                    usage.estimate_perplexity_cost(model, in_tok, out_tok),
                    extra={"provider": "perplexity"},
                )
                return {
                    "text": text,
                    "citations": citations,
                    "model": model,
                    "raw": data,
                }
            if r.status_code in (429, 500, 502, 503, 504):
                wait = BACKOFF_SECONDS[min(attempt, len(BACKOFF_SECONDS) - 1)]
                print(f"[Perplexity {r.status_code}, retrying in {wait}s...]")
                time.sleep(wait)
                continue
            raise RuntimeError(f"Perplexity API error {r.status_code}: {r.text[:500]}")
        except requests.RequestException as e:
            last_err = e
            wait = BACKOFF_SECONDS[min(attempt, len(BACKOFF_SECONDS) - 1)]
            print(f"[Perplexity network error: {e}, retrying in {wait}s...]")
            time.sleep(wait)

    raise RuntimeError(f"Perplexity API failed after {MAX_RETRIES} retries: {last_err}")
