> ⚠️ **机制已退役 + 数字不可比（2026-09-10）。**
> - **配置已退役**:`inTurnSeal` 在当前插件加载时直接报错
>   (`src/index.ts` 的 `allowed` 白名单里没有它 → `Retired slice configuration
>   inTurnSeal`)。本文描述的开关不再存在。
> - **实现引用已失效**:本文提到的 `src/driver.ts`(`maybeSealSteps`)**在仓库中
>   已不存在**——2026-09-08 原生迁移删掉了自建驱动器。纯函数层现在是
>   `src/lab/step-tape.ts`(2026-09-10 前在 `src/slice/step-tape.ts`)，仍留在源码
>   树里，但只被 `tests/step-tape.spec.ts` 引用，不在插件的现役调用图上。
>   轮内压缩现在由 `tool-result-fold`(`src/fold/`) 承担，
>   机制不同，见 `docs/tool-result-fold.md`。
> - **下面的 A/B 数字测自旧 loop**，与当前架构不可比。

# 轮内切片(in-turn slicing):设计、v2 重载荷 A/B 结果与裁决

> 2026-09-02 · deepseek-harness-a4(DSH 0.1.2-alpha.4)· deepseek-v4-flash

## 动机

slice loop 把"每轮只给模型这一轮需要的上下文"做到了**轮界**。但真实负载是
2–4 轮 × 20–47 步、单轮工具输出最高 70 万字符——上下文膨胀几乎全在**轮内**。
轮内切片把同一套"封存 + 召回"下沉到步级:一轮走到阈值后,最旧的一批步折成
封存条目(调用摘要 + 结果头尾 + 精确切口),原文留在会话日志,`recall_step`
逐字取回。

## 实现

- `src/lab/step-tape.ts`(原 `src/slice/step-tape.ts`):封存条目纯函数;`stepsToSeal` 经济学门槛(轨迹 ≥
  sealTokens 且未封存步 ≥ batch+keep 才批量封);`sealSavesEnough` 体量守卫
  (折叠不压缩就不封);`protectEarlySteps` 宪法保护(见下)。
- `src/driver.ts` `maybeSealSteps`:请求组装前折叠;`slice/step-seal` 审计事件。
- `src/recall-step.ts`:`recall_step(turn, step)`。
- 默认**关闭**(`inTurnSeal.enabled=false`);启用时轨迹字节行为改变,禁用时与
  从前逐字节一致(契约测试断言)。

## v2 重载荷 A/B(~300K token/轮)

场景 l1/l2 由独立子代理设计(不知 slice 机制),每节点 13–20K 字符,读满 45
节点 ≈188K token;9 条早期规则读于步 1,必须活过重载荷链;诱饵分布早/中/晚。

| 场景 | 臂 | 判卷 | 峰值 | 步数 | reasoning | 成本 |
|---|---|---|---|---|---|---|
| l1 | transcript | ✓ 45/45 | 330K | 49 | 8.7K | $0.135 |
| l1 | slice-noseal | ✓ 45/45 | 66K | 139 | 8.4K | $0.068 |
| l1 | slice-seal 无保护 | ✗ 42/45 | 92K | 54 | 7.2K | $0.133 |
| l1 | slice-seal +保护 | ✓ 45/45 | 104K | 49 | 7.2K | $0.137 |
| l2 | transcript | ✓ 45/45 | 302K | 49 | 5.2K | $0.124 |
| l2 | slice-noseal | ✓ 45/45 | 308K | 49 | 10K | $0.126 |
| l2 | slice-seal 无保护 | ✗ 0/45 | 86K | 51 | 8.3K | $0.124 |
| l2 | slice-seal +保护 | ✓ 45/45 | 83K | 66 | 52.6K | $0.169 |

## 四个结论

**1. 封存 MVP 有严重缺陷 → 宪法保护修复并验证。** 无保护封存折叠含清单规则的
manifest 步,模型丢规则、`recall_step` 补不回:l1 42/45(tier 规则错,早/中三分之一)、
l2 0/45(全 missing)。`protectEarlySteps`(默认 2,前 N 步永不折叠——跨轮 seed
永不折叠的步内类比)把两场景都拉回 45/45。**本轮最有价值产出:一条可迁移的不变式。**

**2. "峰值已被现有机制解决"是错的。** l1 slice-noseal 峰值 66K 只因模型碰巧一步
一节点(139 步);l2 同臂模型批处理,峰值 308K = transcript。峰值削减依赖模型行为,
不可靠——这反而给封存真实价值:它可靠兜底(83–104K),不管模型怎么批。

**3. 封存不是成本赢,可能是成本负。** l1 加保护成本持平;l2 加保护 $0.169,比
transcript 贵 36%——reasoning 爆到 52.6K(为导航封存态重推理;单次观测,含变异)。
重建 miss + 额外推理 ≈ 抵消峰值省下的。

**4. 300–330K 下无 rot。** 所有非封存臂在 330K 峰值下 45/45——flash 此任务高峰值
不触发 rot。封存削峰的质量收益在本工况 = 0。

## 裁决

**轮内封存默认保持关闭。** 正确性安全(必须带宪法保护)、能可靠削峰,但本工况
(flash + 前缀缓存 + 1M 窗口)无成本无质量收益,且有成本反弹风险。

**只在这些条件下值得开:** ① 上下文窗口小于单轮所需的模型(330K 塞不进 128K/256K);
② 实证存在"高峰值触发 rot"的任务/模型——本轮两个场景都没有。

**`protectEarlySteps` 是无条件保留的产出:** 即使封存不默认开,这条不变式也写死——
任何未来的轮内折叠都不得碰规则确立步。

## 复算

场景:`results/20260902-longturn-v2/scenarios-snapshot/`;逐 cell 账本:
`results/20260902-longturn-v2/` 与 `-v2-fixed/`;汇总 `scripts/ab-summary.mts`。
`results/` 自 2026-09-27 起不再纳入 Git,这些文件在 GitHub release `archive-legacy-results-2026-09-04` 里,恢复方法见 [results/README.md](../results/README.md)。
