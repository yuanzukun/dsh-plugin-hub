/**
 * tool-result-fold — 给 dsh 默认 transcript loop 加"轮内折叠"的独立插件(2026-09-04)。
 *
 * 机制:每步开始前(`agent/pre-step`,`prepend` 挂在最外层、拿到下游的 enter 判定之后才折),把上一步
 * 刚落盘的工具结果按内容路由折成紧凑视图,以 **surface 替换事件**遮蔽原节点(`surfaceOp: replace`,
 * 引用被遮蔽的 seq)——与 dsh 自带的 compaction-tool-result-pruner 同一机制,会话不变量明确允许
 * "引用被替换事件的内容改写"。
 * pre-step 路径把原文留在日志里,spill 路径把原文留在存储里;`expand_result` 逐字取回。
 * 已经发出的历史结果保持不变;新结果只在首次请求前折叠。检索返回的原文不再折叠。
 *
 * 路由规则复用 slice 的 result-digest(Headroom 式):代码不折,grep/glob 只在巨量命中时按文件配额折,
 * 日志错误优先,文档/数据留头尾与结构行。
 * 装载:默认 loop 不装 slice loop 也能用;slice loop 则无条件挂这一份副本(折叠只在这里做,slice 自己不折)。
 * 同一个 ctx 里不要再挂独立仓库那一份——两份都会注册 `expand_result`,重名注册直接失败。
 *
 * 定位(2026-09-09):折叠视图首行同时给出 `{turn, step, call}`(步内序号)和 `{seq}`(原结果的日志 seq,跨进程稳定);
 * `expand_result({"seq": N, "formatVersion": V})` 接受当前格式的折叠视图 seq——顺着 sourceEventSeqs[0] 回到原文。
 *
 * spill 臂(tools/post-execute)改写的是**落盘前**的内容,日志里只剩视图;所以视图首行必须带 spill locator,
 * expand_result 从 locator 读回原文。做不到(没有 spill 后端 / 存储失败)就不改写,留给 pre-step 在 surface 上折。
 * 它与 pre-step 共用同一份退避/钉住状态:已退避的工具资源、显式钉住步里的小结果,这条路同样不折。
 *
 * 恢复(resume / 插件晚挂):folder 建立时日志里最后一个 request/header、assistant/message 或 assistant/attempt 之前的追加态结果,
 * 已经原样给模型看过(上一进程发过请求),第一次 pre-step 不再折它们——折了会让整段前缀改写、缓存全失;
 * 只折之后新落盘的结果。之前进程留下的折叠替换仍按 restoreFold 逐个认领计数,退避阈值跨进程一致。
 */
import { Context, Service } from '@deepseek-ai/cordis'
import { isDeepStrictEqual } from 'node:util'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { freezeMessage } from '@deepseek-ai/dsh-llm'
import type { Session, SessionEvent, SessionSeq, ToolResultMessage } from '@deepseek-ai/dsh-session'
import { SESSION_FORMAT_VERSION, isAppendSurfaceEvent, isReplacementSurfaceEvent } from '@deepseek-ai/dsh-session'
import { defineTool, type PostToolDecision, type ToolDefinition, type ToolExecution, type ToolExecutionResult, type ToolRunContext } from '@deepseek-ai/dsh-tools'
import type { SpillStore } from '@deepseek-ai/dsh-spill'
import { fullResultAt, originalResultAt, resultBySeq, spillLocatorOf, loggedTextParts, originalPartText, originalResultText, type ResultLocator } from './results.js'
export { fullResultAt, originalResultAt, resultBySeq, spillLocatorOf, originalText } from './results.js'
import { digestToolResult, resolveDigestPolicy, type DigestPolicy } from '../slice/result-digest.js'

export const name = 'tool-result-fold'

export interface Config {
  /** 关掉后插件只注册 expand_result,不折任何结果。 */
  enabled?: boolean
  /** 折叠策略(阈值、头尾行数、日志上下文行数……),见 result-digest.ts。 */
  digest?: Partial<DigestPolicy>
  /** 可选的轮首位置保护(默认 0):显式指定时,前这么多步里的小结果保持原文。默认只按内容与体量判断。 */
  pinSteps?: number
  /** 显式钉住步骤中,仅保护少于此字符数的结果(默认 8000);更大结果仍按内容规则折叠。 */
  pinMaxChars?: number
  /** spill 预览臂(默认 50000 字节,约等于 dsh-base 的 spill-policy 默认 maxInlineTokens 12500 按 4 字节/token 折算;0 = 关):结果达到这个体量时,在 tools/post-execute
   *  就把原文存进 ctx.spillStore(有 spill 后端时),模型看到的是按内容路由的折叠视图 + 文件定位,而不是 spill-policy 的头尾预览。
   *  没挂 spill 后端时此臂不生效。read 结果与 spill-policy 同样跳过(它靠 pre-step 的 surface 替换折叠,原文留日志)。 */
  spillPreviewMinBytes?: number
  /** 展开退避(默认 2):同一工具/资源下这么多个不同的折叠结果块被完整取回、且取回率 ≥ 一半,
   *  本会话不再折该资源。资源为精确 file_path/path,没有路径则用键排序后的参数;局部与重复取回不触发退避。 */
  backoffAfterExpansions?: number
}

export const EXPAND_TOOL_NAME = 'expand_result'
/** slice loop 注册的整步召回工具;独立挂载时它不存在,可供性里就不能提(见 foldAffordance)。 */
const RECALL_STEP_TOOL_NAME = 'recall_step'
const RETRIEVAL_TOOLS = new Set([EXPAND_TOOL_NAME, RECALL_STEP_TOOL_NAME, 'recall_turn', 'recall_search'])

/** grep/glob 的措辞必须与 digestSearch 的实际契约一致:巨量命中会按文件配额折,并写明丢了多少
 *  (`src/slice/result-digest.ts` 的 searchMinMatches/searchMinChars/searchMaxPerFile 与 maxKeepRatio)。
 *  data 一句同理:digestData 保留头尾行与表格行,其余结构行按"每块前 structuredBlockMin 行 + 键新颖"筛选并受
 *  structuredBlockCap 约束——300 行同键 `item:` 只留 17 行,所以这里不能承诺"every structured line"。
 *  块上限也必须写进去:结构行占比 < 80% 的混合文档(散文夹着一串新键行)里,每块超过 structuredBlockCap 的行
 *  即便键全新也会被丢;只写"新键都留"同样是假话。阈值是可配的,所以这里只说"前几行 / 新键 / 十几行"而不写死数字;
 *  `tests/fold-plugin.spec.ts` 把措辞钉在行为上,cap=Infinity 与 cap 生效两条路径各有一例。 */
const FOLD_BODY = `Within the current turn, newly completed large tool results may be condensed before the next model request. Data and document reads keep their first and last lines, table rows, and structured lines (key = value, key: value, headings, section markers), except that a run of structured lines keeps only its first few lines, later lines whose key has not appeared yet, and at most a dozen or so lines per run; build/test/log output keeps every error, failure and warning line with surrounding context, stack traces and summary lines; source code is never condensed; grep/glob results are kept whole unless one search returns very many matches, and then each file keeps its first and last matching lines and an exact \`[... and N more matches in <file>]\` marker names what was dropped. Everything else is replaced by exact markers \`…[+N lines / M chars]…\`, and the view's first line names the call that returns the full result: ${EXPAND_TOOL_NAME}({"turn": t, "step": s, "call": n}) or ${EXPAND_TOOL_NAME}({"seq": N, "formatVersion": ${SESSION_FORMAT_VERSION}}) (N is the log id in the named format; use both values from a fresh locator), durable and one call away; add "grep": <regex> or "lines": "a-b" to get just the part you need, which is far cheaper than the whole result. Use the file tool's read limits: a condensed view represents only what the tool actually returned.`

/** 整步召回句:只有 ${RECALL_STEP_TOOL_NAME} 真的注册了才加,否则就是在宣告一个不存在的工具。 */
const RECALL_STEP_CLAUSE = ` The locator stays valid after the turn is sealed; ${RECALL_STEP_TOOL_NAME}({"turn": t, "step": s}) retrieves that step’s recorded calls and results, hydrating available spilled text and explicitly marking any unavailable preview.`

/** 系统提示词里的可供性说明:模型得知道视图是折过的、原文一步可取。 */
export function foldAffordance(hasRecallStep: boolean): string {
  return `<fold>\n${FOLD_BODY}${hasRecallStep ? RECALL_STEP_CLAUSE : ''}\n</fold>`
}

export const FOLD_AFFORDANCE = foldAffordance(false)

interface CallInfo { name: string; seq: number; path?: string; arguments?: unknown }
interface FoldView { message: ToolResultMessage; blocks: ReadonlyMap<number, string>; before: number; after: number; condensed: boolean }

function callPath(args: unknown): string | undefined {
  if (typeof args !== 'object' || args === null) return undefined
  const bag = args as Record<string, unknown>
  return typeof bag.file_path === 'string' ? bag.file_path : typeof bag.path === 'string' ? bag.path : undefined
}
function parseArgs(raw: unknown): unknown {
  if (typeof raw !== 'string') return raw
  try { return JSON.parse(raw) } catch { return undefined }
}
/** Stable JSON arguments group equivalent object key order without guessing resource aliases. */
function canonicalArguments(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonicalArguments)
  if (typeof value !== 'object' || value === null) return value
  return Object.fromEntries(Object.entries(value).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)
    .map(([key, item]) => [key, canonicalArguments(item)]))
}
/** Exact path identity is shared across read offsets; other calls retain their full argument identity. */
function backoffScope(tool: string, args: unknown): string {
  const parsed = parseArgs(args)
  const path = callPath(parsed)
  return JSON.stringify(path === undefined ? [tool, 'arguments', canonicalArguments(parsed)] : [tool, 'path', path])
}
function partialExpansion(args: { grep?: unknown; lines?: unknown }): boolean {
  // Match execute's filter selection: malformed/empty optional filters fall back to the full result.
  return (typeof args.grep === 'string' && Boolean(args.grep.trim()))
    || (typeof args.lines === 'string' && /^\d+\s*-\s*\d+$/.test(args.lines.trim()))
}
function resultChars(message: ToolResultMessage): number {
  let n = 0
  for (const inner of message.content) if (inner.type === 'text') n += inner.text.length
  return n
}
function headLine(text: string): { head: string; rest: string } {
  const nl = text.indexOf('\n')
  return nl === -1 ? { head: text, rest: '' } : { head: text.slice(0, nl), rest: text.slice(nl) }
}
/** 一个会话的折叠状态:处理游标、callId → 工具名/路径、统计。 */
class SessionFolder {
  private cursor = 0
  private readonly calls = new Map<string, CallInfo>()
  private readonly countedExpansions = new Set<string>()
  /** One full recovery per original result block, shared by all locator aliases and retrieval calls. */
  private readonly expandedBlocks = new Set<string>()
  /** Successful retrieval bytes keyed by their enclosing model call, never by a whole step/session. */
  private readonly retrievedByCall = new Map<number, Set<string>>()
  /** 每步的追加态结果计数(call 序号 = 该步第 n 个结果,expand_result 用同一规则定位)。 */
  private readonly ordinals = new Map<string, number>()
  private readonly originalAt = new Map<number, { turn: number; step: number; ordinal: number }>()
  private readonly countedFolds = new Set<number>()
  readonly stats = { folded: 0, charsBefore: 0, charsAfter: 0, expanded: 0, backedOff: [] as string[], spilled: 0 }
  /** (turn:step:call) → folded block ordinal → resource scope. */
  private readonly foldedAt = new Map<string, ReadonlyMap<number, string>>()
  private readonly perScope = new Map<string, { folded: number; expanded: number }>()
  /** 建 folder 时最后一个 request/header / assistant/message / assistant/attempt 的 seq:不晚于它的追加态结果已经原样发给过模型,不折。 */
  private readonly shownThrough: number
  /** 当前步(pre-step 记录);post-execute 的钉住判断用。 */
  step = 0
  constructor(private readonly session: Session, private readonly policy: DigestPolicy, private readonly pinSteps: number, private readonly backoffAfter: number, private readonly pinMaxChars: number) {
    let shown = -1
    for (const e of session.snapshotEvents()) {
      if (e.type === 'request/header' || e.type === 'assistant/message' || e.type === 'assistant/attempt') shown = e.seq
      // Failed/aborted or crash-orphaned turns can lack a settled attempt in
      // older/truncated logs. Exposure is uncertain: freeze their existing bytes.
      if (e.type === 'turn/end' && ['error', 'aborted', 'interrupted'].includes(e.data.reason.kind)) shown = e.seq
    }
    this.shownThrough = shown
  }

  pinned(step: number, chars: number): boolean {
    return step <= this.pinSteps && chars < this.pinMaxChars
  }

  backedOff(tool: string, args: unknown): boolean {
    return this.stats.backedOff.includes(backoffScope(tool, args))
  }

  /** 把游标之后新落盘的、仍在 surface 上的追加态工具结果折掉。 */
  async fold(): Promise<void> {
    const session = this.session
    const end = session.seq
    const onSurface = new Set<number>(session.surface.nodes as readonly number[])
    for (let i = this.cursor; i < end; i += 1) {
      const event = session.eventAt(i as SessionSeq) as SessionEvent | undefined
      if (event === undefined) continue
      if (event.type === 'tool/call') {
        const d = event.data as { callId: string; name: string; arguments?: unknown }
        this.calls.set(d.callId, { name: d.name, seq: event.seq, path: callPath(parseArgs(d.arguments)), arguments: parseArgs(d.arguments) })
        continue
      }
      if (event.type === 'tool/ptc-dispatch') {
        const d = event.data
        if (!d.isError && RETRIEVAL_TOOLS.has(d.name)) {
          const rootSeq = this.calls.get(d.rootCallId)?.seq
          if (d.name === EXPAND_TOOL_NAME && rootSeq !== undefined) this.noteExpansion(d.arguments, `${rootSeq}:${d.subCallId}`)
          for (const part of loggedTextParts(d.content)) {
            // The durable dispatch copy can be a spill preview. Live observations
            // already hold the full result; replay hydrates it when available.
            try { this.rememberRetrieval(rootSeq, await originalPartText(part, `dispatch ${d.subCallId}`)) } catch { /* unavailable spill is not evidence of forwarding */ }
          }
        }
        continue
      }
      if (event.type !== 'tool/result') continue
      if (isReplacementSurfaceEvent(event)) {
        this.restoreFold(event)
        continue
      }
      if (!isAppendSurfaceEvent(event)) continue
      const d = event.data as { turn: number; step: number; message: ToolResultMessage }
      // Session format V4: the tool-role message answers exactly one call.
      const id = String(d.message.toolCallId)
      const info = this.calls.get(id)
      if (!d.message.isError && info?.name === EXPAND_TOOL_NAME) this.noteExpansion(info.arguments, `${info.seq}:${id}`)
      const key = `${d.turn}:${d.step}`
      const n = (this.ordinals.get(key) ?? 0) + 1
      this.ordinals.set(key, n)
      this.originalAt.set(i, { turn: d.turn, step: d.step, ordinal: n })
      if (!onSurface.has(i) || i <= this.shownThrough) continue
      if (this.pinned(d.step, resultChars(d.message))) continue
      this.foldOne(i as SessionSeq, event as SessionEvent<'tool/result'>, d, n)
    }
    this.cursor = end
  }

  /** Successful retrievals remain call-counted telemetry; only distinct full blocks drive resource backoff. */
  /** Called after a successful outcome, not when a possibly failing call starts. */
  noteExpansion(args: unknown, callId: string): void {
    if (this.countedExpansions.has(callId)) return
    const a = (typeof args === 'object' && args !== null ? args : {}) as { seq?: unknown; formatVersion?: unknown; turn?: unknown; step?: unknown; call?: unknown; block?: unknown; grep?: unknown; lines?: unknown }
    let key: string
    if (a.seq !== undefined) {
      if (a.formatVersion !== SESSION_FORMAT_VERSION) return
      let at
      try { at = this.originalAt.get(originalResultAt(this.session.snapshotEvents(), Number(a.seq)).seq) } catch { return }
      if (at === undefined) return
      key = `${at.turn}:${at.step}:${at.ordinal}`
    } else key = `${Number(a.turn)}:${Number(a.step)}:${a.call === undefined ? 1 : Number(a.call)}`
    let blocks = this.foldedAt.get(key)
    if (a.block !== undefined) {
      const block = Number(a.block)
      if (!Number.isInteger(block) || block < 1) return
      const selected = blocks?.get(block)
      blocks = selected === undefined ? undefined : new Map([[block, selected]])
    }
    if (blocks === undefined) return
    this.countedExpansions.add(callId)
    this.stats.expanded += 1
    if (partialExpansion(a)) return
    for (const [block, scope] of blocks) {
      const identity = `${key}:${block}`
      if (this.expandedBlocks.has(identity)) continue
      this.expandedBlocks.add(identity)
      const t = this.perScope.get(scope) ?? { folded: 0, expanded: 0 }
      t.expanded += 1
      this.perScope.set(scope, t)
      if (t.expanded >= this.backoffAfter && t.expanded * 2 >= t.folded && !this.stats.backedOff.includes(scope)) this.stats.backedOff.push(scope)
    }
  }

  /** Resolve the current native model call, whose string id may be reused in later turns. */
  callSeq(callId: string): number | undefined {
    for (let i = this.session.seq - 1; i >= 0; i--) {
      const event = this.session.eventAt(i as SessionSeq)
      if (event?.type === 'tool/call' && event.data.callId === callId) return event.seq
    }
    return undefined
  }

  rememberRetrieval(callId: number | undefined, text: string): void {
    if (callId === undefined || !text) return
    let texts = this.retrievedByCall.get(callId)
    if (texts === undefined) this.retrievedByCall.set(callId, texts = new Set())
    texts.add(text)
  }

  /** A successful nested call alone is insufficient: the outer projection must
   * actually forward its complete text, either verbatim or as a JSON string. */
  forwardsRetrieval(callId: number | undefined, text: string): boolean {
    if (callId === undefined) return false
    for (const retrieved of this.retrievedByCall.get(callId) ?? []) {
      if (text.includes(retrieved) || text.includes(JSON.stringify(retrieved))) return true
    }
    return false
  }

  /**
   * Replay only replacements that exactly match this folder's deterministic
   * renderer and cited original. Other plugins' replacements do not count as
   * folds. Changing digest policy can prevent recognition of an old fold;
   * without a durable policy record we deliberately leave that count unknown.
   */
  private restoreFold(event: SessionEvent<'tool/result'>): void {
    if (event.sourceEventSeqs?.length !== 1) return
    const source = event.sourceEventSeqs[0]!
    if (this.countedFolds.has(source)) return
    const at = this.originalAt.get(source)
    const original = this.session.eventAt(source)
    if (at === undefined || original?.type !== 'tool/result' || !isAppendSurfaceEvent(original)) return
    // A fold written before a session-format upgrade keeps its frozen hint, e.g.
    // `"formatVersion": 3` in a V3 session restored as V4: rebuild with each older
    // version the replacement itself names, so its count and backoff survive the resume.
    const text = event.data.message.content.map((part) => part.type === 'text' ? part.text : '').join('\n')
    const older = [...new Set([...text.matchAll(/"formatVersion": (\d+)\}\) returns the full text\]/g)].map((match) => Number(match[1])))]
      .filter((version) => version < SESSION_FORMAT_VERSION)
    for (const version of [SESSION_FORMAT_VERSION, ...older]) {
      const view = this.buildFold(original.data, at.ordinal, source, version)
      if (view === undefined || !isDeepStrictEqual(view.message, event.data.message)) continue
      this.recordFold(source, at.turn, at.step, at.ordinal, view)
      return
    }
  }

  private buildFold(d: { turn: number; step: number; message: ToolResultMessage }, n: number, seq: number, formatVersion: number = SESSION_FORMAT_VERSION): FoldView | undefined {
    let changed = false
    let condensed = false
    let before = 0
    let after = 0
    const blocks = new Map<number, string>()
    const hint = `${EXPAND_TOOL_NAME}({"turn": ${d.turn}, "step": ${d.step}, "call": ${n}}) or ${EXPAND_TOOL_NAME}({"seq": ${seq}, "formatVersion": ${formatVersion}})`
    // Session format V4: the tool-role message is the single result block (block 1).
    const message = d.message
    if (message.isError) return undefined
    const info = this.calls.get(String(message.toolCallId)) ?? { name: 'tool', seq: -1 }
    if (RETRIEVAL_TOOLS.has(info.name) || this.backedOff(info.name, info.arguments)) return undefined
    const content = message.content.map((b) => {
      if (b.type !== 'text') return b
      if (this.forwardsRetrieval(info.seq, b.text)) return b
      before += b.text.length
      if (spillLocatorOf(b.text) !== undefined) {
        // post-execute 已把原文存进 spill store、视图落了盘:不再折,只在首行补上 expand_result 定位(此时还没发过,替换零成本)。
        changed = true
        const { head, rest } = headLine(b.text)
        const text = `${head.slice(0, -1)} · ${hint} returns the full text]${rest}`
        after += text.length
        return { ...b, text }
      }
      const r = digestToolResult(b.text, { tool: info.name, ...(info.path ? { path: info.path } : {}) }, this.policy)
      if (!r.digested) {
        after += b.text.length
        return b
      }
      changed = condensed = true
      const text = `[${info.name}${info.path ? ' ' + info.path : ''} · ${r.kind} · ${r.totalLines} lines, ${r.keptLines} kept · ${hint} returns the full text]\n${r.text}`
      after += text.length
      return { ...b, text }
    })
    if (!changed) return undefined
    blocks.set(1, backoffScope(info.name, info.arguments))
    return { message: freezeMessage<ToolResultMessage>({ ...message, content }), blocks, before, after, condensed }
  }

  private recordFold(seq: number, turn: number, step: number, n: number, view: FoldView): void {
    if (this.countedFolds.has(seq)) return
    this.countedFolds.add(seq)
    if (view.condensed) {
      this.stats.folded += 1
      this.stats.charsBefore += view.before
      this.stats.charsAfter += view.after
    }
    this.foldedAt.set(`${turn}:${step}:${n}`, view.blocks)
    for (const scope of view.blocks.values()) {
      const t = this.perScope.get(scope) ?? { folded: 0, expanded: 0 }
      t.folded += 1
      this.perScope.set(scope, t)
    }
  }

  private foldOne(seq: SessionSeq, event: SessionEvent<'tool/result'>, d: { turn: number; step: number; message: ToolResultMessage }, n: number): void {
    const view = this.buildFold(d, n, seq)
    if (view === undefined) return
    this.session.append('tool/result', { ...(event.data as object), message: view.message } as never, {
      surfaceOp: { op: 'replace', startSeq: seq, endSeq: seq },
      sourceEventSeqs: [seq],
    })
    this.recordFold(seq, d.turn, d.step, n, view)
  }
}

/** 部分取回(2026-09-04):按正则取匹配行(±2 行上下文)或按行号区间——比整份取回便宜得多;s10 的 64 次整份取回、f9 的散文事实都是它的场景。 */
export function partialByGrep(text: string, pattern: string, head: string): string {
  let re: RegExp
  try { re = new RegExp(pattern, 'i') } catch { throw new Error(`expand_result: invalid regex ${JSON.stringify(pattern)}`) }
  const lines = text.split('\n')
  const hits: number[] = []
  for (let i = 0; i < lines.length; i += 1) if (re.test(lines[i]!)) hits.push(i)
  if (hits.length === 0) return `[${head} · 0 of ${lines.length} lines match /${pattern}/i]`
  const keep = new Set<number>()
  for (const i of hits) for (let k = Math.max(0, i - 2); k <= Math.min(lines.length - 1, i + 2); k += 1) keep.add(k)
  const out: string[] = []
  let prev = -1
  for (const i of [...keep].sort((x, y) => x - y)) {
    if (prev !== -1 && i > prev + 1) out.push(`…[${i - prev - 1} lines]…`)
    out.push(`${i + 1}: ${lines[i]!}`)
    prev = i
  }
  const shown = Math.min(hits.length, 200)
  return `[${head} · ${hits.length} of ${lines.length} lines match /${pattern}/i${hits.length > 200 ? ', first 200 shown' : ''}]\n${out.slice(0, shown * 5 + 200).join('\n')}`
}

export function partialByLines(text: string, range: string, head: string): string {
  const m = /^(\d+)\s*-\s*(\d+)$/.exec(range.trim())!
  const lines = text.split('\n')
  const a = Math.max(1, Number(m[1])); const b = Math.min(lines.length, Number(m[2]))
  if (b < a) throw new Error(`expand_result: empty range ${range} (result has ${lines.length} lines)`)
  return `[${head} · lines ${a}-${b} of ${lines.length}]\n${lines.slice(a - 1, b).map((l, i) => `${a + i}: ${l}`).join('\n')}`
}

export function expandResultToolDefinition(): ToolDefinition {
  return defineTool({
    name: EXPAND_TOOL_NAME,
    description: 'Return the text of a tool result that the host condensed on entry. The condensed view\'s first line names the call two ways: `seq` (the log id, paired with the formatVersion printed in the same fresh locator) or turn, step and the result\'s ordinal within that step (1-based). Pass `grep` to get only the lines matching a regex (with 2 lines of context) or `lines` as "start-end" for a line range — both are much cheaper than the whole result; omit both for the full text.',
    parameters: {
      formatVersion: { type: 'number', description: `Required with seq: use ${SESSION_FORMAT_VERSION} from a fresh locator. Old-format sequence numbers must not be relabelled; request a fresh recall_turn dialogue or recall_search locator, or use turn/step/call.` },
      seq: { type: 'number', description: 'Durable log id from the condensed view\'s first line; requires formatVersion from the same fresh locator; when given, turn/step/call are ignored.' },
      turn: { type: 'number', description: 'Turn number from the condensed view\'s first line (required without seq).' },
      step: { type: 'number', description: 'Step number from the condensed view\'s first line (required without seq).' },
      call: { type: 'number', description: 'Which result of that step (1-based; default 1).' },
      block: { type: 'number', description: 'Optional; each result is a single block, so only 1 is valid. Omit it.' },
      grep: { type: 'string', description: 'Case-insensitive regex: return only matching lines, each with 2 lines of context, and a count of matches.' },
      lines: { type: 'string', description: 'Line range "start-end" (1-based, inclusive), e.g. "120-180".' },
    },
    output: {
      schema: { type: 'string' as const },
      render: (_args: unknown, value: string) => [{ type: 'text' as const, text: value }],
    },
    execute: async (args: unknown, exec: ToolRunContext): Promise<string> => {
      const agent = exec.agent as Agent | undefined
      if (agent === undefined) throw new Error(`${EXPAND_TOOL_NAME} runs only inside an agent loop`)
      const a = args as { seq?: unknown; formatVersion?: unknown; turn?: unknown; step?: unknown; call?: unknown; block?: unknown; grep?: unknown; lines?: unknown }
      const events = agent.session.snapshotEvents() as readonly SessionEvent[]
      let locator: ResultLocator
      let head: string
      const block = a.block === undefined ? undefined : Number(a.block)
      if (block !== undefined && (!Number.isInteger(block) || block < 1)) throw new Error(`${EXPAND_TOOL_NAME}: \"block\" must be a positive integer`)
      if (a.seq !== undefined) {
        if (a.formatVersion !== SESSION_FORMAT_VERSION) {
          throw new Error(`${EXPAND_TOOL_NAME}: numeric seq requires formatVersion ${SESSION_FORMAT_VERSION} from a fresh locator; sequence numbers can change during format migration. Do not relabel an old locator. Obtain a fresh locator from recall_turn({"turn":"N","view":"dialogue"}) or recall_search, or use the stable {"turn":N,"step":M,"call":K} address.`)
        }
        const seq = Number(a.seq)
        if (!Number.isInteger(seq) || seq < 0) throw new Error(`${EXPAND_TOOL_NAME}: "seq" must be a non-negative integer`)
        const r = resultBySeq(events, seq, block)
        locator = { seq }
        head = `${r.name} · seq ${r.seq} (turn ${r.turn} step ${r.step} call ${r.call})`
      } else {
        const turn = Number(a.turn); const step = Number(a.step); const call = a.call === undefined ? 1 : Number(a.call)
        if (!Number.isInteger(turn) || !Number.isInteger(step) || turn < 1 || step < 1 || !Number.isInteger(call) || call < 1) {
          throw new Error(`${EXPAND_TOOL_NAME} needs {"seq": N, "formatVersion": ${SESSION_FORMAT_VERSION}} or {"turn": N, "step": M} (and optional "call": K), all positive integers`)
        }
        const found = fullResultAt(events, turn, step, call, block)
        if (found === null) throw new Error(`no tool result recorded at turn ${turn} step ${step} call ${call}`)
        locator = { turn, step, call }
        head = `${found.name} · turn ${turn} step ${step} call ${call}`
      }
      if (block !== undefined) head += ` block ${block}`
      const text = await originalResultText(events, locator, head, block)
      if (typeof a.grep === 'string' && a.grep.trim()) return partialByGrep(text, a.grep, head)
      if (typeof a.lines === 'string' && /^\d+\s*-\s*\d+$/.test(a.lines.trim())) return partialByLines(text, a.lines, head)
      return `[full result of ${head}]\n${text}`
    },
  })
}

/** 供 runner/评测读取:某会话的折叠统计。 */
export const FOLD_STATS = new WeakMap<Session, SessionFolder['stats']>()

/** cordis 插件本体:声明注入的服务(tools、systemPrompt),挂载即生效,卸载即回收(ctx.effect)。 */
export class ToolResultFold extends Service {
  static inject = ['tools', 'systemPrompt']

  constructor(ctx: Context, config: Config = {}) {
    super(ctx, 'toolResultFold')
    const policy = resolveDigestPolicy(config.digest)
    const enabled = config.enabled ?? true
    const pinSteps = config.pinSteps ?? 0
    if (!Number.isInteger(pinSteps) || pinSteps < 0) throw new Error('pinSteps must be a non-negative integer')
    const pinMaxChars = config.pinMaxChars ?? 8_000
    if (!(pinMaxChars >= 0)) throw new Error('pinMaxChars must be >= 0')
    const backoffAfter = config.backoffAfterExpansions ?? 2
    if (!Number.isInteger(backoffAfter) || backoffAfter < 1) throw new Error('backoffAfterExpansions must be an integer >= 1')
    ctx.effect(() => ctx.tools.register(expandResultToolDefinition()), 'toolResultFold.expandResult()')
    if (!enabled) return
    ctx.effect(
      () => ctx.systemPrompt.section({
        name: 'fold:affordance', order: -900,
        // 每次装配现算一次(结果对同一装载是恒定的,前缀缓存不受影响):slice loop 挂着时才提 recall_step。
        text: (assembly) => foldAffordance(ctx.tools.get(RECALL_STEP_TOOL_NAME, assembly.scope) !== undefined),
      }),
      'toolResultFold.affordance()',
    )
    const folders = new WeakMap<Session, SessionFolder>()
    const folderFor = (session: Session): SessionFolder => {
      let folder = folders.get(session)
      if (folder === undefined) {
        folder = new SessionFolder(session, policy, pinSteps, backoffAfter, pinMaxChars)
        folders.set(session, folder)
        FOLD_STATS.set(session, folder.stats)
      }
      return folder
    }
    const spillMin = config.spillPreviewMinBytes ?? 50_000
    if (!(spillMin >= 0)) throw new Error('spillPreviewMinBytes must be >= 0')
    // Observe final successes so nested retrievals affect backoff even before
    // their enclosing run_code settles. Durable replay deduplicates by call id.
    ctx.on('tools/result', (exec, result) => {
      if (result.isError || !RETRIEVAL_TOOLS.has(exec.name) || exec.agent === undefined) return
      const folder = folderFor(exec.agent.session)
      const rootSeq = folder.callSeq(exec.rootCallId)
      if (exec.name === EXPAND_TOOL_NAME && rootSeq !== undefined) folder.noteExpansion(exec.arguments, `${rootSeq}:${exec.callId}`)
      if (exec.parent !== undefined) for (const part of result.content) if (part.type === 'text') folder.rememberRetrieval(rootSeq, part.text)
    })
    {
      // 跑在 spill-policy 的 next() 里(它是 prepend 的):我们先把超大结果换成折叠视图 + 定位,它再看到的就是小结果,不会二次 spill。
      // 这里改写的是落盘前的内容,所以只有 saveText 成功、视图首行带上 locator 才改写;否则原样放行,留给 pre-step 在 surface 上折。
      ctx.on('tools/post-execute', async (exec: ToolExecution, result: Readonly<ToolExecutionResult>, next: () => Promise<PostToolDecision>): Promise<PostToolDecision> => {
        const downstream = await next()
        if (downstream.kind !== 'accept' || Object.hasOwn(downstream, 'value') || Object.hasOwn(downstream, 'content')) return downstream
        if (result.isError) return downstream
        const agent = exec.agent as Agent | undefined
        if (agent === undefined) return downstream
        const folder = folderFor(agent.session)
        // Preserve the successful canonical value through generic spill-policy's
        // documented value-replacement path. This re-renders the same content;
        // errors and downstream content/value decisions remain untouched.
        if (RETRIEVAL_TOOLS.has(exec.name) || result.content.some((part) => part.type === 'text' && folder.forwardsRetrieval(folder.callSeq(exec.rootCallId), part.text))) {
          return { kind: 'accept', value: result.value, ...(downstream.additionalContexts ? { additionalContexts: downstream.additionalContexts } : {}) }
        }
        if (spillMin === 0 || exec.parent !== undefined || exec.name === 'read' || exec.name === 'read_file') return downstream
        const store = ctx.get('spillStore') as SpillStore | undefined
        if (store === undefined) return downstream
        const texts = result.content.filter((b): b is { type: 'text'; text: string } => b.type === 'text' && typeof (b as { text?: unknown }).text === 'string')
        const full = texts.map((b) => b.text).join('\n')
        if (Buffer.byteLength(full, 'utf8') < spillMin) return downstream
        // 与 pre-step 同一份退避/钉住状态:模型已完整取回同一资源的多个不同结果,这条路也不再折。
        if (folder.backedOff(exec.name, exec.arguments) || folder.pinned(folder.step, full.length)) return downstream
        const path = callPath(parseArgs(exec.arguments))
        const r = digestToolResult(full, { tool: exec.name, ...(path ? { path } : {}) }, policy)
        if (!r.digested) return downstream
        let ref
        try {
          ref = await store.saveText({ owner: { sessionId: agent.session.id }, source: { toolName: exec.name, callId: String((exec as { callId?: unknown }).callId ?? ''), label: 'result' }, suggestedName: `${exec.name}.txt`, content: full } as never)
        } catch { return downstream }
        const text = `[${exec.name}${path ? ' ' + path : ''} · ${r.kind} · ${r.totalLines} lines, ${r.keptLines} kept · full text (${ref.bytes} bytes) stored at ${ref.locator} — ${ref.retrievalHint}]\n${r.text}`
        if (spillLocatorOf(text) === undefined) return downstream   // 定位行必须能被 expand_result 解析回去,否则原文不可取回,不改写
        folder.stats.spilled += 1
        return { ...downstream, content: [...result.content.filter((b) => b.type !== 'text'), { type: 'text', text }] as never }
      })
    }
    // 折在 next() 之后:下游(slice loop 的步数上限、宿主的中止)可能把这一步判成非 enter,
    // 那一步不再构造请求,先折就是一次没人看的 surface 替换 + 日志写入(A-RT-12)。
    // enter 之后仍然早于请求构造(agent/request),折叠视图照常进这一步的请求。
    // folder 在 next() 之前建:shownThrough 取的是恢复时日志的样子,不受下游 pre-step 追加的事件影响。
    ctx.on('agent/pre-step', async ({ agent, step }, next) => {
      const folder = folderFor((agent as Agent).session)
      const decision = await next()
      if (decision.kind !== 'enter') return decision
      folder.step = step
      await folder.fold()
      return decision
    }, { prepend: true })
  }
}

declare module '@deepseek-ai/cordis' {
  interface Context {
    toolResultFold: ToolResultFold
  }
}

export default ToolResultFold
