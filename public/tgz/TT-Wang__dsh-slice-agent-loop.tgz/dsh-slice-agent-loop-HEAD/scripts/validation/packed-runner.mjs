import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { pathToFileURL } from 'node:url'
import { writeFile, mkdir } from 'node:fs/promises'
import { realpathSync } from 'node:fs'
import { join } from 'node:path'
/** @typedef {import('@deepseek-ai/dsh-agent').Agent} HostAgent */
/** @typedef {import('@deepseek-ai/dsh-system-prompt').default} HostSystemPrompt */
const host = createRequire(realpathSync(new URL('./node_modules/@deepseek-ai/dsh/package.json', import.meta.url)))
/** @type {typeof import('@deepseek-ai/dsh-llm')} */
const llm = await import(pathToFileURL(host.resolve('@deepseek-ai/dsh-llm')).href)
/** @type {typeof import('@deepseek-ai/dsh-session')} */
const sessions = await import(pathToFileURL(host.resolve('@deepseek-ai/dsh-session')).href)
export const name = 'slice-packed-validation-runner'
export const inject = ['llm', 'agents', 'sessions', 'systemPrompt', 'tools']
/** @param {string} value @returns {import('@deepseek-ai/dsh-llm').StreamChunk[]} */
const text = value => [
  { type: 'block-start', index: 0, blockType: 'text' },
  { type: 'text-delta', index: 0, text: value },
  { type: 'block-end', index: 0, block: { type: 'text', text: value } },
  { type: 'usage', usage: { inputTokens: 10, outputTokens: 3 } },
  { type: 'finish', reason: { kind: 'stop' } },
]
/** @param {string} id @param {string} name @param {object} args @returns {import('@deepseek-ai/dsh-llm').StreamChunk[]} */
const tool = (id, name, args) => [
  { type: 'block-start', index: 0, blockType: 'tool-call' },
  { type: 'block-end', index: 0, block: { type: 'tool-call', id: llm.ToolCallId(id), name, arguments: JSON.stringify(args) } },
  { type: 'usage', usage: { inputTokens: 10, outputTokens: 3 } },
  { type: 'finish', reason: { kind: 'tool-calls' } },
]
// Exceed both former excerpt defaults and put evidence in the middle, where
// a head/tail renderer would silently remove it. No network/model call needed.
const secondUser = `Recall the first turn\n${'u'.repeat(5_000)}\nPACKED_USER_MIDDLE\n${'v'.repeat(5_000)}`
const secondAnswer = `  PACKED_SECOND_ANSWER\n${'a'.repeat(5_000)}\nPACKED_ASSISTANT_MIDDLE\n${'b'.repeat(5_000)}\n  `
const intermediateAnswer = 'PACKED_INTERMEDIATE_ASSISTANT'
// V4 source kinds are merge-extensible strings; producers outside this
// compilation (runtime-context, plugin:<name>) are not in the static union.
/** @param {{source?: {kind?: unknown}}|null|undefined} message @returns {string|undefined} */
const sourceKind = message => typeof message?.source?.kind === 'string' ? message.source.kind : undefined
/** @param {import('@deepseek-ai/cordis').Context} ctx @param {{outputDir:string}} config */
export function apply(ctx, config) {
  const appExit = /** @type {((code:number)=>void)|undefined} */ (ctx.get('appExit'))
  if (appExit === undefined) throw new Error('dsh launcher appExit is required')
  const exit = appExit
  /** @type {{request: Omit<import('@deepseek-ai/dsh-llm').GenerateOptions,'signal'> & {signal:undefined}, events:readonly import('@deepseek-ai/dsh-session').SessionEvent[]}[]} */
  const requests = []
  /** @type {string[]} */
  const errors = []
  const recallResponse = tool('packed-recall', 'recall_turn', { turn: '1' })
  // Text followed by a tool call in the same model response, then another
  // assistant response in that turn: both texts must survive sealing.
  recallResponse.unshift(
    { type: 'block-start', index: 1, blockType: 'text' },
    { type: 'text-delta', index: 1, text: intermediateAnswer },
    { type: 'block-end', index: 1, block: { type: 'text', text: intermediateAnswer } },
  )
  const responses = [text('PACKED_FIRST_ANSWER'), recallResponse, text(secondAnswer), text('PACKED_THIRD_ANSWER'), text('PACKED_RESUMED_ANSWER')]
  class Adapter extends llm.LlmAdapter {
    /** @param {string} provider @param {string} model @returns {Promise<import('@deepseek-ai/dsh-llm').LlmResolvedModelInfo>} */
    async resolveModel(provider, model) { return { provider, id: model, name: model, inputModalities: ['text', 'image'], reasoning: { efforts: [{ id: llm.ReasoningEffortId('high'), name: 'High' }, { id: llm.ReasoningEffortId('low'), name: 'Low' }], defaultEffort: llm.ReasoningEffortId('high') } } }
    /** @param {import('@deepseek-ai/dsh-llm').GenerateOptions} request */
    async *stream(request) {
      const session = request.sessionId === undefined ? undefined : ctx.sessions.get(request.sessionId)
      assert.ok(session)
      assert.equal(request.reasoningEffort, 'high', 'the shipped default must inherit the adapter effort, including after resume')
      assert.deepEqual(request.messages, session.deriveMessages())
      const events = structuredClone(session.snapshotEvents())
      const nodes = sessions.foldSurface(events).nodes
      assert.deepEqual(request.messages, nodes.map(seq => sessions.deriveEventMessage(events[seq])).filter(Boolean))
      const header = sessions.foldRequestHeader(events)
      assert.ok(header, 'every dispatched request must have a native header')
      assert.deepEqual(request.tools ?? [], header.tools ?? [])
      // Session format V4: the system prompt is surface node 0, a system/message
      // event replaced in place; loop-built requests leave request.system unset.
      assert.equal(request.system, undefined, 'the system prompt must travel only as message 0')
      assert.equal(events[nodes[0]]?.type, 'system/message', 'surface node 0 must be the native system/message event')
      assert.equal(request.messages[0]?.role, 'system', 'the native system prompt must remain at the surface head')
      assert.equal(request.messages.filter(message => message.role === 'system').length, 1)
      const system = request.messages[0].content.filter(block => block.type === 'text').map(block => block.text).join('\n')
      assert.ok(system.includes('Packed plugin validation fixture.'))
      assert.ok(system.includes('<slice>'))
      // Since 0.1.7 DSH projects the runtime snapshot after it opens the turn, so the
      // snapshot belongs to turn 1 and recall_turn serves it back verbatim as
      // generated context. Only that explicit recall result may repeat it; the
      // surface itself (system, users, tape, assistant) carries one live copy.
      const texts = (/** @type {import('@deepseek-ai/dsh-llm').Message} */ message) => message.content.flatMap(block => block.type === 'text' ? [block.text] : [])
      const surface = request.messages.filter(message => message.role !== 'tool')
      assert.equal(surface.flatMap(texts).join('\n').split('PACKED_RUNTIME_SENTINEL').length, 2, 'the surface must carry exactly one runtime snapshot')
      const runtime = surface.filter(message => texts(message).some(value => value.includes('PACKED_RUNTIME_SENTINEL')))
      assert.deepEqual(runtime.map(message => sourceKind(message)), ['runtime-context'], 'the runtime snapshot must carry the V4 runtime-context source')
      const repeated = request.messages.filter(message => message.role === 'tool' && texts(message).some(value => value.includes('PACKED_RUNTIME_SENTINEL')))
      assert.ok(repeated.every(message => message.role === 'tool' && message.toolCallId === 'packed-recall'), 'only the recall result may repeat the runtime snapshot')
      requests.push({ request: structuredClone({ ...request, signal: undefined }), events })
      const response = responses.shift()
      assert.ok(response, 'unexpected extra model request')
      for (const chunk of response) yield chunk
    }
  }
  ctx.effect(() => ctx.llm.registerAdapter(['packed-mock'], new Adapter()))
  ctx.effect(() => ctx.systemPrompt.context({ name: 'packed-runtime', order: 50, text: 'PACKED_RUNTIME_SENTINEL' }))
  ctx.on('agent/error', ({ error }) => { errors.push(String(error)) })
  async function run() {
    await (/** @type {{await(): Promise<void>}|undefined} */ (ctx.get('loader')))?.await()
    const handle = await ctx.agents.create({ sessionId: sessions.SessionId('packed-loader-session'), meta: { cwd: process.cwd() }, agentOptions: { provider: 'packed-mock', model: 'deterministic' } })
    for (const value of ['First packed request', secondUser, 'Third packed request']) {
      handle.agent.followup(llm.createUserMessage({ content: [{ type: 'text', text: value }], source: { kind: 'user' } }))
      await handle.agent.whenIdle()
    }
    assert.deepEqual(errors, [])
    assert.equal(requests.length, 4)
    const before = structuredClone(handle.agent.session.snapshotEvents())
    /** @param {readonly import('@deepseek-ai/dsh-session').SessionEvent[]} events */
    const tapeNodes = events => sessions.foldSurface(events).nodes.filter(seq => {
      const event = events[seq]
      return sessions.isReplacementSurfaceEvent(event)
        && sessions.deriveEventMessage(event)?.content.some(block => block.type === 'text' && block.text.startsWith('[slice tape v1'))
    })
    // Default keepRecentTurns=0 seals turn 1 before turn 2's first request.
    // Check actual retained content and provenance, not just a marker anywhere
    // in the log: the same entry must remain visible through turn 3 and resume.
    const firstTape = tapeNodes(requests[1].events)
    assert.equal(firstTape.length, 1, 'the shipped default must seal the first completed turn')
    const firstEntrySeq = firstTape[0]
    const firstEntry = requests[1].events[firstEntrySeq]
    assert.ok(JSON.stringify(sessions.deriveEventMessage(firstEntry)).includes('PACKED_FIRST_ANSWER'))
    // The V3->V4 migration names every third-party plugin source 'plugin:' +
    // its original name; slice writes new tape entries under the same kind.
    assert.equal(sourceKind(sessions.deriveEventMessage(firstEntry)), 'plugin:slice:history', 'tape entries must carry the slice history source kind')
    for (const { events } of requests.slice(1)) {
      assert.ok(tapeNodes(events).includes(firstEntrySeq), 'a sealed entry must remain on the surface')
      assert.deepEqual(events[firstEntrySeq], firstEntry, 'a sealed entry must remain frozen')
    }
    assert.equal(tapeNodes(before).length, 2, 'turn 2 must also seal before turn 3')
    const originalUser = requests[1].events.find(event => {
      const message = sessions.deriveEventMessage(event)
      return message?.role === 'user' && message.content.some(block => block.type === 'text' && block.text === secondUser)
    })
    assert.ok(originalUser, 'turn 2 must have an original long user node')
    /** @param {readonly import('@deepseek-ai/dsh-session').SessionEvent[]} events */
    const checkDialogue = events => {
      const nodes = sessions.foldSurface(events).nodes
      assert.ok(nodes.includes(originalUser.seq), 'the later long user message must remain at its original node')
      assert.deepEqual(events[originalUser.seq], originalUser)
      const texts = nodes.flatMap(seq => sessions.deriveEventMessage(events[seq])?.content.flatMap(block => block.type === 'text' ? [block.text] : []) ?? [])
      assert.equal(texts.filter(value => value.includes(secondUser)).length, 1, 'the user text must not be copied into tape')
      const entryTexts = tapeNodes(events).map(seq => sessions.deriveEventMessage(events[seq])?.content.flatMap(block => block.type === 'text' ? [block.text] : []).join('\n') ?? '')
      const secondEntry = entryTexts.find(value => value.includes('PACKED_SECOND_ANSWER'))
      assert.ok(secondEntry, 'turn 2 must have a sealed entry')
      assert.ok(secondEntry.includes(secondAnswer), 'the complete assistant text including its middle and whitespace must survive sealing')
      assert.ok(secondEntry.includes(intermediateAnswer), 'earlier assistant text in the same turn must survive sealing')
      assert.ok(secondEntry.indexOf(intermediateAnswer) < secondEntry.indexOf(secondAnswer), 'assistant texts must retain their order')
    }
    checkDialogue(before)
    assert.ok(before.every(event => sessions.KNOWN_SESSION_EVENT_TYPES.has(event.type)), 'no unknown required plugin events')
    // V4 tool results are tool-role messages; the tool-result block wrapper is gone.
    const recallResult = before.find(event => event.type === 'tool/result' && event.data.message.toolCallId === 'packed-recall')
    assert.ok(recallResult?.type === 'tool/result', 'the recall call must have a durable result')
    assert.equal(recallResult.data.message.role, 'tool')
    assert.equal(sourceKind(recallResult.data.message), 'tool')
    assert.notEqual(recallResult.data.message.isError, true, 'recall_turn must succeed')
    assert.ok(JSON.stringify(recallResult).includes('First packed request'))
    // Sealed tool lines cite durable results by numeric seq in the host's
    // current session format; both supported hosts (0.2.0-rc.2 and 0.2.1-rc.2) write V4.
    assert.equal(sessions.SESSION_FORMAT_VERSION, 4, 'the supported hosts write session format V4')
    const locator = `expand_result(${JSON.stringify({ seq: recallResult.seq, formatVersion: sessions.SESSION_FORMAT_VERSION })})`
    assert.ok(tapeNodes(before).some(seq => JSON.stringify(sessions.deriveEventMessage(before[seq])).includes(JSON.stringify(locator).slice(1, -1))), 'the sealed tool line must cite the recall result with a V4 seq locator')
    // Generated context is labelled by its V4 source kind, not a V3 plugin name.
    assert.ok(JSON.stringify(recallResult).includes('[runtime-context]\\nCurrent runtime context'), 'recall must serve the turn\'s runtime snapshot under its V4 source kind')
    await ctx.sessions.flush(handle.agent.session)
    await handle.dispose()
    const resumed = await ctx.agents.resume({ resumeSessionId: sessions.SessionId('packed-loader-session'), agentOptions: { provider: 'packed-mock', model: 'deterministic' } })
    assert.deepEqual(resumed.agent.session.snapshotEvents().slice(0, before.length), before)
    resumed.agent.followup(llm.createUserMessage({ content: [{ type: 'text', text: 'Resume packed request' }], source: { kind: 'user' } }))
    await resumed.agent.whenIdle()
    await ctx.sessions.flush(resumed.agent.session)
    assert.equal(requests.length, 5)
    assert.deepEqual(errors, [])
    const finalEvents = structuredClone(resumed.agent.session.snapshotEvents())
    assert.ok(tapeNodes(finalEvents).includes(firstEntrySeq), 'resume must retain the original sealed entry')
    assert.deepEqual(finalEvents[firstEntrySeq], firstEntry)
    assert.equal(tapeNodes(finalEvents).length, 3, 'resume must seal the previous completed turn')
    checkDialogue(finalEvents)
    const summary = { status: 'passed', dsh: host('@deepseek-ai/dsh/package.json').version, requests: requests.length, turns: 4, persistenceReload: true, adapterEffortInherited: true, sessionFormatVersion: sessions.SESSION_FORMAT_VERSION, nativeSystemMessageRetained: true, systemPromptNodeZero: true, runtimeContextSource: true, tapeSourceKind: 'plugin:slice:history', frozenTapeRetained: true, originalUserNodeRetained: true, completeAssistantTextsRetained: true, tapeEntries: tapeNodes(finalEvents).length, replacements: finalEvents.filter(sessions.isReplacementSurfaceEvent).length, errors }
    await mkdir(config.outputDir, { recursive: true })
    await writeFile(join(config.outputDir, 'requests.json'), JSON.stringify(requests, null, 2) + '\n')
    await writeFile(join(config.outputDir, 'events.json'), JSON.stringify(finalEvents, null, 2) + '\n')
    await writeFile(join(config.outputDir, 'summary.json'), JSON.stringify(summary, null, 2) + '\n')
    process.stdout.write(JSON.stringify(summary) + '\n')
    exit(0)
  }
  void run().catch(async error => {
    process.stderr.write((error.stack ?? String(error)) + '\n')
    await writeFile(join(config.outputDir, 'failure.txt'), error.stack ?? String(error)).catch(() => {})
    exit(1)
  })
}
