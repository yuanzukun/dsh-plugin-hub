# UI 对齐与 0.5.0 收尾计划（2026-10-20）

> 本文是 2026-10-20 前两轮局部收尾记录；它的 P0–P4 小范围与本轮“尽量 100% 还原 opencode v2 TUI”目标不等价。完整迁移范围、数据模型前置条件与最终验收标准以 [PLAN_OPENCODE_V2_PARITY_2026-10-20.md](PLAN_OPENCODE_V2_PARITY_2026-10-20.md) 为准；本文只保留为历史进度记录。

> 触发：0.5.0 的本地构建已通过门禁，但按实机截图验收不通过——聊天区、输入框、顶栏会话标签页
> 与 opencode v2 差距明显，且旧会话标题读取会刷错误 toast。**0.5.0 不作为发布版本**：本地
> `v0.5.0` tag 已删除，npm / GitHub release 均不发布；验收清单全绿之前不再打 tag。
>
> 参考实现来自本机 vendored 的 opencode dev 源码：`tmp/opencode-src/packages/tui/src/`
> （`component/prompt/index.tsx`、`component/session-tabs.tsx`、`context/session-tabs.tsx`、
> `context/session-tabs-model.ts`、`config/keybind.ts`、`config/index.tsx`、`routes/session/`）。

---

## 0. 现状与差距

### 0.1 截图问题拆解

| # | 现象 | 判断 |
|---|---|---|
| 1 | 聊天区整体可用，但输入框是“四面细边框 + 内部 metadata + 底部一条状态行”；opencode 参考（图 2）是“仅左侧色条 + 顶部留白 + 内部 metadata + 阴影唇边 + 框外 footer” | 输入框结构需要重排，metadata 内容也要换（补 agent / auto 权限徽标） |
| 2 | 底部状态行重复了路由（`standard · deepseek-v4.1-flash cliproxy · max` 与 footer 的 provider/model/effort/permission/mode 重复） | 路由信息应只出现在输入框 metadata；footer 只留位置/上下文/快捷键提示 |
| 3 | 顶栏会话是“编号 + 标题”的静态 chip，不能关闭/重开/拖动/右键管理，标题还会退化成 `tui-<uuid>` | 标签页模型与交互未移植完整；标题退化是会话日志读不出来的连带结果 |
| 4 | 旧会话标题读取失败，每个会话一条 warning toast（`+60 more`） | host 把每个 `readTitleSnapshots` 的 rejected 都转成了告警，且每次刷新都重试 |

### 0.2 标题读取错误的根因（已定位）

安装的 dsh 是 `0.2.0-rc.2`，其 v0→v1 会话迁移（`@deepseek-ai/dsh-session-format-v0-to-v1`，
`lib/index.js:1584`）要求 `subagent/descriptor` 的 `version === 3`；部分旧会话里是
`version: 2`，迁移直接抛
`subagent/descriptor <seq> uses unsupported descriptor version 2; source v0 artifact remains unchanged`。
这不是本插件能修的兼容问题，但本插件必须**优雅降级**：

- `readTitleSnapshots` 返回 rejected 的会话，用 id 作标题、**不再逐条发 warning**；
- 同一批失败聚合为**至多一条** info 提示（例如「已跳过 N 个旧格式会话」），只报一次；
- 记住不可读的 session id（进程内缓存），后续刷新不再重复读取；
- 会话选择器 / 标签页里**不出现**不可读会话（恢复了也打不开，点了必然报错）。

涉及：`src/index.ts` 的 `pushSessionList`（约 2400–2470 行）、`session-list` payload。

### 0.3 输入框对照（opencode v2 `component/prompt/index.tsx`）

opencode 的真实结构（1657–1970 行）：

```
<box width=100%>                                        // prompt 锚点
  <box width=100% border=["left"] customBorderChars=SplitBorder bottomLeft="╹">
    <box paddingLeft/Right = W<44 ? 1 : 2, paddingTop=1,
         bg = decrease(background.raised.base), flexGrow=1, width=100%>
      [附件缩略图条]
      <textarea width=100% minHeight=1 maxHeight=max(6, floor(H/3)) />
      <box row paddingTop=1 gap=1 justifyContent=space-between>
        <PromptMetadataRow agent auto model provider variant />
      </box>
    </box>
  </box>
  <box height=1 border=["left"] vertical="╹">            // 阴影唇边
    <box height=1 border=["bottom"] horizontal="▀" borderColor=promptBg />
  </box>
  <box row width=100% justifyContent=space-between gap=2> // footer（框外）
    左：running ? spinner + "esc interrupt" : cwd[:branch]
    右：[file-context] [contextTokens (pct%)] [$cost] [N subagents] [N shells] [键位提示]
  </box>
</box>
<Autocomplete />                                         // 绝对定位在 prompt 上方
```

metadata 行（对齐图 2 的 `Build auto · tierflow cliproxy · high`）：
`agent`（preset 展示名）· `auto`（权限 autoaccept 徽标）· `model` · `provider` · `variant/effort`；
宽度不足时按 §上游断点逐段丢弃（`<44` 丢 agent/provider，`<28` 只留 model）。

### 0.4 标签页对照（opencode v2 `context/session-tabs.tsx` + `component/session-tabs.tsx`）

上游模型（`session-tabs-model.ts`）：

- `SessionTab { id, title }`；`openSessionTab` / `closeSessionTab` / `reopenSessionTab` /
  `moveSessionTab` / `cycleSessionTab` / `recordSessionTabHistory`；
- 持久化 `tabs`：`{ global: { tabs, unread }, cwd: { [cwd]: { tabs, unread } } }`，
  `scope = global | cwd`；
- 已关闭栈（`recentlyClosed`）支持 `ctrl+shift+t` 重开，最多 10–25 条；
- 配置：`tabs.mode = auto|on|off`、`tabs.scope = global|cwd`、
  `tabs.layout = horizontal|vertical`、`tabs.indicators = status|numbers`；
- 键位：`ctrl+tab` / `alt+down` 下一个，`ctrl+shift+tab` / `alt+up` 上一个，
  `<leader>w` 关闭，`ctrl+shift+t` 重开，`<leader>1..9` 选第 n 个，`ctrl+i` 历史前进；
- UI：chip 宽 22（min 8 / max 32），编号/状态格 + 标题；active chip 背景抬升；
  hover 时右侧 `×`（x = chip 宽 - 2）关闭；`+` 新增；溢出 `‹N` / `N›`；
  右键 context menu（Close / Close others / Rename / Reopen list）；拖动重排；
  长按 5s 关闭；`layout=vertical` 时左侧竖栏（`session-tabs-rail.tsx`）。

当前实现（`renderer/src/ui/session-tabs.tsx` + `app.tsx` 700–780 行）只有：
编号 + 标题、点击选中、`+` 新建、`leader w` 关闭、`ctrl+shift+t` 重开、
`ctrl+tab`/`alt+↑↓` 切换、本地 `tabs.json` 持久化、按 `openTabs` 过滤 session-list。
**缺少**：关闭按钮 / 右键菜单 / 拖动 / 重开列表 / per-cwd scope / 配置项 / 竖栏 /
unread 与 busy 状态 / 会话删除清理 / 标题实时更新（rename、session-list）。

### 0.5 聊天区对照

当前 `ui/transcript.tsx` 已移植了上游的“行节奏”（`marginTop=1`、user 左边界卡、
assistant `paddingLeft=3`、tool inline/block、assistant footer），但：

- assistant footer 目前只有 `agent · model`，缺 `duration` / `tok/s`（上游按宽度隐藏）；
- 权限模式在 footer 重复出现，应移到 prompt metadata 的 `auto` 徽标；
- 行间距与 `background.raised` / `decrease()` 的取值需按截图逐项核对；
- 顶部没有 tab 条与内容之间的留白规则（见 §3）。

---

## 1. 阶段与任务

### P0 稳定性与版本口径（0.5–1 天）

- [ ] 标题读取降级：聚合提示、不可读 session 缓存、从列表剔除（`src/index.ts`）。
- [ ] toast 去重：同一错误文本 5s 内只弹一次（`renderer/src/ui/toast.tsx` 或 store 层）。
- [ ] 版本与发布口径：`v0.5.0` tag 删除（已完成）；CHANGELOG / README 标记“未发布”；
      `package.json` 保持 `0.5.0` 开发版本，验收通过后再决定 tag（或升 0.6.0）。
- [ ] 验收：带 60+ 旧会话的 profile 启动，最多 1 条 info 提示；`/resume` 列表不含不可读会话。

### P1 输入框对齐（1–1.5 天，最高优先）

- [ ] 结构：去掉任何整框边框，改为 `border=["left"]` + `bottomLeft="╹"`；内层
      `paddingLeft/Right = 1|2`、`paddingTop=1`、`bg = decrease(background.raised.base)`；
      `textarea maxHeight = max(6, floor(H/3))`。
- [ ] metadata 行：`agent · auto · model provider · effort`；`agent` 取当前 preset 展示名
      （standard/minimal/code/cordis 或自定义 preset），`auto` 只在权限为 autoaccept 时显示；
      宽度断点丢弃（复用 `prompt-metadata.tsx`）。
- [ ] 阴影唇边：一行 `╹` + 内层 `▀`，颜色 `promptBg`（现有实现保留，核对颜色）。
- [ ] footer：左侧 `cwd[:branch]`（运行中显示 spinner + `esc interrupt`）；右侧
      `12.3K (41%)` + `ctrl+p commands`（`cost` dsh 无值，按上游隐藏规则不显示）；
      删除重复的 `provider/model/effort/permission/mode`。
- [ ] 窄屏：`<44` 时 padding 2→1、metadata 丢 agent/provider、footer 丢细节；
      `<28` 只留 model；`<80` footer 隐藏 `/plugins` 类提示。
- [ ] 验收：80×24 与 120×30 的帧断言——输入框**没有**上/右边框、左侧 `┃`、
      顶行空白、metadata 行内容、唇边行、footer 左右对齐；补 `layout.test.tsx` 断言。

### P2 会话标签页对齐（2–3 天）

- [ ] 模型：按上游 `session-tabs-model.ts` 补 `recordClosedSessionTab`（保留 index）、
      `reopenSessionTab`（插回原位）、`moveSessionTab`（拖动/`leader` 移动）、
      `cycleSessionTab`、历史前进；持久化结构升为
      `{ version: 2, scope, global, cwd }`，兼容读旧 `{open, closed}`。
- [ ] 配置：`tabs.mode`（auto/on/off）、`tabs.scope`（global/cwd）、
      `tabs.layout`（horizontal/vertical）、`tabs.indicators`（status/numbers），
      进入 `dpsk-tui` 设置节与设置页；渲染器通过 `settings` 读取。
- [ ] 交互：点击选中；hover 关闭 `×`；右键菜单（Close / Close others / Reopen / Rename）；
      拖动重排；`+` 打开 Home 草稿 tab；关闭后切到邻居，最后一个回 Home；
      `ctrl+shift+t` 重开栈；`leader 1..9`；`ctrl+i` 历史前进。
- [ ] 标题：`session-list` / rename 时更新 tab 标题；不可读会话不建 tab；
      会话被删除时清理 tab 与重开栈。
- [ ] 状态：`turn-state` 驱动 busy spinner 与 unread 标记（先做 busy，unread 可后置）。
- [ ] 竖栏：`layout=vertical` 或窄屏时用 `session-tabs-rail.tsx` 形态（左侧 42 列内嵌）。
- [ ] 冲突：`alt+up` 当前是“编辑插话”，上游是“上一个 tab”——改为插话队列非空时优先插话，
      否则切 tab；或把插话移到 `<leader>e`（需确认）。
- [ ] 验收：`session-tabs.test.tsx` 覆盖 open/close/reopen/move/overflow/click/右键；
      真实产物帧断言 chip 背景与 `×` 位置。

### P3 聊天区 polish（1 天）

- [ ] assistant footer 补 `duration` / `tok/s`，按 `<28` / `<36` 断点隐藏（上游规则）；
- [ ] 权限徽标移入 prompt metadata 后，从 footer 删除；
- [ ] 行间距 / 背景 / 分隔线按截图核对：user 卡 `raised.base`、assistant `paddingLeft=3`、
      reasoning 折叠、tool inline 图标列宽 2、block 卡背景与 diff 缩进；
- [ ] 滚动条与粘底、jump-to-latest 行样式；
- [ ] 验收：120×30 与 80×24 的整屏 golden frame 对比（人工核对 + 断言）。

### P4 验收与发布门禁（1 天）

- [ ] `tmp/check-frame.ts` 更新为新夹具：prompt 无整框、metadata 五项、footer 右侧
      `%`/`ctrl+p`、tab 关闭与重开、旧会话跳过提示最多一条；删除过期断言
      （`settings rows painted` / `model edit merged back` 等已漂移项）。
- [ ] 新增 `layout.test.tsx` 用例：prompt 边框集合 = `['left']`、唇边行存在、
      footer 左右内容、tabs 关闭/重开/溢出、chip 宽度表。
- [ ] 真实 TTY 验收（用户）：CJK、滚动/帧率、鼠标（点击/右键/拖动）、微信扫码、供应商表单。
- [ ] 发布清单：`npm run check` + `check:renderer` 全绿；7 平台产物重建；
      `generate:sums` 校验一致；tarball 解包检查；**打 tag 前用户确认**。
- [ ] 版本：若 UI 改动按计划完成且无新范围，仍发 `0.5.0`；若引入 unread/动画/竖栏等
      扩展，改为 `0.6.0`（建议 0.6.0，避免 0.5.0 承诺与实测不符）。

---

## 2. 关键设计决定（待确认）

1. **默认 `tabs.scope`**：`cwd`（每个项目一套 tab，opencode 默认似乎也是 cwd）还是 `global`
   ——建议 `cwd`，与 opencode 的“项目即工作区”一致。
2. **`alt+up` 冲突**：插话编辑 vs 上一个 tab ——建议“队列非空优先插话”，否则切 tab。
3. **不可读旧会话**：从列表隐藏（推荐）还是置灰显示并提示“dsh 版本不兼容”。
4. **版本号**：0.5.0（仅 UI 对齐）还是 0.6.0（含竖栏/未读/动画）。建议 0.6.0。
5. **是否移植动画**（tab pulse/shimmer、toast hover）：先不做，保功能与布局；后续再补。

---

## 3. 验证方法（固定）

- 帧级：`renderer/src/layout.test.tsx`（几何断言）+ `tmp/check-frame.ts`（真实产物网格）。
- 交互级：`renderer/src/app.test.tsx` / `session-tabs.test.tsx` / `storage.test.ts`。
- 门禁：`npm run check`（宿主 235 tests）+ `npm run check:renderer`（229 tests）。
- 实机：用户用 `dpsk` 在 Windows Terminal / WezTerm 里跑，重点看 CJK、输入框、
  tab 点击/右键/拖动、旧会话提示。
- 发布：以上全绿后由用户确认，再打 tag（不 push 的约定不变）。

---

## 4. 工作量与顺序

| 阶段 | 内容 | 预估 |
|---|---|---|
| P0 | 标题降级、toast 去重、版本口径 | 0.5–1 天 |
| P1 | 输入框结构与 metadata/footer | 1–1.5 天 |
| P2 | 标签页模型、配置、交互、竖栏（可拆 P2a/P2b） | 2–3 天 |
| P3 | 聊天区 polish | 1 天 |
| P4 | 夹具/测试/实机/发布门禁 | 1 天 |

建议顺序：**P0 → P1 → P3 → P2 → P4**（先把“看起来对”的输入框与聊天区修好，再做标签页交互，
最后统一验收）；P2 的竖栏/未读可作为 0.6.0 的后续批次。

---

## 5. 执行进度（2026-10-20 第二轮）

| 项 | 状态 | 说明 |
|---|---|---|
| P0 旧会话标题降级 | 完成 | 不可读会话缓存并剔除，整批一条 info；`readTitleSnapshots` 不再逐条 warning |
| P0 toast 去重 | 完成 | 同 level+文本去重，队列上限 20；新增测试 |
| P0 版本口径 | 完成 | `v0.5.0` tag 已删；CHANGELOG/README 标注未发布 |
| P1 输入框结构 | 完成（源码已是左边界+唇边） | 80×24 帧已确认无整框；新构建缓存已替换 |
| P1 metadata | 完成 | `agent · auto · model provider · effort`；Auto 预设显示 `auto` |
| P1 footer | 完成 | 默认 `${context}${queued}${subagents}` + `ctrl+p commands`；路由不再重复 |
| P3 聊天区 polish | 部分 | assistant footer 已含 duration/tok-s（既有）；权限徽标移出 footer；行距待实机核对 |
| P2 标签页核心 | 完成 | active `×`、中键关闭、右键菜单（close/others/move/reopen/rename）、`leader 1..9` 按打开顺序、重开原位、不可读会话清理 |
| P2 配置 / 竖栏 / 未读 | 未开始 | `tabs.mode/scope/layout/indicators`、per-cwd scope、vertical rail、busy/unread 留待下一批 |
| P4 夹具 / 实机 / 发布 | 进行中 | `tmp/check-frame.ts` 已按新口径更新；7 平台产物与 SHA256SUMS 待最终重建；CJK/鼠标/微信需实机 |

下一步建议：先在实机确认输入框与标签页（`dpsk` 重启后生效），再决定 P2 配置/竖栏是否需要本轮完成。
