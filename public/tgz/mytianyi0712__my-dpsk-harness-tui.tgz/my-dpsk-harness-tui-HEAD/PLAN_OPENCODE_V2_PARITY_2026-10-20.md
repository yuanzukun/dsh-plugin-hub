# 0.5.0 TUI 高保真修补计划（2026-10-20）

> 目标：在不修改 dsh 上游/backend 的前提下，继续把 dsh TUI 调整为接近 opencode v2 的视觉与操作习惯。会话流不要求完整复制 opencode；本阶段必须正确区分已有数据中的思考、工具调用和正文，正确渲染思考/正文 Markdown，并让流式输出稳定增量显示、不出现每个新字都闪一下的体验。
>
> 版本保持 `0.5.0`，不换版本号；本轮验收完成前不打 tag、不发布、不 push。
>
> **代码边界**：不得修改 `@deepseek-ai/dsh`、dsh core/backend 或上游事件生产逻辑。只修改本仓库的 TUI adapter（`src/index.ts`、`src/host/*`）、renderer、TUI IPC contract/mirror、测试和文档。这里的“host adapter/projection”指本仓库的 TUI 适配代码，不是 dsh 上游后端。

## 1. 范围与不做事项

### 本轮必须完成

- Home 在已有额外 session tabs 时仍显示 tab strip；Home 与 session route 共用 Shell 层的 tabs。
- `Switch model` 打开专用可搜索模型选择 dialog；F2/Shift+F2 是独立 cycle 操作，键位帮助与实际行为一致。
- 会话流正确显示 dsh 已提供的 user/assistant 正文、reasoning、tool call/result 与状态；能从已有的有序 content blocks 和 stream frame 中保留顺序。
- reasoning 与正文都使用 OpenTUI Markdown renderer；Markdown 标题、强调、列表、引用、行内/围栏代码、表格和链接显示正确。
- streaming delta 到来时在同一稳定 row/Markdown renderable 内更新；避免整条 assistant row 被卸载重建、viewport 跳动或每字闪烁。
- 工具 pending/complete/failure/denied、reasoning header/body、assistant footer 的布局和颜色尽量按 opencode v2 对齐。
- 通过自动 char-frame 测试和 Windows 终端实机验收。

### 明确不做

- 不修改 dsh 上游，不要求上游增加事件、不改 session log 格式。
- 不要求完整移植 opencode 的全部 session row/group/history 架构。
- 不伪造 dsh 当前没有暴露的 revert、provider cost、model variants、background shell lifecycle、完整 per-step token 表、multi-file patch diagnostics 等信息。
- 不因追求视觉 parity 改变 dsh 的权限、安全、session 管理或消息提交语义。
- 不把终端正常的差异帧重绘当成 bug。要修的是 renderable/component 重建造成的可见闪烁、Markdown 内容跳变或滚动位置跳动。

## 2. 现状与已证实差距

参考源码固定为 `tmp/opencode-v2.0.32-843a6c5/packages/tui/src/`，重点查看 `routes/session/message-parts.tsx`、`routes/session/rows.ts`、`component/prompt/index.tsx`、`component/dialog-model.tsx`、`component/command-palette.tsx` 与 app Shell。

- **Home tabs**：`renderer/src/app.tsx` 的 route 分支将 `Home` 和包含 `SessionStrip` 的 session shell 互斥渲染；已有 tabs 时回到 Home 会隐藏标签。
- **Model 菜单**：`renderer/src/app.tsx` 的 `/model` 与 `pick-model` 打开按 models 过滤的通用 palette；`command-palette.tsx` 也把 model rows 与 command rows 混合。F2/Shift+F2 才执行 cycle。`src/i18n.ts` 有过时/矛盾的键位帮助。
- **流式 row**：`src/index.ts` 已用 `s<session>-<sequence>` 给 stream row 稳定 id，并把 durable assistant message 对齐到该 id。但 `renderer/src/app.tsx` 的 `session-frame` 处理复制数组并以新对象替换同 id row；Solid `<For>` 是否因此重建子组件需要 instrumentation 验证。
- **Markdown streaming**：`renderer/src/ui/markdown.tsx` 没有接收/传递 `streaming`。锁定的 OpenTUI 0.5.17 `MarkdownRenderable` 支持 `streaming`，并说明尾部 Markdown block 在增量期间保持 unstable、完成后再 finalize。应使用这个正式 API，而不是自行解析 Markdown。
- **思考正文**：`renderer/src/ui/transcript.tsx` 当前把 reasoning body 作为 plain text 显示，而 assistant 正文使用 Markdown；reasoning empty streaming spinner 的判断当前不可达（先对空字符串 return）。
- **事件投影**：`src/host/transcript-events.ts` 将 assistant message 的所有 text blocks 合并、所有 reasoning blocks 合并，并独立投影 tool call/result。TUI adapter 可利用 dsh 已给的 `SessionEvent`、`content`、`callId`、`AssistantStreamFrame` 做更忠实的显示，不得据此要求改上游事件。

闪烁根因尚需实测确认：可能来自 Solid row identity、Markdown renderable 更新/重建、每个 frame 的全量数组更新、scrollbox 高度测量，或其组合。计划先测后改，不先把某个推测当作结论。

## 3. 执行阶段

### T0：诊断流式闪烁（0.5 天）

在开发/测试环境给 transcript row 和 Markdown component 加轻量计数：mount、update、dispose、row id、text length、streaming。对每个 session-frame 记录 batch size 和更新 id；对 scrollbox 记录 scrollTop、scrollHeight、sticky 状态。增加 100 个连续 text-delta 的可重复 fixture。

验收基线：同一 stream row 的 mount 次数；Markdown renderable 是否被复建；每个 delta 引发的 Solid update/render 次数；用户离开底部时 scrollTop 是否变化。区分一个 render frame 内的终端差异绘制与 row/component 重挂载。

### T1：稳定的增量 row 更新（1–2 天）

审计 `renderer/src/app.tsx` 的 transcript store 与 `<For>` 身份行为，以 T0 证据决定改法。优先用 Solid store keyed reconcile 或稳定 row controller，避免单纯 `next[index] = row` 替换对象导致子树身份丢失。对已有 id 做字段级更新，对新 id append；frame 在同一渲染周期内合并，但不能加有感知延迟。普通文本 delta 不应无条件触发完整 viewport 重测。

保持现有 host stream id 到 durable assistant event 的衔接，确认 completion settle 原行而非重复 append。若目前 `session-frame` 中多个事件同批到达，必须按序 merge。

测试门槛：
- 连续 100 个 delta，单一稳定 row identity，正文长度单调增加；
- durable completion 不产生第二条 assistant row；
- 新增 tool row 仍按顺序追加；
- 用户滚离底部后新字不拉回、不改变其可见锚点；
- 不因每个字符重新创建 Markdown renderable。

### T2：正文与思考的 Markdown streaming（1–2 天）

修改 `renderer/src/ui/markdown.tsx`，接收 `streaming` / `conceal` 等显式 props，并把 `streaming` 传入 `<markdown>`。保留稳定 renderable，通过响应式 content setter 更新已有 Markdown，而非每个 delta 创建新节点。assistant row 在 host settle 时将 streaming 从 true 切到 false，让 OpenTUI finalize 最后一个 Markdown block。流式期间不反复 trim 会改变语义的尾部空白，完成后再按 Markdown renderer 规则 finalize。

把 reasoning body 从 plain `<text>` 改用相同 OpenTUI `<markdown>` renderer，使用对应的 thinking 颜色/syntax。reasoning streaming 尚无文字时显示 spinner，避免当前空内容提前 return。Home/session 正文 Markdown 行为统一，conceal 遵循现有 markdown setting。

测试 Markdown 增量序列：未闭合粗体、标题/列表、未闭合 code fence、表格行追加、链接；验证中间帧稳定追加，最终帧语法完整，字符/代码不消失或闪烁。宽度覆盖 40/80/120。

### T3：TUI-only 有序事件适配（1–3 天）

仅在 `src/host/transcript-events.ts` 与 `src/index.ts` 的 TUI adapter 中工作：

- 对 durable assistant message，若现有 `content` block 保留类型与顺序，则投影为有序 text/reasoning part；旧数据或类型不足时 fallback 到当前 assistant row。
- 对 stream frame，按到达顺序将连续同类型 delta 合并成稳定 part；text/reasoning 类型切换时分别显示，不将思考内容并入正文。使用稳定 part id，并在 durable event 到达时 settle/reconcile。
- tool call/result 继续按现有 `callId` 关联，pending row 更新为实际结果。
- 若现有 dsh event 无法区分某种顺序或状态，UI 采用兼容 fallback；不发明后端事件，不改上游 session log。
- 协议扩展仅限可选 UI 字段（如 `kind`/`partId`/`parentId`）；保持 protocol v2 兼容并通过现有 capability/kind 协商。没有必要时不增加 IPC 字段。

测试：ordered text/reasoning blocks；reasoning → text stream；text → tool → text 的 event sequence；tool result 延迟到达；旧 snapshot/fallback；stream 到 durable event 不重复。

### T4：会话流样式与现有工具状态（2–3 天）

按 opencode v2 的布局、间距和 semantic theme tokens 精修现有 row：

- User message：已有 accent gutter、背景和 padding 统一断点；
- Reasoning：Thought/Thinking header、折叠、Markdown body、duration 排版；沿用现有 showReasoning 设置兼容；
- Assistant：正文和 footer 的间隔、streaming 状态、完成 footer；streaming 中不显示最终 footer；
- Inline tools：pending spinner、settled muted label、failed/denied 语义色、已有 error/input/output；
- Shell/tool output：对现有输出按终端宽度调整折叠预览，不声称支持上游未提供的 background lifecycle；
- Edit diff：现有 +/- 数据使用更接近上游的 inset 与 diff 色彩；明确保留多文件/diagnostics 未支持状态。

只展示 dsh 现有 payload 可以证明的信息。缺少 provider、计数、variant 或完整结构时不补造文本。

验收 frame 至少覆盖 reasoning stream、正文 stream、tool pending→complete、failed/denied、assistant footer，以及 27/35/44/80/120 列。

### T5：全局 Shell 与 Home tabs（1–2 天）

把 SessionStrip 从 session-only 分支提升到 Home/session 共用的内容列：

```text
Shell
└── content column
    ├── SessionStrip（仅有已打开的额外 tabs 时显示）
    └── Home | Session
```

无 tab 的 Home 保持干净首屏；Home 中存在两个或更多已打开会话时标签始终可见。tab 切换和回 Home 不丢失各自 composer draft。此阶段不扩展 vertical rail、per-cwd scope 等尚未要求的 tabs 功能。

测试 Home 无 tab、Home 有两个 session tabs、Home ↔ session 切换、80x24/120x30。

### T6：专用 Model dialog 与正确命令语义（1–2 天）

- 将 palette 中 `Switch model` 作为稳定 typed action，而不是 synthetic slash row。
- `Ctrl+P` 搜索 commands；model catalog 不与 command rows 混为同一种选项。
- `pick-model`、`/model`（兼容 alias）共用专用模型 picker；如果 host command registry 使用 `/models`，同时支持 canonical `/models`。
- dialog 使用现有 `{provider, model, label, current}` catalog：搜索、provider 分组、current marker、空/无匹配、取消；选择后只提交一次 `set-selection`。
- F2/Shift+F2 仍是 cycle，当前项按 `provider + model` 匹配；更新 host 与 renderer help 文案。
- 不伪造 favorites/recents/variants/cost；只有数据可用且用户批准本地 preference 语义后再扩展。

测试：palette action、leader action、slash alias 打开同一 dialog；选择/取消；F2 双向 cycle；同名不同 provider。

### T7：综合验收与 0.5.0 gate（1–2 天）

自动验收：host checks、renderer checks、IPC protocol verification、ordered event projection、100-delta identity test、Markdown stream char frames、tool lifecycle、Home multi-tab、model dialog/cycle contract、80x24/120x30/narrow frames、7 平台构建和产物校验、package smoke。

实机验收：Windows Terminal 或 WezTerm；CJK 与 Unicode 宽度；输入法/粘贴；长正文逐字流式；reasoning Markdown；代码块/表格/链接；tool pending 到 complete；用户滚离底部阅读；Home 多标签和 model 搜索/取消/选择。

发布前必须由用户确认；本计划本身不授权创建 tag、发布或 push。

## 4. 实施顺序与估算

| 阶段 | 交付 | 估算 |
|---|---|---:|
| T0 | 复现与计数，确认闪烁来源 | 0.5 天 |
| T1 | 稳定 transcript row 更新与帧合并 | 1–2 天 |
| T2 | reasoning/body Markdown streaming | 1–2 天 |
| T3 | TUI-only 有序事件兼容投影 | 1–3 天 |
| T4 | 会话流/工具样式对齐 | 2–3 天 |
| T5 | Home 中保留 session tabs | 1–2 天 |
| T6 | 专用 Switch model dialog | 1–2 天 |
| T7 | golden frames、TTY、构建验收 | 1–2 天 |

合计约 **9.5–15.5 工程日**。先完成 T0–T2，能尽早验证闪烁是否修复；T3–T4 达成用户明确的会话流目标；T5–T6 完成本次另外两项 UI 行为。

## 5. Definition of Done

- dsh 上游/backend 未修改；所有兼容逻辑都在本项目 TUI adapter/renderer。
- 正文、reasoning、tool 调用在 dsh 现有数据可表达的范围内正确区分并保持顺序。
- 正文与思考中的 Markdown 均由 OpenTUI parser 正确绘制，包括流式未完成语法和 settle 后的最终语法。
- 同一流式 row/Markdown 子树不因每个 delta 卸载重建；长文本视觉上逐步添加，无明显闪烁；滚动锚点稳定。
- tool pending/result/failure/denied 正确更新；stream completion 与 durable event 不产生重复 row/footer。
- Home 存在额外会话 tabs 时 tab strip 不隐藏。
- `Switch model` 是搜索选择 dialog；cycle 是 F2/Shift+F2；帮助文案与实现一致。
- 测试、跨平台构建及 Windows TTY 验收通过。
- 0.5.0 仍保持未发布状态，直到用户明确确认后再决定 release。

## 6. 当前决定

- 版本保持 `0.5.0`，不换版本。
- 不改造 dsh 上游，不要求上游变更事件流。
- 会话流目标是正确区分思考/工具/正文、正确 Markdown、无闪烁流式更新，不要求完整复制 opencode 全部 transcript 语义。
- Home 有额外 tabs 时必须显示标签条。
- `Switch model` 使用专用 picker；F2/Shift+F2 独立执行 cycle。

## 7. 执行进度（2026-10-21）

| 阶段 | 状态 | 落地 |
|---|---|---|
| T0 诊断 | 完成（以测试替代临时插桩） | 用行身份断言作为回归门槛：60 次 delta 后 `store.transcript()[0]` 仍是同一对象、行数恒为 1。比一次性计数插桩更适合长期防回归。 |
| T1 稳定增量行 | 完成 | `renderer/src/app.tsx`：`createStore` + `reconcile(…, { key: 'id' })`；`session-frame` 走 `mergeTranscript` copy-on-write；快照/清空/回滚统一经 `setTranscript`。新增 `transcriptRevision` 信号：store proxy 不读行字段，原地 delta 不触发只调用 `transcript()` 的 effect；吸底 clamp 改为依赖 revision。 |
| T2 Markdown streaming | 完成 | `renderer/src/ui/markdown.tsx`：`streaming` 透传、流式不清洗尾部空白、settle 后 trim；reasoning body 改用同一 renderer；`Thinking` spinner 分支恢复可达；`Thought: x · 0.8s`。 |
| T3 TUI-only 有序适配 | 完成（范围内） | 既有事件已能区分 text / reasoning / tool 且按事件顺序成行；新增 `turn/end` 兜底 settle，避免中断后流式行卡在 streaming。**已知限制**：同一条 assistant message 内 reasoning 与 text 的交错顺序在单行模型下无法表达，渲染顺序固定为 reasoning 在上、正文在下；不为此改协议或拆行（拆行会与 stream→durable 的 id 继承冲突，产生重复正文）。 |
| T4 样式 | 部分 | 已完成 reasoning/body/footer 的核心结构、工具失败/状态色和 settled inline muted；但仍有本次截图确认的 Shell 差距：底部信息过多、WeChat 状态独占底行，sidebar/footer 与 opencode 的信息层级不同。详细续迁见 `PLAN_OPENCODE_V2_UI_PARITY_NEXT_2026-10-21.md`。未做：inline 工具 hover 提亮、用户卡 hover/pending（无后端数据支撑，不伪造成交互）。 |
| T5 Home 标签 | 完成（行为范围） | `SessionStrip` 在 Home/session 共用并且无 tab 时不占行；该状态仅代表 Home 中保留已打开 tab 的行为完成，不代表 session tab 的 detail、即时高亮、hover/overflow 视觉 parity，续迁见 N3。 |
| T6 Switch model | 完成 | 新增 `openModelDialog()`：provider 分组、current 标记、搜索、取消不写入、空目录 alert；`/model` `/models` `ctrl+x m` 与面板 action 同源；面板不再混入模型目录；F2 cycle 按 `provider + model` 匹配；i18n 新增 `rendererSwitchModel` 并修正 `/help` 键位文案。 |
| T7 验收 | 部分，未完成 | 自动门禁：host 235（234 pass / 1 skip）、renderer 243 pass；真实二进制流式驱动 12 delta / 12 帧，0 丢帧、0 空帧、无幽灵 Thought 行，7 平台构建通过；用户已提供 Windows Terminal 实机截图，证明基本会话与 CJK 绘制可用，同时明确指出 Shell/侧栏/标签视觉验收失败。尚未验收：长流逐字追加和滚离底部、reasoning Markdown、工具生命周期、输入法、标签切换高亮、隐藏侧栏标题、长侧栏滚动。

### 真实二进制驱动发现的回归（已修）

流式行从空 reasoning 开始时，`ReasoningRow` 顶部的 `if (!streaming() && empty()) return null` 在组件体内只求值一次。settle 后 `streaming` 变 false，但早退不会重算，于是没有 reasoning 的回答会留下 `Thought: 1.8s` 空行。源构建的静态用例（fixture 一开始就是 settled）覆盖不到，是 `tmp/check-stream.ts` 驱动编译产物时发现的。修法：把"是否画 reasoning 行"的判断提到 `TranscriptRow` 的 JSX 条件里，随 `streaming` / `reasoning` 响应式变化；`ReasoningRow` 自身改为总返回元素。新增两个回归用例（settle 后无幽灵行、有 reasoning 时 header 与正文保留）。

同一批还有一个由 store 改造引入的回归：吸底 effect 原本依赖 `store.transcript()`，但该访问器改成返回 store proxy 后不再读取任何行字段，原地 delta 因此不会触发它，"短内容吸附顶部"的钳制会失效。修法是新增 `transcriptRevision` 信号，`publishTranscript` 每次自增，effect 改为依赖它；`streaming.test.tsx` 的行身份用例同时断言每次 delta 的 revision 递增。

### 新增/更新的测试

- `renderer/src/ui/streaming.test.tsx`（新）：行身份、settle 不重复、流式 Markdown、reasoning Markdown、Thinking spinner、reasoning delta 原地填充、逐 delta 帧扫描（任何一帧都不丢已流出的文字）、settle 后不留幽灵 Thought 行、有 reasoning 时 header 与正文保留。
- `renderer/src/app.test.tsx`：`pick-model` 打开专用 picker、面板不含模型目录、picker 分组与 current、取消不写入、F2 cycle 语义。
- `renderer/src/layout.test.tsx`：Home 保留标签条、无 tab 不占行。
- `renderer/src/ui/command-accept.test.tsx`：`/model` 打开 `Switch model`。
- `renderer/src/component/command-palette.test.ts` 保持 skill 过滤断言（模型行已移除，另有 app 级断言覆盖）。
