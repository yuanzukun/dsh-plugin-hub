# dsh 下一阶段开发计划

> 日期：2026-10-23
> 状态：计划，未开始实现
> 范围：本仓库 TUI adapter、renderer、IPC contract、launcher、测试与文档；不修改 dsh 上游/backend。
> 版本策略：不授权打 tag、发布或 push；daemon/lifecycle 验收后再决定 0.6.0。

## 1. 结论与顺序

六项需求分三条工作流：A. 独立 UI 修复：/trace、设置页汉化；B. 会话/标签页模型：先修加号继承状态与无法切回旧 tab，再承载子 Agent tab 和后台任务；C. 进程模型：用无 TTY 的 core daemon 保证关 tab / 退 TUI 后任务继续，并实现开机自启与独立彻底退出。

推荐顺序：P0 基线 + daemon spike -> P1 /trace -> P2 设置 i18n -> P3 tab 修复 -> P4 子 Agent/后台任务 -> P5 daemon/TUI shell/detach/shutdown -> P6 开机自启 -> P7 验收。

产品边界：关闭 tab、切换 tab、退出 TUI 只影响界面，不中断 agent、shell job、子 Agent。

/shutdown 或 dpsk daemon stop 才彻底停止 core，并中断所有运行中任务。

普通 Ctrl+C、/exit、终端关闭只 detach TUI；有运行任务时先提示，并提供打开全部进行中会话的选项。

默认 dpsk 使用 daemon；直接 dsh --profile tui 保留嵌入式兼容路径，退出时仍会结束 core，必须明确提示。

## 2. 关键根因

- 轨迹：sidebar.tsx 持有 SidebarTraceRow 和 24 行上限，app.tsx 从 transcript 派生摘要；数据被截断且没有详情。

- 子 Agent：SubagentDescriptor 缺少 child sessionId、title、status 和可交互能力；host 对所有 subagent 的 send-message 一律拒绝。

- child session 已有 origin、parentSession、delegationDepth 和日志头 descriptor；应从真实 child session 建索引，不能只信当前全局 descriptor 数组。

- 后台任务：shell-jobs 是 per-owner payload，但 renderer 用单一数组接收，任意 owner 的 emit 会覆盖，不能做全局侧栏。

- 加号继承旧状态：newSessionTab 只切换 route/composer，session-scoped 的 turnRunning、readOnly、usage、subagents、terminal 没有清空，所以新 Home 仍会显示上一个会话的 esc 打断。

- active 标错：openTabSessions 用 id === currentSession 表示 active；Home 时 currentSession 仍是旧会话，旧 tab 和 draft tab 会同时 active。

- 无法切回：从 Home 点旧 tab 时 pickSession 发 session-op switch，host 发现目标就是当前 agent 直接 return，不重发 snapshot；renderer 仍停在 Home。关闭 draft 后 homeDraft 也未清空，下一次加号会复活旧草稿。

- 设置汉化：openSettings/runSetting 仍有 show reasoning、max tool output lines、theme mode、on/off 等硬编码英文，category header settings/appearance 也未翻译。部分 i18n key 已存在但未使用。

- 进程模型：dpsk 直接 spawn dsh --profile tui，renderer 是 host 子进程；bye 触发 ctx.appExit(0)，plugin disposal 会 dispose owned agents、terminal 和 jobs controller。当前没有 daemon、socket、pid/token、autostart。

## 3. 目标架构

采用 headless core daemon + thin TUI shell：core 运行 dsh profile 的 agent/session/jobs 等长生命周期服务，不占 TTY；TUI shell 只负责发现/启动 daemon、spawn renderer、恢复终端并双向转发 IPC envelope。

- core daemon：持有 ctx.agents、jobsRegistry、session persistence、settings、MCP、skills；保存 pending approval/question，即使没有 TUI 连接也不能拒绝或丢弃；日志写 daemon 日志文件。

- TUI shell：由 dpsk Node 进程承担，拥有 TTY；spawn OpenTUI renderer 并转发 renderer IPC 到 daemon socket。renderer crash 时由 shell 恢复终端。

- 单实例与安全：Windows 使用当前用户 Named Pipe，POSIX 使用 DSH_HOME/dpsk/daemon.sock；daemon.json 保存 pid/version/socket/token，文件 0600；attach 必须带 token，不暴露 TCP。

- 生命周期：TUI detach 只解除 surface subscriptions，不 appExit、不 dispose agents/jobs；daemon 只在 /shutdown、dpsk daemon stop、致命启动失败或外部 kill 时退出。

## 4. 关键契约

### 4.1 Tabs v3
TabEntry 增加 kind=session/subagent/draft、parentId，TabsState 增加 activeId；v2 tabs.json 可解码，新写入 v3。active 不再由 currentSession 兼任；running 状态不持久化。

### 4.2 SubagentDescriptor 扩展
增加 sessionId、parentId、title、status、interactive、canSend、createdAt。host 以 child header origin=subagent + parentSession 建索引，并读取 child 日志头 descriptor；one-shot 只读，continuable 仅在 live 或成功 resume 时可交互。

### 4.3 Session snapshot 扩展
增加 sessionKind=root/subagent、parentSessionId、parentTitle、canInteract、interactiveReason；readOnly 保留一版兼容，语义为 subagent 且不可交互。child snapshot 的 title/route/preset/usage/todos 必须全部取 child 自身。

### 4.4 Lifecycle IPC
新增 upstream lifecycle-op 和 downstream lifecycle-state。running-work 返回 sessions、jobs、approvals、questions，用于退出确认和打开全部进行中会话；不能只靠 renderer 缓存推断。

### 4.5 后台任务与协议
shell-jobs renderer 改为 Map<ownerId, ShellJobView[]>；侧栏融合 session-list 中 running/attention 的会话与 running/stopping jobs。协议保持 v2 envelope，新字段可选、新 kind 走 capability negotiation 和 verify:ipc-protocol；确有必要再升 v3。

## 5. 工作包

### P0 基线 + 无头 daemon spike（0.5–1 天）
先在独立临时分支记录当前 host/renderer 测试基线。用 DPSK_CORE_DAEMON=1 启动 dsh --profile tui，跳过 renderer mount，确认非 TTY 下进程常驻、agent 与 shell job 可运行、断开 TUI 连接后仍存活、重新 attach 能拿 snapshot。

同时验证最小 socket 代理：shell 能 spawn renderer、转发 envelope、daemon 不写 TTY、renderer crash 后 shell 能恢复终端。产物写 docs/DAEMON_SPIKE.md。若 dsh profile 无法无 TTY 常驻，暂停 P5 并重新设计，不得用假后台掩盖。

### P1 /trace 独立面板（1–1.5 天）
命令名定为 /trace，单词且与现有术语一致。删除 sidebar trace section、TRACE_VISIBLE、collapsed.trace 和相关 props/memo；新增 trace-model 纯函数，输入完整 transcript，输出时间、role、turn/step、sourceSeq、tool/callId、status、duration、error、摘要，不截断 24 行。

新增全屏 trace dialog：默认滚到最新，上下滚动，Enter 展开完整文本/参数/输出/错误，Esc 关闭；流式更新保持滚动锚点。命令面板和 /help 增加入口。测试 0/1/N 行、CJK/40/80/120 列、sidebar 不再出现轨迹、流式不丢行。

### P2 设置页完整汉化（1–1.5 天）
把 openSettings/runSetting 的行构建抽成 settings-model 纯函数，每行显式带 categoryKey、labelKey、value formatter 和 dialogTitleKey。所有静态标题、分类、on/off、system/dark/light、错误/toast/空态都走 label()，补齐 zh/en 对等 key。

测试 zh-CN 下设置首页、每个 picker、每个 dialog 值无英文静态标签/分类/on/off/system；en 不回归；i18n key 集合严格对等；遍历 SETTINGS_ROWS 的 key 漏写即 fail。

### P3 标签页修复与后台语义（2–3 天）
1. 状态模型：引入 activeTabId 和 viewEpoch。每次新建 draft、切换 tab、强制刷新 snapshot 都递增 epoch；所有 session-scoped 下行 payload 必须同时匹配 route、sessionId 和 epoch，Home 时不得被旧会话 frame/usage/todos 污染。

2. 新建/关闭 draft：+ 创建干净 Home，清空 turnRunning、readOnly、parent/session kind、transcript、usage、todos、subagents、interjections、terminal 和 session actions；保留 process-global catalogs。关闭 draft 清空 homeDraft；已有 draft 时 + 复用并激活，不堆叠空 tab。

3. 显式激活：session-op switch 增加 forceSnapshot（或等价），即使 host 目标就是当前 agent 也重新发 snapshot，但不 cancel/dispose/重启 agent。selectTab 先设置 route/activeTabId 再请求 switch；switch 失败恢复原 active tab。close inactive tab 绝不发 switch。

4. 关闭不等于停止：tab close 不发 interrupt/bye/dispose/job kill；运行中 tab 关闭时提示任务仍在后台。已关闭但 running 的会话出现在后台任务视图，可重新打开。

5. 后台流式：host 至少为每个 session 保留当前 stream row，snapshot 时合并，确保从后台切回 running session 不空白；renderer 暂不要求同时渲染多 transcript。
验收：+ 后无旧 esc/usage/todo/readOnly；点旧 tab 收到 force snapshot 并正确高亮；反复 +/切换/关闭/重开不重复、不串草稿；close 后 agent 仍 running。

### P4 子 Agent 与后台任务侧栏（4–6 天）
1. Host child index：枚举 live agents 和 sessionPersistence.list，筛出 origin=subagent 且 parentSession=当前会话的 child；读取 child 日志头 descriptor，按 child id/createdAt/lastSeq 缓存；新 child 或 descriptor 到达时失效并重推。subagent-list 改为按 sourceSessionId 分组。

2. 可交互能力：移除所有 subagent 一律 read-only 的 guard；仅 live 且 mode=continuable 的 child 接受 send-message。one-shot、未知模式、不可 resume 时 fail-closed。slash command 仍只在有 catalog 的 root session 可用。

3. Sidebar：新增 Subagents 和 后台任务，二者默认折叠，无数据完全不出现。Subagents 行显示 label/provider/mode/status，点击时已开 tab 则激活，否则 openTab(sessionId, title, kind=subagent, parentId) 后 switch/resume。

4. 子 Agent tab：标题为 ↳ label 或 child title，与 root tab 同一 strip；打开后 transcript、T/S 计数、usage/context/cache、workspace、provider/model、sidebar title/todos 全部切到 child；sidebar 显示父会话 breadcrumb。

5. Composer：canInteract=true 时正常输入并发送到 child，固定提示 子 Agent 会话（可交互）· 使用标签页或 Ctrl+Tab 切回父会话。canInteract!=true 时整个 composer 改为不可编辑提示：此子 Agent 会话不支持手动交互，仍可通过标签页/Ctrl+Tab 切换。

6. 后台任务：融合 session-list 中 running/attention 的 root/subagent 与全局 shell jobs。会话行点击打开/激活 tab；job 行显示 owner title/label/status/running time，点击按 job.owner 打开 output inspector。不显示伪造百分比或未提供的输出预览。

验收：one-shot 可看 transcript 但不可输入；continuable live child 可发消息、esc 中断、T/S/usage/sidebar 随 child 切换；父/子 tab 往返不串状态；两个新 section 默认隐藏、点击命中、40 列不越界；已关闭 tab 的 shell jobs 仍可见且操作落到正确 owner。

### P5 Core daemon、TUI shell、detach 与 shutdown（7–10 天）
1. 拆分 renderer bridge：把 renderer-mount 的协议、ack、订阅、approval/question、命令校验与 spawn/TTY/终端恢复分离。新增 RendererConnection 抽象，embedded 用 Node IPC，daemon 用 TUI shell 转发的 socket；终端 restore 只由 TUI shell 负责。

2. daemon 模式：TuiStartup 增加 --daemon；不 mount renderer、不要求 TTY、不向 stdout/stderr 写 UI；保持 agents/session/jobs/MCP/skills/settings 启动；建立 socket、health、token、lock；等待 attach。

3. attach 上下文：控制帧带 client cwd、terminalSize、初始 session。新建 Home session 必须使用 client cwd，不能使用 daemon 启动目录；blank bootstrap session 的 cwd 不匹配时新建 blank 或按 attach cwd 首次创建。

4. TUI shell：dpsk 先确保 profile/renderer，发现同版本 health daemon，不存在则 detached 启动并等 ready；然后连接 socket、spawn renderer、双向转发 envelope。shell 不 import 重型 dsh services，目标是 warm attach 首帧 p50 <= 300ms（先测基线再定）。

5. shell 信号/异常：SIGINT/SIGTERM、renderer crash、socket 非预期断开都必须恢复终端。正常 shutdown/restart 时等待或重连；非预期断开输出简短错误并退出，不得留下占用 TTY 的 renderer。

6. detach：renderer bye 只做 surface detach；停止向旧 surface 推送、解订阅、释放 TUI-only terminal follow/retain，但不 appExit、不 dispose agents/jobs、不把 pending approval/question 置 unavailable。

7. 重连：重新握手后重发完整 snapshot（含 running、stream partial）、catalogs、settings、i18n 和 pending approvals/questions；不重复创建 session、不重置 agent。pending interaction broker 必须在 core，而不是 renderer mount 内部，否则 detach 会打断等待授权的任务。

8. 退出确认：/exit、空 composer Ctrl+C、leader q、终端关闭统一走 requestDetach。先查 running-work；无任务直接 detach；有任务显示三个选项：退出界面（后台继续）、打开全部进行中会话、取消。查询失败时 fail-closed，不静默退出。

9. 独立彻底退出：命令面板新增 彻底停止核心进程，slash 为 /shutdown。它不与 /exit 共用普通路径，必须二次确认，明确会终止所有 agent/shell job/terminal。daemon 先向 TUI 发 bye，等 surface detach 和终端恢复，再 dispose 并退出。

10. 兼容：/restart 在 daemon 模式下重启 core 并自动重连，保留 session；运行任务是否保留必须提示。直接 dsh --profile tui 的嵌入式模式保留，退出时明确提示会终止 core。dpsk daemon status 显示 version/pid/uptime/running work。

P5 验收：fake daemon 覆盖复用/单实例/stale socket/token 拒绝/版本不匹配；attach/detach 后 agent 仍 running、pending approval 重放；shutdown 发出 bye、终端恢复、agents/jobs 清理；shell crash 后 daemon 存活；不同 client cwd 创建正确 workspace；/exit 有任务三选项，/shutdown 才杀 daemon。

### P6 开机自启（2–3 天）
新增 host/autostart.ts，接口 status 和 set(enabled)，OS 注册状态是 source of truth。Windows 用 HKCU Run 或 Startup + 无窗口 shim，命令为 dpsk daemon run --foreground --quiet，避免控制台闪烁。

macOS 写 ~/Library/LaunchAgents/com.mydpsk.daemon.plist，RunAtLoad=true，launchctl load/unload。Linux 优先 user systemd unit，systemctl --user enable --now；无 systemd 回退 XDG autostart .desktop。所有平台不需要管理员权限。

设置页常规/核心新增：核心进程状态（running/stopped/version）、开机自启（on/off/unsupported/需要重新登录）。切换经 lifecycle-op 调 host controller，成功后才显示 enabled；失败给真实错误，不写假状态。

P6 验收：三平台生成/解析/幂等 enable/disable 纯函数测试；temp HOME + fake launchctl/systemctl/reg；Windows 实测注销/登录后无窗口、daemon 存在、日志正常；关闭自启后不启动；dpsk 首次启动复用预热 daemon 并记录首帧时间。

### P7 集成、性能、文档与验收（2–3 天）
自动门禁：npm run check、renderer typecheck + test、verify:ipc-protocol、新增 launcher/daemon/autostart tests、7 平台 renderer build + SHA256SUMS。包 files 必须包含新 daemon/shell/autostart 脚本。

关键 E2E：开启自启 -> 启动任务 -> /exit -> daemon/job 继续 -> 重新 dpsk 从后台任务打开会话；多 tab 运行任务时关 active tab 后另一个 tab 继续；+ 新 tab 无旧状态且能切回老 tab；one-shot/continuable 子 Agent 行为；pending approval 跨 detach/attach；/shutdown 终端恢复且 daemon 消失。

文档：更新 README 的进程模型/命令/设置；docs/contracts.md 的 IPC、tabs、surface 契约；docs/ACCEPTANCE_TUI_SHELL.md 增加 daemon/autostart/detach/shutdown/subagent 项；CHANGELOG 明确 /exit 改为 detach、/shutdown 才彻底退出，直接 dsh 嵌入式是例外。

## 6. 工作量估算
- P0：0.5–1 天；P1：1–1.5 天；P2：1–1.5 天；P3：2–3 天。
- P4：4–6 天；P5：7–10 天；P6：2–3 天；P7：2–3 天。
- 合计约 19.5–29 工程日。单人按 P0→P1/P2→P3→P4→P5→P6→P7；双人可在 P0 后分头做 UI 与 daemon，但 app.tsx、src/index.ts、ipc/kinds.ts、contracts.md 是冲突热点。

## 7. Definition of Done
- sidebar 不再有轨迹；/trace 可打开完整、可滚动、可展开的交互记录。
- Subagents/后台任务默认隐藏，有真实数据时可点击；child tab 独立，T/S、usage、sidebar 随 active session 切换。

- continuable child 可向自身发消息；不可交互 child 在 composer 位置明确提示且 host fail-closed。
- 关闭 tab 不发停止请求；agent/job 继续，后台任务或 picker 可找回；TUI detach 后 daemon 和任务继续。

- /exit 有运行任务时显示确认和打开全部进行中会话；/shutdown 二次确认后停止 daemon、取消任务、恢复终端。
- 加号新 tab 不继承旧 esc/usage/todo/draft/terminal/readOnly，点旧 tab 可可靠切回。
- 设置页 zh-CN 静态文案/分类/值/错误完整汉化；en 不回归。

- 开机自启真实写入平台入口，开机无窗口静默拉起 daemon；设置显示真实状态，失败不误报。
- 不修改 dsh 上游；自动门禁、7 平台构建、协议校验和 Windows 实机验收通过；未获用户验收前不发布、不打 tag、不 push。

## 8. 先做与不做
先做：P1 /trace、P2 设置 i18n、P3.1/P3.2 tab bug 根因修复。必须等 P0 通过：daemon、autostart、退 TUI 后任务继续、/shutdown。

本期不做：远程/多用户 daemon、TCP 暴露、多 TUI 同时写同一 core、伪造 unread/attention、把 one-shot child 伪装成可交互、为关 tab 新建假后台状态、修改 dsh 上游或 session log 格式。

## 9. 主要文件影响
- Trace：renderer/src/app.tsx、ui/sidebar.tsx、新增 ui/trace-model.ts 和 dialog-trace.tsx、src/i18n.ts、app/layout/command-palette tests。

- Tabs/子 Agent：ui/session-tabs-model.ts、ui/session-tabs.tsx、ui/sidebar.tsx、app.tsx、src/index.ts、新增 src/subagent-sessions.ts、src/ipc/kinds.ts、renderer/src/protocol/kinds.ts。
- Daemon：scripts/dpsk.js、src/index.ts、src/startup.ts、src/host/renderer-mount.ts、renderer-process.ts、新增 daemon-server/daemon-client/autostart/lifecycle 模块。

- 设置/文档：app.tsx 的 settings 段、src/i18n.ts、src/host/autostart.ts、docs/contracts.md、README.md、docs/ACCEPTANCE_TUI_SHELL.md、CHANGELOG.md。
- 风险热点：src/index.ts 体量最大且 daemon/child index 都要改；先抽纯投影和 transport，再改状态机。每次只扩大一个契约，保持 embedded 路径和现有测试可运行。
