# TUI 思考与工具呈现 — 实施进度

计划：`PLAN_TUI_THINKING_2026-10-22.md`（默认推荐方案）

| 工作包 | 状态 | 验证结果 |
|---|---|---|
| W0 基线 | 完成 | 基线类型检查 + 渲染器测试通过；后续均已红到绿 |
| W1 开关语义 | 完成 | `newDesigns` 即时控制 transcript；主题解耦；provider/app 测试通过 |
| W2 classic Thinking/点击 | 完成 | `Thinking`/`Thought` 判定、点击折叠、空 Thought 抑制测试通过 |
| W3 分组模型 | 完成 | `thinking.test.ts` 覆盖正文边界、工具先行、多 turn、system、打断等 |
| W4 新版预览 | 完成 | 单块、5–10 行尾随、工具单行、CJK、40/80/120 列帧测试通过 |
| W5 展开/收起 | 完成 | 点击状态机、展开复用 classic reasoning/工具、正文到达不强制折叠 |
| W6 时长/时间戳 | 完成 | 共享 clock、`createdAt`/`bodyAt` 双端协议、`12s`/`1m 05s` 测试通过 |
| W7 集成与文档 | 完成（实机待用户确认） | README/CHANGELOG/contracts/acceptance 更新；全量门禁与 7 平台构建通过 |
| W8 选择高亮 | 完成 | 零长度清理、主题选择色、提交/切换/新轮次清理、拖选不误触展开 |
| W9 resume 加粗 | 完成 | host `joinTextBlocks` + 稳定 Markdown props + 列表项定点去标记 |
| W10 空会话不落盘 | 完成 | conversation-gated persistence、`/resume` 空白过滤、历史空目录安全清理 |
| W11 最后交互排序 | 完成 | `lastActivityAt`、tail 读取缓存、host 统一排序、today/yesterday 分组 |

## 最终验证

- `npm run check`：288 tests，287 pass，1 skipped，exit 0。
- `npm run check:renderer`：typecheck 通过；348 tests，0 fail，exit 0。
- `npm run build`：宿主 13 个入口（含 `lazy-session-persistence`）构建成功。
- `npm run build:renderer`：7 个平台产物构建成功。
- `npm run generate:sums`：7 artifacts，version 0.5.0。
- `npm run verify:ipc-protocol`：protocol v2，40 downstream / 26 upstream kinds 通过。

## 实现取舍（与计划的偏差）

1. OpenTUI 0.6.6 升级 spike 因 `SyntaxStyle` 新增资源所有者参数、当前 fallback 路径无法无侵入适配而回退；保留 0.5.17，
   使用稳定 props + 仅列表项的 strong 去标记兜底。段落 strong、fenced/inline code 仍正常。
2. 空会话修复采用计划备选 `lazySessionPersistence` 装饰器，而非全面 lazy-agent 生命周期重构；这样启动仍有一个
   内存 agent 供 Home/首条消息复用，但 setup-only handle 在 flush/close 时直接丢弃，不会调用后端 `create`。
3. 历史空目录清理只在同时满足：后端 list 可见、目录名精确匹配 `tui-*`、存在 v4 日志、非 live、读头确认无对话
   时删除；支持 dry-run，读失败一律保留。
4. `lastActivityAt` 采用 live 最后事件或 persisted tail event；后端不提供 `eventCount` / tail 读取失败时按计划回退
   `createdAt`，不读全量日志。

## 仍需用户完成

`docs/ACCEPTANCE_TUI_SHELL.md` 第 6 节的真机确认项（Windows Terminal / WezTerm 的 40×16、80×24、120×24 观感、
拖选配色、resume 加粗、空会话目录与排序）。未发布、未打 tag、未 push。
