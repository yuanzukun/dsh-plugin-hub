import { describe, it, afterEach } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, mkdir, writeFile, access, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { pruneBlankTuiSessionDirectories } from '../src/session-prune.ts'

const roots: string[] = []
afterEach(async () => {
  await Promise.all(roots.splice(0).map(root => rm(root, { recursive: true, force: true })))
})

async function fixture(): Promise<{ root: string; sessions: string; paths: Record<string, string> }> {
  const root = await mkdtemp(join(tmpdir(), 'dsh-prune-'))
  roots.push(root)
  const sessions = join(root, 'sessions', '--D-projects--')
  await mkdir(sessions, { recursive: true })
  const paths: Record<string, string> = {}
  for (const id of ['tui-blank', 'tui-real', 'tui-live', 'tui-unknown', 'ses-real']) {
    const dir = join(sessions, id)
    await mkdir(dir)
    await writeFile(join(dir, 'session.v4.jsonl.zstd'), 'not-decoded-in-this-test')
    paths[id] = dir
  }
  return { root, sessions, paths }
}

async function exists(path: string): Promise<boolean> {
  try { await access(path); return true } catch { return false }
}

describe('blank TUI session cleanup', () => {
  it('removes only backend-known, non-live directories confirmed blank', async () => {
    const { root, paths } = await fixture()
    const checked: string[] = []
    const result = await pruneBlankTuiSessionDirectories({
      root: join(root, 'sessions'),
      candidateIds: new Set(['tui-blank', 'tui-real', 'tui-live', 'ses-real']),
      liveIds: new Set(['tui-live']),
      isBlank: async id => {
        checked.push(id)
        return id === 'tui-blank'
      },
    })
    assert.deepEqual(result.removed, ['tui-blank'])
    assert.deepEqual(result.failed, [])
    assert.deepEqual(checked, ['tui-blank', 'tui-real'])
    assert.equal(await exists(paths['tui-blank']), false)
    assert.equal(await exists(paths['tui-real']), true)
    assert.equal(await exists(paths['tui-live']), true)
    assert.equal(await exists(paths['tui-unknown']), true)
    assert.equal(await exists(paths['ses-real']), true)
  })

  it('supports dry-run and never removes a directory whose log is missing', async () => {
    const { root, paths } = await fixture()
    const dry = await pruneBlankTuiSessionDirectories({
      root: join(root, 'sessions'),
      candidateIds: new Set(['tui-blank']),
      liveIds: new Set(),
      isBlank: async () => true,
      dryRun: true,
    })
    assert.deepEqual(dry.removed, ['tui-blank'])
    assert.equal(await exists(paths['tui-blank']), true)

    await rm(join(paths['tui-blank']!, 'session.v4.jsonl.zstd'))
    const missingLog = await pruneBlankTuiSessionDirectories({
      root: join(root, 'sessions'),
      candidateIds: new Set(['tui-blank']),
      liveIds: new Set(),
      isBlank: async () => true,
    })
    assert.deepEqual(missingLog.removed, [])
    assert.equal(await exists(paths['tui-blank']), true)
  })

  it('keeps a candidate when the blank check fails or the id is not tui-prefixed', async () => {
    const { root, paths } = await fixture()
    const result = await pruneBlankTuiSessionDirectories({
      root: join(root, 'sessions'),
      candidateIds: new Set(['tui-blank', 'ses-real']),
      liveIds: new Set(),
      isBlank: async id => {
        if (id === 'tui-blank') throw new Error('unreadable')
        return true
      },
    })
    assert.deepEqual(result.removed, [])
    assert.equal(result.failed.length, 1)
    assert.equal(await exists(paths['tui-blank']), true)
    assert.equal(await exists(paths['ses-real']), true)
  })
})
