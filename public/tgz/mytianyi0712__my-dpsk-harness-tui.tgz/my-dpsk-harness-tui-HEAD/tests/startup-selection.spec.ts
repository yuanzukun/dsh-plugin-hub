import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { startupModelSelection } from '../src/startup-selection.ts'
import { ReasoningEffortId } from '../src/dsh-host/index.ts'

describe('startup model selection', () => {
  it('restores the saved provider, model, and effort for a blank startup session', () => {
    const selection = startupModelSelection(
      undefined,
      { provider: 'saved-provider', model: 'saved-model', effort: 'max', preset: 'minimal' },
      { provider: 'option-provider', model: 'option-model' },
      { provider: 'configured-provider', model: 'configured-model', reasoningEffort: ReasoningEffortId('high') },
      'medium',
    )
    assert.deepEqual(selection, {
      provider: 'saved-provider',
      model: 'saved-model',
      reasoningEffort: ReasoningEffortId('max'),
    })
  })

  it('keeps a historical session request header authoritative', () => {
    const selection = startupModelSelection(
      { config: { provider: 'history-provider', model: 'history-model', reasoningEffort: ReasoningEffortId('low') } } as never,
      { provider: 'saved-provider', model: 'saved-model', effort: 'max' },
      {},
      { provider: 'configured-provider', model: 'configured-model' },
      'medium',
    )
    assert.deepEqual(selection, {
      provider: 'history-provider',
      model: 'history-model',
      reasoningEffort: ReasoningEffortId('low'),
    })
  })

  it('falls back through target options and the configured route when no saved route exists', () => {
    const fromOptions = startupModelSelection(
      undefined,
      undefined,
      { provider: 'option-provider', model: 'option-model' },
      { provider: 'configured-provider', model: 'configured-model', reasoningEffort: ReasoningEffortId('high') },
      'medium',
    )
    assert.deepEqual(fromOptions, {
      provider: 'option-provider',
      model: 'option-model',
      reasoningEffort: ReasoningEffortId('high'),
    })
    const fromConfigured = startupModelSelection(
      undefined,
      undefined,
      {},
      { provider: 'configured-provider', model: 'configured-model' },
      'medium',
    )
    assert.deepEqual(fromConfigured, {
      provider: 'configured-provider',
      model: 'configured-model',
      reasoningEffort: ReasoningEffortId('medium'),
    })
  })
})
