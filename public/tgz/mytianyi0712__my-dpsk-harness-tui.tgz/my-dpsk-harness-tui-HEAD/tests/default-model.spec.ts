import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { AGENT_DEFAULT_MODEL_NAMESPACE, defaultModelPatch, saveDefaultModel } from '../src/settings.ts'

/**
 * dsh's own `agentDefaultModel` row plugin writes through the loader's `configEditor` and
 * returns silently when that service is missing, so a model picked in the TUI never became
 * the default and every restart reopened on the profile's original route. dsh *does* register
 * the settings form for the same row, and that write lands in the profile patch layer — these
 * tests pin the seam that replaced the silent one.
 */
describe('default model persistence', () => {
  it('targets the row dsh registers for the default model', () => {
    // `settingsNamespace` is an identity cast, so the row id is the dsh plugin name.
    assert.equal(AGENT_DEFAULT_MODEL_NAMESPACE, 'agent-default-model')
  })

  it('patches provider, model and effort as one write', () => {
    assert.deepEqual(
      defaultModelPatch({ provider: 'cliproxy', model: 'mimo-v2.6-pro', reasoningEffort: 'high' }),
      { provider: 'cliproxy', model: 'mimo-v2.6-pro', reasoningEffort: 'high' },
    )
  })

  it('leaves the effort out when the route has none', () => {
    // A model without reasoning levels must not inherit the previous route's effort.
    assert.deepEqual(defaultModelPatch({ provider: 'cliproxy', model: 'deepseek-v4.1-flash' }), {
      provider: 'cliproxy',
      model: 'deepseek-v4.1-flash',
    })
  })

  it('writes the patch through the settings service', async () => {
    const calls: Array<{ namespace: string; patch: Record<string, string> }> = []
    const settings = {
      update: async (namespace: string, patch: Record<string, string>) => {
        calls.push({ namespace, patch })
        return undefined
      },
    }
    await saveDefaultModel(settings, { provider: 'cliproxy', model: 'mimo-v2.6-pro', reasoningEffort: 'high' })
    assert.deepEqual(calls, [
      {
        namespace: 'agent-default-model',
        patch: { provider: 'cliproxy', model: 'mimo-v2.6-pro', reasoningEffort: 'high' },
      },
    ])
  })

  it('does nothing when the settings service is absent', async () => {
    // The plugin can mount without a settings service (older host); a pick must still work.
    await saveDefaultModel(undefined, { provider: 'cliproxy', model: 'mimo-v2.6-pro' })
  })
})
