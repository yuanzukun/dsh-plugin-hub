import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { readdirSync } from 'node:fs'
import { join } from 'node:path'
import {
  FALLBACK_THEME_ID,
  SELECTABLE_THEME_IDS,
  SHIPPED_THEME_IDS,
  isSelectableTheme,
} from '../src/theme-catalog.ts'

/**
 * The renderer bundles one JSON document per shipped theme, and the host keeps a
 * mirror of their ids for the one-time `themeName` migration. A document added or
 * removed without the mirror would let the migration keep a dead id (or reject a
 * live one), so the two lists are asserted equal here.
 */
function shippedDocuments(): string[] {
  const directory = join(import.meta.dirname, '..', 'renderer', 'src', 'theme', 'native', 'assets')
  return readdirSync(directory)
    .filter(name => name.endsWith('.json'))
    .map(name => name.slice(0, -'.json'.length))
    .sort()
}

describe('theme catalog', () => {
  it('mirrors exactly the shipped renderer documents', () => {
    assert.deepEqual([...SHIPPED_THEME_IDS].sort(), shippedDocuments())
  })

  it('offers the runtime-generated ids on top of the shipped documents', () => {
    assert.deepEqual(SELECTABLE_THEME_IDS, [...SHIPPED_THEME_IDS, 'system', 'opencode2'])
  })

  it('falls back to a shipped theme', () => {
    assert.ok(SHIPPED_THEME_IDS.includes(FALLBACK_THEME_ID as (typeof SHIPPED_THEME_IDS)[number]))
    assert.equal(isSelectableTheme('system'), true)
    assert.equal(isSelectableTheme('dark-catppuccin'), false)
  })
})
