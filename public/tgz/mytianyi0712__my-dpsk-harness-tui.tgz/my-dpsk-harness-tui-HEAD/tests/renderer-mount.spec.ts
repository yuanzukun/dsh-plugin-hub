import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { mountRenderer } from '../src/host/renderer-mount.ts'
import { emit, fakeChild, helloEnvelope, sentEnvelopes } from './helpers/fake-child.ts'
import type { TranscriptEvent } from '../src/ipc/kinds.ts'

function snapshot(events: readonly TranscriptEvent[]) {
  return () => ({
    sessionId: 'ses_1',
    title: 'first prompt',
    events,
    provider: 'cliproxy',
    model: 'mimo-v2.6-pro',
    effort: 'high',
    permission: 'auto',
    preset: 'standard',
  })
}

function mountWith(overrides: Partial<Parameters<typeof mountRenderer>[0]> = {}) {
  const { child, state } = fakeChild()
  const writes: string[] = []
  const notices: Array<{ text: string; level: string }> = []
  const submitted: string[] = []
  const dir = mkdtempSync(join(tmpdir(), 'dpsk-mount-'))
  const unsubscribes: number[] = []
  // Fake streams: the router replaces `write`, and replacing the real
  // `process.stdout.write` inside a test run swallows the runner's own output.
  const streams = {
    stdout: { write: (chunk: unknown) => { writes.push(String(chunk)); return true } },
    stderr: { write: (chunk: unknown) => { writes.push(String(chunk)); return true } },
  }
  const fakeOut = streams.stdout.write
  const mount = mountRenderer({
    rendererPath: join(dir, 'renderer.bin'),
    snapshot: snapshot([{ id: 'u1', role: 'user', text: 'hello' }]),
    subscribe: emitEvents => {
      emitEvents('ses_1', [])
      return () => unsubscribes.push(1)
    },
    submit: text => submitted.push(text),
    notice: (text, level) => notices.push({ text, level }),
    write: text => writes.push(text),
    logPath: join(dir, 'tui.log'),
    streams,
    spawn: () => child,
    ...overrides,
  })
  return { state, writes, notices, submitted, dir, unsubscribes, mount, child, streams, fakeOut }
}

describe('renderer mount', () => {
  it('reports a missing renderer artifact instead of spawning a missing path', () => {
    const { writes, notices, mount } = mountWith({ rendererPath: undefined })
    assert.equal(mount, undefined)
    assert.ok(writes.some(entry => entry.includes('no renderer artifact found')))
    assert.deepEqual(notices, [{ text: 'no renderer artifact found', level: 'error' }])
  })

  it('sends the session snapshot after the handshake without any theme document', () => {
    const { state, mount } = mountWith()
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const kinds = sentEnvelopes(state).map(envelope => envelope.kind)
    assert.deepEqual(kinds.slice(0, 1), ['hello-ack'])
    assert.ok(!kinds.includes('theme-doc'))
    assert.ok(!kinds.includes('theme-list'))
    const snapshot = sentEnvelopes(state).find(envelope => envelope.kind === 'session-snapshot')
    assert.ok(snapshot !== undefined)
    assert.equal(snapshot.payload.title, 'first prompt')
    assert.deepEqual(snapshot.payload.events, [{ id: 'u1', role: 'user', text: 'hello' }])
    assert.equal(snapshot.payload.model, 'mimo-v2.6-pro')
  })

  it('carries the session usage projection in the initial snapshot', () => {
    const { state, mount } = mountWith({
      snapshot: () => ({
        sessionId: 'ses_1',
        initialRoute: 'session',
        title: 'first prompt',
        events: [],
        provider: 'cliproxy',
        model: 'mimo-v2.6-pro',
        effort: 'high',
        permission: 'auto',
        preset: 'standard',
        availableActions: [],
        attachmentCapabilities: { files: false, images: false },
        usage: {
          sessionId: 'ses_1',
          inputTokens: 12000,
          outputTokens: 3400,
          cacheReadTokens: 8000,
          cacheWriteTokens: 200,
          cacheReadObserved: true,
          contextTokens: 12300,
          contextWindow: 131072,
          contextPct: 9,
        },
      }),
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const snapshot = sentEnvelopes(state).find(envelope => envelope.kind === 'session-snapshot')
    assert.equal(snapshot?.payload.usage.cacheReadTokens, 8000)
    assert.equal(snapshot?.payload.usage.cacheReadObserved, true)
  })

  it('sends the efforts and session list on the handshake', () => {
    const { state, mount } = mountWith({
      efforts: () => ({ efforts: ['off', 'low', 'medium', 'high', 'max'], current: 'high' }),
      sessions: () => [{ id: 'ses_1', title: 'first prompt', active: true }, { id: 'ses_2', title: 'second', active: false }],
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const sent = sentEnvelopes(state)
    const kinds = sent.map(envelope => envelope.kind)
    // The handshake gate queues sends made before the ack, so the `session-frame`
    // the subscribe emits at mount time is flushed last. The session-scoped catalogs
    // follow the snapshot: the renderer resets them when a snapshot names a session.
    assert.deepEqual(kinds, ['hello-ack', 'session-list', 'session-snapshot', 'reasoning-efforts', 'session-frame'])
    const efforts = sent.find(envelope => envelope.kind === 'reasoning-efforts')
    assert.deepEqual(efforts?.payload.efforts, ['off', 'low', 'medium', 'high', 'max'])
    assert.equal(efforts?.payload.current, 'high')
    const list = sent.find(envelope => envelope.kind === 'session-list')
    assert.deepEqual(list?.payload.sessions, [{ id: 'ses_1', title: 'first prompt', active: true }, { id: 'ses_2', title: 'second', active: false }])
    assert.equal(list?.payload.current, 'ses_1')
  })

  it('never sends a kind the renderer did not list', () => {
    let subscribed = 0
    const { state, mount } = mountWith({ efforts: () => ({ efforts: ['high'], current: 'high' }), subagents: emitAgents => { subscribed += 1; emitAgents('ses_1', []); return () => undefined } })
    assert.ok(mount !== undefined)
    const hello = helloEnvelope()
    const kinds = (hello.payload as { kinds: string[] }).kinds.filter(kind => kind !== 'subagent-list')
    emit(state, 'message', JSON.stringify({ ...hello, payload: { ...(hello.payload as object), kinds } }))
    const sent = sentEnvelopes(state).map(envelope => envelope.kind)
    assert.ok(sent.includes('hello-ack'))
    assert.ok(sent.includes('session-snapshot'))
    // `reasoning-efforts` is a required kind, so the negotiation does not skip it; an
    // optional kind the renderer left out is skipped on every path, initial value included.
    assert.ok(sent.includes('reasoning-efforts'))
    assert.ok(!sent.includes('subagent-list'))
    // The subscription itself is not opened, so its replay cannot become a send later.
    assert.equal(subscribed, 0)
  })

  it('answers a settings write on its request id, with the written values or the error', async () => {
    let wrote: { patch: Record<string, unknown>; ns: string } | undefined
    const { state, mount } = mountWith({
      settingsSection: () => ({ ns: 'dpsk-tui', schemaVersion: 2, values: { showReasoning: false } }),
      updateSettings: async (patch, ns) => {
        wrote = { patch, ns }
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 5, kind: 'update-settings', payload: { requestId: 'r1', patch: { showReasoning: false } } }))
    await new Promise(resolve => setImmediate(resolve))
    assert.deepEqual(wrote, { patch: { showReasoning: false }, ns: 'tui' })
    const answered = sentEnvelopes(state).filter(envelope => envelope.kind === 'settings').at(-1)
    assert.equal(answered?.payload.requestId, 'r1')
    assert.equal(answered?.payload.values.showReasoning, false)
    assert.equal(answered?.payload.error, undefined)
  })

  it('reports a settings write failure on the same request id', async () => {
    const { state, mount } = mountWith({
      settingsSection: () => ({ ns: 'dpsk-tui', schemaVersion: 2, values: {} }),
      updateSettings: async () => {
        throw new Error('disk is read-only')
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 6, kind: 'update-settings', payload: { requestId: 'r2', patch: { keyTools: 'tab' } } }))
    await new Promise(resolve => setImmediate(resolve))
    const answered = sentEnvelopes(state).filter(envelope => envelope.kind === 'settings').at(-1)
    assert.equal(answered?.payload.requestId, 'r2')
    assert.equal(answered?.payload.error, 'disk is read-only')
  })

  it('routes the composer submit through the host', async () => {
    const { state, submitted, mount } = mountWith()
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 1, kind: 'send-message', payload: { sessionId: 'ses_1', text: '/theme dark-catppuccin', delivery: 'steer' } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 2, kind: 'send-message', payload: { sessionId: 'ses_1', text: '   ', delivery: 'steer' } }))
    await new Promise(resolve => setImmediate(resolve))
    assert.deepEqual(submitted, [{ sessionId: 'ses_1', text: '/theme dark-catppuccin', delivery: 'steer' }])
  })

  it('routes the renderer interrupt request through the host cancel seam', async () => {
    let cancelled = 0
    const { state, mount } = mountWith({ interrupt: () => { cancelled += 1 } })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 1, kind: 'interrupt', payload: { sessionId: 'ses_1' } }))
    await new Promise(resolve => setImmediate(resolve))
    assert.equal(cancelled, 1)
  })

  it('ignores a theme id because the renderer owns the theme catalog', () => {
    const { state, mount } = mountWith()
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 1, kind: 'set-selection', payload: { sessionId: 'ses_1', effort: 'high' } }))
    assert.ok(!sentEnvelopes(state).some(envelope => envelope.kind === 'theme-doc'))
  })

  it('answers a renderer dialog request on the sequence the request arrived on', () => {
    const requests: Array<{ kind: string; args: unknown }> = []
    const { state, mount } = mountWith({
      dialogRequest: (kind, args, reply) => {
        requests.push({ kind, args })
        reply('saved')
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 7, kind: 'dialog-request', payload: { kind: 'provider-form', args: { id: 'cliproxy' } } }))
    assert.deepEqual(requests, [{ kind: 'provider-form', args: { id: 'cliproxy' } }])
    const response = sentEnvelopes(state).filter(envelope => envelope.kind === 'dialog-response').at(-1)
    // The answer is correlated by the request's sequence, not the host's own counter.
    assert.equal(response?.payload.seq, 7)
    assert.equal(response?.payload.value, 'saved')
  })

  it('ignores a dialog request when the host has no dialog handler', () => {
    const { state, mount } = mountWith()
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 3, kind: 'dialog-request', payload: { kind: 'provider-form' } }))
    assert.equal(sentEnvelopes(state).filter(envelope => envelope.kind === 'dialog-response').length, 0)
  })

  it('routes session lifecycle requests through the host session seam', async () => {
    const ops: Array<Record<string, unknown>> = []
    const { state, mount } = mountWith({ sessionOp: request => ops.push(request) })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 4, kind: 'session-op', payload: { op: 'new', sessionId: 'ses_new', selection: { provider: 'cliproxy', model: 'mimo', preset: 'standard' } } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 5, kind: 'session-op', payload: { op: 'switch', sessionId: 'ses_2' } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 6, kind: 'session-op', payload: { op: 'rename', sessionId: 'ses_1', title: 'renamed' } }))
    await new Promise(resolve => setImmediate(resolve))
    assert.deepEqual(ops, [
      { sessionId: 'ses_new', op: 'new', selection: { provider: 'cliproxy', model: 'mimo', preset: 'standard' } },
      { sessionId: 'ses_2', op: 'switch' },
      { sessionId: 'ses_1', op: 'rename', title: 'renamed' },
    ])
  })

  it('routes model, effort, permission and preset picks to the host write-back seam', async () => {
    const selections: Array<Record<string, string | undefined>> = []
    const { state, mount } = mountWith({ setSelection: async selection => { selections.push(selection) } })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 4, kind: 'set-selection', payload: { sessionId: 'ses_1', provider: 'cliproxy', model: 'mimo-v2.6-pro' } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 5, kind: 'set-selection', payload: { sessionId: 'ses_1', effort: 'max' } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 6, kind: 'set-selection', payload: { sessionId: 'ses_1', permission: 'danger-full-access' } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 7, kind: 'set-selection', payload: { sessionId: 'ses_1', preset: 'code' } }))
    // A pick with nothing to write back is dropped, so the host is not called with an empty patch.
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 8, kind: 'set-selection', payload: { sessionId: 'ses_1' } }))
    await new Promise(resolve => setImmediate(resolve))
    assert.deepEqual(selections, [
      { sessionId: 'ses_1', provider: 'cliproxy', model: 'mimo-v2.6-pro' },
      { sessionId: 'ses_1', effort: 'max' },
      { sessionId: 'ses_1', permission: 'danger-full-access' },
      { sessionId: 'ses_1', preset: 'code' },
    ])
  })

  it('returns an exact queued message for edit and deletes only the requested id', async () => {
    const edits: Array<{ sessionId: string; id?: string }> = []
    const deletions: Array<{ sessionId: string; id: string }> = []
    const { state, mount } = mountWith({
      editInterjection: request => { edits.push(request); return 'fix the tests' },
      deleteInterjection: async request => { deletions.push(request) },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 9, kind: 'interject-edit', payload: { sessionId: 'ses_1', id: 'msg-2' } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 10, kind: 'interject-delete', payload: { sessionId: 'ses_1', id: 'msg-1' } }))
    await new Promise<void>(resolve => setImmediate(resolve))
    assert.deepEqual(edits, [{ sessionId: 'ses_1', id: 'msg-2' }])
    assert.deepEqual(deletions, [{ sessionId: 'ses_1', id: 'msg-1' }])
    const results = sentEnvelopes(state).filter(envelope => envelope.kind === 'command-result')
    assert.deepEqual(results.map(result => ({ seq: result.payload.seq, ok: result.payload.ok, value: result.payload.value })), [
      { seq: 9, ok: true, value: 'fix the tests' },
      { seq: 10, ok: true, value: undefined },
    ])
  })


  it('correlates approval answers and treats renderer close as rejection', async () => {
    const { state, mount } = mountWith()
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const first = mount.approve({ sessionId: 'ses_1', toolName: 'shell', reason: 'run command' })
    const request = sentEnvelopes(state).find(envelope => envelope.kind === 'approval-request')
    assert.equal(request?.payload.toolName, 'shell')
    assert.equal(typeof request?.payload.request, 'string')
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 11, kind: 'approval-answer', payload: { request: request?.payload.request, outcome: 'allowed-once' } }))
    assert.equal(await first, 'allowed-once')
    const second = mount.approve({ sessionId: 'ses_1', toolName: 'write' })
    const requests = sentEnvelopes(state).filter(envelope => envelope.kind === 'approval-request')
    const secondRequest = requests[1]
    assert.ok(secondRequest)
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 12, kind: 'approval-close', payload: { request: secondRequest.payload.request } }))
    assert.equal(await second, 'rejected')
  })

  it('correlates exact question requests and supports cancellation close', async () => {
    const { state, mount } = mountWith()
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const pending = mount.askQuestion({ request: 'q-child', sessionId: 'ses_1', state: 'open', questions: [{ id: 'q', question: 'choose', options: [{ label: 'yes', description: 'allow' }] }] })
    const sent = sentEnvelopes(state).find(envelope => envelope.kind === 'question-request')
    assert.equal(sent?.payload.request, 'q-child')
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 13, kind: 'question-answer', payload: { request: 'q-child', answers: [{ id: 'q', selected: ['yes'] }] } }))
    assert.deepEqual(await pending, [{ id: 'q', selected: ['yes'] }])
    const closed = mount.askQuestion({ request: 'q-close', sessionId: 'ses_1', state: 'continued', questions: [{ id: 'q', question: 'again' }] })
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 14, kind: 'question-close', payload: { request: 'q-close' } }))
    assert.equal(await closed, undefined)
  })
  it('pushes the turn state and the catalogs after the handshake', () => {
    const { state, mount } = mountWith({
      commands: () => [{ name: 'model', description: 'pick a model' }, { name: 'think', description: 'set effort', argumentHint: '<level>' }],
      models: () => [{ provider: 'cliproxy', model: 'mimo-v2.6-pro', label: 'MiMo', current: true }],
      turnState: emit => {
        emit('ses_1', false)
        emit('ses_1', true)
        return () => undefined
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const sent = sentEnvelopes(state)
    const commands = sent.find(envelope => envelope.kind === 'command-catalog')
    assert.equal(commands?.payload.commands.length, 2)
    const models = sent.find(envelope => envelope.kind === 'model-catalog')
    assert.equal(models?.payload.models[0].label, 'MiMo')
    const turns = sent.filter(envelope => envelope.kind === 'turn-state').map(envelope => envelope.payload.running)
    assert.deepEqual(turns, [false, true])
  })

  it('passes the session workspace through so the renderer completes @ paths locally', () => {
    const { state, mount } = mountWith({
      snapshot: () => ({
        sessionId: 'ses_1', title: 'first prompt', events: [],
        provider: 'cliproxy', model: 'mimo', effort: 'high', permission: 'auto', preset: 'standard',
        workspace: 'D:/projects/dsh',
      }),
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const snapshot = sentEnvelopes(state).find(envelope => envelope.kind === 'session-snapshot')
    assert.equal(snapshot?.payload.workspace, 'D:/projects/dsh')
  })

  it('routes settings writes through the host seam and answers an empty patch', async () => {
    const patches: Array<{ patch: Record<string, unknown>; ns: 'tui' | 'agent-loop' }> = []
    const { state, mount } = mountWith({
      settingsSection: () => ({ ns: 'dpsk-tui', schemaVersion: 2, values: { showReasoning: true, maxToolOutputLines: 5 }, agentLoop: { maxParallelToolCalls: 3 } }),
      updateSettings: async (patch, ns) => {
        patches.push({ patch, ns })
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const settings = sentEnvelopes(state).find(envelope => envelope.kind === 'settings')
    assert.equal(settings?.payload.schemaVersion, 2)
    assert.equal(settings?.payload.values.maxToolOutputLines, 5)
    assert.equal(settings?.payload.agentLoop.maxParallelToolCalls, 3)
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 5, kind: 'update-settings', payload: { requestId: 'a', patch: { showReasoning: false } } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 6, kind: 'update-settings', payload: { requestId: 'b', patch: {} } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 7, kind: 'update-settings', payload: { requestId: 'c', patch: { maxParallelToolCalls: 5 }, ns: 'agent-loop' } }))
    await new Promise(resolve => setImmediate(resolve))
    // The default namespace is the TUI one; an agent-loop write carries `ns`. An empty
    // patch writes nothing and is answered with a real error on its request id.
    assert.deepEqual(patches, [{ patch: { showReasoning: false }, ns: 'tui' }, { patch: { maxParallelToolCalls: 5 }, ns: 'agent-loop' }])
    const empty = sentEnvelopes(state).filter(envelope => envelope.kind === 'settings' && envelope.payload.requestId === 'b').at(-1)
    assert.equal(empty?.payload.error, 'nothing to write')
  })

  it('sends the locale and the dictionary with the handshake catalogs', () => {
    const { state, mount } = mountWith({ i18n: () => ({ locale: 'zh-CN', strings: { rendererSession: '会话: ', rendererPlaceholder: '提示词' } }) })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const payload = sentEnvelopes(state).find(envelope => envelope.kind === 'i18n')?.payload
    assert.equal(payload.locale, 'zh-CN')
    assert.equal(payload.strings.rendererSession, '会话: ')
  })

  it('pushes transcript deltas as session-frame', () => {
    const { state, mount } = mountWith()
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const sent = sentEnvelopes(state)
    assert.ok(sent.some(envelope => envelope.kind === 'session-frame'))
  })


  it('forwards the terminal scheme the renderer detected', () => {
    const seen: string[] = []
    const { state, mount } = mountWith({ onTerminalScheme: scheme => seen.push(scheme) })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 1, kind: 'terminal-scheme', payload: { scheme: 'light' } }))
    assert.deepEqual(seen, ['light'])
    assert.ok(!sentEnvelopes(state).some(envelope => envelope.kind === 'theme-doc'))
  })

  it('restores the terminal and unsubscribes on bye without killing the renderer', () => {
    const { state, writes, unsubscribes, mount } = mountWith()
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 1, kind: 'bye', payload: {} }))
    // The renderer writes its own restore right after `bye`; killing it here truncated that
    // sequence and handed the shell back with mouse tracking still on.
    assert.equal(state.kills, 0)
    assert.ok(writes.some(text => text.includes('\x1b[?1006l')))
    assert.equal(unsubscribes.length, 1)
  })

  it('kills a renderer that never exits after bye', async () => {
    const { state, mount } = mountWith({ byeGraceMs: 20 })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 1, kind: 'bye', payload: {} }))
    assert.equal(state.kills, 0)
    await new Promise(resolve => setTimeout(resolve, 80))
    assert.equal(state.kills, 1)
  })

  it('drops every send after the renderer asks to quit', () => {
    const { state, notices, mount } = mountWith()
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 5, kind: 'bye', payload: {} }))
    const before = sentEnvelopes(state).length
    // The renderer's channel is closing: anything the mount would send afterwards (a
    // question the host still asks, a late notice) must be dropped, not thrown as
    // ERR_IPC_CHANNEL_CLOSED. `ask` goes through the mount's own send seam.
    void mount.ask([{ id: 'late', question: 'still there?' }])
    assert.equal(sentEnvelopes(state).length, before)
    // Nothing is killed on `bye`: the renderer is on its way out by itself.
    assert.equal(state.kills, 0)
    assert.ok(!notices.some(entry => entry.text.includes('ERR_IPC')))
  })

  it('unsubscribes and reports on abnormal exit', () => {
    const { state, notices, unsubscribes, mount } = mountWith()
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'exit', 1, null)
    assert.equal(unsubscribes.length, 1)
    assert.ok(notices.some(entry => entry.text.includes('exited abnormally')))
  })

  it('writes dsh output to the log file and forwards it as a log envelope', () => {
    const { state, streams, dir, mount } = mountWith()
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    streams.stdout.write('routed line\n')
    const logged = readFileSync(join(dir, 'tui.log'), 'utf8')
    assert.ok(logged.includes('routed line'))
    assert.ok(sentEnvelopes(state).some(envelope => envelope.kind === 'log' && String(envelope.payload.text).includes('routed line')))
  })

  it('puts the original write functions back on stop', () => {
    const { state, streams, mount, fakeOut } = mountWith()
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    assert.notEqual(streams.stdout.write, fakeOut)
    mount.stop()
    assert.equal(streams.stdout.write, fakeOut)
  })

  it('pushes the WeChat bridge output after the handshake, including the replayed backlog', () => {
    const { state, mount } = mountWith({
      wechatOutput: emitMessage => {
        emitMessage({ kind: 'status', text: 'paired: 2 accounts' })
        emitMessage({ kind: 'qr', text: '▄▀█' })
        return () => undefined
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const outputs = sentEnvelopes(state).filter(envelope => envelope.kind === 'wechat-output')
    assert.deepEqual(outputs.map(envelope => envelope.payload.kind), ['status', 'qr'])
  })

  it('routes a bridge command to the host seam and drops an empty op', () => {
    const ops: Array<{ op: string; arg: string | undefined }> = []
    const { state, mount } = mountWith({ wechatOp: (op, arg) => ops.push({ op, arg }) })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 6, kind: 'wechat-op', payload: { op: 'pair', arg: 'u123' } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 7, kind: 'wechat-op', payload: { op: '' } }))
    assert.deepEqual(ops, [{ op: 'pair', arg: 'u123' }])
  })

  it('routes shell-job-op to the host seam and rejects a malformed request before it', async () => {
    const calls: unknown[] = []
    const { state, mount } = mountWith({ shellJobOp: async request => { calls.push(request); return { chunks: [], next: 0, lossy: false } } })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 20, kind: 'shell-job-op', payload: { sessionId: 'ses_1', id: 'job-1', op: 'read', from: 8 } }))
    await new Promise(resolve => setImmediate(resolve))
    assert.deepEqual(calls, [{ sessionId: 'ses_1', id: 'job-1', op: 'read', from: 8 }])
    const ok = sentEnvelopes(state).find(envelope => envelope.kind === 'command-result' && envelope.payload.seq === 20)
    assert.equal(ok?.payload.ok, true)
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 21, kind: 'shell-job-op', payload: { sessionId: 'ses_1', id: 'job-1', op: 'read', from: -1 } }))
    await new Promise(resolve => setImmediate(resolve))
    const bad = sentEnvelopes(state).find(envelope => envelope.kind === 'command-result' && envelope.payload.seq === 21)
    assert.equal(bad?.payload.ok, false)
    assert.match(String(bad?.payload.error), /valid operation/)
    assert.equal(calls.length, 1)
  })

  it('routes terminal-op to the host seam and its stream frames back down', async () => {
    const calls: unknown[] = []
    const { state, mount } = mountWith({
      terminalOp: async (request, emit) => {
        calls.push(request)
        if (request.op === 'follow') emit('terminal-frame', { sessionId: 'ses_1', id: 'term-1', attachmentId: 'att-1', frame: { type: 'output', sequence: 1, data: 'hi' } })
        return { terminals: [], environment: { cwd: '.', maxInputBytes: 1024, maxCols: 80, maxRows: 24, scrollback: 100 } }
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 30, kind: 'terminal-op', payload: { sessionId: 'ses_1', op: 'follow', id: 'term-1', attachmentId: 'att-1' } }))
    await new Promise(resolve => setImmediate(resolve))
    assert.deepEqual(calls, [{ sessionId: 'ses_1', op: 'follow', id: 'term-1', attachmentId: 'att-1' }])
    const frames = sentEnvelopes(state).filter(envelope => envelope.kind === 'terminal-frame')
    assert.deepEqual(frames.map(envelope => envelope.payload.frame.sequence), [1])
    // A `write` without data, and a `resize` with a zero column, are refused by the gate.
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 31, kind: 'terminal-op', payload: { sessionId: 'ses_1', op: 'write', id: 'term-1', attachmentId: 'att-1' } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 32, kind: 'terminal-op', payload: { sessionId: 'ses_1', op: 'resize', id: 'term-1', attachmentId: 'att-1', cols: 0, rows: 10 } }))
    await new Promise(resolve => setImmediate(resolve))
    const refused = sentEnvelopes(state).filter(envelope => envelope.kind === 'command-result' && [31, 32].includes(envelope.payload.seq as number))
    assert.deepEqual(refused.map(envelope => envelope.payload.ok), [false, false])
    assert.equal(calls.length, 1)
  })

  it('answers a doctor request correlated by the request seq', async () => {
    const { state, mount } = mountWith({ doctor: async op => `${op}: ok` })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 12, kind: 'doctor-check', payload: { op: 'plugins' } }))
    await new Promise(resolve => setImmediate(resolve))
    const results = sentEnvelopes(state).filter(envelope => envelope.kind === 'command-result')
    assert.deepEqual(results.map(envelope => [envelope.payload.seq, envelope.payload.text]), [[12, 'plugins: ok']])
  })

  it('reports a failed doctor run as an error result', async () => {
    const { state, mount } = mountWith({ doctor: async () => { throw new Error('host gone') } })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 3, kind: 'doctor-check', payload: { op: 'doctor' } }))
    await new Promise(resolve => setImmediate(resolve))
    const result = sentEnvelopes(state).find(envelope => envelope.kind === 'command-result')
    assert.equal(result?.payload.ok, false)
    assert.equal(result?.payload.error, 'host gone')
  })

  it('pushes the skill list on subscribe', async () => {
    const { state, mount } = mountWith({
      skills: emit => {
        emit('ses_1', [{ name: 'dsh-review', description: 'review the diff' }])
        return () => undefined
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    await new Promise(resolve => setImmediate(resolve))
    const lists = sentEnvelopes(state).filter(envelope => envelope.kind === 'skills-list')
    assert.equal(lists.length, 1)
    assert.deepEqual(lists[0].payload.skills.map((s: { name: string }) => s.name), ['dsh-review'])
  })

  it('pushes usage, branch, MCP server names, plugin inventory, and todos on subscribe', async () => {
    const { state, mount } = mountWith({
      usage: emit => {
        emit({ sessionId: 'ses_1', inputTokens: 12000, outputTokens: 3400, cacheReadTokens: 8000, cacheWriteTokens: 200, contextTokens: 12300, contextWindow: 131072, contextPct: 9 })
        return () => undefined
      },
      gitBranch: emit => {
        emit('ses_1', 'main')
        return () => undefined
      },
      mcpServers: emit => {
        emit([{ id: 'mcp-1', name: 'dsh-review', status: 'active' }, { id: 'mcp-2', name: 'git-commit', status: 'active' }])
        return () => undefined
      },
      hostPlugins: async () => [{ id: 'p-1', moduleName: 'dsh-review', enabled: true, fiberPhase: 'active' }],
      todos: emit => {
        emit('ses_1', [{ content: 'fix the bug', status: 'in_progress' }])
        return () => undefined
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const { promise: settle, resolve: settleNow } = Promise.withResolvers<void>()
    setImmediate(settleNow)
    await settle
    const sent = sentEnvelopes(state)
    const usage = sent.find(envelope => envelope.kind === 'usage')
    assert.equal(usage?.payload.contextPct, 9)
    assert.equal(usage?.payload.cost, undefined)
    assert.equal(sent.find(envelope => envelope.kind === 'git-branch')?.payload.branch, 'main')
    const mcp = sent.find(envelope => envelope.kind === 'mcp-servers')
    assert.deepEqual(mcp?.payload.servers.map((i: { name: string }) => i.name), ['dsh-review', 'git-commit'])
    const plugins = sent.find(envelope => envelope.kind === 'host-plugins')
    assert.equal(plugins?.payload.plugins[0].moduleName, 'dsh-review')
    const todo = sent.find(envelope => envelope.kind === 'todos')
    assert.equal(todo?.payload.items[0].status, 'in_progress')
  })

  it('pushes the subagent list on subscribe and on every change', async () => {
    const { state, mount } = mountWith({
      subagents: emit => {
        emit('ses_1', [{ label: 'explorer', provider: 'cliproxy', mode: 'one-shot' }])
        return () => undefined
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    await new Promise(resolve => setImmediate(resolve))
    const lists = sentEnvelopes(state).filter(envelope => envelope.kind === 'subagent-list')
    assert.equal(lists.length, 1)
    assert.deepEqual(lists[0].payload.agents.map((a: { label: string; mode: string }) => [a.label, a.mode]), [['explorer', 'one-shot']])
  })

  it('asks the renderer a user-questions request and resolves on the matching answer', async () => {
    const { state, mount } = mountWith({})
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const answers = mount.ask([{ id: 'a', question: 'pick a route', options: [{ label: 'fast' }] }])
    const request = sentEnvelopes(state).find(envelope => envelope.kind === 'question-request')
    assert.ok(request !== undefined)
    assert.deepEqual(request.payload.questions.map((q: { id: string; options?: { label: string }[] }) => [q.id, q.options?.map(o => o.label)]), [['a', ['fast']]])
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 40, kind: 'question-answer', payload: { request: request.payload.request, answers: [{ id: 'a', selected: ['fast'] }] } }))
    assert.deepEqual(await answers, [{ id: 'a', selected: ['fast'] }])
    // An answer for a request the mount never sent is dropped, and a consumed request
    // does not reopen: the correlation is the mount's counter, not the envelope seq.
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 41, kind: 'question-answer', payload: { request: 'q99', answers: [] } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 42, kind: 'question-answer', payload: { request: 'q1', answers: [{ id: 'a', selected: ['late'] }] } }))
    await new Promise(resolve => setImmediate(resolve))
    assert.equal(sentEnvelopes(state).filter(envelope => envelope.kind === 'question-request').length, 1)
  })

  it('passes the request args to the form field list', async () => {
    const seen: Array<{ form: string; args: Record<string, unknown> | undefined }> = []
    const { state, mount } = mountWith({
      formSpec: async (form, args) => {
        seen.push({ form, args })
        return form === 'custom-model'
          ? { title: 'custom model', fields: [{ key: 'model', label: 'Model id', kind: 'text', value: '' }] }
          : undefined
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 13, kind: 'dialog-request', payload: { kind: 'custom-model', args: { provider: 'cliproxy' } } }))
    await new Promise(resolve => setImmediate(resolve))
    assert.deepEqual(seen, [{ form: 'custom-model', args: { provider: 'cliproxy' } }])
    const spec = sentEnvelopes(state).find(envelope => envelope.kind === 'form-spec')
    assert.deepEqual([spec.payload.form, spec.payload.fields.map((f: { key: string }) => f.key)], ['custom-model', ['model']])
  })

  it('sends the provider field list down when the renderer asks for the form', async () => {
    const { state, mount } = mountWith({
      formSpec: async (form, args) => form === 'provider'
        ? { title: 'edit provider', fields: [{ key: 'id', label: 'ID', kind: 'text', value: String(args?.id ?? '') }] }
        : undefined,
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 7, kind: 'dialog-request', payload: { kind: 'provider', args: { id: 'cliproxy' } } }))
    await new Promise(resolve => setImmediate(resolve))
    const spec = sentEnvelopes(state).find(envelope => envelope.kind === 'form-spec')
    assert.ok(spec !== undefined)
    assert.deepEqual(spec.payload.form, 'provider')
    assert.equal(spec.payload.title, 'edit provider')
    assert.deepEqual(spec.payload.fields.map((field: { key: string; value: string }) => [field.key, field.value]), [['id', 'cliproxy']])
  })

  it('carries the per-model fields in the submitted model line', async () => {
    const submitted: Array<{ form: string; values: Record<string, string> }> = []
    const { state, mount } = mountWith({
      formSpec: async () => undefined,
      formSubmit: async (form, values) => { submitted.push({ form, values }) },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 14, kind: 'form-submit', payload: { form: 'provider', values: { id: 'cliproxy', models: 'mimo|MiMo|high=high;max=max|max|131072|32768 x|' } } }))
    await new Promise(resolve => setImmediate(resolve))
    // The host seam receives the line verbatim; the split into per-model fields is the
    // host's own parsing, so the IPC carries the whole field list in one line.
    assert.equal(submitted[0].values.models, 'mimo|MiMo|high=high;max=max|max|131072|32768 x|')
  })

  it('writes the completed form values through the host seam', async () => {
    const submitted: Array<{ form: string; values: Record<string, string> }> = []
    const { state, mount } = mountWith({
      formSpec: async () => undefined,
      formSubmit: async (form, values) => { submitted.push({ form, values }) },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 9, kind: 'form-submit', payload: { form: 'provider', values: { id: 'cliproxy', models: 'mimo\nx' } } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 10, kind: 'form-submit', payload: { form: '', values: {} } }))
    await new Promise(resolve => setImmediate(resolve))
    assert.deepEqual(submitted, [{ form: 'provider', values: { id: 'cliproxy', models: 'mimo\nx' } }])
  })

  it('answers the discovery probe with the merged models line', async () => {
    const probes: Array<{ form: string; fields: Record<string, string> }> = []
    const { state, mount } = mountWith({
      modelDiscover: async (form, fields) => {
        probes.push({ form, fields })
        return 'mimo|MiMo|high=high|max|131072|32768 gpt|GPT|none||128000|4096'
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 15, kind: 'model-discover', payload: { form: 'provider', fields: { id: 'cliproxy', models: 'mimo|MiMo|high=high|max|131072|32768' } } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 16, kind: 'model-discover', payload: { form: '', fields: {} } }))
    await new Promise(resolve => setImmediate(resolve))
    // The host owns the probe, so the renderer's field values arrive verbatim and the
    // merged line comes back as `model-discovery`. An empty form name is dropped.
    assert.deepEqual(probes, [{ form: 'provider', fields: { id: 'cliproxy', models: 'mimo|MiMo|high=high|max|131072|32768' } }])
    const answer = sentEnvelopes(state).find(envelope => envelope.kind === 'model-discovery')
    assert.deepEqual([answer.payload.form, answer.payload.models], ['provider', 'mimo|MiMo|high=high|max|131072|32768 gpt|GPT|none||128000|4096'])
  })

  it('sends nothing when the deployment has no discovery probe', async () => {
    const { state, mount } = mountWith({ modelDiscover: async () => undefined })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 17, kind: 'model-discover', payload: { form: 'provider', fields: { id: 'cliproxy' } } }))
    await new Promise(resolve => setImmediate(resolve))
    assert.equal(sentEnvelopes(state).filter(envelope => envelope.kind === 'model-discovery').length, 0)
  })

  it('answers the nested editor request with the parsed model list', async () => {
    const { state, mount } = mountWith({
      modelListRequest: (form, fields) => {
        if (form !== 'provider') return undefined
        const parsed = (fields.models ?? '').split(/\s+/).filter(line => line !== '')
        if (parsed.length === 0) return undefined
        return { models: parsed.map(line => {
          const bits = line.split('|')
          return { id: bits[0] ?? '', label: bits[1] ?? '' }
        }) }
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 18, kind: 'model-list-request', payload: { form: 'provider', fields: { models: 'mimo|MiMo|none||131072|32768 gpt|GPT|none||128000|4096' } } }))
    await new Promise(resolve => setImmediate(resolve))
    const list = sentEnvelopes(state).find(envelope => envelope.kind === 'model-list')
    assert.deepEqual([list.payload.form, list.payload.models], ['provider', [{ id: 'mimo', label: 'MiMo' }, { id: 'gpt', label: 'GPT' }]])
  })

  it('answers the picked model with a form spec for its fields', async () => {
    const { state, mount } = mountWith({
      modelEdit: (form, id, models) => {
        const bits = (models ?? '').split(' ').find(line => line.startsWith(`${id}|`))?.split('|')
        if (bits === undefined) return undefined
        return { title: `models · ${id}`, fields: [
          { key: 'id', label: 'ID', kind: 'text', value: bits[0] },
          { key: 'name', label: 'Name', kind: 'text', value: bits[1] ?? '' },
          { key: 'max', label: 'Max', kind: 'text', value: bits[5] ?? '' },
        ] }
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 19, kind: 'model-edit', payload: { form: 'provider', id: 'mimo', models: 'mimo|MiMo|none||131072|32768' } }))
    await new Promise(resolve => setImmediate(resolve))
    const spec = sentEnvelopes(state).find(envelope => envelope.kind === 'form-spec')
    assert.deepEqual([spec.payload.form, spec.payload.fields.map((f: { key: string; value: string }) => [f.key, f.value])],
      ['model', [['id', 'mimo'], ['name', 'MiMo'], ['max', '32768']]])
  })

  it('sends the merged line back when a model form submits', async () => {
    const { state, mount } = mountWith({
      formSubmit: async (form, values) => form === 'model' ? `${values.id}|${values.name}|none||131072|${values.max}` : undefined,
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 20, kind: 'form-submit', payload: { form: 'model', values: { id: 'mimo', name: 'MiMo Pro', max: '4096' } } }))
    await new Promise(resolve => setImmediate(resolve))
    const answer = sentEnvelopes(state).find(envelope => envelope.kind === 'model-discovery')
    assert.deepEqual([answer.payload.form, answer.payload.models], ['provider', 'mimo|MiMo Pro|none||131072|4096'])
  })

  it('falls back to the host-run dialog when the form has no field list', async () => {
    const requested: string[] = []
    const { state, mount } = mountWith({
      formSpec: async () => undefined,
      dialogRequest: (kind, _args, reply) => { requested.push(kind); reply('done') },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 11, kind: 'dialog-request', payload: { kind: 'custom-model' } }))
    await new Promise(resolve => setImmediate(resolve))
    assert.deepEqual(requested, ['custom-model'])
    const answer = sentEnvelopes(state).find(envelope => envelope.kind === 'dialog-response')
    assert.deepEqual([answer.payload.seq, answer.payload.value], [11, 'done'])
    assert.equal(sentEnvelopes(state).filter(envelope => envelope.kind === 'form-spec').length, 0)
  })
})

describe('catalog refresh seam', () => {
  it('re-sends an empty catalog when the host has nothing, instead of leaving the old one', () => {
    const { state, mount } = mountWith({
      efforts: () => ({ efforts: [], current: 'default' }),
      sessions: () => [],
      commands: () => [],
      models: () => [],
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const sent = sentEnvelopes(state)
    // An empty list is a real answer: the renderer's pickers clear instead of keeping a
    // previous session's rows.
    assert.deepEqual(sent.find(envelope => envelope.kind === 'reasoning-efforts')?.payload.efforts, [])
    assert.deepEqual(sent.find(envelope => envelope.kind === 'session-list')?.payload.sessions, [])
    assert.deepEqual(sent.find(envelope => envelope.kind === 'command-catalog')?.payload.commands, [])
    assert.deepEqual(sent.find(envelope => envelope.kind === 'model-catalog')?.payload.models, [])
  })

  it('the snapshot precedes the session-scoped catalogs it would otherwise clear', () => {
    const { state, mount } = mountWith({ efforts: () => ({ efforts: ['low'], current: 'low' }) })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const kinds = sentEnvelopes(state).map(envelope => envelope.kind)
    // The renderer drops its per-session catalogs when a snapshot names a session, so a
    // catalog sent before it would be cleared before the first frame.
    assert.ok(kinds.indexOf('session-snapshot') < kinds.indexOf('reasoning-efforts'))
})
})

describe('per-session state arrives after the snapshot that resets it', () => {
  it('the first ack sends the snapshot before every session-scoped catalog', () => {
    const { state, mount } = mountWith({
      efforts: () => ({ efforts: ['low'], current: 'low' }),
      commands: () => [{ name: 'compact', description: 'compact' }],
      models: () => [{ provider: 'p', model: 'm', label: 'M' }],
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const kinds = sentEnvelopes(state).map(envelope => envelope.kind)
    const snapshot = kinds.indexOf('session-snapshot')
    assert.ok(snapshot >= 0)
    for (const kind of ['reasoning-efforts', 'command-catalog', 'model-catalog']) {
      const at = kinds.indexOf(kind)
      if (at === -1) continue
      assert.ok(at > snapshot, `${kind} must follow session-snapshot`)
    }
  })
})

describe('terminal outcomes', () => {
  it('restores the terminal and reports once when the renderer crashes', () => {
    const writes: string[] = []
    const notices: Array<{ text: string; level: string }> = []
    let exits = 0
    const { state, mount } = mountWith({
      onRendererExit: () => { exits += 1 },
      notice: (text, level) => notices.push({ text, level }),
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    // A crash is one terminal outcome: the restore sequence, one error notice, and one
    // renderer-exit notification, even if a late `exit` follows.
    emit(state, 'exit', 1, null)
    assert.equal(exits, 1)
    assert.ok(notices.some(entry => entry.level === 'error' && entry.text.includes('abnormally')))
    emit(state, 'exit', 1, null)
    assert.equal(exits, 1)
  })

  it('a host stop is not reported as a crash', () => {
    const notices: Array<{ text: string; level: string }> = []
    const { state, mount } = mountWith({ notice: (text, level) => notices.push({ text, level }) })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    mount.stop()
    emit(state, 'exit', null, 'SIGTERM')
    assert.equal(notices.some(entry => entry.text.includes('abnormally')), false)
  })
})

describe('idempotent teardown', () => {
  it('stop twice unsubscribes and restores once', () => {
    const unsubscribes: number[] = []
    let exits = 0
    const { state, mount } = mountWith({
      subscribe: () => () => { unsubscribes.push(1) },
      onRendererExit: () => { exits += 1 },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    mount.stop()
    mount.stop()
    assert.equal(unsubscribes.length, 1)
    assert.equal(exits, 1)
  })

  it('a renderer bye ends the session once and settles pending questions', async () => {
    let byes = 0
    const { state, mount } = mountWith({ onBye: () => { byes += 1 } })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    const pending = mount.askQuestion({ request: 'q1', sessionId: 'ses_1', state: 'open', questions: [{ id: 'a', question: 'pick' }] })
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 7, kind: 'bye', payload: { reason: 'renderer exit' } }))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 8, kind: 'bye', payload: { reason: 'again' } }))
    assert.equal(byes, 1)
    assert.equal(await pending, undefined)
  })
})

describe('host startup failures', () => {
  it('reports a rejected handshake and never takes the terminal', () => {
    const notices: Array<{ text: string; level: string }> = []
    const { state, mount } = mountWith({ notice: (text, level) => notices.push({ text, level }) })
    assert.ok(mount !== undefined)
    const hello = helloEnvelope()
    emit(state, 'message', JSON.stringify({ ...hello, payload: { ...hello.payload as object, protocolVersion: 1 } }))
    // A protocol mismatch is terminal: the host says why and sends no state to a renderer
    // that will exit on its own.
    assert.ok(notices.some(entry => entry.level === 'error' && entry.text.includes('renderer refused')))
    assert.equal(sentEnvelopes(state).some(envelope => envelope.kind === 'session-snapshot'), false)
  })

  it('a missing renderer binary reports instead of spawning nothing', () => {
    const notices: Array<{ text: string; level: string }> = []
    const writes: string[] = []
    const mount = mountWith({ rendererPath: undefined, notice: (text, level) => notices.push({ text, level }) })
    assert.equal(mount.mount, undefined)
    assert.ok(writes.length >= 0)
    assert.deepEqual(notices, [{ text: 'no renderer artifact found', level: 'error' }])
  })
})

describe('settings write round trip', () => {
  it('answers the request id after the write resolves', async () => {
    const writes: Array<{ patch: Record<string, unknown>; ns: string }> = []
    const { state, mount } = mountWith({
      settingsSection: () => ({ ns: 'dpsk-tui', schemaVersion: 2, values: { themeName: 'opencode' } }),
      updateSettings: async (patch, ns) => { writes.push({ patch, ns }) },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 20, kind: 'update-settings', payload: { requestId: 'r1', patch: { themeName: 'carbonfox' } } }))
    await new Promise(resolve => setImmediate(resolve))
    assert.deepEqual(writes, [{ patch: { themeName: 'carbonfox' }, ns: 'tui' }])
    const answer = sentEnvelopes(state).find(envelope => envelope.kind === 'settings' && envelope.payload.requestId === 'r1')
    assert.ok(answer !== undefined)
    assert.equal(answer.payload.error, undefined)
    assert.equal((answer.payload.values as Record<string, unknown>).themeName, 'opencode')
  })

  it('answers a failed write with the real error', async () => {
    const { state, mount } = mountWith({
      settingsSection: () => ({ ns: 'dpsk-tui', schemaVersion: 2, values: {} }),
      updateSettings: async () => { throw new Error('settings document is read-only') },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 21, kind: 'update-settings', payload: { requestId: 'r2', patch: { newDesigns: true } } }))
    await new Promise(resolve => setImmediate(resolve))
    const answer = sentEnvelopes(state).find(envelope => envelope.kind === 'settings' && envelope.payload.requestId === 'r2')
    assert.equal(answer?.payload.error, 'settings document is read-only')
  })
})

describe('terminal restore uses the real TTY', () => {
  it('writes the crash restore to the TTY handle, not the routed log', () => {
    const tty: string[] = []
    const logged: string[] = []
    const { state, mount } = mountWith({
      write: (text: string) => { tty.push(text) },
      streams: {
        stdout: { write: (chunk: unknown) => { logged.push(String(chunk)); return true } },
        stderr: { write: (chunk: unknown) => { logged.push(String(chunk)); return true } },
      },
    })
    assert.ok(mount !== undefined)
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'exit', 1, null)
    // The restore sequence can only work on the terminal; the routed stream would swallow it.
    assert.ok(tty.some(text => text.includes('\x1b[?1049l')))
    assert.ok(logged.every(text => !text.includes('\x1b[?1049l')))
  })
})
