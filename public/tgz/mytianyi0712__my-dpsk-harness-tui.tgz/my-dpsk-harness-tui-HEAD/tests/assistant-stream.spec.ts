import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { appendAssistantTextDelta } from '../src/host/assistant-stream.ts'

describe('assistant stream rows', () => {
  it('stamps bodyAt when a reasoning row starts emitting text', () => {
    const reasoning = {
      id: 's1',
      text: '',
      reasoning: 'why',
      createdAt: 1_000,
    }
    const body = appendAssistantTextDelta(reasoning, 's1', 'answer', 5_000)
    assert.equal(body.bodyAt, 5_000)
    assert.equal(body.text, 'answer')
    assert.equal(body.reasoningDone, true)
  })

  it('keeps the first body timestamp across later deltas', () => {
    const first = appendAssistantTextDelta(
      { id: 's1', text: '', reasoning: 'why', createdAt: 1_000 },
      's1',
      'a',
      5_000,
    )
    const second = appendAssistantTextDelta(first, 's1', 'b', 7_000)
    assert.equal(second.bodyAt, 5_000)
    assert.equal(second.text, 'ab')
  })

  it('stamps bodyAt on a fresh text-only row too', () => {
    const row = appendAssistantTextDelta(undefined, 's2', 'hello', 3_000)
    assert.equal(row.bodyAt, 3_000)
    assert.equal(row.reasoning, '')
  })
})
