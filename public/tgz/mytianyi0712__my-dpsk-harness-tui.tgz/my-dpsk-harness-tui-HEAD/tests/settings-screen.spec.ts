import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { visibleWidth, type SelectItem } from '@earendil-works/pi-tui'
import { SettingsScreen, cycleValue, type SettingsTab } from '../src/components/settings-screen.ts'
import { createTranslator } from '../src/i18n.ts'
import { createPalette } from '../src/theme.ts'

const palette = createPalette(false, 'dark', true)
const t = createTranslator('en')

const TEST_TABS: SettingsTab[] = [
  {
    id: 'appearance',
    label: 'Appearance',
    items: [
      { value: 'theme', label: 'Theme', currentValue: 'catppuccin' },
      { value: 'cursor', label: 'Cursor', currentValue: 'visible' },
    ],
  },
  {
    id: 'model',
    label: 'Model',
    items: [
      { value: 'title-model', label: 'Title model', currentValue: 'deepseek/chat' },
    ],
  },
]

describe('SettingsScreen', () => {
  it('renders an OMP-style full-screen frame at the requested size', () => {
    const screen = new SettingsScreen([], 'Settings', palette, t, 10, 14)
    screen.setTabs(TEST_TABS, 'Settings')

    const rows = screen.render(80)

    assert.equal(rows.length, 14)
    assert.ok(rows[0]!.startsWith('╭─ Settings '))
    assert.ok(rows.some(row => row.includes('Appearance') && row.includes('Model')))
    assert.ok(rows.some(row => row.includes('Theme') && row.includes('catppuccin')))
    assert.ok(rows.some(row => row.includes('switch tabs')))
    assert.ok(rows.every(row => visibleWidth(row) === 80))
  })

  it('switches tabs and preserves each tab cursor', () => {
    const screen = new SettingsScreen([], 'Settings', palette, t)
    screen.setTabs(TEST_TABS, 'Settings')
    let selected: { item: SelectItem; tabId: string | undefined } | undefined
    screen.onSelect = (item, tabId) => {
      selected = { item, tabId }
    }

    screen.handleInput('\x1b[B')
    screen.handleInput('\x1b[C')
    screen.handleInput('\x1b[D')
    screen.handleInput('\r')

    assert.equal(selected?.tabId, 'appearance')
    assert.equal(selected?.item.value, 'cursor')

    screen.handleInput('\x1b[C')
    screen.handleInput('\r')
    assert.equal(selected?.tabId, 'model')
    assert.equal(selected?.item.value, 'title-model')
  })

  it('preselects submenu values and sends Escape back instead of closing', () => {
    const screen = new SettingsScreen([], 'Settings', palette, t)
    const items: SelectItem[] = [
      { value: 'a', label: 'A' },
      { value: 'b', label: 'B' },
    ]
    let selected: string | undefined
    let backCount = 0
    let closeCount = 0
    screen.onSelect = item => {
      selected = item.value
    }
    screen.onBack = () => {
      backCount++
    }
    screen.onClose = () => {
      closeCount++
    }

    screen.setItems(items, 'Choose', 'b')
    screen.handleInput('\x1b[C')
    screen.handleInput('\r')
    screen.handleInput('\x1b')

    assert.equal(selected, 'b')
    assert.equal(backCount, 1)
    assert.equal(closeCount, 0)

    screen.setTabs(TEST_TABS, 'Settings')
    screen.handleInput('\x1b')
    assert.equal(closeCount, 1)
  })

  it('wraps row navigation like the OMP selectors', () => {
    const screen = new SettingsScreen([], 'Settings', palette, t)
    screen.setItems([
      { value: 'first', label: 'First' },
      { value: 'last', label: 'Last' },
    ], 'Choose')
    let selected: string | undefined
    screen.onSelect = item => {
      selected = item.value
    }

    screen.handleInput('\x1b[A')
    screen.handleInput('\r')

    assert.equal(selected, 'last')
  })
  it('wraps the complete selected option value instead of hiding its tail', () => {
    const screen = new SettingsScreen([], 'Settings', palette, t, 10)
    screen.setItems([
      {
        value: 'url',
        label: 'Base URL',
        currentValue: 'https://gateway.example/company/region/v1/chat/completions',
      },
    ], 'Provider')
    const rendered = screen.render(40).join('\n')
    assert.ok(rendered.includes('https://gateway.example'))
    assert.ok(rendered.includes('chat/completions'))
  })

  it('skips section headers when moving and confirming', () => {
    const screen = new SettingsScreen([], 'Settings', palette, t)
    screen.setTabs([{
      id: 'models',
      label: 'Models',
      items: [
        { value: '__header', label: 'Providers', currentValue: '', kind: 'header' },
        { value: 'add', label: 'Add provider', currentValue: '', kind: 'action' },
        { value: 'model', label: 'Default model', currentValue: 'deepseek/chat' },
      ],
    }], 'Settings')
    let selected: string | undefined
    screen.onSelect = item => {
      selected = item.value
    }

    const rendered = screen.render(80).join('\n')
    assert.ok(rendered.includes('Providers'))
    assert.ok(!rendered.includes('→ Providers'))

    screen.handleInput('\r')
    assert.equal(selected, 'add')

    screen.handleInput('\x1b[A')
    screen.handleInput('\r')
    assert.equal(selected, 'model')
  })
})

describe('cycleValue', () => {
  it('advances and wraps through the provided values', () => {
    assert.equal(cycleValue(['off', 'low', 'max'], 'off'), 'low')
    assert.equal(cycleValue(['off', 'low', 'max'], 'max'), 'off')
    assert.equal(cycleValue(['off', 'low', 'max'], undefined), 'off')
    assert.equal(cycleValue([3, 6, 10], 7), 3)
  })
})
