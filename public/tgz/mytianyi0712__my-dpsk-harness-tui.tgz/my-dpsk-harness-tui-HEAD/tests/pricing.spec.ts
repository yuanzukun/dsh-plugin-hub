import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import {
  DEFAULT_PRICING_TABLE,
  EMPTY_USAGE_COST_FOLD,
  estimateUsageCost,
  findPricingModel,
  foldUsageCost,
  parsePricingTable,
  scheduleActive,
  type PricingTable,
} from '../src/host/pricing.ts'

const SHANGHAI_PEAK = Date.parse('2026-10-23T10:00:00+08:00')
const SHANGHAI_OFFPEAK = Date.parse('2026-10-23T02:00:00+08:00')

function sample(time: number) {
  return {
    time,
    provider: 'cliproxy',
    model: 'deepseek-v4.1-flash',
    inputTokens: 1_000_000,
    outputTokens: 0,
  }
}

describe('pricing table', () => {
  it('parses the bundled table and matches an exact provider/model', () => {
    const parsed = parsePricingTable(DEFAULT_PRICING_TABLE)
    assert.deepEqual(parsed.errors, [])
    assert.equal(estimateUsageCost(sample(SHANGHAI_PEAK), parsed.table)?.costUsd, 0.3)
  })

  it('applies DeepSeek off-peak multipliers in the configured timezone', () => {
    const peak = estimateUsageCost(sample(SHANGHAI_PEAK))
    const offpeak = estimateUsageCost(sample(SHANGHAI_OFFPEAK))
    assert.equal(peak?.costUsd, 0.3)
    assert.equal(offpeak?.costUsd, 0.15)
    assert.equal(offpeak?.schedule, 'deepseek-off-peak')
  })

  it('treats the off-peak end as exclusive', () => {
    const atEnd = Date.parse('2026-10-23T08:30:00+08:00')
    assert.equal(estimateUsageCost(sample(atEnd))?.schedule, undefined)
  })

  it('charges input, output, and cache read independently', () => {
    const estimate = estimateUsageCost({
      time: SHANGHAI_PEAK,
      provider: 'cliproxy',
      model: 'deepseek-v4.1-flash',
      inputTokens: 1_000_000,
      outputTokens: 1_000_000,
      cacheReadTokens: 1_000_000,
    })
    assert.ok(Math.abs((estimate?.costUsd ?? 0) - 1.506) < 1e-12)
  })

  it('supports schedules that cross midnight', () => {
    const table: PricingTable = {
      version: 1,
      currency: 'USD',
      models: {
        'p/m': {
          provider: 'p',
          model: 'm',
          ratesPerMillion: { input: 1, output: 1 },
          schedules: [{ timezone: 'UTC', start: '22:00', end: '02:00', multiplier: 0.5 }],
        },
      },
    }
    assert.equal(scheduleActive(table.models['p/m']!.schedules![0]!, Date.parse('2026-10-23T23:00:00Z')), true)
    assert.equal(scheduleActive(table.models['p/m']!.schedules![0]!, Date.parse('2026-10-24T01:00:00Z')), true)
    assert.equal(scheduleActive(table.models['p/m']!.schedules![0]!, Date.parse('2026-10-24T12:00:00Z')), false)
  })

  it('leaves an unknown model unpriced', () => {
    assert.equal(estimateUsageCost({ ...sample(SHANGHAI_PEAK), model: 'not-a-priced-model', provider: 'cliproxy' }), undefined)
    const fold = foldUsageCost(EMPTY_USAGE_COST_FOLD, {
      ...sample(SHANGHAI_PEAK),
      model: 'unknown-model',
    })
    assert.deepEqual(fold, { costUsd: 0, pricedSamples: 0, unpricedSamples: 1 })
  })

  it('matches provider aliases and source model ids without exact table keys', () => {
    assert.equal(findPricingModel(DEFAULT_PRICING_TABLE, 'cliproxy', 'deepseek/deepseek-v4.1-flash')?.key, 'deepseek-v4.1-flash')
    assert.equal(findPricingModel(DEFAULT_PRICING_TABLE, 'cliproxy', 'deepseek-v4.1-flash')?.basis, 'basename')
    assert.equal(findPricingModel(DEFAULT_PRICING_TABLE, 'xiaomi_mimo', 'xiaomi_mimo/mimo-v2.6-pro')?.key, 'mimo-v2.6-pro')
    assert.equal(findPricingModel(DEFAULT_PRICING_TABLE, 'other', 'mimo-v2.6-pro')?.entry.ratesPerMillion.input, 0.435)
  })

  it('falls back to a unique versionless family only when it is unambiguous', () => {
    const table: PricingTable = {
      version: 1,
      currency: 'USD',
      models: {
        'vendor/deepseek-v4.2-flash': {
          model: 'deepseek-v4.2-flash',
          ratesPerMillion: { input: 1, output: 2 },
        },
      },
    }
    assert.equal(findPricingModel(table, 'vendor', 'deepseek-flash')?.basis, 'versionless')
    const ambiguous: PricingTable = {
      version: 1,
      currency: 'USD',
      models: {
        a: { model: 'deepseek-v4-flash', ratesPerMillion: { input: 1, output: 2 } },
        b: { model: 'deepseek-v4.1-flash', ratesPerMillion: { input: 3, output: 4 } },
      },
    }
    assert.equal(findPricingModel(ambiguous, 'vendor', 'deepseek-flash'), undefined)
  })

  it('rejects malformed external pricing', () => {
    const bad = parsePricingTable({
      version: 1,
      currency: 'CNY',
      models: { x: { ratesPerMillion: { input: -1, output: 1 }, schedules: [{ timezone: 'Not/AZone', start: '25:00', end: '02:00' }] } },
    })
    assert.ok(bad.errors.length >= 2)
    assert.equal(bad.table, undefined)
  })
})
