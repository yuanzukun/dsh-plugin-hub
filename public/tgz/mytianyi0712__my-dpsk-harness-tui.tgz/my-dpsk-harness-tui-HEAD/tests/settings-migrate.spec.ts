import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, readdir, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import type { Context } from '../src/dsh-host/index.ts'
import {
  formatMigrationReport,
  migrateLegacyTheme,
  persistLegacySettings,
  readLegacySettings,
  type LegacySettings,
} from '../src/settings-migrate.ts'
import { FALLBACK_THEME_ID, SHIPPED_THEME_IDS, isSelectableTheme } from '../src/theme-catalog.ts'

/**
 * A context whose settings layer exposes one patch file and one live section
 * per namespace, so migration reads and writes go through the same seams the
 * TUI uses.
 */
function contextWithSettings(
  documentPath: string,
  sections: Record<string, Record<string, unknown>>,
  writes: Array<{ ns: string; patch: Record<string, unknown> }>,
): Context {
  const settings = {
    documentPath,
    describe: () => Object.entries(sections).map(([ns, value]) => ({ ns, value })),
    update: async (ns: string, patch: Record<string, unknown>) => {
      writes.push({ ns, patch })
      sections[ns] = { ...sections[ns], ...patch }
    },
  }
  return { settings } as unknown as Context
}

async function patchFile(content: string): Promise<string> {
  const dir = await mkdtemp(join(tmpdir(), 'dpsk-migrate-'))
  const path = join(dir, 'cordis.patch.yml')
  await writeFile(path, content, 'utf8')
  return path
}

describe('readLegacySettings', () => {
  it('reads the pre-0.5.0 tui row config from the patch layer', async () => {
    const path = await patchFile([
      '- id: tui',
      '  config:',
      '    showReasoning: false',
      '    maxToolOutputLines: 3',
      '    themeMode: selected',
      '    themeSelected: dark-catppuccin',
    ].join('\n'))
    const legacy = readLegacySettings(contextWithSettings(path, {}, []))
    assert.deepEqual(legacy.tui, {
      showReasoning: false,
      maxToolOutputLines: 3,
      themeMode: 'selected',
      themeSelected: 'dark-catppuccin',
    })
    assert.equal(legacy.sessionTitle, undefined)
    assert.equal(legacy.source, path)
    await rm(join(path, '..'), { recursive: true, force: true })
  })

  it('reads legacy config nested in an insert list', async () => {
    const path = await patchFile([
      '- insert:',
      '    - id: session-title-llm-tui',
      '      config:',
      '        provider: deepseek',
      '        model: deepseek-v4.1-flash',
    ].join('\n'))
    const legacy = readLegacySettings(contextWithSettings(path, {}, []))
    assert.deepEqual(legacy.sessionTitle, { provider: 'deepseek', model: 'deepseek-v4.1-flash' })
    assert.equal(legacy.tui, undefined)
    await rm(join(path, '..'), { recursive: true, force: true })
  })

  it('reads legacy config from a patch layer that uses cordis !!js tags', async () => {
    const path = await patchFile([
      '- id: agent-loop',
      '  config:',
      '    agents:',
      '      - id: main',
      '        sessionId: !!js ctx.tuiStartup.sessionId',
      '        cwd: !!js process.cwd()',
      '- id: tui',
      '  config:',
      '    themeMode: selected',
      '    themeSelected: dark-gruvbox',
    ].join('\n'))
    const legacy = readLegacySettings(contextWithSettings(path, {}, []))
    assert.deepEqual(legacy.tui, { themeMode: 'selected', themeSelected: 'dark-gruvbox' })
    assert.equal(legacy.source, path)
    await rm(join(path, '..'), { recursive: true, force: true })
  })

  it('returns an empty result when the patch layer is unreadable', () => {
    const legacy = readLegacySettings(contextWithSettings('/nonexistent/patch.yml', {}, []))
    assert.deepEqual(legacy, { tui: undefined, sessionTitle: undefined, source: undefined })
  })

  it('returns an empty result when settings are unavailable', () => {
    const legacy = readLegacySettings({} as Context)
    assert.deepEqual(legacy, { tui: undefined, sessionTitle: undefined, source: undefined })
  })
})

describe('persistLegacySettings', () => {
  const legacy: LegacySettings = {
    tui: { showReasoning: false, maxToolOutputLines: 3, keyTools: 'ctrl+o' },
    sessionTitle: { provider: 'deepseek', model: 'deepseek-v4.1-flash' },
    source: 'patch.yml',
  }

  it('writes every legacy field into the renamed namespaces', async () => {
    const writes: Array<{ ns: string; patch: Record<string, unknown> }> = []
    const ctx = contextWithSettings('patch.yml', { 'dpsk-tui': {}, 'dpsk-session-title': {} }, writes)
    const report = await persistLegacySettings(ctx, legacy)
    assert.deepEqual(writes[0], {
      ns: 'dpsk-tui',
      patch: { showReasoning: false, maxToolOutputLines: 3, keyTools: 'ctrl+o' },
    })
    assert.deepEqual(writes[1], {
      ns: 'dpsk-session-title',
      patch: { provider: 'deepseek', model: 'deepseek-v4.1-flash' },
    })
    assert.deepEqual(report.migrated, [
      'dpsk-tui.showReasoning',
      'dpsk-tui.maxToolOutputLines',
      'dpsk-tui.keyTools',
      'dpsk-session-title.provider',
      'dpsk-session-title.model',
    ])
    assert.deepEqual(report.skipped, [])
  })

  it('skips fields the new namespace already carries', async () => {
    const writes: Array<{ ns: string; patch: Record<string, unknown> }> = []
    const ctx = contextWithSettings(
      'patch.yml',
      { 'dpsk-tui': { showReasoning: true }, 'dpsk-session-title': {} },
      writes,
    )
    const report = await persistLegacySettings(ctx, legacy)
    assert.deepEqual(writes[0].patch, { maxToolOutputLines: 3, keyTools: 'ctrl+o' })
    assert.deepEqual(report.skipped, ['dpsk-tui.showReasoning'])
    assert.ok(!report.migrated.includes('dpsk-tui.showReasoning'))
  })

  it('is idempotent: a restart after migration writes nothing', async () => {
    const writes: Array<{ ns: string; patch: Record<string, unknown> }> = []
    const ctx = contextWithSettings('patch.yml', { 'dpsk-tui': {}, 'dpsk-session-title': {} }, writes)
    await persistLegacySettings(ctx, legacy)
    const second = await persistLegacySettings(ctx, legacy)
    assert.equal(writes.length, 2)
    assert.deepEqual(second.migrated, [])
    assert.equal(second.skipped.length, 5)
  })

  it('reports the migrated keys and the patch source', () => {
    const lines = formatMigrationReport(
      { migrated: ['dpsk-tui.showReasoning'], skipped: ['dpsk-tui.keyTools'], unavailableThemes: [] },
      'patch.yml',
    )
    assert.ok(lines[0].includes('tui → dpsk-tui'))
    assert.ok(lines.some(line => line.includes('迁移: dpsk-tui.showReasoning')))
    assert.ok(lines.some(line => line.includes('保留新值: dpsk-tui.keyTools')))
    assert.ok(lines.some(line => line.includes('来源: patch.yml')))
  })

  it('reports nothing when there is nothing to migrate', () => {
    assert.deepEqual(
      formatMigrationReport({ migrated: [], skipped: [], unavailableThemes: [] }, undefined),
      [],
    )
  })

  it('does not copy the retired 0.4.0 theme palette into the new section', async () => {
    const writes: Array<{ ns: string; patch: Record<string, unknown> }> = []
    const ctx = contextWithSettings('cordis.patch.yml', { 'dpsk-tui': {} }, writes)
    const legacy: LegacySettings = {
      tui: { themeCustom: { accent: [250, 179, 135] }, themeSelected: 'dark-catppuccin', themeMode: 'selected', newDesigns: true },
      sessionTitle: undefined,
      source: 'patch.yml',
    }
    const report = await persistLegacySettings(ctx, legacy)
    const write = writes.find(entry => entry.ns === 'dpsk-tui')
    assert.ok(write !== undefined)
    // The native renderer catalog replaces the synthesized palette: the role overlay and
    // the old fixed-theme ids are inputs only, while the new fields move as they are.
    assert.equal('themeCustom' in write.patch, false)
    assert.equal('themeSelected' in write.patch, false)
    assert.equal(write.patch.newDesigns, true)
    assert.ok(report.skipped.includes('dpsk-tui.themeCustom'))
    assert.ok(report.skipped.includes('dpsk-tui.themeSelected'))
  })
})

describe('migrateLegacyTheme', () => {
  it('keeps a legacy selected id the native catalog ships and normalizes the mode', async () => {
    const writes: Array<{ ns: string; patch: Record<string, unknown> }> = []
    const ctx = contextWithSettings('patch.yml', { 'dpsk-tui': {} }, writes)
    const report = { migrated: [] as string[], skipped: [] as string[], unavailableThemes: [] as string[] }
    await migrateLegacyTheme(ctx, { themeSelected: 'gruvbox', themeMode: 'selected' }, report)
    assert.deepEqual(writes, [{ ns: 'dpsk-tui', patch: { themeName: 'gruvbox', themeMode: 'system' } }])
    assert.deepEqual(report.migrated, ['dpsk-tui.themeName', 'dpsk-tui.themeMode'])
    assert.deepEqual(report.unavailableThemes, [])
  })

  it('falls back to opencode and reports an id the catalog does not ship', async () => {
    const writes: Array<{ ns: string; patch: Record<string, unknown> }> = []
    const ctx = contextWithSettings('patch.yml', { 'dpsk-tui': {} }, writes)
    const report = { migrated: [] as string[], skipped: [] as string[], unavailableThemes: [] as string[] }
    await migrateLegacyTheme(ctx, { themeSelected: 'dark-catppuccin', themeMode: 'dynamic' }, report)
    assert.deepEqual(writes[0]?.patch, { themeName: 'opencode', themeMode: 'system' })
    assert.deepEqual(report.unavailableThemes, ['dark-catppuccin'])
  })

  it('never overwrites a selection the new namespace already carries', async () => {
    const writes: Array<{ ns: string; patch: Record<string, unknown> }> = []
    const ctx = contextWithSettings('patch.yml', { 'dpsk-tui': { themeName: 'nord', themeMode: 'dark' } }, writes)
    const report = { migrated: [] as string[], skipped: [] as string[], unavailableThemes: [] as string[] }
    await migrateLegacyTheme(ctx, { themeSelected: 'dark-gruvbox', themeMode: 'selected' }, report)
    assert.deepEqual(writes, [])
    assert.deepEqual(report.migrated, [])
  })

  it('maps every shipped document id and refuses an unknown one', () => {
    for (const id of SHIPPED_THEME_IDS) assert.equal(isSelectableTheme(id), true, id)
    assert.equal(isSelectableTheme('system'), true)
    assert.equal(isSelectableTheme('alabaster'), false)
    assert.equal(FALLBACK_THEME_ID, 'opencode')
  })

  it('mirrors the renderer asset directory exactly', async () => {
    const dir = join(import.meta.dirname, '..', 'renderer', 'src', 'theme', 'native', 'assets')
    const names = (await readdir(dir)).filter(name => name.endsWith('.json')).map(name => name.slice(0, -'.json'.length))
    assert.deepEqual([...SHIPPED_THEME_IDS].sort(), names.sort())
  })
})
