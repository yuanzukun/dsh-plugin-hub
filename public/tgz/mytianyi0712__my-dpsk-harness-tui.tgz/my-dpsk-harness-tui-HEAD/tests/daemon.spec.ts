import assert from 'node:assert/strict'
import { once } from 'node:events'
import { mkdtempSync, rmSync } from 'node:fs'
import net from 'node:net'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'
import { createDaemonBridge, daemonPaths, startDaemonServer } from '../src/host/daemon.ts'

function sendLine(socket: net.Socket, value: unknown): void {
  socket.write(JSON.stringify(value) + '\n')
}

function nextJson(socket: net.Socket): Promise<Record<string, unknown>> {
  return new Promise((resolve, reject) => {
    let buffer = ''
    const onData = (chunk: Buffer | string): void => {
      buffer += String(chunk)
      const newline = buffer.indexOf('\n')
      if (newline === -1) return
      socket.removeListener('data', onData)
      resolve(JSON.parse(buffer.slice(0, newline)) as Record<string, unknown>)
    }
    socket.on('data', onData)
    socket.once('error', reject)
  })
}

test('the daemon socket authenticates, bridges renderer frames, and reports detach', async () => {
  const root = mkdtempSync(join(tmpdir(), 'dpsk-daemon-'))
  const previous = process.env.MYDPSK_CONFIG_HOME
  process.env.MYDPSK_CONFIG_HOME = root
  let gone = 0
  let shutdown = 0
  const bridge = createDaemonBridge(() => { gone += 1 })
  const paths = daemonPaths()
  const server = await startDaemonServer({ bridge, paths, onShutdown: () => { shutdown += 1 } })
  try {
    const ping = net.connect(paths.socket)
    await once(ping, 'connect')
    const pong = nextJson(ping)
    sendLine(ping, { type: 'ping', token: server.token })
    assert.deepEqual(await pong, { type: 'ok' })
    ping.destroy()

    const socket = net.connect(paths.socket)
    await once(socket, 'connect')
    const ready = nextJson(socket)
    sendLine(socket, { type: 'attach', token: server.token })
    assert.deepEqual(await ready, { type: 'ready' })

    const outbound = nextJson(socket)
    bridge.child.send('hello-from-core')
    assert.deepEqual(await outbound, { type: 'message', data: 'hello-from-core' })

    const inbound = once(bridge.child, 'message')
    sendLine(socket, { type: 'message', data: 'hello-from-renderer' })
    assert.deepEqual(await inbound, ['hello-from-renderer'])

    socket.destroy()
    await new Promise(resolve => setTimeout(resolve, 50))
    assert.ok(gone >= 1)

    const stop = net.connect(paths.socket)
    await once(stop, 'connect')
    const ack = nextJson(stop)
    sendLine(stop, { type: 'shutdown', token: server.token })
    assert.deepEqual(await ack, { type: 'ok' })
    await new Promise(resolve => setTimeout(resolve, 60))
    assert.equal(shutdown, 1)
  } finally {
    server.close()
    if (previous === undefined) delete process.env.MYDPSK_CONFIG_HOME
    else process.env.MYDPSK_CONFIG_HOME = previous
    rmSync(root, { recursive: true, force: true })
  }
})


