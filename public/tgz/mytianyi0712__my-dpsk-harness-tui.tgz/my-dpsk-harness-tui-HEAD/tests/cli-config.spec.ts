import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  cliConfigPath,
  cliImportPlan,
  filterCliImportPatch,
  formatCliImportReport,
  readCliConfig,
} from '../src/cli-config.ts'

async function cliFile(content: string): Promise<string> {
  const dir = await mkdtemp(join(tmpdir(), 'dpsk-cli-'))
  const path = join(dir, 'cli.json')
  await writeFile(path, content, 'utf8')
  return path
}

describe('cli.json import', () => {
  it('prefers OPENCODE_TUI_CONFIG and falls back to the user config dir', async () => {
    const path = await cliFile('{}')
    assert.equal(cliConfigPath({ OPENCODE_TUI_CONFIG: path }), path)
    assert.equal(cliConfigPath({ OPENCODE_TUI_CONFIG: join(tmpdir(), 'no-such-cli.json') }), undefined)
    const home = cliConfigPath({})
    assert.ok(home === undefined || home.endsWith(join('.config', 'opencode', 'cli.json')))
    await rm(join(path, '..'), { recursive: true, force: true })
  })

  it('reads a JSON object and refuses anything else', async () => {
    const object = await cliFile('{"theme":"catppuccin","mouse":true}')
    assert.deepEqual(readCliConfig(object), { theme: 'catppuccin', mouse: true })
    const array = await cliFile('[1,2,3]')
    assert.equal(readCliConfig(array), undefined)
    const broken = await cliFile('{')
    assert.equal(readCliConfig(broken), undefined)
    assert.equal(readCliConfig(join(tmpdir(), 'no-such-file.json')), undefined)
    await Promise.all([rm(join(object, '..'), { recursive: true, force: true }), rm(join(array, '..'), { recursive: true, force: true }), rm(join(broken, '..'), { recursive: true, force: true })])
  })

  it('maps the supported keys onto the settings section', () => {
    const plan = cliImportPlan({
      theme: 'catppuccin',
      keybinds: { leader: 'ctrl+x', app: 'ctrl+p' },
      leader_timeout: 2500,
      scroll_speed: 3,
      scroll_acceleration: true,
      diff_style: 'stacked',
      cursor: 'block',
      mouse: false,
    })
    // `theme` has no slot: the renderer owns its own theme catalog.
    assert.deepEqual(plan.patch, {
      keybinds: { leader: 'ctrl+x', app: 'ctrl+p' },
      leaderTimeout: 2500,
      scrollSpeed: 3,
      scrollAcceleration: true,
      diffStyle: 'stacked',
      cursor: 'block',
      mouse: false,
    })
    assert.deepEqual(plan.ignored, ['theme'])
    assert.equal(plan.imported.some(entry => entry.key === 'theme'), false)
  })

  it('reports a key with no slot and refuses a value of the wrong type', () => {
    const plan = cliImportPlan({ theme: 12, mouse: 'yes', plugin: 'x' })
    assert.deepEqual(plan.patch, {})
    assert.deepEqual(plan.ignored.sort(), ['mouse', 'plugin', 'theme'])
    assert.deepEqual(plan.imported, [])
  })

  it('never overwrites a field the settings section already carries', () => {
    const patch = { themeSelected: 'catppuccin', mouse: false, leaderTimeout: 2500 }
    const current = { themeSelected: 'alabaster' }
    const { writable, skipped } = filterCliImportPatch(patch, current)
    assert.deepEqual(writable, { mouse: false, leaderTimeout: 2500 })
    assert.deepEqual(skipped, ['themeSelected'])
    // A section with nothing written yet takes everything.
    assert.deepEqual(filterCliImportPatch(patch, undefined).writable, patch)
  })

  it('prints the import, the kept fields, and the ignored keys', () => {
    const plan = cliImportPlan({ theme: 'catppuccin', mouse: true, theme_mode: 'dynamic' })
    const lines = formatCliImportReport(plan, [], '/home/u/.config/opencode/cli.json')
    assert.ok(lines[0].includes('cli.json 一次性导入'))
    assert.ok(lines.some(line => line.includes('导入: mouse → mouse')))
    // Both theme keys stay in the user's file and are named in the report.
    assert.ok(lines.some(line => line.includes('忽略: theme')))
    assert.ok(lines.some(line => line.includes('忽略: theme_mode')))
    assert.deepEqual(formatCliImportReport({ patch: {}, imported: [], ignored: [] }, [], 'x'), [])
  })

  it('leaves no report when there is nothing to say', () => {
    const path = join(tmpdir(), 'absent-cli.json')
    assert.ok(!existsSync(path))
  })
})
