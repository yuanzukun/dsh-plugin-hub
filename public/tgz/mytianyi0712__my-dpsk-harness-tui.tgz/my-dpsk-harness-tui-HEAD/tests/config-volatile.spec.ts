import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { z } from '../src/dsh-host/index.ts'
import { TuiConfigSchema, resolveTuiConfig } from '../src/config.ts'
import { CLI_IMPORT_FIELDS } from '../src/cli-config.ts'

/**
 * dsh's settings service only projects **volatile** Config fields, and rejects every write
 * to a row that declares none. A schema without `volatile()` therefore breaks persistence
 * silently from the renderer's point of view: the picker paints, the write is refused.
 */
describe('TUI config schema', () => {
  it('declares every editable presentation field volatile', () => {
    // `toJSON` stores child schemas by reference id; rebuilding the schema resolves them,
    // which is exactly what the settings service does before it projects a form.
    const rebuilt = new z(TuiConfigSchema.toJSON()) as unknown as { dict?: Record<string, { meta?: { volatile?: boolean } }> }
    const fields = rebuilt.dict ?? {}
    for (const key of ['themeName', 'themeMode', 'newDesigns', 'pathDisplay', 'showReasoning', 'maxToolOutputLines', 'leftPrompt', 'rightPrompt', 'animations']) {
      assert.equal(fields[key]?.meta?.volatile, true, `${key} must be volatile`)
    }
  })

  it('declares every field the one-time cli.json import writes volatile', () => {
    const rebuilt = new z(TuiConfigSchema.toJSON()) as unknown as { dict?: Record<string, { meta?: { volatile?: boolean } }> }
    const fields = rebuilt.dict ?? {}
    for (const key of CLI_IMPORT_FIELDS) {
      assert.equal(fields[key]?.meta?.volatile, true, `${key} must be volatile or the import is rejected`)
    }
  })

  it('parses a defaulted config whose volatile fields are live references', () => {
    const value = TuiConfigSchema({}) as unknown as { themeName: { get: () => string }; animations: { get: () => boolean } }
    assert.equal(value.themeName.get(), 'opencode')
    assert.equal(value.animations.get(), true)
    // The resolver unwraps the references; an object leaking through would be a schema bug.
    const resolved = resolveTuiConfig(value as never)
    assert.equal(resolved.themeName, 'opencode')
    assert.equal(resolved.themeMode, 'system')
    assert.equal(resolved.pathDisplay, 'tilde')
    assert.equal(resolved.animations, true)
  })

  it('resolves pathDisplay through its live reference', () => {
    const value = TuiConfigSchema({ pathDisplay: 'full' }) as unknown as { pathDisplay: unknown }
    assert.notEqual(value.pathDisplay, 'full', 'a volatile field must not be a bare string')
    assert.equal(resolveTuiConfig(value as never).pathDisplay, 'full')
  })

  it('resolves newDesigns through its live reference', () => {
    // The bug this pins: the plugin compared the Config field with `=== true`, but a volatile
    // field is a live reference object, so the settings switch never applied (`newDesigns`
    // stayed off however often the picker was used). Only the resolver unwraps it.
    const value = TuiConfigSchema({ newDesigns: true }) as unknown as { newDesigns: unknown }
    assert.notEqual(value.newDesigns, true, 'a volatile field must not be a bare boolean')
    assert.equal(resolveTuiConfig(value as never).newDesigns, true)
  })
})
