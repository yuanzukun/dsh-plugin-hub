import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import {
  RENDERER_PROTOCOL_VERSION,
  decodeLine,
  encodeLine,
  envelopeErrors,
  splitLines,
  type IpcEnvelope,
} from '../src/ipc/envelope.ts'
import { DOWNSTREAM_KINDS, HOST_CAPABILITIES, UPSTREAM_KINDS } from '../src/ipc/kinds.ts'
import {
  DEFAULT_REQUIRED_CAPABILITIES,
  helloAck,
  negotiateRenderer,
  type HostView,
} from '../src/ipc/negotiate.ts'
import { IpcTransport, childChannel, nullChannel, processChannel } from '../src/ipc/transport.ts'

function helloEnvelope(capabilities: readonly string[], protocolVersion = RENDERER_PROTOCOL_VERSION): IpcEnvelope {
  return {
    protocolVersion,
    seq: 0,
    kind: 'hello',
    payload: {
      protocolVersion,
      rendererId: 'dpsk-renderer',
      rendererVersion: '0.5.0',
      capabilities,
      kinds: [...DOWNSTREAM_KINDS, ...UPSTREAM_KINDS],
    },
  }
}

/** A hello envelope that declares only some kinds, for degradation tests. */
function helloWithKinds(capabilities: readonly string[], kinds: readonly string[]): IpcEnvelope {
  return {
    protocolVersion: RENDERER_PROTOCOL_VERSION,
    seq: 0,
    kind: 'hello',
    payload: {
      protocolVersion: RENDERER_PROTOCOL_VERSION,
      rendererId: 'dpsk-renderer',
      rendererVersion: '0.5.0',
      capabilities,
      kinds,
    },
  }
}

const hostView: HostView = {
  hostId: 'my-dpsk-harness-tui',
  hostVersion: '0.5.0',
  capabilities: [...HOST_CAPABILITIES],
  requiredCapabilities: DEFAULT_REQUIRED_CAPABILITIES,
  terminalAuthorized: true,
}

describe('envelope framing', () => {
  it('round-trips an envelope through NDJSON', () => {
    const envelope: IpcEnvelope = { protocolVersion: 2, seq: 7, kind: 'session-snapshot', payload: { title: 'x', events: [] } }
    const line = encodeLine(envelope)
    assert.ok(!line.includes('\n'))
    const decoded = decodeLine(line)
    assert.deepEqual(decoded.errors, [])
    assert.deepEqual(decoded.envelope, envelope)
  })

  it('rejects a line that is not JSON', () => {
    const decoded = decodeLine('not json')
    assert.equal(decoded.envelope, undefined)
    assert.equal(decoded.errors.length, 1)
  })

  it('reports every missing envelope field', () => {
    const errors = envelopeErrors({ protocolVersion: 'one', kind: '' })
    assert.ok(errors.some(reason => reason.includes('protocolVersion')))
    assert.ok(errors.some(reason => reason.includes('seq')))
    assert.ok(errors.some(reason => reason.includes('kind')))
    assert.ok(errors.some(reason => reason.includes('payload')))
  })

  it('accepts a null payload', () => {
    assert.deepEqual(envelopeErrors({ protocolVersion: 2, seq: 0, kind: 'bye', payload: null }), [])
  })

  it('keeps a trailing partial line as the remainder', () => {
    const first = splitLines('{"a":1}\n{"b":2}\n{"c"', '')
    assert.deepEqual(first.lines, ['{"a":1}', '{"b":2}'])
    assert.equal(first.remainder, '{"c"')
    const second = splitLines('3}\n', first.remainder)
    assert.deepEqual(second.lines, ['{"c"3}'])
    assert.equal(second.remainder, '')
  })
})

describe('negotiateRenderer', () => {
  it('accepts a renderer that knows every kind and capability', () => {
    const negotiation = negotiateRenderer(helloEnvelope(['transcript', 'composer', 'dialog', 'scrollbar', 'mouse']), hostView)
    assert.equal(negotiation.status, 'compatible')
    assert.deepEqual(negotiation.reasons, [])
    assert.deepEqual(negotiation.skippedKinds, [])
  })

  it('degrades when the renderer does not know optional kinds', () => {
    const kinds = DOWNSTREAM_KINDS.filter(kind => kind !== 'log')
    const negotiation = negotiateRenderer(
      helloWithKinds(['transcript', 'composer', 'dialog', 'scrollbar', 'mouse'], [...kinds, ...UPSTREAM_KINDS]),
      hostView,
    )
    assert.equal(negotiation.status, 'compatible_degraded')
    assert.ok(negotiation.skippedKinds.includes('log'))
    assert.ok(negotiation.reasons.some(reason => reason.includes('log')))
  })

  it('degrades when the renderer lacks an optional capability', () => {
    const negotiation = negotiateRenderer(helloEnvelope(['transcript', 'composer']), hostView)
    assert.equal(negotiation.status, 'compatible_degraded')
    assert.ok(negotiation.degradedCapabilities.includes('mouse'))
    assert.ok(negotiation.reasons.some(reason => reason.includes('mouse')))
  })

  it('rejects a protocol version mismatch', () => {
    const negotiation = negotiateRenderer(helloEnvelope(['transcript', 'composer'], 1), hostView)
    assert.equal(negotiation.status, 'rejected')
    assert.ok(negotiation.reasons[0].includes('protocol version mismatch'))
  })

  it('rejects a renderer missing a required capability', () => {
    const negotiation = negotiateRenderer(helloEnvelope(['transcript']), hostView)
    assert.equal(negotiation.status, 'rejected')
    assert.ok(negotiation.reasons[0].includes('composer'))
  })

  it('waits for authorization when the TTY is not handed over', () => {
    const negotiation = negotiateRenderer(helloEnvelope(['transcript', 'composer']), { ...hostView, terminalAuthorized: false })
    assert.equal(negotiation.status, 'waiting_authorization')
    assert.ok(negotiation.reasons[0].includes('terminal handoff'))
  })

  it('reports unknown when the hello payload is malformed', () => {
    const negotiation = negotiateRenderer({ protocolVersion: 2, seq: 0, kind: 'hello', payload: {} }, hostView)
    assert.equal(negotiation.status, 'unknown')
  })

  it('names the capabilities the host itself does not provide', () => {
    const negotiation = negotiateRenderer(helloEnvelope(['transcript', 'composer']), {
      ...hostView,
      capabilities: ['session-events'],
    })
    assert.equal(negotiation.status, 'compatible_degraded')
    assert.ok(negotiation.reasons.some(reason => reason.includes('model-catalog')))
  })

  it('answers with the host identity and the negotiated status', () => {
    const negotiation = negotiateRenderer(helloEnvelope(['transcript', 'composer', 'dialog', 'scrollbar', 'mouse']), hostView)
    const ack = helloAck(negotiation, hostView)
    assert.equal(ack.protocolVersion, RENDERER_PROTOCOL_VERSION)
    assert.equal(ack.hostId, 'my-dpsk-harness-tui')
    assert.equal(ack.status, 'compatible')
    assert.deepEqual(ack.capabilities, hostView.capabilities)
  })
})

describe('IpcTransport', () => {
  it('assigns sequence numbers in send order', () => {
    const sent: string[] = []
    const transport = new IpcTransport({ send: text => sent.push(text), onMessage: () => () => undefined })
    const first = transport.send('hello', { protocolVersion: 2, rendererId: 'r', rendererVersion: '0.5.0', capabilities: [] })
    const second = transport.send('bye', null)
    assert.equal(first.seq, 0)
    assert.equal(second.seq, 1)
    assert.equal(transport.nextSeq, 2)
    assert.equal(sent.length, 2)
  })

  it('decodes inbound envelopes and fans out to every listener', () => {
    let emit: (text: string) => void = () => undefined
    const channel = { send: () => undefined, onMessage: (listener: (text: string) => void) => { emit = listener; return () => undefined } }
    const transport = new IpcTransport(channel)
    const seen: string[] = []
    transport.onEnvelope(envelope => seen.push(envelope.kind))
    transport.onEnvelope(envelope => seen.push(`second:${envelope.seq}`))
    emit(encodeLine({ protocolVersion: 2, seq: 3, kind: 'settings', payload: {} }))
    assert.deepEqual(seen, ['settings', 'second:3'])
  })

  it('drops a malformed envelope and logs why', () => {
    const logs: Array<{ level: string; text: string }> = []
    let emit: (text: string) => void = () => undefined
    const transport = new IpcTransport(
      { send: () => undefined, onMessage: (listener: (text: string) => void) => { emit = listener; return () => undefined } },
      (level, text) => logs.push({ level, text }),
    )
    const seen: string[] = []
    transport.onEnvelope(envelope => seen.push(envelope.kind))
    emit('{"protocolVersion":1,"seq":0,"kind":""}')
    assert.deepEqual(seen, [])
    assert.equal(logs[0].level, 'warn')
    assert.ok(logs[0].text.includes('kind'))
  })

  it('stops delivering after close', () => {
    let emit: (text: string) => void = () => undefined
    const transport = new IpcTransport({ send: () => undefined, onMessage: (listener: (text: string) => void) => { emit = listener; return () => undefined } })
    const seen: string[] = []
    transport.onEnvelope(envelope => seen.push(envelope.kind))
    transport.close()
    emit(encodeLine({ protocolVersion: 2, seq: 0, kind: 'log', payload: {} }))
    assert.deepEqual(seen, [])
  })

  it('works against a channel that carries nothing', () => {
    const transport = new IpcTransport(nullChannel())
    assert.equal(transport.send('bye', null).kind, 'bye')
  })
})

describe('channel adapters', () => {
  it('processChannel normalizes non-string messages to JSON text', () => {
    const sent: string[] = []
    const listeners: Array<(data: unknown) => void> = []
    const channel = processChannel(
      text => sent.push(text),
      listener => {
        listeners.push(listener)
        return () => {
          listeners.splice(listeners.indexOf(listener), 1)
        }
      },
    )
    const received: string[] = []
    channel.onMessage(text => received.push(text))
    listeners[0]?.({ protocolVersion: 2, seq: 0, kind: 'bye', payload: null })
    assert.deepEqual(received, [JSON.stringify({ protocolVersion: 2, seq: 0, kind: 'bye', payload: null })])
    channel.send('line')
    assert.deepEqual(sent, ['line'])
  })

  it('childChannel unsubscribes and releases the child listener when empty', () => {
    const removals: number[] = []
    const listeners: Array<(data: unknown) => void> = []
    const child = {
      send: () => undefined,
      on: (_event: 'message', listener: (data: unknown) => void) => {
        listeners.push(listener)
        return {
          removeListener: (_event: 'message', target: (data: unknown) => void) => {
            listeners.splice(listeners.indexOf(target), 1)
            removals.push(listeners.length)
          },
        }
      },
    }
    const channel = childChannel(child)
    const received: string[] = []
    const off = channel.onMessage(text => received.push(text))
    listeners[0]?.('one')
    assert.deepEqual(received, ['one'])
    off()
    assert.equal(removals.length, 1)
    assert.equal(listeners.length, 0)
    channel.onMessage(text => received.push(text))
    listeners[0]?.('two')
    assert.deepEqual(received, ['one', 'two'])
  })

  it('childChannel survives a closed channel, stops sending, and reports once', () => {
    const reports: string[] = []
    const attempts: string[] = []
    const child = {
      send: (message: string) => {
        attempts.push(message)
        const error = new Error('Channel closed') as Error & { code?: string }
        error.code = 'ERR_IPC_CHANNEL_CLOSED'
        throw error
      },
      on: (_event: 'message', _listener: (data: unknown) => void) => ({ removeListener: () => undefined }),
    }
    const channel = childChannel(child, text => reports.push(text))
    channel.send('one')
    channel.send('two')
    // The first send throws and is caught; the channel is marked closed, so the second
    // send never reaches the child. One report, not one per send.
    assert.deepEqual(attempts, ['one'])
    assert.equal(reports.length, 1)
    assert.ok(reports[0].includes('ERR_IPC_CHANNEL_CLOSED'))
  })

  it('childChannel sends normally when the channel is open', () => {
    const sent: string[] = []
    const reports: string[] = []
    const child = {
      send: (message: string) => sent.push(message),
      on: (_event: 'message', _listener: (data: unknown) => void) => ({ removeListener: () => undefined }),
    }
    const channel = childChannel(child, text => reports.push(text))
    channel.send('one')
    channel.send('two')
    assert.deepEqual(sent, ['one', 'two'])
    assert.deepEqual(reports, [])
  })
})
