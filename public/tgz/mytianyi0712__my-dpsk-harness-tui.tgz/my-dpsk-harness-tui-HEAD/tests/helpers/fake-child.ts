import type { ChildProcess } from 'node:child_process'
import { RENDERER_PROTOCOL_VERSION } from '../../src/ipc/envelope.ts'
import { DOWNSTREAM_KINDS, UPSTREAM_KINDS } from '../../src/ipc/kinds.ts'

/**
 * A fake spawned child for renderer host tests.
 *
 * The host's renderer modules use three child capabilities: `send` for envelopes,
 * `on('message')` for upstream envelopes, `on('exit')` for the process exit, and
 * `kill` for `stop`. The fake records everything and lets a test emit an event.
 */
export interface FakeChildState {
  sent: string[]
  kills: number
  listeners: Record<string, Array<(...args: unknown[]) => void>>
}

export function fakeChild(): { child: ChildProcess; state: FakeChildState } {
  const state: FakeChildState = { sent: [], kills: 0, listeners: {} }
  const child = {
    send: (message: string) => state.sent.push(message),
    on: (event: string, listener: (...args: unknown[]) => void) => {
      state.listeners[event] = [...(state.listeners[event] ?? []), listener]
      return {
        removeListener: (targetEvent: string, target: (...args: unknown[]) => void) => {
          state.listeners[targetEvent] = (state.listeners[targetEvent] ?? []).filter(item => item !== target)
        },
      }
    },
    kill: () => { state.kills += 1 },
  }
  return { child: child as unknown as ChildProcess, state }
}

export function emit(state: FakeChildState, event: string, ...args: unknown[]): void {
  for (const listener of state.listeners[event] ?? []) listener(...args)
}

/** Parse the envelopes the fake child received, in order. */
export function sentEnvelopes(state: FakeChildState): Array<{ kind: string; payload: Record<string, unknown> }> {
  return state.sent.map(line => {
    const envelope = JSON.parse(line) as { kind: string; payload: unknown }
    return { kind: envelope.kind, payload: typeof envelope.payload === 'object' && envelope.payload !== null ? (envelope.payload as Record<string, unknown>) : {} }
  })
}

/** The hello a compliant renderer sends first. */
export function helloEnvelope(seq = 0): { protocolVersion: number; seq: number; kind: string; payload: unknown } {
  return {
    protocolVersion: RENDERER_PROTOCOL_VERSION,
    seq,
    kind: 'hello',
    payload: {
      protocolVersion: RENDERER_PROTOCOL_VERSION,
      rendererId: 'dpsk-renderer',
      rendererVersion: '0.5.0',
      capabilities: ['transcript', 'composer', 'dialog', 'scrollbar', 'mouse'],
      kinds: [...DOWNSTREAM_KINDS, ...UPSTREAM_KINDS],
    },
  }
}
