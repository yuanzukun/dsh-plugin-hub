import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { SessionId, type SessionPersistence, type SessionPersistenceSnapshot } from '../src/dsh-host/index.ts'
import {
  ACTIVITY_TAIL_EVENTS,
  isInteractionActivity,
  liveLastActivity,
  SessionActivityResolver,
  sessionActivityAt,
  sortSessionsByActivity,
} from '../src/session-activity.ts'

describe('session activity ordering', () => {
  it('sorts by last activity, falls back to createdAt, and breaks ties by id', () => {
    const rows = [
      { id: 'A', createdAt: 10, lastActivityAt: 40 },
      { id: 'B', createdAt: 20, lastActivityAt: 50 },
      { id: 'C', createdAt: 30, lastActivityAt: 30 },
      { id: 'D', createdAt: 25 },
      { id: 'E', createdAt: 25 },
    ]
    assert.deepEqual(sortSessionsByActivity(rows).map(row => row.id), ['B', 'A', 'C', 'D', 'E'])
    assert.equal(sessionActivityAt({ id: 'x', createdAt: 42 }), 42)
    assert.equal(sessionActivityAt({ id: 'x', createdAt: 42, lastActivityAt: 99 }), 99)
  })

  it('classifies only real interaction events, not replay bookkeeping', () => {
    assert.equal(isInteractionActivity({ type: 'assistant/message', time: 1 }), true)
    assert.equal(isInteractionActivity({ type: 'turn/end', time: 1 }), true)
    assert.equal(isInteractionActivity({ type: 'session/end-seed', time: 1 }), false)
    assert.equal(isInteractionActivity({ type: 'session/title', time: 1 }), false)
    assert.equal(isInteractionActivity({ type: 'workspace/changes', time: 1 }), false)
    assert.equal(isInteractionActivity(undefined), false)
  })

  it('reads a bounded tail and ignores bookkeeping after the last interaction', async () => {
    const opened: number[] = []
    let revision = 1
    let calls = 0
    const persistence = {
      stat: async () => ({
        header: { id: SessionId('s1') },
        revision,
        eventCount: 12,
      }) as unknown as SessionPersistenceSnapshot,
      open: async () => {
        opened.push(revision)
        return {
          read: async (offset: number, length: number) => {
            assert.equal(offset, 0)
            assert.equal(length, 12)
            calls += 1
            return {
              eventState: 'detached',
              events: [
                { type: 'user/message', time: 1_000 },
                { type: 'assistant/message', time: 5_000 },
                { type: 'session/end-seed', time: 9_000 },
                { type: 'session/title', time: 9_100 },
              ],
            }
          },
          close: async () => undefined,
        }
      },
    } as unknown as SessionPersistence
    const resolver = new SessionActivityResolver(persistence)
    assert.equal(await resolver.lastActivityAt(SessionId('s1')), 5_000)
    assert.equal(await resolver.lastActivityAt(SessionId('s1')), 5_000)
    assert.equal(calls, 1)
    revision = 2
    assert.equal(await resolver.lastActivityAt(SessionId('s1')), 5_000)
    assert.equal(calls, 2)
    assert.deepEqual(opened, [1, 2])
  })

  it('uses a known snapshot and returns undefined when the backend has no event count', async () => {
    let openCalls = 0
    const persistence = {
      stat: async () => undefined,
      open: async () => {
        openCalls += 1
        return { read: async () => ({ eventState: 'detached', events: [] }), close: async () => undefined }
      },
    } as unknown as SessionPersistence
    const resolver = new SessionActivityResolver(persistence)
    const snapshot = { header: { id: SessionId('s2') }, revision: 'r1' } as unknown as SessionPersistenceSnapshot
    assert.equal(await resolver.lastActivityAt(SessionId('s2'), snapshot), undefined)
    assert.equal(openCalls, 0)
  })

  it('derives live activity from the newest interaction and tolerates an empty log', () => {
    const events = new Map<number, { type?: string; time?: number }>([
      [0, { type: 'user/message', time: 100 }],
      [1, { type: 'assistant/message', time: 200 }],
      [2, { type: 'session/end-seed', time: 999 }],
    ])
    assert.equal(liveLastActivity({ seq: 3, eventAt: seq => events.get(Number(seq)) }), 200)
    assert.equal(liveLastActivity({ seq: 2, eventAt: () => ({ type: 'session/end-seed', time: 1 }) }), undefined)
    assert.equal(liveLastActivity({ seq: 0, eventAt: () => ({ type: 'user/message', time: 1 }) }), undefined)
    assert.equal(liveLastActivity({ seq: 2, eventAt: () => undefined }), undefined)
  })

  it('bounds the live scan to the interaction tail window', () => {
    let reads = 0
    liveLastActivity({
      seq: ACTIVITY_TAIL_EVENTS + 10,
      eventAt: () => {
        reads += 1
        return { type: 'session/end-seed', time: 1 }
      },
    })
    assert.equal(reads, ACTIVITY_TAIL_EVENTS)
  })
})
