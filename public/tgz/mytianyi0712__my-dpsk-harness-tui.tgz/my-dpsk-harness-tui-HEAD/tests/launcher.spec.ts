/**
 * Launcher migration tests: the 0.4.0 `dsh-omp-tui` package must be stripped from the
 * profile's `package.json`, not just renamed on disk. With both packages installed the
 * old one wins the `tui` service slot and the new package silently does not activate —
 * the state a user sees as "the new version is not installed".
 *
 * `stripLegacyProfilePackage` is exported from the launcher for
 * these tests; the launcher only dispatches when it is the main module, so importing it
 * spawns nothing.
 */

import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { homedir, tmpdir } from 'node:os'
import { join } from 'node:path'
import { RESTART_EXIT_CODE, backendChoicePath, backendDriftWarning, backendSignature, migrateLegacyBackendChoice, pickBackend, programConfigHome, restartHandoffPath, savedBackendCommand, stripLegacyProfilePackage, withResumeArgument } from '../scripts/dpsk.js'
/** A temp DSH_HOME whose tui profile carries the given manifest. */
async function fixture(manifest: unknown): Promise<string> {
  const home = await mkdtemp(join(tmpdir(), 'dpsk-launcher-'))
  await mkdir(join(home, 'profiles', 'tui'), { recursive: true })
  await writeFile(
    join(home, 'profiles', 'tui', 'package.json'),
    `${JSON.stringify(manifest, null, 2)}\n`,
    'utf8',
  )
  return home
}

function profileJson(home: string): string {
  return join(home, 'profiles', 'tui', 'package.json')
}

const legacyManifest = {
  name: 'dsh-profile-tui',
  private: true,
  dsh: { profile: { bundles: ['@deepseek-ai/dsh-base', 'dsh-omp-tui', 'my-dpsk-harness-tui'] } },
  dependencies: {
    'dsh-omp-tui': 'https://github.com/mytianyi0712/dsh-tui-plugin-OhMyPi/releases/download/v0.4.0/dsh-omp-tui-0.4.0.tgz',
    'my-dpsk-harness-tui': 'file:C:/Temp/dpsk-pack/my-dpsk-harness-tui-0.5.0.tgz',
  },
  devDependencies: { 'dsh-omp-tui': '0.4.0' },
}

describe('legacy profile package migration', () => {
  it('strips the legacy bundle and both dependency tables', async () => {
    const home = await fixture(legacyManifest)
    const result = stripLegacyProfilePackage(home)
    assert.deepEqual(result, { changed: true, removed: ['dsh.profile.bundles', 'dependencies', 'devDependencies'] })

    const written = JSON.parse(await readFile(profileJson(home), 'utf8'))
    assert.deepEqual(written.dsh.profile.bundles, ['@deepseek-ai/dsh-base', 'my-dpsk-harness-tui'])
    assert.deepEqual(Object.keys(written.dependencies), ['my-dpsk-harness-tui'])
    assert.deepEqual(written.devDependencies, {})
    await rm(home, { recursive: true, force: true })
  })

  it('is idempotent: a second run reports no change and rewrites nothing', async () => {
    const home = await fixture(legacyManifest)
    stripLegacyProfilePackage(home)
    const after = await readFile(profileJson(home), 'utf8')
    const second = stripLegacyProfilePackage(home)
    assert.deepEqual(second, { changed: false, removed: [] })
    assert.equal(await readFile(profileJson(home), 'utf8'), after)
    await rm(home, { recursive: true, force: true })
  })

  it('leaves a profile without the legacy entry byte-identical', async () => {
    const home = await fixture({
      dsh: { profile: { bundles: ['@deepseek-ai/dsh-base', 'my-dpsk-harness-tui'] } },
      dependencies: { 'my-dpsk-harness-tui': 'file:C:/Temp/dpsk-pack/my-dpsk-harness-tui-0.5.0.tgz' },
    })
    const before = await readFile(profileJson(home), 'utf8')
    assert.deepEqual(stripLegacyProfilePackage(home), { changed: false, removed: [] })
    assert.equal(await readFile(profileJson(home), 'utf8'), before)
    await rm(home, { recursive: true, force: true })
  })

  it('reports no change for a missing or malformed manifest', async () => {
    const empty = await mkdtemp(join(tmpdir(), 'dpsk-launcher-'))
    assert.deepEqual(stripLegacyProfilePackage(empty), { changed: false, removed: [] })
    await rm(empty, { recursive: true, force: true })

    const home = await fixture({})
    await writeFile(profileJson(home), '{', 'utf8')
    assert.deepEqual(stripLegacyProfilePackage(home), { changed: false, removed: [] })
    assert.equal(await readFile(profileJson(home), 'utf8'), '{')
    await rm(home, { recursive: true, force: true })
  })
})

describe('backend selection', () => {
  const pathCandidate = { source: 'PATH', command: 'dsh', resolved: 'C:/npm/dsh.cmd', version: '0.2.0-rc.2' }
  const systemCandidate = { source: 'PATH', command: 'C:/Program Files/nodejs/dsh.cmd', resolved: 'C:/Program Files/nodejs/dsh.cmd', version: '0.2.1-rc.2' }
  const realCandidate = { source: 'DSH_REAL', command: 'C:/other/dsh.cmd', resolved: 'C:/other/dsh.cmd', version: '0.2.1-rc.2' }

  it('uses the only backend without asking', () => {
    assert.deepEqual(pickBackend([pathCandidate], undefined), { chosen: pathCandidate, needsPrompt: false })
  })

  it('honours an explicit DSH_REAL without asking, even with several backends', () => {
    assert.deepEqual(pickBackend([realCandidate, pathCandidate, systemCandidate], undefined), { chosen: realCandidate, needsPrompt: false })
  })

  it('reuses the remembered choice by command or by resolved path', () => {
    assert.equal(pickBackend([pathCandidate, systemCandidate], 'dsh').chosen, pathCandidate)
    assert.equal(pickBackend([pathCandidate, systemCandidate], 'C:/Program Files/nodejs/dsh.cmd').chosen, systemCandidate)
  })

  it('asks once when several backends are unknown', () => {
    const result = pickBackend([pathCandidate, systemCandidate], undefined)
    assert.equal(result.chosen, undefined)
    assert.equal(result.needsPrompt, true)
  })

  it('asks again when the remembered backend disappeared', () => {
    const result = pickBackend([pathCandidate, systemCandidate], 'C:/gone/dsh.cmd')
    assert.equal(result.needsPrompt, true)
  })

  it('returns nothing to run when no backend exists', () => {
    assert.deepEqual(pickBackend([], undefined), { chosen: undefined, needsPrompt: false })
  })

  it('warns only when the backend is older than the desktop runtime', () => {
    assert.equal(backendDriftWarning('0.2.0-rc.2', undefined), '')
    assert.equal(backendDriftWarning('0.2.1-rc.2', '0.2.1-rc.2'), '')
    assert.equal(backendDriftWarning('0.2.1-rc.2', '0.2.0-rc.2'), '')
    const warning = backendDriftWarning('0.2.0-rc.2', '0.2.1-rc.2')
    assert.match(warning, /0\.2\.1-rc\.2/)
    assert.match(warning, /npm i -g @deepseek-ai\/dsh@0\.2\.1-rc\.2/)
  })

  it('keeps the remembered choice under the program config home', () => {
    assert.equal(backendChoicePath('C:/config/.mydpsk'), join('C:/config/.mydpsk', 'backend.json'))
  })

  it('defaults the program config home to ~/.config/.mydpsk', () => {
    assert.equal(programConfigHome(), join(homedir(), '.config', '.mydpsk'))
  })

  it('migrates a legacy backend choice once and leaves the legacy file in place', async () => {
    const home = await mkdtemp(join(tmpdir(), 'dpsk-config-migrate-'))
    const legacy = join(home, 'legacy', 'backend.json')
    const next = join(home, 'config', 'backend.json')
    await mkdir(join(home, 'legacy'), { recursive: true })
    await writeFile(legacy, '{"command":"dsh"}\n', 'utf8')
    assert.equal(migrateLegacyBackendChoice(legacy, next), true)
    assert.equal(await readFile(next, 'utf8'), '{"command":"dsh"}\n')
    assert.equal(existsSync(legacy), true)
    assert.equal(migrateLegacyBackendChoice(legacy, next), false)
    await rm(home, { recursive: true, force: true })
  })

  it('uses a saved backend without probing once its file signature matches', () => {
    const choice = { command: 'dsh', resolved: 'C:/npm/dsh.cmd', signature: '123:456' }
    assert.equal(savedBackendCommand(choice, undefined, () => '123:456'), 'C:/npm/dsh.cmd')
  })

  it('falls back to discovery when the saved backend is missing, unsigned, or replaced', () => {
    assert.equal(savedBackendCommand(undefined, undefined, () => '123:456'), undefined)
    assert.equal(savedBackendCommand({ command: 'dsh', resolved: 'C:/npm/dsh.cmd' }, undefined, () => '123:456'), undefined)
    assert.equal(savedBackendCommand({ command: 'dsh', resolved: 'C:/npm/dsh.cmd', signature: '123:456' }, undefined, () => undefined), undefined)
    assert.equal(savedBackendCommand({ command: 'dsh', resolved: 'C:/npm/dsh.cmd', signature: '123:456' }, undefined, () => '123:999'), undefined)
  })

  it('never lets the signature cache override DSH_REAL', () => {
    assert.equal(savedBackendCommand({ command: 'dsh', resolved: 'C:/npm/dsh.cmd', signature: '123:456' }, 'C:/other/dsh.cmd', () => '123:456'), undefined)
  })

  it('signs a real file with size and mtime', async () => {
    const home = await mkdtemp(join(tmpdir(), 'dpsk-backend-signature-'))
    const file = join(home, 'dsh.cmd')
    await writeFile(file, 'fixture', 'utf8')
    assert.match(backendSignature(file) ?? '', /^7:\d+$/)
    assert.equal(backendSignature(join(home, 'missing.cmd')), undefined)
    await rm(home, { recursive: true, force: true })
  })
})

describe('restart supervisor helpers', () => {
  it('replaces an existing --resume argument instead of duplicating it', () => {
    assert.deepEqual(withResumeArgument(['--profile', 'tui', '--resume', 'old'], 'new'), ['--profile', 'tui', '--resume', 'new'])
    assert.deepEqual(withResumeArgument(['--profile', 'tui'], 'new'), ['--profile', 'tui', '--resume', 'new'])
  })

  it('uses a dedicated exit code and the program config runtime path', () => {
    assert.equal(RESTART_EXIT_CODE, 75)
    const previous = process.env.MYDPSK_CONFIG_HOME
    process.env.MYDPSK_CONFIG_HOME = 'C:/config-home'
    try {
      assert.equal(restartHandoffPath(), join('C:/config-home', 'runtime', 'restart.json'))
    } finally {
      if (previous === undefined) delete process.env.MYDPSK_CONFIG_HOME
      else process.env.MYDPSK_CONFIG_HOME = previous
    }
  })
})
