import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { SessionId, type SessionEvent, type SessionHandle, type SessionHeader, type SessionPersistence } from '../src/dsh-host/index.ts'
import { ConversationGatedHandle, installConversationGatedCreate } from '../src/lazy-session-persistence.ts'

const header = {
  version: 4,
  id: SessionId('tui-lazy'),
  createdAt: 100,
  cwd: 'D:/Projects/dsh',
  isSeeded: false,
} as unknown as SessionHeader

const event = (type: string): SessionEvent => ({ type, seq: 0, time: 1, data: {} }) as unknown as SessionEvent

interface FakeBackend {
  readonly persistence: SessionPersistence
  readonly appends: string[][]
  readonly calls: { create: number; flush: number; close: number; read: number }
}

function fakeBackend(): FakeBackend {
  const appends: string[][] = []
  const calls = { create: 0, flush: 0, close: 0, read: 0 }
  let real: SessionHandle | undefined
  const persistence = {
    create: async () => {
      calls.create += 1
      real = {
        id: header.id,
        header,
        inheritedEventCount: 0,
        access: 'write',
        read: async () => {
          calls.read += 1
          return { eventState: 'detached', events: [] }
        },
        append: async (events: readonly SessionEvent[]) => {
          appends.push(events.map(item => item.type))
        },
        flush: async () => { calls.flush += 1 },
        close: async () => { calls.close += 1 },
        [Symbol.asyncDispose]: async () => undefined,
      } as unknown as SessionHandle
      return real
    },
  } as unknown as SessionPersistence
  return { persistence, appends, calls }
}

describe('conversation-gated persistence', () => {
  it('drops a setup-only session instead of materializing it', async () => {
    const fake = fakeBackend()
    const restore = installConversationGatedCreate(fake.persistence)
    try {
      const handle = await fake.persistence.create(header)
      await handle.append([event('session'), event('permission/preset'), event('sandbox/mode'), event('approval/policy')])
      await handle.flush()
      await handle.close()
      assert.equal(fake.calls.create, 0)
      assert.equal(fake.calls.flush, 0)
      assert.equal(fake.calls.close, 0)
      assert.deepEqual(fake.appends, [])
      // Calling close twice is idempotent and still leaves no artifact behind.
      await handle.close()
      assert.equal(fake.calls.close, 0)
    } finally {
      restore()
    }
  })

  it('materializes once and replays the setup buffer before the first conversation event', async () => {
    const fake = fakeBackend()
    const restore = installConversationGatedCreate(fake.persistence)
    try {
      const handle = await fake.persistence.create(header)
      await handle.append([event('session'), event('permission/preset')])
      const buffered = await handle.read(0, 10)
      assert.deepEqual(buffered.events.map(item => item.type), ['session', 'permission/preset'])
      assert.equal(fake.calls.create, 0)

      await handle.append([event('user/message')])
      assert.equal(fake.calls.create, 1)
      assert.deepEqual(fake.appends, [['session', 'permission/preset', 'user/message']])
      assert.equal(handle.access, 'write')
      assert.equal(handle.inheritedEventCount, 0)

      await handle.append([event('assistant/message')])
      assert.deepEqual(fake.appends, [
        ['session', 'permission/preset', 'user/message'],
        ['assistant/message'],
      ])
      await handle.flush()
      assert.equal(fake.calls.flush, 1)
      await handle.close()
      assert.equal(fake.calls.close, 1)
      assert.equal(fake.calls.create, 1)
    } finally {
      restore()
    }
  })

  it('retains the create options inherited count and restores the original method', async () => {
    const fake = fakeBackend()
    const original = fake.persistence.create
    const restore = installConversationGatedCreate(fake.persistence)
    assert.notEqual(fake.persistence.create, original)
    const handle = await fake.persistence.create(header, { inheritedEventCount: 3 as never })
    assert.ok(handle instanceof ConversationGatedHandle)
    assert.equal(handle.inheritedEventCount, 3)
    restore()
    assert.equal(fake.persistence.create, original)
  })
})
