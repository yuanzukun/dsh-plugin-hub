import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { migrateRecord, normalizeEvent, encodeSession, decodeAllFrames } from '../scripts/sessions-migrate.mjs'
import { validateStoredEvents } from '@deepseek-ai/dsh-session-persistence'

const header = {
  type: 'session',
  version: 0,
  id: 'session-test',
  createdAt: 1700000000000,
  cwd: 'D:/x',
  delegationDepth: 0,
}

/** A v0 log that carries one of each shape v4 rejects. */
function legacyRecord() {
  return {
    header,
    events: [
      { type: 'permission/preset', seq: 0, time: 1, data: { preset: 'workspace-write' } },
      { type: 'request/header', seq: 1, time: 2, data: { header: { config: {}, system: 'You are a helpful assistant.', tools: [] } } },
      { type: 'assistant/message', seq: 2, time: 3, data: { turn: 1, step: 1, message: { role: 'assistant', id: 'msg-1', content: [{ type: 'text', text: 'hi' }], source: { kind: 'model', provider: 'p', model: 'm' } } } },
      { type: 'tool/call', seq: 3, time: 4, data: { turn: 1, step: 1, callId: 'call-1', name: 'pwsh', arguments: '{"command":"ls"}' } },
      { type: 'tool/result', seq: 4, time: 5, data: { turn: 1, step: 1, message: { role: 'user', id: 'res-1', content: [{ type: 'text', text: 'ok' }], source: { kind: 'tool', callId: 'call-1' } } }, sourceEventSeqs: [3] },
      // v0 streaming deltas: still in the log, unknown to v4, must be marked ignorable.
      { type: 'assistant/chunk', seq: 5, time: 6, data: { turn: 1, step: 1, chunk: { type: 'text-delta', text: 'h' } } },
      { type: 'text-chunks', seq: 6, time: 7, data: { turn: 1, step: 1, chunks: ['h'] } },
      // An object where the surface marker belongs, and a replace op v4 no longer accepts.
      { type: 'user/message', seq: 7, time: 8, data: { role: 'user', id: 'msg-u1', content: [{ type: 'text', text: 'edited' }], source: { kind: 'user' } }, surfaceOp: { kind: 'replace' } },
      // A result with no call id: it cannot be attributed, so it must not reach the log.
      { type: 'tool/result', seq: 8, time: 9, data: { turn: 2, step: 1, message: { role: 'user', id: 'res-2', content: [{ type: 'text', text: 'boom' }], source: { kind: 'tool', callId: '' } }, error: { name: 'ToolNotFoundError' } }, sourceEventSeqs: [7] },
    ],
  }
}

describe('legacy session migration', () => {
  it('produces a log the current reader accepts', () => {
    const migrated = migrateRecord(legacyRecord(), type => !['assistant/chunk', 'text-chunks', 'reasoning-chunks'].includes(type))
    const [headerLine, ...eventLines] = migrated.lines
    const nextHeader = JSON.parse(headerLine)
    const events = eventLines.map(line => JSON.parse(line))
    assert.equal(nextHeader.version, 4)
    assert.equal(nextHeader.isSeeded, false)
    // The reader's own validation is the contract: no throw means dsh can open it.
    assert.doesNotThrow(() => validateStoredEvents(nextHeader, events, { kind: 'session', sessionId: nextHeader.id }))
    // The unattributable result row is the only thing dropped.
    assert.deepEqual(Object.fromEntries(migrated.dropped), { 'tool/result': 1 })
    // Both streaming rows survived, flagged as safe to ignore.
    assert.equal(migrated.marked.get('assistant/chunk'), 1)
    assert.equal(migrated.marked.get('text-chunks'), 1)
    const chunks = events.filter(event => event.type === 'assistant/chunk' || event.type === 'text-chunks')
    assert.equal(chunks.length, 2)
    for (const chunk of chunks) assert.equal(chunk.ignorable, true)
  })

  it('drops the system prompt from a recorded request header', () => {
    const event = normalizeEvent({ type: 'request/header', seq: 1, time: 2, data: { header: { system: 'x', tools: [] } } })
    assert.equal(event.data.header.system, undefined)
    // v4 refuses an empty `tools` array, so the field goes away entirely.
    assert.equal(event.data.header.tools, undefined)
  })

  it('gives a tool result the role, id and error flag the reader requires', () => {
    const event = normalizeEvent({ type: 'tool/result', seq: 4, data: { message: { role: 'user', content: 'x', source: { kind: 'tool', callId: 'call-1' } }, error: { name: 'x' } } })
    assert.equal(event.data.message.role, 'tool')
    assert.equal(event.data.message.toolCallId, 'call-1')
    assert.deepEqual(event.data.message.source, { kind: 'tool', callId: 'call-1' })
    assert.equal(event.data.message.isError, true)
  })

  it('round-trips through the frame encoding the store uses', () => {
    const migrated = migrateRecord(legacyRecord(), () => true)
    const encoded = encodeSession(migrated.lines)
    assert.equal(decodeAllFrames(encoded).trim(), migrated.lines.join('\n'))
  })
})
