import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { mkdir, mkdtemp, rm, symlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { listWorkspaceFiles } from '../src/workspace-files.ts'

async function workspace(): Promise<string> {
  return mkdtemp(join(tmpdir(), 'dpsk-workspace-'))
}

describe('workspace file index', () => {
  it('lists directories first with a trailing slash, then files, relative to the root', async () => {
    const root = await workspace()
    await mkdir(join(root, 'src'))
    await writeFile(join(root, 'src', 'app.ts'), 'x')
    await writeFile(join(root, 'README.md'), 'x')
    const files = await listWorkspaceFiles(root)
    assert.deepEqual(files, ['src/', 'src/app.ts', 'README.md'])
    await rm(root, { recursive: true, force: true })
  })

  it('skips .git and node_modules entirely', async () => {
    const root = await workspace()
    await mkdir(join(root, '.git'))
    await writeFile(join(root, '.git', 'HEAD'), 'ref')
    await mkdir(join(root, 'node_modules', 'dep'), { recursive: true })
    await writeFile(join(root, 'node_modules', 'dep', 'index.js'), 'x')
    await writeFile(join(root, 'main.ts'), 'x')
    assert.deepEqual(await listWorkspaceFiles(root), ['main.ts'])
    await rm(root, { recursive: true, force: true })
  })

  it('lists a symlink but never follows it', async () => {
    const root = await workspace()
    await mkdir(join(root, 'real'))
    await writeFile(join(root, 'real', 'inside.ts'), 'x')
    await symlink(join(root, 'real'), join(root, 'link'), 'dir').catch(() => undefined)
    const files = await listWorkspaceFiles(root)
    assert.ok(files.includes('real/'))
    assert.ok(files.includes('real/inside.ts'))
    // A followed link would produce `link/` and `link/inside.ts`; a symlinked directory is
    // skipped as an entry, so neither appears.
    assert.ok(!files.includes('link/inside.ts'))
    await rm(root, { recursive: true, force: true })
  })

  it('rejects when the root cannot be read, so the host reports a real failure', async () => {
    await assert.rejects(() => listWorkspaceFiles(join(tmpdir(), 'dpsk-no-such-workspace-xyz')))
  })
})
