import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { adaptTerminalController, type TerminalFrame } from '../src/dsh-host/terminal-controller.ts'
import type { Agent } from '../src/dsh-host/agent.ts'
import type { Context } from '../src/dsh-host/framework.ts'
import type { SessionId } from '../src/dsh-host/session.ts'

const sessionId = 'ses-terminal' as unknown as SessionId
const agent = { id: sessionId } as Agent
const context = {} as Context
const info = {
  id: 'term',
  title: 'Shell',
  shell: { path: '/bin/sh', args: ['-i'], name: 'sh' },
  cwd: '/workspace',
  cols: 80,
  rows: 24,
  state: 'running' as const,
  exitCode: null,
}
const signal = new AbortController().signal

describe('terminal controller compatibility adapter', () => {
  it('maps the 0.2.0 follow/write/resize methods onto the stable local contract', async () => {
    const calls: string[] = []
    const raw = {
      environment: () => ({ cwd: '/workspace', maxInputBytes: 1024, maxCols: 120, maxRows: 40, scrollback: 1000 }),
      list: () => [{ ...info, controllerId: 'controller-1' }],
      create: async () => info,
      retain: async function* () { yield { type: 'retained' } },
      close: async () => undefined,
      async *follow() {
        calls.push('follow')
        yield { type: 'snapshot', sequence: 1, screen: 'ready', info, writable: true }
      },
      async write(_agent: Agent, _id: string, attachmentId: string, data: string) {
        calls.push(`write:${attachmentId}:${data}`)
      },
      async resize(_agent: Agent, _id: string, attachmentId: string, cols: number, rows: number) {
        calls.push(`resize:${attachmentId}:${cols}x${rows}`)
      },
    }

    const controller = adaptTerminalController(raw, context)
    const listed = controller.list(sessionId)
    assert.equal(listed[0]?.controllerId, 'controller-1')
    assert.deepEqual(controller.environment(agent, signal), {
      cwd: '/workspace',
      maxInputBytes: 1024,
      maxCols: 120,
      maxRows: 40,
      scrollback: 1000,
    })

    const frames: TerminalFrame[] = []
    for await (const frame of controller.follow(agent, 'term', 'attachment-1', signal)) frames.push(frame)
    await controller.write(agent, 'term', 'attachment-1', 'ls\r')
    await controller.resize(agent, 'term', 'attachment-1', 100, 30)

    assert.deepEqual(frames, [{ type: 'snapshot', sequence: 1, screen: 'ready', info }])
    assert.deepEqual(calls, ['follow', 'write:attachment-1:ls\r', 'resize:attachment-1:100x30'])
  })

  it('bridges the 0.2.1 attach stream through the in-process gateway', async () => {
    const snapshotSeen = Promise.withResolvers<void>()
    const inputSeen = Promise.withResolvers<readonly unknown[]>()
    const requests: unknown[] = []
    const raw = {
      environment: () => ({ cwd: '/workspace', maxInputBytes: 1024, maxCols: 120, maxRows: 40, scrollback: 1000 }),
      list: () => [info],
      create: async () => info,
      retain: async function* () { yield { type: 'retained' } },
      close: async () => undefined,
      attach: async function* () { yield { type: 'snapshot', sequence: 1, screen: '', info } },
    }
    const gateway = {
      async stream(request: {
        uplink?: AsyncIterable<unknown>
      }) {
        requests.push(request)
        const uplink = request.uplink
        assert.ok(uplink !== undefined)
        return (async function* () {
          yield { type: 'snapshot', sequence: 7, screen: 'ready', info, writable: true }
          snapshotSeen.resolve()
          const iterator = uplink[Symbol.asyncIterator]()
          const first = await iterator.next()
          const second = await iterator.next()
          inputSeen.resolve([first.value, second.value])
          yield { type: 'ack', sequence: 1 }
          yield { type: 'state', info: { ...info, title: 'Renamed' }, writable: true }
          yield { type: 'output', sequence: 8, data: 'hello' }
          yield { type: 'state', info: { ...info, title: 'Read only' }, writable: false }
        })()
      },
    }
    const contextWithGateway = {
      get(key: string) {
        return key === 'typertGateway' ? gateway : undefined
      },
    } as unknown as Context

    const controller = adaptTerminalController(raw, contextWithGateway)
    const frames: TerminalFrame[] = []
    const following = (async () => {
      for await (const frame of controller.follow(agent, 'term', 'attachment-1', signal)) frames.push(frame)
    })()
    await snapshotSeen.promise
    await controller.write(agent, 'term', 'attachment-1', 'echo hi\r')
    await controller.resize(agent, 'term', 'attachment-1', 100, 30)
    await following

    assert.equal(requests.length, 1)
    const request = requests[0] as {
      namespace: string
      method: string
      args: Record<string, unknown>
      peer: { principal: { kind: string }; interactions: string }
    }
    assert.equal(request.namespace, 'terminal')
    assert.equal(request.method, 'attach')
    assert.deepEqual(request.args, { agentId: sessionId, id: 'term' })
    assert.equal(request.peer.principal.kind, 'owner')
    assert.equal(request.peer.interactions, 'none')
    assert.deepEqual(await inputSeen.promise, [
      { type: 'write', sequence: 1, data: 'echo hi\r' },
      { type: 'resize', sequence: 2, cols: 100, rows: 30 },
    ])
    assert.deepEqual(frames, [
      { type: 'snapshot', sequence: 7, screen: 'ready', info: { ...info, controllerId: 'attachment-1' } },
      { type: 'state', info: { ...info, title: 'Renamed', controllerId: 'attachment-1' } },
      { type: 'output', sequence: 8, data: 'hello' },
      { type: 'state', info: { ...info, title: 'Read only' } },
    ])
  })

  it('detects the API exposed by the installed terminal-controller package', async () => {
    const { TerminalController } = await import('@deepseek-ai/dsh-api-terminal-controller')
    const installed = Object.create(TerminalController.prototype) as object
    assert.doesNotThrow(() => adaptTerminalController(installed, context))
  })

  it('rejects a controller exposing neither upstream terminal API', () => {
    assert.throws(
      () => adaptTerminalController({}, context),
      /neither follow\/write\/resize.*nor attach/,
    )
  })
})
