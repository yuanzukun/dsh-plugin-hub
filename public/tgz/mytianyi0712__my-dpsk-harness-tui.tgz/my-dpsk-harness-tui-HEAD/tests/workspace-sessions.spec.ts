import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import {
  backfillWorkspace,
  groupSession,
  workspaceFor,
  type GroupableSession,
  type GroupingWorkspace,
} from '../src/workspace-sessions.ts'
import { SessionId, type GroupingRegistry } from '../src/dsh-host/index.ts'

const CWD = process.cwd()

/** In-memory stand-in for the registry's entity; `attachSession` prepends. */
class FakeWorkspace implements GroupingWorkspace {
  sessionIds: SessionId[]
  readonly attached: string[] = []

  constructor(readonly path: string, sessionIds: readonly string[] = []) {
    this.sessionIds = sessionIds.map(id => SessionId(id))
  }

  async attachSession(sessionId: SessionId): Promise<void> {
    this.attached.push(String(sessionId))
    this.sessionIds = [sessionId, ...this.sessionIds]
  }
}

/** In-memory stand-in for `ctx.workspaceRegistry`. */
class FakeRegistry implements GroupingRegistry {
  archivedSessionIds: readonly SessionId[] = []
  readonly rows: FakeWorkspace[]
  readonly created: string[] = []
  readonly missing = new Set<string>()

  constructor(rows: FakeWorkspace[] = []) {
    this.rows = rows
  }

  async resolveByPath(path: string): Promise<GroupingWorkspace | undefined> {
    if (this.missing.has(path)) throw new Error(`ENOENT: no such file or directory, realpath '${path}'`)
    return this.rows.find(row => row.path === path)
  }

  async create(path: string): Promise<GroupingWorkspace> {
    if (this.missing.has(path)) throw new Error(`ENOENT: no such file or directory, '${path}'`)
    this.created.push(path)
    const row = new FakeWorkspace(path)
    this.rows.push(row)
    return row
  }
}

function session(id: string, cwd: string | undefined, extra: Partial<GroupableSession> = {}): GroupableSession {
  return { id, cwd, createdAt: 1, ...extra }
}

describe('workspace lookup', () => {
  it('reuses the workspace already owning the directory', async () => {
    const existing = new FakeWorkspace(CWD)
    const registry = new FakeRegistry([existing])
    assert.equal(await workspaceFor(registry, CWD, true), existing)
    assert.deepEqual(registry.created, [])
  })

  it('registers an unowned directory only when creation is allowed', async () => {
    const registry = new FakeRegistry()
    assert.equal(await workspaceFor(registry, CWD, false), undefined)
    assert.deepEqual(registry.created, [])

    const created = await workspaceFor(registry, CWD, true)
    assert.equal(created?.path, CWD)
    assert.deepEqual(registry.created, [CWD])
  })

  it('treats an unresolvable directory as unowned instead of throwing', async () => {
    const registry = new FakeRegistry()
    registry.missing.add(CWD)
    assert.equal(await workspaceFor(registry, CWD, true), undefined)
    assert.deepEqual(registry.created, [])
  })
})

describe('session grouping', () => {
  it('skips a session that records no directory', async () => {
    const registry = new FakeRegistry([new FakeWorkspace(CWD)])
    assert.equal(await groupSession(registry, session('tui-1', undefined), { create: true }), 'unrecorded')
    assert.equal(await groupSession(registry, session('tui-2', ''), { create: true }), 'unrecorded')
  })

  it('attaches an unaccounted session to the workspace of its cwd', async () => {
    const workspace = new FakeWorkspace(CWD)
    const registry = new FakeRegistry([workspace])
    assert.equal(await groupSession(registry, session('tui-1', CWD), { create: true }), 'attached')
    assert.deepEqual(workspace.attached, ['tui-1'])
    assert.deepEqual(workspace.sessionIds.map(String), ['tui-1'])
  })

  it('reports an already accounted session without writing', async () => {
    const workspace = new FakeWorkspace(CWD, ['tui-1'])
    const registry = new FakeRegistry([workspace])
    assert.equal(await groupSession(registry, session('tui-1', CWD), { create: true }), 'present')
    assert.deepEqual(workspace.attached, [])
  })

  it('leaves a session ungrouped when its directory has no workspace and creation is barred', async () => {
    const registry = new FakeRegistry()
    assert.equal(await groupSession(registry, session('sub-1', CWD), { create: false }), 'unresolved')
    assert.deepEqual(registry.created, [])
  })
})

describe('history backfill', () => {
  it('attaches earlier sessions of the same directory, newest last', async () => {
    const workspace = new FakeWorkspace(CWD)
    const registry = new FakeRegistry([workspace])
    const attached = await backfillWorkspace(workspace, [
      session('new', CWD, { createdAt: 30 }),
      session('old', CWD, { createdAt: 10 }),
      session('middle', CWD, { createdAt: 20 }),
    ], [])
    assert.equal(attached, 3)
    assert.deepEqual(workspace.sessionIds.map(String), ['new', 'middle', 'old'])
  })

  it('skips other directories, subagents, archived sessions, and existing accounts', async () => {
    const workspace = new FakeWorkspace(CWD, ['accounted'])
    const attached = await backfillWorkspace(workspace, [
      session('accounted', CWD, { createdAt: 1 }),
      session('elsewhere', 'D:/definitely-not-this-project', { createdAt: 2 }),
      session('child', CWD, { createdAt: 3, origin: 'subagent' }),
      session('archived', CWD, { createdAt: 4 }),
      session('records', CWD, { createdAt: 5 }),
    ], ['archived'])
    assert.equal(attached, 1)
    assert.deepEqual(workspace.sessionIds.map(String), ['records', 'accounted'])
  })
})
