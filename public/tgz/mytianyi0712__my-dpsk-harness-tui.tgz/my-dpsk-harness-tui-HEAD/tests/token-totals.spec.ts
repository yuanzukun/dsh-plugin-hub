import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { EMPTY_USAGE_FOLD, foldUsageSample } from '../src/host/token-totals.ts'

describe('usage folding', () => {
  it('sums the disjoint buckets', () => {
    const once = foldUsageSample(EMPTY_USAGE_FOLD, {
      inputTokens: 100,
      outputTokens: 40,
      cacheReadTokens: 200,
      cacheWriteTokens: 10,
    })
    const twice = foldUsageSample(once, {
      inputTokens: 1,
      outputTokens: 2,
      cacheReadTokens: 3,
      cacheWriteTokens: 4,
    })
    assert.deepEqual(twice.totals, {
      inputTokens: 101,
      outputTokens: 42,
      cacheReadTokens: 203,
      cacheWriteTokens: 14,
    })
    assert.equal(twice.cacheReadObserved, true)
    assert.equal(twice.cacheBucketsComplete, true)
  })

  it('separates an observed cache read from all-sample completeness', () => {
    const complete = foldUsageSample(EMPTY_USAGE_FOLD, {
      inputTokens: 10,
      outputTokens: 5,
      cacheReadTokens: 90,
      cacheWriteTokens: 0,
    })
    assert.equal(complete.cacheBucketsComplete, true)
    // This call omitted the optional read bucket: completeness is now false, but the
    // explicit read already observed keeps the session-level reporting flag alive.
    const partial = foldUsageSample(complete, { inputTokens: 1, outputTokens: 1 })
    assert.equal(partial.cacheBucketsComplete, false)
    assert.equal(partial.cacheReadObserved, true)
    assert.equal(partial.cacheReadComplete, false)
    // The counter still folds the sample it did see, so token totals stay honest.
    assert.deepEqual(partial.totals, {
      inputTokens: 11,
      outputTokens: 6,
      cacheReadTokens: 90,
      cacheWriteTokens: 0,
    })
    // Completeness never comes back: the earlier unknown bucket cannot be recovered.
    const later = foldUsageSample(partial, {
      inputTokens: 1,
      outputTokens: 1,
      cacheReadTokens: 1,
      cacheWriteTokens: 1,
    })
    assert.equal(later.cacheBucketsComplete, false)
  })

  it('keeps read-hit reporting available when only the write bucket is missing', () => {
    const readOnly = foldUsageSample(EMPTY_USAGE_FOLD, {
      inputTokens: 10,
      outputTokens: 5,
      cacheReadTokens: 90,
    })
    assert.equal(readOnly.cacheReadObserved, true)
    assert.equal(readOnly.cacheReadComplete, true)
    assert.equal(readOnly.cacheWriteComplete, false)
    assert.equal(readOnly.cacheBucketsComplete, false)
  })

  it('treats a real zero in both buckets as complete', () => {
    const fold = foldUsageSample(EMPTY_USAGE_FOLD, {
      inputTokens: 5,
      outputTokens: 5,
      cacheReadTokens: 0,
      cacheWriteTokens: 0,
    })
    assert.equal(fold.cacheReadObserved, true)
    assert.equal(fold.cacheBucketsComplete, true)
  })

  it('keeps reads unobserved when every sample omits the optional bucket', () => {
    const fold = foldUsageSample(EMPTY_USAGE_FOLD, { inputTokens: 5, outputTokens: 5 })
    assert.equal(fold.cacheReadObserved, false)
    assert.equal(fold.cacheReadComplete, false)
  })
})
