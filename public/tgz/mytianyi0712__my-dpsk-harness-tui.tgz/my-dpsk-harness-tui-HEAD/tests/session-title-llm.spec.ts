import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import {
  createSessionTitleProviderRunner,
  type SessionTitleLlmConfig,
  type TitleLlmModuleRuntime,
} from '../src/dsh-host/session-title-llm.ts'
import type { Context } from '../src/dsh-host/framework.ts'
import type { SessionSeq } from '../src/dsh-host/session.ts'
import type {
  SessionTitleProviderRequest,
  SessionTitleUserMessage,
} from '@deepseek-ai/dsh-session-title'

const config: SessionTitleLlmConfig = {
  targetWords: 6,
  targetCjkCharacters: 12,
  maxInputBytes: 4096,
  maxOutputTokens: 64,
  timeoutMs: 60_000,
  provider: 'configured-provider',
  model: 'configured-model',
}

const ctx = {} as Context
const request = {} as SessionTitleProviderRequest
const messages = [
  { seq: 1 as unknown as SessionSeq, text: 'Build a session-title compatibility test' },
] as const satisfies readonly SessionTitleUserMessage[]

const model = { provider: 'title-provider', model: 'title-model' }

describe('session-title LLM compatibility runner', () => {
  it('uses the 0.2.0 generator with the complete provider config', async () => {
    const calls: unknown[][] = []
    const api: TitleLlmModuleRuntime = {
      resolveSessionTitleLlmConfig(input) {
        assert.deepEqual(input, config)
        return { ...config, provider: 'resolved-provider', model: 'resolved-model' }
      },
      async generateSessionTitleWithLlm(...args) {
        calls.push(args)
        return { title: 'Legacy title', messageSeqs: [messages[0].seq], model }
      },
    }

    const runner = createSessionTitleProviderRunner(config, 'test-provider', api)
    const result = await runner.generate(ctx, request, messages)

    assert.equal(runner.mode, 'legacy')
    assert.deepEqual(result, { title: 'Legacy title', messageSeqs: [messages[0].seq], model })
    assert.equal(calls.length, 1)
    assert.equal(calls[0]?.[0], ctx)
    assert.deepEqual(calls[0]?.[1], { ...config, provider: 'resolved-provider', model: 'resolved-model' })
    assert.equal(calls[0]?.[2], request)
    assert.equal(calls[0]?.[3], messages)
    assert.equal(calls[0]?.[4], 'test-provider')
  })

  it('uses the 0.2.1 executor with prepared prompt, message seqs, and output parsing', async () => {
    const calls: unknown[][] = []
    const api: TitleLlmModuleRuntime = {
      resolveSessionTitleLlmConfig(input) {
        assert.equal('targetWords' in input, false)
        assert.equal('targetCjkCharacters' in input, false)
        assert.deepEqual(input, {
          maxInputBytes: 4096,
          maxOutputTokens: 64,
          timeoutMs: 60_000,
          provider: 'configured-provider',
          model: 'configured-model',
        })
        return { ...input, maxOutputTokens: 96 }
      },
      async executeSessionTitleLlm(...args) {
        calls.push(args)
        return {
          blocks: [{ type: 'text', text: '**Compatibility title**\nignored explanation' }],
          finish: { kind: 'stop' },
          model,
        }
      },
    }

    const runner = createSessionTitleProviderRunner(config, 'test-provider', api)
    const result = await runner.generate(ctx, request, messages)

    assert.equal(runner.mode, 'prepared')
    assert.deepEqual(result, { title: 'Compatibility title', messageSeqs: [messages[0].seq], model })
    assert.equal(calls.length, 1)
    assert.equal(calls[0]?.[0], ctx)
    assert.deepEqual(calls[0]?.[1], {
      maxInputBytes: 4096,
      maxOutputTokens: 96,
      timeoutMs: 60_000,
      provider: 'configured-provider',
      model: 'configured-model',
    })
    assert.equal(calls[0]?.[2], request)
    assert.equal(calls[0]?.[3], 'test-provider')

    const prepared = calls[0]?.[4] as {
      system: string
      input: string
      messageSeqs: readonly SessionSeq[]
      selectReasoningEffort: (candidate: unknown) => string | undefined
    }
    assert.match(prepared.system, /Aim for about 6 words/)
    assert.match(prepared.system, /12 CJK characters/)
    assert.match(prepared.input, /Build a session-title compatibility test/)
    assert.deepEqual(prepared.messageSeqs, [messages[0].seq])
    assert.equal(
      prepared.selectReasoningEffort({ reasoning: { efforts: [{ id: 'low' }, { id: 'high' }] } }),
      'low',
    )
    assert.equal(prepared.selectReasoningEffort({}), undefined)
  })

  it('rejects prepared executor outcomes the provider cannot accept as titles', async () => {
    const api: TitleLlmModuleRuntime = {
      async executeSessionTitleLlm() {
        return {
          blocks: [{ type: 'tool-call' }],
          finish: { kind: 'tool-calls' },
          model,
        }
      },
    }
    const runner = createSessionTitleProviderRunner(config, 'test-provider', api)
    await assert.rejects(
      runner.generate(ctx, request, messages),
      /title output must contain text only/,
    )

    const empty: TitleLlmModuleRuntime = {
      async executeSessionTitleLlm() {
        return {
          blocks: [{ type: 'text', text: '   ' }],
          finish: { kind: 'stop' },
          model,
        }
      },
    }
    await assert.rejects(
      createSessionTitleProviderRunner(config, 'test-provider', empty).generate(ctx, request, messages),
      /title model produced no text/,
    )
  })

  it('selects the API exported by the installed package at runtime', async () => {
    const installed = await import('@deepseek-ai/dsh-session-title-llm')
    const expected = typeof installed.executeSessionTitleLlm === 'function' ? 'prepared' : 'legacy'
    const runner = createSessionTitleProviderRunner(config, 'test-provider')
    assert.equal(runner.mode, expected)
  })

  it('rejects an unsupported upstream package instead of failing at import time', () => {
    assert.throws(
      () => createSessionTitleProviderRunner(config, 'test-provider', {}),
      /exports neither generateSessionTitleWithLlm.*nor executeSessionTitleLlm/,
    )
  })
})
