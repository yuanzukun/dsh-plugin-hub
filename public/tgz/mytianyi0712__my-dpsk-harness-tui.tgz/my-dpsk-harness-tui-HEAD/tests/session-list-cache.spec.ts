import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { parseSessionListCache, readSessionListCache, writeSessionListCache } from '../src/session-list-cache.ts'

describe('session-list cache', () => {
  it('keeps presentation fields and drops malformed rows', () => {
    const rows = parseSessionListCache(JSON.stringify({
      sessions: [
        { id: 's1', title: 'work', createdAt: 10, lastActivityAt: 20, workspace: 'D:/p', status: 'running', attention: true, blank: false },
        { id: 's2', title: 'blank', createdAt: 11, blank: true },
        { id: '', title: 'bad', createdAt: 12 },
        { id: 's3', title: 'bad-time', createdAt: 'x' },
      ],
    }))
    assert.deepEqual(rows, [
      { id: 's1', title: 'work', active: false, workspace: 'D:/p', createdAt: 10, lastActivityAt: 20, status: 'idle', attention: false },
      { id: 's2', title: 'blank', active: false, createdAt: 11, status: 'idle', attention: false, blank: true },
    ])
  })

  it('returns an empty list for missing or malformed files', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dpsk-session-cache-'))
    try {
      assert.deepEqual(readSessionListCache(join(root, 'missing.json')), [])
      assert.deepEqual(parseSessionListCache('not json'), [])
      assert.deepEqual(parseSessionListCache('{"sessions":{}}'), [])
    } finally {
      await rm(root, { recursive: true, force: true })
    }
  })

  it('round-trips the cached rows', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dpsk-session-cache-'))
    const file = join(root, 'nested', 'sessions.json')
    try {
      const rows = [{ id: 's1', title: 'work', active: false as const, createdAt: 10, status: 'idle' as const, attention: false }]
      await writeSessionListCache(file, rows)
      assert.deepEqual(readSessionListCache(file), rows)
      assert.equal(JSON.parse(await readFile(file, 'utf8')).version, 1)
    } finally {
      await rm(root, { recursive: true, force: true })
    }
  })
})
