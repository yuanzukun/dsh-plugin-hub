import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { FIRST_PROMPT_LABEL_CHARS, singleLine, userMessageText } from '../src/session-label.ts'
import type { SessionEvent } from '../src/dsh-host/index.ts'

function userMessage(parts: readonly { type: string; text?: string }[]): SessionEvent {
  return {
    type: 'user/message',
    seq: 0,
    time: 0,
    data: { message: { id: 'm1', role: 'user', content: parts } },
  } as unknown as SessionEvent
}

describe('session labels', () => {
  it('collapses a multi-line prompt into one row', () => {
    assert.equal(singleLine('  first line\n\n second\tline  '), 'first line second line')
  })

  it('reads the text parts of the opening user message', () => {
    assert.equal(userMessageText(userMessage([{ type: 'text', text: 'fix the bug' }])), 'fix the bug')
    assert.equal(
      userMessageText(userMessage([{ type: 'text', text: 'one' }, { type: 'file', text: 'ignored' }, { type: 'text', text: 'two' }])),
      'one two',
    )
  })

  it('ignores anything that is not a user message with text', () => {
    const assistant = { type: 'assistant/message', seq: 1, time: 0, data: { message: { content: [{ type: 'text', text: 'hi' }] } } } as unknown as SessionEvent
    assert.equal(userMessageText(assistant), undefined)
    assert.equal(userMessageText(userMessage([])), undefined)
    assert.equal(userMessageText(userMessage([{ type: 'image' }])), undefined)
    assert.equal(userMessageText(userMessage([{ type: 'text', text: '   ' }])), undefined)
  })

  it('cuts a long prompt to the label bound', () => {
    const long = 'x'.repeat(FIRST_PROMPT_LABEL_CHARS * 2)
    const label = userMessageText(userMessage([{ type: 'text', text: long }]))
    assert.equal(label?.length, FIRST_PROMPT_LABEL_CHARS)
    assert.ok(label?.endsWith('…'))
  })
})
