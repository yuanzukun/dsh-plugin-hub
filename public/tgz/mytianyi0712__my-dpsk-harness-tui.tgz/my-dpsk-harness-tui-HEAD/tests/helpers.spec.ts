import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { contentText, parseArguments } from '../src/components/content.ts'
import { displayInlineText, displayText } from '../src/components/text.ts'


describe('contentText', () => {
  it('joins text and reasoning blocks, skipping other block types', () => {
    const text = contentText([
      { type: 'reasoning', text: 'think' },
      { type: 'text', text: 'answer' },
      { type: 'image', attachment: {} as never },
    ])
    assert.equal(text, 'think\n\nanswer')
  })
})

describe('parseArguments', () => {
  it('accepts valid JSON and rejects malformed input', () => {
    assert.deepEqual(parseArguments('{"a":1}'), { valid: true, value: { a: 1 } })
    assert.deepEqual(parseArguments(''), { valid: true, value: {} })
    assert.deepEqual(parseArguments('nope'), { valid: false, raw: 'nope' })
  })
})

describe('text sanitizers', () => {
  it('strips control characters and collapses newlines inline', () => {
    assert.equal(displayText('a\u0007b'), 'ab')
    assert.equal(displayText('a\rb'), 'a\nb')
    assert.equal(displayInlineText('a\r\nb'), 'a b')
  })
})
