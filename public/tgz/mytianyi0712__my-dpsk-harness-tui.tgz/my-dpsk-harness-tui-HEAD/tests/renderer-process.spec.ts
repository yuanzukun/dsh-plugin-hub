import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  TERMINAL_RESTORE,
  defaultHostView,
  platformKey,
  rendererCacheDir,
  rendererArtifactName,
  rendererExecutable,
  resolveRendererPath,
  spawnRenderer,
} from '../src/host/renderer-process.ts'
import { routeStdoutToLog, tuiLogPath } from '../src/host/renderer-log.ts'
import { RENDERER_PROTOCOL_VERSION } from '../src/ipc/envelope.ts'
import { emit, fakeChild, helloEnvelope } from './helpers/fake-child.ts'

const hostView = defaultHostView('my-dpsk-harness-tui', '0.5.0', true)

describe('renderer path resolution', () => {
  it('builds the platform key from platform and arch', () => {
    assert.equal(platformKey('win32', 'x64'), 'win32-x64')
    assert.equal(platformKey('linux', 'arm64'), 'linux-arm64')
  })

  it('adds the executable suffix only on Windows', () => {
    assert.equal(rendererExecutable('win32'), '.exe')
    assert.equal(rendererExecutable('linux'), '')
    assert.equal(rendererExecutable('darwin'), '')
  })

  it('caches the renderer under the version and platform', () => {
    const dir = rendererCacheDir('0.5.0', 'win32-x64')
    assert.ok(dir.endsWith(join('.dsh', 'dpsk', 'renderer', '0.5.0-win32-x64')))
  })

  it('names the artifact the way the launcher downloads it', () => {
    assert.equal(rendererArtifactName('win32-x64'), 'dpsk-renderer-win32-x64.exe')
    assert.equal(rendererArtifactName('win32-arm64'), 'dpsk-renderer-win32-arm64.exe')
    assert.equal(rendererArtifactName('linux-x64'), 'dpsk-renderer-linux-x64')
    assert.equal(rendererArtifactName('darwin-arm64'), 'dpsk-renderer-darwin-arm64')
  })

  it('finds the cached artifact under the launcher name', () => {
    delete process.env.DSH_RENDERER_PATH
    const home = mkdtempSync(join(tmpdir(), 'dsh-home-'))
    const key = platformKey()
    const dir = join(home, '.dsh', 'dpsk', 'renderer', `0.5.0-${key}`)
    mkdirSync(dir, { recursive: true })
    const binary = join(dir, rendererArtifactName(key))
    writeFileSync(binary, 'stub')
    const root = join(tmpdir(), 'dsh-no-package-root-')
    assert.equal(resolveRendererPath('0.5.0', root, home), binary)
    rmSync(home, { recursive: true, force: true })
  })

  it('prefers DSH_RENDERER_PATH when the file exists', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dpsk-renderer-'))
    const binary = join(dir, 'dpsk-renderer.exe')
    writeFileSync(binary, 'stub')
    process.env.DSH_RENDERER_PATH = binary
    assert.equal(resolveRendererPath('0.5.0', dir), binary)
    delete process.env.DSH_RENDERER_PATH
    rmSync(dir, { recursive: true, force: true })
  })

  it('finds a development build next to the package root', () => {
    delete process.env.DSH_RENDERER_PATH
    const home = mkdtempSync(join(tmpdir(), 'dsh-empty-home-'))
    const root = mkdtempSync(join(tmpdir(), 'dpsk-root-'))
    const key = platformKey()
    const dist = join(root, 'renderer', 'dist')
    mkdirSync(dist, { recursive: true })
    const binary = join(dist, rendererArtifactName(key))
    writeFileSync(binary, 'stub')
    assert.equal(resolveRendererPath('0.5.0', root, home), binary)
    rmSync(root, { recursive: true, force: true })
    rmSync(home, { recursive: true, force: true })
  })

  it('reports no renderer when nothing exists', () => {
    delete process.env.DSH_RENDERER_PATH
    process.env.DSH_RENDERER_PATH = join(tmpdir(), 'dpsk-definitely-not-here')
    const home = mkdtempSync(join(tmpdir(), 'dsh-empty-home-'))
    assert.equal(resolveRendererPath('0.5.0', join(tmpdir(), 'dpsk-empty-root-'), home), undefined)
    delete process.env.DSH_RENDERER_PATH
    rmSync(home, { recursive: true, force: true })
  })
})

describe('terminal restore sequence', () => {
  it('leaves the alternate screen, disables mouse tracking, shows the cursor, resets SGR', () => {
    assert.ok(TERMINAL_RESTORE.includes('[?1049l'))
    assert.ok(TERMINAL_RESTORE.includes('[?1000l'))
    assert.ok(TERMINAL_RESTORE.includes('[?1006l'))
    assert.ok(TERMINAL_RESTORE.includes('[?25h'))
    assert.ok(TERMINAL_RESTORE.includes('[0m'))
    // Clearing after leaving the alternate screen would wipe the shell's scrollback
    // instead of the TUI frame, so the clear comes first.
    assert.ok(TERMINAL_RESTORE.includes('[2J'))
    assert.ok(TERMINAL_RESTORE.indexOf('[2J') < TERMINAL_RESTORE.indexOf('[?1049l'))
    // Every mouse mode OpenTUI can enable, not just the click and SGR ones.
    assert.ok(TERMINAL_RESTORE.includes('[?1002l'))
    assert.ok(TERMINAL_RESTORE.includes('[?1003l'))
    assert.ok(TERMINAL_RESTORE.includes('[?2004l'))
  })

  it('declares the host capabilities and the required renderer capabilities', () => {
    const view = defaultHostView('my-dpsk-harness-tui', '0.5.0', true)
    assert.deepEqual(view.capabilities, [
      'session-events',
      'model-catalog',
      'provider-catalog',
      'permission-presets',
      'agent-presets',
      'settings-write',
      'wechat-bridge',
      'doctor',
      'i18n',
      'subagents',
      'skills',
      'interjection',
      'terminal-size',
    ])
    assert.deepEqual(view.requiredCapabilities, ['transcript', 'composer'])
    assert.equal(view.terminalAuthorized, true)
    assert.equal(defaultHostView('h', '1', false).terminalAuthorized, false)
  })
})

describe('spawnRenderer handshake', () => {
  it('answers the hello with a compatible ack and reports it', () => {
    const { child, state } = fakeChild()
    const writes: string[] = []
    const acks: Array<{ status: string }> = []
    const handle = spawnRenderer('renderer.bin', {
      hostView,
      write: text => writes.push(text),
      spawn: () => child,
      onAck: negotiation => acks.push({ status: negotiation.status }),
    })
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    assert.equal(acks[0]?.status, 'compatible')
    const ack = JSON.parse(state.sent[0] ?? '{}') as { kind: string; payload: { status: string; hostId: string } }
    assert.equal(ack.kind, 'hello-ack')
    assert.equal(ack.payload.status, 'compatible')
    assert.equal(ack.payload.hostId, 'my-dpsk-harness-tui')
    handle.send('session-snapshot', { sessionId: 's', title: 't', events: [] })
    assert.ok(state.sent[1]?.includes('session-snapshot'))
  })

  it('rejects a renderer that lacks a required capability', () => {
    const { child, state } = fakeChild()
    const acks: Array<{ status: string; reasons: string[] }> = []
    spawnRenderer('renderer.bin', {
      hostView,
      spawn: () => child,
      write: () => undefined,
      onAck: negotiation => acks.push({ status: negotiation.status, reasons: negotiation.reasons }),
    })
    const weak = {
      protocolVersion: RENDERER_PROTOCOL_VERSION,
      seq: 0,
      kind: 'hello',
      payload: {
        protocolVersion: RENDERER_PROTOCOL_VERSION,
        rendererId: 'dpsk-renderer',
        rendererVersion: '0.5.0',
        capabilities: ['transcript'],
        kinds: ['hello-ack', 'hello'],
      },
    }
    emit(state, 'message', JSON.stringify(weak))
    assert.equal(acks[0]?.status, 'rejected')
    const ack = JSON.parse(state.sent[0] ?? '{}') as { payload: { status: string; reasons: string[] } }
    assert.equal(ack.payload.status, 'rejected')
    assert.ok(ack.payload.reasons[0].includes('composer'))
  })

  it('waits for authorization when the terminal is not handed over', () => {
    const { child, state } = fakeChild()
    const acks: Array<{ status: string }> = []
    spawnRenderer('renderer.bin', {
      hostView: defaultHostView('my-dpsk-harness-tui', '0.5.0', false),
      spawn: () => child,
      write: () => undefined,
      onAck: negotiation => acks.push({ status: negotiation.status }),
    })
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    assert.equal(acks[0]?.status, 'waiting_authorization')
    const ack = JSON.parse(state.sent[0] ?? '{}') as { payload: { status: string } }
    assert.equal(ack.payload.status, 'waiting_authorization')
  })

  it('forwards upstream envelopes to the host callback', () => {
    const { child, state } = fakeChild()
    const upstream: string[] = []
    spawnRenderer('renderer.bin', {
      hostView,
      spawn: () => child,
      write: () => undefined,
      onEnvelope: envelope => upstream.push(envelope.kind),
    })
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'message', JSON.stringify({ protocolVersion: 2, seq: 1, kind: 'send-message', payload: { text: '/help' } }))
    assert.deepEqual(upstream, ['send-message'])
  })

  it('writes the restore sequence and a crash report on abnormal exit', () => {
    const { child, state } = fakeChild()
    const writes: string[] = []
    const exits: Array<{ code: number | null; signal: string | null; abnormal: boolean }> = []
    spawnRenderer('renderer.bin', {
      hostView,
      spawn: () => child,
      write: text => writes.push(text),
      onExit: (code, signal, abnormal) => exits.push({ code, signal, abnormal }),
    })
    emit(state, 'exit', 1, null)
    assert.equal(exits[0]?.abnormal, true)
    assert.ok(writes.includes(TERMINAL_RESTORE))
    assert.ok(writes.some(entry => entry.includes('exited abnormally')))
  })

  it('does not restore the terminal on a clean exit', () => {
    const { child, state } = fakeChild()
    const writes: string[] = []
    spawnRenderer('renderer.bin', {
      hostView,
      spawn: () => child,
      write: text => writes.push(text),
    })
    emit(state, 'exit', 0, null)
    assert.ok(!writes.includes(TERMINAL_RESTORE))
    assert.equal(writes.length, 0)
  })

  it('kills the renderer and restores the terminal on stop', () => {
    const { child, state } = fakeChild()
    const writes: string[] = []
    const handle = spawnRenderer('renderer.bin', {
      hostView,
      spawn: () => child,
      write: text => writes.push(text),
    })
    handle.stop()
    assert.equal(state.kills, 1)
    assert.ok(writes.includes(TERMINAL_RESTORE))
    handle.bye()
    assert.ok(state.sent.some(line => line.includes('"bye"')))
  })

  it('kills the renderer and restores the terminal when it closes its own channel', async () => {
    const { child, state } = fakeChild()
    const writes: string[] = []
    spawnRenderer('renderer.bin', {
      hostView,
      spawn: () => child,
      write: text => writes.push(text),
    })
    // A renderer that closes its own IPC channel does not exit: `exit` never fires and
    // the process keeps painting. `disconnect` is the signal. It owns the terminal and
    // can no longer hear the host, so it is killed and the terminal is put back. The
    // kill is scheduled, so the assertion waits for it.
    emit(state, 'disconnect')
    await new Promise(resolve => setTimeout(resolve, 300))
    assert.equal(state.kills, 1)
    assert.ok(writes.includes(TERMINAL_RESTORE))
    assert.ok(writes.some(entry => entry.includes('IPC channel closed by the renderer')))
  })

  it('does not kill the renderer on disconnect after it exited', async () => {
    const { child, state } = fakeChild()
    const writes: string[] = []
    spawnRenderer('renderer.bin', {
      hostView,
      spawn: () => child,
      write: text => writes.push(text),
    })
    emit(state, 'exit', 0, null)
    emit(state, 'disconnect')
    await new Promise(resolve => setTimeout(resolve, 300))
    assert.equal(state.kills, 0)
    assert.ok(!writes.includes(TERMINAL_RESTORE))
  })

  it('a stop the host asked for is not reported as an abnormal exit', () => {
    const { child, state } = fakeChild()
    const writes: string[] = []
    const exits: Array<{ abnormal: boolean }> = []
    const handle = spawnRenderer('renderer.bin', {
      hostView,
      spawn: () => child,
      write: text => writes.push(text),
      onExit: (_code, _signal, abnormal) => exits.push({ abnormal }),
    })
    handle.stop()
    // The kill lands as SIGTERM; without the `stopping` flag the exit handler would call
    // it a crash and print a crash report for an orderly quit.
    emit(state, 'exit', null, 'SIGTERM')
    assert.deepEqual(exits, [{ abnormal: false }])
    assert.ok(!writes.some(entry => entry.includes('exited abnormally')))
  })

  it('bye on a closed channel reports the reason and does not throw', () => {
    const { child, state } = fakeChild()
    const writes: string[] = []
    const handle = spawnRenderer('renderer.bin', {
      hostView,
      spawn: () => child,
      write: text => writes.push(text),
    })
    const closed = child as unknown as { send: (message: string) => void }
    closed.send = () => {
      const error = new Error('Channel closed') as Error & { code?: string }
      error.code = 'ERR_IPC_CHANNEL_CLOSED'
      throw error
    }
    handle.bye()
    assert.ok(writes.some(entry => entry.includes('ERR_IPC_CHANNEL_CLOSED')))
  })
})

describe('routeStdoutToLog', () => {
  it('appends stdout to the log file and reports one info line per write', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dpsk-log-'))
    const logPath = join(dir, 'tui-4242.log')
    const lines: Array<{ level: string; text: string }> = []
    const restore = routeStdoutToLog(logPath, (level, text) => lines.push({ level, text }))
    process.stdout.write('hello from dsh\n')
    process.stderr.write('a warning\n')
    restore()
    const logged = readFileSync(logPath, 'utf8')
    assert.ok(logged.includes('hello from dsh'))
    assert.ok(logged.includes('a warning'))
    assert.deepEqual(lines, [{ level: 'info', text: 'hello from dsh' }, { level: 'warn', text: 'a warning' }])
    rmSync(dir, { recursive: true, force: true })
  })

  it('puts the original write functions back on restore', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dpsk-log-'))
    const original = process.stdout.write
    const restore = routeStdoutToLog(join(dir, 'tui.log'), () => undefined)
    assert.notEqual(process.stdout.write, original)
    restore()
    assert.equal(process.stdout.write, original)
    rmSync(dir, { recursive: true, force: true })
  })

  it('names the log file after the process id under DSH_HOME/logs', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-home-'))
    process.env.DSH_HOME = dir
    const path = tuiLogPath(1234)
    assert.equal(path, join(dir, 'logs', 'tui-1234.log'))
    delete process.env.DSH_HOME
    rmSync(dir, { recursive: true, force: true })
  })
})

describe('renderer spawn failure', () => {
  it('reports a child that cannot start instead of waiting for a handshake', () => {
    const write: string[] = []
    const exits: Array<{ code: number | null; signal: string | null; abnormal: boolean }> = []
    const { child, state } = fakeChild()
    const handle = spawnRenderer('C:/missing/renderer.exe', {
      hostView: defaultHostView('host', '0.5.0', true),
      write: text => write.push(text),
      spawn: () => child,
      onExit: (code, signal, abnormal) => exits.push({ code, signal, abnormal }),
    })
    assert.ok(handle !== undefined)
    // A spawn error is a terminal outcome: the host reports it and stops waiting.
    emit(state, 'error', Object.assign(new Error('spawn C:/missing/renderer.exe ENOENT'), { code: 'ENOENT' }))
    assert.equal(exits.length, 1)
    assert.equal(exits[0]?.abnormal, true)
    assert.ok(write.some(line => line.includes('could not start the renderer')))
    // A late `exit` for the same child does not report a second outcome.
    emit(state, 'exit', null, null)
    assert.equal(exits.length, 1)
  })
})

describe('IPC disconnect', () => {
  it('kills a renderer whose channel closed while it was alive and restores once', async () => {
    const write: string[] = []
    const exits: boolean[] = []
    const { child, state } = fakeChild()
    spawnRenderer('renderer.exe', {
      hostView,
      write: text => write.push(text),
      spawn: () => child,
      onExit: (_code, _signal, abnormal) => exits.push(abnormal),
    })
    emit(state, 'message', JSON.stringify(helloEnvelope()))
    emit(state, 'disconnect')
    await new Promise(resolve => setTimeout(resolve, 260))
    assert.equal(state.kills, 1)
    assert.ok(write.some(text => text.includes('\x1b[?1049l')))
    assert.ok(write.some(text => text.includes('IPC channel closed')))
    // A real exit after the kill is the one outcome, and it is not double-reported.
    emit(state, 'exit', null, 'SIGTERM')
    assert.equal(exits.length, 1)
  })
})
