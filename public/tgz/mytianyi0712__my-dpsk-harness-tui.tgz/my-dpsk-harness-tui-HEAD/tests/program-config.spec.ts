import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  DEFAULT_PROGRAM_CONFIG,
  EMPTY_CUSTOM_PRICE_TABLE,
  ProgramConfigStore,
  ensureProgramConfigHome,
  parseProgramConfig,
  programConfigHome,
  programConfigPaths,
  writeJsonAtomic,
} from '../src/host/program-config.ts'
import { DEFAULT_PRICING_TABLE, findPricingModel } from '../src/host/pricing.ts'

async function fixture(): Promise<{ root: string; dsh: string; home: string }> {
  const root = await mkdtemp(join(tmpdir(), 'dpsk-program-config-'))
  return { root, dsh: join(root, 'dsh-home'), home: join(root, 'config-home') }
}

describe('program config', () => {
  it('uses ~/.config/.mydpsk unless an explicit home is provided', () => {
    assert.equal(programConfigHome({}, 'C:/Users/test'), join('C:/Users/test', '.config', '.mydpsk'))
    assert.equal(programConfigHome({ MYDPSK_CONFIG_HOME: 'C:/custom' }, 'C:/Users/test'), 'C:/custom')
  })

  it('seeds config, program price, empty custom price, and migrates the legacy backend choice', async () => {
    const f = await fixture()
    const paths = programConfigPaths({ DSH_HOME: f.dsh }, f.root)
    await mkdir(join(f.dsh, 'dpsk'), { recursive: true })
    await mkdir(paths.home, { recursive: true })
    await writeFile(join(f.dsh, 'dpsk', 'backend.json'), '{"command":"dsh"}\n', 'utf8')
    await writeFile(join(paths.home, 'pricing.json'), '{"legacy":true}\n', 'utf8')
    ensureProgramConfigHome(paths)
    assert.deepEqual(JSON.parse(await readFile(paths.config, 'utf8')), DEFAULT_PROGRAM_CONFIG)
    assert.deepEqual(JSON.parse(await readFile(paths.price, 'utf8')), DEFAULT_PRICING_TABLE)
    assert.deepEqual(JSON.parse(await readFile(paths.customPrice, 'utf8')), EMPTY_CUSTOM_PRICE_TABLE)
    assert.equal(await readFile(paths.backend, 'utf8'), '{"command":"dsh"}\n')
    assert.equal(existsSync(join(f.dsh, 'dpsk', 'backend.json')), true)
    assert.equal(existsSync(join(paths.home, 'pricing.json')), false)
    await rm(f.root, { recursive: true, force: true })
  })

  it('reloads a custom_price override without restarting dsh', async () => {
    const f = await fixture()
    const store = new ProgramConfigStore({ env: { DSH_HOME: f.dsh }, home: f.root })
    try {
      writeJsonAtomic(store.paths.customPrice, {
        version: 1,
        currency: 'USD',
        managedBy: 'user',
        editable: true,
        models: {
          'p/m': { provider: 'p', model: 'm', ratesPerMillion: { input: 7, output: 8 } },
        },
      })
      const result = store.reload()
      assert.equal(result.changed, true)
      assert.equal(store.customPrice().models['p/m']?.ratesPerMillion.input, 7)
      assert.equal(store.price().models['p/m']?.ratesPerMillion.input, 7)
      assert.equal(store.publicPrice().models['p/m'], undefined)
    } finally {
      store.close()
      await rm(f.root, { recursive: true, force: true })
    }
  })

  it('writes /price-style overrides to custom_price.json and gives them exact priority', async () => {
    const f = await fixture()
    const store = new ProgramConfigStore({ env: { DSH_HOME: f.dsh }, home: f.root })
    try {
      const source = store.publicPrice().models['deepseek-v4.1-flash']
      assert.ok(source !== undefined)
      const entry = store.setCustomPrice('cliproxy', 'deepseek-v4.1-flash', source)
      assert.equal(entry.provider, 'cliproxy')
      assert.equal(entry.model, 'deepseek-v4.1-flash')
      const persisted = JSON.parse(await readFile(store.paths.customPrice, 'utf8'))
      assert.equal(persisted.models['cliproxy/deepseek-v4.1-flash'].ratesPerMillion.input, source.ratesPerMillion.input)
      const matched = findPricingModel(store.price(), 'cliproxy', 'deepseek-v4.1-flash')
      assert.equal(matched?.basis, 'exact')
      assert.equal(matched?.key, 'cliproxy/deepseek-v4.1-flash')
    } finally {
      store.close()
      await rm(f.root, { recursive: true, force: true })
    }
  })

  it('keeps the last good snapshot when a reload is invalid', async () => {
    const f = await fixture()
    const store = new ProgramConfigStore({ env: { DSH_HOME: f.dsh }, home: f.root })
    try {
      const before = store.price()
      writeJsonAtomic(store.paths.customPrice, { version: 1, currency: 'CNY', models: {} })
      const result = store.reload()
      assert.equal(result.changed, false)
      assert.equal(store.price(), before)
      assert.ok(store.current().errors.some(error => error.includes('currency')))
      await writeFile(store.paths.config, '{"version":1,"priceFile":"../outside.json","hotReload":true}\n', 'utf8')
      assert.equal(store.reload().changed, false)
      assert.ok(store.current().errors.some(error => error.includes('inside the program config home')))
    } finally {
      store.close()
      await rm(f.root, { recursive: true, force: true })
    }
  })

  it('polls an external custom_price edit and reports it to listeners', async () => {
    const f = await fixture()
    const store = new ProgramConfigStore({ env: { DSH_HOME: f.dsh }, home: f.root, pollMs: 25 })
    try {
      let notified = 0
      store.onChange(() => { notified += 1 })
      writeJsonAtomic(store.paths.customPrice, {
        version: 1,
        currency: 'USD',
        managedBy: 'user',
        editable: true,
        models: { 'p/m': { provider: 'p', model: 'm', ratesPerMillion: { input: 2, output: 3 } } },
      })
      for (let i = 0; i < 20 && notified === 0; i++) await new Promise(resolve => setTimeout(resolve, 25))
      assert.equal(notified, 1)
      assert.equal(store.customPrice().models['p/m']?.ratesPerMillion.input, 2)
    } finally {
      store.close()
      await rm(f.root, { recursive: true, force: true })
    }
  })

  it('persists the last route and agent preset in the program config home', async () => {
    const f = await fixture()
    const store = new ProgramConfigStore({ env: { DSH_HOME: f.dsh }, home: f.root, pollMs: 0 })
    try {
      const saved = store.setLastSelection({ provider: 'cliproxy', model: 'deepseek-v4.1-flash', effort: 'max', preset: 'minimal' })
      assert.deepEqual(saved, { provider: 'cliproxy', model: 'deepseek-v4.1-flash', effort: 'max', preset: 'minimal' })
      const persisted = JSON.parse(await readFile(store.paths.config, 'utf8'))
      assert.deepEqual(persisted.lastSelection, saved)
      assert.equal(store.current().config.lastSelection?.preset, 'minimal')
      store.close()
      const reopened = new ProgramConfigStore({ env: { DSH_HOME: f.dsh }, home: f.root, pollMs: 0 })
      try {
        assert.deepEqual(reopened.current().config.lastSelection, saved)
      } finally {
        reopened.close()
      }
    } finally {
      store.close()
      await rm(f.root, { recursive: true, force: true })
    }
  })

  it('validates a saved selection without discarding a good config', () => {
    const parsed = parseProgramConfig({
      version: 1,
      priceFile: 'price.json',
      hotReload: true,
      lastSelection: { provider: 'p', model: 'm', effort: 'high', preset: 'standard' },
    })
    assert.deepEqual(parsed.config?.lastSelection, { provider: 'p', model: 'm', effort: 'high', preset: 'standard' })
    assert.ok(parseProgramConfig({
      version: 1,
      priceFile: 'price.json',
      hotReload: true,
      lastSelection: { provider: '', model: 'm' },
    }).errors.some(error => error.includes('lastSelection.provider')))
  })

  it('rejects config path traversal and accepts the legacy pricingFile key', () => {
    assert.ok(parseProgramConfig({ version: 1, priceFile: '../p.json', hotReload: true }).errors.length > 0)
    assert.ok(parseProgramConfig(null).errors.length > 0)
    assert.equal(parseProgramConfig({ version: 1, pricingFile: 'price.json', hotReload: true }).config?.priceFile, 'price.json')
  })
})
