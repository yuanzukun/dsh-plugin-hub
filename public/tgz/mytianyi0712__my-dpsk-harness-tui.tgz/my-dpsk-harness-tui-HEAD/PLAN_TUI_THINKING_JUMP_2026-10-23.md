# Compact thinking 回落与 Jump to latest 修复计划

> 日期：2026-10-23
> 状态：实施完成（自动门禁通过；实机待确认）
> 版本：保持 `0.5.0`
> 边界：只改 renderer；不改 host IPC、不改 dsh 上游、不发布、不打 tag、不 push。

## 1. 已确认的根因

### 1.1 新版 thinking 样式消失

真实 session：`C:\Users\mytianyi\.dsh\sessions\--C-Users-mytianyi--\tui-1189fdfc-44f5-4a78-b398-59ba398d23fc\session.v4.jsonl.zstd`。

- turn 2 step 1 的 assistant message 是 `reasoning + text + tool-call`：模型先写了一段可见正文，再发起 anysearch。
- `renderer/src/ui/thinking.ts` 的 `planThinking` 在遇到第一段 assistant text 后设置 `bodySeen = true`，并在同一 turn 内不再重置。
- 于是 step 2-8 的 reasoning/tool 行全部没有被绑定到 compact block，`Row` 回落成 classic `Thought` + 工具卡片。

截图中的 `Given the dates...` -> shell 卡片 -> batch_search -> `Thought: 7.6s` -> 后续 reasoning 正是这个形状。

配置没有丢失：`~/.dsh/profiles/tui/cordis.patch.yml:175` 仍是 `newDesigns: true`，host settings payload 也会发送 resolved 值。因此修复点不是设置或主题，而是 `planThinking` 的 turn 内分组边界。

### 1.2 跳到最新按钮

`renderer/src/app.tsx:3924-3928` 当前实现是一个插在 scrollbox 和 prompt stack 之间、占满一行的普通布局行，而且 `<text>` 没有鼠标事件。

问题有两个：

1. 它占用一整行，导致滚动时输入框向下移动。
2. box 没有 `flexDirection="row"`，`justifyContent` 只作用于纵向；text 没有 `onMouseUp` / `onMouseDown`，所以既不在右侧，也无法点击。

目标位置：输入框面板上方那一行空白，右边缘对齐输入框内容宽度；覆盖在 transcript 之上，不参与布局。

## 2. 设计

### 2.1 Compact thinking：每个思考阶段独立成块

去掉 turn 级永久 `bodySeen` 锁，改为：

- reasoning / tool 打开或延续当前 block；
- assistant text 若当前有 block，则作为该 block 的 body，关闭当前 block；
- 下一条 reasoning / tool 再打开新的 compact block；
- 只有 text、没有 reasoning/tool 的 assistant 行保持普通回答，不创建空 header；
- user / turn change / system row 仍关闭当前 block；
- body-only answer 后的 footer/error 不创建第二个 block。

这样截图对应的 turn 会产生：

1. step 1：`Thought ...` + 中间正文 preamble；
2. step 2-8：新的 `Thought ... | Used N Tools` compact block（reasoning + shell + anysearch 合并）；
3. step 9：最终回答前的 reasoning + 最终正文形成最后一个 compact block + answer。

不修改协议、不修改 host 折叠逻辑；只改变 renderer 的纯投影和对应的 block 渲染。

### 2.2 Jump to latest：绝对定位的输入框上方按钮

新增 `renderer/src/ui/jump-to-latest.tsx`（名称可最终微调）：

- `position="absolute"`，`height={1}`，`zIndex={50}`；
- `right={pad()}`：相对内容列右边缘，而不是终端边缘；侧栏/terminal dock 时不会跑到 pane 里；
- `bottom={popupAnchorRows()}`：占用 prompt panel 上方原本的一行空白，不新增布局行；
- `overflow="hidden"`、`selectable={false}`；
- 仅 `awayFromBottom() && !popupOpen() && !dialogOpen()` 时显示；
- `onMouseDown` 记录按压并阻止文本选择，`onMouseUp` 在左键且未拖动时调用 `jumpToLatest()`；
- hover 时使用 `background.raised.high` / 弱色背景形成可点击反馈，文案仍用 `text.action.secondary.base`。

布局锚点：

- 给 session 内容列加 `position="relative"`，让 jump button 和已有的 AutocompletePopup 都以内容列为坐标系；
- AutocompletePopup 的 left/width/bottom 现有语义不变，只增加一个 owner，防止 sidebar dock 后绝对定位漂移；
- jump button zIndex 低于 autocomplete，且 popupOpen 时隐藏，避免和补全面板抢命中。

删除 app.tsx 中原来的 in-flow `awayFromBottom` 行。

### 2.3 用户文本块与下一条正文的垂直间距

当前各行的顶部间距并不统一：

- `AssistantRow` 的正文有 `marginTop={1}`；
- `ToolRow`、`SystemRow` 也有 `marginTop={1}`；
- compact `ThinkingHeader` 和 classic `ReasoningRow` 没有 `marginTop`，所以 user 卡片之后会直接贴着 `Thinking` / `Thought`。

修复决策：

- 给 compact `ThinkingHeader` 和 classic `ReasoningRow` 外层统一加 `marginTop={1}`；
- 不在 `UserRow` 上加 `marginBottom`，避免 assistant 正文、tool、system 已有顶部间距时变成两行空白；
- 目标是所有 user 卡片到下一条内容都恰好保留一行空白，classic 与 compact 一致。


## 3. 实施步骤

| Step | 内容 | 验收 |
|---|---|---|
| J0 | 固化真实事件形状 fixture：preamble text -> tools -> reasoning -> final text | fixture 当前失败，修复后通过 |
| J1 | 修改 `planThinking` 的 block 边界，移除 turn 内 `bodySeen` 锁 | thinking unit tests 全绿；多个 block、bodyId、toolCount 正确 |
| J2 | 更新旧的 answer-first tools stay classic 测试为中间正文后开启新 compact block | 语义变更被显式锁定 |
| J3 | transcript frame 回归：preamble 后出现 compact header，classic `Thought:` 行不再混入 | 真实形状 frame 断言 |
| J4 | 新增 JumpToLatest 组件 + 内容列 relative + 删除旧布局行 | 位置/命中测试通过 |
| J5 | 鼠标命中测试：40/80/120 列、侧栏 dock、autocomplete 打开、底部不显示 | 点击后滚到最新，输入框不移动 |
| J6 | 统一 user 卡片后第一行的顶部间距：ThinkingHeader / ReasoningRow 加 marginTop | classic 与 compact frame 都恰好一行空白，assistant/tool 不双倍 |
| J7 | README / CHANGELOG / acceptance 更新 | 文档一致 |
| J8 | typecheck、renderer 全量、host check、build、SHA256SUMS、重装 | 自动门禁全绿 |

## 4. 测试矩阵

### 4.1 Thinking

- `assistant(reasoning+text)` -> `tool` -> `assistant(reasoning+text)`：两个 compact block；第二个从 tool 起头。
- `assistant(text)` only -> `tool`：tool 起一个新 block。
- 连续多个 tool / reasoning、无中间 text：仍只有一个 block（不因修复而碎片化）。
- `user`、`turn` change、`system` row 的 boundary 不回归。
- compact preview 的 tool count 与顺序、bodyId、关闭状态正确。
- 从 settings payload 收到 `newDesigns: true` 后，真实事件形状必须走 compact，而不是依赖 profile 的瞬时值。

### 4.2 Jump to latest

- 长 transcript 向上滚动：按钮出现在 prompt panel 正上方一行，右边缘与 prompt 内容右边缘对齐。
- 按钮出现前后 prompt panel 的 y 坐标不变（证明没有占布局行）。
- `mockMouse.click` 命中后：按钮消失、sticky 恢复、最新行可见。
- 40 / 80 / 120 列不溢出；168 列 docked sidebar 时按钮在内容列内，不进入 sidebar。
- 完成 popup 打开时按钮隐藏；dialog 打开时不抢焦点。
- 手动滚到底部后按钮自动消失。

### 4.3 User 卡片与后续内容的间距

- classic：user 卡片后接 `ReasoningRow`，卡片文本与 `Thought` header 之间恰好一行页面空白。
- compact：user 卡片后接 `ThinkingHeader`，间距与 classic 完全一致。
- user 卡片后接普通 assistant 正文、tool、system 行时保持现有单行空白，不因本次改动变成双行。
- 多行 user 文本、40 / 80 / 120 列、长 transcript sticky bottom 下间距仍正确。
- 同一 turn 内两个 compact block 之间的间距不被误加到用户卡片之外。


## 5. 实机验收

1. `dpsk` 重启，`/settings` 显示 `new thinking style: on`。
2. 打开截图对应的长 session，向上滚动：每个 reasoning/tool 阶段显示 compact header，不再夹着 classic `Thought: 7.6s`。
3. 向上滚动后，输入框上方右侧出现 `跳到最新 ↓`；点击一次回到最新，输入框不移动。
4. 40/80/120 列和 docked sidebar 各检查一次位置。
5. 不出现按钮被输入框或补全面板遮住，或按钮占掉 transcript 一行的回归。
6. user 卡片与下方 thinking/正文之间始终保留恰好一行空白，classic 与 compact 一致。

## 6. 非目标

- 不把 `newDesigns` 改成默认 on。
- 不改 host 的 transcript event 或 protocol。
- 不新增 vertical rail、tab history 或主题功能。
- 不在本轮发布、tag 或 push。

## 7. 实施结果

- compact 分组、用户卡片间距、Jump overlay 与回归测试全部完成。
- 宿主 290 项、渲染器 380 项；7 平台构建、全局安装和 tui profile 同步完成。
- 渲染器缓存 8b49ff56dc40，全局/profile 源包 9a469dc4f7a7，dpsk check 已幂等。
- 正在运行的旧 dpsk 进程需要重启后才会加载新 renderer。
