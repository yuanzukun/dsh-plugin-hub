/**
 * Minimal i18n layer for user-facing strings. Every visible string lives in
 * one of the locale dictionaries below; the active locale is resolved from
 * the `tui.locale` config row (default `zh-CN`).
 *
 * Adding a string: add a key to {@link MessageKey} (via the `Messages`
 * record), then fill it in BOTH dictionaries — the `Messages` type enforces
 * key parity at compile time, and `tests/i18n.spec.ts` re-checks it.
 */

/** Supported UI locales. */
export const LOCALES = ['zh-CN', 'en'] as const
export type Locale = (typeof LOCALES)[number]

/** Message templates; `{name}` placeholders are substituted by {@link Translator}. */
export type Messages = {
  // --- welcome header -----------------------------------------------------
  headerWelcome: string
  headerTips: string
  headerCommands: string
  headerSessions: string
  headerComplete: string
  headerExpand: string
  headerSession: string
  headerWorkspace: string
  headerTip: string
  headerTipBody: string
  // --- /help listing ------------------------------------------------------
  helpShortcuts: string
  helpCtrlC: string
  helpCtrlO: string
  helpCtrlR: string
  helpEsc: string
  helpEnter: string
  helpCtrlD: string
  helpCtrlT: string
  helpCtrlShiftO: string
  helpAltL: string
  helpAltUp: string
  helpCtrlP: string
  helpAltM: string
  helpCycleModel: string
  helpCtrlQ: string
  helpCommands: string
  helpPalette: string
  helpHelp: string
  helpModel: string
  helpThink: string
  helpNew: string
  helpResume: string
  helpDetails: string
  helpSkills: string
  helpSkillInvoke: string
  helpMode: string
  helpTheme: string
  helpSettings: string
  // --- command autocomplete descriptions ----------------------------------
  cmdPalette: string
  cmdHelp: string
  cmdModel: string
  cmdThink: string
  cmdNew: string
  cmdResume: string
  cmdDetails: string
  cmdSkills: string
  cmdMode: string
  cmdTheme: string
  cmdSettings: string
  helpPermission: string
  cmdPermission: string
  // --- notices ------------------------------------------------------------
  noticeNoSessions: string
  noticeSessionListFailed: string
  /** One aggregate notice for sessions whose stored log this dsh build cannot read. */
  noticeSessionsSkipped: string
  noticeNoSkills: string
  noticeSkillListFailed: string
  noticeSkillUsage: string
  noticeUnknownSkill: string
  noticeSkillFailed: string
  noticeAlreadySession: string
  noticeResuming: string
  noticeCreatingSession: string
  confirmYes: string
  confirmNo: string
  noticeSessionCreated: string
  noticeSessionCreateFailed: string
  noticeSessionResumed: string
  noticeResumeFailed: string
  noticeResumeTimeout: string
  noticeDefaultModelFailed: string
  noticeModelSet: string
  noticeThinkSet: string
  noticeThinkAlready: string
  noticeThinkUnknown: string
  noticeThinkUnsupported: string
  noticeThinkFailed: string
  noticeCompacting: string
  noticeCompactionDone: string
  noticeCompactionFailed: string
  noticeCompactionCause: string
  noticeCompactionHint: string
  noticeCompaction400Hint: string
  noticeTurnEnded: string
  noticeToolCards: string
  noticeReasoningShown: string
  noticeReasoningHidden: string
  noticeDisplayReset: string
  noticeInterjectionQueued: string
  noticeInterjectionEdit: string
  noticeInterjectionAlreadyEffective: string
  noticeInterjectionFailed: string
  noticeSessionOpUnavailable: string
  noticeNoModels: string
  noticeModelFailed: string
  noticeUnknownCommand: string
  noticeCommandFailed: string
  noticeReferenceFailed: string
  noticeModeSet: string
  noticeModeUnknown: string
  noticeModeUnavailable: string
  noticeModeAlready: string
  noticeModeNotBlank: string
  noticeModeMountFailed: string
  noticeModeSwitchFailed: string
  noticeEventRenderFailed: string
  noticeThemeSet: string
  noticeThemeUnknown: string
  noticeThemeModeSet: string
  noticeWorkspaceListFailed: string
  noticeThemeModeUnknown: string
  noticeThemeDarkSet: string
  noticeThemeLightSet: string
  noticeSettingsUnavailable: string
  noticeSettingsSaved: string
  noticeSettingsFailed: string
  noticeTitleModelSet: string
  noticeProviderModelsEdited: string
  noticeExitHint: string
  noticeFullAccessWarning: string
  // --- dialogs and flows --------------------------------------------------
  dialogTypeAnswer: string
  askTitle: string
  askInlineOptionHint: string
  askInlineMultiHint: string
  askInlineTextHint: string
  modelProvider: string
  modelTitle: string
  modelEffort: string
  resumeTitle: string
  settingsTitle: string
  settingsHint: string
  settingsSubmenuHint: string
  settingsEffortHint: string
  settingsEmpty: string
  settingsTabGeneral: string
  settingsTabModelsProviders: string
  settingsTabAppearance: string
  settingsTabModel: string
  settingsTabDefaults: string
  settingsAddProvider: string
  settingsEditProvider: string
  settingsProviderName: string
  settingsProviderId: string
  settingsCredentialConfigured: string
  settingsApi: string
  settingsApiOpenAiCompletions: string
  settingsApiOpenAiResponses: string
  settingsApiAnthropicMessages: string
  settingsBaseURL: string
  settingsApiKey: string
  settingsModels: string
  settingsManageModels: string
  settingsAddModel: string
  settingsModelListHint: string
  settingsModelListEmpty: string
  settingsModelValue: string
  settingsModelEffort: string
  settingsModelEffortLevels: string
  settingsModelEffortHint: string
  settingsModelDisplayName: string
  settingsModelContextWindow: string
  settingsModelMaxTokens: string
  settingsEffortInherit: string
  settingsEffortFromAdapter: string
  settingsEffortDisabled: string
  settingsModelRequired: string
  settingsModelDuplicate: string
  settingsProviderTemplate: string
  settingsBlankProvider: string
  settingsDiscoverModels: string
  settingsDiscovering: string
  settingsDiscoveredCount: string
  settingsDiscoverMerged: string
  settingsDiscoveryUnavailable: string
  settingsConfiguredProviders: string
  settingsConfiguredModels: string
  settingsProviderModelCount: string
  settingsSetDefaultModel: string
  settingsSetTitleModel: string
  providerFormHint: string
  providerConfigRequired: string
  providerIdRequired: string
  providerIdInvalid: string
  providerBaseURLRequired: string
  providerApiRequired: string
  providerModelsRequired: string
  /** Field labels the renderer draws for the provider form (`form-spec`). */
  providerFieldId: string
  providerFieldName: string
  providerFieldApi: string
  providerFieldBaseURL: string
  providerFieldApiKey: string
  providerFieldModels: string
  providerFieldModel: string
  providerFieldDiscover: string
  providerFieldEditModels: string
  providerFieldEfforts: string
  providerFieldEffort: string
  providerFieldContext: string
  providerFieldMax: string
  noticeProviderSaved: string
  noticeProviderFailed: string
  noticeDiscoveryUnavailable: string
  settingsTheme: string
  settingsThemeMode: string
  settingsThemeModeDynamic: string
  settingsThemeModeSelected: string
  settingsThemeDark: string
  settingsThemeLight: string
  settingsThemeSelectedItem: string
  settingsThemeCustom: string
  settingsThemeCustomNone: string
  settingsThemeCustomEditHint: string
  noticeThemeCustomSet: string
  noticeThemeCustomInvalid: string
  settingsTitleModel: string
  settingsProvider: string
  settingsModel: string
  settingsCustomProvider: string
  settingsCustomModel: string
  settingsEditCustomProvider: string
  settingsEditCustomModel: string
  settingsCustomConfig: string
  settingsSaveDefault: string
  settingsSaveTitle: string
  settingsSave: string
  settingsCancel: string
  customConfigHint: string
  customConfigRequired: string
  customConfigTarget: string
  settingsDefaultPermission: string
  settingsDefaultModel: string
  settingsDefaultEffort: string
  settingsOn: string
  settingsOff: string
  settingsEnabled: string
  settingsShowReasoning: string
  settingsToolOutputLines: string
  settingsDefaultMode: string
  settingsMaxParallelToolCalls: string
  settingsLeftPrompt: string
  settingsRightPrompt: string
  settingsPromptHint: string
  settingsKeyTools: string
  settingsKeyReasoning: string
  noticeKeybindingSet: string
  noticePromptSet: string
  settingsTabAdvanced: string
  settingsTabWechat: string
  settingsWechatProgressEnabled: string
  settingsWechatProgressInterval: string
  settingsWechatNotify: string
  settingsWechatUnavailable: string
  noticeWechatInvalidInterval: string
  noticeDefaultPermissionSet: string
  noticeDefaultModelSet: string
  noticeDefaultEffortSet: string
  noticeDefaultModeSet: string
  untitled: string
  // --- mode / theme labels ------------------------------------------------
  modeStandard: string
  modeMinimal: string
  modeCode: string
  modeCordis: string
  modeStandardHint: string
  modeMinimalHint: string
  modeCodeHint: string
  modeCordisHint: string
  permissionReadOnly: string
  permissionReadOnlyHint: string
  permissionWorkspaceWrite: string
  permissionWorkspaceWriteHint: string
  permissionFullAccess: string
  permissionFullAccessHint: string
  // --- renderer shell labels (sent to the renderer as the `i18n` payload) -----
  rendererSession: string
  rendererStatus: string
  rendererWechat: string
  rendererInterrupt: string
  rendererPalette: string
  rendererThemes: string
  rendererModels: string
  rendererSwitchModel: string
  rendererSessionPicker: string
  rendererSettings: string
  rendererThemeMode: string
  rendererTheme: string
  rendererShowReasoning: string
  rendererMaxLines: string
  rendererLeftPrompt: string
  rendererRightPrompt: string
  rendererKeysTitle: string
  rendererKeysHelp: string
  rendererThink: string
  rendererPermission: string
  rendererModeSuffix: string
  rendererPermissionAuto: string
  rendererPermissionCustom: string
  rendererPermissionReadOnly: string
  rendererPermissionWorkspaceWrite: string
  rendererPermissionFullAccess: string
  rendererMode: string
  rendererSkills: string
  rendererDetails: string
  rendererNewSession: string
  rendererHomePlaceholder: string
  rendererHomeKeys: string
  rendererContext: string
  rendererMcp: string
  rendererTodo: string
  rendererTrace: string
  rendererSpent: string
  rendererNoMcp: string
  rendererNoTodos: string
  rendererNoTrace: string
  rendererMoreItems: string
  rendererWechatUnavailable: string
  rendererWechatConnected: string
  rendererWechatDisconnected: string
  rendererLockHeld: string
  rendererLockPid: string
  rendererLockUnknown: string
  rendererPlugins: string
  rendererPlaceholder: string
  rendererJumpLatest: string
  rendererDrawerSubagents: string
  rendererCurrent: string
  rendererShow: string
  rendererHide: string
  /** The `ctrl+p` palette: its category headers, its own actions, and the WeChat ops. */
  rendererPaletteActions: string
  rendererPaletteEfforts: string
  rendererPaletteSessions: string
  rendererPaletteSkills: string
  rendererPalettePermissions: string
  rendererPaletteModes: string
  rendererPaletteWechat: string
  rendererPaletteRename: string
  rendererPaletteNewSession: string
  rendererPaletteExport: string
  rendererPaletteExit: string
  rendererPaletteDoctor: string
  rendererPaletteHelp: string
  /** Palette rows that only exist while the capability does (queue, shell jobs, terminal). */
  rendererPaletteQueue: string
  rendererPaletteShellJobs: string
  rendererPaletteTerminalOpen: string
  rendererPaletteTerminalHide: string
  rendererPaletteTerminalSelect: string
  rendererPaletteTerminalClose: string
  rendererWechatConnect: string
  rendererWechatStatus: string
  rendererWechatNotify: string
  rendererWechatProgress: string
  /** The chip a session with no title wears, in the strip, the sidebar, and the picker. */
  rendererUntitled: string
  /** The completion popup's `@` row marker and its empty states. */
  rendererKindReference: string
  rendererNoMatchingCommands: string
  rendererNoMatchingReferences: string
  /** The dialog chrome: the filter placeholder and the footer hints. */
  rendererTabMenuTitle: string
  rendererTabClose: string
  rendererTabCloseOthers: string
  rendererTabMoveLeft: string
  rendererTabMoveRight: string
  rendererTabReopen: string
  rendererTabRename: string
  rendererProviderForm: string
  rendererCustomModel: string
  rendererExported: string
  rendererExportSession: string
  rendererExportMarkdown: string
  rendererExportJson: string
  rendererQueueDelete: string
  rendererShellJobs: string
  rendererShellJobsEmpty: string
  rendererShellJobsStop: string
  rendererTerminals: string
  rendererTerminalNew: string
  rendererTerminalCloseAsk: string
  rendererSessionScopeProject: string
  rendererSessionScopeAll: string
  rendererSessionCount: string
  rendererPathDisplay: string
  rendererPathDisplayTilde: string
  rendererPathDisplayFull: string
  rendererSessionToday: string
  rendererSessionYesterday: string
  rendererSessionLast7Days: string
  rendererNoWorkspace: string
  rendererMcpServers: string
  rendererLanguage: string
  rendererLocaleRestart: string
  rendererSearch: string
  rendererDialogMove: string
  rendererDialogRun: string
  rendererTraceScroll: string
  rendererSubagents: string
  rendererBackgroundTasks: string
  rendererNoSubagents: string
  rendererNoBackgroundTasks: string
  rendererSubagentReadOnly: string
  rendererSubagentTabHint: string
  rendererSettingsCategoryGeneral: string
  rendererCancel: string
  rendererExitTitle: string
  rendererExitDetach: string
  rendererExitEndsTasks: string
  rendererExitDetachHint: string
  rendererExitEndsTasksHint: string
  rendererExitOpenRunning: string
  rendererShutdown: string
  rendererShutdownTitle: string
  rendererShutdownMessage: string
  rendererSettingsCategoryAppearance: string
  rendererAutostart: string
  rendererAutostartEnabled: string
  rendererAutostartDisabled: string
  rendererAutostartUnsupported: string
  rendererNewDesigns: string
  rendererThemeSystem: string
  rendererThemeDark: string
  rendererThemeLight: string
  rendererThemeModeUnavailable: string
  rendererTraceClose: string
  rendererTraceUser: string
  rendererTraceAssistant: string
  rendererTraceTool: string
  rendererTraceSystem: string
  rendererTraceSeq: string
  rendererTraceTurn: string
  rendererTraceStep: string
  rendererTraceStatus: string
}

export const MESSAGES: Record<Locale, Messages> = {
  'zh-CN': {
    headerWelcome: '欢迎回来！',
    headerTips: '小贴士',
    headerCommands: '打开命令',
    headerSessions: '引用会话与文件',
    headerComplete: '补全',
    headerExpand: '展开工具输出',
    headerSession: '会话',
    headerWorkspace: '工作目录',
    headerTip: '提示：',
    headerTipBody: '输入 /help 查看命令与快捷键。',
    helpShortcuts: '键盘快捷键',
    helpCtrlC: '清屏 / 中断；双击退出',
    helpCtrlO: '展开 / 折叠工具输出',
    helpCtrlR: '历史搜索（暂未开放）',
    helpEsc: '中断当前回合',
    helpEnter: '生成中回车：插话并在下一步生效',
    helpCtrlD: '编辑器为空时退出',
    helpCtrlT: '显示 / 隐藏思考块',
    helpCtrlShiftO: '显示 / 隐藏工具活动',
    helpAltL: '重置终端显示',
    helpAltUp: '编辑下一条未生效的插话',
    helpCtrlP: '打开命令面板',
    helpAltM: '打开模型选择器（ctrl+x m）',
    helpCycleModel: '循环切换模型（Shift 反向）',
    helpCtrlQ: '提交消息（生成中为插话）',
    helpCommands: '命令',
    helpPalette: '查看调色板角色表',
    helpHelp: '本帮助列表',
    helpModel: '选择 provider / model / 推理强度',
    helpThink: '切换当前模型的思考等级',
    helpNew: '新建会话',
    helpResume: '恢复持久化会话',
    helpDetails: '查看会话诊断',
    helpSkills: '列出可用技能',
    helpSkillInvoke: '以指令方式调用技能',
    helpSettings: '打开可视化设置',
    helpMode: '切换工作模式（官方预设与本地安装的预设）',
    helpTheme: '查看主题或切换主题',
    cmdPalette: '查看调色板角色表',
    cmdHelp: '查看快捷键与命令',
    cmdModel: '选择 provider / model / 推理强度',
    cmdThink: '切换当前模型的思考等级',
    cmdNew: '新建会话',
    cmdSettings: '打开可视化设置',
    cmdResume: '切换会话',
    cmdDetails: '查看会话状态与用量',
    cmdSkills: '列出可用技能',

    cmdMode: '切换 Agent 模式（官方预设与本地安装的预设）',
    cmdTheme: '查看或切换主题',
    helpPermission: '切换权限模式（沙箱 + 审批策略）',
    cmdPermission: '切换权限模式（沙箱 + 审批策略）',
    noticeNoSessions: '没有持久化会话。',
    noticeSessionListFailed: '会话列表获取失败：{error}',
    noticeSessionsSkipped: '已跳过 {count} 个无法读取的旧会话（dsh 会话格式版本不兼容）。',
    noticeNoSkills: '没有可用技能。',
    noticeSkillListFailed: '技能列表获取失败：{error}',
    noticeSkillUsage: '用法：/skill:<名称>',
    noticeUnknownSkill: '未知技能：{name}',
    noticeSkillFailed: '技能 "{name}" 加载失败：{error}',
    noticeAlreadySession: '已在当前会话。',
    noticeResuming: '正在恢复会话…',
    noticeCreatingSession: '正在创建新会话…',
    confirmYes: '是',
    confirmNo: '否',
    noticeSessionCreated: '已新建会话 {id}。',
    noticeSessionCreateFailed: '新建会话失败：{error}',
    noticeSessionResumed: '会话 {id} 已恢复。',
    noticeResumeFailed: '会话恢复失败：{error}',
    noticeResumeTimeout: '会话恢复超时，已取消本次恢复。',
    noticeDefaultModelFailed: '无法把默认模型写回配置：{error}',
    noticeModelSet: '模型已设为 {provider}/{model}。',
    noticeThinkSet: '思考等级已切换为 {name}（{id}）。',
    noticeThinkAlready: '当前思考等级已是 {name}（{id}）。',
    noticeThinkUnknown: '当前模型不支持思考等级：{name}',
    noticeThinkUnsupported: '当前模型未提供可切换的思考等级。',
    noticeThinkFailed: '思考等级切换失败：{error}',
    noticeCompacting: '上下文压缩中…',
    noticeCompactionDone: '上下文压缩完成。',
    noticeCompactionFailed: '上下文压缩失败：{error}',
    noticeCompactionCause: '详细原因：{cause}',
    noticeCompactionHint: '压缩失败通常表示可压缩历史太少或摘要未比原文更短。建议继续对话积累更多历史后再试。',
    noticeCompaction400Hint: '压缩请求被模型 API 拒绝（HTTP 400）。请检查 DEEPSEEK_BASE_URL 网关是否兼容 compaction 请求，以及当前模型是否支持该请求体。',
    noticeTurnEnded: '回合结束：{reason}。',
    noticeToolCards: '工具卡：{visibility}。',
    noticeReasoningShown: '思考块已显示。',
    noticeReasoningHidden: '思考块已隐藏。',
    noticeDisplayReset: '显示已重置。',
    noticeInterjectionQueued: '插话已加入队列，将在下一步生效；Alt+Up 可编辑。',
    noticeInterjectionEdit: '已取消该插话的排队状态，正在编辑。',
    noticeInterjectionAlreadyEffective: '该插话已生效，无法再编辑。',
    noticeInterjectionFailed: '插话发送失败：{error}',
    noticeSessionOpUnavailable: '渲染器暂不支持 {op} 操作。',
    noticeNoModels: '没有可循环的模型目录。',
    noticeModelFailed: '模型选择失败：{error}',
    noticeUnknownCommand: '未知命令：{name}',
    noticeCommandFailed: '命令执行失败：{error}',
    noticeReferenceFailed: '会话引用失败：{error}',
    noticeModeSet: '已切换到「{mode}」。',
    noticeModeUnknown: '未知模式：{name}',
    noticeModeUnavailable: '当前组合未提供 agent-presets 服务。',
    noticeModeAlready: '当前已是「{mode}」。',
    noticeModeNotBlank: '会话已产生内容，无法切换模式；请在新会话中切换。',
    noticeModeMountFailed: '模式装配失败：{error}',
    noticeModeSwitchFailed: '模式切换失败：{error}',
    noticeEventRenderFailed: '会话事件渲染失败：{error}',
    noticeThemeSet: '已切换主题：{name}。',
    noticeThemeUnknown: '未知主题：{name}',
    noticeThemeModeSet: '主题模式已切换：{mode}。',
    noticeWorkspaceListFailed: '工作区文件索引读取失败：{error}',
    noticeThemeModeUnknown: '未知主题模式：{name}',
    noticeThemeDarkSet: '深色主题已设为 {name}。',
    noticeThemeLightSet: '浅色主题已设为 {name}。',
    noticeSettingsUnavailable: '当前组合未提供持久化设置服务。',
    noticeSettingsSaved: '设置已保存。',
    noticeSettingsFailed: '设置保存失败：{error}',
    noticeTitleModelSet: '标题模型已设为 {provider}/{model}。',
    noticeProviderModelsEdited: '模型清单已更新（{count} 个模型）。',
    noticeExitHint: '再次按 Ctrl+C 退出',
    noticeFullAccessWarning: '当前为完全访问模式：文件沙箱已禁用，且不会请求审批。请谨慎操作。',
    dialogTypeAnswer: '输入你的回答并回车',
    askTitle: '提问',
    askInlineOptionHint: '输入数字选择，或直接输入自定义回答后回车',
    askInlineMultiHint: '多个选项用逗号分隔序号，回车提交；也可直接输入自定义回答',
    askInlineTextHint: '输入回答后回车',
    modelProvider: '服务商',
    modelTitle: '模型 · {provider}',
    modelEffort: '推理强度',
    resumeTitle: '恢复会话',
    settingsTitle: '设置',
    settingsHint: '↑/↓ 选择 · ←/→/Tab 切换标签 · Enter 切换/修改 · Esc 关闭',
    settingsSubmenuHint: '↑/↓ 选择 · Enter 确认 · Esc 返回',
    settingsEffortHint: '回车循环切换默认模型的思考等级',
    settingsEmpty: '没有可用选项',
    settingsTabGeneral: '常规',
    settingsTabModelsProviders: '模型与供应商',
    settingsTabAppearance: '外观',
    settingsTabModel: '模型',
    settingsTabDefaults: '默认配置',
    settingsAddProvider: '＋ 新增供应商',
    settingsEditProvider: '编辑供应商',
    settingsProviderName: '供应商名称',
    settingsProviderId: '供应商 ID',
    settingsCredentialConfigured: '已配置（留空保持不变）',
    settingsApi: '接口类型',
    settingsApiOpenAiCompletions: 'OAI 兼容（OpenAI Completions）',
    settingsApiOpenAiResponses: 'Response（OpenAI Responses）',
    settingsApiAnthropicMessages: 'Message（Anthropic Messages）',
    settingsBaseURL: 'Base URL',
    settingsApiKey: 'API Key',
    settingsModels: '模型列表',
    settingsManageModels: '管理模型列表',
    settingsAddModel: '新增模型',
    settingsModelListHint: '↑/↓ 选择 · Enter 展开/切换 · e 自定义思考等级 · Esc 收起 · Delete 删除模型',
    settingsModelListEmpty: '暂无模型。请选择“新增模型”。',
    settingsModelValue: '完整模型 ID',
    settingsModelEffort: '思考强度',
    settingsModelEffortLevels: '思考等级',
    settingsModelEffortHint: 'Enter 循环预设：跟随上游 → DeepSeek → OpenAI → GPT → Claude → 非推理；e 自定义，可输入 deepseek/openai/gpt/claude/false，或 off, high, max，或 high: ultra, max: ultra',
    settingsModelDisplayName: '显示名称',
    settingsModelContextWindow: '上下文窗口',
    settingsModelMaxTokens: '最大输出 tokens',
    settingsEffortInherit: '跟随默认',
    settingsEffortFromAdapter: '跟随上游',
    settingsEffortDisabled: '非推理',
    settingsModelRequired: '模型 ID 不能为空',
    settingsModelDuplicate: '模型 ID 已存在',
    settingsProviderTemplate: '选择供应商模板',
    settingsBlankProvider: '空白自定义',
    settingsDiscoverModels: '探测上游模型',
    settingsDiscovering: '正在探测模型…',
    settingsDiscoveredCount: '已发现 {count} 个模型',
    settingsDiscoverMerged: '已从上游加入 {count} 个模型',
    settingsDiscoveryUnavailable: '当前部署未提供模型探测服务。',
    settingsConfiguredProviders: '已配置供应商',
    settingsConfiguredModels: '已配置模型',
    settingsProviderModelCount: '{count} 个模型',
    settingsSetDefaultModel: '设为默认模型',
    settingsSetTitleModel: '设为标题模型',
    providerFormHint: '↑/↓ 移动 · Enter 编辑/循环接口/执行 · Esc 返回',
    providerConfigRequired: '供应商名称不能为空',
    providerIdRequired: '供应商 ID 不能为空',
    providerIdInvalid: '供应商 ID 必须是小写字母开头的 kebab-case',
    providerApiRequired: '自定义供应商必须选择有效接口类型',
    providerBaseURLRequired: '自定义供应商必须填写 Base URL',
    providerModelsRequired: '自定义供应商至少需要一个模型',
    providerFieldId: 'ID',
    providerFieldName: '名称',
    providerFieldApi: '接口类型',
    providerFieldBaseURL: 'Base URL',
    providerFieldApiKey: 'API Key',
    providerFieldModels: '模型（空格分隔 id）',
    providerFieldModel: '模型 id',
    providerFieldDiscover: '探测上游模型',
    providerFieldEditModels: '编辑模型',
    providerFieldEfforts: '思考等级（level=wire;...，无则 none）',
    providerFieldEffort: '默认思考强度',
    providerFieldContext: '上下文窗口',
    providerFieldMax: '最大输出 token',
    noticeProviderSaved: '供应商已保存。',
    noticeProviderFailed: '供应商保存失败：{error}',
    noticeDiscoveryUnavailable: '当前部署未提供模型探测服务。',
    settingsTheme: '主题',
    settingsThemeMode: '主题模式',
    settingsThemeModeDynamic: '动态',
    settingsThemeModeSelected: '选定',
    settingsThemeDark: '深色主题',
    settingsThemeLight: '浅色主题',
    settingsThemeSelectedItem: '单一主题',
    settingsThemeCustom: '主题颜色覆盖',
    settingsThemeCustomNone: '未设置',
    settingsThemeCustomEditHint: '输入 RGB 三元组，例如 250,179,135；留空清除覆盖',
    noticeThemeCustomSet: '主题颜色覆盖已更新：{name}',
    noticeThemeCustomInvalid: '颜色格式无效，请输入 0-255 范围内的三个数字，用逗号分隔。',
    settingsTitleModel: '标题模型',
    settingsProvider: '供应商',
    settingsModel: '模型',
    settingsCustomProvider: '✎ 自定义供应商…',
    settingsCustomModel: '✎ 自定义模型…',
    settingsEditCustomProvider: '✎ 编辑当前自定义供应商…',
    settingsEditCustomModel: '✎ 编辑当前自定义模型…',
    settingsCustomConfig: '✎ 自定义模型配置…',
    settingsSaveDefault: '保存为默认模型',
    settingsSaveTitle: '保存为标题模型',
    settingsSave: '保存',
    settingsCancel: '取消',
    customConfigHint: '↑/↓/←/→ 移动 · Enter 编辑/选中/取消选中 · Esc 返回',
    customConfigRequired: '供应商和模型不能为空',
    customConfigTarget: '至少选择一个保存目标',
    settingsDefaultPermission: '默认权限模式',
    settingsDefaultModel: '默认模型',
    settingsDefaultEffort: '默认思考强度',
    settingsOn: '开',
    settingsOff: '关',
    settingsEnabled: '启用',
    settingsShowReasoning: '显示思考过程',
    settingsToolOutputLines: '工具输出行数',
    settingsDefaultMode: '默认模式',
    settingsMaxParallelToolCalls: '最大并行工具调用数',
    settingsLeftPrompt: '左侧状态栏模板',
    settingsRightPrompt: '底部状态栏模板',
    settingsPromptHint: '输入提示词模板；留空恢复默认模板',
    settingsKeyTools: '工具输出展开快捷键',
    settingsKeyReasoning: '思考块开关快捷键',
    noticeKeybindingSet: '快捷键已更新：{name}',
    noticePromptSet: '提示词模板已更新：{name}',
    settingsTabAdvanced: '高级',
    settingsTabWechat: '微信claw',
    settingsWechatProgressEnabled: '进度汇报',
    settingsWechatProgressInterval: '进度汇报间隔（轮）',
    settingsWechatNotify: '终端任务推送微信',
    settingsWechatUnavailable: '微信桥不可用',
    noticeWechatInvalidInterval: '进度汇报间隔必须是正整数。',
    noticeDefaultPermissionSet: '默认权限模式已设为 {permission}。',
    noticeDefaultModelSet: '默认模型已设为 {provider}/{model}。',
    noticeDefaultEffortSet: '默认思考强度已设为 {effort}。',
    noticeDefaultModeSet: '默认模式已设为 {mode}。',
    untitled: '（未命名）',
    modeStandard: '标准',
    modeMinimal: '极简',
    modeCode: 'PTC',
    modeCordis: '创造',
    modeStandardHint: '完整 Agent 与工具链',
    modeMinimalHint: 'bash + 编辑器双工具',
    modeCodeHint: 'PTC Code Mode SDK',
    modeCordisHint: '创建和调试 preset',
    permissionReadOnly: '只读',
    permissionReadOnlyHint: '只允许读取；写入或更高权限操作需要审批',
    permissionWorkspaceWrite: '工作区写入',
    permissionWorkspaceWriteHint: '允许写入工作区与临时目录；范围外操作需要审批',
    permissionFullAccess: '完全访问',
    permissionFullAccessHint: '不受文件沙箱限制，且不会请求审批',
    rendererSession: '会话: ',
    rendererStatus: '状态: ',
    rendererWechat: '微信',
    rendererInterrupt: 'esc 中断',
    rendererPalette: '命令面板',
    rendererThemes: '主题',
    rendererModels: '模型',
    rendererSwitchModel: '切换模型',
    rendererSessionPicker: '会话',
    rendererSettings: '设置',
    rendererThemeMode: '主题模式',
    rendererTheme: '主题',
    rendererShowReasoning: '显示思考块',
    rendererMaxLines: '工具输出最大行数',
    rendererLeftPrompt: '左侧提示模板',
    rendererRightPrompt: '右侧提示模板',
    rendererKeysTitle: '按键',
    rendererKeysHelp: 'ctrl+p 面板 · ctrl+x n/l/m/b/c/s/x/q · ctrl+tab 切换会话 · shift+tab 切换 agent · f2 循环模型 · ctrl+t 思考强度 · tab 补全 · esc 中断 · alt+up 编辑插话 · pageup/pagedown 滚动',
    rendererThink: '思考强度',
    rendererPermission: '权限',
    rendererModeSuffix: '模式',
    rendererPermissionAuto: '自动',
    rendererPermissionCustom: '自定义',
    rendererPermissionReadOnly: '只读',
    rendererPermissionWorkspaceWrite: '工作区写入',
    rendererPermissionFullAccess: '完全权限',
    rendererMode: 'Agent 模式',
    rendererSkills: '技能',
    rendererDetails: '会话详情',
    rendererNewSession: '+ 新会话',
    rendererHomePlaceholder: '随便问…「修一个代码库里的 TODO」',
    rendererHomeKeys: 'shift+tab 切 agent · ctrl+p 命令',
    rendererContext: '上下文',
    rendererMcp: 'MCP',
    rendererTodo: 'TODO',
    rendererTrace: '轨迹',
    rendererSpent: '花费',
    rendererNoMcp: '未配置 MCP',
    rendererNoTodos: '无待办',
    rendererNoTrace: '暂无动作',
    rendererMoreItems: '…还有 {count} 项',
    rendererWechatUnavailable: '微信桥不可用',
    rendererWechatConnected: '已连接',
    rendererWechatDisconnected: '未连接',
    rendererLockHeld: '接收锁：本进程持有',
    rendererLockPid: '接收锁：pid {pid}',
    rendererLockUnknown: '接收锁：未知',
    rendererPlugins: '插件',
    rendererPlaceholder: '提示词，/命令，Ctrl+P 面板',
    rendererJumpLatest: '跳到最新 ↓',
    rendererDrawerSubagents: '子代理',
    rendererCurrent: '当前',
    rendererShow: '显示',
    rendererHide: '隐藏',
    rendererPaletteActions: '操作',
    rendererPaletteEfforts: '思考强度',
    rendererPaletteSessions: '会话',
    rendererPaletteSkills: '技能',
    rendererPalettePermissions: '权限',
    rendererPaletteModes: 'Agent 模式',
    rendererPaletteWechat: '微信',
    rendererPaletteRename: '重命名会话',
    rendererPaletteNewSession: '新建会话',
    rendererPaletteExport: '导出会话为 Markdown',
    rendererPaletteExit: '退出（恢复终端）',
    rendererPaletteDoctor: '运行诊断',
    rendererPaletteHelp: '查看快捷键',
    rendererPaletteQueue: '管理排队消息',
    rendererPaletteShellJobs: '列出后台任务',
    rendererPaletteTerminalOpen: '打开终端',
    rendererPaletteTerminalHide: '隐藏终端',
    rendererPaletteTerminalSelect: '选择终端',
    rendererPaletteTerminalClose: '关闭终端',
    rendererWechatConnect: '连接',
    rendererWechatStatus: '状态',
    rendererWechatNotify: '通知',
    rendererWechatProgress: '进度',
    rendererUntitled: '未命名会话',
    rendererKindReference: '引用',
    rendererNoMatchingCommands: '没有匹配的命令',
    rendererNoMatchingReferences: '没有匹配的文件、Agent 或引用',
    rendererTabMenuTitle: '会话标签页',
    rendererTabClose: '关闭标签页',
    rendererTabCloseOthers: '关闭其它标签页',
    rendererTabMoveLeft: '标签页左移',
    rendererTabMoveRight: '标签页右移',
    rendererTabReopen: '重新打开关闭的标签页',
    rendererTabRename: '重命名标签页',
    rendererProviderForm: '供应商表单',
    rendererCustomModel: '自定义模型',
    rendererExported: '会话已导出',
    rendererExportSession: '导出会话',
    rendererExportMarkdown: 'Markdown 记录',
    rendererExportJson: 'JSON 会话日志',
    rendererQueueDelete: '删除排队消息？',
    rendererShellJobs: '后台任务',
    rendererShellJobsEmpty: '此会话没有后台任务',
    rendererShellJobsStop: '停止后台任务？',
    rendererTerminals: '终端',
    rendererTerminalNew: '新建终端',
    rendererTerminalCloseAsk: '关闭终端？',
    rendererSessionScopeProject: '当前项目',
    rendererSessionScopeAll: '全部会话',
    rendererSessionCount: '{count} 个会话',
    rendererPathDisplay: '路径显示',
    rendererPathDisplayTilde: '~ 缩写',
    rendererPathDisplayFull: '完整路径',
    rendererSessionToday: '今天',
    rendererSessionYesterday: '昨天',
    rendererSessionLast7Days: '最近 7 天',
    rendererNoWorkspace: '无当前工作目录',
    rendererMcpServers: 'MCP 服务器',
    rendererLanguage: '界面语言',
    rendererLocaleRestart: '语言已保存，重启 dpsk 后生效',
    rendererSearch: '搜索',
    rendererDialogMove: '移动',
    rendererDialogRun: '运行',
    rendererTraceScroll: "滚动",
    rendererSubagents: '子代理',
    rendererBackgroundTasks: '后台任务',
    rendererNoSubagents: '暂无子代理',
    rendererNoBackgroundTasks: '暂无运行中的后台任务',
    rendererSubagentReadOnly: '该子代理为只读，当前模式不支持继续对话',
    rendererSubagentTabHint: '可在会话标签页之间切换返回上级或其他会话',
    rendererSettingsCategoryGeneral: '常规',
    rendererCancel: '取消',
    rendererExitTitle: '退出 dpsk',
    rendererExitDetach: '退出界面（任务在后台继续）',
    rendererExitEndsTasks: '仍然退出（正在运行的任务会停止）',
    rendererExitDetachHint: '核心进程和正在运行的任务会继续存活',
    rendererExitEndsTasksHint: '当前为内嵌模式，退出会同时结束核心进程和任务',
    rendererExitOpenRunning: '打开全部进行中会话',
    rendererShutdown: '彻底结束核心进程',
    rendererShutdownTitle: '彻底结束核心进程？',
    rendererShutdownMessage: '这会结束核心进程并中断所有正在运行的任务。若只想关闭界面、保留后台任务，请使用 /exit。',
    rendererSettingsCategoryAppearance: '外观',
    rendererAutostart: '开机启动核心',
    rendererAutostartEnabled: '已注册开机启动',
    rendererAutostartDisabled: '已取消开机启动',
    rendererAutostartUnsupported: '当前系统不支持开机启动',
    rendererNewDesigns: '新版思考样式',
    rendererThemeSystem: '跟随系统',
    rendererThemeDark: '深色',
    rendererThemeLight: '浅色',
    rendererThemeModeUnavailable: '当前主题不支持 {mode}',
    rendererTraceClose: "关闭",
    rendererTraceUser: "用户",
    rendererTraceAssistant: "助手",
    rendererTraceTool: "工具",
    rendererTraceSystem: "系统",
    rendererTraceSeq: "序号",
    rendererTraceTurn: "轮次",
    rendererTraceStep: "步骤",
    rendererTraceStatus: "状态",
  },
  en: {
    headerWelcome: 'Welcome back!',
    headerTips: 'Tips',
    headerCommands: '/ for commands',
    headerSessions: '@ for sessions and files',
    headerComplete: 'Tab to complete',
    headerExpand: 'Ctrl+O to expand tool output',
    headerSession: 'Session',
    headerWorkspace: 'Workspace',
    headerTip: 'Tip:',
    headerTipBody: 'Use /help to discover the command surface.',
    helpShortcuts: 'Keyboard shortcuts',
    helpCtrlC: 'clear / interrupt; press twice to exit',
    helpCtrlO: 'expand / collapse tool output',
    helpCtrlR: 'history search (not available yet)',
    helpEsc: 'interrupt the running turn',
    helpEnter: 'while generating, Enter queues an interjection for the next step',
    helpCtrlD: 'exit when editor is empty',
    helpCtrlT: 'toggle reasoning blocks',
    helpCtrlShiftO: 'show / hide tool activity',
    helpAltL: 'reset terminal display',
    helpAltUp: 'edit the next queued interjection',
    helpCtrlP: 'open the command palette',
    helpAltM: 'open the model picker (ctrl+x m)',
    helpCycleModel: 'cycle models (Shift for reverse)',
    helpCtrlQ: 'submit message (interjection while generating)',
    helpCommands: 'Commands',
    helpPalette: 'show the palette role table',
    helpHelp: 'this listing',
    helpModel: 'pick a provider/model/reasoning effort',
    helpThink: 'switch the current model reasoning effort',
    helpNew: 'start a new session',
    helpResume: 'resume a persisted session',
    helpDetails: 'show session diagnostics',
    helpSkills: 'list available skills',
    helpSkillInvoke: 'invoke a skill as instructions',
    helpMode: 'switch working mode (shipped or locally installed presets)',
    helpTheme: 'show themes or switch theme',
    helpSettings: 'open visual settings',
    cmdPalette: 'Show the palette role table',
    cmdHelp: 'Show keyboard shortcuts and commands',
    cmdModel: 'Pick a provider/model/reasoning effort',
    cmdThink: 'Switch the current model reasoning effort',
    cmdNew: 'Start a new session',
    cmdResume: 'Switch session',
    cmdDetails: 'Show session status and usage',
    cmdSkills: 'List available skills',

    cmdMode: 'Switch agent (shipped or locally installed presets)',
    cmdTheme: 'Show or switch theme',
    cmdSettings: 'Open visual settings',
    helpPermission: 'switch permission mode (sandbox + approval policy)',
    cmdPermission: 'Switch permission mode (sandbox + approval policy)',
    noticeNoSessions: 'No persisted sessions.',
    noticeSessionListFailed: 'Session listing failed: {error}',
    noticeSessionsSkipped: 'Skipped {count} unreadable legacy session(s): their stored format is incompatible with this dsh build.',
    noticeNoSkills: 'No skills available.',
    noticeSkillListFailed: 'Skill listing failed: {error}',
    noticeSkillUsage: 'Usage: /skill:<name>',
    noticeUnknownSkill: 'Unknown skill: {name}',
    noticeSkillFailed: 'Skill "{name}" failed to load: {error}',
    noticeAlreadySession: 'Already on this session.',
    noticeResuming: 'Resuming session…',
    noticeCreatingSession: 'Creating a new session…',
    confirmYes: 'Yes',
    confirmNo: 'No',
    noticeSessionCreated: 'Started session {id}.',
    noticeSessionCreateFailed: 'Failed to create session: {error}',
    noticeSessionResumed: 'Session {id} resumed.',
    noticeResumeFailed: 'Failed to resume session: {error}',
    noticeResumeTimeout: 'Session resume timed out and was cancelled.',
    noticeDefaultModelFailed: 'Could not persist the default model: {error}',
    noticeModelSet: 'Model set to {provider}/{model}.',
    noticeThinkSet: 'Reasoning effort switched to {name} ({id}).',
    noticeThinkAlready: 'Reasoning effort is already {name} ({id}).',
    noticeThinkUnknown: 'The current model does not support reasoning effort: {name}',
    noticeThinkUnsupported: 'The current model does not expose selectable reasoning efforts.',
    noticeThinkFailed: 'Reasoning effort switch failed: {error}',
    noticeCompacting: 'Context being compacted…',
    noticeCompactionDone: 'Compaction finished.',
    noticeCompactionFailed: 'Compaction failed: {error}',
    noticeCompactionCause: 'Detailed reason: {cause}',
    noticeCompactionHint: 'Compaction usually fails when the compactable history is too small or the summary is not shorter. Continue the conversation and retry later.',
    noticeCompaction400Hint: 'The model API rejected the compaction request (HTTP 400). Check whether DEEPSEEK_BASE_URL gateway supports compaction requests and whether the current model accepts the request body.',
    noticeTurnEnded: 'Turn ended: {reason}.',
    noticeToolCards: 'Tool cards {visibility}.',
    noticeReasoningShown: 'Reasoning blocks shown.',
    noticeReasoningHidden: 'Reasoning blocks hidden.',
    noticeDisplayReset: 'Display reset.',
    noticeInterjectionQueued: 'Interjection queued; it will take effect on the next step. Alt+Up to edit.',
    noticeInterjectionEdit: 'Cancelled the queued interjection and opened it for editing.',
    noticeInterjectionAlreadyEffective: 'That interjection already took effect and can no longer be edited.',
    noticeInterjectionFailed: 'Interjection failed: {error}',
    noticeSessionOpUnavailable: 'The renderer does not support the {op} operation yet.',
    noticeNoModels: 'No model catalog available to cycle.',
    noticeModelFailed: 'Model selection failed: {error}',
    noticeUnknownCommand: 'Unknown command: {name}',
    noticeCommandFailed: 'Command failed: {error}',
    noticeReferenceFailed: 'Session reference failed: {error}',
    noticeModeSet: 'Mode switched to {mode}.',
    noticeModeUnknown: 'Unknown mode: {name}',
    noticeModeUnavailable: 'agent-presets is not composed in this deployment.',
    noticeModeAlready: 'Already in {mode} mode.',
    noticeModeNotBlank: 'Cannot switch modes: the session already produced content. Start a new session to switch.',
    noticeModeMountFailed: 'Preset mount failed: {error}',
    noticeModeSwitchFailed: 'Mode switch failed: {error}',
    noticeEventRenderFailed: 'Session event render failed: {error}',
    noticeThemeSet: 'Theme switched to {name}.',
    noticeThemeUnknown: 'Unknown theme: {name}',
    noticeThemeModeSet: 'Theme mode switched to {mode}.',
    noticeWorkspaceListFailed: 'Could not read the workspace file index: {error}',
    noticeThemeModeUnknown: 'Unknown theme mode: {name}',
    noticeThemeDarkSet: 'Dark theme set to {name}.',
    noticeThemeLightSet: 'Light theme set to {name}.',
    noticeSettingsUnavailable: 'Persistent settings are not available in this deployment.',
    noticeSettingsSaved: 'Settings saved.',
    noticeSettingsFailed: 'Settings save failed: {error}',
    noticeTitleModelSet: 'Title model set to {provider}/{model}.',
    noticeProviderModelsEdited: 'Model catalog updated ({count} models).',
    noticeExitHint: 'Press Ctrl+C again to exit',
    noticeFullAccessWarning: 'Full access mode is active: file confinement is disabled and approval prompts are off. Proceed with care.',
    dialogTypeAnswer: 'type your answer and press enter',
    askTitle: 'Question',
    askInlineOptionHint: 'Type a number to select, or type a custom answer and press Enter',
    askInlineMultiHint: 'Enter comma-separated option numbers and press Enter, or type a custom answer',
    askInlineTextHint: 'Type your answer and press Enter',
    modelProvider: 'Provider',
    modelTitle: 'Model · {provider}',
    modelEffort: 'Reasoning effort',
    resumeTitle: 'Resume session',
    settingsTitle: 'Settings',
    settingsHint: '↑/↓ select · ←/→/Tab switch tabs · Enter toggle/change · Esc close',
    settingsSubmenuHint: '↑/↓ select · Enter confirm · Esc go back',
    settingsEffortHint: 'Enter cycles the default model thinking level',
    settingsEmpty: 'No options available',
    settingsTabGeneral: 'General',
    settingsTabModelsProviders: 'Models & Providers',
    settingsTabAppearance: 'Appearance',
    settingsTabModel: 'Model',
    settingsTabDefaults: 'Defaults',
    settingsAddProvider: '＋ Add provider',
    settingsEditProvider: 'Edit provider',
    settingsProviderName: 'Provider name',
    settingsProviderId: 'Provider ID',
    settingsCredentialConfigured: 'Configured (leave blank to keep)',
    settingsApi: 'API type',
    settingsApiOpenAiCompletions: 'OAI-compatible (OpenAI Completions)',
    settingsApiOpenAiResponses: 'Response (OpenAI Responses)',
    settingsApiAnthropicMessages: 'Message (Anthropic Messages)',
    settingsBaseURL: 'Base URL',
    settingsApiKey: 'API Key',
    settingsModels: 'Models',
    settingsManageModels: 'Manage model list',
    settingsAddModel: 'Add model',
    settingsModelListHint: '↑/↓ select · Enter expand/cycle · e custom thinking levels · Esc collapse · Delete remove model',
    settingsModelListEmpty: 'No models. Choose “Add model”.',
    settingsModelValue: 'Full model ID',
    settingsModelEffort: 'Thinking level',
    settingsModelEffortLevels: 'Thinking levels',
    settingsModelEffortHint: 'Enter cycles presets: follow upstream → DeepSeek → OpenAI → GPT → Claude → non-reasoning; e custom. Accepts deepseek/openai/gpt/claude/false, off, high, max, or high: ultra, max: ultra',
    settingsModelDisplayName: 'Display name',
    settingsModelContextWindow: 'Context window',
    settingsModelMaxTokens: 'Max output tokens',
    settingsEffortInherit: 'Follow default',
    settingsEffortFromAdapter: 'Follow upstream',
    settingsEffortDisabled: 'Non-reasoning',
    settingsModelRequired: 'Model ID is required',
    settingsModelDuplicate: 'Model ID already exists',
    settingsProviderTemplate: 'Choose provider template',
    settingsBlankProvider: 'Blank custom',
    settingsDiscoverModels: 'Discover upstream models',
    settingsDiscovering: 'Discovering models…',
    settingsDiscoveredCount: '{count} models discovered',
    settingsDiscoverMerged: 'Added {count} models from upstream',
    settingsDiscoveryUnavailable: 'Model discovery is not available in this deployment.',
    settingsConfiguredProviders: 'Configured providers',
    settingsConfiguredModels: 'Configured models',
    settingsProviderModelCount: '{count} models',
    settingsSetDefaultModel: 'Set as default model',
    settingsSetTitleModel: 'Set as title model',
    providerFormHint: '↑/↓/←/→ move · Enter edit/cycle API/run · Esc back',
    providerConfigRequired: 'Provider name is required',
    providerIdRequired: 'Provider ID is required',
    providerIdInvalid: 'Provider ID must be lowercase kebab-case',
    providerApiRequired: 'A custom provider must use a supported API type',
    providerBaseURLRequired: 'A custom provider must specify a Base URL',
    providerModelsRequired: 'A custom provider needs at least one model',
    providerFieldId: 'ID',
    providerFieldName: 'Name',
    providerFieldApi: 'API type',
    providerFieldBaseURL: 'Base URL',
    providerFieldApiKey: 'API Key',
    providerFieldModels: 'Models (ids separated by spaces)',
    providerFieldModel: 'Model id',
    providerFieldDiscover: 'Discover upstream models',
    providerFieldEditModels: 'Edit models',
    providerFieldEfforts: 'Thinking levels (level=wire;..., none if no reasoning)',
    providerFieldEffort: 'Default effort',
    providerFieldContext: 'Context window',
    providerFieldMax: 'Max output tokens',
    noticeProviderSaved: 'Provider saved.',
    noticeProviderFailed: 'Provider save failed: {error}',
    noticeDiscoveryUnavailable: 'Model discovery is not available in this deployment.',
    settingsTheme: 'Theme',
    settingsThemeMode: 'Theme mode',
    settingsThemeModeDynamic: 'Dynamic',
    settingsThemeModeSelected: 'Selected',
    settingsThemeDark: 'Dark theme',
    settingsThemeLight: 'Light theme',
    settingsThemeSelectedItem: 'Theme',
    settingsThemeCustom: 'Theme color overrides',
    settingsThemeCustomNone: 'None',
    settingsThemeCustomEditHint: 'Enter an RGB triple, e.g. 250,179,135; leave blank to clear',
    noticeThemeCustomSet: 'Theme color override updated: {name}',
    noticeThemeCustomInvalid: 'Invalid color format. Enter three comma-separated numbers between 0 and 255.',
    settingsTitleModel: 'Title model',
    settingsProvider: 'Provider',
    settingsModel: 'Model',
    settingsCustomProvider: '✎ Custom provider…',
    settingsCustomModel: '✎ Custom model…',
    settingsEditCustomProvider: '✎ Edit current custom provider…',
    settingsEditCustomModel: '✎ Edit current custom model…',
    settingsCustomConfig: '✎ Custom model config…',
    settingsSaveDefault: 'Save as default model',
    settingsSaveTitle: 'Save as title model',
    settingsSave: 'Save',
    settingsCancel: 'Cancel',
    customConfigHint: '↑/↓/←/→ move · Enter edit/toggle · Esc back',
    customConfigRequired: 'Provider and model are required',
    customConfigTarget: 'Choose at least one save target',
    settingsDefaultPermission: 'Default permission mode',
    settingsDefaultModel: 'Default model',
    settingsDefaultEffort: 'Default reasoning effort',
    settingsOn: 'On',
    settingsOff: 'Off',
    settingsEnabled: 'Enabled',
    settingsShowReasoning: 'Show reasoning',
    settingsToolOutputLines: 'Tool output lines',
    settingsDefaultMode: 'Default mode',
    settingsMaxParallelToolCalls: 'Max parallel tool calls',
    settingsLeftPrompt: 'Left status template',
    settingsRightPrompt: 'Bottom status template',
    settingsPromptHint: 'Enter a prompt template; leave blank to restore the default',
    settingsKeyTools: 'Tool output expand key',
    settingsKeyReasoning: 'Reasoning toggle key',
    noticeKeybindingSet: 'Keybinding updated: {name}',
    noticePromptSet: 'Prompt template updated: {name}',
    settingsTabAdvanced: 'Advanced',
    settingsTabWechat: 'WeChat Claw',
    settingsWechatProgressEnabled: 'Progress reports',
    settingsWechatProgressInterval: 'Progress interval (rounds)',
    settingsWechatNotify: 'Push terminal tasks to WeChat',
    settingsWechatUnavailable: 'WeChat bridge unavailable',
    noticeWechatInvalidInterval: 'Progress interval must be a positive integer.',
    noticeDefaultPermissionSet: 'Default permission mode set to {permission}.',
    noticeDefaultModelSet: 'Default model set to {provider}/{model}.',
    noticeDefaultEffortSet: 'Default reasoning effort set to {effort}.',
    noticeDefaultModeSet: 'Default mode set to {mode}.',
    untitled: '(untitled)',
    modeStandard: 'standard',
    modeMinimal: 'minimal',
    modeCode: 'PTC',
    modeCordis: 'creator',
    modeStandardHint: 'full Agent and toolchain',
    modeMinimalHint: 'bash + editor only',
    modeCodeHint: 'PTC Code Mode SDK',
    modeCordisHint: 'create and debug presets',
    permissionReadOnly: 'read only',
    permissionReadOnlyHint: 'Allow reads; writes or higher-privilege operations require approval',
    permissionWorkspaceWrite: 'workspace write',
    permissionWorkspaceWriteHint: 'Allow writes inside the workspace and temporary directories; wider access requires approval',
    permissionFullAccess: 'full access',
    permissionFullAccessHint: 'Disable file confinement and approval prompts',
    rendererSession: 'session: ',
    rendererStatus: 'status: ',
    rendererWechat: 'wechat',
    rendererInterrupt: 'esc interrupt',
    rendererPalette: 'command palette',
    rendererThemes: 'themes',
    rendererModels: 'models',
    rendererSwitchModel: 'Switch model',
    rendererSessionPicker: 'sessions',
    rendererSettings: 'settings',
    rendererThemeMode: 'theme mode',
    rendererTheme: 'theme',
    rendererShowReasoning: 'show reasoning blocks',
    rendererMaxLines: 'max tool output lines',
    rendererLeftPrompt: 'left prompt template',
    rendererRightPrompt: 'right prompt template',
    rendererKeysTitle: 'keys',
    rendererKeysHelp: 'ctrl+p palette · ctrl+x n/l/m/b/c/s/x/q · ctrl+tab sessions · shift+tab agent · f2 cycle model · ctrl+t effort · tab complete · esc interrupt · alt+up edit interjection · pageup/pagedown scroll',
    rendererThink: 'reasoning effort',
    rendererPermission: 'permission',
    rendererModeSuffix: ' mode',
    rendererPermissionAuto: 'auto',
    rendererPermissionCustom: 'custom',
    rendererPermissionReadOnly: 'read only',
    rendererPermissionWorkspaceWrite: 'workspace write',
    rendererPermissionFullAccess: 'full access',
    rendererMode: 'agent',
    rendererSkills: 'skills',
    rendererDetails: 'session details',
    rendererNewSession: '+ New session',
    rendererHomePlaceholder: 'Ask anything… "Fix a TODO in the codebase"',
    rendererHomeKeys: 'shift+tab agents · ctrl+p commands',
    rendererContext: 'context',
    rendererMcp: 'MCP',
    rendererTodo: 'TODO',
    rendererTrace: 'trace',
    rendererSpent: 'spent',
    rendererNoMcp: 'no MCP servers',
    rendererNoTodos: 'no todos',
    rendererNoTrace: 'no activity',
    rendererMoreItems: '+{count} more',
    rendererWechatUnavailable: 'unavailable',
    rendererWechatConnected: 'connected',
    rendererWechatDisconnected: 'not connected',
    rendererLockHeld: 'lock: this process',
    rendererLockPid: 'lock: pid {pid}',
    rendererLockUnknown: 'lock: unknown',
    rendererPlugins: 'MCP',
    rendererPlaceholder: 'prompt, /command, Ctrl+P palette',
    rendererJumpLatest: 'Jump to latest ↓',
    rendererDrawerSubagents: 'subagents',
    rendererCurrent: 'current',
    rendererShow: 'show',
    rendererHide: 'hide',
    rendererPaletteActions: 'actions',
    rendererPaletteEfforts: 'reasoning effort',
    rendererPaletteSessions: 'sessions',
    rendererPaletteSkills: 'skills',
    rendererPalettePermissions: 'permissions',
    rendererPaletteModes: 'agents',
    rendererPaletteWechat: 'wechat',
    rendererPaletteRename: 'rename session',
    rendererPaletteNewSession: 'new session',
    rendererPaletteExport: 'export session as Markdown',
    rendererPaletteExit: 'exit (restore terminal)',
    rendererPaletteDoctor: 'run diagnostics',
    rendererPaletteHelp: 'show key bindings',
    rendererPaletteQueue: 'manage queued messages',
    rendererPaletteShellJobs: 'list shell jobs',
    rendererPaletteTerminalOpen: 'open terminal',
    rendererPaletteTerminalHide: 'hide terminal',
    rendererPaletteTerminalSelect: 'select terminal',
    rendererPaletteTerminalClose: 'close terminal',
    rendererWechatConnect: 'connect',
    rendererWechatStatus: 'status',
    rendererWechatNotify: 'notify',
    rendererWechatProgress: 'progress',
    rendererUntitled: 'New Session',
    rendererKindReference: 'reference',
    rendererNoMatchingCommands: 'No matching commands',
    rendererNoMatchingReferences: 'No matching files, agents, or references',
    rendererTabMenuTitle: 'session tab',
    rendererTabClose: 'close tab',
    rendererTabCloseOthers: 'close other tabs',
    rendererTabMoveLeft: 'move tab left',
    rendererTabMoveRight: 'move tab right',
    rendererTabReopen: 'reopen closed tab',
    rendererTabRename: 'rename tab',
    rendererProviderForm: 'provider form',
    rendererCustomModel: 'custom model',
    rendererExported: 'session exported',
    rendererExportSession: 'export session',
    rendererExportMarkdown: 'Markdown transcript',
    rendererExportJson: 'JSON session log',
    rendererQueueDelete: 'delete queued message?',
    rendererShellJobs: 'shell jobs',
    rendererShellJobsEmpty: 'no shell jobs for this session',
    rendererShellJobsStop: 'stop shell job?',
    rendererTerminals: 'terminals',
    rendererTerminalNew: 'new terminal',
    rendererTerminalCloseAsk: 'close terminal?',
    rendererSessionScopeProject: 'current project',
    rendererSessionScopeAll: 'all sessions',
    rendererSessionCount: '{count} sessions',
    rendererPathDisplay: 'path display',
    rendererPathDisplayTilde: '~ abbreviated',
    rendererPathDisplayFull: 'full path',
    rendererSessionToday: 'today',
    rendererSessionYesterday: 'yesterday',
    rendererSessionLast7Days: 'last 7 days',
    rendererNoWorkspace: 'no current workspace',
    rendererMcpServers: 'MCP servers',
    rendererLanguage: 'language',
    rendererLocaleRestart: 'language saved — restart dpsk to apply',
    rendererSearch: 'Search',
    rendererDialogMove: 'move',
    rendererDialogRun: 'run',
    rendererTraceScroll: "scroll",
    rendererSubagents: 'subagents',
    rendererBackgroundTasks: 'background tasks',
    rendererNoSubagents: 'no subagents',
    rendererNoBackgroundTasks: 'no running background tasks',
    rendererSubagentReadOnly: 'this subagent is read-only and cannot continue the conversation',
    rendererSubagentTabHint: 'use the session tabs to switch back to the parent or another session',
    rendererSettingsCategoryGeneral: 'general',
    rendererCancel: 'cancel',
    rendererExitTitle: 'exit dpsk',
    rendererExitDetach: 'exit TUI (tasks continue in background)',
    rendererExitEndsTasks: 'exit anyway (running tasks will stop)',
    rendererExitDetachHint: 'the core process and its running tasks stay alive',
    rendererExitEndsTasksHint: 'embedded mode exits the core process and stops its tasks',
    rendererExitOpenRunning: 'open every running session',
    rendererShutdown: 'shut down core process',
    rendererShutdownTitle: 'shut down the core process?',
    rendererShutdownMessage: 'This ends the core process and interrupts every running task. Use /exit to close only the TUI and keep work running.',
    rendererSettingsCategoryAppearance: 'appearance',
    rendererAutostart: 'launch core at login',
    rendererAutostartEnabled: 'launch at login enabled',
    rendererAutostartDisabled: 'launch at login disabled',
    rendererAutostartUnsupported: 'launch at login is unsupported on this platform',
    rendererNewDesigns: 'new thinking style',
    rendererThemeSystem: 'system',
    rendererThemeDark: 'dark',
    rendererThemeLight: 'light',
    rendererThemeModeUnavailable: 'the selected theme does not offer {mode}',
    rendererTraceClose: "close",
    rendererTraceUser: "user",
    rendererTraceAssistant: "assistant",
    rendererTraceTool: "tool",
    rendererTraceSystem: "system",
    rendererTraceSeq: "seq",
    rendererTraceTurn: "turn",
    rendererTraceStep: "step",
    rendererTraceStatus: "status",
  },
}

export type MessageKey = keyof Messages

/** Substitute `{name}` placeholders in a template. */
function fill(template: string, params: Record<string, string | number> | undefined): string {
  if (params === undefined) return template
  return template.replace(/\{(\w+)\}/g, (match, name: string) =>
    name in params ? String(params[name]) : match)
}

/** Build the translator bound to one locale; unknown locales fall back to zh-CN. */
export function createTranslator(locale: Locale): Translator {
  const messages = MESSAGES[locale] ?? MESSAGES['zh-CN']
  return (key, params) => fill(messages[key] ?? MESSAGES['zh-CN'][key], params)
}

/**
 * The whole dictionary for one locale, as the `i18n` payload sends it.
 *
 * The renderer runs in a separate process and cannot import this module, so the
 * strings travel over IPC. A locale with no dictionary falls back to `zh-CN`,
 * the same rule the translator uses.
 */
export function messagesFor(locale: Locale): Record<string, string> {
  return { ...(MESSAGES[locale] ?? MESSAGES['zh-CN']) }
}

/** Translate one message key, with optional `{name}` parameters. */
export type Translator = (key: MessageKey, params?: Record<string, string | number>) => string
