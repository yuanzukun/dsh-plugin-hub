import { resolveSessionPreset, type Context, type Session, type SessionEvent } from './dsh-host/index.ts'

/** Events proving that a session contains model-facing conversation data. */
const CONVERSATION_EVENT_TYPES: Readonly<Record<string, true>> = {
  'user/message': true,
  'assistant/message': true,
  'tool/call': true,
}

/** Whether a session has crossed the blank-session boundary. */
export function hasConversationData(events: readonly SessionEvent[]): boolean {
  return events.some(event => CONVERSATION_EVENT_TYPES[event.type] === true)
}


/**
 * Decide whether one `session-list` row is the setup-only shell the UI hides.
 *
 * Live agents are authoritative while they exist: an empty in-memory setup buffer
 * means the session has no persisted log yet, so the head scan cannot see it.
 * Persisted rows fall back to the head scan; an unknown/unreadable head is never
 * marked blank. A real title always proves the session has conversational value.
 */
export function sessionListBlank(input: {
  readonly title: string
  readonly liveEvents?: readonly SessionEvent[]
  readonly persistedBlank?: boolean
}): boolean {
  if (input.title.trim() !== '') return false
  if (input.liveEvents !== undefined) return !hasConversationData(input.liveEvents)
  return input.persistedBlank === true
}

/**
 * Persist a runtime preset immediately before the first user message. Keeping
 * this out of blank-session setup preserves the persistence backend's lazy
 * materialization contract: an abandoned session leaves no artifact.
 */
export function recordConversationPreset(ctx: Context, session: Session, preset: string): void {
  if (resolveSessionPreset(ctx, session) === preset) return
  session.append('agent-preset/selected', { agentPreset: preset })
}
