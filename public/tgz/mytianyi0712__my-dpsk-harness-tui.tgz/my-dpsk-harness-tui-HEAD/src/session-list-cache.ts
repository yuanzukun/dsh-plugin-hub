/** Small disk cache for the session rail: first paint uses the last known list while the
 * real enumeration refreshes in the background. Only presentation fields are retained. */
import { mkdirSync, readFileSync } from 'node:fs'
import { writeFile } from 'node:fs/promises'
import { dirname } from 'node:path'
import type { SessionListPayload } from './ipc/kinds.ts'

export type CachedSessionRow = SessionListPayload['sessions'][number]

function validRow(value: unknown): value is Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false
  const row = value as Record<string, unknown>
  return typeof row.id === 'string' && row.id !== ''
    && typeof row.title === 'string'
    && typeof row.createdAt === 'number' && Number.isFinite(row.createdAt)
}

export function parseSessionListCache(text: string): CachedSessionRow[] {
  let raw: unknown
  try {
    raw = JSON.parse(text)
  } catch {
    return []
  }
  if (raw === null || typeof raw !== 'object' || Array.isArray(raw)) return []
  const sessions = (raw as { sessions?: unknown }).sessions
  if (!Array.isArray(sessions)) return []
  return sessions.flatMap((value): CachedSessionRow[] => {
    if (!validRow(value)) return []
    return [{
      id: value.id as string,
      title: value.title as string,
      active: false,
      ...(typeof value.workspace === 'string' ? { workspace: value.workspace } : {}),
      ...(typeof value.parentId === 'string' ? { parentId: value.parentId } : {}),
      createdAt: value.createdAt as number,
      ...(typeof value.lastActivityAt === 'number' && Number.isFinite(value.lastActivityAt)
        ? { lastActivityAt: value.lastActivityAt }
        : {}),
      // A process that just started has no running agents yet; the fresh enumeration
      // replaces these presentation flags a moment later.
      status: 'idle' as const,
      attention: false,
      ...(value.blank === true ? { blank: true } : {}),
    }]
  })
}

export function readSessionListCache(path: string): CachedSessionRow[] {
  try {
    return parseSessionListCache(readFileSync(path, 'utf8'))
  } catch {
    return []
  }
}

export async function writeSessionListCache(path: string, sessions: readonly CachedSessionRow[]): Promise<void> {
  mkdirSync(dirname(path), { recursive: true })
  await writeFile(path, `${JSON.stringify({ version: 1, sessions })}\n`, 'utf8')
}
