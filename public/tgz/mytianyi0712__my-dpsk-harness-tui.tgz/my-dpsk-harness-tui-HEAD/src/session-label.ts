/**
 * Labels for sessions that carry no title of their own.
 *
 * dsh writes a `session/title` event only when a title provider ran. Sessions created before
 * that provider existed — and blank ones carried over from another surface — have none, so
 * every list fell back to "New Session" plus the id and the rows became indistinguishable.
 * The opening user message is the text every dsh surface derives a title from, so the
 * terminal reads it out of the head of the log and uses it as the label.
 */

import type { SessionEvent } from './dsh-host/index.ts'

/** Longest label produced here; the session strip and the pickers truncate further. */
export const FIRST_PROMPT_LABEL_CHARS = 60

/** Event types that prove a session carries a conversation (mirrors `session-lifecycle`). */
const CONVERSATION_EVENT_TYPES: Readonly<Record<string, true>> = {
  'user/message': true,
  'assistant/message': true,
  'tool/call': true,
}

/** Whether one event shows the session got past its setup events. */
export function hasConversationEvent(event: SessionEvent): boolean {
  return CONVERSATION_EVENT_TYPES[event.type] === true
}

/** Collapse a prompt into one row: newlines and runs of spaces become single spaces. */
export function singleLine(text: string): string {
  return text.replace(/\s+/g, ' ').trim()
}

/**
 * The readable text of one `user/message` event, as a one-line label.
 *
 * Only text parts count: an attachment-only prompt has no text to show, and a tool result
 * is a different event type. The label is cut to {@link FIRST_PROMPT_LABEL_CHARS} so the row
 * keeps its shape before the renderer's own cell-aware truncation runs.
 */
export function userMessageText(event: SessionEvent): string | undefined {
  if (event.type !== 'user/message') return undefined
  const message = (event.data as { message?: { content?: readonly { type?: string; text?: string }[] } }).message
  const parts = message?.content
  if (!Array.isArray(parts)) return undefined
  const text = parts
    .filter(part => part?.type === 'text' && typeof part.text === 'string')
    .map(part => part.text as string)
    .join(' ')
  const line = singleLine(text)
  if (line === '') return undefined
  return line.length > FIRST_PROMPT_LABEL_CHARS ? `${line.slice(0, FIRST_PROMPT_LABEL_CHARS - 1)}…` : line
}
