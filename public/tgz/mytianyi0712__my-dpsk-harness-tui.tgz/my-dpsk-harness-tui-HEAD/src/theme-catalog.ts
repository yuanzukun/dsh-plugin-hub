/**
 * The theme ids this bundle ships, for the host-side one-time migration.
 *
 * The documents live in `renderer/src/theme/native/assets` and are bundled into the
 * renderer binary, so the host cannot read them as files: this list mirrors the
 * directory. `tests/theme-catalog.spec.ts` compares the two, so adding or removing a
 * document fails the gate instead of letting the migration keep a dead id.
 *
 * `system` is built at runtime from the terminal palette and is always selectable;
 * `opencode2` is only offered while the `new-designs` experiment is on, so the
 * migration accepts it but never keeps it for a user who has the experiment off.
 */

/** Theme ids backed by a shipped document in `renderer/src/theme/native/assets`. */
export const SHIPPED_THEME_IDS = [
  'aura',
  'ayu',
  'carbonfox',
  'catppuccin',
  'catppuccin-frappe',
  'catppuccin-macchiato',
  'cobalt2',
  'cursor',
  'dracula',
  'everforest',
  'flexoki',
  'github',
  'gruvbox',
  'kanagawa',
  'lucent-orng',
  'material',
  'matrix',
  'mercury',
  'monokai',
  'nightowl',
  'nord',
  'one-dark',
  'opencode',
  'orng',
  'osaka-jade',
  'palenight',
  'rosepine',
  'solarized',
  'synthwave84',
  'tokyonight',
  'vercel',
  'vesper',
  'zenburn',
] as const

/** The id a selection falls back to when the requested one is not shipped. */
export const FALLBACK_THEME_ID = 'opencode'

/** Every id a persisted `themeName` may carry: shipped documents, `system`, and the experiment. */
export const SELECTABLE_THEME_IDS: readonly string[] = [...SHIPPED_THEME_IDS, 'system', 'opencode2']

/** Whether a persisted theme id names a theme this bundle can really load. */
export function isSelectableTheme(id: string): boolean {
  return SELECTABLE_THEME_IDS.includes(id)
}
