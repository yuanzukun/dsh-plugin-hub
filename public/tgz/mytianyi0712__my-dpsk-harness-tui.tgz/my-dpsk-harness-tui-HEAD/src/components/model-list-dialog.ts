import {
  defaultEffortOf,
  formatReasoningEffortSetting,
  parseReasoningEffortSetting,
  type ReasoningEffortSetting,
} from '../reasoning-maps.ts'

export interface ProviderModelDraft {
  id: string
  name?: string
  /** Official dsh UI level → wire value (`off: none, high: high, max: max`), or `false` for non-reasoning. */
  reasoningEfforts?: ReasoningEffortSetting
  /** Selected official UI level (`max`, `high`, …), not the wire spelling. */
  reasoningEffort?: string
  contextWindow?: number
  maxTokens?: number
}

type FieldId = 'id' | 'name' | 'efforts' | 'effort' | 'contextWindow' | 'maxTokens'
type ModelRow = { kind: 'model'; index: number }
type FieldRow = { kind: 'field'; index: number; field: FieldId }
type ActionRow = { kind: 'action'; id: 'add' | 'done' | 'cancel' }
type Row = ModelRow | FieldRow | ActionRow

const FIELD_ORDER: FieldId[] = ['id', 'name', 'efforts', 'effort', 'contextWindow', 'maxTokens']

export function parseReasoningEfforts(value: string | readonly string[] | ReasoningEffortSetting | undefined): ReasoningEffortSetting | undefined {
  return parseReasoningEffortSetting(value)
}

export function formatReasoningEfforts(efforts: ReasoningEffortSetting | readonly string[] | undefined): string {
  return formatReasoningEffortSetting(parseReasoningEffortSetting(efforts))
}


export function normalizeProviderModels(
  models: readonly (string | ProviderModelDraft)[],
): ProviderModelDraft[] {
  const seen = new Set<string>()
  const result: ProviderModelDraft[] = []
  for (const entry of models) {
    const id = (typeof entry === 'string' ? entry : entry.id).trim()
    if (id === '' || seen.has(id)) continue
    seen.add(id)
    if (typeof entry === 'string') {
      result.push({ id })
      continue
    }
    const reasoningEfforts = parseReasoningEffortSetting(entry.reasoningEfforts)
    const reasoningEffort = defaultEffortOf(reasoningEfforts, entry.reasoningEffort?.trim())
    const name = entry.name?.trim()
    result.push({
      id,
      ...(name !== undefined && name !== '' && name !== id ? { name } : {}),
      ...(reasoningEfforts === undefined ? {} : { reasoningEfforts }),
      ...(reasoningEffort === undefined ? {} : { reasoningEffort }),
      ...(typeof entry.contextWindow === 'number' && entry.contextWindow > 0 ? { contextWindow: entry.contextWindow } : {}),
      ...(typeof entry.maxTokens === 'number' && entry.maxTokens > 0 ? { maxTokens: entry.maxTokens } : {}),
    })
  }
  return result
}

