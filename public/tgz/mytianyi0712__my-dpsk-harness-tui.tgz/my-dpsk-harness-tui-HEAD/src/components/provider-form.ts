/**
 * The provider draft shape and the protocol identifiers the settings seam
 * accepts. The form UI lives in the renderer (`form-spec` / `form-submit`);
 * the host owns the draft read, the id rules, and the settings write.
 */

import { normalizeProviderModels, type ProviderModelDraft } from './model-list-dialog.ts'

export type { ProviderModelDraft } from './model-list-dialog.ts'

/** Protocol identifiers accepted by dsh-llm-pi-ai for hand-declared routes. */
export const SUPPORTED_PROVIDER_APIS = [
  'openai-completions',
  'openai-responses',
  'anthropic-messages',
] as const

export type SupportedProviderApi = typeof SUPPORTED_PROVIDER_APIS[number]




export interface ProviderDraft {
  /** Permanent dsh route id; lowercase kebab-case. */
  id: string
  /** Human-readable provider display name. */
  name: string
  /** dsh WebUI-compatible protocol type. */
  api: string
  baseURL: string
  /** New key value; an empty value keeps an existing credential. */
  apiKey: string
  /** Credential reference persisted in the provider profile. */
  apiKeyEnv?: string
  /** Whether the existing credential reference currently resolves. */
  apiKeyConfigured?: boolean
  models: ProviderModelDraft[]
}

export interface DiscoveredModel {
  id: string
  name?: string
}
