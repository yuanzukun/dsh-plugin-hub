/**
 * OMP-compatible transcript components adapted to DeepSeek Harness events:
 * responsive welcome panel, full-width user surfaces, unlabelled assistant
 * prose/reasoning, and lifecycle-aware tool output blocks.
 */

import {
  Container,
  Markdown,
  Spacer,
  Text,
  truncateToWidth,
  visibleWidth,
  type Component,
} from '@earendil-works/pi-tui'
import type { Agent, ModelSelection } from '../dsh-host/index.ts'
import type { ContentBlock, StreamChunk } from '../dsh-host/index.ts'
import type { SessionEvent, TodoItem } from '../dsh-host/index.ts'
import { frameBlock, frameBlockSections, gradientLogo, type MarkdownTheme, type Palette } from '../theme.ts'
import type { Translator } from '../i18n.ts'
import { contentText, parseArguments } from './content.ts'
import { displayText } from './text.ts'

const DSH_LOGO = [
  '██████╗ ███████╗██╗  ██╗',
  '██╔══██╗██╔════╝██║  ██║',
  '██║  ██║███████╗███████║',
  '██║  ██║╚════██║██╔══██║',
  '██████╔╝███████║██║  ██║',
]

/** Cache rendered rows for a component until its state or width changes. */
interface RenderCache {
  key: string
  lines: string[]
}

/**
 * Transcript viewport: renders all children, then returns only the visible
 * line window. In follow-latest mode the window stays anchored to the bottom
 * as live events arrive; paging up freezes the top offset for history reading.
 */
export class TranscriptViewport extends Container {
  lineOffset = 0
  followLatest = true
  lastTotalLines = 0
  lastViewportLines = 0

  constructor(private readonly resolveViewportHeight: (width: number) => number) {
    super()
  }

  override render(width: number): string[] {
    const allLines = super.render(width)
    const maxLines = Math.max(0, Math.floor(this.resolveViewportHeight(width)))
    const maxOffset = Math.max(0, allLines.length - maxLines)
    if (this.followLatest) {
      this.lineOffset = maxOffset
    } else {
      this.lineOffset = Math.max(0, Math.min(this.lineOffset, maxOffset))
    }
    this.lastTotalLines = allLines.length
    this.lastViewportLines = Math.max(0, Math.min(maxLines, allLines.length - this.lineOffset))
    if (allLines.length <= maxLines) return allLines
    return allLines.slice(this.lineOffset, this.lineOffset + maxLines)
  }
}

function cachedRender(
  cache: RenderCache | undefined,
  key: string,
  compute: () => string[],
): { cache: RenderCache; lines: string[] } {
  if (cache !== undefined && cache.key === key) return { cache, lines: cache.lines }
  const lines = compute()
  return { cache: { key, lines }, lines }
}

function fitWidth(text: string, width: number): string {
  const clipped = truncateToWidth(text, Math.max(0, width), '')
  return clipped + ' '.repeat(Math.max(0, width - visibleWidth(clipped)))
}

function center(text: string, width: number): string {
  const clipped = truncateToWidth(text, width, '')
  const space = Math.max(0, width - visibleWidth(clipped))
  const left = Math.floor(space / 2)
  return `${' '.repeat(left)}${clipped}${' '.repeat(space - left)}`
}

/** Wrap one plain-text line into rows no wider than `width` display columns. */
function wrapToWidth(text: string, width: number): string[] {
  // Materialize tabs exactly like displayText/pi-tui measure them (3 cells),
  // so the terminal's hardware tab stops can never reflow a wrapped row.
  const safeText = text.replace(/\t/g, '   ')
  const safeWidth = Math.max(1, width)
  if (visibleWidth(safeText) <= safeWidth) return [safeText]
  const rows: string[] = []
  let current = ''
  let currentWidth = 0
  for (const char of Array.from(safeText)) {
    const charWidth = visibleWidth(char)
    if (currentWidth + charWidth > safeWidth) {
      if (current !== '') rows.push(current)
      current = char
      currentWidth = charWidth
    } else {
      current += char
      currentWidth += charWidth
    }
  }
  if (current !== '') rows.push(current)
  return rows
}

/** Responsive two-column welcome panel following OMP's startup composition. */
export class HeaderComponent implements Component {
  private renderCache: RenderCache | undefined

  constructor(
    private readonly agent: Agent,
    private readonly subtitle: () => string | undefined,
    private readonly palette: Palette,
    private readonly gradient: boolean,
    private readonly t: Translator,
    private readonly selection?: () => ModelSelection | undefined,
  ) {}

  invalidate(): void {
    this.renderCache = undefined
  }

  render(width: number): string[] {
    const selection = this.selection?.()
    const cacheKey = `${width}|${selection?.model ?? ''}|${selection?.provider ?? ''}|${this.subtitle() ?? ''}`
    const cached = cachedRender(this.renderCache, cacheKey, () => this.renderUncached(width, selection))
    this.renderCache = cached.cache
    return cached.lines
  }

  private renderUncached(width: number, selection: ModelSelection | undefined): string[] {
    const boxWidth = Math.min(100, Math.max(0, width - 2))
    if (boxWidth < 4) return []

    const showRight = boxWidth >= 64
    const leftWidth = showRight ? Math.min(28, Math.floor((boxWidth - 3) * 0.36)) : boxWidth - 2
    const rightWidth = showRight ? boxWidth - leftWidth - 3 : 0
    const logo = this.gradient
      ? gradientLogo(DSH_LOGO)
      : DSH_LOGO.map(line => this.palette.accent(line))
    const model = displayText(String(selection?.model ?? this.agent.options.model ?? 'No model'))
    const provider = displayText(String(selection?.provider ?? this.agent.options.provider ?? 'DeepSeek'))
    const leftLines = [
      '',
      center(this.palette.bold(this.t('headerWelcome')), leftWidth),
      '',
      ...logo.map(line => center(line, leftWidth)),
      '',
      center(this.palette.muted(model), leftWidth),
      center(this.palette.dim(provider), leftWidth),
      '',
    ]

    const separator = ` ${this.palette.dim('─'.repeat(Math.max(0, rightWidth - 2)))}`
    const session = displayText(String(this.agent.session.id))
    const workspace = displayText(this.agent.session.header.cwd ?? process.cwd())
    const extra = this.subtitle()
    const rightLines = [
      ` ${this.palette.bold(this.palette.accent(this.t('headerTips')))}`,
      ` ${this.palette.dim('/')} ${this.palette.muted(this.t('headerCommands'))}`,
      ` ${this.palette.dim('@')} ${this.palette.muted(this.t('headerSessions'))}`,
      ` ${this.palette.dim('Tab')} ${this.palette.muted(this.t('headerComplete'))}`,
      ` ${this.palette.dim('Ctrl+O')} ${this.palette.muted(this.t('headerExpand'))}`,
      separator,
      ` ${this.palette.bold(this.palette.accent(this.t('headerSession')))}`,
      ` ${this.palette.muted(session)}`,
      ` ${this.palette.dim(this.t('headerWorkspace'))}`,
      ` ${this.palette.muted(workspace)}`,
      ...extra === undefined ? [] : [` ${this.palette.dim(displayText(extra))}`],
      '',
    ]

    const horizontal = '─'
    const title = truncateToWidth('─── dsh ', Math.max(0, boxWidth - 2), '')
    const top = this.palette.dim(
      `╭${title}${horizontal.repeat(Math.max(0, boxWidth - 2 - visibleWidth(title)))}╮`,
    )
    const vertical = this.palette.dim('│')
    const lines = [top]
    const rows = showRight ? Math.max(leftLines.length, rightLines.length) : leftLines.length
    for (let index = 0; index < rows; index++) {
      const left = fitWidth(leftLines[index] ?? '', leftWidth)
      if (showRight) {
        const right = fitWidth(rightLines[index] ?? '', rightWidth)
        lines.push(`${vertical}${left}${vertical}${right}${vertical}`)
      } else {
        lines.push(`${vertical}${left}${vertical}`)
      }
    }
    const bottom = showRight
      ? `╰${horizontal.repeat(leftWidth)}┴${horizontal.repeat(rightWidth)}╯`
      : `╰${horizontal.repeat(leftWidth)}╯`
    lines.push(this.palette.dim(bottom))
    if (boxWidth >= 24) {
      const tip = this.palette.italic(
        ` ${this.palette.accent(this.t('headerTip'))} ${this.palette.muted(this.t('headerTipBody'))}`,
      )
      lines.push(truncateToWidth(tip, boxWidth, ''))
    }
    return lines
  }
}

/** OMP user bubble: padded Markdown on a full-width mantle surface, no label or outline. */
export class UserMessageComponent extends Container {
  private renderCache: RenderCache | undefined

  constructor(text: string, private readonly palette: Palette, mdTheme: MarkdownTheme) {
    super()
    this.addChild(new Markdown(displayText(text), 1, 1, mdTheme, {
      color: (value: string) => palette.text(value),
    }, {
      preserveOrderedListMarkers: true,
      preserveBackslashEscapes: true,
    }))
  }

  override invalidate(): void {
    this.renderCache = undefined
    super.invalidate()
  }

  override render(width: number): string[] {
    const cached = cachedRender(this.renderCache, String(width), () =>
      super.render(width).map((row) => {
        const fill = ' '.repeat(Math.max(0, width - visibleWidth(row)))
        return this.palette.userMessageBg(`${row}${fill}`)
      }))
    this.renderCache = cached.cache
    return cached.lines
  }
}

/** OMP reasoning prose: inset, muted, italic, and deliberately unlabelled. */
export class ThinkingBlock extends Container {
  private renderCache: RenderCache | undefined

  constructor(reasoning: string, palette: Palette, mdTheme: MarkdownTheme) {
    super()
    this.addChild(new Markdown(displayText(reasoning), 1, 0, mdTheme, {
      color: (value: string) => palette.thinking(value),
      italic: true,
    }))
  }

  override invalidate(): void {
    this.renderCache = undefined
    super.invalidate()
  }

  override render(width: number): string[] {
    const cached = cachedRender(this.renderCache, String(width), () => super.render(width))
    this.renderCache = cached.cache
    return cached.lines
  }
}

/** Children of an assistant message: optional reasoning, then response prose. */
function assistantMessageChildren(
  content: readonly ContentBlock[],
  showReasoning: boolean,
  palette: Palette,
  mdTheme: MarkdownTheme,
): Component[] {
  const reasoning = displayText(textBlocks(content, 'reasoning').trim())
  const text = displayText(textBlocks(content, 'text').trim())
  const children: Component[] = []
  if (reasoning !== '' && showReasoning) children.push(new ThinkingBlock(reasoning, palette, mdTheme))
  if (text !== '') {
    if (children.length > 0) children.push(new Spacer(1))
    children.push(new Markdown(text, 1, 0, mdTheme, {
      color: (value: string) => palette.text(value),
    }))
  }
  return children
}

/** Concatenate the text of every block of one type, separated by blank lines. */
function textBlocks(content: readonly ContentBlock[], type: 'text' | 'reasoning'): string {
  return content
    .filter((block): block is Extract<ContentBlock, { type: typeof type }> => block.type === type)
    .map(block => block.text)
    .join('\n\n')
}

interface StreamingBlock {
  type: string
  text: string
}

/** A live assistant step: streamed reasoning/text blocks until the message settles. */
export class StreamingAssistantComponent extends Container {
  private readonly blocks = new Map<number, StreamingBlock>()
  private settledContent: readonly ContentBlock[] | undefined
  private renderCache: RenderCache | undefined

  constructor(
    private readonly palette: Palette,
    private readonly mdTheme: MarkdownTheme,
    private showReasoning: boolean,
  ) {
    super()
    this.rebuild()
  }

  override invalidate(): void {
    this.renderCache = undefined
    super.invalidate()
  }

  override render(width: number): string[] {
    const cached = cachedRender(this.renderCache, String(width), () => super.render(width))
    this.renderCache = cached.cache
    return cached.lines
  }

  /** Replace the streamed blocks with the step's settled content. */
  settle(content: readonly ContentBlock[]): void {
    this.settledContent = content
    this.rebuild()
  }

  /** Toggle whether reasoning blocks render, then re-render. */
  setShowReasoning(show: boolean): void {
    if (this.showReasoning === show) return
    this.showReasoning = show
    this.rebuild()
  }

  /** Fold one streamed chunk into the live block buffer and re-render. */
  update(chunk: StreamChunk): void {
    if (chunk.type === 'block-start') {
      this.blocks.set(chunk.index, { type: chunk.blockType, text: '' })
    } else if (chunk.type === 'text-delta' || chunk.type === 'reasoning-delta') {
      const type = chunk.type === 'text-delta' ? 'text' : 'reasoning'
      const block = this.blocks.get(chunk.index) ?? { type, text: '' }
      block.text += chunk.text
      this.blocks.set(chunk.index, block)
    } else if (chunk.type === 'block-end' && (chunk.block.type === 'text' || chunk.block.type === 'reasoning')) {
      this.blocks.set(chunk.index, { type: chunk.block.type, text: chunk.block.text })
    }
    this.rebuild()
  }

  private rebuild(): void {
    this.renderCache = undefined
    this.clear()
    const children = assistantMessageChildren(
      this.presentedContent(),
      this.showReasoning,
      this.palette,
      this.mdTheme,
    )
    for (const child of children) this.addChild(child)
  }

  /** The settled content when available, otherwise the streamed blocks in model order. */
  private presentedContent(): readonly ContentBlock[] {
    return this.settledContent ?? [...this.blocks.entries()]
      .sort(([left], [right]) => left - right)
      .flatMap<ContentBlock>(([, block]) => {
        if (block.type === 'text') return [{ type: 'text', text: block.text }]
        if (block.type === 'reasoning') return [{ type: 'reasoning', text: block.text }]
        return []
      })
  }
}

/**
 * Owns one live assistant step without mounting it at `step/start`.
 * DSH emits `step/start` before the turn's entered `user/message` events, so
 * the component joins the transcript only when assistant content materializes.
 */
export class AssistantStreamController {
  private current: StreamingAssistantComponent | undefined
  private mounted = false

  constructor(
    private readonly transcript: Container,
    private readonly palette: Palette,
    private readonly mdTheme: MarkdownTheme,
  ) {}

  /** Prepare an assistant step while preserving space for its input messages. */
  start(showReasoning: boolean): void {
    this.current = new StreamingAssistantComponent(this.palette, this.mdTheme, showReasoning)
    this.mounted = false
  }

  /** Append streamed content after every user/context message entered for this step. */
  update(chunk: StreamChunk): void {
    if (this.current === undefined) return
    this.current.update(chunk)
    this.mountCurrent()
  }

  /** Materialize providers that commit a message without publishing chunks. */
  settle(content: readonly ContentBlock[]): void {
    if (this.current === undefined) return
    this.current.settle(content)
    this.mountCurrent()
  }

  /** Detach controller state; already-mounted transcript content remains durable. */
  end(): void {
    this.current = undefined
    this.mounted = false
  }

  private mountCurrent(): void {
    if (this.current === undefined || this.mounted) return
    this.transcript.addChild(this.current)
    this.mounted = true
  }
}

function toolLabel(name: string): string {
  const safeName = name.trim() === '' ? 'unknown' : name
  return safeName
    .replace(/[-_]+/g, ' ')
    .replace(/\b\w/g, letter => letter.toUpperCase())
}

/** Summary key preference per tool variant, mirroring the official OMP tool row. */
const SUMMARY_KEYS: Readonly<Record<string, readonly string[]>> = {
  bash: ['command', 'description'],
  read: ['path', 'file_path', 'url'],
  search: ['query', 'pattern', 'url'],
  write: ['path', 'file_path'],
  edit: ['path', 'file_path'],
  code: ['description'],
}

function toolVariant(name: string): string {
  if (name === 'bash' || name === 'pwsh') return 'bash'
  if (name === 'read' || name === 'web_fetch') return 'read'
  if (name === 'web_search' || name === 'grep' || name === 'glob') return 'search'
  if (name === 'write') return 'write'
  if (name === 'edit') return 'edit'
  if (name === 'run_code') return 'code'
  return 'others'
}

/** Pick the first non-empty string arg for the given keys. */
function pickString(args: Record<string, unknown>, keys: readonly string[]): string | undefined {
  for (const key of keys) {
    const value = args[key]
    if (typeof value === 'string' && value.trim() !== '') {
      return displayText(value.trim())
    }
  }
  return undefined
}

/** Return a display-safe string argument, or an empty string when absent. */
function stringArg(args: Record<string, unknown>, key: string): string {
  const value = args[key]
  return typeof value === 'string' ? displayText(value) : ''
}

/**
 * `str_replace_editor` renders the model-facing edit content here because its
 * result text only says "edited successfully"; the actual old/new strings live
 * in the call arguments.
 */
function strReplaceEditorDetail(args: Record<string, unknown>): string {
  const path = stringArg(args, 'path')
  const command = stringArg(args, 'command')
  if (command === 'create') {
    return `path: ${path}\nfile_text:\n${stringArg(args, 'file_text')}`
  }
  if (command === 'str_replace') {
    return `path: ${path}\nold_str:\n${stringArg(args, 'old_str')}\nnew_str:\n${stringArg(args, 'new_str')}`
  }
  if (command === 'insert') {
    const line = typeof args.insert_line === 'number' ? String(args.insert_line) : ''
    return `path: ${path}\ninsert_line: ${line}\nnew_str:\n${stringArg(args, 'new_str')}`
  }
  if (command === 'view') {
    const range = Array.isArray(args.view_range) ? args.view_range.map(item => displayText(String(item))).join(', ') : ''
    return `path: ${path}${range === '' ? '' : `\nview_range: [${range}]`}`
  }
  return `path: ${path}${command === '' ? '' : `\ncommand: ${command}`}`
}

/** Build `Input`/`Diff` sections for a settled `str_replace_editor` call. */
function strReplaceEditorSections(
  argumentsJson: string,
  palette: Palette,
  width: number,
): { title: string; lines: string[] }[] {
  const parsed = parseArguments(argumentsJson)
  if (!parsed.valid || typeof parsed.value !== 'object' || parsed.value === null) return []
  const args = parsed.value as Record<string, unknown>
  const command = stringArg(args, 'command')
  const path = stringArg(args, 'path')
  const inputLines: string[] = []
  if (path !== '') inputLines.push(`path: ${path}`)
  if (command === 'view') {
    const range = Array.isArray(args.view_range) ? args.view_range.map(item => displayText(String(item))).join(', ') : ''
    if (range !== '') inputLines.push(`view_range: [${range}]`)
  }
  const sections: { title: string; lines: string[] }[] = []
  if (inputLines.length > 0) sections.push({ title: 'Input', lines: inputLines })

  const diffWidth = Math.max(1, width - 6)
  const plus = (line: string): string => palette.success(`+ ${line}`)
  const minus = (line: string): string => palette.error(`- ${line}`)
  const diffLines = (text: string, sign: 'plus' | 'minus'): string[] =>
    text.split('\n')
      .flatMap(line => wrapToWidth(line, diffWidth))
      .map(line => sign === 'plus' ? plus(line) : minus(line))

  if (command === 'create') {
    sections.push({ title: 'Diff', lines: diffLines(stringArg(args, 'file_text'), 'plus') })
  } else if (command === 'str_replace') {
    sections.push({
      title: 'Diff',
      lines: [
        ...diffLines(stringArg(args, 'old_str'), 'minus'),
        ...diffLines(stringArg(args, 'new_str'), 'plus'),
      ],
    })
  } else if (command === 'insert') {
    sections.push({ title: 'Diff', lines: diffLines(stringArg(args, 'new_str'), 'plus') })
  }
  return sections
}

/**
 * The concrete input content shown under the tool title and above `Output`:
 * a shell command, a path, a query, or the first meaningful string argument.
 */
function toolDetail(name: string, argumentsJson: string): string | undefined {
  const parsed = parseArguments(argumentsJson)
  if (!parsed.valid || typeof parsed.value !== 'object' || parsed.value === null) {
    const raw = displayText(argumentsJson).trim()
    return raw === '' ? undefined : raw
  }
  const args = parsed.value as Record<string, unknown>
  if (name === 'str_replace_editor') return strReplaceEditorDetail(args)
  const picked = pickString(args, SUMMARY_KEYS[toolVariant(name)] ?? [])
  if (picked !== undefined) return picked
  for (const value of Object.values(args)) {
    if (typeof value === 'string' && value.trim() !== '') {
      return displayText(value.trim())
    }
  }
  const raw = displayText(argumentsJson).trim()
  return raw === '' ? undefined : raw
}

/**
 * OMP tool lifecycle: pending calls are one quiet status row; settled calls
 * become rounded output blocks with a titled `Output` separator.
 */
export class ToolCardComponent implements Component {
  private result: { content: ContentBlock[]; isError: boolean } | undefined
  private visibility: ToolCardVisibility = 'collapsed'
  private renderCache: RenderCache | undefined

  constructor(
    private readonly name: string,
    private readonly argumentsJson: string,
    private readonly maxOutputLines: number,
    private readonly palette: Palette,
  ) {}

  /** Record the tool result. */
  updateResult(event: Extract<SessionEvent, { type: 'tool/result' }>['data']): void {
    const message = event.message
    this.result = {
      content: [...message.content],
      isError: message.isError === true,
    }
    this.renderCache = undefined
  }

  /** Set the card's visibility state. */
  setVisibility(visibility: ToolCardVisibility): void {
    if (this.visibility === visibility) return
    this.visibility = visibility
    this.renderCache = undefined
  }

  invalidate(): void {
    this.renderCache = undefined
  }

  render(width: number): string[] {
    const cacheKey = `${width}|${this.visibility}|${this.result?.isError ?? ''}`
    const cached = cachedRender(this.renderCache, cacheKey, () => this.renderUncached(width))
    this.renderCache = cached.cache
    return cached.lines
  }

  private renderUncached(width: number): string[] {
    if (this.visibility === 'hidden') return []
    const title = toolLabel(displayText(this.name))
    const detail = toolDetail(this.name, this.argumentsJson)
    if (this.result === undefined) {
      const pending = `${this.palette.warning('')} ${this.palette.toolTitle(title)}`
      const rows = ['', truncateToWidth(pending, Math.max(1, width), '')]
      if (detail !== undefined) {
        for (const line of detail.split('\n').flatMap(line => wrapToWidth(line, Math.max(1, width - 3)))) {
          rows.push(truncateToWidth(`   ${this.palette.muted(line)}`, Math.max(1, width), ''))
        }
      }
      return rows
    }

    const isError = this.result.isError
    const statusColor = isError ? this.palette.error : this.palette.dim
    const statusBg = isError ? this.palette.toolErrorBg : this.palette.toolSuccessBg
    const glyph = isError ? '' : '•'
    const header = isError
      ? this.palette.error(`${glyph} ${title}`)
      : `${this.palette.dim(glyph)} ${this.palette.toolTitle(title)}`
    const output = displayText(contentText(this.result.content).trim())
    let outputLines = output === '' ? [this.palette.dim('(no output)')] : output.split('\n')
    if (this.visibility === 'collapsed' && outputLines.length > this.maxOutputLines) {
      const hidden = outputLines.length - this.maxOutputLines
      outputLines = [
        ...outputLines.slice(0, this.maxOutputLines),
        this.palette.dim(`… +${hidden} lines (Ctrl+O to expand)`),
      ]
    }
    const sections: { title: string; lines: string[] }[] = []
    const editorSections = this.name === 'str_replace_editor'
      ? strReplaceEditorSections(this.argumentsJson, this.palette, width)
      : []
    if (editorSections.length > 0) {
      sections.push(...editorSections)
    } else if (detail !== undefined) {
      const inputLines = detail
        .split('\n')
        .flatMap(line => wrapToWidth(line, Math.max(1, width - 4)))
        .map(line => this.palette.muted(line))
      sections.push({ title: 'Input', lines: inputLines })
    }
    sections.push({ title: 'Output', lines: outputLines.map(line => this.palette.toolOutput(line)) })
    return [
      '',
      ...frameBlockSections(width, statusColor, statusBg, header, sections),
    ]
  }
}

/** Ctrl+O card-visibility cycle: hidden, collapsed preview, expanded. */
export type ToolCardVisibility = 'hidden' | 'collapsed' | 'expanded'

/**
 * A non-human prompt contribution (plugin/goal sources), framed so it cannot
 * be mistaken for the assistant's unframed italic reasoning prose.
 */
export class ContextCardComponent implements Component {
  private readonly fullLines: string[]
  private readonly title: string
  private visibility: ToolCardVisibility = 'collapsed'
  private renderCache: RenderCache | undefined

  constructor(
    label: string,
    text: string,
    private readonly maxOutputLines: number,
    private readonly palette: Palette,
  ) {
    this.fullLines = displayText(text).split('\n')
    this.title = `${palette.context('Injected context')} ${palette.dim(`· ${displayText(label)}`)}`
  }

  setVisibility(visibility: ToolCardVisibility): void {
    if (this.visibility === visibility) return
    this.visibility = visibility
    this.renderCache = undefined
  }

  invalidate(): void {
    this.renderCache = undefined
  }

  render(width: number): string[] {
    const cacheKey = `${width}|${this.visibility}`
    const cached = cachedRender(this.renderCache, cacheKey, () => {
      let linesToRender: string[]
      let truncated = false
      if (this.visibility === 'hidden') return []
      if (this.visibility === 'collapsed' && this.fullLines.length > this.maxOutputLines) {
        const hidden = this.fullLines.length - this.maxOutputLines
        linesToRender = [...this.fullLines.slice(0, this.maxOutputLines), `… +${hidden} lines (Ctrl+O to expand)`]
        truncated = true
      } else {
        linesToRender = this.fullLines
      }
      const body = new Text(linesToRender.map((line, index) =>
        truncated && index >= this.maxOutputLines ? this.palette.dim(line) : this.palette.muted(line)).join('\n'), 0, 0)
      const rows = body.render(Math.max(1, width - 4))
      return frameBlock(rows, width, this.palette.borderMuted, this.palette.toolPendingBg, this.title)
    })
    this.renderCache = cached.cache
    return cached.lines
  }
}

/** A static framed block of pre-rendered rows (e.g. the `/palette` listing). */
export class StaticCardComponent implements Component {
  private renderCache: RenderCache | undefined

  constructor(
    private readonly rows: readonly string[],
    private readonly palette: Palette,
  ) {}

  invalidate(): void {
    this.renderCache = undefined
  }

  render(width: number): string[] {
    const cached = cachedRender(this.renderCache, String(width), () =>
      ['', ...frameBlock(this.rows, width, this.palette.borderMuted, this.palette.toolSuccessBg)])
    this.renderCache = cached.cache
    return cached.lines
  }
}

/**
 * The plan/todo panel rendered above the status line: the current goal plus
 * the whole-list `todo/write` snapshot, omp `Plan` style. Renders nothing
 * while there is neither a goal nor any todo.
 */
/** A child subagent descriptor shown above the transcript. */
export interface SubagentDescriptor {
  readonly label?: string
  readonly provider: string
  readonly mode: 'one-shot' | 'continuable'
}

/** One-line notice for older transcript entries that are currently folded. */
export class TranscriptFoldNoticeComponent implements Component {
  constructor(
    private readonly resolveFolded: () => number,
    private readonly palette: Palette,
  ) {}

  invalidate(): void {}

  render(width: number): string[] {
    const folded = this.resolveFolded()
    if (folded <= 0) return []
    const line = this.palette.dim(`… 已折叠更早的 ${folded} 条记录`)
    return [truncateToWidth(line, Math.max(1, width), '')]
  }
}

/**
 * Subagent call panel rendered above the status line. The dsh harness appends
 * `subagent/descriptor` events to child session logs; when the active session
 * carries them (forked/child sessions), this panel keeps a tree-like list.
 */
export class SubagentPanelComponent implements Component {
  private descriptors: readonly SubagentDescriptor[] = []
  private renderCache: RenderCache | undefined

  constructor(private readonly palette: Palette) {}

  invalidate(): void {
    this.renderCache = undefined
  }

  add(descriptor: SubagentDescriptor): void {
    this.descriptors = [...this.descriptors, descriptor]
    this.renderCache = undefined
  }

  clear(): void {
    this.descriptors = []
    this.renderCache = undefined
  }

  render(width: number): string[] {
    const cacheKey = `${width}|${this.descriptors.map(descriptor => descriptor.label ?? descriptor.provider).join('\u0000')}`
    const cached = cachedRender(this.renderCache, cacheKey, () => this.renderUncached(width))
    this.renderCache = cached.cache
    return cached.lines
  }

  private renderUncached(width: number): string[] {
    if (this.descriptors.length === 0) return []
    const lines = [this.palette.bold(this.palette.accent('Subagents'))]
    this.descriptors.forEach((descriptor, index) => {
      const branch = index === this.descriptors.length - 1 ? '└─' : '├─'
      const name = descriptor.label ?? descriptor.provider
      lines.push(this.palette.muted(` ${branch} ${name} · ${descriptor.mode}`))
    })
    return lines.map(line => truncateToWidth(line, Math.max(1, width), ''))
  }
}

export class TodoPanelComponent implements Component {
  private todos: readonly TodoItem[] = []
  private goal: { readonly objective: string; readonly phase: string } | undefined
  private renderCache: RenderCache | undefined

  constructor(private readonly palette: Palette) {}

  invalidate(): void {
    this.renderCache = undefined
  }

  /** Replace the whole todo list (last `todo/write` wins). */
  setTodos(todos: readonly TodoItem[]): void {
    this.todos = todos
    this.renderCache = undefined
  }

  /** Replace the current goal snapshot, or clear it. */
  setGoal(goal: { readonly objective: string; readonly phase: string } | undefined): void {
    this.goal = goal
    this.renderCache = undefined
  }

  render(width: number): string[] {
    const cacheKey = `${width}|${this.todos.length}|${this.goal?.phase ?? ''}|${this.goal?.objective ?? ''}`
    const cached = cachedRender(this.renderCache, cacheKey, () => this.renderUncached(width))
    this.renderCache = cached.cache
    return cached.lines
  }

  private renderUncached(width: number): string[] {
    if (this.todos.length === 0 && this.goal === undefined) return []
    const lines: string[] = [this.palette.bold(this.palette.accent(' Plan'))]
    if (this.goal !== undefined) {
      lines.push(this.palette.dim(`Goal · ${this.goal.phase}: ${displayText(this.goal.objective)}`))
    }
    for (const todo of this.todos) {
      const mark = todo.status === 'completed' ? '󰄲' : todo.status === 'in_progress' ? '' : ''
      const color = todo.status === 'completed'
        ? this.palette.dim
        : todo.status === 'in_progress' ? this.palette.accent : this.palette.text
      lines.push(color(`${mark} ${displayText(todo.content)}`))
    }
    return lines.map(line => truncateToWidth(line, Math.max(1, width), ''))
  }
}
