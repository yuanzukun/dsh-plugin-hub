/** The session model route, the reasoning-effort chooser, and the context token formatter. */

import { ReasoningEffortId, type LlmReasoningEffortInfo } from '../dsh-host/index.ts'
import type { ModelSelection } from '../dsh-host/index.ts'
import type { EpochHeader } from '../dsh-host/index.ts'


/** Select the route a session will actually continue with. */
export function resolveSessionModelSelection(
  header: EpochHeader | undefined,
  fallback: ModelSelection,
  defaultReasoningEffort: string,
): ModelSelection {
  if (header === undefined) {
    return {
      provider: fallback.provider,
      model: fallback.model,
      reasoningEffort: fallback.reasoningEffort ?? ReasoningEffortId(defaultReasoningEffort),
    }
  }
  return {
    provider: header.config.provider,
    model: header.config.model,
    reasoningEffort: header.config.reasoningEffort ?? ReasoningEffortId(defaultReasoningEffort),
  }
}

export type ReasoningEffortChoice =
  | { kind: 'unsupported' }
  | { kind: 'unknown'; requested: string }
  | { kind: 'already'; effort: LlmReasoningEffortInfo }
  | { kind: 'selected'; effort: LlmReasoningEffortInfo }

/** Fallback cycle when a model does not advertise selectable efforts. */
export const FALLBACK_REASONING_EFFORTS = ['off', 'low', 'high', 'max'] as const

/**
 * Cycle one model's stored thinking level: inherit (undefined) then advertised
 * ids, or the common off/low/high/max ladder when the adapter exposes none.
 */
export function nextModelReasoningEffort(
  current: string | undefined,
  advertisedIds: readonly string[],
): string | undefined {
  const ids = advertisedIds.length > 0 ? [...advertisedIds] : [...FALLBACK_REASONING_EFFORTS]
  const cycle: Array<string | undefined> = [undefined, ...ids]
  const index = cycle.findIndex(id => id === current)
  const from = index >= 0 ? index : 0
  return cycle[(from + 1) % cycle.length]
}

/** Resolve an explicit effort or cycle through the model's advertised order. */
export function chooseReasoningEffort(
  efforts: readonly LlmReasoningEffortInfo[],
  current: ModelSelection['reasoningEffort'],
  requested: string,
): ReasoningEffortChoice {
  if (efforts.length === 0) return { kind: 'unsupported' }
  let target: LlmReasoningEffortInfo | undefined
  if (requested === '') {
    const currentIndex = efforts.findIndex(effort => effort.id === current)
    target = efforts[(currentIndex + 1) % efforts.length]
  } else {
    target = efforts.find(effort => effort.id === requested)
    if (target === undefined) return { kind: 'unknown', requested }
  }
  if (target === undefined) return { kind: 'unsupported' }
  return target.id === current ? { kind: 'already', effort: target } : { kind: 'selected', effort: target }
}

/** Compact token counts for the footer: 100000 → `100k`, 1000000 → `1m`. */
export function formatContextTokens(count: number): string {
  const safe = Math.max(0, Math.floor(count))
  if (safe >= 1_000_000) return `${compactUnit(safe / 1_000_000)}m`
  if (safe >= 1_000) return `${compactUnit(safe / 1_000)}k`
  return String(safe)
}

function compactUnit(value: number): string {
  return Number.isInteger(value) ? String(value) : value.toFixed(1).replace(/\.0$/, '')
}

