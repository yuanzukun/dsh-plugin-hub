/**
 * One-time settings namespace migration for 0.5.0.
 *
 * 0.5.0 renames the two profile rows that own this bundle's settings sections:
 * `tui` → `dpsk-tui` and `session-title-llm-tui` → `dpsk-session-title`. A
 * settings section is keyed by the row id, so values written under the old row
 * ids (by `/settings`, `/theme`, `/title-model`) become inert once the rows are
 * renamed.
 *
 * Startup stays deterministic: `readLegacySettings` reads the profile patch
 * layer synchronously in the TUI constructor, so the legacy values are available
 * as fallbacks before the first paint. `persistLegacySettings` then writes them
 * into the new namespaces asynchronously, skipping any field the new namespace
 * already carries, so a restart never overwrites a newer user choice.
 */

import { readFileSync } from 'node:fs'
import { FALLBACK_THEME_ID, isSelectableTheme } from './theme-catalog.ts'
import { CORE_SCHEMA, load as loadYaml, Type } from 'js-yaml'
import { settingsDocumentPath, settingsValues, type Context, type SettingsNamespace } from './dsh-host/index.ts'
import {
  LEGACY_SESSION_TITLE_ROW,
  LEGACY_TUI_SETTINGS_ROW,
  SESSION_TITLE_SETTINGS_NAMESPACE,
  TUI_SETTINGS_NAMESPACE,
} from './settings.ts'

/**
 * A profile patch layer uses cordis' `!!js` tag for computed values. Plain
 * `js-yaml.load` throws `unknown tag` on those documents, which would make the
 * whole patch layer unreadable. The scalar type below captures `!!js` as its
 * raw source text: migration only reads literal `config` values, so it never
 * evaluates harness expressions.
 */
const cordisJsTag = new Type('tag:yaml.org,2002:js', { kind: 'scalar', construct: (data: string) => data })
const patchSchema = CORE_SCHEMA.extend([cordisJsTag])

/** One patch layer entry; `insert` nests entries the same way `cordis.patch.yml` does. */
interface PatchEntry {
  id?: unknown
  config?: unknown
  insert?: unknown
}

function walkEntries(node: unknown, visit: (entry: PatchEntry) => void): void {
  if (Array.isArray(node)) {
    for (const item of node) walkEntries(item, visit)
    return
  }
  if (typeof node !== 'object' || node === null) return
  const entry = node as PatchEntry
  visit(entry)
  if (Array.isArray(entry.insert)) walkEntries(entry.insert, visit)
}

/** Config values written under one legacy row id, merged across patch layers. */
function configForRow(text: string, rowId: string): Record<string, unknown> | undefined {
  let parsed: unknown
  try {
    parsed = loadYaml(text, { schema: patchSchema })
  } catch {
    return undefined
  }
  const found: Record<string, unknown> = {}
  let seen = false
  walkEntries(parsed, entry => {
    if (entry.id !== rowId) return
    if (typeof entry.config !== 'object' || entry.config === null) return
    seen = true
    for (const [key, value] of Object.entries(entry.config as Record<string, unknown>)) {
      found[key] = value
    }
  })
  return seen ? found : undefined
}

/** Legacy settings values read from the profile patch layer. */
export interface LegacySettings {
  /** Values written under the pre-0.5.0 `tui` row. */
  tui: Record<string, unknown> | undefined
  /** Values written under the pre-0.5.0 `session-title-llm-tui` row. */
  sessionTitle: Record<string, unknown> | undefined
  /** The patch layer the values were read from; undefined when unavailable. */
  source: string | undefined
}

/**
 * Read legacy settings synchronously so the TUI can use them before first paint.
 * Returns an empty result when settings are unavailable (no profile context) or
 * the patch layer cannot be read; migration never blocks startup.
 */
export function readLegacySettings(ctx: Context): LegacySettings {
  const path = settingsDocumentPath(ctx)
  if (path === undefined) return { tui: undefined, sessionTitle: undefined, source: undefined }
  let text: string
  try {
    text = readFileSync(path, 'utf8')
  } catch {
    return { tui: undefined, sessionTitle: undefined, source: undefined }
  }
  return {
    tui: configForRow(text, LEGACY_TUI_SETTINGS_ROW),
    sessionTitle: configForRow(text, LEGACY_SESSION_TITLE_ROW),
    source: path,
  }
}

/** 0.4.0 theme fields the native catalog replaced; only migration inputs now. */
const LEGACY_THEME_KEYS = new Set(['themeDark', 'themeLight', 'themeSelected', 'themeCustom', 'themeSchema'])

export interface MigrationReport {
  /** Fields moved into a new namespace, as `<namespace>.<field>`. */
  migrated: string[]
  /** Fields left in place because the new namespace already carries a value. */
  skipped: string[]
  /** Legacy theme ids the native catalog no longer offers, reported once. */
  unavailableThemes: string[]
}

/**
 * Persist legacy values into the 0.5.0 namespaces, skipping fields the new
 * namespace already carries. Idempotent: a restart after migration writes
 * nothing.
 */
export async function persistLegacySettings(
  ctx: Context,
  legacy: LegacySettings,
): Promise<MigrationReport> {
  const report: MigrationReport = {
    migrated: [],
    skipped: [],
    unavailableThemes: [],
  }
  const forms = ctx.settings
  if (forms === undefined) return report

  const plan: readonly { readonly legacy: Record<string, unknown> | undefined; readonly ns: SettingsNamespace }[] = [
    { legacy: legacy.tui, ns: TUI_SETTINGS_NAMESPACE },
    { legacy: legacy.sessionTitle, ns: SESSION_TITLE_SETTINGS_NAMESPACE },
  ]

  for (const { legacy: values, ns } of plan) {
    if (values === undefined) continue
    const current = settingsValues(ctx, ns) as Record<string, unknown> | undefined
    const patch: Record<string, unknown> = {}
    for (const [key, value] of Object.entries(values)) {
      if (current !== undefined && current[key] !== undefined) {
        report.skipped.push(`${ns}.${key}`)
        continue
      }
      // The 0.4.0 theme fields (`themeDark` / `themeLight` / `themeSelected` /
      // `themeCustom` / `themeSchema`) name a palette this bundle no longer owns: the
      // native renderer catalog replaces it. They are not copied into the new section;
      // the native fields (`themeName` / `themeMode` / `newDesigns`) are written from
      // their defaults by `migrateNativeTheme` instead, so a stale id cannot win.
      if (LEGACY_THEME_KEYS.has(key)) {
        report.skipped.push(`${ns}.${key}`)
        continue
      }
      patch[key] = value
      report.migrated.push(`${ns}.${key}`)
    }
    if (Object.keys(patch).length === 0) continue
    await forms.update(ns, patch)
  }

  return report
}

/**
 * The 0.4.0 `themeDark` / `themeLight` / `themeSelected` triple named a palette this
 * bundle no longer owns. The native catalog replaces it once:
 *
 * - a new selection already persisted (`themeName`) is never overwritten;
 * - otherwise the old selected id is kept when the native catalog really ships it;
 * - an id the catalog does not know falls back to `opencode`, and the report says so;
 * - the old `dynamic` / `selected` mode collapses to `system`, because the native
 *   model is `system | dark | light` and a removed pair cannot be reconstructed.
 *
 * The legacy `themeDark` / `themeLight` pair is deliberately not resolved into a new
 * pair: the renderer follows the terminal in `system` mode, which is what an old
 * `dynamic` selection meant.
 */
export async function migrateLegacyTheme(
  ctx: Context,
  legacy: Record<string, unknown> | undefined,
  report: MigrationReport,
): Promise<void> {
  const forms = ctx.settings
  if (forms === undefined || legacy === undefined) return
  const current = settingsValues(ctx, TUI_SETTINGS_NAMESPACE) as Record<string, unknown> | undefined
  const patch: Record<string, unknown> = {}
  if (current?.themeName === undefined) {
    const selected = typeof legacy.themeSelected === 'string' ? legacy.themeSelected : undefined
    if (selected !== undefined && selected !== '') {
      if (isSelectableTheme(selected)) {
        patch.themeName = selected
      } else {
        patch.themeName = FALLBACK_THEME_ID
        report.unavailableThemes.push(selected)
      }
    }
  }
  if (current?.themeMode === undefined && legacy.themeMode !== undefined) {
    // Anything that is not a pinned native mode becomes `system`; a stale `selected`
    // or `dynamic` must not reach the provider.
    const mode = legacy.themeMode
    patch.themeMode = mode === 'dark' || mode === 'light' ? mode : 'system'
  }
  if (Object.keys(patch).length === 0) return
  await forms.update(TUI_SETTINGS_NAMESPACE, patch)
  for (const key of Object.keys(patch)) report.migrated.push(`${TUI_SETTINGS_NAMESPACE}.${key}`)
}

/** Human-readable migration report for the startup notice. */
export function formatMigrationReport(report: MigrationReport, source: string | undefined): string[] {
  const lines: string[] = []
  if (report.migrated.length === 0) return lines
  lines.push(`settings 命名空间迁移（0.5.0）：tui → dpsk-tui，session-title-llm-tui → dpsk-session-title`)
  for (const key of report.migrated) lines.push(`  迁移: ${key}`)
  for (const key of report.skipped) lines.push(`  保留新值: ${key}`)
  for (const name of report.unavailableThemes) lines.push(`  主题 ${name} 不再是可用主题，已回到 opencode`)
  if (source !== undefined) lines.push(`  来源: ${source}`)
  return lines
}
