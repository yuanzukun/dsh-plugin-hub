/**
 * One-time `cli.json` import for 0.5.0.
 *
 * opencode v2 keeps its TUI preferences in `cli.json` (`~/.config/opencode/cli.json`
 * or the file `OPENCODE_TUI_CONFIG` points at). A user moving to this bundle
 * already has that file, so the supported fields are imported once at startup
 * into the `dpsk-tui` settings section and reported through the startup notices.
 *
 * The import is one-directional and never overwrites a field the section already
 * carries, so a restart after the import writes nothing. Keys this bundle has no
 * slot for are reported as ignored rather than dropped silently.
 */

import { existsSync, readFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

/**
 * The `cli.json` the user has, or `undefined` when there is none.
 *
 * `OPENCODE_TUI_CONFIG` is authoritative: when it is set and the file is missing,
 * the import reports nothing rather than silently reading a different config.
 */
export function cliConfigPath(env: Record<string, string | undefined> = process.env): string | undefined {
  const explicit = env.OPENCODE_TUI_CONFIG
  if (explicit !== undefined) return existsSync(explicit) ? explicit : undefined
  const path = join(homedir(), '.config', 'opencode', 'cli.json')
  return existsSync(path) ? path : undefined
}

/** Parse `cli.json`. A malformed or non-object document yields `undefined`. */
export function readCliConfig(path: string): Record<string, unknown> | undefined {
  let text: string
  try {
    text = readFileSync(path, 'utf8')
  } catch {
    return undefined
  }
  let parsed: unknown
  try {
    parsed = JSON.parse(text)
  } catch {
    return undefined
  }
  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) return undefined
  return parsed as Record<string, unknown>
}

export interface CliImportPlan {
  /** Settings fields to write, in the `dpsk-tui` section's spelling. */
  patch: Record<string, unknown>
  /** One `cli.json` key and the settings fields it writes. */
  imported: Array<{ key: string; fields: string[] }>
  /** Keys with no slot in this bundle, reported so the user knows they stayed. */
  ignored: string[]
}

/**
 * `cli.json` key → the settings fields it writes, and the value type it needs.
 *
 * `theme` is not imported: the renderer owns the theme catalog now (its own
 * `theme.name` row), so an opencode theme id would name a theme this bundle does
 * not ship. The key is reported as ignored instead of writing a dead id.
 */
const CLI_FIELDS: readonly { key: string; type: 'string' | 'number' | 'boolean' | 'object'; fields: readonly string[]; write: (patch: Record<string, unknown>, value: unknown) => void }[] = [
  { key: 'keybinds', type: 'object', fields: ['keybinds'], write: (patch, value) => { patch.keybinds = value as Record<string, string> } },
  { key: 'leader_timeout', type: 'number', fields: ['leaderTimeout'], write: (patch, value) => { patch.leaderTimeout = Math.trunc(value as number) } },
  { key: 'scroll_speed', type: 'number', fields: ['scrollSpeed'], write: (patch, value) => { patch.scrollSpeed = Math.trunc(value as number) } },
  { key: 'scroll_acceleration', type: 'boolean', fields: ['scrollAcceleration'], write: (patch, value) => { patch.scrollAcceleration = value as boolean } },
  { key: 'diff_style', type: 'string', fields: ['diffStyle'], write: (patch, value) => { patch.diffStyle = value as string } },
  { key: 'cursor', type: 'string', fields: ['cursor'], write: (patch, value) => { patch.cursor = value as string } },
  { key: 'mouse', type: 'boolean', fields: ['mouse'], write: (patch, value) => { patch.mouse = value as boolean } },
]

/**
 * Every settings field the one-time import may write, plus the stamp that makes it
 * one-time. `tests/config-volatile.spec.ts` asserts each one is declared volatile in
 * `TuiConfigSchema`; a field missing there makes dsh's settings service reject the whole
 * patch (`Config field "…" is not volatile`), which is how the import used to fail on
 * every startup.
 */
export const CLI_IMPORT_FIELDS: readonly string[] = [
  ...CLI_FIELDS.flatMap(entry => entry.fields),
  'cliImportedAt',
]

/** Map a `cli.json` document onto the settings section. */
export function cliImportPlan(config: Record<string, unknown>): CliImportPlan {
  const patch: Record<string, unknown> = {}
  const imported: Array<{ key: string; fields: string[] }> = []
  const ignored: string[] = []
  const byKey = new Map(CLI_FIELDS.map(entry => [entry.key, entry]))
  for (const [key, value] of Object.entries(config)) {
    const entry = byKey.get(key)
    if (entry === undefined) {
      ignored.push(key)
      continue
    }
    const usable = entry.type === 'object'
      ? typeof value === 'object' && value !== null && !Array.isArray(value)
      : typeof value === entry.type
    if (!usable) {
      ignored.push(key)
      continue
    }
    entry.write(patch, value)
    imported.push({ key, fields: [...entry.fields] })
  }
  return { patch, imported, ignored }
}

/**
 * The fields that are safe to write: the section's existing values win, so the
 * import never overwrites a choice the user already made in this bundle.
 */
export function filterCliImportPatch(
  patch: Record<string, unknown>,
  current: Record<string, unknown> | undefined,
): { writable: Record<string, unknown>; skipped: string[] } {
  const writable: Record<string, unknown> = {}
  const skipped: string[] = []
  for (const [key, value] of Object.entries(patch)) {
    if (current !== undefined && current[key] !== undefined) {
      skipped.push(key)
      continue
    }
    writable[key] = value
  }
  return { writable, skipped }
}

/** Human-readable import report for the startup notices. */
export function formatCliImportReport(plan: CliImportPlan, skipped: string[], path: string): string[] {
  const lines: string[] = []
  if (plan.imported.length === 0 && skipped.length === 0 && plan.ignored.length === 0) return lines
  lines.push(`cli.json 一次性导入（0.5.0）：${path}`)
  for (const entry of plan.imported) {
    // A key can write several fields; only the ones that actually moved are reported.
    const written = entry.fields.filter(field => !skipped.includes(field))
    if (written.length === 0) continue
    lines.push(`  导入: ${entry.key} → ${written.join(' + ')}`)
  }
  for (const field of skipped) lines.push(`  保留已有值: ${field}`)
  for (const key of plan.ignored) lines.push(`  忽略: ${key}（本包无对应设置项）`)
  return lines
}
