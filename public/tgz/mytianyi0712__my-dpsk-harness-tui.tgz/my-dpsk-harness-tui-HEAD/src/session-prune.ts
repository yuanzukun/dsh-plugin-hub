/**
 * Conservative cleanup for abandoned, setup-only TUI sessions.
 *
 * The conversation-gated persistence decorator prevents new blank artifacts, but builds
 * before it left four-event `tui-*` directories behind. Cleanup only removes a directory
 * when all of the following are true:
 * - the session id came from the backend's own `list()` result and starts with `tui-`;
 * - the directory basename is exactly that id and contains `session.v4.jsonl.zstd`;
 * - the session is not live in this process;
 * - a reader-confirmed blank predicate says its log has no conversation event.
 * Symlinks are never followed and unreadable sessions are kept.
 */

import { readdir, rm } from 'node:fs/promises'
import { join } from 'node:path'

export interface PruneBlankTuiSessionsOptions {
  /** `$DSH_HOME/sessions`. */
  readonly root: string
  /** Session ids the persistence backend knows about. */
  readonly candidateIds: ReadonlySet<string>
  /** Sessions currently owned by a live agent. */
  readonly liveIds: ReadonlySet<string>
  /** Runs only after the candidate checks; must reject/throw for an unreadable session. */
  readonly isBlank: (id: string) => Promise<boolean>
  /** Find and report candidates without deleting them. */
  readonly dryRun?: boolean
}

export interface PruneBlankTuiSessionsResult {
  readonly inspected: number
  readonly removed: readonly string[]
  readonly failed: readonly { readonly id: string; readonly error: string }[]
}

async function collectTuiSessionDirectories(root: string): Promise<Map<string, string>> {
  const found = new Map<string, string>()
  const walk = async (directory: string, depth: number): Promise<void> => {
    if (depth > 4) return
    let entries
    try {
      entries = await readdir(directory, { withFileTypes: true })
    } catch {
      return
    }
    for (const entry of entries) {
      if (!entry.isDirectory()) continue
      const absolute = join(directory, entry.name)
      if (entry.name.startsWith('tui-')) found.set(entry.name, absolute)
      await walk(absolute, depth + 1)
    }
  }
  await walk(root, 0)
  return found
}

async function containsSessionLog(directory: string): Promise<boolean> {
  try {
    return (await readdir(directory)).includes('session.v4.jsonl.zstd')
  } catch {
    return false
  }
}

export async function pruneBlankTuiSessionDirectories(
  options: PruneBlankTuiSessionsOptions,
): Promise<PruneBlankTuiSessionsResult> {
  const directories = await collectTuiSessionDirectories(options.root)
  const removed: string[] = []
  const failed: Array<{ id: string; error: string }> = []
  let inspected = 0
  // Sort for deterministic reports and tests.
  for (const [id, directory] of [...directories.entries()].sort(([left], [right]) => left.localeCompare(right))) {
    if (!options.candidateIds.has(id) || options.liveIds.has(id)) continue
    if (!(await containsSessionLog(directory))) continue
    inspected += 1
    try {
      if (!(await options.isBlank(id))) continue
      if (options.dryRun !== true) await rm(directory, { recursive: true, force: false })
      removed.push(id)
    } catch (error: unknown) {
      failed.push({ id, error: error instanceof Error ? error.message : String(error) })
    }
  }
  return { inspected, removed, failed }
}
