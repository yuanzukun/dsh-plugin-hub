// dsh/status.ts — 微信桥持久状态：连接情况 + 接收锁归属。
// TUI 订阅后把这条状态显示在右侧栏；普通运行日志不会进入 TUI。
// `text` 仍按旧格式拼接（只认单行的消费者不变），同时下发结构化字段供侧栏分行绘制。

import { loadAccounts } from '../core/state.ts'
import { getMonitor } from '../core/monitors.ts'
import { isReceiverHeld, publishStatus, type WechatStatusState } from '../core/runtime.ts'
import { receiverHolderPid } from '../core/receiver-lock.ts'

/** 汇总并发布当前微信桥状态。 */
export function publishWechatStatus(): void {
  const accounts = loadAccounts()
  const connected = accounts.filter((account) => getMonitor(account.id)?.getStatus().running === true).length
  const state: WechatStatusState = {
    // 这个函数由桥自身调用，所以桥一定已经挂载；`available` 是我方进程内的事实。
    available: true,
    connected: connected > 0,
    accounts: { connected, total: accounts.length },
    lock: isReceiverHeld()
      ? { held: true }
      : { held: false, pid: receiverHolderPid() ?? undefined },
  }
  const wechat = accounts.length === 0
    ? '微信: 未连接'
    : connected > 0
      ? `微信: 已连接（${connected}/${accounts.length}）`
      : '微信: 未连接'
  const lock = state.lock.held
    ? '接收锁: 本进程持有'
    : `接收锁: pid ${state.lock.pid ?? '未知'}`
  publishStatus(`${wechat} · ${lock}`, state)
}
