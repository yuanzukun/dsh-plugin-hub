import type { PricingTable } from './pricing.ts'

const DEEPSEEK_OFFPEAK = {
  name: 'deepseek-off-peak',
  timezone: 'Asia/Shanghai',
  start: '00:30',
  end: '08:30',
  multiplier: 0.5,
} as const

/**
 * Bundled prices imported from EasyCLIProxyAPI 0.3.29 `usage.db` model_prices.
 * price.json is the program-owned copy; users change custom_price.json instead.
 */
export const DEFAULT_PRICING_TABLE: PricingTable = {
  version: 2,
  currency: 'USD',
  updatedAt: 'easycli-0.3.29-2026-10-23',
  managedBy: 'my-dpsk-harness-tui',
  editable: false,
  models: {
    "claude-fable-5": {
      model: "claude-fable-5",
      ratesPerMillion: { input: 10.0, output: 50.0, cacheRead: 1.0, cacheWrite: 12.5 },
      aliases: ["anthropic/claude-fable-5"],
    },
    "claude-fable-5-1": {
      model: "claude-fable-5-1",
      ratesPerMillion: { input: 10.0, output: 50.0, cacheRead: 0.25, cacheWrite: 12.5 },
      aliases: ["anthropic/claude-fable-5-1"],
    },
    "claude-haiku-4-5": {
      model: "claude-haiku-4-5",
      ratesPerMillion: { input: 1.0, output: 5.0, cacheRead: 0.1, cacheWrite: 1.25 },
      aliases: ["anthropic/claude-haiku-4-5"],
    },
    "claude-haiku-5-5": {
      model: "claude-haiku-5-5",
      ratesPerMillion: { input: 0.1, output: 0.5, cacheRead: 0.01, cacheWrite: 0.125 },
      aliases: ["anthropic/claude-haiku-5-5"],
    },
    "claude-mythos-5": {
      model: "claude-mythos-5",
      ratesPerMillion: { input: 10.0, output: 50.0, cacheRead: 1.0, cacheWrite: 12.5 },
      aliases: ["claude-mythos-5"],
    },
    "claude-mythos-5-1": {
      model: "claude-mythos-5-1",
      ratesPerMillion: { input: 10.0, output: 50.0, cacheRead: 0.25, cacheWrite: 12.5 },
      aliases: ["claude-mythos-5-1"],
    },
    "claude-opus-4-1": {
      model: "claude-opus-4-1",
      ratesPerMillion: { input: 15.0, output: 75.0, cacheRead: 1.5, cacheWrite: 18.75 },
      aliases: ["claude-opus-4.1", "vercel_ai_gateway/anthropic/claude-opus-4.1"],
    },
    "claude-opus-4-5": {
      model: "claude-opus-4-5",
      ratesPerMillion: { input: 5.0, output: 25.0, cacheRead: 0.5, cacheWrite: 6.25 },
      aliases: ["anthropic/claude-opus-4-5"],
    },
    "claude-opus-4-6": {
      model: "claude-opus-4-6",
      ratesPerMillion: { input: 5.0, output: 25.0, cacheRead: 0.5, cacheWrite: 6.25 },
      aliases: ["anthropic/claude-opus-4-6"],
    },
    "claude-opus-4-6-thinking": {
      model: "claude-opus-4-6-thinking",
      ratesPerMillion: { input: 5.0, output: 25.0, cacheRead: 0.5, cacheWrite: 0.0 },
      aliases: ["claude-opus-4.6:thinking", "nano-gpt/anthropic/claude-opus-4.6:thinking"],
    },
    "claude-opus-4-7": {
      model: "claude-opus-4-7",
      ratesPerMillion: { input: 5.0, output: 25.0, cacheRead: 0.5, cacheWrite: 6.25 },
      aliases: ["anthropic/claude-opus-4-7"],
    },
    "claude-opus-4-8": {
      model: "claude-opus-4-8",
      ratesPerMillion: { input: 5.0, output: 25.0, cacheRead: 0.5, cacheWrite: 6.25 },
      aliases: ["anthropic/claude-opus-4-8"],
    },
    "claude-opus-5": {
      model: "claude-opus-5",
      ratesPerMillion: { input: 5.0, output: 25.0, cacheRead: 0.5, cacheWrite: 6.25 },
      aliases: ["anthropic/claude-opus-5"],
    },
    "claude-opus-5-5": {
      model: "claude-opus-5-5",
      ratesPerMillion: { input: 4.0, output: 20.0, cacheRead: 0.2, cacheWrite: 5.0 },
      aliases: ["anthropic/claude-opus-5-5"],
    },
    "claude-sonnet-4-5": {
      model: "claude-sonnet-4-5",
      ratesPerMillion: { input: 3.0, output: 15.0, cacheRead: 0.3, cacheWrite: 3.75 },
      aliases: ["anthropic/claude-sonnet-4-5"],
    },
    "claude-sonnet-4-6": {
      model: "claude-sonnet-4-6",
      ratesPerMillion: { input: 3.0, output: 15.0, cacheRead: 0.3, cacheWrite: 3.75 },
      aliases: ["anthropic/claude-sonnet-4-6"],
    },
    "claude-sonnet-5": {
      model: "claude-sonnet-5",
      ratesPerMillion: { input: 2.0, output: 10.0, cacheRead: 0.2, cacheWrite: 2.5 },
      aliases: ["anthropic/claude-sonnet-5"],
    },
    "deepseek-chat": {
      model: "deepseek-chat",
      ratesPerMillion: { input: 0.1, output: 0.425, cacheRead: 0.05, cacheWrite: 0.0 },
      aliases: ["nano-gpt/deepseek-chat"],
      schedules: [DEEPSEEK_OFFPEAK],
    },
    "deepseek-flash": {
      model: "deepseek-flash",
      ratesPerMillion: { input: 0.15, output: 0.6, cacheRead: 0.003, cacheWrite: 0.0 },
      aliases: ["deepseek/deepseek-flash"],
      schedules: [DEEPSEEK_OFFPEAK],
    },
    "deepseek-reasoner": {
      model: "deepseek-reasoner",
      ratesPerMillion: { input: 0.28, output: 0.42, cacheRead: 0.028, cacheWrite: 0.0 },
      aliases: ["deepseek-reasoner"],
      schedules: [DEEPSEEK_OFFPEAK],
    },
    "deepseek-v4-flash": {
      model: "deepseek-v4-flash",
      ratesPerMillion: { input: 0.15, output: 0.6, cacheRead: 0.003, cacheWrite: 0.0 },
      aliases: ["deepseek/deepseek-v4-flash"],
      schedules: [DEEPSEEK_OFFPEAK],
    },
    "deepseek-v4-flash-vision-exp": {
      model: "deepseek-v4-flash-vision-exp",
      ratesPerMillion: { input: 0.15, output: 0.6, cacheRead: 0.003, cacheWrite: 0.0 },
      aliases: ["deepseek/deepseek-v4-flash-vision-exp"],
      schedules: [DEEPSEEK_OFFPEAK],
    },
    "deepseek-v4-pro": {
      model: "deepseek-v4-pro",
      ratesPerMillion: { input: 0.66, output: 1.98, cacheRead: 0.022, cacheWrite: 0.0 },
      aliases: ["deepseek/deepseek-v4-pro"],
      schedules: [DEEPSEEK_OFFPEAK],
    },
    "deepseek-v4.1-flash": {
      model: "deepseek-v4.1-flash",
      ratesPerMillion: { input: 0.3, output: 1.2, cacheRead: 0.006 },
      schedules: [DEEPSEEK_OFFPEAK],
    },
    "gemini-2.5-flash": {
      model: "gemini-2.5-flash",
      ratesPerMillion: { input: 0.3, output: 2.5, cacheRead: 0.03, cacheWrite: 0.0 },
      aliases: ["google/gemini-2.5-flash"],
    },
    "gemini-2.5-flash-lite": {
      model: "gemini-2.5-flash-lite",
      ratesPerMillion: { input: 0.1, output: 0.4, cacheRead: 0.01, cacheWrite: 0.0 },
      aliases: ["google/gemini-2.5-flash-lite"],
    },
    "gemini-2.5-pro": {
      model: "gemini-2.5-pro",
      ratesPerMillion: { input: 1.25, output: 10.0, cacheRead: 0.125, cacheWrite: 0.0 },
      aliases: ["google/gemini-2.5-pro"],
    },
    "gemini-3-flash": {
      model: "gemini-3-flash",
      ratesPerMillion: { input: 0.0, output: 0.0 },
    },
    "gemini-3-flash-preview": {
      model: "gemini-3-flash-preview",
      ratesPerMillion: { input: 0.5, output: 3.0, cacheRead: 0.05, cacheWrite: 0.0 },
      aliases: ["google/gemini-3-flash-preview"],
    },
    "gemini-3-pro": {
      model: "gemini-3-pro",
      ratesPerMillion: { input: 2.0, output: 12.0, cacheRead: 0.2, cacheWrite: 0.0 },
      aliases: ["opencode/gemini-3-pro"],
    },
    "gemini-3-pro-preview": {
      model: "gemini-3-pro-preview",
      ratesPerMillion: { input: 2.0, output: 12.0, cacheRead: 0.2, cacheWrite: 0.0 },
      aliases: ["vertex_ai/gemini-3-pro-preview"],
    },
    "gemini-3.1-flash-image": {
      model: "gemini-3.1-flash-image",
      ratesPerMillion: { input: 0.5, output: 60.0, cacheRead: 0.0, cacheWrite: 0.0 },
      aliases: ["google/gemini-3.1-flash-image"],
    },
    "gemini-3.1-flash-lite": {
      model: "gemini-3.1-flash-lite",
      ratesPerMillion: { input: 0.25, output: 1.5, cacheRead: 0.025, cacheWrite: 0.0 },
      aliases: ["google/gemini-3.1-flash-lite"],
    },
    "gemini-3.1-pro": {
      model: "gemini-3.1-pro",
      ratesPerMillion: { input: 0.0, output: 0.0 },
    },
    "gemini-3.1-pro-preview": {
      model: "gemini-3.1-pro-preview",
      ratesPerMillion: { input: 2.0, output: 12.0, cacheRead: 0.2, cacheWrite: 0.0 },
      aliases: ["google/gemini-3.1-pro-preview"],
    },
    "gemini-3.5-flash": {
      model: "gemini-3.5-flash",
      ratesPerMillion: { input: 1.5, output: 9.0, cacheRead: 0.15, cacheWrite: 0.0 },
      aliases: ["google/gemini-3.5-flash"],
    },
    "gemini-3.5-flash-lite": {
      model: "gemini-3.5-flash-lite",
      ratesPerMillion: { input: 0.3, output: 2.5, cacheRead: 0.03, cacheWrite: 0.0 },
      aliases: ["google/gemini-3.5-flash-lite"],
    },
    "gemini-3.6-flash": {
      model: "gemini-3.6-flash",
      ratesPerMillion: { input: 0.75, output: 3.75, cacheRead: 0.075, cacheWrite: 0.0 },
      aliases: ["google/gemini-3.6-flash"],
    },
    "gemini-3.7-flash": {
      model: "gemini-3.7-flash",
      ratesPerMillion: { input: 0.75, output: 3.75, cacheRead: 0.075, cacheWrite: 0.0 },
      aliases: ["google/gemini-3.7-flash"],
    },
    "gemini-3.8-flash": {
      model: "gemini-3.8-flash",
      ratesPerMillion: { input: 0.75, output: 3.75, cacheRead: 0.075, cacheWrite: 0.0 },
      aliases: ["google/gemini-3.8-flash"],
    },
    "gemini-pro-agent": {
      model: "gemini-pro-agent",
      ratesPerMillion: { input: 0.0, output: 0.0 },
    },
    "gpt-4.1": {
      model: "gpt-4.1",
      ratesPerMillion: { input: 2.0, output: 8.0, cacheRead: 0.5, cacheWrite: 0.0 },
      aliases: ["openai/gpt-4.1"],
    },
    "gpt-4.1-mini": {
      model: "gpt-4.1-mini",
      ratesPerMillion: { input: 0.4, output: 1.6, cacheRead: 0.1, cacheWrite: 0.0 },
      aliases: ["openai/gpt-4.1-mini"],
    },
    "gpt-4.1-nano": {
      model: "gpt-4.1-nano",
      ratesPerMillion: { input: 0.1, output: 0.4, cacheRead: 0.025, cacheWrite: 0.0 },
      aliases: ["openai/gpt-4.1-nano"],
    },
    "gpt-4o": {
      model: "gpt-4o",
      ratesPerMillion: { input: 2.5, output: 10.0, cacheRead: 1.25, cacheWrite: 0.0 },
      aliases: ["openai/gpt-4o"],
    },
    "gpt-4o-mini": {
      model: "gpt-4o-mini",
      ratesPerMillion: { input: 0.15, output: 0.6, cacheRead: 0.075, cacheWrite: 0.0 },
      aliases: ["openai/gpt-4o-mini"],
    },
    "gpt-5": {
      model: "gpt-5",
      ratesPerMillion: { input: 1.25, output: 10.0, cacheRead: 0.125, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5"],
    },
    "gpt-5-mini": {
      model: "gpt-5-mini",
      ratesPerMillion: { input: 0.25, output: 2.0, cacheRead: 0.025, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5-mini"],
    },
    "gpt-5-nano": {
      model: "gpt-5-nano",
      ratesPerMillion: { input: 0.05, output: 0.4, cacheRead: 0.005, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5-nano"],
    },
    "gpt-5-pro": {
      model: "gpt-5-pro",
      ratesPerMillion: { input: 15.0, output: 120.0, cacheRead: 0.0, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5-pro"],
    },
    "gpt-5.1": {
      model: "gpt-5.1",
      ratesPerMillion: { input: 1.25, output: 10.0, cacheRead: 0.125, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5.1"],
    },
    "gpt-5.1-codex": {
      model: "gpt-5.1-codex",
      ratesPerMillion: { input: 1.25, output: 10.0, cacheRead: 0.125, cacheWrite: 0.0 },
      aliases: ["gpt-5.1-codex"],
    },
    "gpt-5.1-codex-max": {
      model: "gpt-5.1-codex-max",
      ratesPerMillion: { input: 1.25, output: 10.0, cacheRead: 0.125, cacheWrite: 0.0 },
      aliases: ["gpt-5.1-codex-max"],
    },
    "gpt-5.1-codex-mini": {
      model: "gpt-5.1-codex-mini",
      ratesPerMillion: { input: 0.25, output: 2.0, cacheRead: 0.025, cacheWrite: 0.0 },
      aliases: ["gpt-5.1-codex-mini"],
    },
    "gpt-5.2": {
      model: "gpt-5.2",
      ratesPerMillion: { input: 1.75, output: 14.0, cacheRead: 0.175, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5.2"],
    },
    "gpt-5.2-codex": {
      model: "gpt-5.2-codex",
      ratesPerMillion: { input: 1.75, output: 14.0, cacheRead: 0.175, cacheWrite: 0.0 },
      aliases: ["gpt-5.2-codex"],
    },
    "gpt-5.2-pro": {
      model: "gpt-5.2-pro",
      ratesPerMillion: { input: 21.0, output: 168.0, cacheRead: 0.0, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5.2-pro"],
    },
    "gpt-5.3-chat-latest": {
      model: "gpt-5.3-chat-latest",
      ratesPerMillion: { input: 1.75, output: 14.0, cacheRead: 0.175, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5.3-chat-latest"],
    },
    "gpt-5.3-codex": {
      model: "gpt-5.3-codex",
      ratesPerMillion: { input: 1.75, output: 14.0, cacheRead: 0.175, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5.3-codex"],
    },
    "gpt-5.4": {
      model: "gpt-5.4",
      ratesPerMillion: { input: 2.5, output: 15.0, cacheRead: 0.25, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5.4"],
    },
    "gpt-5.4-mini": {
      model: "gpt-5.4-mini",
      ratesPerMillion: { input: 0.75, output: 4.5, cacheRead: 0.075, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5.4-mini"],
    },
    "gpt-5.4-nano": {
      model: "gpt-5.4-nano",
      ratesPerMillion: { input: 0.2, output: 1.25, cacheRead: 0.02, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5.4-nano"],
    },
    "gpt-5.4-pro": {
      model: "gpt-5.4-pro",
      ratesPerMillion: { input: 30.0, output: 180.0, cacheRead: 0.0, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5.4-pro"],
    },
    "gpt-5.5": {
      model: "gpt-5.5",
      ratesPerMillion: { input: 5.0, output: 30.0, cacheRead: 0.5, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5.5"],
    },
    "gpt-5.5-pro": {
      model: "gpt-5.5-pro",
      ratesPerMillion: { input: 30.0, output: 180.0, cacheRead: 0.0, cacheWrite: 0.0 },
      aliases: ["openai/gpt-5.5-pro"],
    },
    "gpt-5.6": {
      model: "gpt-5.6",
      ratesPerMillion: { input: 4.0, output: 20.0, cacheRead: 0.4, cacheWrite: 5.0 },
      aliases: ["openai/gpt-5.6"],
    },
    "gpt-5.6-cyber": {
      model: "gpt-5.6-cyber",
      ratesPerMillion: { input: 12.5, output: 75.0, cacheRead: 1.25, cacheWrite: 15.625 },
      aliases: ["gpt-5.6-cyber"],
    },
    "gpt-5.6-luna": {
      model: "gpt-5.6-luna",
      ratesPerMillion: { input: 0.2, output: 1.2, cacheRead: 0.02, cacheWrite: 0.25 },
      aliases: ["openai/gpt-5.6-luna"],
    },
    "gpt-5.6-sol": {
      model: "gpt-5.6-sol",
      ratesPerMillion: { input: 4.0, output: 20.0, cacheRead: 0.4, cacheWrite: 5.0 },
      aliases: ["openai/gpt-5.6-sol"],
    },
    "gpt-5.6-terra": {
      model: "gpt-5.6-terra",
      ratesPerMillion: { input: 2.0, output: 12.0, cacheRead: 0.2, cacheWrite: 2.5 },
      aliases: ["openai/gpt-5.6-terra"],
    },
    "gpt-6-astra": {
      model: "gpt-6-astra",
      ratesPerMillion: { input: 10.0, output: 50.0, cacheRead: 1.0, cacheWrite: 12.5 },
      aliases: ["openai/gpt-6-astra"],
    },
    "gpt-6-luna": {
      model: "gpt-6-luna",
      ratesPerMillion: { input: 0.1, output: 0.5, cacheRead: 0.01, cacheWrite: 0.125 },
      aliases: ["openai/gpt-6-luna"],
    },
    "gpt-6-sol": {
      model: "gpt-6-sol",
      ratesPerMillion: { input: 2.0, output: 10.0, cacheRead: 0.2, cacheWrite: 2.5 },
      aliases: ["openai/gpt-6-sol"],
    },
    "gpt-6.1-sol": {
      model: "gpt-6.1-sol",
      ratesPerMillion: { input: 2.0, output: 10.0, cacheRead: 0.1, cacheWrite: 2.5 },
      aliases: ["openai/gpt-6.1-sol"],
    },
    "gpt-oss-120b-medium": {
      model: "gpt-oss-120b-medium",
      ratesPerMillion: { input: 0.0, output: 0.0 },
    },
    "grok-3": {
      model: "grok-3",
      ratesPerMillion: { input: 3.0, output: 15.0, cacheRead: 0.75, cacheWrite: 0.0 },
      aliases: ["helicone/grok-3"],
    },
    "grok-3-mini": {
      model: "grok-3-mini",
      ratesPerMillion: { input: 0.3, output: 0.5, cacheRead: 0.075, cacheWrite: 0.0 },
      aliases: ["helicone/grok-3-mini"],
    },
    "grok-4-1-fast": {
      model: "grok-4-1-fast",
      ratesPerMillion: { input: 0.2, output: 0.5, cacheRead: 0.05, cacheWrite: 0.0 },
      aliases: ["grok-4.1-fast", "ofox/x-ai/grok-4.1-fast"],
    },
    "grok-4.20": {
      model: "grok-4.20",
      ratesPerMillion: { input: 1.25, output: 2.5, cacheRead: 0.2, cacheWrite: 0.0 },
      aliases: ["xai/grok-4.20"],
    },
    "grok-4.3": {
      model: "grok-4.3",
      ratesPerMillion: { input: 1.25, output: 2.5, cacheRead: 0.2, cacheWrite: 0.0 },
      aliases: ["xai/grok-4.3"],
    },
    "grok-4.5": {
      model: "grok-4.5",
      ratesPerMillion: { input: 2.0, output: 6.0, cacheRead: 0.3, cacheWrite: 0.0 },
      aliases: ["xai/grok-4.5"],
    },
    "grok-4.6": {
      model: "grok-4.6",
      ratesPerMillion: { input: 2.0, output: 6.0, cacheRead: 0.5, cacheWrite: 0.0 },
      aliases: ["xai/grok-4.6"],
    },
    "grok-4.7": {
      model: "grok-4.7",
      ratesPerMillion: { input: 2.0, output: 6.0, cacheRead: 0.5, cacheWrite: 0.0 },
      aliases: ["xai/grok-4.7"],
    },
    "grok-build-0.1": {
      model: "grok-build-0.1",
      ratesPerMillion: { input: 1.0, output: 2.0, cacheRead: 0.2, cacheWrite: 0.0 },
      aliases: ["xai/grok-build-0.1"],
    },
    "grok-code-fast-1": {
      model: "grok-code-fast-1",
      ratesPerMillion: { input: 1.0, output: 2.0, cacheRead: 0.2, cacheWrite: 0.0 },
      aliases: ["xai/grok-code-fast-1"],
    },
    "mimo-v2.6-flash": {
      model: "mimo-v2.6-flash",
      ratesPerMillion: { input: 0.14, output: 0.28, cacheRead: 0.0028, cacheWrite: 0.0 },
      aliases: ["xiaomi_mimo/mimo-v2.6-flash"],
    },
    "mimo-v2.6-pro": {
      model: "mimo-v2.6-pro",
      ratesPerMillion: { input: 0.435, output: 0.87, cacheRead: 0.0036, cacheWrite: 0.0 },
      aliases: ["xiaomi_mimo/mimo-v2.6-pro"],
    },
    "o1": {
      model: "o1",
      ratesPerMillion: { input: 15.0, output: 60.0, cacheRead: 7.5, cacheWrite: 0.0 },
      aliases: ["o1"],
    },
    "o1-pro": {
      model: "o1-pro",
      ratesPerMillion: { input: 150.0, output: 600.0, cacheRead: 0.0, cacheWrite: 0.0 },
      aliases: ["openai/o1-pro"],
    },
    "o3": {
      model: "o3",
      ratesPerMillion: { input: 2.0, output: 8.0, cacheRead: 0.5, cacheWrite: 0.0 },
      aliases: ["o3"],
    },
    "o3-mini": {
      model: "o3-mini",
      ratesPerMillion: { input: 1.1, output: 4.4, cacheRead: 0.55, cacheWrite: 0.0 },
      aliases: ["openai/o3-mini"],
    },
    "o3-pro": {
      model: "o3-pro",
      ratesPerMillion: { input: 20.0, output: 80.0, cacheRead: 0.0, cacheWrite: 0.0 },
      aliases: ["openai/o3-pro"],
    },
    "o4-mini": {
      model: "o4-mini",
      ratesPerMillion: { input: 1.1, output: 4.4, cacheRead: 0.275, cacheWrite: 0.0 },
      aliases: ["openai/o4-mini"],
    },
    "swift-1.5-iq3_xxs": {
      model: "swift-1.5-iq3_xxs",
      ratesPerMillion: { input: 0.0, output: 0.0, cacheRead: 0.0, cacheWrite: 0.0 },
    },
    "tierflow": {
      model: "tierflow",
      ratesPerMillion: { input: 1.0, output: 4.0, cacheRead: 0.1 },
    },
  },
}
