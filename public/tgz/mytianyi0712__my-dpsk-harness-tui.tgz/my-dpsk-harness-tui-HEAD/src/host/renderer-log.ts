/**
 * Log routing for the renderer handoff.
 *
 * Once the renderer owns the TTY, any dsh write to stdout corrupts the screen.
 * `routeStdoutToLog` replaces `process.stdout.write` and `process.stderr.write`
 * with a log-file append plus an IPC `log` envelope, so harness chatter lands in
 * `$DSH_HOME/logs/tui-<pid>.log` and shows up in the renderer's console overlay
 * instead of painting over the transcript.
 *
 * The replacement is scoped: `restore` puts the original write functions back,
 * which is what the host does when the renderer exits so the terminal is usable
 * again and later output goes to the real terminal.
 */

import { appendFileSync, existsSync, mkdirSync, writeSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

/**
 * Write straight to the terminal, bypassing `process.stdout.write`.
 *
 * Once `routeStdoutToLog` has replaced the stream's writer, a control sequence written
 * through it lands in the log file instead of reaching the terminal — which is exactly how
 * the shutdown restore (leave the alternate screen, mouse tracking off, cursor back) went
 * missing and left a shell that echoed `[555;109;10M` mouse reports on every movement. The
 * file descriptor is untouched by the patch, so this is the path that always reaches the TTY.
 */
export function writeTerminal(text: string): void {
  try {
    writeSync(1, text)
  } catch {
    // A closed or redirected terminal is not worth a crash on the way out.
  }
}

/** `$DSH_HOME/logs`, created on demand. `DSH_HOME` defaults to `~/.dsh`. */
export function tuiLogDir(): string {
  const root = process.env.DSH_HOME?.trim() || join(homedir(), '.dsh')
  const dir = join(root, 'logs')
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
  return dir
}

/** The per-process log file: `tui-<pid>.log`. */
export function tuiLogPath(pid: number = process.pid): string {
  return join(tuiLogDir(), `tui-${pid}.log`)
}

export type LogLevel = 'info' | 'warn' | 'error'

/** A writable stream pair the router replaces. Only `write` is used. */
export interface RoutedStreams {
  stdout: { write: (chunk: string | Uint8Array, cb?: (err?: Error | null) => void) => boolean }
  stderr: { write: (chunk: string | Uint8Array, cb?: (err?: Error | null) => void) => boolean }
}

/**
 * Route stdout and stderr to the log file and to the renderer's console overlay.
 *
 * Returns the restore function. The IPC callback receives one line per write,
 * with stderr mapped to `warn`; the renderer's `log` kind is optional, so a
 * renderer that does not implement it simply never receives these.
 *
 * `streams` defaults to `process`. Tests pass a fake pair: replacing the real
 * `process.stdout.write` inside a test run swallows the test runner's own output,
 * so a suite that mounts the renderer would report nothing at all.
 */
export function routeStdoutToLog(
  logPath: string,
  onLine: (level: LogLevel, text: string) => void,
  streams: RoutedStreams = process,
): () => void {
  const originalOut = streams.stdout.write
  const originalErr = streams.stderr.write

  const emit = (level: LogLevel, chunk: unknown) => {
    const text = String(chunk)
    try {
      appendFileSync(logPath, text)
    } catch {
      // The log is best effort: a failed append must not take the harness down,
      // and must not write to the TTY the renderer owns.
    }
    const trimmed = text.replace(/\r?\n$/, '')
    if (trimmed !== '') onLine(level, trimmed)
  }

  streams.stdout.write = ((chunk: unknown) => {
    emit('info', chunk)
    return true
  }) as typeof streams.stdout.write

  streams.stderr.write = ((chunk: unknown) => {
    emit('warn', chunk)
    return true
  }) as typeof streams.stderr.write

  return () => {
    streams.stdout.write = originalOut
    streams.stderr.write = originalErr
  }
}
