/**
 * Local cost estimation for the sidebar. The price table is deliberately data, not code:
 * providers change rates and DeepSeek-style off-peak windows without a release.
 */
import { DEFAULT_PRICING_TABLE } from './pricing-defaults.ts'

export { DEFAULT_PRICING_TABLE } from './pricing-defaults.ts'
export type PricingDay = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun'

export interface PricingRates {
  readonly input: number
  readonly output: number
  readonly cacheRead?: number
  readonly cacheWrite?: number
}

export interface PricingSchedule {
  readonly name?: string
  readonly timezone: string
  readonly days?: readonly PricingDay[]
  readonly start: string
  readonly end: string
  readonly multiplier?: number
  readonly ratesPerMillion?: Partial<PricingRates>
  readonly effectiveFrom?: string
  readonly effectiveUntil?: string
}

export interface PricingModel {
  readonly provider?: string
  readonly model?: string
  /** Provider-specific ids that resolve to this price, e.g. `deepseek/deepseek-v4.1-flash`. */
  readonly aliases?: readonly string[]
  readonly ratesPerMillion: PricingRates
  readonly schedules?: readonly PricingSchedule[]
}

export interface PricingTable {
  readonly version: number
  readonly currency: 'USD'
  readonly updatedAt?: string
  /** Program-managed tables are rewritten from the bundled copy; custom tables are user-owned. */
  readonly managedBy?: string
  readonly editable?: boolean
  readonly models: Readonly<Record<string, PricingModel>>
}

export interface UsageCostSample {
  readonly time: number
  readonly provider?: string
  readonly model?: string
  readonly inputTokens: number
  readonly outputTokens: number
  readonly cacheReadTokens?: number
  readonly cacheWriteTokens?: number
}

export interface CostEstimate {
  readonly costUsd: number
  readonly currency: 'USD'
  readonly modelKey: string
  readonly schedule?: string
}

export interface UsageCostFold {
  readonly costUsd: number
  readonly pricedSamples: number
  readonly unpricedSamples: number
}

export const EMPTY_USAGE_COST_FOLD: UsageCostFold = {
  costUsd: 0,
  pricedSamples: 0,
  unpricedSamples: 0,
}

const DAYS: readonly PricingDay[] = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat']

function matchGlob(pattern: string | undefined, value: string | undefined): boolean {
  if (pattern === undefined || pattern === '*' || pattern === '') return true
  if (value === undefined) return false
  const escaped = pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*')
  return new RegExp(`^${escaped}$`, 'i').test(value)
}

function entryParts(key: string, entry: PricingModel): { provider: string; model: string } {
  const slash = key.indexOf('/')
  return {
    provider: entry.provider ?? (slash < 0 ? '*' : key.slice(0, slash)),
    model: entry.model ?? (slash < 0 ? key : key.slice(slash + 1)),
  }
}

/** Canonical form for alias matching. Dots/underscores and path prefixes do not matter. */
export function normalizePricingModelId(value: string): string {
  const base = value.split('/').filter(Boolean).at(-1) ?? value
  return base
    .toLowerCase()
    .replace(/:.*$/, '')
    .replace(/[_.\s]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
}

/** Versionless family key: `deepseek/deepseek-v4.1-flash` and `deepseek-flash` both become `deepseek-flash`. */
export function versionlessPricingModelId(value: string): string {
  return normalizePricingModelId(value)
    .replace(/(^|-)(v?\d+(?:-\d+)*)(?=-|$)/g, '$1')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
}

export interface PricingMatch {
  readonly key: string
  readonly entry: PricingModel
  readonly basis: 'exact' | 'basename' | 'alias' | 'versionless' | 'family'
}

/**
 * Resolve a price across provider-id differences. Exact provider/model wins, then the
 * model basename, then aliases, then a unique versionless/family match. Ambiguous
 * versionless matches deliberately fail: a wrong price is worse than no price.
 */
export function findPricingModel(
  table: PricingTable,
  provider: string | undefined,
  model: string | undefined,
): PricingMatch | undefined {
  if (model === undefined || model === '') return undefined
  const exactKey = provider === undefined ? undefined : `${provider}/${model}`
  if (exactKey !== undefined) {
    const exact = table.models[exactKey]
    if (exact !== undefined) return { key: exactKey, entry: exact, basis: 'exact' }
  }
  const target = normalizePricingModelId(model)
  const targetLessVersion = versionlessPricingModelId(model)
  const exacts: PricingMatch[] = []
  const aliases: PricingMatch[] = []
  const versionless: PricingMatch[] = []
  const family: PricingMatch[] = []
  for (const [key, entry] of Object.entries(table.models)) {
    const parts = entryParts(key, entry)
    if (!matchGlob(parts.provider, provider) && parts.provider !== '*') continue
    const modelCandidates = [parts.model, key, ...(entry.aliases ?? [])]
    let matched: PricingMatch['basis'] | undefined
    for (const candidate of modelCandidates) {
      if (normalizePricingModelId(candidate) === target) {
        matched = candidate === parts.model ? 'basename' : 'alias'
        break
      }
    }
    if (matched !== undefined) {
      ;(matched === 'basename' ? exacts : aliases).push({ key, entry, basis: matched })
      continue
    }
    const candidateLessVersion = versionlessPricingModelId(parts.model)
    if (candidateLessVersion !== '' && candidateLessVersion === targetLessVersion) {
      versionless.push({ key, entry, basis: 'versionless' })
      continue
    }
    if (candidateLessVersion !== '' && targetLessVersion !== ''
      && (targetLessVersion.startsWith(`${candidateLessVersion}-`) || candidateLessVersion.startsWith(`${targetLessVersion}-`))) {
      family.push({ key, entry, basis: 'family' })
    }
  }
  return exacts[0] ?? aliases[0] ?? (versionless.length === 1 ? versionless[0] : undefined)
    ?? (family.length === 1 ? family[0] : undefined)
}

function parseClock(value: string): number | undefined {
  const match = /^(\d{1,2}):(\d{2})$/.exec(value)
  if (match === null) return undefined
  const hour = Number(match[1])
  const minute = Number(match[2])
  if (!Number.isInteger(hour) || !Number.isInteger(minute)) return undefined
  if (hour < 0 || hour > 24 || minute < 0 || minute > 59) return undefined
  if (hour === 24 && minute !== 0) return undefined
  return hour * 60 + minute
}

function timeZoneValid(zone: string): boolean {
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: zone }).format(0)
    return true
  } catch {
    return false
  }
}

function zonedParts(epochMs: number, timeZone: string): { day: PricingDay; minute: number } | undefined {
  try {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone,
      weekday: 'short',
      hour: '2-digit',
      minute: '2-digit',
      hourCycle: 'h23',
    }).formatToParts(new Date(epochMs))
    const weekday = parts.find(part => part.type === 'weekday')?.value.toLowerCase().slice(0, 3) as PricingDay | undefined
    const hour = Number(parts.find(part => part.type === 'hour')?.value)
    const minute = Number(parts.find(part => part.type === 'minute')?.value)
    if (weekday === undefined || !DAYS.includes(weekday) || !Number.isFinite(hour) || !Number.isFinite(minute)) return undefined
    return { day: weekday, minute: (hour % 24) * 60 + minute }
  } catch {
    return undefined
  }
}

export function scheduleActive(schedule: PricingSchedule, epochMs: number): boolean {
  if (schedule.effectiveFrom !== undefined && Date.parse(schedule.effectiveFrom) > epochMs) return false
  if (schedule.effectiveUntil !== undefined && Date.parse(schedule.effectiveUntil) <= epochMs) return false
  const parts = zonedParts(epochMs, schedule.timezone)
  const start = parseClock(schedule.start)
  const end = parseClock(schedule.end)
  if (parts === undefined || start === undefined || end === undefined) return false
  if (schedule.days !== undefined && !schedule.days.includes(parts.day)) return false
  if (start === end) return true
  return start < end
    ? parts.minute >= start && parts.minute < end
    : parts.minute >= start || parts.minute < end
}

/** The first active schedule wins, matching the JSON table order. */
export function activeSchedule(schedules: readonly PricingSchedule[] | undefined, epochMs: number): PricingSchedule | undefined {
  return schedules?.find(schedule => scheduleActive(schedule, epochMs))
}

/**
 * Estimate one provider sample. Cache writes are charged only when the provider reports
 * them; missing buckets stay zero rather than being invented. Returns undefined when the
 * model is not in the table, so the UI can show `$ —`.
 */
export function estimateUsageCost(sample: UsageCostSample, table: PricingTable = DEFAULT_PRICING_TABLE): CostEstimate | undefined {
  const found = findPricingModel(table, sample.provider, sample.model)
  if (found === undefined) return undefined
  const schedule = activeSchedule(found.entry.schedules, sample.time)
  const rates = { ...found.entry.ratesPerMillion, ...(schedule?.ratesPerMillion ?? {}) }
  const multiplier = schedule?.multiplier ?? 1
  const raw = (
    sample.inputTokens * rates.input
    + sample.outputTokens * rates.output
    + (sample.cacheReadTokens ?? 0) * (rates.cacheRead ?? 0)
    + (sample.cacheWriteTokens ?? 0) * (rates.cacheWrite ?? 0)
  ) / 1_000_000
  return {
    costUsd: raw * multiplier,
    currency: 'USD',
    modelKey: found.key,
    ...(schedule?.name === undefined ? {} : { schedule: schedule.name }),
  }
}

export function foldUsageCost(
  fold: UsageCostFold,
  sample: UsageCostSample,
  table: PricingTable = DEFAULT_PRICING_TABLE,
): UsageCostFold {
  const estimate = estimateUsageCost(sample, table)
  if (estimate === undefined) {
    return { ...fold, unpricedSamples: fold.unpricedSamples + 1 }
  }
  return {
    costUsd: fold.costUsd + estimate.costUsd,
    pricedSamples: fold.pricedSamples + 1,
    unpricedSamples: fold.unpricedSamples,
  }
}

function finiteRate(value: unknown, label: string, errors: string[]): value is number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) {
    errors.push(`${label} must be a non-negative number`)
    return false
  }
  return true
}

function validateRates(value: unknown, label: string, errors: string[], partial: boolean): boolean {
  if (value === null || typeof value !== 'object') {
    errors.push(`${label} must be an object`)
    return false
  }
  const rates = value as Record<string, unknown>
  let ok = true
  if (!partial || rates.input !== undefined) ok = finiteRate(rates.input, `${label}.input`, errors) && ok
  if (!partial || rates.output !== undefined) ok = finiteRate(rates.output, `${label}.output`, errors) && ok
  for (const key of ['cacheRead', 'cacheWrite']) {
    if (rates[key] !== undefined) ok = finiteRate(rates[key], `${label}.${key}`, errors) && ok
  }
  if (!partial && (rates.input === undefined || rates.output === undefined)) ok = false
  return ok
}

/** Validate external JSON without silently accepting a half-valid table. */
export function parsePricingTable(value: unknown): { table?: PricingTable; errors: readonly string[] } {
  const errors: string[] = []
  if (value === null || typeof value !== 'object') return { errors: ['pricing table must be an object'] }
  const raw = value as Record<string, unknown>
  if (raw.currency !== 'USD') errors.push('currency must be "USD"')
  if (typeof raw.version !== 'number' || !Number.isFinite(raw.version)) errors.push('version must be a number')
  if (raw.updatedAt !== undefined && typeof raw.updatedAt !== 'string') errors.push('updatedAt must be a string')
  if (raw.managedBy !== undefined && typeof raw.managedBy !== 'string') errors.push('managedBy must be a string')
  if (raw.editable !== undefined && typeof raw.editable !== 'boolean') errors.push('editable must be a boolean')
  if (raw.models === null || typeof raw.models !== 'object') {
    return { errors: [...errors, 'models must be an object'] }
  }
  for (const [key, candidate] of Object.entries(raw.models)) {
    if (candidate === null || typeof candidate !== 'object') {
      errors.push(`models.${key} must be an object`)
      continue
    }
    const entry = candidate as Record<string, unknown>
    if (entry.provider !== undefined && typeof entry.provider !== 'string') errors.push(`models.${key}.provider must be a string`)
    if (entry.model !== undefined && typeof entry.model !== 'string') errors.push(`models.${key}.model must be a string`)
    if (entry.aliases !== undefined && (!Array.isArray(entry.aliases) || entry.aliases.some(alias => typeof alias !== 'string'))) {
      errors.push(`models.${key}.aliases must be an array of strings`)
    }
    if (!validateRates(entry.ratesPerMillion, `models.${key}.ratesPerMillion`, errors, false)) continue
    if (entry.schedules !== undefined) {
      if (!Array.isArray(entry.schedules)) {
        errors.push(`models.${key}.schedules must be an array`)
        continue
      }
      entry.schedules.forEach((schedule, index) => {
        const label = `models.${key}.schedules[${index}]`
        if (schedule === null || typeof schedule !== 'object') {
          errors.push(`${label} must be an object`)
          return
        }
        const item = schedule as Record<string, unknown>
        if (typeof item.timezone !== 'string' || !timeZoneValid(item.timezone)) errors.push(`${label}.timezone is invalid`)
        if (typeof item.start !== 'string' || parseClock(item.start) === undefined) errors.push(`${label}.start must be HH:MM`)
        if (typeof item.end !== 'string' || parseClock(item.end) === undefined) errors.push(`${label}.end must be HH:MM`)
        if (item.days !== undefined) {
          if (!Array.isArray(item.days) || item.days.some(day => typeof day !== 'string' || !DAYS.includes(day as PricingDay))) {
            errors.push(`${label}.days must contain mon..sun`)
          }
        }
        if (item.multiplier !== undefined && (typeof item.multiplier !== 'number' || !Number.isFinite(item.multiplier) || item.multiplier <= 0)) {
          errors.push(`${label}.multiplier must be a positive number`)
        }
        if (item.ratesPerMillion !== undefined) validateRates(item.ratesPerMillion, `${label}.ratesPerMillion`, errors, true)
        for (const field of ['effectiveFrom', 'effectiveUntil']) {
          const stamp = item[field]
          if (stamp !== undefined && (typeof stamp !== 'string' || Number.isNaN(Date.parse(stamp)))) {
            errors.push(`${label}.${field} must be an ISO timestamp`)
          }
        }
      })
    }
  }
  return errors.length === 0 ? { table: raw as unknown as PricingTable, errors } : { errors }
}

export function pricingTableText(table: PricingTable = DEFAULT_PRICING_TABLE): string {
  return `${JSON.stringify(table, null, 2)}\n`
}
