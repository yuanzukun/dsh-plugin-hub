import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {
  DEFAULT_PRICING_TABLE,
  parsePricingTable,
  pricingTableText,
  type PricingModel,
  type PricingTable,
} from './pricing.ts'

/** Program-owned config is separate from DSH_HOME; dsh never writes these files. */
export interface ProgramConfigPaths {
  readonly home: string
  readonly config: string
  /** Program-managed public price table (initialized from the bundled copy). */
  readonly price: string
  /** User-owned overrides written by /price or edited by hand; highest priority. */
  readonly customPrice: string
  readonly backend: string
  readonly runtime: string
  readonly legacyBackend: string
}

export interface SavedSelection {
  readonly provider: string
  readonly model: string
  readonly effort?: string
  readonly preset?: string
}

export interface ProgramConfigDocument {
  readonly version: number
  readonly priceFile: string
  readonly hotReload: boolean
  /** Last route + agent preset the TUI actually used; restored on the next launch. */
  readonly lastSelection?: SavedSelection
}

export interface ProgramConfigSnapshot {
  readonly config: ProgramConfigDocument
  /** Effective merged table: public price.json + custom_price.json. */
  readonly price: PricingTable
  readonly publicPrice: PricingTable
  readonly customPrice: PricingTable
  readonly priceSource: 'file' | 'builtin'
  readonly errors: readonly string[]
}

export const DEFAULT_PROGRAM_CONFIG: ProgramConfigDocument = {
  version: 1,
  priceFile: 'price.json',
  hotReload: true,
}

export const EMPTY_CUSTOM_PRICE_TABLE: PricingTable = {
  version: 1,
  currency: 'USD',
  updatedAt: 'empty',
  managedBy: 'user',
  editable: true,
  models: {},
}

export function programConfigHome(env: NodeJS.ProcessEnv = process.env, home = os.homedir()): string {
  const explicit = env.MYDPSK_CONFIG_HOME?.trim()
  return explicit === undefined || explicit === '' ? path.join(home, '.config', '.mydpsk') : explicit
}

export function programConfigPaths(
  env: NodeJS.ProcessEnv = process.env,
  home = os.homedir(),
): ProgramConfigPaths {
  const configHome = programConfigHome(env, home)
  const dshHome = env.DSH_HOME?.trim() || path.join(home, '.dsh')
  return {
    home: configHome,
    config: path.join(configHome, 'config.json'),
    price: path.join(configHome, 'price.json'),
    customPrice: path.join(configHome, 'custom_price.json'),
    backend: path.join(configHome, 'backend.json'),
    runtime: path.join(configHome, 'runtime'),
    legacyBackend: path.join(dshHome, 'dpsk', 'backend.json'),
  }
}

function atomicWrite(file: string, text: string): void {
  fs.mkdirSync(path.dirname(file), { recursive: true })
  const temp = `${file}.tmp-${process.pid}-${Date.now()}`
  fs.writeFileSync(temp, text, 'utf8')
  fs.renameSync(temp, file)
}

export function writeJsonAtomic(file: string, value: unknown): void {
  atomicWrite(file, `${JSON.stringify(value, null, 2)}\n`)
}

function copyIfMissing(source: string, destination: string): boolean {
  if (fs.existsSync(destination) || !fs.existsSync(source)) return false
  fs.mkdirSync(path.dirname(destination), { recursive: true })
  const temp = `${destination}.tmp-${process.pid}-${Date.now()}`
  fs.copyFileSync(source, temp)
  fs.renameSync(temp, destination)
  return true
}

/** Keep the program-owned public table in sync with the bundled copy. */
function syncPublicPrice(paths: ProgramConfigPaths): void {
  const text = pricingTableText(DEFAULT_PRICING_TABLE)
  try {
    if (fs.readFileSync(paths.price, 'utf8') === text) return
  } catch {
    // Missing or unreadable: rewrite below.
  }
  atomicWrite(paths.price, text)
}

/** Create the config home, migrate the legacy backend choice, and seed managed files. */
export function ensureProgramConfigHome(paths: ProgramConfigPaths): void {
  fs.mkdirSync(paths.home, { recursive: true })
  fs.mkdirSync(paths.runtime, { recursive: true })
  copyIfMissing(paths.legacyBackend, paths.backend)
  if (!fs.existsSync(paths.config)) {
    writeJsonAtomic(paths.config, DEFAULT_PROGRAM_CONFIG)
  } else {
    try {
      const raw = parseJson(paths.config) as Record<string, unknown>
      if (raw.pricingFile !== undefined || raw.priceFile === 'pricing.json') {
        const parsed = parseProgramConfig(raw)
        if (parsed.config !== undefined) writeJsonAtomic(paths.config, parsed.config)
      }
    } catch {
      // Invalid config keeps the user's file untouched; the store reports the error.
    }
  }
  // The old development filename was pricing.json. The public table is program-managed,
  // so removing the generated copy is safe; user edits live in custom_price.json.
  fs.rmSync(path.join(paths.home, 'pricing.json'), { force: true })
  syncPublicPrice(paths)
  if (!fs.existsSync(paths.customPrice)) writeJsonAtomic(paths.customPrice, EMPTY_CUSTOM_PRICE_TABLE)
}

function parseJson(file: string): unknown {
  return JSON.parse(fs.readFileSync(file, 'utf8'))
}

export function parseProgramConfig(value: unknown): { config?: ProgramConfigDocument; errors: readonly string[] } {
  const errors: string[] = []
  if (value === null || typeof value !== 'object') return { errors: ['config.json must be an object'] }
  const raw = value as Record<string, unknown>
  if (typeof raw.version !== 'number' || !Number.isFinite(raw.version)) errors.push('config.version must be a number')
  const rawPriceFile = typeof raw.priceFile === 'string'
    ? raw.priceFile
    : typeof raw.pricingFile === 'string'
      ? raw.pricingFile
      : undefined
  const priceFile = rawPriceFile === 'pricing.json' ? 'price.json' : rawPriceFile
  if (priceFile === undefined || priceFile.trim() === '') {
    errors.push('config.priceFile must be a non-empty relative file name')
  } else if (path.isAbsolute(priceFile) || priceFile.split(/[\\/]/).includes('..')) {
    errors.push('config.priceFile must stay inside the program config home')
  }
  if (typeof raw.hotReload !== 'boolean') errors.push('config.hotReload must be a boolean')
  let lastSelection: SavedSelection | undefined
  if (raw.lastSelection !== undefined) {
    if (raw.lastSelection === null || typeof raw.lastSelection !== 'object' || Array.isArray(raw.lastSelection)) {
      errors.push('config.lastSelection must be an object')
    } else {
      const saved = raw.lastSelection as Record<string, unknown>
      const provider = typeof saved.provider === 'string' ? saved.provider.trim() : ''
      const model = typeof saved.model === 'string' ? saved.model.trim() : ''
      const effort = saved.effort === undefined ? undefined : typeof saved.effort === 'string' ? saved.effort.trim() : ''
      const preset = saved.preset === undefined ? undefined : typeof saved.preset === 'string' ? saved.preset.trim() : ''
      if (provider === '') errors.push('config.lastSelection.provider must be a non-empty string')
      if (model === '') errors.push('config.lastSelection.model must be a non-empty string')
      if (effort === '') errors.push('config.lastSelection.effort must be a non-empty string')
      if (preset === '') errors.push('config.lastSelection.preset must be a non-empty string')
      if (provider !== '' && model !== '' && effort !== '' && preset !== '') {
        lastSelection = {
          provider,
          model,
          ...(effort === undefined ? {} : { effort }),
          ...(preset === undefined ? {} : { preset }),
        }
      }
    }
  }
  if (errors.length > 0 || priceFile === undefined) return { errors }
  return {
    config: {
      version: raw.version as number,
      priceFile,
      hotReload: raw.hotReload as boolean,
      ...(lastSelection === undefined ? {} : { lastSelection }),
    },
    errors,
  }
}

function loadConfigCandidate(file: string): { config: ProgramConfigDocument; errors: readonly string[] } {
  try {
    const parsed = parseProgramConfig(parseJson(file))
    return { config: parsed.config ?? DEFAULT_PROGRAM_CONFIG, errors: parsed.errors }
  } catch (error) {
    return { config: DEFAULT_PROGRAM_CONFIG, errors: [`config.json: ${error instanceof Error ? error.message : String(error)}`] }
  }
}

function loadPriceCandidate(
  file: string,
  fallback: PricingTable,
  label: string,
): { price: PricingTable; source: 'file' | 'builtin'; errors: readonly string[]; invalid: boolean } {
  if (!fs.existsSync(file)) {
    return { price: fallback, source: 'builtin', errors: [`${label} is missing; using fallback`], invalid: true }
  }
  try {
    const parsed = parsePricingTable(parseJson(file))
    if (parsed.table === undefined) return { price: fallback, source: 'builtin', errors: parsed.errors, invalid: true }
    return { price: parsed.table, source: 'file', errors: [], invalid: false }
  } catch (error) {
    return {
      price: fallback,
      source: 'builtin',
      errors: [`${label}: ${error instanceof Error ? error.message : String(error)}`],
      invalid: true,
    }
  }
}

/** Effective table: custom_price.json entries replace same-key public entries. */
export function mergePriceTables(publicPrice: PricingTable, customPrice: PricingTable): PricingTable {
  return {
    version: Math.max(publicPrice.version, customPrice.version),
    currency: 'USD',
    updatedAt: customPrice.updatedAt ?? publicPrice.updatedAt,
    managedBy: 'merged',
    editable: true,
    models: { ...publicPrice.models, ...customPrice.models },
  }
}

function resolvePricePath(paths: ProgramConfigPaths, config: ProgramConfigDocument): string {
  return path.resolve(paths.home, config.priceFile)
}

function fileSignature(file: string): string {
  try {
    const stat = fs.statSync(file)
    return `${stat.size}:${Math.trunc(stat.mtimeMs)}`
  } catch {
    return 'missing'
  }
}

/**
 * Owns validated program config plus the two price tables. A failed reload never replaces
 * the last good snapshot: users edit custom_price.json externally, so partial JSON is
 * expected input.
 */
export class ProgramConfigStore {
  readonly paths: ProgramConfigPaths
  private snapshot: ProgramConfigSnapshot
  private readonly listeners = new Set<(snapshot: ProgramConfigSnapshot) => void>()
  private watcher: fs.FSWatcher | undefined
  private debounce: NodeJS.Timeout | undefined
  private poll: NodeJS.Timeout | undefined
  private signatures = ''
  private closed = false

  constructor(options: { readonly env?: NodeJS.ProcessEnv; readonly home?: string; readonly pollMs?: number } = {}) {
    this.paths = programConfigPaths(options.env ?? process.env, options.home ?? os.homedir())
    ensureProgramConfigHome(this.paths)
    const config = loadConfigCandidate(this.paths.config)
    const publicPrice = loadPriceCandidate(resolvePricePath(this.paths, config.config), DEFAULT_PRICING_TABLE, 'price.json')
    const customPrice = loadPriceCandidate(this.paths.customPrice, EMPTY_CUSTOM_PRICE_TABLE, 'custom_price.json')
    this.snapshot = {
      config: config.config,
      price: mergePriceTables(publicPrice.price, customPrice.price),
      publicPrice: publicPrice.price,
      customPrice: customPrice.price,
      priceSource: publicPrice.source,
      errors: [...config.errors, ...publicPrice.errors, ...customPrice.errors],
    }
    this.signatures = this.readSignatures(this.snapshot.config)
    const pollMs = options.pollMs ?? 2_000
    if (pollMs > 0) this.startPolling(pollMs)
    this.startWatching()
  }

  current(): ProgramConfigSnapshot {
    return this.snapshot
  }

  price(): PricingTable {
    return this.snapshot.price
  }

  publicPrice(): PricingTable {
    return this.snapshot.publicPrice
  }

  customPrice(): PricingTable {
    return this.snapshot.customPrice
  }

  onChange(listener: (snapshot: ProgramConfigSnapshot) => void): () => void {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  /** Remember the route/preset the TUI last used. Returns the previous value when unchanged. */
  setLastSelection(selection: SavedSelection): SavedSelection {
    const normalized: SavedSelection = {
      provider: selection.provider,
      model: selection.model,
      ...(selection.effort === undefined ? {} : { effort: selection.effort }),
      ...(selection.preset === undefined ? {} : { preset: selection.preset }),
    }
    if (JSON.stringify(this.snapshot.config.lastSelection) === JSON.stringify(normalized)) return normalized
    writeJsonAtomic(this.paths.config, { ...this.snapshot.config, lastSelection: normalized })
    this.reload()
    return normalized
  }

  /** Persist a manual override for one current model. */
  setCustomPrice(provider: string, model: string, source: PricingModel): PricingModel {
    const key = `${provider}/${model}`
    const entry: PricingModel = {
      provider,
      model,
      ratesPerMillion: { ...source.ratesPerMillion },
      ...(source.schedules === undefined ? {} : { schedules: source.schedules.map(schedule => ({ ...schedule })) }),
    }
    const table: PricingTable = {
      version: this.snapshot.customPrice.version,
      currency: 'USD',
      updatedAt: new Date().toISOString(),
      managedBy: 'user',
      editable: true,
      models: { ...this.snapshot.customPrice.models, [key]: entry },
    }
    writeJsonAtomic(this.paths.customPrice, table)
    this.reload()
    return entry
  }

  /** Force a synchronous reload; used by fs.watch and by tests. */
  reload(): { changed: boolean; snapshot: ProgramConfigSnapshot } {
    if (this.closed) return { changed: false, snapshot: this.snapshot }
    const config = loadConfigCandidate(this.paths.config)
    if (config.errors.length > 0) {
      this.snapshot = { ...this.snapshot, errors: config.errors }
      return { changed: false, snapshot: this.snapshot }
    }
    const publicPrice = loadPriceCandidate(resolvePricePath(this.paths, config.config), DEFAULT_PRICING_TABLE, 'price.json')
    if (publicPrice.invalid) {
      this.snapshot = { ...this.snapshot, errors: publicPrice.errors }
      return { changed: false, snapshot: this.snapshot }
    }
    const customPrice = loadPriceCandidate(this.paths.customPrice, EMPTY_CUSTOM_PRICE_TABLE, 'custom_price.json')
    if (customPrice.invalid) {
      this.snapshot = { ...this.snapshot, errors: customPrice.errors }
      return { changed: false, snapshot: this.snapshot }
    }
    const merged = mergePriceTables(publicPrice.price, customPrice.price)
    const previousJson = JSON.stringify({
      config: this.snapshot.config,
      publicPrice: this.snapshot.publicPrice,
      customPrice: this.snapshot.customPrice,
      priceSource: this.snapshot.priceSource,
    })
    const next: ProgramConfigSnapshot = {
      config: config.config,
      price: merged,
      publicPrice: publicPrice.price,
      customPrice: customPrice.price,
      priceSource: publicPrice.source,
      errors: [],
    }
    const nextJson = JSON.stringify({
      config: next.config,
      publicPrice: next.publicPrice,
      customPrice: next.customPrice,
      priceSource: next.priceSource,
    })
    if (nextJson === previousJson) {
      if (this.snapshot.errors.length > 0) this.snapshot = next
      return { changed: false, snapshot: this.snapshot }
    }
    this.snapshot = next
    this.signatures = this.readSignatures(next.config)
    for (const listener of this.listeners) listener(next)
    return { changed: true, snapshot: next }
  }

  close(): void {
    this.closed = true
    if (this.debounce !== undefined) clearTimeout(this.debounce)
    if (this.poll !== undefined) clearInterval(this.poll)
    this.watcher?.close()
    this.watcher = undefined
  }

  private readSignatures(config: ProgramConfigDocument): string {
    return `${fileSignature(this.paths.config)}|${fileSignature(resolvePricePath(this.paths, config))}|${fileSignature(this.paths.customPrice)}`
  }

  private scheduleReload(): void {
    if (this.debounce !== undefined) clearTimeout(this.debounce)
    this.debounce = setTimeout(() => {
      this.debounce = undefined
      this.reload()
    }, 150)
    this.debounce.unref()
  }

  private startWatching(): void {
    try {
      this.watcher = fs.watch(this.paths.home, { persistent: false }, (_event, filename) => {
        if (filename === null || filename === 'config.json' || filename === 'price.json' || filename === 'custom_price.json') {
          this.scheduleReload()
        }
      })
      this.watcher.on('error', () => undefined)
    } catch {
      this.watcher = undefined
    }
  }

  private startPolling(pollMs: number): void {
    this.poll = setInterval(() => {
      const next = this.readSignatures(this.snapshot.config)
      if (next !== this.signatures) {
        this.signatures = next
        this.reload()
      }
    }, pollMs)
    this.poll.unref()
  }
}
