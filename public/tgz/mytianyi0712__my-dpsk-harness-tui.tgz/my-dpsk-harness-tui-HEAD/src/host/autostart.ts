/** Launch-at-login registration for the headless core daemon. */
import { execFileSync } from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const RUN_KEY = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run'
const RUN_VALUE = 'dpsk-core'
const MAC_LABEL = 'com.mydpsk.core'

export interface AutostartStatus {
  readonly supported: boolean
  readonly enabled: boolean
  readonly detail: string
}

export function autostartPaths(home = os.homedir()): { file: string; kind: string } {
  if (process.platform === 'win32') return { file: RUN_KEY, kind: 'windows' }
  if (process.platform === 'darwin') return { file: path.join(home, 'Library', 'LaunchAgents', MAC_LABEL + '.plist'), kind: 'mac' }
  if (process.platform === 'linux') return { file: path.join(home, '.config', 'autostart', 'dpsk-core.desktop'), kind: 'linux' }
  return { file: '', kind: 'unsupported' }
}

function windowsValue(): string | undefined {
  try {
    const out = execFileSync('reg', ['query', RUN_KEY, '/v', RUN_VALUE], { encoding: 'utf8', windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] })
    const row = out.split(String.fromCharCode(10)).find(line => line.includes(RUN_VALUE))
    if (row === undefined) return undefined
    const at = row.indexOf('REG_SZ')
    return at === -1 ? undefined : row.slice(at + 6).trim()
  } catch {
    return undefined
  }
}

export function autostartStatus(home = os.homedir()): AutostartStatus {
  const target = autostartPaths(home)
  if (target.kind === 'windows') {
    const value = windowsValue()
    return { supported: true, enabled: value !== undefined, detail: value ?? 'not registered' }
  }
  if (target.kind === 'unsupported') return { supported: false, enabled: false, detail: 'unsupported platform' }
  try {
    if (!fs.existsSync(target.file)) return { supported: true, enabled: false, detail: 'not registered' }
    const text = fs.readFileSync(target.file, 'utf8')
    if (target.kind === 'linux' && text.includes('Hidden=true')) return { supported: true, enabled: false, detail: 'disabled' }
    return { supported: true, enabled: true, detail: target.file }
  } catch (error) {
    return { supported: true, enabled: false, detail: error instanceof Error ? error.message : String(error) }
  }
}

function quote(value: string): string {
  return String.fromCharCode(34) + value + String.fromCharCode(34)
}

function commandLine(command: readonly string[]): string {
  return command.map(quote).join(' ')
}

function xmlEscape(value: string): string {
  return value.split('&').join('&amp;').split('<').join('&lt;').split('>').join('&gt;')
}

export async function setAutostart(enabled: boolean, command: readonly string[], home = os.homedir()): Promise<AutostartStatus> {
  const target = autostartPaths(home)
  try {
    if (target.kind === 'windows') {
      if (enabled) {
        execFileSync('reg', ['add', RUN_KEY, '/v', RUN_VALUE, '/t', 'REG_SZ', '/d', commandLine(command), '/f'], { windowsHide: true, stdio: 'ignore' })
      } else {
        try { execFileSync('reg', ['delete', RUN_KEY, '/v', RUN_VALUE, '/f'], { windowsHide: true, stdio: 'ignore' }) } catch { /* already absent */ }
      }
    } else if (target.kind === 'linux') {
      if (!enabled) {
        fs.rmSync(target.file, { force: true })
      } else {
        fs.mkdirSync(path.dirname(target.file), { recursive: true })
        const lines = [
          '[Desktop Entry]',
          'Type=Application',
          'Name=dpsk core',
          'Comment=Start the dpsk core daemon at login',
          'Exec=' + commandLine(command),
          'Terminal=false',
          'Hidden=false',
          'X-GNOME-Autostart-enabled=true',
          '',
        ]
        fs.writeFileSync(target.file, lines.join(String.fromCharCode(10)))
      }
    } else if (target.kind === 'mac') {
      if (!enabled) {
        fs.rmSync(target.file, { force: true })
      } else {
        fs.mkdirSync(path.dirname(target.file), { recursive: true })
        const q = String.fromCharCode(34)
        const args = command.map(value => '    <string>' + xmlEscape(value) + '</string>')
        const body = ['<plist version=' + q + '1.0' + q + '><dict>', '  <key>Label</key><string>' + MAC_LABEL + '</string>', '  <key>ProgramArguments</key><array>', ...args, '  </array>', '  <key>RunAtLoad</key><true/>', '  <key>KeepAlive</key><false/>', '</dict></plist>', '']
        fs.writeFileSync(target.file, body.join(String.fromCharCode(10)))
      }
    } else {
      return { supported: false, enabled: false, detail: 'unsupported platform' }
    }
  } catch (error) {
    return { ...autostartStatus(home), detail: error instanceof Error ? error.message : String(error) }
  }
  return autostartStatus(home)
}


