/**
 * Session log → transcript events for the renderer.
 *
 * The renderer is a pure consumer: the host normalizes the append-only session log
 * into `TranscriptEvent` rows and sends them as `session-snapshot` (full history)
 * and `session-frame` (append deltas). The mapping is the same one the pi-tui
 * transcript uses, so the two paths show the same content:
 *
 * - `user/message` → a user row. Non-user sources (the wechat bridge, a subagent)
 *   keep their label in `source` so the renderer can show the card the same way.
 * - `assistant/message` → an assistant row, with its reasoning text always carried.
 * - `tool/call` opens a tool row keyed by `callId`; the matching `tool/result`
 *   fills its output.
 * - `system/message`, `step/*`, `subagent/descriptor` and other bookkeeping events
 *   are not transcript rows and are skipped.
 *
 * The projection carries **the whole** row: reasoning, tool output, and diffs are
 * never cut here. Folding, verbosity, `session.thinking`, TPS and diff wrapping are
 * paint-time decisions in the renderer, so switching one of them never requires
 * re-running the model or re-reading a log the host already truncated.
 */

import type { ContentBlock, SessionEvent } from '../dsh-host/index.ts'
import type { TranscriptEvent } from '../ipc/kinds.ts'
import { contentText, parseArguments } from '../components/content.ts'
import { displayText } from '../components/text.ts'

/**
 * A JSON-safe copy of a value: the IPC layer serializes payloads, and a log event can
 * carry a class instance, a bigint, or a cycle. Primitives pass through, plain objects
 * and arrays are copied, and anything else is described by its `type`/`kind` tag so the
 * frame stays renderable instead of throwing inside `JSON.stringify`.
 */
export function jsonSafe(value: unknown, seen: Set<object> = new Set()): unknown {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value
  if (typeof value === 'number') return Number.isFinite(value) ? value : null
  if (typeof value === 'bigint') return value.toString()
  if (typeof value !== 'object') return undefined
  if (seen.has(value)) return '[circular]'
  seen.add(value)
  try {
    if (Array.isArray(value)) {
      return value.map(item => {
        const next = jsonSafe(item, seen)
        return next === undefined ? null : next
      })
    }
    const result: Record<string, unknown> = {}
    for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
      const next = jsonSafe(item, seen)
      if (next !== undefined) result[key] = next
    }
    return result
  } finally {
    seen.delete(value)
  }
}

/**
 * The message's blocks as JSON-safe values, each keeping its `type` tag.
 *
 * Image and file blocks are reduced to their reference (`attachmentId` / `name` /
 * `mediaType`): the log holds a reference, never bytes, and a block that named a local
 * path must not leak it through a renderer payload.
 */
export function contentBlocks(blocks: readonly unknown[]): unknown[] {
  return blocks.map(block => {
    const record = typeof block === 'object' && block !== null ? block as Record<string, unknown> : undefined
    const type = typeof record?.type === 'string' ? record.type : undefined
    if (record === undefined || type === undefined) return jsonSafe(block)
    if (type === 'image' || type === 'file') {
      const attachment = typeof record.attachment === 'object' && record.attachment !== null
        ? record.attachment as Record<string, unknown>
        : undefined
      if (attachment === undefined) return { type }
      return {
        type,
        attachment: {
          attachmentId: String(attachment.attachmentId ?? ''),
          ...(typeof attachment.name === 'string' ? { name: attachment.name } : {}),
          ...(typeof attachment.mediaType === 'string' ? { mediaType: attachment.mediaType } : {}),
        },
      }
    }
    return jsonSafe(block)
  }).filter(block => block !== undefined)
}

/**
 * Whether Markdown at the end of `text` is inside an unclosed inline span or fence.
 *
 * The host folds multiple model text blocks into one transcript row. A blank line between
 * blocks is the right paragraph separator, except when the model split an emphasis/code
 * span across the blocks: CommonMark does not let emphasis cross a blank line, so joining
 * `**bold` + `text**` with `\n\n` would print the markers literally. We only need to know
 * whether the accumulated text is currently open, so this is a deliberately small scanner,
 * not a Markdown parser. Fenced code and escaped delimiters are skipped.
 */
export function hasUnclosedInlineSpan(text: string): boolean {
  let fenced: string | undefined
  let code = false
  let bold = false
  let italic = false
  let strike = false
  const lines = text.split('\n')
  for (const line of lines) {
    const fence = /^\s*(```+|~~~+)/.exec(line)?.[1]
    if (fenced !== undefined) {
      if (fence !== undefined && fence[0] === fenced[0] && fence.length >= fenced.length) fenced = undefined
      continue
    }
    if (fence !== undefined) {
      fenced = fence
      continue
    }
    const escaped = (index: number): boolean => {
      let slashes = 0
      for (let at = index - 1; at >= 0 && line[at] === '\\'; at--) slashes += 1
      return slashes % 2 === 1
    }
    for (let index = 0; index < line.length;) {
      const char = line[index] ?? ''
      if (char === '`' && !escaped(index)) {
        code = !code
        index += 1
        continue
      }
      if (code) {
        index += 1
        continue
      }
      const pair = line.slice(index, index + 2)
      if ((pair === '**' || pair === '__') && !escaped(index)) {
        bold = !bold
        index += 2
        continue
      }
      if (pair === '~~' && !escaped(index)) {
        strike = !strike
        index += 2
        continue
      }
      // A leading `* ` is a list marker, not an emphasis opener.
      if (char === '*' && !escaped(index) && !(index === line.search(/\S/) && line[index + 1] === ' ')) {
        italic = !italic
      }
      index += 1
    }
  }
  return fenced !== undefined || code || bold || italic || strike
}

/**
 * Join the model's text blocks without breaking a span the model split across blocks.
 * Normal blocks keep a blank-line paragraph boundary; a currently open emphasis/code
 * span gets a single newline so it remains one CommonMark inline run.
 */
export function joinTextBlocks(blocks: readonly string[]): string {
  let joined = ''
  for (const block of blocks) {
    if (joined === '') {
      joined = block
      continue
    }
    joined += `${hasUnclosedInlineSpan(joined) ? '\n' : '\n\n'}${block}`
  }
  return joined
}

/**
 * One transcript row while the fold is still mutating it.
 *
 * Exported because the incremental fold carries a {@link TranscriptFoldState} between passes,
 * and that state owns the row objects a later event fills in.
 */
export interface MutableRow {
  id: string
  role: TranscriptEvent['role']
  sourceSeq?: number
  createdAt?: number
  step?: number
  callId?: string
  content?: readonly unknown[]
  toolArguments?: unknown
  text?: string
  tool?: string
  toolOutput?: string[]
  toolInput?: Record<string, string>
  source?: string
  reasoning?: string
  streaming?: boolean
  filePath?: string
  diff?: string[]
  status?: 'pending' | 'ok' | 'failed' | 'denied'
  attachments?: Array<{ readonly type: 'image' | 'file'; readonly attachmentId: string; readonly name?: string; readonly mediaType?: string }>
  model?: string
  /** This step's model time (`assistant/message` minus `step/start`): the `Thought` header. */
  durationMs?: number
  /** The whole turn's model time, set on the row that carries the turn's footer. */
  turnDurationMs?: number
  tokPerSec?: number
  /** `true` on the one assistant row of a turn that paints the footer. */
  footer?: boolean
  interrupted?: boolean
  error?: string
  turn?: number
}

/** What the fold accumulates for one turn, between its `turn/start` and its `turn/end`. */
interface TurnTotal {
  readonly start?: number
  outputTokens: number
  generationMs: number
  /** The turn's newest assistant row: the one that takes the footer when the turn ends. */
  last?: MutableRow
}

/**
 * State the fold carries between passes.
 *
 * A live session delivers one event at a time, so an incremental pass never sees a
 * `tool/call` together with its `tool/result`, nor a `step/start` together with the assistant
 * message it times. One instance per session keeps those pairs together — without it a tool
 * row painted `Running…` never learned its result, and a settled `Thought` had no duration —
 * and lets `turn/end` update a row that is already on screen.
 */
export interface TranscriptFoldState {
  readonly toolRows: Map<string, MutableRow>
  readonly stepStart: Map<string, number>
  readonly endedTurns: Map<number, string>
  readonly turns: Map<number, TurnTotal>
}

/** A fresh fold state: one per session (and one per snapshot read). */
export function createTranscriptFoldState(): TranscriptFoldState {
  return {
    toolRows: new Map(),
    stepStart: new Map(),
    endedTurns: new Map(),
    turns: new Map(),
  }
}

/**
 * Fold a session log into transcript rows.
 *
 * `events` is the durable snapshot; tool rows are matched to their results by
 * `callId`, so the result lands on the row the call opened. No display policy is
 * applied: every row carries its complete content.
 *
 * Pass a {@link TranscriptFoldState} to fold a long log in several passes (the live
 * session path): the pairs above then survive between passes, and an event that only
 * *updates* an earlier row returns that row again so the renderer can replace it by id.
 */
export function transcriptEvents(events: readonly SessionEvent[], state: TranscriptFoldState = createTranscriptFoldState()): TranscriptEvent[] {
  // The rows are built mutable so a `tool/result` can fill the row its call
  // opened; the returned array is handed to the IPC layer as read-only.
  const rows: MutableRow[] = []
  const toolRows = state.toolRows
  // `step/start` opens the model call; the assistant row that follows carries the
  // usage, so the footer's duration and tok/s come from the pair.
  const stepStart = state.stepStart
  const endedTurns = state.endedTurns
  const turns = state.turns
  for (const event of events) {
    switch (event.type) {
      case 'user/message': {
        // Injected context is not a message: a row for it would put the harness's own prompt
        // scaffolding (the runtime-context snapshot, the skill catalog, a compaction digest,
        // the system reminder) in front of the reader as if they had typed it. Those sources
        // carry a `form` describing the injection; only a plain `user` turn (and the bridge,
        // which is a real remote message) carries no form.
        const source = event.data.source as { kind?: string; form?: unknown; summary?: unknown }
        const sourceForm = source.form
        // The one injection meant for the reader is the model-change notice dsh appends when a
        // session's route moves (`form: 'notice'`, with a one-line account): dropping it like
        // every other injection left an in-session model switch with no trace in the
        // transcript, so the answer merely started coming from another model.
        const notice = source.kind === 'model-selection' && typeof source.summary === 'string'
          ? displayText(source.summary.trim())
          : ''
        if (notice === '' && source.kind !== 'user' && sourceForm !== undefined) break
        const text = notice !== '' ? notice : displayText(contentText(event.data.content).trim())
        // Attachments are references, never bytes: the renderer asks the host to read one
        // through `attachment-read` when the user opens it, and the row paints the name.
        const attachments: NonNullable<MutableRow['attachments']> = []
        for (const block of event.data.content) {
          if (block.type === 'image') {
            attachments.push({
              type: 'image',
              attachmentId: String(block.attachment.attachmentId),
              ...(block.attachment.name === undefined ? {} : { name: block.attachment.name }),
              mediaType: block.attachment.mediaType,
            })
            continue
          }
          if (block.type === 'file') {
            attachments.push({ type: 'file', attachmentId: String(block.attachment.attachmentId), name: block.attachment.name })
          }
        }
        if (text === '' && attachments.length === 0) break
        const jsonBlocks = contentBlocks(event.data.content)
        rows.push({
          id: `u${event.seq}`,
          role: 'user',
          sourceSeq: event.seq,
          ...(typeof event.time === 'number' ? { createdAt: event.time } : {}),
          ...(jsonBlocks.length === 0 ? {} : { content: jsonBlocks }),
          text,
          source: event.data.source.kind,
          ...(attachments.length === 0 ? {} : { attachments }),
        })
        break
      }
      case 'assistant/message': {
        const blocks = event.data.message.content
        const text = displayText(joinTextBlocks(
          blocks
            .filter((block): block is Extract<ContentBlock, { type: 'text' }> => block.type === 'text')
            .map(block => block.text),
        ).trim())
        // Reasoning always travels; the renderer's `session.thinking` decides whether it
        // paints expanded, folded, or as a one-line header.
        const reasoning = displayText(joinTextBlocks(
          blocks
            .filter((block): block is Extract<ContentBlock, { type: 'reasoning' }> => block.type === 'reasoning')
            .map(block => block.text),
        ).trim())
        if (text === '' && reasoning === '') break
        const jsonBlocks = contentBlocks(blocks)
        const start = stepStart.get(`${event.data.turn}:${event.data.step}`)
        const durationMs = start === undefined ? undefined : event.time - start
        const usage = event.data.usage
        const row: MutableRow = {
          id: `a${event.seq}`,
          role: 'assistant',
          sourceSeq: event.seq,
          ...(typeof event.time === 'number' ? { createdAt: event.time } : {}),
          turn: event.data.turn,
          step: event.data.step,
          ...(jsonBlocks.length === 0 ? {} : { content: jsonBlocks }),
          ...(text === '' ? {} : { text }),
          ...(reasoning === '' ? {} : { reasoning }),
          ...(event.data.message.source?.kind === 'model' ? { model: event.data.message.source.model } : {}),
          ...(durationMs === undefined || durationMs <= 0 ? {} : { durationMs }),
        }
        rows.push(row)
        // The turn's footer is accumulated here and attached when the turn ends: one step of
        // a tool-using turn is not the end of the exchange, and a footer between two steps
        // read as if the turn had finished.
        const total = turns.get(event.data.turn) ?? { outputTokens: 0, generationMs: 0 }
        if (durationMs !== undefined && durationMs > 0) total.generationMs += durationMs
        if (usage !== undefined) total.outputTokens += usage.outputTokens
        total.last = row
        turns.set(event.data.turn, total)
        break
      }
      case 'step/start': {
        stepStart.set(`${event.data.turn}:${event.data.step}`, event.time)
        break
      }
      case 'turn/start': {
        turns.set(event.data.turn, { start: event.time, outputTokens: 0, generationMs: 0 })
        break
      }
      case 'turn/end': {
        endedTurns.set(event.data.turn, event.data.reason.kind)
        const total = turns.get(event.data.turn)
        if (total?.last !== undefined) {
          const row = total.last
          // The footer's pair is the turn's own: model time across every step (tool execution
          // happens after each step's message settles, so it is already excluded) and the
          // turn's output tokens. The per-step `durationMs` stays for the `Thought` header.
          const generationMs = total.generationMs
          row.footer = true
          if (generationMs > 0) {
            row.turnDurationMs = generationMs
            row.tokPerSec = Math.round(total.outputTokens / (generationMs / 1000))
          }
          const kind = event.data.reason.kind
          if (kind === 'aborted' || kind === 'interrupted' || kind === 'error') row.interrupted = true
          // A full replay already has this row in `rows`; the incremental pass does not, and
          // the renderer only repaints a row it is sent again.
          if (!rows.includes(row)) rows.push(row)
        }
        turns.delete(event.data.turn)
        break
      }
      case 'tool/call': {
        const row: MutableRow = {
          id: `t${event.seq}`,
          role: 'tool',
          sourceSeq: event.seq,
          ...(typeof event.time === 'number' ? { createdAt: event.time } : {}),
          tool: event.data.name,
          toolOutput: [],
          status: 'pending',
          turn: event.data.turn,
          step: event.data.step,
          callId: event.data.callId,
        }
        // The strReplaceEditor card shows the path and the +/- lines the model
        // asked for; the same argument keys the pi-tui card reads (transcript.ts's
        // `strReplaceEditorSections`), so the two paths show one diff.
        const parsed = parseArguments(event.data.arguments)
        if (parsed.valid && typeof parsed.value === 'object' && parsed.value !== null) {
          const args = parsed.value as Record<string, unknown>
          // The row header upstream paints is built from these scalars; nested objects
          // (an edit's `edits` array, a subagent's config) are skipped rather than
          // stringified, so the header never shows a JSON blob.
          const scalars: Record<string, string> = {}
          for (const [key, value] of Object.entries(args)) {
            if (Object.keys(scalars).length >= 6) break
            if (typeof value === 'string') scalars[key] = value
            else if (typeof value === 'number') scalars[key] = String(value)
          }
          // The complete arguments travel beside the scalar header, so a card that needs
          // the nested `edits` array does not have to re-parse a display string.
          row.toolArguments = parsed.value
          if (Object.keys(scalars).length > 0) row.toolInput = scalars
          const command = typeof args.command === 'string' ? args.command : ''
          const path = typeof args.path === 'string' ? args.path : ''
          if (path !== '') row.filePath = path
          const lines: string[] = []
          if (command === 'create') lines.push(...String(args.file_text ?? '').split('\n').map(line => `+ ${line}`))
          else if (command === 'str_replace') {
            lines.push(...String(args.old_str ?? '').split('\n').map(line => `- ${line}`))
            lines.push(...String(args.new_str ?? '').split('\n').map(line => `+ ${line}`))
          } else if (command === 'insert') lines.push(...String(args.new_str ?? '').split('\n').map(line => `+ ${line}`))
          if (lines.length > 0) row.diff = lines
        }
        rows.push(row)
        toolRows.set(event.data.callId, row)
        // The map outlives the pass now, so it cannot grow for a whole session: the oldest
        // entries are settled calls nothing looks up again.
        if (toolRows.size > 512) {
          const oldest = toolRows.keys().next()
          if (!oldest.done) toolRows.delete(oldest.value)
        }
        break
      }
      case 'tool/result': {
        const row = toolRows.get(event.data.message.toolCallId)
        if (row === undefined) break
        const output = displayText(contentText(event.data.message.content).trim())
        // The row the call opened is filled in place: the snapshot carries one row
        // per tool call with its output, and `session-frame` sends the same row
        // again with the output attached (in-place update by `id`).
        row.toolOutput = output === '' ? [] : output.split('\n')
        if (event.data.message.isError === true) {
          const reason = event.data.error?.reason ?? ''
          row.status = /approval|denied|rejected/i.test(`${event.data.error?.code ?? ''} ${reason}`) ? 'denied' : 'failed'
          if (reason !== '') row.error = reason
        } else {
          row.status = 'ok'
        }
        // A full replay already has the row; a live pass saw the call in an earlier one and
        // has to hand the settled row back, or the renderer keeps painting `Running…`.
        if (!rows.includes(row)) rows.push(row)
        break
      }
      default:
        break
    }
  }
  // A turn that ended aborted, interrupted, or with an error marks its assistant
  // rows; the footer shows `interrupted` and the error line.
  for (const row of rows) {
    if (row.turn === undefined) continue
    const kind = endedTurns.get(row.turn)
    if (kind === 'aborted' || kind === 'interrupted' || kind === 'error') row.interrupted = true
  }
  return rows
}
