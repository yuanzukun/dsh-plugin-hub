/**
 * Host identity for the Host Descriptor: the bundle's own id and version.
 *
 * The plugin host describes itself to plugins (`hostId` / `hostVersion`), and
 * the `/plugins` panel prints the same pair. Hardcoding the version drifts from
 * the release line, so the identity is read from the manifest shipped next to
 * the built module: `lib/host/host-identity.js` resolves `../../dsh-plugin.json`
 * to the package root, and the same relative path resolves to the repo root in
 * source. Falls back to the shipped defaults when the manifest is unreadable.
 */

import { readFileSync } from 'node:fs'

/** Package id, matching `package.json` name, `dsh-plugin.json` id, and the launcher. */
export const HOST_ID = 'my-dpsk-harness-tui'

const FALLBACK_VERSION = '0.5.0'

function readManifestVersion(): string {
  try {
    const text = readFileSync(new URL('../../dsh-plugin.json', import.meta.url), 'utf8')
    const manifest = JSON.parse(text) as { version?: unknown }
    return typeof manifest.version === 'string' && manifest.version !== '' ? manifest.version : FALLBACK_VERSION
  } catch {
    return FALLBACK_VERSION
  }
}

/** Bundle version, read once from the shipped manifest. */
export const HOST_VERSION = readManifestVersion()
