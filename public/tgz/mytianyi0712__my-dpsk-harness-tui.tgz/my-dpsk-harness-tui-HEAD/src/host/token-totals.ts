/**
 * Token-usage folding for the renderer's status bar.
 *
 * dsh reports cache buckets as OPTIONAL per model call, and a call that omits them is not
 * the same as a call with zero cache traffic. This fold keeps the distinction: the strict
 * `cacheReadComplete` / `cacheBucketsComplete` flags break as soon as any sample omits a
 * bucket, while `cacheReadObserved` records that at least one sample did report cache reads.
 *
 * The UI needs both: a session whose provider never reports cache reads must stay `—`, but a
 * cold first call that omitted zero-valued fields must not poison every later cache-hit
 * sample. Once `cacheReadObserved` is true, omitted optional fields are treated as zero cache
 * traffic for the cumulative session ratio. The strict flags remain available for callers
 * that need exact per-sample completeness.
 */

/** The running totals the status bar reads, one counter per disjoint bucket. */
export interface TokenTotals {
  readonly inputTokens: number
  readonly outputTokens: number
  readonly cacheReadTokens: number
  readonly cacheWriteTokens: number
}

/** One provider usage sample, as `assistant/message` carries it. */
export interface UsageSample {
  readonly inputTokens: number
  readonly outputTokens: number
  readonly cacheReadTokens?: number
  readonly cacheWriteTokens?: number
}

export interface UsageFold {
  readonly totals: TokenTotals
  /** At least one folded sample carried an explicit cacheReadTokens value. */
  readonly cacheReadObserved: boolean
  /** Every folded sample carried cacheReadTokens. */
  readonly cacheReadComplete: boolean
  /** Every folded sample carried cacheWriteTokens. */
  readonly cacheWriteComplete: boolean
  /** Every folded sample carried both cache buckets. */
  readonly cacheBucketsComplete: boolean
}

export const EMPTY_USAGE_FOLD: UsageFold = {
  totals: { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 },
  cacheReadObserved: false,
  cacheReadComplete: true,
  cacheWriteComplete: true,
  cacheBucketsComplete: true,
}

/** Add one sample. A sample missing a cache bucket clears the completeness flag forever. */
export function foldUsageSample(fold: UsageFold, usage: UsageSample): UsageFold {
  return {
    totals: {
      inputTokens: fold.totals.inputTokens + usage.inputTokens,
      outputTokens: fold.totals.outputTokens + usage.outputTokens,
      cacheReadTokens: fold.totals.cacheReadTokens + (usage.cacheReadTokens ?? 0),
      cacheWriteTokens: fold.totals.cacheWriteTokens + (usage.cacheWriteTokens ?? 0),
    },
    cacheReadObserved: fold.cacheReadObserved || usage.cacheReadTokens !== undefined,
    cacheReadComplete: fold.cacheReadComplete && usage.cacheReadTokens !== undefined,
    cacheWriteComplete: fold.cacheWriteComplete && usage.cacheWriteTokens !== undefined,
    cacheBucketsComplete: fold.cacheBucketsComplete
      && usage.cacheReadTokens !== undefined
      && usage.cacheWriteTokens !== undefined,
  }
}
