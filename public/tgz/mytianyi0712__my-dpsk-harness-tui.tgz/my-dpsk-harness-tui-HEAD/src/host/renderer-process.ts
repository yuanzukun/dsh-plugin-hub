/**
 * Renderer process management.
 *
 * The renderer is a Bun-compiled OpenTUI binary that owns the TTY. The host
 * spawns it with `stdio: ['inherit','inherit','ipc']`: the renderer inherits the
 * terminal and talks to the host on the IPC channel (fd 3). The host never writes
 * to the TTY while the renderer is alive — dsh stdout is routed to a log file
 * (see `src/host/renderer-log.ts`).
 *
 * Terminal restoration is the host's responsibility on every path that does not
 * go through the renderer's own `destroy()`:
 * - normal exit: the renderer emits the restore sequence itself;
 * - crash / kill: the renderer never got to restore, so the host writes the
 *   sequence when the child exits abnormally;
 * - Ctrl+C: `exitOnCtrlC` runs the renderer's `destroy()`, the normal path.
 */

import { spawn, type ChildProcess } from 'node:child_process'
import { existsSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { writeTerminal } from './renderer-log.ts'
import { IpcTransport, childChannel } from '../ipc/transport.ts'
import { RENDERER_PROTOCOL_VERSION } from '../ipc/envelope.ts'
import { HOST_CAPABILITIES } from '../ipc/kinds.ts'
import { negotiateRenderer, helloAck, type HostView, type Negotiation } from '../ipc/negotiate.ts'

/**
 * The control sequence that returns a terminal to a usable state. OpenTUI's
 * `destroy()` emits the equivalent; this is the host's fallback when the
 * renderer dies before it can restore.
 *
 * Order matters: SGR reset and the mode resets first, then the TUI frame is cleared while
 * it is still the visible buffer, and only then does `?1049l` put the shell's own screen
 * back. Clearing after leaving the alternate screen would erase the user's scrollback
 * instead of the frame.
 */
export const TERMINAL_RESTORE =
  '\x1b[0m\x1b[?1000l\x1b[?1002l\x1b[?1003l\x1b[?1006l\x1b[?2004l\x1b[?2027l\x1b[?2031l\x1b[2J\x1b[H\x1b[?1049l\x1b[?25h\x1b]0;\x07'

/** Where the launcher caches the renderer binary for this platform. */
export function rendererCacheDir(version: string, platform: string, home: string = homedir()): string {
  return join(home, '.dsh', 'dpsk', 'renderer', `${version}-${platform}`)
}

/** The current platform key used in the renderer cache path. */
export function platformKey(platform: string = process.platform, arch: string = process.arch): string {
  return `${platform}-${arch}`
}

/** The executable suffix for a platform. */
export function rendererExecutable(platform: string = process.platform): string {
  return platform === 'win32' ? '.exe' : ''
}

/**
 * The artifact name the launcher downloads and the development build produces:
 * `dpsk-renderer-<platform>-<arch>`, with `.exe` on Windows. The host and the launcher
 * must look for the same name, or a cached artifact is invisible to the host.
 */
export function rendererArtifactName(platform: string = platformKey()): string {
  return `dpsk-renderer-${platform}${platform.startsWith('win32') ? '.exe' : ''}`
}

/**
 * Locate the renderer binary.
 *
 * Order: `DSH_RENDERER_PATH` (explicit, used by tests and by a launcher that
 * downloaded the binary), the launcher's cache directory for the running
 * platform, then a development build next to this source tree. Returns
 * `undefined` when none of them exists, so the host can report the missing
 * binary instead of spawning a path that does not exist.
 */
export function resolveRendererPath(version: string, packageRoot: string, home: string = homedir()): string | undefined {
  const env = process.env.DSH_RENDERER_PATH
  if (env !== undefined && env !== '' && existsSync(env)) return env
  const cached = join(rendererCacheDir(version, platformKey(), home), rendererArtifactName())
  if (existsSync(cached)) return cached
  const dev = join(packageRoot, 'renderer', 'dist', rendererArtifactName())
  if (existsSync(dev)) return dev
  return undefined
}

export interface RendererProcessOptions {
  readonly hostView: HostView
  /** Called with the negotiated answer so the host can push initial state. */
  onAck?: (negotiation: Negotiation, ack: ReturnType<typeof helloAck>) => void
  /** Called for every upstream envelope the renderer sends. */
  onEnvelope?: (envelope: { protocolVersion: number; seq: number; kind: string; payload: unknown }) => void
  /** Called when the renderer exits. `abnormal` is true for a crash, a signal, or a non-zero code. */
  onExit?: (code: number | null, signal: string | null, abnormal: boolean) => void
  /** Where terminal restore sequences and crash reports are written. */
  write?: (text: string) => void
  /**
   * Spawn implementation, defaulting to `node:child_process`'s `spawn`. Tests
   * inject a fake child so the handshake, the crash restore, and the `bye`
   * shutdown are checked without a real renderer binary.
   */
  spawn?: (path: string, args: readonly string[], options: { stdio: readonly string[] }) => ChildProcess
  /** Accept a fresh hello from a reattached renderer and replay the full snapshot. */
  allowReattach?: boolean
}

export interface RendererHandle {
  child: ChildProcess
  transport: IpcTransport
  /** Send one downstream envelope to the renderer. */
  send: (kind: string, payload: unknown) => void
  /** Ask the renderer to shut down. */
  bye: () => void
  /** Put the terminal back without touching the child: used when the renderer is already
   * leaving on its own, so a kill would truncate the restore it is writing. */
  restore: () => void
  /** Kill the renderer and restore the terminal. A stop the host asked for is not
   * reported as an abnormal exit. */
  stop: () => void
}

/**
 * Spawn the renderer and run the handshake.
 *
 * The host sends `hello-ack` as soon as the renderer announces itself. The
 * renderer creates its CLI renderer only after a compatible answer, so the
 * terminal is handed over after negotiation, not before.
 */
export function spawnRenderer(path: string, options: RendererProcessOptions): RendererHandle {
  // `process.stdout.write` is routed to the log once the renderer owns the TTY (see
  // `renderer-log.ts`), so the default writer goes to the descriptor instead: a restore
  // sequence that lands in a log file restores nothing.
  const write = options.write ?? writeTerminal
  const spawnImpl = options.spawn ?? spawn
  const child = spawnImpl(path, [], { stdio: ['inherit', 'inherit', 'ipc'] })
  const transport = new IpcTransport(
    childChannel(child, text => write(`dpsk-renderer: ${text}\n`)),
    (level, text) => {
      if (level === 'error') write(`dpsk-renderer: ${text}\n`)
    },
  )

  let acked = false
  let exited = false

  // A shutdown the host asked for is not a crash: `stop()` kills the child, and the
  // resulting SIGTERM must not be reported as an abnormal exit (the caller would try to
  // notify a renderer that is already gone, over a channel that is already closed).
  let stopping = false
  transport.onEnvelope(envelope => {
    if (envelope.kind === 'hello' && (!acked || options.allowReattach === true)) {
      acked = true
      const negotiation = negotiateRenderer(envelope, options.hostView)
      const ack = helloAck(negotiation, options.hostView)
      transport.send('hello-ack', ack)
      options.onAck?.(negotiation, ack)
      return
    }
    options.onEnvelope?.(envelope)
  })

  // A spawn failure (a missing or unreadable binary) fires `error`, and on some platforms no
  // `exit` follows it. Without this handler the host waits for a handshake that can never
  // arrive; the terminal was never handed over, so only the report is needed.
  child.on('error', (error: Error) => {
    if (exited) return
    exited = true
    write(`dpsk-renderer: could not start the renderer: ${error.message}\n`)
    options.onExit?.(null, null, true)
  })

  child.on('exit', (code, signal) => {
    // One terminal outcome per child: a spawn error already reported it, and a real exit
    // after a `stop()` has nothing left to restore.
    if (exited) return
    exited = true
    const abnormal = !stopping && (code !== 0 || signal !== null)
    if (abnormal) {
      // The renderer never restored the terminal; put it back before the user
      // sees a frozen or mouse-tracking shell.
      write(TERMINAL_RESTORE)
      write(`dpsk-renderer: exited abnormally (code ${code ?? 'null'}, signal ${signal ?? 'none'})\n`)
    }
    options.onExit?.(code, signal, abnormal)
  })

  // A renderer that closes its own IPC channel does not exit: it keeps painting and
  // keeps taking keystrokes, and `exit` never fires. `disconnect` is the signal. It
  // owns the terminal and can no longer hear the host, so it is killed and the terminal
  // is put back. A renderer that is on its way out also disconnects, so the kill is
  // scheduled and skipped when its exit lands first.
  child.on('disconnect', () => {
    if (exited) return
    setTimeout(() => {
      if (exited) return
      write(TERMINAL_RESTORE)
      write('dpsk-renderer: IPC channel closed by the renderer while it was alive\n')
      child.kill()
    }, 200)
  })

  return {
    child,
    transport,
    send: (kind, payload) => transport.send(kind, payload),
    bye: () => transport.send('bye', { reason: 'host shutdown' }),
    restore: () => write(TERMINAL_RESTORE),
    stop: () => {
      stopping = true
      // Restore before the kill: a kill that lands mid-write must not swallow the sequence.
      write(TERMINAL_RESTORE)
      child.kill()
    },
  }
}

/** The host's declared capabilities and required renderer capabilities. */
export function defaultHostView(hostId: string, hostVersion: string, terminalAuthorized: boolean): HostView {
  // The launcher inherits the terminal's `COLUMNS` / `LINES`; the renderer inherits the same
  // environment, so the ack's echo is the grid both sides start from. A missing or non-positive
  // value is left out: the renderer's own measurement replaces it on the first resize.
  const columns = Number(process.env.COLUMNS)
  const lines = Number(process.env.LINES)
  const grid = columns > 0 && lines > 0 ? { width: columns, height: lines } : undefined
  return {
    hostId,
    hostVersion,
    capabilities: [...HOST_CAPABILITIES],
    requiredCapabilities: ['transcript', 'composer'],
    terminalAuthorized,
    ...(grid === undefined ? {} : { terminalSize: grid }),
  }
}

export { RENDERER_PROTOCOL_VERSION }
