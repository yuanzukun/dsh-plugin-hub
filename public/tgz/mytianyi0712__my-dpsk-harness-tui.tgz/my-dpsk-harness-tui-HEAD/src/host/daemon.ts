/** Local daemon transport: a named-pipe/Unix-socket bridge between the core host and a TUI client. */
import { createHash, randomBytes, timingSafeEqual } from 'node:crypto'
import { EventEmitter } from 'node:events'
import fs from 'node:fs'
import net, { type Socket } from 'node:net'
import os from 'node:os'
import path from 'node:path'
import type { ChildProcess } from 'node:child_process'
import { programConfigPaths } from './program-config.ts'

export interface DaemonPaths {
  readonly runtime: string
  readonly socket: string
  readonly token: string
  readonly pid: string
  readonly log: string
}

export function daemonPaths(env: NodeJS.ProcessEnv = process.env, home = os.homedir()): DaemonPaths {
  const runtime = programConfigPaths(env, home).runtime
  const key = createHash('sha256').update(programConfigPaths(env, home).home).digest('hex').slice(0, 16)
  return {
    runtime,
    socket: process.platform === 'win32' ? '\\\\.\\pipe\\dpsk-' + key : path.join(runtime, 'daemon.sock'),
    token: path.join(runtime, 'daemon.token'),
    pid: path.join(runtime, 'daemon.pid'),
    log: path.join(runtime, 'core.log'),
  }
}

export function readDaemonToken(paths = daemonPaths()): string | undefined {
  try {
    const token = fs.readFileSync(paths.token, 'utf8').trim()
    return token === '' ? undefined : token
  } catch {
    return undefined
  }
}

export function writeDaemonIdentity(paths = daemonPaths()): string {
  fs.mkdirSync(paths.runtime, { recursive: true })
  const token = randomBytes(32).toString('hex')
  fs.writeFileSync(paths.token, token, { encoding: 'utf8', mode: 0o600 })
  fs.writeFileSync(paths.pid, String(process.pid), 'utf8')
  return token
}

/** A ChildProcess-shaped object whose messages travel over one local socket. */
export interface DaemonBridge {
  readonly child: ChildProcess
  attach(socket: Socket, initial?: string): void
  detach(): void
  connected(): boolean
}

interface WireClient {
  readonly socket: Socket
  buffer: string
}

export function createDaemonBridge(onClientGone: () => void): DaemonBridge {
  let client: WireClient | undefined
  const write = (socket: Socket, value: unknown): void => {
    if (socket.destroyed || !socket.writable) return
    try {
      socket.write(JSON.stringify(value) + '\n')
    } catch {
      // A disconnected terminal is the normal detach path.
    }
  }
  const child = new EventEmitter() as EventEmitter & { send: (message: string) => void; kill: () => void }
  child.send = message => {
    if (client === undefined) return
    write(client.socket, { type: 'message', data: message })
  }
  child.kill = () => {
    const current = client
    client = undefined
    if (current !== undefined) current.socket.destroy()
  }
  const gone = (socket: Socket): void => {
    if (client?.socket !== socket) return
    client = undefined
    onClientGone()
  }
  const consume = (socket: Socket, chunk: string): void => {
    const active = client
    if (active?.socket !== socket) return
    active.buffer += chunk
    for (;;) {
      const newline = active.buffer.indexOf('\n')
      if (newline === -1) return
      const line = active.buffer.slice(0, newline).trim()
      active.buffer = active.buffer.slice(newline + 1)
      if (line === '') continue
      try {
        const message = JSON.parse(line) as { type?: string; data?: unknown }
        if (message.type === 'message' && typeof message.data === 'string') child.emit('message', message.data)
        else if (message.type === 'detach') {
          const current = client
          client = undefined
          current?.socket.destroy()
          onClientGone()
        }
      } catch {
        // The client is untrusted; one malformed line drops only itself.
        socket.destroy()
      }
    }
  }
  return {
    child: child as unknown as ChildProcess,
    attach(socket, initial = '') {
      const previous = client?.socket
      client = { socket, buffer: initial }
      previous?.destroy()
      socket.on('data', chunk => consume(socket, String(chunk)))
      socket.on('close', () => gone(socket))
      socket.on('error', () => gone(socket))
      consume(socket, '')
    },
    connected() {
      return client !== undefined && !client.socket.destroyed
    },
    detach() {
      const current = client
      client = undefined
      current?.socket.destroy()
      onClientGone()
    },
  }
}

export interface DaemonServer {
  readonly paths: DaemonPaths
  readonly token: string
  close(): void
}

export interface DaemonServerOptions {
  readonly bridge: DaemonBridge
  readonly onShutdown: () => void
  readonly paths?: DaemonPaths
}

function sameToken(left: string, right: string): boolean {
  const a = Buffer.from(left)
  const b = Buffer.from(right)
  return a.length === b.length && timingSafeEqual(a, b)
}

export async function startDaemonServer(options: DaemonServerOptions): Promise<DaemonServer> {
  const paths = options.paths ?? daemonPaths()
  const token = writeDaemonIdentity(paths)
  if (process.platform !== 'win32') fs.rmSync(paths.socket, { force: true })
  let closed = false
  const server = net.createServer(socket => {
    socket.setEncoding('utf8')
    let buffer = ''
    let authorized = false
    const timer = setTimeout(() => { if (!authorized) socket.destroy() }, 5_000)
    timer.unref?.()
    const onData = (chunk: string): void => {
      buffer += chunk
      for (;;) {
        const newline = buffer.indexOf('\n')
        if (newline === -1) return
        const line = buffer.slice(0, newline).trim()
        buffer = buffer.slice(newline + 1)
        if (line === '') continue
        let message: { type?: string; token?: string }
        try {
          message = JSON.parse(line) as { type?: string; token?: string }
        } catch {
          socket.destroy()
          return
        }
        if (!authorized) {
          if (typeof message.token !== 'string' || !sameToken(message.token, token)) {
            socket.end(JSON.stringify({ type: 'error', message: 'unauthorized' }) + '\n')
            return
          }
          authorized = true
          clearTimeout(timer)
          if (message.type === 'ping') {
            socket.end(JSON.stringify({ type: 'ok' }) + '\n')
            return
          }
          if (message.type === 'shutdown') {
            socket.end(JSON.stringify({ type: 'ok' }) + '\n')
            setTimeout(options.onShutdown, 20)
            return
          }
          if (message.type !== 'attach') {
            socket.end(JSON.stringify({ type: 'error', message: 'unknown request' }) + '\n')
            return
          }
          socket.write(JSON.stringify({ type: 'ready' }) + '\n')
          socket.removeListener('data', onData)
          options.bridge.attach(socket, buffer)
          return
        }
      }
    }
    socket.on('data', onData)
    socket.on('close', () => clearTimeout(timer))
    socket.on('error', () => clearTimeout(timer))
  })
  await new Promise<void>((resolve, reject) => {
    const onError = (error: Error): void => {
      server.removeListener('listening', onListening)
      reject(error)
    }
    const onListening = (): void => {
      server.removeListener('error', onError)
      resolve()
    }
    server.once('error', onError)
    server.once('listening', onListening)
    server.listen(paths.socket)
  })
  const close = (): void => {
    if (closed) return
    closed = true
    server.close()
    if (process.platform !== 'win32') fs.rmSync(paths.socket, { force: true })
    fs.rmSync(paths.token, { force: true })
    fs.rmSync(paths.pid, { force: true })
  }
  process.once('exit', close)
  return { paths, token, close }
}


