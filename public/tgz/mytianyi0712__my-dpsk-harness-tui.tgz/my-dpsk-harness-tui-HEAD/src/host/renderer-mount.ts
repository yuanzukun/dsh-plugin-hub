/**
 * Host-side renderer mount.
 *
 * The wiring between dsh and the renderer child process. Everything the renderer
 * needs is injected, so the mount is testable with fakes and the plugin supplies
 * the real seams:
 *
 * - `snapshot` reads the current session log and folds it into a `session-snapshot`
 *   payload. It is sent once, right after the handshake, so the transcript is on
 *   screen before the first frame.
 * - `subscribe` reports transcript deltas (the durable session events plus the live
 *   assistant stream frames) as `session-frame` payloads.
 * - `submit` receives the composer's `send-message` and runs the host's own
 *   submit path, so slash commands, the interjection queue, and title refresh stay
 *   in the host: the renderer never touches dsh services.
 *
 * The mount owns the child process lifecycle: it routes dsh's stdout to the log
 * file, spawns the renderer, sends the initial state on the handshake, and restores
 * the terminal when the renderer exits abnormally.
 */

import { spawnRenderer, defaultHostView, type RendererHandle } from './renderer-process.ts'
import type { HostView } from '../ipc/negotiate.ts'
import type { ChildProcess } from 'node:child_process'
import { routeStdoutToLog, tuiLogPath, writeTerminal, type RoutedStreams } from './renderer-log.ts'
import { transcriptEvents } from './transcript-events.ts'
import type { ApprovalRequestPayload, AttachmentReadPayload, CommandCatalogPayload, CommandResultPayload, FormFieldSpec, HostPluginItem, InterjectDeletePayload, InterjectEditPayload, InterjectionItem, InterruptPayload, McpServerItem, ModelCatalogPayload, QuestionAnswerItem, QuestionRequestPayload, QuestionSpec, QuestionTimeoutPayload, ReasoningEffortsPayload, SelectionPayload, SendMessagePayload, SessionListPayload, SessionOpPayload, SessionSnapshotPayload, ShellJobOpPayload, ShellJobView, SkillSpec, SubagentDescriptor, TerminalEndPayload, TerminalFramePayload, TerminalOpPayload, TodoItem, TranscriptEvent, UsagePayload } from '../ipc/kinds.ts'

export interface RendererMountDeps {
  /** Where the renderer binary is; `undefined` makes the mount report and stop. */
  rendererPath: string | undefined
  /**
   * How long a renderer that asked to quit may take before the host kills it. The renderer
   * restores the terminal on its way out, so killing it earlier truncates that sequence.
   */
  readonly byeGraceMs?: number
  /** Accept a renderer hello after a detach and replay the full state. */
  readonly allowReattach?: boolean
  /** `/exit` detaches the renderer instead of stopping this mount. */
  readonly detachOnBye?: boolean
  readonly hostView?: HostView
  /** The session log folded to transcript rows, plus the state the shell shows. */
  snapshot: () => SessionSnapshotPayload
  /** Push transcript deltas; the listener is unsubscribed when the mount stops. */
  subscribe: (emit: (sessionId: string, events: readonly TranscriptEvent[]) => void) => () => void
  /** The composer's submit, routed through the host's exact-session send path. */
  submit: (request: SendMessagePayload) => Promise<void>
  /** The reasoning efforts the renderer's ctrl+t cycles through. */
  efforts?: () => ReasoningEffortsPayload
  /** The complete session catalog for the renderer's picker. */
  sessions?: () => SessionListPayload['sessions']
  /** The model catalog for the current session. */
  models?: () => ModelCatalogPayload['models']
  /** The slash command registry for the composer's completion. */
  commands?: () => CommandCatalogPayload['commands']
  /** Execute an exact session operation and return its real result. */
  sessionOp?: (request: SessionOpPayload) => Promise<unknown>
  /** The renderer picked a model / effort / permission / preset. The host writes
   * it back through its settings and selection seams; the renderer never does. */
  /** The host applied a selection; the mount re-sends the catalogs so the pickers mark
   * the real current row. */
  onSelectionApplied?: () => void
  setSelection?: (selection: SelectionPayload) => Promise<void>
  /** Cancel one queued message owned by the requested session and return its text. */
  editInterjection?: (request: InterjectEditPayload) => string | undefined
  /** Delete one queued message id in the requested session inbox. */
  deleteInterjection?: (request: InterjectDeletePayload) => Promise<void>

  /** Read one exact durable attachment reference from a session-owned log. */
  readAttachment?: (request: AttachmentReadPayload) => Promise<unknown>
  /** Subscribe to the WeChat bridge's persistent output (log / qr / error / status).
   * The bridge buffers output before a subscriber exists and replays it on subscribe,
   * so the QR code a user needs is never lost between startup and the first frame. */
  wechatOutput?: (emit: (message: { kind: 'log' | 'qr' | 'error' | 'status'; text: string }) => void) => () => void
  /**
   * The subagent list the renderer draws. The host owns the list (it is fed by
   * `subagent/descriptor` session events); `emit` is called with the current list on
   * subscribe and on every change, and the returned function unsubscribes. The renderer
   * never sees the session events, so the list is pushed, not derived.
   */
  subagents?: (emit: (sessionId: string, agents: readonly SubagentDescriptor[]) => void) => () => void
  /** The skill list, scoped to the session/workspace. */
  skills?: (emit: (sessionId: string, skills: readonly SkillSpec[]) => void) => () => void
  /**
   * The session's token usage and context occupancy. The host pushes it from
   * `updateStatusValues()` (the same refresh the pi-tui footer reads), so the renderer's
   * footer and sidebar see the numbers the harness actually measures. `cost` stays
   * undefined: dsh has no price table, and the renderer shows no `$` segment.
   */
  usage?: (emit: (usage: UsagePayload) => void) => () => void
  /** The workspace branch for the exact session. */
  gitBranch?: (emit: (sessionId: string, branch: string | undefined) => void) => () => void
  /** Configured MCP clients and their live loader phases; emits again when the phase moves. */
  mcpServers?: (emit: (servers: readonly McpServerItem[]) => void) => () => void
  /** Real Loader plugin inventory; undefined means the optional inventory service is absent. */
  hostPlugins?: () => Promise<readonly HostPluginItem[] | undefined>
  /** Session-owned shell jobs; the projection carries exact owner and output byte coordinates. */
  shellJobs?: (emit: (sessionId: string, jobs: readonly ShellJobView[]) => void) => () => void
  shellJobOp?: (request: ShellJobOpPayload) => Promise<unknown>
  terminalOp?: (request: TerminalOpPayload, emit: (kind: 'terminal-frame' | 'terminal-end', payload: TerminalFramePayload | TerminalEndPayload) => void) => Promise<unknown>
  /** The session's todo list. */
  todos?: (emit: (sessionId: string, items: readonly TodoItem[]) => void) => () => void
  /** The pending messages owned by one session. */
  interjections?: (emit: (sessionId: string, items: readonly InterjectionItem[]) => void) => () => void
  /** A `/wechat-*` command the renderer asked the host to run. `op` is the suffix
   * after `/wechat-`; the host builds the line and runs it through its own command
   * path, so argument parsing and unknown-command rejection stay in the host. */
  wechatOp?: (op: string, arg: string | undefined) => void
  /** `/doctor` and `/plugins`. The host runs its own checks and returns the report
   * text; the renderer draws it in an alert. The answer is sent as `command-result`
   * correlated by the **request's** seq. */
  doctor?: (op: 'doctor' | 'plugins') => Promise<string>
  /** The terminal's cell geometry, reported by the renderer at startup and on every resize.
   * The renderer owns the TTY, so it is the only side that can measure the grid; the host
   * keeps the latest value for its own layout decisions (transcript line caps, plugin layout). */
  terminalSize?: (size: { width: number; height: number }) => void
  /** The terminal's color scheme, detected by the renderer from its own glyph colors. The
   * renderer resolves `theme.mode: "system"` locally; the host only keeps the value for its
   * own ANSI output. */
  onTerminalScheme?: (scheme: 'dark' | 'light') => void
  /** Interrupt the exact session's running turn. */
  interrupt?: (request: InterruptPayload) => Promise<void> | void
  /** Called after the handshake answer, once the catalogs and the snapshot are out.
   * The host uses it for state that is loaded asynchronously (the effort list for a
   * route comes from the provider info), which cannot be sent in the ack callback. */
  onAcked?: (send: (kind: string, payload: unknown) => void) => void
  /** Notices the renderer shows in the console overlay. The levels match the host's
   * `appendNotice`, so the mount can pass the host's notifier straight through. */
  notice?: (text: string, level: 'info' | 'warning' | 'error') => void
  /** The settings section the renderer's `/settings` page shows (the host's
   * `settings.describe()` projection). The agent-loop cap is carried separately: its
   * fields are not TUI fields and are written back with `ns` on `update-settings`. */
  settingsSection?: () => { ns: string; schemaVersion: number; values: Record<string, unknown>; agentLoop?: { maxParallelToolCalls?: number } }
  /** The locale and the dictionary the renderer draws its labels from. The renderer
   * runs in a separate process, so the strings travel over IPC; a renderer that
   * paints before `i18n` arrives uses its built-in English labels. */
  i18n?: () => { locale: string; strings: Record<string, string> }
  /** The renderer wrote settings fields; the host puts them through its own
   * settings seam, so the renderer never touches `ctx.settings`. `ns` selects the
   * namespace (`tui` default, `agent-loop` for the harness fields that are not TUI). */
  updateSettings?: (patch: Record<string, unknown>, ns: 'tui' | 'agent-loop') => Promise<void>
  /** The renderer asks the host to run a harness-owned dialog (the provider form
   * and the model flow land in S7). `reply` sends the answer back as
   * `dialog-response` on the sequence the request went out on. */
  dialogRequest?: (kind: string, args: Record<string, unknown> | undefined, reply: (value: unknown) => void) => void
  /** The renderer answers a host-initiated plugin dialog (`extension-dialog`) on the
   * same request id; `value` is the picked option id, `'yes'`/`'no'`, the input text,
   * or `undefined` for cancel. */
  extensionDialogReply?: (requestId: number, value: string | undefined) => void
  /** A normalized key combo the renderer's keymap did not consume; the host matches it
   * against the plugin shortcut registrations and dispatches a hit. */
  shortcut?: (combo: string) => void
  /** The renderer asked to exit (`ctrl+x q`); the host runs its own bounded exit hook
   * after the mount stops, so the launcher's shutdown rules stay in one place. */
  onBye?: () => void
  /** Renderer asked to terminate the core process, not just detach this TUI. */
  onShutdown?: () => void
  /** False while a daemon core has no TUI attached; human prompts fail closed. */
  isRendererAttached?: () => boolean
  /** Read or change the OS launch-at-login entry; returns the verified state. */
  autostartOp?: (enabled: boolean) => Promise<unknown>
  /**
   * The field list for a harness-owned form the renderer draws. The host reads the
   * current draft through its own settings seam and sends the fields down as
   * `form-spec`; the renderer collects the values and sends `form-submit`, which
   * `formSubmit` writes through the same seam. Keeping both halves in the host means
   * the provider id rules, the credential reference, and the settings mutations are
   * not duplicated in the renderer.
   *
   * The read is async (the credential probe is a promise), so the handler resolves
   * the promise and falls back to `dialogRequest` when the form has no spec.
   */
  formSpec?: (form: string, args: Record<string, unknown> | undefined) => Promise<{ title: string; fields: FormFieldSpec[] } | undefined>
  formSubmit?: (form: string, values: Record<string, string>) => Promise<void | string>
  /**
   * The provider form's discovery probe. The renderer has no button primitive, so the
   * probe is an `action` row in the field list: Enter on it sends the form's current
   * values up as `model-discover`, and the host runs its own `ctx.llm.discoverModels`
   * (the discovery namespace lookup and the credential rules stay in the host) and
   * answers with the merged models line as `model-discovery`. Returning `undefined`
   * means the deployment has no probe, which the host reports as a notice.
   */
  modelDiscover?: (form: string, fields: Record<string, string>) => Promise<string | undefined>
  /**
   * The nested per-model editor. The provider form has an `edit-models` action row; Enter
   * sends the form's current values up, the host parses the flat line and answers with the
   * model list (`model-list`). Picking a model sends `model-edit` with the line it came
   * from; the host answers with a `form-spec` for that model (id / name / efforts / effort
   * / context / max), and the model form's submit merges the edited fields back into that
   * line through `model-discovery`. Parsing, encoding, and the merge stay in the host.
   */
  modelListRequest?: (form: string, fields: Record<string, string>) => { models: { id: string; label: string }[] } | undefined
  modelEdit?: (form: string, id: string, models: string) => { title: string; fields: FormFieldSpec[] } | undefined
  /** Push the exact session's running state; the footer spinner reads it. */
  turnState?: (emit: (sessionId: string, running: boolean) => void) => () => void
  /** Release renderer-owned streams on clean exit, crash, or startup failure. */
  onRendererExit?: () => void
  write?: (text: string) => void
  logPath?: string
  /** Streams the log router replaces; defaults to `process`. Tests pass fakes. */
  streams?: RoutedStreams
  /** Spawn implementation, defaulting to the real one. Tests inject a fake child. */
  spawn?: (path: string, args: readonly string[], options: { stdio: readonly string[] }) => ChildProcess
}

export interface RendererMount {
  handle: RendererHandle
  /** Restore the terminal, unsubscribe, and put the original stdout writes back. */
  stop: () => void
  /** Ask the human through the renderer and resolve with answers or cancellation. */
  ask: (questions: readonly QuestionSpec[]) => Promise<QuestionAnswerItem[]>
  askQuestion: (request: QuestionRequestPayload, signal?: AbortSignal) => Promise<readonly QuestionAnswerItem[] | undefined>
  approve: (request: Omit<ApprovalRequestPayload, 'request'>, signal?: AbortSignal) => Promise<'allowed-once' | 'rejected' | 'cancelled' | 'unavailable'>
  /** True only for a question explicitly timed out by the renderer's deadline display. */
  questionTimedOut: (request: string) => boolean
  supports: (kind: string) => boolean
  /** Drop pending human interactions when the TUI disappears without exiting the core. */
  drop: () => void
}

/**
 * Spawn the renderer and wire it to the session.
 *
 * `undefined` is returned when no renderer binary can be found: the host reports
 * the missing artifact instead of spawning a path that does not exist, which would
 * leave the terminal in a half-handed-over state.
 */
export function mountRenderer(deps: RendererMountDeps): RendererMount | undefined {
  const path = deps.rendererPath
  if (path === undefined) {
    const write = deps.write ?? ((text: string) => process.stdout.write(text))
    write('dpsk: no renderer artifact found. Run `dpsk update`, or set DSH_RENDERER_PATH.\n')
    deps.notice?.('no renderer artifact found', 'error')
    return undefined
  }

  // The real TTY write is captured before stdout is routed to the log: the crash restore
  // sequence must reach the terminal, and the routed writer would file it away instead.
  const streams = deps.streams ?? process
  // `streams.stdout.write` is the *routed* writer by the time the restore runs, so the
  // default goes to the terminal's descriptor instead.
  const ttyWrite = deps.write ?? writeTerminal
  const restoreLog = routeStdoutToLog(deps.logPath ?? tuiLogPath(process.pid), (level, text) => {
    send('log', { text, level })
  }, streams)

  // Nothing goes out before the handshake answer. The renderer creates its CLI
  // renderer only after `compatible`, so a snapshot sent earlier would be applied
  // to a store the renderer has not painted yet, and a log line sent earlier would
  // be dropped. Sends made before the ack are held in order and flushed on the ack.
  const pending: Array<{ kind: string; payload: unknown }> = []
  let acked = false
  let unsubscribeWechat: (() => void) | undefined
  let unsubscribeMcp: (() => void) | undefined
  let unsubscribeSubagents: (() => void) | undefined
  let unsubscribeInterjections: (() => void) | undefined
  let unsubscribeShellJobs: (() => void) | undefined
  let unsubscribeUsage: (() => void) | undefined
  let unsubscribeGitBranch: (() => void) | undefined
  let unsubscribeTodos: (() => void) | undefined
  let unsubscribeSkills: (() => void) | undefined
  /**
   * The user-questions requests the renderer has been asked to answer, keyed by the
   * request id the renderer answers with. The host's `user-questions/request` handler
   * blocks until the answer arrives, so the promise is registered here and resolved
   * by the `question-answer` envelope.
   */
  const pendingQuestions = new Map<string, (answers: QuestionAnswerItem[] | undefined) => void>()
  const pendingApprovals = new Map<string, (outcome: 'allowed-once' | 'rejected' | 'cancelled' | 'unavailable') => void>()
  const timedOutQuestions = new Set<string>()
  let questionSeq = 0
  let approvalSeq = 0
  // After `bye` the renderer is on its way out and its channel is closing; anything the
  // host still wants to say (a notice from the exit handler, a queued push) is dropped
  // rather than thrown. `bye` is the renderer's own request, so the channel closing first
  // is the normal order, not an error.
  let closing = false
  let stopped = false
  let cleanupSubscriptions = (): void => undefined
  /** Kinds the renderer said it does not implement; the host never sends them. */
  const skipped = new Set<string>()
  const send = (kind: string, payload: unknown): void => {
    if (closing) return
    if (skipped.has(kind)) return
    if (!acked) {
      pending.push({ kind, payload })
      return
    }
    handle.send(kind, payload)
  }
  const commandResult = (seq: number, operation: () => unknown | Promise<unknown>): void => {
    void Promise.resolve().then(operation).then(
      value => {
        const result: CommandResultPayload = { seq, ok: true, ...(value === undefined ? {} : { value }) }
        send('command-result', result)
      },
      (error: unknown) => {
        const result: CommandResultPayload = { seq, ok: false, error: error instanceof Error ? error.message : String(error) }
        send('command-result', result)
      },
    )
  }
  let rendererExitNotified = false
  const dropPendingInteractions = (): void => {
    for (const resolve of pendingQuestions.values()) resolve(undefined)
    pendingQuestions.clear()
    timedOutQuestions.clear()
    for (const resolve of pendingApprovals.values()) resolve('unavailable')
    pendingApprovals.clear()
  }
  const notifyRendererExit = (): void => {
    if (rendererExitNotified) return
    rendererExitNotified = true
    deps.onRendererExit?.()
  }

  const handle = spawnRenderer(path, {
    allowReattach: deps.allowReattach === true,
    hostView: deps.hostView ?? defaultHostView('my-dpsk-harness-tui', '0.5.0', true),
    write: ttyWrite,
    spawn: deps.spawn,
    onAck: negotiation => {
      if (negotiation.status !== 'compatible' && negotiation.status !== 'compatible_degraded') {
        deps.notice?.(`renderer refused: ${negotiation.reasons.join('; ')}`, 'error')
        return
      }
      // A reattached renderer is a fresh process: clear the previous detach state and
      // replace every renderer-owned subscription before replaying the full snapshot.
      closing = false
      skipped.clear()
      unsubscribeWechat?.()
      unsubscribeMcp?.()
      unsubscribeSubagents?.()
      unsubscribeInterjections?.()
      unsubscribeShellJobs?.()
      unsubscribeUsage?.()
      unsubscribeGitBranch?.()
      unsubscribeTodos?.()
      unsubscribeSkills?.()
      unsubscribeWechat = undefined
      unsubscribeMcp = undefined
      unsubscribeSubagents = undefined
      unsubscribeInterjections = undefined
      unsubscribeShellJobs = undefined
      unsubscribeUsage = undefined
      unsubscribeGitBranch = undefined
      unsubscribeTodos = undefined
      unsubscribeSkills = undefined
      acked = true
      // The negotiation named the kinds this renderer did not list; every host send goes
      // through `send`, so a skipped kind never reaches the wire, including the initial
      // values below.
      for (const kind of negotiation.skippedKinds) skipped.add(kind)
      // The catalogs the renderer's pickers read. They are sent before the snapshot
      // so the palette has entries on the first paint.
      const snapshot = deps.snapshot()
      const sessions = deps.sessions?.()
      if (sessions !== undefined) send('session-list', { sessions: sessions.map(session => ({ ...session })), current: snapshot.sessionId })
      const section = deps.settingsSection?.()
      if (section !== undefined) {
        send('settings', {
          ns: section.ns,
          schemaVersion: section.schemaVersion,
          values: { ...section.values },
          ...(section.agentLoop === undefined ? {} : { agentLoop: { ...section.agentLoop } }),
        })
      }
      const locale = deps.i18n?.()
      if (locale !== undefined) send('i18n', { locale: locale.locale, strings: { ...locale.strings } })
      const mcpServers = deps.mcpServers
      if (mcpServers !== undefined && !skipped.has('mcp-servers')) {
        unsubscribeMcp = mcpServers(servers => send('mcp-servers', { servers: servers.map(item => ({ ...item })) }))
      }
      if (!skipped.has('host-plugins')) {
        const pluginInventory = deps.hostPlugins?.()
        if (pluginInventory !== undefined) void pluginInventory.then(plugins => {
          if (plugins !== undefined) send('host-plugins', { plugins: plugins.map(item => ({ ...item })) })
        }).catch(error => send('boot-notice', { kind: 'warning', text: `Plugin inventory unavailable: ${error instanceof Error ? error.message : String(error)}` }))
      }
      send('session-snapshot', { ...snapshot, events: [...snapshot.events] })
      // The session-scoped catalogs follow the snapshot: the renderer resets its per-session
      // catalogs when a snapshot names a new session, so sending them earlier would erase
      // them and leave the pickers empty on the first frame.
      const effortState = deps.efforts?.()
      if (effortState !== undefined) send('reasoning-efforts', { ...effortState, efforts: [...effortState.efforts] })
      const models = deps.models?.()
      if (models !== undefined) send('model-catalog', { sessionId: snapshot.sessionId, models: models.map(model => ({ ...model })) })
      const commands = deps.commands?.()
      if (commands !== undefined) send('command-catalog', { sessionId: snapshot.sessionId, commands: commands.map(command => ({ ...command })) })
      // The WeChat bridge replays its buffered output, so it subscribes only after the
      // initial snapshot. Session projections retain the exact session id they describe.
      const subscribe = <T>(kind: string, source: ((emit: (value: T) => void) => () => void) | undefined, emit: (value: T) => void): (() => void) | undefined =>
        skipped.has(kind) ? undefined : source?.(emit)
      unsubscribeWechat = subscribe('wechat-output', deps.wechatOutput, message => send('wechat-output', message))
      unsubscribeSubagents = skipped.has('subagent-list') ? undefined : deps.subagents?.((sessionId, agents) => send('subagent-list', { sessionId, agents: agents.map(agent => ({ ...agent })) }))
      unsubscribeSkills = skipped.has('skills-list') ? undefined : deps.skills?.((sessionId, skills) => send('skills-list', { sessionId, skills: skills.map(skill => ({ ...skill })) }))
      unsubscribeUsage = subscribe('usage', deps.usage, usage => send('usage', { ...usage }))
      unsubscribeGitBranch = skipped.has('git-branch') ? undefined : deps.gitBranch?.((sessionId, branch) => send('git-branch', { sessionId, branch }))
      // MCP and plugin inventories are global one-shot snapshots; they are refreshed on a
      // subsequent mount rather than pretending Loader lifecycle is a client-side stream.
      unsubscribeShellJobs = skipped.has('shell-jobs') ? undefined : deps.shellJobs?.((sessionId, jobs) => send('shell-jobs', { sessionId, jobs: jobs.map(job => ({ ...job, output: { ...job.output, ...(job.output.spillPaths === undefined ? {} : { spillPaths: [...job.output.spillPaths] }) } })) }))
      unsubscribeInterjections = skipped.has('interject-list') ? undefined : deps.interjections?.((sessionId, items) => send('interject-list', { sessionId, items: items.map(item => ({ ...item })) }))
      unsubscribeTodos = skipped.has('todos') ? undefined : deps.todos?.((sessionId, items) => send('todos', { sessionId, items: items.map(item => ({ ...item })) }))
      for (const envelope of pending) if (!skipped.has(envelope.kind)) handle.send(envelope.kind, envelope.payload)
      pending.length = 0
      deps.onAcked?.(send)
    },
    onEnvelope: envelope => {
      const payload = typeof envelope.payload === 'object' && envelope.payload !== null ? (envelope.payload as Record<string, unknown>) : {}
      switch (envelope.kind) {
        case 'send-message': {
          const request = payload as Partial<SendMessagePayload>
          const allowed = ['sessionId', 'text', 'delivery', 'attachments', 'skills']
          const validAttachment = (value: unknown): boolean => {
            if (typeof value !== 'object' || value === null || Array.isArray(value)) return false
            const attachment = value as Record<string, unknown>
            if (Object.keys(attachment).some(key => !['type', 'mediaType', 'data', 'name'].includes(key))
              || typeof attachment.data !== 'string'
              || Buffer.byteLength(attachment.data, 'base64') > 20 * 1024 * 1024
              || ('name' in attachment && attachment.name !== undefined && typeof attachment.name !== 'string')) return false
            if (attachment.type === 'file') return !('mediaType' in attachment)
            return attachment.type === 'image'
              && ['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(String(attachment.mediaType))
          }
          const attachments = request.attachments
          const skills = request.skills
          const invalid = Object.keys(payload).some(key => !allowed.includes(key))
            || typeof request.sessionId !== 'string' || request.sessionId.trim() === ''
            || typeof request.text !== 'string'
            || (request.delivery !== 'steer' && request.delivery !== 'queue')
            || (attachments !== undefined && (!Array.isArray(attachments) || !attachments.every(validAttachment)))
            || (skills !== undefined && (!Array.isArray(skills) || !skills.every(skill => typeof skill === 'string' && skill !== '')))
            || (request.text.trim() === '' && (attachments?.length ?? 0) === 0 && (skills?.length ?? 0) === 0)
          if (invalid) {
            commandResult(envelope.seq, () => { throw new Error('invalid send-message payload') })
            return
          }
          commandResult(envelope.seq, () => deps.submit(request as SendMessagePayload))
          return
        }
        case 'interrupt': {
          const request = payload as Partial<InterruptPayload>
          if (typeof request.sessionId !== 'string' || request.sessionId.trim() === '' || Object.keys(payload).some(key => key !== 'sessionId')) {
            commandResult(envelope.seq, () => { throw new Error('interrupt requires only a non-empty sessionId') })
            return
          }
          if (deps.interrupt === undefined) {
            commandResult(envelope.seq, () => { throw new Error('interrupt is not available in this deployment') })
            return
          }
          commandResult(envelope.seq, () => deps.interrupt!(request as InterruptPayload))
          return
        }
        case 'set-selection': {
          const selection = payload as Partial<SelectionPayload>
          const keys = ['sessionId', 'provider', 'model', 'effort', 'permission', 'preset'] as const
          if (Object.keys(payload).some(key => !keys.includes(key as typeof keys[number]))
            || typeof selection.sessionId !== 'string' || selection.sessionId.trim() === '') {
            commandResult(envelope.seq, () => { throw new Error('set-selection requires a non-empty sessionId and known fields') })
            return
          }
          const hasProvider = typeof selection.provider === 'string' && selection.provider !== ''
          const hasModel = typeof selection.model === 'string' && selection.model !== ''
          const hasEffort = typeof selection.effort === 'string' && selection.effort !== ''
          const hasPermission = typeof selection.permission === 'string' && selection.permission !== ''
          const hasPreset = typeof selection.preset === 'string' && selection.preset !== ''
          const groupCount = Number(hasProvider || hasModel) + Number(hasEffort) + Number(hasPermission) + Number(hasPreset)
          if (hasProvider !== hasModel || groupCount !== 1
            || (selection.provider !== undefined && !hasProvider)
            || (selection.model !== undefined && !hasModel)
            || (selection.effort !== undefined && !hasEffort)
            || (selection.permission !== undefined && !hasPermission)
            || (selection.preset !== undefined && !hasPreset)) {
            commandResult(envelope.seq, () => { throw new Error('set-selection requires one complete selection value') })
            return
          }
          if (deps.setSelection === undefined) {
            commandResult(envelope.seq, () => { throw new Error('selection is not available in this deployment') })
            return
          }
          commandResult(envelope.seq, async () => {
            await deps.setSelection!(selection as SelectionPayload)
            deps.onSelectionApplied?.()
          })
          return
        }
        case 'session-op': {
          const rejectRequest = (message: string): void => commandResult(envelope.seq, () => { throw new Error(message) })
          const op = payload.op
          if (op !== 'new' && op !== 'switch' && op !== 'rename' && op !== 'fork' && op !== 'read') {
            rejectRequest('invalid session operation')
            return
          }
          const allowed = op === 'new'
            ? new Set(['op', 'sessionId', 'cwd', 'selection'])
            : op === 'rename'
              ? new Set(['op', 'sessionId', 'title'])
              : op === 'fork'
                ? new Set(['op', 'sessionId', 'boundary'])
                : new Set(['op', 'sessionId'])
          if (Object.keys(payload).some(key => !allowed.has(key))) {
            rejectRequest(`unexpected field for session ${op}`)
            return
          }
          const sessionId = payload.sessionId
          if (sessionId !== undefined && (typeof sessionId !== 'string' || sessionId.trim() === '')) {
            rejectRequest('sessionId must be a non-empty string')
            return
          }
          if (op !== 'new' && typeof sessionId !== 'string') {
            rejectRequest(`session ${op} requires sessionId`)
            return
          }
          if (op === 'rename' && typeof payload.title !== 'string') {
            rejectRequest('session rename requires title')
            return
          }
          if (op === 'fork' && (typeof payload.boundary !== 'number' || !Number.isSafeInteger(payload.boundary) || payload.boundary < 0)) {
            rejectRequest('session fork requires a non-negative event boundary')
            return
          }
          if (op === 'new' && payload.cwd !== undefined && typeof payload.cwd !== 'string') {
            rejectRequest('session cwd must be a string')
            return
          }
          if (op === 'new' && payload.selection !== undefined) {
            const selection = payload.selection
            if (typeof selection !== 'object' || selection === null || Array.isArray(selection)) {
              rejectRequest('session selection must be an object')
              return
            }
            const selectionKeys = ['provider', 'model', 'effort', 'preset', 'permission']
            if (Object.keys(selection).some(key => !selectionKeys.includes(key))
              || !('provider' in selection) || typeof selection.provider !== 'string' || selection.provider === ''
              || !('model' in selection) || typeof selection.model !== 'string' || selection.model === ''
              || !('preset' in selection) || typeof selection.preset !== 'string' || selection.preset === '') {
              rejectRequest('session selection requires provider, model, and preset')
              return
            }
            if (('effort' in selection && selection.effort !== undefined && typeof selection.effort !== 'string')
              || ('permission' in selection && selection.permission !== undefined && typeof selection.permission !== 'string')) {
              rejectRequest('session selection effort and permission must be strings')
              return
            }
          }
          if (deps.sessionOp === undefined) {
            rejectRequest('session operations are not available in this deployment')
            return
          }
          commandResult(envelope.seq, () => deps.sessionOp!(payload as unknown as SessionOpPayload))
          return
        }
        case 'update-settings': {
          // The renderer keeps a promise per request: the host answers the same `requestId`
          // with the settings as they are after the write, or with the real write error.
          const requestId = typeof payload.requestId === 'string' ? payload.requestId : ''
          const patch = typeof payload.patch === 'object' && payload.patch !== null ? (payload.patch as Record<string, unknown>) : undefined
          const ns = payload.ns === 'agent-loop' ? 'agent-loop' : 'tui'
          const answer = (error?: string): void => {
            const section = deps.settingsSection?.()
            if (section === undefined) {
              send('settings', { ns: ns === 'agent-loop' ? '' : 'tui', schemaVersion: 0, values: {}, ...(error === undefined ? {} : { error }) })
              return
            }
            send('settings', {
              ns: section.ns,
              schemaVersion: section.schemaVersion,
              values: { ...section.values },
              ...(section.agentLoop === undefined ? {} : { agentLoop: { ...section.agentLoop } }),
              requestId,
              ...(error === undefined ? {} : { error }),
            })
          }
          if (requestId === '') return
          if (patch === undefined || Object.keys(patch).length === 0) {
            answer('nothing to write')
            return
          }
          if (deps.updateSettings === undefined) {
            answer('settings are not available in this deployment')
            return
          }
          deps.updateSettings(patch, ns).then(
            () => answer(),
            (error: unknown) => answer(error instanceof Error ? error.message : String(error)),
          )
          return
        }
        case 'interject-edit': {
          const request = payload as Partial<InterjectEditPayload>
          if (Object.keys(payload).some(key => key !== 'sessionId' && key !== 'id')
            || typeof request.sessionId !== 'string' || request.sessionId.trim() === ''
            || (request.id !== undefined && (typeof request.id !== 'string' || request.id === ''))) {
            commandResult(envelope.seq, () => { throw new Error('interject-edit requires a sessionId and optional message id') })
            return
          }
          if (deps.editInterjection === undefined) {
            commandResult(envelope.seq, () => { throw new Error('interjection editing is not available in this deployment') })
            return
          }
          commandResult(envelope.seq, () => deps.editInterjection!(request as InterjectEditPayload))
          return
        }
        case 'interject-delete': {
          const request = payload as Partial<InterjectDeletePayload>
          if (Object.keys(payload).some(key => key !== 'sessionId' && key !== 'id')
            || typeof request.sessionId !== 'string' || request.sessionId.trim() === ''
            || typeof request.id !== 'string' || request.id === '') {
            commandResult(envelope.seq, () => { throw new Error('interject-delete requires a sessionId and message id') })
            return
          }
          if (deps.deleteInterjection === undefined) {
            commandResult(envelope.seq, () => { throw new Error('interjection deletion is not available in this deployment') })
            return
          }
          commandResult(envelope.seq, () => deps.deleteInterjection!(request as InterjectDeletePayload))
          return
        }
        case 'question-timeout': {
          const request = payload as Partial<QuestionTimeoutPayload>
          const id = typeof request.request === 'string' ? request.request : ''
          if (id === '' || Object.keys(payload).some(key => key !== 'request')) return
          const resolve = pendingQuestions.get(id)
          if (resolve === undefined) return
          timedOutQuestions.add(id)
          pendingQuestions.delete(id)
          resolve(undefined)
          return
        }
        case 'shell-job-op': {
          const request = payload as Partial<ShellJobOpPayload>
          if (Object.keys(payload).some(key => !['sessionId', 'id', 'op', 'from'].includes(key))
            || typeof request.sessionId !== 'string' || request.sessionId.trim() === ''
            || typeof request.id !== 'string' || request.id === ''
            || (request.op !== 'read' && request.op !== 'kill')
            || (request.from !== undefined && (!Number.isSafeInteger(request.from) || request.from < 0))) {
            commandResult(envelope.seq, () => { throw new Error('shell-job-op requires a sessionId, job id, and valid operation') })
            return
          }
          if (deps.shellJobOp === undefined) {
            commandResult(envelope.seq, () => { throw new Error('shell jobs are not available in this deployment') })
            return
          }
          commandResult(envelope.seq, () => deps.shellJobOp!(request as ShellJobOpPayload))
          return
        }
        case 'terminal-op': {
          const request = payload
          const operation = typeof request.op === 'string' ? request.op : undefined
          const keys = operation === 'list' ? ['sessionId', 'op']
            : operation === 'create' ? ['sessionId', 'op', 'id', 'cols', 'rows', 'shellPath']
              : operation === 'retain' || operation === 'release' || operation === 'follow' || operation === 'detach' ? ['sessionId', 'op', 'id', 'attachmentId']
                : operation === 'write' ? ['sessionId', 'op', 'id', 'attachmentId', 'data']
                  : operation === 'resize' ? ['sessionId', 'op', 'id', 'attachmentId', 'cols', 'rows']
                    : operation === 'close' ? ['sessionId', 'op', 'id'] : []
          const dimensionsValid = (value: unknown): boolean => typeof value === 'number' && Number.isSafeInteger(value) && value > 0
          const hasId = operation === 'list' || (typeof request.id === 'string' && request.id !== '')
          const hasAttachment = !['retain', 'release', 'follow', 'detach', 'write', 'resize'].includes(String(operation))
            || (typeof request.attachmentId === 'string' && request.attachmentId !== '')
          const hasDimensions = operation !== 'create' && operation !== 'resize'
            || (dimensionsValid(request.cols) && dimensionsValid(request.rows))
          const valid = keys.length > 0
            && Object.keys(payload).every(key => keys.includes(key))
            && typeof request.sessionId === 'string' && request.sessionId.trim() !== ''
            && hasId && hasAttachment && hasDimensions
            && (operation !== 'create' || (request.shellPath === undefined || typeof request.shellPath === 'string'))
            && (operation !== 'write' || typeof request.data === 'string')
          if (!valid) {
            commandResult(envelope.seq, () => { throw new Error('terminal-op requires a valid session, operation, and operation-specific fields') })
            return
          }
          if (deps.terminalOp === undefined) {
            commandResult(envelope.seq, () => { throw new Error('interactive terminals are not available in this deployment') })
            return
          }
          commandResult(envelope.seq, () => deps.terminalOp!(request as unknown as TerminalOpPayload, (kind, event) => send(kind, event)))
          return
        }
        case 'attachment-read': {
          const request = payload as Partial<AttachmentReadPayload>
          if (Object.keys(payload).some(key => key !== 'sessionId' && key !== 'attachment')
            || typeof request.sessionId !== 'string' || request.sessionId.trim() === ''
            || typeof request.attachment !== 'object' || request.attachment === null || Array.isArray(request.attachment)) {
            commandResult(envelope.seq, () => { throw new Error('attachment-read requires a sessionId and reference object') })
            return
          }
          if (deps.readAttachment === undefined) {
            commandResult(envelope.seq, () => { throw new Error('attachment reading is not available in this deployment') })
            return
          }
          commandResult(envelope.seq, () => deps.readAttachment!(request as AttachmentReadPayload))
          return
        }
        case 'wechat-op': {
          // The bridge owns the login state machine and the account list; the
          // renderer only asks for a command and renders what the bridge pushes.
          const op = typeof payload.op === 'string' ? payload.op : ''
          const arg = typeof payload.arg === 'string' ? payload.arg : undefined
          if (op !== '') deps.wechatOp?.(op, arg)
          return
        }
        case 'doctor-check': {
          // The report text comes back correlated by the request's seq, so the
          // renderer's alert shows the answer to its own request, not a later one.
          const op = payload.op === 'plugins' ? 'plugins' : 'doctor'
          const report = deps.doctor?.(op)
          if (report === undefined) return
          void report
            .then(text => send('command-result', { seq: envelope.seq, ok: true, text }))
            .catch(error => send('command-result', { seq: envelope.seq, ok: false, error: error instanceof Error ? error.message : String(error) }))
          return
        }
        case 'dialog-request': {
          // The renderer owns the dialog UI, so a harness-owned form (provider
          // edit, custom model) is requested here. When the host has a field list
          // for the form, the spec goes down as `form-spec` and the renderer draws
          // it; the answer comes back as `form-submit`. A form the host has no spec
          // for falls through to `dialogRequest`, which is the host-run path.
          const kind = typeof payload.kind === 'string' ? payload.kind : ''
          if (kind === '') return
          const args = typeof payload.args === 'object' && payload.args !== null ? (payload.args as Record<string, unknown>) : undefined
          const spec = deps.formSpec?.(kind, args)
          if (spec === undefined) {
            if (deps.dialogRequest !== undefined) deps.dialogRequest(kind, args, value => send('dialog-response', { seq: envelope.seq, value }))
            return
          }
          // The draft read is async (the credential probe), so the fallback to the
          // host-run path happens after the promise resolves.
          void Promise.resolve(spec).then(resolved => {
            if (resolved === undefined) {
              if (deps.dialogRequest !== undefined) deps.dialogRequest(kind, args, value => send('dialog-response', { seq: envelope.seq, value }))
              return
            }
            send('form-spec', { form: kind, title: resolved.title, fields: [...resolved.fields] })
          })
          return
        }
        case 'extension-dialog-response': {
          // The renderer's answer to a plugin dialog the host sent down.
          const requestId = typeof payload.requestId === 'number' ? payload.requestId : -1
          const value = typeof payload.value === 'string' ? payload.value : undefined
          if (requestId >= 0) deps.extensionDialogReply?.(requestId, value)
          return
        }
        case 'shortcut': {
          const combo = typeof payload.combo === 'string' ? payload.combo : ''
          if (combo !== '') deps.shortcut?.(combo)
          return
        }
        case 'form-submit': {
          // The renderer's form values go back through the host's seam. The report
          // the host prints (notice / transcript) is the renderer's feedback; the
          // write itself is not acknowledged, matching `send-message`.
          const form = typeof payload.form === 'string' ? payload.form : ''
          const values = typeof payload.values === 'object' && payload.values !== null ? (payload.values as Record<string, string>) : {}
          if (form === '') return
          void Promise.resolve(deps.formSubmit?.(form, values)).then(line => {
            // A nested per-model edit returns the merged line; it goes back down as
            // `model-discovery` so the provider form's models field updates.
            if (typeof line === 'string') send('model-discovery', { form: 'provider', models: line })
          }).catch(error => {
            const message = error instanceof Error ? error.message : String(error)
            send('boot-notice', { text: message, kind: 'error' })
          })
          return
        }
        case 'model-discover': {
          // The provider form's action row. The host runs its own probe with the values
          // the renderer has on screen and answers with the merged line, so the encoding
          // rules and the namespace lookup stay in the host. A deployment without the
          // probe answers nothing; the host reports it as a notice.
          const form = typeof payload.form === 'string' ? payload.form : ''
          const fields = typeof payload.fields === 'object' && payload.fields !== null ? (payload.fields as Record<string, string>) : {}
          if (form === '' || deps.modelDiscover === undefined) return
          void deps.modelDiscover(form, fields).then(line => {
            if (line === undefined) return
            send('model-discovery', { form, models: line })
          }).catch(error => {
            const message = error instanceof Error ? error.message : String(error)
            send('boot-notice', { text: message, kind: 'error' })
          })
          return
        }
        case 'model-list-request': {
          // The provider form's `edit-models` row. The host parses the flat line and sends
          // the model list down; the renderer opens its own select over it.
          const form = typeof payload.form === 'string' ? payload.form : ''
          const fields = typeof payload.fields === 'object' && payload.fields !== null ? (payload.fields as Record<string, string>) : {}
          if (form === '' || deps.modelListRequest === undefined) return
          const resolved = deps.modelListRequest(form, fields)
          if (resolved === undefined) return
          send('model-list', { form, models: resolved.models.map(model => ({ ...model })) })
          return
        }
        case 'model-edit': {
          // The model picked in the list, plus the line it came from. The host answers with
          // a form for that model; the model form's submit merges into this line.
          const form = typeof payload.form === 'string' ? payload.form : ''
          const id = typeof payload.id === 'string' ? payload.id : ''
          const models = typeof payload.models === 'string' ? payload.models : ''
          if (form === '' || id === '' || deps.modelEdit === undefined) return
          const resolved = deps.modelEdit(form, id, models)
          if (resolved === undefined) return
          send('form-spec', { form: 'model', title: resolved.title, fields: [...resolved.fields] })
          return
        }
        case 'terminal-scheme': {
          deps.onTerminalScheme?.((payload.scheme === 'light' ? 'light' : 'dark'))
          return
        }
        case 'terminal-size': {
          // The renderer owns the TTY, so its measurement is the grid the host uses.
          const width = Number(payload.width)
          const height = Number(payload.height)
          if (width > 0 && height > 0) deps.terminalSize?.({ width, height })
          return
        }
        case 'question-answer': {
          const request = typeof payload.request === 'string' ? payload.request : ''
          const resolve = pendingQuestions.get(request)
          if (resolve === undefined) return
          pendingQuestions.delete(request)
          resolve(payload.cancelled === true ? undefined : Array.isArray(payload.answers) ? payload.answers as QuestionAnswerItem[] : [])
          send('question-result', { request, ok: true })
          return
        }
        case 'approval-answer': {
          const request = typeof payload.request === 'string' ? payload.request : ''
          const resolve = pendingApprovals.get(request)
          if (resolve === undefined) return
          pendingApprovals.delete(request)
          const outcome = payload.outcome === 'allowed-once' || payload.outcome === 'rejected' ? payload.outcome : 'unavailable'
          resolve(outcome)
          return
        }
        case 'approval-close': {
          const request = typeof payload.request === 'string' ? payload.request : ''
          const resolve = pendingApprovals.get(request)
          if (resolve === undefined) return
          pendingApprovals.delete(request)
          resolve('rejected')
          return
        }
        case 'question-close': {
          const request = typeof payload.request === 'string' ? payload.request : ''
          const resolve = pendingQuestions.get(request)
          if (resolve === undefined) return
          pendingQuestions.delete(request)
          resolve(undefined)
          return
        }
        case 'autostart-op': {
          const request = payload as { enabled?: unknown }
          if (Object.keys(payload).length !== 1 || Object.keys(payload)[0] !== 'enabled' || typeof request.enabled !== 'boolean') {
            commandResult(envelope.seq, () => { throw new Error('autostart-op requires one boolean enabled field') })
            return
          }
          if (deps.autostartOp === undefined) {
            commandResult(envelope.seq, () => { throw new Error('autostart is not available in this deployment') })
            return
          }
          commandResult(envelope.seq, () => deps.autostartOp!(request.enabled as boolean))
          return
        }
        case 'shutdown': {
          const request = payload as { reason?: string }
          if (!['reason'].includes(Object.keys(payload)[0] ?? 'reason') || Object.keys(payload).length > 1
            || (request.reason !== undefined && typeof request.reason !== 'string')) {
            commandResult(envelope.seq, () => { throw new Error('shutdown accepts only an optional reason') })
            return
          }
          commandResult(envelope.seq, () => {
            deps.onShutdown?.()
            return null
          })
          return
        }
        case 'bye': {
          if (deps.detachOnBye === true) {
            closing = true
            pending.length = 0
            dropPendingInteractions()
            deps.onBye?.()
            return
          }
          // The renderer asks once; a repeated `bye` on a mount that already stopped is
          // not a second session end.
          const alreadyStopped = stopped
          closing = true
          pending.length = 0
          stop()
          if (!alreadyStopped) {
            // The renderer restores the terminal itself right after this; a child that never
            // exits would keep the TTY, so a late kill is armed but never holds the loop.
            const watchdog = setTimeout(() => handle.stop(), deps.byeGraceMs ?? 2000)
            watchdog.unref?.()
            deps.onBye?.()
          }
          return
        }
        default:
          return
      }
    },
    onExit: (code, signal, abnormal) => {
      closing = true
      if (stopped) return
      stopped = true
      for (const resolve of pendingQuestions.values()) resolve(undefined)
      pendingQuestions.clear()
      timedOutQuestions.clear()
      for (const resolve of pendingApprovals.values()) resolve('unavailable')
      pendingApprovals.clear()
      cleanupSubscriptions()
      notifyRendererExit()
      restoreLog()
      if (abnormal) deps.notice?.(`renderer exited abnormally (code ${code ?? 'null'}, signal ${signal ?? 'null'})`, 'error')
    },
  })

  const emit = (sessionId: string, events: readonly TranscriptEvent[]): void => {
    send('session-frame', { sessionId, events: [...events] })
  }
  const unsubscribe = deps.subscribe(emit)
  const unsubscribeTurn = deps.turnState?.((sessionId, running) => send('turn-state', { sessionId, running }))
  cleanupSubscriptions = () => {
    unsubscribe()
    if (unsubscribeTurn !== undefined) unsubscribeTurn()
    if (unsubscribeWechat !== undefined) unsubscribeWechat()
    if (unsubscribeMcp !== undefined) unsubscribeMcp()
    if (unsubscribeSubagents !== undefined) unsubscribeSubagents()
    if (unsubscribeSkills !== undefined) unsubscribeSkills()
    if (unsubscribeUsage !== undefined) unsubscribeUsage()
    if (unsubscribeGitBranch !== undefined) unsubscribeGitBranch()
    if (unsubscribeTodos !== undefined) unsubscribeTodos()
    if (unsubscribeShellJobs !== undefined) unsubscribeShellJobs()
    if (unsubscribeInterjections !== undefined) unsubscribeInterjections()
  }
  const stop = (): void => {
    if (stopped) return
    stopped = true
    // A mount the renderer itself asked to leave (`bye`) is not killed: the renderer is
    // writing its own restore and the child's exit lands in `onExit`. Killing it there
    // truncated the sequence, which is how a quit left the terminal in mouse-tracking mode
    // and the shell echoing `[555;109;10M` on every mouse move.
    const graceful = closing
    closing = true
    for (const resolve of pendingQuestions.values()) resolve(undefined)
    pendingQuestions.clear()
    timedOutQuestions.clear()
    for (const resolve of pendingApprovals.values()) resolve('unavailable')
    pendingApprovals.clear()
    notifyRendererExit()
    cleanupSubscriptions()
    if (graceful) {
      // Belt and braces: the host still puts the terminal back, but does not kill the child
      // mid-write. The routing stays on so the plugins' own shutdown lines land in the log
      // instead of on the prompt the user just got back.
      handle.restore()
      return
    }
    handle.stop()
    restoreLog()
  }

  const questionPayload = (request: string, questions: readonly QuestionSpec[], state: 'open' | 'continued', callId?: string, remainingMs?: number): QuestionRequestPayload => ({
    request,
    sessionId: deps.snapshot().sessionId,
    state,
    ...(callId === undefined ? {} : { callId }),
    ...(remainingMs === undefined ? {} : { remainingMs }),
    questions: questions.map(q => ({
      id: q.id,
      question: q.question,
      ...(q.header === undefined ? {} : { header: q.header }),
      ...(q.detail === undefined ? {} : { detail: q.detail }),
      ...(q.multiSelect === undefined ? {} : { multiSelect: q.multiSelect }),
      ...(q.intent === undefined ? {} : { intent: q.intent }),
      ...(q.options === undefined ? {} : { options: q.options.map(o => ({ label: o.label, ...(o.description === undefined ? {} : { description: o.description }) })) }),
    })),
  })

  const ask = (questions: readonly QuestionSpec[]): Promise<QuestionAnswerItem[]> => {
    questionSeq += 1
    const request = `q${questionSeq}`
    if (skipped.has('question-request')) return Promise.resolve([])
    return new Promise(resolve => {
      pendingQuestions.set(request, answers => resolve(answers ?? []))
      send('question-request', questionPayload(request, questions, 'open'))
    })
  }

  const askQuestion = (request: QuestionRequestPayload, signal?: AbortSignal): Promise<readonly QuestionAnswerItem[] | undefined> => {
    if (deps.isRendererAttached?.() === false) return Promise.resolve(undefined)
    if (skipped.has('question-request') || signal?.aborted) return Promise.resolve(undefined)
    return new Promise(resolve => {
      const finish = (answers: QuestionAnswerItem[] | undefined): void => {
        signal?.removeEventListener('abort', abort)
        pendingQuestions.delete(request.request)
        resolve(answers)
      }
      const abort = (): void => {
        if (!pendingQuestions.has(request.request)) return
        pendingQuestions.delete(request.request)
        send('question-close', { request: request.request })
        finish(undefined)
      }
      pendingQuestions.set(request.request, finish)
      signal?.addEventListener('abort', abort, { once: true })
      send('question-request', request)
    })
  }

  const approve = (request: Omit<ApprovalRequestPayload, 'request'>, signal?: AbortSignal): Promise<'allowed-once' | 'rejected' | 'cancelled' | 'unavailable'> => {
    if (deps.isRendererAttached?.() === false) return Promise.resolve('unavailable')
    approvalSeq += 1
    const id = `a${approvalSeq}`
    if (skipped.has('approval-request')) return Promise.resolve('unavailable')
    if (signal?.aborted) return Promise.resolve('cancelled')
    return new Promise(resolve => {
      const finish = (outcome: 'allowed-once' | 'rejected' | 'cancelled' | 'unavailable'): void => {
        signal?.removeEventListener('abort', abort)
        pendingApprovals.delete(id)
        resolve(outcome)
      }
      const abort = (): void => {
        if (!pendingApprovals.has(id)) return
        send('approval-close', { request: id })
        finish('cancelled')
      }
      pendingApprovals.set(id, finish)
      signal?.addEventListener('abort', abort, { once: true })
      send('approval-request', { request: id, ...request })
    })
  }

  return { handle, stop, ask, askQuestion, approve, questionTimedOut: request => timedOutQuestions.delete(request), supports: kind => !skipped.has(kind), drop: dropPendingInteractions }
}

export { transcriptEvents }
