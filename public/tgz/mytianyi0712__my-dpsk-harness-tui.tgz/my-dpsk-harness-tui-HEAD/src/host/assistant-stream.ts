/** One in-flight assistant stream row, before the durable message replaces it. */
export interface AssistantStreamRow {
  id: string
  text: string
  reasoning: string
  reasoningDone?: boolean
  createdAt: number
  bodyAt?: number
}

/**
 * Append a text delta. `bodyAt` is the first answer character's timestamp: the compact
 * thought header uses it as the end of thinking even while the answer is still streaming.
 * A row that already streamed reasoning must acquire `bodyAt` on this transition; otherwise
 * the header falls back to `createdAt`, sees a zero duration, and stays a bare `Thought`
 * until the durable assistant message arrives.
 */
export function appendAssistantTextDelta(
  row: AssistantStreamRow | undefined,
  id: string,
  text: string,
  now: number,
): AssistantStreamRow {
  if (row === undefined) {
    return { id, text, reasoning: '', createdAt: now, bodyAt: now }
  }
  return {
    ...row,
    text: row.text + text,
    ...(row.reasoning === '' ? {} : { reasoningDone: true }),
    bodyAt: row.bodyAt ?? now,
  }
}
