declare module 'js-yaml' {
  /** Parse one YAML document into plain JS values; throws on malformed input. */
  export function load(text: string, options?: { schema?: unknown }): unknown
  /** Serialize a value to a YAML document string. */
  export function dump(value: unknown): string

  /** A YAML tag definition. `kind` is the node shape the tag applies to. */
  export class Type {
    constructor(tag: string, options: { kind: 'scalar' | 'sequence' | 'mapping', construct: (data: never) => unknown })
  }

  /** The core schema (YAML 1.2 core tags). `extend` returns a new schema. */
  export const CORE_SCHEMA: { extend(types: readonly Type[]): unknown }
}
