/** Startup route resolution: program config remembers the last TUI selection, while a
 * historical session's own request header remains the authoritative route for that session. */
import { ReasoningEffortId } from './dsh-host/index.ts'
import type { EpochHeader, ModelSelection } from './dsh-host/index.ts'
import { resolveSessionModelSelection } from './components/status.ts'
import type { SavedSelection } from './host/program-config.ts'

export interface StartupRouteOptions {
  readonly provider?: string
  readonly model?: string
}

export function startupModelSelection(
  header: EpochHeader | undefined,
  saved: SavedSelection | undefined,
  options: StartupRouteOptions,
  configured: ModelSelection,
  defaultReasoningEffort: string,
): ModelSelection {
  const fallback: ModelSelection = {
    provider: saved?.provider ?? options.provider ?? configured.provider,
    model: saved?.model ?? options.model ?? configured.model,
    reasoningEffort: ReasoningEffortId(saved?.effort ?? configured.reasoningEffort ?? defaultReasoningEffort),
  }
  return resolveSessionModelSelection(header, fallback, defaultReasoningEffort)
}
