/**
 * Framework seams: cordis + schemastery.
 */

export { Service, type Context } from '@deepseek-ai/cordis'
export { scopeOf, type ScopeKey } from '@deepseek-ai/dsh-scope'
export { default as z } from '@deepseek-ai/schemastery'
