/**
 * Workspace-registry seam.
 *
 * dsh groups sessions into durable Workspace records served by
 * `ctx.workspaceRegistry`. That service ships with the *web* layers only:
 * `dsh-base` installs the KV/storage stack and leaves "workspace in web layers"
 * (see its storage row comment), so a terminal profile has no grouping service
 * at all. Its sessions are therefore persisted with a `cwd` but never entered
 * into any workspace account, and the desktop client — which buckets every
 * session the registry does not account for into the ungrouped bucket — shows
 * them as ungrouped.
 *
 * This seam exposes the parts of the registry contract the terminal profile
 * needs and loads the plugin on demand. Mounting is deliberately optional: a
 * profile that hosts the registry already (web, desktop) is used as-is, and a
 * profile whose install predates `@deepseek-ai/dsh-workspace` simply keeps the
 * previous ungrouped behavior instead of failing to load.
 */

import type { SessionId } from '@deepseek-ai/dsh-session'
import type { Workspace, WorkspaceId, WorkspaceRegistry } from '@deepseek-ai/dsh-workspace'

export type { Workspace, WorkspaceId, WorkspaceRegistry }

/** The plugin class shape `ctx.plugin()` accepts for the registry row. */
export type WorkspaceRegistryPlugin = typeof WorkspaceRegistry

/**
 * Load the workspace-registry plugin class.
 *
 * The specifier is a literal so the bundler keeps it external (harness packages
 * resolve through the profile at runtime) and `tsc` still checks the shape; the
 * package is a devDependency for types only and an optional runtime peer, so
 * callers must treat a rejection as "grouping unavailable", not as a bug.
 */
export async function loadWorkspaceRegistry(): Promise<WorkspaceRegistryPlugin> {
  const module = await import('@deepseek-ai/dsh-workspace')
  return module.WorkspaceRegistry
}

/**
 * The subset of a Workspace entity grouping needs.
 *
 * Structural on purpose: the terminal profile links the registry implementation
 * through the profile (not through this package's dependency tree), so the code
 * depends on the entity contract it actually calls and stays testable with a
 * plain fake.
 */
export interface GroupingWorkspace {
  /** Canonical directory path the workspace owns. */
  readonly path: string
  /** Header-validated sessions in display order, newest first. */
  readonly sessionIds: readonly SessionId[]
  /** Prepend a session to this workspace's durable account. */
  attachSession(sessionId: SessionId): Promise<void>
}

/** The subset of `ctx.workspaceRegistry` grouping needs. */
export interface GroupingRegistry {
  /** Session ids hidden from every grouping surface. */
  readonly archivedSessionIds?: readonly SessionId[]
  /** Resolve the workspace owning a canonical directory path, if any. */
  resolveByPath(path: string): Promise<GroupingWorkspace | undefined>
  /** Register an existing directory as a workspace. */
  create(path: string): Promise<GroupingWorkspace>
}
