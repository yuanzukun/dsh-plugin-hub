/**
 * Session-title LLM compatibility seam.
 *
 * dsh 0.2.0 exports `generateSessionTitleWithLlm()` and owns prompt framing,
 * reasoning selection, and output parsing. dsh 0.2.1-rc.1+ exports
 * `executeSessionTitleLlm()` instead and moves those provider responsibilities
 * into the plugin. A static named import of either symbol makes the shared host
 * chunk fail to instantiate on the other line, so this module loads the package
 * namespace and selects the available API at runtime.
 */

import type { Context } from './framework.ts'
import { z } from './framework.ts'
import type { SessionSeq } from './session.ts'
import {
  normalizeSessionTitle,
  SessionTitleProviderId,
  type SessionTitleModelIdentity,
  type SessionTitleProviderRequest,
  type SessionTitleProviderResult,
  type SessionTitleUserMessage,
} from '@deepseek-ai/dsh-session-title'
import * as titleLlmModule from '@deepseek-ai/dsh-session-title-llm'

/** Shared execution controls plus this provider's title-length targets. */
export interface SessionTitleLlmConfig {
  /** Target word count for non-CJK titles. */
  readonly targetWords: number
  /** Target character count for Chinese, Japanese, or Korean titles. */
  readonly targetCjkCharacters: number
  /** Maximum UTF-8 bytes in the prepared user input. */
  readonly maxInputBytes: number
  /** Auxiliary generation output-token cap. */
  readonly maxOutputTokens: number
  /** End-to-end auxiliary request deadline in milliseconds. */
  readonly timeoutMs: number
  /** Optional explicit provider route; must be paired with `model`. */
  readonly provider?: string
  /** Optional explicit model id; must be paired with `provider`. */
  readonly model?: string
}

/** Execution-only subset accepted by dsh 0.2.1's shared title executor. */
export interface SessionTitleLlmExecutionConfig {
  readonly maxInputBytes: number
  readonly maxOutputTokens: number
  readonly timeoutMs: number
  readonly provider?: string
  readonly model?: string
}

/** Fields shared by both upstream title-LLM config schemas, plus local targets. */
export const SessionTitleLlmConfigFields = {
  targetWords: z.number().step(1).min(1).required(),
  targetCjkCharacters: z.number().step(1).min(1).required(),
  maxInputBytes: titleLlmModule.SessionTitleLlmConfigFields.maxInputBytes,
  maxOutputTokens: titleLlmModule.SessionTitleLlmConfigFields.maxOutputTokens,
  timeoutMs: titleLlmModule.SessionTitleLlmConfigFields.timeoutMs,
  provider: titleLlmModule.SessionTitleLlmConfigFields.provider,
  model: titleLlmModule.SessionTitleLlmConfigFields.model,
}


interface ResponseBlock {
  readonly type: string
  readonly text?: string
}

interface PreparedTitleModel {
  readonly reasoning?: {
    readonly efforts?: readonly { readonly id?: string }[]
  }
}

interface PreparedSessionTitleLlmRequest {
  readonly system: string
  readonly input: string
  readonly messageSeqs: readonly SessionSeq[]
  readonly selectReasoningEffort: (model: PreparedTitleModel) => string | undefined
}

interface PreparedSessionTitleLlmResponse {
  readonly blocks: readonly ResponseBlock[]
  readonly finish: { readonly kind: string }
  readonly model: SessionTitleModelIdentity
}

type LegacyGenerate = (
  ctx: Context,
  config: SessionTitleLlmConfig,
  request: SessionTitleProviderRequest,
  selectedMessages: readonly SessionTitleUserMessage[],
  titleProvider: SessionTitleProviderId,
) => Promise<SessionTitleProviderResult>

type PreparedExecute = (
  ctx: Context,
  config: SessionTitleLlmExecutionConfig,
  request: SessionTitleProviderRequest,
  titleProvider: SessionTitleProviderId,
  prepared: PreparedSessionTitleLlmRequest,
) => Promise<PreparedSessionTitleLlmResponse>

type ResolveConfig = (config: object) => unknown

/** Runtime shape common to both upstream title-LLM package lines. */
export interface TitleLlmModuleRuntime {
  readonly generateSessionTitleWithLlm?: LegacyGenerate
  readonly executeSessionTitleLlm?: PreparedExecute
  readonly resolveSessionTitleLlmConfig?: ResolveConfig
}

/** One version-selected title provider implementation. */
export interface SessionTitleProviderRunner {
  readonly mode: 'legacy' | 'prepared'
  generate(
    ctx: Context,
    request: SessionTitleProviderRequest,
    selectedMessages: readonly SessionTitleUserMessage[],
  ): Promise<SessionTitleProviderResult>
}

const defaultRuntime = titleLlmModule as unknown as TitleLlmModuleRuntime

/** Language-aware system instruction for a title derived from one message. */
function systemPrompt(config: SessionTitleLlmConfig): string {
  return [
    'Create a concise title for an AI coding-assistant session from the supplied human messages.',
    'Return only the title on one line, **in plain text of natural language**, with no quotes, prefix, explanation, Markdown, XML, or terminal control codes. No code is allowed.',
    'Use the language of the messages.',
    `Aim for about ${config.targetWords} words in non-CJK languages or ${config.targetCjkCharacters} CJK characters.`,
    'If the messages give little to name, still return a short best-effort title, such as Greeting, instead of explaining.',
  ].join('\n')
}

/** Asterisk emphasis wrapping a whole line, such as `**Title**`. */
const EMPHASIS_WRAPPER = /^(?<marker>\*{1,3})(?<inner>\S(?:.*\S)?)\k<marker>$/u

/**
 * Take the title from model output: the first non-empty line, without
 * asterisk emphasis that wraps that whole line. Models that disregard the
 * one-line instruction put the title first and commentary after it.
 */
function titleFromOutput(text: string): string {
  const line = text.split(/\r?\n/u).map(item => item.trim()).find(item => item.length > 0) ?? ''
  const groups = EMPHASIS_WRAPPER.exec(line)?.groups
  const marker = groups?.['marker']
  const inner = groups?.['inner']
  return marker === undefined || inner === undefined || inner.includes(marker) ? line : inner
}

/** Reject terminal tool-call or max-token outcomes and derive one non-empty title. */
function titleFromResponse(response: PreparedSessionTitleLlmResponse): string {
  switch (response.finish.kind) {
    case 'stop':
      break
    case 'tool-calls':
      throw new Error('session-title-llm: title output must contain text only')
    case 'max-tokens':
      throw new Error('session-title-llm: title output reached maxOutputTokens')
    default:
      throw new Error(`session-title-llm: unsupported finish reason "${String(response.finish.kind)}"`)
  }
  if (response.blocks.some(block => block.type === 'tool-call')) {
    throw new Error('session-title-llm: title output must contain text only')
  }
  const text = response.blocks
    .filter(block => block.type === 'text')
    .map(block => block.text ?? '')
    .join(' ')
  const title = normalizeSessionTitle(titleFromOutput(text), Number.MAX_SAFE_INTEGER)
  if (title.length === 0) throw new Error('session-title-llm: title model produced no text')
  return title
}

/**
 * Select the legacy helper or the prepared executor once, at plugin mount.
 *
 * Both branches keep the same provider-facing result shape. The prepared
 * branch reproduces the 0.2.1 first-prompt provider's system instruction,
 * JSON framing, least-effort selection, and output validation.
 */
export function createSessionTitleProviderRunner(
  config: SessionTitleLlmConfig,
  id: string,
  api: TitleLlmModuleRuntime = defaultRuntime,
): SessionTitleProviderRunner {
  const titleProvider = SessionTitleProviderId(id)

  if (typeof api.generateSessionTitleWithLlm === 'function') {
    const generate = api.generateSessionTitleWithLlm
    const resolved = (typeof api.resolveSessionTitleLlmConfig === 'function'
      ? api.resolveSessionTitleLlmConfig(config)
      : config) as SessionTitleLlmConfig
    return {
      mode: 'legacy',
      generate: (ctx, request, selectedMessages) => generate(ctx, resolved, request, selectedMessages, titleProvider),
    }
  }

  if (typeof api.executeSessionTitleLlm === 'function') {
    if (!Number.isInteger(config.targetWords) || config.targetWords <= 0) {
      throw new Error('session-title-first-prompt-llm: targetWords must be a positive integer')
    }
    if (!Number.isInteger(config.targetCjkCharacters) || config.targetCjkCharacters <= 0) {
      throw new Error('session-title-first-prompt-llm: targetCjkCharacters must be a positive integer')
    }
    const execution: SessionTitleLlmExecutionConfig = {
      maxInputBytes: config.maxInputBytes,
      maxOutputTokens: config.maxOutputTokens,
      timeoutMs: config.timeoutMs,
      ...(config.provider === undefined ? {} : { provider: config.provider }),
      ...(config.model === undefined ? {} : { model: config.model }),
    }
    const resolved = (typeof api.resolveSessionTitleLlmConfig === 'function'
      ? api.resolveSessionTitleLlmConfig(execution)
      : execution) as SessionTitleLlmExecutionConfig
    const execute = api.executeSessionTitleLlm
    return {
      mode: 'prepared',
      async generate(ctx, request, selectedMessages) {
        if (selectedMessages.length === 0) {
          throw new Error('session-title-llm: at least one source message is required')
        }
        const response = await execute(ctx, resolved, request, titleProvider, {
          system: systemPrompt(config),
          input: `Generate the session title from this JSON array of human messages:\n${JSON.stringify(selectedMessages)}`,
          messageSeqs: selectedMessages.map(message => message.seq),
          selectReasoningEffort: model => model.reasoning?.efforts?.[0]?.id,
        })
        return {
          title: titleFromResponse(response),
          messageSeqs: selectedMessages.map(message => message.seq),
          model: response.model,
        }
      },
    }
  }

  throw new Error(
    '@deepseek-ai/dsh-session-title-llm exports neither generateSessionTitleWithLlm (0.2.0) nor executeSessionTitleLlm (0.2.1+); install a compatible dsh release',
  )
}
