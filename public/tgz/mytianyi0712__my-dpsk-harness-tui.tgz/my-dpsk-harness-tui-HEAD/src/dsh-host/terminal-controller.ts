/**
 * Terminal-controller compatibility seam.
 *
 * dsh 0.2.0 exposes attach via `follow()`, `write()`, and `resize()`.
 * dsh 0.2.1 replaces those with one `attach()` Remote stream whose input is an
 * async uplink and whose output also carries writability and acknowledgement
 * frames. The TUI IPC protocol remains the 0.2.0 shape, so this adapter maps
 * either upstream surface onto the same local controller contract.
 */

import type { Agent } from './agent.ts'
import type { Context } from './framework.ts'
import type { SessionId } from './session.ts'

export type WebTerminalId = string
export type TerminalAttachmentId = string

export interface TerminalShellInfo {
  readonly path: string
  readonly args: readonly string[]
  readonly name: string
}

export interface TerminalEnvironment {
  readonly cwd: string
  readonly maxInputBytes: number
  readonly maxCols: number
  readonly maxRows: number
  readonly scrollback: number
}

export interface WebTerminalInfo {
  readonly id: string
  readonly title: string
  readonly shell: TerminalShellInfo
  readonly cwd: string
  readonly cols: number
  readonly rows: number
  readonly state: 'running' | 'exited' | 'failed'
  readonly exitCode: number | null
  readonly error?: string
  readonly controllerId?: TerminalAttachmentId
}

export interface TerminalCreateRequest {
  readonly shellPath?: string
  readonly id: WebTerminalId
  readonly cols: number
  readonly rows: number
}

export type TerminalFrame =
  | { readonly type: 'snapshot'; readonly sequence: number; readonly screen: string; readonly info: WebTerminalInfo }
  | { readonly type: 'output'; readonly sequence: number; readonly data: string }
  | { readonly type: 'state'; readonly info: WebTerminalInfo }

/** The local contract used by the TUI host across both upstream API lines. */
export interface TerminalControllerService {
  environment(agent: Agent, signal: AbortSignal): TerminalEnvironment
  list(sessionId: SessionId): readonly WebTerminalInfo[]
  create(agent: Agent, request: TerminalCreateRequest, signal: AbortSignal): Promise<WebTerminalInfo>
  retain(sessionId: SessionId, id: WebTerminalId, signal: AbortSignal): AsyncIterable<unknown>
  follow(
    agent: Agent,
    id: WebTerminalId,
    attachmentId: TerminalAttachmentId,
    signal: AbortSignal,
  ): AsyncIterable<TerminalFrame>
  write(
    agent: Agent,
    id: WebTerminalId,
    attachmentId: TerminalAttachmentId,
    data: string,
  ): Promise<void>
  resize(
    agent: Agent,
    id: WebTerminalId,
    attachmentId: TerminalAttachmentId,
    cols: number,
    rows: number,
  ): Promise<void>
  close(agent: Agent, id: WebTerminalId): Promise<void>
}

interface RawWebTerminalInfo {
  readonly id: string
  readonly title: string
  readonly shell: TerminalShellInfo
  readonly cwd: string
  readonly cols: number
  readonly rows: number
  readonly state: 'running' | 'exited' | 'failed'
  readonly exitCode: number | null
  readonly error?: string
  readonly controllerId?: string
}

interface RawTerminalEnvironment {
  readonly cwd: string
  readonly maxInputBytes: number
  readonly maxCols: number
  readonly maxRows: number
  readonly scrollback: number
}

interface RawTerminalController {
  environment(agent: Agent, signal: AbortSignal): RawTerminalEnvironment
  list(sessionId: SessionId): readonly RawWebTerminalInfo[]
  create(agent: Agent, request: TerminalCreateRequest, signal: AbortSignal): Promise<RawWebTerminalInfo>
  retain(sessionId: SessionId, id: WebTerminalId, signal: AbortSignal): AsyncIterable<unknown>
  close(agent: Agent, id: WebTerminalId): Promise<void>
  follow?(
    agent: Agent,
    id: WebTerminalId,
    attachmentId: TerminalAttachmentId,
    signal: AbortSignal,
  ): AsyncIterable<unknown>
  write?(
    agent: Agent,
    id: WebTerminalId,
    attachmentId: TerminalAttachmentId,
    data: string,
  ): Promise<void>
  resize?(
    agent: Agent,
    id: WebTerminalId,
    attachmentId: TerminalAttachmentId,
    cols: number,
    rows: number,
  ): Promise<void>
  attach?(agent: Agent, id: WebTerminalId, signal: AbortSignal): AsyncIterable<unknown>
}

interface PeerScope {
  readonly id: string
  readonly ctx: Context
  readonly principal: { readonly kind: 'owner' }
  readonly signal: AbortSignal
  readonly interactions: 'none'
  dispose(): Promise<void>
}

interface GatewayStreamRequest {
  readonly namespace: string
  readonly method: string
  readonly args: Readonly<Record<string, unknown>>
  readonly uplink?: AsyncIterable<unknown>
  readonly signal?: AbortSignal
  readonly peer: PeerScope
}

interface TypertGateway {
  stream(request: GatewayStreamRequest): Promise<AsyncIterable<unknown>>
}

interface NewAttachment {
  readonly queue: TerminalInputQueue
  sequence: number
}

let peerSequence = 0

/** One uplink queue consumed by the 0.2.1 terminal attach stream. */
class TerminalInputQueue implements AsyncIterable<unknown> {
  private readonly items: unknown[] = []
  private readonly waiters: ((result: IteratorResult<unknown>) => void)[] = []
  private closed = false

  send(item: unknown): void {
    if (this.closed) throw new Error('terminal attachment input is closed')
    const waiter = this.waiters.shift()
    if (waiter === undefined) this.items.push(item)
    else waiter({ done: false, value: item })
  }

  close(): void {
    if (this.closed) return
    this.closed = true
    this.items.length = 0
    for (const waiter of this.waiters.splice(0)) waiter({ done: true, value: undefined })
  }

  [Symbol.asyncIterator](): AsyncIterator<unknown> {
    return this
  }

  next(): Promise<IteratorResult<unknown>> {
    const item = this.items.shift()
    if (item !== undefined) return Promise.resolve({ done: false, value: item })
    if (this.closed) return Promise.resolve({ done: true, value: undefined })
    const pending = Promise.withResolvers<IteratorResult<unknown>>()
    this.waiters.push(pending.resolve)
    return pending.promise
  }

  return(): Promise<IteratorResult<unknown>> {
    this.close()
    return Promise.resolve({ done: true, value: undefined })
  }
}

function isRawWebTerminalInfo(value: unknown): value is RawWebTerminalInfo {
  if (typeof value !== 'object' || value === null) return false
  if (!('id' in value) || typeof value.id !== 'string') return false
  if (!('title' in value) || typeof value.title !== 'string') return false
  if (!('shell' in value) || typeof value.shell !== 'object' || value.shell === null) return false
  const shell = value.shell
  if (!('path' in shell) || typeof shell.path !== 'string') return false
  if (!('name' in shell) || typeof shell.name !== 'string') return false
  if (!('args' in shell) || !Array.isArray(shell.args) || !shell.args.every(argument => typeof argument === 'string')) return false
  if (!('cwd' in value) || typeof value.cwd !== 'string') return false
  if (!('cols' in value) || typeof value.cols !== 'number') return false
  if (!('rows' in value) || typeof value.rows !== 'number') return false
  if (!('state' in value) || (value.state !== 'running' && value.state !== 'exited' && value.state !== 'failed')) return false
  if (!('exitCode' in value) || (value.exitCode !== null && typeof value.exitCode !== 'number')) return false
  if ('error' in value && value.error !== undefined && typeof value.error !== 'string') return false
  if ('controllerId' in value && value.controllerId !== undefined && typeof value.controllerId !== 'string') return false
  return true
}

/** Copy only the stable fields the TUI wire protocol understands. */
function normalizeInfo(info: RawWebTerminalInfo): WebTerminalInfo {
  return {
    id: info.id,
    title: info.title,
    shell: { path: info.shell.path, args: [...info.shell.args], name: info.shell.name },
    cwd: info.cwd,
    cols: info.cols,
    rows: info.rows,
    state: info.state,
    exitCode: info.exitCode,
    ...(info.error === undefined ? {} : { error: info.error }),
    ...(info.controllerId === undefined ? {} : { controllerId: info.controllerId }),
  }
}

function normalizeEnvironment(environment: RawTerminalEnvironment): TerminalEnvironment {
  return {
    cwd: environment.cwd,
    maxInputBytes: environment.maxInputBytes,
    maxCols: environment.maxCols,
    maxRows: environment.maxRows,
    scrollback: environment.scrollback,
  }
}

/** Attach the TUI attachment identity when the 0.2.1 stream grants input control. */
function withAttachmentControl(info: WebTerminalInfo, attachmentId: TerminalAttachmentId, writable: boolean): WebTerminalInfo {
  if (!writable) {
    const { controllerId: _controllerId, ...uncontrolled } = info
    return uncontrolled
  }
  return { ...info, controllerId: attachmentId }
}

/** Drop 0.2.1 acknowledgements and project writability back to the 0.2.0 controllerId field. */
function normalizeFrame(value: unknown, attachmentId?: TerminalAttachmentId): TerminalFrame | undefined {
  if (typeof value !== 'object' || value === null || !('type' in value)) {
    throw new Error('terminal frame is not an object')
  }
  const type = value.type
  if (type === 'snapshot') {
    if (!('sequence' in value) || typeof value.sequence !== 'number') throw new Error('terminal snapshot frame has no sequence')
    if (!('screen' in value) || typeof value.screen !== 'string') throw new Error('terminal snapshot frame has no screen')
    if (!('info' in value) || !isRawWebTerminalInfo(value.info)) throw new Error('terminal snapshot frame has no valid info')
    const info = normalizeInfo(value.info)
    const writable = 'writable' in value && value.writable === true
    return {
      type: 'snapshot',
      sequence: value.sequence,
      screen: value.screen,
      info: attachmentId === undefined ? info : withAttachmentControl(info, attachmentId, writable),
    }
  }
  if (type === 'output') {
    if (!('sequence' in value) || typeof value.sequence !== 'number') throw new Error('terminal output frame has no sequence')
    if (!('data' in value) || typeof value.data !== 'string') throw new Error('terminal output frame has no data')
    return { type: 'output', sequence: value.sequence, data: value.data }
  }
  if (type === 'state') {
    if (!('info' in value) || !isRawWebTerminalInfo(value.info)) throw new Error('terminal state frame has no valid info')
    const info = normalizeInfo(value.info)
    const writable = 'writable' in value && value.writable === true
    return { type: 'state', info: attachmentId === undefined ? info : withAttachmentControl(info, attachmentId, writable) }
  }
  if (type === 'ack') return undefined
  throw new Error(`unsupported terminal frame type: ${String(type)}`)
}

/** Operations whose shape did not change across 0.2.0 and 0.2.1. */
function commonControllerOperations(raw: RawTerminalController): Pick<
  TerminalControllerService,
  'environment' | 'list' | 'create' | 'retain' | 'close'
> {
  return {
    environment: (agent, signal) => normalizeEnvironment(raw.environment(agent, signal)),
    list: sessionId => raw.list(sessionId).map(normalizeInfo),
    create: async (agent, request, signal) => normalizeInfo(await raw.create(agent, request, signal)),
    retain: (sessionId, id, signal) => raw.retain(sessionId, id, signal),
    close: (agent, id) => raw.close(agent, id),
  }
}

/** One owner Peer used only for in-process terminal attach streams. */
function createGatewayPeer(context: Context): PeerScope {
  const lifetime = new AbortController()
  return {
    id: `tui-terminal-${Date.now()}-${++peerSequence}`,
    ctx: context,
    principal: { kind: 'owner' },
    signal: lifetime.signal,
    interactions: 'none',
    dispose: async () => {
      lifetime.abort(new Error('TUI terminal Remote peer disposed'))
    },
  }
}

/**
 * Adapt the installed terminal controller without a static import of either
 * version's changed method set.
 */
export function adaptTerminalController(rawController: unknown, context: Context): TerminalControllerService {
  const raw = rawController as RawTerminalController
  const common = commonControllerOperations(raw)

  if (typeof raw.follow === 'function' && typeof raw.write === 'function' && typeof raw.resize === 'function') {
    const follow = raw.follow
    const write = raw.write
    const resize = raw.resize
    return {
      ...common,
      async *follow(agent, id, attachmentId, signal) {
        for await (const frame of follow.call(raw, agent, id, attachmentId, signal)) {
          const normalized = normalizeFrame(frame)
          if (normalized !== undefined) yield normalized
        }
      },
      write: (agent, id, attachmentId, data) => write.call(raw, agent, id, attachmentId, data),
      resize: (agent, id, attachmentId, cols, rows) => resize.call(raw, agent, id, attachmentId, cols, rows),
    }
  }

  if (typeof raw.attach !== 'function') {
    throw new Error('terminal controller exposes neither follow/write/resize (0.2.0) nor attach (0.2.1+)')
  }

  const attachments = new Map<string, NewAttachment>()
  let peer: PeerScope | undefined
  return {
    ...common,
    async *follow(agent, id, attachmentId, signal) {
      // Cordis Context is augmented by the optional dsh-api-gateway package,
      // which is deliberately not a compile-time peer of this adapter.
      const contextWithServices = context as unknown as { get(key: string): unknown }
      const gateway = contextWithServices.get.call(context, 'typertGateway') as TypertGateway | undefined
      if (gateway === undefined) throw new Error('terminal attach requires the typertGateway service')
      peer ??= createGatewayPeer(context)
      const key = `${String(agent.id)}\0${id}\0${attachmentId}`
      const queue = new TerminalInputQueue()
      const streamSignal = AbortSignal.any([signal, peer.signal])
      const cancel = (): void => queue.close()
      streamSignal.addEventListener('abort', cancel, { once: true })
      try {
        const stream = await gateway.stream({
          namespace: 'terminal',
          method: 'attach',
          args: { agentId: agent.id, id },
          uplink: queue,
          signal: streamSignal,
          peer,
        })
        attachments.set(key, { queue, sequence: 0 })
        for await (const frame of stream) {
          if (streamSignal.aborted) return
          const normalized = normalizeFrame(frame, attachmentId)
          if (normalized !== undefined) yield normalized
        }
      } finally {
        streamSignal.removeEventListener('abort', cancel)
        queue.close()
        attachments.delete(key)
      }
    },
    async write(agent, id, attachmentId, data) {
      const key = `${String(agent.id)}\0${id}\0${attachmentId}`
      const attachment = attachments.get(key)
      if (attachment === undefined) throw new Error(`${id}: terminal attachment is not following`)
      attachment.sequence += 1
      attachment.queue.send({ type: 'write', sequence: attachment.sequence, data })
    },
    async resize(agent, id, attachmentId, cols, rows) {
      const key = `${String(agent.id)}\0${id}\0${attachmentId}`
      const attachment = attachments.get(key)
      if (attachment === undefined) throw new Error(`${id}: terminal attachment is not following`)
      attachment.sequence += 1
      attachment.queue.send({ type: 'resize', sequence: attachment.sequence, cols, rows })
    },
  }
}
