/**
 * Declaration-merge imports: these side-effect type imports keep the Cordis
 * Context/Events augmentations active for the whole program even though the
 * rest of the code no longer imports these packages directly.
 */

import type {} from '@deepseek-ai/dsh-commands'
import type {} from '@deepseek-ai/dsh-token-meter'
import type {} from '@deepseek-ai/dsh-user-questions'
import type {} from '@deepseek-ai/dsh-session-query'
import type {} from '@deepseek-ai/dsh-agent-default-model'
import type {} from '@deepseek-ai/dsh-skill'
import type {} from '@deepseek-ai/dsh-session-reference'
import type {} from '@deepseek-ai/dsh-settings'
import type {} from '@deepseek-ai/dsh-permission-presets'
import type {} from '@deepseek-ai/dsh-session-projection'
import type {} from '@deepseek-ai/dsh-agent-preset-registry'
import type {} from '@deepseek-ai/dsh-goal'
import type {} from '@deepseek-ai/dsh-compaction'
import type {} from '@deepseek-ai/dsh-session-persistence'
import type {} from '@deepseek-ai/dsh-tool-todo'
/**
 * The Workspace registry is a web-layer plugin, so a terminal profile only has
 * `ctx.workspaceRegistry` after `src/workspace-sessions.ts` mounts it. The
 * merge keeps `ctx.get('workspaceRegistry')` typed on every profile.
 */
import type {} from '@deepseek-ai/dsh-workspace'

import type {} from '@deepseek-ai/cordis-plugin-loader'
import type {} from '@deepseek-ai/dsh-user-approval'
import type {} from '@deepseek-ai/dsh-jobs'
import type {} from '@deepseek-ai/dsh-api-terminal-controller'
import type {} from '@deepseek-ai/dsh-attachment'
/**
 * The WeChat bridge's own message source. dsh 0.2 removed the shared catch-all
 * `plugin` kind: each producer declares its own `kind` in `MessageSourceMap`,
 * and consumers fall through unknown kinds.
 */
declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    'wechat-bridge': {
      kind: 'wechat-bridge'
      plugin: string
      form: 'notice'
      summary: string
    }
  }
}

/**
 * The subagent call descriptor the harness appends to child session logs. The
 * package's event map does not carry the key, so the row shape is declared here;
 * the renderer's subagent panel and the host's subagent set read the same fields.
 */
declare module '@deepseek-ai/dsh-session' {
  interface SessionEventMap {
    'subagent/descriptor': {
      label: string
      provider: string
      mode: 'one-shot' | 'continuable'
    }
  }
}
