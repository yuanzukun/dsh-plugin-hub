/**
 * Renderer protocol v1 negotiation.
 *
 * The renderer announces its protocol version, identity and capabilities in the
 * `hello` envelope; the host answers with its own identity, the capabilities it
 * will send, and one of five states. The vocabulary is the same five states the
 * plugin-spec admission uses, so `/plugins` and `/doctor` can report both kinds
 * of admission the same way.
 *
 * The host decides, not the renderer: the renderer exits on `rejected` and on
 * `unknown`, and the host refuses to hand the terminal over on
 * `waiting_authorization`.
 */

import { RENDERER_PROTOCOL_VERSION, type IpcEnvelope } from './envelope.ts'
import {
  HOST_CAPABILITIES,
  OPTIONAL_DOWNSTREAM_KINDS,
  RENDERER_CAPABILITIES,
  type HelloPayload,
  type HelloAckPayload,
  type NegotiationStatus,
} from './kinds.ts'

/** The host's own view of the contract, supplied by the host process. */
export interface HostView {
  readonly hostId: string
  readonly hostVersion: string
  /** Capabilities the host will send data for. */
  readonly capabilities: readonly string[]
  /** Renderer capabilities the host requires before it will render. */
  readonly requiredCapabilities: readonly string[]
  /** Terminal handoff is authorized (the launcher owns the TTY for the renderer). */
  readonly terminalAuthorized: boolean
  /** The grid the host observed from its own environment; echoed in the ack. */
  readonly terminalSize?: { readonly width: number; readonly height: number }
}

/** The default required set: a renderer that cannot draw these cannot run. */
export const DEFAULT_REQUIRED_CAPABILITIES: readonly string[] = ['transcript', 'composer']

export interface Negotiation {
  readonly status: NegotiationStatus
  readonly reasons: readonly string[]
  /** Kinds the renderer does not know; the host will skip sending them. */
  readonly skippedKinds: readonly string[]
  /** Capabilities the renderer lacks; the host degrades the features they drive. */
  readonly degradedCapabilities: readonly string[]
}

function parseHello(envelope: IpcEnvelope): HelloPayload | undefined {
  if (typeof envelope.payload !== 'object' || envelope.payload === null) return undefined
  const payload = envelope.payload as Record<string, unknown>
  if (typeof payload.protocolVersion !== 'number') return undefined
  if (typeof payload.rendererId !== 'string' || payload.rendererId === '') return undefined
  if (typeof payload.rendererVersion !== 'string') return undefined
  if (!Array.isArray(payload.capabilities)) return undefined
  if (!Array.isArray(payload.kinds)) return undefined
  return {
    protocolVersion: payload.protocolVersion,
    rendererId: payload.rendererId,
    rendererVersion: payload.rendererVersion,
    capabilities: payload.capabilities.filter((item): item is string => typeof item === 'string'),
    kinds: payload.kinds.filter((item): item is string => typeof item === 'string'),
  }
}

/**
 * Decide whether this renderer may take the terminal.
 *
 * `rejected` covers a protocol version mismatch and a missing required
 * capability. `waiting_authorization` covers a renderer that is compatible but
 * has not been given the TTY. `compatible_degraded` lists the optional kinds and
 * capabilities the host will skip, so the renderer can print what is missing.
 */
export function negotiateRenderer(envelope: IpcEnvelope, host: HostView): Negotiation {
  const hello = parseHello(envelope)
  if (hello === undefined) {
    return { status: 'unknown', reasons: ['hello payload is malformed'], skippedKinds: [], degradedCapabilities: [] }
  }

  if (hello.protocolVersion !== RENDERER_PROTOCOL_VERSION) {
    return {
      status: 'rejected',
      reasons: [`protocol version mismatch: host speaks v${RENDERER_PROTOCOL_VERSION}, renderer speaks v${hello.protocolVersion}`],
      skippedKinds: [],
      degradedCapabilities: [],
    }
  }

  const known = new Set(hello.kinds)
  const missingRequired = host.requiredCapabilities.filter(capability => !hello.capabilities.includes(capability))
  if (missingRequired.length > 0) {
    return {
      status: 'rejected',
      reasons: [`renderer is missing required capabilities: ${missingRequired.join(', ')}`],
      skippedKinds: [],
      degradedCapabilities: [],
    }
  }

  const skippedKinds = OPTIONAL_DOWNSTREAM_KINDS.filter(kind => !known.has(kind))
  const degradedCapabilities = RENDERER_CAPABILITIES.filter(capability => !hello.capabilities.includes(capability))

  if (!host.terminalAuthorized) {
    return {
      status: 'waiting_authorization',
      reasons: ['terminal handoff is not authorized; the launcher must hand the TTY to the renderer'],
      skippedKinds: skippedKinds,
      degradedCapabilities: degradedCapabilities,
    }
  }

  const reasons: string[] = []
  if (skippedKinds.length > 0) reasons.push(`renderer does not know: ${skippedKinds.join(', ')}`)
  if (degradedCapabilities.length > 0) reasons.push(`renderer lacks optional capabilities: ${degradedCapabilities.join(', ')}`)
  const hostMissing = HOST_CAPABILITIES.filter(capability => !host.capabilities.includes(capability))
  if (hostMissing.length > 0) reasons.push(`host does not provide: ${hostMissing.join(', ')}`)

  return {
    status: reasons.length === 0 ? 'compatible' : 'compatible_degraded',
    reasons,
    skippedKinds,
    degradedCapabilities,
  }
}

/** Build the host's answer to a successful negotiation. */
export function helloAck(negotiation: Negotiation, host: HostView): HelloAckPayload {
  return {
    protocolVersion: RENDERER_PROTOCOL_VERSION,
    hostId: host.hostId,
    hostVersion: host.hostVersion,
    capabilities: host.capabilities,
    status: negotiation.status,
    reasons: negotiation.reasons,
    ...(host.terminalSize === undefined ? {} : { terminalSize: host.terminalSize }),
  }
}

/** The renderer-side mirror: kinds the renderer must implement. */
export function rendererKindCoverage(capabilities: readonly string[]): { known: string[]; unknown: string[] } {
  const known = new Set(capabilities)
  return {
    known: RENDERER_CAPABILITIES.filter(capability => known.has(capability)),
    unknown: RENDERER_CAPABILITIES.filter(capability => !known.has(capability)),
  }
}
