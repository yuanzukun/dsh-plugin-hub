/**
 * Renderer protocol v2 envelope and NDJSON framing.
 *
 * The host (this bundle, running inside dsh's Node process) and the renderer
 * (a Bun-compiled OpenTUI binary that owns the TTY) exchange one JSON object
 * per IPC message. The envelope carries the protocol version, a sequence
 * number for ordering and correlation, the kind, and the payload.
 *
 * Framing is one envelope per line. The Node IPC channel already delivers whole
 * messages, so the line form matters only for the log file and for a future
 * socket transport; `encodeLine` / `decodeLine` are the single source of truth
 * for both.
 */

/** Protocol version this bundle speaks. Bumped on any breaking envelope change. */
export const RENDERER_PROTOCOL_VERSION = 2

/** One message on the host ↔ renderer channel. */
export interface IpcEnvelope {
  readonly protocolVersion: number
  readonly seq: number
  readonly kind: string
  readonly payload: unknown
}

/** Shape checks for the envelope header; returns the reasons it is unusable. */
export function envelopeErrors(envelope: unknown): string[] {
  const reasons: string[] = []
  if (typeof envelope !== 'object' || envelope === null) {
    return ['envelope is not an object']
  }
  const record = envelope as Record<string, unknown>
  if (typeof record.protocolVersion !== 'number') reasons.push('protocolVersion is not a number')
  if (typeof record.seq !== 'number') reasons.push('seq is not a number')
  if (typeof record.kind !== 'string' || record.kind === '') reasons.push('kind is not a non-empty string')
  if (!('payload' in record)) reasons.push('payload is missing')
  return reasons
}

/** Serialize one envelope as an NDJSON line (no trailing newline). */
export function encodeLine(envelope: IpcEnvelope): string {
  return JSON.stringify(envelope)
}

/** Parse one NDJSON line; returns the envelope and the reasons it is invalid. */
export function decodeLine(line: string): { envelope: IpcEnvelope | undefined; errors: string[] } {
  let parsed: unknown
  try {
    parsed = JSON.parse(line)
  } catch (error) {
    return { envelope: undefined, errors: [`line is not valid JSON: ${error instanceof Error ? error.message : String(error)}`] }
  }
  const errors = envelopeErrors(parsed)
  if (errors.length > 0) return { envelope: undefined, errors }
  return { envelope: parsed as IpcEnvelope, errors: [] }
}

/**
 * Split a byte stream into complete lines. Keeps a trailing partial line in the
 * returned remainder so the caller can prepend it to the next chunk.
 */
export function splitLines(chunk: string, pending: string): { lines: string[]; remainder: string } {
  const parts = (pending + chunk).split('\n')
  const last = parts[parts.length - 1]
  return { lines: parts.slice(0, -1), remainder: last ?? '' }
}
