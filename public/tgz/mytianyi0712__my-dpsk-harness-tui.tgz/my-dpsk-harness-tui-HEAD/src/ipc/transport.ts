/**
 * Renderer protocol v2 transport.
 *
 * The transport is the same on both sides: a channel that carries whole text
 * messages (the Node IPC channel on fd 3), a sequence counter, and envelope
 * framing. The host side wraps a `ChildProcess`; the renderer side wraps
 * `process.send` / `process.on('message')`. Both are expressed as the `Channel`
 * interface so one transport implementation serves both processes.
 */

import { RENDERER_PROTOCOL_VERSION } from './envelope.ts'
import { decodeLine, encodeLine, type IpcEnvelope } from './envelope.ts'

/** A bidirectional message channel: whole messages in, whole messages out. */
export interface Channel {
  send(text: string): void
  /** Subscribe to incoming messages; returns an unsubscribe function. */
  onMessage(listener: (text: string) => void): () => void
}

/** A channel that carries no messages (the IPC pipe is closed). */
export function nullChannel(): Channel {
  return { send: () => undefined, onMessage: () => () => undefined }
}

export interface TransportLog {
  (level: 'info' | 'warn' | 'error', text: string): void
}

/**
 * Envelope transport over a message channel.
 *
 * `send` assigns the next sequence number and returns the envelope it sent, so
 * the caller can correlate a later `command-result`. Malformed inbound messages
 * are reported through the log and dropped: a renderer that sends garbage must
 * not take the host down, and a host that sends garbage must not take the
 * renderer down.
 */
export class IpcTransport {
  private seq = 0
  private readonly listeners: Array<(envelope: IpcEnvelope) => void> = []
  private readonly unsubscribe: () => void

  constructor(
    private readonly channel: Channel,
    private readonly log: TransportLog = () => undefined,
  ) {
    this.unsubscribe = this.channel.onMessage(text => this.receive(text))
  }

  private receive(text: string): void {
    const { envelope, errors } = decodeLine(text)
    if (envelope === undefined) {
      this.log('warn', `dropped malformed envelope: ${errors.join('; ')}`)
      return
    }
    for (const listener of this.listeners) listener(envelope)
  }

  send(kind: string, payload: unknown): IpcEnvelope {
    const envelope: IpcEnvelope = { protocolVersion: RENDERER_PROTOCOL_VERSION, seq: this.seq, kind, payload }
    this.seq += 1
    this.channel.send(encodeLine(envelope))
    return envelope
  }

  /** Observe incoming envelopes; returns an unsubscribe function. */
  onEnvelope(listener: (envelope: IpcEnvelope) => void): () => void {
    this.listeners.push(listener)
    return () => {
      const index = this.listeners.indexOf(listener)
      if (index >= 0) this.listeners.splice(index, 1)
    }
  }

  /** Stop observing inbound messages. The underlying channel is owned by the caller. */
  close(): void {
    this.unsubscribe()
    this.listeners.length = 0
  }

  /** Next sequence number, for tests and for correlating results. */
  get nextSeq(): number {
    return this.seq
  }
}

/** The renderer-side channel: Bun's `process.send` and `process.on('message')`. */
export function processChannel(send: (text: string) => void, on: (listener: (data: unknown) => void) => () => void): Channel {
  return {
    send: text => send(text),
    onMessage: listener => on(data => listener(typeof data === 'string' ? data : JSON.stringify(data))),
  }
}

/**
 * The host-side channel: a spawned child with an IPC pipe.
 *
 * `send` is `child.send`, and messages arrive on the child's `message` event.
 * The subscription is registered once and fanned out to the transport, so the
 * child's `message` listener count stays flat regardless of how many transports
 * are built. The listener is removed when the last subscriber unsubscribes.
 *
 * A renderer that closes its own IPC channel makes `child.send` throw
 * `ERR_IPC_CHANNEL_CLOSED` as an uncaught `error` event on the child, which takes the
 * host down. `send` is wrapped: the first failure marks the channel closed, every later
 * send is dropped, and the reason is reported once through `report`.
 */
export function childChannel(child: {
  send: (message: string) => void,
  on: (event: 'message', listener: (data: unknown) => void) => { removeListener: (event: 'message', listener: (data: unknown) => void) => void },
}, report?: (text: string) => void): Channel {
  const listeners: Array<(text: string) => void> = []
  let subscription: { removeListener: (event: 'message', listener: (data: unknown) => void) => void } | undefined
  let closed = false
  const fanout = (data: unknown) => {
    const text = typeof data === 'string' ? data : JSON.stringify(data)
    for (const listener of listeners.slice()) listener(text)
  }
  return {
    send: text => {
      if (closed) return
      try {
        child.send(text)
      } catch (error) {
        closed = true
        const code = (error as { code?: string }).code
        report?.(`IPC channel closed: ${code ?? (error as Error).message}`)
      }
    },
    onMessage: listener => {
      // Re-register the fanout when the subscriber count goes from zero to one:
      // a transport that closes and is reopened must receive messages again.
      if (subscription === undefined) subscription = child.on('message', fanout)
      listeners.push(listener)
      return () => {
        const index = listeners.indexOf(listener)
        if (index >= 0) listeners.splice(index, 1)
        if (listeners.length === 0 && subscription !== undefined) {
          subscription.removeListener('message', fanout)
          subscription = undefined
        }
      }
    },
  }
}
