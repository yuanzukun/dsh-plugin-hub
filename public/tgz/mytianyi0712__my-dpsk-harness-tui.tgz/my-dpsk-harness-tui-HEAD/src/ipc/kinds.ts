/**
 * Renderer protocol v2 kinds and payload shapes.
 *
 * Kinds are split by direction. Downstream kinds go host → renderer (the
 * renderer is a pure consumer of harness state); upstream kinds go renderer →
 * host (the renderer never touches dsh services directly, it asks the host to
 * perform them). Every kind is registered in `DOWNSTREAM_KINDS` /
 * `UPSTREAM_KINDS`; `verify:ipc-protocol` checks that the renderer-side mirror
 * lists the same set, so a kind cannot be added to one side only.
 */

/** One transcript entry, normalized from a dsh `SessionEvent` by the host. */
export interface TranscriptEvent {
  /** Stable id for in-place updates (streaming deltas reuse it). */
  readonly id: string
  readonly role: 'user' | 'assistant' | 'system' | 'tool'
  /** Markdown text for assistant/user/system text blocks. */
  readonly text?: string
  /** Tool name for tool rows; `undefined` for text rows. */
  readonly tool?: string
  /** Tool output lines, truncated to the host's `maxToolOutputLines`. */
  readonly toolOutput?: readonly string[]
  /** The call's string scalar arguments (shell `command`, `read` `path`, `grep` `pattern`,
   * …), so the row can paint the same header upstream does (`$ <command>`, `Read <path>`).
   * Numbers are carried in decimal; at most six keys. */
  readonly toolInput?: Readonly<Record<string, string>>
  /** Reasoning text when `showReasoning` is on. */
  readonly reasoning?: string
  /** Streaming state: the row is still growing. */
  readonly streaming?: boolean
  /** `true` once the step's reasoning stopped (the first answer delta arrived): the header
   * switches from upstream's `Thinking` spinner to `Thought`. */
  readonly reasoningDone?: boolean
  /** The file a strReplaceEditor call names; the block card's FilePath row. */
  readonly filePath?: string
  /** The call's +/- diff lines, from the same argument keys the pi-tui card reads. */
  readonly diff?: readonly string[]
  /** Tool row lifecycle: pending until the result lands, then ok/failed/denied. */
  readonly status?: 'pending' | 'ok' | 'failed' | 'denied'
  /** The provider model that produced an assistant row (the footer's Model slot). */
  readonly model?: string
  /** The model call's wall time in ms (step/start to the message). */
  readonly durationMs?: number
  /** The whole turn's model time in ms: sum of its steps, tool execution excluded. */
  readonly turnDurationMs?: number
  /** Output tokens per second across the turn (`outputTokens / turnDurationMs`). */
  readonly tokPerSec?: number
  /**
   * `true` on the one assistant row of a turn that paints the footer. A tool-using turn has
   * several assistant rows; the footer belongs to the end of the exchange, not to each step.
   */
  readonly footer?: boolean
  /** Durable attachment references the message carried; the bytes stay in the host. */
  readonly attachments?: readonly { readonly type: 'image' | 'file'; readonly attachmentId: string; readonly name?: string; readonly mediaType?: string }[]
  /** The turn ended aborted/interrupted/error while this row was live. */
  readonly interrupted?: boolean
  /** The failure reason a denied/failed tool row carries, or the turn error. */
  readonly error?: string
  /** Who produced a `user` row: `user` is typed input, anything else is a system-injected
   * prompt (the system reminder, the skill catalog, a compaction digest). The renderer hides
   * non-`user` rows, the way upstream never prints its own injected context. */
  readonly source?: string
  /** The log sequence this row came from, so a row can be traced back to its event. */
  readonly sourceSeq?: number
  /** The event's timestamp (ms since the epoch) when the log records one. */
  readonly createdAt?: number
  /** First answer text timestamp for a live row. Durable replays fall back to createdAt. */
  readonly bodyAt?: number
  /** The turn and step the row belongs to (assistant and tool rows). */
  readonly turn?: number
  readonly step?: number
  /** The tool call id a tool row answers, so streamed and durable rows share one identity. */
  readonly callId?: string
  /** The complete parsed call arguments, for a row that needs more than the scalar header. */
  readonly toolArguments?: unknown
  /** The message's JSON-safe content blocks with reasoning and text intact. */
  readonly content?: readonly unknown[]
}

/** Host → renderer: the renderer announces itself and its capabilities. */
export interface HelloPayload {
  readonly protocolVersion: number
  readonly rendererId: string
  readonly rendererVersion: string
  /** Capability names the renderer can render (e.g. `dialog`, `scrollbar`). */
  readonly capabilities: readonly string[]
  /** Kind names the renderer implements. The host skips kinds it does not list. */
  readonly kinds: readonly string[]
}

/** Renderer → host: the host answers the handshake with its own identity. */
export interface HelloAckPayload {
  readonly protocolVersion: number
  readonly hostId: string
  readonly hostVersion: string
  /** Capability names the host will send. */
  readonly capabilities: readonly string[]
  readonly status: NegotiationStatus
  readonly reasons: readonly string[]
  /** The grid the host observed from the environment (`COLUMNS` / `LINES`), so the renderer
   * starts with a plausible geometry before its first resize event. Absent when the host has
   * no terminal of its own. */
  readonly terminalSize?: { readonly width: number; readonly height: number }
}

/** Negotiation status, shared with plugin-spec admission vocabulary. */
export type NegotiationStatus = 'compatible' | 'compatible_degraded' | 'waiting_authorization' | 'rejected' | 'unknown'

/** Host → renderer: full transcript plus the state the shell shows around it. */
export interface SessionSnapshotPayload {
  readonly sessionId: string
  readonly initialRoute: 'home' | 'session'
  readonly readOnly?: boolean
  readonly parentId?: string
  readonly title: string
  readonly events: readonly TranscriptEvent[]
  readonly provider: string
  readonly model: string
  readonly effort: string
  readonly permission: string
  readonly preset: string
  readonly workspace?: string
  readonly availableActions: readonly string[]
  readonly attachmentCapabilities: { readonly files: boolean; readonly images: boolean }
  /** The usage projection for this exact session. Sent with the snapshot so a resumed
   * or freshly attached renderer paints token/cache/context data before the next live
   * status update arrives. */
  readonly usage?: UsagePayload
}

/** Host → renderer: a route-only update. Unlike `session-snapshot`, this never resets
 * the transcript, catalogs, tabs, or draft state; model/effort picks use it so switching
 * a model cannot rebuild the whole page. */
export interface SelectionStatePayload {
  readonly sessionId: string
  readonly provider: string
  readonly model: string
  readonly effort: string
  /** Present only when the permission preset itself changed. */
  readonly permission?: string
  /** Present only when the agent preset itself changed. */
  readonly preset?: string
  readonly attachmentCapabilities?: { readonly files: boolean; readonly images: boolean }
  /** Capability list can change when terminal setup finishes after the first frame. */
  readonly availableActions?: readonly string[]
}

/** Host → renderer: one append/replace delta against the transcript. */
export interface SessionFramePayload {
  readonly sessionId: string
  readonly events: readonly TranscriptEvent[]
}

/** Host → renderer: the complete logical session catalog. */
export interface SessionListPayload {
  readonly sessions: readonly {
    readonly id: string
    readonly title: string
    readonly active: boolean
    readonly workspace?: string
    readonly parentId?: string
    readonly sessionKind?: 'main' | 'subagent'
    readonly canInteract?: boolean
    readonly createdAt: number
    /** Final event time; omitted when the backend cannot cheaply provide one. */
    readonly lastActivityAt?: number
    readonly status: 'idle' | 'running'
    readonly attention: boolean
    /**
     * The session never got past its setup events: no user or assistant message and no tool
     * call. Every terminal start materializes one, and the desktop client hides them, so the
     * lists here hide them too — except the current one, which is the live "New Session" the
     * user is looking at.
     */
    readonly blank?: boolean
  }[]
  readonly current: string
}

/** Host → renderer: the model picker contents for one session. */
export interface ModelCatalogPayload {
  readonly sessionId: string
  readonly models: readonly { readonly provider: string; readonly model: string; readonly label: string; readonly current: boolean }[]
}

/** Host → renderer: provider rows for the settings page. */
export interface ProviderCatalogPayload {
  readonly providers: readonly { readonly id: string; readonly label: string; readonly api: string; readonly baseURL?: string }[]
}

/** Host → renderer: effort levels for one session's current model. */
export interface ReasoningEffortsPayload {
  readonly sessionId: string
  readonly efforts: readonly string[]
  readonly current: string
}

/** Host → renderer: workspace paths relative to one session's workspace. */
export interface WorkspaceFilesPayload {
  readonly sessionId: string
  readonly files: readonly string[]
}

/** Host → renderer: deployed permission presets for one session. */
export interface PermissionPresetsPayload {
  readonly sessionId: string
  readonly presets: readonly { readonly id: string; readonly label: string; readonly current: boolean }[]
}

/** Host → renderer: deployed agent presets for one session. */
export interface AgentPresetsPayload {
  readonly sessionId: string
  readonly presets: readonly { readonly id: string; readonly label: string; readonly current: boolean }[]
}

/** Host → renderer: the live settings section, plus the schema version. The agent-loop
 * namespace is carried separately: its fields are not TUI fields, and the renderer writes
 * them back with `ns` on `update-settings`. */
export interface SettingsPayload {
  /** The settings section this row owns; the renderer's config adapter keys by it. */
  readonly ns: string
  readonly schemaVersion: number
  readonly values: Record<string, unknown>
  readonly agentLoop?: { readonly maxParallelToolCalls?: number }
  /** The answered `update-settings` request; absent on the initial and subscribed pushes. */
  readonly requestId?: string
  /** The write failure the answered request reports; absent on success. */
  readonly error?: string
}

/** Host → renderer: locale and the strings the renderer draws. */
export interface I18nPayload {
  readonly locale: string
  readonly strings: Record<string, string>
}

/**
 * Renderer → host: the terminal's color scheme, detected from the terminal's
 * default background (OpenTUI's `getPalette`). In `dynamic` theme mode the host
 * answers by sending the dark or light member of the configured pair.
 */
export interface TerminalSchemePayload {
  readonly scheme: 'dark' | 'light'
}

/**
 * Renderer → host: the terminal's cell geometry. The renderer owns the TTY, so it is the
 * only side that can measure the grid; it sends the size once at startup and again on every
 * resize. The host keeps the latest value for its own layout decisions (transcript line
 * caps, plugin layout) and echoes the size it observed from the environment in `hello-ack`,
 * so the renderer starts with a plausible geometry before its first resize event.
 */
export interface TerminalSizePayload {
  readonly width: number
  readonly height: number
}

/** Host → renderer: the outcome of an upstream command request. */
export interface CommandResultPayload {
  readonly seq: number
  readonly ok: boolean
  readonly value?: unknown
  readonly text?: string
  readonly error?: string
}

/** Host → renderer: the user's answer to a renderer-initiated dialog. */
export interface DialogResponsePayload {
  readonly seq: number
  readonly value: unknown
}

/** Host → renderer: a plugin-owned dialog the renderer draws; the answer rides
 * `extension-dialog-response` on the same request id. */
export interface ExtensionDialogPayload {
  readonly requestId: number
  readonly kind: 'select' | 'confirm' | 'input'
  readonly title: string
  readonly options?: readonly { id: string; label: string; description?: string }[]
  readonly confirmLabel?: string
  readonly cancelLabel?: string
  readonly initial?: string
  readonly placeholder?: string
}

/** Renderer → host: the answer to an extension dialog. `value` is the picked option
 * id, the confirm boolean as `'yes'`/`'no'`, or the input text. */
export interface ExtensionDialogResponsePayload {
  readonly requestId: number
  readonly value: string | undefined
}

/** Renderer → host: a keypress the renderer's keymap did not consume, normalized to
 * the canonical combo (`ctrl+o`, `shift+ctrl+p`). The host matches it against the
 * plugin shortcut registrations and dispatches a hit. */
export interface ShortcutPayload {
  readonly combo: string
}

/** Host → renderer: a notice to draw in the console overlay. */
export interface BootNoticePayload {
  readonly kind: 'info' | 'warning' | 'error'
  readonly text: string
}

/** Host → renderer: a dsh-side log line (dsh stdout is routed away from the TTY). */
export interface LogPayload {
  readonly level: 'info' | 'warn' | 'error'
  readonly text: string
}

/** Host → renderer: whether a turn is running in one session. */
export interface TurnStatePayload {
  readonly sessionId: string
  readonly running: boolean
}

/** Host → renderer: the slash command registry for one session. */
export interface CommandCatalogPayload {
  readonly sessionId: string
  readonly commands: readonly { readonly name: string; readonly description: string; readonly argumentHint?: string }[]
}


/** Renderer → host: cancel a queued interjection owned by exactly one session. */
export interface InterjectEditPayload {
  readonly sessionId: string
  readonly id?: string
}

/** Renderer → host: delete one queued message by id in the exact session inbox. */
export interface InterjectDeletePayload {
  readonly sessionId: string
  readonly id: string
}

/** Renderer → host: read one durable attachment reference authorized by a session log. */
export interface AttachmentReadPayload {
  readonly sessionId: string
  readonly attachment: unknown
}

/**
 * Host → renderer: one WeChat bridge output line. The bridge owns the login state
 * machine; `qr` carries the scannable ASCII block, `status` the one-line bridge
 * state, `log` and `error` the console text. The renderer draws `qr` as a
 * borderless monospace block so the scan is not disturbed by card borders,
 * matching the 0.4.0 TUI's rule.
 */
export interface WechatOutputPayload {
  readonly kind: 'log' | 'qr' | 'error' | 'status'
  readonly text: string
  /** Present on `status`: the same state as structure, so the pane never splits ` · `. */
  readonly status?: WechatStatusPayload
}

/** One attachment admitted with a submitted user message. Data is canonical base64. */
export type SubmittedAttachment =
  | { readonly type: 'image'; readonly mediaType: 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif'; readonly data: string; readonly name?: string }
  | { readonly type: 'file'; readonly data: string; readonly name?: string }

/** Renderer → host: submit a prompt to one exact session. */
export interface SendMessagePayload {
  readonly sessionId: string
  readonly text: string
  readonly delivery: 'steer' | 'queue'
  readonly attachments?: readonly SubmittedAttachment[]
  readonly skills?: readonly string[]
}

/** Renderer → host: exact session lifecycle request. */
export interface SessionOpPayload {
  readonly op: 'new' | 'switch' | 'rename' | 'fork' | 'read'
  readonly sessionId?: string
  readonly title?: string
  readonly boundary?: number
  readonly cwd?: string
  readonly selection?: {
    readonly provider: string
    readonly model: string
    readonly effort?: string
    readonly preset: string
    readonly permission?: string
  }
}

/** Renderer → host: change the selection of one exact session. */
export interface SelectionPayload {
  readonly sessionId: string
  readonly provider?: string
  readonly model?: string
  readonly effort?: string
  readonly permission?: string
  readonly preset?: string
}

/** Renderer → host: write settings fields through the host's settings seam. `ns` selects
 * the namespace; the default is the TUI namespace, and `agent-loop` carries the harness
 * fields that are not TUI settings (the parallel tool call cap). */
export interface UpdateSettingsPayload {
  readonly requestId: string
  readonly patch: Record<string, unknown>
  readonly ns?: 'tui' | 'agent-loop'
}

/** Renderer → host: ask the host to show a harness-owned dialog (provider form). */
export interface DialogRequestPayload {
  readonly kind: string
  readonly args?: Record<string, unknown>
}

/**
 * One field of a harness-owned form the renderer draws.
 *
 * The host owns the field list: it reads the current draft through its own settings
 * seam and sends the values down. `secret` marks a credential field so the renderer
 * masks it; `select` carries the accepted values in `options`. There is no multi-line
 * field: OpenTUI's `textarea` maps neither `value` nor `onInput` through the solid
 * reconciler (only `initialValue` and `onSubmit` are accessors), so a list field is
 * one line with the items separated by spaces.
 */
export interface FormFieldSpec {
  readonly key: string
  readonly label: string
  readonly kind: 'text' | 'secret' | 'select' | 'action'
  readonly value: string
  readonly options?: readonly string[]
  /** The value is long (the provider model catalog is one line per model): the
   * renderer draws it as a multi-line textarea instead of a single-line input. */
  readonly multiline?: boolean
}

/**
 * Host → renderer: the form to draw. The renderer collects the values and sends them
 * back as `form-submit`; the host writes them through its own seam, so the provider
 * id rules, the credential reference, and the settings mutations stay in the host.
 */
export interface FormSpecPayload {
  readonly form: string
  readonly title: string
  readonly fields: readonly FormFieldSpec[]
}

/** Renderer → host: the completed form values. */
export interface FormSubmitPayload {
  readonly form: string
  readonly values: Record<string, string>
}

/**
 * Renderer → host: run the provider model discovery probe with the form's current values.
 *
 * The probe is the host's (`ctx.llm.discoverModels` plus the provider's discovery namespace
 * lookup and the credential rules), so the renderer sends the field values it has on screen
 * and receives the merged line back. An `action` field in `form-spec` is what triggers this:
 * the renderer's form has no button, so a row whose kind is `action` sends the current values
 * on Enter instead of submitting the form.
 */
export interface ModelDiscoverPayload {
  readonly form: string
  readonly fields: Record<string, string>
}

/**
 * Host → renderer: the models the provider form's current line carries, for the nested
 * per-model editor. The host parses the flat line (`id|name|level=wire;...|effort|context|max`),
 * so the encoding rules stay in the host; the renderer only shows `id` and a label.
 */
export interface ModelListPayload {
  readonly form: string
  readonly models: readonly { readonly id: string; readonly label: string }[]
}

/**
 * Renderer → host: ask for the model list of the provider form's current values. The
 * renderer has no button primitive, so this is an `action` row in the field list: Enter
 * sends the form's current values up and keeps the form open.
 */
export interface ModelListRequestPayload {
  readonly form: string
  readonly fields: Record<string, string>
}

/**
 * Renderer → host: the model picked in the list, plus the line it came from. The host
 * answers with a `form-spec` for that model (name / efforts / effort / context / max),
 * and the model form's submit merges the edited fields back into the line the request
 * carried, so the merge happens against the values the renderer has on screen.
 */
export interface ModelEditPayload {
  readonly form: string
  readonly id: string
  readonly models: string
}

/**
 * Host → renderer: the models field after the probe merged the provider's published ids
 * into it, or after a nested per-model edit. The value is the host's flat encoding
 * (`id|name|level=wire;...|effort|context|max`, models separated by spaces), so the
 * encoding rules stay in the host and the renderer only replaces the field's value.
 */
export interface ModelDiscoveryPayload {
  readonly form: string
  readonly models: string
}

/**
 * Renderer → host: a WeChat bridge command. `op` is the command suffix after
 * `/wechat-` (`login` / `status` / `pair` / `allow` / `deny` / `list` / `logout` /
 * `notify` / `config`); the host builds the line and runs it through its own
 * command path, so the bridge's argument parsing and the command registry's
 * unknown-command rejection stay in one place. The bridge pushes its output back
 * as `wechat-output`.
 */
export interface WechatOpPayload {
  readonly op: string
  readonly arg?: string
}

/**
 * Host → renderer: the subagents the session has spawned.
 *
 * The pi-tui path keeps a panel fed by `subagent/descriptor` session events. The
 * renderer gets the same list from the same events, so the two paths cannot disagree
 * about which subagents exist.
 */
export interface SubagentDescriptor {
  readonly label: string
  readonly provider: string
  readonly mode: 'one-shot' | 'continuable'
}

export interface SubagentListPayload {
  readonly sessionId: string
  readonly agents: readonly SubagentDescriptor[]
}

/**
 * Host → renderer: the skills the workspace snapshot carries.
 *
 * The renderer's palette already lists `skill:` commands from the command catalog, so
 * this list is what the palette's skills category shows: the name and the description the
 * host read from `ctx.skills.snapshot`.
 */
export interface SkillSpec {
  readonly name: string
  readonly description: string
}

export interface SkillsListPayload {
  readonly sessionId: string
  readonly skills: readonly SkillSpec[]
}

/**
 * Host → renderer: the session's token usage and context occupancy.
 *
 * The numbers come from `ctx.tokenMeter.measure(session).totalTokens` (the measured
 * context), `session.requestContext().contextWindow` when the recorded provider/model
 * match the current selection, and the running `tokenTotals` the footer already reads.
 * `cost` is a host-side local estimate from `~/.config/.mydpsk/price.json` and `custom_price.json`; when the
 * model is not priced it stays undefined and the renderer shows `$ —`, never `$0.00`.
 */
export interface UsagePayload {
  readonly sessionId: string
  readonly inputTokens: number
  readonly outputTokens: number
  readonly cacheReadTokens?: number
  readonly cacheWriteTokens?: number
  /** At least one sample explicitly reported cache-read tokens. */
  readonly cacheReadObserved?: boolean
  readonly cacheReadComplete?: boolean
  readonly cacheWriteComplete?: boolean
  readonly cacheBucketsComplete?: boolean
  readonly contextTokens?: number
  readonly contextWindow?: number
  readonly contextPct?: number
  readonly cost?: number
  /** ISO-4217 code the host priced `cost` in (`CNY` → `¥`). */
  readonly currency?: string
  /** Where `cost` came from: the provider's own bill, its unit prices, or our local table. */
  readonly costSource?: 'upstream-bill' | 'upstream-price' | 'local' | 'none'
  /** True when at least one folded sample had no resolvable model price. */
  readonly costUnavailable?: boolean
}

/** Host → renderer: the branch for one session's workspace. */
export interface GitBranchPayload {
  readonly sessionId: string
  readonly branch?: string
}

/** One configured MCP client entry. Credentials and full config never cross IPC. */
/** The MCP client's lifecycle phase, as the Loader reports it. */
export type McpLifecycleStatus = 'loading' | 'active' | 'pending' | 'unloading' | 'failed'

export interface McpServerItem {
  readonly id: string
  readonly name: string
  /** The real loader phase; absent means "not reported", never "connected". */
  readonly status?: McpLifecycleStatus | null
}

/**
 * Host → renderer: the WeChat bridge's state as structure. The pane paints the connection
 * and the receiver lock on separate rows, so the host must not pre-join them into one string.
 */
export interface WechatStatusPayload {
  readonly available: boolean
  readonly connected: boolean
  readonly accounts: { readonly connected: number; readonly total: number }
  readonly lock: { readonly held: boolean; readonly pid?: number }
}

export interface McpServersPayload {
  readonly servers: readonly McpServerItem[]
}

/** One real Loader plugin entry projected by dsh-host-plugin-inventory. */
export interface HostPluginItem {
  readonly id: string
  readonly moduleName: string
  readonly enabled: boolean
  readonly fiberPhase: 'pending' | 'loading' | 'active' | 'failed' | 'unloading' | null
}

export interface HostPluginsPayload {
  readonly plugins: readonly HostPluginItem[]
}

/** Host → renderer: the session's todo list, forwarded from `todo/write` session events. */
export interface TodoItem {
  readonly content: string
  readonly status: string
}

export interface TodosPayload {
  readonly sessionId: string
  readonly items: readonly TodoItem[]
}

export interface ShellJobView {
  readonly id: string
  readonly kind: string
  readonly label: string
  readonly owner?: string
  readonly outputLimitBytes?: number
  readonly status: 'running' | 'stopping' | 'completed' | 'killed' | 'failed'
  readonly progress?: string
  readonly detail?: string
  readonly startedAt: number
  readonly finishedAt?: number
  readonly output: { readonly total: number; readonly earliest: number; readonly spillPaths?: readonly string[] }
}

export interface ShellJobsPayload {
  readonly sessionId: string
  readonly jobs: readonly ShellJobView[]
}

export interface ShellJobOpPayload {
  readonly sessionId: string
  readonly id: string
  readonly op: 'read' | 'kill'
  readonly from?: number
}

export interface TerminalShellInfo {
  readonly path: string
  readonly args: readonly string[]
  readonly name: string
}

export interface TerminalEnvironmentInfo {
  readonly cwd: string
  readonly maxInputBytes: number
  readonly maxCols: number
  readonly maxRows: number
  readonly scrollback: number
}

export interface WebTerminalInfo {
  readonly id: string
  readonly title: string
  readonly shell: TerminalShellInfo
  readonly cwd: string
  readonly cols: number
  readonly rows: number
  readonly state: 'running' | 'exited' | 'failed'
  readonly exitCode: number | null
  readonly error?: string
  readonly controllerId?: string
}

export type TerminalFrame =
  | { readonly type: 'snapshot'; readonly sequence: number; readonly screen: string; readonly info: WebTerminalInfo }
  | { readonly type: 'output'; readonly sequence: number; readonly data: string }
  | { readonly type: 'state'; readonly info: WebTerminalInfo }

export type TerminalOpPayload =
  | { readonly sessionId: string; readonly op: 'list' }
  | { readonly sessionId: string; readonly op: 'create'; readonly id: string; readonly cols: number; readonly rows: number; readonly shellPath?: string }
  | { readonly sessionId: string; readonly op: 'retain'; readonly id: string; readonly attachmentId: string }
  | { readonly sessionId: string; readonly op: 'release'; readonly id: string; readonly attachmentId: string }
  | { readonly sessionId: string; readonly op: 'follow'; readonly id: string; readonly attachmentId: string }
  | { readonly sessionId: string; readonly op: 'detach'; readonly id: string; readonly attachmentId: string }
  | { readonly sessionId: string; readonly op: 'write'; readonly id: string; readonly attachmentId: string; readonly data: string }
  | { readonly sessionId: string; readonly op: 'resize'; readonly id: string; readonly attachmentId: string; readonly cols: number; readonly rows: number }
  | { readonly sessionId: string; readonly op: 'close'; readonly id: string }

export interface TerminalFramePayload {
  readonly sessionId: string
  readonly id: string
  readonly attachmentId: string
  readonly frame: TerminalFrame
}

export interface TerminalEndPayload {
  readonly sessionId: string
  readonly id: string
  readonly attachmentId: string
  readonly error?: string
}

/** One queued user message the host can address in the exact session inbox. */
export interface InterjectionItem {
  readonly id: string
  readonly text: string
}

/** Host → renderer: pending messages owned by one session. */
export interface InterjectListPayload {
  readonly sessionId: string
  readonly items: readonly InterjectionItem[]
}

/**
 * Host → renderer: a user-questions request the renderer must ask the human.
 *
 * The host's `user-questions/request` handler blocks until the answer arrives, so
 * the request carries a `request` id the answer is correlated by. `questions` is the
 * dsh shape narrowed to what the renderer draws: the question text, an optional short
 * heading, and the option labels.
 */
export interface QuestionSpec {
  readonly id: string
  readonly question: string
  readonly header?: string
  readonly detail?: string
  readonly multiSelect?: boolean
  readonly intent?: { readonly kind: 'plan-review'; readonly approve: string; readonly callId?: string }
  readonly options?: readonly { readonly label: string; readonly description?: string }[]
}

export interface QuestionRequestPayload {
  readonly request: string
  readonly sessionId: string
  readonly ownerSessionId?: string
  readonly state: 'open' | 'continued'
  readonly callId?: string
  readonly remainingMs?: number
  readonly questions: readonly QuestionSpec[]
}

export interface QuestionTimeoutPayload {
  readonly request: string
}

export interface QuestionAnswerItem {
  readonly id: string
  readonly selected: readonly string[]
  readonly custom?: string
}

export interface QuestionAnswerPayload {
  readonly request: string
  readonly answers?: readonly QuestionAnswerItem[]
  readonly cancelled?: true
}

export interface QuestionClosePayload {
  readonly request: string
}

export interface QuestionResultPayload {
  readonly request: string
  readonly ok: boolean
  readonly error?: string
}

export interface ApprovalRequestPayload {
  readonly request: string
  readonly sessionId: string
  readonly ownerSessionId?: string
  readonly toolName: string
  readonly callId?: string
  readonly reason?: string
}

export interface ApprovalClosePayload {
  readonly request: string
}

export interface ApprovalAnswerPayload {
  readonly request: string
  readonly outcome: 'allowed-once' | 'rejected'
}

/** Renderer → host: `/doctor` and `/plugins` requests. */
export interface DoctorPayload {
  readonly op: 'doctor' | 'plugins'
}

/** Both directions: shut the channel down. Carries no payload content. */
export interface ByePayload {
  readonly reason?: string
}

/** Renderer → host: end the core process deliberately, distinct from detaching the TUI. */
export interface ShutdownPayload {
  readonly reason?: string
}

/** Renderer → host: change OS launch-at-login registration for the core. */
export interface AutostartOpPayload {
  readonly enabled: boolean
}

/** Renderer → host: interrupt one exact session's running turn. */
export interface InterruptPayload {
  readonly sessionId: string
}

/** The kinds the host sends. The renderer must understand every one it receives. */
export const DOWNSTREAM_KINDS = [
  'hello-ack',
  'session-snapshot',
  'selection-state',
  'session-frame',
  'session-list',
  'model-catalog',
  'provider-catalog',
  'reasoning-efforts',
  'workspace-files',
  'permission-presets',
  'agent-presets',
  'settings',
  'i18n',
  'command-result',
  'command-catalog',
  'dialog-response',
  'extension-dialog',
  'boot-notice',
  'turn-state',
  'wechat-output',
  'form-spec',
  'question-request',
  'question-close',
  'question-result',
  'approval-request',
  'approval-close',
  'subagent-list',
  'skills-list',
  'usage',
  'git-branch',
  'mcp-servers',
  'host-plugins',
  'todos',
  'shell-jobs',
  'interject-list',
  'model-discovery',
  'model-list',
  'log',
  'bye',
  'terminal-frame',
  'terminal-end',
] as const

/** The kinds the renderer sends. The host must understand every one it receives. */
export const UPSTREAM_KINDS = [
  'hello',
  'send-message',
  'interject-edit',
  'interject-delete',
  'shell-job-op',
  'attachment-read',
  'session-op',
  'set-selection',
  'update-settings',
  'dialog-request',
  'shortcut',
  'extension-dialog-response',
  'form-submit',
  'model-discover',
  'model-list-request',
  'model-edit',
  'question-answer',
  'approval-answer',
  'wechat-op',
  'doctor-check',
  'terminal-scheme',
  'terminal-size',
  'bye',
  'shutdown',
  'autostart-op',
  'terminal-op',
  'question-timeout',
  'interrupt',
] as const

export type DownstreamKind = (typeof DOWNSTREAM_KINDS)[number]
export type UpstreamKind = (typeof UPSTREAM_KINDS)[number]

/**
 * Kind → payload interface name, declared in this module. `verify:ipc-protocol`
 * checks that every registered kind names an interface that exists in this file,
 * so a kind cannot be added without a documented payload shape.
 */
export const KIND_PAYLOAD_NAMES: Record<string, string> = {
  'hello': 'HelloPayload',
  'hello-ack': 'HelloAckPayload',
  'session-snapshot': 'SessionSnapshotPayload',
  'selection-state': 'SelectionStatePayload',
  'session-frame': 'SessionFramePayload',
  'session-list': 'SessionListPayload',
  'model-catalog': 'ModelCatalogPayload',
  'provider-catalog': 'ProviderCatalogPayload',
  'reasoning-efforts': 'ReasoningEffortsPayload',
  'workspace-files': 'WorkspaceFilesPayload',
  'permission-presets': 'PermissionPresetsPayload',
  'agent-presets': 'AgentPresetsPayload',
  'settings': 'SettingsPayload',
  'i18n': 'I18nPayload',
  'command-result': 'CommandResultPayload',
  'command-catalog': 'CommandCatalogPayload',
  'dialog-response': 'DialogResponsePayload',
  'extension-dialog': 'ExtensionDialogPayload',
  'form-spec': 'FormSpecPayload',
  'model-discovery': 'ModelDiscoveryPayload',
  'model-list': 'ModelListPayload',
  'question-request': 'QuestionRequestPayload',
  'question-close': 'QuestionClosePayload',
  'question-result': 'QuestionResultPayload',
  'approval-request': 'ApprovalRequestPayload',
  'approval-close': 'ApprovalClosePayload',
  'approval-answer': 'ApprovalAnswerPayload',
  'subagent-list': 'SubagentListPayload',
  'skills-list': 'SkillsListPayload',
  'usage': 'UsagePayload',
  'git-branch': 'GitBranchPayload',
  'mcp-servers': 'McpServersPayload',
  'host-plugins': 'HostPluginsPayload',
  'todos': 'TodosPayload',
  'interject-list': 'InterjectListPayload',
  'shell-jobs': 'ShellJobsPayload',
  'terminal-frame': 'TerminalFramePayload',
  'terminal-end': 'TerminalEndPayload',
  'boot-notice': 'BootNoticePayload',
  'turn-state': 'TurnStatePayload',
  'wechat-output': 'WechatOutputPayload',
  'log': 'LogPayload',
  'send-message': 'SendMessagePayload',
  'interject-edit': 'InterjectEditPayload',
  'interject-delete': 'InterjectDeletePayload',
  'attachment-read': 'AttachmentReadPayload',
  'shell-job-op': 'ShellJobOpPayload',
  'session-op': 'SessionOpPayload',
  'set-selection': 'SelectionPayload',
  'update-settings': 'UpdateSettingsPayload',
  'dialog-request': 'DialogRequestPayload',
  'extension-dialog-response': 'ExtensionDialogResponsePayload',
  'shortcut': 'ShortcutPayload',
  'form-submit': 'FormSubmitPayload',
  'model-discover': 'ModelDiscoverPayload',
  'model-list-request': 'ModelListRequestPayload',
  'model-edit': 'ModelEditPayload',
  'question-answer': 'QuestionAnswerPayload',
  'wechat-op': 'WechatOpPayload',
  'doctor-check': 'DoctorPayload',
  'terminal-scheme': 'TerminalSchemePayload',
  'terminal-size': 'TerminalSizePayload',
  'bye': 'ByePayload',
  'shutdown': 'ShutdownPayload',
  'autostart-op': 'AutostartOpPayload',
  'terminal-op': 'TerminalOpPayload',
  'question-timeout': 'QuestionTimeoutPayload',
  'interrupt': 'InterruptPayload',
}

/** Kinds the receiving side may not understand; negotiation degrades to a warning. */
export const OPTIONAL_DOWNSTREAM_KINDS: readonly DownstreamKind[] = ['log', 'dialog-response', 'i18n', 'wechat-output', 'form-spec', 'question-request', 'subagent-list', 'skills-list', 'model-discovery', 'model-list']
export const OPTIONAL_UPSTREAM_KINDS: readonly UpstreamKind[] = ['dialog-request', 'form-submit', 'question-answer', 'wechat-op', 'doctor-check', 'model-discover', 'model-list-request', 'model-edit']

/** Capabilities the renderer declares; the host sends matching data. */
export const RENDERER_CAPABILITIES = ['transcript', 'composer', 'dialog', 'scrollbar', 'mouse'] as const
/** Capabilities the host declares; the renderer must be able to consume them. Each entry
 * names a data surface the host actually pushes down or a request it answers upstream. */
export const HOST_CAPABILITIES = ['session-events', 'model-catalog', 'provider-catalog', 'permission-presets', 'agent-presets', 'settings-write', 'wechat-bridge', 'doctor', 'i18n', 'subagents', 'skills', 'interjection', 'terminal-size'] as const
