/**
 * Persistent settings namespaces used by the TUI and the title provider.
 *
 * dsh 0.2 has no runtime settings registration: a settings section is the live
 * Config of a profile entry, keyed by that entry's row id. Both namespaces
 * below name rows this bundle inserts through `cordis.patch.yml`.
 *
 * 0.5.0 renames the rows (`tui` → `dpsk-tui`, `session-title-llm-tui` →
 * `dpsk-session-title`); `src/settings-migrate.ts` moves values written under
 * the old row ids once at activation.
 */

import { settingsNamespace } from './dsh-host/index.ts'

/** The `dpsk-tui` row: theme, prompt templates, keybindings and card settings. */
export const TUI_SETTINGS_NAMESPACE = settingsNamespace('dpsk-tui')

/**
 * The `agent-default-model` row: the route a *new* session starts from. dsh ships its own
 * `saveSelection()` for it, but that path silently returns when the deployment has no
 * `configEditor` service — which is why a picked model never became the default here.
 * Writing the row through the settings service is the path `/settings` already proves
 * works, so the model the user left the TUI with is the one the next session opens with.
 */
export const AGENT_DEFAULT_MODEL_NAMESPACE = settingsNamespace('agent-default-model')

/** Row id that carried TUI settings before 0.5.0; read-only compatibility source. */
export const LEGACY_TUI_SETTINGS_ROW = 'tui'

export type ThemeModeSetting = 'system' | 'dark' | 'light'

/**
 * Theme and prompt settings the TUI persists. These fields are part of the
 * `tui` row's Config schema (`TuiConfigSchema`), so the row's live Config is
 * the settings section.
 *
 * The native theme provider owns the theme catalog and the resolved tokens; the
 * host only stores the selection (`themeName` / `themeMode`) and the experiment flag.
 */
export interface TuiSettings {
  /** Native theme id (`opencode`, `opencode2`, a discovered file, or `system`). */
  themeName?: string
  /** `system` follows the terminal; `dark` / `light` pin one mode. */
  themeMode?: ThemeModeSetting
  /** New compact thinking/tool transcript presentation. */
  newDesigns?: boolean
  /** `tilde` shortens paths below the user's home; `full` paints the absolute path. */
  pathDisplay?: 'tilde' | 'full'
  /** Template rendered left-aligned beside the permission state below the editor. */
  leftPrompt?: string
  /** Template rendered below the directory and permission row. */
  rightPrompt?: string
  /** Keybinding for cycling tool cards. */
  keyTools?: string
  /** Keybinding for toggling reasoning blocks. */
  keyReasoning?: string
  /** Leader window length in milliseconds (opencode v2 `leader_timeout`). */
  leaderTimeout?: number
  /** Raw keybind table imported from `cli.json`, keyed by opencode command id. */
  keybinds?: Record<string, string>
  /** Scroll wheel speed (opencode v2 `scroll_speed`). */
  scrollSpeed?: number
  /** Accelerated scrolling (opencode v2 `scroll_acceleration`). */
  scrollAcceleration?: boolean
  /** System notifications on a finished turn (`attention.notifications`); default off. */
  attentionNotifications?: boolean
  /** Attention sound on a finished turn (`attention.sound`); default off. */
  attentionSound?: boolean
  /** Attention volume, 0–1 (`attention.volume`); default 0.4. */
  attentionVolume?: number
  /** Animations (`animations`): false paints the still spinner frame. */
  animations?: boolean
  /** Diff rendering style (opencode v2 `diff_style`). */
  diffStyle?: string
  /** Cursor style (opencode v2 `cursor`). */
  cursor?: string
  /** Mouse capture on/off (opencode v2 `mouse`). */
  mouse?: boolean
  /** Set once the `cli.json` import ran, so a restart does not import twice. */
  cliImportedAt?: string
  /** Whether model reasoning blocks are rendered. */
  showReasoning: boolean
  /** Maximum tool-card body lines retained in a collapsed preview. */
  maxToolOutputLines: number
}

/**
 * The patch that makes `selection` the default for the next session.
 *
 * `provider` and `model` are required by the row schema; `reasoningEffort` is optional and
 * only written when the route has one.
 */
export function defaultModelPatch(selection: {
  readonly provider: string
  readonly model: string
  readonly reasoningEffort?: string | undefined
}): Record<string, string> {
  return {
    provider: selection.provider,
    model: selection.model,
    ...(selection.reasoningEffort === undefined ? {} : { reasoningEffort: String(selection.reasoningEffort) }),
  }
}

/**
 * Persist the route as the default for the next session.
 *
 * dsh's own `agentDefaultModel.saveSelection()` writes through the loader's
 * `configEditor` and returns silently when that service is missing, so a pick updated the
 * session but never the default (the profile kept its original model). The settings service
 * is the seam `/settings` already writes through, and its write lands in the profile patch
 * layer, so "the model I left with" survives the restart.
 */
export async function saveDefaultModel(
  settings: { update: (ns: string, patch: Record<string, string>) => Promise<unknown> } | undefined,
  selection: { readonly provider: string; readonly model: string; readonly reasoningEffort?: string | undefined },
): Promise<void> {
  if (settings === undefined) return
  await settings.update(AGENT_DEFAULT_MODEL_NAMESPACE, defaultModelPatch(selection))
}

/** The `dpsk-session-title` row: title model route plus generation limits. */
export const SESSION_TITLE_SETTINGS_NAMESPACE = settingsNamespace('dpsk-session-title')

/** Row id that carried title settings before 0.5.0; read-only compatibility source. */
export const LEGACY_SESSION_TITLE_ROW = 'session-title-llm-tui'
