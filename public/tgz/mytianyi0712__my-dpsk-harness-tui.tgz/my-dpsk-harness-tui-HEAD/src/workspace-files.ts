/**
 * The workspace index the renderer's `@` completion reads.
 *
 * Upstream's `filesystem.list` walks the Session directory and returns paths relative to
 * it, directories first with a trailing `/`. The renderer never walks the disk: the host
 * owns this list and pushes it as `workspace-files`, so a mention can only name a path
 * that is really in the workspace.
 *
 * The walk is bounded (depth, entry count) and skips `.git` and `node_modules`: an index of
 * the whole workspace is an input aid, not a file browser, and an unbounded walk over a
 * checkout with a dependency tree would stall the host.
 */

import { readdir } from 'node:fs/promises'
import { join } from 'node:path'

/** Directories the walk never descends into. */
const SKIPPED_DIRECTORIES = new Set(['.git', 'node_modules'])

/** Depth limit below the workspace root (upstream stops at nested project directories). */
const MAX_DEPTH = 6

/** Entry limit; the walk stops once the list is this long. */
const MAX_ENTRIES = 2000

/** Sort directories before files, then by name, as upstream's list does. */
function compareEntries(left: { name: string; directory: boolean }, right: { name: string; directory: boolean }): number {
  if (left.directory !== right.directory) return left.directory ? -1 : 1
  return left.name.localeCompare(right.name)
}

/**
 * Index a workspace. Paths are `/`-separated and relative to `root`; a directory carries a
 * trailing `/`. A read error on the root rejects, so the caller reports a real failure; an
 * unreadable subdirectory is skipped, because a partial index is still a useful one.
 */
export async function listWorkspaceFiles(root: string): Promise<string[]> {
  const files: string[] = []
  const walk = async (directory: string, relative: string, depth: number): Promise<void> => {
    if (files.length >= MAX_ENTRIES) return
    const entries = await readdir(directory, { withFileTypes: true })
    const rows = entries
      .filter(entry => !SKIPPED_DIRECTORIES.has(entry.name))
      .map(entry => ({ name: entry.name, directory: entry.isDirectory(), symlink: entry.isSymbolicLink() }))
      .sort(compareEntries)
    for (const row of rows) {
      if (files.length >= MAX_ENTRIES) return
      const path = relative === '' ? row.name : `${relative}/${row.name}`
      // A symlink is listed as an entry but never followed: the walk must not leave the tree.
      if (row.directory && !row.symlink) {
        files.push(`${path}/`)
        if (depth < MAX_DEPTH) await walk(join(directory, row.name), path, depth + 1).catch(() => undefined)
        continue
      }
      if (row.symlink) continue
      files.push(path)
    }
  }
  await walk(root, '', 0)
  return files
}
