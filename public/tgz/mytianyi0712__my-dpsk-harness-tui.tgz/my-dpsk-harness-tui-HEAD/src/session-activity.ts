/**
 * Session ordering by last interaction.
 *
 * `SessionHeader.createdAt` is immutable and cannot answer "where is the conversation I
 * just used?". The host derives last activity from the newest meaningful interaction
 * event, not from whichever bookkeeping event happened to be appended last. Ordering is
 * centralized here so the tab strip, `/sessions`, and the `/resume` picker cannot disagree.
 */

import type { SessionId, SessionPersistence, SessionPersistenceSnapshot, SessionSeq } from './dsh-host/index.ts'

export interface ActivitySortable {
  readonly id: string
  readonly createdAt: number
  readonly lastActivityAt?: number
}

/** How many tail events to inspect for a real interaction before falling back to createdAt. */
export const ACTIVITY_TAIL_EVENTS = 128

/**
 * Events that represent a user/model interaction. `session/end-seed`, `session/title`,
 * `workspace/changes`, permissions and other bookkeeping are deliberately excluded: they
 * can be appended during restart/replay and must not make an old conversation look fresh.
 */
const INTERACTION_EVENT_TYPES = new Set<string>([
  'user/message',
  'assistant/message',
  'assistant/attempt',
  'tool/call',
  'tool/result',
  'turn/start',
  'turn/end',
  'command/run',
  'command/done',
])

export function isInteractionActivity(
  event: { readonly type?: string; readonly time?: number } | undefined,
): event is { readonly type: string; readonly time: number } {
  return event !== undefined
    && typeof event.time === 'number'
    && event.type !== undefined
    && INTERACTION_EVENT_TYPES.has(event.type)
}

/** The timestamp used for ordering and today/yesterday grouping. */
export function sessionActivityAt(session: ActivitySortable): number {
  return session.lastActivityAt ?? session.createdAt
}

/**
 * Descending by last interaction, then by creation time, then id. The id tie-break keeps
 * repeated refreshes stable when two sessions share both timestamps.
 */
export function sortSessionsByActivity<T extends ActivitySortable>(sessions: readonly T[]): T[] {
  return [...sessions].sort((left, right) => {
    const activity = sessionActivityAt(right) - sessionActivityAt(left)
    if (activity !== 0) return activity
    const created = right.createdAt - left.createdAt
    if (created !== 0) return created
    return left.id.localeCompare(right.id)
  })
}

/** The newest meaningful interaction time of a live Session, without reading its log twice. */
export function liveLastActivity(session: {
  readonly seq: number
  eventAt: (seq: SessionSeq) => { readonly type?: string; readonly time?: number } | undefined
}): number | undefined {
  const from = Math.max(0, session.seq - ACTIVITY_TAIL_EVENTS)
  for (let index = session.seq - 1; index >= from; index -= 1) {
    const event = session.eventAt(index as SessionSeq)
    if (isInteractionActivity(event)) return event.time
  }
  return undefined
}

interface ActivityCacheEntry {
  readonly revision: SessionPersistenceSnapshot['revision']
  readonly at?: number
}

/**
 * Tail-reader for persisted sessions with a `(id, revision)` cache.
 *
 * A bounded tail window is one small read, not a full-log scan. It scans backwards for the
 * last meaningful interaction, so replay-only events cannot reorder the picker. Backends
 * without `eventCount` fall back to the caller's createdAt ordering rather than guessing
 * from a full log.
 */
export class SessionActivityResolver {
  private readonly cache = new Map<string, ActivityCacheEntry>()

  constructor(private readonly persistence: Pick<SessionPersistence, 'stat' | 'open'>) {}

  async lastActivityAt(
    id: SessionId,
    knownSnapshot?: SessionPersistenceSnapshot,
  ): Promise<number | undefined> {
    const key = String(id)
    const snapshot = knownSnapshot ?? await this.persistence.stat(id)
    if (snapshot === undefined) return undefined
    const cached = this.cache.get(key)
    if (cached !== undefined && cached.revision === snapshot.revision) return cached.at

    let at: number | undefined
    if (snapshot.eventCount !== undefined && snapshot.eventCount > 0) {
      const length = Math.min(ACTIVITY_TAIL_EVENTS, snapshot.eventCount)
      const offset = snapshot.eventCount - length
      const handle = await this.persistence.open(id, 'read')
      try {
        const { events } = await handle.read(offset, length)
        for (let index = events.length - 1; index >= 0; index -= 1) {
          if (isInteractionActivity(events[index])) {
            at = events[index]?.time
            break
          }
        }
      } finally {
        await handle.close()
      }
    }
    this.cache.set(key, { revision: snapshot.revision, ...(at === undefined ? {} : { at }) })
    return at
  }
}
