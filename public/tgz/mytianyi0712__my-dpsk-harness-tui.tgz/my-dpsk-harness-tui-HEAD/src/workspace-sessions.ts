/**
 * Workspace grouping for terminal sessions.
 *
 * dsh groups sessions in durable Workspace records: a session is displayed under
 * the workspace whose `sessionIds` account names it, and every session no
 * workspace accounts for lands in the client's "ungrouped" bucket. Web hosts get
 * that account for free because their API session controller attaches each
 * session it creates; the terminal profile creates sessions through the agent
 * loop, so its sessions reached disk with a recorded `cwd` but never entered a
 * workspace — exactly what the desktop client showed as "未分组".
 *
 * This row closes the gap with the standard mechanism instead of a side channel:
 * it mounts `@deepseek-ai/dsh-workspace` when the profile does not carry it,
 * resolves the workspace owning a session's recorded `cwd` — registering the
 * directory on first use, the same way the desktop's folder picker does — and
 * calls `attachSession`, which is what the API session controller calls after
 * `createSession`. Sessions already on disk are backfilled for the
 * directories this terminal is working in, so an existing history joins its
 * workspace rather than staying ungrouped.
 */

import {
  SessionId,
  loadWorkspaceRegistry,
  type Context,
  type GroupingRegistry,
  type GroupingWorkspace,
  type Session,
} from './dsh-host/index.ts'
import { sameProject } from './session-filter.ts'

export const name = 'workspace-sessions'

/** Upper bound on one backfill pass, so a huge history cannot stall startup. */
const MAX_BACKFILL = 500

/** Header fields grouping reads; the real `SessionHeader` is assignable to it. */
export interface GroupableSession {
  readonly id: SessionId | string
  readonly cwd?: string
  readonly createdAt?: number
  readonly origin?: string
}

/** What {@link groupSession} did, for logging and tests. */
export type GroupOutcome =
  /** A workspace account now names this session. */
  | 'attached'
  /** The workspace already accounted for it; nothing was written. */
  | 'present'
  /** The session records no usable `cwd`, so it belongs to no directory. */
  | 'unrecorded'
  /** The directory has no workspace and this call was not allowed to create one. */
  | 'unresolved'

/** Resolve the workspace owning `cwd`, registering the directory when allowed. */
export async function workspaceFor(
  registry: GroupingRegistry,
  cwd: string,
  create: boolean,
): Promise<GroupingWorkspace | undefined> {
  try {
    const existing = await registry.resolveByPath(cwd)
    if (existing !== undefined) return existing
  } catch {
    // `realpath` failed: the recorded directory is gone, so there is nothing an
    // account could be validated against. Leaving the session ungrouped is the
    // only safe outcome — it also matches the registry's own attach contract.
    return undefined
  }
  if (!create) return undefined
  try {
    return await registry.create(cwd)
  } catch {
    return undefined
  }
}

/**
 * Enter one session into the workspace owning its recorded directory.
 *
 * `create` controls whether a missing workspace is registered: a top-level
 * session is the user working in that directory, so it may create one; a
 * subagent child inherits its parent's directory and must never invent a
 * workspace of its own.
 */
export async function groupSession(
  registry: GroupingRegistry,
  session: GroupableSession,
  options: { readonly create: boolean },
): Promise<GroupOutcome> {
  const cwd = session.cwd
  if (cwd === undefined || cwd === '') return 'unrecorded'
  const workspace = await workspaceFor(registry, cwd, options.create)
  if (workspace === undefined) return 'unresolved'
  const id = SessionId(String(session.id))
  if (workspace.sessionIds.includes(id)) return 'present'
  await workspace.attachSession(id)
  return 'attached'
}

/**
 * Enter the sessions already on disk into one workspace.
 *
 * Only sessions recorded under this workspace's directory are considered, the
 * archive set is skipped (an archived session keeps whatever slot it had, and
 * unarchiving a never-accounted one belongs in the client's own "ungrouped"
 * flow), and subagent children are left to their parent. Attaching oldest first
 * leaves the newest session at the head of the account, because `attachSession`
 * prepends.
 *
 * @returns how many sessions were newly attached.
 */
export async function backfillWorkspace(
  workspace: GroupingWorkspace,
  sessions: readonly GroupableSession[],
  archived: readonly string[],
): Promise<number> {
  const archivedIds = new Set(archived)
  const candidates = sessions
    .filter(session => session.origin !== 'subagent')
    .filter(session => !archivedIds.has(String(session.id)))
    .filter(session => session.cwd !== undefined && sameProject(session.cwd, workspace.path))
    .sort((left, right) => (left.createdAt ?? 0) - (right.createdAt ?? 0))
    .slice(-MAX_BACKFILL)
  let attached = 0
  for (const session of candidates) {
    const id = SessionId(String(session.id))
    if (workspace.sessionIds.includes(id)) continue
    try {
      await workspace.attachSession(id)
      attached += 1
    } catch (error) {
      // One unattachable session (an unreadable header, a directory that changed
      // between the scan and the write) must not abort the rest of the pass.
      continue
    }
  }
  return attached
}

/**
 * Look up a service whose package is not a compile-time dependency of this
 * package. Only used for the presence probe below: the registry needs
 * `storageDomain`, and mounting it without that peer would leave the fiber
 * pending forever instead of reporting anything.
 */
function optionalService(ctx: Context, name: string): unknown {
  const get = ctx.get as unknown as (key: string) => unknown
  return get(name)
}

/** Mount the workspace registry unless the profile already provides it. */
async function ensureRegistry(ctx: Context): Promise<GroupingRegistry | undefined> {
  const existing = ctx.get('workspaceRegistry')
  if (existing !== undefined) return existing
  if (optionalService(ctx, 'storageDomain') === undefined) return undefined
  let plugin: Awaited<ReturnType<typeof loadWorkspaceRegistry>>
  try {
    plugin = await loadWorkspaceRegistry()
  } catch {
    // The profile predates the workspace package (or a minimal install omits it).
    ctx.logger.info(`workspace grouping unavailable: @deepseek-ai/dsh-workspace is not installed`)
    return undefined
  }
  try {
    await ctx.plugin(plugin as never, {} as never).await()
  } catch (error) {
    ctx.logger.warn(`workspace grouping unavailable: ${String(error)}`)
    return undefined
  }
  const mounted = ctx.get('workspaceRegistry')
  if (mounted === undefined) ctx.logger.warn('workspace grouping unavailable: registry did not activate')
  return mounted
}

/** Attach one live session, containing failures so a group miss never disturbs it. */
async function attachQuietly(
  ctx: Context,
  registry: GroupingRegistry,
  session: Session,
  create: boolean,
): Promise<GroupOutcome | 'failed'> {
  try {
    return await groupSession(registry, session.header, { create })
  } catch (error) {
    ctx.logger.warn(`session "${String(session.id)}" could not be grouped: ${String(error)}`)
    return 'failed'
  }
}

/** Every stored header, read once per backfill pass. */
async function storedSessions(ctx: Context): Promise<GroupableSession[]> {
  const persistence = ctx.get('sessionPersistence')
  if (persistence === undefined) return []
  const snapshots = await persistence.list()
  return snapshots.map(snapshot => snapshot.header)
}

/**
 * Group the live sessions, backfill their directories, then keep following
 * session creation. Runs after `sessions` and `sessionPersistence` are up, and
 * re-runs if either restarts.
 */
async function start(ctx: Context): Promise<void> {
  const registry = await ensureRegistry(ctx)
  if (registry === undefined) return

  // One backfill pass per directory per run: the scan reads every stored header,
  // so it is worth doing only when a directory first becomes known.
  const backfilled = new Set<string>()
  const backfillOnce = async (workspace: GroupingWorkspace): Promise<void> => {
    if (backfilled.has(workspace.path)) return
    backfilled.add(workspace.path)
    try {
      const attached = await backfillWorkspace(
        workspace,
        await storedSessions(ctx),
        (registry.archivedSessionIds ?? []).map(String),
      )
      if (attached > 0) ctx.logger.info(`workspace "${workspace.path}": grouped ${attached} earlier session(s)`)
    } catch (error) {
      ctx.logger.warn(`workspace history backfill failed: ${String(error)}`)
    }
  }

  const live = ctx.sessions.list()
  // Resolve first: the backfill needs a workspace per directory, and a live
  // session may be the only record of which directory this terminal works in.
  const workspaces = new Map<string, GroupingWorkspace>()
  for (const session of live) {
    const cwd = session.header.cwd
    if (cwd === undefined) continue
    const workspace = await workspaceFor(registry, cwd, session.header.origin !== 'subagent')
    if (workspace !== undefined) workspaces.set(workspace.path, workspace)
  }
  for (const workspace of workspaces.values()) await backfillOnce(workspace)

  // Live sessions go last so the newest sits at the head of the account: every
  // attach prepends, and the backfill already entered older sessions.
  for (const session of live) {
    await attachQuietly(ctx, registry, session, false)
  }

  ctx.on('session/created', session => {
    const create = session.header.origin !== 'subagent'
    const cwd = session.header.cwd
    void (async () => {
      await attachQuietly(ctx, registry, session, create)
      // A profile whose terminal row mounts before the agent loop has no live
      // session to learn the working directory from; the first created session
      // supplies it, so run the first pass here too.
      if (cwd === undefined) return
      const workspace = await workspaceFor(registry, cwd, false)
      if (workspace !== undefined) await backfillOnce(workspace)
    })()
  })
}

export function apply(ctx: Context): void {
  ctx.inject(['sessions', 'sessionPersistence'], async injected => {
    try {
      await start(injected)
    } catch (error) {
      injected.logger.warn(`workspace grouping failed: ${String(error)}`)
    }
  })
}
