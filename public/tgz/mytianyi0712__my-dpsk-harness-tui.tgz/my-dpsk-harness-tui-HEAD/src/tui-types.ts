/**
 * The small TUI vocabulary this bundle still needs after the render base exited.
 *
 * 0.5.0 moved the renderer to the OpenTUI sidecar, so the host no longer mounts a
 * terminal UI. What remains are plain data shapes the host produces for the renderer's
 * completion popup and the command catalog. Keeping them here (instead of importing the
 * retired base package) means the published bundle carries none of its code at all,
 * which is what `verify:boundary` and the license gate expect of a "base exited" release.
 */

/** One completion row: the accepted value, its label, and an optional detail line. */
export interface AutocompleteItem {
  value: string
  label: string
  description?: string
}

/** One slash command advertised to the renderer's palette and composer completion. */
export interface SlashCommand {
  name: string
  description: string
  argumentHint?: string
  getArgumentCompletions?: (prefix: string) => AutocompleteItem[] | null | Promise<AutocompleteItem[] | null>
}

/** The terminal's colour scheme, reported by the renderer's palette probe. */
export type TerminalColorScheme = 'dark' | 'light'
