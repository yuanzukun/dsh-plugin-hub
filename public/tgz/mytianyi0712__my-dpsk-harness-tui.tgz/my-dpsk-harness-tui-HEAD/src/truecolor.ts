/**
 * 24-bit colour detection, lifted out of the retired host theme engine.
 *
 * The renderer owns its palette now; the host only needs this one answer to decide
 * whether its own startup output may use truecolor escape sequences.
 */

/**
 * Detect 24-bit colour support, mirroring the omp harness's `detectColorMode`:
 * `COLORTERM=truecolor|24bit` or a Windows Terminal session admit truecolor;
 * `TERM` `dumb`/`linux`/empty deny it; anything else assumes truecolor.
 */
export function detectTruecolor(): boolean {
  const colorterm = process.env.COLORTERM
  if (colorterm === 'truecolor' || colorterm === '24bit') return true
  if (process.env.WT_SESSION !== undefined) return true
  const term = process.env.TERM ?? ''
  return term !== '' && term !== 'dumb' && term !== 'linux'
}
