/**
 * Serializable configuration and defaults for the omp-styled terminal mode.
 * The bundle's `tui` row carries these; schemastery validates the shape.
 */

import { z } from './dsh-host/index.ts'
import type { Locale } from './i18n.ts'

/** Shipped working modes (backend compositions); locally installed presets use any other id. */
export type UiMode = 'standard' | 'minimal' | 'code' | 'cordis'

/**
 * Banner and ANSI-output settings. The renderer owns the theme catalog and its
 * palette (native `theme.name` / `theme.mode` rows in its own config section),
 * so the host row carries no theme id, mode, or color override.
 */
export interface TuiThemeConfig {
  /** Apply the ANSI palette to host output at all. */
  color?: boolean
  /** Paint the startup banner with the 24-bit brand gradient. */
  truecolor?: boolean
}

/** Interaction and presentation settings. */
/** User-facing path rendering; operational paths always stay absolute. */
export type PathDisplayMode = 'tilde' | 'full'

export interface TuiConfig {
  /** Render model reasoning blocks. */
  showReasoning?: boolean
  /** Maximum tool-card body lines retained in its collapsed preview. */
  maxToolOutputLines?: number
  /** Reasoning effort used before a session has a recorded request header. */
  defaultReasoningEffort?: string
  theme?: TuiThemeConfig
  /** Native theme id the renderer selects (`opencode`, `opencode2`, a discovered file, `system`). */
  themeName?: string
  /** `system` follows the terminal; `dark` / `light` pin one mode. */
  themeMode?: 'system' | 'dark' | 'light'
  /** New compact thinking/tool transcript presentation. */
  newDesigns?: boolean
  /** Shorten paths below the user's home to `~/...`, or always paint the full path. */
  pathDisplay?: PathDisplayMode
  /** Backend composition preset for blank sessions: any shipped or locally installed preset id. */
  mode?: string
  /** UI language; `zh-CN` is the default, `en` is fully supported. */
  locale?: Locale
  /** Terminal title. */
  title?: string
  /** Keybinding for cycling tool cards. */
  keyTools?: string
  /** Keybinding for toggling reasoning blocks. */
  keyReasoning?: string
  /** System notifications when a turn finishes (`attention.notifications`); default off. */
  attentionNotifications?: boolean
  /** Attention sound when a turn finishes (`attention.sound`); default off. */
  attentionSound?: boolean
  /** Attention volume, 0–1 (`attention.volume`); default 0.4. */
  attentionVolume?: number
  /** Interface animations (`animations`); false paints still frames. */
  animations?: boolean
  /** Prompt footer templates (`${name}` tokens resolved by the renderer). */
  leftPrompt?: string
  rightPrompt?: string
  /** Leader-key window in milliseconds (opencode v2 `leader_timeout`). */
  leaderTimeout?: number
  /** Raw keybind table imported from `cli.json`, keyed by opencode command id. */
  keybinds?: Record<string, string>
  /** Scroll wheel speed (opencode v2 `scroll_speed`). */
  scrollSpeed?: number
  /** Accelerated scrolling (opencode v2 `scroll_acceleration`). */
  scrollAcceleration?: boolean
  /** Diff rendering style (opencode v2 `diff_style`). */
  diffStyle?: string
  /** Cursor style (opencode v2 `cursor`). */
  cursor?: string
  /** Mouse capture on/off (opencode v2 `mouse`). */
  mouse?: boolean
  /** Stamp proving the one-time `cli.json` import ran, so a restart writes nothing. */
  cliImportedAt?: string
}

/** The prompt footer's shipped templates. Both are `${name}` token strings the renderer
 * resolves against host state (`renderer/src/ui/prompt-template.ts`); the settings page
 * edits them and the host echoes the edited value back. */
export const DEFAULT_LEFT_PROMPT = '${location}'
/** The footer's right group mirrors upstream: context usage plus the optional queue/subagent
 * counters. The route (agent/model/provider/effort) lives in the prompt's metadata row, so it
 * is not repeated here; the key hint is appended by the renderer. */
export const DEFAULT_RIGHT_PROMPT = '${context}${queued}${subagents}'

export const DEFAULT_MODE: string = 'standard'
/** The shipped UI language: this is a Chinese-first TUI (README, CHANGELOG, and the
 * dictionary's own copy are zh-CN), so a config that says nothing runs in Chinese.
 *
 * Deliberately not sniffed from the environment or `Intl`: the dsh runtime hosts this
 * plugin in an Electron process with trimmed ICU data, and both
 * `Intl.DateTimeFormat().resolvedOptions().locale` and a stray `LANG` read `en*` on a
 * Chinese Windows box — the very mismatch this default replaces. Set `locale: en` in the
 * profile's patch layer (or the `/settings` language row) for the English copy. */
export const DEFAULT_LOCALE: Locale = 'zh-CN'
export const DEFAULT_REASONING_EFFORT = 'max'

const themeSchema = z.object({
  color: z.boolean().default(true),
  truecolor: z.boolean(),
})

/** Alias kept for consumers that name the plugin config `Config`. */
export type Config = TuiConfig

/**
 * Schemastery schema for presentation settings embedded by the bundle. dsh 0.2
 * exposes the row's live Config as the settings section, so the row id (`dpsk-tui`)
 * is the settings namespace.
 *
 * `volatile()` is not decoration: dsh's settings service only projects **volatile**
 * fields into its form, and rejects every write to a row with none (`Plugin entry
 * "dpsk-tui" has no volatile fields`). Each field the renderer's settings page writes
 * therefore goes through `config.<field>.get()`, which is the live value the editor
 * replaces without remounting the plugin.
 */
// `volatile()` wraps each field's *output* in a live reference, which `resolveTuiConfig`
// unwraps with `liveValue`; the constructor-facing type stays the plain `TuiConfig`, so the
// schema is asserted to that shape instead of the volatile-wrapped inference.
export const TuiConfigSchema: z<TuiConfig> = z.object({
  showReasoning: z.boolean().default(true).volatile(),
  maxToolOutputLines: z.number().step(1).min(1).default(6).volatile(),
  defaultReasoningEffort: z.string().default(DEFAULT_REASONING_EFFORT).volatile(),
  theme: themeSchema,
  themeName: z.string().default('opencode').volatile(),
  themeMode: z.union([z.const('system'), z.const('dark'), z.const('light')]).default('system').volatile(),
  newDesigns: z.boolean().default(false).volatile(),
  pathDisplay: z.union([z.const('tilde'), z.const('full')]).default('tilde').volatile(),
  mode: z.string().default(DEFAULT_MODE).volatile(),
  locale: z.union([z.const('zh-CN'), z.const('en')]).default(DEFAULT_LOCALE).volatile(),
  title: z.string().default('dsh').volatile(),
  keyTools: z.string().volatile(),
  keyReasoning: z.string().volatile(),
  attentionNotifications: z.boolean().default(false).volatile(),
  attentionSound: z.boolean().default(false).volatile(),
  attentionVolume: z.number().min(0).max(1).default(0.4).volatile(),
  animations: z.boolean().default(true).volatile(),
  leftPrompt: z.string().volatile(),
  rightPrompt: z.string().volatile(),
  // The one-time `cli.json` import (`src/cli-config.ts`) writes these fields, and the
  // legacy `tui` row migration copies the same names, so they must be declared volatile
  // here: dsh's settings service rejects any write to an undeclared field
  // (`Config field "cliImportedAt" is not volatile`). Omitting them made the import fail
  // on every startup and re-run forever (the stamp could never be written).
  leaderTimeout: z.number().step(1).volatile(),
  keybinds: z.dict(z.string()).volatile(),
  scrollSpeed: z.number().volatile(),
  scrollAcceleration: z.boolean().volatile(),
  diffStyle: z.string().volatile(),
  cursor: z.string().volatile(),
  mouse: z.boolean().volatile(),
  cliImportedAt: z.string().volatile(),
}) as unknown as z<TuiConfig>

/** Fully defaulted banner settings. */
export interface ResolvedTuiThemeConfig {
  color: boolean
  truecolor: boolean
}

/** Fully defaulted presentation settings. */
export interface ResolvedTuiConfig {
  showReasoning: boolean
  maxToolOutputLines: number
  defaultReasoningEffort: string
  theme: ResolvedTuiThemeConfig
  themeName: string
  themeMode: 'system' | 'dark' | 'light'
  newDesigns: boolean
  pathDisplay: PathDisplayMode
  mode: string
  locale: Locale
  title: string
  keyTools: string
  keyReasoning: string
  attentionNotifications: boolean
  attentionSound: boolean
  attentionVolume: number
  animations: boolean
  /** The prompt footer's templates: `${name}` token strings the renderer resolves. */
  leftPrompt: string
  rightPrompt: string
}

/**
 * Read one declared value.
 *
 * A `volatile()` schema field yields a live reference (`{ get() }`) rather than the raw
 * value, which is what lets the settings editor replace it without remounting the plugin.
 * A plain object here would be a schema bug, not a value, so it never flows into the
 * resolved config.
 */
function liveValue<T>(field: T | { readonly get: () => T | undefined } | undefined): T | undefined {
  if (field !== null && typeof field === 'object' && typeof (field as { get?: unknown }).get === 'function') {
    return (field as { get: () => T | undefined }).get()
  }
  return field as T | undefined
}

/** Apply direct-call defaults after Loader schema validation has normally run. */
export function resolveTuiConfig(config: TuiConfig | undefined): ResolvedTuiConfig {
  const theme = config?.theme
  return {
    showReasoning: liveValue(config?.showReasoning) ?? true,
    maxToolOutputLines: liveValue(config?.maxToolOutputLines) ?? 6,
    defaultReasoningEffort: liveValue(config?.defaultReasoningEffort) ?? DEFAULT_REASONING_EFFORT,
    theme: {
      color: theme?.color ?? true,
      truecolor: theme?.truecolor ?? false,
    },
    themeName: liveValue(config?.themeName) ?? 'opencode',
    themeMode: liveValue(config?.themeMode) ?? 'system',
    newDesigns: liveValue(config?.newDesigns) === true,
    pathDisplay: liveValue(config?.pathDisplay) ?? 'tilde',
    mode: liveValue(config?.mode) ?? DEFAULT_MODE,
    // An explicit `locale` row (or a live ref) wins; otherwise the shipped dictionary.
    locale: liveValue(config?.locale) ?? DEFAULT_LOCALE,
    title: liveValue(config?.title) ?? 'dsh',
    keyTools: liveValue(config?.keyTools) ?? 'ctrl+o',
    keyReasoning: liveValue(config?.keyReasoning) ?? 'ctrl+t',
    attentionNotifications: liveValue(config?.attentionNotifications) === true,
    attentionSound: liveValue(config?.attentionSound) === true,
    attentionVolume: liveValue(config?.attentionVolume) ?? 0.4,
    animations: liveValue(config?.animations) !== false,
    leftPrompt: liveValue(config?.leftPrompt) ?? DEFAULT_LEFT_PROMPT,
    rightPrompt: liveValue(config?.rightPrompt) ?? DEFAULT_RIGHT_PROMPT,
  }
}
