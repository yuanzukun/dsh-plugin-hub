/**
 * Interactive DeepSeek Harness front door, visually aligned with the local
 * OMP 17.2.15 Catppuccin layout while retaining dsh-native agent, session,
 * command, and persistence contracts.
 * @module my-dpsk-harness-tui
 */

import { Buffer } from 'node:buffer'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { readFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { basename, dirname, isAbsolute, join, resolve } from 'node:path'
import { Service, type Context } from './dsh-host/index.ts'
import { type AutocompleteItem, type SlashCommand, type TerminalColorScheme } from './tui-types.ts'
import type {
  Agent,
  AgentHandle,
  AssistantStreamFrame,
  ModelSelection,
  ModelSelectionRef,
} from './dsh-host/index.ts'
import { installModelSelection } from './dsh-host/index.ts'
import { AttachmentStore, createUserMessage, errorChain, JobId, MessageId, parseCommand, type AttachmentAdmissionPart, type CommandSubmitAttachment, type FileAttachmentRef, type ImageAttachmentRef, type ImageMediaType, type JobOutputRead, type JobView, type ToolCallId, type LlmConfigurableProvider, type LlmReasoningEffortInfo, currentPermissionPreset, setPermissionPreset } from './dsh-host/index.ts'
import { buildForkSeed, ReasoningEffortId, SessionId, SessionLogOffset, SessionSeq, sessionEvents, type AskUserQuestionAnswer, type AskUserQuestionAnswerItem, type AskUserQuestionItem, type Session, type SessionEvent } from './dsh-host/index.ts'
import { foldSessionTitle } from './dsh-host/index.ts'
import { EMPTY_USAGE_FOLD, foldUsageSample, type UsageFold } from './host/token-totals.ts'
import { EMPTY_USAGE_COST_FOLD, findPricingModel, foldUsageCost, type UsageCostFold } from './host/pricing.ts'
import { ProgramConfigStore, writeJsonAtomic } from './host/program-config.ts'
import { parseSessionReferenceText } from './dsh-host/index.ts'
import { isUserInvocable, loadTerminalController, readPluginInventory, renderSkillContent, scopeOf, UserQuestionError } from './dsh-host/index.ts'
// Type-only imports pull in the declaration merges that expose `ctx.commands`,
// `ctx.tokenMeter`, `ctx.llm`, `ctx.userQuestions`, `ctx.sessionQuery`,
// `ctx.agentDefaultModel`, `ctx.skills`, `ctx.sessionReferenceResolver`, and
// `ctx.permissionPresets` on the cordis Context, plus the goal/compaction/skill
// session-event extensions.
import { settingsNamespace, settingsValues, type SettingsNamespace } from './dsh-host/index.ts'
import { PERMISSION_SETTINGS_NAMESPACE } from './dsh-host/index.ts'
// Declaration merges: `ctx.agentPresets` and the `agent-preset/selected`
// session event, plus the runtime preset resolver for resumed sessions.
import { resolveSessionPreset } from './dsh-host/index.ts'
import {
  DEFAULT_LEFT_PROMPT,
  DEFAULT_RIGHT_PROMPT,
  TuiConfigSchema,
  resolveTuiConfig,
  type Config,
  type ResolvedTuiConfig,
  type UiMode,
} from './config.ts'
import type { TuiStartup } from './startup.ts'
import { createTranslator, messagesFor, type MessageKey, type Translator } from './i18n.ts'
import {
  FULL_ACCESS_REGISTRY_NAME,
  FULL_ACCESS_UI_NAME,
  displayPermissionName,
  permissionCommandMetadata,
  registryPermissionName,
} from './permission.ts'
import { detectTruecolor } from './truecolor.ts'
import { listWorkspaceFiles } from './workspace-files.ts'
import { readSessionListCache, writeSessionListCache } from './session-list-cache.ts'
import {
  saveDefaultModel,
  SESSION_TITLE_SETTINGS_NAMESPACE,
  TUI_SETTINGS_NAMESPACE,
  type TuiSettings,
} from './settings.ts'
import {
  formatMigrationReport,
  migrateLegacyTheme,
  persistLegacySettings,
  readLegacySettings,
} from './settings-migrate.ts'
import {
  cliConfigPath,
  cliImportPlan,
  filterCliImportPatch,
  formatCliImportReport,
  readCliConfig,
} from './cli-config.ts'
import {
  formatContextTokens,
  chooseReasoningEffort,
  resolveSessionModelSelection,
} from './components/status.ts'
import { startupModelSelection } from './startup-selection.ts'
import { normalizeProviderModels } from './components/model-list-dialog.ts'
import {
  parseReasoningEffortSetting,
  type ReasoningEffortSetting,
} from './reasoning-maps.ts'
import {
  SUPPORTED_PROVIDER_APIS,
  type ProviderDraft,
  type ProviderModelDraft,
} from './components/provider-form.ts'
import { contentText } from './components/content.ts'
import { mountRenderer, type RendererMount } from './host/renderer-mount.ts'
import { appendAssistantTextDelta, type AssistantStreamRow } from './host/assistant-stream.ts'
import type { ContentBlock } from './dsh-host/index.ts'
import type { AttachmentReadPayload, HostPluginItem, McpServerItem, SendMessagePayload, SessionListPayload, SessionOpPayload, ShellJobOpPayload, ShellJobView as ShellJobWireView, SkillSpec, SubagentDescriptor, TerminalEndPayload, TerminalFrame, TerminalFramePayload, TerminalOpPayload, TodoItem, UsagePayload } from './ipc/kinds.ts'
import { adaptTerminalController, type TerminalAttachmentId, type TerminalControllerService, type WebTerminalId, type WebTerminalInfo as HostWebTerminalInfo } from './dsh-host/product.ts'
import { defaultHostView, resolveRendererPath } from './host/renderer-process.ts'
import { createDaemonBridge, daemonPaths, startDaemonServer } from './host/daemon.ts'
import { autostartStatus, setAutostart } from './host/autostart.ts'
import { createTranscriptFoldState, transcriptEvents, type TranscriptFoldState } from './host/transcript-events.ts'
import { displayText } from './components/text.ts'
import { filterProjectSessions, sameProject } from './session-filter.ts'
import { hasConversationData, recordConversationPreset, sessionListBlank } from './session-lifecycle.ts'
import { userMessageText, hasConversationEvent } from './session-label.ts'
import { pruneBlankTuiSessionDirectories } from './session-prune.ts'
import { liveLastActivity, SessionActivityResolver, sortSessionsByActivity } from './session-activity.ts'
import type { BridgeConfig, WechatBridge, WechatOutputMessage } from './wechat/index.ts'
import { setActiveAgent } from './wechat/dsh/session.ts'
import { setTuiForegroundControl } from './wechat/dsh/tui-control.ts'
import { createExtensionServices, type ExtensionServices, type SettingsField, type SettingsSection } from './extensions/index.ts'
import type { TuiPluginHost } from './host/index.ts'
import { enqueueBootNotice, drainBootNotices } from './boot-notices.ts'
import { upstreamDriftWarnings, UPSTREAM_VALIDATED_VERSIONS } from './std-contract.ts'
import { negotiate, parseManifest } from './plugin-spec/index.ts'

export const name = 'tui'

const SPINNER_FRAMES = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
const SPINNER_INTERVAL_MS = 80
/** How long to wait for the configured agent to publish before giving up. */
const AGENT_READY_TIMEOUT_MS = 30000
/** Safety cap for a session resume's persistence load and setup phase. */
const RESUME_TIMEOUT_MS = 30_000
/** How many recent sessions to show in the `/resume` picker before title reads. */
const RESUME_PICKER_LIMIT = 50
/** Safety cap for loading title snapshots before showing the `/resume` picker. */
const RESUME_TITLES_TIMEOUT_MS = 5_000
/** Setup events at the head are enough to distinguish a blank session from a conversation. */
const SESSION_HEAD_SCAN_EVENTS = 40
/** Context fallback while exact model metadata is unavailable. */
const DEFAULT_CONTEXT_WINDOW = 1_000_000
/** Bound renderer-owned file uploads before the host decodes or stores them. */
const MAX_RENDERER_FILE_ATTACHMENT_BYTES = 20 * 1024 * 1024

/** UI modes map 1:1 to the shipped dsh agent presets (backend compositions). */
const MODE_PRESETS = { standard: 'standard', minimal: 'minimal', code: 'code', cordis: 'cordis' } as const
type UiModeKey = keyof typeof MODE_PRESETS

/** Bare `/mode` cycles through the shipped presets in this order. */
const MODE_ORDER: readonly UiModeKey[] = ['standard', 'minimal', 'code', 'cordis']

/** i18n key for each mode's localized label. */
const MODE_LABEL_KEYS: Record<UiModeKey, MessageKey> = {
  standard: 'modeStandard',
  minimal: 'modeMinimal',
  code: 'modeCode',
  cordis: 'modeCordis',
}



/** Restore a session's recorded backend preset, falling back for blank sessions. */
function modeForSession(ctx: Context, session: Session, fallback: string): string {
  return resolveSessionPreset(ctx, session) ?? fallback
}

/** The localized label of a preset id, preferring the roster's own name. */
function modeLabel(
  t: Translator,
  mode: string,
  names: ReadonlyMap<string, string>,
): string {
  const rosterName = names.get(mode)
  if (rosterName !== undefined) return rosterName
  return mode in MODE_LABEL_KEYS ? t(MODE_LABEL_KEYS[mode as UiModeKey]) : mode
}

/** Filter preset argument choices while preserving their descriptions. */
function filterCommandOptions(options: readonly AutocompleteItem[], prefix: string): AutocompleteItem[] | null {
  const query = prefix.trim().toLocaleLowerCase()
  const filtered = query === ''
    ? options
    : options.filter(item => `${item.value} ${item.label}`.toLocaleLowerCase().startsWith(query))
  return filtered.length === 0 ? null : [...filtered]
}

/** Show the command's expected argument while the user edits its prefix. */
function commandInputHint(text: string, commands: readonly SlashCommand[]): string | undefined {
  const match = /^\/([^\s]*)/.exec(text)
  if (match?.[1] === undefined) return undefined
  const command = commands.find(entry => entry.name === match[1])
  return command?.argumentHint === undefined ? undefined : `/${command.name} ${command.argumentHint}`
}

/** Format a token count compactly: 1234 → "1.2k", 1234567 → "1.2M". */
function formatTokens(count: number): string {
  if (count >= 1_000_000) return `${(count / 1_000_000).toFixed(1)}M`
  if (count >= 1_000) return `${(count / 1_000).toFixed(1)}k`
  return String(count)
}



/** Resolve a regular repository or linked worktree branch without spawning Git. */
async function readGitBranch(cwd: string): Promise<string | undefined> {
  const dotGit = join(cwd, '.git')
  let gitDir = dotGit
  try {
    const pointer = (await readFile(dotGit, 'utf8')).trim()
    const match = /^gitdir:\s*(.+)$/i.exec(pointer)
    if (match?.[1] !== undefined) {
      gitDir = isAbsolute(match[1]) ? match[1] : resolve(cwd, match[1])
    }
  } catch {
    // A normal checkout exposes `.git` as a directory, not a pointer file.
  }
  try {
    const head = (await readFile(join(gitDir, 'HEAD'), 'utf8')).trim()
    if (head.startsWith('ref:')) return head.slice(head.lastIndexOf('/') + 1)
    return head === '' ? undefined : head.slice(0, 7)
  } catch {
    return undefined
  }
}

/** Legacy empty-session cleanup is a one-time housekeeping task, not a first-frame cost. */
const STARTUP_CLEANUP_INTERVAL_MS = 6 * 60 * 60 * 1000

/** The terminal mode's plugin entry: mounts the whole UI in its constructor. */
export class Tui extends Service {
  static inject = ['tuiStartup', 'agents', 'commands', 'tokenMeter', 'llm', 'userQuestions', 'sessionQuery', 'sessionPersistence', 'agentDefaultModel', 'skills', 'sessionReferenceResolver', 'agentPresets', 'permissionPresets', 'settings', 'sessionTitle']
  static Config = TuiConfigSchema

  /** Mount 后由 TUI 赋值：读取当前前台 agent。 */
  private foregroundAgentImpl: (() => Agent | undefined) | undefined

  /** Mount 后由 TUI 赋值：按 TUI `/new` 逻辑创建会话并切到前台。 */
  private createForegroundSessionImpl: (() => Promise<SessionId | undefined>) | undefined

  /** 当前前台会话；未挂载时返回 undefined。 */
  foregroundAgent(): Agent | undefined {
    return this.foregroundAgentImpl?.()
  }

  /** WeChat `@dsh new` 使用：按 TUI 的 `/new` 逻辑创建会话并切到前台。 */
  async createForegroundSession(): Promise<SessionId | undefined> {
    if (this.createForegroundSessionImpl === undefined) return undefined
    return this.createForegroundSessionImpl()
  }

  constructor(ctx: Context, config: Config) {
    super(ctx, 'tui')

    const startup: TuiStartup = ctx.tuiStartup
    const sessionId = startup.sessionId ?? startup.resumeSessionId
    if (sessionId === undefined) {
      throw new Error('tui: no session identity available')
    }

    const resolved: ResolvedTuiConfig = resolveTuiConfig(config)
    const t: Translator = createTranslator(resolved.locale)
    const truecolor = resolved.theme.truecolor || detectTruecolor()
    // Runtime theme state; `/theme` and `/settings` re-paint in place. The TUI
    // row's live Config is its own settings section (dsh 0.2 dropped
    // `SettingsForms.register`), keyed by the row id `tui`.
    const settings = ctx.settings
    interface ProviderModelProfile {
      id: string
      name?: string
      contextWindow?: number
      maxTokens?: number
      reasoningEfforts?: ReasoningEffortSetting
    }
    interface ConfiguredProviderProfile {
      apiKeyEnv?: string
      displayName?: string
      api?: string
      baseURL?: string
      models?: ProviderModelProfile[]
    }
    const asRecord = (value: unknown): Record<string, unknown> | undefined => (
      value !== null && typeof value === 'object' && !Array.isArray(value)
        ? value as Record<string, unknown>
        : undefined
    )
    const readPath = (value: unknown, path: readonly string[]): unknown => {
      let current = value
      for (const key of path) {
        const record = asRecord(current)
        if (record === undefined) return undefined
        current = record[key]
      }
      return current
    }
    const configurableProviderList = (): LlmConfigurableProvider[] => (
      typeof ctx.llm.listConfigurableProviders === 'function'
        ? ctx.llm.listConfigurableProviders()
        : []
    )
    const readConfiguredProvider = (entry: LlmConfigurableProvider): ConfiguredProviderProfile | undefined => {
      const value = readPath(settingsValues(ctx, settingsNamespace(entry.settingsNs)), entry.settingsPath)
      const record = asRecord(value)
      if (record === undefined) return undefined
      const profile: ConfiguredProviderProfile = {}
      if (typeof record.apiKeyEnv === 'string') profile.apiKeyEnv = record.apiKeyEnv
      if (typeof record.displayName === 'string') profile.displayName = record.displayName
      if (typeof record.api === 'string') profile.api = record.api
      if (typeof record.baseURL === 'string') profile.baseURL = record.baseURL
      if (Array.isArray(record.models) && record.models.length > 0) {
        const models = record.models.flatMap(model => {
          if (typeof model === 'string') return [{ id: model }]
          const modelRecord = asRecord(model)
          return typeof modelRecord?.id === 'string'
            ? [{
              id: modelRecord.id,
              ...(typeof modelRecord.name === 'string' ? { name: modelRecord.name } : {}),
              ...(typeof modelRecord.contextWindow === 'number' ? { contextWindow: modelRecord.contextWindow } : {}),
              ...(typeof modelRecord.maxTokens === 'number' ? { maxTokens: modelRecord.maxTokens } : {}),
              ...(() => {
                const reasoningEfforts = parseReasoningEffortSetting(
                  modelRecord.reasoningEfforts as string | readonly string[] | ReasoningEffortSetting | Record<string, unknown> | boolean | undefined,
                )
                return reasoningEfforts === undefined ? {} : { reasoningEfforts }
              })(),
            }]
            : []
        })
        if (models.length > 0) profile.models = models
      }
      return profile
    }
    const configuredProviderProfiles = (): Readonly<Record<string, ConfiguredProviderProfile>> => {
      const profiles: Record<string, ConfiguredProviderProfile> = {}
      for (const entry of configurableProviderList()) {
        const profile = readConfiguredProvider(entry)
        if (profile !== undefined) profiles[entry.provider] = profile
      }
      return profiles
    }
    let reasoningEffortCache: { route: string; efforts: readonly LlmReasoningEffortInfo[] } | undefined
    /**
     * The provider form seam behind the renderer's `form-spec` / `form-submit`. It
     * lives in the plugin scope (not inside `runCommand`) because the renderer mount
     * is wired outside the command handler, and the form write must go through the
     * same profile read, the id rules, and the settings mutation.
     *
     * `providerCatalog` / `modelCatalog` are filled by the command handler's catalog
     * refresh; the declarations sit here so the read side sees them.
     */
    interface ProviderSettingsTarget {
      ns: SettingsNamespace
      path: string[]
      entry: LlmConfigurableProvider
    }
    interface ProviderCatalogEntry {
      id: string
      name: string
      source: 'registered' | 'configurable'
      configurable?: LlmConfigurableProvider
      profile?: ConfiguredProviderProfile
    }
    let providerCatalog: ProviderCatalogEntry[] = []
    let modelCatalog: Array<{ provider: string; model: string }> = []

    const providerSettingsTarget = (
      providerId: string,
      editingId?: string,
    ): ProviderSettingsTarget | undefined => {
      const entries = configurableProviderList()
      const entry = entries.find(candidate => candidate.provider === (editingId ?? providerId))
        ?? (editingId === undefined ? entries.find(candidate => candidate.settingsPath.length > 0) : undefined)
      if (entry === undefined || (editingId === undefined && entry.settingsPath.length === 0)) return undefined
      const path = editingId === undefined
        ? [...entry.settingsPath.slice(0, -1), providerId]
        : [...entry.settingsPath]
      return { ns: settingsNamespace(entry.settingsNs), path, entry }
    }

    const credentialReference = (providerId: string): string => {
      const normalized = providerId.toUpperCase().replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '')
      return `${normalized || 'DSH_PROVIDER'}_API_KEY`
    }

    const providerDiscoveryNamespace = (providerId: string | undefined): string | undefined => {
      const entries = configurableProviderList()
      const entry = entries.find(candidate => candidate.provider === providerId)
        ?? entries.find(candidate => candidate.settingsPath.length > 0)
        ?? entries[0]
      if (entry === undefined || typeof ctx.llm.discoverModels !== 'function') return undefined
      const runtime = ctx.llm as typeof ctx.llm & {
        listModelDiscoveryNamespaces?: () => readonly string[]
      }
      const namespaces = runtime.listModelDiscoveryNamespaces?.()
      if (namespaces !== undefined && !namespaces.includes(entry.settingsNs)) return undefined
      return entry.settingsNs
    }

    /**
     * The flat catalog field: one line per model, `id|name|efforts|effort|context|maxTokens`,
     * models separated by spaces. OpenTUI's `textarea` carries no `value` / `onInput` through
     * the solid reconciler, so the catalog is a single-line field; the separator keeps the
     * per-model fields the nested editor edits. `ReasoningEffortSetting` is a level→wire dict
     * (or `false`), not an array, so the pairs are encoded `level=wire` separated by `;`.
     *
     * Both directions live in the host: the form submit parses the line, and the discovery
     * probe merges into the same encoding, so the renderer never sees two formats.
     */
    const encodeModelLine = (model: ProviderModelDraft): string => [
      model.id,
      model.name ?? '',
      encodeEfforts(model.reasoningEfforts),
      model.reasoningEffort ?? '',
      typeof model.contextWindow === 'number' ? String(model.contextWindow) : '',
      typeof model.maxTokens === 'number' ? String(model.maxTokens) : '',
    ].join('|')

    /** `ReasoningEffortSetting` is a level→wire dict (or `false`), not an array, so the
     * pairs are encoded `level=wire` separated by `;`; a non-reasoning model writes `none`. */
    const encodeEfforts = (efforts: ProviderModelDraft['reasoningEfforts']): string =>
      efforts === false
        ? 'none'
        : efforts === undefined
          ? ''
          : Object.entries(efforts).map(([level, wire]) => `${level}=${wire ?? ''}`).join(';')

    const encodeModelsLine = (models: readonly ProviderModelDraft[]): string =>
      models.map(encodeModelLine).join(' ')

    /** An entry with no `|` is just an id, which is what the flat list used to carry. */
    const parseModelsLine = (line: string): ProviderModelDraft[] =>
      line.split(/\s+/).map(part => part.trim()).filter(part => part !== '').map(part => {
        const bits = part.split('|')
        const id = (bits[0] ?? '').trim()
        const name = (bits[1] ?? '').trim()
        const efforts = (bits[2] ?? '').trim()
        const effort = (bits[3] ?? '').trim()
        const contextWindow = (bits[4] ?? '').trim()
        const maxTokens = (bits[5] ?? '').trim()
        return {
          id,
          ...(name === '' ? {} : { name }),
          ...(efforts === '' ? {} : { reasoningEfforts: efforts === 'none' ? false as const : (() => {
            const map: Record<string, string | null> = {}
            for (const pair of efforts.split(';')) {
              const index = pair.indexOf('=')
              if (index < 0) continue
              map[pair.slice(0, index)] = pair.slice(index + 1) === '' ? null : pair.slice(index + 1)
            }
            return map
          })() }),
          ...(effort === '' ? {} : { reasoningEffort: effort }),
          ...(contextWindow === '' ? {} : { contextWindow: Number(contextWindow) }),
          ...(maxTokens === '' ? {} : { maxTokens: Number(maxTokens) }),
        }
      })

    /**
     * The provider draft for the form, read through the host's own settings and
     * credential seams. The renderer's `form-spec` reads it, so the form shows the
     * profile the host owns.
     *
     * `templateId` / `templateName` carry the preset a new provider starts from; the
     * preset picker is UI, so it stays in the caller.
     */
    const providerDraftFor = async (
      providerId: string | undefined,
      templateId = '',
      templateName = '',
    ): Promise<ProviderDraft> => {
      const existing = providerId === undefined ? undefined : providerCatalog.find(candidate => candidate.id === providerId)
      const profile = providerId === undefined ? undefined : configuredProviderProfiles()[providerId]
      const id = providerId ?? templateId
      const apiKeyEnv = profile?.apiKeyEnv
      const apiKeyConfigured = apiKeyEnv === undefined
        ? false
        : await (async () => {
          const credentials = ctx.get('credentials') as { describe?: (ref: string) => Promise<{ configured: boolean }> } | undefined
          if (credentials?.describe === undefined) return true
          try {
            return (await credentials.describe(apiKeyEnv)).configured
          } catch {
            return false
          }
        })()
      return {
        id,
        name: profile?.displayName ?? existing?.name ?? templateName,
        api: profile?.api ?? '',
        baseURL: profile?.baseURL ?? '',
        apiKey: '',
        apiKeyEnv: profile?.apiKeyEnv,
        apiKeyConfigured,
        models: profile?.models?.map(model => ({
          id: model.id,
          ...(model.name === undefined ? {} : { name: model.name }),
          ...(model.reasoningEfforts === undefined ? {} : { reasoningEfforts: model.reasoningEfforts }),
          ...(typeof model.contextWindow === 'number' ? { contextWindow: model.contextWindow } : {}),
          ...(typeof model.maxTokens === 'number' ? { maxTokens: model.maxTokens } : {}),
        }))
          ?? modelCatalog.filter(model => model.provider === id).map(model => ({
            id: model.model,
          })),
      }
    }

    const saveProvider = async (providerId: string | undefined, draft: ProviderDraft): Promise<void> => {
      if (settings === undefined) throw new Error('settings unavailable')
      const id = draft.id.trim()
      if (id === '') throw new Error(t('providerIdRequired'))
      if (providerId !== undefined && providerId !== id) throw new Error(t('providerIdInvalid'))
      const target = providerSettingsTarget(id, providerId)
      if (target === undefined) throw new Error(t('settingsDiscoveryUnavailable'))
      const nestedProfile = target.entry.settingsPath.length > 0
      const catalogEntry = configurableProviderList().find(entry => entry.provider === id)
      const isCatalogProvider = catalogEntry?.declared === false || !nestedProfile
      if (nestedProfile && !isCatalogProvider && draft.models.length === 0) throw new Error(t('providerModelsRequired'))

      const apiKeyEnv = draft.apiKeyEnv ?? (draft.apiKey.trim() === '' ? undefined : credentialReference(id))
      if (draft.apiKey.trim() !== '') {
        const credentials = ctx.get('credentials') as { set?: (ref: string, value: string) => Promise<void> } | undefined
        if (credentials?.set === undefined || apiKeyEnv === undefined) {
          throw new Error('credentials service unavailable')
        }
        await credentials.set(apiKeyEnv, draft.apiKey.trim())
      }

      type SettingsMutation =
        | { op: 'set'; path: readonly string[]; value: unknown }
        | { op: 'unset'; path: readonly string[] }
      const ops: SettingsMutation[] = []
      const set = (field: string, value: unknown): void => { ops.push({ op: 'set', path: [...target.path, field], value }) }
      const unset = (field: string): void => { ops.push({ op: 'unset', path: [...target.path, field] }) }
      if (nestedProfile) {
        const displayName = draft.name.trim()
        if (displayName === '' || displayName === id) unset('displayName')
        else set('displayName', displayName)
        if (draft.api.trim() === '') unset('api')
        else set('api', draft.api.trim())
        if (draft.models.length === 0) unset('models')
        else set('models', draft.models.map(model => {
          const reasoningEfforts = parseReasoningEffortSetting(model.reasoningEfforts)
          return {
            id: model.id,
            ...(model.name === undefined || model.name === '' ? {} : { name: model.name }),
            ...(typeof model.contextWindow === 'number' ? { contextWindow: model.contextWindow } : {}),
            ...(typeof model.maxTokens === 'number' ? { maxTokens: model.maxTokens } : {}),
            ...(reasoningEfforts === undefined ? {} : { reasoningEfforts }),
          }
        }))
      }
      if (draft.baseURL.trim() === '') unset('baseURL')
      else set('baseURL', draft.baseURL.trim())
      if (apiKeyEnv !== undefined) set('apiKeyEnv', apiKeyEnv)
      await settings.mutate(target.ns, ops)
      reasoningEffortCache = undefined
      appendNotice(t('noticeProviderSaved'), 'info')
      rendererCatalogPush?.()
    }

    // Provider configuration belongs to the adapter that declares it through
    // dsh-llm's configurable-provider directory. The TUI only follows the
    // declared namespace/path and never invents a provider-owned namespace.
    // The renderer owns the theme catalog and picks its own palette, so the host
    // keeps no theme selection, override table, or `/theme` command.
    // 0.5.0 renames the settings rows. Values written under the pre-0.5.0 row
    // ids are read synchronously from the profile patch layer so they are
    // available before the first paint, then persisted into the new namespaces
    // after startup (`persistLegacySettings`). The new namespace wins, the
    // legacy row fills gaps, and defaults fill what neither carries.
    const legacySettings = readLegacySettings(ctx)
    const legacyRow = legacySettings.tui as TuiSettings | undefined
    const persistedTheme = settingsValues(ctx, TUI_SETTINGS_NAMESPACE) as TuiSettings | undefined
    const pick = <K extends keyof TuiSettings>(key: K): TuiSettings[K] | undefined =>
      persistedTheme?.[key] ?? legacyRow?.[key]
    // Runtime presentation state; `/settings` can persist these through the
    // same TUI settings namespace.
    let showReasoning = pick('showReasoning') ?? resolved.showReasoning
    let maxToolOutputLines = pick('maxToolOutputLines') ?? resolved.maxToolOutputLines
    // The footer templates are read straight from the settings section the renderer
    // receives (`settingsSection`), so the host keeps no second copy: an edit in the
    // settings page is the one value both sides paint.
    let keyTools = pick('keyTools') ?? 'ctrl+o'
    let keyReasoning = pick('keyReasoning') ?? 'ctrl+t'
    const programConfigStore = new ProgramConfigStore()
    const savedLastSelection = () => programConfigStore.current().config.lastSelection
    const resolveDefaultMode = (): string => savedLastSelection()?.preset ?? ctx.agentPresets?.defaultId ?? resolved.mode
    let uiMode: string = resolveDefaultMode()
    // Roster display names (id → name); refreshed from ctx.agentPresets.list().
    const presetNames = new Map<string, string>()
    const permissionCommand = permissionCommandMetadata(ctx.permissionPresets, t)
    /** Merge a route/preset update into program config; provider+model are required. */
    const saveLastSelection = (patch: {
      readonly provider?: string
      readonly model?: string
      readonly effort?: string
      readonly preset?: string
    }): void => {
      const existing = savedLastSelection()
      const provider = patch.provider ?? existing?.provider
      const model = patch.model ?? existing?.model
      if (provider === undefined || model === undefined) return
      const effort = patch.effort ?? existing?.effort
      const preset = patch.preset ?? existing?.preset
      try {
        programConfigStore.setLastSelection({
          provider,
          model,
          ...(effort === undefined ? {} : { effort }),
          ...(preset === undefined ? {} : { preset }),
        })
      } catch (error: unknown) {
        appendNotice(t('noticeDefaultModelFailed', { error: errorChain(error) }), 'warning')
      }
    }

    /** The package root, so `renderer/dist` of a development build is found from `lib/index.js`. */
    const packageRoot = join(import.meta.dirname, '..')
    let rendererMount: RendererMount | undefined

    // Community extension seams (dsh-ecosystem-spec v0.15): the TUI row
    // provides the renderer-coupled services and installs pi-tui backends
    // below once `appendNotice`/`palette` are available.
    const extensions: ExtensionServices = createExtensionServices()
    ctx.provide('tuiDialogs', extensions.dialogs)
    ctx.provide('tuiStatus', extensions.status)
    ctx.provide('tuiShortcuts', extensions.shortcuts)
    ctx.provide('tuiRenderers', extensions.renderers)
    ctx.provide('tuiSettingsSections', extensions.settingsSections)
    ctx.provide('tuiScenes', extensions.scenes)
    const pluginHost = ctx.get('tuiPluginHost', false) as TuiPluginHost | undefined

    // Warn once when the profile's harness tree drifts from the validated
    // upstream line. The check is best-effort and never blocks startup.
    void upstreamDriftWarnings(join(import.meta.dirname, '..', '..', '..')).then(warnings => {
      for (const warning of warnings) enqueueBootNotice(warning, 'warning')
    })

    /** The grid the renderer last reported. The renderer owns the TTY, so this is the only
     * geometry the host has; `/doctor` shows it, and the transcript caps read it. */
    let rendererGrid: { width: number; height: number } | undefined
    /** The renderer's snapshot re-send hook, registered by the renderer mount. A session
     * switch publishes the new agent in the agent setup path, which is outside the mount's
     * scope, so the mount hands the hook here and the switch calls it. */
    let rendererSnapshotPush: (() => void) | undefined
    /** Route-only repaint hook. Model/effort picks use this instead of a full snapshot so the
     * transcript is not rebuilt and the preset row cannot flash a stale default. */
    let rendererSelectionPush: ((options?: { permission?: string; preset?: string }) => void) | undefined
    /** The renderer's send seam, captured on the handshake ack. The host's notices, the
     * snapshot re-send on a session switch, and the rail refresh all go through it; before
     * the ack the mount buffers sends in order, so nothing is lost. */
    let rendererSend: ((kind: string, payload: unknown) => void) | undefined
    /** The renderer's model-catalog re-send hook, registered by the mount. A provider
     * save adds a provider, so the catalog the renderer's model picker shows has to be
     * rebuilt from the provider list; the mount registers the builder here and the
     * provider seam calls it after a save. */
    let rendererCatalogPush: (() => void) | undefined
    /** The whole per-session catalog set (efforts, presets, permission, models). A pick moves
     * the route, and the effort list belongs to the route: the mount re-runs this after a
     * selection so the picker and the effort dialog follow the model that was just chosen. */
    let rendererCatalogsPush: (() => void) | undefined

    /**
     * The `/doctor` report rows. Shared by the pi-tui card and the renderer's
     * `doctor-check` alert, so both paths print the same report from one place.
     */
    const doctorRows = async (check: boolean): Promise<string[]> => {
      const rows: string[] = ['doctor:']
      if (pluginHost === undefined) {
        rows.push('plugin host unavailable')
      } else {
        const selfCheck = pluginHost.selfCheck()
        rows.push(selfCheck.length > 0 ? `self-check: ${selfCheck.join('; ')}` : 'self-check: ok')
        const descriptor = pluginHost.buildHostDescriptor({ commandsMounted: true })
        rows.push(`contracts advertised: ${descriptor.contracts.length}`)
        rows.push(`generation: ${pluginHost.generationId}`)
      }
      rows.push(`verified dsh lines: ${UPSTREAM_VALIDATED_VERSIONS.join(', ')} (see verify:contract)`)
      rows.push(rendererGrid === undefined ? 'renderer grid: not reported' : `renderer grid: ${rendererGrid.width}x${rendererGrid.height}`)
      if (check) {
        // The profile root is three levels above this module's directory
        // (profiles/tui/node_modules/my-dpsk-harness-tui/lib), which is where the
        // harness and std protocol packages resolve.
        const warnings = await upstreamDriftWarnings(join(import.meta.dirname, '..', '..', '..'))
        rows.push(warnings.length === 0 ? 'contract probe: ok' : `contract probe: ${warnings.join('; ')}`)
      }
      return rows
    }

    /**
     * The `/plugins` report rows, shared for the same reason. `target` is the text
     * after `/plugins`, which carries the optional `check <path>` argument.
     */
    const pluginRows = async (target: string): Promise<string[]> => {
      const rows: string[] = []
      rows.push('trust: plugins run trusted-in-process; grants are behaviour, not a security boundary')
      const hostDescriptor = pluginHost?.buildHostDescriptor({ commandsMounted: true })
      rows.push(`host: ${hostDescriptor?.hostId ?? 'my-dpsk-harness-tui'} ${hostDescriptor?.hostVersion ?? ''} · generation ${pluginHost?.generationId ?? 'unavailable'}`)
      if (target.startsWith('check ')) {
        const path = target.slice('check '.length).trim()
        if (path === '') {
          rows.push('usage: /plugins check <path>')
        } else {
          try {
            const raw = await readFile(path, 'utf8')
            const manifest = parseManifest(JSON.parse(raw))
            const granted = pluginHost?.grants.grantedPermissions(manifest.id) ?? new Set<string>()
            const result = negotiate(manifest, { grantedPermissions: granted })
            rows.push(`check ${path}: ${result.status}`)
            for (const decision of result.contractDecisions) {
              rows.push(`- ${decision.coordinate}: ${decision.status}${decision.reason === undefined ? '' : ` (${decision.reason})`}`)
            }
          } catch (error: unknown) {
            rows.push(`check failed: ${error instanceof Error ? error.message : String(error)}`)
          }
        }
      } else if (target !== '') {
        rows.push('usage: /plugins [check <path>]')
      }
      if (pluginHost === undefined) {
        rows.push('plugin host unavailable')
      } else {
        const selfCheck = pluginHost.selfCheck()
        rows.push(selfCheck.length > 0 ? `self-check: ${selfCheck.join('; ')}` : 'self-check: ok')
        const admissions = pluginHost.activeAdmissions()
        rows.push(`admissions: ${admissions.length}`)
        for (const admission of admissions) {
          rows.push(`- ${admission.componentId} ${admission.activationInstance} ${admission.negotiation.status}`)
        }
        const ledger = await pluginHost.ledger.tail(5)
        rows.push('ledger (last 5):')
        for (const entry of ledger) {
          rows.push(`- ${entry.operation} ${entry.scope} ${entry.resource} ${entry.pluginId}`)
        }
        const snapshot = pluginHost.grants.snapshot()
        const grantRules = Object.keys(snapshot.grants).length
        const denyRules = Object.keys(snapshot.denies).length
        rows.push(`grants: ${grantRules} grant rules, ${denyRules} deny rules${snapshot.failedClosed ? ', FAILED CLOSED' : ''}`)
      }
      return rows
    }

    // The agent is published asynchronously on the resume path (persistence
    // load), so agent-dependent setup runs in mount() once it is live.
    let agent: Agent | undefined
    let gitBranch: string | undefined
    /** Running token usage for the active session; kept incrementally to avoid rescanning the whole log on every status update. */
    /**
     * Running token usage for the active session. Folded through `foldUsageSample`, which
     * also tracks whether every sample carried both cache buckets.
     */
    let usageFold: UsageFold = EMPTY_USAGE_FOLD
    let usageCostFold: UsageCostFold = EMPTY_USAGE_COST_FOLD
    // Agent-scoped helpers handed to the command surface by mount().
    const handles: {
      newAgent: (() => Promise<SessionId | undefined>) | undefined
      switchAgent: ((id: SessionId) => Promise<void>) | undefined
      saveSelection: ((selection: ModelSelection) => Promise<void>) | undefined
      setReasoningEffort: ((effort: NonNullable<ModelSelection['reasoningEffort']>) => Promise<void>) | undefined
      selectionRef: ModelSelectionRef | undefined
    } = {
      newAgent: undefined,
      switchAgent: undefined,
      saveSelection: undefined,
      setReasoningEffort: undefined,
      selectionRef: undefined,
    }
    const reasoningEffortsFor = async (selection: ModelSelection): Promise<readonly LlmReasoningEffortInfo[]> => {
      const route = `${selection.provider}\u0000${selection.model}`
      if (reasoningEffortCache?.route === route) return reasoningEffortCache.efforts
      const info = await ctx.llm.resolveModelInfo(selection.provider, selection.model)
      const efforts = info.reasoning?.efforts ?? []
      reasoningEffortCache = { route, efforts }
      return efforts
    }

    // The renderer owns the TTY; notices ride the IPC toast overlay. Before the handshake
    // ack the send seam is not captured, so notices stay buffered and flush in order.
    const pendingNotices: Array<{ text: string; kind: 'info' | 'warning' | 'error' }> = []

    const appendNotice = (text: string, kind: 'info' | 'warning' | 'error'): void => {
      // The renderer owns the TTY, so its toast overlay is the notice surface: the level
      // rides in the payload and picks the border color. Before the mount exists the
      // notices stay buffered; the mount's own send seam buffers pre-ack sends in order.
      if (rendererMount !== undefined) {
        rendererMount.handle.send('boot-notice', { text, kind })
        return
      }
      pendingNotices.push({ text, kind })
    }


    /**
     * A persisted session is blank when its head carries setup/bookkeeping only. Reading
     * only the head mirrors the renderer's blank detection and avoids loading a whole log
     * just to decide whether `/resume` should show it. A read failure keeps the row visible:
     * hiding an unreadable real conversation is worse than showing one extra row.
     */
    const isBlankStoredSession = async (id: SessionId): Promise<boolean> => {
      const handle = await ctx.sessionPersistence.open(id, 'read')
      try {
        const { events } = await handle.read(0, SESSION_HEAD_SCAN_EVENTS)
        return !events.some(hasConversationEvent)
      } finally {
        await handle.close()
      }
    }

    /** Revision-cached tail reads shared by `/resume` and the renderer's session list. */
    const sessionActivity = new SessionActivityResolver(ctx.sessionPersistence)

    /**
     * The one-time 0.5.0 startup migrations, run once per process after the settings
     * layer is live and before the first frame's notices flush:
     *
     * 1. `cli.json` (opencode's own TUI file) is imported into `dpsk-tui` once, guarded
     *    by the `cliImportedAt` stamp so a restart writes nothing;
     * 2. legacy `tui` / `session-title-llm-tui` row values move into the renamed
     *    namespaces;
     * 3. the retired theme triple maps onto the native `themeName` / `themeMode`.
     *
     * Each step reports what it did; a settings backend that is absent (no profile) is a
     * silent no-op rather than a startup failure.
     */
    let migrationsRan = false
    const runStartupMigrations = async (): Promise<void> => {
      if (migrationsRan) return
      migrationsRan = true
      // Remove conversation-less artifacts left by builds before conversation-gated
      // persistence. This runs even when the settings backend is absent, and treats every
      // read/delete failure as non-fatal.
      const home = process.env.DSH_HOME ?? join(homedir(), '.dsh')
      const cleanupStampPath = join(home, 'dpsk', 'startup-cleanup.json')
      let cleanupDue = true
      try {
        const stamp = JSON.parse(readFileSync(cleanupStampPath, 'utf8')) as { at?: unknown }
        cleanupDue = typeof stamp.at !== 'number' || Date.now() - stamp.at >= STARTUP_CLEANUP_INTERVAL_MS
      } catch {
        // Missing/corrupt stamp: run once, then write a fresh one.
      }
      if (cleanupDue) try {
        const snapshots = await ctx.sessionPersistence.list()
        const candidateIds = new Set(snapshots
          .map(snapshot => String(snapshot.header.id))
          .filter(id => id.startsWith('tui-')))
        if (candidateIds.size > 0) {
          const liveIds = new Set(ctx.agents.list().map(candidate => String(candidate.session.id)))
          const report = await pruneBlankTuiSessionDirectories({
            root: join(home, 'sessions'),
            candidateIds,
            liveIds,
            isBlank: id => isBlankStoredSession(SessionId(id)),
          })
          if (report.removed.length > 0) {
            appendNotice(`Removed ${String(report.removed.length)} empty TUI session${report.removed.length === 1 ? '' : 's'}`, 'info')
          }
          if (report.failed.length > 0) {
            appendNotice(`Could not inspect ${String(report.failed.length)} empty TUI session${report.failed.length === 1 ? '' : 's'}; kept them`, 'warning')
          }
        }
        try {
          mkdirSync(dirname(cleanupStampPath), { recursive: true })
          writeFileSync(cleanupStampPath, `${JSON.stringify({ at: Date.now() })}\n`, 'utf8')
        } catch {
          // A missing stamp only means the next process retries cleanup.
        }
      } catch (error: unknown) {
        appendNotice(`Empty-session cleanup skipped: ${errorChain(error)}`, 'warning')
      }
      const forms = ctx.settings
      if (forms === undefined) return
      const current = (settingsValues(ctx, TUI_SETTINGS_NAMESPACE) ?? {}) as Record<string, unknown>
      try {
        const path = current.cliImportedAt === undefined ? cliConfigPath(process.env) : undefined
        const document = path === undefined ? undefined : readCliConfig(path)
        if (path !== undefined && document !== undefined) {
          const plan = cliImportPlan(document)
          const { writable, skipped } = filterCliImportPatch(plan.patch, current)
          const patch = { ...writable, cliImportedAt: new Date().toISOString() }
          await forms.update(TUI_SETTINGS_NAMESPACE, patch)
          for (const line of formatCliImportReport(plan, skipped, path)) appendNotice(line, 'info')
        }
      } catch (error: unknown) {
        appendNotice(`cli.json import failed: ${errorChain(error)}`, 'warning')
      }
      try {
        const legacy = readLegacySettings(ctx)
        const report = await persistLegacySettings(ctx, legacy)
        await migrateLegacyTheme(ctx, legacy.tui, report)
        for (const line of formatMigrationReport(report, legacy.source)) appendNotice(line, 'info')
      } catch (error: unknown) {
        appendNotice(`settings migration failed: ${errorChain(error)}`, 'warning')
      }
    }

    // Managed dialog backend: the FIFO queue lives in DialogsService; the renderer draws
    // each modal through its own dialog stack. The host keeps the request id → resolver
    // map; the answer rides `extension-dialog-response` back on the same id. A dialog
    // requested before the mount exists fails closed — the renderer owns the TTY, so
    // there is no pi-tui overlay left to draw it in.
    const extensionDialogs = new Map<number, (value: string | undefined) => void>()
    let extensionDialogSeq = 0
    const extensionDialog = (payload: {
      kind: 'select' | 'confirm' | 'input'
      title: string
      options?: { id: string; label: string; description?: string }[]
      confirmLabel?: string
      cancelLabel?: string
      initial?: string
      placeholder?: string
    }): Promise<string | undefined> => new Promise(resolve => {
      if (rendererMount === undefined) {
        resolve(undefined)
        return
      }
      const requestId = ++extensionDialogSeq
      extensionDialogs.set(requestId, value => {
        extensionDialogs.delete(requestId)
        resolve(value)
      })
      rendererMount.handle.send('extension-dialog', { requestId, ...payload })
    })
    extensions.dialogs.installBackend({
      select: request => extensionDialog({
        kind: 'select',
        title: request.title,
        options: request.options.map(option => ({
          id: option.id,
          label: option.label,
          ...option.description === undefined ? {} : { description: option.description },
        })),
      }),
      confirm: request => extensionDialog({
        kind: 'confirm',
        title: request.title,
        initial: request.message,
        confirmLabel: request.confirmLabel,
        cancelLabel: request.cancelLabel,
      }).then(value => value === 'yes'),
      input: request => extensionDialog({
        kind: 'input',
        title: request.title,
        initial: request.initial,
        placeholder: request.placeholder,
      }),
    })

    // Scene backend: the renderer has no scene host (its surface is the fixed
    // transcript/composer/palette layout), so plugin scenes fail closed. The deviation
    // from the React scene contract is documented in docs/contracts.md.
    extensions.scenes.installBackend({
      open: () => false,
      close: () => undefined,
    })

    const warnIfFullAccess = (target: Agent): void => {
      if (currentPermissionPreset(ctx, target.session) === FULL_ACCESS_REGISTRY_NAME) {
        appendNotice(t('noticeFullAccessWarning'), 'warning')
      }
    }

    // 微信桥输出不直接写 stderr：日志/二维码作为持久化文本进入 transcript，
    // 与 `/help` 的静态卡片一样保留在终端中，且不会越过差分渲染器覆盖输入框。
    // 普通运行日志不展示；error 类走临时通知，status 更新到固定占位行。
    const wechatErrorLog = /(?:error|failed|crash|refused|timed?\s*out|失败|错误|异常|❌)/i
    /**
     * Subscribe to the WeChat bridge's persistent output. The bridge replays its
     * buffer on subscribe, so a QR code produced before the UI existed is not lost.
     * `undefined` when the bridge is not deployed (no `wechat` service) — the caller
     * treats that as "no bridge", not as an error.
     */
    const subscribeWechat = (emit: (message: WechatOutputMessage) => void): (() => void) | undefined => {
      let bridge: WechatBridge | undefined
      try {
        bridge = ctx.get('wechat') as WechatBridge | undefined
      } catch {
        bridge = undefined
      }
      if (bridge?.subscribeOutput === undefined) return undefined
      return bridge.subscribeOutput(emit)
    }

    /**
     * The subagent list, shared by the pi-tui panel and the renderer. The same
     * `subagent/descriptor` event feeds both, so the two paths cannot disagree about
     * which subagents exist. The list is pushed to the renderer on subscribe (the
     * renderer starts empty) and on every change.
     */
    const foregroundSessionId = (): string => String(agent?.session.id ?? sessionId)
    const subagentListeners = new Set<(sessionId: string, agents: readonly SubagentDescriptor[]) => void>()
    /** Descriptor metadata keyed by the subagent child session id. */
    const subagentById = new Map<string, SubagentDescriptor>()
    const rememberSubagentDescriptor = (session: Session): SubagentDescriptor | undefined => {
      if (session.header.origin !== 'subagent') return undefined
      const id = String(session.id)
      const known = subagentById.get(id)
      if (known !== undefined) return known
      for (const event of sessionEvents(session)) {
        if (event.type !== 'subagent/descriptor') continue
        const descriptor: SubagentDescriptor = { label: event.data.label, provider: event.data.provider, mode: event.data.mode }
        subagentById.set(id, descriptor)
        return descriptor
      }
      return undefined
    }
    const loadSubagentDescriptor = async (id: string): Promise<SubagentDescriptor | undefined> => {
      const known = subagentById.get(id)
      if (known !== undefined) return known
      try {
        const handle = await ctx.sessionPersistence.open(SessionId(id), 'read')
        try {
          const { events } = await handle.read(0, 64)
          for (const event of events) {
            if (event.type !== 'subagent/descriptor') continue
            const descriptor: SubagentDescriptor = { label: event.data.label, provider: event.data.provider, mode: event.data.mode }
            subagentById.set(id, descriptor)
            return descriptor
          }
        } finally {
          await handle.close()
        }
      } catch {
        // An unreadable child stays fail-closed: the renderer treats it as one-shot.
      }
      return undefined
    }
    const subagentList: SubagentDescriptor[] = []
    const notifySubagents = (sourceSessionId = foregroundSessionId()): void => {
      for (const listener of subagentListeners) listener(sourceSessionId, [...subagentList])
    }
    const subscribeSubagents = (emit: (sessionId: string, agents: readonly SubagentDescriptor[]) => void): (() => void) => {
      subagentListeners.add(emit)
      emit(foregroundSessionId(), [...subagentList])
      return () => subagentListeners.delete(emit)
    }
    const addSubagent = (sourceSessionId: string, descriptor: SubagentDescriptor): void => {
      subagentList.push(descriptor)
      notifySubagents(sourceSessionId)
    }
    const clearSubagents = (): void => {
      subagentList.length = 0
      notifySubagents()
    }

    const skillListeners = new Set<(sessionId: string, skills: readonly SkillSpec[]) => void>()
    const skillList: SkillSpec[] = []
    const notifySkills = (sourceSessionId = foregroundSessionId()): void => {
      for (const listener of skillListeners) listener(sourceSessionId, [...skillList])
    }
    const subscribeSkills = (emit: (sessionId: string, skills: readonly SkillSpec[]) => void): (() => void) => {
      skillListeners.add(emit)
      emit(foregroundSessionId(), [...skillList])
      return () => skillListeners.delete(emit)
    }


    // --- status -----------------------------------------------------------
    let currentScheme: TerminalColorScheme = 'dark'

    // --- interjection queue -------------------------------------------------
    // While the agent is running, Enter queues the composed text as an
    // interjection (`agent.steer`) instead of a normal follow-up. The loop
    // claims it at the next step boundary, so it reaches the model right after
    // the in-flight tool call settles (or immediately after the current model
    // message when there are no tool calls). Entries are removed from this list
    // once their matching `user/message` event is rendered.
    const pendingInterjections: Array<{ sessionId: string; message: ReturnType<typeof createUserMessage>; text: string }> = []

    const refreshInterjectionIndicator = (): void => {
      // The drawer shows the queue the host owns; every mutation path already calls this
      // function, so the push rides the same seam.
      const sourceSessionId = foregroundSessionId()
      const items = pendingInterjections.filter(entry => entry.sessionId === sourceSessionId).map(entry => ({ id: entry.message.id, text: entry.text }))
      rendererSend?.('interject-list', { sessionId: sourceSessionId, items })
      for (const emit of queueListeners) emit(sourceSessionId, items)
    }

    const enqueueInterjection = (text: string): void => {
      const current = agent
      if (current === undefined) return
      const message = createUserMessage({
        content: [{ type: 'text', text }],
        source: { kind: 'user' },
      })
      pendingInterjections.push({ sessionId: String(current.session.id), message, text })
      try {
        current.steer(message)
      } catch (error: unknown) {
        const index = pendingInterjections.findIndex(entry => entry.sessionId === String(current.session.id) && entry.message.id === message.id)
        if (index !== -1) pendingInterjections.splice(index, 1)
        refreshInterjectionIndicator()
        return
      }
      appendNotice(t('noticeInterjectionQueued'), 'info')
      refreshInterjectionIndicator()
      updateStatusValues()
    }

    /**
     * Remove one still-pending interjection from the exact session inbox before it
     * takes effect. Without an id, the oldest message for that session is selected.
     */
    const takeOldestInterjection = (request?: { sessionId?: string; id?: string }): string | undefined => {
      const sessionId = request?.sessionId ?? (agent === undefined ? '' : String(agent.session.id))
      if (sessionId === '') return undefined
      const current = ctx.agents.get(SessionId(sessionId))
      if (current === undefined) return undefined
      const index = pendingInterjections.findIndex(entry => entry.sessionId === sessionId
        && (request?.id === undefined || entry.message.id === request.id))
      if (index === -1) return undefined
      const item = pendingInterjections.splice(index, 1)[0]
      if (item === undefined) return undefined
      try {
        if (!current.inbox.remove(item.message.id)) {
          refreshInterjectionIndicator()
          updateStatusValues()
          appendNotice(t('noticeInterjectionAlreadyEffective'), 'warning')
          return undefined
        }
        refreshInterjectionIndicator()
        updateStatusValues()
        appendNotice(t('noticeInterjectionEdit'), 'info')
        return item.text
      } catch (error: unknown) {
        pendingInterjections.splice(index, 0, item)
        refreshInterjectionIndicator()
        appendNotice(t('noticeInterjectionFailed', { error: errorChain(error) }), 'error')
        return undefined
      }
    }

    const deleteInterjection = async (request: { sessionId: string; id: string }): Promise<void> => {
      const current = ctx.agents.get(SessionId(request.sessionId))
      if (current === undefined) throw new Error(`session ${request.sessionId} is not live`)
      if (current.session.header.origin === 'subagent') throw new Error('subagent sessions are read-only')
      const index = pendingInterjections.findIndex(entry => entry.sessionId === request.sessionId && entry.message.id === request.id)
      const item = pendingInterjections[index]
      if (item === undefined) throw new Error(`queued message ${request.id} is no longer pending`)
      if (!current.inbox.remove(MessageId(request.id))) throw new Error(`queued message ${request.id} is no longer pending`)
      pendingInterjections.splice(index, 1)
      refreshInterjectionIndicator()
      updateStatusValues()
    }

    /** Expensive status inputs (token meter + permission) are refreshed at most once per second. */
    const CONTEXT_USAGE_REFRESH_MS = 1_000
    let contextUsageCache: { measuredAt: number; totalTokens: number; permission: string } = {
      measuredAt: 0,
      totalTokens: 0,
      permission: '',
    }

    // Usage, branch, todo, and queue pushes are session-scoped host projections. MCP server
    // names and Loader plugin inventory are global snapshots sent at handshake; no admission
    // status is relabeled as MCP connection state.
    const usageListeners = new Set<(usage: UsagePayload) => void>()
    const commandFileReceipts = new Map<string, { readonly sessionId: string; readonly ref: FileAttachmentRef }>()
    const detachCommandFileReceiptResolver = ctx.commands.registerFileReceiptResolver((target, receiptId) => {
      const entry = commandFileReceipts.get(receiptId)
      return entry?.sessionId === String(target.session.id) ? entry.ref : undefined
    })
    ctx.effect(() => ctx.commands.register({
      name: 'restart',
      description: 'Restart dsh to reload DSH-side configuration',
      recordInput: false,
      handler: invocation => {
        if (process.env.DPSK_SUPERVISOR !== '1') {
          return {
            kind: 'error',
            text: '/restart is only available when the TUI is launched through dpsk.',
          }
        }
        const sessionId = String(invocation.agent.session.id)
        const hasConversation = sessionEvents(invocation.agent.session).length > 0
        try {
          writeJsonAtomic(join(programConfigStore.paths.runtime, 'restart.json'), {
            version: 1,
            sessionId: hasConversation ? sessionId : undefined,
            route: hasConversation ? 'session' : 'home',
            requestedAt: new Date().toISOString(),
          })
        } catch (error) {
          return {
            kind: 'error',
            text: `Could not write restart handoff: ${errorChain(error)}`,
          }
        }
        setTimeout(() => ctx.appExit?.(75), 25)
        return { kind: 'success', text: 'Restarting dsh to reload configuration...' }
      },
    }))
    ctx.effect(() => ctx.commands.register({
      name: 'price',
      description: 'Assign a price from price.json to the current model in custom_price.json',
      recordInput: false,
      input: { hint: 'price model id (blank to choose)' },
      handler: async invocation => {
        const route = handles.selectionRef?.current
        const provider = route?.provider ?? invocation.agent.options.provider
        const model = route?.model ?? invocation.agent.options.model
        if (provider === undefined || provider === '' || model === undefined || model === '') {
          return { kind: 'error', text: 'The current model route is unavailable.' }
        }
        const publicPrice = programConfigStore.publicPrice()
        const entries = Object.entries(publicPrice.models)
        const pick = async (): Promise<string | undefined> => {
          if (entries.length === 0) return undefined
          return extensionDialog({
            kind: 'select',
            title: `Price for ${provider}/${model}`,
            options: entries.map(([key, entry]) => {
              const rates = entry.ratesPerMillion
              const cache = rates.cacheRead === undefined ? 'cache n/a' : `cache $${rates.cacheRead}/1M`
              return {
                id: key,
                label: key,
                description: `input $${rates.input}/1M · ${cache} · output $${rates.output}/1M`,
              }
            }),
          })
        }
        const query = invocation.rawInput.trim()
        let selectedKey: string | undefined
        if (query !== '') {
          selectedKey = publicPrice.models[query] === undefined
            ? findPricingModel(publicPrice, provider, query)?.key
            : query
          if (selectedKey === undefined) {
            return {
              kind: 'error',
              text: `No price entry matched "${query}". Edit custom_price.json manually or run /price to pick from price.json.`,
            }
          }
        } else {
          selectedKey = await pick()
          if (selectedKey === undefined) return { kind: 'success', text: 'Price selection cancelled.' }
        }
        const selected = publicPrice.models[selectedKey]
        if (selected === undefined) return { kind: 'error', text: `Price entry "${selectedKey}" is unavailable.` }
        try {
          programConfigStore.setCustomPrice(provider, model, selected)
        } catch (error) {
          return { kind: 'error', text: `Could not save custom price: ${errorChain(error)}` }
        }
        return {
          kind: 'success',
          text: `Saved ${provider}/${model} from price.json entry "${selectedKey}" to custom_price.json. Edit custom_price.json for future overrides; price.json is program-managed.`,
        }
      },
    }))
    const jobsRegistry = ctx.get('jobs')
    const detachJobController = jobsRegistry?.attachController('tui')
    const existingTerminalController = ctx.get('terminalController')
    let terminalController: TerminalControllerService | undefined = existingTerminalController === undefined
      ? undefined
      : adaptTerminalController(existingTerminalController, ctx)
    let terminalSetupFiber: { dispose: () => Promise<void> } | undefined
    const terminalFollowers = new Map<string, { readonly sessionId: string; readonly id: string; readonly attachmentId: string; readonly abort: AbortController; task?: Promise<void> }>()
    const terminalFollowerKey = (sessionId: string, id: string, attachmentId: string): string => `${sessionId}\0${id}\0${attachmentId}`
    const terminalRetains = new Map<string, { readonly abort: AbortController; task?: Promise<void> }>()
    /** Terminals this TUI created. Only these are closed on exit; a terminal another
     * surface owns stays alive, matching the controller's shared ownership. */
    const ownedTerminals = new Map<string, { readonly sessionId: string; readonly id: string }>()
    const ensureTerminalController = async (): Promise<void> => {
      if (terminalController !== undefined) return
      if (ctx.get('subprocess') === undefined || ctx.get('sandboxPolicy') === undefined || ctx.get('typert') === undefined) return
      const fiber = ctx.inject(['subprocess', 'sandboxPolicy', 'typert'], async injected => {
        const existing = injected.get('terminalController')
        if (existing !== undefined) {
          terminalController = adaptTerminalController(existing, injected)
          return
        }
        const { TerminalController } = await loadTerminalController()
        const pluginFiber = injected.plugin(TerminalController as never, {} as never)
        await pluginFiber.await()
        const created = injected.get('terminalController')
        if (created === undefined) throw new Error('terminal controller plugin did not provide terminalController')
        terminalController = adaptTerminalController(created, injected)
      })
      terminalSetupFiber = fiber
      await fiber.await()
      if (terminalController === undefined) throw new Error('terminal controller dependencies are unavailable')
    }
    const gitBranchListeners = new Set<(sessionId: string, branch: string | undefined) => void>()
    const todoListeners = new Set<(sessionId: string, items: readonly TodoItem[]) => void>()
    const queueListeners = new Set<(sessionId: string, items: readonly { id: string; text: string }[]) => void>()
    const turnStateListeners = new Set<(sessionId: string, running: boolean) => void>()
    let questionRequestSequence = 0
    const continuedQuestionControllers = new Set<AbortController>()
    const continuedQuestionTasks = new Set<Promise<void>>()
    const waitForContinuedQuestion = async (target: Agent, callId: ToolCallId, signal: AbortSignal): Promise<boolean> => {
      const projections = ctx.get('sessionProjections')
      if (projections === undefined) throw new Error('timed question projection is unavailable')
      const readState = (): boolean | undefined => {
        const view = projections.stateOf(target.session, 'userQuestions') as {
          readonly active?: readonly { readonly callId: ToolCallId; readonly state: string }[]
          readonly settled?: readonly { readonly callId: ToolCallId }[]
        } | undefined
        if (view?.active?.some(question => question.callId === callId && question.state === 'continued')) return true
        if (view?.settled?.some(question => question.callId === callId)) return false
        return undefined
      }
      const initial = readState()
      if (initial !== undefined) return initial
      if (signal.aborted) return false
      return new Promise<boolean>(resolve => {
        let settled = false
        let unsubscribe = (): void => undefined
        const finish = (value: boolean): void => {
          if (settled) return
          settled = true
          signal.removeEventListener('abort', abort)
          unsubscribe()
          resolve(value)
        }
        const abort = (): void => finish(false)
        unsubscribe = projections.onChanged((session, key, value) => {
          if (session.id !== target.session.id || key !== 'userQuestions') return
          const view = value as { readonly active?: readonly { readonly callId: ToolCallId; readonly state: string }[]; readonly settled?: readonly { readonly callId: ToolCallId }[] }
          if (view.active?.some(question => question.callId === callId && question.state === 'continued')) finish(true)
          else if (view.settled?.some(question => question.callId === callId)) finish(false)
        })
        signal.addEventListener('abort', abort, { once: true })
        const current = readState()
        if (current !== undefined) finish(current)
        else if (signal.aborted) abort()
      })
    }
    let lastUsage: UsagePayload | undefined
    let lastGitBranch: string | undefined
    let lastGitBranchSessionId = foregroundSessionId()
    let lastTodos: readonly TodoItem[] | undefined
    let lastTodosSessionId = foregroundSessionId()
    let estimatedContextWindow = DEFAULT_CONTEXT_WINDOW
    const notifyTurnState = (target: Agent): void => {
      const sourceSessionId = String(target.session.id)
      for (const emit of turnStateListeners) emit(sourceSessionId, target.status === 'running')
    }
    let contextEstimateRevision = 0
    const updateStatusValues = (): void => {
      const current = agent
      if (current === undefined) return
      const selection = handles.selectionRef?.current
      const recordedContext = current.session.requestContext()
      const recordedWindow = recordedContext !== undefined
        && selection !== undefined
        && recordedContext.provider === selection.provider
        && recordedContext.model === selection.model
        ? recordedContext.contextWindow
        : undefined
      const contextWindow = recordedWindow ?? estimatedContextWindow
      const now = Date.now()
      if (now - contextUsageCache.measuredAt >= CONTEXT_USAGE_REFRESH_MS) {
        let totalTokens = 0
        try {
          totalTokens = ctx.tokenMeter.measure(current.session).totalTokens
        } catch {
          // Before assembly, some providers cannot estimate the input. Show the
          // required zero fallback rather than hiding the context segment.
        }
        contextUsageCache = {
          measuredAt: now,
          totalTokens,
          permission: currentPermissionPreset(ctx, current.session),
        }
      }
      lastUsage = {
        sessionId: String(current.session.id),
        inputTokens: usageFold.totals.inputTokens,
        outputTokens: usageFold.totals.outputTokens,
        cacheReadTokens: usageFold.totals.cacheReadTokens,
        cacheWriteTokens: usageFold.totals.cacheWriteTokens,
        cacheReadObserved: usageFold.cacheReadObserved,
        cacheReadComplete: usageFold.cacheReadComplete,
        cacheWriteComplete: usageFold.cacheWriteComplete,
        cacheBucketsComplete: usageFold.cacheBucketsComplete,
        contextTokens: contextUsageCache.totalTokens,
        contextWindow,
        contextPct: contextWindow > 0 ? Math.round(contextUsageCache.totalTokens / contextWindow * 100) : undefined,
        ...(usageCostFold.pricedSamples > 0 && usageCostFold.unpricedSamples === 0
          ? { cost: usageCostFold.costUsd, currency: 'USD', costSource: 'local' as const }
          : {}),
        ...(usageCostFold.unpricedSamples > 0 ? { costUnavailable: true } : {}),
      }
      for (const emit of usageListeners) emit(lastUsage)
      refreshInterjectionIndicator()
    }

    const refreshGitBranch = (workspace: string): void => {
      const target = agent
      const targetSessionId = String(target?.session.id ?? sessionId)
      gitBranch = undefined
      void readGitBranch(workspace).then(branch => {
        if (agent !== target) return
        gitBranch = branch
        lastGitBranch = branch
        lastGitBranchSessionId = targetSessionId
        for (const emit of gitBranchListeners) emit(targetSessionId, branch)
        updateStatusValues()
      })
    }

    const refreshContextEstimate = (target: Agent, selection: ModelSelection): void => {
      const revision = ++contextEstimateRevision
      const recorded = target.session.requestContext()
      const recordedWindow = recorded !== undefined
        && recorded.provider === selection.provider
        && recorded.model === selection.model
        ? recorded.contextWindow
        : undefined
      estimatedContextWindow = recordedWindow ?? DEFAULT_CONTEXT_WINDOW
      if (target.id === agent?.id) {
        updateStatusValues()
      }
      // The recorded window belongs to the *last* request; the route's metadata is what the
      // next one will use. Preferring the recorded value outright left a resumed session
      // showing the old window after the profile changed a model's `contextWindow` — the bar
      // kept dividing by 262144 until the user sent another message. The recorded value stays
      // as the synchronous fallback, so the row never flashes the 1M default.
      void ctx.llm.resolveModelInfo(selection.provider, selection.model).then((info) => {
        if (revision !== contextEstimateRevision || target.id !== agent?.id) return
        estimatedContextWindow = info.context?.contextWindow ?? recordedWindow ?? DEFAULT_CONTEXT_WINDOW
        updateStatusValues()
      }).catch(() => {
        // Keep the recorded (or fallback) window when exact model metadata is unavailable.
      })
    }


    // --- transcript ---------------------------------------------------------
    // The renderer draws the transcript from `transcriptEvents` (the snapshot and the
    // per-event frames the mount dep sends), so the host keeps only the side effects
    // the durable events carry: token totals, the todo push, the interjection queue,
    // compaction/turn notices, and the subagent set.
    let live = false
    const hostEventEffects = (sourceSessionId: string, event: SessionEvent, notify: boolean): void => {
      switch (event.type) {
        case 'user/message': {
          // Interjections are durable user messages; once the loop appends one
          // it has taken effect and is no longer editable with Alt+Up.
          const pendingIndex = pendingInterjections.findIndex(entry => entry.sessionId === sourceSessionId && entry.message.id === event.data.id)
          if (pendingIndex >= 0) {
            pendingInterjections.splice(pendingIndex, 1)
            if (sourceSessionId === foregroundSessionId()) refreshInterjectionIndicator()
          }
          break
        }
        case 'assistant/message':
          if (event.data.usage !== undefined) {
            usageFold = foldUsageSample(usageFold, event.data.usage)
            const source = event.data.message.source
            const selection = handles.selectionRef?.current
            usageCostFold = foldUsageCost(usageCostFold, {
              time: event.time,
              provider: source?.provider ?? selection?.provider,
              model: source?.model ?? selection?.model,
              inputTokens: event.data.usage.inputTokens,
              outputTokens: event.data.usage.outputTokens,
              cacheReadTokens: event.data.usage.cacheReadTokens,
              cacheWriteTokens: event.data.usage.cacheWriteTokens,
            }, programConfigStore.price())
          }
          break
        case 'todo/write':
          lastTodos = event.data.todos
          lastTodosSessionId = sourceSessionId
          for (const emit of todoListeners) emit(sourceSessionId, event.data.todos)
          break
        case 'compaction/start':
          if (live && notify) appendNotice(t('noticeCompacting'), 'info')
          break
        case 'compaction/end':
          // Force token counts to re-measure: the compressed history is
          // dramatically smaller than the shadowed range.
          contextUsageCache.measuredAt = 0
          if (live && notify) {
            appendNotice(
              event.data.error === undefined ? t('noticeCompactionDone') : t('noticeCompactionFailed', { error: event.data.error }),
              event.data.error === undefined ? 'info' : 'error',
            )
          }
          break
        case 'turn/end':
          if (live && notify && event.data.reason.kind !== 'completed') {
            appendNotice(t('noticeTurnEnded', { reason: event.data.reason.kind }), 'warning')
          }
          break
        case 'subagent/descriptor':
          addSubagent(sourceSessionId, { label: event.data.label, provider: event.data.provider, mode: event.data.mode })
          break
        default:
          break
      }
    }

    /** Replay the durable session log for its side effects after a session switch. */
    const replayTranscript = (): void => {
      const current = agent
      if (current === undefined) return
      const sourceSessionId = String(current.session.id)
      clearSubagents()
      lastTodos = []
      lastTodosSessionId = sourceSessionId
      for (const emit of todoListeners) emit(sourceSessionId, lastTodos)
      usageFold = EMPTY_USAGE_FOLD
      usageCostFold = EMPTY_USAGE_COST_FOLD
      contextUsageCache.measuredAt = 0
      for (const event of sessionEvents(current.session)) hostEventEffects(sourceSessionId, event, false)
      updateStatusValues()
    }

    const repriceActiveUsage = (): void => {
      const current = agent
      if (current === undefined) return
      usageCostFold = EMPTY_USAGE_COST_FOLD
      for (const event of sessionEvents(current.session)) {
        if (event.type !== 'assistant/message' || event.data.usage === undefined) continue
        const source = event.data.message.source
        const selection = handles.selectionRef?.current
        usageCostFold = foldUsageCost(usageCostFold, {
          time: event.time,
          provider: source?.provider ?? selection?.provider,
          model: source?.model ?? selection?.model,
          inputTokens: event.data.usage.inputTokens,
          outputTokens: event.data.usage.outputTokens,
          cacheReadTokens: event.data.usage.cacheReadTokens,
          cacheWriteTokens: event.data.usage.cacheWriteTokens,
        }, programConfigStore.price())
      }
      updateStatusValues()
    }

    programConfigStore.onChange(() => {
      repriceActiveUsage()
    })

    const latestCompactionError = (): string | undefined => {
      if (agent === undefined) return undefined
      const events = sessionEvents(agent.session)
      for (let index = events.length - 1; index >= 0; index--) {
        const event = events[index]!
        if (event.type === 'compaction/end') {
          const error = (event.data as { error?: string } | undefined)?.error
          return typeof error === 'string' && error !== '' ? error : undefined
        }
      }
      return undefined
    }

    const recordActivePreset = (target: Agent): void => {
      const mounted = ctx.agentPresets?.composedPreset(target.ctx)
      const preset = mounted ?? resolveSessionPreset(ctx, target.session)
        ?? (target.id === agent?.id ? uiMode : undefined)
      if (preset !== undefined) recordConversationPreset(ctx, target.session, preset)
    }

    const toggleReasoning = (): void => {
      showReasoning = !showReasoning
      appendNotice(showReasoning ? t('noticeReasoningShown') : t('noticeReasoningHidden'), 'info')
    }

    const resetDisplay = (): void => {
      replayTranscript()
      rendererSnapshotPush?.()
      appendNotice(t('noticeDisplayReset'), 'info')
    }

    const cycleModel = async (direction: 1 | -1): Promise<void> => {
      const save = handles.saveSelection
      const selection = handles.selectionRef?.current
      if (save === undefined || selection === undefined) return
      try {
        const entries: ModelSelection[] = []
        for (const provider of ctx.llm.listProviders()) {
          try {
            const models = await ctx.llm.listModels(provider.id)
            for (const model of models) {
              entries.push({ provider: provider.id, model: model.id })
            }
          } catch {
            // Providers may expose no model catalog; the current selection
            // still participates below.
          }
        }
        const currentIndex = entries.findIndex(entry =>
          entry.provider === selection.provider && entry.model === selection.model)
        if (currentIndex !== -1 && entries.length > 1) {
          const target = entries[(currentIndex + direction + entries.length) % entries.length]!
          const next: ModelSelection = {
            provider: target.provider,
            model: target.model,
            ...selection.reasoningEffort === undefined ? {} : { reasoningEffort: selection.reasoningEffort },
          }
          await save(next)
          appendNotice(t('noticeModelSet', { provider: next.provider, model: next.model }), 'info')
        } else {
          appendNotice(t('noticeNoModels'), 'warning')
        }
      } catch (error: unknown) {
        appendNotice(t('noticeModelFailed', { error: errorChain(error) }), 'error')
      }
    }

    const runSessionSwitchDecision = async (current: Agent, kind: 'new' | 'resume', targetSessionId?: string): Promise<boolean> => {
      if (pluginHost === undefined) return true
      const payload: Record<string, unknown> = {
        kind,
        sessionId: String(current.session.id),
        cwd: current.session.header.cwd ?? process.cwd(),
      }
      if (targetSessionId !== undefined) payload.targetSessionId = targetSessionId
      const decision = await pluginHost.runDecision('tui/session-switch', payload)
      if (typeof decision === 'object' && decision !== null && 'cancel' in decision && decision.cancel === true) {
        const reason = 'reason' in decision && typeof decision.reason === 'string' ? decision.reason : undefined
        appendNotice(typeof reason === 'string' && reason !== '' ? reason : 'Session switch cancelled by a plugin', 'warning')
        return false
      }
      return true
    }
    const notifySessionSwitched = (kind: 'new' | 'resume', sessionId: string, previousSessionId: string): void => {
      if (pluginHost === undefined) return
      void pluginHost.runDecision('tui/session-switched', { kind, sessionId, previousSessionId })
    }

    const applyAgentPreset = async (target: Agent, preset: string, roster?: Awaited<ReturnType<NonNullable<typeof ctx.agentPresets>['list']>>): Promise<void> => {
      const presets = ctx.agentPresets
      if (presets === undefined) throw new Error('agent presets are unavailable')
      const available = roster ?? await presets.list()
      const definition = available.find(item => item.id === preset)
      if (available.length > 0 && (definition === undefined || definition.broken !== undefined)) {
        throw new Error(`agent preset ${preset} is unavailable`)
      }
      if (hasConversationData(sessionEvents(target.session))) throw new Error('agent preset can only change in an empty session')
      const currentPreset = presets.composedPreset(target.ctx)
      if (currentPreset === preset) return
      if (currentPreset === undefined) await presets.mount(target.ctx, preset)
      else await presets.recompose(target.ctx, preset)
      if (target.id === agent?.id) {
        uiMode = preset
        updateStatusValues()
        const route = handles.selectionRef?.current
        saveLastSelection({
          ...(route === undefined ? {} : { provider: route.provider, model: route.model, ...(route.reasoningEffort === undefined ? {} : { effort: String(route.reasoningEffort) }) }),
          preset,
        })
        if (rendererSelectionPush !== undefined) rendererSelectionPush({ preset })
        else rendererSnapshotPush?.()
      }
    }
    const runCommandWithAttachments = async (target: Agent, line: string, submitted: NonNullable<SendMessagePayload['attachments']>): Promise<void> => {
      const parsed = parseCommand(line)
      if (parsed === undefined) throw new Error('invalid slash command')
      const definition = ctx.commands.find(target, parsed.name)
      if (definition === undefined) throw new Error(`unknown command /${parsed.name}`)
      if (definition.input?.attachments !== true) throw new Error(`/${parsed.name} does not accept attachments`)
      const store = ctx.get('attachments')
      if (store === undefined) throw new Error('attachments are unavailable in this deployment')
      const commandAttachments: CommandSubmitAttachment[] = []
      const receipts: string[] = []
      try {
        let imageRouteChecked = false
        for (const attachment of submitted) {
          if (Buffer.byteLength(attachment.data, 'base64') > MAX_RENDERER_FILE_ATTACHMENT_BYTES) throw new Error('attachment exceeds the 20 MiB upload limit')
          if (attachment.type === 'image') {
            if (!imageRouteChecked) {
              const route = target.session.requestHeader()
              const provider = route?.config.provider ?? target.options.provider
              const model = route?.config.model ?? target.options.model
              if (provider === undefined || model === undefined) throw new Error('image attachment route is unavailable')
              const info = await ctx.llm.resolveModelInfo(provider, model)
              if (!info.inputModalities?.includes('image')) throw new Error(`model ${provider}/${model} does not support image input`)
              imageRouteChecked = true
            }
            commandAttachments.push({ type: 'image', mediaType: attachment.mediaType, data: attachment.data, ...(attachment.name === undefined ? {} : { name: attachment.name }) })
            continue
          }
          const ref = await store.admitEncodedFile({ data: attachment.data, ...(attachment.name === undefined ? {} : { name: attachment.name }) })
          const receiptId = crypto.randomUUID()
          commandFileReceipts.set(receiptId, { sessionId: String(target.session.id), ref })
          receipts.push(receiptId)
          commandAttachments.push({ type: 'file', receiptId })
        }
        const execution = await ctx.commands.execute(target, line, commandAttachments, new AbortController().signal)
        if (execution === undefined) throw new Error(`unknown command /${parsed.name}`)
        const result = execution.result
        const text = result.text?.replaceAll(FULL_ACCESS_REGISTRY_NAME, FULL_ACCESS_UI_NAME)
        if (result.kind === 'error') throw new Error(text ?? `/${parsed.name} failed`)
        if (text !== undefined && text !== '') appendNotice(text, 'info')
        rendererSnapshotPush?.()
      } finally {
        for (const receiptId of receipts) commandFileReceipts.delete(receiptId)
      }
    }
    const runCommand = async (line: string): Promise<void> => {
      const current = agent
      if (current === undefined) return

      // The TUI presents the unrestricted preset as `full-access`; the host
      // registry still knows it as `danger-full-access`, so translate before
      // handing the slash command to the backend.
      const permissionMatch = /^\/permission(?:\s+(.*))?$/.exec(line)
      if (permissionMatch !== null) {
        const arg = permissionMatch[1]?.trim() ?? ''
        line = arg === '' ? '/permission' : `/permission ${registryPermissionName(arg)}`
      }
      if (line === '/think' || line.startsWith('/think ')) {
        const selection = handles.selectionRef?.current
        const setEffort = handles.setReasoningEffort
        if (selection === undefined || setEffort === undefined) return
        try {
          const efforts = await reasoningEffortsFor(selection)
          const choice = chooseReasoningEffort(
            efforts,
            selection.reasoningEffort,
            line.slice('/think'.length).trim(),
          )
          if (choice.kind === 'unsupported') {
            appendNotice(t('noticeThinkUnsupported'), 'warning')
            return
          }
          if (choice.kind === 'unknown') {
            appendNotice(t('noticeThinkUnknown', { name: choice.requested }), 'warning')
            return
          }
          const params = { name: displayText(choice.effort.name), id: displayText(choice.effort.id) }
          if (choice.kind === 'already') {
            appendNotice(t('noticeThinkAlready', params), 'info')
            return
          }
          await setEffort(choice.effort.id)
          appendNotice(t('noticeThinkSet', params), 'info')
        } catch (error: unknown) {
          appendNotice(t('noticeThinkFailed', { error: errorChain(error) }), 'error')
        }
        return
      }
      if (line === '/new' || line.startsWith('/new ')) {
        const creator = handles.newAgent
        if (creator === undefined) return
        if (!(await runSessionSwitchDecision(current, 'new'))) return
        appendNotice(t('noticeCreatingSession'), 'info')
        try {
          const id = await creator()
          if (id !== undefined) notifySessionSwitched('new', String(id), String(current.session.id))
        } catch (error: unknown) {
          appendNotice(t('noticeSessionCreateFailed', { error: errorChain(error) }), 'error')
        }
        return
      }
      if (line === '/resume' || line.startsWith('/resume ')) {
        const switcher = handles.switchAgent
        if (switcher === undefined) return
        const explicit = line.slice('/resume'.length).trim()
        if (explicit !== '') {
          if (!(await runSessionSwitchDecision(current, 'resume', explicit))) return
          await switcher(SessionId(explicit))
          notifySessionSwitched('resume', explicit, String(current.session.id))
          return
        }
        if (!(await runSessionSwitchDecision(current, 'resume'))) return
        try {
          const records = await ctx.sessionQuery.listSessions()
          const workspace = current.session.header.cwd ?? process.cwd()
          const candidates = filterProjectSessions(records, workspace)
          let snapshots: Awaited<ReturnType<typeof ctx.sessionPersistence.list>> = []
          try {
            snapshots = await ctx.sessionPersistence.list()
          } catch {
            // Tail activity is optional; the picker still opens in createdAt order.
          }
          const snapshotById = new Map(snapshots.map(snapshot => [String(snapshot.header.id), snapshot]))
          const ranked = await Promise.all(candidates.map(async record => {
            let lastActivityAt: number | undefined
            try {
              lastActivityAt = await sessionActivity.lastActivityAt(record.header.id, snapshotById.get(String(record.header.id)))
            } catch {
              // Fall back to createdAt through sortSessionsByActivity.
            }
            return {
              id: String(record.header.id),
              createdAt: record.header.createdAt ?? 0,
              ...(lastActivityAt === undefined ? {} : { lastActivityAt }),
              record,
            }
          }))
          const persisted: typeof ranked = []
          for (const item of sortSessionsByActivity(ranked)) {
            if (persisted.length >= RESUME_PICKER_LIMIT) break
            let blank = false
            try {
              blank = await isBlankStoredSession(item.record.header.id)
            } catch {
              // Keep unreadable sessions visible; the explicit pick will report the real error.
            }
            if (!blank) persisted.push(item)
          }
          if (persisted.length === 0) {
            appendNotice(t('noticeNoSessions'), 'warning')
            return
          }
          const titlesPromise = ctx.sessionQuery.readTitleSnapshots(
            persisted.map(item => item.record.header.id),
          ).catch(() => [] as Awaited<ReturnType<typeof ctx.sessionQuery.readTitleSnapshots>>)
          let titleTimer: NodeJS.Timeout | undefined
          const timeoutPromise = new Promise<Awaited<ReturnType<typeof ctx.sessionQuery.readTitleSnapshots>>>(
            resolve => { titleTimer = setTimeout(() => resolve([]), RESUME_TITLES_TIMEOUT_MS) },
          )
          // Titles are decorative; if a slow/corrupt session blocks the batch,
          // show the picker after the timeout with untitled labels instead of freezing.
          const titles = await Promise.race([titlesPromise, timeoutPromise])
          clearTimeout(titleTimer)
          const titleById = new Map<string, string | undefined>()
          for (const observation of titles) {
            if (observation.status === 'fulfilled') {
              titleById.set(String(observation.sessionId), observation.value.title?.title)
            }
          }
          const picked = await extensionDialog({
            kind: 'select',
            title: t('resumeTitle'),
            options: persisted.map(item => ({
              id: String(item.record.header.id),
              label: titleById.get(String(item.record.header.id)) ?? t('untitled'),
              description: `${item.record.header.id} · ${new Date(item.lastActivityAt ?? item.record.header.createdAt ?? 0).toLocaleString()}`,
            })),
          })
          if (picked !== undefined) {
            await switcher(SessionId(picked))
            notifySessionSwitched('resume', picked, String(current.session.id))
          }
        } catch (error: unknown) {
          appendNotice(t('noticeSessionListFailed', { error: errorChain(error) }), 'error')
        }
        return
      }
      if (line === '/skills' || line.startsWith('/skills ')) {
        try {
          const snapshot = await ctx.skills.snapshot({ cwd: current.session.header.cwd ?? process.cwd() })
          if (snapshot.skills.length === 0) {
            appendNotice(t('noticeNoSkills'), 'info')
            return
          }
          const rows = snapshot.skills.map(skill =>
            `/${skill.name} — ${skill.description}${skill.source === undefined ? '' : ` (${skill.source})`}`)
          appendNotice(rows.join('\n'), 'info')
        } catch (error: unknown) {
          appendNotice(t('noticeSkillListFailed', { error: errorChain(error) }), 'error')
        }
        return
      }
      if (line.startsWith('/skill:')) {
        const name = line.slice('/skill:'.length).trim()
        if (name === '') {
          appendNotice(t('noticeSkillUsage'), 'warning')
          return
        }
        try {
          const definition = await ctx.skills.get(name, { cwd: current.session.header.cwd ?? process.cwd() })
          if (definition === undefined) {
            appendNotice(t('noticeUnknownSkill', { name }), 'warning')
            return
          }
          recordActivePreset(current)
          current.followup(createUserMessage({
            content: [{ type: 'text', text: renderSkillContent(definition) }],
            source: { kind: 'skill-invocation', name, form: 'instructions' },
          }))
        } catch (error: unknown) {
          appendNotice(t('noticeSkillFailed', { name, error: errorChain(error) }), 'error')
        }
        return
      }
      if (line === '/details' || line.startsWith('/details ')) {
        const folded = foldSessionTitle(sessionEvents(current.session))
        const model = handles.selectionRef?.current?.model ?? current.options.model
        let inputTokens = 0
        let outputTokens = 0
        for (const event of sessionEvents(current.session)) {
          if (event.type === 'assistant/message' && event.data.usage !== undefined) {
            inputTokens += event.data.usage.inputTokens
            outputTokens += event.data.usage.outputTokens
          }
        }
        const contextWindow = current.session.requestContext()?.contextWindow
        const usedTokens = ctx.tokenMeter.measure(current.session).totalTokens
        const rows: Array<[string, string]> = [
          ['Title', folded?.title ?? 'untitled'],
          ['Session', String(current.session.id)],
          ['Directory', current.session.header.cwd ?? process.cwd()],
          ['Model', `${current.options.provider ?? '?'}/${model ?? '?'}`],
          ['Agent', `${current.id} · ${current.status}`],
          ['Tokens', `↑${formatTokens(inputTokens)} ↓${formatTokens(outputTokens)}`],
          ['Context', contextWindow === undefined
            ? `${formatTokens(usedTokens)} used · capacity unknown`
            : `${Math.round(usedTokens / contextWindow * 100)}% · ${formatTokens(usedTokens)} / ${formatTokens(contextWindow)}`],
        ]
        appendNotice(rows.map(([label, value]) => `${label}: ${value}`).join('\n'), 'info')
        return
      }
      if (line === '/mode' || line.startsWith('/mode ')) {
        const presets = ctx.agentPresets
        if (presets === undefined) {
          appendNotice(t('noticeModeUnavailable'), 'warning')
          return
        }
        const roster = (await presets.list()).filter(preset => preset.broken === undefined)
        // Cycle order: the roster's own order (shipped first, then any number
        // of locally installed presets), deduplicated against the shipped set.
        const known = roster.length > 0
          ? [...new Set([...MODE_ORDER, ...roster.map(preset => preset.id)])]
          : [...MODE_ORDER]
        const arg = line.slice('/mode'.length).trim()
        if (arg !== '' && !known.includes(arg)) {
          appendNotice(t('noticeModeUnknown', { name: arg }), 'warning')
          return
        }
        const live = presets.composedPreset(current.ctx)
        const currentMode = live ?? uiMode
        const liveIndex = known.indexOf(currentMode)
        const target = arg === ''
          ? known[(liveIndex + 1) % known.length] ?? currentMode
          : arg
        if (currentMode === target) {
          appendNotice(t('noticeModeAlready', { mode: modeLabel(t, target, presetNames) }), 'info')
          return
        }
        // Swapping the composition mid-conversation would leave logged tool
        // calls the new preset cannot make; the official roster only allows
        // switching while the session is blank.
        try {
          await applyAgentPreset(current, target, roster)
          appendNotice(t('noticeModeSet', { mode: modeLabel(t, target, presetNames) }), 'info')
        } catch (error: unknown) {
          if (error instanceof Error && error.message === 'agent preset can only change in an empty session') {
            appendNotice(t('noticeModeNotBlank'), 'warning')
          } else {
            appendNotice(t('noticeModeSwitchFailed', { error: errorChain(error) }), 'error')
          }
        }
        return
      }

      if (line === '/help' || line.startsWith('/help ')) {
        const commandRows = ctx.commands.list(current).map(command => {
          const permission = command.name === 'permission'
          const hint = permission ? permissionCommand.argumentHint : command.input?.hint
          const description = permission ? t('helpPermission') : command.description
          return `/${command.name}${hint === undefined ? '' : ` ${hint}`} — ${description}`
        })
        const rows = [
          t('helpShortcuts'),
          `Esc  ${t('helpEsc')}`,
          `Enter  ${t('helpEnter')}`,
          `Ctrl+C  ${t('helpCtrlC')}`,
          `Ctrl+D  ${t('helpCtrlD')}`,
          `Ctrl+T  ${t('helpCtrlT')}`,
          `Ctrl+O  ${t('helpCtrlO')}`,
          `Ctrl+Shift+O  ${t('helpCtrlShiftO')}`,
          `Alt+L  ${t('helpAltL')}`,
          `Alt+Up  ${t('helpAltUp')}`,
          `Ctrl+P  ${t('helpCtrlP')}`,
          `Ctrl+X M  ${t('helpAltM')}`,
          `F2 / Shift+F2  ${t('helpCycleModel')}`,
          `Ctrl+Q / Ctrl+Enter  ${t('helpCtrlQ')}`,
          t('helpCommands'),
          `/palette — ${t('helpPalette')}`,
          `/help — ${t('helpHelp')}`,
          `/model — ${t('helpModel')}`,
          `/think [level] — ${t('helpThink')}`,
          `/new — ${t('helpNew')}`,
          `/resume — ${t('helpResume')}`,
          `/details — ${t('helpDetails')}`,
          `/skills — ${t('helpSkills')}`,
          `/skill:<name> — ${t('helpSkillInvoke')}`,
          `/mode — ${t('helpMode')}`,
          `/theme — ${t('helpTheme')}`,
          `/settings — ${t('helpSettings')}`,
          ...commandRows,
        ]
        appendNotice(rows.join('\n'), 'info')
        return
      }
      if (line.trim() === '/compact' || line.startsWith('/compact ')) {
        if (pluginHost !== undefined) {
          const decision = await pluginHost.runDecision('tui/compact', {
            sessionId: String(current.id),
            cwd: current.session.header.cwd ?? process.cwd(),
          })
          if (decision !== null && typeof decision === 'object' && (decision as { cancel?: unknown }).cancel === true) {
            const reason = (decision as { reason?: unknown }).reason
            appendNotice(typeof reason === 'string' && reason !== '' ? reason : 'Compaction cancelled by a plugin', 'warning')
            return
          }
        }
      }
      const execution = await ctx.commands.execute(current, line, [], new AbortController().signal)
      if (execution === undefined) {
        appendNotice(t('noticeUnknownCommand', {
          name: line.slice(1, line.indexOf(' ') === -1 ? undefined : line.indexOf(' ')),
        }), 'warning')
        return
      }
      const result = execution.result
      const resultText = result.text?.replaceAll(FULL_ACCESS_REGISTRY_NAME, FULL_ACCESS_UI_NAME)
      const isWechatCommand = line.startsWith('/wechat-')
      if (isWechatCommand && resultText !== undefined && resultText !== '') {
        // The bridge command result rides the toast overlay; the renderer has no
        // persistent static card surface for it.
        appendNotice(resultText, result.kind === 'error' ? 'error' : 'info')
        return
      }
      if (result.kind === 'error') {
        appendNotice(resultText ?? '', 'error')
        if (line.trim() === '/compact') {
          const cause = latestCompactionError()
          if (cause !== undefined && cause !== '' && !String(resultText ?? '').includes(cause)) {
            appendNotice(t('noticeCompactionCause', { cause }), 'error')
          }
          if (cause !== undefined && cause.includes('400 status code')) {
            appendNotice(t('noticeCompaction400Hint'), 'warning')
          } else {
            appendNotice(t('noticeCompactionHint'), 'warning')
          }
        }
      } else if (resultText !== undefined && resultText !== '') {
        appendNotice(resultText, 'info')
      }
      // A command can move the route state the renderer shows (permission preset,
      // mode, workspace); the snapshot re-push after completion keeps the prompt
      // bar's metadata in step with the host's state.
      rendererSnapshotPush?.()
    }

    const deliverInput = (text: string): void => {
      const current = agent
      if (current === undefined) return
      const trimmed = text.trim()
      if (trimmed === '') return
      if (trimmed.startsWith('/')) {
        // A command handler (e.g. /compact) may reject after logging a partial
        // attempt; surface it as a notice instead of an unhandled rejection.
        void runCommand(trimmed).catch((error: unknown) => {
          try {
            const message = errorChain(error)
            if (trimmed === '/compact') {
              const cause = latestCompactionError()
              if (cause !== undefined && cause !== '' && !message.includes(cause)) {
                appendNotice(t('noticeCompactionCause', { cause }), 'error')
              }
              if (cause !== undefined && cause.includes('400 status code')) {
                appendNotice(t('noticeCompaction400Hint'), 'warning')
              } else {
                appendNotice(t('noticeCompactionHint'), 'warning')
              }
            }
            appendNotice(t('noticeCommandFailed', { error: message }), 'error')
          } catch {
            appendNotice(t('noticeCommandFailed', { error: error instanceof Error ? error.message : String(error) }), 'error')
          }
        })
        return
      }
      // While the agent is generating, Enter defaults to the interjection
      // queue: the message is steered into the next step boundary instead of
      // opening a brand-new follow-up turn.
      if (current.status === 'running') {
        enqueueInterjection(text)
        return
      }
      const refreshTitle = (): void => {
        const sessionTitle = ctx.get('sessionTitle')
        if (sessionTitle !== undefined && foldSessionTitle(sessionEvents(current.session)) === undefined) {
          void sessionTitle.refresh(current.session).catch(() => undefined)
        }
      }
      // `@[label](dsh-session:…)` mentions lift another session's surface
      // into this one: prepare attaches the snapshot and injects the
      // additional context without a model turn.
      const parsed = parseSessionReferenceText(text)
      if (parsed.references.length > 0) {
        void (async () => {
          try {
            const prepared = await ctx.sessionReferenceResolver.prepare(
              current,
              [{ type: 'text', text: parsed.text }],
              parsed.references,
            )
            // Inject first (queues context without waking), then follow up:
            // the waking driver claims both at the next pre-step, so the
            // model sees the referenced snapshot from the first step.
            if (prepared.additionalContext !== undefined) {
              current.inject(prepared.additionalContext)
            }
            recordActivePreset(current)
            current.followup(createUserMessage({ content: prepared.content, source: { kind: 'user' } }))
            refreshTitle()
          } catch (error: unknown) {
            appendNotice(t('noticeReferenceFailed', { error: errorChain(error) }), 'error')
          }
        })()
        return
      }
      recordActivePreset(current)
      current.followup(createUserMessage({
        content: [{ type: 'text', text }],
        source: { kind: 'user' },
      }))
      refreshTitle()
    }

    // The composer's entry point: the renderer's `send-message` dep and the pi-tui
    // editor both land here. Plugin `tui/input` interceptors run before delivery.
    const submitText = (text: string): void => {
      const current = agent
      if (current === undefined) return
      if (text.trim() === '') return
      const hasInputInterceptors = pluginHost?.activeDecisionSubscriptions().some(subscription => subscription.event === 'tui/input') ?? false
      if (!hasInputInterceptors) {
        deliverInput(text)
        return
      }
      void (async () => {
        const decision = await pluginHost!.runDecision('tui/input', {
          text,
          delivery: current.status === 'running' ? 'steer' : 'followup',
          sessionId: String(current.id),
          cwd: current.session.header.cwd ?? process.cwd(),
        })
        if (decision !== null && typeof decision === 'object') {
          const record = decision as { cancel?: unknown; handled?: unknown; text?: unknown; reason?: unknown; notice?: unknown }
          if (record.cancel === true) {
            appendNotice(typeof record.reason === 'string' && record.reason !== '' ? record.reason : 'Input cancelled by a plugin', 'warning')
            return
          }
          if (record.handled === true) {
            appendNotice(typeof record.notice === 'string' && record.notice !== '' ? record.notice : 'Input handled by a plugin', 'info')
            return
          }
          if (typeof record.text === 'string' && record.text.trim() !== '') {
            submitText(record.text.trim())
            return
          }
        }
        submitText(text)
      })()
    }
    const submitRendererMessage = async (request: SendMessagePayload): Promise<void> => {
      const target = ctx.agents.get(SessionId(request.sessionId))
      if (target === undefined) throw new Error(`session ${request.sessionId} is not live`)
      if (target.session.header.origin === 'subagent' && (rememberSubagentDescriptor(target.session)?.mode ?? subagentById.get(request.sessionId)?.mode) !== 'continuable') throw new Error('subagent sessions are read-only')
      const attachments = request.attachments ?? []
      const text = request.text.trim()
      if (text === '' && attachments.length === 0 && (request.skills?.length ?? 0) === 0) throw new Error('message must contain text or an attachment')
      const store = ctx.get('attachments')
      if (attachments.length > 0 && store === undefined) throw new Error('attachments are unavailable in this deployment')
      const skillInvocation = /^\/skill:([a-z0-9]+(?:-[a-z0-9]+)*)$/.exec(text)
      if (text.startsWith('/') && skillInvocation === null) {
        if (target !== agent) throw new Error('slash commands require the foreground session')
        if ((request.skills?.length ?? 0) > 0) throw new Error('slash commands do not accept attached skills')
        if (attachments.length > 0) await runCommandWithAttachments(target, text, attachments)
        else await runCommand(text)
        return
      }
      let deliveredText = skillInvocation === null ? text : ''
      const requestedSkillNames = [...(request.skills ?? []), ...(skillInvocation === null ? [] : [skillInvocation[1]!])]
      if (deliveredText !== '' && pluginHost?.activeDecisionSubscriptions().some(subscription => subscription.event === 'tui/input')) {
        const decision = await pluginHost.runDecision('tui/input', {
          text,
          delivery: request.delivery,
          sessionId: String(target.session.id),
          cwd: target.session.header.cwd ?? process.cwd(),
        })
        if (typeof decision === 'object' && decision !== null) {
          if ('cancel' in decision && decision.cancel === true) {
            const reason = 'reason' in decision && typeof decision.reason === 'string' ? decision.reason : 'Input cancelled by a plugin'
            throw new Error(reason)
          }
          if ('handled' in decision && decision.handled === true) {
            const notice = 'notice' in decision && typeof decision.notice === 'string' ? decision.notice : undefined
            if (notice !== undefined && notice !== '') appendNotice(notice, 'info')
            return
          }
          if ('text' in decision && typeof decision.text === 'string' && decision.text.trim() !== '') deliveredText = decision.text.trim()
        }
      }
      const parsed = parseSessionReferenceText(deliveredText)
      const cwd = target.session.header.cwd ?? process.cwd()
      const invokedSkills: Array<NonNullable<Awaited<ReturnType<typeof ctx.skills.get>>>> = []
      const seenSkills = new Set<string>()
      for (const name of requestedSkillNames) {
        if (seenSkills.has(name)) throw new Error(`skill ${name} was requested more than once`)
        seenSkills.add(name)
        const skill = await ctx.skills.get(name, { cwd, scope: scopeOf(target.ctx) })
        if (skill === undefined || !isUserInvocable(skill)) throw new Error(`skill ${name} is not available for user invocation`)
        invokedSkills.push(skill)
      }
      const content: AttachmentAdmissionPart[] = parsed.text === '' && invokedSkills.length > 0
        ? [{ type: 'text', text: `Use the skill ${invokedSkills.map(skill => skill.name).join(', ')}.` }]
        : parsed.text === '' ? [] : [{ type: 'text', text: parsed.text }]
      let imageRouteChecked = false
      for (const attachment of attachments) {
        if (store === undefined) throw new Error('attachments are unavailable in this deployment')
        if (Buffer.byteLength(attachment.data, 'base64') > MAX_RENDERER_FILE_ATTACHMENT_BYTES) throw new Error('attachment exceeds the 20 MiB upload limit')
        if (attachment.type === 'file') {
          if (store.saveFile === AttachmentStore.prototype.saveFile) throw new Error('file attachments are unavailable in this deployment')
          const reference = await store.admitEncodedFile({
            data: attachment.data,
            ...(attachment.name === undefined ? {} : { name: attachment.name }),
          })
          content.push({ type: 'file', attachment: reference })
          continue
        }
        if (!imageRouteChecked) {
          const route = target.session.requestHeader()
          const provider = route?.config.provider ?? target.options.provider
          const model = route?.config.model ?? target.options.model
          if (provider === undefined || model === undefined) throw new Error('image attachment route is unavailable')
          const info = await ctx.llm.resolveModelInfo(provider, model)
          if (!info.inputModalities?.includes('image')) throw new Error(`model ${provider}/${model} does not support image input`)
          imageRouteChecked = true
        }
        content.push({
          type: 'image',
          mediaType: attachment.mediaType,
          data: attachment.data,
          ...(attachment.name === undefined ? {} : { name: attachment.name }),
        })
      }
      const admitted = store === undefined ? content : await store.admitPromptContent(content)
      const prepared = parsed.references.length === 0
        ? undefined
        : await ctx.sessionReferenceResolver.prepare(target, admitted as unknown as ContentBlock[], parsed.references)
      if (prepared?.additionalContext !== undefined) target.inject(prepared.additionalContext)
      const messageContent = (prepared === undefined ? admitted : [...prepared.content]) as unknown as ContentBlock[]
      for (const skill of invokedSkills) {
        target.inject(createUserMessage({
          content: [{ type: 'text', text: renderSkillContent(skill) }],
          source: { kind: 'skill-invocation', name: skill.name, form: 'instructions' },
        }))
      }
      recordActivePreset(target)
      const message = createUserMessage({ content: messageContent, source: { kind: 'user' } })
      const sessionKey = String(target.session.id)
      pendingInterjections.push({ sessionId: sessionKey, message, text: parsed.text || invokedSkills.map(skill => `skill:${skill.name}`).join(' ') })
      try {
        if (request.delivery === 'queue') target.followup(message)
        else target.steer(message)
      } catch (error: unknown) {
        const pendingIndex = pendingInterjections.findIndex(entry => entry.sessionId === sessionKey && entry.message.id === message.id)
        if (pendingIndex !== -1) pendingInterjections.splice(pendingIndex, 1)
        refreshInterjectionIndicator()
        throw error
      }
      refreshInterjectionIndicator()
      const titles = ctx.get('sessionTitle')
      if (titles !== undefined && foldSessionTitle(sessionEvents(target.session)) === undefined) {
        void titles.refresh(target.session).catch(() => undefined)
      }
    }

    const readRendererAttachment = async (request: AttachmentReadPayload): Promise<unknown> => {
      const target = ctx.agents.get(SessionId(request.sessionId))
      if (target === undefined) throw new Error(`session ${request.sessionId} is not live`)
      const store = ctx.get('attachments')
      if (store === undefined) throw new Error('attachments are unavailable in this deployment')
      const candidate = request.attachment as Record<string, unknown>
      const attachmentId = candidate.attachmentId
      if (typeof attachmentId !== 'string' || attachmentId === '') throw new Error('attachment reference has no attachmentId')
      const isImage = typeof candidate.mediaType === 'string'
      const expectedKeys = isImage
        ? ['attachmentId', 'mediaType', 'bytes', 'width', 'height', 'name', 'originalDimensions']
        : ['attachmentId', 'name', 'bytes']
      if (Object.keys(candidate).some(key => !expectedKeys.includes(key))) throw new Error('attachment reference has unknown fields')
      if (!isImage && (typeof candidate.name !== 'string' || typeof candidate.bytes !== 'number')) throw new Error('file attachment reference is incomplete')
      if (isImage && (candidate.mediaType !== 'image/png' && candidate.mediaType !== 'image/jpeg' && candidate.mediaType !== 'image/webp' && candidate.mediaType !== 'image/gif')) {
        throw new Error('image attachment media type is unsupported')
      }
      const sameReference = (value: unknown): boolean => {
        if (typeof value !== 'object' || value === null || Array.isArray(value)) return false
        const ref = value as Record<string, unknown>
        if (ref.attachmentId !== attachmentId || (typeof ref.mediaType === 'string') !== isImage) return false
        for (const key of ['mediaType', 'bytes', 'width', 'height', 'name']) {
          if (candidate[key] !== undefined && ref[key] !== candidate[key]) return false
        }
        return true
      }
      const containsReference = (value: unknown): boolean => {
        if (sameReference(value)) return true
        if (Array.isArray(value)) return value.some(containsReference)
        if (typeof value !== 'object' || value === null) return false
        return Object.values(value as Record<string, unknown>).some(containsReference)
      }
      const snapshot = await ctx.sessionQuery.readSession(SessionId(request.sessionId))
      const queuedReference = pendingInterjections.some(entry => entry.sessionId === request.sessionId && containsReference(entry.message))
      if (!containsReference(snapshot.events) && !queuedReference) throw new Error('attachment reference is not present in this session')
      const maxBytes = 20 * 1024 * 1024
      if (isImage) {
        if (store.readImage === AttachmentStore.prototype.readImage) throw new Error('image attachment reading is unavailable in this deployment')
        const stored = await store.readImage(candidate as unknown as ImageAttachmentRef)
        if (stored.data.byteLength > maxBytes) throw new Error('attachment exceeds the 20 MiB read limit')
        return {
          type: 'image',
          data: Buffer.from(stored.data).toString('base64'),
          mediaType: stored.ref.mediaType,
          ...(stored.ref.name === undefined ? {} : { name: stored.ref.name }),
        }
      }
      if (store.readFileStream === AttachmentStore.prototype.readFileStream) throw new Error('file attachment reading is unavailable in this deployment')
      const chunks: Buffer[] = []
      let total = 0
      for await (const chunk of store.readFileStream(candidate as unknown as FileAttachmentRef)) {
        total += chunk.byteLength
        if (total > maxBytes) throw new Error('attachment exceeds the 20 MiB read limit')
        chunks.push(Buffer.from(chunk))
      }
      return { type: 'file', data: Buffer.concat(chunks).toString('base64'), name: String(candidate.name) }
    }


    // --- mount: run once the configured agent is live -------------------------
    let offModelSelection: (() => void) | undefined
    const ownedHandles = new Map<string, AgentHandle>()
    let mounted = false

    const mount = async (liveAgent: Agent): Promise<void> => {
      if (mounted) return
      mounted = true
      agent = liveAgent
      uiMode = modeForSession(ctx, liveAgent.session, resolveDefaultMode())
      // 让微信桥跟随 TUI 当前会话；/resume、/new 等切换也走 activateAgent。
      setActiveAgent(liveAgent)
      this.foregroundAgentImpl = () => agent

      // The renderer owns the TTY: dsh stdout is routed to the log, and the host
      // pushes the session to the renderer over IPC. The renderer sends the composer
      // back to `submitText`, so slash commands, the interjection queue, and session
      // references all stay in the host.
      // The model route for an agent: the session's request header wins over the
      // configured Agent route. Declared before the renderer mount because the mount's
      // `onAck` builds a snapshot, and the hello can arrive while the activation body is
      // suspended at an `await` — a `const` declared later is in its temporal dead zone
      // then, and the snapshot throws `Cannot access 'selectionFor' before initialization`.
      const selectionFor = (target: Agent): ModelSelection =>
        startupModelSelection(
          target.session.requestHeader(),
          savedLastSelection(),
          target.options,
          ctx.agentDefaultModel.currentSelection(),
          resolved.defaultReasoningEffort,
        )

      // A historical session continues its last actual request route. A new
      // session starts from the configured Agent route and dsh default model.
      const initialSelection = selectionFor(liveAgent)
      const selectionRef: ModelSelectionRef = { current: initialSelection, assembled: undefined }
      // Seed config on the first launch after an upgrade too: from then on the last actual
      // route and mode are always present even if the user never opens a picker.
      saveLastSelection({
        provider: initialSelection.provider,
        model: initialSelection.model,
        ...(initialSelection.reasoningEffort === undefined ? {} : { effort: String(initialSelection.reasoningEffort) }),
        preset: uiMode,
      })
      offModelSelection = installModelSelection(liveAgent.ctx, selectionRef)
      /**
       * Persist the route as the default for the next session.
       *
       * dsh's `agentDefaultModel.saveSelection()` writes through the loader's `configEditor`
       * and returns silently when that service is absent, so a pick updated the session but
       * never the default: every restart reopened on the profile's original model. The
       * settings service is the seam `/settings` uses, and its write lands in the profile
       * patch layer, so "the model I left with" survives the restart.
       */
      const persistDefaultModel = async (selection: ModelSelection): Promise<void> => {
        try {
          await saveDefaultModel(settings, selection)
        } catch (error: unknown) {
          // A default that cannot be written must not fail the pick; the session already
          // runs the new route.
          appendNotice(t('noticeDefaultModelFailed', { error: errorChain(error) }), 'warning')
        }
      }
      const commitSelection = async (selection: ModelSelection): Promise<void> => {
        const target = agent ?? liveAgent
        // The ref is what `installModelSelection` hands to the next request, and the live
        // agent is the only agent there is until the renderer switches sessions. Publish the
        // new route before the settings write so the prompt follows the pick immediately;
        // a route-only push keeps the transcript and its scroll position intact.
        selectionRef.current = selection
        refreshContextEstimate(target, selection)
        saveLastSelection({
          provider: selection.provider,
          model: selection.model,
          ...(selection.reasoningEffort === undefined ? {} : { effort: String(selection.reasoningEffort) }),
          preset: uiMode,
        })
        if (rendererSelectionPush !== undefined) rendererSelectionPush()
        else rendererSnapshotPush?.()
        await persistDefaultModel(selection)
      }
      const saveSelection = async (selection: ModelSelection): Promise<void> => {
        const current = selectionRef.current
        const unchanged = current !== undefined
          && current.provider === selection.provider
          && current.model === selection.model
          && (current.reasoningEffort ?? undefined) === (selection.reasoningEffort ?? undefined)
        // Picking the route that is already active is a no-op: re-saving rewrote the stored
        // default and appended a second `model set` notice.
        if (unchanged) return
        await commitSelection(selection)
        appendNotice(t('noticeModelSet', { provider: selection.provider, model: selection.model }), 'info')
      }
      /**
       * The route the surfaces show.
       *
       * `selectionFor` folds the session's `request/header`, which dsh appends when a request
       * is dispatched — so right after a pick it still names the model of the *previous*
       * request, and the prompt kept showing that one even though the host had already
       * switched. The ref is what `installModelSelection` hands to the next request, so for
       * the foreground session it is the truth; a background target (a fork source) keeps
       * its own header.
       */
      const displaySelection = (target: Agent): ModelSelection =>
        target.session.header.origin !== 'subagent'
          && target === (agent ?? liveAgent)
          && selectionRef.current !== undefined
          ? selectionRef.current
          : selectionFor(target)
      const setReasoningEffort = async (effort: NonNullable<ModelSelection['reasoningEffort']>): Promise<void> => {
        const selection = handles.selectionRef?.current
        if (selection === undefined) throw new Error('model selection unavailable')
        await commitSelection({ ...selection, reasoningEffort: effort })
      }
      // The renderer path returns before the pi-tui wiring, so the handles the renderer
      // writes through (the model pick, the effort pick, the custom-model provider
      // fallback) are assigned here. Declaring them at the end of the pi-tui path left
      // them `undefined` on the renderer path, so a model pick did nothing.
      handles.saveSelection = saveSelection
      handles.setReasoningEffort = setReasoningEffort
      handles.selectionRef = selectionRef

      // Hydrate every event-derived surface for the session this mount opened. The mount
      // path is not the same as `activateAgent()` (which already replays on a switch), so
      // without this a restarted/reattached renderer got transcript rows from the snapshot
      // but no token totals, cache completeness, cost, todos, or subagents: those live only
      // in `lastUsage`/the listener sets filled by `hostEventEffects`. Replaying here makes
      // restart and first-session start deterministic and, because the durable
      // assistant/message events carry `usage.cacheReadTokens`, restores cache statistics
      // from the session log instead of requiring a second sidecar.
      replayTranscript()
      // Replay above is deliberately silent; from here on a durable event is live and may
      // raise a notice. The mount path previously left this false for the whole process,
      // so compaction failures and interrupted turns lost their live warnings.
      live = true
      refreshGitBranch(liveAgent.session.header.cwd ?? process.cwd())
      refreshContextEstimate(liveAgent, initialSelection)

      // Live assistant streaming is not a durable session event (dsh 0.2 replaced
      // `assistant/chunk`), so the streaming row is built from the stream frames and
      // settled by the durable `assistant/message` that follows. Declared before the
      // activation path: a switch drops the row, which belongs to the session it started in.
      let streamRow: AssistantStreamRow | undefined
      let streamSequence = 0
      /**
       * The fold state for live events. A live session sends one event per frame, so the
       * incremental fold needs its own memory: without it a tool row kept `Running…` (its
       * `tool/result` arrived alone) and a settled `Thought` had no duration (its
       * `step/start` arrived alone). Reset whenever the foreground session changes.
       */
      let transcriptFold: TranscriptFoldState = createTranscriptFoldState()

      /**
       * Switch the foreground session. The renderer's rail, `ctrl+tab`, and `/resume`
       * all land here; the host owns the lifecycle, so the new agent is published through
       * one activation path that re-points the selections, the subscriptions the mount
       * handed over, and the renderer's snapshot.
       */
      const activateAgent = (next: Agent): void => {
        offModelSelection?.()
        const nextSelection = selectionFor(next)
        selectionRef.current = nextSelection
        selectionRef.assembled = undefined
        uiMode = modeForSession(ctx, next.session, resolveDefaultMode())
        offModelSelection = installModelSelection(next.ctx, selectionRef)
        agent = next
        setActiveAgent(next)
        usageFold = EMPTY_USAGE_FOLD
        usageCostFold = EMPTY_USAGE_COST_FOLD
        contextUsageCache.measuredAt = 0
        streamRow = undefined
        transcriptFold = createTranscriptFoldState()
        refreshInterjectionIndicator()
        refreshContextEstimate(next, nextSelection)
        refreshGitBranch(next.session.header.cwd ?? process.cwd())
        replayTranscript()
        live = true
        updateStatusValues()
        notifyTurnState(next)
        rendererSnapshotPush?.()
      }

      const createAgent = async (request: { sessionId?: SessionId; cwd?: string; selection?: SessionOpPayload['selection']; fork?: { parentSession: SessionId; seed: readonly SessionEvent[]; inheritedEventCount: number }; baseAgent?: Agent } = {}): Promise<SessionId> => {
        const current = request.baseAgent ?? agent ?? liveAgent
        const requestedSelection = request.selection
        const selection: ModelSelection = requestedSelection === undefined
          ? selectionRef.current ?? selectionFor(current)
          : {
            provider: requestedSelection.provider,
            model: requestedSelection.model,
            ...(requestedSelection.effort === undefined ? {} : { reasoningEffort: ReasoningEffortId(requestedSelection.effort) }),
          }
        const preset = requestedSelection?.preset ?? uiMode
        const cwd = request.cwd ?? current.session.header.cwd ?? process.cwd()
        const id = request.sessionId ?? SessionId(`tui-${crypto.randomUUID()}`)
        const permission = requestedSelection?.permission ?? currentPermissionPreset(ctx, current.session)
        if (requestedSelection?.permission !== undefined && permission === 'custom') {
          throw new Error('custom permission cannot be selected when creating a session')
        }
        const handle = await ctx.agents.create({
          sessionId: id,
          meta: {
            cwd,
            agentPreset: preset,
            ...(request.fork === undefined ? {} : { parentSession: request.fork.parentSession, isSeeded: true as const }),
          },
          ...(request.fork === undefined ? {} : { inheritedEventCount: SessionLogOffset(request.fork.inheritedEventCount), seed: [...request.fork.seed] }),
          agentOptions: {
            ...current.options,
            provider: selection.provider,
            model: selection.model,
            ...(selection.reasoningEffort === undefined ? {} : { reasoningEffort: selection.reasoningEffort }),
          },
          setup: async agentCtx => { await ctx.agentPresets.mount(agentCtx, preset) },
        })
        if (permission !== 'custom') {
          try {
            setPermissionPreset(ctx, handle.agent.session, permission)
          } catch (error: unknown) {
            if (requestedSelection?.permission === undefined) {
              // Inherited presets may be unavailable in the target deployment; preserve
              // the session's default only for this implicit inheritance path.
            } else {
              await handle.dispose().catch(() => undefined)
              throw new Error(`Could not apply permission preset ${permission}: ${errorChain(error)}`, { cause: error })
            }
          }
        }
        activateAgent(handle.agent)
        appendNotice(t('noticeSessionCreated', { id: String(id) }), 'info')
        return id
      }
      this.createForegroundSessionImpl = createAgent
      setTuiForegroundControl({
        foregroundAgent: () => this.foregroundAgent(),
        createForegroundSession: () => this.createForegroundSession(),
        currentModelSelection: () => selectionRef.current,
        saveModelSelection: async (selection: ModelSelection) => {
          await commitSelection(selection)
        },
      })

      // `/resume` switches the foreground session: the rail and `ctrl+tab` reach it
      // through `session-op`, and the slash command uses the same seam.
      const resumeOperations = new Map<string, Promise<Agent>>()
      const resumeAgent = async (targetId: SessionId): Promise<Agent> => {
        const targetKey = String(targetId)
        const liveTarget = ctx.agents.get(targetId)
        if (liveTarget !== undefined) return liveTarget
        const pendingResume = resumeOperations.get(targetKey)
        if (pendingResume !== undefined) return pendingResume
        const operation = (async (): Promise<Agent> => {
          const current = agent ?? liveAgent
          const presets = ctx.agentPresets
          const controller = new AbortController()
          const resumePromise = ctx.agents.resume({
            resumeSessionId: targetId,
            agentOptions: current.options,
            signal: controller.signal,
            setup: presets === undefined ? undefined : async (agentCtx, resumed) => {
              const recorded = resolveSessionPreset(agentCtx, resumed.session)
              if (recorded !== undefined) await presets.mount(agentCtx, recorded)
            },
          })
          let timedOut = false
          let settled = false
          void resumePromise.then(handle => {
            if (timedOut) void handle.dispose().catch(() => undefined)
          }).catch(() => undefined)
          let resumeTimer: NodeJS.Timeout | undefined
          const timeoutPromise = new Promise<AgentHandle>((_, reject) => {
            resumeTimer = setTimeout(() => {
              controller.abort()
              if (!settled) {
                timedOut = true
                reject(new DOMException('Session resume timed out', 'AbortError'))
              }
            }, RESUME_TIMEOUT_MS)
          })
          try {
            const handle = await Promise.race([resumePromise, timeoutPromise])
            settled = true
            clearTimeout(resumeTimer)
            ownedHandles.set(targetKey, handle)
            return handle.agent
          } catch (error: unknown) {
            settled = true
            clearTimeout(resumeTimer)
            const aborted = error instanceof Error && error.name === 'AbortError'
            throw new Error(aborted ? 'Session resume timed out' : `Session resume failed: ${errorChain(error)}`, { cause: error })
          }
        })()
        resumeOperations.set(targetKey, operation)
        try {
          return await operation
        } finally {
          if (resumeOperations.get(targetKey) === operation) resumeOperations.delete(targetKey)
        }
      }
      const switchAgent = async (targetId: SessionId): Promise<void> => {
        const targetKey = String(targetId)
        const remember = async (target: Agent): Promise<void> => {
          if (target.session.header.origin !== 'subagent') return
          rememberSubagentDescriptor(target.session)
          await loadSubagentDescriptor(String(target.session.id))
        }
        const current = agent ?? liveAgent
        if (String(current.session.id) === targetKey) {
          await remember(current)
          rendererSnapshotPush?.()
          return
        }
        const live = ctx.agents.get(targetId)
        if (live !== undefined) {
          await remember(live)
          activateAgent(live)
          return
        }
        // A persisted session the process has not mounted yet is resumed from its log, the
        // same way `/resume` does it. Switching only to *live* agents made picking an older
        // session from the picker fail with "session … is not live" instead of opening it.
        const resumed = await resumeAgent(targetId)
        await remember(resumed)
        activateAgent(resumed)
      }
      handles.newAgent = createAgent
      handles.switchAgent = switchAgent

      // Slash commands + @ / path completions (pi-tui's combined provider
      // scans the workspace rooted at the session cwd). The command registry is shared:
      // the renderer's completion reads it through the mount's `commands` dep, and the
      // skills refresh re-sends it. Declaring it after the renderer block's `return`
      // put it in the temporal dead zone for the mount's ack callback.
      const modeOptions: AutocompleteItem[] = [
        { value: 'standard', label: `standard — ${t('modeStandard')}`, description: t('modeStandardHint') },
        { value: 'minimal', label: `minimal — ${t('modeMinimal')}`, description: t('modeMinimalHint') },
        { value: 'code', label: `code — ${t('modeCode')}`, description: t('modeCodeHint') },
        { value: 'cordis', label: `cordis — ${t('modeCordis')}`, description: t('modeCordisHint') },
      ]
      const commandEntriesFor = (target: Agent): SlashCommand[] => [
        { name: 'palette', description: t('cmdPalette') },
        { name: 'help', description: t('cmdHelp') },
        { name: 'models', description: t('cmdModel') },
        {
          name: 'effort',
          description: t('cmdThink'),
          argumentHint: '<level>',
          getArgumentCompletions: async (prefix) => {
            const selection = handles.selectionRef?.current
            if (selection === undefined) return null
            try {
              const options: AutocompleteItem[] = (await reasoningEffortsFor(selection)).map(effort => ({
                value: effort.id,
                label: `${effort.id} — ${effort.name}`,
                description: effort.description,
              }))
              return filterCommandOptions(options, prefix)
            } catch {
              return null
            }
          },
        },
        { name: 'new', description: t('cmdNew') },
        {
          name: 'sessions',
          description: t('cmdResume'),
          argumentHint: '<sessionId>',
          getArgumentCompletions: async (prefix) => {
            try {
              const records = await ctx.sessionQuery.listSessions()
              const workspace = (agent ?? liveAgent).session.header.cwd ?? process.cwd()
              const options: AutocompleteItem[] = filterProjectSessions(records, workspace)
                .map(record => {
                  const id = String(record.header.id)
                  const created = new Date(record.header.createdAt ?? 0).toLocaleString()
                  return { value: id, label: id, description: created }
                })
              return filterCommandOptions(options, prefix)
            } catch {
              return null
            }
          },
        },
        { name: 'status', description: t('cmdDetails') },
        { name: 'skills', description: t('cmdSkills') },
        {
          name: 'agents',
          description: t('cmdMode'),
          argumentHint: '<standard|minimal|code|cordis|user preset>',
          getArgumentCompletions: async (prefix) => {
            const roster = ctx.agentPresets
            let extra: AutocompleteItem[] = []
            if (roster !== undefined) {
              try {
                const shipped = new Set(modeOptions.map(option => option.value))
                extra = (await roster.list())
                  .filter(preset => preset.broken === undefined && !shipped.has(preset.id))
                  .map(preset => ({
                    value: preset.id,
                    label: `${preset.id} — ${preset.name ?? preset.id}`,
                    description: preset.description,
                  }))
              } catch {
                // Roster unreadable: shipped set only.
              }
            }
            return filterCommandOptions([...modeOptions, ...extra], prefix)
          },
        },
        { name: 'settings', description: t('cmdSettings') },
        ...ctx.commands.list(target).map((command): SlashCommand => {
          if (command.name === 'permission') {
            return {
              name: command.name,
              description: t('cmdPermission'),
              argumentHint: permissionCommand.argumentHint,
              getArgumentCompletions: prefix => filterCommandOptions(permissionCommand.options, prefix),
            }
          }
          return {
            name: command.name,
            description: command.description,
            ...command.input === undefined ? {} : { argumentHint: command.input.hint },
          }
        }),
      ]
      let commandEntries = commandEntriesFor(agent ?? liveAgent)
      const pushCommandCatalog = (sourceSessionId = foregroundSessionId()): void => {
        const target = agent ?? liveAgent
        const commands = target.session.header.origin === 'subagent' ? [] : commandEntries.map(command => ({
          name: command.name,
          description: command.description ?? '',
          ...(command.argumentHint === undefined ? {} : { argumentHint: command.argumentHint }),
        }))
        rendererSend?.('command-catalog', { sessionId: sourceSessionId, commands })
      }
      const refreshSkillCommands = async (): Promise<void> => {
        const target = agent ?? liveAgent
        const targetId = String(target.session.id)
        if (target.session.header.origin === 'subagent') {
          skillList.length = 0
          commandEntries = commandEntriesFor(target)
          notifySkills(targetId)
          pushCommandCatalog(targetId)
          return
        }
        try {
          const workspace = target.session.header.cwd ?? process.cwd()
          const snapshot = await ctx.skills.snapshot({ cwd: workspace })
          if ((agent ?? liveAgent) !== target) return
          skillList.length = 0
          for (const skill of snapshot.skills) skillList.push({ name: skill.name, description: skill.description ?? '' })
          notifySkills(targetId)
          commandEntries = commandEntriesFor(target)
          for (const skill of snapshot.skills) commandEntries.push({ name: `skill:${skill.name}`, description: t('helpSkillInvoke') })
          pushCommandCatalog(targetId)
        } catch (error: unknown) {
          if ((agent ?? liveAgent) !== target) return
          skillList.length = 0
          commandEntries = commandEntriesFor(target)
          notifySkills(targetId)
          pushCommandCatalog(targetId)
          appendNotice(`Could not load skills: ${errorChain(error)}`, 'warning')
        }
      }

        const imageCapabilityByRoute = new Map<string, boolean>()
        const initialRoute: 'home' | 'session' = startup.resumeSessionId === undefined ? 'home' : 'session'
        /**
         * Full transcript projections are immutable until the append-only log grows. Switching
         * away and back to an open tab should not re-fold the same history; event count plus
         * the last sequence is enough to invalidate append-only logs.
         */
        const transcriptProjectionCache = new Map<string, {
          readonly eventCount: number
          readonly lastSeq: string
          readonly title: string
          readonly rows: ReturnType<typeof transcriptEvents>
        }>()
        const projectionFor = (current: Agent): { title: string; rows: ReturnType<typeof transcriptEvents> } => {
          const events = sessionEvents(current.session)
          const lastSeq = events.length === 0 ? '-1' : String(events[events.length - 1]?.seq)
          const key = String(current.session.id)
          const cached = transcriptProjectionCache.get(key)
          if (cached !== undefined && cached.eventCount === events.length && cached.lastSeq === lastSeq) {
            return { title: cached.title, rows: cached.rows }
          }
          const title = foldSessionTitle(events)?.title ?? ''
          const rows = transcriptEvents(events)
          transcriptProjectionCache.set(key, { eventCount: events.length, lastSeq, title, rows })
          return { title, rows }
        }
        const availableActionsFor = (target: Agent): string[] => target.session.header.origin === 'subagent'
          ? []
          : [
              ...(ctx.commands.list(target).some(command => command.name === 'compact') ? ['compact'] : []),
              ...(hasConversationData(sessionEvents(target.session)) ? [] : ['mode']),
              ...(jobsRegistry === undefined ? [] : ['shell.jobs']),
              ...(terminalController === undefined ? [] : ['terminal.toggle', 'terminal.select', 'terminal.close']),
            ]
        const snapshotFor = () => {
          const current = agent ?? liveAgent
          const model = displaySelection(current)
          const parent = current.session.header.origin === 'subagent'
            ? current.session.header.parentSession
            : undefined
          const attachmentRoute = `${model.provider}\u0000${model.model}`
          const projection = projectionFor(current)
          return {
            sessionId: String(current.session.id),
            initialRoute,
            ...(current.session.header.origin === 'subagent' ? { readOnly: subagentById.get(String(current.session.id))?.mode !== 'continuable' } : {}),
            ...(parent === undefined ? {} : { parentId: String(parent) }),
            title: projection.title,
            events: projection.rows,
            provider: model.provider,
            model: model.model,
            effort: model.reasoningEffort ?? 'default',
            permission: currentPermissionPreset(ctx, current.session),
            preset: uiMode,
            workspace: current.session.header.cwd ?? process.cwd(),
            availableActions: availableActionsFor(current),
            attachmentCapabilities: {
              files: attachmentStore !== undefined && attachmentStore.saveFile !== AttachmentStore.prototype.saveFile,
              images: imageCapabilityByRoute.get(attachmentRoute) === true,
            },
            // Carry the usage projection with the snapshot. The renderer replaces its
            // session-scoped state on this frame; sending usage only as a separate event
            // lets that reset erase it until the next status update, which is exactly how
            // token/cache statistics vanished after a restart or tab switch.
            ...(lastUsage !== undefined && lastUsage.sessionId === String(current.session.id)
              ? { usage: lastUsage }
              : {}),
          }
        }
        const attachmentStore = ctx.get('attachments')
        const refreshImageCapability = async (target: Agent): Promise<void> => {
          const route = displaySelection(target)
          const routeKey = `${route.provider}\u0000${route.model}`
          try {
            const info = await ctx.llm.resolveModelInfo(route.provider, route.model)
            imageCapabilityByRoute.set(routeKey, info.inputModalities?.includes('image') === true)
          } catch {
            imageCapabilityByRoute.set(routeKey, false)
          }
          if ((agent ?? liveAgent) !== target || rendererSend === undefined) return
          if (rendererSelectionPush !== undefined) rendererSelectionPush()
          else {
            const snapshot = snapshotFor()
            rendererSend('session-snapshot', { ...snapshot, events: [...snapshot.events] })
          }
        }
        // The rail's last presentation snapshot. It is small and lets the first
        // `session-list` paint immediately while the fresh enumeration runs in the
        // background; a missing/corrupt cache is just an empty list.
        const sessionListCachePath = join(process.env.DSH_HOME ?? join(homedir(), '.dsh'), 'dpsk', 'session-list-cache.json')
        let lastSessionRows: SessionListPayload['sessions'] = readSessionListCache(sessionListCachePath)
        let sessionListGeneration = 0
        /**
         * Sessions whose stored log this dsh build cannot read (the v0→v1 migration rejects
         * e.g. `subagent/descriptor` version 2). They cannot be resumed, so they are hidden
         * after one aggregate notice instead of one warning per session on every refresh.
         */
        const unreadableSessions = new Map<string, string>()
        let unreadableNoticeShown = false
        /**
         * What the head of a stored log says about a session that carries no title.
         *
         * dsh writes a `session/title` event only when a title provider ran. Sessions from
         * before that provider existed have none, and every terminal start materializes one
         * more empty session, so the list filled up with rows reading "New Session" plus an
         * id — indistinguishable from each other and from a real conversation. The head of
         * the log answers both questions: whether the session ever got past its setup events
         * (the desktop hides those) and what the user said first (the label every surface
         * derives a title from).
         */
        interface SessionHead {
          readonly label?: string
          readonly blank: boolean
        }
        const sessionHeads = new Map<string, SessionHead>()
        const FIRST_PROMPT_SCAN_EVENTS = SESSION_HEAD_SCAN_EVENTS
        const readSessionHead = async (id: string): Promise<SessionHead> => {
          const cached = sessionHeads.get(id)
          if (cached !== undefined) return cached
          let head: SessionHead = { blank: false }
          try {
            const handle = await ctx.sessionPersistence.open(SessionId(id), 'read')
            try {
              const { events } = await handle.read(0, FIRST_PROMPT_SCAN_EVENTS)
              let label: string | undefined
              let blank = true
              for (const event of events) {
                if (label === undefined) label = userMessageText(event)
                if (hasConversationEvent(event)) blank = false
              }
              head = { ...(label === undefined ? {} : { label }), blank }
            } finally {
              await handle.close()
            }
          } catch {
            // An unreadable head is not fatal: keep the row visible and untitled.
            head = { blank: false }
          }
          // Only settled answers are cached: a live blank session says its first word later.
          if (!head.blank) sessionHeads.set(id, head)
          return head
        }
        /** Resolve fallback labels and blank flags for every untitled row, a few reads at a time. */
        const fillSessionHeads = async (ids: readonly string[], titles: Map<string, string>, blanks: Map<string, boolean>): Promise<void> => {
          const queue = [...ids]
          const worker = async (): Promise<void> => {
            for (let next = queue.shift(); next !== undefined; next = queue.shift()) {
              const head = await readSessionHead(next)
              if (head.label !== undefined) titles.set(next, head.label)
              if (head.blank) blanks.set(next, true)
            }
          }
          await Promise.all(Array.from({ length: Math.min(8, queue.length) }, worker))
        }
        const pushSessionListNow = async (): Promise<void> => {
          if (rendererSend === undefined) return
          const generation = ++sessionListGeneration
          const currentId = String((agent ?? liveAgent).session.id)
          let records: Awaited<ReturnType<typeof ctx.sessionQuery.listSessions>>
          try {
            records = await ctx.sessionQuery.listSessions()
          } catch (error: unknown) {
            if (generation === sessionListGeneration) appendNotice(t('noticeSessionListFailed', { error: errorChain(error) }), 'error')
            return
          }
          const liveAgents = ctx.agents.list()
          type SessionSource = { header: (typeof records)[number]['header'] }
          const sourceById = new Map<string, SessionSource>()
          for (const record of records) sourceById.set(String(record.header.id), { header: record.header })
          const agentById = new Map<string, Agent>()
          for (const candidate of liveAgents) {
            const id = String(candidate.session.id)
            agentById.set(id, candidate)
            if (!sourceById.has(id)) sourceById.set(id, { header: candidate.session.header })
          }
          const ids = [...sourceById.keys()]
          const readable = ids.filter(id => !unreadableSessions.has(id))
          const titleById = new Map<string, string>()
          let newlyUnreadable = 0
          const markUnreadable = (id: string, reason: string): void => {
            if (unreadableSessions.has(id)) return
            unreadableSessions.set(id, reason)
            newlyUnreadable += 1
          }
          try {
            const titles = await ctx.sessionQuery.readTitleSnapshots(readable.map(id => SessionId(id)))
            for (const observation of titles) {
              const id = String(observation.sessionId)
              if (observation.status === 'fulfilled') {
                titleById.set(id, observation.value.title?.title ?? '')
              } else {
                markUnreadable(id, errorChain(observation.reason))
              }
            }
            for (const id of readable) {
              if (titleById.has(id)) continue
              // A live agent always has a title in memory. A persisted session without a
              // title snapshot is simply untitled (a blank or never-titled session), not
              // unreadable: the renderer paints its own "New Session" label for the empty
              // string, so hiding the session would lose a real conversation.
              titleById.set(id, '')
            }
          } catch (error: unknown) {
            // The whole batch failed: keep live agents usable and drop the rest.
            for (const id of readable) {
              if (agentById.has(id)) titleById.set(id, '')
              else markUnreadable(id, errorChain(error))
            }
            if (readable.length === 0) appendNotice(t('noticeSessionListFailed', { error: errorChain(error) }), 'error')
          }
          if (newlyUnreadable > 0 && !unreadableNoticeShown) {
            unreadableNoticeShown = true
            appendNotice(t('noticeSessionsSkipped', { count: String(unreadableSessions.size) }), 'info')
          }
          // Rows that never got a title still need to be told apart, and the ones that never
          // got a conversation need hiding: the head of the log answers both.
          const untitled = readable.filter(id => (titleById.get(id) ?? '') === '')
          const blankById = new Map<string, boolean>()
          if (untitled.length > 0) await fillSessionHeads(untitled, titleById, blankById)
          if (generation !== sessionListGeneration || String((agent ?? liveAgent).session.id) !== currentId) return
          let persistenceSnapshots: Awaited<ReturnType<typeof ctx.sessionPersistence.list>> = []
          try {
            persistenceSnapshots = await ctx.sessionPersistence.list()
          } catch {
            // Tails are optional: fall back to live events/createdAt and keep the list usable.
          }
          const snapshotById = new Map(persistenceSnapshots.map(snapshot => [String(snapshot.header.id), snapshot]))
          const unsorted: SessionListPayload['sessions'] = await Promise.all(
            [...sourceById.entries()]
              .filter(([id]) => !unreadableSessions.has(id))
              .map(async ([id, source]) => {
                const parent = source.header.origin === 'subagent'
                  && source.header.parentSession !== undefined
                  && sourceById.has(String(source.header.parentSession))
                  ? String(source.header.parentSession)
                  : undefined
                const liveAgent = agentById.get(id)
                const liveEvents = liveAgent === undefined ? undefined : sessionEvents(liveAgent.session)
                const blank = sessionListBlank({
                  title: titleById.get(id) ?? '',
                  ...(liveEvents === undefined
                    ? { persistedBlank: blankById.get(id) === true }
                    : { liveEvents }),
                })
                let lastActivityAt = liveAgent === undefined ? undefined : liveLastActivity(liveAgent.session)
                if (lastActivityAt === undefined) {
                  try {
                    lastActivityAt = await sessionActivity.lastActivityAt(SessionId(id), snapshotById.get(id))
                  } catch {
                    // Missing/unreadable tail: sort and group through createdAt below.
                  }
                }
                return {
                  id,
                  title: titleById.get(id) || (source.header.origin === 'subagent' ? subagentById.get(id)?.label ?? '' : ''),
                  sessionKind: source.header.origin === 'subagent' ? 'subagent' as const : 'main' as const,
                  canInteract: source.header.origin === 'subagent' && liveAgent !== undefined && subagentById.get(id)?.mode === 'continuable',
                  active: id === currentId,
                  ...(source.header.cwd === undefined ? {} : { workspace: source.header.cwd }),
                  ...(parent === undefined ? {} : { parentId: parent }),
                  createdAt: source.header.createdAt,
                  ...(lastActivityAt === undefined ? {} : { lastActivityAt }),
                  status: liveAgent?.status === 'running' ? 'running' : 'idle',
                  attention: false,
                  ...(blank ? { blank: true } : {}),
                }
              }),
          )
          const sessions = sortSessionsByActivity(unsorted)
          lastSessionRows = sessions
          rendererSend('session-list', { sessions, current: currentId })
          void writeSessionListCache(sessionListCachePath, sessions).catch(() => undefined)
        }

        let sessionListInFlight = false
        let sessionListQueued = false
        const pushSessionList: () => Promise<void> = async () => {
          if (sessionListInFlight) {
            sessionListQueued = true
            return
          }
          sessionListInFlight = true
          try {
            await pushSessionListNow()
          } finally {
            sessionListInFlight = false
            if (sessionListQueued) {
              sessionListQueued = false
              void pushSessionList()
            }
          }
        }

        const listMcpServers = (): readonly McpServerItem[] | undefined => {
          const loader = ctx.loader
          if (loader === undefined) return undefined
          const servers: McpServerItem[] = []
          for (const entry of loader.entries()) {
            if (entry.options.name !== '@deepseek-ai/dsh-mcp-client') continue
            const config = typeof entry.options.config === 'object' && entry.options.config !== null
              ? entry.options.config as Record<string, unknown>
              : undefined
            const name = typeof config?.serverName === 'string' && config.serverName !== '' ? config.serverName : entry.id
            // The Loader's own fiber state is the only truthful lifecycle we have; a missing
            // fiber (or a disposed one) is reported as unknown rather than guessed into
            // "connected". The numbering is `FiberState` in cordis: 0 pending, 1 loading,
            // 2 active, 3 failed, 4 disposed, 5 unloading.
            const fiberState = entry.fiber?.state
            const status = fiberState === 0 ? 'pending'
              : fiberState === 1 ? 'loading'
                : fiberState === 2 ? 'active'
                  : fiberState === 3 ? 'failed'
                    : fiberState === 5 ? 'unloading'
                      : null
            servers.push({ id: entry.id, name, status })
          }
          servers.sort((left, right) => left.name.localeCompare(right.name) || left.id.localeCompare(right.id))
          return servers
        }

        /**
         * The MCP inventory is a live stream, not a mount-time snapshot: `fiberPhase` moves
         * `pending → loading → active/failed` while the process runs, and a pane that read the
         * loader once would report the startup phase forever. The watcher below re-emits only
         * when the projection actually changed, so idle turns cost one cheap loader scan.
         */
        const mcpServersListeners = new Set<(servers: readonly McpServerItem[]) => void>()
        const emitMcpServers = (): void => {
          const servers = listMcpServers() ?? []
          for (const emit of mcpServersListeners) emit(servers)
        }
        let lastMcpServersSignature = JSON.stringify(listMcpServers() ?? [])
        ctx.effect(() => {
          const timer = setInterval(() => {
            const signature = JSON.stringify(listMcpServers() ?? [])
            if (signature === lastMcpServersSignature) return
            lastMcpServersSignature = signature
            emitMcpServers()
          }, 2000)
          return () => clearInterval(timer)
        })

        const listHostPlugins = async (): Promise<readonly HostPluginItem[] | undefined> => {
          try {
            const snapshot = await readPluginInventory(ctx)
            return snapshot.entries.map(entry => ({
              id: String(entry.entryId),
              moduleName: entry.moduleName,
              enabled: entry.enabled,
              fiberPhase: entry.fiberPhase,
            }))
          } catch (error: unknown) {
            appendNotice(`Could not read plugin inventory: ${errorChain(error)}`, 'warning')
            return undefined
          }
        }

        const shellJobsFor = (sessionId: string): ShellJobWireView[] => {
          if (jobsRegistry === undefined) return []
          const ownerId = SessionId(sessionId)
          return jobsRegistry.list(ownerId)
            .filter((job: JobView) => job.owner !== undefined && String(job.owner) === sessionId && (job.kind === 'bash' || job.kind === 'pwsh'))
            .map(job => ({
              id: String(job.id),
              kind: job.kind,
              label: job.label,
              ...(job.owner === undefined ? {} : { owner: String(job.owner) }),
              ...(job.outputLimitBytes === undefined ? {} : { outputLimitBytes: job.outputLimitBytes }),
              status: job.status,
              ...(job.progress === undefined ? {} : { progress: job.progress }),
              ...(job.detail === undefined ? {} : { detail: job.detail }),
              startedAt: job.startedAt,
              ...(job.finishedAt === undefined ? {} : { finishedAt: job.finishedAt }),
              output: {
                total: job.output.total,
                earliest: job.output.earliest,
                ...(job.output.spillPaths === undefined ? {} : { spillPaths: [...job.output.spillPaths] }),
              },
            }))
        }

        const operateShellJob = async (request: ShellJobOpPayload): Promise<unknown> => {
          if (jobsRegistry === undefined) throw new Error('shell jobs are not available in this deployment')
          const ownerId = SessionId(request.sessionId)
          const target = ctx.agents.get(ownerId)
          if (target === undefined) throw new Error(`session ${request.sessionId} is not live`)
          if (target.session.header.origin === 'subagent') throw new Error('subagent sessions are read-only')
          const id = JobId(request.id)
          const job = jobsRegistry.get(id, ownerId)
          if ((job.kind !== 'bash' && job.kind !== 'pwsh') || job.owner === undefined || String(job.owner) !== request.sessionId) {
            throw new Error(`job ${request.id} is not a shell job owned by session ${request.sessionId}`)
          }
          if (request.op === 'read') return jobsRegistry.readAt(id, request.from ?? 0, ownerId) satisfies JobOutputRead
          return { result: jobsRegistry.kill(id, ownerId) }
        }

        const operateTerminal = async (
          request: TerminalOpPayload,
          emit: (kind: 'terminal-frame' | 'terminal-end', payload: TerminalFramePayload | TerminalEndPayload) => void,
        ): Promise<unknown> => {
          const controller = terminalController
          if (controller === undefined) throw new Error('interactive terminals are not available in this deployment')
          const target = ctx.agents.get(SessionId(request.sessionId))
          if (target === undefined || String(target.session.id) !== request.sessionId) throw new Error(`session ${request.sessionId} is not live`)
          if (target.session.header.origin === 'subagent') throw new Error('subagent sessions are read-only')
          const sessionId = String(target.session.id)
          const terminalId = (id: string): WebTerminalId => id as WebTerminalId
          const attachmentId = (id: string): TerminalAttachmentId => id as TerminalAttachmentId
          const copyInfo = (info: HostWebTerminalInfo) => ({
            id: String(info.id),
            title: info.title,
            shell: { path: info.shell.path, args: [...info.shell.args], name: info.shell.name },
            cwd: info.cwd,
            cols: info.cols,
            rows: info.rows,
            state: info.state,
            exitCode: info.exitCode,
            ...(info.error === undefined ? {} : { error: info.error }),
            ...(info.controllerId === undefined ? {} : { controllerId: String(info.controllerId) }),
          })
          if (request.op === 'list') {
            return {
              terminals: controller.list(target.session.id).map(copyInfo),
              environment: { ...controller.environment(target, new AbortController().signal) },
            }
          }
          if (request.op === 'create') {
            const created = await controller.create(target, {
              id: terminalId(request.id),
              cols: request.cols,
              rows: request.rows,
              ...(request.shellPath === undefined ? {} : { shellPath: request.shellPath }),
            }, new AbortController().signal)
            ownedTerminals.set(`${sessionId}\0${request.id}`, { sessionId, id: request.id })
            return copyInfo(created)
          }
          if (request.op === 'retain') {
            const key = terminalFollowerKey(sessionId, request.id, request.attachmentId)
            if (terminalRetains.has(key)) throw new Error('this terminal window is already retained')
            const hold: { readonly abort: AbortController; task?: Promise<void> } = { abort: new AbortController() }
            terminalRetains.set(key, hold)
            let resolveStarted: () => void = () => undefined
            let rejectStarted: (error: unknown) => void = () => undefined
            const started = new Promise<void>((resolve, reject) => { resolveStarted = resolve; rejectStarted = reject })
            hold.task = (async () => {
              let acknowledged = false
              try {
                for await (const _frame of controller.retain(target.session.id, terminalId(request.id), hold.abort.signal)) {
                  if (!acknowledged) {
                    acknowledged = true
                    resolveStarted()
                  }
                }
                if (!acknowledged) rejectStarted(new Error('terminal retention ended before its acknowledgement'))
              } catch (error: unknown) {
                if (!acknowledged) rejectStarted(error)
              } finally {
                if (terminalRetains.get(key) === hold) terminalRetains.delete(key)
              }
            })()
            await started
            return undefined
          }
          if (request.op === 'release') {
            const key = terminalFollowerKey(sessionId, request.id, request.attachmentId)
            const hold = terminalRetains.get(key)
            if (hold === undefined) return undefined
            hold.abort.abort()
            await hold.task
            return undefined
          }
          if (request.op === 'follow') {
            const key = terminalFollowerKey(sessionId, request.id, request.attachmentId)
            if (terminalFollowers.has(key)) throw new Error('this terminal attachment is already following')
            const follower: { readonly sessionId: string; readonly id: string; readonly attachmentId: string; readonly abort: AbortController; task?: Promise<void> } = { sessionId, id: request.id, attachmentId: request.attachmentId, abort: new AbortController() }
            terminalFollowers.set(key, follower)
            let resolveStarted: () => void = () => undefined
            let rejectStarted: (error: unknown) => void = () => undefined
            const started = new Promise<void>((resolve, reject) => { resolveStarted = resolve; rejectStarted = reject })
            follower.task = (async () => {
              let sawFrame = false
              try {
                for await (const frame of controller.follow(target, terminalId(request.id), attachmentId(request.attachmentId), follower.abort.signal)) {
                  const wireFrame: TerminalFrame = frame
                  emit('terminal-frame', { sessionId, id: request.id, attachmentId: request.attachmentId, frame: wireFrame })
                  if (!sawFrame) {
                    sawFrame = true
                    resolveStarted()
                  }
                }
                if (!sawFrame) rejectStarted(new Error('terminal follow ended before its initial screen'))
                else if (!follower.abort.signal.aborted) emit('terminal-end', { sessionId, id: request.id, attachmentId: request.attachmentId })
              } catch (error: unknown) {
                if (!sawFrame) rejectStarted(error)
                else if (!follower.abort.signal.aborted) emit('terminal-end', { sessionId, id: request.id, attachmentId: request.attachmentId, error: errorChain(error) })
              } finally {
                if (!sawFrame && follower.abort.signal.aborted) rejectStarted(new Error('terminal follow was detached before its initial screen'))
                if (terminalFollowers.get(key) === follower) terminalFollowers.delete(key)
              }
            })()
            await started
            return undefined
          }
          if (request.op === 'detach') {
            terminalFollowers.get(terminalFollowerKey(sessionId, request.id, request.attachmentId))?.abort.abort()
            return undefined
          }
          if (request.op === 'write') {
            await controller.write(target, terminalId(request.id), attachmentId(request.attachmentId), request.data)
            return undefined
          }
          if (request.op === 'resize') {
            await controller.resize(target, terminalId(request.id), attachmentId(request.attachmentId), request.cols, request.rows)
            return undefined
          }
          await controller.close(target, terminalId(request.id))
          ownedTerminals.delete(`${sessionId}\0${request.id}`)
          for (const follower of terminalFollowers.values()) {
            if (follower.sessionId === sessionId && follower.id === request.id) follower.abort.abort()
          }
          for (const [key, hold] of terminalRetains) {
            if (!key.startsWith(`${sessionId}\0${request.id}\0`)) continue
            hold.abort.abort()
            await hold.task
          }
          return undefined
        }
        /**
         * The workspace paths the renderer's `@` completion reads. The host owns the index
         * (the session cwd, dot directories skipped, at most 2000 entries, directories
         * first with a trailing `/`), so the renderer never walks the disk and a mention
         * can only name a path that is really in the workspace. A read failure is reported
         * as an empty list with a notice, never as a silent success.
         */
        let workspaceListGeneration = 0
        const pushWorkspaceFiles = async (): Promise<void> => {
          if (rendererSend === undefined) return
          const current = agent ?? liveAgent
          const targetId = String(current.session.id)
          const generation = ++workspaceListGeneration
          const workspace = current.session.header.cwd ?? process.cwd()
          try {
            const files = await listWorkspaceFiles(workspace)
            if (generation !== workspaceListGeneration || foregroundSessionId() !== targetId) return
            rendererSend('workspace-files', { sessionId: targetId, files })
          } catch (error: unknown) {
            if (generation !== workspaceListGeneration || foregroundSessionId() !== targetId) return
            rendererSend('workspace-files', { sessionId: targetId, files: [] })
            appendNotice(t('noticeWorkspaceListFailed', { error: errorChain(error) }), 'warning')
          }
        }
        /**
         * The provider a `custom-model` form was built for. The renderer's
         * `form-submit` carries only the field values, so the host remembers which
         * provider the field list was built for; the write goes to that provider's
         * session-title settings, not to whatever is active when the answer arrives.
         */
        const formProvider = new Map<string, string>()
        /**
         * The nested per-model editor's state: the flat line the editor was opened from
         * and the model picked in the list. The model form's `form-submit` carries only
         * the field values, so the merge happens against the remembered line and replaces
         * the remembered model.
         */
        const modelLines = new Map<string, string>()
        const modelEditIds = new Map<string, string>()
        /** Headless daemon: the renderer arrives later over the local socket. */
        const daemonMode = ctx.tuiStartup.daemon === true
        const daemonGone = { handle: (): void => undefined }
        const daemonBridge = daemonMode ? createDaemonBridge(() => daemonGone.handle()) : undefined
        const daemonHostView = daemonMode
          ? (() => {
              const view = defaultHostView('my-dpsk-harness-tui', '0.5.0', true)
              return { ...view, capabilities: [...view.capabilities, 'daemon-detach'] }
            })()
          : undefined
        const mountResult = mountRenderer({
          rendererPath: daemonMode ? 'daemon' : resolveRendererPath('0.5.0', packageRoot),
          ...(daemonHostView === undefined ? {} : { hostView: daemonHostView }),
          ...(daemonBridge === undefined ? {} : { spawn: () => daemonBridge.child }),
          allowReattach: daemonMode,
          detachOnBye: daemonMode,
          isRendererAttached: daemonBridge === undefined ? undefined : () => daemonBridge.connected(),
          ...(daemonMode ? { write: () => undefined, logPath: daemonPaths().log } : {}),
          snapshot: snapshotFor,
          submit: submitRendererMessage,
          onTerminalScheme: scheme => {
            currentScheme = scheme
          },
          // The renderer's `/settings` page reads the host's settings section and
          // writes through the same seam; the renderer never touches `ctx.settings`.
          settingsSection: () => {
            const values = settingsValues(ctx, TUI_SETTINGS_NAMESPACE) as Record<string, unknown> | undefined
            // The parallel tool call cap lives in the agent-loop namespace, not the TUI
            // one; the renderer's settings page shows it as its own row and writes it
            // back with `ns` on `update-settings`.
            const loop = settingsValues(ctx, settingsNamespace('agent-loop')) as { maxParallelToolCalls?: number } | undefined
            const autostart = autostartStatus()
            return {
              ns: TUI_SETTINGS_NAMESPACE,
              schemaVersion: 2,
              // Resolved defaults first, persisted overrides second: the renderer paints the
              // same values the host would use, even for a field the user never wrote.
              values: {
                themeName: resolved.themeName ?? 'opencode',
                themeMode: resolved.themeMode ?? 'system',
                // `config.newDesigns` is a live ref, never `true`: read the resolved value.
                newDesigns: resolved.newDesigns,
                autostart: autostart.enabled,
                autostartSupported: autostart.supported,
                pathDisplay: resolved.pathDisplay,
                leftPrompt: resolved.leftPrompt,
                rightPrompt: resolved.rightPrompt,
                // Native presentation defaults the renderer's spinner, fold budget, and
                // attention service read directly.
                animations: resolved.animations,
                attentionNotifications: resolved.attentionNotifications,
                attentionSound: resolved.attentionSound,
                attentionVolume: resolved.attentionVolume,
                ...(values ?? {}),
              },
              ...(typeof loop?.maxParallelToolCalls === 'number' ? { agentLoop: { maxParallelToolCalls: loop.maxParallelToolCalls } } : {}),
            }
          },
          updateSettings: async (patch, ns) => {
            const forms = ctx.settings
            if (forms === undefined) throw new Error('settings are not available in this deployment')
            await forms.update(ns === 'agent-loop' ? settingsNamespace('agent-loop') : TUI_SETTINGS_NAMESPACE, patch)
          },
          // The renderer cannot import this module (separate process), so the locale
          // and the dictionary go over IPC.
          i18n: () => ({ locale: resolved.locale, strings: messagesFor(resolved.locale) }),
          // The provider form is drawn by the renderer; the host reads the draft and
          // writes the values through its own seams, so the id rules, the credential
          // reference, and the settings mutations stay in one place. The model catalog
          // is one id per line — the nested per-model editor (name / efforts / context
          // / maxTokens) is not in the renderer, so the fields the host can express as
          // lines are the ones the form carries.
          extensionDialogReply: (requestId, value) => extensionDialogs.get(requestId)?.(value),
          shortcut: combo => {
            // The renderer sends the canonical combo (`ctrl+alt+shift+name`); the
            // registrations are written in pi-tui order, so both sides normalize to
            // the modifier set plus the base key before matching.
            const canonical = (text: string): string => {
              const parts = text.toLowerCase().split('+')
              const base = parts[parts.length - 1] ?? ''
              const mods = new Set(parts.slice(0, -1))
              const ordered: string[] = []
              if (mods.has('ctrl')) ordered.push('ctrl')
              if (mods.has('alt')) ordered.push('alt')
              if (mods.has('shift')) ordered.push('shift')
              return ordered.length === 0 ? base : `${ordered.join('+')}+${base}`
            }
            const wanted = canonical(combo)
            for (const registration of extensions.shortcuts.snapshot()) {
              if (canonical(registration.combo) === wanted) {
                extensions.shortcuts.dispatch(registration.combo)
                return
              }
            }
          },
          onBye: () => daemonMode ? daemonBridge?.detach() : ctx.appExit?.(0),
          onShutdown: () => ctx.appExit?.(0),
          autostartOp: async enabled => {
            const command = [process.execPath, join(packageRoot, 'scripts', 'dpsk.js'), 'daemon', 'start', '--quiet', '--daemon-cwd', homedir()]
            const status = await setAutostart(enabled, command)
            if (enabled && !status.enabled) throw new Error(status.detail)
            return status
          },
          onRendererExit: () => {
            for (const controller of continuedQuestionControllers) controller.abort()
            for (const follower of terminalFollowers.values()) follower.abort.abort()
            for (const hold of terminalRetains.values()) hold.abort.abort()
          },
          formSpec: async (form, args) => {
            if (form === 'custom-model') {
              // The custom model is one line of text written through the session-title
              // settings namespace, the same seam the pi-tui prompt uses. The provider
              // comes from the renderer's request, falling back to the active model
              // selection (`handles.selectionRef`, not the theme `selection` the mount
              // deps carry), and is remembered for the write.
              const provider = typeof args?.provider === 'string' ? args.provider : handles.selectionRef?.current?.provider ?? ''
              formProvider.set(form, provider)
              return {
                title: t('settingsEditCustomModel'),
                fields: [{ key: 'model', label: t('providerFieldModel'), kind: 'text', value: '' }],
              }
            }
            if (form !== 'provider') return undefined
            const id = typeof args?.id === 'string' ? args.id : undefined
            const draft = await providerDraftFor(id)
            return {
              title: id === undefined ? t('settingsAddProvider') : t('settingsEditProvider'),
              fields: [
                { key: 'id', label: t('providerFieldId'), kind: 'text', value: draft.id },
                { key: 'name', label: t('providerFieldName'), kind: 'text', value: draft.name },
                { key: 'api', label: t('providerFieldApi'), kind: 'select', value: draft.api, options: ['', ...SUPPORTED_PROVIDER_APIS] },
                { key: 'baseURL', label: t('providerFieldBaseURL'), kind: 'text', value: draft.baseURL },
                { key: 'apiKey', label: t('providerFieldApiKey'), kind: 'secret', value: '' },
                // One line per model, fields separated by `|`:
                // `id|name|efforts|effort|context|maxTokens`. The catalog is drawn as a
                // multi-line textarea (the field carries `multiline`), so a long model
                // list wraps inside the panel instead of scrolling off a single line.
                // The separator keeps the per-model fields the pi-tui nested editor
                // edits (name / efforts / effort / context / max).
                { key: 'models', label: t('providerFieldModels'), kind: 'text', value: encodeModelsLine(draft.models), multiline: true },
                // The renderer has no button primitive, so the discovery probe is a row
                // in the same field list: Enter on it sends the current values up as
                // `model-discover` and the host answers with the merged line. The probe
                // stays the host's (`ctx.llm.discoverModels` + the namespace lookup), so
                // the renderer path gets the same discovery the pi-tui form has.
                { key: 'discover', label: t('providerFieldDiscover'), kind: 'action', value: t('providerFieldDiscover') },
                // The nested per-model editor: Enter on this row asks the host for the
                // model list the current line carries, the renderer opens a select over
                // it, and picking a model opens a form for that model's fields. The
                // parsing, the encoding, and the merge all stay in the host.
                { key: 'edit-models', label: t('providerFieldEditModels'), kind: 'action', value: t('providerFieldEditModels') },
              ],
            }
          },
          formSubmit: async (form, values) => {
            if (form === 'custom-model') {
              const model = (values.model ?? '').trim()
              if (model === '') return
              const provider = formProvider.get(form) ?? handles.selectionRef?.current?.provider ?? ''
              if (provider === '') return
              await settings.update(SESSION_TITLE_SETTINGS_NAMESPACE, { provider, model })
              const sessionTitle = ctx.get('sessionTitle')
              if (sessionTitle !== undefined) void sessionTitle.refresh((agent ?? liveAgent).session).catch(() => undefined)
              appendNotice(t('noticeTitleModelSet', { provider, model }), 'info')
              return
            }
            if (form === 'model') {
              // The model form's submit merges into the line the editor was opened from,
              // replacing the model that was picked. The submitted `id` renames the model.
              const line = modelLines.get('provider') ?? ''
              const picked = modelEditIds.get('provider') ?? ''
              const parsed = parseModelsLine(line)
              const index = parsed.findIndex(candidate => candidate.id === picked)
              if (index < 0) return
              const id = (values.id ?? '').trim()
              const name = (values.name ?? '').trim()
              const efforts = (values.efforts ?? '').trim()
              const effort = (values.effort ?? '').trim()
              const context = (values.context ?? '').trim()
              const max = (values.max ?? '').trim()
              parsed[index] = {
                // `ProviderModelDraft` requires the id; an empty submitted id keeps the
                // picked one (clearing the id is not a valid edit).
                id: id === '' ? picked : id,
                ...(name === '' ? {} : { name }),
                ...(efforts === '' ? {} : { reasoningEfforts: efforts === 'none' ? false as const : (() => {
                  const map: Record<string, string | null> = {}
                  for (const pair of efforts.split(';')) {
                    const at = pair.indexOf('=')
                    if (at < 0) continue
                    map[pair.slice(0, at)] = pair.slice(at + 1) === '' ? null : pair.slice(at + 1)
                  }
                  return map
                })() }),
                ...(effort === '' ? {} : { reasoningEffort: effort }),
                ...(context === '' ? {} : { contextWindow: Number(context) }),
                ...(max === '' ? {} : { maxTokens: Number(max) }),
              }
              const merged = normalizeProviderModels(parsed)
              appendNotice(t('noticeProviderModelsEdited', { count: merged.length }), 'info')
              return encodeModelsLine(merged)
            }
            if (form !== 'provider') return
            const draft: ProviderDraft = {
              id: (values.id ?? '').trim(),
              name: values.name ?? '',
              api: values.api ?? '',
              baseURL: values.baseURL ?? '',
              apiKey: values.apiKey ?? '',
              models: parseModelsLine(values.models ?? ''),
            }
            await saveProvider(undefined, draft)
          },
          // The provider form's discovery probe is the host's: the renderer sends the
          // field values it has on screen, the host runs `ctx.llm.discoverModels` with
          // them, merges the published ids into the flat line, and sends the line back.
          // The encoding rules, the namespace lookup, and the dedupe stay in one place,
          // so the renderer path gets the same discovery the pi-tui form has.
          modelDiscover: async (form, fields) => {
            if (form !== 'provider') return undefined
            const id = (fields.id ?? '').trim()
            const ns = providerDiscoveryNamespace(id === '' ? undefined : id)
            if (ns === undefined) {
              appendNotice(t('settingsDiscoveryUnavailable'), 'warning')
              return undefined
            }
            const found = await ctx.llm.discoverModels(ns, {
              ...(id === '' ? {} : { provider: id }),
              baseURL: fields.baseURL || undefined,
              apiKey: fields.apiKey || undefined,
              api: fields.api || undefined,
            })
            const current = parseModelsLine(fields.models ?? '')
            const merged = normalizeProviderModels([
              ...current,
              ...found.map(model => ({ id: model.id, ...(model.name === undefined ? {} : { name: model.name }) })),
            ])
            const added = merged.length - current.length
            appendNotice(t(added > 0 ? 'settingsDiscoverMerged' : 'settingsDiscoveredCount', { count: added > 0 ? added : found.length }), 'info')
            return encodeModelsLine(merged)
          },
          // The nested per-model editor: the host parses the flat line for the list, and
          // builds a field form for the picked model. The merge on submit happens against
          // the line the editor was opened from, so the edit lands on the values the
          // renderer has on screen.
          modelListRequest: (form, fields) => {
            if (form !== 'provider') return undefined
            const parsed = parseModelsLine(fields.models ?? '')
            if (parsed.length === 0) return undefined
            return { models: parsed.map(model => ({ id: model.id, label: model.name ?? '' })) }
          },
          modelEdit: (form, id, models) => {
            if (form !== 'provider') return undefined
            const model = parseModelsLine(models).find(candidate => candidate.id === id)
            if (model === undefined) return undefined
            modelLines.set('provider', models)
            modelEditIds.set('provider', id)
            return {
              title: `${t('settingsModels')} · ${model.id}`,
              fields: [
                { key: 'id', label: t('providerFieldId'), kind: 'text', value: model.id },
                { key: 'name', label: t('providerFieldName'), kind: 'text', value: model.name ?? '' },
                { key: 'efforts', label: t('providerFieldEfforts'), kind: 'text', value: encodeEfforts(model.reasoningEfforts) },
                { key: 'effort', label: t('providerFieldEffort'), kind: 'text', value: model.reasoningEffort ?? '' },
                { key: 'context', label: t('providerFieldContext'), kind: 'text', value: typeof model.contextWindow === 'number' ? String(model.contextWindow) : '' },
                { key: 'max', label: t('providerFieldMax'), kind: 'text', value: typeof model.maxTokens === 'number' ? String(model.maxTokens) : '' },
              ],
            }
          },
          // The slash command registry the composer completes against. The host
          // owns the registry; the renderer only completes text and sends it back.
          commands: () => (agent ?? liveAgent).session.header.origin === 'subagent' ? [] : commandEntries.map(command => ({
            name: command.name,
            description: command.description ?? '',
            ...(command.argumentHint === undefined ? {} : { argumentHint: command.argumentHint }),
          })),
          // Session lifecycle goes through the host's own slash-command path, so
          // the unsaved-changes prompt, the title refresh, and the wechat session
          // follow-all stay in one place instead of being duplicated here.
          sessionOp: async (request: SessionOpPayload): Promise<unknown> => {
            const requireSessionId = (): SessionId => {
              if (typeof request.sessionId !== 'string' || request.sessionId.trim() === '') {
                throw new Error(`session ${request.op} requires sessionId`)
              }
              return SessionId(request.sessionId)
            }
            const current = agent ?? liveAgent
            const previousSessionId = String(current.session.id)
            if (request.op === 'new') {
              if (!(await runSessionSwitchDecision(current, 'new'))) throw new Error('session creation cancelled')
              const id = await createAgent({
                ...(request.sessionId === undefined ? {} : { sessionId: SessionId(request.sessionId) }),
                ...(request.cwd === undefined ? {} : { cwd: request.cwd }),
                ...(request.selection === undefined ? {} : { selection: request.selection }),
              })
              notifySessionSwitched('new', String(id), previousSessionId)
              return { sessionId: String(id) }
            }
            if (request.op === 'switch') {
              const id = requireSessionId()
              if (!(await runSessionSwitchDecision(current, 'resume', String(id)))) throw new Error('session switch cancelled')
              await switchAgent(id)
              notifySessionSwitched('resume', String(id), previousSessionId)
              return { sessionId: String(id) }
            }
            if (request.op === 'read') {
              const id = requireSessionId()
              return await ctx.sessionQuery.readSession(id)
            }
            if (request.op === 'rename') {
              const id = requireSessionId()
              if (typeof request.title !== 'string') throw new Error('session rename requires title')
              const target = await resumeAgent(id)
              const titles = ctx.get('sessionTitle')
              if (titles === undefined) throw new Error('session title service is unavailable')
              const snapshot = titles.rename(target.session, request.title)
              if (String((agent ?? liveAgent).session.id) === String(id)) rendererSnapshotPush?.()
              void pushSessionList()
              return snapshot
            }
            if (request.op === 'fork') {
              const id = requireSessionId()
              const sourceAgent = agent ?? liveAgent
              const sourceId = SessionId(String(sourceAgent.session.id))
              if (id === sourceId) throw new Error('fork target must differ from its source session')
              if (typeof request.boundary !== 'number' || !Number.isSafeInteger(request.boundary) || request.boundary < 0) {
                throw new Error('session fork requires an inclusive event boundary')
              }
              if (!(await runSessionSwitchDecision(sourceAgent, 'new', String(id)))) throw new Error('session fork cancelled')
              const source = await ctx.sessionQuery.readSession(sourceId)
              const boundaryEvent = source.events[request.boundary]
              if (boundaryEvent === undefined || boundaryEvent.seq !== SessionSeq(request.boundary)) {
                throw new Error(`event ${request.boundary} is not present in session ${sourceId}`)
              }
              const sourceSelection = displaySelection(sourceAgent)
              const newId = await createAgent({
                sessionId: id,
                baseAgent: sourceAgent,
                cwd: source.session.cwd ?? process.cwd(),
                selection: {
                  provider: sourceSelection.provider,
                  model: sourceSelection.model,
                  ...(sourceSelection.reasoningEffort === undefined ? {} : { effort: String(sourceSelection.reasoningEffort) }),
                  preset: modeForSession(ctx, sourceAgent.session, resolveDefaultMode()),
                  permission: currentPermissionPreset(ctx, sourceAgent.session),
                },
                fork: {
                  parentSession: sourceId,
                  seed: buildForkSeed(source.events, SessionSeq(request.boundary)),
                  inheritedEventCount: request.boundary + 1,
                },
              })
              notifySessionSwitched('new', String(newId), previousSessionId)
              return { sessionId: String(newId) }
            }
            throw new Error(`unsupported session operation: ${request.op}`)
          },
          // A model pick writes through the host's selection seam; an effort pick
          // through the effort seam; permission and preset reuse the slash command
          // path, which already handles the registry name translation and the
          // blank-session rule for preset switching.
          setSelection: async selection => {
            const target = agent ?? liveAgent
            if (selection.sessionId !== String(target.session.id)) throw new Error(`selection target ${selection.sessionId} is not the foreground session`)
            if (target.session.header.origin === 'subagent') throw new Error('subagent sessions are read-only')
            if ((selection.provider === undefined) !== (selection.model === undefined)) throw new Error('model selection requires both provider and model')
            if (selection.provider !== undefined && selection.model !== undefined) {
              const save = handles.saveSelection
              if (save === undefined) throw new Error('model selection is not available in this deployment')
              const current = handles.selectionRef?.current
              const matchingEffort = current !== undefined
                && current.provider === selection.provider
                && current.model === selection.model
                ? current.reasoningEffort
                : undefined
              await save({
                provider: selection.provider,
                model: selection.model,
                ...(matchingEffort === undefined ? {} : { reasoningEffort: matchingEffort }),
              })
              void refreshImageCapability(target)
              return
            }
            if (selection.effort !== undefined) {
              const setEffort = handles.setReasoningEffort
              if (setEffort === undefined) throw new Error('reasoning effort is not available for this model')
              await setEffort(ReasoningEffortId(selection.effort))
              return
            }
            if (selection.permission !== undefined) {
              const permission = registryPermissionName(selection.permission)
              const option = ctx.permissionPresets.catalog().options.find(candidate => String(candidate.value) === permission)
              if (option === undefined) throw new Error(`permission preset ${selection.permission} is unavailable`)
              setPermissionPreset(ctx, target.session, option.value)
              updateStatusValues()
              if (rendererSelectionPush !== undefined) {
                rendererSelectionPush({ permission: displayPermissionName(currentPermissionPreset(ctx, target.session)) })
              } else {
                rendererSnapshotPush?.()
              }
              return
            }
            if (selection.preset !== undefined) {
              await applyAgentPreset(target, selection.preset)
              return
            }
            throw new Error('selection has no value')
          },
          // A pick moves the route, so the surfaces that describe it have to be rebuilt: the
          // snapshot carries the route but not the catalogs, and the effort list belongs to
          // the model — without this a second `/model` still marked the replaced model and
          // `/effort` still offered the old model's levels. `pushSessionCatalogs` ends with
          // the model catalog, so the pair is never sent twice.
          onSelectionApplied: () => {
            if (rendererCatalogsPush !== undefined) rendererCatalogsPush()
            else rendererCatalogPush?.()
          },
          // The renderer asks for an exact-session queue edit; Alt+Up uses the
          // current agent and resolves the same session-owned queue.
          editInterjection: takeOldestInterjection,
          readAttachment: readRendererAttachment,
          deleteInterjection,
          turnState: emit => {
            turnStateListeners.add(emit)
            notifyTurnState(agent ?? liveAgent)
            return () => turnStateListeners.delete(emit)
          },
          // The bridge replays its buffer on subscribe, so a QR code produced before
          // the renderer existed reaches the first frame. No bridge → no subscription.
          wechatOutput: emit => subscribeWechat(emit) ?? (() => undefined),
          subagents: emit => subscribeSubagents(emit),
          skills: emit => subscribeSkills(emit),
          // The renderer's usage, branch, plugin, and todo feeds. Each subscribes into
          // the host's own listener set and replays the last value, so the renderer sees
          // the numbers the harness measured, not a second copy of the state.
          usage: emit => {
            usageListeners.add(emit)
            if (lastUsage !== undefined) emit(lastUsage)
            return () => usageListeners.delete(emit)
          },
          gitBranch: emit => {
            gitBranchListeners.add(emit)
            emit(lastGitBranchSessionId, lastGitBranch)
            return () => gitBranchListeners.delete(emit)
          },
          mcpServers: emit => {
            mcpServersListeners.add(emit)
            emit(listMcpServers() ?? [])
            return () => mcpServersListeners.delete(emit)
          },
          hostPlugins: listHostPlugins,
          shellJobs: emit => {
            if (jobsRegistry === undefined) return () => undefined
            for (const live of ctx.agents.list()) {
              const ownerId = String(live.session.id)
              emit(ownerId, shellJobsFor(ownerId))
            }
            return jobsRegistry.events.subscribe({ owners: 'all' }, event => {
              const owner = event.type === 'output' ? event.owner : event.job.owner
              if (owner === undefined) return
              const ownerId = String(owner)
              emit(ownerId, shellJobsFor(ownerId))
            })
          },
          shellJobOp: operateShellJob,
          terminalOp: operateTerminal,
          todos: emit => {
            todoListeners.add(emit)
            if (lastTodos !== undefined) emit(lastTodosSessionId, lastTodos)
            return () => todoListeners.delete(emit)
          },
          // The queue the host owns; the drawer subscribes and gets the last snapshot.
          interjections: emit => {
            queueListeners.add(emit)
            emit(foregroundSessionId(), pendingInterjections.filter(entry => entry.sessionId === foregroundSessionId()).map(entry => ({ id: entry.message.id, text: entry.text })))
            return () => queueListeners.delete(emit)
          },
          interrupt: async request => {
            const target = ctx.agents.get(SessionId(request.sessionId))
            if (target === undefined) throw new Error(`session ${request.sessionId} is not live`)
            if (target.status === 'running') await target.cancel({ kind: 'user' })
          },
          // A bridge command goes through the host's own command path, so argument
          // parsing and the registry's unknown-command rejection stay in one place.
          wechatOp: (op, arg) => {
            submitText(`/wechat-${op}${arg === undefined ? '' : ' ' + arg}`)
          },
          // The reports are the same rows the pi-tui cards print.
          doctor: async op => (op === 'plugins' ? await pluginRows('') : await doctorRows(false)).join('\n'),
          // The renderer owns the TTY, so its measurement is the grid the host has. The mount
          // reports it at startup and on every resize; `/doctor` prints the latest value.
          terminalSize: size => {
            rendererGrid = size
          },
          sessions: () => lastSessionRows,
          // The effort list for the current route is loaded from the provider info,
          // which is async, so it goes out after the handshake catalogs.
          onAcked: send => {
            rendererSend = send
            // Housekeeping enumerates every stored session and may rewrite settings; it is
            // useful but never required for the first frame. Let the renderer paint first.
            setTimeout(() => { void runStartupMigrations() }, 1500)
            const pushSessionCatalogs = (target: Agent): void => {
              const targetId = String(target.session.id)
              if (target.session.header.origin === 'subagent') {
                send('reasoning-efforts', { sessionId: targetId, efforts: [], current: 'default' })
                send('permission-presets', { sessionId: targetId, presets: [] })
                send('agent-presets', { sessionId: targetId, presets: [] })
                rendererCatalogPush?.()
                return
              }
              const selection = displaySelection(target)
              void reasoningEffortsFor(selection).then(infos => {
                if ((agent ?? liveAgent) !== target) return
                send('reasoning-efforts', {
                  sessionId: targetId,
                  efforts: infos.map(info => String(info.id)),
                  current: String(selection.reasoningEffort ?? 'default'),
                })
              }).catch(error => {
                if ((agent ?? liveAgent) !== target) return
                send('reasoning-efforts', { sessionId: targetId, efforts: [], current: String(selection.reasoningEffort ?? 'default') })
                appendNotice(`Could not load reasoning efforts: ${errorChain(error)}`, 'warning')
              })
              const livePermission = displayPermissionName(currentPermissionPreset(ctx, target.session))
              // Reuse the slash-command adapter so the picker gets the same localized names
              // and descriptions as `/help`, instead of the raw registry keys.
              const permissionOptions = permissionCommandMetadata(ctx.permissionPresets, t).options
              send('permission-presets', {
                sessionId: targetId,
                presets: permissionOptions.map(option => ({
                  id: String(option.value),
                  label: option.label,
                  current: String(option.value) === livePermission,
                })),
              })
              const presets = ctx.agentPresets
              if (presets !== undefined) {
                void presets.list().then(roster => {
                  if ((agent ?? liveAgent) !== target) return
                  const rows = roster.filter(preset => preset.broken === undefined).map(preset => ({
                    id: preset.id,
                    label: preset.name ?? preset.id,
                    current: preset.id === modeForSession(ctx, target.session, resolveDefaultMode()),
                  }))
                  send('agent-presets', { sessionId: targetId, presets: rows })
                }).catch(error => {
                  if ((agent ?? liveAgent) !== target) return
                  send('agent-presets', { sessionId: targetId, presets: [] })
                  appendNotice(`Could not load agent presets: ${errorChain(error)}`, 'warning')
                })
              }
              rendererCatalogPush?.()
            }
            rendererCatalogsPush = () => pushSessionCatalogs(agent ?? liveAgent)
            rendererCatalogPush = () => {
              const target = agent ?? liveAgent
              const targetId = String(target.session.id)
              const route = displaySelection(target)
              if (target.session.header.origin === 'subagent') {
                send('model-catalog', { sessionId: targetId, models: [] })
                return
              }
              const profiles = configuredProviderProfiles()
              const providerRows = ctx.llm.listProviders().map(entry => {
                const profile = profiles[entry.id]
                return {
                  id: entry.id,
                  label: profile?.displayName ?? entry.name,
                  api: profile?.api ?? '',
                  ...(profile?.baseURL === undefined ? {} : { baseURL: profile.baseURL }),
                }
              })
              send('provider-catalog', { providers: providerRows })
              void (async () => {
                const rows: Array<{ provider: string; model: string; label: string; current: boolean }> = []
                for (const provider of ctx.llm.listProviders()) {
                  try {
                    const models = await ctx.llm.listModels(provider.id)
                    for (const model of models) {
                      const id = String(model.id)
                      rows.push({
                        provider: provider.id,
                        model: id,
                        label: String(model.name ?? id),
                        current: provider.id === route.provider && id === route.model,
                      })
                    }
                  } catch {
                    // Preserve readable provider rows and the exact active route.
                  }
                }
                if ((agent ?? liveAgent) !== target) return
                if (!rows.some(row => row.current)) {
                  rows.push({ provider: route.provider, model: route.model, label: route.model, current: true })
                }
                send('model-catalog', { sessionId: targetId, models: rows })
              })()
            }
            rendererSelectionPush = options => {
              const target = agent ?? liveAgent
              const route = displaySelection(target)
              const routeKey = `${route.provider}\u0000${route.model}`
              send('selection-state', {
                sessionId: String(target.session.id),
                provider: route.provider,
                model: route.model,
                effort: String(route.reasoningEffort ?? 'default'),
                ...(options?.permission === undefined ? {} : { permission: options.permission }),
                ...(options?.preset === undefined ? {} : { preset: options.preset }),
                attachmentCapabilities: {
                  files: attachmentStore !== undefined && attachmentStore.saveFile !== AttachmentStore.prototype.saveFile,
                  images: imageCapabilityByRoute.get(routeKey) === true,
                },
                availableActions: availableActionsFor(target),
              })
            }
            rendererSnapshotPush = () => {
              const target = agent ?? liveAgent
              const snapshot = snapshotFor()
              send('session-snapshot', { ...snapshot, events: [...snapshot.events] })
              void refreshImageCapability(target)
              void pushSessionList()
              void pushWorkspaceFiles()
              void refreshSkillCommands()
              pushSessionCatalogs(target)
            }
            const current = agent ?? liveAgent
            pushSessionCatalogs(current)
            void refreshImageCapability(current)
            setTimeout(() => { void pushSessionList() }, 300)
            setTimeout(() => { void pushWorkspaceFiles() }, 300)
          },
          notice: (text, level) => appendNotice(text, level),
          subscribe: emit => {
            const offs: Array<() => void> = []
            offs.push(ctx.on('agent/status', (payload: { agent: Agent; status: string }) => {
              void pushSessionList()
              if (payload.agent.id !== (agent ?? liveAgent).id) return
              notifyTurnState(payload.agent)
              updateStatusValues()
            }))
            offs.push(ctx.on('approval/request', async (request, next) => {
              const owner = request.agent
              const root = agent ?? liveAgent
              if (ctx.agents.get(owner.session.id) !== owner || (owner !== root && !ctx.agents.isOwnedBy(owner.session.id, root))) return next()
              if (mountResult === undefined || !mountResult.supports('approval-request') || !mountResult.supports('approval-answer')) return next()
              const answer = mountResult.approve({
                sessionId: String(root.session.id),
                ownerSessionId: String(owner.session.id),
                toolName: request.toolName,
                ...(request.callId === undefined ? {} : { callId: String(request.callId) }),
                ...(request.reason === undefined ? {} : { reason: request.reason }),
              }, request.signal)
              return answer
            }))
            offs.push(ctx.on('user-questions/request', async (request, next) => {
              const owner = request.agent
              const root = agent ?? liveAgent
              if (owner === undefined || ctx.agents.get(owner.session.id) !== owner || (owner !== root && !ctx.agents.isOwnedBy(owner.session.id, root))) return next()
              if (mountResult === undefined || !mountResult.supports('question-request') || !mountResult.supports('question-answer') || !mountResult.supports('question-timeout')) return next()
              const requestId = `q${++questionRequestSequence}-${String(owner.session.id)}`
              let remainingMs: number | undefined
              let claimController: AbortController | undefined
              let claimPending: Promise<IteratorResult<{ remainingMs: number }>> | undefined
              const abortClaim = (): void => claimController?.abort(request.signal?.reason)
              const questions = request.questions.map(question => ({
                id: question.id,
                question: question.question,
                ...(question.header === undefined ? {} : { header: question.header }),
                ...(question.detail === undefined ? {} : { detail: question.detail }),
                ...(question.multiSelect === undefined ? {} : { multiSelect: question.multiSelect }),
                ...(question.intent === undefined ? {} : { intent: question.intent }),
                ...(question.options === undefined ? {} : { options: question.options.map(option => ({ label: option.label, ...(option.description === undefined ? {} : { description: option.description }) })) }),
              }))
              const continueQuestion = async (): Promise<void> => {
                const callId = request.wait?.callId
                if (callId === undefined) return
                const lifetime = new AbortController()
                continuedQuestionControllers.add(lifetime)
                try {
                  if (!await waitForContinuedQuestion(owner, callId, lifetime.signal)) return
                  const lateRequest = `q${++questionRequestSequence}-${String(owner.session.id)}-continued`
                  const lateAnswers = await mountResult.askQuestion({
                    request: lateRequest,
                    sessionId: String(root.session.id),
                    ownerSessionId: String(owner.session.id),
                    state: 'continued',
                    callId: String(callId),
                    questions,
                  }, lifetime.signal)
                  if (lateAnswers === undefined) return
                  const accepted = ctx.userQuestions.answer(root, callId, {
                    answers: lateAnswers.map(answer => ({ id: answer.id, selected: [...answer.selected], ...(answer.custom === undefined ? {} : { custom: answer.custom }) })),
                  })
                  if (!accepted) appendNotice(`Late answer for question ${String(callId)} was no longer pending.`, 'warning')
                } finally {
                  continuedQuestionControllers.delete(lifetime)
                }
              }
              const isTimedOut = (): boolean => request.signal?.aborted === true
                && request.signal.reason instanceof UserQuestionError
                && request.signal.reason.code === 'ASK_TIMED_OUT'
              try {
                if (request.wait?.timed === true && request.wait.callId !== undefined) {
                  claimController = new AbortController()
                  request.signal?.addEventListener('abort', abortClaim, { once: true })
                  const claimIterator = ctx.userQuestions.attachWait(owner, request.wait.callId, claimController.signal)[Symbol.asyncIterator]()
                  const claim = await claimIterator.next()
                  if (claim.done) {
                    if (request.signal?.aborted) throw request.signal.reason
                    return next()
                  }
                  remainingMs = claim.value.remainingMs
                  claimPending = claimIterator.next()
                }
                const answers = await mountResult.askQuestion({
                  request: requestId,
                  sessionId: String(root.session.id),
                  ownerSessionId: String(owner.session.id),
                  state: 'open',
                  ...(request.wait?.callId === undefined ? {} : { callId: String(request.wait.callId) }),
                  ...(remainingMs === undefined ? {} : { remainingMs }),
                  questions,
                }, request.signal)
                if (answers === undefined && mountResult.questionTimedOut(requestId)) {
                  claimController?.abort()
                  await claimPending?.catch(() => undefined)
                  if (isTimedOut()) {
                    const task = continueQuestion()
                      .catch(error => appendNotice(`Could not continue timed question: ${errorChain(error)}`, 'error'))
                      .finally(() => continuedQuestionTasks.delete(task))
                    continuedQuestionTasks.add(task)
                    throw request.signal!.reason
                  }
                }
                if (request.signal?.aborted) throw request.signal.reason
                if (answers === undefined) throw new UserQuestionError('The user cancelled the question', 'ASK_ABORTED')
                return { answers: answers.map(answer => ({ id: answer.id, selected: [...answer.selected], ...(answer.custom === undefined ? {} : { custom: answer.custom }) })) }
              } finally {
                request.signal?.removeEventListener('abort', abortClaim)
                claimController?.abort()
                await claimPending?.catch(() => undefined)
              }
            }))
            offs.push(ctx.on('session/event', (session: Session, event: SessionEvent) => {
              // The foreground agent moves on `/new`, `/resume`, and the rail's switch;
              // binding the subscription to the mount-time agent filtered every event of
              // the new session out and left the old transcript on screen.
              if (agent === undefined || session.id !== agent.session.id) return
              const sourceSessionId = String(session.id)
              hostEventEffects(sourceSessionId, event, true)
              const rows = transcriptEvents([event], transcriptFold)
              if (event.type === 'turn/end' && streamRow !== undefined) {
                // An interrupted, aborted, or failed turn may never deliver the stream's
                // `end` frame or the durable assistant message. Settle the drafted row here,
                // so the renderer drops its streaming state instead of leaving a spinner on a
                // turn that is already over.
                const streamed = streamRow
                streamRow = undefined
                // The turn's footer belongs to exactly one row. If the fold already handed
                // back that row (the step wrote a durable message), the drafted one settles
                // bare; if not, this row *is* the end of the turn and takes the footer — and
                // the interruption mark — itself.
                const closed = rows.some(row => row.footer === true)
                const kind = event.data.reason.kind
                const interrupted = kind === 'aborted' || kind === 'interrupted' || kind === 'error'
                emit(sourceSessionId, [{
                  id: streamed.id,
                  role: 'assistant',
                  text: streamed.text,
                  createdAt: streamed.createdAt,
                  ...(streamed.bodyAt === undefined ? {} : { bodyAt: streamed.bodyAt }),
                  ...(streamed.reasoning === '' ? {} : { reasoning: streamed.reasoning }),
                  ...(streamed.reasoningDone === true ? { reasoningDone: true } : {}),
                  streaming: false,
                  ...(closed ? {} : { footer: true, ...(interrupted ? { interrupted: true } : {}) }),
                }])
              }
              if (event.type === 'assistant/message') {
                // The completed row replaces the streaming one instead of being appended
                // beside it: the stream drafted under `s<agentId>` and the durable log
                // numbers the message `a<seq>`, so a plain append left a dead half-answer
                // on screen above the real one. Re-keying the final row inherits the id the
                // renderer already painted, so the frame updates in place. The id is changed
                // on the row *object*: the fold state keeps that row as the turn's last, and
                // the `turn/end` update has to address the same id.
                const streamed = streamRow
                streamRow = undefined
                if (streamed !== undefined) {
                  const row = rows.find(candidate => candidate.role === 'assistant')
                  if (row !== undefined) {
                    const mutable = row as { id: string; bodyAt?: number }
                    mutable.id = streamed.id
                    if (streamed.bodyAt !== undefined) mutable.bodyAt = streamed.bodyAt
                  }
                }
              }
              if (rows.length > 0) emit(sourceSessionId, rows)
            }))
            offs.push(ctx.on('agent/assistant-stream', (payload: { agent: Agent; frame: AssistantStreamFrame }) => {
              if (agent === undefined || payload.agent.id !== agent.id) return
              const frame = payload.frame
              if (frame.type === 'start') {
                streamRow = undefined
                return
              }
              if (frame.type === 'chunk') {
                const chunk = frame.chunk
                if (chunk.type === 'text-delta') {
                  const now = Date.now()
                  streamRow = appendAssistantTextDelta(
                    streamRow,
                    `s${payload.agent.session.id}-${++streamSequence}`,
                    chunk.text,
                    now,
                  )
                  // The first answer delta closes the thought: the renderer turns its
                  // `Thinking` spinner into the `Thought` header, which upstream keys off the
                  // reasoning part's completion rather than the whole step's.
                  emit(String(payload.agent.session.id), [{
                    id: streamRow.id,
                    role: 'assistant',
                    text: streamRow.text,
                    createdAt: streamRow.createdAt,
                    ...(streamRow.bodyAt === undefined ? {} : { bodyAt: streamRow.bodyAt }),
                    streaming: true,
                    ...(streamRow.reasoningDone === true ? { reasoningDone: true } : {}),
                    ...(streamRow.reasoning === '' ? {} : { reasoning: streamRow.reasoning }),
                  }])
                } else if (chunk.type === 'reasoning-delta') {
                  // Reasoning streams unconditionally: whether it is painted open, folded,
                  // or hidden is the renderer's `session.thinking`, not a transport cap.
                  streamRow = streamRow === undefined
                    ? { id: `s${payload.agent.session.id}-${++streamSequence}`, text: '', reasoning: chunk.text, createdAt: Date.now() }
                    : { ...streamRow, reasoning: streamRow.reasoning + chunk.text }
                  emit(String(payload.agent.session.id), [{
                    id: streamRow.id,
                    role: 'assistant',
                    text: streamRow.text,
                    createdAt: streamRow.createdAt,
                    ...(streamRow.bodyAt === undefined ? {} : { bodyAt: streamRow.bodyAt }),
                    reasoning: streamRow.reasoning,
                    streaming: true,
                  }])
                }
              } else if (frame.type === 'end' && streamRow !== undefined) {
                emit(String(payload.agent.session.id), [{
                  id: streamRow.id,
                  role: 'assistant',
                  text: streamRow.text,
                  createdAt: streamRow.createdAt,
                  ...(streamRow.bodyAt === undefined ? {} : { bodyAt: streamRow.bodyAt }),
                  ...(streamRow.reasoning === '' ? {} : { reasoning: streamRow.reasoning }),
                  ...(streamRow.reasoningDone === true ? { reasoningDone: true } : {}),
                  streaming: false,
                }])
              }
            }))
            return () => { for (const off of offs) off() }
          },
        })
        rendererMount = mountResult
        // Terminal setup dynamically loads and mounts a plugin. It must not delay the first
        // frame; when it settles, publish the newly available terminal actions route-only.
        void ensureTerminalController().then(() => {
          rendererSelectionPush?.()
        }).catch((error: unknown) => {
          terminalController = undefined
          appendNotice(`Interactive terminal unavailable: ${errorChain(error)}`, 'warning')
        })
        // The buffered notices ride the mount's send seam, which replays them in order.
        for (const notice of drainBootNotices()) pendingNotices.push(notice)
        for (const notice of pendingNotices.splice(0)) rendererMount?.handle.send('boot-notice', { text: notice.text, kind: notice.kind })
        setTimeout(() => { void refreshSkillCommands() }, 300)
        if (daemonMode && daemonBridge !== undefined) {
          daemonGone.handle = () => mountResult?.drop()
          try {
            const daemonServer = await startDaemonServer({
              bridge: daemonBridge,
              onShutdown: () => ctx.appExit?.(0),
            })
            ctx.effect(() => () => daemonServer.close())
          } catch (error: unknown) {
            appendNotice(`dpsk daemon: ${errorChain(error)}`, 'error')
            ctx.appExit?.(1)
          }
        }
        if (mountResult === undefined) {
          appendNotice('dpsk: renderer artifact missing. Run `dpsk update`.', 'error')
          ctx.appExit?.(1)
        }
        return

    }

    const startMount = (target: Agent): void => {
      void mount(target).catch((error: unknown) => {
        rendererMount?.stop()
        appendNotice(`tui: renderer startup failed: ${errorChain(error)}`, 'error')
        ctx.appExit?.(1)
      })
    }
    const readyAgent = ctx.agents.get(sessionId)
    if (readyAgent !== undefined) {
      startMount(readyAgent)
    } else {
      const offCreated = ctx.on('agent/created', ({ agent: candidate }) => {
        if (candidate.id === sessionId) {
          offCreated()
          startMount(candidate)
        }
      })
      const timeout = setTimeout(() => {
        if (mounted) return
        offCreated()
        appendNotice(`tui: session "${sessionId}" never became live (timed out).`, 'error')
        ctx.appExit?.(1)
      }, AGENT_READY_TIMEOUT_MS)
      ctx.effect(() => () => {
        clearTimeout(timeout)
      })
    }

    ctx.effect(() => async () => {
      rendererMount?.stop()
      setTuiForegroundControl(undefined)
      detachCommandFileReceiptResolver()
      commandFileReceipts.clear()
      offModelSelection?.()
      for (const controller of continuedQuestionControllers) controller.abort()
      const continuedQuestionResults = await Promise.allSettled([...continuedQuestionTasks])
      continuedQuestionControllers.clear()
      continuedQuestionTasks.clear()
      for (const follower of terminalFollowers.values()) follower.abort.abort()
      for (const hold of terminalRetains.values()) hold.abort.abort()
      const followerResults = await Promise.allSettled([
        ...[...terminalFollowers.values()].flatMap(follower => follower.task === undefined ? [] : [follower.task]),
        ...[...terminalRetains.values()].flatMap(hold => hold.task === undefined ? [] : [hold.task]),
      ])
      terminalFollowers.clear()
      terminalRetains.clear()
      const closedTerminals: Promise<unknown>[] = []
      for (const owned of ownedTerminals.values()) {
        const owner = ctx.agents.get(SessionId(owned.sessionId))
        if (owner === undefined || terminalController === undefined) continue
        closedTerminals.push(terminalController.close(owner, owned.id as WebTerminalId).catch(() => undefined))
      }
      ownedTerminals.clear()
      const closeResults = await Promise.allSettled(closedTerminals)
      const controllerResult = terminalSetupFiber === undefined ? [] : await Promise.allSettled([terminalSetupFiber.dispose()])
      detachJobController?.()
      const handleResults = await Promise.allSettled([...ownedHandles.values()].map(handle => handle.dispose()))
      ownedHandles.clear()
      const errors = [...continuedQuestionResults, ...followerResults, ...closeResults, ...controllerResult, ...handleResults].flatMap(result => result.status === 'rejected' ? [result.reason] : [])
      if (errors.length > 0) throw new AggregateError(errors, 'Could not dispose all TUI-owned resources')
    })
  }
}

export { SessionId }
export default Tui
