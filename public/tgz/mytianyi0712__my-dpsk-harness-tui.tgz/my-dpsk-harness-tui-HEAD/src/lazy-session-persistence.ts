/**
 * Conversation-gated session persistence.
 *
 * dsh's storage contract materializes a session on the first durability barrier,
 * including an otherwise blank created session. The TUI mounts an agent at startup so
 * `/new`, resume, and the first prompt share one lifecycle, but that means a bare launch
 * leaves a setup-only session behind. This decorator keeps `create()` and setup appends
 * in memory until the first conversation event, at which point the real backend session
 * is created and the buffered setup events are replayed ahead of that event. A handle
 * that never sees a conversation event drops its buffer on flush/close and never calls
 * the backend at all.
 */

import { Service, SessionLogOffset, type Context, type SessionEvent, type SessionHandle, type SessionHandleAppendOptions, type SessionHandleFlushOptions, type SessionHandleReadOptions, type SessionHandleReadResult, type SessionHeader, type SessionPersistence, type SessionPersistenceCreateOptions } from './dsh-host/index.ts'
import { hasConversationEvent } from './session-label.ts'

type CreateReal = () => Promise<SessionHandle>

/** The one per-session write handle returned by the decorated `create`. */
export class ConversationGatedHandle implements SessionHandle {
  readonly id
  readonly header: SessionHeader
  readonly inheritedEventCount
  readonly access = 'write' as const

  private real: SessionHandle | undefined
  private readonly buffered: SessionEvent[] = []
  private closed = false
  private chain: Promise<unknown> = Promise.resolve()

  constructor(
    header: SessionHeader,
    inheritedEventCount: number,
    private readonly createReal: CreateReal,
  ) {
    this.id = header.id
    this.header = header
    this.inheritedEventCount = SessionLogOffset(inheritedEventCount)
  }

  /** Serialize mutations so a later append cannot overtake materialization. */
  private enqueue<T>(task: () => Promise<T>): Promise<T> {
    const next = this.chain.then(task, task)
    this.chain = next.catch(() => undefined)
    return next
  }

  private async materialize(): Promise<void> {
    if (this.real !== undefined) return
    const real = await this.createReal()
    const pending = this.buffered.splice(0, this.buffered.length)
    if (pending.length > 0) await real.append(pending)
    this.real = real
  }

  async read(offset = 0, length?: number, _options?: SessionHandleReadOptions): Promise<SessionHandleReadResult> {
    return this.enqueue(async () => {
      if (this.real !== undefined) return this.real.read(offset, length, _options)
      const end = length === undefined ? undefined : offset + length
      return { eventState: 'detached', events: this.buffered.slice(offset, end) }
    })
  }

  async append(events: readonly SessionEvent[], options?: SessionHandleAppendOptions): Promise<void> {
    return this.enqueue(async () => {
      if (this.closed) throw new Error(`session "${String(this.id)}": append on a closed handle`)
      if (this.real !== undefined) {
        await this.real.append(events, options)
        return
      }
      this.buffered.push(...events)
      if (this.buffered.some(hasConversationEvent)) await this.materialize()
    })
  }

  async flush(options?: SessionHandleFlushOptions): Promise<void> {
    return this.enqueue(async () => {
      if (this.real !== undefined) {
        await this.real.flush(options)
        return
      }
      // A setup-only session is deliberately not durable. If it already carries a
      // conversation event, materialize first (this path should normally be append-driven).
      if (this.buffered.some(hasConversationEvent)) {
        await this.materialize()
        await this.real!.flush(options)
      }
    })
  }

  async close(): Promise<void> {
    return this.enqueue(async () => {
      if (this.closed) return
      this.closed = true
      if (this.real !== undefined) await this.real.close()
      this.buffered.length = 0
    })
  }

  async [Symbol.asyncDispose](): Promise<void> {
    await this.close()
  }
}

/**
 * Replace one persistence instance's `create` with the gated version. Kept as a pure
 * function so tests can use a fake backend and the service lifecycle can restore the
 * original method.
 */
export function installConversationGatedCreate(persistence: SessionPersistence): () => void {
  const original = persistence.create
  const boundOriginal = original.bind(persistence)
  const patched = (header: SessionHeader, options?: SessionPersistenceCreateOptions): Promise<SessionHandle> => {
    const inherited = options?.inheritedEventCount ?? 0
    return Promise.resolve(new ConversationGatedHandle(header, inherited, () => boundOriginal(header, options)))
  }
  persistence.create = patched
  return () => {
    if (persistence.create === patched) persistence.create = original
  }
}

export class LazySessionPersistence extends Service {
  static inject = ['sessionPersistence']

  constructor(ctx: Context) {
    super(ctx, 'lazySessionPersistence')
    const restore = installConversationGatedCreate(ctx.sessionPersistence)
    ctx.effect(() => restore)
  }
}

export default LazySessionPersistence

