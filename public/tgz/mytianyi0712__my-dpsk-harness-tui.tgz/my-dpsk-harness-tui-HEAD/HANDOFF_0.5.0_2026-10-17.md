# dsh 0.5.0 交接说明（2026-10-17 归档，S1–S9 全部走完）

> **归档说明（2026-10-20）**：本文保留 S1–S9 的历史状态，**不再代表当前实现**。之后的收尾批次
> 已完成：渲染器成为默认路径、宿主终端 UI 基座退出、opencode v2 布局（Home / tabs / sidebar /
> pane / toast / spinner / markdown / prompt footer）落地、`cli.json` 导入与存储锁缺陷修复、
> CI 与产物清单对齐。当前状态与逐项说明见 `CHANGELOG.md` 的 0.5.0「交付收尾」一节与 README。
> 文中“渲染器 opt-in / pi-tui 默认 / 292 tests”等描述均属归档时点。

本文用于交接 0.5.0 的后续开发。逐批明细与发现记录在阶段待办
`C:\Users\mytianyi\.opencode\plan\dsh-0.5.0-todo.md`（不随仓库分发）；方案文件
`C:\Users\mytianyi\.opencode\plan\dsh-0.5.0-opencode-v2-tui-refactor.md`（12 节全文）。
本文只写**状态、决定与限制**，不写计划。

---

## 1. 目标与范围（0.5.0）

把 dsh TUI 插件重构到 opencode v2 的 TUI 风格，并把渲染底座从 `@earendil-works/pi-tui`
迁到 OpenTUI sidecar，同时完成许可合规与包改名。

| 项 | 值 |
|---|---|
| 版本 | `0.5.0` |
| 包名 | `dsh-omp-tui` → **`my-dpsk-harness-tui`** |
| 启动器 bin | `omdsh` → **`dpsk`** |
| 许可 | **BSD-3-Clause**（不改 MIT）；派生代码逐文件署名 |
| 主题 | opencode v2 token 模型（hue 色阶 + 语义 token + `@dialog`），98 个 OMP 主题重定义为 token 文档 |
| 渲染器 | Bun sidecar + OpenTUI（`@opentui/core` + `@opentui/solid`），宿主 ↔ 渲染器走 NDJSON IPC（fd 3） |
| 分发 | `bun build --compile` 单文件可执行 7 平台矩阵；用户无需安装 Bun |

**为什么是 sidecar**：OpenTUI 需要 Bun ≥1.3.14 或 Node ≥26.4 + `--experimental-ffi`；
dsh 跑在 Node `^22.19.0 || >=24.0.0`（开发机 Node 24.19.0 / Bun 1.4.2），进程内 OpenTUI 不可行。
渲染器因此作为持有 TTY 的子进程，宿主 stdio 改道到 `$DSH_HOME/logs/tui-<pid>.log`。

**渲染器路径是 opt-in**：环境变量 `DSH_RENDERER=1|true` 才走 sidecar，pi-tui TUI 保持默认。

**S8 决定（偏离计划，已由用户确认）**：计划 D1 写「pi-tui 与 vendored patch 全部退出」。
执行到 S8 时渲染器已有大量覆盖但仍有缺口，移除基座会让 0.5.0 的默认路径变成这些功能不可用的
渲染器，属于功能倒退。**已向用户提问，用户选择「保留 pi-tui，先补功能对齐（推荐）」**——
0.5.0 以渲染器 opt-in 发布，基座彻底退出与「渲染器设为默认」排在渲染器功能对齐之后。
CHANGELOG 与 README 已按此事实写明。

---

## 2. 阶段与提交（43 个 commit 未推送）

| 阶段 | 内容 | commit |
|---|---|---|
| S1 | 许可合规基线（NOTICE 登记表 + 六条规则门禁 + 逐文件署名） | `ee04195` |
| S2 | 改名 + `dpsk` 启动器 + settings 命名空间迁移 | `5bd7167` |
| S3 | IPC 协议层（信封 / kind 表 / 协商 / transport / fixtures / 门禁） | `371e875` |
| S4 | 渲染器脚手架 + 终端交接（Bun + OpenTUI sidecar，7 平台构建） | `ae854eb` |
| S5 | 渲染 shell + token 主题引擎 + keymap + 命令面板 | `174eb5f` |
| S5 收尾 | opencode 对话框/键位参考源登记为 vendored 资产；对话框基座 + 窄终端断点 | `2df67db` `17773b4` |
| S6 第一步 | composer 历史、插话队列、会话轨、模型/思考强度/权限/预设写回 | `2225316` |
| S6 第二步 | `@` 路径补全（Bun `node:fs`，宿主只发 `workspace`） | `f587adb` |
| S7 第一批 | theme-migrate、token 覆盖合并、settings 页、`cli.json` 导入 | `bc7cf1d` |
| S7 第二批 | 微信桥 UI、`/doctor` `/plugins`、Enter 真实提交与布局修复 | `041edfe` |
| S7 第三批 | i18n 走 IPC、纵向布局修复 | `73587dc`（`0c5036a` 是 gitignore） |
| S8 第一批 | 产物清单、启动器下载/校验、`check` 扩展、CI/release、文档 | `7edeb4e` |
| S8 第二批 | 供应商表单走 IPC（`form-spec`/`form-submit`）+ prompt Enter 修复 | `202d83d`（`e46be31` 是单独修复） |
| S8 第三批 | user questions 走 IPC + **prompt Enter 修复的回退** | `61ad7d4` |
| S8 第四批 | 自定义模型表单 + 技能命令目录抵达渲染器（重发 `command-catalog`） | `943be64` |
| S8 第五批 | status line 细节（provider/model · effort · permission · preset） | `19d128a` |
| S8 第六批 | 子代理面板走 IPC（`subagent-list`） | `36f311a`（`984449e` 是 snapshot permission 修复） |
| S8 第七批 | 逐模型字段走扁平行 | `b82b2c3` |
| S8 第八批 | prompt 模板进 settings 页 | `e3368b0` |
| S8 第九批 | skills 面板走 IPC（`skills-list`，面板 skills 分类） | `08f9219` |
| S8 第十批 | 快捷键行进 settings 页（`keyTools` / `keyReasoning` 写回，渲染器 keymap 不读） | `599fc9e` |
| S8 第十一批 | 模型发现探测走 IPC（`model-discover` / `model-discovery`，`FormFieldSpec` 加 `action`） | `9edaa8c` |
| S8 第十二批 | agent-loop 设置行走 IPC（`maxParallelToolCalls`，`update-settings` 加 `ns`） | `cbb260e` |
| S8 第十三批 | 逐模型嵌套编辑器走 IPC（`model-list` / `model-list-request` / `model-edit`，扁行编解码与表单提交共用，合并经 `model-discovery` 落回） | `557e983` |
| S8 第十三批修复 | **渲染器写 stderr 关闭自己的 IPC 通道**（根因 + 单分发器 + stderr 改道通知 + 宿主容忍通道关闭 + disconnect 补 kill 与终端恢复） | `2ecd6bf` |
| S8 第十三批修复续 | 宿主按启动器的产物名查缓存的渲染器（`rendererArtifactName`，缓存与 dev 查找共用；`rendererCacheDir`/`resolveRendererPath` 加可选 `home`） | `5735325` |
| S8 第十三批修复续 | **TDZ：渲染器 hello 在激活体的 `await` 挂起点到达**（模型路由、选择引用、handles 写回、命令注册表移到渲染器挂载之前，块内补 `refreshSkillCommands`） | `3485c58`（`0200e33` 是文档） |
| S9 安装修复 | **旧包遮蔽新包**（`dsh-omp-tui` 与新包注册同一个 `tui` 服务；从 profile 的 `dsh.profile.bundles` 与依赖表摘掉，启动/`check`/`update` 三条路径自愈 + `tests/launcher.spec.ts`） | `60ab5e4` |
| S9 安装修复 | 系统安装文档（全局安装生成 `dpsk` 命令、旧包摘除后的验证三步、junction 删链接的安全做法） | `fac82b3` |
| S9 安装修复续 | **`dpsk --renderer` 开关**（渲染器 opt-in 的命令行入口；`consumeRendererFlag` 透传前吃掉开关 + 3 条测试） | `551baf4` |
| S9 | **系统安装完成**：全局 `dpsk` 命令可用、profile 只剩 `my-dpsk-harness-tui`、渲染器缓存命中，`dpsk` 冒烟 alt-screen + CJK + 状态行全绿、stderr 空 | — |

**remote `origin` = `https://github.com/mytianyi0712/dsh-tui-plugin-OhMyPi.git`，全部未 push（43 个
commit，含本交接文档的 docs commit）。** 按约定：开发过程不 push；S9 打包安装后由用户实测功能，再由用户 push。
改名后的 GitHub 仓库改名与 `npm deprecate dsh-omp-tui` 步骤写在 `docs/PUBLISHING.md`，**尚未执行**。

---

## 3. 当前验收状态

```
npm run check
  verify:boundary      ok (public adapter in src/dsh-adapter, host shell in src/dsh-host, OpenTUI confined to renderer/)
  verify:contract      ok
  verify:patch-surface ok (7 overrides, 94 inserts — patch 基座在 0.5.0 保留，见 §1 决定)
  verify:plugin-spec   ok (manifest my-dpsk-harness-tui@0.5.0, negotiation compatible_degraded, 9 contracts advertised)
  verify:ipc-protocol  ok (protocol v1, 28 downstream kinds, 16 upstream kinds, 3 fixtures)
  verify:license       ok (7 upstream entries, vendored 逐文件 SHA-256, 扫描 src/scripts/renderer)
  typecheck            ok (宿主)
  tests 289 / pass 288 / fail 0 / skipped 1

npm run test:renderer    → 89 pass / 0 fail（7 文件）
npm run build:renderer   → 7 平台产物（74–99 MB，合计 ~634 MB，gitignored）
```

**最后一次的真实状态（如实）**：`npm run check` 与 `test:renderer` 在 S8 第十三批代码上全绿；
win32-x64 产物重建后真实产物端到端断言全真（连续两次运行 0 项落空、退出码 0）；
**7 平台产物与 `SHA256SUMS.json` 已为第十三批重生成**。

**系统安装状态（S9 复核）**：`dpsk` 已是 PATH 上的真实命令（`npm install -g ./<tgz>` 生成
`dpsk`/`dpsk.cmd`/`dpsk.ps1`，旧的 `omdsh` shim 已删）；tui profile 的 `dsh.profile.bundles`
只剩 `@deepseek-ai/dsh-base` 与 `my-dpsk-harness-tui`（旧包 `dsh-omp-tui` 已摘除，目录让位
重命名保留）；`dpsk check` 报告全局与 profile 源包哈希一致、渲染器 本地/清单 均为
`c43e73c66d65`；`dpsk` 实机冒烟（隐藏窗口、重定向管道、10 秒后 `taskkill /T /F`）无新 fatal
日志，stdout 剥 ANSI 后含 `dpsk host: my-dpsk-harness-tui 0.5.0`、`会话列表:`、CJK 标签与
`compatible · cliproxy` 状态行，stderr 为 0 字节。

实机端到端复验（真实编译产物 win32-x64，`tmp/check-frame.ts`，时间线 1200–8500ms，
快照时点 1700/2600/3800/3900/4300/4800/6000/7100/7700/8500）全部为真：

- 握手 `compatible` → 上报 `terminal-scheme: dark` → 进入 alt-screen `[?1049h` → theme-doc 配色
- slash 补全行（`/pe` → `pick a permission preset`）、mention 补全（`@tmp/check-fr` → `@tmp/check-frame.ts`）
- doctor alert（`contract probe: ok`）、生成中指示、命令面板与行、面板 skills 行（`skill dsh-review`）
- provider form（标题 / `cliproxy` / `< openai-completions >`）、`[ Discover upstream models ]` 与
  `[ Edit models ]` 两行
- 发现探测：Enter 在 action 行发 `model-discover`（表单保持打开），宿主答 `model-discovery` 后合并行
  落进 models 字段（`discovery merge painted`），`up` 回到 models 字段键入 `x` → 尾部 `4096x` 在窗口内
- **逐模型嵌套编辑器**：`down` + Enter 在 `Edit models` 行发 `model-list-request`（表单保持打开），
  宿主答的清单选择框画 `gpt (GPT)`（`model list painted`）；`down` + Enter 选中发 `model-edit`，宿主答
  六字段表单，标题 `models · gpt` 与字段值 `GPT` 在屏（`model form painted`）；`down down` 到 max 字段
  键入 `x`、Enter 提交 → 合并行尾 `4096x` 落回 models 字段（`model edit merged back`），
  `models line complete in form-submit` 断合并后的行在 provider 表单的提交载荷里
- question prompt（`notes` + `ok` 在屏）、`question-answer` 载荷 `{a:[fast], b:[], custom:"ok"}`
- settings 行、`key tools:` 行、`max parallel tool calls:` 行（agent-loop 命名空间，写回带 `ns`）、
  status 路由行、子代理行、会话轨、微信二维码与状态行、IPC 标签
- `send-message` ×2（`interject: true`）、`doctor-check` ×1、`model-discover` ×1、
  `model-list-request` ×1、`model-edit` ×1、`form-submit` ×2
- `bye` → `code 0` / `abnormal false` / stdout 含恢复序列 `[?1049l`

---

## 4. 工作目录与命令

| 用途 | 位置 / 命令 |
|---|---|
| 仓库 | `D:\Projects\dsh` |
| 门禁 | `npm run check`（boundary / contract / patch-surface / plugin-spec / ipc-protocol / license / typecheck / test） |
| 宿主测试 | `node --test --experimental-transform-types "tests/*.spec.ts"` |
| 渲染器测试 | `npm run test:renderer`（= `cd renderer && bun test --preload @opentui/solid/preload`，**preload 必须**） |
| 渲染器构建 | `npm run build:renderer`（= `cd renderer && bun build.ts`，7 平台）；单平台 `bun build.ts win32-x64` |
| 产物清单 | `npm run generate:sums` → `SHA256SUMS.json`（gitignored，随包分发，CI 在 pack 前生成） |
| patch 快照重生成 | `node scripts/verify-patch-surface.ts --snapshot` |
| 主题生成器 | `node scripts/generate-token-themes.mjs` → `src/token-theme-data.ts`（勿手改） |
| 打包 | `npm run prepare && npm pack` → `my-dpsk-harness-tui-0.5.0.tgz`（129 files） |
| 安装到系统 | `dsh plugin --profile tui add ./my-dpsk-harness-tui-0.5.0.tgz`（本机 dsh `0.2.0-rc.2`） |
| 启动器自检 | `node <profile>\scripts\dpsk.js check`（幂等：源包哈希 + 渲染器哈希） |
| 临时验收脚本 | `tmp/`（gitignored）：`check-frame.ts`（真实产物网格断言）等 |

`bun` 在开发机是 npm shim（`bun.ps1`/`bun.cmd`）；`Node.spawn('bun')` 会 ENOENT，
真实 `bun.exe` 在 `node_modules/bun/bin/bun.exe`。分发必须走编译产物。

---

## 5. 关键设计决策（改代码前必读）

1. **token 解析在渲染器侧**。宿主发原始主题文档，渲染器把 `$ref` 扁平化成
   `token path → color`。`tokenColor(theme, path)` 按**完整 token 路径**查。
2. **握手门**。宿主在 `hello-ack` 之前不发任何东西；早于 ack 的 send 进 `pending` 队列，
   ack 后按序 flush。渲染器只有拿到 `compatible` / `compatible_degraded` 才创建 `createCliRenderer`。
3. **渲染器是私有 workspace 包，不能 import `src/`**。`renderer/src/protocol/kinds.ts` 是
   `src/ipc/kinds.ts` 的**镜像**（含 payload 接口镜像：`FormFieldSpec` / `QuestionSpec` /
   `SubagentDescriptor` / `SkillSpec`），门禁比对 kind 表（不比对 payload），镜像手工保持同步。
4. **迁移同步、写回异步**。settings 命名空间迁移（`tui`→`dpsk-tui`、
   `session-title-llm-tui`→`dpsk-session-title`）在构造时同步读 profile patch 层喂首屏，之后异步
   写入新命名空间，**跳过新命名空间已有值的字段**（幂等）。旧命名空间一个 release 内只读兼容。
5. **`/undo` `/redo` 不提供**。dsh harness 没有 git 快照层，文档写明"不提供"，**不接假实现**。
6. **tree-sitter 语法高亮推迟到 0.6.0**，`syntax.*` token 按设计缺席。
7. **LICENSE 的版权行保持原样**；历史文档不重写。
8. **capabilities（特性）与 kinds（消息类型）是两套词表**，协商分开判定。
9. **斜杠命令的归属**：picker 类命令（`/settings` `/theme` `/model` `/sessions` `/help` `/doctor`
   `/plugins`）在渲染器本地拦截，其余行送宿主（`send-message`）。报告行只有一处来源
   （`doctorRows(check)` / `pluginRows(target)`），pi-tui 卡片与渲染器 alert 共用，不可能漂移。
10. **宿主拥有的表单走三段式**：`dialog-request`（渲染器请求）→ 下游 `form-spec`（宿主拥有字段清单）
    → 上游 `form-submit`（宿主负责写入）。字段类型只有 `text` / `secret` / `select`，**没有多行字段**
    （OpenTUI `textarea` 在 solid reconciler 里不映射 `value` 与 `onInput`）。逐模型字段以**扁平行**
    `id|name|level=wire;...|effort|context|max` 表达（空格分隔多模型，`;` 分隔 efforts 对，非推理模型
    写 `none`）。嵌套的逐模型编辑器 UI 与上游发现探测（`ctx.llm.discoverModels`）**不在渲染器**。
11. **user questions 走 IPC**：`mountRenderer` 返回 `ask(questions)`，宿主调用它发下
    `question-request`（id 由 mount 自己的计数器生成），promise 在 `question-answer` 带同一 id 时解析。
    `askLocally` 是两条渲染路径共用的入口（渲染器已挂载走 `rendererMount.ask`，否则走 pi-tui inline）；
    微信桥的 `askWithFallback` 把这条本地路径与 peer 回复赛跑。渲染器逐题提问，答完最后一题才发。
12. **子代理与 skills 是「推送」不是「推导」**：同一份 `subagent/descriptor` 事件、同一份技能快照
    同时喂 pi-tui 面板与渲染器，两条路径不可能对「有哪些」有分歧。订阅时先发当前列表，之后每次变化
    重发，`stop` 里退订。技能命令的 `skill:` 条目随 `command-catalog` **重发**抵达渲染器（技能快照是
    异步的，在 ack 之后才落地——只在 ack 发一次会让技能在渲染器路径永不可达）。
13. **被 mount 用的 seam 函数必须在插件作用域**：渲染器 mount 的 deps 在命令处理器（`runCommand`）
    之外接线，`runCommand` 里的 `const` 对它不可见。`providerDraftFor` / `saveProvider` /
    `providerSettingsTarget` / `providerDiscoveryNamespace` / `credentialReference` /
    `ProviderCatalogEntry` / `providerCatalog` / `modelCatalog` / `subagentList` / `skillList` 都在
    插件作用域，`runCommand` 里的填充代码靠闭包写入同一份 `let`。
14. **读侧共用**：`providerDraftFor(providerId, templateId?, templateName?)` 被 pi-tui `ProviderForm`
    与渲染器 `form-spec` 共用，两条路径不可能读出不同的 profile。写侧 `saveProvider` 不变。
15. **字符串走 IPC**：宿主随 ack 发 `i18n`（`locale` + `strings`），渲染器 store 有 `strings` /
    `locale` + `label(key, fallback)`；词典没带的键落渲染器自带的英文标签，首帧永不空白。
    `Messages` 类型强制 zh/en 键数一致。
16. **对话框的 Enter 只走 keymap 的 `dialog-submit`**（见 §9 第 6 条）；composer 必须绑 `onSubmit`
    （它不是对话框，`dialog-submit` 对它没有控制器可路由）。
17. **发现探测是宿主的，渲染器没有按钮基元**：`ctx.llm.discoverModels` + 发现命名空间查找 + 凭据规则
    都在宿主。探测是 `form-spec` 字段清单里的一行（`kind: 'action'`，画成 `[ label ]`）：Enter 在该行
    把表单当前值送上去（`model-discover`），**表单保持打开**；宿主跑探测、把发布的 id 合并进扁平行、用
    `model-discovery` 把合并后的行发回。扁平行 `id|name|level=wire;...|effort|context|max` 的编解码
    （`parseModelsLine` / `encodeModelsLine`）在插件作用域，表单提交与探测共用同一份编码，渲染器只原样
    替换值。宿主答案写进表单的**本地值**（对话框在 mount 注册写入器，与 controller 同样的
    capture-and-restore 模式），不是靠更新字段清单信号——见 §9 第 13、14 条。

---

## 6. 许可合规约定

- `NOTICE.md` 是机器可读登记表：`derived` 是路径前缀，`vendored` 是逐文件 SHA-256（漂移即失败），
  `license` 指向下方许可文本章节 id。
- `scripts/verify-license.ts` 的 6 条规则在 `npm run check` 里。rule 4：**`vendor/**` 下每个文件都必须
  被某个条目登记**。门禁只扫 `SCAN_DIRS = ['src','scripts','renderer']`（源码扩展名，markdown 不扫）。
- **导入 MIT 依赖不构成派生**；只有文件头声明派生（Derived/Ported/Adapted/Vendored/Copied from、
  Based on、移植自、迁移自）并点名已登记 slug 时才要求 `SPDX-License-Identifier:`。头部区域是前 2000
  字符；引号内的模块说明符会被剥掉再做 slug 匹配（**大小写敏感**，`OpenTUI` 不匹配 slug `opentui`）。
- **自写文件的头部不要出现上游名**：写「not derived from opencode」也会被判定为声明派生并要求 SPDX。
- 上游版本：opencode `anomalyco/opencode` MIT v2.0.30；OpenTUI `anomalyco/opentui` MIT 0.6.6；
  OMP `can1357/oh-my-pi` MIT；dsh-ecosystem-spec MIT；Tencent `openclaw-weixin` MIT；pi-tui MIT；
  turtle-ui `turtle1999/turtle-ui` BSD-3-Clause（upstream commit `b08ed69`）。
- **移植约定**：逐文件 SPDX + provenance 头，并加进对应 `derived` 列表。渲染器里自写的组件
  （`ui/dialog-fields.tsx`、`ui/completions.ts`、`ui/paths.ts`、`ui/text.ts`）不声明派生。

---

## 7. 已知卡点与环境限制

- **渲染器永不写 stderr（已修，`2ecd6bf`）**：Bun 在子进程**第一次写 fd 2（stderr）**时关闭它的
  IPC 通道（`stdio` 为 inherit 与 pipe 皆成立，编译产物与 `bun` 跑脚本皆成立）。Node 的警告
  （`MaxListenersExceededWarning`、`process.emitWarning` 的报告）走 `process.stderr.write`，所以
  `main.tsx` 把 `process.stderr.write` 换成通知块入口（store 未建时缓冲），并把 `process` 与渲染器
  事件发射器的 max listeners 设为无限（每个打开的对话框经 `useTerminalDimensions` 订阅一个 resize
  监听，嵌套流 provider 表单 → 模型清单 → 逐模型表单越过默认上限 10，那条上限打印的警告就是关闭
  通道的触发器）。渲染器代码**不得用 `console.*`**（OpenTUI 把 console 方法改写到自己的覆盖层，
  `console.error` 绕过改道），失败报告一律走 stdout。宿主侧 `childChannel.send` 包 try/catch，
  `spawnRenderer` 听 `child.on('disconnect')`（通道被渲染器关闭时 `exit` 不触发）。
- **TDZ 崩溃只在安装产物里现形（已修，`3485c58`）**：渲染器挂载后激活体 `return`，`hello` 到达时它悬在
  后面的 `await` 上，挂载的 `onAck` 读后声明的 `const` 就抛 `Cannot access ... before initialization`。
  门禁全绿掩盖它（mount 测试直接构造 mount，不走激活体）。检测办法是实机 smoke 看有没有新的 fatal 日志
  文件（见 §9 第 58 条）。渲染器路径要读的声明一律排在渲染器块之前。
- **渲染器在真实 TTY 下的完整渲染无法在本环境验证**（shell 工具 stdio 是管道）。可见帧断言只能在
  渲染器内用 `createTestRenderer` + `captureCharFrame()`；真实产物靠重建屏幕网格断言。
  **实机验收留给用户。**
- **CJK 与非 ASCII grapheme 属实机验收**：OpenTUI 把非 ASCII grapheme 存进原生 grapheme 池，单元格
  存引用 + 延续格；管道 stdout 下渲染器拿不到终端能力（OSC 66 查询无响应），CJK 标签在流里序列化为
  空格（网格实测 `会话: ` → 空格 + `:`）。`createTestRenderer` 的网格里有 CJK（测试断言通过），真实
  终端（Windows Terminal / kitty，有显式宽度能力）下的 CJK 渲染只能用户在实机看。`en` locale 在渲染器
  全通。同理 `↳` 与 `·` 在管道流里也是空格，行尾在面板宽度处被裁断。
- **系统里的安装曾经既没有 `dpsk` 命令、又被旧包遮蔽（已修，`60ab5e4`）**：全局那份是 0.4.0 时代 `npm link`
  留下的目录 junction，npm 不为改名后的 bin 重新生成 shim，PATH 上只有指向已不存在的 `scripts/omdsh.js`
  的旧 shim；profile 的 `package.json` 又还留着 `dsh-omp-tui@0.4.0`，与新包抢同一个 `tui` 服务且先加载赢下，
  新包整体 `did not activate`。现在启动器在启动/`check`/`update` 三条路径都会摘旧包，安装循环补了全局
  `npm install -g ./<tgz>`。手工删链接用 `cmd /c rmdir <链接>`（只删链接）；**递归删除会顺着 junction
  删进源码目录**。
- **`renderer install` 无法成功**：仓库未改名、无 `v0.5.0` release，启动器实测给出清晰的 404 报告并
  回退到 pi-tui。缓存命中路径离线可用（`DSH_RENDERER_PATH` 被设，无网络）。
- **渲染器 typecheck 未入门禁**：`bun x tsc -p tsconfig.json --noEmit`（在 `renderer/`）报既有的
  `bun:test` / `process` / `node:fs` / `KeyHandler.on` 错误。宿主 `npm run typecheck` 干净。
- **`/export` `/rename` 在 harness 里没有实现**（宿主只有 `/new` `/resume`），渲染器打印「暂不支持」
  是诚实的，不是缺口。
- Windows 上 Node 在 `fetch` 之后 `process.exit(1)` 会打印 libuv 断言
  `!(handle->flags & UV_HANDLE_CLOSING)`（`src\win\async.c:94`）——运行时关闭噪声，报告文本正常、
  退出码 1。
- `dpsk check` 的覆盖流程是「移除 profile 包 → `dsh plugin add` → 写源包哈希」。中途失败会留下
  **目录缺失**状态，`.bin` 里的 `dpsk` shim 指向缺失脚本 → 后续 `dpsk` 报 `MODULE_NOT_FOUND`。恢复办法
  是重跑 `dsh plugin --profile tui add <tgz>`。
- **GitHub 取源限制**：匿名 API 配额 60/小时，`raw.githubusercontent` 与 jsdelivr 在此环境不可达。
  取上游源码用 `git clone --depth 1 --filter=blob:none --sparse --single-branch --branch <tag>` +
  `git sparse-checkout set packages/tui/src/...`。
- `C:\Users\mytianyi\.dsh\profiles\tui\cordis.patch.yml` 含 API key，**绝不提交**。
- `renderer/dist` 产物 74–99 MB，不入库（gitignored）；`SHA256SUMS.json` 是生成物，进 gitignore
  同时进 `package.json` files（`npm pack` 认 files，不受 gitignore 影响）。

---

## 8. 未完成的收尾与推迟项

### 下一轮第一件事（收尾）

1. **系统安装循环（四步，缺一步就不算装好）**：
   1. `npm run prepare && npm pack` → `my-dpsk-harness-tui-0.5.0.tgz`
   2. `npm install -g ./my-dpsk-harness-tui-0.5.0.tgz` ← **这一步才生成 PATH 上的 `dpsk` 命令**；profile 级安装（`dsh plugin --profile tui add`）不产生全局 bin，漏掉它就是「`dpsk` 不是内部或外部命令」
   3. `dpsk check`（幂等）：摘掉 profile 里的旧包 `dsh-omp-tui`、用全局包覆盖 tui profile、报告当前平台渲染器哈希与随包清单比对
   4. 重建过渲染器时把 `renderer/dist/dpsk-renderer-win32-x64.exe` 复制进 `~/.dsh/dpsk/renderer/0.5.0-win32-x64/`
   验收：`dsh --profile tui --dump-config` 里不再出现 `dsh-omp-tui`；`dpsk` 启动不打印 `entries did not activate`。7 平台产物与 `SHA256SUMS.json` 已为第十三批重生成；第十三批的三个修复（stderr 通道、缓存产物名、TDZ）与 S9 的旧包摘除都已打进当前 tarball。
2. CHANGELOG 的 0.5.0 release 链接仍指向 0.4.0；`renderer install` 要能成功需要仓库改名 + 打出
   `v0.5.0` release（`docs/PUBLISHING.md` 的手工步骤）。
3. **实机 TTY 验收（只能由用户做）**：真实终端下的 CJK 标签渲染、渲染器在真实 TTY 的帧率与滚动、
   微信扫码/白名单/推送 smoke、供应商表单在真实 profile 的保存写回与发现探测。

### 推迟项（渲染器功能对齐之后）

- **移除 pi-tui 基座**：`patches/`、`verify:patch-surface`、`patch-surface.snapshot.json`、
  `@earendil-works/pi-tui` devDep、`cordis.patch.yml` 的 patch 引用、`package.json` files 中的
  `patches`、`src/components/{model-list-dialog,provider-form,custom-model-form}.ts` 的 pi-tui 依赖、
  `src/index.ts` 的 pi-tui mount 路径；`npm run check` 换新组合；并把渲染器设为默认。
- 逐模型的**嵌套编辑器**已在第十三批走 IPC（`Edit models` 行 → 模型清单选择框 → 逐模型六字段表单，
  合并进扁平行后经 `model-discovery` 落回；解析、编码、合并都在宿主）。剩下的缺口是 pi-tui 那套
  「逐行选字段、逐字段编辑」的嵌套目录形态——渲染器是「选择框 + 表单」两步，功能等价，UI 形态不同。
- **渲染器 keymap 读取 `keyTools` / `keyReasoning` 与 `cli.json` 导入的 `keybinds` 表**：写回已在第十批
  完成（值对 pi-tui 路径有效），渲染器路径的键位可配置是缺口——渲染器的 keymap 是固定的 leader 表。
  协议要新增「键位表随 settings 发下」的形状。
- 独立的 skills 页（技能行目前在面板与斜杠补全里可达）。
- 多行字段（`textarea` 在 solid reconciler 里的 `value`/`onInput` 不生效，要自己挂事件监听）。
- **渲染器 typecheck 入门禁**：`bun x tsc -p tsconfig.json --noEmit`（在 `renderer/`）报既有的
  `bun:test` / `process` / `node:fs` / `KeyHandler.on` 错误。宿主 `npm run typecheck` 干净。
- 验收：CI 矩阵全绿；tarball 解包含 LICENSE/NOTICE/lib/renderer 产物。

---

## 9. 易踩的坑（按实际踩点记录）

### 渲染器 / Solid

1. **`bun test` 不应用 `bunfig.toml` 的 preload**。没有 Solid transform 时 JSX props 是**静态**的：
   `<text content={label()}>` 只在创建时求值一次、`<For each={rows()}>` 只渲染初始数组、
   `visible={signal()}` 永不更新。表现是"UI 画得出来但永远不更新"，而测试里 store 在 render 前喂好
   数据会让帧断言全过，**掩盖缺陷**。修法：`test:renderer` 必须带 `--preload @opentui/solid/preload`。
   `bun build --compile` 走 `@opentui/solid/bun-plugin`，编译产物是反应式的。
2. **Solid 组件的返回值不是反应式的**。组件函数只运行一次，`cond ? <box/> : null` 作为返回值只求值
   一次。反应式开关写在 JSX 属性（`visible={cond()}`）或 JSX 子位置（`{cond ? <text/> : null}`）。
3. **`<Show>` 在 false 时向父节点插入空文本节点**，OpenTUI reconciler 报 `Orphan text error`。
   条件内容用三元式。
4. **`visible={store.paletteOpen}`（传 accessor 函数本身）** 会把函数赋给 `node.visible` → 真值 →
   永远可见。必须写 `visible={store.paletteOpen()}`。
5. **Enter 的键名是 `return`**，不是 `enter`。composer 的 Enter 处理器必须是 **`onSubmit`** 属性
   （`onEnter` 不在 solid 映射表里 → Enter 在编译产物里从不提交；store 测试绕过 input，缺陷只在真实
   产物检查里暴露）。
6. **对话框的 input 不要绑 Enter**：从按键处理器里打开的对话框会收到同一个按键——keymap 的
   `dialog-submit` 跑控制器 submit → `closeTopDialog` → `onDone` → 记录答案 → `openDialog` 新对话框 →
   Solid 同步渲染 → 新 input 带 `focused={true}` 挂载 → 同一个按键继续传播到新 input → 它的 `onSubmit`
   触发 → prompt 一开就提交空值。实测栈：`KeyHandler.emitWithPriority` → `Renderable` →
   `Input.submit()` → `emit (node:events)` → `submit (dialog-forms)`。**对话框的 Enter 只走 keymap 的
   `dialog-submit`**（路由到对话框控制器）；composer 必须绑 `onSubmit`（它不是对话框，没有控制器可
   路由）。`e46be31` 的 prompt `onSubmit` 修复是错的，已在 `61ad7d4` 回退。
7. **`textarea` 在 solid reconciler 里只认 `initialValue` / `onSubmit` 访问器**；`value` 与 `onInput`
   都不生效（`onInput`/`onChange` 的 case 只匹配 `InputRenderable`）。所以协议里没有多行字段。
8. **`<input>` 没有 `fg` 属性**；颜色属性是 `textColor` / `focusedTextColor` /
   `focusedBackgroundColor` / `placeholderColor`。`cursorColor` / `cursorStyle` 是 renderer 级 API，
   不是 input props——opencode 底本把它们当 input props 用，移植时删掉。
9. **Escape 只在 escape-timeout 窗口后上报**：测试要 `Bun.sleep(120)` + `flush()`。
10. **箭头要用 `mockInput.pressArrow('down')`**；`pressKey('down')` 把 `down` 当字面字符键入
    （`KeyCodes` 里没有 `down`，箭头是 `\u001B[A`）。`PageUp`/`PageDown` 在 KeyCodes 里没有条目，mock
    无法驱动。`typeText(text, 0)`（delay 0）与 `typeText(text)` 行为不同，去掉 delay 后键入才稳定。
11. **leader 和弦的第二个键会漏进新获得焦点的过滤框**：`ctrl+x t` 打开面板后 `t` 字节到达刚聚焦的
    input，过滤框变成 `themet`。修法是不用「预填过滤文本」表达分组，改为 spec 上的 `categoryFilter`
    字段在打开时收窄行集。同理 `ctrl+x s` 后的 `s` 会落到 settings 页的 filter，列表被过滤成含 `s` 的
    行——断言取过滤后在屏的行，不是「所有行」。
12. **每个对话框都要在 mount 注册控制器、cleanup 交还**：首版 `DialogPrompt` / `DialogConfirm` /
    `DialogAlert` 只建了 controller 没注册，Enter 完全无反应。`DialogSelect` 的注册写法（捕获 previous
    + onCleanup 还原）是嵌套栈的关键。写入器（`setFormFieldWriter`）用同样的模式。
13. **把函数当信号值直接 set，Solid 会把它当 producer 调用**：`setSignal(writer)` 里 writer 是两参数
    函数，被当 producer 用前值调用、返回 `undefined`，信号里存的是 `undefined`（实测 mount 里 set 完
    立刻读回 undefined，写入器永远「未注册」）。正解是包一层 producer：`setSignal(() => writer)`。
14. **信号驱动的字段清单不会把值搬进已有的 input**：`setFormFields(list => list.map(...))` 更新信号后，
    `For` 的行没有重建（探针实测 effect 与 `For` 的 memo 在 set 之后不再运行），input 的文本仍是旧值。
    走表单的**本地值**（写入器写进 `state.values`）才是正解——那正是键入用的同一条路径。
15. **行标题必须按面板实际宽度截断**（`dialogSelectContentWidth(min(dialogWidth(size), width - 2))`），
    不是 opencode 的固定 61。40 列终端下固定 61 会让长标题折行溢到屏幕外。
16. **`@dialog` 作用域没有 `background.action.primary.$focused`**；活动行高亮带用 `$hovered` 槽。
17. **选择框列表窗口是 `floor(终端高度/2) - 6` 行**（24 行终端下 6 行）；**窗口外的行不能靠网格断言**，
    改走对话框栈的 options 断言（`store.dialogStack().at(-1)?.options`）。`scrollToSelection` 在测试
    网格里没有滚动。
18. **管道 stdout 下渲染器默认 80×24；固定尺寸的根盒溢出时 OpenTUI overdraw 行而非裁剪**——用
    `width="100%"` + `flexGrow`（transcript 盒固定 `height={12}` 加二维码 3 行，在 24 行终端下把
    composer 行与二维码第三行画在同一行上）。

### 真实产物断言

19. **断言真实产物必须重建屏幕网格并在特性在屏时取快照**：差分渲染会跳过与上一帧同格的字符
    （`@tmp/check-frame.ts` 到达为 `@` + 光标跳转 + `mp/check-frame.ts`）；被后续覆盖的内容（doctor
    alert 被面板盖住、面板被 filter 改变、prompt 提交后关闭）在最终流里丢失。
20. **分帧正则必须匹配完整 CSI/OSC 序列**（`\x1b\[…final` 与 `\x1b\]…(BEL|ST)`）；只匹配 `[...]`
    会把 ESC 留在文本 token 里，网格出现字面控制字符。
21. **同一个快照时点不能同时断言「未过滤的行」与「过滤后的行」**：面板 filter 键入会改变列表。
    面板行快照在键入 filter 之前（4300ms），skills 行快照在 `skill` 过滤之后（4800ms）。
22. **`final` 是拼好的网格字符串**，取行要先 `split('\n')` 再 `slice`（`final.slice(10,16).map` 是
    `TypeError`）。
23. **input `width={40}` 正好裁断 40 字符的行**：网格断言只能取行首，完整值断言在 `form-submit`
    载荷上（渲染器把 input 的完整值送上去）。
24. **注入顺序决定键盘归属**：对话框打开时按键进的是过滤框，不是 composer。`ctrl+p` 之后的字节被
    面板吃掉，`@` 补全断言落空；把 `@` 注入排在 `ctrl+p` 之前才通。

### 宿主 / 协议

25. **`send` 返回 envelope seq**；`dialog-response` / `command-result` 按**请求的 seq** 关联（不是宿主
    自己的计数器）；`question-answer` 按 mount 的请求 id 关联。seq 不在挂起表的结果丢弃，领过一次即
    删除，同一 seq 不会弹两次报告框，消费过的 id 不重开。
26. **`subscribe` 在握手前注册并立即 emit**，会在 ack 前发出 `session-frame`。已加握手门（ack 前排队，
    ack 后按序 flush）。
27. **桥的订阅必须排在快照之后**：二维码先于 transcript 到达会让扫码块插到会话内容前面。
28. **`handles.setReasoningEffort` 的参数是 branded `ReasoningEffortId`**，IPC 送来的裸 string 必须
    `ReasoningEffortId(...)` 包装。
29. **`SlashCommand.description` 是 `string | undefined`**，`command-catalog` 的 payload 要求 `string`，
    映射时 `?? ''`。
30. **`ReasoningEffortSetting = ReasoningEffortMap | false`**，`ReasoningEffortMap` 是
    `Partial<Record<ThinkingLevel, string | null>>` —— 是**字典**不是数组，`[...map]` 报
    `must have a [Symbol.iterator]() method`。扁平行里编码为 `level=wire` 对、`;` 分隔；`wire` 为空写
    `null`（只有 `off` 可映射到 null/空）。非推理模型写 `none`。
31. **mount deps 里的 `selection` 是主题选择**（mode/darkId/lightId/selectedId），没有 `provider`；
    模型选择取 `handles.selectionRef?.current`。
32. **notice 级别词表是 `'info' | 'warning' | 'error'`**（不是 `'warn'`）；IPC `log` payload 的 level
    是 `'info' | 'warn' | 'error'`。两套词表在 mount 里分开。
33. **`exec()` 无匹配返回 `null`**，不是 `undefined`；`match === undefined` 的守卫会让 `match[0]` 抛
    `TypeError`。
34. **`settingsValues(ctx, ns)` 内部调 `ctx.settings.describe()`**；测试里的 fake context 只给 `update`
    会抛 `forms.describe is not a function`。用现成的 `contextWithSettings` helper。
35. **`OPENCODE_TUI_CONFIG` 设了但文件不存在时回落到默认路径是错的**：显式路径应当权威。
36. **`foldSessionTitle()` 返回对象**（取 `folded?.title`），不是字符串；`Session` 没有 `title` 属性。
37. **`AssistantStreamFrame` 的 chunk 是 `block-start` / `text-delta` / `reasoning-delta` /
    `block-end`**，不是 `{ text }`；流式行只累加 `text-delta`。
38. **profile patch 层带 cordis `!!js` 标签**，`js-yaml.load()` 抛 `unknown tag`。用
    `CORE_SCHEMA.extend([new Type('tag:yaml.org,2002:js', {kind:'scalar', construct: raw})])` 捕获原文；
    ESM 构建导出 `Type`（不是 `Tag`），无 `Schema.create`。
39. **Bun IPC**：子进程 `process.send(...)` / `process.on('message')`；`process.channel.send` 不存在。
    宿主 `child.send(...)` / `child.on('message')`。`stdio: ['inherit','inherit','ipc']` 时
    `child.stderr` 为 null（要读 stderr 用 `['inherit','inherit','pipe','ipc']`）。
40. **`childChannel` 的缺陷**：全部退订后重新订阅不会重新挂监听。已改为 0→1 时重新注册。
41. **跨平台 `bun build --compile` 需要 8 个 `@opentui/core-<platform>` 原生包全部安装**（pnpm 默认只
    装当前平台的可选依赖）。已显式写进 `renderer/package.json` devDependencies。
42. **`resolveRendererPath` 在 Windows 查带 `.exe` 后缀的产物名**；测试写 stub 时必须带后缀。
    `RendererHandle` 不暴露 `child`。
43. **`mountRenderer` 必须注入 `spawn`**，否则测试真的 spawn 不存在的路径
    （`ERR_IPC_CHANNEL_CLOSED`）。`routeStdoutToLog` 必须接受 `streams` 参数：测试里替换真实
    `process.stdout.write` 会吞掉测试运行器输出。

### 工具与编辑

44. **在测试里用 `oldString` 替换「下一个测试的声明行」来插入新测试，会把那个测试的声明吃掉、留下
    孤立函数体**（`store is not defined` / 语法错）。插入点要用**测试体结尾**（`await dispose()\n})`）
    做锚。这个坑在本会话踩了三次。
45. **测试名里的英文撇号（`input's`）会截断单引号字符串**，产生 BABEL_PARSE_ERROR。
46. **help 文本是模板字符串（backtick），里面不能出现 backtick**——会截断字符串产生
    `SyntaxError: Unexpected identifier`。中文文案里的代码名用裸词或引号。
47. **PowerShell `Add-Content` 写 JSON 时双引号转义会把字面反斜杠写进文件**（`Expected property name
    ... at position 1`）。用单引号字符串变量写。
48. **PowerShell 里 `$env:PATH = "$bin;$env:PATH"` 后 `Remove-Item Env:PATH -Force` 是清空 PATH 不是
    还原**，后续 `node` 找不到。要跑 profile 的启动器就直接 `node <path>\scripts\dpsk.js`，不要动 PATH。
    `.bin` 目录里是 `dpsk` / `dpsk.CMD` / `dpsk.ps1` 三个 shim，没有 `dpsk.js`。
49. **`git commit -m` 与 `-F` 不能混用**；正文走临时文件，subject 一并写进文件首行。
50. **`npm run build:renderer` / `test:renderer` 用 `cd renderer && bun ...`**：`bunfig.toml` 只在 cwd
    为 `renderer` 时生效，从仓库根跑会报 `Cannot find module 'react/jsx-dev-runtime'`。

### 渲染器 / IPC 通道（第十三批新增）

51. **Bun 在子进程第一次写 fd 2（stderr）时关闭它的 IPC 通道**（`stdio` 为 inherit 与 pipe 皆成立，
    编译产物与 `bun` 跑脚本皆成立）。渲染器写 stderr = 自断通道：进程活着、继续画、继续吃按键，宿主
    之后的 `child.send` 抛 `ERR_IPC_CHANNEL_CLOSED`。`process.stderr.write` 必须换掉（改道进通知块，
    store 未建时缓冲），`console.*` 在渲染器不可用（OpenTUI 把 console 方法改写到自己的覆盖层，
    `console.error` 绕过改道），失败报告走 stdout（拥有 TTY 之前 stdout 就是终端）。
52. **`child.on('exit')` 在「通道被关、进程仍活着」时不触发**；`child.on('disconnect')` 才是信号。
    验收脚本要同时听两个事件；宿主在 disconnect 后 200ms 补 kill 与终端恢复序列，`exit` 先到时跳过
    （正常退出先 disconnect 后 exit）。`handle.bye()` 也要包 try/catch，否则未捕获异常让验收脚本在
    断言打印前退出。
53. **两个 IPC 分发器把每个下行信封应用两遍**：每个对话框开两遍，每个对话框的
    `useTerminalDimensions` resize 监听也翻倍，跨过默认上限 10 → `MaxListenersExceededWarning` 打印到
    stderr → 通道关闭（51 的触发器）。分发器只在握手前注册一次，握手窗口不留空。
    `process.setMaxListeners(0)` 与 `renderer.setMaxListeners(0)` 是第二层保险。
54. **bisect 用「一次只动一步的变体开关」（`DSH_PROBE`）+「disconnect 出现的时间点」定位触发链**，
    比读代码猜快；变体脚本放 `tmp/`（gitignored）。store 层测试（直接调
    `store.closeTopDialog('gpt')`）通过，缺陷只在编译产物的真实按键链里现形——**回归测试要走
    `testRender` + `pressArrow('down')` + `pressEnter()`**，断言「宿主答 `form-spec` 后表单开一次」
    与「通知块只画一条 paint 记录」。

### 宿主 / 激活体 TDZ（第十四批新增）

55. **`onAck` 在激活体的 `await` 挂起点上运行**：渲染器挂载后激活体 `return`，`hello` 到达时激活体还
    悬在后面的 `await` 上。挂载的 ack 回调要建快照、发目录，所以**渲染器路径要读的 `const` 必须声明在
    渲染器块之前**。第一个坑是 `selectionFor`（`Cannot access 'selectionFor' before initialization`），
    修完第二个坑是 `commandEntries`（同一形状，`command-catalog` 的映射读它）。门禁全绿掩盖缺陷：mount
    测试直接构造 mount，不走真实激活体，TDZ 只在安装产物的真实握手路径里现形。
56. **渲染器路径的 `handles` 赋值必须与声明同处**：`handles.saveSelection` /
    `handles.setReasoningEffort` / `handles.selectionRef` 原本在 pi-tui 路径末尾赋值，渲染器路径
    `return` 前它们仍是 `undefined`——模型选择点了等于没点（不报错，只是没写回）。移动声明时把赋值一起
    搬，并检查「谁在渲染器路径读 handles」。
57. **`refreshSkillCommands()` 要在渲染器块内调用**：技能命令目录的重发原本挂在 pi-tui 路径的注册表上，
    渲染器路径不跑，`command-catalog` 少一次重发（技能在渲染器里不可达）。渲染器块内加
    `void refreshSkillCommands()`。
58. **TDZ 的实机 smoke 办法**：用约定的启动命令 `dpsk`（它自带 `--profile tui`，不要再传），
    `$env:DSH_RENDERER='1'`（或让启动器自动确保产物），
    `Start-Process cmd -ArgumentList "/c dpsk > out.txt 2> err.txt"`，睡 8–10 秒后
    `taskkill /T /F /PID <cmd 的 pid>`，读最新的 `$env:USERPROFILE\.dsh\logs\tui-<pid>.log`——**出现新的
    fatal 日志文件就是崩溃**，没有就是干净。stdout 里看到 `[?1049h` 与 `会话:`/`会话列表:`/`dpsk host:
    my-dpsk-harness-tui 0.5.0` 即渲染器已进 alt-screen 并画完首帧（原始流里 CJK 与 header 会被光标移动
    拆开，断言前先剥 ANSI 序列）。stderr 应当是空的。

### 系统安装（S9 新增）

59. **旧包会把新包整体遮住**：`dsh-omp-tui@0.4.0` 与 `my-dpsk-harness-tui@0.5.0` 注册**同一个 `tui`
   服务**和同一个 session-title provider。profile 的 `dsh.profile.bundles` 里两份并存时，先加载的旧包赢，
   新包报 `2 entries did not activate`——现象与「新包没装」一模一样，而 `dpsk check` 依旧报告「全局与
   profile 一致」（它比的是新包自己的源包哈希）。只重命名 `node_modules/dsh-omp-tui` 不够：依赖表还留着，
   下一次 pnpm 安装会把它装回来。要同时摘 `dsh.profile.bundles` 与 `dependencies`/`devDependencies`
   （`stripLegacyProfilePackage`），或手工 `dsh plugin --profile tui rm dsh-omp-tui`。查组合树用
   `dsh --profile tui --dump-config`。
60. **`npm link`/junction 装的全局包不会为改名的 bin 生成 shim**：`%APPDATA%\npm\node_modules\dsh-omp-tui`
   是指向开发目录的 JUNCTION，里面的 `package.json` 已写成 `bin: { dpsk }`，但 `%APPDATA%\npm` 下只有指向
   早已改名的 `scripts/omdsh.js` 的三个旧 shim——`dpsk` 命令根本不存在。删链接用
   `cmd /c rmdir "<链接路径>"`（只删链接），**绝不要**用递归删除（`Remove-Item -Recurse` /
   `rmdir /s`），那会顺着 junction 删进 `D:\Projects\dsh`。之后 `npm install -g ./<tgz>` 由 npm 生成
   `dpsk`/`dpsk.cmd`/`dpsk.ps1`。
61. **`dpsk` 已经自带 `--profile tui`**：再传一次报
   `error: option '--profile <name>' argument 'tui' is invalid. select a profile only once` 并什么都不画。
   smoke 用裸 `dpsk`；要看将执行的命令用 `DSH_DEBUG=1 dpsk`。
62. **启动器的 profile 迁移要挂在启动与 `check` 上**：只在 `dpsk update` 跑的迁移，对不用 `update`
   （离线/未改名仓库）的用户等于没有。`ensureProfile()` 与 `runCheck()` 开头各调一次
   `migrateLegacyProfilePackage()`，摘干净后是零输出幂等。

63. **启动器自己的开关必须在透传前摘掉**：`--renderer` / `--no-renderer` 只是 `DSH_RENDERER` 的糖，
    dsh 不认这两个选项，原样透传会被 dsh 当未知参数。`consumeRendererFlag(passthrough)` 在
    `startTui` 开头把开关吃掉、改成设/清环境变量，其余参数保序透传；带值的写法
    （`--renderer=true`）故意不认，留给 dsh 报错。
64. **坑 46 复发**：给 help 模板字符串加新行时又写了反引号（`` `--renderer` ``），直接
    `SyntaxError: Invalid left-hand side expression in postfix operation`，报错位置指向整个模板字符串
    的起始行（`const launcherHelp = ` 那一行），容易被带到别处。**改 help 之前先通读有没有
    backtick**。测试里立刻暴露：`tests/launcher.spec.ts` 一 import 就解析失败。

### 用户并行实测新版界面（2026-10-17 起）

用户要在继续开发的同时实测新 TUI。入口是 `dpsk --renderer`（等价 `DSH_RENDERER=1`；0.5.0 默认
仍是 pi-tui）。**用户实测前先 `dpsk check`**：同版本内容漂移只有 `check` 会覆盖 profile，否则
用户测到的是旧构建。`docs/INSTALL.md` 的「试新版界面」小节写了首屏应当看到什么、键位、以及
「启动还是旧界面」的两个常见原因（没设开关 / 旧包遮蔽）。

---

## 10. 工作流约定（沿用）

每个阶段：**先建 todo 列表 → 工作中更新 todo → 验收 → 自主 commit（不必询问）→ 绝不 push**。
全部阶段完成后：打包安装到系统，**用户实测功能，然后用户 push**。

提交信息格式：`<emoji> <type>(<scope>): <中文描述>`，body 走临时文件 + `git commit -F`
（`-m` 与 `-F` 不能同用，把 subject 一并写进文件首行）。
