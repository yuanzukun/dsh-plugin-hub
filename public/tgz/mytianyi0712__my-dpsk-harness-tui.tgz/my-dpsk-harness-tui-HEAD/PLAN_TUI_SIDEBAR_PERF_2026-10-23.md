# Sidebar, context cost, config hot reload, restart, startup and switch performance plan

> Date: 2026-10-23
> Status: planning
> Version: keep `0.5.0`
> Boundaries: renderer + launcher + host hot paths; no dsh upstream change, no publish/tag/push, no protocol redesign in the first pass.

## 1. Goals

1. Reduce the docked/overlay sidebar width from 42 to 40 cells without clipping, overflow, or resize regressions.
2. Improve cold startup and warm startup time to first usable frame.
3. Improve live-session switching, cold persisted-session switching, and switch-back responsiveness.
4. Keep every optimization measurable and reversible; correctness and session isolation always win over cache tricks.
5. Make the compact thinking header settle on the first body chunk: `Thought <duration> | Used N Tools` must not wait for body completion.
6. Restore cache-hit reporting when the provider supplies `cacheReadTokens` but omits `cacheWriteTokens`; only the read bucket is required for the hit-rate denominator.
7. Replace the context block with `CTX`, `SUM`, and estimated `$` lines using dynamic k/m formatting.
8. Move program-owned config to `~/.config/.mydpsk`, add price.json plus a custom_price.json override table, and hot-reload program config without restarting dsh.
9. Add `/restart` to reload DSH-side configuration through a persistent dpsk supervisor without closing the terminal.

## 2. Baseline and observed hot spots

### 2.1 Sidebar width

- `renderer/src/ui/layout.ts` defines `SIDEBAR_WIDTH = 42`; it is the docked width, overlay width, default terminal pane width, and resize default.
- Existing geometry tests hard-code 42 in several places: 168-column content width, pane columns, wheel coordinates, prompt centering.
- `clampPaneWidth` has a 24-cell floor and a content-floor cap, so 40 remains a valid default.

### 2.2 Launcher / startup baseline

- Warm measurements on this machine: `dsh --version` 156-239 ms, `node scripts/dpsk.js renderer path` 94-98 ms, `dpsk --version` 832-933 ms.
- The launcher spends roughly 500-600 ms above the underlying dsh+node cost. `resolveBackend()` scans every PATH entry and spawns `dsh --version` even when a valid backend is already saved in `~/.dsh/dpsk/backend.json`.
- Host `mount()` currently awaits `runStartupMigrations()` and then `ensureTerminalController()` before spawning the renderer. Migrations list all session snapshots and may prune blank TUI directories.
- The ack path synchronously builds the full initial snapshot: `snapshotFor()` folds all session events through `transcriptEvents()`.
- The first `pushSessionList()` scans every session, title snapshots, untitled heads, persistence snapshots, and activity tails. Current store has 202 session files, 48.3 MB compressed total, p90 0.7 MB, max 5.9 MB.

### 2.3 Session switch baseline

- Live switch: `activateAgent()` clears folds/usage, runs `replayTranscript()` over all session events, then `rendererSnapshotPush()` builds/sends another full `transcriptEvents()` projection.
- `rendererSnapshotPush()` also starts image-capability, full session-list, workspace-file scan, skills snapshot, model/agent/reasoning catalogs. They run in parallel but compete for the same event loop/IO.
- Cold persisted switch: `resumeAgent()` first calls `ctx.sessionQuery.listSessions()` only to validate the target, then `ctx.agents.resume()` loads the log, then the same replay/snapshot path runs. This is an avoidable full scan.
- Renderer snapshot handler clears commands, models, mentions, skills, subagents, todos, queues, usage, git, turn state, permission and preset lists on every snapshot, even for same-session refreshes.
- There is no per-session renderer transcript cache: switching away and back throws away the old rendered rows and waits for a fresh full snapshot.

## 3. Design decisions

### 3.1 Sidebar 40

- Change `SIDEBAR_WIDTH` from 42 to 40 and keep every consumer derived from the constant.
- Do not introduce a second width constant. Docked, overlay, and default terminal pane all follow the same value.
- Keep `clampPaneWidth` min 24 and `CONTENT_MIN_WIDTH` semantics unchanged.
- Update frame tests from 42-derived coordinates to 40-derived coordinates; add narrow/docked/overlay/resize assertions.

### 3.2 Startup: eliminate repeated discovery, parallelize, defer optional work

- Launcher fast path: if `DSH_REAL` is absent, `backend.json` has a valid saved backend, and the saved executable still exists with a valid signature, skip PATH scanning and `dsh --version`; fall back to full discovery on any mismatch. Keep an explicit `dpsk backend list` full-refresh path.
- Parallelize independent host startup work: run optional session cleanup and terminal-controller setup concurrently, with failure isolation.
- Move blank-session pruning and other non-render-critical maintenance after the first snapshot when it does not affect current settings/theme/model state.
- If profiling shows `ensureTerminalController()` is expensive, mount the renderer first and publish terminal actions in a later snapshot instead of delaying the first frame.
- Keep the initial snapshot authoritative; catalogs may follow it, but the renderer must not be blocked behind workspace/skills/model scans.

### 3.3 Session switch: cache projections, coalesce refreshes, paint from cache

- Host projection cache: cache the folded transcript per agent/session revision; invalidate on session event/turn/rename changes. Reuse it in `snapshotFor()`, `replayTranscript()`, rename refreshes, and image-capability refreshes.
- Cold resume validation: stop calling `listSessions()` just to find the target; use a direct session/persistence lookup or a cached session index.
- Workspace/skills/catalog cache: cache workspace files by cwd, skills by workspace revision, and model/agent preset catalogs with a short TTL or explicit invalidation. Coalesce duplicate requests.
- Session-list coalescing: at most one in-flight list build plus one trailing refresh; reuse title/head/activity caches where revision permits. Do not rebuild on every agent status tick.
- Priority order on switch: send `session-snapshot` first, then visible session catalogs, then background workspace/skills/image/MCP work.
- Renderer per-session cache: retain the last transcript, metadata, scroll position, draft, commands/models, and catalogs per session; on tab switch paint the cached view immediately, then reconcile the authoritative snapshot.
- Same-session snapshots must preserve existing per-session state instead of clearing all lists; only a genuine session change may swap the active cache.
- Add an optimistic active/pending tab marker so a click gives feedback before the host round trip completes.
- Add latest-wins generation guards so rapid switches cannot let an older resume/snapshot overwrite a newer selection.

### 3.4 Compact thinking header at first body delta

Root cause:

- The host creates `streamRow` on the first reasoning delta with `createdAt` at reasoning start and no `bodyAt`.
- When the first text delta arrives, the existing-stream-row branch appends text but does not set `bodyAt`.
- `planThinking` then falls back to `row.createdAt` for `endedAt`, producing a zero duration; `formatThinkingDuration` omits sub-second values, so the header is just `Thought` (plus tools when present) until the durable assistant message arrives.
- Only after body completion does the durable row supply a completion timestamp and a full duration.

Fix:

- On the first text delta for an existing reasoning stream row, set `bodyAt = bodyAt ?? now` and mark reasoning done.
- Preserve `bodyAt` through later text deltas, stream-end frames, and the durable assistant row.
- `planThinking` will then use the first body timestamp as `endedAt`, so `Thought Xs | Used N Tools` appears as soon as body output starts.
- Classic reasoning rows and reasoning content remain unchanged.

Tests:

- Reasoning delta -> tool -> first text delta: compact header immediately contains duration and tool count.
- Before the first text delta the header remains in the live thinking state.
- Durable assistant message updates timestamps without changing text or tool count.
- No premature `Thought` duration when there is no body output yet.


### 3.5 Cache hit statistics with read-only provider samples

Root cause:

- A real cliproxy sample carried `cacheReadTokens` and no `cacheWriteTokens`.
- `foldUsageSample()` sets `cacheBucketsComplete=false` whenever either bucket is absent.
- `sidebar.tsx` and `status-bar.ts` require `cacheBucketsComplete === true`, so the UI renders `cache —` even though the read-hit denominator is available.

Fix:

- Track read and write completeness separately in `UsageFold`: `cacheReadComplete`, `cacheWriteComplete`; keep `cacheBucketsComplete` as the conjunction for compatibility.
- Extend host and renderer `UsagePayload` with optional `cacheReadComplete`. Emit it from the running usage fold.
- Compute and show cache hit when `cacheReadComplete` is true and `inputTokens + cacheReadTokens > 0`. `cacheWriteTokens` is not required for the hit-rate ratio.
- Backward compatibility: when `cacheReadComplete` is absent, fall back to the old `cacheBucketsComplete === true` behavior.
- Keep `cache —` only when cache reads are truly unreported or the denominator is zero.

Tests:

- Host fold: read present + write absent -> read complete true, write complete false, buckets complete false.
- Sidebar: read-only sample renders `cache <pct>%`, not `cache —`.
- Status bar: same sample renders `cache <pct>%`.
- Missing cache-read bucket or zero denominator still renders `cache —`.
- Old payload without `cacheReadComplete` keeps previous semantics.


### 3.6 Context summary and estimated cost

Sidebar context section becomes a fixed three-line block:

```text
CTX 14.5k
SUM 14.3k (40% cache)
$ 0.0042
```

- `CTX` uses `usage.contextTokens` and dynamic `formatTokens` units (k/m).
- `SUM` uses cumulative known input + output + cache read/write totals with the same dynamic units.
- The existing cache-hit suffix moves onto the SUM line so the previous cache-stat requirement stays visible inside the three-line structure.
- `$` is an estimated USD cost, formatted dynamically: `$0.0042`, `$0.12`, `$1.23`; unknown model price renders `$ —`.
- Missing usage values render `CTX —`, `SUM —`, `$ —`; no fabricated zero.

### 3.7 Pricing table, config home, and hot reload

Config home moves to `~/.config/.mydpsk` (literal home-relative path on every platform, including Windows).

Ownership split:

- Program-owned config: `~/.config/.mydpsk/config.json`, `price.json`, `custom_price.json`, `backend.json`.
- DSH-owned data stays under DSH_HOME: sessions, attachments, project caches, `cordis.patch.yml`, and dsh settings.
- Runtime state/cache such as renderer binaries, tabs, and prompt history are not config and are not moved into the config directory in this pass.

Pricing JSON design:

- Built-in public table ships with the package and seeds `price.json`; `custom_price.json` starts empty and has higher priority.
- External edits override/extend the built-in table; there is no in-program price editor.
- Provider/model matching supports exact, provider wildcard, model wildcard, and global fallback.
- Rates are USD per 1M tokens, with separate input, cache-read, cache-write, and output prices.
- Optional context/price tiers can be represented without hardcoding provider names.
- Time schedules are data-driven: timezone, weekdays, inclusive start/end, effective-from/until, and a multiplier or alternate rate set. This covers DeepSeek peak/off-peak billing without code changes.
- Cost is computed per usage sample using the sample timestamp and model/provider metadata, then folded into session cost. Aggregating first and applying one rate would misprice calls that cross a peak/off-peak boundary.

Example pricing shape (rates are placeholders until the built-in table is verified):

```json
{
  "version": 1,
  "currency": "USD",
  "models": {
    "cliproxy/deepseek-v4.1-flash": {
      "provider": "cliproxy",
      "model": "deepseek-v4.1-flash",
      "ratesPerMillion": {
        "input": 0.28,
        "cacheRead": 0.028,
        "cacheWrite": 0.28,
        "output": 0.42
      },
      "schedules": [
        {
          "timezone": "Asia/Shanghai",
          "days": ["mon", "tue", "wed", "thu", "fri", "sat", "sun"],
          "start": "00:30",
          "end": "08:30",
          "multiplier": 0.5
        }
      ]
    }
  }
}
```


Hot reload:

- Host owns a config store that watches `config.json`, `price.json`, and `custom_price.json` with fs.watch plus debounce and a polling fallback.
- Changes are parsed, validated, atomically loaded, and broadcast to the renderer; invalid files keep the last good config and produce a toast.
- Pricing reload recomputes active-session usage cost and pushes a new `usage` payload without restarting the renderer.
- Other program-owned config fields are declared hot-reloadable or restart-required in schema; restart-required fields report that explicitly.
- DSH-side configuration is explicitly out of scope: it is read by dsh at process start and is handled by the restart command below.
- First-run migration copies legacy `~/.dsh/dpsk/backend.json` to the new config home, writes atomically, and leaves a backup/legacy marker.


### 3.8 Restart command and dsh supervisor

Add an in-app `/restart` command for reloading DSH-side configuration without closing the terminal.

- `dpsk` becomes a supervisor in interactive mode: it keeps the terminal/process alive, spawns the selected `dsh` child, and normally exits when that child exits.
- `/restart` writes a handoff file under `~/.config/.mydpsk/runtime/restart.json` containing the current session id, route, draft, and restart reason, then exits the DSH plugin with a dedicated restart exit code.
- The supervisor recognizes only that exit code and respawns dsh with the same backend and `DSH_RENDERER_PATH`; normal exits, Ctrl+C, and crashes still terminate the supervisor.
- Respawned dsh uses `--resume <sessionId>` when appropriate and reloads the DSH profile/patch files, which is the point of the command.
- The new renderer consumes the handoff to restore the draft and route; tabs/history continue to come from their existing state files.
- If dsh was launched directly without the dpsk supervisor, `/restart` reports that in-place restart is unavailable instead of exiting and losing the TUI.
- Add a restart loop guard: at most three automatic restarts in 60 seconds, then surface the last failure and exit.
- The supervisor does not re-run profile installation, backend discovery, or renderer download for each restart.
- `/restart` is the primary command; a launcher-level control-file request can share the same handoff path if an external `dpsk restart` surface is added later.


## 4. Phases

| Phase | Work | Exit criterion |
|---|---|---|
| S0 | Add opt-in timing marks behind `DPSK_PERF=1`: launcher, agent ready, migrations, terminal ready, renderer spawn/hello/ack, snapshot build/send/apply, first-frame, switch click/resume/activation/catalog completion. Record p50/p95 for 5 warm runs and relevant cold cases. | Baseline report committed as text in the plan/progress; no behavior change |
| S1 | Sidebar 42 -> 40; update geometry, resize, overlay, terminal pane tests. | 120/121/168-column frame tests pass; no clipping/overflow |
| S1.5 | Set `bodyAt` on the first text delta of an existing reasoning stream; preserve it through stream end/durable row; add header timing tests. | Header switches to `Thought Xs | Used N Tools` on first body chunk; no early duration before body |
| S1.6 | Split cache read/write completeness, add `cacheReadComplete` to usage payload, update sidebar/status bar hit-rate gates. | Read-only provider sample shows cache hit percent in both surfaces; unknown reads still show cache dash |
| S2 | Launcher saved-backend fast path; add tests for valid cache, missing executable, DSH_REAL override, version mismatch fallback. | `dpsk --version` p50 materially lower; no stale/incorrect backend selected |
| S2.5 | Migrate program config to `~/.config/.mydpsk`; add price.json/custom_price.json/config.json store, schema validation, watcher, debounce, last-good fallback, and legacy backend.json migration. | External config edits apply without restart; invalid file keeps last good config and reports an error |
| S2.6 | Add per-sample cost estimation with provider/model matching, cache buckets, tiers, and timezone schedule windows; render CTX, SUM, cache share, and USD cost in the sidebar. | Real read-only usage sample shows cost and cache hit percentage; DeepSeek peak/off-peak schedule changes pricing at the configured time |
| S2.7 | Add `/restart` handoff + dsh supervisor loop with session/draft restoration, direct-launch fallback, and restart-loop guard. | DSH profile changes reload after `/restart` without closing the terminal; normal exits do not respawn |
| S3 | Parallelize startup and defer optional cleanup/terminal work after first snapshot where safe. | Cold/warm first-frame p50 improves without lost settings/theme/terminal actions |
| S4 | Host switch caches: transcript projection cache, direct target lookup, workspace/skills/catalog caches, session-list coalescing, priority ordering. | Live switch and cold switch p50 improve; no stale rows/catalogs |
| S5 | Renderer per-session cache and optimistic switch feedback; same-session snapshot preservation; latest-wins guards. | Cached switch is visibly immediate; host refresh reconciles without flicker; stale results are dropped |
| S6 | Full regression, benchmark report, README/CHANGELOG/contracts/acceptance updates. | Host/renderer suites green; benchmark table recorded |
| S7 | Build, 7-platform artifacts, SHA256SUMS, global/profile install, `dpsk check` idempotence. | Installed 0.5.0 matches manifest and profile |

## 5. Test matrix

### Sidebar

- 40-cell docked, overlay, and terminal pane at 120/121/168 columns.
- Pane resize clamps, drag seam, wheel hit area, prompt/content centering, and sidebar section truncation.
- No row exceeds terminal width; content never falls below its floor.

### Startup / launcher

- Saved backend hit avoids PATH scan and version spawn; invalid/moved path falls back.
- `DSH_REAL` and `dpsk backend list` still perform full discovery.
- Renderer path cache hit remains offline and hash-independent at launch.
- Same settled configuration starts with one migration pass, one initial snapshot, and no duplicate session-list scan before paint.

### Switch correctness / performance

- Live switch and cold resume preserve transcript, title, usage, queue, todos, MCP, terminal, and permission state.
- Same-session snapshot does not erase catalogs or reset turn state.
- Switch-back paints cached rows immediately, then reconciles a newer host snapshot.
- Rapid A -> B -> C switches end on C; late A/B responses cannot overwrite C.
- Session-list coalescing sends the newest current id exactly once per settled refresh.
- Cache invalidation: incoming events, rename, model change, workspace/skills change, and process restart.
- Benchmark: fresh start, warm start, live switch, cold persisted switch, switch-back, measured p50/p95.

### Thinking header timing

- Host stream fixture: reasoning delta at t0, tool at t1, first text delta at t2; emitted row carries `bodyAt = t2`.
- `planThinking` header at t2 already renders `Thought <duration> | Used N Tools`; it must not wait for `assistant/message`.
- Later text deltas keep the same `bodyAt` and duration.
- Stream end and durable assistant message retain the same header values and tool count.
- Reasoning-only live block still shows `Thinking`; no `Thought` duration appears before body output.
- Zero-tool block renders `Thought <duration>` without a bogus Used suffix.
- Classic mode remains unchanged.


### Cache hit statistics

- `foldUsageSample` distinguishes read-only samples from fully unknown cache usage.
- Host `usage` payload carries `cacheReadComplete` and all existing cache token fields.
- Sidebar frame with `cacheReadTokens` + omitted `cacheWriteTokens` shows a percentage and non-empty token total.
- Status-bar metrics show `cache N%` for the same sample.
- Known read but zero denominator stays `cache —`; absent read stays `cache —`.
- Old payload without `cacheReadComplete` remains backward compatible.


### Context lines and cost estimation

- Sidebar at 40 cells paints exactly `CTX <token>`, `SUM <token>`, `$ <usd>` plus the cache suffix on SUM.
- Dynamic units switch between raw, k, and m at the existing formatter boundaries.
- Cost uses per-sample provider/model detection, input/cache-read/cache-write/output rates, and 1M-token normalization.
- DeepSeek-style schedule tests cover peak/off-peak boundaries, weekday filters, midnight-crossing windows, and timezone conversion.
- Multiple samples across different schedules fold into one session cost instead of repricing the aggregate.
- Unknown model/provider renders `$ —`; zero/empty usage does not fabricate a zero charge.
- Cache read/write buckets are included consistently with the cache-hit percentage.

### Program config and hot reload

- New config home resolves to `~/.config/.mydpsk` on Windows and POSIX.
- Legacy `~/.dsh/dpsk/backend.json` migrates once; repeated startups are idempotent.
- Valid external edits to config.json/custom_price.json apply within the debounce window without restarting dsh.
- Invalid JSON, wrong schema, partial atomic writes, and deleted files keep the last good config and show a notice.
- Pricing reload reprices active usage and pushes the new USD cost to the renderer.
- Restart-required program config fields are reported as such instead of silently not applying.
- DSH-owned profile/settings files are never watched or rewritten by this config store.

### Restart command and supervisor

- `/restart` writes a handoff and exits with the dedicated restart code only when the dpsk supervisor owns the process.
- Supervisor respawns only the restart code; normal exit, Ctrl+C, SIGTERM, crash, and renderer failure keep existing shutdown semantics.
- Respawn keeps backend, `DSH_RENDERER_PATH`, terminal stdio, current session, tab set, and draft.
- New process reads DSH profile/patch changes; old renderer process is gone before respawn.
- Direct dsh launch reports that in-place restart is unsupported and does not exit.
- Three restarts inside 60 seconds trip the loop guard and surface the last error.
- Launcher fast path is not re-run on every restart.


## 6. Acceptance targets (initial)

- Sidebar occupies 40 cells by default and all geometry tests pass at 40/80/120/168 widths.
- Warm launcher overhead (`dpsk --version`) p50 <= 500 ms, from the current ~838 ms.
- Warm startup to first usable frame improves at least 20 percent versus S0 baseline.
- Live session switch shows cached content or an active pending tab in <= 50 ms; host refresh completes without layout jump.
- Cold persisted-session switch p50 improves at least 20 percent versus S0 baseline.
- No session content crosses sessions, no stale transcript wins, and all existing host/renderer tests remain green.
- On the first streamed body chunk, the compact header already shows `Thought <duration> | Used N Tools`; it no longer waits for body completion.
- With a provider usage sample that reports `cacheReadTokens` but omits `cacheWriteTokens`, both sidebar and status bar show the cache hit percentage instead of `cache —`.
- Sidebar context shows `CTX <token>`, `SUM <token> (cache N%)`, `$ <usd>` at 40 columns; unknown price is `$ —`, not `$0.00`.
- External edits to `~/.config/.mydpsk/config.json` and `custom_price.json` apply without restarting dsh; invalid files leave the last good config active with a visible error.
- `/restart` reloads DSH profile/patch changes without closing the terminal, preserving session, tabs, and draft; normal exit still exits normally.

## 7. Risks and mitigations

- Cached transcript is stale for a background running session: invalidate on every session event revision and mark the view refreshing until the authoritative snapshot arrives.
- Per-session catalogs can diverge after settings/model changes: version caches by session revision and clear them on rename/model/permission/preset events.
- Deferred startup work can hide real failures: keep health checks explicit and report deferred failures as toast/log notices.
- Launcher backend caching can select a moved/wrong runtime: store path signature and fall back to full discovery on mismatch; keep `dpsk backend list`.
- Larger renderer cache can increase memory: bound it by open tabs and evict closed sessions; measure RSS before/after.
- Price tables can be stale or model ids can change: keep built-in defaults, show `$ 未配置模型价格` for unknown, and include a pricing version/updatedAt in config validation diagnostics.
- Hot reload can observe partial writes: debounce, retry, validate, and keep the last good snapshot before broadcasting.
- Restart can orphan the renderer or loop on startup failure: wait for child/renderer exit, use a dedicated exit code, backoff, and a 3-restarts/60s guard.

## 8. Non-goals for this pass

- No host protocol redesign or transcript pagination.
- No removal of sidebar sections to fake width savings.
- No renderer bundle size optimization or dsh upstream change.
- No version bump, publish, tag, push, or commit.
- No arbitrary rate editor; `/price` assigns a `price.json` entry into `custom_price.json`, which may also be edited externally and has the highest priority.
- No hot reload of DSH-owned profile/settings; DSH-side changes use `/restart`.
- No migration of sessions, attachments, renderer binaries, tabs, or prompt history into the config directory.
- No automatic backend switch while dsh is running; backend changes apply on the next launch or restart.

