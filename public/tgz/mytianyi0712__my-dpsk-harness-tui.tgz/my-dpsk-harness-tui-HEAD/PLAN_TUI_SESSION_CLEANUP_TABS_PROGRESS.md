# Session cleanup / picker / tabs - progress

Plan: `PLAN_TUI_SESSION_CLEANUP_TABS_2026-10-23.md`
Status: build/install complete; automated gates green; manual TUI acceptance pending; S6 config layer deferred.

| Step | Status | Evidence |
|---|---|---|
| S0 baseline | done | host 290 / renderer 376 baselines locked |
| S1 blank live session | done | `sessionListBlank` host test; picker/tab filtering; host 290 pass |
| S2 compact picker | done | activity-label unit tests + 40/80/120 frame; one title + time row |
| S8.1 running footer | done | interrupt replaces cwd on left, command hint stays right; unit + frame pass |
| S8.3 ~ path display | done | win32/posix pure tests, ~-aware truncation, setting write + frame persistence |
| S3 tab model | done | 8 model tests: order, closed stack, reopen, draft promotion, prune, legacy/v2 decode |
| S4 draft tab | done | one draft, + idempotent, first prompt promotes in place, failure keeps draft |
| S5 strip interaction | done | stable order, cached title, hover close, drag reorder, running dot, ctrl+1..0, prune |
| S8.2 effort shortcut | done | Ctrl+T existing forward cycle/Home/Session/wrap tests; Tab unchanged |
| S6 tab config | deferred | tabs.mode/scope/layout/indicators and vertical rail wait for horizontal real-terminal acceptance |
| S7 final gates/install | done | host 290 / renderer 376 green; 7-platform build + SHA256SUMS; global/profile synced; dpsk check idempotent |

## Verification

- `npm run check`: 290 tests, 289 pass, 1 skipped, exit 0.
- `npm run test:renderer`: 376 pass, 0 fail, 3088 expectations, exit 0.
- Test harness now injects memory-backed LocalStorage; full renderer suite leaves no real tabs.json.
- `bun run typecheck` in renderer and `npm run typecheck` in host pass.

## Deliberate scope decisions

- Session picker uses one title + right-aligned coarse time; no group headers/details. Hidden searchText retains id/workspace.
- Home draft is renderer-local synthetic tab; it is not persisted and never calls host create by itself.
- Tab order is local/manual; catalog lastActivity only sorts picker.
- No fake unread/attention. Running dot uses session-list.status.
- `Ctrl+T` remains the effort cycle; Tab stays completion; Ctrl+Shift+T stays reopen.
- `~` is display-only; all operational paths remain absolute.

## Remaining

1. Build host + 7-platform renderer artifacts and regenerate SHA256SUMS.
2. Install current build globally, sync tui profile, replace win32-x64 renderer cache.
3. Run `dpsk check` idempotence.
4. User manual acceptance from docs/ACCEPTANCE_TUI_SHELL.md section 7.

