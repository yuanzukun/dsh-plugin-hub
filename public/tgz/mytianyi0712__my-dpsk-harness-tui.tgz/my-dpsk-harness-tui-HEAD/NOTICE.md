# Third-Party Notices（上游登记表）

本包以 BSD-3-Clause 分发（见 [`LICENSE`](LICENSE)）。其中包含来自第三方上游的
代码、数据与资产。MIT 与 BSD-3-Clause 派生材料在本包中的收录条件为：逐文件
provenance 头 + 本表登记 + 随包分发完整许可文本。

`node scripts/verify-license.ts` 校验本表与源码/资产的一致性（CI 门禁
`pnpm run verify:license`）。

## 登记表

本表是机器可读的。`derived` 为路径前缀；`vendored` 为逐文件 SHA-256 摘要
（漂移即失败）。`license` 字段指向下方许可文本的章节 id。

```json
{
  "notices": [
    {
      "id": "omp",
      "upstream": "can1357/oh-my-pi",
      "spdx": "MIT",
      "copyright": "Copyright (c) 2025 Mario Zechner; Copyright (c) 2025-2026 Can Bölük; Copyright (c) 2026 Stencil Labs, Inc.",
      "upstreamVersion": "vendored 2026-08-18 (wechat bridge only; the theme defaults moved to the native opencode theme provider and the generated palette module was retired in 0.5.0)",
      "vendoredAt": "2026-08-18",
      "slugs": ["oh-my-pi"],
      "license": "MIT-OMP",
      "derived": [
        "src/wechat/index.ts",
        "src/wechat/core",
        "src/wechat/dsh"
      ],
      "vendored": []
    },
    {
      "id": "openclaw-weixin",
      "upstream": "Tencent/openclaw-weixin",
      "spdx": "MIT",
      "copyright": "Copyright (C) 2026 Tencent. All rights reserved.",
      "upstreamVersion": "channel 2.4.6 / client version 132102",
      "vendoredAt": "2026-08-18",
      "slugs": ["openclaw-weixin"],
      "license": "MIT-TENCENT",
      "derived": [
        "src/wechat/core"
      ],
      "vendored": []
    },
    {
      "id": "dsh-ecosystem-spec",
      "upstream": "T-Auto/dsh-ecosystem-spec",
      "spdx": "MIT",
      "copyright": "Copyright (c) 2026 dsh ecosystem community contributors",
      "upstreamVersion": "spec 0.15 / permissions 0.1",
      "vendoredAt": "2026-09-01",
      "slugs": ["dsh-ecosystem-spec"],
      "license": "MIT-DSH-SPEC",
      "derived": [
        "src/plugin-spec/registry-0.15.json",
        "src/plugin-spec/permissions-0.15.json",
        "src/plugin-spec/extensions-0.15.json"
      ],
      "vendored": [
        { "path": "vendor/dsh-ecosystem-spec/registry/registry-0.15.json", "sha256": "c3090dd129aadb06f87b56ad148dfbcec2ce4eed2404dda5eed9cf1dbae51f54" },
        { "path": "vendor/dsh-ecosystem-spec/registry/permissions-0.1.json", "sha256": "1e2cfeaa860936f1608cb8a8bffdf6343de6f513645eb98f6765d72157d5a1a7" },
        { "path": "vendor/dsh-ecosystem-spec/registry/contracts/decision-events-v1alpha1.json", "sha256": "56440dde1b00c210b22761a0cba139ce0a20207330567777cebe1e48b494ceb0" },
        { "path": "vendor/dsh-ecosystem-spec/registry/contracts/scene-v1alpha1.json", "sha256": "69ce3ae26d60dea2ed170376db8a1fb5860c94bd192c62681423c1d848ec2b26" },
        { "path": "vendor/dsh-ecosystem-spec/registry/contracts/settings-section-v1alpha1.json", "sha256": "685b0f17fe489f458e9b799811f61c42b858330584e95ecb97e7216b5be100ac" },
        { "path": "vendor/dsh-ecosystem-spec/registry/contracts/tui-channel-v1alpha1.json", "sha256": "2d0668656d999a8cacd363cd3c76207f9392118be8a83e6dd5f81b54ae063fe6" },
        { "path": "vendor/dsh-ecosystem-spec/protocols/tui-contributions.js", "sha256": "0d452c7d37f40debbb9e29c44cb6c1214693966f6a152a8b1e4185eac7a94716" },
        { "path": "vendor/dsh-ecosystem-spec/protocols/profile-definitions.js", "sha256": "2c0eead58688abaa71d468fa461bda3500cb2c899654128e4244eb661bf3a528" },
        { "path": "vendor/dsh-ecosystem-spec/conformance/fixtures/valid-plugin.json", "sha256": "118d3e46b00017f9ba7a150212d02005c78fd25ffc37ab1cbac016835d20f47e" },
        { "path": "vendor/dsh-ecosystem-spec/conformance/fixtures/valid-tui-contributions.json", "sha256": "d55b6a7c784da91e2bc72e0eda33fe30821f5c519b5e7118231ae27f6553d509" },
        { "path": "vendor/dsh-ecosystem-spec/conformance/fixtures/valid-private-protocol-plugin.json", "sha256": "4d68f9455698cef9d637db1f7148ce3c26232f9ab92f3ebc859988891cc9010e" },
        { "path": "vendor/dsh-ecosystem-spec/conformance/fixtures/waiting-authorization-plugin.json", "sha256": "b4f88c341ee851d2439f7ad508dd7b3fccc79468f1542d488b865bdc84fb55dc" },
        { "path": "vendor/dsh-ecosystem-spec/conformance/fixtures/invalid-plugin-unknown-coordinate.json", "sha256": "309c9b15c08d24224432a88f47551a74308aa9cde050e0fd1a221d7e71a66939" },
        { "path": "vendor/dsh-ecosystem-spec/conformance/fixtures/invalid-plugin-optional-no-fallback.json", "sha256": "0d5d34172bc0d80495aecc83f898f90de071487ae6b0e44cde661d1cecf9a467" },
        { "path": "vendor/dsh-ecosystem-spec/conformance/fixtures/invalid-plugin-client-facet.json", "sha256": "003a0cc9dd7334a1d7cdb81459a28363ccb37bf9505b45a537c4d4b698ece189" },
        { "path": "vendor/dsh-ecosystem-spec/conformance/fixtures/invalid-plugin-provides.json", "sha256": "491881e7b950d53f205fd82cc0f5c51e806ec34f7b04818688934675ec5b1565" }
      ]
    },
    {
      "id": "pi-tui",
      "upstream": "earendil-works/pi (npm @earendil-works/pi-tui)",
      "spdx": "MIT",
      "copyright": "Copyright (c) 2025 Mario Zechner",
      "upstreamVersion": "0.80.7",
      "vendoredAt": "2026-08-20",
      "slugs": ["pi-tui"],
      "license": "MIT-PI-TUI",
      "derived": [],
      "vendored": []
    },
    {
      "id": "turtle-ui",
      "upstream": "turtle1999/turtle-ui",
      "spdx": "BSD-3-Clause",
      "copyright": "Copyright (c) 2026, DeepSeek",
      "upstreamVersion": "upstream commit b08ed69",
      "vendoredAt": "2026-08-20",
      "slugs": ["turtle-ui"],
      "license": "BSD-3-TURTLE",
      "derived": [],
      "vendored": []
    },
    {
      "id": "opentui",
      "upstream": "anomalyco/opentui (npm @opentui/core, @opentui/solid, @opentui/keymap)",
      "spdx": "MIT",
      "copyright": "Copyright (c) 2025 opentui",
      "upstreamVersion": "0.6.6",
      "vendoredAt": "2026-10-16",
      "slugs": ["opentui"],
      "license": "MIT-OPENTUI",
      "derived": [],
      "vendored": []
    },
    {
      "id": "opencode",
      "upstream": "anomalyco/opencode (packages/tui)",
      "spdx": "MIT",
      "copyright": "Copyright (c) 2025 opencode",
      "upstreamVersion": "2.0.32 (commit 843a6c514e606b436a7fe713422ace0a93ad3d61)",
      "vendoredAt": "2026-10-19",
      "slugs": ["opencode"],
      "license": "MIT-OPENCODE",
      "derived": [
        "renderer/src/theme/core",
        "renderer/src/theme/native",
        "renderer/src/keymap/keymap.ts",
        "renderer/src/component/command-palette.tsx",
        "renderer/src/ui/select-controller.ts",
        "renderer/src/ui/dialog.tsx",
        "renderer/src/ui/dialog-select.tsx",
        "renderer/src/ui/dialog-forms.tsx",
        "renderer/src/ui/border.ts",
        "renderer/src/ui/layout.ts",
        "renderer/src/ui/toast.tsx",
        "renderer/src/ui/spinner.tsx",
        "renderer/src/ui/session-tabs.tsx",
        "renderer/src/ui/sidebar.tsx",
        "renderer/src/ui/pane-resize.tsx",
        "renderer/src/ui/subagent-dock.tsx",
        "renderer/src/ui/queued-dock.tsx",
        "renderer/src/ui/transcript.tsx",
        "renderer/src/ui/prompt-metadata.tsx",
        "renderer/src/ui/autocomplete.tsx",
        "renderer/src/ui/prompt-template.ts",
        "renderer/src/ui/home.tsx",
        "renderer/src/ui/markdown.tsx",
        "renderer/src/ui/scroll.ts",
        "renderer/src/clipboard.ts",
        "renderer/src/editor.ts",
        "renderer/src/attention.ts",
        "renderer/src/audio.ts",
        "renderer/src/storage.ts"
      ],
      "vendored": [
        { "path": "vendor/opencode/theme-v2-opencode.json", "sha256": "4a36ca0d0e886653ff3c5d3e8d837647bfc2c4efc809ec4f4fa50dd26b48a6f7" },
        { "path": "vendor/opencode/dialog.tsx", "sha256": "13bc807b4d64ada7aa2a621ebfecf6a956ea0dd4d82a17b72b99fc84c66a4a55" },
        { "path": "vendor/opencode/dialog-alert.tsx", "sha256": "f075fa8196e8d5f8e2a2ae7e854687b875892cef545fee0101898839b6029d61" },
        { "path": "vendor/opencode/dialog-confirm.tsx", "sha256": "90fdb74ed3220a07876f5258a9d29993cf881a3bd8788359895ce8fff059e2f2" },
        { "path": "vendor/opencode/dialog-prompt.tsx", "sha256": "9e031c1e9a740054f7728ca1cce69d7f3a92d73ef3f33c1d932c5458cb3b4095" },
        { "path": "vendor/opencode/dialog-select.tsx", "sha256": "2834c1c09ad4d70ec5c32955b4abb36bcec7f73ead4dbf044c5cd633cf922f71" },
        { "path": "vendor/opencode/select-controller.ts", "sha256": "b96c04d8eb20825a573c2bca378f6f78418bd51992730e1022bc756a37311940" },
        { "path": "vendor/opencode/keybind.ts", "sha256": "4a240fd4715da6776a811422edbcc3b05dcf8b7c0d008164f05c53aff7e7ad49" },
        { "path": "vendor/opencode/keymap.tsx", "sha256": "3cb1ea6d40c77eb69a8ff1245bd75aa7424485cfc401c8ea0023f270584a4c6b" },
        { "path": "renderer/src/assets/audio/bip-bop-01.mp3", "sha256": "129765d4203f92ecb36ba17553b037ebf4daf28ebb56013b3896d3e7e36f2d74" },
        { "path": "renderer/src/assets/audio/bip-bop-03.mp3", "sha256": "82b992e5dc5cfdc4d7206e0cd12d3132fa76ae30f8af51ec4cc216ba15f1afcd" },
        { "path": "renderer/src/assets/audio/staplebops-06.mp3", "sha256": "eb87d63312ac11b1ceb1a8b348057dfe4d1166d5a85dc79778fe69d458f4c097" },
        { "path": "renderer/src/assets/audio/nope-03.mp3", "sha256": "9832805f84dcdb4a8ccb46a98cc75def72b52509610837938ed8343b2537df0c" },
        { "path": "renderer/src/assets/audio/yup-01.mp3", "sha256": "b227d0516dfa1eda3b250635cce19e040af3f9cee443a8bb4b5a80990bca3f58" }
      ]
    }
  ]
}
```

### 关于 `opentui` 与 `opencode` 条目

- **`opentui` 是运行时依赖，不是派生代码。** 渲染器子进程的源码是本包原创，
  通过 import 使用 `@opentui/*`；import 一个 MIT 依赖不构成派生，所以 `derived`
  为空。但 `bun build --compile` 的单文件产物把 OpenTUI 的代码连同 Bun 运行时
  一起打进分发包，随包分发的产物里包含上游 MIT 代码，因此必须随包分发其许可
  文本（本节 `MIT-OPENTUI`）。Bun 运行时本身也是 MIT（`oven-sh/bun`），其许可
  文本随编译产物一并分发。
- **`opencode` 条目的 `derived` 是逐文件登记的。** 0.5.0 的渲染 shell、token 主题引擎、
  keymap、命令面板与对话框基座从 opencode v2 逐文件移植，每个移植文件落地时必须带
  `SPDX-License-Identifier: MIT` 与逐文件 provenance 头（写明上游文件与 upstream
  commit，并列出修改摘要），并加入本条目的 `derived` 前缀。门禁规则 5 会在文件声明派生
  却缺 SPDX 头时失败。`renderer/src/ui/text.ts` 的截断函数是本包自写（替换上游的
  `Locale.truncate`），不声明派生，因此不进 `derived`。
- **命名与背书边界**：本包不是 opencode 或 OpenTUI 的官方产品，不使用上游名称
  暗示背书；`dpsk` 启动器与 `my-dpsk-harness-tui` 包名是本包自己的名字。

## 许可文本

### MIT-OMP

```
MIT License

Copyright (c) 2025 Mario Zechner
Copyright (c) 2025-2026 Can Bölük
Copyright (c) 2026 Stencil Labs, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING, BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### MIT-TENCENT

```
Tencent is pleased to support the open source community by making
openclaw-weixin available.

Copyright (C) 2026 Tencent. All rights reserved.

openclaw-weixin is licensed under the MIT.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### MIT-DSH-SPEC

```
MIT License

Copyright (c) 2026 dsh ecosystem community contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### MIT-PI-TUI

```
MIT License

Copyright (c) 2025 Mario Zechner

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### BSD-3-TURTLE

```
BSD 3-Clause License

Copyright (c) 2026, DeepSeek

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
```

### MIT-OPENTUI

```
MIT License

Copyright (c) 2025 opentui

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### MIT-OPENCODE

```
MIT License

Copyright (c) 2025 opencode

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## 命名与背书边界

- 本包与 `opencode` / Anomaly、`OMP` / oh-my-pi、Pi、DeepSeek、Tencent 之间不存在
  隶属、赞助或背书关系。提及这些名称仅用于指代来源（nominative use）。
- 本包的 BSD-3-Clause 第 3 条禁止使用版权方或贡献者名义背书衍生产品；上游名称
  的商标权利归各自所有者。
- 本包标识（包名、bin 名、logo、徽章）不得使用 `opencode`、`OMP`、`Pi`、
  `DeepSeek` 作为标识。
