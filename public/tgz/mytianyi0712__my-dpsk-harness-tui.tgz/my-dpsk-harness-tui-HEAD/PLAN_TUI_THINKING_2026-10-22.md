# TUI 思考与工具呈现重构计划（2026-10-22）

> 目标：把现有“New designs”开关从“只多一个 `opencode2` 主题候选”改造成**思考/工具呈现方式**的开关；修复思考进行中仍显示 `Thought` 的问题；在开关打开时实现单块 `Thinking`、5–10 行动态预览、单行工具状态、点击展开/收起；同时修复思考/正文中偶发的局部文字背景异常（截图中的浅色底纹/小方块）、resume 切换对话后 Markdown 加粗标记（`**`）显示原文的问题，以及**每次启动留下空会话、会话按创建时间而不是最后交互时间排序**的问题；并保证关闭开关时完整保留当前老版 opencode 样式。
>
> 范围：本仓库的 renderer、TUI adapter、IPC mirror、测试与文档。**不修改 dsh 上游**，不发布、不打 tag、不 push。版本仍为 `0.5.0`（未发布）。

---

## 1. 现状核查：为什么“开关没感觉”

| 现象 | 代码事实 | 结论 |
|---|---|---|
| 开关打开/关闭几乎无变化 | `newDesigns` 只做两件事：`ThemeProvider` 的 `available()` 在 true 时把 `opencode2` 放进主题候选（`renderer/src/theme/provider.tsx:138-140`）；关闭且当前主题是 `opencode2` 时强制切回 `opencode`（`renderer/src/theme/provider.tsx:284-288`）。它**没有参与 transcript 渲染**。 | 开关当前是“主题候选开关”，不是“界面样式开关”。 |
| 设置页的开关文案歧义 | `/settings` 的 appearance 区只写了 `new designs: on/off`（`renderer/src/app.tsx:1305-1307`），旁边就是 theme / theme mode。用户自然期待它改变界面，但实际只有主题选择器多一项。 | 需要改文案并把语义落到 transcript。 |
| 思考进行中也显示 `Thought` | `ReasoningRow.title()` 无条件写 `Thought`（`renderer/src/ui/transcript.tsx:303-309`）。只有 `streaming && reasoning 为空` 时才显示 spinner（`transcript.tsx:318-322`）；一旦有 reasoning 文本，标题立刻变成 `Thought`。 | 这是本次要修的第 3 项。 |
| 没有“一个思考块” | 每个 `assistant` / `tool` 行独立渲染；多段 reasoning 会得到多个 `Thought` 头，工具行与思考行并列。 | 需要渲染层分组，而不是继续堆单行。 |
| 点击展开没有接线 | 思考头是一个普通 `box`，没有 `onMouseUp`/`onMouseDown`；`toggleReasoning` 只有 store 内部和测试调用（`renderer/src/app.tsx:473-480`、`app.test.tsx:1841`）。 | 需要真正的鼠标命中区，并补 frame 测试。 |
| 思考时长只在落盘后出现 | `durationMs` 来自 `assistant/message` 的 `event.time - step/start`（`src/host/transcript-events.ts:254-268`）；流式行由 `agent/assistant-stream` 临时拼出来，**没有 `createdAt`**（`src/index.ts:3662-3679`）。 | 实时“Thinking 12s”没有时间基准，需要 host 补时间戳或渲染层本地计时。 |
| 工具行没有“思考区内单行”概念 | 所有工具走 `InlineToolRow` / `BlockToolRow`；`text.muted`、`$ cmd`、块卡片输出。 | 新样式需要一层“思考区内工具的紧凑投影”，展开后再回到这些旧组件。 |
| 思考/正文偶发局部浅色底纹或小方块 | 已用 `mockMouse.drag` 在 test harness 复现：选中 Markdown 文本后，`captureSpans()` 中被选中 span 的 `bg` 从页面底色变成 `text.base`（`#cdd6f4`）；`mockMouse.click` 会留下零长度 selection（`getSelectedText() === ''`），而应用没有任何代码清理它。`selectable={false}` 加在 `<markdown>` 上**不会**阻止其子 `TextRenderable` 被选中。 | 高概率是**文本选择高亮 + 选择未清理**，不是 Markdown 语法色或主题 token 泄漏。需要从选择生命周期和选择配色两头修。 |
| resume 切换对话后加粗显示 `**` 原文 | 已复现：resumed snapshot 的长回答包含 `- 一般比 Windows 低 **5%~15%**…` 时，帧里保留 `**`；用静态 `syntaxStyle` 的简单 box 用例可隐藏标记，transcript/scrollbox 仍失败。另一条独立线索：`transcriptEvents` 把多个 text block 用 `\n\n` 连接（`src/host/transcript-events.ts`），若 `**` 跨 block，会拼成 `**加粗\n\n文字**`；marked 不承认跨段强调，也会保留 `**`。 | 有两个来源：**host 拼接打断跨段强调** + **OpenTUI 0.5.17 列表项内联强调的 conceal 缺陷**。需要分别修，不能只靠换主题。 |
| 每次启动都留下空会话 | `TuiStartup` 为 bare launch mint 一个 `tui-<uuid>`（`src/startup.ts:55-57`）；agent-loop 在启动时 `persistence.create` 并追加 setup events，把会话 materialize 到盘上。实机 `.dsh/sessions/.../tui-*/session.v4.jsonl.zstd` 只有 4 个 setup events（`session` / `permission/preset` / `sandbox/mode` / `approval/policy`），没有 `user/message`、`assistant/message` 或 `tool/call`。renderer 只是用 `blank` 隐藏行（`app.tsx:2032-2033`），文件仍在。 | 不是显示问题，是**启动即持久化**。需要在第一个 user message 之前不创建/不 materialize 存储会话；单纯隐藏不能阻止累积。 |
| 会话按创建时间排序 | host `pushSessionList` 用 `source.header.createdAt` 排序（`src/index.ts:2616`）；host `/resume` picker 同样（`src/index.ts:1473`）；renderer 的 today/yesterday 分组也用 `createdAt`（`app.tsx:2052-2055`）。`SessionHeader` 只有 `createdAt`，没有 `lastActivityAt`。 | 需要新增“最后交互时间”，在 host 算好并随 `session-list` 下发；renderer 只消费，不自己猜。 |

**核心判断**：这次不是“给现有 ReasoningRow 换个标题”，而是新增一个**思考块视图模型 + 分组渲染层**；`newDesigns` 只作为该层的开关。老版路径必须原样保留（除 `Thinking` 文案修复外）。

---

## 2. 目标与非目标

### 2.1 目标

- **G1 开关真正生效**：`newDesigns` 打开 = 新版思考/工具呈现；关闭 = 当前老版 opencode 呈现。切换即时生效，不需要重启，不需要重放日志。
- **G2 老版保留**：关闭时，现有用户卡片、回答、思考头、gutter、工具卡片、footer 的视觉不变；只修 `Thinking` 文案和补点击。
- **G3 修复 `Thinking`/`Thought`**：模型尚未输出正文时，标题必须是 `Thinking`；正文开始/思考结束后才是 `Thought`。
- **G4 单块合并**：以“模型是否输出正文”为唯一分块标准。正文之前的多段 reasoning、多个工具调用、连续的工具状态更新，合并到**一个** `Thinking` 标签下。
- **G5 新版预览**：正文之前，思考内容在一个 **5–10 行动态区域**内滚动显示（自动跟随最新内容）；区内工具默认单行：`Running: 工具名 参数` / `Done: ...` / `Failed: ...`，超宽用 `...` 截断。
- **G6 展开/收起**：点击 `Thinking`/`Thought` 标签展开；展开后回到 opencode 默认的思考展开样式（`┃` gutter + Markdown + 正常工具行/工具卡片）。再点收起。
- **G7 标签格式**：进行中 `Thinking 12s | Used 2 Tools`；结束 `Thought 1m 05s | Used 2 Tools`；无工具时省略 `| Used ...`；不足 1 分钟不显示 `m`。
- **G8 可验证**：新增纯函数单测 + 真实 char-frame 测试；覆盖 40/80/120 列、CJK、长参数、失败/拒绝、打断、设置切换。
- **G9 选择高亮不再变成异常背景**：单击不留下小方块；拖选使用主题选择色（或明确禁用 Markdown 拖选，复制走既有动作）；提交、切换会话、开启新一轮时清理选择。思考和正文都不再出现截图中的局部底纹。
- **G10 resume 后 Markdown 标记不泄漏**：resume/切换对话后的 snapshot 与实时流式对同一段文本渲染一致；列表项、段落、思考正文里的 `**加粗**` 不再显示 `**`；跨 text block 的加粗不因 host 的 `\n\n` 拼接被拆坏。
- **G11 无交流的会话不落盘**：启动 TUI、resume/切换旧会话、`/new` 后不发送消息、退出 TUI，都不应新增一个可恢复的空会话文件；第一个 user message 才是会话的持久化起点。已有的历史空会话要隐藏/清理，但不误删真实会话。
- **G12 会话按最后交互时间排序**：TUI 会话列表、`/sessions` 选择器、host `/resume` picker、today/yesterday 分组都按 `lastActivityAt` 排序；缺失时回退 `createdAt`。刚用过的旧会话要回到顶部/今天分组。

### 2.2 非目标

- 不修改 dsh 上游事件生产、session log schema 或模型调用逻辑。
- 不在本次引入“可手动滚动的思考小窗”。新版预览是**自动尾随**的 5–10 行窗口；要看完整内容用点击展开。这样可以避开嵌套 `scrollbox` 的滚轮/焦点冲突。
- 不做思考块内的逐工具展开/折叠；只有整块展开/收起。
- 不把 `Thinking`/`Thought`/`Running` 等标签接入 zh/en 字典（本轮先保持与 opencode 一致的英文标签；后续可加 `rendererThinking` 等键）。
- 不改新版预览的 Markdown 渲染能力：预览是纯文本/单行投影，展开后才是完整 Markdown。
- 不重写整个 Markdown 渲染器：W9 优先升级 OpenTUI 或定点 `renderNode`；文本规范化只作最后兜底。

---

## 3. 设计决策（已给出推荐，需用户确认的见第 10 节）

### D1. `newDesigns` 的语义

保留持久化键 `newDesigns`（避免配置迁移），但把它解释为：

```text
newDesigns = false  → classic：当前老版 opencode 思考/工具呈现
newDesigns = true   → compact：新版单块 Thinking + 5–10 行预览 + 单行工具
```

默认 `false`，与用户“我很喜欢老版样式”的偏好一致。

### D2. 与主题解耦

`newDesigns` **不再控制 `opencode2` 的可用性**。`opencode2` 始终作为普通主题出现在主题选择器里；打开/关闭思考样式不会改当前主题，也不会把 `opencode2` 强制切回 `opencode`。

理由：用户要的是“思考/工具显示方式”，不是“换主题”。把两者绑在一起会让开关继续产生“我明明只想改思考样式，主题却被改了”的副作用。

备选（若用户坚持保留旧行为）：`newDesigns` 同时控制 `opencode2` 候选和新版思考样式；此时关闭开关若当前主题是 `opencode2`，仍强制回 `opencode`。本计划默认采用解耦方案。

### D3. 单块边界：正文

- `assistant` 行的 `text.trim() !== ''` 视为“正文开始”。
- 正文之前：该 turn 内所有 `assistant` 的 reasoning 段、所有 `tool` 行都属于同一个思考块。
- 正文之后：本 turn 后续若还有 reasoning/tool，走 classic 行，不再新建思考块。
- 新的 `user` 行或 turn 变化：结束当前块并重置“正文已出现”状态；下一轮可以重新产生思考块。
- `system` 行：作为边界结束当前块（避免块的内容跨过一条系统提示后仍显示在提示上方），但不重置“正文已出现”以外的 turn 语义。实际实现中 system 行很少出现在 turn 中间；按边界处理最安全。

### D4. 新版默认态与点击态

每个思考块有三种呈现状态：

| 状态 | 触发 | 表现 |
|---|---|---|
| `preview`（默认，仅思考中） | 正文未出现、`showReasoning !== false`、用户未手动收起 | 标签 + 5–10 行动态预览 |
| `detail`（用户点击展开） | 用户点标签 | 标签 + opencode 默认展开样式（完整 reasoning + 正常工具行） |
| `closed`（默认，思考结束） | 正文出现后自动进入；或用户在 detail 态再点标签 | 仅标签一行 |

点击状态机（按 block id 记忆）：

```text
resolved = userState[id] === 'detail' ? detail
         : userState[id] === 'closed' ? closed
         : (phase === thinking && showReasoning ? preview : closed)

点击：
  detail  -> closed
  其它    -> detail
```

- 用户一旦手动进入 `detail`，正文出现后**不强制收起**（尊重用户正在阅读）。
- 用户没有手动操作时，正文出现会把 `preview` 自动切到 `closed`。
- `showReasoning: false` 时，思考中默认 `closed`（只看标签），不显示预览；点击仍可展开。
- 关闭 `newDesigns` 时，新状态集合保留但不再使用；重新打开可恢复用户之前的展开选择。

### D5. 展开后的“opencode 默认样式”

展开态不是把预览放大，而是：

- 一个思考块标签；
- 按时间顺序渲染块内成员：
  - `assistant` 的 reasoning：用现有 `┃` gutter + `MarkdownText`（muted syntax），每段一个 body，段间留白；
  - `tool`：用现有 `InlineToolRow` / `BlockToolRow`（含输出/diff/error）；
  - 正文 `assistant` 行：正文仍由该行自己的 `AssistantRow` 渲染，不在块内重复。
- 也就是说：**一个标签，下面按原顺序是经典的思考正文和经典工具卡片**。

这样既满足“多段思考合并到一个标签下”，又满足“展开后还原 opencode 默认样式”。

### D6. 思考时长

- 起点：块内最早的“步骤开始”时间。
  - `assistant` 行：`createdAt - durationMs`（durable 行已有这两个字段，能反推出 step 开始）；流式行用 `createdAt`。
  - `tool` 行：`createdAt`（tool/call 时间）。
- 终点：
  - 正文行有 `bodyAt` 用 `bodyAt`；否则用正文 durable 行的 `createdAt`（消息完成时间，回放时略高估）。
  - 无正文（被打断/仅工具）用块内最后一个已知完成时间；没有就省略时长。
  - 思考中：`now - startedAt`，1 秒一跳。
- 时长缺失或 `<= 0`：只显示 `Thinking` / `Thought`，不显示 `0s`。
- 回放与实时可能相差“正文生成耗时”；这是可接受的近似，文档中写明。若要求严格一致，需要 host 把 `bodyAt` 写进 session log（本轮不做）。

### D7. 标签格式

```text
进行中，有工具：  Thinking 12s | Used 2 Tools
进行中，无工具：  Thinking 12s
结束，有工具：    Thought 1m 05s | Used 3 Tools
结束，无工具：    Thought 42s
1 个工具：        Thought 42s | Used 1 Tool
无时长：          Thinking | Used 1 Tool
```

- 不足 60 秒：只显示 `Ns`（例如 `42s`）。
- 满 60 秒：`Xm YYs`（例如 `1m 05s`、`12m 30s`）；秒数补两位，宽度稳定。
- 超过 59 分钟：仍用总分钟数（`61m 05s`），不引入 `h`。
- 前缀折叠标记：展开/预览 `-`，收起 `+`；与 classic 一致。
- 思考中在标记后加 spinner：`- ⠋ Thinking 12s | Used 2 Tools`；`animations: false` 时为 `⋯`。
- 无工具时**不显示** ` | Used 0 Tools`。
- 宽度不足时先省略 ` | Used ...`，再压缩/截断时长与标签；不要把 CJK 或单词截成半个。

### D8. 单行工具格式

| 状态 | 文案 | 颜色 |
|---|---|---|
| `pending` | `Running: Read src/app.tsx` | 前缀 warning，参数 muted |
| `ok` | `Done: Read src/app.tsx` | 前缀/参数都用 muted（安静） |
| `failed` | `Failed: Read src/missing.ts` | 整行 error |
| `denied` | `Denied: Read src/secret.ts` | 整行 error |

规则：

- 工具名用现有 `toolDisplay(row).title`（`Read` / `Glob` / `Grep` / `Shell` / `Edit` / `Write` / `Subagent` / `WebFetch` / `Web Search` / 原始名）。
- 参数用现有 `toolDetail()` 的结果；把换行压成空格，去掉多余空白。
- 整行按可用宽度截断，末尾用 **`...`**（三个 ASCII 点，符合用户示例），不是 `…`。
- 截断按终端 cell 宽度（CJK 2 格），不能出现半个汉字。
- 失败/拒绝的完整错误不放进单行；展开后在经典工具行里看。
- 工具调用一出现就计数；结果更新只改同一行状态，不重复计数。

### D9. 预览区几何

- 只在 `phase === thinking` 且解析状态为 `preview` 时出现。
- 预览内容 = 块内按时间顺序的 reasoning 文本行 + 工具单行。
- 内容为 0 时不占行；内容非空时高度 = `clamp(内容行数, 5, 10)`。
- 内容少于 5 行时，顶部对齐，下面补空行到 5 行；超过 10 行时显示**最后 10 行**（自动尾随）。
- 不做嵌套 `scrollbox`，不显示滚动条；行数由预计算决定，渲染时每行 `wrapMode="none"`。
- reasoning 文本先做轻量 Markdown 去噪（标题 `#`、`**`、行内反引号、fence 行、列表前缀），再按 cell 宽度换行；展开态仍是完整 Markdown。
- 预览缩进：标签下方再缩进 2 格；颜色 `text.muted`，工具前缀按 D8 着色。

### D10. 文本选择策略

截图中的“局部背景色”按文本选择处理，而不是按 Markdown token 处理。策略：

- **保留拖选**用于复制；但选择必须有明确主题色，不能使用 OpenTUI 的“前景色当背景”默认回退。
- **单击（零长度选择）必须清理**：不留下小方块。
- **提交、切换会话、开启新一轮**时清理选择；流式更新中不主动清除非空选择，避免打断用户复制。
- 如果 Markdown 子 renderable 无法可靠设置选择色，则退化为：**禁用 Markdown 内容的选择**（仍然保留纯文本行/工具输出的选择），复制最后一条回答继续走 `leader y`。这一项在 W8 的 spike 后二选一，交给用户确认。

---

## 4. 视觉规格

### 4.1 classic（newDesigns = false）

保持现状，只修标题词和加点击：

```text
- Thinking: Checks
┃ first step
┃ const x = 1

   the answer

standard · mimo-v2.6-pro · 3.2s · 42.0 tok/s
```

结束后（落盘后才有 `durationMs`）：

```text
+ Thought: Checks · 0.8s
```

- 思考中（`streaming` 且正文为空）显示 `Thinking`；正文出现或行落盘后显示 `Thought`。
- 空 reasoning 的流式行如果已经有正文，不再画空的 `Thought` 头（`TranscriptRow` 的显示条件一并收紧）。
- 本节只改词和点击，不给非空的经典思考头新增 inline spinner；空思考头仍沿用现有 spinner。
- 点击标题行切换 `+` / `-`（保留现有 `collapsedReasoning` 语义）。
- 不动 `┃` gutter、muted Markdown、警告色 60%/100% 的现有规则。

### 4.2 新版思考中（newDesigns = true，默认 preview）

```text
- ⠋ Thinking 12s | Used 2 Tools
  The transcript merges rows by id, so I need to
  check the grouping boundary before painting.
  Running: Read renderer/src/ui/transcript.tsx
  Done: Grep "ReasoningRow"

   the answer is still streaming…
```

- 只有一个 `Thinking` 标签；多段 reasoning 与工具都在同一个 5–10 行窗口里。
- 预览窗口在标签下方，缩进 2 格；内容超过窗口时保留最新的行（顶部旧行被滚掉）。
- 正文一出现，标签变 `Thought`，预览自动收起，正文开始渲染。

### 4.3 新版思考结束（默认 closed）

```text
+ Thought 1m 05s | Used 3 Tools

   the answer

standard · mimo-v2.6-pro · 3.2s · 42.0 tok/s
```

- 默认只留一行标签，给正文让出空间。
- 点击标签展开。

### 4.4 新版展开（detail）

```text
- Thought 1m 05s | Used 3 Tools
┃ **Checks**
┃
┃ first step
┃
┃ ```ts
┃ const x = 1
┃ ```

→ Read renderer/src/ui/transcript.tsx

$ npm run check
> tsc
ok
```

- 一个标签；下面按时间顺序是完整 reasoning body 和经典工具行/卡片。
- 工具卡片恢复 `$ cmd`、输出尾部预算、diff、错误等现有行为。
- 再点标签收起为一行。

### 4.5 宽度/缩进

- 标签与 classic 一样从 `CONTENT_INDENT = 3` 开始。
- 预览内容再缩进 2 格。
- 所有行右边界留 1 格；超宽先换行（reasoning）或 `...` 截断（工具行）。
- 40 列下：标签允许被截断为 `- Thinking 12s | ...`；预览工具行必须能显示至少 `Running: Read` 这类前缀，参数可被截掉。

### 4.6 局部文字背景异常（本轮新增）

**现象**（用户截图）：

- 思考正文或回答正文中，某些整行文字出现比页面略亮的浅色底纹；同一段里其余行正常。
- 行尾偶尔出现一个小方块；滚动/继续流式后仍可能保留。
- 思考和正文都可能出现，没有固定的 Markdown 结构。

**test harness 复现**：

```text
mockMouse.drag(5, answerLine0, 30, answerLine3)
  -> renderer.getSelection().getSelectedText() 非空
  -> captureSpans() 中被选中 span 的 bg = #cdd6f4（text.base），而不是 background.base
mockMouse.click(30, answerLine0)
  -> getSelectedText() === ''，selection 仍然存在（零长度）
  -> 应用没有 clearSelection 调用
```

`selectable={false}` 加在 `<markdown>` 上经实测**不会**阻止其子 `TextRenderable` 被选中，所以不能只在 Markdown 根节点上关闭选择。

**根因判断**：

1. OpenTUI 的文本选择在没有显式 `selectionBg` 时，会用前景色填充被选中的 cell（或至少 test harness 的 span bg 如此），于是出现一条浅色带；
2. 单击会创建一个零长度的 selection，应用只在 Ctrl+C / dialog 路径清理，普通点击/提交/切换会话都不清理，于是小方块和残留底纹留在屏上；
3. 流式 Markdown 会重建子 renderable，旧选择可能继续作用在新文本上，形成“随机位置”的底纹。

**修复方向**（W8 详述）：

- **P0 生命周期**：单击（零长度）立即 `clearSelection()`；提交/切换会话/新一轮开始时清理；不主动清除非空选择。
- **P1 配色**：给 transcript 的文本/Markdown 子 renderable 设置主题化 `selectionBg` / `selectionFg`；如果 Markdown 子 renderable 无法可靠配色，则关闭 Markdown 内容的选择（保留纯文本行选择）。
- **P2 回归**：点击、拖选、提交、切换、流式更新五个场景的 char-frame/selection 断言；实机确认思考和正文都不再出现截图中的底纹。

### 4.7 resume 后 Markdown 加粗标记泄漏（本轮新增）

**现象**（用户截图）：

- 从历史 resume/切换会话后，回答里的列表项和段落出现 `**5%~15%**`、`**A 卡 + 单机/Steam 联机**`、`**5.33%**` 等原文标记。
- 标题（`##`）和列表符号仍被渲染；只在 resume 后出现，实时流式通常正常。
- 同一段文本里有的加粗正常、有的显示 `**`，位置不固定。

**两条独立线索**：

1. **host 拼接打断跨 block 强调**：`transcriptEvents` 把 `assistant/message` 的多个 text block 用 `\n\n` 连接（`src/host/transcript-events.ts` 的 `blocks.filter(text).map(...).join('\n\n')`）。如果模型把 `**加粗` 和 `文字**` 放在两个 block，resume 会得到 `**加粗\n\n文字**`；CommonMark/marked 不允许强调跨空行，于是 `**` 作为字面量留下。实时路径是 chunk 顺序拼接，不会插入空行，所以实时正常。
2. **OpenTUI 列表项内联强调的 conceal 缺陷**：同样的 `- 一般比 Windows 低 **5%~15%**…`，直接 `<markdown>`（相同 syntax style）能隐藏 `**`；经过 `MarkdownText` + transcript/scrollbox 后仍显示。test harness 已复现；把 `syntaxStyle` 提前求值成对象能修一部分直接用例，但 shell 里仍失败，说明列表项子 renderable 的 conceal/样式绑定还有问题。

**修复方向**（W9 详述）：

- **Host 侧**：新增 `joinTextBlocks()`，只在强调/代码 span 已闭合时使用 `\n\n`；检测到未闭合的 `**`、`*`、`` ` `` 时用 `\n` 或空串续接。加纯函数测试，覆盖跨 block 加粗、跨 block 行内代码、正常多段。
- **Renderer 侧**：先做 OpenTUI 0.5.17 → 0.6.6 的升级 spike；若列表项仍泄漏，使用 `renderNode` 定制列表项内联渲染（应用 bold 属性并隐藏标记），或在 `MarkdownText` 前做列表项规范化。不要用“全局删掉 `**`”这种会破坏正常加粗的方案。
- **验收**：同一段包含 `- **bold**` 的 assistant 文本，实时流式帧与 resume snapshot 帧一致；两者都不含 `**`；加粗 span 仍带 bold 属性；跨 block 的加粗在 host 拼接后仍是一个完整强调。

### 4.8 每次启动留下空会话（本轮新增）

**现象**：

- 每次 `dpsk` 启动都会新建一个 `tui-<uuid>` 会话；即使用户马上 resume 旧会话，这个空会话仍留在 `.dsh/sessions` 里。
- 空会话没有 user/assistant/tool 事件，只有 4 条 setup 事件；在 `/resume` 或桌面会话列表里表现为 "New Session" 垃圾行。
- renderer 的 `blank` 过滤只隐藏列表行，不删除文件，也不能阻止下次再生成一个。

**实机证据**：

```text
.dsh/sessions/--C-Users-mytianyi--/tui-c854149d-.../session.v4.jsonl.zstd
  events = 4
  session, permission/preset, sandbox/mode, approval/policy
  no user/message, assistant/message, tool/call
```

**根因**：

- `TuiStartup` 在 bare launch 时 mint 一个 session id；
- agent-loop 在启动时 `sessionPersistence.create`，并在 publish 时 `appendUnstoredSuffix` 写入 setup events；
- 后端在第一次物理 append / close 时 materialize，于是空会话落盘；
- 关闭/切换时 `close()` 还会完成 pending durability，进一步保证它留下。

**修复方向**（W10 详述）：

- **首选：lazy session creation**。启动时只挂 Home/空壳 UI，不创建 agent/session；第一个 `send-message` 才 `ctx.agents.create` 并提交。这样“打开就 resume”不会产生任何新会话。
- **备选：LazySessionPersistence 装饰器**。拦截 `sessionPersistence.create`，把 setup events 和 handle 缓冲起来；第一个 conversation event 才真正 create/append；在 conversation 之前 `close()`/`flush()` 直接丢弃。风险是服务覆盖顺序和 agent-loop 对 `list`/`stat` 的预期。
- **短期兜底**：host `/resume` 过滤 `blank`；启动时清理历史 4-event 空 `tui-*` 目录（只删确认无 conversation 的）。这只能止血，不能阻止新空会话。

**验收**：

- 启动 → 退出（不发送）：`.dsh/sessions` 不新增目录。
- 启动 → resume 旧会话 → 发送：只更新旧会话，不新增空会话。
- 启动 → `--session <id>` → 不发送 → 退出：不新增该 id 的会话；发送第一条后才出现。
- 启动 → `/new` → 不发送 → 再切换：不新增可恢复空会话。
- 启动 → 发送第一条消息：恰好新增一个会话，且第一条 `user/message` 在其中。

### 4.9 会话按最后交互时间排序（本轮新增）

**现象**：

- 会话列表、`/sessions`、`/resume` picker 都按创建时间排；刚用过的旧会话仍沉在下面。
- renderer 的 today/yesterday 分组也按创建时间，导致今天用过的旧会话仍归在 "older"。

**现状**：

- `SessionHeader` 只有 `createdAt`（dsh 的 immutable header），没有 `updatedAt`/`lastActivityAt`。
- host `pushSessionList` 用 `header.createdAt` 排序；host `/resume` 用 `header.createdAt` 排序；renderer 的 `openSessionRows` 用 `session.createdAt` 分组。
- 最后交互时间只能从**最后一条 session event 的 `time`** 或**存储文件 mtime** 派生，不能从 header 直接读。

**修复方向**（W11 详述）：

- 新增 `lastActivityAt`，随 `SessionListPayload` 下发；host 统一排序，renderer 只消费。
- live session 用 `session.eventAt(session.seq - 1)?.time`；持久化 session 用 persistence snapshot 的 `eventCount` 读最后一条 event，失败则退回文件 mtime，再退回 `createdAt`。
- 用 `revision` 缓存每个 session 的 `lastActivityAt`，避免每次列表刷新都读全量日志。
- `/resume` picker 与 `pushSessionList` 共用同一个排序函数；renderer 的 today/yesterday 分组改用 `lastActivityAt ?? createdAt`。

**验收**：

- 创建时间 A < B < C，最后交互 C < A < B 时，列表顺序为 C、A、B。
- 刚用过的旧会话回到顶部/今天分组；空会话仍被隐藏。
- 没有 `lastActivityAt` 的旧数据回退 `createdAt`，不崩、不出现 `NaN`。

---

## 5. 技术方案

### 5.1 数据模型

新增纯视图模型（不进入协议角色）：

```ts
type ThinkingPhase = 'thinking' | 'thought'

interface ThinkingBlockView {
  readonly id: string                 // = leaderId（稳定）
  readonly leaderId: string           // 块内第一行的 id
  readonly rows: readonly TranscriptEvent[]
  readonly phase: ThinkingPhase
  readonly toolCount: number
  readonly startedAt?: number
  readonly endedAt?: number
  readonly bodyId?: string            // 正文行 id（如果有）
}

interface ThinkingRowBinding {
  readonly blockId: string
  readonly leader: boolean
}

interface ThinkingPlan {
  readonly blocks: ReadonlyMap<string, ThinkingBlockView>
  readonly byRow: ReadonlyMap<string, ThinkingRowBinding>
}
```

- **不新增 transcript role**。思考块是渲染层对现有 `assistant` / `tool` 行的投影。
- `TranscriptEvent` 增加一个可选字段 `bodyAt?: number`（正文首字符时间）；`createdAt` 已存在，只需给流式行补上。
- `ThinkingBlockView.id` 直接用 leader 行 id：流式行 re-key 时 host 保持同一个 streamed id（现有逻辑），所以 id 稳定，点击状态不会因落盘丢失。

### 5.2 分组算法

纯函数 `planThinking(rows, options)`：

```text
open: MutableBlock | undefined
bodySeen = false
turn = undefined

for row of rows:
  if row.turn !== undefined && turn !== undefined && row.turn !== turn:
    close(open, live=false); open = undefined; bodySeen = false
  turn = row.turn ?? turn

  if row.role === 'user':
    close(open, live=false); open = undefined; bodySeen = false
    continue

  if row.role === 'system':
    close(open, live=false); open = undefined
    continue

  if bodySeen:
    continue                         // 本 turn 正文已出现：后续一律 classic

  if row.role === 'assistant':
    hasText = row.text?.trim() !== ''
    // 注意：不能只用 streaming 判断，否则“纯正文流式行”会多出一个空的 Thought 头。
    hasReasoning = (row.reasoning ?? '').trim() !== ''
    // `reasoning !== undefined` 区分“reasoning 先到、内容还没到”与“纯正文流”。
    waiting = row.streaming === true && !hasText && row.reasoning !== undefined && !hasReasoning
    mayThink = hasReasoning || waiting
    if mayThink:
      open ??= start(row)
      attach(open, row)
    if hasText:
      if open !== undefined:
        open.bodyId = row.id
        close(open, live=true)
        open = undefined
      bodySeen = true
    continue

  if row.role === 'tool':
    open ??= start(row)              // 工具先于任何 reasoning 也归入思考块
    attach(open, row)
```

`close(block, live)`：

```text
phase =
  block.bodyId !== undefined ? 'thought'
  : (live && (running || anyStreaming(block) || anyToolPending(block))) ? 'thinking'
  : 'thought'
startedAt = min(startOf(row) for row in block.rows)
endedAt = body ? (body.bodyAt ?? body.createdAt) : lastCompletion(block)
```

`startOf(row)`：

```text
if row.createdAt === undefined: undefined
if row.role === 'assistant' && row.durationMs > 0: row.createdAt - row.durationMs
else: row.createdAt
```

边界情况：

- **只有工具、没有 reasoning**：工具行先出现也会建立思考块；标签显示 `Thinking ... | Used 1 Tool`，预览只有工具行。
- **单行同时有 reasoning + text**：该行是 leader；块渲染在正文前，正文由该行自己的 `AssistantRow` 渲染。
- **正文行前面已有块**：正文行加入块（如果它有 reasoning），然后立即关闭；块上下文由 leader 渲染，正文行渲染自己的 text。
- **正文行没有 reasoning**：不加入块，只触发 `bodySeen` 和关闭。
- **纯正文流式行**：`streaming: true`、`text` 非空、没有 reasoning → **不建块**。否则每条普通回答都会多出一个空的 `Thought` 头。只有“有 reasoning”或“还在等第一段 reasoning/正文（text 为空）”才建立思考块。
- **先有块、正文行无 reasoning**：正文行不加入块；块在正文行关闭，正文行照常渲染 text。
- **打断/错误**：没有正文，`live` 关闭时 phase = thought；footer 仍由最后一行自己显示。
- **多个 turn**：user 行或 turn 变化重置；正常情况下每个 turn 最多一个思考块。
- **system 行**：结束当前块（不合并跨系统提示的内容），但不设置 `bodySeen`；system 之后如果还有 reasoning，可开新块。因此一个 turn 被 system 行切开时，允许出现两个块；这是有意的边界，不把系统提示夹在块的时间线中间。
- **历史快照**：没有 `streaming`、没有 pending、`turnRunning=false`，所有块 phase=thought。

### 5.3 行渲染接线

现有 `<For each={store.transcript()}>` **保持不变**，不改成嵌套分组列表。每个 `Row` 只读取自己的 binding：

- `leader`：
  - `assistant`：先渲染 `<ThinkingBlock>`，再渲染自己的 `AssistantRow`（如果有正文/footer/error）。
  - `tool`：只渲染 `<ThinkingBlock>`；工具本身由块在展开态渲染，预览态渲染单行。
- 非 leader：
  - `assistant`：不渲染 reasoning；如果 `text`/`footer`/`error` 存在，渲染 `AssistantRow`；否则渲染 `null`。
  - `tool`：渲染 `null`（已被块吸收）。
- 不在任何块里的行：完全走现有逻辑。

补充：非 leader 的 `assistant` 行即使有 reasoning，也只渲染 `AssistantRow`（text/footer/error），不渲染 `ReasoningRow`；它的 reasoning 已经由块的 detail 展示。这样不会出现“块里一份、行上一份”的重复。

这样做的原因：

- `<For>` 的 item identity 不变；流式 delta 仍然只更新行内字段，不会重建整行/Markdown。
- 思考块放在 leader 的位置，天然保持“块出现在第一次思考/工具的位置”。
- 非 leader 的正文行仍按自己的位置渲染，所以“块摘要在上、正文在下”的顺序正确。

### 5.4 组件拆分（`renderer/src/ui/transcript.tsx`）

从现有组件中抽出可复用部分：

- `ReasoningBody({ text, streaming, store, palette })`：现有 `┃` gutter + `MarkdownText`（muted syntax）。
- `ToolRow({ row, store, palette })`：现有 `toolDisplay` → `InlineToolRow` / `BlockToolRow` 的分发。
- `ReasoningRow`：保留 classic 单行头 + 可点击 + 修 `Thinking`/`Thought`；body 用 `ReasoningBody`。
- 新增 `ThinkingBlock`：
  - `ThinkingHeader`：marker、spinner、label、duration、tools；点击/悬停。
  - `ThinkingPreview`：5–10 行纯文本窗口。
  - `ThinkingDetail`：按 `block.rows` 顺序渲染 `ReasoningBody` 和 `ToolRow`。
- `ThinkingDetail` 直接复用整行组件（它们自带 `CONTENT_INDENT` / `marginTop`），**不要**再包一层 `CONTENT_INDENT`；header 和 preview 各自加自己的缩进，避免双缩进。
- `TranscriptRow` 新增可选 prop：

```ts
thinking?: {
  readonly block: ThinkingBlockView
  readonly leader: boolean
  readonly mode: 'preview' | 'detail' | 'closed'
  readonly onToggle: () => void
}
```

具体分支：

```text
assistant + block:
  {leader ? <ThinkingBlock/> : null}
  {block === undefined ? <ReasoningRow/> : null}
  {row.text || row.footer || row.error ? <AssistantRow/> : null}

tool + block:
  {leader ? <ThinkingBlock/> : null}
  （非 leader 返回 null）
```

### 5.5 Store / 设置接线

在 `AppStore` / `RowStore` 增加：

```ts
newThinkingStyle: () => boolean            // settings().newDesigns === true
thinkingMode: (id) => 'detail' | 'closed' | undefined
toggleThinking: (id) => void
showReasoning: () => boolean               // 复用 settings().showReasoning
```

- `thinkingMode` 用不可变 `Record<string, 'detail' | 'closed'>` 信号实现；每次写入替换对象，Solid 才能看到新引用。
- `toggleThinking(id)` 按 D4 状态机写入；在 session 切换/新 session 时可清理不存在的 id（避免集合无限增长）。
- 设置页：
  - 文案改为 `new thinking style: on/off`（用户可见）。
  - `runSetting('newDesigns')` 直接 `setSetting('newDesigns', current.newDesigns !== true)`；不再走 `themeControls().setNewDesigns`。
  - 保留 `setting:newDesigns` 这个内部 value，减少测试/命令面板 churn。
- 主题：
  - `ThemeProvider.available()` 始终包含 `opencode2`。
  - 删除 `ThemeSelection.newDesigns`、`ThemeStorage.save` 的 `newDesigns`、`Themes.newDesigns`、`setNewDesigns`、`ThemeControls.newDesigns` / `setNewDesigns`。
  - `app.tsx` 的 `themeStorage()` 不再读写 `newDesigns`。
  - `opencode2` 的“实验”注释和 README 说明同步更新。
  - `src/config.ts`、`src/settings.ts` 中 `newDesigns` 的注释从“offers opencode2 and the new layouts”改成“新版 thinking/tool transcript 呈现”。
- 如果不想动 provider 接口，最小方案是保留 `newDesigns` 字段但让 provider 忽略；不推荐，因为会留下两套真相。

### 5.6 Host / IPC 改动（尽量小）

1. **流式行补 `createdAt`**（`src/index.ts`）：
   - `streamRow` 增加 `createdAt`（第一次创建时 `Date.now()`）。
   - `text-delta` / `reasoning-delta` / `end` 三处 emit 都带上 `createdAt`。
2. **流式正文补 `bodyAt`**（可选但推荐）：
   - `streamRow` 增加 `bodyAt?: number`；第一次 `text-delta` 时设置。
   - `assistant/message` 替换流式行时，把 `bodyAt` 复制到 durable row；`turn/end` 结算流式行时也带上。
   - durable 行的 `bodyAt` 只在本次进程内存在；回放时缺失，按 D6 回退。
3. **协议镜像**：`src/ipc/kinds.ts` 与 `renderer/src/protocol/kinds.ts` 的 `TranscriptEvent` 增加 `bodyAt?: number`；`createdAt` 已存在，无需改 schema。
4. **工具耗时（可选）**：若希望“仅工具、无正文”的块也有结束时间，可在 `tool/result` 时给工具行补 `durationMs = result.time - call.time`。本轮不强制；没有就省略时长。

不做：

- 不新增 `thinking` role。
- 不改 session log。
- 不改 host 的 transcript 折叠语义（reasoning 仍完整发送）。

### 5.7 计时器

新增 `renderer/src/ui/clock.ts`：

- 共享 1 秒 tick，订阅者从 0→1 时启动，1→0 时停止（同 `spinner.tsx` 的共享时钟模式）。
- `useNowSeconds(active: () => boolean)` 只在 `phase === 'thinking'` 时订阅。
- 只有 `ThinkingHeader` 的文本节点读取 `now()`；不要让整个 shell 依赖它，否则每秒重绘整屏。
- `animations: false` 不影响计时；只影响 spinner 的帧。

### 5.8 文本工具

在 `renderer/src/ui/text.ts` 增加：

- `truncateEnd(text, width)`：保留头部，末尾 `...`；宽度按 `displayWidth`，CJK 不切半字。
- `wrapCells(text, width)`：按 cell 宽度换行，优先在空格处断行；CJK 可在任意字符间断行；保证每行 `displayWidth <= width`。
- `previewText(markdown)`：去掉标题 `#`、粗体 `**`/`__`、行内反引号、fence 行、列表前缀；保留代码内容。只用于预览，展开态不经过它。

测试：

- `truncateEnd('中文路径/很长', 8)` 的宽度 <= 8；
- `wrapCells('a'.repeat(25), 10)` 得到 3 行；
- 工具行换行压平；
- 预览文本去噪不吞掉代码内容。

### 5.9 性能与稳定性

- `planThinking` 只在 `newThinkingStyle()` 为 true 时计算；classic 路径零成本。
- 用 `createMemo` 读取 `transcriptRevision()` + `transcript()` + `turnRunning()`；一次 delta 只做一次 O(n) 扫描。
- 每个 Row 读取 `plan()` 的 binding；这会让所有 assistant/tool 行依赖 plan。首版接受；如果 500+ 行实测掉帧，再做**按 turn 分段缓存**：user 行切段，历史段结果缓存，只有最后一段随 delta 重算。
- 不把 `<For>` 改成会重建 item 的分组列表；这是避免流式闪烁的硬约束。
- 计时器只更新 header 文本，不触发 transcript 重新分组。

### 5.10 文本选择生命周期与配色（W8）

#### 5.10.1 现状与 API

- `CliRenderer` 在 `finishSelection()` 时发出 `selection` 事件；`Selection` 提供 `getSelectedText()`、`isActive`、`isDragging`。
- `TextBufferRenderable` 的 `selectionBg` / `selectionFg` 默认是 `undefined`；不设置时原生层会用前景色填充选中 cell（test harness 已复现 `bg = text.base`）。
- `<markdown>` 的 `selectable={false}` 不会传播到内部 `TextRenderable`；需要遍历子 renderable 或从选择生命周期下手。
- **诊断优先**：W8 第一步先加一条临时诊断（只在本分支）：在 `selection` 事件里把 `hasSelection` / `getSelectedText().length` 打到 `tui-<pid>.log`。让用户复现截图场景；如果 `hasSelection === false` 仍然出现底纹，说明不是选择，转为检查 Markdown 子块的 `bg` / 主题 token（此时 P1 的配色方案不适用，需要另开根因）。

#### 5.10.2 P0：清理零长度/过期选择

在 `Shell` 的 `onMount` 里订阅一次：

```ts
const renderer = useRenderer()
onMount(() => {
  const off = renderer.on('selection', (selection: Selection) => {
    if (selection.getSelectedText().trim() === '') renderer.clearSelection()
  })
  onCleanup(off)
})
```

并在以下路径调用 store 暴露的 `clearTextSelection()`：

- `submitComposer()` 真正发送前；
- `session-op switch/new/fork` 的激活路径（`activateAgent` / snapshot 切换）；
- `turn/start`（新一轮开始）——如果用户正在拖选，下一帧会重新开始选择；
- 现有的 `escape` / Ctrl+C 优先级里保留“先清选择”。

不要在这些路径清理**非空**选择：用户可能正在复制。只在“零长度”或“明确的会话/轮次切换”时清。

#### 5.10.3 P1：选择配色

优先方案：

- 给 `RowStore` 增加 `selectionBg` / `selectionFg`（从主题 token 取，例如 `background.raised.max` / `text.base`，或新增一对专门的 `selection.*` token）。
- 所有我们直接创建的 `<text>` 元素传入 `selectionBg` / `selectionFg`。
- Markdown：
  - 用 `ref` 拿到 `<markdown>` 的 renderable；在 `props.text` / 主题变化后遍历 `getChildren()`，对每个带 `selectionBg` 属性的子 renderable 设置主题色。
  - Markdown 每次 delta 会重建子块，所以遍历要在渲染空闲后（`renderer.idle()` 或 `queueMicrotask`）再跑一次；成本只在有新内容时发生。
  - 如果遍历不可靠（子节点类型变化、异步重建、表格子 renderable 例外），执行备选方案。

备选方案（更稳，但失去拖选）：

- 遍历 Markdown 子 renderable，设置 `selectable = false`；这样思考/回答正文不能拖选，但纯文本行（工具行、header、footer）仍可选择。
- 复制能力保留：`leader y` 复制最后一条回答；`Ctrl+C` 的现有优先级保持不变。
- 在 README/验收文档中写明“正文不支持拖选，复制用 `leader y`”。

选择配色必须满足：

- 亮色/暗色主题下都能区分选中与未选中；
- 不与 `text.base` 相同（否则在 test harness 中会被误判为异常底纹）；
- 不覆盖语法高亮的前景色，只换背景；或选择时统一前景色，保证可读。

#### 5.10.4 回归测试

- `mockMouse.click` 在 transcript 任意行：`getSelectedText()` 为空，`hasSelection` 为 false（或 selection 已清），`captureSpans` 中没有 `bg === text.base` 的文本 span。
- `mockMouse.drag` 跨思考/正文：selection 非空；选中 span 的 bg 等于主题选择色，不是 `text.base`。
- 提交 prompt / 切换 session / `turn/start`：selection 被清。
- 流式 delta 到达时已有非空 selection：不崩溃、不把旧高亮画到新文本上；必要时清选择。
- `selectable=false`（如果选备选方案）：drag 不产生 selection；纯文本行仍可选择。

#### 5.10.5 实机确认

- 单击思考/正文：不出现小方块。
- 拖选思考/正文：底纹是主题色，不是浅色反白；滚动后仍跟随文本。
- 点击别处/提交/切换会话：底纹消失。
- 复制：拖选 + 终端复制或 `leader y` 仍可用。

### 5.11 resume 后加粗标记泄漏（W9）

#### 5.11.1 Host：保留跨 block 的强调

现状 `src/host/transcript-events.ts`：

```ts
const text = displayText(
  blocks
    .filter((block): block is Extract<ContentBlock, { type: 'text' }> => block.type === 'text')
    .map(block => block.text)
    .join('\n\n')
    .trim(),
)
```

问题：`\n\n` 是段落分隔，插在未闭合的 `**`/`*`/`` ` `` 中间会破坏强调。新增纯函数 `joinTextBlocks(blocks)`：

```text
joined = ''
open = undefined        // '**' | '*' | '`' | '```' | '~~' ...
for block of blocks:
  if joined === '': joined = block
  else if open !== undefined:
    // 未闭合强调：用空串或单换行续接，不能插空行
    joined += '\n' + block
  else:
    joined += '\n\n' + block
  open = scanUnclosedInlineSpan(joined)
return joined
```

`scanUnclosedInlineSpan` 只扫描行内强调/代码，跳过 fenced code；遇到 `**`/`*`/`` ` ``/`~~` 的奇偶变化更新 `open`。如果实现成本高，先做保守规则：

- 上一个 block 末尾的 `**` 计数为奇数时，用 `''` 或 `\n` 续接；
- 否则维持 `\n\n`。

测试：

- `['这是 **加粗', '文字**。']` → `这是 **加粗\n文字**。`（或空串），渲染后无 `**`。
- `['第一段', '第二段']` → `第一段\n\n第二段`。
- `['```ts', 'const x = 1', '```']` → 代码 fence 不被当强调。
- 跨 block 的 `*斜体*`、`` `code` ``、`~~删除~~` 同样处理。

#### 5.11.2 Renderer：列表项 conceal

已确认：

- 同样的 `- **bold**` 文本，直接 `<markdown>` + 相同 style 可 conceal；
- `MarkdownText` + transcript/scrollbox 仍显示 `**`；
- 把 `syntaxStyle` 提前求值成对象能修直接用例，但 shell 仍失败；
- 全主题 `generateSyntax` 已注册 `markup.strong`/`markup.bold`，不是缺 token。

W9 的 spike 顺序：

0. **诊断**：在 resume 前后记录 `activeSyntaxStyle()` 的对象身份、`getStyle('markup.strong')`、以及 Markdown 子 renderable 实际持有的 `syntaxStyle`。先区分“样式丢失/销毁”与“列表项 conceal 逻辑本身不生效”，再决定升级还是 `renderNode`。
1. **升级 spike**：在分支上把 `renderer/package.json` 的 `@opentui/core`/`@opentui/solid` 从 `0.5.17` 升到 `0.6.6`（pnpm store 已有），跑 `transcript.test.tsx` 的加粗用例与 resume snapshot 用例。若升级修复且无 API 回归，优先升级。
2. **稳定 props**：无论是否升级，`MarkdownText` 把 `syntaxStyle`、`tableOptions` 提升为稳定对象（模块常量或 `createMemo`），避免每次 re-render 给 Markdown 传新对象导致列表项子 renderable 重建。该改动独立、低风险，先落。
3. **custom `renderNode`**：若升级后仍泄漏，给 `Markdown` 的 `renderNode` 提供列表项/强调 token 的渲染：
   - 对 `strong` 文本，输出带 `bold` 属性的 `TextRenderable`，不输出 `**`；
   - 对 `list` item 的 inline children 同样处理；
   - 保留 link/code 的既有样式。
4. **兜底规范化**：仅在 `renderNode` 不可行时，对 **列表项行** 做 `**x**` → `x` 的文本规范化（失去粗体但不再显示标记），并在文档中写明。不要对正文全文删除 `**`。

#### 5.11.3 回归

- host 纯函数：跨 block 加粗/代码/正常段落。
- renderer：resume snapshot 的 `- **bold**` 帧不含 `**`；实时流式帧与 snapshot 帧一致；`captureSpans` 中断言加粗 span 带 bold 属性（若可读）。
- 主题：light/dark、opencode/opencode2 都覆盖；CJK、标点、嵌套 `**`、加粗跨行。
- 实机：resume 一个包含加粗列表的会话，对比实时和 resume；滚动、切换会话后仍正常。

### 5.12 空会话不落盘（W10）

#### 5.12.1 先确认 materialize 的时点

W10 第一步不是改代码，而是加一条临时日志/测试：

- 启动后、resume 前、退出时分别调用 `ctx.sessionPersistence.stat(id)` / `list()`，确认空会话何时可见；
- 解压 `session.v4.jsonl.zstd`，确认事件数始终是 4（setup）还是会有额外事件；
- 断开 Home 与 resume 的路径，确认是 agent-loop 的 `create` 还是 TUI 的 mount 触发。

当前实机证据是 4 条 setup 事件，说明 agent-loop 的 `create` + `appendUnstoredSuffix` 已经 materialize；W10 要阻止的是“在第一条 user message 之前 create”。

#### 5.12.2 首选：lazy session creation

目标：启动 TUI 时不创建 agent，也不创建持久化 session；Home 只挂一个“无会话”壳。

改动点：

1. **`src/startup.ts`**：bare launch 不再 mint `sessionId`；`--session <id>` 只作为 **pending fresh id** 交给 TUI，第一条消息才用它 `createAgent`；只有 `--resume` 在启动时声明 configured agent。
2. **`cordis.patch.yml`**：`agent-loop.agents` 只在 `--resume` 时声明；bare launch 与 `--session` 都不启动 configured agent（`--session` 的 id 由 TUI 首次发送时传入 `createAgent`）。**先验证 agent-loop 接受空 `agents`** 并在首个 `ctx.agents.create` 前不启动任何 agent；若不接受，改用 placeholder/装饰器方案。
3. **TUI row**（`src/index.ts`）：
   - 允许 `liveAgent === undefined` 的 Home 模式，并保留 `pendingSessionId`（来自 `--session`）；
   - `snapshotFor()` 返回一个 synthetic Home snapshot（`sessionId: ''` 或占位 id，`initialRoute: 'home'`，空 events）；
   - `send-message` 的第一条：先 `createAgent({ sessionId: pendingSessionId })` 得到真实 session，再走现有提交路径；
   - `session-op new/switch/read/fork` 在无 agent 时按“先创建/先 resume”处理；
   - 所有 `(agent ?? liveAgent)` 的读取点用 `currentAgent()` helper，Home 模式返回 `undefined` 并给出明确错误，而不是崩。
4. **Renderer**：Home 路由已经存在；`currentSession()` 允许空串/占位 id，首个 `send-message` 后由 host 推 `session-snapshot` 切到真实会话。`/new` 在没有会话时只清空输入，不发 `session-op` 或发一个“尚未创建”的本地动作。
5. **WeChat / 其他入口**：`createForegroundSessionImpl` 已有；Home 模式下的 `foregroundAgent()` 需要返回 `undefined`，调用方按无会话处理。

风险：这是跨 host/renderer 的生命周期重构，`(agent ?? liveAgent)` 的假设很多；必须用 W0 的启动/恢复矩阵兜住。

#### 5.12.3 备选：LazySessionPersistence 装饰器

如果 lazy agent 改动过大，评估在 TUI adapter 里包装 `sessionPersistence`：

- `create(header)`：返回一个 proxy handle；`append()` 先缓冲 setup events，不调用真实 `create`。
- 当 append 的 batch 里出现 `user/message` / `assistant/message` / `tool/call` 时：
  1. 调用真实 `create(header)`；
  2. 先 append 缓冲的 setup events；
  3. 再 append 当前 conversation event；
  4. 后续 append 直通。
- `flush()` / `close()`：如果从未 materialize，直接丢弃 buffer，不调用真实 create/flush；已 materialize 则直通。
- `read` / `stat` / `list` / `identity`：直通真实 service；未 materialize 的会话对读路径不可见（这正是“空会话不存在”的语义）。
- 风险：必须在 agent-loop 注入 `sessionPersistence` 之前安装；Cordis service 覆盖顺序、`instanceof`/identity、其他 plugin 的预期都要验证。若做不到干净覆盖，放弃此方案，走 5.12.2。

#### 5.12.4 短期兜底与历史清理

- host `/resume` picker 过滤 `blank: true`（与 renderer 的 `listableSessions` 一致）。
- 启动时扫描 `$DSH_HOME/sessions/**/tui-*/session.v4.jsonl.zstd`：
  - 用 `sessionPersistence.open(id, 'read')` 读前几条（或复用 `readSessionHead`）确认**不含** `user/message`、`assistant/message`、`tool/call`；不要直接解压/正则猜；
  - 删除整个 session 目录前必须确认 id 前缀与路径匹配，且不在当前 live agent 列表；
  - 先 dry-run 列清单，再实际删除；失败只记 warning，不阻塞启动。
- 这是历史垃圾清理，不是新会话防护；不能替代 5.12.2/5.12.3。

#### 5.12.5 测试

- host 启动矩阵：bare launch + no send + exit → 无新 session；bare launch + resume → 无新 session；bare launch + first send → 恰好一个 session。
- `/new` + no send + switch → 无新 session；`/new` + send → 一个 session。
- 空会话清理只删 4-event 目录；含 user/assistant/tool 的目录绝不删。
- renderer Home 模式：无 snapshot 时能渲染；首条 send 后收到 snapshot 并切到 session route。
- 回归：resume 现有会话、`/sessions`、tabs、WeChat 入口都能工作。

### 5.13 最后交互时间与排序（W11）

#### 5.13.1 数据来源

优先级：

1. **live session**：`session.eventAt(session.seq - 1)?.time`（`Session.seq` 是下一个 seq，最后一条是 `seq-1`）。若没有事件，回退 `header.createdAt`。
2. **persisted session**：`sessionPersistence.stat(id)` 或 `list()` 给出 `eventCount` 时，`open(id, 'read').read(eventCount - 1, 1)` 取最后一条 event 的 `time`；关闭 handle。
3. **没有 `eventCount`**：读存储文件 mtime（`$DSH_HOME/sessions/<cwd-slug>/<id>/session.v4.jsonl.zstd` 的 `mtimeMs`），这是最后一次物理写入时间；路径解析失败就回退 `createdAt`。空会话的 mtime 接近创建时间，仍会被 `blank` 过滤。
4. **都不可用**：回退 `header.createdAt`，并在 payload 里省略 `lastActivityAt`，renderer 用 `createdAt`。

缓存：

- 以 `(id, revision)` 为键缓存 persisted 值；`revision` 不变就不重读。
- live session 在 `session/event` 订阅里更新 `lastActivityAt = max(current, event.time)`；turn 结束、工具结果也会推进。
- 列表刷新时先 merge live map + persisted cache，再排序。

#### 5.13.2 协议与排序

- `SessionListPayload.sessions[]` 增加 `lastActivityAt?: number`（host `src/ipc/kinds.ts` + renderer mirror）。
- host：`pushSessionList` 用 `b.lastActivityAt ?? b.createdAt` 降序；`sortSessionsByActivity()` 纯函数，`/resume` picker 复用。
- renderer：`sessions` signal 类型增加 `lastActivityAt`；`openSessionRows` 的 today/yesterday 分组改用 `lastActivityAt ?? createdAt`；tab strip 仍按 host 顺序。
- 显示（可选）：`/sessions` 行 description 可加 `last active <time>`；不强制。

#### 5.13.3 测试

- 纯函数：A/B/C 的 `createdAt` 与 `lastActivityAt` 交叉，排序稳定；缺失回退；相同时间按 id 稳定排序。
- host：live event 推进 `lastActivityAt`；resume 旧会话后发消息，列表把它排到顶部；`/resume` picker 同样。
- renderer：刚用过的旧会话进入 today 分组；`createdAt` 旧但 `lastActivityAt` 新时不出现在 older。
- 性能：100 个 session 的列表刷新不逐个读全量日志；`revision` 缓存命中。


---

## 6. 工作包与排期

估算总计 **11–17 工程日**，不含用户实机验收。

| 工作包 | 内容 | 估算 | 主要文件/验收 |
|---|---|---|---|
| **W0 基线** | 用现有代码固化 classic 帧；补一条“streaming 但有 reasoning 仍显示 Thought”的失败测试；记录 40/80/120 列基线；补 `mockMouse.click`/`drag` 的选择异常失败测试 | 0.5d | `streaming.test.tsx`、`transcript.test.tsx`；失败测试先红后绿 |
| **W1 开关语义** | `newDesigns` 改为思考样式开关；设置页文案/写入；主题 provider 解耦 `opencode2`；更新 provider/app 测试 | 1d | `app.tsx`、`provider.tsx`、`controls.ts`、`app.test.tsx`、`provider.test.tsx`；开关切换即时生效，主题不变 |
| **W2 classic 修复** | `Thinking`/`Thought` 判定；思考头加鼠标点击；classic 测试更新 | 0.5d | `transcript.tsx`、`app.test.tsx`；streaming 行显示 `Thinking`，settled 显示 `Thought`，点击可折叠 |
| **W3 分组模型** | `planThinking` + `ThinkingBlockView` + 边界；纯函数单测 | 1d | 新 `ui/thinking.ts` / `thinking.test.ts`；覆盖正文边界、工具先行、多 turn、打断 |
| **W4 新版预览** | `ThinkingHeader`、`ThinkingPreview`、5–10 行、单行工具、截断/换行；文本工具 | 1.5d | `thinking.tsx`、`transcript.tsx`、`text.ts`；帧测试覆盖 Running/Done/Failed、无工具、CJK |
| **W5 展开/收起** | `ThinkingDetail` 复用 classic 行；点击状态机；hover；`showReasoning` 交互 | 1d | `transcript.tsx`、`app.tsx`；`mockMouse.click` 展开/收起，正文出现自动收起 |
| **W6 时长/时间戳** | 共享 1s clock；`formatThinkingDuration`；host 流式 `createdAt` / `bodyAt`；`<1m` 规则 | 0.5d | `clock.ts`、`src/index.ts`、`src/ipc/kinds.ts`、`thinking.test.ts`；`12s` / `1m 05s` |
| **W7 集成与验收** | 设置切换/流式中切换；40/80/120 帧；README/CHANGELOG/contracts/acceptance；构建与门禁 | 1.5d | 全量测试、`build:renderer`、`dpsk check`、真机清单 |
| **W8 选择高亮异常** | 选择生命周期（单击/提交/切换清理）、主题化选择色或禁用 Markdown 拖选、点击/拖选/流式回归 | 1–1.5d | `app.tsx`、`transcript.tsx`、`markdown.tsx`、`text.ts`、selection 测试；截图场景不再出现 |
| **W9 resume 加粗泄漏** | `joinTextBlocks` 保留跨 block 强调；OpenTUI 升级 spike / 稳定 Markdown props / 列表项 conceal 修复；实时与 resume 一致性 | 1–2d | `src/host/transcript-events.ts`、`markdown.tsx`、`transcript.test.tsx`、`transcript-events.spec.ts`；resume 帧不含 `**` |
| **W10 空会话不落盘** | lazy session creation 或 LazySessionPersistence；`/resume` 过滤 blank；历史 4-event 目录清理；启动/恢复/`/new` 矩阵 | 2–4d | `startup.ts`、`cordis.patch.yml`、`index.ts`、`app.tsx`、新增 host 生命周期测试；启动/退出无新目录 |
| **W11 最后交互排序** | `lastActivityAt` 采集/缓存、`SessionListPayload`、host 排序、`/resume` 复用、renderer 分组 | 1–1.5d | `src/index.ts`、`src/ipc/kinds.ts`、`renderer/src/app.tsx`、排序纯函数测试；旧会话回顶/今天 |

依赖顺序：

```text
W0 → W1 → W2 → W3 → W4 → W5 → W6 → W7
                    ↘ W8（选择高亮，可与 W4/W5 并行）
                    ↘ W9（resume 加粗；host 侧可与 W1 并行，renderer 侧在 W4 前落）
                    ↘ W10 → W11（会话生命周期先于排序；W10 可与 W4 并行）
```

W2 可以在 W1 前独立做；W3 的纯函数可以与 W4 并行；W6 的 host 时间戳可以与 W4 并行，但 W5 的最终帧验收依赖 W6 的时长格式。W8 与 W4/W5 都改 transcript，建议在同一分支上先落 P0，再做 W4/W5，最后做 P1 配色，避免点击处理互相踩。W9 的 host `joinTextBlocks` 可以先做；renderer 的升级/渲染修复要先于 W4 定稿，避免抄错 Markdown 基线。W10 改启动/会话生命周期，建议单独分支并先做 spike；W11 依赖 W10 的会话模型与排序结果。

---

## 7. 测试计划

### 7.1 纯函数单测（新增 `renderer/src/ui/thinking.test.ts`）

**分组矩阵**

- `assistant(reasoning, no text)` → `tool` → `assistant(reasoning, text)`：一个块、2 段 reasoning、1 个工具、phase=thought、正文行只渲染 text。
- `assistant(text, streaming, no reasoning)`：**无块**（纯正文流不能多出空 Thought 头）。
- `assistant(text, streaming, reasoning: '')`：**无块**（空 reasoning 不算思考）。
- `assistant('', streaming, reasoning: '')`：块已建立（等待第一段 reasoning），内容为空，仅 header。
- `assistant('', streaming, no reasoning)`：无块（没有 reasoning 流，不凭空造 Thinking）。
- `assistant(text, no reasoning)` → `tool`：无块，工具走 classic。
- `tool` → `tool` → `assistant(text)`：块从第一个工具开始，toolCount=2。
- 两个 `user` turn：两个独立块，不合并。
- `assistant(reasoning, streaming, no text)` + `turnRunning=true`：phase=thinking。
- 同上但 `turnRunning=false` / `streaming=false`：phase=thought。
- 单行同时有 reasoning + text：块 leader 是该行，正文由该行渲染。
- `system` 行分隔：前块关闭，后块可新建。
- 无 reasoning、无工具、只有 text：无块。
- 失败/拒绝工具：仍在块内，status 保留。

**格式**

- `formatThinkingDuration(999) = ''`（或仅标签）；`12_000 = '12s'`；`60_000 = '1m 00s'`；`65_000 = '1m 05s'`。
- `thinkingHeader({phase:'thinking',durationMs:12_000,toolCount:2})` → `Thinking 12s | Used 2 Tools`。
- 无工具 → 无 `| Used`；1 个 → `Used 1 Tool`。
- 无时长 → `Thinking | Used 1 Tool`（不出现双空格）。
- marker：preview/detail `-`，closed `+`。

**工具单行**

- pending/ok/failed/denied 的前缀与颜色 token。
- 长参数截断到宽度，末尾 `...`，宽度不超。
- 参数含换行时压成空格。
- 工具 detail 为空时只显示工具名。

**预览**

- 1 行 → 5 行高（4 行空白）；5 行 → 5 行；10 行 → 10 行；12 行 → 10 行且是最新 10 行。
- 长 reasoning 行按宽度换行；CJK 行不切半字。
- 多段 reasoning + 工具的时间顺序。
- Markdown 去噪：`**Checks**` → `Checks`；`# Head` → `Head`；fence 行不显示；代码内容保留。

### 7.2 Renderer char-frame 测试

新增/更新 `renderer/src/ui/transcript.test.tsx`、`streaming.test.tsx`、`app.test.tsx`：

1. **classic streaming**：`streaming: true`、reasoning 有内容、text 为空 → `Thinking: ...`，不出现 `Thought`。
2. **classic settled**：`streaming: false` → `Thought: ...`；点击标题后 `+` 且正文消失。
3. **new live**：`newDesigns: true`，snapshot 里有 `assistant(reasoning: '**Plan**...', streaming) + tool(pending) + assistant(reasoning: '...', streaming)`：
   - 只出现一个 `Thinking`；
   - 出现 `Running: Read ...`；
   - 出现 `Used 1 Tool`；
   - 不出现第二个 `Thought`/`Thinking`。
4. **tool status update**：同一 tool 行从 pending 更新为 ok → `Done: Read ...`，计数不变。
5. **body appears**：追加 `text: 'the answer'` → 标签变 `Thought`、预览消失、正文上屏。
6. **click expand/collapse**：`mockMouse.click` 点击 header 的列/行 → 出现完整 reasoning body 和经典工具行；再点 → 只剩 header。
7. **no tools**：`Thinking 12s` 不含 `Used`。
8. **duration**：用 `createdAt`/`durationMs` 构造 65s → `Thought 1m 05s`；12s → `Thought 12s`。
9. **interrupted**：无正文、`interrupted` → `Thought ...`，预览不存在。
10. **showReasoning=false**：new style 下思考中只有 header，无预览；点击仍可展开。
11. **width**：40/80/120 列下 header/预览/正文不越界；CJK 参数截断不切半字。
12. **live toggle**：流式中 `settings` 从 false→true，块出现且已有 reasoning 不丢；true→false，回到 classic 行。
13. **row identity**：new style 下连续 delta 不重建行（可复用 `streaming.test.tsx` 的 `toBe(first)` 断言）。
14. **selection click**：`mockMouse.click` 在思考/正文行 → `getSelectedText()` 为空且 selection 已清；`captureSpans` 中不存在 `bg === text.base` 的异常底纹/方块。
15. **selection drag**：`mockMouse.drag` 跨思考/正文 → selection 非空；选中 span 的 bg 是主题选择色（不是 `text.base`）；提交/切换 session 后 selection 清空。
16. **selection + streaming**：已有选择时追加 delta → 不把旧选择画到新文本上；不崩溃；必要时选择被清。
17. **resume 加粗**：用 `session-snapshot` 模拟 resume，回答包含 `- **A 卡 + 单机/Steam 联机**`、`**5%~15%**`、跨 block 的 `**加粗`/`文字**`；帧里不出现 `**`；加粗 span 仍带 bold 属性；实时流式帧与 snapshot 帧一致。
18. **会话分组排序**：`createdAt` 旧但 `lastActivityAt` 新的会话进入 today 分组；无 `lastActivityAt` 时回退 `createdAt`；列表顺序与 host 下发顺序一致。

### 7.3 App/store 测试

- 设置页 `setting:newDesigns` 切换：发送 `update-settings { newDesigns: true }`，不调用任何主题写入。
- 设置页标题显示 `on`/`off`。
- `themeControls` stub 移除 `newDesigns`/`setNewDesigns` 后编译通过（`app.test.tsx:3083-3093`）。
- `thinkingMode` 写入/读取；切换 session 后旧 id 不崩。

### 7.4 Provider 测试

- `opencode2` 在 `newDesigns: false` 时也出现在 `all()`。
- `settings` 后到时 `themeName: 'opencode2'` 仍能选中。
- 删除/改写现有 `provider.test.tsx:104-118` 的 newDesigns 断言。

### 7.5 Host 文本拼接（W9，`tests/transcript-events.spec.ts`）

- `['这是 **加粗', '文字**。']` → 拼接结果不出现跨段空行；渲染后无 `**`。
- `['第一段', '第二段']` → `\n\n` 段落分隔保留。
- 跨 block 的行内代码/斜体/删除线不被空行拆坏。
- 正常已闭合的 `**加粗**` 不被误判为未闭合。
- 多 text block 的 assistant 消息折叠后，`text` 与实时 chunk 拼接的语义一致。

### 7.6 门禁与手工验收
自动：

```text
npm run typecheck:renderer
npm run test:renderer
npm run check          # verify:boundary/contract/plugin-spec/ipc-protocol/license + typecheck + test
npm run build:renderer
```

手工（Windows Terminal / WezTerm，168×24、80×24、40×16）：

- [ ] 关闭开关：与改造前逐帧对比，除 `Thinking` 文案外无差异。
- [ ] 打开开关：多工具 + 多段 reasoning 的 turn 只有一个 `Thinking`，预览 5–10 行自动滚动。
- [ ] `Running:` → `Done:` 原位更新；失败工具显示 `Failed:`；长参数末尾 `...`。
- [ ] 正文出现后 `Thought`、预览收起、正文正常流式；点击展开恢复经典样式，再点收起。
- [ ] 思考中与正文后点击都有效；拖选文本不会误触。
- [ ] 打断一个只思考未出正文的 turn：标签变 `Thought`，不残留 Thinking spinner。
- [ ] `/settings` 切换即时生效、重启后保持；切换后主题不变。
- [ ] `showReasoning = hide`：新版只显示 header；展开仍可看。
- [ ] 40 列下 CJK 参数、`Used 1 Tool`、时长不换行/不溢出。
- [ ] 老版主题选择器仍能选 `opencode2`（开关关闭时）。
- [ ] 单击思考/正文：不出现截图中的小方块。
- [ ] 拖选思考/正文：底纹是主题选择色；滚动、继续流式后不残留；点击别处/提交/切换会话后消失。
- [ ] 复制：拖选 + 终端复制或 `leader y` 仍可用；如果采用“禁用 Markdown 拖选”的备选方案，正文不可拖选但 `leader y` 可复制。
- [ ] resume 一个包含 `- **加粗**` 列表的会话：回答/思考都不出现 `**`；实时与 resume 视觉一致。
- [ ] 跨 block 的加粗（模型把 `**加粗` 和 `文字**` 分块输出）在 resume 后仍能加粗，不泄漏标记。

### 7.7 会话生命周期与排序（W10/W11）

**Host 启动/恢复矩阵**

- [ ] 启动 TUI → 不发送 → 退出：`.dsh/sessions` 不新增 `tui-*` 目录；`sessionPersistence.list()` 不出现新 id。
- [ ] 启动 TUI → resume 旧会话 → 发送/不发送 → 退出：不新增空会话；旧会话有正常更新。
- [ ] 启动 TUI → `/new` → 不发送 → 切回旧会话：不新增可恢复空会话。
- [ ] 启动 TUI → 发送第一条消息：恰好新增一个会话；第一条 `user/message` 在该会话中；Home → session 路由切换一次。
- [ ] 启动 TUI → 退出 → 再启动：上次的空会话不累积；已有真实会话不变。
- [ ] 历史空会话清理：只删解压后无 `user/message`/`assistant/message`/`tool/call` 的 `tui-*` 目录；含对话的目录绝不删。
- [ ] `blank` 会话在 host `/resume` 与 renderer `/sessions` 都不出现（当前会话除外）。

**排序**

- [ ] 创建时间 A < B < C，最后交互 C < A < B：host `session-list` 与 `/resume` picker 顺序为 C、A、B。
- [ ] 在旧会话里发一条消息后，它回到列表顶部/today 分组。
- [ ] 无 `lastActivityAt` 的旧数据回退 `createdAt`；相同时间按 id 稳定排序，不出现 `NaN`。
- [ ] 100 个会话的刷新不逐个读全量日志；`revision` 缓存命中，列表刷新可接受。

**实机**

- [ ] 用 Windows Terminal 启动/退出/resume/`/new` 四次，检查 `.dsh/sessions` 目录数量与内容。
- [ ] resume 一个旧会话，发送后回到 `/sessions`，确认它在顶部/今天。
- [ ] 空会话不再出现在 `/resume`、`/sessions`、桌面/workspace 列表。

---

## 8. 风险与缓解

| 风险 | 表现 | 缓解 |
|---|---|---|
| **行重建/闪烁** | 分组后把 `<For>` 换成嵌套列表，流式 delta 每次重建 Markdown | 保持平铺 `<For>`；块只在 leader 位置渲染；非 leader 行返回 null；不替换行对象 |
| **点击与文本选择冲突** | 用户拖选思考文字时误触展开 | `onMouseUp` 前检查 renderer 是否有 selection；有则忽略；至少用 `onMouseDown` + 小位移判定 |
| **嵌套滚动** | 预览用 `scrollbox` 后滚轮被内层吃掉、外层 transcript 失灵 | 预览不用 `scrollbox`；纯文本行 + 预计算高度；完整内容用展开 |
| **计时器重绘** | 1s tick 让整屏每帧重算 | 共享 clock；只有 header 文本节点读 `now()`；phase=thought 时取消订阅 |
| **长 transcript O(n)** | 1000+ 行每 delta 全量扫描 + 所有行重新求值 | 首版测量；必要时按 turn 分段缓存，只重算最后一段 |
| **时长近似** | 实时与回放差一个正文生成时间 | 文档写明；优先用 `bodyAt`；缺失时省略而不是显示错误值 |
| **主题解耦副作用** | `opencode2` 提前出现在主题列表；旧测试断言失败 | 作为明确变更记录；更新 provider/app 测试；README 说明 |
| **开关迁移惊讶** | 曾为 `opencode2` 打开 `newDesigns` 的用户，升级后直接进入新版思考样式 | 0.5.0 未发布；CHANGELOG 写明语义变更；默认 false 只影响显式打开的人 |
| **`showReasoning` 语义混淆** | 用户以为 hide = 整块消失 | 文档/设置提示：hide 只收起预览/正文，header 仍显示时长与工具数 |
| **选择高亮修复误伤复制** | 清理太激进，用户拖选后一提交/滚动就没了 | 只清零长度/会话切换/提交；非空选择保留到显式点击/复制；`leader y` 兜底 |
| **Markdown 子 renderable 无法配色** | `<markdown>` 的 `selectionBg` 不生效，拖选仍是浅色反白 | W8 先 spike；失败则禁用 Markdown 拖选（备选方案），保留纯文本行选择和 `leader y` |
| **选择高亮仍被当成主题色泄漏** | 修复后仍有人把选择色误判为 bug | 选择色与 `text.base` 明确不同；验收文档写明“拖选会出现主题选择色” |
| **OpenTUI 升级回归** | 0.6.6 修了加粗但引入布局/API 变化 | 升级 spike 独立分支；跑全量 renderer 测试 + 40/80/120 帧；不行就回退到 `renderNode` 方案 |
| **跨 block 拼接改变段落语义** | `joinTextBlocks` 把本该分段的文本粘成一段 | 只在检测到未闭合强调/代码时用单换行；正常段落仍 `\n\n`；纯函数测试覆盖 |
| **加粗兜底规范化丢样式** | 为去掉 `**` 把正常加粗也变成普通文本 | 只对泄漏的列表项/未闭合 span 做兜底；优先升级或 `renderNode`，不全局删 `**` |
| **lazy session 改动面过大** | 启动/首条消息/resume/`/new` 的 `(agent ?? liveAgent)` 假设被打破 | W10 单独分支 + 启动矩阵；先做 spike 再改主路径；保留“启动即建会话”的 feature flag 以便回退 |
| **persistence 装饰器覆盖失败** | 服务注册顺序/identity/`instanceof` 冲突，agent-loop 不认 | 先验证 Cordis 覆盖能力；不干净就放弃，走 lazy agent；不要半覆盖 |
| **清理历史空会话误删** | 把含对话的 session 目录当空会话删掉 | 只删解压后确认无 conversation event 的 `tui-*` 目录；先 dry-run 列清单；当前 live agent 跳过 |
| **lastActivity 数据不可得** | 后端不提供 `eventCount`，mtime 又不可靠 | 三级回退：last event → 文件 mtime → `createdAt`；缺失不显示 `<time>`，排序仍稳定 |
| **排序变化打乱当前视图** | 正在看的会话因排序跳到别处 | 当前会话在 tab strip/选择器保持选中；排序只在列表刷新时应用，不重排当前 transcript |

---

## 9. Definition of Done

- [ ] `newDesigns` 开关在 `/settings` 中即时切换新版/老版 transcript；不改变当前主题；重启后保持。
- [ ] 老版路径除 `Thinking` 文案与点击外无视觉变化。
- [ ] 思考中显示 `Thinking`，正文开始/结束后显示 `Thought`；classic 与新版都成立。
- [ ] 新版在正文之前只产生一个思考块，合并多段 reasoning 与多个工具；工具计数正确。
- [ ] 预览严格 5–10 行、自动尾随最新内容；区内工具为 `Running:` / `Done:` / `Failed:` / `Denied:` 单行，超宽 `...` 截断。
- [ ] 点击标签可展开/收起；展开为 opencode 默认思考展开样式（gutter + Markdown + 经典工具行）。
- [ ] 标签格式满足 `<1m` 规则、`Used N Tool(s)` 规则、无工具省略规则。
- [ ] 40/80/120 列、CJK、长参数、失败/拒绝、打断、`showReasoning=false` 均有测试或验收记录。
- [ ] 单击不再留下小方块；拖选使用主题选择色（或明确禁用 Markdown 拖选并在文档写明复制方式）；提交/切换会话后选择清空。
- [ ] resume/切换对话后，思考与回答里的 `**加粗**` 都不显示 `**`；实时与 resume 帧一致；跨 block 的加粗仍生效。
- [ ] 启动/退出/resume/`/new` 不新增无交流的空会话；首条消息才落盘；历史空会话清理不误删真实会话。
- [ ] 会话列表/`/resume`/today 分组按 `lastActivityAt` 排序；旧会话用过后回到顶部/今天；缺失回退 `createdAt`。
- [ ] 所有自动门禁通过；`build:renderer` 成功；无 dsh 上游修改；不发布、不打 tag、不 push。
- [ ] README / CHANGELOG / docs/contracts / docs/ACCEPTANCE_TUI_SHELL 已更新。
- [ ] 用户完成 Windows Terminal 实机验收并确认。

---

## 10. 需要用户确认的设计点

以下八项会显著影响实现，建议按推荐值执行；如果不认可，请在开工前指出：

1. **`opencode2` 解耦**（推荐：始终可选；开关只控制思考样式）。备选：继续用 `newDesigns` 门控 `opencode2`。
2. **时长口径**（推荐：从第一段思考/工具开始到正文出现，包含工具等待；回放用消息完成时间近似）。
3. **展开后的顺序**（推荐：一个标签下按时间顺序渲染“reasoning body + 经典工具行”，不把多段 reasoning 先拼成一大段再列工具）。
4. **标签语言**（推荐：本轮保持英文 `Thinking`/`Thought`/`Running`/`Done`/`Used`，与 opencode 一致；后续再走 zh/en 字典）。
5. **文本选择策略**（推荐：保留拖选并主题化选择色；若 Markdown 子 renderable 无法可靠配色，则禁用 Markdown 拖选、复制走 `leader y`）。这一项只影响“是否还能拖选复制正文”，不影响 W8 的 P0 清理。
6. **resume 加粗修复策略**（推荐：先做 OpenTUI 0.6.6 升级 spike + host `joinTextBlocks`；升级不能修再走 `renderNode`；文本规范化只作最后兜底）。这一项会影响 1–2 天的排期和依赖版本。
7. **空会话修复策略**（推荐：lazy session creation；备选：LazySessionPersistence 装饰器；短期只做 `/resume` 过滤 + 历史 4-event 清理）。这是本轮改动面最大、最需要单独分支/回退开关的一项。
8. **最后交互时间来源**（推荐：live 用最后 event time，持久化用 `eventCount` tail read + `revision` 缓存，缺失回退文件 mtime/`createdAt`）。如果后端不提供 `eventCount`，要接受 mtime 近似。

另外两个默认选择，如无异议按此执行：

- 新版默认 `newDesigns: false`（保留用户喜欢的老版）。
- 预览不做手动滚动；要完整内容点击展开。
