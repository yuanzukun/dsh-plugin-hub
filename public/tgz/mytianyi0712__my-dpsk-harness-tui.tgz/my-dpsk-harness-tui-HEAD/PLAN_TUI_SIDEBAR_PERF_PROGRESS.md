# Sidebar / context / config / restart / performance progress

> Date: 2026-10-23
> Version: 0.5.0
> Status: implementation in progress

## Completed

- S1: sidebar default width 42 -> 40; docked/overlay/terminal tests updated.
- S1.5: assistant text transition stamps `bodyAt`; compact header settles on first body chunk.
- S1.6: cache read/write completeness split; read-only provider samples show cache hit again.
- S2: launcher backend signature cache; warm `node scripts/dpsk.js --version` measured 246-283ms versus 832-933ms baseline.
- S2.5: `~/.config/.mydpsk` path, legacy backend migration, seeded config.json/price.json/empty custom_price.json, validated watcher + polling fallback.
- S2.6: EasyCLIProxyAPI 0.3.29 public price import (95 models), alias/versionless matcher, separate `price.json` + empty `custom_price.json` overlay, `/price` command, missing-price notice, DeepSeek schedule support, host cost fold, sidebar CTX/SUM/$.
- S2.7: `/restart` command + dpsk supervisor + dedicated exit code + session handoff + draft persistence + loop guard.
- S3: startup migrations and terminal setup run concurrently.
- S4: cold resume no longer lists the full corpus; session-list refresh is coalesced; transcript projection cache added.
- S5 partial: renderer drafts survive restart; full per-session transcript paint cache remains follow-up.

## Verification

- Host: `npm run check` green: 328 tests, 327 pass, 1 skipped.
- Renderer: `npm run test:renderer` green: 400 pass, 3173 expectations.
- Build: host `npm run build` and all seven renderer platform bundles complete after the final price/config changes.
- Targeted: launcher 20 pass; pricing 9 pass; program-config 9 pass; startup-selection 3 pass; write-card/pending-context/cache/thinking/stream/draft/unpriced UI tests pass.
- Launcher warm benchmark after config-home migration: 281-315ms for `node scripts/dpsk.js --version`.

## Remaining

- Optional S5 per-session transcript UI cache and optimistic pending-tab marker.
- Install the new build and run `dpsk check`; capture real startup/live/cold-switch timings.
- Add user-facing config error toasts for invalid pricing/config reloads.

## Price table decision

- `price.json` is the program-managed public table, generated from EasyCLIProxyAPI 0.3.29 `usage.db` model_prices (95 entries).
- `custom_price.json` starts empty; `/price` writes per-current-model overrides and manual edits are supported. Effective priority: custom_price.json > price.json.
- Unpriced usage renders `$ 未配置模型价格`; `/price` reloads and reprices the active session immediately.

## Installed build

- Global package and tui profile source hash: `677abe84d3b1`.
- Renderer cache hash: `8c727ec2c7aa`; matches `SHA256SUMS.json`.
- `dpsk check`: global/profile consistent, renderer consistent, no overwrite needed.
- Session activity fix: interaction-only ordering; strict local-calendar today/yesterday labels.
- Sidebar default width: 40.
- Route-only `selection-state` avoids full transcript resend and `standard` preset flash on model/effort/preset changes.
- Launcher realpath dispatch fix for npm global symlink installs.

## Model switching fast path

- Added downstream `selection-state` (route-only) IPC alongside the full `session-snapshot`.
- Model/effort/preset picks and image-capability refreshes no longer resend the transcript.
- Renderer applies route changes optimistically; the host publishes route state before the settings write.
- No preset reset/flash (`standard`) during a model pick; catalogs remain intact.
- IPC verifier: 41 downstream kinds, 26 upstream kinds.

## Permission picker fix

- Permission catalog is process-level and now survives session snapshots/draft reset.
- `/permission` falls back to workspace-write/full-access until the host catalog arrives.
- Host sends localized labels from the same metadata adapter as `/help`.
- Regression tests cover fallback and catalog preservation across snapshots.

## Startup fast path v2

- First frame no longer awaits startup migrations or terminal plugin setup.
- Session rail paints from a disk cache; fresh enumeration refreshes 300ms later.
- Workspace files / skills are deferred until after first paint.
- Empty-session cleanup is throttled to once per 6 hours.
- Node compile cache enabled for the dsh child.
- Renderer uses Bun ESM bytecode; warm sidecar startup ~150ms -> ~75ms on this machine.

## Transcript counters and jump geometry

- Rounds = real user rows (including interrupted, excluding model-selection notices).
- Steps = unique `(turn, step)` tool-handoff steps; parallel calls in one step count once.
- The bottom T/S counters derive from the transcript, not the last assistant row.
- Jump to latest uses soft-wrapped visual composer rows plus attachment rows, so it stays above the input box.

## Prompt route metadata, last selection, and thinking folds

- Prompt row: localized mode + permission, model, effort; distinct theme inks; provider stays in sidebar.
- `config.json.lastSelection` stores provider/model/effort/preset; startup restores it unless a historical request header wins.
- Live thinking detail folds back to its dynamic preview; reasoning text itself is a fold target; settled blocks fold to the one-line header.

## Tool cards and live activity labels

- `write` uses the raised block card: `# Wrote <path>` header, content in a capped body.
- Pending tool rows keep the concrete tool name and argument instead of a bare `Running…` label.
