/**
 * Attention sounds.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, 2.0.32, `packages/tui/src/audio.ts` +
 * `attention-sounds.bun.ts`), MIT. Registered in NOTICE.md under the `opencode` entry;
 * verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * The five sound files are the upstream assets; the `with { type: 'file' }` imports make
 * Bun embed them in the compiled renderer, so a released binary carries its own audio.
 *
 * Behaviour that is upstream's, not this package's:
 * - The audio device is created lazily and a deployment without audio support yields
 *   `null` for both loading and playback instead of throwing.
 * - A loaded file is cached by path; a failed load is cached as `null` so a missing file is
 *   not re-read on every notification.
 * - `dispose` drops the device and the cache.
 */

import { Audio, type AudioErrorContext, type AudioPlayOptions, type AudioSound } from '@opentui/core'
import { readFile } from 'node:fs/promises'
import bipBop01 from './assets/audio/bip-bop-01.mp3' with { type: 'file' }
import bipBop03 from './assets/audio/bip-bop-03.mp3' with { type: 'file' }
import staplebops06 from './assets/audio/staplebops-06.mp3' with { type: 'file' }
import nope03 from './assets/audio/nope-03.mp3' with { type: 'file' }
import yup01 from './assets/audio/yup-01.mp3' with { type: 'file' }

/** The built-in sound a notification names. */
export type AttentionSoundName = 'default' | 'question' | 'permission' | 'error' | 'done' | 'subagent_done'

/** One bundled sound per attention name. */
export const BUILTIN_SOUNDS: Readonly<Record<AttentionSoundName, string>> = {
  default: bipBop01,
  question: bipBop03,
  permission: staplebops06,
  error: nope03,
  done: bipBop01,
  subagent_done: yup01,
}

let audio: Audio | null | undefined
const sounds = new Map<string, Promise<AudioSound | null>>()

function getAudio(): Audio | null {
  if (audio !== undefined) return audio
  try {
    const next = Audio.create({ autoStart: false })
    next.on('error', (error: Error, context: AudioErrorContext) => {
      console.debug('tui audio error', { error, context })
    })
    audio = next
    return next
  } catch (error: unknown) {
    console.debug('failed to create tui audio', { error })
    audio = null
    return null
  }
}

/** Load one sound file, caching both successes and failures. */
export function loadSoundFile(file: string): Promise<AudioSound | null> {
  const current = getAudio()
  if (current === null) return Promise.resolve(null)
  const cached = sounds.get(file)
  if (cached !== undefined) return cached
  const task = readFile(file)
    .then(bytes => current.loadSound(bytes))
    .catch((error: unknown) => {
      console.debug('failed to load tui sound', { file, error })
      return null
    })
  sounds.set(file, task)
  return task
}

/** Play one loaded sound; `null` when the deployment has no audio device. */
export function play(sound: AudioSound, options?: AudioPlayOptions): ReturnType<Audio['play']> | null {
  const current = getAudio()
  if (current === null) return null
  if (!current.isStarted() && !current.start()) return null
  return current.play(sound, options)
}

/** Drop the device and the loaded-sound cache. */
export function dispose(): void {
  audio?.dispose()
  audio = undefined
  sounds.clear()
}
