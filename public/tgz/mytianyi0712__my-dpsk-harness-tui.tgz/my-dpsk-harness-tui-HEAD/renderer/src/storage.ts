/**
 * Local persistence.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, 2.0.32,
 * `packages/tui/src/context/storage.tsx` + `util/persistence.ts` +
 * `packages/util/src/flock.ts`'s acquire/release core), MIT. Registered in NOTICE.md
 * under the `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * The renderer owns the files the upstream TUI owns: tabs, the closed-tab stack, the layout
 * and prompt history. Theme, `new-designs`, and the frontend config stay in the host
 * settings section; nothing here duplicates them.
 *
 * Storage root: `(DSH_HOME ?? ~/.dsh)/state`, channel `deepseek`, so a file is
 * `.../state/deepseek/tui/<key>.json`. Writes are atomic (temporary file + rename) and pass
 * through a cross-process lock, because two terminals may run the same bundle against one
 * home. A read that fails or a file that is not JSON yields the caller's initial value; a
 * failed write is a real rejection, never a silent success.
 *
 * Modifications:
 * - The lock is this bundle's own small directory lease (stale after 60s, 15s wait, 100ms
 *   backoff). Upstream's Flock carries a heartbeat and an Effect wrapper this bundle does not
 *   need: one process writes a file the other only reads. The wait is long enough that a
 *   burst of overlapping saves (the tab strip persists without awaiting) queues instead of
 *   rejecting under load; it is still bounded, and a lease older than 60s is reclaimed.
 * - The `fs.watch` live-reload of upstream is not ported: a second terminal's tab edits are
 *   not a supported workflow here, and a watcher that can throw ENOSPC would only add a
 *   failure mode.
 */

import { mkdirSync, readFileSync } from 'node:fs'
import { appendFile, mkdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'

/** The state root: `$DSH_HOME/state`, defaulting to `~/.dsh/state`. */
export function storageRoot(env: Record<string, string | undefined> = process.env): string {
  return join(env.DSH_HOME ?? join(env.HOME ?? env.USERPROFILE ?? homedir(), '.dsh'), 'state')
}

/** The channel directory under the root. */
export const STORAGE_CHANNEL = 'deepseek'

const STALE_MS = 60_000
const TIMEOUT_MS = 15_000
const BASE_DELAY_MS = 100

/** Read one JSON file, or `undefined` when it is missing or malformed. */
export async function readJsonFile<T>(file: string): Promise<T | undefined> {
  try {
    return JSON.parse(await readFile(file, 'utf8')) as T
  } catch {
    return undefined
  }
}

/** Write one JSON file atomically: a temporary sibling renamed into place. */
export async function writeJsonAtomic(file: string, value: unknown): Promise<void> {
  await mkdir(dirname(file), { recursive: true })
  const temporary = `${file}.${process.pid}.${crypto.randomUUID()}.tmp`
  try {
    await writeFile(temporary, JSON.stringify(value))
    await rename(temporary, file)
  } catch (error: unknown) {
    await rm(temporary, { force: true }).catch(() => undefined)
    throw error
  }
}

/** Append one JSON line (prompt history), creating the directory if needed. */
export async function appendJsonLine(file: string, value: unknown): Promise<void> {
  await mkdir(dirname(file), { recursive: true })
  await appendFile(file, `${JSON.stringify(value)}\n`)
}

/** Read a JSON-lines file; a malformed line is dropped, never fatal. */
export async function readJsonLines<T>(file: string): Promise<T[]> {
  let text: string
  try {
    text = await readFile(file, 'utf8')
  } catch {
    return []
  }
  const values: T[] = []
  for (const line of text.split('\n')) {
    if (line.trim() === '') continue
    try {
      values.push(JSON.parse(line) as T)
    } catch {
      // A half-written last line is what a crash leaves; skip it.
    }
  }
  return values
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

function errorCode(error: unknown): string | undefined {
  const code = typeof error === 'object' && error !== null && 'code' in error ? (error as { code?: unknown }).code : undefined
  return typeof code === 'string' ? code : undefined
}

/**
 * Error codes meaning "another writer holds (or is releasing) the lease".
 *
 * Windows reports a directory that is being deleted as `EPERM`/`EACCES` from `mkdir`, not
 * as `EEXIST`. The release path is `rm(lockDir, { recursive: true })`, so a writer that
 * starts while the previous one is releasing can see that window; treating it as fatal is
 * what produced `Could not save the tab set: EPERM … mkdir 'tabs.json.lock'` when two
 * quick tab saves overlapped. `EBUSY` is the same condition on some filesystems.
 */
export const LOCK_CONTENTION_CODES: readonly string[] = ['EEXIST', 'EPERM', 'EACCES', 'EBUSY']

/** Whether a lease-acquisition failure is contention rather than a real error. */
export function isLockContention(code: string | undefined): boolean {
  return code !== undefined && LOCK_CONTENTION_CODES.includes(code)
}

/** Whether an existing lock directory is older than the stale window. */
async function stale(lockDir: string): Promise<boolean> {
  try {
    const info = await stat(lockDir)
    return Date.now() - info.mtimeMs > STALE_MS
  } catch {
    return false
  }
}

/**
 * Run `task` while holding the directory lock for `file`. The lease is a directory; a lease
 * older than a minute belongs to a crashed writer and is taken over.
 */
export async function withFileLock<T>(file: string, task: () => Promise<T>): Promise<T> {
  const lockDir = `${file}.lock`
  const started = Date.now()
  for (;;) {
    try {
      // A non-recursive `mkdir` is the lease: it fails only when another writer holds the
      // name, and the parent is created on the first miss rather than in a separate await
      // that would let two contenders race past each other.
      await mkdir(lockDir)
      break
    } catch (error: unknown) {
      const code = errorCode(error)
      if (code === 'ENOENT' || code === 'ENOTDIR') {
        await mkdir(dirname(lockDir), { recursive: true })
        continue
      }
      // `EPERM`/`EACCES`/`EBUSY` are contention on Windows (delete-pending directory), not a
      // real permission problem: retry them under the same timeout as `EEXIST`.
      if (!isLockContention(code)) throw error
      if (await stale(lockDir)) {
        await rm(lockDir, { recursive: true, force: true }).catch(() => undefined)
        continue
      }
      if (Date.now() - started > TIMEOUT_MS) throw new Error(`Timed out waiting for the storage lock at ${lockDir}`)
      await sleep(BASE_DELAY_MS)
    }
  }
  try {
    return await task()
  } finally {
    await rm(lockDir, { recursive: true, force: true }).catch(() => undefined)
  }
}

/** The renderer's local file store: one directory, one pending-write set to flush on exit. */
export interface LocalStorage {
  /** Read one stored JSON object (a missing or malformed file yields `undefined`). */
  read: <T>(key: string) => Promise<T | undefined>
  /** Apply a synchronous mutation to the stored object and write it back atomically. */
  update: <T extends object>(key: string, initial: T, mutate: (draft: T) => void) => Promise<T>
  /** Append one prompt-history entry. */
  appendHistory: (entry: unknown) => Promise<void>
  /** The prompt history, oldest first. */
  readHistory: <T>() => Promise<T[]>
  /** Await every write started so far; a failure rejects. */
  flush: () => Promise<void>
  /** The directory the files live in. */
  readonly directory: string
  readonly historyFile: string
}

/** Create the store under `<root>/<channel>/tui`. */
export function createLocalStorage(root: string = storageRoot()): LocalStorage {
  const directory = join(root, STORAGE_CHANNEL, 'tui')
  mkdirSync(directory, { recursive: true })
  const historyFile = join(directory, 'prompt-history.jsonl')
  const pending = new Set<Promise<unknown>>()
  /** History appends are chained: two concurrent appends must land in submission order. */
  let historyChain: Promise<unknown> = Promise.resolve()
  const track = <T>(task: Promise<T>): Promise<T> => {
    pending.add(task)
    void task.then(() => pending.delete(task), () => pending.delete(task))
    return task
  }
  const fileFor = (key: string): string => {
    if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/.test(key)) throw new TypeError(`Invalid storage key: ${key}`)
    return join(directory, `${key}.json`)
  }
  return {
    directory,
    historyFile,
    read: async <T>(key: string) => readJsonFile<T>(fileFor(key)),
    update: <T extends object>(key: string, initial: T, mutate: (draft: T) => void) => track(withFileLock(fileFor(key), async () => {
      const stored = await readJsonFile<T>(fileFor(key))
      const draft = { ...(stored ?? initial) }
      mutate(draft)
      await writeJsonAtomic(fileFor(key), draft)
      return draft
    })),
    appendHistory: entry => {
      const next = historyChain.then(() => appendJsonLine(historyFile, entry))
      historyChain = next.catch(() => undefined)
      return track(next)
    },
    readHistory: <T>() => readJsonLines<T>(historyFile),
    async flush() {
      const failures: unknown[] = []
      while (pending.size > 0) {
        const results = await Promise.allSettled([...pending])
        failures.push(...results.filter(result => result.status === 'rejected').map(result => result.reason))
      }
      if (failures.length === 1) throw failures[0]
      if (failures.length > 1) throw new AggregateError(failures, 'Storage writes failed')
    },
  }
}

/** Read one file synchronously (a stored tab set restored before the first frame). */
export function readJsonFileSync<T>(file: string): T | undefined {
  try {
    return JSON.parse(readFileSync(file, 'utf8')) as T
  } catch {
    return undefined
  }
}
