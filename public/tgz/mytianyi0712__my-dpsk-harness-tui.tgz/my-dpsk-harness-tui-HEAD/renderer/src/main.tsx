/**
 * Renderer entry point.
 *
 * Order matters: the renderer announces itself over IPC **before** it creates the
 * CLI renderer, so a renderer that is rejected on protocol version or missing
 * capabilities never touches the terminal. The host authorizes the handoff by
 * answering `hello-ack` with a compatible status; only then does the renderer
 * take the TTY.
 *
 * One message dispatcher is registered once, before the handshake, and it is the
 * only place that applies a downstream envelope to the store. A second dispatcher
 * would apply every envelope twice, which opens every dialog twice and doubles the
 * resize listeners each dialog subscribes. It also keeps the window between the
 * handshake resolving and a listener being registered empty: nothing is lost.
 *
 * Shutdown paths:
 * - `bye` from the host → destroy the renderer (OpenTUI emits the terminal
 *   restore sequence) and exit 0. A `bye` that arrives before the renderer exists
 *   exits directly; one that arrives during startup is checked after the renderer
 *   is created.
 * - Ctrl+C → the keymap's `cancel` action (clear the draft or dialog, then exit from an
 *   empty idle prompt via `bye`); `exitOnCtrlC` is off so OpenTUI never exits behind it.
 * - The host kills the renderer → the process dies; the host is responsible for
 *   emitting the restore sequence on child exit (see `src/host/renderer-process.ts`).
 */

import { createCliRenderer, type CliRenderer } from '@opentui/core'
import { render } from '@opentui/solid'
import { RENDERER_PROTOCOL_VERSION, RENDERER_CAPABILITIES, type HelloAckPayload, type IpcEnvelope } from './protocol/kinds.ts'
import { decodeEnvelope, rendererChannel, sendEnvelope } from './ipc/channel.ts'
import { Shell, createAppStore, type AppStore } from './app.tsx'
import { ThemeProvider, useThemes } from './theme/provider.tsx'
import { registerActiveTheme } from './theme/paths.ts'
import { onCleanup, onMount } from '#solid'
import { createKeymap, LEADER_TIMEOUT_MS } from './keymap/keymap.ts'

const RENDERER_ID = 'dpsk-renderer'
const RENDERER_VERSION = '0.5.0'

/**
 * The full terminal restore. `renderer.destroy()` covers most of it, but OpenTUI leaves the
 * mouse-tracking modes to `disableMouse`; asserting them here means a quit can never hand
 * back a shell that echoes `[555;109;10M` on every mouse move. Same sequence the host
 * writes when the renderer dies before it can clean up (`src/host/renderer-process.ts`).
 */
const TERMINAL_RESTORE =
  '\x1b[0m\x1b[?1000l\x1b[?1002l\x1b[?1003l\x1b[?1006l\x1b[?2004l\x1b[?2027l\x1b[?2031l\x1b[2J\x1b[H\x1b[?1049l\x1b[?25h\x1b]0;\x07'

/**
 * Bun closes the child's IPC channel the first time the process writes to fd 2, so the
 * renderer must never write to stderr. A Node warning printed on stderr
 * (`MaxListenersExceededWarning`, an unhandled rejection report) silently cuts the host
 * off from the renderer: the renderer process stays alive, keeps painting, keeps taking
 * keystrokes, and the host's next `send` throws `ERR_IPC_CHANNEL_CLOSED`. Every stderr
 * write is routed into the store's notice block instead, so a warning is visible on
 * screen and the channel stays open. Writes that happen before the store exists are
 * buffered and flushed when it does.
 */
const stderrBuffer: string[] = []
function routeStderrToNotices(store: AppStore): void {
  process.stderr.write = ((chunk: unknown) => {
    const text = typeof chunk === 'string' ? chunk : Buffer.from(chunk as Uint8Array).toString('utf8')
    const trimmed = text.trim()
    if (trimmed !== '') store.pushNotice('error', trimmed)
    return true
  }) as typeof process.stderr.write
  for (const text of stderrBuffer) {
    const trimmed = text.trim()
    if (trimmed !== '') store.pushNotice('error', trimmed)
  }
  stderrBuffer.length = 0
}

function fail(message: string): never {
  // Before the renderer owns the terminal, stdout is the terminal, so a plain-text
  // report is visible there. Writing the same report to stderr would close the IPC
  // channel on the way out.
  process.stdout.write(`dpsk-renderer: ${message}\n`)
  process.exit(1)
}

const channel = rendererChannel() ?? fail('no IPC channel; the renderer must be spawned by the launcher with stdio: [inherit, inherit, ipc]')

// The warning that closes the channel is emitted by the process emitter when a listener
// burst crosses the default limit of 10. Raising the limit keeps a burst of dialog
// subscriptions from printing it at all.
process.setMaxListeners(0)

// The renderer sends one envelope at a time, so the sequence number continues from
// the `hello` (seq 0) that opened the channel.
let nextSeq = 1

/** Send one envelope upstream and return the sequence it went out on, so a
 * request can be matched with the host's answer. */
function send(kind: string, payload: unknown): number {
  const seq = nextSeq
  nextSeq += 1
  sendEnvelope(channel, seq, kind, payload)
  return seq
}

/** Bridges the provider's resolved tokens to the store's path-based color helpers. */
function ThemeShell(props: { store: AppStore }) {
  const themes = useThemes()
  registerActiveTheme(() => themes.currentTokens())
  // A theme failure (a malformed custom file, a discovery error) is a real notice, not a
  // silent fallback: the provider reports it and the shell paints it.
  onMount(() => themes.onError(error => props.store.pushNotice('error', `theme: ${error.message}`)))
  onCleanup(() => registerActiveTheme(undefined))
  return <Shell store={props.store} />
}

// The store is created before anything else can report; a settings write that the host
// never confirmed names the channel in the notice the store itself raises.
const store = createAppStore(send, undefined, () => { void shutdown('renderer exit') })
routeStderrToNotices(store)
/**
 * The one shutdown path: flush the renderer's local files, dispose the clipboard and the
 * audio device, then destroy the renderer (which emits the terminal restore) and exit.
 *
 * Idempotent by construction: a second call (the host's `bye` followed by the channel
 * closing, or a Ctrl+C) returns the same promise instead of disposing twice.
 */
let shuttingDown: Promise<void> | undefined
function shutdown(reason: string): Promise<void> {
  if (shuttingDown !== undefined) return shuttingDown
  shuttingDown = (async () => {
    /**
     * Exit only after the terminal restore is on the wire. `renderer.destroy()` writes the
     * leave-alt-screen sequence through the TTY stream, which is asynchronous: an immediate
     * `process.exit` drops those bytes and leaves the user's shell painting on the alternate
     * screen (the last painted frame stays visible). The write callback is the flush point.
     */
    const finish = (code: number): Promise<void> => new Promise(resolve => {
      process.stdout.write('', () => {
        resolve()
        process.exit(code)
      })
    })
    // Restore the terminal *before* anything that yields. The host exits on the `bye` this
    // process already sent, so a restore that lands after the shell prompt would erase the
    // prompt; writing it first makes the order deterministic. Clear the frame while it is
    // still the visible buffer, then assert the full restore: leaving the alternate screen
    // alone is not "restored" — OpenTUI's mouse-tracking modes have to be off too, or the
    // shell that gets the TTY back echoes `[555;109;10M` on every mouse move.
    process.stdout.write('\x1b[2J\x1b[H')
    renderer?.destroy()
    process.stdout.write(TERMINAL_RESTORE)
    try {
      await store.flushLocalState()
    } catch (error: unknown) {
      // A storage failure is reported but must not keep the terminal hostage.
      // The render tree is already gone, so this goes to the plain terminal instead of
      // the store's notice block.
      process.stdout.write(`dpsk-renderer: could not flush state (${reason}): ${error instanceof Error ? error.message : String(error)}` + '\n')
    }
    try {
      await store.disposeServices()
    } catch {
      // Disposal is best-effort: the terminal is already restored.
    }
    await finish(0)
  })()
  return shuttingDown
}

process.once('disconnect', () => {
  store.rejectPendingRequests('renderer IPC channel closed')
  // The host is gone; leaving the terminal in the alternate screen would strand the shell.
  void shutdown('host disconnected')
})

// The renderer is created after the handshake, so a `bye` that arrives during startup
// has to be remembered and acted on once the renderer exists.
let renderer: CliRenderer | undefined
let byeSeen = false

const ack = new Promise<IpcEnvelope>((resolve, reject) => {
  const timer = setTimeout(() => reject(new Error('timed out waiting for hello-ack')), 15000)
  channel.onMessage(line => {
    const envelope = decodeEnvelope(line)
    if (envelope === undefined) return
    store.apply(envelope)
    if (envelope.kind === 'hello-ack') {
      clearTimeout(timer)
      resolve(envelope)
    }
    if (envelope.kind === 'bye') {
      byeSeen = true
      // After the renderer exists it shuts down through its own destroy path, which
      // emits the terminal restore sequence. Before it exists there is no terminal to
      // restore, so exiting directly is correct. `shutdown` is idempotent: the host can
      // send `bye` and then close the channel, and only the first call tears anything down.
      if (renderer !== undefined) void shutdown('host bye')
    }
  })
})

// Announce before touching the terminal: the host decides whether the renderer
// may take the TTY, and a rejected renderer must leave the terminal untouched.
sendEnvelope(channel, 0, 'hello', {
  protocolVersion: RENDERER_PROTOCOL_VERSION,
  rendererId: RENDERER_ID,
  rendererVersion: RENDERER_VERSION,
  capabilities: [...RENDERER_CAPABILITIES],
  kinds: [
    'hello-ack', 'session-snapshot', 'selection-state', 'session-frame', 'session-list', 'model-catalog', 'provider-catalog',
    'reasoning-efforts', 'workspace-files', 'permission-presets', 'agent-presets', 'settings', 'i18n',
    'command-result', 'command-catalog', 'dialog-response', 'boot-notice', 'question-request', 'question-close', 'question-result', 'approval-request', 'approval-close', 'turn-state',
    'wechat-output', 'form-spec', 'subagent-list', 'skills-list', 'model-discovery',
    'model-list', 'log', 'bye', 'usage', 'git-branch', 'mcp-servers', 'host-plugins', 'todos', 'shell-jobs', 'interject-list',
    'terminal-frame', 'terminal-end', 'extension-dialog',
    'hello', 'send-message', 'interject-edit', 'interject-delete', 'attachment-read', 'session-op', 'set-selection', 'update-settings',
    'shell-job-op', 'terminal-op',
    'dialog-request', 'form-submit', 'question-answer', 'approval-answer', 'model-discover', 'model-list-request',
    'model-edit', 'wechat-op', 'doctor-check', 'terminal-scheme', 'terminal-size', 'bye', 'interrupt', 'question-timeout',
    'shortcut', 'extension-dialog-response',
  ],
})

const ackEnvelope = await ack
const payload = ackEnvelope.payload as Partial<HelloAckPayload>
if (ackEnvelope.protocolVersion !== RENDERER_PROTOCOL_VERSION) {
  fail(`host protocol version ${ackEnvelope.protocolVersion} does not match renderer version ${RENDERER_PROTOCOL_VERSION}`)
}
if (payload.status !== 'compatible' && payload.status !== 'compatible_degraded') {
  fail(`host refused the handoff (${payload.status ?? 'unknown'}): ${(payload.reasons ?? []).join('; ')}`)
}

// The grid the renderer starts with: the host echoes the `COLUMNS` / `LINES` it inherited in
// the ack, and the renderer inherits the same environment. OpenTUI measures the TTY itself, so
// this is only the seed — it matters when stdout is piped and there is no TTY to query, where
// the renderer would otherwise default to 80x24.
const ackGrid = payload.terminalSize
const envGrid = { width: Number(process.env.COLUMNS), height: Number(process.env.LINES) }
const seed = ackGrid !== undefined && ackGrid.width > 0 && ackGrid.height > 0
  ? ackGrid
  : envGrid.width > 0 && envGrid.height > 0 ? envGrid : undefined
if (seed !== undefined) store.setTerminalSize(seed)
renderer = await createCliRenderer({
  // Ctrl+C is the keymap's `cancel` action: it clears the draft or the dialog first and
  // exits only from an empty, idle prompt (upstream's prompt/modal priority).
  exitOnCtrlC: false,
  ...(seed === undefined ? {} : { width: seed.width, height: seed.height }),
})
// Each open dialog subscribes a resize listener through `useTerminalDimensions`, and a
// nested flow (provider form → model list → model form) crosses the default limit of 10.
// The warning that limit prints goes to stderr, and a stderr write closes the IPC
// channel, so the renderer's emitter gets an unbounded listener count.
renderer.setMaxListeners(0)
// Publish the measured grid: the store's geometry gates read it, and the host keeps the latest
// value for its own layout decisions. The renderer owns the TTY, so it is the only side that
// can measure the grid.
const publishSize = (width: number, height: number): void => {
  store.setTerminalSize({ width, height })
  send('terminal-size', { width, height })
}
publishSize(renderer.width, renderer.height)
renderer.on('resize', (width: number, height: number) => publishSize(width, height))
if (byeSeen) {
  await shutdown('host bye before mount')
}

// The keymap is attached after the renderer exists: key events only reach the
// renderer once it owns the TTY, and the store's actions are all upstream requests.
// The leader window length comes from the imported settings when the user set one.
//
// No `preventDefault` here: OpenTUI routes a bound key to the focused renderable anyway
// (the textarea binds `up`/`down` for its own caret), and a global handler that swallowed
// the key would also stop the caret from moving. The history keys guard themselves — the
// store only recalls at the first/last line — so both readers can see the event.
const configuredLeaderTimeout = store.settings().leaderTimeout
const keymap = createKeymap(
  action => store.runAction(action),
  typeof configuredLeaderTimeout === 'number' ? configuredLeaderTimeout : LEADER_TIMEOUT_MS,
  undefined,
  () => store.keyLayer(),
  action => action !== 'terminal.toggle' || store.availableActions().includes('terminal.toggle'),
)
renderer.keyInput.on('keypress', key => {
  if (store.handleTerminalKey(key, keymap.leaderIsOpen())) return
  // The shell's own bindings win: a chord the keymap consumed never goes upstream as a
  // plugin shortcut, so `ctrl+p` cannot also fire a plugin registration.
  if (keymap.handle(key)) return
  // Plugin shortcuts (tuiShortcuts) are registered in the host, so an unconsumed modified
  // keypress goes upstream as the canonical combo; the host dispatches a registration hit.
  if (key.ctrl || key.meta || key.shift) {
    const mods: string[] = []
    if (key.ctrl) mods.push('ctrl')
    if (key.meta) mods.push('alt')
    if (key.shift) mods.push('shift')
    send('shortcut', { combo: `${mods.join('+')}+${key.name.toLowerCase()}` })
  }
})

await render(() => (
  <ThemeProvider
    storage={store.themeStorage()}
    mode={renderer?.themeMode ?? 'dark'}
  >
    <ThemeShell store={store} />
  </ThemeProvider>
), renderer)

/** The scheme the terminal's default background implies. */
function schemeFromBackground(hex: string | null): 'dark' | 'light' {
  if (hex === null) return 'dark'
  const r = parseInt(hex.slice(1, 3), 16)
  const g = parseInt(hex.slice(3, 5), 16)
  const b = parseInt(hex.slice(5, 7), 16)
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 < 0.5 ? 'dark' : 'light'
}

// Report the terminal's color scheme: in `dynamic` theme mode the host answers by
// sending the dark or light member of the configured pair. The palette query is
// best effort — a terminal that does not answer the OSC 11 query leaves the host on
// its own default, so a failure here is not fatal.
try {
  const colors = await renderer.getPalette({ size: 256 })
  sendEnvelope(channel, nextSeq++, 'terminal-scheme', { scheme: schemeFromBackground(colors.defaultBackground) })
} catch {
  sendEnvelope(channel, nextSeq++, 'terminal-scheme', { scheme: 'dark' })
}

// Keep the process alive: the renderer's event loop owns the TTY until `bye`.
// The single dispatcher above handles `bye` for the whole life of the process.
await new Promise(() => undefined)
