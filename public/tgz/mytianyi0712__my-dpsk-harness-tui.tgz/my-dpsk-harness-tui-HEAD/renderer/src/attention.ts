/**
 * Attention notifications and sounds.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, 2.0.32, `packages/tui/src/attention.ts` +
 * `context/attention.tsx`), MIT. Registered in NOTICE.md under the `opencode` entry;
 * verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications:
 * - Upstream's Solid context provider is not ported: the store creates the service once, so
 *   a provider would be a second place to find it.
 * - The default notification title is the product name this bundle paints (`deepseek`).
 * - Sound names are validated by a local list rather than an Effect schema: the resolved
 *   config already carries only the names this bundle knows.
 *
 * Behaviour that is upstream's, not this package's:
 * - Notifications and sounds are off until the settings enable them; a disabled request
 *   reports `attention_disabled` instead of pretending to have fired.
 * - Focus is tracked from the renderer's own `focus` / `blur` events; a request with
 *   `when: "blurred"` is skipped while the terminal is focused, and one with
 *   `when: "focused"` is skipped while it is not.
 * - While the focus state is still unknown (no event yet, or a terminal that never reports
 *   one), `when: "blurred"` fires rather than skipping: a turn finishing in a terminal that
 *   cannot report focus is exactly the case the notification exists for.
 * - Message and title are stripped of ANSI and control characters and cut to 240 / 80
 *   characters; an empty message is not sent.
 * - A sound falls back from the configured override to the bundled file, and a platform
 *   with no audio device reports `sound: false` instead of an error.
 */

import stripAnsi from 'strip-ansi'
import * as TuiAudio from './audio.ts'

/** How a request is limited to a focus state. */
export type AttentionWhen = 'always' | 'focused' | 'blurred'

/** Why a request did not fire. */
export type AttentionNotifySkipReason = 'attention_disabled' | 'renderer_destroyed' | 'empty_message' | 'focused' | 'blurred' | 'focus_unknown'

/** The settings the service reads. */
export interface AttentionConfig {
  readonly notifications: boolean
  readonly sound: boolean
  readonly volume: number
  readonly sounds: Partial<Record<TuiAudio.AttentionSoundName, string>>
}

export interface AttentionRequest {
  readonly title?: string
  readonly message: string
  readonly notification?: false | { readonly when?: AttentionWhen }
  readonly sound?: false | true | { readonly volume?: number; readonly when?: AttentionWhen; readonly name?: TuiAudio.AttentionSoundName }
}

export interface AttentionResult {
  readonly ok: boolean
  readonly notification: boolean
  readonly sound: boolean
  readonly skipped?: AttentionNotifySkipReason
}

/** The renderer surface attention needs; a narrow type keeps the service testable. */
export interface AttentionRenderer {
  readonly isDestroyed: boolean
  on: (event: 'focus' | 'blur', listener: () => void) => unknown
  off: (event: 'focus' | 'blur', listener: () => void) => unknown
  triggerNotification: (message: string, title?: string) => boolean
}

export interface Attention {
  notify: (request: AttentionRequest) => Promise<AttentionResult>
  dispose: () => void
}

const DEFAULT_TITLE = 'deepseek'
const TITLE_LIMIT = 80
const MESSAGE_LIMIT = 240

function skipped(reason: AttentionNotifySkipReason): AttentionResult {
  return { ok: false, notification: false, sound: false, skipped: reason }
}

function normalizeText(input: string | undefined, fallback: string, limit: number): string {
  const text = stripAnsi(input ?? '')
    .replace(/[ \t]*[\r\n]+[ \t]*/g, ' ')
    .replace(/[\u0000-\u0009\u000B\u000C\u000E-\u001F\u007F-\u009F]/g, '')
    .trim()
  const normalized = text.length > 0 ? text : fallback
  return Array.from(normalized).slice(0, limit).join('')
}

function clampVolume(volume: number): number {
  if (!Number.isFinite(volume)) return 0
  return Math.min(1, Math.max(0, volume))
}

type FocusState = 'unknown' | 'focused' | 'blurred'

function focusSkip(when: AttentionWhen, focus: FocusState): AttentionNotifySkipReason | undefined {
  if (when === 'always') return undefined
  // Unknown focus only suppresses the `focused` variant: it cannot be shown to be focused.
  if (focus === 'unknown') return when === 'focused' ? 'focus_unknown' : undefined
  if (when === 'blurred' && focus === 'focused') return 'focused'
  if (when === 'focused' && focus === 'blurred') return 'blurred'
  return undefined
}

/** Whether this request asks for a sound, and at what volume. */
function soundVolume(request: AttentionRequest, config: AttentionConfig): number | undefined {
  if (!config.sound) return undefined
  if (request.sound === false) return undefined
  if (request.sound === true) return clampVolume(config.volume)
  if (request.sound === undefined) return clampVolume(config.volume)
  return clampVolume(request.sound.volume ?? config.volume)
}

/** Create the attention service for one renderer. */
export function createTuiAttention(input: {
  renderer: AttentionRenderer
  config: AttentionConfig
  audio?: Pick<typeof TuiAudio, 'loadSoundFile' | 'play'>
}): Attention {
  let focus: FocusState = 'unknown'
  let disposed = false
  const audio = input.audio ?? TuiAudio

  const onFocus = (): void => {
    focus = 'focused'
  }
  const onBlur = (): void => {
    focus = 'blurred'
  }
  input.renderer.on('focus', onFocus)
  input.renderer.on('blur', onBlur)

  const soundCandidates = (name: TuiAudio.AttentionSoundName): string[] =>
    [input.config.sounds[name], TuiAudio.BUILTIN_SOUNDS[name]].filter(
      (item, index, list): item is string => typeof item === 'string' && list.indexOf(item) === index,
    )

  const playSound = async (name: TuiAudio.AttentionSoundName, volume: number): Promise<boolean> => {
    try {
      for (const file of soundCandidates(name)) {
        const current = await audio.loadSoundFile(file).catch((error: unknown) => {
          console.debug('failed to load attention sound', { file, error })
          return null
        })
        if (disposed) return false
        if (current === null) continue
        if (audio.play(current, { volume }) !== null) return true
      }
      return false
    } catch (error: unknown) {
      console.debug('failed to play attention sound', { error })
      return false
    }
  }

  return {
    async notify(request) {
      try {
        if (!input.config.notifications && !input.config.sound) return skipped('attention_disabled')
        if (disposed || input.renderer.isDestroyed) return skipped('renderer_destroyed')
        const message = normalizeText(request.message, '', MESSAGE_LIMIT)
        if (message === '') return skipped('empty_message')
        const requestedNotification = typeof request.notification === 'object' ? request.notification : undefined
        const notificationSkip = focusSkip(requestedNotification?.when ?? 'blurred', focus)
        const notificationRequested = input.config.notifications && request.notification !== false
        const shouldNotify = notificationRequested && notificationSkip === undefined
        const notification = shouldNotify
          ? (() => {
              try {
                return input.renderer.triggerNotification(message, normalizeText(request.title, DEFAULT_TITLE, TITLE_LIMIT))
              } catch (error: unknown) {
                console.debug('failed to trigger attention notification', { error })
                return false
              }
            })()
          : false
        const volume = soundVolume(request, input.config)
        const requestedSound = typeof request.sound === 'object' ? request.sound : undefined
        const soundSkip = volume === undefined ? undefined : focusSkip(requestedSound?.when ?? 'always', focus)
        const soundName = requestedSound?.name ?? 'default'
        const sound = volume === undefined || soundSkip !== undefined ? false : await playSound(soundName, volume)
        if (!notification && !sound) {
          if (notificationRequested && notificationSkip !== undefined) return skipped(notificationSkip)
          if (soundSkip !== undefined) return skipped(soundSkip)
        }
        return { ok: notification || sound, notification, sound }
      } catch (error: unknown) {
        console.debug('failed to handle attention notification', { error })
        return { ok: false, notification: false, sound: false }
      }
    },
    dispose() {
      if (disposed) return
      disposed = true
      input.renderer.off('focus', onFocus)
      input.renderer.off('blur', onBlur)
    },
  }
}
