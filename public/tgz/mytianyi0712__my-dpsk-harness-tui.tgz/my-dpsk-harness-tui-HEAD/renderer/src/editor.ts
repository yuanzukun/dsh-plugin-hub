/**
 * The external editor.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, 2.0.32, `packages/tui/src/editor.ts`), MIT.
 * Registered in NOTICE.md under the `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications:
 * - Upstream's `.claude/ide` lock-file discovery and the Zed SQLite selection lookup are not
 *   ported: they are another product's editor integration, and dsh has no caller for a
 *   selection range. `openEditor` itself is the whole supported surface.
 *
 * Behaviour that is upstream's, not this package's:
 * - `$VISUAL` wins over `$EDITOR`; a missing editor is a real error, not a silent no-op.
 * - The draft goes to a temporary Markdown file; the renderer is suspended (and the buffer
 *   cleared) before the child inherits the TTY, and resumed in `finally` so a failed editor
 *   never leaves the screen blank.
 * - A non-zero exit is reported with its code or signal, and the file is removed either way.
 */

import { existsSync } from 'node:fs'
import { readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawn } from 'node:child_process'

/** The renderer surface the editor needs; a narrower type keeps tests independent of OpenTUI. */
export interface EditorRenderer {
  suspend: () => void
  resume: () => void
  requestRender: () => void
  readonly currentRenderBuffer: { clear: () => void }
}

/** Open the user's editor on `value`; returns the edited text, or `undefined` when emptied. */
export async function openEditor(input: {
  value: string
  renderer: EditorRenderer
  cwd?: string
  stdin?: 'inherit' | 'pipe' | 'ignore'
}): Promise<string | undefined> {
  const editor = process.env.VISUAL || process.env.EDITOR
  if (!editor) throw new Error('Set $VISUAL or $EDITOR to open an external editor')
  const file = join(tmpdir(), `${Date.now()}.md`)
  await writeFile(file, input.value)
  input.renderer.suspend()
  input.renderer.currentRenderBuffer.clear()
  try {
    await new Promise<void>((resolve, reject) => {
      const parts = editor.split(' ')
      const child = spawn(parts[0]!, [...parts.slice(1), file], {
        cwd: input.cwd !== undefined && existsSync(input.cwd) ? input.cwd : process.cwd(),
        stdio: [input.stdin ?? 'inherit', 'inherit', 'inherit'],
        shell: process.platform === 'win32',
      })
      child.on('error', reject)
      child.on('exit', (code, signal) => {
        if (code === 0) {
          resolve()
          return
        }
        reject(new Error(`Editor exited with ${signal ? `signal ${signal}` : `code ${code}`}`))
      })
    })
    return (await readFile(file, 'utf8')) || undefined
  } finally {
    await rm(file, { force: true }).catch(() => undefined)
    input.renderer.currentRenderBuffer.clear()
    input.renderer.resume()
    input.renderer.requestRender()
  }
}
