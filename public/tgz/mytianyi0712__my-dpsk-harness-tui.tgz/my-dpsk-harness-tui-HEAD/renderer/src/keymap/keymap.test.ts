/**
 * Keymap tests.
 *
 * The leader window is driven with an injected scheduler so the timeout is asserted
 * without waiting 2000ms: `schedule` returns the cancel function, and the test
 * triggers the expiry by hand.
 */

import { expect, test } from 'bun:test'
import { BINDINGS, createKeymap, keyLabel, LEADER, LEADER_TIMEOUT_MS } from './keymap.ts'

const key = (name: string, modifiers: { ctrl?: boolean; shift?: boolean; meta?: boolean } = {}) => ({
  name,
  ctrl: modifiers.ctrl === true,
  shift: modifiers.shift === true,
  meta: modifiers.meta === true,
})

test('keyLabel builds the binding spelling from modifiers', () => {
  expect(keyLabel(key('x', { ctrl: true }))).toBe('ctrl+x')
  expect(keyLabel(key('P', { ctrl: true, shift: true }))).toBe('ctrl+shift+p')
  expect(keyLabel(key('enter'))).toBe('enter')
  expect(keyLabel(key('a', { meta: true }))).toBe('meta+a')
})

test('the binding table covers the leader chords and the two single keys', () => {
  expect(BINDINGS[LEADER + ' n']).toBe('new-session')
  expect(BINDINGS[LEADER + ' l']).toBe('list-sessions')
  expect(BINDINGS[LEADER + ' m']).toBe('pick-model')
  expect(BINDINGS[LEADER + ' t']).toBe('terminal.toggle')
  expect(BINDINGS[LEADER + ' c']).toBe('compact')
  expect(BINDINGS[LEADER + ' x']).toBe('export')
  expect(BINDINGS[LEADER + ' e']).toBe('open-editor')
  expect(BINDINGS[LEADER + ' y']).toBe('copy-message')
  expect(BINDINGS[LEADER + ' q']).toBe('exit')
  expect(BINDINGS['ctrl+p']).toBe('palette')
  expect(BINDINGS['ctrl+t']).toBe('cycle-effort')
  expect(BINDINGS['ctrl+1']).toBe('select-session-1')
  expect(BINDINGS['ctrl+0']).toBe('select-session-0')
  expect(LEADER_TIMEOUT_MS).toBe(2000)
})

test('a leader chord resolves to its action', () => {
  const dispatched: string[] = []
  const keymap = createKeymap(action => dispatched.push(action))
  keymap.handle(key('x', { ctrl: true }))
  expect(keymap.leaderIsOpen()).toBe(true)
  keymap.handle(key('t'))
  expect(dispatched).toEqual(['terminal.toggle'])
  expect(keymap.leaderIsOpen()).toBe(false)
})

test('an unknown chord closes the window and dispatches nothing', () => {
  const dispatched: string[] = []
  const keymap = createKeymap(action => dispatched.push(action))
  keymap.handle(key('x', { ctrl: true }))
  keymap.handle(key('z'))
  expect(dispatched).toEqual([])
  expect(keymap.leaderIsOpen()).toBe(false)
  // The window is closed, so the next keystroke is read as a fresh key: `ctrl+t`
  // after a stray `ctrl+x z` still cycles the effort.
  keymap.handle(key('t', { ctrl: true }))
  expect(dispatched).toEqual(['cycle-effort'])
})

test('the leader window times out when the second key never arrives', () => {
  const dispatched: string[] = []
  let expiry: (() => void) | undefined
  const keymap = createKeymap(action => dispatched.push(action), 2000, (fn, ms) => {
    expect(ms).toBe(2000)
    expiry = fn
    return () => { expiry = undefined }
  })
  keymap.handle(key('x', { ctrl: true }))
  expect(keymap.leaderIsOpen()).toBe(true)
  expect(expiry).toBeDefined()
  expiry?.()
  expect(keymap.leaderIsOpen()).toBe(false)
  keymap.handle(key('n'))
  expect(dispatched).toEqual([])
})

test('dispose cancels a pending leader window', () => {
  let cancelled = false
  const keymap = createKeymap(() => undefined, 2000, () => () => { cancelled = true })
  keymap.handle(key('x', { ctrl: true }))
  keymap.dispose()
  expect(cancelled).toBe(true)
  expect(keymap.leaderIsOpen()).toBe(false)
})

test('single-key bindings dispatch without a leader', () => {
  const dispatched: string[] = []
  const keymap = createKeymap(action => dispatched.push(action))
  keymap.handle(key('p', { ctrl: true }))
  keymap.handle(key('t', { ctrl: true }))
  expect(dispatched).toEqual(['palette', 'cycle-effort'])
})

test('ctrl+c is the cancel binding and the layer fall-through still reaches it', () => {
  expect(BINDINGS['ctrl+c']).toBe('cancel')
  const dispatched: string[] = []
  const keymap = createKeymap(action => dispatched.push(action), LEADER_TIMEOUT_MS, undefined, () => 'composer')
  // The composer layer has no `ctrl+c`, so it falls through to the global table.
  expect(keymap.handle(key('c', { ctrl: true }))).toBe(true)
  expect(dispatched).toEqual(['cancel'])
})

test('leader chords are consumed even when the action is gated off', () => {
  const dispatched: string[] = []
  const keymap = createKeymap(action => dispatched.push(action), LEADER_TIMEOUT_MS, undefined, () => 'session', () => false)
  keymap.handle(key('x', { ctrl: true }))
  expect(keymap.handle(key('t'))).toBe(true)
  expect(dispatched).toEqual([])
})
