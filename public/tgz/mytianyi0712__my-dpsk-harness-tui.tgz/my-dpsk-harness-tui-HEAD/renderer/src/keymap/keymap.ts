/**
 * The renderer keymap: leader `ctrl+x` chords, `ctrl+p` command palette, `ctrl+t`
 * effort cycle.
 *
 * Ported from opencode (`anomalyco/opencode`, v2.0.30, `packages/tui/src/config/keybind.ts`
 * and `context/keymap.tsx`), MIT. Registered in NOTICE.md under the `opencode`
 * entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * The binding table is opencode v2's leader vocabulary, narrowed to the actions the
 * dsh harness can actually perform through IPC: there is no git snapshot layer in the
 * harness, so `/undo` and `/redo` are not offered, and no fake implementation is
 * wired. The leader is a plain state machine rather than `@opentui/keymap`'s full
 * layer registry: the renderer has one focused input (the composer) and a handful of
 * chords, and a state machine is testable with `createTestRenderer` + `pressKey`.
 *
 * A leader key opens a window (`leader_timeout`, default 2000ms). The next key is
 * read as the chord; a chord that is not in the table closes the window and consumes
 * nothing, so a stray `ctrl+x z` cannot swallow the following keystrokes.
 *
 * `ctrl+c` is a binding, not a process signal: upstream clears the draft or the
 * selection first, closes the top modal next, and exits only when the prompt is empty and
 * nothing is open. The renderer's `exitOnCtrlC` is therefore off, and the `cancel` action
 * decides which of those three happened.
 */

/** The shape of a key event the renderer reads from `renderer.keyInput`. */
export interface KeyEventLike {
  preventDefault?: () => void
  readonly name: string
  readonly ctrl: boolean
  readonly shift: boolean
  readonly meta: boolean
}

/** The leader key. opencode v2 uses `ctrl+x` for the leader prefix. */
export const LEADER = 'ctrl+x'

/** The command palette. A new capability for dsh: the pi-tui TUI has no palette. */
export const PALETTE = 'ctrl+p'

/** Cycle the reasoning effort. Maps to `set-selection { effort }`. */
export const CYCLE_EFFORT = 'ctrl+t'

/** Paste: read the system clipboard and add its image or text to the draft. */
export const PASTE = 'ctrl+v'

/** Cancel: clear a draft or selection first, close a dialog next, and only then exit. */
export const CANCEL = 'ctrl+c'

/** The layers the keymap routes through, in the order the store resolves them. */
export type KeyLayer = 'global' | 'session' | 'composer' | 'autocomplete' | 'modal'

/** Chord → action id. The action ids are the store's `runAction` vocabulary. The leader
 * table is the session layer's chord vocabulary; `leader t` is the real terminal pane
 * action and is offered only when the host reports its controller capability. */
export const BINDINGS: Record<string, string> = {
  [CANCEL]: 'cancel',
  [PASTE]: 'paste-clipboard',
  [PALETTE]: 'palette',
  [CYCLE_EFFORT]: 'cycle-effort',
  [`${LEADER} n`]: 'new-session',
  [`${LEADER} l`]: 'list-sessions',
  [`${LEADER} m`]: 'pick-model',
  [`${LEADER} t`]: 'terminal.toggle',
  [`${LEADER} c`]: 'compact',
  [`${LEADER} s`]: 'settings',
  [`${LEADER} x`]: 'export',
  [`${LEADER} e`]: 'open-editor',
  [`${LEADER} y`]: 'copy-message',
  [`${LEADER} q`]: 'exit',
  [`${LEADER} b`]: 'toggle-sidebar',
  [`${LEADER} w`]: 'close-session-tab',
  'ctrl+shift+t': 'reopen-session-tab',
  'meta+down': 'next-tab',
  'meta+up': 'previous-tab',
  [`${LEADER} 1`]: 'select-session-1',
  [`${LEADER} 2`]: 'select-session-2',
  [`${LEADER} 3`]: 'select-session-3',
  [`${LEADER} 4`]: 'select-session-4',
  [`${LEADER} 5`]: 'select-session-5',
  [`${LEADER} 6`]: 'select-session-6',
  [`${LEADER} 7`]: 'select-session-7',
  [`${LEADER} 8`]: 'select-session-8',
  [`${LEADER} 9`]: 'select-session-9',
  'ctrl+1': 'select-session-1',
  'ctrl+2': 'select-session-2',
  'ctrl+3': 'select-session-3',
  'ctrl+4': 'select-session-4',
  'ctrl+5': 'select-session-5',
  'ctrl+6': 'select-session-6',
  'ctrl+7': 'select-session-7',
  'ctrl+8': 'select-session-8',
  'ctrl+9': 'select-session-9',
  'ctrl+0': 'select-session-0',
}

/**
 * The modal bindings a dialog owns while it is open.
 *
 * The store routes these to the controller the active dialog registered; with no
 * dialog open the controller is undefined and every one of them is a no-op, so
 * the same table serves the composer later (`up` becomes prompt history in S6).
 * `meta` is the Alt key: `alt+up` / `alt+down` jump between category sections,
 * matching opencode's `dialog.select.section_*`.
 */
export const MODAL_BINDINGS: Record<string, string> = {
  up: 'dialog-prev',
  down: 'dialog-next',
  pageup: 'dialog-page-up',
  pagedown: 'dialog-page-down',
  home: 'dialog-home',
  end: 'dialog-end',
  left: 'dialog-left',
  right: 'dialog-right',
  return: 'dialog-submit',
  escape: 'dialog-close',
  'ctrl+space': 'dialog-toggle',
  'meta+up': 'dialog-section-prev',
  'meta+down': 'dialog-section-next',
}

/** The per-layer tables. The active layer owns the keyboard; a key that is not in its
 * table falls through to the global table, and a key that is in no table does nothing. */
export const LAYER_BINDINGS: Record<Exclude<KeyLayer, 'global'>, Record<string, string>> = {
  // The session layer: the escape interrupt, the tab cycle, and the model/preset cycles.
  session: {
    escape: 'interrupt',
    'ctrl+tab': 'cycle-session',
    'ctrl+shift+tab': 'cycle-session-back',
    f2: 'cycle-model',
    'shift+f2': 'cycle-model-back',
    'shift+tab': 'cycle-preset',
    'ctrl+r': 'rename-session',
  },
  // The composer layer: the prompt history at the first/last line. `left`/`right` stay
  // with the textarea: claiming them here would stop the caret from moving, and the store
  // could not hand the key back.
  composer: {
    up: 'history-prev',
    down: 'history-next',
  },
  // The autocomplete layer: the popup owns the arrows, the palette key, and Enter.
  autocomplete: {
    up: 'completion-prev',
    'ctrl+p': 'completion-prev',
    down: 'completion-next',
    'ctrl+n': 'completion-next',
    return: 'completion-accept',
    tab: 'completion-accept',
    escape: 'completion-close',
  },
  modal: MODAL_BINDINGS,
}

/** The leader window length, in milliseconds. */
export const LEADER_TIMEOUT_MS = 2000

/** Build the binding label for one key event: `ctrl+x`, `ctrl+p`, `shift+ctrl+y`. */
export function keyLabel(event: KeyEventLike): string {
  const parts: string[] = []
  if (event.ctrl) parts.push('ctrl')
  if (event.meta) parts.push('meta')
  if (event.shift) parts.push('shift')
  parts.push(event.name.toLowerCase())
  return parts.join('+')
}

/**
 * The keymap state machine.
 *
 * `handle` is fed every key event the renderer sees; `dispatch` receives the action
 * id when a binding resolves. `dispose` closes a pending leader window.
 */
export function createKeymap(
  dispatch: (action: string) => void,
  leaderTimeoutMs: number = LEADER_TIMEOUT_MS,
  schedule: (fn: () => void, ms: number) => () => void = (fn, ms) => {
    const timer = setTimeout(fn, ms)
    return () => clearTimeout(timer)
  },
  /** The layer that currently owns the keyboard: `dialogOpen` beats the popup, the popup
   * beats the focused composer, and the composer beats the session. */
  layer: () => KeyLayer = () => 'session',
  /** Session-scoped host actions are resolved after snapshot; absent actions are not dispatched. */
  actionAvailable: (action: string) => boolean = () => true,
) {
  let leaderOpen = false
  let close: (() => void) | undefined

  const closeWindow = (): void => {
    leaderOpen = false
    if (close !== undefined) close()
    close = undefined
  }

  return {
    /** Feed one key event; returns whether the keymap consumed it. */
    handle(event: KeyEventLike): boolean {
      const label = keyLabel(event)
      if (leaderOpen) {
        // The chord is consumed either way: an unknown chord closes the window and
        // does nothing, so the next keystroke is read as a fresh key.
        closeWindow()
        const action = BINDINGS[`${LEADER} ${label}`]
        if (action !== undefined && actionAvailable(action)) dispatch(action)
        return true
      }
      if (label === LEADER) {
        leaderOpen = true
        close = schedule(closeWindow, leaderTimeoutMs)
        return true
      }
      // The active layer owns the keyboard; a key it does not claim falls through to the
      // session layer (the escape interrupt, the tab cycle, and the model/preset cycles
      // stay live while the composer is focused), then to the global table, and a key in
      // no table does nothing.
      const owner = layer()
      const table = owner === 'global' ? undefined : LAYER_BINDINGS[owner]
      const action = (table !== undefined ? table[label] : undefined)
        ?? (owner === 'session' ? undefined : LAYER_BINDINGS.session[label])
        ?? BINDINGS[label]
      if (action !== undefined && actionAvailable(action)) {
        if (action === 'dialog-toggle') event.preventDefault?.()
        dispatch(action)
        return true
      }
      return false
    },
    /** True while a leader chord is waiting for its second key. */
    leaderIsOpen: () => leaderOpen,
    dispose: closeWindow,
  }
}
