/**
 * Renderer-side IPC channel.
 *
 * Bun exposes Node's IPC surface as `process.send` (send) and
 * `process.on('message')` (receive). `process.channel` is an EventEmitter and
 * has no `send`, so the send path must go through `process.send`.
 *
 * The channel is optional: running the renderer without a parent IPC channel
 * (a standalone smoke run) yields `undefined`, and the app renders a placeholder
 * with no host data.
 */

import { RENDERER_PROTOCOL_VERSION, type IpcEnvelope } from '../protocol/kinds.ts'

/** A bidirectional message channel: whole text messages in, whole text messages out. */
export interface Channel {
  send(text: string): void
  onMessage(listener: (text: string) => void): () => void
}

/** The renderer's IPC channel, or `undefined` when no parent channel exists. */
export function rendererChannel(): Channel | undefined {
  const send = process.send
  if (typeof send !== 'function') return undefined
  return {
    send: text => {
      // A closed channel throws `ERR_IPC_CHANNEL_CLOSED`. The channel closes as soon as the
      // host starts tearing down, and a second quit (a second ctrl+c, a late size report)
      // must not throw into a key handler and skip the terminal restore.
      try {
        send(text)
      } catch {
        // Nothing left to tell.
      }
    },
    onMessage: listener => {
      const handler = (data: unknown) => listener(typeof data === 'string' ? data : JSON.stringify(data))
      process.on('message', handler)
      return () => process.off('message', handler)
    },
  }
}

/** Parse one NDJSON line into an envelope; returns undefined when the line is unusable. */
export function decodeEnvelope(line: string): IpcEnvelope | undefined {
  try {
    const parsed = JSON.parse(line) as Record<string, unknown>
    if (typeof parsed.protocolVersion !== 'number' || typeof parsed.seq !== 'number') return undefined
    if (typeof parsed.kind !== 'string' || parsed.kind === '') return undefined
    return { protocolVersion: parsed.protocolVersion, seq: parsed.seq, kind: parsed.kind, payload: parsed.payload }
  } catch {
    return undefined
  }
}

/** Send one envelope with the next sequence number. */
export function sendEnvelope(channel: Channel, seq: number, kind: string, payload: unknown): void {
  channel.send(JSON.stringify({ protocolVersion: RENDERER_PROTOCOL_VERSION, seq, kind, payload }))
}
