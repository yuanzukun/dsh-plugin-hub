/**
 * The `ctrl+p` command palette.
 *
 * Ported from opencode (`anomalyco/opencode`, v2.0.30,
 * `packages/tui/src/component/command-palette.tsx`), MIT. Registered in NOTICE.md
 * under the `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * The palette is a new capability for dsh: rows come from host catalogs and local actions;
 * every entry runs through the store, so a pick becomes an upstream request the host performs.
 * `ctrl+x m` / `ctrl+x t` / `ctrl+x l` open the palette with the matching filter.
 *
 * Modifications: the palette is a `DialogSelect` on the store's dialog stack, so
 * it gets opencode's keyboard navigation, filter box, and selection window for
 * free; the entry list is a pure function of the store's host state, and a pick
 * resolves through `runPaletteEntry` in the store, which turns the entry id back
 * into the same upstream request the keymap action makes.
 */

import type { DialogOption } from '../ui/dialog.tsx'

/** The host state the palette reads. */
export interface PaletteData {
  readonly efforts: readonly string[]
  readonly effortCurrent: string
  /** The skills the host pushed. The palette's skills category lists them; picking a row
   * sends the `skill:` command upstream, which is the same line the composer completes. */
  readonly skills: readonly { name: string; description: string }[]
  /** The provider catalog, used by the pickers that resolve a provider's display name. */
  readonly providers: readonly { id: string; label: string }[]
  /** The permission presets and agent presets the host pushed; picking a row sends the
   * `set-selection` request the keymap path uses. `current` marks the live route. */
  readonly permissions: readonly { id: string; label: string }[]
  readonly permissionCurrent: string
  readonly modes: readonly { id: string; label: string }[]
  readonly modeCurrent: string
  /** The footer text for the active row, localized by the host's dictionary. */
  readonly currentLabel: string
  /**
   * The host dictionary: `(key, englishFallback) => string`. Every string the palette paints
   * goes through it, so a `zh-CN` terminal lists `切换模型` and a `重命名会话`, not the English
   * command vocabulary the ids happen to use.
   */
  readonly t: (key: string, fallback: string) => string
}

/**
 * The palette's own actions: every entry runs the same code the equivalent slash command or
 * keybinding runs, so the list and the keyboard can never drift apart. Upstream's palette is
 * the whole command surface (`ctrl+p` lists every registered command plus the settings), and
 * dsh's equivalent surface is its slash vocabulary — the four lifecycle actions first, then
 * the pickers, in the order the footer documents them.
 *
 * `labelKey` names the dictionary entry; `label` is the English fallback for a locale the
 * dictionary does not cover (and the text the tests read).
 */
export const PALETTE_ACTIONS: readonly { id: string; labelKey?: string; label: string }[] = [
  { id: 'rename-session', labelKey: 'rendererPaletteRename', label: 'rename session' },
  { id: 'new-session', labelKey: 'rendererPaletteNewSession', label: 'new session' },
  { id: 'trace', labelKey: 'rendererTrace', label: 'view interaction trace' },
  { id: 'export', labelKey: 'rendererPaletteExport', label: 'export session as markdown' },
  { id: 'exit', labelKey: 'rendererPaletteExit', label: 'exit (restore terminal)' },
  { id: 'shutdown', labelKey: 'rendererShutdown', label: 'shut down core process' },
  { id: 'slash:/status', labelKey: 'rendererDetails', label: 'show session details' },
  { id: 'slash:/doctor', labelKey: 'rendererPaletteDoctor', label: 'run diagnostics' },
  { id: 'slash:/help', labelKey: 'rendererPaletteHelp', label: 'show key bindings' },
  { id: 'slash:/agents', labelKey: 'rendererMode', label: 'switch agent' },
  { id: 'slash:/models', labelKey: 'rendererSwitchModel', label: 'switch model' },
  { id: 'slash:/permission', labelKey: 'rendererPermission', label: 'switch permission' },
  { id: 'slash:/mcps', labelKey: 'rendererMcp', label: 'list MCP servers' },
  { id: 'slash:/sessions', labelKey: 'rendererSessionPicker', label: 'list sessions' },
  { id: 'slash:/settings', labelKey: 'rendererSettings', label: 'open settings' },
  { id: 'slash:/skills', labelKey: 'rendererSkills', label: 'list skills' },
  { id: 'slash:/themes', labelKey: 'rendererTheme', label: 'switch theme' },
  { id: 'slash:/effort', labelKey: 'rendererThink', label: 'switch reasoning effort' },
]

/** Build the palette rows from the store's current host state.
 * An entry id is `group:value`, which `runPaletteEntry` in the store maps back to
 * the upstream request. The active item carries a `current` footer so the list
 * shows what is already selected.
 *
 * Model rows are deliberately absent: upstream's palette lists commands, and choosing
 * "Switch model" opens the model dialog. Mixing the catalog into the command list made a
 * model row resolve as a command, so the same menu both picked and switched.
 *
 * Rows are bare values under a translated section header — `切换模型` under `操作`, `max` under
 * `思考强度` — the shape opencode's own palette uses: the header carries the noun, so a row
 * never repeats it in a prefix the user has to read on every line.
 */
export function paletteOptions(data: PaletteData): DialogOption[] {
  const options: DialogOption[] = PALETTE_ACTIONS.map(action => ({
    title: action.labelKey === undefined ? action.label : data.t(action.labelKey, action.label),
    value: `action:${action.id}`,
    category: data.t('rendererPaletteActions', 'actions'),
    searchText: action.id,
  }))
  const efforts = data.t('rendererPaletteEfforts', 'reasoning effort')
  for (const effort of data.efforts) {
    options.push({
      title: effort,
      value: `effort:${effort}`,
      category: efforts,
      searchText: `reasoning effort ${effort}`,
      footer: effort === data.effortCurrent ? data.currentLabel : undefined,
    })
  }
  // Sessions are deliberately not a group here: the list is one row per open session, so a
  // long history turned the palette into a scrollable second session picker. `/sessions`
  // (and the action row that opens it) is the picker; the palette stays a command list.
  const skills = data.t('rendererPaletteSkills', 'skills')
  for (const skill of data.skills) {
    options.push({
      title: skill.name,
      value: `skill:${skill.name}`,
      category: skills,
      description: skill.description,
      searchText: `skill ${skill.name}`,
    })
  }
  const permissions = data.t('rendererPalettePermissions', 'permissions')
  for (const preset of data.permissions) {
    options.push({
      title: preset.label,
      value: `permission:${preset.id}`,
      category: permissions,
      searchText: `permission ${preset.id}`,
      footer: preset.id === data.permissionCurrent ? data.currentLabel : undefined,
    })
  }
  const modes = data.t('rendererPaletteModes', 'agents')
  for (const preset of data.modes) {
    options.push({
      title: preset.label,
      value: `mode:${preset.id}`,
      category: modes,
      searchText: `agent mode ${preset.id}`,
      footer: preset.id === data.modeCurrent ? data.currentLabel : undefined,
    })
  }
  // The WeChat bridge commands: the host routes each op through its own slash path,
  // so the palette entry is the same request the bridge's own command line makes.
  const wechat = data.t('rendererPaletteWechat', 'wechat')
  for (const op of ['connect', 'status', 'notify', 'progress']) {
    options.push({
      title: data.t(`rendererWechat${op.charAt(0).toUpperCase()}${op.slice(1)}`, op),
      value: `wechat:${op}`,
      category: wechat,
      searchText: `wechat ${op}`,
    })
  }
  return options
}
