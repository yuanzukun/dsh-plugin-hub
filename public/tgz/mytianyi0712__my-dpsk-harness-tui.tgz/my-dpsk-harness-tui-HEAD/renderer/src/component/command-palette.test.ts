import { expect, test } from 'bun:test'
import { paletteOptions } from './command-palette.tsx'
import { filterOptions } from '../ui/dialog-select.tsx'

test('palette filter keeps the skill row and drops the action rows', () => {
  const options = paletteOptions({
    availableActions: [], commands: [], effort: 'high', permission: 'auto', preset: 'standard', theme: 'opencode',
    models: [], sessions: [], skills: [{ name: 'dsh-review', description: 'review the diff' }],
    efforts: ['high'], permissionCurrent: 'auto', modeCurrent: 'standard', effortCurrent: 'high',
    currentLabel: 'current', providers: [], modes: [], permissions: [],
    t: (_key: string, fallback: string) => fallback,
    catalogAvailable: () => true,
  } as never)
  const skill = options.find(option => option.value === 'skill:dsh-review')
  expect(skill?.title).toBe('dsh-review')
  expect(filterOptions(options, 'skill').map(option => option.value)).toContain('skill:dsh-review')
  expect(filterOptions(options, 'skill').some(option => option.value === 'action:new-session')).toBe(false)
})
