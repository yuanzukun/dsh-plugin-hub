import { Buffer } from 'node:buffer'
import { EmbeddedTerminalRenderable } from '@opentui/core'
import { extend } from '@opentui/solid'
import { createEffect, createSignal, onCleanup, onMount, Show } from '#solid'
import type { TerminalFrame, WebTerminalInfo } from '../protocol/kinds.ts'

declare module '@opentui/solid' {
  interface OpenTUIComponents {
    embeddedTerminal: typeof EmbeddedTerminalRenderable
  }
}

extend({ embeddedTerminal: EmbeddedTerminalRenderable })

type TerminalKeyEvent = {
  readonly name: string
  readonly ctrl: boolean
  readonly shift: boolean
  readonly meta: boolean
  preventDefault?: () => void
  stopPropagation?: () => void
}

type TerminalSize = { cols: number; rows: number }
const sameSize = (first: TerminalSize | undefined, second: TerminalSize | undefined): boolean =>
  first !== undefined && second !== undefined && first.cols === second.cols && first.rows === second.rows

export function TerminalPane(props: {
  sessionId: string
  info: WebTerminalInfo
  attachmentId: string
  frames: () => readonly TerminalFrame[]
  consumeFrames: (count: number) => void
  write: (data: string) => void
  resize: (cols: number, rows: number) => void
  follow: () => Promise<void>
  detach: () => void
  registerKeyHandler: (handler: ((event: TerminalKeyEvent) => boolean) | undefined) => void
  foreground: string
  background: string
  endError: () => string | undefined
  maxInputBytes: number
  scrollback: number
}) {
  const [failure, setFailure] = createSignal<string>()
  let terminal: EmbeddedTerminalRenderable | undefined
  let canonicalSize: TerminalSize | undefined
  let terminalSize: TerminalSize | undefined
  let pendingSnapshot: Extract<TerminalFrame, { type: 'snapshot' }> | undefined
  let restored = false
  let ownsControl = props.info.controllerId === props.attachmentId
  let disposed = false
  let lastSequence = -1
  let lastResize = ''
  const stream: TerminalFrame[] = []
  const pendingInput: string[] = []

  const setCanonicalSize = (size: TerminalSize): void => {
    canonicalSize = size
    if (terminal !== undefined) {
      terminal.width = size.cols
      terminal.height = size.rows
    }
  }

  const flushInput = (): void => {
    if (!restored || !ownsControl) return
    for (const data of pendingInput.splice(0)) props.write(data)
  }

  const processStream = (): void => {
    if (disposed || terminal === undefined) return
    while (stream.length > 0) {
      const frame = stream[0]
      if (frame === undefined) return
      if (frame.type === 'snapshot') {
        if (frame.sequence <= lastSequence) {
          stream.shift()
          continue
        }
        pendingSnapshot = frame
        ownsControl = frame.info.controllerId === props.attachmentId
        if (!ownsControl) pendingInput.length = 0
        setCanonicalSize({ cols: frame.info.cols, rows: frame.info.rows })
        if (!sameSize(canonicalSize, terminalSize)) return
        stream.shift()
        terminal.write(Buffer.from('\x1bc', 'utf8'))
        terminal.write(Buffer.from(frame.screen, 'utf8'))
        lastSequence = frame.sequence
        pendingSnapshot = undefined
        restored = true
        flushInput()
        continue
      }
      if (!restored) return
      if (frame.type === 'state') {
        const hadControl = ownsControl
        ownsControl = frame.info.controllerId === props.attachmentId
        if (hadControl && !ownsControl) pendingInput.length = 0
        if (frame.info.cols !== canonicalSize?.cols || frame.info.rows !== canonicalSize?.rows) {
          setCanonicalSize({ cols: frame.info.cols, rows: frame.info.rows })
          if (!sameSize(canonicalSize, terminalSize)) return
        }
        stream.shift()
        flushInput()
        continue
      }
      if (frame.sequence <= lastSequence) {
        stream.shift()
        continue
      }
      if (frame.sequence !== lastSequence + 1) {
        setFailure(`Terminal output sequence gap: expected ${lastSequence + 1}, received ${frame.sequence}`)
        return
      }
      if (!sameSize(canonicalSize, terminalSize)) return
      stream.shift()
      terminal.write(Buffer.from(frame.data, 'utf8'))
      lastSequence = frame.sequence
      flushInput()
    }
  }

  const onKey = (event: TerminalKeyEvent): boolean => {
    if (!terminal?.focused) return false
    if ((event.ctrl && event.name.toLowerCase() === 'x') || !restored) return false
    event.preventDefault?.()
    event.stopPropagation?.()
    terminal.handleKeyPress(event as Parameters<EmbeddedTerminalRenderable['handleKeyPress']>[0])
    return true
  }

  createEffect(() => {
    const incoming = props.frames()
    if (incoming.length === 0 || terminal === undefined) return
    stream.push(...incoming)
    props.consumeFrames(incoming.length)
    processStream()
  })
  createEffect(() => {
    const message = props.endError()
    if (message !== undefined) setFailure(message)
  })

  onMount(() => {
    props.registerKeyHandler(onKey)
    terminal?.focus()
    const queued = props.frames()
    if (queued.length > 0) {
      stream.push(...queued)
      props.consumeFrames(queued.length)
      processStream()
    }
    void props.follow().catch(error => setFailure(error instanceof Error ? error.message : String(error)))
  })

  onCleanup(() => {
    disposed = true
    props.registerKeyHandler(undefined)
    props.detach()
  })

  const onSizeChange = function (this: { width: number; height: number }): void {
    const size = { cols: Math.max(1, this.width - 2), rows: Math.max(1, this.height) }
    terminalSize = size
    if (pendingSnapshot !== undefined && sameSize(size, { cols: pendingSnapshot.info.cols, rows: pendingSnapshot.info.rows })) {
      processStream()
    } else if (restored) {
      processStream()
      if (ownsControl && canonicalSize !== undefined && !sameSize(size, canonicalSize)) {
        const identity = `${size.cols}x${size.rows}`
        if (identity !== lastResize) {
          lastResize = identity
          props.resize(size.cols, size.rows)
        }
      }
    }
  }

  return (
    <box flexGrow={1} minWidth={0} minHeight={0} overflow="hidden" backgroundColor={props.background} onSizeChange={onSizeChange} onMouseDown={() => terminal?.focus()}>
      <Show when={failure() === undefined} fallback={<text fg={props.foreground} content={failure() ?? ''} /> }>
        <embeddedTerminal
          ref={value => {
            terminal = value
            terminalSize = { cols: value.width, rows: value.height }
            setCanonicalSize({ cols: props.info.cols, rows: props.info.rows })
            processStream()
          }}
          position="absolute"
          left={1}
          top={0}
          width={Math.max(1, props.info.cols)}
          height={Math.max(1, props.info.rows)}
          maxScrollback={props.scrollback}
          transparentBackground={false}
          onData={(data, source) => {
            if (source !== 'input') return
            const input = Buffer.from(data).toString('utf8')
            if (Buffer.byteLength(input, 'utf8') > props.maxInputBytes) {
              setFailure(`Terminal input exceeds the ${props.maxInputBytes}-byte limit`)
              return
            }
            if (!restored) pendingInput.push(input)
            else if (ownsControl) props.write(input)
          }}
          onTerminalResize={(cols, rows) => {
            terminalSize = { cols, rows }
            processStream()
            if (restored && ownsControl && canonicalSize !== undefined && !sameSize(terminalSize, canonicalSize)) {
              const identity = `${cols}x${rows}`
              if (identity !== lastResize) {
                lastResize = identity
                props.resize(cols, rows)
              }
            }
          }}
        />
      </Show>
    </box>
  )
}
