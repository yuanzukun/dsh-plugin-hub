/**
 * The native theme provider.
 *
 * Ported from opencode v2.0.32 (`packages/tui/src/context/theme.tsx`), MIT; the data
 * source is this renderer (built-in documents, discovered files, the generated system
 * theme) and the persisted selection is dsh's TUI settings section, not an opencode
 * config file.
 *
 * SPDX-License-Identifier: MIT
 *
 * What it owns: the theme catalog (`all`), the resolved tokens for the active theme and
 * mode (`currentTokens`), the `ComponentTheme` view components paint from, the terminal
 * palette probe for the `system` theme, and the persisted `theme.name` / `theme.mode` /
 * the resolved `theme.name` / `theme.mode` selection. The transcript style is a shell setting,
 * not a theme candidate: `opencode2` is always selectable.
 */

import { CliRenderEvents, type SyntaxStyle, type TerminalColors } from '@opentui/core'
import { useRenderer } from '@opentui/solid'
import { createContext, createEffect, createMemo, createSignal, onCleanup, onMount, useContext, type Accessor, type ParentProps } from '#solid'
import {
  parseThemeDocument,
  resolveThemeDocument,
  themeModes,
  type Mode,
  type ResolvedTheme,
  type SurfaceName,
} from './core/index'
import { createComponentTheme, type ComponentTheme } from './native/component'
import { discoverThemes } from './native/discovery'
import { allThemes, getOpenCode2Theme, hasTheme, parseTheme, setCustomThemes, setSystemTheme, subscribeThemes, type ThemeDocumentSource } from './native/index'
import { generateSystem, terminalMode } from './native/system'
import { registerThemeControls } from './controls'
import { generateSyntax } from './core/index'
import { registerActiveSyntax } from './paths.ts'

export type ThemeModeSetting = 'system' | 'dark' | 'light'

/** The persisted theme selection. The transcript style (`newDesigns`) is a shell setting. */
export interface ThemeSelection {
  readonly name: string
  readonly mode: ThemeModeSetting
}

/** Where the provider reads and writes the selection. Both are the host's settings seam. */
export interface ThemeStorage {
  readonly selection: () => ThemeSelection
  readonly save: (patch: { readonly name?: string; readonly mode?: ThemeModeSetting }) => Promise<void>
}

export interface Themes {
  readonly current: ComponentTheme
  readonly currentTokens: Accessor<ResolvedTheme>
  readonly selected: string
  readonly all: () => Record<string, ThemeDocumentSource>
  readonly has: (name: string) => boolean
  readonly mode: Accessor<Mode>
  readonly modes: Accessor<readonly Mode[]>
  readonly supports: (mode: Mode) => boolean
  readonly locked: Accessor<boolean>
  readonly ready: Accessor<boolean>
  /** Pin a mode; `persist` writes it to the selection. */
  setMode: (mode?: Mode, persist?: boolean) => boolean
  /** Follow the terminal again (`theme.mode: "system"`). */
  unlock: (persist?: boolean) => void
  /** Select a theme by name. Unknown names are refused. */
  set: (name: string) => boolean
  /** Re-probe the terminal palette (after the first paint). */
  afterPaint: () => void
  onError: (handler: (error: Error) => void) => () => void
}

interface ThemeContextValue {
  readonly current: ComponentTheme
  readonly themes: Themes
}

const [selection, setSelection] = createSignal<ThemeSelection>({ name: 'opencode', mode: 'system' })
const [themesState, setThemesState] = createSignal(allThemes())
subscribeThemes(themes => setThemesState(themes))

let errorHandler: ((error: Error) => void) | undefined
let pendingError: Error | undefined

function emitError(error: unknown): void {
  const value = error instanceof Error ? error : new Error(String(error))
  if (errorHandler !== undefined) {
    errorHandler(value)
    return
  }
  pendingError = value
}

/** The state the provider boots from; the shell re-reads it whenever settings change. */
export function initialThemeSelection(): ThemeSelection {
  return selection()
}

const themeContext = createContext<ThemeContextValue>()

function usablePalette(colors: TerminalColors | undefined): colors is TerminalColors {
  return Boolean(colors && (colors.defaultBackground ?? colors.palette[0]) && (colors.defaultForeground ?? colors.palette[7]))
}

function loadTheme(source: ThemeDocumentSource, name: string, requested: Mode): { modes: readonly Mode[]; mode: Mode; theme: ResolvedTheme } {
  const document = parseTheme(source, name)
  const modes = themeModes(document)
  const mode = modes.includes(requested) ? requested : (modes[0] ?? requested)
  return { modes, mode, theme: resolveThemeDocument(document, mode) }
}

/**
 * The theme context.
 *
 * `mode` is the terminal's reported scheme; the selection's `mode` pins `dark`/`light` or
 * follows it. `system` is a built-in theme document generated from the terminal palette.
 */
export function ThemeProvider(props: ParentProps<{ storage: ThemeStorage; mode: Mode }>) {
  const renderer = useRenderer()
  const [themeNames, setThemeNames] = createSignal(allThemes())
  subscribeThemes(next => setThemeNames(next))
  const [lock, setLock] = createSignal<Mode | undefined>(undefined)
  const [mode, setModeSignal] = createSignal<Mode>(props.mode)
  const [active, setActive] = createSignal('opencode')
  const [ready, setReady] = createSignal(false)
  // Adopt the persisted selection once; later writes go back through `storage.save`.
  const initial = props.storage.selection()
  setSelection(initial)
  setActive(initial.name === '' ? 'opencode' : initial.name)
  const lockedMode = initial.mode === 'system' ? undefined : initial.mode
  setLock(lockedMode)
  setModeSignal(lockedMode ?? props.mode)

  // `opencode2` is a normal theme choice. The `newDesigns` shell setting controls the
  // transcript presentation, never whether this theme exists.
  const available = (): Record<string, ThemeDocumentSource> => ({ opencode2: getOpenCode2Theme(), ...themeNames() })
  const has = (name: string): boolean => Boolean(name) && available()[name] !== undefined
  const selected = createMemo(() => {
    const sources = available()
    const name = sources[active()] ? active() : 'opencode'
    try {
      return loadTheme(sources[name] as ThemeDocumentSource, name, mode())
    } catch (error) {
      if (name === 'opencode') throw error
      emitError(error)
      setActive('opencode')
      return loadTheme(sources.opencode as ThemeDocumentSource, 'opencode', mode())
    }
  })
  const tokens = () => selected().theme
  const current = createComponentTheme(tokens)
  /**
   * The syntax style follows the theme, and the previous one is destroyed only after the
   * renderer is idle: a frame still painting with the old style must not point at freed
   * tables. Upstream's `createSyntaxStyleMemo` is the same lifecycle.
   */
  const [syntax, setSyntax] = createSignal<SyntaxStyle>(generateSyntax(tokens()))
  {
    let previous: SyntaxStyle | undefined = syntax()
    createEffect(() => {
      const next = generateSyntax(tokens())
      const stale = previous
      previous = next
      setSyntax(next)
      if (stale === undefined || stale === next) return
      void renderer
        .idle()
        .catch(() => undefined)
        .finally(() => stale.destroy())
    })
  }

  let palette: TerminalColors | undefined
  let canProbe = false
  let probing = false
  let disposed = false

  const applyPalette = (): void => {
    if (palette === undefined) return
    setSystemTheme(generateSystem(palette, mode()))
  }

  const refreshPalette = (): void => {
    if (active() !== 'system' || !canProbe || probing || disposed) return
    probing = true
    void renderer
      .getPalette({ size: 16 })
      .then(colors => {
        if (disposed || !usablePalette(colors)) return
        palette = colors
        const detected = lock() ?? terminalMode(colors) ?? mode()
        if (mode() !== detected) setModeSignal(detected)
        applyPalette()
      })
      .catch(() => undefined)
      .finally(() => {
        probing = false
      })
  }

  /** The first paint uses the built-in fallback; the probe runs once the frame is out. */
  const afterPaint = (): void => {
    canProbe = true
    refreshPalette()
  }

  const persist = (patch: { readonly name?: string; readonly mode?: ThemeModeSetting }): void => {
    const next: ThemeSelection = {
      name: patch.name ?? selection().name,
      mode: patch.mode ?? selection().mode,
    }
    setSelection(next)
    void props.storage.save(patch).catch(error => emitError(error))
  }

  const pin = (requested: Mode = mode(), write = true): void => {
    setLock(requested)
    setModeSignal(requested)
    refreshPalette()
    if (write) persist({ mode: requested })
  }

  const unlock = (write = true): void => {
    setLock(undefined)
    setModeSignal(props.mode)
    refreshPalette()
    if (write) persist({ mode: 'system' })
  }

  const set = (name: string): boolean => {
    if (!has(name)) return false
    setActive(name)
    if (name === 'system') refreshPalette()
    persist({ name })
    return true
  }

  const handleTerminalMode = (next: Mode): void => {
    if (lock() !== undefined) return
    setModeSignal(next)
    refreshPalette()
  }
  renderer.on(CliRenderEvents.THEME_MODE, handleTerminalMode)

  createEffect(() => renderer.setBackgroundColor(tokens().background.base))

  onMount(() => {
    // Custom theme files are discovered once at mount; a failure keeps the built-ins.
    void discoverThemes([process.env.DSH_HOME ?? `${process.env.HOME ?? process.env.USERPROFILE ?? ''}`])
      .then(themes => setCustomThemes(themes))
      .catch(() => undefined)
      .finally(() => {
        setActive(value => has(value) ? value : 'opencode')
        setReady(true)
      })
  })

  onCleanup(() => {
    disposed = true
    renderer.off(CliRenderEvents.THEME_MODE, handleTerminalMode)
  })

  registerActiveSyntax(() => syntax())
  onCleanup(() => registerActiveSyntax(undefined))
  registerThemeControls({
    all: () => available(),
    selected: () => active(),
    mode: () => mode(),
    // A preview paints the pending theme but writes nothing: cancel has to restore the
    // committed one, and merely opening a picker must not persist anything.
    preview(name: string) {
      if (!has(name)) return false
      setActive(name)
      if (name === 'system') refreshPalette()
      return true
    },
    set,

    setMode(requested) {
      if (!selected().modes.includes(requested)) return false
      pin(requested, true)
      return true
    },
    unlock,
  })
  onCleanup(() => registerThemeControls(undefined))

  /**
   * Adopt a persisted selection that arrives after the first paint.
   *
   * The host answers the handshake first and sends its `settings` section on the next tick, so
   * the `selection()` read at mount can still be the empty default. This effect adopts the
   * persisted theme once it arrives, and picks up a theme written from the settings page while
   * the provider is already running.
   */
  createEffect(() => {
    const next = props.storage.selection()
    if (next.name !== '' && next.name !== active() && has(next.name)) {
      setActive(next.name)
      refreshPalette()
    }
    const wanted = next.mode === 'system' ? undefined : next.mode
    if ((wanted ?? 'system') !== (lock() ?? 'system')) {
      setLock(wanted)
      setModeSignal(wanted ?? props.mode)
      refreshPalette()
    }
  })

  const themes: Themes = {
    current,
    currentTokens: tokens,
    get selected() {
      return active()
    },
    all: available,
    has,
    mode,
    modes: () => selected().modes,
    supports: requested => selected().modes.includes(requested),
    locked: () => lock() !== undefined,
    ready,
    setMode(requested = mode(), write = true) {
      if (!selected().modes.includes(requested)) return false
      pin(requested, write)
      return true
    },
    unlock,
    set,
    afterPaint,
    onError(handler) {
      errorHandler = handler
      if (pendingError !== undefined) {
        handler(pendingError)
        pendingError = undefined
      }
      return () => {
        if (errorHandler === handler) errorHandler = undefined
      }
    },
  }

  return (
    <themeContext.Provider value={{ current, themes }}>
      {props.children}
    </themeContext.Provider>
  )
}

export function useThemes(): Themes {
  const value = useContext(themeContext)
  if (value === undefined) throw new Error('useThemes must be used inside ThemeProvider')
  return value.themes
}

export function useTheme(): ComponentTheme {
  const value = useContext(themeContext)
  if (value === undefined) throw new Error('useTheme must be used inside ThemeProvider')
  return value.current
}

/** Re-resolve the same theme on another surface (`dialog`), without remounting children. */
export function ThemeContextProvider(props: ParentProps<{ context: SurfaceName | undefined }>) {
  const value = useContext(themeContext)
  if (value === undefined) throw new Error('ThemeContextProvider must be used inside ThemeProvider')
  const current = createComponentTheme(() => {
    const name = props.context
    return name === undefined ? value.themes.currentTokens() : value.themes.currentTokens().surface(name)
  })
  return (
    <themeContext.Provider value={{ current, themes: value.themes }}>
      {props.children}
    </themeContext.Provider>
  )
}
