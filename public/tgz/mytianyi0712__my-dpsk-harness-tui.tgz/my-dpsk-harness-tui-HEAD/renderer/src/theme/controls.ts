/**
 * Theme controls the app store can call.
 *
 * The native provider is mounted above the shell (it needs the renderer for the palette
 * probe), while the palette and settings dialogs live in the store. This module is the
 * bridge: the provider registers its controls once, and the store calls them without
 * importing a component.
 */

export interface ThemeControls {
  readonly all: () => Record<string, unknown>
  readonly selected: () => string
  readonly mode: () => 'dark' | 'light'
  /** Preview a theme without committing it (a picker's moving highlight). */
  readonly preview: (name: string) => boolean
  /** Commit a theme: the selection is persisted through the settings section. */
  readonly set: (name: string) => boolean
  readonly setMode: (mode: 'dark' | 'light') => boolean
  readonly unlock: () => void
}

let controls: ThemeControls | undefined

export function registerThemeControls(value: ThemeControls | undefined): void {
  controls = value
}

export function themeControls(): ThemeControls | undefined {
  return controls
}
