/**
 * Native theme provider tests.
 *
 * The provider is mounted exactly as `main.tsx` mounts it (above the shell, with the
 * store's settings adapter), so the assertions read the painted grid and its spans: the
 * default theme is the native `opencode` document, and a pick re-resolves the tokens.
 */

import { expect, test } from 'bun:test'
import { testRender } from '@opentui/solid'
import { createAppStore } from '../app.tsx'
import { Shell } from '../app.tsx'
import { ThemeProvider, useThemes } from './provider.tsx'
import { registerActiveTheme } from './paths.ts'
import { themeControls } from './controls.ts'
import { onCleanup } from '#solid'

function sessionStore() {
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1', initialRoute: 'session', title: 'theme', events: [{ id: 'e1', role: 'user', text: 'hello' }],
      provider: 'cliproxy', model: 'mimo', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/x',
    },
  })
  return store
}

function bridge(props: { store: ReturnType<typeof createAppStore> }) {
  const themes = useThemes()
  registerActiveTheme(() => themes.currentTokens())
  onCleanup(() => registerActiveTheme(undefined))
  return <Shell store={props.store} />
}

async function mount(store: ReturnType<typeof createAppStore>, overrides: Partial<ReturnType<ReturnType<typeof createAppStore>['themeStorage']>['selection']> = {}) {
  const storage = store.themeStorage()
  const view = await testRender(
    () => (
      <ThemeProvider storage={{ ...storage, selection: () => ({ ...storage.selection(), ...overrides }) }} mode="dark">
        {bridge({ store })}
      </ThemeProvider>
    ),
    { width: 90, height: 24 },
  )
  await view.renderOnce()
  return view
}

test('the provider resolves the native opencode document and paints its tokens', async () => {
  const store = sessionStore()
  const view = await mount(store)
  const frame = view.captureCharFrame()
  expect(frame).toContain('hello')
  // The native document's `border.base` is `#484848`; the prompt gutter paints it.
  const spans = view.captureSpans()
  const colors = new Set(spans.lines.flatMap(line => line.spans.map(span => span.fg.toString())))
  expect(colors.size).toBeGreaterThan(1)
  // The store's path helper reads the same resolved theme (no synthetic token map).
  expect(store.color('border.base')).toBe('#484848')
  // `@dialog.*` resolves through the native `surface("dialog")` view, not a flat map.
  expect(store.color('@dialog.text.base')).toBe(store.color('text.base'))
  expect(store.color('text.base')).not.toBeUndefined()
  // The default selection is the native default, and `system` follows the terminal.
  expect(store.themeStorage().selection().name).toBe('opencode')
  expect(store.themeStorage().selection().mode).toBe('system')
  view.renderer.destroy()
})

test('a selection stored in the TUI settings selects that theme', async () => {
  const store = sessionStore()
  const view = await mount(store, { name: 'catppuccin', mode: 'dark' })
  expect(store.color('border.base')).not.toBe('#484848')
  view.renderer.destroy()
})

test('the composer rule and the chrome use the accent hue, not the white action ink', async () => {
  // `text.action.primary.base` is the label ink on a coloured button — in this theme it is
  // near-white. Using it as the emphasis colour is what flattened the whole shell to grey;
  // the accent hue (`hue.accent.*`) is the purple the syntax and the opencode UI share.
  const store = sessionStore()
  const view = await mount(store)
  const accent = store.color('hue.accent.200')
  expect(accent).not.toBeUndefined()
  expect(accent).not.toBe(store.color('text.action.primary.base'))
  const target = accent!.replace('#', '')
  const rgb = [0, 2, 4].map(offset => Number.parseInt(target.slice(offset, offset + 2), 16))
  const spans = view.captureSpans()
  const accentSpans = spans.lines
    .flatMap(line => line.spans)
    .filter(span => {
      const [r = 0, g = 0, b = 0] = span.fg.toInts().map(value => Math.round(value / 255 * 255))
      return Math.abs(r - rgb[0]!) <= 2 && Math.abs(g - rgb[1]!) <= 2 && Math.abs(b - rgb[2]!) <= 2
    })
  expect(accentSpans.length).toBeGreaterThan(0)
  // At least one of them is the prompt's left rule.
  expect(accentSpans.some(span => span.text.includes('┃'))).toBe(true)
  view.renderer.destroy()
})

test('opencode2 is selectable without the transcript-style switch', async () => {
  // The old experiment coupled `newDesigns` to the theme catalog. The switch now belongs to
  // the transcript, so `opencode2` must be present even when it is off.
  const store = sessionStore()
  const view = await mount(store)
  expect(Object.keys(themeControls()?.all() ?? {})).toContain('opencode2')
  expect(store.themeStorage().selection()).not.toHaveProperty('newDesigns')
  view.renderer.destroy()
})

test('a late settings payload can still select opencode2', async () => {
  const store = sessionStore()
  const view = await mount(store)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'settings',
    payload: { schemaVersion: 2, values: { themeName: 'opencode2' } },
  })
  await view.renderOnce()
  expect(themeControls()?.selected()).toBe('opencode2')
  view.renderer.destroy()
})
