/**
 * Native token paths.
 *
 * The native theme provider resolves a theme document into `ResolvedTheme` token trees of
 * `RGBA` values. Components address a token by a dotted path (`text.base`,
 * `background.raised.base`, `text.action.primary.$focused`, `hue.accent.200`); a leading
 * `@dialog.` names the dialog surface, which is the native `surface("dialog")` view.
 *
 * A path the theme does not define resolves to `undefined`, so the caller keeps its own
 * literal fallback. That is the only place a fallback may come from: a token the theme
 * does not carry is not synthesized from another color.
 */

import { SyntaxStyle, type RGBA } from '@opentui/core'
import type { ResolvedTheme, StatefulColor, SurfaceName } from './core/index'

/** The surface prefix a path may carry (`@dialog.text.base`). */
const SURFACE_PREFIX = '@'

function isStateful(value: object): value is StatefulColor {
  return 'base' in value && typeof (value as { state?: unknown }).state === 'function'
}

function surfaceFor(theme: ResolvedTheme, name: string): ResolvedTheme | undefined {
  return theme.surface(name as SurfaceName)
}

/** Look one dotted token path up in a resolved theme. */
export function tokenRgba(theme: ResolvedTheme, path: string): RGBA | undefined {
  let current: ResolvedTheme | undefined = theme
  let segments = path.split('.')
  const first = segments[0] ?? ''
  if (first.startsWith(SURFACE_PREFIX)) {
    current = surfaceFor(theme, first.slice(SURFACE_PREFIX.length))
    if (current === undefined) return undefined
    segments = segments.slice(1)
  }
  if (segments.length === 0) return undefined
  // Hue slots are stored by semantic name (`accent`, `neutral`, …) and step.
  if (segments[0] === 'hue' && segments.length === 3) {
    const scale = (current.hue as Record<string, Record<string, RGBA>>)[segments[1] ?? '']
    return scale?.[segments[2] ?? '']
  }
  let node: unknown = current
  let state: string | undefined
  for (const [index, segment] of segments.entries()) {
    if (node === null || typeof node !== 'object') return undefined
    if (segment.startsWith('$')) {
      state = segment
      if (index !== segments.length - 1) return undefined
      break
    }
    node = (node as Record<string, unknown>)[segment]
  }
  if (state !== undefined) {
    if (node === null || typeof node !== 'object' || !isStateful(node)) return undefined
    return (node as unknown as Record<string, RGBA>)[state]
  }
  // A stateful slot addressed without a state resolves to its `base` color.
  if (node !== null && typeof node === 'object' && isStateful(node)) return node.base
  return typeof node === 'object' && node !== null && 'r' in node ? node as RGBA : undefined
}

/** `#rrggbb` for a color the terminal can paint; alpha is dropped (OpenTUI styles take RGB). */
export function rgbaHex(color: RGBA): string {
  const [r, g, b] = color.toInts()
  return `#${[r, g, b].map(channel => channel.toString(16).padStart(2, '0')).join('')}`
}

/** One token path as a hex color, or `undefined` when the theme does not define it. */
export function tokenHex(theme: ResolvedTheme, path: string): string | undefined {
  const color = tokenRgba(theme, path)
  return color === undefined ? undefined : rgbaHex(color)
}

/** The active theme's syntax style, registered by the provider alongside it. */
let activeSyntax: (() => SyntaxStyle | undefined) | undefined

/** Register the syntax style the markdown and code renderables paint with. */
export function registerActiveSyntax(accessor: (() => SyntaxStyle | undefined) | undefined): void {
  activeSyntax = accessor
}

/** The active native `SyntaxStyle`, or `undefined` before the provider mounts. */
export function activeSyntaxStyle(): SyntaxStyle | undefined {
  return activeSyntax?.()
}

/**
 * The style a renderable paints with right now: the active theme's style, or a plain
 * fallback before the provider mounts. The fallback exists only for the first frame, when
 * the theme is not installed yet; it is never a second theme.
 */
let fallbackSyntax: SyntaxStyle | undefined
export function syntaxStyleOrFallback(fg: string): SyntaxStyle {
  const active = activeSyntax?.()
  if (active !== undefined) return active
  if (fallbackSyntax === undefined) fallbackSyntax = SyntaxStyle.fromStyles({ default: { fg } })
  return fallbackSyntax
}

/**
 * The syntax style for reasoning text.
 *
 * Upstream's `generateThinkingSyntax` recolors **every** registered token to one muted ink,
 * so a thought chain reads as a single quiet voice instead of a second answer: without it
 * the reasoning body keeps the answer's heading/emphasis/code colors and the two blocks
 * become indistinguishable. The result is cached per ink, because a `SyntaxStyle` owns
 * native memory and a streaming row would otherwise build one per delta.
 */
const mutedSyntaxStyles = new Map<string, SyntaxStyle>()
export function mutedSyntaxStyle(fg: string): SyntaxStyle {
  const cached = mutedSyntaxStyles.get(fg)
  if (cached !== undefined) return cached
  const active = activeSyntax?.()
  const style = active === undefined
    ? SyntaxStyle.fromStyles({ default: { fg } })
    : SyntaxStyle.fromStyles(
      Object.fromEntries(active.getRegisteredNames().map(name => [name, { ...active.getStyle(name), fg }])),
    )
  mutedSyntaxStyles.set(fg, style)
  return style
}

/** The active theme, registered by the provider so plain store helpers can read it. */
let activeTheme: (() => ResolvedTheme | undefined) | undefined

export function registerActiveTheme(accessor: (() => ResolvedTheme | undefined) | undefined): void {
  activeTheme = accessor
}

/** One token path as a hex color from the active native theme. */
export function activeTokenHex(path: string): string | undefined {
  const theme = activeTheme?.()
  return theme === undefined ? undefined : tokenHex(theme, path)
}

/**
 * The token one step down its own hue scale — native `theme.decrease()` — as a hex color.
 * A color that is not a hue slot comes back unchanged, matching upstream.
 */
export function activeDecreaseHex(path: string, amount = 1): string | undefined {
  const theme = activeTheme?.()
  if (theme === undefined) return undefined
  const color = tokenRgba(theme, path)
  if (color === undefined) return undefined
  return rgbaHex(theme.decrease(color, amount))
}
