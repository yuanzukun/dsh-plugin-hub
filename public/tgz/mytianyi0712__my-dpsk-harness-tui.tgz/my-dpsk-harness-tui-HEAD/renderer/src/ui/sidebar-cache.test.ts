import { expect, test } from 'bun:test'
import { cacheShareParts } from './sidebar.tsx'

test('a read-only provider sample still paints the cache hit share', () => {
  expect(cacheShareParts({
    sessionId: 'ses_1',
    inputTokens: 12_000,
    outputTokens: 3_400,
    cacheReadTokens: 8_000,
    cacheReadComplete: true,
  })).toEqual({ tokens: '23.4k', share: ' (40% cache)' })
})

test('missing read data keeps the cache dash', () => {
  expect(cacheShareParts({
    sessionId: 'ses_1',
    inputTokens: 12_000,
    outputTokens: 3_400,
    cacheReadTokens: 8_000,
    cacheReadComplete: false,
  }).share).toBe(' (cache —)')
})

test('an observed read in a mixed history paints the cumulative share', () => {
  expect(cacheShareParts({
    sessionId: 'ses_1',
    inputTokens: 100,
    outputTokens: 10,
    cacheReadTokens: 50,
    cacheWriteTokens: 0,
    cacheReadObserved: true,
    cacheReadComplete: false,
    cacheBucketsComplete: false,
  }).share).toBe(' (33% cache)')
})

test('a history with no observed reads keeps the dash', () => {
  expect(cacheShareParts({
    sessionId: 'ses_1',
    inputTokens: 100,
    outputTokens: 10,
    cacheReadTokens: 0,
    cacheWriteTokens: 0,
    cacheReadObserved: false,
    cacheReadComplete: false,
    cacheBucketsComplete: false,
  }).share).toBe(' (cache —)')
})

test('legacy complete-buckets payload still paints the share', () => {
  expect(cacheShareParts({
    sessionId: 'ses_1',
    inputTokens: 100,
    outputTokens: 10,
    cacheReadTokens: 100,
    cacheWriteTokens: 0,
    cacheBucketsComplete: true,
  }).share).toBe(' (50% cache)')
})
