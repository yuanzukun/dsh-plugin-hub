/**
 * Dialog base for the renderer.
 *
 * Derived from opencode (`anomalyco/opencode`, v2.0.30,
 * `packages/tui/src/ui/dialog.tsx`), MIT. Registered in NOTICE.md under the
 * `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications:
 * - `useTheme().surface("dialog")` is replaced by the store's token lookup under
 *   the `@dialog` scope (`store.color('@dialog.text.base')`), with a fallback per
 *   slot so a theme that omits a dialog token still paints.
 * - `Keymap.use()` / `Keymap.createLayer()` / `keymap.mode.push("modal")` are
 *   replaced by the store's dialog stack: the keymap routes modal keys to the
 *   active dialog's controller, and Escape closes the top of the stack.
 * - Clipboard copy-on-select, the toast overlay, and `useConfig` (cursor style)
 *   are not ported: the renderer has no clipboard seam and 0.5.0 ships no toast.
 * - The dialog stack lives in the app store (plain signals) instead of a Solid
 *   context, because the keymap and the IPC layer both need to reach it.
 * - `<Show>` is avoided at box level: OpenTUI's reconciler rejects the empty text
 *   node a false `<Show>` inserts into a box parent ("Orphan text error"), so the
 *   conditional content is a ternary JSX child.
 */

import { RGBA, TextAttributes } from '@opentui/core'
import { useRenderer, useTerminalDimensions } from '@opentui/solid'
import { For, type JSX, type ParentProps } from '#solid'
import type { FormFieldSpec, QuestionSpec, ShellJobView } from '../protocol/kinds.ts'
import { DIALOG_STACK_WIDTH } from './layout.ts'

/** Dialog panel widths, in cells, matching opencode v2's three sizes. */
export type DialogSize = 'medium' | 'large' | 'xlarge'

/** Side padding inside a dialog panel. */
export const DIALOG_INSET = 3
/** List rows reserve a 1-cell gutter for the marker, so they inset one more. */
export const DIALOG_LIST_INSET = DIALOG_INSET + 1

export function dialogWidth(size: DialogSize): number {
  if (size === 'xlarge') return 116
  if (size === 'large') return 88
  return 60
}

/** One row in a select dialog. `value` is what the host receives on pick. */
export interface DialogOption {
  readonly title: string
  readonly value: string
  readonly description?: string
  /** The group header the row sits under. */
  readonly category?: string
  /** Extra text the filter matches against (labels, ids, aliases). */
  readonly searchText?: string
  /** Right-aligned hint, e.g. the active marker or a key. */
  readonly footer?: string
  readonly details?: readonly string[]
  readonly disabled?: boolean
}

/** A dialog the store asked the renderer to show. `onDone` resolves it. */
export interface DialogSpec {
  readonly id: number
  readonly kind: 'select' | 'prompt' | 'confirm' | 'alert' | 'fields' | 'shell-output' | 'question' | 'trace'
  readonly title: string
  readonly size?: DialogSize
  /** Filter input placeholder (select) / initial value (prompt). */
  readonly placeholder?: string
  /** Seeds the select filter box when the dialog opens (the palette group shortcut). */
  readonly initialFilter?: string
  /** Restricts the rows to one category when the dialog opens (`ctrl+x t` → themes). */
  readonly categoryFilter?: string
  readonly options?: readonly DialogOption[]
  /** The option to highlight first; also the `●` marker. */
  readonly current?: string
  readonly sectionNavigation?: boolean
  /** Prompt initial text, and confirm/alert body text. */
  readonly value?: string
  readonly message?: string
  /** The label of the affirmative action in a confirm dialog. */
  readonly confirmLabel?: string
  /** The field list a `fields` dialog draws (a harness-owned form). */
  readonly fields?: readonly FormFieldSpec[]
  /** Enter on an `action` field: send the current values upstream, keep the form open. */
  readonly onAction?: (key: string, values: Record<string, string>) => void
  /** Preview the highlighted row without committing it (the theme picker). */
  readonly onPreview?: (value: string) => void
  readonly onDone: (value: string | undefined) => void
  readonly sessionId?: string
  readonly job?: ShellJobView
  readonly question?: QuestionSpec
}

/** The keyboard surface of the dialog that owns the modal keys. */
export interface DialogController {
  /** Move the highlighted row by `delta` (a page step is ±10). */
  move(delta: number): void
  moveTo(index: number): void
  /** Jump to the next/previous category header. */
  moveSection(direction: -1 | 1): void
  /** Toggle the active button in a confirm dialog. */
  moveColumn(direction: -1 | 1): void
  /** The highlighted row's index; `undefined` controllers have no row model. */
  selectedIndex?(): number
  /** Run the active row or button. */
  submit(): void
  count(): number
  toggle?(): void
}

/** The store slice a dialog component reads. `AppStore` satisfies it structurally. */
export interface DialogStore {
  color(path: string): string | undefined
  /** The host dictionary: dialog chrome (`Search`, `move`, `run`) is not a key name. */
  label(key: string, fallback: string): string
  dialogStack(): readonly DialogSpec[]
  dialogOpen(): boolean
  dialogController(): DialogController | undefined
  setDialogController(controller: DialogController | undefined): void
  closeTopDialog(value: string | undefined, expectId?: string | number): void
  /** The writer the open harness form registers on mount (the same capture-and-restore
   * pattern as the dialog controller). The host's discovery answer writes a field's
   * value through it, so the form's local values stay the single source of truth. */
  formFieldWriter(): ((key: string, value: string) => void) | undefined
  setFormFieldWriter(writer: ((key: string, value: string) => void) | undefined): void
}

/** One token lookup inside the `@dialog` scope, with a fallback. */
export function dialogColor(store: DialogStore, path: string, fallback: string): string {
  return store.color(`@dialog.${path}`) ?? store.color(path) ?? fallback
}

/** The footer action row. `key` is the literal key label shown next to the title,
 * and `color` overrides the title color (e.g. a confirmation flash). */
export interface DialogFooterAction {
  readonly title: string
  readonly key?: string
  readonly side?: 'left' | 'right'
  readonly disabled?: boolean
  readonly color?: string
  readonly onTrigger?: () => void
}

/** The shared dim layer: one full-screen backdrop under every panel, so a nested stack
 * (provider form → model list → model form) darkens the shell once, not once per entry.
 * A mouse-up outside the panel dismisses the top dialog; a text-selection release does not. */
export function DialogBackdrop(props: { store: DialogStore }) {
  const dimensions = useTerminalDimensions()
  const renderer = useRenderer()
  let dismiss = false
  return (
    <box
      position="absolute"
      left={0}
      top={0}
      zIndex={3000}
      width={dimensions().width}
      height={dimensions().height}
      backgroundColor={RGBA.fromInts(0, 0, 0, 150)}
      onMouseDown={() => {
        dismiss = !!renderer.getSelection()
      }}
      onMouseUp={() => {
        if (dismiss) {
          dismiss = false
          return
        }
        props.store.closeTopDialog(undefined)
      }}
    />
  )
}

/** One panel: the transparent full-screen frame centers the clamped panel, and the panel
 * stops the mouse-up so a click inside it never reaches the backdrop's dismiss handler.
 * `zIndex` stacks nested dialogs so the top of the store's stack paints over the rest. */
export function DialogPanel(props: { store: DialogStore; spec: DialogSpec; zIndex?: number; children: JSX.Element }) {
  const dimensions = useTerminalDimensions()
  const renderer = useRenderer()
  const width = () => Math.min(dialogWidth(props.spec.size ?? 'medium'), dimensions().width - 2)
  return (
    <box
      position="absolute"
      left={0}
      top={0}
      zIndex={props.zIndex ?? 3001}
      width={dimensions().width}
      height={dimensions().height}
      alignItems="center"
      paddingTop={Math.floor(dimensions().height / 4)}
      onMouseUp={(event: { stopPropagation(): void }) => {
        // The release landed on the frame outside the panel: dismiss the top dialog.
        if (renderer.getSelection()?.getSelectedText()) return
        props.store.closeTopDialog(undefined)
        event.stopPropagation()
      }}
    >
      <box
        width={width()}
        maxWidth={dimensions().width - 2}
        backgroundColor={dialogColor(props.store, 'background.base', '#181825')}
        paddingTop={1}
        onMouseUp={(event: { stopPropagation(): void }) => {
          if (renderer.getSelection()?.getSelectedText()) return
          event.stopPropagation()
        }}
      >
        {props.children}
      </box>
    </box>
  )
}

export function DialogHeader(props: ParentProps<{ store: DialogStore; title: string; onClose?: () => void }>) {
  const close = () => (props.onClose ?? (() => props.store.closeTopDialog(undefined)))()
  return (
    <box flexDirection="row" justifyContent="space-between" gap={1}>
      <text attributes={TextAttributes.BOLD} fg={dialogColor(props.store, 'text.base', '#cdd6f4')}>
        {props.title}
      </text>
      {props.children}
      <text fg={dialogColor(props.store, 'text.muted', '#7f849c')} flexShrink={0} onMouseUp={close}>
        esc
      </text>
    </box>
  )
}

/** Header, body, and an optional footer with one blank row between each. */
export function DialogLayout(
  props: ParentProps<{ store: DialogStore; header: JSX.Element; footer?: JSX.Element; inset?: number }>,
) {
  const inset = () => props.inset ?? DIALOG_INSET
  return (
    <box paddingLeft={inset()} paddingRight={inset()} paddingBottom={1} gap={1}>
      {props.header}
      <box>{props.children}</box>
      {props.footer}
    </box>
  )
}

/** Stretches a raised band across the side padding; its content re-applies the inset. */
export function DialogBleed(props: ParentProps) {
  return (
    <box marginLeft={-DIALOG_INSET} marginRight={-DIALOG_INSET}>
      {props.children}
    </box>
  )
}

export function DialogFooter(props: ParentProps<{ store: DialogStore; actions?: DialogFooterAction[]; inset?: number }>) {
  const dimensions = useTerminalDimensions()
  // Below 60 columns the action row stacks vertically so the labels never collide.
  const narrow = () => dimensions().width < DIALOG_STACK_WIDTH
  const actions = () => props.actions ?? []
  const left = () => actions().filter(action => action.side !== 'right')
  const right = () => actions().filter(action => action.side === 'right')
  return (
    <box paddingLeft={props.inset} paddingRight={props.inset} flexDirection="row" justifyContent="space-between" flexShrink={0}>
      <box flexDirection={narrow() ? 'column' : 'row'} gap={narrow() ? 0 : 2}>
        {props.children}
        <For each={left()}>{action => <DialogFooterItem store={props.store} action={action} />}</For>
      </box>
      <box flexDirection="row" gap={2}>
        <For each={right()}>{action => <DialogFooterItem store={props.store} action={action} />}</For>
      </box>
    </box>
  )
}

function DialogFooterItem(props: { store: DialogStore; action: DialogFooterAction }) {
  const normal = () => dialogColor(props.store, 'text.base', '#cdd6f4')
  const muted = () => dialogColor(props.store, 'text.muted', '#7f849c')
  const disabledColor = () => dialogColor(props.store, 'text.action.primary.$disabled', '#565f89')
  return (
    <text
      onMouseUp={() => {
        if (props.action.disabled) return
        props.action.onTrigger?.()
      }}
    >
      <span style={{ fg: props.action.disabled ? disabledColor() : (props.action.color ?? normal()) }}>
        {props.action.title}
      </span>
      {props.action.key !== undefined ? <span style={{ fg: props.action.disabled ? disabledColor() : muted() }}> {props.action.key}</span> : null}
    </text>
  )
}
