/**
 * The spinner.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, 2.0.32,
 * `packages/tui/src/component/spinner.tsx` + `spinner-frames.ts`), MIT; registered in
 * NOTICE.md. Upstream runs the braille block frames on an 80 ms tick and falls back to a
 * single `⋯` when `animations` is off; the shell shows the glyph in two places: the icon
 * cell of a pending tool row, and the prompt footer's left slot while a turn is live.
 * The tick is a plain interval over a shared signal, so the component cleans up when the
 * renderer disposes it and the frame loop repaints on every change.
 * SPDX-License-Identifier: MIT
 */

import { createSignal, onCleanup } from '#solid'

/** Upstream's tick: 80 ms per frame. */
export const SPINNER_INTERVAL_MS = 80

/** The braille block frames, the same sequence opencode cycles. */
export const SPINNER_FRAMES = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']

/** One shared clock for every spinner on screen.
 *
 * A spinner per row would arm an interval per transcript row — on a long session that is
 * hundreds of timers ticking for rows nobody is looking at. The clock starts with the
 * first subscriber and stops with the last, so an idle shell wakes up for nothing.
 * The frame index is monotonic and reduced on read, so two spinners read the same frame.
 */
const [frameTick, setFrameTick] = createSignal(0)
let subscribers = 0
let timer: ReturnType<typeof setInterval> | undefined

export function useSpinner(intervalMs = SPINNER_INTERVAL_MS): () => string {
  if (subscribers === 0) {
    // A fresh burst starts on the first frame: the frame index is shared, so without the
    // reset a spinner mounted after an idle gap would open mid-cycle.
    setFrameTick(0)
    timer = setInterval(() => setFrameTick(tick => tick + 1), intervalMs)
  }
  subscribers += 1
  onCleanup(() => {
    subscribers -= 1
    if (subscribers === 0 && timer !== undefined) {
      clearInterval(timer)
      timer = undefined
    }
  })
  return () => SPINNER_FRAMES[frameTick() % SPINNER_FRAMES.length] ?? '⠋'
}

/** One spinner glyph. */
export function Spinner(props: { fg: string; intervalMs?: number; animated?: boolean }) {
  // `animations = false` paints upstream's still frame instead of arming a timer.
  if (props.animated === false) return <text fg={props.fg} content="⋯" wrapMode="none" />
  const glyph = useSpinner(props.intervalMs ?? SPINNER_INTERVAL_MS)
  return <text fg={props.fg} content={glyph()} flexShrink={0} />
}
