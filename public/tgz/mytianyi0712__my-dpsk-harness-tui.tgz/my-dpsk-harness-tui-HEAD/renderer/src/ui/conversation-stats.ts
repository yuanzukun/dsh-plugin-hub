/** Bottom-bar conversation counters derived from the durable transcript rows.
 *
 * A round is one real user message, including a message whose turn was interrupted. A step
 * is one model step that handed off to tools; multiple parallel tool calls in the same
 * `(turn, step)` count once. These are deliberately independent of the last assistant row,
 * which may be a streaming/partial row with no turn metadata.
 */
import type { TranscriptEvent } from '../protocol/kinds.ts'

export interface ConversationStats {
  readonly rounds: number
  readonly steps: number
}

export function conversationStats(rows: readonly Pick<TranscriptEvent, 'id' | 'role' | 'source' | 'turn' | 'step'>[]): ConversationStats {
  let rounds = 0
  const stepKeys = new Set<string>()
  const fallbackKeys: string[] = []
  for (const row of rows) {
    if (row.role === 'user' && row.source !== 'model-selection') rounds += 1
    if (row.role !== 'tool') continue
    if (row.turn !== undefined && row.step !== undefined) {
      stepKeys.add(`${row.turn}:${row.step}`)
    } else {
      // Older/synthetic rows may omit the pair; keep each call visible rather than silently
      // dropping it from the counter.
      fallbackKeys.push(row.id)
    }
  }
  for (const id of fallbackKeys) stepKeys.add(`tool:${id}`)
  return { rounds, steps: stepKeys.size }
}
