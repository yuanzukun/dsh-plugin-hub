/**
 * Layout constants and breakpoints.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, dev, `packages/tui/src/ui/layout.ts`), MIT.
 * Registered in NOTICE.md under the `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * The numbers are opencode's own: the sidebar and the vertical tab rail share one width, the
 * content floors keep the prompt readable at every split, and the breakpoints decide which
 * chrome collapses. The renderer reads terminal dimensions through `useTerminalDimensions`, so
 * every rule here is a function of the live width, not of a fixed frame.
 */

/** Docked right sidebar width, and the default vertical tab rail width. */
export const SIDEBAR_WIDTH = 40
/** The narrowest the vertical rail may get. */
export const TABS_COMPACT_WIDTH = 5
/** Below this rail width the tab cards collapse to one row each. */
export const TABS_COMPACT_BREAKPOINT = 12
/** The widest the vertical rail may get. */
export const SIDEBAR_MAX_WIDTH = 72
/** The content column never gets narrower than this. */
export const CONTENT_MIN_WIDTH = 44
/** The content column prefers this width. */
export const CONTENT_PREFERRED_WIDTH = 64
/** Below this total width a plugin panel cannot split; it goes fullscreen. */
export const PANEL_SPLIT_MIN_WIDTH = CONTENT_PREFERRED_WIDTH + CONTENT_MIN_WIDTH
/** A vertical tab rail only fits when the terminal is at least this wide. */
export const TABS_FIT_MIN_WIDTH = 106
/** Above this width the right sidebar may dock; below it it paints as an overlay. */
export const SIDEBAR_DOCK_MIN_WIDTH = 120

/** Prompt and home padding: 2 cells, 1 cell under the narrow breakpoint. */
export const NARROW_WIDTH = 44
/** Dialog footer action groups stack into a column below this width. */
export const DIALOG_STACK_WIDTH = 60
/** The home footer hides its version and `/mcps` hint below this width. */
export const HOME_VERSION_WIDTH = 64
/** The home footer hides the `/plugins` hint below this width. */
export const HOME_PLUGINS_WIDTH = 80
/**
 * The rows the session prompt stack spends on chrome *below* the popup's bottom edge: the
 * panel's top padding (1), the metadata row's top padding (1), the metadata row itself (1),
 * and the shadow lip (1).
 *
 * The blank row the stack keeps above the panel is deliberately excluded: the completion
 * popup floats over it, so it sits directly on the panel's top border exactly as it did
 * before that row existed. A running turn adds its own `esc interrupt` row, which the shell
 * counts separately.
 */
export const PROMPT_CHROME_ROWS = 4
/** The assistant footer hides the model name below this width. */
export const ASSISTANT_MODEL_WIDTH = 28
/** The assistant footer hides the duration between this width and the model width. */
export const ASSISTANT_DURATION_WIDTH = 35
/** Below this width the header's host label collapses: the brand token is the only identity
 * row that survives the narrow terminal (dsh's honest mapping of the spec's logo collapse). */
export const LOGO_COLLAPSE_WIDTH = 22
/** Horizontal padding the shell uses at a given terminal width. */
export function shellPadding(width: number): number {
  return width < NARROW_WIDTH ? 1 : 2
}

/** The vertical rail only fits when the terminal leaves the content floor. */
export function tabsFitVertically(total: number, railWidth: number = SIDEBAR_WIDTH): boolean {
  return total >= railWidth + CONTENT_PREFERRED_WIDTH
}

/** The rail resize clamp: never below the compact width, never past the sidebar max, and never
 * so wide that the content column drops under its floor. */
export function clampTabsWidth(requested: number, total: number): number {
  return Math.max(TABS_COMPACT_WIDTH, Math.min(requested, SIDEBAR_MAX_WIDTH, total - CONTENT_MIN_WIDTH))
}

/** The right pane resize clamp: keeps a 24-cell minimum when the terminal can afford it, and
 * always leaves the content its floor. */
export function clampPaneWidth(requested: number, total: number): number {
  const floor = Math.min(24, Math.floor(total / 2))
  return Math.max(floor, Math.min(requested, Math.max(floor, Math.floor(total / 2), total - CONTENT_MIN_WIDTH)))
}

/** The sidebar docks only when the terminal is wide enough after the rail is taken out. */
export function sidebarDocked(width: number, railWidth: number): boolean {
  return width - railWidth > SIDEBAR_DOCK_MIN_WIDTH
}

/** A plugin panel splits only when the terminal is wide enough for both panes. */
export function panelCanSplit(width: number): boolean {
  return width >= PANEL_SPLIT_MIN_WIDTH
}

/** The tab strip is vertical only when the terminal fits the rail plus the content floor. */
export function tabsVertical(width: number): boolean {
  return width >= TABS_FIT_MIN_WIDTH
}
