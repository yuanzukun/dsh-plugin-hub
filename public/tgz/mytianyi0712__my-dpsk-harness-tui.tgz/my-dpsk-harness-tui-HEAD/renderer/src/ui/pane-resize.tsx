/**
 * The pane resize handle.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, 2.0.32,
 * `packages/tui/src/ui/pane-resize.ts` + `ui/pane-resize-handle.tsx`), MIT; registered in
 * NOTICE.md under the `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications:
 * - Upstream's `createPaneResize` factory is inlined here: dsh docks exactly one right pane
 *   (the sidebar or the live terminal), so a shared factory would have one caller.
 * - The clamp is dsh's: never below the 24-cell floor, never so wide that the content column
 *   drops under its 44-cell floor (`clampPaneWidth`).
 *
 * Behaviour that is upstream's, not this package's:
 * - The handle is two cells wide, absolutely positioned on the boundary so it overlays the
 *   content column and the pane instead of taking a cell from either.
 * - The visible cell is the one inside the pane, and it highlights while hovered or while a
 *   drag is in progress.
 * - A double click on the boundary restores the default pane width.
 */

import { MouseButton, type MouseEvent } from '@opentui/core'
import { createSignal } from '#solid'
import { clampPaneWidth, SIDEBAR_WIDTH } from './layout.ts'

interface HandleProps {
  /** The pane's current width. */
  readonly width: number
  /** The terminal width, for the clamp and the boundary math. */
  readonly total: number
  /** Where the boundary sits, in absolute columns: `total - width`. */
  readonly left: number
  /** Whether the pane being resized is on the right of the handle. */
  readonly highlight?: 'left' | 'right'
  readonly onResize: (width: number) => void
  readonly fgHighlight: string
}

/** The handle: two cells on the boundary, hover/drag highlight, drag-to-resize, double-click reset. */
export function PaneResizeHandle(props: HandleProps) {
  const [hovered, setHovered] = createSignal(false)
  const [resizing, setResizing] = createSignal(false)
  let moved = false
  let lastBoundaryClick = 0

  const sizeFrom = (event: MouseEvent): number => clampPaneWidth(props.total - event.x, props.total)
  const commit = (width: number): void => props.onResize(clampPaneWidth(width, props.total))
  const finish = (event: MouseEvent): void => {
    if (!resizing()) return
    const next = moved ? sizeFrom(event) : props.width
    setResizing(false)
    lastBoundaryClick = moved ? 0 : Date.now()
    commit(next)
    event.stopPropagation()
  }

  return (
    <box
      position="absolute"
      left={props.left}
      top={0}
      zIndex={10}
      width={2}
      height="100%"
      onMouseOver={() => setHovered(true)}
      onMouseOut={() => setHovered(false)}
      onMouseDown={(event: MouseEvent) => {
        if (event.button !== MouseButton.LEFT) return
        const now = Date.now()
        if (now - lastBoundaryClick < 300) {
          lastBoundaryClick = 0
          setResizing(false)
          setHovered(false)
          commit(SIDEBAR_WIDTH)
          event.preventDefault()
          event.stopPropagation()
          return
        }
        moved = false
        setResizing(true)
        event.preventDefault()
        event.stopPropagation()
      }}
      onMouseDrag={(event: MouseEvent) => {
        if (!resizing()) return
        moved = true
        lastBoundaryClick = 0
        commit(sizeFrom(event))
        event.stopPropagation()
      }}
      onMouseDragEnd={finish}
      onMouseUp={finish}
    >
      <box
        width={1}
        height="100%"
        marginLeft={props.highlight === 'right' ? 1 : 0}
        backgroundColor={hovered() || resizing() ? props.fgHighlight : undefined}
      />
    </box>
  )
}
