import { describe, expect, test } from 'bun:test'
import { conversationStats } from './conversation-stats.ts'

describe('conversationStats', () => {
  test('counts every real user message, including an interrupted one', () => {
    expect(conversationStats([
      { id: 'u1', role: 'user', source: 'user' },
      { id: 'u2', role: 'user', source: 'user' },
      { id: 'notice', role: 'user', source: 'model-selection' },
      { id: 'a1', role: 'assistant', turn: 1, step: 1 },
    ] as never)).toEqual({ rounds: 2, steps: 0 })
  })

  test('counts a tool-using model step once even when it calls several tools', () => {
    expect(conversationStats([
      { id: 'u1', role: 'user', source: 'user' },
      { id: 't1', role: 'tool', turn: 7, step: 1 },
      { id: 't2', role: 'tool', turn: 7, step: 1 },
      { id: 'a1', role: 'assistant', turn: 7, step: 2 },
      { id: 't3', role: 'tool', turn: 7, step: 2 },
      { id: 'u2', role: 'user', source: 'user' },
    ] as never)).toEqual({ rounds: 2, steps: 2 })
  })

  test('keeps tool rows without step metadata countable', () => {
    expect(conversationStats([
      { id: 't1', role: 'tool' },
      { id: 't2', role: 'tool' },
    ] as never)).toEqual({ rounds: 0, steps: 2 })
  })
})
