/**
 * Transcript row tests: the shapes opencode v2 paints, against the rows the host sends.
 *
 * The rows are rendered through the real `Shell` so the assertions read the painted grid:
 * the user card's gutter, the assistant indent and footer, the tool rows' icons and bodies.
 */

import { expect, test } from 'bun:test'
import { testRender } from '@opentui/solid'
import { Shell, createAppStore, type AppStore } from '../app.tsx'
import type { TranscriptEvent } from '../protocol/kinds.ts'
import { getScrollAcceleration } from './scroll.ts'
import { toolPreviewLine } from './transcript.tsx'
import { isolateShellStore } from '../test-harness.tsx'

/** A session with the given rows, on the session route. */
function sessionStore(events: readonly TranscriptEvent[]): AppStore {
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'session',
      title: 'first prompt',
      events,
      provider: 'cliproxy',
      model: 'mimo-v2.6-pro',
      effort: 'high',
      permission: 'auto',
      preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  return store
}

async function paint(store: AppStore, width = 100, height = 30) {
  isolateShellStore(store)
  const view = await testRender(() => <Shell store={store} />, { width, height })
  // `<markdown>` parses before it lays out, and the transcript's sticky scroll settles one
  // layout later; drain the scheduler until the frame stops changing.
  await view.renderOnce()
  // `<markdown>` parses before it lays out, but the renderable arrives a few scheduler
  // passes later; drain until the frame stops changing.
  for (let pass = 0; pass < 10; pass++) {
    await Bun.sleep(40)
    view.renderer.requestRender?.()
  }
  return { ...view, store }
}

test('a user row paints as the raised card with the accent gutter', async () => {
  const view = await paint(sessionStore([{ id: 'u1', role: 'user', text: 'run the tests' }]))
  const rows = view.captureCharFrame().split('\n')
  const text = rows.findIndex(row => row.includes('run the tests'))
  expect(text).toBeGreaterThan(-1)
  // The card is `┃` in the first content column, two cells of inner padding, then the text.
  expect(rows[text]?.trimStart().startsWith('┃')).toBe(true)
  expect(rows[text]).toMatch(/^\s*┃\s{2,}run the tests/)
  // The gutter runs above and below the text: the card's top and bottom padding rows.
  expect(rows[text - 1]?.trimEnd().endsWith('┃')).toBe(true)
  expect(rows[text + 1]?.trimEnd().endsWith('┃')).toBe(true)
  view.renderer.destroy()
})

test('a model-change notice paints as a system line, not as a user card', async () => {
  const view = await paint(
    sessionStore([
      { id: 'u1', role: 'user', text: 'run the tests' },
      { id: 'u2', role: 'user', text: 'mimo-v2.6-pro → cliproxy/deepseek-v4.1-flash', source: 'model-selection' },
    ]),
  )
  const rows = view.captureCharFrame().split('\n')
  const notice = rows.find(row => row.includes('→')) ?? ''
  // dsh's in-session switch notice: a `↳` line in the muted ink, no card and no gutter.
  expect(notice).toContain('↳ mimo-v2.6-pro → cliproxy/deepseek-v4.1-flash')
  expect(notice).not.toContain('┃')
  // The real user turn above it keeps its card.
  const card = rows.find(row => row.includes('run the tests')) ?? ''
  expect(card).toMatch(/^\s*┃\s{2,}run the tests/)
  view.renderer.destroy()
})

test('the assistant footer carries agent, model, duration and tokens per second', async () => {
  const view = await paint(
    sessionStore([
      // `footer: true` is the host's mark on the one assistant row that closes a turn.
      { id: 'a1', role: 'assistant', text: 'the answer', model: 'mimo-v2.6-pro', durationMs: 1200, tokPerSec: 40, footer: true },
    ]),
  )
  const frame = view.captureCharFrame()
  // The answer sits at the content indent (the viewport's 2-cell padding plus the row's 3),
  // and the footer closes the message.
  expect(frame).toMatch(/^ {5}the answer\s*$/m)
  expect(frame).toContain('standard · mimo-v2.6-pro · 1.2s · 40.0 tok/s')
  view.renderer.destroy()
})

test('an intermediate step of a tool-using turn paints no footer', async () => {
  const view = await paint(
    sessionStore([
      { id: 'a1', role: 'assistant', text: 'let me search', model: 'mimo-v2.6-pro', durationMs: 1000 },
      { id: 't1', role: 'tool', tool: 'websearch', toolInput: { query: 'news' }, toolOutput: ['results'], status: 'ok' },
      { id: 'a2', role: 'assistant', text: 'the answer', model: 'mimo-v2.6-pro', durationMs: 2000, turnDurationMs: 3000, tokPerSec: 53, footer: true },
    ]),
  )
  const rows = view.captureCharFrame().split('\n')
  const footers = rows.filter(row => row.includes('standard · mimo-v2.6-pro'))
  // One footer, on the row that ends the exchange — not one per step.
  expect(footers).toHaveLength(1)
  expect(footers[0]).toContain('3.0s · 53.0 tok/s')
  view.renderer.destroy()
})

test('reasoning starts expanded and folds to a single header row', async () => {
  const view = await paint(
    sessionStore([{ id: 'a1', role: 'assistant', text: 'the answer', reasoning: '**Checks**\nthe failing import', durationMs: 800 }]),
  )
  const expanded = view.captureCharFrame()
  expect(expanded).toContain('- Thought: Checks')
  expect(expanded).toContain('0.8s')
  expect(expanded).toContain('the failing import')
  // The body sits under the gutter, above the answer.
  const body = expanded.split('\n').findIndex(row => row.includes('the failing import'))
  const answer = expanded.split('\n').findIndex(row => row.trim() === 'the answer')
  expect(body).toBeGreaterThan(-1)
  expect(body).toBeLessThan(answer)
  view.store.toggleReasoning('a1')
  await Bun.sleep(0)
  await view.renderOnce()
  const folded = view.captureCharFrame()
  expect(folded).toContain('+ Thought: Checks')
  expect(folded).not.toContain('the failing import')
  view.renderer.destroy()
})

test('classic reasoning says Thinking until the answer text or the stream settles', async () => {
  const thinkingStore = sessionStore([{ id: 'a1', role: 'assistant', reasoning: '**Checks**\nwaiting', text: '', streaming: true }])
  const thinking = await paint(thinkingStore)
  const live = thinking.captureCharFrame()
  expect(live).toContain('Thinking: Checks')
  expect(live).not.toContain('Thought: Checks')
  thinking.renderer.destroy()

  const answeringStore = sessionStore([{ id: 'a1', role: 'assistant', reasoning: '**Checks**\nwaiting', text: 'the answer', streaming: true }])
  const answering = await paint(answeringStore)
  const answeringFrame = answering.captureCharFrame()
  expect(answeringFrame).toContain('Thought: Checks')
  expect(answeringFrame).not.toContain('Thinking: Checks')
  answering.renderer.destroy()

  const settledStore = sessionStore([{ id: 'a1', role: 'assistant', reasoning: '**Checks**\nwaiting', text: 'the answer', durationMs: 800 }])
  const settled = await paint(settledStore)
  expect(settled.captureCharFrame()).toContain('Thought: Checks')
  settled.renderer.destroy()
})

test('a streaming answer with no reasoning never paints an empty Thought header', async () => {
  const view = await paint(sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '', text: 'plain answer', streaming: true },
  ]))
  const frame = view.captureCharFrame()
  expect(frame).toContain('plain answer')
  expect(frame).not.toContain('Thinking')
  expect(frame).not.toContain('Thought')
  view.renderer.destroy()
})

test('clicking the classic reasoning header folds it without calling the store directly', async () => {
  const view = await paint(
    sessionStore([{ id: 'a1', role: 'assistant', text: 'the answer', reasoning: '**Checks**\nthe failing import', durationMs: 800 }]),
  )
  const read = (): string[] => view.captureCharFrame().split('\n')
  const header = read().findIndex(row => row.includes('- Thought: Checks'))
  const column = read()[header]?.indexOf('- Thought:') ?? 0
  expect(header).toBeGreaterThan(-1)
  expect(column).toBeGreaterThan(-1)
  await view.mockMouse.click(column + 2, header)
  await Bun.sleep(0)
  await view.renderOnce()
  const folded = view.captureCharFrame()
  expect(folded).toContain('+ Thought: Checks')
  expect(folded).not.toContain('the failing import')
  view.renderer.destroy()
})
test('the reasoning header, its body and the answer paint in three inks', async () => {
  const view = await paint(
    sessionStore([{ id: 'a1', role: 'assistant', text: 'the answer', reasoning: '**Checks**\nthe failing import', durationMs: 800 }]),
  )
  const frame = view.captureSpans()
  /** The ink of the span carrying `needle`, as `#rrggbb`. */
  const ink = (needle: string): string | undefined => {
    const row = frame.lines.find(line => line.spans.map(span => span.text).join('').includes(needle))
    const channels = row?.spans.find(span => span.text.includes(needle))?.fg?.buffer
    return channels === undefined ? undefined : `#${[0, 1, 2].map(index => (channels[index] ?? 0).toString(16).padStart(2, '0')).join('')}`
  }
  // Upstream's `ReasoningPart`: the open header is the warning ink at 60% over the page, the
  // body the muted ink through the thinking syntax style, and the answer `markdown.text`.
  // Before this, the header inherited the default ink and the body borrowed the answer's
  // syntax colors, so a thought chain read as more answer text.
  expect(ink('Thought:')).toBe('#998c6d')
  expect(ink('the failing import')).toBe('#565f89')
  expect(ink('the answer')).toBe('#cdd6f4')
  // Folding it back paints the header at full strength, the way upstream dims it only open.
  view.store.toggleReasoning('a1')
  await Bun.sleep(0)
  await view.renderOnce()
  const folded = view.captureSpans()
  const foldedRow = folded.lines.find(line => line.spans.map(span => span.text).join('').includes('Thought:'))
  const channels = foldedRow?.spans.find(span => span.text.includes('Thought:'))?.fg?.buffer
  expect(channels === undefined ? undefined : `#${[0, 1, 2].map(index => (channels[index] ?? 0).toString(16).padStart(2, '0')).join('')}`).toBe('#f9e2af')
  view.renderer.destroy()
})

test('a shell call is a block card with the command line and its output', async () => {
  const view = await paint(
    sessionStore([
      {
        id: 't1',
        role: 'tool',
        tool: 'pwsh',
        toolInput: { command: 'npm run check' },
        toolOutput: ['> tsc', 'ok'],
        status: 'ok',
      },
    ]),
  )
  const rows = view.captureCharFrame().split('\n')
  const header = rows.findIndex(row => row.includes('$ npm run check'))
  expect(header).toBeGreaterThan(-1)
  expect(rows[header]?.trimStart().startsWith('┃')).toBe(true)
  const output = rows.findIndex(row => row.includes('> tsc'))
  expect(output).toBeGreaterThan(header)
  // Output lines are the muted body, inside the same card.
  expect(rows[output]).toMatch(/^\s*┃/)
  view.renderer.destroy()
})

test('shell output keeps its tail and counts the lines it folded away', async () => {
  const output = Array.from({ length: 30 }, (_, index) => `line ${index}`)
  const view = await paint(sessionStore([{ id: 't1', role: 'tool', tool: 'pwsh', toolInput: { command: 'seq 30' }, toolOutput: output, status: 'ok' }]), 100, 40)
  const frame = view.captureCharFrame()
  // The last line is on screen, the first is folded into the count row.
  expect(frame).toContain('line 29')
  expect(frame).not.toContain('line 0\n')
  expect(frame).toContain('earlier lines')
  view.renderer.destroy()
})

test('a pending read is an inline row with a spinner and the path', async () => {
  const view = await paint(sessionStore([{ id: 't1', role: 'tool', tool: 'read', toolInput: { path: 'src/app.tsx' }, status: 'pending' }]))
  const frame = view.captureCharFrame()
  // Pending rows swap the icon for the spinner and keep the concrete path in the label.
  expect(frame).toContain('Reading src/app.tsx')
  expect(frame).not.toContain('Reading file…')
  // A settled row is `→ Read <path>`.
  view.store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-frame',
    payload: { sessionId: 'ses_1', events: [{ id: 't1', role: 'tool', tool: 'read', toolInput: { path: 'src/app.tsx' }, status: 'ok' }] },
  })
  await view.renderOnce()
  expect(view.captureCharFrame()).toContain('→ Read src/app.tsx')
  view.renderer.destroy()
})

test('an edit is a block card with the path and the +/- diff', async () => {
  const view = await paint(
    sessionStore([
      {
        id: 't1',
        role: 'tool',
        tool: 'edit',
        toolInput: { path: 'src/app.tsx' },
        filePath: 'src/app.tsx',
        diff: ['- old line', '+ new line'],
        status: 'ok',
      },
    ]),
  )
  const rows = view.captureCharFrame().split('\n')
  const header = rows.findIndex(row => row.includes('← Edit src/app.tsx'))
  expect(header).toBeGreaterThan(-1)
  expect(rows.findIndex(row => row.includes('- old line'))).toBeGreaterThan(header)
  expect(rows.findIndex(row => row.includes('+ new line'))).toBeGreaterThan(header)
  view.renderer.destroy()
})

test('a failed inline tool paints the error glyph and the reason', async () => {
  const view = await paint(
    sessionStore([
      { id: 't1', role: 'tool', tool: 'read', toolInput: { path: 'src/missing.ts' }, status: 'failed', error: 'file not found' },
    ]),
  )
  const frame = view.captureCharFrame()
  expect(frame).toContain('✗ Read src/missing.ts')
  expect(frame).toContain('file not found')
  view.renderer.destroy()
})

test('an answer paints through the native markdown renderable', async () => {
  const view = await paint(
    sessionStore([
      {
        id: 'a1',
        role: 'assistant',
        text: '# Heading\n\nSome **strong** text.\n\n```ts\nconst x = 1\n```',
      },
    ]),
  )
  const frame = view.captureCharFrame()
  // The headings, the emphasis markers and the fence markers are all concealed: the
  // answer reads as prose and code, which is upstream's `markdownMode = "rendered"`.
  expect(frame).toContain('Heading')
  expect(frame).toContain('Some strong text.')
  expect(frame).not.toContain('**strong**')
  expect(frame).toContain('const x = 1')
  expect(frame).not.toContain('```')
  view.renderer.destroy()
})

test('the collapsed tool body follows the settings budget without re-reading the log', async () => {
  const many = Array.from({ length: 30 }, (_, index) => `out ${index}`)
  const store = sessionStore([{ id: 't1', role: 'tool', tool: 'bash', toolInput: { command: 'npm run check' }, toolOutput: many, status: 'ok' }])
  store.apply({ protocolVersion: 2, seq: 2, kind: 'settings', payload: { schemaVersion: 2, values: { maxToolOutputLines: 4 } } })
  const view = await paint(store)
  const frame = view.captureCharFrame()
  // The budget is four rows: the count line plus the newest three, and nothing older.
  expect(frame).toContain('… 27 earlier lines')
  expect(frame).toContain('out 27')
  expect(frame).toContain('out 29')
  expect(frame).not.toContain('out 26')
})

test('the toast queue paints one notice with the queue count under it', async () => {
  const store = sessionStore([{ id: 'u1', role: 'user', text: 'hello' }])
  store.pushNotice('warning', 'first notice')
  store.pauseToast()
  store.pushNotice('error', 'second notice')
  store.pushNotice('info', 'third notice')
  const view = await paint(store)
  const frame = view.captureCharFrame()
  expect(frame).toContain('first notice')
  expect(frame).toContain('+2 more')
  expect(frame).not.toContain('second notice')
  view.renderer.destroy()
})

test('the toast queue collapses duplicate notices', () => {
  const store = sessionStore([{ id: 'u1', role: 'user', text: 'hello' }])
  store.pushNotice('warning', 'same notice')
  // A retrying subsystem reports the same failure repeatedly; the queue keeps one copy.
  store.pauseToast()
  store.pushNotice('warning', 'same notice')
  expect(store.pendingToasts()).toBe(0)
  store.pushNotice('error', 'different')
  expect(store.pendingToasts()).toBe(1)
})

test('animations=false paints the still spinner frame', async () => {
  const store = sessionStore([{ id: 't1', role: 'tool', tool: 'read', toolInput: { path: 'src/app.tsx' }, status: 'pending' }])
  store.apply({ protocolVersion: 2, seq: 2, kind: 'settings', payload: { schemaVersion: 2, values: { animations: false } } })
  const view = await paint(store)
  const frame = view.captureCharFrame()
  expect(frame).toContain('⋯')
  expect(/[⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏]/.test(frame)).toBe(false)
  view.renderer.destroy()
})

test('the transcript scrolls three rows per tick by default and honors the settings', async () => {
  const store = sessionStore([{ id: 'u1', role: 'user', text: 'hello' }])
  expect(getScrollAcceleration(store.settings()).tick()).toBe(3)
  expect(getScrollAcceleration({ scrollSpeed: 7 }).tick()).toBe(7)
  // The accelerated branch is the platform curve, whatever its minified class name is.
  expect(getScrollAcceleration({ scrollAcceleration: true }).constructor.name).toContain('MacOSScrollAccel')
})

/** Turn on the compact transcript style after the initial snapshot. */
function enableCompact(store: AppStore, seq = 2): void {
  store.apply({
    protocolVersion: 2,
    seq,
    kind: 'settings',
    payload: { schemaVersion: 2, values: { newDesigns: true, showReasoning: true } },
  })
}

test('write renders as the opencode block card with the path in its header', async () => {
  const store = sessionStore([
    {
      id: 'w1',
      role: 'tool',
      tool: 'write',
      toolInput: { filePath: 'scripts/mk-btrfs.sh', content: '#!/usr/bin/env bash\nset -euo pipefail' },
      status: 'ok',
    },
  ])
  const view = await paint(store, 100, 30)
  const rows = view.captureCharFrame().split('\n')
  const header = rows.findIndex(row => row.includes('# Wrote scripts/mk-btrfs.sh'))
  expect(header).toBeGreaterThan(-1)
  // The file body is a card body, never part of the title run.
  expect(rows[header]).not.toContain('#!/usr/bin/env bash')
  expect(rows[header]).toContain('┃')
  expect(rows.some(row => row.includes('#!/usr/bin/env bash'))).toBe(true)
  expect(rows.join('\n')).not.toContain('← Write')
  view.renderer.destroy()
})

test('a pending tool row names the tool and argument instead of a bare Running label', async () => {
  const store = sessionStore([
    { id: 'p1', role: 'tool', tool: 'read', toolInput: { path: 'src/deep.ts' }, status: 'pending' },
    { id: 'p2', role: 'tool', tool: 'mystery', toolInput: { action: 'scan workspace' }, status: 'pending' },
  ])
  const view = await paint(store, 100, 30)
  const frame = view.captureCharFrame()
  expect(frame).toContain('Reading src/deep.ts')
  expect(frame).toContain('Running mystery scan workspace')
  expect(frame).not.toContain('Running…')
  view.renderer.destroy()
})

test('the compact transcript paints one Thinking block with preview tools', async () => {
  const store = sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '**Plan**\ncheck grouping', text: '', streaming: true, turn: 1 },
    { id: 't1', role: 'tool', tool: 'read', toolInput: { path: 'renderer/src/ui/transcript.tsx' }, status: 'pending', turn: 1 },
    { id: 'a2', role: 'assistant', reasoning: 'still checking the boundary', text: '', streaming: true, turn: 1 },
  ])
  enableCompact(store)
  const view = await paint(store, 100, 32)
  const frame = view.captureCharFrame()
  expect(frame.match(/Thinking/g)?.length).toBe(1)
  expect(frame).not.toContain('Thought')
  expect(frame).toContain('Used 1 Tool')
  expect(frame).toContain('Running: Read renderer/src/ui/transcript.tsx')
  expect(frame).toContain('Plan')
  expect(frame).toContain('still checking the boundary')
  view.renderer.destroy()
})

test('a compact tool result updates Done in place and keeps the call count', async () => {
  const store = sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '**Plan**\ncheck', text: '', streaming: true, turn: 1 },
    { id: 't1', role: 'tool', tool: 'read', toolInput: { path: 'src/app.tsx' }, status: 'pending', turn: 1 },
  ])
  enableCompact(store)
  const view = await paint(store, 100, 30)
  expect(view.captureCharFrame()).toContain('Running: Read src/app.tsx')
  store.apply({
    protocolVersion: 2,
    seq: 3,
    kind: 'session-frame',
    payload: {
      sessionId: 'ses_1',
      events: [{ id: 't1', role: 'tool', tool: 'read', toolInput: { path: 'src/app.tsx' }, status: 'ok', turn: 1 }],
    },
  })
  await view.renderOnce()
  const frame = view.captureCharFrame()
  expect(frame).toContain('Done: Read src/app.tsx')
  expect(frame).not.toContain('Running: Read src/app.tsx')
  expect(frame).toContain('Used 1 Tool')
  expect(frame.match(/Used 1 Tool/g)?.length).toBe(1)
  view.renderer.destroy()
})

test('the compact preview closes into a Thought header when the answer appears', async () => {
  const store = sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '**Plan**\ncheck grouping', text: '', streaming: true, turn: 1 },
    { id: 't1', role: 'tool', tool: 'grep', toolInput: { pattern: 'ReasoningRow' }, status: 'ok', turn: 1 },
    { id: 'a2', role: 'assistant', reasoning: 'boundary found', text: '', streaming: true, turn: 1 },
  ])
  enableCompact(store)
  const view = await paint(store, 100, 32)
  expect(view.captureCharFrame()).toContain('Done: Grep "ReasoningRow"')
  store.apply({
    protocolVersion: 2,
    seq: 3,
    kind: 'session-frame',
    payload: {
      sessionId: 'ses_1',
      events: [{ id: 'a2', role: 'assistant', reasoning: 'boundary found', text: 'the answer', streaming: false, turn: 1 }],
    },
  })
  for (let pass = 0; pass < 8; pass++) {
    await Bun.sleep(40)
    view.renderer.requestRender?.()
  }
  const frame = view.captureCharFrame()
  expect(frame).toContain('Thought')
  expect(frame).toContain('Used 1 Tool')
  expect(frame).toContain('the answer')
  expect(frame).not.toContain('Done: Grep')
  expect(frame).not.toContain('check grouping')
  view.renderer.destroy()
})

test('a compact block with no tools omits the Used suffix', async () => {
  const store = sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '**Plan**\njust thinking', text: '', streaming: true },
  ])
  enableCompact(store)
  const view = await paint(store, 100, 24)
  const header = view.captureCharFrame().split('\n').find(row => row.includes('Thinking')) ?? ''
  expect(header).toContain('Thinking')
  expect(header).not.toContain('Used')
  view.renderer.destroy()
})

test('a settled compact block formats its duration and tool grammar', async () => {
  const store = sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '**Done**\nreasonable', text: '', createdAt: 70_000, durationMs: 65_000, turn: 1 },
    { id: 't1', role: 'tool', tool: 'glob', toolInput: { pattern: '*.ts' }, status: 'ok', turn: 1 },
  ])
  enableCompact(store)
  const view = await paint(store, 100, 24)
  const frame = view.captureCharFrame()
  expect(frame).toContain('Thought 1m 05s | Used 1 Tool')
  view.renderer.destroy()
})

test('showReasoning=false keeps the compact header and hides the preview', async () => {
  const store = sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '**Secret**\ninternal chain', text: '', streaming: true },
  ])
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'settings',
    payload: { schemaVersion: 2, values: { newDesigns: true, showReasoning: false } },
  })
  const view = await paint(store, 100, 24)
  const frame = view.captureCharFrame()
  expect(frame).toContain('Thinking')
  expect(frame).not.toContain('internal chain')
  view.renderer.destroy()
})

test('compact previews truncate long CJK arguments with ASCII dots at 40 columns', async () => {
  const path = '目录/'.repeat(12) + '文件.tsx'
  const store = sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '**检查**\n正在核对终端宽度', text: '', streaming: true },
    { id: 't1', role: 'tool', tool: 'read', toolInput: { path }, status: 'pending' },
  ])
  enableCompact(store)
  const view = await paint(store, 40, 24)
  const frame = view.captureCharFrame()
  expect(frame).toContain('Running: Read')
  expect(frame).toContain('...')
  // No painted row may exceed the terminal's 40-cell contract.
  for (const row of frame.split('\n')) expect(row.length).toBeLessThanOrEqual(40)
  view.renderer.destroy()
})

test('the compact preview tails the newest ten lines', async () => {
  const reasoning = Array.from({ length: 12 }, (_, index) => `line-${String(index).padStart(2, '0')}`).join('\n')
  const store = sessionStore([{ id: 'a1', role: 'assistant', reasoning, text: '', streaming: true }])
  enableCompact(store)
  const view = await paint(store, 80, 32)
  const frame = view.captureCharFrame()
  expect(frame).toContain('line-11')
  expect(frame).toContain('line-02')
  expect(frame).not.toContain('line-00')
  expect(frame).not.toContain('line-01')
  view.renderer.destroy()
})

for (const width of [80, 120]) {
  test(`the compact header and preview stay inside ${width} columns`, async () => {
    const store = sessionStore([
      { id: 'a1', role: 'assistant', reasoning: '**Wide**\nthe preview must stay in its column', text: '', streaming: true },
      { id: 't1', role: 'tool', tool: 'read', toolInput: { path: 'renderer/src/ui/transcript.tsx' }, status: 'pending' },
    ])
    enableCompact(store)
    const view = await paint(store, width, 24)
    const frame = view.captureCharFrame()
    expect(frame).toContain('Thinking')
    expect(frame).toContain('Used 1 Tool')
    expect(frame).toContain('Running: Read renderer/src/ui/transcript.tsx')
    for (const row of frame.split('\n')) expect(row.length).toBeLessThanOrEqual(width)
    view.renderer.destroy()
  })
}

test('compact failed and denied tools use their one-line error statuses', async () => {
  const store = sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '**Check**\nrunning both', text: '', streaming: true },
    { id: 't1', role: 'tool', tool: 'read', toolInput: { path: 'src/missing.ts' }, status: 'failed', error: 'file not found' },
    { id: 't2', role: 'tool', tool: 'read', toolInput: { path: 'src/secret.ts' }, status: 'denied', error: 'permission denied' },
  ])
  enableCompact(store)
  const view = await paint(store, 100, 32)
  const frame = view.captureCharFrame()
  expect(frame).toContain('Failed: Read src/missing.ts')
  expect(frame).toContain('Denied: Read src/secret.ts')
  expect(frame).toContain('Used 2 Tools')
  view.renderer.destroy()
})

test('toolPreviewLine flattens whitespace and keeps the requested width', () => {
  const line = toolPreviewLine({
    id: 't1',
    role: 'tool',
    tool: 'pwsh',
    toolInput: { command: 'npm\n  run   check' },
    status: 'failed',
  }, 40)
  expect(line.prefix).toBe('Failed: ')
  expect(line.body).toBe('Shell npm run check')
  expect(line.tone).toBe('error')
  const long = toolPreviewLine({ id: 't2', role: 'tool', tool: 'read', toolInput: { path: '目录/'.repeat(20) }, status: 'pending' }, 18)
  expect(long.prefix.startsWith('Running:')).toBe(true)
  expect(long.body.endsWith('...')).toBe(true)
  expect((long.prefix + long.body).length).toBeLessThanOrEqual(18)
})

test('clicking a compact header expands the classic reasoning and tool rows, then folds them', async () => {
  const store = sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '**Plan**\ncomplete reasoning body', text: '', streaming: true },
    { id: 't1', role: 'tool', tool: 'pwsh', toolInput: { command: 'npm run check' }, toolOutput: ['> tsc', 'ok'], status: 'ok' },
  ])
  enableCompact(store)
  const view = await paint(store, 100, 32)
  expect(view.captureCharFrame()).toContain('Done: Shell npm run check')
  let header = view.captureCharFrame().split('\n').findIndex(row => row.includes('Thinking'))
  let column = view.captureCharFrame().split('\n')[header]?.indexOf('Thinking') ?? 0
  await view.mockMouse.click(column, header)
  for (let pass = 0; pass < 4; pass++) {
    await Bun.sleep(40)
    view.renderer.requestRender?.()
  }
  const detail = view.captureCharFrame()
  expect(detail).toContain('Thinking')
  expect(detail).toContain('complete reasoning body')
  expect(detail).toContain('$ npm run check')
  expect(detail).toContain('> tsc')
  expect(detail).not.toContain('Done: Shell npm run check')

  // Clicking the expanded reasoning body folds a live block back to its dynamic preview,
  // not to an empty closed header: the newest lines stay visible while the model works.
  const bodyRow = detail.split('\n').findIndex(row => row.includes('complete reasoning body'))
  const bodyColumn = detail.split('\n')[bodyRow]?.indexOf('complete') ?? 0
  await view.mockMouse.click(bodyColumn, bodyRow)
  await Bun.sleep(40)
  const preview = view.captureCharFrame()
  expect(preview).toContain('Thinking')
  expect(preview).toContain('Done: Shell npm run check')
  expect(preview).not.toContain('$ npm run check')

  header = preview.split('\n').findIndex(row => row.includes('Thinking'))
  column = preview.split('\n')[header]?.indexOf('Thinking') ?? 0
  await view.mockMouse.click(column, header)
  await Bun.sleep(40)
  expect(view.captureCharFrame()).toContain('complete reasoning body')
  // A second header click on a live block again returns to the preview rather than a blank
  // collapsed state.
  header = view.captureCharFrame().split('\n').findIndex(row => row.includes('Thinking'))
  column = view.captureCharFrame().split('\n')[header]?.indexOf('Thinking') ?? 0
  await view.mockMouse.click(column, header)
  await Bun.sleep(40)
  const liveAgain = view.captureCharFrame()
  expect(liveAgain).toContain('Done: Shell npm run check')
  expect(liveAgain).not.toContain('$ npm run check')
  view.renderer.destroy()
})

test('a user-expanded compact block stays expanded when the answer arrives', async () => {
  const store = sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '**Plan**\nreasoning worth reading', text: '', streaming: true, turn: 1 },
    { id: 'a2', role: 'assistant', reasoning: 'more thought', text: '', streaming: true, turn: 1 },
  ])
  enableCompact(store)
  const view = await paint(store, 100, 32)
  const frame = view.captureCharFrame()
  const header = frame.split('\n').findIndex(row => row.includes('Thinking'))
  const column = frame.split('\n')[header]?.indexOf('Thinking') ?? 0
  await view.mockMouse.click(column, header)
  await Bun.sleep(40)
  expect(view.captureCharFrame()).toContain('reasoning worth reading')
  store.apply({
    protocolVersion: 2,
    seq: 3,
    kind: 'session-frame',
    payload: {
      sessionId: 'ses_1',
      events: [{ id: 'a2', role: 'assistant', reasoning: 'more thought', text: 'the answer', streaming: false, turn: 1 }],
    },
  })
  for (let pass = 0; pass < 8; pass++) {
    await Bun.sleep(40)
    view.renderer.requestRender?.()
  }
  const after = view.captureCharFrame()
  expect(after).toContain('Thought')
  expect(after).toContain('reasoning worth reading')
  expect(after).toContain('more thought')
  expect(after).toContain('the answer')
  // Once the block is settled, clicking its reasoning body folds the whole block; the answer
  // remains visible because collapse only hides the thinking detail.
  const bodyRow = after.split('\n').findIndex(row => row.includes('reasoning worth reading'))
  const bodyColumn = after.split('\n')[bodyRow]?.indexOf('reasoning') ?? 0
  await view.mockMouse.click(bodyColumn, bodyRow)
  await Bun.sleep(40)
  const folded = view.captureCharFrame()
  expect(folded).toContain('Thought')
  expect(folded).not.toContain('reasoning worth reading')
  expect(folded).not.toContain('more thought')
  expect(folded).toContain('the answer')
  view.renderer.destroy()
})

test('showReasoning=false still allows a click to inspect the compact detail', async () => {
  const store = sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '**Hidden**\nhidden chain', text: '', streaming: true },
  ])
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'settings',
    payload: { schemaVersion: 2, values: { newDesigns: true, showReasoning: false } },
  })
  const view = await paint(store, 100, 28)
  expect(view.captureCharFrame()).not.toContain('hidden chain')
  const frame = view.captureCharFrame()
  const header = frame.split('\n').findIndex(row => row.includes('Thinking'))
  const column = frame.split('\n')[header]?.indexOf('Thinking') ?? 0
  await view.mockMouse.click(column, header)
  for (let pass = 0; pass < 4; pass++) {
    await Bun.sleep(40)
    view.renderer.requestRender?.()
  }
  expect(view.captureCharFrame()).toContain('hidden chain')
  view.renderer.destroy()
})

test('a live compact duration advances on the shared one-second clock', async () => {
  const store = sessionStore([
    {
      id: 'a1',
      role: 'assistant',
      reasoning: '**Plan**\nstill working',
      text: '',
      streaming: true,
      createdAt: Date.now() - 12_000,
    },
  ])
  enableCompact(store)
  const view = await paint(store, 100, 24)
  const readSeconds = (): number => {
    const match = /Thinking (\d+)s/.exec(view.captureCharFrame())
    return match?.[1] === undefined ? -1 : Number(match[1])
  }
  const before = readSeconds()
  expect(before).toBeGreaterThanOrEqual(12)
  await Bun.sleep(1100)
  await view.renderOnce()
  const after = readSeconds()
  expect(after).toBeGreaterThan(before)
  view.renderer.destroy()
})

test('a transcript click leaves no zero-length selection or foreground-coloured block', async () => {
  const store = sessionStore([{ id: 'a1', role: 'assistant', text: 'selectable answer words that span the row' }])
  const view = await paint(store, 100, 24)
  const rows = view.captureCharFrame().split('\n')
  const row = rows.findIndex(line => line.includes('selectable answer'))
  const column = rows[row]?.indexOf('selectable') ?? 0
  expect(row).toBeGreaterThan(-1)
  await view.mockMouse.click(column + 3, row)
  await Bun.sleep(30)
  await view.renderOnce()
  expect(view.renderer.getSelection()?.getSelectedText() ?? '').toBe('')
  expect(view.renderer.hasSelection).toBe(false)
  const foreground = [0xcd, 0xd6, 0xf4]
  const badSpans = view.captureSpans().lines
    .flatMap(line => line.spans)
    .filter(span => JSON.stringify(span.bg.toInts().slice(0, 3)) === JSON.stringify(foreground))
  expect(badSpans).toEqual([])
  view.renderer.destroy()
})

test('a transcript drag uses the themed selection colour and submit/session changes clear it', async () => {
  const store = sessionStore([{ id: 'a1', role: 'assistant', text: 'selectable answer words that span the row' }])
  const view = await paint(store, 100, 24)
  const rows = view.captureCharFrame().split('\n')
  const row = rows.findIndex(line => line.includes('selectable answer'))
  const start = rows[row]?.indexOf('selectable') ?? 0
  await view.mockMouse.drag(start, row, start + 16, row)
  await Bun.sleep(40)
  await view.renderOnce()
  expect(view.renderer.getSelection()?.getSelectedText() ?? '').not.toBe('')
  const spans = view.captureSpans().lines.flatMap(line => line.spans)
  const channels = (color: { toInts: () => readonly number[] }): number[] =>
    color.toInts().slice(0, 3)
  const hexChannels = (hex: string | undefined): number[] | undefined => {
    const match = /^#([0-9a-f]{6})$/i.exec(hex ?? '')
    if (match === null) return undefined
    const digits = match[1] ?? ''
    return [0, 2, 4].map(offset => Number.parseInt(digits.slice(offset, offset + 2), 16))
  }
  const selectionBg = hexChannels(store.selectionBg())
  const foreground = hexChannels(store.color('text.base') ?? '#cdd6f4')
  expect(selectionBg).toBeDefined()
  expect(foreground).toBeDefined()
  expect(spans.some(span => JSON.stringify(channels(span.bg)) === JSON.stringify(selectionBg))).toBe(true)
  expect(spans.some(span => JSON.stringify(channels(span.bg)) === JSON.stringify(foreground))).toBe(false)

  store.setComposer('next turn')
  store.submitComposer()
  await Bun.sleep(20)
  expect(view.renderer.hasSelection).toBe(false)
  view.renderer.destroy()
})

test('dragging across a compact header selects text without toggling the block', async () => {
  const store = sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '**Plan**\npreview body', text: '', streaming: true },
    { id: 't1', role: 'tool', tool: 'pwsh', toolInput: { command: 'npm run check' }, toolOutput: ['ok'], status: 'ok' },
  ])
  enableCompact(store)
  const view = await paint(store, 100, 28)
  const rows = view.captureCharFrame().split('\n')
  const header = rows.findIndex(line => line.includes('Thinking'))
  const column = rows[header]?.indexOf('Thinking') ?? 0
  await view.mockMouse.drag(column, header, column + 12, header + 1)
  await Bun.sleep(40)
  await view.renderOnce()
  expect(store.thinkingMode('a1')).toBeUndefined()
  expect(view.captureCharFrame()).toContain('Done: Shell npm run check')
  expect(view.renderer.getSelection()?.getSelectedText() ?? '').not.toBe('')
  view.renderer.destroy()
})

test('switching sessions clears an active text selection', async () => {
  const store = sessionStore([{ id: 'a1', role: 'assistant', text: 'selectable session answer' }])
  const view = await paint(store, 100, 24)
  const rows = view.captureCharFrame().split('\n')
  const row = rows.findIndex(line => line.includes('selectable session'))
  const column = rows[row]?.indexOf('selectable') ?? 0
  await view.mockMouse.drag(column, row, column + 12, row)
  await Bun.sleep(30)
  expect(view.renderer.hasSelection).toBe(true)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_2',
      initialRoute: 'session',
      title: 'second',
      events: [{ id: 'u1', role: 'user', text: 'other session' }],
      provider: 'cliproxy',
      model: 'mimo-v2.6-pro',
      effort: 'high',
      permission: 'auto',
      preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  await Bun.sleep(20)
  expect(view.renderer.hasSelection).toBe(false)
  view.renderer.destroy()
})

test('a new turn clears the selection but ordinary stream deltas do not', async () => {
  const store = sessionStore([{ id: 'a1', role: 'assistant', text: 'an answer to copy before the next turn' }])
  const view = await paint(store, 100, 24)
  const rows = view.captureCharFrame().split('\n')
  const row = rows.findIndex(line => line.includes('an answer to copy'))
  const column = rows[row]?.indexOf('an answer') ?? 0
  await view.mockMouse.drag(column, row, column + 11, row)
  await Bun.sleep(30)
  expect(view.renderer.hasSelection).toBe(true)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-frame',
    payload: {
      sessionId: 'ses_1',
      events: [{ id: 'a1', role: 'assistant', text: 'an answer to copy before the next turn grows', streaming: true }],
    },
  })
  await Bun.sleep(20)
  // A delta must not clear a selection the user is still dragging/copying.
  expect(view.renderer.hasSelection).toBe(true)
  store.apply({ protocolVersion: 2, seq: 3, kind: 'turn-state', payload: { sessionId: 'ses_1', running: true } })
  await Bun.sleep(20)
  expect(view.renderer.hasSelection).toBe(false)
  view.renderer.destroy()
})

test('resumed list items conceal strong markers in the answer body', async () => {
  const view = await paint(sessionStore([{
    id: 'a1',
    role: 'assistant',
    text: '- 一般比 Windows 低 **5%~15%**\n- **A 卡 + 单机/Steam 联机**\n\n普通段落 **5.33%** 正常。',
  }]), 100, 30)
  const frame = view.captureCharFrame()
  expect(frame).toContain('5%~15%')
  expect(frame).toContain('A 卡 + 单机/Steam 联机')
  expect(frame).toContain('5.33%')
  expect(frame).not.toContain('**')
  view.renderer.destroy()
})

test('reasoning list items and cross-block strong spans also conceal their markers', async () => {
  const view = await paint(sessionStore([{
    id: 'a1',
    role: 'assistant',
    reasoning: '**检查**\n- **思考列表** 中的加粗',
    text: '这是 **加粗\n文字**。\n\n- **列表加粗**',
  }]), 100, 30)
  const frame = view.captureCharFrame()
  expect(frame).toContain('思考列表 中的加粗')
  expect(frame).toContain('这是 加粗')
  expect(frame).toContain('文字。')
  expect(frame).toContain('列表加粗')
  expect(frame).not.toContain('**')
  view.renderer.destroy()
})

test('switching the thinking style at runtime preserves the live rows', async () => {
  const store = sessionStore([
    { id: 'a1', role: 'assistant', reasoning: '**Plan**\ncompare both styles', text: '', streaming: true },
    { id: 't1', role: 'tool', tool: 'read', toolInput: { path: 'src/app.tsx' }, status: 'pending' },
  ])
  const view = await paint(store, 100, 28)
  expect(view.captureCharFrame()).toContain('Thinking: Plan')
  expect(view.captureCharFrame()).toContain('Reading src/app.tsx')
  store.apply({ protocolVersion: 2, seq: 2, kind: 'settings', payload: { schemaVersion: 2, values: { newDesigns: true } } })
  await view.renderOnce()
  await Bun.sleep(40)
  const compact = view.captureCharFrame()
  expect(compact).toContain('Used 1 Tool')
  expect(compact).toContain('Running: Read src/app.tsx')
  expect(compact).not.toContain('Thinking: Plan')
  store.apply({ protocolVersion: 2, seq: 3, kind: 'settings', payload: { schemaVersion: 2, values: { newDesigns: false } } })
  await view.renderOnce()
  await Bun.sleep(40)
  const classic = view.captureCharFrame()
  expect(classic).toContain('Thinking: Plan')
  expect(classic).toContain('Reading src/app.tsx')
  expect(classic).not.toContain('Used 1 Tool')
  view.renderer.destroy()
})

test('a compact preview appears when the first reasoning chunk arrives after an empty start', async () => {
  const store = sessionStore([{ id: 'a1', role: 'assistant', reasoning: '', text: '', streaming: true }])
  enableCompact(store)
  const view = await paint(store, 100, 24)
  expect(view.captureCharFrame()).toContain('Thinking')
  store.apply({
    protocolVersion: 2,
    seq: 3,
    kind: 'session-frame',
    payload: {
      sessionId: 'ses_1',
      events: [{ id: 'a1', role: 'assistant', reasoning: '**Plan**\nthe first preview line', text: '', streaming: true }],
    },
  })
  for (let pass = 0; pass < 6; pass++) {
    await Bun.sleep(40)
    view.renderer.requestRender?.()
  }
  expect(view.captureCharFrame()).toContain('the first preview line')
  view.renderer.destroy()
})

test('an intermediate assistant body starts a fresh compact block after its tools', async () => {
  const store = sessionStore([
    { id: 'u1', role: 'user', text: 'go', turn: 1 },
    { id: 'a1', role: 'assistant', reasoning: 'before tools', text: 'preamble', turn: 1 },
    { id: 't1', role: 'tool', tool: 'read', toolInput: { path: 'src/app.tsx' }, status: 'ok', turn: 1 },
    { id: 'a2', role: 'assistant', reasoning: 'after preamble', text: 'final answer', turn: 1 },
  ])
  enableCompact(store)
  const view = await paint(store, 100, 30)
  const frame = view.captureCharFrame()
  // The preamble is its own block; the tool + later reasoning start a second compact block.
  expect(frame.match(/Thought/g)?.length).toBe(2)
  expect(frame).toContain('Used 1 Tool')
  expect(frame).toContain('preamble')
  expect(frame).toContain('final answer')
  expect(frame).not.toContain('Thought:')
  expect(frame).not.toContain('after preamble')
  view.renderer.destroy()
})

test('user cards keep one blank page row before classic and compact thinking', async () => {
  const gap = async (compact: boolean) => {
    const store = sessionStore([
      { id: 'u1', role: 'user', text: 'hello', turn: 1 },
      { id: 'a1', role: 'assistant', reasoning: 'plan', text: '', streaming: true, turn: 1 },
    ])
    if (compact) enableCompact(store)
    const view = await paint(store, 100, 30)
    const rows = view.captureCharFrame().split('\n')
    const userRow = rows.findIndex(row => row.includes('hello'))
    const headerRow = rows.findIndex(row => row.includes('Thinking'))
    view.renderer.destroy()
    return { userRow, headerRow, rows }
  }
  const classic = await gap(false)
  const compact = await gap(true)
  expect(classic.userRow).toBeGreaterThanOrEqual(0)
  expect(classic.headerRow).toBeGreaterThan(classic.userRow)
  expect(classic.headerRow - classic.userRow).toBe(3)
  expect(compact.headerRow - compact.userRow).toBe(3)
  expect(classic.rows[classic.userRow + 2]?.trim()).toBe('')
  expect(compact.rows[compact.userRow + 2]?.trim()).toBe('')
})
