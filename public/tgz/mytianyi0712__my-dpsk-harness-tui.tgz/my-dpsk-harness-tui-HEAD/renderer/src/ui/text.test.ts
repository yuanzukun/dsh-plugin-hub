import { describe, expect, test } from 'bun:test'
import { displayWidth, flattenWhitespace, normalizeListStrong, previewText, truncateDirectory, truncateEnd, wrapCells } from './text.ts'

describe('truncateEnd', () => {
  test('keeps the head and appends exactly three ASCII dots', () => {
    const value = truncateEnd('renderer/src/ui/transcript.tsx', 18)
    expect(value.endsWith('...')).toBe(true)
    expect(displayWidth(value)).toBeLessThanOrEqual(18)
    expect(value).not.toContain('…')
  })

  test('never halves a CJK character', () => {
    const value = truncateEnd('中文路径/很长很长', 9)
    expect(displayWidth(value)).toBeLessThanOrEqual(9)
    expect(value.endsWith('...')).toBe(true)
    // Every code point before the marker survived whole.
    for (const char of value.slice(0, -3)) expect(displayWidth(char)).toBeLessThanOrEqual(2)
  })

  test('leaves a string that already fits untouched', () => {
    expect(truncateEnd('Read file', 20)).toBe('Read file')
  })
})

describe('wrapCells', () => {
  test('wraps long ASCII strings into cell-bounded lines', () => {
    const lines = wrapCells('a'.repeat(25), 10)
    expect(lines).toEqual(['a'.repeat(10), 'a'.repeat(10), 'a'.repeat(5)])
  })

  test('wraps CJK at character boundaries and preserves the whole payload', () => {
    const text = '思考块需要按终端单元格宽度换行'
    const lines = wrapCells(text, 7)
    expect(lines.join('')).toBe(text)
    for (const line of lines) expect(displayWidth(line)).toBeLessThanOrEqual(7)
  })

  test('prefers a space break point', () => {
    expect(wrapCells('read src/app.tsx now', 12)).toEqual(['read', 'src/app.tsx', 'now'])
  })

  test('keeps explicit blank lines', () => {
    expect(wrapCells('one\n\ntwo', 20)).toEqual(['one', '', 'two'])
  })
})

describe('previewText', () => {
  test('conceals headings, emphasis, code ticks, and fences but keeps code', () => {
    const value = previewText('# Head\n\n**Checks** and `const x = 1`\n```ts\nconst y = 2\n```\n- list item')
    expect(value).toContain('Head')
    expect(value).toContain('Checks and const x = 1')
    expect(value).toContain('const y = 2')
    expect(value).toContain('list item')
    expect(value).not.toContain('**')
    expect(value).not.toContain('```')
    expect(value).not.toContain('- list')
  })

  test('does not swallow ordinary code content', () => {
    expect(previewText('const snake_case = 1')).toBe('const snake_case = 1')
  })
})

test('flattenWhitespace turns a multi-line detail into one line', () => {
  expect(flattenWhitespace('  npm\n run   check  ')).toBe('npm run check')
})


describe('normalizeListStrong', () => {
  test('strips strong markers from list items and their indented continuations', () => {
    const value = normalizeListStrong('- 一般比 Windows 低 **5%~15%**\n- **A 卡 + 单机/Steam 联机**\n  续行 **5.33%**\n\n普通段落 **仍加粗**')
    expect(value).toContain('低 5%~15%')
    expect(value).toContain('A 卡 + 单机/Steam 联机')
    expect(value).toContain('续行 5.33%')
    expect(value).toContain('普通段落 **仍加粗**')
    expect(value.slice(0, value.indexOf('\n\n'))).not.toContain('**')
  })

  test('does not rewrite fenced code or inline code', () => {
    const value = normalizeListStrong('- title\n```ts\nconst x = "**literal**"\n```\n- `**code**` **strong**')
    expect(value).toContain('const x = "**literal**"')
    expect(value).toContain('`**code**` strong')
  })
})

test('tilde paths keep their home anchor when narrowed', () => {
  expect(truncateDirectory('~/Projects/dsh', 5)).toBe('~/dsh')
  const narrowed = truncateDirectory('~/Projects/very-long-directory-name', 10)
  expect(narrowed.startsWith('~/')).toBe(true)
  expect(displayWidth(narrowed)).toBeLessThanOrEqual(10)
  expect(truncateDirectory('~/dsh', 3)).toBe('dsh')
})
