import { TextAttributes } from '@opentui/core'
import type { ScrollBoxRenderable } from '@opentui/core'
import { useTerminalDimensions } from '@opentui/solid'
import { createMemo, For, onCleanup, onMount } from '#solid'
import { DialogFooter, DialogHeader, DialogLayout, dialogColor, type DialogController, type DialogSpec, type DialogStore } from './dialog.tsx'
import type { TraceRow } from './trace-model.ts'

export function DialogTrace(props: {
  readonly store: DialogStore
  readonly spec: DialogSpec
  readonly rows: () => readonly TraceRow[]
}) {
  const dimensions = useTerminalDimensions()
  let scroll: ScrollBoxRenderable | undefined
  let previous: DialogController | undefined
  const grouped = createMemo(() => {
    const groups: Array<{ category: string; rows: TraceRow[] }> = []
    for (const row of props.rows()) {
      const last = groups.at(-1)
      if (last !== undefined && last.category === row.category) last.rows.push(row)
      else groups.push({ category: row.category, rows: [row] })
    }
    return groups
  })

  const controller: DialogController = {
    move: delta => scroll?.scrollBy(delta * 3, 'step'),
    moveTo: index => scroll?.scrollTo({ x: 0, y: Math.max(0, index * 3) }),
    moveSection: () => undefined,
    moveColumn: () => undefined,
    submit: () => scroll?.scrollTo({ x: 0, y: scroll.scrollHeight }),
    count: () => props.rows().length,
  }

  onMount(() => {
    previous = props.store.dialogController()
    props.store.setDialogController(controller)
  })
  onCleanup(() => props.store.setDialogController(previous))

  return (
    <DialogLayout
      store={props.store}
      header={<DialogHeader store={props.store} title={props.spec.title} />}
      footer={<DialogFooter store={props.store} actions={[
        { title: props.store.label('rendererTraceScroll', 'scroll'), key: '↑↓' },
        { title: props.store.label('rendererTraceClose', 'close'), key: 'esc', side: 'right', onTrigger: () => props.store.closeTopDialog(undefined) },
      ]} />}
    >
      <box flexDirection='column' gap={1}>
        {props.rows().length === 0 ? (
          <text fg={dialogColor(props.store, 'text.muted', '#7f849c')} content={props.store.label('rendererNoTrace', 'no activity')} />
        ) : (
          <scrollbox
            height={Math.max(3, Math.floor(dimensions().height * 0.65) - 6)}
            verticalScrollbarOptions={{ trackOptions: { foregroundColor: dialogColor(props.store, 'text.muted', '#7f849c') } }}
            ref={(value: ScrollBoxRenderable | null) => { scroll = value ?? undefined }}
          >
            <For each={grouped()}>
              {group => (
                <box flexDirection='column' gap={1}>
                  {group.category === '' ? null : (
                    <text fg={dialogColor(props.store, 'hue.accent.200', '#9d7cd8')} attributes={TextAttributes.BOLD} content={group.category} />
                  )}
                  <For each={group.rows}>
                    {row => (
                      <box flexDirection='column' gap={0}>
                        <text fg={dialogColor(props.store, 'text.base', '#cdd6f4')} attributes={TextAttributes.BOLD} content={row.title} wrapMode='none' />
                        <For each={row.details}>
                          {detail => <text fg={dialogColor(props.store, 'text.muted', '#7f849c')} content={detail} wrapMode='word' />}
                        </For>
                      </box>
                    )}
                  </For>
                </box>
              )}
            </For>
          </scrollbox>
        )}
      </box>
    </DialogLayout>
  )
}

