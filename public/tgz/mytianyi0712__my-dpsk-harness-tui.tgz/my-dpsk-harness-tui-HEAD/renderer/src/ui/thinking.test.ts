import { describe, expect, test } from 'bun:test'
import type { TranscriptEvent } from '../protocol/kinds.ts'
import {
  formatThinkingDuration,
  formatToolCount,
  planThinking,
  resolveThinkingMode,
  thinkingHeader,
} from './thinking.ts'

const assistant = (id: string, fields: Partial<TranscriptEvent> = {}): TranscriptEvent =>
  ({ id, role: 'assistant', ...fields })
const tool = (id: string, fields: Partial<TranscriptEvent> = {}): TranscriptEvent =>
  ({ id, role: 'tool', tool: 'read', status: 'ok', ...fields })

describe('planThinking', () => {
  test('merges reasoning and tools before the answer into one thought block', () => {
    const rows = [
      assistant('a1', { reasoning: '**Plan**\nfirst', text: '', streaming: true, turn: 1 }),
      tool('t1', { status: 'pending', toolInput: { path: 'src/app.tsx' }, turn: 1 }),
      assistant('a2', { reasoning: 'second', text: 'the answer', streaming: true, turn: 1 }),
    ]
    const plan = planThinking(rows, { turnRunning: true })
    expect(plan.blocks.size).toBe(1)
    const block = plan.blocks.get('a1')
    expect(block?.rows.map(row => row.id)).toEqual(['a1', 't1', 'a2'])
    expect(block?.leaderId).toBe('a1')
    expect(block?.bodyId).toBe('a2')
    expect(block?.toolCount).toBe(1)
    expect(block?.phase).toBe('thought')
    expect(plan.byRow.get('a1')).toEqual({ blockId: 'a1', leader: true })
    expect(plan.byRow.get('t1')).toEqual({ blockId: 'a1', leader: false })
    expect(plan.byRow.get('a2')).toEqual({ blockId: 'a1', leader: false })
  })

  test('does not invent a block for a plain streaming answer', () => {
    const plan = planThinking([
      assistant('a1', { text: 'plain', streaming: true }),
      assistant('a2', { text: 'later', streaming: true, reasoning: '' }),
    ])
    expect(plan.blocks.size).toBe(0)
    expect(plan.byRow.size).toBe(0)
  })

  test('waits for the first reasoning chunk only when the host indicated reasoning', () => {
    const withReasoningField = planThinking([
      assistant('a1', { text: '', reasoning: '', streaming: true }),
    ])
    expect(withReasoningField.blocks.get('a1')?.phase).toBe('thinking')
    expect(withReasoningField.blocks.get('a1')?.rows).toHaveLength(1)

    const withoutReasoningField = planThinking([
      assistant('a1', { text: '', streaming: true }),
    ])
    expect(withoutReasoningField.blocks.size).toBe(0)
  })

  test('a tool-first block is kept and counts each call once', () => {
    const plan = planThinking([
      tool('t1', { callId: 'call-1', status: 'pending' }),
      tool('t1b', { callId: 'call-1', status: 'ok' }),
      tool('t2', { callId: 'call-2', status: 'failed', error: 'nope' }),
      assistant('a1', { text: 'answer' }),
    ])
    const block = plan.blocks.get('t1')
    expect(block?.rows.map(row => row.id)).toEqual(['t1', 't1b', 't2'])
    expect(block?.toolCount).toBe(2)
    expect(block?.bodyId).toBe('a1')
    expect(block?.rows.at(-1)?.status).toBe('failed')
  })

  test('a body ends one block and later tools start a new compact block', () => {
    const plan = planThinking([
      assistant('a1', { reasoning: 'before', text: 'preamble', turn: 1 }),
      tool('t1', { status: 'pending', turn: 1 }),
      assistant('a2', { reasoning: 'after', text: 'final', turn: 1 }),
    ])
    expect([...plan.blocks.keys()]).toEqual(['a1', 't1'])
    const first = plan.blocks.get('a1')
    const second = plan.blocks.get('t1')
    expect(first?.rows.map(row => row.id)).toEqual(['a1'])
    expect(first?.bodyId).toBe('a1')
    expect(second?.rows.map(row => row.id)).toEqual(['t1', 'a2'])
    expect(second?.leaderId).toBe('t1')
    expect(second?.bodyId).toBe('a2')
    expect(plan.byRow.get('t1')).toEqual({ blockId: 't1', leader: true })
  })

  test('two user turns produce two independent blocks', () => {
    const plan = planThinking([
      assistant('a1', { reasoning: 'one', streaming: true }),
      { id: 'u1', role: 'user', text: 'next', turn: 1 },
      assistant('a2', { reasoning: 'two', streaming: true, turn: 2 }),
      { id: 'u2', role: 'user', text: 'third', turn: 2 },
      assistant('a3', { reasoning: 'three', streaming: true, turn: 3 }),
    ])
    expect([...plan.blocks.keys()]).toEqual(['a1', 'a2', 'a3'])
  })

  test('a turn-number change closes the block even without a user row', () => {
    const plan = planThinking([
      assistant('a1', { reasoning: 'one', streaming: true, turn: 1 }),
      tool('t1', { status: 'ok', turn: 1 }),
      assistant('a2', { reasoning: 'two', streaming: true, turn: 2 }),
    ])
    expect([...plan.blocks.keys()]).toEqual(['a1', 'a2'])
    expect(plan.blocks.get('a1')?.rows.map(row => row.id)).toEqual(['a1', 't1'])
  })

  test('a system row is a hard boundary but later reasoning starts a new block', () => {
    const plan = planThinking([
      assistant('a1', { reasoning: 'one', streaming: true }),
      { id: 's1', role: 'system', text: 'notice' },
      assistant('a2', { reasoning: 'two', streaming: true }),
    ])
    expect([...plan.blocks.keys()]).toEqual(['a1', 'a2'])

    const afterBody = planThinking([
      assistant('a1', { text: 'answer' }),
      { id: 's1', role: 'system', text: 'notice' },
      assistant('a2', { reasoning: 'late', streaming: true }),
    ])
    expect([...afterBody.blocks.keys()]).toEqual(['a2'])
    expect(afterBody.blocks.get('a2')?.rows.map(row => row.id)).toEqual(['a2'])
  })

  test('a single row with reasoning and text is its own leader and body', () => {
    const plan = planThinking([assistant('a1', { reasoning: 'why', text: 'answer', durationMs: 1200, createdAt: 10_000 })])
    const block = plan.blocks.get('a1')
    expect(block?.rows.map(row => row.id)).toEqual(['a1'])
    expect(block?.bodyId).toBe('a1')
    expect(block?.leaderId).toBe('a1')
    expect(block?.startedAt).toBe(8800)
    expect(block?.endedAt).toBe(10_000)
    expect(plan.byRow.get('a1')).toEqual({ blockId: 'a1', leader: true })
  })

  test('the first answer timestamp ends the block when the durable row has one', () => {
    const plan = planThinking([
      assistant('a1', { reasoning: 'why', text: '', createdAt: 10_000 }),
      assistant('a2', { text: 'answer', createdAt: 20_000, bodyAt: 15_000 }),
    ])
    expect(plan.blocks.get('a1')?.startedAt).toBe(10_000)
    expect(plan.blocks.get('a1')?.endedAt).toBe(15_000)
  })

  test('the compact header settles when the streaming body starts', () => {
    const plan = planThinking([
      assistant('a1', { id: 'a1', reasoning: 'why', text: '', streaming: true, createdAt: 1_000, turn: 1 }),
      tool('t1', { status: 'ok', createdAt: 2_000, turn: 1 }),
      assistant('a2', { reasoning: 'done', text: 'answer', streaming: true, createdAt: 12_000, bodyAt: 12_000, turn: 1 }),
    ], { turnRunning: true })
    const block = plan.blocks.get('a1')
    expect(block?.phase).toBe('thought')
    expect(block?.endedAt).toBe(12_000)
    expect(block?.toolCount).toBe(1)
    expect(block ? thinkingHeader(block, 13_000) : '').toBe('Thought 11s | Used 1 Tool')
  })

  test('phase stays thinking only while a live signal remains', () => {
    const streaming = planThinking([assistant('a1', { reasoning: 'why', text: '', streaming: true })], { turnRunning: false })
    expect(streaming.blocks.get('a1')?.phase).toBe('thinking')

    const running = planThinking([assistant('a1', { reasoning: 'why', text: '' })], { turnRunning: true })
    expect(running.blocks.get('a1')?.phase).toBe('thinking')

    const settled = planThinking([assistant('a1', { reasoning: 'why', text: '', createdAt: 20_000 })], { turnRunning: false })
    expect(settled.blocks.get('a1')?.phase).toBe('thought')
    expect(settled.blocks.get('a1')?.endedAt).toBe(20_000)
  })

  test('a pending tool keeps a tool-first block thinking', () => {
    const plan = planThinking([tool('t1', { status: 'pending', createdAt: 1000 })], { turnRunning: false })
    expect(plan.blocks.get('t1')?.phase).toBe('thinking')
    expect(plan.blocks.get('t1')?.startedAt).toBe(1000)
    expect(plan.blocks.get('t1')?.endedAt).toBeUndefined()
  })

  test('failure and denial keep their status in the block rows', () => {
    const plan = planThinking([
      tool('t1', { status: 'denied', error: 'blocked' }),
      tool('t2', { status: 'failed', error: 'boom' }),
      assistant('a1', { text: 'still answered' }),
    ])
    expect(plan.blocks.get('t1')?.rows.map(row => row.status)).toEqual(['denied', 'failed'])
  })
})

describe('thinking formatting', () => {
  test('formats durations below and above a minute', () => {
    expect(formatThinkingDuration(undefined)).toBe('')
    expect(formatThinkingDuration(999)).toBe('')
    expect(formatThinkingDuration(12_000)).toBe('12s')
    expect(formatThinkingDuration(60_000)).toBe('1m 00s')
    expect(formatThinkingDuration(65_000)).toBe('1m 05s')
    expect(formatThinkingDuration(3_605_000)).toBe('60m 05s')
  })

  test('formats tool counts with singular, plural, and omission', () => {
    expect(formatToolCount(0)).toBe('')
    expect(formatToolCount(1)).toBe('Used 1 Tool')
    expect(formatToolCount(2)).toBe('Used 2 Tools')
  })

  test('resolves explicit overrides and the live-preview default', () => {
    expect(resolveThinkingMode({ phase: 'thinking' }, undefined, true)).toBe('preview')
    expect(resolveThinkingMode({ phase: 'thinking' }, undefined, false)).toBe('closed')
    expect(resolveThinkingMode({ phase: 'thought' }, undefined, true)).toBe('closed')
    expect(resolveThinkingMode({ phase: 'thought' }, 'detail', false)).toBe('detail')
    expect(resolveThinkingMode({ phase: 'thinking' }, 'closed', true)).toBe('closed')
  })

  test('builds the header without double spaces', () => {
    expect(thinkingHeader({ phase: 'thinking', startedAt: 1000, toolCount: 2 }, 13_000)).toBe('Thinking 12s | Used 2 Tools')
    expect(thinkingHeader({ phase: 'thought', startedAt: 0, endedAt: 65_000, toolCount: 1 })).toBe('Thought 1m 05s | Used 1 Tool')
    expect(thinkingHeader({ phase: 'thought', toolCount: 1 })).toBe('Thought | Used 1 Tool')
    expect(thinkingHeader({ phase: 'thinking', toolCount: 0 }, 12_000)).toBe('Thinking')
  })
})


