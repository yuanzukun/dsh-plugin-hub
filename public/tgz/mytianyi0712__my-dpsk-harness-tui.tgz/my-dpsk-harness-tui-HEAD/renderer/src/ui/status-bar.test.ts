import { expect, test } from 'bun:test'
import { formatStatusBarSecondLine, statusBarFirstLine, statusBarLine, statusBarMetrics, statusBarRunningLine } from './status-bar.ts'
import { displayWidth, truncateDirectory } from './text.ts'

test('the cwd keeps the full path, then the final directory, then a short tail', () => {
  expect(truncateDirectory('D:/Projects/dsh', 40)).toBe('D:/Projects/dsh')
  expect(truncateDirectory('D:/Projects/dsh', 3)).toBe('dsh')
  expect(truncateDirectory('D:/Projects/very-long-directory-name', 12)).toBe('...tory-name')
  expect(truncateDirectory('D:/项目/源码', 8)).toBe('源码')
  expect(displayWidth(truncateDirectory('D:/项目/very-long-directory-name', 8))).toBeLessThanOrEqual(8)
})

test('the command hint is hidden before the cwd is shortened', () => {
  expect(statusBarFirstLine('D:/Projects/dsh', 'ctrl+p commands', 32)).toEqual({
    directory: 'D:/Projects/dsh',
    hint: 'ctrl+p commands',
  })
  // 15 + 1 + 14 = 30 cells of content: at 24 the hint yields first so the cwd stays whole.
  expect(statusBarFirstLine('D:/Projects/dsh', 'ctrl+p commands', 24)).toEqual({
    directory: 'D:/Projects/dsh',
    hint: '',
  })
  // Once the directory alone cannot fit, it degrades to its final segment and then a tail.
  expect(statusBarFirstLine('D:/Projects/long-repository', 'ctrl+p commands', 16)).toEqual({
    directory: 'long-repository',
    hint: '',
  })
  expect(statusBarFirstLine('D:/Projects/very-long-directory-name', 'ctrl+p commands', 8)).toEqual({
    directory: '...-name',
    hint: '',
  })
})

test('the running row puts the interrupt affordance first and keeps the command hint', () => {
  expect(statusBarRunningLine('esc interrupt', 'shift+tab agents · ctrl+p commands', 80)).toEqual({
    directory: 'esc interrupt',
    hint: 'shift+tab agents · ctrl+p commands',
  })
  // The interrupt keeps its leading slot; the ordinary hint yields before it is truncated.
  expect(statusBarRunningLine('esc interrupt', 'shift+tab agents · ctrl+p commands', 30)).toEqual({
    directory: 'esc interrupt',
    hint: '',
  })
  // Very narrow rows shorten the interrupt label rather than letting the spinner overflow.
  expect(statusBarRunningLine('esc interrupt', 'ctrl+p commands', 8)).toEqual({
    directory: 'esc i…',
    hint: '',
  })
})

test('metrics use disjoint token buckets and omit an undefined step', () => {
  const metrics = statusBarMetrics({
    inputTokens: 12000,
    outputTokens: 3400,
    cacheReadTokens: 8000,
    cacheWriteTokens: 200,
    cacheBucketsComplete: true,
    contextTokens: 12300,
    contextWindow: 131072,
    contextPct: 9,
  }, { turn: 12, step: 4, tokPerSec: 72 })
  expect(metrics).toEqual({
    step: 'T12 S4',
    speed: '72.0 tok/s',
    tokens: '23.6k tokens',
    cache: 'cache 40%',
    context: '12.3k/131.1k (9%)',
  })
  expect(statusBarLine(metrics)).toBe('T12 S4 · 72.0 tok/s | 23.6k tokens · cache 40% | 12.3k/131.1k (9%)')
  expect(statusBarMetrics(undefined, undefined)).toEqual({ step: '', speed: '', tokens: '', cache: '', context: '' })
})

test('cache hit uses a read-only sample when the write bucket is absent', () => {
  const metrics = statusBarMetrics({
    inputTokens: 12000,
    outputTokens: 3400,
    cacheReadTokens: 8000,
    cacheReadComplete: true,
  }, undefined)
  expect(metrics.cache).toBe('cache 40%')
})

test('an observed read in a mixed history paints the cumulative hit share', () => {
  // The first model call omitted the optional cache fields; later calls reported reads.
  // Once any read is observed, omitted fields mean zero cache traffic, not a permanent
  // unknown, so the session can still report its aggregate hit rate.
  const metrics = statusBarMetrics({
    inputTokens: 100,
    outputTokens: 10,
    cacheReadTokens: 50,
    cacheWriteTokens: 0,
    cacheReadObserved: true,
    cacheReadComplete: false,
    cacheBucketsComplete: false,
  }, undefined)
  expect(metrics.cache).toBe('cache 33%')
})

test('cache hit stays unknown when no sample ever reported reads', () => {
  const metrics = statusBarMetrics({
    inputTokens: 100,
    outputTokens: 10,
    cacheReadTokens: 0,
    cacheWriteTokens: 0,
    cacheReadObserved: false,
    cacheReadComplete: false,
    cacheBucketsComplete: false,
  }, undefined)
  expect(metrics.cache).toBe('cache —')
})

test('cache hit falls back to the legacy complete-buckets flag', () => {
  const metrics = statusBarMetrics({
    inputTokens: 100,
    outputTokens: 10,
    cacheReadTokens: 100,
    cacheWriteTokens: 0,
    cacheBucketsComplete: true,
  }, undefined)
  expect(metrics.cache).toBe('cache 50%')
})

test('cache hit stays unknown when the cache denominator is zero', () => {
  expect(statusBarMetrics({ inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0, cacheBucketsComplete: true }, undefined).cache).toBe('cache —')
})

test('the second line is centered and cell-truncated for narrow terminals', () => {
  const metrics = statusBarMetrics({
    inputTokens: 12000,
    outputTokens: 3400,
    cacheReadTokens: 8000,
    cacheWriteTokens: 200,
    cacheBucketsComplete: true,
    contextTokens: 12300,
    contextWindow: 131072,
    contextPct: 9,
  }, { turn: 12, step: 4, tokPerSec: 72 })
  const line = statusBarLine(metrics)
  const centered = formatStatusBarSecondLine(metrics, 40)
  expect(formatStatusBarSecondLine(statusBarMetrics(undefined, undefined), 40)).toBe('')
  expect(displayWidth(line)).toBeGreaterThan(40)
  expect(displayWidth(centered)).toBeLessThanOrEqual(40)
  expect(centered.endsWith('…')).toBe(true)
})
