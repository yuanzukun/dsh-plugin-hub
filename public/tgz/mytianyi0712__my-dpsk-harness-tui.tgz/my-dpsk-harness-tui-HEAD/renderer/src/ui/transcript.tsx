/**
 * Session row rendering.
 *
 * Row structure, glyphs, and breakpoints are ported from opencode v2
 * (`anomalyco/opencode`, 2.0.32, `packages/tui/src/routes/session/index.tsx` and
 * `message-parts.tsx`), MIT. Registered in NOTICE.md under the `opencode` entry;
 * verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications from upstream:
 * - Upstream splits a message into `part` rows dispatched by part type; dsh's host folds
 *   the session log into one row per message/tool call, so the row kinds here are
 *   `user | assistant | system | tool` (`transcript.tsx`'s `TranscriptEvent`).
 * - Agent colors are per-agent palettes upstream (`local.agent.color`); dsh has a single
 *   agent preset list with no palette, so the user card uses the theme's accent hue.
 * - Reasoning defaults to expanded (the user's explicit choice); upstream's
 *   `session.thinking = "hide"` collapses it. The header glyph and colors are upstream's.
 * - Tool titles are built from the call's scalar arguments (`TranscriptEvent.toolInput`):
 *   upstream reads a typed `input` object, dsh's host can only send strings.
 * - No `<Show>` at box level: OpenTUI's reconciler rejects the empty text node a false
 *   `<Show>` inserts into a box parent, so conditions are JSX ternaries.
 */

import { createTextAttributes, type MouseEvent as TuiMouseEvent } from '@opentui/core'
import { For, type JSX } from '#solid'
import type { TranscriptEvent } from '../protocol/kinds.ts'
import { SPLIT_BORDER } from './border.ts'
import { MarkdownText } from './markdown.tsx'
import { Spinner } from './spinner.tsx'
import { previewText, flattenWhitespace, truncateEnd, wrapCells } from './text.ts'
import { resolveThinkingMode, thinkingHeader, thinkingMarker, type ThinkingBlockView, type ThinkingMode } from './thinking.ts'
import { useNowMs } from './clock.ts'

/** The icon column of an inline tool row, in cells (upstream `INLINE_TOOL_ICON_WIDTH`). */
export const INLINE_TOOL_ICON_WIDTH = 2
/** Assistant text, reasoning, and the footer sit this far in from the viewport edge. */
const CONTENT_INDENT = 3
/** Shell output keeps its last 9 lines plus one `…` line (upstream `maxLines = 10`). */
const SHELL_MAX_LINES = 10
/** The diff body keeps its first 20 lines. */
const DIFF_MAX_LINES = 20
/** The assistant footer hides the model below this width (upstream `terminal.width >= 28`). */
export const FOOTER_MODEL_WIDTH = 28
/** …and hides the duration between this width and `FOOTER_MODEL_WIDTH` (upstream `< 36`). */
export const FOOTER_DURATION_WIDTH = 36

/** The slice of the app store the rows read. Kept structural so the rows can be tested
 * without constructing the whole shell. */
export interface RowStore {
  /** One token's color by full path. */
  readonly color: (path: string) => string | undefined
  /** One token's color stepped down its hue scale (upstream `theme.decrease`). */
  readonly decrease: (path: string, amount?: number) => string | undefined
  /** The rows whose fold state the user flipped away from the default. */
  readonly collapsedReasoning: () => ReadonlySet<string>
  readonly toggleReasoning: (id: string) => void
  /** Whether a reasoning body starts open (`session.thinking = "show"`). */
  readonly reasoningOpenByDefault: () => boolean
  /** Whether the compact thinking presentation is enabled (`newDesigns`). */
  readonly newThinkingStyle: () => boolean
  /** The user's explicit compact-block choice, if they made one. */
  readonly thinkingMode: (id: string) => 'detail' | 'closed' | undefined
  readonly toggleThinking: (id: string, live?: boolean) => void
  /** `showReasoning`: hide the automatic preview/body while keeping the header. */
  readonly showReasoning: () => boolean
  /** Theme pair applied to every selectable transcript renderable. */
  readonly selectionBg: () => string
  readonly selectionFg: () => string
  /** True while a text selection exists, so a click handler can leave a drag alone. */
  readonly hasTextSelection: () => boolean
  /** The collapsed tool-output budget in lines, from the settings page. */
  readonly toolOutputLines: () => number
  /** `frontend.animations`: false paints the still `⋯` frame instead of arming a timer. */
  readonly animations: () => boolean
}

/** The shapes a tool call takes: a left-gutter card with a body, or one inline row. */
type ToolShape = 'block' | 'inline'

/** One tool's presentation, resolved from the host's tool name. */
interface ToolDisplay {
  readonly shape: ToolShape
  /** The inline icon cell. Block rows draw no icon. */
  readonly icon?: string
  /** Pending / completed labels for the generic fallback. */
  readonly title: string
  /** The trailing argument (`$ npm run check`, `Read src/app.tsx`). */
  readonly detail: string
  /** Whether the output belongs in the row body. Inline rows never print it. */
  readonly showsOutput: boolean
}

/** `**title**\n…` → `title`; the reasoning summary rule from upstream's `context/thinking.ts`. */
export function reasoningSummary(reasoning: string): string {
  const match = /^\s*\*\*([^*]+)\*\*/.exec(reasoning)
  return match?.[1]?.trim() ?? ''
}

/** `1.2s` — the assistant footer's duration spelling (`Locale.duration`). */
export function formatDuration(ms: number): string {
  return `${(ms / 1000).toFixed(1)}s`
}

/** The first string argument, for a tool with no dedicated row. */
function firstArgument(input: Readonly<Record<string, string>> | undefined): string {
  if (input === undefined) return ''
  for (const value of Object.values(input)) {
    if (value !== '') return value
  }
  return ''
}

/** The `path` argument under any of the spellings the host's tools use. */
function inputPath(input: Readonly<Record<string, string>> | undefined): string {
  if (input === undefined) return ''
  return input.path ?? input.filePath ?? input.file_path ?? input.file ?? ''
}

/** The detail text one tool shows after its label. */
function toolDetail(tool: string, input: Readonly<Record<string, string>> | undefined): string {
  const path = inputPath(input)
  switch (tool) {
    case 'read':
      if (path === '') return ''
      if (input?.offset === undefined && input?.limit === undefined) return path
      {
        const offset = Number(input?.offset ?? 1) || 1
        const limit = Number(input?.limit ?? 0) || 0
        return `${path}:${offset}-${limit === 0 ? '' : offset + limit - 1}`
      }
    case 'glob':
    case 'grep': {
      const pattern = input?.pattern ?? ''
      const where = path === '' ? '' : ` in ${path}`
      return pattern === '' ? where.trim() : `"${pattern}"${where}`
    }
    case 'web_fetch':
    case 'webfetch':
      return input?.url ?? ''
    case 'web_search':
    case 'websearch':
      return input?.query === undefined ? '' : `"${input.query}"`
    case 'subagent':
    case 'task':
      return input?.description ?? ''
    case 'write':
      return path
    case 'pwsh':
    case 'bash':
    case 'shell':
    case 'exec': {
      const command = input?.command ?? input?.cmd ?? ''
      const workdir = input?.workdir ?? ''
      const prefix = workdir === '' || workdir === '.' ? '' : `cd ${workdir} && `
      return `${prefix}${command}`
    }
    default:
      return firstArgument(input)
  }
}

/** Resolve the host's tool name into its row shape. The names are the ones the harness
 * actually emits (`pwsh read write edit glob grep subagent web_fetch web_search
 * todo_write ask_user_question skill`) plus the upstream spellings, so a session recorded
 * by either build paints the same row. */
export function toolDisplay(row: TranscriptEvent): ToolDisplay {
  const tool = row.tool ?? 'tool'
  const input = row.toolInput
  const detail = toolDetail(tool, input)
  switch (tool) {
    case 'pwsh':
    case 'bash':
    case 'shell':
    case 'exec':
      return { shape: 'block', title: 'Shell', detail, showsOutput: true }
    case 'read':
      return { shape: 'inline', icon: '→', title: 'Read', detail, showsOutput: false }
    case 'glob':
      return { shape: 'inline', icon: '✱', title: 'Glob', detail, showsOutput: false }
    case 'grep':
      return { shape: 'inline', icon: '✱', title: 'Grep', detail, showsOutput: false }
    case 'edit':
    case 'strReplaceEditor':
      return { shape: 'block', title: 'Edit', detail, showsOutput: true }
    case 'write':
      return { shape: 'block', title: 'Write', detail, showsOutput: true }
    case 'apply_patch':
    case 'patch':
      return { shape: 'block', title: 'Patched', detail, showsOutput: true }
    case 'subagent':
    case 'task':
      return { shape: 'inline', icon: '│', title: 'Subagent', detail, showsOutput: false }
    case 'web_fetch':
    case 'webfetch':
      return { shape: 'inline', icon: '%', title: 'WebFetch', detail, showsOutput: false }
    case 'web_search':
    case 'websearch':
      return { shape: 'inline', icon: '◈', title: 'Web Search', detail, showsOutput: false }
    default:
      return { shape: 'inline', icon: '✓', title: tool, detail, showsOutput: false }
  }
}

/** Cap a body at `max` lines, folding the head into a count line when it overflows.
 * Shell output keeps the tail (the error is at the end); a diff keeps the head. */
function capLines(lines: readonly string[], max: number, keep: 'head' | 'tail'): { lines: string[]; hidden: number } {
  if (lines.length <= max) return { lines: [...lines], hidden: 0 }
  const visible = keep === 'head' ? lines.slice(0, max) : lines.slice(lines.length - (max - 1))
  return { lines: [...visible], hidden: lines.length - visible.length }
}

/** One row's colors, resolved once per paint. */
interface Palette {
  readonly base: string
  readonly muted: string
  readonly accent: string
  readonly path: string
  readonly error: string
  readonly success: string
  readonly warning: string
  readonly raised: string
  readonly page: string
  readonly border: string
  /** Upstream's `diff.*` table: the patch paints tinted rows, not just tinted glyphs. */
  readonly diff?: {
    readonly addedText: string
    readonly addedBackground: string
    readonly removedText: string
    readonly removedBackground: string
    readonly contextText: string
    readonly contextBackground: string
    readonly hunkHeader: string
  }
}

/** The pending glyph + label of an inline tool row. */
function pendingLabel(display: ToolDisplay): string {
  // A pending row is the only place a live tool call can explain itself. Keep the concrete
  // argument in the label; a bare `Running…` told the user nothing about what was running.
  const detail = flattenWhitespace(display.detail)
  const withDetail = (verb: string, fallback: string): string => detail === '' ? fallback : `${verb} ${detail}`
  switch (display.title) {
    case 'Read':
      return withDetail('Reading', 'Reading file…')
    case 'Glob':
      return withDetail('Finding', 'Finding files…')
    case 'Grep':
      return withDetail('Searching', 'Searching content…')
    case 'Write':
      return withDetail('Writing', 'Preparing write…')
    case 'Edit':
      return withDetail('Editing', 'Preparing edit…')
    case 'WebFetch':
      return withDetail('Fetching', 'Fetching from the web…')
    case 'Web Search':
      return withDetail('Searching', 'Searching web…')
    case 'Subagent':
      return withDetail('Delegating to', 'Delegating…')
    default: {
      const title = display.title === '' ? 'tool' : display.title
      return detail === '' ? `Running ${title}…` : `Running ${title} ${detail}`
    }
  }
}

/**
 * The user's card: a `┃` gutter, the raised background, and 2 cells of inner padding —
 * upstream's `UserMessage`. The gutter carries the agent color upstream; dsh has no
 * per-agent palette, so it carries the theme's accent hue.
 */
function UserRow(props: { row: TranscriptEvent; palette: Palette; children?: JSX.Element }): JSX.Element {
  return (
    <box
      flexShrink={0}
      width="100%"
      marginTop={1}
      border={['left']}
      borderStyle="single"
      borderColor={props.palette.accent}
      customBorderChars={SPLIT_BORDER}
      backgroundColor={props.palette.raised}
      overflow="hidden"
    >
      <box flexDirection="column" paddingTop={1} paddingBottom={1} paddingLeft={2} paddingRight={1} overflow="hidden">
        <text fg={props.palette.base} wrapMode="word" width="100%" content={props.row.text ?? ''} />
        {props.children ?? null}
      </box>
    </box>
  )
}

/** A system row: the muted `↳` line upstream prints for its own bookkeeping messages. */
function SystemRow(props: { row: TranscriptEvent; palette: Palette }): JSX.Element {
  return (
    <box flexShrink={0} width="100%" marginTop={1} paddingLeft={CONTENT_INDENT} paddingRight={1} overflow="hidden">
      <text fg={props.palette.muted} wrapMode="word" width="100%" content={`↳ ${props.row.text ?? ''}`} />
    </box>
  )
}

/**
 * Click activation that does not fight text selection.
 *
 * OpenTUI starts a selection on mouse-down. A drag over the header is therefore a copy
 * gesture, not a fold request. We arm the click on mouse-down, disarm it on any drag, and
 * only commit on mouse-up at (nearly) the same cell. An existing selection also suppresses
 * the first arm so clicking elsewhere dismisses the selection instead of toggling a row.
 */
function clickWithoutSelection(store: RowStore, action: () => void): {
  onMouseDown: (event: TuiMouseEvent) => void
  onMouseDrag: () => void
  onMouseUp: (event: TuiMouseEvent) => void
} {
  let origin: { x: number; y: number } | undefined
  let dragged = false
  return {
    onMouseDown(event) {
      if (store.hasTextSelection()) {
        origin = undefined
        return
      }
      origin = { x: event.x, y: event.y }
      dragged = false
    },
    onMouseDrag() {
      dragged = true
    },
    onMouseUp(event) {
      const start = origin
      origin = undefined
      if (start === undefined || dragged) return
      if (Math.abs(event.x - start.x) > 1 || Math.abs(event.y - start.y) > 1) return
      action()
    },
  }
}
/** The classic `┃` reasoning body. Kept separate so the compact detail view paints exactly
 * the same Markdown body as a settled/open reasoning row. */
function ReasoningBody(props: {
  text: string
  streaming: boolean
  palette: Palette
  store: RowStore
}): JSX.Element {
  return (
    <box
      marginTop={1}
      border={['left']}
      borderStyle="single"
      borderColor={props.store.decrease('background.base') ?? props.palette.border}
      customBorderChars={SPLIT_BORDER}
      paddingLeft={1}
      flexDirection="column"
      overflow="hidden"
    >
      <MarkdownText
        text={props.text}
        color={(path, fallback) => props.store.color(path) ?? fallback}
        streaming={props.streaming}
        ink="text.muted"
        inkFallback={props.palette.muted}
        muted
      />
    </box>
  )
}
/**
 * Reasoning, upstream's `ReasoningPart`: while the thought streams the header is a spinner
 * plus `Thinking`; once the thought stops it becomes a one-line `Thought` header (summary and
 * duration) that toggles the body. Expanded, the body sits behind a `┃` gutter on a
 * hue-step-down border.
 */
function ReasoningRow(props: {
  row: TranscriptEvent
  palette: Palette
  store: RowStore
}): JSX.Element {
  const reasoning = (): string => props.row.reasoning ?? ''
  const streaming = (): boolean => props.row.streaming === true
  /** A streaming row that has no reasoning yet still owns upstream's `Thinking` spinner; a
   * settled row with no reasoning paints nothing. */
  const empty = (): boolean => reasoning().trim() === ''
  // The header is `Thinking` while the model is still working on this step and becomes
  // `Thought` as soon as either the stream marks reasoning complete or answer text appears.
  // Checking the text as well keeps a host that did not send `reasoningDone` from leaving a
  // live `Thinking` header above an answer that has already started.
  const hasText = (): boolean => (props.row.text ?? '').trim() !== ''
  const done = (): boolean => props.row.streaming !== true || props.row.reasoningDone === true || hasText()
  // The default comes from the host's `showReasoning` (`session.thinking`); the set
  // holds the rows the user flipped away from it, so changing the default later keeps
  // each row's explicit choice.
  const flipped = () => props.store.collapsedReasoning().has(props.row.id)
  const open = () => props.store.reasoningOpenByDefault() !== flipped()
  const summary = () => reasoningSummary(reasoning())
  // Upstream's `ReasoningPart`: `Thinking` for as long as the reasoning streams, then a
  // one-line header whose `-`/`+` marker is the fold state, the summary, and the duration.
  // Upstream joins the duration with `·` (`Thought: Fix · 0.8s`); without a summary it is
  // `Thought: 0.8s`, so the colon still introduces the only value on the line.
  const title = (): string => {
    const marker = open() ? '-' : '+'
    const name = summary()
    const duration = props.row.durationMs === undefined ? '' : formatDuration(props.row.durationMs)
    if (name === '') return duration === '' ? `${marker} Thought` : `${marker} Thought: ${duration}`
    return `${marker} Thought: ${name}${duration === '' ? '' : ` · ${duration}`}`
  }
  /** The live header, before the thought is done: upstream's `Thinking`, with the summary the
   * same way it shows one once folded (`Thinking: Fix`). */
  const thinkingLabel = (): string => {
    const name = summary()
    return name === '' ? ' Thinking' : ` Thinking: ${name}`
  }
  // Upstream's `ReasoningHeader`: the header is the warning ink at 60% while the block is
  // open and at full strength once it is folded away. Painting it with the default ink made
  // the header read as more answer text; painting it muted lost it entirely against the
  // muted body.
  const headerColor = () => (open() ? mixTowards(props.palette.page, props.palette.warning, 0.6) : props.palette.warning)
  const activate = clickWithoutSelection(props.store, () => props.store.toggleReasoning(props.row.id))
  return (
    <box flexShrink={0} width="100%" marginTop={1} paddingLeft={CONTENT_INDENT} paddingRight={1} flexDirection="column" overflow="hidden">
      <box
        flexShrink={0}
        width="100%"
        height={1}
        overflow="hidden"
        onMouseDown={activate.onMouseDown}
        onMouseDrag={activate.onMouseDrag}
        onMouseUp={activate.onMouseUp}
      >
        {done() ? (
          <text wrapMode="none" fg={headerColor()} content={title()} />
        ) : (
          <box flexDirection="row" overflow="hidden">
            <Spinner fg={headerColor()} animated={props.store.animations()} />
            <text wrapMode="none" fg={headerColor()} content={thinkingLabel()} />
          </box>
        )}
      </box>
      {open() && !empty() ? (
        <ReasoningBody text={reasoning()} streaming={streaming()} palette={props.palette} store={props.store} />
      ) : null}
    </box>
  )
}

/** One line in the compact thinking preview. `prefix` is painted separately for tool
 * status colour; reasoning lines leave it empty. */
export interface ThinkingPreviewLine {
  readonly prefix: string
  readonly body: string
  readonly tone: 'muted' | 'warning' | 'error'
}

/** The single-line tool projection: `Running: Read src/app.tsx`, `Done: ...`, etc. */
export function toolPreviewLine(row: TranscriptEvent, width: number): ThinkingPreviewLine {
  const display = toolDisplay(row)
  const detail = flattenWhitespace(display.detail)
  const label = detail === '' ? display.title : `${display.title} ${detail}`
  const status = row.status ?? 'ok'
  const word = status === 'pending' ? 'Running' : status === 'failed' ? 'Failed' : status === 'denied' ? 'Denied' : 'Done'
  const prefix = `${word}: `
  const shown = truncateEnd(`${prefix}${label}`, Math.max(1, width))
  const visiblePrefix = shown.startsWith(prefix) ? prefix : shown
  return {
    prefix: visiblePrefix,
    body: shown.slice(visiblePrefix.length),
    tone: status === 'pending' ? 'warning' : status === 'failed' || status === 'denied' ? 'error' : 'muted',
  }
}

/** Project a block into the compact, automatically tailing preview lines. */
export function buildThinkingPreview(block: ThinkingBlockView, width: number): ThinkingPreviewLine[] {
  const out: ThinkingPreviewLine[] = []
  const columns = Math.max(1, width)
  for (const row of block.rows) {
    if (row.role === 'assistant' && (row.reasoning ?? '').trim() !== '') {
      for (const line of previewText(row.reasoning ?? '').split('\n')) {
        for (const wrapped of wrapCells(line, columns)) out.push({ prefix: '', body: wrapped, tone: 'muted' })
      }
    } else if (row.role === 'tool') {
      out.push(toolPreviewLine(row, columns))
    }
  }
  // A block consisting only of fence markers or blank reasoning has no preview content.
  while (out.length > 0 && out.at(-1)?.body === '' && out.at(-1)?.prefix === '') out.pop()
  return out
}

function ThinkingHeader(props: {
  block: ThinkingBlockView
  mode: ThinkingMode
  width: number
  palette: Palette
  store: RowStore
}): JSX.Element {
  const thinking = () => props.block.phase === 'thinking'
  // Only a live header with a known start subscribes; a closed/thought block costs nothing.
  const now = useNowMs(() => thinking() && props.block.startedAt !== undefined)
  const title = () => thinkingHeader(props.block, now())
  const titleWidth = () => Math.max(1, props.width - CONTENT_INDENT - 1 - 2 - (thinking() ? 2 : 0))
  // The same warning ink as classic reasoning: 60% while the body is visible, full strength
  // when folded. The compact header is still one clickable row in every state.
  const ink = () => props.mode === 'closed' ? props.palette.warning : mixTowards(props.palette.page, props.palette.warning, 0.6)
  const activate = clickWithoutSelection(props.store, () => props.store.toggleThinking(props.block.id, props.block.phase === 'thinking'))
  return (
    <box
      flexShrink={0}
      width="100%"
      height={1}
      marginTop={1}
      paddingLeft={CONTENT_INDENT}
      paddingRight={1}
      flexDirection="row"
      overflow="hidden"
      onMouseDown={activate.onMouseDown}
      onMouseDrag={activate.onMouseDrag}
      onMouseUp={activate.onMouseUp}
    >
      <text fg={ink()} wrapMode="none" content={`${thinkingMarker(props.mode)} `} flexShrink={0} />
      {thinking() ? <Spinner fg={ink()} animated={props.store.animations()} /> : null}
      <text
        fg={ink()}
        wrapMode="none"
        flexGrow={1}
        content={`${thinking() ? ' ' : ''}${truncateEnd(title(), titleWidth())}`}
      />
    </box>
  )
}

function ThinkingPreview(props: {
  block: ThinkingBlockView
  width: number
  palette: Palette
}): JSX.Element | null {
  const columns = () => Math.max(1, props.width - CONTENT_INDENT - 2 - 1)
  const content = () => buildThinkingPreview(props.block, columns())
  // The window is exactly 5–10 rows and tails the newest lines. No nested scrollbox: the
  // complete content is one click away in the expanded block.
  const visible = () => content().slice(-10)
  const height = () => visible().length === 0 ? 0 : Math.max(5, Math.min(10, visible().length))
  const rows = () => {
    const lines = visible()
    if (lines.length === 0) return []
    return [...lines, ...Array.from({ length: height() - lines.length }, () => ({ prefix: '', body: '', tone: 'muted' as const }))]
  }
  const tone = (line: ThinkingPreviewLine): string =>
    line.tone === 'warning' ? props.palette.warning : line.tone === 'error' ? props.palette.error : props.palette.muted
  // Keep this component mounted even while the first reasoning chunk is still empty: an
  // Keep this component mounted even while the first reasoning chunk is still empty:
  // an early null return is evaluated once, so the preview would never appear on a delta.
  return (
    <box
      flexShrink={0}
      width="100%"
      height={height()}
      paddingLeft={CONTENT_INDENT + 2}
      paddingRight={1}
      flexDirection="column"
      overflow="hidden"
    >
      <For each={rows()}>
        {line => line.prefix === '' && line.body === ''
          ? <box height={1} width="100%" />
          : (
            <box height={1} width="100%" flexDirection="row" overflow="hidden">
              {line.prefix === '' ? null : <text fg={tone(line)} wrapMode="none" content={line.prefix} flexShrink={0} />}
              <text fg={line.body.length > 0 && line.tone === 'error' ? props.palette.error : props.palette.muted} wrapMode="none" content={line.body} />
            </box>
          )}
      </For>
    </box>
  )
}

/** The expanded compact block: the original reasoning bodies and classic tool rows in
 * timeline order. Header-relative indentation is owned by each reused row, not a wrapper,
 * so block cards keep their normal width. */
function ThinkingDetail(props: {
  block: ThinkingBlockView
  palette: Palette
  store: RowStore
}): JSX.Element {
  // The whole reasoning body is a fold target as well as the header. A live block folds back
  // to its dynamic preview instead of disappearing, so the newest lines stay visible while the
  // model is still thinking; a settled block folds to its one-line header.
  const collapse = clickWithoutSelection(props.store, () => props.store.toggleThinking(props.block.id, props.block.phase === 'thinking'))
  return (
    <box flexShrink={0} width="100%" flexDirection="column" overflow="hidden">
      <For each={props.block.rows}>
        {row => {
          if (row.role === 'assistant' && (row.reasoning ?? '').trim() !== '') {
            return (
              <box
                flexShrink={0}
                width="100%"
                paddingLeft={CONTENT_INDENT}
                flexDirection="column"
                overflow="hidden"
                onMouseDown={collapse.onMouseDown}
                onMouseDrag={collapse.onMouseDrag}
                onMouseUp={collapse.onMouseUp}
              >
                <ReasoningBody
                  text={row.reasoning ?? ''}
                  streaming={row.streaming === true}
                  palette={props.palette}
                  store={props.store}
                />
              </box>
            )
          }
          if (row.role === 'tool') return <ToolRow row={row} palette={props.palette} store={props.store} />
          return null
        }}
      </For>
    </box>
  )
}
function ThinkingBlock(props: {
  block: ThinkingBlockView
  mode: ThinkingMode
  width: number
  palette: Palette
  store: RowStore
}): JSX.Element {
  return (
    <box flexShrink={0} width="100%" flexDirection="column" overflow="hidden">
      <ThinkingHeader {...props} />
      {props.mode === 'preview'
        ? <ThinkingPreview block={props.block} width={props.width} palette={props.palette} />
        : props.mode === 'detail'
          ? <ThinkingDetail block={props.block} palette={props.palette} store={props.store} />
          : null}
    </box>
  )
}
/** Alpha compositing against the page, which is what upstream's reasoning header does
 * with `text.feedback.warning.base` at 0.6: painting 60% of the ink over the background
 * equals mixing the two hex values at that weight. Kept local so the rows stay a pure
 * function of their palette. */
function mixTowards(base: string, color: string, weight: number): string {
  const parse = (value: string): [number, number, number] | undefined => {
    const match = /^#([0-9a-f]{6})$/i.exec(value.trim())
    if (match === null) return undefined
    const hex = match[1] ?? ''
    return [0, 2, 4].map(offset => Number.parseInt(hex.slice(offset, offset + 2), 16)) as [number, number, number]
  }
  const from = parse(base)
  const to = parse(color)
  if (from === undefined || to === undefined) return color
  const channel = (index: number): string =>
    Math.round((from[index] ?? 0) * (1 - weight) + (to[index] ?? 0) * weight)
      .toString(16)
      .padStart(2, '0')
  return `#${channel(0)}${channel(1)}${channel(2)}`
}

/** An inline tool row: the 2-cell icon column, the label, and the tool's own status. */
function InlineToolRow(props: { row: TranscriptEvent; display: ToolDisplay; palette: Palette; store: RowStore }): JSX.Element {
  const status = () => props.row.status ?? 'ok'
  const pending = () => status() === 'pending'
  const failed = () => status() === 'failed'
  const denied = () => status() === 'denied'
  const label = () => {
    const detail = props.display.detail
    if (props.display.title === 'Read') return detail === '' ? 'Read' : `Read ${detail}`
    if (props.display.title === 'Glob' || props.display.title === 'Grep') {
      return detail === '' ? props.display.title : `${props.display.title} ${detail}`
    }
    if (props.display.title === 'WebFetch') return detail === '' ? 'WebFetch' : `WebFetch ${detail}`
    if (props.display.title === 'Web Search') return detail === '' ? 'Web Search' : `Web Search ${detail}`
    if (props.display.title === 'Subagent') return detail === '' ? 'Subagent' : `Subagent — ${detail}`
    if (props.display.title === 'Write') return detail === '' ? 'Write' : `Write ${detail}`
    return detail === '' ? props.display.title : `${props.display.title} ${detail}`
  }
  // Upstream's `InlineTool` resolves a settled row to `text.muted` and only lifts it to
  // `text.base` while a clickable row is hovered; dsh has no click affordance on these rows
  // yet, so the settled ink stays muted. Failure is the one state that carries feedback.
  const textColor = () => (failed() ? props.palette.error : props.palette.muted)
  const icon = () => (failed() ? '✗' : props.display.icon ?? '✓')
  return (
    <box flexShrink={0} width="100%" marginTop={1} paddingLeft={CONTENT_INDENT} paddingRight={1} flexDirection="column" overflow="hidden">
      <box flexDirection="row" width="100%" overflow="hidden">
        {pending() ? (
          <box width={INLINE_TOOL_ICON_WIDTH} flexShrink={0}>
            <Spinner fg={props.palette.warning} animated={props.store.animations()} />
          </box>
        ) : (
          <text fg={failed() ? props.palette.error : props.palette.muted} width={INLINE_TOOL_ICON_WIDTH} flexShrink={0} content={icon()} />
        )}
        <text
          flexGrow={1}
          fg={pending() ? props.palette.muted : textColor()}
          attributes={denied() ? createTextAttributes({ strikethrough: true }) : undefined}
          wrapMode="none" content={pending() ? pendingLabel(props.display) : label()} />
      </box>
      {failed() && props.row.error !== undefined && props.row.error !== '' ? (
        <text fg={props.palette.error} paddingLeft={INLINE_TOOL_ICON_WIDTH} wrapMode="word" width="100%" content={props.row.error} />
      ) : null}
    </box>
  )
}

/** The diff body: `- ` lines in the error color, `+ ` lines in the success color. */
function DiffBody(props: { diff: readonly string[]; palette: Palette }): JSX.Element {
  const capped = () => capLines(props.diff, DIFF_MAX_LINES, 'head')
  return (
    <box flexDirection="column" width="100%" overflow="hidden">
      <For each={capped().lines}>
        {line => {
          const ink = props.palette.diff
          // Upstream's `patch-diff`: a removed row is red on the removed tint, an added row
          // green on the added tint, a hunk header is its own colour, and context rows keep
          // the page but dim their text. The tint is what makes a patch read as a block.
          const removed = line.startsWith('-')
          const added = line.startsWith('+')
          const hunk = line.startsWith('@@')
          const fg = ink === undefined
            ? (removed ? props.palette.error : added ? props.palette.success : props.palette.base)
            : hunk ? ink.hunkHeader : removed ? ink.removedText : added ? ink.addedText : ink.contextText
          const bg = ink === undefined
            ? undefined
            : hunk ? undefined : removed ? ink.removedBackground : added ? ink.addedBackground : ink.contextBackground
          return <text fg={fg} bg={bg} wrapMode="word" width="100%" content={line} />
        }}
      </For>
      {capped().hidden > 0 ? (
        <text fg={props.palette.muted} content={`… ${capped().hidden} more lines`} />
      ) : null}
    </box>
  )
}

/** A block tool row: the raised card with the `┃` gutter, a header, and the body. */
function BlockToolRow(props: { row: TranscriptEvent; display: ToolDisplay; palette: Palette; store: RowStore }): JSX.Element {
  const status = () => props.row.status ?? 'ok'
  const pending = () => status() === 'pending'
  const failed = () => status() === 'failed'
  // The budget is a paint-time setting: the host sends every line, so changing it never
  // re-reads the log or re-runs a model.
  const isShell = () => props.display.title === 'Shell'
  const isEdit = () => props.display.title === 'Edit' || props.display.title === 'Patched'
  const isWrite = () => props.display.title === 'Write'
  const output = () => {
    if (isWrite()) {
      const content = props.row.toolInput?.content ?? ''
      return capLines(content === '' ? [] : content.split('\n'), Math.max(1, props.store.toolOutputLines()), 'head')
    }
    return capLines(props.row.toolOutput ?? [], Math.max(1, props.store.toolOutputLines()), 'tail')
  }
  const header = () => {
    if (isShell()) return props.display.detail === '' ? 'Writing command…' : `$ ${props.display.detail}`
    if (isEdit()) return props.display.detail === '' ? props.display.title : `← ${props.display.title} ${props.display.detail}`
    if (isWrite()) {
      if (props.display.detail === '') return pending() ? '# Writing…' : '# Wrote'
      return pending() ? `# Writing ${props.display.detail}…` : `# Wrote ${props.display.detail}`
    }
    return props.display.detail === '' ? props.display.title : `${props.display.title} ${props.display.detail}`
  }
  const headerColor = () => (failed() ? props.palette.error : pending() ? props.palette.muted : props.palette.base)
  return (
    <box
      flexShrink={0}
      width="100%"
      marginTop={1}
      border={['left']}
      borderStyle="single"
      borderColor={props.palette.page}
      customBorderChars={SPLIT_BORDER}
      backgroundColor={props.palette.raised}
      paddingTop={1}
      paddingBottom={1}
      paddingLeft={2}
      paddingRight={1}
      flexDirection="column"
      gap={1}
      overflow="hidden"
    >
      <box flexDirection="row" gap={1} width="100%" overflow="hidden">
        {pending() ? <Spinner fg={props.palette.warning} animated={props.store.animations()} /> : null}
        <text fg={headerColor()} wrapMode={props.display.detail.includes('\n') ? 'word' : 'none'} width="100%" content={header().replace(/^\$ /, pending() ? '' : '$ ')} />
      </box>
      {isEdit() && props.row.diff !== undefined && props.row.diff.length > 0 ? (
        <DiffBody diff={props.row.diff} palette={props.palette} />
      ) : null}
      {props.display.showsOutput && output().lines.length > 0 ? (
        <box flexDirection="column" width="100%" overflow="hidden">
          {output().hidden > 0 ? <text fg={props.palette.muted} content={`… ${output().hidden} ${isWrite() ? 'more' : 'earlier'} lines`} /> : null}
          <For each={output().lines}>{line => <text fg={props.palette.muted} wrapMode="none" content={line} />}</For>
        </box>
      ) : null}
      {props.row.error !== undefined && props.row.error !== '' ? (
        <text fg={props.palette.error} wrapMode="word" width="100%" content={props.row.error} />
      ) : null}
    </box>
  )
}

/** Dispatch one tool row to the existing inline/block presentation. The compact detail view
 * and the classic path share this function; no compact-only tool renderer is introduced. */
function ToolRow(props: { row: TranscriptEvent; palette: Palette; store: RowStore }): JSX.Element {
  const display = toolDisplay(props.row)
  if (display.shape === 'block') {
    return <BlockToolRow row={props.row} display={display} palette={props.palette} store={props.store} />
  }
  return <InlineToolRow row={props.row} display={display} palette={props.palette} store={props.store} />
}
/** The assistant footer: agent · model · duration · tok/s · interrupted, with upstream's
 * 28/36-column breakpoints. The duration and the rate are the turn's, not the step's: a
 * tool-using turn has one footer, and its numbers cover the whole exchange. */
function AssistantFooter(props: {
  row: TranscriptEvent
  agentLabel: string
  width: number
  palette: Palette
}): JSX.Element | null {
  const duration = (): number | undefined => props.row.turnDurationMs ?? props.row.durationMs
  const parts = (): Array<{ text: string; fg: string }> => {
    const out: Array<{ text: string; fg: string }> = []
    // An unknown preset contributes nothing: the footer's first run would otherwise be an
    // empty cell before the `·`.
    if (props.agentLabel !== '') out.push({ text: props.agentLabel, fg: props.row.error === undefined ? props.palette.accent : props.palette.muted })
    if (props.width >= FOOTER_MODEL_WIDTH && props.row.model !== undefined) out.push({ text: props.row.model, fg: props.palette.muted })
    const ms = duration()
    if (ms !== undefined && (props.width < FOOTER_MODEL_WIDTH || props.width >= FOOTER_DURATION_WIDTH)) {
      out.push({ text: formatDuration(ms), fg: props.palette.muted })
    }
    if (props.row.tokPerSec !== undefined) out.push({ text: `${props.row.tokPerSec.toFixed(1)} tok/s`, fg: props.palette.muted })
    if (props.row.interrupted === true) out.push({ text: 'interrupted', fg: props.palette.muted })
    return out
  }
  if (parts().length === 0) return null
  return (
    <box flexShrink={0} width="100%" marginTop={1} paddingLeft={CONTENT_INDENT} paddingRight={1} overflow="hidden">
      <box flexDirection="row" gap={0} overflow="hidden">
        <For each={parts()}>
          {(part, index) => (
            <text fg={part.fg} wrapMode="none" content={index() === 0 ? part.text : ` · ${part.text}`} />
          )}
        </For>
      </box>
    </box>
  )
}

/** The assistant's answer text. `children` is the caller's markdown renderable: the
 * renderer owns the syntax style, so the row stays a layout component. */
function AssistantRow(props: {
  row: TranscriptEvent
  palette: Palette
  agentLabel: string
  width: number
  children: JSX.Element
}): JSX.Element {
  return (
    <box flexShrink={0} width="100%" flexDirection="column" overflow="hidden">
      {props.row.text !== undefined && props.row.text !== '' ? (
        <box marginTop={1} paddingLeft={CONTENT_INDENT} paddingRight={1} flexDirection="column" overflow="hidden">
          {props.children}
        </box>
      ) : null}
      {/* Upstream adds the footer when the message reaches a terminal state; while a row is
       * still streaming the footer is absent, so a delta never repaints or resizes it.
       * A tool-using turn has several assistant rows, and only the one the host marked
       * `footer` closes the exchange — a footer after every step read as if the turn were
       * over while the tools were still running. */}
      {props.row.streaming === true || props.row.footer !== true ? null : (
        <AssistantFooter row={props.row} agentLabel={props.agentLabel} width={props.width} palette={props.palette} />
      )}
      {props.row.error !== undefined && props.row.error !== '' ? (
        <box paddingLeft={CONTENT_INDENT} paddingRight={1} overflow="hidden">
          <text fg={props.palette.error} wrapMode="word" width="100%" content={`Error: ${props.row.error}`} />
        </box>
      ) : null}
    </box>
  )
}

/**
 * One transcript row. `children` is the markdown body for an assistant row (the shell
 * owns the syntax style and the renderer hook); every other row ignores it.
 */
export function TranscriptRow(props: {
  row: TranscriptEvent
  store: RowStore
  agentLabel: string
  width: number
  /** Present when the compact plan assigned this row to a thinking block. */
  thinking?: { readonly block: ThinkingBlockView; readonly leader: boolean }
  children?: JSX.Element
}): JSX.Element | null {
  const palette = (): Palette => ({
    base: props.store.color('text.base') ?? '#cdd6f4',
    muted: props.store.color('text.muted') ?? '#565f89',
    accent: props.store.color('hue.accent.200') ?? props.store.color('text.action.primary.$selected') ?? '#9d7cd8',
    path: props.store.color('text.path.base') ?? '#89d7eb',
    error: props.store.color('text.feedback.error.base') ?? '#f38ba8',
    success: props.store.color('text.feedback.success.base') ?? '#a6e22e',
    warning: props.store.color('text.feedback.warning.base') ?? '#f9e2af',
    raised: props.store.color('background.raised.base') ?? '#181825',
    page: props.store.color('background.base') ?? '#0a0a0a',
    border: props.store.color('border.base') ?? '#484848',
    // Upstream's `diff.*` table. A patch paints tinted rows (added/removed/context) and its
    // hunk headers in their own ink, which is what makes a diff read as a block rather than
    // as coloured `+`/`-` glyphs on the page.
    diff: {
      addedText: props.store.color('diff.text.added') ?? '#a6e22e',
      addedBackground: props.store.color('diff.background.added') ?? '#1c2b1c',
      removedText: props.store.color('diff.text.removed') ?? '#f38ba8',
      removedBackground: props.store.color('diff.background.removed') ?? '#2b1c1c',
      contextText: props.store.color('diff.text.context') ?? '#565f89',
      contextBackground: props.store.color('diff.background.context') ?? '#0a0a0a',
      hunkHeader: props.store.color('diff.text.hunkHeader') ?? '#9d7cd8',
    },
  })
  if (props.row.role === 'user') {
    if (props.row.source !== undefined && props.row.source !== 'user') return <SystemRow row={props.row} palette={palette()} />
    return <UserRow row={props.row} palette={palette()}>{props.children}</UserRow>
  }
  if (props.row.role === 'system') return <SystemRow row={props.row} palette={palette()} />
  // Rows assigned to compact thinking are painted by their leader. A non-leader row has
  // already contributed its reasoning/tool/card body to the block, so painting it again
  // would duplicate content.
  const compact = () => props.thinking
  const mode = () => compact() === undefined
    ? 'closed'
    : resolveThinkingMode(compact()!.block, props.store.thinkingMode(compact()!.block.id), props.store.showReasoning())
  if (props.row.role === 'tool') {
    if (compact() !== undefined) {
      if (compact()!.leader !== true) return null
      return (
        <ThinkingBlock
          block={compact()!.block}
          mode={mode()}
          width={props.width}
          palette={palette()}
          store={props.store}
        />
      )
    }
    return <ToolRow row={props.row} palette={palette()} store={props.store} />
  }
  const hasBody = () => (props.row.text ?? '') !== '' || props.row.footer === true || (props.row.error ?? '') !== ''
  // A non-leader assistant row paints only its answer/footer/error; its reasoning lives in
  // the block's detail view. Do not early-return here: the box must stay mounted so a later
  // text/footer/error update can mount the answer inside it.
  return (
    <box flexShrink={0} width="100%" flexDirection="column" overflow="hidden">
      {compact() !== undefined
        ? compact()!.leader === true
          ? <ThinkingBlock block={compact()!.block} mode={mode()} width={props.width} palette={palette()} store={props.store} />
          : null
        : (props.row.reasoning ?? '').trim() !== ''
          || (props.row.streaming === true && (props.row.text ?? '').trim() === '' && props.row.reasoning !== undefined)
          ? <ReasoningRow row={props.row} palette={palette()} store={props.store} />
          : null}
      {compact() !== undefined && !hasBody()
        ? null
        : (
          <AssistantRow row={props.row} palette={palette()} agentLabel={props.agentLabel} width={props.width}>
            {props.children ?? null}
          </AssistantRow>
        )}
    </box>
  )
}
