/**
 * `@` path completion.
 *
 * Written for this package, not ported. The row list comes from the host's
 * workspace index (`workspace-files`): the renderer never walks the filesystem,
 * so the completion names only paths that are really in the session's workspace.
 *
 * The boundary gate keeps `@deepseek-ai/*` out of the renderer, and the session
 * reference syntax (`@[label](dsh-session:…)`) is produced by the host's parser,
 * so this module only completes filesystem paths.
 */


/** The trailing `@…` token the composer is completing, or `undefined` when the
 * caret is not inside a mention. A token with whitespace is already finished. */
export function trailingMention(text: string): string | undefined {
  const match = /@[^\s]*$/.exec(text)
  if (match === null) return undefined
  return match[0]
}

/**
 * Complete a `@` token against the workspace.
 *
 * `@src/ipc/kin` lists the entries of `<workspace>/src/ipc` that start with `kin`;
 * directories get a trailing `/` so the next keystroke continues inside them. The
 * root token `@` lists the workspace's top level. Results are capped so a huge
 * directory cannot flood the composer.
 */
export function mentionSuggestions(entries: readonly string[], token: string, limit = 12): string[] {
  if (!token.startsWith('@')) return []
  const body = token.slice(1)
  const matches = entries
    .filter(entry => entry.startsWith(body))
    .sort((left, right) => left.localeCompare(right))
  // The host's index lists directories with a trailing `/`; any other name is a file.
  return matches.slice(0, limit).map(entry => `@${entry}`)
}
