import { displayWidth, formatTokens, truncate, truncateDirectory } from './text.ts'

export interface StatusBarUsage {
  readonly inputTokens: number
  readonly outputTokens: number
  readonly cacheReadTokens?: number
  readonly cacheWriteTokens?: number
  readonly cacheReadObserved?: boolean
  readonly cacheReadComplete?: boolean
  readonly cacheWriteComplete?: boolean
  readonly cacheBucketsComplete?: boolean
  readonly contextTokens?: number
  readonly contextWindow?: number
  readonly contextPct?: number
}

export interface StatusBarStep {
  readonly turn?: number
  readonly step?: number
  readonly tokPerSec?: number
}

export interface StatusBarMetrics {
  readonly step: string
  readonly speed: string
  readonly tokens: string
  readonly cache: string
  readonly context: string
}

export function statusBarMetrics(usage: StatusBarUsage | undefined, step: StatusBarStep | undefined): StatusBarMetrics {
  const total = usage === undefined
    ? undefined
    : usage.inputTokens + usage.outputTokens + (usage.cacheReadTokens ?? 0) + (usage.cacheWriteTokens ?? 0)
  const cacheDenominator = usage === undefined
    ? 0
    : usage.inputTokens + (usage.cacheReadTokens ?? 0) + (usage.cacheWriteTokens ?? 0)
  // `cacheReadObserved` means at least one provider sample explicitly reported reads.
  // In that case a later/earlier sample omitting the optional field is a zero for the
  // session ratio, not a permanent "unknown"; an adapter that never reports reads still
  // stays `cache —`. Older hosts only sent the completeness flags.
  const readReported = usage !== undefined
    && (usage.cacheReadObserved !== undefined
      ? usage.cacheReadObserved
      : usage.cacheReadComplete ?? usage.cacheBucketsComplete === true)
  const context = usage?.contextTokens === undefined
    ? ''
    : `${formatTokens(usage.contextTokens)}${usage.contextWindow === undefined ? '' : `/${formatTokens(usage.contextWindow)}`}${usage.contextPct === undefined ? '' : ` (${usage.contextPct}%)`}`
  return {
    step: step?.turn === undefined || step.step === undefined ? '' : `T${step.turn} S${step.step}`,
    speed: step?.tokPerSec === undefined ? '' : `${step.tokPerSec.toFixed(1)} tok/s`,
    tokens: total === undefined ? '' : `${formatTokens(total)} tokens`,
    cache: usage === undefined
      ? ''
      : readReported !== true || cacheDenominator === 0
        ? 'cache —'
        : `cache ${Math.round((usage.cacheReadTokens ?? 0) / cacheDenominator * 100)}%`,
    context,
  }
}

export function statusBarLine(metrics: StatusBarMetrics): string {
  const groups = [
    [metrics.step, metrics.speed].filter(Boolean).join(' · '),
    [metrics.tokens, metrics.cache].filter(Boolean).join(' · '),
    metrics.context,
  ].filter(Boolean)
  return groups.join(' | ')
}

export interface StatusBarFirstLine {
  readonly directory: string
  readonly hint: string
}

/**
 * Split the first row's cells between the cwd and the hint.
 *
 * The hint yields first: when both do not fit, it is dropped before the directory is
 * shortened, so a narrow terminal still names the directory it is in.
 */
export function statusBarFirstLine(directory: string, hint: string, width: number): StatusBarFirstLine {
  const safeWidth = Math.max(0, width)
  const separatorWidth = directory !== '' && hint !== '' ? 1 : 0
  if (displayWidth(directory) + separatorWidth + displayWidth(hint) <= safeWidth) return { directory, hint }
  return { directory: truncateDirectory(directory, safeWidth), hint: '' }
}


/**
 * The running turn's first row. The interrupt affordance owns the leading slot where the
 * cwd normally sits; the ordinary command hint keeps the trailing slot while it fits.
 * `spinnerWidth` includes the spinner glyph and its one-cell gap.
 */
export function statusBarRunningLine(
  interrupt: string,
  hint: string,
  width: number,
  spinnerWidth = 2,
): StatusBarFirstLine {
  const safeWidth = Math.max(0, width)
  const reserved = Math.max(0, spinnerWidth)
  const interruptLabel = truncate(interrupt, Math.max(0, safeWidth - reserved))
  const separatorWidth = interruptLabel !== '' && hint !== '' ? 1 : 0
  const hintRoom = Math.max(0, safeWidth - reserved - displayWidth(interruptLabel) - separatorWidth)
  return {
    directory: interruptLabel,
    hint: displayWidth(hint) <= hintRoom ? hint : '',
  }
}

/** The second row's text, centred with explicit cells: `<text>` fills the row in OpenTUI, so
 * `justifyContent` cannot centre it and the padding has to be part of the string. */
export function formatStatusBarSecondLine(metrics: StatusBarMetrics, width: number): string {
  const value = statusBarLine(metrics)
  if (value === '') return ''
  const clipped = truncate(value, width)
  const used = displayWidth(clipped)
  return used >= width ? clipped : `${' '.repeat(Math.floor((width - used) / 2))}${clipped}`
}

/** One painted run of the hint: the chord, its label, or the `·` between two chords. */
export interface StatusHintSegment {
  readonly text: string
  readonly tone: 'key' | 'label' | 'separator'
}

/**
 * Split the hint line into key/label runs so the chords can carry the brighter ink.
 *
 * The host formats the hint as `key label · key label` (`shift+tab agents · ctrl+p
 * commands`) and localizes each label, so the split is done on the shape, not on the words:
 * the `·`-separated items each start with their chord. A label that is itself a chord
 * (`esc interrupt` while a turn runs) keeps the same two inks.
 */
export function statusHintSegments(hint: string): StatusHintSegment[] {
  const segments: StatusHintSegment[] = []
  for (const [index, item] of hint.split(' · ').entries()) {
    if (item === '') continue
    if (index > 0) segments.push({ text: ' · ', tone: 'separator' })
    const space = item.indexOf(' ')
    if (space <= 0) {
      segments.push({ text: item, tone: 'key' })
      continue
    }
    segments.push({ text: item.slice(0, space), tone: 'key' })
    segments.push({ text: item.slice(space), tone: 'label' })
  }
  return segments
}
