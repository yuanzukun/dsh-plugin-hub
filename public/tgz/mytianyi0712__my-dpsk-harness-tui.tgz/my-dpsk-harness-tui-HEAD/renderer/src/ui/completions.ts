/**
 * Composer completions.
 *
 * Written for this package, not ported. The command list comes from the host's
 * `command-catalog`; the renderer never runs a command, it only completes the
 * text the user types and sends it back for the host to execute.
 */

/** One slash command as the host advertises it. */
export interface CommandInfo {
  readonly name: string
  readonly description: string
  readonly argumentHint?: string
}

/**
 * The commands the composer's `/…` prefix completes.
 *
 * A prefix with a space is already an argument, so completion stops there: the
 * argument lists (`/think high`, `/resume <sessionId>`) are the host's own
 * `getArgumentCompletions` path, and the renderer sends the whole line.
 */
export function commandSuggestions(commands: readonly CommandInfo[], text: string): CommandInfo[] {
  if (!text.startsWith('/')) return []
  if (text.includes(' ')) return []
  const needle = text.slice(1).toLowerCase()
  // Ranking, not catalog order: `/mo` must offer `model` before `models`, and an exact
  // name always wins so `tab` executes the command the user just spelled out.
  const rank = (command: CommandInfo): number => {
    const name = command.name.toLowerCase()
    if (name === needle) return 0
    if (name.startsWith(needle)) return 1
    return 2
  }
  return commands
    .filter(command => command.name.toLowerCase().includes(needle))
    .map((command, index) => ({ command, index, rank: rank(command) }))
    .sort((left, right) => left.rank - right.rank || left.index - right.index)
    .map(entry => entry.command)
}

import { trailingMention, mentionSuggestions } from './paths.ts'

/** Accept the first suggestion: the composer becomes `/<name>` with a trailing space
 * when the command takes an argument, so the next keystroke starts the argument. */
export function acceptSuggestion(commands: readonly CommandInfo[], text: string): string | undefined {
  const matches = commandSuggestions(commands, text)
  const first = matches[0]
  if (first === undefined) return undefined
  return first.argumentHint === undefined ? `/${first.name}` : `/${first.name} `
}

/** Accept the first `@` path completion: the trailing mention token is replaced by
 * the match, which keeps the rest of the draft intact. */
export function acceptMention(entries: readonly string[], text: string): string | undefined {
  const token = trailingMention(text)
  if (token === undefined) return undefined
  const first = mentionSuggestions(entries, token)[0]
  if (first === undefined) return undefined
  return text.slice(0, text.length - token.length) + first
}

/** The trailing whitespace-delimited token of the draft (`''` when it ends in a space).
 * An argument accept replaces this token, so the command and its settled arguments stay. */
export function lastArgumentToken(text: string): string {
  const match = /[^\s]*$/.exec(text)
  return match === null ? '' : match[0]
}

/** The catalogs the slash arguments complete against. Every list is host state the
 * renderer already holds (`reasoning-efforts`, `permission-presets`,
 * `agent-presets`, `session-list`, `model-catalog`); the renderer never asks the host
 * for a second copy, so a completion can never disagree with the picker next to it. */
export interface CompletionCatalogs {
  readonly efforts: readonly string[]
  readonly permissions: readonly { id: string; label: string }[]
  readonly modes: readonly { id: string; label: string }[]
  readonly sessions: readonly { id: string; title: string }[]
  readonly models: readonly { provider: string; model: string; label: string }[]
}

/** One slash argument: the value that completes, and the detail line to the right. */
export interface ArgumentSuggestion {
  readonly value: string
  readonly detail: string
}

/**
 * The argument completions for `/name rest`, or an empty list when the command takes
 * no argument or has none of its kind.
 *
 * The renderer completes the arguments it can name from host state; a command whose
 * argument list lives in the host's async completion (`/skill:<name>`, free text) gets
 * nothing and the draft is submitted as typed.
 */
export function argumentSuggestions(catalogs: CompletionCatalogs, text: string): ArgumentSuggestion[] {
  if (!text.startsWith('/')) return []
  const space = text.indexOf(' ')
  if (space === -1) return []
  const name = text.slice(1, space)
  const typed = text.slice(space + 1)
  // A second token ends the completion: a value that already carries every slot is
  // not completed further.
  const tokens = typed.trim().split(/\s+/).filter(Boolean)
  const prefix = tokens.at(-1) ?? ''
  const matches = (value: string): boolean => value.toLowerCase().startsWith(prefix.toLowerCase())
  switch (name) {
    // opencode's command names lead; the older dsh spellings complete too, so an alias typed
    // from habit still offers its values.
    case 'effort':
    case 'think':
    case 'variants':
    case 'thinking':
      return catalogs.efforts.filter(matches).map(value => ({ value, detail: 'reasoning effort' }))
    case 'permission':
      return catalogs.permissions.filter(entry => matches(entry.id)).map(entry => ({ value: entry.id, detail: entry.label }))
    case 'agents':
    case 'mode':
      return catalogs.modes.filter(entry => matches(entry.id)).map(entry => ({ value: entry.id, detail: entry.label }))
    case 'sessions':
    case 'resume':
    case 'continue':
      return catalogs.sessions.filter(entry => matches(entry.id)).map(entry => ({ value: entry.id, detail: entry.title }))
    case 'models':
    case 'model': {
      if (tokens.length >= 2) return []
      return catalogs.models
        .map(entry => ({ value: `${entry.provider}/${entry.model}`, detail: entry.label }))
        .filter(entry => matches(entry.value))
    }
    default:
      return []
  }
}

/** The `@` completions the composer shows under the draft. */
export function mentionLines(entries: readonly string[], text: string): string[] {
  const token = trailingMention(text)
  if (token === undefined) return []
  return mentionSuggestions(entries, token)
}
