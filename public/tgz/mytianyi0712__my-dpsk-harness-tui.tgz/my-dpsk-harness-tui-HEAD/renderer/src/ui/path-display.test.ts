import { describe, expect, test } from 'bun:test'
import { formatDisplayPath, type PathDisplayOptions } from './path-display.ts'

const windows: PathDisplayOptions = { home: 'C:\\Users\\me', mode: 'tilde', platform: 'win32' }
const linux: PathDisplayOptions = { home: '/home/me', mode: 'tilde', platform: 'linux' }

describe('formatDisplayPath', () => {
  test('shortens the home directory and its descendants on Windows', () => {
    expect(formatDisplayPath('C:\\Users\\me', windows)).toBe('~')
    expect(formatDisplayPath('C:\\Users\\me\\Projects\\dsh', windows)).toBe('~/Projects/dsh')
    expect(formatDisplayPath('c:\\users\\ME\\Projects\\dsh', windows)).toBe('~/Projects/dsh')
  })

  test('does not confuse a sibling prefix with the home directory', () => {
    expect(formatDisplayPath('C:\\Users\\mecode\\x', windows)).toBe('C:\\Users\\mecode\\x')
    expect(formatDisplayPath('/home/mecode/x', linux)).toBe('/home/mecode/x')
  })

  test('shortens POSIX home paths and keeps non-home roots', () => {
    expect(formatDisplayPath('/home/me', linux)).toBe('~')
    expect(formatDisplayPath('/home/me/projects/dsh', linux)).toBe('~/projects/dsh')
    expect(formatDisplayPath('/srv/dsh', linux)).toBe('/srv/dsh')
  })

  test('leaves relative paths alone and returns the full path in full mode', () => {
    expect(formatDisplayPath('src/app.tsx', windows)).toBe('src/app.tsx')
    expect(formatDisplayPath('C:\\Users\\me\\Projects', { ...windows, mode: 'full' })).toBe('C:\\Users\\me\\Projects')
  })
})
