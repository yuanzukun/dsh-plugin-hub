/**
 * The queued dock: one line above the prompt naming the prompts waiting behind the turn.
 *
 * Derived from opencode v2 (`anomalyco/opencode`, 2.0.32,
 * `packages/tui/src/routes/session/composer/queued-tab.tsx`), MIT. Registered in NOTICE.md
 * under the `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications:
 * - The queue remains a one-line dock; the command palette opens an id-addressed editor
 *   where any queued message can be restored to the composer or deleted.
 */
import { SPLIT_BORDER } from './border.ts'
import type { InterjectionItem } from '../protocol/kinds.ts'
import { truncate } from './text.ts'

interface QueuedDockProps {
  readonly items: readonly InterjectionItem[]
  readonly width: number
  readonly fgBase: string
  readonly fgMuted: string
  readonly bgBase: string
  readonly border: string
}

/** The card: `┃ <n> queued · <first entry>` on the raised panel. */
export function QueuedDock(props: QueuedDockProps) {
  const first = () => props.items[0]?.text ?? ''
  const count = () => props.items.length
  const cells = () => Math.max(1, props.width - 5)
  return (
    <box
      flexShrink={0}
      width="100%"
      border={['left']}
      borderStyle="single"
      borderColor={props.border}
      customBorderChars={SPLIT_BORDER}
      backgroundColor={props.bgBase}
      paddingTop={1}
      paddingBottom={1}
      paddingLeft={2}
      paddingRight={1}
      overflow="hidden"
    >
      <text fg={props.fgBase} wrapMode="none" flexShrink={0}>
        {`${count()} queued · ${truncate(first(), cells())}`}
      </text>
    </box>
  )
}
