/**
 * The Home route.
 *
 * Ported shape from opencode v2 (`anomalyco/opencode` 2.0.28, `packages/tui/src/...`), MIT;
 * registered in NOTICE.md. SPDX-License-Identifier: MIT
 *
 * Upstream, Home is a whole route: a wordmark, a one-line note, the centered prompt, and the
 * global footer — no session tabs. opencode's tab strip is the terminal's own window chrome,
 * and its session list is a dialog (`leader l`). dsh keeps that division: this file paints
 * landing chrome only, and the shell swaps the whole route in while the transcript is empty.
 *
 * The wordmark is the upstream glyph table verbatim (opencode 2.0.28 `Pb`/`gx`), not a font:
 * four rows drawn cell by cell so `_`, `^`, `~`, and `,` can carry the half-block shading that
 * makes the letters read as extruded. A text font loses that shading and the exact column
 * count, which is what made dsh's older logo look like a different product.
 *
 * dsh's mapping of the upstream slots:
 * - the line under the wordmark is the host identity, where opencode prints its updater note;
 * - the prompt's metadata row is the agent, the route, and the reasoning effort;
 * - the hint row's left slot is the working directory, its right slot the global keys;
 * - the footer lists configured MCP server count and failed Loader plugins only.
 */

import { createTextAttributes } from '@opentui/core'
import { For, type JSX } from '#solid'
import { PROMPT_CORNER_BORDER, SHADOW_LIP_BORDER, SHADOW_LIP_EDGE } from './border.ts'
import { PromptMetadata } from './prompt-metadata.tsx'
import type { PopupAnchor } from './autocomplete.tsx'

/** The home prompt never grows past this; upstream uses the same 75-cell measure. */
export const HOME_PROMPT_MAX_WIDTH = 75

/**
 * The wordmark tables.
 *
 * opencode's `logo.ts` art, re-drawn for this bundle's name: `deep` on the left of the
 * lockup and `seek` on the right, both 19 cells wide and four rows tall, so the lockup
 * keeps upstream's size, spacing and breakpoints. `_`, `^` and `~` are shading
 * instructions, not visible glyphs (`renderLine` explains each one).
 *
 * The 22-column branch paints the same two tables stacked, and the narrowest branch paints
 * a three-row `compact` lockup.
 */
export const WORDMARK = {
  left: ['   ▄               ', '█▀▀█ █▀▀█ █▀▀█ █▀▀█', '█__█ █^^^ █^^^ █__█', '▀▀▀▀ ▀▀▀▀ ▀▀▀▀ █▀▀▀'],
  right: ['               ▄   ', '█▀▀▀ █▀▀█ █▀▀█ █ ▄▀', '▀▀▀█ █^^^ █^^^ █▀▄ ', '▀▀▀▀ ▀▀▀▀ ▀▀▀▀ ▀ ~▀'],
}
/** The three-row lockup the narrowest branch paints (`width < 22`). */
export const WORDMARK_COMPACT = ['█▀▀▄', '█__█', '▀▀▀ ']

/** Upstream's logo breakpoints: the lockup needs 44 cells side by side, 22 stacked, 12 rows. */
export const LOGO_WIDE_MIN_WIDTH = 44
export const LOGO_STACK_MIN_WIDTH = 22
export const LOGO_MIN_HEIGHT = 12

/**
 * The rows the wordmark occupies, or zero when the terminal cannot carry it.
 *
 * Upstream's `Logo` returns nothing under 12 rows; the side-by-side lockup is four rows,
 * the stacked one seven (three for `left` after its spacer row, four for `right`), and the
 * narrow one three.
 */
export function logoHeight(width: number, height: number): number {
  if (height < LOGO_MIN_HEIGHT) return 0
  if (width >= LOGO_WIDE_MIN_WIDTH) return WORDMARK.left.length
  if (width >= LOGO_STACK_MIN_WIDTH) return WORDMARK.left.length - 1 + WORDMARK.right.length
  return WORDMARK_COMPACT.length
}

/** One painted cell: the glyph, its ink, and the shading behind a space cell. */
interface LogoCell {
  readonly char: string
  readonly role: 'ink' | 'muted' | 'shade'
  readonly shaded: boolean
}

/**
 * `renderLine` from upstream's `component/logo.tsx`.
 *
 * The art characters are instructions: `_` is a space over the shadow color (the extruded
 * face), `^` a `▀` over the shadow, `~` a shadow-colored `▀`, and everything else paints in
 * the line's own color. `,` — upstream's other shading mark — never appears in these
 * tables, so it is not special-cased here.
 */
export function renderLine(line: string, role: 'ink' | 'muted'): LogoCell[] {
  return Array.from(line).map(char => {
    if (char === '_') return { char: ' ', role, shaded: true }
    if (char === '^') return { char: '▀', role, shaded: true }
    if (char === '~') return { char: '▀', role: 'shade', shaded: false }
    return { char, role, shaded: false }
  })
}

/** The two colors the wordmark paints with: face ink, and the bevel. */
export interface LogoPalette {
  readonly ink: string
  readonly muted: string
  readonly shade: string
}

function LogoLine(props: { readonly cells: readonly LogoCell[]; readonly palette: LogoPalette; readonly bold: boolean }) {
  return (
    <box flexDirection="row" flexShrink={0}>
      <For each={props.cells}>
        {cell => (
          <text
            fg={cell.role === 'ink' ? props.palette.ink : cell.role === 'muted' ? props.palette.muted : props.palette.shade}
            bg={cell.shaded ? props.palette.shade : undefined}
            attributes={props.bold ? createTextAttributes({ bold: true }) : undefined}
            content={cell.char}
            wrapMode="none"
            selectable={false}
            flexShrink={0}
          />
        )}
      </For>
    </box>
  )
}

/** Upstream's three breakpoints: side by side, stacked, then the compact lockup. */
function Wordmark(props: { readonly width: number; readonly height: number; readonly palette: LogoPalette }) {
  const rows = () => logoHeight(props.width, props.height)
  // OpenTUI's reconciler rejects a box-level `<Show>` (it inserts an empty text node when
  // false), so conditional children are JSX ternaries throughout this tree.
  return rows() === 0 ? null : (
    <box flexShrink={0} width="100%" alignItems="center" flexDirection="column">
      {props.width >= LOGO_WIDE_MIN_WIDTH ? (
        <For each={WORDMARK.left}>
          {(line, index) => (
            <box flexDirection="row" gap={1} flexShrink={0}>
              <LogoLine cells={renderLine(line, 'muted')} palette={props.palette} bold={false} />
              <LogoLine cells={renderLine(WORDMARK.right[index()] ?? '', 'ink')} palette={props.palette} bold />
            </box>
          )}
        </For>
      ) : props.width >= LOGO_STACK_MIN_WIDTH ? (
        <>
          <For each={WORDMARK.left.slice(1)}>
            {line => <LogoLine cells={renderLine(line, 'muted')} palette={props.palette} bold={false} />}
          </For>
          <For each={WORDMARK.right}>
            {line => <LogoLine cells={renderLine(line, 'ink')} palette={props.palette} bold />}
          </For>
        </>
      ) : (
        <For each={WORDMARK_COMPACT}>
          {line => <LogoLine cells={renderLine(line, 'ink')} palette={props.palette} bold />}
        </For>
      )}
    </box>
  )
}

/** The home route's props: the store's live signals, already resolved to strings. */
export interface HomeProps {
  readonly placeholder: string
  readonly agent: string
  readonly permission: string
  readonly model: string
  readonly effort: string
  readonly composer: string
  readonly composerRows: number
  readonly terminalWidth: number
  readonly attachments: readonly { readonly id: string; readonly label: string }[]
  readonly onRemoveAttachment: (id: string) => void
  readonly terminalHeight: number
  readonly placeholders: {
    readonly bgBase: string
    readonly bgPanel: string
    readonly fgBase: string
    readonly fgMuted: string
    /** The mode's ink (`hue.accent.200`), the same the composer's gutter carries. */
    readonly fgAccent: string
    /** The permission slot, matching the compact thinking header. */
    readonly fgPermission: string
    /** The reasoning-effort slot (a cyan accent distinct from the mode). */
    readonly fgEffort: string
    readonly border: string
    readonly logoShade: string
  }
  readonly registerComposer: (ref: { plainText: string; cursorOffset: number } | undefined) => void
  readonly onComposerInput: () => void
  readonly onSubmit: () => void
  readonly focused: boolean
  readonly renderPopup?: (anchor: PopupAnchor) => JSX.Element
  /**
   * The row under the prompt panel: the shell's cwd/hint line. Home passes the prompt's own
   * width, so the row hugs the input box the way it does on the session route instead of
   * sitting on the terminal's bottom edge far below it.
   */
  readonly statusLine?: (width: number) => JSX.Element
}

/**
 * The centered column, laid out as upstream's `routes/home.tsx`: a flexible spacer, a 3-row
 * fixed spacer, the logo, a 1-row spacer, the prompt (max 75 cells), and a closing spacer.
 * There is no host line under the logo: upstream reserves that row for an update notice,
 * which dsh has no source for, so the row stays empty rather than inventing an identity.
 */
export function Home(props: HomeProps) {
  // Horizontal geometry is the column Home is mounted in, not the terminal: a docked sidebar
  // narrows the column, and a popup positioned from the terminal width would sit off-centre
  // (and could overflow the column). The shell passes the content width in.
  const width = () => props.terminalWidth
  const narrow = () => width() < 44
  const promptWidth = () => Math.max(20, Math.min(HOME_PROMPT_MAX_WIDTH, width() - 2 * (narrow() ? 1 : 2)))
  const logoRows = () => logoHeight(props.terminalWidth, props.terminalHeight)
  /** Rows from the route's top edge to the prompt panel's top border: the two spacers share
   * the leftover rows, then the 3-row spacer, the logo, the 1-row spacer, and the wrapper's
   * own `paddingTop`. The popup is anchored from the panel, so this is the one figure that
   * must match the JSX exactly. */
  const contentHeight = () => logoRows() + 4 + (props.composerRows + 3) + 1 + (props.attachments.length > 0 ? 1 : 0) + 1 + (props.statusLine === undefined ? 0 : 1)
  const panelTop = () => {
    const centered = 1 + Math.max(0, Math.floor((props.terminalHeight - 2 - contentHeight()) / 2))
    // `+ 5`: the 3-row spacer, the logo, the 1-row spacer, and the prompt wrapper's
    // `paddingTop` that the panel sits inside.
    return centered + logoRows() + 5
  }
  const palette = () => ({
    ink: props.placeholders.fgBase,
    muted: props.placeholders.fgMuted,
    shade: props.placeholders.logoShade,
  })
  const metadata = () => ({
    parts: { agent: props.agent, permission: props.permission, model: props.model, effort: props.effort },
    colors: {
      // The session prompt's inks, shared so the landing page and session route never drift.
      agent: props.placeholders.fgAccent,
      permission: props.placeholders.fgPermission,
      model: props.placeholders.fgBase,
      effort: props.placeholders.fgEffort,
      muted: props.placeholders.fgMuted,
    },
  })
  return (
    <box width="100%" height="100%" flexDirection="column" backgroundColor={props.placeholders.bgBase} overflow="hidden">
      <box
        flexGrow={1}
        minHeight={0}
        width="100%"
        alignItems="center"
        paddingLeft={narrow() ? 1 : 2}
        paddingRight={narrow() ? 1 : 2}
        flexDirection="column"
        overflow="hidden"
      >
        {/* Upstream's vertical rhythm: a flexible spacer, a fixed 3-row spacer, the logo,
         * one row, the prompt, then a closing spacer. */}
        <box flexGrow={1} minHeight={0} />
        <box height={3} minHeight={0} flexShrink={1} />
        <Wordmark width={props.terminalWidth} height={props.terminalHeight} palette={palette()} />
        <box height={1} flexShrink={0} />
        <box width="100%" maxWidth={HOME_PROMPT_MAX_WIDTH} paddingTop={1} flexShrink={0} flexDirection="column">
          <box
            width="100%"
            border={['left']}
            borderStyle="single"
            borderColor={props.placeholders.border}
            customBorderChars={PROMPT_CORNER_BORDER}
            flexShrink={0}
            overflow="hidden"
          >
            {/* Upstream's composer shape: the gutter box carries no background, so the accent
             * rule sits on the page; the panel colour belongs to this inner box. */}
            <box
              width="100%"
              backgroundColor={props.placeholders.bgPanel}
              paddingLeft={narrow() ? 1 : 2}
              paddingRight={narrow() ? 1 : 2}
              paddingTop={1}
              flexShrink={0}
              overflow="hidden"
            >
              {props.attachments.length > 0 ? (
                <box flexDirection="row" gap={1} width="100%" flexShrink={0} overflow="hidden">
                  <For each={props.attachments}>
                    {attachment => <text fg={props.placeholders.fgMuted} content={`${attachment.label} ×`} onMouseUp={() => props.onRemoveAttachment(attachment.id)} />}
                  </For>
                </box>
              ) : null}
              <textarea
                ref={(r: { plainText: string; cursorOffset: number } | null) => props.registerComposer(r ?? undefined)}
                width="100%"
                minHeight={1}
                maxHeight={Math.max(6, Math.floor(props.terminalHeight / 3))}
                initialValue={props.composer}
                placeholder={props.placeholder}
                textColor={props.placeholders.fgBase}
                focusedTextColor={props.placeholders.fgBase}
                focusedBackgroundColor={props.placeholders.bgPanel}
                focused={props.focused}
                keyBindings={[
                  { name: 'return', action: 'submit' },
                  { name: 'return', ctrl: true, action: 'newline' },
                  { name: 'return', meta: true, action: 'newline' },
                  { name: 'j', ctrl: true, action: 'newline' },
                ]}
                onContentChange={props.onComposerInput}
                onSubmit={props.onSubmit}
              />
              <box width="100%" flexShrink={0} paddingTop={1}>
                <PromptMetadata parts={metadata().parts} colors={metadata().colors} width={promptWidth()} />
              </box>
            </box>
          </box>
          {/* The shadow lip, as upstream builds it: the outer box ends the `╹` gutter and
           * the inner box draws the `▀` bottom edge. */}
          <box height={1} flexShrink={0} border={['left']} borderStyle="single" borderColor={props.placeholders.border} customBorderChars={SHADOW_LIP_EDGE} overflow="hidden">
            <box height={1} border={['bottom']} borderStyle="single" borderColor={props.placeholders.bgPanel} customBorderChars={SHADOW_LIP_BORDER} />
          </box>
          {/* The cwd/hint row rides the prompt, not the terminal's bottom edge. */}
          {props.statusLine === undefined ? null : (
            <box width="100%" flexShrink={0}>
              {props.statusLine(promptWidth())}
            </box>
          )}
        </box>
        <box flexGrow={1} minHeight={0} />
      </box>
      {props.renderPopup?.({
        bottom: props.terminalHeight - panelTop(),
        left: Math.max(0, Math.floor((width() - promptWidth()) / 2)),
        width: promptWidth(),
      })}
    </box>
  )
}
