import stripAnsi from 'strip-ansi'
import { type ScrollBoxRenderable } from '@opentui/core'
import { useTerminalDimensions } from '@opentui/solid'
import { createSignal, For, onCleanup, onMount } from '#solid'
import type { ShellJobView } from '../protocol/kinds.ts'
import { DialogFooter, DialogHeader, DialogLayout, dialogColor, type DialogController, type DialogSpec, type DialogStore } from './dialog.tsx'

interface ShellJobChunk {
  readonly at: number
  readonly text: string
  readonly channel?: string
  readonly gapBefore?: true
}

interface ShellJobRead {
  readonly chunks: readonly ShellJobChunk[]
  readonly next: number
  readonly lossy: boolean
}

export function DialogShellOutput(props: {
  store: DialogStore
  spec: DialogSpec
  job: ShellJobView
  sessionId: string
  read: (sessionId: string, id: string, from: number) => Promise<{ ok: boolean; value?: unknown; error?: string }>
  currentJob: () => ShellJobView | undefined
}) {
  const dimensions = useTerminalDimensions()
  const [chunks, setChunks] = createSignal<readonly ShellJobChunk[]>([])
  const [next, setNext] = createSignal(0)
  const [lossy, setLossy] = createSignal(false)
  const [error, setError] = createSignal('')
  const [loading, setLoading] = createSignal(false)
  let scroll: ScrollBoxRenderable | undefined
  let previousController: DialogController | undefined

  const load = async (): Promise<void> => {
    if (loading()) return
    setLoading(true)
    setError('')
    try {
      const result = await props.read(props.sessionId, props.job.id, next())
      if (!result.ok) {
        setError(result.error ?? 'Shell job output is no longer available')
        return
      }
      const raw = result.value as Partial<ShellJobRead> | undefined
      if (raw === undefined || !Array.isArray(raw.chunks) || typeof raw.next !== 'number' || !Number.isSafeInteger(raw.next) || raw.next < next() || typeof raw.lossy !== 'boolean') {
        setError('Shell job returned an invalid output chunk list')
        return
      }
      const valid = raw.chunks.filter((chunk): chunk is ShellJobChunk =>
        typeof chunk === 'object' && chunk !== null && Number.isSafeInteger(chunk.at) && typeof chunk.text === 'string'
        && (chunk.channel === undefined || typeof chunk.channel === 'string')
        && (chunk.gapBefore === undefined || chunk.gapBefore === true),
      )
      setChunks(current => [...current, ...valid])
      setNext(raw.next)
      setLossy(current => current || raw.lossy === true)
      queueMicrotask(() => {
        if (scroll !== undefined) scroll.scrollTo({ x: 0, y: scroll.scrollHeight })
      })
    } catch (cause: unknown) {
      setError(cause instanceof Error ? cause.message : String(cause))
    } finally {
      setLoading(false)
    }
  }

  const status = (): string => props.currentJob()?.status ?? 'removed'
  const output = () => props.currentJob()?.output ?? props.job.output
  const controller: DialogController = {
    move: delta => scroll?.scrollBy(delta, 'step'),
    moveTo: index => scroll?.scrollTo(index),
    moveSection: () => undefined,
    moveColumn: () => undefined,
    submit: () => { void load() },
    count: () => 0,
  }

  onMount(() => {
    previousController = props.store.dialogController()
    props.store.setDialogController(controller)
    void load()
  })
  onCleanup(() => props.store.setDialogController(previousController))

  return (
    <DialogLayout
      store={props.store}
      header={<DialogHeader store={props.store} title={`${props.job.label} · ${status()}`} />}
      footer={<DialogFooter store={props.store} actions={[
        { title: loading() ? 'reading' : 'read next', key: 'enter', disabled: loading(), onTrigger: () => { void load() } },
        { title: 'close', key: 'esc', side: 'right', onTrigger: () => props.store.closeTopDialog(undefined) },
      ]} />}
    >
      <box flexDirection="column" gap={1}>
        {lossy() ? <text fg={dialogColor(props.store, 'text.feedback.warning.base', '#f9e2af')} content="Earlier output was dropped; offsets are absolute UTF-8 byte positions." /> : null}
        {error() !== '' ? <text fg={dialogColor(props.store, 'text.feedback.error.base', '#f38ba8')} content={error()} /> : null}
        {props.currentJob() === undefined ? <text fg={dialogColor(props.store, 'text.feedback.warning.base', '#f9e2af')} content="Job no longer listed; retaining the last output read." /> : null}
        <scrollbox
          height={Math.max(3, Math.floor(dimensions().height * 0.6) - 7)}
          stickyScroll
          stickyStart="bottom"
          verticalScrollbarOptions={{ trackOptions: { foregroundColor: dialogColor(props.store, 'text.muted', '#7f849c') } }}
          ref={(value: ScrollBoxRenderable | null) => { scroll = value ?? undefined }}
        >
          {chunks().length === 0 ? <text fg={dialogColor(props.store, 'text.muted', '#7f849c')} content={loading() ? 'Reading output…' : 'No retained output.'} /> : null}
          <For each={chunks()}>
            {chunk => (
              <text
                fg={chunk.channel === 'stderr' ? dialogColor(props.store, 'text.feedback.error.base', '#f38ba8') : dialogColor(props.store, 'text.base', '#cdd6f4')}
                content={`${chunk.gapBefore ? '[output gap] ' : ''}@${chunk.at}${chunk.channel === undefined ? '' : ` [${chunk.channel}]`}\n${stripAnsi(chunk.text).replace(/\r\n?/g, '\n')}`}
                wrapMode="word"
              />
            )}
          </For>
        </scrollbox>
        <text fg={dialogColor(props.store, 'text.muted', '#7f849c')} content={`next byte ${next()} · retained ${output().earliest}–${output().total}${props.job.detail === undefined ? '' : ` · ${props.job.detail}`}`} />
      </box>
    </DialogLayout>
  )
}
