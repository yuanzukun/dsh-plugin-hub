/**
 * Selection window math tests.
 *
 * The list navigation is pure arithmetic, so it is tested without a renderer:
 * every assertion below is the window a keyboard step produces, which is what
 * keeps the highlighted row on screen in a narrow dialog.
 */

import { expect, test } from 'bun:test'
import {
  moveSelection,
  moveSelectionOffset,
  reconcileSelection,
  reconcileSelectionWindow,
  revealSelectionOffset,
} from './select-controller.ts'

test('reconcileSelection clamps an index into a shrinking list', () => {
  expect(reconcileSelection(7, 5)).toBe(4)
  expect(reconcileSelection(-1, 5)).toBe(0)
  expect(reconcileSelection(3, 5)).toBe(3)
  // An empty list has no valid index; 0 is the sentinel the callers guard on.
  expect(reconcileSelection(2, 0)).toBe(0)
})

test('moveSelection wraps at both ends and clamps when asked', () => {
  const count = 5
  expect(moveSelection(0, { count, delta: -1, policy: 'wrap' })).toBe(4)
  expect(moveSelection(4, { count, delta: 1, policy: 'wrap' })).toBe(0)
  expect(moveSelection(2, { count, delta: 2, policy: 'wrap' })).toBe(4)
  expect(moveSelection(0, { count, delta: -1, policy: 'clamp' })).toBe(0)
  expect(moveSelection(4, { count, delta: 1, policy: 'clamp' })).toBe(4)
  // A page step (10 rows) past either end wraps in one step.
  expect(moveSelection(3, { count, delta: 10, policy: 'wrap' })).toBe(0)
  expect(moveSelection(1, { count, delta: -10, policy: 'wrap' })).toBe(4)
  expect(moveSelection(1, { count: 0, delta: 1, policy: 'wrap' })).toBe(0)
})

test('revealSelectionOffset pulls the window onto the selected row', () => {
  const view = { count: 20, limit: 5 }
  // Below the window: the window starts at the selection.
  expect(revealSelectionOffset(10, { ...view, selected: 9 })).toBe(9)
  // Above the window: the window ends at the selection.
  expect(revealSelectionOffset(10, { ...view, selected: 17 })).toBe(13)
  // Inside the window: the offset is kept, so scrolling does not jump.
  expect(revealSelectionOffset(10, { ...view, selected: 12 })).toBe(10)
  // The window never runs past the last row.
  expect(revealSelectionOffset(0, { ...view, selected: 19 })).toBe(15)
})

test('reconcileSelectionWindow keeps an index inside the visible window', () => {
  const view = { count: 20, limit: 5, offset: 10 }
  expect(reconcileSelectionWindow(12, view)).toBe(12)
  expect(reconcileSelectionWindow(17, view)).toBe(14)
  expect(reconcileSelectionWindow(3, view)).toBe(10)
  expect(reconcileSelectionWindow(4, { count: 0, limit: 5, offset: 0 })).toBe(0)
})

test('moveSelectionOffset scrolls only when the row is near an edge', () => {
  const view = { count: 20, limit: 5 }
  // The margin is 2 rows for a 5-row window, so a row 2 cells below the top
  // pulls the window up to it and a row 2 cells above the bottom pulls it down.
  expect(moveSelectionOffset(10, { ...view, selected: 11, direction: -1 })).toBe(9)
  expect(moveSelectionOffset(10, { ...view, selected: 14, direction: 1 })).toBe(12)
  // A row comfortably inside the window leaves the offset alone.
  expect(moveSelectionOffset(10, { ...view, selected: 12, direction: 1 })).toBe(10)
  expect(moveSelectionOffset(10, { ...view, selected: 12, direction: -1 })).toBe(10)
  // Edges clamp at 0 and at count - limit.
  expect(moveSelectionOffset(0, { ...view, selected: 0, direction: -1 })).toBe(0)
  expect(moveSelectionOffset(15, { ...view, selected: 19, direction: 1 })).toBe(15)
})
