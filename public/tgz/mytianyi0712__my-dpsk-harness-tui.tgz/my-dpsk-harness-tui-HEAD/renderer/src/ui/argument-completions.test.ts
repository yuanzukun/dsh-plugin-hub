/**
 * Slash-argument completion tests.
 *
 * The renderer completes a slash command's argument from the catalogs the host already
 * pushed (`reasoning-efforts`, `permission-presets`, `agent-presets`, `session-list`,
 * `model-catalog`), so these tests feed plain catalog objects and assert the rows.
 */

import { expect, test } from 'bun:test'
import { argumentSuggestions, commandSuggestions, lastArgumentToken, type CompletionCatalogs } from './completions.ts'

const catalogs: CompletionCatalogs = {
  efforts: ['off', 'low', 'medium', 'high'],
  permissions: [{ id: 'read-only', label: 'read only' }, { id: 'workspace-write', label: 'workspace write' }],
  modes: [{ id: 'standard', label: 'standard' }, { id: 'code', label: 'code' }],
  sessions: [{ id: 'ses_1', title: 'first prompt' }],
  models: [{ provider: 'cliproxy', model: 'mimo', label: 'MiMo' }],
}

test('a command with no argument completes nothing', () => {
  expect(argumentSuggestions(catalogs, '/help')).toEqual([])
  expect(argumentSuggestions(catalogs, '/help now')).toEqual([])
  // A non-slash draft is never an argument.
  expect(argumentSuggestions(catalogs, 'think hi')).toEqual([])
})

test('/think completes the reasoning efforts the host listed', () => {
  expect(argumentSuggestions(catalogs, '/think ').map(row => row.value)).toEqual(['off', 'low', 'medium', 'high'])
  expect(argumentSuggestions(catalogs, '/think hi')).toEqual([{ value: 'high', detail: 'reasoning effort' }])
})

test('/permission and /mode complete their preset ids with labels', () => {
  expect(argumentSuggestions(catalogs, '/permission wo')).toEqual([{ value: 'workspace-write', detail: 'workspace write' }])
  expect(argumentSuggestions(catalogs, '/mode co')).toEqual([{ value: 'code', detail: 'code' }])
})

test('/resume completes session ids and /model completes its provider slot', () => {
  expect(argumentSuggestions(catalogs, '/resume ses')).toEqual([{ value: 'ses_1', detail: 'first prompt' }])
  expect(argumentSuggestions(catalogs, '/model cliproxy/')).toEqual([{ value: 'cliproxy/mimo', detail: 'MiMo' }])
})

test('a suggestion never invents a value the host did not list', () => {
  expect(argumentSuggestions(catalogs, '/permission zzz')).toEqual([])
  expect(argumentSuggestions({ ...catalogs, efforts: [] }, '/think ')).toEqual([])
})

test('lastArgumentToken is the token an accept replaces', () => {
  expect(lastArgumentToken('/think hi')).toBe('hi')
  expect(lastArgumentToken('/think ')).toBe('')
  // The whole command is the token while no argument has been typed, so the argument
  // accept path never runs on a bare command (commandSuggestions owns that case).
  expect(commandSuggestions([{ name: 'think', description: 'effort' }], '/thi').map(command => command.name)).toEqual(['think'])
})
