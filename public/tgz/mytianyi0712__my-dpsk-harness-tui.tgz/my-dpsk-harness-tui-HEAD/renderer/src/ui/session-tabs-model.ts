/** A synthetic tab for the Home draft. It never reaches the host or tabs.json. */
export const DRAFT_TAB_ID = '__dsh_new_session__'

const MAX_CLOSED_TABS = 25

export interface ClosedTab {
  readonly id: string
  readonly index: number
  readonly title?: string
}

export interface TabsState {
  readonly open: readonly string[]
  readonly closed: readonly ClosedTab[]
  /** Last known title per real session; lets a tab paint before the catalog arrives. */
  readonly titles: Readonly<Record<string, string>>
}

export function emptyTabsState(): TabsState {
  return { open: [], closed: [], titles: {} }
}

function withTitle(titles: Readonly<Record<string, string>>, id: string, title: string | undefined): Record<string, string> {
  if (title === undefined || title === '') return { ...titles }
  if (titles[id] === title) return { ...titles }
  return { ...titles, [id]: title }
}

/** Add a real session or the single Home draft, preserving the caller's order. */
export function openTab(state: TabsState, id: string, title?: string): TabsState {
  if (id === '') return state
  const open = state.open.includes(id) ? [...state.open] : [...state.open, id]
  return { open, closed: [...state.closed], titles: withTitle(state.titles, id, title) }
}

/** Close one tab; `fallbackId` is the right neighbour, then the left, then Home. */
export function closeTab(state: TabsState, id: string): { state: TabsState; fallbackId?: string } {
  const index = state.open.indexOf(id)
  if (index === -1) return { state }
  const open = state.open.filter(candidate => candidate !== id)
  const closed = id === DRAFT_TAB_ID
    ? [...state.closed]
    : [...state.closed, {
        id,
        index,
        ...(state.titles[id] === undefined ? {} : { title: state.titles[id] }),
      }].slice(-MAX_CLOSED_TABS)
  const fallbackId = state.open[index + 1] ?? state.open[index - 1]
  return {
    state: { open, closed, titles: { ...state.titles } },
    ...(fallbackId === undefined || fallbackId === DRAFT_TAB_ID ? {} : { fallbackId }),
  }
}

/** Close every tab except one; the kept tab may be either a session or the draft. */
export function closeOtherTabs(state: TabsState, id: string): TabsState {
  const index = state.open.indexOf(id)
  if (index === -1) return state
  const closed = [...state.closed]
  for (const [candidateIndex, candidate] of state.open.entries()) {
    if (candidate === id || candidate === DRAFT_TAB_ID) continue
    closed.push({
      id: candidate,
      index: candidateIndex,
      ...(state.titles[candidate] === undefined ? {} : { title: state.titles[candidate] }),
    })
  }
  return { open: [id], closed: closed.slice(-MAX_CLOSED_TABS), titles: { ...state.titles } }
}

function reorder(state: TabsState, id: string, to: number): TabsState {
  const from = state.open.indexOf(id)
  if (from === -1) return state
  const bounded = Math.min(state.open.length - 1, Math.max(0, to))
  if (bounded === from) return state
  const open = [...state.open]
  open.splice(from, 1)
  open.splice(bounded, 0, id)
  return { open, closed: [...state.closed], titles: { ...state.titles } }
}

export function moveTab(state: TabsState, id: string, delta: number): TabsState {
  const from = state.open.indexOf(id)
  return from === -1 ? state : reorder(state, id, from + delta)
}

export function moveTabTo(state: TabsState, id: string, index: number): TabsState {
  return reorder(state, id, index)
}

/** Reopen the most recent closed tab that is not already open, at its original index. */
export function reopenLastTab(state: TabsState): { state: TabsState; reopenedId?: string } {
  const closed = [...state.closed]
  while (closed.length > 0) {
    const entry = closed.pop()!
    if (state.open.includes(entry.id) || entry.id === DRAFT_TAB_ID) continue
    const open = [...state.open]
    open.splice(Math.min(entry.index, open.length), 0, entry.id)
    return {
      state: { open, closed, titles: withTitle(state.titles, entry.id, entry.title) },
      reopenedId: entry.id,
    }
  }
  return { state: { ...state, closed } }
}

/** Put a real id where the draft sits; no draft appends the real tab. */
export function promoteDraft(state: TabsState, id: string, title?: string): TabsState {
  if (id === '' || id === DRAFT_TAB_ID) return state
  const draftIndex = state.open.indexOf(DRAFT_TAB_ID)
  const withoutDraft = state.open.filter(candidate => candidate !== DRAFT_TAB_ID)
  let open: string[]
  if (withoutDraft.includes(id)) {
    open = withoutDraft
  } else if (draftIndex === -1) {
    open = [...withoutDraft, id]
  } else {
    open = [...withoutDraft]
    open.splice(Math.min(draftIndex, open.length), 0, id)
  }
  return { open, closed: [...state.closed], titles: withTitle(state.titles, id, title) }
}

/** Remove tabs (and reopen entries) the host no longer knows; keep the active id and draft. */
export function pruneTabs(state: TabsState, known: ReadonlySet<string>, keepId = ''): TabsState {
  const open = state.open.filter(id => id === DRAFT_TAB_ID || id === keepId || known.has(id))
  const closed = state.closed.filter(entry => known.has(entry.id))
  if (open.length === state.open.length && closed.length === state.closed.length) return state
  return { open, closed, titles: { ...state.titles } }
}

/** Cycle in visual order. A current id outside the strip enters at its first/last tab. */
export function cycleTabId(state: TabsState, current: string, direction: 1 | -1): string | undefined {
  if (state.open.length === 0) return undefined
  const index = state.open.indexOf(current)
  if (index === -1) return direction === 1 ? state.open[0] : state.open.at(-1)
  return state.open[(index + direction + state.open.length) % state.open.length]
}

/** Decode both the 0.5.0 legacy `{open,closed}` shape and the v2 title-aware shape. */
export function decodeTabs(value: unknown): TabsState {
  if (typeof value !== 'object' || value === null) return emptyTabsState()
  const record = value as { version?: unknown; open?: unknown; tabs?: unknown; closed?: unknown }
  const rawOpen = record.version === 2 && Array.isArray(record.tabs) ? record.tabs : record.open
  const open: string[] = []
  const titles: Record<string, string> = {}
  if (Array.isArray(rawOpen)) {
    for (const entry of rawOpen) {
      if (typeof entry === 'string') {
        if (entry !== DRAFT_TAB_ID && !open.includes(entry)) open.push(entry)
        continue
      }
      if (typeof entry !== 'object' || entry === null) continue
      const tab = entry as { id?: unknown; title?: unknown }
      if (typeof tab.id !== 'string' || tab.id === '' || tab.id === DRAFT_TAB_ID || open.includes(tab.id)) continue
      open.push(tab.id)
      if (typeof tab.title === 'string' && tab.title !== '') titles[tab.id] = tab.title
    }
  }
  const closed: ClosedTab[] = []
  if (Array.isArray(record.closed)) {
    for (const entry of record.closed) {
      if (typeof entry !== 'object' || entry === null) continue
      const tab = entry as { id?: unknown; index?: unknown; title?: unknown }
      if (typeof tab.id !== 'string' || tab.id === '' || tab.id === DRAFT_TAB_ID) continue
      if (typeof tab.index !== 'number' || !Number.isSafeInteger(tab.index) || tab.index < 0) continue
      closed.push({
        id: tab.id,
        index: tab.index,
        ...(typeof tab.title === 'string' && tab.title !== '' ? { title: tab.title } : {}),
      })
    }
  }
  return { open, closed: closed.slice(-MAX_CLOSED_TABS), titles }
}

/** The persisted v2 shape never contains the ephemeral Home draft. */
export function encodeTabs(state: TabsState): {
  version: 2
  tabs: Array<{ id: string; title: string }>
  closed: ClosedTab[]
} {
  return {
    version: 2,
    tabs: state.open.filter(id => id !== DRAFT_TAB_ID).map(id => ({ id, title: state.titles[id] ?? '' })),
    closed: state.closed.filter(entry => entry.id !== DRAFT_TAB_ID).map(entry => ({ ...entry })),
  }
}
