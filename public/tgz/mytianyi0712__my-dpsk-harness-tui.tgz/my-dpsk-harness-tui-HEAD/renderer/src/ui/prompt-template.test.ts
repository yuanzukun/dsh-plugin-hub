/**
 * Prompt footer template tests.
 *
 * The two templates come from the host's settings section and are the only thing the
 * footer renders, so these tests pin the parser, the slot table, and the drop-whole rule.
 */

import { expect, test } from 'bun:test'
import { parsePromptTemplate, promptTemplateResolver, promptTemplateSegments, renderPromptTemplate, type PromptTemplateState } from './prompt-template.ts'

const state: PromptTemplateState = {
  workspace: 'D:/Projects/dsh',
  branch: 'main',
  provider: 'cliproxy',
  model: 'mimo-v2.6-pro',
  effort: 'high',
  permission: 'auto',
  mode: 'standard',
  context: '12.3k (9%)',
  queued: 2,
  subagents: 1,
  running: false,
  runningLabel: 'esc interrupt',
}

test('the parser keeps literal text, drops empty slots, and leaves an unterminated ${ alone', () => {
  expect(parsePromptTemplate('${cwd} · ${model}')).toEqual([
    { type: 'value', name: 'cwd' },
    { type: 'text', text: ' · ' },
    { type: 'value', name: 'model' },
  ])
  expect(parsePromptTemplate('a${b')).toEqual([{ type: 'text', text: 'a' }, { type: 'text', text: '${b' }])
  expect(parsePromptTemplate('${}x')).toEqual([{ type: 'text', text: '${}' }, { type: 'text', text: 'x' }])
  expect(renderPromptTemplate('a${unknown}b', () => undefined)).toBe('ab')
})

test('the shipped left template renders the workspace and its branch', () => {
  const resolve = promptTemplateResolver(state)
  expect(renderPromptTemplate('${location}', resolve)).toBe('dsh:main')
  expect(renderPromptTemplate('${cwd}', resolve)).toBe('D:/Projects/dsh')
  // No repository branch: the location degrades to the workspace path, never `repo:`.
  expect(renderPromptTemplate('${location}', promptTemplateResolver({ ...state, branch: undefined }))).toBe('D:/Projects/dsh')
})

test('the shipped right template renders the route, counts, and context', () => {
  const resolve = promptTemplateResolver(state)
  const right = renderPromptTemplate('${model} · ${effort} · ${permission} · ${mode} · ${queued} · ${context} · ${subagents}', resolve)
  expect(right).toBe('cliproxy/mimo-v2.6-pro · high · auto · standard · 2 queued · 12.3k (9%) · 1 sub')
  // An empty queue and no subagents leave no dangling segment.
  expect(renderPromptTemplate('${model} · ${queued}${subagents}', promptTemplateResolver({ ...state, queued: 0, subagents: 0 })))
    .toBe('cliproxy/mimo-v2.6-pro')
})

test('a missing slot drops its literal prefix instead of leaving a separator', () => {
  const resolve = promptTemplateResolver({ ...state, effort: '' })
  expect(promptTemplateSegments('${model} · ${effort}', resolve).map(segment => segment.text)).toEqual([
    'cliproxy/mimo-v2.6-pro',
  ])
  // Only separator literals are dropped with a missing slot; `a` is real text and stays.
  expect(promptTemplateSegments('a${unknown}b', () => undefined)).toEqual([{ text: 'ab' }])
})

test('the running slot is the localized interrupt hint and only while a turn is live', () => {
  const idle = promptTemplateResolver(state)
  expect(idle('indicator')).toBeUndefined()
  const running = promptTemplateResolver({ ...state, running: true })
  expect(running('indicator')).toBe('esc interrupt')
})

test('segments carry the theme token that colors each slot', () => {
  const segments = promptTemplateSegments('${model} · ${effort}', promptTemplateResolver(state))
  expect(segments.map(segment => segment.color)).toEqual(['text.base', 'text.feedback.warning.base'])
})

test('a segment carries its slot so the footer can drop slots by name', () => {
  const segments = promptTemplateSegments('${cwd} · ${model}', promptTemplateResolver(state))
  // The literal between two slots binds to the segment that follows it, so a dropped slot
  // never leaves its separator behind — and the surviving segment names the slot it is.
  expect(segments.map(segment => `${segment.slot ?? '-'}:${segment.text}`)).toEqual([
    'cwd:D:/Projects/dsh',
    'model: · cliproxy/mimo-v2.6-pro',
  ])
  // Dropping the first slot drops the literal that introduced the second one.
  expect(promptTemplateSegments('${effort} · ${model}', promptTemplateResolver({ ...state, effort: '' })).map(segment => segment.text))
    .toEqual([' · cliproxy/mimo-v2.6-pro'])
})
