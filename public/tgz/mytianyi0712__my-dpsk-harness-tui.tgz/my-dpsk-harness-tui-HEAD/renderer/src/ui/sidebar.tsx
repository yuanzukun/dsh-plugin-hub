/**
 * The right sidebar: six fixed sections — context, WeChat, MCP, TODO, subagents, background — plus the
 * session title above and the route footer below. Sections never reorder and never disappear:
 * an empty section paints its empty-state line, so the pane always has the same shape.
 * SPDX-License-Identifier: MIT
 */

import { createTextAttributes } from '@opentui/core'
import type { ScrollAcceleration } from '@opentui/core'
import { For } from '#solid'
import { HOME_VERSION_WIDTH, SIDEBAR_WIDTH } from './layout.ts'
import { formatTokens, truncate, displayWidth } from './text.ts'
import type { McpLifecycleStatus, McpServerItem, TodoItem, UsagePayload, WechatStatusPayload } from '../protocol/kinds.ts'
/** One child session row in the Subagents section. */
export interface SidebarSubagentRow {
  readonly id: string
  readonly title: string
  readonly status: 'idle' | 'running'
  readonly canInteract: boolean
}

/** One running shell job row in the Background tasks section. */
export interface SidebarBackgroundRow {
  readonly owner: string
  readonly ownerTitle: string
  readonly id: string
  readonly label: string
  readonly status: string
}



export interface SidebarSectionLabels {
  readonly context: string
  readonly wechat: string
  readonly mcp: string
  readonly todo: string
  readonly subagents: string
  readonly backgroundTasks: string
  readonly emptySubagents: string
  readonly emptyBackgroundTasks: string
  readonly spent: string
  readonly emptyMcp: string
  readonly emptyTodos: string
  readonly more: string
  readonly unavailable: string
  readonly unknown: string
  readonly lockHeld: string
  readonly lockPid: string
  /** The pane title an untitled session wears. */
  readonly untitled: string
  readonly lockUnknown: string
  readonly connected: string
  readonly disconnected: string
}

interface SidebarProps {
  readonly usage: UsagePayload | undefined
  readonly mcpServers: readonly McpServerItem[]
  readonly gitBranch: string | undefined
  readonly workspace: string
  readonly provider: string
  readonly width: number
  readonly model: string
  readonly height: number
  readonly fgTitle: string
  readonly fgBase: string
  readonly fgMuted: string
  readonly fgContext: string
  readonly fgSuccess: string
  readonly fgError: string
  readonly bgBase: string
  readonly labels: SidebarSectionLabels
  /** The bridge's structured state; undefined means it never reported (bridge absent). */
  readonly wechat: WechatStatusPayload | undefined
  /** The pending login QR block: borderless monospace rows, kept in the pane. */
  readonly wechatQr: string
  readonly todos: readonly TodoItem[]
  readonly subagents: readonly SidebarSubagentRow[]
  readonly backgroundTasks: readonly SidebarBackgroundRow[]
  readonly onOpenSubagent: (id: string) => void
  readonly onOpenBackground: (owner: string, id: string) => void
  /** The full activity count, even while the section is folded. */
  readonly collapsed: { readonly mcp: boolean; readonly todo: boolean; readonly subagents: boolean; readonly background: boolean }
  readonly onToggleSection: (section: 'mcp' | 'todo' | 'subagents' | 'background') => void
  /** The harness build stamp, upstream's version hint. */
  readonly version: string
  /** The session title, upstream's `title_shimmer` line at the top of the pane. */
  readonly title: string
  /** The live terminal width: the footer's version line has a breakpoint on it. */
  readonly terminalWidth: number
  /** The transcript's scroll acceleration (`getScrollAcceleration`), shared with the pane. */
  readonly scrollAcceleration: ScrollAcceleration
}

/** `¥` for CNY, `$` for USD, and the code itself for anything else. */
export function currencySymbol(currency: string | undefined): string {
  switch (currency) {
    case undefined:
    case 'CNY':
    case 'RMB':
      return '¥'
    case 'USD':
      return '$'
    case 'EUR':
      return '€'
    default:
      return `${currency} `
  }
}

/**
 * The amount line. `undefined` stays `—` (a missing price is not a zero bill), and a real
 * charge below one cent reads `<¥0.01` instead of rounding to `¥0.00`.
 */
export function formatCost(cost: number | undefined, currency: string | undefined): string {
  if (cost === undefined || !Number.isFinite(cost)) return '—'
  if (cost > 0 && cost < 0.01) return `<${currencySymbol(currency)}0.01`
  return `${currencySymbol(currency)}${cost.toFixed(2)}`
}

/** The amount without the symbol, because the context block owns the fixed `$` label. */
export function formatUsdAmount(cost: number | undefined): string {
  if (cost === undefined || !Number.isFinite(cost)) return '—'
  if (cost > 0 && cost < 0.01) return '<0.01'
  return cost.toFixed(2)
}

/**
 * The token total and the cache share. The share is reported once at least one folded sample
 * explicitly carried cache reads; an adapter that never reports them reads `cache —` rather
 * than a fabricated 0%.
 */
export function formatCacheShare(usage: UsagePayload | undefined): string {
  const parts = cacheShareParts(usage)
  return `${parts.tokens}${parts.share}`
}

/** The same line split for the pane: the token total in base ink, the share in muted. */
export function cacheShareParts(usage: UsagePayload | undefined): { tokens: string; share: string } {
  if (usage === undefined) return { tokens: '—', share: '' }
  const total = usage.inputTokens + usage.outputTokens + (usage.cacheReadTokens ?? 0) + (usage.cacheWriteTokens ?? 0)
  const cacheTotal = (usage.cacheReadTokens ?? 0) + (usage.cacheWriteTokens ?? 0)
  const denominator = usage.inputTokens + cacheTotal
  const tokens = formatTokens(total)
  // At least one explicit read sample makes the cumulative ratio meaningful. Optional
  // fields omitted by other samples count as zero reads (the provider is known to report
  // this bucket); an adapter that never reports reads keeps the dash. Older payloads fall
  // back to the two completeness flags.
  const readReported = usage.cacheReadObserved !== undefined
    ? usage.cacheReadObserved
    : usage.cacheReadComplete ?? usage.cacheBucketsComplete === true
  if (readReported !== true || denominator === 0) return { tokens, share: ' (cache —)' }
  return { tokens, share: ` (${Math.round(((usage.cacheReadTokens ?? 0) / denominator) * 100)}% cache)` }
}

/** The lifecycle word for one MCP client; an unknown phase is never dressed up as running. */
export function mcpStatusLabel(status: McpLifecycleStatus | null | undefined): string {
  switch (status) {
    case 'active':
      return 'running'
    case 'loading':
      return 'loading'
    case 'pending':
      return 'pending'
    case 'unloading':
      return 'unloading'
    case 'failed':
      return 'failed'
    default:
      return '—'
  }
}

/** The todo marker: pending, in progress, done, or the raw word for an unknown status. */
export function todoSymbol(status: string): string {
  switch (status) {
    case 'pending':
      return '○'
    case 'in_progress':
      return '◐'
    case 'completed':
      return '●'
    default:
      return '○'
  }
}

/** How many todo rows a section paints before it summarises the rest. */
const TODO_VISIBLE = 12

/** One coloured run of a single-line row. */
export interface SidebarSegment {
  readonly text: string
  readonly fg: string
  readonly dim?: boolean
}

/**
 * Clip a run list to `width` cells, dropping whole runs that no longer fit and cutting the
 * last visible one. Upstream's pane paints labels muted and their values in the accent ink;
 * doing that needs spans inside one `<text>`, so the fit has to be computed per run.
 */
export function fitSegments(segments: readonly SidebarSegment[], width: number): readonly SidebarSegment[] {
  const out: SidebarSegment[] = []
  let used = 0
  for (const segment of segments) {
    if (segment.text === '') continue
    const room = width - used
    if (room <= 0) break
    const text = truncate(segment.text, room)
    out.push(text === segment.text ? segment : { ...segment, text })
    used += displayWidth(text)
    if (text !== segment.text) break
  }
  return out
}

/** The docked sidebar: the title, the five-section body, and the footer card. */
export function Sidebar(props: SidebarProps) {
  const branchText = () => `${props.workspace.split(/[\\/]/).pop()}${props.gitBranch === undefined ? '' : `:${props.gitBranch}`}`
  const line = () => Math.max(1, props.width - 3)
  /** A single-line row made of coloured runs, clipped to the pane. */
  const runs = (segments: readonly SidebarSegment[]) => (
    <box flexDirection="row" width="100%" height={1} flexShrink={0} overflow="hidden">
      <text wrapMode="none" flexShrink={0}>
        <For each={fitSegments(segments, line())}>{segment => (
          <span style={{ fg: segment.fg, dim: segment.dim === true }}>{segment.text}</span>
        )}</For>
      </text>
    </box>
  )
  /** A section header. Collapsible ones carry the caret and the click target. */
  const header = (label: string, section?: 'mcp' | 'todo' | 'subagents' | 'background') => {
    const folded = section === undefined ? false : props.collapsed[section]
    const text = section === undefined ? label : `${folded ? '▸' : '▾'} ${label}`
    return (
      <box
        flexDirection="row"
        width="100%"
        height={1}
        flexShrink={0}
        onMouseDown={section === undefined ? undefined : () => props.onToggleSection(section)}
      >
        <text fg={props.fgMuted} content={truncate(text, line())} wrapMode="none" flexShrink={0} />
      </box>
    )
  }
  const body = (content: string, fg: string = props.fgBase, dim = false) => (
    <text
      fg={fg}
      attributes={dim ? createTextAttributes({ dim: true }) : undefined}
      content={truncate(content, line())}
      wrapMode="none"
      flexShrink={0}
    />
  )
  const contextFirst = () => props.usage?.contextTokens === undefined ? '—' : formatTokens(props.usage.contextTokens)
  const wechatConnected = () => {
    const wechat = props.wechat
    if (wechat === undefined || !wechat.available) return props.labels.unavailable
    if (!wechat.connected) return props.labels.disconnected
    return `${props.labels.connected} (${wechat.accounts.connected}/${wechat.accounts.total})`
  }
  const wechatLock = () => {
    const lock = props.wechat?.lock
    if (lock === undefined) return props.labels.lockUnknown
    if (lock.held) return props.labels.lockHeld
    return lock.pid === undefined ? props.labels.lockUnknown : props.labels.lockPid.replace('{pid}', String(lock.pid))
  }
  const todoDone = () => props.todos.filter(item => item.status === 'completed').length
  const todoRows = () => props.todos.slice(0, TODO_VISIBLE)
  return (
    <box
      width={props.width}
      height="100%"
      flexDirection="column"
      flexShrink={0}
      paddingLeft={2}
      paddingRight={2}
      paddingTop={1}
      paddingBottom={1}
      backgroundColor={props.bgBase}
      gap={1}
      overflow="hidden"
    >
      {/* The session title, upstream's `title_shimmer` line. dsh has no rename-in-place or
       * marquee, so it is one bold line, cut to the pane. */}
      <box flexDirection="row" width="100%" height={1} flexShrink={0} paddingRight={2} paddingBottom={1} overflow="hidden">
        <text fg={props.fgTitle} attributes={createTextAttributes({ bold: true })} content={truncate(props.title === '' ? props.labels.untitled : props.title, props.width - 4)} wrapMode="none" flexShrink={0} />
      </box>
      {/* The sections scroll on their own: a long list must not push the footer off the pane. */}
      <scrollbox
        flexGrow={1}
        minHeight={0}
        width="100%"
        horizontalScrollbarOptions={{ visible: false }}
        verticalScrollbarOptions={{
          position: 'absolute',
          right: 0,
          top: 0,
          width: 1,
          height: '100%',
          trackOptions: {
            backgroundColor: props.bgBase,
            foregroundColor: props.fgMuted,
          },
        }}
        scrollAcceleration={props.scrollAcceleration}
      >
        <box flexDirection="column" width="100%" flexShrink={0} gap={1} paddingRight={1} overflow="hidden">
          {/* 1. Context: this turn's occupancy, the token total with its cache share, the bill. */}
          <box flexDirection="column" width="100%" flexShrink={0} gap={0}>
            {header(props.labels.context)}
            {runs([
              { text: 'CTX ', fg: props.fgMuted },
              { text: contextFirst(), fg: props.fgContext },
            ])}
            {runs([
              { text: 'SUM ', fg: props.fgMuted },
              { text: cacheShareParts(props.usage).tokens, fg: props.fgBase },
              { text: cacheShareParts(props.usage).share, fg: props.fgMuted },
            ])}
            {runs([
              { text: '$ ', fg: props.fgMuted },
              { text: props.usage?.costUnavailable === true ? '未配置模型价格' : formatUsdAmount(props.usage?.cost), fg: props.fgSuccess },
            ])}
          </box>
          {/* 2. WeChat: the connection and the receiver lock on their own rows, then the QR. */}
          <box flexDirection="column" width="100%" flexShrink={0} gap={0}>
            {header(props.labels.wechat)}
            {body(wechatConnected(), props.fgContext)}
            {body(wechatLock(), props.fgMuted)}
            {props.wechatQr === '' ? null : body(props.wechatQr)}
          </box>
          {/* 3. MCP: one row per configured client with its real loader phase. */}
          <box flexDirection="column" width="100%" flexShrink={0} gap={0}>
            {header(props.mcpServers.length === 0 ? props.labels.mcp : `${props.labels.mcp} (${props.mcpServers.length})`, 'mcp')}
            {props.collapsed.mcp ? null : props.mcpServers.length === 0
              ? body(props.labels.emptyMcp, props.fgMuted)
              : <For each={props.mcpServers}>{server => runs([
                { text: server.name, fg: server.status === 'failed' ? props.fgError : props.fgBase },
                { text: '  ', fg: props.fgMuted },
                { text: mcpStatusLabel(server.status), fg: server.status === 'failed' ? props.fgError : props.fgMuted },
              ])}</For>}
          </box>
          {/* 4. TODO: the harness's own todo table, written as a whole-table snapshot. */}
          <box flexDirection="column" width="100%" flexShrink={0} gap={0}>
            {header(props.todos.length === 0 ? props.labels.todo : `${props.labels.todo} (${todoDone()}/${props.todos.length})`, 'todo')}
            {props.collapsed.todo ? null : props.todos.length === 0
              ? body(props.labels.emptyTodos, props.fgMuted)
              : <For each={todoRows()}>{item => runs([
                { text: `${todoSymbol(item.status)} `, fg: item.status === 'completed' ? props.fgMuted : item.status === 'in_progress' ? props.fgContext : props.fgBase },
                { text: item.content, fg: item.status === 'completed' ? props.fgMuted : props.fgBase, dim: item.status === 'completed' },
              ])}</For>}
            {props.collapsed.todo || props.todos.length <= TODO_VISIBLE ? null : body(props.labels.more.replace('{count}', String(props.todos.length - TODO_VISIBLE)), props.fgMuted)}
          </box>
          {/* 5. Subagents: child sessions spawned by the one on screen. Folded by default. */}
          <box flexDirection='column' width='100%' flexShrink={0} gap={0}>
            {header(props.subagents.length === 0 ? props.labels.subagents : props.labels.subagents + ' (' + props.subagents.length + ')', 'subagents')}
            {props.collapsed.subagents ? null : props.subagents.length === 0
              ? body(props.labels.emptySubagents, props.fgMuted)
              : <For each={props.subagents}>{row => (
                <box flexDirection='row' width='100%' height={1} flexShrink={0} overflow='hidden' onMouseDown={() => props.onOpenSubagent(row.id)}>
                  <text fg={row.canInteract ? props.fgContext : props.fgBase} content={truncate((row.canInteract ? '✎ ' : '↳ ') + row.title, Math.max(1, line() - 9))} wrapMode='none' flexShrink={0} />
                  <box flexGrow={1} />
                  <text fg={row.status === 'running' ? props.fgContext : props.fgMuted} content={row.status} wrapMode='none' flexShrink={0} />
                </box>
              )}</For>}
          </box>
          {/* 6. Background tasks: running shell jobs across every live session. */}
          <box flexDirection='column' width='100%' flexShrink={0} gap={0}>
            {header(props.backgroundTasks.length === 0 ? props.labels.backgroundTasks : props.labels.backgroundTasks + ' (' + props.backgroundTasks.length + ')', 'background')}
            {props.collapsed.background ? null : props.backgroundTasks.length === 0
              ? body(props.labels.emptyBackgroundTasks, props.fgMuted)
              : <For each={props.backgroundTasks}>{row => (
                <box flexDirection='row' width='100%' height={1} flexShrink={0} overflow='hidden' onMouseDown={() => props.onOpenBackground(row.owner, row.id)}>
                  <text fg={props.fgBase} content={truncate('⏱ ' + row.label + ' · ' + row.ownerTitle, Math.max(1, line() - 9))} wrapMode='none' flexShrink={0} />
                  <box flexGrow={1} />
                  <text fg={props.fgMuted} content={row.status} wrapMode='none' flexShrink={0} />
                </box>
              )}</For>}
          </box>
        </box>
      </scrollbox>
      {/* The footer card: the provider route, and the workspace branch under 22 rows. */}
      <box flexDirection="column" width="100%" flexShrink={0} paddingTop={1} gap={0} overflow="hidden">
        {props.provider !== '' && props.terminalWidth >= HOME_VERSION_WIDTH ? (
          <text fg={props.fgBase} content={truncate(`${props.provider}/${props.model}`, props.width - 4)} wrapMode="none" flexShrink={0} />
        ) : null}
        {props.height >= 22 ? (
          <text fg={props.fgMuted} content={`⬖ ${truncate(branchText(), 38)}`} wrapMode="none" flexShrink={0} />
        ) : (
          <text fg={props.fgMuted} content={truncate(branchText(), 38)} wrapMode="none" flexShrink={0} />
        )}
        {props.version !== '' ? (
          <text fg={props.fgMuted} content={truncate(props.version, props.width - 4)} wrapMode="none" flexShrink={0} />
        ) : null}
      </box>
    </box>
  )
}

/** One activity line: `HH:MM who  what`, with the tool's status and duration appended. */
/** The sidebar painted as a right-aligned overlay: the same content over a dark backdrop. */
export function SidebarOverlay(props: SidebarProps & { readonly backdrop: string }) {
  return (
    <box
      position="absolute"
      right={0}
      top={0}
      bottom={0}
      width={Math.min(SIDEBAR_WIDTH, props.terminalWidth)}
      flexDirection="row"
      backgroundColor={props.backdrop}
      zIndex={500}
    >
      <box flexGrow={1} />
      <Sidebar {...props} />
    </box>
  )
}
