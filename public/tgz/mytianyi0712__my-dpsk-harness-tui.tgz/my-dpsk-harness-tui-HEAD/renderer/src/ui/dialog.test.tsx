/**
 * Dialog base tests.
 *
 * The dialogs are driven through the keymap, so every test feeds real key events
 * to the renderer and asserts what the dialog resolves to. A pick is the observable
 * result: `onDone` receives the value the host would get, so the assertions check
 * the navigation landed on the right row rather than the painted highlight.
 */

import { expect, test } from 'bun:test'
import { createAppStore, type AppStore } from '../app.tsx'
import { isolateShellStore, mountShell } from '../test-harness.tsx'
import { Shell } from '../app.tsx'
import { testRender } from '@opentui/solid'
import { createKeymap } from '../keymap/keymap.ts'
import type { DialogOption } from './dialog.tsx'

const THEMES: DialogOption[] = [
  { title: 'alpha', value: 'a', category: 'themes' },
  { title: 'beta', value: 'b', category: 'themes' },
  { title: 'gamma', value: 'c', category: 'themes' },
]

const SECTIONS: DialogOption[] = [
  { title: 'alpha', value: 'a', category: 'themes' },
  { title: 'beta', value: 'b', category: 'themes' },
  { title: 'compact', value: 'compact', category: 'actions' },
  { title: 'new session', value: 'new', category: 'actions' },
]

/** Mount through `mountShell`: it starts the renderer, so dialogs mounted after the first frame keep repainting. */
async function mount(store: AppStore, width = 90, height = 24) {
  return mountShell(store, { width, height })
}

test('the select dialog paints its rows and the category header', async () => {
  const store = createAppStore()
  store.openDialog({ kind: 'select', title: 'themes', options: THEMES, categoryFilter: 'themes', onDone: () => undefined })
  const { renderer, renderOnce, captureCharFrame } = await mount(store)
  const frame = captureCharFrame()
  expect(frame).toContain('themes')
  expect(frame).toContain('alpha')
  expect(frame).toContain('gamma')
  renderer.destroy()
})

test('arrow keys move the highlight and wrap at both ends', async () => {
  const picked: Array<string | undefined> = []
  const store = createAppStore()
  store.openDialog({ kind: 'select', title: 'themes', options: THEMES, onDone: value => picked.push(value) })
  const { renderer, mockInput, renderOnce } = await mount(store)
  // From the first row, `up` wraps to the last.
  mockInput.pressArrow('up')
  await renderOnce()
  mockInput.pressEnter()
  await renderOnce()
  expect(picked).toEqual(['c'])

  store.openDialog({ kind: 'select', title: 'themes', options: THEMES, onDone: value => picked.push(value) })
  await renderOnce()
  mockInput.pressArrow('down')
  mockInput.pressArrow('down')
  await renderOnce()
  mockInput.pressEnter()
  await renderOnce()
  expect(picked).toEqual(['c', 'c'])
  renderer.destroy()
})

test('home and end jump to the first and last row', async () => {
  const picked: Array<string | undefined> = []
  const store = createAppStore()
  store.openDialog({ kind: 'select', title: 'themes', options: THEMES, onDone: value => picked.push(value) })
  const { renderer, mockInput, renderOnce } = await mount(store)
  mockInput.pressKey('END')
  await renderOnce()
  mockInput.pressEnter()
  await renderOnce()
  expect(picked).toEqual(['c'])

  store.openDialog({ kind: 'select', title: 'themes', options: THEMES, onDone: value => picked.push(value) })
  await renderOnce()
  mockInput.pressKey('HOME')
  await renderOnce()
  mockInput.pressEnter()
  await renderOnce()
  expect(picked).toEqual(['c', 'a'])
  renderer.destroy()
})

test('typing in the filter narrows the list and Enter picks the match', async () => {
  const picked: Array<string | undefined> = []
  const store = createAppStore()
  store.openDialog({ kind: 'select', title: 'themes', options: THEMES, onDone: value => picked.push(value) })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mount(store)
  await mockInput.typeText('beta')
  await renderOnce()
  const frame = captureCharFrame()
  expect(frame).toContain('beta')
  expect(frame).not.toContain('alpha')
  mockInput.pressEnter()
  await renderOnce()
  expect(picked).toEqual(['b'])
  renderer.destroy()
})

test('a query with no match says so and Enter resolves nothing', async () => {
  const picked: Array<string | undefined> = []
  const store = createAppStore()
  store.openDialog({ kind: 'select', title: 'themes', options: THEMES, onDone: value => picked.push(value) })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mount(store)
  await mockInput.typeText('missing')
  await renderOnce()
  expect(captureCharFrame()).toContain('No results found')
  mockInput.pressEnter()
  await renderOnce()
  expect(picked).toEqual([])
  renderer.destroy()
})

test('alt+up and alt+down jump between category sections when the dialog opts in', async () => {
  const picked: Array<string | undefined> = []
  const store = createAppStore()
  // Section navigation is a capability the dialog declares (upstream's `sectionNavigation`);
  // a list without it consumes Alt+Up/Down without moving.
  store.openDialog({ kind: 'select', title: 'palette', options: SECTIONS, sectionNavigation: true, onDone: value => picked.push(value) })
  const { renderer, mockInput, renderOnce } = await mount(store)
  mockInput.pressArrow('down', { meta: true })
  await renderOnce()
  mockInput.pressEnter()
  await renderOnce()
  // The first row of the `actions` section.
  expect(picked).toEqual(['compact'])
  renderer.destroy()
})

test('escape closes the dialog and resolves it as cancelled', async () => {
  const picked: Array<string | undefined> = []
  const store = createAppStore()
  store.openDialog({ kind: 'select', title: 'themes', options: THEMES, onDone: value => picked.push(value) })
  const { renderer, mockInput, renderOnce, flush, captureCharFrame } = await mount(store)
  expect(captureCharFrame()).toContain('alpha')
  // Escape needs the escape-timeout window before the parser reports it.
  mockInput.pressEscape()
  await Bun.sleep(120)
  await flush()
  expect(picked).toEqual([undefined])
  expect(store.dialogOpen()).toBe(false)
  expect(captureCharFrame()).not.toContain('alpha')
  renderer.destroy()
})

test('a nested stack resolves the top and hands the keyboard back to the one below', async () => {
  const resolved: Array<string | undefined> = []
  const store = createAppStore()
  store.openDialog({ kind: 'select', title: 'themes', options: THEMES, onDone: value => resolved.push(value ?? 'select-cancelled') })
  const { renderer, mockInput, renderOnce, flush } = await mount(store)
  const selectController = store.dialogController()
  expect(selectController?.count()).toBe(3)

  store.openDialog({ kind: 'confirm', title: 'exit?', message: 'restore the terminal', onDone: value => resolved.push(value ?? 'confirm-cancelled') })
  await renderOnce()
  const confirmController = store.dialogController()
  expect(confirmController).not.toBe(selectController)

  mockInput.pressEscape()
  await Bun.sleep(120)
  await flush()
  expect(resolved).toEqual(['confirm-cancelled'])
  // The select dialog is still open and owns the keys again.
  expect(store.dialogOpen()).toBe(true)
  expect(store.dialogController()).toBe(selectController)
  mockInput.pressArrow('down')
  await renderOnce()
  mockInput.pressEnter()
  await renderOnce()
  expect(resolved).toEqual(['confirm-cancelled', 'b'])
  renderer.destroy()
})

test('the confirm dialog toggles between cancel and confirm with left and right', async () => {
  const resolved: Array<string | undefined> = []
  const store = createAppStore()
  store.openDialog({ kind: 'confirm', title: 'exit?', message: 'restore the terminal', onDone: value => resolved.push(value) })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mount(store)
  expect(captureCharFrame()).toContain('restore the terminal')
  expect(captureCharFrame()).toContain('confirm')
  // Enter runs the active button, which starts on confirm.
  mockInput.pressEnter()
  await renderOnce()
  expect(resolved).toEqual(['confirm'])

  store.openDialog({ kind: 'confirm', title: 'exit?', message: 'restore the terminal', onDone: value => resolved.push(value) })
  await renderOnce()
  mockInput.pressArrow('left')
  await renderOnce()
  mockInput.pressEnter()
  await renderOnce()
  expect(resolved).toEqual(['confirm', undefined])
  renderer.destroy()
})

test('the prompt dialog sends the typed text and cancels on escape', async () => {
  const resolved: Array<string | undefined> = []
  const store = createAppStore()
  store.openDialog({ kind: 'prompt', title: 'rename session', value: 'first prompt', onDone: value => resolved.push(value) })
  const { renderer, mockInput, renderOnce, flush, captureCharFrame } = await mount(store)
  expect(captureCharFrame()).toContain('first prompt')
  mockInput.pressEnter()
  await renderOnce()
  expect(resolved).toEqual(['first prompt'])

  store.openDialog({ kind: 'prompt', title: 'rename session', value: 'draft', onDone: value => resolved.push(value) })
  await renderOnce()
  await mockInput.typeText(' renamed')
  await renderOnce()
  mockInput.pressEnter()
  await renderOnce()
  expect(resolved).toEqual(['first prompt', 'draft renamed'])

  store.openDialog({ kind: 'prompt', title: 'rename session', value: 'x', onDone: value => resolved.push(value) })
  await renderOnce()
  mockInput.pressEscape()
  await Bun.sleep(120)
  await flush()
  expect(resolved).toEqual(['first prompt', 'draft renamed', undefined])
  renderer.destroy()
})

test('the alert dialog closes on Enter and on Escape', async () => {
  const resolved: Array<string | undefined> = []
  const store = createAppStore()
  store.openDialog({ kind: 'alert', title: 'renderer refused', message: 'host protocol mismatch', onDone: value => resolved.push(value) })
  const { renderer, mockInput, renderOnce, flush, captureCharFrame } = await mount(store)
  expect(captureCharFrame()).toContain('host protocol mismatch')
  mockInput.pressEnter()
  await renderOnce()
  expect(resolved).toEqual(['ok'])

  store.openDialog({ kind: 'alert', title: 'notice', message: 'second alert', onDone: value => resolved.push(value) })
  await renderOnce()
  mockInput.pressEscape()
  await Bun.sleep(120)
  await flush()
  expect(resolved).toEqual(['ok', undefined])
  renderer.destroy()
})

test('modal keys are no-ops when no dialog is open', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => sent.push({ kind, payload }))
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [] },
  })
  const { renderer, mockInput, renderOnce } = await mount(store)
  mockInput.pressArrow('up')
  mockInput.pressArrow('down')
  mockInput.pressKey('HOME')
  mockInput.pressEscape()
  await Bun.sleep(120)
  await renderOnce()
  // The composer's arrows and `home` do nothing with an empty, empty-cursor draft; the
  // escape falls through to the session layer's interrupt request, which the host ignores
  // for an idle turn.
  expect(sent).toEqual([{ kind: 'interrupt', payload: { sessionId: 'ses_1' } }])
  expect(store.dialogOpen()).toBe(false)
  renderer.destroy()
})

test('a prompt opened with no initial value submits the typed text', async () => {
  const resolved: Array<string | undefined> = []
  const store = createAppStore()
  store.openDialog({ kind: 'prompt', title: 'notes', onDone: value => resolved.push(value) })
  isolateShellStore(store)
  const { renderer, mockInput, renderOnce, captureCharFrame } = await testRender(() => <Shell store={store} />, { width: 90, height: 24 })
  const keymap = createKeymap(action => store.runAction(action), undefined, undefined, () => store.keyLayer())
  renderer.keyInput.on('keypress', (key: { name: string; ctrl: boolean; shift: boolean; meta: boolean }) => keymap.handle(key))
  await renderOnce()
  await Bun.sleep(10)
  await mockInput.typeText('ok')
  await renderOnce()
  expect(captureCharFrame()).toContain('ok')
  mockInput.pressEnter()
  await renderOnce()
  expect(resolved).toEqual(['ok'])
  renderer.destroy()
})

/** A list long enough that the dialog window cannot show every row at a 24-row terminal. */
const LONG: DialogOption[] = Array.from({ length: 20 }, (_, index) => ({
  title: `row${String(index + 1).padStart(2, '0')}`,
  value: `v${index + 1}`,
  category: 'rows',
}))

test('a long list scrolls with the highlight instead of hiding it below the window', async () => {
  const picked: Array<string | undefined> = []
  const store = createAppStore()
  store.openDialog({ kind: 'select', title: 'palette', options: LONG, onDone: value => picked.push(value) })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mount(store)
  // The window is `height / 2 - 6` rows tall, so only the first six rows are visible.
  expect(captureCharFrame()).toContain('row01')
  for (let step = 0; step < 9; step += 1) {
    mockInput.pressArrow('down')
    await renderOnce()
  }
  const frame = captureCharFrame()
  // The tenth row is the highlight; the window must have followed it.
  expect(frame).toContain('row10')
  expect(frame).not.toContain('row01')
  mockInput.pressEnter()
  await renderOnce()
  expect(picked).toEqual(['v10'])
  renderer.destroy()
})

test('home and end reveal their rows in a long list', async () => {
  const store = createAppStore()
  store.openDialog({ kind: 'select', title: 'palette', options: LONG, onDone: () => undefined })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mount(store)
  mockInput.pressKey('END')
  await renderOnce()
  expect(captureCharFrame()).toContain('row20')
  // Walking back up must bring the window with it, not leave it at the bottom.
  for (let step = 0; step < 9; step += 1) {
    mockInput.pressArrow('up')
    await renderOnce()
  }
  const frame = captureCharFrame()
  expect(frame).toContain('row11')
  expect(frame).not.toContain('row20')
  mockInput.pressKey('HOME')
  await renderOnce()
  expect(captureCharFrame()).toContain('row01')
  renderer.destroy()
})
