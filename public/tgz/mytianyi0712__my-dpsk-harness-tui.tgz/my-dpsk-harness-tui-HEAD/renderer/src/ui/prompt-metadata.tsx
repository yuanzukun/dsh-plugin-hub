/**
 * The prompt's metadata row.
 *
 * Row order and breakpoints are ported from opencode v2 (`anomalyco/opencode`, 2.0.32,
 * `packages/tui/src/component/prompt/metadata.tsx`), MIT. Registered in NOTICE.md under
 * the `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications:
 * - The row is `mode permission · model · effort`; the provider stays in the sidebar, where
 *   it has room and does not compete with the route the prompt is actually running.
 * - The mode, permission, model and effort each carry a distinct ink. The permission uses the
 *   same warning tone as the compact thinking header; the effort uses a different accent so
 *   the two colour facts never collapse into one hue.
 * - At narrow widths the row stays complete and clips at the panel edge rather than dropping
 *   the mode or permission, which are the two facts a user checks most often.
 */

import { TextAttributes } from '@opentui/core'
import { For } from '#solid'

/** One painted run of the row: the text and its color. */
export interface MetadataSegment {
  readonly text: string
  readonly fg: string
  /** Upstream paints the effort (its `variant`) bold. */
  readonly bold?: boolean
}

/** The colors the row paints with, resolved by the caller from the theme. */
export interface MetadataColors {
  readonly agent: string
  readonly permission: string
  readonly model: string
  readonly effort: string
  /** The `·` between fields, and any ink that belongs to no single field. */
  readonly muted: string
}

/** The pieces the row is built from. Empty strings are dropped, never painted blank. */
export interface MetadataParts {
  /** The localized agent preset, e.g. `极简模式`. */
  readonly agent: string
  /** The localized current permission preset, e.g. `完全权限`. */
  readonly permission: string
  readonly model: string
  readonly effort: string
}

/**
 * Build the row's runs.
 *
 * The order is `mode permission · model · effort`. A separator belongs to the run after
 * it, so dropping a field never strands a `·`. The first pair is separated by a space, not a
 * dot: they read as one "current route" phrase, matching the requested `极简模式 完全权限`
 * example.
 */
export function metadataSegments(parts: MetadataParts, colors: MetadataColors, width: number): MetadataSegment[] {
  void width
  const segments: MetadataSegment[] = []
  const append = (text: string, fg: string, separator: string, bold = false): void => {
    if (text === '') return
    if (segments.length > 0) segments.push({ text: separator, fg: colors.muted })
    segments.push({ text, fg, ...(bold ? { bold: true } : {}) })
  }
  append(parts.agent, colors.agent, ' ')
  append(parts.permission, colors.permission, ' ')
  append(parts.model, colors.model, ' · ')
  append(parts.effort, colors.effort, ' · ', true)
  return segments
}

/** The row itself: one pinned line under the textarea. */
export function PromptMetadata(props: { parts: MetadataParts; colors: MetadataColors; width: number }) {
  const segments = () => metadataSegments(props.parts, props.colors, props.width)
  return (
    <box flexDirection="row" width="100%" height={1} flexShrink={0} overflow="hidden">
      <For each={segments()}>
        {segment => (
          <text
            fg={segment.fg}
            content={segment.text}
            wrapMode="none"
            flexShrink={0}
            attributes={segment.bold === true ? TextAttributes.BOLD : undefined}
          />
        )}
      </For>
    </box>
  )
}
