/**
 * Assistant text rendering.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, 2.0.32,
 * `packages/tui/src/routes/session/message-parts.tsx`'s `AssistantText`), MIT. Registered
 * in NOTICE.md under the `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications:
 * - Upstream's plugin `renderNode` slot is not ported: this bundle has no in-process
 *   Markdown node plugins, and an empty hook would be a wrapper with no caller.
 * - The syntax style comes from the active native theme (`generateSyntax`), so headings,
 *   emphasis, inline code, links, lists, quotes and fenced code all paint with the same
 *   tokens upstream uses.
 *
 * The text is handed to OpenTUI's own `<markdown>` renderable, which is what upstream
 * paints with: it parses the source, renders grid tables, conceals the markers when the
 * mode is `rendered`, and paints fenced code through the same syntax style.
 *
 * `streaming` is OpenTUI's own incremental mode: while it is on, the trailing Markdown
 * block stays unstable (an unclosed fence or list keeps growing instead of being parsed as
 * a finished block) and the parser reuses the blocks that are already stable. The flag is
 * flipped off once the message settles, which finalizes the last block.
 */

import { mutedSyntaxStyle, syntaxStyleOrFallback } from '../theme/paths.ts'
import { normalizeListStrong } from './text.ts'

interface MarkdownTextProps {
  /** The message text exactly as the log carries it. */
  readonly text: string
  /** One token's color by full path. */
  readonly color: (path: string, fallback: string) => string
  /**
   * The source is still growing. Passing this to `<markdown>` is what keeps a half-typed
   * fenced block, list or table from being reparsed as a different block on every delta.
   */
  readonly streaming?: boolean
  /** Conceal the Markdown markers (`rendered` mode). Reasoning paints them raw. */
  readonly conceal?: boolean
  /** The ink token: `markdown.text` for answers, a muted token for reasoning. */
  readonly ink?: string
  /** The literal to paint when the theme does not define {@link ink}. */
  readonly inkFallback?: string
  /**
   * Paint through the reasoning syntax style: every token recolored to {@link ink}, the way
   * upstream's `generateThinkingSyntax` flattens a thought chain to one voice.
   */
  readonly muted?: boolean
}

/**
 * Stable Markdown props. OpenTUI 0.5.17 reconciles list-item children by object identity;
 * passing a fresh table-options object on every transcript delta rebuilt those children
 * without their conceal state, which is why `**` leaked only inside list items. The object
 * is immutable and shared across every MarkdownText instance.
 */
const TABLE_OPTIONS = Object.freeze({ style: 'grid' as const, cellPaddingX: 1 })
/**
 * One Markdown block: the assistant body, or a reasoning body.
 *
 * The content is trimmed only once the row has settled: trimming every delta would drop the
 * trailing blank line that tells the parser a block ended, so a finished paragraph would
 * flicker between `open` and `closed` on every character.
 */
export function MarkdownText(props: MarkdownTextProps) {
  const source = (): string => props.conceal === false ? props.text : normalizeListStrong(props.text)
  const content = (): string => (props.streaming === true ? source() : source().trim())
  const ink = (): string => props.color(props.ink ?? 'markdown.text', props.inkFallback ?? '#cdd6f4')
  const syntax = (): ReturnType<typeof syntaxStyleOrFallback> =>
    props.muted === true ? mutedSyntaxStyle(ink()) : syntaxStyleOrFallback(ink())
  return (
    <markdown
      content={content()}
      syntaxStyle={syntax()}
      internalBlockMode="top-level"
      tableOptions={TABLE_OPTIONS}
      streaming={props.streaming === true}
      conceal={props.conceal !== false}
      fg={ink()}
      bg={props.color('background.base', '#0a0a0a')}
    />
  )
}
