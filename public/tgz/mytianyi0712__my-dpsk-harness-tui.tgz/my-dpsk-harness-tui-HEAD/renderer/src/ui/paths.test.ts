/**
 * `@` path completion tests.
 *
 * The rows come from the host's workspace index (`workspace-files`, relative paths with a
 * trailing `/` on directories); the tests feed the same shape and assert the completions.
 */

import { expect, test } from 'bun:test'
import { acceptMention, mentionLines } from './completions.ts'
import { mentionSuggestions, trailingMention } from './paths.ts'

const WORKSPACE = ['src/ipc/', 'src/ipc/kinds.ts', 'src/ipc/envelope.ts', 'src/notes.md']

test('trailingMention finds the token at the end of the draft', () => {
  expect(trailingMention('read @src/ipc/kin')).toBe('@src/ipc/kin')
  expect(trailingMention('@')).toBe('@')
  // A mention that is not at the end is already finished text.
  expect(trailingMention('@src/a.ts and more')).toBeUndefined()
  expect(trailingMention('no mention')).toBeUndefined()
})

test('suggestions complete a path against the workspace index', () => {
  expect(mentionSuggestions(WORKSPACE, '@src/ipc/k')).toEqual(['@src/ipc/kinds.ts'])
  expect(mentionSuggestions(WORKSPACE, '@src/ipc/')).toEqual(['@src/ipc/', '@src/ipc/envelope.ts', '@src/ipc/kinds.ts'])
  // A directory carries its trailing slash so the next keystroke continues inside it.
  expect(mentionSuggestions(WORKSPACE, '@src/')).toEqual(['@src/ipc/', '@src/ipc/envelope.ts', '@src/ipc/kinds.ts', '@src/notes.md'])
  expect(mentionSuggestions(WORKSPACE, '@missing')).toEqual([])
  expect(mentionSuggestions(WORKSPACE, 'plain')).toEqual([])
})

test('a huge directory is capped so the composer list stays short', () => {
  const entries = Array.from({ length: 40 }, (_, index) => `file${String(index).padStart(2, '0')}.ts`)
  const matches = mentionSuggestions(entries, '@file')
  expect(matches.length).toBe(12)
  expect(matches[0]).toBe('@file00.ts')
})

test('acceptMention replaces the trailing token and keeps the rest of the draft', () => {
  expect(acceptMention(WORKSPACE, 'read @src/ipc/k')).toBe('read @src/ipc/kinds.ts')
  expect(acceptMention(WORKSPACE, 'read @src/n')).toBe('read @src/notes.md')
  expect(acceptMention(WORKSPACE, 'read plain')).toBeUndefined()
})

test('mentionLines is empty when the draft has no trailing mention', () => {
  expect(mentionLines(WORKSPACE, 'plain text')).toEqual([])
  expect(mentionLines(WORKSPACE, '@src/ipc/e')).toEqual(['@src/ipc/envelope.ts'])
})
