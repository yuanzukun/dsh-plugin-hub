/**
 * Prompt, confirm, and alert dialogs.
 *
 * Derived from opencode (`anomalyco/opencode`, v2.0.30,
 * `packages/tui/src/ui/dialog-prompt.tsx`, `dialog-confirm.tsx`,
 * `dialog-alert.tsx`), MIT. Registered in NOTICE.md under the `opencode` entry;
 * verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications:
 * - The prompt uses a single-line `input` instead of a `textarea` (rename,
 *   provider answers, and custom model ids are all one-line), so the busy/spinner
 *   state, the `actions` table, `useConfig` cursor style, and the textarea
 *   `traits` handling are not ported.
 * - `Keymap.createLayer()` is replaced by the store's modal key routing: each
 *   component registers a controller the keymap drives (`enter` submits,
 *   `left`/`right` toggle the confirm buttons, `escape` closes).
 * - `Locale.titlecase` is replaced by a local titlecase.
 * - `<Show>` at box level is replaced by ternaries.
 */

import { TextAttributes } from '@opentui/core'
import { For, onCleanup, onMount } from '#solid'
import { createStore } from '#solid/store'
import { DialogFooter, DialogHeader, DialogLayout, dialogColor, type DialogController, type DialogFooterAction, type DialogSpec, type DialogStore } from './dialog.tsx'

function titlecase(text: string): string {
  const first = text[0]
  if (first === undefined) return text
  return first.toUpperCase() + text.slice(1)
}

/** The prompt dialog: one line of text, Enter submits, Escape cancels. */
export function DialogPrompt(props: { store: DialogStore; spec: DialogSpec }) {
  const store = props.store
  const spec = props.spec
  const [state, setState] = createStore({ value: spec.value ?? spec.placeholder ?? '' })
  let input: { focus(): void; isDestroyed: boolean } | undefined

  function submit(): void {
    const value = state.value.trim()
    store.closeTopDialog(value === '' ? undefined : value)
  }

  const controller: DialogController = {
    move: () => undefined,
    moveTo: () => undefined,
    moveSection: () => undefined,
    moveColumn: () => undefined,
    submit,
    count: () => 0,
  }

  // The top dialog owns the modal keys; closing restores the dialog underneath it.
  onMount(() => {
    const previous = store.dialogController()
    store.setDialogController(controller)
    onCleanup(() => store.setDialogController(previous))
    setTimeout(() => {
      if (input !== undefined && !input.isDestroyed) input.focus()
    }, 1)
  })

  const actions: DialogFooterAction[] = [{ title: 'submit', key: 'enter', onTrigger: submit }]

  return (
    <DialogLayout
      store={store}
      header={<DialogHeader store={store} title={spec.title} onClose={() => store.closeTopDialog(undefined)} />}
      footer={<DialogFooter store={store} actions={actions} />}
    >
      <box gap={1}>
        <input
          width={54}
          value={state.value}
          placeholder={spec.placeholder ?? 'Enter text'}
          focused={true}
          textColor={dialogColor(store, 'text.base', '#cdd6f4')}
          placeholderColor={dialogColor(store, 'text.muted', '#7f849c')}
          focusedBackgroundColor={dialogColor(store, 'background.formfield.base', '#181825')}
          focusedTextColor={dialogColor(store, 'text.action.primary.$focused', '#cdd6f4')}
          ref={(renderable: { focus(): void; isDestroyed: boolean }) => {
            input = renderable
          }}
          onInput={value => setState('value', value)}
          // No Enter handler on the input: the store's keymap routes `return` to
          // `dialog-submit`, which runs this dialog's controller and submits. Binding
          // `onSubmit` here would add a second path, and a dialog opened from inside a
          // keypress handler gets the same keypress: the new input mounts focused
          // (`focused={true}`), the key event keeps propagating to it, and the prompt
          // submits an empty value the instant it opens.
        />
      </box>
    </DialogLayout>
  )
}

/** The confirm dialog: two buttons, `left`/`right` toggle, Enter runs the active one. */
export function DialogConfirm(props: { store: DialogStore; spec: DialogSpec }) {
  const store = props.store
  const spec = props.spec
  const [state, setState] = createStore({ active: 'confirm' as 'confirm' | 'cancel' })

  function run(which: 'confirm' | 'cancel'): void {
    store.closeTopDialog(which === 'confirm' ? spec.confirmLabel ?? 'confirm' : undefined)
  }

  const controller: DialogController = {
    move: () => undefined,
    moveTo: () => undefined,
    moveSection: () => undefined,
    moveColumn: direction => setState('active', state.active === 'confirm' ? 'cancel' : 'confirm'),
    submit: () => run(state.active),
    count: () => 0,
  }

  // The top dialog owns the modal keys; closing restores the dialog underneath it.
  onMount(() => {
    const previous = store.dialogController()
    store.setDialogController(controller)
    onCleanup(() => store.setDialogController(previous))
  })

  const actions: DialogFooterAction[] = [
    { title: 'confirm', key: 'enter', onTrigger: () => run('confirm') },
    { title: 'cancel', key: 'esc', side: 'right', onTrigger: () => run('cancel') },
  ]

  return (
    <DialogLayout
      store={store}
      header={<DialogHeader store={store} title={spec.title} onClose={() => store.closeTopDialog(undefined)} />}
      footer={<DialogFooter store={store} actions={actions} />}
    >
      <box gap={1}>
        {spec.message !== undefined ? <text fg={dialogColor(store, 'text.muted', '#7f849c')} content={spec.message} /> : null}
        <box flexDirection="row" justifyContent="flex-end" gap={1}>
          <For each={['cancel', 'confirm'] as const}>
            {key => (
              <box
                paddingLeft={1}
                paddingRight={1}
                backgroundColor={key === state.active ? dialogColor(store, 'background.action.primary.$hovered', '#313244') : 'transparent'}
                onMouseUp={() => run(key)}
              >
                <text
                  fg={key === state.active ? dialogColor(store, 'text.action.primary.$focused', '#cdd6f4') : dialogColor(store, 'text.muted', '#7f849c')}
                  attributes={key === state.active ? TextAttributes.BOLD : undefined}
                  content={titlecase(spec.confirmLabel !== undefined && key === 'confirm' ? spec.confirmLabel : key)}
                />
              </box>
            )}
          </For>
        </box>
      </box>
    </DialogLayout>
  )
}

/** The alert dialog: one message, Enter or Escape dismisses it. */
export function DialogAlert(props: { store: DialogStore; spec: DialogSpec }) {
  const store = props.store
  const spec = props.spec

  const controller: DialogController = {
    move: () => undefined,
    moveTo: () => undefined,
    moveSection: () => undefined,
    moveColumn: () => undefined,
    submit: () => store.closeTopDialog('ok'),
    count: () => 0,
  }

  // The top dialog owns the modal keys; closing restores the dialog underneath it.
  onMount(() => {
    const previous = store.dialogController()
    store.setDialogController(controller)
    onCleanup(() => store.setDialogController(previous))
  })

  const actions: DialogFooterAction[] = [{ title: 'ok', key: 'enter', onTrigger: () => store.closeTopDialog('ok') }]

  return (
    <DialogLayout
      store={store}
      header={<DialogHeader store={store} title={spec.title} onClose={() => store.closeTopDialog(undefined)} />}
      footer={<DialogFooter store={store} actions={actions} />}
    >
      {spec.message !== undefined ? <text fg={dialogColor(store, 'text.muted', '#7f849c')} content={spec.message} /> : null}
    </DialogLayout>
  )
}
