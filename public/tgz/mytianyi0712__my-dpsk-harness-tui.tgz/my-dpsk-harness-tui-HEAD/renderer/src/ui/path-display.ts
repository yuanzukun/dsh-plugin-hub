import { posix, win32 } from 'node:path'

/** How user-facing paths render. Operations always keep the original path. */
export type PathDisplayMode = 'tilde' | 'full'

export interface PathDisplayOptions {
  readonly home: string
  readonly mode: PathDisplayMode
  /** Injectable for tests; production passes the renderer platform. */
  readonly platform?: string
}

/** Shorten a path below the user's home to `~/...`; relative and foreign paths stay intact. */
export function formatDisplayPath(value: string, options: PathDisplayOptions): string {
  if (value === '' || options.mode === 'full' || options.home === '') return value
  const path = options.platform === 'win32' || (options.platform === undefined && process.platform === 'win32')
    ? win32
    : posix
  if (!path.isAbsolute(value)) return value
  const relative = path.relative(path.normalize(options.home), path.normalize(value))
  if (relative === '') return '~'
  if (relative === '..' || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative)) return value
  return `~/${relative.split(path.sep).filter(Boolean).join('/')}`
}
