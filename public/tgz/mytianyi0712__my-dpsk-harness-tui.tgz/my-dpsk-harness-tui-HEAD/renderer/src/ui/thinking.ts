/**
 * Thinking-block projection.
 *
 * The host folds a session log into assistant/tool rows. The compact transcript needs a
 * view model over those rows, but grouping must not mutate the host protocol: this module
 * is a pure scan that maps each participating row id to one block. Assistant text is the
 * only boundary between the live thinking block and the answer; tools and reasoning before
 * that boundary belong to the same block.
 */

import type { TranscriptEvent } from '../protocol/kinds.ts'

export type ThinkingPhase = 'thinking' | 'thought'

export interface ThinkingBlockView {
  /** Stable identity used by the click-state map. */
  readonly id: string
  /** The first row in time order; the block is painted at this row's position. */
  readonly leaderId: string
  /** Reasoning/tool rows in timeline order. The body row is not included unless it reasons. */
  readonly rows: readonly TranscriptEvent[]
  readonly phase: ThinkingPhase
  readonly toolCount: number
  readonly startedAt?: number
  readonly endedAt?: number
  /** The assistant row whose answer text closes the block. */
  readonly bodyId?: string
}

export interface ThinkingRowBinding {
  readonly blockId: string
  /** The row that paints the block; every other bound row is absorbed by it. */
  readonly leader: boolean
}

export interface ThinkingPlan {
  readonly blocks: ReadonlyMap<string, ThinkingBlockView>
  readonly byRow: ReadonlyMap<string, ThinkingRowBinding>
}

export interface PlanThinkingOptions {
  /** The host's live turn flag. A trailing block with no live signal settles to `thought`. */
  readonly turnRunning?: boolean
}

interface MutableBlock {
  readonly id: string
  readonly leaderId: string
  readonly rows: TranscriptEvent[]
  readonly toolKeys: Set<string>
  bodyId?: string
  body?: TranscriptEvent
}

/** The step start implied by a row. A durable assistant row's createdAt is its completion. */
export function rowStartedAt(row: TranscriptEvent): number | undefined {
  if (row.createdAt === undefined) return undefined
  if (row.role === 'assistant' && row.durationMs !== undefined && row.durationMs > 0) {
    return row.createdAt - row.durationMs
  }
  return row.createdAt
}

/** The last known completion time. Pending tools cannot claim to have completed. */
function rowCompletedAt(row: TranscriptEvent): number | undefined {
  if (row.createdAt === undefined) return undefined
  if (row.role === 'tool' && row.status === 'pending') return undefined
  return row.createdAt
}

function hasReasoning(row: TranscriptEvent): boolean {
  return (row.reasoning ?? '').trim() !== ''
}

function hasBody(row: TranscriptEvent): boolean {
  return row.role === 'assistant' && (row.text ?? '').trim() !== ''
}

function toolKey(row: TranscriptEvent): string {
  return row.callId ?? row.id
}

/**
 * Project a transcript into compact thinking blocks.
 *
 * A block opens on reasoning (including an empty reasoning field while its delta is still
 * pending) or a tool call. An assistant body closes the current block; later reasoning/tools
 * in the same turn open another block. User rows, turn changes, and system rows also close
 * the current block.
 */
export function planThinking(
  rows: readonly TranscriptEvent[],
  options: PlanThinkingOptions = {},
): ThinkingPlan {
  const blocks = new Map<string, ThinkingBlockView>()
  const byRow = new Map<string, ThinkingRowBinding>()
  let open: MutableBlock | undefined
  let turn: number | undefined

  const close = (block: MutableBlock, live: boolean): void => {
    const rowsInBlock = [...block.rows]
    const starts = rowsInBlock.map(rowStartedAt).filter((value): value is number => value !== undefined)
    const completed = rowsInBlock
      .filter(row => row.role !== 'assistant' || block.bodyId === undefined || row.id !== block.bodyId)
      .map(rowCompletedAt)
      .filter((value): value is number => value !== undefined)
    const bodyCompleted = block.body === undefined ? undefined : block.body.bodyAt ?? rowCompletedAt(block.body)
    const ended = bodyCompleted ?? (completed.length === 0 ? undefined : Math.max(...completed, ...(starts.length === 0 ? [] : [Math.min(...starts)])))
    const anyStreaming = rowsInBlock.some(row => row.streaming === true)
    const anyToolPending = rowsInBlock.some(row => row.role === 'tool' && row.status === 'pending')
    const phase: ThinkingPhase = block.bodyId !== undefined
      ? 'thought'
      : live && (options.turnRunning === true || anyStreaming || anyToolPending)
        ? 'thinking'
        : 'thought'
    const view: ThinkingBlockView = {
      id: block.id,
      leaderId: block.leaderId,
      rows: rowsInBlock,
      phase,
      toolCount: block.toolKeys.size,
      ...(starts.length === 0 ? {} : { startedAt: Math.min(...starts) }),
      ...(ended === undefined ? {} : { endedAt: ended }),
      ...(block.bodyId === undefined ? {} : { bodyId: block.bodyId }),
    }
    blocks.set(view.id, view)
    for (const row of rowsInBlock) {
      byRow.set(row.id, { blockId: view.id, leader: row.id === view.leaderId })
    }
  }

  const start = (row: TranscriptEvent): MutableBlock => {
    const block: MutableBlock = {
      id: row.id,
      leaderId: row.id,
      rows: [],
      toolKeys: new Set<string>(),
    }
    open = block
    return block
  }

  const attach = (block: MutableBlock, row: TranscriptEvent): void => {
    block.rows.push(row)
    if (row.role === 'tool') block.toolKeys.add(toolKey(row))
  }

  for (const row of rows) {
    if (row.turn !== undefined && turn !== undefined && row.turn !== turn) {
      if (open !== undefined) close(open, false)
      open = undefined
    }
    if (row.turn !== undefined) turn = row.turn

    if (row.role === 'user') {
      if (open !== undefined) close(open, false)
      open = undefined
      continue
    }

    if (row.role === 'system') {
      if (open !== undefined) close(open, false)
      open = undefined
      continue
    }

    if (row.role === 'assistant') {
      const reasoning = hasReasoning(row)
      const body = hasBody(row)
      const waiting = row.streaming === true && !body && row.reasoning !== undefined && !reasoning
      if (reasoning || waiting) {
        const block = open ?? start(row)
        attach(block, row)
      }
      if (body) {
        if (open !== undefined) {
          open.bodyId = row.id
          open.body = row
          close(open, true)
          open = undefined
        }
      }
      continue
    }

    if (row.role === 'tool') {
      const block = open ?? start(row)
      attach(block, row)
    }
  }

  if (open !== undefined) close(open, true)

  return { blocks, byRow }
}

/** `<1m` is seconds only; one minute and over is `Xm YYs` with a stable two-digit seconds field. */
export function formatThinkingDuration(durationMs: number | undefined): string {
  if (durationMs === undefined || !Number.isFinite(durationMs) || durationMs < 1000) return ''
  const totalSeconds = Math.floor(durationMs / 1000)
  if (totalSeconds < 60) return `${String(totalSeconds)}s`
  const minutes = Math.floor(totalSeconds / 60)
  const seconds = totalSeconds % 60
  return `${String(minutes)}m ${String(seconds).padStart(2, '0')}s`
}

/** `1 Tool` / `2 Tools`, omitted entirely when no call has appeared. */
export function formatToolCount(toolCount: number): string {
  if (toolCount <= 0) return ''
  return `Used ${String(toolCount)} ${toolCount === 1 ? 'Tool' : 'Tools'}`
}

/** The compact header text, without the leading marker/spinner. */
export function thinkingHeader(block: Pick<ThinkingBlockView, 'phase' | 'startedAt' | 'endedAt' | 'toolCount'>, now = Date.now()): string {
  const live = block.phase === 'thinking'
  const duration = formatThinkingDuration(
    live
      ? block.startedAt === undefined ? undefined : Math.max(0, now - block.startedAt)
      : block.startedAt === undefined || block.endedAt === undefined ? undefined : Math.max(0, block.endedAt - block.startedAt),
  )
  const label = live ? 'Thinking' : 'Thought'
  const tools = formatToolCount(block.toolCount)
  return [duration === '' ? label : `${label} ${duration}`, tools].filter(part => part !== '').join(' | ')
}

/** The fold marker shown before the label. */
export function thinkingMarker(mode: 'preview' | 'detail' | 'closed'): '-' | '+' {
  return mode === 'closed' ? '+' : '-'
}

export type ThinkingMode = 'preview' | 'detail' | 'closed'
export type ThinkingModeOverride = 'detail' | 'closed'

/**
 * Resolve the three-state presentation:
 * - an explicit detail/closed choice always wins;
 * - a live, visible reasoning block defaults to its preview;
 * - everything else starts closed so an answer keeps the transcript compact.
 *
 * `showReasoning` only hides the automatic preview/body. The header remains clickable, so
 * hiding reasoning never hides the fact that a thought happened.
 */
export function resolveThinkingMode(
  block: Pick<ThinkingBlockView, 'phase'>,
  override: ThinkingModeOverride | undefined,
  showReasoning: boolean,
): ThinkingMode {
  if (override !== undefined) return override
  return block.phase === 'thinking' && showReasoning ? 'preview' : 'closed'
}

