/**
 * The session tabs: the horizontal strip opencode v2 paints above the transcript.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, 2.0.32, `packages/tui/src/component/
 * session-tabs.tsx` and `context/session-tabs-model.ts`), MIT. Registered in NOTICE.md
 * under the `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications from upstream:
 * - The pulse, marquee, drag-reorder, rename, and close affordances are not ported: they
 *   need live session status and mouse hover, and dsh's `session-list` carries only the
 *   current session. The chip keeps upstream's geometry — a right-aligned indicator cell
 *   plus the title — but uses a higher-contrast active surface for terminal palettes.
 * - Upstream's indicator cell shows `1..n` under `tabs.indicators = "numbers"`, else a
 *   status glyph. dsh has no busy/attention/unread state to draw, so it always shows the
 *   1-based number: the same cell the leader's `1..9` select-session chords use.
 * - Upstream's add affordance is a 3-cell `" + "` text, not a labelled chip.
 */

import { createTextAttributes } from '@opentui/core'
import { createSignal, For } from '#solid'
import { truncate } from './text.ts'

/** One session row the host pushed via `session-list`. */
export interface SessionTab {
  readonly id: string
  readonly title: string
  readonly active: boolean
  readonly status?: 'idle' | 'running'
  /** The Home draft has no host session until its first send promotes it. */
  readonly draft?: boolean
}

/** Upstream's chip metrics: a chip is 22 cells wide, min 8, max 32. */
export const SESSION_TAB_WIDTH = 22
export const SESSION_TAB_MAX_WIDTH = 32
export const SESSION_TAB_MIN_WIDTH = 8
/** The `" + "` add cell: three characters, no padding box. */
const ADD_TAB_WIDTH = 3

/** What a chip says when the host has no title for the session yet. */
/** The label every surface uses for a session that has never been titled. */
export const UNTITLED = 'New Session'

/** The overflow marker widths, one gap cell beside the arrow and the count: `‹12 ` / ` 12›`. */
export function overflowWidth(count: number): number {
  return String(count).length + 2
}

/** The indicator cell: two cells minimum, so `1` still aligns under `12`. */
export function numberWidth(count: number): number {
  return Math.max(2, String(count).length)
}

interface StripProps {
  readonly sessions: readonly SessionTab[]
  readonly total: number
  readonly onSelect: (id: string) => void
  readonly onNew: () => void
  /** Close one tab without selecting it (the `×` affordance). */
  readonly onClose: (id: string) => void
  /** Open the tab's management menu (right click). */
  readonly onMenu: (id: string) => void
  readonly fgActive: string
  readonly fgBase: string
  readonly fgMuted: string
  readonly fgNumber: string
  readonly bgActive: string
  readonly bgChip: string
  /** The chip an untitled session wears (host dictionary: `未命名会话`). */
  readonly untitled?: string
  /** Drag a chip to a new zero-based position. */
  readonly onMove: (id: string, index: number) => void
  readonly fgRunning: string
}

type TabMouseEvent = {
  readonly x?: number
  readonly button?: number
  stopPropagation?: () => void
  preventDefault?: () => void
}

/** One chip: the number cell, then the title. */
interface TabSlot {
  readonly session: SessionTab
  readonly width: number
  readonly number: number
  readonly widthOfNumber: number
}

/** The solved strip: which chips are visible, at what width, and the hidden counts. */
export interface TabLayout {
  readonly slots: readonly TabSlot[]
  readonly before: number
  readonly after: number
}

/**
 * Solve the strip the way upstream's `adaptiveSessionTabLayout` does: the active chip gets
 * at least its 22-cell default, the rest share a floor of 8, and the two overflow markers
 * take their cells out of the row before the visible run is sized. The run recenters on
 * the active chip when it does not fit.
 */
export function tabLayout(sessions: readonly SessionTab[], available: number): TabLayout {
  if (sessions.length === 0) return { slots: [], before: 0, after: 0 }
  const activeIndex = sessions.findIndex(session => session.active)
  const fit = (width: number): number =>
    Math.min(
      sessions.length,
      Math.max(
        1,
        activeIndex === -1
          ? Math.floor(Math.max(0, width) / SESSION_TAB_MIN_WIDTH)
          : 1 + Math.floor((Math.max(0, width) - SESSION_TAB_WIDTH) / SESSION_TAB_MIN_WIDTH),
      ),
    )
  const solve = (count: number, start: number, attempts: number): { count: number; start: number } => {
    const bounded = Math.min(Math.max(0, start), sessions.length - count)
    const nextStart = Math.min(
      Math.max(
        0,
        activeIndex === -1
          ? bounded
          : activeIndex < bounded
            ? activeIndex
            : activeIndex >= bounded + count
              ? activeIndex - count + 1
              : bounded,
      ),
      sessions.length - count,
    )
    const markers =
      (nextStart > 0 ? overflowWidth(nextStart) : 0) +
      (nextStart + count < sessions.length ? overflowWidth(sessions.length - nextStart - count) : 0)
    const nextCount = fit(available - markers)
    if (nextCount === count || attempts === 0) return { count, start: nextStart }
    return solve(nextCount, nextStart, attempts - 1)
  }
  const solved = solve(fit(available), 0, 3)
  const visible = sessions.slice(solved.start, solved.start + solved.count)
  const before = solved.start
  const after = sessions.length - solved.start - solved.count
  const contentWidth = Math.max(
    1,
    available - (before > 0 ? overflowWidth(before) : 0) - (after > 0 ? overflowWidth(after) : 0),
  )
  const roomy = contentWidth >= SESSION_TAB_WIDTH * visible.length
  const total = roomy ? Math.min(contentWidth, SESSION_TAB_MAX_WIDTH * visible.length) : contentWidth
  const indicator = numberWidth(sessions.length)
  const width = Math.max(1, Math.floor(total / Math.max(1, visible.length)))
  const remainder = Math.max(0, total - width * visible.length)
  const slots = visible.map((session, index) => ({
    session,
    width: width + (index < remainder ? 1 : 0),
    number: solved.start + index + 1,
    widthOfNumber: indicator,
  }))
  return { slots, before, after }
}

/**
 * The horizontal strip: the overflow marker, the chips, the trailing marker, then `" + "`.
 *
 * An idle chip is the page; the active chip uses the theme's high raised surface and bold
 * label. Upstream's one-step tint was too close to the page in terminal palettes, making the
 * current tab hard to find. The title budget is the chip width minus the number cell and one
 * separating cell (`restingTitleWidth` upstream).
 */
export function SessionStrip(props: StripProps) {
  // The strip's own horizontal padding is not available to the chips.
  const inset = () => (props.total < 44 ? 2 : 4)
  const available = () => Math.max(1, props.total - inset() - ADD_TAB_WIDTH)
  const layout = () => tabLayout(props.sessions, available())
  const [hovered, setHovered] = createSignal<string | undefined>()
  const [dragging, setDragging] = createSignal<string | undefined>()
  let drag: { id: string; startX: number; index: number; moved: boolean } | undefined
  let suppressClick = false
  /** The active chip reserves two cells for its close affordance (` ×`). */
  const closeWidth = (slot: TabSlot): number => (slot.session.active ? 2 : 0)
  const titleWidth = (slot: TabSlot): number => Math.max(1, slot.width - 1 - slot.widthOfNumber - closeWidth(slot))
  const running = (slot: TabSlot): boolean => slot.session.status === 'running'
  /** Map a terminal column to the visible slot under it (or the nearest edge). */
  const targetIndex = (x: number | undefined): number => {
    const solved = layout()
    if (solved.slots.length === 0) return 0
    let cursor = inset() + (solved.before > 0 ? overflowWidth(solved.before) : 0)
    if (x === undefined) return solved.slots.at(-1)!.number - 1
    for (const slot of solved.slots) {
      if (x < cursor + slot.width) return slot.number - 1
      cursor += slot.width
    }
    return solved.slots.at(-1)!.number - 1
  }
  const closeFrom = (event: TabMouseEvent, id: string): void => {
    event.stopPropagation?.()
    props.onClose(id)
  }
  return (
    <box
      flexDirection="row"
      width="100%"
      height={1}
      flexShrink={0}
      paddingLeft={props.total < 44 ? 1 : 2}
      paddingRight={props.total < 44 ? 1 : 2}
      zIndex={1}
      overflow="hidden"
    >
      {layout().before > 0 ? (
        <text fg={props.fgMuted} content={`‹${layout().before} `} wrapMode="none" flexShrink={0} selectable={false} />
      ) : null}
      <For each={layout().slots}>
        {slot => {
          const id = slot.session.id
          const active = slot.session.active
          return (
            <box
              width={slot.width}
              flexShrink={0}
              flexDirection="row"
              position="relative"
              backgroundColor={active ? props.bgActive : props.bgChip}
              onMouseOver={() => setHovered(id)}
              onMouseOut={() => {
                if (dragging() !== id) setHovered(undefined)
              }}
              onMouseUp={() => {
                if (dragging() === id) return
                if (suppressClick) {
                  suppressClick = false
                  return
                }
                drag = undefined
                props.onSelect(id)
              }}
              onMouseDown={(event: TabMouseEvent) => {
                if (event.button === 2) {
                  event.stopPropagation?.()
                  props.onMenu(id)
                  return
                }
                if (event.button === 1) {
                  event.stopPropagation?.()
                  props.onClose(id)
                  return
                }
                drag = { id, startX: event.x ?? 0, index: slot.number - 1, moved: false }
              }}
              onMouseDrag={(event: TabMouseEvent) => {
                if (drag === undefined || drag.id !== id) return
                if (Math.abs((event.x ?? drag.startX) - drag.startX) > 1) {
                  drag.moved = true
                  setDragging(id)
                  event.stopPropagation?.()
                }
              }}
              onMouseDragEnd={(event: TabMouseEvent) => {
                if (drag === undefined || drag.id !== id) return
                const moved = drag.moved
                const from = drag.index
                const target = targetIndex(event.x)
                drag = undefined
                setDragging(undefined)
                if (!moved) return
                suppressClick = true
                if (target !== from) props.onMove(id, target)
                event.stopPropagation?.()
              }}
              overflow="hidden"
            >
              <box width={slot.widthOfNumber} flexShrink={0} justifyContent="flex-end" paddingRight={1}>
                <text
                  fg={running(slot) ? props.fgRunning : active ? props.fgActive : props.fgNumber}
                  attributes={active ? createTextAttributes({ bold: true }) : undefined}
                  content={running(slot) ? '●' : String(slot.number)}
                  wrapMode="none"
                  selectable={false}
                />
              </box>
              <box width={titleWidth(slot)} flexShrink={1} overflow="hidden">
                <text
                  fg={active ? props.fgActive : props.fgMuted}
                  attributes={active ? createTextAttributes({ bold: true }) : undefined}
                  content={truncate(slot.session.title.trim() === '' ? props.untitled ?? UNTITLED : slot.session.title, titleWidth(slot))}
                  wrapMode="none"
                  selectable={false}
                />
              </box>
              {active ? (
                <text
                  width={2}
                  fg={props.fgMuted}
                  content=" ×"
                  wrapMode="none"
                  selectable={false}
                  onMouseDown={(event: TabMouseEvent) => event.stopPropagation?.()}
                  onMouseUp={(event: TabMouseEvent) => closeFrom(event, id)}
                />
              ) : hovered() === id ? (
                <box
                  position="absolute"
                  right={0}
                  top={0}
                  width={2}
                  zIndex={2}
                  backgroundColor={props.bgChip}
                  onMouseDown={(event: TabMouseEvent) => event.stopPropagation?.()}
                  onMouseUp={(event: TabMouseEvent) => closeFrom(event, id)}
                >
                  <text fg={props.fgMuted} content=" ×" wrapMode="none" selectable={false} />
                </box>
              ) : null}
            </box>
          )
        }}
      </For>
      {layout().after > 0 ? (
        <text fg={props.fgMuted} content={` ${layout().after}›`} wrapMode="none" flexShrink={0} selectable={false} />
      ) : null}
      <text
        width={ADD_TAB_WIDTH}
        fg={props.fgMuted}
        content=" + "
        wrapMode="none"
        flexShrink={0}
        selectable={false}
        onMouseUp={() => props.onNew()}
      />
    </box>
  )
}

/** The strip's own width measure, exported so the shell can assert it fits. */
export const TAB_STRIP_ADD_WIDTH = ADD_TAB_WIDTH