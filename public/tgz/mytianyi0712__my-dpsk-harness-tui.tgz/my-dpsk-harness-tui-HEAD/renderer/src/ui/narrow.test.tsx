/**
 * Narrow terminal breakpoints.
 *
 * `createTestRenderer` exposes `resize()`, so the layout is asserted at real
 * widths without a TTY: the dialog panel never runs past the screen, the footer
 * stacks below 60 columns (opencode's `narrow()` rule), and the rows stay
 * reachable at 40 columns.
 */

import { expect, test } from 'bun:test'
import { testRender } from '@opentui/solid'
import { Shell, createAppStore } from '../app.tsx'
import { createKeymap } from '../keymap/keymap.ts'
import { isolateShellStore } from '../test-harness.tsx'
import { dialogWidth } from './dialog.tsx'
import type { DialogOption } from './dialog.tsx'

const THEMES: DialogOption[] = [
  { title: 'alpha', value: 'a', category: 'themes' },
  { title: 'beta', value: 'b', category: 'themes' },
  { title: 'gamma theme with a long name that must be truncated', value: 'c', category: 'themes' },
]

function openThemes(store: ReturnType<typeof createAppStore>) {
  store.openDialog({ kind: 'select', title: 'themes', options: THEMES, onDone: () => undefined })
}

/** Every painted line must fit the terminal width. */
function assertFits(frame: string, width: number): void {
  for (const line of frame.split('\n')) {
    expect(line.length).toBeLessThanOrEqual(width)
  }
}

test('the panel width table is opencode v2 three sizes', () => {
  expect(dialogWidth('medium')).toBe(60)
  expect(dialogWidth('large')).toBe(88)
  expect(dialogWidth('xlarge')).toBe(116)
})

test('a 40-column terminal keeps the dialog inside the screen and stacks the footer', async () => {
  const store = createAppStore()
  openThemes(store)
  isolateShellStore(store)
  const setup = await testRender(() => <Shell store={store} />, { width: 80, height: 20 })
  const keymap = createKeymap(action => store.runAction(action))
  setup.renderer.keyInput.on('keypress', (key: { name: string; ctrl: boolean; shift: boolean; meta: boolean }) => keymap.handle(key))
  await setup.renderOnce()
  setup.resize(40, 20)
  await setup.renderOnce()

  const frame = setup.captureCharFrame()
  assertFits(frame, 40)
  const lines = frame.split('\n')
  const moveLine = lines.findIndex(line => line.includes('move'))
  const runLine = lines.findIndex(line => line.includes('run'))
  expect(moveLine).toBeGreaterThanOrEqual(0)
  // Below 60 columns the action row stacks vertically, so the labels are on
  // separate lines rather than colliding on one.
  expect(runLine).toBeGreaterThan(moveLine)
  // The rows are still reachable: the list paints inside the panel.
  expect(frame).toContain('alpha')
  setup.renderer.destroy()
})

test('a 60-column terminal keeps the footer actions on one row', async () => {
  const store = createAppStore()
  openThemes(store)
  isolateShellStore(store)
  const setup = await testRender(() => <Shell store={store} />, { width: 80, height: 20 })
  await setup.renderOnce()
  setup.resize(60, 20)
  await setup.renderOnce()

  const frame = setup.captureCharFrame()
  assertFits(frame, 60)
  const line = frame.split('\n').find(line => line.includes('move') && line.includes('run'))
  expect(line).toBeDefined()
  setup.renderer.destroy()
})

test('a long row title is truncated to the panel, not wrapped', async () => {
  const store = createAppStore()
  openThemes(store)
  isolateShellStore(store)
  const setup = await testRender(() => <Shell store={store} />, { width: 40, height: 20 })
  await setup.renderOnce()
  const frame = setup.captureCharFrame()
  assertFits(frame, 40)
  // The truncation marker appears and the tail of the long title is cut.
  expect(frame).toContain('…')
  expect(frame).not.toContain('that must be truncated')
  setup.renderer.destroy()
})

test('the shell repaints after a resize and the dialog follows the new width', async () => {
  const store = createAppStore()
  isolateShellStore(store)
  const { renderer, renderOnce, captureCharFrame, resize } = await testRender(
    () => <Shell store={store} />,
    { width: 80, height: 20 },
  )
  await renderOnce()
  openThemes(store)
  await renderOnce()
  expect(captureCharFrame()).toContain('alpha')
  resize(30, 12)
  await renderOnce()
  const frame = captureCharFrame()
  assertFits(frame, 30)
  // The panel shrinks to `width - 2`, so the header stays on screen.
  expect(frame).toContain('themes')
  expect(renderer.width).toBe(30)
  renderer.destroy()
})
