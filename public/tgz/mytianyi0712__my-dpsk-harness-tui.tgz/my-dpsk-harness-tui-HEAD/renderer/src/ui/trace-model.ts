import type { TranscriptEvent } from '../protocol/kinds.ts'

/** One row in the /trace interaction timeline. */
export interface TraceRow {
  readonly id: string
  readonly title: string
  readonly category: string
  readonly details: readonly string[]
}

export interface TraceLabels {
  readonly user: string
  readonly assistant: string
  readonly tool: string
  readonly system: string
  readonly seq: string
  readonly turn: string
  readonly step: string
  readonly status: string
}

function clock(value: number | undefined): string {
  if (value === undefined) return '--:--:--'
  const date = new Date(value)
  return date.toTimeString().slice(0, 8)
}

function roleLabel(role: string, labels: TraceLabels): string {
  if (role === 'user') return labels.user
  if (role === 'assistant') return labels.assistant
  if (role === 'tool') return labels.tool
  return labels.system
}

/** Build the full interaction timeline. No row cap: the /trace panel owns scrolling. */
export function buildTraceRows(events: readonly TranscriptEvent[], labels: TraceLabels): TraceRow[] {
  return events.map((row, index) => {
    const role = roleLabel(row.role, labels)
    const status = row.status === undefined ? '' : ' · ' + row.status
    const duration = row.durationMs === undefined ? '' : ' · ' + (row.durationMs / 1000).toFixed(1) + 's'
    const tool = row.tool === undefined ? '' : ' ' + row.tool
    const title = clock(row.createdAt) + '  ' + role + tool + status + duration
    const category = row.turn === undefined ? role : labels.turn + ' ' + String(row.turn)
    const details: string[] = []
    if (row.sourceSeq !== undefined) details.push(labels.seq + ' ' + String(row.sourceSeq))
    if (row.turn !== undefined) details.push(labels.turn + ' ' + String(row.turn) + (row.step === undefined ? '' : ' · ' + labels.step + ' ' + String(row.step)))
    if (row.id !== '') details.push('id ' + row.id)
    if (row.callId !== undefined) details.push('call ' + row.callId)
    if (row.model !== undefined) details.push('model ' + row.model)
    if (row.status !== undefined) details.push(labels.status + ' ' + row.status)
    if (row.text !== undefined && row.text !== '') details.push('text: ' + row.text)
    if (row.reasoning !== undefined && row.reasoning !== '') details.push('reasoning: ' + row.reasoning)
    if (row.toolInput !== undefined) details.push('input: ' + JSON.stringify(row.toolInput, null, 2))
    if (row.toolOutput !== undefined && row.toolOutput.length > 0) details.push('output: ' + row.toolOutput.join('\\n'))
    if (row.error !== undefined) details.push('error: ' + row.error)
    return { id: row.id + ':' + String(index), title, category, details }
  })
}


