/**
 * Border glyphs for the left-gutter chrome.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, dev, `packages/tui/src/ui/border.ts`), MIT.
 * Registered in NOTICE.md under the `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * The prompt, the composer drawer, the autocomplete popup, and the user message card all draw a
 * single left border. OpenTUI's `single` style puts corner glyphs at the top and bottom of that
 * edge, which breaks the vertical line the region needs; `customBorderChars` replaces the corners
 * with the same vertical glyph so the gutter reads as one continuous `┃`.
 */

import type { BorderCharacters } from '@opentui/core'

/** A border whose corners do not interrupt the sides: the left gutter stays one line. */
export const SPLIT_BORDER: BorderCharacters = {
  topLeft: '┃',
  topRight: '┃',
  bottomLeft: '┃',
  bottomRight: '┃',
  horizontal: '─',
  vertical: '┃',
  topT: '─',
  bottomT: '─',
  leftT: '┃',
  rightT: '┃',
  cross: '┼',
}

/** The prompt's bottom-left corner: the gutter turns into the shadow lip. */
export const PROMPT_CORNER_BORDER: BorderCharacters = {
  ...SPLIT_BORDER,
  bottomLeft: '╹',
}

/**
 * An edge with every glyph blank: the prompt's shadow lip draws one line and nothing else.
 * `single`'s corners would cut the `┃` gutter, and `SPLIT_BORDER`'s `┃` corners would paint
 * a second vertical line the lip does not want.
 */
export const EMPTY_BORDER: BorderCharacters = {
  topLeft: '',
  topRight: '',
  bottomLeft: '',
  bottomRight: '',
  horizontal: ' ',
  vertical: ' ',
  leftT: '',
  rightT: '',
  topT: '',
  bottomT: '',
  cross: '',
}

/** The shadow lip under the prompt: a bottom edge drawn with the upper-half block, with the
 * outer box's left corner turned into `╹` so the gutter terminates on the lip. */
export const SHADOW_LIP_BORDER: BorderCharacters = {
  ...EMPTY_BORDER,
  horizontal: '▀',
}

/** The outer half of the lip row: a blank left border that ends in `╹`. */
export const SHADOW_LIP_EDGE: BorderCharacters = {
  ...EMPTY_BORDER,
  vertical: '╹',
}
