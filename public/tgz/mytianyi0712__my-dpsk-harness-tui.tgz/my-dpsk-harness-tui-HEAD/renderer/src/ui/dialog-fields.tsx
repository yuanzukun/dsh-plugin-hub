/**
 * The multi-field form the renderer draws for a harness-owned form (the provider
 * editor). Written for this project, not a port: the upstream prompt editor is a
 * nested model-catalog editor with a discovery probe, and the renderer's version is
 * the flat field list the host sends as `form-spec`.
 *
 * The host owns the field list and the write: it reads the current draft through its
 * settings seam, sends the fields down, and writes the collected values back through
 * the same seam. The renderer only draws and collects, so the provider id rules, the
 * credential reference, and the settings mutations stay in one place.
 *
 * The values travel back as a JSON string in `onDone`, because the dialog stack's
 * resolve channel carries `string | undefined`.
 *
 * An `action` field is a row that sends the current values upstream on Enter
 * (`model-discover`) and leaves the form open: the host answers with the merged line,
 * which lands back in the field through the writer this component registers on mount.
 * The renderer has no button primitive, so the action is a row in the same field list.
 *
 * The writer is registered the same way the dialog controller is (capture the previous,
 * restore on cleanup), so the form's local values are the single source of truth. A
 * signal-driven field list would need the whole `For` to be rebuilt to move a value
 * into an input, and the input's own text is the reactive path that typing already
 * uses; writing through the same path keeps the answer and the typed edits in one place.
 */

import { For, onCleanup, onMount } from '#solid'
import { createStore } from '#solid/store'
import type { FormFieldSpec } from '../protocol/kinds.ts'
import { DialogFooter, DialogHeader, DialogLayout, dialogColor, type DialogController, type DialogFooterAction, type DialogSpec, type DialogStore } from './dialog.tsx'

/** The active field's inputs take keyboard focus; the others paint unfocused. */
function fieldFocus(active: boolean): boolean {
  return active
}

export function DialogFields(props: { store: DialogStore; spec: DialogSpec }) {
  const store = props.store
  const spec = props.spec
  const fields = () => spec.fields ?? []
  const [state, setState] = createStore({
    active: 0,
    // Values are keyed by field key, not by position: a field list change keeps the
    // edits of the fields that did not move. Seeded from the spec so the row's painted
    // text and the collected value read the same reactive source.
    values: Object.fromEntries(fields().filter(field => field.value !== undefined).map(field => [field.key, field.value!])) as Record<string, string>,
  })

  const valueOf = (field: FormFieldSpec): string => state.values[field.key] ?? field.value

  function collect(): Record<string, string> {
    const out: Record<string, string> = {}
    fields().forEach(field => {
      out[field.key] = valueOf(field)
    })
    return out
  }

  function submit(): void {
    const field = fields()[state.active]
    if (field !== undefined && field.kind === 'action') {
      // An action row sends the current values upstream and leaves the form open; the
      // host answers with the merged line. It is not a form submission.
      spec.onAction?.(field.key, collect())
      return
    }
    store.closeTopDialog(JSON.stringify(collect()))
  }

  const controller: DialogController = {
    // `up`/`down` move between fields; `left`/`right` cycle a select field's value.
    move: direction => {
      const count = fields().length
      if (count === 0) return
      const next = Math.min(count - 1, Math.max(0, state.active + (direction > 0 ? 1 : -1)))
      setState('active', next)
    },
    moveTo: () => undefined,
    moveSection: () => undefined,
    moveColumn: direction => {
      const field = fields()[state.active]
      if (field === undefined || field.kind !== 'select') return
      const options = field.options ?? []
      if (options.length === 0) return
      const current = valueOf(field)
      const index = options.indexOf(current)
      const next = options[(index + (direction > 0 ? 1 : -1) + options.length) % options.length]
      setState('values', field.key, next ?? '')
    },
    submit,
    count: () => fields().length,
  }

  // The top dialog owns the modal keys and the field writer; closing restores the
  // dialog underneath it.
  onMount(() => {
    const previous = store.dialogController()
    const previousWriter = store.formFieldWriter()
    store.setDialogController(controller)
    store.setFormFieldWriter((key, value) => setState('values', key, value))
    onCleanup(() => {
      store.setDialogController(previous)
      store.setFormFieldWriter(previousWriter)
    })
  })

  const actions: DialogFooterAction[] = [
    { title: 'save', key: 'enter', onTrigger: submit },
    { title: 'cancel', key: 'esc', side: 'right', onTrigger: () => store.closeTopDialog(undefined) },
  ]

  return (
    <DialogLayout
      store={store}
      header={<DialogHeader store={store} title={spec.title} onClose={() => store.closeTopDialog(undefined)} />}
      footer={<DialogFooter store={store} actions={actions} />}
    >
      <box flexDirection="column" gap={1}>
        <For each={fields()}>
          {(field, index) => {
            const active = () => state.active === index()
            const value = () => valueOf(field)
            // A secret field shows its real text only while it is the active field;
            // the rest of the form sees a masked text row, so the API key never
            // sits in the scrollback of a wide panel and the real value stays in
            // the form's state (the input is not driven by the masked display).
            const masked = () => '\u2022'.repeat(value().length)
            let buffer: { plainText: string } | undefined
            return (
              <box flexDirection={field.multiline === true ? 'column' : 'row'} gap={1} width="100%" overflow="hidden">
                <text
                  fg={active() ? dialogColor(store, 'text.action.primary.$focused', '#cdd6f4') : dialogColor(store, 'text.muted', '#7f849c')}
                  content={field.label}
                  flexShrink={0}
                />
                {field.kind === 'action' ? (
                  <text
                    fg={active() ? dialogColor(store, 'text.action.primary.$focused', '#cdd6f4') : dialogColor(store, 'text.muted', '#7f849c')}
                    content={`[ ${value()} ]`}
                  />
                ) : field.kind === 'select' ? (
                  <text
                    fg={active() ? dialogColor(store, 'text.base', '#cdd6f4') : dialogColor(store, 'text.muted', '#7f849c')}
                    content={`< ${value()} >`}
                  />
                ) : field.multiline === true ? (
                  <textarea
                    ref={(r: { plainText: string } | null | undefined) => { buffer = r ?? undefined }}
                    width="100%"
                    height={Math.min(6, Math.max(1, value().split('\n').length))}
                    initialValue={value()}
                    focused={active()}
                    textColor={dialogColor(store, 'text.formfield.base', '#cdd6f4')}
                    focusedTextColor={dialogColor(store, 'text.action.primary.$focused', '#cdd6f4')}
                    focusedBackgroundColor={dialogColor(store, 'background.formfield.base', '#181825')}
                    onContentChange={() => {
                      if (buffer !== undefined) setState('values', field.key, buffer.plainText)
                    }}
                  />
                ) : field.kind === 'secret' && !active() ? (
                  <text
                    fg={dialogColor(store, 'text.base', '#cdd6f4')}
                    content={masked()}
                  />
                ) : (
                  <input
                    width="100%"
                    flexGrow={1}
                    value={value()}
                    focused={fieldFocus(active())}
                    textColor={dialogColor(store, 'text.formfield.base', '#cdd6f4')}
                    focusedTextColor={dialogColor(store, 'text.action.primary.$focused', '#cdd6f4')}
                    focusedBackgroundColor={dialogColor(store, 'background.formfield.base', '#181825')}
                    onInput={text => setState('values', field.key, text)}
                  />
                )}
              </box>
            )
          }}
        </For>
      </box>
    </DialogLayout>
  )
}
