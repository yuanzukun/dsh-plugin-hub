/**
 * The composer's completion popup.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, dev, `packages/tui/src/component/prompt/autocomplete.tsx`), MIT.
 * Registered in NOTICE.md under the `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * The popup is absolutely positioned above the prompt's top edge, so it never changes the
 * prompt's height and never pushes the footer down: the 0.5.0 shell painted slash and `@`
 * completions as rows inside the main column, which moved the composer on every keystroke.
 * The popup grows upward from the prompt anchor, is as wide as the prompt, and shows at most
 * ten rows.
 */

import { createMemo, For } from '#solid'
import { useTerminalDimensions } from '@opentui/solid'
import { argumentSuggestions, commandSuggestions, mentionLines, type CompletionCatalogs } from './completions.ts'
import { SPLIT_BORDER } from './border.ts'
import { PROMPT_CHROME_ROWS } from './layout.ts'
import { displayWidth, truncate } from './text.ts'

/** One row the popup shows: a slash command or a `@` path. */
export interface CompletionRow {
  readonly kind: 'command' | 'argument' | 'reference'
  readonly label: string
  readonly detail: string
  /** The command name without the leading `/`; only on `kind === 'command'`. */
  readonly name?: string
  /** The command declared an `argumentHint`, so accepting it inserts `/<name> `
   * instead of running it. Upstream's `slash.arguments ? insertSlash : command.run`. */
  readonly takesArguments?: boolean
}

/** The rows the composer is completing: slash commands when the draft starts with `/`,
 * `@` paths when the caret sits inside a mention token. */
export function completionRows(
  commands: readonly { name: string; description: string; argumentHint?: string }[],
  mentions: readonly string[],
  composer: string,
  catalogs: CompletionCatalogs,
): CompletionRow[] {
  const commands_ = commandSuggestions(commands, composer).map(command => ({
    kind: 'command' as const,
    // No trailing space: the accept path decides between running the command and
    // inserting the space, so the label has to be exactly the command line.
    label: `/${command.name}`,
    detail: command.description,
    name: command.name,
    takesArguments: command.argumentHint !== undefined,
  }))
  // A slash command whose argument slot is being typed completes its values from the
  // catalogs the host already pushed: `/think hi` offers `high`, `/permission wo` offers
  // `workspace-write`. The row replaces the argument token, not the whole draft.
  const arguments_ = argumentSuggestions(catalogs, composer).map(row => ({
    kind: 'argument' as const,
    label: row.value,
    detail: row.detail,
  }))
  const mentionRows = mentionLines(mentions, composer).map(path => ({
    kind: 'reference' as const,
    label: path,
    detail: '',
  }))
  return [...commands_, ...arguments_, ...mentionRows]
}

/** The slice of the app store the popup reads. */
export interface AutocompleteStore {
  commands: () => readonly { name: string; description: string; argumentHint?: string }[]
  /** The catalog, or the renderer's own command list when the host has not pushed one. */
  slashCommands?: () => readonly { name: string; description: string; argumentHint?: string }[]
  composer: () => string
  mentions: () => readonly string[]
  workspace: () => string
  /** The WeChat status row adds one row under the prompt panel. */
  wechatStatus: () => string
  /** A running turn adds its own `esc interrupt` row under the prompt panel. */
  turnRunning: () => boolean
  /** The catalogs a slash argument completes against (host state the store holds). */
  catalogs: () => CompletionCatalogs
  /** The highlighted row; a pick accepts it into the draft. */
  completionSelection: () => number
  setCompletionSelection: (index: number) => void
  acceptCompletion: (row: CompletionRow) => void
  /** `escape` closes the popup without touching the draft; the popup stays hidden
   * until the composer text changes again. */
  popupOpen: () => boolean
  /** One token's color by full path; the popup paints with the theme's chrome tokens. */
  color: (path: string) => string | undefined
  /** Host dictionary lookup for the popup's own words (the empty state, the row marker). */
  label: (key: string, fallback: string) => string
}

/** Where the popup hangs: the rows between the prompt panel's top edge and the terminal's
 * bottom edge, plus the panel's own horizontal band. The session route lets the popup infer
 * its anchor (the prompt is pinned to the bottom at the shell's padding); the home route
 * passes the centered panel's offset and its 75-cell measure. */
export interface PopupAnchor {
  readonly bottom: number
  readonly left: number
  readonly width: number
}

/** The rows the popup paints at once; the selection scrolls the window inside it. */
export const MAX_VISIBLE_ROWS = 10

/**
 * The right-aligned marker a row may carry.
 *
 * Upstream labels only the non-command rows (`reference`, `skill`, `agent`); a slash command
 * carries its own description instead. Printing the transport kind on every row (`command`,
 * `argument`) was the old oh-my-pi list, where the column existed for a different shape of
 * data — opencode's popup reads `label  description` and marks the odd row out.
 */
export function completionMarker(
  row: CompletionRow,
  label: (key: string, fallback: string) => string,
): string {
  return row.kind === 'reference' ? label('rendererKindReference', 'reference') : ''
}

/** The token a draft is completing, or `undefined` when nothing is being completed. */
function completionToken(composer: string): 'slash' | 'argument' | 'mention' | undefined {
  if (composer.startsWith('/') && !composer.includes('\n')) return 'slash'
  if (/(^|\s)@[^\s]*$/.test(composer)) return 'mention'
  if (/^\/[^\s]+\s+\S*$/.test(composer)) return 'argument'
  return undefined
}

/** The popup: split borders, one row per completion, the highlighted row tinted. */
export function AutocompletePopup(props: { store: AutocompleteStore; anchor?: PopupAnchor }) {
  const store = props.store
  // The popup is the prompt stack's last child, so it paints over the dock, the prompt, and the
  // transcript rows it covers. It hangs above the prompt panel: `bottom` counts the rows below the
  // panel (padding 2 + input 1 + metadata 1 + shadow lip 1 + footer 1, plus the WeChat status row
  // when it is present), so the popup's bottom edge lands on the panel's top edge.
  const rows = createMemo(() => completionRows((store.slashCommands ?? store.commands)(), store.mentions(), store.composer(), store.catalogs()))
  const height = createMemo(() => Math.min(MAX_VISIBLE_ROWS, Math.max(1, rows().length)))
  // A zero-match list stays open with the native empty state while an argument or mention
  // token is being typed: closing it would hide the fact that nothing matches. A slash
  // draft with no command match is not a popup at all.
  const visible = createMemo(() => store.popupOpen() && (rows().length > 0 || completionToken(store.composer()) !== undefined))
  /**
   * The window's first row: the selection is always inside the visible run, which is what
   * upstream's `reconcileSelectionWindow` does. Without it the marks jump to a row the
   * popup is not painting as soon as the list is longer than the window.
   */
  const windowStart = createMemo(() => {
    const count = rows().length
    if (count <= MAX_VISIBLE_ROWS) return 0
    const selected = store.completionSelection()
    return Math.max(0, Math.min(selected - MAX_VISIBLE_ROWS + 1, count - MAX_VISIBLE_ROWS))
  })
  const visibleRows = createMemo(() => rows().slice(windowStart(), windowStart() + MAX_VISIBLE_ROWS))
  const moreBelow = createMemo(() => Math.max(0, rows().length - windowStart() - MAX_VISIBLE_ROWS))
  // The prompt stack's height below the panel's top edge, when the route cannot pass a
  // measured anchor: the textarea's rows, the metadata row, and the shadow lip
  // (`PROMPT_CHROME_ROWS`), plus the interrupt row while a turn runs. The session route
  // passes the real anchor instead, so a growing draft or a dock cannot desynchronize this.
  const promptRows = createMemo(() => store.composer().split('\n').length)
  const bottom = createMemo(
    () => props.anchor?.bottom ?? promptRows() + PROMPT_CHROME_ROWS + (store.turnRunning() ? 1 : 0),
  )
  const dimensions = useTerminalDimensions()
  const pad = createMemo(() => (dimensions().width < 44 ? 1 : 2))
  const left = createMemo(() => props.anchor?.left ?? pad())
  const width = createMemo(() => props.anchor?.width ?? Math.max(1, dimensions().width - 2 * pad()))
  const ink = (path: string, fallback: string): string => store.color(path) ?? fallback
  /**
   * The one-line account of an empty list: the mode decides which catalogue came up empty,
   * the way upstream's `emptyMessage()` picks between commands and files.
   */
  const emptyMessage = (): string => completionToken(store.composer()) === 'slash'
    ? store.label('rendererNoMatchingCommands', 'No matching commands')
    : store.label('rendererNoMatchingReferences', 'No matching files, agents, or references')
  /** The label column: the popup's width minus its padding and the right marker. */
  const contentWidth = (row: CompletionRow): number => {
    const marker = completionMarker(row, store.label)
    return Math.max(1, width() - 4 - (marker === '' ? 0 : displayWidth(marker) + 2))
  }

  return (
    <box
      position="absolute"
      visible={visible()}
      left={left()}
      bottom={bottom()}
      width={width()}
      height={height()}
      zIndex={100}
      border={["left", "right"]}
      customBorderChars={SPLIT_BORDER}
      borderStyle="single"
      borderColor={store.color('border.base') ?? '#484848'}
      backgroundColor={store.color('background.raised.high') ?? '#313244'}
      flexDirection="column"
      overflow="hidden"
    >
      {rows().length === 0 ? (
        <box paddingLeft={1} paddingRight={1}>
          <text fg={store.color('text.muted') ?? '#565f89'} content={emptyMessage()} />
        </box>
      ) : (
        <For each={visibleRows()}>
          {(row, index) => {
            const selected = (): boolean => store.completionSelection() === index()
            const marker = (): string => completionMarker(row, store.label)
            return (
              <box
                flexDirection="row"
                paddingLeft={1}
                paddingRight={1}
                backgroundColor={selected()
                  // The same tint the palette paints on its highlighted row, so the two menus
                  // read as one system.
                  ? ink('background.action.primary.$hovered', '#313244')
                  : ink('background.raised.high', '#313244')}
              >
                {/* Upstream's row: the label, then its description after a single space, then
                 * the marker pushed to the right edge. The highlighted row lifts the whole
                 * line to the action ink instead of tinting only the label. */}
                <text
                  fg={selected() ? ink('text.action.primary.$focused', '#cdd6f4') : ink('text.base', '#cdd6f4')}
                  content={truncate(row.label, contentWidth(row))}
                  wrapMode="none"
                  flexShrink={0}
                />
                {row.detail === '' ? null : (
                  <text
                    fg={selected() ? ink('text.action.primary.$focused', '#cdd6f4') : ink('text.muted', '#565f89')}
                    content={` ${row.detail}`}
                    wrapMode="none"
                    flexShrink={1}
                    minWidth={0}
                  />
                )}
                {marker() === '' ? null : (
                  <>
                    <box flexGrow={1} minWidth={2} />
                    <text
                      flexShrink={0}
                      fg={selected() ? ink('text.action.primary.$focused', '#cdd6f4') : ink('text.muted', '#565f89')}
                      content={marker()}
                      wrapMode="none"
                    />
                  </>
                )}
              </box>
            )
          }}
        </For>
      )}
    </box>
  )
}
