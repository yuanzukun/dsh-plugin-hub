/**
 * Text truncation for dialog rows, rail titles, and the prompt footer.
 *
 * Replaces opencode's `Locale.truncate` (`packages/tui/src/util/locale.ts`): the renderer has
 * no locale table, so it measures display cells itself. OpenTUI paints East Asian characters at
 * two cells, and a cut by `String.length` (UTF-16 code units) miscounts every CJK label — a
 * 20-character Chinese title occupies 40 cells and silently runs past the terminal edge.
 * Written for this package, not ported.
 */

/** East Asian wide ranges, per Unicode East Asian Width. */
const WIDE_RANGES: Array<[number, number]> = [
  [0x1100, 0x115f], [0x2e80, 0x303e], [0x3041, 0x33ff], [0x3400, 0x4dbf],
  [0x4e00, 0x9fff], [0xa000, 0xa4cf], [0xac00, 0xd7a3], [0xf900, 0xff60],
  [0xffe0, 0xffe6], [0x1f300, 0x1f64f], [0x1f680, 0x1f9ff], [0x20000, 0x2ffdf],
  [0x30000, 0x3124f],
]

/** Combining marks and format characters take no cell of their own. */
function isZeroWidth(code: number): boolean {
  return (code >= 0x0300 && code <= 0x036f) ||
    (code >= 0x1ab0 && code <= 0x1bff) ||
    (code >= 0x20d0 && code <= 0x20f0) ||
    (code >= 0xfe20 && code <= 0xfe2f) ||
    (code >= 0x200b && code <= 0x200f) ||
    code === 0xfeff
}

/** The painted cells one code point occupies: 2 for East Asian wide, 1 for the rest. */
function codePointCells(code: number): number {
  if (isZeroWidth(code)) return 0
  for (const [low, high] of WIDE_RANGES) {
    if (code >= low && code <= high) return 2
  }
  return 1
}

/** The display width of `text` in terminal cells. */
export function displayWidth(text: string): number {
  let cells = 0
  for (const char of text) cells += codePointCells(char.codePointAt(0) ?? 0)
  return cells
}

/** The leading `cells` display cells of `text`; a split wide character is dropped, not halved. */
function sliceHead(text: string, cells: number): string {
  let used = 0
  let out = ''
  for (const char of text) {
    const width = codePointCells(char.codePointAt(0) ?? 0)
    if (used + width > cells) break
    out += char
    used += width
  }
  return out
}

/** The trailing `cells` display cells of `text`. */
function sliceTail(text: string, cells: number): string {
  let used = 0
  const chars = [...text].reverse()
  let out = ''
  for (const char of chars) {
    const width = codePointCells(char.codePointAt(0) ?? 0)
    if (used + width > cells) break
    out = char + out
    used += width
  }
  return out
}

/** Cut `text` to `width` cells, keeping the head. */
export function truncate(text: string, width: number): string {
  if (width <= 0) return ''
  if (displayWidth(text) <= width) return text
  return `${sliceHead(text, Math.max(1, width - 1))}…`
}

/** Cut `text` to `width` cells, keeping both ends. */
export function truncateMiddle(text: string, width: number): string {
  if (width <= 0) return ''
  if (displayWidth(text) <= width) return text
  const head = Math.ceil((width - 1) / 2)
  const tail = Math.floor((width - 1) / 2)
  return `${sliceHead(text, head)}…${tail > 0 ? sliceTail(text, tail) : ''}`
}

/** Cut `text` to `width` cells, keeping the tail (paths whose end matters). */
export function truncateLeft(text: string, width: number): string {
  if (width <= 0) return ''
  if (displayWidth(text) <= width) return text
  return `…${sliceTail(text, Math.max(1, width - 1))}`
}

/** Show the most specific path component that fits, preferring its tail when even that is long. */
export function truncateDirectory(path: string, width: number): string {
  if (width <= 0 || path === '') return ''
  if (displayWidth(path) <= width) return path
  const directory = path.split(/[\\/]/).filter(Boolean).at(-1) ?? path
  if (path.startsWith('~/') && width >= 5) {
    const anchored = `~/${directory}`
    if (displayWidth(anchored) <= width) return anchored
    return `~/${truncateLeft(directory, width - 2)}`
  }
  if (displayWidth(directory) <= width) return directory
  if (width <= 3) return truncateLeft(directory, width)
  return `...${sliceTail(directory, width - 3)}`
}

/** Token counts the same way the host's footer formats them: `1.2k`, `1.0M`, plain. */
export function formatTokens(count: number): string {
  if (count >= 1_000_000) return `${(count / 1_000_000).toFixed(1)}M`
  if (count >= 1_000) return `${(count / 1_000).toFixed(1)}k`
  return String(count)
}

/** Cut `text` to `width` cells, keeping the head and ending with the ASCII `...` marker.
 * Unlike {@link truncate}, this never uses the single-cell ellipsis: tool previews need a
 * predictable three-character suffix, and a wide character is dropped rather than split. */
export function truncateEnd(text: string, width: number): string {
  if (width <= 0) return ''
  if (displayWidth(text) <= width) return text
  if (width <= 3) return sliceHead(text, width)
  return `${sliceHead(text, width - 3)}...`
}

/** Collapse every whitespace run to one space; used before a tool detail becomes one line. */
export function flattenWhitespace(text: string): string {
  return text.replace(/\s+/g, ' ').trim()
}

/**
 * Wrap text to at most `width` display cells per line.
 *
 * Spaces are preferred break points, but CJK may break between any two cells. Empty input
 * returns one empty line so callers can keep paragraph spacing; a trailing split wide
 * character is never emitted half-width.
 */
export function wrapCells(text: string, width: number): string[] {
  if (width <= 0) return text === '' ? [''] : [text]
  const out: string[] = []
  for (const paragraph of text.split('\n')) {
    if (paragraph === '') {
      out.push('')
      continue
    }
    let line = ''
    let used = 0
    let lastSpace = -1
    for (const char of paragraph) {
      const cells = codePointCells(char.codePointAt(0) ?? 0)
      if (used + cells > width && line !== '') {
        if (lastSpace >= 0) {
          const head = line.slice(0, lastSpace).trimEnd()
          const tail = line.slice(lastSpace + 1)
          out.push(head)
          line = tail
          used = displayWidth(line)
          lastSpace = line.lastIndexOf(' ')
        } else {
          out.push(line)
          line = ''
          used = 0
          lastSpace = -1
        }
      }
      if (cells > width) continue
      line += char
      used += cells
      if (char === ' ') lastSpace = line.length - 1
    }
    out.push(line.trimEnd())
  }
  return out.length === 0 ? [''] : out
}

/**
 * Strip lightweight Markdown decoration for the compact thinking preview.
 *
 * This is deliberately not a parser: the expanded view still uses the real Markdown
 * renderable. Fence delimiters are removed but their code lines survive, list/heading
 * prefixes are dropped, and inline emphasis/code markers are concealed.
 */
export function previewText(markdown: string): string {
  return markdown
    .split('\n')
    .filter(line => !/^\s*(```|~~~)/.test(line))
    .map(line => line
      .replace(/^\s{0,3}#{1,6}\s+/, '')
      .replace(/^\s*>\s?/, '')
      .replace(/^\s*(?:[-*+]|\d+[.)])\s+/, '')
      .replace(/!\[([^\]]*)\]\([^)]*\)/g, '$1')
      .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/__([^_]+)__/g, '$1')
      .replace(/~~([^~]+)~~/g, '$1')
      .replace(/`([^`]+)`/g, '$1')
      .trimEnd())
    .join('\n')
}

/**
 * OpenTUI 0.5.17 conceals `**strong**` in paragraphs but not in list-item inline content.
 * The upgrade that fixes it (0.6.6) requires a renderer-owned SyntaxStyle and is not
 * compatible with the fallback path, so this is the documented, narrow fallback: remove
 * strong delimiters only inside list items/continuations. Paragraph strong, fenced code,
 * and inline code are untouched.
 */
export function normalizeListStrong(markdown: string): string {
  const out: string[] = []
  let listIndent: number | undefined
  let fenced: string | undefined
  for (const line of markdown.split('\n')) {
    const fence = /^\s*(```+|~~~+)/.exec(line)?.[1]
    if (fenced !== undefined) {
      out.push(line)
      if (fence !== undefined && fence[0] === fenced[0] && fence.length >= fenced.length) fenced = undefined
      continue
    }
    if (fence !== undefined) {
      fenced = fence
      out.push(line)
      continue
    }
    const indent = line.length - line.trimStart().length
    const list = /^(\s*)(?:[-*+]|\d+[.)])\s+/.exec(line)
    if (list !== null) {
      listIndent = (list[1] ?? '').length
    } else if (line.trim() === '') {
      // A blank line does not close an indented continuation by itself; a following
      // unindented line does. Keep the current indent until that line arrives.
    } else if (listIndent === undefined || indent <= listIndent) {
      listIndent = undefined
    }
    if (listIndent === undefined) {
      out.push(line)
      continue
    }
    // Preserve inline code verbatim while stripping strong delimiters from prose runs.
    out.push(line.split(/(`[^`]*`)/g).map((part, index) =>
      index % 2 === 1 ? part : part.replace(/\*\*/g, '').replace(/__/g, ''))
      .join(''))
  }
  return out.join('\n')
}
