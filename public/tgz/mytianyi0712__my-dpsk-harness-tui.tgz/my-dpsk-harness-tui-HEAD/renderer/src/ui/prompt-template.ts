/**
 * Prompt footer templates.
 *
 * Ported vocabulary from opencode v2 (`anomalyco/opencode`, dev,
 * `packages/tui/src/component/prompt/index.tsx` footer slots), MIT; registered in
 * NOTICE.md. SPDX-License-Identifier: MIT
 *
 * dsh has always carried `leftPrompt` / `rightPrompt` settings (the pi-tui composer footer
 * rendered them). The renderer owns the TTY now, so the same two strings drive the
 * renderer's footer: `${name}` tokens resolve against state the host already pushed
 * (`workspace`, `git-branch`, `model-catalog`, `usage`, `subagent-list`, the snapshot
 * route). A token with no value renders as nothing — a missing git branch must not paint a
 * dangling separator, and an unknown token must not print its own name.
 *
 * The slots resolve to bare values: separators belong to the template, so an edited
 * template reads as the text it renders. A literal between two slots binds to the slot
 * that follows it, which is how a dropped slot takes its own ` · ` with it instead of
 * leaving a dangling separator.
 */

/** One segment of a parsed template: literal text or a `${name}` slot. */
export type PromptTemplateToken =
  | { readonly type: 'text'; readonly text: string }
  | { readonly type: 'value'; readonly name: string }

/** Parse a template. An unterminated or empty `${` stays literal, as it always has. */
export function parsePromptTemplate(template: string): PromptTemplateToken[] {
  const tokens: PromptTemplateToken[] = []
  let rest = template
  while (rest.length > 0) {
    const start = rest.indexOf('${')
    if (start < 0) {
      tokens.push({ type: 'text', text: rest })
      break
    }
    if (start > 0) tokens.push({ type: 'text', text: rest.slice(0, start) })
    const end = rest.indexOf('}', start)
    if (end < 0) {
      tokens.push({ type: 'text', text: rest.slice(start) })
      break
    }
    const name = rest.slice(start + 2, end)
    if (name === '') {
      tokens.push({ type: 'text', text: '${}' })
      rest = rest.slice(end + 1)
      continue
    }
    tokens.push({ type: 'value', name })
    rest = rest.slice(end + 1)
  }
  return tokens
}

/** Render a template through a value resolver.
 *
 * Built on the segment splitter, so the string and the painted groups agree: a slot with no
 * value takes the literal that introduced it with it, and an unknown name renders as
 * nothing rather than printing itself.
 */
export function renderPromptTemplate(
  template: string,
  resolve: (name: string) => string | undefined,
): string {
  return promptTemplateSegments(template, resolve).map(segment => segment.text).join('')
}

/** The state the footer templates read. Every field is a signal the store already holds. */
export interface PromptTemplateState {
  readonly workspace: string
  readonly branch: string | undefined
  readonly provider: string
  readonly model: string
  readonly effort: string
  readonly permission: string
  readonly mode: string
  readonly context: string | undefined
  readonly queued: number
  readonly subagents: number
  readonly running: boolean
  /** The localized `esc interrupt` label; the template's `${indicator}` slot. */
  readonly runningLabel: string
}

/**
 * The slot table. It covers dsh's own built-ins (`cwd`, `git/worktree`, `model`, `effort`,
 * `context`, `queued`) plus the route slots the renderer can name (`provider`,
 * `permission`, `mode`) and the running flag (`indicator`, `esc`).
 *
 * `queued` is the interjection queue depth — the meaning dsh gave it — and `subagents` is
 * the child agent count. Both render only when non-zero so the default right template does
 * not paint `0` at the end of every idle footer.
 */
export function promptTemplateResolver(state: PromptTemplateState): (name: string) => string | undefined {
  const repository = state.workspace.split(/[\\/]/).filter(part => part !== '').pop() ?? state.workspace
  const worktree = state.branch === undefined ? repository : `${repository}:${state.branch}`
  const route = state.model === '' ? undefined : `${state.provider === '' ? '' : `${state.provider}/`}${state.model}`
  return name => {
    switch (name) {
      case 'location':
        // The shipped left template: the workspace path, or `repo:branch` once a branch is
        // known. `${cwd}` and `${git/worktree}` are the explicit forms.
        return state.branch === undefined ? state.workspace : worktree
      case 'cwd':
      case 'directory':
        return state.workspace
      case 'git/worktree':
      case 'git':
        return worktree
      case 'provider':
        return state.provider === '' ? undefined : state.provider
      case 'model':
        return route
      case 'effort':
        return state.effort === '' ? undefined : state.effort
      case 'permission':
        return state.permission === '' ? undefined : state.permission
      case 'mode':
        return state.mode === '' ? undefined : state.mode
      case 'context':
        return state.context
      case 'queued':
        return state.queued === 0 ? undefined : `${state.queued} queued`
      case 'subagents':
        return state.subagents === 0 ? undefined : `${state.subagents} sub`
      case 'indicator':
      case 'esc':
        return state.running ? state.runningLabel : undefined
      default:
        return undefined
    }
  }
}

/** One painted footer segment: the text and the theme token that colors it. */
export interface TemplateSegment {
  readonly text: string
  /** A token path the caller resolves; `undefined` paints with the footer's base color. */
  readonly color?: string
  /** The slot this segment came from (`undefined` for literal-only text). The footer's
   * width rules drop slots by name, so the segment has to carry it. */
  readonly slot?: string
}

/** The token that colors one value slot, in the footer's visual language. */
const SLOT_COLORS: Record<string, string> = {
  provider: 'text.action.primary.base',
  model: 'text.base',
  effort: 'text.feedback.warning.base',
  permission: 'text.action.primary.base',
  mode: 'text.muted',
  context: 'text.context.base',
  queued: 'text.feedback.warning.base',
  subagents: 'text.muted',
  indicator: 'text.feedback.warning.base',
  esc: 'text.feedback.warning.base',
  'git/worktree': 'text.muted',
  git: 'text.muted',
  location: 'text.muted',
  cwd: 'text.muted',
  directory: 'text.muted',
}

/**
 * Split a rendered template into paintable segments, one per value slot. The segments
 * exist so the footer can drop a whole slot when it does not fit (opencode's rule) instead
 * of truncating the last one mid-word; literal text binds to the segment that follows it.
 */
export function promptTemplateSegments(
  template: string,
  resolve: (name: string) => string | undefined,
): TemplateSegment[] {
  const segments: TemplateSegment[] = []
  let pending = ''
  for (const token of parsePromptTemplate(template)) {
    if (token.type === 'text') {
      pending += token.text
      continue
    }
    const value = resolve(token.name)
    const color = SLOT_COLORS[token.name]
    if (value === undefined || value === '') {
      // A missing slot takes its separator with it, never the text before it: `a${x}b` keeps
      // `a` and `b` when `x` is unknown, while ` · ${x}` drops the ` · ` written for `x`.
      const separator = /^[\s·|/-]*$/.test(pending)
      pending = separator ? '' : pending
      continue
    }
    segments.push({ text: `${pending}${value}`, ...(color === undefined ? {} : { color }), slot: token.name })
    pending = ''
  }
  if (pending !== '') segments.push({ text: pending })
  return segments
}
