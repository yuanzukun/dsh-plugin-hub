/**
 * One shared one-second clock for live thinking headers.
 *
 * A timer per transcript block would wake a long session hundreds of times per second as
 * soon as each block's header is rendered. This clock starts only when at least one caller
 * is active, and stops at the last unsubscribe. Each subscriber owns a local signal, so a
 * tick repaints only the header text that reads it, not the whole shell.
 */

import { createEffect, createSignal, onCleanup } from '#solid'

export const CLOCK_INTERVAL_MS = 1000

type Listener = (now: number) => void
const listeners = new Set<Listener>()
let timer: ReturnType<typeof setInterval> | undefined

function subscribe(listener: Listener): () => void {
  listeners.add(listener)
  if (listeners.size === 1) {
    timer = setInterval(() => {
      const now = Date.now()
      for (const current of listeners) current(now)
    }, CLOCK_INTERVAL_MS)
  }
  return () => {
    listeners.delete(listener)
    if (listeners.size === 0 && timer !== undefined) {
      clearInterval(timer)
      timer = undefined
    }
  }
}

/** Wall-clock milliseconds, ticking once per second while `active()` is true. */
export function useNowMs(active: () => boolean): () => number {
  const [now, setNow] = createSignal(Date.now())
  createEffect(() => {
    if (!active()) return
    setNow(Date.now())
    const off = subscribe(setNow)
    onCleanup(off)
  })
  return now
}

/** Test seam: true while the shared timer is armed. */
export function clockActive(): boolean {
  return timer !== undefined
}
