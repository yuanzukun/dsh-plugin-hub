import { expect, test } from 'bun:test'
import { buildTraceRows } from './trace-model.ts'
import type { TranscriptEvent } from '../protocol/kinds.ts'

const labels = {
  user: 'user',
  assistant: 'assistant',
  tool: 'tool',
  system: 'system',
  seq: 'seq',
  turn: 'turn',
  step: 'step',
  status: 'status',
}

test('the trace model keeps every interaction and its full payload', () => {
  const events: TranscriptEvent[] = [
    { id: 'u1', role: 'user', text: 'fix the bug', createdAt: 1_000, turn: 1, sourceSeq: 7 },
    { id: 'a1', role: 'assistant', text: 'done', reasoning: 'checked files', createdAt: 2_000, durationMs: 1500, turn: 1, step: 2, model: 'mimo' },
    { id: 't1', role: 'tool', tool: 'bash', toolInput: { command: 'pnpm test' }, toolOutput: ['ok', 'one warning'], status: 'ok', callId: 'call-1', createdAt: 3_000 },
  ]
  const rows = buildTraceRows(events, labels)
  expect(rows).toHaveLength(3)
  expect(rows[0]?.details).toContain('text: fix the bug')
  expect(rows[1]?.details).toContain('reasoning: checked files')
  expect(rows[1]?.details).toContain('model mimo')
  expect(rows[2]?.details).toContain('call call-1')
  expect(rows[2]?.details.join('\\n')).toContain('pnpm test')
  expect(rows[2]?.details.join('\\n')).toContain('one warning')
})

test('the trace model has no 24-row ceiling', () => {
  const events: TranscriptEvent[] = Array.from({ length: 60 }, (_, index) => ({ id: 'e' + String(index), role: 'user', text: 'row ' + String(index) }))
  expect(buildTraceRows(events, labels)).toHaveLength(60)
})


