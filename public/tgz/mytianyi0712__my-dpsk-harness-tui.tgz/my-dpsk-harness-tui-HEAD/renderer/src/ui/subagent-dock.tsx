/**
 * The subagent dock: the live subagents a turn has spawned, as a card above the prompt.
 *
 * Derived from opencode v2 (`anomalyco/opencode`, 2.0.32,
 * `packages/tui/src/routes/session/composer/subagents-tab.tsx`), MIT. Registered in
 * NOTICE.md under the `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications:
 * - Upstream's composer is a tabbed drawer (subagents / history / queued); dsh only has the
 *   subagent list to show here, because history is the composer's own `up`/`down` recall and
 *   the queue is a one-line dock (`queued-dock.tsx`). The tabs, the `esc` hint, and the
 *   `alt+left/right` switch are gone with them.
 * - The card shape is the user message card: a `┃` gutter, the raised background, and 2
 *   cells of inner padding, so the dock reads as part of the composer stack.
 */

import { For } from '#solid'
import { SPLIT_BORDER } from './border.ts'
import { truncate } from './text.ts'

interface SubagentDockProps {
  readonly subagents: readonly { label: string; provider: string; mode: string }[]
  readonly width: number
  /** The card's gutter and title color. */
  readonly fgTitle: string
  readonly fgBase: string
  readonly fgMuted: string
  /** The raised panel the card paints on. */
  readonly bgBase: string
  readonly labelTitle: string
}

/** The dock: the title row, then one `↳` row per subagent. */
export function SubagentDock(props: SubagentDockProps) {
  const cells = () => Math.max(1, props.width - 4)
  return (
    <box
      flexShrink={0}
      width="100%"
      border={['left']}
      borderStyle="single"
      borderColor={props.fgTitle}
      customBorderChars={SPLIT_BORDER}
      backgroundColor={props.bgBase}
      paddingLeft={2}
      paddingRight={1}
      paddingTop={1}
      paddingBottom={1}
      flexDirection="column"
      gap={0}
      overflow="hidden"
    >
      <text fg={props.fgTitle} content={props.labelTitle} flexShrink={0} />
      <For each={props.subagents}>
        {agent => (
          <text
            fg={props.fgBase}
            content={truncate(`↳ ${agent.label} · ${agent.provider} · ${agent.mode}`, cells())}
            wrapMode="none"
            flexShrink={0}
          />
        )}
      </For>
    </box>
  )
}
