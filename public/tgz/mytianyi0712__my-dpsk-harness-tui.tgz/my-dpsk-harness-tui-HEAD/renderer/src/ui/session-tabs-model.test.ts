import { describe, expect, test } from 'bun:test'
import {
  DRAFT_TAB_ID,
  closeOtherTabs,
  closeTab,
  cycleTabId,
  decodeTabs,
  emptyTabsState,
  encodeTabs,
  moveTab,
  moveTabTo,
  openTab,
  promoteDraft,
  pruneTabs,
  reopenLastTab,
} from './session-tabs-model.ts'

function tabs(...ids: string[]) {
  let state = emptyTabsState()
  for (const id of ids) state = openTab(state, id, `${id} title`)
  return state
}

describe('session tabs model', () => {
  test('open is order-stable, deduplicated, and keeps the latest title', () => {
    const state = openTab(openTab(emptyTabsState(), 'a', 'A'), 'b', 'B')
    expect(openTab(state, 'a', 'A renamed').open).toEqual(['a', 'b'])
    expect(openTab(state, 'a', 'A renamed').titles.a).toBe('A renamed')
  })

  test('close records the index and picks the right neighbour, then the left', () => {
    const first = closeTab(tabs('a', 'b', 'c'), 'b')
    expect(first.state.open).toEqual(['a', 'c'])
    expect(first.fallbackId).toBe('c')
    expect(first.state.closed.at(-1)).toMatchObject({ id: 'b', index: 1, title: 'b title' })
    expect(closeTab(tabs('a'), 'a').fallbackId).toBeUndefined()
  })

  test('close others and move preserve the manually chosen order', () => {
    const moved = moveTab(tabs('a', 'b', 'c'), 'c', -1)
    expect(moved.open).toEqual(['a', 'c', 'b'])
    expect(moveTabTo(moved, 'b', 0).open).toEqual(['b', 'a', 'c'])
    expect(closeOtherTabs(moved, 'c').open).toEqual(['c'])
  })

  test('reopen restores the original index and skips ids already open', () => {
    const closed = closeTab(tabs('a', 'b', 'c'), 'b').state
    const reopened = reopenLastTab(closed)
    expect(reopened.reopenedId).toBe('b')
    expect(reopened.state.open).toEqual(['a', 'b', 'c'])
  })

  test('a draft is unique, ephemeral, and promoted in place', () => {
    let state = openTab(openTab(tabs('a', 'c'), DRAFT_TAB_ID, 'New Session'), DRAFT_TAB_ID, 'New Session')
    expect(state.open).toEqual(['a', 'c', DRAFT_TAB_ID])
    state = promoteDraft(state, 'b', 'B')
    expect(state.open).toEqual(['a', 'c', 'b'])
    expect(state.titles.b).toBe('B')
    expect(encodeTabs(state).tabs.map(tab => tab.id)).toEqual(['a', 'c', 'b'])
    expect(encodeTabs(state).tabs.some(tab => tab.id === DRAFT_TAB_ID)).toBe(false)
  })

  test('catalog pruning keeps the active and draft tabs but drops dead reopens', () => {
    const state = { ...tabs('a', 'b'), closed: [{ id: 'gone', index: 2 }] }
    expect(pruneTabs(state, new Set(['a']), 'b').open).toEqual(['a', 'b'])
    expect(pruneTabs(state, new Set(['a']), 'b').closed).toEqual([])
  })

  test('cycle wraps and handles a current id outside the strip', () => {
    expect(cycleTabId(tabs('a', 'b', 'c'), 'c', 1)).toBe('a')
    expect(cycleTabId(tabs('a', 'b', 'c'), 'a', -1)).toBe('c')
    expect(cycleTabId(tabs('a', 'b'), 'outside', 1)).toBe('a')
  })

  test('decodes legacy tabs and v2 title snapshots while dropping the draft', () => {
    const legacy = decodeTabs({ open: ['a', DRAFT_TAB_ID, 'a'], closed: [{ id: 'b', index: 0 }] })
    expect(legacy.open).toEqual(['a'])
    expect(legacy.closed).toEqual([{ id: 'b', index: 0 }])
    const v2 = decodeTabs({ version: 2, tabs: [{ id: 'a', title: 'Alpha' }, { id: DRAFT_TAB_ID, title: 'New' }], closed: [] })
    expect(v2).toEqual({ open: ['a'], closed: [], titles: { a: 'Alpha' } })
  })
})
