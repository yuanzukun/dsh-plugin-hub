/**
 * Streaming invariants for the session flow.
 *
 * These tests pin the two things a streamed answer must never do:
 *
 * 1. replace the row object the transcript holds, which makes `<For>` tear the row down
 *    and rebuild its `<markdown>` renderable for every delta (the visible flicker);
 * 2. append a second assistant row when the durable `assistant/message` settles the
 *    streamed one.
 *
 * The Markdown tests read the painted grid, because "correct Markdown" is only true if the
 * native renderable actually parsed it: a bold summary, a list, and a fenced block all have
 * to reach the screen with their markers concealed.
 */

import { expect, test } from 'bun:test'
import { testRender } from '@opentui/solid'
import { Shell, createAppStore, type AppStore } from '../app.tsx'
import type { TranscriptEvent } from '../protocol/kinds.ts'
import { isolateShellStore } from '../test-harness.tsx'

function sessionStore(events: readonly TranscriptEvent[]): AppStore {
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'session',
      title: 'first prompt',
      events,
      provider: 'cliproxy',
      model: 'mimo-v2.6-pro',
      effort: 'high',
      permission: 'auto',
      preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  return store
}

async function paint(store: AppStore, width = 100, height = 30) {
  isolateShellStore(store)
  const view = await testRender(() => <Shell store={store} />, { width, height })
  await view.renderOnce()
  for (let pass = 0; pass < 8; pass++) {
    await Bun.sleep(30)
    view.renderer.requestRender?.()
  }
  return { ...view, store }
}

/** A frame that updates one row, the shape the host sends for each stream delta. */
function frame(seq: number, events: readonly TranscriptEvent[]) {
  return { protocolVersion: 2, seq, kind: 'session-frame', payload: { sessionId: 'ses_1', events } }
}

test('a streamed answer keeps one row identity while every delta grows it', () => {
  const store = sessionStore([{ id: 's1', role: 'assistant', text: 'a', streaming: true }])
  const first = store.transcript()[0]
  // The sticky-bottom clamp keys off the revision, not the array proxy: an in-place field
  // update must bump it or a short transcript would stop re-settling on new text.
  let revision = store.transcriptRevision()
  for (let delta = 2; delta <= 60; delta++) {
    store.apply(frame(delta, [{ id: 's1', role: 'assistant', text: 'a'.repeat(delta), streaming: true }]) as never)
    expect(store.transcript()).toHaveLength(1)
    // The same row object: `reconcile` updates its fields in place, so the row's subtree
    // (and its Markdown renderable) is never re-created by the delta.
    expect(store.transcript()[0]).toBe(first)
    expect(store.transcriptRevision()).toBeGreaterThan(revision)
    revision = store.transcriptRevision()
  }
  expect(store.transcript()[0]?.text).toHaveLength(60)
})

test('the durable assistant event settles the streamed row instead of appending a second', () => {
  const store = sessionStore([{ id: 's1', role: 'assistant', text: 'partial', streaming: true }])
  store.apply(frame(2, [{ id: 's1', role: 'assistant', text: 'partial answer', streaming: true }]) as never)
  // The host re-keys the durable row to the streamed id, so this is the same row settling.
  store.apply(frame(3, [{ id: 's1', role: 'assistant', text: 'partial answer', model: 'mimo-v2.6-pro', durationMs: 1200, tokPerSec: 40 }]) as never)
  expect(store.transcript()).toHaveLength(1)
  expect(store.transcript()[0]?.text).toBe('partial answer')
  expect(store.transcript()[0]?.streaming).toBeUndefined()
  expect(store.transcript()[0]?.model).toBe('mimo-v2.6-pro')
})

test('a streaming answer paints its growing Markdown in place', async () => {
  const store = sessionStore([{ id: 's1', role: 'assistant', text: '## Head', streaming: true }])
  const view = await paint(store)
  expect(view.captureCharFrame()).toContain('Head')
  store.apply(frame(2, [{ id: 's1', role: 'assistant', text: '## Head\n\nSome **strong** text.', streaming: true }]) as never)
  await view.renderOnce()
  await Bun.sleep(60)
  const frameNow = view.captureCharFrame()
  expect(frameNow).toContain('Head')
  expect(frameNow).toContain('Some strong text.')
  expect(frameNow).not.toContain('**strong**')
  view.renderer.destroy()
})

test('reasoning paints through the same Markdown renderer as the answer', async () => {
  const store = sessionStore([
    {
      id: 'a1',
      role: 'assistant',
      text: 'the answer',
      reasoning: '**Checks**\n\nfirst step\n\n```ts\nconst x = 1\n```',
      durationMs: 800,
    },
  ])
  const view = await paint(store)
  const frameNow = view.captureCharFrame()
  // The summary stays the header (upstream joins the duration with `·`); the body is parsed
  // Markdown, so the `**` markers and the fence markers are concealed instead of printed.
  expect(frameNow).toContain('Thought: Checks · 0.8s')
  expect(frameNow).toContain('first step')
  expect(frameNow).toContain('const x = 1')
  expect(frameNow).not.toContain('**Checks**')
  expect(frameNow).not.toContain('```')
  view.renderer.destroy()
})

test('reasoning that starts before its text streams shows the Thinking spinner', async () => {
  const store = sessionStore([{ id: 's1', role: 'assistant', text: '', reasoning: '', streaming: true }])
  store.apply({ protocolVersion: 2, seq: 2, kind: 'settings', payload: { schemaVersion: 2, values: { animations: false } } })
  const view = await paint(store)
  // A still spinner is `⋯`: the row exists while the thought is empty, which the old
  // `if (reasoning === '') return null` made impossible.
  expect(view.captureCharFrame()).toContain('⋯')
  view.renderer.destroy()
})

test('a reasoning delta arriving later fills the same row', async () => {
  const store = sessionStore([{ id: 's1', role: 'assistant', text: '', reasoning: '', streaming: true }])
  const first = store.transcript()[0]
  store.apply(frame(2, [{ id: 's1', role: 'assistant', text: '', reasoning: '**Plan**\n\n- inspect the layout', streaming: true }]) as never)
  expect(store.transcript()).toHaveLength(1)
  expect(store.transcript()[0]).toBe(first)
  const view = await paint(store)
  const frameNow = view.captureCharFrame()
  // The thought is still arriving, so the header is upstream's live `Thinking`, not the
  // settled `Thought` header — the row used to flip on the first delta instead of at the end.
  expect(frameNow).toContain('Thinking: Plan')
  expect(frameNow).not.toContain('Thought')
  expect(frameNow).toContain('inspect the layout')
  view.renderer.destroy()
})

test('the first answer delta ends the thought: Thinking becomes Thought', async () => {
  const store = sessionStore([{ id: 's1', role: 'assistant', text: '', reasoning: '**Plan**\n\n- inspect the layout', streaming: true }])
  const view = await paint(store)
  expect(view.captureCharFrame()).toContain('Thinking: Plan')
  // `reasoningDone` is the stream's `end` of the reasoning part: the header settles to
  // `Thought` while the answer itself is still growing, exactly upstream's `isDone`.
  store.apply(frame(2, [{ id: 's1', role: 'assistant', text: 'the answer', reasoning: '**Plan**\n\n- inspect the layout', streaming: true, reasoningDone: true }]) as never)
  await view.renderOnce()
  await Bun.sleep(60)
  const frameNow = view.captureCharFrame()
  expect(frameNow).not.toContain('Thinking')
  expect(frameNow).toContain('Thought: Plan')
  expect(frameNow).toContain('the answer')
  view.renderer.destroy()
})

test('a settled row ignores a stale reasoningDone flag and keeps its duration', async () => {
  const store = sessionStore([
    {
      id: 'a1',
      role: 'assistant',
      text: 'the answer',
      reasoning: '**Checks**\n\nfirst step',
      durationMs: 800,
      reasoningDone: true,
    },
  ])
  const view = await paint(store)
  const frameNow = view.captureCharFrame()
  expect(frameNow).toContain('Thought: Checks · 0.8s')
  expect(frameNow).not.toContain('Thinking')
  view.renderer.destroy()
})

test('no delta paints a frame that loses the text already streamed', async () => {
  // The user-visible failure was a flash: the answer disappeared for a frame while the row
  // was rebuilt. This walks the grid after every delta and asserts the accumulated answer is
  // still on screen, which is the property the row-identity fix exists to protect.
  const store = sessionStore([{ id: 's1', role: 'assistant', text: '', streaming: true }])
  const view = await paint(store)
  const words = ['The', ' answer', ' arrives', ' one', ' word', ' at', ' a', ' time', '.']
  let text = ''
  for (const [index, word] of words.entries()) {
    text += word
    store.apply(frame(index + 2, [{ id: 's1', role: 'assistant', text, streaming: true }]) as never)
    await view.renderOnce()
    await Bun.sleep(40)
    expect(view.captureCharFrame()).toContain(text.trim())
    expect(store.transcript()).toHaveLength(1)
  }
  expect(view.store.transcript()[0]?.text).toBe('The answer arrives one word at a time.')
  expect(view.store.transcript()[0]?.streaming).toBe(true)
  view.renderer.destroy()
})

test('a settled answer with no reasoning paints no Thought header', async () => {
  // The streamed row starts empty, so the reasoning row must be decided reactively: an early
  // `return null` evaluated once survives the settle and leaves `Thought: 1.8s` over an
  // answer that never had a thought block.
  const store = sessionStore([{ id: 'u1', role: 'user', text: 'hello' }, { id: 's1', role: 'assistant', text: '', streaming: true }])
  store.apply(frame(2, [{ id: 's1', role: 'assistant', text: 'the answer', streaming: true }]) as never)
  store.apply(frame(3, [{ id: 's1', role: 'assistant', text: 'the answer', model: 'mimo-v2.6-pro', durationMs: 1800, tokPerSec: 42, footer: true }]) as never)
  const view = await paint(store)
  const frameNow = view.captureCharFrame()
  expect(frameNow).toContain('the answer')
  expect(frameNow).toContain('1.8s')
  expect(frameNow).not.toContain('Thought')
  view.renderer.destroy()
})

test('a stream that ends with reasoning keeps its Thought header and body', async () => {
  const store = sessionStore([{ id: 's1', role: 'assistant', text: '', reasoning: '**Plan**\n\ncheck the layout', streaming: true }])
  store.apply(frame(2, [{ id: 's1', role: 'assistant', text: 'the answer', reasoning: '**Plan**\n\ncheck the layout', streaming: true }]) as never)
  store.apply(frame(3, [{ id: 's1', role: 'assistant', text: 'the answer', reasoning: '**Plan**\n\ncheck the layout', durationMs: 900 }]) as never)
  const view = await paint(store)
  const frameNow = view.captureCharFrame()
  expect(frameNow).toContain('Thought: Plan · 0.9s')
  expect(frameNow).toContain('check the layout')
  expect(frameNow).toContain('the answer')
  view.renderer.destroy()
})
