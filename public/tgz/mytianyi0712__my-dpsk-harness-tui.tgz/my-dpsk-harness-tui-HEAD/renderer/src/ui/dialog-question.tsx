import { TextAttributes, type ScrollBoxRenderable } from '@opentui/core'
import { useTerminalDimensions } from '@opentui/solid'
import { For, onCleanup, onMount } from '#solid'
import { createStore } from '#solid/store'
import type { QuestionAnswerItem, QuestionSpec } from '../protocol/kinds.ts'
import { DIALOG_LIST_INSET, DialogFooter, DialogHeader, DialogLayout, dialogColor, type DialogController, type DialogSpec, type DialogStore } from './dialog.tsx'

export function DialogQuestion(props: { store: DialogStore; spec: DialogSpec; question: QuestionSpec }) {
  const { store, spec, question } = props
  const options = () => question.options ?? []
  const [state, setState] = createStore({ active: 0, selected: [] as string[], custom: '' })
  const dimensions = useTerminalDimensions()
  let scroll: ScrollBoxRenderable | undefined

  const answer = (): QuestionAnswerItem => ({
    id: question.id,
    selected: [...state.selected],
    ...(state.custom === '' ? {} : { custom: state.custom }),
  })
  const toggleSelected = (label: string): void => {
    const selected = state.selected.includes(label)
      ? state.selected.filter(value => value !== label)
      : [...state.selected, label]
    setState('selected', selected)
  }
  const submit = (): void => {
    if (options().length > 0 && question.multiSelect !== true) {
      const picked = options()[state.active]
      if (picked === undefined) return
      store.closeTopDialog(JSON.stringify({ ...answer(), selected: [picked.label] }))
      return
    }
    store.closeTopDialog(JSON.stringify(answer()))
  }
  const move = (delta: number): void => {
    const count = options().length
    if (count === 0) return
    const active = (state.active + delta + count) % count
    setState('active', active)
    const row = scroll?.getChildren()[active]
    if (row !== undefined && scroll !== undefined) {
      const top = row.y - scroll.y
      if (top < 0) scroll.scrollBy(top)
      else if (top >= scroll.height) scroll.scrollBy(top - scroll.height + 1)
    }
  }
  const controller: DialogController = {
    move,
    moveTo: index => {
      if (options().length === 0) return
      setState('active', Math.max(0, Math.min(options().length - 1, index)))
    },
    moveSection: () => undefined,
    moveColumn: () => undefined,
    submit,
    toggle: () => {
      if (question.multiSelect !== true) return
      const selected = options()[state.active]
      if (selected !== undefined) toggleSelected(selected.label)
    },
    selectedIndex: () => state.active,
    count: () => options().length,
  }

  onMount(() => {
    const previous = store.dialogController()
    store.setDialogController(controller)
    onCleanup(() => store.setDialogController(previous))
  })

  return (
    <DialogLayout
      store={store}
      header={<DialogHeader store={store} title={spec.title} onClose={() => store.closeTopDialog(undefined)} />}
      footer={<DialogFooter store={store} actions={[
        ...(question.multiSelect === true ? [{ title: 'toggle', key: 'ctrl+space', onTrigger: () => controller.toggle?.() }] : []),
        { title: 'submit', key: 'enter', onTrigger: submit },
        { title: 'cancel', key: 'esc', side: 'right', onTrigger: () => store.closeTopDialog(undefined) },
      ]} />}
    >
      <box flexDirection="column" gap={1}>
        <text fg={dialogColor(store, 'text.muted', '#7f849c')} content={question.question} />
        {question.detail !== undefined ? <text fg={dialogColor(store, 'text.muted', '#7f849c')} content={question.detail} wrapMode="word" /> : null}
        {options().length > 0 ? (
          <scrollbox
            height={Math.max(1, Math.min(options().length + 1, Math.floor(dimensions().height / 2) - 8))}
            scrollbarOptions={{ visible: false }}
            ref={(value: ScrollBoxRenderable | null) => { scroll = value ?? undefined }}
          >
            <For each={options()}>
              {(option, index) => {
                const active = () => state.active === index()
                const selected = () => state.selected.includes(option.label)
                const preferred = () => question.intent?.kind === 'plan-review' && question.intent.approve === option.label
                return (
                  <box
                    flexDirection="column"
                    onMouseMove={() => setState('active', index())}
                    onMouseDown={() => setState('active', index())}
                    onMouseUp={() => question.multiSelect === true ? toggleSelected(option.label) : store.closeTopDialog(JSON.stringify({ ...answer(), selected: [option.label] }))}
                  >
                    <box
                      flexDirection="row"
                      gap={1}
                      paddingLeft={DIALOG_LIST_INSET - 1}
                      paddingRight={DIALOG_LIST_INSET - 1}
                      backgroundColor={active() ? dialogColor(store, 'background.action.primary.$hovered', '#313244') : 'transparent'}
                    >
                      <text fg={active() ? dialogColor(store, 'text.action.primary.$focused', '#cdd6f4') : dialogColor(store, 'text.base', '#cdd6f4')} content={`${question.multiSelect === true ? (selected() ? '☑' : '☐') : (active() ? '›' : ' ')} ${option.label}`} attributes={active() ? TextAttributes.BOLD : undefined} />
                      {preferred() ? <text fg={dialogColor(store, 'text.feedback.success.base', '#a6e22e')} content="approve" /> : null}
                    </box>
                    {option.description !== undefined ? <box paddingLeft={DIALOG_LIST_INSET + 2} paddingRight={DIALOG_LIST_INSET}><text fg={dialogColor(store, 'text.muted', '#7f849c')} content={option.description} wrapMode="word" /></box> : null}
                  </box>
                )
              }}
            </For>
          </scrollbox>
        ) : null}
        <box paddingLeft={DIALOG_LIST_INSET} paddingRight={DIALOG_LIST_INSET}>
          <input
            width="100%"
            value={state.custom}
            placeholder={options().length === 0 ? 'Type your answer' : 'Additional or custom answer'}
            focused={true}
            textColor={dialogColor(store, 'text.formfield.base', '#cdd6f4')}
            placeholderColor={dialogColor(store, 'text.muted', '#7f849c')}
            focusedBackgroundColor={dialogColor(store, 'background.formfield.base', '#181825')}
            focusedTextColor={dialogColor(store, 'text.action.primary.$focused', '#cdd6f4')}
            onInput={value => setState('custom', value)}
          />
        </box>
      </box>
    </DialogLayout>
  )
}
