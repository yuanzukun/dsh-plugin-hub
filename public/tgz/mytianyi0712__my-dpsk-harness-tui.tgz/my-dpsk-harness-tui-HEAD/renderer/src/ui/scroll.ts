/**
 * Scroll acceleration.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, 2.0.32, `packages/tui/src/util/scroll.ts`),
 * MIT. Registered in NOTICE.md under the `opencode` entry; verified by
 * scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Upstream's default is `CustomSpeedScroll(3)`: three rows per input tick, not OpenTUI's
 * own acceleration curve. A configured `scroll.acceleration` swaps in the platform
 * acceleration, and a configured `scroll.speed` replaces the step.
 */

import { MacOSScrollAccel, type ScrollAcceleration } from '@opentui/core'

/** A fixed number of rows per scroll tick. */
export class CustomSpeedScroll implements ScrollAcceleration {
  constructor(private readonly speed: number) {}

  tick(): number {
    return this.speed
  }

  reset(): void {
    // A fixed step has no accumulated state to reset.
  }
}

/** The acceleration the transcript and the sidebar scroll with, from the TUI settings. */
export function getScrollAcceleration(config: { readonly scrollAcceleration?: unknown; readonly scrollSpeed?: unknown }): ScrollAcceleration {
  if (config.scrollAcceleration === true) return new MacOSScrollAccel()
  if (typeof config.scrollSpeed === 'number' && Number.isFinite(config.scrollSpeed)) return new CustomSpeedScroll(config.scrollSpeed)
  return new CustomSpeedScroll(3)
}
