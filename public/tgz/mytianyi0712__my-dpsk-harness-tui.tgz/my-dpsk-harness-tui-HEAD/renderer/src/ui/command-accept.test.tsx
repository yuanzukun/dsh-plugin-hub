/**
 * The composer's slash-command path: one Enter per command.
 *
 * The regression this file pins: before 0.5.0's accept fix, typing `/help` opened the
 * completion popup and Enter only re-set the draft to the same text (`setComposer` clears
 * the popup's "closed" flag), so the popup never closed and the command never ran. The
 * tests drive the real keymap + textarea, not the store API alone, because the bug lived
 * in the interaction between the two.
 */

import { expect, test } from 'bun:test'
import { mountShell } from '../test-harness.tsx'
import { createAppStore } from '../app.tsx'

/** A host catalog shaped like `src/index.ts`'s: local pickers carry no hint, `btw` does. */
const catalog = {
  protocolVersion: 2,
  seq: 1,
  kind: 'command-catalog' as const,
  payload: {
    sessionId: 'ses_1',
    commands: [
      { name: 'help', description: 'Show keyboard shortcuts and commands' },
      { name: 'model', description: 'Switch the model' },
      { name: 'think', description: 'Set the reasoning effort', argumentHint: '<level>' },
      { name: 'resume', description: 'Resume a session', argumentHint: '<sessionId>' },
      { name: 'btw', description: 'Add a side remark', argumentHint: '<text>' },
    ],
  },
}

async function mount(options?: { readonly catalog?: boolean }) {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  // A session snapshot leaves the home route, so the composer under test is the session
  // prompt (the home prompt shares the store but not the submit wiring assertions).
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'session',
      title: 'first prompt',
      events: [{ id: 'e1', role: 'user', text: 'hello' }],
      provider: 'cliproxy',
      model: 'mimo-v2.6-pro',
      effort: 'high',
      permission: 'auto',
      preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  // The snapshot resets the per-session catalogs, so the catalog lands after it.
  if (options?.catalog !== false) store.apply(catalog)
  const view = await mountShell(store, { width: 100, height: 30 })
  return { ...view, store, sent }
}

test('a local picker command runs on one Enter and the popup does not swallow it', async () => {
  const view = await mount()
  await view.mockInput.typeText('/help', 0)
  await view.renderOnce()
  // The popup is up: `/help` is a prefix of no other command, so its row is the only one.
  expect(view.store.composer()).toBe('/help')
  expect(view.store.popupOpen()).toBe(true)
  view.mockInput.pressEnter()
  await view.renderOnce()
  // One Enter: the dialog is open, the draft is consumed, and nothing went upstream.
  expect(view.store.dialogStack()).toHaveLength(1)
  expect(view.store.dialogStack()[0]?.title).toBe('keys')
  expect(view.store.composer()).toBe('')
  expect(view.store.popupOpen()).toBe(false)
  expect(view.sent).toEqual([])
  // A second Enter submits the *dialog*, it does not reopen or re-run the command.
  view.mockInput.pressEnter()
  await view.renderOnce()
  expect(view.store.dialogStack()).toHaveLength(0)
  expect(view.sent).toEqual([])
  view.renderer.destroy()
})

test('a no-argument host command is sent upstream on one Enter', async () => {
  const view = await mount()
  // `model` is a local picker; `resume`/`btw`/`think` take arguments. So a plain host
  // command has to come from a catalog row with no hint that is not intercepted locally.
  view.store.apply({
    protocolVersion: 2,
    seq: 3,
    kind: 'command-catalog',
    payload: { sessionId: 'ses_1', commands: [{ name: 'new', description: 'Start a new session' }] },
  })
  await view.mockInput.typeText('/new', 0)
  await view.renderOnce()
  expect(view.store.popupOpen()).toBe(true)
  view.mockInput.pressEnter()
  await view.renderOnce()
  expect(view.sent).toEqual([{ kind: 'send-message', payload: { sessionId: 'ses_1', text: '/new', delivery: 'steer' } }])
  expect(view.store.composer()).toBe('')
  view.renderer.destroy()
})

test('a command with arguments inserts its trailing space and waits', async () => {
  const view = await mount()
  await view.mockInput.typeText('/btw', 0)
  await view.renderOnce()
  view.mockInput.pressEnter()
  await view.renderOnce()
  // Inserted, not run: the popup is gone and the draft is the command plus one space.
  expect(view.store.composer()).toBe('/btw ')
  expect(view.store.popupOpen()).toBe(false)
  expect(view.sent).toEqual([])
  await view.mockInput.typeText('hi', 0)
  await view.renderOnce()
  view.mockInput.pressEnter()
  await view.renderOnce()
  expect(view.sent).toEqual([{ kind: 'send-message', payload: { sessionId: 'ses_1', text: '/btw hi', delivery: 'steer' } }])
  view.renderer.destroy()
})

test('an unknown command is handed to the host verbatim', async () => {
  const view = await mount()
  await view.mockInput.typeText('/zzz', 0)
  await view.renderOnce()
  expect(view.store.popupOpen()).toBe(false)
  view.mockInput.pressEnter()
  await view.renderOnce()
  expect(view.sent).toEqual([{ kind: 'send-message', payload: { sessionId: 'ses_1', text: '/zzz', delivery: 'steer' } }])
  view.renderer.destroy()
})

test('Tab and Enter agree: both run the local picker on one keystroke', async () => {
  const view = await mount()
  await view.mockInput.typeText('/model', 0)
  await view.renderOnce()
  view.mockInput.pressKey('TAB')
  await view.renderOnce()
  expect(view.store.dialogStack()).toHaveLength(1)
  // `/model` opens the dedicated picker, not the command palette: the title is upstream's
  // command title, and the picker owns the list whether or not the catalog has loaded.
  expect(view.store.dialogStack()[0]?.title).toBe('Switch model')
  expect(view.store.composer()).toBe('')
  view.renderer.destroy()
})
