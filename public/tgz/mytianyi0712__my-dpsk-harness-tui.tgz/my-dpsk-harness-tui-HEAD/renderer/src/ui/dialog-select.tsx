/**
 * The select dialog.
 *
 * Derived from opencode (`anomalyco/opencode`, v2.0.30,
 * `packages/tui/src/ui/dialog-select.tsx`), MIT. Registered in NOTICE.md under
 * the `opencode` entry; verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications:
 * - The option list is driven by the store's dialog spec (the host pushes the
 *   catalogs down over IPC), not by opencode's server client.
 * - `fuzzysort` is replaced by a weighted substring score: title matches weigh 2
 *   (a prefix match weighs 3), category and `searchText` weigh 1. Users search by
 *   the item name, so title matches dominate, which is opencode's `scoreFn` intent.
 * - `remeda` (`pipe` / `filter` / `groupBy` / `entries` / `flatMap` / `isDeepEqual`)
 *   is replaced by plain array code; values are strings, so strict equality is enough.
 * - `Keymap.createLayer()` is replaced by the store's modal key routing: the
 *   controller this component registers on mount is what the keymap drives
 *   (`↑↓`, `pageup`/`pagedown`, `home`/`end`, `enter`, `alt+up`/`alt+down`).
 * - Upstream reveals the selected row through its own list widget; here the
 *   scroll box's children are category containers, not rows, so the window is
 *   moved by a line index derived from the same accounting the row total uses
 *   (see `selectedLine`).
 * - `useTheme().surface("dialog")` is replaced by `@dialog` token lookups;
 *   `config.cursor`, `getScrollAcceleration`, `Locale.truncate*`, the row `gutter`
 *   and `margin` slots, the per-option `actions` table, and the `search` /
 *   `filterThreshold` / `preserveSelection` / `focusTarget` / `locked` props are
 *   not ported.
 * - `<Show>` at box level is replaced by ternaries (OpenTUI rejects the empty text
 *   node a false `<Show>` inserts into a box parent).
 */

import { TextAttributes } from '@opentui/core'
import type { ScrollBoxRenderable } from '@opentui/core'
import { useTerminalDimensions } from '@opentui/solid'
import { createEffect, createMemo, For, on, onCleanup, onMount } from '#solid'
import { createStore } from '#solid/store'
import { DIALOG_LIST_INSET, DialogFooter, DialogHeader, dialogColor, dialogWidth, type DialogController, type DialogFooterAction, type DialogOption, type DialogSpec, type DialogStore } from './dialog.tsx'
import { moveSelection, reconcileSelection } from './select-controller.ts'
import { truncate, truncateLeft, truncateMiddle } from './text.ts'

/** Rows reserve scroll padding, row padding, the marker, title padding, and the gap. */
export function dialogSelectContentWidth(width: number): number {
  return width - DIALOG_LIST_INSET * 2 - 4
}

/** Weighted substring score: title 2 (prefix 3), category 1, searchText 1. */
export function scoreOption(option: DialogOption, needle: string): number {
  const title = option.title.toLowerCase()
  if (needle === '') return 0
  let score = 0
  if (title.includes(needle)) score += title.startsWith(needle) ? 3 : 2
  if ((option.category ?? '').toLowerCase().includes(needle)) score += 1
  if ((option.searchText ?? '').toLowerCase().includes(needle)) score += 1
  return score
}

/** The options that survive the filter, in score order (stable ties keep input order). */
export function filterOptions(options: readonly DialogOption[], query: string): DialogOption[] {
  const usable = options.filter(option => option.disabled !== true)
  const needle = query.trim().toLowerCase()
  if (needle === '') return usable
  const scored = usable
    .map((option, index) => ({ option, index, score: scoreOption(option, needle) }))
    .filter(entry => entry.score > 0)
    .sort((a, b) => b.score - a.score || a.index - b.index)
  return scored.map(entry => entry.option)
}

/** Group by category, keeping the order categories first appear. */
export function groupOptions(options: readonly DialogOption[]): Array<[string, DialogOption[]]> {
  const groups: Array<[string, DialogOption[]]> = []
  const byCategory: Record<string, DialogOption[]> = {}
  for (const option of options) {
    const category = option.category ?? ''
    const bucket = byCategory[category]
    if (bucket === undefined) {
      byCategory[category] = [option]
      groups.push([category, byCategory[category]!])
    } else {
      bucket.push(option)
    }
  }
  return groups
}

/** The select dialog: filter input, grouped rows, keyboard navigation. */
export function DialogSelect(props: { store: DialogStore; spec: DialogSpec }) {
  const store = props.store
  const spec = props.spec
  // `initialFilter` seeds the query, so a picker opened from a command argument already
  // narrows to what the user typed rather than making them retype it.
  const [state, setState] = createStore({ selected: 0, filter: spec.initialFilter ?? '' })
  const dimensions = useTerminalDimensions()

  // The opening category filter (`ctrl+x t` → themes) narrows the rows before the
  // query does, so the group shortcut never types into the filter box.
  const filtered = () => {
    const options = spec.options ?? []
    const scoped = spec.categoryFilter === undefined ? options : options.filter(option => option.category === spec.categoryFilter)
    return filterOptions(scoped, state.filter)
  }
  const grouped = createMemo(() => groupOptions(filtered()))
  const flat = createMemo(() => grouped().flatMap(([, options]) => options))
  const rows = createMemo(() => {
    const headers = grouped().reduce((acc, [category], index) => acc + (category === '' ? 0 : index > 0 ? 2 : 1), 0)
    return flat().reduce((acc, option) => acc + 1 + (option.details?.length ?? 0), headers)
  })
  const height = createMemo(() => Math.max(1, Math.min(rows(), Math.floor(dimensions().height / 2) - 6)))
  // The title is cut to the space the panel actually has, so a long name never
  // spills past the terminal edge.
  const titleWidth = createMemo(() => {
    const panel = Math.min(dialogWidth(spec.size ?? 'medium'), dimensions().width - 2)
    return Math.max(1, dialogSelectContentWidth(panel))
  })
  const selected = createMemo(() => flat()[state.selected])

  // The list can shrink under a filter; pull the index back into range.
  createEffect(
    on(
      [flat, () => state.filter],
      () => {
        const count = flat().length
        if (count === 0) return
        const next = reconcileSelection(state.selected, count)
        if (next !== state.selected) setState('selected', next)
      },
    ),
  )

  // A fresh query highlights the first match; clearing it returns to `current`.
  createEffect(
    on(
      () => state.filter,
      query => {
        if (query === '') {
          const index = spec.current === undefined ? -1 : flat().findIndex(option => option.value === spec.current)
          setState('selected', index >= 0 ? index : 0)
          return
        }
        if (flat().length > 0) setState('selected', 0)
      },
    ),
  )

  let input: { focus(): void; isDestroyed: boolean } | undefined
  let scroll: ScrollBoxRenderable | undefined

  /**
   * The painted line (0-based, from the top of the list content) the selected row starts on.
   *
   * The scroll box's children are the category containers, not rows, so a row cannot be
   * located by child index. The line is derived from the same accounting `rows()` uses:
   * a category header paints one line (plus the blank one the layout puts above every
   * header except the first), and a row paints its title line plus one line per detail.
   */
  function selectedLine(): number | undefined {
    const target = selected()
    if (target === undefined) return undefined
    let line = 0
    let group = 0
    for (const [category, options] of grouped()) {
      if (category !== '') line += group === 0 ? 1 : 2
      for (const option of options) {
        if (option.value === target.value) return line
        line += 1 + (option.details?.length ?? 0)
      }
      group += 1
    }
    return undefined
  }

  /** The lines the viewport can actually show; the scrollbar's viewport is the visible height. */
  function visibleLines(box: ScrollBoxRenderable): number {
    const measured = box.verticalScrollBar.viewportSize
    return Math.max(1, measured > 0 ? measured : box.viewport.height)
  }

  /**
   * Reveal the selected row. `center` puts it in the middle of the window, for the long
   * jumps (`home` / `end` / a section jump) the user did not aim at row by row;
   * otherwise the window moves the least it can, which is what a step at a time needs.
   */
  function scrollToSelection(center: boolean): void {
    const box = scroll
    if (box === undefined) return
    const line = selectedLine()
    if (line === undefined) return
    const visible = visibleLines(box)
    if (center) {
      box.scrollTop = line - Math.floor(visible / 2)
      return
    }
    const top = box.scrollTop
    if (line < top) box.scrollTop = line
    else if (line >= top + visible) box.scrollTop = line - visible + 1
  }

  /**
   * Move the highlight and reveal it. Single steps move the window the least they can;
   * a section jump centers the section's first row, because that is a long jump the user
   * did not aim at row by row.
   */
  function moveTo(index: number, center = false): void {
    setState('selected', index)
    if (selected() !== undefined) {
      scrollToSelection(center)
      spec.onPreview?.(selected()!.value)
    }
  }

  function move(delta: number): void {
    if (flat().length === 0) return
    moveTo(moveSelection(state.selected, { count: flat().length, delta, policy: 'wrap' }))
  }

  function moveSection(direction: -1 | 1): void {
    const sections = grouped().filter(([, options]) => options.length > 0)
    if (sections.length === 0) return
    const current = sections.findIndex(([category]) => category === selected()?.category)
    const section = sections[(current + direction + sections.length) % sections.length]
    const first = section?.[1][0]
    if (first === undefined) return
    moveTo(flat().indexOf(first), true)
  }

  function submit(): void {
    const option = selected()
    if (option === undefined) return
    // Name the dialog this commit belongs to: the same key press also reaches the keymap's
    // `dialog-submit`, and without the id that second call would submit the follow-up dialog
    // this one just opened (the "panel opens then vanishes" symptom).
    store.closeTopDialog(option.value, spec.id)
  }

  const controller: DialogController = {
    move: delta => move(delta),
    // `home` / `end` land on a distant row, so they center the window on it too.
    moveTo: index => moveTo(index, true),
    // `Alt+Up` / `Alt+Down` belong to the dialogs that declare section navigation; every
    // other list consumes the key without moving, exactly like upstream's opt-in.
    moveSection: direction => {
      if (spec.sectionNavigation !== true) return
      moveSection(direction)
    },
    // A select list has no button row to toggle.
    moveColumn: () => undefined,
    submit,
    count: () => flat().length,
    selectedIndex: () => state.selected,
  }

  // The top dialog owns the modal keys; closing restores the dialog underneath it.
  onMount(() => {
    const previous = store.dialogController()
    store.setDialogController(controller)
    onCleanup(() => {
      store.setDialogController(previous)
      if (input !== undefined && !input.isDestroyed) input.focus()
    })
    if (input !== undefined && !input.isDestroyed) {
      const field = input
      setTimeout(() => {
        if (!field.isDestroyed) field.focus()
      }, 1)
    }
  })

  const footerActions = (): DialogFooterAction[] => [
    { title: store.label('rendererDialogMove', 'move'), key: '↑↓' },
    { title: store.label('rendererDialogRun', 'run'), key: 'enter', onTrigger: submit, disabled: flat().length === 0 },
  ]

  const rowFg = (active: boolean, current: boolean): string => {
    if (active) return dialogColor(store, 'text.action.primary.$focused', '#cdd6f4')
    if (current) return dialogColor(store, 'text.action.primary.$selected', '#cdd6f4')
    return dialogColor(store, 'text.base', '#cdd6f4')
  }

  return (
    <box gap={1} paddingBottom={1} flexGrow={1}>
      <box paddingLeft={DIALOG_LIST_INSET} paddingRight={DIALOG_LIST_INSET}>
        <DialogHeader store={store} title={spec.title} onClose={() => store.closeTopDialog(undefined)} />
        <box paddingTop={1}>
          {/* No explicit width: the input fills the inset box, so the panel's `maxWidth` clamp
           * (terminal width - 2) narrows it on a narrow terminal instead of overflowing it. */}
          <input
            value={state.filter}
            placeholder={spec.placeholder ?? store.label('rendererSearch', 'Search')}
            focused={true}
            textColor={dialogColor(store, 'text.base', '#cdd6f4')}
            placeholderColor={dialogColor(store, 'text.muted', '#7f849c')}
            focusedBackgroundColor={dialogColor(store, 'background.formfield.base', '#181825')}
            focusedTextColor={dialogColor(store, 'text.action.primary.$focused', '#cdd6f4')}
            ref={(renderable: { focus(): void; isDestroyed: boolean }) => {
              input = renderable
            }}
            onInput={value => setState('filter', value)}
          />
        </box>
      </box>
      <box flexGrow={1} flexShrink={1}>
        {flat().length > 0 ? (
          <scrollbox
            paddingLeft={1}
            paddingRight={1}
            maxHeight={height()}
            scrollbarOptions={{ visible: false }}
            ref={(renderable: ScrollBoxRenderable | null) => {
              if (renderable === null) return
              scroll = renderable
            }}
          >
            <For each={grouped()}>
              {([category, options], index) => (
                <box flexDirection="column">
                  {category !== '' ? (
                    <box paddingTop={index() === 0 ? 0 : 1} paddingLeft={DIALOG_LIST_INSET - 1}>
                      <text fg={store.color('hue.accent.200') ?? dialogColor(store, 'text.base', '#cdd6f4')} attributes={TextAttributes.BOLD}>
                        {category}
                      </text>
                    </box>
                  ) : null}
                  <For each={options}>
                    {option => {
                      const active = () => option.value === selected()?.value
                      const current = () => option.value === spec.current
                      const index = () => flat().findIndex(row => row.value === option.value)
                      const fg = () => rowFg(active(), current())
                      return (
                        <box
                          flexDirection="column"
                          position="relative"
                          onMouseMove={() => {
                            const at = index()
                            if (at === -1 || at === state.selected) return
                            moveTo(at)
                          }}
                          onMouseDown={() => {
                            const at = index()
                            if (at !== -1) moveTo(at)
                          }}
                          onMouseUp={() => store.closeTopDialog(option.value)}
                        >
                          <box
                            flexDirection="row"
                            paddingLeft={current() ? DIALOG_LIST_INSET - 3 : DIALOG_LIST_INSET - 1}
                            paddingRight={DIALOG_LIST_INSET - 1}
                            gap={1}
                            backgroundColor={active() ? dialogColor(store, 'background.action.primary.$hovered', '#313244') : 'transparent'}
                          >
                            {current() ? (
                              <text flexShrink={0} fg={fg()}>
                                ●
                              </text>
                            ) : null}
                            <text
                              flexGrow={1}
                              fg={fg()}
                              attributes={active() ? TextAttributes.BOLD : undefined}
                              overflow="hidden"
                              wrapMode="none"
                              paddingLeft={3}
                            >
                              {truncate(option.title, titleWidth())}
                              {option.description !== undefined && option.description !== option.category ? (
                                <span style={{ fg: active() ? fg() : dialogColor(store, 'text.muted', '#7f849c') }}> {option.description}</span>
                              ) : null}
                            </text>
                            {option.footer !== undefined ? (
                              <box flexShrink={0}>
                                <text fg={active() ? fg() : dialogColor(store, 'text.muted', '#7f849c')}>{option.footer}</text>
                              </box>
                            ) : null}
                          </box>
                          <For each={option.details ?? []}>
                            {detail => (
                              <box paddingLeft={DIALOG_LIST_INSET - 1} paddingRight={DIALOG_LIST_INSET - 1}>
                                <text
                                  fg={dialogColor(store, 'text.muted', '#7f849c')}
                                  wrapMode="none"
                                  content={truncateMiddle(detail, Math.max(1, dialogSelectContentWidth(Math.min(dialogWidth(spec.size ?? 'medium'), dimensions().width))))}
                                />
                              </box>
                            )}
                          </For>
                        </box>
                      )
                    }}
                  </For>
                </box>
              )}
            </For>
          </scrollbox>
        ) : (
          <box paddingLeft={DIALOG_LIST_INSET} paddingRight={DIALOG_LIST_INSET}>
            <text fg={dialogColor(store, 'text.muted', '#7f849c')} content={state.filter === '' ? 'No items available' : 'No results found'} />
          </box>
        )}
      </box>
      <DialogFooter store={store} inset={DIALOG_LIST_INSET} actions={footerActions()} />
    </box>
  )
}
