/** Coarse activity labels for the compact session picker. */
export interface SessionActivityLabels {
  readonly today: string
  readonly yesterday: string
  readonly last7Days: string
}

function localDayNumber(time: number): number {
  const date = new Date(time)
  return Date.UTC(date.getFullYear(), date.getMonth(), date.getDate())
}

/** Format a session's last activity as today / yesterday / last 7 days / local date. */
export function formatSessionActivityLabel(
  activityAt: number | undefined,
  now: number,
  locale: string,
  labels: SessionActivityLabels,
): string {
  if (activityAt === undefined || !Number.isFinite(activityAt) || activityAt <= 0) return ''
  // Compare calendar-day numbers, not rolling 24-hour windows. A session from two
  // calendar days ago must never be labelled yesterday just because it is <48h old.
  const days = Math.round((localDayNumber(now) - localDayNumber(activityAt)) / 86_400_000)
  const nowDate = new Date(now)
  if (days <= 0) return labels.today
  if (days === 1) return labels.yesterday
  if (days <= 6) return labels.last7Days
  const activity = new Date(activityAt)
  const sameYear = activity.getFullYear() === nowDate.getFullYear()
  return new Intl.DateTimeFormat(locale, sameYear
    ? { month: '2-digit', day: '2-digit' }
    : { year: 'numeric', month: '2-digit', day: '2-digit' }).format(activity)
}
