import { describe, expect, test } from 'bun:test'
import { formatSessionActivityLabel } from './session-activity-label.ts'

const labels = { today: 'today', yesterday: 'yesterday', last7Days: 'last 7 days' }
const now = new Date(2026, 9, 23, 14, 30).getTime()

describe('formatSessionActivityLabel', () => {
  test('uses coarse calendar buckets, not raw 24-hour windows', () => {
    expect(formatSessionActivityLabel(new Date(2026, 9, 23, 0, 1).getTime(), now, 'en', labels)).toBe('today')
    expect(formatSessionActivityLabel(new Date(2026, 9, 22, 23, 59).getTime(), now, 'en', labels)).toBe('yesterday')
    expect(formatSessionActivityLabel(new Date(2026, 9, 20, 12, 0).getTime(), now, 'en', labels)).toBe('last 7 days')
    expect(formatSessionActivityLabel(new Date(2026, 9, 16, 12, 0).getTime(), now, 'en', labels)).toBe('10/16')
  })

  test('never labels a session from two calendar days ago as yesterday', () => {
    const midnight = new Date(2026, 9, 23, 0, 1).getTime()
    expect(formatSessionActivityLabel(new Date(2026, 9, 21, 23, 59).getTime(), midnight, 'en', labels)).toBe('last 7 days')
    expect(formatSessionActivityLabel(new Date(2026, 9, 22, 0, 0).getTime(), midnight, 'en', labels)).toBe('yesterday')
    expect(formatSessionActivityLabel(new Date(2026, 9, 21, 0, 0).getTime(), midnight, 'en', labels)).toBe('last 7 days')
  })

  test('includes the year once the activity crosses into another year', () => {
    expect(formatSessionActivityLabel(new Date(2025, 11, 31, 12, 0).getTime(), now, 'en', labels)).toContain('2025')
  })

  test('returns an empty marker for missing or invalid activity', () => {
    expect(formatSessionActivityLabel(undefined, now, 'en', labels)).toBe('')
    expect(formatSessionActivityLabel(0, now, 'en', labels)).toBe('')
    expect(formatSessionActivityLabel(Number.NaN, now, 'en', labels)).toBe('')
  })
})
