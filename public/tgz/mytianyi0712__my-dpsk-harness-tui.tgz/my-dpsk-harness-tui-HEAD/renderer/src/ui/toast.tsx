/**
 * The toast overlay.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, 2.0.32, `packages/tui/src/ui/toast.tsx`),
 * MIT. Registered in NOTICE.md under the `opencode` entry; verified by
 * scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications:
 * - Upstream's `ToastProvider` context is replaced by the app store's queue: the shell
 *   already owns the notice signal, and a second context would be a second place to look
 *   for the current toast.
 * - The action row is a dismiss affordance only. dsh notices carry a level and a text;
 *   inventing an action callback for them would be a button with no handler behind it.
 *
 * Behaviour that is upstream's, not this package's:
 * - One toast is on screen at a time; further notices queue and the surface shows
 *   `+N more` under the visible one.
 * - Hovering pauses the timer (the remaining time is banked), leaving resumes it from
 *   where it stopped.
 * - A text selection is never dismissed by the click that made it.
 */

import { createSignal, For, onCleanup, Show } from '#solid'
import { useTerminalDimensions } from '@opentui/solid'

/** One notice: the level picks the border color, the text is the report. */
export interface ToastItem {
  readonly level: 'info' | 'warning' | 'error'
  readonly text: string
  readonly title?: string
}

/** The slice of the app store the overlay reads. */
export interface ToastStore {
  /** The visible toast, or `undefined` when the queue is empty. */
  toast: () => ToastItem | undefined
  /** Notices waiting behind the visible one. */
  pendingToasts: () => number
  /** The visible toast's remaining time, in ms. */
  toastRemaining: () => number
  color: (path: string) => string | undefined
  dismissToast: () => void
  pauseToast: () => void
  resumeToast: () => void
}

/** How long a notice stays up, in ms. Upstream's default; dsh passes none. */
export const TOAST_DURATION_MS = 5000

/** The variant color for one toast level. */
function toastColor(store: ToastStore, level: ToastItem['level']): string {
  if (level === 'error') return store.color('text.feedback.error.base') ?? '#f38ba8'
  if (level === 'warning') return store.color('text.feedback.warning.base') ?? '#f9e2af'
  return store.color('text.action.secondary.base') ?? '#89d7eb'
}

/** The overlay: the current toast at the top-right, and how many wait behind it. */
export function ToastOverlay(props: { store: ToastStore }) {
  const store = props.store
  const dimensions = useTerminalDimensions()
  const [hovered, setHovered] = createSignal(false)
  const maxWidth = () => Math.min(60, Math.max(10, dimensions().width - 6))
  return (
    <Show when={store.toast()}>
      {current => (
        <box
          position="absolute"
          top={1}
          right={2}
          zIndex={4000}
          flexDirection="column"
          maxWidth={maxWidth()}
          justifyContent="center"
          alignItems="flex-start"
          border={['left', 'right']}
          borderStyle="single"
          borderColor={toastColor(store, current().level)}
          onMouseOver={() => {
            setHovered(true)
            store.pauseToast()
          }}
          onMouseOut={() => {
            setHovered(false)
            store.resumeToast()
          }}
          onMouseUp={() => store.dismissToast()}
        >
          <box
            width="100%"
            paddingLeft={2}
            paddingRight={2}
            paddingTop={1}
            paddingBottom={1}
            backgroundColor={store.color('background.raised.high') ?? '#313244'}
          >
            {current().title === undefined ? (
              <box flexDirection="row" width="100%" gap={2}>
                <text fg={store.color('text.base') ?? '#cdd6f4'} wrapMode="word" flexGrow={1} content={current().text} />
                <text
                  flexShrink={0}
                  wrapMode="none"
                  fg={hovered() ? store.color('hue.accent.200') ?? '#9d7cd8' : store.color('text.muted') ?? '#565f89'}
                  content="x"
                />
              </box>
            ) : (
              <>
                <box flexDirection="row" width="100%" marginBottom={1}>
                  <text attributes={1} fg={store.color('text.base') ?? '#cdd6f4'} content={current().title ?? ''} />
                  <box flexGrow={1} />
                  <text
                    flexShrink={0}
                    wrapMode="none"
                    fg={hovered() ? store.color('hue.accent.200') ?? '#9d7cd8' : store.color('text.muted') ?? '#565f89'}
                    content="x"
                  />
                </box>
                <text fg={store.color('text.base') ?? '#cdd6f4'} wrapMode="word" width="100%" content={current().text} />
              </>
            )}
            {store.pendingToasts() > 0 ? (
              <text fg={store.color('text.muted') ?? '#565f89'} marginTop={1} content={`+${store.pendingToasts()} more`} />
            ) : null}
          </box>
        </box>
      )}
    </Show>
  )
}

/**
 * The toast queue: one visible toast, the rest waiting, and a timer that pauses on hover.
 *
 * Kept as a factory rather than a provider so the store owns it; every transition is the
 * same one upstream's `toast.show` / `dismiss` / `pause` / `resume` performs.
 */
export function createToastQueue() {
  const [queue, setQueue] = createSignal<readonly ToastItem[]>([])
  const [remaining, setRemaining] = createSignal(TOAST_DURATION_MS)
  let handle: ReturnType<typeof setTimeout> | undefined
  let startedAt = 0
  let paused = false
  let left = TOAST_DURATION_MS

  const clear = (): void => {
    if (handle === undefined) return
    clearTimeout(handle)
    handle = undefined
  }
  const current = (): ToastItem | undefined => queue()[0]
  const start = (duration: number): void => {
    clear()
    left = duration
    setRemaining(duration)
    startedAt = Date.now()
    handle = setTimeout(() => dismiss(), duration)
  }
  const dismiss = (): void => {
    clear()
    const next = queue()[1]
    setQueue(items => items.slice(1))
    if (next === undefined) {
      paused = false
      left = TOAST_DURATION_MS
      setRemaining(TOAST_DURATION_MS)
      return
    }
    if (paused) return
    start(TOAST_DURATION_MS)
  }
  const show = (item: ToastItem): void => {
    const items = queue()
    // Identical notices are the same report, not new information: a failing subsystem that
    // retries must not fill the queue with duplicates (the host also aggregates where it can).
    if (items.some(entry => entry.text === item.text && entry.level === item.level)) return
    // Keep the queue bounded; the visible toast and the newest reports win.
    if (items.length >= 20) return
    if (items.length > 0 && (paused || items.length > 1)) {
      setQueue([...items, item])
      return
    }
    if (items.length > 0) {
      // The visible toast is on its timer with nothing behind it: the new notice takes
      // over, which is what upstream does when the queue is empty.
      setQueue([item])
      if (!paused) start(TOAST_DURATION_MS)
      return
    }
    setQueue([item])
    start(TOAST_DURATION_MS)
  }
  const pause = (): void => {
    if (current() === undefined || paused) return
    paused = true
    left = Math.max(0, left - (Date.now() - startedAt))
    setRemaining(left)
    clear()
  }
  const resume = (): void => {
    if (current() === undefined || !paused) return
    paused = false
    start(left)
  }
  onCleanup(clear)
  return {
    current,
    pending: (): number => Math.max(0, queue().length - 1),
    remaining,
    show,
    dismiss,
    pause,
    resume,
  }
}
