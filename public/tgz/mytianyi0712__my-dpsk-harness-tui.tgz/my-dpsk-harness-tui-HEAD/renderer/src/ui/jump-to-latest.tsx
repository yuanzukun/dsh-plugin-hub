/**
 * The "jump to latest" affordance.
 *
 * It is an overlay, not a transcript row: the button sits in the one blank row above
 * the prompt panel, right-aligned inside the content column. Rendering it in flow moved
 * the composer down whenever it appeared, and a bare <text> had no mouse target.
 */

import { MouseButton, type MouseEvent } from '@opentui/core'
import { createSignal, type JSX } from '#solid'

export interface JumpToLatestProps {
  readonly visible: boolean
  /** Cells from the content column's right edge. */
  readonly right: number
  /** Rows from the content column's bottom edge to the panel top. */
  readonly bottom: number
  readonly label: string
  readonly fg: string
  readonly bg: string
  readonly bgHover: string
  readonly onJump: () => void
}

/** One clickable line above the composer; the caller owns visibility and theme inks. */
export function JumpToLatest(props: JumpToLatestProps): JSX.Element {
  const [hovered, setHovered] = createSignal(false)
  let press: { x: number; y: number } | undefined
  let dragged = false
  return (
    <box
      position="absolute"
      visible={props.visible}
      right={props.right}
      bottom={props.bottom}
      height={1}
      zIndex={50}
      flexDirection="row"
      flexShrink={0}
      paddingLeft={1}
      paddingRight={1}
      overflow="hidden"
      backgroundColor={hovered() ? props.bgHover : props.bg}
      onMouseOver={() => setHovered(true)}
      onMouseOut={() => setHovered(false)}
      onMouseDown={(event: MouseEvent) => {
        if (event.button !== MouseButton.LEFT) return
        press = { x: event.x, y: event.y }
        dragged = false
        event.stopPropagation()
        event.preventDefault?.()
      }}
      onMouseDrag={(event: MouseEvent) => {
        if (press === undefined) return
        if (Math.abs(event.x - press.x) > 0 || Math.abs(event.y - press.y) > 0) dragged = true
      }}
      onMouseUp={(event: MouseEvent) => {
        if (event.button !== MouseButton.LEFT) return
        const start = press
        press = undefined
        if (start === undefined || dragged) return
        event.stopPropagation()
        props.onJump()
      }}
    >
      <text fg={props.fg} content={props.label} wrapMode="none" selectable={false} />
    </box>
  )
}
