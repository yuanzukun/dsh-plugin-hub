/**
 * Renderer-side mirror of the renderer protocol v2 kind registry.
 *
 * The renderer runs as a separate Bun process, so it cannot import from the
 * host's `src/ipc/kinds.ts`. This file is the renderer's copy of the same
 * registry, and `pnpm run verify:ipc-protocol` checks that both sides list the
 * same kinds in both directions: a kind cannot exist on one side only.
 *
 * The renderer implements every downstream kind it receives and sends every
 * upstream kind it declares. Kinds the host does not send are simply never
 * received; kinds the renderer does not implement are skipped by the host during
 * negotiation.
 */

/** Protocol version this renderer speaks. Must match the host's `RENDERER_PROTOCOL_VERSION`. */
export const RENDERER_PROTOCOL_VERSION = 2

/** One message on the host ↔ renderer channel. */
export interface IpcEnvelope {
  readonly protocolVersion: number
  readonly seq: number
  readonly kind: string
  readonly payload: unknown
}

export interface SessionSnapshotPayload {
  readonly sessionId: string
  readonly initialRoute: 'home' | 'session'
  readonly parentId?: string
  readonly readOnly?: boolean
  readonly title: string
  readonly events: readonly TranscriptEvent[]
  readonly provider: string
  readonly model: string
  readonly effort: string
  readonly permission: string
  readonly preset: string
  readonly workspace?: string
  readonly availableActions: readonly string[]
  readonly attachmentCapabilities: { readonly files: boolean; readonly images: boolean }
  /** Usage for this exact session, carried by the snapshot so resume/reattach paint
   * token and cache statistics on the first frame. */
  readonly usage?: UsagePayload
}

/** Host → renderer: a route-only update; it must not reset the transcript or catalogs. */
export interface SelectionStatePayload {
  readonly sessionId: string
  readonly provider: string
  readonly model: string
  readonly effort: string
  readonly permission?: string
  readonly preset?: string
  readonly attachmentCapabilities?: { readonly files: boolean; readonly images: boolean }
  /** Capability list can change when terminal setup finishes after the first frame. */
  readonly availableActions?: readonly string[]
}

export interface SessionFramePayload {
  readonly sessionId: string
  readonly events: readonly TranscriptEvent[]
}

export interface SessionListPayload {
  readonly sessions: readonly {
    readonly id: string
    readonly title: string
    readonly active: boolean
    readonly workspace?: string
    readonly parentId?: string
    readonly sessionKind?: 'main' | 'subagent'
    readonly canInteract?: boolean
    readonly createdAt: number
    /** Final event time; omitted when the backend cannot cheaply provide one. */
    readonly lastActivityAt?: number
    readonly status: 'idle' | 'running'
    readonly attention: boolean
  }[]
  readonly current: string
}

export interface ModelCatalogPayload {
  readonly sessionId: string
  readonly models: readonly { readonly provider: string; readonly model: string; readonly label: string; readonly current: boolean }[]
}

export interface ReasoningEffortsPayload {
  readonly sessionId: string
  readonly efforts: readonly string[]
  readonly current: string
}

export interface WorkspaceFilesPayload {
  readonly sessionId: string
  readonly files: readonly string[]
}

export interface PermissionPresetsPayload {
  readonly sessionId: string
  readonly presets: readonly { readonly id: string; readonly label: string; readonly current: boolean }[]
}

export interface AgentPresetsPayload {
  readonly sessionId: string
  readonly presets: readonly { readonly id: string; readonly label: string; readonly current: boolean }[]
}

export interface TurnStatePayload {
  readonly sessionId: string
  readonly running: boolean
}

export interface CommandCatalogPayload {
  readonly sessionId: string
  readonly commands: readonly { readonly name: string; readonly description: string; readonly argumentHint?: string }[]
}


export interface InterjectEditPayload {
  readonly sessionId: string
  readonly id?: string
}

export interface InterjectDeletePayload {
  readonly sessionId: string
  readonly id: string
}

export interface AttachmentReadPayload {
  readonly sessionId: string
  readonly attachment: unknown
}
export type SubmittedAttachment =
  | { readonly type: 'image'; readonly mediaType: 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif'; readonly data: string; readonly name?: string }
  | { readonly type: 'file'; readonly data: string; readonly name?: string }

export interface SendMessagePayload {
  readonly sessionId: string
  readonly text: string
  readonly delivery: 'steer' | 'queue'
  readonly attachments?: readonly SubmittedAttachment[]
  readonly skills?: readonly string[]
}

export interface SessionOpPayload {
  readonly op: 'new' | 'switch' | 'rename' | 'fork' | 'read'
  readonly sessionId?: string
  readonly title?: string
  readonly boundary?: number
  readonly cwd?: string
  readonly selection?: { readonly provider: string; readonly model: string; readonly effort?: string; readonly preset: string; readonly permission?: string }
}

export interface SelectionPayload {
  readonly sessionId: string
  readonly provider?: string
  readonly model?: string
  readonly effort?: string
  readonly permission?: string
  readonly preset?: string
}

export interface CommandResultPayload {
  readonly seq: number
  readonly ok: boolean
  readonly value?: unknown
  readonly text?: string
  readonly error?: string
}

/** The kinds the host sends; the renderer must understand every one it receives. */
export const DOWNSTREAM_KINDS = [
  'hello-ack',
  'session-snapshot',
  'selection-state',
  'session-frame',
  'session-list',
  'model-catalog',
  'provider-catalog',
  'reasoning-efforts',
  'workspace-files',
  'permission-presets',
  'agent-presets',
  'settings',
  'i18n',
  'command-result',
  'command-catalog',
  'dialog-response',
  'extension-dialog',
  'boot-notice',
  'turn-state',
  'wechat-output',
  'form-spec',
  'question-request',
  'question-close',
  'question-result',
  'approval-request',
  'approval-close',
  'subagent-list',
  'skills-list',
  'usage',
  'git-branch',
  'mcp-servers',
  'host-plugins',
  'todos',
  'shell-jobs',
  'interject-list',
  'model-discovery',
  'model-list',
  'log',
  'terminal-frame',
  'terminal-end',
  'bye',
] as const

/** The kinds the renderer sends; the host must understand every one it receives. */
export const UPSTREAM_KINDS = [
  'hello',
  'send-message',
  'interject-edit',
  'interject-delete',
  'shell-job-op',
  'attachment-read',
  'session-op',
  'set-selection',
  'update-settings',
  'dialog-request',
  'shortcut',
  'extension-dialog-response',
  'form-submit',
  'model-discover',
  'model-list-request',
  'model-edit',
  'question-answer',
  'approval-answer',
  'wechat-op',
  'doctor-check',
  'terminal-scheme',
  'terminal-size',
  'bye',
  'shutdown',
  'autostart-op',
  'terminal-op',
  'question-timeout',
  'interrupt',
] as const

export type DownstreamKind = (typeof DOWNSTREAM_KINDS)[number]
export type UpstreamKind = (typeof UPSTREAM_KINDS)[number]

/**
 * One field of a harness-owned form, mirrored from the host's `FormFieldSpec`.
 *
 * The renderer cannot import the host module (separate process), so the shape is
 * duplicated here; `verify:ipc-protocol` checks the kind registry, not the payload
 * interfaces, so the mirror is kept in sync by hand.
 */
export interface FormFieldSpec {
  readonly key: string
  readonly label: string
  readonly kind: 'text' | 'secret' | 'select' | 'action'
  readonly value: string
  readonly options?: readonly string[]
  /** The value is long (the provider model catalog is one line per model): the
   * renderer draws it as a multi-line textarea instead of a single-line input. */
  readonly multiline?: boolean
}

/**
 * The renderer's request to run the host's provider model discovery probe, mirrored from
 * the host's `ModelDiscoverPayload`. An `action` field sends the form's current values on
 * Enter; the host answers with `model-discovery` carrying the merged models line.
 */
export interface ModelDiscoverPayload {
  readonly form: string
  readonly fields: Record<string, string>
}

/** Host → renderer: the models field after the probe merged the published ids. */
export interface ModelDiscoveryPayload {
  readonly form: string
  readonly models: string
}

/**
 * Host → renderer: the models the provider form's current line carries, for the nested
 * per-model editor. The host parses the flat line, so the encoding rules stay in the host.
 */
export interface ModelListPayload {
  readonly form: string
  readonly models: readonly { readonly id: string; readonly label: string }[]
}

/** Renderer → host: ask for the model list of the provider form's current values. */
export interface ModelListRequestPayload {
  readonly form: string
  readonly fields: Record<string, string>
}

/** Renderer → host: the model picked in the list, plus the line it came from. */
export interface ModelEditPayload {
  readonly form: string
  readonly id: string
  readonly models: string
}

/**
 * One question the host asks the human through the renderer, mirrored from the host's
 * `QuestionSpec`. The answer goes back as `{id, selected, custom?}` items.
 */
export interface QuestionSpec {
  readonly id: string
  readonly question: string
  readonly header?: string
  readonly detail?: string
  readonly multiSelect?: boolean
  readonly intent?: { readonly kind: 'plan-review'; readonly approve: string; readonly callId?: string }
  readonly options?: readonly { readonly label: string; readonly description?: string }[]
}

export interface QuestionRequestPayload {
  readonly request: string
  readonly sessionId: string
  readonly ownerSessionId?: string
  readonly state: 'open' | 'continued'
  readonly callId?: string
  readonly remainingMs?: number
  readonly questions: readonly QuestionSpec[]
}

export interface QuestionTimeoutPayload { readonly request: string }

export interface QuestionAnswerItem {
  readonly id: string
  readonly selected: readonly string[]
  readonly custom?: string
}

export interface QuestionClosePayload { readonly request: string }
export interface QuestionResultPayload { readonly request: string; readonly ok: boolean; readonly error?: string }
export interface ApprovalRequestPayload {
  readonly request: string
  readonly sessionId: string
  readonly ownerSessionId?: string
  readonly toolName: string
  readonly callId?: string
  readonly reason?: string
}
export interface ApprovalClosePayload { readonly request: string }
export interface ApprovalAnswerPayload { readonly request: string; readonly outcome: 'allowed-once' | 'rejected' }

/**
 * One subagent the session spawned, mirrored from the host's `SubagentDescriptor`.
 * The host feeds the list from `subagent/descriptor` session events; the renderer
 * never sees those events, so the list arrives as `subagent-list`.
 */
export interface SubagentDescriptor {
  readonly label: string
  readonly provider: string
  readonly mode: 'one-shot' | 'continuable'
}

export interface SubagentListPayload {
  readonly sessionId: string
  readonly agents: readonly SubagentDescriptor[]
}
/**
 * One skill the workspace snapshot carries, mirrored from the host's `SkillSpec`. The
 * renderer's palette shows the list under a skills category; picking a row sends the
 * `skill:` command upstream.
 */
export interface SkillSpec {
  readonly name: string
  readonly description: string
}
export interface SkillsListPayload {
  readonly sessionId: string
  readonly skills: readonly SkillSpec[]
}

/** Token usage and context occupancy, scoped to one session. */
export interface UsagePayload {
  readonly sessionId: string
  readonly inputTokens: number
  readonly outputTokens: number
  readonly cacheReadTokens?: number
  readonly cacheWriteTokens?: number
  /** At least one sample explicitly reported cache-read tokens. */
  readonly cacheReadObserved?: boolean
  readonly cacheReadComplete?: boolean
  readonly cacheWriteComplete?: boolean
  readonly cacheBucketsComplete?: boolean
  readonly contextTokens?: number
  readonly contextWindow?: number
  readonly contextPct?: number
  readonly cost?: number
  /** ISO-4217 code the host priced `cost` in (`CNY` → `¥`). */
  readonly currency?: string
  /** Where `cost` came from: the provider's own bill, its unit prices, or our local table. */
  readonly costSource?: 'upstream-bill' | 'upstream-price' | 'local' | 'none'
  /** True when at least one folded sample had no resolvable model price. */
  readonly costUnavailable?: boolean
}

export interface ShellJobView {
  readonly id: string
  readonly kind: string
  readonly label: string
  readonly owner?: string
  readonly outputLimitBytes?: number
  readonly status: 'running' | 'stopping' | 'completed' | 'killed' | 'failed'
  readonly progress?: string
  readonly detail?: string
  readonly startedAt: number
  readonly finishedAt?: number
  readonly output: { readonly total: number; readonly earliest: number; readonly spillPaths?: readonly string[] }
}

export interface ShellJobsPayload { readonly sessionId: string; readonly jobs: readonly ShellJobView[] }
export interface ShellJobOpPayload { readonly sessionId: string; readonly id: string; readonly op: 'read' | 'kill'; readonly from?: number }


export interface TerminalShellInfo { readonly path: string; readonly args: readonly string[]; readonly name: string }
export interface TerminalEnvironmentInfo { readonly cwd: string; readonly maxInputBytes: number; readonly maxCols: number; readonly maxRows: number; readonly scrollback: number }
export interface WebTerminalInfo {
  readonly id: string
  readonly title: string
  readonly shell: TerminalShellInfo
  readonly cwd: string
  readonly cols: number
  readonly rows: number
  readonly state: 'running' | 'exited' | 'failed'
  readonly exitCode: number | null
  readonly error?: string
  readonly controllerId?: string
}
export type TerminalFrame =
  | { readonly type: 'snapshot'; readonly sequence: number; readonly screen: string; readonly info: WebTerminalInfo }
  | { readonly type: 'output'; readonly sequence: number; readonly data: string }
  | { readonly type: 'state'; readonly info: WebTerminalInfo }
export type TerminalOpPayload =
  | { readonly sessionId: string; readonly op: 'list' }
  | { readonly sessionId: string; readonly op: 'create'; readonly id: string; readonly cols: number; readonly rows: number; readonly shellPath?: string }
  | { readonly sessionId: string; readonly op: 'retain'; readonly id: string; readonly attachmentId: string }
  | { readonly sessionId: string; readonly op: 'release'; readonly id: string; readonly attachmentId: string }
  | { readonly sessionId: string; readonly op: 'follow'; readonly id: string; readonly attachmentId: string }
  | { readonly sessionId: string; readonly op: 'detach'; readonly id: string; readonly attachmentId: string }
  | { readonly sessionId: string; readonly op: 'write'; readonly id: string; readonly attachmentId: string; readonly data: string }
  | { readonly sessionId: string; readonly op: 'resize'; readonly id: string; readonly attachmentId: string; readonly cols: number; readonly rows: number }
  | { readonly sessionId: string; readonly op: 'close'; readonly id: string }
export interface TerminalFramePayload { readonly sessionId: string; readonly id: string; readonly attachmentId: string; readonly frame: TerminalFrame }
export interface TerminalEndPayload { readonly sessionId: string; readonly id: string; readonly attachmentId: string; readonly error?: string }
export interface GitBranchPayload {
  readonly sessionId: string
  readonly branch?: string
}

/** The MCP client's lifecycle phase, as the Loader reports it. */
export type McpLifecycleStatus = 'loading' | 'active' | 'pending' | 'unloading' | 'failed'

export interface McpServerItem {
  readonly id: string
  readonly name: string
  /** The real loader phase; absent means "not reported", never "connected". */
  readonly status?: McpLifecycleStatus | null
}

/**
 * The WeChat bridge's state as structure, not as a pre-joined line: the pane paints the
 * connection and the receiver lock on their own rows, and the renderer must not split a
 * ` · ` separated string to do it.
 */
export interface WechatStatusPayload {
  /** The bridge plugin is mounted in this process at all. */
  readonly available: boolean
  readonly connected: boolean
  readonly accounts: { readonly connected: number; readonly total: number }
  readonly lock: { readonly held: boolean; readonly pid?: number }
}

export interface McpServersPayload {
  readonly servers: readonly McpServerItem[]
}

export interface HostPluginItem {
  readonly id: string
  readonly moduleName: string
  readonly enabled: boolean
  readonly fiberPhase: 'pending' | 'loading' | 'active' | 'failed' | 'unloading' | null
}

export interface HostPluginsPayload {
  readonly plugins: readonly HostPluginItem[]
}

/** One todo row, forwarded from the host's `todo/write` session events. */
export interface TodoItem {
  readonly content: string
  readonly status: string
}

export interface TodosPayload {
  readonly sessionId: string
  readonly items: readonly TodoItem[]
}

export interface InterjectionItem {
  readonly id: string
  readonly text: string
}

export interface InterjectListPayload {
  readonly sessionId: string
  readonly items: readonly InterjectionItem[]
}

export interface InterruptPayload {
  readonly sessionId: string
}

/** Host → renderer: a plugin-owned dialog the renderer draws; the answer rides
 * `extension-dialog-response` on the same request id. */
export interface ExtensionDialogPayload {
  readonly requestId: number
  readonly kind: 'select' | 'confirm' | 'input'
  readonly title: string
  readonly options?: readonly { id: string; label: string; description?: string }[]
  readonly confirmLabel?: string
  readonly cancelLabel?: string
  readonly initial?: string
  readonly placeholder?: string
}

/** Renderer → host: the answer to an extension dialog. */
export interface ExtensionDialogResponsePayload {
  readonly requestId: number
  readonly value: string | undefined
}

/** Renderer → host: a keypress the renderer's keymap did not consume, normalized to
 * the canonical combo (`ctrl+o`, `shift+ctrl+p`). The host matches it against the
 * plugin shortcut registrations and dispatches a hit. */
export interface ShortcutPayload {
  readonly combo: string
}


/**
 * One transcript entry, mirrored from the host's `TranscriptEvent`. The host normalizes
 * the session log into these rows and sends them as `session-snapshot` / `session-frame`.
 */
export interface TranscriptAttachment {
  readonly type: 'image' | 'file'
  readonly attachmentId: string
  readonly name?: string
  readonly mediaType?: string
}

export interface TranscriptEvent {
  readonly id: string
  readonly role: 'user' | 'assistant' | 'system' | 'tool'
  readonly text?: string
  readonly tool?: string
  readonly toolOutput?: readonly string[]
  /** The call's string scalar arguments (shell `command`, `read` `path`, `grep` `pattern`,
   * …). Upstream paints the tool header from these (`$ <command>`, `Read <path>`). */
  readonly toolInput?: Readonly<Record<string, string>>
  readonly reasoning?: string
  readonly streaming?: boolean
  /** The step's reasoning is over: the header switches from `Thinking` to `Thought`. */
  readonly reasoningDone?: boolean
  readonly filePath?: string
  readonly diff?: readonly string[]
  readonly status?: 'pending' | 'ok' | 'failed' | 'denied'
  readonly model?: string
  readonly durationMs?: number
  /** The whole turn's model time in ms (tool execution excluded). */
  readonly turnDurationMs?: number
  readonly tokPerSec?: number
  /** `true` on the one assistant row of a turn that paints the footer. */
  readonly footer?: boolean
  readonly interrupted?: boolean
  /** Durable attachment references the message carried; open one through `attachment-read`. */
  readonly attachments?: readonly TranscriptAttachment[]
  readonly error?: string
  /** Who produced a `user` row; anything but `user` is system-injected context that the
   * transcript never prints. */
  readonly source?: string
  /** The log sequence this row came from. */
  readonly sourceSeq?: number
  /** The event's timestamp (ms since the epoch) when the log records one. */
  readonly createdAt?: number
  /** First answer text timestamp for a live row. Durable replays fall back to createdAt. */
  readonly bodyAt?: number
  /** The turn and step the row belongs to. */
  readonly turn?: number
  readonly step?: number
  /** The tool call id a tool row answers. */
  readonly callId?: string
  /** The complete parsed call arguments. */
  readonly toolArguments?: unknown
  /** The message's content blocks. */
  readonly content?: readonly unknown[]
}
/** Capabilities this renderer declares in the handshake. */
export const RENDERER_CAPABILITIES = ['transcript', 'composer', 'dialog', 'scrollbar', 'mouse'] as const

/** Negotiation vocabulary, shared with the host's plugin-spec admission. */
export type NegotiationStatus = 'compatible' | 'compatible_degraded' | 'waiting_authorization' | 'rejected' | 'unknown'

/** The host's answer to the handshake. */
export interface HelloAckPayload {
  readonly protocolVersion: number
  readonly hostId: string
  readonly hostVersion: string
  readonly capabilities: readonly string[]
  readonly status: NegotiationStatus
  readonly reasons: readonly string[]
  /** The grid the host read from its environment; the renderer seeds its own geometry from it. */
  readonly terminalSize?: { readonly width: number; readonly height: number }
}
