/**
 * The renderer shell.
 *
 * The opencode v2 layout: a Home route (wordmark, centered prompt, global footer) and a
 * session route (tab strip, transcript viewport, pinned prompt stack, optional sidebar
 * and terminal pane). A signal store fed by the IPC layer owns every value; the shell
 * paints it and routes keys through the layered keymap.
 */

import { Buffer } from 'node:buffer'
import { open, mkdir, writeFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { useRenderer } from '@opentui/solid'
import { createEffect, createMemo, createSignal, For, type JSX, onCleanup, onMount } from '#solid'
import { createStore, reconcile } from '#solid/store'
import { createTextAttributes, type PasteEvent, type ScrollBoxRenderable } from '@opentui/core'
import { usePaste, useTerminalDimensions } from '@opentui/solid'
import type { FormFieldSpec, HostPluginItem, IpcEnvelope, InterjectionItem, McpServerItem, NegotiationStatus, QuestionAnswerItem, QuestionSpec, ShellJobView, SkillSpec, SubmittedAttachment, SubagentDescriptor, TerminalEndPayload, TerminalFrame, TerminalFramePayload, TerminalEnvironmentInfo, TodoItem, TranscriptEvent, UsagePayload, WechatStatusPayload, WebTerminalInfo } from './protocol/kinds.ts'

import { activeDecreaseHex, activeTokenHex } from './theme/paths.ts'
import type { ThemeStorage } from './theme/provider.tsx'
import { themeControls } from './theme/controls.ts'
import { paletteOptions } from './component/command-palette.tsx'
import { DialogBackdrop, DialogPanel, type DialogController, type DialogSpec } from './ui/dialog.tsx'
import { DialogSelect } from './ui/dialog-select.tsx'
import { DialogAlert, DialogConfirm, DialogPrompt } from './ui/dialog-forms.tsx'
import { DialogFields } from './ui/dialog-fields.tsx'
import { DialogQuestion } from './ui/dialog-question.tsx'
import { trailingMention } from './ui/paths.ts'
import { lastArgumentToken, type CompletionCatalogs } from './ui/completions.ts'
import { AutocompletePopup, completionRows, type CompletionRow } from './ui/autocomplete.tsx'
import { TranscriptRow as SessionRow } from './ui/transcript.tsx'
import { planThinking, type ThinkingModeOverride, type ThinkingPlan } from './ui/thinking.ts'
import { MarkdownText } from './ui/markdown.tsx'
import { Home } from './ui/home.tsx'
import { formatStatusBarSecondLine, statusBarFirstLine, statusBarMetrics, statusBarRunningLine, statusHintSegments } from './ui/status-bar.ts'
import { formatSessionActivityLabel } from './ui/session-activity-label.ts'
import { formatDisplayPath, type PathDisplayMode } from './ui/path-display.ts'
import { createToastQueue, ToastOverlay } from './ui/toast.tsx'
import { createTuiAttention, type Attention } from './attention.ts'
import { createTuiClipboard, type ClipboardService } from './clipboard.ts'
import { createLocalStorage, type LocalStorage } from './storage.ts'
import { openEditor } from './editor.ts'
import { displayWidth, formatTokens, truncate, truncateLeft, truncateMiddle } from './ui/text.ts'
import { clampPaneWidth, PROMPT_CHROME_ROWS, shellPadding, SIDEBAR_WIDTH, sidebarDocked } from './ui/layout.ts'

/** The pinned metrics row at the bottom edge. The cwd row rides the prompt stack instead,
 * so it follows the input box (docked with the prompt in a session, floating with it on
 * Home); only this row is outside the routes. */
const STATUS_METRICS_ROWS = 1
/** The cwd/hint row: it closes the prompt stack, so it counts toward the popup anchor. */
const STATUS_CWD_ROWS = 1
import { SessionStrip } from './ui/session-tabs.tsx'
import { JumpToLatest } from './ui/jump-to-latest.tsx'
import { conversationStats } from './ui/conversation-stats.ts'
import { DRAFT_TAB_ID, closeOtherTabs as closeOtherTabsState, closeTab as closeTabState, cycleTabId, decodeTabs, emptyTabsState, encodeTabs, moveTab as moveTabState, openTab as openTabState, promoteDraft as promoteDraftState, pruneTabs, reopenLastTab, type TabsState } from './ui/session-tabs-model.ts'
import { Sidebar, SidebarOverlay } from './ui/sidebar.tsx'
import { UNTITLED } from './ui/session-tabs.tsx'
import { PaneResizeHandle } from './ui/pane-resize.tsx'
import { getScrollAcceleration } from './ui/scroll.ts'
import { Spinner, useSpinner } from './ui/spinner.tsx'
import { SubagentDock } from './ui/subagent-dock.tsx'
import { QueuedDock } from './ui/queued-dock.tsx'
import { DialogShellOutput } from './ui/dialog-shell-output.tsx'
import { DialogTrace } from './ui/dialog-trace.tsx'
import { buildTraceRows, type TraceLabels, type TraceRow } from './ui/trace-model.ts'
import { TerminalPane } from './component/terminal-pane.tsx'
import { EMPTY_BORDER, PROMPT_CORNER_BORDER, SHADOW_LIP_BORDER, SHADOW_LIP_EDGE, SPLIT_BORDER } from './ui/border.ts'
import { PromptMetadata } from './ui/prompt-metadata.tsx'
import type { KeyLayer } from './keymap/keymap.ts'

type TerminalKeyInput = { readonly name: string; readonly ctrl: boolean; readonly shift: boolean; readonly meta: boolean; preventDefault?: () => void; stopPropagation?: () => void }
type PendingAttachment = { readonly id: string; readonly owner: string; readonly label: string; readonly submitted: SubmittedAttachment }
const MAX_LOCAL_ATTACHMENT_BYTES = 20 * 1024 * 1024
/** The renderer's live view of host state, filled by the IPC layer.
 * `send` is the upstream channel: the composer and the keymap use it to ask the
 * host to perform something, and returns the sequence the envelope went out on so
 * a request can be matched with the host's answer. It defaults to a no-op returning
 * `0` so the store can be built in tests without a channel. */
export function createAppStore(
  send: (kind: string, payload: unknown) => number = () => 0,
  /** Rejects every settings write still waiting for its answer when the channel closes, so
   * a save never hangs after the host goes away. */
  registerUpdateRejector: (reject: (reason: string) => void) => void = () => undefined,
  /** The renderer's own exit: the renderer owns the TTY, so `/exit` restores it and leaves
   * instead of asking the host and waiting for the channel to close under it. */
  requestExit: () => void = () => undefined,
) {
  const [status, setStatus] = createSignal<NegotiationStatus>('waiting_authorization')
  const [hostLabel, setHostLabel] = createSignal('host: not connected')
  /** The host's own version, without the `host:` prefix: the home route stamps it in the
   * bottom-right corner (opencode's build stamp). */
  const [hostVersion, setHostVersion] = createSignal('')
  /** The host advertised daemon detach: /exit leaves the core and its tasks alive. */
  const [daemonDetach, setDaemonDetach] = createSignal(false)
  const [sessionTitle, setSessionTitle] = createSignal('no session')
  const [route, setRoute] = createSignal<'home' | 'session'>('home')
  const [readOnly, setReadOnly] = createSignal(false)
  const sessionDrafts = new Map<string, string>()
  let homeDraft = ''
  // The transcript rows are a Solid store keyed by row id, not a signal whose array is
  // rebuilt on every frame. `<For>` reconciles by item identity, so the old
  // `next[index] = row` replacement tore the row's subtree down and rebuilt its Markdown
  // renderable for each streamed character — the visible flicker. `reconcile(…, { key:
  // 'id' })` keeps the existing proxy for an id and updates only the fields that changed,
  // so a streaming answer grows inside one mounted row.
  const [transcriptStore, setTranscriptStore] = createStore<TranscriptEvent[]>([])
  /** The plain rows behind the store: a merge copy-on-writes this array, and the store is
   * only the reactive projection of it. */
  let transcriptPlain: TranscriptEvent[] = []
  const transcript = (): TranscriptEvent[] => transcriptStore
  /**
   * A monotonic counter that changes whenever the transcript changes.
   *
   * `transcript()` returns the store proxy without reading a property, so it tracks array
   * shape but not the fields of a row: a text delta that rewrites `text` in place fires no
   * effect that only calls `transcript()`. Anything whose job is "the transcript moved"
   * (the sticky-bottom clamp) must read this instead.
   */
  const [transcriptRevision, setTranscriptRevision] = createSignal(0)
  const publishTranscript = (rows: TranscriptEvent[]): void => {
    transcriptPlain = rows
    setTranscriptStore(reconcile(rows, { key: 'id' }))
    setTranscriptRevision(revision => revision + 1)
  }
  const setTranscript = (next: TranscriptEvent[] | ((current: TranscriptEvent[]) => TranscriptEvent[])): void => {
    publishTranscript(typeof next === 'function' ? next(transcriptPlain) : [...next])
  }
  /**
   * Merge one session frame. The hot path is an assistant stream delta that repeats one row
   * id: the array is copied once and only that row is replaced, so every other row keeps its
   * identity (and every mounted Markdown renderable stays alive).
   */
  const mergeTranscript = (incoming: readonly TranscriptEvent[]): void => {
    if (incoming.length === 0) return
    const indexById = new Map(transcriptPlain.map((row, index) => [row.id, index]))
    let next: TranscriptEvent[] | undefined
    for (const row of incoming) {
      const index = indexById.get(row.id)
      if (index === undefined) {
        next ??= [...transcriptPlain]
        next.push(row)
        indexById.set(row.id, next.length - 1)
        continue
      }
      next ??= [...transcriptPlain]
      next[index] = row
    }
    if (next !== undefined) publishTranscript(next)
  }
  let draftRevision = 0
  let draftPersistTimer: ReturnType<typeof setTimeout> | undefined
  interface StoredDrafts { version: number; home: string; sessions: Record<string, string>; savedAt: number }
  const scheduleDraftPersist = (): void => {
    if (localStorage === undefined) return
    if (draftPersistTimer !== undefined) clearTimeout(draftPersistTimer)
    draftPersistTimer = setTimeout(() => {
      draftPersistTimer = undefined
      const sessions: Record<string, string> = {}
      for (const [id, text] of sessionDrafts) if (text !== '') sessions[id] = text
      void localStorage?.update<StoredDrafts>('drafts', { version: 1, home: '', sessions: {}, savedAt: 0 }, draft => {
        draft.version = 1
        draft.home = homeDraft
        draft.sessions = sessions
        draft.savedAt = Date.now()
      }).catch(() => undefined)
    }, 150)
    draftPersistTimer.unref?.()
  }
  const loadDrafts = async (): Promise<void> => {
    const stored = await localStorage?.read<StoredDrafts>('drafts').catch(() => undefined)
    if (stored === undefined) return
    if (homeDraft === '' && typeof stored.home === 'string') homeDraft = stored.home
    if (stored.sessions !== null && typeof stored.sessions === 'object') {
      for (const [id, text] of Object.entries(stored.sessions)) {
        if (typeof text === 'string' && (sessionDrafts.get(id) ?? '') === '') sessionDrafts.set(id, text)
      }
    }
    if (composer() !== '') return
    if (route() === 'home' && homeDraft !== '') setComposer(homeDraft)
    else if (route() === 'session' && currentSession() !== '') setComposer(sessionDrafts.get(currentSession()) ?? '')
  }
  // The first snapshot chooses the initial route; later snapshots follow the active one.
  let routeInitialized = false
  let pendingSwitchSessionId: string | undefined
  const [composer, setComposerText] = createSignal('')
  // `escape` closes the popup without touching the draft: the popup stays hidden until the
  // composer text changes again.
  const setComposer = (text: string): void => {
    if (composer() !== text) {
      draftRevision += 1
      setComposerText(text)
    }
    if (route() === 'home') homeDraft = text
    else if (currentSession() !== '') sessionDrafts.set(currentSession(), text)
    scheduleDraftPersist()
    setCompletionClosed(false)
  }
  /** The image preview overlay: the host-read bytes, painted by the shell's image block. */
  const [attachmentPreview, setAttachmentPreview] = createSignal<{ readonly name: string; readonly mediaType: string; readonly bytes: Uint8Array } | undefined>(undefined)
  /** The toast queue: the last three notices the host pushed, painted top-right. A notice
   * never enters the main column, so the transcript, prompt, and footer keep their rows. */
  /** The clipboard, created by the shell once it has a renderer. */
  let clipboard: ClipboardService | undefined
  const setClipboard = (service: ClipboardService | undefined): void => {
    const previous = clipboard
    clipboard = service
    if (previous !== undefined && previous !== service) void previous.dispose().catch(() => undefined)
  }
  /**
   * `leader e`: open the draft in `$VISUAL` / `$EDITOR`. The renderer is suspended by the
   * editor itself; the returned text replaces the draft, and a failed run is a real notice.
   */
  const openExternalEditor = (): void => {
    const view = shellRenderer as unknown as Parameters<typeof openEditor>[0]['renderer'] | undefined
    if (view === undefined) return
    void openEditor({
      value: composer(),
      renderer: view,
      ...(workspace() === '' ? {} : { cwd: workspace() }),
    }).then(content => {
      if (content === undefined) return
      setComposer(content)
      ;(composerBuffer as { setText?: (text: string) => void } | undefined)?.setText?.(content)
    }).catch((error: unknown) => {
      pushNotice('error', `Failed to open editor: ${error instanceof Error ? error.message : String(error)}`)
    })
  }
  /** `prompt.paste`: read the system clipboard, then paste an image or the text. */
  const pasteFromClipboard = (): void => {
    const service = clipboard
    if (service === undefined) {
      pushNotice('error', 'The clipboard is not available')
      return
    }
    void service.read().then(content => {
      if (content === undefined) return
      if (content.mime.startsWith('image/')) {
        const buffer = Buffer.from(content.data, 'base64')
        const mediaType = content.mime === 'image/jpeg' || content.mime === 'image/webp' || content.mime === 'image/gif' ? content.mime : 'image/png'
        if (route() !== 'home' && pendingHomeSessionId === undefined && !attachmentCapabilities().images) {
          pushNotice('error', 'The selected model route does not support pasted images')
          return
        }
        const item: PendingAttachment = { id: crypto.randomUUID(), owner: attachmentOwner(), label: `clipboard.${mediaType.slice('image/'.length)}`, submitted: { type: 'image', mediaType, data: buffer.toString('base64'), name: `clipboard.${mediaType.slice('image/'.length)}` } }
        setPendingAttachments(current => [...current, item])
        return
      }
      if (content.mime === 'text/plain') {
        const text = content.data
        setComposer(composer() + text)
        ;(composerBuffer as { setText?: (text: string) => void } | undefined)?.setText?.(composer() + text)
      }
    }).catch((error: unknown) => {
      pushNotice('error', `Clipboard read failed: ${error instanceof Error ? error.message : String(error)}`)
    })
  }
  /** `leader y`: copy the newest assistant answer, the row a reader most often wants. */
  const copyLastMessage = (): void => {
    const row = [...transcript()].reverse().find(candidate => candidate.role === 'assistant' && (candidate.text ?? '') !== '')
    if (row === undefined) {
      pushNotice('warning', 'No assistant message to copy')
      return
    }
    const service = clipboard
    if (service === undefined) {
      pushNotice('error', 'The clipboard is not available')
      return
    }
    void service.write(row.text ?? '').then(
      () => pushNotice('info', 'Copied the last message'),
      (error: unknown) => pushNotice('error', `Clipboard write failed: ${error instanceof Error ? error.message : String(error)}`),
    )
  }
  /** The services the shell created; shutdown flushes and disposes them once. */
  let attention: Attention | undefined
  /**
   * Shutdown step one: wait for the local file writes (history, tabs) started so far. A
   * failure is the caller's to report; this only guarantees the wait happened.
   */
  const flushLocalState = async (): Promise<void> => {
    await localStorage?.flush()
  }
  /** Shutdown step two: dispose the clipboard and the audio device. */
  const disposeServices = async (): Promise<void> => {
    const clip = clipboard
    clipboard = undefined
    if (clip !== undefined) await clip.dispose()
    const { dispose: disposeAudio } = await import('./audio.ts')
    disposeAudio()
  }
  const setAttention = (service: Attention | undefined): void => {
    attention?.dispose()
    attention = service
  }
  /** One turn finished: a notification and a sound for the session that just went idle. */
  const notifyTurnFinished = async (): Promise<void> => {
    if (attention === undefined) return
    try {
      await attention.notify({ message: sessionTitle() === '' ? currentSession() : sessionTitle(), notification: { when: 'blurred' }, sound: true })
    } catch (error: unknown) {
      pushNotice('error', error instanceof Error ? error.message : String(error))
    }
  }
  /** The renderer the mounted shell runs in; `cancel` needs its text selection. */
  let shellRenderer: { readonly hasSelection?: boolean; clearSelection?: () => void } | undefined
  const toastQueue = createToastQueue()
  /** The workspace paths the host's index pushed; `@` completion never walks the disk. */
  const [mentions, setMentions] = createSignal<string[]>([])
  /** The native command ids the host reported for the foreground session. Only these
   * are offered; a command the host cannot run here is not registered at all. */
  const [availableActions, setAvailableActions] = createSignal<string[]>([])
  const [attachmentCapabilities, setAttachmentCapabilities] = createSignal({ files: false, images: false })
  const [pendingAttachments, setPendingAttachments] = createSignal<PendingAttachment[]>([])
  const [efforts, setEfforts] = createSignal<string[]>([])
  const [effortCurrent, setEffortCurrent] = createSignal('')
  /** The active route and switches the host reports in the snapshot. The status row
   * shows them; the pickers write them back through `set-selection`. */
  const [provider, setProvider] = createSignal('')
  const [model, setModel] = createSignal('')
  const [permission, setPermission] = createSignal('')
  const [preset, setPreset] = createSignal('')
  const [sessions, setSessions] = createSignal<Array<{ id: string; title: string; active: boolean; workspace?: string; parentId?: string; sessionKind?: 'main' | 'subagent'; canInteract?: boolean; createdAt?: number; lastActivityAt?: number; status?: 'idle' | 'running'; attention?: boolean; blank?: boolean }>>([])
  const [currentSession, setCurrentSession] = createSignal('')
  const [workspace, setWorkspace] = createSignal('')
  const [settings, setSettings] = createSignal<Record<string, unknown>>({})
  /** Display-only path rendering. Every request, attachment, shell and export keeps raw paths. */
  const pathDisplayMode = (): PathDisplayMode => settings().pathDisplay === 'full' ? 'full' : 'tilde'
  const displayPath = (value: string): string => formatDisplayPath(value, { home: homedir(), mode: pathDisplayMode() })
  /** Monotonic suffix for `update-settings` request ids. */
  let nextSettingsId = 0
  let pendingHomeSessionId: string | undefined
  /** The real session the Home draft is waiting to become; guards unrelated snapshots. */
  let draftTargetId: string | undefined
  // The WeChat bridge pushes `qr` / `status` / `log` / `error` lines. The QR block is
  // kept as its own signal so the scan block stays on screen until login replaces it,
  // and the status line is a single segment the footer shows.
  const [wechatQr, setWechatQr] = createSignal('')
  const [wechatStatus, setWechatStatus] = createSignal('')
  /** The bridge's structured state; `undefined` means it never reported (bridge absent). */
  const [wechatState, setWechatState] = createSignal<WechatStatusPayload | undefined>(undefined)
  /** Which collapsible sidebar sections are folded. MCP and TODO start expanded; a
   * process restart returns to these defaults. */
  const [sidebarCollapsed, setSidebarCollapsed] = createSignal<{ mcp: boolean; todo: boolean; subagents: boolean; background: boolean }>({ mcp: false, todo: false, subagents: true, background: true })
  const toggleSidebarSection = (section: 'mcp' | 'todo' | 'subagents' | 'background'): void => {
    setSidebarCollapsed(previous => ({ ...previous, [section]: !previous[section] }))
  }
  /** The subagents the host pushed. The rail row lists them; an empty list paints nothing. */
  const [subagents, setSubagents] = createSignal<SubagentDescriptor[]>([])
  /** The skills the host pushed. The palette's skills category lists them. */
  const [skills, setSkills] = createSignal<SkillSpec[]>([])
  /** The provider, permission, and mode catalogs the host pushed at ack. The palette's
   * picker groups list them; the current marker follows the snapshot's live route, not
   * the payload's flag, so a pick re-marks the row the host writes back. */
  const [providers, setProviders] = createSignal<Array<{ id: string; label: string; api: string }>>([])
  const [permissionPresets, setPermissionPresets] = createSignal<Array<{ id: string; label: string }>>([])
  const [agentPresets, setAgentPresets] = createSignal<Array<{ id: string; label: string }>>([])
  /**
   * The preset's display name: the catalog label, or the id when the roster has no name.
   * Every surface that names the agent — the prompt's metadata row on both routes, the
   * assistant footer, the details page — reads it from here, so one screen never says
   * `标准模式` while another says `standard`.
   */
  const presetLabel = (): string => {
    const id = preset()
    return agentPresets().find(entry => entry.id === id)?.label ?? id
  }
  /** The prompt's mode slot: built-in ids get the localized `…模式` spelling, custom
   * presets keep the catalog's own name. */
  const modeLabel = (): string => {
    const id = preset()
    const key = id === 'standard' ? 'modeStandard'
      : id === 'minimal' ? 'modeMinimal'
        : id === 'code' ? 'modeCode'
          : id === 'cordis' ? 'modeCordis'
            : undefined
    if (key === undefined) return presetLabel()
    const suffix = label('rendererModeSuffix', '模式')
    const catalog = presetLabel()
    // The roster label already owns localized spelling (`标准模式`, `minimal`); only add
    // the suffix when the catalog exposes the bare id or a suffix-less name.
    if (catalog !== id) return catalog.endsWith('模式') || catalog.endsWith(' mode') ? catalog : `${catalog}${suffix}`
    const fallback = id === 'standard' ? '标准'
      : id === 'minimal' ? '极简'
        : id === 'code' ? 'PTC'
          : '创造'
    return `${label(key, fallback)}${suffix}`
  }
  /** The prompt's permission slot. dsh may expose either its friendly preset id or the
   * older `danger-full-access` spelling; both name the same permission mode. */
  const permissionLabel = (): string => {
    const raw = permission()
    if (raw === 'auto' || raw === 'autoaccept') return label('rendererPermissionAuto', '自动')
    if (raw === 'full-access' || raw === 'danger-full-access') return label('rendererPermissionFullAccess', '完全权限')
    if (raw === 'workspace-write') return label('rendererPermissionWorkspaceWrite', '工作区写入')
    if (raw === 'read-only') return label('rendererPermissionReadOnly', '只读')
    return raw
  }
  /** The session's measured token usage and context occupancy; the footer's context
   * segment and the sidebar's Context block read it. `cost` is the host's local pricing
   * estimate; an unknown model leaves it undefined so the sidebar shows `$ —`. */
  const [usage, setUsage] = createSignal<UsagePayload | undefined>(undefined)
  /** The workspace's git branch, read from `.git` by the host. */
  const [gitBranch, setGitBranch] = createSignal<string | undefined>(undefined)
  /** Real configured MCP server names; no connection state is inferred. */
  const [mcpServers, setMcpServers] = createSignal<McpServerItem[]>([])
  /** Real Loader plugin inventory; fiber phase is diagnostic only. */
  const [hostPlugins, setHostPlugins] = createSignal<HostPluginItem[]>([])
  /** The right sidebar's state. `auto` is the spec's arbitration: it docks when the
   * terminal leaves more than 120 cells after the rail, and stays closed otherwise.
   * `leader b` flips it to `open` (docked when it fits, overlay when it does not) and
   * then to `closed`, so the key can hide an auto-docked pane on a wide terminal. */
  const [sidebarState, setSidebarState] = createSignal<'auto' | 'open' | 'closed'>('auto')
  /** The docked pane's width; the resize handle moves it through `clampPaneWidth`. */
  const [sidebarWidth, setSidebarWidth] = createSignal(SIDEBAR_WIDTH)
  /** The session's todo list, forwarded from `todo/write` events. */
  const [todos, setTodos] = createSignal<TodoItem[]>([])
  /** The pending interjection queue the host pushed; the drawer's queued tab shows it. */
  const [interjections, setInterjections] = createSignal<InterjectionItem[]>([])
  const [shellJobs, setShellJobs] = createSignal<ShellJobView[]>([])
  /** Shell jobs by owner session, so the Background tasks rail can see every session. */
  const [shellJobsByOwner, setShellJobsByOwner] = createSignal<Record<string, ShellJobView[]>>({})
  const [terminalOpen, setTerminalOpen] = createSignal(false)
  const [terminalSessionId, setTerminalSessionId] = createSignal('')
  const [terminalInfo, setTerminalInfo] = createSignal<WebTerminalInfo | undefined>(undefined)
  const [terminalEnvironment, setTerminalEnvironment] = createSignal<TerminalEnvironmentInfo | undefined>(undefined)
  const [terminalAttachmentId, setTerminalAttachmentId] = createSignal('')
  const [terminalFrames, setTerminalFrames] = createSignal<TerminalFrame[]>([])
  const [terminalEndError, setTerminalEndError] = createSignal<string | undefined>(undefined)
  let terminalKeyHandler: ((event: TerminalKeyInput) => boolean) | undefined
  /** The drawer's active tab: 0 subagents, 1 history, 2 queued. */
  // The host sends the locale and the dictionary over IPC; before `i18n` arrives the
  // shell paints with its built-in English labels, so the first frame is never blank.
  const [strings, setStrings] = createSignal<Record<string, string>>({})
  const [locale, setLocale] = createSignal('en')
  /** One label, falling back to the built-in English text the shell ships with. */
  const label = (key: string, fallback: string): string => strings()[key] ?? fallback
  /** The chip a session with no title wears: one spelling for the strip, the pane, and
   * the picker, in the host dictionary's language. */
  const untitledLabel = (): string => label('rendererUntitled', UNTITLED)
  /** The full interaction timeline shown by /trace. */
  const traceRows = (): readonly TraceRow[] => {
    const labels: TraceLabels = {
      user: label('rendererTraceUser', 'user'),
      assistant: label('rendererTraceAssistant', 'assistant'),
      tool: label('rendererTraceTool', 'tool'),
      system: label('rendererTraceSystem', 'system'),
      seq: label('rendererTraceSeq', 'seq'),
      turn: label('rendererTraceTurn', 'turn'),
      step: label('rendererTraceStep', 'step'),
      status: label('rendererTraceStatus', 'status'),
    }
    return buildTraceRows(transcript(), labels)
  }
  /** One notice lands as a toast. The renderer never writes to stderr (Bun closes the IPC
   * channel on the first stderr write), so warnings route here and paint in the overlay.
   * `level` picks the border color; the queue keeps the last three. */
  const pushNotice = (level: 'info' | 'warning' | 'error', text: string): void => {
    toastQueue.show({ level, text })
  }
  const attachPastedFiles = async (paths: readonly string[]): Promise<void> => {
    const owner = attachmentOwner()
    const admitted: PendingAttachment[] = []
    try {
      for (const path of paths) {
        const file = await open(path, 'r')
        try {
          const chunks: Buffer[] = []
          let total = 0
          const stream = file.createReadStream({ highWaterMark: 64 * 1024, autoClose: false })
          for await (const chunk of stream) {
            total += chunk.byteLength
            if (total > MAX_LOCAL_ATTACHMENT_BYTES) throw new Error(`${path} exceeds the 20 MiB attachment limit`)
            chunks.push(Buffer.from(chunk))
          }
          const name = path.split(/[\\/]/).at(-1) || 'attachment'
          admitted.push({
            id: crypto.randomUUID(),
            owner,
            label: name,
            submitted: { type: 'file', data: Buffer.concat(chunks, total).toString('base64'), name },
          })
        } finally {
          await file.close()
        }
      }
      setPendingAttachments(current => [...current, ...admitted])
    } catch (error: unknown) {
      pushNotice('error', error instanceof Error ? error.message : String(error))
    }
  }
  const handlePaste = (event: PasteEvent): void => {
    const mimeType = event.metadata?.mimeType
    if (mimeType === 'text/uri-list') {
      event.preventDefault()
      const entries = Buffer.from(event.bytes).toString('utf8').split(/\r?\n/).map(line => line.trim()).filter(line => line !== '' && !line.startsWith('#'))
      try {
        const paths = entries.map(entry => {
          const url = new URL(entry)
          if (url.protocol !== 'file:') throw new Error(`unsupported pasted URI scheme: ${url.protocol}`)
          return fileURLToPath(url)
        })
        if (paths.length > 0) void attachPastedFiles(paths)
      } catch (error: unknown) {
        pushNotice('error', error instanceof Error ? error.message : String(error))
      }
      return
    }
    if (event.metadata?.kind === 'text' || (mimeType === undefined && event.metadata?.kind !== 'binary')) return
    const mediaType = mimeType === 'image/png' || mimeType === 'image/jpeg' || mimeType === 'image/webp' || mimeType === 'image/gif'
      ? mimeType
      : undefined
    if (mediaType === undefined) {
      if (event.metadata?.kind === 'binary' || mimeType?.startsWith('image/')) {
        event.preventDefault()
        pushNotice('error', `Unsupported pasted attachment type${mimeType === undefined ? '' : `: ${mimeType}`}`)
      }
      return
    }
    event.preventDefault()
    if (route() !== 'home' && pendingHomeSessionId === undefined && !attachmentCapabilities().images) {
      pushNotice('error', 'The selected model route does not support pasted images')
      return
    }
    if (event.bytes.byteLength > MAX_LOCAL_ATTACHMENT_BYTES) {
      pushNotice('error', 'Pasted image exceeds the 20 MiB attachment limit')
      return
    }
    const extension = mediaType === 'image/jpeg' ? 'jpg' : mediaType.slice('image/'.length)
    const id = crypto.randomUUID()
    const label = `pasted-image.${extension}`
    setPendingAttachments(current => [...current, {
      owner: attachmentOwner(),
      id,
      label,
      submitted: { type: 'image', mediaType, data: Buffer.from(event.bytes).toString('base64'), name: label },
    }])
  }
  const removePendingAttachments = (ids: ReadonlySet<string>): void => {
    if (ids.size === 0) return
    setPendingAttachments(current => current.filter(item => !ids.has(item.id)))
  }
  const attachmentOwner = (): string => pendingHomeSessionId === undefined ? (route() === 'home' ? 'home' : currentSession()) : 'home'
  const pendingAttachmentsForCurrent = (): PendingAttachment[] => pendingAttachments().filter(item => item.owner === attachmentOwner())
  /** A click on a toast dismisses the visible one; the next in the queue takes over. */
  const dismissToast = (): void => toastQueue.dismiss()
  /** The expanded textarea, registered by the shell. The history keys read its caret so
   * `up` only leaves the draft at the first visual line (opencode's rule); with no textarea
   * registered (a store built in tests) the keys always recall. */
  let composerBuffer: { plainText: string; cursorOffset: number; logicalCursor?: { row: number } } | undefined
  /** The highlighted popup row. It resets to the first row when a completion is accepted. */
  const [completionSelection, setCompletionSelection] = createSignal(0)
  /** The popup was dismissed with `escape`; a draft change re-opens it. */
  const [completionClosed, setCompletionClosed] = createSignal(false)
  // The popup accepted a row on this keystroke: the textarea's submit handler must not
  // also send the draft, so the flag tells the submit side that `return` was consumed.
  const [popupAccepted, setPopupAccepted] = createSignal(false)
  /** The reasoning blocks the user collapsed. Empty = expanded, which is dsh's default
   * (upstream's `session.thinking = "hide"` starts collapsed; the user chose the opposite
   * so the model's work is visible without a click). The set is immutable: every write
   * replaces it, so Solid sees a new reference and the row repaints. */
  const [collapsedReasoning, setCollapsedReasoning] = createSignal<ReadonlySet<string>>(new Set())
  const toggleReasoning = (id: string): void => {
    setCollapsedReasoning(current => {
      const next = new Set(current)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  /**
   * Explicit expand/collapse choices for compact thinking blocks. Only touched rows live in
   * this map; the default (preview while thinking, closed afterwards) stays derived. Each
   * write replaces the record so Solid sees a new signal value.
   */
  const [thinkingModes, setThinkingModes] = createSignal<Readonly<Record<string, ThinkingModeOverride>>>({})
  const thinkingMode = (id: string): ThinkingModeOverride | undefined => thinkingModes()[id]
  const toggleThinking = (id: string, live = false): void => {
    setThinkingModes(current => {
      const next = { ...current }
      if (current[id] === 'detail') {
        // A live block returns to its derived preview, preserving the 5–10 dynamic rows.
        // Once settled, the same action folds it to the compact header.
        if (live) delete next[id]
        else next[id] = 'closed'
        return next
      }
      next[id] = 'detail'
      return next
    })
  }
  /** The catalogs the slash-argument completion reads: the same signals the pickers use,
   * so a completion value is always one the host accepts. */
  const completionCatalogs = (): CompletionCatalogs => ({
    efforts: efforts(),
    permissions: permissionPresets(),
    modes: agentPresets(),
    sessions: sessions(),
    models: models(),
  })
  /**
   * The commands this renderer runs itself. `/` has to open a menu even when the host has
   * not pushed a `command-catalog` yet — a fresh Home session can render before that push,
   * and an empty catalog used to leave the popup with zero rows (the key appeared to do
   * nothing). These are exactly the names `interceptCommand` answers locally.
   */
  const localCommands = (): { name: string; description: string }[] => [
    { name: 'models', description: label('rendererSwitchModel', 'switch model') },
    { name: 'help', description: label('rendererPaletteHelp', 'key bindings') },
    { name: 'settings', description: label('rendererSettings', 'settings') },
    { name: 'themes', description: label('rendererThemes', 'themes') },
    { name: 'permission', description: label('rendererPermission', 'permission') },
    { name: 'agents', description: label('rendererMode', 'agent') },
    { name: 'skills', description: label('rendererSkills', 'skills') },
    { name: 'status', description: label('rendererDetails', 'session status') },
    { name: 'sessions', description: label('rendererSessionPicker', 'sessions') },
    { name: 'palette', description: label('rendererPalette', 'command palette') },
    { name: 'trace', description: label('rendererTrace', 'trace') },
    { name: 'effort', description: label('rendererThink', 'reasoning effort') },
    { name: 'queue', description: label('rendererQueue', 'queued messages') },
    { name: 'doctor', description: label('rendererDoctor', 'diagnostics') },
    { name: 'plugins', description: label('rendererPlugins', 'plugins') },
    { name: 'mcps', description: label('rendererMcp', 'MCP servers') },
    { name: 'rename', description: label('rendererRename', 'rename session') },
    { name: 'exit', description: label('rendererPaletteExit', 'exit TUI') },
    { name: 'shutdown', description: label('rendererShutdown', 'shut down core process') },
  ]
  /**
   * The catalog plus the renderer's own commands, host entries first and by name.
   *
   * The host's catalog covers what the harness registers; the local vocabulary covers what
   * this renderer intercepts (`/resume`, `/rename`, `/theme`, …). A host catalog that happens
   * to omit one of those must not make the key look dead: `/re` has to find `/resume` whether
   * or not the host listed it.
   */
  const slashCommands = (): readonly { name: string; description: string; argumentHint?: string }[] => {
    const merged = new Map<string, { name: string; description: string; argumentHint?: string }>()
    for (const command of commands()) merged.set(command.name, command)
    for (const command of localCommands()) if (!merged.has(command.name)) merged.set(command.name, command)
    return [...merged.values()]
  }

  /** The rows the composer is completing, from one call site so the popup, the keymap,
   * and `tab` can never disagree about what is on screen. */
  const completions = (): CompletionRow[] => completionRows(slashCommands(), mentions(), composer(), completionCatalogs())
  /** The popup is a pure function of the composer text: it owns the keyboard when it has
   * rows to show. */
  const popupOpen = (): boolean => !completionClosed() && (completions().length > 0 || completingToken())
  /**
   * A mention token the popup owns even with zero matches: the empty state tells the
   * writer that the path is not in the workspace, so the popup stays. A slash command
   * with no match is not the popup's business — the draft is handed to the host verbatim.
   */
  const completingToken = (): boolean => /(^|\s)@[^\s]*$/.test(composer())
  /** The layer that owns the keyboard: the dialog beats the popup, the popup beats the
   * focused composer, and the composer beats the session. */
  const keyLayer = (): KeyLayer => {
    if (dialogStack().length > 0) return 'modal'
    if (popupOpen()) return 'autocomplete'
    return 'composer'
  }
  /** Accept one popup row.
   *
   * A command row follows upstream's `slash.arguments ? insertSlash : command.run`: a
   * command that declares arguments is inserted with its trailing space, and a command
   * without them runs on the same keystroke. dsh's local pickers (`/theme`, `/model`,
   * `/help`, …) are a third case: they take a hint for the upstream parser but the bare
   * form opens the renderer's own dialog, so they must not wait for a second Enter.
   *
   * `setComposer` re-opens the popup (it clears `completionClosed`), so every write here
   * is followed by `setCompletionClosed(true)`: the popup must never outlive the accept. */
  const acceptCompletion = (row: CompletionRow): void => {
    const text = composer()
    setCompletionSelection(0)
    if (row.kind === 'command') {
      const name = row.name ?? row.label.replace(/^\//, '')
      // The draft is cleared first: an accepted command is a finished line, not a prefix.
      setComposer('')
      setCompletionClosed(true)
      if (interceptCommand(`/${name}`)) return
      if (row.takesArguments === true) {
        setComposer(`/${name} `)
        setCompletionClosed(true)
        return
      }
      runLine(`/${name}`)
      return
    }
    if (row.kind === 'argument') {
      // The trailing partial argument token is replaced; the rest of the draft (the
      // command and its earlier arguments) stays as typed.
      const head = text.slice(0, text.length - lastArgumentToken(text).length)
      setComposer(`${head}${row.label}`)
      setCompletionClosed(true)
      return
    }
    const token = trailingMention(text)
    if (token === undefined) return
    setComposer(text.slice(0, text.length - token.length) + row.label)
    setCompletionClosed(true)
  }
  /** The transcript viewport. The Shell registers the scrollbox on mount; the store drives
   * it, so `Jump to latest`, `pageup`, and `pagedown` all work through one path. */
  let scrollbox: ScrollBoxRenderable | undefined
  /** A bump signal the scrollbar and the transcript writes raise, so the jump row is a
   * reactive read of the viewport: without it the row would be computed once and never
   * repaint when the user wheels away from the newest message. */
  const [viewportEpoch, setViewportEpoch] = createSignal(0)
  const bumpViewport = (): void => {
    setViewportEpoch(epoch => epoch + 1)
  }
  const setScrollbox = (ref: ScrollBoxRenderable | undefined): void => {
    if (scrollbox !== undefined && scrollbox !== ref) scrollbox.verticalScrollBar.off('change', bumpViewport)
    scrollbox = ref
    if (ref !== undefined) ref.verticalScrollBar.on('change', bumpViewport)
    bumpViewport()
    settleStickyTop()
  }
  /** The viewport is not showing the newest row. The jump row appears only in this state. */
  const awayFromBottom = (): boolean => {
    viewportEpoch()
    if (scrollbox === undefined) return false
    return scrollbox.scrollTop + scrollbox.viewport.height < scrollbox.scrollHeight - 1
  }
  /**
   * OpenTUI 0.5.17 scrolls to `scrollHeight - viewport.height` when the sticky bottom is
   * applied, before the content has its final height, so a transcript shorter than the
   * viewport loses its first rows. This settles the viewport after layout: short content
   * sits at the top, and a sticky transcript sits on its newest row. A reader who
   * scrolled up keeps their position (sticky is off).
   */
  const settleStickyTop = (): void => {
    if (scrollbox === undefined) return
    if (scrollbox.scrollHeight <= scrollbox.viewport.height) {
      // Short content: pin to the top without leaving sticky mode, and reset the
      // scrollbox's private top/bottom flags so it does not pull the view back down.
      if (scrollbox.scrollTop !== 0) scrollbox.scrollTop = 0
      return
    }
  }

  /** Re-engage sticky scroll and land on the newest row. */
  const jumpToLatest = (): void => {
    if (scrollbox === undefined) return
    scrollbox.stickyScroll = true
    scrollbox.scrollTo(scrollbox.scrollHeight)
  }
  /** Wheel the viewport by whole rows. Manual scrolling drops sticky, so the newest rows
   * do not yank the view back down while the user is reading older ones. */
  const scrollRows = (delta: number): void => {
    if (scrollbox === undefined) return
    scrollbox.stickyScroll = false
    scrollbox.scrollBy(delta)
  }
  /** The terminal size the host reported at the handshake. OpenTUI owns the TTY and follows
   * `SIGWINCH` itself, so this is the fallback for a piped stdout, where the renderer has
   * no TTY to query and defaults to 80x24. */
  const [terminalSize, setTerminalSize] = createSignal({ width: 80, height: 24 })
  /** Answers to the renderer's own `doctor-check` requests, keyed by the request's
   * seq. A `command-result` whose seq is not pending is dropped: the host can answer
   * a request the renderer no longer cares about, and an alert must not pop for it. */
  const pendingResults = new Map<number, (result: { ok: boolean; value?: unknown; text?: string; error?: string }) => void>()
  const requestResult = (kind: string, payload: unknown): Promise<{ ok: boolean; value?: unknown; text?: string; error?: string }> => {
    const result = Promise.withResolvers<{ ok: boolean; value?: unknown; text?: string; error?: string }>()
    pendingResults.set(send(kind, payload), result.resolve)
    return result.promise
  }
  const reportRequest = (kind: string, payload: unknown): void => {
    void requestResult(kind, payload).then(result => {
      if (!result.ok) pushNotice('error', result.error ?? `${kind} failed`)
    })
  }
  const isCurrentSessionPayload = (payload: Record<string, unknown>): boolean =>
    !(route() === 'home' && activeTabId() === DRAFT_TAB_ID)
    && typeof payload.sessionId === 'string' && payload.sessionId === currentSession()
  /**
   * A user-questions request being answered one question at a time. The host's
   * `user-questions/request` handler blocks until the whole request is answered, so
   * the answers accumulate and go back together, correlated by the request id.
   */
  const [questionFlow, setQuestionFlow] = createSignal<
    { request: string; sessionId: string; state: 'open' | 'continued'; questions: QuestionSpec[]; answers: QuestionAnswerItem[]; index: number } | undefined
  >()
  const [questionRemainingMs, setQuestionRemainingMs] = createSignal<number | undefined>(undefined)
  let questionTimer: ReturnType<typeof setInterval> | undefined
  let questionDeadline: number | undefined
  let questionDialogId: number | undefined
  let questionDialogTitle = ''
  const stopQuestionTimer = (): void => {
    clearInterval(questionTimer)
    questionTimer = undefined
    questionDeadline = undefined
    setQuestionRemainingMs(undefined)
  }
  const startQuestionTimer = (request: string, remainingMs: number | undefined): void => {
    stopQuestionTimer()
    if (remainingMs === undefined || !Number.isFinite(remainingMs) || remainingMs < 0) return
    questionDeadline = Date.now() + remainingMs
    const tick = (): void => {
      if (questionFlow()?.request !== request || questionDeadline === undefined) {
        stopQuestionTimer()
        return
      }
      const remaining = Math.max(0, questionDeadline - Date.now())
      updateQuestionDialogTitle(Math.ceil(remaining / 1000))
      setQuestionRemainingMs(remaining)
      if (remaining > 0) return
      stopQuestionTimer()
      setQuestionFlow(undefined)
      closeTopDialog(undefined)
      send('question-timeout', { request })
    }
    tick()
    if (questionDeadline !== undefined) questionTimer = setInterval(tick, 200)
  }
  const [approvalFlow, setApprovalFlow] = createSignal<{ request: string; sessionId: string; ownerSessionId?: string; toolName: string; callId?: string; reason?: string } | undefined>()
  const [turnRunning, setTurnRunning] = createSignal(false)
  const [commands, setCommands] = createSignal<Array<{ name: string; description: string; argumentHint?: string }>>([])
  const [models, setModels] = createSignal<Array<{ provider: string; model: string; label: string; current: boolean }>>([])
  const [history, setHistory] = createSignal<string[]>([])
  /** The renderer's local files (prompt history, tab set, layout); created by the shell. */
  let localStorage: LocalStorage | undefined
  const setLocalStorage = (storage: LocalStorage | undefined): void => {
    localStorage = storage
  }
  const hasLocalStorage = (): boolean => localStorage !== undefined
  /** A storage failure is reported once per session: a read-only home would otherwise warn
   * on every submitted prompt, drowning the transcript. */
  let storageWarned = false
  const warnStorage = (what: string, error: unknown): void => {
    if (storageWarned) return
    storageWarned = true
    pushNotice('warning', `Could not ${what}: ${error instanceof Error ? error.message : String(error)}`)
  }
  /** Record one submitted line: the in-memory list plus the durable history file. */
  const recordHistory = (text: string): void => {
    if (text.trim() === '') return
    setHistory(list => [...list, text])
    setHistoryIndex(-1)
    void localStorage?.appendHistory({ text, at: Date.now() }).catch(error => warnStorage('save prompt history', error))
  }
  /** Load the persisted history once, oldest first, deduplicated and capped at 50. */
  const loadHistory = async (): Promise<void> => {
    const storage = localStorage
    if (storage === undefined) return
    const entries = await storage.readHistory<{ text?: unknown }>().catch(() => [])
    const lines: string[] = []
    for (const entry of entries) {
      if (typeof entry?.text !== 'string' || entry.text.trim() === '') continue
      const at = lines.indexOf(entry.text)
      if (at !== -1) lines.splice(at, 1)
      lines.push(entry.text)
    }
    setHistory(lines.slice(-50))
  }
  const [historyIndex, setHistoryIndex] = createSignal(-1)
  const [dialogStack, setDialogStack] = createSignal<DialogSpec[]>([])
  const [dialogController, setDialogController] = createSignal<DialogController | undefined>(undefined)
  // The writer the open harness form registers on mount. The host's discovery answer
  // (`model-discovery`) writes a field's value through it, so the form's local values
  // stay the single source of truth: the same path typing uses.
  const [formFieldWriter, setFormFieldWriterSignal] = createSignal<((key: string, value: string) => void) | undefined>(undefined)
  // The models line the nested editor was opened from. The host answers `model-edit` with
  // a form for one model, and the merge happens against this line, so the edit lands on the
  // values the renderer has on screen.
  const [modelLine, setModelLine] = createSignal('')
  /** Setting a signal to a function must wrap it: Solid treats a bare function as a
   * producer and calls it with the previous value, so the stored value becomes the
   * producer's result (`undefined` for a two-argument writer). */
  const setFormFieldWriter = (writer: ((key: string, value: string) => void) | undefined): void => {
    setFormFieldWriterSignal(() => writer)
  }
  const pendingDialogs = new Map<number, (value: unknown) => void>()
  let dialogId = 0

  /** Ask the host to run a harness-owned dialog (the provider form lands in S7).
   * The request carries no local state; the host answers with `dialog-response`
   * keyed by the sequence the request went out on. */
  const requestDialog = (kind: string, args?: Record<string, unknown>): Promise<unknown> => {
    const seq = send('dialog-request', { kind, ...(args === undefined ? {} : { args }) })
    return new Promise(resolve => pendingDialogs.set(seq, resolve))
  }

  /** Show a dialog. `onDone` receives the picked value, or `undefined` on cancel. */
  const openDialog = (spec: Omit<DialogSpec, 'id'>): number => {
    const id = ++dialogId
    setDialogStack(stack => [...stack, { ...spec, id }])
    return id
  }

  /** Close the top of the stack and resolve it. Closing nothing is a no-op. */
  /**
   * Pop the top dialog and hand `value` to its `onDone`.
   *
   * `expectId` guards the double-delivery of one key press: a select list commits on the
   * focused input's `onKeyDown`, and the keymap's `dialog-submit` fires for the same event.
   * When the first handler opens a follow-up dialog (`switch model` → the model picker), the
   * second handler would otherwise submit *that* dialog and close it in the same tick, which
   * is why the secondary panel flashed and vanished. A caller that names the dialog it means
   * to close is ignored once the stack has moved on.
   */
  const closeTopDialog = (value: string | undefined, expectId?: string | number): void => {
    const stack = dialogStack()
    const top = stack.at(-1)
    if (top === undefined) return
    if (expectId !== undefined && top.id !== expectId) return
    if (top.id === questionDialogId) questionDialogId = undefined
    setDialogStack(stack.slice(0, -1))
    top.onDone(value)
  }
  const updateQuestionDialogTitle = (seconds: number): void => {
    const id = questionDialogId
    if (id === undefined) return
    setDialogStack(stack => stack.map(spec => spec.id === id ? { ...spec, title: `${questionDialogTitle} · ${seconds}s` } : spec))
  }
  const openQuestionDialog = (spec: Omit<DialogSpec, 'id'>): void => {
    questionDialogTitle = spec.title
    questionDialogId = openDialog({ ...spec, title: questionRemainingMs() === undefined ? spec.title : `${spec.title} · ${Math.ceil((questionRemainingMs() ?? 0) / 1000)}s` })
  }

  /** The permission catalog is process-level, but a first-frame dialog can beat its push.
   * Keep the two dsh-base presets as a safe fallback; the next catalog replaces them. */
  const permissionChoices = (): Array<{ id: string; label: string }> => {
    const presets = permissionPresets()
    if (presets.length > 0) return presets
    return [
      { id: 'workspace-write', label: label('permissionWorkspaceWrite', 'workspace write') },
      { id: 'full-access', label: label('permissionFullAccess', 'full access') },
    ]
  }

  const applySelection = (selection: { provider?: string; model?: string; effort?: string; permission?: string; preset?: string }): void => {
    // Update the route optimistically on every surface. A model/effort pick used to wait for
    // the host's settings write and a full session-snapshot before repainting, which made the
    // prompt sit on the old route and briefly flash reset fields. The host follows with a
    // route-only `selection-state`, so the transcript and catalogs stay untouched.
    if (selection.provider !== undefined) setProvider(selection.provider)
    if (selection.model !== undefined) setModel(selection.model)
    if (selection.effort !== undefined) setEffortCurrent(selection.effort)
    if (selection.permission !== undefined) setPermission(selection.permission)
    if (selection.preset !== undefined) setPreset(selection.preset)
    if (route() === 'home' && activeTabId() === DRAFT_TAB_ID) return
    if (route() === 'home') {
      // Fall through for the blank session Home shows, which is the one the first message
      // reuses: a pick kept local there never reached the request, so the answer came back
      // on the previous model. After `leader n` the route is Home too, but the session is
      // still the previous conversation — writing there would move *its* route, and the new
      // session gets the pick from the `selection` it is created with.
      if (transcriptPlain.length > 0 || sessionTitle() !== '' || turnRunning()) return
    }
    if (currentSession() === '') return
    reportRequest('set-selection', { sessionId: currentSession(), ...selection })
  }

  /** Pick a reasoning effort; the host writes it back to the exact session route. */
  const pickEffort = (effort: string): void => applySelection({ effort })

  /** Pick a session from the rail: activate its tab and ask the host for a fresh snapshot. */
  const pickSession = (sessionId: string): void => {
    void switchToSession(sessionId)
  }

  /**
   * The open tab set is the renderer's own, persisted in its storage root. The pure
   * `session-tabs-model` owns the order, close/reopen stack, and title snapshots; these
   * accessors keep the existing call sites and tests terse. `DRAFT_TAB_ID` is a Home-only
   * draft that never reaches the host or tabs.json.
   */
  const [tabsState, setTabsState] = createSignal<TabsState>(emptyTabsState())
  const [activeTabId, setActiveTabId] = createSignal('')
  const openTabs = (): readonly string[] => tabsState().open
  const closedTabs = () => tabsState().closed
  const tabTitle = (id: string): string => tabsState().titles[id] ?? ''
  const persistTabs = (state: TabsState): void => {
    const persisted = encodeTabs(state)
    void localStorage?.update('tabs', persisted, draft => {
      draft.version = 2
      draft.tabs = [...persisted.tabs]
      draft.closed = [...persisted.closed]
    }).catch(error => warnStorage('save the tab set', error))
  }
  const commitTabs = (state: TabsState): void => {
    if (state === tabsState()) return
    setTabsState(state)
    persistTabs(state)
  }

  /** Drop every signal that belongs to the session currently on screen. */
  const resetSessionView = (): void => {
    setSessionTitle('')
    setTranscript([])
    setSubagents([])
    setTodos([])
    setInterjections([])
    setShellJobs([])
    setUsage(undefined)
    setGitBranch(undefined)
    setTurnRunning(false)
    setReadOnly(false)
    hideTerminal()
    setTerminalSessionId('')
    setTerminalInfo(undefined)
    setTerminalAttachmentId('')
    setTerminalFrames([])
    setTerminalEndError(undefined)
    setTerminalEnvironment(undefined)
  }

  /** Activate a real session tab optimistically, then require a fresh host snapshot. */
  const switchToSession = async (sessionId: string): Promise<void> => {
    if (sessionId === '') return
    if (route() === 'session' && currentSession() !== '') sessionDrafts.set(currentSession(), composer())
    const previousRoute = route()
    const previousActive = activeTabId()
    const previousSession = currentSession()
    pendingSwitchSessionId = sessionId
    const result = await requestResult('session-op', { op: 'switch', sessionId })
    if (result.ok) return
    setRoute(previousRoute)
    setActiveTabId(previousActive)
    setCurrentSession(previousSession)
    pushNotice('error', result.error ?? 'Could not switch session')
    if (pendingSwitchSessionId === sessionId) pendingSwitchSessionId = undefined
  }

  /** Leave the session route without creating or destroying any session. */
  const goHome = (): void => {
    if (route() === 'session' && currentSession() !== '') sessionDrafts.set(currentSession(), composer())
    resetSessionView()
    setRoute('home')
    setActiveTabId(DRAFT_TAB_ID)
    setComposer(homeDraft)
  }
  /** Add the one ephemeral Home draft tab; the real tabs keep their order. */
  const ensureDraftTab = (): void => {
    const next = openTabState(tabsState(), DRAFT_TAB_ID)
    if (next !== tabsState()) setTabsState(next)
  }
  const newSessionTab = (): void => {
    goHome()
    ensureDraftTab()
  }
  /** Replace the draft in place once the first prompt belongs to a real session. */
  const promoteDraftTab = (sessionId: string, title = ''): void => {
    const next = promoteDraftState(tabsState(), sessionId, title)
    if (next !== tabsState()) commitTabs(next)
  }
  /** Add a real session tab if it is not open yet. */
  const openTab = (sessionId: string, title = ''): void => {
    const next = openTabState(tabsState(), sessionId, title)
    if (next !== tabsState()) commitTabs(next)
  }
  /** Close one tab; when it is active, move to its right neighbour, then left, then Home. */
  const closeTab = (id: string): void => {
    const result = closeTabState(tabsState(), id)
    if (result.state === tabsState()) return
    setTabsState(result.state)
    persistTabs(result.state)
    const active = id === DRAFT_TAB_ID ? route() === 'home' && activeTabId() === DRAFT_TAB_ID : route() === 'session' && (activeTabId() === id || currentSession() === id)
    if (id === DRAFT_TAB_ID) homeDraft = ''
    if (!active) return
    if (result.fallbackId !== undefined) {
      pickSession(result.fallbackId)
      return
    }
    goHome()
  }
  /** Close the active tab, including the Home draft. Home without a draft is a no-op. */
  const closeSessionTab = (): void => {
    if (route() === 'home') {
      if (openTabs().includes(DRAFT_TAB_ID)) closeTab(DRAFT_TAB_ID)
      return
    }
    closeTab(activeTabId() || currentSession())
  }
  /** Close every tab except this one, keeping the closed stack for `ctrl+shift+t`. */
  const closeOtherTabs = (id: string): void => {
    if (!openTabs().includes(id)) return
    commitTabs(closeOtherTabsState(tabsState(), id))
    if (id === DRAFT_TAB_ID) {
      goHome()
      return
    }
    const active = route() === 'session' && (activeTabId() === id || currentSession() === id)
    if (!active) pickSession(id)
  }
  /** Move a tab by `delta` slots (context menu / future drag). */
  const moveTab = (id: string, delta: number): void => {
    commitTabs(moveTabState(tabsState(), id, delta))
  }
  const moveTabTo = (id: string, index: number): void => {
    const next = openTabState(tabsState(), id)
    commitTabs(moveTabState(next, id, index - next.open.indexOf(id)))
  }
  /** `ctrl+shift+t`: reopen the most recently closed tab that is not already open. */
  const reopenSessionTab = (): void => {
    const result = reopenLastTab(tabsState())
    if (result.reopenedId === undefined) {
      pushNotice('info', 'No closed session tab to reopen')
      return
    }
    setTabsState(result.state)
    persistTabs(result.state)
    pickSession(result.reopenedId)
  }
  /** Right-click menu on a chip: the management actions the strip does not have room for. */
  const openTabMenu = (id: string): void => {
    openDialog({
      kind: 'select',
      title: label('rendererTabMenuTitle', 'session tab'),
      options: [
        { title: label('rendererTabClose', 'close tab'), value: 'close' },
        { title: label('rendererTabCloseOthers', 'close other tabs'), value: 'close-others' },
        { title: label('rendererTabMoveLeft', 'move tab left'), value: 'move-left' },
        { title: label('rendererTabMoveRight', 'move tab right'), value: 'move-right' },
        { title: label('rendererTabReopen', 'reopen closed tab'), value: 'reopen' },
        // A draft has no host session, so there is nothing to rename yet.
        ...(id === DRAFT_TAB_ID ? [] : [{ title: label('rendererTabRename', 'rename tab'), value: 'rename' }]),
      ],
      onDone: value => {
        if (value === 'close') closeTab(id)
        else if (value === 'close-others') closeOtherTabs(id)
        else if (value === 'move-left') moveTab(id, -1)
        else if (value === 'move-right') moveTab(id, 1)
        else if (value === 'reopen') reopenSessionTab()
        else if (value === 'rename') openRenameSession(id)
      },
    })
  }
  /** Click/keyboard selection: a draft is Home, a real id is a host session switch. */
  const selectTab = (id: string): void => {
    if (id === DRAFT_TAB_ID) goHome()
    else pickSession(id)
  }
  /** Cycle the open tabs in visual order; the host owns real session switches. */
  const cycleTab = (direction: 1 | -1): void => {
    if (openTabs().length < 2) return
    const current = route() === 'home' ? DRAFT_TAB_ID : (activeTabId() || currentSession())
    const next = cycleTabId(tabsState(), current, direction)
    if (next === undefined || next === current) return
    if (next === DRAFT_TAB_ID) goHome()
    else pickSession(next)
  }
  /** Load the persisted tab set once the storage root exists. */
  const loadTabs = async (): Promise<void> => {
    const stored = await localStorage?.read<unknown>('tabs').catch(() => undefined)
    const loaded = decodeTabs(stored)
    // Merge, never replace: a snapshot that arrived before the file finished loading has
    // already opened a tab, and dropping it would make the strip flicker to empty.
    setTabsState(current => {
      const currentIds = new Set(current.open)
      return {
        open: [...loaded.open.filter(id => !currentIds.has(id)), ...current.open],
        closed: current.closed.length > 0 ? current.closed : loaded.closed,
        titles: { ...loaded.titles, ...current.titles },
      }
    })
  }

  /** `leader b`: cycle auto → open → closed → auto. */
  const toggleSidebar = (): void => {
    setSidebarState(state => (state === 'auto' ? 'open' : state === 'open' ? 'closed' : 'auto'))
  }

  /** The handle's drag delta, through the pane clamp. */
  const resizeSidebar = (width: number): void => {
    setSidebarWidth(clampPaneWidth(width, terminalSize().width))
  }

  /** Pick a model: the host writes the complete route back through its own seam. */
  const pickModel = (provider: string, model: string): void => applySelection({ provider, model })

  /** One line's endpoint: a local picker command opens its dialog, everything else is
   * sent upstream verbatim (the host owns `/theme <id>`, `/resume <id>`, `/btw …`). */
  const runLine = (text: string): void => {
    const line = text.trim()
    if (line === '') return
    if (interceptCommand(line)) return
    reportRequest('send-message', { sessionId: currentSession(), text: line, delivery: 'steer' })
    recordHistory(line)
  }

  const startNewSession = (): void => {
    newSessionTab()
  }

  const submitHomeMessage = (text: string, attachments: readonly PendingAttachment[]): void => {
    if (text === '' && attachments.length === 0) return
    // The first send owns the Home draft. Without a prior +, create the draft now so the
    // optimistic session route still shows exactly one tab.
    ensureDraftTab()
    const selection = { provider: provider(), model: model(), preset: preset() }
    if (selection.provider === '' || selection.model === '' || selection.preset === '') {
      pushNotice('error', 'Cannot create a session before its model and preset are loaded')
      return
    }
    // The session Home is showing is already a real (blank) session. Reusing it keeps one
    // conversation per first message; minting a fresh id left the blank one behind as a
    // second "New Session" tab and made the host create a session nobody asked for.
    const reuse = currentSession() !== '' && activeTabId() !== DRAFT_TAB_ID && transcriptPlain.length === 0 && sessionTitle() === '' && !turnRunning()
    if (reuse) {
      const sessionId = currentSession()
      const draft = composer()
      draftTargetId = sessionId
      setComposer('')
      setRoute('session')
      void (async () => {
        const sent = await requestResult('send-message', {
          sessionId,
          text,
          delivery: 'steer',
          ...(attachments.length === 0 ? {} : { attachments: attachments.map(item => item.submitted) }),
        })
        if (!sent.ok) {
          draftTargetId = undefined
          if (composer() === '') setComposer(draft)
          if (transcriptPlain.length === 0 && route() === 'session' && currentSession() === sessionId) setRoute('home')
          pushNotice('error', sent.error ?? 'Message submission failed')
          return
        }
        if (draftTargetId === sessionId) {
          promoteDraftTab(sessionId, sessionTitle())
          draftTargetId = undefined
        }
        removePendingAttachments(new Set(attachments.map(item => item.id)))
        if (text !== '') recordHistory(text)
      })()
      return
    }
    const sessionId = `tui-${crypto.randomUUID()}`
    const draft = composer()
    const previous = {
      sessionId: currentSession(),
      title: sessionTitle(),
      transcript: [...transcriptPlain],
      workspace: workspace(),
      provider: provider(),
      model: model(),
      effort: effortCurrent(),
      permission: permission(),
      preset: preset(),
      actions: availableActions(),
      efforts: efforts(),
      commands: commands(),
      models: models(),
      mentions: mentions(),
      skills: skills(),
      subagents: subagents(),
      todos: todos(),
      interjections: interjections(),
      permissionPresets: permissionPresets(),
      agentPresets: agentPresets(),
      attachmentCapabilities: attachmentCapabilities(),
      sessions: sessions(),
      usage: usage(),
      branch: gitBranch(),
      running: turnRunning(),
    }
    setComposer('')
    const clearedRevision = draftRevision
    pendingHomeSessionId = sessionId
    draftTargetId = sessionId
    setRoute('session')
    setCurrentSession(sessionId)
    setSessionTitle(sessionId)
    setTranscript([])
    setAvailableActions([])
    setEfforts([])
    setCommands([])
    setModels([])
    setMentions([])
    setSkills([])
    setSubagents([])
    setTodos([])
    setInterjections([])
    setShellJobs([])
    setUsage(undefined)
    setGitBranch(undefined)
    setTurnRunning(false)
    setAgentPresets([])
    setSessions(current => [
      { id: sessionId, title: sessionId, active: true, createdAt: Date.now(), status: 'idle', attention: false },
      ...current.map(session => ({ ...session, active: false })),
    ])
    const cwd = previous.workspace
    const request = {
      op: 'new',
      sessionId,
      ...(cwd === '' ? {} : { cwd }),
      selection: {
        provider: selection.provider,
        model: selection.model,
        ...(effortCurrent() === '' ? {} : { effort: effortCurrent() }),
        preset: selection.preset,
        ...(permission() === '' ? {} : { permission: permission() }),
      },
    }
    void (async () => {
      const created = await requestResult('session-op', request)
      const value = created.value
      const returnedId = typeof value === 'object' && value !== null && 'sessionId' in value ? value.sessionId : undefined
      if (!created.ok || returnedId !== sessionId) {
        pendingHomeSessionId = undefined
        draftTargetId = undefined
        if (currentSession() === sessionId) {
          setRoute('home')
          setCurrentSession(previous.sessionId)
          setSessionTitle(previous.title)
          setTranscript(previous.transcript)
          setWorkspace(previous.workspace)
          setProvider(previous.provider)
          setModel(previous.model)
          setEffortCurrent(previous.effort)
          setPermission(previous.permission)
          setPreset(previous.preset)
          setAvailableActions(previous.actions)
          setEfforts(previous.efforts)
          setCommands(previous.commands)
          setModels(previous.models)
          setMentions(previous.mentions)
          setSkills(previous.skills)
          setSubagents(previous.subagents)
          setTodos(previous.todos)
          setInterjections(previous.interjections)
          setPermissionPresets(previous.permissionPresets)
          setAgentPresets(previous.agentPresets)
          setAttachmentCapabilities(previous.attachmentCapabilities)
          setSessions(previous.sessions)
          setUsage(previous.usage)
          setGitBranch(previous.branch)
          setTurnRunning(previous.running)
        }
        if (draftRevision === clearedRevision && composer() === '') setComposer(draft)
        pushNotice('error', created.error ?? 'Session creation returned an invalid session ID')
        return
      }
      setPendingAttachments(current => current.map(item => item.owner === 'home' ? { ...item, owner: sessionId } : item))
      // The host session now exists, so the optimistic Home draft becomes its real tab even
      // if the message send below still fails. A failed create above leaves the draft intact.
      if (draftTargetId === sessionId) {
        promoteDraftTab(sessionId, '')
        draftTargetId = undefined
      }
      const activeAttachmentIds = new Set(pendingAttachments().map(item => item.id))
      const attachmentsToSend = attachments.filter(item => activeAttachmentIds.has(item.id))
      if (text === '' && attachmentsToSend.length === 0) {
        pendingHomeSessionId = undefined
        return
      }
      const sent = await requestResult('send-message', { sessionId, text, delivery: 'steer', ...(attachmentsToSend.length === 0 ? {} : { attachments: attachmentsToSend.map(item => item.submitted) }) })
      pendingHomeSessionId = undefined
      if (!sent.ok) {
        if (draftRevision === clearedRevision && composer() === '') setComposer(draft)
        pushNotice('error', sent.error ?? 'Message submission failed')
        return
      }
      if (draftTargetId === sessionId) {
        promoteDraftTab(sessionId, sessionTitle())
        draftTargetId = undefined
      }
      removePendingAttachments(new Set(attachmentsToSend.map(item => item.id)))
      if (text !== '') recordHistory(text)
    })()
  }

  /** The composer's Enter. A fresh Home route creates its Session only on first send. */
  const submitComposer = (): void => {
    const text = composer().trim()
    const attachments = pendingAttachmentsForCurrent()
    if ((text === '' && attachments.length === 0) || pendingHomeSessionId !== undefined) return
    // A submitted prompt ends the current selection. A drag that is still non-empty is
    // cleared only on an explicit submit, not on a streaming delta.
    clearTextSelection()
    if (route() === 'home') {
      if (attachments.length === 0 && text !== '' && interceptCommand(text)) {
        setComposer('')
        return
      }
      submitHomeMessage(text, attachments)
      return
    }
    if (attachments.length === 0) {
      if (text !== '') runLine(text)
      setComposer('')
      return
    }
    const draft = composer()
    setComposer('')
    removePendingAttachments(new Set(attachments.map(item => item.id)))
    const clearedRevision = draftRevision
    void requestResult('send-message', { sessionId: currentSession(), text, delivery: 'steer', attachments: attachments.map(item => item.submitted) }).then(result => {
      if (result.ok) {
        if (text !== '') recordHistory(text)
        return
      }
      if (draftRevision === clearedRevision && composer() === '') setComposer(draft)
      setPendingAttachments(current => {
        const currentIds = new Set(current.map(item => item.id))
        return [...attachments.filter(item => !currentIds.has(item.id)), ...current]
      })
      pushNotice('error', result.error ?? 'Message submission failed')
    })
  }

  // The draft the user was typing before entering history, so returning to the
  // bottom of the list puts it back.
  let savedDraft = ''

  /** `↑` / `↓` in the composer walk the submitted history. */
  const recallHistory = (delta: -1 | 1): void => {
    const list = history()
    if (list.length === 0) return
    const index = historyIndex()
    if (index === -1) savedDraft = composer()
    const next = index === -1 ? (delta === -1 ? list.length - 1 : 0) : index + delta
    if (next < 0 || next >= list.length) {
      setHistoryIndex(-1)
      setComposer(savedDraft)
      return
    }
    setHistoryIndex(next)
    const draft = list[next]
    if (draft !== undefined) setComposer(draft)
  }

  /** Ask the host to restore one queued interjection from the exact session inbox. */
  const editInterjection = (id?: string): void => {
    void requestResult('interject-edit', { sessionId: currentSession(), ...(id === undefined ? {} : { id }) }).then(result => {
      if (!result.ok) {
        pushNotice('error', result.error ?? 'Could not edit queued message')
        return
      }
      if (typeof result.value === 'string') {
        setComposer(result.value)
        setHistoryIndex(-1)
      }
    })
  }

  /** Write one settings field through the host's settings seam. `ns` selects the
   * namespace; the agent-loop fields are not TUI settings. */
  /** Settings writes waiting for the host's answer, keyed by request id. */
  const pendingSettings = new Map<string, (error?: string) => void>()
  const rejectPendingRequests = (reason: string): void => {
    for (const settle of pendingSettings.values()) settle(reason)
    pendingSettings.clear()
    for (const settle of pendingResults.values()) settle({ ok: false, error: reason })
    pendingResults.clear()
  }
  // The caller passes `undefined`: register a no-op, not a call through an absent callback.
  registerUpdateRejector(rejectPendingRequests)
  /**
   * Write one settings field. The local copy is optimistic; the promise settles on the
   * host's answer for the same request id and is rejected with the real write error.
   */
  const setSetting = (key: string, value: unknown, ns?: 'tui' | 'agent-loop'): Promise<void> => {
    setSettings(current => ({ ...current, [key]: value }))
    const requestId = `settings-${String(pendingSettings.size + 1)}-${String(nextSettingsId++)}`
    const answered = Promise.withResolvers<void>()
    pendingSettings.set(requestId, error => {
      pendingSettings.delete(requestId)
      if (error === undefined) answered.resolve()
      else answered.reject(new Error(error))
    })
    send('update-settings', { requestId, patch: { [key]: value }, ...(ns === undefined ? {} : { ns }) })
    return answered.promise
  }

  /** The native theme provider's storage: only the theme name and mode live here. */
  const themeStorage = (): ThemeStorage => ({
    selection: () => ({
      name: typeof settings().themeName === 'string' ? settings().themeName as string : 'opencode',
      mode: settings().themeMode === 'dark' || settings().themeMode === 'light' ? settings().themeMode as 'dark' | 'light' : 'system',
    }),
    save: async patch => {
      // The provider speaks `name` / `mode`; the host section spells them `themeName` /
      // `themeMode`. The transcript switch is written by `runSetting` through the
      // settings seam, never by a theme pick.
      const fields: Array<[string, string]> = []
      if (patch.name !== undefined) fields.push(['themeName', patch.name])
      if (patch.mode !== undefined) fields.push(['themeMode', patch.mode])
      await Promise.all(fields.map(([key, value]) => setSetting(key, value)))
    },
  })

  /** The /trace command: the complete interaction timeline in one scrollable panel. */
  const openTrace = (): void => {
    openDialog({
      kind: 'trace',
      title: label('rendererTrace', 'trace'),
      size: 'xlarge',
      onDone: () => undefined,
    })
  }

  /** The `/settings` page: the fields the host's settings section exposes. */
  const openSettings = (): void => {
    const current = settings()
    const general = label('rendererSettingsCategoryGeneral', 'general')
    const appearance = label('rendererSettingsCategoryAppearance', 'appearance')
    const yesNo = (value: unknown): string => value === true ? label('settingsOn', 'on') : label('settingsOff', 'off')
    const onOff = (value: boolean): string => value ? label('settingsOn', 'on') : label('settingsOff', 'off')
    const themeModeRaw = themeControls() === undefined
      ? String(current.themeMode ?? 'system')
      : (themeControls()!.mode() === undefined ? 'system' : themeControls()!.mode())
    const themeModeLabel = themeModeRaw === 'dark'
      ? label('rendererThemeDark', 'dark')
      : themeModeRaw === 'light'
        ? label('rendererThemeLight', 'light')
        : label('rendererThemeSystem', 'system')
    const options = [
      { title: label('rendererLanguage', 'language') + ': ' + locale(), value: 'setting:locale', category: general },
      { title: label('rendererShowReasoning', 'show reasoning blocks') + ': ' + yesNo(current.showReasoning ?? true), value: 'setting:showReasoning', category: general },
      { title: label('rendererMaxLines', 'max tool output lines') + ': ' + String(current.maxToolOutputLines ?? 5), value: 'setting:maxToolOutputLines', category: general },
      { title: label('settingsMaxParallelToolCalls', 'max parallel tool calls') + ': ' + String(current.maxParallelToolCalls ?? ''), value: 'setting:maxParallelToolCalls', category: general },
      { title: label('rendererLeftPrompt', 'left prompt') + ': ' + String(current.leftPrompt ?? ''), value: 'setting:leftPrompt', category: general },
      { title: label('rendererRightPrompt', 'right prompt') + ': ' + String(current.rightPrompt ?? ''), value: 'setting:rightPrompt', category: general },
      { title: label('settingsKeyTools', 'key tools') + ': ' + String(current.keyTools ?? ''), value: 'setting:keyTools', category: general },
      { title: label('settingsKeyReasoning', 'key reasoning') + ': ' + String(current.keyReasoning ?? ''), value: 'setting:keyReasoning', category: general },
      { title: label('rendererTheme', 'theme') + ': ' + (themeControls()?.selected() ?? String(current.themeName ?? 'opencode')), value: 'setting:theme', category: appearance },
      { title: label('rendererThemeMode', 'theme mode') + ': ' + themeModeLabel, value: 'setting:themeMode', category: appearance },
      { title: label('rendererNewDesigns', 'new thinking style') + ': ' + onOff(current.newDesigns === true), value: 'setting:newDesigns', category: appearance },
      { title: label('rendererPathDisplay', 'path display') + ': ' + (current.pathDisplay === 'full' ? label('rendererPathDisplayFull', 'full path') : label('rendererPathDisplayTilde', '~ abbreviated')), value: 'setting:pathDisplay', category: appearance },
      { title: label('rendererAutostart', 'launch core at login') + ': ' + yesNo(current.autostart === true), value: 'setting:autostart', category: general, disabled: current.autostartSupported === false, description: current.autostartSupported === false ? label('rendererAutostartUnsupported', 'launch at login is unsupported on this platform') : undefined },
      { title: label('rendererProviderForm', 'provider form'), value: 'form:provider', category: general },
      { title: label('rendererCustomModel', 'custom model'), value: 'form:custom-model', category: general },
    ]
    openDialog({
      kind: 'select',
      title: label('rendererSettings', 'settings'),
      options,
      sectionNavigation: true,
      onDone: value => {
        if (value === undefined) return
        if (value.startsWith('setting:')) {
          runSetting(value.slice('setting:'.length))
          return
        }
        if (value.startsWith('form:')) {
          const form = value.slice('form:'.length)
          // The custom model is written per provider, so the request carries the provider
          // of the model that is currently selected in the catalog.
          const current = models().find(model => model.current)
          requestDialog(form, form === 'custom-model' && current !== undefined ? { provider: current.provider } : undefined)
        }
      },
    })
  }

  /** One settings field opens the picker its type needs. */
  const runSetting = (key: string): void => {
    const current = settings()
    switch (key) {
      case 'autostart': {
        const enabled = current.autostart !== true
        void requestResult('autostart-op', { enabled }).then(result => {
          if (!result.ok) {
            pushNotice('error', result.error ?? label('rendererAutostartUnsupported', 'launch at login is unsupported on this platform'))
            return
          }
          const status = result.value as { enabled?: boolean; detail?: string } | undefined
          setSettings(previous => ({ ...previous, autostart: status?.enabled === true }))
          pushNotice('info', status?.enabled === true ? label('rendererAutostartEnabled', 'launch at login enabled') : label('rendererAutostartDisabled', 'launch at login disabled'))
        })
        return
      }
      case 'theme':
        openThemeDialog()
        return
      case 'themeMode': {
        const controls = themeControls()
        if (controls === undefined) return
        openDialog({
          kind: 'select',
          title: label('rendererThemeMode', 'theme mode'),
          options: [
            { title: label('rendererThemeSystem', 'system'), value: 'system' },
            { title: label('rendererThemeDark', 'dark'), value: 'dark' },
            { title: label('rendererThemeLight', 'light'), value: 'light' },
          ],
          current: settings().themeMode === 'dark' || settings().themeMode === 'light' ? settings().themeMode as string : 'system',
          onDone: value => {
            if (value === undefined) return
            if (value === 'system') {
              controls.unlock()
              return
            }
            if (!controls.setMode(value as 'dark' | 'light')) pushNotice('error', label('rendererThemeModeUnavailable', 'the selected theme does not offer {mode}').replace('{mode}', value))
          },
        })
        return
      }
      case 'newDesigns':
        // The transcript switch is a shell setting, not a theme control: flipping it must
        // leave the selected theme (including `opencode2`) untouched.
        void setSetting('newDesigns', current.newDesigns !== true)
        return
      case 'pathDisplay':
        openDialog({
          kind: 'select',
          title: label('rendererPathDisplay', 'path display'),
          options: [
            { title: label('rendererPathDisplayTilde', '~ abbreviated'), value: 'tilde' },
            { title: label('rendererPathDisplayFull', 'full path'), value: 'full' },
          ],
          current: pathDisplayMode(),
          onDone: value => {
            if (value === 'tilde' || value === 'full') void setSetting('pathDisplay', value)
          },
        })
        return
      case 'locale':
        openDialog({
          kind: 'select',
          title: label('rendererLanguage', 'language'),
          options: [
            { title: '中文（zh-CN）', value: 'zh-CN' },
            { title: 'English (en)', value: 'en' },
          ],
          current: locale(),
          onDone: value => {
            if (value === undefined || value === locale()) return
            void setSetting('locale', value)
            pushNotice('info', label('rendererLocaleRestart', 'language saved — restart dpsk to apply'))
          },
        })
        return
      case 'showReasoning':
        openDialog({
          kind: 'select',
          title: label('rendererShowReasoning', 'show reasoning blocks'),
          options: [{ title: label('rendererShow', 'show'), value: 'true' }, { title: label('rendererHide', 'hide'), value: 'false' }],
          current: String(current.showReasoning ?? true),
          onDone: value => {
            if (value !== undefined) setSetting('showReasoning', value === 'true')
          },
        })
        return
      case 'leftPrompt':
      case 'rightPrompt':
        openDialog({
          kind: 'prompt',
          title: key === 'leftPrompt' ? label('rendererLeftPrompt', 'left prompt') : label('rendererRightPrompt', 'right prompt'),
          value: String(current[key] ?? ''),
          // The template text is free-form (the host parses it with
          // `parseTuiPromptTemplate`), so any text is accepted and written as-is.
          onDone: value => {
            if (value !== undefined) setSetting(key, value)
          },
        })
        return
      case 'keyTools':
      case 'keyReasoning':
        openDialog({
          kind: 'prompt',
          title: key === 'keyTools' ? label('settingsKeyTools', 'key tools') : label('settingsKeyReasoning', 'key reasoning'),
          value: String(current[key] ?? ''),
          // The key string is free-form (`ctrl+o`, `shift+tab`). An empty answer is not
          // written: pi-tui's keybind edit skips it, so the same rule keeps the two paths
          // from writing a key that `matchesKey` can never match.
          onDone: value => {
            const trimmed = value?.trim() ?? ''
            if (trimmed !== '') setSetting(key, trimmed)
          },
        })
        return
      case 'maxParallelToolCalls':
        openDialog({
          kind: 'prompt',
          title: label('settingsMaxParallelToolCalls', 'max parallel tool calls'),
          value: String(current.maxParallelToolCalls ?? ''),
          // The cap is an agent-loop field, so the write carries the namespace.
          onDone: value => {
            const count = Number(value)
            if (Number.isFinite(count) && count > 0) setSetting('maxParallelToolCalls', Math.trunc(count), 'agent-loop')
          },
        })
        return
      case 'maxToolOutputLines':
        openDialog({
          kind: 'prompt',
          title: label('rendererMaxLines', 'max tool output lines'),
          value: String(current.maxToolOutputLines ?? 5),
          onDone: value => {
            const lines = Number(value)
            if (Number.isFinite(lines) && lines > 0) setSetting('maxToolOutputLines', Math.trunc(lines))
          },
        })
        return
      default:
        return
    }
  }

  /** `/doctor` and `/plugins` are host-owned checks. The renderer asks, the host
   * runs its own checks, and the report comes back as `command-result` on the
   * sequence this request went out on. */
  /**
   * Ask the current question in the flow. A question with options is a select dialog
   * (the picked label is the answer); a question without options is a prompt, whose
   * text is the free-text `custom` answer. The dialog's `onDone` records the answer
   * and moves to the next question, so the whole request answers sequentially.
   */
  const askCurrent = (): void => {
    const flow = questionFlow()
    if (flow === undefined) return
    const question = flow.questions[flow.index]
    if (question === undefined) return
    openQuestionDialog({
      kind: 'question',
      title: question.header ?? question.question,
      size: 'large',
      question,
      onDone: value => {
        if (value === undefined) {
          stopQuestionTimer()
          setQuestionFlow(undefined)
          send('question-answer', { request: flow.request, cancelled: true })
          return
        }
        try {
          recordAnswer(JSON.parse(value) as QuestionAnswerItem)
        } catch (error: unknown) {
          pushNotice('error', error instanceof Error ? error.message : String(error))
          setQuestionFlow(undefined)
          send('question-answer', { request: flow.request, cancelled: true })
        }
      },
    })
  }

  const recordAnswer = (item: QuestionAnswerItem): void => {
    questionDialogId = undefined
    const flow = questionFlow()
    if (flow === undefined) return
    const next = { ...flow, answers: [...flow.answers, item], index: flow.index + 1 }
    if (next.index >= next.questions.length) {
      stopQuestionTimer()
      questionDialogId = undefined
      setQuestionFlow(undefined)
      send('question-answer', { request: next.request, answers: next.answers })
      return
    }
    setQuestionFlow(next)
    askCurrent()
  }

  const showApproval = (request: { request: string; sessionId: string; ownerSessionId?: string; toolName: string; callId?: string; reason?: string }): void => {
    setApprovalFlow(request)
    openDialog({
      kind: 'confirm',
      title: `Approve ${request.toolName}?`,
      message: `${request.ownerSessionId !== undefined && request.ownerSessionId !== request.sessionId ? `Requested by child session ${request.ownerSessionId}. ` : ''}${request.reason ?? (request.callId === undefined ? 'The tool requests permission to run.' : `Tool call ${request.callId} requests permission to run.`)}`,
      onDone: answer => {
        const current = approvalFlow()
        setApprovalFlow(undefined)
        if (current === undefined) return
        send('approval-answer', { request: current.request, outcome: answer === 'confirm' ? 'allowed-once' : 'rejected' })
      },
    })
  }

  const requestDoctor = (op: 'doctor' | 'plugins'): void => {
    const seq = send('doctor-check', { op })
    pendingResults.set(seq, result => {
      openDialog({
        kind: 'alert',
        title: op,
        message: result.ok ? (result.text ?? '') : (result.error ?? 'report failed'),
        onDone: () => undefined,
      })
    })
  }

  const exportSession = async (format: 'json' | 'markdown'): Promise<void> => {
    const sessionId = currentSession()
    const result = await requestResult('session-op', { op: 'read', sessionId })
    if (!result.ok) {
      pushNotice('error', result.error ?? 'Session export failed')
      return
    }
    const value = result.value
    if (typeof value !== 'object' || value === null || !('session' in value) || !('events' in value)
      || typeof value.session !== 'object' || value.session === null || !Array.isArray(value.events)) {
      pushNotice('error', 'Session read returned an invalid dsh log')
      return
    }
    const session = value.session
    const events = value.events
    let content: string
    if (format === 'json') {
      content = `${JSON.stringify({ session, events }, null, 2)}\n`
    } else {
      const lines = [`# Session ${sessionId}`, '', `- Title: ${sessionTitle()}`, `- Workspace: ${workspace()}`, `- Events: ${events.length}`, '']
      for (const event of events) {
        const serialized = JSON.stringify(event, null, 2)
        let longestBacktickRun = 0
        for (const match of serialized.matchAll(/`+/g)) longestBacktickRun = Math.max(longestBacktickRun, match[0].length)
        const fence = '`'.repeat(Math.max(3, longestBacktickRun + 1))
        const type = typeof event === 'object' && event !== null && 'type' in event && typeof event.type === 'string' ? event.type : 'event'
        const seq = typeof event === 'object' && event !== null && 'seq' in event && typeof event.seq === 'number' ? event.seq : '?'
        lines.push(`## ${seq} · ${type}`, '', `${fence}json`, serialized, fence, '')
      }
      content = `${lines.join('\n')}\n`
    }
    const root = process.env.DSH_HOME ?? join(homedir(), '.dsh')
    const safeId = sessionId.replace(/[^A-Za-z0-9._-]/g, '_')
    const stamp = new Date().toISOString().replace(/[:.]/g, '-')
    const filePath = join(root, 'exports', `dsh-session-${safeId}-${stamp}-${crypto.randomUUID()}.${format === 'json' ? 'json' : 'md'}`)
    try {
      await mkdir(join(root, 'exports'), { recursive: true })
      await writeFile(filePath, content, { encoding: 'utf8', flag: 'wx' })
      openDialog({ kind: 'alert', title: label('rendererExported', 'session exported'), message: filePath, onDone: () => undefined })
    } catch (error: unknown) {
      pushNotice('error', `Session export failed: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  const chooseSessionExport = (): void => {
    openDialog({
      kind: 'select',
      title: label('rendererExportSession', 'export session'),
      options: [
        { title: label('rendererExportMarkdown', 'Markdown transcript'), value: 'markdown' },
        { title: label('rendererExportJson', 'JSON session log'), value: 'json' },
      ],
      onDone: value => {
        if (value === 'markdown' || value === 'json') void exportSession(value)
      },
    })
  }

  const openQueueDialog = (): void => {
    const sessionId = currentSession()
    const options = interjections().flatMap((item, index) => [
      {
        title: `Edit queued message ${index + 1}`,
        value: `edit:${item.id}`,
        category: 'queue',
        description: truncate(item.text, 96),
        searchText: item.text,
      },
      {
        title: `Delete queued message ${index + 1}`,
        value: `delete:${item.id}`,
        category: 'queue',
        description: truncate(item.text, 96),
        searchText: item.text,
      },
    ])
    openDialog({
      kind: 'select',
      title: label('rendererQueue', 'queued messages'),
      options,
      onDone: value => {
        if (value === undefined) return
        const separator = value.indexOf(':')
        const operation = value.slice(0, separator)
        const id = value.slice(separator + 1)
        if (id === '') return
        if (operation === 'edit') {
          editInterjection(id)
          return
        }
        if (operation === 'delete') {
          const queued = interjections().find(item => item.id === id)
          if (queued === undefined) return
          openDialog({
            kind: 'confirm',
            title: label('rendererQueueDelete', 'delete queued message?'),
            message: queued.text,
            onDone: answer => {
              if (answer !== 'confirm') return
              void requestResult('interject-delete', { sessionId, id }).then(result => {
                if (!result.ok) pushNotice('error', result.error ?? 'Could not delete queued message')
              })
            },
          })
        }
      },
    })
  }
  /** A slash command that is a picker, not a host command, is intercepted locally:
   * typing `/theme` opens the theme dialog the same way `ctrl+x t` does. */
  /** The host commands that do something real here: the catalog the host pushed (the
   * harness' own slash commands) plus the two host-owned lifecycle actions. A local
   * command is not gated. */
  /** The child sessions spawned by the session on screen. */
  const sidebarSubagents = () => sessions()
    .filter(session => session.parentId === currentSession() && session.sessionKind !== 'main')
    .map(session => ({
      id: session.id,
      title: session.title.trim() || session.id.slice(-8),
      status: session.status ?? 'idle',
      canInteract: session.canInteract === true,
    }))

  /** Every running shell job across every live session, keyed back to its owner. */
  const backgroundTasks = () => {
    const titles = new Map(sessions().map(session => [session.id, session.title.trim()]))
    return Object.entries(shellJobsByOwner()).flatMap(([owner, jobs]) => jobs
      .filter(job => job.status === 'running' || job.status === 'stopping')
      .map(job => ({
        owner,
        ownerTitle: titles.get(owner) || owner.slice(-8),
        id: job.id,
        label: job.label,
        status: job.status,
        job,
      })))
  }

  const openShellJobDialog = (sessionId: string, job: ShellJobView): void => {
    openDialog({
      kind: 'shell-output',
      title: job.label + ' · ' + job.status,
      size: 'large',
      sessionId,
      job,
      onDone: () => undefined,
    })
  }
  const openBackgroundTask = (owner: string, id: string): void => {
    const job = backgroundTasks().find(task => task.owner === owner && task.id === id)?.job
    if (job !== undefined) openShellJobDialog(owner, job)
  }


  const openShellJobs = (): void => {
    const sessionId = currentSession()
    const options = shellJobs().flatMap(job => [
      { title: `${job.label} · ${job.status}`, value: `read:${job.id}`, category: job.status, description: `${job.kind} · ${job.id}`, searchText: `${job.label} ${job.kind} ${job.id} ${job.status}` },
      ...(job.status === 'running' || job.status === 'stopping'
        ? [{ title: `Stop ${job.label}`, value: `kill:${job.id}`, category: job.status, description: job.id }]
        : []),
    ])
    if (options.length === 0) {
      openDialog({ kind: 'alert', title: label('rendererShellJobs', 'shell jobs'), message: label('rendererShellJobsEmpty', 'no shell jobs for this session'), onDone: () => undefined })
      return
    }
    openDialog({
      kind: 'select',
      title: label('rendererShellJobs', 'shell jobs'),
      options,
      onDone: value => {
        if (value === undefined) return
        const separator = value.indexOf(':')
        const operation = value.slice(0, separator)
        const id = value.slice(separator + 1)
        if (id === '') return
        const job = shellJobs().find(candidate => candidate.id === id)
        if (job === undefined) return
        if (operation === 'read') {
          openShellJobDialog(sessionId, job)
          return
        }
        if (operation === 'kill') {
          openDialog({
            kind: 'confirm',
            title: label('rendererShellJobsStop', 'stop shell job?'),
            message: job.label,
            onDone: answer => {
              if (answer !== 'confirm') return
              void requestResult('shell-job-op', { sessionId, id, op: 'kill' }).then(result => {
                if (!result.ok) pushNotice('error', result.error ?? 'Could not stop shell job')
              })
            },
          })
        }
      },
    })
  }
  const hostCommandAvailable = (name: string): boolean =>
    availableActions().includes(name) || (name === 'compact' && commands().some(command => command.name === 'compact'))
  const activateTerminal = (sessionId: string, info: WebTerminalInfo): void => {
    const previous = terminalInfo()
    const previousSession = terminalSessionId()
    const previousAttachment = terminalAttachmentId()
    if (previous !== undefined && previousSession !== '' && previousAttachment !== '') {
      releaseTerminal(previousSession, previous.id, previousAttachment)
    }
    setTerminalSessionId(sessionId)
    setTerminalInfo(info)
    setTerminalAttachmentId(crypto.randomUUID())
    setTerminalFrames([])
    setTerminalEndError(undefined)
    setTerminalOpen(true)
    const attachment = terminalAttachmentId()
    void retainTerminal(sessionId, info.id, attachment).catch(error => pushNotice('error', error instanceof Error ? error.message : String(error)))
  }
  const createTerminal = (sessionId: string, environment: TerminalEnvironmentInfo): void => {
    const id = crypto.randomUUID()
    const cols = Math.max(1, Math.min(environment.maxCols, sidebarWidth() - 2))
    const rows = Math.max(1, Math.min(environment.maxRows, terminalSize().height - 3))
    void requestResult('terminal-op', { sessionId, op: 'create', id, cols, rows }).then(result => {
      if (!result.ok) {
        pushNotice('error', result.error ?? 'Could not create terminal')
        return
      }
      if (typeof result.value !== 'object' || result.value === null || !('id' in result.value)) {
        pushNotice('error', 'Terminal controller returned invalid terminal metadata')
        return
      }
      activateTerminal(sessionId, result.value as WebTerminalInfo)
    })
  }
  const openTerminals = (forcePicker = false): void => {
    if (!hostCommandAvailable('terminal.toggle') || route() !== 'session') return
    const sessionId = currentSession()
    if (sessionId === '') return
    void requestResult('terminal-op', { sessionId, op: 'list' }).then(result => {
      if (!result.ok) {
        pushNotice('error', result.error ?? 'Could not list terminals')
        return
      }
      if (typeof result.value !== 'object' || result.value === null || !('terminals' in result.value) || !('environment' in result.value)) {
        pushNotice('error', 'Terminal controller returned invalid list metadata')
        return
      }
      const value = result.value as { terminals: WebTerminalInfo[]; environment: TerminalEnvironmentInfo }
      if (!Array.isArray(value.terminals) || typeof value.environment.maxCols !== 'number' || typeof value.environment.maxRows !== 'number' || typeof value.environment.maxInputBytes !== 'number') {
        pushNotice('error', 'Terminal controller returned invalid environment limits')
        return
      }
      setTerminalEnvironment(value.environment)
      const previous = terminalInfo()
      if (!forcePicker && terminalSessionId() === sessionId && previous !== undefined && value.terminals.some(item => item.id === previous.id)) {
        activateTerminal(sessionId, value.terminals.find(item => item.id === previous.id)!)
        return
      }
      if (value.terminals.length === 0) {
        createTerminal(sessionId, value.environment)
        return
      }
      if (!forcePicker && value.terminals.length === 1) {
        const only = value.terminals[0]
        if (only !== undefined) activateTerminal(sessionId, only)
        return
      }
      openDialog({
        kind: 'select',
        title: label('rendererTerminals', 'terminals'),
        options: [
          ...value.terminals.map(item => ({ title: item.title, value: item.id, description: `${item.shell.name} · ${displayPath(item.cwd)} · ${item.state}` })),
          { title: label('rendererTerminalNew', 'new terminal'), value: '__new-terminal__', category: 'actions' },
        ],
        onDone: selected => {
          if (selected === undefined) return
          if (selected === '__new-terminal__') {
            createTerminal(sessionId, value.environment)
            return
          }
          const selectedInfo = value.terminals.find(item => item.id === selected)
          if (selectedInfo !== undefined) activateTerminal(sessionId, selectedInfo)
        },
      })
    })
  }
  const closeTerminal = (): void => {
    const info = terminalInfo()
    const sessionId = terminalSessionId()
    const attachment = terminalAttachmentId()
    if (info === undefined || sessionId === '') return
    openDialog({
      kind: 'confirm',
      title: label('rendererTerminalCloseAsk', 'close terminal?'),
      message: `${info.title} · ${info.shell.name}`,
      onDone: answer => {
        if (answer !== 'confirm') return
        if (attachment !== '') releaseTerminal(sessionId, info.id, attachment)
        void requestResult('terminal-op', { sessionId, op: 'close', id: info.id }).then(result => {
          if (!result.ok) {
            pushNotice('error', result.error ?? 'Could not close terminal')
            return
          }
          setTerminalOpen(false)
          setTerminalInfo(undefined)
          setTerminalAttachmentId('')
          setTerminalFrames([])
        })
      },
    })
  }
  const hideTerminal = (): void => {
    const info = terminalInfo()
    const sessionId = terminalSessionId()
    const attachment = terminalAttachmentId()
    if (info !== undefined && sessionId !== '' && attachment !== '') releaseTerminal(sessionId, info.id, attachment)
    setTerminalOpen(false)
  }
  const retainTerminal = async (sessionId: string, id: string, attachmentId: string): Promise<void> => {
    const result = await requestResult('terminal-op', { sessionId, op: 'retain', id, attachmentId })
    if (!result.ok) throw new Error(result.error ?? 'Could not retain terminal')
  }
  const releaseTerminal = (sessionId: string, id: string, attachmentId: string): void => {
    void requestResult('terminal-op', { sessionId, op: 'release', id, attachmentId }).then(result => {
      if (!result.ok) pushNotice('error', result.error ?? 'Could not release terminal')
    })
  }
  const followTerminal = async (sessionId: string, id: string, attachmentId: string): Promise<void> => {
    const result = await requestResult('terminal-op', { sessionId, op: 'follow', id, attachmentId })
    if (!result.ok) throw new Error(result.error ?? 'Could not attach to terminal')
  }
  const writeTerminal = (sessionId: string, id: string, attachmentId: string, data: string): void => {
    void requestResult('terminal-op', { sessionId, op: 'write', id, attachmentId, data }).then(result => {
      if (!result.ok) pushNotice('error', result.error ?? 'Could not write terminal input')
    })
  }
  const resizeTerminal = (sessionId: string, id: string, attachmentId: string, cols: number, rows: number): void => {
    void requestResult('terminal-op', { sessionId, op: 'resize', id, attachmentId, cols, rows }).then(result => {
      if (!result.ok) pushNotice('error', result.error ?? 'Could not resize terminal')
    })
  }
  const detachTerminal = (sessionId: string, id: string, attachmentId: string): void => {
    void requestResult('terminal-op', { sessionId, op: 'detach', id, attachmentId }).then(result => {
      if (!result.ok) pushNotice('error', result.error ?? 'Could not detach terminal')
    })
  }
  const consumeTerminalFrames = (count: number): void => { setTerminalFrames(frames => frames.slice(count)) }
  const registerTerminalKeyHandler = (handler: typeof terminalKeyHandler): void => { terminalKeyHandler = handler }
  const handleTerminalKey = (event: TerminalKeyInput, leaderActive: boolean): boolean => {
    if (dialogStack().length > 0 || leaderActive || (event.ctrl && !event.meta && !event.shift && event.name.toLowerCase() === 'x')) return false
    return terminalKeyHandler?.(event) ?? false
  }
  const openRenameSession = (targetId: string = currentSession()): void => {
    const initial = targetId === currentSession()
      ? sessionTitle()
      : sessions().find(session => session.id === targetId)?.title ?? targetId
    openDialog({
      kind: 'prompt',
      title: label('rendererPaletteRename', 'rename session'),
      value: initial,
      placeholder: 'Session title',
      onDone: value => {
        const title = value?.trim()
        if (title === undefined || title === '') return
        void requestResult('session-op', { op: 'rename', sessionId: targetId, title }).then(result => {
          if (!result.ok) pushNotice('error', result.error ?? 'Session rename failed')
        })
      },
    })
  }
  /**
   * The one quit: tell the host, then end this process. The renderer owns the TTY, so it
   * restores the screen and the mouse modes itself (see `main.tsx`); waiting for the host
   * instead is what left a mouse-reporting shell behind. Repeated calls are no-ops, so a
   * second ctrl+c during the shutdown cannot send a second `bye`.
   */
  let quitRequested = false
  const finishQuit = (reason: string): void => {
    if (quitRequested) return
    quitRequested = true
    send('bye', { reason })
    requestExit()
  }
  /** The running-work shortcut: open every live session as a tab and focus the first. */
  const openRunningSessions = (): void => {
    const running = sessions().filter(session => session.status === 'running')
    for (const session of running) openTab(session.id, session.title)
    const first = running[0]
    if (first !== undefined) selectTab(first.id)
  }
  const requestQuit = (reason: string): void => {
    if (quitRequested) return
    const running = sessions().filter(session => session.status === 'running')
    if (running.length === 0) {
      finishQuit(reason)
      return
    }
    const detach = daemonDetach()
    openDialog({
      kind: 'select',
      title: label('rendererExitTitle', 'exit dpsk'),
      options: [
        {
          title: detach ? label('rendererExitDetach', 'exit TUI (tasks continue in background)') : label('rendererExitEndsTasks', 'exit anyway (running tasks will stop)'),
          value: 'quit',
          description: detach ? label('rendererExitDetachHint', 'the core process and its running tasks stay alive') : label('rendererExitEndsTasksHint', 'embedded mode exits the core process and stops its tasks'),
        },
        { title: label('rendererExitOpenRunning', 'open every running session'), value: 'running' },
        { title: label('rendererCancel', 'cancel'), value: 'cancel' },
      ],
      onDone: value => {
        if (value === 'quit') finishQuit(reason)
        else if (value === 'running') openRunningSessions()
      },
    })
  }
  /** `/shutdown`: a deliberate full-core stop, distinct from detaching the TUI. */
  const requestShutdown = (): void => {
    openDialog({
      kind: 'confirm',
      title: label('rendererShutdownTitle', 'Shut down the core process?'),
      message: label('rendererShutdownMessage', 'This ends the core process and interrupts every running task. Use /exit to detach the TUI and leave work running.'),
      onDone: answer => {
        if (answer !== 'confirm') return
        quitRequested = true
        send('shutdown', { reason: 'renderer shutdown' })
        setTimeout(requestExit, 100)
      },
    })
  }

  const interceptCommand = (text: string): boolean => {
    const line = text.trim()
    // A host command the session cannot run is not offered: the draft goes upstream
    // verbatim, exactly as the host's own parser would leave an unknown line.
    if (line.startsWith('/') && line !== '/' && !line.includes(' ')) {
      const name = line.slice(1)
      // Canonical names are opencode's (`/models`, `/agents`, `/effort`, `/sessions`,
      // `/themes`, `/status`); the older dsh spellings stay as aliases so muscle memory
      // keeps working, and neither is sent upstream.
      const local = [
        'models', 'model', 'agents', 'mode', 'effort', 'think', 'variants', 'thinking',
        'sessions', 'resume', 'continue', 'themes', 'theme', 'status', 'details',
        'settings', 'skills', 'help', 'permission', 'doctor', 'plugins', 'mcps',
        'rename', 'queue', 'palette', 'trace', 'exit', 'shutdown',
        ...(hostCommandAvailable('shell.jobs') ? ['shell'] : []),
      ].includes(name)
      if (!local && commands().some(command => command.name === name) && !hostCommandAvailable(name)) return false
    }
    switch (line) {
      case '/themes':
      case '/theme':
        // The native renderer owns the theme catalog; `/theme` opens its picker instead of
        // asking the host for a palette it no longer has.
        openThemeDialog()
        return true
      case '/rename':
        openRenameSession()
        return true
      case '/settings':
        openSettings()
        return true
      case '/queue':
        openQueueDialog()
        return true
      case '/trace':
        openTrace()
        return true
      case '/exit':
        requestQuit('renderer exit')
        return true
      case '/shutdown':
        requestShutdown()
        return true
      case '/doctor':
        requestDoctor('doctor')
        return true
      case '/plugins':
        requestDoctor('plugins')
        return true
      case '/mcps':
        openMcpDialog()
        return true
      case '/shell':
        if (!hostCommandAvailable('shell.jobs')) return false
        openShellJobs()
        return true
      case '/models':
      case '/model':
        openModelDialog()
        return true
      case '/sessions':
      case '/continue':
      case '/resume':
        openSessionPicker()
        return true
      case '/palette':
        openPalette(label('rendererPaletteTitle', 'palette'), '')
        return true
      case '/effort':
      case '/variants':
      case '/thinking':
      case '/think':
        // The effort list is the host's `reasoning-efforts`; a pick writes through the
        // same `set-selection` seam `ctrl+t` uses.
        openDialog({
          kind: 'select',
          title: label('rendererThink', 'reasoning effort'),
          options: efforts().map(effort => ({ title: effort, value: `effort:${effort}` })),
          current: `effort:${effortCurrent()}`,
          onDone: value => {
            if (value !== undefined) runPaletteEntry(value)
          },
        })
        return true
      case '/permission':
        openDialog({
          kind: 'select',
          title: label('rendererPermission', 'permission'),
          options: permissionChoices().map(preset => ({ title: preset.label, value: `permission:${preset.id}` })),
          current: `permission:${permission()}`,
          onDone: value => {
            if (value !== undefined) runPaletteEntry(value)
          },
        })
        return true
      case '/agents':
      case '/mode':
        openDialog({
          kind: 'select',
          title: label('rendererMode', 'agent'),
          options: agentPresets().map(preset => ({ title: preset.label, value: `mode:${preset.id}` })),
          current: `mode:${preset()}`,
          onDone: value => {
            if (value !== undefined) runPaletteEntry(value)
          },
        })
        return true
      case '/skills':
        // The skills list is the host's snapshot; a pick sends the `skill:<name>` line the
        // registry already owns, exactly like the palette's skills group.
        openDialog({
          kind: 'select',
          title: label('rendererSkills', 'skills'),
          options: skills().map(skill => ({ title: skill.name, value: `skill:${skill.name}`, description: skill.description, searchText: skill.name })),
          onDone: value => {
            if (value !== undefined) runPaletteEntry(value)
          },
        })
        return true
      case '/status':
      case '/details':
        // The renderer holds the route, the workspace, and the usage the host measured,
        // so the details page is local; nothing here is a guess about host-only state.
        openDialog({
          kind: 'alert',
          title: label('rendererDetails', 'session details'),
          message: [
            `${label('rendererSession', 'session: ')}${sessionTitle()}`,
            `${label('rendererStatus', 'status: ')}${provider()}/${model()} · ${effortCurrent()} · ${permission()} · ${presetLabel()}`,
            `workspace: ${displayPath(workspace())}`,
            usage() === undefined ? 'usage: —' : `tokens: ${formatTokens(usage()?.inputTokens ?? 0)} in · ${formatTokens(usage()?.outputTokens ?? 0)} out`,
            usage()?.contextTokens === undefined
              ? 'context: —'
              : `context: ${formatTokens(usage()?.contextTokens ?? 0)}${usage()?.contextPct === undefined ? '' : ` (${usage()?.contextPct}%)`}`,
          ].join('\n'),
          onDone: () => undefined,
        })
        return true
      case '/help':
        openDialog({
          kind: 'alert',
          title: label('rendererKeysTitle', 'keys'),
          message: label(
            'rendererKeysHelp',
            'ctrl+p palette · ctrl+x n/l/m/b/c/s/x/q · ctrl+tab sessions · shift+tab agent · f2 model · ctrl+t effort · tab complete · esc interrupt · alt+up edit interjection · pageup/pagedown scroll',
          ),
          onDone: () => undefined,
        })
        return true
      default:
        return false
    }
  }

  /**
   * The catalog rows a picker or tab may list. A session that never got past its setup
   * events is a leftover "New Session" shell: the desktop client hides those, and the
   * host marks both persisted and live shells with `blank`. The Home route has its own
   * draft-tab representation, so even the current blank session stays out of this catalog.
   */
  const listableSessions = (): ReturnType<typeof sessions> =>
    sessions().filter(session => session.blank !== true)
  const openSessionRows = (scope: 'project' | 'all'): void => {
    const visible = listableSessions()
    const rows = scope === 'project'
      ? visible.filter(session => {
        if (workspace() === '' || session.workspace === undefined) return false
        const activePath = resolve(workspace())
        const targetPath = resolve(session.workspace)
        return process.platform === 'win32'
          ? activePath.toLowerCase() === targetPath.toLowerCase()
          : activePath === targetPath
      })
      : visible
    const now = Date.now()
    const activityLabels = {
      today: label('rendererSessionToday', 'today'),
      yesterday: label('rendererSessionYesterday', 'yesterday'),
      last7Days: label('rendererSessionLast7Days', 'last 7 days'),
    }
    const options = rows.map(session => {
      const activityAt = session.lastActivityAt ?? session.createdAt
      const activity = formatSessionActivityLabel(activityAt, now, locale(), activityLabels)
      // The picker is a quick switcher, not a session inspector: keep one title and one
      // coarse time marker. The id/workspace/status stay searchable but never paint.
      const searchText = [session.id, session.title, session.workspace, session.parentId, session.status]
        .filter((value): value is string => typeof value === 'string' && value !== '')
        .join(' ')
      return {
        title: session.title.trim() === '' ? untitledLabel() : session.title,
        value: session.id,
        searchText,
        ...(activity === '' ? {} : { footer: activity }),
      }
    })
    openDialog({
      kind: 'select',
      title: scope === 'all' ? 'All sessions' : 'Current project sessions',
      options,
      current: currentSession(),
      onDone: value => { if (value !== undefined) pickSession(value) },
    })
  }

  const openSessionPicker = (): void => {
    if (sessions().length === 0) {
      openSessionRows('all')
      return
    }
    openDialog({
      kind: 'select',
      title: label('rendererSessionPicker', 'sessions'),
      options: [
        { title: label('rendererSessionScopeProject', 'current project'), value: 'project', description: displayPath(workspace()) || label('rendererNoWorkspace', 'no current workspace') },
        { title: label('rendererSessionScopeAll', 'all sessions'), value: 'all', description: label('rendererSessionCount', '{count} sessions').replace('{count}', String(listableSessions().length)) },
      ],
      onDone: value => {
        if (value === 'project') openSessionRows('project')
        else if (value === 'all') openSessionRows('all')
      },
    })
  }
  const openMcpDialog = (): void => {
    openDialog({
      kind: 'select',
      title: label('rendererMcpServers', 'MCP servers'),
      options: mcpServers().map(server => ({ title: server.name, value: server.id, description: server.id, searchText: server.name })),
      onDone: () => undefined,
    })
  }

  /** Open the palette as a select dialog. `category` narrows the rows on open. */
  /**
   * Read one durable attachment through the host and show it. The host verifies that the
   * reference belongs to this session's log (or its queue) and enforces the 20 MiB read
   * bound; an image opens in the terminal's image preview, a file in a paged text dialog.
   */
  const openAttachment = async (attachment: NonNullable<TranscriptEvent['attachments']>[number]): Promise<void> => {
    const result = await requestResult('attachment-read', { sessionId: currentSession(), attachment })
    if (!result.ok) {
      pushNotice('error', result.error ?? 'Could not read attachment')
      return
    }
    const value = result.value as { type?: string; data?: string; name?: string; mediaType?: string } | undefined
    if (value?.type === 'image' && typeof value.data === 'string') {
      setAttachmentPreview({ name: attachment.name ?? attachment.attachmentId, mediaType: value.mediaType ?? attachment.mediaType ?? 'image/png', bytes: Buffer.from(value.data, 'base64') })
      return
    }
    if (value?.type === 'file' && typeof value.data === 'string') {
      const text = Buffer.from(value.data, 'base64').toString('utf8')
      openDialog({
        kind: 'alert',
        title: attachment.name ?? attachment.attachmentId,
        message: text,
        onDone: () => undefined,
      })
      return
    }
    pushNotice('error', 'Attachment read returned an unexpected payload')
  }


  /** The native theme picker: every theme the provider offers, previewed as it is picked. */
  const openThemeDialog = (): void => {
    const controls = themeControls()
    if (controls === undefined) return
    const names = Object.keys(controls.all()).sort((left, right) => left.localeCompare(right, undefined, { sensitivity: 'base' }))
    const initial = controls.selected()
    let confirmed = false
    const id = openDialog({
      kind: 'select',
      title: label('rendererThemes', 'themes'),
      options: names.map(value => ({ title: value, value })),
      current: initial,
      onPreview: value => {
        controls.preview(value)
      },
      onDone: value => {
        if (value === undefined) {
          // Cancel restores the committed theme without writing anything back.
          if (!confirmed) controls.preview(initial)
          return
        }
        controls.set(value)
        confirmed = true
        void id
      },
    })
  }

  /**
   * The model picker.
   *
   * Upstream registers exactly one command for this (`model.list`, titled "Switch model")
   * and it opens a dialog; cycling recent models is a *separate* command bound to F2. dsh
   * used to route `/model` and `ctrl+x m` into the generic palette filtered to its model
   * rows, which read like a menu of commands and left the cycle bound to the same word.
   * One dialog keeps all three entry points — the palette row, `ctrl+x m`, `/model` — on
   * the same picker, and the pick still commits through the `set-selection` seam.
   */
  const openModelDialog = (): void => {
    const providerLabel = new Map(providers().map(row => [row.id, row.label]))
    const options = models().map(entry => ({
      title: entry.label,
      value: `model:${entry.provider}/${entry.model}`,
      // Upstream groups the list by provider; the provider label is the section header.
      category: providerLabel.get(entry.provider) ?? entry.provider,
      description: entry.model,
      searchText: `${entry.model} ${entry.provider} ${providerLabel.get(entry.provider) ?? ''} ${entry.label}`,
      ...(entry.current ? { footer: label('rendererCurrent', 'current') } : {}),
    }))
    if (options.length === 0) {
      openDialog({
        kind: 'alert',
        title: label('rendererSwitchModel', 'Switch model'),
        message: 'No models are available for this session yet.',
        onDone: () => undefined,
      })
      return
    }
    openDialog({
      kind: 'select',
      title: label('rendererSwitchModel', 'Switch model'),
      options,
      sectionNavigation: true,
      current: options.find(option => option.footer !== undefined)?.value,
      onDone: value => {
        if (value !== undefined) runPaletteEntry(value)
      },
    })
  }

  const openPalette = (title: string, category: string): void => {
    const translate = (key: string, fallback: string): string => label(key, fallback)
    // The section header these dynamic rows join: the palette's `actions` group, translated
    // the same way `paletteOptions` translates it, or the rows would land under a second
    // header spelled `actions` beside `操作`.
    const actionCategory = translate('rendererPaletteActions', 'actions')
    const options = paletteOptions({
      efforts: efforts(),
      effortCurrent: effortCurrent(),
      skills: skills(),
      providers: providers(),
      permissions: permissionPresets(),
      permissionCurrent: permission(),
      modes: agentPresets(),
      modeCurrent: preset(),
      currentLabel: label('rendererCurrent', 'current'),
      t: translate,
    })
    if (interjections().length > 0) {
      options.unshift({ title: translate('rendererPaletteQueue', 'manage queued messages'), value: 'action:manage-queue', category: actionCategory, searchText: 'queue' })
    }
    if (hostCommandAvailable('shell.jobs')) options.unshift({ title: translate('rendererPaletteShellJobs', 'list shell jobs'), value: 'action:show-shell-jobs', category: actionCategory, searchText: 'shell jobs' })
    if (route() === 'session' && hostCommandAvailable('terminal.toggle')) {
      options.unshift({
        title: terminalOpen() ? translate('rendererPaletteTerminalHide', 'hide terminal') : translate('rendererPaletteTerminalOpen', 'open terminal'),
        value: 'action:terminal.toggle',
        category: actionCategory,
        searchText: 'terminal shell',
      })
    }
    if (route() === 'session' && hostCommandAvailable('terminal.select')) options.unshift({ title: translate('rendererPaletteTerminalSelect', 'select terminal'), value: 'action:terminal.select', category: actionCategory, searchText: 'terminal shell' })
    if (route() === 'session' && hostCommandAvailable('terminal.close') && terminalInfo() !== undefined) options.unshift({ title: translate('rendererPaletteTerminalClose', 'close terminal'), value: 'action:terminal.close', category: actionCategory, searchText: 'terminal shell' })
    openDialog({
      kind: 'select',
      title,
      options,
      sectionNavigation: true,
      categoryFilter: category === '' ? undefined : category,
      onDone: value => {
        if (value !== undefined) runPaletteEntry(value)
      },
    })
  }

  /** A palette entry id is `group:value`; running it is the same request the
   * keymap action makes, so there is one path from a pick to the host. */
  const runPaletteEntry = (entryId: string): void => {
    const separator = entryId.indexOf(':')
    const group = separator === -1 ? entryId : entryId.slice(0, separator)
    const value = separator === -1 ? '' : entryId.slice(separator + 1)
    switch (group) {
      case 'action':
        // A `slash:` action is the palette's route to the local command vocabulary: it goes
        // through the same interceptor a typed `/command` does.
        if (value.startsWith('slash:')) {
          interceptCommand(value.slice('slash:'.length))
          return
        }
        runAction(value)
        return
      case 'model': {
        const split = value.indexOf('/')
        if (split === -1) return
        pickModel(value.slice(0, split), value.slice(split + 1))
        return
      }
      case 'effort':
        pickEffort(value)
        return
      case 'session':
        pickSession(value)
        return
      case 'skill':
        reportRequest('send-message', { sessionId: currentSession(), text: '', delivery: 'steer', skills: [value] })
        return
      case 'permission':
        // A permission pick writes through the host's selection seam, which maps the
        // user-facing name onto the registry preset and lands it on the session. The
        // picker's ids arrive in that same vocabulary, so no translation happens here.
        applySelection({ permission: value })
        return
      case 'mode':
        applySelection({ preset: value })
        return
      case 'wechat':
        // The bridge owns the login state machine; the renderer asks for the command
        // and renders what the bridge pushes back as `wechat-output`.
        send('wechat-op', { op: value })
        return
      default:
        return
    }
  }

  /** Run one keymap action. Every action is a request the host performs; the
   * renderer never touches dsh services directly. Modal actions drive the dialog
   * that currently owns the keyboard. */
  /**
   * Clear a live text selection, if there is one. Upstream checks the renderer's selection
   * before the draft: Ctrl+C with text selected copies/clears, it does not discard the
   * draft the user is still typing in.
   */
  /** True while the renderer has any text selection; used by click-vs-drag guards. */
  const hasTextSelection = (): boolean => {
    const selected = (shellRenderer as { getSelection?: () => { getSelectedText: () => string } | null } | undefined)?.getSelection?.()
    return selected !== null && selected !== undefined && selected.getSelectedText().trim() !== ''
  }
  const clearTextSelection = (): boolean => {
    const view = shellRenderer
    if (view === undefined || view.hasSelection !== true) return false
    view.clearSelection?.()
    return true
  }

  const runAction = (action: string): void => {
    const controller = dialogController()
    // `leader 1..9` picks the Nth open tab (the strip's numbers), not the catalog row.
    if (action.startsWith('select-session-')) {
      const digit = Number(action.slice('select-session-'.length))
      const index = digit === 0 ? 9 : digit - 1
      const target = openTabs()[index]
      if (target !== undefined) selectTab(target)
      return
    }
    switch (action) {
      case 'palette':
        openPalette(label('rendererPalette', 'command palette'), '')
        return
      case 'show-shell-jobs':
        openShellJobs()
        return
      case 'pick-theme':
        openThemeDialog()
        return
      case 'terminal.toggle':
        if (terminalOpen()) hideTerminal()
        else openTerminals()
        return
      case 'terminal.select':
        openTerminals(true)
        return
      case 'terminal.close':
        closeTerminal()
        return
      case 'pick-model':
        openModelDialog()
        return
      case 'list-sessions':
        openSessionPicker()
        return
      case 'manage-queue':
        openQueueDialog()
        return
      case 'trace':
        openTrace()
        return
      case 'settings':
        openSettings()
        return
      case 'rename-session':
        openRenameSession()
        return
      case 'composer-accept': {
        // `tab` accepts the highlighted popup row; with no popup the first match is the
        // same row the popup would have shown, so the key stays useful for one-row lists.
        const rows = completions()
        const row = rows[completionSelection()] ?? rows[0]
        if (row !== undefined) acceptCompletion(row)
        return
      }
      case 'cycle-effort': {
        const list = efforts()
        if (list.length === 0) return
        const index = list.indexOf(effortCurrent())
        const next = list[(index + 1) % list.length]
        if (next === undefined) return
        pickEffort(next)
        return
      }
      case 'new-session':
        startNewSession()
        return
      case 'close-session-tab':
        closeSessionTab()
        return
      case 'reopen-session-tab':
        reopenSessionTab()
        return
      case 'next-tab':
        cycleTab(1)
        return
      case 'previous-tab':
        cycleTab(-1)
        return
      case 'compact':
        reportRequest('send-message', { sessionId: currentSession(), text: '/compact', delivery: 'steer' })
        return
      case 'export':
        chooseSessionExport()
        return
      case 'exit':
        requestQuit('renderer exit')
        return
      case 'shutdown':
        requestShutdown()
        return
      case 'open-editor':
        openExternalEditor()
        return
      case 'copy-message':
        copyLastMessage()
        return
      case 'paste-clipboard':
        pasteFromClipboard()
        return
      case 'cancel':
        // Upstream's Ctrl+C priority: clear a text selection, then a draft, then the top
        // modal; an empty prompt with nothing open is the real exit request.
        if (clearTextSelection()) return
        if (dialogStack().length > 0) {
          closeTopDialog(undefined)
          return
        }
        if (composer() !== '') {
          setComposer('')
          return
        }
        requestQuit('renderer ctrl+c')
        return
      case 'dialog-prev':
        if (controller !== undefined) controller.move(-1)
        else recallHistory(-1)
        return
      case 'dialog-next':
        if (controller !== undefined) controller.move(1)
        else recallHistory(1)
        return
      case 'dialog-page-up':
        // With no dialog owning the keyboard, `pageup` wheels the transcript viewport up.
        if (controller !== undefined) controller.move(-10)
        else scrollRows(-10)
        return
      case 'dialog-page-down':
        if (controller !== undefined) controller.move(10)
        else scrollRows(10)
        return
      case 'jump-latest':
        jumpToLatest()
        return
      case 'completion-prev': {
        const rows = completions()
        if (rows.length === 0) return
        setCompletionSelection((completionSelection() - 1 + rows.length) % rows.length)
        return
      }
      case 'completion-next': {
        const rows = completions()
        if (rows.length === 0) return
        setCompletionSelection((completionSelection() + 1) % rows.length)
        return
      }
      case 'completion-accept': {
        // The popup owns `return` and `tab`: accept the highlighted row.
        const rows = completions()
        const row = rows[completionSelection()]
        if (row !== undefined) { acceptCompletion(row); setPopupAccepted(true) }
        return
      }
      case 'completion-close':
        // `escape` closes the popup without touching the draft; the popup stays hidden
        // until the composer text changes again.
        setCompletionClosed(true)
        return
      case 'interrupt':
        reportRequest('interrupt', { sessionId: currentSession() })
        return
      case 'toggle-sidebar':
        toggleSidebar()
        return
      case 'cycle-session':
      case 'cycle-session-back': {
        const list = sessions()
        if (list.length < 2) return
        const index = list.findIndex(session => session.active)
        const next = action === 'cycle-session'
          ? list[(index + 1) % list.length]
          : list[(index - 1 + list.length) % list.length]
        if (next !== undefined) pickSession(next.id)
        return
      }
      case 'cycle-model':
      case 'cycle-model-back': {
        const catalog = models()
        if (catalog.length < 2) return
        // Match the live route on provider *and* model: the same model id can exist on two
        // providers, and a model-only match starts the cycle from index -1 (element 0).
        const index = catalog.findIndex(entry => entry.model === model() && entry.provider === provider())
        const next = action === 'cycle-model'
          ? catalog[(index + 1) % catalog.length]
          : catalog[(index - 1 + catalog.length) % catalog.length]
        if (next !== undefined) pickModel(next.provider, next.model)
        return
      }
      case 'cycle-preset': {
        const presets = agentPresets()
        if (presets.length < 2) return
        const index = presets.findIndex(entry => entry.id === preset())
        const next = presets[(index + 1) % presets.length]
        if (next !== undefined) applySelection({ preset: next.id })
        return
      }
      case 'history-prev': {
        // `up` only leaves the draft at its first line; inside the text the textarea
        // keeps the key (this action runs, but the list does not move).
        if (composerBuffer !== undefined && (composerBuffer.logicalCursor?.row ?? 0) > 0) return
        recallHistory(-1)
        return
      }
      case 'history-next': {
        if (composerBuffer !== undefined) {
          const lastLine = composerBuffer.plainText.split('\n').length - 1
          if ((composerBuffer.logicalCursor?.row ?? 0) < lastLine) return
        }
        recallHistory(1)
        return
      }
      case 'dialog-home':
        controller?.moveTo(0)
        return
      case 'dialog-end':
        if (controller !== undefined) controller.moveTo(controller.count() - 1)
        return
      case 'dialog-section-prev':
        // `Alt+Up` is the 0.4.0 interjection-edit binding: with no dialog open it
        // asks the host to pull the oldest queued interjection back into the composer.
        if (controller !== undefined) controller.moveSection(-1)
        else editInterjection()
        return
      case 'dialog-section-next':
        controller?.moveSection(1)
        return
      case 'dialog-left':
        controller?.moveColumn(-1)
        return
      case 'dialog-right':
        controller?.moveColumn(1)
        return
      case 'dialog-submit':
        controller?.submit()
        return
      case 'dialog-toggle':
        controller?.toggle?.()
        return
      case 'dialog-close':
        if (dialogStack().length === 0 && attachmentPreview() !== undefined) {
          setAttachmentPreview(undefined)
          return
        }
        closeTopDialog(undefined)
        return
      default:
        return
    }
  }

  return {
    status,
    setStatus,
    hostLabel,
    setHostLabel,
    hostVersion,
    sessionTitle,
    setSessionTitle,
    route,
    readOnly,
    transcript,
    transcriptRevision,
    setTranscript,
    composer,
    setComposer,
    /** The visible notice, the queue behind it, and the timer controls the overlay reads. */
    toast: () => toastQueue.current(),
    pendingToasts: () => toastQueue.pending(),
    toastRemaining: () => toastQueue.remaining(),
    pauseToast: () => toastQueue.pause(),
    resumeToast: () => toastQueue.resume(),
    dismissToast,
    /** A notice lands as a toast. The renderer never writes to stderr (Bun closes the IPC
     * channel on the first stderr write), so warnings route here and paint in the overlay. */
    pushNotice,
    completionSelection,
    setCompletionSelection,
    acceptCompletion,
    collapsedReasoning,
    toggleReasoning,
    newThinkingStyle: () => settings().newDesigns === true,
    thinkingMode,
    toggleThinking,
    showReasoning: () => settings().showReasoning !== false,
    reasoningOpenByDefault: () => settings().showReasoning !== false,
    animations: () => settings().animations !== false,
    toolOutputLines: () => {
      const value = settings().maxToolOutputLines
      return typeof value === 'number' && Number.isFinite(value) && value > 0 ? Math.trunc(value) : 10
    },
    setScrollbox,
    /** The shell registers the composer textarea so the history keys can read its caret. */
    setComposerBuffer: (buffer: typeof composerBuffer) => { composerBuffer = buffer },
    /** The catalogs and rows the popup completes: one source for the popup and the keys. */
    catalogs: completionCatalogs,
    completions,
    awayFromBottom,
    jumpToLatest,
    settleStickyTop,
    scrollRows,
    terminalSize,
    setTerminalSize,
    mentions,
    setMentions,
    availableActions,
    setAvailableActions,
    efforts,
    effortCurrent,
    provider,
    model,
    permission,
    preset,
    sessions,
    attachmentCapabilities,
    pendingAttachments,
    pendingAttachmentsForCurrent,
    removePendingAttachments,
    handlePaste,
    currentSession,
    workspace,
    /** User-facing path formatting; never feed this value to a host operation. */
    displayPath,
    pathDisplayMode,
    settings,
    locale,
    strings,
    label,
    traceRows,
    wechatQr,
    wechatStatus,
    wechatState,
    slashCommands,
    sidebarCollapsed,
    toggleSidebarSection,
    subagents,
    skills,
    usage,
    gitBranch,
    mcpServers,
    hostPlugins,
    todos,
    interjections,
    shellJobs,
    subagentsForCurrent: sidebarSubagents,
    backgroundTasks,
    openBackgroundTask,
    terminalOpen,
    terminalSessionId,
    terminalInfo,
    terminalEnvironment,
    terminalAttachmentId,
    terminalFrames,
    terminalEndError,
    consumeTerminalFrames,
    registerTerminalKeyHandler,
    handleTerminalKey,
    followTerminal,
    retainTerminal,
    releaseTerminal,
    detachTerminal,
    writeTerminal,
    resizeTerminal,
    closeTerminal,
    readShellJob: (sessionId: string, id: string, from: number) => requestResult('shell-job-op', { sessionId, id, op: 'read', from }),
    sidebarState,
    toggleSidebar,
    sidebarWidth,
    resizeSidebar,
    providers,
    permissionPresets,
    agentPresets,
    setSetting,
    turnRunning,
    commands,
    models,
    history,
    historyIndex,
    dialogStack,
    dialogController,
    setDialogController,
    openDialog,
    closeTopDialog,
    requestDialog,
    dialogOpen: (): boolean => dialogStack().length > 0,
    /** The writer the open harness form registers; the discovery answer writes through it. */
    formFieldWriter,
    setFormFieldWriter,
    pickEffort,
    pickSession,
    startNewSession,
    presetLabel,
    modeLabel,
    permissionLabel,
    /** Mix `weight` of `color` into `base` (`#rrggbb` inputs): native `tint` for a hex pair. */
    mix: (base: string, color: string, weight: number): string => {
      const parse = (value: string): [number, number, number] | undefined => {
        const match = /^#([0-9a-f]{6})$/i.exec(value.trim())
        if (match === null) return undefined
        const hex = match[1] ?? ''
        return [0, 2, 4].map(offset => Number.parseInt(hex.slice(offset, offset + 2), 16)) as [number, number, number]
      }
      const from = parse(base)
      const to = parse(color)
      if (from === undefined || to === undefined) return color
      const ratio = Math.max(0, Math.min(1, weight))
      const channel = (index: number): string =>
        Math.round((from[index] ?? 0) * (1 - ratio) + (to[index] ?? 0) * ratio).toString(16).padStart(2, '0')
      return `#${channel(0)}${channel(1)}${channel(2)}`
    },
    attachmentPreview,
    openAttachment,
    closeAttachmentPreview: () => setAttachmentPreview(undefined),
    /** The native theme provider's persisted-selection adapter. */
    themeStorage,
    /** One token's color by full path (`text.base`, `@dialog.text.base`), from the native
     * provider's resolved theme. `undefined` lets the component paint its own literal. */
    color: (path: string): string | undefined => activeTokenHex(path),
    /** The theme's selected-text pair, intentionally distinct from `text.base` as a bg. */
    selectionBg: () => activeTokenHex('background.raised.max') ?? '#313244',
    selectionFg: () => activeTokenHex('text.base') ?? '#cdd6f4',
    hasTextSelection,
    /** The token's color one slot down its own hue scale: native `theme.decrease()`. */
    decrease: (path: string, amount = 1): string | undefined => activeDecreaseHex(path, amount),
    /** The composer's Enter: send the draft upstream and clear it. */
    submitComposer,
    runAction,
    keyLayer,
    popupOpen,
    popupAccepted,
    resetPopupAccepted: () => setPopupAccepted(false),
    rejectPendingRequests,
    /** The shell owns the attention service; it is disposed with the renderer. */
    setAttention,
    setLocalStorage,
    hasLocalStorage,
    flushLocalState,
    disposeServices,
    loadHistory,
    loadDrafts,
    loadTabs,
    activeTabId,
    openTabs,
    tabTitle,
    openTab,
    selectTab,
    newSessionTab,
    closeTab,
    closeSessionTab,
    closeOtherTabs,
    moveTab,
    moveTabTo,
    openTabMenu,
    reopenSessionTab,
    cycleTab,
    setClipboard,
    /** The shell registers its renderer so store-level actions can read the selection. */
    setRenderer: (view: { readonly hasSelection?: boolean; clearSelection?: () => void; readonly root?: unknown } | undefined) => {
      shellRenderer = view
    },
    /** Apply one downstream envelope to the store. Unknown kinds are ignored. */
    apply: (envelope: IpcEnvelope) => {
      const payload = typeof envelope.payload === 'object' && envelope.payload !== null ? (envelope.payload as Record<string, unknown>) : {}
      switch (envelope.kind) {
        case 'hello-ack': {
          const ack = payload as { hostId?: string; hostVersion?: string; status?: NegotiationStatus; capabilities?: string[]; terminalSize?: { width?: number; height?: number } }
          setStatus(ack.status ?? 'unknown')
          setHostLabel(`host: ${ack.hostId ?? 'unknown'} ${ack.hostVersion ?? ''}`.trim())
          setHostVersion(ack.hostVersion ?? '')
          setDaemonDetach(Array.isArray(ack.capabilities) && ack.capabilities.includes('daemon-detach'))
          // The grid the host read from the environment is the starting geometry; the renderer's
          // own measurement replaces it as soon as the renderer exists.
          if (typeof ack.terminalSize?.width === 'number' && typeof ack.terminalSize?.height === 'number') {
            setTerminalSize({ width: ack.terminalSize.width, height: ack.terminalSize.height })
          }
          return
        }
        case 'settings': {
          const values = payload as { ns?: string; values?: Record<string, unknown>; agentLoop?: Record<string, unknown>; requestId?: string; error?: string }
          // A push from another namespace (the agent-loop row) must not replace the TUI
          // section: only this row's namespace and the initial push (no ns) are adopted.
          if (typeof values.ns === 'string' && values.ns !== '' && values.ns !== 'dpsk-tui') return
          const merged: Record<string, unknown> = { ...(values.values ?? {}) }
          if (values.agentLoop !== undefined) Object.assign(merged, values.agentLoop)
          setSettings(merged)
          if (typeof values.requestId === 'string') {
            const settle = pendingSettings.get(values.requestId)
            pendingSettings.delete(values.requestId)
            settle?.(typeof values.error === 'string' ? values.error : undefined)
          }
          return
        }
        case 'workspace-files': {
          if (!isCurrentSessionPayload(payload)) return
          const files = payload as { files?: unknown }
          setMentions(Array.isArray(files.files) ? files.files.filter((file): file is string => typeof file === 'string') : [])
          return
        }
        case 'reasoning-efforts': {
          if (!isCurrentSessionPayload(payload)) return
          const efforts = payload as { efforts?: string[]; current?: string }
          setEfforts(efforts.efforts ?? [])
          setEffortCurrent(efforts.current ?? '')
          return
        }
        case 'session-list': {
          const list = payload as { sessions?: Array<{ id: string; title: string; active: boolean; workspace?: string; parentId?: string; sessionKind?: 'main' | 'subagent'; canInteract?: boolean; createdAt: number; lastActivityAt?: number; status: 'idle' | 'running'; attention: boolean; blank?: boolean }>; current?: string }
          const currentId = typeof list.current === 'string' && list.current !== '' ? list.current : currentSession()
          setSessions((list.sessions ?? []).map(session => currentId === '' ? session : { ...session, active: session.id === currentId }))
          // The host hides sessions it cannot read; a persisted tab pointing at one would
          // paint nothing and still consume a number, so drop it (and its reopen entry).
          const known = new Set((list.sessions ?? []).map(session => session.id))
          setTabsState(current => {
            const next = pruneTabs(current, known, currentSession())
            if (next !== current) persistTabs(next)
            return next
          })
          return
        }
        case 'i18n': {
          const payload2 = payload as { locale?: string; strings?: Record<string, string> }
          if (typeof payload2.locale === 'string') setLocale(payload2.locale)
          if (typeof payload2.strings === 'object' && payload2.strings !== null) setStrings({ ...payload2.strings })
          return
        }
        case 'skills-list': {
          if (!isCurrentSessionPayload(payload)) return
          const payload2 = payload as { skills?: SkillSpec[] }
          setSkills(Array.isArray(payload2.skills) ? payload2.skills : [])
          return
        }
        case 'subagent-list': {
          if (!isCurrentSessionPayload(payload)) return
          const payload2 = payload as { agents?: SubagentDescriptor[] }
          setSubagents(Array.isArray(payload2.agents) ? payload2.agents : [])
          return
        }
        case 'usage': {
          if (!isCurrentSessionPayload(payload)) return
          const payload2 = payload as Partial<UsagePayload>
          if (typeof payload2.sessionId === 'string' && typeof payload2.inputTokens === 'number' && typeof payload2.outputTokens === 'number') {
            setUsage({
              sessionId: payload2.sessionId,
              inputTokens: payload2.inputTokens,
              outputTokens: payload2.outputTokens,
              cacheReadTokens: payload2.cacheReadTokens ?? 0,
              cacheWriteTokens: payload2.cacheWriteTokens ?? 0,
              cacheReadObserved: typeof payload2.cacheReadObserved === 'boolean' ? payload2.cacheReadObserved : undefined,
              cacheReadComplete: typeof payload2.cacheReadComplete === 'boolean' ? payload2.cacheReadComplete : undefined,
              cacheWriteComplete: typeof payload2.cacheWriteComplete === 'boolean' ? payload2.cacheWriteComplete : undefined,
              cacheBucketsComplete: payload2.cacheBucketsComplete === true,
              contextTokens: typeof payload2.contextTokens === 'number' ? payload2.contextTokens : undefined,
              contextWindow: typeof payload2.contextWindow === 'number' ? payload2.contextWindow : undefined,
              contextPct: typeof payload2.contextPct === 'number' ? payload2.contextPct : undefined,
              cost: typeof payload2.cost === 'number' ? payload2.cost : undefined,
              currency: typeof payload2.currency === 'string' ? payload2.currency : undefined,
              costSource: payload2.costSource,
              costUnavailable: payload2.costUnavailable === true,
            })
          }
          return
        }
        case 'git-branch': {
          if (!isCurrentSessionPayload(payload)) return
          const payload2 = payload as { branch?: string }
          setGitBranch(typeof payload2.branch === 'string' ? payload2.branch : undefined)
          return
        }
        case 'mcp-servers': {
          const payload2 = payload as { servers?: McpServerItem[] }
          setMcpServers(Array.isArray(payload2.servers) ? payload2.servers : [])
          return
        }
        case 'host-plugins': {
          const payload2 = payload as { plugins?: HostPluginItem[] }
          setHostPlugins(Array.isArray(payload2.plugins) ? payload2.plugins : [])
          return
        }
        case 'shell-jobs': {
          const owner = typeof payload.sessionId === 'string' ? payload.sessionId : ''
          if (owner === '') return
          const jobs = Array.isArray((payload as { jobs?: ShellJobView[] }).jobs) ? (payload as { jobs?: ShellJobView[] }).jobs! : []
          setShellJobsByOwner(previous => ({ ...previous, [owner]: jobs }))
          if (route() === 'session' && owner === currentSession()) setShellJobs(jobs)
          return
        }
        case 'terminal-frame': {
          const message = payload as Partial<TerminalFramePayload>
          const current = terminalInfo()
          if (message.sessionId !== terminalSessionId() || message.id !== current?.id || message.attachmentId !== terminalAttachmentId() || message.frame === undefined) return
          if (!['snapshot', 'output', 'state'].includes(message.frame.type)) return
          if (message.frame.type === 'snapshot' || message.frame.type === 'state') setTerminalInfo(message.frame.info)
          setTerminalFrames(frames => [...frames, message.frame!])
          return
        }
        case 'terminal-end': {
          const message = payload as Partial<TerminalEndPayload>
          const current = terminalInfo()
          if (message.sessionId !== terminalSessionId() || message.id !== current?.id || message.attachmentId !== terminalAttachmentId()) return
          setTerminalEndError(message.error)
          if (message.error !== undefined) pushNotice('error', message.error)
          return
        }
        case 'todos': {
          if (!isCurrentSessionPayload(payload)) return
          const payload2 = payload as { items?: TodoItem[] }
          setTodos(Array.isArray(payload2.items) ? payload2.items : [])
          return
        }
        case 'interject-list': {
          if (!isCurrentSessionPayload(payload)) return
          const payload2 = payload as { items?: InterjectionItem[] }
          setInterjections(Array.isArray(payload2.items) ? payload2.items : [])
          return
        }
        case 'question-request': {
          const payload2 = payload as { request?: string; sessionId?: string; ownerSessionId?: string; state?: 'open' | 'continued'; callId?: string; remainingMs?: number; questions?: QuestionSpec[] }
          const request = typeof payload2.request === 'string' ? payload2.request : ''
          const sessionId = typeof payload2.sessionId === 'string' ? payload2.sessionId : currentSession()
          const questions = Array.isArray(payload2.questions) ? payload2.questions : []
          if (request === '' || sessionId === '' || questions.length === 0) return
          stopQuestionTimer()
          setQuestionFlow({ request, sessionId, state: payload2.state === 'continued' ? 'continued' : 'open', questions, answers: [], index: 0 })
          if (payload2.state !== 'continued') startQuestionTimer(request, payload2.remainingMs)
          askCurrent()
          return
        }
        case 'question-close': {
          const request = typeof payload.request === 'string' ? payload.request : ''
          if (questionFlow()?.request !== request) return
          stopQuestionTimer()
          setQuestionFlow(undefined)
          closeTopDialog(undefined)
          return
        }
        case 'question-result': {
          const result = payload as { request?: string; ok?: boolean; error?: string }
          if (result.ok !== true && typeof result.error === 'string') pushNotice('error', result.error)
          return
        }
        case 'approval-request': {
          const request = payload as { request?: string; sessionId?: string; ownerSessionId?: string; toolName?: string; callId?: string; reason?: string }
          if (typeof request.request !== 'string' || typeof request.sessionId !== 'string' || request.request === '' || request.sessionId === '' || typeof request.toolName !== 'string') return
          showApproval({ request: request.request, sessionId: request.sessionId, ...(request.ownerSessionId === undefined ? {} : { ownerSessionId: request.ownerSessionId }), toolName: request.toolName, ...(request.callId === undefined ? {} : { callId: request.callId }), ...(request.reason === undefined ? {} : { reason: request.reason }) })
          return
        }
        case 'approval-close': {
          const request = typeof payload.request === 'string' ? payload.request : ''
          if (approvalFlow()?.request !== request) return
          setApprovalFlow(undefined)
          closeTopDialog(undefined)
          return
        }
        case 'turn-state': {
          if (!isCurrentSessionPayload(payload)) return
          const wasRunning = turnRunning()
          if (payload.running === true && !wasRunning) clearTextSelection()
          setTurnRunning(payload.running === true)
          // The notification fires on the transition out of a running turn, not on a
          // replayed snapshot: a snapshot only reports the state it found.
          if (wasRunning && payload.running !== true) void notifyTurnFinished()
          return
        }
        case 'command-catalog': {
          if (!isCurrentSessionPayload(payload)) return
          const catalog = payload as { commands?: Array<{ name: string; description: string; argumentHint?: string }> }
          setCommands(catalog.commands ?? [])
          return
        }
        case 'model-catalog': {
          if (!isCurrentSessionPayload(payload)) return
          const catalog = payload as { models?: Array<{ provider: string; model: string; label: string; current: boolean }> }
          setModels(catalog.models ?? [])
          return
        }
        case 'wechat-output': {
          const message = payload as { kind?: string; text?: string; status?: WechatStatusPayload }
          const text = typeof message.text === 'string' ? message.text : ''
          switch (message.kind) {
            case 'qr':
              // The scan block is borderless monospace text; a new QR replaces the old.
              setWechatQr(text)
              return
            case 'status':
              setWechatStatus(text)
              // The structured state is what the pane paints; the joined line stays for the
              // places that only want one string.
              if (message.status !== undefined) setWechatState(message.status)
              return
            case 'error':
              pushNotice('error', text)
              return
            default:
              // A routed bridge log line carries its own level prefix (`warn:` / `error:`);
              // anything else is an informational line.
              pushNotice(text.startsWith('error') ? 'error' : text.startsWith('warn') ? 'warning' : 'info', text)
          }
          return
        }
        case 'form-spec': {
          const spec = payload as { form?: string; title?: string; fields?: FormFieldSpec[] }
          const form = typeof spec.form === 'string' ? spec.form : ''
          if (form === '' || !Array.isArray(spec.fields)) return
          openDialog({
            kind: 'fields',
            title: typeof spec.title === 'string' ? spec.title : form,
            fields: spec.fields,
            // An action row sends the current values upstream and keeps the form open:
            // `discover` runs the host's probe, `edit-models` asks for the model list the
            // nested editor shows. The host answers both by replacing the models line.
            onAction: (key, values) => {
              if (key === 'edit-models') {
                setModelLine(values.models ?? '')
                send('model-list-request', { form, fields: values })
                return
              }
              send('model-discover', { form, fields: values })
            },
            // The values go back as JSON in the dialog's resolve channel; the host
            // writes them through its own seam, so nothing is validated here.
            onDone: value => {
              if (value === undefined) return
              let values: Record<string, string> = {}
              try {
                const parsed = JSON.parse(value) as Record<string, string>
                values = parsed
              } catch {
                return
              }
              send('form-submit', { form, values })
            },
          })
          return
        }
        case 'model-discovery': {
          const spec = payload as { form?: string; models?: string }
          if (typeof spec.models !== 'string') return
          // The host's probe merged the provider's published ids into the line; the
          // encoding rules stay in the host, so the renderer replaces the value as-is.
          // The write goes through the writer the open form registered, the same path
          // typing uses, so the answer and the typed edits cannot diverge.
          const write = formFieldWriter()
          if (write === undefined) return
          write('models', spec.models)
          return
        }
        case 'model-list': {
          const spec = payload as { form?: string; models?: { id: string; label: string }[] }
          if (!Array.isArray(spec.models)) return
          openDialog({
            kind: 'select',
            title: label('settingsModels', 'models'),
            options: spec.models.map(model => ({ title: `${model.id}${model.label === '' ? '' : ` (${model.label})`}`, value: model.id })),
            onDone: value => {
              if (value === undefined) return
              // The host answers with a form for the picked model; the merge happens
              // against the line this list was requested from.
              send('model-edit', { form: spec.form ?? 'provider', id: value, models: modelLine() })
            },
          })
          return
        }
        case 'command-result': {
          const result = payload as { seq?: number; ok?: boolean; value?: unknown; text?: string; error?: string }
          const resolve = pendingResults.get(result.seq ?? -1)
          if (resolve === undefined) return
          pendingResults.delete(result.seq ?? -1)
          resolve({
            ok: result.ok === true,
            ...(result.value === undefined ? {} : { value: result.value }),
            ...(typeof result.text === 'string' ? { text: result.text } : {}),
            ...(typeof result.error === 'string' ? { error: result.error } : {}),
          })
          return
        }
        case 'session-snapshot': {
          const snapshot = payload as { sessionId?: string; initialRoute?: 'home' | 'session'; parentId?: string; readOnly?: boolean; attachmentCapabilities?: { files?: boolean; images?: boolean }; title?: string; events?: TranscriptEvent[]; workspace?: string; provider?: string; model?: string; effort?: string; permission?: string; preset?: string; availableActions?: string[]; usage?: UsagePayload }
          if (typeof snapshot.sessionId !== 'string') return
          const snapshotUsage = snapshot.usage?.sessionId === snapshot.sessionId ? snapshot.usage : undefined
          if (routeInitialized && route() === 'home' && activeTabId() === DRAFT_TAB_ID && pendingSwitchSessionId !== snapshot.sessionId) return
          const pendingSwitch = pendingSwitchSessionId === snapshot.sessionId
          if (pendingSwitch) pendingSwitchSessionId = undefined
          const changedSession = snapshot.sessionId !== currentSession() || pendingSwitch
          if (changedSession) clearTextSelection()
          const previousSessionId = currentSession()
          if (changedSession) {
            const previousTerminal = terminalInfo()
            if (previousTerminal !== undefined && terminalSessionId() !== '' && terminalAttachmentId() !== '') {
              releaseTerminal(terminalSessionId(), previousTerminal.id, terminalAttachmentId())
            }
            setTerminalOpen(false)
            setTerminalSessionId('')
            setTerminalInfo(undefined)
            setTerminalAttachmentId('')
            setTerminalFrames([])
            setTerminalEndError(undefined)
            setTerminalEnvironment(undefined)
          }
          const previousRoute = route()
          if (!routeInitialized) {
            setRoute(snapshot.initialRoute === 'session' ? 'session' : 'home')
            routeInitialized = true
          } else if (changedSession) {
            setRoute('session')
          }
          if (previousSessionId !== '' && previousRoute === 'session') sessionDrafts.set(previousSessionId, composer())
          setCurrentSession(snapshot.sessionId)
          if (route() === 'session') setActiveTabId(snapshot.sessionId)
          if (route() === 'session') setComposer(sessionDrafts.get(snapshot.sessionId) ?? '')
          else setComposer(homeDraft)
          setCommands([])
          setModels([])
          setMentions([])
          setSkills([])
          setSubagents([])
          setTodos([])
          setInterjections([])
          setShellJobs(shellJobsByOwner()[snapshot.sessionId] ?? [])
          // The snapshot is authoritative for a newly current session and owns the first
          // usage projection. A same-session snapshot without usage must not erase the live
          // status data that is still current (for example a selection refresh).
          if (snapshotUsage !== undefined) setUsage(snapshotUsage)
          else if (changedSession) setUsage(undefined)
          setGitBranch(undefined)
          setTurnRunning(false)
          // `permissionPresets` is process-level, not session-scoped. Clearing it here
          // made `/permission` empty whenever a snapshot arrived after the catalog.
          setAgentPresets([])
          setReadOnly(snapshot.readOnly === true)
          setAttachmentCapabilities({
            files: snapshot.attachmentCapabilities?.files === true,
            images: snapshot.attachmentCapabilities?.images === true,
          })
          // A blank Home session is not a tab: the strip would show an empty "New Session"
          // chip before the user has said anything. It joins the strip on the first message
          // (the snapshot then carries events) or when the user picks it from the catalog.
          // `initialRoute: home` with no transcript is the blank landing shell even if a
          // stale title was persisted. A real conversation always carries events.
          const blankHome = snapshot.initialRoute === 'home' && (snapshot.events ?? []).length === 0
          const snapshotTitle = snapshot.title ?? ''
          if (draftTargetId === snapshot.sessionId) {
            promoteDraftTab(snapshot.sessionId, snapshotTitle)
            draftTargetId = undefined
          } else if (!blankHome) {
            openTab(snapshot.sessionId, snapshotTitle)
          }
          setSessionTitle(snapshot.title ?? '')
          setTranscript(snapshot.events ?? [])
          bumpViewport()
          if (typeof snapshot.workspace === 'string') setWorkspace(snapshot.workspace)
          if (typeof snapshot.provider === 'string') setProvider(snapshot.provider)
          if (typeof snapshot.model === 'string') setModel(snapshot.model)
          if (typeof snapshot.effort === 'string') setEffortCurrent(snapshot.effort)
          if (typeof snapshot.permission === 'string') setPermission(snapshot.permission)
          if (typeof snapshot.preset === 'string') setPreset(snapshot.preset)
          // The host advertises what this exact session can do; a missing list means the
          // page cannot offer those entries, so it stays empty rather than guessing.
          setAvailableActions(Array.isArray(snapshot.availableActions) ? snapshot.availableActions.filter((entry): entry is string => typeof entry === 'string') : [])
          return
        }
        case 'selection-state': {
          if (!isCurrentSessionPayload(payload)) return
          const state = payload as { provider?: string; model?: string; effort?: string; permission?: string; preset?: string; attachmentCapabilities?: { files?: boolean; images?: boolean }; availableActions?: unknown }
          if (typeof state.provider === 'string') setProvider(state.provider)
          if (typeof state.model === 'string') setModel(state.model)
          if (typeof state.effort === 'string') setEffortCurrent(state.effort)
          if (typeof state.permission === 'string') setPermission(state.permission)
          if (typeof state.preset === 'string') setPreset(state.preset)
          if (state.attachmentCapabilities !== undefined) {
            setAttachmentCapabilities({
              files: state.attachmentCapabilities.files === true,
              images: state.attachmentCapabilities.images === true,
            })
          }
          if (Array.isArray(state.availableActions)) {
            setAvailableActions(state.availableActions.filter((entry): entry is string => typeof entry === 'string'))
          }
          return
        }
        case 'provider-catalog': {
          const catalog = payload as { providers?: { id: string; label: string; api: string }[] }
          setProviders(catalog.providers ?? [])
          return
        }
        case 'permission-presets': {
          if (!isCurrentSessionPayload(payload)) return
          const catalog = payload as { presets?: { id: string; label: string; current: boolean }[] }
          setPermissionPresets((catalog.presets ?? []).map(row => ({ id: row.id, label: row.label })))
          return
        }
        case 'agent-presets': {
          if (!isCurrentSessionPayload(payload)) return
          const catalog = payload as { presets?: { id: string; label: string; current: boolean }[] }
          setAgentPresets((catalog.presets ?? []).map(row => ({ id: row.id, label: row.label })))
          return
        }
        case 'session-frame': {
          if (!isCurrentSessionPayload(payload)) return
          const frame = payload as { events?: TranscriptEvent[] }
          mergeTranscript(frame.events ?? [])
          bumpViewport()
          return
        }
        case 'boot-notice': {
          // The host's notice levels are `info` / `warning` / `error`; the payload carries
          // the level in `kind`, and the toast border color follows it.
          const notice = payload as { kind?: string; text?: string }
          if (typeof notice.text === 'string') {
            pushNotice(notice.kind === 'error' ? 'error' : notice.kind === 'warning' ? 'warning' : 'info', notice.text)
          }
          return
        }
        case 'extension-dialog': {
          // A plugin-owned dialog: the renderer draws it with its own dialog stack and
          // sends the answer back on the same request id. Cancel answers `undefined`.
          const spec = payload as { requestId?: number; kind?: string; title?: string; options?: { id: string; label: string; description?: string }[]; confirmLabel?: string; cancelLabel?: string; initial?: string }
          if (typeof spec.requestId !== 'number' || typeof spec.title !== 'string') return
          openDialog({
            kind: spec.kind === 'input' ? 'prompt' : spec.kind === 'confirm' ? 'confirm' : 'select',
            title: spec.title,
            options: spec.options?.map(option => ({ title: option.label, value: option.id })),
            value: spec.initial,
            confirmLabel: spec.confirmLabel,
            onDone: (value) => send('extension-dialog-response', { requestId: spec.requestId, value }),
          })
          return
        }
        case 'log': {
          // The routed host stdout/stderr stream carries a level; a warning and an error get
          // their own toast color instead of all flattening into one warning-colored block.
          const log = payload as { level?: string; text?: string }
          if (typeof log.text === 'string') {
            pushNotice(log.level === 'error' ? 'error' : log.level === 'warning' ? 'warning' : 'info', log.text)
          }
          return
        }
        case 'dialog-response': {
          const response = payload as { seq?: number; value?: unknown }
          if (typeof response.seq !== 'number') return
          const resolve = pendingDialogs.get(response.seq)
          if (resolve === undefined) return
          pendingDialogs.delete(response.seq)
          resolve(response.value)
          return
        }
        default:
          return
      }
    },
  }
}

export type AppStore = ReturnType<typeof createAppStore>

/** One transcript row. The row shapes live in `ui/transcript.tsx`; the assistant body is
 * painted here so the markdown module stays a plain layout component. */
function Row(props: { store: AppStore; row: TranscriptEvent; width: number; thinkingPlan?: ThinkingPlan }) {
  const store = props.store
  const color = (path: string, fallback: string) => store.color(path) ?? fallback
  return (
    <SessionRow
      row={props.row}
      store={store}
      agentLabel={store.presetLabel()}
      width={props.width}
      thinking={(() => {
        const binding = props.thinkingPlan?.byRow.get(props.row.id)
        const block = binding === undefined ? undefined : props.thinkingPlan?.blocks.get(binding.blockId)
        return binding === undefined || block === undefined ? undefined : { block, leader: binding.leader }
      })()}
    >
      {props.row.role === 'assistant' ? (
        <MarkdownText text={props.row.text ?? ''} color={color} streaming={props.row.streaming === true} />
      ) : null}
      {(props.row.attachments ?? []).length > 0 ? (
        <box flexDirection="column" width="100%" flexShrink={0} paddingTop={1}>
          <For each={props.row.attachments ?? []}>
            {attachment => (
              <text
                fg={color('text.muted', '#565f89')}
                content={`▣ ${attachment.name ?? attachment.attachmentId}${attachment.mediaType === undefined ? '' : ` · ${attachment.mediaType}`} (enter opens)`}
                wrapMode="none"
                onMouseUp={() => void store.openAttachment(attachment)}
              />
            )}
          </For>
        </box>
      ) : null}
    </SessionRow>
  )
}

/** The dialog stack: every open spec renders its own backdrop, and the top of the
 * stack owns the modal keys through the controller it registered on mount. */
export function DialogLayer(props: { store: AppStore }) {
  const store = props.store
  return (
    <>
      {/* One dim layer for the whole stack: a nested flow darkens the shell once, not once per
       * entry, and the top panel paints over the entries below it. */}
      {store.dialogStack().length > 0 ? <DialogBackdrop store={store} /> : null}
      <For each={store.dialogStack()}>
        {(spec, index) => (
          <DialogPanel store={store} spec={spec} zIndex={3001 + index()}>
            {spec.kind === 'select' ? <DialogSelect store={store} spec={spec} /> : null}
            {spec.kind === 'prompt' ? <DialogPrompt store={store} spec={spec} /> : null}
            {spec.kind === 'confirm' ? <DialogConfirm store={store} spec={spec} /> : null}
            {spec.kind === 'alert' ? <DialogAlert store={store} spec={spec} /> : null}
            {spec.kind === 'fields' ? <DialogFields store={store} spec={spec} /> : null}
            {spec.kind === 'question' && spec.question !== undefined ? <DialogQuestion store={store} spec={spec} question={spec.question} /> : null}
            {spec.kind === 'shell-output' && spec.job !== undefined && spec.sessionId !== undefined ? <DialogShellOutput store={store} spec={spec} job={spec.job} sessionId={spec.sessionId} read={store.readShellJob} currentJob={() => store.shellJobs().find(job => job.id === spec.job?.id)} /> : null}
            {spec.kind === 'trace' ? <DialogTrace store={store} spec={spec} rows={() => store.traceRows()} /> : null}
          </DialogPanel>
        )}
      </For>
    </>
  )
}

/**
 * The shell layout: the opencode v2 region tree.
 *
 * A column root with no border, split into a header row, the session line, the session rail,
 * the transcript viewport (a scrollbox that sticks to the newest row), the jump-to-latest strip,
 * and the prompt stack. The prompt stack is `flexShrink={0}`, so the prompt and the footer sit
 * at the bottom edge and the transcript absorbs every conditional block: a subagent, a WeChat
 * scan, a notice, or a completion list can no longer move the composer. The completion popup and
 * the toast overlay are absolutely positioned, so they paint without taking rows.
 */
/** The subset of a renderable needed to theme selected text recursively. */
interface SelectableNode {
  selectionBg?: string
  selectionFg?: string
  getChildren?: () => readonly SelectableNode[]
}

/** Markdown builds its own child text renderables, so setting a prop on `<markdown>` is not
 * enough. Walk the mounted tree and assign the theme pair to every selectable descendant. */
function paintSelectionColors(root: SelectableNode, bg: string, fg: string): void {
  const visit = (node: SelectableNode): void => {
    for (const child of node.getChildren?.() ?? []) {
      if ('selectionBg' in child) child.selectionBg = bg
      if ('selectionFg' in child) child.selectionFg = fg
      visit(child)
    }
  }
  visit(root)
}
export function Shell(props: { store: AppStore }) {
  const store = props.store
  usePaste(store.handlePaste)
  const dimensions = useTerminalDimensions()
  const view = useRenderer() as unknown as SelectableNode & {
    readonly hasSelection?: boolean
    clearSelection?: () => void
    readonly isDestroyed: boolean
    readonly root: SelectableNode
    on: (event: string, listener: (...args: any[]) => void) => unknown
    off: (event: string, listener: (...args: any[]) => void) => unknown
    requestRender?: () => void
    triggerNotification: (message: string, title?: string) => boolean
  }
  onMount(() => {
    store.setRenderer(view)
    const settings = store.settings()
    // A click creates a zero-length selection. Upstream leaves it mounted, which paints a
    // stray cell/background after the click. Keep real drags (the user may be copying) but
    // clear the empty ones on the next microtask, after the selection event has settled.
    const onSelection = (selection: { getSelectedText?: () => string }): void => {
      const selected = selection.getSelectedText?.() ?? ''
      if (selected.trim() === '') {
        queueMicrotask(() => {
          if (!view.isDestroyed && view.hasSelection === true) view.clearSelection?.()
        })
        return
      }
      // Markdown recreates its child renderables; apply the pair at selection time too so a
      // rebuilt paragraph cannot fall back to OpenTUI's foreground-as-background default.
      paintSelectionColors(view.root, store.selectionBg(), store.selectionFg())
      view.requestRender?.()
    }
    view.on('selection', onSelection)
    onCleanup(() => view.off('selection', onSelection))
    store.setClipboard(createTuiClipboard(view as never))
    // The renderer's own state root; the host never reads these files. Tests inject a
    // memory-backed storage before mount, so this default never reaches the user's home.
    const ownsStorage = !store.hasLocalStorage()
    if (ownsStorage) store.setLocalStorage(createLocalStorage())
    void store.loadHistory()
    void store.loadDrafts()
    void store.loadTabs()
    store.setAttention(createTuiAttention({
      renderer: view,
      config: {
        notifications: settings.attentionNotifications === true,
        sound: settings.attentionSound === true,
        volume: typeof settings.attentionVolume === 'number' ? settings.attentionVolume : 0.4,
        sounds: {},
      },
    }))
    onCleanup(() => {
      store.setAttention(undefined)
      store.setClipboard(undefined)
      if (ownsStorage) store.setLocalStorage(undefined)
      store.setRenderer(undefined)
    })
  })
  // Re-apply the theme pair after every transcript/theme change. This is deliberately a
  // microtask: Markdown's child renderables are reconciled inside the same update, before
  // the next paint. Only property writes happen here; no layout is measured.
  createEffect(() => {
    const revision = store.transcriptRevision()
    const bg = store.selectionBg()
    const fg = store.selectionFg()
    void revision
    queueMicrotask(() => {
      if (!view.isDestroyed) paintSelectionColors(view.root, bg, fg)
    })
  })
  // ThemeProvider supplies the resolved native theme; until it is mounted the shell uses
  // component fallbacks so the first frame is never colorless.
  const fg = (path: string, fallback: string) => store.color(path) ?? fallback
  const bg = (path: string, fallback: string) => store.color(path) ?? fallback
  // The session chips are a row across the top of the content column, so the column is the
  // full terminal width minus the docked sidebar. There is no rail to subtract.
  // The sidebar docks by the width rule alone: `width - rail > 120`. The overlay is the
  // explicit form (`leader b`); the docked form is the auto one the right-pane arbitration
  // picks when the terminal leaves the content its floor.
  // The pane is visible on `auto` only where it can dock; `open` always shows it (docked
  // when the dock rule passes, as a right-aligned overlay when it does not), `closed`
  // hides it everywhere. The dock rule is a pure function of the terminal width.
  const sidebarFits = () => sidebarDocked(dimensions().width, 0)
  const terminalDockedHere = () => store.terminalOpen() && sidebarFits()
  const sidebarOpenHere = () => !store.terminalOpen() && (store.sidebarState() === 'open' || (store.sidebarState() === 'auto' && sidebarFits()))
  const sidebarDockedHere = () => sidebarOpenHere() && sidebarFits()
  const rightPaneDockedHere = () => terminalDockedHere() || sidebarDockedHere()
  /** Upstream's `getScrollAcceleration`: three rows per tick unless the settings say otherwise. */
  const scrollAcceleration = createMemo(() => getScrollAcceleration(store.settings()))
  // The docked right pane is the sidebar or terminal; the resize handle overlays the seam
  // rather than taking a cell, so the content column is the terminal minus the pane alone.
  const contentWidth = () => dimensions().width - (rightPaneDockedHere() ? store.sidebarWidth() : 0)
  // The horizontal padding the regions share: 2 cells, 1 under the narrow breakpoint.
  const pad = () => shellPadding(contentWidth())
  // The cells a full-width row has left after the shell padding.
  const inner = () => Math.max(1, contentWidth() - pad() * 2)
  // The compact transcript is a pure projection of the row array. Classic mode skips the
  // scan entirely, so the existing path has no extra per-delta cost.
  const thinkingPlan = createMemo<ThinkingPlan | undefined>(() =>
    store.newThinkingStyle()
      ? planThinking(store.transcript(), { turnRunning: store.turnRunning() })
      : undefined,
  )
  // The sidebar's props: the usage, MCP, todo and activity signals the host pushed, plus the
  // token colors the sections need. The cost line reads `—` when the host priced nothing.
  const sidebarProps = () => ({
    usage: store.usage(),
    mcpServers: store.mcpServers(),
    gitBranch: store.gitBranch(),
    workspace: store.workspace(),
    provider: store.provider(),
    model: store.model(),
    height: dimensions().height,
    terminalWidth: dimensions().width,
    // The docked pane takes the clamped width the handle moved; the overlay keeps 40.
    width: sidebarDockedHere() ? store.sidebarWidth() : SIDEBAR_WIDTH,
    fgTitle: fg('hue.accent.200', '#9d7cd8'),
    fgBase: fg('text.base', '#cdd6f4'),
    fgMuted: fg('text.muted', '#565f89'),
    fgContext: fg('text.context.base', '#89d7eb'),
    fgSuccess: fg('text.feedback.success.base', '#a6e22e'),
    fgError: fg('text.feedback.error.base', '#f38ba8'),
    bgBase: bg('background.raised.base', '#181825'),
    labels: {
      context: store.label('rendererContext', 'context'),
      wechat: store.label('rendererWechat', 'wechat'),
      mcp: store.label('rendererMcp', 'MCP'),
      todo: store.label('rendererTodo', 'TODO'),
      subagents: store.label('rendererSubagents', 'subagents'),
      backgroundTasks: store.label('rendererBackgroundTasks', 'background tasks'),
      emptySubagents: store.label('rendererNoSubagents', 'no subagents'),
      emptyBackgroundTasks: store.label('rendererNoBackgroundTasks', 'no running background tasks'),
      untitled: store.label('rendererUntitled', UNTITLED),
      spent: store.label('rendererSpent', 'spent'),
      emptyMcp: store.label('rendererNoMcp', 'no MCP servers'),
      emptyTodos: store.label('rendererNoTodos', 'no todos'),
      more: store.label('rendererMoreItems', '+{count} more'),
      unavailable: store.label('rendererWechatUnavailable', 'unavailable'),
      unknown: store.label('rendererUnknown', 'unknown'),
      lockHeld: store.label('rendererLockHeld', 'lock: this process'),
      lockPid: store.label('rendererLockPid', 'lock: pid {pid}'),
      lockUnknown: store.label('rendererLockUnknown', 'lock: unknown'),
      connected: store.label('rendererWechatConnected', 'connected'),
      disconnected: store.label('rendererWechatDisconnected', 'not connected'),
    },
    wechat: store.wechatState(),
    wechatQr: store.wechatQr(),
    todos: store.todos(),
    subagents: store.subagentsForCurrent(),
    backgroundTasks: store.backgroundTasks(),
    onOpenSubagent: (id: string) => store.selectTab(id),
    onOpenBackground: (owner: string, id: string) => store.openBackgroundTask(owner, id),
    collapsed: store.sidebarCollapsed(),
    onToggleSection: (section: 'mcp' | 'todo' | 'subagents' | 'background') => store.toggleSidebarSection(section),
    version: store.hostVersion(),
    title: store.sessionTitle(),
    scrollAcceleration: scrollAcceleration(),
  })
  const terminalSurface = (width: number) => {
    const info = store.terminalInfo()
    const sessionId = store.terminalSessionId()
    const attachmentId = store.terminalAttachmentId()
    const environment = store.terminalEnvironment()
    if (info === undefined || sessionId === '' || attachmentId === '' || environment === undefined) return null
    return (
      <box width={width} height="100%" minWidth={0} minHeight={0} flexDirection="column" overflow="hidden" backgroundColor={bg('background.raised.base', '#181825')}>
        <box width="100%" height={1} flexShrink={0} paddingLeft={1} paddingRight={1} flexDirection="row" overflow="hidden">
          <text fg={fg('hue.accent.200', '#9d7cd8')} content={`${info.title} · ${info.state}`} wrapMode="none" />
          <box flexGrow={1} />
          <text fg={fg('text.muted', '#565f89')} content="ctrl+p commands" wrapMode="none" />
        </box>
        <For each={[attachmentId]}>
          {currentAttachment => (
            <TerminalPane
              sessionId={sessionId}
              info={info}
              attachmentId={currentAttachment}
              frames={store.terminalFrames}
              consumeFrames={store.consumeTerminalFrames}
              write={data => store.writeTerminal(sessionId, info.id, currentAttachment, data)}
              resize={(cols, rows) => store.resizeTerminal(sessionId, info.id, currentAttachment, cols, rows)}
              follow={() => store.followTerminal(sessionId, info.id, currentAttachment)}
              detach={() => store.detachTerminal(sessionId, info.id, currentAttachment)}
              registerKeyHandler={store.registerTerminalKeyHandler}
              foreground={fg('text.base', '#cdd6f4')}
              background={bg('background.raised.base', '#181825')}
              endError={store.terminalEndError}
              maxInputBytes={environment.maxInputBytes}
              scrollback={environment.scrollback}
            />
          )}
        </For>
      </box>
    )
  }
  // The composer textarea buffer follows the composer signal, so typing, history recalls,
  // and popup acceptance share one value. `initialValue` is not reactive; updates go through
  // the buffer. History keys also inspect its caret row to choose whether to move inside
  // the draft or leave it.
  let composerBuffer: { plainText: string; cursorOffset: number; logicalCursor?: { row: number }; width?: number; setText?: (text: string) => void } | undefined
  /** Both routes mount a textarea; whichever registered last is the live one. */
  const registerComposer = (buffer: typeof composerBuffer): void => {
    composerBuffer = buffer
    store.setComposerBuffer(buffer ?? undefined)
  }
  createEffect(() => {
    // The transcript rows and the viewport height both change the scroll geometry; the
    // clamp runs after the layout pass, when the real content height is known. `revision`
    // (not `transcript()`) is the dependency: a stream delta updates one row's fields in
    // place, which the array proxy alone does not track.
    store.transcriptRevision()
    store.terminalSize()
    queueMicrotask(() => store.settleStickyTop())
  })
  createEffect(() => {
    const text = store.composer()
    const buffer = composerBuffer as { plainText: string; cursorOffset: number; setText?: (text: string) => void } | undefined
    if (buffer !== undefined && buffer.plainText !== text) {
      buffer.setText?.(text)
      // `setText` leaves the caret at the start; the draft continues at the end.
      buffer.cursorOffset = text.length
    }
  })
  // The home route: a session with nothing to read and no turn in flight is a landing
  // page (opencode's Home), not an empty transcript. The first message — a draft typed on
  // home, a `/command`, or a host-pushed event — turns it into the session route.
  const homeRoute = (): boolean => store.route() === 'home'
  createEffect(() => {
    if (homeRoute() && store.terminalOpen()) store.runAction('terminal.toggle')
  })
  const statusDirectory = () => store.displayPath(store.workspace())
  const conversation = createMemo(() => conversationStats(store.transcript()))
  const statusMetrics = () => {
    const stats = conversation()
    const assistant = [...store.transcript()].reverse().find(row => row.role === 'assistant' && row.tokPerSec !== undefined)
    const progress = stats.rounds > 0 || stats.steps > 0
    return statusBarMetrics(store.usage(), {
      ...(progress ? { turn: stats.rounds, step: stats.steps } : {}),
      ...(assistant?.tokPerSec === undefined ? {} : { tokPerSec: assistant.tokPerSec }),
    })
  }
  // The information under the prompt is two rows with two different homes. The cwd/hint row
  // belongs to the prompt stack, so it follows the input box: docked under it in the session
  // route, and floating with it on Home. The metrics row is the shell's last row: it stays on
  // the bottom edge whatever the route does.
  const barPad = (): number => shellPadding(contentWidth())
  const barInner = (): number => Math.max(1, contentWidth() - barPad() * 2)
  const runningHint = () => store.turnRunning() ? store.label('rendererInterrupt', 'esc interrupt') : ''
  const statusFirstLine = (width: number) => {
    const hint = store.label('rendererHomeKeys', 'shift+tab agents · ctrl+p commands')
    return store.turnRunning()
      ? statusBarRunningLine(runningHint(), hint, width)
      : statusBarFirstLine(statusDirectory(), hint, width)
  }
  const statusSecondLine = () => formatStatusBarSecondLine(statusMetrics(), barInner())
  /**
   * The row directly under the input box. Idle: cwd on the left, command hint on the right.
   * Running: spinner + interrupt affordance replaces the cwd on the left; the command hint
   * stays on the right, yielding only when the terminal cannot fit both.
   */
  const statusCwdRow = (width: number = barInner()): JSX.Element => {
    const first = statusFirstLine(width)
    return (
      <box width="100%" height={1} flexShrink={0} flexDirection="row" justifyContent="space-between" gap={1} overflow="hidden">
        {store.turnRunning() ? (
          <box flexDirection="row" gap={1} flexShrink={0} overflow="hidden">
            <Spinner fg={fg('text.feedback.warning.base', '#f9e2af')} animated={store.animations()} />
            <text fg={fg('text.feedback.warning.base', '#f9e2af')} content={first.directory} wrapMode="none" flexShrink={0} />
          </box>
        ) : (
          <text fg={fg('text.muted', '#565f89')} content={first.directory} wrapMode="none" flexShrink={0} />
        )}
        {first.hint !== '' ? (
          // The chords carry the body ink and their labels the muted one, so the row reads as
          // `ctrl+p commands` rather than one flat string.
          <box flexDirection="row" flexShrink={0} overflow="hidden">
            <For each={statusHintSegments(first.hint)}>
              {segment => (
                <text
                  fg={segment.tone === 'key' ? fg('text.base', '#cdd6f4') : fg('text.muted', '#565f89')}
                  content={segment.text}
                  wrapMode="none"
                  flexShrink={0}
                />
              )}
            </For>
          </box>
        ) : null}
      </box>
    )
  }
  /** The metrics row: the one row that is always on the bottom edge of the frame. */
  const statusMetricsRow = (): JSX.Element => (
    <box width={contentWidth()} height={1} flexShrink={0} flexDirection="column" paddingLeft={barPad()} paddingRight={barPad()} overflow="hidden">
      <box width="100%" height={1} flexShrink={0} justifyContent="center" overflow="hidden">
        <text fg={fg('text.muted', '#565f89')} content={statusSecondLine()} wrapMode="none" flexShrink={0} />
      </box>
    </box>
  )
  // The prompt's metadata row: agent · model · effort, dropped from the right as the
  // prompt narrows (the spec's measured-drop rule). Under the 44-cell breakpoint the
  // segment labels go first, so a narrow terminal still names the route.
  /** The rows between the prompt stack's bottom edge and the popup's bottom edge: the prompt
   * chrome, the draft's own lines, the docks, the closing cwd row, and — only while a turn
   * runs — the interrupt row. The metrics row and the bridge rows are outside the stack and
   * do not count. */
  const composerRows = (): number => {
    // Read the composer signal so this layout follows every edit. OpenTUI's textarea
    // reports `height: 1` even while its content soft-wraps, so the visual line count has
    // to be derived from the actual textarea width; otherwise Jump to latest lands inside
    // the text instead of in the blank row above the panel.
    const text = store.composer()
    const maxVisibleRows = Math.max(6, Math.floor(dimensions().height / 3))
    const width = composerBuffer?.width !== undefined && composerBuffer.width > 0
      ? composerBuffer.width
      : Math.max(1, inner() - 5)
    let visualRows = 0
    // One cell is reserved for the text cursor; wrapping one cell early is safer than
    // letting the overlay touch the last visual row of the draft.
    const wrapWidth = Math.max(1, width - 1)
    for (const line of text.split('\n')) visualRows += Math.max(1, Math.ceil(displayWidth(line) / wrapWidth))
    return Math.min(maxVisibleRows, Math.max(1, visualRows))
  }
  const popupAnchorRows = (): number =>
    PROMPT_CHROME_ROWS +
    STATUS_CWD_ROWS +
    composerRows() +
    (store.pendingAttachmentsForCurrent().length > 0 ? 1 : 0) +
    (store.subagents().length > 0 ? store.subagents().length + 3 : 0) +
    (store.interjections().length > 0 ? 3 : 0) +
    (store.turnRunning() ? 1 : 0)
  /** The prompt panel's background: upstream paints it one hue step down from the raised
   * panel (`theme.decrease(theme.background.raised.base)`), so the composer reads as a
   * recess in the page rather than a card floating on it. */
  const promptBackground = (): string =>
    store.decrease('background.raised.base') ?? bg('background.raised.base', '#181825')
  /** The composer's gutter ink: the accent while the input has focus, the plain border while a
   * dialog owns the keyboard. The shadow lip's `╹` continues the same rule. */
  const promptBorder = (): string =>
    store.dialogOpen() ? fg('border.base', '#484848') : fg('hue.accent.200', '#9d7cd8')
  /** The metadata row under the prompt textarea: `mode permission · model · effort`.
   * The provider is deliberately absent here; the sidebar owns it. */
  const metadata = () => ({
    parts: {
      agent: store.modeLabel(),
      permission: store.permissionLabel(),
      model: store.model(),
      effort: store.effortCurrent(),
    },
    colors: {
      // Mode uses the composer's accent, permission the thinking/warning tone, model the
      // body ink, and effort a distinct cyan accent so it never matches the mode.
      agent: fg('hue.accent.200', '#9d7cd8'),
      permission: fg('text.feedback.warning.base', '#f9e2af'),
      model: fg('text.base', '#cdd6f4'),
      effort: fg('text.context.base', '#89dceb'),
      muted: fg('text.muted', '#565f89'),
    },
  })
  /**
   * The open session tabs, in the host catalog's order: a catalog row is not a tab until
   * this renderer opened it. Upstream paints the strip in the app shell, outside the
   * `Home | Session` switch, so a user who typed on Home while their sessions stay open
   * still sees those tabs (and can go back to one) instead of the strip disappearing.
   *
   * `active` is derived from this renderer's own current session, not the catalog's flag:
   * the catalog arrives on a later `session-list` push, so trusting it left the previous
   * chip highlighted for a frame or two after a switch.
   */
  const openTabSessions = () => {
    const current = store.currentSession()
    const activeId = store.activeTabId()
    const byId = new Map(store.sessions().map(session => [session.id, session]))
    // The manual tab order is authoritative. The catalog's lastActivity ordering is for the
    // picker only; filtering `sessions()` here made every moveTab call invisible.
    return store.openTabs().map(id => {
      if (id === DRAFT_TAB_ID) {
        return {
          id,
          title: store.label('rendererUntitled', UNTITLED),
          active: homeRoute() && activeId === id,
          draft: true,
        }
      }
      const session = byId.get(id)
      const title = session?.title.trim() || store.tabTitle(id) || store.label('rendererUntitled', UNTITLED)
      return {
        id,
        title,
        active: !homeRoute() && (activeId === id || (activeId === '' && id === current)),
        status: session?.status ?? 'idle' as const,
      }
    })
  }
  const stripVisible = (): boolean => openTabSessions().length > 0
  const sessionStrip = (): JSX.Element => (
    <SessionStrip
      sessions={openTabSessions()}
      total={contentWidth()}
      onSelect={id => store.selectTab(id)}
      onNew={() => store.runAction('new-session')}
      onClose={id => store.closeTab(id)}
      onMenu={id => store.openTabMenu(id)}
      onMove={(id, index) => store.moveTabTo(id, index)}
      fgActive={fg('text.base', '#cdd6f4')}
      fgBase={fg('text.base', '#cdd6f4')}
      fgMuted={fg('text.muted', '#565f89')}
      fgNumber={fg('text.formfield.base', '#6c7086')}
      // A one-step `decrease(raised.base)` is the page-adjacent surface in the bundled
      // dark themes and all but disappeared against the idle chip. `raised.high` gives the
      // active tab a clearly brighter fill, while the title/number ride bold in the strip.
      bgActive={bg('background.raised.high', '#313244')}
      bgChip={bg('background.base', '#0a0a0a')}
      untitled={store.label('rendererUntitled', UNTITLED)}
      fgRunning={fg('text.feedback.warning.base', '#f9e2af')}
    />
  )
  return (
    <box width="100%" height="100%" flexDirection="column" backgroundColor={bg('background.base', '#0a0a0a')} overflow="hidden">
    <box flexGrow={1} minHeight={0} width="100%" overflow="hidden">
      {homeRoute() ? (
        <box width="100%" height="100%" flexDirection="column" backgroundColor={bg('background.base', '#0a0a0a')} overflow="hidden">
        {/* The strip keeps its row on Home: the route below it is one row shorter, and
         * Home's own height math (logo, centered prompt, popup anchor) is told that. */}
        {stripVisible() ? sessionStrip() : null}
        {/* Home docks the sidebar by the same rule as the session route, so a wide terminal
         * never has one route overlay the pane and the other split it. */}
        <box flexGrow={1} minHeight={0} width="100%" flexDirection="row" position="relative" overflow="hidden">
        <box flexGrow={1} minWidth={0} minHeight={0} flexDirection="column" overflow="hidden">
        <Home
          terminalHeight={dimensions().height - (stripVisible() ? 1 : 0) - STATUS_METRICS_ROWS}
          placeholder={store.label('rendererHomePlaceholder', 'Ask anything… "Fix a TODO in the codebase"')}
          agent={store.modeLabel()}
          permission={store.permissionLabel()}
          model={store.model()}
          effort={store.effortCurrent()}
          composer={store.composer()}
          composerRows={composerRows()}
          attachments={store.pendingAttachmentsForCurrent().map(({ id, label }) => ({ id, label }))}
          onRemoveAttachment={id => store.removePendingAttachments(new Set([id]))}
          terminalWidth={contentWidth()}
          placeholders={{
            bgBase: bg('background.base', '#0a0a0a'),
            // The home prompt is the same recess the session prompt paints: one hue step
            // down from the raised panel.
            bgPanel: store.decrease('background.raised.base') ?? bg('background.raised.base', '#181825'),
            fgBase: fg('text.base', '#cdd6f4'),
            fgMuted: fg('text.muted', '#565f89'),
            fgAccent: fg('hue.accent.200', '#9d7cd8'),
            fgPermission: fg('text.feedback.warning.base', '#f9e2af'),
            fgEffort: fg('text.context.base', '#89dceb'),
            border: store.dialogOpen() ? fg('border.base', '#484848') : fg('hue.accent.200', '#9d7cd8'),
            // Upstream's inner shadow is the ink mixed into the page at 25% (`Ir`), not the
            // raised panel color: the panel is too dark and hollowed the glyphs out.
            logoShade: store.mix(bg('background.base', '#0a0a0a'), fg('text.base', '#cdd6f4'), 0.25),
          }}
          registerComposer={registerComposer}
          onComposerInput={() => store.setComposer(composerBuffer?.plainText ?? '')}
          onSubmit={() => {
            if (store.popupAccepted()) {
              store.resetPopupAccepted()
              return
            }
            store.setComposer(composerBuffer?.plainText ?? '')
            store.submitComposer()
          }}
          focused={!store.dialogOpen()}
          renderPopup={anchor => <AutocompletePopup store={store} anchor={anchor} />}
          statusLine={width => statusCwdRow(width)}
        />
        </box>
        {sidebarDockedHere() ? <Sidebar {...sidebarProps()} /> : null}
        </box>
        {/* The pane is global: it opens on Home too, where the build stamp and the MCP
         * inventory replace the footer rows the landing page used to paint. */}
        {sidebarOpenHere() && !sidebarDockedHere() ? (
          <SidebarOverlay {...sidebarProps()} backdrop={bg('dialog.backdrop', '#000000')} />
        ) : null}
        <ToastOverlay store={store} />
        <DialogLayer store={store} />
        </box>
      ) : (
      <box width="100%" height="100%" flexDirection="column" backgroundColor={bg('background.base', '#0a0a0a')} overflow="hidden">
        {/* The main row: the session chips ride the top of the content column, as upstream
         * paints them (`tabs.layout = horizontal`), so there is no separate rail pane. */}
        <box flexGrow={1} minHeight={0} flexDirection="row" position="relative" overflow="hidden">
        <box flexGrow={1} minWidth={0} flexDirection="column" position="relative" overflow="hidden">
        {/* The tab strip, shared with the Home route so it never disappears while sessions
         * stay open: `leader l` opens the full picker; a chip click sends the host's
         * `session-op` switch. */}
        {stripVisible() ? sessionStrip() : null}
        {/* The transcript viewport: the newest row is always on screen, and the viewport absorbs
         * every row the session appends. Manual scrolling drops sticky, so reading older rows is
         * not interrupted by a new frame. */}
        <scrollbox
          flexGrow={1}
          width="100%"
          stickyScroll
          stickyStart="bottom"
          scrollAcceleration={scrollAcceleration()}
          verticalScrollbarOptions={{
            // Auto visibility: the bar appears only while the viewport overflows, so a short
            // session keeps the full width and a long one shows how far the reader has scrolled.
            trackOptions: { foregroundColor: fg('text.muted', '#565f89'), backgroundColor: bg('background.base', '#0a0a0a') },
          }}
          paddingLeft={pad()}
          paddingRight={0}
          overflow="hidden"
          ref={(renderable: ScrollBoxRenderable | null) => store.setScrollbox(renderable ?? undefined)}
        >
          <For each={store.transcript()}>{row => <Row store={store} row={row} width={inner()} thinkingPlan={thinkingPlan()} />}</For>
        </scrollbox>
        {/* The prompt stack: pinned to the bottom edge. The subagent dock and the WeChat scan block
         * grow downward from here, and the prompt keeps its place at the bottom. */}
        {/* `overflow="visible"` so the completion popup can hang above the prompt: the stack is
         * pinned at the bottom edge, and every row the popup covers is empty transcript space. */}
        <box
          flexDirection="column"
          width="100%"
          flexShrink={0}
          paddingLeft={pad()}
          paddingRight={pad()}
          overflow="visible"
        >
          {store.readOnly() ? (
            <box width='100%' height={3} flexShrink={0} flexDirection='column' justifyContent='center' paddingLeft={pad()} gap={0}>
              <text fg={fg('text.base', '#cdd6f4')} content={store.label('rendererSubagentReadOnly', 'this subagent is read-only and cannot continue the conversation')} />
              <text fg={fg('text.muted', '#565f89')} content={store.label('rendererSubagentTabHint', 'use the session tabs to switch back to the parent or another session')} />
            </box>
          ) : (
            <>
        {/* The dock above the prompt is for live work only: the subagents a turn has spawned and
         * the prompts waiting behind it. Submitted history is not work in flight, so it no
         * longer forces a permanent three-tab card over the transcript — upstream's composer
         * area is the prompt alone when nothing is running. The drawer takes its rows from the
         * column, so the composer row itself never moves when the queue or the subagent list
         * changes. */}
        {store.subagents().length > 0 ? (
          <SubagentDock
            subagents={store.subagents()}
            width={contentWidth()}
            fgTitle={fg('hue.accent.200', '#9d7cd8')}
            fgBase={fg('text.base', '#cdd6f4')}
            fgMuted={fg('text.muted', '#565f89')}
            bgBase={bg('background.raised.base', '#181825')}
            labelTitle={store.label('rendererDrawerSubagents', 'subagents')}
          />
        ) : null}
        {store.interjections().length > 0 ? (
          <QueuedDock
            items={store.interjections()}
            width={contentWidth()}
            fgBase={fg('text.base', '#cdd6f4')}
            fgMuted={fg('text.muted', '#565f89')}
            bgBase={bg('background.raised.base', '#181825')}
            border={fg('border.base', '#484848')}
          />
        ) : null}
          {/* The prompt: a left gutter, the input, and the metadata row inside a raised panel.
           * The bridge's QR and status live in the sidebar, so the bottom bar stays two rows. */}
          <box width="100%" flexShrink={0}>
            {/* One blank row *above* the panel, outside its border: upstream separates the
             * answer (and its footer) from the box the user types in, and the gap must not
             * change the input box's own shape. */}
            <box width="100%" height={1} flexShrink={0} />
            {/* Upstream's composer shape: the gutter is the *outer* box and carries no
             * background, so the accent rule sits on the page; the panel's colour belongs to
             * the inner box. Painting the border box too left the rule on a small band of
             * panel colour, and the lip's `╹` in `border.base` then ended the rule with a grey
             * nub instead of continuing the accent. */}
            <box
              width="100%"
              border={["left"]}
              borderStyle="single"
              borderColor={promptBorder()}
              customBorderChars={PROMPT_CORNER_BORDER}
              flexShrink={0}
              overflow="hidden"
            >
              <box
                width="100%"
                backgroundColor={promptBackground()}
                paddingLeft={pad()}
                paddingRight={pad()}
                paddingTop={1}
                flexShrink={0}
                overflow="hidden"
              >
                {store.pendingAttachmentsForCurrent().length > 0 ? (
                  <box flexDirection="row" gap={1} width="100%" flexShrink={0} overflow="hidden">
                    <For each={store.pendingAttachmentsForCurrent()}>
                      {attachment => <text fg={fg('text.muted', '#565f89')} content={`${attachment.label} ×`} onMouseUp={() => store.removePendingAttachments(new Set([attachment.id]))} />}
                    </For>
                  </box>
                ) : null}
                <textarea
                  ref={(r: { plainText: string; cursorOffset: number } | null) => registerComposer(r ?? undefined)}
                  width="100%"
                  minHeight={1}
                  maxHeight={Math.max(6, Math.floor(dimensions().height / 3))}
                  initialValue={store.composer()}
                  placeholder={store.label('rendererPlaceholder', 'prompt, /command, Ctrl+P palette')}
                  textColor={fg('text.formfield.base', '#cdd6f4')}
                  focusedTextColor={fg('text.action.primary.$focused', '#cdd6f4')}
                  focusedBackgroundColor={promptBackground()}
                  focused={!store.dialogOpen()}
                  // OpenTUI's textarea binds plain Enter to a newline and submit to
                  // meta+Enter; the composer's contract is the opposite — plain Enter
                  // sends, the modifier keys insert the newline.
                  keyBindings={[
                    { name: 'return', action: 'submit' },
                    { name: 'return', ctrl: true, action: 'newline' },
                    { name: 'return', meta: true, action: 'newline' },
                    { name: 'j', ctrl: true, action: 'newline' },
                  ]}
                  onContentChange={() => store.setComposer(composerBuffer?.plainText ?? '')}
                  onSubmit={() => {
                    // The popup owns `return` while it has rows: the keymap dispatches the accept
                    // before this handler runs, and the flag marks that `return` was consumed.
                    if (store.popupAccepted()) {
                      store.resetPopupAccepted()
                      return
                    }
                    store.setComposer(composerBuffer?.plainText ?? '')
                    store.submitComposer()
                  }}
                />
                <box width="100%" flexShrink={0} paddingTop={1}>
                  <PromptMetadata parts={metadata().parts} colors={metadata().colors} width={inner()} />
                </box>
              </box>
            </box>
            {/* The shadow lip: the outer box ends the `╹` gutter and the inner box draws the
             * `▀` bottom edge. Both use `EMPTY_BORDER`, whose `single` corners would cut the
             * vertical rule into pieces. The `╹` takes the gutter's own colour and the `▀`
             * the panel's, so the rule and the shadow each continue unbroken. */}
            <box height={1} flexShrink={0} border={["left"]} borderStyle="single" borderColor={promptBorder()} customBorderChars={SHADOW_LIP_EDGE} overflow="hidden">
              <box height={1} border={["bottom"]} borderStyle="single" borderColor={promptBackground()} customBorderChars={SHADOW_LIP_BORDER} />
            </box>
          </box>
          {/* The prompt footer: the running state on the left, the route and the contract status on
           * the right. There is no separate global status bar; the footer is the status row. */}
          {/* Last child: the popup is absolutely positioned from the stack's bottom edge, so it
           * hangs over the dock and the prompt without taking a row from the column. */}
          <AutocompletePopup
            store={store}
            anchor={{ bottom: popupAnchorRows(), left: pad(), width: inner() }}
          />
            </>
          )}
          {/* The cwd/hint row closes the prompt stack, so it is the row directly under the
           * input box — the same place it takes on Home, where the prompt floats. */}
          {statusCwdRow()}
        </box>
        {/* The overlay owns the blank row directly above the prompt panel: right-aligned to
         * the content column, below the completion popup, and never part of the flex flow. */}
        <JumpToLatest
          visible={store.awayFromBottom() && !store.popupOpen() && !store.dialogOpen()}
          right={pad()}
          bottom={popupAnchorRows()}
          label={store.label('rendererJumpLatest', 'Jump to latest ↓')}
          fg={fg('text.action.secondary.base', '#89d7eb')}
          bg={bg('background.base', '#0a0a0a')}
          bgHover={bg('background.raised.high', '#313244')}
          onJump={store.jumpToLatest}
        />
        </box>
        {/* The right pane shares the session row; the live terminal takes priority over sidebar content. */}
        {/* The boundary handle overlays the seam, so the content column keeps its cells. */}
        {rightPaneDockedHere() ? (
          <PaneResizeHandle
            width={store.sidebarWidth()}
            total={dimensions().width}
            left={Math.max(0, dimensions().width - store.sidebarWidth())}
            highlight="right"
            onResize={w => store.resizeSidebar(w)}
            fgHighlight={bg('background.raised.high', '#313244')}
          />
        ) : null}
        {terminalDockedHere() ? terminalSurface(store.sidebarWidth()) : sidebarDockedHere() ? <Sidebar {...sidebarProps()} /> : null}
        {store.terminalOpen() && !terminalDockedHere() ? (
          <box position="absolute" right={0} top={0} width={SIDEBAR_WIDTH} height="100%" overflow="hidden">
            {terminalSurface(SIDEBAR_WIDTH)}
          </box>
        ) : null}
        </box>
        {/* The sidebar paints as a right-aligned overlay when the terminal cannot dock it. */}
        {sidebarOpenHere() && !sidebarDockedHere() ? (
          <SidebarOverlay {...sidebarProps()} backdrop={bg('dialog.backdrop', '#000000')} />
        ) : null}
        {/* The toast overlay sits top-right; the dialog layer covers the screen. Both are absolutely
         * positioned, so neither takes rows from the column. */}
        <ToastOverlay store={store} />
        <DialogLayer store={store} />
        {store.attachmentPreview() === undefined ? null : (
          <box position="absolute" left={0} top={0} width="100%" height="100%" zIndex={3100} flexDirection="column" backgroundColor={bg('background.base', '#0a0a0a')} padding={1}>
            <box flexDirection="row" width="100%" height={1} flexShrink={0} gap={2} overflow="hidden">
              <text fg={fg('hue.accent.200', '#9d7cd8')} content={store.attachmentPreview()!.name} wrapMode="none" />
              <text fg={fg('text.muted', '#565f89')} content={`${store.attachmentPreview()!.mediaType} · esc closes`} wrapMode="none" />
            </box>
            <box flexGrow={1} minHeight={0} width="100%" overflow="hidden">
              <image source={store.attachmentPreview()!.bytes} fit="fit" />
            </box>
          </box>
        )}
      </box>
      )}
    </box>
    {/* The metrics row is the last child of the root, outside both routes and every overlay:
     * Home, Session, a docked sidebar and a terminal pane all share it, and it can never be
     * pushed off the frame. The cwd row above it belongs to the prompt, not to the shell. */}
    {statusMetricsRow()}
    </box>
  )
}
