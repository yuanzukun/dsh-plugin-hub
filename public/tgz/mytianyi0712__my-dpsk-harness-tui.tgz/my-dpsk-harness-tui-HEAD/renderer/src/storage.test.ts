import { describe, expect, test } from 'bun:test'
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createLocalStorage, isLockContention, storageRoot, withFileLock } from './storage.ts'

function tempRoot(): string {
  return mkdtempSync(join(tmpdir(), 'dpsk-storage-'))
}

describe('local storage', () => {
  test('root follows DSH_HOME and the channel directory', () => {
    expect(storageRoot({ DSH_HOME: 'D:/home' })).toBe(join('D:/home', 'state'))
    expect(storageRoot({ HOME: 'D:/users/me' })).toBe(join('D:/users/me', '.dsh', 'state'))
  })

  test('update creates, mutates, and persists one JSON object', async () => {
    const root = tempRoot()
    const storage = createLocalStorage(root)
    await storage.update('tabs', { open: [] as string[], closed: [] as string[] }, draft => { draft.open.push('ses_1') })
    await storage.update('tabs', { open: [] as string[], closed: [] as string[] }, draft => { draft.closed.push('ses_0') })
    expect(await storage.read<{ open: string[]; closed: string[] }>('tabs')).toEqual({ open: ['ses_1'], closed: ['ses_0'] })
    // The file is real JSON at the documented path.
    expect(JSON.parse(readFileSync(join(storage.directory, 'tabs.json'), 'utf8'))).toEqual({ open: ['ses_1'], closed: ['ses_0'] })
    await storage.flush()
    rmSync(root, { recursive: true, force: true })
  })

  test('a malformed stored file yields the caller initial instead of throwing', async () => {
    const root = tempRoot()
    const storage = createLocalStorage(root)
    await storage.update('layout', { sidebar: 0 }, () => undefined)
    rmSync(join(storage.directory, 'layout.json'), { force: true })
    expect(await storage.read('layout')).toBeUndefined()
    await storage.update('layout', { sidebar: 42 }, () => undefined)
    expect(await storage.read('layout')).toEqual({ sidebar: 42 })
    rmSync(root, { recursive: true, force: true })
  })

  test('prompt history appends one JSON line per entry and skips a torn last line', async () => {
    const root = tempRoot()
    const storage = createLocalStorage(root)
    await storage.appendHistory({ text: 'first', at: 1 })
    await storage.appendHistory({ text: 'second', at: 2 })
    await storage.flush()
    expect(await storage.readHistory<{ text: string; at: number }>()).toEqual([{ text: 'first', at: 1 }, { text: 'second', at: 2 }])
    rmSync(root, { recursive: true, force: true })
  })

  test('the lock serializes two writers and releases the directory', async () => {
    const root = tempRoot()
    const file = join(root, 'serial.json')
    const order: string[] = []
    let release: () => void = () => undefined
    const held = new Promise<void>(resolve => { release = resolve })
    let acquired: () => void = () => undefined
    const tookLock = new Promise<void>(resolve => { acquired = resolve })
    const first = withFileLock(file, async () => { order.push('first:start'); acquired(); await held; order.push('first:end') })
    // Wait until the first writer really holds the lease; otherwise the second may win it
    // and the assertion would be about scheduling, not about serialization.
    await tookLock
    const second = withFileLock(file, async () => { order.push('second') })
    await new Promise(resolve => setTimeout(resolve, 50))
    release()
    await Promise.all([first, second])
    expect(order).toEqual(['first:start', 'first:end', 'second'])
    rmSync(root, { recursive: true, force: true })
  })

  test('windows delete-pending codes are treated as lock contention, not failures', () => {
    // `mkdir` on a directory that is being deleted reports EPERM/EACCES on Windows; the
    // release path is `rm(lockDir)`, so two quick saves hit exactly that window.
    for (const code of ['EEXIST', 'EPERM', 'EACCES', 'EBUSY']) expect(isLockContention(code)).toBe(true)
    for (const code of ['ENOENT', 'ENOTDIR', 'EIO', undefined]) expect(isLockContention(code)).toBe(false)
  })

  test('overlapping fire-and-forget updates all settle without rejecting', async () => {
    // The shell persists the tab set from callbacks that do not await (openTab / closeTab),
    // so two saves can overlap. Before the contention fix this produced EPERM on Windows.
    const root = tempRoot()
    const storage = createLocalStorage(root)
    const results: Array<Promise<unknown>> = []
    for (let i = 0; i < 12; i++) {
      results.push(storage.update('tabs', { open: [] as string[] }, draft => { draft.open = [`a${i}`] }))
      results.push(storage.update('tabs', { open: [] as string[] }, draft => { draft.open = [`b${i}`] }))
    }
    const settled = await Promise.allSettled(results)
    expect(settled.filter(result => result.status === 'rejected')).toEqual([])
    await storage.flush()
    const stored = await storage.read<{ open: string[] }>('tabs')
    expect(stored?.open.length).toBe(1)
    rmSync(root, { recursive: true, force: true })
  }, 20_000)
})
