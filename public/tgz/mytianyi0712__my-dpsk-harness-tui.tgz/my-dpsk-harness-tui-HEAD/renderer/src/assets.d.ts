/**
 * Bundled asset declarations.
 *
 * Bun's `with { type: 'file' }` import yields a path to the bytes: inside a `bun build
 * --compile` binary the bytes are embedded and the path resolves to the virtual root, so
 * the attention sounds travel with the renderer instead of being looked up next to it.
 */
declare module '*.mp3' {
  const path: string
  export default path
}
