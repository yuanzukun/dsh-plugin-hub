/**
 * The clipboard.
 *
 * Ported from opencode v2 (`anomalyco/opencode`, 2.0.32, `packages/tui/src/clipboard.ts` +
 * `context/clipboard.tsx`), MIT. Registered in NOTICE.md under the `opencode` entry;
 * verified by scripts/verify-license.ts.
 * SPDX-License-Identifier: MIT
 *
 * Modifications:
 * - Upstream's Solid context provider is not ported: the shell owns one clipboard instance
 *   and passes it to the components that copy, so a context would be a second way to reach
 *   the same object.
 *
 * Behaviour that is upstream's, not this package's:
 * - Reads prefer `image/png` over `text/plain`; an empty text read is `undefined`, not an
 *   empty string.
 * - Writes strip NUL (OpenTUI rejects it) and go to both the host and the terminal clipboard;
 *   a write is successful when either destination took it, and a failed host with no terminal
 *   attempt is a real error.
 * - Every OpenTUI failure mode (timeout, limit, read failure) surfaces as a real error
 *   instead of a silent no-op.
 */

import {
  createClipboard,
  createHostClipboard,
  createRendererClipboardAdapter,
  decodePasteBytes,
  type RendererClipboardBoundary,
} from '@opentui/core'

/** One clipboard payload: text, or a base64 PNG. */
export type ClipboardContent = Readonly<{ data: string; mime: string }>

/** The clipboard the shell copies and pastes with. */
export interface ClipboardService {
  read: () => Promise<ClipboardContent | undefined>
  write: (text: string) => Promise<void>
  dispose: () => Promise<void>
}

/** The TUI clipboard: the host clipboard first, then the terminal's own OSC 52 route. */
export function createTuiClipboard(renderer: RendererClipboardBoundary): ClipboardService {
  const clipboard = createClipboard({
    host: createHostClipboard(),
    terminal: createRendererClipboardAdapter(renderer),
  })
  return {
    async read() {
      const result = await clipboard.read({ preferredTypes: ['image/png', 'text/plain'], selection: 'clipboard' })
      if (result.status !== 'read') {
        if (result.status === 'failed') throw result.error
        if (result.status === 'timed-out') throw new Error('Clipboard read timed out')
        if (result.status === 'limit-exceeded') throw new RangeError('Clipboard content exceeded configured read or image conversion limits')
        return undefined
      }
      if (result.representation.mimeType === 'image/png') {
        return { data: Buffer.from(result.representation.bytes).toString('base64'), mime: 'image/png' }
      }
      if (result.representation.mimeType === 'text/plain') {
        if (result.representation.bytes.length === 0) return undefined
        return { data: decodePasteBytes(result.representation.bytes), mime: 'text/plain' }
      }
      throw new Error(`Unexpected clipboard MIME type: ${result.representation.mimeType}`)
    },
    async write(text) {
      const result = await clipboard.writeText(text.replaceAll('\0', ''), { destination: 'all-available', selection: 'clipboard' })
      if (result.host.status === 'written' || result.terminal.status === 'attempted') return
      if (result.host.status === 'failed') throw result.host.error
      throw new Error(`Clipboard write failed (host: ${result.host.status}, terminal: ${result.terminal.status})`)
    },
    dispose: () => clipboard.dispose(),
  }
}
