/**
 * Renderer shell tests.
 *
 * `testRender` from `@opentui/solid` builds a full renderer against a mock
 * terminal, and `captureCharFrame()` returns the painted screen as plain text.
 * That makes the renderer testable without a TTY: the assertions below check the
 * shell's header, session line, transcript rows, composer, notices, and status
 * line after the store is fed real downstream envelopes.
 */

import { expect, test } from 'bun:test'
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { homedir, tmpdir } from 'node:os'
import { join } from 'node:path'
import { testRender } from '@opentui/solid'
import { Shell, createAppStore } from './app.tsx'
import { createKeymap } from './keymap/keymap.ts'
import { createTuiAttention } from './attention.ts'
import { mountShell } from './test-harness.tsx'
import { SessionStrip } from './ui/session-tabs.tsx'
import { DRAFT_TAB_ID } from './ui/session-tabs-model.ts'
import { PALETTE_ACTIONS, paletteOptions } from './component/command-palette.tsx'
import { commandSuggestions } from './ui/completions.ts'
import { RENDERER_PROTOCOL_VERSION, type IpcEnvelope } from './protocol/kinds.ts'

/** The session route: one message is enough for the shell to leave the Home landing page. */
function sessionRoute(store: ReturnType<typeof createAppStore>, seq = 1): void {
  store.apply({
    protocolVersion: 2,
    seq,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'session', title: 'first prompt',
      events: [{ id: 'route-e1', role: 'user', text: 'hello' }],
      provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard',
      workspace: 'D:/Projects/dsh', attachmentCapabilities: { files: false, images: false },
    },
  })
}

/**
 * The painted grid without the trailing newline `captureCharFrame()` appends, so `at(-1)` is
 * the last painted row (the status bar's metrics line) rather than an empty string.
 */
function painted(frame: string): string[] {
  const rows = frame.split('\n')
  while (rows.length > 0 && rows[rows.length - 1] === '') rows.pop()
  return rows
}

/** One span's ink as `#rrggbb`, or `undefined` when it inherits. */
function inkOf(span: { readonly fg?: { readonly buffer?: Uint16Array } } | undefined): string | undefined {
  const channels = span?.fg?.buffer
  if (channels === undefined) return undefined
  return `#${[0, 1, 2].map(index => (channels[index] ?? 0).toString(16).padStart(2, '0')).join('')}`
}

/** One span's background as `#rrggbb`, or `undefined` when it inherits. */
function backgroundOf(span: { readonly bg?: { readonly buffer?: Uint16Array } } | undefined): string | undefined {
  const channels = span?.bg?.buffer
  if (channels === undefined) return undefined
  return `#${[0, 1, 2].map(index => (channels[index] ?? 0).toString(16).padStart(2, '0')).join('')}`
}

/** The painted span containing a tab title on the first (strip) row. */
function tabSpan(
  frame: { readonly lines: readonly { readonly spans: readonly { readonly text: string; readonly attributes?: number; readonly bg?: { readonly buffer?: Uint16Array } }[] }[] },
  title: string,
) {
  return frame.lines[0]?.spans.find(span => span.text.includes(title))
}

/** The ink of the first painted span on the one row that contains `needle`. */
function rowInk(
  frame: { readonly lines: readonly { readonly spans: readonly { readonly text: string; readonly fg?: { readonly buffer?: Uint16Array } }[] }[] },
  needle: string,
): string | undefined {
  const row = frame.lines.find(line => line.spans.map(span => span.text).join('').includes(needle))
  const span = row?.spans.find(entry => entry.text.trim() !== '' && entry.text.includes(needle))
  return inkOf(span)
}

const ackEnvelope: IpcEnvelope = {
  protocolVersion: RENDERER_PROTOCOL_VERSION,
  seq: 0,
  kind: 'hello-ack',
  payload: {
    protocolVersion: RENDERER_PROTOCOL_VERSION,
    hostId: 'my-dpsk-harness-tui',
    hostVersion: '0.5.0',
    capabilities: ['session-events', 'model-catalog'],
    status: 'compatible',
    reasons: [],
  },
}

const snapshotEnvelope: IpcEnvelope = {
  protocolVersion: RENDERER_PROTOCOL_VERSION,
  seq: 1,
  kind: 'session-snapshot',
  payload: {
    sessionId: 'ses_1',
    initialRoute: 'session',
    title: 'first prompt',
    events: [
      { id: 'e1', role: 'user', text: 'hello' },
      { id: 'e2', role: 'assistant', text: 'hi there' },
    ],
    provider: 'cliproxy',
    model: 'mimo-v2.6-pro',
    effort: 'high',
    permission: 'auto',
    preset: 'standard',
    availableActions: [],
    attachmentCapabilities: { files: false, images: false },
  },
}

test('store applies the handshake and the session snapshot', () => {
  const store = createAppStore()
  store.apply(ackEnvelope)
  store.apply(snapshotEnvelope)
  expect(store.status()).toBe('compatible')
  expect(store.hostLabel()).toBe('host: my-dpsk-harness-tui 0.5.0')
  expect(store.sessionTitle()).toBe('first prompt')
  expect(store.transcript()).toEqual([
    { id: 'e1', role: 'user', text: 'hello' },
    { id: 'e2', role: 'assistant', text: 'hi there' },
  ])
})

test('session-list derives the active row from its explicit current id', () => {
  const store = createAppStore()
  sessionRoute(store, 1)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-list',
    payload: {
      sessions: [
        { id: 'ses_1', title: 'cached current', active: false, createdAt: 1, status: 'idle', attention: false },
        { id: 'ses_2', title: 'stale active', active: true, createdAt: 2, status: 'running', attention: true },
      ],
      current: 'ses_1',
    },
  })
  expect(store.sessions().map(session => [session.id, session.active])).toEqual([
    ['ses_1', true],
    ['ses_2', false],
  ])
})

test('a second session-snapshot replaces the transcript and the route', () => {
  const store = createAppStore()
  store.apply(ackEnvelope)
  store.apply(snapshotEnvelope)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_2',
      initialRoute: 'session',
      title: 'resumed session',
      events: [{ id: 'e9', role: 'user', text: 'second session' }],
      provider: 'ollama',
      model: 'qwen',
      effort: 'low',
      permission: 'ask',
      preset: 'plan',
      workspace: 'D:/Other/project',
    },
  })
  // The switch re-send replaces the whole route: the transcript is the new session's log,
  // the title and the provider/model/effort/permission/preset follow the new session, and
  // the old session's rows are gone.
  expect(store.sessionTitle()).toBe('resumed session')
  expect(store.transcript()).toEqual([{ id: 'e9', role: 'user', text: 'second session' }])
  expect([store.provider(), store.model(), store.effortCurrent(), store.permission(), store.preset()]).toEqual(
    ['ollama', 'qwen', 'low', 'ask', 'plan'],
  )
  expect(store.workspace()).toBe('D:/Other/project')
})

test('selection-state updates the route without rebuilding transcript or catalogs', () => {
  const store = createAppStore()
  store.apply(ackEnvelope)
  store.apply(snapshotEnvelope)
  const transcript = store.transcript()
  const title = store.sessionTitle()
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'selection-state',
    payload: {
      sessionId: 'ses_1',
      provider: 'cliproxy',
      model: 'deepseek-v4.1-flash',
      effort: 'default',
      attachmentCapabilities: { files: true, images: true },
      availableActions: ['terminal.toggle', 'terminal.select', 'terminal.close'],
    },
  })
  expect([store.provider(), store.model(), store.effortCurrent()]).toEqual(['cliproxy', 'deepseek-v4.1-flash', 'default'])
  // The route-only message must not trigger a full snapshot reset.
  expect(store.transcript()).toEqual(transcript)
  expect(store.sessionTitle()).toBe(title)
  expect(store.preset()).toBe('standard')
  expect(store.attachmentCapabilities()).toEqual({ files: true, images: true })
  expect(store.availableActions()).toEqual(['terminal.toggle', 'terminal.select', 'terminal.close'])
})

test('session-frame replaces a row with the same id and appends a new one', () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply(snapshotEnvelope)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-frame',
    payload: {
      sessionId: 'ses_1',
      events: [
        { id: 'e2', role: 'assistant', text: 'hi there, growing', streaming: true },
        { id: 't3', role: 'tool', tool: 'bash', toolOutput: ['out'] },
      ],
    },
  })
  expect(store.transcript().length).toBe(3)
  expect(store.transcript()[1]?.text).toBe('hi there, growing')
  expect(store.transcript()[2]?.tool).toBe('bash')
  expect(store.transcript()[2]?.toolOutput).toEqual(['out'])
})

test('the toast queue shows one notice, replaces it when idle, and queues while paused', () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  for (let index = 0; index < 3; index++) {
    store.apply({ protocolVersion: 2, seq: index, kind: 'boot-notice', payload: { kind: 'info', text: `notice ${index}` } })
  }
  // Upstream replaces the visible toast when nothing is waiting and the timer is running.
  expect(store.toast()?.text).toBe('notice 2')
  expect(store.pendingToasts()).toBe(0)
  // Hovering banks the timer; a notice arriving while paused waits behind the visible one.
  store.pauseToast()
  store.apply({ protocolVersion: 2, seq: 10, kind: 'boot-notice', payload: { kind: 'warning', text: 'degraded' } })
  expect(store.toast()?.text).toBe('notice 2')
  expect(store.pendingToasts()).toBe(1)
  store.resumeToast()
  // A click dismisses the visible toast and promotes the next one in order.
  store.dismissToast()
  expect(store.toast()?.text).toBe('degraded')
  expect(store.toast()?.level).toBe('warning')
  store.dismissToast()
  expect(store.toast()).toBeUndefined()
})

test('a streaming row keeps its id and grows in place', () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply(snapshotEnvelope)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-frame',
    payload: { sessionId: 'ses_1', events: [{ id: 'e2', role: 'assistant', text: 'hi there, how', streaming: true }] },
  })
  const last = store.transcript().at(-1)
  expect(last?.id).toBe('e2')
  expect(last?.streaming).toBe(true)
  expect(last?.text).toBe('hi there, how')
})

test('submitComposer sends the draft upstream once and clears it', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => sent.push({ kind, payload }))
  sessionRoute(store, 20)
  store.setComposer('/theme dark-catppuccin')
  store.submitComposer()
  store.submitComposer()
  expect(sent).toEqual([{ kind: 'send-message', payload: { sessionId: 'ses_1', text: '/theme dark-catppuccin', delivery: 'steer' } }])
  expect(store.composer()).toBe('')
})

test('runAction maps every keymap action to an upstream request', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => sent.push({ kind, payload }))
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'reasoning-efforts', payload: { sessionId: 'ses_1', efforts: ['off', 'low', 'medium', 'high', 'max'], current: 'high' } })
  store.runAction('cycle-effort')
  store.runAction('new-session')
  store.runAction('compact')
  store.runAction('export')
  store.runAction('exit')
  // The renderer owns the TTY: `/exit` also runs its own shutdown, which writes the restore.
  // The route updates optimistically; the host's catalog still has the final say.
  expect(sent).toEqual([
    { kind: 'set-selection', payload: { sessionId: 'ses_1', effort: 'max' } },
    { kind: 'send-message', payload: { sessionId: 'ses_1', text: '/compact', delivery: 'steer' } },
    { kind: 'bye', payload: { reason: 'renderer exit' } },
  ])
  // New goes to the Home route and clears the draft; it does not create a Session.
  expect(store.route()).toBe('home')
  // Export is a picker: the host export request is sent when a format is picked.
  expect(store.dialogStack().at(-1)?.title).toBe('export session')
  expect(store.effortCurrent()).toBe('max')
  // While the New draft is on screen, the previous session's catalogs must not repaint it.
  store.apply({ protocolVersion: 2, seq: 2, kind: 'reasoning-efforts', payload: { sessionId: 'ses_1', efforts: ['off', 'low', 'medium', 'high', 'max'], current: 'high' } })
  expect(store.effortCurrent()).toBe('max')
})

test('cycle-effort wraps to the first effort and does nothing with no list', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => sent.push({ kind, payload }))
  sessionRoute(store, 20)
  store.runAction('cycle-effort')
  expect(sent).toEqual([])
  store.apply({ protocolVersion: 2, seq: 1, kind: 'reasoning-efforts', payload: { sessionId: 'ses_1', efforts: ['off', 'low', 'medium'], current: 'medium' } })
  store.runAction('cycle-effort')
  expect(sent).toEqual([{ kind: 'set-selection', payload: { sessionId: 'ses_1', effort: 'off' } }])
  store.apply({ protocolVersion: 2, seq: 2, kind: 'reasoning-efforts', payload: { sessionId: 'ses_1', efforts: ['off', 'low', 'medium'], current: 'off' } })
  expect(store.effortCurrent()).toBe('off')
})

test('an effort palette pick sends set-selection upstream', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => sent.push({ kind, payload }))
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'reasoning-efforts', payload: { sessionId: 'ses_1', efforts: ['high', 'max'], current: 'high' } })
  store.pickEffort('max')
  expect(sent).toEqual([{ kind: 'set-selection', payload: { sessionId: 'ses_1', effort: 'max' } }])
  store.apply({ protocolVersion: 2, seq: 2, kind: 'reasoning-efforts', payload: { sessionId: 'ses_1', efforts: ['high', 'max'], current: 'max' } })
  expect(store.effortCurrent()).toBe('max')
})

test('pick-model opens the model picker, while the palette stays a command list', () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'model-catalog',
    payload: { sessionId: 'ses_1', models: [{ provider: 'cliproxy', model: 'mimo-v2.6-pro', label: 'MiMo V2.6 Pro', current: true }] },
  })
  store.runAction('pick-model')
  expect(store.dialogOpen()).toBe(true)
  const top = store.dialogStack().at(-1)
  // The dedicated picker: a titled model list grouped by provider, with no category
  // filter — `/model` and `ctrl+x m` land here, and cycling stays on F2.
  expect(top?.title).toBe('Switch model')
  expect(top?.categoryFilter).toBeUndefined()
  expect(top?.options?.map(option => option.category)).toEqual(['cliproxy'])
  store.runAction('palette')
  expect(store.dialogStack().length).toBe(2)
  const palette = store.dialogStack().at(-1)
  expect(palette?.categoryFilter).toBeUndefined()
  // The command list carries the switch-model action but not the catalog itself.
  expect(palette?.options?.some(option => option.value === 'action:slash:/models')).toBe(true)
  expect(palette?.options?.some(option => option.category === 'models')).toBe(false)
})

test('a model pick on the Home route reaches the host instead of staying local', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => sent.push({ kind, payload }))
  // The startup session: blank, on Home, on the configured default model.
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'home',
      title: '',
      events: [],
      provider: 'cliproxy',
      model: 'mimo-v2.6-pro',
      effort: 'high',
      permission: 'auto',
      preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'model-catalog',
    payload: {
      sessionId: 'ses_1',
      models: [
        { provider: 'cliproxy', model: 'deepseek-v4.1-flash', label: 'DeepSeek V4.1 Flash', current: false },
        { provider: 'cliproxy', model: 'mimo-v2.6-pro', label: 'MiMo V2.6 Pro', current: true },
      ],
    },
  })
  expect(store.route()).toBe('home')
  store.runAction('pick-model')
  store.closeTopDialog('model:cliproxy/deepseek-v4.1-flash')
  // Home is the blank session the first message reuses. Keeping the pick local left the
  // host on its own route, so the request — and the assistant footer that names the model
  // that answered — still carried the previous one.
  expect(sent.filter(entry => entry.kind === 'set-selection')).toEqual([
    { kind: 'set-selection', payload: { sessionId: 'ses_1', provider: 'cliproxy', model: 'deepseek-v4.1-flash' } },
  ])
  expect(store.model()).toBe('deepseek-v4.1-flash')
  expect(store.route()).toBe('home')
})

test('a pick on Home after New stays local: that route still shows the previous session', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => sent.push({ kind, payload }))
  sessionRoute(store, 1)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'model-catalog',
    payload: {
      sessionId: 'ses_1',
      models: [{ provider: 'cliproxy', model: 'deepseek-v4.1-flash', label: 'DeepSeek V4.1 Flash', current: false }],
    },
  })
  store.runAction('new-session')
  expect(store.route()).toBe('home')
  store.runAction('pick-model')
  store.closeTopDialog('model:cliproxy/deepseek-v4.1-flash')
  // New does not switch the host session; it only shows Home over the conversation that is
  // still foreground. Writing the pick there would move *that* session's route, and the new
  // one gets the pick from the `selection` it is created with.
  expect(sent.filter(entry => entry.kind === 'set-selection')).toEqual([])
  expect(store.model()).toBe('deepseek-v4.1-flash')
})

test('palette options come from the host state and carry the entry id', () => {
  const store = createAppStore()
  sessionRoute(store, 1)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'reasoning-efforts', payload: { sessionId: 'ses_1', efforts: ['high', 'max'], current: 'high' } })
  store.apply({ protocolVersion: 2, seq: 3, kind: 'session-list', payload: { sessions: [{ id: 'ses_1', title: 'first prompt', active: true }], current: 'ses_1' } })
  store.apply({ protocolVersion: 2, seq: 4, kind: 'provider-catalog', payload: { providers: [{ id: 'cliproxy', label: 'CliProxy', api: 'openai', baseURL: '' }] } })
  store.apply({ protocolVersion: 2, seq: 5, kind: 'model-catalog', payload: { sessionId: 'ses_1', models: [{ provider: 'cliproxy', model: 'mimo-v2.6-pro', label: 'mimo', current: true }] } })
  store.apply({ protocolVersion: 2, seq: 6, kind: 'permission-presets', payload: { sessionId: 'ses_1', presets: [{ id: 'auto', label: 'Auto', current: true }, { id: 'full', label: 'Full access', current: false }] } })
  store.apply({ protocolVersion: 2, seq: 7, kind: 'agent-presets', payload: { sessionId: 'ses_1', presets: [{ id: 'standard', label: 'standard', current: true }, { id: 'code', label: 'code', current: false }] } })
  const options = paletteOptions({
    t: (_key: string, fallback: string) => fallback,
    efforts: store.efforts(),
    effortCurrent: store.effortCurrent(),
    skills: [{ name: 'dsh-review', description: 'review the diff' }],
    providers: store.providers(),
    permissions: store.permissionPresets(),
    permissionCurrent: store.permission(),
    modes: store.agentPresets(),
    modeCurrent: store.preset(),
    currentLabel: 'current',
  })
  expect(options.filter(option => option.category === 'skills').map(option => [option.value, option.description])).toEqual([['skill:dsh-review', 'review the diff']])
  // Sessions are not a palette group (a long history turned the list into a second picker);
  // the action row opens the real one.
  expect(options.some(option => option.value.startsWith('session:'))).toBe(false)
  expect(options.some(option => option.category === 'sessions')).toBe(false)
  // The actions group is the whole command surface: the lifecycle actions, then one entry
  // per local slash command, so the palette and the typed vocabulary cannot drift apart.
  const actions = options.filter(option => option.category === 'actions').map(option => option.value)
  expect(actions.slice(0, 5)).toEqual([
    'action:rename-session',
    'action:new-session',
    'action:trace',
    'action:export',
    'action:exit',
  ])
  expect(actions).toContain('action:slash:/settings')
  expect(actions).toContain('action:slash:/models')
  expect(actions).toContain('action:slash:/sessions')
  expect(actions).toHaveLength(PALETTE_ACTIONS.length)
  // The model catalog is not a palette group: "switch model" is a command that opens the
  // picker, so a menu row can never both select and switch a model.
  expect(options.some(option => option.category === 'models')).toBe(false)
  expect(options.filter(option => option.category === 'permissions').map(option => [option.value, option.footer])).toEqual([
    ['permission:auto', 'current'],
    ['permission:full', undefined],
  ])
  expect(options.filter(option => option.category === 'agents').map(option => [option.value, option.footer])).toEqual([
    ['mode:standard', 'current'],
    ['mode:code', undefined],
  ])
  expect(options.filter(option => option.category === 'wechat').map(option => option.value)).toEqual([
    'wechat:connect',
    'wechat:status',
    'wechat:notify',
    'wechat:progress',
  ])
})

test('picking a palette entry sends the matching upstream request and closes the dialog', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => sent.push({ kind, payload }))
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'reasoning-efforts', payload: { sessionId: 'ses_1', efforts: ['high', 'max'], current: 'high' } })
  store.runAction('palette')
  store.closeTopDialog('effort:max')
  expect(sent).toEqual([{ kind: 'set-selection', payload: { sessionId: 'ses_1', effort: 'max' } }])
  expect(store.dialogOpen()).toBe(false)
})

test('permission opens built-in choices before the host catalog arrives', () => {
  const store = createAppStore()
  sessionRoute(store, 1)
  store.setComposer('/permission')
  store.submitComposer()
  expect(store.dialogStack().at(-1)?.options?.map(option => [option.title, option.value])).toEqual([
    ['workspace write', 'permission:workspace-write'],
    ['full access', 'permission:full-access'],
  ])
  store.closeTopDialog(undefined)
})

test('permission keeps the process catalog across a later session snapshot', () => {
  const store = createAppStore()
  sessionRoute(store, 1)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'permission-presets',
    payload: {
      sessionId: 'ses_1',
      presets: [
        { id: 'workspace-write', label: 'workspace write', current: true },
        { id: 'full-access', label: 'full access', current: false },
      ],
    },
  })
  store.apply({
    protocolVersion: 2,
    seq: 3,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'session',
      title: 'first prompt',
      events: [{ id: 'e1', role: 'user', text: 'hello' }],
      provider: 'cliproxy',
      model: 'mimo-v2.6-pro',
      effort: 'high',
      permission: 'workspace-write',
      preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  store.setComposer('/permission')
  store.submitComposer()
  expect(store.dialogStack().at(-1)?.options?.map(option => [option.title, option.value])).toEqual([
    ['workspace write', 'permission:workspace-write'],
    ['full access', 'permission:full-access'],
  ])
  store.closeTopDialog(undefined)
})

test('permission, mode, and wechat palette picks send their upstream requests', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => sent.push({ kind, payload }))
  sessionRoute(store, 20)
  for (const entry of ['permission:full', 'mode:code', 'wechat:connect']) {
    store.runAction('palette')
    store.closeTopDialog(entry)
  }
  expect(sent).toEqual([
    { kind: 'set-selection', payload: { sessionId: 'ses_1', permission: 'full' } },
    { kind: 'set-selection', payload: { sessionId: 'ses_1', preset: 'code' } },
    { kind: 'wechat-op', payload: { op: 'connect' } },
  ])
})

test('the first Home message reuses the blank session instead of creating another', async () => {
  // The Home route already sits on a real (blank) session. Sending the first message must
  // submit into that session: minting a new id left the blank one behind as a second
  // "New Session" tab and made the host build a session nobody asked for.
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'home', title: '', events: [], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  const { renderer, mockInput, renderOnce } = await mountShell(store, { width: 100, height: 24 })
  await renderOnce()
  await mockInput.typeText('hello there', 0)
  await renderOnce()
  mockInput.pressEnter()
  await renderOnce()
  // One submission, into the session Home was already on.
  expect(sent.filter(entry => entry.kind === 'send-message')).toEqual([
    { kind: 'send-message', payload: { sessionId: 'ses_1', text: 'hello there', delivery: 'steer' } },
  ])
  expect(sent.some(entry => entry.kind === 'session-op' && (entry.payload as { op?: string }).op === 'new')).toBe(false)
  expect(store.route()).toBe('session')
  // The send request is still pending: the draft becomes the real tab when it settles.
  store.apply({ protocolVersion: 2, seq: 2, kind: 'command-result', payload: { seq: 1, ok: true } })
  await renderOnce()
  expect(store.openTabs()).toEqual(['ses_1'])
  renderer.destroy()
})

test('new session creates one Home draft and the first prompt promotes it in place', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.runAction('new-session')
  expect(store.openTabs()).toEqual(['ses_1', DRAFT_TAB_ID])
  expect(store.route()).toBe('home')
  // A second + switches back to the same draft instead of stacking empty tabs.
  store.runAction('new-session')
  expect(store.openTabs()).toEqual(['ses_1', DRAFT_TAB_ID])
  store.setComposer('a new conversation')
  store.submitComposer()
  const create = sent.find(entry => entry.kind === 'session-op' && (entry.payload as { op?: string }).op === 'new')
  const created = create?.payload as { sessionId?: string } | undefined
  expect(typeof created?.sessionId).toBe('string')
  const createdId = created!.sessionId!
  // Until the host acknowledges creation the optimistic strip still owns the draft.
  expect(store.openTabs()).toEqual(['ses_1', DRAFT_TAB_ID])
  store.apply({ protocolVersion: 2, seq: 2, kind: 'command-result', payload: { seq: 1, ok: true, value: { sessionId: createdId } } })
  await Promise.resolve()
  await Promise.resolve()
  expect(store.openTabs()).toEqual(['ses_1', createdId])
  const send = sent.find(entry => entry.kind === 'send-message')
  expect(send?.payload).toMatchObject({ sessionId: createdId, text: 'a new conversation' })
  store.apply({ protocolVersion: 2, seq: 3, kind: 'command-result', payload: { seq: 2, ok: true } })
  await Promise.resolve()
  store.apply({
    protocolVersion: 2,
    seq: 4,
    kind: 'session-snapshot',
    payload: { sessionId: createdId, initialRoute: 'session', title: 'a new conversation', events: [{ id: 'e-new', role: 'user', text: 'a new conversation' }], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' },
  })
  expect(store.openTabs()).toEqual(['ses_1', createdId])
  expect(store.tabTitle(createdId)).toBe('a new conversation')
})

test('closing the Home draft returns to its left neighbour', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.runAction('new-session')
  store.closeSessionTab()
  expect(store.openTabs()).toEqual(['ses_1'])
  expect(store.route()).toBe('home')
  expect(sent).toEqual([{ kind: 'session-op', payload: { op: 'switch', sessionId: 'ses_1' } }])
})

test('a blank Home session does not put a New Session chip in the strip', async () => {
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'home', title: '', events: [], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  expect(store.openTabs()).toEqual([])
  // A session that already has a conversation keeps its tab.
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-snapshot', payload: { sessionId: 'ses_2', initialRoute: 'session', title: 'real work', events: [{ id: 'e1', role: 'user', text: 'hi' }], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  expect(store.openTabs()).toEqual(['ses_2'])
})

test("a partial host catalog still completes the renderer's own commands", async () => {
  // The host catalogs what the harness registers; `/sessions`, `/rename`, `/themes` … are
  // intercepted here. `/re` used to find nothing when the host's list stopped at `/effort`,
  // which read as "the slash key does nothing".
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 't', events: [{ id: 'e1', role: 'user', text: 'hi' }], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'command-catalog', payload: { sessionId: 'ses_1', commands: [{ name: 'model', description: 'switch model' }, { name: 'help', description: 'help' }, { name: 'think', description: 'effort' }] } })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 110, height: 28 })
  await renderOnce()
  await mockInput.typeText('/re', 0)
  await renderOnce()
  const frame = captureCharFrame()
  // opencode's `/sessions` is not a `/re` match; the local `/rename` still is.
  expect(frame).toContain('/rename')
  // The merged catalog carries the renamed local vocabulary too.
  expect(store.slashCommands().map(command => command.name)).toContain('sessions')
  expect(store.slashCommands().map(command => command.name)).toContain('models')
  // The host's own rows are still there when the prefix matches them.
  await mockInput.typeText('', 0)
  renderer.destroy()
})

test("a slash opens the command menu on Home before the host sends a catalog", async () => {
  // A fresh Home session can paint before `command-catalog` arrives. An empty catalog used to
  // leave the popup with zero rows, so `/` looked like a dead key; the renderer's own command
  // vocabulary fills in, and the row still runs through the local interceptor.
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'home', title: '', events: [], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'C:/Users/mytianyi' } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'model-catalog', payload: { sessionId: 'ses_1', models: [{ provider: 'cliproxy', model: 'mimo-v2.6-pro', label: 'MiMo' }] } })
  expect(store.commands().length).toBe(0)
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 110, height: 28 })
  await renderOnce()
  await mockInput.typeText('/', 0)
  await renderOnce()
  expect(captureCharFrame()).toContain('/model')
  await mockInput.typeText('model', 0)
  await renderOnce()
  mockInput.pressEnter()
  await renderOnce()
  expect(store.dialogStack().map(dialog => dialog.title)).toEqual(['Switch model'])
  renderer.destroy()
})

test("one Enter opens a palette entry's follow-up dialog without closing it again", async () => {
  // The focused list input and the keymap both report `return` for the same press. The first
  // commit opens the model picker; the second used to submit *that* picker and close it in the
  // same tick, which read as "select the row, press Enter, nothing happens".
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 21, kind: 'model-catalog', payload: { sessionId: 'ses_1', models: [{ provider: 'cliproxy', model: 'mimo-v2.6-pro', label: 'MiMo' }, { provider: 'cliproxy', model: 'kimi-k2', label: 'Kimi' }] } })
  store.apply({ protocolVersion: 2, seq: 22, kind: 'provider-catalog', payload: { providers: [{ id: 'cliproxy', label: 'Cliproxy' }] } })
  const { renderer, mockInput, renderOnce } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  mockInput.pressKey('p', { ctrl: true })
  await renderOnce()
  await mockInput.typeText('switch model', 0)
  await renderOnce()
  mockInput.pressEnter()
  await renderOnce()
  expect(store.dialogStack().map(dialog => dialog.title)).toEqual(['Switch model'])
  renderer.destroy()
})

test('a typed slash command opens its dialog when Enter accepts the completion', async () => {
  // `/model` is a local command: accepting the completion has to route it through the same
  // interceptor a submitted line uses, and the follow-up dialog has to survive the press.
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 21, kind: 'command-catalog', payload: { sessionId: 'ses_1', commands: [{ name: 'model', description: 'switch model' }, { name: 'help', description: 'help' }] } })
  store.apply({ protocolVersion: 2, seq: 22, kind: 'model-catalog', payload: { sessionId: 'ses_1', models: [{ provider: 'cliproxy', model: 'mimo-v2.6-pro', label: 'MiMo' }] } })
  store.apply({ protocolVersion: 2, seq: 23, kind: 'provider-catalog', payload: { providers: [{ id: 'cliproxy', label: 'Cliproxy' }] } })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  await mockInput.typeText('/', 0)
  await renderOnce()
  // The bare slash wakes the command list.
  expect(captureCharFrame()).toContain('/model')
  await mockInput.typeText('model', 0)
  await renderOnce()
  mockInput.pressEnter()
  await renderOnce()
  expect(store.dialogStack().map(dialog => dialog.title)).toEqual(['Switch model'])
  expect(store.composer()).toBe('')
  renderer.destroy()
})

test('key events reach the keymap and open the palette through the store', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  // `ctrl+p` opens the palette with no group filter, so the action entries show.
  mockInput.pressKey('p', { ctrl: true })
  await renderOnce()
  expect(captureCharFrame()).toContain('rename session')
})

test('the palette paints its entries when open and escape closes it', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  const { renderer, mockInput, renderOnce, flush, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  store.runAction('palette')
  await renderOnce()
  const frame = captureCharFrame()
  expect(frame).toContain('command palette')
  expect(frame).toContain('rename session')
  expect(frame).toContain('new session')
  // Escape needs the escape-timeout window before the parser reports it.
  mockInput.pressEscape()
  await Bun.sleep(120)
  await flush()
  expect(store.dialogOpen()).toBe(false)
  expect(captureCharFrame()).not.toContain('rename session')
})

test('typing into the composer and pressing Enter sends the draft upstream', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store)
  const { mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  await mockInput.typeText('hello world', 0)
  await renderOnce()
  expect(store.composer()).toBe('hello world')
  expect(captureCharFrame()).toContain('hello world')
  mockInput.pressEnter()
  await renderOnce()
  expect(sent).toEqual([{ kind: 'send-message', payload: { sessionId: 'ses_1', text: 'hello world', delivery: 'steer' } }])
  expect(store.composer()).toBe('')
})

test('a multi-line draft paints in the composer textarea and clears on Enter', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store)
  store.setComposer('line one\nline two')
  const { mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  await Bun.sleep(10)
  const frame = captureCharFrame()
  expect(store.composer()).toBe('line one\nline two')
  expect(frame).toContain('line one')
  expect(frame).toContain('line two')
  mockInput.pressEnter()
  await renderOnce()
  expect(sent).toEqual([{ kind: 'send-message', payload: { sessionId: 'ses_1', text: 'line one\nline two', delivery: 'steer' } }])
})


test('Tab on a local picker command opens its dialog on one keystroke', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'command-catalog',
    payload: {
      sessionId: 'ses_1', commands: [{ name: 'permission', description: 'pick a permission preset' }] },
  })
  const { renderer, mockInput, renderOnce } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  await mockInput.typeText('/pe', 0)
  await renderOnce()
  expect(store.composer()).toBe('/pe')
  mockInput.pressKey('TAB')
  await renderOnce()
  // `/permission` is a renderer-local picker: accepting it opens the dialog instead of
  // parking the half-typed line in the draft for a second Enter.
  expect(store.composer()).toBe('')
  expect(store.dialogStack().length).toBe(1)
  expect(store.dialogStack()[0]?.title).toBe('permission')
  expect(sent).toEqual([])
  expect(store.popupOpen()).toBe(false)
})

test('a user-questions request asks one question at a time and answers the whole request', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'question-request',
    payload: {
      request: 'q7',
      questions: [
        { id: 'a', question: 'pick a route', header: 'route', options: [{ label: 'fast' }, { label: 'safe' }] },
        { id: 'b', question: 'notes' },
      ],
    },
  })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  await Bun.sleep(10)
  expect(captureCharFrame()).toContain('route')
  expect(captureCharFrame()).toContain('fast')
  // Picking the first option records the answer for `a` and opens the second question;
  // the request is not answered until every question has an answer.
  mockInput.pressEnter()
  await renderOnce()
  expect(sent).toEqual([])
  expect(captureCharFrame()).toContain('notes')
  // The prompt's input focuses one millisecond after it mounts; give it the tick before
  // typing, otherwise the keystrokes go nowhere and the answer comes back empty.
  await Bun.sleep(10)
  await mockInput.typeText('ok')
  await renderOnce()
  expect(captureCharFrame()).toContain('ok')
  mockInput.pressEnter()
  await renderOnce()
  expect(sent).toEqual([{
    kind: 'question-answer',
    payload: { request: 'q7', answers: [{ id: 'a', selected: ['fast'] }, { id: 'b', selected: [], custom: 'ok' }] },
  }])
  renderer.destroy()
})

test('the provider form paints its fields, cycles the select, and sends the values on Enter', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'form-spec',
    payload: {
      form: 'provider',
      title: 'edit provider',
      fields: [
        { key: 'id', label: 'ID', kind: 'text', value: 'cliproxy' },
        { key: 'api', label: 'API type', kind: 'select', value: 'openai-completions', options: ['openai-completions', 'anthropic-messages'] },
        { key: 'apiKey', label: 'API key', kind: 'secret', value: 'sk-123' },
        { key: 'models', label: 'Models', kind: 'text', value: 'mimo|MiMo|high|high|128k|8k\nother|Other|||', multiline: true },
      ],
    },
  })
  expect(store.dialogOpen()).toBe(true)
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  await Bun.sleep(10)
  const frame = captureCharFrame()
  expect(frame).toContain('edit provider')
  expect(frame).toContain('ID')
  expect(frame).toContain('cliproxy')
  expect(frame).toContain('< openai-completions >')
  // The secret field is not the active field, so its text paints as masked bullets;
  // the multiline models field paints each model line inside the panel.
  expect(frame).toContain('•••••')
  expect(frame).not.toContain('sk-123')
  expect(frame).toContain('mimo|MiMo|high|high|128k|8k')
  expect(frame).toContain('other|Other|||')
  // `down` moves to the select field, `right` cycles its accepted values. The dialog
  // controller is what the keymap routes to, so driving it here exercises the same seam.
  store.runAction('dialog-next')
  await renderOnce()
  store.runAction('dialog-right')
  await renderOnce()
  expect(store.dialogOpen()).toBe(true)
  expect(captureCharFrame()).toContain('< anthropic-messages >')
  store.runAction('dialog-submit')
  await renderOnce()
  expect(sent).toEqual([{
    kind: 'form-submit',
    payload: { form: 'provider', values: { id: 'cliproxy', api: 'anthropic-messages', apiKey: 'sk-123', models: 'mimo|MiMo|high|high|128k|8k\nother|Other|||' } },
  }])
  renderer.destroy()
})

test('escape on the provider form cancels without sending', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'form-spec',
    payload: { form: 'provider', title: 'edit provider', fields: [{ key: 'id', label: 'ID', kind: 'text', value: 'cliproxy' }] },
  })
  const { renderer, mockInput, renderOnce, flush } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  await Bun.sleep(10)
  mockInput.pressEscape()
  await Bun.sleep(120)
  await flush()
  expect(sent).toEqual([])
  expect(store.dialogOpen()).toBe(false)
  renderer.destroy()
})

test('the discovery action row sends the current values and takes the merged line back', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'form-spec',
    payload: {
      form: 'provider',
      title: 'edit provider',
      fields: [
        { key: 'id', label: 'ID', kind: 'text', value: 'cliproxy' },
        { key: 'models', label: 'Models', kind: 'text', value: 'mimo|MiMo|high=high|max|131072|32768' },
        { key: 'discover', label: 'Discover upstream models', kind: 'action', value: 'Discover upstream models' },
      ],
    },
  })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  await Bun.sleep(10)
  // The renderer has no button primitive, so the probe is a row in the same field list.
  expect(captureCharFrame()).toContain('[ Discover upstream models ]')
  // Enter on an action row sends the probe request and keeps the form open; Enter on a
  // field row submits the form.
  mockInput.pressArrow('down')
  mockInput.pressArrow('down')
  mockInput.pressEnter()
  await renderOnce()
  expect(sent).toEqual([{
    kind: 'model-discover',
    payload: { form: 'provider', fields: { id: 'cliproxy', models: 'mimo|MiMo|high=high|max|131072|32768', discover: 'Discover upstream models' } },
  }])
  expect(store.dialogOpen()).toBe(true)
  // The host answers with the merged line and the models field's value is replaced. The
  // input is 40 cells wide, so the appended id is asserted at the head of the window.
  store.apply({ protocolVersion: 2, seq: 2, kind: 'model-discovery', payload: { form: 'provider', models: 'mimo|MiMo|high=high|max|131072|32768 gpt|GPT|none||128000|4096' } })
  await renderOnce()
  expect(captureCharFrame()).toContain('gpt|')
  renderer.destroy()
})

test('the edit-models row asks the host for the list and a pick sends the picked model', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'form-spec',
    payload: {
      form: 'provider',
      title: 'edit provider',
      fields: [
        { key: 'models', label: 'Models', kind: 'text', value: 'mimo|MiMo|none||131072|32768 gpt|GPT|none||128000|4096' },
        { key: 'edit-models', label: 'Edit models', kind: 'action', value: 'Edit models' },
      ],
    },
  })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  await Bun.sleep(10)
  expect(captureCharFrame()).toContain('[ Edit models ]')
  // The active row starts on the models field; `down` moves to the action row, and Enter
  // on it sends the list request and keeps the form open.
  mockInput.pressArrow('down')
  mockInput.pressEnter()
  await renderOnce()
  expect(sent[0]).toEqual({
    kind: 'model-list-request',
    payload: { form: 'provider', fields: { models: 'mimo|MiMo|none||131072|32768 gpt|GPT|none||128000|4096', 'edit-models': 'Edit models' } },
  })
  // The host answers with the parsed list; the renderer opens its own select over it, and
  // the pick carries the line the list was requested from, so the merge happens against
  // the values the renderer has on screen.
  store.apply({ protocolVersion: 2, seq: 2, kind: 'model-list', payload: { form: 'provider', models: [{ id: 'mimo', label: 'MiMo' }, { id: 'gpt', label: 'GPT' }] } })
  await renderOnce()
  expect(captureCharFrame()).toContain('gpt (GPT)')
  store.closeTopDialog('gpt')
  await renderOnce()
  expect(sent[1]).toEqual({ kind: 'model-edit', payload: { form: 'provider', id: 'gpt', models: 'mimo|MiMo|none||131072|32768 gpt|GPT|none||128000|4096' } })
  renderer.destroy()
})

test('picking a model row through the real keys sends model-edit and opens one form', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'form-spec',
    payload: {
      form: 'provider',
      title: 'edit provider',
      fields: [
        { key: 'models', label: 'Models', kind: 'text', value: 'mimo|MiMo gpt|GPT' },
        { key: 'edit-models', label: 'Edit models', kind: 'action', value: 'Edit models' },
      ],
    },
  })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  // The whole flow runs through the mock keyboard: `down` moves to the action row, Enter
  // routes through the keymap's `dialog-submit` to the form's controller, the controller
  // sends the list request, the host answers with the list, `down` highlights the second
  // row, Enter routes to the list's controller, which closes the dialog with the picked
  // value, and the answer carries the line the list was opened from.
  store.runAction('dialog-next')
  await renderOnce()
  store.runAction('dialog-submit')
  store.apply({ protocolVersion: 2, seq: 2, kind: 'model-list', payload: { form: 'provider', models: [{ id: 'mimo', label: 'MiMo' }, { id: 'gpt', label: 'GPT' }] } })
  await renderOnce()
  expect(store.dialogStack().length).toBe(2)
  store.runAction('dialog-next')
  await renderOnce()
  store.runAction('dialog-submit')
  await renderOnce()
  expect(sent[1]).toEqual({ kind: 'model-edit', payload: { form: 'provider', id: 'gpt', models: 'mimo|MiMo gpt|GPT' } })
  // The picked row closed the list, so only the provider form is left on the stack.
  expect(store.dialogStack().length).toBe(1)
  // One envelope opens exactly one dialog. A second dispatcher applies every envelope
  // twice, which opens two forms and doubles the resize listeners each dialog
  // subscribes; crossing Node's limit of 10 prints MaxListenersExceededWarning on
  // stderr, and a stderr write closes the renderer's IPC channel. The channel itself
  // is not visible in a test (the store's `send` is injected), so the count of open
  // dialogs is the assertion that the single dispatcher holds.
  store.apply({
    protocolVersion: 2,
    seq: 3,
    kind: 'form-spec',
    payload: { form: 'model', title: 'models · gpt', fields: [{ key: 'max', label: 'Max', kind: 'text', value: '4096' }] },
  })
  await renderOnce()
  expect(store.dialogStack().length).toBe(2)
  expect(captureCharFrame()).toContain('models · gpt')
  // A warning routes to the toast overlay: the renderer never writes to stderr, so the overlay
  // is the only path a stray warning takes to the screen. The toast paints its text plus the
  // click-to-dismiss marker (upstream's `x`, inside the panel's own padding), and sits in the
  // top-right band above the dialog layer.
  store.pushNotice('error', 'a warning routed from stderr')
  await renderOnce()
  const toastFrame = captureCharFrame()
  const toastRow = toastFrame.split('\n').find(row => row.includes('a warning routed from stderr'))
  expect(toastRow).toBeDefined()
  expect(toastRow).toMatch(/x\s*│/)
  renderer.destroy()
})

test('the toast overlay paints one notice at the top-right and never pushes the layout', async () => {
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hello' }], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  const base = await mountShell(store, { width: 120, height: 24 })
  await base.renderOnce()
  const baseRows = base.captureCharFrame().split('\n')
  store.pushNotice('warning', 'toast one')
  store.pauseToast()
  store.pushNotice('error', 'toast two')
  store.pushNotice('error', 'toast three')
  await base.renderOnce()
  const stacked = base.captureCharFrame().split('\n')
  // The overlay is absolutely positioned in the top-right band, so the prompt stack and the
  // footer keep their rows. Upstream shows one toast and counts the queue under it.
  const top = stacked.slice(0, 8).join('\n')
  expect(top).toContain('toast one')
  expect(top).toContain('+2 more')
  expect(top).not.toContain('toast two')
  // The toast sits in the right half, never at the left edge of the content column.
  const toastRow = stacked.findIndex(row => row.includes('toast one'))
  expect(toastRow).toBeGreaterThan(0)
  expect(stacked[toastRow]!.indexOf('toast one')).toBeGreaterThan(60)
  expect(stacked[23]).toBe(baseRows[23]!)
  expect(stacked[22]).toBe(baseRows[22]!)
  // The width clamp: the band is at most 60 cells, so nothing paints in the last two columns.
  expect(stacked[toastRow]!.slice(118).trim()).toBe('')
  base.renderer.destroy()
})

test('the settings page lists the harness forms and a pick sends dialog-request', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'model-catalog',
    payload: {
      sessionId: 'ses_1', models: [{ provider: 'cliproxy', model: 'mimo-v2.6-pro', label: 'mimo', current: true }] },
  })
  store.runAction('settings')
  expect(store.dialogOpen()).toBe(true)
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  await Bun.sleep(10)
  // The page carries the interface language, the settings fields, the agent-loop cap, the two
  // prompt templates, the two keybinding fields, and the two harness forms. The list window is six rows, so the
  // rows below it are asserted on the dialog stack's options, not on the painted grid.
  const options = store.dialogStack().at(-1)?.options?.map(option => option.value) ?? []
  // The appearance rows come from the native theme provider; the rest are the harness
  // fields and forms this page edits.
  expect(options).toEqual([
    'setting:locale',
    'setting:showReasoning',
    'setting:maxToolOutputLines',
    'setting:maxParallelToolCalls',
    'setting:leftPrompt',
    'setting:rightPrompt',
    'setting:keyTools',
    'setting:keyReasoning',
    'setting:theme',
    'setting:themeMode',
    'setting:newDesigns',
    'setting:pathDisplay',
    'setting:autostart',
    'form:provider',
    'form:custom-model',
  ])
  // Nine options in a six-row window, so the pick is driven through the dialog's resolve
  // channel: keyboard navigation of a select list is covered by the settings tests, and
  // what is under test here is the handler wiring. The custom model request carries the
  // provider of the model currently selected in the catalog; the provider form carries
  // no args.
  store.closeTopDialog('form:custom-model')
  await renderOnce()
  expect(sent).toEqual([{ kind: 'dialog-request', payload: { kind: 'custom-model', args: { provider: 'cliproxy' } } }])
  store.runAction('settings')
  store.closeTopDialog('form:provider')
  await renderOnce()
  expect(sent[1]).toEqual({ kind: 'dialog-request', payload: { kind: 'provider' } })
  renderer.destroy()
})

test('the prompt template fields write through the settings seam', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'settings', payload: { schemaVersion: 2, values: { leftPrompt: 'hi', rightPrompt: '' } } })
  store.runAction('settings')
  store.closeTopDialog('setting:leftPrompt')
  // The template text is free-form, so the answer is written as-is.
  store.closeTopDialog('!skill dsh-review')
  expect(sent).toEqual([{ kind: 'update-settings', payload: { requestId: expect.any(String), patch: { leftPrompt: '!skill dsh-review' } } }])
  store.runAction('settings')
  store.closeTopDialog('setting:rightPrompt')
  store.closeTopDialog('')
  // An empty answer is written too: clearing the template is a valid edit.
  expect(sent[1]).toEqual({ kind: 'update-settings', payload: { requestId: expect.any(String), patch: { rightPrompt: '' } } })
})

test('a double ctrl+c at an idle prompt exits once', () => {
  const sent: string[] = []
  let exits = 0
  const store = createAppStore(
    kind => {
      sent.push(kind)
      return sent.length
    },
    undefined,
    () => { exits += 1 },
  )
  sessionRoute(store, 20)
  // Upstream's priority: the first ctrl+c clears a draft or a dialog, an empty idle prompt
  // is the quit. A second one lands while the shutdown is in flight and must not send a
  // second `bye` on a channel that is already closing.
  store.runAction('cancel')
  store.runAction('cancel')
  expect(sent).toEqual(['bye'])
  expect(exits).toBe(1)
})

test('/exit asks the renderer to restore its own terminal', () => {
  const sent: string[] = []
  let exits = 0
  const store = createAppStore(
    kind => {
      sent.push(kind)
      return sent.length
    },
    undefined,
    () => { exits += 1 },
  )
  store.runAction('exit')
  // The host no longer kills a renderer that says `bye`, so the renderer has to end
  // itself: its shutdown writes the terminal restore the host used to truncate.
  expect(sent).toEqual(['bye'])
  expect(exits).toBe(1)
})

test('the language row writes the interface locale through update-settings', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'i18n', payload: { locale: 'zh-CN', strings: {} } })
  store.runAction('settings')
  store.closeTopDialog('setting:locale')
  const picker = store.dialogStack().at(-1)
  // The two dictionaries the host ships; the current one is marked, and the current pick is a
  // no-op so re-picking the language on screen never writes a redundant patch.
  expect(picker?.options?.map(option => option.value)).toEqual(['zh-CN', 'en'])
  store.closeTopDialog('zh-CN')
  expect(sent).toEqual([])
  store.runAction('settings')
  store.closeTopDialog('setting:locale')
  store.closeTopDialog('en')
  expect(sent).toEqual([{ kind: 'update-settings', payload: { requestId: expect.any(String), patch: { locale: 'en' } } }])
})

test('the keybinding fields write the typed key and skip an empty answer', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'settings', payload: { schemaVersion: 2, values: { keyTools: 'ctrl+o', keyReasoning: 'ctrl+t' } } })
  store.runAction('settings')
  store.closeTopDialog('setting:keyTools')
  store.closeTopDialog('shift+tab')
  expect(sent).toEqual([{ kind: 'update-settings', payload: { requestId: expect.any(String), patch: { keyTools: 'shift+tab' } } }])
  store.runAction('settings')
  store.closeTopDialog('setting:keyReasoning')
  store.closeTopDialog('   ')
  // An empty answer is not written: pi-tui's keybind edit skips it, and a key that
  // `matchesKey` can never match is not a setting worth persisting.
  expect(sent.length).toBe(1)
})

test('the agent-loop cap row writes with its namespace', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'settings', payload: { schemaVersion: 2, values: {}, agentLoop: { maxParallelToolCalls: 3 } } })
  store.runAction('settings')
  store.closeTopDialog('setting:maxParallelToolCalls')
  store.closeTopDialog('5')
  // The cap is not a TUI field, so the write carries the namespace.
  expect(sent).toEqual([{ kind: 'update-settings', payload: { requestId: expect.any(String), patch: { maxParallelToolCalls: 5 }, ns: 'agent-loop' } }])
})

test('the skills list reaches the palette and a pick sends the skill command upstream', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'skills-list', payload: { sessionId: 'ses_1', skills: [{ name: 'dsh-review', description: 'review the diff' }, { name: 'git-commit', description: 'commit the staged diff' }] } })
  expect(store.skills().length).toBe(2)
  store.runAction('palette')
  // The palette's skills category carries the host's list; picking a row sends the same
  // `skill:` line the composer completes, so the host's registry owns the invocation.
  store.closeTopDialog('skill:git-commit')
  expect(sent).toEqual([{ kind: 'send-message', payload: { sessionId: 'ses_1', text: '', delivery: 'steer', skills: ['git-commit'] } }])
})

test('usage, branch, MCP server names, plugin inventory, and todos land in their signals', () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'usage', payload: { sessionId: 'ses_1', inputTokens: 12000, outputTokens: 3400, cacheReadTokens: 8000, cacheWriteTokens: 200, contextTokens: 12300, contextWindow: 131072, contextPct: 9 } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'git-branch', payload: { sessionId: 'ses_1', branch: 'main' } })
  store.apply({ protocolVersion: 2, seq: 3, kind: 'mcp-servers', payload: { servers: [{ id: 'mcp-1', name: 'dsh-review' }] } })
  store.apply({ protocolVersion: 2, seq: 4, kind: 'host-plugins', payload: { plugins: [{ id: 'p-1', moduleName: 'dsh-review', enabled: true, fiberPhase: 'active' }] } })
  store.apply({ protocolVersion: 2, seq: 5, kind: 'todos', payload: { sessionId: 'ses_1', items: [{ content: 'fix the bug', status: 'in_progress' }] } })
  expect(store.usage()?.contextPct).toBe(9)
  expect(store.usage()?.cost).toBeUndefined()
  expect(store.gitBranch()).toBe('main')
  expect(store.mcpServers()).toEqual([{ id: 'mcp-1', name: 'dsh-review' }])
  expect(store.hostPlugins()).toEqual([{ id: 'p-1', moduleName: 'dsh-review', enabled: true, fiberPhase: 'active' }])
  expect(store.todos()[0]!.status).toBe('in_progress')
  store.apply({ protocolVersion: 2, seq: 6, kind: 'usage', payload: { sessionId: 'ses_1', outputTokens: 1 } })
  expect(store.usage()?.contextPct).toBe(9)
})

test('the snapshot fills the route signals and the status bar paints the cwd and the palette hint', async () => {
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'session',
      title: 'first prompt',
      events: [{ id: 'e1', role: 'user', text: 'hello' }],
      provider: 'cliproxy',
      model: 'mimo-v2.6-pro',
      effort: 'high',
      permission: 'auto',
      preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  expect([store.provider(), store.model(), store.effortCurrent(), store.permission(), store.preset()]).toEqual(
    ['cliproxy', 'mimo-v2.6-pro', 'high', 'auto', 'standard'],
  )
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 120, height: 24 })
  await renderOnce()
  const rows = painted(captureCharFrame())
  // The metadata row under the textarea is `mode permission · model · effort`.
  const metadataAt = (text: string): string => rows.find(row => row.includes(text)) ?? ''
  expect(metadataAt('标准模式')).toContain('标准模式 自动 · mimo-v2.6-pro · high')
  // The bar's first row is the cwd on the left and the palette hint on the right; the route is
  // no longer repeated there.
  const directoryRow = rows.at(-2) ?? ''
  expect(directoryRow).toContain('D:/Projects/dsh')
  expect(directoryRow).toContain('ctrl+p commands')
  expect(directoryRow).not.toContain('cliproxy/mimo-v2.6-pro')
  expect(directoryRow).not.toContain('standard')
  // The second row is the centred metrics line; the turn/step counters no longer wait for
  // usage or for the last assistant row, so the one user message is already visible.
  expect((rows.at(-1) ?? '')).toContain('T1 S0')
  // The 44-cell breakpoint drops the agent and the auto badge from the metadata row.
  const narrow = await mountShell(store, { width: 70, height: 24 })
  await narrow.renderOnce()
  const narrowRows = painted(narrow.captureCharFrame())
  expect(narrowRows.at(-2)).toContain('D:/Projects/dsh')
  expect(narrowRows.at(-2)).toContain('ctrl+p commands')
  expect(narrowRows.find(row => row.includes('mimo-v2.6-pro')) ?? '').toContain('mimo-v2.6-pro · high')
  narrow.renderer.destroy()
  renderer.destroy()
})

test('the prompt paints mode, permission, model and effort in four inks', async () => {
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'session',
      title: 't',
      events: [{ id: 'e1', role: 'user', text: 'hi' }],
      provider: 'cliproxy',
      model: 'deepseek-v4.1-flash',
      effort: 'max',
      permission: 'full-access',
      preset: 'minimal',
      workspace: 'D:/Projects/dsh',
    },
  })
  const { renderer, renderOnce, captureSpans } = await mountShell(store, { width: 120, height: 24 })
  await renderOnce()
  const frame = captureSpans()
  // The requested final shape: 极简模式 完全权限 · deepseek-v4.1-flash · max.
  // Mode uses the gutter accent, permission reuses the thinking warning tone, model the body
  // ink, and effort a distinct cyan accent. The provider is intentionally absent from this row.
  const metadataLine = frame.lines.find(line => line.spans.map(span => span.text).join('').includes('极简模式'))
  const metadataText = metadataLine?.spans.map(span => span.text).join('') ?? ''
  expect(metadataText).toContain('极简模式 完全权限 · deepseek-v4.1-flash · max')
  expect(metadataText).not.toContain('cliproxy')
  expect(rowInk(frame, '极简模式')).toBe('#9d7cd8')
  expect(rowInk(frame, '完全权限')).toBe('#f9e2af')
  expect(rowInk(frame, 'deepseek-v4.1-flash')).toBe('#cdd6f4')
  expect(rowInk(frame, 'max')).toBe('#89dceb')
  // The hint row keeps the chords bright and their labels muted, like `ctrl+p commands`.
  expect(rowInk(frame, 'ctrl+p')).toBe('#cdd6f4')
  expect(rowInk(frame, 'commands')).toBe('#565f89')
  renderer.destroy()
})

test('the prompt and the footer name the preset the same way', async () => {
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'session',
      title: 'first prompt',
      events: [
        { id: 'e1', role: 'user', text: 'hello' },
        { id: 'a1', role: 'assistant', text: 'the answer', model: 'mimo-v2.6-pro', durationMs: 1200, tokPerSec: 40, footer: true },
      ],
      provider: 'cliproxy',
      model: 'mimo-v2.6-pro',
      effort: 'high',
      permission: 'auto',
      preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'agent-presets',
    payload: { sessionId: 'ses_1', presets: [{ id: 'standard', label: '标准模式', current: true }] },
  })
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 120, height: 24 })
  await renderOnce()
  const frame = captureCharFrame()
  // The catalog's label is the only spelling of the agent: the prompt row said `标准模式` while
  // the footer said `standard` (the id), so one screen named the same thing two ways.
  expect(frame).toContain('标准模式 自动 · mimo-v2.6-pro · high')
  expect(frame).toContain('标准模式 · mimo-v2.6-pro · 1.2s · 40.0 tok/s')
  expect(frame).not.toContain('standard')
  renderer.destroy()
})

test('the palette and the popup paint the host dictionary, not the English ids', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 30,
    kind: 'i18n',
    payload: {
      locale: 'zh-CN',
      strings: {
        rendererPaletteActions: '操作',
        rendererPaletteRename: '重命名会话',
        rendererSwitchModel: '切换模型',
        rendererCurrent: '当前',
        rendererNoMatchingReferences: '没有匹配的文件、Agent 或引用',
        rendererSearch: '搜索',
        rendererDialogMove: '移动',
        rendererDialogRun: '运行',
        rendererPalette: '命令面板',
      },
    },
  })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 100, height: 30 })
  store.runAction('palette')
  await renderOnce()
  const frame = captureCharFrame()
  // The painted window shows the translated header and rows (only the first screenful fits,
  // so the rest is read from the dialog's options).
  expect(frame).toContain('命令面板')
  expect(frame).toContain('搜索')
  expect(frame).toContain('移动')
  expect(frame).toContain('运行')
  expect(frame).toContain('操作')
  expect(frame).toContain('重命名会话')
  expect(frame).not.toContain('rename session')
  const options = store.dialogStack().at(-1)?.options ?? []
  const title = (value: string): string | undefined => options.find(option => option.value === value)?.title
  expect(title('action:slash:/models')).toBe('切换模型')
  expect(title('action:rename-session')).toBe('重命名会话')
  expect(options.some(option => option.title === 'switch model')).toBe(false)
  // The popup's empty state reads from the same dictionary (`@` keeps the popup open with
  // zero matches; a slash draft with no match submits on Enter instead).
  store.closeTopDialog(undefined)
  mockInput.typeText('@zzz', 0)
  await renderOnce()
  expect(captureCharFrame()).toContain('没有匹配的文件、Agent 或引用')
  renderer.destroy()
})

test('the shadow lip continues the gutter instead of ending it in the border ink', async () => {
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'session',
      title: 't',
      events: [{ id: 'e1', role: 'user', text: 'hi' }],
      provider: 'p',
      model: 'm',
      effort: 'high',
      permission: 'auto',
      preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  const { renderer, renderOnce, captureSpans } = await mountShell(store, { width: 100, height: 24 })
  await renderOnce()
  const frame = captureSpans()
  const rows = frame.lines.map(line => line.spans.map(span => span.text).join(''))
  const lip = rows.findIndex(row => row.includes('╹'))
  expect(lip).toBeGreaterThan(0)
  // The lip's `╹` carries the same accent as the gutter above it and the `▀` shadow the panel's
  // own background: a `border.base` corner ended the accent rule in a grey nub.
  const lipRow = frame.lines[lip]!
  expect(inkOf(lipRow.spans.find(span => span.text.includes('╹')))).toBe('#9d7cd8')
  expect(inkOf(lipRow.spans.find(span => span.text.includes('▀')))).toBe('#181825')
  // The row above the lip is the metadata line, still inside the gutter.
  expect(rows[lip - 1]).toContain('┃')
  renderer.destroy()
})

test('a custom prompt template never becomes a third footer row', async () => {
  // `leftPrompt` / `rightPrompt` still parse (their own tests cover the slot table), but the
  // shell's status bar is a fixed two rows: a template cannot add a row or replace the cwd.
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 0, kind: 'settings', payload: { schemaVersion: 2, values: { leftPrompt: '${location}', rightPrompt: '${model}${context}' } } })
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hello' }], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'usage', payload: { sessionId: 'ses_1', inputTokens: 1, outputTokens: 1, cacheReadTokens: 0, cacheWriteTokens: 0, contextTokens: 12300, contextWindow: 131072, contextPct: 9 } })
  store.apply({ protocolVersion: 2, seq: 3, kind: 'git-branch', payload: { sessionId: 'ses_1', branch: 'main' } })
  const wide = await mountShell(store, { width: 120, height: 24 })
  await wide.renderOnce()
  const rows = painted(wide.captureCharFrame())
  const directoryRow = rows.at(-2) ?? ''
  const metricsRow = rows.at(-1) ?? ''
  expect(directoryRow).toContain('D:/Projects/dsh')
  expect(directoryRow).not.toContain('dsh:main')
  expect(directoryRow).not.toContain('cliproxy/mimo-v2.6-pro')
  // The metrics row is the bar's own, not the template's render.
  expect(metricsRow).toContain('12.3k/131.1k (9%)')
  expect(rows.join('\n')).toContain('标准模式 自动 · mimo-v2.6-pro · high')
  wide.renderer.destroy()
})

test('a session snapshot carries usage so restart and same-session refreshes keep cache stats', async () => {
  const store = createAppStore()
  const usage = {
    sessionId: 'ses_1',
    inputTokens: 12000,
    outputTokens: 3400,
    cacheReadTokens: 8000,
    cacheWriteTokens: 200,
    cacheReadObserved: true,
    cacheReadComplete: false,
    cacheBucketsComplete: false,
    contextTokens: 12300,
    contextWindow: 131072,
    contextPct: 9,
  }
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt',
      events: [{ id: 'e1', role: 'user', text: 'hello' }],
      provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard',
      workspace: 'D:/Projects/dsh', usage,
    },
  })
  // The resume/reattach snapshot is the first usage projection; it must not wait for the
  // next live status event or a turn. A mixed cache history still yields a real percentage.
  expect(store.usage()?.cacheReadTokens).toBe(8000)
  expect(store.usage()?.cacheReadObserved).toBe(true)
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 120, height: 24 })
  await renderOnce()
  expect(captureCharFrame()).toContain('cache 40%')
  // A same-session snapshot (route refresh, image capability change, …) may omit usage;
  // that is not evidence the live numbers vanished, so keep the current projection.
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt',
      events: [{ id: 'e1', role: 'user', text: 'hello' }],
      provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  await renderOnce()
  expect(store.usage()?.inputTokens).toBe(12000)
  expect(captureCharFrame()).toContain('cache 40%')
  // A genuine session change must clear the old projection when the new snapshot has no
  // usage, so one tab's cache numbers never leak into another.
  store.apply({
    protocolVersion: 2,
    seq: 3,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_2', initialRoute: 'session', title: 'second',
      events: [{ id: 'e2', role: 'user', text: 'hello again' }],
      provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  await renderOnce()
  expect(store.usage()).toBeUndefined()
  renderer.destroy()
})

test('the status bar paints the usage metrics and keeps two rows under 44 columns', async () => {
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hello' }, { id: 't1', role: 'tool', turn: 3, step: 1, tool: 'read', status: 'ok' }, { id: 't2', role: 'tool', turn: 3, step: 2, tool: 'glob', status: 'ok' }, { id: 'a1', role: 'assistant', text: 'the answer', turn: 3, step: 2, tokPerSec: 42 }], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'usage', payload: { sessionId: 'ses_1', inputTokens: 12000, outputTokens: 3400, cacheReadTokens: 8000, cacheWriteTokens: 200, cacheBucketsComplete: true, contextTokens: 12300, contextWindow: 131072, contextPct: 9 } })
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 120, height: 24 })
  await renderOnce()
  const frame = captureCharFrame()
  const rows = painted(frame)
  const metrics = rows.at(-1) ?? ''
  expect(metrics).toContain('T1 S2 · 42.0 tok/s')
  expect(metrics).toContain('23.6k tokens')
  expect(metrics).toContain('cache 40%')
  expect(metrics).toContain('12.3k/131.1k (9%)')
  // The metrics text is centred: its left margin is within one cell of its right margin.
  const left = metrics.length - metrics.trimStart().length
  const right = metrics.length - metrics.trimEnd().length
  expect(Math.abs(left - right)).toBeLessThanOrEqual(1)
  // dsh has no price table, so the bar invents no `$` segment.
  expect(frame).not.toContain('$')
  // Under the 44-cell breakpoint the metadata labels drop, but the bar keeps both rows.
  const narrow = await mountShell(store, { width: 40, height: 24 })
  await narrow.renderOnce()
  const narrowRows = painted(narrow.captureCharFrame())
  expect(narrowRows.at(-2)).toContain('dsh')
  expect(narrowRows.length).toBe(24)
  // The metadata row keeps mode, permission, model and effort; the provider belongs to the
  // sidebar and never appears in this row, even at the narrow breakpoint.
  const narrowMetadata = narrowRows.find(row => row.includes('mimo-v2.6-pro')) ?? ''
  expect(narrowMetadata).toContain('标准模式 自动')
  expect(narrowMetadata).toContain('mimo-v2.6-pro')
  expect(narrowMetadata).not.toContain('cliproxy/')
  narrow.renderer.destroy()
  renderer.destroy()
})

test('the completion popup sits flush on the composer after the footer row was removed', async () => {
  // The stack's chrome lost its footer row (the status bar owns it), so the popup anchor
  // dropped from 5 to 4. One row too many left a blank line between the popup and the panel.
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 't', events: [{ id: 'e1', role: 'user', text: 'hi' }], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'workspace-files', payload: { sessionId: 'ses_1', files: ['src/alpha.ts', 'src/beta.ts'] } })
  store.setComposer('@src/')
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 100, height: 24 })
  await renderOnce()
  const rows = painted(captureCharFrame())
  const popupRows = rows.flatMap((row, index) => (row.includes('reference') ? [index] : []))
  expect(popupRows.length).toBeGreaterThan(0)
  const lastPopup = Math.max(...popupRows)
  // The panel's top edge is the nearest `┃` row above the draft text: the panel spends two
  // rows of air above the textarea, so the border is not simply `draftRow - 1`.
  const draftRow = rows.findIndex(row => row.includes('@src/') && !row.includes('reference'))
  let panelTop = draftRow - 1
  // The completion popup draws the same `┃` gutter, so the walk stops at its first row.
  while (panelTop > 0 && rows[panelTop - 1]!.trimStart().startsWith('┃') && !rows[panelTop - 1]!.includes('reference')) panelTop -= 1
  expect(rows[panelTop]?.trimStart().startsWith('┃')).toBe(true)
  // No blank line in between: the popup's last row is the row directly above the panel.
  expect(panelTop).toBe(lastPopup + 1)
  renderer.destroy()
})

test('the subagent list paints one row per descriptor', async () => {
  const store = createAppStore()
  sessionRoute(store, 2)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'subagent-list',
    payload: {
      sessionId: 'ses_1', agents: [{ label: 'explorer', provider: 'cliproxy', mode: 'one-shot' }, { label: 'builder', provider: 'anthropic', mode: 'continuable' }] },
  })
  expect(store.subagents().length).toBe(2)
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  const frame = captureCharFrame()
  expect(frame).toContain('↳ explorer · cliproxy · one-shot')
  expect(frame).toContain('↳ builder · anthropic · continuable')
  store.apply({ protocolVersion: 2, seq: 2, kind: 'subagent-list', payload: { sessionId: 'ses_1', agents: [] } })
  expect(store.subagents().length).toBe(0)
  await renderOnce()
  expect(captureCharFrame()).not.toContain('explorer')
  renderer.destroy()
})

test('the open tabs paint as one horizontal strip with the add chip', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 2)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-list', payload: { sessions: [{ id: 'ses_1', title: 'first prompt', active: true }, { id: 'ses_2', title: 'second', active: false }], current: 'ses_1' } })
  // The catalog alone paints no chip: the tab set is the renderer's, fed by snapshots.
  store.openTab('ses_2')
  // Upstream's default layout is the horizontal strip at every width: there is no rail
  // breakpoint, and the strip closes with the add affordance.
  for (const width of [80, 120]) {
    const view = await mountShell(store, { width, height: 24 })
    await view.renderOnce()
    const frame = view.captureCharFrame()
    expect(frame).toContain('1 first prompt')
    expect(frame).toContain('2 second')
    expect(frame).toContain(' + ')
    view.renderer.destroy()
  }
  // A pick on a chip sends the host's session-op switch.
  store.pickSession('ses_2')
  expect(sent).toContainEqual({ kind: 'session-op', payload: { op: 'switch', sessionId: 'ses_2' } })
})

test('the sidebar docks at 168 columns and paints as an overlay under the dock rule', async () => {
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hello' }], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-list', payload: { sessions: [{ id: 'ses_1', title: 'first prompt', active: true }], current: 'ses_1' } })
  store.apply({ protocolVersion: 2, seq: 3, kind: 'usage', payload: { sessionId: 'ses_1', inputTokens: 12000, outputTokens: 3400, cacheReadTokens: 8000, cacheWriteTokens: 200, contextTokens: 12300, contextWindow: 131072, contextPct: 9, cost: 0.12, currency: 'USD', costSource: 'local' } })
  store.apply({ protocolVersion: 2, seq: 4, kind: 'git-branch', payload: { sessionId: 'ses_1', branch: 'main' } })
  store.apply({ protocolVersion: 2, seq: 5, kind: 'mcp-servers', payload: { servers: [{ id: 'mcp-1', name: 'dsh-review' }, { id: 'mcp-2', name: 'git-commit' }] } })
  store.apply({ protocolVersion: 2, seq: 6, kind: 'host-plugins', payload: { plugins: [{ id: 'p-1', moduleName: 'dsh-review', enabled: true, fiberPhase: 'failed' }] } })
  const wide = await mountShell(store, { width: 168, height: 24 })
  await wide.renderOnce()
  const docked = wide.captureCharFrame()
  // 168 - 40 rail = 128 > 120: the sidebar docks as the right pane.
  expect(docked).toContain('context')
  expect(docked).toContain('12.3k')
  expect(docked).toContain('MCP')
  expect(docked).toContain('dsh-review')
  expect(docked).toContain('dsh:main')
  // Upstream's sidebar opens with the session title, not with a hardcoded brand.
  expect(docked).toContain('first prompt')
  expect(docked).toContain('$ 0.12')
  wide.renderer.destroy()
  // 120 - 40 = 80: the dock rule fails, so the sidebar is absent until `leader b` opens it.
  const mid = await mountShell(store, { width: 120, height: 24 })
  await mid.renderOnce()
  expect(mid.captureCharFrame()).not.toContain('▾ MCP')
  store.toggleSidebar()
  await mid.renderOnce()
  const overlay = mid.captureCharFrame()
  expect(overlay).toContain('context')
  expect(overlay).toContain('12.3k')
  store.toggleSidebar()
  await mid.renderOnce()
  expect(mid.captureCharFrame()).not.toContain('▾ MCP')
  mid.renderer.destroy()
})

test('the resize handle paints between the panes and the clamp bounds the pane width', async () => {
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'hello-ack', payload: { protocolVersion: 2, hostId: 'my-dpsk-harness-tui', hostVersion: '0.5.0', capabilities: [], status: 'compatible', reasons: [], terminalSize: { width: 168, height: 24 } } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hello' }], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  store.apply({ protocolVersion: 2, seq: 3, kind: 'session-list', payload: { sessions: [{ id: 'ses_1', title: 'first prompt', active: true }], current: 'ses_1' } })
  store.apply({ protocolVersion: 2, seq: 4, kind: 'usage', payload: { sessionId: 'ses_1', inputTokens: 12000, outputTokens: 3400, cacheReadTokens: 8000, cacheWriteTokens: 200, contextTokens: 12300, contextWindow: 131072, contextPct: 9 } })
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 168, height: 24 })
  await renderOnce()
  const frame = captureCharFrame()
  // The handle is an absolute 2-cell overlay on the seam, so neither the content column nor
  // the pane loses a cell: idle it paints nothing (upstream shows its bar only on hover or
  // while dragging), and the pane starts at `width - sidebarWidth`.
  expect(frame.split('\n')[10]!.slice(126, 127)).not.toBe('┃')
  expect(frame).toContain('context')
  // The clamp keeps the pane inside the content floor and the 24-cell minimum.
  store.resizeSidebar(200)
  expect(store.sidebarWidth()).toBe(124)
  store.resizeSidebar(10)
  expect(store.sidebarWidth()).toBe(24)
  renderer.destroy()
})


test('requestDialog sends the request and resolves when the host answers on the same sequence', async () => {
  const sent: Array<{ kind: string; payload: unknown; seq: number }> = []
  let next = 0
  const store = createAppStore((kind, payload) => {
    next += 1
    sent.push({ kind, payload, seq: next })
    return next
  })
  sessionRoute(store, 20)
  const promise = store.requestDialog('provider-form', { id: 'cliproxy' })
  expect(sent).toEqual([{ kind: 'dialog-request', payload: { kind: 'provider-form', args: { id: 'cliproxy' } }, seq: 1 }])
  store.apply({ protocolVersion: 2, seq: 9, kind: 'dialog-response', payload: { seq: 1, value: 'saved' } })
  expect(await promise).toBe('saved')
  // The answer is consumed once: a late duplicate for the same sequence resolves nothing.
  store.apply({ protocolVersion: 2, seq: 10, kind: 'dialog-response', payload: { seq: 1, value: 'again' } })
  store.apply({ protocolVersion: 2, seq: 11, kind: 'dialog-response', payload: { seq: 42, value: 'unknown' } })
  expect(store.dialogStack().length).toBe(0)
})

test('shell paints header, session, transcript, composer, notices, status', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply(ackEnvelope)
  store.apply(snapshotEnvelope)
  store.apply({ protocolVersion: 2, seq: 3, kind: 'boot-notice', payload: { kind: 'info', text: 'settings 命名空间迁移：tui → dpsk-tui' } })
  store.setComposer('/theme dark-catppuccin')

  const setup = await mountShell(store, { width: 90, height: 24 })
  await setup.renderOnce()
  const frame = setup.captureCharFrame()

  // There is no header band above the transcript: upstream opens the content column with the
  // transcript itself, so the brand and the host label are not painted here. The submitted
  // prompt is plain ink and the answer is indented markdown, both without role labels.
  expect(frame).not.toContain('my-dpsk-harness-tui 0.5.0')
  expect(frame).toContain('hello')
  expect(frame).toContain('   hi there')
  expect(frame).toContain('/theme dark-catppuccin')
  expect(frame).toContain('settings 命名空间迁移：tui → dpsk-tui')

  setup.renderer.destroy()
})

test('tool status icons, the block card, and the assistant footer paint', async () => {
  const store = createAppStore()
  store.apply(ackEnvelope)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'session',
      title: 'first prompt',
      events: [
        { id: 't1', role: 'tool', tool: 'pwsh', toolInput: { command: 'npm run check' }, toolOutput: [], status: 'pending' },
        { id: 't2', role: 'tool', tool: 'read', toolInput: { path: 'src/missing.ts' }, toolOutput: [], status: 'failed', error: 'file not found' },
        { id: 't3', role: 'tool', tool: 'write', toolInput: { path: 'src/notes.md' }, toolOutput: [], status: 'denied' },
        { id: 't4', role: 'tool', tool: 'edit', toolInput: { path: 'src/app.tsx' }, filePath: 'src/app.tsx', diff: ['- old line', '+ new line'], status: 'ok' },
        { id: 'a5', role: 'assistant', text: 'the answer', model: 'mimo-v2.6-pro', durationMs: 1200, tokPerSec: 40, footer: true, interrupted: true },
      ],
    },
  })
  const setup = await mountShell(store, { width: 120, height: 40 })
  await setup.renderOnce()
  const frame = setup.captureCharFrame()
  // The shell is upstream's `$ <command>` card: a `┃` gutter with the command line and the
  // output body. Pending swaps the `$` for a spinner, so the header is the bare command.
  expect(frame).toContain('npm run check')
  expect(frame).toContain('┃')
  // An inline row puts the 2-cell icon column before the label; the failed row paints `✗`
  // and carries the error under it.
  expect(frame).toContain('✗ Read src/missing.ts')
  expect(frame).toContain('file not found')
  // A write row is a block card headed by its path; the write content stays in the body.
  expect(frame).toContain('# Wrote src/notes.md')
  // The edit card shows the path and the +/- diff lines.
  expect(frame).toContain('src/app.tsx')
  expect(frame).toContain('- old line')
  expect(frame).toContain('+ new line')
  // The footer carries agent · model · duration · tok/s · interrupted for the assistant row.
  // No preset in this snapshot, so the footer starts at the model.\n  expect(frame).toContain('mimo-v2.6-pro · 1.2s · 40.0 tok/s · interrupted')
  setup.renderer.destroy()
})

test('the spinner advances the braille frames on the 80 ms tick', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 120, height: 24 })
  await renderOnce()
  await renderOnce()
  const idle = captureCharFrame()
  expect(idle).toContain('D:/Projects/dsh')
  expect(idle).toContain('shift+tab agents')
  // The snapshot resets the per-session state, so the running turn is reported after mount.
  store.apply({ protocolVersion: 2, seq: 1, kind: 'turn-state', payload: { sessionId: 'ses_1', running: true } })
  await renderOnce()
  const first = captureCharFrame()
  // The spinner's own tick may already have advanced past the first frame; the interrupt
  // replaces the cwd on the left while the ordinary command hint keeps the right slot.
  expect(/[⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏]/.test(first)).toBe(true)
  expect(first).toContain('esc interrupt')
  expect(first).toContain('shift+tab agents')
  expect(first).toContain('ctrl+p commands')
  expect(first).not.toContain('D:/Projects/dsh')
  const { promise: settle, resolve: settleNow } = Promise.withResolvers<void>()
  setTimeout(settleNow, 90)
  await settle
  await renderOnce()
  const second = captureCharFrame()
  expect(/[⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏]/.test(second)).toBe(true)
  expect(second).not.toBe(first)
  renderer.destroy()
})

test('the keymap table resolves each chord to its action in the active layer', () => {
  const fired: string[] = []
  let layer: 'session' | 'composer' | 'autocomplete' = 'session'
  const keymap = createKeymap(action => fired.push(action), undefined, undefined, () => layer)
  const press = (name: string, mods: { ctrl?: boolean; shift?: boolean } = {}) => {
    keymap.handle({ name, ctrl: mods.ctrl === true, shift: mods.shift === true, meta: false })
  }
  // The session layer: the escape interrupt, the tab cycle, and the model/preset cycles.
  press('escape')
  press('tab', { ctrl: true })
  press('tab', { ctrl: true, shift: true })
  press('f2')
  press('f2', { shift: true })
  press('tab', { shift: true })
  // The leader chords: `leader b` toggles the sidebar, `leader 3` picks the third tab.
  press('x', { ctrl: true })
  press('b')
  press('x', { ctrl: true })
  press('3')
  // The composer layer owns the history arrows; the autocomplete layer owns the popup keys.
  layer = 'composer'
  press('up')
  press('down')
  layer = 'autocomplete'
  press('up')
  press('n', { ctrl: true })
  press('return')
  press('escape')
  expect(fired).toEqual([
    'interrupt',
    'cycle-session',
    'cycle-session-back',
    'cycle-model',
    'cycle-model-back',
    'cycle-preset',
    'toggle-sidebar',
    'select-session-3',
    'history-prev',
    'history-next',
    'completion-prev',
    'completion-next',
    'completion-accept',
    'completion-close',
  ])
})

test('the subagent and queued docks sit above the composer without moving the prompt', async () => {
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hello' }], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh', attachmentCapabilities: { files: false, images: false } } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'subagent-list', payload: { sessionId: 'ses_1', agents: [{ label: 'explorer', provider: 'cliproxy', mode: 'one-shot' }] } })
  store.apply({ protocolVersion: 2, seq: 3, kind: 'interject-list', payload: { sessionId: 'ses_1', items: [{ id: 'queue-1', text: 'fix the tests' }, { id: 'queue-2', text: 'add the docs' }] } })
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  const frame = captureCharFrame()
  // The subagent dock is one card: its title, then one `↳` row per agent.
  expect(frame).toContain('subagents')
  expect(frame).toContain('↳ explorer · cliproxy · one-shot')
  // Authoring history and the queue are not tabs any more: history is the composer's own
  // `up`/`down`, and the queue is one line counting the pending prompts.
  expect(frame).not.toContain('history')
  expect(frame).toContain('2 queued · fix the tests')
  expect(frame).not.toContain('⏳')
  // The prompt row stays where it was: the docks took their rows from the column.
  const rows = frame.split('\n').filter(row => row.trim() !== '')
  // The metrics line is the shell's last row now; the cwd/prompt stack row is immediately
  // above it and must not move when the docks open.
  expect(rows.at(-2)).toContain('D:/Projects/dsh')
  renderer.destroy()
})

test('the popup lists workspace paths and the prompt row keeps its position', async () => {
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'command-catalog', payload: { sessionId: 'ses_1', commands: [{ name: 'permission', description: 'pick a permission preset', argumentHint: 'preset' }, { name: 'models', description: 'pick a model' }] } })
  const base = await mountShell(store, { width: 90, height: 24 })
  await base.renderOnce()
  const baseRows = base.captureCharFrame().split('\n')
  const baseFooter = baseRows.filter(row => row.trim() !== '').pop()
  // `/pe` opens the popup above the prompt; the prompt row itself does not move.
  store.setComposer('/pe')
  await base.renderOnce()
  const slashRows = base.captureCharFrame().split('\n')
  expect(slashRows.some(row => row.includes('permission'))).toBe(true)
  expect(slashRows.filter(row => row.trim() !== '').pop()).toBe(baseFooter)
  // `@tests/ipc/fix` lists the workspace paths under that directory. The host owns the
  // index; the renderer only filters the `workspace-files` list it pushed.
  store.apply({ protocolVersion: 2, seq: 3, kind: 'workspace-files', payload: { sessionId: 'ses_1', files: ['tests/ipc/fixtures/', 'tests/ipc/fixtures/basic.ndjson'] } })
  store.setComposer('@tests/ipc/fix')
  await base.renderOnce()
  const pathRows = base.captureCharFrame().split('\n')
  expect(pathRows.some(row => row.includes('@tests/ipc/fixtures/'))).toBe(true)
  expect(pathRows.filter(row => row.trim() !== '').pop()).toBe(baseFooter)
  // `tab` accepts the first match into the draft.
  store.runAction('completion-accept')
  expect(store.composer()).toBe('@tests/ipc/fixtures/')
  base.renderer.destroy()
})

test('the popup keys route through the keymap: down selects, return accepts, escape closes', async () => {
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  store.apply({ protocolVersion: 2, seq: 1, kind: 'command-catalog', payload: { sessionId: 'ses_1', commands: [{ name: 'models', description: 'pick a model' }, { name: 'models-edit', description: 'pick an edit model', argumentHint: 'model' }] } })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  await mockInput.typeText('/mo', 0)
  await renderOnce()
  // The popup owns the keyboard: `down` moves the selection to the second row.
  mockInput.pressArrow('down')
  await renderOnce()
  const rows = captureCharFrame().split('\n')
  const selected = rows.filter(row => row.includes('/models-edit')).length
  expect(selected).toBeGreaterThan(0)
  // `return` accepts the highlighted row into the draft, with the trailing space for its argument.
  mockInput.pressEnter()
  await renderOnce()
  expect(store.composer()).toBe('/models-edit ')
  // `escape` closes the popup and keeps the draft.
  store.setComposer('/mo')
  await renderOnce()
  expect(captureCharFrame()).toContain('/models-edit')
  mockInput.pressEscape()
  // The mock terminal delivers a lone ESCAPE byte after its escape-sequence timeout.
  await new Promise(resolve => setTimeout(resolve, 120))
  await renderOnce()
  expect(captureCharFrame()).not.toContain('/models-edit')
  expect(store.composer()).toBe('/mo')
  renderer.destroy()
})

test('a reasoning row starts expanded and folds on click', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply(ackEnvelope)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-snapshot',
    payload: { sessionId: 'ses_1', title: 'first prompt', events: [{ id: 'e2', role: 'assistant', text: 'the answer', reasoning: 'a thinking step', durationMs: 800 }] },
  })
  const setup = await mountShell(store, { width: 90, height: 24 })
  await setup.renderOnce()
  // The viewport settles one microtask after the first layout; a second pass paints it.
  await Bun.sleep(0)
  await setup.renderOnce()
  const frame = setup.captureCharFrame()
  // dsh defaults the reasoning block open (the user's choice; upstream hides it), so the
  // body is on screen under upstream's `- Thought` header, above the answer.
  expect(frame).toContain('- Thought')
  expect(frame).toContain('a thinking step')
  expect(frame).toContain('   the answer')
  expect(frame.indexOf('a thinking step')).toBeLessThan(frame.indexOf('   the answer'))
  // Folding keeps one row on screen: the header flips to `+` and the body is gone.
  store.toggleReasoning('e2')
  await Bun.sleep(0)
  await setup.renderOnce()
  const folded = setup.captureCharFrame()
  expect(folded).toContain('+ Thought')
  expect(folded).not.toContain('a thinking step')
  setup.renderer.destroy()
})

test('Enter sends an interjection while a turn is running, a normal send when it is not', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'turn-state', payload: { sessionId: 'ses_1', running: false } })
  store.setComposer('first')
  store.submitComposer()
  store.apply({ protocolVersion: 2, seq: 2, kind: 'turn-state', payload: { sessionId: 'ses_1', running: true } })
  store.setComposer('second')
  store.submitComposer()
  expect(sent).toEqual([
    { kind: 'send-message', payload: { sessionId: 'ses_1', text: 'first', delivery: 'steer' } },
    { kind: 'send-message', payload: { sessionId: 'ses_1', text: 'second', delivery: 'steer' } },
  ])
  expect(store.history()).toEqual(['first', 'second'])
})

test('up and down walk the submitted history when no dialog owns the keys', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.setComposer('alpha')
  store.submitComposer()
  store.setComposer('beta')
  store.submitComposer()
  store.setComposer('draft')
  store.runAction('dialog-prev')
  expect(store.composer()).toBe('beta')
  store.runAction('dialog-prev')
  expect(store.composer()).toBe('alpha')
  store.runAction('dialog-next')
  store.runAction('dialog-next')
  expect(store.composer()).toBe('draft')
  expect(store.historyIndex()).toBe(-1)
  // The history walk never sends anything upstream.
  expect(sent).toEqual([
    { kind: 'send-message', payload: { sessionId: 'ses_1', text: 'alpha', delivery: 'steer' } },
    { kind: 'send-message', payload: { sessionId: 'ses_1', text: 'beta', delivery: 'steer' } },
  ])
})

test('Alt+Up requests the exact session queue and restores returned text', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store)
  store.runAction('dialog-section-prev')
  expect(sent).toEqual([{ kind: 'interject-edit', payload: { sessionId: 'ses_1' } }])
  store.apply({ protocolVersion: 2, seq: 2, kind: 'command-result', payload: { seq: 1, ok: true, value: 'queued text' } })
  await Promise.resolve()
  expect(store.composer()).toBe('queued text')
})

test('queue management edits or deletes the selected message ID', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'interject-list',
    payload: { sessionId: 'ses_1', items: [{ id: 'q-1', text: 'first queued' }, { id: 'q-2', text: 'second queued' }] },
  })
  expect(store.interjections()).toEqual([{ id: 'q-1', text: 'first queued' }, { id: 'q-2', text: 'second queued' }])
  store.runAction('manage-queue')
  store.closeTopDialog('edit:q-2')
  expect(sent).toEqual([{ kind: 'interject-edit', payload: { sessionId: 'ses_1', id: 'q-2' } }])
  store.apply({ protocolVersion: 2, seq: 3, kind: 'command-result', payload: { seq: 1, ok: true, value: 'second queued' } })
  await Promise.resolve()
  expect(store.composer()).toBe('second queued')
  store.runAction('manage-queue')
  store.closeTopDialog('delete:q-1')
  expect(sent).toHaveLength(1)
  expect(store.dialogOpen()).toBe(true)
  store.closeTopDialog('confirm')
  expect(sent[1]).toEqual({ kind: 'interject-delete', payload: { sessionId: 'ses_1', id: 'q-1' } })
})

test('slash completion ranks the host catalog and Tab runs the accepted command', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'command-catalog',
    payload: {
      sessionId: 'ses_1',
      commands: [
        { name: 'models', description: 'list models' },
        { name: 'model', description: 'pick a model' },
        { name: 'permission', description: 'pick a permission preset' },
        { name: 'think', description: 'set effort', argumentHint: '<level>' },
      ],
    },
  })
  // An exact name wins over a longer sibling: `/model` must never accept `models`.
  store.setComposer('/model')
  expect(commandSuggestions(store.commands(), store.composer()).map(command => command.name)).toEqual(['model', 'models'])
  store.setComposer('/pe')
  expect(commandSuggestions(store.commands(), store.composer()).map(command => command.name)).toEqual(['permission'])
  store.runAction('composer-accept')
  // `/permission` is a renderer-local picker, so accepting it consumes the draft.
  expect(store.composer()).toBe('')
  expect(store.dialogStack().at(-1)?.title).toBe('permission')
  store.closeTopDialog(undefined)
  store.setComposer('/thi')
  store.runAction('composer-accept')
  // A host command that takes an argument gets the trailing space so the next keystroke
  // starts it; `think` is also local, so the dialog wins and the draft clears.
  expect(store.composer()).toBe('')
  expect(store.dialogStack().at(-1)?.title).toBe('reasoning effort')
  store.closeTopDialog(undefined)
  store.setComposer('/think high')
  expect(commandSuggestions(store.commands(), store.composer())).toEqual([])
  expect(sent).toEqual([])
})

test('the model picker lists the catalog grouped by provider and commits one selection', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'model-catalog',
    payload: {
      sessionId: 'ses_1',
      models: [
        { provider: 'cliproxy', model: 'mimo-v2.6-pro', label: 'MiMo V2.6 Pro', current: true },
        { provider: 'deepseek', model: 'dpsk-v4', label: 'Dpsk V4', current: false },
      ],
    },
  })
  store.runAction('pick-model')
  const top = store.dialogStack().at(-1)
  const options = top?.options ?? []
  expect(top?.title).toBe('Switch model')
  // One section per provider: upstream groups the model list rather than flattening it.
  expect(options.map(option => [option.title, option.category])).toEqual([
    ['MiMo V2.6 Pro', 'cliproxy'],
    ['Dpsk V4', 'deepseek'],
  ])
  expect(options[0]?.footer).toBe('current')
  expect(options[1]?.footer).toBeUndefined()
  expect(top?.current).toBe('model:cliproxy/mimo-v2.6-pro')
  store.closeTopDialog('model:deepseek/dpsk-v4')
  expect(sent).toEqual([{ kind: 'set-selection', payload: { sessionId: 'ses_1', provider: 'deepseek', model: 'dpsk-v4' } }])
})

test('cancelling the model picker writes nothing and cycles stay on F2', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'model-catalog',
    payload: {
      sessionId: 'ses_1',
      models: [
        { provider: 'cliproxy', model: 'mimo-v2.6-pro', label: 'MiMo V2.6 Pro', current: true },
        { provider: 'cliproxy', model: 'mimo-v2.6-flash', label: 'MiMo Flash', current: false },
      ],
    },
  })
  store.runAction('pick-model')
  store.closeTopDialog(undefined)
  expect(sent).toEqual([])
  // F2 is the cycle: it never opens a dialog, and it matches the live route on provider
  // and model instead of the model id alone.
  store.runAction('cycle-model')
  expect(store.dialogOpen()).toBe(false)
  expect(sent).toEqual([{ kind: 'set-selection', payload: { sessionId: 'ses_1', provider: 'cliproxy', model: 'mimo-v2.6-flash' } }])
})

test('the session strip paints the sessions and a pick sends session-op switch', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  // A session with a message is the session route; an empty one is the home landing page.
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: { sessionId: 'ses_1', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hello' }] },
  })
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-list',
    payload: {
      sessions: [
        { id: 'ses_1', title: 'first prompt', active: true },
        { id: 'ses_2', title: 'second session', active: false },
      ],
      current: 'ses_1',
    },
  })
  // The catalog is not the tab set: the renderer opens a tab per session it has visited.
  store.openTab('ses_2')
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  const frame = captureCharFrame()
  // The strip is the only session chrome: each chip leads with its 1-based number cell and
  // the add affordance closes the row as upstream's three-cell `" + "`.
  expect(frame).toContain('1 first prompt')
  expect(frame).toContain('2 second session')
  expect(frame).toContain(' + ')
  expect(store.sessions().map(session => session.id)).toEqual(['ses_1', 'ses_2'])
  // `leader l` opens the scope pick, then the scoped session rows.
  store.runAction('list-sessions')
  expect(store.dialogStack().at(-1)?.options?.map(option => option.value)).toEqual(['project', 'all'])
  store.closeTopDialog('all')
  expect(store.dialogStack().at(-1)?.options?.map(option => option.value)).toContain('ses_2')
  store.closeTopDialog('ses_2')
  expect(sent).toEqual([{ kind: 'session-op', payload: { op: 'switch', sessionId: 'ses_2' } }])
  renderer.destroy()
})

test('the session picker hides leftover blank sessions but keeps the current one', () => {
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hi' }], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' },
  })
  // Every terminal start materializes one empty session; the desktop hides them, so the
  // picker must too — otherwise the list reads as a dump of "New Session" rows and ids.
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-list',
    payload: {
      sessions: [
        { id: 'ses_1', title: 'first prompt', active: true, workspace: 'D:/Projects/dsh', createdAt: 3, status: 'idle', attention: false },
        { id: 'tui-blank', title: '', active: false, workspace: 'D:/Projects/dsh', createdAt: 2, status: 'idle', attention: false, blank: true },
        { id: 'tui-gone', title: '', active: false, workspace: 'D:/Projects/dsh', createdAt: 1, status: 'idle', attention: false, blank: true },
      ],
      current: 'ses_1',
    },
  })
  store.runAction('list-sessions')
  expect(store.dialogStack().at(-1)?.options?.find(option => option.value === 'all')?.description).toBe('1 sessions')
  store.closeTopDialog('all')
  expect(store.dialogStack().at(-1)?.options?.map(option => option.value)).toEqual(['ses_1'])
})

test('a blank session that is current is hidden too', () => {
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: { sessionId: 'tui-now', initialRoute: 'home', title: '', events: [], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' },
  })
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-list',
    payload: {
      sessions: [
        { id: 'tui-now', title: '', active: true, workspace: 'D:/Projects/dsh', createdAt: 2, status: 'idle', attention: false, blank: true },
        { id: 'tui-gone', title: '', active: false, workspace: 'D:/Projects/dsh', createdAt: 1, status: 'idle', attention: false, blank: true },
      ],
      current: 'tui-now',
    },
  })
  store.runAction('list-sessions')
  expect(store.dialogStack().at(-1)?.options?.find(option => option.value === 'all')?.description).toBe('0 sessions')
  store.closeTopDialog('all')
  expect(store.dialogStack().at(-1)?.options?.map(option => option.value)).toEqual([])
})

test('Tab accepts a mention path into the draft, keeping the text before it', () => {
  const dir = mkdtempSync(join(tmpdir(), 'dpsk-mention-'))
  mkdirSync(join(dir, 'src'), { recursive: true })
  writeFileSync(join(dir, 'src', 'notes.md'), '')
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'session', title: 'first prompt', events: [],
      provider: 'cliproxy', model: 'mimo', effort: 'high', permission: 'auto', preset: 'standard',
      workspace: dir,
    },
  })
  expect(store.workspace()).toBe(dir)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'workspace-files', payload: { sessionId: 'ses_1', files: ['src/', 'src/notes.md'] } })
  store.setComposer('read @src/n')
  store.runAction('composer-accept')
  expect(store.composer()).toBe('read @src/notes.md')
  rmSync(dir, { recursive: true, force: true })
})

test('the composer paints the mention list under the draft', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'dpsk-mention-'))
  mkdirSync(join(dir, 'src'), { recursive: true })
  writeFileSync(join(dir, 'src', 'notes.md'), '')
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'session', title: 'first prompt', events: [],
      provider: 'cliproxy', model: 'mimo', effort: 'high', permission: 'auto', preset: 'standard',
      workspace: dir,
    },
  })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'workspace-files', payload: { sessionId: 'ses_1', files: ['src/', 'src/notes.md'] } })
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  store.setComposer('@src/n')
  await renderOnce()
  expect(captureCharFrame()).toContain('@src/notes.md')
  rmSync(dir, { recursive: true, force: true })
  renderer.destroy()
})

test('/settings opens the settings page locally without sending anything upstream', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'settings',
    payload: { schemaVersion: 2, values: { showReasoning: true, maxToolOutputLines: 5 } },
  })
  store.setComposer('/settings')
  store.submitComposer()
  expect(sent).toEqual([])
  expect(store.dialogOpen()).toBe(true)
  expect(store.dialogStack().at(-1)?.title).toBe('settings')
  // The draft is cleared, so the page opens without leaving the command in the composer.
  expect(store.composer()).toBe('')
})

test('picking a settings field writes it through update-settings', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'settings', payload: { schemaVersion: 2, values: { showReasoning: true } } })
  store.setComposer('/settings')
  store.submitComposer()
  store.closeTopDialog('setting:showReasoning')
  // The field opens its own picker; picking `hide` writes the field.
  expect(store.dialogStack().at(-1)?.title).toBe('show reasoning blocks')
  store.closeTopDialog('false')
  expect(sent).toEqual([{ kind: 'update-settings', payload: { requestId: expect.any(String), patch: { showReasoning: false } } }])
  expect(store.settings().showReasoning).toBe(false)
})

test('newDesigns toggles the transcript setting without touching the theme', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'settings',
    payload: { schemaVersion: 2, values: { newDesigns: false, themeName: 'opencode2', themeMode: 'dark' } },
  })
  store.setComposer('/settings')
  store.submitComposer()
  const page = store.dialogStack().at(-1)
  expect(page?.options?.find(option => option.value === 'setting:newDesigns')?.title).toBe('new thinking style: off')
  store.closeTopDialog('setting:newDesigns')
  expect(sent).toEqual([{
    kind: 'update-settings',
    payload: { requestId: expect.any(String), patch: { newDesigns: true } },
  }])
  expect(store.settings().newDesigns).toBe(true)
  // The switch is not coupled to the theme: `opencode2` remains selected.
  expect(store.settings().themeName).toBe('opencode2')
  expect(store.settings().themeMode).toBe('dark')
})
test('path display switches between ~ and full without changing the workspace', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  const cwd = join(homedir(), 'Projects', 'dsh')
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'path test', events: [{ id: 'e1', role: 'user', text: 'hi' }], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: cwd },
  })
  expect(store.displayPath(store.workspace())).toBe('~/Projects/dsh')
  store.setComposer('/settings')
  store.submitComposer()
  const page = store.dialogStack().at(-1)
  expect(page?.options?.find(option => option.value === 'setting:pathDisplay')?.title).toBe('path display: ~ abbreviated')
  store.closeTopDialog('setting:pathDisplay')
  expect(store.dialogStack().at(-1)?.options?.map(option => option.value)).toEqual(['tilde', 'full'])
  store.closeTopDialog('full')
  expect(sent).toEqual([{
    kind: 'update-settings',
    payload: { requestId: expect.any(String), patch: { pathDisplay: 'full' } },
  }])
  expect(store.pathDisplayMode()).toBe('full')
  expect(store.displayPath(store.workspace())).toBe(cwd)
  // The switch is display-only: the host still receives the absolute workspace.
  expect(store.workspace()).toBe(cwd)
})

test('a prompt settings field validates its answer before writing', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'settings', payload: { schemaVersion: 2, values: { maxToolOutputLines: 5 } } })
  store.setComposer('/settings')
  store.submitComposer()
  store.closeTopDialog('setting:maxToolOutputLines')
  store.closeTopDialog('not a number')
  expect(sent).toEqual([])
  // The invalid answer closed the prompt, so the page is opened again.
  store.setComposer('/settings')
  store.submitComposer()
  store.closeTopDialog('setting:maxToolOutputLines')
  store.closeTopDialog('7.9')
  expect(sent).toEqual([{ kind: 'update-settings', payload: { requestId: expect.any(String), patch: { maxToolOutputLines: 7 } } }])
})

test('/theme opens the native picker without asking the host for a palette', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.setComposer('/theme')
  store.submitComposer()
  // The renderer owns the catalog; with no provider mounted (a bare store) the picker is
  // simply not offered, and the host never receives a theme request.
  expect(sent).toEqual([])
})

test('the shell paints the host dictionary labels with English fallback', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'i18n',
    payload: { locale: 'zh-CN', strings: { rendererSession: '会话: ', rendererPlaceholder: '提示词，/命令，Ctrl+P 面板', rendererInterrupt: 'esc 中断' } },
  })
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-snapshot',
    payload: { sessionId: 'ses_1', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hello' }], provider: 'p', model: 'm', effort: 'e', permission: 'p', preset: 's' },
  })
  store.apply({ protocolVersion: 2, seq: 3, kind: 'turn-state', payload: { sessionId: 'ses_1', running: true } })
  expect(store.locale()).toBe('zh-CN')
  expect(store.label('rendererSession', 'session: ')).toBe('会话: ')
  // A key the dictionary does not carry falls back to the label the shell ships with.
  expect(store.label('rendererWechat', 'wechat: ')).toBe('wechat: ')
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  const frame = captureCharFrame()
  // The composer placeholder and the running footer's interrupt hint follow the dictionary.
  // There is no session label row any more — the tab chip carries the title — so the key is
  // still forwarded for `/details` without appearing in the frame.
  expect(frame).toContain('提示词，/命令，Ctrl+P 面板')
  expect(frame).toContain('esc 中断')
  expect(frame).not.toContain('输入: ')
  renderer.destroy()
})

test('the WeChat scan block and bridge status live in the sidebar, never in the status bar', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 9)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'wechat-output', payload: { kind: 'qr', text: '▄▀█▀▄\n█▀█▀█' } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'wechat-output', payload: { kind: 'status', text: 'paired: 2 accounts', status: { available: true, connected: true, accounts: { connected: 2, total: 2 }, lock: { held: true } } } })
  store.apply({ protocolVersion: 2, seq: 3, kind: 'wechat-output', payload: { kind: 'log', text: 'monitor started' } })
  store.apply({ protocolVersion: 2, seq: 4, kind: 'wechat-output', payload: { kind: 'error', text: 'login refused' } })
  expect(store.wechatQr()).toBe('▄▀█▀▄\n█▀█▀█')
  expect(store.wechatStatus()).toBe('paired: 2 accounts')
  // Bridge logs and errors land as toasts; the QR block and the status line are their own
  // signals, so a new login replaces the scan without touching the toast queue. Upstream
  // shows one toast and replaces it when nothing is queued behind it.
  expect(store.toast()?.text).toBe('login refused')
  expect(store.toast()?.level).toBe('error')
  expect(store.pendingToasts()).toBe(0)
  // Closed sidebar: the bridge paints nowhere in the column, and the bar keeps its two rows.
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  const closed = painted(captureCharFrame())
  expect(closed.join('\n')).not.toContain('paired: 2 accounts')
  expect(closed.join('\n')).not.toContain('▄▀█▀▄')
  expect(closed.length).toBe(24)
  // Open sidebar: the QR and the status are rows of the pane, which scrolls with its body.
  store.toggleSidebar()
  await renderOnce()
  const open = captureCharFrame()
  expect(open).toContain('▄▀█▀▄')
  // The pane paints the structured state on its own rows instead of the pre-joined line.
  expect(open).toContain('connected (2/2)')
  expect(open).toContain('lock: this process')
  expect(open).toContain('wechat')
  renderer.destroy()
})

test('/doctor asks the host and the report opens an alert on the matching seq', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.setComposer('/doctor')
  store.submitComposer()
  expect(sent).toEqual([{ kind: 'doctor-check', payload: { op: 'doctor' } }])
  // A result for a request the renderer no longer cares about must not pop an alert.
  store.apply({ protocolVersion: 2, seq: 9, kind: 'command-result', payload: { seq: 42, ok: true, text: 'stale' } })
  expect(store.dialogOpen()).toBe(false)
  store.apply({ protocolVersion: 2, seq: 10, kind: 'command-result', payload: { seq: 1, ok: true, text: 'self-check: ok' } })
  expect(store.dialogOpen()).toBe(true)
  expect(store.dialogStack().at(-1)?.title).toBe('doctor')
  store.closeTopDialog(undefined)
  // The answer is consumed: the same seq does not open a second alert.
  store.apply({ protocolVersion: 2, seq: 11, kind: 'command-result', payload: { seq: 1, ok: true, text: 'again' } })
  expect(store.dialogOpen()).toBe(false)
})

test('/plugins sends the plugins request and an error result shows the error text', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.setComposer('/plugins')
  store.submitComposer()
  expect(sent).toEqual([{ kind: 'doctor-check', payload: { op: 'plugins' } }])
  store.apply({ protocolVersion: 2, seq: 2, kind: 'command-result', payload: { seq: 1, ok: false, error: 'host gone' } })
  expect(store.dialogStack().at(-1)?.title).toBe('plugins')
})

test('a slash argument popup lists host values and the accept replaces only the argument', async () => {
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'command-catalog', payload: { sessionId: 'ses_1', commands: [{ name: 'think', description: 'set effort', argumentHint: '<level>' }] } })
  store.apply({ protocolVersion: 2, seq: 3, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [], provider: 'cliproxy', model: 'mimo', effort: 'low', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'reasoning-efforts', payload: { sessionId: 'ses_1', efforts: ['off', 'low', 'medium', 'high'], current: 'low' } })
  store.setComposer('/think hi')
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  // The popup carries the matching value; an argument row has no kind column to mark
  // (opencode's popup labels only the `@` reference rows).
  const frame = captureCharFrame()
  expect(frame).toContain('high')
  expect(frame).not.toContain('argument')
  // Accepting keeps the command and replaces the trailing token.
  store.runAction('completion-accept')
  expect(store.composer()).toBe('/think high')
  renderer.destroy()
})

test('the bare command pickers open for effort, permission, and mode', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  // The picker rows read the catalogs; the snapshot supplies the live route the dialogs mark.
  store.apply({ protocolVersion: 2, seq: 1, kind: 'reasoning-efforts', payload: { sessionId: 'ses_1', efforts: ['off', 'high'], current: 'high' } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'permission-presets', payload: { sessionId: 'ses_1', presets: [{ id: 'full-access', label: 'full access', current: true }] } })
  store.apply({ protocolVersion: 2, seq: 3, kind: 'agent-presets', payload: { sessionId: 'ses_1', presets: [{ id: 'code', label: 'code', current: true }] } })
  store.apply({ protocolVersion: 2, seq: 4, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [], provider: 'cliproxy', model: 'mimo', effort: 'high', permission: 'full-access', preset: 'code', workspace: 'D:/Projects/dsh' } })
  store.setComposer('/think')
  store.submitComposer()
  // The bare command opens a picker instead of being sent upstream.
  expect(sent).toEqual([])
  expect(store.dialogOpen()).toBe(true)
  store.closeTopDialog('effort:off')
  expect(sent).toEqual([{ kind: 'set-selection', payload: { sessionId: 'ses_1', effort: 'off' } }])
  store.setComposer('/permission')
  store.submitComposer()
  store.closeTopDialog('permission:full-access')
  store.setComposer('/mode')
  store.submitComposer()
  store.closeTopDialog('mode:code')
  expect(sent.slice(1)).toEqual([
    { kind: 'set-selection', payload: { sessionId: 'ses_1', permission: 'full-access' } },
    { kind: 'set-selection', payload: { sessionId: 'ses_1', preset: 'code' } },
  ])
})

test('a command with arguments still goes upstream instead of opening the picker', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  for (const line of ['/resume ses_42', '/think high', '/permission full-access', '/mode code']) {
    store.setComposer(line)
    store.submitComposer()
    expect(store.dialogOpen()).toBe(false)
  }
  expect(sent.map(entry => (entry.payload as { text?: string }).text)).toEqual([
    '/resume ses_42',
    '/think high',
    '/permission full-access',
    '/mode code',
  ])
})

test('an empty session is the home route; the first message flips to the session route', async () => {
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'hello-ack', payload: { protocolVersion: 2, hostId: 'my-dpsk-harness-tui', hostVersion: '0.5.0', capabilities: [], status: 'compatible', reasons: [] } })
  // The host reports a resume as the session route; a fresh start reports Home.
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-list', payload: { sessions: [], current: '' } })
  store.apply({ protocolVersion: 2, seq: 3, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'home', title: 'first prompt', events: [], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  store.apply({ protocolVersion: 2, seq: 4, kind: 'mcp-servers', payload: { servers: [{ id: 'mcp-1', name: 'dsh-review' }] } })
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 100, height: 30 })
  await renderOnce()
  const home = captureCharFrame()
  const rows = painted(home)
  // The landing page: the wordmark centred, the prompt under it, and only the metrics row on
  // the frame's bottom edge. There is no tab strip, no session header, and no build/MCP footer
  // row: that information lives in the sidebar.
  expect(home).toContain('Ask anything')
  expect(home).toContain('shift+tab agents')
  expect(home).toContain('D:/Projects/dsh')
  expect(home).not.toContain('session:  first prompt')
  expect(home).not.toContain(' + ')
  expect(home).not.toContain('⊙ 1 MCP')
  expect(home).not.toContain('0.5.0')
  // The wordmark is the `block` font's half-block art, so the assertion is the glyph row
  // count: the lockup sits above the prompt.
  const logoRow = rows.findIndex(row => /[█▀▄]/.test(row))
  const promptRow = rows.findIndex(row => row.includes('Ask anything'))
  expect(logoRow).toBeGreaterThan(-1)
  expect(promptRow).toBeGreaterThan(logoRow)
  // The cwd row rides the prompt: it is the row under the panel's shadow lip, not the
  // second-to-last row of the frame.
  const lipRow = rows.findLastIndex(row => row.includes('▀'))
  expect(rows[lipRow + 1]).toContain('D:/Projects/dsh')
  expect(rows.at(-2)).not.toContain('D:/Projects/dsh')
  expect(rows.length).toBe(30)
  // The build stamp and the MCP inventory are sidebar rows, not landing chrome.
  store.toggleSidebar()
  await renderOnce()
  const withSidebar = captureCharFrame()
  expect(withSidebar).toContain('0.5.0')
  expect(withSidebar).toContain('dsh-review')
  store.toggleSidebar()
  await renderOnce()

  // The first send creates the Session and flips the route: the host answers the
  // `session-op new` with its id, then the transcript arrives on that session.
  store.setComposer('hello')
  store.submitComposer()
  // The optimistic route is the new Session: the renderer paints its prompt and waits
  // for the host's `session-op` answer before it sends the message.
  expect(store.route()).toBe('session')
  store.apply({ protocolVersion: 2, seq: 6, kind: 'session-frame', payload: { sessionId: store.currentSession(), events: [{ id: 'e1', role: 'user', text: 'hello' }] } })
  await renderOnce()
  const session = captureCharFrame()
  expect(session).toContain('hello')
  expect(session).not.toContain('Ask anything')
  renderer.destroy()
})

test('a user row with attachments paints the durable references and asks the host to read one', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  const attachment = { type: 'image' as const, attachmentId: 'att-1', name: 'shot.png', mediaType: 'image/png' }
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-frame',
    payload: { sessionId: 'ses_1', events: [{ id: 'u2', role: 'user', text: 'look', attachments: [attachment] }] },
  })
  expect(store.transcript().at(-1)?.attachments).toEqual([attachment])
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  // The row names the attachment instead of inventing bytes; opening it goes upstream.
  expect(captureCharFrame()).toContain('shot.png')
  // The read request is awaited inside `openAttachment`; resolve its `command-result`
  // first, then the failure surfaces as a notice instead of a resolved preview.
  const readSeq = sent.length + 1
  const opening = store.openAttachment(attachment)
  await Bun.sleep(0)
  expect(sent.at(-1)).toEqual({ kind: 'attachment-read', payload: { sessionId: 'ses_1', attachment } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'command-result', payload: { seq: readSeq, ok: false, error: 'attachment exceeds the 20 MiB read limit' } })
  await opening
  await renderOnce()
  expect(store.toast()?.text).toContain('20 MiB')
  renderer.destroy()
})

test('shell jobs list, read output, and stop through the host command seam', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hello' }], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh', availableActions: ['shell.jobs'] } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'shell-jobs', payload: { sessionId: 'ses_1', jobs: [{ id: 'job-1', kind: 'bash', label: 'npm run check', owner: 'ses_1', status: 'running', startedAt: 1, output: { total: 42, earliest: 0 } }] } })
  expect(store.shellJobs()).toHaveLength(1)
  // The palette entry the host advertised opens the job list; the row carries both the
  // output reader and the stop action, keyed by the real job id.
  store.runAction('palette')
  store.closeTopDialog('action:show-shell-jobs')
  expect(store.dialogOpen()).toBe(true)
  // Picking the row swaps the list for the output dialog carrying the exact job and
  // session; the dialog itself issues `shell-job-op read` from its first mount.
  store.closeTopDialog('read:job-1')
  const outputSpec = store.dialogStack().at(-1)
  expect(outputSpec?.kind).toBe('shell-output')
  expect(outputSpec?.job?.id).toBe('job-1')
  expect(outputSpec?.sessionId).toBe('ses_1')
  // A job that leaves the host list has ended; the signal follows the host, not a guess.
  store.apply({ protocolVersion: 2, seq: 3, kind: 'shell-jobs', payload: { sessionId: 'ses_1', jobs: [] } })
  expect(store.shellJobs()).toHaveLength(0)
  store.closeTopDialog(undefined)
})

test('the terminal pane follows, writes, resizes over terminal-op and paints its screen', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hello' }], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh', availableActions: ['terminal.toggle', 'terminal.select', 'terminal.close'] } })
  const info = { id: 'term-1', title: 'shell', shell: { path: '/bin/bash', args: [], name: 'bash' }, cwd: 'D:/Projects/dsh', cols: 40, rows: 10, state: 'running' as const, exitCode: null, controllerId: 'ctl-1' }
  // `list` answers with no terminals, so the renderer creates one instead of inventing a pane.
  store.runAction('terminal.toggle')
  const list = sent.at(-1)
  expect(list?.kind).toBe('terminal-op')
  expect(list?.payload).toEqual({ sessionId: 'ses_1', op: 'list' })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'command-result', payload: { seq: 1, ok: true, value: { terminals: [], environment: { cwd: 'D:/Projects/dsh', maxInputBytes: 65536, maxCols: 200, maxRows: 60, scrollback: 1000 } } } })
  await Promise.resolve()
  const create = sent.at(-1)
  expect(create?.kind).toBe('terminal-op')
  expect((create?.payload as { op: string }).op).toBe('create')
  store.apply({ protocolVersion: 2, seq: 3, kind: 'command-result', payload: { seq: sent.length, ok: true, value: info } })
  await Promise.resolve()
  // The activation retains the window for this attachment and opens the pane.
  const retain = sent.at(-1)
  expect(retain?.payload).toMatchObject({ sessionId: 'ses_1', op: 'retain', id: 'term-1' })
  expect(store.terminalOpen()).toBe(true)
  expect(store.terminalAttachmentId()).not.toBe('')
  const attachment = store.terminalAttachmentId()
  store.apply({ protocolVersion: 2, seq: 4, kind: 'terminal-frame', payload: { sessionId: 'ses_1', id: 'term-1', attachmentId: attachment, frame: { type: 'snapshot', sequence: 1, screen: '$ ready\r\n', info } } })
  expect(store.terminalFrames()).toHaveLength(1)
  // A frame for another attachment is not this window's screen.
  store.apply({ protocolVersion: 2, seq: 5, kind: 'terminal-frame', payload: { sessionId: 'ses_1', id: 'term-1', attachmentId: 'other', frame: { type: 'output', sequence: 2, data: 'x' } } })
  expect(store.terminalFrames()).toHaveLength(1)
  store.apply({ protocolVersion: 2, seq: 6, kind: 'terminal-end', payload: { sessionId: 'ses_1', id: 'term-1', attachmentId: attachment, error: 'stream failed' } })
  expect(store.terminalEndError()).toBe('stream failed')
})

test('/mcps lists the real server names and shows the native empty states', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  // No servers advertised: the list says so instead of inventing a connected count.
  store.setComposer('/mcps')
  store.submitComposer()
  expect(store.dialogStack().at(-1)?.title).toBe('MCP servers')
  expect(store.dialogStack().at(-1)?.options).toEqual([])
  store.closeTopDialog(undefined)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'mcp-servers', payload: { servers: [{ id: 'mcp-2', name: 'git-commit' }, { id: 'mcp-1', name: 'dsh-review' }] } })
  store.setComposer('/mcps')
  store.submitComposer()
  const options = store.dialogStack().at(-1)?.options ?? []
  // The host owns the order (sorted by name) and the id; the row shows the name only.
  expect(options.map(option => option.title)).toEqual(['git-commit', 'dsh-review'])
  expect(options.map(option => option.value)).toEqual(['mcp-2', 'mcp-1'])
  store.closeTopDialog(undefined)
})

test('/plugins asks the host for its own report and paints it as an alert', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.setComposer('/plugins')
  store.submitComposer()
  expect(sent.at(-1)).toEqual({ kind: 'doctor-check', payload: { op: 'plugins' } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'command-result', payload: { seq: 1, ok: true, text: 'self-check: ok\nadmissions: 1' } })
  await Promise.resolve()
  expect(store.dialogStack().at(-1)?.kind).toBe('alert')
  expect(store.dialogStack().at(-1)?.message).toContain('self-check: ok')
  store.closeTopDialog(undefined)
})

test('showReasoning is the fold default, and a per-row flip survives it', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'settings', payload: { schemaVersion: 2, values: { showReasoning: false } } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-frame', payload: { sessionId: 'ses_1', events: [{ id: 'a1', role: 'assistant', text: 'the answer', reasoning: 'a thinking step', durationMs: 800 }] } })
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 100, height: 24 })
  await renderOnce()
  // `session.thinking = "hide"` folds the body: the header line stays, the text does not.
  expect(captureCharFrame()).toContain('Thought')
  expect(captureCharFrame()).not.toContain('a thinking step')
  store.toggleReasoning('a1')
  await renderOnce()
  expect(captureCharFrame()).toContain('a thinking step')
  renderer.destroy()
})

test('ctrl+c clears the draft, then closes a dialog, and exits only from an empty prompt', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.setComposer('half-typed')
  store.runAction('cancel')
  // First press: the draft goes, nothing exits, nothing asks the host.
  expect(store.composer()).toBe('')
  expect(sent).toEqual([])
  store.runAction('palette')
  expect(store.dialogOpen()).toBe(true)
  store.runAction('cancel')
  expect(store.dialogOpen()).toBe(false)
  expect(sent).toEqual([])
  store.runAction('cancel')
  expect(sent).toEqual([{ kind: 'bye', payload: { reason: 'renderer ctrl+c' } }])
})

test('the keymap consumes ctrl+c and reports whether a key was handled', () => {
  const fired: string[] = []
  const keymap = createKeymap(action => fired.push(action))
  expect(keymap.handle({ name: 'c', ctrl: true, shift: false, meta: false })).toBe(true)
  expect(keymap.handle({ name: 'z', ctrl: false, shift: false, meta: false })).toBe(false)
  expect(fired).toEqual(['cancel'])
})

test('attention follows the focus policy and reports why it skipped', async () => {
  const events: Array<{ title: string | undefined; message: string }> = []
  const listeners = new Map<string, Set<() => void>>()
  const renderer = {
    isDestroyed: false,
    on: (event: 'focus' | 'blur', listener: () => void) => {
      const set = listeners.get(event) ?? new Set()
      set.add(listener)
      listeners.set(event, set)
      return undefined
    },
    off: (event: 'focus' | 'blur', listener: () => void) => {
      listeners.get(event)?.delete(listener)
      return undefined
    },
    triggerNotification: (message: string, title?: string) => {
      events.push({ title, message })
      return true
    },
  }
  const fire = (event: 'focus' | 'blur'): void => {
    for (const listener of listeners.get(event) ?? []) listener()
  }
  const attention = createTuiAttention({
    renderer,
    config: { notifications: true, sound: false, volume: 0.4, sounds: {} },
    audio: { loadSoundFile: async () => null, play: () => null },
  })
  // Before the terminal reports focus, a `blurred` request still fires (see the module note);
  // only `focused` is suppressed while the state is unknown.
  expect((await attention.notify({ message: 'turn finished', notification: { when: 'focused' } })).skipped).toBe('focus_unknown')
  fire('blur')
  const fired = await attention.notify({ title: 'deepseek', message: 'turn finished' })
  expect(fired.ok).toBe(true)
  expect(events).toEqual([{ title: 'deepseek', message: 'turn finished' }])
  fire('focus')
  expect((await attention.notify({ message: 'turn finished' })).skipped).toBe('focused')
  // An explicit `always` ignores focus; a disabled config reports itself, and an empty
  // message never reaches the notification call.
  expect((await attention.notify({ message: 'always', notification: { when: 'always' } })).ok).toBe(true)
  const disabled = createTuiAttention({ renderer, config: { notifications: false, sound: false, volume: 0.4, sounds: {} } })
  expect((await disabled.notify({ message: 'x' })).skipped).toBe('attention_disabled')
  disabled.dispose()
  expect((await attention.notify({ message: '   ' })).skipped).toBe('empty_message')
  attention.dispose()
  expect((await attention.notify({ message: 'after dispose' })).skipped).toBe('renderer_destroyed')
  expect(listeners.get('blur')?.size).toBe(0)
})

test('a running turn that goes idle notifies once and a replay does not', async () => {
  const notified: string[] = []
  const store = createAppStore()
  sessionRoute(store, 20)
  store.setAttention(createTuiAttention({
    renderer: { isDestroyed: false, on: () => undefined, off: () => undefined, triggerNotification: message => { notified.push(message); return true } },
    config: { notifications: true, sound: false, volume: 0.4, sounds: {} },
  }))
  store.apply({ protocolVersion: 2, seq: 2, kind: 'turn-state', payload: { sessionId: 'ses_1', running: true } })
  // A replayed snapshot that still says "running" must not fire anything.
  store.apply({ protocolVersion: 2, seq: 3, kind: 'turn-state', payload: { sessionId: 'ses_1', running: true } })
  expect(notified).toEqual([])
  store.apply({ protocolVersion: 2, seq: 4, kind: 'turn-state', payload: { sessionId: 'ses_1', running: false } })
  await Promise.resolve()
  await Promise.resolve()
  expect(notified).toEqual(['first prompt'])
  // Another idle frame is not a transition, so it stays silent.
  store.apply({ protocolVersion: 2, seq: 5, kind: 'turn-state', payload: { sessionId: 'ses_1', running: false } })
  await Promise.resolve()
  expect(notified).toEqual(['first prompt'])
  store.setAttention(undefined)
})

test('leader y copies the newest answer through the clipboard service', async () => {
  const written: string[] = []
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 3, kind: 'session-frame', payload: { sessionId: 'ses_1', events: [{ id: 'a1', role: 'assistant', text: 'the answer' }] } })
  store.setClipboard({ read: async () => undefined, write: async text => { written.push(text) }, dispose: async () => undefined })
  store.runAction('copy-message')
  await Promise.resolve()
  await Promise.resolve()
  expect(written).toEqual(['the answer'])
  expect(store.toast()?.text).toBe('Copied the last message')
  // With nothing to copy the action reports it instead of writing an empty clipboard.
  const empty = createAppStore()
  sessionRoute(empty, 20)
  empty.setClipboard({ read: async () => undefined, write: async text => { written.push(text) }, dispose: async () => undefined })
  empty.runAction('copy-message')
  expect(empty.toast()).toMatchObject({ level: 'warning', text: 'No assistant message to copy' })
  expect(written).toEqual(['the answer'])
})

test('ctrl+v pastes clipboard text or an image attachment', async () => {
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hello' }], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh', attachmentCapabilities: { files: true, images: true } } })
  let next: { data: string; mime: string } | undefined = { data: 'pasted words', mime: 'text/plain' }
  store.setClipboard({ read: async () => next, write: async () => undefined, dispose: async () => undefined })
  store.setComposer('before ')
  store.runAction('paste-clipboard')
  await Promise.resolve()
  await Promise.resolve()
  expect(store.composer()).toBe('before pasted words')
  // An image lands as a pending attachment, not as base64 text in the draft.
  next = { data: Buffer.from('png-bytes').toString('base64'), mime: 'image/png' }
  store.runAction('paste-clipboard')
  await Promise.resolve()
  await Promise.resolve()
  const attachments = store.pendingAttachmentsForCurrent()
  expect(attachments).toHaveLength(1)
  expect(attachments[0]?.submitted).toMatchObject({ type: 'image', mediaType: 'image/png' })
})

test('submitted prompts are persisted and deduplicated back into the history list', async () => {
  const { createLocalStorage } = await import('./storage.ts')
  const { mkdtempSync, rmSync } = await import('node:fs')
  const { tmpdir } = await import('node:os')
  const { join } = await import('node:path')
  const root = mkdtempSync(join(tmpdir(), 'dpsk-history-'))
  const storage = createLocalStorage(root)
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.setLocalStorage(storage)
  store.setComposer('first prompt')
  store.submitComposer()
  await Promise.resolve()
  store.setComposer('second prompt')
  store.submitComposer()
  await Promise.resolve()
  store.setComposer('first prompt')
  store.submitComposer()
  await storage.flush()
  expect((await storage.readHistory<{ text: string }>()).map(entry => entry.text)).toEqual(['first prompt', 'second prompt', 'first prompt'])
  // A fresh shell loads the file: the repeated line moves to the end, the list is unique.
  const reloaded = createAppStore()
  sessionRoute(reloaded, 20)
  reloaded.setLocalStorage(createLocalStorage(root))
  await reloaded.loadHistory()
  expect(reloaded.history()).toEqual(['second prompt', 'first prompt'])
  rmSync(root, { recursive: true, force: true })
})

test('session drafts survive a renderer restart', async () => {
  const { createLocalStorage } = await import('./storage.ts')
  const { mkdtempSync, rmSync } = await import('node:fs')
  const { tmpdir } = await import('node:os')
  const { join } = await import('node:path')
  const root = mkdtempSync(join(tmpdir(), 'dpsk-drafts-'))
  const storage = createLocalStorage(root)
  const first = createAppStore()
  sessionRoute(first, 20)
  first.setLocalStorage(storage)
  first.setComposer('keep this draft')
  await Bun.sleep(220)
  await storage.flush()
  const second = createAppStore()
  sessionRoute(second, 20)
  const reloadStorage = createLocalStorage(root)
  second.setLocalStorage(reloadStorage)
  expect(second.route()).toBe('session')
  expect(second.currentSession()).toBe('ses_1')
  expect(await reloadStorage.read('drafts')).toMatchObject({ sessions: { ses_1: 'keep this draft' } })
  await second.loadDrafts()
  expect(second.composer()).toBe('keep this draft')
  rmSync(root, { recursive: true, force: true })
})

test('closing and reopening a tab follows upstream order, and closing the last one goes Home', async () => {
  const { createLocalStorage } = await import('./storage.ts')
  const { mkdtempSync, rmSync } = await import('node:fs')
  const { tmpdir } = await import('node:os')
  const { join } = await import('node:path')
  const root = mkdtempSync(join(tmpdir(), 'dpsk-tabs-'))
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 1)
  store.setLocalStorage(createLocalStorage(root))
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-list', payload: { sessions: [{ id: 'ses_2', title: 'second', active: false }], current: 'ses_1' } })
  store.openTab('ses_2')
  expect(store.openTabs()).toEqual(['ses_1', 'ses_2'])
  // Closing the current tab selects its right neighbour through the host's switch.
  store.closeSessionTab()
  expect(store.openTabs()).toEqual(['ses_2'])
  expect(sent.at(-1)).toEqual({ kind: 'session-op', payload: { op: 'switch', sessionId: 'ses_2' } })
  // Reopen restores it at its original index.
  store.reopenSessionTab()
  expect(store.openTabs()).toEqual(['ses_1', 'ses_2'])
  // The host follows the switch with a snapshot; the store's current session moves with it.
  const switchTo = (sessionId: string): void => {
    store.apply({ protocolVersion: 2, seq: 10, kind: 'session-snapshot', payload: { sessionId, initialRoute: 'session', title: sessionId, events: [{ id: `e-${sessionId}`, role: 'user', text: 'hi' }], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } })
  }
  switchTo('ses_2')
  // The reopened tab is current, so closing it drops that one and leaves the other.
  expect(store.openTabs()).toEqual(['ses_1', 'ses_2'])
  store.closeSessionTab()
  expect(store.openTabs()).toEqual(['ses_1'])
  // The host's switch is followed by a snapshot, which is what makes `ses_1` current; then
  // closing the last tab leaves Home without another session request.
  switchTo('ses_1')
  store.closeSessionTab()
  expect(store.openTabs()).toEqual([])
  // The last tab closing leaves Home. Every switch above asked the host for a tab that was
  // still open; nothing is requested for a tab that is gone.
  expect(store.route()).toBe('home')
  expect(sent.filter(entry => entry.kind === 'session-op').map(entry => (entry.payload as { sessionId: string }).sessionId)).toEqual(['ses_2', 'ses_1', 'ses_1'])
  rmSync(root, { recursive: true, force: true })
})

test('the tab menu closes others and moves a tab without switching sessions', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 2)
  store.apply({
    protocolVersion: 2,
    seq: 3,
    kind: 'session-list',
    payload: {
      sessions: [
        { id: 'ses_1', title: 'first', active: true },
        { id: 'ses_3', title: 'third', active: false },
      ],
      current: 'ses_1',
    },
  })
  store.openTab('ses_3')
  expect(store.openTabs()).toEqual(['ses_1', 'ses_3'])
  store.moveTab('ses_3', -1)
  expect(store.openTabs()).toEqual(['ses_3', 'ses_1'])
  // Moving is local: no host request.
  expect(sent.some(entry => entry.kind === 'session-op')).toBe(false)
  store.closeOtherTabs('ses_1')
  expect(store.openTabs()).toEqual(['ses_1'])
  // Closing others switches only when the kept tab is not already current.
  expect(sent.some(entry => entry.kind === 'session-op')).toBe(false)
  store.reopenSessionTab()
  // The closed tab returns at the index it had when it was closed (`ses_3` was first).
  expect(store.openTabs()).toEqual(['ses_3', 'ses_1'])
  expect(sent.at(-1)).toEqual({ kind: 'session-op', payload: { op: 'switch', sessionId: 'ses_3' } })
})

test('initialFilter narrows a picker and section navigation is opt-in per dialog', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.openDialog({
    kind: 'select',
    title: 'pick',
    initialFilter: 'gam',
    sectionNavigation: true,
    options: [
      { title: 'alpha', value: 'a', category: 'first' },
      { title: 'gamma', value: 'g', category: 'second' },
      { title: 'beta', value: 'b', category: 'first' },
    ],
    onDone: () => undefined,
  })
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 80, height: 24 })
  await renderOnce()
  // The seeded query filters the list before the first frame: only the match is painted.
  const frame = captureCharFrame()
  expect(frame).toContain('gamma')
  expect(frame).not.toContain('alpha')
  // Alt+Down jumps to the next category (the opt-in dialog declares it).
  store.runAction('dialog-section-next')
  await renderOnce()
  expect(store.dialogOpen()).toBe(true)
  renderer.destroy()
  // Without the flag the controller leaves the selection where it is: the list is mounted
  // through the real shell so its controller is the one the keymap reaches.
  const plain = createAppStore()
  sessionRoute(plain, 20)
  plain.openDialog({
    kind: 'select',
    title: 'plain',
    options: [
      { title: 'one', value: '1', category: 'a' },
      { title: 'two', value: '2', category: 'b' },
    ],
    onDone: () => undefined,
  })
  const second = await mountShell(plain, { width: 80, height: 24 })
  await second.renderOnce()
  plain.runAction('dialog-section-next')
  await second.renderOnce()
  expect(plain.dialogController()?.selectedIndex?.()).toBe(0)
  second.renderer.destroy()
})

test('the completion window keeps the selected row inside the painted run', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  // Twelve matching commands: more than the ten-row window, so the window must scroll.
  store.apply({ protocolVersion: 2, seq: 2, kind: 'command-catalog', payload: { sessionId: 'ses_1', commands: Array.from({ length: 12 }, (_, index) => ({ name: `cmd-${index}`, description: `command ${index}` })) } })
  store.setComposer('/cmd-')
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 80, height: 30 })
  await renderOnce()
  const first = captureCharFrame()
  expect(first).toContain('/cmd-0')
  expect(first).not.toContain('/cmd-11')
  // Moving the selection past the window scrolls the run so the mark stays visible.
  for (let step = 0; step < 11; step++) store.runAction('completion-next')
  await renderOnce()
  const last = captureCharFrame()
  expect(last).toContain('/cmd-11')
  expect(last).not.toContain('/cmd-0')
  renderer.destroy()
})

test('a zero-match mention keeps the popup open with the native empty state', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'workspace-files', payload: { sessionId: 'ses_1', files: ['src/app.tsx'] } })
  store.setComposer('@zzz-no-such')
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 80, height: 30 })
  await renderOnce()
  expect(captureCharFrame()).toContain('No matching')
  renderer.destroy()
})

test('shutdown flushes local writes before the renderer is destroyed', async () => {
  const { createLocalStorage } = await import('./storage.ts')
  const { mkdtempSync, existsSync, rmSync } = await import('node:fs')
  const { tmpdir } = await import('node:os')
  const { join } = await import('node:path')
  const root = mkdtempSync(join(tmpdir(), 'dpsk-flush-'))
  const storage = createLocalStorage(root)
  const store = createAppStore()
  sessionRoute(store, 20)
  store.setLocalStorage(storage)
  store.setComposer('a prompt worth keeping')
  store.submitComposer()
  // The write is still in flight when shutdown starts; `flushLocalState` is what makes it
  // land before the process exits.
  await store.flushLocalState()
  expect(existsSync(join(storage.directory, 'prompt-history.jsonl'))).toBe(true)
  // Disposing the services twice is safe (no clipboard registered here).
  await store.disposeServices()
  await store.disposeServices()
  rmSync(root, { recursive: true, force: true })
})

test('typing in the palette filter narrows the painted rows', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'skills-list', payload: { sessionId: 'ses_1', skills: [{ name: 'dsh-review', description: 'review the diff' }] } })
  const { renderer, mockInput, renderOnce, captureCharFrame } = await mountShell(store, { width: 100, height: 30 })
  await renderOnce()
  store.runAction('palette')
  await renderOnce()
  expect(captureCharFrame()).toContain('rename session')
  mockInput.typeText('dsh', 0)
  await renderOnce()
  const filtered = captureCharFrame()
  expect(filtered).toContain('dsh-review')
  expect(filtered).not.toContain('rename session')
  renderer.destroy()
})

test('one down in the palette keeps the highlight on a painted row', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'command-catalog', payload: { sessionId: 'ses_1', commands: Array.from({ length: 30 }, (_, index) => ({ name: `cmd-${index}`, description: `command ${index}` })) } })
  const { renderer, renderOnce, captureSpans } = await mountShell(store, { width: 100, height: 30 })
  await renderOnce()
  store.runAction('palette')
  await renderOnce()
  // The palette opens with the first row highlighted; one `down` must move the highlight to
  // a row that is really painted, not scroll it out of the list's window.
  const hoveredRow = (): number => {
    const hover = store.color('background.action.primary.$hovered') ?? '#313244'
    const target = hover.toLowerCase()
    const rows: number[] = []
    for (const line of captureSpans().lines) {
      const text = line.spans.map(span => span.text).join('')
      const marked = line.spans.some(span => {
        const channels = (span as unknown as { bg?: { buffer?: Uint16Array } }).bg?.buffer
        if (channels === undefined) return false
        const hex = `#${[0, 1, 2].map(index => (channels[index] ?? 0).toString(16).padStart(2, '0')).join('')}`
        return hex.toLowerCase() === target && span.text.trim() !== ''
      })
      if (marked) rows.push(text.indexOf('/cmd-'))
    }
    return rows.length
  }
  expect(hoveredRow()).toBeGreaterThan(0)
  store.runAction('dialog-next')
  await renderOnce()
  expect(hoveredRow()).toBeGreaterThan(0)
  renderer.destroy()
})

test('one down moves the palette selection by exactly one row', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'command-catalog', payload: { sessionId: 'ses_1', commands: Array.from({ length: 30 }, (_, index) => ({ name: `cmd-${index}`, description: `command ${index}` })) } })
  const { renderer, renderOnce } = await mountShell(store, { width: 100, height: 40 })
  await renderOnce()
  store.runAction('palette')
  await renderOnce()
  expect(store.dialogController()?.selectedIndex?.()).toBe(0)
  store.runAction('dialog-next')
  await renderOnce()
  // A single arrow moves one row, even when the list is longer than the window.
  expect(store.dialogController()?.selectedIndex?.()).toBe(1)
  renderer.destroy()
})

test('a theme preview writes nothing; Escape restores; a pick writes the host field', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  const { renderer, renderOnce } = await mountShell(store, { width: 100, height: 30 })
  await renderOnce()
  // The provider must be mounted for the controls to exist; the shell mounts it in main.tsx,
  // so this test drives the provider bridge directly through the same calls the picker makes.
  const { registerThemeControls, themeControls } = await import('./theme/controls.ts')
  let active = 'opencode'
  const written: string[] = []
  registerThemeControls({
    all: () => ({ opencode: {}, carbonfox: {}, dracula: {} }),
    selected: () => active,
    mode: () => 'dark',
    preview: name => { active = name; return true },
    set: name => { active = name; written.push(name); return true },
    setMode: () => true,
    unlock: () => undefined,
  })
  store.runAction('pick-theme')
  await renderOnce()
  store.runAction('dialog-next')
  await renderOnce()
  // Moving the highlight previews only: nothing is persisted yet.
  expect(active).toBe('carbonfox')
  expect(written).toEqual([])
  store.closeTopDialog(undefined)
  await renderOnce()
  // Cancel restores the committed theme.
  expect(active).toBe('opencode')
  store.runAction('pick-theme')
  await renderOnce()
  store.runAction('dialog-next')
  await renderOnce()
  store.closeTopDialog('dracula')
  await renderOnce()
  expect(written).toEqual(['dracula'])
  registerThemeControls(undefined)
  renderer.destroy()
})

test('the session picker groups by last activity and preserves host order', () => {
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'current', events: [{ id: 'e1', role: 'user', text: 'hi' }], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' },
  })
  const now = Date.now()
  const day = 24 * 60 * 60 * 1000
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-list',
    payload: {
      sessions: [
        { id: 'ses_1', title: 'current', active: true, workspace: 'D:/Projects/dsh', createdAt: now - 60 * day, lastActivityAt: now, status: 'idle', attention: false },
        { id: 'ses_yesterday', title: 'yesterday', active: false, workspace: 'D:/Projects/dsh', createdAt: now, lastActivityAt: now - day, status: 'idle', attention: false },
        { id: 'ses_missing', title: 'fallback', active: false, workspace: 'D:/Projects/dsh', createdAt: now - 20 * day, status: 'idle', attention: false },
      ],
      current: 'ses_1',
    },
  })
  store.runAction('list-sessions')
  store.closeTopDialog('all')
  const dialog = store.dialogStack().at(-1)
  const options = dialog?.options ?? []
  expect(options.map(option => option.value)).toEqual(['ses_1', 'ses_yesterday', 'ses_missing'])
  expect(dialog?.current).toBe('ses_1')
  expect(options.find(option => option.value === 'ses_1')?.footer).toBe('today')
  expect(options.find(option => option.value === 'ses_yesterday')?.footer).toBe('yesterday')
  expect(options.find(option => option.value === 'ses_missing')?.footer).toMatch(/^\d{2}\/\d{2}$/)
  // Compact rows carry no session inspector metadata.
  expect(options.every(option => option.description === undefined && option.details === undefined && option.category === undefined)).toBe(true)
  // Hidden search still finds an id and workspace without painting them.
  expect(options.find(option => option.value === 'ses_1')?.searchText).toContain('D:/Projects/dsh')
})

test('the compact session picker paints a title plus time at every width', async () => {
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'current', events: [{ id: 'e1', role: 'user', text: 'hi' }], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' },
  })
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-list',
    payload: {
      sessions: [{
        id: 'tui-hidden-id',
        title: 'Alpha session',
        active: true,
        workspace: 'D:/Projects/dsh',
        parentId: 'ses_parent',
        createdAt: Date.now(),
        lastActivityAt: Date.now(),
        status: 'idle',
        attention: false,
      }],
      current: 'ses_1',
    },
  })
  store.runAction('list-sessions')
  store.closeTopDialog('all')
  for (const width of [40, 80, 120]) {
    const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width, height: 24 })
    await renderOnce()
    const frame = captureCharFrame()
    expect(frame).toContain('today')
    expect(frame).not.toContain('tui-hidden-id')
    expect(frame).not.toContain('child of')
    expect(frame).not.toContain('idle')
    renderer.destroy()
  }
})


test('the status row paints ~ by default and the full path after the setting', async () => {
  const store = createAppStore()
  const cwd = join(homedir(), 'Projects', 'dsh')
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'path frame', events: [{ id: 'e1', role: 'user', text: 'hi' }], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: cwd },
  })
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 120, height: 24 })
  await renderOnce()
  const abbreviated = captureCharFrame()
  expect(abbreviated).toContain('~/Projects/dsh')
  expect(abbreviated).not.toContain(cwd)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'settings', payload: { schemaVersion: 2, values: { pathDisplay: 'full' } } })
  await renderOnce()
  const full = captureCharFrame()
  expect(full).toContain(cwd)
  expect(full).not.toContain('~/Projects/dsh')
  renderer.destroy()
})

test('tab strip keeps manual order and cached titles when the catalog reorders', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-list',
    payload: {
      sessions: [
        { id: 'ses_3', title: 'third session', active: false },
        { id: 'ses_1', title: 'first prompt', active: true },
        { id: 'ses_2', title: 'second session', active: false },
      ],
      current: 'ses_1',
    },
  })
  store.openTab('ses_2')
  store.openTab('ses_3')
  // This tab has a cached title but no catalog row: it must still paint, not a blank chip.
  store.openTab('ses_cached', 'Cached only')
  store.moveTab('ses_3', -1)
  expect(store.openTabs()).toEqual(['ses_1', 'ses_3', 'ses_2', 'ses_cached'])
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  const frame = captureCharFrame().split('\n')[0] ?? ''
  const first = frame.indexOf('first prompt')
  const third = frame.indexOf('third session')
  const second = frame.indexOf('second session')
  const cached = frame.indexOf('Cached only')
  expect(first).toBeGreaterThanOrEqual(0)
  expect(first < third && third < second && second < cached).toBe(true)
  renderer.destroy()
})

test('a running session paints the real status dot in its tab', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-list',
    payload: {
      sessions: [{ id: 'ses_1', title: 'first prompt', active: true, status: 'running', attention: false }],
      current: 'ses_1',
    },
  })
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  expect(captureCharFrame()).toMatch(/●\s*first prompt/)
  renderer.destroy()
})

test('the active tab has a clearly different surface and bold label', async () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-list',
    payload: {
      sessions: [
        { id: 'ses_1', title: 'first prompt', active: true },
        { id: 'ses_2', title: 'second session', active: false },
      ],
      current: 'ses_1',
    },
  })
  store.openTab('ses_2')
  const { renderer, renderOnce, captureSpans } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  const frame = captureSpans()
  const active = tabSpan(frame, 'first prompt')
  const idle = tabSpan(frame, 'second session')
  expect(active).toBeDefined()
  expect(idle).toBeDefined()
  // The old active fill was only one hue step from the idle page and read as the same
  // chip in terminal palettes. The active surface is now visibly distinct and its label
  // is bold, not merely a slightly brighter muted ink.
  expect(backgroundOf(active)).not.toBe(backgroundOf(idle))
  expect(active?.attributes).not.toBe(idle?.attributes)
  renderer.destroy()
})

test('hovering reveals a close cell and dragging reorders the tab', async () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-list',
    payload: {
      sessions: [
        { id: 'ses_1', title: 'first prompt', active: true },
        { id: 'ses_2', title: 'second session', active: false },
      ],
      current: 'ses_1',
    },
  })
  store.openTab('ses_2')
  const { renderer, renderOnce, captureCharFrame, mockMouse } = await mountShell(store, { width: 90, height: 24 })
  await renderOnce()
  const idle = captureCharFrame().split('\n')[0] ?? ''
  const idleCloseCells = [...idle].filter(char => char === '×').length
  // The second chip starts after the first 32-cell slot plus the two-cell inset.
  await mockMouse.moveTo(50, 0)
  await renderOnce()
  const hovered = captureCharFrame().split('\n')[0] ?? ''
  const hoveredCloseCells = [...hovered].filter(char => char === '×').length
  expect(hoveredCloseCells).toBe(idleCloseCells + 1)
  // Its close overlay occupies the last two cells of the second chip (right edge 66).
  await mockMouse.click(65, 0)
  await renderOnce()
  expect(store.openTabs()).toEqual(['ses_1'])
  // Reopen the second tab and drag it onto the first position.
  store.openTab('ses_2', 'second session')
  await renderOnce()
  await mockMouse.drag(50, 0, 5, 0)
  await renderOnce()
  expect(store.openTabs()).toEqual(['ses_2', 'ses_1'])
  renderer.destroy()
})

test('ctrl+0 selects the tenth tab and catalog pruning keeps live drafts', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => {
    sent.push({ kind, payload })
    return sent.length
  })
  sessionRoute(store, 20)
  for (let index = 2; index <= 10; index++) store.openTab(`ses_${index}`, `session ${index}`)
  store.runAction('select-session-0')
  expect(sent.at(-1)).toEqual({ kind: 'session-op', payload: { op: 'switch', sessionId: 'ses_10' } })
  store.runAction('new-session')
  expect(store.openTabs()).toContain(DRAFT_TAB_ID)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-list',
    payload: {
      sessions: [{ id: 'ses_1', title: 'first prompt', active: true }, { id: 'ses_10', title: 'session 10', active: false }],
      current: 'ses_1',
    },
  })
  // Dead real tabs and their reopen entries disappear; the active id and the draft survive.
  expect(store.openTabs()).toEqual(['ses_1', 'ses_10', DRAFT_TAB_ID])
})

test('new session tab menu omits rename because there is no host session yet', () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.runAction('new-session')
  store.openTabMenu(DRAFT_TAB_ID)
  const values = store.dialogStack().at(-1)?.options?.map(option => option.value)
  expect(values).toEqual(['close', 'close-others', 'move-left', 'move-right', 'reopen'])
})

test('ctrl+t cycles reasoning effort on Home as well as in a session', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => sent.push({ kind, payload }))
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: { sessionId: 'ses_1', initialRoute: 'home', title: '', events: [], provider: 'p', model: 'm', effort: 'low', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' },
  })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'reasoning-efforts', payload: { sessionId: 'ses_1', efforts: ['low', 'high'], current: 'low' } })
  store.runAction('cycle-effort')
  expect(store.effortCurrent()).toBe('high')
  expect(sent).toEqual([{ kind: 'set-selection', payload: { sessionId: 'ses_1', effort: 'high' } }])
  store.runAction('cycle-effort')
  expect(store.effortCurrent()).toBe('low')
  expect(sent.at(-1)).toEqual({ kind: 'set-selection', payload: { sessionId: 'ses_1', effort: 'low' } })
})

test('jump to latest is a clickable overlay above the prompt and never moves it', async () => {
  const store = createAppStore()
  sessionRoute(store)
  const events = Array.from({ length: 40 }, (_, index) => ({
    id: `e${index}`,
    role: index % 2 === 0 ? 'user' : 'assistant',
    text: `overflow row ${index}`,
  }))
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1', initialRoute: 'session', title: 'long', events,
      provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  const { renderer, renderOnce, captureCharFrame, mockMouse } = await mountShell(store, { width: 80, height: 24 })
  await renderOnce()
  await Bun.sleep(40)
  await renderOnce()
  const before = painted(captureCharFrame())
  const promptBefore = before.findIndex(row => row.includes('prompt, /command'))
  expect(promptBefore).toBeGreaterThan(0)
  expect(store.awayFromBottom()).toBe(false)
  store.scrollRows(-10)
  await renderOnce()
  await Bun.sleep(20)
  await renderOnce()
  expect(store.awayFromBottom()).toBe(true)
  const scrolled = painted(captureCharFrame())
  const buttonRow = scrolled.findIndex(row => row.includes('Jump to latest'))
  const promptAfter = scrolled.findIndex(row => row.includes('prompt, /command'))
  expect(buttonRow).toBeGreaterThan(0)
  // One blank overlay row, then the panel's top row, then the placeholder row.
  expect(buttonRow).toBe(promptAfter - 2)
  expect(promptAfter).toBe(promptBefore)
  expect(scrolled[buttonRow]?.trimEnd().endsWith('Jump to latest ↓')).toBe(true)
  const x = (scrolled[buttonRow] ?? '').indexOf('Jump to latest ↓') + 2
  await mockMouse.click(x, buttonRow)
  await renderOnce()
  await Bun.sleep(20)
  await renderOnce()
  const latest = painted(captureCharFrame())
  expect(latest.some(row => row.includes('Jump to latest'))).toBe(false)
  expect(latest.some(row => row.includes('overflow row 39'))).toBe(true)
  renderer.destroy()
})

test('the status bar keeps round and tool-step counters with no final assistant row', async () => {
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1', initialRoute: 'session', title: 'counters',
      events: [
        { id: 'u1', role: 'user', source: 'user', text: 'one' },
        { id: 't1', role: 'tool', turn: 1, step: 1, tool: 'read', status: 'ok' },
        { id: 't2', role: 'tool', turn: 1, step: 1, tool: 'grep', status: 'ok' },
        { id: 'u2', role: 'user', source: 'user', text: 'interrupted' },
        { id: 't3', role: 'tool', turn: 2, step: 2, tool: 'glob', status: 'ok' },
      ],
      provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 120, height: 24 })
  await renderOnce()
  expect(captureCharFrame()).toContain('T2 S2')
  renderer.destroy()
})

test('jump to latest stays above a wrapped multi-line composer', async () => {
  const store = createAppStore()
  sessionRoute(store)
  const events = Array.from({ length: 40 }, (_, index) => ({
    id: `w${index}`,
    role: index % 2 === 0 ? 'user' : 'assistant',
    text: `wrapped row ${index}`,
  }))
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-snapshot', payload: {
    sessionId: 'ses_1', initialRoute: 'session', title: 'wrapped', events,
    provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard',
    workspace: 'D:/Projects/dsh',
  } })
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 80, height: 24 })
  await renderOnce()
  await Bun.sleep(40)
  await renderOnce()
  store.scrollRows(-10)
  store.setComposer(`first line
${'long wrapped input '.repeat(30)}`)
  await renderOnce()
  await Bun.sleep(30)
  await renderOnce()
  const rows = painted(captureCharFrame())
  const buttonRow = rows.findIndex(row => row.includes('Jump to latest'))
  const inputRow = rows.findIndex(row => row.includes('long wrapped input'))
  expect(buttonRow).toBeGreaterThan(0)
  expect(inputRow).toBeGreaterThan(buttonRow)
  expect(rows[buttonRow]).not.toContain('first line')
  expect(rows[buttonRow]).not.toContain('long wrapped input')
  renderer.destroy()
})

test('jump to latest yields to the completion popup and returns when it closes', async () => {
  const store = createAppStore()
  sessionRoute(store)
  const events = Array.from({ length: 40 }, (_, index) => ({
    id: `j${index}`,
    role: index % 2 === 0 ? 'user' : 'assistant',
    text: `jump row ${index}`,
  }))
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1', initialRoute: 'session', title: 'long', events,
      provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  })
  const { renderer, renderOnce, captureCharFrame } = await mountShell(store, { width: 120, height: 24 })
  await renderOnce()
  await Bun.sleep(40)
  await renderOnce()
  store.scrollRows(-10)
  await renderOnce()
  await Bun.sleep(20)
  await renderOnce()
  expect(painted(captureCharFrame()).some(row => row.includes('Jump to latest'))).toBe(true)
  store.apply({
    protocolVersion: 2,
    seq: 3,
    kind: 'command-catalog',
    payload: { sessionId: 'ses_1', commands: [{ name: 'model', description: 'switch model' }] },
  })
  store.setComposer('/m')
  await renderOnce()
  await Bun.sleep(20)
  await renderOnce()
  expect(store.popupOpen()).toBe(true)
  expect(painted(captureCharFrame()).some(row => row.includes('Jump to latest'))).toBe(false)
  store.setComposer('')
  await renderOnce()
  await Bun.sleep(20)
  await renderOnce()
  expect(store.popupOpen()).toBe(false)
  expect(painted(captureCharFrame()).some(row => row.includes('Jump to latest'))).toBe(true)
  renderer.destroy()
})


test('the trace command opens the complete interaction panel', () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  expect(store.traceRows().length).toBeGreaterThan(0)
  store.runAction('trace')
  expect(store.dialogStack().at(-1)?.kind).toBe('trace')
})

test('child sessions and running shell jobs feed the hidden-by-default rail sections', () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-list', payload: { sessions: [
    { id: 'ses_1', title: 'parent task', active: true, createdAt: 1, status: 'running', attention: false, sessionKind: 'main' },
    { id: 'child-1', title: 'researcher', active: false, parentId: 'ses_1', createdAt: 2, status: 'running', attention: false, sessionKind: 'subagent', canInteract: true },
  ], current: 'ses_1' } })
  store.apply({ protocolVersion: 2, seq: 3, kind: 'shell-jobs', payload: { sessionId: 'child-1', jobs: [{ id: 'job-1', kind: 'bash', label: 'npm run check', owner: 'child-1', status: 'running', startedAt: 1, output: { total: 42, earliest: 0 } }] } })
  expect(store.sidebarCollapsed().subagents).toBe(true)
  expect(store.sidebarCollapsed().background).toBe(true)
  expect(store.subagentsForCurrent()).toEqual([{ id: 'child-1', title: 'researcher', status: 'running', canInteract: true }])
  expect(store.backgroundTasks().map(task => [task.owner, task.ownerTitle, task.label, task.status])).toEqual([
    ['child-1', 'researcher', 'npm run check', 'running'],
  ])
  store.toggleSidebarSection('subagents')
  expect(store.sidebarCollapsed().subagents).toBe(false)
})



test('exit warns about running work and offers the detach and open-running choices', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => sent.push({ kind, payload }))
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'hello-ack', payload: { hostId: 'h', hostVersion: '0.5.0', status: 'compatible', capabilities: ['daemon-detach'], reasons: [] } })
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-list', payload: { sessions: [
    { id: 'ses_1', title: 'running task', active: true, createdAt: 1, status: 'running', attention: false, sessionKind: 'main' },
  ], current: 'ses_1' } })
  store.runAction('exit')
  const top = store.dialogStack().at(-1)
  expect(top?.kind).toBe('select')
  expect(top?.options?.map(option => option.value)).toEqual(['quit', 'running', 'cancel'])
  expect(sent.some(entry => entry.kind === 'bye')).toBe(false)
  store.closeTopDialog('quit')
  expect(sent.some(entry => entry.kind === 'bye')).toBe(true)
})

test('shutdown is a separate confirmation from exiting the TUI', () => {
  const store = createAppStore()
  sessionRoute(store, 20)
  store.runAction('shutdown')
  const top = store.dialogStack().at(-1)
  expect(top?.kind).toBe('confirm')
  expect(top?.title).toBe('Shut down the core process?')
})



test('the settings page exposes the real launch-at-login state and writes it through the host', () => {
  const sent: Array<{ kind: string; payload: unknown }> = []
  const store = createAppStore((kind, payload) => sent.push({ kind, payload }))
  sessionRoute(store, 20)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'settings', payload: { ns: 'tui', schemaVersion: 2, values: { autostart: false, autostartSupported: true } } })
  store.runAction('settings')
  const option = store.dialogStack().at(-1)?.options?.find(item => item.value === 'setting:autostart')
  expect(option?.disabled).toBe(false)
  expect(option?.title).toContain('off')
  store.closeTopDialog('setting:autostart')
  expect(sent).toContainEqual({ kind: 'autostart-op', payload: { enabled: true } })
})
