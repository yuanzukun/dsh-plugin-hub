/**
 * Shared shell test harness.
 *
 * OpenTUI only runs Solid's queue inside the renderer's scheduler, so a fixture that
 * paints one frame (`renderOnce()`) leaves every late-mounting component — dialogs,
 * popups, toasts, spinners — frozen: its root's render binding is never re-run. The
 * fixtures below start the renderer, wire the keymap through the store exactly as
 * `main.tsx` does, and paint on demand with `settle()`, which drains the scheduler
 * until the screen stops changing.
 *
 * JSX is transformed by @opentui/solid (see `renderer/bunfig.toml`'s test preload).
 */

import { testRender } from '@opentui/solid'
import type { CapturedFrame } from '@opentui/core'
import type { MockInput, MockMouse, TestRenderer } from '@opentui/core/testing'
import { Shell, type AppStore } from './app.tsx'
import type { LocalStorage } from './storage.ts'
import { createKeymap, LEADER_TIMEOUT_MS } from './keymap/keymap.ts'

export type ShellFixture = {
  /** The running test renderer. */
  renderer: TestRenderer
  /** Mock keyboard: `pressKey`, `pressArrow`, `pressEnter`, … */
  mockInput: MockInput
  /** Mock mouse. */
  mockMouse: MockMouse
  /** Drain the scheduler until the painted screen stops changing. */
  settle: () => Promise<void>
  /** The painted grid. */
  captureCharFrame: () => string
  /** The painted grid with colors and attributes. */
  captureSpans: () => CapturedFrame
  /** Resize the mock terminal, then drain. */
  resize: (width: number, height: number) => Promise<void>
  /** One key event through the shell's keymap, then drain. */
  press: (name: string, modifiers?: { ctrl?: boolean; shift?: boolean; meta?: boolean }) => Promise<void>
  /** `settle()` under the names the migrated call sites already use. */
  renderOnce: () => Promise<void>
  flush: () => Promise<void>
}
/** A tiny in-memory LocalStorage so frame tests never read or write the user's real state. */
export function createMemoryStorage(): LocalStorage {
  const objects = new Map<string, unknown>()
  const history: unknown[] = []
  return {
    directory: 'memory://tui',
    historyFile: 'memory://prompt-history',
    read: async (key: string) => objects.get(key),
    update: async (key: string, initial: object, mutate: (draft: object) => void) => {
      const draft = { ...((objects.get(key) as object | undefined) ?? initial) }
      mutate(draft)
      objects.set(key, draft)
      return draft
    },
    appendHistory: async (entry: unknown) => { history.push(entry) },
    readHistory: async () => history,
    flush: async () => undefined,
  } as unknown as LocalStorage
}

/** Give direct `testRender(<Shell/>)` callers the same isolation as `mountShell`. */
export function isolateShellStore(store: AppStore): void {
  if (!store.hasLocalStorage()) store.setLocalStorage(createMemoryStorage())
}

/** Mount the real shell with the keymap wired to the store, as `main.tsx` does. */
export async function mountShell(
  store: AppStore,
  options: { width?: number; height?: number; leaderTimeout?: number } = {},
): Promise<ShellFixture> {
  isolateShellStore(store)
  const setup = await testRender(() => <Shell store={store} />, {
    width: options.width ?? 90,
    height: options.height ?? 24,
  })
  // The scheduler must run for late-mounted components to keep repainting.
  setup.renderer.start()
  const configuredLeaderTimeout = store.settings().leaderTimeout
  const keymap = createKeymap(
    action => store.runAction(action),
    options.leaderTimeout ?? (typeof configuredLeaderTimeout === 'number' ? configuredLeaderTimeout : LEADER_TIMEOUT_MS),
    undefined,
    () => store.keyLayer(),
  )
  setup.renderer.keyInput.on('keypress', (key: { name: string; ctrl: boolean; shift: boolean; meta: boolean }) => {
    keymap.handle(key)
  })
  const settle = async (): Promise<void> => {
    // The filter input focuses one millisecond after mount; give it the tick.
    await Bun.sleep(1)
    await setup.waitForVisualIdle()
  }
  await settle()
  return {
    renderer: setup.renderer,
    mockInput: setup.mockInput,
    mockMouse: setup.mockMouse,
    settle,
    renderOnce: settle,
    flush: settle,
    captureCharFrame: setup.captureCharFrame,
    captureSpans: setup.captureSpans,
    resize: async (width: number, height: number) => {
      await setup.renderer.resize(width, height)
      await settle()
    },
    press: async (name: string, modifiers: { ctrl?: boolean; shift?: boolean; meta?: boolean } = {}) => {
      setup.mockInput.pressKey(name, modifiers)
      await settle()
    },
  }
}
