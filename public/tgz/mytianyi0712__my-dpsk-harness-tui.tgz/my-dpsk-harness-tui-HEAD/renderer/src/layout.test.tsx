/**
 * Geometry assertions for the shell's region tree.
 *
 * `captureCharFrame()` is the painted screen as the user sees it, so every assertion here
 * reads rows the way a terminal does: a region that moves, a footer that is not the last
 * row, a line that runs past the terminal edge, a transcript that is not stuck to its
 * newest row, or a prompt stack that is pushed off the bottom edge all fail here.
 *
 * The structure asserted is opencode v2's: the session chips ride the top row of the content
 * column (`tabs.layout = "horizontal"`), the transcript fills the middle, the prompt stack is
 * pinned to the bottom, and the footer closes the frame. There is no second header band and no
 * vertical rail.
 *
 * The widths are the breakpoints the layout pins: 40 (the content floor, where the prompt
 * padding narrows), 60 (the narrow band where the dialog footer stacks), 80 (the default grid),
 * and 120 (the wide band where the sidebar may dock).
 */

import { expect, test } from 'bun:test'
import { testRender } from '@opentui/solid'
import { Shell, createAppStore, type AppStore } from './app.tsx'
import { logoHeight } from './ui/home.tsx'
import { createMemoryStorage } from './test-harness.tsx'
import { sidebarDocked } from './ui/layout.ts'

const WIDTHS = [40, 60, 80, 120]
const HEIGHT = 24

/** A store with a handshake, one session, and `events` transcript rows. The newest row is
 * the last one, so a sticky-bottom viewport must show it. */
function storeWith(events: number): AppStore {
  const store = createAppStore()
  store.apply({
    protocolVersion: 2,
    seq: 0,
    kind: 'hello-ack',
    payload: { protocolVersion: 2, hostId: 'my-dpsk-harness-tui', hostVersion: '0.5.0', capabilities: [], status: 'compatible', reasons: [] },
  } as never)
  store.apply({
    protocolVersion: 2,
    seq: 1,
    kind: 'session-snapshot',
    payload: {
      sessionId: 'ses_1',
      initialRoute: 'session',
      title: 'first prompt',
      events: Array.from({ length: events }, (_, index) => ({
        id: `e${index}`,
        role: index % 2 === 0 ? 'user' : 'assistant',
        text: `row ${index}`,
      })),
      provider: 'cliproxy',
      model: 'mimo-v2.6-pro',
      effort: 'high',
      permission: 'auto',
      preset: 'standard',
      workspace: 'D:/Projects/dsh',
    },
  } as never)
  return store
}

async function paint(store: AppStore, width: number, height = HEIGHT): Promise<string[]> {
  if (!store.hasLocalStorage()) store.setLocalStorage(createMemoryStorage())
  const setup = await testRender(() => <Shell store={store} />, { width, height })
  // `<markdown>` parses before it lays out but arrives a few scheduler passes after the
  // first frame; drain the scheduler until the transcript, the layout, and the sticky-bottom
  // scroll have all settled.
  for (let pass = 0; pass < 4; pass++) {
    await Bun.sleep(40)
    setup.renderer.requestRender?.()
  }
  // The frame ends with a newline, so `split` yields one phantom row past the grid.
  const rows = setup.captureCharFrame().split('\n')
  if (rows[rows.length - 1] === '') rows.pop()
  setup.renderer.destroy()
  return rows
}

/** The row index that carries `needle`, or -1. */
function rowIndex(rows: string[], needle: string): number {
  return rows.findIndex(row => row.includes(needle))
}

for (const width of WIDTHS) {
  test(`the region order holds at ${width} columns`, async () => {
    const rows = await paint(storeWith(2), width)
    // The frame is exactly the grid: no phantom rows, no row longer than the terminal.
    expect(rows.length).toBe(HEIGHT)
    for (const row of rows) expect(row.length).toBeLessThanOrEqual(width)

    // Row 0 is the horizontal session strip. The transcript follows immediately: row 1 is
    // its top margin, row 2 the user card's top border, row 3 the text.
    const userRow = rowIndex(rows, 'row 0')
    const bar = rowIndex(rows, 'dsh')
    expect(rows[0]).toContain('first prompt')
    expect(userRow).toBe(3)
    expect(rows[1]?.trim()).toBe('')
    expect(rows[2]?.trimStart().startsWith('┃')).toBe(true)
    expect(rows.some(row => row.includes('dpsk'))).toBe(false)
    expect(rows.some(row => row.includes('session:'))).toBe(false)
    // The status bar owns the last two rows: the cwd line then the centred metrics line.
    // At 40 columns the cwd is down to its final directory, so the row is found by that.
    expect(bar).toBe(HEIGHT - 2)

    // The prompt stack is pinned above the bar: the shadow lip (`▀`) is its last row.
    const lip = rows.findIndex(row => row.includes('▀'))
    expect(lip).toBe(HEIGHT - 3)
  })

  test(`the status bar is exactly two rows at ${width} columns`, async () => {
    const rows = await paint(storeWith(2), width)
    const directory = rows[HEIGHT - 2]!
    const metrics = rows[HEIGHT - 1]!
    // The first row carries `pad()` cells of padding on each side (1 below the 44-column
    // content floor, 2 above). The hint is the first thing to go when both do not fit: at
    // 40/44 columns only the cwd paints, from 60 up both share the row.
    const pad = width < 44 ? 1 : 2
    expect(directory.slice(0, pad).trim()).toBe('')
    expect(directory).toContain('dsh')
    expect(directory.length).toBeLessThanOrEqual(width)
    const bothFit = width >= 60
    if (bothFit) expect(directory.trimEnd().endsWith('ctrl+p commands')).toBe(true)
    else expect(directory).not.toContain('ctrl+p commands')
    // The metrics row never runs past the grid, and the shell has no third footer row.
    expect(metrics.length).toBeLessThanOrEqual(width)
    expect(rows[HEIGHT - 3]).toContain('▀')
  })
}

test('the active chip follows the renderer current session, not the catalog flag', async () => {
  // The host's `session-list` arrives on a later push, so a catalog that still marks the
  // previous session active must not keep the old chip highlighted after a switch.
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hi' }], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } } as never)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-list', payload: { sessions: [{ id: 'ses_1', title: 'first prompt', active: true }, { id: 'ses_2', title: 'second session', active: false }], current: 'ses_1' } } as never)
  store.openTab('ses_2')
  // Switch to `ses_2` without any follow-up `session-list`: the snapshot alone moves the chip.
  store.apply({ protocolVersion: 2, seq: 3, kind: 'session-snapshot', payload: { sessionId: 'ses_2', initialRoute: 'session', title: 'second session', events: [{ id: 'e2', role: 'user', text: 'hi' }], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } } as never)
  const rows = await paint(store, 80)
  // Only the active chip carries the close affordance, and it trails the second chip.
  const strip = rows[0] ?? ''
  expect(store.currentSession()).toBe('ses_2')
  expect(strip).toContain('second session')
  expect(strip.split('×').length - 1).toBe(1)
  expect(strip.indexOf('×')).toBeGreaterThan(strip.indexOf('second session'))
})

test('the session chips ride the top row with their number cell and the add cell', async () => {
  const store = storeWith(2)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-list', payload: { sessions: [{ id: 'ses_1', title: 'first prompt', active: true }, { id: 'ses_2', title: 'second session', active: false }], current: 'ses_1' } } as never)
  // The catalog only lists sessions; the strip paints the tabs this renderer opened.
  store.openTab('ses_2')
  const rows = await paint(store, 80)
  // Upstream paints the strip as the first row of the content column: the active chip is
  // filled, the idle one hollow, and the add affordance closes the run.
  // Upstream's chip is the 1-based number cell then the title; the add affordance is the
  // three-cell `" + "` text, not a labelled chip.
  expect(rows[0]).toContain('1 first prompt')
  expect(rows[0]).toContain('2 second session')
  expect(rows[0]).toContain(' + ')
  // The transcript starts below the chip row, not above it.
  expect(rowIndex(rows, 'row 0')).toBeGreaterThan(0)
})

test('the tab strip reports the chips it cannot fit', async () => {
  const store = storeWith(2)
  const sessions = Array.from({ length: 12 }, (_, index) => ({ id: `ses_${index}`, title: `session number ${index}`, active: index === 0 }))
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-list', payload: { sessions, current: 'ses_0' } } as never)
  for (const session of sessions) store.openTab(session.id)
  const rows = await paint(store, 60)
  // Twelve 8-cell chips cannot fit a 60-cell row, so the strip closes with the hidden count.
  expect(rows[0]).toContain('›')
  expect(rows[0]).toContain(' + ')
})

test('the viewport stays stuck to the newest transcript row', async () => {
  // 40 rows in a 24-row grid: the scrollbox must show the newest row, not the oldest.
  const rows = await paint(storeWith(40), 80)
  const newest = rowIndex(rows, 'row 39')
  const oldest = rowIndex(rows, 'row 0')
  expect(newest).toBeGreaterThan(-1)
  expect(oldest).toBe(-1)
  // The newest row sits above the prompt stack, inside the viewport.
  const prompt = rowIndex(rows, 'Projects/dsh')
  expect(newest).toBeLessThan(prompt)
})

test('a subagent dock and a completion popup paint without moving the prompt', async () => {
  const store = storeWith(2)
  store.apply({
    protocolVersion: 2,
    seq: 2,
    kind: 'subagent-list',
    payload: { sessionId: 'ses_1', agents: [{ label: 'explorer', provider: 'cliproxy', mode: 'one-shot' }] },
  } as never)
  // The host owns the workspace index; the popup filters the list it pushed.
  store.apply({ protocolVersion: 2, seq: 6, kind: 'workspace-files', payload: { sessionId: 'ses_1', files: ['tmp/layout-120.tsx'] } } as never)
  store.setComposer('@tmp/la')
  const rows = await paint(store, 90)
  const prompt = rowIndex(rows, 'Projects/dsh')
  // The status bar closes the frame: the dock took rows from the transcript, not the bar.
  expect(prompt).toBe(HEIGHT - 2)
  // The drawer is the dock: its rows sit above the popup's span, so the subagent row stays
  // visible while the popup paints over the composer rows it covers.
  const popup = rowIndex(rows, '@tmp/layout-120.tsx')
  expect(popup).toBeGreaterThan(1)
  expect(popup).toBeLessThan(prompt)
  expect(rows[popup]).toContain('reference')
  expect(rows.some(row => row.includes('explorer'))).toBe(true)
})

test('submitted history alone does not dock a drawer over the transcript', async () => {
  const store = storeWith(2)
  // Submit a prompt, then return to idle: the history list is non-empty but nothing is in
  // flight, so the composer area is the prompt alone.
  store.apply({ protocolVersion: 2, seq: 2, kind: 'turn-state', payload: { sessionId: 'ses_1', running: true } } as never)
  store.apply({ protocolVersion: 2, seq: 3, kind: 'turn-state', payload: { sessionId: 'ses_1', running: false } } as never)
  const rows = await paint(store, 90)
  expect(rowIndex(rows, 'rendersDrawer')).toBe(-1)
  expect(rows.some(row => row.includes('history'))).toBe(false)
})

test('the toast overlay sits top-right and never takes rows from the column', async () => {
  const store = storeWith(2)
  store.pushNotice('warning', 'a warning routed from stderr')
  const rows = await paint(store, 90)
  const toast = rowIndex(rows, 'a warning routed from stderr')
  // The overlay sits in the top band, right-aligned with a 2-cell margin, and paints over the
  // shell without taking rows. The panel starts at the first row and its own `paddingTop` puts
  // the message on the second one (upstream's `ToastSurface`); the footer stays last.
  expect(toast).toBe(2)
  const toastRow = rows[toast]!
  expect(toastRow).toContain('a warning routed from stderr')
  expect(toastRow).toMatch(/x\s*│/)
  // The right margin: the toast's right border ends 2 cells before the terminal edge.
  expect(toastRow.trimEnd().endsWith('│')).toBe(true)
  expect(toastRow.length - toastRow.trimEnd().length).toBe(2)
  expect(rowIndex(rows, 'Projects/dsh')).toBe(HEIGHT - 2)
})

/** A store with two sessions, MCP server names, usage, and the sidebar open: the matrix probes
 * every region that a width breakpoint changes. */
function richStore(): AppStore {
  const store = storeWith(2)
  store.apply({ protocolVersion: 2, seq: 3, kind: 'session-list', payload: { sessions: [{ id: 'ses_1', title: 'first prompt', active: true }, { id: 'ses_2', title: 'second session', active: false }], current: 'ses_1' } } as never)
  store.apply({ protocolVersion: 2, seq: 4, kind: 'mcp-servers', payload: { servers: [{ id: 'mcp-1', name: 'dsh-review' }] } } as never)
  store.apply({ protocolVersion: 2, seq: 5, kind: 'usage', payload: { sessionId: 'ses_1', inputTokens: 12000, outputTokens: 3400, cacheReadTokens: 8000, cacheWriteTokens: 200, contextTokens: 12300, contextWindow: 131072, contextPct: 9 } } as never)
  return store
}

const MATRIX_WIDTHS = [40, 44, 60, 64, 80, 108, 120]
const MATRIX_HEIGHTS = [12, 14, 16, 22, 24, 30]

for (const width of MATRIX_WIDTHS) {
  for (const height of MATRIX_HEIGHTS) {
    test(`the breakpoint matrix holds at ${width}x${height}`, async () => {
      const rows = await paint(richStore(), width, height)
      // The grid is exact: every row fits the terminal, and the two-row status bar closes it
      // with the metrics line last.
      expect(rows.length).toBe(height)
      for (const row of rows) expect(row.length).toBeLessThanOrEqual(width)
      const directory = rows[height - 2]
      expect(directory).toContain('dsh')
      const lip = rows.findIndex(row => row.includes('▀'))
      expect(lip).toBe(height - 3)

      // The chips own the first row at every width: there is no rail breakpoint, because
      // upstream's default layout is the horizontal strip.
      expect(rows[0]).toContain(' + ')
      // The chips survive every width; their titles are cut to the share the row allows, so
      // the assertion is the number cell, not the full title.
      expect(rows[0]).toMatch(/\d first prompt|\d first/)

      // The sidebar stays closed in the matrix: an overlay at 40 columns covers the screen,
      // so the region order and the bar fit are asserted without it. The sidebar's own
      // breakpoints are asserted in the overlay tests below.
      const sidebar = rowIndex(rows, 'Context')
      expect(sidebar).toBe(-1)

      // The bar's padding follows the content floor: 1 cell below 44, 2 cells at and above.
      // The hint yields before the directory does, so the row is not padded to the edge at
      // every width: assert the indent and that nothing runs past the grid instead.
      const pad = width < 44 ? 1 : 2
      expect(directory!.slice(0, pad).trim()).toBe('')
      expect(directory!.length).toBeLessThanOrEqual(width)
    })
  }
}

test('the six sections ride the pane at every width the overlay opens', async () => {
  const store = richStore()
  store.toggleSidebar()
  // The pane no longer drops sections on narrow grids: every width paints the same six
  // headers, and a section with no data shows its empty-state line instead of disappearing.
  for (const width of [60, 64, 80] as const) {
    const rows = await paint(store, width, 40)
    for (const header of ['context', 'wechat', 'MCP', 'TODO', 'subagents', 'background tasks']) {
      expect(rowIndex(rows, header)).toBeGreaterThan(-1)
    }
  }
  // The footer's provider line keeps its 64-column breakpoint.
  expect((await paint(store, 64)).some(row => row.includes('cliproxy/mimo-v2.6-pro'))).toBe(true)
  expect((await paint(store, 60)).some(row => row.includes('cliproxy/mimo-v2.6-pro'))).toBe(false)
})

test('a long sidebar inventory scrolls inside the pane without pushing its title or footer out', async () => {
  // The pane's body is its own scrollbox: 40 MCP rows must not grow the frame, evict the
  // session title at the top, or push the route/workspace/branch footer off the bottom.
  const store = richStore()
  store.apply({
    protocolVersion: 2,
    seq: 6,
    kind: 'mcp-servers',
    payload: { servers: Array.from({ length: 40 }, (_, index) => ({ id: `mcp-${index}`, name: `server-${index}`, status: 'active' })) },
  } as never)
  store.toggleSidebar()
  const rows = await paint(store, 168, 24)
  expect(rows.length).toBe(24)
  // The title row and the footer card survive the long list.
  expect(rows.join('\n')).toContain('first prompt')
  expect(rows.join('\n')).toContain('cliproxy/mimo-v2.6-pro')
  // The list is clipped: the last entries are below the fold, not painted over the footer.
  expect(rows.join('\n')).not.toContain('server-39')
  expect(rows.join('\n')).toContain('server-0')
})

test('the sidebar docks once the terminal clears the dock rule', async () => {
  const store = richStore()
  store.toggleSidebar()
  const wide = await paint(store, 168)
  // With no rail to subtract, the dock rule is `width > 120`: the pane docks inside the grid,
  // the bar still carries the cwd, and the sidebar content sits in the grid.
  expect(wide[wide.length - 2]).toContain('Projects/dsh')
  expect(rowIndex(wide, 'context')).toBeGreaterThan(-1)
  expect(wide.some(row => row.includes('cliproxy/mimo-v2.6-pro'))).toBe(true)
})

test('the wordmark follows the native three-way breakpoint and the 12-row floor', async () => {
  // Side by side at 44+ (four rows), stacked between 22 and 43 (seven rows), compact under 22
  // (three rows), and absent on a short terminal.
  expect(logoHeight(120, 24)).toBe(4)
  expect(logoHeight(44, 24)).toBe(4)
  expect(logoHeight(43, 24)).toBe(7)
  expect(logoHeight(22, 24)).toBe(7)
  expect(logoHeight(21, 24)).toBe(3)
  expect(logoHeight(120, 11)).toBe(0)
  // A fresh store: the route is initialized from the first snapshot's `initialRoute`, so a
  // session-route snapshot applied earlier would keep the shell on the session page.
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 9, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'home', title: 't', events: [], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } } as never)
  const rows = await paint(store, 120, 40)
  const frame = rows.join('\n')
  // The lockup's own glyph row: the four-row table, painted with half-block shading.
  expect(frame).toContain('█▀▀█')
  expect(frame).toContain('█▀▀▀')
})

test('the brand matrix covers the exact logo and height breakpoints', async () => {
  // 21/22 is the stacked/compact boundary and 43/44 the side-by-side one; 11/12 is the
  // height floor. Each pair is painted and read back from the grid.
  for (const [width, height] of [[21, 3], [22, 7], [43, 7], [44, 4]] as const) {
    // The reserved geometry is the layout contract; the painted grid also switches branch,
    // which the glyph row below asserts.
    expect(logoHeight(width, 24)).toBe(height)
    const store = createAppStore()
    store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'home', title: 't', events: [], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } } as never)
    const frame = (await paint(store, width, 24)).join('\n')
    // The lockup paints at least its glyph rows above the prompt; the compact branch's `▀▀▀`
    // bottom row is the marker that the narrow table was used.
    expect(/[█▀▄]/.test(frame)).toBe(true)
    if (width >= 22) expect(frame).toContain('█▀▀')
  }
  // The 12-row floor applies to the route, not the terminal: the pinned metrics row is
  // reserved first, so a 12-row terminal leaves the Home route 11 rows (no wordmark) and a
  // 13-row one leaves 12 (wordmark). The cwd row is part of the route now (it follows the
  // prompt), so it takes nothing from the reservation.
  const short = createAppStore()
  short.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'home', title: 't', events: [], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } } as never)
  const eleven = (await paint(short, 120, 12)).join('\n')
  expect(/█▀▀█/.test(eleven)).toBe(false)
  const twelve = createAppStore()
  twelve.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'home', title: 't', events: [], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } } as never)
  expect(/█▀▀█/.test((await paint(twelve, 120, 13)).join('\n'))).toBe(true)
})

test('Home keeps the cwd row under the prompt and the metrics row on the bottom edge', async () => {
  // The two information rows have different homes: the cwd/hint row rides the prompt stack,
  // so on a landing page it sits directly under the panel instead of falling to the frame's
  // bottom, while the metrics row stays the last painted row.
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'home', title: 't', events: [], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } } as never)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'usage', payload: { sessionId: 'ses_1', inputTokens: 1200, outputTokens: 300, cacheReadTokens: 0, cacheWriteTokens: 0, cacheBucketsComplete: true, contextTokens: 2000, contextWindow: 262144, contextPct: 1 } } as never)
  const rows = await paint(store, 100, HEIGHT)
  // The wordmark also paints `▀`, so the lip is the last such row: the panel sits under it.
  const lip = rows.findLastIndex(row => row.includes('▀'))
  const cwd = rows.findIndex(row => row.includes('D:/Projects/dsh'))
  expect(lip).toBeGreaterThan(0)
  expect(cwd).toBe(lip + 1)
  expect(rows[cwd]).toContain('ctrl+p commands')
  // The metrics row is the frame's last row, well below the floating prompt.
  expect(rows[HEIGHT - 1]).toContain('tokens')
  expect(HEIGHT - 1 - cwd).toBeGreaterThan(3)
})

test('the sidebar docks past 120 columns and overlays at 120', async () => {
  // The dock rule is a pure function of the width (no rail to subtract): 121 docks, 120 does not.
  expect(sidebarDocked(121, 0)).toBe(true)
  expect(sidebarDocked(120, 0)).toBe(false)
  for (const width of [120, 121]) {
    const store = richStore()
    store.toggleSidebar()
    const rows = await paint(store, width)
    // Both forms paint the same blocks; only the placement differs (docked in the grid, or
    // the right-aligned overlay), and neither overflows the terminal.
    expect(rows.join('\n')).toContain('context')
    for (const row of rows) expect(row.length).toBeLessThanOrEqual(width + 1)
  }
})

/** A store with the data every sidebar section needs, painted with the pane docked. */
function sidebarStore(): AppStore {
  const store = storeWith(2)
  store.apply({ protocolVersion: 2, seq: 3, kind: 'usage', payload: { sessionId: 'ses_1', inputTokens: 12000, outputTokens: 3400, cacheReadTokens: 8000, cacheWriteTokens: 200, cacheBucketsComplete: true, contextTokens: 247100, contextWindow: 1000000, contextPct: 25, cost: 0.12, currency: 'USD', costSource: 'local' } } as never)
  store.apply({ protocolVersion: 2, seq: 4, kind: 'mcp-servers', payload: { servers: [{ id: 'a', name: 'dsh-review', status: 'active' }, { id: 'b', name: 'slow-server', status: 'failed' }] } } as never)
  store.apply({ protocolVersion: 2, seq: 5, kind: 'wechat-output', payload: { kind: 'status', text: 'wechat: connected', status: { available: true, connected: true, accounts: { connected: 1, total: 1 }, lock: { held: true } } } } as never)
  store.apply({ protocolVersion: 2, seq: 6, kind: 'todos', payload: { sessionId: 'ses_1', items: [{ content: 'wire the pane', status: 'completed' }, { content: 'price the turn', status: 'in_progress' }, { content: 'ship it', status: 'pending' }] } } as never)
  store.apply({ protocolVersion: 2, seq: 7, kind: 'host-plugins', payload: { plugins: [{ id: 'p1', moduleName: 'plugin-should-not-paint', enabled: true, fiberPhase: 'active' }] } } as never)
  store.toggleSidebar()
  return store
}

test('the sidebar paints six sections in order and no plugin inventory', async () => {
  const rows = await paint(sidebarStore(), 168, 40)
  const text = rows.join('\n')
  const at = (needle: string): number => rows.findIndex(row => row.includes(needle))
  // Order is fixed: context, wechat, mcp, todo, subagents, background tasks.
  const order = ['context', 'wechat', 'MCP', 'TODO', 'subagents', 'background tasks'].map(needle => at(needle))
  for (const index of order) expect(index).toBeGreaterThan(0)
  expect([...order].sort((left, right) => left - right)).toEqual(order)
  // The plugin inventory left the pane; the protocol channel still feeds nothing here.
  expect(text).not.toContain('Plugins')
  expect(text).not.toContain('plugin-should-not-paint')
})

test('the sidebar sections carry their data and their empty states', async () => {
  const rows = await paint(sidebarStore(), 168, 40)
  const text = rows.join('\n')
  // Context: the turn's context use, the token total with the cache share, and the amount.
  expect(text).toContain('CTX 247.1k')
  expect(text).toContain('SUM 23.6k (40% cache)')
  expect(text).toContain('$ 0.12')
  // WeChat: two structured lines instead of one concatenated string.
  expect(text).toContain('connected (1/1)')
  expect(text).toContain('lock: this process')
  // MCP: one row per server, lifecycle word, not a guessed "connected".
  expect(text).toContain('MCP (2)')
  expect(text).toContain('dsh-review')
  expect(text).toContain('running')
  expect(text).toContain('failed')
  // TODO: the counter and the status symbols.
  expect(text).toContain('TODO (1/3)')
  expect(text).toContain('● wire the pane')
  expect(text).toContain('◐ price the turn')
  expect(text).toContain('○ ship it')
  // Subagents and background tasks are folded by default: only their headers paint.
  expect(text).toContain('subagents')
  expect(text).toContain('background tasks')
})

test('an unpriced model explains the missing cost in the sidebar', async () => {
  const store = sidebarStore()
  store.apply({ protocolVersion: 2, seq: 8, kind: 'usage', payload: { sessionId: 'ses_1', inputTokens: 12000, outputTokens: 3400, cacheReadTokens: 8000, cacheWriteTokens: 200, cacheReadComplete: true, contextTokens: 247100, contextWindow: 1000000, contextPct: 25, costUnavailable: true } } as never)
  const text = (await paint(store, 168, 30)).join('\n')
  expect(text).toContain('$ 未配置模型价格')
})

test('an empty sidebar shows every section with its empty-state line', async () => {
  const store = storeWith(0)
  store.toggleSidebar()
  const rows = await paint(store, 168, 30)
  const text = rows.join('\n')
  expect(text).toContain('context')
  expect(text).toContain('wechat')
  expect(text).toContain('unavailable')
  expect(text).toContain('no MCP servers')
  expect(text).toContain('no todos')
  expect(text).toContain('subagents')
  expect(text).toContain('background tasks')
  // Folded by default, so the empty-state lines are not painted until each section opens.
  expect(text).not.toContain('no subagents')
  expect(text).not.toContain('no running background tasks')
})

test('clicking a section header collapses and expands it', async () => {
  const store = sidebarStore()
  if (!store.hasLocalStorage()) store.setLocalStorage(createMemoryStorage())
  const setup = await testRender(() => <Shell store={store} />, { width: 168, height: 30 })
  for (let pass = 0; pass < 4; pass++) {
    await Bun.sleep(40)
    setup.renderer.requestRender?.()
  }
  const read = (): string[] => {
    const rows = setup.captureCharFrame().split('\n')
    if (rows[rows.length - 1] === '') rows.pop()
    return rows
  }
  expect(read().join('\n')).toContain('dsh-review')
  // The MCP header is the click target: 40-cell pane, so its rows sit in the right columns.
  const header = read().findIndex(row => row.includes('MCP ('))
  const column = read()[header]?.indexOf('MCP (') ?? 0
  await setup.mockMouse.click(column + 2, header)
  for (let pass = 0; pass < 3; pass++) {
    await Bun.sleep(40)
    setup.renderer.requestRender?.()
  }
  const collapsed = read().join('\n')
  expect(collapsed).toContain('▸ MCP')
  expect(collapsed).not.toContain('dsh-review')
  setup.renderer.destroy()
})

test('the bar shrinks into the content column when a pane docks', async () => {
  // The bar is the shell's last child, but it has to line up with the composer's column: with
  // a docked pane it spans `contentWidth()` only, so its left padding starts at the prompt's
  // left edge and its metrics line is centred in that column (not in the whole terminal).
  const store = richStore()
  store.toggleSidebar()
  const rows = await paint(store, 168, 24)
  const directory = rows[22] ?? ''
  const metrics = rows[23] ?? ''
  // 168 terminal, 40-cell pane: the content column is 126, so 2 cells of padding each side.
  const column = 168 - 40
  // `captureCharFrame` pads every row to the grid, so measurements are taken on the trimmed row.
  expect(directory.trimEnd().length).toBeLessThanOrEqual(column)
  expect(directory.slice(0, 2).trim()).toBe('')
  // The right-aligned hint stops at the column's padding, not the terminal's.
  expect(directory.trimEnd().length).toBe(column - 2)
  const start = metrics.length - metrics.trimStart().length
  const textWidth = metrics.trimEnd().length - start
  expect(textWidth).toBeGreaterThan(0)
  expect(start).toBe(2 + Math.floor((column - 4 - textWidth) / 2))
  expect(start + textWidth).toBeLessThanOrEqual(column - 2)
})

test('the bar follows the content column at the dock threshold and at an extreme pane width', async () => {
  // 121 is the first width that docks; 124 with the pane dragged out to 80 leaves the content
  // column at its 44-cell floor, which is where a naive `width - pane` can go negative.
  for (const [width, pane] of [[121, 40], [124, 80]] as const) {
    const store = richStore()
    // `resizeSidebar` clamps against the host-reported grid, so report it first.
    store.apply({ protocolVersion: 2, seq: 9, kind: 'hello-ack', payload: { protocolVersion: 2, hostId: 'h', hostVersion: '0.5.0', capabilities: [], status: 'compatible', reasons: [], terminalSize: { width, height: 24 } } } as never)
    store.toggleSidebar()
    store.resizeSidebar(pane)
    expect(store.sidebarWidth()).toBe(pane)
    const column = width - pane
    const rows = await paint(store, width, 24)
    const directory = rows[22] ?? ''
    const metrics = rows[23] ?? ''
    expect(rows.length).toBe(24)
    for (const row of rows) expect(row.trimEnd().length).toBeLessThanOrEqual(width)
    // The bar never runs past the content column's right edge.
    expect(directory.trimEnd().length).toBeLessThanOrEqual(column)
    // Exactly two rows and nothing negative or overflowing in the padded lines.
    expect(directory.slice(0, 1).trim()).toBe('')
    const start = metrics.length - metrics.trimStart().length
    const textWidth = metrics.trimEnd().length - start
    expect(start).toBeGreaterThanOrEqual(1)
    expect(start + textWidth).toBeLessThanOrEqual(column)
  }
})

test('the Home completion popup sits flush on its prompt panel', async () => {
  // Home anchors its popup from `panelTop()`, which has to count the prompt wrapper's own
  // padding; one row short left a blank line between the popup and the panel.
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'home', title: 't', events: [], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } } as never)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'workspace-files', payload: { sessionId: 'ses_1', files: ['src/alpha.ts', 'src/beta.ts'] } } as never)
  store.setComposer('@src/')
  const rows = await paint(store, 100, 30)
  const popupRows = rows.flatMap((row, index) => (row.includes('reference') ? [index] : []))
  expect(popupRows.length).toBeGreaterThan(0)
  const draftRow = rows.findIndex(row => row.includes('@src/') && !row.includes('reference'))
  const panelTop = draftRow - 1
  expect(rows[panelTop]?.trimStart().startsWith('┃')).toBe(true)
  expect(panelTop).toBe(Math.max(...popupRows) + 1)
})

test('an untitled session is labelled New Session in the strip', async () => {
  // A blank or never-titled session is a real conversation: the strip shows the label, it
  // does not disappear, and a titled neighbour keeps its own title.
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 0, kind: 'hello-ack', payload: { protocolVersion: 2, hostId: 'h', hostVersion: '0.5.0', capabilities: [], status: 'compatible', reasons: [] } } as never)
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'session', title: '', events: [{ id: 'e1', role: 'user', text: 'hello' }], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } } as never)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-list', payload: { sessions: [{ id: 'ses_1', title: '', active: true }, { id: 'ses_2', title: 'wire the pane', active: false }], current: 'ses_1' } } as never)
  store.openTab('ses_2')
  store.toggleSidebar()
  const rows = await paint(store, 100, 24)
  const strip = rows[0] ?? ''
  expect(strip).toContain('New Session')
  expect(strip).toContain('wire the pane')
  // The pane's title row follows the same rule: it must not fall back to the session id.
  expect(rows.join('\n')).toContain('New Session')
  expect(rows.join('\n')).not.toContain('ses_1')
})

test('the sidebar inventory really scrolls with the wheel', async () => {
  // "Long lists scroll" is a behaviour, not just clipping: the wheel over the pane must move
  // its body while the title and the footer card stay put.
  const store = richStore()
  store.apply({
    protocolVersion: 2,
    seq: 6,
    kind: 'mcp-servers',
    payload: { servers: Array.from({ length: 40 }, (_, index) => ({ id: `mcp-${index}`, name: `plugin-${String(index).padStart(2, '0')}`, status: 'active' })) },
  } as never)
  store.toggleSidebar()
  if (!store.hasLocalStorage()) store.setLocalStorage(createMemoryStorage())
  const setup = await testRender(() => <Shell store={store} />, { width: 168, height: 24 })
  for (let pass = 0; pass < 4; pass++) {
    await Bun.sleep(40)
    setup.renderer.requestRender?.()
  }
  const before = setup.captureCharFrame()
  expect(before).toContain('plugin-00')
  // Wheel over the pane's body column (the sidebar occupies the right 40 cells). Four ticks
  // of the default three-row acceleration walk past the Context/MCP blocks to the tail of
  // the inventory.
  for (let tick = 0; tick < 4; tick++) {
    await setup.mockMouse.scroll(160, 12, 'down')
    for (let pass = 0; pass < 2; pass++) {
      await Bun.sleep(40)
      setup.renderer.requestRender?.()
    }
  }
  const after = setup.captureCharFrame()
  expect(after).not.toBe(before)
  // The body moved: an entry that was below the initial window is now painted.
  expect(after).toContain('plugin-10')
  // The chrome did not move: the session title and the route footer are still painted.
  expect(after).toContain('first prompt')
  expect(after).toContain('cliproxy/mimo-v2.6-pro')
  setup.renderer.destroy()
})

test('Home docks the sidebar by the same rule as the session route', async () => {
  // At 168 columns the pane docks on the session route; Home must split the grid the same
  // way instead of overlaying it, so the landing page's wordmark centres inside the
  // remaining content column rather than in the full terminal.
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'home', title: 'first prompt', events: [], provider: 'cliproxy', model: 'mimo-v2.6-pro', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } } as never)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'mcp-servers', payload: { servers: [{ id: 'mcp-1', name: 'dsh-review' }] } } as never)
  // `auto` already docks at 168 columns, so the baseline has to be the closed state:
  // auto → open → closed.
  store.toggleSidebar()
  store.toggleSidebar()
  const closed = await paint(store, 168, 24)
  expect(closed.join('\n')).not.toContain('dsh-review')
  // One more toggle returns to `auto`, which docks at 168 columns.
  store.toggleSidebar()
  const docked = await paint(store, 168, 24)
  const glyphRow = (rows: string[]): string => rows.map(row => row.slice(0, Math.floor(row.length / 2))).find(row => /[█▀▄]/.test(row)) ?? ''
  const indent = (row: string): number => row.length - row.trimStart().length
  // The lockup is centred in the content column, so docking moves it left by half the pane.
  expect(indent(glyphRow(docked))).toBeLessThan(indent(glyphRow(closed)))
  // The prompt panel is centred in the column too, so its left gutter sits at the column's
  // centre (168 - 40 = 126 wide, 75-cell prompt) rather than the terminal's (which would be
  // column 46). This is the geometry the completion popup is anchored from.
  const promptRow = docked.find(row => row.includes('Ask anything')) ?? ''
  // Column-centred is 26 (terminal-centred would be 46); allow the panel's own 1-cell offset.
  expect(Math.abs(promptRow.indexOf('┃') - Math.floor((128 - 75) / 2))).toBeLessThanOrEqual(1)
  // The pane paints in the grid, and the landing page is still readable beside it.
  expect(docked.join('\n')).toContain('dsh-review')
  expect(docked.join('\n')).toContain('Ask anything')
  // Nothing overflows: the dock took columns from the content, not from the terminal.
  expect(docked.length).toBe(24)
  for (const row of docked) expect(row.length).toBeLessThanOrEqual(168)
})

test('Home keeps the session strip while other sessions stay open', async () => {
  // Upstream mounts the strip in the app shell, outside the Home/Session switch: going back
  // to Home never hides the tabs the user still has open, so a click can return to one.
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'home', title: 'first prompt', events: [{ id: 'e1', role: 'user', text: 'hi' }], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } } as never)
  store.apply({ protocolVersion: 2, seq: 2, kind: 'session-list', payload: { sessions: [{ id: 'ses_1', title: 'first prompt', active: true }, { id: 'ses_2', title: 'second session', active: false }], current: 'ses_1' } } as never)
  store.openTab('ses_2')
  expect(store.route()).toBe('home')
  const rows = await paint(store, 100, 30)
  // Home is the route, and the strip still owns the first row.
  expect(rows.length).toBe(30)
  expect(rows[0]).toContain('first prompt')
  expect(rows[0]).toContain('second session')
  // Home paints below it: the centered prompt keeps its row.
  expect(rows.join('\n')).toContain('Ask anything')
})

test('a tab-less Home paints no strip row', async () => {
  const store = createAppStore()
  store.apply({ protocolVersion: 2, seq: 1, kind: 'session-snapshot', payload: { sessionId: 'ses_1', initialRoute: 'home', title: 't', events: [], provider: 'p', model: 'm', effort: 'high', permission: 'auto', preset: 'standard', workspace: 'D:/Projects/dsh' } } as never)
  const rows = await paint(store, 100, 30)
  // No open tabs: the landing page keeps its clean first row (the logo's top spacer).
  expect(rows[0]?.trim()).toBe('')
  expect(rows.join('\n')).toContain('Ask anything')
})
