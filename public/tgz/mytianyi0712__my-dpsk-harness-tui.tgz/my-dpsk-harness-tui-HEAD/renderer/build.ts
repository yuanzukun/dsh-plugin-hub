/**
 * Renderer build.
 *
 * Runs with Bun (`bun renderer/build.ts`) and compiles the renderer to a
 * single-file executable per platform. Solid JSX is transformed by the
 * `@opentui/solid` bundler plugin; the compiled binary carries the Bun runtime,
 * so users do not need Bun installed.
 *
 * Output names are `dpsk-renderer-<platform>-<arch>[.exe]` under
 * `renderer/dist`, matching `resolveRendererPath` in `src/host/renderer-process.ts`.
 */

import { createRequire } from 'node:module'
import solidPlugin from '@opentui/solid/bun-plugin'

const requireFromHere = createRequire(import.meta.url)
const SOLID_CLIENT = requireFromHere.resolve('solid-js/dist/solid.js')
const SOLID_STORE_CLIENT = requireFromHere.resolve('solid-js/store/dist/store.js')

/** Bun build targets and the platform keys `resolveRendererPath` looks for. */
const TARGETS = [
  { bun: 'bun-windows-x64', key: 'win32-x64' },
  { bun: 'bun-windows-arm64', key: 'win32-arm64' },
  { bun: 'bun-linux-x64', key: 'linux-x64' },
  { bun: 'bun-linux-x64-musl', key: 'linux-x64-musl' },
  { bun: 'bun-linux-arm64', key: 'linux-arm64' },
  { bun: 'bun-darwin-x64', key: 'darwin-x64' },
  { bun: 'bun-darwin-arm64', key: 'darwin-arm64' },
] as const

const only = process.argv[2]
const targets = only === undefined ? TARGETS : TARGETS.filter(target => target.key === only)

for (const target of targets) {
  const result = await Bun.build({
    entrypoints: ['src/main.tsx'],
    target: 'bun',
    format: 'esm',
    // Precompile the renderer's JS graph into bytecode. The sidecar is spawned on every
    // TUI start, so paying compilation at build time removes it from the user-visible
    // launch path; Bun invalidates nothing at runtime because this is a standalone binary.
    bytecode: true,
    plugins: [
      solidPlugin,
      /**
       * `solid-js` resolves to its server build under the `bun`/`node` export condition, and
       * the server build's `createEffect` is a no-op. An `alias` entry is not enough: the
       * bundler then resolves the store's own `import "solid-js"` to a *different* module id
       * than the app's, so a compiled renderer ended up with two signal registries — effects
       * ran once, `createStore` setters notified nobody, and dialogs painted their first
       * frame only. An `onResolve` hook maps every spelling of both specifiers to the same
       * absolute client file, so one registry survives compilation.
       */
      {
        name: 'solid-client',
        setup(build) {
          build.onResolve({ filter: /^solid-js$/ }, () => ({ path: SOLID_CLIENT }))
          build.onResolve({ filter: /^solid-js\/store$/ }, () => ({ path: SOLID_STORE_CLIENT }))
        },
      },
    ],
    compile: {
      target: target.bun,
      outfile: `dist/dpsk-renderer-${target.key}`,
    },
  })
  if (!result.success) {
    console.error(`build failed for ${target.bun}:`)
    for (const log of result.logs) console.error(log)
    process.exit(1)
  }
  console.log(`built dist/dpsk-renderer-${target.key}`)
}
