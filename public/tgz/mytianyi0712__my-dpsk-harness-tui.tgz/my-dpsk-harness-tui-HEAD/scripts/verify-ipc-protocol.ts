/**
 * Renderer protocol gate.
 *
 * Checks the host ↔ renderer contract:
 *
 * 1. The kind lists are disjoint by direction, contain no duplicates, and the
 *    optional subsets are inside their full sets.
 * 2. Every registered kind names a payload interface that is declared in
 *    `src/ipc/kinds.ts`.
 * 3. Every fixture line is a valid envelope at the current protocol version with
 *    a registered kind.
 * 4. Fixture direction: `downstream.ndjson` carries only host → renderer kinds,
 *    `upstream.ndjson` only renderer → host kinds, and `handshake.ndjson` is the
 *    `hello` / `hello-ack` pair in that order.
 * 5. When `renderer/src/protocol/kinds.ts` exists, the renderer-side mirror lists
 *    the same kinds in both directions.
 *
 * Run as `node scripts/verify-ipc-protocol.ts`.
 */

import { existsSync, readFileSync } from 'node:fs'
import { readFile } from 'node:fs/promises'
import { join } from 'node:path'
import {
  DOWNSTREAM_KINDS,
  KIND_PAYLOAD_NAMES,
  OPTIONAL_DOWNSTREAM_KINDS,
  OPTIONAL_UPSTREAM_KINDS,
  UPSTREAM_KINDS,
} from '../src/ipc/kinds.ts'
import { RENDERER_PROTOCOL_VERSION, decodeLine } from '../src/ipc/envelope.ts'

const ROOT = join(import.meta.dirname, '..')
const FIXTURE_DIR = join(ROOT, 'tests', 'ipc', 'fixtures')
const RENDERER_KINDS = join(ROOT, 'renderer', 'src', 'protocol', 'kinds.ts')

const failures: string[] = []

function checkLists(): void {
  const downstream = new Set(DOWNSTREAM_KINDS)
  const upstream = new Set(UPSTREAM_KINDS)
  if (downstream.size !== DOWNSTREAM_KINDS.length) failures.push('DOWNSTREAM_KINDS contains duplicates')
  if (upstream.size !== UPSTREAM_KINDS.length) failures.push('UPSTREAM_KINDS contains duplicates')
  for (const kind of OPTIONAL_DOWNSTREAM_KINDS) {
    if (!downstream.has(kind)) failures.push(`optional downstream kind ${kind} is not in DOWNSTREAM_KINDS`)
  }
  for (const kind of OPTIONAL_UPSTREAM_KINDS) {
    if (!upstream.has(kind)) failures.push(`optional upstream kind ${kind} is not in UPSTREAM_KINDS`)
  }
  for (const kind of downstream) {
    const name = KIND_PAYLOAD_NAMES[kind]
    if (name === undefined) {
      failures.push(`downstream kind ${kind} has no payload interface registered`)
      continue
    }
    const source = readKindsSource()
    if (!source.includes(`interface ${name}`) && !source.includes(`type ${name} `)) failures.push(`payload interface ${name} for kind ${kind} is not declared`)
  }
  for (const kind of upstream) {
    const name = KIND_PAYLOAD_NAMES[kind]
    if (name === undefined) {
      failures.push(`upstream kind ${kind} has no payload interface registered`)
      continue
    }
    const source = readKindsSource()
    if (!source.includes(`interface ${name}`) && !source.includes(`type ${name} `)) failures.push(`payload interface ${name} for kind ${kind} is not declared`)
  }
}

function readKindsSource(): string {
  return readFileSync(join(ROOT, 'src', 'ipc', 'kinds.ts'), 'utf8')
}

async function checkFixtures(): Promise<void> {
  const downstream = new Set<string>(DOWNSTREAM_KINDS)
  const upstream = new Set<string>(UPSTREAM_KINDS)

  const handshake = (await readFixture('handshake.ndjson')).map(line => line.kind)
  if (handshake[0] !== 'hello' || handshake[1] !== 'hello-ack' || handshake.length !== 2) {
    failures.push(`handshake.ndjson must be exactly hello then hello-ack, got: ${handshake.join(', ') || 'empty'}`)
  }

  for (const line of await readFixture('downstream.ndjson')) {
    if (!downstream.has(line.kind)) failures.push(`downstream.ndjson carries a non-downstream kind: ${line.kind}`)
  }
  for (const line of await readFixture('upstream.ndjson')) {
    if (!upstream.has(line.kind)) failures.push(`upstream.ndjson carries a non-upstream kind: ${line.kind}`)
  }
}

async function readFixture(name: string): Promise<Array<{ kind: string; protocolVersion: number }>> {
  const text = await readFile(join(FIXTURE_DIR, name), 'utf8')
  const lines = text.split('\n').filter(line => line.trim() !== '')
  const parsed: Array<{ kind: string; protocolVersion: number }> = []
  for (const line of lines) {
    const { envelope, errors } = decodeLine(line)
    if (envelope === undefined) {
      failures.push(`${name}: malformed envelope line: ${errors.join('; ')}`)
      continue
    }
    if (envelope.protocolVersion !== RENDERER_PROTOCOL_VERSION) {
      failures.push(`${name}: envelope at protocolVersion ${envelope.protocolVersion}, expected ${RENDERER_PROTOCOL_VERSION}`)
      continue
    }
    parsed.push({ kind: envelope.kind, protocolVersion: envelope.protocolVersion })
  }
  return parsed
}

function checkRendererMirror(): string | undefined {
  if (!existsSync(RENDERER_KINDS)) {
    return 'renderer mirror not present yet (renderer/src/protocol/kinds.ts); checked when the renderer scaffold lands'
  }
  const source = readFileSync(RENDERER_KINDS)
  for (const kind of DOWNSTREAM_KINDS) {
    if (!source.includes(`'${kind}'`)) failures.push(`renderer mirror is missing downstream kind ${kind}`)
  }
  for (const kind of UPSTREAM_KINDS) {
    if (!source.includes(`'${kind}'`)) failures.push(`renderer mirror is missing upstream kind ${kind}`)
  }
  return undefined
}

// 6. Wiring: every downstream kind has a host send point (a `send('kind'` literal in
// the host's renderer-facing sources) and a renderer handler (a `case 'kind'` in the
// store's apply switch); every upstream kind has a renderer send point (a `send('kind'`
// literal in the renderer sources) and a host handler (a `case 'kind'` in the mount).
// A declared kind nobody sends or nobody handles is dead protocol, and the gate fails.
function checkWiring(): void {
  const hostSend = [
    join(ROOT, 'src', 'host', 'renderer-mount.ts'),
    join(ROOT, 'src', 'host', 'renderer-process.ts'),
    join(ROOT, 'src', 'index.ts'),
  ].map(path => readFileSync(path, 'utf8')).join('\n')
  const rendererApp = readFileSync(join(ROOT, 'renderer', 'src', 'app.tsx'), 'utf8')
  const rendererMain = readFileSync(join(ROOT, 'renderer', 'src', 'main.tsx'), 'utf8')
  const rendererSources = `${rendererApp}\n${rendererMain}`
  const hostHandler = [
    join(ROOT, 'src', 'host', 'renderer-mount.ts'),
    join(ROOT, 'src', 'host', 'renderer-process.ts'),
  ].map(path => readFileSync(path, 'utf8')).join('\n')
  const handles = (source: string, kind: string): boolean =>
    source.includes(`case '${kind}'`) || source.includes(`kind === '${kind}'`)
  for (const kind of DOWNSTREAM_KINDS) {
    // A send point is any call passing the kind literal as the first argument:
    // `send('kind'`, `handle.send('kind'`, `rendererSend?.('kind'`.
    if (!hostSend.includes(`('${kind}'`)) failures.push(`downstream kind ${kind} has no host send point`)
    if (!handles(rendererApp, kind) && !handles(rendererMain, kind)) failures.push(`downstream kind ${kind} has no renderer handler`)
  }
  for (const kind of UPSTREAM_KINDS) {
    if (!rendererSources.includes(`'${kind}'`)) failures.push(`upstream kind ${kind} has no renderer send point`)
    if (!handles(hostHandler, kind)) failures.push(`upstream kind ${kind} has no host handler`)
  }
}

checkWiring()
checkLists()
await checkFixtures()
const note = checkRendererMirror()

if (failures.length > 0) {
  console.error('verify:ipc-protocol failed — renderer protocol drifted:')
  for (const failure of failures) console.error(`  ${failure}`)
  process.exit(1)
}

const message = `verify:ipc-protocol ok (protocol v${RENDERER_PROTOCOL_VERSION}, ${DOWNSTREAM_KINDS.length} downstream kinds, ${UPSTREAM_KINDS.length} upstream kinds, 3 fixtures)`
console.log(note === undefined ? message : `${message} — ${note}`)
