// Local daemon client: identity, control requests, and the renderer IPC proxy.
import { spawn } from 'node:child_process'
import crypto from 'node:crypto'
import fs from 'node:fs'
import net from 'node:net'
import os from 'node:os'
import path from 'node:path'

const isWin = process.platform === 'win32'

export function configHome() {
  const explicit = process.env.MYDPSK_CONFIG_HOME?.trim()
  return explicit === undefined || explicit === '' ? path.join(os.homedir(), '.config', '.mydpsk') : explicit
}

export function daemonRuntimePaths() {
  const home = configHome()
  const runtime = path.join(home, 'runtime')
  const key = crypto.createHash('sha256').update(home).digest('hex').slice(0, 16)
  return {
    runtime,
    socket: isWin ? '\\\\.\\pipe\\dpsk-' + key : path.join(runtime, 'daemon.sock'),
    token: path.join(runtime, 'daemon.token'),
    pid: path.join(runtime, 'daemon.pid'),
    log: path.join(runtime, 'core.log'),
  }
}

export function readDaemonToken(paths = daemonRuntimePaths()) {
  try {
    const token = fs.readFileSync(paths.token, 'utf8').trim()
    return token === '' ? undefined : token
  } catch {
    return undefined
  }
}

/** Authenticate one control/attach request and return the ready socket plus leftover lines. */
export function connectDaemon(type, timeout = 2_000) {
  return new Promise((resolve, reject) => {
    const paths = daemonRuntimePaths()
    const token = readDaemonToken(paths)
    if (token === undefined) {
      reject(new Error('daemon token missing'))
      return
    }
    const socket = net.connect(paths.socket)
    socket.setEncoding('utf8')
    let buffer = ''
    let settled = false
    let timer
    const finish = value => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      if (value.error !== undefined) {
        socket.destroy()
        reject(value.error)
        return
      }
      resolve({ socket, buffer, paths })
    }
    timer = setTimeout(() => finish({ error: new Error('daemon did not answer') }), timeout)
    timer.unref?.()
    const onData = chunk => {
      buffer += chunk
      for (;;) {
        const newline = buffer.indexOf('\n')
        if (newline === -1) return
        const line = buffer.slice(0, newline).trim()
        buffer = buffer.slice(newline + 1)
        if (line === '') continue
        let message
        try { message = JSON.parse(line) } catch { finish({ error: new Error('daemon sent malformed JSON') }); return }
        if (message.type === 'error') { finish({ error: new Error(typeof message.message === 'string' ? message.message : 'daemon rejected the request') }); return }
        if (message.type === 'ready' || message.type === 'ok') {
          socket.removeListener('data', onData)
          finish({ socket, buffer })
          return
        }
      }
    }
    socket.on('data', onData)
    socket.once('connect', () => socket.write(JSON.stringify({ type, token }) + '\n'))
    socket.on('error', error => finish({ error }))
    socket.once('close', () => finish({ error: new Error('daemon closed the connection') }))
  })
}

export async function daemonAlive(timeout = 1_000) {
  try {
    const connection = await connectDaemon('ping', timeout)
    connection.socket.end()
    return true
  } catch {
    return false
  }
}

function winQuote(arg) {
  return String.fromCharCode(34) + arg.split(String.fromCharCode(34)).join(String.fromCharCode(34,34)) + String.fromCharCode(34)
}


const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))

export async function waitForDaemon(timeout = 10_000) {
  const deadline = Date.now() + timeout
  while (Date.now() < deadline) {
    if (await daemonAlive(400)) return true
    await sleep(100)
  }
  return false
}

export async function startDaemon(options) {
  if (await daemonAlive(400)) return daemonRuntimePaths()
  const paths = daemonRuntimePaths()
  fs.mkdirSync(paths.runtime, { recursive: true })
  const cwd = options.cwd ?? process.cwd()
  let child
  let spawnError
  if (isWin) {
    // A detached cmd.exe child gets a visible console window on Windows. Start the
    // core through wscript with window style 0 so the background daemon stays hidden.
    const cmdPath = path.join(paths.runtime, 'daemon-start.cmd')
    const vbsPath = path.join(paths.runtime, 'daemon-start.vbs')
    const command = [options.backend, ...options.args].map(winQuote).join(' ')
    fs.writeFileSync(cmdPath, [
      '@echo off',
      'cd /d ' + winQuote(cwd) + ' || exit /b 1',
      command + ' >> ' + winQuote(paths.log) + ' 2>&1',
      '',
    ].join('\r\n'))
    fs.writeFileSync(vbsPath, [
      'Dim sh, q',
      'q = Chr(34)',
      'Set sh = CreateObject("WScript.Shell")',
      'sh.Run q & WScript.Arguments(0) & q, 0, False',
      '',
    ].join('\r\n'))
    const wscript = path.join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'wscript.exe')
    child = spawn(wscript, ['//B', '//NoLogo', vbsPath, cmdPath], {
      detached: true,
      windowsHide: true,
      stdio: 'ignore',
      cwd,
      env: { ...process.env, DPSK_DAEMON: '1' },
    })
  } else {
    const fd = fs.openSync(paths.log, 'a')
    try {
      child = spawn(options.backend, options.args, {
        detached: true,
        stdio: ['ignore', fd, fd],
        cwd,
        env: { ...process.env, DPSK_DAEMON: '1' },
      })
    } finally {
      fs.closeSync(fd)
    }
  }
  child.on('error', error => { spawnError = error })
  child.unref()
  if (await waitForDaemon(options.timeout ?? 10_000)) return paths
  if (spawnError !== undefined) throw spawnError
  const detail = child.exitCode === null ? '' : ' (exit code ' + String(child.exitCode) + ')'
  throw new Error('daemon did not become ready' + detail)
}

export async function stopDaemon(timeout = 5_000) {
  if (!await daemonAlive(400)) return false
  try {
    const connection = await connectDaemon('shutdown')
    connection.socket.end()
  } catch {
    return false
  }
  const deadline = Date.now() + timeout
  while (Date.now() < deadline) {
    if (!await daemonAlive(300)) return true
    await sleep(100)
  }
  return false
}

const TERMINAL_RESTORE = '\x1b[0m\x1b[?1000l\x1b[?1002l\x1b[?1003l\x1b[?1006l\x1b[?2004l\x1b[?2027l\x1b[?2031l\x1b[2J\x1b[H\x1b[?1049l\x1b[?25h'

/** Spawn the renderer on this TTY and proxy its IPC frames to the daemon socket. */
export async function attachDaemon(rendererPath) {
  const connection = await connectDaemon('attach')
  const socket = connection.socket
  const child = spawn(rendererPath, [], { stdio: ['inherit', 'inherit', 'ipc'], env: process.env, windowsHide: true })
  let buffer = connection.buffer
  let childExited = false
  let finished = false
  const sendWire = value => {
    if (socket.destroyed || !socket.writable) return
    try { socket.write(JSON.stringify(value) + '\n') } catch { /* detach is normal */ }
  }
  const finish = (code = 0) => {
    if (finished) return
    finished = true
    if (!socket.destroyed) {
      try { socket.write(JSON.stringify({ type: 'detach' }) + '\n') } catch { /* ignore */ }
      socket.end()
    }
    if (!childExited) {
      try { child.kill() } catch { /* ignore */ }
    }
    process.exit(code)
  }
  const recover = () => {
    try { process.stdout.write(TERMINAL_RESTORE) } catch { /* ignore */ }
    finish(0)
  }
  const consume = chunk => {
    buffer += chunk
    for (;;) {
      const newline = buffer.indexOf('\n')
      if (newline === -1) return
      const line = buffer.slice(0, newline).trim()
      buffer = buffer.slice(newline + 1)
      if (line === '') continue
      let message
      try { message = JSON.parse(line) } catch { continue }
      if (message.type === 'message' && typeof message.data === 'string') {
        try { child.send(message.data) } catch { /* renderer is leaving */ }
      } else if (message.type === 'error') {
        process.stderr.write('dpsk: daemon error: ' + String(message.message ?? 'unknown') + '\n')
        recover()
      }
    }
  }
  if (buffer !== '') consume('')
  socket.on('data', consume)
  socket.on('error', recover)
  socket.on('close', () => setTimeout(recover, 50))
  child.on('message', data => sendWire({ type: 'message', data: String(data) }))
  child.on('error', error => {
    process.stderr.write('dpsk: renderer failed: ' + error.message + '\n')
    recover()
  })
  child.on('exit', code => {
    childExited = true
    finish(code ?? 0)
  })
  process.on('SIGINT', () => undefined)
  process.on('SIGTERM', () => undefined)
  return new Promise(() => undefined)
}



