/**
 * Renderer artifact manifest.
 *
 * Writes `SHA256SUMS.json` listing every compiled renderer binary under
 * `renderer/dist` with its SHA-256 and byte size. The launcher downloads one
 * artifact for the running platform and verifies the hash before it caches the
 * binary, so a truncated or tampered download never reaches the TTY.
 *
 * Run as `node scripts/generate-sha256sums.mjs` after `npm run build:renderer`.
 * The CI release job uploads the artifacts and this manifest as release assets.
 */

import { createHash } from 'node:crypto'
import { existsSync, readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const root = process.cwd()
const dist = join(root, 'renderer', 'dist')
const version = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')).version

if (!existsSync(dist)) {
  process.stderr.write('SHA256SUMS: renderer/dist is missing. Run `npm run build:renderer` first.\n')
  process.exit(1)
}

const names = readdirSync(dist).filter(name => name.startsWith('dpsk-renderer-')).sort()
if (names.length === 0) {
  process.stderr.write('SHA256SUMS: no renderer artifacts in renderer/dist.\n')
  process.exit(1)
}

const files = {}
for (const name of names) {
  const path = join(dist, name)
  const bytes = readFileSync(path)
  files[name] = {
    sha256: createHash('sha256').update(bytes).digest('hex'),
    size: statSync(path).size,
  }
}

const manifest = { version, generatedAt: new Date().toISOString(), files }
writeFileSync(join(root, 'SHA256SUMS.json'), `${JSON.stringify(manifest, null, 2)}\n`, 'utf8')
process.stdout.write(`SHA256SUMS.json: ${Object.keys(files).length} artifacts, version ${version}\n`)
