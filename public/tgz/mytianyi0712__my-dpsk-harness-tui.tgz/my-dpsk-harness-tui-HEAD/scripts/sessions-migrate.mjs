// 会话格式迁移：把旧构建写下的 `session.jsonl.zstd`（header `version: 0`）转成当前
// 运行时能读的 `session.v4.jsonl.zstd`（header `version: 4`）。
//
// 两个不兼容点，都在 dsh 的读取校验里写死：
//   1. header 必须是 `version: 4` 且 `isSeeded` 为布尔；v0 的头两样都不满足。
//   2. 日志里出现当前构建不认识的事件类型时，读取会拒绝——除非该事件带
//      `ignorable: true`（`@deepseek-ai/dsh-session` 的兼容约定）。旧构建写下的
//      `assistant/chunk` / `text-chunks` / `reasoning-chunks` 就是这一类增量帧，
//      它们的最终内容已经落在 `assistant/message` 里。
//
// 所以迁移只做两件事：补全 header、给当前构建不认识的事件打上 `ignorable`，
// 事件本身一条不丢。原文件保留为 `session.jsonl.zstd.legacy-<时间戳>`。

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import process from 'node:process'
import { randomUUID } from 'node:crypto'
import { createRequire } from 'node:module'
import { validateStoredEvents } from '@deepseek-ai/dsh-session-persistence'
import zlib from 'node:zlib'

export const LEGACY_FILE = 'session.jsonl.zstd'
export const V4_FILE = 'session.v4.jsonl.zstd'

/** zstd 每条事件一帧，单次 `zstdDecompressSync` 只能解出第一帧。 */
export function decodeAllFrames(raw) {
  const starts = []
  for (let i = 0; i < raw.length - 3; i += 1) {
    if (raw[i] === 0x28 && raw[i + 1] === 0xb5 && raw[i + 2] === 0x2f && raw[i + 3] === 0xfd) starts.push(i)
  }
  let text = ''
  for (let index = 0; index < starts.length; index += 1) {
    const from = starts[index]
    const to = starts[index + 1] ?? raw.length
    try {
      text += zlib.zstdDecompressSync(raw.subarray(from, to)).toString('utf8')
    } catch {
      // 压缩数据里偶然出现的 magic 不是帧，跳过。
    }
  }
  return text
}

export function encodeSession(lines) {
  return zlib.zstdCompressSync(Buffer.from(`${lines.join('\n')}\n`, 'utf8'))
}

/**
 * 当前构建认识哪些事件类型，以安装的 `@deepseek-ai/dsh-session` 为准：该模块的运行时
 * 导出里没有这份目录（生成物被擦除），但源码里有全部类型字面量，所以按字面量判断。
 * 这样迁移逻辑跟着 dsh 升级自动更新，不在本仓库硬编码一份会过期的名单。
 */
export function knownEventTypeMatcher() {
  try {
    const require = createRequire(import.meta.url)
    const entry = require.resolve('@deepseek-ai/dsh-session')
    const source = fs.readFileSync(entry, 'utf8')
    return type => source.includes(`"${type}"`) || source.includes(`'${type}'`)
  } catch {
    return () => true
  }
}

export function readSessionFile(file) {
  const text = decodeAllFrames(fs.readFileSync(file))
  const lines = text.split('\n').filter(line => line.trim() !== '')
  const header = JSON.parse(lines[0])
  if (header?.type !== 'session') throw new Error('first line is not a session header')
  const events = []
  const errors = []
  for (const line of lines.slice(1)) {
    try {
      events.push(JSON.parse(line))
    } catch (error) {
      errors.push(error instanceof Error ? error.message : String(error))
    }
  }
  return { header, events, errors }
}

/**
 * v4 的逐事件规则，只处理会导致读取被拒的那几条。
 *
 * `request/header` 在 v0 里把 system prompt 存在 `data.header.system`；v4 要求该字段必须
 * 不存在（system prompt 改由 `system/message` 事件承载）。这里删掉它：这份 header 是对
 * 历史请求的快照，恢复会话时新的请求会按当前预设重新构建。
 */
/** 这些事件落在会话面上，v4 要求每条都带 `surfaceOp`。 */
const SURFACE_EVENT_TYPES = new Set(['user/message', 'assistant/message', 'tool/result', 'system/message'])

export function normalizeEvent(input, lookupSeq = () => undefined) {
  // 会话面（surface）上的消息事件在 v4 里必须带 surfaceOp 标记，缺了整条被拒；v0 偶尔把
  // 整个对象写进这个字段，读回来不是字符串。两者都退化成追加，且必须在分支之前处理。
  const needsSurfaceOp = SURFACE_EVENT_TYPES.has(input?.type)
  const brokenSurfaceOp = input?.surfaceOp !== undefined && input.surfaceOp !== 'append'
  const event = brokenSurfaceOp || (needsSurfaceOp && input?.surfaceOp === undefined)
    ? { ...input, surfaceOp: 'append' }
    : input
  const type = event?.type
  if (type === 'request/header') {
    const header = event.data?.header
    if (header === undefined || header === null) return event
    const nextHeader = { ...header }
    let changed = false
    if (nextHeader.system !== undefined) {
      delete nextHeader.system
      changed = true
    }
    // v4 拒绝空的 tools 数组（「must omit empty tools」）：没有工具的请求根本不带这个字段。
    if (Array.isArray(nextHeader.tools) && nextHeader.tools.length === 0) {
      delete nextHeader.tools
      changed = true
    }
    return changed ? { ...event, data: { ...event.data, header: nextHeader } } : event
  }
  // v0 把工具结果的 message 记成 `role: "user"`（它是发给模型的一条用户侧消息），
  // v4 的读取校验要求 role 必须是 `"tool"`；带 `error` 的结果还必须标 `isError`。
  if (type === 'tool/result') {
    const data = event.data ?? {}
    const message = data.message
    if (message === undefined || message === null) return event
    // v4 的结果消息带一个与 `source.callId` 相同的 `toolCallId`，`isError` 恒为布尔，
    // 且 `source` 必须是工具来源（v0 里偶尔缺 `source` 或写成别的 kind）。
    const ref = Array.isArray(event.sourceEventSeqs) ? event.sourceEventSeqs[0] : undefined
    const paired = typeof ref === 'number' ? lookupSeq(ref) : undefined
    const callId = message.source?.callId
      || message.toolCallId
      || paired?.data?.callId
      || paired?.data?.message?.toolCallId
      || undefined
    // 没有 call id 的结果行无法归属到任何一次调用（v0 里出现过空串），v4 会拒绝整条日志。
    // 这类行是「工具根本不存在」的失败记录，丢弃它不影响会话内容。
    if (callId === undefined || callId === '') return undefined
    const nextMessage = { ...message, role: 'tool', isError: data.error !== undefined, toolCallId: callId, source: { kind: 'tool', callId } }
    // v4 的每条消息都要有 id，缺了读取会拒整条日志；旧记录偶尔没有。
    if (typeof nextMessage.id !== 'string' || nextMessage.id === '') nextMessage.id = randomUUID()
    return { ...event, data: { ...data, message: nextMessage } }
  }
  // v0 的 `assistant/message` 记录了它由哪些增量事件拼成；v4 要求它自包含，不允许该字段。
  if (type === 'assistant/message') {
    const data = event.data ?? {}
    if (data.sourceEventSeqs === undefined && event.sourceEventSeqs === undefined) return event
    const nextData = { ...data }
    delete nextData.sourceEventSeqs
    const next = { ...event, data: nextData }
    delete next.sourceEventSeqs
    return next
  }
  return event
}

/**
 * v0 → v4。返回新的行数组与被标记为 `ignorable` 的事件类型统计。
 * 不删事件：`assistant/message` 已含最终内容，增量帧留着只是没人再读。
 */
export function migrateRecord(record, isKnown = () => true) {
  const header = { ...record.header, version: 4, isSeeded: record.header.isSeeded ?? false }
  delete header.seedLength
  const marked = new Map()
  const dropped = new Map()
  const bySeq = new Map(record.events.filter(event => typeof event?.seq === 'number').map(event => [event.seq, event]))
  const lines = [JSON.stringify(header)]
  let rewrote = 0
  for (const event of record.events) {
    if (event?.type === 'session') continue
    const normalized = normalizeEvent(event, seq => bySeq.get(seq))
    if (normalized === undefined) {
      dropped.set(event.type, (dropped.get(event.type) ?? 0) + 1)
      continue
    }
    if (normalized !== event) rewrote += 1
    const known = isKnown(normalized.type)
    if (!known) marked.set(normalized.type, (marked.get(normalized.type) ?? 0) + 1)
    lines.push(JSON.stringify(known || normalized.ignorable === true ? normalized : { ...normalized, ignorable: true }))
  }
  return { lines, marked, dropped, rewrote, events: lines.length - 1 }
}

function walkSessionDirs(root) {
  const dirs = []
  const stack = [root]
  while (stack.length > 0) {
    const dir = stack.pop()
    let entries
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true })
    } catch {
      continue
    }
    const hasSessionFile = entries.some(entry => entry.isFile() && (entry.name === LEGACY_FILE || entry.name === V4_FILE))
    if (hasSessionFile) dirs.push(dir)
    for (const entry of entries) if (entry.isDirectory()) stack.push(path.join(dir, entry.name))
  }
  return dirs
}

export function surveySessions(root) {
  const report = { v4: [], legacy: [], broken: [] }
  for (const dir of walkSessionDirs(root)) {
    const v4 = path.join(dir, V4_FILE)
    const legacy = path.join(dir, LEGACY_FILE)
    const target = fs.existsSync(v4) ? v4 : legacy
    try {
      const record = readSessionFile(target)
      const entry = { dir, file: target, version: record.header.version, events: record.events.length, errors: record.errors.length }
      if (record.header.version === 4) report.v4.push(entry)
      else report.legacy.push(entry)
    } catch (error) {
      report.broken.push({ dir, file: target, error: error instanceof Error ? error.message : String(error) })
    }
  }
  return report
}

export function migrateSessionDir(dir, options = {}) {
  const { dryRun = false, now = Date.now(), isKnown = () => true } = options
  const legacy = path.join(dir, LEGACY_FILE)
  const v4 = path.join(dir, V4_FILE)
  if (!fs.existsSync(legacy)) return { status: 'skipped', reason: 'no legacy file' }
  const record = readSessionFile(legacy)
  if (record.header.version === 4) return { status: 'skipped', reason: 'already v4' }
  const migrated = migrateRecord(record, isKnown)
  if (!dryRun) {
    if (fs.existsSync(v4)) fs.renameSync(v4, `${v4}.replaced-${now}`)
    fs.renameSync(legacy, `${legacy}.legacy-${now}`)
    fs.writeFileSync(v4, encodeSession(migrated.lines))
  }
  return {
    status: dryRun ? 'would-migrate' : 'migrated',
    from: record.header.version,
    events: migrated.events,
    marked: Object.fromEntries(migrated.marked),
    parseErrors: record.errors.length,
  }
}

/**
 * 已经是 v4 但仍然读不出来的会话：事件类型是本构建不认识的（写入方比读取方新，例如
 * `job/registered`、`working-directory/change`）。把这些类型标成 `ignorable` 即可——
 * 这是 dsh 自己的兼容机制，读的时候跳过它们而不是拒绝整条日志。
 */
export function repairV4SessionDir(dir, options = {}) {
  const { dryRun = false, now = Date.now() } = options
  const file = path.join(dir, V4_FILE)
  if (!fs.existsSync(file)) return { status: 'skipped', reason: 'no v4 file' }
  const record = readSessionFile(file)
  const validate = events => validateStoredEvents(record.header, events, { kind: 'session', sessionId: record.header.id })
  try {
    validate(record.events)
    return { status: 'skipped', reason: 'already valid' }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    if (!message.includes('unknown to this harness')) return { status: 'skipped', reason: message.slice(0, 120) }
  }
  // The reader names the first offending type it meets. Mark every event of that type as
  // `ignorable` and ask again: the log may carry several types this build never heard of,
  // and per-event validation is not enough (a row can also trip a shape rule first).
  let lines = record.events.map(event => JSON.stringify(event))
  const markedTypes = []
  for (let round = 0; round < 64; round += 1) {
    let failure
    try {
      validate(lines.map(line => JSON.parse(line)))
      break
    } catch (error) {
      failure = error instanceof Error ? error.message : String(error)
    }
    const named = /contains event type "([^"]+)"/.exec(failure)
    if (named === null) return { status: 'skipped', reason: failure.slice(0, 140) }
    const type = named[1]
    if (markedTypes.includes(type)) return { status: 'skipped', reason: `stuck on ${type}` }
    markedTypes.push(type)
    lines = lines.map(line => {
      const event = JSON.parse(line)
      return event.type === type ? JSON.stringify({ ...event, ignorable: true }) : line
    })
  }
  const header = JSON.stringify(record.header)
  const payload = [header, ...lines]
  if (!dryRun) {
    fs.renameSync(file, `${file}.replaced-${now}`)
    fs.writeFileSync(file, encodeSession(payload))
  }
  return { status: dryRun ? 'would-repair' : 'repaired', marked: markedTypes.length, types: markedTypes }
}

export function dshHome() {
  return process.env.DSH_HOME ?? path.join(os.homedir(), '.dsh')
}

/** `dpsk sessions [list|migrate] [--dry-run]`。 */
export function runSessions(args = []) {
  const mode = args[0] === 'migrate' ? 'migrate' : 'list'
  const dryRun = args.includes('--dry-run')
  const root = path.join(dshHome(), 'sessions')
  if (!fs.existsSync(root)) {
    console.log(`dpsk: 没有会话目录 ${root}`)
    return 0
  }
  const report = surveySessions(root)
  console.log(`dpsk: 会话库 ${root}`)
  console.log(`  v4 可读    ${report.v4.length}`)
  console.log(`  旧格式     ${report.legacy.length}${report.legacy.length === 0 ? '' : '（启动时会被跳过）'}`)
  console.log(`  无法解析   ${report.broken.length}`)
  let rejected = 0
  for (const entry of report.v4) {
    try {
      const record = readSessionFile(entry.file)
      validateStoredEvents(record.header, record.events, { kind: 'session', sessionId: record.header.id })
    } catch {
      rejected += 1
    }
  }
  console.log(`  读取被拒   ${rejected}${rejected === 0 ? '' : '（含本构建不认识的插件事件，migrate 会修）'}`)
  for (const entry of report.broken.slice(0, 5)) console.log(`    · ${entry.file}: ${entry.error}`)
  if (mode === 'list') {
    if (report.legacy.length > 0) {
      console.log('')
      console.log('用 `dpsk sessions migrate --dry-run` 看影响，去掉 `--dry-run` 执行转换。')
      console.log('原文件会保留为 `.legacy-<时间戳>`。')
    }
    return 0
  }
  let migrated = 0
  let markedTotal = 0
  const markedByType = new Map()
  const isKnown = knownEventTypeMatcher()
  for (const entry of report.legacy) {
    try {
      const result = migrateSessionDir(entry.dir, { dryRun, isKnown })
      if (result.status === 'migrated' || result.status === 'would-migrate') {
        migrated += 1
        for (const [type, count] of Object.entries(result.marked ?? {})) {
          markedTotal += count
          markedByType.set(type, (markedByType.get(type) ?? 0) + count)
        }
      }
    } catch (error) {
      console.log(`  ✗ ${entry.dir}: ${error instanceof Error ? error.message : String(error)}`)
    }
  }
  let repaired = 0
  const repairedTypes = new Map()
  for (const entry of report.v4) {
    try {
      const result = repairV4SessionDir(entry.dir, { dryRun })
      if (result.status === 'repaired' || result.status === 'would-repair') {
        repaired += 1
        for (const type of result.types ?? []) repairedTypes.set(type, (repairedTypes.get(type) ?? 0) + 1)
      }
    } catch (error) {
      console.log(`  ✗ ${entry.dir}: ${error instanceof Error ? error.message : String(error)}`)
    }
  }
  console.log('')
  console.log(`dpsk: ${dryRun ? '将迁移' : '已迁移'} ${migrated} 个会话。`)
  if (repaired > 0) {
    console.log(`  ${dryRun ? '另有' : '另有'} ${repaired} 个会话读了会报「未知事件类型」，把那些类型标成 ignorable：`)
    for (const [type, count] of [...repairedTypes.entries()].sort((left, right) => right[1] - left[1])) {
      console.log(`    ${type}  ×${count} 个会话`)
    }
  }
  if (markedTotal > 0) {
    console.log(`  ${markedTotal} 条增量事件被标记为 ignorable（内容已在 assistant/message 里）：`)
    for (const [type, count] of [...markedByType.entries()].sort((left, right) => right[1] - left[1])) {
      console.log(`    ${type}  ×${count}`)
    }
  }
  if (migrated === 0 && repaired === 0) console.log('dpsk: 没有需要迁移或修复的会话。')
  if (!dryRun && (migrated > 0 || repaired > 0)) console.log('  重启 dpsk 后这些会话会出现在会话列表里。')
  return 0
}

const invoked = process.argv[1] === undefined ? '' : path.resolve(process.argv[1])
if (invoked === path.resolve(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1'))) {
  process.exit(runSessions(process.argv.slice(2)))
}
