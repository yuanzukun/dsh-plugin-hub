/**
 * Boundary gate.
 *
 * - Community std adapter (`@dsh-std/adapter-dsh`) may only be imported inside
 *   `src/dsh-adapter/` — that tree is the public adapter surface.
 * - Official `@deepseek-ai/*` domain packages may only be imported inside
 *   `src/dsh-host/` — that tree is the host rendering shell, not an adapter.
 * - Protocol packages (`@dsh-std/manifest`, `@dsh-std/core`, …) may be used
 *   anywhere (plugin-spec, host seams).
 * - OpenTUI (`@opentui/*`) and `solid-js` may only be imported inside
 *   `renderer/` — the renderer is a separate Bun process, and the host process
 *   (dsh's Node runtime) cannot load OpenTUI at all.
 * - `renderer/**` may not import `@deepseek-ai/*`: the renderer talks to the
 *   harness only through the IPC protocol, never through harness services.
 *
 * Run as `node scripts/verify-boundary.ts`.
 */

import { readdir, readFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { join, relative, sep } from 'node:path'

const ROOT = join(import.meta.dirname, '..')
const SRC_DIR = join(ROOT, 'src')
const RENDERER_DIR = join(ROOT, 'renderer')
const ADAPTER_DIR = join(SRC_DIR, 'dsh-adapter')
const HOST_DIR = join(SRC_DIR, 'dsh-host')
const UPSTREAM_RE = /from ['"]@deepseek-ai\//
const STD_ADAPTER_RE = /from ['"]@dsh-std\/adapter-dsh/
const RENDERER_ONLY_RE = /from ['"](@opentui\/|solid-js)/
const SOURCE_EXTENSIONS = ['.ts', '.tsx']

interface Violation {
  file: string
  line: number
  text: string
}

function isInside(file: string, dir: string): boolean {
  return file === dir || file.startsWith(dir + sep)
}

async function scan(file: string, violations: Violation[]): Promise<void> {
  const insideAdapter = isInside(file, ADAPTER_DIR)
  const insideHost = isInside(file, HOST_DIR)
  const insideRenderer = isInside(file, RENDERER_DIR)
  const lines = (await readFile(file, 'utf8')).split(/\r?\n/)
  for (let index = 0; index < lines.length; index++) {
    const line = lines[index] ?? ''
    const text = line.trim()
    if (UPSTREAM_RE.test(line) && !insideAdapter && !insideHost) {
      violations.push({ file: relative(ROOT, file), line: index + 1, text })
    }
    if (STD_ADAPTER_RE.test(line) && !insideAdapter) {
      violations.push({ file: relative(ROOT, file), line: index + 1, text })
    }
    if (RENDERER_ONLY_RE.test(line) && !insideRenderer) {
      violations.push({ file: relative(ROOT, file), line: index + 1, text })
    }
    if (insideRenderer && UPSTREAM_RE.test(line)) {
      violations.push({ file: relative(ROOT, file), line: index + 1, text })
    }
  }
}

async function walk(dir: string, violations: Violation[]): Promise<void> {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const full = join(dir, entry.name)
    if (entry.isDirectory()) {
      if (entry.name === 'node_modules') continue
      await walk(full, violations)
    } else if (SOURCE_EXTENSIONS.some(extension => entry.name.endsWith(extension))) {
      await scan(full, violations)
    }
  }
}

const violations: Violation[] = []

await walk(SRC_DIR, violations)
if (existsSync(RENDERER_DIR)) {
  await walk(RENDERER_DIR, violations)
}

if (violations.length > 0) {
  console.error('verify:boundary failed:')
  console.error('  @deepseek-ai/* only in src/dsh-host/; @dsh-std/adapter-dsh only in src/dsh-adapter/')
  console.error('  @opentui/* and solid-js only in renderer/; renderer/** may not import @deepseek-ai/*')
  for (const violation of violations) {
    console.error(`  ${violation.file}:${violation.line}: ${violation.text}`)
  }
  process.exit(1)
}

console.log('verify:boundary ok (public adapter in src/dsh-adapter, host shell in src/dsh-host, OpenTUI confined to renderer/)')
