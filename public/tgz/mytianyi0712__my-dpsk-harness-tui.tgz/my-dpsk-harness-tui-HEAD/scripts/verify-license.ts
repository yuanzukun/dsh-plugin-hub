/**
 * License gate.
 *
 * Verifies that every third-party derived asset in this package is registered
 * in `NOTICE.md` and carries a matching provenance header:
 *
 * 1. `NOTICE.md` contains a machine-readable registry block; every entry's
 *    license text section (`### <license>`) is present.
 * 2. Every `derived` path prefix exists.
 * 3. Every `vendored` file exists and its SHA-256 matches the registered digest
 *    (drift in a vendored upstream asset fails the gate).
 * 4. Every file under `vendor/**` is registered by some entry.
 * 5. Every source file that mentions a registered upstream slug carries an
 *    `SPDX-License-Identifier:` header matching that entry's license.
 * 6. `package.json` ships `LICENSE` and `NOTICE.md`, and `LICENSE` points at
 *    `NOTICE.md`.
 *
 * Run as `node scripts/verify-license.ts`.
 */

import { createHash } from 'node:crypto'
import { readFile, readdir } from 'node:fs/promises'
import { join, relative, sep } from 'node:path'

const ROOT = join(import.meta.dirname, '..')
const NOTICE_FILE = join(ROOT, 'NOTICE.md')
const LICENSE_FILE = join(ROOT, 'LICENSE')

/** Source trees scanned for provenance headers. */
const SCAN_DIRS = ['src', 'scripts', 'renderer']
const SOURCE_EXTENSIONS = ['.ts', '.tsx', '.mjs', '.js']

interface VendoredEntry {
  path: string
  sha256: string
}

interface NoticeEntry {
  id: string
  upstream: string
  spdx: string
  copyright: string
  upstreamVersion: string
  vendoredAt: string
  slugs: string[]
  license: string
  derived: string[]
  vendored: VendoredEntry[]
}

interface Registry {
  notices: NoticeEntry[]
}

interface Failure {
  rule: string
  message: string
}

function toPosix(path: string): string {
  return path.split(sep).join('/')
}

async function walk(dir: string, files: string[]): Promise<void> {
  let entries
  try {
    entries = await readdir(dir, { withFileTypes: true })
  } catch {
    return
  }
  for (const entry of entries) {
    const full = join(dir, entry.name)
    if (entry.isDirectory()) {
      await walk(full, files)
    } else {
      files.push(full)
    }
  }
}

function parseRegistry(notice: string): Registry {
  const start = notice.indexOf('```json')
  if (start === -1) throw new Error('NOTICE.md has no registry block (```json)')
  const end = notice.indexOf('```', start + 7)
  if (end === -1) throw new Error('NOTICE.md registry block is not closed')
  const block = notice.slice(start + 7, end)
  return JSON.parse(block) as Registry
}

function sha256(bytes: Buffer): string {
  return createHash('sha256').update(bytes).digest('hex')
}

const failures: Failure[] = []

const noticeText = await readFile(NOTICE_FILE, 'utf8')
let registry: Registry
try {
  registry = parseRegistry(noticeText)
} catch (error) {
  console.error(`verify:license failed — NOTICE.md registry is unreadable:`)
  console.error(error instanceof Error ? error.message : String(error))
  process.exit(1)
}

const entries = registry.notices

// Rule 1: every entry has its license text section.
for (const entry of entries) {
  if (!noticeText.includes(`### ${entry.license}`)) {
    failures.push({ rule: 'license-text', message: `${entry.id}: license section "### ${entry.license}" is missing from NOTICE.md` })
  }
  if (entry.slugs.length === 0) {
    failures.push({ rule: 'slug', message: `${entry.id}: no upstream slug declared for provenance matching` })
  }
}

// Rule 2: derived paths exist.
for (const entry of entries) {
  for (const path of entry.derived) {
    try {
      await readdir(join(ROOT, path))
    } catch {
      // Not a directory — try as a file.
      try {
        await readFile(join(ROOT, path))
      } catch {
        failures.push({ rule: 'derived-path', message: `${entry.id}: derived path "${path}" does not exist` })
      }
    }
  }
}

// Rule 3: vendored digests match.
const registeredVendored = new Set<string>()
for (const entry of entries) {
  for (const item of entry.vendored) {
    registeredVendored.add(item.path)
    let bytes: Buffer
    try {
      bytes = await readFile(join(ROOT, item.path.replace(/\//g, sep)))
    } catch {
      failures.push({ rule: 'vendored-path', message: `${entry.id}: vendored path "${item.path}" does not exist` })
      continue
    }
    const digest = sha256(bytes)
    if (digest !== item.sha256) {
      failures.push({
        rule: 'vendored-digest',
        message: `${entry.id}: vendored asset drifted — ${item.path}\n  registered: ${item.sha256}\n  current:    ${digest}`,
      })
    }
  }
}

// Rule 4: every file under vendor/** is registered.
const vendorFiles: string[] = []
await walk(join(ROOT, 'vendor'), vendorFiles)
for (const file of vendorFiles) {
  const posix = toPosix(relative(ROOT, file))
  if (!registeredVendored.has(posix)) {
    failures.push({ rule: 'unregistered-vendored', message: `vendor asset "${posix}" is not registered in NOTICE.md` })
  }
}

// Rule 5: provenance headers on files that declare derivation in their header.
// Matching is restricted to the header region, quoted module specifiers are
// stripped (importing an MIT dependency is not derivation), and a file is only
// held to the SPDX requirement when it states a provenance phrase naming the slug.
const PROVENANCE_PHRASES = /(Derived from|Ported from|Adapted from|Vendored from|Copied from|Based on|移植自|迁移自)/i
const sources: string[] = []
for (const dir of SCAN_DIRS) {
  await walk(join(ROOT, dir), sources)
}
for (const file of sources) {
  const ext = file.slice(file.lastIndexOf('.'))
  if (!SOURCE_EXTENSIONS.includes(ext)) continue
  const text = await readFile(file, 'utf8')
  const posix = toPosix(relative(ROOT, file))
  const header = text.slice(0, 2000).replace(/(['"`])[^'"`\n]*\1/g, '')
  for (const entry of entries) {
    const matched = entry.slugs.filter((slug) => header.includes(slug))
    if (matched.length === 0) continue
    const declares = PROVENANCE_PHRASES.test(header)
    if (!declares) continue
    const spdx = new RegExp(`SPDX-License-Identifier:\\s*${entry.spdx}`, 'i')
    if (!spdx.test(header)) {
      failures.push({
        rule: 'provenance-header',
        message: `${posix} declares derivation from "${entry.id}" (slug "${matched[0]}") but has no SPDX header — add:\n  SPDX-License-Identifier: ${entry.spdx}`,
      })
    }
  }
}

// Rule 6: package ships LICENSE + NOTICE.md, LICENSE points at NOTICE.md.
const pkg = JSON.parse(await readFile(join(ROOT, 'package.json'), 'utf8')) as { files?: string[]; license?: string }
const shipped = new Set(pkg.files ?? [])
if (!shipped.has('LICENSE')) {
  failures.push({ rule: 'ship-license', message: 'package.json files does not ship LICENSE' })
}
if (!shipped.has('NOTICE.md')) {
  failures.push({ rule: 'ship-notice', message: 'package.json files does not ship NOTICE.md' })
}
if (pkg.license !== 'BSD-3-Clause') {
  failures.push({ rule: 'package-license', message: `package.json license is "${pkg.license}", expected BSD-3-Clause` })
}
const licenseText = await readFile(LICENSE_FILE, 'utf8')
if (!licenseText.includes('NOTICE.md')) {
  failures.push({ rule: 'license-points-to-notice', message: 'LICENSE does not point at NOTICE.md' })
}

if (failures.length > 0) {
  console.error(`verify:license failed (${failures.length} issue${failures.length === 1 ? '' : 's'}):`)
  for (const failure of failures) console.error(`  [${failure.rule}] ${failure.message}`)
  process.exit(1)
}

console.log(`verify:license ok (${entries.length} upstream entries, ${registeredVendored.size} vendored assets, ${sources.length} sources scanned)`)
