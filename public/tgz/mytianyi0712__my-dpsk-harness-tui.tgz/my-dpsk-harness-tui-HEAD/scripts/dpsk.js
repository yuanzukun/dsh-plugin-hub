#!/usr/bin/env node
// dpsk: my-dpsk-harness-tui 启动器（Node 实现，跨平台 bin 入口）。
// 只负责调用系统 PATH 中官方 dsh 的独立进程，并启动 tui profile。
// 本项目不下载、不缓存 dsh。正常启动不迁移设置、不自动升级；只做一次新旧包交替的自愈
// 摘除（旧包 `dsh-omp-tui` 与新包注册同一个 `tui` 服务，留在 profile 里会遮住新包）。
// `dpsk update` 从 GitHub Release 安装最新包，并做新版本适配。
// `dpsk check` 比较全局包与 tui profile 内容，有差异时用全局包覆盖 profile。
// 渲染器是默认路径：启动器每次启动都确保当前平台的 OpenTUI 渲染器产物在缓存里，
// 并把路径写入 DSH_RENDERER_PATH；取不到产物时报告并以非零码退出（pi-tui 渲染路径
// 已随基座退出删除）。
//
// 环境变量：
//   DSH_REAL             显式指定 dsh 可执行文件
//   DSH_DEBUG=1          只打印将要执行的命令
//   DPSK_NO_BOOTSTRAP=1 跳过首次运行的 profile 引导

import { spawn, spawnSync } from 'node:child_process'
import crypto from 'node:crypto'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import process from 'node:process'
import { fileURLToPath } from 'node:url'
import { attachDaemon, daemonAlive, daemonRuntimePaths, startDaemon, stopDaemon } from './daemon-client.js'

const PACKAGE = 'my-dpsk-harness-tui'
// 0.5.0 之前的包名。profile 的 node_modules 里可能残留旧目录，`dpsk update` 时让位。
const LEGACY_PACKAGE = 'dsh-omp-tui'
const PROFILE = 'tui'
// 仓库改名后 `dpsk update` 才能取到 release 产物；GitHub 端改名是手工步骤，
// 未改名前 `dpsk update` 会取到旧仓库的产物，`dpsk` 启动与 check 不受影响。
const GITHUB_REPO = 'mytianyi0712/my-dpsk-harness-tui'
const ownPackageJson = JSON.parse(
  fs.readFileSync(fileURLToPath(new URL('../package.json', import.meta.url)), 'utf8'),
)
const ownVersion = ownPackageJson.version

const launcherHelp = `dpsk — my-dpsk-harness-tui 启动器

用法:
  dpsk [参数...]
  dpsk check
  dpsk update
  dpsk renderer [path|install|check]
  dpsk daemon status|start|stop|restart|logs [--quiet]
dpsk sessions [list|migrate] [--dry-run]
  列出会话库里各格式的数量；migrate 把旧构建写下的 v0 会话转成当前运行时能读的 v4
  （header 补齐 + 增量事件标记 ignorable），原文件保留为 .legacy-<时间戳>。

说明:
  dpsk 会调用系统 PATH 中的官方 dsh，并启动 --profile tui。
  渲染器是默认路径：启动器每次启动都确保当前平台的 OpenTUI 渲染器产物在缓存里，
  并把路径写入 DSH_RENDERER_PATH；取不到产物时报告并以非零码退出（pi-tui 渲染路径
  已随基座退出删除，没有回退路径）。
  每次启动都会按版本号同步 tui profile 中的 my-dpsk-harness-tui：版本与全局不一致、
  或 profile 中残留旧版链接安装时，会用当前全局包重新安装。同版本仅内容变化
  时启动不会覆盖，请使用 dpsk check。
  启动与 check 还会把 0.4.0 的旧包 dsh-omp-tui 从 profile 的 bundle 列表与依赖里摘掉
  （两个包注册同一个 tui 服务，旧包留在 profile 里会遮住新包、使新包整体不激活）。
  首次尚无 tui profile 时会自动引导安装。
  dpsk check 比较全局 my-dpsk-harness-tui 与 tui profile 的实际内容，存在差异时
  用全局包覆盖 profile；并报告当前平台缓存的渲染器产物哈希与随包清单的比对。
  dpsk update 从 GitHub Release 安装最新包，并针对新版本做适配
  （凭据扁平化、旧会话编码、社区 std adapter、旧包摘除与目录让位）。
  dpsk renderer install 下载并 SHA-256 校验当前平台的 OpenTUI 渲染器产物，缓存到
  ~/.dsh/dpsk/renderer/<version>-<platform>/；path 子命令打印缓存路径，check 子命令比对哈希。
  启动时缓存命中直接用（离线可跑）；未命中时从 GitHub Release 下载并 SHA-256 校验。
  dpsk backend [list|reset] 列出可启动的 dsh 后端、它们读的会话库、以及与桌面端运行时的
  版本差；reset 清掉记住的选择，下次启动重新询问。
  系统里有多份 dsh（多个 Node 发行版各自全局安装）时，首次启动会询问用哪一个，并记在
  ~/.config/.mydpsk/backend.json；只有一个时直接使用，不打断。
  所有其它参数原样透传给 dsh（例如 --resume <session>）。
  官方 dsh 命令（web/plugin/--profile/--patch 等）请直接使用 dsh。

环境变量:
  DSH_REAL             显式指定 dsh 可执行文件
  DSH_DEBUG=1          只打印将要执行的命令
  DSH_RENDERER_PATH    显式指定渲染器产物路径
  DPSK_EMBEDDED=1      不启动/连接核心守护进程，退回内嵌 dsh 进程
  DPSK_NO_BOOTSTRAP=1  跳过首次 profile 引导安装
`

const args = process.argv.slice(2)
if (args[0] === '-h' || args[0] === '--help') {
  process.stdout.write(launcherHelp)
  process.exit(0)
}

const dsh = process.env.DSH_REAL || 'dsh'
const isWin = process.platform === 'win32'

function fail(message, code = 1) {
  process.stderr.write(`dpsk: ${message}\n`)
  process.exit(code)
}

function say(message) {
  process.stderr.write(`dpsk: ${message}\n`)
}

/** cmd.exe 以空格拼接参数；含空格/元字符的参数需要双引号包裹。 */
function shellQuote(arg) {
  return /[ \t"^&|<>()]/.test(arg) ? `"${arg.replace(/"/g, '""')}"` : arg
}

/**
 * Windows：Node ≥18 的安全限制要求 .cmd 经 shell 启动；Node ≥22 对
 * `shell:true + 非空 args 数组` 会告警（DEP0190）。因此把转义后的命令
 * 拼成一个字符串传入，非 Windows 保持数组直传。
 */
function runSync(command, args, opts = {}) {
  if (isWin) {
    const line = [command, ...args].map(shellQuote).join(' ')
    return spawnSync(line, [], { ...opts, shell: true })
  }
  return spawnSync(command, args, opts)
}

function run(command, args) {
  if (isWin) {
    const line = [command, ...args].map(shellQuote).join(' ')
    return spawn(line, [], { stdio: 'inherit', shell: true })
  }
  return spawn(command, args, { stdio: 'inherit' })
}

function packageRoot() {
  const root = fileURLToPath(new URL('..', import.meta.url))
  return root.replace(/\\/g, '/').replace(/\/+$/, '')
}

function dshHome() {
  return process.env.DSH_HOME?.trim() || path.join(os.homedir(), '.dsh')
}

function profilePackageDir() {
  return path.join(dshHome(), 'profiles', PROFILE, 'node_modules', PACKAGE)
}

function installedProfileVersion() {
  try {
    return JSON.parse(fs.readFileSync(path.join(profilePackageDir(), 'package.json'), 'utf8')).version
  } catch {
    return undefined
  }
}

/** profile 中的 my-dpsk-harness-tui 是否是指向别处的链接安装（pnpm file: 目录常见）。 */
function profilePackageIsLink() {
  const dir = profilePackageDir()
  try {
    return fs.realpathSync(dir) !== path.resolve(dir)
  } catch {
    return false
  }
}

/**
 * 旧版本（0.2.x 及更早的 pnpm 安装）会在包目录内留下嵌套的
 * `node_modules/.pnpm`，其中的 @deepseek-ai 依赖可能与新版 dsh 不兼容。
 * 干净安装（nodeLinker: hoisted）不会在包目录内嵌套 node_modules。
 */
function profileInstallIsHealthy() {
  if (profilePackageIsLink()) return false
  if (fs.existsSync(path.join(profilePackageDir(), 'node_modules', '.pnpm'))) return false
  return true
}

/**
 * Dev `tsdown` omits session-title / session-persistence. Rebuild with the
 * prepare config before packing so tui profile can load those loader entries.
 */
function ensurePublishBuild() {
  const root = packageRoot()
  const prepareConfig = path.join(root, 'tsdown.prepare.config.ts')
  if (!fs.existsSync(prepareConfig)) return
  const result = runSync('npx', ['--no-install', 'tsdown', '--config', prepareConfig], { cwd: root, stdio: 'pipe' })
  if (result.status !== 0) {
    throw new Error(`构建发布产物失败：${String(result.stderr ?? result.stdout ?? '').trim() || '未知错误'}`)
  }
  const needed = ['session-title.js', 'session-persistence.js', 'index.js']
  const missing = needed.filter(name => !fs.existsSync(path.join(root, 'lib', name)))
  if (missing.length > 0) {
    throw new Error(`发布产物缺少 ${missing.join(', ')}`)
  }
}

/** 把全局包目录打包成临时 tarball，避免 pnpm 把 file: 目录安装成链接。 */
function packSelfTarball() {
  ensurePublishBuild()
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dpsk-pack-'))
  const output = path.join(tempDir, `${PACKAGE}-${ownVersion}.tgz`)
  const result = runSync('npm', ['pack', packageRoot(), '--ignore-scripts', '--pack-destination', tempDir], { stdio: 'pipe' })
  if (result.status !== 0) {
    throw new Error(`npm pack 失败：${String(result.stderr ?? '').trim() || '未知错误'}`)
  }
  const tarball = path.join(tempDir, `${PACKAGE}-${ownVersion}.tgz`)
  if (!fs.existsSync(tarball)) {
    const files = fs.readdirSync(tempDir).filter(name => name.endsWith('.tgz'))
    if (files.length === 0) throw new Error(`npm pack 未生成 tarball：${String(result.stdout ?? '').trim()}`)
    return path.join(tempDir, files[0])
  }
  return tarball
}

function removeProfilePackage() {
  fs.rmSync(profilePackageDir(), { recursive: true, force: true })
}

function compareVersions(a, b) {
  const aParts = a.split('-')[0].split('.').map(Number)
  const bParts = b.split('-')[0].split('.').map(Number)
  const length = Math.max(aParts.length, bParts.length)
  for (let i = 0; i < length; i++) {
    const av = aParts[i] ?? 0
    const bv = bParts[i] ?? 0
    if (av !== bv) return av - bv
  }
  return 0
}

/**
 * 选择这次要启动的 dsh 后端。
 *
 * `dsh` 的会话存储是同一个（`$DSH_HOME/sessions`），但**读日志的是后端自己的版本**：
 * 桌面客户端自带 0.2.1 系列运行时，而 PATH 上的 CLI 可能是更旧的版本，它写下的新会话
 * （`job/registered` 之类新事件）旧后端读不出来，`/resume` 里就少了那些会话。所以启动
 * 前先列出所有可启动的后端，让用户挑一个，并记住；只有一个时直接用，不打扰。
 *
 * @returns `{ chosen, needsPrompt }`；`chosen` 为 undefined 且 `needsPrompt` 为真时由调用方询问。
 */
export function pickBackend(candidates, savedCommand) {
  if (candidates.length === 0) return { chosen: undefined, needsPrompt: false }
  // `DSH_REAL` 是显式覆盖，永远优先，也不再询问。
  const explicit = candidates.find(candidate => candidate.source === 'DSH_REAL')
  if (explicit !== undefined) return { chosen: explicit, needsPrompt: false }
  if (typeof savedCommand === 'string' && savedCommand !== '') {
    const saved = candidates.find(candidate => candidate.command === savedCommand || candidate.resolved === savedCommand)
    if (saved !== undefined) return { chosen: saved, needsPrompt: false }
  }
  if (candidates.length === 1) return { chosen: candidates[0], needsPrompt: false }
  return { chosen: undefined, needsPrompt: true }
}

/**
 * 后端版本与桌面端运行时的差距提示。
 *
 * 同一个会话目录、不同版本的后端：版本较旧的一侧读不出新版本写下的事件，只能跳过整条会话。
 * 这里把原因说清楚并给出升级命令，而不是让用户以为会话丢了。
 */
export function backendDriftWarning(backendVersion, desktopVersion) {
  if (typeof backendVersion !== 'string' || typeof desktopVersion !== 'string') return ''
  if (compareVersions(backendVersion, desktopVersion) >= 0) return ''
  return `桌面客户端是 dsh ${desktopVersion}，当前 TUI 后端是 ${backendVersion}：桌面端用新版本写下的会话在 TUI 里可能读不出来（列表会少几条）。`
    + `要与桌面端对齐可升级后端：npm i -g @deepseek-ai/dsh@${desktopVersion}`
    + `（本包按 0.2.0 适配；升级后若插件异常，装回 @deepseek-ai/dsh@0.2.0-rc.2 即可）`
}


/**
 * 新版 dsh-session-persistence-jsonl 默认使用 zstd；同一会话目录里若同时存在
 * 同一格式代际的 plain 与 zstd 日志，会被新版后端判定为 encoding mismatch 并
 * 拒绝加载。0.2 的规范文件名按代际寻址（v0 为 `session.jsonl`，其后为
 * `vN.session.jsonl`，zstd 编码再加 `.zstd`），所以冲突检查必须覆盖全部代际。
 * 仅在 `dpsk update` 时处理会阻断启动的两类旧布局。
 */
function migrateLegacySessionArtifacts() {
  const sessionsRoot = path.join(dshHome(), 'sessions')
  let projects
  try {
    projects = fs.readdirSync(sessionsRoot, { withFileTypes: true })
  } catch {
    return
  }

  for (const project of projects) {
    if (!project.isDirectory()) continue
    const projectDir = path.join(sessionsRoot, project.name)
    let entries
    try {
      entries = fs.readdirSync(projectDir, { withFileTypes: true })
    } catch {
      continue
    }

    for (const entry of entries) {
      if (!entry.isFile()) continue
      if (entry.name !== 'session.jsonl' && entry.name !== 'session.jsonl.zstd') continue
      const legacy = `${entry.name}.dpsk-legacy-${Date.now()}`
      fs.renameSync(path.join(projectDir, entry.name), path.join(projectDir, legacy))
      say(`已将旧版扁平会话文件 ${path.join(projectDir, entry.name)} 重命名为 ${legacy}`)
    }

    for (const entry of entries) {
      if (!entry.isDirectory()) continue
      const sessionDir = path.join(projectDir, entry.name)
      let files
      try {
        files = fs.readdirSync(sessionDir)
      } catch {
        continue
      }
      // 规范代际名：`session.jsonl`（v0）或 `vN.session.jsonl`；带 `.zstd`
      // 后缀的是同一代际的压缩版本。保留 zstd，把冲突的 plain 让位。
      for (const name of files) {
        const base = /^(v\d+\.)?session\.jsonl$/.exec(name)
        if (base === null) continue
        if (!files.includes(`${name}.zstd`)) continue
        const legacy = `${name}.dpsk-legacy-${Date.now()}`
        fs.renameSync(path.join(sessionDir, name), path.join(sessionDir, legacy))
        say(`已将会话 ${entry.name} 的旧 plain 日志 ${name} 重命名为 ${legacy}，保留 zstd 版本。`)
      }
    }
  }
}

/** 用 dsh plugin add 把指定源安装到 tui profile。 */
function addToProfile(source, silent) {
  const stdio = silent ? ['ignore', 'pipe', 'pipe'] : ['inherit', 'inherit', 'pipe']
  const runAdd = extraArgs => runSync(
    dsh,
    ['plugin', '--profile', PROFILE, 'add', ...extraArgs, source],
    { stdio },
  )
  let result = runAdd([])
  if (result.status !== 0 && String(result.stderr).includes('ERR_PNPM_ADDING_TO_ROOT')) {
    if (!silent) say('pnpm 拒绝写入 workspace 根（ERR_PNPM_ADDING_TO_ROOT），带 -w 重试…')
    result = runAdd(['-w'])
  }
  return result
}

function pnpmAvailable() {
  const probe = runSync('pnpm', ['--version'], { stdio: 'pipe' })
  return probe.error === undefined && probe.status === 0
}

/**
 * dsh plugin add 依赖系统 pnpm；没有 pnpm 时用 npm 直接安装 tarball 到
 * profile（不写 package.json，只补 node_modules）。dsh 的 bundle 解析走
 * profile/node_modules，因此该回退只要求用户安装了 Node 和 npm。
 */
function npmInstallToProfile(tarball, silent) {
  const stdio = silent ? ['ignore', 'pipe', 'pipe'] : ['inherit', 'inherit', 'pipe']
  return runSync(
    'npm',
    ['install', '--prefix', path.join(dshHome(), 'profiles', PROFILE), '--no-save', '--legacy-peer-deps', tarball],
    { stdio },
  )
}

function addResultError(result) {
  const stderr = String(result.stderr ?? '').trim()
  return stderr === '' ? '插件安装失败。' : stderr
}

function requireDsh() {
  const dshProbe = runSync(dsh, ['--version'], { stdio: 'pipe' })
  if (dshProbe.error || dshProbe.status !== 0) {
    fail('未检测到 dsh CLI。请先安装官方客户端：npm install -g @deepseek-ai/dsh')
  }
}

function syncMarkerPath() {
  return path.join(profilePackageDir(), '.dpsk-source')
}

function fileSha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')
}

/** Content hash of a directory tree; file bytes only, so tarball mtimes do not matter. */
function directoryFingerprint(root) {
  const hash = crypto.createHash('sha256')
  const files = []
  const walk = (dir, rel) => {
    let entries
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true })
    } catch {
      return
    }
    entries.sort((a, b) => a.name.localeCompare(b.name))
    for (const entry of entries) {
      if (entry.name === 'node_modules' || entry.name === '.dpsk-source') continue
      const nextRel = rel === '' ? entry.name : `${rel}/${entry.name}`
      const full = path.join(dir, entry.name)
      if (entry.isDirectory()) walk(full, nextRel)
      else if (entry.isFile()) files.push(nextRel)
    }
  }
  walk(root, '')
  for (const rel of files) {
    hash.update(rel)
    hash.update('\0')
    try {
      hash.update(fs.readFileSync(path.join(root, rel)))
    } catch {
      hash.update('<unreadable>')
    }
    hash.update('\0')
  }
  return hash.digest('hex')
}

function fingerprintTarball(tarball) {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dpsk-check-'))
  try {
    const result = runSync('tar', ['-xzf', tarball, '-C', tempDir], { stdio: 'pipe' })
    if (result.status !== 0) {
      throw new Error(`解包失败：${String(result.stderr ?? '').trim() || '未知错误'}`)
    }
    const nested = path.join(tempDir, 'package')
    return directoryFingerprint(fs.existsSync(nested) ? nested : tempDir)
  } finally {
    fs.rmSync(tempDir, { recursive: true, force: true })
  }
}

function readProfileSourceHash() {
  try {
    const value = fs.readFileSync(syncMarkerPath(), 'utf8').trim()
    return value === '' ? undefined : value
  } catch {
    return undefined
  }
}

function writeProfileSourceHash(hash) {
  fs.writeFileSync(syncMarkerPath(), `${hash}\n`, 'utf8')
}

/** Pack the current global/launcher package and install it into tui profile. */
function installGlobalToProfile(previousVersion, tarball) {
  requireDsh()
  removeProfilePackage()
  if (previousVersion !== undefined) {
    say(`正在把 tui profile 的 my-dpsk-harness-tui 同步为 ${ownVersion}（原 ${previousVersion}）…`)
  } else {
    say(`正在把全局 my-dpsk-harness-tui ${ownVersion} 安装到 tui profile…`)
  }

  let packed = tarball
  if (packed === undefined) {
    try {
      packed = packSelfTarball()
    } catch (error) {
      fail(error instanceof Error ? error.message : String(error))
    }
  }

  const addResult = pnpmAvailable()
    ? addToProfile(packed, false)
    : npmInstallToProfile(packed, false)
  if (addResult.status !== 0) {
    fail(`插件安装失败。可稍后手工重试：dsh plugin --profile tui add <tgz 或 file:包路径>\n${addResultError(addResult)}`)
  }
  writeProfileSourceHash(fingerprintTarball(packed))
}

function profileDiffersFromGlobal(globalHash) {
  if (!fs.existsSync(profilePackageDir())) {
    return { differ: true, reason: 'missing' }
  }
  if (!profileInstallIsHealthy()) {
    return { differ: true, reason: 'unhealthy' }
  }
  const profileHash = readProfileSourceHash()
  if (profileHash !== globalHash) {
    return { differ: true, reason: 'content', profileHash }
  }
  return { differ: false, profileHash }
}

/**
 * 同步 tui profile 中的 my-dpsk-harness-tui：
 * - 首次安装：静默引导安装当前全局包；
 * - 旧版本或链接安装：用当前全局包重新打包安装，支持从旧版本更新。
 * 安装优先走 dsh 官方 plugin add（pnpm），没有 pnpm 时回退 npm。
 * 同版本仅内容变化时不覆盖，交给 `dpsk check`。
 */
function ensureProfile() {
  // 旧包（0.4.0 的 `dsh-omp-tui`）与新包注册同一个 `tui` 服务，profile 里两份共存时旧的
  // 先加载、新包整体不激活。启动前先摘掉，被遮蔽的 profile 任何一次启动都能自愈。
  migrateLegacyProfilePackage()
  const installed = installedProfileVersion()
  const needsInstall = installed !== ownVersion || !profileInstallIsHealthy()

  if (!needsInstall) return

  if (process.env.DPSK_NO_BOOTSTRAP === '1') {
    if (installed === undefined) {
      fail('已跳过 profile 引导安装，但 tui profile 尚未安装 my-dpsk-harness-tui。')
    }
    say(`DPSK_NO_BOOTSTRAP=1：profile 中 my-dpsk-harness-tui 需要重装（版本 ${installed ?? '未知'}），但本次不重装。`)
    return
  }

  installGlobalToProfile(installed)
}

/**
 * 渲染器产物约定（与 `renderer/build.ts`、`src/host/renderer-process.ts` 的
 * `resolveRendererPath` 同一套名字）：`dpsk-renderer-<platform>-<arch>`，Windows
 * 带 `.exe`。缓存目录 `~/.dsh/dpsk/renderer/<version>-<platform>/`。
 */
function rendererPlatformKey() {
  return `${process.platform}-${process.arch}`
}

function rendererArtifactName(platform = rendererPlatformKey()) {
  return `dpsk-renderer-${platform}${platform.startsWith('win32') ? '.exe' : ''}`
}

function rendererCacheDir(version, platform) {
  return path.join(dshHome(), 'dpsk', 'renderer', `${version}-${platform}`)
}

function rendererCachedPath(version, platform) {
  return path.join(rendererCacheDir(version, platform), rendererArtifactName(platform))
}

/** 发布产物清单 `SHA256SUMS.json`（由 scripts/generate-sha256sums.mjs 生成）。 */
async function fetchRendererManifest(version) {
  const url = `https://github.com/${GITHUB_REPO}/releases/download/v${version}/SHA256SUMS.json`
  const response = await fetch(url, { headers: { 'User-Agent': 'dpsk' } })
  if (!response.ok) throw new Error(`渲染器清单获取失败（HTTP ${response.status}）：${url}`)
  const manifest = await response.json()
  if (typeof manifest !== 'object' || manifest === null || typeof manifest.files !== 'object' || manifest.files === null) {
    throw new Error('渲染器清单格式不对（缺 files）')
  }
  return manifest
}

/**
 * 下载并校验当前平台的渲染器产物。
 *
 * 先比缓存里的哈希；缓存命中即返回，不重复下载。下载后先比字节数再比 SHA-256，
 * 两者都过才落盘并置可执行位 —— 截断或被改动的产物绝不能拿到 TTY 上。
 */
async function installRenderer(version, { silent = false } = {}) {
  const platform = rendererPlatformKey()
  const artifact = rendererArtifactName(platform)
  const target = rendererCachedPath(version, platform)
  const manifest = await fetchRendererManifest(version)
  const entry = manifest.files[artifact]
  if (typeof entry !== 'object' || entry === null || typeof entry.sha256 !== 'string') {
    throw new Error(`清单里没有 ${platform} 的渲染器产物（可用：${Object.keys(manifest.files).join(', ')}）`)
  }
  if (fs.existsSync(target)) {
    const local = fileSha256(target)
    if (local === entry.sha256) {
      if (!silent) say(`缓存命中：${target}（sha256 ${local.slice(0, 12)}）`)
      return target
    }
    say(`缓存的渲染器哈希不符（本地 ${local.slice(0, 12)} / 清单 ${entry.sha256.slice(0, 12)}），重新下载…`)
  }
  const url = `https://github.com/${GITHUB_REPO}/releases/download/v${version}/${artifact}`
  const response = await fetch(url, { headers: { 'User-Agent': 'dpsk' } })
  if (!response.ok) throw new Error(`渲染器下载失败（HTTP ${response.status}）：${url}`)
  const bytes = Buffer.from(await response.arrayBuffer())
  if (typeof entry.size === 'number' && bytes.length !== entry.size) {
    throw new Error(`渲染器下载大小与清单不符（${bytes.length} / ${entry.size}）`)
  }
  const hash = crypto.createHash('sha256').update(bytes).digest('hex')
  if (hash !== entry.sha256) throw new Error(`渲染器哈希校验失败（下载得到 ${hash.slice(0, 12)}）`)
  fs.mkdirSync(rendererCacheDir(version, platform), { recursive: true })
  fs.writeFileSync(target, bytes)
  if (!platform.startsWith('win32')) fs.chmodSync(target, 0o755)
  if (!silent) say(`已缓存 ${artifact}（${(bytes.length / 1024 / 1024).toFixed(1)} MB，sha256 ${hash.slice(0, 12)}）→ ${target}`)
  return target
}

/** `dpsk renderer` 子命令：path / install / check。 */
async function runRenderer(args) {
  const sub = args[1] ?? 'path'
  const platform = rendererPlatformKey()
  const cached = rendererCachedPath(ownVersion, platform)
  if (sub === 'path') {
    process.stdout.write(`${fs.existsSync(cached) ? cached : ''}\n`)
    return
  }
  if (sub === 'install') {
    try {
      const path2 = await installRenderer(ownVersion)
      process.stdout.write(`${path2}\n`)
    } catch (error) {
      fail(error instanceof Error ? error.message : String(error))
    }
    return
  }
  if (sub === 'check') {
    if (!fs.existsSync(cached)) {
      say(`当前平台 ${platform} 尚无缓存的渲染器产物。运行 dpsk renderer install。`)
      return
    }
    const local = fileSha256(cached)
    let manifest
    try {
      manifest = await fetchRendererManifest(ownVersion)
    } catch (error) {
      say(`无法取得清单，只能报告本地哈希：${local.slice(0, 12)}（${cached}）`)
      return
    }
    const entry = manifest.files[rendererArtifactName(platform)]
    if (entry === undefined) {
      say(`清单里没有 ${platform} 的产物；本地哈希 ${local.slice(0, 12)}`)
      return
    }
    say(`渲染器 ${rendererArtifactName(platform)}：本地 ${local.slice(0, 12)} / 清单 ${entry.sha256.slice(0, 12)} → ${local === entry.sha256 ? '一致' : '不一致'}`)
    return
  }
  fail(`未知 renderer 子命令：${sub}（可用：path / install / check）`)
}

function runCheck() {
  // 与启动同一套新旧交替：check 报告差异之前先把旧包摘干净，否则「全局与 profile 一致」
  // 可能是一致地坏的——两份包都在 profile 里，服务注册撞车。
  migrateLegacyProfilePackage()
  const installed = installedProfileVersion()
  let tarball
  try {
    tarball = packSelfTarball()
  } catch (error) {
    fail(error instanceof Error ? error.message : String(error))
  }
  const globalHash = fingerprintTarball(tarball)
  const profileHash = readProfileSourceHash()
  say(`全局 my-dpsk-harness-tui v${ownVersion}  源包 ${globalHash.slice(0, 12)}`)
  if (!fs.existsSync(profilePackageDir())) {
    say('tui profile 尚未安装 my-dpsk-harness-tui。')
  } else {
    say(`tui profile     v${installed ?? '未知'}  源包 ${profileHash === undefined ? '未知' : profileHash.slice(0, 12)}`)
  }

  const diff = profileDiffersFromGlobal(globalHash)
  reportRendererCheck()
  if (!diff.differ) {
    say('全局环境与 tui profile 一致，无需覆盖。')
    return
  }

  const reason = diff.reason === 'missing'
    ? 'profile 未安装'
    : diff.reason === 'unhealthy'
      ? 'profile 为链接或旧版嵌套安装'
      : profileHash === undefined
        ? 'profile 不是由当前启动器同步的'
        : installed !== ownVersion
          ? `版本不一致（全局 ${ownVersion} / profile ${installed ?? '未知'}）`
          : '同版本内容不一致'
  say(`存在差异（${reason}），正在用全局包覆盖 tui profile…`)
  installGlobalToProfile(installed, tarball)
  const after = installedProfileVersion()
  const afterHash = readProfileSourceHash()
  say(`已用全局 v${ownVersion} 覆盖 tui profile（现为 v${after ?? '未知'}，源包 ${afterHash === undefined ? '未知' : afterHash.slice(0, 12)}）。`)
}

/**
 * `dpsk check` 的渲染器部分：报告当前平台缓存产物的哈希，与随包 `SHA256SUMS.json`
 * （若存在）比对。清单缺失时只报本地哈希 —— check 是本地操作，不联网。
 */
function reportRendererCheck() {
  const platform = rendererPlatformKey()
  const cached = rendererCachedPath(ownVersion, platform)
  if (!fs.existsSync(cached)) {
    say(`渲染器：当前平台 ${platform} 无缓存产物（运行 dpsk renderer install）。`)
    return
  }
  const local = fileSha256(cached)
  const manifestPath = path.join(packageRoot(), 'SHA256SUMS.json')
  if (!fs.existsSync(manifestPath)) {
    say(`渲染器：${rendererArtifactName(platform)} 本地 sha256 ${local.slice(0, 12)}（随包无清单可比对）`)
    return
  }
  let manifest
  try {
    manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'))
  } catch (error) {
    say(`渲染器清单读取失败：${error instanceof Error ? error.message : String(error)}`)
    return
  }
  const entry = manifest?.files?.[rendererArtifactName(platform)]
  if (typeof entry?.sha256 !== 'string') {
    say(`渲染器：本地 sha256 ${local.slice(0, 12)}；清单无 ${platform} 条目`)
    return
  }
  say(`渲染器：本地 ${local.slice(0, 12)} / 清单 ${entry.sha256.slice(0, 12)} → ${local === entry.sha256 ? '一致' : '不一致'}`)
}

/**
 * 0.5.0 把包名从 `dsh-omp-tui` 改为 `my-dpsk-harness-tui`。旧包与新包注册**同一个
 * `tui` 服务**与同一个 session-title provider，profile 里两份共存时先加载的旧包会赢，
 * 新包的条目整体报 `2 entries did not activate`——界面退回 0.4.0 或什么都不显示，用户
 * 看到的就是「新包没装上」。所以要把旧包从 profile 的 `package.json` 里摘干净：
 * `dsh.profile.bundles` 一项加依赖表一项。只重命名 `node_modules` 里的旧目录不够，
 * 依赖表还留着，下一次 pnpm 安装会把它装回来。
 */
export function stripLegacyProfilePackage(home) {
  const file = path.join(home, 'profiles', PROFILE, 'package.json')
  if (!fs.existsSync(file)) return { changed: false, removed: [] }
  let manifest
  try {
    manifest = JSON.parse(fs.readFileSync(file, 'utf8'))
  } catch {
    return { changed: false, removed: [] }
  }
  const removed = []
  if (Array.isArray(manifest?.dsh?.profile?.bundles) && manifest.dsh.profile.bundles.includes(LEGACY_PACKAGE)) {
    manifest.dsh.profile.bundles = manifest.dsh.profile.bundles.filter(entry => entry !== LEGACY_PACKAGE)
    removed.push('dsh.profile.bundles')
  }
  for (const section of ['dependencies', 'devDependencies']) {
    const table = manifest?.[section]
    if (table !== undefined && table[LEGACY_PACKAGE] !== undefined) {
      delete table[LEGACY_PACKAGE]
      removed.push(section)
    }
  }
  if (removed.length === 0) return { changed: false, removed }
  fs.writeFileSync(file, `${JSON.stringify(manifest, null, 2)}\n`)
  return { changed: true, removed }
}

/**
 * 完整的新旧包交替处理：摘 profile 的 `package.json`，再把 `node_modules` 里的旧包目录
 * 让位重命名（内容保留不删，便于回滚）。启动、`check`、`update` 三条路径都跑，所以
 * 被旧包遮蔽的 profile 任何一次运行都能自愈；摘干净后再跑是幂等的（无输出）。
 */
function migrateLegacyProfilePackage() {
  const home = dshHome()
  const strip = stripLegacyProfilePackage(home)
  if (strip.changed) {
    say(`已从 tui profile 的 package.json 摘掉旧包 ${LEGACY_PACKAGE}（${strip.removed.join('、')}）。`)
  }
  const parent = path.join(home, 'profiles', PROFILE, 'node_modules')
  const legacyDir = path.join(parent, LEGACY_PACKAGE)
  if (!fs.existsSync(legacyDir)) return
  const stamp = `dsh-omp-tui.dpsk-legacy-${Date.now()}`
  try {
    fs.renameSync(legacyDir, path.join(parent, stamp))
    say(`已将旧包目录 node_modules/${LEGACY_PACKAGE} 重命名为 ${stamp}（内容保留，未删除）。`)
  } catch (error) {
    say(`旧包目录 node_modules/${LEGACY_PACKAGE} 让位失败：${error instanceof Error ? error.message : String(error)}。可稍后手工处理。`)
  }
}

function adaptForNewVersion() {
  migrateLegacySessionArtifacts()
  migrateLegacyProfilePackage()
}

/** 第一个在 PATH 上真实存在的文件（`dsh` 在 Windows 上是 `.cmd`/`.exe`）。 */
function resolveOnPath(name) {
  const extensions = isWin ? ['.exe', '.cmd', '.bat', ''] : ['']
  for (const dir of (process.env.PATH ?? '').split(path.delimiter)) {
    if (dir === '') continue
    for (const extension of extensions) {
      const file = path.join(dir, name + extension)
      try {
        if (fs.statSync(file).isFile()) return file
      } catch {}
    }
  }
  return undefined
}

/**
 * PATH 上的每一个 `dsh`（按真实路径去重）。
 *
 * 多个 Node 发行版（系统级 `C:\Program Files\nodejs`、用户级 npm 前缀、bun）各自带一份全局
 * 安装时，PATH 里会有多个 `dsh`：它们读同一份会话库但版本可能不同，正是要询问用户的情形。
 */
function dshOnPath() {
  const extensions = isWin ? ['.exe', '.cmd', '.bat', ''] : ['']
  const hits = []
  const seen = new Set()
  for (const dir of (process.env.PATH ?? '').split(path.delimiter)) {
    if (dir === '') continue
    for (const extension of extensions) {
      const file = path.join(dir, `dsh${extension}`)
      try {
        if (!fs.statSync(file).isFile()) continue
        const real = (() => {
          try {
            return fs.realpathSync(file)
          } catch {
            return file
          }
        })()
        const key = real.toLowerCase()
        if (seen.has(key)) break
        seen.add(key)
        hits.push({ source: 'PATH', command: hits.length === 0 ? 'dsh' : file, resolved: file, version: backendVersion(file) })
        break
      } catch {}
    }
  }
  return hits
}

/** `dsh --version` 报告的版本，取第一个 semver。 */
function backendVersion(command) {
  const result = runSync(command, ['--version'], { stdio: 'pipe' })
  if (result.status !== 0) return undefined
  const match = /(\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?)/.exec(String(result.stdout ?? ''))
  return match === null ? undefined : match[1]
}

/** 这次可以启动哪些 dsh 后端（`DSH_REAL` 覆盖在前，其次是 PATH 上的每一份）。 */
function backendCandidates() {
  const found = []
  const explicit = process.env.DSH_REAL
  if (typeof explicit === 'string' && explicit.trim() !== '') {
    const command = explicit.trim()
    found.push({ source: 'DSH_REAL', command, resolved: resolveOnPath(command), version: backendVersion(command) })
  }
  for (const hit of dshOnPath()) {
    if (found.some(candidate => candidate.resolved === hit.resolved)) continue
    found.push(hit)
  }
  return found
}

/** 桌面客户端自带的运行时版本（`$DSH_HOME/dsh-runtimes/<name>/runtime.json`）。 */
function desktopRuntimeVersion(home = dshHome()) {
  const dir = path.join(home, 'dsh-runtimes')
  let names
  try {
    names = fs.readdirSync(dir)
  } catch {
    return undefined
  }
  const versions = []
  for (const name of names) {
    try {
      const manifest = JSON.parse(fs.readFileSync(path.join(dir, name, 'runtime.json'), 'utf8'))
      if (typeof manifest?.desktopVersion === 'string') versions.push(manifest.desktopVersion)
    } catch {}
  }
  if (versions.length === 0) return undefined
  return versions.sort(compareVersions).at(-1)
}

/** Program-owned config lives outside the DSH home so dsh never rewrites it. */
export function programConfigHome() {
  const explicit = process.env.MYDPSK_CONFIG_HOME?.trim()
  return explicit === undefined || explicit === '' ? path.join(os.homedir(), '.config', '.mydpsk') : explicit
}

/** First-run backend choice, now stored under the program config home. */
export function backendChoicePath(home = programConfigHome()) {
  return path.join(home, 'backend.json')
}

/** Copy the pre-0.5.0 backend choice once without deleting the legacy file. */
export function migrateLegacyBackendChoice(legacy, next) {
  if (fs.existsSync(next) || !fs.existsSync(legacy)) return false
  fs.mkdirSync(path.dirname(next), { recursive: true })
  const temp = `${next}.tmp-${process.pid}-${Date.now()}`
  fs.copyFileSync(legacy, temp)
  fs.renameSync(temp, next)
  return true
}

function ensureProgramConfigHome() {
  const home = programConfigHome()
  fs.mkdirSync(home, { recursive: true })
  migrateLegacyBackendChoice(path.join(dshHome(), 'dpsk', 'backend.json'), backendChoicePath(home))
  return home
}

function readBackendChoice() {
  try {
    ensureProgramConfigHome()
    return JSON.parse(fs.readFileSync(backendChoicePath(), 'utf8'))
  } catch {
    return undefined
  }
}

/** A cheap identity for an executable file: replacing or updating it invalidates the cache. */
export function backendSignature(file) {
  try {
    const stat = fs.statSync(file)
    return stat.isFile() ? `${stat.size}:${Math.trunc(stat.mtimeMs)}` : undefined
  } catch {
    return undefined
  }
}

/**
 * Return the saved backend without probing PATH when the remembered executable is still
 * byte-for-byte the same file identity recorded by the last full resolve. Returns undefined
 * for DSH_REAL (which must win every launch), a missing signature, or a moved/replaced file.
 */
export function savedBackendCommand(choice, explicit = process.env.DSH_REAL, signature = backendSignature) {
  if (typeof explicit === 'string' && explicit.trim() !== '') return undefined
  if (choice === null || typeof choice !== 'object') return undefined
  if (typeof choice.resolved !== 'string' || choice.resolved === '') return undefined
  if (typeof choice.signature !== 'string' || choice.signature === '') return undefined
  if (signature(choice.resolved) !== choice.signature) return undefined
  return choice.resolved
}

function writeBackendChoice(choice) {
  try {
    ensureProgramConfigHome()
    const file = backendChoicePath()
    fs.mkdirSync(path.dirname(file), { recursive: true })
    fs.writeFileSync(file, `${JSON.stringify(choice, null, 2)}\n`)
  } catch (error) {
    say(`无法记住后端选择：${error instanceof Error ? error.message : String(error)}`)
  }
}

/** 多个后端时问一次；回车选第一个，非 TTY 不阻塞。 */
async function promptBackend(candidates) {
  const { createInterface } = await import('node:readline/promises')
  const rl = createInterface({ input: process.stdin, output: process.stderr })
  try {
    say('检测到多个 dsh 后端，请选择本次使用哪一个（只询问一次，之后可在 ~/.config/.mydpsk/backend.json 修改）：')
    candidates.forEach((candidate, index) => {
      process.stderr.write(`  ${index + 1}) ${candidate.version ?? '未知版本'}  ${candidate.resolved ?? candidate.command}  [${candidate.source}]\n`)
    })
    const answer = (await rl.question(`选择 [1-${candidates.length}]（回车 = 1）：`)).trim()
    const index = answer === '' ? 0 : Number.parseInt(answer, 10) - 1
    return candidates[index >= 0 && index < candidates.length ? index : 0]
  } finally {
    rl.close()
  }
}

/**
 * 决定这次启动哪个 dsh，并把「用哪个后端 / 提醒过哪个版本差」记进 `backend.json`。
 *
 * 没有可启动的后端时返回默认名，让 `dsh` 的 ENOENT 分支给出安装提示。
 */
async function resolveBackend() {
  const saved = readBackendChoice()
  const fast = savedBackendCommand(saved)
  if (fast !== undefined) return fast
  const candidates = backendCandidates()
  if (candidates.length === 0) return dsh
  const picked = pickBackend(candidates, typeof saved?.command === 'string' ? saved.command : undefined)
  let chosen = picked.chosen
  if (chosen === undefined && picked.needsPrompt) {
    if (process.stdin.isTTY) {
      chosen = await promptBackend(candidates)
    } else {
      say('检测到多个 dsh 后端，非交互环境下使用第一个；可用 DSH_REAL 指定。')
    }
  }
  chosen ??= candidates[0]
  const desktop = desktopRuntimeVersion()
  const warning = backendDriftWarning(chosen.version, desktop)
  const drift = warning === '' ? undefined : `${chosen.version}|${desktop}`
  if (warning !== '' && saved?.warned !== drift) say(warning)
  const previous = saved === undefined
    ? {}
    : { command: saved.command, resolved: saved.resolved, version: saved.version, desktopVersion: saved.desktopVersion, warned: saved.warned, signature: saved.signature }
  const next = { command: chosen.command, resolved: chosen.resolved, version: chosen.version, desktopVersion: desktop, warned: drift ?? previous.warned, signature: chosen.resolved === undefined ? undefined : backendSignature(chosen.resolved) }
  if (JSON.stringify(next) !== JSON.stringify(previous)) writeBackendChoice(next)
  return chosen.command
}


async function githubLatestRelease() {
  const response = await fetch(`https://api.github.com/repos/${GITHUB_REPO}/releases/latest`, {
    headers: {
      'User-Agent': 'dpsk',
      Accept: 'application/vnd.github+json',
    },
  })
  if (!response.ok) {
    throw new Error(`GitHub 发布查询失败（HTTP ${response.status}）`)
  }
  const release = await response.json()
  const tag = typeof release.tag_name === 'string' ? release.tag_name : ''
  if (tag === '') throw new Error('GitHub 发布缺少 tag_name')
  const version = tag.replace(/^v/, '')
  const assets = Array.isArray(release.assets) ? release.assets : []
  const tgz = assets.find(asset => (
    typeof asset === 'object' && asset !== null
    && typeof asset.browser_download_url === 'string'
    && String(asset.name ?? '').endsWith('.tgz')
  ))
  const url = typeof tgz?.browser_download_url === 'string'
    ? tgz.browser_download_url
    : `https://github.com/${GITHUB_REPO}/releases/download/${tag}/${PACKAGE}-${version}.tgz`
  return { tag, version, url }
}

async function runUpdate() {
  const dshProbe = runSync(dsh, ['--version'], { stdio: 'pipe' })
  if (dshProbe.error || dshProbe.status !== 0) {
    fail('未检测到 dsh CLI。请先安装官方客户端：npm install -g @deepseek-ai/dsh')
  }

  say('正在查询 GitHub 最新发布…')
  let latest
  try {
    latest = await githubLatestRelease()
  } catch (error) {
    fail(error instanceof Error ? error.message : String(error))
  }

  const installed = installedProfileVersion()
  if (installed === latest.version) {
    say(`已是最新版本 v${latest.version}，执行新版本适配…`)
  } else {
    if (installed !== undefined) say(`profile 内为 v${installed}，正在安装 GitHub ${latest.tag}…`)
    else say(`正在安装 GitHub ${latest.tag}…`)
    const result = addToProfile(latest.url, false)
    if (result.status !== 0) {
      fail(`从 GitHub 安装失败。\n${addResultError(result)}`)
    }
    say(`profile 已更新为 v${installedProfileVersion() ?? latest.version}。`)
  }

  adaptForNewVersion()
  say('适配完成。')
}

/**
 * `dpsk backend [list|reset]`：看清楚这次会用哪个 dsh、它读哪份会话库，以及和桌面端的版本差。
 * `reset` 清掉记住的选择，下次启动重新询问。
 */
function runBackend(args) {
  const sub = args[1] ?? 'list'
  if (sub === 'reset') {
    fs.rmSync(backendChoicePath(), { force: true })
    say('已清除记住的 dsh 后端，下次启动会重新选择。')
    return
  }
  if (sub !== 'list') {
    fail(`未知 backend 子命令：${sub}（可用：list / reset）`)
  }
  const candidates = backendCandidates()
  const saved = readBackendChoice()
  const desktop = desktopRuntimeVersion()
  say(`会话库：${path.join(dshHome(), 'sessions')}`)
  say(`桌面端运行时：${desktop ?? '未检测到'}`)
  if (candidates.length === 0) {
    say('未在 PATH 上找到 dsh。安装：npm i -g @deepseek-ai/dsh')
    return
  }
  say('可启动的后端：')
  for (const candidate of candidates) say(`  ${candidate.version ?? '未知版本'}  ${candidate.resolved ?? candidate.command}  [${candidate.source}]`)
  const picked = pickBackend(candidates, typeof saved?.command === 'string' ? saved.command : undefined)
  const active = picked.chosen ?? candidates[0]
  const remembered = typeof saved?.command === 'string' ? `（记住的选择：${saved.command}）` : '（尚未选择，首次启动会询问）'
  say(`本次将使用：${active.version ?? '未知版本'}  ${active.resolved ?? active.command} ${remembered}`)
  if (picked.needsPrompt) say('存在多个后端且尚未选择：下次交互式启动会询问一次。')
  const warning = backendDriftWarning(active.version, desktop)
  if (warning !== '') say(warning)
}

export const RESTART_EXIT_CODE = 75

export function restartHandoffPath() {
  return path.join(programConfigHome(), 'runtime', 'restart.json')
}

/** Replace or append `--resume <id>` without duplicating the flag. */
export function withResumeArgument(args, sessionId) {
  const next = [...args]
  const index = next.indexOf('--resume')
  if (index >= 0) {
    if (index + 1 < next.length) next[index + 1] = sessionId
    else next.push(sessionId)
    return next
  }
  next.push('--resume', sessionId)
  return next
}

export function readRestartHandoff() {
  try {
    const value = JSON.parse(fs.readFileSync(restartHandoffPath(), 'utf8'))
    if (value === null || typeof value !== 'object') return undefined
    return value
  } catch {
    return undefined
  }
}

function runChild(command, args) {
  return new Promise(resolve => {
    const child = run(command, args)
    let settled = false
    const finish = value => {
      if (settled) return
      settled = true
      resolve(value)
    }
    child.on('error', error => finish({ error }))
    child.on('exit', (code, signal) => finish({ code, signal }))
  })
}

async function runSupervisor(backend, baseArgs) {
  const restarts = []
  let args = [...baseArgs]
  for (;;) {
    const result = await runChild(backend, args)
    if (result.error !== undefined) {
      const err = result.error
      if (err && typeof err === 'object' && 'code' in err && err.code === 'ENOENT') {
        process.stderr.write('dpsk: 未在 PATH 中找到官方 dsh。\n')
        process.stderr.write('dpsk: 请先安装 @deepseek-ai/dsh（例如: npm install -g @deepseek-ai/dsh）。\n')
        process.exit(127)
      }
      process.stderr.write(`dpsk: 启动 dsh 失败: ${String(err)}\n`)
      process.exit(1)
    }
    if (result.signal !== null) {
      process.kill(process.pid, result.signal)
      return
    }
    const handoff = result.code === RESTART_EXIT_CODE && process.env.DPSK_SUPERVISOR === '1'
      ? readRestartHandoff()
      : undefined
    if (handoff === undefined) process.exit(result.code ?? 0)
    fs.rmSync(restartHandoffPath(), { force: true })
    const now = Date.now()
    restarts.push(now)
    while (restarts.length > 0 && now - restarts[0] > 60_000) restarts.shift()
    if (restarts.length > 3) {
      process.stderr.write('dpsk: dsh 连续重启超过 3 次/60 秒，停止以避免循环。\n')
      process.exit(1)
    }
    args = typeof handoff.sessionId === 'string' && handoff.sessionId !== ''
      ? withResumeArgument(baseArgs, handoff.sessionId)
      : [...baseArgs]
  }
}

async function ensureRendererArtifact() {
  if (process.env.DSH_RENDERER_PATH !== undefined) return process.env.DSH_RENDERER_PATH
  const cached = rendererCachedPath(ownVersion, rendererPlatformKey())
  if (fs.existsSync(cached)) {
    process.env.DSH_RENDERER_PATH = cached
    return cached
  }
  try {
    process.env.DSH_RENDERER_PATH = await installRenderer(ownVersion)
    return process.env.DSH_RENDERER_PATH
  } catch (error) {
    say(`渲染器不可用：${error instanceof Error ? error.message : String(error)}`)
    say('没有回退路径（pi-tui 渲染基座已删除）；运行 `dpsk renderer install` 后重试。')
    process.exit(1)
  }
}

async function startTui(passthrough) {
  const spawnArgs = ['--profile', PROFILE, ...passthrough]

  await ensureRendererArtifact()

  if (process.env.DSH_DEBUG === '1') {
    const suffix = process.env.DSH_RENDERER_PATH !== undefined ? ` (DSH_RENDERER_PATH=${process.env.DSH_RENDERER_PATH})` : ''
    process.stdout.write(`dpsk → ${dsh} ${spawnArgs.join(' ')}${suffix}\n`)
    process.exit(0)
  }

  ensureProfile()
  // Node 22+ can reuse V8-compiled modules across processes. Keep the cache next to the
  // dsh profile so consecutive TUI launches spend less time compiling the same loader
  // graph; Node invalidates entries by file identity/content on its own.
  if (process.env.NODE_COMPILE_CACHE === undefined && process.env.NODE_DISABLE_COMPILE_CACHE !== '1') {
    try {
      const compileCache = path.join(dshHome(), 'dpsk', 'node-compile-cache')
      fs.mkdirSync(compileCache, { recursive: true })
      process.env.NODE_COMPILE_CACHE = compileCache
    } catch {
      // Compile cache is a speed optimization only.
    }
  }
  // The backend is resolved after the profile is in place: the choice names the dsh that will
  // read the shared session store, and a wrong pick is exactly what makes the TUI's history
  // differ from the desktop client's.
  const backend = await resolveBackend()
  fs.rmSync(restartHandoffPath(), { force: true })
  if (process.env.DPSK_EMBEDDED !== '1') {
    const alreadyAlive = await daemonAlive(400)
    try {
      if (!alreadyAlive) {
        await startDaemon({ backend, args: ['--profile', PROFILE, '--daemon', ...passthrough], cwd: process.cwd() })
      }
      await attachDaemon(process.env.DSH_RENDERER_PATH)
      return
    } catch (error) {
      const alive = await daemonAlive(500)
      if (alive) {
        say('daemon attach failed: ' + (error instanceof Error ? error.message : String(error)))
        process.exit(1)
      }
      say('daemon unavailable; using embedded mode: ' + (error instanceof Error ? error.message : String(error)))
    }
  }
  process.env.DPSK_SUPERVISOR = '1'
  await runSupervisor(backend, spawnArgs)
}

async function runDaemon(argv) {
  const sub = argv[0] ?? 'status'
  const quiet = argv.includes('--quiet')
  const passthrough = argv.slice(1).filter(arg => arg !== '--quiet')
  let daemonCwd = process.cwd()
  const cwdIndex = passthrough.indexOf('--daemon-cwd')
  if (cwdIndex >= 0) {
    const value = passthrough[cwdIndex + 1]
    if (value !== undefined && value !== '') daemonCwd = value
    passthrough.splice(cwdIndex, 2)
  }
  const paths = daemonRuntimePaths()
  if (sub === 'logs') {
    if (!fs.existsSync(paths.log)) {
      say('no daemon log at ' + paths.log)
      return
    }
    const text = fs.readFileSync(paths.log, 'utf8').trimEnd().split(/\r?\n/)
    process.stdout.write(text.slice(-50).join('\n') + '\n')
    return
  }
  if (sub === 'status') {
    const alive = await daemonAlive(800)
    let pid = ''
    try { pid = fs.readFileSync(paths.pid, 'utf8').trim() } catch { /* not running */ }
    say(alive ? 'daemon running' + (pid === '' ? '' : ' (pid ' + pid + ')') : 'daemon not running')
    return
  }
  if (sub === 'stop') {
    const stopped = await stopDaemon()
    if (!quiet) say(stopped ? 'daemon stopped' : 'daemon was not running')
    return
  }
  if (sub === 'start' || sub === 'restart') {
    if (sub === 'restart') await stopDaemon()
    if (await daemonAlive(400)) {
      if (!quiet) say('daemon already running')
      return
    }
    ensureProfile()
    const backend = await resolveBackend()
    await startDaemon({ backend, args: ['--profile', PROFILE, '--daemon', ...passthrough], cwd: daemonCwd })
    if (!quiet) say('daemon started')
    return
  }
  say('usage: dpsk daemon status|start|stop|restart|logs [--quiet]')
  process.exitCode = 2
}

function main() {
  if (args[0] === 'update') {
    void runUpdate().catch(error => fail(error instanceof Error ? error.message : String(error)))
  } else if (args[0] === 'check') {
    runCheck()
  } else if (args[0] === 'renderer') {
    void runRenderer(args).catch(error => fail(error instanceof Error ? error.message : String(error)))
  } else if (args[0] === 'sessions') {
    import('./sessions-migrate.mjs')
      .then(module => process.exit(module.runSessions(args.slice(1))))
      .catch(error => fail(error instanceof Error ? error.message : String(error)))
  } else if (args[0] === 'backend') {
    runBackend(args)
  } else if (args[0] === 'daemon') {
    void runDaemon(args.slice(1)).catch(error => fail(error instanceof Error ? error.message : String(error)))
  } else {
    void startTui(args).catch(error => fail(error instanceof Error ? error.message : String(error)))
  }
}

// 导入不派发：`tests/launcher.spec.ts` 只取 `stripLegacyProfilePackage`，直接跑会 spawn 真实 dsh。
// npm 的 global install may expose this script through a package-directory symlink; compare
// realpaths so `dpsk` still dispatches when argv[1] and import.meta.url name the same file
// through different paths.
function canonicalScriptPath(file) {
  try {
    return fs.realpathSync(file).replace(/\\/g, '/').toLowerCase()
  } catch {
    return path.resolve(file).replace(/\\/g, '/').toLowerCase()
  }
}
const invoked = process.argv[1] === undefined ? '' : canonicalScriptPath(process.argv[1])
const self = canonicalScriptPath(fileURLToPath(import.meta.url))
if (invoked !== '' && invoked === self) main()
