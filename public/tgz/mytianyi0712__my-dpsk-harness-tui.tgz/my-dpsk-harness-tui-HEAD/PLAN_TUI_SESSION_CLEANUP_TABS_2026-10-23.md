# TUI 会话清理、选择器精简与 OpenCode v2 标签页完善计划

> 日期：2026-10-23
> 状态：实施完成（自动门禁通过；实机待确认；S6 配置层暂缓）
> 版本：保持 0.5.0
> 边界：不改 dsh 上游，不发布、不打 tag、不 push；沿用现有 session-list/session-snapshot/session-op 协议。

## 1. 目标

1. 彻底隐藏空白 live session；截图中不在磁盘上的 tui-22d14... 不得出现在 picker、tabs 或会话计数中。
2. 会话选择页每行只显示标题和右侧 today / yesterday / last 7 days / 日期；不显示 id、cwd、父子关系、status。
3. 完成横向 session tabs 核心状态机：稳定手动顺序、真实标题、草稿 tab、关闭/重开、拖动重排、真实 running 状态。
4. 保持空会话不落盘、resume 干净、classic/compact transcript 不回归。

## 2. 已确认根因

### 2.1 空白 live session

- 截图 id tui-22d14... 不存在于 ~/.dsh/sessions，说明是尚未物化的 live agent。
- src/index.ts 的 pushSessionList 只通过 readSessionHead 判断 untitled 行是否 blank；live 空壳 open() 失败后 catch 返回 blank:false。
- renderer 的 listableSessions 只过滤 blank:true，于是 live 空壳被当作真实会话显示。
- 这是内存 blank 推导缺口，不是 W10 落盘门控失效。

### 2.2 选择器信息过载

- openSessionRows 把 id、workspace、relation、status、attention 放进 details，把 workspace/relation 放进 description。
- DialogSelect 会画 description 和每个 detail，因此一行会话占 3 到 5 行。
- 这些字段应留在 sidebar 或 session info，不属于快速选择器。

### 2.3 Tabs 半成品

- 顺序失效：openTabs 有顺序，openTabSessions 却按 session-list 的最后活动顺序 filter，moveTab 结果不生效。
- 没有草稿 tab：+ 只回 Home，仍高亮旧会话；没有 New Session 状态。
- 标题没有本地快照：catalog 未到或标题为空时 chip 可能空白。
- 缺 hover close、拖动重排、running indicator、完整 Home/draft 语义。
- open/close/reopen/move/cycle 逻辑散落在 app.tsx，缺纯模型和边界测试。
- 缺 ctrl+1..0、tab history back/forward 等 OpenCode 横向 tab 键位。


## 3. 设计决策

### 3.1 空白会话

- live 行在内存判断：无标题、存在 live agent、且 !hasConversationData(sessionEvents(agent.session)) 时标为 blank:true。
- persisted 行继续读日志头；读失败不误判 blank。
- renderer 过滤所有 blank 行，包括 current；Home 由独立 draft tab 表示，不再借用真实空会话。
- host payload 保留 blank 标记，避免破坏 sidebar/current snapshot 回退。

### 3.2 选择器

- 每行固定一行：标题 + 右对齐时间标签。
- 时间标签：today / yesterday / last 7 days / MM-DD；来源 lastActivityAt ?? createdAt，本地时区。
- current 只保留左侧圆点；删除 description、details、category header。
- searchText 可继续包含 id/workspace 用于搜索，但不显示。
- 顶层 current project / all sessions scope 选择保留，描述精简为计数。
- 新增 formatSessionActivityLabel 纯函数并覆盖今天、昨天、7 天内、跨月跨年、缺失时间。

### 3.3 Tab 模型

- 新增 renderer/src/ui/session-tabs-model.ts 纯状态机：TabEntry { id, kind: session|draft, title }。
- TabState v2: { version:2, tabs, closed, history, historyIndex }。
- 真实 session tab 顺序是唯一权威；catalog 的 lastActivity 只影响 picker。
- 最多一个临时 draft；+ / leader n / /new 创建或切回 New Session。
- draft 不写 tabs.json，不触发 host session-op new；首条消息成功后在原 index 提升为真实 session。
- 关闭 active 时右邻 -> 左邻 -> Home；关闭栈保留 title/index；ctrl+shift+t 原位恢复。
- catalog 成功返回后更新 title/status；只有确认列表成功后才清理消失的 tab。

### 3.4 交互

- chip 维持编号 + 标题，增加真实 running spinner/status 色。
- active 始终显示关闭区；hover inactive 覆盖显示 x，不改变标题布局宽度。
- 中键关闭、右键菜单统一走模型；拖动超过 1 cell 才重排，未移动则点击选中。
- + 始终最右；溢出保留 active chip 和 left/right count。
- 补 ctrl+1..0；保留 leader 1..9、ctrl+tab、ctrl+shift+tab、leader w、ctrl+shift+t。
- 本轮只做 horizontal；vertical rail 与 tabs.mode/scope/layout 配置另立阶段。

## 4. 工作包

### S0 基线与失败测试

- 锁定 host 288 / renderer 348 基线，先写红测：live blank、picker compact、tab 顺序、draft、move/reopen/title/status。

### S1 空白 session

- 修改 src/index.ts pushSessionList，合并 live 内存 blank 与 persisted head blank。
- renderer listableSessions 过滤全部 blank。
- 检查历史 setup-only v4 目录清理是否实际执行；只修既有安全条件，不扩大删除范围。

### S2 选择器精简

- openSessionRows 改为 title + footer time + current marker + hidden searchText。
- 删除 session picker 的 details/description/category。
- 增加 i18n 与 40/80/120 列 frame 测试。

### S3 Tab 纯模型与持久化

- 新增 session-tabs-model.ts 与单测；tabs.json 升 v2，兼容旧 { open, closed }。
- app.tsx 只留薄适配：snapshot/list、storage、host switch。
- 覆盖重复 open、重复 draft、close active、close others、reopen index、move clamp、history、catalog refresh、删除清理。

### S4 Draft tab

- + / leader n / /new 创建唯一 draft 并保留 Home 草稿。
- 首条消息发送时乐观占位；session-op new 成功或 snapshot 到达后原位替换为真实 id。
- 失败回滚到 draft，不留下幽灵真实 tab。
- 测试：两个 + 仍 1 个；首条消息后 title/index 正确；切换后 draft 文本保留。

### S5 Strip 交互与标题

- openTabSessions 按 openTabs 顺序 join catalog，不再按 catalog 顺序 filter。
- hover close、拖动重排、running spinner、active 关闭按钮 stopPropagation。
- 标题优先本地快照，catalog/snapshot/rename 后校正。
- 补 ctrl+数字、tab history；40/80/120 列与 CJK 标题 frame 测试。

### S6 OpenCode 配置层（横向验后另做）

- 接 tabs.mode=auto|on|off、tabs.scope=cwd|global、tabs.indicators=status|numbers。
- 不伪造 unread；attention 未接通时只显示真实 running/idle。
- vertical rail 单独立项，不与本轮横向修复混做。

### S7 验证与安装

- npm run check、check:renderer、build、build:renderer、generate:sums。
- 真实二进制 frame smoke：picker、live blank、A/B 切换、拖动、关闭/重开、draft 提升。
- 重新打包全局、同步 tui profile、复制当前平台 renderer 缓存，dpsk check 幂等通过。
- 更新 README、CHANGELOG、contracts、acceptance 和进度文件。

## 5. 验收清单

### 空会话

- [ ] 启动不发送直接开 picker，没有未命名 live session。
- [ ] 当前 Home 空壳不在 picker；退出后磁盘不新增该 id。
- [ ] 首条消息后会话只出现一次，draft title 原位变真实标题。
- [ ] setup-only 历史目录按安全条件清理，真实/live 会话不误删。

### 选择器

- [ ] 每行只有标题和 today/yesterday/last 7 days/日期，无 id、cwd、关系、status。
- [ ] current 只有左侧圆点；Enter/点击切换正常。
- [ ] 40/80/120 列 CJK 标题不换行，时间右对齐。

### Tabs

- [ ] catalog 因活动时间重排时，顶部 tab 保持用户手动顺序。
- [ ] + 打开唯一 New Session tab；首条消息原位替换，无第二个空 tab。
- [ ] active close 右邻 -> 左邻 -> Home；中键/右键/leader w 不串动作。
- [ ] ctrl+shift+t 回原 index；拖动顺序重启后保留。
- [ ] hover inactive 出现关闭 affordance；active 标题/编号清晰。
- [ ] running tab 有真实状态；无 unread/attention 假图标。
- [ ] snapshot/list/rename 后标题更新；删除 session 清 tab 和 closed 栈。
- [ ] 40x16、80x24、120x30 无重叠、无标题空白、overflow count 正确。

## 6. 风险与约束

- live blank 必须用 hasConversationData 判断；首条 user message 到达后立即解除 blank。
- 不得用 catalog 的 lastActivity 顺序渲染 tabs。
- draft 不得触发持久化，否则又会产生空会话。
- hover/拖动不能吞 click；沿用 moved 阈值与 stopPropagation，先写 frame/interaction 测试。
- 不引入假状态；attention/unread 当前无真实数据。
- 本轮不改上游协议；优先复用 blank/status/lastActivityAt。

## 7. 建议顺序

S0 -> S1 -> S2 -> S3 -> S4 -> S5 -> S6（可选）-> S7。

S1/S2 可先独立交付并消除截图问题；S3-S5 完成 tab 核心；S6 在横向 tabs 实机验收后再进入。


## 8. 补充需求（2026-10-23 第二轮）

### 8.1 运行态 footer：esc interrupt 替换 cwd

现状：renderer/src/app.tsx 的 statusCwdRow 左侧固定画 workspace，右侧在 idle 时画 shift+tab agent / ctrl+p commands，在 running 时把右侧换成 spinner + esc interrupt。

目标：

- idle：左侧 cwd，右侧 shift+tab agent / ctrl+p commands。
- running：左侧 workspace 消失，改为 spinner + esc interrupt；右侧仍保留 shift+tab agent / ctrl+p commands。
- 窄终端优先级：esc interrupt 永远保留；右侧提示可先缩短或丢弃；不再为了运行态挤掉 cwd 之外的命令提示，也不再让 cwd 与 interrupt 同时占左。
- 动画只有真实 turnRunning 才播放，idle 不保留 spinner 帧。

实现建议：

- 把 statusBarFirstLine 扩展为接受 leftOverride / reservedLeft 的纯布局函数，或在 app 里先计算 running 左侧宽度再调用新函数。
- statusCwdRow 改成显式 left = running ? interrupt : directory；hint 始终来自 rendererHomeKeys。
- 补 frame 测试：80x24 下 idle/running 的左右文案切换；40 列下 interrupt 保留且命令提示按需截断。

### 8.2 思考强度循环快捷键

- 现状已有 Ctrl+T 绑定 cycle-effort，按 efforts 列表向前循环并在末尾回到开头。
- Tab 是补全键，不能改为思考强度；Ctrl+Shift+T 已是 reopen closed tab，也不能复用。
- 当前没有反向循环键；若后续需要，建议另选 Ctrl+Alt+T 或 Alt+Shift+T，不占用 Tab / Ctrl+Shift+T。
- 本轮只补 keymap、帮助文案和测试，确保 Ctrl+T 在 Home/Session、空 effort、单 effort、多 effort 下行为一致。

### 8.3 用户目录 ~ 显示与设置

目标：

- 所有用户可见的目录展示默认将用户根目录缩写为 ~；Windows 同样默认 C:\Users\<user> -> ~，Linux /home/<user> -> ~。
- 设置页新增 path display 切换：~ abbreviation 与 full path；默认 ~ abbreviation。
- 只改变显示，不改变 workspace、请求、附件、shell、terminal、剪贴板或导出中的真实全路径。

实现建议：

- 新增 renderer/src/ui/path-display.ts 纯函数 formatDisplayPath(path, { home, mode, platform })。
- Windows 用 win32 规则，Linux/macOS 用 posix 规则；大小写匹配仅在 Windows 忽略。
- 边界：home 本身、home 子目录、相似前缀 (mecode vs me)、尾部斜杠、UNC/盘符、相对路径、空路径。
- 确保 ~ 后使用正斜杠，例如 ~/Projects/dsh；full 模式返回原始路径。
- truncateDirectory 保留 ~ 锚点：宽度足够时显示 ~/…/tail，不把 ~ 截掉；窄宽度仍优先末级目录。
- 在 statusCwdRow、Home 的 cwd 行、session picker 的 project scope 描述、session status 详情、terminal picker 描述等展示入口统一调用；sidebar 的 basename 不变。
- renderer 已有 node:os homedir；不新增协议字段。若未来 remote renderer，再把 homeDir 放入握手 payload。

设置与持久化：

- 新增 TuiSettings / TuiConfigSchema 字段 pathDisplay，值 tilde 或 full，默认 tilde，volatile。
- /settings -> appearance 增加 path display 行：home directory: ~/... / full path。
- 通过现有 update-settings patch 写入；旧配置缺字段时默认 tilde，不迁移、不重写已有配置。
- docs/contracts 记录显示语义；README 记录 Windows 和 Linux 默认行为。

测试：

- 纯函数测试 Windows / POSIX / 大小写 / 相似前缀 / 精确 home / full 模式。
- status bar 与 Home frame 测试：默认显示 ~，设置 full 后显示完整路径，重启后保持。
- 40/80/120 列：~ 路径截断、CJK 目录、full long path 不越界。
- 运行态 frame：running 时 cwd 被 esc interrupt 替换，但右侧 shift+tab / ctrl+p 命令提示仍在。

## 9. 更新后的实施顺序

S0 -> S1 -> S2 -> S8.1 -> S8.3 -> S3 -> S4 -> S5 -> S8.2 -> S6（可选）-> S7。

S1/S2 先解决截图中的空会话和选择器；S8.1/S8.3 是独立视觉修复，可并行验证；S3-S5 完成 tab 核心；S8.2 只补快捷键帮助与回归测试。

## 10. 实施结果

- S1-S5、S8.1-S8.3 已完成；宿主 290 项、渲染器 376 项全绿。
- S6 tabs.mode/scope/layout/indicators、vertical rail 与 tab history back/forward 暂缓，待横向 tabs 实机验收后再做。
- 构建、7 平台产物、全局安装、tui profile 同步与 `dpsk check` 幂等均已完成。下一步只剩用户按 acceptance 第 7 节实机确认。


