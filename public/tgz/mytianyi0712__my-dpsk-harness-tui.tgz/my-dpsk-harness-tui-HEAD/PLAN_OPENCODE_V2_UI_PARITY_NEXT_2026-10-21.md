# 0.5.0 TUI 外壳视觉续迁计划（2026-10-21）

> 目标：基于用户提供的 Windows Terminal 对比图，修复上一阶段会话主流程之外仍明显偏离 opencode v2 的 shell、侧栏和 session tabs。版本仍保持 `0.5.0`；不改 dsh 上游/backend，不发布、不打 tag、不 push。
>
> 本计划只授权本仓库 TUI adapter、renderer、IPC mirror、测试和文档修改。不得因为参考 UI 需要而修改 `@deepseek-ai/dsh` 或上游事件生产逻辑。

## 1. 当前结论

上一计划 T0–T3 与 T6 的自动化实现基本完成；T1/T2 修复另有编译后二进制流式驱动验证。T5 的 Home 共享 tab strip 行为已实现。T4 仅核心 transcript 样式完成，T7 未完成实机验收。用户提供的截图证明程序能显示 CJK 会话、reasoning、正文、metadata 和右侧信息，但用户明确指出外观仍与 opencode 差别很大，因此不能把“自动门禁通过”记作整体 parity 完成。

本计划的基线：

- 当前 footer 还绘制 workspace/location、context、queued/subagents（按配置）、`ctrl+p commands`；WeChat 状态另占一行。部分信息与 sidebar 重复，垂直空间成本在底部持续存在。
- Sidebar 主体已有独立 scrollbox，但关闭了垂直 scrollbar；provider/model 与 workspace/branch 固定在底部，和主信息滚动区分离。
- Sidebar 隐藏时没有在 tabs 上方显示当前 session title 行。
- Session strip 的绘制模型只接收 `id/title/active`，显示序号、截断标题和 active 的 `×`；没有显示 workspace/branch/subagent parent 等 session detail，也没有 hover title/marquee。
- host `session-list` 已提供 `workspace/parentId/createdAt/status/attention`，但 renderer 的 `SessionTab` 缩减成三字段；host 当前将 `attention` 固定为 `false`。
- active 高亮依赖 host 异步推送的 `sessions[].active`。session snapshot 已即时更新 `currentSession`，应以 renderer 的当前 session id 作为 selection truth，避免切换期间高亮滞后。
- opencode tabs 有 active elevation、hover/drag、详情、busy/unread/attention feedback、横向 adaptive layout；本项目不应在缺少数据时伪造 unread/attention。

## 2. 设计原则与不做事项

- 以图二为结构参考，以当前 dsh 实际 payload 为事实来源；不可用字段不伪造。
- 可见会话细节优先复用 session-list 已有字段：标题、workspace basename、branch（若已能从 host 读出并随 session catalog 提供）、父 session/subagent 标识、running/idle。不要在 renderer 为每个 tab 重读 session log。
- 切换选中态以当前 session id 为准；不等待 session-list 的异步 active 标志。
- 窄终端采用确定性降级，不水平挤压成难读字符；超长文字按终端 cell width 截断，hover/焦点可看完整 detail（若 OpenTUI 当前组件能力支持）。
- Sidebar 长列表可滚动，标题与固定 footer 不随内容滚出；滚动条可见且不改变内容宽度。
- 先定义截图矩阵和 acceptance frames，再实现；每个阶段保留可回退的小提交范围，但未经用户确认不提交。
- 不做垂直 tabs rail、动画 marquee/拖拽复刻、attention/unread 假数据、cost 推断、后端事件扩展。这些除非后续用户明确要求且有真实数据支撑。

## 3. 工作包

### N0：冻结基线与视觉验收矩阵（0.5 天）

- 保留用户提供的两张截图作为人工对照基线（只引用，不改写附件）。
- 从当前实现生成/更新 char-frame fixture，覆盖 80x24、120x30、窄终端（40x16）及右 pane dock/overlay。
- 验收维度分区：顶部 tabs、隐藏侧栏标题、prompt metadata、footer、sidebar 长列表/滚动条、活动 tab 切换。
- 记录当前可复现差距；临时诊断代码和 scratch 文件不进入正式交付。

**验收**：基线 frame 可重复；窄/标准/宽终端预期行数和左右 pane 宽度有断言；没有通过改色掩盖结构问题。

### N1：底部两行状态栏与信息归属（0.5–1 天）

底部固定两行，禁止再加常驻第三行：

```text
<当前工作目录，左对齐，智能截断>                         <Ctrl+P 命令提示，右对齐，可隐藏>
                 <轮次/步骤 · tok/s | 总 tokens · cache hit% | context/window (pct)>
```

- 第一行左侧显示当前工作目录。优先显示完整 cwd；宽度不足时依次退化为最后一个目录名、最后目录名的尾部加 `...`（按终端 cell 宽度），极窄时尽量保留最后 1–3 个可见字符和省略号。不能从中间截断后让用户误认路径。
- 第一行右侧显示 `Ctrl+P commands` 等命令面板提示；先隐藏该提示，再压缩 cwd。提示不得挤掉或覆盖 cwd。
- 第二行水平居中，按有数据的 segment 显示：最近完成的 `turn/step`、该 step 的 `tok/s`、总 token、缓存命中率、context used/window/percent。建议紧凑形式 `T12 S4 · 72 tok/s | 28.4k tokens · cache 63% | 8.4k/64k (13%)`，分隔符只在两侧 segment 都存在时绘制。
- 总 token 定义为累计 `inputTokens + outputTokens + cacheReadTokens + cacheWriteTokens`；token meter 将 input 作为 uncached input，cache read/write 独立记账。
- 缓存命中率定义为 `cacheReadTokens / (inputTokens + cacheReadTokens + cacheWriteTokens)`。分母为 0 或 cache 字段不可用时显示 `—`/省略，不推算命中。实现前须核实 dsh token-meter 对缺失 cache bucket 的语义；现有 host 累计器将缺字段按 0 处理，若无法区分“真实 0”和“未知”，应增加本仓库 TUI usage 可用性标记/adapter fallback，而不是把未知呈现成 0% 命中。不得修改上游。
- 当前 host 的 `tok/s` 与 `turn/step` 只在 assistant durable row 有值；显示最近完成的 assistant step，流式期间保留最近值或显示 `…`，禁止用字符数估速。若后续要实时值，另行评估本仓库 adapter 是否能从现有 stream 边界无损派生，不能要求上游新增事件。
- WeChat 在线状态、MCP、插件、provider/model、workspace branch、长路径等额外信息全部放在侧栏；WeChat 不再占底栏第二行。
- 左右 prompt 模板不能覆盖固定两行布局；保留设置兼容策略需先审计现有使用者，最终 footer 的两行语义由 shell 控制。必要的运行/中断操作仍需可见/可触发。

**验收**：80x24 永远恰好两行底栏；cwd 超长与 CJK 的截断不越界；提示空间不足时先隐藏；第二行严格居中且仅画真实数据；token/cache/context 公式有纯函数测试；WeChat 不增加底部行；turn running 时仍可中断。

### N2：Sidebar 信息层级与滚动（0.5–1 天）

- 不实现 tabs 上方的额外 session title/header 行。所有会话额外信息只在侧栏显示。
- 侧栏固定标题显示 session title；内容区独立滚动，provider/model、workspace/branch 和必要运行状态作为固定 footer 或侧栏可读 section。
- 显示真实 session/workspace 信息；按 42 列侧栏和 resize 后宽度 cell-aware 截断，不能把插件名/路径挤出边界。cwd 在侧栏可完整查看或以可读方式分段显示，不受底栏短路径规则限制。
- 为内容区启用垂直滚动条；track 放在预留的右侧 padding 内，显示/隐藏不得改变文本宽度。横向滚动始终关闭。
- WeChat 当前状态、MCP、插件目录放入可滚动主体，长目录不得推出固定 footer。侧栏高度不足时优先保证可滚动的主体区域，不挤掉标题和关键 session identity。

**验收**：长插件/MCP/WeChat 信息可用滚轮滚动；侧栏 title 与 route/workspace 信息可读；窄 overlay/docked 都无重叠；侧栏隐藏时不插入 title 行，底部状态栏仍然恰好两行；Home 不画伪 session 信息。

### N3：Session tabs 细节和即时 selection（1–2 天）

- 将 tab 模型接入已有协议的 `workspace/parentId/createdAt/status`，供侧栏当前 session detail、tab picker/menu 使用；tab strip 本身保持紧凑，不重复显示这些额外信息。
- active 由 `currentSession()` 派生，不把异步 catalog active 当成唯一来源；`session-snapshot` 到达时立即更新高亮，旧 list response 不能短暂重选旧 tab。
- tab label 使用准确 session title，按可用宽度 cell-aware 截断；workspace/branch/subagent parent/running 状态在侧栏或既有 tab management surface 查看，不加顶部标题行或挤入标签文字。
- 保持 active elevation/色彩对比清晰；不只靠低对比背景差异，至少 active 标题/序号有语义色或强调属性。关闭符号仅在 active/hover 出现，避免每个 tab 常驻占宽。
- 拥挤时 active tab 必须保留可读标题，邻接 tabs 按预算缩小，overflow controls 显示隐藏数量；窄终端验证 add/close/menu 命中区不重叠。
- 对 running 状态只在明确活跃 tab 可用的既有数据处显示；attention/unread 保持不显示，因为 host 当前 payload 固定 false。

**验收**：切换 A→B 后首个 snapshot frame active 高亮为 B；catalog 延迟/乱序不能回滚 active；长标题与多 tab 下 active 可识别；额外 session detail 只在 sidebar/picker/menu，不出现在 tab strip/footer；40/80/120 列无重叠；Home/session 共用 selection 状态；鼠标与键盘选择一致。

### N4：整体集成、人工 TTY 验收与计划收口（0.5–1 天）

- 更新两行 footer、sidebar、tabs char-frame；运行 host、renderer、protocol、license、7-platform build/package gates。
- 对比用户实机截图，重点检查底栏严格两行、cwd 短路径优先级、命令提示隐藏规则、第二行居中、侧栏长列表滚动、tab active 高亮。
- 由用户在 Windows Terminal 或 WezTerm 实测：滚动、输入法、CJK cell width、窄终端、sidebar toggle、tab 切换/关闭、切到 Home 再返回。
- 只记录用户实际验收过的项目；没有用户确认的实机项保留为未完成。

**验收**：自动 gates 全绿；无新增 dsh 上游修改；用户确认上述实机检查；0.5.0 保持未发布、无 tag、无 push。

## 4. 依赖与顺序

`N0 → N1 → N2 → N3 → N4`

N0 → N1 先冻结尺寸基线并实现两行 footer；N2 固定 sidebar 的滚动与信息归属；N3 只优化紧凑 tab strip 和即时 selection，不在顶部增加标题行。N1–N3 可各自独立测试，但不可跳过 N0 的 frame 基线。

估算总计 **3–5 工程日**，不含用户排期的实机验收。

## 5. Definition of Done

- 底栏严格两行：第一行 cwd 左对齐、Ctrl+P 提示右对齐且按优先级隐藏；第二行居中显示真实 turn/step、TPS、总 token、缓存命中率和上下文使用。
- Sidebar 长内容可滚动，scrollbar 可见且稳定；session title、route/workspace 与其他额外信息只在侧栏，不在 tabs 上方增加标题行。
- Tabs 切换时高亮即时且稳定；active tab 在拥挤场景仍容易识别；没有伪造 unread/attention。
- 40x16、80x24、120x30 frame 无截断越界/控件重叠；活动 tab、scroll、overlay/docked 状态都覆盖。
- 所有自动门禁通过；用户完成 Windows TTY/IME/CJK 验收；不修改上游、不发布、不打 tag、不 push。

## 6. 当前进度

| 工作包 | 状态 | 证据/剩余 |
|---|---|---|
| N0 基线 | 完成 | 两行底栏的尺寸/内容契约固化在 `status-bar.test.ts`（纯函数）与 `layout.test.tsx` / `app.test.tsx`（char frame）；用户两张截图作为人工对照基线。 |
| N1 两行状态栏 | 完成 | `renderer/src/ui/status-bar.ts`：cwd 智能截断、提示优先让位、token/缓存/context 公式、居中；`Shell` 根节点统一挂载 `STATUS_BAR_ROWS = 2`，运行中 spinner + `esc interrupt` 并入第一行右侧；usage 新增 `cacheBucketsComplete`。 |
| N2 Sidebar | 完成（本篇范围） | WeChat 状态/二维码、harness 版本移入侧栏；Home 与 Session 用同一停靠规则（宽终端分栏、窄终端 overlay）；滚动条启用且绝对定位在右侧 padding；长清单不挤出标题/页脚（新增 frame 测试）。 |
| N3 Tabs | 完成（本篇范围） | strip 的 `active` 改由 `currentSession()` 派生，切换首帧即换高亮，catalog 晚到不会回滚；额外 session detail 仍由侧栏承载，未在顶部增加标题行。 |
| N4 综合验收 | 部分 | 自动门禁全绿（host 237 / renderer 255）；`tmp/check-frame.ts` 与 `tmp/check-status.ts` 两个真实二进制驱动全部通过（含 30 列 cwd 退化、usage→底栏链路、停靠时按终端宽度居中）；侧栏滚轮、Session/Home 补全弹窗贴边、缓存完整性均有回归测试；实机验收清单见 `docs/ACCEPTANCE_TUI_SHELL.md`，等待用户逐项确认。 |

## 7. 边界说明

旧计划中标为“完成”的 T5 仅表示 Home 上 tabs 保持可见，不代表 tabs 已达到 opencode 的 session detail/selection parity。旧计划 T7 的自动门禁通过也不代表整项完成：用户的实机反馈已明确判定视觉验收失败。此续迁计划不重开已验证的 streaming/model picker 逻辑，除非 N4 回归发现问题。
