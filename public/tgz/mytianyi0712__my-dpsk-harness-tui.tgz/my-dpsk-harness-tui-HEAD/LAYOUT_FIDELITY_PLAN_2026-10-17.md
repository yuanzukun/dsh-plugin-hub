# dsh 布局保真度复查与下一步开发计划（2026-10-17）

本文是 0.5.0 之后的复查结论与开发计划。复查方法：真实渲染器画面重建（两帧，80x24 与
120x30）、渲染树逐行核对、opencode v2 上游源码取规范、IPC kind 表与宿主数据面核对。
`HANDOFF_0.5.0_2026-10-17.md` 说 S1–S9 走完、门禁全绿，与实机布局混乱**不矛盾**：现有验收
只断言子串，没有任何断言检查区域顺序、宽度、边框、对齐。

---

## 1. 结论

渲染器目前**不是** opencode v2 的布局，而是 0.5.0 S4 的布局骨架（`renderer/src/app.tsx:5-8`
自述「S4 ships the layout skeleton only」）加上后续批次往这个骨架里塞的数据行。opencode v2
的核心区域一个都没有实现。用户看到的「进入后布局混乱」由 7 个根因造成（§2.3）。

功能面（对话框几何、补全、表单、i18n、微信桥、子代理、设置页）是照 opencode 移植的，这部分
是对的；**布局骨架与呈现层是空缺**。

## 2. 证据

### 2.1 实测画面

`tmp/layout-capture.ts`（真实编译产物 `renderer/dist/dpsk-renderer-win32-x64.exe`，80x24）与
`renderer/layout-120.tsx`（`testRender`，120x30 与 80x24）重建的画面：

120 列（30 行）：

```
  1 |┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐|
  2 |│ dpsk host: my-dpsk-harness-tui 0.5.0                                                                                 │|
  3 |│session: first prompt                                                                                                 │|
  4 |│sessions: ●first prompt ○second session ○third session with a long title that overflows the rail                      │|
  5 |│user:     hello                                                                                                       │|
  6 |│assistant:short answer                                                                                                │|
  7 |│read:     src/host/renderer-process.ts                                                                                │|
  8 |│          line 108-177                                                                                                │|
  9 |│assistant:这是一段很长的中文文字，用来测试在 120 列终端下的换行与缩进行为，观察它是否溢                               │|
 10 |│          出边框、是否把后面的行挤掉、以及续行的缩进是否与首行对齐。                                                  │|
 11 |│bash:     npm run check                                                                                               │|
 12 |│          verify:boundary ok                                                                                          │|
 ...
 25 |│↳ explorer · cliproxy · one-shot                                                                                      │|
 26 |│composer: prompt, /command, Ctrl+P palette                                                                            │|
 27 |│generating (Enter queues an interjection)                                                                             │|
 29 |│status: compatible · cliproxy/mimo-v2.6-pro · high · auto · standard                                                  │|
 30 |└──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘|
```

要点：内容行只到第 88 列（`Row` 写死 `width={88}`，`app.tsx:921-923`），120 列下右边 32 列
空白，边框右缘与内容右缘不齐；composer 在第 26 行，随 subagents 块出现被推上（80 列下从第
21 行变到第 20 行，生成中提示插到它下面）。

80 列：sessions 轨道无截断，折成两行且列错位：

```
  4 |│sessions●first     ○second      ○third session with a long title that         │|
  5 |│        prompt     session      overflows the rail                            │|
```

### 2.2 渲染树（`renderer/src/app.tsx:959-1085`）

单列堆叠，全部 `width="100%"`，无 flex 分区，无绝对定位区域：

| 顺序 | 区域 | 实现 |
|---|---|---|
| 1 | 根盒 | `width/height 100%` + `borderStyle="single"`（opencode 根无边框） |
| 2 | header | ` dpsk ` + hostLabel |
| 3 | session 行 | label + title |
| 4 | sessions 轨道 | 行内 `●/○` + 标题，无截断 |
| 5 | transcript | `flexGrow={1} minHeight={1}` 普通 box，**无 scrollbox** |
| 6 | subagents | 条件块，插在 transcript 与 composer 之间 |
| 7 | 微信 QR | 条件块，同上 |
| 8 | composer | label + `input width="70%"` |
| 9 | 生成中提示 | 条件行 |
| 10 | slash 补全 | 流内行（非 popup） |
| 11 | notices | 流内行（非 toast） |
| 12 | `@` 补全 | 流内行（非 popup） |
| 13 | DialogLayer | 遮罩 + 面板（照 opencode 移植，正确） |
| 14 | 微信状态行 | 条件行 |
| 15 | status 行 | provider/model · effort · permission · preset |

### 2.3 根因

1. **固定宽度**：`Row` 写死 `width={88}` / `width={10}` / `width={78}`（`app.tsx:921-923`），
   composer `width="70%"`（`app.tsx:1008`）。终端宽度变化时内容右缘与边框右缘不齐，窄终端溢出
   触发折行。
2. **transcript 无滚动容器**：`flexGrow` box 装全部行（`app.tsx:985-988`），无 sticky bottom、
   无 scrollbar、无 jump-to-latest 行。长会话溢出后被裁，且没有「回到最新」的入口。
3. **composer 未钉底**：条件块（subagents / QR / 生成提示 / slash 补全 / notices / `@` 补全）
   插在 transcript 与 composer 之间的流里，随状态出现消失，把 composer 与 status 行推上推下。
4. **无区域划分**：没有左侧竖 tab 栏、没有右侧 sidebar、没有右 pane、没有 pane 分隔手柄、没有
   toast、没有 spinner、没有 markdown 渲染、没有工具卡、没有 prompt footer。
   `grep markdown|spinner|sidebar|pane|tab|toast` 在 `renderer/src` 内零命中（对话框注释
   `ui/dialog.tsx:16-17` 明确「toast overlay 未移植」）。
5. **补全不是 popup**：slash 与 `@` 补全是流内行（`app.tsx:1033-1056`），opencode 是挂在 prompt
   锚点上方、宽度=prompt 宽、最多 10 行的绝对定位 popup。
6. **数据面缺口**：宿主已算出 `tokenTotals`（`src/index.ts:753-754`、`1347-1351`、`1820-1825`）、
   `contextWindow`（`src/index.ts:1825`）、`gitBranch`（`src/index.ts:752`）、MCP/plugin 状态、
   subagent/shell 计数，但 IPC 28 个下行 kind（`renderer/src/protocol/kinds.ts:27-56`）与
   `RendererMountDeps`（`src/host/renderer-mount.ts:30-164`）里**没有**任何 usage / context /
   cost / todos / MCP / tab / pane / terminal-size kind。渲染器拿不到，prompt footer 与 sidebar
   无法实现。
7. **键位缺口**：`BINDINGS`（`renderer/src/keymap/keymap.ts:40-51`）只有 `ctrl+p`、`ctrl+t`、
   `ctrl+x n,l,m,t,c,s,x,q`。opencode 的 `leader b`（sidebar）、`leader left/right`（pane 焦点）、
   `leader t`（terminal pane，被 theme 占用）、`ctrl+tab`（tab 切换）、`escape`（中断）、
   `ctrl+b`（后台化）、`shift+tab`（agent 循环）、`f2`（model 循环）、prompt 的 `up/down` 历史
   （现在归 dialog）全部没有。`MODAL_BINDINGS` 的 `up/down` 只服务 dialog。

### 2.4 测试面

- `renderer/src/app.test.tsx`、`ui/dialog.test.tsx`、`tests/renderer-mount.spec.ts`、
  `tests/renderer-process.spec.ts`、`tmp/check-frame.ts`：断言子串（`frame).toContain(...)`）。
- `renderer/src/ui/narrow.test.tsx`：断言每行长度 ≤ 终端宽、面板宽度表 60/88/116、`<60` 列
  footer 竖排。**没有任何断言检查区域顺序、区域宽度、边框、缩进、对齐、粘底。**
- 结论：门禁全绿（289 tests / 288 pass / 0 fail / 1 skipped；`test:renderer` 89 pass）与布局
  混乱同时成立，验收标准缺几何维度。

## 3. 目标布局规范（opencode v2，`anomalyco/opencode` dev 分支 `packages/tui`，2.0.32）

来源为上游真实源码（逐文件 raw 读取），非文档转述。`vendor/opencode/` 只有 dialog/keymap/theme
文件，**没有任何布局文件**，不能当布局参考。

### 3.1 根树

```
<box width=termW height=termH column bg=background.base>            // 无边框、无 padding
  <box flexGrow=1 minHeight=0 row position=relative>                // main row
    [SessionTabs orientation=vertical width=42]                     // 条件：竖栏
    <box flexGrow=1 minWidth=0 column>                              // content column
      [SessionTabs 横 strip height=1 flexShrink=0]                  // 条件：横 tab
      <Switch> Home | SessionFrame | PluginRoute </Switch>
    </box>
    [PaneResizeHandle]                                              // 条件
  </box>
  [DevToolsBar height=1]                                            // 条件
  [StartupLoading]  [Reconnecting]  [MigrationOverlay]  [Toast]     // 绝对定位
</box>
```

区域分离靠**背景色**（`background.base` vs `background.raised.base`）与区域内 padding，不靠边框。

### 3.2 Session route（`component/session-frame.tsx` + `routes/session/index.tsx`）

```
row [
  session pane (flexGrow=1 flexBasis=0 minWidth=0, 外 padding 左右 2（<44 时 1）、paddingBottom 1)
    transcript scrollbox (flexGrow=1, stickyStart=bottom, scrollbar 可选)
    jump-to-latest 行 (height=1, justifyContent=flex-end)           // awayFromBottom 时
    prompt 栈 (flexShrink=0)：
      queued dock → composer.top slot → Composer drawer →
      PermissionPrompt | FormPrompt | LocationMissing | Prompt
  right pane (flexShrink=0, width 42 | 可 resize | fullscreen)
    Sidebar | PanelHost | TerminalPane                              // 仲裁：panel > sidebar > terminal
  PaneResizeHandle
  [sidebar 作为遮罩 overlay]                                        // ≤120 列时不 dock
]
```

### 3.3 Prompt（`component/prompt/index.tsx`）

```
<box width=100%>                                   // home 里 maxWidth=75
  <box border=["left"] glyph ┃ (bottom-left ╹) customBorderChars=SplitBorder>
    <box paddingLeft/Right=W<44?1:2 paddingTop=1 flexShrink=0 bg=decrease(raised.base) flexGrow=1>
      [image strip]
      <textarea width=100% minHeight=1 maxHeight=max(6, floor(termH/3))/>
      <box row justifyContent=space-between paddingTop=1 gap=1>  // metadata 行
        agent · model · provider · variant                        // 按测量宽度逐级丢
      </box>
    </box>
  </box>
  <box height=1 border=["left"]> <box height=1 border=["bottom"] horizontal="▀"/> </box>  // shadow lip
  <box row justifyContent=space-between gap=2>   // footer 行
    左：spinner + "esc interrupt"（运行中）| cwd[:branch]
    右：file-context · contextTokens(percent%) · $cost · N subagents · N shells · 键位提示
  </box>
</box>
<Autocomplete/>   // 绝对定位，挂在 prompt 锚点上方，width=prompt 宽，height=min(10,…)
```

### 3.4 转写行节奏（`routes/session/index.tsx` + `message-parts.tsx`）

- 每行包装：`marginTop={1}`、`flexShrink={0}`。
- **user**：`border=["left"]` `┃`（agent 色），bg `raised.base`，padding top1 bottom1 left2。
- **assistant 文本**：`paddingLeft=3`，markdown 渲染（`theme.markdown.text` / `background.base`），
  表格 grid。
- **reasoning**：`paddingLeft=3`；折叠时一行 `Thought: …`；展开时左边界代码块。
- **inline 工具行**（shell/glob/read/grep/webfetch/subagent…）：`paddingLeft=3`，icon 格
  `width=2` + 弹性标签；pending 用 Spinner 替换 icon，失败 `✗`（error 色），denied 删除线。
- **block 工具行**（edit/apply-patch）：左边界 `┃`，padding top1 bottom1 left2，bg `raised.base`，
  header `label + FilePath`，diff body `paddingLeft=1`，宽度 >120 用 split diff。
- **assistant footer**：`paddingLeft=3`，`Agent · Model · Duration · tok/s · interrupted`；
  宽度 <28 隐 model，28..35 隐 duration。

### 3.5 常量与断点（`ui/layout.ts`）

| 常量 | 值 |
|---|---|
| `SESSION_SIDEBAR_WIDTH` | 42 |
| `SESSION_TABS_COMPACT_WIDTH` | 5 |
| `SESSION_TABS_COMPACT_BREAKPOINT` | 12 |
| `SESSION_SIDEBAR_MAX_WIDTH` | 72 |
| `SESSION_CONTENT_MIN_WIDTH` | 44 |
| `SESSION_CONTENT_PREFERRED_WIDTH` | 64 |
| `SESSION_PANEL_SPLIT_MIN_WIDTH` | 108 |

断点：`<12` 竖栏 compact；`<22` logo 塌；`<28` assistant footer 隐 model；`28..35` 隐 duration；
`<44` prompt/home padding 2→1、metadata 丢标签、home footer 隐藏；`<60` dialog footer 竖排；
`<64` home footer 隐 `/mcps`+版本；`<80` permission footer 竖排、prompt footer 中断时隐细节、
home footer 隐 `/plugins`；`≤120` sidebar 不 dock（变 overlay）；`width - rail > 120` 才 dock；
`<108` panel 不能 split（全屏）；`<106` 竖 tab 退化为横 strip；dialog 列表
`maxHeight=floor(h/2)-6`，面板 `maxWidth=W-2`。

### 3.6 键位（`config/keybind.ts`）

leader `ctrl+x`；`ctrl+p` palette；`leader l` 会话列表；`leader n` 新会话；`leader b` sidebar；
`leader left/right` pane 焦点；`leader t` terminal pane；`leader down/up` 选/关 terminal；
`ctrl+tab`/`ctrl+shift+tab` 换 tab；`leader 1..9` 选 tab；`leader w` 关 tab；`escape` 中断；
`ctrl+b` 后台化；`shift+tab` agent 循环；`f2`/`shift+f2` model/variant；`ctrl+t` variant；
`return` 提交、`shift/ctrl/alt+return`/`ctrl+j` 换行、`leader return` 排队；prompt `up/down`
历史（仅当光标在首/末可视行）；autocomplete `up/ctrl+p`/`down/ctrl+n`/`return`/`tab`/`escape`。

## 4. 差距清单

| # | 差距 | 现状锚点 | 目标锚点 |
|---|---|---|---|
| G1 | 根盒带单线边框，区域靠边框分离 | `app.tsx:960` | 无根边框，靠 bg + padding |
| G2 | 固定宽度 88/10/78/70% | `app.tsx:921-923`、`1008` | 终端相对 flex |
| G3 | transcript 无 scrollbox / 无粘底 / 无 jump 行 | `app.tsx:985-988` | `index.tsx:1390-1461` |
| G4 | composer 未钉底，条件块插在流里 | `app.tsx:993-1056` | prompt 栈 `flexShrink=0` |
| G5 | 无竖 tab 栏（会话列表） | `app.tsx:970-980`（行内轨道） | `session-tabs.tsx` 竖栏 42 |
| G6 | 无右 sidebar（context/MCP/cwd:branch） | 无 | `sidebar.tsx` + `feature-plugins/sidebar/*` |
| G7 | 无右 pane（terminal/plugin）与 resize handle | 无 | `session-frame.tsx:354-395` |
| G8 | 无 toast | notices 流内行 `app.tsx:1045-1047` | `ui/toast.tsx`（top1 right2，maxWidth min(60,W-6)） |
| G9 | 无 spinner（运行中/工具 pending） | 一行文字 `app.tsx:1026-1030` | `component/spinner.tsx` 40ms 帧 |
| G10 | 无 markdown 渲染 | `Row` 纯 text `app.tsx:924` | OpenTUI `Markdown` renderable |
| G11 | 无工具卡/inline 工具行节奏 | `Row` label+output `app.tsx:921-929` | `message-parts.tsx:158-232` |
| G12 | 无 prompt 左边界/padding/shadow lip/metadata | `app.tsx:1005-1023` | `prompt/index.tsx:1657-1877` |
| G13 | 无 prompt footer（context %、cost、cwd:branch、键位提示） | status 行 `app.tsx:1065-1082` | `prompt/index.tsx:1878-1970` + `feature-plugins/prompt/footer.tsx` |
| G14 | 补全是流内行，非 popup | `app.tsx:1033-1056` | `autocomplete.tsx:822-952` |
| G15 | 无 Home 路由（首屏居中 logo + maxWidth 75 prompt + home footer） | 无 | `routes/home.tsx:88-135` |
| G16 | 数据面缺 usage/context/cost/todos/MCP/branch | `renderer/src/protocol/kinds.ts:27-56`、`src/host/renderer-mount.ts:30-164` | 新增 kind + deps |
| G17 | 键位缺 sidebar/pane/tabs/interrupt/background/agent 循环/model 循环/prompt 历史 | `keymap.ts:40-51` | `keybind.ts` 表 |
| G18 | 断点表缺（只有 dialog `<60` 竖排） | `ui/dialog.tsx:220` | §3.5 全表 |
| G19 | 测试无几何断言 | `app.test.tsx`、`narrow.test.tsx` | 几何断言套件 |
| G20 | vendored 布局参考缺失 | `vendor/opencode/` 无布局文件 | 取上游布局文件登记 NOTICE |
| G21 | 无 `overflow="hidden"`，溢出内容画在兄弟区域之上（重影/叠字） | `app.tsx:960-1082`（全树无一处设 overflow） | 每个区域显式 `overflow="hidden"` |
| G22 | 对话框遮罩尺寸按终端算，却嵌在 1 格边框内 → 遮罩与面板整体偏移 1 格、叠画；嵌套对话框各自加一层 150 alpha 变暗；面板内宽度按名义 60/88/116 算，不按 clamp 后的实际宽度算 | `ui/dialog.tsx:140-175`、`ui/dialog-select.tsx:237` | 遮罩在无边框根下；`width=min(size, W-2)` 贯穿到内容宽度 |
| G23 | `truncate*` 用 `String.length`（UTF-16 码元），不是显示格宽度 → CJK/宽字符截断算错，行宽断言也测不到 | `renderer/src/ui/text.ts:11-31` | 显示宽度度量（`string-width`），截断按格 |
| G24 | 会话切换是死路：mount 只跑一次（`src/index.ts:3226-3230`），订阅绑在 mount 时的 agent（`:3836-3837`、`:3748-3751`），`session-snapshot` 从不重发 → 切会话后转写/标题/状态是旧会话，新事件被过滤 | `src/host/renderer-mount.ts:223-264`、`src/index.ts:3836` | 切换后重发 snapshot、重订阅 |
| G25 | 宿主所有 notice 在渲染器路径不可见：`appendNotice` 只喂从未启动的 pi-tui notice 槽（`src/index.ts:893-907`、`:4222-4226`；渲染器路径在 `:3869` return）。命令失败、供应商保存/发现结果、模式/权限错误、`/export` 不可用、渲染器崩溃报告全部丢 | `src/index.ts:893-907`、`src/host/renderer-mount.ts:3833` | notice 走 IPC 进 toast |
| G26 | status 行选后不刷新：provider/model/effort/permission/preset 只在 `session-snapshot` 里设（`app.tsx:847-857`），选择发上游但无重发 → 状态行显示旧路由；permission/preset 在渲染器里没有选择器 | `app.tsx:847-857`、`renderer-mount.ts:274-293` | 选择后重发 catalog/snapshot |
| G27 | 死 kind：`provider-catalog`、`permission-presets`、`agent-presets` 声明了但从不发也不处理；`wechat-op` 渲染器从不发；宿主 `bye()` 无调用点；`send-message` 的 `interject` 标记被 mount 吃掉（`renderer-mount.ts:269-273`）；`boot-notice`/`log` 的 level 被忽略，全塞进 5 行警告色列表（`app.tsx:881-890`） | `src/ipc/kinds.ts:440-468`、`renderer/src/protocol/kinds.ts:27-56` | 补齐或删除，门禁覆盖「已声明且已用」 |
| G28 | 能力表虚报：`RENDERER_CAPABILITIES` 声明 `scrollbar` 与 `transcript`，但主 shell 无 scrollbox、无滚动键（`pageup/pagedown/home/end` 只归 dialog） | `renderer/src/protocol/kinds.ts:174`、`keymap.ts:62-76` | 能力随真实功能声明 |
| G29 | 表单保真度：`secret` 字段明文渲染（无掩码）；无多行字段；所有 input 固定 40 格（`dialog-fields.tsx:139-146`）、prompt 固定 54 格（`dialog-forms.tsx:73-90`）；对话框 `paddingTop=h/4` 无底部边距，短终端面板可跑到屏下；`form-spec` 回答让发起的 `dialog-request` promise 永远挂起（`app.tsx:105-108`） | `ui/dialog-fields.tsx:123-147`、`ui/dialog.tsx:149` | 掩码、多行、宽度随面板、底部边距、promise 结算 |
| G30 | 无尺寸/resize 契约：协议无 width/height，宿主无 SIGWINCH 处理，主 shell 从不读终端尺寸（只有 dialog 读 `useTerminalDimensions`）→ shell 无法实现断点，宿主无法影响布局 | `src/ipc/kinds.ts`（无 size kind）、`app.tsx`（无 `useTerminalDimensions`） | shell 读尺寸 + 断点表；协议加 `terminal-size` |
| G31 | `streaming` 标记宿主已设（`src/index.ts:3851`）但 shell 忽略；`TranscriptEvent.reasoning` 字段（`src/ipc/kinds.ts:26`）`transcript-events.ts` 从不填充；`showReasoning` 是设置页的一行，不驱动任何渲染 | `src/host/transcript-events.ts:34-91`、`app.tsx:859-880` | 填充 + 渲染 reasoning 块与流式指示 |
| G32 | 颜色 token 缺：shell 请求 `text.formfield.base`（`app.tsx:1011`），token 数据只有 `text.formfield.$focused/$selected`（`src/token-theme-data.ts:63-64`）→ composer 文字色回落到硬编码 `#cdd6f4` | `app.tsx:1011`、`src/token-theme-data.ts:63-64` | 补 token 路径 |

## 5. 下一步开发计划

原则：**先修几何，再补区域，最后补数据与键位**；每阶段以「真实画面帧 + 几何断言」验收，不以
子串断言验收。渲染器仍是 opt-in（`DSH_RENDERER=1` / `dpsk --renderer`），pi-tui 保持默认，直到
布局保真度对齐后才谈「设为默认」与基座退出（沿用 0.5.0 的 S8 决定）。

### P0 几何地基（修「混乱」本身）

任务：
1. 根盒去边框，改 `background.base`；区域靠 `background.raised.base` + padding 分离。
2. `Row` 去掉 `width={88}`/`width={10}`/`width={78}`，改 `flexGrow` + `paddingLeft`；composer
   `input` 去掉 `width="70%"`，改 `width="100%"` + `flexGrow`。
3. transcript 换 `scrollbox`（`flexGrow=1 minHeight=0`，`stickyStart="bottom"`，
   `scrollbarOptions`），加 jump-to-latest 行（`height=1`，`justifyContent=flex-end`）。
4. prompt 栈钉底：`flexShrink=0` 容器包住 composer + 生成提示 + footer；把 subagents、微信 QR、
   notices、slash/`@` 补全移出 transcript 与 composer 之间的流（subagents → composer drawer；
   notices → toast；补全 → 绝对定位 popup；QR → 独占块，随 prompt 栈一起 flexShrink=0）。
5. sessions 轨道加截断（`truncateMiddle`，`renderer/src/ui/text.ts` 已有）与固定行宽。
6. 每个区域显式 `overflow="hidden"`（G21）：溢出内容不再画在兄弟区域上，消除重影/叠字。
7. 主 shell 读 `useTerminalDimensions()`（G30）：断点表（§3.5）在 shell 内生效，不再只有
   dialog 响应尺寸。协议加 `terminal-size` kind（宿主把 TTY 尺寸变化告知渲染器），
   `renderer/src/ui/layout.ts` 集中常量与 clamp 函数。
8. 对话框遮罩移到无边框根下（G22）：遮罩与面板不再偏移 1 格；嵌套对话框共享一层变暗；
   面板内宽度按 `min(size, W-2)` 的实际 clamp 值算，不按名义 60/88/116；加底部边距。
9. `truncate*` 改显示格宽度度量（G23）：CJK/宽字符截断算对，行宽断言才有意义。

涉及：`renderer/src/app.tsx`（渲染树）、`renderer/src/ui/`（新增 `toast.tsx`、`popup.tsx`）。

验收：
- 新几何断言套件（`renderer/src/layout.test.tsx`）在 40/60/80/120 列、24/30 行下断言：区域
  顺序、composer 行位置在条件块出现时**不变**、transcript 区高度 = 剩余高度、内容右缘 = 内宽、
  无行超出终端宽、粘底后最新行在屏。
- `tmp/layout-capture.ts` 两帧（80x24、120x30）人工核对，画面贴进本文。

### P0.5 状态面（布局之外的功能断链，与 P0 并行）

任务：
1. 会话切换重连（G24）：`session-op switch` 后宿主重发 `session-snapshot`、重订阅
   `session-frame`/`turn-state`（订阅不再绑 mount 时的 agent）。
2. notice 走 IPC（G25）：`appendNotice` 在渲染器路径接 toast（P2 的 toast 落地前先接
   `boot-notice`/`log` 的 level，`level` 决定颜色与位置，不再压成 5 行警告色）。
3. 选择后刷新（G26）：`set-selection` 之后宿主重发 catalog 与状态行数据。
4. 死 kind 处置（G27）：`provider-catalog`/`permission-presets`/`agent-presets` 补齐发送与
   处理（permission/preset 选择器落地），或从 kind 表删除；`wechat-op` 接上 `/wechat-*`
   命令；宿主 `bye()` 在退出路径调用；`send-message` 的 `interject` 标记不再被 mount 吃掉。
5. 能力表如实声明（G28）：`RENDERER_CAPABILITIES` 的 `scrollbar` 随 P0 的 scrollbox 才声明。
6. `streaming` 与 `reasoning` 填充并渲染（G31）：`transcript-events.ts` 填
   `TranscriptEvent.reasoning`，shell 用 `streaming` 画流式指示；`showReasoning` 设置行开始
   真正驱动渲染。
7. 表单保真（G29）：`secret` 掩码、多行字段、input 宽度随面板、`form-spec` 回答结算发起的
   `dialog-request` promise。
8. 补 `text.formfield.base` token 路径（G32）。

涉及：`src/index.ts`、`src/host/renderer-mount.ts`、`src/ipc/kinds.ts`、
`renderer/src/protocol/kinds.ts`、`renderer/src/ui/dialog-fields.tsx`、
`scripts/verify-ipc-protocol.ts`。

验收：切换会话后转写/标题/状态是新会话的；命令失败与供应商保存在屏上可见；选择模型后状态行
刷新；`verify:ipc-protocol` 断言每个 kind 都有发送点与处理点（门禁升级）；`secret` 字段输入时
不回显明文。

### P1 prompt 与转写呈现

任务：
1. Prompt 组件照 §3.3 重做：左边界 `┃` + `╹`、padding 1/2（`<44` 时 1）、`textarea`
   `minHeight=1` `maxHeight=max(6, floor(H/3))`、metadata 行、shadow lip（`▀`）、footer 行。
2. 转写行照 §3.4 重做：user 左边界卡、assistant markdown（OpenTUI `Markdown` renderable，
   `paddingLeft=3`）、inline 工具行（icon `width=2` + 标签 + spinner/denied/failed）、block 工具
   卡（edit/apply-patch + diff）、assistant footer。
3. 新增 IPC kind：`usage`（input/output/cacheRead/cacheWrite/cost/contextWindow/contextPct）、
   `git-branch`、`mcp-status`、`todos`；宿主从 `tokenTotals`（`src/index.ts:1347-1351`）、
   `requestContext()`（`src/index.ts:1210`、`1825`）、`gitBranch`（`src/index.ts:752`）推送，
   走 `RendererMountDeps` 新增 dep。
4. prompt footer 填 context %、cost、cwd:branch、subagent/shell 计数、键位提示，按 §3.5 的
   宽度丢弃规则。

涉及：`renderer/src/app.tsx`、新增 `renderer/src/ui/prompt.tsx`、`renderer/src/ui/transcript.tsx`、
`renderer/src/protocol/kinds.ts`、`src/ipc/kinds.ts`、`src/host/renderer-mount.ts`、
`src/index.ts`、`scripts/verify-ipc-protocol.ts`（kind 表门禁）。

验收：120 列与 80 列帧里 prompt 有左边界与 footer；转写里 user 是左边界卡、assistant 是
markdown、read/bash 是 inline 行、edit 是带 diff 的卡；footer 显示 `12.3k (41%) · $0.42`；
`<44` 列 footer 丢细节；`verify:ipc-protocol` 覆盖新 kind。

### P2 区域与键位

任务：
1. 竖 tab 栏（会话列表，宽 42，`<12` compact）+ 横 tab strip（1 行），按 §3.5 的 dock 条件。
2. 右 sidebar（宽 42，`>120` dock，`≤120` overlay）：title、context block、MCP block、
   cwd:branch footer。
3. 右 pane（terminal / plugin panel）+ `PaneResizeHandle` + panel `fullscreen`（`<108`）仲裁。
4. toast overlay（top1 right2，maxWidth min(60,W-6)，左/右 `┃` 变体色）。
5. spinner（40ms 帧，block frames）用于运行中与工具 pending。
6. 键位补齐 §3.6：`leader b`、`leader left/right`、`leader t`（terminal，theme 移到 `leader y`
   或 palette）、`ctrl+tab`、`escape` 中断（走宿主 interrupt）、`ctrl+b` 后台化、`shift+tab`
   agent 循环、`f2` model 循环、prompt `up/down` 历史（与 dialog 焦点分层）。
7. keymap 从状态机升级为分层（global / session / composer / autocomplete / modal），照
   `context/keymap.tsx` 的 layer 语义。

涉及：新增 `renderer/src/ui/session-tabs.tsx`、`renderer/src/ui/sidebar.tsx`、
`renderer/src/ui/pane-resize.tsx`、`renderer/src/ui/spinner.tsx`、`renderer/src/ui/toast.tsx`；
`renderer/src/keymap/keymap.ts`；`renderer/src/protocol/kinds.ts`（pane/tab/sidebar 状态）。

验收：120 列画面出现左竖栏 + 右 sidebar；80 列 sidebar 变 overlay；`leader b` 开关 sidebar；
`escape` 中断在屏上有 spinner；toast 出现在右上且不推动布局；键位表测试逐条断言 chord → action。

### P3 composer 抽屉与补全 popup

任务：
1. Composer drawer（左边界 `┃`、padding 1/2/1/1、title 行 + `esc`、tab 左/右切换、footer 提示行）
   承载 subagents / shell 历史 / queued 插话。
2. `@` 与 `/` 补全改绝对定位 popup（挂在 prompt 锚点上方，`width=prompt 宽`，
   `height=min(10, count, anchor.y)`，`SplitBorder`，选中行 bg，kind 标签右对齐，空态文案）。
3. popup 键位：`up/ctrl+p`、`down/ctrl+n`、`return`、`tab`、`escape`。

验收：输入 `/pe` 时 popup 在 prompt 上方且不改变 prompt 高度；`@tmp/check-fr` 时 popup 列出
路径；`tab` 接受首个匹配；popup 出现时 composer 行位置不变。

### P4 断点表与几何回归

任务：
1. 实现 §3.5 全断点表，集中成 `renderer/src/ui/layout.ts`（照上游常量与 clamp 函数）。
2. 几何断言套件覆盖每个断点：40/44/60/64/80/108/120 列 × 12/14/16/22/24/30 行。
3. `tmp/check-frame.ts` 扩展为断言区域顺序与行位置，不只断言子串。

验收：断点矩阵全绿；`npm run check` 与 `test:renderer` 全绿；真实产物两帧人工核对通过。

### P5 渲染器设为默认与基座退出

前置：P0–P4 全绿 + 用户实机 TTY 验收（CJK、真实帧率与滚动、微信扫码/白名单/推送、供应商表单
写回、逐模型嵌套编辑器）。

任务：删 `patches/`、`verify:patch-surface` 与 snapshot、pi-tui 装配路径（`src/index.ts` 的
pi-tui 分支）、`DSH_RENDERER` opt-in 开关（渲染器成为默认）；`dpsk` 启动器与文档随之更新。

验收：`dpsk` 直接进入渲染器路径；`npm run check` 全绿；7 平台产物重生成；实机冒烟。

### 前置工作（P0 之前）

- **vendored 布局参考**：把上游布局文件取进 `vendor/opencode/`（`app.tsx`、
  `component/session-frame.tsx`、`component/session-tabs.tsx`、`component/prompt/index.tsx`、
  `component/prompt/autocomplete.tsx`、`component/prompt/metadata.tsx`、`component/spinner.tsx`、
  `component/startup-loading.tsx`、`component/reconnecting.tsx`、`component/migration-overlay.tsx`、
  `routes/session/index.tsx`、`routes/session/composer/index.tsx`、`routes/session/sidebar.tsx`、
  `routes/home.tsx`、`ui/layout.ts`、`ui/border.ts`、`ui/toast.tsx`、`feature-plugins/prompt/footer.tsx`、
  `feature-plugins/sidebar/context.tsx`、`feature-plugins/sidebar/footer.tsx`、
  `feature-plugins/home/footer.tsx`、`config/keybind.ts`），逐文件 SHA-256 登记进 `NOTICE.md`，
  `scripts/verify-license.ts` 覆盖。派生文件加 SPDX 头（沿用 0.5.0 的 D2 决定与署名模板）。
- **logo 重画**：`routes/home.tsx` 的 logo 区域需要 dsh 自己的标识图形，不复制 opencode 标识
  （沿用 0.5.0 §3.1 的「重画，不复制」）。

## 6. 需要用户确认的决定点

1. **P0 是否先只修几何**（composer 钉底 + scrollbox + 去固定宽度），让界面立刻不混乱，再逐区
   域补齐？还是 P0+P1 合并成一次大改？
2. **右 pane 的 terminal/plugin 是否要做**：dsh 无 git snapshot、无 plugin panel 宿主，右 pane
   可先只做 sidebar（G6），G7 推迟。这决定 P2 的规模。
3. **`leader t` 语义冲突**：现在 `ctrl+x t` 是 theme，opencode 是 terminal pane。theme 移到
   palette 还是换 chord？
4. **`/undo` `/redo`**：dsh 无 git snapshot 层，维持不做（0.5.0 已确认）。
5. **渲染器设为默认的时间点**：P5 前是否先让用户实机验收 P0 画面。

## 7. 验证方法（固定）

- 每阶段跑 `tmp/layout-capture.ts`（真实编译产物）与 `renderer/layout-120.tsx`（testRender），
  把两帧 ASCII 画面贴进阶段记录；画面是验收物，不是子串。
- 几何断言套件（P0 起建）在 40/60/80/120 列断言区域顺序与行位置；`narrow.test.tsx` 的行宽断言
  保留。
- 真实 TTY 验收由用户做（CJK、帧率、滚动、鼠标、微信桥），沿用 0.5.0 的「实机验收是渲染器设为
  默认的前置」约定。
