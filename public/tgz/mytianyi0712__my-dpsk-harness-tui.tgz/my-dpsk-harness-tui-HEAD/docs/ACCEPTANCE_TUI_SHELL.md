# TUI 外壳实机验收清单（0.5.0）

这份清单只列**必须由人在真实终端里确认**的项目，以及每项对应的自动化证据。自动门禁全绿不代表
验收通过：布局观感、输入方法与 CJK 宽度只能真机判断。

前置：`dpsk check` 应报告「全局环境与 tui profile 一致」且渲染器哈希与清单一致；然后直接 `dpsk`。

## 1. 底部信息分两处

自动证据：`renderer/src/ui/status-bar.test.ts`（纯函数）、`renderer/src/layout.test.tsx` 与
`renderer/src/app.test.tsx`（char frame，含 40/44/60/80/120/168 列矩阵）、`tmp/check-status.ts`
（编译产物，120/50/30 列）。

真机确认：

- [ ] 终端**最后一行**恒为指标行，没有第三行；Home 与 Session 都是如此。
- [ ] 工作目录行跟着输入框走：Session 里紧贴输入框下沿，Home 里跟着居中的 prompt 一起浮动（不是钉在屏幕最底下）；在窄窗口（把终端拖到 ~40–60 列）时**先消失的是右侧提示**，目录再退化为末级目录，极窄时变成 `...` + 尾部字符。
- [ ] 提示行右侧平时是 `shift+tab agents · ctrl+p commands`（按键亮、说明浅）；跑一轮对话时换成 spinner + `esc interrupt`（整段警告色），turn 结束后变回来。
- [ ] 指标行居中，形如 `T12 S4 · 72.0 tok/s | 23.6k tokens · cache 63% | 8.4k/64k (13%)`；本轮没跑过时不显示 TPS/轮次。
- [ ] 输入框左侧竖条是**一条连续的强调色**：从面板顶行到 `╹` 收口不断、不变色，`╹` 与竖条同色，下面的 `▀` 阴影与输入框底色一致（不是更亮的灰）。
- [ ] 界面语言：未配置 `tui.locale` 时按系统语言推断；zh 下命令面板（`命令面板`/`搜索`/`移动`/`运行`）、分节标题、斜杠菜单描述（`/models 选择 provider / model / 推理强度` 这种）与底栏提示全部为中文。
- [ ] 斜杠命令名与 opencode 一致：`/models` `/agents` `/effort` `/sessions` `/themes` `/status` `/new` `/settings` `/skills` `/help` `/mcps`；旧名 `/model` `/mode` `/think` `/resume` `/theme` `/details` 仍作别名；`/undo` `/redo` `/copy` 等 dsh 做不到的命令不出现。
- [ ] 输入框元信息 gent auto · provider/model · effort 分色：agent 与竖条同色，provider 弱化色、model 正文色，effort 警告色且加粗。gent 显示预设的**展示名**（如 标准模式），不是 id standard —— 与回答 footer 的 agent 段一致。
- [ ] 侧栏停靠（宽终端、开侧栏）时底栏跟着输入框缩进：工作目录行左边界与输入框面板左边界对齐，指标行在**内容列**内居中（不是相对整个终端）。
- [ ] 中文路径（如 `D:/项目/源码`）不被截成半个字，宽度不溢出。
- [ ] 切换任意内置主题后，思考头（暗金）、思考正文（灰）、回答正文（亮）三者在亮色与暗色主题下都**互不相同**；折叠思考块后头部变亮一度。

## 2. 额外信息只在侧栏

自动证据：`renderer/src/layout.test.tsx`（长清单裁剪、滚轮滚动、Home 停靠、停靠时底栏随内容列缩进，含 121 列与侧栏拖到 80 格两种边界）、
`renderer/src/app.test.tsx`（WeChat 状态与二维码只在侧栏、底栏不出现）。

真机确认：

- [ ] 底栏不再出现 `⊙ N MCP`、版本号、WeChat 状态行。
- [ ] 打开侧栏（`leader b` 或命令面板）能看到自上而下恰好五段：会话标题、上下文（三行）、微信（两行状态 + 登录二维码）、MCP（每台一行 + 生命周期）、TODO（状态符号）、轨迹（默认收起）、以及 provider/model、workspace:branch、版本号。
- [ ] 点击 MCP / TODO / 轨迹 的标题行可以收起、再点可展开；默认 MCP 展开、TODO 展开、轨迹收起。
- [ ] 侧栏里不再有插件清单（`/plugins` 仍在命令面板）。
- [ ] MCP / TODO / 轨迹 超过一屏时，滚轮能滚动内容；**标题行与底部 provider/branch/version 不动**；滚动条出现在右侧预留位，不挤压文字。
- [ ] Home 上也能打开侧栏；宽终端是分栏（内容变窄），窄终端是覆盖层（overlay）。
- [ ] tabs 上方**没有**额外的会话标题行。

## 3. 会话标签

自动证据：`renderer/src/layout.test.tsx`（`active` 由 `currentSession()` 派生、首帧换高亮）。

真机确认：

- [ ] 切换会话时高亮立刻跟随，不会先亮旧标签。
- [ ] 多标签 + 长标题时当前标签仍可读；`×` 只在当前/悬停标签上出现。

## 4. 输入与补全

自动证据：`renderer/src/app.test.tsx`（Session 补全弹窗贴边）、`renderer/src/layout.test.tsx`（Home 补全弹窗贴边）。

真机确认：

- [ ] 输入 `@` 或 `/` 时补全框紧贴输入框上沿，**中间没有空白行**（Home 与 Session 都要看）。
- [ ] 运行中弹出补全框时也不压住输入行。
- [ ] 中文输入法候选框不被界面抢焦点；粘贴多行文本正常。

## 5. 会话流（回归，非本轮改动）

自动证据：`renderer/src/ui/streaming.test.tsx`、`tmp/check-stream.ts`（12 delta / 12 帧、0 丢帧、0 空帧）。

真机确认：

- [ ] 长回答逐字追加，不闪烁、不整块重绘。
- [ ] 思考块用 Markdown 渲染（标题/列表/代码），推理还在流时标题是 `Thinking` 转圈（有摘要时 `Thinking: 摘要`），
      推理结束后才变 `Thought[: 摘要 · 时长]`；没有思考的回答**不出现** `Thought` 空行。
- [ ] 思考块里的标题、强调、行内代码**不借用回答的配色**：整段思考是一个弱化的声音。
- [ ] 用户滚离底部后，新字不把视图拉回底部。

## 6. 思考/工具、选择、resume 与会话生命周期

自动证据：`renderer/src/ui/thinking.test.ts`、`text.test.ts`、`transcript.test.tsx`、`streaming.test.tsx`、
`renderer/src/app.test.tsx`、`tests/transcript-events.spec.ts`、`tests/lazy-session-persistence.spec.ts`、
`tests/session-prune.spec.ts`、`tests/session-activity.spec.ts`。

真机确认：

- [ ] `/settings` 的 `new thinking style` 打开/关闭即时切换，当前主题（包括 `opencode2`）不变；重启后保持。
- [ ] classic：思考中显示 `Thinking`，正文开始/思考结束后显示 `Thought`；点击标题可折叠，`┃` gutter 与工具卡片保持旧样。
- [ ] compact：正文前多段 reasoning + 工具只出现一个标题；计数正确，无工具时没有 `Used 0 Tools`。
- [ ] compact 预览为 5–10 行并自动尾随最新内容；`Running` → `Done` 原位更新，失败/拒绝显示 `Failed` / `Denied`，长参数以 `...` 截断。
- [ ] 正文出现后预览自动收起、标题变 `Thought`；点击展开完整 reasoning Markdown 与 classic 工具卡片，再点收起；手动展开不会被正文强制折叠。
- [ ] `show reasoning: hide` 下 compact 只显示标题，点击仍能展开完整内容。
- [ ] Windows Terminal / WezTerm 在 40×16、80×24、120×24 下，标题、CJK 参数与 `Used N Tools` 不溢出、不换行；40 列仍可读 `Running: Read`。
- [ ] 单击思考/正文不留下小方块；拖选出现主题选择色而不是 `text.base` 反白；提交、切换会话、开始新一轮后选区消失。
- [ ] resume 一个含 `- **加粗**` 列表的会话，思考与回答都不显示 `**`；实时与 resume 帧一致；跨 text block 的 `**加粗` / `文字**` 不泄漏。
- [ ] 启动 TUI 后不发送直接退出、resume 旧会话后不发送、`/new` 后不发送再切回：`$DSH_HOME/sessions` 不新增可恢复空目录。
- [ ] 发送第一条消息后恰好新增一个会话，且第一条 `user/message` 在里面；历史 4-event 空目录被清理，真实会话不被误删。
- [ ] `/sessions`、host `/resume`、today/yesterday 分组按最后交互时间排序；刚用过的旧会话回到顶部和今天；缺少 `lastActivityAt` 的旧数据不崩。


## 7. 会话选择器、OpenCode tabs、运行态 footer 与 ~ 路径

自动证据：`renderer/src/ui/session-tabs-model.test.ts`、`session-activity-label.test.ts`、`path-display.test.ts`、
`status-bar.test.ts`、`renderer/src/app.test.tsx`、`renderer/src/layout.test.tsx`、`tests/session-lifecycle.spec.ts`、
`tests/config-volatile.spec.ts`。

真机确认：

- [ ] 启动 TUI 不发送、home 直接退出、resume 后不发送：session picker 不出现未命名 ghost session；host 当前 live 空壳也不显示。
- [ ] `/sessions` 每行只有标题 + `today` / `yesterday` / `last 7 days` / 日期；没有 id、cwd、父子关系、status 或第二详情行。
- [ ] 当前 session 只有左侧圆点；搜索仍能按标题、隐藏 id 或 workspace 命中。
- [ ] `+` / `leader n` 只出现一个 `New Session` tab；重复按不叠加；输入首条消息后原位置变成真实标题，不出现第二个空 tab。
- [ ] 从 session route 关闭 Home 草稿 tab 会回到相邻真实 tab；关闭最后一个真实 tab 回 Home 且不创建空 session。
- [ ] host `session-list` 因 lastActivity 重排后，顶部 tab 手动顺序不变；拖动后顺序重启仍保留。
- [ ] active tab 有 `×`；hover inactive tab 出现 `×` 且不误触切换；中键关闭、右键菜单、`Ctrl+Shift+T` 原位重开正常。
- [ ] `Ctrl+Tab` / `Ctrl+Shift+Tab` 循环，`leader 1..9` 和 `Ctrl+1..0` 选对应 tab；running tab 显示真实状态点，无假 unread。
- [ ] `Ctrl+T` 向前循环思考强度并回绕；`Tab` 仍执行补全，`Ctrl+Shift+T` 仍重开 tab。
- [ ] 生成中：左侧 cwd 被 spinner + `esc interrupt` 替换，右侧仍显示 `shift+tab agent · ctrl+p commands`；40 列不重叠。
- [ ] Windows 下 `C:\Users\<user>\Projects\dsh` 默认显示 `~/Projects/dsh`；Linux 下 `/home/<user>/...` 同样缩写。
- [ ] `/settings` 的 `path display` 切到 `full path` 后显示完整路径，重启保持；切回 `~` 正常。
- [ ] 路径缩写只影响界面：shell、terminal、附件、@ 补全、复制与导出仍使用真实绝对路径。
- [ ] 同一 turn 内中间 assistant 正文之后，如果继续出现 reasoning/tools，会显示新的 compact header，而不是回落 classic Thought 行。
- [ ] 用户卡片与下一条 thinking / reasoning / 正文之间恰好一行空白，classic 与 compact 一致，普通正文与工具行没有双倍间距。
- [ ] 向上滚动后 Jump to latest / 跳到最新 出现在输入框上方右侧，可直接点击回到最新；按钮出现前后输入框不移动，补全面板打开时隐藏。


## 8. 守护进程、退出与开机启动

- [ ] `dpsk daemon status` 初始显示 not running；`dpsk daemon start` 后显示 pid；再次 `dpsk` 只 attach，不新起 core。
- [ ] TUI 中 `/exit`、空输入框 `Ctrl+C`、leader `q` 和直接关闭终端后，`dpsk daemon status` 仍显示 running。
- [ ] 重新 `dpsk` 能重新握手并重放当前会话 snapshot；正在运行的任务没有中断。
- [ ] 有 running 会话时退出弹窗出现 detach / 打开全部进行中会话 / 取消；选择打开后所有 running 标签可见。
- [ ] `/shutdown` 与命令面板全量退出先确认，确认后 core 停止，后台任务结束。
- [ ] 设置页开机启动开关显示真实 OS 状态；开启后 Windows HKCU Run / macOS LaunchAgent / Linux XDG 文件存在，关闭后移除；失败时不显示为已开启。

## 失败时怎么报告

给出：终端名与尺寸（如 `Windows Terminal 168x24`）、当时的操作、以及截图。如果方便，附上
`~/.dsh/logs/tui-<pid>.log` 的相关片段。我会先按现象补一条失败测试，再改实现，避免同样的问题再次出现。
