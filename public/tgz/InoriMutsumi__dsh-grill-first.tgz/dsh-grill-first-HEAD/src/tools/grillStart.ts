/**
 * `grill_start` 工具（R1/R2/R4/R6）：开工前判定任务是否已经说清楚。
 *
 * - clear：放行（门禁置 open），模型直接开工；
 * - needs-clarification：门禁置 closed，并返回记忆摘要、追问方向与轮次上限。
 */
import type { GrillConfig, MemoryScope } from '../config.js'
import type { GateRegistry } from '../gate/preExecute.js'
import { judgeTask } from '../judge/heuristics.js'
import { loadMemory, summarize } from '../memory/store.js'
import type { GrillAgent, ToolDefinition, ToolRunContext } from '../types.js'
import { PLUGIN_VERSION } from '../version.js'
import type { SessionRegistry } from './sessions.js'

/** 工具依赖（由 index.ts 装配注入）。 */
export interface GrillStartDeps {
  config: () => GrillConfig
  gates: GateRegistry
  sessions: SessionRegistry
  /** 解析当前会话的工作区根目录（项目层记忆落点）。 */
  workspaceRoot: (agent?: GrillAgent) => string
  /** 项目层记忆落在工作区还是插件家目录（memoryScope 配置）。 */
  memoryScope?: () => MemoryScope
  logger?: { warn(message: string): void }
}

/** grill_start 的返回体。 */
export interface GrillStartResult {
  verdict: 'clear' | 'needs-clarification'
  skip: boolean
  reason: string
  score?: number
  memory_context?: string
  focus_hints?: string[]
  gate_state?: 'open' | 'closed'
  max_rounds?: number
  max_questions_per_round?: number
  intensity?: string
  mode?: string
  task_id?: string
  previous_task?: string
  hint?: string
  /** 已经追问过的轮数（达到 maxRounds 后不再追问）。 */
  rounds_used?: number
  /** 当前运行的插件版本（取自 package.json）：用于确认改动是否已随重启生效。 */
  version?: string
}

/** 把对象包成"回灌给模型的文本块"。 */
export function textOutput(schema: Record<string, unknown>): ToolDefinition['output'] {
  return {
    schema,
    render: (_args: unknown, value: unknown) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
  }
}

/** grill_start 的参数 schema。 */
const PARAMETERS: Record<string, unknown> = {
  type: 'object',
  properties: {
    task: {
      type: 'string',
      description: '任务原文或任务摘要（必填）：把用户这句话原样贴进来，不要自己改写。',
    },
    mode: {
      type: 'string',
      enum: ['new-task', 'drift-check'],
      description: 'new-task=开工前的常规判定（默认）；drift-check=任务中途用户大改目标/范围时的重新判定。',
    },
  },
  required: ['task'],
  additionalProperties: false,
}

/** grill_start 的返回 schema（宽松描述，host 只做展示与校验兜底）。 */
const OUTPUT_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: {
    verdict: { type: 'string', enum: ['clear', 'needs-clarification'] },
    skip: { type: 'boolean', description: 'true=无需提问，直接开工' },
    reason: { type: 'string' },
    score: { type: 'number', description: '需求完整度打分（0-100）' },
    memory_context: { type: 'string', description: '两层记忆的紧凑摘要，可先向用户呈现' },
    focus_hints: { type: 'array', items: { type: 'string' }, description: '建议的追问方向' },
    gate_state: { type: 'string', enum: ['open', 'closed'] },
    max_rounds: { type: 'number' },
    max_questions_per_round: { type: 'number' },
    intensity: { type: 'string' },
    mode: { type: 'string' },
    task_id: { type: 'string' },
    previous_task: { type: 'string' },
    hint: { type: 'string' },
    rounds_used: { type: 'number', description: '已经追问过的轮数' },
    version: { type: 'string', description: '运行中的插件版本；若缺失说明宿主加载的是旧版代码，需重启 DSH' },
  },
  additionalProperties: true,
}

/**
 * 创建 `grill_start` 工具定义。
 * @param deps 配置读取、门禁表、会话表、工作区根目录。
 */
export function createGrillStartTool(deps: GrillStartDeps): ToolDefinition {
  return {
    name: 'grill_start',
    description:
      '开工前的需求判定（grill-first 插件）。任何新任务开始前先调用一次，把任务原文传进来：返回 verdict=clear 就直接开工；返回 needs-clarification 就按 focus_hints 用 ask_user_question 多轮追问，问清后用 grill_confirm 请用户确认。',
    parameters: PARAMETERS,
    output: textOutput(OUTPUT_SCHEMA),
    isConcurrencySafe: () => true,
    async execute(rawArgs: unknown, exec: ToolRunContext): Promise<GrillStartResult> {
      const args = (rawArgs ?? {}) as { task?: unknown; mode?: unknown }
      const config = deps.config()
      const agentId = exec?.agent?.id ?? ''
      const task = typeof args.task === 'string' ? args.task.trim() : ''
      const mode = args.mode === 'drift-check' ? 'drift-check' : 'new-task'

      if (!config.enabled) {
        return { verdict: 'clear', skip: true, reason: 'disabled', version: PLUGIN_VERSION }
      }
      if (task === '') {
        return {
          verdict: 'needs-clarification',
          skip: false,
          reason: 'empty-task',
          focus_hints: ['task 为空：请把用户的原话或任务摘要原样传进来，再调用一次 grill_start。'],
          hint: '缺少 task 参数。',
          version: PLUGIN_VERSION,
        }
      }

      const judged = judgeTask({
        text: task,
        mode,
        bypassKeywords: config.bypassKeywords,
        intensity: config.intensity,
      })
      const previous = deps.sessions.get(agentId)

      if (judged.verdict === 'clear') {
        deps.sessions.end(agentId)
        deps.gates.open(agentId)
        return {
          verdict: 'clear',
          skip: true,
          reason: judged.reason,
          score: judged.score,
          gate_state: 'open',
          mode,
          version: PLUGIN_VERSION,
        }
      }

      const startedAt = Date.now()
      // maxRounds 兜底：问够轮数就不再问，直接按当前理解开工（0.1.4 修：以前这个配置项根本没生效）。
      const roundsUsed = previous?.rounds ?? 0
      if (roundsUsed >= config.maxRounds) {
        deps.sessions.end(agentId)
        deps.gates.open(agentId)
        return {
          verdict: 'clear',
          skip: true,
          reason: 'max-rounds-reached',
          score: judged.score,
          gate_state: 'open',
          mode,
          rounds_used: roundsUsed,
          hint: `已经追问 ${roundsUsed} 轮（上限 ${config.maxRounds}），按当前理解直接开工；有歧义就先做最小可验证版本。`,
          version: PLUGIN_VERSION,
        }
      }
      deps.sessions.start({ agentId, task, mode, startedAt, rounds: roundsUsed })
      deps.gates.close(agentId)

      let memoryContext = ''
      if (config.memoryEnabled) {
        try {
          memoryContext = summarize(await loadMemory(deps.workspaceRoot(exec?.agent), (deps.memoryScope?.() ?? 'project')))
        } catch (error) {
          deps.logger?.warn(`[grill-first] 读取记忆失败：${error instanceof Error ? error.message : String(error)}`)
          memoryContext = ''
        }
      }

      return {
        verdict: 'needs-clarification',
        skip: false,
        reason: judged.reason,
        score: judged.score,
        memory_context: memoryContext,
        focus_hints: judged.focus_hints,
        gate_state: 'closed',
        max_rounds: config.maxRounds,
        max_questions_per_round: config.maxQuestionsPerRound,
        intensity: config.intensity,
        mode,
        task_id: `${agentId}:${startedAt}`,
        rounds_used: roundsUsed,
        version: PLUGIN_VERSION,
        ...(previous?.task ? { previous_task: previous.task } : {}),
      }
    },
  }
}
