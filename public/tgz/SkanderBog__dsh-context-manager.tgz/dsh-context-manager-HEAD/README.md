# DSH Context Manager

A standalone plugin for DeepSeek Harness 0.2.0-rc.2 or later. Adds a **Context** button beside the conversation title, plus `/context-manager` in the command menu. No desktop source changes, extra background server, or model tool is required.

## Use

1. Open **Context** in an existing conversation.
2. Inspect estimated context usage and its composition: instructions, user messages, answers, stored reasoning, tool/file outputs, tool definitions, and attachment references.
3. Choose **Keep**, **Summarize**, or **Omit** for older history groups. The latest exchange, system/developer instructions, Harness instruction/catalog/runtime snapshots, and incomplete tool exchanges are protected.
4. Choose whether summaries should summarize, retain the original text of, or omit recorded tool/file outputs.
5. Optionally open **Add notes to preserve** on a selected group. Record a decision, rejected approach and reason, risk, or next step.
6. Generate a preview. Review the exact replacement text, notes, generation usage, and estimated local token change, check the review box, and apply.

## Local context, reported usage, and ACP

The panel labels **local context** separately from **the last reported model request**. The first uses Harness's context meter; it is an estimate of the retained session surface. The second reports provider input and output counts from the latest recent assistant event with usable usage data. Input includes Harness's disjoint uncached, cache-read, and cache-write buckets. Reasoning tokens are already part of output and are not added again. A previous request does not measure the next request, especially after a route or context change. Missing usage is shown as unavailable, never as zero.

If the current agent can see an `acp_status` tool, **Read ACP status** asks that tool for its report using the current agent/session and Harness's ordinary tool execution and permission pipeline. It makes no model request and runs only when clicked. The report is displayed as text without parsing it into an invented token count. Refreshing the panel clears it; refresh the status after further work. Errors, restricted tool modes, cancellation, and an unavailable engine are explicit. No proxy addresses, credentials, or other sessions are discovered. The request has a cooperative ten-second timeout.

This supports the tool boundary used by `ranxianglei/billion-context` and ACP implementations, without a required dependency on either. In billion-context's native DSH mode, the local history can be much larger than the proxy's effective model input. The local estimate and ACP report therefore remain separate. The adapter has been tested with Harness's real tool runtime and a controlled ACP tool; a live third-party engine and provider have not been certified by these tests.

Preview generation reports the number of summary calls and their provider-reported input/output totals independently of context savings. Partial reporting is labelled. Omission-only previews report zero model calls. These are token counts, not currency estimates or a complete billing ledger; discarded/failed previews and other plugins' calls are not reconstructed into a session total.

## Compression history and originals

**Load compression history** reads standard Harness `compaction/summary` records. Each shows its recorded summary route, command/engine attribution when available, usage, checkpoint text, and whether the replacement is active, superseded, or was not applied. Attribution is left unknown when the log does not establish it.

**View originals** reads the record's exact source event IDs from the same session log, including noncontiguous ranges and older checkpoints. This is a read-only, human-facing view; it neither restores messages nor sends them to a model. Reasoning and raw summarizer output are excluded. Image pixels are not displayed. Truncation and unavailable source events are marked explicitly. The view continues to work after reloading a saved session.

History pages search at most 1,000 log events for at most ten records; command attribution uses a bounded lookback for each record. Originals show five messages per page with at most 8,000 visible characters each. Last-request accounting searches at most 10,000 recent events. These bounds keep inspection responsive on long sessions. **Older compression records** continues through pages even when a page has no checkpoints; **Newer compression records** returns through visited pages. Refresh starts again at the newest records. Proxy-only compression and IoT's separate originals archive are outside this log view.

## Reviewed decision notes

Notes are optional user-authored background data, with a category, source history event number, and source session ID. They are appended verbatim as a separate block of the reviewed checkpoint, bypassing generative rewriting. Later **Context Manager** summaries preserve valid note blocks and their provenance, including after a session reload. Ordinary user/assistant messages quoting the note format are not promoted to persistent notes. Notes are user-reviewed statements, not automatically verified facts.

Changing a note invalidates the current preview. Each note is limited to 2,000 characters; a summary range can carry at most 32 notes and 16,000 note characters. Excess is rejected before model calls, without silently dropping notes. A range whose notes alone exceed its context budget is also rejected before generating a summary. Keep retains notes; Omit deliberately removes them from active context. Other compaction engines can summarize or remove these blocks, so this is not a permanent pin.

IoT's compact thinking remains native reasoning and is excluded from summary input. Groups containing reasoning are labelled. Record decisions you want to preserve in the explicit note fields; the plugin does not extract or rewrite native reasoning or provider signatures.

## Preview lifecycle

The footer shows the approximate token count of selected groups before replacement, and distinguishes paid summary requests from omission-only previews that do not call the model. When a preview is ready, focus moves to its review checkbox. Generate preview stays disabled while that preview is available, avoiding duplicate summary requests; use **Discard preview** or change the selection to prepare another. Expired previews are removed automatically. A cancelled request cannot restore its preview if a response arrives late.

Summary requests start with the conversation's most recently routed model and reasoning effort and may incur normal model usage. Effort values are forwarded unchanged; when none was recorded, the provider default applies. The summary output limit remains 2,048 tokens. A host plugin can reroute requests marked `purpose: 'compaction'` to a dedicated summarizer; it must also clear or translate any effort unsupported by its replacement model. Changing an unsent composer selection alone does not set the summary model. An omission-only preview does not call the model. A preview makes no change to active context. It expires after ten minutes, a new preview, plugin reload, or a change to the conversation. Apply is permitted only while the agent is idle. A preview that expires or is discarded while the initial save is pending is rejected before any history changes.

**Keep applies to this operation. It is not a permanent pin against Harness's automatic compaction.** Existing automatic compaction is left in place.

## Why balanced history groups?

Model adapters can require reasoning signatures and complete tool-call/result pairs when replaying previous assistant messages. Removing only reasoning from those native messages can invalidate the conversation. This plugin keeps selected exchanges intact or replaces entire balanced ranges with ordinary text checkpoints. It never edits the reasoning or provider metadata of retained messages.

Summary input is a fresh, tool-free text transcript. It excludes reasoning, labels document content as data, and asks the model to preserve goals, decisions, constraints, verified results, paths, and unresolved work. As with any model summary, details may be lost or misrepresented: review the preview before applying.

A summary is accepted only after an explicit successful stream finish. Interrupted or truncated responses cannot become previews. Model failures show the provider's error code and message so account access, unsupported models, and output limits can be diagnosed; they leave active history unchanged and are not automatically retried.

## Files, PDFs, images, and original history

- Tool output includes text returned by file readers, PDF plugins, terminal commands, and other tools. The output option applies to all recorded tool output; it does not infer which text came from a PDF.
- “Keep original text” retains the recorded output text inside the checkpoint. It does not reread the file or retain image pixels.
- Attached images are not visually summarized. Keep the containing group to retain the original attachment.
- Files on disk are never changed or deleted by this plugin.
- Original messages remain in Harness's append-only log and chat transcript. Compaction changes the model's active context, not the original transcript. There is no one-click undo in this version.
- Checkpoints use standard Harness events and continue to work after the plugin is uninstalled.

The context total uses Harness's token meter. Category estimates use its fixed text heuristic and do not necessarily sum to the total. CJK text, tool schemas, image pricing, provider accounting, and framing can differ. The header percentage follows Harness's existing live context projection; it is absent before the model reports enough information. The panel still shows estimates when the context limit is unavailable.

## Install a packaged release

Download the archive from [v0.2.1](https://github.com/SkanderBog/dsh-context-manager/releases/tag/v0.2.1).

```sh
dsh plugin --profile tauri add /absolute/path/dsh-context-manager-0.2.1.tgz
```

Use your actual Harness profile name. The community Linux desktop uses `tauri` on the tested installation. Other Harness desktop distributions may use `desktop`; quit that desktop before changing its reserved profile. Restart Harness after updating the plugin: reloading the frontend or toggling a component can leave the previously imported host module cached.

Some community desktop builds incorrectly remove local `.tgz` installs during startup, treating the archive as a missing directory. On those builds, keep this project in a permanent folder, run `npm ci` and `npm run build` there, then install the folder with `dsh plugin --profile tauri add /absolute/path/dsh-context-manager`. Keep the folder while the plugin is installed. This workaround requires no desktop source changes.

This targets **DeepSeek Harness's plugin runtime**, not the separate DeepSeek consumer chat app. The host and browser APIs are standard Harness APIs. The tested host is Harness **0.2.0-rc.2** inside the community Linux desktop; another official desktop build must supply the same APIs. No claim of native macOS or Windows desktop testing is made.

## Development and validation

Requires Node.js 22.19+ and the matching Harness packages. The plugin has no additional production dependency beyond host-supplied peer packages. Browser React is supplied by Harness. The host entry is bundled into one small module so plugin updates reload its helpers together.

```sh
npm ci
npm run check
npm run test:package
npm pack
```

Tests use Harness's real Session, token meter, compaction invariant companion, AgentLoop, command registry, and JSONL persistence with synthetic history and a controlled model. They cover retained reasoning, balanced tool pairs, selective ranges, read-only preview, cancellation, stale plans, save failures, and replay without the plugin. The package check validates the archive's exact public file list and reruns the host and browser suites against its extracted entries. They do not measure the quality of a real model's summary.

`node scripts/check-models.mjs RUNTIME_ROOT [PLUGIN_ENTRY]` checks a separately installed Harness runtime with its actual DeepSeek Messages adapter and LLM service. A deterministic in-memory HTTP response verifies an arbitrary future model ID, Off/Low/High/Max/default reasoning serialization, the compaction marker, parsed usage, provider errors, and unchanged history. It makes no network or paid model request and does not certify live account access or summary quality.

Control commands use Harness's existing authenticated command route. Their records stay outside model context. While installed, the plugin hides inspection/preview payloads from ordinary chat cards and displays a short successful-compaction record. Original control records remain in the session log.

## Failure handling

If Rewind or another plugin replaces the active history or changes its request route while a summary is streaming, the preview cancels the obsolete model request. It ignores unrelated sessions and non-context events. The fingerprint is still checked before publishing and applying a preview. Multiple views of the same session keep separate registrations, so closing one view does not disable the remaining view's Context command.

Apply checks persistence before changing context and flushes again afterward. A final disk error is reported as **changed in memory, saving failed**. A multi-range append failure reports how many ranges were applied. The preview is consumed once committing starts so an uncertain operation is never automatically retried. Refresh and inspect the current session after such an error.

## Related plugins and improvement directions

Source review on 2026-10-02 identified useful complementary approaches:

- [dsh-auxiliary](https://github.com/dsh-plugins/dsh-auxiliary/blob/main/src/compact-router.ts) routes `purpose: 'compaction'` requests to a separate model. This plugin already marks summary calls that way; its automated tests check the marker and original route. Live interoperability with that router has not been tested.
- [Context Compression Selector](https://github.com/WilliamShi666/dsh-context-compression-selector) offers automatic tool-output reduction and model-specific token accounting. Its explicit distinction between tokenizer counts, estimates, and unavailable counts is a useful direction for improving this panel's approximate breakdown. No tokenizer or reducer from that project is bundled here.
- [dsh-context-management](https://github.com/overact/dsh-context-management) provides history recall and session notes alongside automatic compaction. Read-only retrieval of original messages would be a useful future addition here; retaining the log does not currently give the model a recall tool.

These three projects have not been tested for live interoperability. This plugin remains a manual, reviewed compaction interface. Automatic policy, precise next-request accounting, permanent pins, model-facing history recall tools, and undo remain future work. Human-facing original-message inspection and explicit reviewed notes are available as described above.

## Installed-plugin compatibility check

The 2026-10-08 check used the real Harness `0.2.0-rc.2` services with Rewind `0.15.0`, Better Sidebar `0.24.1`, DSH Market `1.66.6`, and the companion PDF Reader checkout. It exercised stale-preview rejection after rewind, cancelling a streaming summary on rewind, durable compaction, PDF text/image delivery and independent plugin disposal. Market coverage is its route registration and read-only capabilities endpoint; package installation/update operations and the third-party browser interfaces are not exercised. See [VALIDATION.md](VALIDATION.md) for the desktop-version boundary.

To repeat against explicit local installations, with Poppler available:

```sh
npm run test:installed -- /absolute/runtime/root /absolute/profile/root /absolute/pdf-reader/checkout
```

The profile must already contain Rewind, Better Sidebar and DSH Market. The script reads their packages and uses Harness's own module-resolution service, then creates scratch sessions, snapshots, attachments and market storage. It does not boot the live profile or read its conversations. Model responses, settings UI, loader inventory and web-runtime metadata are controlled fixtures; session, command, tool, persistence, HTTP routing and plugin code are real. A temporary loopback server is closed on completion. No paid model request or package-manager mutation is made.

### Compatibility and resource checks

The November 2 API checks include current Harness `0.2.1-rc.5`, pinned by community Desktop `v0.30.0`, and upcoming `0.2.2-alpha.2`. On the alpha host, external ACP status dispatch uses the selected batch executor and matches its returned call ID; older hosts retain the single-call API. Provider-owned tool policy remains in the execution path. An alpha profile must mount an executor as required by Harness itself.

Current model IDs and reasoning controls come from the routed request and owning adapter. The summary preserves an explicitly selected opaque effort while keeping its own 2,048-token output budget. The model probe tests the real DeepSeek request serializer and SSE parser with controlled responses; it performs no paid account calls and does not certify remote summary quality. CI runs this probe against the extracted archive on current rc.5 and alpha.2.

All selected summary ranges are checked against the transcript limit before the first model request. An oversized later range therefore leaves history unchanged without charging an earlier summary request. Omit-only ranges do not require a model or summary transcript.

The same preflight checks every omission marker and each summary's retained output text, reviewed notes, and checkpoint framing. If that required text already prevents any context savings, the entire preview is rejected before making a model request, including when the invalid range comes after another selected summary. A generated summary can still be too long; that is checked again before offering a preview.

CI tests packed host and browser artifacts on Linux, macOS and Windows. The pinned baseline is Harness `0.2.0-rc.2`; additional Linux/Node 24 lanes exercise `0.2.1-alpha.1`, `0.2.1-alpha.2`, `0.2.1-rc.2`, `0.2.1-rc.5`, and `0.2.2-alpha.2` without changing the release dependency pins. These are plugin/runtime checks, not packaged desktop GUI tests.


## Store compatibility and permissions

The manifest includes the Store-specific `dsh.compatibility` matrix as well as the host's `engines.dsh` gate. Packed API tests pass on DSH `0.2.0-rc.2`, `0.2.1-alpha.1`, `0.2.1-alpha.2`, `0.2.1-rc.2`, `0.2.1-rc.5`, and `0.2.2-alpha.2`. Linux, macOS and Windows packed-plugin tests exercise host and browser contracts, not packaged desktop GUIs. Web/desktop profiles need the stated conversation and command client modules; headless profiles expose only the command.

| Capability | Scope |
| --- | --- |
| Conversation data | Reads the selected session's active history to estimate usage and build a preview. Recorded reasoning is excluded from summary input and client excerpts. |
| Persistent changes | After the user reviews and applies a preview, writes standard compaction events through Harness session persistence. Original log entries remain. There is no undo button; Keep is not a permanent pin. |
| Network and cost | Summary generation uses the configured Harness LLM service and may send selected transcript text to its provider and incur usage charges. Omission-only previews make no model request. Explicit ACP status reads invoke the installed `acp_status` tool through Harness policy; that tool may contact its own engine. |
| Credentials | Uses the host's configured LLM service; does not request, display, or directly read provider credentials. |
| Files and processes | No direct filesystem, shell, native executable, package installation, Profile modification, or restart API in shipped runtime code. Session persistence is an indirect disk-write effect handled by Harness. |
| Dependencies | Host-supplied DSH services and React; no bundled native tools, external server, or production npm dependencies. The committed host bundle installs without `prepare` or install hooks; `prepack` is a maintainer packaging step. |

Because this plugin changes active conversation context and can invoke a model, it needs a permission-aware review even if a static scanner does not recognize those host-service effects. Listing, automatic source checks, tests, and independent security review are separate states. CLI install/start/uninstall/rollback operation records remain explicitly unknown unless a disposable-profile report establishes them; ordinary host tests do not establish those operations.
