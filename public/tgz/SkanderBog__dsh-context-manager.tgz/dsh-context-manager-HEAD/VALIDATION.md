# Validation

## v0.2.0 release validation — 2026-10-19

- Source and extracted-package suites pass 44 tests. History navigation now covers older/newer pages, empty pages, cursor zero, clearing the originals view, and refresh resetting the navigation trail.
- The CI matrix adds Harness `0.2.1-rc.2` with its stable Cordis `4.0.5` peer. Release publication is gated on all six lanes; profile lifecycle and packaged desktop GUI coverage remain separate.
- The earlier features and their validation are recorded below. No installed profile is changed by publishing this release.

## Context reporting, history inspection, and reviewed notes — 2026-10-19

- The exact package check passes **44 tests** against the extracted host bundle and browser entry. It verifies the eleven-file public archive. Real Harness services cover provider usage with disjoint cache buckets, missing usage, a session-bound ACP status tool, compression attribution, pagination, reload, preserved native reasoning/signatures, and unchanged context during inspection.
- Notes are tested across two successive summaries and persistence replay, including exact source provenance, explicit omission, preflight rejection of invalid/excessive notes, exclusion from generative rewriting, and rejection of note-format impersonation by ordinary assistant text. Browser tests cover editing notes, preview invalidation, separate local/reported usage, on-demand ACP status, original-message pagination, and refresh cleanup.
- Headless Chrome passed at **1280 × 800** and **360 × 800** with 65 history groups. Actual textarea entry reaches the preview request. ACP and originals views render; preview review receives focus; Apply remains visible; there is no horizontal overflow or browser error. These use a controlled command endpoint and the shipped browser source, not the packaged desktop GUI.
- The installed-plugin composition harness passed against Harness **0.2.0-rc.2**, Rewind **0.15.0**, Better Sidebar **0.24.1**, DSH Market **1.66.6**, and PDF Reader. It uses scratch storage, exercises rewind/cancellation, durable compaction, PDF text/images, read-only Market capabilities, and plugin disposal.
- The ACP integration exercises the real Harness tool runtime with a controlled tool matching the native ACP string-output contract. No live billion-context/IoT deployment or paid provider call was made. External engines can alter their APIs and context policies; these checks do not certify every combination. Existing native reasoning is excluded, never rewritten by this plugin.
- No release version, profile registration, or desktop restart is part of this source update. CI separately checks Linux/Node 22, Linux/Node 24 on two Harness alpha versions, macOS/Node 24, and Windows/Node 24.

## Unreleased compatibility fixes — 2026-10-08

- Regression tests first reproduced a lost command registration after closing a second view and an obsolete summary request continuing after a rewind. The fixes retain per-view registrations and abort previews on context-changing session events, with listener cleanup on completion.
- The updated source and built host tests pass **28 tests**; the package suite also exercises the browser entry extracted from the tarball.
- `scripts/check-installed.mjs` provides an opt-in composition test against an explicit runtime/profile/PDF checkout. It uses real Harness `0.2.0-rc.2`, Rewind `0.15.0`, Better Sidebar `0.24.1`, and DSH Market `1.66.6`. Both plugin checkouts mount together. Rewind invalidates a completed preview, cancels a streaming preview, and preserves an earlier persisted compaction checkpoint. PDF text extraction and image attachments work with the other plugins present. Unloading these two plugins leaves Rewind's commands and Sidebar's HTTP routes registered. Market's read-only capabilities endpoint responds successfully.
- The installed desktop was **0.22.3**. The **0.22.4** release tag pins the same `0.2.0-rc.2` session, LLM, tool and conversation UI APIs. This supports host API compatibility; it is not a claim that the packaged 0.22.4 GUI or every bundled desktop plugin was exercised. Third-party browser UIs, Market package mutations and external model providers remain outside this isolated test.
- The harness uses scratch storage and controlled settings, loader inventory, web-runtime metadata and model replies. It applies the host's real package-resolution interception; ordinary Node imports can otherwise resolve an obsolete global Harness installation and produce false compatibility failures.

## Isolated update validation

Version 0.1.4 was tested on 2026-10-02 in a separate checkout with Node.js 22.23.2 and Harness 0.2.0-rc.2. The active desktop, its profile, and the linked installed plugin were left untouched.

- The new browser regression first failed against 0.1.3: with exactly one eligible older exchange, “Summarize older groups” left it set to Keep. It passes after removing the extra exclusion; the locked latest exchange still stays Keep, and “Keep all” resets the selection.
- All **26 tests** passed against the rebuilt host entry and browser source.
- All **26 tests** also passed against the host and browser files extracted from `dsh-context-manager-0.1.4.tgz`, with dependencies from a separate clean installation.
- Summary request coverage now checks the last routed provider/model, rather than an unsent composer selection, and the `compaction` purpose recognized by host routing middleware. Third-party routing plugins were source-reviewed; live interoperability was not tested.

The following live desktop observations belong to the earlier 0.1.3 release. No new desktop installation, restart, or live model test was performed for 0.1.4.

## Previous 0.1.3 validation

Verified on 2026-10-02 with Node.js 22.23.2 and DeepSeek Harness 0.2.0-rc.2.

## Automated checks

A fresh dependency installation passed all **26 tests**, exercising the compiled host entry plus the browser client. Tests use real Harness Session, AgentLoop, command, projection, invariant, token-meter, and JSONL persistence implementations, with a controlled model response.

Coverage includes balanced tool exchanges, preserved reasoning signatures, protected latest exchanges and Harness instruction snapshots, selective and repeated compaction, preview cancellation and expiry, stale-session rejection, empty/truncated/oversized summaries, persistence failures, partial commit reporting, and replay without this plugin. Browser checks cover controls, review confirmation, stale/failed application, and successful refresh.

## Live desktop check

The plugin loaded in the community Linux desktop using its standard Harness plugin interface. A disposable synthetic conversation used DeepSeek-V41-Flash with High reasoning. Only this test conversation was compacted.

1. The Context button displayed the live percentage. The panel correctly protected system instructions, runtime context, skill catalogs, and the latest exchange.
2. One deliberately repetitive older user message was summarized. Its estimated size fell from **2,017 to 238 tokens**; total context fell from **19,968 to 18,189 tokens**. The exact checkpoint was reviewed before Apply.
3. The next model reply correctly recalled all three test facts: project **LANTERN**, reference **420**, and next step **draw a blue square**. It did not perform the fictional action.
4. The original message remained visible in chat and present in the persisted log. A read-only check of that log confirmed the standard compaction start, summary, checkpoint, and end events.
5. The context and existing PDF plugins both survived a desktop restart when installed from permanent project folders. Their local dependencies were resolved against the installed Harness runtime.

## Installation finding and limits

This desktop build incorrectly treats local archive dependencies as missing directories and removes them on startup. The linked-folder workaround is documented in README. Updating an installed module can also require restarting Harness; toggling the component alone did not clear the old module cache in this installation.

This is a small functional test, not a general benchmark of model summary quality. Token estimates are approximate. Native Windows and macOS desktops were not tested. The plugin targets DeepSeek Harness, not the separate consumer DeepSeek chat app. Keep is per operation; permanent pinning and one-click undo are not implemented.
