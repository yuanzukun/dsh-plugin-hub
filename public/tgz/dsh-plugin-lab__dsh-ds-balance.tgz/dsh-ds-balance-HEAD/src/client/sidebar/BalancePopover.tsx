/**
 * 余额浮层：点击条目后在条目的上方展开。
 *
 * 皮肤照抄官方「用量 / 用时」浮层（ui-chat 的 stat-dialog.module.css）；
 * 定位由父组件用 useAnchoredPosition 算好后经 style 传入，本组件只渲染表面。
 * 面板由父组件 createPortal 挂到 document.body，所以 panelRef 指向面板自身。
 * @module dsh-ds-balance/client/sidebar/BalancePopover
 */

import type { CSSProperties, RefObject } from 'react'
import {
  Button,
  FishLogo,
  IconPluginPinwheelOutlineRegular,
  IconRefreshOutlineRegular,
  Tooltip,
} from '@deepseek-ai/dsh-client-ui-primitives'
import { interpolate, type LocaleKey } from '../locales.ts'
import { ageBucket, formatMoney, type AgeBucket, type CurrencySelection } from '../model.ts'
import css from './BalancePopover.module.css'

/** 没有可显示金额时的占位符；条目与浮层共用同一个字面量。 */
export const BALANCE_PLACEHOLDER = '--'

/** ageBucket 里带数值的四档。 */
type CountedBucket = Exclude<AgeBucket, 'just-now' | 'unknown'>

/** 档位对应的 Intl 单位名。 */
const AGE_UNIT: Record<CountedBucket, string> = {
  seconds: 'second',
  minutes: 'minute',
  hours: 'hour',
  days: 'day',
}

/**
 * 探测词典语言。
 *
 * `t` 只接受键、不暴露当前语言，而词典里没有时长单位词条（键名已定、不许新增），
 * 所以单位的本地化交给 `Intl.NumberFormat` 的 unit 样式：中文得「3分钟」、
 * 英文得「3 minutes」，再套进 `{value}前` / `{value} ago` 两种模板都成立。
 * @param t - 词典函数。
 * @returns 传给 Intl 的 BCP-47 语言标签。
 */
function unitLocale(t: (key: LocaleKey) => string): string {
  return /[\u3400-\u9fff]/.test(t('popover.updated.justNow')) ? 'zh-CN' : 'en-US'
}

/**
 * 把一档数值时长渲染成本地化的单位短语。
 * @param bucket - 已排除 just-now / unknown 的档位。
 * @param value - 该档位的数值。
 * @param locale - 目标语言标签。
 * @returns 形如「3分钟」或「3 minutes」的短语。
 */
function ageValueText(bucket: CountedBucket, value: number, locale: string): string {
  try {
    return new Intl.NumberFormat(locale, {
      style: 'unit',
      unit: AGE_UNIT[bucket],
      unitDisplay: 'long',
    }).format(value)
  } catch {
    /* 老引擎缺 unit 样式时退化成裸数字，不阻断渲染。 */
    return String(value)
  }
}

/** 浮层属性。 */
export interface BalancePopoverProps {
  /** 词典函数。 */
  t: (key: LocaleKey) => string
  /** 币种选择结果。 */
  selection: CurrencySelection
  /** 用户在设置里选的币种，用于不匹配文案。 */
  displayCurrency: string
  /** 数据现在的年龄（毫秒）= 收到那份响应时后端报的年龄 + 此后流逝的时间。 */
  ageMs: number
  /**
   * 标题里的来源标签（含括号，来自词典）；`null` 表示不标。
   *
   * 由父组件算好再传进来：本组件不做来源判断，也不拼括号 —— 中英文的括号不同形，
   * 拼在代码里必然出错。
   */
  sourceLabel: string | null
  /** 是否正在刷新。 */
  refreshing: boolean
  /** 冷却剩余秒数；0 表示可以刷新。 */
  cooldownSeconds: number
  /**
   * 「本宿主没有配置槽」的提示行；null 表示不提示。
   *
   * 文案由 [config-slot.ts](../config-slot.ts) 给：它是英文 `[WARN]` 诊断行，
   * 按兼容性硬约束两种语言下都照原文给，所以刻意不进双语词典。
   */
  configSlotWarning: string | null
  /** 面板自身的引用：useAnchoredPosition 用它量尺寸，外部点击判定用它算「内部」。 */
  panelRef: RefObject<HTMLElement>
  /** 由 useAnchoredPosition 给出的 fixed 坐标；首帧是 MEASURE_STYLE（隐藏待测）。 */
  style: CSSProperties
  /** 刷新回调。 */
  onRefresh: () => void
  /** 「改用 X」回调。 */
  onUseShown: () => void
  /**
   * 「改用 X」按钮是否置灰；缺省 false。
   * 设置不可写时置灰 —— 不假装写入成功：点下去什么都不会发生，比留一个按得动却没反应的按钮诚实。
   */
  useShownDisabled?: boolean
  /**
   * 右上角图标：点下去做什么、落到哪里。宿主没提供 layout 服务时给 undefined ——
   * 这时那个按钮**不渲染**：不留按不动的死按钮。
   */
  pluginsAction?: PluginsAction
}

/**
 * 浮层右上角图标点下去会发生什么。
 *
 * 落点由**宿主能力**决定：宿主提供跨插件深链服务时直达本插件的配置格，
 * 服务缺席时只能到 Plugins 列表。所以措辞跟着落点分档 ——
 * 「打开插件配置页」与「打开插件页」各说自己那一件事，不许用一句含糊的话盖住两种落点。
 */
export interface PluginsAction {
  /** 执行跳转；「先关浮层」由父组件包在里面。 */
  open: () => void
  /** 落点是不是本插件的配置格。 */
  reachesConfig: boolean
}

/**
 * 渲染余额浮层。
 * @param props - 选择结果、时间、刷新状态、面板 ref/style 与三个动作回调。
 * @returns 浮层元素。
 */
export function BalancePopover(props: BalancePopoverProps): JSX.Element {
  const {
    t,
    selection,
    displayCurrency,
    ageMs,
    sourceLabel,
    refreshing,
    cooldownSeconds,
    configSlotWarning,
    panelRef,
    style,
    onRefresh,
    onUseShown,
    useShownDisabled,
    pluginsAction,
  } = props

  const shown = selection.shown
  const totalText = shown === null ? BALANCE_PLACEHOLDER : formatMoney(shown.total, shown.currency)
  const grantedText =
    shown === null ? BALANCE_PLACEHOLDER : formatMoney(shown.granted, shown.currency)
  const toppedUpText =
    shown === null ? BALANCE_PLACEHOLDER : formatMoney(shown.toppedUp, shown.currency)

  const age = ageBucket(ageMs)
  const updatedText =
    age.bucket === 'just-now' || age.bucket === 'unknown'
      ? t('popover.updated.justNow')
      : interpolate(t('popover.updated'), {
          value: ageValueText(age.bucket, age.value, unitLocale(t)),
        })

  const cooling = cooldownSeconds > 0

  // 刷新中优先于冷却：两者不会同时成立，但刷新中的文案更贴近当下。
  let statusText = ''
  if (refreshing) statusText = t('popover.refreshing')
  else if (cooling)
    statusText = interpolate(t('popover.cooldown'), { value: String(cooldownSeconds) })

  const refreshLabel = t('sidebar.aria.refresh')

  // 右上角图标没有可见文字，名字只能来自 aria-label 与 tooltip —— 两处逐字同源，
  // 且**按落点分档**：能直达配置格就说配置格，只能到列表就说列表（见 PluginsAction）。
  const pluginsLabel = t(
    pluginsAction?.reachesConfig === true
      ? 'popover.action.openPluginConfig'
      : 'popover.action.openPlugins',
  )

  return (
    <section
      ref={panelRef}
      className={css.panel}
      style={style}
      role="dialog"
      aria-label={t('popover.title')}
    >
      <div className={css.title}>
        {/* 标题与来源标签**合成一组**：这一行是 space-between 的两端布局，三个并列子元素会把
            标签推到行中间。包起来之后标签紧贴标题右侧，右端仍由那个图标按钮占着。 */}
        <span className={css.titleMain}>
          {/* 标题就是这个账户在官网的用量页入口：图标与文字本身不变，只有文字带下划线且不变色
              （宿主没有「链接色」这种语义 token，硬套会破配色纪律）。 */}
          <a
            className={css.titleLabel}
            href="https://platform.deepseek.com/usage"
            target="_blank"
            rel="noopener noreferrer"
          >
            <FishLogo size={14} />
            {t('popover.title')}
          </a>

          {/* 来源标签是**链接外面的普通文本**：它描述这个数字的来路，不是官网用量页的入口 ——
              放进链接里它会跟着下划线，读起来像标题的一部分。括号由词典给，这里只做拼接。 */}
          {sourceLabel === null ? null : <span className={css.sourceLabel}>{sourceLabel}</span>}
        </span>

        {/* 右上角：无可见文字的图标按钮，点了去本插件的配置格；宿主没有那条深链服务时
            退回 Plugins 列表 —— 措辞跟着落点走，不承诺到不了的地方。
            名字只能靠 aria-label 与 tooltip；动作缺席（宿主没有 layout 服务）时整块不渲染。 */}
        {pluginsAction === undefined ? null : (
          <Tooltip label={pluginsLabel} side="top" delayMs={500}>
            <button
              type="button"
              className={css.iconButton}
              aria-label={pluginsLabel}
              onClick={pluginsAction.open}
            >
              <IconPluginPinwheelOutlineRegular size={16} />
            </button>
          </Tooltip>
        )}
      </div>

      {/* 标题与明细之间唯一的一条分隔线；只靠边框成线，所以标 aria-hidden。 */}
      <div className={css.titleRule} aria-hidden />

      <dl className={css.details}>
        <dt>{t('popover.total')}</dt>
        <dd>{totalText}</dd>
        <dt>{t('popover.granted')}</dt>
        <dd>{grantedText}</dd>
        <dt>{t('popover.toppedUp')}</dt>
        <dd>{toppedUpText}</dd>
      </dl>

      {shown !== null && !selection.matchesPreference ? (
        <div className={css.notice}>
          <p className={css.noticeText}>
            {interpolate(t('popover.mismatch'), { wanted: displayCurrency, shown: shown.currency })}
          </p>
          <div className={css.noticeActions}>
            <Button
              size="sm"
              variant="outline"
              disabled={useShownDisabled === true}
              onClick={onUseShown}
            >
              {interpolate(t('popover.action.useShown'), { shown: shown.currency })}
            </Button>
          </div>
        </div>
      ) : null}

      {/* 缺配置槽的诊断行：只解释「为什么这里没有配置入口」并给升级指引，
          不提供任何动作按钮 —— 升级宿主不是这个浮层能做的事。 */}
      {configSlotWarning === null ? null : (
        <div className={css.notice}>
          <p className={css.noticeText}>{configSlotWarning}</p>
        </div>
      )}

      <div className={css.footer}>
        <span className={css.updated}>{updatedText}</span>
        <span className={css.status} role="status">
          {statusText}
        </span>
        <Tooltip label={refreshLabel} side="top" delayMs={500} disabled={refreshing || cooling}>
          <button
            type="button"
            className={css.refresh}
            aria-label={refreshLabel}
            // 冷却期内也算不可用：点了不会发请求，按钮就该灰着，而不是只换一行文字。
            disabled={refreshing || cooling}
            data-refreshing={refreshing || undefined}
            data-cooling={cooling || undefined}
            onClick={onRefresh}
          >
            <IconRefreshOutlineRegular size={16} />
          </button>
        </Tooltip>
      </div>
    </section>
  )
}
