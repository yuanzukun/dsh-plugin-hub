/**
 * 勘察与开发用的 mock 场景。覆盖后端契约里所有状态组合。
 *
 * **不变量**：`selected` 由后端权威给出，所以每个场景里它要么是 `null`，
 * 要么必须能在 `balances` 里找到同币种同金额的一条。覆写 `balances` 的场景
 * 必须同时覆写 `selected`。这条由 `test/mock-scenarios.test.ts` 兜底。
 * @module dsh-ds-balance/client/mock/scenarios
 */

import type { BalanceResponse } from '../api-types.ts'
import { UNREACHABLE_CODE } from '../data.ts'

const T0 = 1760000000000

const cny = (total: string, granted: string, toppedUp: string) => ({
  currency: 'CNY',
  total,
  granted,
  toppedUp,
})

/** 造一个完整的响应，未指定的字段走正常值。 */
function make(patch: Partial<BalanceResponse>): BalanceResponse {
  return {
    requestId: 'req_mock',
    schemaVersion: 1,
    source: 'deepseek-http',
    situation: 'ok',
    state: 'ok',
    stale: false,
    fetchedAt: T0,
    ageMs: 12000,
    isAvailable: true,
    accountTag8: 'a1b2c3d4',
    balances: [cny('110.00000000', '10.00000000', '100.00000000')],
    selected: { currency: 'CNY', total: '110.00000000' },
    severity: 'ok',
    thresholds: { CNY: { warn: '10.00000000', critical: '5.00000000' } },
    todayUsage: null,
    error: null,
    ...patch,
  }
}

/** 全部场景。键即 URL 参数 `?dsb=<key>` 的取值。 */
export const scenarios = {
  /** 正常。 */
  ok: make({}),

  /** 正常，但数字来自账号登录那条路（用来眼看「来源标签」）。 */
  account: make({ source: 'deepseek-account' }),

  /** 余额偏低但可用。 */
  warn: make({
    situation: 'low',
    severity: 'warn',
    balances: [cny('8.00000000', '0.00000000', '8.00000000')],
    selected: { currency: 'CNY', total: '8.00000000' },
  }),

  /** 余额告急。 */
  critical: make({
    situation: 'critical',
    severity: 'critical',
    balances: [cny('3.00000000', '0.00000000', '3.00000000')],
    selected: { currency: 'CNY', total: '3.00000000' },
  }),

  /** 账户不可用（余额耗尽 / 欠费）。读到了，但上游说这个账户停用。 */
  unavailable: make({
    situation: 'account-unavailable',
    severity: 'unavailable',
    isAvailable: false,
    balances: [cny('0.00000000', '0.00000000', '0.00000000')],
    selected: { currency: 'CNY', total: '0.00000000' },
  }),

  /** 有旧值但本次刷新失败：数字照常显示，文案说它旧。 */
  stale: make({
    situation: 'stale',
    state: 'stale',
    stale: true,
    severity: 'unknown',
    ageMs: 3_600_000,
    fetchedAt: T0 - 3_600_000,
    error: { code: 'NO_NETWORK', message: 'fetch failed' },
  }),

  /** 无值失败：接入了却读不到（没有旧快照）。环是叉。 */
  error: make({
    situation: 'fetch-failed',
    state: 'error',
    stale: false,
    severity: 'unknown',
    isAvailable: false,
    balances: [],
    selected: null,
    ageMs: 0,
    error: { code: 'UPSTREAM_5XX', message: 'upstream returned 500' },
  }),

  /** 插件自己的端点不可达（旧契约里没有这个信号，靠客户端本地合成）。 */
  offline: make({
    situation: 'offline',
    state: 'error',
    stale: false,
    severity: 'unknown',
    isAvailable: false,
    balances: [],
    selected: null,
    ageMs: 0,
    error: { code: UNREACHABLE_CODE, message: 'balance endpoint responded 502' },
  }),

  /** 插件自己出错了（装配错误之类）：与「上游坏了」分开说。 */
  internalError: make({
    situation: 'internal-error',
    state: 'error',
    stale: false,
    severity: 'unknown',
    isAvailable: false,
    balances: [],
    selected: null,
    ageMs: 0,
    error: { code: 'STORAGE_ERROR', message: 'no ledger for source deepseek-account' },
  }),

  /** 未配置：尚无任何解释。 */
  empty: make({
    situation: 'empty-wallet',
    state: 'empty',
    severity: 'unknown',
    isAvailable: false,
    balances: [],
    selected: null,
    ageMs: 0,
  }),

  /** 未配置且带 NO_KEY 错误 —— 需要用户去配置的那一族。 */
  noKey: make({
    situation: 'no-credential',
    state: 'empty',
    severity: 'unknown',
    isAvailable: false,
    balances: [],
    selected: null,
    ageMs: 0,
    error: { code: 'NO_KEY', message: 'no API key configured' },
  }),

  /** 首帧：还没问到后端。 */
  checking: make({
    situation: 'checking',
    state: 'empty',
    severity: 'unknown',
    isAvailable: false,
    balances: [],
    selected: null,
    ageMs: 0,
  }),

  /** 多币种。`selected` 显式写出，不靠 `make()` 的默认值兜。 */
  multiCurrency: make({
    balances: [
      cny('110.00000000', '10.00000000', '100.00000000'),
      { currency: 'USD', total: '20.00000000', granted: '0.00000000', toppedUp: '20.00000000' },
    ],
    selected: { currency: 'CNY', total: '110.00000000' },
    thresholds: {
      CNY: { warn: '10.00000000', critical: '5.00000000' },
      USD: { warn: '2.00000000', critical: '1.00000000' },
    },
  }),

  /**
   * 选定了账户里没有的币种（USD），账户只有 CNY。
   *
   * 不匹配由「`selected.currency` 与设置里的显示币种不等」判定 —— 所以场景本身
   * 只需要保证 `selected` 是账户里真实存在的那个币种，剩下的交给设置值。
   */
  currencyMismatch: make({
    balances: [cny('110.00000000', '10.00000000', '100.00000000')],
    selected: { currency: 'CNY', total: '110.00000000' },
  }),

  /** 账户完全没有余额。 */
  noBalanceAtAll: make({
    situation: 'empty-wallet',
    severity: 'unknown',
    isAvailable: true,
    balances: [],
    selected: null,
  }),

  /** 今日用量缺失（第一版 UI 不消费，用于契约回归）。 */
  usageMissing: make({ todayUsage: null }),

  /** 今日用量需复核（第一版 UI 不消费，用于契约回归）。 */
  usageNeedsReview: make({
    todayUsage: {
      value: '3.21000000',
      currency: 'CNY',
      source: 'projection',
      confidence: 'low',
      needsReview: true,
      range: ['1.50000000', '6.40000000'],
    },
  }),
} satisfies Record<string, BalanceResponse>

/** 场景键。 */
export type ScenarioKey = keyof typeof scenarios

/** 场景键清单，供开发切换器使用。 */
export const scenarioKeys = Object.keys(scenarios) as ScenarioKey[]

/** 默认场景。 */
export const defaultScenario: ScenarioKey = 'ok'

/** 运行时判断一个字符串是不是已知场景键。 */
export function isScenarioKey(value: string): value is ScenarioKey {
  return Object.prototype.hasOwnProperty.call(scenarios, value)
}
