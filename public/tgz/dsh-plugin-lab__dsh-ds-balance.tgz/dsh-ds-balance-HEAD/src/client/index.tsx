/**
 * 浏览器半边入口：注册词典、bundle 详情页里的配置卡片与左下角条目。
 *
 * 这两半各占一个 slot，互不依赖；配置卡片挂在 `plugins.bundle.config` 上，
 * key 逐字就是包名。
 *
 * 两侧共用**同一个** {@link ConfigFormOf}：`ctx.configForms.get(ENTRY_ID)` 在 apply 期
 * 建一次、引用稳定。`plugins.bundle.config` 的座位 props **永远不带 `form`**
 * （0.1.6 与 0.1.7 两版同形，宿主 `PluginManagerPage.tsx:584` 只递 `view` 与 `entryKey`），
 * 所以这一条就是唯一读路径 —— 左下角条目与卡片都不经过 slot props 拿表单。
 *
 * 配置那一格另有一层**能力探测**（不查版本号）：卡片拿不到表单时宿主不会报错，
 * 只会静默什么都不显示。探测只决定要不要在浮层里提示，不参与注册 ——
 * 服务真的在时，下面那次 `inject` 照旧正常注册。见 [config-slot.ts](config-slot.ts)。
 * @module dsh-ds-balance/client
 */

import { useCallback, useSyncExternalStore, type ReactNode } from 'react'
import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type { ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client'
// 类型导入即声明：这两行让下面两个 slot 键的契约进入类型系统。
import type {} from '@deepseek-ai/dsh-client-ui-plugin-manager/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import { BalanceSettingsCard } from './settings/BalanceSettingsCard.tsx'
import { writeFieldValue } from './settings/use-config-form.ts'
import type { ConfigFormOf } from './settings/use-config-form.ts'
import { SidebarBalance, type PluginsNavigation } from './sidebar/SidebarBalance.tsx'
import { createRouteHint, type RouteHint, type RouteHintContext } from './route-hint.ts'
import type { PluginsAction } from './sidebar/BalancePopover.tsx'
// 副作用导入：修正宿主 .footerActions 的排版遗漏，见 .agents/notes/2026-09-17-footer-stack-override.md。
import './sidebar/footer-stack.module.css'
import { NS, en, zh, type LocaleKey } from './locales.ts'

// 把本命名空间并进 DSH 的词典表：`ctx.locale.register` 的实参因此有类型约束，
// 拼错命名空间或缺一种语言都是编译错误。
//
// **声明放在注册点，不放词典模块**：词典文件是纯数据（测试要能直接 import 它做键集对账），
// 而这条 module augmentation 依赖宿主包的类型，把宿主拖进任何读到词典的程序里都不划算。
declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    'ds-balance': LocaleKey
  }
}
import { CONFIG_SLOT, createConfigSlotProbe, type ConfigSlotProbe } from './config-slot.ts'

/**
 * 本插件那一行的 Loader 条目 id —— **逐字抄自宿主半边的 `src/config.ts`**。
 *
 * 不许跨半体值导入（[src/AGENTS.md](../AGENTS.md)），所以这里是第二份字面量；
 * 两份必须逐字相等，且等于 `package.json` 的 `name` 与 `cordis.patch.yml` 的行 id ——
 * 三条由 `test/artifacts.test.ts` 对账。0.1.7 起它同时是**设置命名空间**：
 * 客户端按它取表单，写错的表现是卡片在、但拿不到 form。
 */
export const ENTRY_ID = 'dsh-ds-balance'

/**
 * `plugins.bundle.config` 的 key —— **就是包名**。
 *
 * 宿主按包名索引这一格（`slot-contract.ts` 对该槽的说明 + `config-ledger.ts:51` 的
 * `keysOf('plugins.bundle.config')` + `PluginManagerPage.tsx:1269` 的
 * `configured={ledger.bundles.has(pkg.name)}`），所以它与 {@link ENTRY_ID} 今天是同一个
 * 字面量。**别把两件事并成一个概念**：槽 key 取包名，`ctx.configForms.get()` 取
 * **Loader 条目 id**；两者今天同串，漂开的表现是卡片在、表单永远只读。
 * 这条静默耦合由 `test/redlines.test.ts` 与 `test/artifacts.test.ts` 对账。
 *
 * **真源是 package.json 的 name**；本处手写一份字面量是因为浏览器半体不 import
 * package.json（产物要能在信封里照字面找到这个键），由 redlines 断言与 `pkg.name` 逐字相等。
 * **写成独立具名常量而不是直接用 `ENTRY_ID`**：产物级断言要在打包后的信封里照字面
 * 找到这个键 —— 直接复用那个常量会让「键」与「命名空间」在产物里无从分辨。
 */
export const BUNDLE_CONFIG_KEY = 'dsh-ds-balance'

/**
 * 左下角条目在 `sidebar.footer.action` 里的 slot id。
 *
 * **它不是设置命名空间**，0.1.7 起与配置无关；与宿主半边的 `SIDEBAR_ENTRY_ID` 逐字一致。
 */
export const SIDEBAR_ENTRY_ID = 'ds-balance'

/** 两条半体共享的默认值，用于快照缺字段时兜底。与宿主 schema 的默认值一致。 */
const DEFAULT_CONFIG = {
  displayCurrency: 'auto',
  manualRefreshCooldownSeconds: 30,
  clientPollSeconds: 30,
} as const

/**
 * 运行时服务门禁：删任何一项都会让 `apply` 静默不跑。
 *
 * 只留**永远在**的两项。`configForms` **不在这里**：它是可选服务，由 `apply` 内的
 * `ctx.inject` 把门（[src/AGENTS.md](../AGENTS.md) 的可选服务规则）。
 *
 * **缺它的实际表现是整个浏览器半边不渲染** —— 圆环与浮层也一起消失，不是只丢卡片：
 * 左下角条目要读 `displayCurrency`（浮层的「改用 X」也写它），那条路同样走
 * `configForms`，所以两者**同生共死**。这是 0.1.6 及更早宿主上的真实现象，
 * 也正是 [config-slot.ts](config-slot.ts) 那层探测要报的那件事。
 * 把两者解耦（例如缺服务时仍画一个不带设置的圆环）是产品决策，不在本轮范围。
 */
export const inject = ['slots', 'locale']

/** 组件拿到的 `t` 形状。真实类型来自 slot 的 locale 座位，这里只约束键集。 */
type Translate = (key: LocaleKey) => string

/** 是不是可调用的翻译函数。 */
function isTranslate(value: unknown): value is Translate {
  return typeof value === 'function'
}

/** 收窄座位里的 `t`：宿主没给（类型未知）时回落成「原样返回键」的兜底，绝不崩。 */
function translateOf(value: unknown): Translate {
  return isTranslate(value) ? value : (key) => key
}

/** 是不是普通对象（数组与 `null` 都不算）。 */
function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/** 把任意值收窄成普通对象；数组与 null 都当作空对象。 */
function asRecord(value: unknown): Record<string, unknown> {
  return isRecord(value) ? value : {}
}

/**
 * 订阅配置表单的快照。
 *
 * 官方契约明写 `getSnapshot()` 在两个快照之间返回**同一个引用**，所以可以直接交给
 * `useSyncExternalStore`，不需要外面再包一层缓存。
 * @param form - 该条目的配置表单，apply 期建一次，引用稳定。
 * @returns 当前快照。
 */
function useFormSnapshot(form: ConfigFormOf): ConfigFormSnapshot<Record<string, unknown>> {
  const subscribe = useCallback((listener: () => void) => form.subscribe(listener), [form])
  const getSnapshot = useCallback(() => form.getSnapshot(), [form])
  return useSyncExternalStore(subscribe, getSnapshot)
}

/** 生效值；缺字段（首帧）时收窄成空对象，读路径保持全域可读。 */
function useScopeValue(form: ConfigFormOf): Record<string, unknown> {
  return asRecord(useFormSnapshot(form).value)
}

/**
 * 订阅「宿主文档是否接受写入」。
 *
 * 为 false 时界面据此禁用写入入口，而不是让用户点完发现什么都没发生。
 * @param form - 该条目的配置表单。
 * @returns 当前是否接受写入。
 */
function useScopeWritable(form: ConfigFormOf): boolean {
  return useFormSnapshot(form).writable !== false
}

/** 从快照里取展示币种。 */
function readDisplayCurrency(value: Record<string, unknown>): string {
  const raw = value.displayCurrency
  return typeof raw === 'string' && raw.length > 0 ? raw : DEFAULT_CONFIG.displayCurrency
}

/** 从快照里取手动刷新冷却秒数。 */
function readCooldown(value: Record<string, unknown>): number {
  const raw = Number(value.manualRefreshCooldownSeconds)
  return Number.isFinite(raw) && raw >= 0 ? raw : DEFAULT_CONFIG.manualRefreshCooldownSeconds
}

/** 从快照里取客户端轮询秒数。下限跟 schema 的 5 秒对齐。 */
function readPollSeconds(value: Record<string, unknown>): number {
  const raw = Number(value.clientPollSeconds)
  return Number.isFinite(raw) && raw >= 5 ? raw : DEFAULT_CONFIG.clientPollSeconds
}

/**
 * 读某个币种的 warn 阈值。
 *
 * 字段名由宿主 schema 的约定拼出来：币种代码小写 + `Warn`（`cnyWarn` / `usdWarn`）。
 * 拼名而不是列表，是为了不在这里再抄一份币种清单 —— 加了新币种，设置卡片与宿主 schema
 * 各自登记，这里自动跟上。
 * **只服务圆环弧长**；颜色不走这里。
 * @param value - 设置快照里的生效值。
 * @param currency - 后端选定的展示币种。
 * @returns 阈值；没配或不是有限数时给 `undefined`。
 */
function readWarnThreshold(value: Record<string, unknown>, currency: string): number | undefined {
  const raw = Number(value[currency.toLowerCase() + 'Warn'])
  return Number.isFinite(raw) ? raw : undefined
}

/**
 * 配置指纹：任何一项设置改动都会换一个值，用来触发一次立刻重取。
 *
 * **不含 `apiKey` 本身**（密钥不进 React 的依赖字符串），只带一个「配没配」的布尔；
 * 其余字段按名字排序拼成稳定串，顺序不受对象键序影响。
 * @param value - 设置快照里的生效值。
 * @returns 稳定指纹。
 */
function readSignature(value: Record<string, unknown>): string {
  const parts = Object.keys(value)
    .filter((key) => key !== 'apiKey')
    .sort()
    .map((key) => key + '=' + String(value[key]))
  parts.push('apiKeySet=' + String(value.apiKey !== undefined && value.apiKey !== ''))
  return parts.join('\u0001')
}

/** 左下角条目的座位 props。 */
interface SidebarSeat {
  wide: boolean
  t: unknown
}

/**
 * 左下角条目。
 *
 * 注册常驻，不做动态注销：重新注册会换掉 React key，导致整棵子树重挂、局部状态丢失。
 * 「启用左下角」开关已删除：左下角是本插件唯一的展示位，关掉它等于关掉全部功能。
 */
function SidebarSeatComponent(props: {
  seat: SidebarSeat
  form: ConfigFormOf
  configSlotProbe: ConfigSlotProbe
  pluginsNavigation: PluginsNavigation
  routeHint: RouteHint
}): ReactNode {
  const value = useScopeValue(props.form)
  const writable = useScopeWritable(props.form)
  // 与设置卡片共用同一条写路径：写进本插件那一行的设置命名空间。
  // 成败由 writeFieldValue 的返回值直接给出，不再读回 user 层猜。
  const selectCurrency = useCallback(
    (currency: string): Promise<boolean> =>
      writeFieldValue(props.form, 'displayCurrency', currency),
    [props.form],
  )
  return (
    <SidebarBalance
      wide={props.seat.wide}
      t={translateOf(props.seat.t)}
      configSlotProbe={props.configSlotProbe}
      pluginsNavigation={props.pluginsNavigation}
      routeHint={props.routeHint}
      onSelectCurrency={selectCurrency}
      config={{
        displayCurrency: readDisplayCurrency(value),
        manualRefreshCooldownSeconds: readCooldown(value),
        clientPollSeconds: readPollSeconds(value),
        configSignature: readSignature(value),
        warnThresholdOf: (currency) => readWarnThreshold(value, currency),
        writable,
      }}
    />
  )
}

/** 配置卡片的座位 props。 */
interface SettingsSeat {
  /**
   * 槽的 owner props 声明的两个视图。**`plugins.bundle.config` 只会问 `page`**：
   * 宿主 `slot-contract.ts` 的原话是 *Bundle configuration renders only `page`*，
   * 全仓渲染这一格也只有 `PluginManagerPage.tsx:584` 一处；`summary` 只出现在
   * `plugins.row.config`（行缺描述时的回退，`:496`）。
   * 这里照抄 owner props 的类型面，不缩窄 —— 缩窄成 `'page'` 会与宿主声明脱节。
   */
  view: 'summary' | 'page'
  t: unknown
}

/**
 * bundle 详情页里的配置卡片。
 *
 * **`summary` 那一档已删**（本轮）：回退到 `plugins.bundle.config` 之后没有任何渲染路径
 * 会请求它（见 {@link SettingsSeat}），留着就是一个永不执行的分支 ——
 * 本仓对假信号很敏感（`orderPairWrites` 退役那条注释就是先例）。
 * 当年它也不能返回 null：本包没有发布展示元数据（`locale/*.json` 的 `meta.title` /
 * `meta.description`），行描述永远是空的，那一档必然被渲染。
 */
function SettingsSeatComponent(props: { seat: SettingsSeat; form: ConfigFormOf }): ReactNode {
  const t = translateOf(props.seat.t)
  return <BalanceSettingsCard t={t} form={props.form} />
}

/**
 * Plugins 面板的 id，逐字等于宿主 `ui-plugin-manager/src/client/index.ts:47` 的 `PANEL_ID`。
 *
 * 这里写字面量而**不 import** 那个常量：它是另一个 feature plugin 的值导出，
 * 跨插件值导入是本仓红线。
 */
const PLUGINS_PANEL_ID = 'plugins'

/** apply 期的入口句柄：比座位拿到的 {@link PluginsNavigation} 多两个挂载点。 */
interface PluginsNavigationHandle extends PluginsNavigation {
  /**
   * 「切到 Plugins 面板」这个动作到位时挂上它。
   * @param selectPanel - 切到 Plugins 面板的动作。
   * @returns 反注册；服务被卸载时图标跟着消失。
   */
  attachPanel: (selectPanel: () => void) => () => void
  /**
   * 「直达某个 bundle」这个动作到位时挂上它。
   * @param openBundle - 深链动作；服务缺席就一直没人挂。
   * @returns 反注册；服务被卸载时落点退回列表页。
   */
  attachDeepLink: (openBundle: (packageName: string) => void) => () => void
}

/**
 * 建一个可订阅的「打开本插件配置」入口。
 *
 * 为什么要订阅而不是直接给个 prop：`ctx.inject([...])` 的回调可能在座位注册之后才跑
 * （服务晚到），那时 prop 已经绑好了。订阅让图标随服务出现、也随它消失。
 *
 * 快照里除动作外还带**落点**：深链服务在不在，决定那句话承诺什么
 * （见 BalancePopover 的 PluginsAction）。两个服务各自晚到，所以两个挂载点都触发重发。
 * @returns 入口句柄。
 */
function createPluginsNavigation(): PluginsNavigationHandle {
  let selectPanel: (() => void) | undefined
  let openBundle: ((packageName: string) => void) | undefined
  let snapshot: PluginsAction | undefined
  const listeners = new Set<() => void>()

  /**
   * 点下去做的事：深链优先，抛错退回列表页。
   *
   * 读的是**当下**这两个动作（不是快照里那份）：快照只描述落点，服务换过也照旧能用。
   * 两条都不通只记一笔、不抛 —— 调用方已经关了浮层，圆环与后端照常。
   */
  const open = (): void => {
    if (openBundle !== undefined) {
      try {
        openBundle(BUNDLE_CONFIG_KEY)
        return
      } catch (error) {
        console.warn('[WARN] ds-balance: cannot open the bundle config page', error)
      }
    }
    try {
      selectPanel?.()
    } catch (error) {
      // 面板 id 未注册时 selectPanel 会抛（宿主 ui-layout 的 selectPanel）：profile 里没装
      // plugin-manager 时那个 main 面板不存在，点了图标就没地方可去。
      console.warn('[WARN] ds-balance: cannot switch to the plugins panel', error)
    }
  }

  /** 按当下两个动作重发快照；「页签在不在」与「落点变没变」之外不惊动订阅者。 */
  const publish = (): void => {
    const reachesConfig = openBundle !== undefined
    const next: PluginsAction | undefined =
      selectPanel === undefined ? undefined : { open, reachesConfig }
    const unchanged =
      next === undefined
        ? snapshot === undefined
        : snapshot !== undefined && snapshot.reachesConfig === reachesConfig
    if (unchanged) return
    snapshot = next
    for (const listener of [...listeners]) listener()
  }

  return {
    getSnapshot: () => snapshot,
    subscribe: (listener) => {
      listeners.add(listener)
      return () => {
        listeners.delete(listener)
      }
    },
    attachPanel: (callback) => {
      selectPanel = callback
      publish()
      return () => {
        if (selectPanel === callback) {
          selectPanel = undefined
          publish()
        }
      }
    },
    attachDeepLink: (callback) => {
      openBundle = callback
      publish()
      return () => {
        if (openBundle === callback) {
          openBundle = undefined
          publish()
        }
      }
    },
  }
}

/** 挂载两半。 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'ds-balance: dictionaries')

  // 探测「拿不拿得到配置表单」这个**能力**，不查版本号，也不盯槽名 ——
  // plugins.bundle.config 这一格在 0.1.6 与 0.1.7 都存在且都不传 form，盯它等于盯一条
  // 恒为真的信号。真正会断的那一环是 configForms 服务，所以下面那次 inject 的回调
  // 才是 markDeclared 的触发点。三种态都可逆，晚到的服务会把已经出现的提示撤掉。
  const configSlotProbe = createConfigSlotProbe()
  ctx.effect(() => () => configSlotProbe.dispose(), 'ds-balance: config slot probe')

  // 「当前会话在用哪条路由」这条提示：后端据此决定余额走 Key 还是走账号登录。
  // 侧栏是壳层座位、不在会话作用域里，所以提示自己去宿主客户端服务上读。
  //
  // **两个服务一律经 ctx.inject 把门**：cordis 不许读没 inject 过的服务，而这次读发生在
  // 渲染期 —— 直接访问会抛，抛出去的表现是左下角整条条目被停用（注册在、`active: false`）。
  // 服务缺席只让提示退化（后端回落全局默认路由），界面照常。
  const routeServices: RouteHintContext = {}
  for (const name of ['uiSession', 'sessions'] as const) {
    ctx.inject([name], (serviceCtx) => {
      serviceCtx.effect(() => {
        routeServices[name] = (serviceCtx as unknown as RouteHintContext)[name]
        return () => {
          delete routeServices[name]
        }
      }, `ds-balance: route hint (${name})`)
    })
  }
  const routeHint = createRouteHint(() => routeServices)

  // 「切到 Plugins 页」的入口：宿主把它放在跨插件服务 `ctx.layout` 上
  // （宿主 `ui-layout/src/client/service.ts:28-52`：cross-plugin panel-action face behind ctx.layout）。
  // 服务不在 —— 例如 profile 里没装 plugin-manager —— 时整条链不建立，
  // 浮层右上角那个图标就不渲染：不留按不动的死按钮。
  // layout 刻意**不进顶层 inject**：缺服务会让整个插件不装载。
  const pluginsNavigation = createPluginsNavigation()
  // 深链优先：宿主在 `next` 线起于 ui-plugin-manager 里 provide 了 pluginNavigation.openBundle(包名)
  // （@deepseek-ai/dsh-client-ui-plugin-manager 的 index.d.ts），它自己先切面板再定位到那个 bundle 的
  // 配置格 —— 所以它是加速器而不是替代品：更早的线上没有这条服务，特征检测缺席就退回
  // 「切到 Plugins 列表」，**措辞也跟着退回**（落点进了快照，见 createPluginsNavigation）。
  // 同样刻意不进顶层 inject（缺服务不能拖垮整插件装载）；两个动作各有挂载点，谁先到都不影响另一个。
  ctx.inject(['pluginNavigation'], (navCtx) => {
    // 鸭子类型收窄：旧宿主没这条服务、新宿主也可能换实现 —— 读不到就什么都不做（没图标好过点了会炸）。
    const face = (navCtx as unknown as Record<string, unknown>)['pluginNavigation']
    if (typeof face !== 'object' || face === null) return
    const candidate = (face as Record<string, unknown>)['openBundle']
    if (typeof candidate !== 'function') return
    // 绑回服务对象：宿主实现内部要用 this（与 selectPanel 同理）。
    const openBundle = (candidate as (packageName: string) => void).bind(face)
    navCtx.effect(
      () => pluginsNavigation.attachDeepLink(openBundle),
      'ds-balance: bundle config deep link',
    )
  })
  ctx.inject(['layout'], (layoutCtx) => {
    // 鸭子类型收窄：宿主可能是旧版本或换了实现（本仓不装 ui-layout、不 import 它的类型），
    // 读不到 layout 或长得不对时同样什么都不做 —— 没图标，好过点了会炸。
    if (!('layout' in layoutCtx)) return
    const face = layoutCtx.layout
    if (typeof face !== 'object' || face === null) return
    if (!('selectPanel' in face) || typeof face.selectPanel !== 'function') return
    // 绑回服务对象：宿主的 selectPanel 内部要用 this（LayoutController 的 panels 与 navigation）。
    const selectPanel = face.selectPanel.bind(face)
    // 这一层只挂动作：深链优先与两笔 warn 都在 createPluginsNavigation 的 open 里。
    layoutCtx.effect(
      () =>
        pluginsNavigation.attachPanel(() => {
          selectPanel(PLUGINS_PANEL_ID)
        }),
      'ds-balance: plugins panel navigation',
    )
  })

  // 配置是**可选服务**：用嵌套 inject 把门，服务缺席时这一段不跑（探测那条计时器照跑，
  // 到点就把浮层里的 [WARN] 提示点亮）。`get()` 的实参是**设置命名空间** = 本插件那一行的
  // Loader 条目 id，不是槽 key —— 两者今天同串，但它们不是一个概念。
  ctx.inject(['configForms'], (configCtx) => {
    // 服务到位 = 宿主有配置能力。这是探测要盯的那一环，所以在这里报 available。
    configSlotProbe.markDeclared()

    // 一条读路径。两侧共用同一个 form：卡片的座位 props 永远不带 form
    // （bundle 槽两版同形），左下角条目更是拿不到 slot props。
    const form = configCtx.configForms.get<Record<string, unknown>>(ENTRY_ID)

    // 卡片的 key 是**包名**：宿主按 ledger.bundles.has(pkg.name) 判这一格有没有注册项，
    // 写错就整段配置不出现，也不会报错。
    ctx.slots.inject(CONFIG_SLOT, () =>
      ctx.slots.register(
        { name: CONFIG_SLOT, key: BUNDLE_CONFIG_KEY, locale: NS },
        (seat: SettingsSeat) => <SettingsSeatComponent seat={seat} form={form} />,
      ),
    )

    ctx.slots.inject('sidebar.footer.action', () =>
      ctx.slots.register(
        { name: 'sidebar.footer.action', id: SIDEBAR_ENTRY_ID, order: 0, locale: NS },
        (seat: SidebarSeat) => (
          <SidebarSeatComponent
            seat={seat}
            form={form}
            configSlotProbe={configSlotProbe}
            pluginsNavigation={pluginsNavigation}
            routeHint={routeHint}
          />
        ),
      ),
    )
  })
}
