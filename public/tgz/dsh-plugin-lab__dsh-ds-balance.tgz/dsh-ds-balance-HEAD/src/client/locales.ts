/**
 * 本地化词典。`zh` 是键集真源，`en` 用 `Record<LocaleKey, string>` 做编译期完整性检查。
 * @module dsh-ds-balance/client/locales
 */

/** 词典命名空间，必须与 slot 注册项的 `locale` 字段一致。 */
export const NS = 'ds-balance'

/** 中文词典（键集真源）。 */
export const zh = {
  'sidebar.label': 'DeepSeek 余额',
  'sidebar.aria.ring': 'DeepSeek 余额状态',
  'sidebar.aria.refresh': '刷新余额',
  'sidebar.aria.mismatch': '显示的币种与你选择的不一致',

  'popover.title': '账户余额',
  // 来源标签：跟着数据来源走。**括号属于词典** —— 中文全角、英文半角带前置空格，
  // 代码里只做拼接，绝不写死括号字符。
  'popover.source.key': '（API Key）',
  'popover.source.account': '（账号登录）',
  'popover.total': '余额',
  'popover.granted': '赠送',
  'popover.toppedUp': '充值',
  'popover.updated': '{value}前',
  'popover.updated.justNow': '刚刚更新',
  'popover.refreshing': '刷新中',
  'popover.cooldown': '{value} 秒后可再次刷新',
  'popover.mismatch': '未找到 {wanted} 余额，当前显示 {shown}',
  'popover.action.useShown': '改用 {shown}',
  // 右上角图标的两档措辞。落点由**宿主能力**决定（跨插件深链服务在不在），
  // 措辞就跟着落点分档：一句含糊的话盖不住两种落点。见 BalancePopover 的 PluginsAction。
  'popover.action.openPlugins': '打开插件页',
  'popover.action.openPluginConfig': '打开插件配置页',

  // 处境文案：**一个处境一句**，环 / 悬停 / 浮层都从这里取。
  // 键名前缀是 situation 而不是 state：后者是契约字段名，而「处境」是界面概念
  // （一个处境可能吃掉多个 state + severity + error 的组合）。
  //
  // **措辞是给用户看的，不是给开发者看的**。这七句会出现在两处，都必须能**单独读懂**：
  // - **悬停气泡**（收起态与展开态同一份，见 `client/situation.ts` 的 `hoverTextOf`）：
  //   数字**可信**时气泡显示金额本身（只有 `ok` / `low` / `critical` 三个处境，
  //   它们的 `textKey` 是 `null`）；其余八个处境显示下面这些句子 —— 包括
  //   `stale` 与 `account-unavailable`，它们**手里有数字也显文案**；
  // - 浮层与读屏的 `aria-label`。
  //
  // 所以每一句都要能单独回答「**这一格现在怎么了**」：
  //
  // - 不写「插件内部错误」：用户不知道也不关心是哪个组件坏了，他要的是「现在拿不到」。
  //   改「服务异常」—— 说的是同一件事，但主语是这个功能，不是我们的代码。
  // - `unavailable` 刻意**不带「暂时」**。它接住的是 `fetch-failed` 那一整片错误码，
  //   里面既有等一等就好的（网络 / 超时 / 429 / 5xx），也有**等不好的**：
  //   `UPSTREAM_401`（key 失效）与 `UPSTREAM_402`（欠费）。对后者说「暂时」是假话，
  //   而且是有害的假话 —— 用户该去改凭据、去充值，不是在原地等。
  //   宁可少说一层时间性，也不能说反。
  'situation.checking': '正在获取',
  'situation.unavailable': '读不到余额',
  'situation.internalError': '服务异常',
  'situation.noCredential': '尚未配置凭据',
  'situation.accountUnavailable': '账户不可用',
  'situation.stale': '数据已过期',
  'situation.emptyWallet': '暂无余额',

  'settings.group.connection': '连接',
  'settings.group.refresh': '刷新',
  'settings.group.display': '展示',
  'settings.group.thresholds': '阈值',
  'settings.field.apiKey': 'API Key',
  'settings.field.apiKeyRef': 'API 密钥引用名',
  'settings.field.baseUrl': '接口地址',
  'settings.field.serverRefreshSeconds': '服务端刷新频率（秒）',
  'settings.field.clientPollSeconds': '客户端轮询频率（秒）',
  'settings.field.manualRefreshCooldownSeconds': '手动刷新冷却（秒）',
  'settings.field.displayCurrency': '显示币种',
  'settings.field.cnyWarn': 'CNY 预警',
  'settings.field.cnyCritical': 'CNY 告急',
  'settings.field.usdWarn': 'USD 预警',
  'settings.field.usdCritical': 'USD 告急',
  'settings.hint.apiKeyRef': '凭据存储里的条目名；非空时优先于 API Key。',
  'settings.hint.baseUrl': '留空则使用提供方默认地址。',
  'settings.hint.displayCurrency': '所选币种不存在时，回落到账户实际持有的币种。',
  'settings.hint.threshold': '后端判定；界面颜色跟随返回的严重度。',
  'settings.hint.thresholdPair': '告急值必须低于预警值',
  'settings.hint.serverRefreshSeconds': '访问官方接口的间隔。',
  'settings.hint.clientPollSeconds': '刷新显示的间隔；正常时只读缓存，读不到时才访问上游。',
  'settings.hint.manualRefreshCooldownSeconds': '两次手动刷新之间的最短间隔。',
  'settings.currency.auto': '自动（跟随账户）',
  // 凭据行的**状态徽章**：两条逐字用官方措辞 —— 取自 ui-settings-plugins 的
  // webSearchApiKeySet / webSearchApiKeyUnset（后者去掉搜索相关的后半句）。
  'settings.credential.configured': '已配置密钥。',
  'settings.credential.notConfigured': '未配置密钥。',
  // 凭据行下方的说明。官方 webSearchApiKeyHint 是一句与状态无关的常量说明，这里照做：
  // 状态由徽章交代，说明只讲字段契约。
  'settings.hint.credential': '不写入设置文件。留空表示保持当前密钥。',
  'settings.group.customized': '自定义设置',
  'settings.test': '测试连接',
  'settings.testing': '测试中…',
  'settings.test.ok': '连接正常。',
  'settings.test.fail': '连接失败：{message}',
  'settings.save': '保存',
  'settings.saving': '保存中…',
  'settings.failed': '保存失败，请重试。',
  'settings.readOnly': '当前配置只读，无法保存修改。',
  'settings.unsaved': '未保存',
  'settings.invalid': '请检查标红的字段。',
  'settings.configured': '已配置',
  'settings.notConfigured': '未配置',
  'settings.overridden': '已覆盖',
  'settings.reset': '重置',
  'settings.invalidNumber': '请填数字；留空表示使用默认值。',
  'settings.hint.refreshAdvanced': '不常改：默认值适用于大多数情况。',
  // 这里曾有一条 'settings.summary'（该行 Configure 子页的说明行）。回退到
  // plugins.bundle.config 之后没有任何渲染路径会问 summary 档，于是连同它一起删了 ——
  // 详见 src/client/index.tsx 的 SettingsSeat。
  // 本轮又删掉四条**孤儿键**（词典里有、全仓没人引用）：`sidebar.aria.balance`
  // （与 sidebar.label 逐字相同，rail 的 aria 走 aria.ring）、`settings.hint.apiKey`
  // （那一行用的是 settings.hint.credential）、`settings.hint.number`
  // （真正用的是 settings.invalidNumber，两者文案原本就重复）、
  // `settings.currencyMismatch`（出到屏幕的是 popover.mismatch）。
} as const

/** 词典键。 */
export type LocaleKey = keyof typeof zh

/** 英文词典。缺键会在编译期报错。 */
export const en: Record<LocaleKey, string> = {
  'sidebar.label': 'DeepSeek balance',
  'sidebar.aria.ring': 'DeepSeek balance status',
  'sidebar.aria.refresh': 'Refresh balance',
  'sidebar.aria.mismatch': 'Shown currency differs from your selection',

  'popover.title': 'Account balance',
  'popover.source.key': ' (API key)',
  'popover.source.account': ' (account sign-in)',
  'popover.total': 'Balance',
  'popover.granted': 'Granted',
  'popover.toppedUp': 'Topped up',
  'popover.updated': '{value} ago',
  'popover.updated.justNow': 'Updated just now',
  'popover.refreshing': 'Refreshing',
  'popover.cooldown': 'Refresh available in {value}s',
  'popover.mismatch': 'No {wanted} balance found; showing {shown}',
  'popover.action.useShown': 'Use {shown}',
  'popover.action.openPlugins': 'Open the Plugins page',
  'popover.action.openPluginConfig': 'Open the plugin configuration page',

  // 与 zh 逐条对应，理由写在 zh 那一段。
  // `unavailable` 同样**不带 Temporarily**：它接住 401（key 失效）/ 402（欠费）这类
  // 「等不好」的错误，说「暂时」会把人劝去干等。
  'situation.checking': 'Loading',
  'situation.unavailable': 'Balance unavailable',
  'situation.internalError': 'Service error',
  'situation.noCredential': 'No credential configured',
  'situation.accountUnavailable': 'Account unavailable',
  'situation.stale': 'Data is stale',
  'situation.emptyWallet': 'No balance',

  'settings.group.connection': 'Connection',
  'settings.group.refresh': 'Refresh',
  'settings.group.display': 'Display',
  'settings.group.thresholds': 'Thresholds',
  'settings.field.apiKey': 'API key',
  'settings.field.apiKeyRef': 'API key reference',
  'settings.field.baseUrl': 'Endpoint',
  'settings.field.serverRefreshSeconds': 'Server refresh (seconds)',
  'settings.field.clientPollSeconds': 'Client poll (seconds)',
  'settings.field.manualRefreshCooldownSeconds': 'Manual refresh cooldown (seconds)',
  'settings.field.displayCurrency': 'Display currency',
  'settings.field.cnyWarn': 'CNY warning',
  'settings.field.cnyCritical': 'CNY critical',
  'settings.field.usdWarn': 'USD warning',
  'settings.field.usdCritical': 'USD critical',
  'settings.hint.apiKeyRef': 'Credential store entry name; takes precedence over the API key.',
  'settings.hint.baseUrl': 'Leave blank to use the provider default.',
  'settings.hint.displayCurrency': 'Falls back to a currency the account actually holds.',
  'settings.hint.threshold': 'Decided on the server; the UI colour follows the returned severity.',
  'settings.hint.thresholdPair': 'Critical must be lower than warning',
  'settings.hint.serverRefreshSeconds': 'How often the official API is called.',
  'settings.hint.clientPollSeconds': 'How often the display refreshes; cache-only while healthy.',
  'settings.hint.manualRefreshCooldownSeconds': 'Minimum gap between two manual refreshes.',
  'settings.currency.auto': 'Automatic (follow account)',
  'settings.credential.configured': 'A key is configured.',
  'settings.credential.notConfigured': 'No key is configured.',
  'settings.hint.credential':
    'Stored outside the settings file. Leave blank to keep the current key.',
  'settings.group.customized': 'Customized settings',
  'settings.test': 'Test connection',
  'settings.testing': 'Testing…',
  'settings.test.ok': 'Connection looks good.',
  'settings.test.fail': 'Connection failed: {message}',
  'settings.save': 'Save',
  'settings.saving': 'Saving…',
  'settings.failed': 'Saving failed. Try again.',
  'settings.readOnly': 'This configuration is read-only.',
  'settings.unsaved': 'Unsaved',
  'settings.invalid': 'Check the highlighted fields.',
  'settings.configured': 'Configured',
  'settings.notConfigured': 'Not configured',
  'settings.overridden': 'Overridden',
  'settings.reset': 'Reset',
  'settings.invalidNumber': 'Enter a number; leave empty to use the default.',
  'settings.hint.refreshAdvanced': 'Rarely changed: the defaults suit most setups.',
  // 与 zh 同批删掉四条孤儿键，以及 `dev.*`（见 zh 那段末尾的说明）。
}

/** 取词典。未知语言回落英文。 */
export function dictionaryFor(language: string): Record<LocaleKey, string> {
  return language.toLowerCase().startsWith('zh') ? zh : en
}

/** 极简插值：把 `{name}` 替换成实参。 */
export function interpolate(template: string, params: Record<string, string>): string {
  return template.replace(/\{(\w+)\}/g, (whole, name: string) =>
    Object.prototype.hasOwnProperty.call(params, name) ? params[name] : whole,
  )
}
