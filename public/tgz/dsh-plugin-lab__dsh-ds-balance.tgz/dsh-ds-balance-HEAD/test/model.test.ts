import { describe, expect, it } from 'vitest'
import type { BalanceResponse } from '../src/client/api-types.ts'
import {
  ageBucket,
  cooldownSecondsOf,
  cooldownUntilOf,
  currencySymbol,
  currentAgeMs,
  dotStateOf,
  formatAmount,
  formatMoney,
  ringRatioOf,
  selectionOf,
} from '../src/client/model.ts'
import { presentationOf } from '../src/client/situation.ts'

/** 造一个响应；只覆写关心的字段。 */
function response(patch: Partial<BalanceResponse> = {}): BalanceResponse {
  return {
    requestId: 'req_test',
    schemaVersion: 1,
    source: 'deepseek-http',
    state: 'ok',
    stale: false,
    fetchedAt: 1_760_000_000_000,
    ageMs: 12_000,
    isAvailable: true,
    accountTag8: 'a1b2c3d4',
    balances: [
      { currency: 'CNY', total: '110.00000000', granted: '10.00000000', toppedUp: '100.00000000' },
    ],
    selected: { currency: 'CNY', total: '110.00000000' },
    severity: 'ok',
    thresholds: { CNY: { warn: '10.00000000', critical: '5.00000000' } },
    todayUsage: null,
    error: null,
    ...patch,
  }
}

describe('dotStateOf', () => {
  it('把 severity 机械映射到五个状态，没有金额判断', () => {
    expect(dotStateOf('ok')).toBe('done')
    expect(dotStateOf('warn')).toBe('warning')
    expect(dotStateOf('critical')).toBe('error')
    expect(dotStateOf('unavailable')).toBe('error')
    expect(dotStateOf('unknown')).toBe('idle')
  })
})

describe('formatAmount / formatMoney', () => {
  it('裁两位、补千分位，全程按字符串走', () => {
    expect(formatAmount('1234567.89000000')).toBe('1,234,567.89')
    expect(formatAmount('110.00000000')).toBe('110')
    expect(formatAmount('-5.50000000')).toBe('-5.50')
  })

  it('未知币种回落成代码本身，不加符号', () => {
    expect(currencySymbol('CNY')).toBe('¥')
    expect(currencySymbol('USD')).toBe('$')
    expect(currencySymbol('JPY')).toBe('')
    expect(formatMoney('12.00000000', 'JPY')).toBe('12')
  })
})

describe('selectionOf', () => {
  it('读后端的 selected，而不是自己挑', () => {
    const value = selectionOf(
      response({
        balances: [
          {
            currency: 'CNY',
            total: '110.00000000',
            granted: '0.00000000',
            toppedUp: '110.00000000',
          },
          { currency: 'USD', total: '20.00000000', granted: '0.00000000', toppedUp: '20.00000000' },
        ],
        // 后端把 USD 排在后面却选了它：顺序不该影响结果。
        selected: { currency: 'USD', total: '20.00000000' },
      }),
      'auto',
    )
    expect(value.shown?.currency).toBe('USD')
    expect(value.shown?.granted).toBe('0.00000000')
    expect(value.matchesPreference).toBe(true)
    expect(value.auto).toBe(true)
    expect(value.empty).toBe(false)
  })

  it('auto 永不报不匹配', () => {
    expect(selectionOf(response(), 'auto').matchesPreference).toBe(true)
    expect(selectionOf(response(), '').matchesPreference).toBe(true)
  })

  it('选定币种与后端选出的不一致时标记不匹配', () => {
    const value = selectionOf(response(), 'USD')
    expect(value.matchesPreference).toBe(false)
    expect(value.shown?.currency).toBe('CNY')
    expect(value.auto).toBe(false)
  })

  it('币种比较不区分大小写', () => {
    expect(selectionOf(response(), 'cny').matchesPreference).toBe(true)
  })

  it('selected 为 null 时是空态', () => {
    const value = selectionOf(
      response({ balances: [], selected: null, severity: 'unknown' }),
      'USD',
    )
    expect(value.shown).toBeNull()
    expect(value.empty).toBe(true)
    expect(value.matchesPreference).toBe(false)
  })

  it('selected 指向 balances 里没有的币种时给 null，不硬凑一条', () => {
    const value = selectionOf(
      response({ selected: { currency: 'EUR', total: '1.00000000' } }),
      'auto',
    )
    expect(value.shown).toBeNull()
    expect(value.empty).toBe(true)
  })
})

describe('ageBucket', () => {
  it('按毫秒差归档，负值与非数归 unknown', () => {
    expect(ageBucket(1_000).bucket).toBe('just-now')
    expect(ageBucket(30_000).bucket).toBe('seconds')
    expect(ageBucket(90_000).bucket).toBe('minutes')
    expect(ageBucket(3 * 3_600_000).bucket).toBe('hours')
    expect(ageBucket(50 * 3_600_000).bucket).toBe('days')
    expect(ageBucket(Number.NaN).bucket).toBe('unknown')
    expect(ageBucket(-1).bucket).toBe('unknown')
  })
})

describe('currentAgeMs', () => {
  it('年龄随时间流逝增长，且不会变成负数', () => {
    expect(currentAgeMs(1_000_000, 12_000, 1_012_000)).toBe(24_000)
    // 两端时钟有偏差时，未来的基准不该算出负年龄。
    expect(currentAgeMs(1_000_000, 0, 999_000)).toBe(0)
  })

  it('换一份新响应就换一次基准 —— 自动轮询必须也能把年龄拨回「刚刚」', () => {
    // 旧基准下过了 60 秒，年龄已经涨到 72 秒。
    expect(currentAgeMs(1_000_000, 12_000, 1_060_000)).toBe(72_000)
    // 同一时刻后端给了新快照（刚抓的，ageMs 0），年龄必须归零重算 ——
    // 这就是「只有手动刷新才动」那条缺陷的判据：基准必须跟着响应走。
    expect(currentAgeMs(1_060_000, 0, 1_060_000)).toBe(0)
    expect(currentAgeMs(1_060_000, 0, 1_061_000)).toBe(1_000)
  })

  it('基准缺失或为负时按 0 算（客户端对宿主形状的防御）', () => {
    expect(currentAgeMs(1_000_000, Number.NaN, 1_005_000)).toBe(5_000)
    expect(currentAgeMs(1_000_000, -1, 1_005_000)).toBe(5_000)
  })
})

/**
 * `ringSpecOf` 已随处境重构退役（形态改由 `client/situation.ts` 的形态表给，那里是全仓唯一的
 * 「处境 → 环/记号/弧」入口）。它保留过一次死代码的教训：**重构后没有任何生产调用方，
 * 却还有一整组测试在守着它** —— 那些断言全绿，守的是一个再也画不到屏幕上的映射。
 * 所以现在守的是**不变量**（下面这组），不是某个中间函数。
 */
describe('形态不变量（跨处境，钉的是「屏幕上不可能出现的组合」）', () => {
  it('**有数字那一族的颜色永远不是 idle**：色与弧都来自真实阈值', () => {
    // 这条是「stopped + 空余额列表」那次缺陷的结构性防线：
    // 只要处境说「有数字」，颜色就必须是绿/琥珀/红之一，绝不能是灰（灰 = 没信息）。
    for (const situation of ['ok', 'low', 'critical', 'stale'] as const) {
      for (const severity of ['ok', 'warn', 'critical'] as const) {
        const p = presentationOf(situation, severity)
        expect(p.ring, `${situation}/${severity}`).not.toBe('idle')
      }
    }
  })

  it('**`account-unavailable` 恒为「红环 + 叉」**：它由 isAvailable=false 判定，与币种无关', () => {
    // 上游对欠费账户可能给空的 balance_infos，那时 severity 曾经是 unknown → 灰环，
    // 与「账户本来就没余额」同形。现在 severityOf 先判 isAvailable，颜色恒红。
    // 叉则是它与「余额恰好为 0」分开的唯一通道（两者其余通道逐值相同）。
    for (const severity of ['ok', 'warn', 'critical', 'unavailable', 'unknown'] as const) {
      const p = presentationOf('account-unavailable', severity)
      expect(p.ring, severity).toBe('error')
      expect(p.marker, severity).toBe('cross')
    }
  })
})

describe('ringRatioOf', () => {
  it('warn 阈值就是坐标轴：余额为零画空环，到 warn 线正好满环', () => {
    expect(ringRatioOf('0.00000000', 5, 'critical')).toBe(0)
    expect(ringRatioOf('5.00000000', 5, 'ok')).toBe(1)
  })

  it('critical 线落在 c/w 上，不重复参与弧长', () => {
    // c = 1、w = 5：critical 线在弧上是 20%，但它只决定颜色，不额外截断弧长。
    expect(ringRatioOf('1.00000000', 5, 'critical')).toBeCloseTo(0.2, 6)
    expect(ringRatioOf('2.50000000', 5, 'warn')).toBeCloseTo(0.5, 6)
  })

  it('超过 warn 线一律封顶满环', () => {
    expect(ringRatioOf('5.00000001', 5, 'ok')).toBe(1)
    expect(ringRatioOf('999999.00000000', 5, 'ok')).toBe(1)
  })

  it('阈值缺失或非正数时退回按 severity 定性', () => {
    const cases = [
      ['ok', 1],
      ['unavailable', 1],
      ['warn', 0.75],
      ['critical', 0.25],
      ['unknown', 0],
    ] as const
    for (const [severity, expected] of cases) {
      expect(ringRatioOf('110.00000000', undefined, severity), severity).toBe(expected)
      expect(ringRatioOf('110.00000000', 0, severity), severity + ' w=0').toBe(expected)
      expect(ringRatioOf('110.00000000', -5, severity), severity + ' w<0').toBe(expected)
    }
  })

  it('没有可展示的币种时也退回定性，而不是当成余额为零', () => {
    expect(ringRatioOf(null, 5, 'unknown')).toBe(0)
    expect(ringRatioOf(null, undefined, 'warn')).toBe(0.75)
  })

  it('负余额画空环，不画成满环', () => {
    expect(ringRatioOf('-1.00000000', 5, 'critical')).toBe(0)
  })

  it('余额为零时环为空，但颜色照样跟着 severity 走', () => {
    // 弧长与配色是两条独立的链：这一条只保证前者不干扰后者。
    expect(ringRatioOf('0.00000000', 5, 'critical')).toBe(0)
    // 颜色链的入口现在是 dotStateOf（形态表内部用它）—— ringSpecOf 已退役。
    expect(dotStateOf('critical')).toBe('error')
    expect(dotStateOf('unknown')).toBe('idle')
  })

  it('金额比较走整数：恰好等于阈值的边界不会因浮点误差漏判', () => {
    // 0.1 + 0.2 那类误差在浮点下会让 v < w，这里必须恰好等于 1。
    expect(ringRatioOf('0.30000000', 0.3, 'ok')).toBe(1)
    expect(ringRatioOf('1.10000000', 1.1, 'ok')).toBe(1)
    expect(ringRatioOf('10.00000000', 3, 'ok')).toBe(1)
  })

  it('形状违约的金额退回定性，不抛错', () => {
    for (const bad of ['', 'abc', '1.2.3', '--1']) {
      expect(ringRatioOf(bad, 5, 'warn'), bad).toBe(0.75)
    }
  })
})

describe('cooldownUntilOf', () => {
  it('这次真的触发了：按配置的秒数', () => {
    expect(cooldownUntilOf(1000, 5, null)).toBe(6000)
  })

  it('后端拒绝：用它给的剩余毫秒，不自己编一段新的', () => {
    expect(cooldownUntilOf(1000, 5, 3200)).toBe(4200)
  })

  it('后端拒绝且它说已经可以了：就没有冷却', () => {
    expect(cooldownUntilOf(1000, 5, 0)).toBe(1000)
  })

  it('负数一律当 0，不产生倒退的截止时刻', () => {
    expect(cooldownUntilOf(1000, -5, null)).toBe(1000)
    expect(cooldownUntilOf(1000, 5, -100)).toBe(1000)
  })
})

describe('cooldownSecondsOf', () => {
  const at = 1_760_000_000_000

  it('同时刻取值：5 秒就是 5，不是 6', () => {
    // 守的是那条真实缺陷：截止是精确时刻，而「现在」是每秒采样一次的旧值，
    // 两者不同刻时 ceil 会凭空多出一秒 —— 显示与按钮禁用都跟着多一秒。
    expect(cooldownSecondsOf(cooldownUntilOf(at, 5, null), at)).toBe(5)
  })

  it('拿旧一刻的采样值去算，就是会多算一秒（所以调用方必须同刻设）', () => {
    expect(cooldownSecondsOf(cooldownUntilOf(at, 5, null), at - 400)).toBe(6)
  })

  it('到点与过点都回 0；没有冷却也回 0', () => {
    const until = cooldownUntilOf(at, 5, null)
    expect(cooldownSecondsOf(until, until)).toBe(0)
    expect(cooldownSecondsOf(until, until + 1)).toBe(0)
    expect(cooldownSecondsOf(0, at)).toBe(0)
  })

  it('未满一秒也算一秒，倒计时不提前归零', () => {
    expect(cooldownSecondsOf(at + 1, at)).toBe(1)
    expect(cooldownSecondsOf(at + 999, at)).toBe(1)
    expect(cooldownSecondsOf(at + 1000, at)).toBe(1)
    expect(cooldownSecondsOf(at + 1001, at)).toBe(2)
  })
})
