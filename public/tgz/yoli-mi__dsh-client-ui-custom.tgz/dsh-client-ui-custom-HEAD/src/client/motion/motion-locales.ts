/** Copy for the 动效 (Motion) settings section. */

/** Dictionary namespace owned by the motion surface. */
export const MOTION_NS = 'motion'

/** All motion section copy keys. */
export type MotionKey =
  | 'nav' | 'title' | 'intro'
  | 'presetTitle' | 'presetDesc'
  | 'presetFluid' | 'presetFluidDesc'
  | 'presetElegant' | 'presetElegantDesc'
  | 'presetMinimal' | 'presetMinimalDesc'
  | 'toggleTitle' | 'toggleDesc'
  | 'styleTitle' | 'styleDesc'
  | 'styleFadeUp' | 'styleFade' | 'styleRiseScale' | 'styleSlideIn' | 'styleBlurIn' | 'styleScaleIn'
  | 'sidebarStyleTitle' | 'sidebarStyleDesc' | 'styleSlideLeft' | 'styleExpand' | 'styleSlideDown'
  | 'sidebarToggleTitle' | 'sidebarToggleDesc'
  | 'selectionToggleTitle' | 'selectionToggleDesc'
  | 'newChatToggleTitle' | 'newChatToggleDesc'
  | 'newChatStyleTitle' | 'newChatStyleDesc'
  | 'styleReveal' | 'styleBloom' | 'styleZoom'
  | 'settingsToggleTitle' | 'settingsToggleDesc'

/** Simplified Chinese copy. */
export const zh: Record<MotionKey, string> = {
  nav: '动效',
  title: '动效',
  intro: '对话内容的入场动效。',
  presetTitle: '预设方案',
  presetDesc: '一键应用整套动效组合，无需逐项调试；应用后仍可自由微调。',
  presetFluid: '流畅',
  presetFluidDesc: '层叠上浮与滑动，明快活泼。',
  presetElegant: '优雅',
  presetElegantDesc: '柔和模糊与绽放，安静高级。',
  presetMinimal: '极简',
  presetMinimalDesc: '仅保留轻微淡入，近乎无感。',
  toggleTitle: '对话入场动效',
  toggleDesc: '载入或切换对话时，消息以动效出现，而不是瞬间跳出；关闭后恢复原生表现。',
  styleTitle: '动效样式',
  styleDesc: '选择对话内容出现的方式（关闭入场动效时不可用）。',
  styleFadeUp: '淡入上浮',
  styleFade: '轻柔淡入',
  styleRiseScale: '上浮放大',
  styleSlideIn: '右侧滑入',
  styleBlurIn: '模糊显影',
  styleScaleIn: '轻盈缩放',
  sidebarToggleTitle: '侧边栏动效',
  sidebarToggleDesc: '打开 Web 时侧边栏树逐项出现，展开工作区时对话框浮现。',
  sidebarStyleTitle: '侧边栏动效样式',
  sidebarStyleDesc: '侧边栏会话树的出现方式，与对话动效独立选择。',
  styleSlideLeft: '左侧滑入',
  styleExpand: '纵向展开',
  styleSlideDown: '自上而下',
  selectionToggleTitle: '选中框动效',
  selectionToggleDesc: '切换对话时，当前会话行描出常驻的选中框。',
  newChatToggleTitle: '新建对话动效',
  newChatToggleDesc: '新建对话时，欢迎界面和输入区淡入出现。',
  newChatStyleTitle: '新建对话动效样式',
  newChatStyleDesc: '新建对话时欢迎界面的出现方式。',
  styleReveal: '轻柔显影',
  styleBloom: '柔和绽放',
  styleZoom: '柔和缩放',
  settingsToggleTitle: '设置界面动效',
  settingsToggleDesc: '打开设置时面板从左下角向中间扩张，切换左侧标签时高亮与页面内容淡入；关闭后立即出现。',
}

/** English copy. */
export const en: Record<MotionKey, string> = {
  nav: 'Motion',
  title: 'Motion',
  intro: 'Entrance motion for conversation content.',
  presetTitle: 'Presets',
  presetDesc: 'Apply a complete motion combo in one click — no per-option tuning; every value stays editable afterwards.',
  presetFluid: 'Fluid',
  presetFluidDesc: 'Cascading rise and slide — bright and lively.',
  presetElegant: 'Elegant',
  presetElegantDesc: 'Soft blur and bloom — quiet and refined.',
  presetMinimal: 'Minimal',
  presetMinimalDesc: 'Barely-there fades only — almost imperceptible.',
  toggleTitle: 'Conversation entrance motion',
  toggleDesc: 'Messages arrive with a motion effect when a conversation loads or switches, instead of popping in at once; off = stock behavior.',
  styleTitle: 'Motion style',
  styleDesc: 'How conversation content arrives (unavailable while entrance motion is off).',
  styleFadeUp: 'Fade up',
  styleFade: 'Gentle fade',
  styleRiseScale: 'Rise & scale',
  styleSlideIn: 'Slide in',
  styleBlurIn: 'Blur in',
  styleScaleIn: 'Gentle scale',
  sidebarToggleTitle: 'Sidebar motion',
  sidebarToggleDesc: 'The sidebar tree cascades in on web load; workspace rows fade in when their group expands.',
  sidebarStyleTitle: 'Sidebar motion style',
  sidebarStyleDesc: 'How the sidebar session tree arrives — independent of the transcript style.',
  styleSlideLeft: 'Slide in from left',
  styleExpand: 'Expand',
  styleSlideDown: 'Drop in',
  selectionToggleTitle: 'Selection box',
  selectionToggleDesc: 'Trace a persistent selection box on the active conversation row when switching.',
  newChatToggleTitle: 'New conversation motion',
  newChatToggleDesc: "A brand-new conversation's welcome dialog and composer fade in.",
  newChatStyleTitle: 'New conversation style',
  newChatStyleDesc: 'How the welcome dialog of a brand-new conversation arrives.',
  styleReveal: 'Soft reveal',
  styleBloom: 'Gentle bloom',
  styleZoom: 'Soft zoom',
  settingsToggleTitle: 'Settings motion',
  settingsToggleDesc: 'The settings dialog expands from the lower-left, nav highlight and page content fade in on switch; off = instant appearance.',
}

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The motion settings-section copy. */
    motion: MotionKey
  }
}
