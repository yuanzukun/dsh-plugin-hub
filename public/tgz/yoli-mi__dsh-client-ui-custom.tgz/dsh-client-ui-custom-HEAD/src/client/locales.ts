/** Locale dictionaries for the shortcuts settings section. */

/** Dictionary namespace owned by ui-custom's settings section. */
export const NS = 'shortcuts'

/** All section copy keys. */
export type ShortcutsKey =
  | 'nav' | 'title' | 'intro'
  | 'newConversation' | 'switchModel' | 'cycleThinking' | 'sendMessage' | 'newline' | 'usagePanel'
  | 'defaultWorkspaceTitle' | 'defaultWorkspaceDesc' | 'defaultWorkspaceNone'
  | 'modelShortcutTitle' | 'modelShortcutDesc' | 'modelShortcutEmpty'
  | 'modelShortcutAdd' | 'modelShortcutRemove' | 'modelShortcutPickTarget'
  | 'modelCatalogEmpty' | 'modelCatalogUnavailable'
  | 'comboHint' | 'record' | 'reset' | 'save' | 'saving' | 'dirty'
  | 'unavailable' | 'unavailableHint'

/** Simplified Chinese copy. */
export const zh: Record<ShortcutsKey, string> = {
  nav: '快捷键',
  title: '快捷键',
  intro: '自定义键盘快捷键：新建对话、切换模型、切换思考强度、呼出应用用量面板，以及聊天输入框的发送与换行手势。组合键语法：Mod 代表 Ctrl 或 Meta（Mac 的 Command），例如 Mod+Alt+N。发送默认 Enter、换行默认 Shift+Enter——习惯 Enter 换行的可以把发送改为 Mod+Enter、换行改为 Enter。',
  newConversation: '新建对话',
  switchModel: '切换模型',
  cycleThinking: '切换思考强度',
  sendMessage: '发送消息',
  newline: '换行',
  usagePanel: '呼出用量',
  defaultWorkspaceTitle: '默认工作区',
  defaultWorkspaceDesc: '「新建对话」快捷键在此工作区创建会话；不指定则沿用当前会话的工作区。',
  defaultWorkspaceNone: '不指定',
  modelShortcutTitle: '模型快捷键',
  modelShortcutDesc: '为特定模型绑定快捷键，按下即切换过去（每个快捷键对应一个模型）。',
  modelShortcutEmpty: '尚未添加模型快捷键。点击「添加模型快捷键」后，录制组合键并选择目标模型。',
  modelShortcutAdd: '添加模型快捷键',
  modelShortcutRemove: '删除该绑定',
  modelShortcutPickTarget: '选择目标模型',
  modelCatalogEmpty: '当前会话没有可用的模型目录，无法选择目标模型。',
  modelCatalogUnavailable: '模型目录加载失败。',
  comboHint: '点击后按下组合键…',
  record: '录制快捷键',
  reset: '恢复默认',
  save: '保存',
  saving: '保存中…',
  dirty: '有未保存的修改',
  unavailable: '快捷键设置当前不可用',
  unavailableHint: '连接处于内存模式或该命名空间未对浏览器暴露。',
}

/** English copy. */
export const en: Record<ShortcutsKey, string> = {
  nav: 'Shortcuts',
  title: 'Keyboard Shortcuts',
  intro: 'Custom keyboard shortcuts: new conversation, next model, thinking-effort cycling, the app-usage panel, plus the composer send/newline gestures. Combo syntax: Mod means Ctrl or Meta (Cmd on macOS), e.g. Mod+Alt+N. Send defaults to Enter and newline to Shift+Enter — if you prefer Enter to insert a newline, set send to Mod+Enter and newline to Enter.',
  newConversation: 'New conversation',
  switchModel: 'Switch model',
  cycleThinking: 'Cycle thinking effort',
  sendMessage: 'Send message',
  newline: 'Newline',
  usagePanel: 'Open usage',
  defaultWorkspaceTitle: 'Default workspace',
  defaultWorkspaceDesc: 'The "new conversation" shortcut opens a session in this workspace; unset inherits the current session\'s workspace.',
  defaultWorkspaceNone: 'Unset',
  modelShortcutTitle: 'Model shortcuts',
  modelShortcutDesc: 'Bind a key combo to a specific model; pressing it switches to that model directly.',
  modelShortcutEmpty: 'No model shortcuts yet. Click "Add model shortcut", record a combo, and pick the target model.',
  modelShortcutAdd: 'Add model shortcut',
  modelShortcutRemove: 'Remove this binding',
  modelShortcutPickTarget: 'Pick a target model',
  modelCatalogEmpty: 'The current session has no model catalog to pick from.',
  modelCatalogUnavailable: 'The model catalog failed to load.',
  comboHint: 'Click, then press the combination…',
  record: 'Record shortcut',
  reset: 'Reset',
  save: 'Save',
  saving: 'Saving…',
  dirty: 'Unsaved changes',
  unavailable: 'Shortcut settings are unavailable',
  unavailableHint: 'The connection is in memory mode, or the namespace is not exposed to the browser.',
}

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The shortcuts settings section copy. */
    shortcuts: ShortcutsKey
  }
}
