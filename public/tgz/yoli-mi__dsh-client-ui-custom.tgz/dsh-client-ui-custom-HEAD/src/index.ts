/**
 * Web-surface theme plugin, node half: registers the runtime-editable
 * settings section (theme "外观" + shortcuts "快捷键" pages) so the browser
 * scope can read/write it. The theme itself is pure browser work.
 */
import type { Context } from '@deepseek-ai/cordis'
import { settingsNamespace } from '@deepseek-ai/dsh-settings'
import z from '@deepseek-ai/schemastery'
import {
  DEFAULT_HISTORY_LIMIT, DEFAULT_HISTORY_POSITION, DEFAULT_MOTION_STYLE, DEFAULT_NEW_CHAT_MOTION_STYLE,
  DEFAULT_SIDEBAR_MOTION_STYLE, FEATURES, HISTORY_POSITIONS, isMotionStyle, isNewChatMotionStyle,
  isSidebarMotionStyle, MOTION_STYLES, NEW_CHAT_MOTION_STYLES, SIDEBAR_MOTION_STYLES, UI_CUSTOM_SETTINGS_NS,
} from './shared.ts'
import type { ShortcutConfig } from './client/config.ts'
import type { HistoryPosition, MotionStyle, NewChatMotionStyle, PluginFeature, SidebarMotionStyle, ThemeSection } from './shared.ts'

/** The full ui-custom section schema (schemastery defaults = the plugin's neutral defaults). */
const UiCustomSectionSchema = z.object({
  // theme
  wallpaper: z.string().default(''),
  glass: z.string().default('frosted'),
  accent: z.string().default('#4176e6'),
  autoAccent: z.boolean().default(false),
  surfaceOpacity: z.number().default(100),
  sidebarOpacity: z.number().default(100),
  chatSurfaceOpacity: z.number().default(100),
  inputOpacity: z.number().default(100),
  codeBlockOpacity: z.number().default(100),
  darkSurfaceOpacity: z.number().default(100),
  gradient: z.string().default(''),
  darkScrim: z.number().default(0),
  fontFamily: z.string().default(''),
  codeFontFamily: z.string().default(''),
  fontScale: z.number().default(1),
  scrollbarAccent: z.boolean().default(false),
  vignette: z.boolean().default(false),
  // opt-in refinement knobs (neutral defaults: the plugin changes nothing)
  cornerRadius: z.string().default('inherit'),
  surfaceShadow: z.string().default('inherit'),
  focusGlow: z.string().default('inherit'),
  wallpaperTone: z.string().default('inherit'),
  darkAccent: z.string().default(''),
  // user's own presets: id → JSON string of { name, config }
  myPresets: z.dict(z.string()).default({}),
  // render the user's own messages as Markdown (General-settings toggle)
  renderUserMarkdown: z.boolean().default(false),
  // conversation entrance motion (动效 settings-section toggle + styles)
  motionEnabled: z.boolean().default(true),
  motionStyle: z.union([...MOTION_STYLES]).default(DEFAULT_MOTION_STYLE),
  sidebarMotionStyle: z.union([...SIDEBAR_MOTION_STYLES]).default(DEFAULT_SIDEBAR_MOTION_STYLE),
  sidebarMotionEnabled: z.boolean().default(true),
  selectionMotionEnabled: z.boolean().default(true),
  newChatMotionEnabled: z.boolean().default(true),
  newChatMotionStyle: z.union([...NEW_CHAT_MOTION_STYLES]).default(DEFAULT_NEW_CHAT_MOTION_STYLE),
  settingsMotionEnabled: z.boolean().default(true),
  // shortcuts
  newConversation: z.string().default(''),
  switchModel: z.string().default(''),
  cycleThinking: z.string().default(''),
  sendMessage: z.string().default('Enter'),
  newline: z.string().default('Shift+Enter'),
  usagePanel: z.string().default(''),
  defaultWorkspace: z.string().default(''),
  modelShortcuts: z.array(z.object({
    combo: z.string().default(''),
    provider: z.string().default(''),
    model: z.string().default(''),
  })).default([]),
  // history strip: recent-turns limit (0 = show all) + side (left/right/off)
  historyLimit: z.number().default(DEFAULT_HISTORY_LIMIT),
  historyPosition: z.union([...HISTORY_POSITIONS]).default(DEFAULT_HISTORY_POSITION),
  // pinned turns per session (turn numbers that ignore the count limit)
  pinnedTurns: z.dict(z.array(z.number())).default({}),
  // marketplace catalog source(s): raw manifest URL(s) / GitHub repo URL(s)
  marketplaceUrl: z.string().default(''),
  // auto-discover dsh-plugin topic repos from GitHub (merged after sources)
  discoverGitHub: z.boolean().default(false),
  // discovery sort (stars / publish date) and how many entries to show
  discoverSort: z.union(['stars', 'date']).default('stars'),
  discoverLimit: z.number().default(30),
  // feature whitelist: which independently selectable features mount on the
  // web client (absent/empty = all; see resolveFeatures on the client side)
  features: z.array(z.union([...FEATURES])).default([]),
})

/** Plugin config shape accepted at the loader layer (flat theme + nested shortcuts). */
interface UiCustomConfig extends Partial<ThemeSection> {
  /**
   * Feature whitelist: which independently selectable features to mount
   * (history / markdown / appearance / marketplace / shortcuts / usage /
   * motion). Absent or empty = every feature (backward compatible); present =
   * only the listed features register on the web client.
   */
  features?: readonly PluginFeature[]
  shortcuts?: Partial<ShortcutConfig>
  /** History strip recent-turns limit (0 = show all). */
  historyLimit?: number
  /** History strip side ('left' / 'right') or hidden ('off'). */
  historyPosition?: HistoryPosition
  /** Pinned turn numbers per session (ignore the strip's count limit). */
  pinnedTurns?: Record<string, number[]>
  /** Conversation entrance motion (default true). */
  motionEnabled?: boolean
  /** Conversation entrance-motion style (default 'fade-up'). */
  motionStyle?: MotionStyle
  /** Sidebar entrance-motion style (default 'slide-left'). */
  sidebarMotionStyle?: SidebarMotionStyle
  /** Sidebar motion (initial tree + group expand), default true. */
  sidebarMotionEnabled?: boolean
  /** Persistent selection-box trace on the active row, default true. */
  selectionMotionEnabled?: boolean
  /** Blank-session (new conversation) entrance, default true. */
  newChatMotionEnabled?: boolean
  /** Blank-session entrance style (default 'reveal'). */
  newChatMotionStyle?: NewChatMotionStyle
  /** Settings-panel motion (dialog expansion, nav highlight, page switch), default true. */
  settingsMotionEnabled?: boolean
  /**
   * Marketplace catalog source(s): raw manifest JSON URL(s) and/or GitHub
   * repo URL(s), comma/newline separated. Seeded into the settings namespace
   * so the browser scope can read it.
   */
  marketplaceUrl?: string
  /** Auto-discover `dsh-plugin` topic repos from GitHub (default true). */
  discoverGitHub?: boolean
  /** Discovery sort: 'stars' (default) or 'date' (publish date, recent first). */
  discoverSort?: 'stars' | 'date'
  /** How many discovered entries to show (default 30). */
  discoverLimit?: number
}

/**
 * Host plugin body: expose the ui-custom settings namespace to the web
 * client when the settings service is composed. The namespace's composition
 * base carries the loader config (flat theme fields + nested shortcuts), so a
 * cleared field reverts to the loader default and the settings pages layer on
 * top of it.
 * @param ctx - Host context that may acquire the settings service.
 * @param config - the plugin's loader-layer config.
 */
export function apply(ctx: Context, config?: UiCustomConfig): void {
  ctx.inject(['settings'], (settingsCtx) => {
    const shortcuts = config?.shortcuts
    settingsCtx.settings.register(settingsNamespace(UI_CUSTOM_SETTINGS_NS), UiCustomSectionSchema, {
      base: {
        wallpaper: config?.wallpaper ?? '',
        glass: config?.glass ?? 'frosted',
        accent: config?.accent ?? '#4176e6',
        autoAccent: config?.autoAccent ?? false,
        surfaceOpacity: config?.surfaceOpacity ?? 100,
        sidebarOpacity: config?.sidebarOpacity ?? 100,
        chatSurfaceOpacity: config?.chatSurfaceOpacity ?? 100,
        inputOpacity: config?.inputOpacity ?? 100,
        codeBlockOpacity: config?.codeBlockOpacity ?? 100,
        darkSurfaceOpacity: config?.darkSurfaceOpacity ?? 100,
        gradient: config?.gradient ?? '',
        darkScrim: config?.darkScrim ?? 0,
        fontFamily: config?.fontFamily ?? '',
        codeFontFamily: config?.codeFontFamily ?? '',
        fontScale: config?.fontScale ?? 1,
        scrollbarAccent: config?.scrollbarAccent ?? false,
        vignette: config?.vignette ?? false,
        cornerRadius: config?.cornerRadius ?? 'inherit',
        surfaceShadow: config?.surfaceShadow ?? 'inherit',
        focusGlow: config?.focusGlow ?? 'inherit',
        wallpaperTone: config?.wallpaperTone ?? 'inherit',
        darkAccent: config?.darkAccent ?? '',
        myPresets: config?.myPresets ?? {},
        renderUserMarkdown: config?.renderUserMarkdown ?? false,
        motionEnabled: config?.motionEnabled ?? true,
        motionStyle: isMotionStyle(config?.motionStyle) ? config.motionStyle : DEFAULT_MOTION_STYLE,
        sidebarMotionStyle: isSidebarMotionStyle(config?.sidebarMotionStyle)
          ? config.sidebarMotionStyle
          : DEFAULT_SIDEBAR_MOTION_STYLE,
        sidebarMotionEnabled: config?.sidebarMotionEnabled ?? true,
        selectionMotionEnabled: config?.selectionMotionEnabled ?? true,
        newChatMotionEnabled: config?.newChatMotionEnabled ?? true,
        newChatMotionStyle: isNewChatMotionStyle(config?.newChatMotionStyle)
          ? config.newChatMotionStyle
          : DEFAULT_NEW_CHAT_MOTION_STYLE,
        settingsMotionEnabled: config?.settingsMotionEnabled ?? true,
        newConversation: shortcuts?.newConversation ?? '',
        switchModel: shortcuts?.switchModel ?? '',
        cycleThinking: shortcuts?.cycleThinking ?? '',
        sendMessage: shortcuts?.sendMessage ?? 'Enter',
        newline: shortcuts?.newline ?? 'Shift+Enter',
        usagePanel: shortcuts?.usagePanel ?? '',
        defaultWorkspace: shortcuts?.defaultWorkspace ?? '',
        modelShortcuts: shortcuts?.modelShortcuts ?? [],
        historyLimit: config?.historyLimit ?? DEFAULT_HISTORY_LIMIT,
        historyPosition: config?.historyPosition ?? DEFAULT_HISTORY_POSITION,
        pinnedTurns: config?.pinnedTurns ?? {},
        marketplaceUrl: config?.marketplaceUrl ?? '',
        discoverGitHub: config?.discoverGitHub ?? false,
        discoverSort: config?.discoverSort ?? 'stars',
        discoverLimit: config?.discoverLimit ?? 30,
        features: config?.features ? [...config.features] : [],
      },
    })
  })
}
