# dsh-cron-job

dsh-cron-job 是 DeepSeek Harness 的定时任务与通讯插件。你可以让模型帮你创建定时任务，并把结果发送到微信、飞书、钉钉、企业微信、QQ、Slack、Telegram、Discord 或 WhatsApp。

[English](README.en.md)

## 使用要求

- 已安装 DeepSeek Harness。
- Node.js 版本不低于 22.19。
- 至少准备一个可用的 DSH 模型。
- 如需推送消息，请准备对应平台的机器人或账号。

## 安装

安装程序默认把插件装到 `web` profile。它会替换已安装的旧版 dsh-im 通讯插件，并保留原有渠道配置和凭据引用。

macOS 或 Linux：

```sh
npx -y github:upJiang/dsh-cron-job install
```

Windows PowerShell：

```powershell
npx -y github:upJiang/dsh-cron-job install
```

安装完成后，停止正在运行的 DSH，再重新启动：

```sh
dsh web --host 127.0.0.1 --port 3080
```

然后刷新浏览器，打开 `http://127.0.0.1:3080/`。

## 连接通讯账号

1. 打开 DSH 设置中的“通讯账号”。
2. 选择微信、飞书、钉钉、企业微信、QQ、Slack、Telegram、Discord 或 WhatsApp。
3. 按页面提示扫码或填写平台凭据。
4. 完成连接测试，并先在目标会话中给机器人发送一条消息。

各设备的账号配置独立保存。插件不会在设备之间同步密钥、Token、登录状态或聊天记录。

微信主动推送依赖最近一次私聊的回复上下文。首次安装或从旧版本升级后，请先给微信机器人发送一条新私聊，再执行连接测试或创建微信推送任务。

## 创建定时任务

1. 打开 DSH 设置中的“定时任务”。
2. 用自然语言描述任务，例如执行时间、要读取的内容和推送位置。
   也可以载入 Product Hunt + GitHub Trending 示例，再直接修改或删除其中任意内容。
3. 选择工作区、模型和推送目标，然后生成草稿。
4. 检查时间、时区、提示词、工具权限和通知目标。
5. 点击“测试并创建”。
6. 等待工作区、模型、Agent、数据源和全部通知目标完成真实测试。
7. 测试全部通过后，点击“确认并启用”。

测试消息会带有“定时任务创建测试”标记。只要有一个检查或推送目标失败，任务就不会创建。

## 处理测试失败

页面会显示失败位置和原因：

- 工作区失败时，重新选择可访问的目录，并检查目录权限。
- 模型失败时，更换 Provider 或模型，或到对应设置中补充 API Key。
- Agent 或数据源失败时，修改提示词、网址、认证配置或工具权限。
- 推送失败时，重新连接账号、补充平台凭据、选择其他会话或移除失败目标。

修改计划、时区、工作区、提示词、模型、工具权限或推送目标后，需要重新完成测试。

如果网站只能通过代理访问，插件会优先使用 `HTTP_PROXY`、`HTTPS_PROXY` 和 `NO_PROXY`。未设置这些环境变量时，插件会读取 macOS 或 Windows 当前用户的系统代理；它只读取配置，不会修改系统代理。

## 管理任务

在“定时任务”页面可以搜索和筛选任务，查看下次执行时间与运行历史，也可以编辑、暂停、恢复、立即运行、取消运行或删除任务。

每次运行使用独立的 DSH Session。同一个任务不会并发执行。DSH 关闭期间错过的任务不会补跑。

## 卸载

macOS、Linux 或 Windows PowerShell 都可以执行：

```sh
dsh plugin --profile web remove dsh-cron-job
```

卸载后重新启动 DSH，并刷新浏览器。

## 本地开发安装

在插件源码目录执行：

```sh
node bin/dsh-cron-job.mjs install --source .
```

安装完成后重新启动 DSH。
