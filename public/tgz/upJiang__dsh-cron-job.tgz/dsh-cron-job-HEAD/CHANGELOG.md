# Changelog / 更新日志

本文件记录 `dsh-cron-job` 的重要变化。格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，版本号遵循 [Semantic Versioning](https://semver.org/lang/zh-CN/)。

This file records notable changes to `dsh-cron-job`. It follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [0.1.0] - 2026-08-27

### Added / 新增

- 新增模型驱动的定时任务草稿、完整试运行、确认门禁、调度、运行历史和多渠道投递。
  Added model-assisted job drafts, full preflight runs, confirmation gates, scheduling, run history, and multi-channel delivery.
- 新增 cron、单次时间和固定间隔三种时区感知的调度规则，并在重启后跳过错过的执行。
  Added timezone-aware cron, one-time, and fixed-interval schedules with missed runs skipped after restart.
- 新增独立的定时任务管理页面，支持自然语言创建、编辑、搜索、筛选、分页、暂停、恢复、立即运行、取消和删除。
  Added a dedicated job management page with natural-language creation, editing, search, filters, pagination, pause, resume, run-now, cancellation, and deletion.
- 新增 12 个模型工具，所有创建和关键配置更新均复用 Host 的完整试运行门禁。
  Added 12 model tools; creation and critical configuration updates share the Host-enforced full preflight gate.
- 集成微信、飞书、钉钉、企业微信、QQ、Slack、Telegram、Discord 和 WhatsApp 的双向通讯、账号管理、流式回复、图片和文件能力。
  Integrated bidirectional messaging, account management, streaming replies, images, and files for WeChat, Feishu, DingTalk, WeCom, QQ, Slack, Telegram, Discord, and WhatsApp.
- 新增 macOS、Windows 和 Linux CI，以及跨平台路径和工作区处理。
  Added macOS, Windows, and Linux CI with cross-platform path and workspace handling.

### Security / 安全

- 任务只有在工作区、模型、Agent、数据源和全部通知目标的真实试运行均成功后才能确认；关键配置或凭据引用版本变化会使测试失效。
  Jobs can be confirmed only after successful real preflight checks for the workspace, model, agent, sources, and every notification target; critical configuration or credential-reference changes invalidate the test.
- 定时任务禁止 Shell、Node、Python、PowerShell 和其他未授权外部写操作；凭据仅通过 DSH credentials provider 管理，不进入任务记录或模型上下文。
  Scheduled jobs block Shell, Node, Python, PowerShell, and unauthorized external writes; credentials remain in the DSH credentials provider and never enter job records or model context.
- 微信主动推送只使用最近一次经过 owner 私聊授权且收件人完全匹配的路由；敏感上下文令牌仅保存在权限为 `0600` 的 Host 状态文件中。
  Proactive WeChat delivery uses only the latest owner-authorized direct-message route with an exact recipient match; the sensitive context token remains solely in a Host state file with `0600` permissions.

### Removed / 移除

- 不包含 AI Office Connector，也不依赖 `@xmanrui/dsh-im`。
  The plugin does not include AI Office Connector and does not depend on `@xmanrui/dsh-im`.
