function invalidRoute(message, code = 'current-conversation-unavailable') {
  const error = new Error(message);
  error.code = code;
  return error;
}

function text(value) {
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

function notificationRecipient(channel, value) {
  switch (channel) {
    case 'weixin': {
      const toUserId = text(value?.toUserId);
      return toUserId ? { toUserId } : null;
    }
    case 'feishu': {
      const receiveId = text(value?.receiveId ?? value?.chatId);
      return receiveId ? { receiveIdType: 'chat_id', receiveId } : null;
    }
    case 'dingtalk':
      return null;
    case 'wecom': {
      const chatId = text(value?.chatId);
      return chatId ? { chatId } : null;
    }
    case 'qq': {
      const targetId = text(value?.targetId);
      const scope = value?.scope === 'group' ? 'group' : 'c2c';
      return targetId ? { scope, targetId } : null;
    }
    case 'slack': {
      const channelId = text(value?.channelId);
      return channelId ? { channelId } : null;
    }
    case 'telegram': {
      const chatId = text(value?.chatId);
      return chatId ? { chatId } : null;
    }
    case 'discord': {
      const channelId = text(value?.channelId);
      return channelId ? { channelId } : null;
    }
    case 'whatsapp': {
      const jid = text(value?.jid);
      return jid ? { jid } : null;
    }
    default:
      throw invalidRoute(`Unsupported current conversation channel: ${channel}`);
  }
}

function normalizeRoute(route) {
  const sessionId = text(route?.sessionId);
  const channel = text(route?.channel);
  const botId = text(route?.botId);
  if (!sessionId || !channel || !botId) {
    throw invalidRoute('The current communication session cannot be identified');
  }
  const recipient = notificationRecipient(channel, route.recipient);
  if (channel !== 'dingtalk' && !recipient) {
    throw invalidRoute('The current communication target cannot be identified');
  }
  return Object.freeze({
    sessionId,
    channel,
    botId,
    ...(recipient ? { recipient: Object.freeze(recipient) } : {}),
  });
}

function sameTarget(left, right) {
  return left.channel === right.channel
    && left.botId === right.botId
    && JSON.stringify(left.recipient ?? null) === JSON.stringify(right.recipient ?? null);
}

export class ConversationRouteRegistry {
  #routes = new Map();

  async run(route, operation) {
    if (typeof operation !== 'function') throw new TypeError('conversation route operation is required');
    const normalized = normalizeRoute(route);
    const token = Symbol('conversation-route');
    const active = this.#routes.get(normalized.sessionId) ?? new Map();
    active.set(token, normalized);
    this.#routes.set(normalized.sessionId, active);
    try {
      return await operation();
    } finally {
      active.delete(token);
      if (active.size === 0 && this.#routes.get(normalized.sessionId) === active) {
        this.#routes.delete(normalized.sessionId);
      }
    }
  }

  resolve(sessionId) {
    const id = text(sessionId);
    const active = id ? this.#routes.get(id) : null;
    if (!active?.size) {
      throw invalidRoute(
        'No active communication conversation is associated with this DSH Session',
      );
    }
    const unique = [];
    for (const route of active.values()) {
      if (!unique.some((candidate) => sameTarget(candidate, route))) unique.push(route);
    }
    if (unique.length !== 1) {
      throw invalidRoute(
        'More than one active communication conversation is associated with this DSH Session',
        'current-conversation-ambiguous',
      );
    }
    const route = unique[0];
    return {
      channel: route.channel,
      botId: route.botId,
      ...(route.recipient ? { recipient: structuredClone(route.recipient) } : {}),
    };
  }
}
