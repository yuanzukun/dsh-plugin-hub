export function createDeadline(timeoutMs, signal) {
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1) {
    throw new TypeError('timeoutMs must be a positive integer');
  }
  const controller = new AbortController();
  const timer = setTimeout(() => {
    controller.abort(new DOMException('The operation timed out', 'TimeoutError'));
  }, timeoutMs);
  return {
    signal: signal ? AbortSignal.any([signal, controller.signal]) : controller.signal,
    timeoutSignal: controller.signal,
    dispose() { clearTimeout(timer); },
  };
}
