import { mkdir, readFile, rename, unlink, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';

const EMPTY_STATE = Object.freeze({
  version: 2,
  sessions: {},
  seenMessageIds: [],
  getUpdatesBuf: '',
  privateRoute: null,
});

const MAX_WEIXIN_USER_ID_LENGTH = 512;
const MAX_WEIXIN_CONTEXT_TOKEN_LENGTH = 4_096;

function normalizeWeixinUserId(value) {
  const text = typeof value === 'string' ? value.trim() : '';
  return text.length <= MAX_WEIXIN_USER_ID_LENGTH
    && /^[A-Za-z0-9@._:-]+$/u.test(text)
    ? text
    : null;
}

function normalizeWeixinContextToken(value) {
  const text = typeof value === 'string' ? value.trim() : '';
  return text.length <= MAX_WEIXIN_CONTEXT_TOKEN_LENGTH
    && /^[\x21-\x7e]+$/u.test(text)
    ? text
    : null;
}

function normalizePrivateRoute(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const toUserId = normalizeWeixinUserId(value.toUserId);
  const contextToken = normalizeWeixinContextToken(value.contextToken);
  const updatedAt = typeof value.updatedAt === 'string' && value.updatedAt.length <= 64
    && Number.isFinite(Date.parse(value.updatedAt))
    ? new Date(value.updatedAt).toISOString()
    : null;
  return toUserId && contextToken && updatedAt
    ? { toUserId, contextToken, updatedAt }
    : null;
}

function normalizeState(value) {
  if (!value || typeof value !== 'object') return structuredClone(EMPTY_STATE);
  const sessions = {};
  if (value.sessions && typeof value.sessions === 'object' && !Array.isArray(value.sessions)) {
    for (const [key, sessionId] of Object.entries(value.sessions)) {
      if (typeof key === 'string' && typeof sessionId === 'string' && sessionId) {
        sessions[key] = sessionId;
      }
    }
  }
  return {
    version: 2,
    sessions,
    seenMessageIds: Array.isArray(value.seenMessageIds)
      ? value.seenMessageIds.filter((id) => typeof id === 'string').slice(-1_000)
      : [],
    getUpdatesBuf: typeof value.getUpdatesBuf === 'string' ? value.getUpdatesBuf : '',
    privateRoute: normalizePrivateRoute(value.privateRoute),
  };
}

export class WeixinStateStore {
  #path;
  #state = structuredClone(EMPTY_STATE);
  #writeQueue = Promise.resolve();

  constructor(path) {
    this.#path = path;
  }

  async load() {
    try {
      const persisted = JSON.parse(await readFile(this.#path, 'utf8'));
      this.#state = normalizeState(persisted);
      if (JSON.stringify(persisted) !== JSON.stringify(this.#state)) await this.#persist();
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error;
      this.#state = structuredClone(EMPTY_STATE);
      await this.#persist();
    }
    return this;
  }

  sessionFor(key) {
    return this.#state.sessions[key] ?? null;
  }

  async setSession(key, sessionId) {
    this.#state.sessions[key] = sessionId;
    await this.#persist();
  }

  async clearSession(key) {
    delete this.#state.sessions[key];
    await this.#persist();
  }

  async clearSessions() {
    this.#state.sessions = {};
    await this.#persist();
  }

  hasSeen(messageId) {
    return this.#state.seenMessageIds.includes(messageId);
  }

  async markSeen(messageId) {
    if (this.hasSeen(messageId)) return;
    this.#state.seenMessageIds.push(messageId);
    if (this.#state.seenMessageIds.length > 1_000) {
      this.#state.seenMessageIds.splice(0, this.#state.seenMessageIds.length - 1_000);
    }
    await this.#persist();
  }

  getUpdatesBuf() {
    return this.#state.getUpdatesBuf;
  }

  async setGetUpdatesBuf(value) {
    if (typeof value !== 'string' || value === this.#state.getUpdatesBuf) return;
    this.#state.getUpdatesBuf = value;
    await this.#persist();
  }

  async rememberPrivateRoute({ toUserId, contextToken, updatedAt = new Date().toISOString() } = {}) {
    const route = normalizePrivateRoute({ toUserId, contextToken, updatedAt });
    if (!route) throw new TypeError('Invalid Weixin private route');
    if (JSON.stringify(route) === JSON.stringify(this.#state.privateRoute)) return;
    this.#state.privateRoute = route;
    await this.#persist();
  }

  privateRouteFor(toUserId) {
    const normalized = normalizeWeixinUserId(toUserId);
    return normalized && normalized === this.#state.privateRoute?.toUserId
      ? structuredClone(this.#state.privateRoute)
      : null;
  }

  snapshot() {
    const { privateRoute: _privateRoute, ...safe } = this.#state;
    return structuredClone(safe);
  }

  async remove() {
    try {
      await unlink(this.#path);
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error;
    }
    this.#state = structuredClone(EMPTY_STATE);
  }

  async #persist() {
    const snapshot = `${JSON.stringify(this.#state, null, 2)}\n`;
    const operation = this.#writeQueue.then(async () => {
      await mkdir(dirname(this.#path), { recursive: true, mode: 0o700 });
      const temporary = `${this.#path}.tmp`;
      await writeFile(temporary, snapshot, { encoding: 'utf8', mode: 0o600 });
      await rename(temporary, this.#path);
    });
    this.#writeQueue = operation.then(() => undefined, () => undefined);
    await operation;
  }
}
