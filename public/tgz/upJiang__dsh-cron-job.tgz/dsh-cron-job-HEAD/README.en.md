# dsh-cron-job

dsh-cron-job adds scheduled tasks and messaging to DeepSeek Harness. Ask the model to create a task, then send its results to WeChat, Feishu, DingTalk, WeCom, QQ, Slack, Telegram, Discord, or WhatsApp.

[中文](README.md)

## Requirements

- DeepSeek Harness is installed.
- Node.js 22.19 or later is installed.
- At least one DSH model is available.
- A bot or account is available for each messaging platform you want to use.

## Install

The installer uses the `web` profile by default. It replaces an installed legacy dsh-im communication plugin while keeping its channel configuration and credential references.

On macOS or Linux:

```sh
npx -y github:upJiang/dsh-cron-job install
```

On Windows PowerShell:

```powershell
npx -y github:upJiang/dsh-cron-job install
```

After installation, stop the running DSH process and start it again:

```sh
dsh web --host 127.0.0.1 --port 3080
```

Refresh the browser and open `http://127.0.0.1:3080/`.

## Connect messaging accounts

1. Open Communications in DSH settings.
2. Choose WeChat, Feishu, DingTalk, WeCom, QQ, Slack, Telegram, Discord, or WhatsApp.
3. Scan the QR code or enter the credentials requested by the page.
4. Complete the connection test, then send the bot one message in the target conversation.

Account settings are stored separately on each device. The plugin does not sync keys, tokens, sign-in sessions, or chat history between devices.

WeChat proactive delivery uses the latest private-chat reply context. After a first install or an upgrade from an older version, send the WeChat bot a new direct message before running a connection test or creating a WeChat delivery task.

## Create a scheduled task

1. Open Scheduled Tasks in DSH settings.
2. Describe the schedule, sources, and delivery destination in plain language.
   You can also load the Product Hunt + GitHub Trending example, then edit or remove any part of it.
3. Choose a workspace, model, and delivery targets, then generate the draft.
4. Review the schedule, time zone, prompt, tool permissions, and delivery targets.
5. Select Test and create.
6. Wait for the real workspace, model, agent, source, and delivery tests to finish.
7. When every test passes, select Confirm and enable.

Test notifications include a Scheduled task creation test label. The task cannot be created if any check or delivery target fails.

## Fix a failed test

The page shows which stage failed and why:

- For a workspace failure, select an accessible folder and check its permissions.
- For a model failure, choose another provider or model, or add the required API key in its settings.
- For an agent or source failure, edit the prompt, URL, authentication settings, or tool permissions.
- For a delivery failure, reconnect the account, add the required platform credentials, choose another conversation, or remove the failed target.

Changing the schedule, time zone, workspace, prompt, model, tool permissions, or delivery targets requires another complete test.

When a website requires a proxy, the plugin first uses `HTTP_PROXY`, `HTTPS_PROXY`, and `NO_PROXY`. If those environment variables are not set, it reads the current user's macOS or Windows system proxy. It only reads the settings and never changes the system proxy.

## Manage tasks

The Scheduled Tasks page lets you search and filter tasks, inspect the next run and run history, edit tasks, pause or resume them, run them now, cancel a running task, or delete them.

Every run uses a separate DSH Session. The same task cannot run concurrently. Runs missed while DSH is stopped are skipped.

## Uninstall

Run this command on macOS, Linux, or Windows PowerShell:

```sh
dsh plugin --profile web remove dsh-cron-job
```

Restart DSH and refresh the browser after uninstalling.

## Install from a local checkout

Run this command from the plugin source directory:

```sh
node bin/dsh-cron-job.mjs install --source .
```

Restart DSH after installation.
