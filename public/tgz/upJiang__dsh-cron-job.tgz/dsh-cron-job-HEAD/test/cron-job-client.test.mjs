import assert from 'node:assert/strict';
import test from 'node:test';
import * as React from 'react';
import TestRenderer from 'react-test-renderer';

import {
  NaturalDraftForm,
  PRODUCT_DISCOVERY_EXAMPLE,
  TaskEditor,
} from '../plugin-src/client/cron/index.js';

const { act, create } = TestRenderer;

async function flushMicrotasks() {
  for (let index = 0; index < 6; index += 1) await Promise.resolve();
}

function draft() {
  return {
    id: 'draft-one',
    status: 'draft',
    state: null,
    config: {
      name: 'Daily summary',
      description: 'Summarize selected sources.',
      schedule: { type: 'cron', expression: '30 8 * * *' },
      timezone: 'Asia/Shanghai',
      workspace: '/workspace/project',
      prompt: 'Read the configured sources and return a linked summary.',
      model: null,
      toolPolicy: { web: true, search: true, fetch: true, rss: true, deny: [] },
      sources: [],
      targets: [],
      timeoutMs: 60_000,
    },
    testRecords: [],
  };
}

test('the optional discovery example fills an editable prompt without overwriting user input', async () => {
  let renderer;
  await act(async () => {
    renderer = create(React.createElement(NaturalDraftForm, {
      api: {},
      catalog: { workspaces: ['/workspace/project'], models: { groups: [] }, targets: [] },
      onCreated() {},
      onOpenAccounts() {},
    }));
    await flushMicrotasks();
  });

  const exampleButton = renderer.root.findByProps({ title: '载入可编辑的任务示例' });
  assert.equal(exampleButton.props.disabled, false);
  await act(async () => {
    exampleButton.props.onClick();
    await flushMicrotasks();
  });

  const input = renderer.root.findByProps({ id: 'dcj-natural-prompt' });
  assert.equal(input.props.value, PRODUCT_DISCOVERY_EXAMPLE);
  assert.match(input.props.value, /producthunt\.com/u);
  assert.match(input.props.value, /github\.com\/trending/u);
  assert.match(input.props.value, /不要求条目日期等于/u);
  assert.doesNotMatch(input.props.value, /无法核实当天内容/u);
  assert.equal(
    renderer.root.findByProps({ 'aria-controls': 'dcj-create-workspace-listbox' }).props['aria-expanded'],
    false,
  );
  const disabledButton = renderer.root.findByProps({ title: '清空任务描述后可载入示例' });
  assert.equal(disabledButton.props.disabled, true);

  await act(async () => {
    input.props.onChange({ target: { value: '用户自己的任务描述' } });
    await flushMicrotasks();
  });
  assert.equal(renderer.root.findByProps({ id: 'dcj-natural-prompt' }).props.value, '用户自己的任务描述');
});

test('TaskEditor traps Tab focus and restores the opener after Escape', async (t) => {
  const originalDocument = globalThis.document;
  t.after(() => { globalThis.document = originalDocument; });

  let keydown;
  let openerFocus = 0;
  let firstFocus = 0;
  let lastFocus = 0;
  const opener = { isConnected: true, focus() { openerFocus += 1; fakeDocument.activeElement = opener; } };
  const first = {
    getAttribute() { return null; },
    focus() { firstFocus += 1; fakeDocument.activeElement = first; },
  };
  const last = {
    getAttribute() { return null; },
    focus() { lastFocus += 1; fakeDocument.activeElement = last; },
  };
  const dialog = {
    contains(node) { return node === first || node === last; },
    focus() { fakeDocument.activeElement = dialog; },
    querySelectorAll() { return [first, last]; },
  };
  const fakeDocument = {
    activeElement: opener,
    addEventListener(name, listener) { if (name === 'keydown') keydown = listener; },
    removeEventListener(name, listener) {
      if (name === 'keydown' && keydown === listener) keydown = undefined;
    },
  };
  globalThis.document = fakeDocument;

  const api = { async runs() { return { items: [] }; } };
  function Fixture() {
    const [open, setOpen] = React.useState(true);
    return open ? React.createElement(TaskEditor, {
      item: draft(),
      catalog: { models: { groups: [] }, targets: [] },
      api,
      progress: null,
      onClose: () => setOpen(false),
      onChanged() {},
      onOpenAccounts() {},
    }) : React.createElement('p', null, 'closed');
  }

  let renderer;
  await act(async () => {
    renderer = create(React.createElement(Fixture), {
      createNodeMock(element) {
        if (element.props?.className === 'dcj-drawer') return dialog;
        if (element.props?.id === 'dcj-task-name') return first;
        return {};
      },
    });
    await flushMicrotasks();
  });
  assert.equal(firstFocus, 1);
  assert.equal(renderer.root.findByProps({ role: 'dialog' }).props.tabIndex, -1);

  fakeDocument.activeElement = last;
  let prevented = 0;
  await act(async () => {
    keydown({ key: 'Tab', shiftKey: false, defaultPrevented: false, preventDefault() { prevented += 1; } });
  });
  assert.equal(firstFocus, 2);
  assert.equal(prevented, 1);

  fakeDocument.activeElement = first;
  await act(async () => {
    keydown({ key: 'Tab', shiftKey: true, defaultPrevented: false, preventDefault() { prevented += 1; } });
  });
  assert.equal(lastFocus, 1);
  assert.equal(prevented, 2);

  await act(async () => {
    keydown({ key: 'Escape', shiftKey: false, defaultPrevented: false, preventDefault() {} });
    await flushMicrotasks();
  });
  assert.equal(renderer.root.findAllByProps({ role: 'dialog' }).length, 0);
  assert.equal(openerFocus, 1);
  assert.equal(keydown, undefined);
});

test('TaskEditor does not close when an inner control consumes Escape', async (t) => {
  const originalDocument = globalThis.document;
  t.after(() => { globalThis.document = originalDocument; });
  let keydown;
  let closes = 0;
  globalThis.document = {
    activeElement: null,
    addEventListener(name, listener) { if (name === 'keydown') keydown = listener; },
    removeEventListener() {},
  };
  let renderer;
  await act(async () => {
    renderer = create(React.createElement(TaskEditor, {
      item: draft(),
      catalog: { models: { groups: [] }, targets: [] },
      api: { async runs() { return { items: [] }; } },
      progress: null,
      onClose: () => { closes += 1; },
      onChanged() {},
      onOpenAccounts() {},
    }), {
      createNodeMock(element) {
        if (element.props?.className === 'dcj-drawer') {
          return { querySelectorAll() { return []; }, contains() { return false; } };
        }
        return {};
      },
    });
    await flushMicrotasks();
  });
  await act(async () => {
    keydown({ key: 'Escape', defaultPrevented: true, preventDefault() {} });
  });
  assert.equal(closes, 0);
  await act(async () => { renderer.unmount(); });
});
