import assert from 'node:assert/strict';
import { stat } from 'node:fs/promises';
import { relative, resolve } from 'node:path';

/** Unix mode bits are not exposed by Windows filesystem metadata. */
export async function assertFileMode(path, expected) {
  const info = await stat(path);
  assert.equal(info.isFile(), true);
  if (process.platform !== 'win32') {
    assert.equal(info.mode & 0o777, expected);
  }
}

export async function assertDirectoryMode(path, expected) {
  const info = await stat(path);
  assert.equal(info.isDirectory(), true);
  if (process.platform !== 'win32') {
    assert.equal(info.mode & 0o777, expected);
  }
}

export function portablePath(value) {
  return String(value).replaceAll('\\', '/');
}

export function isInsidePath(root, candidate) {
  const relativePath = relative(resolve(root), resolve(candidate));
  return relativePath !== '' && !relativePath.startsWith('..') && !relativePath.startsWith('..\\') && !relativePath.startsWith('../');
}

export function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
