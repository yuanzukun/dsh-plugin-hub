import assert from 'node:assert/strict';
import test from 'node:test';

import { createImHostPlugin, inject, name } from '../plugin-src/host/index.mjs';

test('Host composes nine IM channels and the cron service inside one plugin context', async () => {
  const calls = [];
  const controllers = new Map();
  const conversationRoutes = { marker: 'conversation-routes' };
  const channel = (name) => async (ctx, config) => {
    calls.push([name, ctx, config]);
    const controller = { name };
    controllers.set(name, controller);
    config.onController(controller);
  };
  const plugin = createImHostPlugin({
    conversationRoutes,
    applyFeishu: channel('feishu'),
    applyWeixin: channel('weixin'),
    applyDingtalk: channel('dingtalk'),
    applyWecom: channel('wecom'),
    applyQq: channel('qq'),
    applySlack: channel('slack'),
    applyTelegram: channel('telegram'),
    applyDiscord: channel('discord'),
    applyWhatsapp: channel('whatsapp'),
    installCronJob: async (ctx, actualControllers, config, internals) => {
      calls.push(['cron', ctx, actualControllers, config, internals]);
    },
  });
  const ctx = { marker: 'shared-context' };
  const config = {
    rpcAuthority: 'trusted-host',
    feishu: { domain: 'feishu' },
    weixin: { timeout: 30 },
    dingtalk: { replyTimeoutMs: 60_000 },
    wecom: { replyTimeoutMs: 60_000 },
    qq: { replyTimeoutMs: 60_000 },
    slack: { replyTimeoutMs: 60_000 },
    telegram: { replyTimeoutMs: 60_000 },
    discord: { replyTimeoutMs: 60_000 },
    whatsapp: { replyTimeoutMs: 60_000 },
    cron: { dataPath: '/tmp/dsh-cron-job-test.json' },
  };

  await plugin.apply(ctx, config);

  assert.equal(name, 'dsh-cron-job-host');
  assert.deepEqual(inject, [
    'connection',
    'credentials',
    'webServer',
    'typertGateway',
    'web',
    'tools',
    'systemPrompt',
  ]);
  for (const [index, channelName] of CHANNELS.map(([channelName]) => channelName).entries()) {
    const [actualName, actualContext, actualConfig] = calls[index];
    assert.equal(actualName, channelName);
    assert.equal(actualContext, ctx);
    assert.deepEqual(
      Object.fromEntries(Object.entries(actualConfig).filter(([key]) => key !== 'onController')),
      { ...config[channelName], rpcAuthority: 'trusted-host', conversationRoutes },
    );
    assert.equal(typeof actualConfig.onController, 'function');
  }
  assert.deepEqual(calls[9], [
    'cron', ctx, controllers, { ...config.cron, rpcAuthority: 'trusted-host' },
    { conversationRoutes },
  ]);
  assert.deepEqual([...controllers.keys()], CHANNELS.map(([channelName]) => channelName));
});

const CHANNELS = [
  ['feishu', 'applyFeishu'],
  ['weixin', 'applyWeixin'],
  ['dingtalk', 'applyDingtalk'],
  ['wecom', 'applyWecom'],
  ['qq', 'applyQq'],
  ['slack', 'applySlack'],
  ['telegram', 'applyTelegram'],
  ['discord', 'applyDiscord'],
  ['whatsapp', 'applyWhatsapp'],
];

function activationFixture(failedChannels) {
  const calls = [];
  const events = [];
  const errors = [];
  const failures = new Map();
  const internals = Object.fromEntries(CHANNELS.map(([channel, applyName]) => [
    applyName,
    async () => {
      calls.push(channel);
      events.push(`${channel}:start`);
      await new Promise((resolve) => setImmediate(resolve));
      if (failedChannels.has(channel)) {
        const error = new Error(`${channel} unavailable`);
        failures.set(channel, error);
        events.push(`${channel}:failed`);
        throw error;
      }
      events.push(`${channel}:end`);
    },
  ]));
  internals.installCronJob = async () => {};
  const ctx = { logger: { error: (...args) => errors.push(args) } };
  return { plugin: createImHostPlugin(internals), ctx, calls, events, errors, failures };
}

test('Host continues activating channels in order when one channel fails', async () => {
  for (const [failedChannel] of CHANNELS) {
    const fixture = activationFixture(new Set([failedChannel]));

    await fixture.plugin.apply(fixture.ctx, {});

    assert.deepEqual(fixture.calls, CHANNELS.map(([channel]) => channel));
    assert.deepEqual(fixture.events, CHANNELS.flatMap(([channel]) => [
      `${channel}:start`,
      `${channel}:${channel === failedChannel ? 'failed' : 'end'}`,
    ]));
    assert.equal(fixture.errors.length, 1);
    assert.match(fixture.errors[0][0], new RegExp(`activate ${failedChannel}`));
    assert.equal(fixture.errors[0][1], fixture.failures.get(failedChannel));
  }
});

test('Host reports aggregate failure only after every channel was attempted', async () => {
  const fixture = activationFixture(new Set(CHANNELS.map(([channel]) => channel)));

  await assert.rejects(
    () => fixture.plugin.apply(fixture.ctx, {}),
    (error) => error instanceof AggregateError
      && error.errors.length === CHANNELS.length
      && /failed to activate every channel/.test(error.message),
  );
  assert.deepEqual(fixture.calls, CHANNELS.map(([channel]) => channel));
  assert.equal(fixture.errors.length, CHANNELS.length);
});
