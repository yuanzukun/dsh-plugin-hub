import assert from 'node:assert/strict';
import test from 'node:test';

import {
  configFingerprint,
  normalizeTaskConfig,
} from '../plugin-src/host/cron/domain.mjs';
import {
  CronHarnessRunner,
  installCronToolGuard,
} from '../plugin-src/host/cron/harness-runner.mjs';
import {
  NotificationDispatcher,
  publicTask,
} from '../plugin-src/host/cron/notifications.mjs';
import {
  createCronJobRpcHandler,
  CRON_JOB_ENDPOINTS,
} from '../plugin-src/host/cron/rpc.mjs';
import { nextRunAt } from '../plugin-src/host/cron/schedule.mjs';
import { CronJobService } from '../plugin-src/host/cron/service.mjs';
import { cronJobToolDefinitions } from '../plugin-src/host/cron/tools.mjs';
import { createWorkspaceAwareController } from '../src/channels/shared/bot-workspace-store.mjs';
import { ConversationRouteRegistry } from '../src/channels/shared/conversation-route.mjs';

class MemoryStore {
  constructor(state = {}) {
    this.state = {
      schemaVersion: 1,
      revision: 0,
      drafts: [],
      jobs: [],
      runs: [],
      ...structuredClone(state),
    };
  }

  snapshot() {
    return structuredClone(this.state);
  }

  async update(mutator) {
    const next = structuredClone(this.state);
    const value = await mutator(next);
    next.revision = this.state.revision + 1;
    this.state = next;
    return structuredClone(value === undefined ? next : value);
  }
}

function task(overrides = {}) {
  return {
    name: 'Daily summary',
    description: 'Summarize selected sources.',
    schedule: { type: 'cron', expression: '30 8 * * *' },
    timezone: 'Asia/Shanghai',
    workspace: process.cwd(),
    prompt: 'Read the configured sources and return a linked summary.',
    model: { provider: 'provider-a', model: 'model-a', reasoningEffort: 'medium' },
    toolPolicy: { web: true, search: true, fetch: true, rss: true, deny: [] },
    sources: [{ type: 'web', url: 'https://example.com/latest' }],
    targets: [
      { channel: 'weixin', botId: 'weixin-bot', recipient: { toUserId: 'user-one' } },
      { channel: 'slack', botId: 'slack-bot', recipient: { channelId: 'channel-two' } },
    ],
    timeoutMs: 60_000,
    ...overrides,
  };
}

function notifications({ revisions, failChannels = new Set(), sent = [] } = {}) {
  const current = revisions ?? new Map([
    ['weixin:weixin-bot', 1],
    ['slack:slack-bot', 2],
  ]);
  return {
    resolveTargetRefs(targets) { return structuredClone(targets); },
    publicTargets() { return []; },
    targetVersions(targets) {
      return targets.map((target) => ({
        ...structuredClone(target),
        credentialRevision: current.get(`${target.channel}:${target.botId}`) ?? -1,
        connected: true,
      }));
    },
    async send(target, text, options) {
      sent.push({ target: structuredClone(target), text, options });
      if (failChannels.has(target.channel)) {
        const error = new Error(`${target.channel} credentials are unavailable`);
        error.code = `${target.channel}-credential-missing`;
        throw error;
      }
      return {
        targetId: `opaque-${target.channel}`,
        channel: target.channel,
        botId: target.botId,
        kind: options.kind,
        runId: options.runId,
        status: 'delivered',
        deliveredAt: '2026-08-27T00:00:00.000Z',
        durationMs: 1,
        providerMessageIds: [`message-${target.channel}`],
      };
    },
  };
}

function runner(overrides = {}) {
  return {
    async catalog() { return { workspaces: [], models: [] }; },
    async run(config, options = {}) {
      options.onSession?.({ kind: 'task', sessionId: 'session-task' });
      options.onProgress?.({ stage: 'agent', status: 'passed' });
      return {
        sessionId: 'session-task',
        probeSessionId: options.probeModel ? 'session-probe' : undefined,
        output: 'Validated result with links.',
        toolNames: ['web_fetch'],
        instructions: [],
      };
    },
    async stop() { return true; },
    async close() {},
    ...overrides,
  };
}

function serviceFixture(options = {}) {
  const store = options.store ?? new MemoryStore();
  const sent = [];
  const notifier = options.notifications ?? notifications({ sent });
  const service = new CronJobService({
    store,
    notifications: notifier,
    runner: options.runner ?? runner(),
    now: options.now ?? (() => new Date('2026-08-27T00:00:00.000Z')),
  });
  return { service, store, sent, notifications: notifier };
}

async function activeJob(fixture, input = task()) {
  const draft = await fixture.service.draft(input);
  const ready = await fixture.service.testDraft(draft.id);
  assert.equal(ready.status, 'ready');
  return fixture.service.confirmDraft(draft.id);
}

test('cron, once, and interval schedules return the next timezone-aware future instant', () => {
  assert.equal(
    nextRunAt({ type: 'cron', expression: '30 8 * * *' }, 'Asia/Shanghai', {
      after: new Date('2026-08-27T00:29:00.000Z'),
    }),
    '2026-08-27T00:30:00.000Z',
  );
  assert.equal(
    nextRunAt({ type: 'once', at: '2026-08-27T01:00:00.000Z' }, 'UTC', {
      after: new Date('2026-08-27T00:00:00.000Z'),
    }),
    '2026-08-27T01:00:00.000Z',
  );
  assert.equal(
    nextRunAt({ type: 'once', at: '2026-08-26T01:00:00.000Z' }, 'UTC', {
      after: new Date('2026-08-27T00:00:00.000Z'),
    }),
    null,
  );
  assert.equal(
    nextRunAt({ type: 'interval', seconds: 300 }, 'UTC', {
      after: new Date('2026-08-27T00:12:00.000Z'),
      intervalAnchor: '2026-08-27T00:00:00.000Z',
    }),
    '2026-08-27T00:15:00.000Z',
  );
});

test('fingerprints are stable for key order and change with critical config or credentials', () => {
  const config = normalizeTaskConfig(task());
  const versions = [{
    channel: 'weixin', botId: 'weixin-bot', recipient: { toUserId: 'user-one' },
    credentialRevision: 1,
  }];
  const reordered = structuredClone(config);
  reordered.model = { model: 'model-a', reasoningEffort: 'medium', provider: 'provider-a' };
  assert.equal(configFingerprint(config, versions), configFingerprint(reordered, versions));
  assert.notEqual(
    configFingerprint(config, versions),
    configFingerprint({ ...config, prompt: 'Changed prompt.' }, versions),
  );
  assert.notEqual(
    configFingerprint(config, versions),
    configFingerprint(config, [{ ...versions[0], credentialRevision: 2 }]),
  );
});

test('only a complete preflight and every delivered target can create an active job', async () => {
  const fixture = serviceFixture();
  const draft = await fixture.service.draft(task());
  await assert.rejects(() => fixture.service.confirmDraft(draft.id), { code: 'preflight-required' });

  const ready = await fixture.service.testDraft(draft.id);
  assert.equal(ready.status, 'ready');
  assert.equal(ready.testRecords[0].kind, 'preflight');
  assert.equal(ready.testRecords[0].status, 'passed');
  assert.equal(ready.testRecords[0].receipts.length, 2);
  assert.equal(fixture.store.snapshot().runs.length, 0);
  assert.equal(fixture.sent.length, 2);
  assert.ok(fixture.sent.every((item) => item.text.includes('定时任务创建测试')));

  const job = await fixture.service.confirmDraft(draft.id);
  assert.equal(job.state, 'active');
  assert.equal(fixture.store.snapshot().drafts.length, 0);
  assert.equal(fixture.store.snapshot().jobs.length, 1);
});

test('one failed notification blocks creation and records a credential repair receipt', async () => {
  const sent = [];
  const fixture = serviceFixture({
    notifications: notifications({ failChannels: new Set(['slack']), sent }),
  });
  const draft = await fixture.service.draft(task());
  const failed = await fixture.service.testDraft(draft.id);

  assert.equal(failed.status, 'test_failed');
  assert.equal(failed.successfulPreflight, null);
  assert.equal(failed.testRecords[0].receipts.length, 2);
  assert.equal(failed.testRecords[0].receipts[1].status, 'failed');
  assert.deepEqual(failed.testRecords[0].failures[0].credentialRequired, {
    channel: 'slack',
    field: 'account credentials',
  });
  await assert.rejects(() => fixture.service.confirmDraft(draft.id), { code: 'preflight-required' });
  assert.equal(fixture.store.snapshot().jobs.length, 0);
});

test('a provider rejection keeps a safe provider code and actionable message in preflight', async () => {
  const providerError = new Error('微信发送频率受限，请等待 5 分钟后重试。');
  providerError.code = 'send-rejected';
  providerError.providerCode = '-2';
  const fixture = serviceFixture({
    notifications: {
      resolveTargetRefs(targets) { return structuredClone(targets); },
      targetVersions(targets) {
        return targets.map((target) => ({ ...structuredClone(target), credentialRevision: 1 }));
      },
      async send() { throw providerError; },
    },
  });
  const draft = await fixture.service.draft({
    ...task(),
    targets: [{
      channel: 'weixin',
      botId: 'weixin-bot',
      recipient: { toUserId: 'user-one' },
    }],
  });

  const failed = await fixture.service.testDraft(draft.id);

  assert.equal(failed.status, 'test_failed');
  assert.deepEqual(failed.testRecords[0].failures[0], {
    stage: 'target',
    targetId: failed.testRecords[0].receipts[0].targetId,
    code: 'send-rejected',
    message: '微信发送频率受限，请等待 5 分钟后重试。',
    providerCode: '-2',
  });
  assert.equal(failed.testRecords[0].receipts[0].providerCode, '-2');
});

test('critical edits and credential revisions invalidate a successful preflight', async () => {
  const revisions = new Map([
    ['weixin:weixin-bot', 1],
    ['slack:slack-bot', 2],
  ]);
  const fixture = serviceFixture({ notifications: notifications({ revisions }) });
  const first = await fixture.service.draft(task());
  await fixture.service.testDraft(first.id);
  const changed = await fixture.service.updateDraft(first.id, { prompt: 'Use a different prompt.' });
  assert.equal(changed.status, 'draft');
  assert.equal(changed.successfulPreflight, null);

  const second = await fixture.service.draft(task());
  await fixture.service.testDraft(second.id);
  revisions.set('slack:slack-bot', 3);
  assert.equal(fixture.service.get(second.id).status, 'draft');
  assert.equal(fixture.service.snapshot().drafts.find((item) => item.id === second.id).status, 'draft');
  await assert.rejects(() => fixture.service.confirmDraft(second.id), { code: 'preflight-required' });
  const persisted = fixture.store.snapshot().drafts.find((item) => item.id === second.id);
  assert.equal(persisted.status, 'draft');
  assert.equal(persisted.successfulPreflight, null);
});

test('metadata updates apply directly while critical active-job updates create a gated draft', async () => {
  const fixture = serviceFixture();
  const job = await activeJob(fixture);
  const renamed = await fixture.service.updateJob(job.id, {
    name: 'Renamed summary',
    description: 'New description.',
  });
  assert.equal(renamed.id, job.id);
  assert.equal(renamed.config.name, 'Renamed summary');
  assert.equal(fixture.store.snapshot().drafts.length, 0);

  const pending = await fixture.service.updateJob(job.id, { prompt: 'A new critical prompt.' });
  assert.equal(pending.baseJobId, job.id);
  assert.equal(pending.status, 'draft');
  assert.equal(fixture.store.snapshot().jobs[0].config.prompt, job.config.prompt);
});

test('formal runs enforce one lock, support precise cancellation, and retain partial delivery', async () => {
  let release;
  let stoppedSession;
  const blockingRunner = runner({
    async run(_config, { signal, onSession, probeModel } = {}) {
      if (probeModel) {
        return {
          sessionId: 'preflight-session', probeSessionId: 'probe-session',
          output: 'Validated result.', toolNames: [], instructions: [],
        };
      }
      onSession?.({ kind: 'task', sessionId: 'running-session' });
      return new Promise((resolve) => {
        release = () => resolve({
          sessionId: 'running-session', output: 'Result', toolNames: [], instructions: [],
        });
        signal.addEventListener('abort', () => resolve({
          sessionId: 'running-session', output: 'Cancelled result', toolNames: [], instructions: [],
        }), { once: true });
      });
    },
    async stop(sessionId) { stoppedSession = sessionId; return true; },
  });
  const fixture = serviceFixture({ runner: blockingRunner });
  const job = await activeJob(fixture);

  const running = fixture.service.run(job.id);
  await assert.rejects(() => fixture.service.run(job.id), { code: 'job-running' });
  const cancellation = await fixture.service.cancel(job.id);
  assert.equal(cancellation.cancelled, true);
  assert.equal(stoppedSession, 'running-session');
  const cancelled = await running;
  assert.equal(cancelled.status, 'cancelled');
  release?.();

  const partialSent = [];
  const partial = serviceFixture({
    notifications: notifications({ failChannels: new Set(['slack']), sent: partialSent }),
  });
  const partialJob = await activeJob(serviceFixture());
  partial.store.state.jobs.push(partialJob);
  const record = await partial.service.run(partialJob.id);
  assert.equal(record.status, 'partial_failure');
  assert.deepEqual(record.receipts.map((item) => item.status), ['delivered', 'failed']);
});

test('startup skips all missed executions without backfilling them', async () => {
  const config = normalizeTaskConfig(task({
    schedule: { type: 'interval', seconds: 300 },
    sources: [],
  }));
  const store = new MemoryStore({
    jobs: [{
      id: 'job-missed', revision: 1, state: 'active', config,
      createdAt: '2026-08-26T00:00:00.000Z', updatedAt: '2026-08-26T00:00:00.000Z',
      lastRunAt: null, nextRunAt: '2026-08-26T00:05:00.000Z',
      intervalAnchor: '2026-08-26T00:00:00.000Z', testRecords: [],
    }],
  });
  let runs = 0;
  const fixture = serviceFixture({
    store,
    runner: runner({ async run() { runs += 1; return { sessionId: 'x', output: 'x', toolNames: [] }; } }),
  });
  await fixture.service.skipMissedOnStartup(new Date('2026-08-27T00:02:00.000Z'));
  assert.equal(runs, 0);
  assert.equal(store.snapshot().jobs[0].nextRunAt, '2026-08-27T00:05:00.000Z');
});

test('public Cron RPC uses the same confirmation gate and never exposes recipients', async () => {
  const fixture = serviceFixture();
  const handler = createCronJobRpcHandler(fixture.service);
  const draft = await fixture.service.draft(task());
  const blocked = await handler(CRON_JOB_ENDPOINTS.confirm, { id: draft.id });
  assert.equal(blocked.ok, false);
  assert.equal(blocked.error.code, 'preflight-required');

  const snapshot = publicTask(fixture.service.snapshot());
  const target = snapshot.drafts[0].config.targets[0];
  assert.equal('recipient' in target, false);
  assert.match(target.targetRef, /^[a-f0-9]{24}$/u);
  assert.match(target.recipientLabel, /\.\.\./u);
  assert.doesNotMatch(JSON.stringify(snapshot), /user-one|channel-two/u);
});

test('the real runner performs a model probe, a separate task Session, and matches object URL args', async () => {
  const sessions = [];
  const prompts = [];
  class FakeHarness {
    async listModels() {
      return { groups: [{
        id: 'provider-a',
        models: [{ id: 'model-a', reasoning: { efforts: [{ id: 'medium' }] } }],
      }] };
    }
    async createSession() {
      const id = `session-${sessions.length + 1}`;
      sessions.push(id);
      return id;
    }
    async selectSessionModel() {}
    async ask(sessionId, prompt, options) {
      prompts.push({ sessionId, prompt });
      if (prompt === 'Reply with exactly: CRON_MODEL_OK') return 'CRON_MODEL_OK';
      options.onUpdate?.({
        type: 'tool', callId: 'fetch-1', name: 'web_fetch', arguments: { url: 'https://example.com/latest/' },
      });
      options.onUpdate?.({ type: 'status', callId: 'fetch-1', toolName: 'web_fetch', ok: true });
      return 'Final linked summary.\n<!-- DSH_CRON_JOB_STATUS:SUCCESS -->';
    }
    async stopActiveTurn() { return true; }
  }
  const controlledSessions = new Map();
  const actualRunner = new CronHarnessRunner({ webServer: { port: 3080 } }, {
    controlledSessions,
    Harness: FakeHarness,
  });
  const progress = [];
  const result = await actualRunner.run(normalizeTaskConfig(task()), {
    probeModel: true,
    onProgress: (item) => progress.push(item),
  });
  assert.deepEqual(sessions, ['session-1', 'session-2']);
  assert.equal(prompts.length, 2);
  assert.equal(result.probeSessionId, 'session-1');
  assert.equal(result.sessionId, 'session-2');
  assert.equal(result.output, 'Final linked summary.');
  assert.deepEqual(result.toolNames, ['web_fetch']);
  assert.match(prompts[1].prompt, /DSH_CRON_JOB_STATUS:SUCCESS/u);
  assert.match(prompts[1].prompt, /DSH_CRON_JOB_STATUS:FAILED/u);
  assert.ok(progress.some((item) => item.stage === 'source' && item.status === 'passed'));
  assert.equal(controlledSessions.size, 0);
});

test('the real runner rejects agent-reported failure after successful source reads', async () => {
  class FakeHarness {
    async listModels() { return { groups: [], failures: [] }; }
    async createSession() { return 'session-agent-failure'; }
    async ask(_sessionId, _prompt, options) {
      options.onUpdate?.({
        type: 'tool', callId: 'fetch-1', name: 'web_fetch',
        arguments: { url: 'https://example.com/latest' },
      });
      options.onUpdate?.({
        type: 'status', callId: 'fetch-1', toolName: 'web_fetch', ok: true, statusCode: 200,
      });
      return 'The requested result could not be verified.\n<!-- DSH_CRON_JOB_STATUS:FAILED -->';
    }
    async stopActiveTurn() { return true; }
  }
  const actualRunner = new CronHarnessRunner({ webServer: { port: 3080 } }, { Harness: FakeHarness });
  await assert.rejects(
    actualRunner.run(normalizeTaskConfig(task({ model: null }))),
    { code: 'agent-reported-failure', preflightStage: 'agent' },
  );
});

test('the real runner rejects a final result without a completion marker', async () => {
  class FakeHarness {
    async listModels() { return { groups: [], failures: [] }; }
    async createSession() { return 'session-agent-unconfirmed'; }
    async ask(_sessionId, _prompt, options) {
      options.onUpdate?.({
        type: 'tool', callId: 'fetch-1', name: 'web_fetch',
        arguments: { url: 'https://example.com/latest' },
      });
      options.onUpdate?.({
        type: 'status', callId: 'fetch-1', toolName: 'web_fetch', ok: true, statusCode: 200,
      });
      return 'Final linked summary without a status marker.';
    }
    async stopActiveTurn() { return true; }
  }
  const actualRunner = new CronHarnessRunner({ webServer: { port: 3080 } }, { Harness: FakeHarness });
  await assert.rejects(
    actualRunner.run(normalizeTaskConfig(task({ model: null }))),
    { code: 'agent-completion-unconfirmed', preflightStage: 'agent' },
  );
});

test('the real runner reports a source credential failure instead of a misleading URL miss', async () => {
  class FakeHarness {
    async listModels() { return { groups: [] }; }
    async createSession() { return 'session-source-failure'; }
    async ask(_sessionId, _prompt, options) {
      options.onUpdate?.({
        type: 'tool', callId: 'search-1', name: 'web_search',
        arguments: { query: 'site:producthunt.com latest products' },
      });
      options.onUpdate?.({
        type: 'status', callId: 'search-1', toolName: 'web_search', ok: false,
        error: 'DeepSeek search has no API key for "DEEPSEEK_API_KEY"',
        errorCode: 'WEB_PROVIDER_CREDENTIAL_MISSING',
      });
      return 'The source could not be accessed.';
    }
    async stopActiveTurn() { return true; }
  }
  const actualRunner = new CronHarnessRunner({ webServer: { port: 3080 } }, { Harness: FakeHarness });
  await assert.rejects(
    actualRunner.run(normalizeTaskConfig(task({
      model: null,
      sources: [{ type: 'web', url: 'https://www.producthunt.com/' }],
    }))),
    (error) => {
      assert.equal(error.preflightStage, 'source');
      assert.equal(error.code, 'WEB_PROVIDER_CREDENTIAL_MISSING');
      assert.deepEqual(error.credentialRequired, {
        channel: 'web-search', field: 'DEEPSEEK_API_KEY',
      });
      return true;
    },
  );
});

test('the real runner rejects non-2xx web fetch results before a task can pass', async () => {
  class FakeHarness {
    async listModels() { return { groups: [], failures: [] }; }
    async createSession() { return 'session-http-failure'; }
    async ask(_sessionId, _prompt, options) {
      options.onUpdate?.({
        type: 'tool', callId: 'fetch-403', name: 'web_fetch',
        arguments: { url: 'https://www.producthunt.com/' },
      });
      options.onUpdate?.({
        type: 'status', callId: 'fetch-403', toolName: 'web_fetch', ok: false,
        error: 'HTTP status 403', errorCode: 'WEB_HTTP_403', statusCode: 403,
      });
      return 'The source could not be accessed.';
    }
    async stopActiveTurn() { return true; }
  }
  const actualRunner = new CronHarnessRunner({ webServer: { port: 3080 } }, { Harness: FakeHarness });
  await assert.rejects(
    actualRunner.run(normalizeTaskConfig(task({
      model: null,
      sources: [{ type: 'web', url: 'https://www.producthunt.com/' }],
    }))),
    (error) => {
      assert.equal(error.preflightStage, 'source');
      assert.equal(error.code, 'WEB_HTTP_403');
      assert.match(error.message, /status 403/u);
      return true;
    },
  );
});

test('the tool guard rejects process and external-write tools but permits configured reads', () => {
  let guard;
  const controlled = new Map([['session-one', {
    web: true, search: true, fetch: true, rss: true, deny: ['blocked_read'],
  }]]);
  const dispose = installCronToolGuard({
    tools: { guard(callback) { guard = callback; return () => { guard = null; }; } },
  }, controlled);
  const exec = (name) => ({ name, agent: { sessionId: 'session-one' } });

  assert.match(guard(exec('bash')), /read-only/u);
  assert.match(guard(exec('web_upload')), /external state/u);
  assert.match(guard(exec('blocked_read')), /tool policy/u);
  assert.equal(guard(exec('web_fetch')), undefined);
  assert.equal(guard({ name: 'bash', agent: { sessionId: 'other' } }), undefined);
  dispose();
  assert.equal(guard, null);
});

test('the tool guard requires exact fetch tools for URL sources unless search is configured', () => {
  let guard;
  const controlled = new Map([
    ['url-session', {
      web: true, search: true, fetch: true, rss: true, deny: [],
      requiredSourceTypes: ['web'],
    }],
    ['search-session', {
      web: true, search: true, fetch: true, rss: true, deny: [],
      requiredSourceTypes: ['web', 'search'],
    }],
  ]);
  const dispose = installCronToolGuard({
    tools: { guard(callback) { guard = callback; return () => { guard = null; }; } },
  }, controlled);

  assert.match(
    guard({ name: 'web_search', agent: { id: 'url-session' } }),
    /Search tools are not allowed/u,
  );
  assert.equal(guard({ name: 'web_fetch', agent: { id: 'url-session' } }), undefined);
  assert.equal(guard({ name: 'web_search', agent: { id: 'search-session' } }), undefined);
  dispose();
});

test('the notification dispatcher routes all nine channels and returns opaque public targets', async () => {
  const channels = [
    'weixin', 'feishu', 'dingtalk', 'wecom', 'qq', 'slack', 'telegram', 'discord',
    'whatsapp',
  ];
  const calls = [];
  const controllers = new Map(channels.map((channel) => [channel, {
    notificationTargets: () => [{
      botId: `${channel}-bot`, name: `${channel} bot`, connected: true,
      credentialRevision: 1,
      recipient: channel === 'dingtalk' ? { webhook: 'must-not-persist' } : { chatId: `${channel}-chat` },
    }],
    async sendNotification(botId, notification) {
      calls.push({ channel, botId, notification });
      return { providerMessageIds: [`${channel}-message`] };
    },
  }]));
  const dispatcher = new NotificationDispatcher(controllers);
  const listed = dispatcher.listTargets();
  assert.equal(listed.length, 9);
  assert.equal(listed.find((item) => item.channel === 'dingtalk').recipient, null);
  assert.ok(dispatcher.publicTargets().every((item) => !('recipient' in item)));
  for (const item of listed) {
    await dispatcher.send({
      channel: item.channel, botId: item.botId, ...(item.recipient ? { recipient: item.recipient } : {}),
    }, 'test', { kind: 'preflight', runId: 'run-one' });
  }
  assert.deepEqual(calls.map((item) => item.channel), channels);
  assert.equal(calls.find((item) => item.channel === 'dingtalk').notification.recipient, undefined);
});

test('cron_job_draft publishes the complete strict task and current-conversation schema', () => {
  const definition = cronJobToolDefinitions({})
    .find((item) => item.name === 'cron_job_draft');
  const taskSchema = definition.parameters.properties.task;

  assert.equal(definition.parameters.additionalProperties, false);
  assert.equal(taskSchema.additionalProperties, false);
  assert.deepEqual(taskSchema.required, [
    'name', 'schedule', 'timezone', 'workspace', 'prompt', 'targets',
  ]);
  assert.equal(Object.hasOwn(taskSchema.properties, 'notifications'), false);
  assert.equal(Object.hasOwn(taskSchema.properties, 'notificationTargets'), false);
  assert.deepEqual(
    taskSchema.properties.targets.items.oneOf[0].properties.currentConversation,
    {
      type: 'boolean',
      const: true,
      description: 'Safely select the communication conversation that initiated this Agent turn.',
    },
  );
});

test('cron_job_draft resolves currentConversation from only the active Agent session', async () => {
  const routes = new ConversationRouteRegistry();
  const dispatcher = new NotificationDispatcher(new Map(), routes);
  const fixture = serviceFixture({ notifications: dispatcher });
  const definition = cronJobToolDefinitions(fixture.service)
    .find((item) => item.name === 'cron_job_draft');
  const input = task({ targets: [{ currentConversation: true }] });

  await assert.rejects(
    definition.execute({ task: input }, { agent: { sessionId: 'session-im' } }),
    { code: 'current-conversation-unavailable' },
  );
  assert.equal(fixture.store.snapshot().drafts.length, 0);

  const draft = await routes.run({
    sessionId: 'session-im',
    channel: 'weixin',
    botId: 'weixin-bot',
    recipient: { toUserId: 'private-user' },
  }, () => definition.execute({ task: input }, { agent: { id: 'session-im' } }));

  assert.deepEqual(draft.config.targets, [{
    channel: 'weixin',
    botId: 'weixin-bot',
    recipient: { toUserId: 'private-user' },
  }]);
  await assert.rejects(
    definition.execute({ task: input }, { agent: { id: 'session-im' } }),
    { code: 'current-conversation-unavailable' },
  );
  assert.equal(fixture.store.snapshot().drafts.length, 1);
});

test('currentConversation rejects concurrent different conversations for one Agent session', async () => {
  const routes = new ConversationRouteRegistry();
  let release;
  const held = new Promise((resolve) => { release = resolve; });
  const first = routes.run({
    sessionId: 'shared-session',
    channel: 'weixin',
    botId: 'weixin-bot',
    recipient: { toUserId: 'user-one' },
  }, () => held);
  const second = routes.run({
    sessionId: 'shared-session',
    channel: 'slack',
    botId: 'slack-bot',
    recipient: { channelId: 'channel-two' },
  }, async () => {
    assert.throws(() => routes.resolve('shared-session'), {
      code: 'current-conversation-ambiguous',
    });
  });

  await second;
  release();
  await first;
});

test('workspace decoration preserves notification target arrays and delivery receipts', async () => {
  const base = {
    status: () => ({ bots: [{ botId: 'weixin-bot', connected: true }] }),
    notificationTargets: () => [{
      botId: 'weixin-bot',
      name: 'Weixin bot',
      connected: true,
      recipient: { toUserId: 'private-recipient' },
      credentialRevision: 1,
    }],
    sendNotification: async () => ({ providerMessageIds: ['message-one'] }),
  };
  const wrapped = createWorkspaceAwareController(base, {
    workspaces: {
      decorateStatus: (value) => value,
      workspaceFor: () => process.cwd(),
      agentPresetFor: () => null,
    },
    stateFor: async () => ({}),
    agentPresetCatalog: {
      defaultId: 'standard',
      items: [{ id: 'standard', label: 'Standard' }],
    },
  });
  const dispatcher = new NotificationDispatcher(new Map([['weixin', wrapped]]));

  assert.equal(Array.isArray(wrapped.notificationTargets()), true);
  assert.equal(dispatcher.publicTargets().length, 1);
  const receipt = await dispatcher.send({
    channel: 'weixin',
    botId: 'weixin-bot',
    recipient: { toUserId: 'private-recipient' },
  }, 'test', { kind: 'preflight', runId: 'run-one' });
  assert.deepEqual(receipt.providerMessageIds, ['message-one']);
});
