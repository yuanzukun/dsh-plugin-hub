import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import test from 'node:test';

import {
  CronJobHttpFetchProvider,
  installCronWebFetchProvider,
  webFetchInternals,
} from '../plugin-src/host/cron/web-fetch.mjs';

async function withServer(handler, run) {
  const server = createServer(handler);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  try {
    const address = server.address();
    await run(`http://127.0.0.1:${address.port}`);
  } finally {
    await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  }
}

test('cron URL provider fetches bounded text and follows same-origin redirects', async () => {
  await withServer((request, response) => {
    if (request.url === '/redirect') {
      response.writeHead(302, { location: '/page' }).end();
      return;
    }
    response.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    response.end('<main>scheduled source</main>');
  }, async (origin) => {
    const result = await new CronJobHttpFetchProvider().fetch({ url: `${origin}/redirect` });
    assert.equal(result.statusCode, 200);
    assert.equal(result.body.kind, 'html');
    assert.match(result.body.content, /scheduled source/);
    assert.equal(result.url, `${origin}/page`);
  });
});

test('cron URL provider rejects non-http URLs and exposes a web provider disposer', async () => {
  const provider = new CronJobHttpFetchProvider();
  await assert.rejects(provider.fetch({ url: 'file:///tmp/source' }), { code: 'WEB_URL_BLOCKED' });
  let registered;
  const dispose = installCronWebFetchProvider({
    web: { registerFetchProvider(value) { registered = value; return () => { registered = null; }; } },
  });
  assert.equal(registered.id, provider.id);
  dispose();
  assert.equal(registered, null);
});

test('cron URL provider discovers each system proxy protocol once', async () => {
  let discoveries = 0;
  const provider = new CronJobHttpFetchProvider({
    env: {},
    discoverProxy: async (_platform, protocol) => {
      discoveries += 1;
      assert.equal(protocol, 'http:');
      return null;
    },
  });
  await withServer((_request, response) => {
    response.writeHead(200, { 'content-type': 'text/plain' });
    response.end('ok');
  }, async (origin) => {
    await provider.fetch({ url: `${origin}/first` });
    await provider.fetch({ url: `${origin}/second` });
  });
  assert.equal(discoveries, 1);
});

test('cron URL provider honors NO_PROXY before environment and system proxies', async () => {
  let discoveries = 0;
  const provider = new CronJobHttpFetchProvider({
    env: {
      HTTP_PROXY: 'http://127.0.0.1:1',
      NO_PROXY: '127.0.0.1',
    },
    discoverProxy: async () => {
      discoveries += 1;
      return 'http://127.0.0.1:1';
    },
  });
  await withServer((_request, response) => {
    response.writeHead(200, { 'content-type': 'text/plain' });
    response.end('direct');
  }, async (origin) => {
    const result = await provider.fetch({ url: origin });
    assert.equal(result.body.content, 'direct');
  });
  assert.equal(discoveries, 0);
});

test('macOS system proxy parser reads enabled HTTP and HTTPS settings', () => {
  const settings = `
<dictionary> {
  HTTPEnable : 1
  HTTPPort : 8080
  HTTPProxy : proxy.example.test
  HTTPSEnable : 1
  HTTPSPort : 8443
  HTTPSProxy : secure-proxy.example.test
}
`;
  assert.equal(
    webFetchInternals.macSystemProxy(settings, 'http:'),
    'http://proxy.example.test:8080/',
  );
  assert.equal(
    webFetchInternals.macSystemProxy(settings, 'https:'),
    'http://secure-proxy.example.test:8443/',
  );
  assert.equal(
    webFetchInternals.macSystemProxy(settings.replace('HTTPSEnable : 1', 'HTTPSEnable : 0'), 'https:'),
    null,
  );
});

test('Windows system proxy parser supports shared and per-protocol settings', () => {
  const shared = `
    ProxyEnable    REG_DWORD    0x1
    ProxyServer    REG_SZ       proxy.example.test:7890
`;
  assert.equal(
    webFetchInternals.windowsSystemProxy(shared, 'https:'),
    'http://proxy.example.test:7890/',
  );

  const perProtocol = `
    ProxyEnable    REG_DWORD    0x00000001
    ProxyServer    REG_SZ       http=plain.example.test:8080;https=secure.example.test:8443
`;
  assert.equal(
    webFetchInternals.windowsSystemProxy(perProtocol, 'http:'),
    'http://plain.example.test:8080/',
  );
  assert.equal(
    webFetchInternals.windowsSystemProxy(perProtocol, 'https:'),
    'http://secure.example.test:8443/',
  );
  assert.equal(
    webFetchInternals.windowsSystemProxy(shared.replace('0x1', '0x0'), 'http:'),
    null,
  );
});

test('cron URL provider keeps HTML main content beyond a large navigation prefix', async () => {
  const navigation = `<nav>${'navigation '.repeat(15_000)}</nav>`;
  await withServer((_request, response) => {
    response.writeHead(200, { 'content-type': 'text/html' });
    response.end(`${navigation}<main><article><h1>Repository</h1><a href="/owner/repo">Open</a></article></main>`);
  }, async (origin) => {
    const result = await new CronJobHttpFetchProvider({ env: { NO_PROXY: '*' } })
      .fetch({ url: `${origin}/trending` });
    assert.equal(result.statusCode, 200);
    assert.equal(result.truncated, false);
    assert.doesNotMatch(result.body.content, /navigation/u);
    assert.match(result.body.content, /<h1>Repository<\/h1>/u);
    assert.match(result.body.content, new RegExp(`href="${origin}/owner/repo"`, 'u'));
  });
});

test('HTML cleanup removes executable, navigation, and menu overlay content generically', () => {
  const content = webFetchInternals.readableHtml(`
    <body>
      <header>Header</header>
      <main role="main">
        <details class="select-menu overlay"><summary>Filters</summary>${'option '.repeat(1_000)}</details>
        <article><h2>Useful content</h2><a href="./item">Item</a></article>
        <script>secret()</script>
      </main>
      <footer>Footer</footer>
    </body>
  `, new URL('https://example.test/path/page'));
  assert.doesNotMatch(content, /Header|Filters|option|secret|Footer/u);
  assert.match(content, /Useful content/u);
  assert.match(content, /href="https:\/\/example\.test\/path\/item"/u);
});
