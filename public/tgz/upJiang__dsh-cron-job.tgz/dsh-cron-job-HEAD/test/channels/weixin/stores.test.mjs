import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';

import {
  deriveWeixinBotIdentity,
  WeixinConfigStore,
} from '../../../src/channels/weixin/config-store.mjs';
import { WeixinStateStore } from '../../../src/channels/weixin/state-store.mjs';
import { assertFileMode } from '../../platform.mjs';

test('config store persists non-secret account facts atomically with restrictive permissions', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-weixin-config-'));
  const path = join(root, 'nested', 'config.json');
  const store = await new WeixinConfigStore(path).load();
  const identity = deriveWeixinBotIdentity('account@im.bot');
  await store.save({
    ...identity,
    accountId: 'account@im.bot',
    ownerUserId: 'owner-user',
    baseUrl: 'https://ilinkai.weixin.qq.com',
    createdAt: '2026-08-15T00:00:00.000Z',
  });

  const raw = await readFile(path, 'utf8');
  assert.match(raw, /"accountId": "account@im\.bot"/);
  assert.doesNotMatch(raw, /bot_token|secret-token/);
  await assertFileMode(path, 0o600);
  assert.deepEqual((await new WeixinConfigStore(path).load()).list(), store.list());
});

test('config store rejects duplicate or tampered identities', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-weixin-invalid-'));
  const path = join(root, 'config.json');
  await writeFile(path, JSON.stringify({
    version: 1,
    accounts: [{
      botId: 'wx_000000000000000000000000',
      accountId: 'real@im.bot',
      tokenRef: 'DSH_WEIXIN_BOT_TOKEN_000000000000000000000000',
      ownerUserId: 'owner',
      baseUrl: 'https://ilinkai.weixin.qq.com',
    }],
  }));
  await assert.rejects(new WeixinConfigStore(path).load(), /invalid account data/);
});

test('state store migrates v1 and retains sessions, cursor, and a bounded private route', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-weixin-state-'));
  const path = join(root, 'state.json');
  await writeFile(path, JSON.stringify({
    version: 1,
    sessions: { 'p2p:legacy': 'session-legacy' },
    seenMessageIds: ['message-legacy'],
    getUpdatesBuf: 'cursor-legacy',
  }), { recursive: true });
  const state = await new WeixinStateStore(path).load();
  await state.setSession('p2p:user', 'session-1');
  await state.markSeen('message-1');
  await state.setGetUpdatesBuf('cursor-2');
  await state.rememberPrivateRoute({
    toUserId: 'owner-user@example.com',
    contextToken: 'opaque-token/with+base64==',
    updatedAt: '2026-08-27T00:00:00.000Z',
  });

  const restored = await new WeixinStateStore(path).load();
  assert.equal(restored.sessionFor('p2p:legacy'), 'session-legacy');
  assert.equal(restored.hasSeen('message-legacy'), true);
  assert.equal(restored.sessionFor('p2p:user'), 'session-1');
  assert.equal(restored.hasSeen('message-1'), true);
  assert.equal(restored.getUpdatesBuf(), 'cursor-2');
  assert.deepEqual(restored.privateRouteFor('owner-user@example.com'), {
    toUserId: 'owner-user@example.com',
    contextToken: 'opaque-token/with+base64==',
    updatedAt: '2026-08-27T00:00:00.000Z',
  });
  assert.equal(restored.privateRouteFor('another-user'), null);
  assert.doesNotMatch(JSON.stringify(restored.snapshot()), /opaque-token|privateRoute/);
  assert.equal(JSON.parse(await readFile(path, 'utf8')).version, 2);
  await assertFileMode(path, 0o600);
});

test('state store rejects malformed private routes and removes invalid persisted values', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-weixin-route-'));
  const path = join(root, 'state.json');
  await writeFile(path, JSON.stringify({
    version: 2,
    sessions: {},
    seenMessageIds: [],
    getUpdatesBuf: '',
    privateRoute: {
      toUserId: 'owner-user',
      contextToken: 'token\nwith-control-character',
      updatedAt: '2026-08-27T00:00:00.000Z',
    },
  }));

  const state = await new WeixinStateStore(path).load();
  assert.equal(state.privateRouteFor('owner-user'), null);
  assert.equal(JSON.parse(await readFile(path, 'utf8')).privateRoute, null);
  await assert.rejects(
    state.rememberPrivateRoute({ toUserId: '../owner', contextToken: 'valid', updatedAt: new Date().toISOString() }),
    /Invalid Weixin private route/,
  );
  await assert.rejects(
    state.rememberPrivateRoute({ toUserId: 'owner', contextToken: 'x'.repeat(4_097), updatedAt: new Date().toISOString() }),
    /Invalid Weixin private route/,
  );
});
