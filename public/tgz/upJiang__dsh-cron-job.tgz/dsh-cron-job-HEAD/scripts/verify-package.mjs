import { access, readFile, readdir, stat } from 'node:fs/promises';
import { relative, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = resolve(import.meta.dirname, '..');

async function sourceFiles(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const path = resolve(directory, entry.name);
    if (entry.isDirectory()) files.push(...await sourceFiles(path));
    else if (entry.isFile() && /\.(?:m?js|json|yml)$/u.test(entry.name)) files.push(path);
  }
  return files;
}

async function readTree(directory) {
  const files = await sourceFiles(directory);
  return (await Promise.all(files.map((path) => readFile(path, 'utf8')))).join('\n');
}

function requireMatch(value, pattern, message) {
  if (!pattern.test(value)) throw new Error(message);
}

const channels = [
  'weixin', 'feishu', 'dingtalk', 'wecom', 'qq', 'slack', 'telegram', 'discord',
  'whatsapp',
];
const tools = [
  'cron_job_draft', 'cron_job_test', 'cron_job_confirm', 'cron_job_list', 'cron_job_get',
  'cron_job_update', 'cron_job_pause', 'cron_job_resume', 'cron_job_run', 'cron_job_cancel',
  'cron_job_delete', 'cron_job_runs',
];
const required = [
  'lib/index.js',
  'lib/client.js',
  'bin/dsh-cron-job.mjs',
  'cordis.patch.yml',
  'README.md',
  'README.en.md',
  'THIRD_PARTY_NOTICES.md',
  'plugin-src/client/cron/index.js',
  'plugin-src/client/cron/styles.js',
  'plugin-src/host/cron/domain.mjs',
  'plugin-src/host/cron/harness-runner.mjs',
  'plugin-src/host/cron/notifications.mjs',
  'plugin-src/host/cron/rpc.mjs',
  'plugin-src/host/cron/schedule.mjs',
  'plugin-src/host/cron/service.mjs',
  'plugin-src/host/cron/store.mjs',
  'plugin-src/host/cron/tools.mjs',
  ...channels.flatMap((channel) => [
    `plugin-src/host/channels/${channel}/index.mjs`,
    `src/channels/${channel}/${channel}-runtime.mjs`,
  ]),
];
await Promise.all(required.map((path) => access(resolve(root, path))));

const [
  manifestText,
  lockText,
  patch,
  host,
  client,
  hostSource,
  clientSource,
  cronSource,
  cliSource,
  executable,
] = await Promise.all([
  readFile(resolve(root, 'package.json'), 'utf8'),
  readFile(resolve(root, 'package-lock.json'), 'utf8'),
  readFile(resolve(root, 'cordis.patch.yml'), 'utf8'),
  readFile(resolve(root, 'lib/index.js'), 'utf8'),
  readFile(resolve(root, 'lib/client.js'), 'utf8'),
  readTree(resolve(root, 'plugin-src/host')),
  readTree(resolve(root, 'plugin-src/client')),
  readTree(resolve(root, 'plugin-src/host/cron')),
  readFile(resolve(root, 'bin/dsh-cron-job.mjs'), 'utf8'),
  stat(resolve(root, 'bin/dsh-cron-job.mjs')),
]);
const manifest = JSON.parse(manifestText);
const lock = JSON.parse(lockText);

if (manifest.name !== 'dsh-cron-job') throw new Error('package name must be dsh-cron-job');
if (manifest.bin?.['dsh-cron-job'] !== 'bin/dsh-cron-job.mjs') {
  throw new Error('package manifest must publish the dsh-cron-job executable');
}
if (manifest.dsh?.bundle?.patch !== './cordis.patch.yml') {
  throw new Error('package manifest must publish a DSH bundle patch');
}
if (manifest.dsh?.client?.platform !== 'web') {
  throw new Error('package manifest must publish a web client entry');
}
if (!/^#!\/usr\/bin\/env node\r?\n/u.test(cliSource)) {
  throw new Error('dsh-cron-job CLI must start with the Node.js shebang');
}
if (process.platform !== 'win32' && (executable.mode & 0o111) === 0) {
  throw new Error('dsh-cron-job CLI is not executable');
}

// DSH service packages use module-local Symbols. Bundling a second copy breaks Host lookup.
for (const section of ['dependencies', 'devDependencies', 'optionalDependencies', 'peerDependencies']) {
  for (const name of Object.keys(manifest[section] ?? {})) {
    if (/^@deepseek-ai\/dsh-/u.test(name)) {
      throw new Error(`${name} must not be declared in ${section}; use the Host copy`);
    }
  }
}
const bundledDependencies = manifest.bundleDependencies ?? manifest.bundledDependencies ?? [];
for (const name of Array.isArray(bundledDependencies) ? bundledDependencies : []) {
  if (/^@deepseek-ai\/dsh-/u.test(name)) throw new Error(`${name} must not be bundled`);
}
const forbiddenLockPaths = Object.keys(lock.packages ?? {}).filter((path) => (
  /(?:^|\/)node_modules\/@deepseek-ai\/dsh-[^/]+(?:\/|$)/u.test(path)
));
if (forbiddenLockPaths.length > 0) {
  throw new Error(`package lock installs DSH runtime packages: ${forbiddenLockPaths.join(', ')}`);
}

const pinnedDependencies = {
  '@tencent-connect/qqbot-connector': '1.2.0',
  '@tencent-connect/qqbot-nodejs': '1.0.4',
  '@wecom/aibot-node-sdk': '1.0.7',
  'cron-parser': '5.10.0',
  'dingtalk-stream': '2.1.4',
  parse5: '8.0.0',
  qrcode: '1.5.4',
};
const pinnedBuildDependencies = {
  '@larksuiteoapi/node-sdk': '1.73.0',
  '@whiskeysockets/baileys': '7.0.0-rc14',
  esbuild: '0.25.9',
  'https-proxy-agent': '5.0.1',
  'lucide-react': '0.468.0',
  react: '18.3.1',
  'react-dom': '18.3.1',
  'react-test-renderer': '18.3.1',
};
for (const [name, version] of Object.entries(pinnedDependencies)) {
  if (manifest.dependencies?.[name] !== version) {
    throw new Error(`${name} must be a pinned runtime dependency at ${version}`);
  }
}
for (const [name, version] of Object.entries(pinnedBuildDependencies)) {
  if (manifest.devDependencies?.[name] !== version) {
    throw new Error(`${name} must be a pinned build dependency at ${version}`);
  }
}
if (lock.packages?.['node_modules/protobufjs']?.dev !== true) {
  throw new Error('protobufjs must remain build-only in the package lock');
}

requireMatch(patch, /id:\s*dsh-cron-job[\s\S]*name:\s*['"]dsh-cron-job['"]/u,
  'bundle patch must activate dsh-cron-job');
requireMatch(client, /__ModuleLoader__\.load\(\{\s*id:\s*["']dsh-cron-job["']/u,
  'client bundle must register the dsh-cron-job loader id');
requireMatch(clientSource, /ctx\.slots\.inject\(\s*['"]settings\.section['"]/u,
  'client must register a settings section');
requireMatch(clientSource, /id:\s*['"]dsh-cron-job['"]/u,
  'client settings section must use the dsh-cron-job id');
requireMatch(clientSource, /label:\s*\(\)\s*=>\s*t\(\s*['"]定时任务['"]\s*\)/u,
  'client settings section must use the scheduled-job label');
requireMatch(clientSource, /aria-haspopup['"]?\s*:\s*['"]listbox['"]/u,
  'client must expose accessible listbox controls');
if (/<select\b/iu.test(clientSource) || /React\.createElement\(\s*['"]select['"]/u.test(clientSource)) {
  throw new Error('client must not use native select controls');
}
if (clientSource.includes('settings.plugins.tab')) {
  throw new Error('client still contains the legacy Plugins-tab registration');
}

for (const channel of channels) {
  requireMatch(hostSource, new RegExp(`channels/${channel}/index\\.mjs`, 'u'),
    `Host source does not compose ${channel}`);
  requireMatch(hostSource, new RegExp(`\\['${channel}',\\s*start[A-Z]`, 'u'),
    `Host source does not start ${channel}`);
}
requireMatch(hostSource, /notificationTargets\s*\(/u,
  'channel controllers must expose notificationTargets');
requireMatch(hostSource, /sendNotification\s*\(/u,
  'channel controllers must expose sendNotification');
requireMatch(hostSource, /installCronJob\s*\(/u, 'Host must install the Cron service');
requireMatch(cronSource, /CRON_JOB_RPC_CHANNEL\s*=\s*['"]\/cron-job['"]/u,
  'Cron RPC channel is missing');
for (const name of tools) {
  if (!cronSource.includes(`'${name}'`)) throw new Error(`Cron model tool ${name} is missing`);
}
for (const marker of [
  'successfulPreflight', 'configFingerprint', 'targetVersions', 'skipMissedOnStartup',
  'job-running', 'partial_failure', 'AGENTS.md',
]) {
  if (!cronSource.includes(marker)) throw new Error(`Cron safety marker ${marker} is missing`);
}

for (const name of ['@xmanrui/dsh-feishu', '@xmanrui/dsh-weixin', '@xmanrui/dsh-dingtalk']) {
  if (host.includes(name) || manifestText.includes(name) || lockText.includes(name)) {
    throw new Error(`published package still depends on ${name}`);
  }
}
if (/(?:from\s*|import\s*\(|require\s*\()\s*["'](?:@larksuiteoapi\/node-sdk|@whiskeysockets\/baileys|https-proxy-agent|protobufjs)(?:\/[^"']*)?["']/u.test(host)) {
  throw new Error('Host bundle imports a build-only SDK at runtime');
}
if (/AI Office|Office Connector|office-harness\.v1|dsh-office/iu.test(hostSource + clientSource)) {
  throw new Error('AI Office Connector code remains in the published plugin');
}

const compatibilityOldIdentity = new Set([
  'src/channels/shared/inbound-file.mjs',
  'src/channels/shared/semantic/artifact.mjs',
  'src/channels/shared/connection-test.mjs',
]);
const identityFiles = [
  ...await sourceFiles(resolve(root, 'src')),
  ...await sourceFiles(resolve(root, 'plugin-src')),
];
for (const path of identityFiles) {
  const source = await readFile(path, 'utf8');
  if (!/dsh-im|@xmanrui\/dsh-im|DSH-IM/u.test(source)) continue;
  const local = relative(root, path).replaceAll('\\', '/');
  if (!compatibilityOldIdentity.has(local)) {
    throw new Error(`legacy dsh-im identity remains outside the compatibility allowlist: ${local}`);
  }
}
if (!cliSource.includes("'@xmanrui/dsh-im'")) {
  throw new Error('CLI must retain the legacy package migration entry');
}
if (/\/Users\/|[A-Za-z]:\\\\Users\\\\|company-newapi|公司-newapi|ccswitch/iu.test(
  hostSource + clientSource + cliSource + manifestText,
)) {
  throw new Error('published code contains a personal path or environment-specific provider value');
}
if (/private-bot-token|must-be-rolled-back|DEEPSEEK_API_KEY=|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/u.test(client + host)) {
  throw new Error('built artifacts contain a test or credential marker');
}

await import(pathToFileURL(resolve(root, 'lib/index.js')).href);
console.log('Verified dsh-cron-job package artifacts.');
