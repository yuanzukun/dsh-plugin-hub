import { apply as applyDingtalk } from './channels/dingtalk/index.mjs';
import { apply as applyDiscord } from './channels/discord/index.mjs';
import { apply as applyFeishu } from './channels/feishu/index.mjs';
import { apply as applyQq } from './channels/qq/index.mjs';
import { apply as applySlack } from './channels/slack/index.mjs';
import { apply as applyTelegram } from './channels/telegram/index.mjs';
import { apply as applyWecom } from './channels/wecom/index.mjs';
import { apply as applyWeixin } from './channels/weixin/index.mjs';
import { apply as applyWhatsapp } from './channels/whatsapp/index.mjs';
import { installCronJob } from './cron/index.mjs';
import { ConversationRouteRegistry } from '../../src/channels/shared/conversation-route.mjs';
import { installOutboundArtifactTool } from '../../src/channels/shared/semantic/artifact.mjs';
import { setImHostLanguage } from '../../src/channels/shared/i18n.mjs';

export const name = 'dsh-cron-job-host';
export const inject = [
  'connection',
  'credentials',
  'webServer',
  'typertGateway',
  'web',
  'tools',
  'systemPrompt',
];

function channelConfig(config, name, controllers, conversationRoutes) {
  const channel = config[name] ?? {};
  const resolved = config.rpcAuthority === undefined
    ? channel
    : { ...channel, rpcAuthority: config.rpcAuthority };
  return {
    ...resolved,
    conversationRoutes,
    onController(controller) {
      controllers.set(name, controller);
      channel.onController?.(controller);
    },
  };
}

export function createImHostPlugin(internals = {}) {
  const startFeishu = internals.applyFeishu ?? applyFeishu;
  const startWeixin = internals.applyWeixin ?? applyWeixin;
  const startDingtalk = internals.applyDingtalk ?? applyDingtalk;
  const startWecom = internals.applyWecom ?? applyWecom;
  const startQq = internals.applyQq ?? applyQq;
  const startSlack = internals.applySlack ?? applySlack;
  const startTelegram = internals.applyTelegram ?? applyTelegram;
  const startDiscord = internals.applyDiscord ?? applyDiscord;
  const startWhatsapp = internals.applyWhatsapp ?? applyWhatsapp;
  const startCron = internals.installCronJob ?? installCronJob;
  const channels = [
    ['feishu', startFeishu],
    ['weixin', startWeixin],
    ['dingtalk', startDingtalk],
    ['wecom', startWecom],
    ['qq', startQq],
    ['slack', startSlack],
    ['telegram', startTelegram],
    ['discord', startDiscord],
    ['whatsapp', startWhatsapp],
  ];
  return Object.freeze({
    name,
    inject,
    async apply(ctx, config = {}) {
      setImHostLanguage(config.language ?? process.env.DSH_IM_LANGUAGE);
      if (typeof ctx?.inject === 'function') {
        ctx.inject(['tools', 'systemPrompt'], (artifactCtx) => {
          installOutboundArtifactTool(artifactCtx);
        });
      } else {
        installOutboundArtifactTool(ctx);
      }
      const logger = typeof ctx?.logger === 'function'
        ? ctx.logger(name)
        : (ctx?.logger ?? console);
      const failures = [];
      const controllers = new Map();
      const conversationRoutes = internals.conversationRoutes ?? new ConversationRouteRegistry();
      for (const [channel, start] of channels) {
        try {
          await start(ctx, channelConfig(config, channel, controllers, conversationRoutes));
        } catch (error) {
          failures.push(error);
          logger.error?.(`[dsh-cron-job] failed to activate ${channel}; continuing with the remaining channels`, error);
        }
      }
      if (failures.length === channels.length) {
        throw new AggregateError(failures, 'dsh-cron-job failed to activate every channel');
      }
      await startCron(ctx, controllers, {
        ...(config.cron ?? {}),
        ...(config.rpcAuthority === undefined ? {} : { rpcAuthority: config.rpcAuthority }),
      }, { conversationRoutes, ...(internals.cron ?? {}) });
    },
  });
}

export async function apply(ctx, config = {}) {
  return createImHostPlugin().apply(ctx, config);
}
