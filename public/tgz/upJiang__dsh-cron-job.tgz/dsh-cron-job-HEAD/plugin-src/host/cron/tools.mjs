import { publicTask } from './notifications.mjs';

const ID = { type: 'string', description: 'Exact draft or job id returned by a cron job tool.' };
const OUTPUT = {
  schema: { type: 'object', additionalProperties: true },
  render: (_args, value) => [{ type: 'text', text: JSON.stringify(publicTask(value)) }],
};

const SCHEDULE = {
  description: 'Execution rule. Cron uses a standard five-field expression; once uses RFC3339; interval is seconds.',
  oneOf: [
    {
      type: 'object', additionalProperties: false,
      properties: {
        type: { type: 'string', const: 'cron' },
        expression: { type: 'string', description: 'Standard five-field cron expression, for example 30 8 * * *.' },
      },
      required: ['type', 'expression'],
    },
    {
      type: 'object', additionalProperties: false,
      properties: {
        type: { type: 'string', const: 'once' },
        at: { type: 'string', description: 'RFC3339 date-time with an explicit offset.' },
      },
      required: ['type', 'at'],
    },
    {
      type: 'object', additionalProperties: false,
      properties: {
        type: { type: 'string', const: 'interval' },
        seconds: { type: 'integer', description: 'Interval from 60 to 31536000 seconds.' },
      },
      required: ['type', 'seconds'],
    },
  ],
};

const TARGET = {
  description: 'Notification target. In an IM-originated request use exactly {"currentConversation":true}; never guess a bot id or recipient.',
  oneOf: [
    {
      type: 'object', additionalProperties: false,
      properties: {
        currentConversation: {
          type: 'boolean', const: true,
          description: 'Safely select the communication conversation that initiated this Agent turn.',
        },
      },
      required: ['currentConversation'],
    },
    {
      type: 'object', additionalProperties: false,
      properties: {
        targetRef: { type: 'string', description: 'Opaque target reference returned by the cron job catalog.' },
      },
      required: ['targetRef'],
    },
    {
      type: 'object', additionalProperties: false,
      properties: {
        channel: {
          type: 'string',
          enum: ['weixin', 'feishu', 'wecom', 'qq', 'slack', 'telegram', 'discord', 'whatsapp'],
        },
        botId: { type: 'string', description: 'Exact configured bot id.' },
        recipientId: { type: 'string', description: 'Exact platform recipient id supplied by the user.' },
      },
      required: ['channel', 'botId', 'recipientId'],
    },
  ],
};

const TASK = {
  type: 'object',
  additionalProperties: false,
  properties: {
    name: { type: 'string', description: 'Short task name.' },
    description: { type: 'string', description: 'Optional user-facing description.' },
    schedule: SCHEDULE,
    timezone: { type: 'string', description: 'IANA time zone, for example Asia/Shanghai.' },
    workspace: { type: 'string', description: 'Absolute workspace directory visible to DSH.' },
    prompt: { type: 'string', description: 'Complete Agent instructions for every formal run.' },
    model: {
      type: 'object', additionalProperties: false,
      properties: {
        provider: { type: 'string', description: 'Exact DSH provider id.' },
        model: { type: 'string', description: 'Exact model id.' },
        reasoningEffort: { type: 'string', description: 'Optional reasoning effort supported by this model.' },
      },
      required: ['provider', 'model'],
    },
    toolPolicy: {
      type: 'object', additionalProperties: false,
      properties: {
        web: { type: 'boolean' },
        search: { type: 'boolean' },
        fetch: { type: 'boolean' },
        rss: { type: 'boolean' },
        deny: { type: 'array', items: { type: 'string' } },
      },
    },
    sources: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: false,
        properties: {
          type: { type: 'string', enum: ['web', 'rss', 'search', 'fetch'] },
          url: { type: 'string', description: 'Optional HTTP or HTTPS source URL.' },
        },
        required: ['type'],
      },
    },
    targets: {
      type: 'array',
      description: 'One or more notification targets. The fields notifications and notificationTargets are invalid.',
      items: TARGET,
    },
    timeoutMs: { type: 'integer', description: 'Run timeout from 10000 to 3600000 milliseconds.' },
  },
  required: ['name', 'schedule', 'timezone', 'workspace', 'prompt', 'targets'],
};

function tool(name, description, parameters, execute) {
  return Object.freeze({ name, description, parameters, output: OUTPUT, execute });
}

export function cronJobToolDefinitions(service) {
  return [
    tool(
      'cron_job_draft',
      'Create a validated scheduled-job draft from the user request. This never enables a job. Include schedule, timezone, workspace, prompt, optional model, read-only source/tool policy, and every notification target.',
      {
        type: 'object', additionalProperties: false,
        properties: { task: TASK }, required: ['task'],
      },
      (args, exec) => service.draft(args.task, {
        sessionId: exec?.agent?.id ?? exec?.agent?.sessionId,
      }),
    ),
    tool('cron_job_test', 'Run the mandatory full preflight for a draft. It creates isolated DSH Sessions, calls the model and data sources, and sends a marked test message to every target. It never enables the job.', {
      type: 'object', additionalProperties: false, properties: { id: ID }, required: ['id'],
    }, (args) => service.testDraft(args.id)),
    tool('cron_job_confirm', 'Confirm and enable a draft only when its exact current fingerprint passed the full preflight. Never call this before showing the ready draft to the user and receiving confirmation.', {
      type: 'object', additionalProperties: false, properties: { id: ID }, required: ['id'],
    }, (args) => service.confirmDraft(args.id)),
    tool('cron_job_list', 'List scheduled jobs and drafts with optional search, state, and pagination.', {
      type: 'object', additionalProperties: false, properties: {
        query: { type: 'string' }, status: { type: 'string' },
        page: { type: 'number' }, pageSize: { type: 'number' },
      },
    }, (args) => Promise.resolve(service.snapshot(args))),
    tool('cron_job_get', 'Get one scheduled job or draft.', {
      type: 'object', additionalProperties: false, properties: { id: ID }, required: ['id'],
    }, (args) => Promise.resolve(service.get(args.id))),
    tool('cron_job_update', 'Update a draft or job. Critical active-job changes create a new draft that must pass preflight and confirmation before replacing the active version.', {
      type: 'object', additionalProperties: false,
      properties: { id: ID, changes: { type: 'object' }, draft: { type: 'boolean' } },
      required: ['id', 'changes'],
    }, (args) => args.draft ? service.updateDraft(args.id, args.changes) : service.updateJob(args.id, args.changes)),
    tool('cron_job_pause', 'Pause an active scheduled job.', {
      type: 'object', additionalProperties: false, properties: { id: ID }, required: ['id'],
    }, (args) => service.pause(args.id)),
    tool('cron_job_resume', 'Resume a paused scheduled job and calculate its next future execution.', {
      type: 'object', additionalProperties: false, properties: { id: ID }, required: ['id'],
    }, (args) => service.resume(args.id)),
    tool('cron_job_run', 'Run an enabled or paused job immediately in a new isolated DSH Session without changing its schedule.', {
      type: 'object', additionalProperties: false, properties: { id: ID }, required: ['id'],
    }, (args) => service.run(args.id)),
    tool('cron_job_cancel', 'Cancel the currently running execution of a job.', {
      type: 'object', additionalProperties: false, properties: { id: ID }, required: ['id'],
    }, (args) => service.cancel(args.id)),
    tool('cron_job_delete', 'Delete a job or draft only after direct user confirmation.', {
      type: 'object', additionalProperties: false,
      properties: { id: ID, confirm: { type: 'boolean' } }, required: ['id', 'confirm'],
    }, (args) => {
      if (args.confirm !== true) throw new Error('cron_job_delete requires confirm=true');
      return service.delete(args.id);
    }),
    tool('cron_job_runs', 'List formal runs and optional preflight test records for a job.', {
      type: 'object', additionalProperties: false,
      properties: { id: ID, page: { type: 'number' }, pageSize: { type: 'number' }, includeTests: { type: 'boolean' } },
      required: ['id'],
    }, (args) => Promise.resolve(service.runs(args.id, args))),
  ];
}

export function installCronJobTools(ctx, service) {
  if (typeof ctx?.tools?.register !== 'function') return false;
  for (const definition of cronJobToolDefinitions(service)) ctx.tools.register(definition);
  ctx.systemPrompt?.section?.({
    name: 'tool:cron-job',
    order: 114,
    text: 'Use cron_job_draft to turn natural-language scheduling requests into structured previews. Put notification destinations only in task.targets; notifications and notificationTargets are invalid. When the request comes from a communication channel and the user wants delivery in that same conversation, use targets: [{ currentConversation: true }]; never guess or expose a bot id or recipient. A job must pass cron_job_test and then receive explicit user confirmation before cron_job_confirm. Never imply a draft or failed test is active. Critical updates require a new full preflight.',
  });
  return true;
}
