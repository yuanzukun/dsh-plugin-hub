import { CronExpressionParser } from 'cron-parser';

export function nextRunAt(schedule, timezone, { after = new Date(), intervalAnchor } = {}) {
  const afterMs = after instanceof Date ? after.getTime() : new Date(after).getTime();
  if (!Number.isFinite(afterMs)) throw new TypeError('after must be a valid date');
  if (schedule.type === 'once') {
    const at = Date.parse(schedule.at);
    return at > afterMs ? new Date(at).toISOString() : null;
  }
  if (schedule.type === 'interval') {
    const step = schedule.seconds * 1_000;
    const anchor = Date.parse(intervalAnchor ?? new Date(afterMs).toISOString());
    const elapsed = Math.max(0, afterMs - anchor);
    return new Date(anchor + (Math.floor(elapsed / step) + 1) * step).toISOString();
  }
  return CronExpressionParser.parse(schedule.expression, {
    currentDate: new Date(afterMs),
    tz: timezone,
  }).next().toDate().toISOString();
}

export class CronScheduler {
  #service;
  #clock;
  #timer = null;
  #closed = false;

  constructor(service, { clock = globalThis } = {}) {
    this.#service = service;
    this.#clock = clock;
  }

  start() {
    this.reschedule();
    return this;
  }

  reschedule() {
    if (this.#closed) return;
    if (this.#timer !== null) this.#clock.clearTimeout(this.#timer);
    this.#timer = null;
    const next = this.#service.nextScheduledJob();
    if (!next) return;
    const wait = Math.max(0, Math.min(Date.parse(next.nextRunAt) - Date.now(), 2_147_000_000));
    this.#timer = this.#clock.setTimeout(() => {
      this.#timer = null;
      void this.#tick();
    }, wait);
    this.#timer?.unref?.();
  }

  async #tick() {
    if (this.#closed) return;
    await this.#service.runDueJobs(new Date()).catch(() => undefined);
    this.reschedule();
  }

  close() {
    this.#closed = true;
    if (this.#timer !== null) this.#clock.clearTimeout(this.#timer);
    this.#timer = null;
  }
}
