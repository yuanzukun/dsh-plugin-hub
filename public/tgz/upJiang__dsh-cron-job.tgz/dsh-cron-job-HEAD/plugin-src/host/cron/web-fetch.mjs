import { request as httpRequest } from 'node:http';
import { request as httpsRequest } from 'node:https';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

import HttpsProxyAgent from 'https-proxy-agent';
import { parse, serializeOuter } from 'parse5';

const PROVIDER_ID = 'dsh-cron-job-http';
const MAX_URL_LENGTH = 2_048;
const MAX_RESPONSE_BYTES = 5_000_000;
const MAX_BODY_CHARS = 100_000;
const DEFAULT_TIMEOUT_MS = 30_000;
const MAX_REDIRECTS = 5;
const USER_AGENT = 'dsh-cron-job/0.1 (+https://github.com/upJiang/dsh-cron-job)';
const execFilePromise = promisify(execFile);
const OMITTED_HTML_ELEMENTS = new Set([
  'aside', 'canvas', 'dialog', 'footer', 'form', 'header', 'iframe', 'nav',
  'noscript', 'object', 'script', 'style', 'svg', 'template',
]);
const KEPT_HTML_ATTRIBUTES = new Set(['alt', 'colspan', 'href', 'rowspan', 'src', 'title']);
const MENU_CONTAINER_TOKEN = /(?:^|[\s_-])(?:dropdown|menu|overlay|picker|popover|selector)(?:$|[\s_-])/iu;

function proxyUrl(protocol, host, port) {
  if (typeof host !== 'string' || !host.trim()) return null;
  const normalizedPort = Number(port);
  if (!Number.isSafeInteger(normalizedPort) || normalizedPort < 1 || normalizedPort > 65_535) {
    return null;
  }
  const hostname = host.trim().includes(':') && !host.trim().startsWith('[')
    ? `[${host.trim()}]`
    : host.trim();
  try {
    return new URL(`${protocol}://${hostname}:${normalizedPort}`).toString();
  } catch {
    return null;
  }
}

function macSystemProxy(text, protocol) {
  const values = new Map();
  for (const line of String(text).split(/\r?\n/u)) {
    const match = line.match(/^\s*([A-Za-z]+)\s*:\s*(.*?)\s*$/u);
    if (match) values.set(match[1], match[2]);
  }
  const prefix = protocol === 'https:' ? 'HTTPS' : 'HTTP';
  if (values.get(`${prefix}Enable`) !== '1') return null;
  return proxyUrl('http', values.get(`${prefix}Proxy`), values.get(`${prefix}Port`));
}

function windowsProxyValue(text, key) {
  const match = String(text).match(new RegExp(`^\\s*${key}\\s+REG_(?:DWORD|SZ)\\s+(.+?)\\s*$`, 'imu'));
  return match?.[1]?.trim() ?? null;
}

function windowsSystemProxy(text, protocol) {
  if (!/^0x0*1$/iu.test(windowsProxyValue(text, 'ProxyEnable') ?? '')) return null;
  const configured = windowsProxyValue(text, 'ProxyServer');
  if (!configured) return null;
  const scheme = protocol === 'https:' ? 'https' : 'http';
  const entries = configured.includes('=')
    ? Object.fromEntries(configured.split(';').map((entry) => entry.trim()).filter(Boolean)
        .map((entry) => entry.split('=', 2).map((part) => part.trim())))
    : { http: configured, https: configured };
  const selected = entries[scheme] ?? entries.http;
  if (!selected) return null;
  try {
    const normalized = new URL(selected.includes('://') ? selected : `http://${selected}`);
    return proxyUrl(normalized.protocol.replace(':', ''), normalized.hostname, normalized.port);
  } catch {
    return null;
  }
}

async function discoverSystemProxy(platform, protocol, run = execFilePromise) {
  try {
    if (platform === 'darwin') {
      const { stdout } = await run('/usr/sbin/scutil', ['--proxy'], {
        encoding: 'utf8', timeout: 5_000, maxBuffer: 256_000,
      });
      return macSystemProxy(stdout, protocol);
    }
    if (platform === 'win32') {
      const { stdout } = await run('reg.exe', [
        'query', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings',
      ], { encoding: 'utf8', timeout: 5_000, maxBuffer: 256_000, windowsHide: true });
      return windowsSystemProxy(stdout, protocol);
    }
  } catch {
    // System proxy discovery is optional. A missing command, disabled proxy, or
    // unreadable user setting falls back to the ordinary direct request.
  }
  return null;
}

function proxyEnvironment(url, env = process.env) {
  const noProxy = env.NO_PROXY ?? env.no_proxy ?? '';
  const bypass = noProxy.split(/[,;]/u).map((item) => item.trim().toLowerCase()).filter(Boolean)
    .some((entry) => {
      if (entry === '*') return true;
      const [host, port] = entry.split(':', 2);
      if (port && port !== url.port) return false;
      const hostname = url.hostname.toLowerCase();
      if (host.includes('*')) {
        const escaped = host.split('*')
          .map((part) => part.replace(/[.*+?^${}()|[\]\\]/gu, '\\$&'))
          .join('.*');
        return new RegExp(`^${escaped}$`, 'u').test(hostname);
      }
      return host.startsWith('.')
        ? hostname.endsWith(host)
        : hostname === host || hostname.endsWith(`.${host}`);
    });
  if (bypass) return null;
  const value = url.protocol === 'https:'
    ? (env.HTTPS_PROXY ?? env.https_proxy ?? env.HTTP_PROXY ?? env.http_proxy)
    : (env.HTTP_PROXY ?? env.http_proxy);
  return value?.trim() || null;
}

function nodeResponse(statusCode, headers, bytes) {
  const normalized = new Map(Object.entries(headers).map(([key, value]) => [
    key.toLowerCase(), Array.isArray(value) ? value.join(', ') : String(value ?? ''),
  ]));
  return {
    status: statusCode,
    headers: { get: (key) => normalized.get(String(key).toLowerCase()) ?? null },
    arrayBuffer: async () => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
    body: null,
  };
}

function requestViaProxy(url, signal, proxy) {
  if (!proxy) return null;
  return new Promise((resolve, reject) => {
    const request = (url.protocol === 'https:' ? httpsRequest : httpRequest)(url, {
      method: 'GET',
      agent: new HttpsProxyAgent(proxy),
      headers: {
        'user-agent': USER_AGENT,
        accept: 'text/html,application/xhtml+xml,text/*;q=0.9,application/json;q=0.8',
      },
      signal,
    }, (response) => {
      const chunks = [];
      response.on('data', (chunk) => chunks.push(chunk));
      response.on('end', () => resolve(nodeResponse(
        response.statusCode ?? 0,
        response.headers,
        Buffer.concat(chunks),
      )));
      response.on('error', reject);
    });
    request.on('error', reject);
    request.end();
  });
}

async function requestUrl(url, signal, proxy) {
  const proxied = requestViaProxy(url, signal, proxy);
  if (proxied) return proxied;
  return globalThis.fetch(url, {
    method: 'GET',
    redirect: 'manual',
    headers: {
      'user-agent': USER_AGENT,
      accept: 'text/html,application/xhtml+xml,text/*;q=0.9,application/json;q=0.8',
    },
    signal,
  });
}

function webError(message, code) {
  const error = new Error(message);
  error.code = code;
  return error;
}

function validateUrl(value) {
  if (typeof value !== 'string' || !value.trim() || value.length > MAX_URL_LENGTH) {
    throw webError('web fetch URL is invalid', 'WEB_INVALID_URL');
  }
  let url;
  try {
    url = new URL(value);
  } catch {
    throw webError('web fetch URL is invalid', 'WEB_INVALID_URL');
  }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) {
    throw webError('web fetch accepts only HTTP(S) URLs without embedded credentials', 'WEB_URL_BLOCKED');
  }
  return url;
}

function contentKind(contentType) {
  const mediaType = String(contentType ?? '').split(';', 1)[0].trim().toLowerCase();
  if (mediaType === 'text/html' || mediaType === 'application/xhtml+xml') return 'html';
  if (mediaType.startsWith('text/') || mediaType === 'application/json'
    || mediaType === 'application/xml' || mediaType === 'application/rss+xml'
    || mediaType === 'application/atom+xml') return 'text';
  throw webError(`unsupported content type "${mediaType || 'unknown'}"`, 'WEB_UNSUPPORTED_CONTENT_TYPE');
}

function htmlAttribute(node, name) {
  return node?.attrs?.find((attribute) => attribute.name === name)?.value ?? '';
}

function firstHtmlElement(root, predicate) {
  const pending = [root];
  while (pending.length > 0) {
    const node = pending.pop();
    if (predicate(node)) return node;
    if (Array.isArray(node?.childNodes)) pending.push(...node.childNodes.toReversed());
  }
  return null;
}

function omittedHtmlElement(node) {
  if (OMITTED_HTML_ELEMENTS.has(node?.tagName)) return true;
  if (node?.tagName !== 'details') return false;
  return MENU_CONTAINER_TOKEN.test([
    htmlAttribute(node, 'class'),
    htmlAttribute(node, 'id'),
    htmlAttribute(node, 'role'),
  ].join(' '));
}

function absoluteHtmlReference(value, baseUrl) {
  if (!value) return null;
  try {
    const resolved = new URL(value, baseUrl);
    return ['http:', 'https:'].includes(resolved.protocol) ? resolved.toString() : null;
  } catch {
    return null;
  }
}

function cleanHtmlTree(node, baseUrl) {
  if (!Array.isArray(node?.childNodes)) return;
  node.childNodes = node.childNodes.filter((child) => !omittedHtmlElement(child));
  for (const child of node.childNodes) {
    child.parentNode = node;
    if (Array.isArray(child.attrs)) {
      child.attrs = child.attrs.flatMap((attribute) => {
        if (!KEPT_HTML_ATTRIBUTES.has(attribute.name)) return [];
        if (!['href', 'src'].includes(attribute.name)) return [attribute];
        const value = absoluteHtmlReference(attribute.value, baseUrl);
        return value ? [{ ...attribute, value }] : [];
      });
    }
    cleanHtmlTree(child, baseUrl);
  }
}

function readableHtml(html, baseUrl) {
  try {
    const document = parse(html);
    const main = firstHtmlElement(document, (node) => node?.tagName === 'main')
      ?? firstHtmlElement(document, (node) => htmlAttribute(node, 'role') === 'main')
      ?? firstHtmlElement(document, (node) => node?.tagName === 'body');
    if (!main) return html;
    cleanHtmlTree(main, baseUrl);
    const content = serializeOuter(main).trim();
    return content || html;
  } catch {
    return html;
  }
}

function requestSignal(parent, timeoutMs) {
  const controller = new AbortController();
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);
  const abort = () => controller.abort(parent.reason);
  if (parent) {
    if (parent.aborted) abort();
    else parent.addEventListener('abort', abort, { once: true });
  }
  return {
    signal: controller.signal,
    timedOut: () => timedOut,
    close() {
      clearTimeout(timer);
      parent?.removeEventListener('abort', abort);
    },
  };
}

async function readResponse(response, url) {
  const kind = contentKind(response.headers.get('content-type'));
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (bytes.byteLength > MAX_RESPONSE_BYTES) {
    throw webError('web fetch response exceeds the size limit', 'WEB_RESPONSE_TOO_LARGE');
  }
  const decoded = new TextDecoder().decode(bytes);
  const content = kind === 'html' ? readableHtml(decoded, url) : decoded;
  const truncated = content.length > MAX_BODY_CHARS;
  return {
    url: url.toString(),
    statusCode: response.status,
    body: { kind, content: truncated ? content.slice(0, MAX_BODY_CHARS) : content },
    truncated,
  };
}

async function fetchUrl(initialUrl, parentSignal, resolveProxy) {
  let current = validateUrl(initialUrl);
  let redirects = 0;
  const request = requestSignal(parentSignal, DEFAULT_TIMEOUT_MS);
  try {
    for (;;) {
      let response;
      try {
        response = await requestUrl(current, request.signal, await resolveProxy(current));
      } catch (error) {
        if (parentSignal?.aborted) throw webError('web fetch aborted', 'WEB_ABORTED');
        if (request.timedOut()) throw webError('web fetch timed out', 'WEB_FETCH_TIMEOUT');
        throw webError('web fetch request failed', 'WEB_PROVIDER_ERROR');
      }
      if (![301, 302, 303, 307, 308].includes(response.status)) {
        return readResponse(response, current);
      }
      if (redirects >= MAX_REDIRECTS) {
        await response.body?.cancel();
        throw webError('web fetch exceeded the redirect limit', 'WEB_REDIRECT_BLOCKED');
      }
      const location = response.headers.get('location');
      await response.body?.cancel();
      if (!location) throw webError('web fetch redirect has no location', 'WEB_PROVIDER_ERROR');
      const next = validateUrl(new URL(location, current).toString());
      if (next.origin !== current.origin) {
        throw webError('web fetch does not follow cross-origin redirects', 'WEB_REDIRECT_BLOCKED');
      }
      current = next;
      redirects += 1;
    }
  } finally {
    request.close();
  }
}

export class CronJobHttpFetchProvider {
  id = PROVIDER_ID;

  #platform;
  #env;
  #discoverProxy;
  #systemProxies = new Map();

  constructor({
    platform = process.platform,
    env = process.env,
    discoverProxy = discoverSystemProxy,
  } = {}) {
    this.#platform = platform;
    this.#env = env;
    this.#discoverProxy = discoverProxy;
  }

  available() {
    return typeof globalThis.fetch === 'function';
  }

  fetch(request, signal) {
    return fetchUrl(request?.url, signal, (url) => this.#proxyFor(url));
  }

  async #proxyFor(url) {
    const configured = proxyEnvironment(url, this.#env);
    if (configured) return configured;
    const noProxy = this.#env.NO_PROXY ?? this.#env.no_proxy ?? '';
    if (proxyEnvironment(url, { ...this.#env, HTTP_PROXY: 'bypass-check', HTTPS_PROXY: 'bypass-check' }) === null
      && noProxy.trim()) return null;
    if (!this.#systemProxies.has(url.protocol)) {
      this.#systemProxies.set(url.protocol, Promise.resolve(
        this.#discoverProxy(this.#platform, url.protocol),
      ).catch(() => null));
    }
    return this.#systemProxies.get(url.protocol);
  }
}

export const webFetchInternals = Object.freeze({
  macSystemProxy,
  readableHtml,
  windowsSystemProxy,
});

export function installCronWebFetchProvider(ctx) {
  if (typeof ctx?.web?.registerFetchProvider !== 'function') {
    throw new TypeError('DSH web capability is required for scheduled URL sources');
  }
  return ctx.web.registerFetchProvider(new CronJobHttpFetchProvider());
}
