import { homedir } from 'node:os';
import { join } from 'node:path';

import { CronHarnessRunner, installCronToolGuard } from './harness-runner.mjs';
import { NotificationDispatcher } from './notifications.mjs';
import { installCronJobRpc } from './rpc.mjs';
import { CronScheduler } from './schedule.mjs';
import { CronJobService } from './service.mjs';
import { CronJobStore } from './store.mjs';
import { installCronJobTools } from './tools.mjs';
import { installCronWebFetchProvider } from './web-fetch.mjs';

export async function installCronJob(ctx, controllers, config = {}, internals = {}) {
  installCronWebFetchProvider(ctx);
  const dshHome = process.env.DSH_HOME || join(homedir(), '.dsh');
  const dataPath = config.dataPath
    ?? join(dshHome, 'integrations', 'dsh-cron-job', 'cron-jobs.json');
  const store = internals.store ?? await new CronJobStore(dataPath).load();
  const controlledSessions = new Map();
  const runner = internals.runner ?? new CronHarnessRunner(ctx, {
    harnessBaseUrl: config.harnessBaseUrl,
    controlledSessions,
  });
  const notifications = internals.notifications
    ?? new NotificationDispatcher(controllers, internals.conversationRoutes);
  const logger = typeof ctx?.logger === 'function' ? ctx.logger('dsh-cron-job:cron') : console;
  const service = internals.service ?? new CronJobService({ store, runner, notifications, logger });
  const liftGuard = installCronToolGuard(ctx, controlledSessions);
  const disposeRpc = installCronJobRpc(ctx, service, config.rpcAuthority);
  installCronJobTools(ctx, service);
  await service.skipMissedOnStartup();
  const scheduler = internals.scheduler ?? new CronScheduler(service);
  service.attachScheduler(scheduler);
  scheduler.start();
  ctx.effect(() => async () => {
    scheduler.close();
    await service.close();
    await disposeRpc?.();
    liftGuard?.();
  }, 'dsh-cron-job: close scheduler, runs, RPC, and tool guard');
  return service;
}

export * from './domain.mjs';
export * from './harness-runner.mjs';
export * from './notifications.mjs';
export * from './rpc.mjs';
export * from './schedule.mjs';
export * from './service.mjs';
export * from './store.mjs';
export * from './tools.mjs';
