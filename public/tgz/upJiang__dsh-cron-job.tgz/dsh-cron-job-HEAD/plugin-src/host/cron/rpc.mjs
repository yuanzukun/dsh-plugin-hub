import { resolveRpcAuthority } from '../rpc-authority.mjs';
import { publicTask } from './notifications.mjs';

export const CRON_JOB_RPC_CHANNEL = '/cron-job';
export const CRON_JOB_ENDPOINTS = Object.freeze({
  snapshot: 'snapshot',
  catalog: 'catalog',
  get: 'job.get',
  draft: 'draft.create',
  draftNatural: 'draft.from-natural-language',
  updateDraft: 'draft.update',
  test: 'draft.test',
  confirm: 'draft.confirm',
  update: 'job.update',
  pause: 'job.pause',
  resume: 'job.resume',
  run: 'job.run',
  cancel: 'job.cancel',
  delete: 'job.delete',
  runs: 'job.runs',
});

function record(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function identifier(value) {
  return typeof value === 'string' && /^[A-Za-z0-9-]{8,128}$/.test(value);
}

function badRequest(message) {
  return { ok: false, error: { code: 'bad-request', message } };
}

function publicError(error) {
  const allowed = new Set([
    'bad-request', 'draft-not-found', 'job-not-found', 'draft-testing', 'preflight-required',
    'job-running', 'job-not-running', 'invalid-config', 'target-not-found',
  ]);
  const code = allowed.has(error?.code) ? error.code : 'cron-job-operation-failed';
  return {
    ok: false,
    error: {
      code,
      message: code === 'cron-job-operation-failed'
        ? '定时任务操作失败，请检查配置后重试。'
        : (error?.message ?? code),
    },
  };
}

export function createCronJobRpcHandler(service) {
  if (!service) throw new TypeError('Cron job service is required');
  return async (endpoint, payload = {}, signal) => {
    if (signal?.aborted) return { ok: false, error: { code: 'cancelled', message: 'Cancelled' } };
    if (!Object.values(CRON_JOB_ENDPOINTS).includes(endpoint) || !record(payload)) {
      return badRequest('Unknown cron job endpoint or invalid payload.');
    }
    try {
      let value;
      if (endpoint === CRON_JOB_ENDPOINTS.snapshot) {
        value = service.snapshot(payload);
      } else if (endpoint === CRON_JOB_ENDPOINTS.catalog) {
        value = await service.catalog({ signal });
      } else {
        if (!identifier(payload.id)
          && ![CRON_JOB_ENDPOINTS.draft, CRON_JOB_ENDPOINTS.draftNatural].includes(endpoint)) {
          return badRequest('A valid id is required.');
        }
        if (endpoint === CRON_JOB_ENDPOINTS.get) value = service.get(payload.id);
        else if (endpoint === CRON_JOB_ENDPOINTS.draft) value = await service.draft(payload.task);
        else if (endpoint === CRON_JOB_ENDPOINTS.draftNatural) {
          value = await service.draftFromNaturalLanguage(
            payload.description,
            payload.defaults,
            { signal },
          );
        }
        else if (endpoint === CRON_JOB_ENDPOINTS.updateDraft) {
          value = await service.updateDraft(payload.id, payload.changes);
        } else if (endpoint === CRON_JOB_ENDPOINTS.test) {
          value = await service.testDraft(payload.id, { signal });
        } else if (endpoint === CRON_JOB_ENDPOINTS.confirm) {
          value = await service.confirmDraft(payload.id);
        } else if (endpoint === CRON_JOB_ENDPOINTS.update) {
          value = await service.updateJob(payload.id, payload.changes);
        } else if (endpoint === CRON_JOB_ENDPOINTS.pause) value = await service.pause(payload.id);
        else if (endpoint === CRON_JOB_ENDPOINTS.resume) value = await service.resume(payload.id);
        else if (endpoint === CRON_JOB_ENDPOINTS.run) value = await service.run(payload.id);
        else if (endpoint === CRON_JOB_ENDPOINTS.cancel) value = await service.cancel(payload.id);
        else if (endpoint === CRON_JOB_ENDPOINTS.delete) {
          if (payload.confirm !== true) return badRequest('Deletion requires confirm=true.');
          value = await service.delete(payload.id);
        } else value = service.runs(payload.id, payload);
      }
      return signal?.aborted
        ? { ok: false, error: { code: 'cancelled', message: 'Cancelled' } }
        : { ok: true, value: publicTask(value) };
    } catch (error) {
      return publicError(error);
    }
  };
}

export function installCronJobRpc(ctx, service, authority) {
  if (typeof ctx?.connection?.rpc?.handle !== 'function') {
    throw new TypeError('DSH Host Connection RPC is required');
  }
  return ctx.connection.rpc.handle(
    CRON_JOB_RPC_CHANNEL,
    createCronJobRpcHandler(service),
    { authority: resolveRpcAuthority(authority) },
  );
}
