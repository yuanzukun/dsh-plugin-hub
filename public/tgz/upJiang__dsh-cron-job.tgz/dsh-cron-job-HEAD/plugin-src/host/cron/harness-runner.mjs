import { access, readFile, stat } from 'node:fs/promises';
import { constants } from 'node:fs';
import { dirname, join, parse } from 'node:path';

import { HarnessClient } from '../../../src/channels/shared/harness-client.mjs';

const SOURCE_TOOL = Object.freeze({
  web: /fetch|browse|browser/i,
  search: /search/i,
  fetch: /fetch|browse/i,
  rss: /rss|feed|fetch|web/i,
});
const COMPLETION_MARKER = /(?:\r?\n)?<!-- DSH_CRON_JOB_STATUS:(SUCCESS|FAILED) -->\s*$/u;

function harnessOrigin(webServer, configured) {
  if (configured) return configured;
  const port = Number(webServer?.port);
  if (!Number.isSafeInteger(port) || port <= 0) throw new Error('DSH webServer port is unavailable');
  return `http://127.0.0.1:${port}`;
}

function selectedModel(catalog, selection) {
  if (!selection) return null;
  const group = catalog.groups.find((item) => item.id === selection.provider);
  return group?.models.find((model) => model.id === selection.model) ?? undefined;
}

function sourceWasAccessed(source, calls) {
  const matching = calls.filter((call) => SOURCE_TOOL[source.type]?.test(call.name));
  if (!source.url) return matching.length > 0;
  const expected = source.url.toLowerCase().replace(/\/$/u, '');
  return matching.some((call) => {
    let serialized;
    try {
      serialized = typeof call.arguments === 'string'
        ? call.arguments
        : JSON.stringify(call.arguments ?? '');
    } catch {
      serialized = '';
    }
    return serialized.toLowerCase().replace(/\\\//gu, '/').includes(expected);
  });
}

function matchingSourceCalls(source, calls) {
  return calls.filter((call) => sourceWasAccessed(source, [call]));
}

function serializedArguments(call) {
  try {
    return (typeof call.arguments === 'string'
      ? call.arguments
      : JSON.stringify(call.arguments ?? '')).toLowerCase().replace(/\\\//gu, '/');
  } catch {
    return '';
  }
}

function relatedFailedSourceCall(source, calls) {
  if (!source.url) return calls.find((call) => call.error) ?? null;
  let url;
  try {
    url = new URL(source.url);
  } catch {
    return null;
  }
  const host = url.hostname.toLowerCase().replace(/^www\./u, '');
  return calls.find((call) => call.error && serializedArguments(call).includes(host)) ?? null;
}

function sourceInstruction(source) {
  if (!source.url) return `- ${source.type}`;
  if (source.type === 'search') {
    return `- search: use web_search with a query that explicitly includes ${source.url}`;
  }
  if (source.type === 'rss') {
    return `- rss: use an RSS/feed reader when available, otherwise web_fetch this exact URL: ${source.url}`;
  }
  return `- ${source.type}: use web_fetch with this exact URL: ${source.url}`;
}

function sourceFailure(source, calls) {
  const matching = matchingSourceCalls(source, calls);
  if (matching.length === 0) {
    const relatedFailure = relatedFailedSourceCall(source, calls);
    if (relatedFailure) {
      const error = new Error(relatedFailure.error);
      error.code = relatedFailure.errorCode ?? 'source-tool-failed';
      if (error.code === 'WEB_PROVIDER_CREDENTIAL_MISSING') {
        error.credentialRequired = { channel: 'web-search', field: 'DEEPSEEK_API_KEY' };
      }
      return error;
    }
    const error = new Error(source.url
      ? `No successful ${source.type} tool call accessed the configured URL ${source.url}`
      : `No ${source.type} tool call was observed for the configured source`);
    error.code = 'source-not-accessed';
    return error;
  }
  const successful = matching.some((call) => call.resultObserved
    && !call.error
    && (!Number.isInteger(call.statusCode)
      || (call.statusCode >= 200 && call.statusCode < 300)));
  if (successful) return null;
  const failed = matching.find((call) => call.error
    || (Number.isInteger(call.statusCode) && (call.statusCode < 200 || call.statusCode >= 300)));
  if (failed) {
    const error = new Error(failed.error
      ?? `The ${source.type} tool returned HTTP ${failed.statusCode}`);
    error.code = failed.errorCode ?? 'source-tool-failed';
    if (error.code === 'WEB_PROVIDER_CREDENTIAL_MISSING') {
      error.credentialRequired = { channel: 'web-search', field: 'DEEPSEEK_API_KEY' };
    }
    return error;
  }
  const error = new Error(source.url
    ? `The ${source.type} tool result for ${source.url} could not be confirmed`
    : `The ${source.type} tool result could not be confirmed`);
  error.code = 'source-result-unconfirmed';
  return error;
}

function taskInstruction(config) {
  const sourceLines = config.sources.map(sourceInstruction).join('\n');
  return [
    'Execute the scheduled task below now and return the complete final result.',
    'This is a read-only scheduled-agent run. Never invoke shell, Bash, PowerShell, Node, Python, run_code, or any external write operation.',
    config.sources.length > 0
      ? `You must actually access every configured data source with the appropriate Web/RSS/search/fetch tools.\n${sourceLines}`
      : 'Use only the read-only tools needed for this task.',
    'If the task completed and the final result is ready for delivery, append this exact final line: <!-- DSH_CRON_JOB_STATUS:SUCCESS -->',
    'If any required work could not be completed or verified, explain the failure briefly and append this exact final line: <!-- DSH_CRON_JOB_STATUS:FAILED -->',
    'Never claim success after reporting a task failure. Do not omit the final status line.',
    'Do not describe these execution rules in the final answer.',
    '',
    config.prompt,
  ].join('\n');
}

function completedOutput(value) {
  const output = String(value ?? '').trim();
  if (!output) {
    const error = new Error('The scheduled task produced no final text output');
    error.code = 'empty-agent-output';
    throw error;
  }
  const marker = output.match(COMPLETION_MARKER);
  if (!marker) {
    const error = new Error('The scheduled task did not confirm whether its final result was successful');
    error.code = 'agent-completion-unconfirmed';
    throw error;
  }
  if (marker[1] === 'FAILED') {
    const error = new Error('The scheduled task reported that it could not complete successfully');
    error.code = 'agent-reported-failure';
    throw error;
  }
  const content = output.slice(0, marker.index).trim();
  if (!content) {
    const error = new Error('The scheduled task produced no final text output');
    error.code = 'empty-agent-output';
    throw error;
  }
  return content;
}

function jsonObject(text) {
  const source = String(text ?? '').trim();
  const fenced = source.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1] ?? source;
  const start = fenced.indexOf('{');
  const end = fenced.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('The model did not return a JSON task draft');
  return JSON.parse(fenced.slice(start, end + 1));
}

export async function readableAgentInstructions(workspace) {
  await access(workspace, constants.R_OK);
  if (!(await stat(workspace)).isDirectory()) {
    const error = new Error('The scheduled-job workspace must be a directory');
    error.code = 'workspace-not-directory';
    throw error;
  }
  const files = [];
  const root = parse(workspace).root;
  let current = workspace;
  while (true) {
    const candidate = join(current, 'AGENTS.md');
    try {
      const content = await readFile(candidate, 'utf8');
      files.unshift({ path: candidate, bytes: Buffer.byteLength(content) });
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error;
    }
    if (current === root) break;
    current = dirname(current);
  }
  return files;
}

export class CronHarnessRunner {
  #harness;
  #controlledSessions;
  #controls = new Map();
  #controlOwner = {};

  constructor(ctx, {
    harnessBaseUrl,
    controlledSessions = new Map(),
    Harness = HarnessClient,
  } = {}) {
    this.#controlledSessions = controlledSessions;
    this.#harness = new Harness({
      baseUrl: harnessOrigin(ctx.webServer, harnessBaseUrl),
      workspace: process.cwd(),
      autostart: false,
      rpcIdPrefix: 'cron-job',
      logPrefix: 'dsh-cron-job',
    });
  }

  async catalog({ signal } = {}) {
    return {
      workspaces: await this.#harness.listWorkspaces({ signal }),
      models: await this.#harness.listModels({ signal }),
    };
  }

  async draftFromNaturalLanguage(description, defaults, { signal } = {}) {
    if (typeof description !== 'string' || !description.trim()) {
      throw new TypeError('A natural-language task description is required');
    }
    const workspace = defaults?.workspace;
    await readableAgentInstructions(workspace);
    const sessionId = await this.#harness.createSession({ workspace, signal });
    const policy = {
      web: false,
      search: false,
      fetch: false,
      rss: false,
      deny: [],
    };
    const control = this.#registerSession(sessionId, policy);
    try {
      if (defaults?.model) await this.#harness.selectSessionModel(sessionId, defaults.model, { signal });
      const output = await this.#ask(sessionId, [
        'Convert the user request into one general scheduled-agent task JSON object.',
        'Return JSON only. Do not execute the task.',
        'Required shape:',
        '{"name":"...","description":"...","schedule":{"type":"cron","expression":"5-field cron"},"timezone":"IANA zone","workspace":"absolute path","prompt":"complete reusable agent prompt","model":null,"toolPolicy":{"web":true,"search":true,"fetch":true,"rss":true,"deny":[]},"sources":[{"type":"web|rss|search|fetch","url":"https://..."}],"targets":[]}',
        'Schedule may instead be {"type":"once","at":"RFC3339"} or {"type":"interval","seconds":60}.',
        `Use this workspace exactly: ${workspace}`,
        `Use this timezone unless the user explicitly overrides it: ${defaults.timezone}`,
        'Keep targets as an empty array; the Host will attach the selected notification targets.',
        '',
        description.trim(),
      ].join('\n'), { timeoutMs: 180_000, signal }, control);
      return { task: jsonObject(output), sessionId };
    } finally {
      this.#releaseSession(sessionId);
    }
  }

  async run(config, { signal, onProgress, onSession, probeModel = false } = {}) {
    let instructions;
    try {
      instructions = await readableAgentInstructions(config.workspace);
    } catch (error) {
      error.preflightStage = 'workspace';
      throw error;
    }
    onProgress?.({ stage: 'workspace', status: 'passed', instructions });
    let models;
    try {
      models = await this.#harness.listModels({ signal });
    } catch (error) {
      error.preflightStage = 'model';
      throw error;
    }
    const model = selectedModel(models, config.model);
    if (model === undefined) {
      const error = new Error('The configured provider/model is not available');
      error.code = 'model-unavailable';
      throw error;
    }
    if (config.model?.reasoningEffort
      && !model?.reasoning?.efforts?.some((effort) => effort.id === config.model.reasoningEffort)) {
      const error = new Error('The configured reasoning effort is not available for this model');
      error.code = 'model-reasoning-unavailable';
      throw error;
    }

    let probeSessionId;
    if (probeModel) {
      try {
        probeSessionId = await this.#harness.createSession({ workspace: config.workspace, signal });
        const control = this.#registerSession(probeSessionId, config.toolPolicy);
        onSession?.({ kind: 'model-probe', sessionId: probeSessionId });
        if (config.model) await this.#harness.selectSessionModel(probeSessionId, config.model, { signal });
        const probe = await this.#ask(
          probeSessionId,
          'Reply with exactly: CRON_MODEL_OK',
          { timeoutMs: Math.min(config.timeoutMs, 120_000), signal },
          control,
        );
        if (!probe.includes('CRON_MODEL_OK')) {
          const error = new Error('The model probe returned an unexpected result');
          error.code = 'model-probe-invalid';
          throw error;
        }
      } catch (error) {
        error.preflightStage = 'model';
        throw error;
      } finally {
        if (probeSessionId) this.#releaseSession(probeSessionId);
      }
      onProgress?.({ stage: 'model', status: 'passed', sessionId: probeSessionId });
    } else {
      onProgress?.({ stage: 'model', status: 'passed', skippedProbe: true });
    }

    const sessionId = await this.#harness.createSession({ workspace: config.workspace, signal });
    const requiredSourceTypes = [...new Set(config.sources.map((source) => source.type))];
    const control = this.#registerSession(sessionId, config.toolPolicy, requiredSourceTypes);
    onSession?.({ kind: 'task', sessionId });
    const toolCalls = [];
    const toolCallsById = new Map();
    let latestToolCall = null;
    if (config.sources.length > 0) onProgress?.({ stage: 'source', status: 'running' });
    let output;
    try {
      if (config.model) await this.#harness.selectSessionModel(sessionId, config.model, { signal });
      output = await this.#ask(sessionId, taskInstruction(config), {
        timeoutMs: config.timeoutMs,
        signal,
        progressMode: 'all',
        onUpdate(update) {
          if (update.type === 'tool' && typeof update.name === 'string') {
            const call = {
              name: update.name,
              arguments: update.arguments,
              callId: update.callId,
              resultObserved: false,
              error: null,
              errorCode: null,
              statusCode: null,
            };
            toolCalls.push(call);
            if (update.callId) toolCallsById.set(update.callId, call);
            latestToolCall = call;
          } else if (update.type === 'status' && update.ok !== undefined) {
            const call = (update.callId ? toolCallsById.get(update.callId) : null)
              ?? latestToolCall;
            if (call) {
              call.resultObserved = true;
              call.error = update.ok ? null : (update.error ?? 'The data-source tool failed');
              call.errorCode = update.errorCode ?? null;
              call.statusCode = update.statusCode ?? null;
            }
          }
          onProgress?.({ stage: 'agent', status: 'running', update });
        },
        onInteraction: async () => ({ ok: false, error: {
          code: 'interaction-not-allowed',
          message: 'Scheduled jobs cannot request interactive approval or additional input.',
        } }),
      }, control);
    } catch (error) {
      error.preflightStage = 'agent';
      throw error;
    } finally {
      this.#releaseSession(sessionId);
    }
    if (typeof output !== 'string' || !output.trim()) {
      const error = new Error('The scheduled task produced no final text output');
      error.code = 'empty-agent-output';
      error.preflightStage = 'agent';
      throw error;
    }
    for (const source of config.sources) {
      const error = sourceFailure(source, toolCalls);
      if (error) {
        error.preflightStage = 'source';
        error.source = source;
        throw error;
      }
    }
    if (config.sources.length > 0) onProgress?.({
      stage: 'source',
      status: 'passed',
      count: config.sources.length,
    });
    let finalOutput;
    try {
      finalOutput = completedOutput(output);
    } catch (error) {
      error.preflightStage = 'agent';
      throw error;
    }
    const toolNames = [...new Set(toolCalls.map((call) => call.name))];
    onProgress?.({ stage: 'agent', status: 'passed', sessionId, toolNames });
    return {
      sessionId,
      ...(probeSessionId ? { probeSessionId } : {}),
      output: finalOutput,
      toolNames,
      instructions,
    };
  }

  #registerSession(sessionId, policy, requiredSourceTypes = []) {
    const control = { owner: this.#controlOwner, key: `cron-job:${sessionId}` };
    this.#controlledSessions.set(sessionId, {
      ...policy,
      // Runtime-only metadata used by the host guard; never persisted in task config.
      requiredSourceTypes,
    });
    this.#controls.set(sessionId, control);
    return control;
  }

  #releaseSession(sessionId) {
    this.#controlledSessions.delete(sessionId);
    this.#controls.delete(sessionId);
  }

  async #ask(sessionId, prompt, options, control) {
    try {
      return await this.#harness.ask(sessionId, prompt, { ...options, control });
    } catch (error) {
      await this.#harness.stopActiveTurn(sessionId, control).catch(() => undefined);
      throw error;
    }
  }

  stop(sessionId, signal) {
    const control = this.#controls.get(sessionId);
    if (!control) return Promise.resolve(false);
    return this.#harness.stopActiveTurn(sessionId, control, { signal });
  }

  async close() {
    await Promise.allSettled([...this.#controls.keys()].map((sessionId) => this.stop(sessionId)));
  }
}

export function installCronToolGuard(ctx, controlledSessions) {
  if (typeof ctx?.tools?.guard !== 'function') return () => {};
  const forbidden = /^(?:bash|shell|powershell|pwsh|node|python|run_code|exec|terminal)$/i;
  const mutating = /(?:^|[_.:-])(?:write|edit|patch|delete|remove|unlink|rename|move|copy|upload|publish|commit|push|send|message|email|notify|create|update|insert|mutate)(?:$|[_.:-])/i;
  const sourceTools = Object.freeze({
    web: /web|browser/i,
    search: /search/i,
    fetch: /fetch|browse/i,
    rss: /rss|feed/i,
  });
  return ctx.tools.guard((exec) => {
    // DSH's ToolExecution agent identity is `agent.id`; keep the legacy
    // sessionId fallback for older host adapters and isolated tests.
    const sessionId = exec?.agent?.id ?? exec?.agent?.sessionId;
    const policy = sessionId ? controlledSessions.get(String(sessionId)) : undefined;
    if (!policy) return undefined;
    if (forbidden.test(exec.name) || /(?:shell|powershell|python|node\.js)/i.test(exec.name)) {
      return 'Scheduled jobs are read-only and cannot execute shell, Node, Python, or PowerShell tools.';
    }
    const normalizedName = String(exec.name ?? '').trim().toLowerCase();
    if (mutating.test(normalizedName)) {
      return `Tool ${exec.name} can modify external state and is not allowed in scheduled jobs.`;
    }
    if ((policy.deny ?? []).some((name) => String(name).trim().toLowerCase() === normalizedName)) {
      return `Tool ${exec.name} is disabled by this scheduled job's tool policy.`;
    }
    for (const [capability, pattern] of Object.entries(sourceTools)) {
      if (policy[capability] === false && pattern.test(normalizedName)) {
        return `${capability} tools are disabled by this scheduled job's tool policy.`;
      }
    }
    const requiredSourceTypes = new Set(policy.requiredSourceTypes ?? []);
    if (/(?:^|[_.:-])search(?:$|[_.:-])/i.test(normalizedName)
      && !requiredSourceTypes.has('search')
      && ['web', 'fetch', 'rss'].some((type) => requiredSourceTypes.has(type))) {
      return 'Search tools are not allowed for URL/feed sources without a configured search source; use the exact fetch/feed tool required by the task.';
    }
    return undefined;
  });
}
