import { createHash } from 'node:crypto';

import {
  configFingerprint,
  createDraft,
  errorCode,
  hasOnlyMetadataChanges,
  invalidateDraft,
  newId,
  normalizeTaskConfig,
  publicFailure,
} from './domain.mjs';
import { nextRunAt } from './schedule.mjs';

function notFound(kind, id) {
  const error = new Error(`${kind} ${id} was not found`);
  error.code = `${kind.toLowerCase()}-not-found`;
  return error;
}

function publicError(stage, error, options = {}) {
  return publicFailure(
    stage,
    errorCode(error, `${stage}-failed`),
    error?.message ?? String(error),
    {
      ...options,
      ...(typeof error?.providerCode === 'string' ? { providerCode: error.providerCode } : {}),
    },
  );
}

function testMessage(output, draft) {
  return [
    '[dsh-cron-job 定时任务创建测试]',
    `任务：${draft.config.name}`,
    `草稿：${draft.id}`,
    '',
    output,
  ].join('\n');
}

function runMessage(output, job) {
  return [`[dsh-cron-job] ${job.config.name}`, '', output].join('\n');
}

function freshJob(draft, now) {
  return {
    id: draft.baseJobId ?? newId(),
    revision: 1,
    state: 'active',
    config: draft.config,
    createdAt: now,
    updatedAt: now,
    lastRunAt: null,
    nextRunAt: nextRunAt(draft.config.schedule, draft.config.timezone, {
      after: new Date(now),
      intervalAnchor: now,
    }),
    intervalAnchor: now,
    successfulPreflight: draft.successfulPreflight,
    testRecords: draft.testRecords ?? [],
  };
}

export class CronJobService {
  #store;
  #runner;
  #notifications;
  #logger;
  #now;
  #activeRuns = new Map();
  #preflightProgress = new Map();
  #scheduler = null;

  constructor({ store, runner, notifications, logger = console, now = () => new Date() }) {
    this.#store = store;
    this.#runner = runner;
    this.#notifications = notifications;
    this.#logger = logger;
    this.#now = now;
  }

  attachScheduler(scheduler) {
    this.#scheduler = scheduler;
  }

  async skipMissedOnStartup(now = this.#now()) {
    const nowMs = now.getTime();
    await this.#store.update((state) => {
      for (const job of state.jobs) {
        if (job.state !== 'active' || !job.nextRunAt || Date.parse(job.nextRunAt) > nowMs) continue;
        job.nextRunAt = nextRunAt(job.config.schedule, job.config.timezone, {
          after: now,
          intervalAnchor: job.intervalAnchor,
        });
      }
    });
  }

  snapshot({ query = '', status = 'all', page = 1, pageSize = 20 } = {}) {
    const state = this.#store.snapshot();
    const needle = String(query).trim().toLowerCase();
    const filtered = state.jobs.filter((job) => {
      if (status !== 'all' && job.state !== status) return false;
      if (!needle) return true;
      return `${job.config.name}\n${job.config.description}`.toLowerCase().includes(needle);
    });
    const size = Math.max(1, Math.min(100, Number(pageSize) || 20));
    const currentPage = Math.max(1, Number(page) || 1);
    return {
      revision: state.revision,
      jobs: filtered.slice((currentPage - 1) * size, currentPage * size),
      drafts: state.drafts.map((draft) => this.#withCurrentPreflight(draft)),
      total: filtered.length,
      page: currentPage,
      pageSize: size,
      runningJobIds: [...this.#activeRuns.keys()],
      preflightProgress: Object.fromEntries(this.#preflightProgress),
    };
  }

  get(id) {
    const state = this.#store.snapshot();
    const job = state.jobs.find((item) => item.id === id);
    const draft = state.drafts.find((item) => item.id === id);
    if (!job && !draft) throw notFound('Job', id);
    return job ?? this.#withCurrentPreflight(draft);
  }

  #withCurrentPreflight(draft) {
    if (draft?.status !== 'ready' || !draft.successfulPreflight) return draft;
    const versions = this.#notifications.targetVersions(draft.config.targets);
    if (configFingerprint(draft.config, versions) === draft.successfulPreflight.fingerprint) {
      return draft;
    }
    return { ...draft, status: 'draft', successfulPreflight: null };
  }

  async catalog(options) {
    const catalog = await this.#runner.catalog(options);
    return { ...catalog, targets: this.#notifications.publicTargets() };
  }

  async draft(input, { sessionId } = {}) {
    const resolvedTargets = this.#notifications.resolveTargetRefs(
      input.targets ?? [],
      [],
      { sessionId },
    );
    const config = normalizeTaskConfig({ ...input, targets: resolvedTargets });
    const draft = createDraft(config);
    await this.#store.update((state) => { state.drafts.push(draft); });
    return draft;
  }

  async draftFromNaturalLanguage(description, defaults, options) {
    const resolvedTargets = this.#notifications.resolveTargetRefs(defaults?.targets ?? []);
    const result = await this.#runner.draftFromNaturalLanguage(description, defaults, options);
    return this.draft({
      ...result.task,
      workspace: defaults.workspace,
      timezone: result.task.timezone ?? defaults.timezone,
      model: defaults.model ?? result.task.model,
      targets: resolvedTargets,
    });
  }

  async updateDraft(id, input) {
    let result;
    await this.#store.update((state) => {
      const index = state.drafts.findIndex((item) => item.id === id);
      if (index < 0) throw notFound('Draft', id);
      if (state.drafts[index].status === 'testing') {
        const error = new Error('The draft is currently being tested');
        error.code = 'draft-testing';
        throw error;
      }
      const targets = this.#notifications.resolveTargetRefs(
        input.targets ?? state.drafts[index].config.targets,
        state.drafts[index].config.targets,
      );
      const config = normalizeTaskConfig({ ...state.drafts[index].config, ...input, targets });
      result = invalidateDraft(state.drafts[index], config);
      state.drafts[index] = result;
    });
    return result;
  }

  async testDraft(id, { signal, onProgress } = {}) {
    const startedAt = this.#now().toISOString();
    let draft;
    await this.#store.update((state) => {
      const index = state.drafts.findIndex((item) => item.id === id);
      if (index < 0) throw notFound('Draft', id);
      if (state.drafts[index].status === 'testing') {
        const error = new Error('The draft is already being tested');
        error.code = 'draft-testing';
        throw error;
      }
      state.drafts[index] = { ...state.drafts[index], status: 'testing', updatedAt: startedAt };
      draft = structuredClone(state.drafts[index]);
    });

    const testId = newId();
    const reportProgress = (progress) => {
      const current = this.#preflightProgress.get(id) ?? { testId, stages: {}, targets: {} };
      if (progress.stage === 'target' && progress.targetId) {
        current.targets[progress.targetId] = progress;
      } else {
        current.stages[progress.stage] = progress;
      }
      current.updatedAt = this.#now().toISOString();
      this.#preflightProgress.set(id, current);
      onProgress?.(progress);
    };
    this.#preflightProgress.set(id, {
      testId,
      stages: {},
      targets: {},
      startedAt,
      updatedAt: startedAt,
    });
    const record = {
      id: testId,
      kind: 'preflight',
      draftId: id,
      startedAt,
      finishedAt: null,
      status: 'running',
      failures: [],
      receipts: [],
    };
    let runnerResult;
    try {
      reportProgress({ stage: 'workspace', status: 'running' });
      runnerResult = await this.#runner.run(draft.config, {
        signal,
        onProgress: reportProgress,
        probeModel: true,
      });
    } catch (error) {
      const stage = ['workspace', 'model', 'agent', 'source'].includes(error?.preflightStage)
        ? error.preflightStage
        : error?.code?.startsWith('model') ? 'model'
        : error?.code?.startsWith('source') ? 'source'
          : error?.code?.includes('workspace') || ['EACCES', 'ENOENT'].includes(error?.code)
            ? 'workspace'
            : 'agent';
      record.failures.push(publicError(stage, error, error?.credentialRequired ? {
        credentialRequired: error.credentialRequired,
      } : {}));
    }

    if (runnerResult) {
      const message = testMessage(runnerResult.output, draft);
      for (const target of draft.config.targets) {
        const opaqueTargetId = createHash('sha256')
          .update(`${target.channel}\0${target.botId}\0${JSON.stringify(target.recipient ?? null)}`)
          .digest('hex').slice(0, 24);
        reportProgress({ stage: 'target', status: 'running', targetId: opaqueTargetId });
        try {
          const receipt = await this.#notifications.send(target, message, {
            kind: 'preflight', runId: testId, signal,
          });
          record.receipts.push(receipt);
          reportProgress({ stage: 'target', status: 'passed', targetId: receipt.targetId });
        } catch (error) {
          record.receipts.push({
            targetId: opaqueTargetId,
            channel: target.channel,
            botId: target.botId,
            kind: 'preflight',
            runId: testId,
            status: 'failed',
            code: errorCode(error, 'delivery-failed'),
            message: error?.message ?? String(error),
            ...(typeof error?.providerCode === 'string'
              ? { providerCode: error.providerCode }
              : {}),
          });
          record.failures.push(publicError('target', error, {
            targetId: opaqueTargetId,
            ...(error?.code?.includes('credential') ? {
              credentialRequired: { channel: target.channel, field: 'account credentials' },
            } : {}),
          }));
          reportProgress({ stage: 'target', status: 'failed', targetId: opaqueTargetId });
        }
      }
    }

    const finishedAt = this.#now().toISOString();
    record.finishedAt = finishedAt;
    record.durationMs = Date.parse(finishedAt) - Date.parse(startedAt);
    record.status = record.failures.length === 0 ? 'passed' : 'failed';
    if (runnerResult) {
      record.sessionId = runnerResult.sessionId;
      record.probeSessionId = runnerResult.probeSessionId;
      record.output = runnerResult.output;
      record.toolNames = runnerResult.toolNames;
    }
    const targetVersions = this.#notifications.targetVersions(draft.config.targets);
    const fingerprint = configFingerprint(draft.config, targetVersions);
    let result;
    await this.#store.update((state) => {
      const index = state.drafts.findIndex((item) => item.id === id);
      if (index < 0) throw notFound('Draft', id);
      const current = state.drafts[index];
      const unchanged = current.revision === draft.revision
        && configFingerprint(current.config, targetVersions) === fingerprint;
      const passed = record.status === 'passed' && unchanged;
      const successfulPreflight = passed ? {
        fingerprint,
        testedAt: finishedAt,
        testId,
        sessionId: record.sessionId,
        targetVersions,
      } : null;
      result = {
        ...current,
        status: passed ? 'ready' : 'test_failed',
        updatedAt: finishedAt,
        successfulPreflight,
        testRecords: [...(current.testRecords ?? []), record].slice(-10),
      };
      state.drafts[index] = result;
    });
    this.#preflightProgress.delete(id);
    return result;
  }

  async confirmDraft(id) {
    const now = this.#now().toISOString();
    let result;
    let invalidPreflight = false;
    await this.#store.update((state) => {
      const index = state.drafts.findIndex((item) => item.id === id);
      if (index < 0) throw notFound('Draft', id);
      const draft = state.drafts[index];
      const targetVersions = this.#notifications.targetVersions(draft.config.targets);
      const fingerprint = configFingerprint(draft.config, targetVersions);
      if (draft.status !== 'ready' || draft.successfulPreflight?.fingerprint !== fingerprint) {
        invalidPreflight = true;
        state.drafts[index] = {
          ...draft,
          status: 'draft',
          successfulPreflight: null,
          updatedAt: now,
        };
        return;
      }
      if (draft.baseJobId) {
        const jobIndex = state.jobs.findIndex((item) => item.id === draft.baseJobId);
        if (jobIndex < 0) throw notFound('Job', draft.baseJobId);
        const previous = state.jobs[jobIndex];
        result = {
          ...previous,
          revision: previous.revision + 1,
          config: draft.config,
          state: previous.state,
          updatedAt: now,
          successfulPreflight: draft.successfulPreflight,
          testRecords: [
            ...(previous.testRecords ?? []),
            ...(draft.testRecords ?? []),
          ].slice(-20),
          nextRunAt: previous.state === 'active'
            ? nextRunAt(draft.config.schedule, draft.config.timezone, {
                after: new Date(now), intervalAnchor: previous.intervalAnchor ?? now,
              })
            : null,
        };
        state.jobs[jobIndex] = result;
      } else {
        result = freshJob(draft, now);
        state.jobs.push(result);
      }
      state.drafts.splice(index, 1);
    });
    if (invalidPreflight) {
      const error = new Error('The current draft has not passed a valid full preflight test');
      error.code = 'preflight-required';
      throw error;
    }
    this.#scheduler?.reschedule();
    return result;
  }

  async updateJob(id, changes) {
    let result;
    await this.#store.update((state) => {
      const index = state.jobs.findIndex((item) => item.id === id);
      if (index < 0) throw notFound('Job', id);
      const job = state.jobs[index];
      const targets = this.#notifications.resolveTargetRefs(
        changes.targets ?? job.config.targets,
        job.config.targets,
      );
      const config = normalizeTaskConfig({ ...job.config, ...changes, targets });
      if (hasOnlyMetadataChanges(job.config, config)) {
        result = { ...job, config, revision: job.revision + 1, updatedAt: this.#now().toISOString() };
        state.jobs[index] = result;
        return;
      }
      result = createDraft(config, { baseJobId: id });
      state.drafts.push(result);
    });
    return result;
  }

  async setState(id, stateValue) {
    let result;
    await this.#store.update((state) => {
      const index = state.jobs.findIndex((item) => item.id === id);
      if (index < 0) throw notFound('Job', id);
      const job = state.jobs[index];
      if (!['active', 'paused'].includes(stateValue)) throw new TypeError('invalid job state');
      const now = this.#now().toISOString();
      result = {
        ...job,
        state: stateValue,
        revision: job.revision + 1,
        updatedAt: now,
        nextRunAt: stateValue === 'active'
          ? nextRunAt(job.config.schedule, job.config.timezone, {
              after: new Date(now), intervalAnchor: job.intervalAnchor,
            })
          : null,
      };
      state.jobs[index] = result;
    });
    this.#scheduler?.reschedule();
    return result;
  }

  pause(id) { return this.setState(id, 'paused'); }
  resume(id) { return this.setState(id, 'active'); }

  async delete(id) {
    if (this.#activeRuns.has(id)) {
      const error = new Error('Cancel the running job before deleting it');
      error.code = 'job-running';
      throw error;
    }
    await this.#store.update((state) => {
      const jobIndex = state.jobs.findIndex((item) => item.id === id);
      const draftIndex = state.drafts.findIndex((item) => item.id === id);
      if (jobIndex < 0 && draftIndex < 0) throw notFound('Job', id);
      if (jobIndex >= 0) state.jobs.splice(jobIndex, 1);
      if (draftIndex >= 0) state.drafts.splice(draftIndex, 1);
    });
    this.#scheduler?.reschedule();
    return { deleted: true, id };
  }

  runs(jobId, { page = 1, pageSize = 20, includeTests = true } = {}) {
    const state = this.#store.snapshot();
    const job = state.jobs.find((item) => item.id === jobId);
    const drafts = state.drafts.filter((item) => item.id === jobId || item.baseJobId === jobId);
    if (!job && drafts.length === 0) throw notFound('Job', jobId);
    const testRecords = includeTests ? [
      ...(job?.testRecords ?? []),
      ...drafts.flatMap((draft) => draft.testRecords ?? []),
    ] : [];
    const records = [...state.runs.filter((run) => run.jobId === jobId), ...testRecords]
      .sort((left, right) => String(right.startedAt).localeCompare(String(left.startedAt)));
    const size = Math.max(1, Math.min(100, Number(pageSize) || 20));
    const currentPage = Math.max(1, Number(page) || 1);
    return { items: records.slice((currentPage - 1) * size, currentPage * size), total: records.length };
  }

  async run(id, { trigger = 'manual' } = {}) {
    if (this.#activeRuns.has(id)) {
      const error = new Error('This job is already running');
      error.code = 'job-running';
      throw error;
    }
    const job = this.#store.snapshot().jobs.find((item) => item.id === id);
    if (!job) throw notFound('Job', id);
    const controller = new AbortController();
    const runId = newId();
    const active = { runId, controller, task: null, sessionId: null };
    this.#activeRuns.set(id, active);
    const task = Promise.resolve()
      .then(() => this.#executeJob(job, {
        runId,
        trigger,
        signal: controller.signal,
        onSession: ({ sessionId }) => {
          active.sessionId = sessionId;
        },
      }))
      .finally(() => this.#activeRuns.delete(id));
    active.task = task;
    return task;
  }

  async #executeJob(job, { runId, trigger, signal, onSession }) {
    const startedAt = this.#now().toISOString();
    const record = {
      id: runId,
      jobId: job.id,
      kind: 'run',
      trigger,
      startedAt,
      finishedAt: null,
      status: 'running',
      receipts: [],
    };
    try {
      const result = await this.#runner.run(job.config, { signal, onSession });
      signal.throwIfAborted();
      const active = this.#activeRuns.get(job.id);
      if (active) active.sessionId = result.sessionId;
      record.sessionId = result.sessionId;
      record.output = result.output;
      record.toolNames = result.toolNames;
      for (const target of job.config.targets) {
        try {
          record.receipts.push(await this.#notifications.send(
            target,
            runMessage(result.output, job),
            { kind: 'run', runId, signal },
          ));
        } catch (error) {
          record.receipts.push({
            targetId: `${target.channel}:${target.botId}`,
            channel: target.channel,
            botId: target.botId,
            status: 'failed',
            code: errorCode(error, 'delivery-failed'),
            message: error?.message ?? String(error),
          });
        }
      }
      record.status = record.receipts.every((item) => item.status === 'delivered')
        ? 'succeeded' : 'partial_failure';
    } catch (error) {
      record.status = signal.aborted ? 'cancelled' : 'failed';
      record.error = { code: errorCode(error, 'run-failed'), message: error?.message ?? String(error) };
    }
    const finishedAt = this.#now().toISOString();
    record.finishedAt = finishedAt;
    record.durationMs = Date.parse(finishedAt) - Date.parse(startedAt);
    await this.#store.update((state) => {
      state.runs.push(record);
      const index = state.jobs.findIndex((item) => item.id === job.id);
      if (index >= 0) {
        const current = state.jobs[index];
        state.jobs[index] = {
          ...current,
          lastRunAt: finishedAt,
          lastRunStatus: record.status,
          nextRunAt: current.state === 'active'
            ? nextRunAt(current.config.schedule, current.config.timezone, {
                after: new Date(finishedAt), intervalAnchor: current.intervalAnchor,
              })
            : null,
        };
      }
    });
    this.#scheduler?.reschedule();
    return record;
  }

  async cancel(id) {
    const active = this.#activeRuns.get(id);
    if (!active) return { cancelled: false, code: 'job-not-running' };
    if (active.sessionId) await this.#runner.stop(active.sessionId).catch(() => undefined);
    active.controller.abort(new DOMException('Scheduled job cancelled', 'AbortError'));
    return { cancelled: true, runId: active.runId };
  }

  nextScheduledJob() {
    return this.#store.snapshot().jobs
      .filter((job) => job.state === 'active' && job.nextRunAt)
      .sort((left, right) => left.nextRunAt.localeCompare(right.nextRunAt))[0] ?? null;
  }

  async runDueJobs(now = this.#now()) {
    const nowMs = now.getTime();
    const state = this.#store.snapshot();
    const due = state.jobs.filter((job) => job.state === 'active'
      && job.nextRunAt && Date.parse(job.nextRunAt) <= nowMs);
    for (const job of due) {
      if (this.#activeRuns.has(job.id)) continue;
      void this.run(job.id, { trigger: 'schedule' }).catch((error) => {
        this.#logger.error?.(`[dsh-cron-job] scheduled run ${job.id} failed`, error);
      });
    }
    // Every missed occurrence collapses to the first future instant. Nothing is backfilled.
    await this.#store.update((next) => {
      for (const job of next.jobs) {
        if (job.state !== 'active' || !job.nextRunAt || Date.parse(job.nextRunAt) > nowMs) continue;
        job.nextRunAt = nextRunAt(job.config.schedule, job.config.timezone, {
          after: now,
          intervalAnchor: job.intervalAnchor,
        });
      }
    });
  }

  async close() {
    await this.#runner.close?.();
    for (const active of this.#activeRuns.values()) {
      active.controller.abort(new DOMException('dsh-cron-job stopped', 'AbortError'));
    }
    await Promise.allSettled([...this.#activeRuns.values()].map((item) => item.task));
    this.#activeRuns.clear();
  }
}
