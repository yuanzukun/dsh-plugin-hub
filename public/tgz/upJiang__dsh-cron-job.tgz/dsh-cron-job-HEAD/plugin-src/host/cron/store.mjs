import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';

const EMPTY = Object.freeze({ schemaVersion: 1, revision: 0, drafts: [], jobs: [], runs: [] });

function normalize(value) {
  if (!value || typeof value !== 'object' || value.schemaVersion !== 1) return structuredClone(EMPTY);
  return {
    schemaVersion: 1,
    revision: Number.isSafeInteger(value.revision) ? value.revision : 0,
    drafts: Array.isArray(value.drafts) ? value.drafts : [],
    jobs: Array.isArray(value.jobs) ? value.jobs : [],
    runs: Array.isArray(value.runs) ? value.runs : [],
  };
}

export class CronJobStore {
  #path;
  #state = structuredClone(EMPTY);
  #queue = Promise.resolve();

  constructor(path) {
    if (typeof path !== 'string' || !path) throw new TypeError('Cron job store path is required');
    this.#path = path;
  }

  async load() {
    try {
      this.#state = normalize(JSON.parse(await readFile(this.#path, 'utf8')));
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error;
      await this.#persist();
    }
    return this;
  }

  snapshot() {
    return structuredClone(this.#state);
  }

  async update(mutator) {
    if (typeof mutator !== 'function') throw new TypeError('store mutator is required');
    const operation = this.#queue.then(async () => {
      const next = structuredClone(this.#state);
      const value = await mutator(next);
      next.schemaVersion = 1;
      next.revision = this.#state.revision + 1;
      next.runs = next.runs.slice(-500);
      next.drafts = next.drafts.map((draft) => ({
        ...draft,
        testRecords: Array.isArray(draft.testRecords) ? draft.testRecords.slice(-10) : [],
      }));
      this.#state = next;
      await this.#persist();
      return value === undefined ? structuredClone(next) : structuredClone(value);
    });
    this.#queue = operation.then(() => undefined, () => undefined);
    return operation;
  }

  async #persist() {
    await mkdir(dirname(this.#path), { recursive: true, mode: 0o700 });
    const temporary = `${this.#path}.${process.pid}.tmp`;
    await writeFile(temporary, `${JSON.stringify(this.#state, null, 2)}\n`, {
      encoding: 'utf8',
      mode: 0o600,
    });
    await rename(temporary, this.#path);
  }
}
