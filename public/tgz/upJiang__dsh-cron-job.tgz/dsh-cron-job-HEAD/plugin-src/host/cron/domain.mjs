import { createHash, randomUUID } from 'node:crypto';
import { isAbsolute, resolve } from 'node:path';

import { CronExpressionParser } from 'cron-parser';

export const DRAFT_STATES = Object.freeze([
  'draft', 'testing', 'ready', 'test_failed', 'confirmed',
]);
export const JOB_STATES = Object.freeze(['active', 'paused']);
export const CHANNELS = Object.freeze([
  'weixin', 'feishu', 'dingtalk', 'wecom', 'qq', 'slack', 'telegram', 'discord',
  'whatsapp',
]);
export const CRITICAL_FIELDS = Object.freeze([
  'schedule', 'timezone', 'workspace', 'prompt', 'model', 'toolPolicy', 'sources',
  'targets', 'timeoutMs',
]);

function text(value, field, { optional = false, max = 50_000 } = {}) {
  if (value === undefined && optional) return undefined;
  if (typeof value !== 'string' || !value.trim()) throw invalid(`${field} is required`);
  return value.trim().slice(0, max);
}

function invalid(message, code = 'invalid-config') {
  const error = new Error(message);
  error.code = code;
  return error;
}

function validTimezone(value) {
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: value }).format();
    return true;
  } catch {
    return false;
  }
}

export function normalizeSchedule(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw invalid('schedule must be an object');
  }
  if (value.type === 'cron') {
    return { type: 'cron', expression: text(value.expression, 'schedule.expression', { max: 200 }) };
  }
  if (value.type === 'once') {
    const at = text(value.at, 'schedule.at', { max: 100 });
    if (Number.isNaN(Date.parse(at))) throw invalid('schedule.at must be an RFC3339 date-time');
    return { type: 'once', at: new Date(at).toISOString() };
  }
  if (value.type === 'interval') {
    const seconds = Number(value.seconds);
    if (!Number.isSafeInteger(seconds) || seconds < 60 || seconds > 31_536_000) {
      throw invalid('schedule.seconds must be an integer between 60 and 31536000');
    }
    return { type: 'interval', seconds };
  }
  throw invalid('schedule.type must be cron, once, or interval');
}

function normalizeModel(value) {
  if (value == null) return null;
  if (typeof value !== 'object' || Array.isArray(value)) throw invalid('model must be an object');
  const provider = text(value.provider, 'model.provider', { max: 200 });
  const model = text(value.model, 'model.model', { max: 300 });
  const reasoningEffort = text(value.reasoningEffort, 'model.reasoningEffort', {
    optional: true,
    max: 100,
  });
  return { provider, model, ...(reasoningEffort ? { reasoningEffort } : {}) };
}

function normalizeToolPolicy(value) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const deny = Array.isArray(source.deny)
    ? [...new Set(source.deny.map((item) => text(item, 'toolPolicy.deny[]', { max: 200 })))]
    : [];
  return {
    web: source.web !== false,
    search: source.search !== false,
    fetch: source.fetch !== false,
    rss: source.rss !== false,
    deny,
  };
}

function normalizeSources(value) {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > 50) throw invalid('sources must be an array');
  return value.map((item) => {
    if (!item || typeof item !== 'object' || Array.isArray(item)) {
      throw invalid('each source must be an object');
    }
    const type = text(item.type, 'source.type', { max: 50 });
    if (!['web', 'rss', 'search', 'fetch'].includes(type)) throw invalid('unsupported source type');
    const url = text(item.url, 'source.url', { optional: true, max: 4_000 });
    if (url) {
      let parsed;
      try { parsed = new URL(url); } catch { throw invalid('source.url must be a valid URL'); }
      if (!['http:', 'https:'].includes(parsed.protocol)) throw invalid('source.url must use HTTP or HTTPS');
    }
    return { type, ...(url ? { url } : {}) };
  });
}

function normalizeRecipient(value) {
  if (value === undefined) return undefined;
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw invalid('target.recipient must be an object');
  }
  const entries = Object.entries(value);
  if (entries.length === 0 || entries.length > 8) throw invalid('target.recipient is invalid');
  return Object.fromEntries(entries.map(([key, raw]) => {
    if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(key)) throw invalid('target recipient field is invalid');
    if (!['string', 'boolean', 'number'].includes(typeof raw)) {
      throw invalid('target recipient values must be scalar');
    }
    if (typeof raw === 'string' && (!raw.trim() || raw.length > 4_000)) {
      throw invalid('target recipient value is invalid');
    }
    return [key, typeof raw === 'string' ? raw.trim() : raw];
  }));
}

export function normalizeTargets(value) {
  if (!Array.isArray(value) || value.length === 0 || value.length > 20) {
    throw invalid('at least one notification target is required');
  }
  const seen = new Set();
  return value.map((item) => {
    if (!item || typeof item !== 'object' || Array.isArray(item)) {
      throw invalid('each target must be an object');
    }
    const channel = text(item.channel, 'target.channel', { max: 30 });
    if (!CHANNELS.includes(channel)) throw invalid(`unsupported channel: ${channel}`);
    const botId = text(item.botId, 'target.botId', { max: 256 });
    const recipient = normalizeRecipient(item.recipient);
    if (channel === 'dingtalk' && recipient !== undefined) {
      throw invalid('DingTalk manual targets are not accepted; select a recent conversation');
    }
    const key = `${channel}:${botId}:${JSON.stringify(recipient ?? null)}`;
    if (seen.has(key)) throw invalid('duplicate notification target');
    seen.add(key);
    return { channel, botId, ...(recipient ? { recipient } : {}) };
  });
}

export function normalizeTaskConfig(input, { defaults = {} } = {}) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw invalid('task must be an object');
  const workspace = resolve(text(input.workspace ?? defaults.workspace, 'workspace', { max: 4_000 }));
  if (!isAbsolute(workspace)) throw invalid('workspace must be an absolute path');
  const timezone = text(input.timezone ?? defaults.timezone ?? Intl.DateTimeFormat().resolvedOptions().timeZone, 'timezone', { max: 100 });
  if (!validTimezone(timezone)) throw invalid('timezone is not supported by this device');
  const schedule = normalizeSchedule(input.schedule);
  if (schedule.type === 'cron') {
    if (schedule.expression.split(/\s+/u).length !== 5) {
      throw invalid('schedule.expression must use the standard 5-field cron format');
    }
    try {
      CronExpressionParser.parse(schedule.expression, { currentDate: new Date(), tz: timezone });
    } catch {
      throw invalid('schedule.expression is not a valid cron expression');
    }
  }
  const timeoutMs = Number(input.timeoutMs ?? defaults.timeoutMs ?? 600_000);
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 10_000 || timeoutMs > 3_600_000) {
    throw invalid('timeoutMs must be an integer between 10000 and 3600000');
  }
  const toolPolicy = normalizeToolPolicy(input.toolPolicy);
  const sources = normalizeSources(input.sources);
  const disabledSource = sources.find((source) => toolPolicy[source.type] === false);
  if (disabledSource) {
    throw invalid(`toolPolicy.${disabledSource.type} must be enabled for configured ${disabledSource.type} sources`);
  }
  return {
    name: text(input.name, 'name', { max: 200 }),
    description: text(input.description, 'description', { optional: true, max: 2_000 }) ?? '',
    schedule,
    timezone,
    workspace,
    prompt: text(input.prompt, 'prompt', { max: 50_000 }),
    model: normalizeModel(input.model),
    toolPolicy,
    sources,
    targets: normalizeTargets(input.targets),
    timeoutMs,
  };
}

function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonical(value[key])]));
}

export function configFingerprint(config, targetVersions = []) {
  const critical = Object.fromEntries(CRITICAL_FIELDS.map((field) => [field, config[field]]));
  const credentialVersions = targetVersions.map((target) => ({
    channel: target.channel,
    botId: target.botId,
    recipient: target.recipient ?? null,
    credentialRevision: target.credentialRevision ?? -1,
  }));
  return createHash('sha256')
    .update(JSON.stringify(canonical({ config: critical, targetVersions: credentialVersions })))
    .digest('hex');
}

export function createDraft(config, { baseJobId = null, now = new Date().toISOString() } = {}) {
  return {
    id: randomUUID(),
    baseJobId,
    status: 'draft',
    revision: 1,
    config,
    createdAt: now,
    updatedAt: now,
    successfulPreflight: null,
    testRecords: [],
  };
}

export function invalidateDraft(draft, config, now = new Date().toISOString()) {
  return {
    ...draft,
    status: 'draft',
    revision: draft.revision + 1,
    config,
    updatedAt: now,
    successfulPreflight: null,
  };
}

export function publicFailure(stage, code, message, options = {}) {
  return {
    stage,
    ...(options.targetId ? { targetId: options.targetId } : {}),
    code,
    message,
    ...(typeof options.providerCode === 'string'
      && /^-?[A-Za-z0-9_.:-]{1,160}$/.test(options.providerCode)
      ? { providerCode: options.providerCode }
      : {}),
    ...(options.credentialRequired ? { credentialRequired: options.credentialRequired } : {}),
  };
}

export function errorCode(error, fallback) {
  return typeof error?.code === 'string' && error.code ? error.code : fallback;
}

export function hasOnlyMetadataChanges(current, next) {
  return CRITICAL_FIELDS.every((field) => JSON.stringify(current[field]) === JSON.stringify(next[field]));
}

export function newId() {
  return randomUUID();
}
