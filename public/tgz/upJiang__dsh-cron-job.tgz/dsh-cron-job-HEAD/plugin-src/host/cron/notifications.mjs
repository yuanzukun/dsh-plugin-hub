import { createHash } from 'node:crypto';

const CHANNEL_LABELS = Object.freeze({
  weixin: '微信',
  feishu: '飞书',
  dingtalk: '钉钉',
  wecom: '企业微信',
  qq: 'QQ',
  slack: 'Slack',
  telegram: 'Telegram',
  discord: 'Discord',
  whatsapp: 'WhatsApp',
});

function targetId(channel, botId, recipient) {
  return createHash('sha256')
    .update(`${channel}\0${botId}\0${JSON.stringify(recipient ?? null)}`)
    .digest('hex')
    .slice(0, 24);
}

function mask(value) {
  const text = String(value ?? '');
  if (text.length <= 8) return text ? `${text.slice(0, 2)}...` : '';
  return `${text.slice(0, 4)}...${text.slice(-4)}`;
}

function recipientLabel(channel, recipient) {
  if (!recipient) return '最近会话';
  if (channel === 'dingtalk') return '最近会话';
  const value = recipient.toUserId ?? recipient.receiveId ?? recipient.chatId
    ?? recipient.targetId ?? recipient.channelId ?? recipient.jid;
  return value ? mask(value) : '指定目标';
}

export class NotificationDispatcher {
  #controllers;
  #conversationRoutes;

  constructor(controllers, conversationRoutes = null) {
    this.#controllers = controllers;
    this.#conversationRoutes = conversationRoutes;
  }

  listTargets() {
    const items = [];
    for (const [channel, controller] of this.#controllers) {
      const targets = typeof controller?.notificationTargets === 'function'
        ? controller.notificationTargets()
        : [];
      for (const target of targets) {
        // DingTalk session webhooks contain short-lived signed credentials. Keep
        // only the bot reference in cron state and resolve the latest target at send time.
        const recipient = channel === 'dingtalk' ? null : (target.recipient ?? null);
        items.push({
          id: targetId(channel, target.botId, recipient),
          channel,
          channelLabel: CHANNEL_LABELS[channel] ?? channel,
          botId: target.botId,
          botName: target.name ?? target.botId,
          connected: target.connected === true,
          recipientLabel: recipientLabel(channel, recipient),
          credentialRevision: target.credentialRevision ?? 0,
          recipient,
        });
      }
    }
    return items;
  }

  resolveTargetRefs(targets, fallbackTargets = [], { sessionId } = {}) {
    const catalog = new Map(this.listTargets().map((item) => [item.id, item]));
    for (const target of fallbackTargets) {
      const id = targetId(target.channel, target.botId, target.recipient);
      if (!catalog.has(id)) catalog.set(id, target);
    }
    return targets.map((target) => {
      if (target?.currentConversation === true) {
        if (Object.keys(target).length !== 1) {
          const error = new Error('currentConversation cannot be combined with other target fields');
          error.code = 'invalid-current-conversation';
          throw error;
        }
        if (!this.#conversationRoutes || !sessionId) {
          const error = new Error('The current communication conversation is unavailable');
          error.code = 'current-conversation-unavailable';
          throw error;
        }
        return this.#conversationRoutes.resolve(sessionId);
      }
      if (!target?.targetRef) {
        if (!target?.recipientId) return target;
        const recipientId = String(target.recipientId).trim();
        const recipients = {
          weixin: { toUserId: recipientId },
          feishu: { receiveIdType: 'chat_id', receiveId: recipientId },
          wecom: { chatId: recipientId },
          qq: { scope: 'c2c', targetId: recipientId },
          slack: { channelId: recipientId },
          telegram: { chatId: recipientId },
          discord: { channelId: recipientId },
          whatsapp: { jid: recipientId },
        };
        if (!recipients[target.channel]) {
          const error = new Error(`Manual targets are not supported for ${target.channel}`);
          error.code = 'manual-target-unsupported';
          throw error;
        }
        return { channel: target.channel, botId: target.botId, recipient: recipients[target.channel] };
      }
      const found = catalog.get(target.targetRef);
      if (!found) {
        const error = new Error(`Notification target ${target.targetRef} is no longer available`);
        error.code = 'target-not-found';
        throw error;
      }
      return {
        channel: found.channel,
        botId: found.botId,
        ...(found.recipient ? { recipient: found.recipient } : {}),
      };
    });
  }

  targetVersions(targets) {
    const current = this.listTargets();
    return targets.map((target) => {
      const exact = current.find((item) => item.channel === target.channel
        && item.botId === target.botId
        && JSON.stringify(item.recipient ?? null) === JSON.stringify(target.recipient ?? null));
      const match = exact ?? current.find((item) => item.channel === target.channel
        && item.botId === target.botId);
      return {
        channel: target.channel,
        botId: target.botId,
        recipient: target.recipient ?? null,
        credentialRevision: match?.credentialRevision ?? -1,
        connected: match?.connected === true,
      };
    });
  }

  async send(target, text, { kind, runId, signal } = {}) {
    signal?.throwIfAborted();
    const controller = this.#controllers.get(target.channel);
    if (!controller || typeof controller.sendNotification !== 'function') {
      const error = new Error(`Channel ${target.channel} is unavailable`);
      error.code = 'channel-unavailable';
      throw error;
    }
    const started = Date.now();
    const result = await controller.sendNotification(target.botId, {
      text,
      ...(target.channel === 'dingtalk' ? {} : { recipient: target.recipient }),
      signal,
    });
    return {
      targetId: targetId(target.channel, target.botId, target.recipient),
      channel: target.channel,
      botId: target.botId,
      kind,
      runId,
      status: 'delivered',
      deliveredAt: new Date().toISOString(),
      durationMs: Date.now() - started,
      providerMessageIds: Array.isArray(result?.providerMessageIds)
        ? result.providerMessageIds.slice(0, 20)
        : [],
    };
  }

  publicTargets() {
    return this.listTargets().map(({ recipient: _recipient, ...item }) => item);
  }
}

export function publicTask(value) {
  if (!value) return value;
  const clone = structuredClone(value);
  const sanitize = (item) => {
    if (!item || typeof item !== 'object') return item;
    if (Array.isArray(item)) return item.map(sanitize);
    for (const [key, nested] of Object.entries(item)) {
      if (key === 'recipient') {
        delete item[key];
        continue;
      }
      if (key === 'config' || key === 'pendingConfig') {
        if (nested?.targets) nested.targets = nested.targets.map((target) => ({
          channel: target.channel,
          botId: target.botId,
          recipientLabel: recipientLabel(target.channel, target.recipient),
          targetRef: targetId(target.channel, target.botId, target.recipient),
        }));
      }
      if (key === 'targetVersions' && Array.isArray(nested)) {
        item[key] = nested.map((target) => ({
          channel: target.channel,
          botId: target.botId,
          targetRef: targetId(target.channel, target.botId, target.recipient),
          credentialRevision: target.credentialRevision,
          connected: target.connected,
        }));
      }
      sanitize(nested);
    }
    return item;
  };
  return sanitize(clone);
}
