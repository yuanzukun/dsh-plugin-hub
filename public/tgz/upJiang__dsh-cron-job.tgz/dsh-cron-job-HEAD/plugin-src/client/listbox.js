import * as React from 'react';
import { Check, ChevronDown } from 'lucide-react';

import { h } from './i18n.js';

export function Listbox({ label, value, options, disabled = false, onChange, className = '' }) {
  const [open, setOpen] = React.useState(false);
  const selectedIndex = Math.max(0, options.findIndex((option) => option.value === value));
  const [activeIndex, setActiveIndex] = React.useState(selectedIndex);
  const rootRef = React.useRef(null);
  const buttonRef = React.useRef(null);
  const listRef = React.useRef(null);
  const id = React.useId();
  const selected = options[selectedIndex] ?? options[0];

  React.useEffect(() => setActiveIndex(selectedIndex), [selectedIndex]);
  React.useEffect(() => {
    if (!open) return undefined;
    const close = (event) => {
      if (!rootRef.current?.contains(event.target)) setOpen(false);
    };
    document.addEventListener('pointerdown', close);
    return () => document.removeEventListener('pointerdown', close);
  }, [open]);

  const nextEnabled = (from, direction) => {
    let index = from;
    while (index >= 0 && index < options.length) {
      if (!options[index]?.disabled) return index;
      index += direction;
    }
    return from;
  };
  const show = (offset = 0) => {
    if (disabled || options.length === 0) return;
    setOpen(true);
    const direction = offset < 0 ? -1 : 1;
    const candidate = Math.max(0, Math.min(options.length - 1, selectedIndex + offset));
    setActiveIndex(nextEnabled(candidate, direction));
    queueMicrotask(() => listRef.current?.focus?.());
  };
  const choose = (index) => {
    const option = options[index];
    if (!option || option.disabled) return;
    onChange?.(option.value);
    setOpen(false);
    queueMicrotask(() => buttonRef.current?.focus?.());
  };
  const move = (event) => {
    if (event.key === 'Escape') {
      event.preventDefault();
      setOpen(false);
      buttonRef.current?.focus?.();
      return;
    }
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      choose(activeIndex);
      return;
    }
    let next = activeIndex;
    if (event.key === 'ArrowDown') next = nextEnabled(Math.min(options.length - 1, activeIndex + 1), 1);
    else if (event.key === 'ArrowUp') next = nextEnabled(Math.max(0, activeIndex - 1), -1);
    else if (event.key === 'Home') next = nextEnabled(0, 1);
    else if (event.key === 'End') next = nextEnabled(options.length - 1, -1);
    else return;
    event.preventDefault();
    setActiveIndex(next);
    document.getElementById(`${id}-option-${next}`)?.scrollIntoView?.({ block: 'nearest' });
  };

  return h('div', { ref: rootRef, className: `dim-listbox ${className}`.trim() },
    h('button', {
      ref: buttonRef,
      type: 'button',
      className: 'dim-listboxButton',
      disabled,
      'aria-label': label,
      'aria-haspopup': 'listbox',
      'aria-expanded': open,
      'aria-controls': `${id}-list`,
      onClick: () => open ? setOpen(false) : show(),
      onKeyDown: (event) => {
        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
          event.preventDefault();
          show(event.key === 'ArrowDown' ? 1 : -1);
        }
      },
    }, h('span', null, selected?.label ?? '请选择'), h(ChevronDown, { 'aria-hidden': 'true' })),
    open ? h('ul', {
      ref: listRef,
      id: `${id}-list`,
      className: 'dim-listboxOptions',
      role: 'listbox',
      tabIndex: 0,
      'aria-label': label,
      'aria-activedescendant': `${id}-option-${activeIndex}`,
      onKeyDown: move,
    }, options.map((option, index) => h('li', {
      key: option.value,
      id: `${id}-option-${index}`,
      className: 'dim-listboxOption',
      role: 'option',
      'aria-selected': option.value === value,
      'aria-disabled': option.disabled || undefined,
      'data-active': index === activeIndex,
      onPointerMove: () => setActiveIndex(index),
      onClick: () => choose(index),
    }, h('span', null, option.label), option.value === value ? h(Check, { 'aria-hidden': 'true' }) : null))) : null,
  );
}
