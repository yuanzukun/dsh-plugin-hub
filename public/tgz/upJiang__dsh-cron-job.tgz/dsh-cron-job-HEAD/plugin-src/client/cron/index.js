import * as React from 'react';
import {
  Bot,
  CalendarClock,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleAlert,
  CircleCheck,
  CircleDashed,
  Clock3,
  FileText,
  History,
  LoaderCircle,
  MessageSquareText,
  Pause,
  Pencil,
  Play,
  Plus,
  RefreshCw,
  Search,
  Send,
  Settings2,
  Square,
  Trash2,
  X,
} from 'lucide-react';

import { h } from '../i18n.js';
import { createCronJobApi } from './api.js';

const PAGE_SIZE = 10;
export const PRODUCT_DISCOVERY_EXAMPLE = '每天上午 8:30，读取 Product Hunt RSS Feed（https://www.producthunt.com/feed）和 GitHub Trending（https://github.com/trending）当前返回的最新一批内容。各选排在最前的 10 条，每条只用一行输出“名称：极简摘要｜原始链接”；不输出 HTTP 状态、来源验证过程、发布时间或额外背景。末尾的跨站汇总最多 3 条，整体尽量控制在两段微信消息内。以来源自身的排序和时间戳为准，不要求条目日期等于任务所在时区的自然日。任一来源返回非 2xx、无法访问、内容为空、无法解析出至少 10 条带原始链接的内容时，立即让本次任务失败，不生成占位条目，也不推送成功摘要。';
const CHANNEL_LABELS = Object.freeze({
  weixin: '微信',
  feishu: '飞书',
  dingtalk: '钉钉',
  wecom: '企业微信',
  qq: 'QQ',
  slack: 'Slack',
  telegram: 'Telegram',
  discord: 'Discord',
  whatsapp: 'WhatsApp',
});
const STAGES = Object.freeze([
  ['workspace', '工作区'],
  ['model', '模型'],
  ['agent', 'Agent'],
  ['source', '数据源'],
  ['target', '推送'],
]);
const DIALOG_FOCUSABLE = [
  'a[href]',
  'button:not([disabled])',
  'input:not([disabled])',
  'textarea:not([disabled])',
  '[tabindex]:not([tabindex="-1"])',
].join(',');

function useMounted() {
  const mounted = React.useRef(true);
  React.useEffect(() => () => { mounted.current = false; }, []);
  return mounted;
}

function displayTime(value) {
  if (!value) return '尚未安排';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(undefined, {
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit',
  }).format(date);
}

function toLocalDateTime(value) {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60_000);
  return local.toISOString().slice(0, 16);
}

function scheduleText(config) {
  const schedule = config?.schedule;
  if (!schedule) return '未设置计划';
  if (schedule.type === 'cron') return `${schedule.expression} · ${config.timezone}`;
  if (schedule.type === 'once') return `单次 · ${displayTime(schedule.at)}`;
  return `每 ${schedule.seconds} 秒 · ${config.timezone}`;
}

function stateInfo(item, running) {
  if (running) return { label: '运行中', tone: 'warning' };
  if (item.state === 'active') return { label: '已启用', tone: 'success' };
  if (item.state === 'paused') return { label: '已暂停', tone: '' };
  if (item.status === 'ready') return { label: '待确认', tone: 'success' };
  if (item.status === 'testing') return { label: '测试中', tone: 'warning' };
  if (item.status === 'test_failed') return { label: '测试失败', tone: 'danger' };
  return { label: item.baseJobId ? '待发布' : '草稿', tone: '' };
}

function modelValue(model) {
  return model ? `${model.provider}\u0000${model.model}` : '';
}

function modelFromValue(value, reasoningEffort) {
  if (!value) return null;
  const [provider, model] = value.split('\u0000');
  return { provider, model, ...(reasoningEffort ? { reasoningEffort } : {}) };
}

function modelOptions(catalog) {
  return [
    { value: '', label: '跟随 Host 默认模型' },
    ...(catalog?.models?.groups ?? []).flatMap((group) => group.models.map((model) => ({
      value: `${group.id}\u0000${model.id}`,
      label: `${group.name} / ${model.name}`,
      group,
      model,
    }))),
  ];
}

function selectedModelOption(catalog, value) {
  return modelOptions(catalog).find((option) => option.value === value);
}

export function AccessibleListbox({ id, label, value, options, onChange, disabled = false }) {
  const [open, setOpen] = React.useState(false);
  const selectedIndex = Math.max(0, options.findIndex((option) => option.value === value));
  const [activeIndex, setActiveIndex] = React.useState(selectedIndex);
  const rootRef = React.useRef(null);
  const buttonRef = React.useRef(null);
  const listRef = React.useRef(null);
  const labelId = `${id}-label`;
  const listId = `${id}-listbox`;
  const selected = options[selectedIndex] ?? options[0];

  React.useEffect(() => {
    if (!open) return undefined;
    const close = (event) => {
      if (!rootRef.current?.contains(event.target)) setOpen(false);
    };
    document.addEventListener('pointerdown', close);
    return () => document.removeEventListener('pointerdown', close);
  }, [open]);

  React.useEffect(() => {
    setActiveIndex(selectedIndex);
  }, [selectedIndex]);

  const show = (direction = 0) => {
    if (disabled || options.length === 0) return;
    setOpen(true);
    setActiveIndex(Math.max(0, Math.min(options.length - 1, selectedIndex + direction)));
    queueMicrotask(() => listRef.current?.focus?.());
  };
  const choose = (index) => {
    const option = options[index];
    if (!option) return;
    onChange(option.value);
    setOpen(false);
    queueMicrotask(() => buttonRef.current?.focus?.());
  };
  const onButtonKeyDown = (event) => {
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      show(event.key === 'ArrowDown' ? 1 : -1);
    }
  };
  const onListKeyDown = (event) => {
    if (event.key === 'Escape') {
      event.preventDefault();
      setOpen(false);
      buttonRef.current?.focus?.();
      return;
    }
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      choose(activeIndex);
      return;
    }
    let next = activeIndex;
    if (event.key === 'ArrowDown') next = Math.min(options.length - 1, activeIndex + 1);
    else if (event.key === 'ArrowUp') next = Math.max(0, activeIndex - 1);
    else if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = options.length - 1;
    else return;
    event.preventDefault();
    setActiveIndex(next);
    document.getElementById(`${id}-option-${next}`)?.scrollIntoView?.({ block: 'nearest' });
  };

  return h('div', { className: 'dcj-field' },
    h('span', { id: labelId, className: 'dcj-fieldLabel' }, label),
    h('div', { className: 'dcj-select', ref: rootRef },
      h('button', {
        ref: buttonRef,
        type: 'button',
        className: 'dcj-selectButton',
        'aria-labelledby': `${labelId} ${id}-value`,
        'aria-haspopup': 'listbox',
        'aria-expanded': open,
        'aria-controls': listId,
        disabled,
        onClick: () => open ? setOpen(false) : show(),
        onKeyDown: onButtonKeyDown,
      },
      h('span', { id: `${id}-value` }, selected?.label ?? '请选择'),
      h(ChevronDown, { 'aria-hidden': 'true' })),
      open ? h('ul', {
        ref: listRef,
        id: listId,
        className: 'dcj-options',
        role: 'listbox',
        tabIndex: 0,
        'aria-labelledby': labelId,
        'aria-activedescendant': `${id}-option-${activeIndex}`,
        onKeyDown: onListKeyDown,
      }, options.map((option, index) => h('li', {
        key: option.value,
        id: `${id}-option-${index}`,
        className: 'dcj-option',
        role: 'option',
        'aria-selected': option.value === value,
        'data-active': index === activeIndex,
        onPointerMove: () => setActiveIndex(index),
        onClick: () => choose(index),
      },
      h('span', null, option.label),
      option.value === value ? h(Check, { 'aria-hidden': 'true' }) : null))) : null),
  );
}

function TargetPicker({ catalog, selected, onChange, compact = false, currentTargets = [] }) {
  const targets = [...(catalog?.targets ?? [])];
  const known = new Set(targets.map((target) => target.id));
  for (const target of currentTargets) {
    const id = target.targetRef ?? target.id;
    if (!id || known.has(id)) continue;
    known.add(id);
    targets.push({
      ...target,
      id,
      channelLabel: CHANNEL_LABELS[target.channel] ?? target.channel,
      botName: target.botName ?? target.botId,
      recipientLabel: target.recipientLabel ?? '当前任务目标',
      connected: false,
      retained: true,
    });
  }
  const selectedSet = new Set(selected);
  if (targets.length === 0) {
    return h('p', { className: 'dcj-error', role: 'alert' }, '没有可用的推送目标，请先到“通讯账号”连接账号并产生一条最近会话。');
  }
  return h('div', { className: compact ? 'dcj-targets dcj-span2' : 'dcj-targets' },
    targets.map((target) => h('label', { key: target.id, className: 'dcj-target' },
      h('input', {
        type: 'checkbox',
        checked: selectedSet.has(target.id),
        onChange: (event) => {
          const next = new Set(selectedSet);
          if (event.target.checked) next.add(target.id); else next.delete(target.id);
          onChange([...next]);
        },
      }),
      h('span', { className: 'dcj-targetCopy' },
        h('span', null, `${target.channelLabel} · ${target.botName}`),
        h('small', null, target.retained
          ? `${target.recipientLabel} · 已从任务配置保留`
          : `${target.recipientLabel} · ${target.connected ? '在线' : '离线'}`)))),
  );
}

export function NaturalDraftForm({ api, catalog, onCreated, onOpenAccounts }) {
  const [description, setDescription] = React.useState('');
  const [workspace, setWorkspace] = React.useState(catalog?.workspaces?.[0] ?? '');
  const [model, setModel] = React.useState('');
  const [targets, setTargets] = React.useState([]);
  const [expanded, setExpanded] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState('');
  const workspaceOptions = (catalog?.workspaces ?? []).map((path) => ({ value: path, label: path }));

  React.useEffect(() => {
    if (!workspace && catalog?.workspaces?.[0]) setWorkspace(catalog.workspaces[0]);
  }, [catalog, workspace]);

  const submit = async () => {
    if (!description.trim()) { setError('请先描述要定时执行的任务。'); return; }
    if (!workspace) { setError('请选择工作区。'); setExpanded(true); return; }
    if (targets.length === 0) { setError('至少选择一个推送目标。'); setExpanded(true); return; }
    setBusy(true);
    setError('');
    try {
      const draft = await api.draftNatural(description.trim(), {
        workspace,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
        model: modelFromValue(model),
        targets: targets.map((targetRef) => ({ targetRef })),
      });
      onCreated(draft);
      setDescription('');
    } catch (cause) {
      setError(cause?.message ?? '无法生成任务草稿，请检查模型和配置。');
    } finally {
      setBusy(false);
    }
  };

  return h('section', { className: 'dcj-create', 'aria-labelledby': 'dcj-create-heading' },
    h('div', { className: 'dcj-createHeader' },
      h('div', { className: 'dcj-createHeaderCopy' },
        h('h3', { id: 'dcj-create-heading' }, '用自然语言创建'),
        h('p', { className: 'dcj-createNote' }, '创建前必须完成真实试运行和全部渠道测试')),
      h('div', { className: 'dcj-createHeaderActions' },
        h('button', {
          type: 'button',
          className: 'dcj-secondary dcj-exampleButton',
          disabled: busy || Boolean(description.trim()),
          title: description.trim() ? '清空任务描述后可载入示例' : '载入可编辑的任务示例',
          onClick: () => {
            setDescription(PRODUCT_DISCOVERY_EXAMPLE);
            setExpanded(true);
            setError('');
          },
        }, h(FileText, { 'aria-hidden': 'true' }), '载入示例'))),
    h('div', { className: 'dcj-promptRow' },
      h('div', { className: 'dcj-field' },
        h('label', { htmlFor: 'dcj-natural-prompt' }, '任务描述'),
        h('textarea', {
          id: 'dcj-natural-prompt',
          className: 'dcj-textarea',
          value: description,
          placeholder: '例如：每个工作日上午汇总指定网站的新内容，并推送到团队群。',
          onChange: (event) => setDescription(event.target.value),
          onKeyDown: (event) => {
            if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') void submit();
          },
        }),
        h('p', { className: 'dcj-help' }, '模型只生成草稿；测试通过并由你确认后才会启用。')),
      h('button', {
        type: 'button', className: 'dcj-primary', disabled: busy, onClick: submit,
      }, busy ? h(LoaderCircle, { className: 'dcj-spin', 'aria-hidden': 'true' }) : h(Plus, { 'aria-hidden': 'true' }),
      busy ? '正在生成草稿' : '生成任务草稿')),
    h('button', {
      type: 'button',
      className: 'dcj-secondary dcj-createConfigToggle',
      'aria-expanded': expanded,
      onClick: () => setExpanded((value) => !value),
    }, h(Settings2, { 'aria-hidden': 'true' }), expanded ? '收起创建配置' : '设置工作区、模型和推送目标'),
    expanded ? h('div', { className: 'dcj-formGrid dcj-createConfig' },
      workspaceOptions.length > 0
        ? h(AccessibleListbox, {
            id: 'dcj-create-workspace', label: '工作区', value: workspace,
            options: workspaceOptions, onChange: setWorkspace,
          })
        : h('div', { className: 'dcj-field' },
            h('label', { htmlFor: 'dcj-create-workspace-input' }, '工作区绝对路径'),
            h('input', {
              id: 'dcj-create-workspace-input', className: 'dcj-input', value: workspace,
              onChange: (event) => setWorkspace(event.target.value),
            })),
      h(AccessibleListbox, {
        id: 'dcj-create-model', label: '模型', value: model,
        options: modelOptions(catalog), onChange: setModel,
      }),
      h('div', { className: 'dcj-span2 dcj-targetField' },
        h('span', { className: 'dcj-fieldLabel' }, '推送目标'),
        h(TargetPicker, { catalog, selected: targets, onChange: setTargets, compact: true }),
        h('button', { type: 'button', className: 'dcj-secondary dcj-accountButton', onClick: () => onOpenAccounts() },
          h(MessageSquareText, { 'aria-hidden': 'true' }), '管理通讯账号')),
    ) : null,
    error ? h('p', { className: 'dcj-error', role: 'alert' }, error) : null,
  );
}

function sourceLines(sources) {
  return (sources ?? []).map((source) => `${source.type}${source.url ? ` ${source.url}` : ''}`).join('\n');
}

function parseSources(value) {
  return String(value ?? '').split(/\r?\n/u).map((line) => line.trim()).filter(Boolean).map((line) => {
    const [type, ...rest] = line.split(/\s+/u);
    return { type, ...(rest.length ? { url: rest.join(' ') } : {}) };
  });
}

function editorInitial(item) {
  const config = item.config;
  return {
    name: config.name,
    description: config.description ?? '',
    scheduleType: config.schedule.type,
    scheduleValue: config.schedule.type === 'cron' ? config.schedule.expression
      : config.schedule.type === 'once' ? toLocalDateTime(config.schedule.at)
        : String(config.schedule.seconds),
    timezone: config.timezone,
    workspace: config.workspace,
    prompt: config.prompt,
    model: modelValue(config.model),
    reasoningEffort: config.model?.reasoningEffort ?? '',
    web: config.toolPolicy?.web !== false,
    search: config.toolPolicy?.search !== false,
    fetch: config.toolPolicy?.fetch !== false,
    rss: config.toolPolicy?.rss !== false,
    deny: (config.toolPolicy?.deny ?? []).join(', '),
    sources: sourceLines(config.sources),
    targetRefs: config.targets.map((target) => target.targetRef).filter(Boolean),
    timeoutMinutes: String(Math.round((config.timeoutMs ?? 600_000) / 60_000)),
  };
}

function formTask(form) {
  let schedule;
  if (form.scheduleType === 'cron') schedule = { type: 'cron', expression: form.scheduleValue.trim() };
  else if (form.scheduleType === 'once') schedule = {
    type: 'once', at: new Date(form.scheduleValue).toISOString(),
  };
  else schedule = { type: 'interval', seconds: Number(form.scheduleValue) };
  return {
    name: form.name,
    description: form.description,
    schedule,
    timezone: form.timezone,
    workspace: form.workspace,
    prompt: form.prompt,
    model: modelFromValue(form.model, form.reasoningEffort),
    toolPolicy: {
      web: form.web,
      search: form.search,
      fetch: form.fetch,
      rss: form.rss,
      deny: form.deny.split(',').map((value) => value.trim()).filter(Boolean),
    },
    sources: parseSources(form.sources),
    targets: form.targetRefs.map((targetRef) => ({ targetRef })),
    timeoutMs: Number(form.timeoutMinutes) * 60_000,
  };
}

function StageProgress({ progress, record }) {
  const recordTargetStatus = record?.failures?.some((failure) => failure.stage === 'target')
    ? 'failed'
    : record?.receipts?.length > 0 ? 'passed' : undefined;
  return h('div', { className: 'dcj-stageList', 'aria-label': '完整试运行进度' },
    STAGES.map(([stage, label]) => {
      const status = stage === 'target'
        ? (progress?.targets && Object.values(progress.targets).some((item) => item.status === 'failed')
            ? 'failed'
            : progress?.targets && Object.values(progress.targets).some((item) => item.status === 'running')
              ? 'running'
              : recordTargetStatus)
        : progress?.stages?.[stage]?.status
          ?? (record?.failures?.some((failure) => failure.stage === stage) ? 'failed' : undefined);
      const Icon = status === 'passed' ? CircleCheck
        : status === 'failed' ? CircleAlert
          : status === 'running' ? LoaderCircle : CircleDashed;
      return h('div', { key: stage, className: 'dcj-stage', 'data-status': status ?? 'pending' },
        h(Icon, { 'aria-hidden': 'true' }),
        h('span', null, label));
    }),
  );
}

function RunsHistory({ records }) {
  return h('section', { className: 'dcj-history', 'aria-labelledby': 'dcj-history-heading' },
    h('h4', { id: 'dcj-history-heading' }, '运行与测试记录'),
    records.length === 0 ? h('p', { className: 'dcj-help' }, '还没有运行记录。') : records.map((record) => h('article', {
      key: record.id, className: 'dcj-historyItem',
    },
    h('div', { className: 'dcj-historyTop' },
      h('span', null, `${record.kind === 'preflight' ? '创建测试' : '正式运行'} · ${displayTime(record.startedAt)}`),
      h('span', { className: 'dcj-badge', 'data-tone': record.status === 'passed' || record.status === 'succeeded' ? 'success' : record.status === 'running' ? 'warning' : 'danger' }, record.status)),
    record.output ? h('pre', { className: 'dcj-output' }, record.output) : null,
    record.failures?.length ? h('ul', { className: 'dcj-failures' }, record.failures.map((failure, index) => h('li', {
      key: `${failure.stage}-${index}`, className: 'dcj-failure',
    }, h('span', null, `${failure.stage}: ${failure.message}`)))) : null,
    record.receipts?.length ? h('div', { className: 'dcj-receipts' }, record.receipts.map((receipt, index) => h('span', {
      key: `${receipt.targetId}-${index}`,
      className: 'dcj-badge',
      'data-tone': receipt.status === 'delivered' ? 'success' : 'danger',
    }, `${CHANNEL_LABELS[receipt.channel] ?? receipt.channel} · ${receipt.status}`))) : null)),
  );
}

export function TaskEditor({ item, catalog, api, progress, onClose, onChanged, onOpenAccounts }) {
  const [current, setCurrent] = React.useState(item);
  const [form, setForm] = React.useState(() => editorInitial(item));
  const [busy, setBusy] = React.useState('');
  const [error, setError] = React.useState('');
  const [records, setRecords] = React.useState([]);
  const dialogRef = React.useRef(null);
  const firstInputRef = React.useRef(null);
  const busyRef = React.useRef(busy);
  const closeRef = React.useRef(onClose);
  const mounted = useMounted();
  const isDraft = !current.state;
  const modelOption = selectedModelOption(catalog, form.model);
  const reasoningOptions = [
    { value: '', label: '模型默认推理等级' },
    ...(modelOption?.model?.reasoning?.efforts ?? []).map((effort) => ({
      value: effort.id, label: effort.name,
    })),
  ];
  const scheduleOptions = [
    { value: 'cron', label: 'Cron 表达式' },
    { value: 'once', label: '单次时间' },
    { value: 'interval', label: '固定间隔' },
  ];
  const latestRecord = current.testRecords?.at?.(-1) ?? records.find((record) => record.kind === 'preflight');
  busyRef.current = busy;
  closeRef.current = onClose;

  React.useEffect(() => {
    const ownerDocument = document;
    const priorFocus = ownerDocument.activeElement;
    queueMicrotask(() => {
      if (dialogRef.current) firstInputRef.current?.focus?.();
    });
    const onKey = (event) => {
      if (event.defaultPrevented) return;
      if (event.key === 'Escape') {
        if (!busyRef.current) closeRef.current();
        return;
      }
      if (event.key !== 'Tab') return;
      const dialog = dialogRef.current;
      const focusable = [...(dialog?.querySelectorAll?.(DIALOG_FOCUSABLE) ?? [])]
        .filter((element) => element.getAttribute?.('aria-hidden') !== 'true');
      if (focusable.length === 0) {
        event.preventDefault();
        dialog?.focus?.();
        return;
      }
      const first = focusable[0];
      const last = focusable.at(-1);
      const active = ownerDocument.activeElement;
      if (event.shiftKey && (active === first || !dialog?.contains?.(active))) {
        event.preventDefault();
        last.focus?.();
      } else if (!event.shiftKey && (active === last || !dialog?.contains?.(active))) {
        event.preventDefault();
        first.focus?.();
      }
    };
    ownerDocument.addEventListener('keydown', onKey);
    return () => {
      ownerDocument.removeEventListener('keydown', onKey);
      if (priorFocus?.isConnected !== false) priorFocus?.focus?.();
    };
  }, []);

  React.useEffect(() => {
    const controller = new AbortController();
    api.runs(current.id, { pageSize: 20, includeTests: true }, controller.signal)
      .then((value) => { if (mounted.current) setRecords(value.items ?? []); })
      .catch(() => undefined);
    return () => controller.abort();
  }, [api, current.id, mounted]);

  const set = (key, value) => setForm((previous) => ({ ...previous, [key]: value }));
  const confirm = async () => {
    setBusy('confirming');
    setError('');
    try {
      const job = await api.confirm(current.id);
      onChanged(job);
      onClose();
    } catch (cause) {
      if (mounted.current) setError(cause?.message ?? '确认启用失败。');
    } finally {
      if (mounted.current) setBusy('');
    }
  };
  const addManualTarget = () => {
    const channel = form.manualChannel || 'weixin';
    const botId = String(form.manualBotId ?? '').trim();
    const recipientId = String(form.manualRecipientId ?? '').trim();
    if (!botId || !recipientId) { setError('手填目标需要账号 ID 和平台目标 ID。'); return; }
    const token = `manual:${channel}:${botId}:${recipientId}`;
    setForm((previous) => ({
      ...previous,
      targetRefs: [...previous.targetRefs, token],
      manualTargets: [...(previous.manualTargets ?? []), { token, channel, botId, recipientId }],
      manualRecipientId: '',
    }));
  };
  const taskPayload = () => {
    const base = formTask(form);
    const manual = new Map((form.manualTargets ?? []).map((target) => [target.token, target]));
    base.targets = form.targetRefs.map((targetRef) => {
      const target = manual.get(targetRef);
      return target ? { channel: target.channel, botId: target.botId, recipientId: target.recipientId } : { targetRef };
    });
    return base;
  };
  const failures = latestRecord?.failures ?? [];
  const activeProgress = progress?.testId ? progress : null;

  return h('div', { className: 'dcj-drawerBackdrop', role: 'presentation', onMouseDown: (event) => {
    if (event.target === event.currentTarget && !busy) onClose();
  } },
  h('section', {
    ref: dialogRef,
    className: 'dcj-drawer',
    role: 'dialog',
    tabIndex: -1,
    'aria-modal': 'true',
    'aria-labelledby': 'dcj-editor-title',
  },
  h('header', { className: 'dcj-drawerHeader' },
    h('h3', { id: 'dcj-editor-title' }, isDraft ? '任务草稿' : '编辑定时任务'),
    h('button', { type: 'button', className: 'dcj-iconButton', 'aria-label': '关闭', disabled: Boolean(busy), onClick: onClose },
      h(X, { 'aria-hidden': 'true' }))),
  h('div', { className: 'dcj-drawerBody' },
    h('div', { className: 'dcj-formGrid' },
      h('div', { className: 'dcj-field' },
        h('label', { htmlFor: 'dcj-task-name' }, '名称'),
        h('input', { ref: firstInputRef, id: 'dcj-task-name', className: 'dcj-input', value: form.name, onChange: (event) => set('name', event.target.value) })),
      h('div', { className: 'dcj-field' },
        h('label', { htmlFor: 'dcj-task-description' }, '描述'),
        h('input', { id: 'dcj-task-description', className: 'dcj-input', value: form.description, onChange: (event) => set('description', event.target.value) })),
      h('div', { className: 'dcj-span2 dcj-scheduleGrid' },
        h(AccessibleListbox, { id: 'dcj-schedule-type', label: '计划类型', value: form.scheduleType, options: scheduleOptions, onChange: (value) => {
          setForm((previous) => ({ ...previous, scheduleType: value, scheduleValue: value === 'cron' ? '0 8 * * *' : value === 'once' ? toLocalDateTime(new Date(Date.now() + 3_600_000).toISOString()) : '3600' }));
        } }),
        h('div', { className: 'dcj-field' },
          h('label', { htmlFor: 'dcj-schedule-value' }, form.scheduleType === 'cron' ? '5 段 Cron 表达式' : form.scheduleType === 'once' ? '执行时间' : '间隔秒数'),
          h('input', {
            id: 'dcj-schedule-value', className: 'dcj-input',
            type: form.scheduleType === 'once' ? 'datetime-local' : form.scheduleType === 'interval' ? 'number' : 'text',
            min: form.scheduleType === 'interval' ? 60 : undefined,
            value: form.scheduleValue, onChange: (event) => set('scheduleValue', event.target.value),
          }))),
      h('div', { className: 'dcj-field' },
        h('label', { htmlFor: 'dcj-timezone' }, '时区'),
        h('input', { id: 'dcj-timezone', className: 'dcj-input', value: form.timezone, onChange: (event) => set('timezone', event.target.value) })),
      h('div', { className: 'dcj-field' },
        h('label', { htmlFor: 'dcj-workspace' }, '工作区绝对路径'),
        h('input', { id: 'dcj-workspace', className: 'dcj-input', value: form.workspace, onChange: (event) => set('workspace', event.target.value) })),
      h(AccessibleListbox, { id: 'dcj-model', label: 'Provider / 模型', value: form.model, options: modelOptions(catalog), onChange: (value) => {
        setForm((previous) => ({ ...previous, model: value, reasoningEffort: '' }));
      } }),
      h(AccessibleListbox, { id: 'dcj-reasoning', label: '推理等级', value: form.reasoningEffort, options: reasoningOptions, onChange: (value) => set('reasoningEffort', value), disabled: !form.model || reasoningOptions.length === 1 }),
      h('div', { className: 'dcj-field dcj-span2' },
        h('label', { htmlFor: 'dcj-prompt' }, 'Agent 提示词'),
        h('textarea', { id: 'dcj-prompt', className: 'dcj-textarea', value: form.prompt, onChange: (event) => set('prompt', event.target.value) })),
      h('div', { className: 'dcj-field dcj-span2' },
        h('span', { className: 'dcj-fieldLabel' }, '只读工具权限'),
        h('div', { className: 'dcj-checks' }, ['web', 'search', 'fetch', 'rss'].map((key) => h('label', { key, className: 'dcj-check' },
          h('input', { type: 'checkbox', checked: form[key], onChange: (event) => set(key, event.target.checked) }),
          h('span', null, key)))),
      h('div', { className: 'dcj-field' },
        h('label', { htmlFor: 'dcj-deny' }, '额外禁用工具'),
        h('input', { id: 'dcj-deny', className: 'dcj-input', value: form.deny, placeholder: '逗号分隔工具名称', onChange: (event) => set('deny', event.target.value) })),
      h('div', { className: 'dcj-field' },
        h('label', { htmlFor: 'dcj-timeout' }, '超时（分钟）'),
        h('input', { id: 'dcj-timeout', className: 'dcj-input', type: 'number', min: 1, max: 60, value: form.timeoutMinutes, onChange: (event) => set('timeoutMinutes', event.target.value) })),
      h('div', { className: 'dcj-field dcj-span2' },
        h('label', { htmlFor: 'dcj-sources' }, '需要验证的数据源'),
        h('textarea', { id: 'dcj-sources', className: 'dcj-textarea', value: form.sources, placeholder: '每行一个，例如：\nweb https://example.com\nrss https://example.com/feed.xml\nsearch', onChange: (event) => set('sources', event.target.value) }),
        h('p', { className: 'dcj-help' }, '支持 web、rss、search、fetch。试运行必须观察到每种来源对应的真实工具调用。')),
      h('div', { className: 'dcj-field dcj-span2' },
        h('span', { className: 'dcj-fieldLabel' }, '推送目标'),
        h(TargetPicker, { catalog, currentTargets: current.config.targets, selected: form.targetRefs.filter((ref) => !ref.startsWith('manual:')), onChange: (refs) => {
          setForm((previous) => ({ ...previous, targetRefs: [...refs, ...previous.targetRefs.filter((ref) => ref.startsWith('manual:'))] }));
        } }),
        (form.manualTargets ?? []).map((target) => h('div', { key: target.token, className: 'dcj-target' },
          h('button', { type: 'button', className: 'dcj-iconButton', 'aria-label': '移除手填目标', onClick: () => setForm((previous) => ({
            ...previous,
            targetRefs: previous.targetRefs.filter((ref) => ref !== target.token),
            manualTargets: previous.manualTargets.filter((item) => item.token !== target.token),
          })) }, h(X, { 'aria-hidden': 'true' })),
          h('span', { className: 'dcj-targetCopy' }, h('span', null, `${CHANNEL_LABELS[target.channel]} · ${target.botId}`), h('small', null, target.recipientId)))),
        h('div', { className: 'dcj-formGrid' },
          h(AccessibleListbox, { id: 'dcj-manual-channel', label: '手填平台', value: form.manualChannel ?? 'weixin', options: Object.entries(CHANNEL_LABELS).filter(([channel]) => channel !== 'dingtalk').map(([value, label]) => ({ value, label })), onChange: (value) => set('manualChannel', value) }),
          h('div', { className: 'dcj-field' }, h('label', { htmlFor: 'dcj-manual-bot' }, '账号 / Bot ID'), h('input', { id: 'dcj-manual-bot', className: 'dcj-input', value: form.manualBotId ?? '', onChange: (event) => set('manualBotId', event.target.value) })),
          h('div', { className: 'dcj-field' }, h('label', { htmlFor: 'dcj-manual-recipient' }, '平台目标 ID'), h('input', { id: 'dcj-manual-recipient', className: 'dcj-input', value: form.manualRecipientId ?? '', onChange: (event) => set('manualRecipientId', event.target.value) })),
          h('button', { type: 'button', className: 'dcj-secondary', onClick: addManualTarget }, h(Plus, { 'aria-hidden': 'true' }), '添加手填目标'))),
    ),
    isDraft ? h('section', { className: 'dcj-preflight', 'aria-labelledby': 'dcj-preflight-heading' },
      h('h4', { id: 'dcj-preflight-heading' }, '创建门禁'),
      h(StageProgress, { progress: activeProgress, record: latestRecord }),
      failures.length ? h('ul', { className: 'dcj-failures' }, failures.map((failure, index) => h('li', { key: `${failure.stage}-${index}`, className: 'dcj-failure' },
        h('span', null, `${failure.message}`),
        failure.stage === 'target' ? h('button', { type: 'button', className: 'dcj-secondary', onClick: () => onOpenAccounts(failure.credentialRequired?.channel) }, '修复账号') : null))) : null,
      current.status === 'ready' ? h('p', { className: 'dcj-help' }, '当前配置与成功测试指纹一致，可以确认启用。') : h('p', { className: 'dcj-help' }, '修改计划、工作区、提示词、模型、工具或推送目标后，必须重新完成全部测试。')) : null,
    h(RunsHistory, { records }),
    error ? h('p', { className: 'dcj-error', role: 'alert' }, error) : null),
  h('footer', { className: 'dcj-drawerFooter' },
    h('span', { className: 'dcj-help' }, current.status === 'ready' ? '测试已通过，等待你的确认。' : '测试消息会标记为“定时任务创建测试”。'),
    h('div', { className: 'dcj-footerActions' },
      h('button', { type: 'button', className: 'dcj-secondary', disabled: Boolean(busy), onClick: onClose }, '取消'),
      h('button', { type: 'button', className: 'dcj-secondary', disabled: Boolean(busy), onClick: async () => {
        // Save with manual targets included.
        setBusy('saving'); setError('');
        try {
          const next = isDraft ? await api.updateDraft(current.id, taskPayload()) : await api.update(current.id, taskPayload());
          if (mounted.current) { setCurrent(next); setForm(editorInitial(next)); onChanged(next); }
        } catch (cause) { if (mounted.current) setError(cause?.message ?? '保存失败。'); }
        finally { if (mounted.current) setBusy(''); }
      } }, busy === 'saving' ? '保存中' : '保存'),
      isDraft && current.status !== 'ready' ? h('button', { type: 'button', className: 'dcj-primary', disabled: Boolean(busy), onClick: async () => {
        setBusy('saving'); setError('');
        try {
          const saved = await api.updateDraft(current.id, taskPayload());
          if (!mounted.current) return;
          setCurrent(saved); setForm(editorInitial(saved)); onChanged(saved); setBusy('testing');
          const tested = await api.test(saved.id);
          if (!mounted.current) return;
          setCurrent(tested); setForm(editorInitial(tested)); onChanged(tested);
          setRecords((previous) => [tested.testRecords?.at?.(-1), ...previous].filter(Boolean));
        } catch (cause) { if (mounted.current) setError(cause?.message ?? '完整试运行失败。'); }
        finally { if (mounted.current) setBusy(''); }
      } }, h(Send, { 'aria-hidden': 'true' }), busy === 'testing' ? '完整试运行中' : '测试并创建') : null,
      isDraft && current.status === 'ready' ? h('button', { type: 'button', className: 'dcj-primary', disabled: Boolean(busy), onClick: confirm }, h(Check, { 'aria-hidden': 'true' }), busy === 'confirming' ? '正在启用' : '确认并启用') : null)),
  )));
}

function JobRow({ item, running, onOpen, onAction, actionBusy, deleteConfirm, onDeleteConfirm }) {
  const info = stateInfo(item, running);
  const isDraft = !item.state;
  return h('article', { className: 'dcj-job' },
    h('div', { className: 'dcj-jobMain' },
      h('div', { className: 'dcj-jobTitle' },
        h('button', { type: 'button', onClick: () => onOpen(item) }, item.config.name),
        h('span', { className: 'dcj-badge', 'data-tone': info.tone }, info.label)),
      h('div', { className: 'dcj-jobMeta' },
        h('span', null, h(CalendarClock, { 'aria-hidden': 'true' }), scheduleText(item.config)),
        h('span', null, h(Clock3, { 'aria-hidden': 'true' }), isDraft ? `更新于 ${displayTime(item.updatedAt)}` : `下次 ${displayTime(item.nextRunAt)}`),
        h('span', null, h(Send, { 'aria-hidden': 'true' }), `${item.config.targets.length} 个目标`))),
    h('div', { className: 'dcj-actions' },
      deleteConfirm ? [
        h('button', { key: 'cancel-delete', type: 'button', className: 'dcj-secondary', onClick: () => onDeleteConfirm(null) }, '取消'),
        h('button', { key: 'confirm-delete', type: 'button', className: 'dcj-danger', onClick: () => onAction('delete', item) }, h(Trash2, { 'aria-hidden': 'true' }), '确认删除'),
      ] : [
        h('button', { key: 'edit', type: 'button', className: 'dcj-iconButton', 'aria-label': `编辑 ${item.config.name}`, title: '编辑', onClick: () => onOpen(item) }, h(Pencil, { 'aria-hidden': 'true' })),
        !isDraft && running ? h('button', { key: 'cancel', type: 'button', className: 'dcj-iconButton', 'aria-label': `取消运行 ${item.config.name}`, title: '取消运行', disabled: Boolean(actionBusy), onClick: () => onAction('cancel', item) }, h(Square, { 'aria-hidden': 'true' })) : null,
        !isDraft && !running ? h('button', { key: 'run', type: 'button', className: 'dcj-iconButton', 'aria-label': `立即运行 ${item.config.name}`, title: '立即运行', disabled: Boolean(actionBusy), onClick: () => onAction('run', item) }, h(Play, { 'aria-hidden': 'true' })) : null,
        !isDraft ? h('button', { key: 'state', type: 'button', className: 'dcj-iconButton', 'aria-label': `${item.state === 'active' ? '暂停' : '恢复'} ${item.config.name}`, title: item.state === 'active' ? '暂停' : '恢复', disabled: Boolean(actionBusy), onClick: () => onAction(item.state === 'active' ? 'pause' : 'resume', item) }, item.state === 'active' ? h(Pause, { 'aria-hidden': 'true' }) : h(RefreshCw, { 'aria-hidden': 'true' })) : null,
        h('button', { key: 'delete', type: 'button', className: 'dcj-iconButton', 'aria-label': `删除 ${item.config.name}`, title: '删除', disabled: running || Boolean(actionBusy), onClick: () => onDeleteConfirm(item.id) }, h(Trash2, { 'aria-hidden': 'true' })),
      ]),
  );
}

export function CronJobWorkbench({ cronRpcCall, onOpenAccounts, view = 'all' }) {
  const api = React.useMemo(() => createCronJobApi(cronRpcCall), [cronRpcCall]);
  const [snapshot, setSnapshot] = React.useState(null);
  const [catalog, setCatalog] = React.useState(null);
  const [query, setQuery] = React.useState('');
  const [status, setStatus] = React.useState('all');
  const [page, setPage] = React.useState(1);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState('');
  const [selected, setSelected] = React.useState(null);
  const [actionBusy, setActionBusy] = React.useState('');
  const [deleteConfirm, setDeleteConfirm] = React.useState(null);
  const mounted = useMounted();

  const load = React.useCallback(async ({ quiet = false } = {}) => {
    if (!quiet) setLoading(true);
    try {
      const [nextSnapshot, nextCatalog] = await Promise.all([
        api.snapshot({ query, status, page, pageSize: PAGE_SIZE }),
        catalog ? Promise.resolve(catalog) : api.catalog(),
      ]);
      if (!mounted.current) return;
      setSnapshot(nextSnapshot);
      setCatalog(nextCatalog);
      setError('');
    } catch (cause) {
      if (mounted.current) setError(cause?.message ?? '无法读取定时任务。');
    } finally {
      if (mounted.current && !quiet) setLoading(false);
    }
  }, [api, catalog, mounted, page, query, status]);

  React.useEffect(() => { void load(); }, [load]);
  React.useEffect(() => {
    if (!snapshot || (snapshot.runningJobIds?.length ?? 0) === 0
      && Object.keys(snapshot.preflightProgress ?? {}).length === 0) return undefined;
    const timer = setInterval(() => { void load({ quiet: true }); }, 900);
    return () => clearInterval(timer);
  }, [load, snapshot]);

  const drafts = (snapshot?.drafts ?? []).filter((draft) => {
    const needle = query.trim().toLowerCase();
    const matchesQuery = !needle || `${draft.config.name}\n${draft.config.description}`.toLowerCase().includes(needle);
    const matchesStatus = status === 'all' || status === 'drafts'
      || status === draft.status;
    return matchesQuery && matchesStatus;
  });
  const jobs = ['drafts', 'draft', 'testing', 'ready', 'test_failed'].includes(status)
    ? [] : (snapshot?.jobs ?? []);
  const items = [...drafts, ...jobs];
  const totalPages = Math.max(1, Math.ceil((snapshot?.total ?? 0) / PAGE_SIZE));
  const showCreate = view === 'all' || view === 'create';
  const showJobs = view === 'all' || view === 'jobs';

  const action = async (kind, item) => {
    setActionBusy(`${kind}:${item.id}`);
    setError('');
    try {
      if (kind === 'run') {
        void api.run(item.id).then(() => load({ quiet: true })).catch((cause) => {
          if (mounted.current) setError(cause?.message ?? '任务运行失败。');
        });
        await new Promise((resolve) => setTimeout(resolve, 250));
      } else if (kind === 'pause') await api.pause(item.id);
      else if (kind === 'resume') await api.resume(item.id);
      else if (kind === 'cancel') await api.cancel(item.id);
      else if (kind === 'delete') { await api.delete(item.id); setDeleteConfirm(null); }
      await load({ quiet: true });
    } catch (cause) {
      setError(cause?.message ?? '任务操作失败。');
    } finally {
      setActionBusy('');
    }
  };

  return h('main', { id: 'dcj-main', className: `dcj-main dcj-main-${view}`, tabIndex: -1 },
    showCreate
      ? h(NaturalDraftForm, {
          api,
          catalog,
          onCreated: (draft) => { setSelected(draft); void load({ quiet: true }); },
          onOpenAccounts,
        })
      : null,
    showJobs ? h('div', { className: 'dcj-jobsView' },
    h('div', { className: 'dcj-viewIntro' },
      h('div', { className: 'dcj-viewIcon', 'aria-hidden': 'true' }, h(History)),
      h('div', null,
        h('h3', null, '已有任务'),
        h('p', null, '查看状态、下次执行时间和最近运行结果。'))),
    h('div', { className: 'dcj-toolbar' },
      h('div', { className: 'dcj-searchWrap' },
        h(Search, { 'aria-hidden': 'true' }),
        h('input', {
          className: 'dcj-search', type: 'search', value: query,
          'aria-label': '搜索定时任务', placeholder: '搜索任务名称或描述',
          onChange: (event) => { setQuery(event.target.value); setPage(1); },
        })),
      h(AccessibleListbox, {
        id: 'dcj-status', label: '状态筛选', value: status,
        options: [
          { value: 'all', label: '全部状态' },
          { value: 'active', label: '已启用' },
          { value: 'paused', label: '已暂停' },
          { value: 'drafts', label: '草稿与待确认' },
        ],
        onChange: (value) => { setStatus(value); setPage(1); },
      }),
      h('button', { type: 'button', className: 'dcj-iconButton', 'aria-label': '刷新任务列表', title: '刷新', onClick: () => load() }, h(RefreshCw, { 'aria-hidden': 'true' }))),
    error ? h('p', { className: 'dcj-error', role: 'alert' }, error) : null,
    loading ? h('div', { className: 'dcj-loading' }, h(LoaderCircle, { 'aria-hidden': 'true' }), h('p', null, '正在读取定时任务'))
      : items.length === 0 ? h('div', { className: 'dcj-empty' }, h(CalendarClock, { 'aria-hidden': 'true' }), h('p', null, query ? '没有符合条件的任务。' : '还没有定时任务，从上方描述一个任务开始。'))
        : h('div', { className: 'dcj-list' }, items.map((item) => h(JobRow, {
            key: item.id,
            item,
            running: snapshot.runningJobIds?.includes(item.id),
            onOpen: setSelected,
            onAction: action,
            actionBusy: actionBusy.endsWith(item.id),
            deleteConfirm: deleteConfirm === item.id,
            onDeleteConfirm: setDeleteConfirm,
          }))),
    h('div', { className: 'dcj-pagination' },
      h('span', null, `第 ${page} / ${totalPages} 页 · ${snapshot?.total ?? 0} 个正式任务`),
      h('button', { type: 'button', className: 'dcj-iconButton', 'aria-label': '上一页', disabled: page <= 1, onClick: () => setPage((value) => Math.max(1, value - 1)) }, h(ChevronLeft, { 'aria-hidden': 'true' })),
      h('button', { type: 'button', className: 'dcj-iconButton', 'aria-label': '下一页', disabled: page >= totalPages, onClick: () => setPage((value) => Math.min(totalPages, value + 1)) }, h(ChevronRight, { 'aria-hidden': 'true' }))),
    ) : null,
    selected ? h(TaskEditor, {
      item: selected,
      catalog,
      api,
      progress: snapshot?.preflightProgress?.[selected.id],
      onClose: () => setSelected(null),
      onChanged: (next) => { setSelected(next.state ? null : next); void load({ quiet: true }); },
      onOpenAccounts: (channel) => { setSelected(null); onOpenAccounts(channel); },
    }) : null,
    h('div', { className: 'dcj-live', 'aria-live': 'polite' }, actionBusy ? '正在执行任务操作' : ''),
  );
}

export function CronJobSettings({ cronRpcCall, children, onOpenAccounts }) {
  return h(CronJobWorkbench, { cronRpcCall, onOpenAccounts }, children);
}
