export const CRON_JOB_RPC_CHANNEL = '/cron-job';

export const CRON_JOB_ENDPOINTS = Object.freeze({
  snapshot: 'snapshot',
  catalog: 'catalog',
  get: 'job.get',
  draft: 'draft.create',
  draftNatural: 'draft.from-natural-language',
  updateDraft: 'draft.update',
  test: 'draft.test',
  confirm: 'draft.confirm',
  update: 'job.update',
  pause: 'job.pause',
  resume: 'job.resume',
  run: 'job.run',
  cancel: 'job.cancel',
  delete: 'job.delete',
  runs: 'job.runs',
});

export function unwrapCronResult(result) {
  if (!result || typeof result !== 'object' || typeof result.ok !== 'boolean') {
    const error = new Error('定时任务服务返回了无法识别的响应');
    error.code = 'invalid-response';
    throw error;
  }
  if (!result.ok) {
    const error = new Error(result.error?.message || '定时任务操作失败');
    error.code = result.error?.code || 'cron-job-operation-failed';
    throw error;
  }
  return result.value;
}

export function createCronJobApi(rpcCall) {
  if (typeof rpcCall !== 'function') throw new TypeError('cronRpcCall must be a function');
  const call = async (endpoint, payload = {}, signal) => unwrapCronResult(
    await rpcCall(endpoint, payload, signal),
  );
  return Object.freeze({
    snapshot: (query, signal) => call(CRON_JOB_ENDPOINTS.snapshot, query, signal),
    catalog: (signal) => call(CRON_JOB_ENDPOINTS.catalog, {}, signal),
    get: (id, signal) => call(CRON_JOB_ENDPOINTS.get, { id }, signal),
    draftNatural: (description, defaults, signal) => call(
      CRON_JOB_ENDPOINTS.draftNatural,
      { description, defaults },
      signal,
    ),
    updateDraft: (id, changes, signal) => call(
      CRON_JOB_ENDPOINTS.updateDraft,
      { id, changes },
      signal,
    ),
    test: (id, signal) => call(CRON_JOB_ENDPOINTS.test, { id }, signal),
    confirm: (id, signal) => call(CRON_JOB_ENDPOINTS.confirm, { id }, signal),
    update: (id, changes, signal) => call(CRON_JOB_ENDPOINTS.update, { id, changes }, signal),
    pause: (id, signal) => call(CRON_JOB_ENDPOINTS.pause, { id }, signal),
    resume: (id, signal) => call(CRON_JOB_ENDPOINTS.resume, { id }, signal),
    run: (id, signal) => call(CRON_JOB_ENDPOINTS.run, { id }, signal),
    cancel: (id, signal) => call(CRON_JOB_ENDPOINTS.cancel, { id }, signal),
    delete: (id, signal) => call(CRON_JOB_ENDPOINTS.delete, { id, confirm: true }, signal),
    runs: (id, options, signal) => call(CRON_JOB_ENDPOINTS.runs, { id, ...options }, signal),
  });
}
