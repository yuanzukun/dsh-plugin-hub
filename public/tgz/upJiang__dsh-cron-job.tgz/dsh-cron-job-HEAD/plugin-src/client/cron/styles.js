export const CRON_STYLE_ID = 'dsh-cron-job-workbench';

const CSS = String.raw`
.dcj-root { --dcj-blue: var(--dsw-alias-state-business-primary, #3370ff); --dcj-blue-soft: color-mix(in srgb, var(--dcj-blue) 8%, transparent); --dcj-border: var(--dsw-alias-border-l2, #dfe1e5); width: 100%; max-width: 1180px; color: var(--dsw-alias-label-primary, #1f2329); }
.dcj-root, .dcj-root *, .dcj-root *::before, .dcj-root *::after { box-sizing: border-box; letter-spacing: 0; }
.dcj-root button, .dcj-root input, .dcj-root textarea { font: inherit; }
.dcj-root button { touch-action: manipulation; }
.dcj-skip { position: absolute; left: 12px; top: -100px; z-index: 100; padding: 8px 12px; border-radius: 6px; color: #fff; background: var(--dcj-blue); }
.dcj-skip:focus { top: 12px; }
.dcj-topbar { min-width: 0; display: flex; align-items: center; justify-content: space-between; gap: 16px; margin-bottom: 18px; }
.dcj-heading { min-width: 0; }
.dcj-heading h2 { margin: 0; font-size: 20px; line-height: 28px; font-weight: 680; }
.dcj-heading p { margin: 2px 0 0; color: var(--dsw-alias-label-secondary, #646a73); font-size: 13px; line-height: 20px; }
.dcj-modeTabs { flex: none; display: inline-grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 2px; padding: 3px; border: 1px solid var(--dcj-border); border-radius: 8px; background: var(--dsw-alias-bg-module-platform, #f5f6f7); }
.dcj-modeTabs button { min-height: 36px; padding: 0 14px; border: 0; border-radius: 6px; color: var(--dsw-alias-label-secondary, #646a73); background: transparent; cursor: pointer; }
.dcj-modeTabs button[aria-selected="true"] { color: var(--dsw-alias-label-primary, #1f2329); background: var(--dsw-alias-bg-layer-1, #fff); box-shadow: 0 1px 3px rgb(31 35 41 / 9%); }
.dcj-modeTabs button:focus-visible, .dcj-root button:focus-visible, .dcj-root input:focus-visible, .dcj-root textarea:focus-visible { outline: 2px solid color-mix(in srgb, var(--dcj-blue) 70%, white); outline-offset: 2px; }
.dcj-create { margin-bottom: 20px; padding: 16px; border: 1px solid var(--dcj-border); border-radius: 8px; background: var(--dsw-alias-bg-layer-1, #fff); }
.dcj-createHeader { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 12px; }
.dcj-createHeader h3 { margin: 0; font-size: 15px; line-height: 22px; font-weight: 650; }
.dcj-createHeader span { color: var(--dsw-alias-label-tertiary, #8f959e); font-size: 12px; }
.dcj-createHeaderActions { min-width: 0; display: flex; align-items: center; justify-content: flex-end; gap: 10px; }
.dcj-exampleButton { min-height: 36px; flex: none; }
.dcj-promptRow { min-width: 0; display: grid; grid-template-columns: minmax(0, 1fr) max-content; align-items: end; gap: 10px; }
.dcj-field { min-width: 0; display: grid; gap: 6px; }
.dcj-field > label, .dcj-fieldLabel { color: var(--dsw-alias-label-secondary, #646a73); font-size: 12px; line-height: 18px; font-weight: 560; }
.dcj-input, .dcj-textarea, .dcj-search { width: 100%; min-width: 0; border: 1px solid var(--dcj-border); border-radius: 7px; color: var(--dsw-alias-label-primary, #1f2329); background: var(--dsw-alias-bg-layer-1, #fff); }
.dcj-input, .dcj-search { min-height: 40px; padding: 0 11px; }
.dcj-textarea { min-height: 96px; resize: vertical; padding: 9px 11px; line-height: 1.55; }
.dcj-input:hover, .dcj-textarea:hover, .dcj-search:hover { border-color: var(--dsw-alias-border-l3, #bbbfc4); }
.dcj-input[aria-invalid="true"], .dcj-textarea[aria-invalid="true"] { border-color: var(--dsw-alias-state-error-primary, #d54941); }
.dcj-help { margin: 0; color: var(--dsw-alias-label-tertiary, #8f959e); font-size: 11px; line-height: 17px; }
.dcj-error { margin: 0; color: var(--dsw-alias-state-error-primary, #d54941); font-size: 12px; line-height: 18px; overflow-wrap: anywhere; }
.dcj-primary, .dcj-secondary, .dcj-danger, .dcj-iconButton { min-height: 40px; display: inline-flex; align-items: center; justify-content: center; gap: 7px; padding: 0 13px; border: 1px solid var(--dcj-border); border-radius: 7px; color: var(--dsw-alias-label-primary, #1f2329); background: var(--dsw-alias-bg-layer-1, #fff); font-size: 13px; font-weight: 560; cursor: pointer; transition: background .15s ease, border-color .15s ease, opacity .15s ease; }
.dcj-primary { border-color: var(--dcj-blue); color: #fff; background: var(--dcj-blue); }
.dcj-primary:hover:not(:disabled) { filter: brightness(.96); }
.dcj-secondary:hover:not(:disabled), .dcj-iconButton:hover:not(:disabled) { border-color: var(--dsw-alias-border-l3, #bbbfc4); background: var(--dsw-alias-interactive-bg-hover, #f7f8fa); }
.dcj-danger { color: var(--dsw-alias-state-error-primary, #d54941); }
.dcj-root button:disabled { cursor: not-allowed; opacity: .48; }
.dcj-iconButton { width: 40px; padding: 0; }
.dcj-iconButton svg, .dcj-primary svg, .dcj-secondary svg, .dcj-danger svg { width: 16px; height: 16px; flex: none; }
.dcj-toolbar { display: grid; grid-template-columns: minmax(220px, 1fr) 180px max-content; align-items: center; gap: 10px; margin-bottom: 12px; }
.dcj-searchWrap { position: relative; min-width: 0; }
.dcj-searchWrap svg { position: absolute; left: 11px; top: 50%; width: 16px; height: 16px; color: var(--dsw-alias-label-tertiary, #8f959e); transform: translateY(-50%); pointer-events: none; }
.dcj-search { padding-left: 35px; }
.dcj-list { display: grid; gap: 8px; }
.dcj-job { min-width: 0; display: grid; grid-template-columns: minmax(0, 1fr) max-content; align-items: center; gap: 16px; padding: 13px 14px; border: 1px solid var(--dcj-border); border-radius: 8px; background: var(--dsw-alias-bg-layer-1, #fff); }
.dcj-jobMain { min-width: 0; display: grid; gap: 6px; }
.dcj-jobTitle { min-width: 0; display: flex; align-items: center; flex-wrap: wrap; gap: 7px; }
.dcj-jobTitle button { min-width: 0; overflow: hidden; padding: 0; border: 0; color: inherit; background: transparent; font-weight: 650; text-align: left; text-overflow: ellipsis; white-space: nowrap; cursor: pointer; }
.dcj-jobMeta { display: flex; align-items: center; flex-wrap: wrap; gap: 5px 12px; color: var(--dsw-alias-label-secondary, #646a73); font-size: 12px; line-height: 18px; }
.dcj-jobMeta span { display: inline-flex; align-items: center; gap: 5px; }
.dcj-jobMeta svg { width: 14px; height: 14px; }
.dcj-badge { display: inline-flex; align-items: center; min-height: 22px; padding: 0 8px; border-radius: 999px; color: var(--dsw-alias-label-secondary, #646a73); background: var(--dsw-alias-bg-module-platform, #f2f3f5); font-size: 11px; line-height: 18px; }
.dcj-badge[data-tone="success"] { color: var(--dsw-alias-state-success-primary, #168f57); background: color-mix(in srgb, var(--dsw-alias-state-success-primary, #20a162) 10%, transparent); }
.dcj-badge[data-tone="warning"] { color: var(--dsw-alias-state-warn-primary, #b45f06); background: color-mix(in srgb, var(--dsw-alias-state-warn-primary, #d97706) 10%, transparent); }
.dcj-badge[data-tone="danger"] { color: var(--dsw-alias-state-error-primary, #c13c35); background: color-mix(in srgb, var(--dsw-alias-state-error-primary, #d54941) 9%, transparent); }
.dcj-actions { display: flex; align-items: center; gap: 6px; }
.dcj-actions button { min-height: 36px; }
.dcj-empty, .dcj-loading { min-height: 190px; display: grid; place-content: center; justify-items: center; gap: 9px; padding: 24px; border: 1px dashed var(--dcj-border); border-radius: 8px; color: var(--dsw-alias-label-secondary, #646a73); text-align: center; }
.dcj-empty svg, .dcj-loading svg { width: 26px; height: 26px; color: var(--dsw-alias-label-tertiary, #8f959e); }
.dcj-empty p, .dcj-loading p { margin: 0; font-size: 13px; line-height: 20px; }
.dcj-pagination { display: flex; align-items: center; justify-content: flex-end; gap: 9px; margin-top: 12px; color: var(--dsw-alias-label-secondary, #646a73); font-size: 12px; }
.dcj-pagination button { min-height: 36px; }
.dcj-select { position: relative; min-width: 0; }
.dcj-selectButton { width: 100%; min-height: 40px; display: grid; grid-template-columns: minmax(0, 1fr) 16px; align-items: center; gap: 8px; padding: 0 10px; border: 1px solid var(--dcj-border); border-radius: 7px; color: var(--dsw-alias-label-primary, #1f2329); background: var(--dsw-alias-bg-layer-1, #fff); text-align: left; cursor: pointer; }
.dcj-selectButton span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dcj-selectButton svg { width: 15px; height: 15px; transition: transform .15s ease; }
.dcj-selectButton[aria-expanded="true"] svg { transform: rotate(180deg); }
.dcj-options { position: absolute; left: 0; right: 0; top: calc(100% + 5px); z-index: 60; max-height: 240px; overflow-y: auto; margin: 0; padding: 5px; border: 1px solid var(--dcj-border); border-radius: 7px; background: var(--dsw-alias-bg-layer-3, #fff); box-shadow: 0 12px 32px rgb(31 35 41 / 16%); list-style: none; }
.dcj-option { min-height: 38px; display: grid; grid-template-columns: minmax(0, 1fr) 16px; align-items: center; gap: 8px; padding: 6px 8px; border-radius: 5px; cursor: pointer; }
.dcj-option[data-active="true"], .dcj-option:hover { background: var(--dsw-alias-interactive-bg-hover, #f5f6f7); }
.dcj-option[aria-selected="true"] { color: var(--dcj-blue); background: var(--dcj-blue-soft); }
.dcj-option svg { width: 15px; height: 15px; }
.dcj-drawerBackdrop { position: fixed; inset: 0; z-index: 900; display: grid; place-items: center; padding: 20px; background: rgb(15 17 21 / 46%); }
.dcj-drawer { width: min(920px, 100%); max-height: calc(100dvh - 40px); overflow-y: auto; border: 1px solid var(--dcj-border); border-radius: 8px; background: var(--dsw-alias-bg-layer-1, #fff); box-shadow: 0 24px 72px rgb(15 17 21 / 24%); }
.dcj-drawerHeader { position: sticky; top: 0; z-index: 2; display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 14px 18px; border-bottom: 1px solid var(--dsw-alias-border-l1, #eef0f3); background: var(--dsw-alias-bg-layer-1, #fff); }
.dcj-drawerHeader h3 { min-width: 0; overflow: hidden; margin: 0; font-size: 16px; line-height: 24px; font-weight: 650; text-overflow: ellipsis; white-space: nowrap; }
.dcj-drawerBody { display: grid; gap: 18px; padding: 18px; }
.dcj-formGrid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 13px; }
.dcj-span2 { grid-column: 1 / -1; }
.dcj-scheduleGrid { display: grid; grid-template-columns: 150px minmax(0, 1fr); gap: 10px; }
.dcj-checks { display: flex; flex-wrap: wrap; gap: 8px 18px; }
.dcj-check { min-height: 36px; display: inline-flex; align-items: center; gap: 8px; color: var(--dsw-alias-label-secondary, #646a73); font-size: 12px; cursor: pointer; }
.dcj-check input { width: 16px; height: 16px; accent-color: var(--dcj-blue); }
.dcj-targets { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; }
.dcj-target { min-width: 0; min-height: 52px; display: grid; grid-template-columns: 18px minmax(0, 1fr); align-items: center; gap: 9px; padding: 8px 10px; border: 1px solid var(--dcj-border); border-radius: 7px; cursor: pointer; }
.dcj-target:has(input:checked) { border-color: color-mix(in srgb, var(--dcj-blue) 48%, var(--dcj-border)); background: var(--dcj-blue-soft); }
.dcj-target input { width: 16px; height: 16px; accent-color: var(--dcj-blue); }
.dcj-targetCopy { min-width: 0; display: grid; }
.dcj-targetCopy span { overflow: hidden; font-size: 12px; line-height: 18px; font-weight: 560; text-overflow: ellipsis; white-space: nowrap; }
.dcj-targetCopy small { overflow: hidden; color: var(--dsw-alias-label-tertiary, #8f959e); font-size: 11px; line-height: 17px; text-overflow: ellipsis; white-space: nowrap; }
.dcj-drawerFooter { position: sticky; bottom: 0; z-index: 2; display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 18px; border-top: 1px solid var(--dsw-alias-border-l1, #eef0f3); background: var(--dsw-alias-bg-layer-1, #fff); }
.dcj-footerActions { display: flex; align-items: center; gap: 8px; }
.dcj-preflight { display: grid; gap: 8px; padding: 12px; border: 1px solid var(--dcj-border); border-radius: 7px; background: var(--dsw-alias-bg-module-platform, #f7f8fa); }
.dcj-preflight h4, .dcj-history h4 { margin: 0; font-size: 13px; line-height: 20px; font-weight: 650; }
.dcj-stageList { display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: 6px; }
.dcj-stage { min-width: 0; display: grid; justify-items: center; gap: 5px; padding: 8px 5px; border-radius: 6px; color: var(--dsw-alias-label-tertiary, #8f959e); background: var(--dsw-alias-bg-layer-1, #fff); font-size: 11px; text-align: center; }
.dcj-stage svg { width: 16px; height: 16px; }
.dcj-stage[data-status="passed"] { color: var(--dsw-alias-state-success-primary, #168f57); }
.dcj-stage[data-status="failed"] { color: var(--dsw-alias-state-error-primary, #c13c35); }
.dcj-stage[data-status="running"] svg { animation: dcj-spin .9s linear infinite; }
.dcj-failures { display: grid; gap: 6px; margin: 0; padding: 0; list-style: none; }
.dcj-failure { display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; padding: 9px 10px; border-radius: 6px; color: var(--dsw-alias-state-error-primary, #c13c35); background: color-mix(in srgb, var(--dsw-alias-state-error-primary, #d54941) 7%, transparent); font-size: 12px; line-height: 18px; }
.dcj-history { display: grid; gap: 8px; }
.dcj-historyItem { display: grid; gap: 7px; padding: 10px 12px; border: 1px solid var(--dcj-border); border-radius: 7px; }
.dcj-historyTop { display: flex; align-items: center; justify-content: space-between; gap: 10px; color: var(--dsw-alias-label-secondary, #646a73); font-size: 12px; }
.dcj-output { max-height: 220px; overflow: auto; margin: 0; padding: 10px; border-radius: 6px; color: var(--dsw-alias-label-primary, #1f2329); background: var(--dsw-alias-bg-module-platform, #f7f8fa); font: 12px/1.55 ui-monospace, SFMono-Regular, Consolas, monospace; white-space: pre-wrap; overflow-wrap: anywhere; }
.dcj-receipts { display: flex; flex-wrap: wrap; gap: 6px; }
.dcj-live { position: fixed; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); }
@keyframes dcj-spin { to { transform: rotate(360deg); } }
@media (max-width: 760px) {
  .dcj-topbar { align-items: flex-start; flex-direction: column; }
  .dcj-modeTabs { width: 100%; }
  .dcj-promptRow, .dcj-toolbar, .dcj-job, .dcj-formGrid, .dcj-scheduleGrid { grid-template-columns: minmax(0, 1fr); }
  .dcj-promptRow .dcj-primary { width: 100%; }
  .dcj-job { align-items: stretch; }
  .dcj-actions { justify-content: flex-end; flex-wrap: wrap; }
  .dcj-drawerBackdrop { align-items: end; padding: 0; }
  .dcj-drawer { width: 100%; max-height: 94dvh; border-radius: 8px 8px 0 0; }
  .dcj-targets { grid-template-columns: minmax(0, 1fr); }
  .dcj-stageList { grid-template-columns: repeat(3, minmax(0, 1fr)); }
  .dcj-drawerFooter { align-items: stretch; flex-direction: column; }
  .dcj-footerActions { width: 100%; }
  .dcj-footerActions button { flex: 1 1 0; }
}
@media (max-width: 420px) {
  .dcj-create { padding: 12px; }
  .dcj-createHeader { align-items: flex-start; flex-direction: column; }
  .dcj-createHeaderActions { width: 100%; align-items: flex-start; flex-direction: column; }
  .dcj-exampleButton { width: 100%; }
  .dcj-actions { justify-content: stretch; }
  .dcj-actions button { flex: 1 1 0; min-width: 44px; }
}

/* The workbench uses a playful, high-contrast surface while keeping the existing controls. */
.dcj-root {
  --dcj-orange: #f97316;
  --dcj-orange-soft: #fff1e6;
  --dcj-blue: #2563eb;
  --dcj-blue-soft: #eaf2ff;
  --dcj-mint: #34d399;
  --dcj-ink: #263449;
  --dcj-cream: #fffaf3;
  --dcj-border: #fed7aa;
  max-width: 1180px;
  padding: 26px 30px 32px;
  border: 2px solid var(--dcj-ink);
  border-radius: 24px 20px 26px 18px;
  background: var(--dcj-cream);
  box-shadow: 5px 6px 0 var(--dcj-ink);
  color: var(--dcj-ink);
  container: dcj-root / inline-size;
}
.dcj-topbar { align-items: end; gap: 24px; margin-bottom: 24px; }
.dcj-heading { min-width: 0; flex: 1 1 280px; display: grid; gap: 5px; }
.dcj-headingKicker { display: inline-flex; align-items: center; gap: 7px; color: var(--dcj-orange); font-size: 11px; line-height: 16px; font-weight: 800; letter-spacing: .06em; text-transform: uppercase; }
.dcj-headingSpark { width: 22px; height: 22px; display: grid; place-items: center; border: 2px solid var(--dcj-ink); border-radius: 8px 6px 9px 5px; color: var(--dcj-ink); background: var(--dcj-mint); transform: rotate(-6deg); }
.dcj-headingSpark svg { width: 14px; height: 14px; }
.dcj-brandStamp { color: var(--dcj-ink); }
.dcj-headingKickerLabel { color: var(--dcj-blue); }
.dcj-heading h2 { color: var(--dcj-ink); font-size: 28px; line-height: 1.18; font-weight: 850; }
.dcj-heading p { max-width: 540px; margin: 0; color: #526078; font-size: 13px; line-height: 20px; }
.dcj-modeTabs { width: min(100%, 550px); display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 7px; padding: 7px; border: 2px solid var(--dcj-ink); border-radius: 17px 14px 16px 13px; background: #fff; box-shadow: 3px 4px 0 var(--dcj-ink); }
.dcj-modeTabs button { min-width: 0; min-height: 70px; display: grid; grid-template-rows: 25px minmax(0, auto); justify-items: center; gap: 3px; padding: 8px 6px; border: 2px solid transparent; border-radius: 11px 9px 12px 8px; color: #64748b; background: transparent; font-weight: 700; cursor: pointer; transition: transform .16s ease, background .16s ease, color .16s ease, border-color .16s ease; }
.dcj-modeTabs button:hover:not([aria-selected="true"]) { color: var(--dcj-blue); background: var(--dcj-blue-soft); transform: translateY(-2px) rotate(-1deg); }
.dcj-modeTabs button[aria-selected="true"] { border-color: var(--dcj-ink); color: #fff; background: var(--dcj-orange); box-shadow: 2px 3px 0 var(--dcj-ink); transform: translateY(-2px) rotate(1deg); }
.dcj-modeIcon { width: 25px; height: 25px; display: grid; place-items: center; }
.dcj-modeIcon svg { width: 22px; height: 22px; }
.dcj-modeCopy { min-width: 0; display: grid; justify-items: center; }
.dcj-modeLabel { overflow: hidden; max-width: 100%; font-size: 12px; line-height: 17px; text-overflow: ellipsis; white-space: nowrap; }
.dcj-modeCopy small { overflow: hidden; max-width: 100%; color: currentColor; font-size: 9px; line-height: 13px; font-weight: 600; opacity: .78; text-overflow: ellipsis; white-space: nowrap; }
.dcj-create { margin-bottom: 18px; padding: 20px; border: 2px solid var(--dcj-ink); border-radius: 17px 14px 18px 13px; background: #fff; box-shadow: 3px 4px 0 var(--dcj-blue); }
.dcj-createHeader { display: grid; grid-template-columns: minmax(0, 1fr) max-content; align-items: start; gap: 16px; margin-bottom: 20px; }
.dcj-createHeaderCopy { min-width: 0; display: grid; gap: 5px; }
.dcj-createHeader h3 { color: var(--dcj-ink); font-size: 16px; line-height: 22px; font-weight: 800; }
.dcj-createNote { margin: 0; color: #64748b; font-size: 12px; line-height: 18px; }
.dcj-createHeaderActions { min-width: 0; display: flex; align-items: flex-start; justify-content: flex-end; gap: 10px; }
.dcj-primary, .dcj-secondary, .dcj-danger, .dcj-iconButton { border: 2px solid var(--dcj-ink); border-radius: 10px 8px 11px 7px; color: var(--dcj-ink); background: #fff; font-weight: 700; box-shadow: 2px 2px 0 transparent; transition: transform .15s ease, box-shadow .15s ease, background .15s ease, opacity .15s ease; }
.dcj-primary:hover:not(:disabled), .dcj-secondary:hover:not(:disabled), .dcj-iconButton:hover:not(:disabled), .dcj-danger:hover:not(:disabled) { border-color: var(--dcj-ink); box-shadow: 2px 3px 0 var(--dcj-ink); transform: translateY(-1px); }
.dcj-primary { border-color: var(--dcj-ink); color: #fff; background: var(--dcj-orange); }
.dcj-secondary:hover:not(:disabled), .dcj-iconButton:hover:not(:disabled) { background: var(--dcj-blue-soft); }
.dcj-danger { color: #c2410c; background: #fff7ed; }
.dcj-create .dcj-primary, .dcj-create .dcj-secondary { min-height: 36px; padding: 0 11px; gap: 6px; font-size: 12px; }
.dcj-promptRow { grid-template-columns: minmax(0, 1fr); align-items: stretch; gap: 12px; }
.dcj-create .dcj-textarea { min-height: 112px; }
.dcj-promptRow .dcj-primary { justify-self: end; }
.dcj-createConfigToggle { margin-top: 22px; }
.dcj-createConfig { margin-top: 16px; padding-top: 18px; border-top: 2px dashed #fed7aa; gap: 18px 14px; }
.dcj-createConfig .dcj-targetField { display: grid; gap: 12px; }
.dcj-createConfig .dcj-accountButton { margin-top: 0; justify-self: start; }
.dcj-create > .dcj-error { margin-top: 12px; }
.dcj-input, .dcj-textarea, .dcj-search { border: 2px solid #cbd5e1; border-radius: 9px 7px 10px 6px; color: var(--dcj-ink); background: #fff; }
.dcj-input:hover, .dcj-textarea:hover, .dcj-search:hover, .dcj-input:focus, .dcj-textarea:focus, .dcj-search:focus { border-color: var(--dcj-blue); }
.dcj-field > label, .dcj-fieldLabel { color: #526078; font-weight: 700; }
.dcj-help { color: #718096; }
.dcj-viewIntro { display: flex; align-items: center; gap: 12px; margin: 4px 0 18px; }
.dcj-viewIntro h3 { margin: 0; color: var(--dcj-ink); font-size: 20px; line-height: 27px; font-weight: 850; }
.dcj-viewIntro p { margin: 2px 0 0; color: #64748b; font-size: 12px; line-height: 18px; }
.dcj-viewIcon { width: 44px; height: 44px; display: grid; place-items: center; flex: none; border: 2px solid var(--dcj-ink); border-radius: 13px 10px 14px 9px; color: var(--dcj-ink); background: var(--dcj-mint); box-shadow: 2px 3px 0 var(--dcj-ink); transform: rotate(-4deg); }
.dcj-viewIcon svg { width: 23px; height: 23px; }
.dcj-toolbar { margin-bottom: 14px; }
.dcj-job { padding: 15px 16px; border: 2px solid #cbd5e1; border-radius: 13px 10px 14px 9px; background: #fff; box-shadow: 2px 3px 0 #bfdbfe; }
.dcj-job:hover { border-color: var(--dcj-blue); transform: translateY(-1px); }
.dcj-jobTitle button { font-weight: 800; }
.dcj-badge { border: 1px solid currentColor; border-radius: 8px 6px 9px 5px; font-weight: 700; }
.dcj-empty, .dcj-loading { border: 2px dashed #cbd5e1; border-radius: 14px 11px 15px 10px; background: #fff; }
.dcj-selectButton { border: 2px solid #cbd5e1; border-radius: 9px 7px 10px 6px; }
.dcj-options { border: 2px solid var(--dcj-ink); border-radius: 11px 8px 12px 7px; box-shadow: 3px 4px 0 var(--dcj-ink); }
.dcj-option { border-radius: 7px 5px 8px 4px; }
.dcj-drawer { border: 2px solid var(--dcj-ink); border-radius: 18px 14px 19px 13px; box-shadow: 6px 7px 0 var(--dcj-ink); }
.dcj-drawerHeader, .dcj-drawerFooter { border-color: #fed7aa; background: #fffaf3; }
.dcj-preflight { border: 2px solid #bfdbfe; border-radius: 13px 10px 14px 9px; background: var(--dcj-blue-soft); }
.dcj-stage { border: 1px solid #bfdbfe; border-radius: 8px 6px 9px 5px; }
.dcj-historyItem { border: 2px solid #cbd5e1; border-radius: 11px 8px 12px 7px; }

/* The account view inherits the same playful frame without changing channel behavior. */
.dcj-root > [role="tabpanel"] > .dim-page { max-width: none; padding: 0 0 4px; }
.dcj-root > [role="tabpanel"] > .dim-page .dim-layout { grid-template-columns: 160px 2px minmax(0, 1fr); gap: 18px; }
.dcj-root > [role="tabpanel"] > .dim-page .dim-channel { border: 2px solid #cbd5e1; border-radius: 13px 10px 14px 9px; box-shadow: 2px 3px 0 #bfdbfe; }
.dcj-root > [role="tabpanel"] > .dim-page .dim-channel[aria-selected="true"] { border-color: var(--dcj-ink); color: var(--dcj-ink); background: var(--dcj-orange-soft); box-shadow: 2px 3px 0 var(--dcj-orange); }
.dcj-root > [role="tabpanel"] > .dim-page .dim-divider { min-height: 520px; width: 2px; background: #fed7aa; }
.dcj-root > [role="tabpanel"] > .dim-page .dim-surfaceCard { border: 2px solid #cbd5e1; border-radius: 14px 11px 15px 10px; box-shadow: 3px 4px 0 #bfdbfe; }

@container dcj-root (max-width: 760px) {
  .dcj-topbar { align-items: stretch; flex-direction: column; }
  .dcj-heading { width: 100%; flex: none; }
  .dcj-modeTabs { width: 100%; }
}

@container dcj-root (max-width: 680px) {
  .dcj-createHeader { grid-template-columns: minmax(0, 1fr); gap: 10px; }
  .dcj-createHeaderActions { justify-content: flex-start; }
  .dcj-createConfig { grid-template-columns: minmax(0, 1fr); }
  .dcj-createConfig .dcj-span2 { grid-column: auto; }
}

@container dcj-root (max-width: 420px) {
  .dcj-createConfig .dcj-targets { grid-template-columns: minmax(0, 1fr); }
}

@container dcj-root (max-width: 360px) {
  .dcj-root { padding: 12px 8px 16px; border-width: 1px; border-radius: 14px; box-shadow: 3px 4px 0 var(--dcj-ink); }
  .dcj-heading h2 { font-size: 20px; }
  .dcj-heading p { font-size: 11px; line-height: 16px; }
  .dcj-modeTabs { grid-template-columns: minmax(0, 1fr); gap: 4px; padding: 4px; border-width: 1px; border-radius: 11px; box-shadow: 2px 3px 0 var(--dcj-ink); }
  .dcj-modeTabs button { min-height: 48px; grid-template-columns: 24px minmax(0, 1fr); grid-template-rows: minmax(0, 1fr); justify-items: start; gap: 7px; padding: 6px 8px; border-width: 1px; border-radius: 8px; text-align: left; }
  .dcj-modeCopy { justify-items: start; align-content: center; }
  .dcj-modeLabel { overflow: visible; white-space: normal; }
  .dcj-modeCopy small { overflow: visible; white-space: normal; }
  .dcj-viewIntro { align-items: flex-start; }
  .dcj-viewIntro h3 { font-size: 17px; }
  .dcj-create { padding: 12px; }
  .dcj-root > [role="tabpanel"] > .dim-page .dim-rail { grid-template-columns: minmax(0, 1fr); }
  .dcj-root > [role="tabpanel"] > .dim-page .dim-channel { grid-template-columns: 24px minmax(0, 1fr); }
  .dcj-root > [role="tabpanel"] > .dim-page .dim-channelLabel { font-size: 12px; }
  .dcj-root > [role="tabpanel"] > .dim-page .dim-channelNote { display: none; }
}

@media (max-width: 760px) {
  .dcj-root { padding: 20px 16px 24px; border-radius: 19px 16px 21px 14px; box-shadow: 4px 5px 0 var(--dcj-ink); }
  .dcj-topbar { gap: 18px; }
  .dcj-modeTabs { width: 100%; }
  .dcj-promptRow .dcj-primary { width: auto; min-height: 44px; justify-self: end; }
  .dcj-create .dcj-primary, .dcj-create .dcj-secondary { min-height: 44px; }
  .dcj-create .dcj-input, .dcj-create .dcj-selectButton { min-height: 44px; }
  .dcj-root > [role="tabpanel"] > .dim-page .dim-layout { grid-template-columns: minmax(0, 1fr); }
  .dcj-root > [role="tabpanel"] > .dim-page .dim-divider { display: none; }
  .dcj-root > [role="tabpanel"] > .dim-page .dim-rail { max-height: none; grid-template-columns: repeat(3, minmax(0, 1fr)); overflow: visible; }
  .dcj-root > [role="tabpanel"] > .dim-page .dim-channel { grid-template-columns: 24px minmax(0, 1fr); padding: 7px 8px; }
}
@media (max-width: 420px) {
  .dcj-root { padding: 16px 12px 20px; }
  .dcj-modeTabs { gap: 4px; padding: 5px; }
  .dcj-modeTabs button { min-height: 63px; padding: 6px 3px; }
  .dcj-modeCopy small { display: none; }
  .dcj-modeLabel { font-size: 11px; }
  .dcj-create { padding: 15px; }
  .dcj-createHeaderActions { width: auto; align-items: flex-start; flex-direction: row; }
  .dcj-exampleButton { width: auto; }
  .dcj-root > [role="tabpanel"] > .dim-page .dim-rail { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@container dcj-root (max-width: 360px) {
  .dcj-root > [role="tabpanel"] > .dim-page .dim-rail { grid-template-columns: minmax(0, 1fr); }
}
@media (prefers-reduced-motion: reduce) {
  .dcj-root *, .dcj-root *::before, .dcj-root *::after { scroll-behavior: auto !important; transition-duration: .01ms !important; animation-duration: .01ms !important; animation-iteration-count: 1 !important; }
}
`;

export function installCronStyles() {
  if (typeof document === 'undefined') return () => {};
  const existing = document.querySelector(`style[data-plugin-css="${CRON_STYLE_ID}"]`);
  if (existing) return () => {};
  const style = document.createElement('style');
  style.dataset.plugin = 'dsh-cron-job';
  style.dataset.pluginCss = CRON_STYLE_ID;
  style.textContent = CSS;
  document.head.appendChild(style);
  return () => style.remove();
}
