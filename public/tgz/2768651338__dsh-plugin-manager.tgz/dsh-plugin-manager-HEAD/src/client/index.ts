/**
 * 插件管家浏览器半：挂载 dshPluginManager 远程命名空间，并向“设置→插件”注册标签页。
 *
 * 关键点：
 * - 不在 dsh.client.inject 里声明 'remote.dshPluginManager'（挂载发生在 apply 内，
 *   注入会导致自身 fiber 永久 pending）——先 $mount 再通过 ctx.remote.dshPluginManager 访问。
 * - $mount 与标签页注册都在 apply 里完成；远程调用在注入面里解包 RemoteResult。
 * @module dsh-plugin-manager/client
 */

import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-api-remotes/client'
import type { RemoteResult, TypertRemoteNamespaceMap } from '@deepseek-ai/dsh-typert-protocol'
import type { BackupExportResult, BackupImportResult, BackupPreviewResult, CatalogEditResult, CatalogRepairResult, PluginManagerSnapshot, SetEnabledResult } from '../types.ts'
import { PluginManagerTab, type PluginManagerTabInjected } from './PluginManagerTab.tsx'
import { en, zh } from './locales.ts'
import { TYPERT_REMOTE } from './remote.ts'

export type { PluginManagerTabInjected, PluginManagerTabProps } from './PluginManagerTab.tsx'

/** 本插件拥有的文案命名空间（带插件前缀，避免与其他作者的管理器插件撞车）。 */
export const NS = 'settings.dshPluginManager'

/** 所需服务（cordis 注入）。 */
export const inject = ['slots', 'locale', 'remote']

/** 挂载远程命名空间并注册设置标签页。 */
export async function apply(ctx: ClientContext): Promise<void> {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-plugin-manager: dictionaries')

  // 1) 挂载 dshPluginManager 命名空间（返回 disposer，随插件卸载自动清理）。
  await ctx.effect(async () => {
    const dispose = await ctx.remote.$mount(TYPERT_REMOTE)
    return dispose
  }, 'dsh-plugin-manager: remote mount')

  const t = ctx.locale.bind(NS)

  // 当前界面语言（评估 P2-9）：快照里的目录内容是双语的，由界面按语言取用。
  // 非 zh 一律按英文渲染（与宿主 FALLBACK_LOCALE=en 的兜底方向一致）。
  const localeLang = (): 'zh' | 'en' => (ctx.locale.getLocale().active.startsWith('zh') ? 'zh' : 'en')

  // 2) 注入面：解包 RemoteResult，抛错给界面层处理。
  // 不能把 remote.dshPluginManager 写进 inject（挂载发生在 apply 内，注入会让自身 fiber 永久 pending），
  // 也不能做 ctx.remote.dshPluginManager 属性访问（cordis 要求注入）；
  // 用免注入通道 ctx.get() 在挂载完成后取命名空间服务。
  type PluginManagerRemote = TypertRemoteNamespaceMap['dshPluginManager']
  const namespace = (): PluginManagerRemote => ctx.get('remote.dshPluginManager') as PluginManagerRemote

  const list: PluginManagerTabInjected['list'] = async () => {
    const result: RemoteResult<PluginManagerSnapshot> = await namespace().list()
    if (!result.ok) {
      throw new Error(`dshPluginManager.list failed: ${result.error.code}: ${result.error.message}`)
    }
    return result.value
  }
  const setEnabled: PluginManagerTabInjected['setEnabled'] = async (entryId, enabled) => {
    const result: RemoteResult<SetEnabledResult> = await namespace().setEnabled(entryId, enabled)
    if (!result.ok) {
      throw new Error(`dshPluginManager.setEnabled failed: ${result.error.code}: ${result.error.message}`)
    }
    return result.value
  }
  const setOverride: PluginManagerTabInjected['setOverride'] = async (moduleName, name, desc) => {
    const result: RemoteResult<CatalogEditResult> = await namespace().setOverride(moduleName, name, desc)
    if (!result.ok) {
      throw new Error(`dshPluginManager.setOverride failed: ${result.error.code}: ${result.error.message}`)
    }
    return result.value
  }
  const removeOverride: PluginManagerTabInjected['removeOverride'] = async (moduleName) => {
    const result: RemoteResult<CatalogEditResult> = await namespace().removeOverride(moduleName)
    if (!result.ok) {
      throw new Error(`dshPluginManager.removeOverride failed: ${result.error.code}: ${result.error.message}`)
    }
    return result.value
  }
  const exportBackup: PluginManagerTabInjected['exportBackup'] = async () => {
    const result: RemoteResult<BackupExportResult> = await namespace().exportBackup()
    if (!result.ok) {
      throw new Error(`dshPluginManager.exportBackup failed: ${result.error.code}: ${result.error.message}`)
    }
    return result.value
  }
  const importBackup: PluginManagerTabInjected['importBackup'] = async (json, allowNonRegistrySpecs) => {
    const result: RemoteResult<BackupImportResult> = await namespace().importBackup(json, allowNonRegistrySpecs)
    if (!result.ok) {
      throw new Error(`dshPluginManager.importBackup failed: ${result.error.code}: ${result.error.message}`)
    }
    return result.value
  }
  const previewBackup: PluginManagerTabInjected['previewBackup'] = async (json) => {
    const result: RemoteResult<BackupPreviewResult> = await namespace().previewBackup(json)
    if (!result.ok) {
      throw new Error(`dshPluginManager.previewBackup failed: ${result.error.code}: ${result.error.message}`)
    }
    return result.value
  }
  const quarantineOverrides: PluginManagerTabInjected['quarantineOverrides'] = async () => {
    const result: RemoteResult<CatalogRepairResult> = await namespace().quarantineOverrides()
    if (!result.ok) {
      throw new Error(`dshPluginManager.quarantineOverrides failed: ${result.error.code}: ${result.error.message}`)
    }
    return result.value
  }
  const injected = (): PluginManagerTabInjected => ({ list, setEnabled, setOverride, removeOverride, exportBackup, importBackup, previewBackup, quarantineOverrides, localeLang })

  // 3) 注册标签页（排在“插件列表”之后）。
  ctx.slots.inject('settings.plugins.tab', () => ctx.slots.register({
    name: 'settings.plugins.tab',
    id: 'manager',
    order: 20,
    label: () => t('tab'),
    locale: NS,
    inject: injected,
  }, PluginManagerTab))
}