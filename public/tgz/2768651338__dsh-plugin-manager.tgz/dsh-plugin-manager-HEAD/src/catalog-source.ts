/**
 * Community catalog sources: explicit JSON documents, read by the host half.
 * A bad source degrades to a warning plus the built-in catalog; it never blocks
 * the plugin list or executes anything from the source.
 * @module dsh-plugin-manager/catalog-source
 */

import type { CatalogEntry, PluginCategory } from './catalog.ts'

/** A user-declared source. Later specs override earlier ones field by field. */
export interface CatalogSourceSpec {
  /** Stable display/debug id; derived from path/url when omitted. */
  readonly id?: string
  /** Absolute or config-relative JSON file path. */
  readonly path?: string
  /** HTTPS JSON document URL. */
  readonly url?: string
}

/** Normalized entry produced by either source format. */
export interface CatalogSourceEntry {
  readonly name?: string
  readonly nameEn?: string
  readonly desc?: string
  readonly descEn?: string
  readonly category?: PluginCategory
}

/** Result of loading all configured sources. */
export interface CatalogSourceResult {
  /** Module name or alias -> highest-priority entry. */
  readonly entries: Readonly<Record<string, CatalogSourceEntry>>
  /** Human-readable per-source failures; empty when all sources load. */
  readonly warnings: readonly string[]
}

/** Source JSON is display metadata only; keep it well below an import-sized payload. */
export const MAX_SOURCE_CHARS = 2 * 1024 * 1024

export const SOURCE_CONFIG_FORMAT = 'dsh-plugin-manager-catalog-sources'
export const SOURCE_DOCUMENT_FORMAT = 'dsh-plugin-manager-catalog-source'

const VALID_CATEGORIES: ReadonlySet<string> = new Set([
  'core', 'llm', 'session', 'agent', 'tool', 'skill',
  'ui', 'web', 'sandbox', 'storage', 'other',
])

/** Coarse functional projection of the PerryLink catalog's domain vocabulary. */
const LEGACY_CATEGORY_MAP: Readonly<Record<string, PluginCategory>> = {
  agent: 'agent',
  session: 'session',
  tools: 'tool',
  model: 'llm',
  integration: 'tool',
  workflow: 'agent',
  memory: 'session',
  dev: 'tool',
  quality: 'tool',
  safety: 'sandbox',
  knowledge: 'tool',
  research: 'tool',
  interface: 'ui',
}

const MAX_SOURCE_ID_CHARS = 100
const MAX_MODULE_NAME_CHARS = 200
const MAX_DISPLAY_NAME_CHARS = 200
const MAX_DESCRIPTION_CHARS = 1000

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

function optionalString(value: unknown): string | undefined {
  return typeof value === 'string' ? value : undefined
}

function withinLimit(value: string | undefined, limit: number): boolean {
  return value === undefined || value.length <= limit
}

/** Validate the catalog-sources.json shape; an invalid shape has no specs. */
export function parseCatalogSourceConfig(raw: string): {
  specs: readonly CatalogSourceSpec[]
  warning?: string
} {
  let parsed: unknown
  try {
    parsed = JSON.parse(raw)
  } catch (error) {
    return { specs: [], warning: error instanceof Error ? error.message : String(error) }
  }
  if (!isRecord(parsed)) return { specs: [], warning: '目录源配置不是 JSON 对象' }
  if (parsed.version !== 1) return { specs: [], warning: '目录源配置版本不是 1' }
  if (!Array.isArray(parsed.sources)) return { specs: [], warning: '目录源配置缺少 sources 数组' }

  const specs: CatalogSourceSpec[] = []
  for (const [index, item] of parsed.sources.entries()) {
    if (!isRecord(item)) return { specs: [], warning: `第 ${index + 1} 个目录源不是对象` }
    const path = optionalString(item.path)
    const url = optionalString(item.url)
    if ((path === undefined) === (url === undefined)) {
      return { specs: [], warning: `第 ${index + 1} 个目录源必须且只能提供 path 或 url` }
    }
    const id = optionalString(item.id)
    if (id !== undefined && (id.trim().length === 0 || id.length > MAX_SOURCE_ID_CHARS)) {
      return { specs: [], warning: `第 ${index + 1} 个目录源 id 无效` }
    }
    specs.push({ id, path, url })
  }
  return { specs }
}

/** Parse the normalized v1 source document. */
function parseNormalizedSource(raw: unknown, sourceLabel: string): {
  entries: readonly [string, CatalogSourceEntry][]
  warning?: string
} {
  if (!isRecord(raw)) return { entries: [], warning: `${sourceLabel}: 内容不是 JSON 对象` }
  if (raw.format !== SOURCE_DOCUMENT_FORMAT) return { entries: [], warning: `${sourceLabel}: format 不是 ${SOURCE_DOCUMENT_FORMAT}` }
  if (raw.version !== 1) return { entries: [], warning: `${sourceLabel}: version 不是 1` }
  if (!Array.isArray(raw.entries)) return { entries: [], warning: `${sourceLabel}: 缺少 entries 数组` }

  const entries: [string, CatalogSourceEntry][] = []
  const seenKeys = new Set<string>()
  for (const [index, item] of raw.entries.entries()) {
    if (!isRecord(item)) return { entries: [], warning: `${sourceLabel}: 第 ${index + 1} 个条目不是对象` }
    const key = optionalString(item.key)
    if (key === undefined || key.trim().length === 0 || key.length > MAX_MODULE_NAME_CHARS) {
      return { entries: [], warning: `${sourceLabel}: 第 ${index + 1} 个条目 key 无效` }
    }
    if (seenKeys.has(key)) return { entries: [], warning: `${sourceLabel}: 条目 key ${key} 重复` }
    seenKeys.add(key)
    const names = isRecord(item.name) ? item.name : {}
    const descriptions = isRecord(item.description) ? item.description : {}
    const name = optionalString(names.zh)
    const nameEn = optionalString(names.en)
    const desc = optionalString(descriptions.zh)
    const descEn = optionalString(descriptions.en)
    if (!withinLimit(name, MAX_DISPLAY_NAME_CHARS) || !withinLimit(nameEn, MAX_DISPLAY_NAME_CHARS)) {
      return { entries: [], warning: `${sourceLabel}: 条目 ${key} 名称超过 ${MAX_DISPLAY_NAME_CHARS} 字符` }
    }
    if (name === undefined && nameEn === undefined && desc === undefined && descEn === undefined) {
      return { entries: [], warning: `${sourceLabel}: 条目 ${key} 没有可显示的字段` }
    }

    const requested = optionalString(item.category)
    const category = requested === undefined
      ? undefined
      : (VALID_CATEGORIES.has(requested) ? requested : 'other') as PluginCategory
    entries.push([key, { name, nameEn, desc, descEn, category }])

    const aliases = item.aliases
    if (aliases !== undefined) {
      if (!Array.isArray(aliases)) return { entries: [], warning: `${sourceLabel}: 条目 ${key} aliases 不是数组` }
      for (const alias of aliases) {
        if (typeof alias !== 'string' || alias.trim().length === 0 || alias.length > MAX_MODULE_NAME_CHARS) {
          return { entries: [], warning: `${sourceLabel}: 条目 ${key} aliases 无效` }
        }
        if (seenKeys.has(alias)) {
          return { entries: [], warning: `${sourceLabel}: 条目 ${key} 别名 ${alias} 与已有 key/别名重复` }
        }
        seenKeys.add(alias)
        entries.push([alias, { name, nameEn, desc, descEn, category }])
      }
    }
  }
  return { entries }
}

/** Parse the legacy PerryLink packages.json shape. */
function parseLegacySource(raw: unknown, sourceLabel: string): {
  entries: readonly [string, CatalogSourceEntry][]
  warning?: string
} {
  if (!Array.isArray(raw)) return { entries: [], warning: `${sourceLabel}: 内容不是数组` }
  const entries: [string, CatalogSourceEntry][] = []
  for (const [index, item] of raw.entries()) {
    if (!isRecord(item)) return { entries: [], warning: `${sourceLabel}: 第 ${index + 1} 个条目不是对象` }
    const key = optionalString(item.npm)
    const nameEn = optionalString(item.displayName)
    if (key === undefined || key.trim().length === 0 || key.length > MAX_MODULE_NAME_CHARS || nameEn === undefined) {
      return { entries: [], warning: `${sourceLabel}: 第 ${index + 1} 个条目缺少 npm/displayName` }
    }

    const locale = optionalString(item.locale)
    const summary = optionalString(item.summary)
    const summaryZh = optionalString(item.summaryZh)
    const displayNameZh = optionalString(item.displayNameZh)
    const desc = summaryZh ?? (locale === 'zh' ? summary : undefined)
    const descEn = locale === 'zh' ? undefined : summary

    const firstCategory = Array.isArray(item.categories) ? item.categories[0] : undefined
    const requested = optionalString(firstCategory) ?? 'other'
    const category = LEGACY_CATEGORY_MAP[requested] ?? 'other'

    if (
      !withinLimit(nameEn, MAX_DISPLAY_NAME_CHARS)
      || !withinLimit(displayNameZh, MAX_DISPLAY_NAME_CHARS)
      || !withinLimit(desc, MAX_DESCRIPTION_CHARS)
      || !withinLimit(descEn, MAX_DESCRIPTION_CHARS)
    ) {
      return { entries: [], warning: `${sourceLabel}: 条目 ${key} 名称或说明超过上限` }
    }
    entries.push([key, { name: displayNameZh, nameEn, desc, descEn, category }])
  }
  return { entries }
}

/** Auto-detect the two supported source documents. */
export function parseCatalogSourceDocument(raw: string, sourceLabel: string): {
  entries: readonly [string, CatalogSourceEntry][]
  warning?: string
} {
  let parsed: unknown
  try {
    parsed = JSON.parse(raw)
  } catch (error) {
    return { entries: [], warning: `${sourceLabel}: ${error instanceof Error ? error.message : String(error)}` }
  }
  return Array.isArray(parsed)
    ? parseLegacySource(parsed, sourceLabel)
    : parseNormalizedSource(parsed, sourceLabel)
}

/**
 * Load specs serially in config order. Field-level fallback intentionally follows
 * the existing override semantics: the highest source that supplies a field wins.
 */
export async function loadCatalogSources(
  specs: readonly CatalogSourceSpec[],
  readSource: (spec: CatalogSourceSpec) => Promise<string>,
): Promise<CatalogSourceResult> {
  const entries: Record<string, CatalogSourceEntry> = {}
  const warnings: string[] = []

  for (const [index, spec] of specs.entries()) {
    const sourceLabel = spec.id ?? spec.path ?? spec.url ?? `source-${index + 1}`
    try {
      const raw = await readSource(spec)
      if (raw.length > MAX_SOURCE_CHARS) {
        warnings.push(`${sourceLabel}: 内容超过 ${MAX_SOURCE_CHARS} 字符`)
        continue
      }
      const parsed = parseCatalogSourceDocument(raw, sourceLabel)
      if (parsed.warning !== undefined) {
        warnings.push(parsed.warning)
        continue
      }
      for (const [key, entry] of parsed.entries) entries[key] = entry
    } catch (error) {
      warnings.push(`${sourceLabel}: ${error instanceof Error ? error.message : String(error)}`)
    }
  }
  return { entries, warnings }
}

export type { CatalogEntry, PluginCategory }
