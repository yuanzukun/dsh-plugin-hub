/**
 * 插件管家主机半：dshPluginManager 远程服务（list / setEnabled）。
 *
 * - list：把 Cordis Loader 的当前行投影给浏览器，并附上中文目录信息。
 * - setEnabled：手术式改写全局层启停补丁（~/.dsh/cordis.patch.yml）。
 *   该文件被 launcher 的 HMR 观察者（watchUserPatches）实时监听，写入即热生效。
 *
 * 系统行（引导/传输/插件管家自身）与 !!js 表达式控制的行不允许在界面停用。
 * @module dsh-plugin-manager
 */

import { existsSync, mkdirSync, readFileSync, renameSync } from 'node:fs'
import { homedir } from 'node:os'
import { fileURLToPath } from 'node:url'
import { basename, dirname, join, resolve } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/cordis-plugin-loader'
import { Remote, TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import {
  CATALOG,
  CATEGORY_LABELS,
  FALLBACK_DESC,
  FALLBACK_DESC_EN,
  SYSTEM_MODULES,
  SYSTEM_ROW_IDS,
  type PluginCategory,
} from './catalog.ts'
import { initialPatchFile, setRowDisabled } from './patch-file.ts'
import { assertWritablePatchYaml } from './patch-yaml.ts'
import { createTimestampedBackup, localDayKey, pruneBackups, stampOf, writeFileAtomic } from './fs-safe.ts'
import {
  auditDependencySpecs,
  buildBackupDocument,
  buildBackupPreview,
  mergeBundles,
  mergeDependencies,
  mergeOverrides,
  mergePatchRows,
  validateBackupDocument,
} from './backup.ts'
import { isDeclaredDependency, isOfficialModule } from './origin.ts'
import {
  loadCatalogSources,
  parseCatalogSourceConfig,
  type CatalogSourceResult,
  type CatalogSourceSpec,
} from './catalog-source.ts'
import type {
  BackupExportResult,
  BackupImportResult,
  BackupPreviewResult,
  CatalogEditResult,
  CatalogOverrides,
  CatalogRepairResult,
  PluginManagerEntry,
  PluginManagerFiberPhase,
  PluginManagerSnapshot,
  SetEnabledResult,
} from './types.ts'

export type * from './types.ts'

/** 与 dsh-home-paths 一致的 home 解析（避免额外运行时依赖）：$DSH_HOME > ~/.dsh。 */
function dshHome(): string {
  const fromEnv = process.env.DSH_HOME
  const selected = fromEnv !== undefined && fromEnv.trim().length > 0
    ? fromEnv.trim()
    : join(homedir(), '.dsh')
  const expanded = selected === '~' ? homedir()
    : selected.startsWith('~/') || selected.startsWith('~\\') ? join(homedir(), selected.slice(2))
      : selected
  return resolve(expanded)
}

/** 全局层启停补丁路径（与 launcher 的 homePatchPath 一致）。 */
function globalPatchPath(): string {
  return join(dshHome(), 'cordis.patch.yml')
}

/** 目录覆盖文件路径。 */
function overridesPath(): string {
  return join(dshHome(), 'plugin-manager', 'catalog.json')
}

/** 社区目录源配置文件路径。 */
function catalogSourcesPath(): string {
  return join(dshHome(), 'plugin-manager', 'catalog-sources.json')
}

/** 是否为 file: 方式本地加载的模块（评估 P2-5）。 */
function isLocalModule(moduleName: string): boolean {
  return /^file:/i.test(moduleName)
}

/** 把 file:// URL（或 file: 路径）折成短名：取 basename 去常见脚本扩展名（评估 P2-5）。 */
function fileModuleShortName(moduleName: string): string | undefined {
  if (!isLocalModule(moduleName)) return undefined
  try {
    const base = basename(fileURLToPath(moduleName)).replace(/\.(?:m|c)?js$/i, '')
    return base.length > 0 ? base : undefined
  } catch {
    // 非法 file: URL：退回通用短名逻辑。
    return undefined
  }
}

/** 紧凑一个模块名（去掉作用域与常见前缀）。 */
function moduleShortName(moduleName: string): string {
  const fromFile = fileModuleShortName(moduleName)
  if (fromFile !== undefined) return fromFile
  const unscoped = moduleName.startsWith('@') ? moduleName.slice(moduleName.indexOf('/') + 1) : moduleName
  return unscoped
    .replace(/^cordis:/, '')
    .replace(/^cordis-plugin-/, '')
    .replace(/^dsh-(?:host-|client-)?/, '')
}

/** FiberState 跨包常量枚举的运行时镜像。 */
const FIBER_STATE = {
  PENDING: 0,
  LOADING: 1,
  ACTIVE: 2,
  FAILED: 3,
  DISPOSED: 4,
  UNLOADING: 5,
} as const

const FIBER_PHASE: Readonly<Record<number, PluginManagerFiberPhase>> = {
  [FIBER_STATE.PENDING]: 'pending',
  [FIBER_STATE.LOADING]: 'loading',
  [FIBER_STATE.ACTIVE]: 'active',
  [FIBER_STATE.FAILED]: 'failed',
  [FIBER_STATE.DISPOSED]: null,
  [FIBER_STATE.UNLOADING]: 'unloading',
}

/**
 * 读取目录覆盖文件（评估 P1-2）：文件不存在返回空表（正常形态）；
 * 存在但读不出来/损坏时同样返回空表并携带 warning（不阻断列表，由界面横幅提示）。
 */
function readOverrides(): { overrides: CatalogOverrides; warning?: string } {
  let raw: string
  try {
    raw = readFileSync(overridesPath(), 'utf8')
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return { overrides: {} }
    return { overrides: {}, warning: error instanceof Error ? error.message : String(error) }
  }
  try {
    const parsed: unknown = JSON.parse(raw)
    if (parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return { overrides: parsed as CatalogOverrides }
    }
    return { overrides: {}, warning: '文件内容不是 JSON 对象' }
  } catch (error) {
    return { overrides: {}, warning: error instanceof Error ? error.message : String(error) }
  }
}

/** 安全读文件：不存在返回 undefined，其它错误抛给调用方。 */
function tryRead(path: string): string | undefined {
  try {
    return readFileSync(path, 'utf8')
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return undefined
    throw error
  }
}

/** 把 file:// URL（或绝对路径）归一化为本地目录；非法/非本地时返回 undefined。 */
function urlToDir(value: string): string | undefined {
  try {
    if (value.startsWith('file:')) return fileURLToPath(value)
    if (/^[a-zA-Z]:[\\/]/.test(value) || value.startsWith('/') || value.startsWith('\\\\')) return value
    return undefined
  } catch {
    return undefined
  }
}

/** profile 清单（package.json）的宽松形态：只关心读写的那几处，其余原样保留。 */
interface ProfileManifest {
  dependencies?: Record<string, string>
  dsh?: { profile?: { bundles?: string[] }; [key: string]: unknown }
  [key: string]: unknown
}

/** 读取 profile 清单；文件缺失或损坏时抛错（由调用方兜底）。 */
function readProfileManifest(path: string): ProfileManifest {
  const parsed: unknown = JSON.parse(readFileSync(path, 'utf8'))
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error(`profile 清单 ${path} 不是 JSON 对象`)
  }
  return parsed as ProfileManifest
}

/** 写回 profile 清单（2 空格缩进 + 末尾换行，与 dsh 的 writeProfileManifest 一致；原子替换）。 */
function writeProfileManifest(path: string, manifest: ProfileManifest): void {
  writeFileAtomic(path, JSON.stringify(manifest, null, 2) + '\n')
}

/** 补丁备份（.bak）滚动保留份数。 */
const PATCH_BACKUP_KEEP = 5

/** 备份 JSON 的大小上限（字符数，约 2MB 量级；防自我 DoS 与异常文件）。 */
const MAX_IMPORT_JSON_CHARS = 2 * 1024 * 1024

/**
 * 服务端输入长度上限（评估 P2-8）：客户端 maxLength 只是礼貌，服务端限制才是限制。
 * 上限放宽到「显然异常才拦」的量级（比客户端 60/200 宽），让正常长尾输入不被误伤。
 */
const MAX_MODULE_NAME_CHARS = 200
const MAX_OVERRIDE_NAME_CHARS = 200
const MAX_OVERRIDE_DESC_CHARS = 1000

/** 模块名/名称/说明超限的统一拒绝（评估 P2-8）。 */
function tooLong(field: 'moduleName' | 'name' | 'desc'): CatalogEditResult {
  const limit = field === 'moduleName' ? MAX_MODULE_NAME_CHARS : field === 'name' ? MAX_OVERRIDE_NAME_CHARS : MAX_OVERRIDE_DESC_CHARS
  const label = field === 'moduleName' ? '模块名' : field === 'name' ? '名称' : '说明'
  return { accepted: false, reason: 'invalid-input', message: `${label}过长（上限 ${limit} 字符）` }
}

/** 目录缺失时的兜底分类。 */
const OTHER_CATEGORY = 'other' as PluginCategory

/**
 * 插件管家网关：注册为 cordis 服务 dshPluginManager，由 Typert 网关自动导出
 * （SRC 模式：参数名/返回值自动 JSON 编解码，方法参数必须保持简单形参名）。
 */
export class PluginManagerGateway extends TypertRemoteService {
  static inject = ['loader']

  /**
   * 全局写队列（评估 P1-1）：所有落盘方法（启停/目录编辑/备份导入/损坏文件改名）
   * 共用同一条串行队列——此前三条独立队列互不感知，导入与启停并发时会互相覆盖、
   * 静默丢更新。同一文件的所有写入方必须排同一条队。
   */
  private writeQueue: Promise<void> = Promise.resolve()

  /** 目录源在第一次 list() 时加载并缓存；本版不做热刷新，避免远程源反复请求。 */
  private sourceCache: Promise<CatalogSourceResult> | null = null

  constructor(ctx: Context) {
    super(ctx, 'dshPluginManager')
  }

  /** 定位一个非分组行。 */
  private findEntry(entryId: string) {
    for (const entry of this.ctx.loader.entries()) {
      if (entry.options.group) continue
      if (entry.id === entryId) return entry
    }
    return undefined
  }

  /** 定位当前 profile 目录：优先取 Loader 的 baseUrl（profile boot 会设成 profile 目录）。 */
  private profileDir(): string | undefined {
    const loaderCtx = (this.ctx.loader as unknown as { ctx?: { baseUrl?: unknown } } | undefined)?.ctx
    const rootBase = (this.ctx as unknown as { baseUrl?: unknown }).baseUrl
    const baseUrl = loaderCtx?.baseUrl ?? rootBase
    if (typeof baseUrl !== 'string') return undefined
    const dir = urlToDir(baseUrl)
    if (dir === undefined) return undefined
    return existsSync(join(dir, 'package.json')) ? dir : undefined
  }

  /**
   * 读取当前 profile 的依赖表（issue #1：推导「用户安装」信号）。
   * 定位失败或文件缺失/损坏时按空表兜底——来源标记是增强信息，绝不因它阻断列表。
   */
  private profileDependencies(): Readonly<Record<string, string>> {
    try {
      const dir = this.profileDir()
      if (dir === undefined) return {}
      const manifest = readProfileManifest(join(dir, 'package.json'))
      const deps = manifest.dependencies
      if (deps === null || typeof deps !== 'object' || Array.isArray(deps)) return {}
      return deps
    } catch {
      return {}
    }
  }

  /** 本地「今天」已做过补丁备份的日期键；跨天第一次写前自动备份一次。 */
  private patchBackupDay: string | null = null

  /** 把覆盖表原子化写入 catalog.json（目录缺失时创建）。 */
  private writeOverrides(overrides: CatalogOverrides): void {
    mkdirSync(dirname(overridesPath()), { recursive: true })
    writeFileAtomic(overridesPath(), JSON.stringify(overrides, null, 2) + '\n')
  }

  /**
   * 写全局补丁文件（评估 P0-1/P0-2）：跨天首次写前自动备份（滚动保留
   * PATCH_BACKUP_KEEP 份），写前 YAML 回读校验，临时文件 + rename 原子替换。
   */
  private writePatchFile(path: string, content: string): void {
    assertWritablePatchYaml(content)
    const day = localDayKey(new Date())
    if (this.patchBackupDay !== day) {
      try {
        createTimestampedBackup(path, new Date())
        pruneBackups(path, PATCH_BACKUP_KEEP)
        this.patchBackupDay = day
      } catch {
        // 备份失败不阻断写盘；保持未备份状态，下次写前重试。
      }
    }
    writeFileAtomic(path, content)
  }

  /** 保存一个模块的覆盖：空字段视为清除；两字段皆空则移除整条覆盖。 */
  @Remote('setOverride')
  setOverride(moduleName: string, name: string, desc: string): Promise<CatalogEditResult> {
    const run = async (): Promise<CatalogEditResult> => {
      try {
        if (typeof moduleName !== 'string' || moduleName.length === 0) {
          return { accepted: false, reason: 'invalid-input', message: '模块名不能为空' }
        }
        if (moduleName.length > MAX_MODULE_NAME_CHARS) return tooLong('moduleName')
        const overrides = readOverrides().overrides
        const next: CatalogOverrides = { ...overrides }
        const entry: CatalogOverrides[string] = {}
        const trimmedName = (name ?? '').trim()
        const trimmedDesc = (desc ?? '').trim()
        if (trimmedName.length > MAX_OVERRIDE_NAME_CHARS) return tooLong('name')
        if (trimmedDesc.length > MAX_OVERRIDE_DESC_CHARS) return tooLong('desc')
        if (trimmedName.length > 0) entry.name = trimmedName
        if (trimmedDesc.length > 0) entry.desc = trimmedDesc
        if (entry.name === undefined && entry.desc === undefined) {
          delete next[moduleName]
        } else {
          next[moduleName] = entry
        }
        this.writeOverrides(next)
        return { accepted: true }
      } catch (error) {
        return {
          accepted: false,
          reason: 'io-error',
          message: error instanceof Error ? error.message : String(error),
        }
      }
    }
    const queued = this.writeQueue.then(run, run)
    this.writeQueue = queued.then(() => {}, () => {})
    return queued
  }

  /** 移除一个模块的覆盖，恢复内置目录/短名。 */
  @Remote('removeOverride')
  removeOverride(moduleName: string): Promise<CatalogEditResult> {
    const run = async (): Promise<CatalogEditResult> => {
      try {
        if (typeof moduleName !== 'string' || moduleName.length === 0) {
          return { accepted: false, reason: 'invalid-input', message: '模块名不能为空' }
        }
        if (moduleName.length > MAX_MODULE_NAME_CHARS) return tooLong('moduleName')
        const overrides = readOverrides().overrides
        if (!Object.prototype.hasOwnProperty.call(overrides, moduleName)) {
          return { accepted: true }
        }
        const next: CatalogOverrides = { ...overrides }
        delete next[moduleName]
        this.writeOverrides(next)
        return { accepted: true }
      } catch (error) {
        return {
          accepted: false,
          reason: 'io-error',
          message: error instanceof Error ? error.message : String(error),
        }
      }
    }
    const queued = this.writeQueue.then(run, run)
    this.writeQueue = queued.then(() => {}, () => {})
    return queued
  }

  /**
   * 把损坏的覆盖文件改名保存（评估 P1-2）：catalog.json → catalog.json.corrupt-<时间戳>.json。
   * 内容留在磁盘上可人工找回；改名后 list() 不再报读取失败。
   */
  @Remote('quarantineOverrides')
  quarantineOverrides(): Promise<CatalogRepairResult> {
    const run = async (): Promise<CatalogRepairResult> => {
      try {
        const path = overridesPath()
        if (!existsSync(path)) return { accepted: true }
        const movedTo = `${path}.corrupt-${stampOf(new Date())}.json`
        renameSync(path, movedTo)
        return { accepted: true, movedTo }
      } catch (error) {
        return {
          accepted: false,
          reason: 'io-error',
          message: error instanceof Error ? error.message : String(error),
        }
      }
    }
    const queued = this.writeQueue.then(run, run)
    this.writeQueue = queued.then(() => {}, () => {})
    return queued
  }

  /**
   * 运行时行 id 形如 include:<配置行 id>（include 子树的命名空间前缀），
   * 而补丁文件按配置行 id 定位——取最后一段作为补丁 id。
   */
  private patchIdOf(entryId: string): string {
    return entryId.slice(entryId.lastIndexOf(':') + 1)
  }

  /** 判断一行是否允许界面启停。 */
  private toggleGuard(entryId: string, moduleName: string): SetEnabledResult | undefined {
    const patchId = this.patchIdOf(entryId)
    if (patchId.length === 0) {
      return { accepted: false, reason: 'system', message: '引导行不允许启停' }
    }
    if (SYSTEM_MODULES.has(moduleName) || SYSTEM_ROW_IDS.has(entryId) || SYSTEM_ROW_IDS.has(patchId)) {
      return { accepted: false, reason: 'system', message: '系统插件：停用会导致应用或插件管家自身不可用' }
    }
    const entry = this.findEntry(entryId)
    if (entry === undefined) {
      return { accepted: false, reason: 'not-found', message: `插件行不存在：${entryId}` }
    }
    const raw = entry.options.disabled
    if (typeof raw !== 'boolean' && raw !== null && raw !== undefined) {
      return { accepted: false, reason: 'expression', message: '该插件由 !!js 表达式控制启停，请直接编辑配置文件' }
    }
    return undefined
  }

  /** 当前 Loader 行快照 + 目录信息。 */
  @Remote('list')
  async list(): Promise<PluginManagerSnapshot> {
    const sources = await this.catalogSources()
    const { overrides, warning } = readOverrides()
    const declaredDeps = this.profileDependencies()
    const entries: PluginManagerEntry[] = []
    let enabledCount = 0
    for (const entry of this.ctx.loader.entries()) {
      if (entry.options.group) continue
      const moduleName = entry.options.name
      const enabled = !entry.disabled
      if (enabled) enabledCount += 1
      const catalog = CATALOG[moduleName]
      const override = overrides[moduleName]
      const sourceEntry = sources.entries[moduleName]
      const system = SYSTEM_MODULES.has(moduleName) || SYSTEM_ROW_IDS.has(entry.id) || SYSTEM_ROW_IDS.has(this.patchIdOf(entry.id))
      const raw = entry.options.disabled
      const expressionManaged = typeof raw !== 'boolean' && raw !== null && raw !== undefined
      const fiberPhase: PluginManagerFiberPhase = entry.fiber === undefined
        ? null
        : FIBER_PHASE[entry.fiber.state as number] ?? null
      // 英文环境显示名/说明（评估 P2-9）：用户覆盖两种语言下都生效（用户数据优先），
      // 其次取内置英文目录，最后回退英文短名/英文兜底说明——不把中文内容暴露给英文用户。
      const shortName = moduleShortName(moduleName)
      entries.push({
        entryId: entry.id,
        moduleName,
        enabled,
        fiberPhase,
        displayName: override?.name ?? sourceEntry?.name ?? catalog?.name ?? shortName,
        description: override?.desc ?? sourceEntry?.desc ?? catalog?.desc ?? FALLBACK_DESC,
        displayNameEn: override?.name ?? sourceEntry?.nameEn ?? catalog?.nameEn ?? shortName,
        descriptionEn: override?.desc ?? sourceEntry?.descEn ?? catalog?.descEn ?? FALLBACK_DESC_EN,
        category: sourceEntry?.category ?? catalog?.category ?? OTHER_CATEGORY,
        system,
        toggleable: !system && !expressionManaged,
        toggleBlockReason: system ? 'system' : expressionManaged ? 'expression' : null,
        hasOverride: override !== undefined,
        local: isLocalModule(moduleName),
        declared: isDeclaredDependency(declaredDeps, moduleName),
        official: isOfficialModule(moduleName),
      })
    }
    return {
      patchFile: globalPatchPath(),
      overridesFile: overridesPath(),
      sourcesFile: catalogSourcesPath(),
      entryCount: entries.length,
      enabledCount,
      entries,
      categoryLabels: CATEGORY_LABELS,
      ...(warning === undefined ? {} : { overridesWarning: warning }),
      ...(sources.warnings.length > 0 ? { sourcesWarning: sources.warnings.join('；') } : {}),
    }
  }

  /** 加载并缓存社区目录源；配置或源损坏只降级为警告。 */
  private catalogSources(): Promise<CatalogSourceResult> {
    if (this.sourceCache !== null) return this.sourceCache
    const loaded = this.loadCatalogSources()
    this.sourceCache = loaded.catch(error => ({
      entries: {},
      warnings: [error instanceof Error ? error.message : String(error)],
    }))
    return this.sourceCache
  }

  private async loadCatalogSources(): Promise<CatalogSourceResult> {
    let raw: string
    try {
      raw = readFileSync(catalogSourcesPath(), 'utf8')
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        return { entries: {}, warnings: [] }
      }
      return { entries: {}, warnings: [error instanceof Error ? error.message : String(error)] }
    }

    const config = parseCatalogSourceConfig(raw)
    if (config.warning !== undefined) {
      return { entries: {}, warnings: [config.warning] }
    }
    return loadCatalogSources(config.specs, async (spec: CatalogSourceSpec) => {
      if (spec.url !== undefined) {
        const url = new URL(spec.url)
        if (url.protocol !== 'https:') throw new Error('目录源 URL 只允许 https')
        const response = await fetch(url, { signal: AbortSignal.timeout(10_000) })
        if (!response.ok) throw new Error(`HTTP ${response.status}`)
        return await response.text()
      }
      const path = resolve(dirname(catalogSourcesPath()), spec.path ?? '')
      return readFileSync(path, 'utf8')
    })
  }

  /** 启停一个插件：改写全局层补丁文件，由 HMR 观察者热应用。 */
  @Remote('setEnabled')
  setEnabled(entryId: string, enabled: boolean): Promise<SetEnabledResult> {
    const entry = this.findEntry(entryId)
    if (entry === undefined) {
      return Promise.resolve({ accepted: false, reason: 'not-found', message: `插件行不存在：${entryId}` })
    }
    const guarded = this.toggleGuard(entryId, entry.options.name)
    if (guarded !== undefined) return Promise.resolve(guarded)

    const patchId = this.patchIdOf(entryId)
    /** 无法识别行的拒绝结果（评估 P0-2：防静默追加重复行）。 */
    const unrecognized = (): SetEnabledResult => ({
      accepted: false,
      reason: 'unrecognized',
      message: '补丁文件里已存在该插件行，但行格式无法识别（行块首键必须是 id）；为避免写入重复行已拒绝本次操作，请手工检查 cordis.patch.yml',
    })
    const run = async (): Promise<SetEnabledResult> => {
      const path = globalPatchPath()
      try {
        const content = tryRead(path) ?? initialPatchFile()
        let edited = setRowDisabled(content, patchId, enabled)
        if (edited.blocked === 'expression') {
          return { accepted: false, reason: 'expression', message: '该插件由 !!js 表达式控制启停，请直接编辑配置文件' }
        }
        if (edited.blocked === 'unrecognized') return unrecognized()
        if (edited.changed) {
          // 写前重读一次：外部手工编辑与我们并发时，在最新内容上重做合并，避免丢更新。
          const current = tryRead(path)
          if (current !== undefined && current !== content) {
            edited = setRowDisabled(current, patchId, enabled)
            if (edited.blocked === 'expression') {
              return { accepted: false, reason: 'expression', message: '该插件由 !!js 表达式控制启停，请直接编辑配置文件' }
            }
            if (edited.blocked === 'unrecognized') return unrecognized()
          }
          this.writePatchFile(path, edited.content)
        }
        return { accepted: true }
      } catch (error) {
        return {
          accepted: false,
          reason: 'io-error',
          message: error instanceof Error ? error.message : String(error),
        }
      }
    }

    const queued = this.writeQueue.then(run, run)
    this.writeQueue = queued.then(() => {}, () => {})
    return queued
  }

  /**
   * 导入预览（评估 P1-3）：解析备份并与当前状态逐项比对，返回将翻转的启停行、
   * 将新增/覆盖的依赖、将追加的 bundles 与备注清单——只读，不写任何文件。
   * 界面先展示预览，用户确认后才调用 importBackup 真正写入。
   */
  @Remote('previewBackup')
  previewBackup(json: string): BackupPreviewResult {
    try {
      if (typeof json !== 'string' || json.length === 0) {
        return { accepted: false, reason: 'invalid-format', message: '备份内容为空' }
      }
      if (json.length > MAX_IMPORT_JSON_CHARS) {
        return { accepted: false, reason: 'too-large', message: '备份文件过大（上限 2MB）' }
      }
      let parsed: unknown
      try {
        parsed = JSON.parse(json)
      } catch {
        return { accepted: false, reason: 'invalid-format', message: '备份文件不是合法的 JSON' }
      }
      const validation = validateBackupDocument(parsed)
      if (!validation.ok) {
        return { accepted: false, reason: 'invalid-format', message: validation.reason }
      }
      const profileDir = this.profileDir()
      if (profileDir === undefined) {
        return { accepted: false, reason: 'profile-not-found', message: '无法定位当前 profile 目录（缺少 package.json）' }
      }
      const manifest = readProfileManifest(join(profileDir, 'package.json'))
      const preview = buildBackupPreview({
        currentOverrides: readOverrides().overrides,
        currentDependencies: manifest.dependencies ?? {},
        currentBundles: manifest.dsh?.profile?.bundles ?? [],
        currentPatchFile: tryRead(globalPatchPath()),
        document: validation.document,
      })
      return { accepted: true, preview }
    } catch (error) {
      return { accepted: false, reason: 'io-error', message: error instanceof Error ? error.message : String(error) }
    }
  }

  /** 导出备份：备注覆盖 + profile 依赖/bundles + 全局启停补丁。 */
  @Remote('exportBackup')
  exportBackup(): BackupExportResult {
    try {
      const profileDir = this.profileDir()
      if (profileDir === undefined) {
        return { accepted: false, reason: 'profile-not-found', message: '无法定位当前 profile 目录（缺少 package.json）' }
      }
      const manifest = readProfileManifest(join(profileDir, 'package.json'))
      const document = buildBackupDocument({
        profile: basename(profileDir),
        overrides: readOverrides().overrides,
        dependencies: manifest.dependencies ?? {},
        bundles: manifest.dsh?.profile?.bundles ?? [],
        patchFile: tryRead(globalPatchPath()),
      })
      return { accepted: true, document }
    } catch (error) {
      return { accepted: false, reason: 'io-error', message: error instanceof Error ? error.message : String(error) }
    }
  }

  /**
   * 导入备份（评估 P0-3 两阶段）：恢复备注 + profile 依赖/bundles + 全局启停补丁
   * （合并语义，保留当前独有条目）。
   *
   * - `allowNonRegistrySpecs` 为 null（首次调用）：只解析与安全审计。若备份含非常规
   *   依赖（git/file/URL 等），返回 confirmation-required 与逐条清单，**不写任何文件**；
   *   全部依赖均为 registry 风格时直接执行写入。
   * - 传确认清单（用户勾选后重调）：执行写入；清单外的非常规依赖被跳过，
   *   并以 detail.nonRegistrySkipped 报告条数。
   */
  @Remote('importBackup')
  importBackup(json: string, allowNonRegistrySpecs: readonly string[] | null): Promise<BackupImportResult> {
    const run = async (): Promise<BackupImportResult> => {
      try {
        if (typeof json !== 'string' || json.length === 0) {
          return { accepted: false, reason: 'invalid-format', message: '备份内容为空' }
        }
        if (json.length > MAX_IMPORT_JSON_CHARS) {
          return { accepted: false, reason: 'too-large', message: '备份文件过大（上限 2MB）' }
        }
        let parsed: unknown
        try {
          parsed = JSON.parse(json)
        } catch {
          return { accepted: false, reason: 'invalid-format', message: '备份文件不是合法的 JSON' }
        }
        const validation = validateBackupDocument(parsed)
        if (!validation.ok) {
          return { accepted: false, reason: 'invalid-format', message: validation.reason }
        }
        const doc = validation.document

        const profileDir = this.profileDir()
        if (profileDir === undefined) {
          return { accepted: false, reason: 'profile-not-found', message: '无法定位当前 profile 目录（缺少 package.json）' }
        }

        // 依赖安全审计：非常规 spec 必须经用户逐项确认（或确认后跳过），绝不静默合并。
        const audit = auditDependencySpecs(doc.dependencies, allowNonRegistrySpecs)
        if (allowNonRegistrySpecs === null && audit.pending.length > 0) {
          return {
            accepted: false,
            reason: 'confirmation-required',
            message: `备份包含 ${audit.pending.length} 个非常规依赖来源（本地路径 / 外部仓库等），安装时会执行其携带的代码，需逐项确认后才会写入`,
            pendingNonRegistrySpecs: audit.pending,
          }
        }

        // 1) 备注覆盖
        const overrides = readOverrides().overrides
        const overMerged = mergeOverrides(overrides, doc.overrides)
        this.writeOverrides(overMerged.merged)

        // 2) profile 清单：依赖（仅 registry 风格 + 已确认条目）+ bundles
        const manifestPath = join(profileDir, 'package.json')
        const manifest = readProfileManifest(manifestPath)
        const depsMerged = mergeDependencies(manifest.dependencies ?? {}, audit.writable)
        const bundlesMerged = mergeBundles(manifest.dsh?.profile?.bundles ?? [], doc.bundles)
        writeProfileManifest(manifestPath, {
          ...manifest,
          dependencies: depsMerged.merged,
          dsh: {
            ...manifest.dsh,
            profile: {
              ...manifest.dsh?.profile,
              bundles: bundlesMerged.merged,
            },
          },
        })

        // 3) 全局启停补丁（合并：按行应用备份里的启停状态，保留当前其余行；
        //    与 previewBackup 共用 mergePatchRows，保证预览与实际写入一致）
        let patchRowsRestored = 0
        if (doc.patchFile !== undefined) {
          const patchPath = globalPatchPath()
          const merged = mergePatchRows(tryRead(patchPath) ?? initialPatchFile(), doc.patchFile)
          patchRowsRestored = merged.rows.length
          if (patchRowsRestored > 0) this.writePatchFile(patchPath, merged.content)
        }

        const profileName = basename(profileDir)
        return {
          accepted: true,
          detail: {
            overridesRestored: overMerged.changed,
            dependenciesRestored: depsMerged.changed,
            bundlesRestored: bundlesMerged.changed,
            patchRowsRestored,
            nonRegistrySkipped: audit.pending.length,
          },
          installCommand: `dsh plugin --profile ${profileName} install`,
          restartRequired: true,
        }
      } catch (error) {
        return { accepted: false, reason: 'io-error', message: error instanceof Error ? error.message : String(error) }
      }
    }
    const queued = this.writeQueue.then(run, run)
    this.writeQueue = queued.then(() => {}, () => {})
    return queued
  }
}

export default PluginManagerGateway

// 保证覆盖文件所在目录存在（只在需要时创建）。
try {
  mkdirSync(dirname(overridesPath()), { recursive: true })
} catch {
  // 目录不可创建时不阻断插件启动：覆盖功能降级为“无覆盖”。
}

// 供界面展示分类标签。
export { CATALOG, CATEGORY_LABELS, SYSTEM_MODULES } from './catalog.ts'
