// 忠实复现真实 app 的端点声明检查（含 typert-loader 严格注册路径）。
// 裸包名行从 profile node_modules 解析（与真实 app 相同的 bareModuleBaseUrl 机制），
// 抓取 connection 上注册的 claim，验证 dshPluginManager/* 被声明并可调用。
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import assert from 'node:assert'
import { boot } from '@deepseek-ai/dsh-app-boot'
import { installRemoteAccess, testPeer, usesRemoteAccess } from './runtime.mjs'

const tempHome = mkdtempSync(join(tmpdir(), 'dsh-pm-claims-'))
process.env.DSH_HOME = tempHome
const selfUrl = (specifier) => import.meta.resolve(specifier)
const typertUrl = selfUrl('@deepseek-ai/dsh-typert-registry')
const typertLoaderUrl = selfUrl('@deepseek-ai/dsh-typert-loader')
const gatewayUrl = selfUrl('@deepseek-ai/dsh-api-gateway')
const pluginUrl = selfUrl('@txc2768651338/dsh-plugin-manager')
const configPath = join(tempHome, 'cordis.yml')
writeFileSync(configPath, [
  '- id: typert',
  "  name: '" + typertUrl + "'",
  '- id: typert-loader',
  "  name: '" + typertLoaderUrl + "'",
  '- id: api-gateway',
  "  name: '" + gatewayUrl + "'",
  '- id: dsh-plugin-manager',
  "  name: '" + pluginUrl + "'",
  '',
].join('\n'))

const claims = []
try {
  const ctx = await boot('dsh-pm-claims', configPath, undefined, async (hostCtx) => {
    await installRemoteAccess(hostCtx)
    // The official service must survive loading our Host half unchanged.
    hostCtx.provide('pluginManager', { official: true, listPlugins: () => ['official'] })
    hostCtx.provide('connection', {
      rpc: {
        intercept: (channel, claim, handler) => {
          claims.push({ channel, claim, handler })
          return () => {}
        },
      },
    })
  })

  assert.strictEqual(claims.length, 1, 'gateway registered one rpc intercept')
  assert.strictEqual(ctx.get('pluginManager').official, true, 'official service is preserved')
  assert.deepStrictEqual(ctx.get('pluginManager').listPlugins(), ['official'])
  assert.ok(ctx.get('dshPluginManager'), 'our service has its own identity')
  const { claim, handler: dispatch } = claims[0]
  const peer = testPeer(ctx)
  const handler = (endpoint, payload, signal) => dispatch(endpoint, payload, signal, peer)
  assert.strictEqual(claim('pluginManager/list'), false, 'our endpoints do not occupy the official namespace')
  for (const endpoint of ['dshPluginManager/list', 'dshPluginManager/setEnabled', 'dshPluginManager/setOverride', 'dshPluginManager/removeOverride']) {
    console.log(endpoint, '=>', claim(endpoint))
  }
  assert.strictEqual(claim('dshPluginManager/list'), true, 'dshPluginManager/list must be claimed')
  assert.strictEqual(claim('dshPluginManager/setEnabled'), true, 'dshPluginManager/setEnabled must be claimed')
  assert.strictEqual(claim('dshPluginManager/setOverride'), true, 'dshPluginManager/setOverride must be claimed')
  assert.strictEqual(claim('dshPluginManager/removeOverride'), true, 'dshPluginManager/removeOverride must be claimed')

  const result = await handler('dshPluginManager/list', { args: {} }, new AbortController().signal)
  console.log('handler result ok:', result.ok, result.ok ? 'entries=' + result.value.entries.length : JSON.stringify(result.error))
  assert.strictEqual(result.ok, true)

  // 严格路径下 setEnabled 也应可调用（保护行拒绝 + 参数解码）
  const toggle = await handler('dshPluginManager/setEnabled', { args: { entryId: 'include:dsh-plugin-manager', enabled: false } }, new AbortController().signal)
  console.log('setEnabled via handler:', JSON.stringify(toggle))
  assert.strictEqual(toggle.ok, true)
  assert.strictEqual(toggle.value.reason, 'system')

  // P0-3：importBackup 双参数编解码（json + null 审计标记）经严格注册路径可达主机。
  const goodDoc = { format: 'dsh-plugin-manager-backup', version: 1, createdAt: 't', profile: 'web', overrides: {}, dependencies: {}, bundles: [] }
  const probeImport = await handler('dshPluginManager/importBackup', { args: { json: JSON.stringify(goodDoc), allowNonRegistrySpecs: null } }, new AbortController().signal)
  console.log('importBackup via handler:', JSON.stringify(probeImport.ok ? probeImport.value : probeImport.error))
  assert.strictEqual(probeImport.ok, true, 'both params decode cleanly')
  assert.strictEqual(probeImport.value.reason, 'profile-not-found', 'doc validated, flow reached profile check')
  const badImport = await handler('dshPluginManager/importBackup', { args: { json: 'not-json', allowNonRegistrySpecs: null } }, new AbortController().signal)
  assert.strictEqual(badImport.ok, true)
  assert.strictEqual(badImport.value.reason, 'invalid-format')

  if (usesRemoteAccess) {
    const nonOwner = testPeer(ctx, { kind: 'test-guest' })
    for (const [method, args] of [
      ['list', {}],
      ['setOverride', { moduleName: '@x/test', name: 'blocked', desc: '' }],
      ['setEnabled', { entryId: 'include:dsh-plugin-manager', enabled: false }],
    ]) {
      const denied = await dispatch(`dshPluginManager/${method}`, { args }, new AbortController().signal, nonOwner)
      assert.strictEqual(denied.ok, false, `non-owner ${method} is denied`)
      assert.strictEqual(denied.error.code, 'remote-access/denied')
    }
    await peer.dispose()
    const expired = await handler('dshPluginManager/list', { args: {} }, new AbortController().signal)
    assert.strictEqual(expired.ok, false, 'disposed Peers cannot use the manager')
    assert.strictEqual(expired.error.code, 'gateway/peer-disposed')
    console.log('0.2.1 access boundary: owner allowed, non-owner and disposed Peer rejected')
  }

  await ctx.fiber.dispose()
  console.log('CLAIMS E2E: ALL PASS')
} finally {
  rmSync(tempHome, { recursive: true, force: true })
}
