// Execute the published browser artifact against DSH's actual SlotRegistry.
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { runInNewContext } from 'node:vm'
import * as cordis from '@deepseek-ai/cordis'
import * as slots from '@deepseek-ai/dsh-client-ui-slots'
import * as boot from '@deepseek-ai/dsh-app-boot'
import { load } from 'js-yaml'

const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))
const patch = load(readFileSync(new URL('../cordis.patch.yml', import.meta.url), 'utf8'))
assert.equal(patch[0].insert[0].id, 'dsh-plugin-manager', 'bundle does not replace the official row')
assert.equal(patch[0].insert[0].name, manifest.name)
assert.deepEqual(manifest.dsh.client.inject, [
  '@deepseek-ai/dsh-client-locale', '@deepseek-ai/dsh-client-ui-settings', '@deepseek-ai/dsh-api-remotes',
], 'client graph declares package identities instead of service names')

if (typeof boot.evaluatePluginCompatibility === 'function') {
  for (const version of ['0.1.5-rc.3', '0.2.0-rc.2', '0.2.1-rc.2']) {
    assert.equal(boot.evaluatePluginCompatibility(manifest, {}, version), undefined, `${version} passes the actual DSH compatibility gate`)
  }
  for (const version of ['0.0.1', '0.3.0-rc.1', '0.3.0']) {
    assert.ok(boot.evaluatePluginCompatibility(manifest, {}, version), `${version} is outside the declared support range`)
  }
}

const require = createRequire(import.meta.url)
const platform = new Map([
  ['@deepseek-ai/cordis', cordis], ['@deepseek-ai/dsh-client-ui-slots', slots],
  ...['react', 'react/jsx-runtime', 'react-dom', 'react-dom/client'].map(id => [id, require(id)]),
])
function browserArtifact(url) {
  let registration
  runInNewContext(readFileSync(url, 'utf8'), {
    window: { __ModuleLoader__: { load(value) { registration = value } } },
    console, setTimeout, clearTimeout, AbortController, AbortSignal, TextEncoder, TextDecoder,
  }, { filename: url.pathname })
  assert.ok(registration?.factory, 'classic script registers its closure factory')
  return registration.factory(id => {
    assert.ok(platform.has(id), `external ${id} belongs to the shared platform`)
    return platform.get(id)
  })
}

const { SlotRegistry } = browserArtifact(new URL(import.meta.resolve('@deepseek-ai/dsh-client-ui-renderer/client')))
const client = browserArtifact(new URL('../lib/client.js', import.meta.url))
const ctx = new cordis.Context()
let mounted = false
let remoteDisposed = false
let dictionaries = 0
let activeLocale = 'zh-CN'
let remoteError = false
const snapshot = { entryCount: 0, entries: [] }
const official = { listPlugins: () => ['official'] }
ctx.provide('remote.pluginManager', official)
ctx.provide('locale', {
  register() { dictionaries++; return () => { dictionaries-- } },
  bind() { return key => key === 'tab' ? 'Plugin Manager' : key },
  getLocale() { return { active: activeLocale } },
})
ctx.provide('remote', {
  async $mount(artifact) {
    assert.ok(artifact.descriptors.every(d => d.namespace === 'dshPluginManager' && d.service === 'dshPluginManager'))
    const namespace = Object.fromEntries(artifact.descriptors.map(d => [d.method, async () => (
      remoteError ? { ok: false, error: { code: 'transport', message: 'offline' } } : { ok: true, value: snapshot }
    )]))
    const dispose = ctx.provide('remote.dshPluginManager', namespace)
    mounted = true
    return () => { remoteDisposed = true; dispose() }
  },
})

try {
  await ctx.plugin(SlotRegistry)
  const fiber = await ctx.plugin(client)
  assert.ok(mounted, 'remote namespace mounted during plugin activation')
  assert.equal(dictionaries, 1)
  assert.equal(ctx.get('remote.pluginManager'), official, 'official remote namespace preserved')
  assert.equal(ctx.get('slots').entries('settings.plugins.tab').length, 0, 'wait for settings slot declaration')

  const declareTab = () => ctx.get('slots').register({
    name: 'root', id: 'test-settings',
    children: { 'settings.plugins.tab': { kind: 'list', scope: 'root' } },
  }, () => null)
  let disposeTab = declareTab()
  const entries = ctx.get('slots').entries('settings.plugins.tab')
  assert.equal(entries.length, 1, 'tab arrives when its owner declares the slot')
  const injected = entries[0].inject()
  assert.equal(await injected.list(), snapshot, 'client unwraps successful RemoteResult')
  assert.equal(injected.localeLang(), 'zh')
  activeLocale = 'de'
  assert.equal(injected.localeLang(), 'en', 'non-Chinese locales use the English catalog')
  remoteError = true
  await assert.rejects(injected.list(), /dshPluginManager.list failed: transport: offline/)

  disposeTab()
  assert.equal(ctx.get('slots').entries('settings.plugins.tab').length, 0, 'owner unload removes the tab')
  disposeTab = declareTab()
  assert.equal(ctx.get('slots').entries('settings.plugins.tab').length, 1, 'owner reload restores one tab')
  await fiber.dispose()
  assert.equal(remoteDisposed, true, 'plugin unload releases remote mount')
  assert.equal(dictionaries, 0, 'plugin unload releases locale dictionaries')
  assert.equal(ctx.get('slots').entries('settings.plugins.tab').length, 0, 'plugin unload removes its tab')
  assert.equal(ctx.get('remote.pluginManager'), official)
  disposeTab()
  console.log('CLIENT REGISTRATION E2E: package graph, official coexistence, late slot, reload, errors and disposal PASS')
} finally {
  await ctx.fiber.dispose()
}
