// 社区目录源冒烟测试：只测纯解析/加载，不访问网络。
import assert from 'node:assert'
import {
  loadCatalogSources,
  parseCatalogSourceConfig,
  parseCatalogSourceDocument,
  SOURCE_DOCUMENT_FORMAT,
} from '../lib/types/catalog-source.js'

let pass = 0

// 1) 配置形态：path 或 url 二选一；坏配置整体不并发加载。
{
  const valid = parseCatalogSourceConfig(JSON.stringify({
    version: 1,
    sources: [
      { id: 'local', path: 'packages.json' },
      { url: 'https://example.com/packages.json' },
    ],
  }))
  assert.deepStrictEqual(valid, {
    specs: [
      { id: 'local', path: 'packages.json', url: undefined },
      { id: undefined, path: undefined, url: 'https://example.com/packages.json' },
    ],
  })
  assert.strictEqual(parseCatalogSourceConfig('not-json').warning?.length > 0, true)
  assert.strictEqual(parseCatalogSourceConfig('[]').warning?.length > 0, true)
  assert.strictEqual(parseCatalogSourceConfig(JSON.stringify({ version: 2, sources: [] })).warning?.length > 0, true)
  assert.strictEqual(parseCatalogSourceConfig(JSON.stringify({
    version: 1,
    sources: [{ path: 'a.json', url: 'https://example.com/a.json' }],
  })).warning?.length > 0, true)
  pass += 1
}

// 2) normalized v1：key/别名命中；非法/缺省分类不进分类筛选语义。
{
  const result = parseCatalogSourceDocument(JSON.stringify({
    format: SOURCE_DOCUMENT_FORMAT,
    version: 1,
    entries: [
      {
        key: '@x/current',
        aliases: ['@x/legacy'],
        name: { zh: '工具', en: 'Tool' },
        description: { zh: '一件事', en: 'One thing' },
        category: 'not-a-category',
      },
      {
        key: '@x/no-category',
        name: { zh: '其它' },
      },
    ],
  }), 'normalized')
  assert.strictEqual(result.warning, undefined)
  const map = new Map(result.entries)
  assert.deepStrictEqual(map.get('@x/current'), {
    name: '工具', nameEn: 'Tool', desc: '一件事', descEn: 'One thing', category: 'other',
  })
  assert.deepStrictEqual(map.get('@x/legacy'), map.get('@x/current'))
  assert.deepStrictEqual(map.get('@x/no-category'), {
    name: '其它', nameEn: undefined, desc: undefined, descEn: undefined, category: undefined,
  })
  pass += 1
}

// 3) legacy：displayName恒为英文；locale=zh 的 summary 进中文槽，不污染英文界面。
{
  const result = parseCatalogSourceDocument(JSON.stringify([
    {
      npm: 'dsh-legacy-zh',
      displayName: 'Legacy',
      locale: 'zh',
      summary: '中文说明',
      categories: ['tools'],
    },
    {
      npm: 'dsh-legacy-en',
      displayName: 'Legacy English',
      summary: 'English text',
      summaryZh: null,
      categories: ['legal'],
    },
  ]), 'legacy')
  assert.strictEqual(result.warning, undefined)
  const map = new Map(result.entries)
  assert.deepStrictEqual(map.get('dsh-legacy-zh'), {
    name: undefined, nameEn: 'Legacy', desc: '中文说明', descEn: undefined, category: 'tool',
  })
  assert.deepStrictEqual(map.get('dsh-legacy-en'), {
    name: undefined, nameEn: 'Legacy English', desc: undefined, descEn: 'English text', category: 'other',
  })
  pass += 1
}

// 4) 多源加载：后声明覆盖前声明；坏源只警告，不影响其它源。
{
  const specs = [
    { id: 'first', path: 'first.json' },
    { id: 'bad', path: 'bad.json' },
    { id: 'last', path: 'last.json' },
  ]
  const files = new Map([
    ['first.json', JSON.stringify({
      format: SOURCE_DOCUMENT_FORMAT,
      version: 1,
      entries: [{ key: '@x/mod', name: { en: 'First' }, category: 'tool' }],
    })],
    ['bad.json', '{not-json'],
    ['last.json', JSON.stringify({
      format: SOURCE_DOCUMENT_FORMAT,
      version: 1,
      entries: [{ key: '@x/mod', name: { en: 'Last' }, category: 'ui' }],
    })],
  ])
  const result = await loadCatalogSources(specs, async spec => {
    const raw = files.get(spec.path ?? '')
    if (raw === undefined) throw new Error('missing source')
    return raw
  })
  assert.deepStrictEqual(result.entries['@x/mod'], {
    name: undefined, nameEn: 'Last', desc: undefined, descEn: undefined, category: 'ui',
  })
  assert.strictEqual(result.warnings.length, 1)
  assert.ok(result.warnings[0].includes('bad'), 'warning names the failed source')
  pass += 1
}

// 5) 同源重复 key/别名整源拒绝，避免隐形覆盖。
{
  const duplicateKey = parseCatalogSourceDocument(JSON.stringify({
    format: SOURCE_DOCUMENT_FORMAT,
    version: 1,
    entries: [
      { key: '@x/a', name: { en: 'A' } },
      { key: '@x/a', name: { en: 'B' } },
    ],
  }), 'duplicate')
  assert.ok(duplicateKey.warning?.includes('@x/a 重复'), 'duplicate key is rejected')

  const duplicateAlias = parseCatalogSourceDocument(JSON.stringify({
    format: SOURCE_DOCUMENT_FORMAT,
    version: 1,
    entries: [
      { key: '@x/a', name: { en: 'A' } },
      { key: '@x/b', aliases: ['@x/a'], name: { en: 'B' } },
    ],
  }), 'duplicate-alias')
  assert.ok(duplicateAlias.warning?.includes('别名 @x/a'), 'duplicate alias is rejected')
  pass += 1
}

// 6) legacy displayName / displayNameZh 长度也不裸入 UI。
{
  const tooLong = parseCatalogSourceDocument(JSON.stringify([{
    npm: '@x/long',
    displayName: 'a'.repeat(201),
    summary: 'One text',
  }]), 'legacy-length')
  assert.ok(tooLong.warning?.includes('名称或说明'), 'overlong legacy name is rejected')
  pass += 1
}

console.log(`CATALOG SOURCE SMOKE: ${pass}/6 GROUPS PASS`)
