// Real Gateway dependencies differ between the supported DSH generations.
import { TypertGatewayService } from '@deepseek-ai/dsh-api-gateway'

export const usesRemoteAccess = TypertGatewayService.inject.includes('remoteAccess')

export async function installRemoteAccess(ctx) {
  if (usesRemoteAccess) {
    const { RemoteAccessService } = await import('@deepseek-ai/dsh-api-remote-access')
    await ctx.plugin(RemoteAccessService)
  }
}

export function testPeer(ctx, principal = { kind: 'owner' }) {
  const controller = new AbortController()
  return {
    id: 'plugin-manager-test-peer', ctx, principal,
    signal: controller.signal, interactions: 'none',
    async dispose() { controller.abort() },
  }
}
