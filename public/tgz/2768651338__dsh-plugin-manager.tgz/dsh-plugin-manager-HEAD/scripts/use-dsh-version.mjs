// Select a known SDK set in an isolated checkout before `pnpm install`.
import { readFileSync, writeFileSync } from 'node:fs'

const sets = {
  '0.1.5-rc.3': { cordis: '4.0.2', group: '1.0.2', include: '1.0.7', loader: '1.0.3' },
  '0.2.0-rc.2': { cordis: '4.0.4', group: '1.0.4', include: '1.0.9', loader: '1.0.5' },
  '0.2.1-rc.2': { cordis: '4.0.5', group: '1.0.5', include: '1.0.10', loader: '1.0.6' },
}
const version = process.argv[2]
if (!Object.hasOwn(sets, version)) throw new Error(`Choose a supported DSH SDK: ${Object.keys(sets).join(', ')}`)
const path = new URL('../package.json', import.meta.url)
const manifest = JSON.parse(readFileSync(path, 'utf8'))
const deps = manifest.devDependencies
for (const name of Object.keys(deps)) {
  if (name.startsWith('@deepseek-ai/dsh-')) deps[name] = version
}
if (version !== '0.2.1-rc.2') delete deps['@deepseek-ai/dsh-api-remote-access']
else deps['@deepseek-ai/dsh-api-remote-access'] = version
const pins = sets[version]
deps['@deepseek-ai/cordis'] = pins.cordis
for (const name of ['group', 'include', 'loader']) deps[`@deepseek-ai/cordis-plugin-${name}`] = pins[name]
writeFileSync(path, JSON.stringify(manifest, null, 2) + '\n')
console.log(`Selected DSH ${version}; run pnpm install --no-frozen-lockfile in this checkout`)
