/**
 * 浏览器侧“平台模块”清单（DSH 0.1.x / 0.2.x 共享的交集）。
 * 这些模块由 shell 的冻结模块表共享，客户端 bundle 必须 external 化，
 * 不能在包内重复打包（否则跨插件模块身份漂移）。
 * 0.2.1 新增的 zod 仍私有打包，以便在没有该平台键的旧宿主上加载。
 * @module dsh-plugin-manager/platform
 */

/** shell 共享进冻结模块表的模块说明符。 */
export const PLATFORM_MODULES: readonly string[] = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-store',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-dockkit',
]
