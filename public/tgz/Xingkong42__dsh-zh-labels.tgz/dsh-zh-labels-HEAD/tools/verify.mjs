#!/usr/bin/env node
/**
 * dsh-zh-labels 规则验证脚本。
 *
 * 用法：
 *   node tools/verify.mjs            # 检查已安装 DSH 的 client 模块与规则匹配
 *   node tools/verify.mjs --dry-run  # 只报告命中率，不修改文件
 *   node tools/verify.mjs --apply    # 实际应用补丁（与插件 apply 相同逻辑）
 *
 * 用于发布前自检，以及升级 DSH 后排查失效标签。
 */
import { promises as fs, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir } from 'node:os';

const SRC = join(dirname(fileURLToPath(import.meta.url)), '..', 'lib', 'index.js');

// 从插件源码提取 PATCHES（直接导入会执行 apply，这里只取规则表）
const src = await fs.readFile(SRC, 'utf8');
const start = src.indexOf('const PATCHES');
const end = src.indexOf('function candidateDshRoots');
const patchSrc = src.slice(start, end).replace('const PATCHES =', 'const PATCHES =');
const PATCHES = eval(patchSrc + '\nPATCHES');

const mode = process.argv.includes('--apply') ? 'apply' : 'dry';
const roots = [
  process.env.APPDATA ? join(process.env.APPDATA, 'npm', 'node_modules', '@deepseek-ai', 'dsh') : null,
  join(homedir(), '.dsh', 'profiles', 'node_modules', '@deepseek-ai', 'dsh'),
  join(homedir(), '.dsh', 'profiles', 'web', 'node_modules', '@deepseek-ai', 'dsh'),
].filter((p) => p !== null);

let totalRules = 0;
let totalHits = 0;
let changedFiles = 0;

for (const patch of PATCHES) {
  const seen = new Set();
  for (const root of roots) {
    const file = join(root, 'node_modules', '@deepseek-ai', patch.package, 'lib', 'client.js');
    if (seen.has(file) || !existsSync(file)) continue;
    seen.add(file);
    let text;
    try {
      text = await fs.readFile(file, 'utf8');
    } catch {
      continue;
    }
    const missing = patch.rules.filter(([from]) => !text.includes(from));
    totalRules += patch.rules.length;
    totalHits += patch.rules.length - missing.length;

    if (mode === 'apply' && missing.length < patch.rules.length) {
      let next = text;
      for (const [from, to] of patch.rules) {
        if (next.includes(from)) next = next.split(from).join(to);
      }
      if (next !== text) {
        await fs.writeFile(file, next, 'utf8');
        changedFiles += 1;
        console.log(`✓ 已修补 ${patch.package}`);
      }
    }

    if (missing.length > 0) {
      console.log(`[${patch.package}] ${missing.length}/${patch.rules.length} 条规则未命中:`);
      missing.slice(0, 10).forEach(([m]) => console.log(`  ✗ ${m.slice(0, 90)}`));
    } else {
      console.log(`[${patch.package}] ${patch.rules.length}/${patch.rules.length} 命中`);
    }
  }
}

const pct = ((totalHits / totalRules) * 100).toFixed(1);
console.log(`\n总计: ${totalHits}/${totalRules} (${pct}%)`);
if (mode === 'apply') console.log(`已修改文件数: ${changedFiles}`);
if (pct !== '100.0') process.exitCode = 1;
