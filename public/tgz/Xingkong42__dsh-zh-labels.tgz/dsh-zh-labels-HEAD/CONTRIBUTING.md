# 贡献指南

欢迎为 `dsh-zh-labels` 贡献代码！

## 如何添加/更新标签规则

所有翻译规则集中在 `lib/index.js` 的 `PATCHES` 数组中：

```js
{
  package: 'dsh-client-ui-tool',
  rules: [
    // [英文原文（精确匹配源码片段）, 中文译文]
    ['search: "Search"', 'search: "搜索"'],
  ],
},
```

### 添加规则注意事项

1. **精确匹配**：英文原文必须与 `lib/client.js` 中的实际源码片段完全一致
   （含引号、缩进上下文），避免误伤其他代码
2. **幂等**：文件已含中文时规则自然不命中，无需额外处理
3. **内部契约值**：如 `"Tool call only"`、`"No output"` 是程序逻辑比较值，
   **不要翻译**（或只改显示端、成对同步修改）
4. **分组标题**：如 `Step N`、`Message` 同时用于内部匹配，翻译时必须
   同步修改生成端与匹配端

### 验证

```sh
# 语法检查
node --check lib/index.js

# 规则命中率（dry-run）
node tools/verify.mjs --dry-run

# 实际应用
node tools/verify.mjs --apply
```

## 提交规范

- 提交信息用英文，遵循 Conventional Commits（`feat:` / `fix:` / `docs:` / `chore:`）
- 每个逻辑变更一个提交
- 提交前运行 `node --check lib/index.js` 确保语法正确

## 发布流程

1. 修改代码并推送
2. 创建 Git tag：`git tag v1.0.0 && git push origin v1.0.0`
3. 在 GitHub Releases 页面创建 release
4. （可选）提交收录 PR 到 [awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin)
