# Changelog

## [1.1.0] — 2026-08-22

### Added

- GitHub Actions CI：push/PR 自动验证插件语法与规则表健全性
- 架构文档（docs/architecture.md）：补丁引擎设计与"为何不用 i18n"说明
- 使用指南（docs/usage.md / docs/usage.en.md）：安装、验证、升级、排障
- 贡献指南（CONTRIBUTING.md）：规则维护与提交规范

### Fixed

- 补全轨迹时间轴 LaneLabels 中遗漏的 "Tools" 标签（输入/模型/工具）
- 修正规则表：Hierarchy/Compacted 按新版三目表达式匹配
- 补全会话运行状态提示 "Deep diving..."（深度思考中…）

## [1.0.0] — 2026-08-21

### Added

- 启动自动补丁引擎：每次 DSH 启动重新应用中文标签补丁，升级后自动恢复
- 316 条替换规则，覆盖 5 个 client 模块：
  - `dsh-client-ui-tool`：工具行标题（Read/Write/Bash/Pwsh/Inspect…）18 条
  - `dsh-client-ui-conversation`：思考折叠标题（Think）1 条
  - `dsh-client-ui-trajectory`：轨迹面板全部标签 137 条
  - `dsh-client-ui-sidebar`：品牌名 1 条
  - `dsh-client-ui-skill`：技能行标题 1 条
- 多部署根探测：npm 全局 / profile 共享 / profile web 三个 DSH 安装点
- 幂等：已含中文则跳过，重复运行无副作用
- 容错：单条规则失败不影响其余，升级后字符串变化自动跳过
