# Usage Guide

## Install

### Option 1: DSH plugin command (recommended)

```sh
dsh plugin --profile web add github:Xingkong42/dsh-zh-labels
```

### Option 2: Manual (zero dependencies, stdlib only)

```sh
# 1. Clone into the profile's node_modules
cd ~/.dsh/profiles/web/node_modules
git clone https://github.com/Xingkong42/dsh-zh-labels.git

# 2. Edit ~/.dsh/profiles/web/package.json
#    Append "dsh-zh-labels" to dsh.profile.bundles

# 3. Restart DSH
dsh web
```

## Verify

### Method 1: Browser

Restart DSH, open the Web UI and hard-refresh (**Ctrl+F5**). Tool card titles
should show Chinese (读取 / 写入 / 终端 / 搜索 / 工具调用 / 思考…).

### Method 2: HTTP

```sh
curl -s http://127.0.0.1:3080/plugins/@deepseek-ai%2Fdsh-client-ui-tool/client.js | grep -o "搜索" | head -1
```

### Method 3: Verification script

```sh
# Dry run — report rule hit rate without modifying files
node tools/verify.mjs --dry-run

# Apply the patch (same as plugin startup behavior)
node tools/verify.mjs --apply
```

Output `总计: N/N (100.0%)` means all rules match the installed version.

## After a DSH Upgrade

Upgrades overwrite the client module files in `node_modules`, but the plugin
itself is untouched. On the next DSH start the plugin re-applies the patch and
the Chinese labels come back automatically.

> If some labels stay English after an upgrade, the upstream rewrote those
> strings. Run `node tools/verify.mjs --dry-run` to see which rules missed,
> update `PATCHES` in `lib/index.js`, and restart.

## Uninstall

```sh
dsh plugin --profile web remove dsh-zh-labels
# or edit package.json to drop "dsh-zh-labels", then restart
```

> Uninstalling does **not** revert the client module files (they are already
> Chinese). To restore, run `dsh plugin --profile web install`.

## Troubleshooting

### Q: pnpm fails with minimumReleaseAge?
A: pnpm 11 supply-chain policy. Add `minimumReleaseAge: 0` to the profile's
`pnpm-workspace.yaml`.

### Q: Network timeouts during install?
A: Create `.npmrc` in the profile with `registry=https://registry.npmmirror.com/`
for a faster mirror.

### Q: Why not i18n?
A: These labels are upstream "design literals" that deliberately bypass i18n;
a client plugin cannot override module-internal constants, so file-level
patching is the only route. See [docs/architecture.md](docs/architecture.md).
