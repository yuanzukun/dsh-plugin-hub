# 架构说明

`dsh-zh-labels` 是一个 **host 端补丁引擎**：DSH 启动时，自动把部署安装的
client 模块中硬编码的英文 UI 标签替换为中文。

## 为什么需要这个插件？

DSH 的 Web 界面中，工具行标题、思考折叠标题、轨迹面板标签等文本**硬编码**在
client 模块的 `lib/client.js` 里（这些是 "design literals"，不走 i18n 字典）。
直接修改 `node_modules` 里的文件，会在升级 DSH 时被覆盖。

本插件把这些修改**自动化、幂等化**：每次启动重新应用，升级后自动恢复。

## 补丁引擎结构

```
┌─────────────────────────────────────────────┐
│ dsh-zh-labels (host plugin)                 │
│                                             │
│  apply(ctx)                                 │
│    ├─ candidateDshRoots()                   │
│    │   └─ 枚举 DSH 部署根（npm 全局/profile）  │
│    └─ PATCHES                               │
│        ├─ dsh-client-ui-tool        (18条)  │
│        ├─ dsh-client-ui-conversation (1条)  │
│        ├─ dsh-client-ui-trajectory (137条)  │
│        ├─ dsh-client-ui-sidebar      (1条)  │
│        └─ dsh-client-ui-skill        (1条)  │
│            └─ applyRulesToFile()            │
│                └─ 逐条 split/join 替换       │
└─────────────────────────────────────────────┘
```

## 核心设计原则

### 1. 幂等（Idempotent）

每条规则是 `[英文原文, 中文译文]` 的精确匹配。文件已含中文（或不再含英文原文）
时该条规则不命中、不写回。重复运行无副作用。

```js
// 规则示例：精确匹配源码片段，避免误伤
['search: "Search"', 'search: "搜索"'],
['children: "IN"', 'children: "输入"'],
```

### 2. 容错（Fault-tolerant）

每个文件的规则逐条独立处理，单条失败（如升级后字符串变化）不影响其余。
某个部署根不存在时静默跳过。

### 3. 多部署根（Multi-root）

DSH 可能安装在多个位置（npm 全局、profile 共享、profile web），插件逐一探测
并全部修补，确保实际运行的实例一定被覆盖。

### 4. 编码安全

文件按 **UTF-8 无 BOM** 读写，不破坏源文件的编码和换行符。

## 为什么用字符串替换而不是 i18n？

理论上更好的方案是走 i18n 字典（`ctx.locale.register`）。但这些标签被上游注释为
"design literals, not translatable copy"——**刻意不走 i18n**。client 插件无法从
外部覆盖模块内部的常量表，所以只能从文件层修补。

## 内部逻辑值处理

有些字符串是**程序内部契约**，不能翻译（改了会破坏功能）：

| 字符串 | 用途 |
|---|---|
| `"Tool call only"` | `isToolCallOnly()` 的数据比较值 |
| `"No output"` | 结果比较值 |
| `Step N` / `Message` | 轨迹分组标题（生成与匹配成对，需同步翻译） |

插件对这类字符串**只改显示端**，或**成对同步修改**，确保逻辑不被破坏。

## 维护

- **规则失配**：升级 DSH 后某些标签失效 → 更新 `PATCHES` 中对应规则（英文原文
  可能被上游改写），重启 DSH 生效
- **验证**：`node tools/verify.mjs --dry-run` 检查命中率，`--apply` 实际修补
