# 使用指南

## 安装

### 方式一：DSH 插件命令（推荐）

```sh
dsh plugin --profile web add github:Xingkong42/dsh-zh-labels
```

### 方式二：手动安装（无依赖，纯标准库）

```sh
# 1. 克隆到 profile 的 node_modules
cd ~/.dsh/profiles/web/node_modules
git clone https://github.com/Xingkong42/dsh-zh-labels.git

# 2. 编辑 ~/.dsh/profiles/web/package.json
#    在 dsh.profile.bundles 列表末尾追加 "dsh-zh-labels"

# 3. 重启 DSH
dsh web
```

## 验证是否生效

### 方法 1：浏览器直接看

重启 DSH 后，打开 Web 界面按 **Ctrl+F5** 强制刷新，工具卡片标题应显示为中文
（读取 / 写入 / 终端 / 搜索 / 工具调用 / 思考…）。

### 方法 2：HTTP 接口检查

```sh
# 返回的 client 模块应包含中文字符
curl -s http://127.0.0.1:3080/plugins/@deepseek-ai%2Fdsh-client-ui-tool/client.js | grep -o "搜索" | head -1
```

### 方法 3：规则验证脚本

```sh
# 检查规则与当前 DSH 版本的匹配率（不修改文件）
node tools/verify.mjs --dry-run

# 实际应用补丁（与插件启动时行为一致）
node tools/verify.mjs --apply
```

输出 `总计: N/N (100.0%)` 表示规则与当前版本完全匹配。

## 升级 DSH 后

升级会覆盖 `node_modules` 中的 client 模块文件，但**插件本身不受影响**。
重启 DSH 时插件自动重新应用补丁，中文标签自动恢复。

> 如果升级后某些标签仍是英文，说明该标签的英文字符串在新版本中被上游改写，
> 运行 `node tools/verify.mjs --dry-run` 查看哪些规则失配，更新
> `lib/index.js` 中的 `PATCHES` 后重启即可。

## 卸载

```sh
# 从 bundles 列表移除
dsh plugin --profile web remove dsh-zh-labels
# 或手动编辑 package.json，删除 "dsh-zh-labels" 条目后重启
```

> 卸载后**不会**还原 client 模块文件（它们已是中文）。如需还原，
> 执行 `dsh plugin --profile web install` 重新安装官方模块即可。

## 常见问题

### Q: 安装时 pnpm 报 minimumReleaseAge 错误？
A: pnpm 11 的 supply-chain 策略。在 profile 的 `pnpm-workspace.yaml` 中加入
`minimumReleaseAge: 0` 即可关闭。

### Q: 安装时网络超时？
A: 为 profile 创建 `.npmrc`，内容 `registry=https://registry.npmmirror.com/`
可切换到国内镜像加速。

### Q: 为什么不用 i18n 方案？
A: 这些标签是上游刻意不走 i18n 的 "design literals"，client 插件无法覆盖模块
内部常量，只能文件层修补。详见 [docs/architecture.md](docs/architecture.md)。
