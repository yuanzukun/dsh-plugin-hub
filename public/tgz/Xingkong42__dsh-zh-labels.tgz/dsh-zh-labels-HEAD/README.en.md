# dsh-zh-labels — Persistent Chinese UI Labels for DSH

[![license](https://img.shields.io/github/license/Xingkong42/dsh-zh-labels)](LICENSE)

> [中文](README.md) | English

**Keep the DeepSeek Harness Web UI in Chinese — even after upgrades.**

Tool row titles (Read / Write / Bash / Pwsh…), the reasoning disclosure title (Think),
trajectory panel labels, and the sidebar brand name are hard-coded in the client
modules (`lib/client.js`). Editing files inside `node_modules` directly gets
overwritten on every DSH upgrade, silently reverting the UI to English.

This plugin **re-applies the patch automatically on every DSH start**: it scans the
installed client module files and replaces the known English labels with their
Chinese translations. After an upgrade overwrites the files, the next start
restores them — no manual intervention needed.

## Features

- **Auto-patch on startup**: once mounted, every DSH start re-applies the patch
- **316 replacement rules**: tool titles, Think, full trajectory panel, sidebar, skill row
- **Multi-root detection**: scans npm global, profile-shared, and profile-web DSH installs
- **Idempotent**: skips files that already contain Chinese — safe to re-run
- **Fault-tolerant**: a failing rule never blocks the others; changed strings are skipped
- **UTF-8 safe**: reads/writes without BOM, preserving source encoding

## Install

### Option 1: DSH plugin install (recommended)

```sh
dsh plugin --profile web add github:Xingkong42/dsh-zh-labels
```

### Option 2: Manual

1. Clone or copy the repo into the profile's node_modules:

   ```sh
   cd ~/.dsh/profiles/web/node_modules
   git clone https://github.com/Xingkong42/dsh-zh-labels.git
   ```

2. Edit `~/.dsh/profiles/web/package.json` — append `"dsh-zh-labels"` to `dsh.profile.bundles`.

3. Restart DSH (`dsh web`). The plugin applies the patch on startup.

## Verify

After restart, open the Web UI and hard-refresh (Ctrl+F5) to see the Chinese labels.
Or check over HTTP:

```sh
curl -s http://127.0.0.1:3080/plugins/@deepseek-ai%2Fdsh-client-ui-tool/client.js | grep -c "搜索"
```

A non-zero count means the patch is live.

## Updating rules

If a label stops being translated after an upgrade, its English string changed
shape in that version. Update the `PATCHES` rules in `lib/index.js` and restart DSH.
Unmatched rules are skipped gracefully, so the rest of the UI stays translated.

## Layout

```
dsh-zh-labels/
├── lib/
│   └── index.js          # patch engine (316 rules + install-root scan)
├── cordis.patch.yml      # bundle patch entry (composition mount)
├── package.json          # plugin manifest
└── tools/
    └── verify.mjs        # rule-hit verification script
```

## License

[MIT](LICENSE)
