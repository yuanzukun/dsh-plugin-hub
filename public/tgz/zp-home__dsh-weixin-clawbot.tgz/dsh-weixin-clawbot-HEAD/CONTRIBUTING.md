# Contributing

## Development

Requirements: Node.js 22.19 or later and a compatible DSH source checkout for
Host integration testing.

```bash
npm ci --legacy-peer-deps
npm run check
npm test
npm pack
```

Keep the Bundle Host-only. Do not add a browser client merely to expose a
setting that can be expressed safely as a Weixin command. New remote actions
must preserve sender authorization, per-user Session isolation, and explicit
confirmation for `danger-full-access`.

## Pull requests

- Add focused tests for state migration, protocol behavior, and command parsing.
- Test both a fresh state and a state created by version 0.1.0.
- Confirm that `/cancel` and `/steer` do not enter the ordinary per-user queue.
- Do not commit QR codes, credentials, state files, local logs, or packaged
  tarballs.

Changes under `skills/` must remain portable Agent Skills and must not duplicate
the Bundle runtime or contain pairing artifacts. Verify discovery with
`npx skills add . --list` and preview registry metadata with
`clawhub skill publish ./skills/dsh-weixin-clawbot --dry-run`.
