# Changelog

All notable changes to this project are documented here.

## 0.3.0 - 2026-08-22

- Add immediate task acknowledgements, periodic progress, `/task`, `/queue`,
  `/doctor`, `/search`, and `/archive-all confirm`.
- Persist outbound replies before sending and retry failures with bounded
  exponential backoff across Host restarts.
- Add owner-controlled `/users`, `/invite`, `/pair`, `/revoke`, and `/audit`
  authorization management with bounded persistent audit history.
- Integrate the DSH `0.1.1-rc.2` `approval/request` waterfall for phone-owned
  Agents through one-time `/approve` and `/reject` codes while delegating
  borrowed Web/desktop Agents to their original surface.
- Add separate Chinese and English command, architecture, and security docs.
- Explicitly exclude Windows startup entries and system-service installation.

## 0.2.2 - 2026-08-22

- Add the official `dsh-plugin` ecosystem keyword and repository-facing badge.
- Document direct GitHub installation and explicit profile removal.
- Replace wildcard DSH peer declarations with ranges that include the verified
  `0.1.0-rc.8` and `0.1.1-rc.2` prerelease lines.
- Add tests for the discoverable, installable DSH Bundle package contract.

## 0.2.1 - 2026-08-22

- Add a portable `dsh-weixin-clawbot` Agent Skill for skills.sh, ClawHub,
  OpenClaw, Codex, Claude Code, Cursor, and other Agent Skills clients.
- Add strict Skill metadata, security, reference, and marketplace dry-run
  validation without changing the DSH Bundle runtime.
- Add a tag-driven GitHub Release workflow that verifies and attaches the
  installable `.tgz` Bundle.
- Expand the English documentation to match the complete Chinese guide.
- Update `yaml` to 2.9.0 to address `GHSA-48c2-rrv3-qjmp`.

## 0.2.0 - 2026-08-21

- Add per-Weixin-user persistent multi-session management.
- Add `/sessions`, `/use`, `/new`, `/rename`, and `/archive`.
- Add immediate `/cancel` and `/steer` fast paths that bypass the normal turn queue.
- Add model, Preset, permission, workspace, status, and help commands.
- Forward unknown slash commands to the native DSH command registry.
- Reuse a live Agent when Web or desktop DSH already owns the Session.
- Migrate the original version-1 single-session state in place.
- Verify loading on DSH `0.1.1-rc.2` while retaining `0.1.0-rc.8` compatibility.

## 0.1.0 - 2026-08-21

- Initial Tencent iLink polling and text reply bridge.
- Persistent DSH Session per authorized Weixin user.
- QR pairing CLI and DSH credential-store integration.
