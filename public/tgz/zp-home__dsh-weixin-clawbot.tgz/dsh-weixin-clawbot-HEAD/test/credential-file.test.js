import assert from 'node:assert/strict'
import { mkdtemp, readFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'
import { hasCredential, setCredential, unsetCredential } from '../src/credential-file.js'

test('credential writer preserves unrelated YAML entries', async () => {
  const dshHome = await mkdtemp(join(tmpdir(), 'dsh-weixin-credentials-'))
  await setCredential('EXISTING_TEST_KEY', 'first', { dshHome })
  await setCredential('DSH_WEIXIN_TEST_TOKEN', 'second', { dshHome })
  assert.equal(await hasCredential('DSH_WEIXIN_TEST_TOKEN', { dshHome }), true)
  await unsetCredential('DSH_WEIXIN_TEST_TOKEN', { dshHome })
  assert.equal(await hasCredential('DSH_WEIXIN_TEST_TOKEN', { dshHome }), false)
  const source = await readFile(join(dshHome, '.credentials.yaml'), 'utf8')
  assert.match(source, /EXISTING_TEST_KEY: first/)
  assert.doesNotMatch(source, /second/)
})
