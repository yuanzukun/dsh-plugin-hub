#!/usr/bin/env node

import { createInterface } from 'node:readline/promises'
import { stdin, stdout } from 'node:process'
import { mkdir } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import QRCode from 'qrcode'
import { DEFAULT_BASE_URL, IlinkClient } from './protocol.js'
import { StateStore } from './state.js'
import {
  defaultDshHome,
  hasCredential,
  setCredential,
  unsetCredential,
} from './credential-file.js'

const DEFAULT_CREDENTIAL_REF = 'DSH_WEIXIN_BOT_TOKEN'

function parseArgs(argv) {
  const result = { command: argv[0] || 'help' }
  for (let index = 1; index < argv.length; index++) {
    const arg = argv[index]
    if (arg === '--state-dir') result.stateDir = argv[++index]
    else if (arg === '--credential-ref') result.credentialRef = argv[++index]
    else if (arg === '--dsh-home') result.dshHome = argv[++index]
    else if (arg === '--agent-cwd') result.agentCwd = argv[++index]
    else if (arg === '--agent-preset') result.agentPreset = argv[++index]
    else if (arg === '--permission-preset') result.permissionPreset = argv[++index]
    else if (arg === '--qr-file') result.qrFile = argv[++index]
    else if (arg === '--help' || arg === '-h') result.command = 'help'
    else throw new Error(`unknown option: ${arg}`)
  }
  if (!result.stateDir) result.stateDir = join(defaultDshHome(result.dshHome ? { ...process.env, DSH_HOME: result.dshHome } : process.env), 'dsh-weixin')
  result.stateDir = resolve(result.stateDir)
  result.dshHome = result.dshHome ? resolve(result.dshHome) : defaultDshHome()
  result.credentialRef ||= DEFAULT_CREDENTIAL_REF
  result.agentCwd = resolve(result.agentCwd || process.cwd())
  result.agentPreset ||= 'standard'
  result.permissionPreset ||= 'workspace-write'
  result.qrFile = resolve(result.qrFile || join(result.stateDir, 'pairing-qr.png'))
  if (!['workspace-write', 'danger-full-access'].includes(result.permissionPreset)) {
    throw new Error('--permission-preset must be workspace-write or danger-full-access')
  }
  return result
}

function usage() {
  stdout.write([
    'DSH Weixin connector',
    '',
    'Usage:',
    '  dsh-weixin setup [--agent-cwd PATH] [--permission-preset PRESET] [--qr-file PATH]',
    '  dsh-weixin status [--state-dir PATH] [--credential-ref NAME] [--dsh-home PATH]',
    '  dsh-weixin disconnect [--state-dir PATH] [--credential-ref NAME] [--dsh-home PATH]',
    '',
  ].join('\n'))
}

async function promptVerifyCode(reader, prompt) {
  while (true) {
    const code = (await reader.question(prompt)).trim()
    if (/^\d+$/.test(code)) return code
    stdout.write('配对码只能包含数字。\n')
  }
}

async function showQr(qr, qrFile) {
  if (!qr?.qrcode || !qr?.qrcode_img_content) throw new Error('微信网关没有返回有效二维码')
  await mkdir(dirname(qrFile), { recursive: true })
  await QRCode.toFile(qrFile, qr.qrcode_img_content, { width: 512, margin: 2 })
  stdout.write(await QRCode.toString(qr.qrcode_img_content, { type: 'terminal', small: true }))
  stdout.write(`\n请用手机微信扫描二维码。\n二维码图片：${qrFile}\n备用链接：\n${qr.qrcode_img_content}\n\n`)
}

async function pair(options) {
  const client = new IlinkClient()
  const store = new StateStore(options.stateDir)
  let qr = await client.getQrCode()
  await showQr(qr, options.qrFile)

  const reader = createInterface({ input: stdin, output: stdout })
  let verifyCode
  let pollingBaseUrl = DEFAULT_BASE_URL
  try {
    for (;;) {
      const response = await client.pollQrStatus({
        baseUrl: pollingBaseUrl,
        qrcode: qr.qrcode,
        verifyCode,
      }).catch(error => {
        stdout.write(`等待扫码时网络波动：${error instanceof Error ? error.message : String(error)}\n`)
        return { status: 'wait' }
      })
      switch (response.status) {
        case 'wait':
          break
        case 'scaned':
          verifyCode = undefined
          stdout.write('已扫码，正在确认...\n')
          break
        case 'need_verifycode':
          verifyCode = await promptVerifyCode(reader, '请输入手机微信显示的数字配对码：')
          continue
        case 'verify_code_blocked':
          throw new Error('配对码多次输入错误，请稍后重新运行 setup')
        case 'scaned_but_redirect':
          if (response.redirect_host) pollingBaseUrl = `https://${response.redirect_host}`
          break
        case 'binded_redirect':
          throw new Error('该 ClawBot 已绑定；如本机没有凭据，请先在原绑定端解除后重新配对')
        case 'expired':
          stdout.write('二维码已过期，正在刷新...\n')
          qr = await client.getQrCode()
          verifyCode = undefined
          pollingBaseUrl = DEFAULT_BASE_URL
          await showQr(qr, options.qrFile)
          break
        case 'confirmed': {
          if (!response.bot_token || !response.ilink_bot_id || !response.ilink_user_id) {
            throw new Error('登录已确认，但微信网关缺少 bot_token、ilink_bot_id 或 ilink_user_id')
          }
          const credentialFile = await setCredential(options.credentialRef, response.bot_token, { dshHome: options.dshHome })
          const state = await store.load()
          state.account = {
            accountId: response.ilink_bot_id,
            userId: response.ilink_user_id,
            baseUrl: response.baseurl || DEFAULT_BASE_URL,
            connectedAt: new Date().toISOString(),
          }
          state.syncBuf = ''
          state.processed = []
          state.peers = {}
          state.settings.allowedUsers = [response.ilink_user_id]
          state.settings.ownerUserId = response.ilink_user_id
          state.settings.agentCwd = options.agentCwd
          state.settings.agentPreset = options.agentPreset
          state.settings.permissionPreset = options.permissionPreset
          await store.save(state)
          stdout.write(`\n连接成功。\n状态目录：${options.stateDir}\n凭据文件：${credentialFile}\n允许用户：${response.ilink_user_id}\n`)
          return
        }
        default:
          stdout.write(`微信返回未知扫码状态：${String(response.status)}\n`)
      }
      await new Promise(resolveDelay => setTimeout(resolveDelay, 1000))
    }
  } finally {
    reader.close()
  }
}

async function status(options) {
  const state = await new StateStore(options.stateDir).load()
  const configured = await hasCredential(options.credentialRef, { dshHome: options.dshHome })
  stdout.write([
    `配对状态：${state.account?.accountId ? '已配对' : '未配对'}`,
    `凭据状态：${configured ? '已配置' : '未配置'}`,
    `账号：${state.account?.accountId ?? '-'}`,
    `允许用户：${state.settings.allowedUsers.length}`,
    `会话数：${Object.keys(state.peers).length}`,
    `状态目录：${options.stateDir}`,
    '',
  ].join('\n'))
}

async function disconnect(options) {
  const store = new StateStore(options.stateDir)
  const state = await store.load()
  state.account = null
  state.syncBuf = ''
  state.processed = []
  state.peers = {}
  state.settings.allowedUsers = []
  await store.save(state)
  await unsetCredential(options.credentialRef, { dshHome: options.dshHome })
  stdout.write('本机 DSH Weixin 配对信息和令牌已清除。\n')
}

async function main() {
  const options = parseArgs(process.argv.slice(2))
  if (options.command === 'help') return usage()
  if (options.command === 'setup') return pair(options)
  if (options.command === 'status') return status(options)
  if (options.command === 'disconnect') return disconnect(options)
  throw new Error(`unknown command: ${options.command}`)
}

main().catch(error => {
  process.stderr.write(`dsh-weixin: ${error instanceof Error ? error.message : String(error)}\n`)
  process.exitCode = 1
})
