import { randomUUID } from 'node:crypto'
import { homedir } from 'node:os'
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import { Document, parseDocument } from 'yaml'

const REF_PATTERN = /^[A-Za-z_][A-Za-z0-9_]*$/

export function defaultDshHome(env = process.env) {
  return resolve(env.DSH_HOME || join(homedir(), '.dsh'))
}

export function credentialsPath(dshHome = defaultDshHome()) {
  return join(dshHome, '.credentials.yaml')
}

function validateRef(ref) {
  if (!REF_PATTERN.test(ref)) throw new Error(`invalid credential reference: ${ref}`)
}

async function readDocument(filename) {
  let source
  try {
    source = await readFile(filename, 'utf8')
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
  }
  const document = source === undefined ? new Document({}) : parseDocument(source, { uniqueKeys: true })
  if (document.errors.length > 0) {
    throw new Error(`credentials file is invalid: ${filename}`)
  }
  const value = document.toJS() ?? {}
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`credentials file must contain a YAML mapping: ${filename}`)
  }
  return document
}

async function commit(filename, document) {
  await mkdir(dirname(filename), { recursive: true, mode: 0o700 })
  const temporary = `${filename}.${randomUUID()}.tmp`
  await writeFile(temporary, document.toString(), { encoding: 'utf8', mode: 0o600 })
  await rename(temporary, filename)
}

export async function setCredential(ref, value, options = {}) {
  validateRef(ref)
  if (typeof value !== 'string' || !value.trim()) throw new Error('credential value is empty')
  if (process.env[ref]) {
    throw new Error(`${ref} is set in the process environment; remove it before pairing so the new token is not shadowed`)
  }
  const filename = options.filename ?? credentialsPath(options.dshHome)
  const document = await readDocument(filename)
  document.setIn([ref], value.trim())
  await commit(filename, document)
  return filename
}

export async function unsetCredential(ref, options = {}) {
  validateRef(ref)
  if (process.env[ref]) {
    throw new Error(`${ref} is set in the process environment and cannot be removed by this command`)
  }
  const filename = options.filename ?? credentialsPath(options.dshHome)
  const document = await readDocument(filename)
  document.deleteIn([ref])
  await commit(filename, document)
  return filename
}

export async function hasCredential(ref, options = {}) {
  validateRef(ref)
  if (process.env[ref]) return true
  const filename = options.filename ?? credentialsPath(options.dshHome)
  try {
    const document = await readDocument(filename)
    const value = document.toJS()?.[ref]
    return typeof value === 'string' && value.length > 0
  } catch (error) {
    if (error?.code === 'ENOENT') return false
    throw error
  }
}
