# 更新日志 / Changelog
## v0.6 系列 —— 轻量化设计 / Lightweight
### v0.6.7（2026-10-16）— 可自定义数值 / Configurable numbers

这版做两件事：**面板从"只能开关"扩到"能改数值"**，以及把文案里一直说"去配置里改"的那些阈值做成控件。

#### 新增

- **「每分钟进模型上限」（入站，**默认关**、数值默认 5）**：一个开关 + 一个数字。
  `chatTurnLimitEnabled`（布尔，默认 `false`）关着时**完全不限流**——升级上来的忙群行为与之前一模一样；
  打开后按 `chatTurnsPerMinute`（1–10，默认 5）生效：每个会话**每分钟最多让 N 条消息进模型**，
  超出的**丢弃不排队**，并写一条 `stage: ratelimit` 的 trace（原因里带"已有几个回合 / 上限多少 / 去哪个面板改"），
  被丢条数进快照 `features.turnsDropped`。它和「回复限流」是两件事：那个管出站**回多少条**，
  这个管入站**进模型多少次**（模型额度与响应速度的真正瓶颈）。
  口径与既有的激进守卫一致（`floodEnabled` / `rateLimitEnabled` 也都是默认关）。
- **面板支持数值控件**：每行 `− 数字 +`，回车/失焦/点 ± 才写一次（不会每敲一个字符就改配置），
  范围与步长**从 schema 现读**（`numberMetaOf()`，面板不抄第二份），越界/小数由服务端 400 拒绝并说明范围。
  输入框的原生上下箭头**已关掉**（`::-webkit-inner/outer-spin-button` + `appearance:textfield`）：
  两边已经有 −/+ 了，那一对又小又难点、纯属重复。
  一次加 10 个数值项（都是原来只在文案里说"去改配置键"的阈值）：
  `chatTurnsPerMinute`（新）、`dedupWindowSeconds`、`rateLimitMaxReplies`、`rateLimitWindowSeconds`、
  `floodWindowSeconds`、`floodMaxMessages`、`floodStrikeLimit`、`floodMuteSeconds`、
  `pokePerHour`、`opsReportDays`。面板现在是 **8 组 60 个开关 + 10 个数值项**。
- **两个限流闸合并成一组、按管道顺序排**（分在两组里各叫一个"上限"容易混）。新组「**限流：入站 / 出站**」：
  **每分钟进模型上限 / 条数**（入站，消息还没进模型就拦，省额度）在前，
  **出站回复限流 / 上限 / 窗口**（模型已生成、发出去之前拦，防 QQ 风控）在后；组级提示直接写清
  "两个闸默认都关、可以只开一个"。顺带把标签改成不含歧义的说法：
  「回复限流」→「**出站**回复限流」、「回复限流·每窗口上限」→「出站回复上限」、
  「每分钟会话上限」→「每分钟**进模型**上限」。
- **开关与它的数值合成一行**：原来"开/关"和它的数字是**两行**、名字还几乎一样
  （「每分钟进模型上限」+「…·数值」），要上下对照才知道谁管谁。现在同一个行里左边是开关、
  右边是 `− n +`（`SwitchNumberRow`）；两个键仍然各自独立写（点开关写布尔、改数字写数值，
  服务端一次只收一个键），面板里的 `chatTurnLimitEnabled + chatTurnsPerMinute` 也会一起列出来。
  `限流：入站 / 出站` 这一组因此从 5 行变成 **3 行**（两个"开关+数值"合并行 + 一个独立的窗口行）。
- **注入 / 回放的帧不占配额**：它们是本地调试流量，不该被真实用户量挤掉——否则"注入几条验证链路"
  会被自己的上限拦在半路，现场看就是"注入没反应"（inject-guard 那套测试当场就把这个抓出来了）。

#### 修复

- **配置写回只认布尔值**：`upsertPatchValue` 原来把非布尔一律拒掉，数值控件写不进去；
  现在接受整数并写成数字字面量（`chatTurnsPerMinute: 7`），浮点/字符串/引号包住的数字一律拒绝——
  这几项 schema 都是 `step(1)`，写个 `3.5` 进去宿主启动会校验失败。
- **`readPatchValue` 也认数字**（面板要判"待重启"），但**引号包住的当字符串**、不猜：
  `"7"` 在 YAML 里是字符串，显示成 7 会让人以为已经生效。
- **数值行缺范围信息时 fail closed**：`numberMeta` 没接好就拒绝写入（并说清原因），
  绝不放行一个"未知范围"的数字去写配置。

#### 测试

- 新增 `ratelimit-unit`（**12** 条）：到上限就拒、**被拒的请求不占位**（否则窗口永远恢复不了）、
  窗口滑动（59.9s 内 vs 60.001s）、多会话互不影响、非法 limit 兜到 1、
  键数超阈值时清理过期项（Map 不无限长）、`used` 计数给 trace 用。
- `commands-unit` 78 → **83**：真桥先验**默认关**（开关关着时连发 8 条、`chatTurnsPerMinute=2` 也一条不丢），
  再打开开关验上限 2：前两条进模型、第 3 条被丢弃（followups 不再增加）、trace 里有带原因的事件、`turnDropped` 记账。
- `settings-unit` 193 → **210**：数值行的快照形状（min/max/step/unit/default/pending）、
  `upsert` 写数值/幂等/拒小数、`readPatchValue` 读数值且不把 `"7"` 当数字、
  POST 接受 7 并落盘为数字、拒绝 11/0/3.5/`"7"`/`true` 且说清范围、失败时不改文件、
  面板键数 70（60+10）、「每分钟会话上限」数值 1–10 默认 5 且**开关默认 false** 的登记守卫、
  客户端按 `row.type` 分派数值控件。
- `inject-guard-unit` 40 条重新全绿（注入帧豁免配额这条的回归）。
- 全量 **58 套 / 3925 断言全绿**。

### v0.6.6（2026-10-16）— 调试台卡死修复 / Console freeze fixed

调试台打开后页面卡死（浏览器提示「此页面没有响应」）、无法交互。两层原因，一头一尾都得收：

#### 修复

- **服务端：一次连接就把整份 trace 当事件灌出去**。`/api/stream` 每条连接都新建 tailer，
  而 tailer 的首轮是**按字节**截的（256 KiB）——本机 254 KiB 的 trace 文件 = **3 秒内 1180 条事件**。
  现在首轮按**条数**封顶（最近 300 条，`createTraceTailer({ initialEvents })`）；
  显式要历史仍然走 `/api/trace?limit=…`（那条路本来就有上限）。
- **前端：来一条就重绘一次整张表**。`onmessage` 里原来是 `renderStream() + updateErrPill()`，
  而 `renderStream()` 会把至多 400 行整表 `innerHTML` 重建一遍 ⇒ 1180 次重绘把渲染进程按死，
  页面自然是"点不动"。现在**合并重绘**（`scheduleStreamRender`）：无论多快进来多少条，
  **最多每 250ms 画一次**，一次突发 = 一次重绘。
  实测同一份 trace：服务端 **1180 条 / 263 KB → 303 条 / 68 KB**，前端重绘 **1180 次 → 1 次**。
- **桌面端「调试台」不再多开一个 Electron 实例**（同一个功能里的错误用法）：
  桌面端的 `process.execPath` 是 **Electron 本体**，原来直接拿它去跑 `control/bin/qq-control.mjs`，
  等于把这支脚本当成**一个 Electron 应用的入口**（真机实测：控制台进程命令行就是
  `"…\DeepSeek Harness.exe" …\control\bin\qq-control.mjs`，`Get-Process` 里显示成 DeepSeek Harness、
  占 126 MB）。按官方文档（Environment Variables → `ELECTRON_RUN_AS_NODE`：
  "Starts the process as a normal Node.js process."）在拉起时补这个变量；CLI 宿主
  （`node bin.js web`，`process.execPath` 本来就是 node.exe）**不补**，行为不变。
  本机实测该 fuse 是开的（子进程报 `electron=44.0.0 node=24.18.1`，控制台照常监听端口）；
  注入的 env **只追加**，宿主原有的环境变量一个不少。

#### 测试

- `console-debug-unit` 72 → **78**：tailer 首轮按条数封顶（900 条的文件只给最近 300 条、且是**最新**那批）、
  封顶只作用于首轮（之后照常增量、不丢新事件）、`initialEvents: 0` 能显式放开；
  并把面板脚本里的 `scheduleStreamRender` 抠出来**真跑一遍**——同步阶段 0 次重绘、250ms 后合并成 1 次。
- `settings-unit` 189 → **193**：桌面端补 `ELECTRON_RUN_AS_NODE`（CLI 宿主不补）、
  后台拉起注入的 env 只追加（宿主变量一个不少）、不传 env 时不塞 `env` 字段。
- 全量 **57 套 / 3891 断言全绿**；真机复验：重启控制台后同一条 SSE 从 1180 条降到 303 条，
  页面里的合并重绘已生效。

### v0.6.5（2026-10-16）— NapCat 启动链路修复 / NapCat launch path fixed

issue #2 的两个症状：① 填了 NapCat 启动脚本后，仍提示「缺少垫片脚本路径(shimFile)」；
② 那个 `shimFile` 在安装目录里根本找不到（它是运行时生成的，本就不在包里）。

#### 修复

- **控制台「启动 NapCat」与「重启登录流程」从来就没成功过**（两层原因，都在这版修掉）：
  - **第一层（配置层）**：v0.6.3 把启动路径改成"垫片脚本"时只更新了 DSH 面板那条路，
    控制台这两处还在调 `napcatLaunchCommand(chosen.path)` —— **一个参数都没传**，
    于是每次都命中 `launchPlan` 的判据、回一句 `缺少垫片脚本路径（shimFile）`。
    现在两条路共用同一套：垫片路径与日志路径从**工作目录**推（`<cwd>\qq-napcat-launch.cmd` / `.log`）、
    先落盘（目录不存在就建）再提权执行、最后**等垫片心跳**才报成功。
  - **第二层（进程层，修好第一层也仍然点不动）**：控制台原来用通用的 `startDetached`（`detached: true`）去拉
    powershell，而**本机实测 `detached: true` 的 powershell 子进程根本不执行**——退出码 0、
    没有任何输出、垫片一行都没写；同一个命令去掉 `detached` 立刻就跑起来。
    也就是说：只修垫片路径的话，用户会得到一句"提权那一跳被系统拦下了"——**诊断还是错的**。
    现在提权命令走新的 `spawnElevated`（与面板同形状：不 detached、抓 stdout/stderr），
    既能真的执行，也能把 `QAI-ELEVATED`/`QAI-RUNAS` 与 powershell 的报错原文带回界面。
    真机端到端复验：假 launcher 跑通、日志出现心跳、接口 `ok:true`。
- **`shimFile` 不再是用户要去找的东西**：垫片是**点按钮那一刻生成**的，安装包里根本没有它——
  所以按这个名字去文件夹里翻，永远翻不到（这正是 issue #2 里"找了五小时"的那一段）。现在
  ①两条路写**同一个文件**；②报错里说清它叫 `qq-napcat-launch.cmd`、在哪个目录、由谁生成；
  ③垫片自己开头几行就写着"本文件自动生成，别去插件目录找它"，并且 `@echo off` 放在**第一行**
  （否则那几行说明会被回显进提权窗口，本机实测过）。
- **成功判据收紧**：只看**这次新写进去的**心跳（点击前记下日志 mtime）。60 秒内点第二次时，
  上一次的心跳不会被当成这一次的证据（原来会 ⇒ 又一次假成功）。
- **不再让用户去点一个本机根本不会出现的 UAC 弹窗**：控制台旧文案写的是「请在 UAC 弹窗点『是』」，
  而本机策略 `ConsentPromptBehaviorAdmin=0` 下提权**不弹窗**。现在按垫片心跳如实回报：
  没心跳就说"这次点击什么都没发生，请用管理员身份重开控制台"。
- **「找不到 NapCat 启动脚本」不再只能靠用户手抄**：DSH 面板原来只认 `qq-control.json` 里的 `napcatBat`，
  空值就直接说"未配置"，而控制台早就会探测常见安装位置 ⇒ 同一台机器上"控制台能用、面板说没配"。
  候选表现在只有一份（`detectNapcatBat`），控制台与面板共用；探测不到时给的是人话：
  填 `bootmain\launcher.bat`（**不是**同目录的 `napcat.bat`：那一版它只是拉起加载器 + `pause`）、
  默认在哪、以及"控制台与面板读同一份配置，填一次就够"。
- **「桥：无快照」不再是一句没头没尾的话**（用户原话「我不理解，我不理解」）：现在分开说三种情况——
  ①快照停在 N 分钟前（桥停了/插件被禁用）②宿主没跑（快照是宿主里的插件写的，先启动宿主）
  ③宿主在跑却没有快照（插件没启用，**或插件的工作目录与控制台配的不是同一个**——它把快照写成
  `<它自己的 cwd>\qq-runtime.json`）。鼠标停上去有完整解释，「运行快照」空态写同一口径，
  「一键体检」里那一项也给出这两个原因。
- **控制台按钮等 8 秒期间禁用并显示「请求中…（最多等 8 秒）」**：否则用户以为"点了没反应"就会连点，
  连点会拉起第二个提权进程。
- **测试诚实性**：`control-unit` 的汇总与 `process.exit` 原本写在一段审查断言（O1/O2 二维码魔数那 4 条）
  **之前**，那 4 条**从来没跑过**却照样打印"全绿"。已挪到文件末尾。

#### 测试

- `control-unit` 163 → **179**：新增 12 条钉住这次的事故——控制台启动不再回 `shimFile` 那句话、
  垫片落点 = 工作目录（与面板同一个文件）、垫片内容含 `cd /d` + `call launcher.bat`、
  **心跳推进才算成功**、60 秒内点第二次不算成功、**提权走 `spawnElevated` 且不带 `detached`**
  （源码级 + 行为级各一条：抓得到 `QAI-RUNAS`、非零退出带回 stderr、spawn 抛错变成 failed 结果）、
  powershell 非零退出时带出原文、重启登录同样带上垫片路径、写不了垫片时点名文件 + 原始错误；
  另有 4 条原本被 `process.exit` 挡住的审查断言现在真的会跑。
- `settings-unit` 186 → **189**：面板在配置为空时自己去常见位置探测、用户填的路径优先、
  探测不到时报错说清"填哪个文件、填在哪"；心跳桩改成"点击前是旧文件、垫片跑起来才前进"，
  否则 `since` 判据会被一个恒定 mtime 的假桩整个测没。
- `console-debug-unit` 69 → **72**：把面板脚本里的 `describeBridge` 抠出来逐个断言四个分支
  （宿主没跑 / 插件没加载 / 快照太旧 / 活跃），并钉住配置卡片上那两句提示
  （填 `launcher.bat` 而不是 `napcat.bat`；垫片与日志是点按钮时写进工作目录的、不在安装包里）。
- 真机手测：① 生成的垫片用 `cmd /c` 实跑一遍（假 launcher），日志出现心跳行、`shimHeartbeatFresh` 为 true，
  窗口里只剩两行指路提示（说明 `@echo off` 的位置对了）；② 真起一个控制台（临时配置 + 假 launcher，
  不碰真 NapCat）POST `/api/napcat/start`，接口回 `ok:true / shimRan:true`，日志里同时有垫片心跳与
  launcher 输出——**这条路第一次端到端跑通**。
- 全量 **57 套 / 3881 断言全绿**。

### v0.6.4（2026-10-06）— 调试台一键拉起 / One-click console

#### 新增

- **点「调试台」即自动拉起**：该入口原来在控制台没运行时只回一页"请自己去终端跑这条命令"。
  现在它会**先用宿主自己的 node** 起一个控制台进程（`process.execPath` + `control/bin/qq-control.mjs`，
  `cwd` = 插件根），等端口（默认 8799）通了再 302 进带 token 的地址——一次点击直达。
  不需要提权、不需要垫片脚本：控制台是普通 node 进程，自己会解析仓库根并读写 `qq-control.json`。
- **起不来时如实说明**：等满 8 秒仍未监听，或入口文件缺失，页面上写明具体原因（含"已经拉起进程 pid …，
  但端口还没通"），并保留手动命令；`?format=json` 同步返回 `started` / `pid` / `reason`，桌面端据此提示。
- **启动方式沿用已踩明的两条硬事实**：不传 `detached`（本机 Node 26 上带 detached 的子进程不执行命令），
  且 `stdio: 'ignore'`——控制台是长驻进程，抓管道会在我们不再读取后把它的输出憋住。

#### 测试

- `settings-unit` 178 → **184**：`consoleLaunchPlan` 的成形与拒绝、拉起成功 → 302（含 spawn 参数与 cwd）、
  拉起后端口不通 → 页面与 JSON 都带原因、入口缺失 → 不硬拉、面板上「未启动 · 点一下会自动拉起」的文案。
- 全量 **57 套 / 3857 断言全绿**（真机另测：拉起后端口 500 ms 内监听，随后正常停止）。
### v0.6.3（2026-10-06）— 账号入口 + 面板里一键启动 NapCat / Account entry & one-click NapCat launch

#### 新增

- **「QQ助手账号（登录 / 扫码）」入口**：面板「相关链接」组的第一条，指向宿主自己的 `GET /qqai/account`；
  服务端读 `bootmain/config/webui.json` 里的 token 后 **302 到 `http://127.0.0.1:<port>/webui/?token=<token>`**，
  点开就是已登录的 NapCat 页面，不用手抄密钥。token **不进面板载荷**（与调试台入口同一条规矩：
  密钥只出现在 302 的 `Location` 里）。
- **落点形状取自 NapCat 4.18.28 的前端实现 + 本机实测**：`location.search` 取 `token` → 自动登录 →
  `SHA256(token + ".napcat")` → `POST /api/auth/login {hash, totpCode}` → `localStorage["token"]` →
  之后带 `Authorization: Bearer …`。因此 hash 由前端计算、无需预生成；落点必须**带尾斜杠**
  （`/webui` 会先吃一个 301）。控制台侧的 `napcatWebui()` 同步改成同一形状，两边不再各写一种。
- **「相关链接」整组固定在面板最上方**：组内顺序 `account → changelog → readme-debug → console`
  （账号第一、调试台最底），渲染在标题正下方、开关分组之前；客户端组件由 `Footer` 改名为 `Links`。
  载荷里没有多余的 `account` 字段（账号入口即 `links[0]`）。浅渲染三条断言钉住整组位置、组内顺序与"只出现一次"。
  ⚠️ 维护提示：这一组是一个整体，**不要拆开、也不要单独调整其中某一条的顺序**。
- **「快捷操作」：面板里启动 NapCat / 重新登录（扫码）**：`POST /qqai/napcat/start` 与 `/qqai/napcat/relogin`，
  决策逻辑放在新增的 `lib/napcat-launch.js`，控制台与面板共用一份。三条硬规矩：
  ① 必须提权（非提权的 `launcher.bat` 实测秒退）；② **启动脚本优先取同目录的 `launcher.bat`**——
  配置里的 `napcat.bat` 只是拉起加载器 + `pause`（不设 `NAPCAT_*`、不解析 QQ 路径），实测秒退什么都不做；
  ③ 重新登录**只按加载器 PID** `/T /F`（拿不到 PID 直接拒绝），绝不按镜像名杀——那会连用户自己的 QQ 一起杀掉。
  特权动作三道门都要过：POST + `application/json`、同源守卫、只允许回环来源；
  `ok:false` 的回执（"已经在运行了""没找到加载器"）当**解释**原样显示，不当异常抛掉。
- **面板内嵌二维码**：新增 `GET /qqai/napcat/qr`（只允许回环 + 同源）把 `cache/qrcode.png` 交给页面；
  载荷新增 `napcat.qr = { fresh, ageSeconds, url }`（超过 5 分钟视为过期，口径同控制台 `QR_STALE_SECONDS`）。
  新鲜时「快捷操作」下直接显示 176×176 的二维码 + 「刷新二维码」按钮，过期则自动收起并提示去点「重新登录」。
- **启动后自动等待二维码**：启动 / 重启成功后客户端每 3 秒刷新一次面板，二维码一写出就显示并提示扫码；
  90 秒仍未出现则停下并给出一句说明。按钮旁的状态文案同步写明"等几秒，二维码会出现在下面"。
- **账号入口补上前提说明**：「机器人账号的扫码 / 登录状态页；**需要先运行 NapCat**（没起来就点上面的
  「启动 NapCat」）…」；链接行的说明也开始走 `richText`（此前只有开关说明会解析 `**加粗**`，
  链接说明会把星号原样显示出来）。
- **控制台按钮改名**：`control/` 的「打开 NapCat 扫码页」→「**QQ助手账号**」
  （禁用态文案、端口标签同步更新）。

#### 修复

- **浏览器点击入口返回 403（同源守卫）**：浏览器点 `<a href="/qqai/account">` 发出的是导航请求
  （`Sec-Fetch-Site: same-origin`、**不带 `Origin`**），而守卫的"没有 Origin"分支只放行 `''` 与 `none`，
  正常点击因此被判成"来源不明"。该问题自 v0.6.0 起存在（「调试台」按钮同为导航请求）。
  现在放行 `same-origin` / `none` / 空三种，仍然拒 `cross-site` 与 `same-site`；
  测试改为**构造真实浏览器的导航请求头**（`sec-fetch-mode: navigate`、无 `Origin`）逐条覆盖。
  另外，链接行此前只有蓝色标签是 `<a>`、右侧灰色说明是 `<span>`，点说明无反应——**现在整行是一个 `<a>`**。
- **桌面端点击入口无反应**：桌面端主窗口只把 http(s) 外链交给系统浏览器，其余一律拒绝
  （`setWindowOpenHandler` → `shell.openExternal` / `deny`）。面板入口是相对地址，在桌面端解析成
  `dsh-app://app/qqai/account`，既不是 http(s)、也不允许开 Electron 窗口，于是什么都不发生。
  两个入口因此都支持 **`?format=json`**（账号回 `{ ok, url }`，调试台回 `{ ok, running, url, command }`），
  客户端**仅在桌面宿主**（`location.protocol === 'dsh-app:'`）改走"取 JSON → `window.open(绝对 http 地址)`"；
  网页版保持原来的 302 导航。守卫不变（跨站仍 403）。
- **「启动 NapCat」点了没有任何反应——三个根因，逐条修复**：
  ① **子进程不得带 `detached: true`**：本机（Node 26 + Windows）实测，带 detached 时子进程 `exit=0`、
     stdout/stderr 全空、**命令根本没有执行**（落盘标记都未生成）；去掉后立即恢复。形状矩阵验证：
     默认 / 仅管道 / `windowsHide`+管道三种都有输出，`detached`+管道两种组合全部"空且未执行"。
     detached 的原意是避免子进程随宿主退出被回收，但提权那一跳由 AppInfo 服务拉起、本来就不在宿主 Job 内，
     发令用的 powershell 一秒内即退出，因此并不需要它；现在只保留 `unref()`，并加断言禁止再传。
  ② **提权后 `%cd%` 会变成 `C:\Windows\System32`**：`launcher.bat` 用 `%cd%` 拼自身路径，
     于是去找 `System32\NapCatWinBootMain.exe` 并报一句 `is not recognized...` 就退出；
     `-WorkingDirectory` 在这一跳不生效。
  ③ **复杂内层命令经 `cmd /c` + `Start-Process -ArgumentList` 传参会打乱引号**：内层不执行，而退出码仍是 0。
  现在把上述脏活写进**可审计的垫片脚本** `<cwd>\qq-napcat-launch.cmd`（心跳行 + 可选 taskkill + `cd /d` +
  `call launcher.bat` + 输出重定向到 `<cwd>\qq-napcat-launch.log`），提权命令只执行 `cmd.exe /c <垫片路径>`
  （单一纯路径、零嵌套引号）。垫片额外 `chcp 65001` 并向窗口打印两行指路（输出写到哪个日志、二维码在面板哪里看）。
- **「重新登录」误报成功**：成功判据原本是"6099 在听"，而 NapCat 已在运行时该条件恒真——即使提权那一跳被拦下、
  垫片没有执行，界面也会报成功。现在以**垫片心跳**（垫片自写的 `=== shim start … ===`）为准：
  没有新心跳即返回 `ok:false`，并明确说明"这次点击什么都没发生"。管理员宿主改用
  **WMI `Win32_Process.Create`** 启动（`-Verb RunAs` 在已是管理员的宿主里偶发静默不执行）；
  其附加收益是进程由 WmiPrvSE 拉起、**脱离宿主进程树**，非管理员宿主仍走 RunAs（经 AppInfo 拉起，同样脱离）。
- **提权失败被吞掉**：`spawnDetachedProcess` 原用 `stdio: 'ignore'`，提权被拒时界面仍显示"已请求启动"。
  现在捕获 stdout/stderr 并等待退出：非零退出码/失败一律 `ok:false`，并把 PowerShell 的原话带回界面；
  成功时再等最多 8 秒确认 6099 是否真的起来，如实回报"已经起来了"或"还没起来"。
- **点「刷新二维码」整页白屏**：刷新处理器写成 `setState({ qrStamp })`（**整对象替换**）会一并清掉 `data`，
  下一帧渲染读取 `data.napcat` 抛错，React 卸载整棵树。现已改为函数式更新（只改时间戳、保留 `data`），
  `load()` 同样保留 `qrStamp`；并新增渲染边界 **`PanelBoundary`**（React 错误边界只能是 class 组件），
  今后渲染异常只在面板位置显示错误说明与重试按钮，不再影响整个设置页。测试桩同步补上 `React.Component`。
- **测试卫生**：账号入口此前未接收调用方解析出的插件根，单测会读到真机的 `qq-control.json`
  （断言输出里带出本机 NapCat token）。现在 `pluginRoot` 与 `readFile` 均由调用方注入，单测全部在临时目录运行。

#### 隐私

- **面板不再回显密钥**：启动日志中会出现 `[WebUi] WebUi Token: …`，而接口会把日志最后一行贴回面板；
  现在回显前统一打码（"键名+值"与 URL 里的 `?token=` 两种形态），并有断言钉住。
- **收紧启动日志权限**：工作目录下的文件默认带 `BUILTIN\Users:(RX)`，本机任何账户都能读到其中的 NapCat token
  （实测确认）。垫片现在执行 `icacls /inheritance:r`，只保留「当前用户 + Administrators + SYSTEM」；
  `icacls` 失败不影响启动。
- **仓库不再包含机器人账号的真实昵称**：该昵称曾出现在 `lib/onebot.js` 注释、`test/ops-bridge-unit.mjs`
  用例与 CHANGELOG 中，并已进入公开历史（提交 `bdb3bd8`，按维护者决定未改写历史）；
  现已全部替换为中性占位「机器人昵称」。
- **新增两道自动检查**：真机日志片段（桥的收信行 / NapCat 的 token 行 / WebUI 地址行 / 运行日志片段）
  列为禁止形状；私有昵称可从 `DSH_QQ_PRIVATE_NICKNAMES`、本机 profile 配置，或本机私有文件
  `<cwd>/qq-private-nicknames.txt`（受 `qq-*.txt` 忽略规则保护）注入比对。
- `.gitignore` 补充 `qq-*.cmd` / `qq-*.bat`（垫片含 NapCat 安装路径，日志含 token）。
- 复查结论：**密钥与真实 QQ 号从未进入任何提交**（工作树、已推送的 `origin/main`、全历史搜索三处均无）；
  `qq-control.json` 从未被跟踪，且被 `.gitignore` 覆盖。

#### 测试

- `settings-unit` 86 → **178** 条断言（v0.6.4 起为 184）：落点形状（`/webui/?token=` + 明文 token）、读不到配置时的回退、
  `GET /qqai/account` → 302 与跨站 403、载荷不含 token、「相关链接」的位置与顺序、真实浏览器请求头形状、
  整行可点、桌面端 `?format=json` 与客户端桌面分支、快捷操作的决策与路由（含提权被拒、非零退出码、
  心跳判据、垫片内容）、二维码路由与面板内嵌、密钥打码与日志权限、`spawnDetachedProcess` 不传 `detached`。
- 全量 **57 套 / 3851 断言全绿**。

### v0.6.2（2026-10-04）— 功能说明补全 / Every switch explains itself

> 真机反馈：**"有些功能说明不是很全啊，就比如 AI 生图，就写了串英文，都没写需要额外的软件或模型"**。
> 查下来是面板 59 个开关里有 21 行提示是**空的**（只有中文标签 + 英文配置键），
> 需要外部服务的那几个（生图/语音/转写）完全没说清楚要装什么。

- **59 行说明全部重写**，每行都讲清三件事：这个开关**做什么**、**需要准备什么**、
  **关掉会怎样**（说明长度 25–235 字，不再有"一句带过"）。
  例：「AI 生图」现在写明"**需要额外的生图服务**：任何 OpenAI 兼容的图片接口——
  填 imageGenProvider / imageGenBaseUrl / imageGenApiKey / imageGenModel / imageGenSize；
  本地部署的（SD WebUI / ComfyUI 兼容接口）也行，把地址填成它即可"。
- **新增依赖标记**（开关名字后面的小标签，一眼看出要准备什么）：
  「需外部服务」3 个 · 「需密钥」1 个 · 「需词表文件」2 个 · 「需配置」16 个 · 「需群管理员」8 个 ·
  「需 NapCat 扩展」9 个 · 「不需模型」4 个；其余 **16 个开箱即用**（不带标签）。
- **界面**：说明支持极简加粗（成对星号 → 加粗，不引 markdown 库、绝不 innerHTML），
  完整说明同时放进 title 属性，鼠标悬停可看全文。
- **5 条新守卫**（防止再出现"只写标签不写依赖"）：每行说明必须 ≥20 字；依赖标记只能用词表里的值；
  **凡 schema 里同族存在 apiKey / baseUrl / provider / model 的开关，必须标出依赖**
  （这条是证据型检查，以后新增需要密钥的功能忘了写说明会直接测试红）；
  依赖分布要合理；生图/语音/转写这三行的说明必须点明"需要什么"。

- **不再用「非默认」这个说法，直接标出厂默认值**（真机反馈的两轮追问："非默认不是关着的吗？"→
  "改成'默认：状态'这样子好一点，而不是显示非默认一条"）：每一行都显示 **默认：开** / **默认：关**
  （灰色小标签），把它和右边的开关一对比就知道自己改没改过；悬停给出完整解释
  「出厂默认：关 · 当前：开（你改过）」。取值为空的（schema 没声明默认）不显示该标签。
  实测这台机器上 59 个开关里 9 个与出厂不同，**全是"默认关被打开"**（群运营总开关、管理员设置、邀请策略、
  加群方式、申请补拉、管理员变动播报、语音转文字、入群验证、注入通道）。
  快照新增 `defaultValue` 字段，浅渲染两条断言分别覆盖「默认：关」与「默认：开」，并断言不再出现"非默认"字样。

- **需要额外安装 / 配密钥的功能一律默认关**（真机要求："把所有需要额外扩展的，比如'朗读'改成默认关，
  因为这些需要额外安装扩展"）：`voiceReadingEnabled`（朗读语音消息）**默认值由 `true` 改为 `false`** ——
  它依赖一个可用的 TTS 服务（本地 GPT-SoVITS 或云端密钥），没装的人开了也没用；
  "语音回复"、"语音转文字"、"AI 生图"本来就是默认关，保持不变。
  新增一条守卫：**凡面板标了「需外部服务 / 需密钥」的开关，schema 默认值必须是 `false`**（谁改回去测试就直接红）。
  - **升级影响**：配置文件里**显式写死**了该键的人不受影响（显式值永远盖过默认值）——
    本机两个 profile 都写着 `voiceReadingEnabled: true`，要跟着关就得改配置或删掉那一行。

- **说清"这些能力 DSH 不自带"**（真机补充："还有 TTS 的这些内容 Deepseek 并不自带"）：
  `ttsEnabled / sttEnabled / imageGenEnabled / voiceReadingEnabled` 的 schema 描述与面板说明都改成明说
  「**DSH 与本插件都不自带**，要你自己准备（本机装服务或去第三方申请密钥）」，别让人以为装好插件就有；
  「语音与媒体」这一组还加了**组级提示**（挂在组标题下面），一次把三类依赖讲清：自备服务/密钥、
  **默认全部关闭**、以及 OCR/相册/群文件/成员查询走的是 **NapCat 专有接口**（换 OneBot 实现不可用）；
  依赖标记的措辞也从「需外部服务 / 需密钥」改成 **「需自备服务 / 需自备密钥」**（"自备"两个字是关键），
  「需词表文件」同样改成「需自备词表」。新增 3 条断言钉住这些说法。

- **依赖口径更正**（DSH 已自带语音转文字）：
  查了 DSH 0.2.0-rc.2 的实现——**语音转文字 DSH 确实自带**，是一组实验性包
  （`dsh-experimental-speech-to-text` + `-sensevoice` 本地 ONNX + `-api-speech-to-text` + `-client-ui-voice-input`，
  由 `dsh-experimental-voice-input-bundle` 一次性插入，默认 provider 是 `sensevoice-local`；宿主侧服务名 `speechToText`，
  `resolve(request)` → `transcribe(spec, signal)`，要 **16 kHz 单声道 PCM16 WAV**，返回 `{ text, audioSeconds, inferenceSeconds }`）。
  它**需要自己在该 profile 里启用**，且首次使用会下载模型——所以口径应是「DSH 自带（实验性，需启用）」，
  而不是此前写的"不自带"。现在：`sttEnabled` 的面板说明与 schema 描述都改成了这个口径，
  「语音与媒体」的组级提示也把 TTS/生图（真不自带）与 STT（自带但要启用）分开写；
  **TTS / 生图仍是"DSH 与本插件都不自带"**（措辞收窄，不再把 STT 一起算进去）。
  断言相应拆成三条：TTS/生图说"不自带"、STT 说"DSH 自带 + 需启用"、schema 描述口径一致（含一条防串词的检查：
  生图描述里不许再出现 "no TTS service"）。

- **语音转文字改成默认走 DSH 自带的本地识别**（承接上一条：用户指出"是不是可以更改语音转文字的方式，
  因为现在 DSH 自带这个功能了，但是需要自行开启"）：新增 **`sttProvider: 'dsh' | 'cloud'`，默认 `dsh`** ——
  用宿主服务 `speechToText`（`dsh-experimental-voice-input-bundle` 里的本地 SenseVoice），
  **音频不出本机、不需要任何密钥**；只有显式设成 `cloud` 时才会走原来的 `sttBaseUrl`/`sttApiKey` 云端接口。
  实现要点（新建 `lib/stt.js`，纯逻辑、可注入，方便单测）：
  - QQ/NapCat 给的语音格式五花八门（silk / amr / 各种采样率的 wav），统一用 ffmpeg 转成
    **16 kHz 单声道 PCM16 WAV**（DSH 那边用 `validateWave` 校验），并在本地先做一次同样的体检，
    产物不合规就**拒绝**而不是硬发过去；
  - 调用形状按平台契约：`resolve({ audio: Uint8Array, language })` → `transcribe(spec, signal)` → `{ text }`，
    带 120 秒超时；`sttLanguage` 默认 `auto`（中英混说也稳）；
  - 失败一律翻译成人话：没启用 bundle → "请把 …voice-input-bundle 加进 profile 的 bundles 并重启"；
    首次使用要下载模型 → "首次使用要下载本地语音模型…"；没有可用提供方 / 语言不支持也各有提示。
  - 云端的 API Key 预检改成只在 `sttProvider: 'cloud'` 时才要求，否则本地识别会被一个空 key 拦下来。
  新增单测 `test/stt-unit.mjs`（24 条）：默认值、WAV 体检（采样率/声道/位深/非 WAV/太短）、
  ffmpeg 参数与产物校验、临时文件清理、服务调用形状（Uint8Array + signal）、没启用时的中文原因、
  空结果报错、四类错误翻译。

全量 **57 套 / 3765 断言全绿**。

### v0.6.1（2026-10-04）— 开关配色修正 / Switch colours fixed

> 真机反馈：**"关了以后感觉按钮消失了一样"**。原因是 OFF 态的轨道用了与卡片同色的
> `--dsw-alias-bg-layer-2`（近白）、圆点用的是白色 `--dsw-alias-label-primary-foreground`，
> 浅色主题下白底白点，等于隐形。

- **照抄平台自己的开关样式**（`@deepseek-ai/dsh-client-ui-primitives/lib/Switch.module.css`），而不是自己配颜色：
  轨道 OFF = `--dsw-alias-border-l3`（浅色 `#0000001f` / 深色 `#ffffff29`，可见的灰），
  轨道 ON = `--dsw-alias-brand-primary`（浅色近黑、深色近白），
  圆点 OFF = `--dsw-alias-switch-thumb`，圆点 ON = `--dsw-alias-label-primary-foreground`；
  几何一并对齐官方（36×20、内边距 2、圆点 16、位移 16、120ms）。
- **语义改用 `role="switch"` + `aria-checked`**（官方就是这么做的：视觉状态挂在无障碍属性上，两者不会打架），
  不再用自定义 `data-on`。
- 新增 4 条回归断言：官方的三个 token 必须在用、不许再出现"卡片同色轨道"、`aria-checked` 必须随开关状态映射
  （浅渲染实测 `false` / `true` 两种）。

全量 **56 套 / 3728 断言全绿**。

### v0.6.0（2026-10-04）— 轻量化设计 / Lightweight

> 这一版的"轻"落在三处：**能关的东西一眼看得见**（DSH 设置里新增「QQ助手」面板，常用开关点一下就启停）、
> **不为它多装任何东西**（零新增依赖，客户端只用宿主自带的 react）、**改动面最小**（只碰 profile 里本插件那一个
> config 块，原子写 + 自动备份）。另外把 v0.5.9 发布后真机跑出来的一串问题收口：@ 识别、命令粘参、报错糊脸、掉线无声。

#### 新功能：DSH 设置 → 「QQ助手」

- **一个页面管住常用开关**：7 组、59 个开关（从 224 个配置键 / 92 个布尔键里精选）——
  对话基础 · 群运营工具箱 · 娱乐与互动 · 语音与媒体（日常四组直接铺开），
  安全与风控 · 记录与通知 · 高级与调试（三组标"进阶"、默认折叠）。**不是把配置全铺上去**——那样面板本身就重了。
- **每行都说实话**：显示中文标签 + 一句话说明"关掉会怎样" + **配置键名**（方便你回头改文件），
  并标出「非默认」（与 schema 默认值不同）与「待重启」（配置文件里的值与当前生效值不一致）。
- **点一下即写入**：`POST /qqai/panel/set` 只接受**白名单内的布尔键**（非白名单/非布尔一律 400），
  只改 profile 的 `cordis.patch.yml` 里**本插件那一个 config 块**，保留其它条目与注释。
- **写入是安全的**：先写同目录临时文件再 `rename` **原子替换**（撕裂的 YAML 会让 DSH 下次启动直接报错，
  这条不能省），改动前留一份 `.bak-qqai` 备份；写失败时原文件不动，并把真原因回给面板。
- **路由会注销**：配置一改，DSH 会重建这个插件条目（fiber 重挂），而 `webServer.register` 对重复的
  `(kind, path)` 是**直接抛**的——所以挂载函数返回真正的 disposer，重挂不会撞车。
- **面板最底下是更新日志与调试入口**：`更新日志（v0.6.0）` → GitHub 的 `CHANGELOG.md`；`调试文档` → README 的
  调试章节；`调试台（独立控制台）` → 走宿主的 `/qqai/console`（**跑着**就 302 到带 token 的地址，
  没跑就回一页"怎么启动"，见下条）。
  （**v0.6.3 起这一组挪到了页面最上面**，并多了账号入口，顺序见 v0.6.3 条目——这条是当年 v0.6.0 的原貌。）
  **地址全部由真实来源推导**（版本与仓库来自 `package.json`，端口来自控制台的 `qq-control.json`，读不到就回落 8799），
  没有仓库信息时只显示调试台、**不编造链接**。
- **调试台如实标出"运行中 / 未启动"**（真机反馈后补的）：调试台是**独立进程**（`control/`），DSH 插件**不会**
  替你启动它——第一版只给了一个裸链接，点进去只看到连不上，还不知道为什么。现在每次读面板都会探一次端口
  （结果缓存 2 秒）：没启动就把**可直接复制的启动命令**写在那一行上；链接改指宿主自己的 `/qqai/console`，
  **跑着**就 302 到**带 token** 的地址（token 只在服务端从 `qq-control.json` 读出，**不进面板载荷**，
  单测有一条断言专门钉"载荷里没有 token"），**没跑**就回一页"怎么启动"——不再是死链。

#### 轻量化的具体做法（附 DSH 侧的依据）

- **客户端 bundle 手写、不引构建器**：`client/client.js` 就是一段 `window.__ModuleLoader__.load({ id, factory })`，
  `factory` 里只 `require('react')`（平台允许免图依赖的种子之一），`exports.inject = ['slots']`，
  用 `ctx.slots.inject('settings.section', …)` 注册页面——与已装插件 `dshmarket` 完全同一条路，
  官方契约表里给出的示例逐字一致。
- **声明只加必需的**：`package.json` 加 `exports["./client"]` 与
  `dsh.client = { platform: "web", inject: ["@deepseek-ai/dsh-client-ui-settings"] }`；
  `inject` 里的包名写错会**静默跳过**，所以有一条静态守卫盯它的形状。
- **不碰 DSH 的 volatile 门槛**：走自建 HTTP 路由 + `fetch`（`dshmarket` 同款），
  因此不需要给 92 个布尔键挨个加 `.volatile()`，也不用担心"配置页把你插件重挂一次"。
- **样式零成本**：面板样式全部用 DSH 主题变量（`--dsw-alias-*`），深浅色自动跟随，不额外打包 CSS。
- **只挂载在能挂的宿主上**：用 `ctx.inject(['webServer'], …)`，TUI 等没有 webServer 的宿主里这段**根本不执行**，
  QQ 桥照常工作（只是没有那一页）；挂载失败也只记一条 warn，绝不影响桥。

#### 对抗性审查后的加固（两轮，共 6 个 P1，全部带可复现证据）

> 提交后跑了两轮**独立对抗性审查**（只读，禁止改文件/动 git/起进程），它用**可执行的最小复现**证明了下面这些真问题。
> 每条都补了回归断言，断言用的就是审查给出的复现用例——而且这份"覆盖声明"本身被**回退矩阵**验过：
> 把每处加固**逐条改回旧写法**，套件必须变红。第一轮矩阵里有一条（多行字符串那条）暴露出**测试夹具其实并未覆盖到**
> （字符串内容行没以 `tsEnabled:` 那种形式开头），改掉夹具后才真正生效；矩阵现在 **8/8 全部被捕获**。

| # | 问题（审查复现） | 现在的行为 |
|---|---|---|
| P1-1 | **"原子写"里藏着一条非原子退路**：rename 失败时退化成 `writeFile` 直接覆盖活配置，而 500 文案还写着"原文件未被破坏"。Windows 上 rename 覆盖已存在文件会瞬时 `EACCES/EBUSY/EPERM`（平台自己的 `dsh-atomic-write` 为此重试 8 次） | 临时文件用**随机名 + `wx` + `0600`** 创建；rename 对瞬时错误重试 8 次；**绝不退化成覆盖**——失败就保持原文件不动、清掉临时文件、如实报"原文件保持不动" |
| P1-2 | **子键缩进硬编码"父缩进 + 2"**：`yaml.stringify(…, { indent: 4 })` 产出的 4 空格 patch 是合法的，被改成非法 YAML → 宿主下次启动**直接拒载** | 缩进**从文件里量**（`config:` 之后第一行更深的内容行）；只有 config 为空时才按 2 空格惯例兜底，且这是唯一一处"猜" |
| P1-3 | **按键名盲扫**：多行字符串（`\|` 块）里恰好长得像 `key: value` 的一行会被当成真键 → 写出重复键或错误缩进（都是启动级错误） | 键必须**正好在 config 的直接子层**（缩进 === 子键缩进）且不是注释行；读与写共用同一套判定 |
| P1-4 | **跨站可写**：任意网页发一个 `text/plain` 的 CORS 简单请求（连预检都没有）就能改开关 | 写接口要求 `application/json`，并要求 `Sec-Fetch-Site` / `Origin` 同源（**没有 Origin 的本机脚本/curl 照旧放行**）；`/qqai/console`（会把带 token 的地址交出去）同样只给同源 |
| P1-5 | **profile 解析漏了两种官方写法**：`--profile=<name>`、以及位置参数直接给 profile 名 → 可能写到**另一个 profile** 的配置 | `--profile` 与 `--profile=<name>` 都认；**位置参数给的裸名字不认**（第二轮核对 CLI 源码后确认：profile 只能靠 `--profile` 给，位置参数是给被启动应用的，认了反而会把应用参数当 profile 写错地方），认不出就如实回落 `web` 并记一条 warn |

**第二轮审查（针对加固本身）又抓到一个 P1 和一批问题**：

| # | 问题 | 现在的行为 |
|---|---|---|
| P1-6 | **守卫可绕过**：`Origin` 的 hostname 等于请求 `Host` 就信任（DNS rebinding 正好满足），且**"没有 Content-Type 就当本机脚本放行"**——不带 Content-Type 的 POST 是 CORS 简单请求、**不发预检**，于是"要求 application/json"这道闸形同虚设 | 写接口**必须**是 `application/json`（curl 也一样要带头）；Origin 只在三种情况放行：`sec-fetch-site: same-origin`（浏览器担保）、scheme+host+port 与请求 Host **完全一致**、DSH 自家 `dsh-*://`。`file://`、`data:`、`chrome-extension://`、**异端口的本机页面**一律拒绝 |
| P2 | 7 处加固里**6 处没有回归断言**（回退矩阵证明回退了也全绿） | 补成 8 条矩阵全捕获：4 空格缩进、多行字符串伪键、CRLF 幂等/不混排、重复条目取最后一条、读失败原因、注册回滚、守卫的两条绕过 |
| P3 | 家目录 patch / `--patch` 覆盖**会盖过** profile 层 → 面板报"写入成功"但开关不生效 | 检测到家目录 patch 里也有本插件时，面板顶部给出**明确警告**（说明"它盖过 profile 层，要改的是那一层"），不再让人对着"点了没反应"发呆 |
| P3 | 写入重试是**同步忙等**：实测一次失败写会把宿主事件循环按住 **212ms** | 改成 `await` 异步重试（`setTimeout`），不再阻塞宿主的其它请求 |
| P3 | config 第一层是**列表**时会写出宿主解析不了的 YAML；带引号 / 带行尾注释的条目 id 会被误报"没有这个条目" | 列表开头**拒绝写入**并说明原因（宁可不写）；条目 id 允许加引号与行尾注释 |

其余一并修掉：CRLF 下"同值写入"永远判不出来（每点一次都重写并备份）→ 比较忽略行尾、写回保持原行尾不混排；
同名条目有多条时改为**取最后一条**（DSH 自己用 `findLast`，否则面板改的和平台生效的不是同一条，点了没反应）；
临时文件失败时不再改名攒 `.orphan` 垃圾；读失败不再被说成"没有配置文件"；路由注册到一半失败会**回滚**已注册的；
POSIX 下临时文件按 `0600` 创建（patch 里有 `apiKey`，不能让 rename 把权限带宽）；
客户端此前**没有渲染文档承诺的「非默认」徽标** → 现在渲染了。

#### 真机事故与修复（发布前抓到，必须记下来）

> **现象**：装好 v0.6.0 后重启官方桌面端，**整个应用起不来**，弹窗写着
> `web boot: 1 entry did not activate` / `dsh-qq-onebot-bridge: import failed: exports is not defined`。

- **根因**（读加载器源码定位，不是猜）：客户端 bundle 是用**经典 `<script>`** 注入页面的，
  所以页面作用域里**没有 `exports` / `module`**；而模块加载器只把 `factory(require)` 的**返回值**
  当模块导出（`@deepseek-ai/dsh-client-modules/lib/client.js:683`）。
  第一版 bundle 照抄了 dshmarket 的**调用写法**却漏了它**开头那两行自带的 CJS 垫片**
  （`var module = { exports: {} }; var exports = module.exports;` —— 平台上 12/12 个客户端
  bundle 都有这两行），于是 `exports.inject = …` 在经典脚本里直接抛 `exports is not defined`，
  而这个错误发生在**插件激活**阶段，DSH 判定"有 1 个条目没起来"并拒绝启动。
- **修复**：bundle 里补回那两行垫片（并写明为什么），其余逻辑不动。
- **为什么单测没拦住**：原来的客户端冒烟测试**在桩里提供了 `module`/`exports`**
  （`new Function('window','module','exports','require', …)`），等于把真实加载器**没有**的东西
  喂给了 bundle —— 测试比现实更宽松，于是漏过。现在测试桩严格照抄真实契约：
  作用域里**只有 `window`**、`factory` **只传一个 `require`**、导出**取返回值**；
  并新增一条"自带 CJS 垫片"的断言。把垫片两行删掉再跑，会**当场复现** `exports is not defined`
  —— 这条守卫是有效的，不是摆设。
- **教训**（写给未来的自己）：照抄生态里的写法时，要抄**完整的契约**（包括那些看起来"多余"的一两行），
  并且测试桩必须先对齐**真实加载器**的行为，否则桩越宽松，漏得越狠。

> **同一轮真机验证抓到的第二个问题**：面板在官方桌面端里把 profile 认成了 `web`。

- **根因**：**两种宿主两种传法** —— CLI 是 `dsh web --profile desktop`（取 `--profile` 的值），
  而官方桌面端**根本不传 `--profile`**，它把 **profile 目录当位置参数**塞进命令行：
  `"DeepSeek Harness.exe" --expose-internals <…dsh-desktop-host/lib/index.js> <…\app.asar\dsh> C:\Users\<user>\.dsh\profiles\desktop <runtime> …`。
  第一版只认 `--profile`，于是在桌面端里回落成 `web` —— 用户明明看着桌面端，点开关却会去改 **web profile** 的配置。
- **修复**：`resolveProfile()` 先认 `--profile`，再认"命令行里以 `…/profiles/<名字>` 结尾的位置参数"（桌面端这条），
  都不匹配才回落 `web`；认不出时**记一条 warn**，并且面板顶行**始终显示它要写的那份配置文件路径**——
  用户随时能一眼看出它指向对不对。
- **验证**：桌面端宿主（`DeepSeek Harness.exe` 的 `dsh-desktop-host` 进程）现在返回
  `profile = desktop` / `patchFile = …\profiles\desktop\cordis.patch.yml`，7 组 59 开关；CLI 宿主仍按 `--profile` 走。
  新增 4 条断言钉住这两种传法（含末尾带斜杠的路径）。

#### 测试

- 新增 `settings-unit`（**86 条**）：纯逻辑（分组快照、patch 文本的读/改/插入/幂等/拒绝非布尔/没有本插件条目时如实拒绝）+
  路由契约（用假 webServer 捕获注册、直接调 handler：GET 形状、POST 只允许白名单布尔键、405、写后 `pending` 如实为真、
  留备份、**dispose 后能重新挂载**）+ **客户端 bundle 冒烟**（在桩掉的 `__ModuleLoader__` 里真的执行一遍：
  确认导出 `inject/apply`、注册 `settings.section` 且 id=qqai，并钉住它 fetch 的路由名与服务端注册的一致）。
  - 写测试时踩到一个真问题并修掉：`mountQqAiPanel` 原本**没有把 `env` 作为可注入项**，测试会去读/写**真实 profile**——
    现在 env 可注入 + profile 目录可注入，测试全程沙箱在临时目录，**完全不碰真实 profile**（断言用的是临时文件）。
- `static-unit` 21 → **26**：新增四条结构守卫（`./client` 导出、`dsh.client` 的 platform/inject、bundle 被
  `__ModuleLoader__` 包裹、插件入口确实把面板挂到 webServer 上）。
- 全量 **56 套 / 3724 断言全绿**。

#### 已知边界（不藏着）

- 面板页需要在**宿主带 webServer** 时才有入口；首次装好/升级后要**重启一次宿主**让路由挂上（之后改开关就是热重载）。
- 改开关会让 DSH 热重载该插件条目 → **QQ 桥会短暂重连**（一两秒）；若宿主关了热重载，则重启宿主后生效。
- DSH 原生「插件」设置页里的表单只渲染 `.volatile()` 字段，本插件**没有**加（面板已覆盖常用项），
  所以那一页看不到这些开关——这是刻意的取舍，不是漏做。
- 真机待验证：浏览器里首次打开该页的实际观感与深浅色；面板与 `dshmarket` 同页共存时的导航顺序（`order: 45`）。

## v0.5 系列 —— 看得见 · 找得回 / See it, find it
### v0.5.9（2026-10-03）— 兼容 DSH 0.2 与官方桌面端 / DSH 0.2 & desktop client

> 起因是一次**静默停摆**：DSH 运行时升到 **0.2.0-rc.2** 之后，profile 因为插件的 peer 范围只声明到
> `^0.1.x` 而**直接拒载**——`dsh: skipping profile bundle "dsh-qq-onebot-bridge": … is incompatible with dsh 0.2.0-rc.2`，
> 于是 QQ 桥从 9/27 起就没再跑过（6700 无人监听，但没有任何"报错"落到常见日志里，
> 只在 profile 启动输出与插件管理器的操作日志中）。官方新出的桌面端（Electron 版
> `DeepSeek Harness.exe`，跑 `~/.dsh/profiles/desktop`）用的是**同一个运行时版本**，所以两边一起修。

#### 兼容

- **peer 范围放行 `^0.2.0-rc.2`**：六个 `@deepseek-ai/dsh-*` 都加上（旧范围保留），CLI/web 宿主与官方桌面端**都能直接加载，不再需要 `dsh plugin allow-version` 豁免**。
  - 真机验证：先 `revoke-version` 撤掉豁免（`version-exemptions` 回到 `{}`），`dsh --profile web --dump-config` **不再 skip**、插件在树里；再另起一个宿主实例，**6700 正常监听**、`qq-runtime.json`/`qq-trace.jsonl` 立即刷新（= 桥真的起来了）。
  - 兼容性预检不是只看版本号：在 0.2.0-rc.2 里真 import 了一遍，并逐项确认插件用到的接口仍在——`dsh-llm.createUserMessage`、`dsh-tools.defineTool`、`dsh-session.SessionId`、`ctx.agents.create/resume/get`、`ctx.on('session/event')`（该事件在 dsh-agent-loop / dsh-api-session-controller 等包里仍存在）、`agentDefaultModel`。
- **OneBot 端口被占：不再崩溃、不再卡住宿主启动**（web 宿主与桌面端必然会同抢 6700）。旧实现是三连击：`start()` 返回 void、`this.emit('error', …)` 没有订阅者 → EventEmitter **直接抛出未捕获错误**（历史上那次 EADDRINUSE 崩溃就是这么来的）、等 `'listening'` 的 Promise **永不 resolve**（宿主启动卡死）。现在：
  - `OneBotServer.start()` 返回 `{ ok: true }` 或 `{ ok: false, code, reason }`——**永不抛、永不挂**，`'error'` 只在真的有人订阅时才 emit（否则走 `server-error`）；
  - 插件入口按 **15 秒退避重试**，并说清是哪一种失败（`EADDRINUSE` 时直接给排查方法：控制台端口摘要，或 `netstat -ano | findstr :6700`）；
  - 绑不上时**先不启动桥**——避免"两个实例都在跑定时任务/回消息"的假象；
  - 真机三实例实测：占用者被杀后，**重试的那个在 15 秒内自动接管 6700 并启动桥**（产物时间戳当场刷新）。
- `stop()` 对"从未监听成功"的实例同样安全，重试路径反复 start/stop 不会泄漏 Server。
- 一台机器**只允许一个实例托管 QQ 桥**：两个 profile 都装是对的（谁先起谁服务），另一个如实说明并在端口释放后接管；想固定由某一个托管，就把另一个 profile 的 `port` 改成不同值。

#### 文档

- README（中英）新增「官方桌面端（DSH Desktop）」一节：桌面端跑的是应用独占管理的 `desktop` profile、与 CLI **同版本运行时**、装法与配置位置（`~/.dsh/profiles/desktop/cordis.patch.yml`，不要写进仓库），以及"一台机器只托管一个 QQ 桥"的口径。
- **控制台「打开扫码页」不再撞「token 无效」**（真机踩到）：那个按钮原来指向 `http://127.0.0.1:6099`，而 NapCat 的 WebUI **自己也有 token**（存在 `bootmain/config/webui.json`）——不带 token 点进去只会被 NapCat 拒。新增 `GET /api/napcat/webui`：从 `napcatQr` 推出同一份配置目录去读 token，返回可直接打开的地址；接口与控制台其它接口一样受 token + 同源校验保护，响应只有 `ok/url/reason` 三个字段（token 不写运行快照、不进诊断包、不落日志），读不到就如实说明原因。UI 在 6099 监听时自动把带 token 的地址填进按钮。

#### 修掉 4 条静默分支（违反硬约束①，全面检测时抓到）

在真机上收到"回复没有语音"的现象后按 trace 排查，发现 **TTS 的三条分支（没配 key / 没配参考音频 / 合成或发送失败）只写 `debugLog`，trace 与控制台里一个字都没有**——用户无从判断"为什么没语音"。同类还查出三处：

- **TTS**：三条跳过分支与失败分支全部写 `stage:'tts'` 的 trace；成功也记一条（带 KB 与格式）。**同一原因 5 分钟内只记一次**，避免本地 GPT-SoVITS 没启动时每次回复都刷屏。
- **投票结果公布**：没有可用连接时记 `stage:'vote'` + 真实原因（以前只有 debug 日志）。
- **每日日报**：没有可用连接时记 `stage:'report'` + 真实原因。
- **推送通知**：`notifyEnabled=true` 但没配 `notifyPushUrl`/`notifyToken` 时记一条 `level:'warn'`——配置类错误运行期不会变，**每个进程只提示一次**，不会灌满 trace。

#### 独立对抗性审查（针对 v0.5.9 两个提交）发现并修掉的问题

- **P1 · `start()` 会把正在监听的 socket 变成孤儿**：v0.5.9 那版"关闭上一次没绑上的实例"只处理了失败分支，于是**重复调用 `start()`**（超时重试路径）会另起一个 Server → EADDRINUSE，同时把**真正在监听的那个**丢掉：端口一直被占、桥却没起来，日志还反过来赖"端口被另一个进程占用"；`stop()` 之后端口仍然占着（审查用探针实测复现）。现在 `start()` **幂等**（已监听直接返回 `ok:true, already:true`，绝不去关健康实例）、同一 tick 的并发调用**复用同一个 Promise**、失败分支就地关掉没绑上的实例、**超时不再等于失败**（先看 `address()`，慢机器上刚绑成功也算 ok）。新增四条回归断言（含"`stop()` 之后端口能重新绑定"）——旧实现下这几条会直接红。
- **P2 · 重试回调漏 catch + 半初始化**：`setTimeout` 里的 `void tryServe()` 没有 catch（Node CLI 宿主上未处理 rejection 是致命的）；`bridgeStarted` 在 `bridge.start()` 之后才置位，中途抛错会让 dispose 不再管它。现在 `.catch(logger.error)` + `try/finally` 置位。
- **P2 · 稳态日志刷屏**：另一个实例长期占着端口时，旧实现每 15 秒一条 error（≈5760 条/天，会把真错误淹掉）。现在只在第 1 次与每 10 分钟各记一条。
- **P2 · `napcatWebui()` 忽略 `webui.json` 里的端口**：用户改过 NapCat WebUI 端口时会给出一条死链。现在以文件里的 `port` 为准（缺失才回落到配置）。
- **P2 · 静态守卫是假的保障**：旧守卫只 grep 字面 `^0.2.`，"下次升到 0.3 照样绿"。现在以 `package.json` 的 **`dsh.supportedRuntimeLines`（唯一真源）** 为准：每声明一条线，六个 peer 范围都必须覆盖它，且六个 peer 一个都不能少——升运行时线必须同步改表，否则测试直接红。
- **P3 · 路径推导未校验**：`qrcode.png` 这种相对路径会被 dirname 两次算到别处、读出不相干文件的 token。现在要求 `napcatQr` **是绝对路径且至少三层**，否则如实拒绝。
- **P3 · UI 每 4 秒把带 token 的链接覆盖掉**（既有缺陷，v0.5.9 的修复差点被它吃掉）：状态渲染里另有一行把 `napcatLink.href` 写成不带 token 的地址。已删除该行，链接只由"扫码页按钮"那段统一负责。
- **P3 · 文档**：删掉"给另一个 profile 改个端口"这条**危险建议**（两个实例共用同一份 `cwd`，同时读写会互相覆盖状态文件、注入还会发两遍），改成"只在一个 profile 里启用 / 连 `cwd` 一起分开"；并补上"手动装本地目录必须同时加进 `dsh.profile.bundles`，否则只装依赖不会工作"（本机实测）。

#### 修掉一个假信号：空闲被误报成"桥没了"

运行快照（`qq-runtime.json`）原本**只在有活动时**写（节流 2 秒），于是机器人空闲十几分钟后文件就陈旧了；而控制台的存活判断是 `ageSeconds < 900`——一个完全健康的桥会被显示成**「无快照」**。现在 `start()` 会装一个 **60 秒心跳**（unref，注册在 `this.timers` 里，`stop()` 自动清掉）持续刷新快照：**"快照陈旧"从此真的代表"桥不在了"**，而不是"只是没人说话"。测试把 `runtimeHeartbeatMs` 调小来证明"零流量时文件也在动、`stop()` 之后立刻不动"。

#### 修掉「群里 @ 了机器人却不回消息」（真机现场抓到，最要命的一条）

真机现象：在群里 @ 机器人发命令，**一个字都不回**，而 trace 里只有一句 `群聊未 @ 机器人`。

- **根因**：`replyOnlyWhenMentioned` 只认 `at` 段，但**有些 QQ 客户端把 @机器人 发成纯文本**——真实入站记录里，别人发的 @ 是 `ats=[3030…（机器人号）]` 的真 at 段（能被识别），而用户自己那条是 `atMe=false, ats=[]`、正文写的是 `@机器人昵称 /打卡名册`。桥于是把它当成"没 @ 机器人"**静默丢掉**（群里没有任何提示，只有 trace 里那一行）。
- **第二个坑（差点只修一半）**：命令是**行首锚定**的。光把门禁放行还不够——`@小鲸鱼 /打卡名册` 里 `/打卡名册` 不在行首，命令会被当成聊天内容丢给模型。所以命中之后还要把 `@名字` 从正文里摘掉。
- **第三个坑**：摘除必须发生在 `const text = message.text.trim()` **之前**（那是命令解析用的那一份）。第一版把归一化写在门禁里（更靠后），实测：门禁放行了、命令依然没执行，消息走了 agent。
- **修法**：新增 `mentionsByName()`（**字面量**匹配，昵称里的 `.` `+` `(` 不会当正则元字符）与 `stripMentionName()`；桥开机后按需学一次自己的**昵称**（`get_login_info`）与**每个允许群的群名片**（`get_group_member_info`），也可用新配置 `mentionAliases` 手填别名兜底；命中时 trace 明写"文本 @ 命中机器人名「…」（这条没有 at 段）"，没学到名字时把提示附在"未 @"那条原因后面。
- **真机验证**：改完重启桥，注入一条与用户完全相同的消息（`atMe=false`、正文 `@机器人昵称 /禁言名单`）→ trace 出现 `[mention] ok=true 文本 @ 命中机器人名「机器人昵称」`，命令被正确识别（`[ops] 禁言名单…`）。
- 配置键 223 → **224**（`mentionAliases`）。

#### 机器人掉线不再无声（真机现场抓到）

真机现象：15:28 桥收到 `bot_offline`，但**谁都不知道**——trace 里只有一句 `未处理的 notice：bot_offline/`，控制台的「机器人」胶囊靠 6700 的 ESTABLISHED 连接数判断（socket 还挂着时照样显示在线），用户看到的现象就是"发消息没人理"。

- **`bot_online` / `bot_offline` 现在有明确处理**：写一条带真原因的 trace（离线是 `warn` 级，并点名可能的原因：QQ 掉线／同一账号在别处登录，例如同一客户端又开了一个实例抢了会话）、更新运行快照的 `botOnline`/`botOnlineAt`、走推送通知（开了才发）。
- **顺手修掉一个真 bug**：`diagnose.mjs` 的「机器人已连上桥」一直在读 `snapshot.botOnline`，而插件**从来没写过这个字段**——验收台上这一项**永远是红的**（明细永远显示"无 ESTABLISHED 连接"）。现在插件写它，且"未知"时回落到 6700 的连接数；`bot_offline` 时即使 socket 还挂着也不算在线。
- 控制台「机器人」胶囊把两个来源合起来看，并把离线原因写进 title。

#### 看管理员：`/管理员名单` + 控制台显示"机器人自己是不是管理员"

起因是 `/设管理` 那次真实失败：用户填的号不在群里，NapCat 只回 `retcode 1200 get Uid Error`——**得先能看见"该填谁"和"机器人有没有权限"**，这两件事以前都得靠猜。

- **新增只读命令 `/管理员名单`**：读一次群成员列表，只列**群主 + 管理员**（群主在前，同档按等级降序），机器人自己那行标「（我）」——一眼看出 `/设管理` 能不能成；一个管理员都没有时如实说明（不编造）。走只读查询同一条红线：注入/回放回合**不访问 QQ** 并说明原因，私聊里明确"只能在群里用"。（接线时踩到一次：命令词必须同时加进 `#handleOpsCommand` 的**入口白名单**，否则整条命令被提前 return 掉——现在有测试盯着。）
- **运行快照新增 `botAdmin`**：机器人在各群的管理员状态，来源只有 NapCat 的 `group_admin` 通知，**超过 10 分钟保鲜期就标 stale**（不把过期信息当事实）。
- **控制台「群配置」面板**每个群多一段「机器人：是本群管理员 / 不是本群管理员（写命令会被权限自愈拦下）/ 未知」，并且**只有管理员状态、还没有会话的群也会列出来**——否则"机器人在这个群里不是管理员"根本看不到。
#### 命令粘住参数不再悄悄交给模型（真机现场抓到）

真机现象（16:01）：用户发 `/设管理17xxxxxxxx`（**中间没有空格**）——命令正则要求空白分隔，于是**匹配不上**，消息被当成聊天**交给了模型**（trace：`[agent] 会话续接 → 已转交 agent`），白烧一个模型回合，用户看到的现象是"设管理失败了"。

- 这类写法现在会被识别出来并回一句明确的用法提示（`应该写成「/设管理 …」`），**并且不交给模型**——模型手里有工具，把一个像命令的串丢给它是有风险的。trace 里写明"命令一律空白分隔，没有交给模型"。
- 词表 `OPS_ARG_WORDS`（哪些命令需要参数）**必须与命令正则同步**：漏一个词就等于那个命令粘了参数后照样落到模型。新增静态守卫盯着它（`static-unit`），该守卫上线时即发现标签「设置管理员」被误当成命令词。
- 带空格的正常写法完全不受影响（有断言钉住）。
#### 写操作失败不再把原始报错糊到群里（真机现场抓到）

真机现象（15:50）：群里发 `/设管理 10009`（一个**不在群里的号**），机器人回的是

```
⚠️ 处理失败：OneBot action set_group_admin failed: {"status":"failed","retcode":1200,"data":null,"message":"get Uid Error"}
```

——原始 JSON 直接贴进了群，既看不懂（用户以为"机器人坏了"），也把 API 负载泄露到了聊天里；而且这条路径**连 `[ops]` 事件都没写**，trace 里查不到这次尝试。

- 新增 `#actionErrorReason()`：把 NapCat 的报错翻译成中文真原因——`retcode 1200 / get Uid Error` → "NapCat 解析不到这个号的 uid——他很可能不在这个群里（或不是真实 QQ 号）。请用 @ 选中群内成员，或写他真实的 QQ 号"；权限类 retcode（1400/1401/1403/1404）→ "机器人可能不是本群管理员（或群内权限不足）"；其它 → 截断后的原文（最多 160 字）。
- 三条 v0.5.8 写命令（设/撤管理、邀请策略、加群方式）走 `#runOpsAction()`：失败时回中文真原因 + **写一条 `stage:'ops', level:'warn'` 的 trace**，绝不抛给兜底。
- **兜底也改说人话**：`#onQqMessage` 的 catch 以前直接把 `error.message` 贴进群，现在同样过翻译——这一条覆盖了全部 ~28 个 `gate.run` 调用点，不只是这三条命令。
#### 真机逐条验证六条 v0.5.8 群命令（干跑，零出站）

用控制台的注入通道把六条命令逐条喂进真实链路（`injectEnabled=true`，桥每 2 秒轮询；`injectDryRun=true` 所以一个出站帧都没发）。六条**全部走到各自的 `[ops]` 分支**，白名单与权限判定通过，回复被拦下并完整记进 trace（`注入回合的回复已被拦截（dry-run，未发送）：…` 后面就是用户本会看到的原文）：

| 命令 | trace 里的真实原因 |
|---|---|
| `/打卡名册` | `打卡名册：注入/回放回合不访问 QQ` |
| `/申请` | `申请拉取未执行：注入/回放回合不写 QQ（injectDryRun=true（干跑））` |
| `/邀请策略` | `邀请策略只认这四种：关/需审核/免审核/百人以下`（给用法，没误改） |
| `/加群方式` | `加群方式要 1–5 的数字：收到「」` + 用法 |
| `/设管理 10009` | `设置管理员未执行：注入/回放回合不写 QQ（干跑）` |
| `/撤管理 10009` | **修正前**：`设置管理员未执行…`（与设共用标签，用户会以为发错命令）；**修正后**：`撤销管理员未执行…` |

- 结论：**v0.4 红线完好**（同步阶段 0 次出站被拦 + 连回复都被拦下），每条拒绝都带真原因。
- 抓到并修掉：设/撤共用「设置管理员」标签 → 现在按方向给 `设置管理员` / `撤销管理员`（`ops-bridge-unit` 新增 J8/J9 钉死）。
- **仍未做**：真实执行（真要调 NapCat 的写操作）。干跑只能验识别/权限/计划/文案/零出站；真实参数由 `ops-bridge-unit` 的线路级断言（J1/J3）覆盖，真机执行需在群里发命令，或临时关掉 `injectDryRun` 并重启宿主。

#### 测试

- `onebot-api-unit` 44 → **61**：端口冲突四条（`ok:false`、错误码 `EADDRINUSE`、走 `server-error` 而**不抛 uncaughtException**、冲突之后原实例照常工作）+ "同一个 server 连续两次 start() 结论一致" + **幂等/孤儿化回归四条**（已监听时重复 `start()` 返回 `already:true`、同一 tick 并发复用同一个 Promise、`stop()` 后端口能重新绑定、并发路径同样释放端口）——最后四条在审查发现的旧实现下会直接红 + **文本 @ 七条**（`mentionsByName`/`stripMentionName` 的命中、字面量、无 @ 不认、空值安全、摘除后命令回到行首、名字不匹配原样返回）。
- `ops-bridge-unit` 96 → **185**：v0.5.8 六条命令的线路级断言 + **文本 @ 七条**（配置别名 → 命令照常执行、放行原因进 trace、命中不了仍忽略且零出站、忽略原因是"群聊未 @"、未配别名时学到的昵称同样能认、学习只读一次、缓存生效 + 设/撤标签分开）。
- `control-unit` 152 → **161**：新增「NapCat WebUI 带 token 地址」六条（接口要 token、透传 `ok/url`、不支持时如实说明、`napcatWebui()` 的四种分支）。
- `commands-unit` 72 → **78**：新增 TTS trace 四条（本地打不通时必须有 `ok:false` 的 tts 事件、原因含"语音合成/发送失败"、同原因不重复刷、云端缺 key 时点名 `ttsApiKey`）+ **运行快照心跳两条**（桥跑着时无消息也持续刷新快照；`stop()` 之后不再刷新——这样"快照陈旧"才真的代表桥不在了，而不是"只是没人说话"）。
- `members-unit` 104 → **111**：`/管理员名单` 的格式化（群主在前、同档按等级降序、机器人标「（我）」、没有管理员时如实说明、空值安全）。
- `perf-unit` 67 → **71**：群配置面板的机器人管理员状态（过期通知显示为"未知"、只有状态没有会话的群也列出来、没收到过通知时不编造）。
- `static-unit` 17 → **21**：新增守卫三条——六个 `dsh-*` peer 一个不少、声明了支持的运行时线、**每条声明的线都被 peer 范围覆盖**（以 `package.json` 的 `dsh.supportedRuntimeLines` 为唯一真源）。
- 全量 **55 套 / 3633 断言全绿**。

### v0.5.8（2026-09-14）— 群权限补全 · 申请补拉 · 权限自愈 / Admin & requests

> 这一版继续"先用真机探针把参数摸准，再动代码"：4 个新动作的参数形状全部来自静态读本机 NapCat 包
> （QQ 9.9.32-50969 / NapCat 4.18.19），而且**有两个能力被探针挡下来了**——见「按住的」一节。
> ⚠️ 这 4 项尚未在登录状态的真机上跑过（本机 NapCat 当时未登录），验证清单见文末。

#### 新增

- **管理员设置 `/设管理 @某人` · `/撤管理 @某人`**（`set_group_admin`）：探针挖出一个会咬人的细节——`enable` **省略时 NapCat 按 `false` 处理**（`!!undefined === false`），也就是"字段没写全"会**静默把人撤成普通成员**。所以 `planGroupAdmin` 强制要求显式布尔值，缺了直接报错，并且**永远把 `enable` 发给 API**；测试专门钉住"`enable === false` 时字段必须存在"。
- **邀请策略 `/邀请策略 关闭|需审核|免审核|百人以下`**（`set_group_member_invite_policy`）：映射到探针读到的四个字面量 `disabled` / `require_approval` / `no_approval` / `no_approval_under_100`。
- **加群方式 `/加群方式 1–5 [问题=… 答案=…]`**（`set_group_add_option`）：`add_type` 是 QQ 的裸数字，NapCat 官方 schema 只写「加群方式: number」、**没有枚举**；探针确认底层只在 `4/5` 时写问题/答案（4 带答案、5 只写问题），所以 1–3 一律不夹带这两个字段，文案里也不替用户"翻译" 1/2/3 的含义。
- **打卡名册 `/打卡名册`**（`get_group_signed_list`，只读，随 `opsReadEnabled`）：今天谁打了卡、第几名、几点打的。探针确认 `rank = (signInRank-1)/2+1` **可能是小数**，所以渲染四舍五入、排序用原始值；时间戳离谱（如 0）不会显示成 1970。
- **申请补拉 `/申请`**（`get_group_system_msg` + `get_doubt_friends_add_request`）：把离线期间错过的入群申请、入群邀请、可疑好友申请**主动拉回来**并入待审队列，复用既有的 `/待审` `/同意 N` `/拒绝 N`——事件驱动只能处理"当时在场"的请求，管理员不在线就永远错过。两个接口形状完全不同，分别归一化；`checked === true`（已处理）的条目不回灌，同一 `flag` 只并入一次，队列满时如实说明。
  - 关键一环是探针挖出来的：`set_group_add_request` 的 `flag` 在实现里是 `find(i => i.seq === flag)`，而 `get_group_system_msg` 的 `request_id` 正是 `+seq`——所以**主动拉回来的申请真的能审批**，不是只能看。
- **权限自愈（`group_admin` 事件）**：机器人自己被设/撤管理员时记账（`群号 → true/false`，来源只有这个事件，不知道的群绝不猜），可选在群里说明（`adminWatchEnabled`）；已知被撤管理员后，写命令（批量踢/待办/文件/传图/群名/群权限/历史可见…以及 `/mute` `/kick` `/公告` 这些老管理命令）**直接给中文真话并零调用**，而不是让 API 去撞墙报一句模糊错误。恢复管理员后自动解除。

#### 修掉一个真缺陷（注入红线）

- **注入/回放回合 `/同意` 会真的批准人**：`set_group_add_request` 的参数里只有 `flag`，没有 `group_id`/`user_id`，落不进 scoped dry-run 的拦截条件——与 v0.5.1 修的 `/ocr`、`/好友` 是同一类洞（当时那条 P1 没覆盖审批路径）。现在 `#handleVerifyCommand` 与 `#resolveJoin` 都显式判断离线回合，直接拒绝执行并写 trace；新测试 `O1`–`O5` 用"注入回合 0 出站 + 队列条目仍在（没有被静默消费）"钉住它，其中 `O5` 专门覆盖**第二层防线**（申请人答对验证题的自动放行路径不经过命令处理，只能靠 `#resolveJoin` 自己兜）。

#### 独立审计发现并修掉的隐私问题（**发布前拦下**）

一轮独立隐私审计（只读、扫工作树 + **全部 git 对象**）在**已提交的代码里**抓到三处：

- **`control/lib/supervisor.mjs` 注释里有作者机器的真实应用路径**（`D:` 盘下一个具体安装目录的 `QQ.exe`）。它已进入**可达历史**（由 v0.5.6 的提交引入）并会随 `git archive` 打进发布包；`privacy-unit` 却全绿——因为它的路径规则只认 `C:\Users\<名>`/`/home/<名>`/`/Users/<名>`。现已改为不含任何本机路径的描述。
- **`control/启动控制台.bat` 硬编码了作者机器上的 node 安装路径**（D 盘下一个非默认目录，本机真实存在）。它之所以从没被扫到：`git ls-files` 对**非 ASCII 文件名**输出 C 引号形式（`"control/\345\220\257…bat"`），旧的测试直接拿这串去 `readFileSync` → ENOENT → `catch { continue }` **静默丢文件**（128 个被跟踪文件只扫到 126 个）。现在改成通用的 `%ProgramFiles%`/`%LOCALAPPDATA%` 候选 + `QQ_BRIDGE_NODE` 环境变量兜底。
- **`test/control-unit.mjs` 里有一条真机 token 形态的字符串**（`?token=<44 位随机串>`）。真机核对：它不在 `qq-control.json`/`qq-runtime.json`/调试日志里，**当前不是活 token**，但仍应清理——已换成明显的假值。

**隐私套件本身也一并加固**（`test/privacy-unit.mjs` 33 → 36 断言，8 个结构性盲点全部堵上）：

- `git ls-files -z`（+ `core.quotePath=false`）→ 中文文件名不再被丢；新增断言"每个被跟踪文件都被扫到"（读不出来就点名失败）与"非 ASCII 文件名也在清单里"。
- 不再按扩展名白名单过滤（旧实现漏掉 `LICENSE`、`.sh/.ps1/.toml/.env` 与无扩展名文件）；二进制内容按 latin1 再扫一遍。
- **新增"盘符绝对路径"规则**：判据是**"这台机器上真的存在"**（`existsSync`），比"形状像路径"精确，也不会误伤文档里的虚构示例（`X:\qq-history`、`D:\evil`、`C:\NapCat\…` 都不存在）；`C:\Windows\`/`C:\Program Files\` 这类系统路径豁免。
- 密钥形态新增 `?token=<长随机串>` 与"赋值型长密钥"两类；占位符放行改成**显式白名单**（旧实现用 `/your|example|xxx/` 一刀切，会吞掉任何恰好含这些子串的真密钥）。
- schema 密钥字段默认值检查同时认单/双引号，并点名要求 `sttApiKey`/`ttsApiKey`/`imageGenApiKey` 必须被覆盖（旧实现只认单引号，双引号写法整片隐形而"至少 4 个"照样通过）。
- 私有号清单：本机明明有 profile 却收不到号时**判失败而不是静默 SKIP**；收集规则扩到"配置块里身份类键（qq/uin/user/admin/owner/group/chat/notify/friend）的纯数字值"（第一版收得太宽，把 `fileSendMaxBytes` 的字节上限当成了 QQ 号，套件当场误报 5 处，已收紧）。
- **新增可选的"历史/对象库"扫描**（`DSH_QQ_PRIVACY_HISTORY=1`）：工作树干净 ≠ 历史干净。它会遍历 `git cat-file --batch-all-objects` 的全部 blob，报告私有号、本机用户名路径与"真实存在的绝对路径"。真机现状：私有号 **0 命中**；3 个**悬空** blob 含家目录路径；9 个 blob 含真实路径（历史版本的 `supervisor.mjs` + 那些悬空对象）。

> 历史残留的处理说明：悬空对象可用 `git gc --prune=now` 清除；**已进入可达提交的**那处路径只能靠改写历史（会改所有提交哈希）。这两件事都会删除数据，按本项目规矩**不在未确认前自行执行**。

#### 顺手修掉的其它问题（自查发现）

- **控制台「群配置页」漏接新开关**：运行快照的 `features` 是显式白名单、面板开关表也是静态列表，两边都没加 v0.5.8 的键 → 面板会永远显示"关"。两处都补上（`opsAdminEnabled`/`opsInvitePolicyEnabled`/`opsAddOptionEnabled`/`requestSyncEnabled`/`adminWatchEnabled`），并加断言钉住"快照里有、面板里有"。
- **补拉回来的申请会被当成"答题"**：这类条目没有验证题（申请人当时不在线），他随后私聊说句话会被误判成答题、回一句空的「答案不对哦」。现在只认真正发过题目的条目。
- **文档口径**：仓库根目录那个**被跟踪**的 `cordis.patch.yml` 是安装用的 bundle patch，与 README 让用户改的 profile 配置文件**同名**——用户若改错文件填密钥就会提交进仓库。已在 README（中英）与根文件里都加了醒目的"别填这里"提示。
- `.gitignore` 补齐 `qq-*.md`/`qq-*.bin`/`qq-*.html`（规则既然按扩展名兜底，就不该只兜一半）。

#### 独立对抗性审查发现并修掉的问题（P1/P2）

同一轮还跑了一次独立对抗性代码审查（只读、禁改文件/动 git），它抓到的真问题：

- **`/撤管理` 可能反向提权**（P1）：动作判定原来写的是 `raw.includes('设管理')`，于是 `/撤管理 10009 设管理员`（参数里出现那三个字）会被判成"设"——机器人**给**对方管理员还回一句"已设置"。现在用正则真正匹配到的那个词决定，并加了两条回归断言（含"反过来也一样"）。"用整行子串判断语义"这种写法本身就是要避免的。
- **注入/回放的 `group_admin` 事件方向反了**（P2）：`enable` 原来取 `notice.adminSet !== false`，而 `adminSet` 只有 `parseNotice` 会补——注入器与回放管线送进来的 notice **没有**这个字段，`undefined !== false` 即为 `true`，于是一条 `'unset'` 被记成"已恢复管理员"并推播（失败方向是"放开"，正好错在危险的一侧）。现在以 `sub_type` 为权威判据，两者都缺失时**不记账、不猜**并写 trace。
- **`/申请` 的"跳过"用了假原因**（P2）：`checked`/缺 ID 的条目在归一化阶段就被过滤、根本没进计数，于是那句"已处理过或缺少可用的 request_id"解释的全是"队列满"；而且队列满的提示只在进入循环前 `room === 0` 时才打印。现在 `raw`/`invalid`/`already`/`full`/`failed` 各记各的，文案对着各自的原因说。
- **审批闸门把 `injectDryRun:false`（"真发"模式）一起拦了**（P2）：全项目其它注入闸门都尊重这个开关（`/群打卡` 有 B5 断言），只有审批路径漏了；顺带它还把**零出站**的 `/待审` 也连坐拦掉。现在 `/待审` 在闸门之前处理，写审批统一走 `#approvalOffline()`（离线 **且** 不是真发模式）。
- **`/打卡名册` 的名次与自己的排序矛盾**（P2）：`rank = (signInRank-1)/2+1` 可能是小数，四舍五入后前三个签到的人显示成"第 1 名 / 第 2 名 / 第 2 名"（重复且没有第 3 名）。改用排序后的**位置**（排序仍按原始 rank）。
- **配置说明不实**（P2）：`requestSyncCount` 原文声称"NapCat 按最近 N 条搜索 flag"——实际 `set_group_add_request` 根本不发 count、NapCat 内部写死 100，所以拉超过 100 条只会拉回**批不了**的条目；说明已改正、取值上限夹到 100。另外六个新命令都还要求 `groupOpsEnabled`（总开关先答"工具箱未启用"），四个新开关的说明都补上了这一句。
- **P3 级**：`/退群` 被"权限自愈"用假理由拦住（`set_group_leave` 不需要管理员）；管理员变动播报没走 `allowGroups` 白名单（与欢迎语/戳一戳/防撤回口径不一致）；"我已被撤管理员"这条判断没有保鲜期（万一下一条事件没收到就会永久拦住写命令）→ 现在 10 分钟后按"不知道"处理，交给 API 去试；`verifyEnabled=false` 时 `/申请` 改成就地预览**不入队**（否则条目 24 小时后才过期、队列被占满而"处理"命令又不存在）；`/加群方式 5` 给了答案会被静默忽略、`/拒绝 all` 不报失败原因——都改成如实说明。

#### 测试

- `ops-unit` 106 → **149**、`ops-bridge-unit` 96 → **160**、`onebot-api-unit` 33 → **44**、`privacy-unit` 33 → **36**、`perf-unit` 66 → **67**；全量 **55 套 / 3557 断言全绿**。
- 新断言覆盖：`enable` 显式性与"缺 enable 必须报错"、邀请策略四个字面量、`add_type` 只有 4/5 带问题/答案、名册名次、申请归一化（checked 过滤 / 去重 / 三类 kind / 可疑好友 approveOnly）与各路计数口径、审批 flag == `request_id`、注入回合 0 出站（两层防线 + `injectDryRun:false` 的反向断言）、权限自愈的记账与拦截、运行快照与控制台开关表同步、`/撤管理` 反向提权回归。
- 新增的 `onebot-api-unit` 断言是**线路级**的：直接起反向 WS 服务器与客户端，核对 v0.5.8 六个新动作**真实发出去的 payload**（`enable` 是否始终存在且为布尔、`add_type` 1–3 是否真的不带问题/答案、方式 5 的答案是否被强制成空串、可疑好友是否只带 `flag`）。此前这些只在 mock 层断言，而 mock 自己也会拼参数——等于没测。
- **变异测试**：把注入闸门临时拿掉后 `O1`/`O3` 确实变红（不是恒真断言），随后恢复。
- 顺手修掉 `commands-unit` 的一处**计时抖动**：走 agent 的断言原来死等 40ms，全量跑时偶发假红（随后连跑 3 次全绿）；现在改成"见到回复就返回、最多等 400ms"，连跑 3 次稳定。

#### 按住的（探针说"别猜"）

- **不做 `/群搜索`**：`set_group_search` 的两个参数 `no_code_finger_open` / `no_finger_open` 在 NapCat 里连 schema 描述都是「未知」，官方 API 文档也没写语义。给用户一个"传 0/1 的魔法数字"命令是错的，宁可等真机确认。
- **可疑好友申请只能同意**：探针读到 `set_doubt_friends_add_request` 的 handler **完全忽略 `approve`**（源码注释「该字段没有语义 仅做保留 强制为True」）。`/拒绝` 对这类条目会被显式拒绝执行并在文案里说明，不假装拒绝成功。

#### 配置

- 新增 6 个开关/参数键（总数 217 → 223）：`opsAdminEnabled`、`opsInvitePolicyEnabled`、`opsAddOptionEnabled`、`requestSyncEnabled`、`requestSyncCount`、`adminWatchEnabled`，全部默认关闭；`/打卡名册` 归入既有 `opsReadEnabled`，不新增开关。注意这四个新命令开关都要求 `groupOpsEnabled` 总开关也打开（说明里已写明）。

#### 待真机验证（本机 NapCat 未登录，跑不了）

`/设管理`、`/撤管理`、`/邀请策略`、`/加群方式`、`/打卡名册`、`/申请` 各来一次，重点看：`/打卡名册` 的 `rank`/`time` 字段是否与探针一致、`/申请` 拉回来的 `request_id` 能否被 `/同意` 接受、被撤管理员时是否真的走"真话"分支。

### v0.5.7（2026-09-14 发布）— 文档：总览只列两个大版本 / Docs only

> **纯文档改动，无代码变更**（`test/static-unit.mjs` 的守卫随文档惯例一起回到原样）。

- README「功能总览」原来平铺 26 条 bullet，大半是 v0.1–v0.3 时代的老能力，越写越长、也看不出"最近到底做了什么"；现在**只列最近两个大版本新增的能力**：**v0.5 线**（看得见 · 找得回 · 无人值守 · 点一下就完事 · 群运营工具箱 · 控制台看得见，附补丁版本说明）与 **v0.4 线**（一切皆可调试 · 自带控制台 · 依赖修复）。老基础能力（消息桥、会话续接、记忆、提醒、群管套件、TTS、生图、签到、积分小游戏……）压成一行指引：功能都还在，逐版明细看 `CHANGELOG.md`，开关看「配置」。
- README 的更新日志保持滚动展示最近**五个**版本（v0.5.7 → v0.5.3）——期间一度改成"只列两个大版本"，与「功能总览」的定位重复，已回退。
- `test/static-unit.mjs` 守卫回到"恰好五版 + 首版必须是 `package.json` 当前版本"，README 不会悄悄停在旧版本上。
- 验证：static-unit **17/17**、privacy-unit **33/33**；其余套件与本版无关（无代码改动，未重跑全量）。

### v0.5.6（2026-09-14 发布）— 真机可用性修复 + 完整审计 / Real-machine fixes and an audit

> 本版没有新功能，只有"让它真的能用"和"把隐患修掉"。起因是排障时发现控制台三个按钮**看起来能用、其实用不了**，随后做了一轮独立对抗性审查，把发现的严重问题一并修掉。

#### 三个"假可用"（都在你这台机器上实测复现）

- **「启动 NapCat」跑错了脚本**：配置指向 `bootmain\napcat.bat`，而那个脚本只有 `chcp 65001` + `.\NapCatWinBootMain.exe` + `pause`——**不带参数、不设注入环境变量、不提权**，实测打印一行 `argv[0]:…` 后**以 exit 0 秒退**，什么都不做（6099 没开、没有任何 QQ 进程）。现在改为**提权启动**（`Start-Process … -Verb RunAs`）并调用真正的 `launcher.bat`，提示语写明"请在 UAC 点『是』，二维码刷新后 2 分钟内扫掉"。
- **「打开扫码页」是死链**：它只是指向 6099 的链接，而 6099 是 NapCat 进程起来后才存在的。现在未监听时**禁用按钮并显示原因**（"扫码页不可用（NapCat 未运行）"）。
- **满屏「token 无效」**：页面从地址栏取 token，不带 `?token=` 打开就等于空 token，于是每个面板都报错。现在**地址里没 token 时直接弹中文横幅**：token 存在 `qq-control.json`、**宿主 3080 的 token 每次重启都会变**、两者不能混用。

#### 新增：登录二维码面板 + 重启登录流程

- `GET /api/qr` 直接返回二维码图片（dataUrl）+ **这张码是几秒前生成的** + 过期提醒（QQ 的码约 1–2 分钟失效；实测文件写过一次后 8 分钟不再变化，光看"文件在不在"会误判）
- 「重启登录流程」按钮：提权重启整条登录链路

#### 独立对抗性审查发现的问题（全部已修，每条都有回归断言）

- **【严重】重启流程按镜像名 `taskkill /F /IM QQ.exe`，会把用户自己的 QQ 一起杀掉**——真机上就有一个**非提权的个人 QQ** 在跑；护栏还只要"6099 有人监听"就放行（别的程序占用 6099 也算）。
  修法：改为**按加载器 PID 清理**（`taskkill /PID <pid> /T /F`，子进程连带结束），命令里**不再出现 `QQ.exe` 或 `/IM`**；6099 不再作为放行依据；**拿不到加载器 PID 直接拒绝**。
- **`/api/port/free` 无白名单**，`FREEABLE_PORTS` 是死代码 → token 持有者能借它杀掉任意占用者（如占用 8799 的别的进程）。现已按 `host/onebot/napcat/tts` 白名单校验。
- **`stopNapcat` 把「6099 在听」当成「这就是 NapCat」** → 复现过 nginx 占用 6099 时被 `taskkill /PID /T /F`。现在端口占用者的进程名也必须在 NapCat 加载器名单内。
- **启动命令的引号会被 cmd 剥掉**：`-ArgumentList '/c','"<path>"'` 在路径含括号时（配置里就有 `C:\Program Files (x86)\…` 这种候选）会静默不执行，而 `stdio: ignore` 把错误吞了、界面照报成功。改用 `call "<path>"`；路径含单引号时也做了成对转义（否则生成的 PowerShell 脚本解析失败）。
- **`restartNapcatLogin` 不校验启动脚本是否存在** → "先杀后启失败"，什么都没起来。已补校验。
- **`jobsView`/`groupsView` 遇元素级畸形快照（`[null]`）抛错** → 整个 `/api/jobs`、`/api/groups` 500。已改为过滤。
- **控制台把 `jobs.webhook`/`jobs.autoHeal` 整对象透传**（今天不泄露只因 writer 有白名单）。控制台侧现自己挑字段。
- **自愈命令原文进了 trace 的 reason**（含本机绝对路径与用户名），而 trace 会被 `/api/trace` 与诊断包带走。现在 reason 只留**可执行文件 basename + 参数个数**。

#### 顺带修掉的观察项

`qrStatus` 区分「读不到（EBUSY/EACCES）」与「不存在」；`qr()` 校验 **PNG 魔数**（否则任意文件都能被当图片回给前端）；ops 规划器改用 `Object.hasOwn`（`kind:'constructor'` 曾命中原型拿到**函数**）；`planSendLike` 遇 `Symbol` 不再抛错。

#### 隐私复核（本轮一并做了）

- 受控文件 128 个：真实 QQ 号 / 本机绝对路径 / token 形态 / 邮箱 **全 0**
- **git 历史**（79 提交 / 632 blob）扫真实 id：**0 命中**（首次扫描报的"各 1 处"是**假阳性**——`git grep` 的报错输出被当成匹配行，复核后按 0 报）
- 密钥：webhook token/secret 不进任何 trace/log；真机运行快照无 token/secret 字样；新增 `jobs` 块只有描述性字段
- 鉴权：新增路由全在 token 校验之后；21 例绕过尝试（`//api/`、大小写、URL 编码、`__proto__` 路由、重复 token…）全部失败
- 导出：`publicConfig` 只有路径、不含控制台 token；**未脱敏诊断包天然含真实 QQ 号与消息原文——对外分享必须用脱敏通路（页面默认已勾选）**

#### 测试

- 增量：`control-unit` 121 → **152**、`perf-unit` 61 → **66**、`ops-unit` 94 → **106**、`engage-unit` 109 → **111**
- 全量 **55 套 / 3434 断言全绿**
- 唯一未验证项（诚实声明）：`Start-Process -Verb RunAs` 与 `-WorkingDirectory` 的真实组合行为会弹 UAC，审查按禁令未实测

### v0.5.5（2026-09-14 发布）— 控制台看得见 / Console visibility

> 本版主题：**把控制台从「能启停、能看日志」变成「看得懂」**。四阶段计划的最后一块：群配置页、定时任务面板、性能面板、回放 diff、注入场景库。全部是**只读+可回放**的能力，控制台依旧不写配置文件、不替桥做决定。

#### 性能面板（`GET /api/perf`）

- 端到端延迟 = 同一条 traceId 的「最后一条事件 − 第一条事件」；给出整体与**分会话**的 P50/P95/最慢/平均
- **阶段耗时画像**：直接用 trace 里已有的 `ms`（lib/trace.js 记的是「距上一条 mark 的耗时」），不新造埋点
- **失败画像**：按阶段聚合 + 最常见原因计数；**debug 级「功能没开」不算事故**，单独列出——否则每个关着的开关都会污染错误率
- 返回一句人话结论（`最近 N 条消息：P50 x ms，P95 y ms`），没有数据时说"还没有可统计的消息"而不是显示 `NaN`
- `percentiles()` 只认数字与数字字符串：`Number(null) === 0` 会把"没有数据"混进分位数（实测踩过）

#### 定时任务面板（`GET /api/jobs`）

- 播报任务：下次触发时间（人话：`30 秒后`/`2 分钟后`）、上次原因、成功/失败次数、**「一直在失败」标记**
- 入站 webhook：来源与收/丢计数；掉线自愈：命令**是否**配置、冷却、上限、最近一小时尝试次数
- 注入队列：待消费行数、已消费、dry-run 状态、轮询间隔
- 数据来自桥写进运行快照的新 `jobs` 块：**只有描述性字段**，自愈命令原文与任何 token 都不进快照（有断言守住）

#### 群配置页（`GET /api/groups`）

- 每个群一行：白名单状态（从快照 `replay.allowGroups` 判定，不可知时显示"未知"而不是猜）、会话 ID 与状态、最近回合时间、挂在该群上的定时任务
- **16 项生效开关**一览 + 实时计数（表情统计条数 / 运营计数项 / 待确认批量踢 / 正在输入的会话）
- 面板明说：开关的真源是插件配置（profile 的 `cordis.patch.yml`），这里显示的是**生效值**

#### 注入场景库（17 个内置场景）

- `GET /api/scenarios` 列清单；`POST /api/inject` 支持 `{ scenario, params }`（不带 `scenario` 时行为不变，仍收裸 spec）
- 每个场景声明**需要哪些参数**与**专门验哪条链路**，缺参数时点名缺什么（例如 `场景「群里 @我 说话」缺少参数：groupId、userId`），不猜默认值
- 覆盖：群里 @我 / 普通聊天（验 `replyOnlyWhenMentioned` 门控）/ 撤回 / 戳一戳 / 入群 / 表情回应 / 入群申请 / 加好友申请 / 私聊文本 / 私聊图片 / `@我 发图 + /ocr` / 转发卡片（带 `forwardText` 保证确定性）/ 管理员 `/kick` / `/群打卡` / `/批量踢` 第一步 / 敏感词 / 超长消息
- 纯模块只产出 spec（形状与 `lib/inbox.js` 的 `expandInjection` 一致），写队列仍走既有 `api.inject`

#### 回放 diff（`POST /api/replay-diff`）

- 同一批录到的消息跑**两次**回放：基线 vs 你写的配置覆盖（`{"keywordEnabled": true}` 这类），机械比出三类差异：**决策变了**（会回复 ↔ 静默）、**静默原因变了**、**回复文本变了**
- 回复文本变化带**相似度**（字符 bigram 的 Dice 系数），避免措辞微调被误判成行为变化；只有一侧有结果时标 `unknown`（而不是"变了"）
- 缺 `variant` 直接拒绝并给例子，且**不会白跑两次回放**（有断言：拒绝时 `api.replay` 调用次数不增加）

#### 测试

- 新增 2 套：`perf-unit`（61，分位数边界、链分组、阶段/失败画像、任务与群视图、纯模块红线）、`scenario-unit`（49，场景清单完整性、逐场景 spec 形状、缺参数拒绝、文本相似度、diff 分类）
- `control-unit` 99 → 121（三个新 GET 端点的真实 HTTP 断言 + 场景注入 + 两次回放与拒绝路径）
- 全量 **55 套 / 3384 断言全绿**（v0.5.4 为 53 套 / 3252）
- 过程中由测试逼出的真 bug：`percentiles()` 把 `null`/`''` 当 0 计入分位数；三个新 GET 路由漏了 `await`，序列化 Promise 得到空对象（页面会全空白）

### v0.5.4（2026-09-14 发布）— 群运营工具箱 / Group ops toolbox

> 本版主题：**把群运营的日常动作做成一等公民**——原生签到、群待办、@全体余量、禁言名单、批量踢、群资料、入群与发言策略、文件整理、相册上传，外加一份本地统计的运营周报。全部默认关闭（总开关 `groupOpsEnabled`），写操作一律过 ActionGate，注入/回放回合一律不写 QQ。

#### 真机探针先行（本版纠正了三个会做错的地方）

读本机安装的 NapCat 实现包（`bootmain/napcat.mjs`，QQ 9.9.32-50969）逐一核对 action 名与参数 schema，结论写进 `lib/ops.js` 头部并由 `test/ops-unit.mjs` 钉住：

- **批量踢有原生 action**：`set_group_kick_members` 的 `user_id` 是**数组**——不必循环 `set_group_kick`（循环既慢又更容易被风控）。超过 `opsKickBatchSize`（默认 20）时**分批而不是截断**。
- **群待办是三个 action**：`set_group_todo` / `complete_group_todo` / `cancel_group_todo`，共用 `{ group_id, message_id? 或 message_seq? }`。
- **相册上传确实存在，但名字是 `upload_image_to_qun_album`**（不是 `upload_qun_album`）；配套 `get_qun_album_list` / `get_group_album_media_list`。
- **`set_group_member_permissions` 是局部更新**：探针文档明确写「未传入的项目保持不变」。所以 `/群权限` 只提交**显式写出**的项——把没提到的项塞成 `false` 会静默关掉用户没打算关的权限。

#### 新增命令

| 命令 | 开关 | action | 说明 |
|---|---|---|---|
| `/群打卡` | `nativeSignEnabled` | `set_group_sign` | QQ 的**原生群签到**，与本地「签到」积分玩法是两件事（提示语里会点明） |
| `/全体余量` | `opsReadEnabled` | `get_group_at_all_remain` | 本群与本人剩余 @全体次数，不可用时说明常见原因 |
| `/禁言名单` | `opsReadEnabled` | `get_group_shut_list` | 带昵称与剩余时间，并标出已到期人数 |
| `/群详细` | `opsReadEnabled` | `get_group_info_ex` | 扩展群资料（群名/人数/上限/创建时间/描述/问题），长字段截断 |
| `/入群通知` | `opsReadEnabled` | `get_group_ignored_notifies` | 被忽略的入群申请与邀请 |
| `/批量踢` | `opsKickEnabled` | `set_group_kick_members` | 管理员；**两步确认**（`/批量踢 @a @b` → `/批量踢 确认`），60 秒有效，分批不丢人，名单含自己直接拒绝 |
| `/待办` `/完成待办` `/取消待办` | `opsTodoEnabled` | `set/complete/cancel_group_todo` | 引用一条消息即可 |
| `/移动文件` `/重命名文件` `/删文件` `/新建文件夹` | `opsFileEnabled` | `move/rename/delete_group_file`、`create_group_file_folder` | 管理员；破坏性操作，缺参数时逐项说明缺什么 |
| `/传图 <相册ID或名字>` | `opsAlbumUploadEnabled` | `upload_image_to_qun_album` | 引用一张图片；按名字自动查 `get_qun_album_list` 换 ID，`@album_id` 可直接指定 |
| `/群名` `/群备注` | `opsProfileEnabled` | `set_group_name` / `set_group_remark` | 管理员；群名 >30 字、备注 >60 字直接拒绝 |
| `/群权限 相册=关 临时会话=关 新群聊=开` | `opsPolicyEnabled` | `set_group_member_permissions` | 管理员；**只提交写出来的项**（局部更新语义） |
| `/历史可见 开\|关` | `opsPolicyEnabled` | `set_group_new_member_history_visibility` | 管理员 |
| `/周报` | `opsReportEnabled` | 本地统计 | 最近 N 天（`opsReportDays`，默认 7）的消息/入群/退群/踢出/禁言/打卡/待办/文件整理/相册上传计数 + 最忙的一天；**纯本地读，不访问 QQ** |

#### 命令命名踩到的两个坑（都在代码里留了注释）

- `/群资料` 已被既有**基础群信息**查询占用（走 `get_group_info`）→ 扩展版改名 `/群详细`。
- `/成员权限` 会被既有 `/成员` 命令**整条吃掉**（该命令为了好用，刻意支持 `/成员张三`、`/成员@12345` 这种紧贴写法，且有测试保护）→ 改名 `/群权限`。这两个坑都是实测才暴露的，不是设计出来的。

#### 周报计数（`qq-ops.json`）

消息、入群、退群、禁言/解禁、打卡、待办、批量踢、文件整理、相册上传都会计数，按天分桶、保留 30 天、跨重启累加（`OpsCounters` 有 snapshot/restore，坏文件不影响启动）。

#### 新增配置键（默认值）

`groupOpsEnabled`(false) `nativeSignEnabled`(false) `opsReadEnabled`(true) `opsKickEnabled`(false) `opsKickBatchSize`(20) `opsTodoEnabled`(false) `opsFileEnabled`(false) `opsAlbumUploadEnabled`(false) `opsProfileEnabled`(false) `opsPolicyEnabled`(false) `opsReportEnabled`(false) `opsReportDays`(7) `opsCountersFile`("") —— 配置键总数 204 → **217**，`test/static-unit.mjs` 的双向校验（含"没有死开关"）全部通过。所有子开关都在总开关之下：`groupOpsEnabled=false` 时任何群运营命令都只回一句中文说明。

#### 测试

- 新增 2 套：`ops-unit`（94，纯模块：规划器参数形状、分批不丢人、渲染器、周报计数与快照、零依赖红线）、`ops-bridge-unit`（96，桥层：**每个新 API 一条"注入回合 0 出站"断言**、两步确认与超时、分批、相册按名解析、局部更新语义、计数跨重启）
- 全量 **53 套 / 3252 断言全绿**（v0.5.3 为 51 套 / 3062）

### v0.5.3（2026-09-14 发布）— 点一下就完事 / One tap

> 本版主题：**轻互动**。戳一戳、正在输入、表情回应、点赞、标记已读——用真实存在的能力把"群里的小动作"做成一等公民。全部默认关闭；所有写操作过 ActionGate + 出站配额；**注入/回放回合一律不写 QQ**（`injectDryRun: false` 的真发模式除外）。

#### 先做真机探针，再动代码（本版最重要的结论是否定的）

- 按钮类能力**没有靠猜**：直接读本机安装的 NapCat 实现包（`bootmain/napcat.mjs`，QQ 9.9.32-50969），逐个确认 action 名、参数 schema 与入站事件字段，结论写进 `lib/engage.js` 文件头并由 `test/engage-bridge-unit.mjs` 逐条钉住
- **探针结论：这个构建发不了内联按钮**——`"keyboard"` / `"button"` 段名在整个 bundle 里出现 **0 次**（`"text"`/`"json"`/`"markdown"`/`"poke"` 等真实段名都在），OB11 段枚举里只有 `click_inline_keyboard_button`（点**别人**发的按钮）。所以本版**没有做**按钮面板，而是把「点一下就完事」落到真实可用的四种轻互动上
- 确认可用：`group_poke` / `friend_poke` / `send_poke`、`set_input_status`、`set_msg_emoji_like`、`get_emoji_likes`、`fetch_emoji_like`、`send_like`、`mark_group_msg_as_read` / `mark_private_msg_as_read` / `mark_msg_as_read`；入站 `notice.group_msg_emoji_like`（`message_id`/`likes`/`is_add`/`message_seq`）、`notice.notify/poke`、`notice.notify/input_status`

#### 互动能力（`engageEnabled` 总开关 + 每个能力独立子开关，全部默认关）

- **主动戳一戳** `/戳 @某人`（管理员）：`pokeCommandEnabled`，白名单 + ActionGate + 每小时配额 `pokePerHour`（默认 5）三层；命令一律**空白分隔**，`/戳12345` 不认
- **被戳回戳**：`pokeBackEnabled` 时被戳**真的戳回去**（`group_poke`/`friend_poke`），可配 `pokeBackText` 同时回一句话；仍受既有 `pokeEnabled` 总开关与冷却约束（`pokeEnabled=false` 时 trace 会明确点名）
- **正在输入**：`typingEnabled` 私聊里模型动脑前发 `set_input_status`（event_type 1），回复落地即撤销（2）。真机探针确认该 action **只拼 C2C 私聊**，群聊里如实记 reason 而不是白发一次注定失败的调用
- **自动贴表情**：`emojiLikeEnabled` + `emojiLikeId`（默认 `128077`＝👍，`emoji_id` 就是十进制码点，`emojiGlyph` 直接还原成真表情）；`emojiLikeMentionOnly` 默认只对"叫我/引用我"的消息生效
- **表情回应统计**：`reactionStatsEnabled` 记录 `group_msg_emoji_like`。`/赞榜` 看本会话被回应最多的消息（本地统计 + 原文摘要），`/谁赞了 <消息ID>`（或引用一条消息）看**谁**点的——群里走真机 `get_emoji_likes` 拿实时名单，失败或注入回合回落本地统计并**标注数据来源**（`来源：本地统计` / `来源：get_emoji_likes 实时`）
- **点赞**：`sendLikeEnabled` → `/点赞 [@某人]`，一次 `sendLikeTimes`（默认 10，QQ 客户端上限），每目标每天 `sendLikePerDay`（默认 3）
- **标记已读**：`markReadEnabled` → 收到消息顺手 `mark_*_msg_as_read`（按**会话**标记，不按单条消息），每分钟 `markReadPerMinute` 限流

#### 红线（v0.4「一切皆可调试」六条硬约束在本版的落点）

- **`set_msg_emoji_like` 只带 `message_id`、没有任何会话键**，scoped dry-run 拦不住它 → 桥里自己判 `__injected`/`__replayed` 并给出真实 reason；`test/engage-bridge-unit.mjs` 逐条断言注入回合 **0 出站**
- 注入回合里 `/赞榜` 是**纯本地读**，照常回答且 trace 写明"只读本地 JSON，不访问 QQ"；`/谁赞了` 不调 QQ、回落本地并说明原因
- 每个开关的"关着"分支都有真实 reason（`主动戳未启用（engageEnabled=true，pokeCommandEnabled=false）`），配额拒绝也带数量：`戳一戳 已达每小时上限（5/5 次）`
- 注入口径与既有 `injectDryRun` 一致：默认干跑拦截，`injectDryRun: false`（"注入并真发"）时照常执行

#### 顺手修掉的两个真缺陷（都是 v0.5.2 的，且都属于"静默失效"）

- **状态持久化从来没生效过**：桥对 `JsonStore` 调用的是不存在的 `load()`/`save()`（真实 API 是 `read()`/`write()`），异常被 `try/catch` 吞掉，于是**播报去重与统计跨重启丢失**、且毫无提示。已修全部调用点，并补上跨重启回归（`unattended-unit` D21 / `engage-bridge-unit` G1–G4）
- **互动配额恢复打空**：`#loadEngageState()` 在配额对象构造**之前**被调用，`restore` 抛错同样被吞掉 → 每小时配额跨重启失效。已调整顺序并加可选链防御
- 附带：运行快照在记账后不刷新（控制台的表情计数永远停在启动时的 0）→ 记账后按既有 2s 节流补写一次

#### 新增配置键（默认值）

`engageEnabled`(false) `pokeBackEnabled`(false) `pokeBackText`("") `pokeCommandEnabled`(false) `pokePerHour`(5) `typingEnabled`(false) `emojiLikeEnabled`(false) `emojiLikeId`("128077") `emojiLikeMentionOnly`(true) `emojiLikePerHour`(20) `reactionStatsEnabled`(false) `reactionStatsFile`("") `sendLikeEnabled`(false) `sendLikeTimes`(10) `sendLikePerDay`(3) `markReadEnabled`(false) `markReadPerMinute`(10) —— 配置键总数 187 → **204**，`test/static-unit.mjs` 的双向校验（schema ↔ 代码读取，含"没有死开关"）全部通过。

#### 测试

- 新增 2 套：`engage-unit`（109，纯模块：planner 参数形状、表情统计去重/撤回/排行/落盘、配额三档窗口、榜单渲染、零依赖与"不自己发 QQ"红线）、`engage-bridge-unit`（90，桥层：五类新 API 各一条"注入回合 0 出站"、命令空白分隔、配额与闸门、两种注入模式、跨重启持久化）
- 全量 **51 套 / 3062 断言全绿**（v0.5.2 为 49 套 / 2860）

### v0.5.2（2026-09-14 发布）— 无人值守 / Unattended

> 本版主题：**无人值守**。三件事——外部事件能主动进群、定时内容自己发、掉线了自己爬起来。全部默认关闭，写操作与出站一律走既有的闸门/限流/trace 体系。

#### 入站 webhook（`webhookEnabled`，默认关）

- 独立 HTTP 端点（默认只绑 `127.0.0.1:8798`），`POST /hook/<来源名>` → 渲染成一条 QQ 消息发到配置的会话
- 三种 `format` 适配器：`github`（push / pull_request / issues / issue_comment / workflow_run 含 CI 成功失败 / release）、`uptime-kuma`（心跳 0 宕机 / 1 恢复 / 2 待定 / 3 维护）、`generic`（任意 JSON + `{a.b.c}` 占位符模板，取不到值填 `（无）`）
- **鉴权必须二选一**：`token`（`X-Webhook-Token` 头或 `?token=`）或 `secret`（GitHub 风格 `X-Hub-Signature-256` 对**原始请求体**做 HMAC-SHA256）；比较全部走 `crypto.timingSafeEqual`（长度不等先各自 SHA-256 到等长，不会抛错）。**既无 token 也无 secret 的来源在构造时直接剔除且不注册路由**——不存在未鉴权的开放端点
- 体积上限 `webhookMaxBodyBytes`（默认 64 KiB）：超限回 **413**，并且是先回状态码再 `request.resume()` 排水、`socket.end()` 优雅关闭（初版用 `socket.destroy()` 是 abortive close，客户端只看到 `fetch failed` 拿不到 413 —— 这条是实测才暴露的）
- 每来源滑动一分钟限频 `webhookRatePerMinute`（默认 30），超限 **429**；`status()` 暴露每个来源的 `received` / `dropped` / `lastAt`（只暴露名字与计数，**不含 token/secret**）
- 每次事件都写 trace：收到、渲染失败、发送被拦（限流或注入回合）都有中文 reason

#### 定时播报（`broadcastEnabled` + `broadcastJobs`，默认关）

- 三种任务：`rss`（自带 RSS 2.0 / Atom / RDF 解析器，**零第三方依赖**；按 guid/link 去重，跨宿主重启不重复；支持 `keyword` 过滤与 `maxItems`）、`weather`（Open-Meteo，免费无 key；WMO 天气码译成中文 + emoji）、`mc`（复用既有 Server List Ping）
- 排期两种写法：`at: "HH:MM"`（可配 `weekdays`，0=周日，最多向后找 8 天）或 `everyMinutes`（下限 5，优先于 `at`）；定时器延迟夹取到 `[0, 2^31-1]`，间隔类按"上次计划时间 + 间隔"递推，**执行耗时不会让排期漂移**
- 去重与统计（`seen` / `lastAt` / `lastReason` / `runs` / `failures`）落盘 `qq-broadcast.json`，`stop()` 时保存、启动时恢复
- 失败必留中文 `lastReason` 且**不发送空消息**；`/播报` 列任务与下次时间、webhook 状态与收/丢计数，`/播报 测试 <任务 id>` 立即触发一次（管理员）

#### 掉线自愈（`autoHealEnabled` + `autoHealCommand`，默认关）

- QQ 客户端断开时按配置命令把它拉起来：**只启动、绝不杀进程**（杀进程仍归控制台，那边有专门护栏），`detached + shell + stdio:'ignore' + unref`，不阻塞宿主也不连坐子进程
- 冷却 `autoHealCooldownSeconds`（默认 300s）+ 每小时上限 `autoHealMaxPerHour`（默认 3）；**命中冷却或上限都会写 trace 说明原因**，不静默；`autoHealEnabled=true` 却没配命令也照样留 reason
- 与既有 `notifyEnabled` 出站告警互补：告警负责"告诉你掉了"，自愈负责"拉回来"

#### 新增配置键（默认值）

`webhookEnabled`(false) `webhookPort`(8798) `webhookSources`([]) `webhookRatePerMinute`(30) `webhookMaxBodyBytes`(65536) `broadcastEnabled`(false) `broadcastJobs`([]) `broadcastStateFile`("") `autoHealEnabled`(false) `autoHealCommand`("") `autoHealCooldownSeconds`(300) `autoHealMaxPerHour`(3) —— 配置键总数 175 → **187**，`test/static-unit.mjs` 的双向校验（schema ↔ 代码读取）全部通过。

#### 测试

- 新增 4 套：`feed-unit`（144，RSS/Atom/RDF、CDATA、实体、时间解析、截断）、`webhook-unit`（114，含真实 HTTP 往返：鉴权/413/429/405/400/500 与 status 计数）、`broadcast-unit`（189，假 timers 推进到点触发、间隔不漂移、去重、快照往返）、`unattended-unit`（桥层：webhook 真发到群、`/播报` 管理、自愈冷却与上限、**注入回合 0 出站**）
- 全量 **49 套 / 2860 断言全绿**（v0.5.1 为 45 套 / 2306）
- 过程中由测试逼出的真 bug 随手修掉：`formatFeedItems` 的 `limit` 参数算了没用、feed 标题张冠李戴（channel 无 title 时取了第一条 item 的标题）、`stripHtml` 先解实体再删标签导致 `&lt;大新闻&gt;` 被吃掉、CDATA 整段被标签正则吞掉、413 因 abortive close 拿不到状态码、`renderWebhook` 遇 BigInt 序列化抛错

### v0.5.1（2026-09-13 发布）— 审查修复 / Audit fixes

> 本版是 v0.5.0 的补丁：发布后做了一轮**对抗性审查 + 隐私审计**，抓出并修掉 8 个缺陷（3 个 P1、5 个 P2）。没有新功能。

#### 修复

- **`/成员 <昵称>` 对没设群名片的成员永远查不到**（P1）：`String(item?.card ?? item?.nickname ?? '')` 在 `card: ''` 时得到空串，`''.includes('小红')` 恒为 false——而"成员没设群名片"是默认形态。改为"去空白后回落到昵称"（与 `lib/members.js` 的显示名规则同源）
- **转发卡片展开为空时仍起一个空模型回合**（P1）：`forwardExpandEnabled=false`、`get_forward_msg` 返回空、或调用失败这三种情况下，`hasForwards` 豁免让流程继续走到 agent，模型收到一个**内容为空的 user turn**（白烧 token，还可能在群里自说自话）。现在在 handoff 前复查 `effectiveText`，为空则 drop 并写明"转发卡片展开后没有可读内容"
- **`/ocr` 与 `/好友` 在注入/回放回合仍会真的访问 QQ**（P1/P2）：`get_msg`（解析引用图）与 `get_friend_list` 的参数都不带 `group_id`/`user_id`，落不进作用域 dry-run 的拦截条件。`/ocr` 的离线判断原本放在 `get_msg` **之后**（等于没拦），现已提到函数第一行；`/好友` 补上同样的显式判断
- **`/读图` 被 `/读` 语音朗读整条吃掉**（P2）：`/^\/读\s*(.*)$/` 匹配了 `/读图`，于是发出一条朗读"图"字的语音并消耗 TTS，OCR 别名形同虚设。朗读命令改为要求空白分隔，并显式排除 OCR 别名
- **归档写入失败完全静默**（P2）：`HistoryArchive.append()` 吞异常只返回 `false`，调用方丢弃了返回值；磁盘满/目录不可写时历史会静默丢失，`/找` 还会回答"最近 N 天没找到"。现在失败写一条 `stage:'archive'` 的 error 事件（同一故障只报一次，恢复后重新计数）
- **控制台「群资产」读错配置键**（P2）：面板读的是 `historyDir`——这个键在插件 schema 里根本不存在（插件用 `historyArchiveDir`），自定义归档目录时面板永远显示"0 个文件 / 没找到"却不报错。已改为同一键名，并新增 `exists` 标记与"目录还不存在"提示
- **`/取` 的两处隐私/资源问题**（P2）：私聊投递失败时会把**本机绝对路径**发进群里（泄露部署者的用户名与目录结构），现在只回文件名、完整路径仅进本机日志；`qq-files/` 也纳入保留期清理（原文：只清 `qq-images`/`qq-replies`，下载目录永不清理）。另外投递注定被闸门拒时不再先下载（50 MiB 上限 × 反复 `/取` 可以撑满磁盘）
- 细节：单条消息最多展开 3 张转发卡片时，trace 现在会说明"另有 N 张卡片未展开"（原先静默丢弃）；`groupFileListLimit` 的说明补上"同时也限制 `/相册` 显示条数"（实际行为如此，原文只写群文件）

#### 测试

- 新增 `test/inject-assets-unit.mjs`（28 条）：起**真实** OneBotServer + 真 WebSocket 客户端，走**真实注入通道**，逐条验证 7 个新命令"注入回合 0 出站帧 + 回复理由诚实"，并用正对照证明 6 个出站动作在非 dry-run 下**确实**发出（没有正对照，A 段就是空测试）
- `seeing-unit` 71→86、`find-unit` 59→72：把上述 5 个修复逐个钉住；并做了**反向验证**（把 `lib/bridge.js` 换回修复前版本，新断言各挂 8 条），确认不是恒真断言
- `privacy-unit` 32→33：新增"文件名里也不能有真实 QQ 号"，并修掉它自己的一个假阳性——`.gitignore` 匹配器把目录规则 `qq-*/` 去掉末尾斜杠后当文件规则用，导致 `qq-badwords.txt`（插件会写出的敏感词表）被误判为"已忽略"。同时补齐跨行 YAML 列表的私有号采集
- `.gitignore` 补上 `qq-*.txt`（`qq-badwords.txt` 原文未被任何规则覆盖：`.json/.jsonl/.log` 命中、`.txt` 全都不命中）

### v0.5.0（2026-09-13 发布）— 看得见 · 找得回 / See it, find it

> 本版主题：**看得见 · 找得回**。一半是把"已经封装好、却从没接上线"的能力接通（合并转发、群成员、群资料、群历史、表情回应），一半是补上"群里的东西能找回来"（群文件、相册、OCR、历史检索 + 按天归档）。同时修掉一个**违反 v0.4 第一条硬约束**的洞：合并转发卡片此前在传输层被静默丢弃。

#### 合并转发展开（先修洞，再加功能）

- **问题**：`parseMessage` 只认 text/at/reply/record/image/file，没有 `forward` 分支；于是"只发一张聊天记录卡片"的消息在 `#onFrame` 就因"text/records/images/files 全空"被 `return` 掉——**不产生 message 事件、trace 里连一条记录都没有**。而 `get_forward_msg` 的封装注释一直写着"used to expand recalled cards"，这条路径从没接上
- 现在：`parseMessage` 识别 `[CQ:forward]` 与数组形式的 `forward` 段；`#onFrame` 不再因此早退；桥内新增 `#expandForwards`，用 `get_forward_msg` 取节点并交给新的纯模块 `lib/forward.js` 规范化 + 排版成 `[转发聊天记录] 昵称: 内容`（默认最多 50 条 / 4000 字，只展开一层不递归，`forwardExpandEnabled` 可关）
- **同时修掉一个自引入的门控逃逸**：空文本分支原本让 `else if` 链整体跳过，于是"群里没 @ 机器人的转发卡片"会绕过 @ 门（也绕过私聊的 `acceptPrivate` 门）——白调一次 OneBot、白跑一个模型回合。现在空文本路径自己过这两道门并写 reason（由桥层测试 `seeing-unit` 抓出）
- 回放/注入（dry-run）不访问 QQ：注入可直接带 `forwardText` 喂一份正文；录制白名单新增 `forwards` / `forwardText`，注入规格新增 `forwards` / `forwardText`

#### 接通既有能力（封装早就在，只是没人调用）

- `/成员` 列群成员（身份/等级/头衔/禁言中排序）、`/成员 @某人|昵称|QQ号` 看详情（入群时间/最后发言/禁言状态）；agent 工具 `qq_member_info`（群聊专用）
- `/群信息`（群名/群号/人数上限/群主/建群时间）
- `/好友`（**默认关闭**，隐私项，仅私聊里的管理员可用）
- agent 工具 `qq_recent_history`：拉本会话最近 N 条消息（`get_group_msg_history` / NapCat `get_friend_msg_history`），纯逻辑交给新模块 `lib/history.js`
- agent 工具 `qq_react`：给消息贴表情回应（`set_msg_emoji_like`）而不是发一条消息，写操作过闸门；默认作用于本回合收到的消息
- `/退群 确认`（**默认关闭**，必须显式二次确认，走闸门；`DEFAULT_ACTION_LIMITS` 新增 `set_group_leave` 限额）

#### 群资产

- `/文件`、`/文件 <文件夹名>`：列群文件与文件夹（`get_group_root_files` / `get_group_files_by_folder`）
- `/取 <文件名>`：`get_group_file_url` 取链后下载到 `cwd/qq-files/`，**只发到发起人私聊**（群里只留一句提示，不往群里丢文件）；精确/前缀/模糊匹配，文件名经 `sanitizeDownloadName` 消毒（去路径、去 Windows 非法字符、保留名加前缀、120 字上限保留扩展名）
- `/相册`：列群相册（NapCat `get_qun_album_list`）
- `/ocr`：对本条或引用的图片调用 NapCat `ocr_image` 读出文字（不消耗模型）
- 排版与匹配逻辑集中在新的纯模块 `lib/assets.js`

#### 历史归档与检索

- 每条白名单会话的真实消息按天归档到 `cwd/qq-history/YYYY-MM-DD.jsonl`（新模块 `lib/archive.js`，用记录自身的 `ts` 算本地日期，避免东八区凌晨落错分片）；**注入/回放的假事件不入档**，`/` 开头的命令也不入档
- `/找 关键词`：大小写不敏感、空格分隔多词为 AND、只搜当前会话、可配天数与条数；agent 工具 `qq_search_history` 同源同口径
- 保留期默认 90 天，过期分片在宿主启动时**移入** `qq-trash/<日期>/`（`prune` 只移不删，与图片清理同一套"never destroy"约定）
- 控制台新增「群资产 · 历史检索」卡片与 `GET /api/archive`（无 `q` 返回概览、带 `q` 走检索，复用插件同一套解析），`control-unit` 增加真实 HTTP 往返断言

#### 修复（本版自测抓出的 6 个真缺陷）

1. **门控逃逸**：空文本 + 转发卡片绕过 @ 门与 `acceptPrivate` 门（`seeing-unit` 抓出）
2. `/文件`、`/文件 <文件夹>`、`/相册` 把格式化函数的**返回对象**直接插进模板串，群里看到的是 `[object Object]`（`find-unit` 抓出）
3. `/找` 无参数：正则要求命令后至少一个字符，导致"用法"提示是死代码、命令落到模型路径（`find-unit` 抓出）
4. 归档把 `/` 命令也写进去：每次 `/找 X` 都会命中自己刚敲的查询词，"没找到"永远不可达（`find-unit` 抓出）
5. 启动 prune 的回收目录日期套了两层（外层还是 UTC 日期，与内层本地日期错位）（`find-unit` 抓出）
6. **前缀撞车**：`/取` 把既有的 `/取消精华` 吃掉（`commands-unit` 抓出，与历史 `/vote-end` 同一类坑）；`/文件` 同样收紧为"必须空白分隔"

#### 验证

- 单测 44 套 / 2247 断言全绿（新增 `forward-unit` 111、`members-unit` 104、`history-unit` 81、`archive-unit` 86、`assets-unit` 132、桥层 `seeing-unit` 71、桥层 `find-unit` 59，`control-unit` 95→99）
- 真机（宿主 3080 / 控制台 8799）：注入带 `forwardText` 的转发帧 → trace 出现 `forward` 阶段成功事件、模型回合收到完整两条记录；`/成员`、`/群信息`、`/找`、`/文件`、`/相册`、`/ocr` 六条新命令在真机分发正确；`/api/archive` 概览与检索均返回真实数据；UI 新卡片渲染正常

## v0.4 系列 —— 一切皆可调试 / Everything Debuggable
### v0.4.1（2026-09-13 发布）— 依赖解析与安装修复 / Dependency resolution & install fixes

> 本版修社区反馈的安装问题（[issue #1](https://github.com/cheesehaqi/dsh-qq-onebot-bridge/issues/1)）：干净环境下插件加载即 `ERR_MODULE_NOT_FOUND: Cannot find package 'schemastery'`，连带把成因相同的安装/声明问题一起收口。

#### 修复

- **`schemastery` 改用作用域名 `@deepseek-ai/schemastery`**：`lib/index.js`、`lib/bridge.js` 原本写的是裸名 `import z from 'schemastery'`，而 `package.json` 只声明了 `@deepseek-ai/schemastery`——**裸名是另一个包**（未带作用域的 `schemastery@3.18.0`，官方为 `@deepseek-ai/schemastery@3.18.1`），只有在"同 profile 里别的插件恰好把它 hoist 到共享 node_modules"时才解析得到（本机就是被 `dsh-mnemon` 的依赖 hoist 兜住的）。DSH 并没有"裸名别名注入"机制，官方包全部使用作用域名；干净环境必然加载失败
- **peer 版本区间补上 `^0.1.5-rc.1`**：预发布区间不会跨补丁线，`^0.1.2-rc.1` 不匹配 `0.1.5-rc.1` / `0.1.5-rc.2`，在 DSH 0.1.5-rc.1 上会出现 peer 解析问题（`--omit=peer` 能绕过，但根因在声明）
- **静态回归防线**（`test/static-unit.mjs` 新增三项）：lib/ 里每个第三方 import 必须在 `package.json` 的 dependencies/peerDependencies/optionalDependencies 中声明；官方依赖禁止退化成裸名（`@deepseek-ai/x` 的 basename 不得作为 import 规格名出现）；并校验规格名扫描确实抓到官方依赖，避免正则失效导致假通过。这类"只在特定机器上能跑"的依赖问题会被直接测挂
- **文档纠错与补全**：README 中"裸名 `schemastery` 由 DSH 以别名注入"的说法**是错的**，已删除并改写为正确的部署事实；同时补充本地目录安装说明——`dsh plugin add <目录>` 走 pnpm 的 `link:`，不会安装被链接包自己的依赖，需先在插件目录执行 `npm install --omit=dev`（`ws`），从插件市场安装则会随依赖一起装好

#### 验证

- 干净环境复现与回归：无 hoist 裸包的沙箱里，修复前 `ERR_MODULE_NOT_FOUND: Cannot find package 'schemastery' imported from lib/index.js`；修复后插件入口正常加载（152 个配置键）
- 37 套单测 / 1596 断言全绿（新增 3 项静态防线）；本机 `node_modules` 里手工建的"裸名→作用域名"别名 junction 已移除，本地解析口径与干净环境一致，避免再次掩盖同类问题

### v0.4.0（2026-09-12 发布）— 一切皆可调试 / Everything Debuggable

> 本版主题：**一切皆可调试**。出问题时不用猜——每条消息都有 traceId，每个"没回复"都有原因，任何一条历史消息都能离线重跑，假事件能喂进真实管线，而且这 6 条约束在控制台里随时可验收（阶段 1→4：可观测地基 → 控制台调试层 → 录制/回放/注入 → 硬约束验收台）。

#### 独立控制台（control/）

- **独立进程、独立端口**：`control/bin/qq-control.mjs` 自带 HTTP 服务，只绑 `127.0.0.1:8799`（可 `--port` 改），不依赖 DSH 桌面端或 web 宿主——宿主挂了控制台照常可用
- **端口单一真源** `control/lib/config.mjs`：`qq-control.json` 统一管理控制台 8799 / 宿主 3080 / OneBot 6700 / NapCat 6099 / GPT-SoVITS 9880；node 可执行文件、`dsh bin.js`（自动扫 npx 缓存取最新）、NapCat 启动脚本与二维码路径、TTS 脚本、日志路径全部**自动探测 + 可覆盖**
- **监管能力** `control/lib/supervisor.mjs`：解析 `netstat -ano` + `tasklist` 得到每个端口的监听状态/占用 PID/进程名，以及 6700 上的连接数（=机器人在线）；支持启动/停止/重启宿主（`--no-open`、日志重定向）、启动/停止 NapCat 与 QQ、启动/停止 GPT-SoVITS、一键全停、释放被占端口
- **启动预检**：启动宿主前先探 3080/6700，被占则拒绝启动并报出「端口←进程#PID」，消灭"端口被占 → 表现为长时间重新连接"的静默失败
- **杀进程护栏** `assertKillAllowed`：只允许结束"占用受管端口"或"已知机器人进程"（node/QQ/NapCat/python），拒绝杀控制台自身与无关 PID
- **安全模型** `control/lib/server.mjs`：所有 `/api/*` 需 token（query 或 `X-Control-Token`）；带 `Origin` 的请求必须来自控制台自身的源（阻断任何跨站页面驱动本机进程操作）；日志名白名单防路径穿越；配置写入只接受白名单字段与合法端口
- **单页控制台** `control/ui.html`（无外部依赖、离线可用）：五端口状态灯、机器人/宿主在线徽标、QQ/NapCat/Python 进程与二维码新鲜度、按用途分组的操作按钮、三份日志（宿主 stdout/stderr、桥调试日志）自动跟随、路径配置表单；启动器 `control/启动控制台.bat`，也可 `npm run control`
- 新增测试 `test/control-unit.mjs`（76 项）：netstat/tasklist 解析（含 IPv6、表头、ESTABLISHED）、端口摘要与中文标签、日志尾部与 3080 token 提取、二维码新鲜度、配置探测/覆盖/保存/提醒、杀进程护栏正反例、启动命令构造与端口占用拒绝、**真实 HTTP 往返**（UI、404、401 无/错 token、403 跨站 Origin、状态/日志/各 mutation、路径穿越拦截、非法 JSON、非法端口过滤）、`killTree`/`inspect`/`readUi` 容错

#### 录制 · 离线回放 · 事件注入（阶段 3：可回放 + 可注入）

- **录制（新模块 `lib/inbox.js`，`recordInbound` 默认开）**：桥收到的每条消息/通知/请求按**可回放形状**追加到 `cwd/qq-inbox.jsonl`（单行 JSON：`{v,ts,kind,frame}`，只保留业务字段，socket/未知字段一律丢弃；文本截断 2000 字；2 MiB 上限、尾部保留 256 KiB 轮转）
  - `inboxRedact`（默认关）：落盘前把 6 位以上数字（QQ 号）脱敏，便于把录制文件发给别人排查
  - 注入的帧**不会**被二次录制，避免"注入 → 录制 → 回放 → 注入"自激
- **离线回放（新模块 `control/lib/replay.mjs`）**：在**沙箱目录**里用**真实桥代码 + 真实 OneBot 服务端**重跑录制的消息
  - 三重隔离：① `config.cwd` 强制指向沙箱（状态/事件/媒体/运行时全部落在沙箱内），只把线上决策状态**拷贝**进去（词库、积分、签到、提醒、统计、记忆、待办、表情），源目录一个字节都不改；② `OneBotServer` 开启 dry-run 且**从不 `start()`**——没有 socket、没有监听端口，出站调用全部被拦截并计数；③ 模型回合用一条带 `[回放]` 前缀的模拟回复代替（只验证链路与分支，不冒充模型措辞）
  - 结论逐条给出 `会回复 / 静默 / 出错 / 只调用了非发送动作` + **原因** + **会发送什么**（动作名与分段文本）+ 完整决策链；沙箱默认保留最近 5 次，更旧的**移入回收站**（`qq-replay/_trash/<日期>/`）
  - **保真度来源**：桥把线上 28 项决策配置写进运行时快照的 `replay` 段（白名单、安静时段、各功能开关…），否则"白名单为空 = 拒绝一切"的默认值会让回放全部误判为静默；快照仍**不含任何密钥**（口令只写"是否已配置"）
  - 回放参数支持"试配置"：请求里可覆盖任意插件配置键（如临时打开 `keywordEnabled`、改 `quietHours`），`cwd`/事件文件等沙箱关键键**强制忽略**
- **事件注入（`injectEnabled` 默认关）**：控制台写一行到 `cwd/qq-inject.jsonl`，桥按 `injectIntervalMs`（默认 2000ms）轮询，新行经**真实管线**处理（白名单/@ 门/命令/agent 全走一遍）
  - `injectDryRun` **默认 true**：注入触发的所有出站调用被拦截并在事件流里计数（"注入完成：N 个出站调用被拦截"），绝不真发 QQ
  - 只消费**启动之后**追加的行；启动时队列里已有的历史行会被跳过，并留下一条事件说明跳过了多少行、规则是什么（无静默分支）
  - 注入通道未开启时控制台**直接报错并指出开关名**，不会静默入队；控制台「清空注入队列」把文件**移入回收站**而非删除
- **控制台新增「录制 · 回放 · 注入」面板**：录制列表（序号/时间/类型/可读内容/一键回放）、回放结果文本、注入表单（消息/通知/请求 + 群号/QQ 号/文本/@ 开关）、注入队列状态（行数 · 本次已消费 · dry-run 开关）
  - 新接口：`GET /api/inbox`、`POST /api/replay`、`POST /api/inject`、`POST /api/queue/clear`（仍受 token + Origin 双重校验；回放条数、下标数量、回复文本长度、时间预算全部在服务端裁剪）
- **日志尾部读取器加固（`createLineTailer`）**：半行缓冲（正在写入的那一行绝不以半截 JSON 交出）；位置**立即定位**且队列文件不存在时从 0 开始（否则文件首次被创建时首行会被吞掉——真机测试抓到的 bug）；文件被替换/截断视为全新内容
- **注入安全边界（真机测试抓到的漏网）**：dry-run 窗口只覆盖同步阶段，而 agent 回合是**异步**的——模型几秒到几分钟后才回话，那条回复原本会真的发到 QQ。现在给注入帧的会话打"注入回合"记账，`#onSessionEvent` 会把该回合的 `assistant/message` 也拦下，原文写进事件流（`注入回合的模型回复已被拦截（dry-run，未发送）：…`）；收到**真实消息**时立即解除标记，绝不连坐真人；回合结束（含宿主已知的 `turn/end` 报错）也会清账，避免漏拦下一回合。确定性覆盖见 `test/inject-guard-unit.mjs`（15 项：基线发送、注入回合拦截、注入后真人恢复、注入回合报错不连坐、连续两次注入都拦、私聊同理、同步出站仍进 dry-run）
- **回放与注入在事件流里分开标记**：回放的帧标 `replay: 离线回放（沙箱 + dry-run，不碰 QQ）`，注入的帧标 `inject: 来自注入器`；`STAGES` 增加 `inject` / `replay` 中文标签。回放帧也不再被误判成注入（后者会命中上面的拦截逻辑，导致回放永远看不到本该发出的回复）
- 新增测试：
  - `test/inbox-unit.mjs`（116）：字段白名单/序列化/脱敏/轮转/坏行容错、`describeFrame`、`expandInjection` 全分支（群/私聊/通知/请求/纯图片/引用/缺参中文报错）、注入行往返一致、tailer 半行容错与四种定位语义
  - `test/replay-unit.mjs`（74）：沙箱计划与拷贝（敏感文件永不复制、媒体目录只提示）、强制配置（cwd/事件文件/dry-run/关闭外发）、mock 上下文与模拟回合事件顺序、结论归因（只有 level=error 才算出错，被拒分支是正常决策）、回收站剪枝、编排（单条/批量/上限/预算/异常/通知类）
  - `test/replay-console-unit.mjs`（53）：`hintConfig` 白名单（拒绝 cwd/traceFile/未知键）、真实 supervisor 读写录制与注入（含坏行、通道未开启、清空进回收站、失败报告形状）、四个新接口的真实 HTTP 往返与参数裁剪、**面板静态校验**（新元素/新函数/内联 onclick 全部存在、脚本可解析）
  - `test/inject-guard-unit.mjs`（15）：注入帧**绝不真的发出 QQ 消息**的时序全覆盖（见上）
  - `test/replay-live.mjs`（23）：真实桥代码的离线回放验收——关键词命中会回复、未 @ 会静默、私聊命令可用、安静时段给原因；断言 sandbox 隔离、dry-run、无 QQ 连接、无新增监听端口、源目录字节与 mtime 不变
  - `test/replay-live-host.mjs`（38，真机）：真实消息落盘 → 控制台列表 → 离线回放结论与线上一致（白名单来自线上快照、链路出现 `replay` 标记）→ 注入在轮询间隔内被消费、dry-run 拦下全部出站、注入帧不被二次录制 → 历史注入被明确跳过 → 注入回合的模型回复被拦下且原文未出现在任何出站里（模型 300s 内没回话时如实记为 WARN 而非假失败）

#### 硬约束验收台（阶段 4：验收）

- **新模块 `control/lib/acceptance.mjs`（纯函数）**：把 6 条硬约束逐条用**机器上现有的产物**算成 `✅ 达标 / ⚠️ 有提示 / ❌ 不达标 / ❔ 证据不足`，附证据文本、修复提示与关键指标；结论分 `all-green / partial / unknown / broken` 四种
  - ① 无静默分支：最近 500 条事件里所有 `ok:false`（被拒/失败）事件必须带非空 reason，缺的按 stage 点名（空白字符串也算缺）
  - ② 可关联：消息级事件的 traceId 覆盖率 + 有多少条消息真正走完 `inbound→reply`（只有被拦下没走到回复时是"告警"而不是"不达标"，并说明可能原因）
  - ③ 可回放：录制条数 + 最近一次回放的统计与**安全保证**（dry-run 必须开、QQ 连接必须 0、cwd 必须已沙箱化——任一不满足直接判不达标）+ 沙箱数量
  - ④ 可体检：体检的通过/失败/blocker 数与结论，失败项点名（blocker→不达标，普通失败→告警）
  - ⑤ 可导出：诊断包会收集的 6 类产物有几类在位，或最近一次导出的体积与文件名
  - ⑥ 可注入：通道开关 + dry-run 开关（**关掉即不达标**，因为注入会真的发到 QQ）+ 本次已消费行数 + 队列行数 + **拦下过几次异步 agent 回合的回复**
- **`GET /api/acceptance`**（token + 同源 Origin 校验）返回 `{ ok, verdict, totals, report, text }`；旧控制台缺少该方法时返回可读的"不支持"原因而不是 500
- **supervisor**：新增 `acceptance()`，顺带把"回放结果/导出结果"缓存成验收证据（`lastReplay` / `lastExport`），并给体检加 5 秒短时缓存（面板与验收台同时刷新时不再重复扫 `netstat`+`tasklist`）
- **面板**：顶部新增「硬约束验收台」卡片（6 行状态灯 + 证据 + 提示 + 「去看 →」跳转到对应卡片并高亮），加载即算、每 30 秒自动重算、**回放结束后立刻重算**（③ 的证据当场更新）
- 新增测试 `test/acceptance-unit.mjs`（68）：6 条约束的达标/告警/不达标/证据不足分支（含"回放期间有 QQ 连接""dry-run 被关掉""消息级事件缺 traceId"等危险分支必须判不达标）、汇总口径与文本视图、真实 supervisor 汇总（临时目录里造事件/快照/录制/沙箱，验证口径与回收站不计数）、`/api/acceptance` 的真实 HTTP 往返与 token/Origin 门禁、**面板静态校验**（新卡片元素、新函数、跳转目标、内联 onclick 全部存在）
- 阶段 4 完成意味着 6 条硬约束**全部落地且有测试与实时验收**：①无静默分支 ②traceId 贯穿 ③可回放 ④可体检 ⑤可导出 ⑥可注入

## v0.3 系列 —— 语音回复与实用小工具 / TTS & utilities
### v0.3.9（2026-09-11）

**群洞察与定时播报：活跃统计、群荣誉/公告/精华、每日群日报、重复提醒、MC 服务器状态**

- **群活跃统计**（`statsEnabled` **默认关闭**，新模块 `lib/stats.js`）：每个会话按天记录成员发言条数（`/` 开头的命令不计入），`/统计` 看今日榜、`/周榜` 看近 7 天榜；数据存 `cwd/qq-stats/<会话>.json`（原子写、`statsKeepDays` 天自动裁剪）
- **只读群信息查询**（`groupReadEnabled` 默认开）：`/荣誉`（`get_group_honor_info`，龙王/群聊之火/群聊炽焰/快乐源泉）、`/公告`（`_get_group_notice` 读取群公告）、`/群精华`（`get_essence_msg_list`）——全部只读，无风控增量
- **每日群日报**（`dailyReportEnabled` **默认关闭**）：到 `dailyReportTime`（默认 22:00）自动让 agent 用当天聊天记录 + 发言统计写一份口语化日报发到群里
  - 目标会话 = `dailyReportChats` 显式配置 ∪ 用 `/日报 on` 自助开启的群（两者都为空时回落到全部 `allowGroups`）
  - 复用会话续接通路：日报以 followup 进入该群会话，回复走既有出站链路；`/日报` 查看状态、`/日报 on|off` 切换（仅管理员）
- **重复提醒**（`recurringReminderEnabled` 默认开）：`每天8点提醒我喝水`、`每周一9点开会`、`每个工作日15点打卡`——到点自动重排下一次；`/reminders` 会标注周期（`每天 08:00` / `每周一 09:00` / `每个工作日 15:00`），跨宿主重启保留
- **MC 服务器状态**（`mcStatusEnabled` 默认开，新模块 `lib/mcping.js`）：`/mc mc.example.com:25565` 走 Java 版 Server List Ping（纯 `node:net`，零依赖零 Key），显示在线人数/上限、版本、延迟与 MOTD；离线给出中文原因
- `/help` 按开关动态展示新命令
- 新增测试：`test/insight-unit.mjs`（19，统计/荣誉/公告/精华/MC/日报全链路）、`test/stats-unit.mjs`（28，统计存储、榜单、荣誉文案、日报目标选择）、`test/reminder-unit.mjs` 扩充到 32 项（重复提醒解析与下一次触发时间）
- **最终自检三件套（同日补）**：
  - `test/static-unit.mjs`（14）：静态交叉检查——lib 全部 UTF-8 合法、代码读取的每个 `config.*` 都在 schema 里、schema 没有死键（139 个键全部有人用）、`QQBridge` 无重复方法名（115 个）、所有具名 import 都能找到导出、README 中英文均为滚动五版且首版==package.json 版本
  - `test/commands-unit.mjs`（72）：用 mock DSH 上下文（假 agents 服务记录 followup/系统提示段/注册的工具，并模拟 assistant 回复）把**每条命令分支与每个会话工具**都跑一遍：会话创建与工具注册、agent 回发、`/summary /export /撤回 /new`、待办/投票/`/mute /unmute /kick+确认`/`/clear`、群管全套、戳一戳/入群欢迎/防撤回（含图片补发）、入群审批流、`qq_send_file`（上传 + 3 类拒绝路径）/`qq_send_image`/`qq_recall`、resume 成功与失败两条路径、签到/重复提醒/词库/小游戏/运势/骰子/统计/MC，以及 `stop()` 幂等
  - `test/live-e2e.mjs`（6）：**真宿主端到端**——拉起真实 `dsh web` 宿主，假 OneBot 客户端连 6700 验证 `/status`、本地运势、**真 agent 回合**（验证 `defineTool` schema 被宿主接受、`agents.create`、session 事件回发）、同一会话连续对话，以及只读命令在"返回结构异常"的假 OneBot 端下不崩；重启宿主后确认日志出现 `session resumed qq-…`（v0.3.6 会话续接在真实宿主生效）

### v0.3.8（2026-09-11）

**防撤回 + 入群验证 + 敏感词/刷屏 + 群管 API 补齐**

- **防撤回**（`antiRecallEnabled` **默认关闭**，新模块 `lib/recall.js`）：每条入站消息缓存一份（含图片 URL），收到 `group_recall` / `friend_recall` notice 时把内容补发出来
  - `antiRecallInGroup`（默认 true）= 补发到群里；设 false 则私聊推送给第一个管理员
  - `antiRecallImages` 补发被撤回的图片（最多 3 张）、`antiRecallCacheSize` 每会话缓存条数、`antiRecallMaxAgeMinutes` 可恢复时长、`antiRecallCooldownSeconds` 防刷屏
  - 机器人自己撤回的消息不补发；未缓存的消息静默忽略
- **入群/加好友验证**（`verifyEnabled` **默认关闭**，新模块 `lib/verify.js`）：请求进入待审队列并**私聊推送管理员**（含验证题与序号），默认不自动放行
  - 管理员命令：`/待审` 列表、`/同意 <序号>`、`/拒绝 <序号>`、`/同意 all`
  - `verifyKeyword` 口令命中时自动放行；申请人若在验证期私聊答对算术题也会自动放行（`#allowed` 对该申请者临时放行，无需加入白名单）
  - `verifyTimeoutSeconds` 超时后自动出队并提醒管理员（60 秒一次的后台清扫，timer 已 unref）
- **敏感词过滤**（`filterEnabled` **默认关闭**，新模块 `lib/filter.js`）：词表文件 `cwd/qq-badwords.txt`（`#` 注释、`re:` 正则、非法正则安全跳过、按 mtime 热重载），`filterAction: warn|recall|mute` 三种处置（撤回走 `delete_msg`、禁言走 `set_group_ban`），`filterWhitelist` 白名单优先，管理员豁免
- **刷屏防护**（`floodEnabled` **默认关闭**）：滑动窗口（`floodWindowSeconds`/`floodMaxMessages`）先警告、累计 `floodStrikeLimit` 次后禁言 `floodMuteSeconds`
- **群管 API 补齐**（管理员，`adminEnabled`）：`/公告 <内容>`（`_send_group_notice`）、`/精华` 与 `/取消精华`（引用消息，`set_essence_msg`/`delete_essence_msg`）、`/名片 @某人 名字`（`set_group_card`）、`/头衔 @某人 头衔`（`set_group_special_title`）、`/全员禁言` 与 `/解除全员禁言`（`set_group_whole_ban`）
- **`/mute` `/unmute` 等既有群管命令也纳入写操作闸门**（限频 + 审计），不再直接调用 OneBot
- 新增测试：`test/guards-unit.mjs`（12，防撤回/敏感词/刷屏全链路）、`test/verify-flow-unit.mjs`（15，请求队列/口令/答题/好友请求/队列上限）、`test/verify-unit.mjs`（45，队列与命令解析）、`test/stats-unit.mjs`（23，群活跃统计与荣誉文案，为 v0.3.9 打底）；`test/reminders.js` 增加重复提醒解析

### v0.3.7（2026-09-11）

**零成本互动包（纯本地计算，不消耗模型）**

- **关键词问答库**（`keywordEnabled` **默认关闭**，新模块 `lib/keywords.js`）：本地 JSON 词库 `cwd/qq-keywords.json` 命中即回，**不走模型、秒回、零 token**；支持 `exact/contains/regex` 三种匹配（优先级 exact > contains > regex，同级别长词优先）、随机多答、附带图片（http 链接自动落盘 / 本地路径）、`scope: all|group|private` 作用域、每条独立冷却、`/` 开头的命令不参与匹配；文件被手工编辑后按 mtime 自动重载；管理员用 `/kw add 触发词 回复内容`、`/kw del 触发词`、`/kw list` 维护（写入会话级词条）
- **今日人品 / 运势 / 抽签 / 塔罗**（`fortuneEnabled` 默认开）：按「QQ 号 + 日期」哈希的**确定性**结果（同一天同一人永远一致），11 档运势评语 + 12 支签 + 22 张大阿卡纳正逆位解读，全部本地（新模块 `lib/fortune.js`）
- **骰子与随机选择**（`diceEnabled` 默认开）：`.r 3d6`、`掷骰 2d6+1`、`d100`、`/抽一个 火锅 烧烤 面条`、`/随机 A、B、C`（新模块 `lib/dice.js`，含 100 骰/1000 面上限保护）
- **积分经济**（`pointsEnabled` **默认关闭**，新模块 `lib/points.js`）：发言得积分（`pointsPerMessage`，每日封顶 `pointsDailyCap`）、签到奖励（`pointsCheckinBonus`）、`/积分` 查余额、`/排行榜` 看排行、`/转账 @某人 数量` 转账（余额不足/非法金额/转给自己都有明确中文报错）；每会话一个原子写 JSON
- **群内小游戏**（`gameEnabled` **默认关闭**，新模块 `lib/games.js`）：
  - **成语接龙**：内置 **373 条真实四字成语**词库，标准接龙规则（接上一句末字）、同音不同字不算、已用过的不能再用、超时（`idiomChainTimeoutSeconds`）自动收局；进行中的一句直接吃下群消息，**免 @** 让群友顺畅接龙
  - **猜数字**：1-`guessNumberMax` 随机答案，`guessNumberMaxTries` 次机会，大小提示与次数统计
- **帮助菜单**：`/help` 按开关动态列出新命令；词库管理只对管理员显示
- **修复两个既有缺陷**：
  - `QQBridge#stop()` 把 EventEmitter 当 disposer 存进 `disposers`，卸载插件时抛 `dispose is not a function`（现在通过 `#onServer()` 包装成真正的退订函数）
  - `IdiomChain` 的判定原本要求「首字 = 上一句**首字**」（非标准接龙），已改为标准规则「首字 = 上一句**末字**」
- 新增测试：`test/features-unit.mjs`（23，用 mock OneBot 服务器驱动真实 `QQBridge` 验证词库/运势/骰子/积分/接龙/猜数字/私聊关键词/`/撤回` 全链路），`test/games-unit.mjs` 按标准接龙规则重写关键用例

### v0.3.6（2026-09-11）

**agent 主动能力 + 会话续接 + 写操作闸门**

- **会话续接（`sessionResumeEnabled` 默认开）**：`routeKey → sessionId` 落盘 `cwd/qq-sessions.json`，宿主重启后第一条消息用 `ctx.agents.resume()` 接回上一次的**完整会话记录**（不再只靠 `qq-memory/` 的 30 行窗口续命）；续接失败自动回退新建会话，`/new` 会同时清掉映射真正重开
- **agent 主动发送工具**（`agentMediaToolsEnabled` 默认开，新模块 `lib/send.js` 做校验）：
  - `qq_send_image`：把本地图片发进当前会话（超过 `imageSendMaxBytes` 自动用 ffmpeg 压缩到 1920px JPEG 再发）
  - `qq_send_file`：把本地文件发进当前会话（群=群文件 `upload_group_file`，私聊=`upload_private_file`）
  - `qq_send_voice`：按需合成一条语音（复用 `ttsProvider`，含本地 GPT-SoVITS）
  - `qq_recall`：撤回机器人自己最近发出的消息（默认 1 条，最多 5 条）
  - **安全边界**：只允许发送 cwd（+ `fileSendDirs`）内的文件，`.ssh/.dsh/.env/credentials/*.pem/*.key` 等凭据类路径一律拒绝，超出 `fileSendMaxBytes` 拒绝
- **写操作闸门（`lib/actions.js`）**：所有危险 OneBot 写操作（禁言/踢人/公告/精华/名片/上传/撤回/合并转发/好友与入群审批）统一走令牌桶 + 每日上限 `actionRatePerMinute`/`actionRatePerDay` + 审计日志 `cwd/qq-actions.log`（含被拒记录）——新增功能不会悄悄放大账号风控面
- **合并转发卡片（`forwardLongReplies` 默认关）**：群聊里超长回复（默认 ≥ `forwardThresholdChars` 600 字）改发合并转发"聊天记录"卡片，失败自动回退普通文本
- **`/撤回` 命令**：免模型撤回机器人上一条消息（默认 110 秒内可撤，`recallWindowSeconds`）
- **统一存储层（`lib/store.js`）**：原子写（临时文件+rename）、mtime+size 缓存、损坏 JSON 容错，供会话映射等新状态使用
- **onebot.js 传输层大扩充**：新增 request 帧解析（入群/加好友请求事件）、`delete_msg`/`set_group_card`/`set_group_special_title`/`set_group_whole_ban`/`set_group_leave`/`set_essence_msg`/`_send_group_notice`/`set_msg_emoji_like`/`set_group_add_request`/`set_friend_add_request`/`upload_group_file`/`upload_private_file`/`send_group_forward_msg`/`send_private_forward_msg`/`get_group_member_list`/`get_group_member_info`/`get_group_info`/`get_friend_list`/`get_group_honor_info`/`_get_group_notice`/`get_essence_msg_list`/`get_group_msg_history`/`get_version_info`/`get_status`；`parseNotice` 补 `messageId`/`duration`
- **`/health` 扩展**：会话续接状态、写操作闸门拒绝次数与审计开关
- 新增测试：`test/actions-unit.mjs`（28）、`test/send-unit.mjs`（35）、`test/onebot-api-unit.mjs`（32，起真实反向 WS 服务器+客户端验证全部写操作负载与 request/notice 事件）

### v0.3.5（2026-09-04）

**生图功能（高拓展 provider 抽象）**
- **`/画 <描述词>` 生图**（`imageGenEnabled` 默认关闭）：群聊需 @机器人（防白嫖），私聊直接可用；生成后自动落盘 `cwd/qq-images/` 并发回图片段
- **双后端，与 TTS 同款拓展架构**（新模块 `lib/imagegen.js`，新增后端=加一个分支）：
  - `imageGenProvider: openai`——任意 OpenAI 兼容 `/images/generations`（DALL·E / 智谱 CogView / SiliconFlow…），`imageGenBaseUrl`/`imageGenApiKey`/`imageGenModel`/`imageGenSize` 可配，自动处理 `b64_json` 与 `url` 两种响应
  - `imageGenProvider: local`——本地 Stable Diffusion WebUI（AUTOMATIC1111 `/sdapi/v1/txt2img`），`imageGenSteps`/`imageGenCfgScale`/`imageGenSampler` 可配
- 成本/刷屏防护：`imageGenCooldownSeconds`（每会话冷却，默认 60s）+ `imageGenDailyLimit`（每日限额，默认 20）+ `imageGenMaxPromptChars`（描述词长度上限）
- `/help` 菜单在开启时显示生图用法；新增 `test/imagegen-unit.mjs`（15 项），全套 113 项

### v0.3.4（2026-09-01）

**第一梯队互动功能**
- **`/help` 命令帮助**：`/help` / `帮助` / `菜单` 动态列出可用命令（按功能开关与管理员身份展示）
- **戳一戳回复**（`pokeEnabled` 默认开启）：OneBot notice poke 事件，白名单会话内被戳时随机卖萌回复（`pokeReplies` 可配，`pokeCooldownSeconds` 限频）
- **语音朗读**（`voiceReadingEnabled` 默认开启）：@机器人引用文字说「读一下/念出来」，或 `/读 <文字>`——用 TTS 把文字念成语音发回（复用 ttsProvider，wav 自动转 mp3）
- **每日签到**（`checkinEnabled` **默认关闭**）：说「签到」打卡，连续/累计天数按会话持久化到 `cwd/qq-checkin/`；「签到榜」查看排行（新模块 `lib/checkin.js`）
- **入群欢迎语**（`welcomeEnabled` **默认关闭**）：notice group_increase 事件，@新人 + 欢迎文案（`welcomeText` 可配；机器人自己入群不触发）
- onebot.js 新增 `parseNotice` 与 notice 事件、消息透传 `senderName`
- 新增测试 `test/checkin-unit.mjs`（19 项）+ `test/notice-unit.mjs`（9 项），全套 98 项

### v0.3.3（2026-08-29）

**本地 TTS：GPT-SoVITS 零成本语音克隆**
- `ttsProvider` 新增 `local`：接入本地 GPT-SoVITS api_v2 服务（默认 `http://127.0.0.1:9880`），零 API 成本、零云端依赖，3-10 秒参考音频即克隆音色（`ttsLocalRefAudio` + `ttsLocalPromptText`）
- 本地合成输出 wav 自动用 ffmpeg 转 mp3 后发送（`ttsLocalConvertToMp3` 可关，兼容 QQ/NapCat record 段）
- 云端方案（azure/openai）保持不变；`ttsEnabled` 依旧默认关闭
- 新增 `buildLocalTtsRequest`（test/tts-unit.mjs 增至 12 项）
- 附 `TTS控制.bat` 一键启停本地服务（单实例守护，监听 127.0.0.1:9880）

### v0.3.2（2026-08-28）

**避开高峰期静默**
- 避开高峰期（`quietHoursEnabled` **默认关闭**）：开启后在工作日的静默时段内，机器人不回复任何入站消息（不处理、不消耗模型调用，调试日志记录跳过原因）
- 默认时段（`quietHours`）：`9:00-12:00` 与 `14:00-18:00`（本地时间 `H:MM-H:MM`，可自行修改；全角冒号自动归一化，支持跨午夜如 `22:00-2:00`）
- 周末豁免（`quietWeekendExempt` 默认开启）：周六/周日不受静默时段限制
- 已排定的定时提醒与投票开奖不受影响，仍会照常触发
- `/health` 新增避开高峰期状态行（开关/时段/周末豁免一目了然）
- 新增 `test/quiet-unit.mjs`（时段解析 + 工作日/周末/边界判定，24 项）

### v0.3.1（2026-08-28）

**状态通知 + GIF 抽帧**
- 状态变更通知（`notifyEnabled` 默认关闭）：宿主直连推送服务（PushPlus 或任意 JSON webhook，`notifyPushUrl`/`notifyToken`），机器人上线/掉线/桥就绪时推送——掉线通知不经 QQ，机器人都断了也能送达；`notifyCooldownSeconds` 防抖（默认 300s）
- GIF 动画表情抽帧（`gifFrameExtract` 默认开启）：识图前用 ffmpeg 把 gif 第一帧抽成 png（`ffmpegPath` 可配），动画表情对识图工具/模型的兼容性显著提升

### v0.3.0（2026-08-26）

**语音回复（TTS）与实用小工具**
- **语音回复 TTS**（`ttsEnabled` 默认关闭，需 key 与显式开启）：文字回复后自动跟一条语音（record 段）；默认配置 **Azure Speech**（晓晓 + `chat` 风格，`ttsAzureRegion`/`ttsVoice`/`ttsStyle`/`ttsMaxChars` 可调），也可一键切换 `ttsProvider: openai` 接任意 OpenAI 兼容 `/audio/speech`（OpenAI/Minimax/豆包…，`ttsBaseUrl`/`ttsModel`/`ttsVoice`）
- **`/health` 诊断**：插件版本、宿主运行时长、会话/提醒/投票/记忆数、识图与语音开关状态
- **私聊文件转存**：用户发来的文件自动下载到 `cwd/qq-files/` 并回复保存路径（`fileTransferEnabled`、`fileTransferMaxBytes` 默认 50MB）
- **`/export` 聊天导出**：把本会话持久化记录导出为 markdown 文件（`cwd/qq-exports/`，`exportEnabled`）
- 新增 `lib/tts.js`（Azure SSML / OpenAI 兼容双实现）+ `test/tts-unit.mjs`（6 项）；onebot.js 支持 file 段解析

## v0.2 系列 —— 插件化整合 / Plugin integration
### v0.2.9（2026-08-26）

**群管理套件**
- `/summary`：基于持久化记忆让 agent 总结本会话最近聊天（谁说了什么、有没有@我）
- 群投票：「投票：问题？A 选项 B 选项」→ 群友回复字母投票，到时自动公布（`/vote` 查进度、`/vote-end` 提前结束、`voteDurationSeconds` 可配时长）
- 共享待办：「/todo add xxx」「记一下：xxx」添加；`/todo` 查看、`/todo done N` 完成、`/todo clear` 清除已完成（每会话持久化到 `cwd/qq-todos/`）
- 管理员命令（`adminUsers` 白名单，生产已配本人）：
  - `/mute <QQ号或@某人> [分钟]`、`/unmute <QQ号或@某人>`（set_group_ban）
  - `/kick <QQ号或@某人>` → **需 60 秒内回复「确认踢」二次确认**才执行，回复「取消」放弃
  - `/clear` 清空当前会话与持久化记忆
- OneBotServer 新增 `setGroupBan`/`setGroupKick` 动作与 `ats` 透传
- 新增 `test/grouptools-unit.mjs`（投票解析 + 待办持久化，10 项）

### v0.2.8（2026-08-26）

**风控与稳定**
- 回复限流（`rateLimitEnabled`，**默认关闭**）：开启后每会话在 `rateLimitWindowSeconds`（默认 60s）内最多回复 `rateLimitMaxReplies`（默认 10）条，超出静默丢弃并记日志
- 消息去重（`dedupEnabled`，默认开启）：同一 message_id 在 `dedupWindowSeconds`（默认 300s）内重复投递（NapCat 重连重发）会被忽略，避免机器人重复回复
- 生产配置里已附两组的注释示例，按需开启

### v0.2.7（2026-08-26）

**维护性优化**
- 调试日志自动轮转：`qq-bridge-debug.log` 超过 2 MiB 时仅保留末尾 128 KiB，不再无限增长
- 图片保留期清理：宿主启动时自动删除 `qq-images/`、`qq-replies/` 中超过 `imageRetentionDays`（默认 14 天）的下载图片
- 新增 `test/reminder-unit.mjs`：提醒时间解析的 13 项纯单元测试（相对/绝对时间、关键词策略、内容提取）

### v0.2.6（2026-08-26）

**可配置识图方式**
- 新增 `visionMode: tool | native` 配置：`tool`（默认）= 图片存盘后由 agent 用 `visionToolName` 工具查看（稳定路线）；`native` = 图片作为**原生多模态附件**注入消息（DSH 0.1.1+ 附件机制，模型直接看图；文本模型自动降级为占位说明）
- 新增 `visionToolName`（默认 `describe_image`），可自由指定识图工具
- 私聊识图与 @引用图片两种场景都支持两种模式
- 生产默认保持 `tool` 模式；想体验原生多模态把 `visionMode` 改成 `native` 即可（当前原生多模态尚不稳定，自行取舍）

### v0.2.5（2026-08-26）

**定时提醒**
- 新增定时提醒：`30分钟后提醒我喝水`、`明天9点提醒我开会`、`后天 20:30 提醒我生日`
- 触发规则：群聊需 @机器人（@ 时可省略"提醒"字样，如「明天9点开会」）；私聊需带提醒关键词（提醒/记得/喊我/叫我/别忘了）
- 到点自动向原会话发送 `⏰ 提醒：<内容>`；提醒**跨宿主重启保留**（`cwd/qq-reminders.json`）
- 新增 `/reminders` 命令查看当前会话待执行提醒
- 新增配置：`reminderEnabled`（默认 `true`）、`reminderMaxPerChat`（默认 `10`）
- 支持相对时间（N秒/分钟/小时/天后）与绝对时间（今天/明天/后天 HH:mm、N点半/N点M分）
- `OneBotServer` 新增 `currentSocket()`：提醒发送自动使用最新连接（NapCat 重连后不失效）

### v0.2.4（2026-08-24）

**每会话持久化记忆**
- 每个群/私聊的最近对话自动落盘到 `cwd/qq-memory/`（每会话一个 JSON，滚动窗口）
- 宿主重启后自动把历史对话注入新会话系统提示——机器人不再失忆
- `/new` 会同时清除该会话的持久化记忆
- 新增配置：`memoryEnabled`（默认 `true`）、`memoryMaxEntries`（默认 `30`）

### v0.2.3（2026-08-23）

**安全默认值（响应上架评审）**
- 白名单语义改为「空 = 拒绝」：`allowUsers` 为空拒绝所有私聊，`allowGroups` 为空拒绝所有群消息
- 部署者必须显式填入自己的 QQ 号与群号后才能使用
- 配置描述、README（中英）、示例配置同步更新

### v0.2.2（2026-08-21）

**私聊识图**
- 私聊中用户发送的图片/动画表情（image/mface 段）自动下载到 `cwd/qq-images/` 并注入会话，agent 用 `describe_image` 查看后回应
- 下载按 Content-Type 推断扩展名（GIF 动画表情不再误存为 .png）
- 新增配置：`privateImageView`（默认 `true`）

### v0.2.1（2026-08-20）

**稳定性修复**
- 修复未处理的 Promise rejection（新增 `#safeReply` + 消息处理整体 try/catch）
- 修复 @+引用无内容时向 agent 发送空消息的问题
- 修复非语音引用误用"引用了一条语音"指令
- WS 连接 id 加计数器防碰撞
- 依赖 junction 全部指向共享树（修复 `web\node_modules\ws` 被清理导致的启动崩溃）

### v0.2.0（2026-08-20）

**插件化整合**
- 全部 QQ AI 功能整合为独立插件：双向消息桥、每群/每私聊会话分组、语音转文字、引用解析、表情系统、白名单、`/new` `/status`
- 语音转文字最终触发策略：群聊 @机器人并引用语音 → 转写回复；私聊语音直接转写（智谱 GLM-ASR-2512，可换任意 OpenAI 兼容端点）
- 私聊开启（`acceptPrivate: true`），agent 注入 chatScope 会话归属
- 完整 README（中英）、LICENSE、示例配置、风险与合规说明、测试脚本

## v0.1 系列 —— 首个可用版本 / First usable release
### v0.1.1（2026-08-16）

**首个可用版本**
- OneBot v11 反向 WebSocket 双向桥
- 每群/每私聊用户独立会话（sessionMode）
- 黄脸表情表、`[face:名字]` 标记、图片表情收藏、`qq_face_list`/`qq_face_send` 工具
- `allowUsers`/`allowGroups` 白名单、`accessToken`、仅@回复
