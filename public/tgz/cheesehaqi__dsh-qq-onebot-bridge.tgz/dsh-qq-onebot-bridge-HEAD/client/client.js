/**
 * v0.6「轻量化设计」：DSH 设置 → QQ助手。
 *
 * 这是**客户端 bundle**：DSH 的模块加载器按 `package.json` 的
 * `dsh.client`（`platform: web`）+ `exports["./client"]` 把它喂给浏览器，
 * 入口形态与官方/第三方插件一致：
 *
 *     window.__ModuleLoader__.load({ id, factory: (require) => { ...; return module.exports } })
 *
 * 面板只做两件事：`GET /qqai/panel` 读当前生效值，`POST /qqai/panel/set` 写回
 * profile 的 cordis.patch.yml（服务端路由见 lib/settings-routes.js）。
 * 不引第三方 UI 库（只用 react），样式全走 DSH 主题变量，所以深浅色都跟原生一致。
 */
window.__ModuleLoader__.load({
  id: 'dsh-qq-onebot-bridge',
  factory: (require) => {
    // ⚠️ 平台契约（v0.6 真机事故的教训）：客户端 bundle 是用**经典 <script>** 注入的，
    // 页面里没有 `exports` / `module`——每个 bundle 都得像平台自己的 bundle 那样自带这两行
    // CJS 垫片；而加载器只把 `factory(require)` 的**返回值**当作模块导出
    // （见 dsh-client-modules/lib/client.js:683）。少了这两行，宿主启动就会
    // 直接报 `dsh-qq-onebot-bridge: import failed: exports is not defined` 而整个起不来。
    var module = { exports: {} }
    var exports = module.exports

    const React = require('react')
    const h = React.createElement
    const { useCallback, useEffect, useState } = React

    const CSS = `
.qqai-wrap{display:flex;flex-direction:column;gap:14px;font-size:13px;color:var(--dsw-alias-label-primary,#111)}
.qqai-head{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.qqai-title{font-size:15px;font-weight:600}
.qqai-meta{color:var(--dsw-alias-label-secondary,#6b7280);font-size:12px;line-height:1.6}
.qqai-group{border:1px solid var(--dsw-alias-border-l1,#e5e7eb);border-radius:10px;background:var(--dsw-alias-bg-layer-1,#fff);overflow:hidden}
.qqai-group>summary{cursor:pointer;padding:10px 12px;font-weight:600;list-style:none;background:var(--dsw-alias-bg-layer-2,#f6f7f9)}
.qqai-group>summary::-webkit-details-marker{display:none}
.qqai-row{display:flex;align-items:center;gap:12px;padding:9px 12px;border-top:1px solid var(--dsw-alias-border-l1,#eef0f3)}
.qqai-row:first-of-type{border-top:none}
.qqai-row:hover{background:var(--dsw-alias-bg-layer-2,#f8fafc)}
.qqai-text{flex:1;min-width:0}
.qqai-label{display:block}
.qqai-hint,.qqai-key{color:var(--dsw-alias-label-secondary,#6b7280);font-size:11px;line-height:1.5}
.qqai-key{font-family:ui-monospace,SFMono-Regular,Menlo,monospace}
.qqai-badge{margin-left:6px;padding:1px 6px;border-radius:999px;font-size:10px;color:var(--dsw-alias-state-warn-primary,#b45309);border:1px solid currentColor}
.qqai-need{margin-left:6px;padding:1px 6px;border-radius:999px;font-size:10px;white-space:nowrap;color:var(--dsw-alias-label-secondary,#6b7280);background:var(--dsw-alias-bg-layer-2,#f1f5f9);border:1px solid var(--dsw-alias-border-l1,#e5e7eb)}
.qqai-hint b{font-weight:600;color:var(--dsw-alias-label-primary,#111)}
/* 开关照抄平台自己的 Switch.module.css（dsh-client-ui-primitives/lib/Switch.module.css）：
   之前我用的是"卡片同色轨道 + 白圆点"，浅色主题下 OFF 态等于隐形（用户反馈"关了以后感觉按钮消失了一样"）。
   官方取值（design token 表实测）：轨道 OFF = --dsw-alias-border-l3（浅色 #0000001f / 深色 #ffffff29），
   轨道 ON = --dsw-alias-brand-primary（浅色近黑 / 深色近白），圆点 OFF = --dsw-alias-switch-thumb，
   圆点 ON = --dsw-alias-label-primary-foreground；状态一律挂 aria-checked，视觉与无障碍语义不会打架。 */
.qqai-switch{box-sizing:border-box;position:relative;flex:0 0 auto;width:36px;height:20px;padding:2px;border:0;border-radius:999px;background:var(--dsw-alias-border-l3,#0000001f);cursor:pointer;transition:background .12s ease}
.qqai-switch[aria-checked="true"]{background:var(--dsw-alias-brand-primary,#1f2328)}
.qqai-switch:disabled{cursor:default;opacity:.5}
.qqai-switch:focus-visible{outline:var(--dsw-focus-ring-width,2px) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary,#4d6bfe));outline-offset:2px}
.qqai-knob{display:block;width:16px;height:16px;border-radius:50%;background:var(--dsw-alias-switch-thumb,#fff);transition:transform .12s ease}
.qqai-switch[aria-checked="true"] .qqai-knob{background:var(--dsw-alias-label-primary-foreground,#fff);transform:translateX(16px)}
.qqai-flash{padding:6px 10px;border-radius:8px;background:var(--dsw-alias-bg-layer-2,#f1f5f9);color:var(--dsw-alias-state-success-primary,#15803d)}
.qqai-err{padding:8px 10px;border-radius:8px;border:1px solid var(--dsw-alias-state-error-primary,#dc2626);color:var(--dsw-alias-state-error-primary,#dc2626);white-space:pre-wrap}
.qqai-warn{padding:8px 10px;border-radius:8px;border:1px solid var(--dsw-alias-state-warn-primary,#b45309);color:var(--dsw-alias-state-warn-primary,#b45309)}
.qqai-note{padding:8px 12px;border-bottom:1px solid var(--dsw-alias-border-l1,#eef0f3);background:var(--dsw-alias-bg-layer-2,#f8fafc);color:var(--dsw-alias-label-secondary,#6b7280);font-size:11px;line-height:1.6}
.qqai-note b{font-weight:600;color:var(--dsw-alias-label-primary,#111)}
/* 「相关链接」整组在页面的最上边（标题正下方、开关分组之前）：账号入口是组里第一条。
   2026-10-04 定稿："还是挪回到之前的位置吧，直接把相关链接整体拉到最上边"。
   注意：整行就是一个链接（含右边那段灰色说明），所以行本身要 cursor:pointer、且不要默认下划线。 */
.qqai-links{display:flex;flex-direction:column;gap:8px;padding-bottom:12px;border-bottom:1px solid var(--dsw-alias-border-l1,#e5e7eb)}
.qqai-link-row{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap;text-decoration:none;cursor:pointer}
.qqai-link{color:var(--dsw-alias-brand-primary,#2563eb);font-weight:600}
.qqai-link-row:hover .qqai-link{text-decoration:underline}
/* 快捷操作：启动 NapCat / 重新登录。按钮照平台的做法：细边框 + 主题 token，不自己配色。 */
.qqai-actions{display:flex;flex-direction:column;gap:8px;padding-bottom:12px;border-bottom:1px solid var(--dsw-alias-border-l1,#e5e7eb)}
.qqai-action-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.qqai-action{border:1px solid var(--dsw-alias-border-l3,#0000001f);background:var(--dsw-alias-bg-layer-1,#fff);color:var(--dsw-alias-label-primary,#111);border-radius:8px;padding:4px 10px;font:inherit;font-size:12px;cursor:pointer}
.qqai-action:hover:not(:disabled){background:var(--dsw-alias-bg-layer-2,#f6f7f9)}
.qqai-qr{display:flex;gap:12px;align-items:flex-start}
.qqai-qr-img{display:block;width:176px;height:176px;border:1px solid var(--dsw-alias-border-l1,#e5e7eb);border-radius:8px;background:#fff}
.qqai-qr-side{display:flex;flex-direction:column;gap:6px;font-size:12px}
.qqai-qr-title{font-weight:600;color:var(--dsw-alias-label-primary,#111)}
.qqai-action:disabled{cursor:default;opacity:.5}
/* 数值控件（v0.6.7）：风控阈值这类"数字"，不要再让用户去手改 YAML。
   观感对齐平台：细边框 + 主题 token，−/+ 与输入框同高。
   输入框必须关掉原生上下箭头（Chromium 的 ::-webkit-inner/outer-spin-button）：
   我们两边已经有 −/+ 了，那个又小又难点，纯属重复，视觉上也脏（用户 2026-10-17：「右边的上下控制层
   感觉没必要啊，而且还不方便，影响美观」）。appearance:textfield 是 Firefox 的写法，一并带上。
   注意：这段是 JS 模板字符串里的 CSS，注释里不能出现反引号（会把模板提前闭合），
   也不要写 markdown 的星号强调——<style> 的文本会被浅渲染测试当成页面文字收进去。 */
.qqai-num{display:flex;align-items:center;gap:6px;flex:0 0 auto}
.qqai-num-btn{width:26px;height:24px;padding:0;border:1px solid var(--dsw-alias-border-l3,#0000001f);border-radius:6px;background:var(--dsw-alias-bg-layer-1,#fff);color:var(--dsw-alias-label-primary,#111);font:inherit;font-size:14px;line-height:1;cursor:pointer}
.qqai-num-btn:hover:not(:disabled){background:var(--dsw-alias-bg-layer-2,#f6f7f9)}
.qqai-num-btn:disabled{cursor:default;opacity:.4}
.qqai-num-input{width:60px;height:24px;box-sizing:border-box;padding:0 6px;border:1px solid var(--dsw-alias-border-l3,#0000001f);border-radius:6px;background:var(--dsw-alias-bg-layer-1,#fff);color:var(--dsw-alias-label-primary,#111);font:inherit;font-size:12px;text-align:center;-moz-appearance:textfield;appearance:textfield}
.qqai-num-input::-webkit-outer-spin-button,.qqai-num-input::-webkit-inner-spin-button{-webkit-appearance:none;appearance:none;margin:0}
.qqai-num-input:focus-visible{outline:var(--dsw-focus-ring-width,2px) solid var(--dsw-focus-ring-color,var(--dsw-alias-brand-primary,#2563eb));outline-offset:1px}
.qqai-unit{font-size:11px;color:var(--dsw-alias-label-secondary,#6b7280);white-space:nowrap}
/* 「开关 + 数值」合并行右侧那一组：开关与数字并排（中间留 10px，别让它们粘在一起）。 */
.qqai-row-ctl{display:flex;align-items:center;gap:10px;flex:0 0 auto}
.qqai-state{font-size:11px}
.qqai-state.on{color:var(--dsw-alias-state-success-primary,#15803d)}
.qqai-state.off{color:var(--dsw-alias-state-warn-primary,#b45309)}
`

    async function callJson(path, options) {
      const response = await fetch(path, {
        cache: 'no-store',
        ...options,
        headers: { 'content-type': 'application/json', ...(options && options.headers) },
      })
      let payload = null
      try { payload = await response.json() } catch { /* 非 JSON 时下面按状态码报错 */ }
      if (!response.ok || payload?.ok !== true) {
        throw new Error(payload?.reason || `HTTP ${response.status}`)
      }
      return payload
    }

    /**
     * 极简富文本：只认 `**加粗**`（说明里用它点出"需要什么"），其余原样输出。
     * 不引 markdown 库——面板要的是轻量；也绝不把文本塞进 innerHTML。
     */
    function richText(text) {
      const parts = String(text ?? '').split('**')
      return parts.map((part, index) => (index % 2 === 1 ? h('b', { key: index }, part) : part))
    }

    /**
     * 开关本体（布尔行与「开关 + 数值」合并行共用一份，别各写一遍）。
     * 语义与视觉都挂在 aria-checked 上（与官方 Switch 一致）。
     */
    function SwitchControl({ on, busy, label, onChange }) {
      return h('button', {
        className: 'qqai-switch',
        role: 'switch',
        'aria-checked': on ? 'true' : 'false',
        disabled: busy === true,
        title: on ? '点一下关闭' : '点一下开启',
        'aria-label': `${label}：${on ? '开' : '关'}`,
        onClick: () => onChange(!on),
      }, h('span', { className: 'qqai-knob' }))
    }

    /**
     * 数值本体（`−` / 输入框 / `+`）：数值行与「开关 + 数值」合并行共用。
     *
     * 三条规矩：
     *   ① **范围来自服务端**（`spec.min/max/step`，由 schema 现读）——界面只做夹取，不做"我猜能被接受"的判断；
     *      真正的校验在 `POST /qqai/panel/set`，越界/小数会被 400 拒掉并说明范围。
     *   ② 输入过程中**不写**，回车 / 失焦 / 点 ± 才写一次（每敲一个字符就写配置，会把 patch 写烂）。
     *   ③ 写到一半的非法输入（空、`--`、超范围）回滚成上一个生效值，不弹一堆错。
     */
    function NumberControl({ spec, busy, label, onCommit }) {
      const min = Number.isFinite(spec.min) ? spec.min : null
      const max = Number.isFinite(spec.max) ? spec.max : null
      const step = Number.isFinite(spec.step) && spec.step > 0 ? spec.step : 1
      const clamp = (raw) => {
        const num = Number(raw)
        if (!Number.isFinite(num)) return null
        let next = Math.round(num / step) * step
        if (min !== null && next < min) next = min
        if (max !== null && next > max) next = max
        return next
      }
      const [draft, setDraft] = React.useState(String(spec.value ?? ''))
      // 服务端把新值推回来之后（保存成功 / 别的窗口改了），输入框跟着生效值走。
      React.useEffect(() => { setDraft(String(spec.value ?? '')) }, [spec.value])
      const commit = (raw) => {
        const next = clamp(raw)
        if (next === null) { setDraft(String(spec.value ?? '')); return }
        setDraft(String(next))
        if (next !== Number(spec.value)) onCommit(next)
      }
      return h('div', { className: 'qqai-num' },
        h('button', {
          className: 'qqai-num-btn', type: 'button', disabled: busy === true,
          title: `减 ${step}${min !== null ? `（最小 ${min}）` : ''}`, 'aria-label': `${label}：减`,
          onClick: () => commit(Number(spec.value) - step),
        }, '−'),
        h('input', {
          className: 'qqai-num-input', type: 'number', inputMode: 'numeric',
          min, max, step, value: draft, disabled: busy === true,
          'aria-label': label,
          onChange: (event) => setDraft(event.target.value),
          onBlur: (event) => commit(event.target.value),
          onKeyDown: (event) => {
            if (event.key === 'Enter') commit(event.target.value)
            if (event.key === 'Escape') setDraft(String(spec.value ?? ''))
          },
        }),
        h('button', {
          className: 'qqai-num-btn', type: 'button', disabled: busy === true,
          title: `加 ${step}${max !== null ? `（最大 ${max}）` : ''}`, 'aria-label': `${label}：加`,
          onClick: () => commit(Number(spec.value) + step),
        }, '+'),
        spec.unit ? h('span', { className: 'qqai-unit' }, spec.unit) : null)
    }

    /** 布尔行：左边标签+说明，右边一个开关。 */
    function Row({ row, busy, onSet }) {
      const on = row.value === true
      return h('div', { className: 'qqai-row' },
        h('div', { className: 'qqai-text' },
          h('label', { className: 'qqai-label' }, row.label,
            row.pending === true ? h('span', { className: 'qqai-badge', title: '配置文件里的值与当前生效值不一致' }, '待重启') : null,
            // 直接标出**出厂默认值**（不用"非默认"这种说法）：把徽标和右边的开关一对比，
            // 就知道自己改没改过。用户原话："改成'默认：状态'这样子好一点，而不是显示非默认一条"。
            row.defaultValue === true || row.defaultValue === false
              ? h('span', {
                className: 'qqai-need',
                title: `出厂默认：${row.defaultValue === true ? '开' : '关'} · 当前：${on ? '开' : '关'}`
                  + (row.nonDefault === true ? '（你改过）' : '（与出厂一致）'),
              }, `默认：${row.defaultValue === true ? '开' : '关'}`)
              : null,
            row.needs ? h('span', { className: 'qqai-need', title: '这个功能要额外准备的东西' }, row.needs) : null),
          row.hint ? h('span', { className: 'qqai-hint', title: row.hint }, richText(row.hint)) : null,
          h('span', { className: 'qqai-key' }, row.key)),
        h(SwitchControl, { on, busy, label: row.label, onChange: (next) => onSet(row.key, next) }))
    }

    /**
     * 数值行（v0.6.7）：`−` / 输入框 / `+`。
     *
     * 三条规矩：
     *   ① **范围来自服务端**（`row.min/max/step`，由 schema 现读）——界面只做夹取，不做"我猜能被接受"的判断；
     *      真正的校验在 `POST /qqai/panel/set`，越界/小数会被 400 拒掉并说明范围。
     *   ② 输入过程中**不写**，回车 / 失焦 / 点 ± 才写一次（每敲一个字符就写配置，会把 patch 写烂）。
     *   ③ 写到一半的非法输入（空、`--`、超范围）回滚成上一个生效值，不弹一堆错。
     */
    /** 数值行：左边标签+说明，右边 `− n +`（控件本体见 NumberControl）。 */
    function NumberRow({ row, busy, onSet }) {
      const min = Number.isFinite(row.min) ? row.min : null
      const max = Number.isFinite(row.max) ? row.max : null
      const range = min !== null && max !== null ? `${min}–${max}` : (min !== null ? `≥ ${min}` : (max !== null ? `≤ ${max}` : ''))
      return h('div', { className: 'qqai-row' },
        h('div', { className: 'qqai-text' },
          h('label', { className: 'qqai-label' }, row.label,
            row.pending === true ? h('span', { className: 'qqai-badge', title: '配置文件里的值与当前生效值不一致' }, '待重启') : null,
            row.defaultValue !== null && row.defaultValue !== undefined
              ? h('span', {
                className: 'qqai-need',
                title: `出厂默认：${row.defaultValue}${row.unit ? ' ' + row.unit : ''} · 当前：${row.value}${row.unit ? ' ' + row.unit : ''}`
                  + (row.nonDefault === true ? '（你改过）' : '（与出厂一致）')
                  + (range ? ` · 范围：${range}` : ''),
              }, `默认：${row.defaultValue}${row.unit ? ' ' + row.unit : ''}`)
              : null,
            row.needs ? h('span', { className: 'qqai-need', title: '这个功能要额外准备的东西' }, row.needs) : null),
          row.hint ? h('span', { className: 'qqai-hint', title: row.hint }, richText(row.hint)) : null,
          h('span', { className: 'qqai-key' }, range ? `${row.key}（${range}）` : row.key)),
        h(NumberControl, { spec: row, busy, label: row.label, onCommit: (next) => onSet(row.key, next) }))
    }

    /**
     * 「开关 + 数值」合并行（v0.6.7，用户 2026-10-17：「你这两个怎么不合并在一起」）：
     * 开关是总闸、数值是它的阈值，**同一行**里左右并排——不用再上下对照谁管谁。
     * 两个键各自独立写（点开关写布尔、改数字写数值），服务端一次只收一个键。
     */
    function SwitchNumberRow({ row, busy, onSet }) {
      const on = row.value === true
      const num = row.number ?? {}
      const min = Number.isFinite(num.min) ? num.min : null
      const max = Number.isFinite(num.max) ? num.max : null
      const range = min !== null && max !== null ? `${min}–${max}` : ''
      const numDefault = num.defaultValue !== null && num.defaultValue !== undefined
        ? `${num.defaultValue}${num.unit ? ' ' + num.unit : ''}`
        : ''
      return h('div', { className: 'qqai-row' },
        h('div', { className: 'qqai-text' },
          h('label', { className: 'qqai-label' }, row.label,
            row.pending === true || num.pending === true
              ? h('span', { className: 'qqai-badge', title: '配置文件里的值与当前生效值不一致' }, '待重启')
              : null,
            row.defaultValue === true || row.defaultValue === false
              ? h('span', {
                className: 'qqai-need',
                title: `出厂默认：${row.defaultValue === true ? '开' : '关'} · 当前：${on ? '开' : '关'}`
                  + (row.nonDefault === true ? '（你改过）' : '（与出厂一致）'),
              }, `默认：${row.defaultValue === true ? '开' : '关'}`)
              : null,
            numDefault !== ''
              ? h('span', { className: 'qqai-need', title: `${num.label}出厂默认 ${numDefault}${range ? ` · 范围 ${range}` : ''}` }, `数值默认：${numDefault}`)
              : null,
            row.needs ? h('span', { className: 'qqai-need', title: '这个功能要额外准备的东西' }, row.needs) : null),
          row.hint ? h('span', { className: 'qqai-hint', title: row.hint }, richText(row.hint)) : null,
          h('span', { className: 'qqai-key' }, `${row.key} + ${num.key ?? '?'}${range ? `（${range}）` : ''}`)),
        h('div', { className: 'qqai-row-ctl' },
          h(SwitchControl, { on, busy, label: row.label, onChange: (next) => onSet(row.key, next) }),
          h(NumberControl, { spec: num, busy, label: num.label || row.label, onCommit: (next) => onSet(num.key, next) })))
    }

    /**
     * 「相关链接」一组：账号入口（第一条，机器人账号登录 / 扫码）+ 更新日志 / 调试文档 / 调试台。
     *
     * 位置是用户 2026-10-04 连着几条指示定稿的："应该把账号登陆调到最上方" →
     * "不对不对应该在QQ助手的下边" → "还是挪回到之前的位置吧，直接把相关链接整体拉到最上边" →
     * "调试台改到调试文档下方"。
     * ⇒ 现在这**整组**渲染在标题正下方、开关分组之前，顺序由服务端 `links` 数组决定（数组顺序＝界面顺序）。
     *
     * ⚠️ **整行都要能点**（2026-10-04 真机"点击账号没反应"之后改的）：原来只有那行蓝色标签是 `<a>`，
     * 右边那段灰色说明文字是普通 `<span>`——点在说明上什么都不会发生，看着就是"点了没反应"。
     * 现在整行是一个 `<a>`（label + 状态 + 说明都在里面），点哪儿都能进。
     *
     * ⚠️ **桌面端里"相对地址 = 点了没反应"**（2026-10-04 真机，读 `app.asar` 定的案）：桌面端主窗口
     *   `setWindowOpenHandler(({url}) => { http(s) 才 shell.openExternal(url); 一律 deny 开新窗口 })`。
     * 面板里的账号/调试台入口是**相对地址**（`/qqai/account`），在桌面端（渲染基址 `dsh-app://app/`）
     * 会解析成 `dsh-app://app/qqai/account` ⇒ 协议不是 http(s)、又不许开窗口 ⇒ **什么都不发生**。
     * 所以在这类宿主里改成：先向宿主取 `?format=json` 拿到**绝对 http 地址**，再 `window.open(url)` ——
     * 那个地址是 http，桌面端会交给系统浏览器打开（和平台自己的外链同一个待遇）。
     * 网页版（http 宿主）保持原来的默认导航，别多此一举。
     */
    const isDesktopShell = () => typeof location !== 'undefined' && String(location.protocol ?? '') === 'dsh-app:'

    /** 桌面端专用：把相对入口解析成绝对 http 地址再开（取不到就退回默认导航）。 */
    async function openViaHost(href) {
      const url = await fetch(`${href}${href.includes('?') ? '&' : '?'}format=json`, { cache: 'no-store' })
        .then((r) => r.json())
        .then((payload) => (payload?.url ? String(payload.url) : ''))
        .catch(() => '')
      if (url === '') return false
      window.open(url, '_blank', 'noopener,noreferrer')
      return true
    }

    function Links({ links }) {
      if (!Array.isArray(links) || links.length === 0) return null
      return h('div', { className: 'qqai-links' },
        h('div', { className: 'qqai-meta' }, '相关链接'),
        links.map((link) => h('a', {
          key: link.id,
          className: 'qqai-link-row',
          href: link.href,
          target: '_blank',
          rel: 'noreferrer',
          title: link.hint ?? '',
          // 只有**同源相对**入口在桌面端会被卡住（外链是绝对 http(s)，平台自己会交给浏览器）。
          onClick: isDesktopShell() && String(link.href).startsWith('/')
            ? (event) => {
              if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return
              event.preventDefault()
              void openViaHost(link.href)
            }
            : undefined,
        },
        h('span', { className: 'qqai-link' }, link.label),
        link.state ? h('span', { className: `qqai-state ${link.running === true ? 'on' : 'off'}` }, link.state) : null,
        link.hint ? h('span', { className: 'qqai-hint' }, richText(link.hint)) : null)))
    }

    /**
     * 快捷操作：**启动 NapCat** / **重新登录**。
     *
     * 为什么要有（用户 2026-10-04："不能自己快捷启动吗？比如加到哪个控制选项中"）：
     * 以前只能让用户自己去右键"以管理员身份运行 launcher.bat"，而这台机器上双击自提权是**静默失败**的。
     * 现在点一下就行——代价是弹一次 UAC，点「是」即可。
     *
     * 这两条会 POST 到宿主的 `/qqai/napcat/start` 与 `/qqai/napcat/relogin`；
     * 服务端只按**加载器 PID** 清理，绝不会按镜像名杀 QQ（那会连用户自己的 QQ 一起杀掉）。
     */
    function Actions({ napcat, busy, onAction, qrStamp, onRefreshQr }) {
      const running = napcat?.running === true
      const port = napcat?.port ?? 6099
      const qr = napcat?.qr ?? {}
      // busy 没传 / 不是字符串时都按"没有请求在跑"处理（曾经把 undefined 当成"忙"，按钮一直灰着）。
      const pending = typeof busy === 'string' && busy !== ''
      const starting = busy === '/qqai/napcat/start' || busy === '/qqai/napcat/relogin'
      /**
       * 按钮旁边那句状态（用户 2026-10-04："应该在启动旁边加个提示，比如过会会出现二维码，
       * 而不是什么也没有"）——把"接下来会发生什么"直接写出来，别让用户对着空白猜。
       */
      const status = starting
        ? '正在启动 NapCat…等几秒，二维码会出现在下面'
        : running === true
          ? `NapCat：运行中（127.0.0.1:${port}）${qr.fresh === true ? ` · 二维码 ${qr.ageSeconds} 秒前刷新` : ''}`
          : 'NapCat：未运行 · 点「启动 NapCat」后等几秒，二维码会出现在下面'
      return h('div', { className: 'qqai-actions' },
        h('div', { className: 'qqai-meta' }, '快捷操作'),
        h('div', { className: 'qqai-action-row' },
          h('button', {
            className: 'qqai-action',
            disabled: running === true || pending,
            title: running === true ? 'NapCat 已经在运行了' : '以管理员身份启动 NapCat（本机策略下不会弹 UAC，命令直接执行）',
            onClick: () => onAction('/qqai/napcat/start', '启动 NapCat'),
          }, running === true ? 'NapCat 运行中' : (busy === '/qqai/napcat/start' ? '请求中…' : '启动 NapCat')),
          h('button', {
            className: 'qqai-action',
            disabled: pending,
            title: '只结束 NapCat 加载器（不会碰你自己开的 QQ），然后重新走一遍登录流程',
            onClick: () => onAction('/qqai/napcat/relogin', '重新登录'),
          }, busy === '/qqai/napcat/relogin' ? '请求中…' : '重新登录（扫码）'),
          h('span', { className: 'qqai-hint' }, status)),
        /**
         * **把二维码直接贴在这里**（用户 2026-10-04 连着两次："没弹出二维码啊"）。
         * NapCat 的码本来只印在它自己的控制台窗口里，而我们把输出重定向进日志了 ⇒ 窗口是空的、看不到码。
         * 现在只要 `cache/qrcode.png` 还新鲜（≤5 分钟），面板就把图显示出来，点「刷新二维码」重新取一张。
         */
        qr.fresh === true
          ? h('div', { className: 'qqai-qr' },
            h('img', {
              className: 'qqai-qr-img',
              src: `${qr.url}?t=${qrStamp}`,
              alt: 'NapCat 登录二维码',
              width: 176,
              height: 176,
            }),
            h('div', { className: 'qqai-qr-side' },
              h('div', { className: 'qqai-qr-title' }, '用手机 QQ 扫码登录'),
              h('div', { className: 'qqai-hint' }, '二维码由 NapCat 生成在 cache/qrcode.png；超过 5 分钟会自动隐藏。'),
              h('button', {
                className: 'qqai-action',
                disabled: pending,
                title: '重新拉取这张二维码图（NapCat 会自己刷新码）',
                onClick: () => (typeof onRefreshQr === 'function' ? onRefreshQr() : undefined),
              }, '刷新二维码')))
          // 运行中但**码已过期**：不能什么都不显示——那看起来就像"没有二维码"（用户已经问过一次了）。
          : (running === true
            ? h('div', { className: 'qqai-hint' }, qr.ageSeconds >= 0
              ? `二维码已过期（${qr.ageSeconds} 秒前刷新的那张，超过 5 分钟就不显示了）——点上面「重新登录（扫码）」重新生成`
              : '还没有二维码——点上面「启动 NapCat」，或直接点「重新登录（扫码）」')
            : null))
    }

    function Group({ group, busy, onSet }) {
      const note = group.note ? h('div', { className: 'qqai-note' }, richText(group.note)) : null
      // 三种行混排：布尔 / 数值 / 「开关 + 数值」合并行，按 `row.type` 分派（服务端载荷里都带 type）。
      const body = h('div', null, note, group.rows.map((row) => (
        row.type === 'switchNumber'
          ? h(SwitchNumberRow, { key: row.key, row, busy, onSet })
          : row.type === 'number'
            ? h(NumberRow, { key: row.key, row, busy, onSet })
            : h(Row, { key: row.key, row, busy, onSet })
      )))
      if (group.advanced !== true) {
        return h('div', { className: 'qqai-group' },
          h('div', { className: 'qqai-group-head', style: { padding: '10px 12px', fontWeight: 600, background: 'var(--dsw-alias-bg-layer-2,#f6f7f9)' } }, group.title),
          body)
      }
      return h('details', { className: 'qqai-group' },
        h('summary', null, `${group.title}（进阶）`),
        body)
    }

    /**
     * 渲染兜底：**插件里任何一个渲染异常都不该把整页设置带成白屏**。
     *
     * 真机事故（2026-10-04 用户："为啥点击刷新二维码会白屏"）：`onRefreshQr` 里写成
     * `setState({ qrStamp })`（整对象替换）→ 把 `data` 清掉 → 下一帧读 `data.napcat` 抛错 →
     * React 直接把整棵树卸掉，用户看到的就是**一片白**，连"哪出错了"都不知道。
     * 根因已在 `onRefreshQr` 修掉（改成函数式更新），这里再加一道边界：以后再有类似 bug，
     * 面板位置会显示一句人话 + 重试按钮，而不是白屏。
     */
    class PanelBoundary extends React.Component {
      constructor(props) { super(props); this.state = { error: '' } }
      static getDerivedStateFromError(error) { return { error: String(error?.message ?? error) } }
      render() {
        if (this.state.error !== '') {
          return h('div', { className: 'qqai-wrap' },
            h('style', null, CSS),
            h('div', { className: 'qqai-err' }, `QQ助手面板渲染出错：${this.state.error}`,
              h('div', null, '（已隔离，不影响其它设置项。点下面重试，若一直失败请把这句话报给开发者。）')),
            h('button', {
              className: 'qqai-retry',
              onClick: () => this.setState({ error: '' }),
            }, '重试'))
        }
        return this.props.children
      }
    }

    function QqAiPanel() {
      const [state, setState] = useState({ status: 'loading', data: null, error: '', flash: '', busyKey: '', busyAction: '', qrStamp: Date.now(), watchingQr: false })

      const load = useCallback(async () => {
        try {
          const data = await callJson('/qqai/panel')
          // 保留 qrStamp（用它做二维码的防缓存参数），其余按新载荷覆盖。
          setState((prev) => ({ ...prev, status: 'ready', data, error: '', flash: '', busyKey: '' }))
        } catch (error) {
          setState((prev) => ({ ...prev, status: 'error', data: null, error: String(error?.message ?? error), flash: '', busyKey: '' }))
        }
      }, [])

      useEffect(() => { void load() }, [load])

      const toggle = useCallback(async (key, value) => {
        setState((prev) => ({ ...prev, busyKey: key, error: '', flash: '' }))
        try {
          const result = await callJson('/qqai/panel/set', { method: 'POST', body: JSON.stringify({ key, value }) })
          // 布尔行说"开/关"，数值行说"→ 7"（同一个 setter，两种显示）。
          const shown = typeof value === 'number' ? String(value) : (value ? '开' : '关')
          setState({
            status: 'ready',
            data: result.panel ?? state.data,
            busyKey: '',
            busyAction: '',
            error: '',
            flash: `${key} → ${shown}${result.changed === true ? '（已写入配置）' : '（无需改动）'}${result.note ? ' · ' + result.note : ''}`,
          })
        } catch (error) {
          setState((prev) => ({ ...prev, busyKey: '', error: `写入失败：${String(error?.message ?? error)}` }))
        }
      }, [state.data])

      /**
       * 快捷操作（启动 NapCat / 重新登录）。
       * 这里故意**不用** callJson：`ok:false` 的那些回执（比如"已经在运行了""没找到加载器"）
       * 是**解释**不是错误，得原样显示给用户，不能因为 ok!==true 就抛成异常。
       */
      const runAction = useCallback(async (path, label) => {
        setState((prev) => ({ ...prev, busyAction: path, error: '', flash: '' }))
        try {
          const response = await fetch(path, {
            method: 'POST', cache: 'no-store', headers: { 'content-type': 'application/json' }, body: '{}',
          })
          let payload = null
          try { payload = await response.json() } catch { /* 下面按状态码报错 */ }
          if (payload === null) throw new Error(`HTTP ${response.status}`)
          setState((prev) => ({
            ...prev,
            status: 'ready',
            data: payload.panel ?? prev.data,
            busyKey: '',
            busyAction: '',
            error: payload.ok === true ? '' : `${label}：${payload.reason}`,
            flash: payload.ok === true ? `${label}：${payload.reason}${payload.note ? `（${payload.note}）` : ''}` : '',
            // 启动/重启成功 ⇒ **开始盯二维码**（用户 2026-10-04："应该在启动旁边加个提示，
            // 比如过会会出现二维码，而不是什么也没有"）——NapCat 起来后还要几秒才写出那张图，
            // 所以这段时间面板自己每 3 秒刷一次，图一出来就自动显示。
            watchingQr: payload.ok === true ? true : prev.watchingQr,
          }))
        } catch (error) {
          setState((prev) => ({ ...prev, busyAction: '', error: `${label}失败：${String(error?.message ?? error)}` }))
        }
      }, [state.data])

      /**
       * 盯着二维码：启动/重启之后，NapCat 要过几秒才把码写进 `cache/qrcode.png`。
       * 这里每 3 秒拉一次面板，**图一出现就停**（并在下面把它显示出来）；
       * 90 秒还没等到就停下并给一句人话，免得用户对着"什么都没有"发呆。
       */
      useEffect(() => {
        if (state.watchingQr !== true) return undefined
        const timer = setInterval(() => { void load() }, 3000)
        const giveUp = setTimeout(() => {
          setState((prev) => (prev.watchingQr === true
            ? { ...prev, watchingQr: false, flash: '还没看到二维码：点「QQ助手账号」看看扫码页，或再点一次「启动 NapCat」' }
            : prev))
        }, 90_000)
        return () => { clearInterval(timer); clearTimeout(giveUp) }
      }, [state.watchingQr, load])
      useEffect(() => {
        if (state.watchingQr === true && state.data?.napcat?.qr?.fresh === true) {
          setState((prev) => ({ ...prev, watchingQr: false, flash: '二维码已经出来了，用手机 QQ 扫下面那张即可' }))
        }
      }, [state.data, state.watchingQr])

      if (state.status === 'loading') return h('div', { className: 'qqai-wrap' }, h('style', null, CSS), h('div', { className: 'qqai-meta' }, '读取中…'))
      if (state.status === 'error') {
        return h('div', { className: 'qqai-wrap' },
          h('style', null, CSS),
          h('div', { className: 'qqai-err' }, `读取面板失败：${state.error}`, h('div', null, '如果是刚装好插件，先重启一次 DSH 让路由挂上。')),
          h('button', { className: 'qqai-retry', onClick: () => { setState({ status: 'loading', data: null, error: '', flash: '', busyKey: '' }); void load() } }, '重试'))
      }

      const data = state.data
      return h('div', { className: 'qqai-wrap' },
        h('style', null, CSS),
        h('div', { className: 'qqai-head' },
          h('span', { className: 'qqai-title' }, 'QQ助手'),
          h('button', { onClick: () => void load(), disabled: state.busyKey !== '' }, '刷新')),
        // 顶部第一块是「快捷操作」（启动 NapCat / 重新登录）——用户 2026-10-04："把快捷操作拉到相关链接上边"。
        // 理由也顺：没起来的时候，"把它启动起来"比"点开账号页"更该先看到。
        h(Actions, {
          napcat: data.napcat,
          busy: state.busyAction,
          onAction: runAction,
          qrStamp: state.qrStamp,
          onRefreshQr: () => {
            // ⚠️ 这里**必须**用函数式更新（`(prev) => ({...prev, ...})`）：整对象替换会把 `data` 一起清掉，
            //    下一帧 `data.napcat` 取不到 → React 渲染直接抛错 → **整页白屏**（真机踩过）。
            setState((prev) => ({ ...prev, qrStamp: Date.now() }))
            void load()
          },
        }),
        // 紧接着是「相关链接」整组（第一条是账号入口）。
        h(Links, { links: data.links }),
        h('div', { className: 'qqai-meta' },
          `profile：${data.profile} · 配置文件：${data.patchFile}${data.patchExists === false ? '（不存在）' : ''}`),
        h('div', { className: 'qqai-meta' }, data.notes?.apply ?? ''),
        h('div', { className: 'qqai-meta' }, data.notes?.scope ?? ''),
        state.flash ? h('div', { className: 'qqai-flash' }, state.flash) : null,
        state.error ? h('div', { className: 'qqai-err' }, state.error) : null,
        (Array.isArray(data.warnings) ? data.warnings : []).map((text, index) => h('div', { key: `warn-${index}`, className: 'qqai-warn' }, `⚠️ ${text}`)),
        data.groups.map((group) => h(Group, { key: group.id, group, busy: state.busyKey !== '', onSet: toggle })),
      )
    }

    exports.inject = ['slots']
    exports.apply = function apply(ctx) {
      ctx.slots.inject('settings.section', () => ctx.slots.register(
        { name: 'settings.section', id: 'qqai', order: 45, label: () => 'QQ助手' },
        () => h(PanelBoundary, null, h(QqAiPanel, null)),
      ))
    }

    return module.exports
  },
})
