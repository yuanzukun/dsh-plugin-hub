---
name: luxueliu-usage-price-report
description: 核算并输出本机各计费模型的当日用量与花费价目卡（¥/1M tokens 的缓存命中/未命中/输出，附分小时明细）。当用户问“今天/昨天/某天本机 API 花了多少钱”、“/usage 价目卡”、“各模型用量/计费/消费/花费”、“本地网关花了多少”时触发；数据源是本机 LiteLLM 网关落账 gateway_usage.jsonl，按官方公布价计价，只覆盖官方 ds/kimi/gemini/grok 与 OpenRouter，套餐额度（阿里百炼 Token Plan、ClinePass）与 Cursor 直连不计价、不落账。相邻场景：每周 USD 用量周报走 usage_report.py，模型降智/稳定性评估走 systematic-debugging，均不在此列。
author: luxueliu
---

# luxueliu-usage-price-report（本机 API 花费价目卡）

> 作者 luxueliu。与 [luxueliu-usage-command](https://github.com/luxueliu/luxueliu-usage-command)（DSH /usage 命令插件）同源：本 skill 是该能力的可复用知识版，命令插件是运行版；两者口径一致，改价需两处同步。

## 一句话口径

- **三类付费模型全覆盖计价**：
  1. 官方直连类（DeepSeek 官方 API，人民币计价 + 北京峰谷价）；
  2. 中转商类（OpenRouter / 各家中转 API，美元计价）；
  3. 套餐内的计费池类（自动排除阿里百炼 Token Plan、ClinePass 等套餐内的限额模型，仅计价付费池内的非免费模型）。
- **模型表可自由扩展**：三类都不是写死的——luxueliu-usage-command 插件的 cordis config 里
  用 dsModels / usdModels / planModels 可任意添加自己的网关模型与价格，aliases 可把网关落账里的
  旧模型名映射到新名字；无价目的未知模型自动归入"其他/退役别名"兜底，只列 token，绝不误算钱。
- **时区/币种自适应**：自动探测系统 locale 与时区——大陆用户看 ¥ + 北京时间，美区用户自动切换
  $ + 美东时间，港台用户 NT$/HK$；ds 峰谷始终按北京时间（北京电价峰谷），不随用户地区漂移。
- **当地货币直接展示**：所有消费以所在地货币（¥/$/NT$/HK$）显示，按模型×分小时拆分，不甩 token 数字。
- 不落账：Cursor 编辑器直连（不经过本地网关）、DeepSeek 官方直连（DSH 官方 harness 等旁路）。
- 只列"当日有消费"的模型；没消费的不列。

## 数据源

单真理源文件：`gateway_usage.jsonl`（本机 LiteLLM 网关落账，路径见 luxueliu-usage-command 插件配置 `gatewayLog`，留空自动探测）。

每行一条网关调用：created_at(UTC ISO)、ok、model(网关别名)、usage（prompt_tokens / completion_tokens / prompt_cache_hit_tokens / prompt_cache_miss_tokens / prompt_tokens_details.cached_tokens）。

- 只取 ok: true 且 token 非零的记录。
- 缓存拆分：优先 prompt_cache_hit_tokens / prompt_cache_miss_tokens；缺省时 hit = cached_tokens、miss = prompt_tokens - cached_tokens；再缺省则 miss = prompt_tokens。
- model 字段含历史别名，先归一到现行本地别名。
- 关键缺口：DeepSeek 官方直连（DSH 官方 harness 等）不经网关，不在本文件里；官方账单的 ds 金额
  会高于本处数额。Codex 自 2026-08-19 起改走网关 ds-flash/ds-pro，其用量计入本文件。

## 价目（官方公布价，联网核实 2026-08；¥ / 1M tokens：缓存命中/未命中/输出）

luxueliu-usage-command 插件 lib/index.js 顶部 PRICES / DS 是运行真理源；下表为镜像，改价需两处同步。

| 别名 | 命中 hit | 未命中 miss | 输出 out | 币种源 | 官方报价 / 备注 |
| --- | --- | --- | --- | --- | --- |
| ds-pro | 0.15 | 4.5 | 13.5 | CNY | 空闲=0.15/4.5/13.5，高峰×2=0.30/9/27；0817前 0.025/3/6 |
| ds-flash | 0.05 | 1.5 | 4.5 | CNY | 空闲=0.05/1.5/4.5，高峰×2=0.10/3/9；0817前 0.02/1/2 |
| kimi-k2.6 | 1.15 | 6.84 | 28.80 | USD→¥ | $0.16/$0.95/$4.0 Moonshot官方 |
| kimi-k2.7 | 1.37 | 6.84 | 28.80 | USD→¥ | $0.19/$0.95/$4.0 Moonshot官方 |
| kimi-k3 | 2.16 | 21.60 | 108.00 | USD→¥ | $0.30/$3.0/$15.0 Moonshot官方 |
| grok | 3.60 | 14.40 | 43.20 | USD→¥ | $0.50/$2.0/$6.0 xAI官方(<200K) |
| gemini3.1 | 3.60 | 14.40 | 86.40 | USD→¥ | $2/$12 Google；缓存按 in×0.25 [待核实] |
| gemini3.6 | 2.70 | 10.80 | 54.00 | USD→¥ | $1.5/$7.5 Google；缓存 in×0.25 [待核实] |
| gemini3.7 | 2.70 | 10.80 | 54.00 | USD→¥ | $1.5/$7.5 Google；缓存 in×0.25 [待核实] |
| fable5 | 7.20 | 72.00 | 360.00 | USD→¥ | $10/$50 OpenRouter，缓存=in×0.1 |
| opus5 | 3.60 | 36.00 | 180.00 | USD→¥ | $5/$25 OpenRouter，缓存=in×0.1 |

- 汇率 cnyPerUsd = 7.2，USD 计费模型折 ¥。
- 峰值窗（仅 ds）：北京时间 9:00-12:00、14:00-18:00（UTC+8）现价 ×2。ds 峰谷=北京电价峰谷，
  与用户地区/时区无关——美区用户同样按北京时间判定，不随本地时区漂移。
- 周末全天低谷（2026-08-23 起，梁文峰新规）：北京时间周六+周日全天不分峰谷，统一按低谷价（×1）计费。
- 地区定价差异（官方核实 2026-08）：qwen3.8-max 等百炼模型国内价 ¥12/36（缓存 ¥1.5）、国际价=Opus5
  的 40%/24%（两套价；走百炼 Token Plan 套餐时不计价，只列 token）；kimi/grok/gemini/OpenRouter
  官方美元价全球统一；gemini 缓存按 in×0.25 折 [待核实]。

## 输出格式（按本机 locale 自动切 ¥/$/NT$/HK$）

- 价目卡头：=== 价目卡 (¥ / 1M tokens:合计--/缓存命中/未命中/输出) ===（符号随币种）
- 每行：别名：今日消费(MM/DD): ¥合计--/¥命中/¥未命中/¥输出，按合计降序，只列有消费者。
- 分小时：=== YYYY-MM-DD 分小时 (别名--缓存命中/未命中/输出) ===，每小时 HH:00 miss=… hit=… out=…；ds 模型附 现价 ¥X | 0817后 ¥X 与 [标准/高峰]。
- 末段：口径(数据文件=仅网关调用)、时区、币种、ds 直达缺口的提醒。

## 执行

1. 优先直接跑 DSH /usage [today|yesterday|MM-DD|all]（luxueliu-usage-command 插件已实现）。
2. 无 DSH 时按本 skill 手算：读 gateway_usage.jsonl → 归并别名（内置 ALIAS_MAP + 用户 aliases 配置）→
   按上文价目 + 用户 dsModels/usdModels（local hour 按北京时间定 ds 峰谷）→ 组天/组小时 → 按格式输出。
3. 币种/时区探测：语言区域 zh-CN→CNY/¥、en-US→USD/$、zh-TW→TWD/NT$；时区用本机 Intl
   resolvedOptions().timeZone 或 datetime.now().astimezone()；小时用本地墙钟（ds 峰谷例外：北京时间）。
4. 用户的网关若加了自定义模型：官方直连加 dsModels（CNY + 可选 peakHours）、中转加 usdModels（USD）、
   套餐加 planModels；落账里的旧名用 aliases 映射到新名。没有价目的一律按"其他/退役别名"只列 token。

## 边界与升级

- 价格来自官方公布价（联网核实），不要拿本地旧表/待核实值拍定，信 token、别信钱。
- 改价同步两处：luxueliu-usage-command 插件 PRICES/DS + 本表。
- 百炼 Token Plan 与 ClinePass 是套餐额度，不是付费池、也不是直连计费，别混。
- DeepSeek 官方直连（Codex 夺舍等）不在网关落账内：问 ds 总额时说明口径缺口，不脑补成网关可覆盖。
