export declare const name: string;
export declare const inject: string[];
export interface UsageRecord {
  alias: string;
  ts: number;
  miss: number;
  hit: number;
  out: number;
}
export interface CommandResult {
  kind: "success" | "error";
  text: string;
}
export interface UsageCommandConfig {
  gatewayLog?: string;
  currency?: string;
  timezone?: string;
  cnyPerUsd?: number;
  showRateLegend?: boolean;
  tailBytes?: number;
  debugLog?: boolean;
}
export declare function computeReport(rawInput?: string, cfgOverride?: UsageCommandConfig): CommandResult;
export declare function collectRecords(cfg?: UsageCommandConfig): { records: UsageRecord[]; missing: boolean; skipped: number; tailed: boolean; error?: string };
export declare function apply(ctx: any): void;
