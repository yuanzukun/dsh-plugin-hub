/**
 * Panel preview.
 *
 * Renders the real client half into standalone HTML so the panel can be
 * inspected — and screenshotted — without a running Host or a logged-in GUI.
 * It reuses the same dependency-free hook runtime the bundle tests use: mounts
 * the panel, runs its effects against mock data, then serializes the result
 * next to a copy of the plugin's own stylesheet.
 *
 *   npm run preview                 # writes preview/panel.html + preview/panel-detail.html
 *   node tools/preview.mjs out.html # or wherever you want it
 *
 * The theme tokens in the preview harness are a dark-theme stand-in; the real
 * values come from the Host.
 */
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const CLIENT = path.join(root, 'lib', 'client.js')
// Flags are not paths: `--check` must not become the output file name.
const OUT_ARG = process.argv.slice(2).find((argument) => argument.startsWith('-') !== true)
const OUT = OUT_ARG === undefined ? path.join(root, 'preview', 'panel.html') : path.resolve(OUT_ARG)
const source = readFileSync(CLIENT, 'utf8')

// Read the version from the package instead of hardcoding it: the preview is where the
// README screenshots come from, and a footer that says the wrong version is exactly the
// kind of drift that made the last release notes outdated.
const PACKAGE = JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8'))

const NOW = Date.now()
const MINUTE = 60 * 1000
const HOUR = 3600 * 1000

const TODOS = [
  {
    id: 't-1a2b3c4d',
    title: '把dsh-global-todo发到 npm，并在 README 里补上截图',
    description: '先把版本号对齐 package.json 与 VERSION，再跑一遍 npm run verify。\n发布走 Trusted Publishing，不需要 token。',
    status: 'doing',
    priority: 'high',
    dueAt: new Date(NOW + 20 * HOUR).toISOString(),
    tags: ['发布', '文档'],
    // A plan inside the todo: the row shows progress and the detail shows the ticks.
    steps: [
      { text: '对齐 package.json 与 VERSION', done: true },
      { text: '跑一遍 npm run verify', done: true },
      { text: '打 tag 并推送', done: false },
      { text: '补 README 截图', done: false },
    ],
    originSessionId: 'session-77aa31c0-1111-2222-3333-444455556666',
    notes: [
      { at: NOW - 2 * HOUR, by: 'agent', text: '版本号已对齐，verify 跑过了。' },
      { at: NOW - HOUR, by: 'agent', text: '卡在需要你在 npm 上绑定 Trusted Publisher，绑定后我打 tag 发布。' },
    ],
    links: [
      { kind: 'url', value: 'https://docs.npmjs.com/trusted-publishers', title: 'docs.npmjs.com/trusted-publishers' },
      { kind: 'file', value: '/home/me/projects/dsh-global-todo/docs/DESIGN.md', title: 'DESIGN.md' },
      { kind: 'file', value: '/home/me/projects/dsh-global-todo/docs/归档设计稿.md', title: '归档设计稿.md', missing: true },
    ],
    createdAt: NOW - 3 * HOUR,
    createdBy: 'human',
    updatedAt: NOW - 2 * HOUR,
    doneAt: null,
    sessionId: 'session-9f2c1e',
    sessionAlive: true,
    sessionDir: '/home/me/projects/dsh-global-todo',
    lastDispatch: { at: NOW - 2 * HOUR, mode: 'new', ok: true, sessionId: 'session-9f2c1e' },
  },
  {
    id: 't-5e6f7a8b',
    title: '等交换机到货后重测内网吞吐',
    description: '',
    status: 'open',
    priority: 'urgent',
    dueAt: new Date(NOW - 26 * HOUR).toISOString(),
    tags: [],
    links: [{ kind: 'url', value: 'https://github.com/example/dorm-network', title: 'github.com/example/dorm-network' }],
    createdAt: NOW - 30 * HOUR,
    createdBy: 'agent',
    updatedAt: NOW - 30 * HOUR,
    doneAt: null,
    sessionId: '',
    sessionAlive: false,
    sessionDir: '',
    originDir: '/home/me/projects/dorm-network',
    originSessionId: 'session-00000000-0000-4000-8000-000000000001',
    lastDispatch: null,
  },
  {
    id: 't-9c0d1e2f',
    title: '给 staging 迁移动手写一个回滚脚本',
    originSessionId: 'session-00000000-0000-4000-8000-000000000001',
    description: '先把现网 schema 导出成 SQL，再在 staging 上演练一次。',
    status: 'open',
    priority: 'low',
    dueAt: null,
    tags: ['运维'],
    links: [],
    createdAt: NOW - 2 * 24 * HOUR,
    createdBy: 'human',
    updatedAt: NOW - 2 * 24 * HOUR,
    doneAt: null,
    sessionId: '',
    sessionAlive: false,
    lastDispatch: null,
  },
  {
    id: 't-3a4b5c6d',
    originSessionId: 'session-55bb11ff-aaaa-bbbb-cccc-ddddeeeeffff',
    title: '把周报模板换成新的四段式',
    description: '',
    status: 'done',
    priority: 'normal',
    dueAt: null,
    tags: [],
    links: [],
    createdAt: NOW - 5 * 24 * HOUR,
    createdBy: 'agent',
    updatedAt: NOW - 4 * 24 * HOUR,
    doneAt: NOW - 4 * 24 * HOUR,
    notes: [{ at: NOW - 4 * 24 * HOUR, by: 'agent', text: '已按四段式重写并替换了旧模板。' }],
    completion: {
      at: NOW - 4 * 24 * HOUR,
      by: 'agent',
      summary: '把周报模板换成「进展 / 阻塞 / 下周 / 需要的支持」四段式，并在工作区里替换了旧模板。',
      sessionId: 'session-77aa31',
      artifacts: [{ kind: 'file', value: '/home/me/projects/dsh-notes/模板/周报.md', title: '周报.md' }],
    },
    sessionId: '',
    sessionAlive: false,
    lastDispatch: null,
  },
]

const COUNTS = { total: 4, open: 2, doing: 1, done: 1, cancelled: 0, overdue: 1 }

// ------------------------------------------------------------------ runtime

function createRuntime() {
  const stores = new Map()
  const classTypes = []
  let hooks = []
  let cursor = 0
  class Component {
    constructor(props) {
      this.props = props ?? {}
      this.state = {}
    }
  }
  const React = {
    Component,
    createElement: (type, props, ...children) => ({ type, props: props ?? {}, children }),
    useState(initial) {
      const index = cursor++
      // Capture the owning store: the setter may run long after expansion, when
      // the shared `hooks` cursor points at a different component.
      const store = hooks
      if (store[index] === undefined) store[index] = { value: typeof initial === 'function' ? initial() : initial }
      return [
        store[index].value,
        (next) => {
          store[index].value = typeof next === 'function' ? next(store[index].value) : next
        },
      ]
    },
    useRef(initial) {
      const index = cursor++
      if (hooks[index] === undefined) hooks[index] = { value: { current: initial } }
      return hooks[index].value
    },
    useCallback: (fn) => fn,
    useMemo: (fn) => fn(),
    useEffect(effect) {
      const index = cursor++
      if (hooks[index] === undefined) hooks[index] = { effect }
    },
  }
  function expand(element, effects, path = '') {
    if (element === null || element === undefined || typeof element !== 'object') return element
    // Children arrive as arrays; an array node has no `type`, so it must be
    // descended into explicitly or its component children never render.
    if (Array.isArray(element)) return element.map((child, index) => expand(child, effects, `${path}/${index}`))
    const { type, props, children } = element
    if (type !== undefined && type.prototype instanceof Component) {
      classTypes.push(type)
      const instance = new type(props)
      element.children = [expand(instance.render(), effects, path)]
      return element
    }
    if (typeof type === 'function') {
      const key = `${path}#${type.name || 'anon'}`
      let store = stores.get(key)
      if (store === undefined) {
        store = []
        stores.set(key, store)
      }
      const outerHooks = hooks
      const outerCursor = cursor
      hooks = store
      cursor = 0
      let rendered
      try {
        rendered = type({ ...props, children })
      } finally {
        hooks = outerHooks
        cursor = outerCursor
      }
      element.children = [expand(rendered, effects, path)]
      for (const hook of store) if (hook?.effect !== undefined) effects.push(hook.effect)
      return element
    }
    if (Array.isArray(children)) element.children = children.map((child, index) => expand(child, effects, `${path}/${index}`))
    return element
  }
  return {
    React,
    /**
     * Forget every hook store.
     *
     * Hook state is keyed by path + component name so repeated mounts behave like
     * re-renders of one tree — which means a later mount with *different* props would still
     * see the first mount's state. A variant that needs a different starting state has to
     * start over.
     */
    reset() {
      stores.clear()
    },
    mount(component, props) {
      const effects = []
      const tree = expand({ type: component, props: props ?? {}, children: [] }, effects)
      return { tree, effects }
    },
  }
}

// ------------------------------------------------------------------ html

const VOID_TAGS = new Set(['input', 'br', 'img', 'hr', 'meta', 'link'])

function escapeHtml(value) {
  return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

function toHtml(node) {
  if (node === null || node === undefined || node === false) return ''
  if (Array.isArray(node)) return node.map(toHtml).join('')
  if (typeof node === 'string' || typeof node === 'number') return escapeHtml(node)
  if (typeof node !== 'object') return ''
  const { type, props = {}, children } = node
  if (typeof type === 'function') return toHtml(children ?? [])
  const attrs = []
  for (const [key, value] of Object.entries(props)) {
    if (value === undefined || value === null || value === false || key === 'children') continue
    if (key === 'key' || key === 'ref') continue
    if (key === 'style' && typeof value === 'object') {
      attrs.push(`style="${escapeHtml(Object.entries(value).map(([k, v]) => `${k.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`)}:${v}`).join(';'))}"`)
      continue
    }
    if (key === 'className') {
      attrs.push(`class="${escapeHtml(value)}"`)
      continue
    }
    if (typeof value === 'boolean') {
      if (value) attrs.push(key)
      continue
    }
    if (typeof value === 'function') continue
    attrs.push(`${key}="${escapeHtml(value)}"`)
  }
  const inner = toHtml(children ?? [])
  const open = `<${type}${attrs.length > 0 ? ` ${attrs.join(' ')}` : ''}>`
  return VOID_TAGS.has(type) ? open : `${open}${inner}</${type}>`
}

// ------------------------------------------------------------------ run

const runtime = createRuntime()

/**
 * The shell hands slot components a `useSessions` selector hook. The preview has
 * no shell, so it supplies a small stand-in — otherwise the hand-off picker would
 * render with no conversations to choose from and the screenshot would document
 * a feature nobody can see.
 */
// `updatedAt` is the sidebar's own recency key; these deliberately do not match the
// insertion order, so "sorted by last use" can be told apart from "in the order the
// map happened to have".
const FAKE_SESSIONS = {
  byId: {
    'session-77aa31c0-1111-2222-3333-444455556666': {
      id: 'session-77aa31c0-1111-2222-3333-444455556666',
      title: 'dsh-global-todo · 设计与实现',
      cwd: '/home/me/projects/dsh-global-todo',
      retainedBy: { mainView: 1 },
      // The one exception in the shell's rule: a blank session that is *current* stays.
      blank: true,
      updatedAt: NOW - 6 * HOUR,
    },
    'session-00000000-0000-4000-8000-000000000001': {
      id: 'session-00000000-0000-4000-8000-000000000001',
      title: 'Docker 与知识库',
      cwd: '/home/me',
      updatedAt: NOW - 10 * MINUTE,
    },
    'session-55bb11ff-aaaa-bbbb-cccc-ddddeeeeffff': {
      id: 'session-55bb11ff-aaaa-bbbb-cccc-ddddeeeeffff',
      title: 'dorm-network',
      cwd: '/home/me/projects/dorm-network',
      updatedAt: NOW - 2 * HOUR,
    },
    // A subagent child is never a top-level row in the shell, so it must not be offered.
    'session-cccc0000-1111-2222-3333-444455556666': {
      id: 'session-cccc0000-1111-2222-3333-444455556666',
      title: '子代理（不应出现）',
      cwd: '/home/me/projects/dsh-global-todo',
      origin: 'subagent',
      updatedAt: NOW - 30 * 1000,
    },
    // A blank session is hidden unless it is the one in front of the user.
    'session-dddd0000-1111-2222-3333-444455556666': {
      id: 'session-dddd0000-1111-2222-3333-444455556666',
      title: '空白会话（不应出现）',
      cwd: '/home/me',
      blank: true,
      updatedAt: NOW - 20 * 1000,
    },
    // Archived through the registry set...
    'session-aaaa0000-1111-2222-3333-444455556666': {
      id: 'session-aaaa0000-1111-2222-3333-444455556666',
      title: '已归档的老对话（不应出现）',
      cwd: '/home/me/projects/old-project',
      updatedAt: NOW - 1 * MINUTE,
    },
    // ...and archived through the row's own flag.
    'session-bbbb0000-1111-2222-3333-444455556666': {
      id: 'session-bbbb0000-1111-2222-3333-444455556666',
      title: '被归档的会话（不应出现）',
      cwd: '/home/me',
      archived: true,
      updatedAt: NOW - 2 * MINUTE,
    },
  },
}
const FAKE_WORKSPACES = {
  items: [
    { workspaceId: 'ws-1', title: 'dsh-global-todo', path: '/home/me/projects/dsh-global-todo', sessionIds: [] },
    { workspaceId: 'ws-2', title: 'dorm-network', path: '/home/me/projects/dorm-network', sessionIds: [] },
  ],
  archivedSessionIds: ['session-aaaa0000-1111-2222-3333-444455556666'],
}
TODOS.push({
  id: 't-3f4a5b6c',
  title: '手动记一条：等交换机到货',
  description: '',
  status: 'open',
  priority: 'low',
  dueAt: null,
  tags: [],
  links: [],
  createdAt: NOW - 30 * MINUTE,
  createdBy: 'human',
  updatedAt: NOW - 30 * MINUTE,
  doneAt: null,
  sessionId: '',
  sessionAlive: false,
  sessionDir: '',
  lastDispatch: null,
})
const previewProps = {
  useSessions: (read) => read(FAKE_SESSIONS),
}
let entry = null
new Function('window', 'document', 'navigator', source)(
  { __ModuleLoader__: { load: (registration) => (entry = registration) } },
  undefined,
  { language: 'zh-CN' },
)
const plugin = entry.factory((name) => (name === 'react' ? runtime.React : undefined))

const registered = new Map()
plugin.apply({
  // The picker reads the workspace snapshot for the archived set and the workspace
  // options, exactly as it does in the real shell.
  workspaces: { list: { getSnapshot: () => FAKE_WORKSPACES } },
  effect(callback) {
    const dispose = callback()
    return typeof dispose === 'function' ? dispose : () => {}
  },
  locale: { register: () => () => {}, subscribe: () => () => {}, getLocale: () => ({ locale: 'zh-CN' }) },
  // Hostile on purpose: the real shell's `inject` can throw, and a throw from an
  // effect is not a render error, so no error boundary catches it. An earlier
  // version called it unguarded and the panel went blank; this keeps that from
  // coming back.
  inject: () => {
    throw new Error('preview: no services are mounted here')
  },
  slots: {
    inject: (_name, callback) => {
      callback()
      return () => {}
    },
    register: (options, component) => {
      registered.set(options.name, component)
      return () => {}
    },
  },
})

const requestedUrl = []

// Scenarios let one harness photograph states the panel can only reach by clicking:
// an empty list, a filter that matches nothing, the inbox, and a due reminder.
const SCENARIOS = {
  default: { todos: TODOS, counts: COUNTS },
  empty: {
    todos: [],
    counts: { total: 0, open: 0, doing: 0, done: 0, cancelled: 0, archived: 0, overdue: 0, inbox: 0 },
  },
  filtered: { todos: [], counts: COUNTS },
  inbox: {
    todos: TODOS.slice(0, 2).map((todo) => ({ ...todo, tags: [...(todo.tags ?? []), 'inbox'] })),
    counts: { ...COUNTS, total: 2, open: 2, doing: 0, done: 0, overdue: 0, inbox: 2 },
  },
  // An agent finished something and the owner has not answered: the row carries the badge
  // and the filter chip is the only thing that surfaces it.
  review: {
    todos: [
      {
        ...TODOS[0],
        status: 'done',
        doneAt: NOW - 20 * MINUTE,
        review: { pending: true, at: NOW - 20 * MINUTE, by: 'agent' },
        completion: { at: NOW - 20 * MINUTE, by: 'agent', summary: '按计划做完了', sessionId: '', artifacts: [] },
      },
      { ...TODOS[1], status: 'done', doneAt: NOW - HOUR },
    ],
    counts: { ...COUNTS, total: 2, open: 0, doing: 0, done: 2, overdue: 0, review: 1 },
  },
  reminders: {
    todos: TODOS,
    counts: COUNTS,
    reminders: {
      due: [
        { id: TODOS[0].id, seq: 1, dueAt: NOW - 5 * MINUTE, title: TODOS[0].title },
      ],
    },
  },
}
let scenario = 'default'

globalThis.fetch = async (url) => {
  requestedUrl.push(url)
  const active = SCENARIOS[scenario] ?? SCENARIOS.default
  const payload = url.includes('/health')
    ? {
        ok: true,
        data: {
          plugin: 'dsh-global-todo',
          version: PACKAGE.version,
          store: { file: '/home/me/.dsh/global-todo/todos.json' },
          dispatch: { agents: true },
          // The automatic collect switch is a Host setting; the panel only mirrors it. The
          // exemption list is one too, and `dorm-network` is the fixture conversation whose
          // directory is known — so the render check can assert the state it puts that group in.
          settings: {
            autoCollect: true,
            cooldownMinutes: 30,
            exemptWorkspaces: ['/home/me/projects/dorm-network'],
          },
          autoCollect: { enabled: true, asking: false, lastAsk: null, error: null },
          ...(active.reminders === undefined ? {} : { reminders: active.reminders }),
        },
      }
    : { ok: true, data: { todos: active.todos, counts: active.counts } }
  return { status: 200, json: async () => payload }
}

const first = runtime.mount(registered.get('main'), previewProps)
for (const effect of first.effects) effect()
await new Promise((resolve) => setTimeout(resolve, 20))
const second = runtime.mount(registered.get('main'), previewProps)
// A third variant with selection mode on: the harness cannot re-render after a click, so
// the mode is asked for up front and the selection UI can be asserted for real.

const css = source.slice(source.indexOf('const CSS = `') + 'const CSS = `'.length, source.indexOf('`\n\n    // ---'))

/** Find the first node matching a predicate, depth first. */
/** Collect every button matching `predicate`, depth-first, in render order. */
function collectButtonsBy(node, predicate, into) {
  if (node === null || node === undefined || typeof node !== 'object') return into
  if (Array.isArray(node)) {
    for (const child of node) collectButtonsBy(child, predicate, into)
    return into
  }
  if (node.type === 'button' && predicate(node) === true) into.push(node)
  return collectButtonsBy(node.children ?? [], predicate, into)
}

function findButtonBy(node, predicate) {
  if (node === null || node === undefined || typeof node !== 'object') return null
  if (Array.isArray(node)) {
    for (const child of node) {
      const hit = findButtonBy(child, predicate)
      if (hit !== null) return hit
    }
    return null
  }
  if (predicate(node)) return node
  return findButtonBy(node.children ?? [], predicate)
}

/** Find the first button whose label contains `label`. */
function findButton(node, label) {
  if (node === null || node === undefined || typeof node !== 'object') return null
  if (Array.isArray(node)) {
    for (const child of node) {
      const hit = findButton(child, label)
      if (hit !== null) return hit
    }
    return null
  }
  if (node.type === 'button') {
    const text = []
    const collect = (child) => {
      if (child === null || child === undefined) return
      if (typeof child === 'string' || typeof child === 'number') text.push(String(child))
      else if (Array.isArray(child)) child.forEach(collect)
      else if (typeof child === 'object') collect(child.children ?? [])
    }
    collect(node.children)
    if (text.join(' ').includes(label)) return node
  }
  return findButton(node.children ?? [], label)
}

// Open the *last* row's menu: the groups render 逾期 → 接下来 → 没有截止时间 →
// 已完成, so the last one is the finished todo — the detail view that shows the
// completion record this preview exists to document.
const menuTriggers = []
collectButtonsBy(second.tree, (node) => node.props?.['aria-haspopup'] === 'menu', menuTriggers)
const menuTrigger = menuTriggers.length > 0 ? menuTriggers[menuTriggers.length - 1] : null
if (menuTrigger !== null) menuTrigger.props.onClick()
const withMenu = runtime.mount(registered.get('main'), previewProps)
const detailButton = findButton(withMenu.tree, '详情')
if (detailButton !== null && typeof detailButton.props?.onClick === 'function') detailButton.props.onClick()
const third = runtime.mount(registered.get('main'), previewProps)

const render = (tree) => `<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>全局待办 · UI 预览</title>
<style>
  :root{
    --dsw-alias-bg-base:#0d1017; --dsw-alias-bg-layer-1:#151922; --dsw-alias-bg-layer-2:#1b2130;
    --dsw-alias-bg-overlay:#1b2130; --dsw-alias-border-l1:#262d3d; --dsw-alias-border-l2:#39425a;
    --dsw-alias-brand-primary:#6ea8ff; --dsw-alias-label-primary:#e7ebf3; --dsw-alias-label-secondary:#98a2b8;
    --dsw-alias-state-error-primary:#ff7b72; --dsw-alias-state-success-primary:#3ddc97;
    --dsw-alias-state-warn-primary:#ffcc66; --dsw-specific-sidebar-fill:#11151d;
  }
  *{box-sizing:border-box}
  body{margin:0;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);
    font:14px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif}
  .frame{max-width:920px;margin:0 auto;height:100vh;display:flex;flex-direction:column}
  .shellbar{display:flex;gap:8px;align-items:center;padding:10px 16px;color:var(--dsw-alias-label-secondary);
    font-size:12px;border-bottom:1px solid var(--dsw-alias-border-l1)}
  .shellbar b{color:var(--dsw-alias-label-primary);font-weight:600}
  .main{flex:1;min-height:0;overflow:auto}
${css}
</style></head>
<body><div class="frame">
  <div class="shellbar"><b>DSH</b><span>·</span><span>侧栏「待办」→ 主面板（预览用外壳，非真实宿主）</span></div>
  <div class="main">${toHtml(tree)}</div>
</div></body></html>
`

const panelHtml = render(second.tree)
const detailHtml = render(third.tree)
runtime.reset()
// Two passes, like the default render: the first runs the effects (which fetch), the
// second reuses the now-populated hook store — the harness has no re-render of its own.
const selectFirst = runtime.mount(registered.get('main'), { ...previewProps, initialSelectMode: true })
for (const effect of selectFirst.effects) effect()
await new Promise((resolve) => setTimeout(resolve, 20))
const selectTree = runtime.mount(registered.get('main'), { ...previewProps, initialSelectMode: true })
const selectHtml = render(selectTree.tree)
// The settings inspector, rendered the same way: the harness cannot click, so the panel
// is asked to start with it open.
runtime.reset()
const settingsFirst = runtime.mount(registered.get('main'), { ...previewProps, initialSettingsOpen: true })
for (const effect of settingsFirst.effects) effect()
await new Promise((resolve) => setTimeout(resolve, 20))
const settingsTree = runtime.mount(registered.get('main'), { ...previewProps, initialSettingsOpen: true })
const settingsHtml = render(settingsTree.tree)
// The four states that used to have no baseline at all: an empty list, a filter that
// matches nothing, the inbox, and a due reminder. Each mounts its own scenario and is
// photographed by tools/screenshot.mjs, so a regression shows up as a changed image.
const scenarioHtml = {}
for (const [name, props] of [
  ['empty', {}],
  ['filtered', {}],
  ['inbox', { initialFilter: 'inbox' }],
  ['review', { initialFilter: 'review' }],
  ['reminders', {}],
]) {
  scenario = name
  runtime.reset()
  const passOne = runtime.mount(registered.get('main'), { ...previewProps, ...props })
  for (const effect of passOne.effects) effect()
  await new Promise((resolve) => setTimeout(resolve, 20))
  const passTwo = runtime.mount(registered.get('main'), { ...previewProps, ...props })
  scenarioHtml[name] = render(passTwo.tree)
}
scenario = 'default'
// path.dirname, not a regex on '/': on Windows the regex matched nothing, so this created
// a directory literally named panel.html and the write below failed with EISDIR.
mkdirSync(path.dirname(OUT), { recursive: true })
writeFileSync(OUT, panelHtml)
writeFileSync(OUT.replace(/\.html?$/, '') + '-detail.html', detailHtml)
writeFileSync(OUT.replace(/\.html?$/, '') + '-select.html', selectHtml)
writeFileSync(OUT.replace(/\.html?$/, '') + '-settings.html', settingsHtml)
for (const [name, html] of Object.entries(scenarioHtml)) {
  writeFileSync(OUT.replace(/\.html?$/, '') + '-' + name + '.html', html)
}
console.log('written', OUT, 'and the detail variant; fetch calls:', requestedUrl.join(', '))

/**
 * Structural checks on the rendered panel.
 *
 * The client half has no unit-test seam — it is one classic script with no
 * exports — so the render itself is the only place these can be asserted. Run
 * with `--check` (which `npm run verify` does) to treat them as a test.
 *
 * @param {string} html
 * @returns {string[]} failures, empty when the render looks right
 */
function checkRenderedPanel(html, detail, select) {
  const failures = []
  const expect = (condition, message) => {
    if (condition !== true) failures.push(message)
  }

  // Every todo in the sample that came from the same conversation must be one
  // entry: the header line, and none of the rows it stands for.
  // The shell knows the conversation titles, so the merged group is named after
  // the conversation rather than after an id suffix.
  expect(html.includes('Docker 与知识库'), 'the merged conversation header is missing its title')
  expect(html.includes('2 条'), 'the merged header does not carry its count')
  // The group header carries the titles in its tooltip, which is fine — what
  // must not exist is a *row* for them.
  expect(!html.includes('gt-item-title">等交换机到货后重测内网吞吐'), 'a merged todo is still rendered as its own row')
  expect(!html.includes('gt-item-title">给 staging 迁移动手写一个回滚脚本'), 'a merged todo is still rendered as its own row')
  // Single-item conversations keep their row.
  expect(html.includes('把周报模板换成新的四段式'), 'a single-item conversation lost its row')
  // Levels are visible, and the switcher offers all three dimensions.
  expect(html.includes('data-level="high"'), 'no level badge was rendered')
  // The overdue sample is P0, and its conversation is collapsed — so the level has
  // to reach the group header, which is exactly what a careless fixture hid once.
  expect(html.includes('data-level="urgent"'), 'the P0 level badge is missing from the group header')
  // The live-session badge: the sample row is bound to a running conversation.
  expect(html.includes('gt-chip-ok'), 'the running-session badge lost its colour')
  expect(html.includes('会话在跑'), 'the running-session badge label is missing')
  expect(html.includes('紧急'), 'the urgent label is missing')
  // Progress notes and dead attachments are user-facing facts, so they are asserted
  // rather than assumed to render. The row shows the count; the detail — which only
  // exists for the open row — carries the trail.
  expect(html.includes('2 条进展'), 'the row does not show how many notes there are')
  expect(html.includes('文件不在了'), 'a missing attachment is not flagged on the row')
  expect(html.includes('is:overdue'), 'the search syntax hint is missing')
  expect(detail.includes('进展记录'), 'the notes section is missing from the detail')
  expect(detail.includes('已按四段式重写'), 'a note body is missing from the detail')
  // The Host's directory picker delegates to a Remote namespace that is not mounted in
  // every deployment, so a path field is the fallback rather than a dead error.
  expect(html.includes('>手动填<'), 'the manual directory fallback is missing')
  // Selection mode, rendered on purpose: the bar and the row markers must appear, and the
  // batch action must be offered for what the panel is showing.
  expect(select.includes('>全选<'), 'the select-all control is missing')
  expect(select.includes('已选 0 条'), 'the selection bar does not show a count')
  expect(select.includes('>一键分配<'), 'the batch action is missing from the selection bar')
  expect(select.includes('class="gt-pick"'), 'selection markers are missing in selection mode')
  {
    // Collapsed groups render no rows, so the invariant is about what *is* rendered.
    const rows = select.split('class="gt-item"').length - 1
    const picks = select.split('class="gt-pick"').length - 1
    expect(rows > 0 && picks === rows, `every rendered row needs a marker (rows=${rows}, picks=${picks})`)
  }
  // Multi-select is a mode beside the switch, and its marker must not appear unasked.
  expect(html.includes('>选择<'), 'the selection mode switch is missing')
  expect(!html.includes('class="gt-pick"'), 'selection markers must not show until the mode is on')
  // The automatic collect switch is Host state, so it must be visible in the panel —
  // and visibly *on* in this fixture.
  expect(/data-on="1"[^>]*>\s*自动获取/.test(html), 'the automatic collect switch is not shown as on')
  // The capture action belongs to a conversation, so it sits on that conversation's
  // group; the toolbar only keeps a fallback for a conversation that has no group.
  expect(html.includes('分组操作'), 'no group action menu on the conversation groups')
  // The exemption is a per-workspace setting reached from a conversation's group, so it has to
  // render there — and it is keyed on the directory the todos were *written* in, not on the
  // bound session, because the conversation may have been unloaded since and a live lookup
  // answers nothing for it. The fixture exempts the one group whose directory is known.
  expect(html.includes('gt-group-flag'), 'no exemption mark on a group whose directory is known')
  expect(!html.includes('从本对话抓取'), 'the toolbar still duplicates the per-conversation capture action')
  // Two facts the user asked for, asserted rather than trusted: archived conversations
  // are not offered, and the list is ordered by last use.
  expect(!html.includes('子代理（不应出现）'), 'a subagent child is offered as a conversation')
  expect(!html.includes('空白会话（不应出现）'), 'a blank session that is not the current one is offered')
  expect(html.includes('dsh-global-todo · 设计与实现'), 'the current blank session must still be offered')
  expect(!html.includes('已归档的老对话'), 'an archived conversation is offered (registry set)')
  expect(!html.includes('被归档的会话'), 'an archived conversation is offered (row flag)')
  const offered = [...html.matchAll(/<option value="(session-[^"]+)"[^>]*>([^<]*)</g)].map((match) => match[2])
  const expectedOrder = ['Docker 与知识库', 'dorm-network', 'dsh-global-todo · 设计与实现']
  expect(
    JSON.stringify(offered.slice(0, expectedOrder.length)) === JSON.stringify(expectedOrder),
    `the picker is not ordered by last use: ${JSON.stringify(offered.slice(0, expectedOrder.length))}`,
  )
  // The hand-off picker must offer real conversations, not only fallbacks.
  expect(html.includes('dsh-global-todo · 设计与实现'), 'the hand-off picker lost its conversation list')
  expect(html.includes('最近说过话'), 'the picker no longer marks the conversation the Host would pick')
  for (const label of ['对话', '时间', '级别']) {
    expect(html.includes(`>${label}</button>`), `the ${label} grouping button is missing`)
  }
  // The scroll contract: the panel clips and the list scrolls. A flex item defaults to
  // min-height:auto, which silently made the column grow past the slot so nothing scrolled
  // and the host hid the rest of the list. Assert the two declarations that prevent it.
  expect(/\.gt-root\s*\{[^}]*overflow:\s*hidden/.test(css), 'the panel no longer clips its own overflow')
  expect(/\.gt-inner\s*\{[^}]*min-height:\s*0/.test(css), 'the column can grow past the slot again (no min-height: 0)')
  expect(/\.gt-groups\s*\{[^}]*overflow:\s*auto/.test(css), 'the list is no longer the scroll owner')
  // The plan is visible in two places on purpose: progress without opening the row, and the
  // ticks themselves in the detail.
  expect(html.includes('步骤 2/4'), 'the row does not show plan progress')
  expect(html.includes('gt-step'), 'the detail does not render the steps')
  // Grouping must not smuggle raw colours in: theme tokens only.
  expect(/rgb\(|#[0-9a-fA-F]{3,6}\b/.test(html.replace(/<style>[\s\S]*?<\/style>/, '')) === false, 'a literal colour leaked into the markup')
  return failures
}

if (process.argv.includes('--check')) {
  const failures = checkRenderedPanel(panelHtml, detailHtml, selectHtml)
  // The four archived states are photographs, so nothing else would notice if one of them
  // quietly rendered a blank panel: assert the sentence that makes each state itself.
  for (const [name, marker] of [
    ['empty', '记第一条'],
    ['filtered', '清除筛选'],
    ['inbox', '确认后才进入清单'],
    ['review', '待确认'],
    ['reminders', '到点提醒'],
  ]) {
    const html = scenarioHtml[name] ?? ''
    if (!html.includes(marker)) failures.push(`${name} state lost its marker (${marker})`)
  }
  if (failures.length > 0) {
    console.error('panel render check failed:')
    for (const failure of failures) console.error(' -', failure)
    process.exit(1)
  }
  console.log('panel render: ok')
}

// The mounted panel polls while it is open; this tool is a one-shot render.
process.exit(0)
