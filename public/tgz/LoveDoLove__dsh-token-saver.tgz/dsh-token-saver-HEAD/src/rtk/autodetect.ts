/**
 * Automatic detector for identifying the appropriate RTK filter to apply.
 * Ported from dsh-our-free-model / open-sse/rtk autodetect under MIT license.
 */

import { DETECT_WINDOW, RTK_DIFF_MARKER } from './constants.js'
import type { RtkFilterFn } from './applyFilter.js'
import { isGrepHit } from './hitLine.js'
import { gitDiff } from './filters/gitDiff.js'
import { gitStatus } from './filters/gitStatus.js'
import { gitLog } from './filters/gitLog.js'
import { grep } from './filters/grep.js'
import { find } from './filters/find.js'
import { tree } from './filters/tree.js'
import { dedupLog } from './filters/dedupLog.js'
import { smartTruncate } from './filters/smartTruncate.js'
import { readNumbered, isNumberedOutput } from './filters/readNumbered.js'
import { searchList } from './filters/searchList.js'
import { buildOutput } from './filters/buildOutput.js'
import { table } from './filters/table.js'

/**
 * Porcelain v1 status codes: two columns, X (index) and Y (work tree).
 *
 * At least one column is always a real status letter — git never lists an
 * entry as `'  '`. That matters because a line indented by four or more
 * spaces has `line[2] === ' '` and `line.slice(0, 2) === '  '`, so a class
 * that admits a bare space classifies every indented code block, quoted
 * email, and nested YAML document as a git status. Requiring one status
 * letter is the guard that keeps ordinary text away from `gitStatus`.
 */
const PORCELAIN_XY_RE = /^[MADRCU?!][MADRCU?! ]$|^[ MADRCU?!][MADRCU?!]$/

export function isMostlyPorcelain(sampleLines: readonly string[]): boolean {
  if (sampleLines.length < 3) return false
  let porcelainCount = 0
  for (const line of sampleLines) {
    if (isPorcelainLine(line)) porcelainCount++
  }
  return porcelainCount / sampleLines.length >= 0.5
}

function isPorcelainLine(line: string): boolean {
  return line.length >= 3 && line[2] === ' ' && PORCELAIN_XY_RE.test(line.slice(0, 2))
}

/**
 * Is this first line a real `git status` branch header, or a markdown `##`
 * heading? A bare word (`## Usage`) is indistinguishable from an upstream-less
 * `## main`, so the ambiguous case only counts when porcelain entries follow.
 * Firing wrongly destroys a document; not firing costs a few uncompacted bytes
 * on a clean tree.
 */
function isGitStatusHeader(lines: readonly string[]): boolean {
  const header = lines.find((l) => l.startsWith('## '))
  if (!header) return false
  if (header.includes('...')) return true
  if (/\(no branch\)|No commits yet/.test(header)) return true
  return lines.some(isPorcelainLine)
}

const TABLE_HEADER =
  /^\s*(CONTAINER|POD|NAME|USER|PID|COMMAND|STATUS|IMAGE|UPTIME|CPU|MEM|SIZE|TOTAL|ALLOCATION|VERSION|Filesystem|Mount|STATE|ADDRESS|LISTENING|PR|PKG|NODE)\b/i

/**
 * Columnar CLI output: a keyword header line followed by multi-field rows.
 * Kept intentionally conservative; on any doubt the filter must not fire.
 */
export function isTableOutput(sampleLines: readonly string[]): boolean {
  if (sampleLines.length < 5) return false
  if (!TABLE_HEADER.test(sampleLines[0]!)) return false
  const data = sampleLines.slice(1)
  if (data.length < 3) return false
  let multiField = 0
  for (const l of data.slice(0, 10)) {
    if (l.trim().split(/\s+/).length >= 2) multiField++
  }
  return multiField >= 2
}

export function autoDetectFilter(text: string): RtkFilterFn | null {
  const window = text.slice(0, DETECT_WINDOW)
  const lines = window.split('\n').filter((l) => l.trim().length > 0)
  if (lines.length === 0) return null

  // Idempotency guard: prevent duplicate compaction on already-compacted outputs.
  // The pipeline compacts twice by design — once in tools/post-execute, again
  // over the whole wire payload in llm/stream — so every filter's own output
  // must be recognisable here, or the second pass treats a compacted blob as
  // fresh input and truncates the remains.
  if (
    text.includes(RTK_DIFF_MARKER) ||
    text.includes('to save tokens; head and tail preserved') ||
    text.includes('[repeated ') ||
    text.includes(' rows omitted')
  ) {
    return null
  }

  // 1. git log (most specific git headers)
  if (/^commit [a-f0-9]{7,40}/m.test(window)) {
    return gitLog
  }

  // 2. git diff
  if (/^diff --git /m.test(window)) {
    return gitDiff
  }

  // 3. git status (standard prose/header)
  if (/^On branch /m.test(window) || isGitStatusHeader(lines)) {
    return gitStatus
  }

  // 4. build output (check before porcelain, since cargo "Compiling foo" could false-match)
  if (
    /error\[E\d+\]/i.test(window) ||
    /TS\d{4}:/i.test(window) ||
    /SyntaxError:/i.test(window) ||
    /npm ERR!/i.test(window) ||
    /\bCompiling\s+\S+\s+v\d+/i.test(window)
  ) {
    return buildOutput
  }

  // 4.5. table-like CLI output (docker ps, kubectl get, ps aux, df -h, ls -l).
  // Checked before the porcelain rule: data rows of tables ('abcdef1234 nginx ...')
  // otherwise satisfy the porcelain shape test and get mangled by gitStatus.
  if (isTableOutput(lines)) {
    return table
  }

  // 5. porcelain git status
  if (isMostlyPorcelain(lines)) {
    return gitStatus
  }

  // 6. grep/ripgrep hit lines (file:line:content). Shares the parser's own
  // predicate, so detection can never select a filter that then finds nothing
  // to group — notably stack frames, which only look like hits.
  let grepHits = 0
  for (const l of lines.slice(0, 20)) {
    if (isGrepHit(l)) grepHits++
  }
  if (grepHits >= 2) {
    return grep
  }

  // 7. tree format
  if (/[├└]──/m.test(window) || /│\s+/m.test(window)) {
    return tree
  }

  // 8. find / search list (paths)
  let pathLike = 0
  for (const l of lines.slice(0, 20)) {
    if (l.startsWith('./') || (l.includes('/') && !l.includes(' ') && l.length < 200)) {
      pathLike++
    }
  }
  if (pathLike >= 3) {
    return lines.length > 50 ? find : searchList
  }

  // 9. numbered code reading
  if (isNumberedOutput(lines)) {
    return readNumbered
  }

  // 10. repetitive log output
  let repeats = 0
  for (let i = 1; i < lines.length; i++) {
    if (lines[i] === lines[i - 1]) repeats++
  }
  if (repeats >= 3) {
    return dedupLog
  }

  // 11. generic smart truncate fallback for large text blobs
  if (text.split('\n').length >= 50) {
    return smartTruncate
  }

  return null
}
