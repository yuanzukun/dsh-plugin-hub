/**
 * Cumulative RTK savings telemetry, persisted separately from user settings.
 *
 * The in-memory `RtkStats` accumulator is per-process and per-session; this
 * store keeps the historical totals in ~/.dsh/token-saver/stats.json so the Web
 * dashboard still reports savings after a host restart.
 *
 * Callers hand in per-invocation stats (the shared accumulator is never
 * recorded directly), so each compaction is counted exactly once. A pass that
 * compresses nothing records nothing. `calls` counts invocations that produced
 * at least one compacted block and `blocks` counts the blocks themselves, so one
 * request compacting three blocks advances `calls` by one and `blocks` by three.
 * `promptCalls` is the separate prompt-shaping signal. Every read and write is
 * fail-open: broken telemetry must never affect compression behaviour or throw
 * into a request path.
 */

import fs from 'node:fs'
import path from 'node:path'
import { resolveDshHome, type TotalSavings } from './settings.js'
import type { RtkStats } from './rtk/index.js'

function toCounter(value: unknown): number {
  const n = Number(value)
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : 0
}

export function emptyTotals(): TotalSavings {
  return {
    bytesBefore: 0,
    bytesAfter: 0,
    saved: 0,
    calls: 0,
    blocks: 0,
    promptCalls: 0,
  }
}

export function resolveStatsPath(): string {
  return path.join(resolveDshHome(), 'token-saver', 'stats.json')
}

export class StatsStore {
  private readonly filePath: string
  private totals: TotalSavings

  constructor(customPath?: string) {
    this.filePath = customPath ?? resolveStatsPath()
    this.totals = this.load()
  }

  getFilePath(): string {
    return this.filePath
  }

  get(): TotalSavings {
    return { ...this.totals }
  }

  /**
   * Fold one invocation's stats into the cumulative totals.
   *
   * `blocks` counts compressed text blocks while `calls` counts the
   * invocations that produced at least one of them: one request compacting
   * three blocks advances `calls` by one and `blocks` by three. An
   * invocation without a hit records nothing and never touches the file.
   *
   * `promptInjected` is the separate prompt-shaping signal: it advances
   * `promptCalls` and is recorded even when the pass compressed no bytes,
   * because a shaped prompt is a real injection that saves nothing here.
   */
  record(stats: RtkStats | null | undefined, promptInjected = false): TotalSavings {
    try {
      const blocks = Array.isArray(stats?.hits) ? stats.hits.length : 0
      if (blocks <= 0 && !promptInjected) return this.get()
      this.totals = {
        bytesBefore: this.totals.bytesBefore + toCounter(stats?.bytesBefore),
        bytesAfter: this.totals.bytesAfter + toCounter(stats?.bytesAfter),
        saved: this.totals.saved + toCounter(stats?.saved),
        calls: this.totals.calls + (blocks > 0 ? 1 : 0),
        blocks: this.totals.blocks + blocks,
        promptCalls: this.totals.promptCalls + (promptInjected ? 1 : 0),
      }
      this.save()
    } catch {
      // Fail open: telemetry must never break a request path.
    }
    return this.get()
  }

  private load(): TotalSavings {
    try {
      if (!fs.existsSync(this.filePath)) return emptyTotals()
      const parsed = JSON.parse(fs.readFileSync(this.filePath, 'utf8')) as Record<string, unknown>
      if (parsed == null || typeof parsed !== 'object') return emptyTotals()
      return {
        bytesBefore: toCounter(parsed.bytesBefore),
        bytesAfter: toCounter(parsed.bytesAfter),
        saved: toCounter(parsed.saved),
        calls: toCounter(parsed.calls),
        blocks: toCounter(parsed.blocks),
        promptCalls: toCounter(parsed.promptCalls),
      }
    } catch {
      // Fail open on read/parse failure: start from zero instead of crashing.
      return emptyTotals()
    }
  }

  private save(): void {
    try {
      const dir = path.dirname(this.filePath)
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true })
      }
      fs.writeFileSync(this.filePath, JSON.stringify(this.totals, null, 2), 'utf8')
    } catch {
      // Fail open on write failure; in-memory totals stay authoritative.
    }
  }
}
