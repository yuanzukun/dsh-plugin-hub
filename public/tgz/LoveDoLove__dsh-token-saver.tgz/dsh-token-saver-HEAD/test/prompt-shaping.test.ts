import { describe, expect, it, vi } from 'vitest'
import {
  cavemanPrompt,
  ponytailPrompt,
  activePrompts,
  CAVEMAN_LEVELS,
  PONYTAIL_LEVELS,
  injectIntoSystemPrompt,
  stripPromptShaping,
  hasAnyPromptShaping,
  wrapPromptSegment,
  DSH_INJECT_MARKER,
  DSH_MARKER_END,
  OFM_INJECT_MARKER,
  OFM_MARKER_END,
  createAssembleInjector,
  SHAPING_SECTION_NAME,
} from '../src/prompt-shaping'

describe('Prompt Shaping - Caveman & Ponytail', () => {
  it('returns valid prompt string for all caveman levels', () => {
    for (const lvl of CAVEMAN_LEVELS) {
      if (lvl === 'off') {
        expect(cavemanPrompt(lvl)).toBeNull()
      } else {
        const text = cavemanPrompt(lvl)
        expect(typeof text).toBe('string')
        expect(text!.length).toBeGreaterThan(50)
      }
    }
  })

  it('returns valid prompt string for all ponytail levels', () => {
    for (const lvl of PONYTAIL_LEVELS) {
      if (lvl === 'off') {
        expect(ponytailPrompt(lvl)).toBeNull()
      } else {
        const text = ponytailPrompt(lvl)
        expect(typeof text).toBe('string')
        expect(text!.length).toBeGreaterThan(50)
        expect(text).toContain('Never simplify away: input validation at trust boundaries')
      }
    }
  })

  it('handles invalid or off levels gracefully', () => {
    expect(cavemanPrompt('off')).toBeNull()
    expect(cavemanPrompt('unknown' as never)).toBeNull()
    expect(ponytailPrompt('off')).toBeNull()
    expect(ponytailPrompt('invalid' as never)).toBeNull()
  })

  it('assembles activePrompts in canonical order (caveman then ponytail)', () => {
    const both = activePrompts({ caveman: 'full', ponytail: 'lite' })
    expect(both.length).toBe(2)
    expect(both[0]!.id).toBe('caveman')
    expect(both[1]!.id).toBe('ponytail')

    const onlyCaveman = activePrompts({ caveman: 'ultra', ponytail: 'off' })
    expect(onlyCaveman.length).toBe(1)
    expect(onlyCaveman[0]!.id).toBe('caveman')

    const onlyPonytail = activePrompts({ caveman: 'off', ponytail: 'full' })
    expect(onlyPonytail.length).toBe(1)
    expect(onlyPonytail[0]!.id).toBe('ponytail')

    const none = activePrompts({ caveman: 'off', ponytail: 'off' })
    expect(none.length).toBe(0)
  })

  it('keeps the negation, number and comment-protection rail at every caveman level', () => {
    for (const lvl of CAVEMAN_LEVELS) {
      if (lvl === 'off') continue
      const text = cavemanPrompt(lvl)!
      // The upstream floors: never drop negation, numbers stay exact,
      // existing comments are payload, diffs show changed lines only.
      expect(text).toContain('Never drop or weaken negation')
      expect(text).toContain('Numbers and units exact')
      expect(text).toContain('Existing comments in files you edit are payload')
      expect(text).toContain('changed lines plus 1-2 lines of context')
      expect(text).toContain('Anything persisted outside chat')
      expect(text).toContain('A sentence with two readings')
      expect(text).toContain('A status line or confirmation the harness asks for')
      expect(text).toContain('One idea per sentence, 20 words max')
      expect(text).toContain('Tool runs: no text between routine calls')
    }
  })

  it('cuts the announcing opener and the recapping closer at every caveman level', () => {
    for (const lvl of CAVEMAN_LEVELS) {
      if (lvl === 'off') continue
      const text = cavemanPrompt(lvl)!
      expect(text).toContain('No opening line announcing what you are about to do')
      expect(text).toContain('no closing line recapping it or offering further help')
    }
  })

  it('keeps the scope and root-cause rail at every ponytail level', () => {
    for (const lvl of PONYTAIL_LEVELS) {
      if (lvl === 'off') continue
      const text = ponytailPrompt(lvl)!
      expect(text).toContain('callers, tests, fixtures, config, exports')
      expect(text).toContain('grep every caller of the function you touch')
      expect(text).toContain('fix the root cause once in the shared code')
      expect(text).toContain('keeps its error handling and validation')
      expect(text).toContain('Keep the structure the codebase already has')
      expect(text).toContain('shortest working diff wins, once you know everything it must touch')
    }
  })

  it('keeps the already-in-this-codebase rung in the ponytail ladder', () => {
    for (const lvl of PONYTAIL_LEVELS) {
      if (lvl === 'off') continue
      expect(ponytailPrompt(lvl)).toContain('Already in this codebase')
    }
  })
})

describe('Prompt Shaping - System Prompt Injection & Deduplication', () => {
  it('injects into empty or undefined system prompt', () => {
    const res = injectIntoSystemPrompt(undefined, 'Concise instruction')
    expect(res.injected).toBe(true)
    expect(res.reason).toBe('created')
    expect(res.text).toContain(DSH_INJECT_MARKER)
    expect(res.text).toContain('Concise instruction')
    expect(res.text).toContain(DSH_MARKER_END)
  })

  it('appends to existing system prompt with separator', () => {
    const base = 'You are a helpful coding assistant.'
    const res = injectIntoSystemPrompt(base, 'Concise instruction')
    expect(res.injected).toBe(true)
    expect(res.reason).toBe('appended')
    expect(res.text.startsWith(base)).toBe(true)
    expect(res.text).toContain(DSH_INJECT_MARKER)
  })

  it('prevents duplicate injection if DSH marker already exists', () => {
    const initial = injectIntoSystemPrompt('Base prompt', 'Instruction 1').text
    const second = injectIntoSystemPrompt(initial, 'Instruction 2')
    expect(second.injected).toBe(false)
    expect(second.reason).toBe('already-injected')
    expect(second.text).toBe(initial)
  })

  it('prevents duplicate injection if Our Free Model marker already exists', () => {
    const ofmInjected = `Base prompt\n\n${OFM_INJECT_MARKER}\nOFM rules\n${OFM_MARKER_END}`
    expect(hasAnyPromptShaping(ofmInjected)).toBe(true)
    const res = injectIntoSystemPrompt(ofmInjected, 'DSH rules')
    expect(res.injected).toBe(false)
    expect(res.reason).toBe('already-injected')
    expect(res.text).toBe(ofmInjected)
  })

  it('strips both DSH and OFM markers cleanly', () => {
    const textWithBoth = [
      'Base prompt',
      wrapPromptSegment('DSH segment'),
      `${OFM_INJECT_MARKER}\nOFM segment\n${OFM_MARKER_END}`,
      'Ending note',
    ].join('\n\n')

    const stripped = stripPromptShaping(textWithBoth)
    expect(stripped).toContain('Base prompt')
    expect(stripped).toContain('Ending note')
    expect(stripped).not.toContain('DSH segment')
    expect(stripped).not.toContain('OFM segment')
    expect(stripped).not.toContain(DSH_INJECT_MARKER)
    expect(stripped).not.toContain(OFM_INJECT_MARKER)
  })
})

describe('Prompt Shaping - DSH system-prompt/assemble waterfall', () => {
  function assemblyWith(text: string) {
    return {
      sections: [{ name: 'base', text }],
      contexts: [],
      variables: {},
    }
  }

  it('adds a shaping section to the returned assembly', async () => {
    const injector = createAssembleInjector(() => 'Caveman rules')
    const next = vi.fn(async () => assemblyWith('Base system prompt.'))

    const result = await injector(assemblyWith('Base system prompt.'), {}, next)

    expect(next).toHaveBeenCalled()
    expect(result.sections).toHaveLength(2)
    const shaping = result.sections[1]!
    expect(shaping.name).toBe(SHAPING_SECTION_NAME)
    expect(shaping.text).toContain(DSH_INJECT_MARKER)
    expect(shaping.text).toContain('Caveman rules')
    // The shaping text is literal, never a DSH `{{variable}}` template.
    expect(shaping.interpolate).toBe(false)
  })

  it('does not inject twice when the prompt already carries the marker', async () => {
    const injector = createAssembleInjector(() => 'Caveman rules')
    const existing = assemblyWith(`Base\n\n${wrapPromptSegment('Already there')}`)

    const result = await injector(existing, {}, async () => existing)

    expect(result.sections).toHaveLength(1)
  })

  it('leaves the assembly untouched when no prompt is active', async () => {
    const injector = createAssembleInjector(() => '')
    const base = assemblyWith('Base system prompt.')

    const result = await injector(base, {}, async () => base)

    expect(result.sections).toHaveLength(1)
    expect(result.sections[0]!.text).toBe('Base system prompt.')
  })

  it('lets a downstream failure surface unchanged', async () => {
    const injector = createAssembleInjector(() => 'Caveman rules')

    await expect(
      injector(assemblyWith('Base'), {}, async () => {
        throw new Error('downstream boom')
      }),
    ).rejects.toThrow('downstream boom')
  })

  it('fails open when the prompt text cannot be resolved', async () => {
    const injector = createAssembleInjector(() => {
      throw new Error('config boom')
    })
    const base = assemblyWith('Base system prompt.')

    const result = await injector(base, {}, async () => base)

    expect(result.sections).toHaveLength(1)
  })
})
