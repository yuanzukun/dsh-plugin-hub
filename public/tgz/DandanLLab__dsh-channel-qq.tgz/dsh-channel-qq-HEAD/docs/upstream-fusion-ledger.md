# 上游二改（Aegink/dsh-channel-qq）融合对账

> 本仓库是 DandanLLab 原版。Aegink 仓库在其基础上做了大重构（分层架构、92 工具合并
> 18 动作组、管理后台 27 页）。感谢这位二改作者的优质工作——本文件逐项对账：
> 我们吸收什么、不吸收什么、为什么。**吸收的全部是"软规则"（数据/策略/文档层）；
> 不吸收"硬规则"（权限门/访问门控等改变宿主行为的强制层），因为那属于部署者的
> 选择，不是插件的义务。**

## 一、已吸收（0.2.0 起随本仓库）

| 能力 | 来源 | 落点 |
|---|---|---|
| 事实蒸馏思想：注入用短事实、chunk 块只给深召回 | fork `docs/memory.md` 实测结论（chunk 挤进 600 字注入预算 recall 反而归零） | life-engine 组件的注入段保持短事实，`kb_deep_search` 负责原文块 |
| 检索评测基线：60 题基准+退化告警的思路 | fork `memory.eval` job | 记入 `docs/memory-recipe.md` 待做清单（README 路线图） |
| emoji/image 分型：语义搜索时截图类沉底 | fork stickers type 字段 | 我们的表情库 `type` 字段 + docs/emoji-pipeline.md 第五节 |
| 学习闭环候选制：自动产物一律"候选→审核"，不自动改行为 | fork `learning-jobs.ts` 纪律 | life-engine 组件的反思/巩固产物全部走 events 注入线（agent 自己动笔），插件从不代笔——与候选制同构 |
| "原文回指"检索纪律 | fork `qq_memory_search` 带 文件+行号 | `kb_deep_search` 已带 [窗口/日期/时间/出处文件] |

## 二、明确不吸收（硬规则类）

| 能力 | 为什么不收 |
|---|---|
| 审批网关 L0–L3 + 一次性令牌 | 改变宿主权限行为的强制层。dsh 本体已有 permission presets；部署者要硬门控可自己加 |
| 访问门控（陌生人私聊只回"待主人批准"） | 同上。我们保留 `requireMention` / talkValue 这类软触发，不做硬拦 |
| 管理后台 27 页 | 形态不同：本仓库定位是"渠道+生活"插件，不带 GUI 运维面 |
| tools.v2 的 18 动作组强合并 | 工具命名是模型可见面，强合并破坏本仓库现有工具兼容性；可作为可选 preset 未来再议 |

## 三、已修复、无需再取 fork 的

- 表情包入库三闸 + 发送严格后缀 + MISS 三级兜底（我们更强，见 `docs/emoji-pipeline.md`）
- 点歌卡吞卡对账降语音、URL 保护分段、正在输入、六维情感自主上报
- qzone 三件套、qq_swarm、游历群白名单（fork 无对应物）

## 四、fork 的两条实测教训（比代码更值钱）

1. **自动注入的预算是零和的**：600 字预算塞进一块 400 字的 chunk，整回合只剩一条证据，
   recall 实测归零。注入层永远用短事实；原文块只走深召回工具。
2. **语料形状决定召回上限**：日记原文句子做语料，关键词 recall 0.04、向量 0.14——
   药方是事实蒸馏（更短的"一句话事实"），不是更大的块。

## 五、dsh-meme 组件并入（v0.2.1）

[yyh-001/dsh-meme](https://github.com/yyh-001/dsh-meme)（MIT, © Selfloom contributors）
以 vendor 方式整体并入 `src/meme/`（index/memes/anim/panel.html + 内置图库，LICENSE 保留）：

- **唯一代码改动** = QQ 发送通道适配：上游依赖独立的 dsh-companion 插件提供
  `companionQq.sendImage`；组件化后由本插件包装器注入 `ctx.qqChannel`，
  直接桥接自己的 OneBot 客户端——群白名单/私聊 admins 窗口纪律、魔数后缀校验
  全部复用本插件现有管线。独立安装的 dsh-meme 自动回落 companionQq，双向兼容。
- 宿主 API 逐项核实（dsh 0.2.1-alpha.5）：tools.register / webServer.register
  (exact+prefix) / webServer.tapIndex / attachments.readImage|saveImage /
  agentDefaultModel.currentSelection / system-prompt/assemble 全部在役。
- 内置图库（dafeiyu-001 24 张）随包分发；`config.memeEngine` 开关。
