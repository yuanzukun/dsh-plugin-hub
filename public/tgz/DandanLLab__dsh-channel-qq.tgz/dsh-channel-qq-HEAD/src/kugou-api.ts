/** KuGou music via self-hosted KuGouMusicApi server (port 4000).
 *
 * Ported from astrbot_plugin_kugoumusic (analyzed):
 * - server: github.com/MakcRe/KuGouMusicApi, started with PORT=4000
 * - /register/dev once to get dfid (device id), persisted
 * - /search (needs login token after kugou banned anonymous search: error_code 152)
 * - /song/url?hash=..&quality=.. -> { url|backupUrl[], status(1 ok/2 quality degrade), extName }
 * - QR login: /login/qr/key -> /login/qr/create -> /login/qr/check (token+userid)
 * - Cookie storage: <dshHome>/channel-qq/kugou-cookie.txt (token=..;userid=..)
 */

import { promises as fs } from 'node:fs'
import * as os from 'node:os'

const HOME = process.env.DSH_HOME ?? `${os.homedir()}/.dsh`
const BASE = process.env.KUGOU_API_BASE ?? 'http://127.0.0.1:4000'
const COOKIE_FILE = `${HOME}/channel-qq/kugou-cookie.txt`
const DFID_FILE = `${HOME}/channel-qq/kugou-dfid.txt`

export async function loadCookie(): Promise<string> {
  try {
    return (await fs.readFile(COOKIE_FILE, 'utf8')).trim()
  } catch {
    return ''
  }
}

export async function saveCookie(cookie: string): Promise<void> {
  await fs.writeFile(COOKIE_FILE, cookie.trim(), 'utf8')
}

async function ensureDfid(): Promise<string> {
  try {
    const existing = (await fs.readFile(DFID_FILE, 'utf8')).trim()
    if (existing !== '') return existing
  } catch { /* first run */ }
  const res = await fetch(`${BASE}/register/dev`)
  const body = (await res.json()) as { data?: { dfid?: string } }
  const dfid = body.data?.dfid ?? ''
  if (dfid === '') throw new Error('register/dev 拿不到 dfid')
  await fs.writeFile(DFID_FILE, dfid, 'utf8')
  return dfid
}

async function kgGet(path: string, params: Record<string, string>, anonFallback = false): Promise<any> {
  const dfid = await ensureDfid()
  const cookie = await loadCookie()
  const search = new URLSearchParams({ ...params, dfid })
  // kugou banned anonymous search (error_code 152): needs logged cookie; anonymous
  // placeholder only helps /search per kugoumusic plugin notes.
  if (cookie === '') {
    if (anonFallback) search.set('token', 'kg')
  } else {
    search.set('cookie', cookie)
  }
  const res = await fetch(`${BASE}${path}?${search.toString()}`)
  const body = (await res.json()) as any
  return body
}

export interface KugouSearchHit {
  hash: string
  name: string
  singers: string
  durationSec?: number
}

export async function searchSongs(keyword: string, limit = 5): Promise<KugouSearchHit[]> {
  const body = await kgGet('/search', { keywords: keyword, type: 'song', page: '1', pagesize: String(Math.min(limit, 10)) }, true)
  if (body.status !== 1) {
    const code = body.error_code
    throw new Error(code === 152 ? '酷狗搜索需要登录：先 qq_kugou_login 扫码' : `酷狗搜索失败: ${body.error_msg ?? body.msg ?? code}`)
  }
  const lists = body.data?.lists ?? []
  return lists.map((item: any) => ({
    hash: item.hash ?? item.FileHash ?? '',
    name: item.name ?? item.SongName ?? '',
    singers: (item.singers ?? []).map((s: any) => s.name ?? s).join('/'),
    durationSec: item.duration !== undefined ? Math.round(item.duration / 1000) : undefined,
  }))
}

export interface KugouUrlResult {
  url: string
  status: number
  trial: boolean
  extName: string
}

/** Resolve playback URL for a hash. quality: auto|viper_tape|viper_clear|super|high|flac|320|128 */
export async function songUrl(hash: string, quality = 'auto'): Promise<KugouUrlResult> {
  const body = await kgGet('/song/url', { hash, quality })
  const pick = (item: any): string => {
    for (const key of ['url', 'backupUrl']) {
      const v = item[key]
      if (Array.isArray(v)) {
        const first = v.find((u: string) => Boolean(u))
        if (first !== undefined) return String(first)
      } else if (v) return String(v)
    }
    return ''
  }
  const url = pick(body)
  if (url === '') throw new Error(`酷狗拿不到链接 (status=${body.status} error_code=${body.error_code})`)
  const trial = url.toLowerCase().includes('p_0_') && !url.toLowerCase().includes('full')
  return { url, status: body.status ?? 0, trial, extName: body.extName ?? 'mp3' }
}

/** QR login step 1: key + QR image URL. */
export async function qrLoginStart(): Promise<{ key: string; qrUrl: string }> {
  const keyBody = await kgGet('/login/qr/key', { timestamp: String(Date.now()) })
  const key = keyBody.data?.qrcode ?? ''
  if (key === '') throw new Error('拿不到酷狗登录 key')
  const create = await kgGet('/login/qr/create', { key, qrimg: 'true' })
  const qrUrl = create.data?.url ?? `https://activity.kugou.com/static/login/index.html?key=${encodeURIComponent(key)}`
  return { key, qrUrl }
}

/** QR login step 2: poll. Returns cookie on success. */
export async function qrLoginPoll(key: string): Promise<{ status: string; cookie: string; nickname?: string }> {
  const body = await kgGet('/login/qr/check', { key, timestamp: String(Date.now()) })
  const data = body.data ?? {}
  const status = String(data.status ?? body.status ?? '')
  if (status === '1' || body.status === 1) {
    const token = data.token ?? ''
    const userid = data.userid ?? ''
    if (token !== '') {
      const cookie = `token=${token};userid=${userid}`
      await saveCookie(cookie)
      return { status: 'ok', cookie, nickname: data.nickname }
    }
  }
  return { status, cookie: '' }
}
