/** Meme Engine component: vendored from yyh-001/dsh-meme v0.1.61 (MIT, © 2026 Selfloom contributors).
 *
 * Ships as sibling plain-JS modules (`src/meme/index.js|memes.js|anim.js|panel.html`
 * + `bundled-pack/`), copied verbatim into `lib/meme/` at build time. The
 * component keeps dsh-meme's own host contract: `send_meme` / `learn_meme`
 * tools, `/dsh-memes` image route, `/dsh-memes-api` + `/memes-panel` admin,
 * companion-prompt injection via `system-prompt/assemble`.
 *
 * Component adaptation (the only code change vs upstream): the QQ send
 * channel no longer requires the separate dsh-companion plugin — this
 * wrapper injects `ctx.qqChannel = { sendImage }` backed by channel-qq's
 * own OutboundQueue (group/DM window whitelist + strict-suffix pipeline
 * shared with qq_send_emoji). Independent dsh-meme installs keep working
 * (the adapter falls back to `companionQq`).
 */

import type { Context } from '@deepseek-ai/cordis'
import type { QQChannelConfig } from '../config.js'
import type { OneBotClient } from '../onebot.js'
import type { OutboundQueue } from '../outbound.js'
import { readFile, writeFile, rm } from 'node:fs/promises'

export interface MemeEngineComponentConfig {
  /** Master switch; default true. */
  enabled: boolean
  /** Optional meme pack root override (defaults to the bundled pack + ~/.dsh/meme-packs scan). */
  memeRoot: string | null
  /** Admin panel + image routes (needs the host webServer service). */
  webRoutes: boolean
}

interface SendImageOptions {
  /** Send target: group id or QQ number. Omit = primary group. */
  target?: number
  isGroup?: boolean
  caption?: string
}

/** Apply the meme engine component. Returns a disposer. */
export async function applyMemeEngine(
  ctx: Context,
  config: QQChannelConfig,
  client: OneBotClient,
  out: OutboundQueue,
  log: (line: string) => void,
): Promise<() => void> {
  const meme = (config.memeEngine ?? { enabled: true, memeRoot: null, webRoutes: true }) as MemeEngineComponentConfig
  if (meme.enabled === false) {
    log('meme-engine: disabled by config')
    return () => {}
  }

  // Send adapter: route through channel-qq's own OneBot client with the same
  // window whitelist semantics as qq_send_text (group → primaryGroup/extraGroups,
  // DM → admins). Byte-magic/suffix correction stays upstream in qq_send_emoji's
  // pipeline; here we send by base64 like the emoji marker path does.
  const sendImage = async (filePath: string, caption?: string, opts: SendImageOptions = {}): Promise<void> => {
    const buf = await readFile(filePath)
    const isPng = buf.length > 8 && buf[0] === 0x89 && buf[1] === 0x50
    const isGif = buf.length > 6 && buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46
    const isJpg = buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8
    const realExt = isPng ? '.png' : isGif ? '.gif' : isJpg ? '.jpg' : null
    let sendPath = filePath
    if (realExt !== null && !filePath.toLowerCase().endsWith(realExt)) {
      const tmpPath = filePath.replace(/\.[^.]+$/, '') + '_meme' + realExt
      await writeFile(tmpPath, buf)
      sendPath = tmpPath
      setTimeout(() => { rm(tmpPath).catch(() => {}) }, 30_000)
    }
    const b64 = (await readFile(sendPath)).toString('base64')
    const segs: Array<Record<string, unknown>> = [{ type: 'image', data: { file: `base64://${b64}` } }]
    if (caption) segs.push({ type: 'text', data: { text: caption.slice(0, 200) } })
    const groupsAllowed = [config.primaryGroup, ...(config.extraGroups ?? [])].filter((v): v is number => v !== null)
    const target = Number(opts.target ?? config.primaryGroup ?? config.admins[0] ?? 0)
    const isGroup = opts.isGroup ?? groupsAllowed.includes(target)
    if (isGroup && !groupsAllowed.includes(target)) throw new Error(`target ${target} 不在群白名单`)
    if (!isGroup && !config.admins.includes(target)) throw new Error(`target ${target} 不在 admins`)
    await client.call(isGroup ? 'send_group_msg' : 'send_private_msg',
      isGroup ? { group_id: target, message: segs } : { user_id: target, message: segs })
  }

  // Adapter handoff via global side-channel — the cordis Context proxy rejects
  // setting undeclared properties ("without provide"); globalThis always works.
  ;(globalThis as unknown as Record<string, unknown>).__channelQqMemeBridge = {
    sendImage: (path: string, caption?: string, opts?: SendImageOptions) => {
      void sendImage(path, caption, opts).catch((e: unknown) => log(`meme-engine send failed: ${e instanceof Error ? e.message : String(e).slice(0, 120)}`))
    },
  }

  const modUrl = new URL('./meme-engine.js', import.meta.url).href
  // 后台挂载：meme 组件内有市场目录网络请求（jsdelivr 多级回退），可能长时间挂起——
  // 绝不让它阻塞 Service.init（历史事故：apply 卡在 catalog fetch，client.start()
  // 没跑，8082 不监听，NapCat 全链路掉线）。
  void (async () => {
    try {
      const { apply } = (await import(modUrl)) as { apply: (host: unknown, config: unknown) => void }
      apply(ctx, { memeRoot: meme.memeRoot ?? undefined })
      log('meme-engine: component attached (send_meme/learn_meme, admin panel, bundled pack)')
    } catch (e) {
      log(`meme-engine: attach failed — ${e instanceof Error ? e.message : String(e).slice(0, 160)}`)
    }
  })()
  log('meme-engine: attach dispatched (background)')

  // Send failures surface through the outbound queue logs; the component has
  // no disposer contract beyond ctx.effect routes (host-managed), so this is
  // a no-op kept for symmetry with applyLifeEngine.
  return () => {}
}
