// Probe NapCat: is the QQ session alive and receiving? Check group info + member list.
import WebSocket from 'ws'

const ws = new WebSocket('ws://127.0.0.1:3001', { headers: { Authorization: 'Bearer jw_VfZZsK22UT1Oe' } })
let seq = 0
const pending = new Map()

function call(action, params) {
  return new Promise((resolve) => {
    const echo = `p-${++seq}`
    pending.set(echo, resolve)
    ws.send(JSON.stringify({ action, params, echo }))
    setTimeout(() => { if (pending.has(echo)) { pending.delete(echo); resolve({ status: 'timeout' }) } }, 10000)
  })
}

ws.on('message', (data) => {
  try {
    const j = JSON.parse(data.toString())
    if (j.echo && pending.has(j.echo)) { pending.get(j.echo)(j); pending.delete(j.echo) }
  } catch {}
})

ws.on('open', async () => {
  const login = await call('get_login_info', {})
  console.log('login:', login.status, JSON.stringify(login.data ?? login.msg ?? '').slice(0, 120))

  const gi = await call('get_group_info', { group_id: 10002 })
  console.log('group 10002:', gi.status, gi.status === 'ok' ? `name=${gi.data?.group_name} members=${gi.data?.member_count}` : gi.msg)

  const gl = await call('get_group_list', {})
  console.log('group list:', gl.status, gl.status === 'ok' ? `${(gl.data ?? []).length} groups` : gl.msg)

  const si = await call('get_status', {})
  console.log('status:', si.status, JSON.stringify(si.data ?? {}).slice(0, 200))

  process.exit(0)
})
ws.on('error', (e) => { console.log('ws error:', e.message); process.exit(1) })
setTimeout(() => process.exit(0), 15000)
