# dsh-channel-qq 增强模块说明

2026-09-15 从 11 个 AstrBot 插件（angel_heart / angel_memory / angel_smile / angel_eye /
stealer / splitter / qq_group_daily_analysis / meme_manager / private_companion /
arena_image / poke）里吸收思路，落到 dsh 原生实现。

## 新增能力总览

| 模块 | 文件 | 来源插件 | 说明 |
|---|---|---|---|
| 表情包库 | `src/emoji-library.ts` | stealer + meme_manager | MD5 去重、视觉打标（描述+情绪标签）、语义搜索、发送冷却 |
| 搜索表情 | 工具 `qq_search_emojis` | meme_manager | 按情绪/语义找表情（同义词扩展），返回 file 路径配 `qq_send_emoji` 用 |
| 表情统计 | 工具 `qq_emoji_stats` | stealer | 总数 / 已打标数 / 标签 top10 |
| 聊天记录搜索 | 工具 `qq_search_history` | angel_eye | 按关键词/发送者/日期过滤全量历史（含已折叠），可直接 `qq_reply_quote` |
| 群日报 | `scripts/daily-report.mjs` | qq_group_daily_analysis | 独立脚本：读会话日志生成当日消息量/活跃排行/消息流报告 |
| 日程任务 | persona 规则（schedule 工具） | private_companion | 每日 09:00 日报 + 主动出击（到点自己判断说不说） |
| 群友小账本 | workspace `MEMORY.md` | private_companion | 人际观察笔记模板，主动开话头的素材库 |

## 表情库运行机制

- 索引文件：`D:\OpenClaw\.openclaw\data\emoji-index.json`（md5 → file/source/desc/tags）
- 新偷的表情自动入库 + 后台视觉打标（走 dsh 的 llm 通道，失败静默）
- 同会话自动发表情最小间隔 20s（`SEND_COOLDOWN_MS`）
- 标签未打的图仍可按文件名列出，打标随时间自动补齐

## 群日报用法

```powershell
node C:\dsh\dsh-channel-qq\scripts\daily-report.mjs --date 2026-09-15
# 报告输出: C:\Users\Administrator\.dsh\channel-qq\daily-report-2026-09-15.md
```

自动发群：告诉{{persona.selfName}}「把昨天的日报发了」，它会跑脚本 → 读报告 → 用 `qq_send_text`
发精华。persona 里已写入操作步骤，它也可以自己挂 `schedule_create` 每天定时做。

## 关键位置

- 源码: `C:\dsh\dsh-channel-qq\src\`（emoji-library.ts 新增；emoji.ts / tools.ts / index.ts 修改）
- 备份: `C:\dsh\dsh-channel-qq\backup-20260914-pre-inject\`（注入模式改造前）
- 预设: `C:\Users\Administrator\.dsh\.agent-presets\tongling\agent.cordis.yml`
  （persona 末尾新增「日程任务与主动出击」段；bak-20260914 是 9/14 备份）
- 日报: `C:\Users\Administrator\.dsh\channel-qq\daily-report-*.md`

## 未采用（分析后判定不值得搬）

- `private_companion` 整体（982KB 单体，架构耦合 AstrBot；只拆了主动消息+关系账本两个思想）
- `angel_memory` 整体（dsh 已有 MEMORY.md + memory/ + compaction 记忆体系）
- `arena_image`（需要登录 lmarena.ai 的浏览器 CDP 会话 + 常驻 bridge，环境依赖重；生图已有 seedream 工具链）
- `angel_heart` 预筛（注入模式下 agent 即裁决者；token 压力出现时再考虑加预筛）

## 音乐点歌模块（2026-09-15 新增）

来源：astrbot_plugin_music-2.1.7 的思路移植（网易云 Web API 搜索 + meting 解析 + OneBot music/record 段发送）。

| 工具 | 用途 |
|---|---|
| `qq_search_music` | 网易云搜歌（关键词→id/歌名/歌手/时长） |
| `qq_resolve_music` | 解析播放直链/封面/歌词 |
| `qq_send_music_card` | 发官方音乐卡片（163 类型，点歌首选） |
| `qq_send_music_voice` | 下载音频后以语音条发送（卡片失败降级） |
| `qq_music_lyrics` | 拿完整歌词 |
| `qq_music_playlist` | 咱的个人歌单（add/remove/list/clear，持久化到 workspace/music-playlist.json） |

典型流程：`qq_search_music` 挑歌 → `qq_send_music_card` 发卡片；卡片失败降级 `qq_send_music_voice`；想看词就 `qq_music_lyrics`；好歌 `qq_music_playlist(action=add)` 收藏。

API 依赖（第三方免费源，失效时工具会报错）：搜索 `music.163.com/api/search/get/web`、解析 `api.qijieya.cn/meting/`。
## 网易云 VIP 会员支持（2026-09-15 新增，批次2 插件思路吸收）

VIP 登录与音质解锁（来源：neteasemusic / muliyresources 的扫码登录 + 会员 Cookie 思路，
已验证本机直连 music.163.com /api/ 端点可用）：

| 工具 | 用途 |
|---|---|
| `qq_netease_login` action=start | 拿扫码登录二维码链接（发给{{persona.masterName}}扫） |
| `qq_netease_login` action=poll | 轮询扫码状态，成功自动保存会员 Cookie（MUSIC_U） |
| `qq_netease_status` | 查登录状态 + 会员等级 |
| `qq_resolve_music` | 升级：带会员 Cookie 解析，VIP/付费歌曲可拿直链，br 最高 999000（无损/Hi-Res） |
| `qq_send_music_voice` | 升级：同上，VIP 歌也能发语音 |

Cookie 存储在 `C:\Users\Administrator\.dsh\channel-qq\netease-cookie.txt`（明文本地保存）。
登录一次长期有效；过期后 qq_netease_status 会显示未登录，重新扫码即可。

技术要点（为何不用 weapi）：music.163.com 的 /weapi/ 端点对数据中心 IP 有 WAF
（200+空响应体，实测），而 /api/ 端点正常响应 JSON —— 所以扫码与解析全走 /api/ 明文端点，
与 muliyresources 的 direct 模式一致，零部署（不需要 NeteaseCloudMusicApi 服务器）。
## 酷狗音乐模块（2026-09-16 新增）

来源：astrbot_plugin_kugoumusic-2.0.4 思路移植。依赖自建 **KuGouMusicApi** 服务
（已克隆部署到 `C:\dsh\KuGouMusicApi`，已注册 Windows 计划任务 `KuGouMusicApi`
开机自启，端口 4000）。

| 工具 | 用途 |
|---|---|
| `qq_kugou_search` | 酷狗搜歌（**需要登录**，酷狗已禁止匿名搜索，error_code 152） |
| `qq_kugou_send` | 发酷狗歌曲（语音条；quality 可选 viper_tape/viper_clear/super/high/flac/320/128） |
| `qq_kugou_login` action=start/poll | 扫码登录（酷狗App），成功保存 Cookie（token+userid） |

Cookie 存储：`C:\Users\Administrator\.dsh\channel-qq\kugou-cookie.txt`。
设备 dfid 持久化在 `kugou-dfid.txt`（首次自动注册）。

酷狗 VIP 音质阶梯：viper_tape(鲲鹏母带2.0) > viper_clear(超清) > super(HiFi) > high(Hi-Res) > flac > 320 > 128；
未登录时付费歌自动退 60s 试听片段（free_part=1）。

服务运维：`Start-ScheduledTask KuGouMusicApi` / 日志在任务计划程序查看；手动启动：
`PORT=4000 node C:\dsh\KuGouMusicApi\app.js`。