import { clientBundle } from '../tsdown.client.ts'

export default clientBundle('@deepseek-ai/dsh-client-ui-aqua', ['lib/types/index.js', 'lib/types/invariant.js'])
