// 网页划词 → AI 解读（页面侧）。
//
// 在任意 http(s) 页面里：选中文字 → 弹出一个小浮标「解读」→ 点它，选区被发给
// service worker，由它 POST 到本机 dsh 的 /dsh-insight 取回解读文本 → 在选区
// 旁边弹一张卡片显示。
//
// 刻意不依赖侧栏：解读结果直接出现在你划词的地方，不需要任何 iframe、cookie 或
// 鉴权。侧栏那边只是同步显示同一条记录（见 sidepanel.js）。
//
// **划词本身从不发请求**：一次解读就是一次模型调用，自动触发等于每选一段文字就
// 烧一次 token。只有点了浮标才解读，宁可多点一下。
//
// 例外是「结果只进侧栏」的模式（click-sidebar）：侧栏没打开时结果没有任何地方能
// 显示，这时整条链路直接跳过 —— 不发请求，也不弹浮标。
//
// 样式全部用 CSSOM 逐条赋值（不用 <style> 标签），避免撞上页面的 CSP 与样式。
//
// ── 诊断（这三个键只在排查问题时才需要读）────────────────────────────────
//   content_ready  脚本开始执行（写在最前面）
//   content_init   初始化**跑完**、监听器都已注册（写在最后面）
//   content_error  初始化抛了异常，附带消息与栈顶
//
// 只「有 ready、没有 init」就等于「中途抛异常」，配合 content_error 能直接看到
// 是哪一行。这一组是为一类特别难查的故障加的：**页面里选区明明存在，扩展却毫无
// 反应，而且不留任何痕迹** —— 没有这三个键时，只能靠反复追问用户去控制台取值。

/** 初始化抛异常时记一笔。**必须定义在 IIFE 外面** —— 它就是用来接住 IIFE 里异常的。 */
function recordInitError(error) {
  try {
    const detail = {
      at: new Date().toISOString(),
      url: location.href,
      message: String(error?.message ?? error).slice(0, 200),
      stack: String(error?.stack ?? "")
        .split("\n")
        .slice(0, 3)
        .join(" | ")
        .slice(0, 300),
    };
    void chrome.storage.local
      .get("content_error")
      .then((stored) => {
        const list = Array.isArray(stored.content_error) ? stored.content_error : [];
        list.unshift(detail);
        return chrome.storage.local.set({ content_error: list.slice(0, 5) });
      })
      .catch(() => {});
  } catch {}
}

try {
(() => {
  // 在所有帧里都运行。微前端/后台系统大量把正文嵌在 iframe 里，只跑顶层帧的话
  // 那些页面划词会**完全没反应** —— 选中高亮正常，但顶层 document 既收不到
  // mouseup/selectionchange，window.getSelection() 也是空的。
  //
  // 需要按帧区分的只有两处：孤儿横幅只由顶层帧弹（否则 N 个帧会弹 N 条），
  // 以及上报的页面地址（跨域帧读不到 top.location，退回 document.referrer）。
  const isTopFrame = window.top === window;

  // 注入自检：内容脚本可以直接用 chrome.storage，所以把这一笔直接落盘。
  // 「到底有没有注入」从此不需要靠猜 —— 能从扩展存储里读出来。
  void (async () => {
    try {
      const seen = await chrome.storage.local.get("content_ready");
      const list = Array.isArray(seen.content_ready) ? seen.content_ready : [];
      // 标记子帧：修 iframe 划词时，这一笔就是「帧里到底注入了没有」的证据。
      list.unshift({ at: new Date().toISOString(), url: location.href, ...(isTopFrame ? {} : { subframe: true }) });
      await chrome.storage.local.set({ content_ready: list.slice(0, 10) });
    } catch {}
  })();

  const MAX_TEXT = 12_000;
  const MIN_TEXT = 1;
  // 单次解读请求的兜底上限：host 侧是 120 秒，这里略高一点。
  const REQUEST_TIMEOUT_MS = 130_000;

  let bubble = null;
  let card = null;
  let busy = false;

  // 卡片上「钉住」的状态与卡片零件。钉住之后：
  //   - 点页面别处不会把卡片收掉（只收浮标）
  //   - 再划新词时**不新建卡片**，直接把结果就地更新进这张卡
  // 所以卡片一旦被替换/关闭，这些引用要一起清掉，否则会往已脱离文档的节点里写内容。
  let cardParts = null;
  let cardPinned = false;

  // 最近一次鼠标位置。Range 的几何信息在某些页面是坏的（见 anchorRect），那时用它兜底，
  // 否则浮标会带着 "NaNpx" 的 left/top 插进文档 —— 无效值被浏览器忽略，浮标就此消失。
  let lastPointer = null;

  // 侧栏当前是否展开。内容脚本看不到侧栏，由 background 以侧栏长连接的有无判断
  // 后告知（启动时问一次，之后靠推送）。默认 true —— 拿不准时按「开着」处理，
  // 与改动前的行为一致，不会误伤。
  let panelOpen = true;

  // ---- 设置：浮标文字 / 触发与展示方式 / 浮窗位置 ----
  //
  // 内容脚本在 manifest 里是普通脚本（没有 type: module），不能 import 设置模块，
  // 所以自己读 storage。取值只认下面两个集合，其余（缺失、脏值）一律按默认的
  // 「点浮标 + 页面浮窗」走 —— 默认值因此只需要在设置页维护一份。
  const DEFAULT_LABEL = "解读";
  // 模式只决定**结果落在哪**：页面浮窗还是只进侧栏。触发方式只有一种 —— 点浮标。
  // 旧版还有 auto / auto-sidebar（划词即解读），那会为每段选区白跑一次模型；
  // 这两种取值可能残留在老用户的存储里，读到就归一成对应的手动模式。
  const MODES = new Set(["click", "click-sidebar"]);
  const LEGACY_MODES = new Map([
    ["auto", "click"],
    ["auto-sidebar", "click-sidebar"],
  ]);
  const SIDEBAR_ONLY_MODES = new Set(["click-sidebar"]);
  const SETTING_KEYS = ["insight_label", "insight_mode", "insight_position"];

  // 划词后多久确认「选区稳定了」。只弹浮标，不发请求，所以可以短一点。
  const SETTLE_MS = 220;

  // 固定位置时统一留的边距。
  const FIXED_MARGIN = 16;

  let label = DEFAULT_LABEL;
  let mode = "click";
  let position = "follow";

  const sidebarOnly = () => SIDEBAR_ONLY_MODES.has(mode);

  /** 旧版自动模式 → 对应的手动模式；认不出的取值一律回落到默认。 */
  function normalizeMode(raw) {
    const next = LEGACY_MODES.get(raw) ?? raw;
    return MODES.has(next) ? next : "click";
  }

  function readSettings(stored) {
    if (stored === null || typeof stored !== "object") return;
    if (typeof stored.insight_label === "string" && stored.insight_label.trim() !== "") {
      label = stored.insight_label.trim();
    }
    if (typeof stored.insight_mode === "string") mode = normalizeMode(stored.insight_mode);
    if (typeof stored.insight_position === "string") position = stored.insight_position;
  }

  async function reloadSettings() {
    try {
      readSettings(await chrome.storage.local.get(SETTING_KEYS));
    } catch {}
  }

  void reloadSettings();

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (!SETTING_KEYS.some((key) => changes[key] !== undefined)) return;
      // changes 只带改动过的键，逐字段合并容易漏，整组重读更省心。
      void reloadSettings();
    });
  } catch {}

  const dark = () =>
    window.matchMedia?.("(prefers-color-scheme: dark)")?.matches === true;

  function make(tag, styles, text) {
    const el = document.createElement(tag);
    el.setAttribute("data-dsh-insight", "");
    for (const key of Object.keys(styles)) el.style[key] = styles[key];
    if (text !== undefined) el.textContent = text;
    return el;
  }

  function drop(el) {
    if (el !== null && el.parentNode !== null) el.parentNode.removeChild(el);
  }

  function clearBubble() {
    drop(bubble);
    bubble = null;
  }

  function clearCard() {
    drop(card);
    card = null;
    cardParts = null;
    cardPinned = false;
  }

  function clearAll() {
    clearBubble();
    clearCard();
  }

  // ---- 孤儿内容脚本检测 ----
  //
  // 扩展被重载/更新后，**已经打开的页面**里的内容脚本会和扩展失去联系：
  // chrome.runtime.id 变成 undefined，sendMessage 会抛 "Extension context
  // invalidated"。这类失败用户完全看不见 —— 只进侧栏的模式下连卡片都没有，
  // 表现就是「划了词，什么都没发生」。所以专门识别它，并在页面上说清原因。

  let notice = null;
  let noticeTimer = null;

  /** 当前内容脚本是否已经和扩展断开。 */
  function isOrphaned() {
    try {
      return chrome === undefined || chrome.runtime === undefined || chrome.runtime.id === undefined;
    } catch {
      // 光是访问就可能抛 —— 那就按孤儿处理。
      return true;
    }
  }

  function showOrphanNotice() {
    // 只在顶层帧提示。现在脚本在每个帧里都跑，每个帧各弹一条会变成 N 条横幅。
    if (!isTopFrame) return;
    // 侧栏没开、而结果又只能进侧栏：本来就不会有任何反应，再弹一条「请刷新本页」
    // 纯属噪声 —— 而且违背了「只进侧栏」模式下页面保持干净的约定。
    // 页面浮窗模式不受这条限制：那种模式本来就会在页面上出东西，缺了它需要解释。
    if (panelUnavailable()) return;
    if (notice !== null) return;
    const isDark = dark();
    const box = make("div", {
      position: "fixed",
      zIndex: "2147483647",
      left: "50%",
      transform: "translateX(-50%)",
      bottom: "20px",
      maxWidth: "min(520px, calc(100vw - 32px))",
      padding: "8px 14px",
      font: "13px/1.5 system-ui, -apple-system, 'Segoe UI', 'Microsoft YaHei', sans-serif",
      color: isDark ? "#e6edf3" : "#1f2328",
      background: isDark ? "#21262d" : "#ffffff",
      border: `1px solid ${isDark ? "#3d444d" : "#d1d9e0"}`,
      borderRadius: "8px",
      boxShadow: "0 4px 16px rgba(0,0,0,.22)",
      textAlign: "center",
    });
    box.textContent = "dsh-insight 已更新：刷新本页后划词解读才能继续工作。";
    document.documentElement.appendChild(box);
    notice = box;
    // 别一直挂着，用户看见就够了。
    noticeTimer = window.setTimeout(() => {
      clearOrphanNotice();
    }, 8000);
  }

  function clearOrphanNotice() {
    if (noticeTimer !== null) {
      window.clearTimeout(noticeTimer);
      noticeTimer = null;
    }
    drop(notice);
    notice = null;
  }

  /** 能用来摆浮标的矩形：四个数都得是有限值，且不能是完全空的一小块。 */
  function usableRect(rect) {
    if (rect === undefined || rect === null) return false;
    const { left, top, width, height } = rect;
    const finite = [left, top, width, height].every(
      (v) => typeof v === "number" && Number.isFinite(v),
    );
    if (!finite) return false;
    return width > 0 || height > 0;
  }

  /** 把鼠标位置当成一个零尺寸锚点。 */
  function pointerRect() {
    if (lastPointer === null) return null;
    const { x, y } = lastPointer;
    return { left: x, top: y, right: x, bottom: y, width: 0, height: 0 };
  }

  /** 最后的兜底：视口内一个固定点，宁可位置不准也不能丢掉这次划词。 */
  function centerRect() {
    const x = Math.round(window.innerWidth / 2);
    const y = Math.round(window.innerHeight / 3);
    return { left: x, top: y, right: x, bottom: y, width: 0, height: 0 };
  }

  /**
   * 给这次选区长出一个**可用**的锚点矩形。
   *
   * 不能只信 `range.getBoundingClientRect()`：实测在 Monaco 编辑器里它返回
   * `width=0, height=NaN`。NaN 会顺着 `Math.max(8, …)` 传下去，让浮标的
   * left/top 变成 "NaNpx" —— 无效值被浏览器直接忽略，浮标看着就像没出现。
   *
   * 所以逐级退化：Range 包围盒 → Range 分段矩形 → 选区所在元素 → 鼠标位置 → 视口定点。
   */
  function anchorRectFor(range) {
    const candidates = [];
    try {
      candidates.push(range.getBoundingClientRect());
    } catch {}
    try {
      for (const r of range.getClientRects()) candidates.push(r);
    } catch {}
    try {
      const node = range.startContainer;
      const el = node?.nodeType === 1 ? node : node?.parentElement;
      if (el?.getBoundingClientRect) candidates.push(el.getBoundingClientRect());
    } catch {}
    for (const r of candidates) if (usableRect(r)) return r;
    return pointerRect() ?? centerRect();
  }

  /**
   * 选区是不是落在我们自己的卡片/浮标里。
   *
   * 钉住卡片之后，从卡片正文里选一段文字复制是很自然的动作 —— 但那也是一次
   * 「选中文字」，不去管它就会拿卡片自己的文字再发一次解读，把卡片内容顶掉。
   */
  function selectionInsideCard(selection) {
    try {
      if (selection.rangeCount === 0) return false;
      const node = selection.getRangeAt(0).commonAncestorContainer;
      const el = node !== null && node.nodeType === 1 ? node : node?.parentElement;
      return el instanceof Element && el.closest("[data-dsh-insight]") !== null;
    } catch {
      return false;
    }
  }

  /**
   * 当前选区。只有在**确实没有文字**时才返回 undefined。
   *
   * 两个「不」：
   *   - **不信 `isCollapsed`**。实测（Monaco 编辑器）会给出自相矛盾的状态：
   *     `isCollapsed === true` 但 `toString()` 有 89 个字符。以它为准会把这种选区
   *     直接丢掉，表现就是「选中了、扩展毫无反应」，而且不留任何痕迹。
   *     **文本长度才是「有没有东西可解读」的唯一真相。**
   *   - 几何信息坏掉也不算「没有选区」，那只影响浮标摆在哪（见 anchorRectFor）。
   */
  function currentSelection() {
    const selection = window.getSelection();
    if (selection === null || selection === undefined) return undefined;
    const text = selection.toString().trim();
    if (text.length < MIN_TEXT) return undefined;
    if (selectionInsideCard(selection)) return undefined;
    let rect;
    try {
      rect = anchorRectFor(selection.getRangeAt(0));
    } catch {
      // rangeCount 为 0 之类：拿不到几何不影响解读，退回指针/视口定点。
      rect = pointerRect() ?? centerRect();
    }
    return { text: text.slice(0, MAX_TEXT), rect };
  }

  /**
   * 上报给 dsh 的「页面地址」。
   *
   * 现在内容脚本在所有帧里运行，所以可能是在某个 iframe 里划的词。优先用能反映
   * 地址栏的那个：同源时直接读顶层帧的 URL；跨域读不到就退回 document.referrer
   * —— 它就是嵌这个帧的页面。都没有才用帧自己的 URL。
   */
  function pageUrl() {
    if (isTopFrame) return location.href;
    try {
      return window.top.location.href;
    } catch {
      return document.referrer !== "" ? document.referrer : location.href;
    }
  }

  // ---- 浮标 ----

  function showBubble(selection) {
    clearBubble();
    const isDark = dark();
    const button = make(
      "button",
      {
        position: "fixed",
        zIndex: "2147483647",
        padding: "4px 10px",
        font: "12px/1.4 system-ui, -apple-system, 'Segoe UI', sans-serif",
        color: isDark ? "#e6edf3" : "#1f2328",
        background: isDark ? "#21262d" : "#ffffff",
        border: `1px solid ${isDark ? "#3d444d" : "#d1d9e0"}`,
        borderRadius: "6px",
        boxShadow: "0 2px 10px rgba(0,0,0,.18)",
        cursor: "pointer",
        whiteSpace: "nowrap",
      },
      label,
    );
    if (position === "fixed") {
      // 固定在右下角：不用每次都去追选区，鼠标习惯性回到同一处就能点到。
      button.style.right = `${String(FIXED_MARGIN)}px`;
      button.style.bottom = `${String(FIXED_MARGIN)}px`;
    } else {
      // 按钮宽度随文字变化，所以靠右对齐时留出一点余量。
      const estimated = 26 + label.length * 13;
      const left = Math.max(
        8,
        Math.min(window.innerWidth - estimated, selection.rect.right - estimated / 2),
      );
      const top = selection.rect.top > 40 ? selection.rect.top - 32 : selection.rect.bottom + 8;
      button.style.left = `${String(left)}px`;
      button.style.top = `${String(Math.max(8, top))}px`;
    }
    button.addEventListener("mousedown", (event) => {
      // 别让点击清掉选区。
      event.preventDefault();
      event.stopPropagation();
    });
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      void interpret(selection.text, selection.rect);
    });
    document.documentElement.appendChild(button);
    bubble = button;
  }

  // ---- 卡片 ----

  /** 钉住/取消钉住时的外观，以及按钮上的说明文字。 */
  function syncPin() {
    if (cardParts === null) return;
    const pin = cardParts.pin;
    // 彩色图钉 = 已钉住，灰色 = 未钉住。比只改透明度更好认。
    pin.style.opacity = cardPinned ? "1" : "0.4";
    pin.style.filter = cardPinned ? "none" : "grayscale(1)";
    pin.style.borderRadius = "5px";
    pin.setAttribute("aria-pressed", cardPinned ? "true" : "false");
    pin.title = cardPinned
      ? "已钉住：再划新词会就地更新这张卡片（点击取消钉住）"
      : "钉住：卡片不会消失，划新词时就地更新解读";
  }

  /** 请求在飞的时候，标题栏右侧显示「更新中…」，正文保留上一次的结果不闪。 */
  function setCardBusy(on) {
    if (cardParts === null) return;
    cardParts.hint.style.display = on ? "" : "none";
  }

  /**
   * 让标题栏可以按住拖动。
   *
   * 只认标题栏：正文是可选中的文字，整卡可拖会和「划词复制」打架。
   * 用 pointer capture 而不是 window 上的 move 监听 —— 拖到 iframe 上方时，
   * 事件会被那个帧的文档吃掉，window 监听会直接断掉。
   */
  function enableDrag(shell, bar) {
    const clamp = (v, max) => (Number.isFinite(v) ? Math.min(Math.max(0, v), Math.max(0, max)) : 0);
    let drag = null;

    bar.addEventListener("pointerdown", (event) => {
      if (event.button !== 0) return;
      const target = event.target;
      // 图钉和关闭不参与拖动
      if (target instanceof Element && target.closest("button") !== null) return;
      const rect = shell.getBoundingClientRect();
      drag = { id: event.pointerId, dx: event.clientX - rect.left, dy: event.clientY - rect.top };
      // 可能停在「右下角固定」的模式下：先换成 left/top，否则一按就跳一下
      shell.style.right = "auto";
      shell.style.bottom = "auto";
      shell.style.left = `${String(rect.left)}px`;
      shell.style.top = `${String(rect.top)}px`;
      bar.style.cursor = "grabbing";
      try {
        bar.setPointerCapture(event.pointerId);
      } catch {}
      // 别让页面从标题栏开始选字，也别让页面的 mousedown 抢走这次按下
      event.preventDefault();
      event.stopPropagation();
    });

    const move = (event) => {
      if (drag === null || event.pointerId !== drag.id) return;
      const maxX = window.innerWidth - (shell.offsetWidth || 0);
      const maxY = window.innerHeight - (shell.offsetHeight || 0);
      shell.style.left = `${String(clamp(event.clientX - drag.dx, maxX))}px`;
      shell.style.top = `${String(clamp(event.clientY - drag.dy, maxY))}px`;
      event.preventDefault();
    };
    const end = (event) => {
      if (drag === null || event.pointerId !== drag.id) return;
      drag = null;
      bar.style.cursor = "grab";
      try {
        bar.releasePointerCapture(event.pointerId);
      } catch {}
    };
    // pointer capture 之后 move/up 都会回到 bar 上，所以监听在 bar 就够。
    bar.addEventListener("pointermove", move);
    bar.addEventListener("pointerup", end);
    bar.addEventListener("pointercancel", end);
  }

  /** 新建一张卡片。 */
  function showCard(anchorRect, body) {
    clearBubble();
    clearCard();
    const isDark = dark();
    const width = Math.min(420, Math.max(260, window.innerWidth - 24));

    const shell = make("div", {
      position: "fixed",
      zIndex: "2147483647",
      width: `${String(width)}px`,
      maxHeight: "60vh",
      overflow: "auto",
      padding: "10px 12px",
      font: "13px/1.6 system-ui, -apple-system, 'Segoe UI', 'Microsoft YaHei', sans-serif",
      color: isDark ? "#e6edf3" : "#1f2328",
      background: isDark ? "#161b22" : "#ffffff",
      border: `1px solid ${isDark ? "#3d444d" : "#d1d9e0"}`,
      borderRadius: "10px",
      boxShadow: "0 6px 24px rgba(0,0,0,.22)",
      wordBreak: "break-word",
    });

    const bar = make("div", {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      marginBottom: "6px",
      cursor: "grab",
      // 标题栏是拖动把手：别让浏览器把这里当成可选中文字，触摸下也别滚动页面
      userSelect: "none",
      touchAction: "none",
    });
    // 把手的视觉提示：不写这个，没人知道标题栏可以拖。
    const grip = make("span", {
      flex: "0 0 auto",
      fontSize: "11px",
      lineHeight: "1",
      letterSpacing: "1px",
      color: isDark ? "#8b949e" : "#6a737d",
      opacity: "0.7",
    }, "⠿");
    const label = make(
      "span",
      {
        flex: "1",
        fontSize: "11px",
        letterSpacing: ".04em",
        textTransform: "uppercase",
        color: isDark ? "#8b949e" : "#6a737d",
      },
      "dsh 解读",
    );
    const hint = make("span", {
      flex: "0 0 auto",
      fontSize: "11px",
      color: isDark ? "#8b949e" : "#6a737d",
      display: "none",
    }, "更新中…");
    const buttonStyle = {
      border: "0",
      background: "transparent",
      color: isDark ? "#8b949e" : "#6a737d",
      cursor: "pointer",
      font: "13px/1 system-ui, sans-serif",
      padding: "2px 4px",
      flex: "0 0 auto",
    };
    const pin = make("button", buttonStyle, "📌");
    pin.addEventListener("click", () => {
      cardPinned = !cardPinned;
      syncPin();
    });
    const close = make("button", { ...buttonStyle, font: "14px/1 system-ui, sans-serif" }, "✕");
    close.title = "关闭（Esc）";
    close.addEventListener("click", () => {
      clearCard();
    });
    bar.title = "按住拖动";
    bar.appendChild(grip);
    bar.appendChild(label);
    bar.appendChild(hint);
    bar.appendChild(pin);
    bar.appendChild(close);

    // 正文默认按纯文本排版（"解读中…"、跳过、报错都走这条路）；
    // 渲染 Markdown 时 fillCardMarkdown 会把它翻回 normal 并逐元素套样式。
    const content = make("div", { whiteSpace: "pre-wrap" }, body);
    shell.appendChild(bar);
    shell.appendChild(content);

    if (position === "fixed") {
      // 固定在右下角：钉住不动，读长文时不会随选区乱跑。
      shell.style.right = `${String(FIXED_MARGIN)}px`;
      shell.style.bottom = `${String(FIXED_MARGIN)}px`;
      shell.style.maxHeight = "50vh";
    } else {
      const left = Math.max(12, Math.min(window.innerWidth - width - 12, anchorRect.left));
      const below = anchorRect.bottom + 10;
      shell.style.left = `${String(left)}px`;
      shell.style.top = `${String(Math.max(12, Math.min(window.innerHeight - 120, below)))}px`;
    }
    enableDrag(shell, bar);
    document.documentElement.appendChild(shell);
    card = shell;
    cardParts = { content, pin, hint, label, bar };
    syncPin();
    return content;
  }

  /**
   * 开一张卡片：钉住的卡片就地复用，否则新建一张。
   * 复用时不写占位文案 —— 那会让正文闪成「解读中…」，钉住的意义就没了。
   */
  function openCard(anchorRect, placeholder) {
    if (card !== null && cardPinned && cardParts !== null) {
      clearBubble();
      setCardBusy(true);
      return cardParts.content;
    }
    return showCard(anchorRect, placeholder);
  }

  /** 卡片正文填纯文本 —— 占位、跳过、报错走这条路。 */
  function fillCardText(content, text) {
    content.style.whiteSpace = "pre-wrap";
    content.textContent = text;
  }

  /**
   * 卡片正文渲染 Markdown。
   * 浮窗里没有样式表，样式由 md.js 逐元素写成行内样式（见 renderMarkdownForCard）。
   */
  function fillCardMarkdown(content, text) {
    content.style.whiteSpace = "normal";
    const md = globalThis.dshInsightMd;
    // 正常情况 manifest 保证 md.js 先注入；扩展刚被更新/卸载的瞬间可能取不到，
    // 这时退回纯文本，总比把内容吞掉强。
    if (md === undefined) {
      fillCardText(content, text);
      return;
    }
    md.renderMarkdownForCard(content, text, dark());
  }

  async function interpret(text, anchorRect) {
    if (busy) return;
    // 兜底：调用方也可能是排队补发，这里再判一次，保证侧栏没开就绝不发请求。
    if (panelUnavailable()) {
      clearBubble();
      return;
    }
    busy = true;
    // 「只用侧边栏」时不建卡片：结果由 background 广播 + 落 last_insight 给侧栏。
    // 浮标也要收起来 —— 原来是被 showCard 里的 clearBubble 顺带收掉的，不建卡片
    // 就没人收，会留一个点过的按钮挂在页面上。
    let content = null;
    if (sidebarOnly()) clearBubble();
    else content = openCard(anchorRect, "解读中…");
    const started = Date.now();
    let timer = null;
    try {
      // host 侧超时是 120 秒，这里比它略高一点兜底。没有这层的话，万一 sendMessage
      // 因为 service worker 被回收之类的原因永远不 settle，busy 会一直挂着 ——
      // 那样之后点浮标就彻底哑了，而且表面上看不出原因。
      const reply = await Promise.race([
        chrome.runtime.sendMessage({
          type: "interpret",
          text,
          url: pageUrl(),
          title: document.title,
          // 结果该去哪儿 —— 供 background 的兜底闸门判断（sidebar 且侧栏没开则跳过）。
          target: sidebarOnly() ? "sidebar" : "page",
        }),
        new Promise((_, reject) => {
          timer = window.setTimeout(() => reject(new Error("请求超时（130 秒）")), REQUEST_TIMEOUT_MS);
        }),
      ]);
      // skipped 不是失败，别污染诊断记录。
      if (reply?.skipped !== true) {
        recordTrace({ event: "click", ok: reply?.ok === true, ms: Date.now() - started, error: reply?.ok === true ? "" : String(reply?.error ?? "") });
      }
      if (content !== null) {
        setCardBusy(false);
        if (reply?.ok === true) fillCardMarkdown(content, String(reply.text ?? ""));
        else if (reply?.skipped === true) fillCardText(content, "侧栏未打开，已跳过。");
        else fillCardText(content, `解读失败：${String(reply?.error ?? "未知错误")}`);
      }
    } catch (error) {
      // 请求途中扩展被重载也会走到这里 —— 同样属于「孤儿」，给出能照做的提示。
      const orphaned = isOrphaned();
      if (orphaned) showOrphanNotice();
      recordTrace({ event: "click", ok: false, ms: Date.now() - started, error: String(error?.message ?? error) });
      if (content !== null) {
        setCardBusy(false);
        fillCardText(
          content,
          orphaned
            ? "解读失败：扩展已更新，请刷新本页后重试。"
            : `解读失败：${String(error?.message ?? error)}`,
        );
      }
    } finally {
      if (timer !== null) window.clearTimeout(timer);
      busy = false;
    }
  }

  // ---- 侧栏开合状态 ----

  void (async () => {
    try {
      const reply = await chrome.runtime.sendMessage({ type: "panel-state-query" });
      if (typeof reply?.open === "boolean") panelOpen = reply.open;
    } catch {}
  })();

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "panel-state" && typeof msg.open === "boolean") panelOpen = msg.open;
  });

  /**
   * 这次解读无处可显示：模式是「结果只进侧栏」，而侧栏没有打开。
   *
   * 只有 sidebarOnly 模式会命中。页面浮窗模式（click）不受影响 ——
   * 它的结果就画在页面上，本来就不需要侧栏。
   */
  function panelUnavailable() {
    return sidebarOnly() && !panelOpen;
  }

  // ---- 事件 ----

  let debounce = null;

  /** 诊断：记下最近几次尝试的结果（和 content_ready 同一思路，出事不用靠猜）。只记元信息。 */
  function recordTrace(entry) {
    void (async () => {
      try {
        const stored = await chrome.storage.local.get("content_last");
        const list = Array.isArray(stored.content_last) ? stored.content_last : [];
        list.unshift({ at: new Date().toISOString(), url: pageUrl(), ...entry });
        await chrome.storage.local.set({ content_last: list.slice(0, 10) });
      } catch {}
    })();
  }

  // 「回调第一次真的跑起来」记一次（每页）。这一笔回答的是：
  //   监听器在不在？事件到没到？回调当时看到了什么？
  // 它和 content_init（初始化跑完）、content_error（初始化抛异常）合起来三分：
  //   有 error 没 init            → 初始化就挂了，看 content_error 的栈
  //   有 init 没 settle           → 监听器在，但 mouseup/selectionchange 没到我们手里
  //   有 init 也有 settle         → 事件到了，问题在回调内部的判断（快照里能看到）
  let settleSeen = false;
  let settleWithTextSeen = false;
  function snapshotNow() {
    try {
      const sel = window.getSelection();
      const text = sel === null || sel === undefined ? "" : sel.toString().trim();
      return (
        `len=${String(text.length)}` +
        ` collapsed=${String(sel?.isCollapsed ?? "null")}` +
        ` orphan=${String(isOrphaned())}` +
        ` mode=${mode}` +
        ` panel=${String(panelOpen)}` +
        ` ranges=${String(sel?.rangeCount ?? "null")}`
      );
    } catch (error) {
      return `snapshot-failed:${String(error?.message ?? error)}`;
    }
  }
  function traceSettleOnce() {
    // 第一次回调（哪怕只是点了一下空白）：证明「事件确实到达了我们手里」。
    if (!settleSeen) {
      settleSeen = true;
      recordTrace({ event: "settle-first", ok: true, ms: 0, error: snapshotNow().slice(0, 140) });
    }
    // 第一次回调时**确实有非空选区**：这一笔才是排查「选中了没反应」的关键。
    // 单独记是因为用户可能先点空白再选词，第一笔快照会是没有选区的样子。
    if (!settleWithTextSeen) {
      try {
        const sel = window.getSelection();
        const text = sel === null || sel === undefined ? "" : sel.toString().trim();
        if (text.length > 0) {
          settleWithTextSeen = true;
          recordTrace({ event: "settle-selection", ok: true, ms: 0, error: snapshotNow().slice(0, 140) });
        }
      } catch {}
    }
  }

  // 「明明有选区却没接住」只记一次（每页）。普通点击不算 —— 只有真的存在
  // 非折叠、有文字的选区时才会写，所以不会有噪声。
  let captureMissTraced = false;
  function traceCaptureMissOnce() {
    if (captureMissTraced) return;
    let detail = "";
    try {
      const s = window.getSelection();
      if (s === null || s === undefined) return;
      const text = s.toString().trim();
      // 注意：这里**不能**用 s.isCollapsed 提前返回 —— 它正是会给出错误值的那一项，
      // 之前就是因为它，这条诊断和被诊断的代码犯了同一个错、一条都没记下来。
      if (text.length === 0) return;
      let rect = "none";
      try {
        const r = s.getRangeAt(0).getBoundingClientRect();
        rect = `${String(r.width)}x${String(r.height)}`;
      } catch (error) {
        rect = `throw:${String(error?.message ?? error)}`;
      }
      detail = `len=${String(text.length)} rect=${rect} ranges=${String(s.rangeCount)}`;
    } catch (error) {
      detail = `probe-failed:${String(error?.message ?? error)}`;
    }
    if (detail === "") return;
    captureMissTraced = true;
    recordTrace({ event: "capture-miss", ok: false, ms: 0, error: detail.slice(0, 140) });
  }

  // 跳过只记一次（每页），免得侧栏没开时每次划词都写一遍存储。
  let panelSkipTraced = false;
  function tracePanelSkipOnce() {
    if (panelSkipTraced) return;
    panelSkipTraced = true;
    recordTrace({ event: "skip-sidebar-closed", ok: false, ms: 0, error: "侧栏未展开，未发起解读" });
  }

  function onSelectionSettled() {
    window.clearTimeout(debounce);
    // 拖选过程中选区会不断「稳定」，每次都处理会反复挪浮标，所以等停手再算。
    debounce = window.setTimeout(() => {
      traceSettleOnce();
      // 在卡片里选字（多半是想复制）不是划词：不弹浮标，更不能被记成
      // 「抓不到选区」的诊断。
      if (selectionInsideCard(window.getSelection())) {
        clearBubble();
        return;
      }
      const selection = currentSelection();
      if (selection === undefined) {
        clearBubble();
        // 极少数情况下确实存在选区却没接住 —— 记下原因，免得下次又只能靠猜。
        traceCaptureMissOnce();
        return;
      }
      // 扩展重载后本页的脚本已成孤儿：任何请求都注定失败，直接说清原因。
      // （连浮标都不该弹出来 —— 点了也只会失败。）
      if (isOrphaned()) {
        clearBubble();
        showOrphanNotice();
        return;
      }
      // 只能进侧栏、而侧栏没开：既不弹浮标也不发请求（弹了也只会点了没反应）。
      if (panelUnavailable()) {
        clearBubble();
        tracePanelSkipOnce();
        return;
      }
      // 解析中不弹浮标（省得点了一个正在跑的东西）。
      if (busy) return;
      // 只弹浮标 —— 请求要等用户点它才发。这是刻意保留的一步：自动解读会让
      // 每一次划词都变成一次模型调用，token 消耗完全不受控。
      showBubble(selection);
    }, SETTLE_MS);
  }

  document.addEventListener("mouseup", (event) => {
    // 先记指针位置：锚点矩形退化到最后一档时靠它摆浮标。
    if (typeof event?.clientX === "number" && typeof event?.clientY === "number") {
      lastPointer = { x: event.clientX, y: event.clientY };
    }
    onSelectionSettled();
  }, true);
  document.addEventListener("keyup", (event) => {
    const key = event.key ?? "";
    if (key === "Shift" || key.startsWith("Arrow")) onSelectionSettled();
  }, true);
  // 双击选词、三击选段、以及键盘选中都不一定伴随 mouseup；selectionchange 兜底。
  document.addEventListener("selectionchange", onSelectionSettled, true);

  document.addEventListener("mousedown", (event) => {
    const target = event.target;
    if (target instanceof Element && target.closest("[data-dsh-insight]") !== null) return;
    // 钉住的卡片不跟着一起收：不然「划下一段词」这个动作本身就会把它关掉。
    if (cardPinned) {
      clearBubble();
      return;
    }
    clearAll();
  }, true);

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") clearAll();
  }, true);

  // 切回一个「扩展重载前就打开」的标签页时提前告知，别等用户划完词才发现。
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && isOrphaned()) showOrphanNotice();
  }, true);

  // ── 初始化完成标记：写在最末，所以「有 content_init」就等于「监听器都注册好了」。
  // 同时还记下**跑的是哪个版本**、以及**是不是孤儿**，这两项正是排查「划不动」时
  // 最先要区分的：是旧版本还在跑？还是页面没跟着扩展一起刷新？
  void (async () => {
    try {
      let version = "?";
      let orphan = false;
      // 「是否孤儿」与「取版本」分开判定：取不到版本不该被误报成孤儿。
      try {
        orphan = chrome.runtime.id === undefined;
      } catch {
        orphan = true;
      }
      try {
        version = chrome.runtime.getManifest().version;
      } catch {}
      const stored = await chrome.storage.local.get("content_init");
      const list = Array.isArray(stored.content_init) ? stored.content_init : [];
      list.unshift({
        at: new Date().toISOString(),
        url: location.href,
        version,
        orphan,
        ...(isTopFrame ? {} : { subframe: true }),
      });
      await chrome.storage.local.set({ content_init: list.slice(0, 10) });
    } catch {}
  })();
})();
} catch (error) {
  recordInitError(error);
}
