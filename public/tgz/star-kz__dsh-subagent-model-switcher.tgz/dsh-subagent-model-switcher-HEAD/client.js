/**
 * dsh-subagent-model-switcher — Client half.
 *
 * 给「子 agent 会话」的输入框补上模型与思考强度切换（主会话完全不受影响），
 * 任何状态下都可切换：运行中、空闲、未物化（冷会话）都行。
 *
 * 关键事实（源码依据）：
 *  - 官方 composer 在 `conversation.input.right`（提交按钮左侧）渲染 list 槽；
 *    该槽的 render 条件只有 `input !== undefined && sessionId !== undefined`，
 *    子会话（continuable）同样满足——所以补位是可行的；
 *  - 但这**不能靠 register 的 inject(sessionId) 判断**：实测 inject 的结果按一次调用缓存，
 *    和组件实际渲染的会话不是同一个。正确做法是在组件内用标准钩子
 *    useSession 读当前渲染会话的 snapshot.subagent（与官方 ui-subagent 同源），
 *    并用注入的 sessionId 去 modelDirectories.directoryFor 取该会话自己的目录；
 *  - 官方/effort-switcher 的模型位对子会话 return null（available=false），本插件不碰它。
 *
 * 数据通路（v2，修复「该子会话当前未激活」报错）：
 *  - 官方 `session/selectModel` 对子会话一律拒绝（session/agent-busy），不再调用；
 *  - 选择写入插件自己的 settings 命名空间（`dsh-subagent-model-switcher`，
 *    即 Host 半侧 Config 的 volatile 字段 `overrides[sessionId]`）：
 *    官方 `settings/describe` 读、`settings/mutate` 写（路径级 set/unset），
 *    持久化在 profile patch 里，重启后对冷会话同样生效；
 *  - Host 半侧在根 ctx 监听 agent 级瀑布事件，按 sessionId 命中覆盖后在
 *    下一次请求生效（运行中的子 agent 在下一个 step 生效，语义与官方
 *    selectForNextRequest 一致）。
 *
 * 稳定性约定：
 *  - useSyncExternalStore 的 getSnapshot 必须返回稳定引用，否则 React 抛错、
 *    槽位边界退休条目（active:false，控件永久消失）——这里用稳定 EMPTY 常量兜底；
 *  - 外层再套错误边界：组件任何异常只让本控件隐身，不影响其他 UI。
 */
window.__ModuleLoader__.load({
  id: '@k-launcher/dsh-subagent-model-switcher',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } = React;

    const NS = 'dsh-subagent-model-switcher';

    const STR = {
      zh: {
        pickModel: '选择模型',
        effort: '推理强度',
        loading: '加载中…',
        noModels: '没有可用的模型。',
        failed: '切换失败：',
        auto: '默认（跟随继承）',
        noEntry: '插件 Host 半侧未就绪（请重启宿主；若仍失败，检查插件目录内的 schemastery 交界）',
      },
      en: {
        pickModel: 'Select model',
        effort: 'Reasoning effort',
        loading: 'Loading…',
        noModels: 'No models available.',
        failed: 'Switch failed: ',
        auto: 'Default (inherited)',
        noEntry: 'Plugin host half is not ready (restart the host; if it persists, check the schemastery junction inside the plugin directory)',
      },
    };

    const EMPTY_SNAPSHOT = { status: 'idle', groups: [], current: null, error: null };
    const NOOP_SUBSCRIBE = () => () => {};

    const CSS = `
.dsms-root{position:relative;display:inline-flex}
.dsms-trigger{min-width:0;max-width:200px;height:26px;color:var(--dsw-alias-label-secondary);cursor:pointer;background:0 0;border:none;border-radius:22px;outline:none;align-items:center;gap:3px;padding:0 3px 0 6px;font-size:12px;font-weight:500;line-height:18px;display:inline-flex}
.dsms-trigger:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}
.dsms-trigger:disabled{color:var(--dsw-alias-label-dimmed);cursor:default}
.dsms-trigger:focus-visible{box-shadow:0 0 0 2px var(--dsw-alias-border-l3)}
.dsms-label{text-overflow:ellipsis;white-space:nowrap;min-width:0;overflow:hidden}
.dsms-effort{color:var(--dsw-alias-label-caption);flex:none}
.dsms-menu{position:absolute;bottom:calc(100% + 8px);right:0;z-index:9999;width:min(240px,calc(100vw - 32px));max-height:min(380px,calc(100vh - 96px));display:flex;flex-direction:column;padding:3px;border:1px solid var(--dsw-alias-border-l1);border-radius:10px;background:var(--dsw-alias-bg-overlay);box-shadow:var(--dsw-shadow-lv3);color:var(--dsw-alias-label-primary);overflow:hidden}
.dsms-section{color:var(--dsw-alias-label-tertiary);padding:6px 8px 2px;font-size:10px;line-height:14px;flex:none}
.dsms-list{overflow-y:auto;min-height:0;flex:1 1 auto;border-radius:6px;margin:0 2px}
.dsms-item{display:flex;align-items:center;gap:6px;width:100%;border:none;background:0 0;color:var(--dsw-alias-label-secondary);font:inherit;text-align:left;border-radius:6px;padding:4px 8px;cursor:pointer;font-size:12px;line-height:18px}
.dsms-item:hover{background:var(--dsw-alias-interactive-bg-hover)}
.dsms-item.on{color:var(--dsw-alias-brand-primary)}
.dsms-item[disabled]{opacity:.5;cursor:default}
.dsms-efforts{display:flex;flex-wrap:wrap;gap:4px;padding:4px 8px 8px;flex:none}
.dsms-effort-btn{border:1px solid var(--dsw-alias-border-l2);background:transparent;color:var(--dsw-alias-label-secondary);border-radius:6px;padding:2px 8px;font-size:11px;line-height:16px;cursor:pointer}
.dsms-effort-btn:hover{border-color:var(--dsw-alias-brand-primary);color:var(--dsw-alias-brand-primary)}
.dsms-effort-btn.on{border-color:var(--dsw-alias-brand-primary);color:var(--dsw-alias-brand-primary);background:var(--dsw-alias-bg-layer-1)}
.dsms-status{color:var(--dsw-alias-label-tertiary);padding:8px;font-size:12px;line-height:18px}
.dsms-error{color:var(--dsw-alias-state-error-primary);padding:6px 8px;font-size:11px;line-height:15px;word-break:break-word;flex:none}
.dsms-divider{height:1px;margin:4px 0;background:var(--dsw-alias-border-l1);flex:none}
`;

    const chevron = (openUp) =>
      h(
        'svg',
        { width: 12, height: 12, viewBox: '0 0 14 14', fill: 'none', 'aria-hidden': true },
        h('path', {
          d: 'M11.8486 5.5L11.4238 5.92383L8.69727 8.65137C8.44157 8.90706 8.21562 9.13382 8.01172 9.29785C7.79912 9.46883 7.55595 9.61756 7.25 9.66602C7.08435 9.69222 6.91565 9.69222 6.75 9.66602C6.44405 9.61756 6.20088 9.46883 5.98828 9.29785C5.78438 9.13382 5.55843 8.90706 5.30273 8.65137L2.57617 5.92383L2.15137 5.5L3 4.65137L3.42383 5.07617L6.15137 7.80273C6.42595 8.07732 6.59876 8.24849 6.74023 8.3623C6.87291 8.46904 6.92272 8.47813 6.9375 8.48047C6.97895 8.48703 7.02105 8.48703 7.0625 8.48047C7.07728 8.47813 7.12709 8.46904 7.25977 8.3623C7.40124 8.24849 7.57405 8.07732 7.84863 7.80273L10.5762 5.07617L11 4.65137L11.8486 5.5Z',
          fill: 'currentColor',
          transform: openUp ? 'rotate(180 7 7)' : undefined,
        }),
      );

    /** 错误边界：内部异常只让本控件隐身，不让槽位退休整条注册。 */
    class SeatBoundary extends React.Component {
      constructor(props) {
        super(props);
        this.state = { failed: false };
      }
      static getDerivedStateFromError() {
        return { failed: true };
      }
      componentDidCatch(err) {
        console.info('[dsms] seat crashed, staying hidden', err);
      }
      render() {
        return this.state.failed ? null : this.props.children;
      }
    }

    return {
      inject: ['slots'],
      apply(ctx) {
        const slots = ctx.slots ?? ctx.get('slots');
        if (!slots) return;

        const localeId = () => {
          try {
            const locale = ctx.get('locale');
            const snap = locale?.getSnapshot?.() ?? locale?.getLocale?.();
            return String(snap?.active ?? snap?.id ?? snap?.locale ?? '');
          } catch {
            return '';
          }
        };
        const strings = () => (/^zh/i.test(localeId()) ? STR.zh : STR.en);

        const styleNode = document.createElement('style');
        styleNode.dataset.plugin = '@k-launcher/dsh-subagent-model-switcher';
        styleNode.textContent = CSS;
        document.head.appendChild(styleNode);
        ctx.effect?.(() => () => styleNode.remove(), 'dsms: styles');

        /** settings Remote 命名空间（官方 settings/describe + settings/mutate 通路）。 */
        const settingsRemote = () => {
          try {
            const viaGet = ctx.get('remote.settings');
            if (viaGet) return viaGet;
          } catch { /* 服务未就绪 */ }
          return ctx.remote?.settings ?? null;
        };

        /** 读取本插件命名空间的 overrides 与 revision。命名空间缺失（Host 半侧未就绪）时返回 entry:false。 */
        const readOverrides = async () => {
          const remote = settingsRemote();
          if (!remote?.describe) return { entry: false, overrides: {}, revision: undefined };
          const res = await remote.describe();
          const value = res?.ok ? res.value : res?.namespaces ? res : undefined;
          if (!value) throw new Error(res?.error?.message ?? 'settings/describe failed');
          const entry = (value.namespaces ?? []).find((row) => row.ns === NS);
          if (!entry) return { entry: false, overrides: {}, revision: undefined };
          const overrides = entry.value?.overrides;
          return {
            entry: true,
            overrides: overrides && typeof overrides === 'object' ? overrides : {},
            revision: entry.revision,
          };
        };

        /**
         * 写入/清除一条覆盖。sel 为 null 时 unset。revision 冲突自动重读重试一次。
         * @returns 成功 true；失败抛错（调用方转成可读提示）。
         */
        const writeOverride = async (sessionId, sel) => {
          const remote = settingsRemote();
          if (!remote?.mutate) throw new Error('remote.settings unavailable');
          let lastError = null;
          for (let attempt = 0; attempt < 2; attempt += 1) {
            const { entry, revision } = await readOverrides();
            if (!entry) {
              const err = new Error('dsms/no-host-entry');
              err.dsmsNoEntry = true;
              throw err;
            }
            const ops =
              sel === null
                ? [{ op: 'unset', path: ['overrides', sessionId] }]
                : [{ op: 'set', path: ['overrides', sessionId], value: sel }];
            const res = await remote.mutate(NS, ops, revision);
            if (res?.ok || (res && typeof res === 'object' && res.ns === NS && !res.error)) return true;
            lastError = new Error(res?.error?.message ?? 'settings/mutate rejected');
            if (!/conflict/i.test(String(res?.error?.code ?? res?.error?.message ?? ''))) break;
          }
          throw lastError ?? new Error('settings/mutate failed');
        };

        const snapshotOf = (dir) => {
          try {
            return dir?.getSnapshot?.() ?? EMPTY_SNAPSHOT;
          } catch {
            return EMPTY_SNAPSHOT;
          }
        };
        const subscribeOf = (dir) => {
          if (!dir?.subscribe) return NOOP_SUBSCRIBE;
          return (fn) => {
            try {
              const un = dir.subscribe(fn);
              return typeof un === 'function' ? un : () => {};
            } catch {
              return () => {};
            }
          };
        };

        /**
         * 子会话模型/强度选择器。
         * 判断依据：useSession(s => s.subagent) —— 与官方 ui-subagent 读同一处 snapshot，
         * 按「本次渲染的会话」判定，绝不依赖注册期 inject 的缓存结果。
         */
        function SubagentModelSeat({ sessionId, useSession }) {
          const t = strings();
          const subagent = useSession((s) => s?.subagent ?? null);

          // 目录服务按渲染期 sessionId 懒取（服务可能晚于首帧就绪）
          const dirRef = useRef(null);
          const [dirTick, setDirTick] = useState(0);
          useEffect(() => {
            let alive = true;
            const tryResolve = () => {
              try {
                const models = ctx.get('modelDirectories');
                const d = models?.directoryFor?.(sessionId);
                if (d) {
                  dirRef.current = d.store ?? d;
                  if (alive) setDirTick((n) => n + 1);
                  return true;
                }
              } catch { /* 服务未就绪 */ }
              return false;
            };
            if (tryResolve()) return () => { alive = false; };
            const timer = window.setTimeout(() => { if (alive) tryResolve(); }, 600);
            return () => { alive = false; window.clearTimeout(timer); };
          }, [sessionId]);

          const directory = dirRef.current;
          const subscribe = useMemo(() => subscribeOf(directory), [directory, dirTick]);
          const getSnapshot = useCallback(() => snapshotOf(directory), [directory, dirTick]);
          const state = useSyncExternalStore(subscribe, getSnapshot);

          const [open, setOpen] = useState(false);
          const [error, setError] = useState(null);
          const [pending, setPending] = useState(false);
          // 用户覆盖：undefined=尚未读取，null=无覆盖（跟随继承），object=覆盖
          const [overrideSel, setOverrideSel] = useState(undefined);
          const rootRef = useRef(null);

          // 目录就绪后拉一次模型清单
          useEffect(() => {
            if (!directory) return;
            try {
              const d = ctx.get('modelDirectories')?.directoryFor?.(sessionId);
              Promise.resolve(d?.load?.()).catch(() => {});
            } catch { /* 忽略 */ }
          }, [directory, sessionId]);

          // 覆盖读取：挂载时一次；打开菜单时刷新（跨窗口/重启后的持久化状态）
          const refreshOverrides = useCallback(() => {
            readOverrides()
              .then(({ overrides }) => {
                const raw = overrides?.[sessionId];
                setOverrideSel(
                  raw && typeof raw.provider === 'string' && typeof raw.model === 'string'
                    ? {
                        provider: raw.provider,
                        model: raw.model,
                        ...(typeof raw.reasoningEffort === 'string' && raw.reasoningEffort
                          ? { reasoningEffort: raw.reasoningEffort }
                          : {}),
                      }
                    : null,
                );
              })
              .catch(() => {});
          }, [sessionId]);
          useEffect(() => {
            refreshOverrides();
          }, [refreshOverrides]);
          useEffect(() => {
            if (open) refreshOverrides();
          }, [open, refreshOverrides]);

          useEffect(() => {
            if (!open) return undefined;
            const closeOutside = (event) => {
              if (!rootRef.current?.contains(event.target)) setOpen(false);
            };
            document.addEventListener('mousedown', closeOutside);
            return () => document.removeEventListener('mousedown', closeOutside);
          }, [open]);

          if (!subagent) return null;   // 主会话：官方选择器在位，本插件完全隐身

          const groups = state?.groups ?? [];
          const current = state?.current ?? null;
          // 当前选择：用户覆盖（本地/持久化）优先，其次目录投影（继承/上次使用）
          const effective = overrideSel ?? current;
          let chosenModel;
          for (const g of groups) {
            const m = (g.models ?? []).find((x) => x.id === effective?.model);
            if (m && g.id === effective?.provider) {
              chosenModel = m;
              break;
            }
          }
          const effectiveEfforts = chosenModel?.reasoning?.efforts ?? [];
          const currentEffort = effective?.reasoningEffort ?? chosenModel?.reasoning?.defaultEffort;
          const effortLabel = effectiveEfforts.find((l) => l.id === currentEffort)?.name ?? currentEffort;
          const modelLabel = chosenModel?.name ?? effective?.model ?? t.pickModel;
          const busy = pending;

          const failText = (e) =>
            e?.dsmsNoEntry ? t.noEntry : t.failed + String(e?.message ?? e);

          const doSelect = (sel) => {
            setError(null);
            setPending(true);
            writeOverride(sessionId, sel).then(
              () => {
                setPending(false);
                setOverrideSel(sel);
                setOpen(false);
              },
              (e) => {
                setPending(false);
                setError(failText(e));
              },
            );
          };

          const doClear = () => {
            setError(null);
            setPending(true);
            writeOverride(sessionId, null).then(
              () => {
                setPending(false);
                setOverrideSel(null);
                setOpen(false);
              },
              (e) => {
                setPending(false);
                setError(failText(e));
              },
            );
          };

          return h(
            'div',
            { className: 'dsms-root', ref: rootRef },
            h(
              'button',
              {
                type: 'button',
                className: 'dsms-trigger',
                'aria-haspopup': 'menu',
                'aria-expanded': open,
                title: modelLabel + (effortLabel ? ' · ' + effortLabel : ''),
                disabled: busy,
                onClick: () => setOpen((v) => !v),
              },
              h('span', { className: 'dsms-label' }, modelLabel),
              effortLabel !== undefined ? h('span', { className: 'dsms-effort' }, String(effortLabel)) : null,
              chevron(open),
            ),
            open
              ? h(
                  'div',
                  { className: 'dsms-menu', role: 'menu' },
                  h('div', { className: 'dsms-section' }, t.pickModel),
                  h(
                    'div',
                    { className: 'dsms-list' },
                    // 清除覆盖：回到继承/描述符路由
                    h(
                      'button',
                      {
                        type: 'button',
                        className: 'dsms-item' + (overrideSel ? '' : ' on'),
                        disabled: busy || !overrideSel,
                        onClick: () => {
                          if (!overrideSel) return;
                          doClear();
                        },
                      },
                      h('span', { className: 'dsms-label' }, t.auto),
                    ),
                    h('div', { className: 'dsms-divider' }),
                    state?.status === 'loading' && groups.length === 0
                      ? h('div', { className: 'dsms-status' }, t.loading)
                      : groups.length === 0
                        ? h('div', { className: 'dsms-status' }, state?.error || t.noModels)
                        : groups.map((g) => [
                            h('div', { key: g.id + ':h', className: 'dsms-section' }, g.name ?? g.id),
                            ...(g.models ?? []).map((m) =>
                              h(
                                'button',
                                {
                                  key: g.id + '/' + m.id,
                                  type: 'button',
                                  className:
                                    'dsms-item' +
                                    (overrideSel && overrideSel.provider === g.id && overrideSel.model === m.id
                                      ? ' on'
                                      : ''),
                                  disabled: busy,
                                  onClick: () => {
                                    if (
                                      overrideSel &&
                                      overrideSel.provider === g.id &&
                                      overrideSel.model === m.id
                                    ) {
                                      setOpen(false);
                                      return;
                                    }
                                    doSelect({
                                      provider: g.id,
                                      model: m.id,
                                      ...(m.reasoning?.defaultEffort === void 0
                                        ? {}
                                        : { reasoningEffort: m.reasoning.defaultEffort }),
                                    });
                                  },
                                },
                                h('span', { className: 'dsms-label' }, m.name ?? m.id),
                              ),
                            ),
                          ]),
                  ),
                  effectiveEfforts.length > 0
                    ? [
                        h('div', { key: 'div', className: 'dsms-divider' }),
                        h('div', { key: 'eh', className: 'dsms-section' }, t.effort),
                        h(
                          'div',
                          { key: 'el', className: 'dsms-efforts' },
                          effectiveEfforts.map((lv) =>
                            h(
                              'button',
                              {
                                key: lv.id,
                                type: 'button',
                                className: 'dsms-effort-btn' + (lv.id === currentEffort ? ' on' : ''),
                                disabled: busy || !effective,
                                title: lv.description ?? lv.id,
                                onClick: () => {
                                  if (!effective || lv.id === currentEffort) return;
                                  doSelect({
                                    provider: effective.provider,
                                    model: effective.model,
                                    reasoningEffort: lv.id,
                                  });
                                },
                              },
                              lv.name ?? lv.id,
                            ),
                          ),
                        ),
                      ]
                    : null,
                  error ? h('div', { className: 'dsms-error' }, error) : null,
                )
              : null,
          );
        }

        function Seat(props) {
          return h(SeatBoundary, null, h(SubagentModelSeat, props));
        }

        // conversation.input.right：list 槽（提交按钮左侧），纯添加。
        // 不声明 inject：会话判定完全交给组件内的 useSession（见文件头注释）。
        slots.inject('conversation.input.right', () =>
          slots.register(
            { name: 'conversation.input.right', id: 'dsh-subagent-model-switcher', order: 10 },
            Seat,
          ),
        );
      },
    };
  },
});
