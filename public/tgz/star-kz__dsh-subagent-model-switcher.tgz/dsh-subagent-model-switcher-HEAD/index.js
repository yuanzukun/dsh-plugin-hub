/**
 * dsh-subagent-model-switcher — Host 半侧。
 *
 * 目标：让「子 agent 会话」随时可切换模型与思考强度，无论子 agent
 * 正在运行、空闲还是尚未物化（冷会话）。主会话与其他 agent 的行为完全不变。
 *
 * 设计（全部有据可查）：
 *  - 官方 `session/selectModel` 对子会话一律拒绝（session/agent-busy,
 *    "owned by subagent routing"），所以本插件走自己的通道：
 *    插件 Config 的 volatile 字段 `overrides`（settings 命名空间 =
 *    patch 条目 id `dsh-subagent-model-switcher`）。Client 通过官方
 *    `settings/mutate` Remote 写入；volatile 字段热更新、不重启插件，
 *    且持久化在 profile patch 里，重启后对冷会话同样生效。
 *  - 生效点：dsh-scope 的作用域分发「不过滤未打标签的监听器」
 *    （scopeTarget 的 carrier filter：untagged listener 全局接收），
 *    所以在根 ctx 上监听 agent 级瀑布事件即可覆盖每一个子 agent：
 *      · system-prompt/assemble —— context.agent 标识 agent；
 *        有覆盖时把 {{provider}}/{{model}} 变量指向用户选择，并为本次装配
 *        固定快照（WeakMap），与官方 installModelSelection 的
 *        assembled 耦合语义一致；
 *      · agent/request —— payload.agent 标识 agent；用装配快照替换
 *        resolved config 的 provider/model/reasoningEffort（官方同款：
 *        未指定 effort 时清掉继承 effort，回到所选模型默认；但若路由未变
 *        且未指定 effort 则原样放行，不动子 agent 的描述符继承）；
 *      · agent/pre-step —— 路由变化时向下一请求注入官方同款
 *        `[model changed: …]` user 通知（prepend，读最终 decision）。
 *  - 三个监听器都以 `origin === 'subagent'` 严格过滤；无覆盖时原样
 *    透传 next() 的结果，主会话/ACP/未覆盖的子 agent 零影响。
 *
 * 依赖说明：Config 必须是 schemastery schema（settings 体系只认它）。
 * 链接安装的插件无法向上解析 @deepseek-ai/*，因此插件目录内置
 * node_modules/@deepseek-ai/schemastery 交界（junction）指向宿主
 * 正在使用的同一份 schemastery —— realpath 相同，模块实例与
 * dsh-settings 的 instanceof/toJSON 检查兼容。junction 缺失时
 * Config 退化为 undefined，Host 半侧自动停用，Client 会显示可读错误。
 */
import { randomUUID } from 'node:crypto';

let z;
try {
  z = (await import('@deepseek-ai/schemastery')).default;
} catch {
  z = undefined;
}

const OverrideRoute = z
  ? z.object({
      provider: z.string().min(1).required(),
      model: z.string().min(1).required(),
      reasoningEffort: z.string().min(1),
    })
  : undefined;

/** @type {import('@deepseek-ai/schemastery') | undefined} */
export const Config =
  z && OverrideRoute
    ? z.object({
        overrides: z.dict(OverrideRoute).default({}).volatile(),
      })
    : undefined;

export const name = 'dsh-subagent-model-switcher';

const NOTICE_SUMMARY_MAX = 120;

export function apply(ctx, config) {
  const readOverrides = () => {
    try {
      const cell = config?.overrides;
      const value = cell && typeof cell.get === 'function' ? cell.get() : cell;
      return value && typeof value === 'object' ? value : {};
    } catch {
      return {};
    }
  };

  const overrideFor = (agent) => {
    try {
      const header = agent?.session?.header;
      if (!header || header.origin !== 'subagent') return undefined;
      const raw = readOverrides()[header.id];
      if (
        !raw ||
        typeof raw.provider !== 'string' ||
        typeof raw.model !== 'string' ||
        raw.provider.length === 0 ||
        raw.model.length === 0
      ) {
        return undefined;
      }
      const selection = { provider: raw.provider, model: raw.model };
      if (typeof raw.reasoningEffort === 'string' && raw.reasoningEffort.length > 0) {
        selection.reasoningEffort = raw.reasoningEffort;
      }
      return selection;
    } catch {
      return undefined;
    }
  };

  // agent -> 本次装配采用的选择快照（装配与请求必须同源，避免并发切换劈裂两个面）
  const assembled = new WeakMap();

  ctx.on('system-prompt/assemble', async (_assembly, context, next) => {
    const agent = context?.agent;
    const selected = agent ? overrideFor(agent) : undefined;
    if (!agent || !selected) return next();
    const result = await next();
    assembled.set(agent, selected);
    return {
      ...result,
      variables: { ...result.variables, provider: selected.provider, model: selected.model },
    };
  });

  ctx.on('agent/request', async (payload, next) => {
    const resolved = await next();
    try {
      const agent = payload?.agent;
      if (!agent) return resolved;
      const selected = assembled.get(agent) ?? overrideFor(agent);
      if (!selected) return resolved;
      // 路由未变且未指定 effort：原样放行（保留子 agent 描述符继承的 effort）
      if (
        selected.provider === resolved.provider &&
        selected.model === resolved.model &&
        selected.reasoningEffort === undefined
      ) {
        return resolved;
      }
      const { reasoningEffort: _inherited, ...rest } = resolved;
      return {
        ...rest,
        provider: selected.provider,
        model: selected.model,
        ...(selected.reasoningEffort === undefined
          ? {}
          : { reasoningEffort: selected.reasoningEffort }),
      };
    } catch {
      return resolved;
    }
  });

  ctx.on(
    'agent/pre-step',
    async (payload, next) => {
      const decision = await next();
      try {
        const { agent, messages, signal, step } = payload ?? {};
        if (!agent || signal?.aborted || decision?.kind === 'reject') return decision;
        if (!Array.isArray(decision?.messages)) return decision;
        if (decision.messages.length === 0 && (step === 1 || (messages?.length ?? 0) > 0)) {
          return decision;
        }
        const selected = assembled.get(agent);
        const previous = agent.session.requestHeader()?.config;
        if (!selected || !previous) return decision;
        if (selected.provider === previous.provider && selected.model === previous.model) {
          return decision;
        }
        const from =
          previous.provider === selected.provider
            ? previous.model
            : `${previous.provider}/${previous.model}`;
        const to =
          selected.provider === previous.provider
            ? selected.model
            : `${selected.provider}/${selected.model}`;
        const summary = `${from} → ${to}`;
        const notice = {
          role: 'user',
          id: randomUUID(),
          content: [
            {
              type: 'text',
              text: `[model changed: assistant turns above this point were generated by ${from}; the session continues with ${to}]`,
            },
          ],
          source: {
            kind: 'model-selection',
            form: 'notice',
            summary:
              summary.length <= NOTICE_SUMMARY_MAX
                ? summary
                : `${summary.slice(0, NOTICE_SUMMARY_MAX - 1)}…`,
          },
        };
        return { ...decision, messages: [...decision.messages, notice] };
      } catch {
        return decision;
      }
    },
    { prepend: true },
  );
}
