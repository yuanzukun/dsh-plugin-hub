# Third-party notices

## CapsPulse

`native/led.c` is adapted from CapsPulse (MIT License, Copyright (c) 2026
ssk090), which demonstrates writing the MacBook Caps Lock LED through
macOS IOKit/IOHID output elements.

## Mac-Agent-Beacon

`native/led.c` carries further adaptations from Mac-Agent-Beacon (MIT
License, Copyright (c) 2026 rynzh), notably the stdin command protocol
(`1`/`0`/`r`/`q`) and the logical-Caps-Lock safety checks.
