/* Behavioral test: apply() with a fake ctx, kill the helper, verify revival. */
import { apply } from './index.mjs'
import { execSync } from 'node:child_process'

const listeners = new Map()
let disposer = null
const ctx = {
  logger: { info: (...a) => console.log('[info]', ...a), warn: (...a) => console.log('[warn]', ...a) },
  on: (event, fn) => {
    if (!listeners.has(event)) listeners.set(event, [])
    listeners.get(event).push(fn)
    return () => listeners.get(event)?.splice(listeners.get(event).indexOf(fn), 1)
  },
  effect: (body) => { disposer = body(); },
  get: () => null,
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const helperPids = () => {
  try { return execSync('pgrep -f "beacon-led serve"').toString().trim().split('\n').filter(Boolean) }
  catch { return [] }
}

apply(ctx, {})
await sleep(1500)
let pids = helperPids()
console.log('after start:', pids.length === 1 ? 'PASS (1 helper)' : `FAIL (${pids.length})`)
if (pids.length !== 1) process.exit(1)

// Simulate environmental death.
process.kill(Number(pids[0]), 'SIGKILL')
console.log('killed helper', pids[0])
await sleep(400)
console.log('after kill:', helperPids().length === 0 ? 'PASS (dead)' : 'FAIL (still alive)')

// Backoff is 1s for the first failure; wait past it.
await sleep(2500)
pids = helperPids()
console.log('after revival window:', pids.length === 1 ? 'PASS (revived)' : `FAIL (${pids.length})`)

// Dispose must stop the helper.
disposer()
await sleep(500)
const afterDispose = helperPids()
console.log('after dispose:', afterDispose.length === 0 ? 'PASS (clean)' : `FAIL (${afterDispose.length})`)
process.exit(pids.length === 1 && afterDispose.length === 0 ? 0 : 1)
