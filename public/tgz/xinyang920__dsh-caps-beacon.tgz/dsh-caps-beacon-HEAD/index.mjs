/**
 * dsh-caps-beacon — Caps Lock LED status beacon for DeepSeek Harness.
 *
 * A pure observer: it maps host agent state onto the MacBook Caps Lock LED
 * through the bundled `beacon-led` helper and never decides anything.
 *
 *   solid   — at least one root agent is running
 *   blinking— an approval or blocking question is pending, or a root turn
 *             ended in error/blocked (latched until the next turn starts)
 *   off     — idle
 *
 * The `approval/request` and `tools/execute` listeners always delegate
 * through `next()`, so the approval and tool chains behave exactly as if
 * this plugin were not installed.
 *
 * The helper can die for environmental reasons (system sleep resetting the
 * HID device, a stray signal reaching its process group). The controller
 * therefore restarts it with exponential backoff and re-applies the current
 * mode after every restart, so the beacon self-heals instead of going dark
 * until the next dsh restart.
 */
import { spawn } from 'node:child_process'
import { existsSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

export const name = 'dsh-caps-beacon'
export const inject = []

const PLUGIN_DIR = dirname(fileURLToPath(import.meta.url))
const BLOCKING_TOOLS = new Set(['ask_user_question', 'exit_plan_mode'])
const READY_TIMEOUT_MS = 3000
const QUIT_TIMEOUT_MS = 1500
/** Uptime after which the backoff failure count resets. */
const STABLE_UPTIME_MS = 60000
/** Restart delay: 1s doubling up to this cap. */
const MAX_RESTART_DELAY_MS = 30000

const DEFAULTS = {
  enabled: true,
  /** Absolute path to the beacon-led helper; empty resolves beside the plugin. */
  ledPath: '',
  blinkIntervalMs: 250,
  /** Only react to root agents; subagent fan-out stays silent. */
  rootsOnly: true,
  triggers: { approval: true, question: true, error: true },
  verbose: false,
}

function normalizeConfig(raw) {
  const cfg = raw === true || raw === undefined || raw === null ? {} : raw
  const triggers = { ...DEFAULTS.triggers, ...(cfg.triggers ?? {}) }
  return { ...DEFAULTS, ...cfg, triggers }
}

/**
 * One `beacon-led serve` child driven through its stdin, revived with
 * exponential backoff whenever it dies without being stopped.
 */
class LedController {
  constructor(binPath, log) {
    this.binPath = binPath
    this.log = log
    this.proc = undefined
    this.startPromise = undefined
    this.restartTimer = null
    this.failures = 0
    this.startedAt = 0
    this.missing = false
    this.stopping = false
    /** Called after every successful (re)start; re-applies the LED mode. */
    this.onReady = null
  }

  /** Spawn the helper once; resolves when it reports ready or dies first. */
  start() {
    if (this.stopping || this.missing || this.restartTimer) return Promise.resolve()
    if (this.startPromise) return this.startPromise
    if (!existsSync(this.binPath)) {
      this.missing = true
      this.log(`helper not found at ${this.binPath} — run "make" in the plugin directory; LED stays unused`)
      return Promise.resolve()
    }
    this.startedAt = Date.now()
    this.startPromise = new Promise((settled) => {
      let ready = false
      const proc = spawn(this.binPath, ['serve'], { stdio: ['pipe', 'pipe', 'pipe'] })
      this.proc = proc
      proc.stdout.on('data', (chunk) => {
        if (!ready && String(chunk).includes('ready')) {
          ready = true
          if (this.failures > 0) this.log('helper restarted after failure')
          if (this.onReady) this.onReady()
          settled()
        }
      })
      proc.stderr.on('data', (chunk) => this.log(`helper: ${String(chunk).trim()}`))
      // EPIPE after helper death must not crash the host.
      proc.stdin.on('error', () => {})
      const finish = () => {
        this.proc = undefined
        this.startPromise = undefined
        if (!ready) settled()
        if (!this.stopping) this.scheduleRestart()
      }
      proc.on('error', (error) => {
        this.log(`helper failed to start: ${String(error)}`)
        finish()
      })
      proc.on('exit', (code) => {
        if (!this.stopping) this.log(`helper exited (code ${String(code)})`)
        finish()
      })
      const timer = setTimeout(() => {
        if (!ready && !this.stopping && this.proc === proc) {
          this.log('helper did not report ready in time; killing it')
          proc.kill()
        }
      }, READY_TIMEOUT_MS)
      timer.unref?.()
    })
    return this.startPromise
  }

  /** Backoff-schedule a restart after an unexpected exit or spawn failure. */
  scheduleRestart() {
    if (this.stopping || this.restartTimer || this.missing) return
    if (Date.now() - this.startedAt > STABLE_UPTIME_MS) this.failures = 0
    const delay = Math.min(1000 * 2 ** Math.min(this.failures, 5), MAX_RESTART_DELAY_MS)
    this.failures += 1
    this.log(`restarting helper in ${delay}ms (attempt ${this.failures})`)
    this.restartTimer = setTimeout(() => {
      this.restartTimer = null
      void this.start()
    }, delay)
    this.restartTimer.unref?.()
  }

  write(command) {
    if (!this.proc || this.stopping) return
    try { this.proc.stdin.write(command) } catch { /* exit handler owns revival */ }
  }

  async stop() {
    this.stopping = true
    if (this.restartTimer) { clearTimeout(this.restartTimer); this.restartTimer = null }
    try { await this.startPromise } catch { /* start logs its own failures */ }
    const proc = this.proc
    this.proc = undefined
    if (!proc || proc.exitCode !== null) return
    await new Promise((settled) => {
      proc.once('exit', settled)
      try { proc.stdin.write('q') } catch { proc.kill() }
      const timer = setTimeout(() => { proc.kill(); settled() }, QUIT_TIMEOUT_MS)
      timer.unref?.()
    })
  }
}

export function apply(ctx, rawConfig) {
  const cfg = normalizeConfig(rawConfig)
  if (!cfg.enabled) return
  const log = (message) => ctx.logger.info(`[dsh-caps-beacon] ${message}`)
  const warn = (message) => ctx.logger.warn(`[dsh-caps-beacon] ${message}`)
  const binPath = cfg.ledPath ? resolve(cfg.ledPath) : resolve(PLUGIN_DIR, 'build/beacon-led')
  const led = new LedController(binPath, warn)

  let attention = 0
  let errorLatch = false
  const running = new Set()
  let mode = 'off'
  let blinkOn = false
  let blinkTimer = null

  const isRootAgent = (agent) => {
    if (!cfg.rootsOnly) return true
    const agents = ctx.get('agents')
    if (!agents) return true
    try { return agents.roots().includes(agent) } catch { return true }
  }
  const isRootSession = (session) => {
    if (!cfg.rootsOnly) return true
    const agents = ctx.get('agents')
    if (!agents) return true
    try { return agents.roots().some((agent) => agent.session === session) } catch { return true }
  }

  const desired = () => (attention > 0 || errorLatch ? 'blink' : running.size > 0 ? 'solid' : 'off')

  function reconcile() {
    const next = desired()
    if (next === mode) return
    mode = next
    if (blinkTimer) { clearInterval(blinkTimer); blinkTimer = null }
    if (next === 'blink') {
      blinkOn = true
      led.write('1')
      blinkTimer = setInterval(() => {
        blinkOn = !blinkOn
        led.write(blinkOn ? '1' : '0')
      }, cfg.blinkIntervalMs)
    } else {
      led.write(next === 'solid' ? '1' : '0')
    }
    if (cfg.verbose) log(`mode -> ${next}`)
  }

  // A revived helper starts with the LED in an unknown physical state, so
  // force a full re-application of the current mode.
  led.onReady = () => {
    mode = undefined
    reconcile()
    if (cfg.verbose) log('beacon-led ready — Caps Lock LED armed')
  }

  ctx.on('agent/status', ({ agent, status }) => {
    if (!isRootAgent(agent)) return
    if (status === 'running') running.add(agent)
    else running.delete(agent)
    reconcile()
  })

  if (cfg.triggers.approval) {
    ctx.on('approval/request', async (req, next) => {
      if (!isRootAgent(req.agent)) return next()
      attention += 1
      reconcile()
      try { return await next() } finally { attention -= 1; reconcile() }
    })
  }

  if (cfg.triggers.question) {
    ctx.on('tools/execute', async (exec, next) => {
      if (!BLOCKING_TOOLS.has(exec.name) || !isRootAgent(exec.agent)) return next()
      attention += 1
      reconcile()
      try { return await next() } finally { attention -= 1; reconcile() }
    })
  }

  ctx.on('session/event', (session, event) => {
    if (event.type === 'turn/start') {
      if (errorLatch && isRootSession(session)) { errorLatch = false; reconcile() }
    } else if (event.type === 'turn/end') {
      const kind = event.data?.reason?.kind
      if ((kind === 'error' || kind === 'blocked') && cfg.triggers.error && isRootSession(session)) {
        errorLatch = true
        reconcile()
      }
    }
  })

  ctx.effect(() => {
    void led.start()
    return () => {
      if (blinkTimer) clearInterval(blinkTimer)
      void led.stop()
    }
  })
}
