import type { ContextLensAttemptDetail, ValueFingerprint, ValueMetrics } from '../shared/contract.ts';
export type ContextSourceGroup = 'system' | 'context' | 'messages' | 'tools' | 'config';
/** One selectable piece of the exact reconstructed model request. */
export interface ContextSourceNode {
    readonly id: string;
    readonly group: ContextSourceGroup;
    readonly label: string;
    readonly secondary?: string;
    readonly raw: string;
    /** False when the current Session window retained metadata but not raw text. */
    readonly rawAvailable: boolean;
    readonly value: unknown;
    readonly metrics: ValueMetrics;
    readonly fingerprint?: ValueFingerprint;
    readonly span?: {
        readonly start: number;
        readonly end: number;
    };
    readonly searchText: string;
}
/** Stable readable JSON, retaining strings as their exact raw text. */
export declare function sourceRaw(value: unknown): string;
/** Exact browser-side sizes plus the same clearly labelled token heuristic. */
export declare function measureSource(value: unknown, charsPerEstimatedToken: number): ValueMetrics;
/** Build the five ordered source groups from an exact request reconstruction. */
export declare function buildContextSources(detail: ContextLensAttemptDetail): readonly ContextSourceNode[];
/** Find the semantically corresponding source in the previous attempt. */
export declare function previousSource(current: ContextSourceNode, previous: readonly ContextSourceNode[]): ContextSourceNode | undefined;
//# sourceMappingURL=source-model.d.ts.map