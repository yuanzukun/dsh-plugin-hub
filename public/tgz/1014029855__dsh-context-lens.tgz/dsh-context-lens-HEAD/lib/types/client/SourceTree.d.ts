import type { ReactNode } from 'react';
import type { ContextSourceNode } from './source-model.ts';
import type { ContextLensTranslate } from './view-types.ts';
interface SourceTreeProps {
    readonly sources: readonly ContextSourceNode[];
    readonly selectedId: string | undefined;
    readonly query: string;
    readonly onSelect: (id: string) => void;
    readonly t: ContextLensTranslate;
}
/** Five-group request source navigator. */
export declare function SourceTree({ sources, selectedId, query, onSelect, t }: SourceTreeProps): ReactNode;
export {};
//# sourceMappingURL=SourceTree.d.ts.map