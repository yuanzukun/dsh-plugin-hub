import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** Required browser services for the session view contribution. */
export declare const inject: string[];
/** Register Context Lens replay signals and the session-scoped view tab. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map