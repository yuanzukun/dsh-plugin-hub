export interface ContextDiffLine {
    readonly kind: 'same' | 'added' | 'removed';
    readonly text: string;
}
/** Exact line diff used by the inspector's previous-attempt mode. */
export declare function contextDiff(previous: string, current: string): readonly ContextDiffLine[];
//# sourceMappingURL=diff-model.d.ts.map