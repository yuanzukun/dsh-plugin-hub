import type { ConversationNodeContext, ConversationNodeDefinition, ConversationViewBuilder, ConversationViewDefinition, ConversationViewNode } from '@deepseek-ai/dsh-client-runtime/client';
interface RevisionState {
    readonly seq: number;
    readonly type: string;
}
interface ContextLensRevisionNode extends ConversationViewNode {
    readonly target: 'context-lens';
    readonly anchorSeq: number;
    readonly eventType: string;
}
/** Small replay-derived signal used only to refresh Host-owned lens data. */
export interface ContextLensRevisionSnapshot {
    readonly revision: number;
    readonly firstSeq: number | null;
    readonly lastSeq: number | null;
}
declare module '@deepseek-ai/dsh-client-runtime/client' {
    interface ConversationViewSnapshotMap {
        /** Revision signal for the Context Lens Host-side attempt ledger. */
        'context-lens': ContextLensRevisionSnapshot;
    }
}
export declare const EMPTY_CONTEXT_LENS_REVISION: ContextLensRevisionSnapshot;
/** Definition that projects only low-frequency request lifecycle anchors. */
export declare const contextLensRevisionDefinition: ConversationNodeDefinition<RevisionState>;
/** Incremental builder retaining only event anchors, never prompt content. */
export declare class ContextLensRevisionBuilder implements ConversationViewBuilder<ContextLensRevisionNode, ContextLensRevisionSnapshot> {
    readonly empty: ContextLensRevisionSnapshot;
    private readonly nodes;
    private snapshot;
    replace(input: {
        readonly nodes: readonly ContextLensRevisionNode[];
    }): ContextLensRevisionSnapshot;
    apply(input: {
        readonly upserts: readonly ContextLensRevisionNode[];
    }): ContextLensRevisionSnapshot;
    private rebuild;
}
/** Session-local snapshot builder registered under the lens view target. */
export declare const contextLensViewDefinition: ConversationViewDefinition<ContextLensRevisionNode, ContextLensRevisionSnapshot>;
/** Build a node directly in focused tests. */
export declare function revisionNode(context: ConversationNodeContext<RevisionState>): ContextLensRevisionNode | null;
export {};
//# sourceMappingURL=conversation-revision.d.ts.map