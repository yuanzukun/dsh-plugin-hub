import type { ReactNode } from 'react';
import type { ContextLensAttempt, ContextLensAttemptDetail } from '../shared/contract.ts';
import type { ContextSourceNode } from './source-model.ts';
import type { ContextLensTranslate } from './view-types.ts';
interface BudgetSummaryProps {
    readonly attempt: ContextLensAttempt;
    readonly detail: ContextLensAttemptDetail | undefined;
    readonly sources: readonly ContextSourceNode[];
    readonly t: ContextLensTranslate;
}
/** Exact byte/unit budget and explicitly heuristic token density. */
export declare function BudgetSummary({ attempt, detail, sources, t }: BudgetSummaryProps): ReactNode;
export {};
//# sourceMappingURL=BudgetSummary.d.ts.map