/** Simplified Chinese product copy. */
export declare const zh: {
    readonly 'view.context': "上下文";
    readonly 'toolbar.aria': "上下文透镜工具栏";
    readonly 'toolbar.search': "搜索上下文";
    readonly 'toolbar.searchPlaceholder': "搜索来源、模型或内容";
    readonly 'toolbar.refresh': "刷新";
    readonly 'toolbar.export': "导出诊断 JSON";
    readonly 'history.partialTitle': "当前会话窗口不完整";
    readonly 'history.partialBody': "捕获记录来自主机；加载更早会话历史仅用于与完整聊天时间线核对，不会改变已重建的请求详情。";
    readonly 'history.loadAll': "加载完整会话历史";
    readonly 'history.loading': "正在加载历史…";
    readonly 'state.loading': "正在读取捕获记录…";
    readonly 'state.emptyTitle': "还没有捕获到模型请求";
    readonly 'state.emptyBody': "发送一条消息后，这里会显示最终系统提示、消息、工具与配置。";
    readonly 'state.error': "无法读取上下文记录。";
    readonly 'state.retry': "重试";
    readonly 'error.network': "主机接口暂时不可用。";
    readonly 'error.not-found': "这条捕获记录已不存在。";
    readonly 'error.invalid-response': "主机返回了不兼容的数据。";
    readonly 'error.unknown': "发生了未知错误。";
    readonly 'attempts.title': "请求尝试";
    readonly 'attempts.count': "{count} 次";
    readonly 'attempts.noMatch': "没有匹配的请求";
    readonly 'attempts.turnStep': "轮次 {turn} · 步骤 {step}";
    readonly 'attempts.attempt': "尝试 {attempt}";
    readonly 'attempts.latest': "最新";
    readonly 'attempts.capturedAt': "捕获于 {time}";
    readonly 'attempts.seq': "日志序列 {seq}";
    readonly 'metrics.title': "请求预算";
    readonly 'metrics.estimated': "token 为固定密度估算，不是模型 tokenizer 的精确计数。";
    readonly 'metrics.tokens': "估算 token";
    readonly 'metrics.bytes': "UTF-8 字节";
    readonly 'metrics.codeUnits': "UTF-16 单元";
    readonly 'metrics.codePoints': "代码点";
    readonly 'metrics.jsonBytes': "JSON 字节";
    readonly 'metrics.system': "系统提示";
    readonly 'metrics.context': "运行时上下文";
    readonly 'metrics.messages': "消息";
    readonly 'metrics.tools': "工具";
    readonly 'metrics.config': "配置";
    readonly 'tree.title': "来源";
    readonly 'tree.noMatch': "没有匹配的来源";
    readonly 'tree.system': "系统提示";
    readonly 'tree.context': "运行时上下文";
    readonly 'tree.messages': "消息";
    readonly 'tree.tools': "工具";
    readonly 'tree.config': "配置";
    readonly 'tree.unattributed': "未归因的最终系统提示";
    readonly 'tree.named': "命名片段";
    readonly 'tree.message': "消息 #{index} · {role}";
    readonly 'tree.tool': "工具 #{index} · {name}";
    readonly 'tree.contextItem': "上下文 #{index} · {name}";
    readonly 'tree.configItem': "配置 · {name}";
    readonly 'tree.unknownRole': "未知角色";
    readonly 'tree.provenance': "来源：{source}";
    readonly 'tree.metadataOnly': "仅元数据（原文不可用）";
    readonly 'inspector.title': "检查器";
    readonly 'inspector.raw': "原文";
    readonly 'inspector.diff': "与上次比较";
    readonly 'inspector.json': "JSON";
    readonly 'inspector.copy': "复制";
    readonly 'inspector.copied': "已复制";
    readonly 'inspector.noSelection': "选择一个来源查看内容。";
    readonly 'inspector.rawUnavailable': "此捕获没有可重建的原文；这里只保留了 HMAC 指纹与尺寸元数据。";
    readonly 'inspector.diffUnavailable': "无法生成文本差异：至少一侧只有元数据，没有可比较的原文。";
    readonly 'inspector.loading': "正在重建精确请求…";
    readonly 'inspector.noPrevious': "这是第一条尝试，没有可比较的前序请求。";
    readonly 'inspector.unchanged': "与上一条尝试相同。";
    readonly 'inspector.added': "新增";
    readonly 'inspector.removed': "删除";
    readonly 'inspector.hmac': "HMAC 指纹";
    readonly 'inspector.span': "系统提示范围 [{start}, {end})";
    readonly 'health.markerProof': "官方标记已验证";
    readonly 'health.sessionStructureProof': "Session 结构已严格验证";
    readonly 'health.assemblyCaptured': "已捕获命名装配";
    readonly 'health.assemblyUnavailable': "命名装配不可用";
    readonly 'health.messageExact': "消息映射精确";
    readonly 'health.messageMismatch': "消息映射不完整";
    readonly 'health.persisted': "元数据已持久化";
    readonly 'health.notPersisted': "元数据未持久化";
    readonly 'health.reconstructionComplete': "请求已完整重建";
    readonly 'health.reconstructionPartial': "请求重建不完整";
    readonly 'diff.changed': "已变化";
    readonly 'diff.unchanged': "未变化";
    readonly 'diff.summary': "相较前一次尝试";
};
export type ContextLensLocaleKey = keyof typeof zh;
/** English product copy with the same complete key set. */
export declare const en: Record<ContextLensLocaleKey, string>;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Context Lens request inspection and diagnostics. */
        'context-lens': ContextLensLocaleKey;
    }
}
/** Dictionary namespace owned by this plugin. */
export declare const NS = "context-lens";
//# sourceMappingURL=locales.d.ts.map