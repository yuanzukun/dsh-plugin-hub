import type { ReactNode } from 'react';
import type { ContextLensAttempt } from '../shared/contract.ts';
import type { ContextLensTranslate } from './view-types.ts';
interface AttemptRailProps {
    readonly attempts: readonly ContextLensAttempt[];
    readonly selectedId: string | undefined;
    readonly query: string;
    readonly onSelect: (id: string) => void;
    readonly t: ContextLensTranslate;
}
/** Ordered rail of every provider-neutral dispatch attempt. */
export declare function AttemptRail({ attempts, selectedId, query, onSelect, t }: AttemptRailProps): ReactNode;
export {};
//# sourceMappingURL=AttemptRail.d.ts.map