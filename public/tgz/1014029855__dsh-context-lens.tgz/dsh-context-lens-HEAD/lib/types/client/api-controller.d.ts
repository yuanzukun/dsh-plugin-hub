import type { ContextLensAttempt, ContextLensAttemptDetail } from '../shared/contract.ts';
/** User-presentable failure categories; transport details stay out of the UI. */
export type ContextLensErrorCode = 'network' | 'not-found' | 'invalid-response' | 'unknown';
/** Immutable per-session Host API snapshot. */
export interface ContextLensClientSnapshot {
    readonly status: 'idle' | 'loading' | 'ready' | 'error';
    readonly error: ContextLensErrorCode | null;
    readonly attempts: readonly ContextLensAttempt[];
    readonly details: Readonly<Record<string, ContextLensAttemptDetail>>;
    readonly detailLoading: readonly string[];
    readonly detailErrors: Readonly<Record<string, ContextLensErrorCode>>;
    readonly refreshedAt: number | null;
}
interface RevisionSource {
    getSnapshot(): {
        readonly views: {
            get(key: string): unknown;
        };
    };
    subscribe(listener: () => void): () => void;
}
type FetchLike = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
/**
 * Bare observable owning all Host reads for one Session. React receives only
 * the framework-bound selector hook over this object.
 */
export declare class ContextLensSessionController {
    readonly sessionId: string;
    private readonly fetcher;
    private snapshot;
    private readonly listeners;
    private readonly requests;
    private readonly aborts;
    private readonly stopRevision;
    private refreshPromise;
    private refreshRequested;
    private refreshQueued;
    private revision;
    private disposed;
    constructor(sessionId: string, source: RevisionSource, fetcher?: FetchLike);
    /** Current stable snapshot. */
    readonly getSnapshot: () => ContextLensClientSnapshot;
    /** Subscribe to immutable snapshot replacement. */
    readonly subscribe: (listener: () => void) => (() => void);
    private publish;
    private scheduleRefresh;
    private fetchJson;
    private readAttempts;
    private drainRefreshes;
    /** Re-read retained attempt metadata and eagerly hydrate the newest pair. */
    refresh(): Promise<void>;
    /** Hydrate one exact request and, when requested, its predecessor for diff. */
    loadAttempt(id: string, includePrevious?: boolean): Promise<void>;
    private loadPrevious;
    /** Stop timers and subscriptions when the plugin Fiber leaves. */
    dispose(): void;
}
/** Apply-world cache preserving one observable identity per live Session source. */
export declare class ContextLensControllerRegistry {
    private readonly fetcher?;
    private readonly controllers;
    constructor(fetcher?: FetchLike | undefined);
    /** Return the stable controller associated with one live Session instance. */
    get(sessionId: string, source: RevisionSource): ContextLensSessionController;
    /** Dispose every per-Session source on plugin teardown. */
    dispose(): void;
}
/** Same-origin diagnostic export URL for a Session. */
export declare function contextLensExportUrl(sessionId: string): string;
export {};
//# sourceMappingURL=api-controller.d.ts.map