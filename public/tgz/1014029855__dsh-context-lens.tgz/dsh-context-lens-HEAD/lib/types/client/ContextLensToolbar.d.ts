import type { ReactNode } from 'react';
import type { ContextLensTranslate } from './view-types.ts';
interface ContextLensToolbarProps {
    readonly query: string;
    readonly onQueryChange: (value: string) => void;
    readonly onRefresh: () => void;
    readonly exportUrl: string;
    readonly t: ContextLensTranslate;
}
/** Compact command strip for search, refresh, and safe JSON export. */
export declare function ContextLensToolbar({ query, onQueryChange, onRefresh, exportUrl, t, }: ContextLensToolbarProps): ReactNode;
export {};
//# sourceMappingURL=ContextLensToolbar.d.ts.map