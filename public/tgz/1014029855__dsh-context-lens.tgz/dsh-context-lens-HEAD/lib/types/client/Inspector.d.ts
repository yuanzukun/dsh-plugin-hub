import type { ReactNode } from 'react';
import type { ContextSourceNode } from './source-model.ts';
import type { ContextLensTranslate, InspectorMode } from './view-types.ts';
interface InspectorProps {
    readonly source: ContextSourceNode | undefined;
    readonly previous: ContextSourceNode | undefined;
    readonly hasPreviousAttempt: boolean;
    readonly mode: InspectorMode;
    readonly onModeChange: (mode: InspectorMode) => void;
    readonly t: ContextLensTranslate;
}
/** Raw, structural JSON, and previous-attempt inspection of one source. */
export declare function Inspector({ source, previous, hasPreviousAttempt, mode, onModeChange, t, }: InspectorProps): ReactNode;
export {};
//# sourceMappingURL=Inspector.d.ts.map