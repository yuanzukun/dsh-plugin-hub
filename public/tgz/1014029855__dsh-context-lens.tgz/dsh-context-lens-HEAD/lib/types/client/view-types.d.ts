import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { ContextLensLocaleKey } from './locales.ts';
/** Namespace-bound translator shared by the lens presentation components. */
export type ContextLensTranslate = TranslateNS<'context-lens'>;
/** Inspector presentation modes. */
export type InspectorMode = 'raw' | 'diff' | 'json';
/** Keep the locale key type reachable in isolated component test programs. */
export type { ContextLensLocaleKey };
//# sourceMappingURL=view-types.d.ts.map