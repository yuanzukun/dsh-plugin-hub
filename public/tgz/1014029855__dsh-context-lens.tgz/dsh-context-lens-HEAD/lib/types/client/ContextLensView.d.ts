import type { ReactNode } from 'react';
import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import type { InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ContextLensClientSnapshot } from './api-controller.ts';
/** Session-specific capabilities assembled in the registration's apply world. */
export interface ContextLensViewInjected {
    hooks: {
        /** Host API snapshot bound by the renderer as useContextLens. */
        contextLens: ObservableSnapshot<ContextLensClientSnapshot>;
    };
    /** Explicit user-driven Host refresh. */
    refresh: () => Promise<void>;
    /** Hydrate one request plus its predecessor for comparison. */
    loadAttempt: (id: string) => Promise<void>;
    /** Page backward until the Session event window is complete. */
    loadAllHistory: () => Promise<void>;
    /** Same-origin read-only diagnostic export. */
    exportUrl: string;
}
/** Full four-share props for the conversation view entry. */
export type ContextLensViewProps = ConvViewProps & PropsLocale<'context-lens'> & InjectFace<ContextLensViewInjected>;
/** Render the complete provider-neutral request inspector for one Session. */
export declare function ContextLensView(props: ContextLensViewProps): ReactNode;
//# sourceMappingURL=ContextLensView.d.ts.map