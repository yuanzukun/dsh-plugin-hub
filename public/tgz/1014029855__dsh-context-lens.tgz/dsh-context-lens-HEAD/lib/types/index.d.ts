/**
 * dsh-context-lens — provider-neutral request diagnostics for DeepSeek Harness.
 *
 * The Host half observes official waterfalls, stores metadata-only sidecars,
 * and serves a loopback-fenced read API. It never appends a session event.
 */
import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
export declare const name = "dsh-context-lens";
export declare const inject: string[];
export interface Config {
    /** Write metadata-only sidecars; false keeps captures process-local. */
    persistMetadata: boolean;
    /** Retained metadata attempts per session; older entries are dropped. */
    maxAttemptsPerSession: number;
    /** Fixed-density token estimate denominator; estimates are labelled as such. */
    charsPerEstimatedToken: number;
}
export declare const Config: Schema<Config>;
/** Install all registrations after required official services are ready. */
export declare function apply(ctx: Context, config: Config): Promise<void>;
export * from './shared/contract.js';
//# sourceMappingURL=index.d.ts.map