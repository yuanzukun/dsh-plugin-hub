import type { PromptAssembly } from '@deepseek-ai/dsh-system-prompt';
import type { AssemblyMetadata, ValueFingerprint } from '../shared/contract.js';
export interface CapturedAssembly {
    capturedAt: number;
    pre: PromptAssembly;
    post: PromptAssembly;
}
type Fingerprint = (value: unknown) => ValueFingerprint;
/** Detach the public assembly fields; no Scope/Fiber ownership is inferred. */
export declare function cloneAssembly(assembly: PromptAssembly): PromptAssembly;
/**
 * Prove section spans only by exact equality. Anything else becomes one
 * explicitly unattributed synthetic section; this function never guesses.
 */
export declare function assemblyMetadata(capture: CapturedAssembly, finalSystem: string, fingerprint: Fingerprint): AssemblyMetadata;
export {};
//# sourceMappingURL=assembly.d.ts.map