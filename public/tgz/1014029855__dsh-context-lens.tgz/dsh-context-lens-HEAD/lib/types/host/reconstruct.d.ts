import type { Context } from '@deepseek-ai/cordis';
import type { ContextLensAttempt, ContextLensAttemptDetail } from '../shared/contract.js';
import type { ContextLensStore } from './store.js';
export declare class ContextLensReconstructionError extends Error {
    readonly code: 'SESSION_NOT_FOUND' | 'SESSION_LOG_INCOMPLETE';
    constructor(code: 'SESSION_NOT_FOUND' | 'SESSION_LOG_INCOMPLETE', message: string);
}
/** Rebuild raw request values exclusively from official session events. */
export declare function reconstructAttempt(ctx: Context, store: ContextLensStore, attempt: ContextLensAttempt): Promise<ContextLensAttemptDetail>;
//# sourceMappingURL=reconstruct.d.ts.map