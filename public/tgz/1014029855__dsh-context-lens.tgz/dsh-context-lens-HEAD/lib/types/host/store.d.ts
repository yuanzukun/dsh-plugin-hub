import { type ContextLensAttempt, type SessionSummary, type ValueFingerprint } from '../shared/contract.js';
export interface ContextLensLogger {
    warn(message: unknown): void;
}
export interface StoreOptions {
    /** Exact `<DSH_HOME>/context-lens/v1` directory. */
    rootDir: string;
    persistMetadata: boolean;
    maxAttemptsPerSession: number;
    charsPerEstimatedToken: number;
    logger: ContextLensLogger;
}
/**
 * Metadata-only sidecar store. Memory updates are synchronous; disk commits are
 * serialized and atomic. All I/O failures are contained and exposed in health.
 */
export declare class ContextLensStore {
    private readonly options;
    private readonly sessions;
    private readonly committedAttemptIds;
    private writeChain;
    private key;
    private _storageEnabled;
    private persistentReady;
    private _lastError;
    private constructor();
    static open(options: StoreOptions): Promise<ContextLensStore>;
    get storageEnabled(): boolean;
    get persistenceConfigured(): boolean;
    get charsPerEstimatedToken(): number;
    get lastError(): string | undefined;
    get sessionCount(): number;
    get attemptCount(): number;
    fingerprint(value: unknown): ValueFingerprint;
    /** Reserve a stable 1-based attempt ordinal before asynchronous persistence. */
    reserveAttemptNumber(sessionId: string, turn: number, step: number): number;
    previousAttempt(sessionId: string): ContextLensAttempt | undefined;
    /**
     * Record in memory immediately, then atomically replace the per-session file.
     * The returned promise always resolves: model dispatch must never depend on
     * diagnostic storage.
     */
    record(attempt: ContextLensAttempt): Promise<void>;
    listSessions(): SessionSummary[];
    attemptsFor(sessionId: string): ContextLensAttempt[] | undefined;
    attempt(sessionId: string, id: string): ContextLensAttempt | undefined;
    flush(): Promise<void>;
    private initialize;
    private loadOrCreateKey;
    private loadSessions;
    private writeSession;
    private sessionsDir;
    private ensureMode;
    private sessionFilename;
    private reportFailure;
    private errorText;
}
//# sourceMappingURL=store.d.ts.map