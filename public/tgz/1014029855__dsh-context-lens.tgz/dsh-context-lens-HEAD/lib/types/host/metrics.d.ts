import type { ValueFingerprint, ValueMetrics } from '../shared/contract.js';
/** Measure a value without retaining it. Strings use their model-visible text. */
export declare function measureValue(value: unknown, charsPerEstimatedToken: number): ValueMetrics;
/** HMAC the typed JSON representation so low-entropy prompts are not guessable. */
export declare function fingerprintValue(key: Buffer, value: unknown, charsPerEstimatedToken: number): ValueFingerprint;
export declare function addMetrics(...values: ValueMetrics[]): ValueMetrics;
export declare function subtractMetrics(current: ValueMetrics, previous?: ValueMetrics): ValueMetrics;
export declare function emptyMetrics(): ValueMetrics;
//# sourceMappingURL=metrics.d.ts.map