import type { IncomingMessage } from 'node:http';
import type { Context } from '@deepseek-ai/cordis';
import { type CaptureDiagnosticsSnapshot } from '../shared/contract.js';
import type { ContextLensStore } from './store.js';
declare function isLoopbackAddress(address: string | undefined): boolean;
declare function isLoopbackHostname(hostname: string): boolean;
declare function trustedRequest(req: IncomingMessage, port: number): boolean;
/** Mount one official WebServer prefix route, owned by the plugin Fiber. */
export declare function installApi(ctx: Context, store: ContextLensStore, capture?: CaptureDiagnosticsSnapshot): void;
export declare const apiSecurity: {
    isLoopbackAddress: typeof isLoopbackAddress;
    isLoopbackHostname: typeof isLoopbackHostname;
    trustedRequest: typeof trustedRequest;
};
export {};
//# sourceMappingURL=api.d.ts.map