import type { Context } from '@deepseek-ai/cordis';
import { type CaptureDiagnosticsSnapshot, type JsonValue } from '../shared/contract.js';
import type { ContextLensStore } from './store.js';
export interface CaptureDiagnostics extends CaptureDiagnosticsSnapshot {
}
/** Create one process-local, content-free capture health accumulator. */
export declare function createCaptureDiagnostics(): CaptureDiagnostics;
/** Register transparent, global observation middleware on official DSH seams. */
export declare function installCapture(ctx: Context, store: ContextLensStore, diagnostics?: CaptureDiagnostics): CaptureDiagnostics;
/** Type-level proof helper used by tests without exporting raw runtime state. */
export declare function asJsonValue(value: unknown): JsonValue;
//# sourceMappingURL=capture.d.ts.map