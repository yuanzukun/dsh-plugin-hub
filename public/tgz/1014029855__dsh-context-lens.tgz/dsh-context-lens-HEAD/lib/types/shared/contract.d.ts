/**
 * Stable JSON contract shared by the Context Lens Host plugin and its Web UI.
 * Raw request values are never written to the Context Lens sidecar. They only
 * appear in detail responses after being reconstructed from the canonical DSH
 * session log.
 */
export declare const CONTEXT_LENS_SCHEMA_VERSION: 1;
export declare const CONTEXT_LENS_API_PREFIX: "/context-lens/api/v1";
export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | {
    [key: string]: JsonValue;
};
/** Exact size measurements plus DSH's deliberately approximate token price. */
export interface ValueMetrics {
    /** Bytes in the UTF-8 representation of the measured value. */
    utf8Bytes: number;
    /** JavaScript UTF-16 code units. */
    utf16CodeUnits: number;
    /** Unicode code points (not grapheme clusters). */
    codePoints: number;
    /** UTF-8 bytes in JSON.stringify(value). */
    logicalJsonBytes: number;
    /** Fixed-density estimate. This is never presented as tokenizer-exact. */
    estimatedTokens: number;
}
/** Metadata-only identity for a value that remains in the DSH session log. */
export interface ValueFingerprint {
    hmacSha256: string;
    metrics: ValueMetrics;
}
export interface NamedValueFingerprint extends ValueFingerprint {
    name: string;
    index: number;
    /** Exact UTF-16 [start,end) range in the final system prompt, when proved. */
    span?: {
        start: number;
        end: number;
    };
    /** Public DSH assembly does not expose a contributing Fiber/package owner. */
    attribution: 'named' | 'unattributed';
}
export interface AssemblyStageMetadata {
    sections: NamedValueFingerprint[];
    contexts: NamedValueFingerprint[];
    toolNames: string[];
    variableNames: string[];
}
export interface AssemblyMetadata {
    capturedAt: number;
    pre: AssemblyStageMetadata;
    post: AssemblyStageMetadata;
    finalSystemMapping: 'exact-sections' | 'exact-single-section' | 'synthetic' | 'empty';
    finalSections: NamedValueFingerprint[];
}
export interface AttemptDiff {
    previousAttemptId?: string;
    changed: {
        config: boolean;
        system: boolean;
        messages: boolean;
        tools: boolean;
    };
    totalsDelta: ValueMetrics;
}
export interface AttemptCaptureHealth {
    exactAgentLoopRequest: true;
    /** How this request was proved to be the current AgentLoop boundary. */
    captureProof: 'marker' | 'session-structure';
    messageMapping: 'exact' | 'mismatch';
    assembly: 'captured' | 'unavailable';
    persisted: boolean;
}
/** Metadata written to the Context Lens sidecar. No raw prompts live here. */
export interface ContextLensAttempt {
    id: string;
    sessionId: string;
    turn: number;
    step: number;
    attempt: number;
    capturedAt: number;
    stepStartSeq: number;
    requestHeaderSeq: number;
    messageEventSeqs: number[];
    provider: string;
    model: string;
    /** Deployment-configured density used for every estimatedTokens value. */
    charsPerEstimatedToken: number;
    config: ValueFingerprint;
    system: ValueFingerprint;
    messages: ValueFingerprint;
    tools: ValueFingerprint;
    total: ValueFingerprint;
    toolEntries: NamedValueFingerprint[];
    assembly?: AssemblyMetadata;
    diffFromPrevious: AttemptDiff;
    health: AttemptCaptureHealth;
}
export interface ReconstructedRequest {
    provider: string;
    model: string;
    reasoningEffort?: string;
    temperature?: number;
    maxTokens?: number;
    stop?: string[];
    system?: string;
    tools?: JsonValue[];
    messages: JsonValue[];
}
export interface ReconstructedSection extends NamedValueFingerprint {
    /** Sliced from the final request system using a previously proved span. */
    text: string;
}
export interface ContextLensAttemptDetail extends ContextLensAttempt {
    request: ReconstructedRequest;
    reconstructedSections: ReconstructedSection[];
    reconstruction: {
        source: 'live-session' | 'session-persistence';
        complete: boolean;
        warnings: string[];
    };
}
export interface SessionSummary {
    sessionId: string;
    attemptCount: number;
    lastCapturedAt: number;
    lastTurn: number;
    lastStep: number;
    /** False means the sidecar contains every retained attempt up to its cap. */
    partial: boolean;
}
export interface HealthResponse {
    schemaVersion: typeof CONTEXT_LENS_SCHEMA_VERSION;
    status: 'ok' | 'degraded';
    captureEnabled: boolean;
    persistenceConfigured: boolean;
    storageEnabled: boolean;
    attempts: number;
    sessions: number;
    capture: CaptureDiagnosticsSnapshot;
    lastError?: string;
}
/** Content-free counters proving how far requests reached the capture pipeline. */
export interface CaptureDiagnosticsSnapshot {
    assemblyEvents: number;
    preStepEvents: number;
    llmStreamEvents: number;
    markedAgentLoopRequests: number;
    structurallyVerifiedAgentLoopRequests: number;
    ignoredLlmStreams: number;
    recordedAttempts: number;
    failures: number;
    lastFailureBoundary?: string;
}
export interface SessionsResponse {
    schemaVersion: typeof CONTEXT_LENS_SCHEMA_VERSION;
    sessions: SessionSummary[];
}
export interface SessionAttemptsResponse {
    schemaVersion: typeof CONTEXT_LENS_SCHEMA_VERSION;
    sessionId: string;
    attempts: ContextLensAttempt[];
}
export interface AttemptDetailResponse {
    schemaVersion: typeof CONTEXT_LENS_SCHEMA_VERSION;
    sessionId: string;
    attempt: ContextLensAttemptDetail;
}
export interface ExportResponse {
    schemaVersion: typeof CONTEXT_LENS_SCHEMA_VERSION;
    generatedAt: number;
    sessionId: string;
    attempts: ContextLensAttemptDetail[];
}
export interface ErrorResponse {
    schemaVersion: typeof CONTEXT_LENS_SCHEMA_VERSION;
    error: {
        code: string;
        message: string;
    };
}
export declare function attemptId(turn: number, step: number, attempt: number): string;
export declare function isAttemptId(value: string): boolean;
//# sourceMappingURL=contract.d.ts.map