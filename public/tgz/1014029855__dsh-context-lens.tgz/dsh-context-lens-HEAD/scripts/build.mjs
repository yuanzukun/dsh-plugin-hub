import { createRequire } from 'node:module'
import { readFile, rm, mkdir } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'
import { build } from 'esbuild'
import { transform } from 'lightningcss'
import { stableCssModuleClasses } from './css-modules.mjs'

const require = createRequire(import.meta.url)
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const outdir = path.join(root, 'lib')
const pluginId = 'dsh-context-lens'

const clientExternals = new Set([
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-web-react',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-attachment',
  '@deepseek-ai/dsh-client-schema-form',
  '@deepseek-ai/dsh-client-runtime/client',
])

function runTypeScript() {
  const tsc = require.resolve('typescript/bin/tsc')
  const result = spawnSync(process.execPath, [tsc, '--project', path.join(root, 'tsconfig.build.json')], {
    cwd: root,
    encoding: 'utf8',
    stdio: 'inherit',
  })
  if (result.error) throw result.error
  if (result.status !== 0) throw new Error(`TypeScript declaration build failed with exit code ${result.status ?? 'unknown'}`)
}

function cssModulesPlugin() {
  return {
    name: 'dsh-context-lens-css-modules',
    setup(buildContext) {
      buildContext.onResolve({ filter: /\.module\.css$/ }, args => {
        const absolutePath = path.resolve(args.resolveDir, args.path)
        const sourcePath = path.relative(root, absolutePath).split(path.sep).join('/')
        return {
          path: sourcePath,
          namespace: 'context-lens-css-module',
          pluginData: { absolutePath },
        }
      })
      buildContext.onResolve({ filter: /\.css$/ }, args => {
        throw new Error(`Only CSS Modules are supported in the client bundle: ${args.path}`)
      })
      buildContext.onLoad({ filter: /.*/, namespace: 'context-lens-css-module' }, async args => {
        const absolutePath = args.pluginData.absolutePath
        const source = await readFile(absolutePath)
        const result = transform({
          filename: args.path,
          code: source,
          cssModules: { pattern: '[hash]_[local]' },
          minify: true,
        })
        const classes = stableCssModuleClasses(result.exports)
        const tagId = `${pluginId}/${path.basename(args.path)}`
        const contents = [
          `const css = ${JSON.stringify(result.code.toString())};`,
          `const tagId = ${JSON.stringify(tagId)};`,
          "if (typeof document !== 'undefined' && document.querySelector('style[data-plugin-css=' + JSON.stringify(tagId) + ']') === null) {",
          "  const tag = document.createElement('style');",
          `  tag.dataset.plugin = ${JSON.stringify(pluginId)};`,
          '  tag.dataset.pluginCss = tagId;',
          '  tag.textContent = css;',
          '  document.head.appendChild(tag);',
          '}',
          `export default ${JSON.stringify(classes)};`,
        ].join('\n')
        return {
          contents,
          loader: 'js',
          resolveDir: path.dirname(absolutePath),
          watchFiles: [absolutePath],
        }
      })
    },
  }
}

function clientPurityPlugin() {
  return {
    name: 'dsh-context-lens-client-purity',
    setup(buildContext) {
      buildContext.onResolve({ filter: /^@deepseek-ai\// }, args => {
        if (clientExternals.has(args.path)) return { path: args.path, external: true }
        throw new Error(
          `Client value import ${JSON.stringify(args.path)} is not in the DeepSeek Harness platform module table. `
          + 'Use a type-only import or a Cordis service instead of bundling a second runtime identity.',
        )
      })
    },
  }
}

async function main() {
  await rm(outdir, { recursive: true, force: true })
  await mkdir(outdir, { recursive: true })

  runTypeScript()

  await build({
    absWorkingDir: root,
    entryPoints: ['src/index.ts'],
    outfile: 'lib/index.js',
    bundle: true,
    format: 'esm',
    platform: 'node',
    target: 'node22',
    packages: 'external',
    sourcemap: true,
    legalComments: 'none',
    logLevel: 'info',
  })

  await build({
    absWorkingDir: root,
    entryPoints: ['src/client/index.ts'],
    outfile: 'lib/client.js',
    bundle: true,
    format: 'cjs',
    platform: 'browser',
    target: ['chrome120', 'firefox121', 'safari17'],
    external: [...clientExternals],
    plugins: [clientPurityPlugin(), cssModulesPlugin()],
    define: {
      'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'production'),
      'import.meta.env.MODE': JSON.stringify(process.env.NODE_ENV ?? 'production'),
      'import.meta.env': JSON.stringify({ MODE: process.env.NODE_ENV ?? 'production' }),
    },
    sourcemap: true,
    legalComments: 'none',
    logLevel: 'info',
    banner: {
      js: `window.__ModuleLoader__.load({ id: ${JSON.stringify(pluginId)}, factory: (require) => { var module = { exports: {} }; var exports = module.exports;`,
    },
    footer: {
      js: 'return module.exports; } });',
    },
  })
}

await main()
