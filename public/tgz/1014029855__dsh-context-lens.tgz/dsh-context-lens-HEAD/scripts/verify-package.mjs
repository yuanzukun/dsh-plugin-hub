import { spawnSync } from 'node:child_process'
import { existsSync } from 'node:fs'
import { readFile, mkdtemp, rm } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { list } from 'tar'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const destination = await mkdtemp(path.join(os.tmpdir(), 'dsh-context-lens-pack-'))
const executableDir = path.dirname(process.execPath)
const npmCli = [
  path.join(executableDir, 'node_modules', 'npm', 'bin', 'npm-cli.js'),
  path.resolve(executableDir, '..', 'lib', 'node_modules', 'npm', 'bin', 'npm-cli.js'),
].find(existsSync)
if (npmCli === undefined) throw new Error(`Cannot locate npm-cli.js beside Node executable ${process.execPath}`)

try {
  const packed = spawnSync(process.execPath, [npmCli, 'pack', '--ignore-scripts', '--json', '--pack-destination', destination], {
    cwd: root,
    encoding: 'utf8',
  })
  if (packed.error) throw packed.error
  if (packed.status !== 0) throw new Error(`npm pack failed:\n${packed.stdout}\n${packed.stderr}`)
  const report = JSON.parse(packed.stdout)
  const filename = report?.[0]?.filename
  if (typeof filename !== 'string') throw new Error(`npm pack did not report a filename: ${packed.stdout}`)

  const archive = path.join(destination, filename)
  const entries = []
  await list({ file: archive, onentry: entry => entries.push(entry.path) })

  const expected = [
    'package/package.json',
    'package/cordis.patch.yml',
    'package/lib/index.js',
    'package/lib/client.js',
    'package/lib/types/index.d.ts',
    'package/lib/types/client/index.d.ts',
    'package/README.md',
    'package/README.en.md',
    'package/LICENSE',
  ]
  for (const file of expected) {
    if (!entries.includes(file)) throw new Error(`Packed tarball is missing ${file}`)
  }
  const forbidden = entries.filter(file => /(^|\/)(src|tests|coverage|node_modules)(\/|$)/.test(file))
  if (forbidden.length > 0) throw new Error(`Packed tarball contains development files:\n${forbidden.join('\n')}`)

  const client = await readFile(path.join(root, 'lib', 'client.js'), 'utf8')
  if (!client.includes('window.__ModuleLoader__.load({ id: "dsh-context-lens"')) {
    throw new Error('Client artifact does not contain the required DeepSeek Harness ModuleLoader handoff')
  }
  console.log(`Verified ${filename}: ${entries.length} files, required Host/Client artifacts present.`)
} finally {
  await rm(destination, { recursive: true, force: true })
}
