import { readFile, rm } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const manifest = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'))
if (manifest.name !== 'dsh-context-lens') throw new Error(`Refusing to clean unexpected package ${String(manifest.name)}`)

for (const name of ['lib', 'coverage']) {
  const target = path.resolve(root, name)
  if (path.dirname(target) !== root) throw new Error(`Refusing to clean path outside package: ${target}`)
  await rm(target, { recursive: true, force: true })
}
