/** Return a class-name map with deterministic binary key ordering. */
export function stableCssModuleClasses(exportsMap = {}) {
  return Object.fromEntries(
    Object.entries(exportsMap)
      .sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0)
      .map(([local, value]) => [local, value.name]),
  )
}
