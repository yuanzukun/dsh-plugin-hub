import assert from 'node:assert/strict'
import { access, readFile, readdir } from 'node:fs/promises'
import path from 'node:path'
import test from 'node:test'
import { fileURLToPath } from 'node:url'
import { stableCssModuleClasses } from '../../scripts/css-modules.mjs'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..')
const manifest = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'))

test('package exposes an official DSH bundle and web client', async () => {
  assert.equal(manifest.name, 'dsh-context-lens')
  assert.equal(manifest.dsh?.bundle?.patch, './cordis.patch.yml')
  assert.equal(manifest.dsh?.client?.platform, 'web')
  assert.equal(manifest.exports?.['./client']?.default, './lib/client.js')
  assert.ok(manifest.files.includes('lib'))
  await access(path.join(root, 'cordis.patch.yml'))
})

test('built Host, Client, and declaration entry points exist', async () => {
  for (const file of [
    'lib/index.js',
    'lib/index.js.map',
    'lib/client.js',
    'lib/client.js.map',
    'lib/types/index.d.ts',
    'lib/types/client/index.d.ts',
  ]) await access(path.join(root, file))
})

test('built source maps are relocatable and contain no absolute local paths', async () => {
  for (const file of ['lib/index.js.map', 'lib/client.js.map']) {
    const sourceMap = await readFile(path.join(root, file), 'utf8')
    assert.doesNotMatch(sourceMap, /(?:^|[^A-Za-z])[A-Za-z]:[\\/]/)
    assert.doesNotMatch(sourceMap, /(?:[/\\]Users[/\\]|[/\\]home[/\\][^/\\\s]+[/\\]|AppData)/i)
  }
})

test('client artifact uses the lazy factory handoff and emits no orphan stylesheet', async () => {
  const client = await readFile(path.join(root, 'lib/client.js'), 'utf8')
  assert.match(client, /window\.__ModuleLoader__\.load\(\{ id: "dsh-context-lens", factory: \(require\) => \{/)
  assert.match(client, /return module\.exports; \} \}\);/)
  assert.match(client, /data-plugin-css|pluginCss/)
  const libFiles = await readdir(path.join(root, 'lib'))
  assert.ok(!libFiles.includes('client.css'), 'CSS must be injected while the Client factory materializes')
})

test('CSS Module export serialization is deterministic', () => {
  const classes = stableCssModuleClasses({
    zeta: { name: 'hash_zeta' },
    alpha: { name: 'hash_alpha' },
    middle: { name: 'hash_middle' },
  })
  assert.deepEqual(Object.keys(classes), ['alpha', 'middle', 'zeta'])
})

test('browser requires only modules from the DSH platform table', async () => {
  const client = await readFile(path.join(root, 'lib/client.js'), 'utf8')
  const allowed = new Set([
    'react',
    'react/jsx-runtime',
    'react-dom',
    'react-dom/client',
    '@deepseek-ai/cordis',
    '@deepseek-ai/dsh-client-ui-slots',
    '@deepseek-ai/dsh-client-web-react',
    '@deepseek-ai/dsh-client-ui-primitives',
    '@deepseek-ai/dsh-client-ui-attachment',
    '@deepseek-ai/dsh-client-schema-form',
    '@deepseek-ai/dsh-client-runtime/client',
  ])
  const required = [...client.matchAll(/require\(["']([^"']+)["']\)/g)].map(match => match[1])
  assert.deepEqual(required.filter(specifier => !allowed.has(specifier)), [])
})
