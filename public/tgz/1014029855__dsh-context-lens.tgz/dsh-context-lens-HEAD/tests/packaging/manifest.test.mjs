import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import test from 'node:test'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..')

test('bundle patch mounts the package by bare package name', async () => {
  const patch = await readFile(path.join(root, 'cordis.patch.yml'), 'utf8')
  assert.match(patch, /^\s*- insert:/m)
  assert.match(patch, /^\s+- id: context-lens$/m)
  assert.match(patch, /^\s+name: dsh-context-lens$/m)
  assert.doesNotMatch(patch, /[A-Za-z]:\\|\.\/src|\.\.\//)
})

test('package manifest is the authoritative bundle and client declaration', async () => {
  const manifest = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'))
  assert.equal(manifest.name, 'dsh-context-lens')
  assert.ok(manifest.dsh?.bundle)
  assert.ok(manifest.dsh?.client)
  assert.deepEqual(manifest.dsh.client.inject, [
    '@deepseek-ai/dsh-client-locale',
    '@deepseek-ai/dsh-client-runtime',
    '@deepseek-ai/dsh-client-ui-conversation',
  ])
  assert.equal(manifest.dsh.client.platform, 'web')
})

test('published documentation contains no maintainer-local paths', async () => {
  for (const filename of ['README.md', 'README.en.md']) {
    const documentation = await readFile(path.join(root, filename), 'utf8')
    assert.doesNotMatch(documentation, /(?:^|[^A-Za-z])[A-Za-z]:[\\/]/m)
    assert.doesNotMatch(documentation, /(?:[/\\]Users[/\\]|[/\\]home[/\\][^/\\\s]+[/\\]|AppData)/i)
    assert.doesNotMatch(documentation, /(?:localhost|127\.0\.0\.1)(?::\d+)?/i)
  }
})

test('pnpm build-script policy authorizes only the required native builder', async () => {
  const workspace = await readFile(path.join(root, 'pnpm-workspace.yaml'), 'utf8')
  assert.match(workspace, /^allowBuilds:\r?\n\s+esbuild: true\s*$/)
  assert.doesNotMatch(workspace, /dangerouslyAllowAllBuilds|:\s*false/)
})

test('DSH peer range accepts both RC.5 publication version families and stays bounded', async () => {
  const manifest = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'))
  const expected = '>=0.0.1-rc.5 <0.0.2-0 || >=0.1.0-rc.5 <0.1.1-0'
  const dshPeers = Object.entries(manifest.peerDependencies)
    .filter(([name]) => name.startsWith('@deepseek-ai/dsh-'))
  assert.ok(dshPeers.length > 0)
  for (const [, range] of dshPeers) assert.equal(range, expected)
})
