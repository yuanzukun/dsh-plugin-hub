import type { ContextLensAttempt, ValueMetrics } from '../../src/shared/contract.js'
import { attemptId } from '../../src/shared/contract.js'
import type { ContextLensStore } from '../../src/host/store.js'

export const ZERO_METRICS: ValueMetrics = {
  utf8Bytes: 0,
  utf16CodeUnits: 0,
  codePoints: 0,
  logicalJsonBytes: 0,
  estimatedTokens: 0,
}

export function fixtureAttempt(
  store: ContextLensStore,
  sequence = 1,
  overrides: Partial<ContextLensAttempt> = {},
): ContextLensAttempt {
  const sessionId = overrides.sessionId ?? 'session-fixture'
  const turn = overrides.turn ?? 1
  const step = overrides.step ?? 1
  const configValue = { provider: 'test', model: 'model' }
  const messagesValue: unknown[] = []
  const toolsValue: unknown[] = []
  const totalValue = { ...configValue, messages: messagesValue }
  const base: ContextLensAttempt = {
    id: attemptId(turn, step, sequence),
    sessionId,
    turn,
    step,
    attempt: sequence,
    capturedAt: 1_700_000_000_000 + sequence,
    stepStartSeq: 1,
    requestHeaderSeq: 2,
    messageEventSeqs: [],
    provider: 'test',
    model: 'model',
    charsPerEstimatedToken: store.charsPerEstimatedToken,
    config: store.fingerprint(configValue),
    system: store.fingerprint(''),
    messages: store.fingerprint(messagesValue),
    tools: store.fingerprint(toolsValue),
    total: store.fingerprint(totalValue),
    toolEntries: [],
    diffFromPrevious: {
      changed: { config: true, system: true, messages: true, tools: true },
      totalsDelta: store.fingerprint(totalValue).metrics,
    },
    health: {
      exactAgentLoopRequest: true,
      captureProof: 'marker',
      messageMapping: 'exact',
      assembly: 'unavailable',
      persisted: false,
    },
  }
  return { ...base, ...overrides }
}
