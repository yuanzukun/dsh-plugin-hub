import { afterEach, describe, expect, it } from 'vitest'
import { mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { ContextLensStore } from '../../src/host/store.js'
import { fixtureAttempt } from './fixtures.js'

const cleanup: string[] = []

async function tempRoot(): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), 'dsh-context-lens-test-'))
  cleanup.push(root)
  return root
}

afterEach(async () => {
  for (const root of cleanup.splice(0)) await rm(root, { recursive: true, force: true })
})

const logger = { warn: () => undefined }

async function open(root: string, maxAttemptsPerSession = 500): Promise<ContextLensStore> {
  return await ContextLensStore.open({
    rootDir: root,
    persistMetadata: true,
    maxAttemptsPerSession,
    charsPerEstimatedToken: 4,
    logger,
  })
}

describe('metadata-only sidecar store', () => {
  it('atomically persists only fingerprints/metrics and marks the committed snapshot', async () => {
    const root = await tempRoot()
    const store = await open(root)
    const secret = 'private prompt that must not be copied'
    await store.record(fixtureAttempt(store, 1, {
      system: store.fingerprint(secret),
    }))
    await store.flush()

    const names = await readdir(join(root, 'sessions'))
    expect(names).toHaveLength(1)
    const text = await readFile(join(root, 'sessions', names[0] as string), 'utf8')
    expect(text).not.toContain(secret)
    expect(JSON.parse(text).attempts[0].health.persisted).toBe(true)
    expect(store.attemptsFor('session-fixture')?.[0]?.health.persisted).toBe(true)
    expect((await readFile(join(root, 'hmac.key'), 'utf8')).trim()).toMatch(/^[a-f0-9]{64}$/)
  })

  it('caps each session, records partial history, and restores it with the install key', async () => {
    const root = await tempRoot()
    const store = await open(root, 2)
    const firstHmac = store.fingerprint('same value').hmacSha256
    await store.record(fixtureAttempt(store, 1))
    await store.record(fixtureAttempt(store, 2))
    await store.record(fixtureAttempt(store, 3))
    await store.flush()

    expect(store.attemptsFor('session-fixture')?.map(attempt => attempt.attempt)).toEqual([2, 3])
    expect(store.listSessions()[0]).toMatchObject({ attemptCount: 2, partial: true })

    const restored = await open(root, 2)
    expect(restored.fingerprint('same value').hmacSha256).toBe(firstHmac)
    expect(restored.attemptsFor('session-fixture')?.map(attempt => attempt.attempt)).toEqual([2, 3])
  })

  it('rejects a v1 sidecar that smuggles raw request fields', async () => {
    const root = await tempRoot()
    const store = await open(root)
    await store.record(fixtureAttempt(store))
    await store.flush()
    const [name] = await readdir(join(root, 'sessions'))
    const path = join(root, 'sessions', name as string)
    const parsed = JSON.parse(await readFile(path, 'utf8'))
    parsed.attempts[0].request = { system: 'smuggled raw prompt' }
    await writeFile(path, JSON.stringify(parsed), 'utf8')

    const restored = await open(root)
    expect(restored.attemptCount).toBe(0)
    expect(restored.lastError).toMatch(/invalid sidecar schema/)
  })

  it('recursively rejects raw payloads hidden inside metadata objects', async () => {
    const root = await tempRoot()
    const store = await open(root)
    await store.record(fixtureAttempt(store))
    await store.flush()
    const [name] = await readdir(join(root, 'sessions'))
    const path = join(root, 'sessions', name as string)
    const parsed = JSON.parse(await readFile(path, 'utf8'))
    parsed.attempts[0].config.metrics.rawPrompt = 'nested secret'
    await writeFile(path, JSON.stringify(parsed), 'utf8')

    const restored = await open(root)
    expect(restored.attemptCount).toBe(0)
    expect(restored.lastError).toMatch(/invalid sidecar schema/)
  })

  it('keeps intentional memory-only mode healthy without touching the filesystem', async () => {
    const parent = await tempRoot()
    const root = join(parent, 'not-created')
    const store = await ContextLensStore.open({
      rootDir: root,
      persistMetadata: false,
      maxAttemptsPerSession: 5,
      charsPerEstimatedToken: 4,
      logger,
    })
    await store.record(fixtureAttempt(store))
    expect(store.persistenceConfigured).toBe(false)
    expect(store.storageEnabled).toBe(false)
    expect(store.lastError).toBeUndefined()
    await expect(readdir(root)).rejects.toMatchObject({ code: 'ENOENT' })
  })

  it('does not write with a process-random key after persistent initialization fails', async () => {
    const parent = await tempRoot()
    const root = join(parent, 'root-is-a-file')
    await writeFile(root, 'sentinel', 'utf8')
    const store = await open(root)
    expect(store.storageEnabled).toBe(false)
    expect(store.lastError).toMatch(/initialize/)
    await store.record(fixtureAttempt(store))
    await store.flush()
    expect(await readFile(root, 'utf8')).toBe('sentinel')
  })
})
