import type { Context } from '@deepseek-ai/cordis'
import { createUserMessage, deepFreeze, markAgentLoopRequest, type GenerateOptions, type StreamChunk } from '@deepseek-ai/dsh-llm'
import { Session, SessionId } from '@deepseek-ai/dsh-session'
import type { PromptAssembly } from '@deepseek-ai/dsh-system-prompt'
import { describe, expect, it, vi } from 'vitest'
import { installCapture } from '../../src/host/capture.js'
import { ContextLensStore } from '../../src/host/store.js'

type Handler = (...args: any[]) => any

describe('official waterfall observation', () => {
  it('delegates unchanged while capturing the exact marked agent-loop request', async () => {
    const session = Session.create(SessionId('capture-session'))
    const handlers = new Map<string, Handler>()
    const registrations = new Map<string, unknown>()
    const ctx = {
      logger: { warn: vi.fn() },
      sessions: { get: (id: string) => id === session.id ? session : undefined },
      on: (name: string, handler: Handler, options: unknown) => {
        handlers.set(name, handler)
        registrations.set(name, options)
        return () => undefined
      },
    } as unknown as Context
    const store = await ContextLensStore.open({
      rootDir: 'unused-in-memory-mode',
      persistMetadata: false,
      maxAttemptsPerSession: 20,
      charsPerEstimatedToken: 5,
      logger: { warn: () => undefined },
    })
    const diagnostics = installCapture(ctx, store)
    expect(registrations.get('system-prompt/assemble')).toEqual({ global: true, prepend: true })
    expect(registrations.get('llm/stream')).toEqual({ global: true, prepend: true })

    const agent = { session }
    const initial: PromptAssembly = {
      sections: [{ name: 'identity', text: 'System' }],
      contexts: [],
      tools: [],
      variables: {},
    }
    const transformed: PromptAssembly = {
      ...initial,
      sections: [...initial.sections, { name: 'policy', text: 'Rules' }],
    }
    const assemblyNext = vi.fn(async () => transformed)
    const assemblyResult = await handlers.get('system-prompt/assemble')?.(
      initial,
      { agent },
      assemblyNext,
    )
    expect(assemblyNext).toHaveBeenCalledOnce()
    expect(assemblyResult).toBe(transformed)

    const entering = createUserMessage({
      content: [{ type: 'text', text: 'hello' }],
      source: { kind: 'user' },
    })
    const preStepNext = vi.fn(async () => ({ kind: 'enter', messages: [entering] }))
    const decision = await handlers.get('agent/pre-step')?.(
      { agent, turn: 1, step: 1, messages: [], signal: new AbortController().signal },
      preStepNext,
    )
    expect(preStepNext).toHaveBeenCalledOnce()
    expect(decision).toEqual({ kind: 'enter', messages: [entering] })

    session.append('turn/start', { turn: 1 })
    session.append('step/start', { turn: 1, step: 1 })
    session.append('user/message', entering, { surfaceOp: 'append' })
    session.append('request/header', {
      header: { config: { provider: 'test', model: 'model' }, system: 'System\n\nRules' },
      reason: 'initial',
    })
    const request = markAgentLoopRequest(deepFreeze({
      provider: 'test',
      model: 'model',
      messages: session.deriveMessages(),
      system: 'System\n\nRules',
      sessionId: session.id,
      signal: new AbortController().signal,
    } satisfies GenerateOptions))
    const sentinel = (async function* (): AsyncIterable<StreamChunk> {
      yield { type: 'finish', reason: { kind: 'stop' } }
    })()
    const streamNext = vi.fn(() => sentinel)
    const returned = handlers.get('llm/stream')?.(request, streamNext)

    expect(returned).toBe(sentinel)
    expect(streamNext).toHaveBeenCalledOnce()
    expect(store.attemptCount).toBe(1)
    expect(diagnostics).toMatchObject({
      assemblyEvents: 1,
      preStepEvents: 1,
      llmStreamEvents: 1,
      markedAgentLoopRequests: 1,
      structurallyVerifiedAgentLoopRequests: 0,
      ignoredLlmStreams: 0,
      recordedAttempts: 1,
      failures: 0,
    })
    expect(store.attemptsFor(String(session.id))?.[0]).toMatchObject({
      charsPerEstimatedToken: 5,
      provider: 'test',
      model: 'model',
      health: {
        exactAgentLoopRequest: true,
        captureProof: 'marker',
        messageMapping: 'exact',
        assembly: 'captured',
      },
      assembly: { finalSystemMapping: 'exact-sections' },
    })
    expect(ctx.logger.warn).not.toHaveBeenCalled()
  })

  it('captures an unmarked request only when the frozen envelope exactly reconstructs the open Session', async () => {
    const session = Session.create(SessionId('structural-capture-session'))
    const handlers = new Map<string, Handler>()
    const ctx = {
      logger: { warn: vi.fn() },
      sessions: { get: (id: string) => id === session.id ? session : undefined },
      on: (name: string, handler: Handler) => {
        handlers.set(name, handler)
        return () => undefined
      },
    } as unknown as Context
    const store = await ContextLensStore.open({
      rootDir: 'unused-in-memory-mode',
      persistMetadata: false,
      maxAttemptsPerSession: 20,
      charsPerEstimatedToken: 5,
      logger: { warn: () => undefined },
    })
    const diagnostics = installCapture(ctx, store)
    const message = createUserMessage({
      content: [{ type: 'text', text: 'hello' }],
      source: { kind: 'user' },
    })
    session.append('turn/start', { turn: 1 })
    session.append('step/start', { turn: 1, step: 1 })
    session.append('user/message', message, { surfaceOp: 'append' })
    session.append('request/header', {
      header: { config: { provider: 'test', model: 'model' }, system: 'System' },
      reason: 'initial',
    })
    const request = deepFreeze({
      provider: 'test',
      model: 'model',
      messages: session.deriveMessages(),
      system: 'System',
      sessionId: session.id,
      signal: new AbortController().signal,
    } satisfies GenerateOptions)
    const sentinel = (async function* (): AsyncIterable<StreamChunk> {
      yield { type: 'finish', reason: { kind: 'stop' } }
    })()
    const next = vi.fn(() => sentinel)

    expect(handlers.get('llm/stream')?.(request, next)).toBe(sentinel)
    expect(store.attemptCount).toBe(1)
    expect(store.attemptsFor(String(session.id))?.[0]?.health.captureProof)
      .toBe('session-structure')
    expect(diagnostics).toMatchObject({
      llmStreamEvents: 1,
      markedAgentLoopRequests: 0,
      structurallyVerifiedAgentLoopRequests: 1,
      ignoredLlmStreams: 0,
      recordedAttempts: 1,
      failures: 0,
    })
    expect(next).toHaveBeenCalledOnce()
    expect(ctx.logger.warn).not.toHaveBeenCalled()
  })

  it('ignores unmarked auxiliary, divergent, and mutable requests', async () => {
    const session = Session.create(SessionId('ignored-capture-session'))
    const handlers = new Map<string, Handler>()
    const ctx = {
      logger: { warn: vi.fn() },
      sessions: { get: (id: string) => id === session.id ? session : undefined },
      on: (name: string, handler: Handler) => {
        handlers.set(name, handler)
        return () => undefined
      },
    } as unknown as Context
    const store = await ContextLensStore.open({
      rootDir: 'unused-in-memory-mode',
      persistMetadata: false,
      maxAttemptsPerSession: 20,
      charsPerEstimatedToken: 5,
      logger: { warn: () => undefined },
    })
    const diagnostics = installCapture(ctx, store)
    const message = createUserMessage({
      content: [{ type: 'text', text: 'hello' }],
      source: { kind: 'user' },
    })
    session.append('turn/start', { turn: 1 })
    session.append('step/start', { turn: 1, step: 1 })
    session.append('user/message', message, { surfaceOp: 'append' })
    session.append('request/header', {
      header: { config: { provider: 'test', model: 'model' }, system: 'System' },
      reason: 'initial',
    })
    const base = {
      provider: 'test',
      model: 'model',
      messages: session.deriveMessages(),
      system: 'System',
      sessionId: session.id,
      signal: new AbortController().signal,
    } satisfies GenerateOptions
    const requests: GenerateOptions[] = [
      base,
      deepFreeze({ ...base, purpose: 'session-title' }),
      deepFreeze({ ...base, messages: [] }),
    ]
    const sentinel = (async function* (): AsyncIterable<StreamChunk> {
      yield { type: 'finish', reason: { kind: 'stop' } }
    })()
    const next = vi.fn(() => sentinel)

    for (const request of requests) {
      expect(handlers.get('llm/stream')?.(request, next)).toBe(sentinel)
    }
    expect(store.attemptCount).toBe(0)
    expect(diagnostics).toMatchObject({
      llmStreamEvents: 3,
      markedAgentLoopRequests: 0,
      structurallyVerifiedAgentLoopRequests: 0,
      ignoredLlmStreams: 3,
      recordedAttempts: 0,
      failures: 0,
    })
    expect(next).toHaveBeenCalledTimes(3)
    expect(ctx.logger.warn).not.toHaveBeenCalled()
  })
})
