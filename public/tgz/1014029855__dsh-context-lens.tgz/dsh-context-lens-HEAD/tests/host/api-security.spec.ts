import type { IncomingMessage } from 'node:http'
import { describe, expect, it } from 'vitest'
import { apiSecurity } from '../../src/host/api.js'

function request(
  remoteAddress: string,
  host: string,
  extra: Record<string, string> = {},
): IncomingMessage {
  return {
    socket: { remoteAddress },
    headers: { host, ...extra },
  } as unknown as IncomingMessage
}

describe('Context Lens read API trust fence', () => {
  it('accepts only loopback socket + loopback Host + the actual Web port', () => {
    expect(apiSecurity.trustedRequest(request('127.0.0.1', '127.0.0.1:3080'), 3080)).toBe(true)
    expect(apiSecurity.trustedRequest(request('::1', '[::1]:3080'), 3080)).toBe(true)
    expect(apiSecurity.trustedRequest(request('::ffff:127.0.0.1', 'localhost:3080'), 3080)).toBe(true)

    expect(apiSecurity.trustedRequest(request('192.168.1.4', '127.0.0.1:3080'), 3080)).toBe(false)
    expect(apiSecurity.trustedRequest(request('127.0.0.1', 'attacker.example:3080'), 3080)).toBe(false)
    expect(apiSecurity.trustedRequest(request('127.0.0.1', '127.0.0.1:9999'), 3080)).toBe(false)
  })

  it('rejects explicit cross-site markers and mismatched browser origins', () => {
    expect(apiSecurity.trustedRequest(request('127.0.0.1', '127.0.0.1:3080', {
      'sec-fetch-site': 'cross-site',
    }), 3080)).toBe(false)
    expect(apiSecurity.trustedRequest(request('127.0.0.1', '127.0.0.1:3080', {
      origin: 'http://evil.example',
    }), 3080)).toBe(false)
    expect(apiSecurity.trustedRequest(request('127.0.0.1', '127.0.0.1:3080', {
      origin: 'http://127.0.0.1:3080',
    }), 3080)).toBe(true)
    expect(apiSecurity.trustedRequest(request('127.0.0.1', '127.0.0.1:3080', {
      origin: 'https://127.0.0.1:3080',
    }), 3080)).toBe(false)
  })

  it('classifies the complete IPv4 127/8 range without accepting lookalikes', () => {
    expect(apiSecurity.isLoopbackAddress('127.255.0.42')).toBe(true)
    expect(apiSecurity.isLoopbackHostname('127.12.34.56')).toBe(true)
    expect(apiSecurity.isLoopbackAddress('128.0.0.1')).toBe(false)
    expect(apiSecurity.isLoopbackHostname('127.example')).toBe(false)
  })
})
