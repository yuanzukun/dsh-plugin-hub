import type { Context } from '@deepseek-ai/cordis'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { Session, SessionId } from '@deepseek-ai/dsh-session'
import { describe, expect, it } from 'vitest'
import { ContextLensReconstructionError, reconstructAttempt } from '../../src/host/reconstruct.js'
import { ContextLensStore } from '../../src/host/store.js'
import { fixtureAttempt } from './fixtures.js'

const logger = { warn: () => undefined }

async function memoryStore(): Promise<ContextLensStore> {
  return await ContextLensStore.open({
    rootDir: 'unused-in-memory-mode',
    persistMetadata: false,
    maxAttemptsPerSession: 20,
    charsPerEstimatedToken: 4,
    logger,
  })
}

function canonicalSession() {
  const session = Session.create(SessionId('reconstruction-session'))
  session.append('turn/start', { turn: 1 })
  session.append('step/start', { turn: 1, step: 1 })
  const user = session.append('user/message', createUserMessage({
    content: [{ type: 'text', text: 'hello' }],
    source: { kind: 'user' },
  }), { surfaceOp: 'append' })
  const config = { provider: 'test', model: 'model', temperature: 0.2 }
  const system = 'Identity\n\nRules'
  const header = session.append('request/header', {
    header: { config, system },
    reason: 'initial',
  })
  return { session, user, config, system, header }
}

function liveContext(session: Session): Context {
  return {
    sessions: { get: () => session },
    get: () => undefined,
  } as unknown as Context
}

describe('canonical request reconstruction', () => {
  it('rebuilds raw values from request/header and identified surface events', async () => {
    const store = await memoryStore()
    const { session, user, config, system, header } = canonicalSession()
    const messages = [user.data]
    const section = {
      name: 'unattributed:final-system',
      index: 0,
      attribution: 'unattributed' as const,
      ...store.fingerprint(system),
      span: { start: 0, end: system.length },
    }
    const attempt = fixtureAttempt(store, 1, {
      sessionId: String(session.id),
      stepStartSeq: 1,
      requestHeaderSeq: header.seq,
      messageEventSeqs: [user.seq],
      config: store.fingerprint(config),
      system: store.fingerprint(system),
      messages: store.fingerprint(messages),
      tools: store.fingerprint([]),
      total: store.fingerprint({ ...config, messages, system }),
      assembly: {
        capturedAt: 1,
        pre: { sections: [], contexts: [], toolNames: [], variableNames: [] },
        post: { sections: [], contexts: [], toolNames: [], variableNames: [] },
        finalSystemMapping: 'synthetic',
        finalSections: [section],
      },
    })

    const detail = await reconstructAttempt(liveContext(session), store, attempt)
    expect(detail.request).toMatchObject({ provider: 'test', model: 'model', temperature: 0.2, system })
    expect(detail.request.messages).toEqual(messages)
    expect(detail.reconstructedSections).toEqual([{ ...section, text: system }])
    expect(detail.reconstruction).toEqual({ source: 'live-session', complete: true, warnings: [] })
  })

  it('reports HMAC mismatches instead of silently presenting drift as exact', async () => {
    const store = await memoryStore()
    const { session, user, config, system, header } = canonicalSession()
    const attempt = fixtureAttempt(store, 1, {
      sessionId: String(session.id),
      requestHeaderSeq: header.seq,
      messageEventSeqs: [user.seq],
      config: store.fingerprint(config),
      system: store.fingerprint(system),
      messages: store.fingerprint([{ role: 'user', content: 'different' }]),
      tools: store.fingerprint([]),
      total: store.fingerprint({ ...config, messages: [user.data], system }),
    })
    const detail = await reconstructAttempt(liveContext(session), store, attempt)
    expect(detail.reconstruction.complete).toBe(false)
    expect(detail.reconstruction.warnings).toContain('messages fingerprint does not match the capture metadata')
  })

  it('uses the optional official sessionPersistence inspection for inactive sessions', async () => {
    const store = await memoryStore()
    const { session, user, config, system, header } = canonicalSession()
    const attempt = fixtureAttempt(store, 1, {
      sessionId: String(session.id),
      requestHeaderSeq: header.seq,
      messageEventSeqs: [user.seq],
      config: store.fingerprint(config),
      system: store.fingerprint(system),
      messages: store.fingerprint([user.data]),
      tools: store.fingerprint([]),
      total: store.fingerprint({ ...config, messages: [user.data], system }),
    })
    const ctx = {
      sessions: { get: () => undefined },
      get: (name: string) => name === 'sessionPersistence'
        ? { inspect: async () => ({ events: session.events, meta: session.header }) }
        : undefined,
    } as unknown as Context
    const detail = await reconstructAttempt(ctx, store, attempt)
    expect(detail.reconstruction.source).toBe('session-persistence')
    expect(detail.reconstruction.complete).toBe(true)
  })

  it('fails explicitly when the exact request header is no longer available', async () => {
    const store = await memoryStore()
    const session = Session.create(SessionId('no-header'))
    const attempt = fixtureAttempt(store, 1, { sessionId: String(session.id), requestHeaderSeq: 0 })
    await expect(reconstructAttempt(liveContext(session), store, attempt)).rejects.toEqual(
      expect.objectContaining<Partial<ContextLensReconstructionError>>({ code: 'SESSION_LOG_INCOMPLETE' }),
    )
  })
})
