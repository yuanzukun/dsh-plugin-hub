import { describe, expect, it } from 'vitest'
import { attemptId, isAttemptId } from '../../src/shared/contract.js'

describe('Context Lens wire identifiers', () => {
  it('round-trips the documented turn:step:attempt form', () => {
    expect(attemptId(12, 3, 4)).toBe('12:3:4')
    expect(isAttemptId('12:3:4')).toBe(true)
    expect(isAttemptId('01:3:4')).toBe(false)
    expect(isAttemptId('../session')).toBe(false)
    expect(isAttemptId('1:2')).toBe(false)
  })
})
