import { describe, expect, it } from 'vitest'
import type { PromptAssembly } from '@deepseek-ai/dsh-system-prompt'
import { assemblyMetadata, cloneAssembly } from '../../src/host/assembly.js'
import { fingerprintValue } from '../../src/host/metrics.js'

const key = Buffer.alloc(32, 7)
const fingerprint = (value: unknown) => fingerprintValue(key, value, 4)

function assembly(sections: PromptAssembly['sections']): PromptAssembly {
  return {
    sections,
    contexts: [{ name: 'runtime', text: 'cwd={{cwd}}' }],
    tools: [],
    variables: { who: '世界', cwd: '/work' },
  }
}

describe('assembly metadata', () => {
  it('proves exact UTF-16 spans only when the joined final prompt is equal', () => {
    const current = assembly([
      { name: 'identity', text: 'Hello {{who}}' },
      { name: 'tail', text: 'Tail' },
    ])
    const metadata = assemblyMetadata(
      { capturedAt: 10, pre: cloneAssembly(current), post: cloneAssembly(current) },
      'Hello 世界\n\nTail',
      fingerprint,
    )
    expect(metadata.finalSystemMapping).toBe('exact-sections')
    expect(metadata.finalSections.map(section => ({ name: section.name, span: section.span }))).toEqual([
      { name: 'identity', span: { start: 0, end: 8 } },
      { name: 'tail', span: { start: 10, end: 14 } },
    ])
    expect(metadata.post.contexts[0]?.name).toBe('runtime')
    expect(JSON.stringify(metadata)).not.toContain('/work')
  })

  it('recognizes one complete-section restoration without inventing ownership', () => {
    const current = assembly([
      { name: 'complete-candidate', text: 'Only this' },
      { name: 'downstream-extra', text: 'Extra' },
    ])
    const metadata = assemblyMetadata(
      { capturedAt: 10, pre: current, post: current },
      'Only this',
      fingerprint,
    )
    expect(metadata.finalSystemMapping).toBe('exact-single-section')
    expect(metadata.finalSections[0]).toMatchObject({
      name: 'complete-candidate',
      span: { start: 0, end: 9 },
      attribution: 'named',
    })
  })

  it('falls back to one explicit unattributed section when equality cannot prove a map', () => {
    const current = assembly([{ name: 'named-but-different', text: 'A' }])
    const metadata = assemblyMetadata(
      { capturedAt: 10, pre: current, post: current },
      'Provider-neutral final value',
      fingerprint,
    )
    expect(metadata.finalSystemMapping).toBe('synthetic')
    expect(metadata.finalSections).toHaveLength(1)
    expect(metadata.finalSections[0]).toMatchObject({
      name: 'unattributed:final-system',
      attribution: 'unattributed',
      span: { start: 0, end: 28 },
    })
  })
})
