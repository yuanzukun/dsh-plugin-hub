import { describe, expect, it } from 'vitest'
import { fingerprintValue, measureValue, subtractMetrics } from '../../src/host/metrics.js'

describe('context-lens metrics', () => {
  it('distinguishes UTF-8 bytes, UTF-16 units, and code points', () => {
    expect(measureValue('A😀', 2)).toEqual({
      utf8Bytes: 5,
      utf16CodeUnits: 3,
      codePoints: 2,
      logicalJsonBytes: 7,
      estimatedTokens: 2,
    })
  })

  it('uses a configured estimate density and rejects invalid deployment values', () => {
    expect(measureValue('12345', 4).estimatedTokens).toBe(2)
    expect(measureValue('12345', 10).estimatedTokens).toBe(1)
    expect(() => measureValue('x', 0)).toThrow(/positive finite/)
  })

  it('uses keyed HMAC rather than a reusable naked digest', () => {
    const first = fingerprintValue(Buffer.alloc(32, 1), 'low entropy', 4)
    const repeated = fingerprintValue(Buffer.alloc(32, 1), 'low entropy', 4)
    const otherInstall = fingerprintValue(Buffer.alloc(32, 2), 'low entropy', 4)
    expect(first.hmacSha256).toMatch(/^[a-f0-9]{64}$/)
    expect(repeated.hmacSha256).toBe(first.hmacSha256)
    expect(otherInstall.hmacSha256).not.toBe(first.hmacSha256)
  })

  it('reports signed deltas without clamping regressions', () => {
    expect(subtractMetrics(
      { utf8Bytes: 1, utf16CodeUnits: 2, codePoints: 2, logicalJsonBytes: 3, estimatedTokens: 1 },
      { utf8Bytes: 5, utf16CodeUnits: 4, codePoints: 3, logicalJsonBytes: 8, estimatedTokens: 2 },
    )).toEqual({
      utf8Bytes: -4,
      utf16CodeUnits: -2,
      codePoints: -1,
      logicalJsonBytes: -5,
      estimatedTokens: -1,
    })
  })
})
