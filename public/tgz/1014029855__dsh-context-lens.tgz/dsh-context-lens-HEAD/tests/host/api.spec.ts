import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
import { Session, SessionId } from '@deepseek-ai/dsh-session'
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver'
import { describe, expect, it } from 'vitest'
import { installApi } from '../../src/host/api.js'
import { ContextLensStore } from '../../src/host/store.js'

class ResponseCapture {
  status = 0
  headers: Record<string, string> = {}
  body = ''

  setHeader(name: string, value: string): void {
    this.headers[name.toLowerCase()] = value
  }

  writeHead(status: number, headers?: Record<string, string>): this {
    this.status = status
    for (const [name, value] of Object.entries(headers ?? {})) this.setHeader(name, value)
    return this
  }

  end(body?: string): this {
    this.body = body ?? ''
    return this
  }
}

describe('Context Lens session routes', () => {
  it('returns an empty 200 snapshot for a live session before its first attempt', async () => {
    const session = Session.create(SessionId('fresh-session'))
    const store = await ContextLensStore.open({
      rootDir: 'unused-in-memory-mode',
      persistMetadata: false,
      maxAttemptsPerSession: 20,
      charsPerEstimatedToken: 4,
      logger: { warn: () => undefined },
    })
    let route: WebRoute | undefined
    const ctx = {
      logger: { warn: () => undefined },
      sessions: { get: (id: string) => id === session.id ? session : undefined },
      webServer: {
        port: 3080,
        register: (candidate: WebRoute) => { route = candidate; return () => undefined },
      },
      effect: (factory: () => unknown) => factory(),
    } as unknown as Context
    installApi(ctx, store)

    const req = {
      method: 'GET',
      url: '/context-lens/api/v1/sessions/fresh-session',
      socket: { remoteAddress: '127.0.0.1' },
      headers: { host: '127.0.0.1:3080' },
    } as unknown as IncomingMessage
    const res = new ResponseCapture()
    await route?.handler(req, res as unknown as ServerResponse)
    expect(res.status).toBe(200)
    expect(JSON.parse(res.body)).toEqual({ schemaVersion: 1, sessionId: 'fresh-session', attempts: [] })
  })

  it('keeps a true unknown session distinct from the empty live state', async () => {
    const store = await ContextLensStore.open({
      rootDir: 'unused-in-memory-mode',
      persistMetadata: false,
      maxAttemptsPerSession: 20,
      charsPerEstimatedToken: 4,
      logger: { warn: () => undefined },
    })
    let route: WebRoute | undefined
    const ctx = {
      logger: { warn: () => undefined },
      sessions: { get: () => undefined },
      webServer: {
        port: 3080,
        register: (candidate: WebRoute) => { route = candidate; return () => undefined },
      },
      effect: (factory: () => unknown) => factory(),
    } as unknown as Context
    installApi(ctx, store)
    const req = {
      method: 'GET',
      url: '/context-lens/api/v1/sessions/unknown',
      socket: { remoteAddress: '127.0.0.1' },
      headers: { host: '127.0.0.1:3080' },
    } as unknown as IncomingMessage
    const res = new ResponseCapture()
    await route?.handler(req, res as unknown as ServerResponse)
    expect(res.status).toBe(404)
    expect(JSON.parse(res.body).error.code).toBe('SESSION_NOT_FOUND')
  })
})
