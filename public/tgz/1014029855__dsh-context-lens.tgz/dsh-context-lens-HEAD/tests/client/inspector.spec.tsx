import { renderToStaticMarkup } from 'react-dom/server'
import { describe, expect, it } from 'vitest'
import { Inspector } from '../../src/client/Inspector.tsx'
import type { ContextSourceNode } from '../../src/client/source-model.ts'
import type { ContextLensTranslate } from '../../src/client/view-types.ts'

const t = ((key: string) => key) as ContextLensTranslate

function metadataSource(hmacSha256: string): ContextSourceNode {
  return {
    id: 'context:metadata',
    group: 'context',
    label: 'metadata',
    raw: '',
    rawAvailable: false,
    value: {},
    metrics: {
      utf8Bytes: 0,
      utf16CodeUnits: 0,
      codePoints: 0,
      logicalJsonBytes: 2,
      estimatedTokens: 0,
    },
    fingerprint: {
      hmacSha256,
      metrics: {
        utf8Bytes: 0,
        utf16CodeUnits: 0,
        codePoints: 0,
        logicalJsonBytes: 2,
        estimatedTokens: 0,
      },
    },
    searchText: 'metadata',
  }
}

describe('Context inspector metadata diff', () => {
  it('does not compare missing raw values as two equal empty strings', () => {
    const html = renderToStaticMarkup(
      <Inspector
        source={metadataSource('a'.repeat(64))}
        previous={metadataSource('b'.repeat(64))}
        hasPreviousAttempt
        mode="diff"
        onModeChange={() => {}}
        t={t}
      />,
    )
    expect(html).toContain('inspector.diffUnavailable')
    expect(html).not.toContain('inspector.unchanged</p>')
  })

  it('uses equal HMACs to prove metadata-only values unchanged', () => {
    const hmac = 'c'.repeat(64)
    const html = renderToStaticMarkup(
      <Inspector
        source={metadataSource(hmac)}
        previous={metadataSource(hmac)}
        hasPreviousAttempt
        mode="diff"
        onModeChange={() => {}}
        t={t}
      />,
    )
    expect(html).toContain('inspector.unchanged')
  })
})
