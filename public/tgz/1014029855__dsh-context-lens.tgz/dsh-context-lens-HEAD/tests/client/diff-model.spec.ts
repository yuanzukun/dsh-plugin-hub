import { describe, expect, it } from 'vitest'
import { contextDiff } from '../../src/client/diff-model.ts'

describe('Context diff', () => {
  it('retains unchanged lines and marks exact additions and removals', () => {
    expect(contextDiff('same\nold\n', 'same\nnew\n')).toEqual([
      { kind: 'same', text: 'same' },
      { kind: 'removed', text: 'old' },
      { kind: 'added', text: 'new' },
    ])
  })
})
