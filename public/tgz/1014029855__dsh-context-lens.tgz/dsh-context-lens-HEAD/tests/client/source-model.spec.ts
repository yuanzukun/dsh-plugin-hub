import { describe, expect, it } from 'vitest'
import type {
  AssemblyMetadata,
  ContextLensAttemptDetail,
  NamedValueFingerprint,
  ValueFingerprint,
  ValueMetrics,
} from '../../src/shared/contract.ts'
import {
  buildContextSources,
  measureSource,
  previousSource,
} from '../../src/client/source-model.ts'

const METRICS: ValueMetrics = {
  utf8Bytes: 1,
  utf16CodeUnits: 1,
  codePoints: 1,
  logicalJsonBytes: 3,
  estimatedTokens: 1,
}

function fingerprint(): ValueFingerprint {
  return { hmacSha256: 'a'.repeat(64), metrics: { ...METRICS } }
}

function named(name: string, index: number): NamedValueFingerprint {
  return { ...fingerprint(), name, index, attribution: 'named' }
}

function detail(overrides: Partial<ContextLensAttemptDetail> = {}): ContextLensAttemptDetail {
  const value: ContextLensAttemptDetail = {
    id: '1:1:1',
    sessionId: 'session-a',
    turn: 1,
    step: 1,
    attempt: 1,
    capturedAt: 1,
    stepStartSeq: 2,
    requestHeaderSeq: 3,
    messageEventSeqs: [1],
    provider: 'deepseek',
    model: 'deepseek-chat',
    charsPerEstimatedToken: 5,
    config: fingerprint(),
    system: fingerprint(),
    messages: fingerprint(),
    tools: fingerprint(),
    total: fingerprint(),
    toolEntries: [],
    diffFromPrevious: {
      changed: { config: false, system: false, messages: false, tools: false },
      totalsDelta: { ...METRICS },
    },
    health: {
      exactAgentLoopRequest: true,
      captureProof: 'marker',
      messageMapping: 'exact',
      assembly: 'captured',
      persisted: true,
    },
    request: {
      provider: 'deepseek',
      model: 'deepseek-chat',
      system: 'system',
      tools: [],
      messages: [],
    },
    reconstructedSections: [],
    reconstruction: { source: 'live-session', complete: true, warnings: [] },
  }
  return { ...value, ...overrides }
}

describe('Context source model', () => {
  it('uses the captured deployment density for derived estimates', () => {
    expect(measureSource('1234567890', 5).estimatedTokens).toBe(2)
    expect(measureSource('1234567890', 2).estimatedTokens).toBe(5)
    const compact = JSON.stringify({ one: 1, two: 2 })
    expect(measureSource({ one: 1, two: 2 }, 4).utf16CodeUnits).toBe(compact.length)
  })

  it('classifies only source-marked user messages as runtime context', () => {
    const value = detail({
      request: {
        provider: 'deepseek',
        model: 'deepseek-chat',
        messages: [
          {
            role: 'user',
            content: 'context body',
            source: {
              kind: 'plugin',
              plugin: '@example/context',
              form: 'snapshot',
              sections: [{ name: 'clock', text: '12:00' }],
            },
          },
          {
            role: 'assistant',
            content: 'must stay a message',
            source: { kind: 'plugin', plugin: '@example/not-context' },
          },
        ],
      },
    })
    const sources = buildContextSources(value)
    const contexts = sources.filter(source => source.group === 'context')
    expect(contexts).toHaveLength(1)
    expect(contexts[0]).toMatchObject({ label: 'clock', raw: '12:00', rawAvailable: true })
    expect(contexts[0]?.metrics.utf16CodeUnits).toBe('12:00'.length)
    expect(sources.filter(source => source.group === 'messages')).toHaveLength(2)
  })

  it('marks assembly-only context metadata without presenting it as raw text', () => {
    const stage = {
      sections: [],
      contexts: [named('ephemeral', 0)],
      toolNames: [],
      variableNames: [],
    }
    const assembly: AssemblyMetadata = {
      capturedAt: 1,
      pre: stage,
      post: stage,
      finalSystemMapping: 'empty',
      finalSections: [],
    }
    const sources = buildContextSources(detail({ assembly }))
    expect(sources.find(source => source.group === 'context')).toMatchObject({
      label: 'ephemeral',
      raw: '',
      rawAvailable: false,
    })
  })

  it('matches previous sources by stable id and then semantic label', () => {
    const current = buildContextSources(detail({
      request: { provider: 'p', model: 'm', messages: [{ role: 'user', content: 'new' }] },
    })).find(source => source.group === 'messages')
    const previous = buildContextSources(detail({
      request: { provider: 'p', model: 'm', messages: [{ role: 'user', content: 'old' }] },
    }))
    expect(current).toBeDefined()
    expect(previousSource(current!, previous)?.raw).toContain('old')
  })
})
