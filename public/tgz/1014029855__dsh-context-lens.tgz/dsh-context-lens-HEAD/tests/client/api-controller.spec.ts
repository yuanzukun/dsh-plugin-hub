import { describe, expect, it, vi } from 'vitest'
import type {
  ContextLensAttempt,
  ContextLensAttemptDetail,
  ValueFingerprint,
  ValueMetrics,
} from '../../src/shared/contract.ts'
import {
  ContextLensControllerRegistry,
  ContextLensSessionController,
} from '../../src/client/api-controller.ts'

const METRICS: ValueMetrics = {
  utf8Bytes: 4,
  utf16CodeUnits: 4,
  codePoints: 4,
  logicalJsonBytes: 6,
  estimatedTokens: 1,
}

function fingerprint(): ValueFingerprint {
  return { hmacSha256: 'b'.repeat(64), metrics: { ...METRICS } }
}

function attempt(): ContextLensAttempt {
  return {
    id: '1:1:1',
    sessionId: 'session-a',
    turn: 1,
    step: 1,
    attempt: 1,
    capturedAt: 10,
    stepStartSeq: 2,
    requestHeaderSeq: 3,
    messageEventSeqs: [1],
    provider: 'deepseek',
    model: 'deepseek-chat',
    charsPerEstimatedToken: 4,
    config: fingerprint(),
    system: fingerprint(),
    messages: fingerprint(),
    tools: fingerprint(),
    total: fingerprint(),
    toolEntries: [],
    diffFromPrevious: {
      changed: { config: false, system: false, messages: false, tools: false },
      totalsDelta: {
        utf8Bytes: -1,
        utf16CodeUnits: 0,
        codePoints: 0,
        logicalJsonBytes: 0,
        estimatedTokens: 0,
      },
    },
    health: {
      exactAgentLoopRequest: true,
      captureProof: 'marker',
      messageMapping: 'exact',
      assembly: 'unavailable',
      persisted: true,
    },
  }
}

function detail(): ContextLensAttemptDetail {
  return {
    ...attempt(),
    request: {
      provider: 'deepseek',
      model: 'deepseek-chat',
      system: 'system',
      tools: [],
      messages: [{ role: 'user', content: 'hello' }],
    },
    reconstructedSections: [],
    reconstruction: { source: 'live-session', complete: true, warnings: [] },
  }
}

function revisionSource() {
  const listeners = new Set<() => void>()
  let revision = 0
  return {
    getSnapshot: () => ({
      views: { get: () => ({ revision, lastSeq: revision }) },
    }),
    subscribe: (listener: () => void) => {
      listeners.add(listener)
      return () => { listeners.delete(listener) }
    },
    move: () => {
      revision += 1
      for (const listener of listeners) listener()
    },
    listenerCount: () => listeners.size,
  }
}

function json(value: unknown, status = 200): Response {
  return new Response(JSON.stringify(value), {
    status,
    headers: { 'Content-Type': 'application/json' },
  })
}

describe('ContextLensSessionController', () => {
  it('hydrates summaries and exact detail through one stable observable', async () => {
    const row = attempt()
    const exact = detail()
    const fetcher = vi.fn(async (input: RequestInfo | URL) =>
      String(input).includes('/attempts/')
        ? json({ schemaVersion: 1, sessionId: 'session-a', attempt: exact })
        : json({ schemaVersion: 1, sessionId: 'session-a', attempts: [row] }))
    const source = revisionSource()
    const controller = new ContextLensSessionController('session-a', source, fetcher)
    const listener = vi.fn()
    const stop = controller.subscribe(listener)

    await controller.refresh()
    await controller.loadAttempt(row.id)

    expect(controller.getSnapshot()).toMatchObject({
      status: 'ready',
      error: null,
      attempts: [{ id: row.id }],
      details: { [row.id]: { request: { system: 'system' } } },
    })
    expect(listener).toHaveBeenCalled()
    stop()
    controller.dispose()
  })

  it('turns malformed directly rendered summary fields into invalid-response', async () => {
    const row = attempt() as unknown as Record<string, unknown>
    row.diffFromPrevious = {
      changed: null,
      totalsDelta: { ...METRICS },
    }
    const controller = new ContextLensSessionController(
      'session-a',
      revisionSource(),
      async () => json({ schemaVersion: 1, sessionId: 'session-a', attempts: [row] }),
    )

    await controller.refresh()

    expect(controller.getSnapshot()).toMatchObject({ status: 'error', error: 'invalid-response' })
    controller.dispose()
  })

  it('rejects malformed request reconstruction before a component can dereference it', async () => {
    const row = attempt()
    const malformed = { ...detail(), reconstruction: { source: 'elsewhere', warnings: null } }
    const fetcher = async (input: RequestInfo | URL): Promise<Response> =>
      String(input).includes('/attempts/')
        ? json({ schemaVersion: 1, sessionId: 'session-a', attempt: malformed })
        : json({ schemaVersion: 1, sessionId: 'session-a', attempts: [row] })
    const controller = new ContextLensSessionController('session-a', revisionSource(), fetcher)

    await controller.refresh()
    await controller.loadAttempt(row.id)

    expect(controller.getSnapshot().detailErrors[row.id]).toBe('invalid-response')
    expect(controller.getSnapshot().details[row.id]).toBeUndefined()
    controller.dispose()
  })

  it('drains a revision that arrives while the previous summary read is in flight', async () => {
    const row = attempt()
    const exact = detail()
    let releaseFirst: (response: Response) => void = () => {}
    const first = new Promise<Response>((resolve) => { releaseFirst = resolve })
    let summaryReads = 0
    const fetcher = vi.fn(async (input: RequestInfo | URL): Promise<Response> => {
      if (String(input).includes('/attempts/')) {
        return json({ schemaVersion: 1, sessionId: 'session-a', attempt: exact })
      }
      summaryReads += 1
      return summaryReads === 1
        ? first
        : json({ schemaVersion: 1, sessionId: 'session-a', attempts: [row] })
    })
    const source = revisionSource()
    const controller = new ContextLensSessionController('session-a', source, fetcher)
    const refresh = controller.refresh()
    source.move()
    await Promise.resolve()
    releaseFirst(json({ schemaVersion: 1, sessionId: 'session-a', attempts: [] }))

    await refresh

    expect(summaryReads).toBe(2)
    expect(controller.getSnapshot().attempts.map(entry => entry.id)).toEqual([row.id])
    controller.dispose()
  })

  it('does not start the constructor-scheduled read after immediate disposal', async () => {
    const fetcher = vi.fn(async () => json({
      schemaVersion: 1, sessionId: 'session-a', attempts: [],
    }))
    const controller = new ContextLensSessionController('session-a', revisionSource(), fetcher)
    controller.dispose()

    await Promise.resolve()
    await Promise.resolve()

    expect(fetcher).not.toHaveBeenCalled()
  })

  it('rebinds when SessionRuntime remints the same id with a new source', () => {
    const fetcher = vi.fn(async () => json({
      schemaVersion: 1, sessionId: 'session-a', attempts: [],
    }))
    const registry = new ContextLensControllerRegistry(fetcher)
    const firstSource = revisionSource()
    const secondSource = revisionSource()
    const first = registry.get('session-a', firstSource)

    expect(registry.get('session-a', firstSource)).toBe(first)
    expect(firstSource.listenerCount()).toBe(1)

    const second = registry.get('session-a', secondSource)

    expect(second).not.toBe(first)
    expect(firstSource.listenerCount()).toBe(0)
    expect(secondSource.listenerCount()).toBe(1)
    expect(registry.get('session-a', secondSource)).toBe(second)

    registry.dispose()
    expect(secondSource.listenerCount()).toBe(0)
  })
})
