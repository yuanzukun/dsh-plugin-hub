import { describe, expect, it } from 'vitest'
import {
  ContextLensRevisionBuilder,
  contextLensRevisionDefinition,
} from '../../src/client/conversation-revision.ts'

describe('Context Lens conversation revision', () => {
  it('matches lifecycle anchors but not streaming chunks', () => {
    expect(contextLensRevisionDefinition.match({
      type: 'request/header', seq: 4, time: 1, data: {},
    } as never)).toEqual({ id: '4', role: 'start' })
    expect(contextLensRevisionDefinition.match({
      type: 'assistant/chunk', seq: 5, time: 2, data: {},
    } as never)).toBeNull()
  })

  it('publishes a stable min/max log window and monotonic revision', () => {
    const builder = new ContextLensRevisionBuilder()
    const first = builder.replace({
      nodes: [
        { key: 'b', kind: 'k', id: 'b', target: 'context-lens', data: null, anchorSeq: 9, eventType: 'step/end' },
        { key: 'a', kind: 'k', id: 'a', target: 'context-lens', data: null, anchorSeq: 3, eventType: 'step/start' },
      ],
    })
    expect(first).toEqual({ revision: 1, firstSeq: 3, lastSeq: 9 })
    const second = builder.apply({
      upserts: [
        { key: 'c', kind: 'k', id: 'c', target: 'context-lens', data: null, anchorSeq: 12, eventType: 'turn/end' },
      ],
    })
    expect(second).toEqual({ revision: 2, firstSeq: 3, lastSeq: 12 })
  })
})
