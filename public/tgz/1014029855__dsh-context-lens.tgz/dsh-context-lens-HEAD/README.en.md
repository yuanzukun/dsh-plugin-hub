# dsh-context-lens

[Simplified Chinese](./README.md) | English

`dsh-context-lens` is a context-observability plugin for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness). It records the provider-neutral request assembled for each AgentLoop model call and adds a **Context** view to the conversation UI.

Use it to see which system prompt, messages, and tools were included in an attempt, how large each part was, and what changed since the previous attempt.

Context Lens observes public Harness runtime seams without changing the request passed to the LLM. It does not register a model-facing tool.

## What it shows

- Provider, model, system, messages, tools, and call configuration by turn, step, and attempt.
- Named system-prompt sections only when exact attribution is possible. Unmatched content stays explicitly unattributed.
- Durable provenance already present in Harness Session events, including skills, `AGENTS.md`, plugin context, and session references.
- Exact UTF-8 bytes, UTF-16 code units, Unicode code points, and logical JSON bytes.
- Clearly labeled token estimates that are not presented as provider-tokenizer results.
- Search, raw and structured inspection, attempt comparison, and diagnostic JSON export.

> The inspected request is the provider-neutral `GenerateOptions` at Harness's `llm/stream` dispatch seam. A provider adapter may still transform it into its own HTTP payload. Context Lens does not capture network traffic.

## Compatibility

| Component | Verified version |
| --- | --- |
| Context Lens | `0.1.0` |
| DeepSeek Harness | `0.1.0-rc.5` |
| Node.js | `^22.19.0` or `>=24.0.0` |
| Surface | `web` profile |

Harness is still evolving through release candidates. This project makes a tested claim only for the version above; an untested RC may have different event, client-slot, or bundle contracts.

## Install

### Release tarball (recommended)

Download `dsh-context-lens-0.1.0.tgz` from GitHub Releases, then run:

```sh
dsh plugin --profile web add ./dsh-context-lens-0.1.0.tgz
dsh --profile web --dump-config
dsh web
```

When running the CLI from a DeepSeek Harness source checkout, prefix the commands with `pnpm`:

```sh
pnpm dsh plugin --profile web add /path/to/dsh-context-lens-0.1.0.tgz
pnpm dsh --profile web --dump-config
pnpm dsh web
```

The dumped composition should contain a `dsh-context-lens` bundle layer and a `context-lens` row.

### GitHub source

Pin a tag or commit instead of following a moving branch:

```sh
dsh plugin --profile web add github:OWNER/dsh-context-lens#v0.1.0
```

The repository commits the built `lib/` artifacts. pnpm 10+ may still require permission for the Git dependency's `prepare` script in the profile's `pnpm-workspace.yaml`:

```yaml
allowBuilds:
  dsh-context-lens: true
```

Grant that permission only after reviewing the pinned source. Use the release tarball when install-time builds should remain disabled.

## Use

1. Start `dsh web`.
2. Open or create a conversation and complete at least one agent turn.
3. Select **Context** beside **Chat** and **Trajectory**.
4. Choose an attempt to inspect its size, provenance, raw values, and diff from the previous attempt.
5. Use JSON export when collecting diagnostics. The export may contain reconstructed raw context, so review it before sharing.

## Data and privacy

Context Lens does not persist a second raw copy of prompts, messages, or tool schemas.

- Raw requests exist briefly in the live capture path.
- The sidecar is written under `$DSH_HOME/context-lens/v1` and contains sequence references, measurements, spans, timestamps, health, and HMACs.
- Fingerprints use HMAC-SHA-256 with a random per-install key rather than bare SHA-256.
- The local API accepts only `GET` / `HEAD`, checks the loopback peer and Host authority, and returns `Cache-Control: no-store`. Do not expose it directly to a LAN or the public internet.

## Configuration

| Field | Default | Meaning |
| --- | ---: | --- |
| `persistMetadata` | `true` | Write the metadata-only sidecar |
| `maxAttemptsPerSession` | `500` | Maximum retained attempt indexes per Session |
| `charsPerEstimatedToken` | `4` | UTF-16 code units per displayed token estimate |

Override the complete `config` in a later profile `cordis.patch.yml` layer:

```yaml
- id: context-lens
  config:
    persistMetadata: true
    maxAttemptsPerSession: 250
    charsPerEstimatedToken: 4
```

A DSH patch replaces the row's complete `config`; it does not deep-merge it.

## Troubleshooting

### The Context tab is missing

1. Run `dsh --profile web --dump-config` and confirm it contains `dsh-context-lens` and `context-lens`.
2. Restart `dsh web`.
3. Hard-refresh the browser.

### No model requests were captured

Capture starts after the plugin loads. Restart the Web profile, create a new conversation, and send a message. Content-free health counters are available at:

```text
/context-lens/api/v1/health
```

`recordedAttempts` should increase for real AgentLoop requests. `ignoredLlmStreams` includes auxiliary title and compaction calls and is not an error.

### Installing a local tarball fails

Move the tarball to a short path without spaces and pass that path to `dsh plugin add`. Do not use a `link:` development checkout as release compatibility evidence; release acceptance should install the packed tarball.

## Update and uninstall

```sh
# update
dsh plugin --profile web add ./dsh-context-lens-0.1.0.tgz

# uninstall
dsh plugin --profile web remove dsh-context-lens
```

Restart `dsh web` after updating or uninstalling. Harness leaves plugin data intact on uninstall. To remove the capture index and HMAC key as well, stop all Harness processes and delete only `$DSH_HOME/context-lens/`.

## Capture boundary

Context Lens observes named assembly around `system-prompt/assemble`, associates it with a step at `agent/pre-step`, and reads the final provider-neutral request at `llm/stream`. Every waterfall listener delegates to downstream `next()` unchanged.

Real AgentLoop requests are identified first by Harness's official `isAgentLoopRequest()` marker. If a Loader module boundary splits that process-local WeakSet, the structural proof accepts a request only when all of these conditions hold:

- no auxiliary-call `purpose`;
- the complete request tree is deeply frozen except for `AbortSignal`;
- a Session step is open; and
- the full request envelope strictly equals the current `requestHeader()` and `deriveMessages()` reconstruction.

Title generation, compaction, and every other non-matching LLM stream are ignored. Each attempt records whether it used the `marker` or `session-structure` proof.

The plugin appends no custom Session events. Request details are reconstructed from the Harness Session and a metadata-only sidecar.

## Development

```sh
pnpm install
pnpm run verify
pnpm pack
```

`pnpm run verify` runs lint, TypeScript checks, the full test suite, Host/Client builds, packaging-contract tests, and release-content verification. Before releasing, install the packed tarball into a real Harness `web` profile for one complete acceptance run.

## DSH specification alignment

- [Plugin lifecycle](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/index.md): Host and Client entries export Cordis `apply`; required services use `inject`; registrations unload with their Fiber.
- [Plugin configuration](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/config.md): the plugin exports a Schemastery `Config`, and invalid values fail at load time.
- [Bundle publishing](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/publish.md): `package.json#dsh.bundle.patch` points to a top-level patch array, and the profile row uses the bare package name.
- [Client module table](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/subsystems/client-modules.md): the Web client registers through a lazy factory and resolves platform dependencies from Harness's module table.
- [Tool authoring](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/tool.md): this plugin has no model-facing tool, so it does not use `defineTool`, a tool schema, or tool output rendering.

The runtime declarations are `package.json#dsh.bundle`, `package.json#dsh.client`, and `cordis.patch.yml`. The package does not invent a `dsh.plugin.json` manifest that the official Loader does not define.

## License

[MIT](./LICENSE)
