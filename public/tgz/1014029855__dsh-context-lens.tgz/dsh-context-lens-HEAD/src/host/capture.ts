import { isDeepStrictEqual } from 'node:util'
import type { Context } from '@deepseek-ai/cordis'
import type { Agent, PreStepDecision } from '@deepseek-ai/dsh-agent'
import { isAgentLoopRequest, type GenerateOptions } from '@deepseek-ai/dsh-llm'
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session'
import { deriveEventMessage } from '@deepseek-ai/dsh-session'
import type { AssembleContext, PromptAssembly } from '@deepseek-ai/dsh-system-prompt'
import {
  attemptId,
  type AttemptCaptureHealth,
  type AttemptDiff,
  type CaptureDiagnosticsSnapshot,
  type ContextLensAttempt,
  type JsonValue,
  type NamedValueFingerprint,
} from '../shared/contract.js'
import { assemblyMetadata, cloneAssembly, type CapturedAssembly } from './assembly.js'
import { subtractMetrics } from './metrics.js'
import type { ContextLensStore } from './store.js'

interface OpenStep {
  turn: number
  step: number
  stepStartSeq: number
  requestHeaderSeq: number
}

type CaptureProof = AttemptCaptureHealth['captureProof']

function stepKey(sessionId: string, turn: number, step: number): string {
  return `${sessionId}\u0000${turn}\u0000${step}`
}

function jsonEquals(left: unknown, right: unknown): boolean {
  return JSON.stringify(left) === JSON.stringify(right)
}

function openStep(session: Session): OpenStep {
  const stepStart = session.events.findLast(event => event.type === 'step/start')
  if (stepStart === undefined) throw new Error('no step/start is open')
  const laterEnd = session.events.findLast(event => event.type === 'step/end')
  if (laterEnd !== undefined && laterEnd.seq > stepStart.seq) {
    throw new Error('latest step has already ended')
  }
  const header = session.events.findLast(event => event.type === 'request/header')
  if (header === undefined) throw new Error('no request/header exists for the request')
  return {
    turn: stepStart.data.turn,
    step: stepStart.data.step,
    stepStartSeq: stepStart.seq,
    requestHeaderSeq: header.seq,
  }
}

function messageSeqs(session: Session): { seqs: number[]; messages: unknown[] } {
  const seqs: number[] = []
  const messages: unknown[] = []
  for (const seq of session.surface.nodes) {
    const event = session.events[seq]
    if (event === undefined) continue
    const message = deriveEventMessage(event)
    if (message === null) continue
    seqs.push(seq)
    messages.push(message)
  }
  return { seqs, messages }
}

function configValue(options: GenerateOptions): Record<string, unknown> {
  return {
    provider: options.provider,
    model: options.model,
    ...options.reasoningEffort === undefined ? {} : { reasoningEffort: options.reasoningEffort },
    ...options.temperature === undefined ? {} : { temperature: options.temperature },
    ...options.maxTokens === undefined ? {} : { maxTokens: options.maxTokens },
    ...options.stop === undefined ? {} : { stop: options.stop },
  }
}

/** Match dsh-llm's public deepFreeze contract, excluding its live signal. */
function isDeepFrozenRequest(value: unknown): boolean {
  const seen = new WeakSet<object>()
  const pending: unknown[] = [value]
  while (pending.length > 0) {
    const node = pending.pop()
    if (node === null || typeof node !== 'object') continue
    if (node instanceof AbortSignal) continue
    if (seen.has(node)) continue
    seen.add(node)
    if (!Object.isFrozen(node)) return false
    for (const key of Object.keys(node)) {
      pending.push((node as Record<string, unknown>)[key])
    }
  }
  return true
}

/**
 * Loader may instantiate dsh-llm twice, splitting the process-local WeakSet
 * used by isAgentLoopRequest(). In that case accept only the exact public
 * AgentLoop reconstruction invariant: one frozen, purpose-less request whose
 * complete envelope equals the live Session header and derived messages.
 */
function structurallyVerifiesAgentLoopRequest(
  session: Session,
  options: GenerateOptions,
): boolean {
  try {
    if (options.purpose !== undefined
      || options.sessionId === undefined
      || String(options.sessionId) !== String(session.id)
      || !(options.signal instanceof AbortSignal)
      || !isDeepFrozenRequest(options)) return false

    openStep(session)
    const header = session.requestHeader()
    if (header === undefined) return false
    const expected: GenerateOptions = {
      ...header.config,
      messages: session.deriveMessages(),
      ...header.system === undefined ? {} : { system: header.system },
      ...header.tools === undefined ? {} : { tools: header.tools },
      sessionId: session.id,
      signal: options.signal,
    }
    return isDeepStrictEqual(options, expected)
  } catch {
    return false
  }
}

function toolEntries(options: GenerateOptions, store: ContextLensStore): NamedValueFingerprint[] {
  return (options.tools ?? []).map((tool, index) => ({
    name: tool.name,
    index,
    attribution: 'named',
    ...store.fingerprint(tool),
  }))
}

function diff(previous: ContextLensAttempt | undefined, current: ContextLensAttempt): AttemptDiff {
  return {
    ...previous === undefined ? {} : { previousAttemptId: previous.id },
    changed: {
      config: previous?.config.hmacSha256 !== current.config.hmacSha256,
      system: previous?.system.hmacSha256 !== current.system.hmacSha256,
      messages: previous?.messages.hmacSha256 !== current.messages.hmacSha256,
      tools: previous?.tools.hmacSha256 !== current.tools.hmacSha256,
    },
    totalsDelta: subtractMetrics(current.total.metrics, previous?.total.metrics),
  }
}

function buildAttempt(
  session: Session,
  options: GenerateOptions,
  store: ContextLensStore,
  capturedAssembly: CapturedAssembly | undefined,
  captureProof: CaptureProof,
): ContextLensAttempt {
  const position = openStep(session)
  const mapped = messageSeqs(session)
  const attempt = store.reserveAttemptNumber(String(session.id), position.turn, position.step)
  const config = configValue(options)
  const system = options.system ?? ''
  const tools = options.tools ?? []
  const request = {
    ...config,
    messages: options.messages,
    ...options.system === undefined ? {} : { system: options.system },
    ...options.tools === undefined ? {} : { tools: options.tools },
  }
  const base: ContextLensAttempt = {
    id: attemptId(position.turn, position.step, attempt),
    sessionId: String(session.id),
    turn: position.turn,
    step: position.step,
    attempt,
    capturedAt: Date.now(),
    stepStartSeq: position.stepStartSeq,
    requestHeaderSeq: position.requestHeaderSeq,
    messageEventSeqs: mapped.seqs,
    provider: options.provider,
    model: options.model,
    charsPerEstimatedToken: store.charsPerEstimatedToken,
    config: store.fingerprint(config),
    system: store.fingerprint(system),
    messages: store.fingerprint(options.messages),
    tools: store.fingerprint(tools),
    total: store.fingerprint(request),
    toolEntries: toolEntries(options, store),
    ...capturedAssembly === undefined
      ? {}
      : { assembly: assemblyMetadata(capturedAssembly, system, value => store.fingerprint(value)) },
    // Filled below after the complete current fingerprint set exists.
    diffFromPrevious: undefined as never,
    health: {
      exactAgentLoopRequest: true,
      captureProof,
      messageMapping: jsonEquals(mapped.messages, options.messages) ? 'exact' : 'mismatch',
      assembly: capturedAssembly === undefined ? 'unavailable' : 'captured',
      persisted: false,
    },
  }
  base.diffFromPrevious = diff(store.previousAttempt(String(session.id)), base)
  return base
}

export interface CaptureDiagnostics extends CaptureDiagnosticsSnapshot {}

/** Create one process-local, content-free capture health accumulator. */
export function createCaptureDiagnostics(): CaptureDiagnostics {
  return {
    assemblyEvents: 0,
    preStepEvents: 0,
    llmStreamEvents: 0,
    markedAgentLoopRequests: 0,
    structurallyVerifiedAgentLoopRequests: 0,
    ignoredLlmStreams: 0,
    recordedAttempts: 0,
    failures: 0,
  }
}

function warn(
  ctx: Context,
  diagnostics: CaptureDiagnostics,
  boundary: string,
  error: unknown,
): void {
  diagnostics.failures += 1
  diagnostics.lastFailureBoundary = boundary
  const message = error instanceof Error ? error.message : String(error)
  ctx.logger.warn(`context-lens: ${boundary} observation failed: ${message}`)
}

/** Register transparent, global observation middleware on official DSH seams. */
export function installCapture(
  ctx: Context,
  store: ContextLensStore,
  diagnostics: CaptureDiagnostics = createCaptureDiagnostics(),
): CaptureDiagnostics {
  const pendingByAgent = new WeakMap<Agent, CapturedAssembly>()
  const assemblyByStep = new Map<string, CapturedAssembly>()

  ctx.on('system-prompt/assemble', async (
    assembly: PromptAssembly,
    context: AssembleContext,
    next: () => Promise<PromptAssembly>,
  ): Promise<PromptAssembly> => {
    diagnostics.assemblyEvents += 1
    let pre: PromptAssembly | undefined
    try { pre = cloneAssembly(assembly) } catch (error) { warn(ctx, diagnostics, 'assembly/pre', error) }
    // This listener is deliberately the outer wrapper and always delegates.
    const transformed = await next()
    try {
      if (pre !== undefined && context.agent !== undefined) {
        pendingByAgent.set(context.agent, {
          capturedAt: Date.now(),
          pre,
          post: cloneAssembly(transformed),
        })
      }
    } catch (error) {
      warn(ctx, diagnostics, 'assembly/post', error)
    }
    return transformed
  }, { global: true, prepend: true })

  ctx.on('agent/pre-step', async (payload, next): Promise<PreStepDecision> => {
    diagnostics.preStepEvents += 1
    // Preserve downstream authority. Association happens only after it resolves.
    const decision = await next()
    try {
      const captured = pendingByAgent.get(payload.agent)
      pendingByAgent.delete(payload.agent)
      if (captured !== undefined && decision.kind === 'enter' && decision.messages.length > 0) {
        assemblyByStep.set(stepKey(String(payload.agent.session.id), payload.turn, payload.step), captured)
      }
    } catch (error) {
      warn(ctx, diagnostics, 'pre-step association', error)
    }
    return decision
  }, { global: true, prepend: true })

  ctx.on('llm/stream', (options: GenerateOptions, next) => {
    diagnostics.llmStreamEvents += 1
    try {
      const marked = isAgentLoopRequest(options)
      const sessionId = options.sessionId
      const session = sessionId === undefined ? undefined : ctx.sessions.get(sessionId)
      const structural = !marked
        && session !== undefined
        && structurallyVerifiesAgentLoopRequest(session, options)
      if (!marked && !structural) {
        diagnostics.ignoredLlmStreams += 1
      } else {
        if (marked) diagnostics.markedAgentLoopRequests += 1
        else diagnostics.structurallyVerifiedAgentLoopRequests += 1
        if (sessionId === undefined) throw new Error('agent-loop request has no sessionId')
        if (session === undefined) throw new Error(`live session ${String(sessionId)} was not found`)
        const position = openStep(session)
        const captured = assemblyByStep.get(stepKey(String(sessionId), position.turn, position.step))
        void store.record(buildAttempt(
          session,
          options,
          store,
          captured,
          marked ? 'marker' : 'session-structure',
        ))
        diagnostics.recordedAttempts += 1
      }
    } catch (error) {
      warn(ctx, diagnostics, 'llm/stream', error)
    }
    // Never consume, wrap, mutate, or replace the provider stream.
    return next()
  }, { global: true, prepend: true })

  ctx.on('session/event', (session: Session, event: SessionEvent) => {
    if (event.type === 'step/end') {
      assemblyByStep.delete(stepKey(String(session.id), event.data.turn, event.data.step))
      return
    }
    if (event.type === 'turn/end') {
      const prefix = `${String(session.id)}\u0000${event.data.turn}\u0000`
      for (const key of assemblyByStep.keys()) {
        if (key.startsWith(prefix)) assemblyByStep.delete(key)
      }
    }
  }, { global: true })

  ctx.on('session/disposed', (session: Session) => {
    const prefix = `${String(session.id)}\u0000`
    for (const key of assemblyByStep.keys()) {
      if (key.startsWith(prefix)) assemblyByStep.delete(key)
    }
  }, { global: true })

  return diagnostics
}

/** Type-level proof helper used by tests without exporting raw runtime state. */
export function asJsonValue(value: unknown): JsonValue {
  return value as JsonValue
}
