import { createHmac, randomBytes } from 'node:crypto'
import { chmod, mkdir, readFile, readdir, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { writeFileAtomic } from '@deepseek-ai/dsh-atomic-write'
import {
  CONTEXT_LENS_SCHEMA_VERSION,
  attemptId,
  isAttemptId,
  type ContextLensAttempt,
  type NamedValueFingerprint,
  type SessionSummary,
  type ValueFingerprint,
  type ValueMetrics,
} from '../shared/contract.js'
import { fingerprintValue } from './metrics.js'

interface StoredSession {
  schemaVersion: typeof CONTEXT_LENS_SCHEMA_VERSION
  sessionId: string
  partial: boolean
  attempts: ContextLensAttempt[]
}

export interface ContextLensLogger {
  warn(message: unknown): void
}

export interface StoreOptions {
  /** Exact `<DSH_HOME>/context-lens/v1` directory. */
  rootDir: string
  persistMetadata: boolean
  maxAttemptsPerSession: number
  charsPerEstimatedToken: number
  logger: ContextLensLogger
}

function isErrno(error: unknown, code: string): boolean {
  return (error as NodeJS.ErrnoException | null)?.code === code
}

function isSafeInteger(value: unknown, allowNegative = false): value is number {
  return typeof value === 'number'
    && Number.isSafeInteger(value)
    && (allowNegative || value >= 0)
}

function hasOnlyKeys(record: Record<string, unknown>, allowed: readonly string[]): boolean {
  const allowedSet = new Set(allowed)
  return Object.keys(record).every(key => allowedSet.has(key))
}

function isMetrics(value: unknown, allowNegative = false): value is ValueMetrics {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false
  const metrics = value as Record<string, unknown>
  return hasOnlyKeys(metrics, [
    'utf8Bytes', 'utf16CodeUnits', 'codePoints', 'logicalJsonBytes', 'estimatedTokens',
  ])
    && isSafeInteger(metrics.utf8Bytes, allowNegative)
    && isSafeInteger(metrics.utf16CodeUnits, allowNegative)
    && isSafeInteger(metrics.codePoints, allowNegative)
    && isSafeInteger(metrics.logicalJsonBytes, allowNegative)
    && isSafeInteger(metrics.estimatedTokens, allowNegative)
}

function isFingerprint(value: unknown): value is ValueFingerprint {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false
  const fingerprint = value as Record<string, unknown>
  return hasOnlyKeys(fingerprint, ['hmacSha256', 'metrics'])
    && typeof fingerprint.hmacSha256 === 'string'
    && /^[a-f0-9]{64}$/i.test(fingerprint.hmacSha256)
    && isMetrics(fingerprint.metrics)
}

function isNamedFingerprint(value: unknown): value is NamedValueFingerprint {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false
  const named = value as Record<string, unknown>
  if (!hasOnlyKeys(named, ['hmacSha256', 'metrics', 'name', 'index', 'span', 'attribution'])
    || typeof named.hmacSha256 !== 'string'
    || !/^[a-f0-9]{64}$/i.test(named.hmacSha256)
    || !isMetrics(named.metrics)) return false
  if (typeof named.name !== 'string'
    || !isSafeInteger(named.index)
    || (named.attribution !== 'named' && named.attribution !== 'unattributed')) return false
  if (named.span === undefined) return true
  if (named.span === null || typeof named.span !== 'object' || Array.isArray(named.span)) return false
  const span = named.span as Record<string, unknown>
  return hasOnlyKeys(span, ['start', 'end'])
    && isSafeInteger(span.start)
    && isSafeInteger(span.end)
    && span.end >= span.start
    && span.end - span.start === (named.metrics as ValueMetrics).utf16CodeUnits
}

function isStage(value: unknown): boolean {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false
  const stage = value as Record<string, unknown>
  return hasOnlyKeys(stage, ['sections', 'contexts', 'toolNames', 'variableNames'])
    && Array.isArray(stage.sections) && stage.sections.every(isNamedFingerprint)
    && Array.isArray(stage.contexts) && stage.contexts.every(isNamedFingerprint)
    && Array.isArray(stage.toolNames) && stage.toolNames.every(name => typeof name === 'string')
    && Array.isArray(stage.variableNames) && stage.variableNames.every(name => typeof name === 'string')
}

function isAssembly(value: unknown): boolean {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false
  const assembly = value as Record<string, unknown>
  const valid = hasOnlyKeys(assembly, ['capturedAt', 'pre', 'post', 'finalSystemMapping', 'finalSections'])
    && isSafeInteger(assembly.capturedAt)
    && isStage(assembly.pre)
    && isStage(assembly.post)
    && ['exact-sections', 'exact-single-section', 'synthetic', 'empty'].includes(String(assembly.finalSystemMapping))
    && Array.isArray(assembly.finalSections)
    && assembly.finalSections.every(isNamedFingerprint)
  if (!valid) return false
  let end = 0
  for (const section of assembly.finalSections as NamedValueFingerprint[]) {
    if (section.span === undefined) continue
    if (section.span.start < end) return false
    end = section.span.end
  }
  return true
}

const ATTEMPT_KEYS = new Set([
  'id', 'sessionId', 'turn', 'step', 'attempt', 'capturedAt', 'stepStartSeq',
  'requestHeaderSeq', 'messageEventSeqs', 'provider', 'model', 'charsPerEstimatedToken', 'config',
  'system', 'messages', 'tools', 'total', 'toolEntries', 'assembly',
  'diffFromPrevious', 'health',
])

function isAttempt(value: unknown, sessionId: string): value is ContextLensAttempt {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false
  const attempt = value as Record<string, unknown>
  // A v1 sidecar is metadata-only. Reject unknown/raw fields instead of
  // accidentally adopting prompt copies written by a malformed producer.
  if (Object.keys(attempt).some(key => !ATTEMPT_KEYS.has(key))) return false
  if (typeof attempt.id !== 'string' || !isAttemptId(attempt.id)
    || attempt.sessionId !== sessionId
    || !isSafeInteger(attempt.turn)
    || attempt.turn < 1
    || !isSafeInteger(attempt.step)
    || attempt.step < 1
    || !isSafeInteger(attempt.attempt)
    || attempt.attempt < 1
    || !isSafeInteger(attempt.capturedAt)
    || !isSafeInteger(attempt.stepStartSeq)
    || !isSafeInteger(attempt.requestHeaderSeq)
    || !Array.isArray(attempt.messageEventSeqs)
    || !attempt.messageEventSeqs.every(seq => isSafeInteger(seq))
    || typeof attempt.provider !== 'string'
    || attempt.provider.length === 0
    || typeof attempt.model !== 'string'
    || attempt.model.length === 0
    || typeof attempt.charsPerEstimatedToken !== 'number'
    || !Number.isFinite(attempt.charsPerEstimatedToken)
    || attempt.charsPerEstimatedToken <= 0
    || !isFingerprint(attempt.config)
    || !isFingerprint(attempt.system)
    || !isFingerprint(attempt.messages)
    || !isFingerprint(attempt.tools)
    || !isFingerprint(attempt.total)
    || !Array.isArray(attempt.toolEntries)
    || !attempt.toolEntries.every(isNamedFingerprint)
    || (attempt.assembly !== undefined && !isAssembly(attempt.assembly))) return false
  if (attempt.id !== attemptId(attempt.turn as number, attempt.step as number, attempt.attempt as number)) return false
  for (let index = 1; index < (attempt.messageEventSeqs as number[]).length; index += 1) {
    if ((attempt.messageEventSeqs as number[])[index] as number <= ((attempt.messageEventSeqs as number[])[index - 1] as number)) return false
  }

  const diff = attempt.diffFromPrevious
  if (diff === null || typeof diff !== 'object' || Array.isArray(diff)) return false
  const diffRecord = diff as Record<string, unknown>
  if (!hasOnlyKeys(diffRecord, ['previousAttemptId', 'changed', 'totalsDelta'])
    || (diffRecord.previousAttemptId !== undefined
    && (typeof diffRecord.previousAttemptId !== 'string' || !isAttemptId(diffRecord.previousAttemptId)))) return false
  const changed = diffRecord.changed
  if (changed === null || typeof changed !== 'object' || Array.isArray(changed)) return false
  const changedRecord = changed as Record<string, unknown>
  if (!hasOnlyKeys(changedRecord, ['config', 'system', 'messages', 'tools'])
    || typeof changedRecord.config !== 'boolean'
    || typeof changedRecord.system !== 'boolean'
    || typeof changedRecord.messages !== 'boolean'
    || typeof changedRecord.tools !== 'boolean'
    || !isMetrics(diffRecord.totalsDelta, true)) return false

  const health = attempt.health
  if (health === null || typeof health !== 'object' || Array.isArray(health)) return false
  const healthRecord = health as Record<string, unknown>
  return hasOnlyKeys(healthRecord, [
    'exactAgentLoopRequest', 'captureProof', 'messageMapping', 'assembly', 'persisted',
  ])
    && healthRecord.exactAgentLoopRequest === true
    && (healthRecord.captureProof === 'marker' || healthRecord.captureProof === 'session-structure')
    && (healthRecord.messageMapping === 'exact' || healthRecord.messageMapping === 'mismatch')
    && (healthRecord.assembly === 'captured' || healthRecord.assembly === 'unavailable')
    && healthRecord.persisted === true
}

function isStoredSession(value: unknown): value is StoredSession {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false
  const record = value as Record<string, unknown>
  const valid = hasOnlyKeys(record, ['schemaVersion', 'sessionId', 'partial', 'attempts'])
    && record.schemaVersion === CONTEXT_LENS_SCHEMA_VERSION
    && typeof record.sessionId === 'string'
    && typeof record.partial === 'boolean'
    && Array.isArray(record.attempts)
    && record.attempts.every(attempt => isAttempt(attempt, record.sessionId as string))
  if (!valid) return false
  const ids = new Set((record.attempts as ContextLensAttempt[]).map(attempt => attempt.id))
  return ids.size === (record.attempts as ContextLensAttempt[]).length
}

function clone<T>(value: T): T {
  return structuredClone(value)
}

/**
 * Metadata-only sidecar store. Memory updates are synchronous; disk commits are
 * serialized and atomic. All I/O failures are contained and exposed in health.
 */
export class ContextLensStore {
  private readonly sessions = new Map<string, StoredSession>()
  private readonly committedAttemptIds = new Map<string, Set<string>>()
  private writeChain: Promise<void> = Promise.resolve()
  private key: Buffer = randomBytes(32)
  private _storageEnabled = false
  private persistentReady = false
  private _lastError: string | undefined

  private constructor(private readonly options: StoreOptions) {}

  static async open(options: StoreOptions): Promise<ContextLensStore> {
    const store = new ContextLensStore(options)
    await store.initialize()
    return store
  }

  get storageEnabled(): boolean {
    return this._storageEnabled
  }

  get persistenceConfigured(): boolean {
    return this.options.persistMetadata
  }

  get charsPerEstimatedToken(): number {
    return this.options.charsPerEstimatedToken
  }

  get lastError(): string | undefined {
    return this._lastError
  }

  get sessionCount(): number {
    return this.sessions.size
  }

  get attemptCount(): number {
    let total = 0
    for (const session of this.sessions.values()) total += session.attempts.length
    return total
  }

  fingerprint(value: unknown): ValueFingerprint {
    return fingerprintValue(this.key, value, this.options.charsPerEstimatedToken)
  }

  /** Reserve a stable 1-based attempt ordinal before asynchronous persistence. */
  reserveAttemptNumber(sessionId: string, turn: number, step: number): number {
    const current = this.sessions.get(sessionId)?.attempts
      .filter(attempt => attempt.turn === turn && attempt.step === step)
      .reduce((max, attempt) => Math.max(max, attempt.attempt), 0) ?? 0
    return current + 1
  }

  previousAttempt(sessionId: string): ContextLensAttempt | undefined {
    const attempt = this.sessions.get(sessionId)?.attempts.at(-1)
    return attempt === undefined ? undefined : clone(attempt)
  }

  /**
   * Record in memory immediately, then atomically replace the per-session file.
   * The returned promise always resolves: model dispatch must never depend on
   * diagnostic storage.
   */
  record(attempt: ContextLensAttempt): Promise<void> {
    const previous = this.sessions.get(attempt.sessionId)
    const attempts = [...previous?.attempts ?? [], clone(attempt)]
    const overflow = Math.max(0, attempts.length - this.options.maxAttemptsPerSession)
    if (overflow > 0) attempts.splice(0, overflow)
    const next: StoredSession = {
      schemaVersion: CONTEXT_LENS_SCHEMA_VERSION,
      sessionId: attempt.sessionId,
      partial: previous?.partial === true || overflow > 0,
      attempts,
    }
    this.sessions.set(attempt.sessionId, next)
    if (!this.persistentReady) return Promise.resolve()
    const diskSnapshot = clone(next)
    for (const candidate of diskSnapshot.attempts) candidate.health.persisted = true
    const persistedIds = new Set(diskSnapshot.attempts.map(candidate => candidate.id))
    this.writeChain = this.writeChain.then(async () => {
      try {
        await this.writeSession(diskSnapshot)
        this.committedAttemptIds.set(next.sessionId, new Set(persistedIds))
        this._storageEnabled = true
        this._lastError = undefined
        const live = this.sessions.get(next.sessionId)
        if (live !== undefined) {
          for (const recorded of live.attempts) {
            if (persistedIds.has(recorded.id)) recorded.health.persisted = true
          }
        }
      } catch (error) {
        this.reportFailure('write', error)
        const live = this.sessions.get(next.sessionId)
        const committed = this.committedAttemptIds.get(next.sessionId) ?? new Set<string>()
        if (live !== undefined) {
          for (const recorded of live.attempts) {
            if (persistedIds.has(recorded.id)) recorded.health.persisted = committed.has(recorded.id)
          }
        }
      }
    })
    return this.writeChain
  }

  listSessions(): SessionSummary[] {
    return [...this.sessions.values()]
      .filter(session => session.attempts.length > 0)
      .map((session) => {
        // The filter above proves this value exists.
        const last = session.attempts.at(-1) as ContextLensAttempt
        return {
          sessionId: session.sessionId,
          attemptCount: session.attempts.length,
          lastCapturedAt: last.capturedAt,
          lastTurn: last.turn,
          lastStep: last.step,
          partial: session.partial,
        }
      })
      .sort((left, right) => right.lastCapturedAt - left.lastCapturedAt)
  }

  attemptsFor(sessionId: string): ContextLensAttempt[] | undefined {
    const attempts = this.sessions.get(sessionId)?.attempts
    return attempts === undefined ? undefined : clone(attempts)
  }

  attempt(sessionId: string, id: string): ContextLensAttempt | undefined {
    const attempt = this.sessions.get(sessionId)?.attempts.find(candidate => candidate.id === id)
    return attempt === undefined ? undefined : clone(attempt)
  }

  async flush(): Promise<void> {
    await this.writeChain
  }

  private async initialize(): Promise<void> {
    if (!this.options.persistMetadata) return
    try {
      await mkdir(this.sessionsDir(), { recursive: true, mode: 0o700 })
      await this.ensureMode(this.options.rootDir, 0o700)
      await this.ensureMode(this.sessionsDir(), 0o700)
      this.key = await this.loadOrCreateKey()
      await this.loadSessions()
      this.persistentReady = true
      this._storageEnabled = true
    } catch (error) {
      // Keep the random process-local key and an empty in-memory store.
      this.reportFailure('initialize', error)
    }
  }

  private async loadOrCreateKey(): Promise<Buffer> {
    const path = join(this.options.rootDir, 'hmac.key')
    let text: string
    try {
      text = await readFile(path, 'utf8')
    } catch (error) {
      if (!isErrno(error, 'ENOENT')) throw error
      const created = randomBytes(32).toString('hex')
      try {
        await writeFile(path, `${created}\n`, { encoding: 'utf8', flag: 'wx', mode: 0o600 })
        text = created
      } catch (writeError) {
        if (!isErrno(writeError, 'EEXIST')) throw writeError
        text = await readFile(path, 'utf8')
      }
    }
    const trimmed = text.trim()
    if (!/^[a-f0-9]{64}$/i.test(trimmed)) {
      throw new Error('context-lens: HMAC key is not a 32-byte hexadecimal key')
    }
    await this.ensureMode(path, 0o600)
    return Buffer.from(trimmed, 'hex')
  }

  private async loadSessions(): Promise<void> {
    const names = await readdir(this.sessionsDir())
    for (const name of names) {
      if (!name.endsWith('.json')) continue
      const path = join(this.sessionsDir(), name)
      try {
        const parsed: unknown = JSON.parse(await readFile(path, 'utf8'))
        if (!isStoredSession(parsed)) throw new Error('invalid sidecar schema')
        if (name !== this.sessionFilename(parsed.sessionId)) {
          throw new Error('sidecar filename does not match its keyed session identity')
        }
        const capped = parsed.attempts.slice(-this.options.maxAttemptsPerSession)
        this.sessions.set(parsed.sessionId, {
          ...parsed,
          partial: parsed.partial || capped.length !== parsed.attempts.length,
          attempts: capped,
        })
        this.committedAttemptIds.set(parsed.sessionId, new Set(capped.map(attempt => attempt.id)))
      } catch (error) {
        // One damaged session must not hide all healthy diagnostics.
        this.options.logger.warn(`context-lens: skipped ${path}: ${this.errorText(error)}`)
        this._lastError = `load: ${this.errorText(error)}`
      }
    }
  }

  private async writeSession(session: StoredSession): Promise<void> {
    await writeFileAtomic(
      join(this.sessionsDir(), this.sessionFilename(session.sessionId)),
      `${JSON.stringify(session)}\n`,
      { mode: 0o600, dirMode: 0o700 },
    )
  }

  private sessionsDir(): string {
    return join(this.options.rootDir, 'sessions')
  }

  private async ensureMode(path: string, mode: number): Promise<void> {
    try {
      await chmod(path, mode)
    } catch (error) {
      // Windows permission emulation may reject chmod despite the create mode;
      // on POSIX inability to enforce owner-only storage is a hard persistence
      // initialization failure and capture remains memory-only.
      if (process.platform !== 'win32') throw error
    }
  }

  private sessionFilename(sessionId: string): string {
    return `${createHmac('sha256', this.key)
      .update(`session:${sessionId}`, 'utf8')
      .digest('hex')}.json`
  }

  private reportFailure(operation: string, error: unknown): void {
    this._storageEnabled = false
    this._lastError = `${operation}: ${this.errorText(error)}`
    this.options.logger.warn(`context-lens: ${this._lastError}`)
  }

  private errorText(error: unknown): string {
    return error instanceof Error ? error.message : String(error)
  }
}
