import type { Context } from '@deepseek-ai/cordis'
import { SessionId, deriveEventMessage, foldRequestHeader, type SessionEvent } from '@deepseek-ai/dsh-session'
import type {} from '@deepseek-ai/dsh-session-persistence'
import type {
  ContextLensAttempt,
  ContextLensAttemptDetail,
  JsonValue,
  ReconstructedRequest,
  ReconstructedSection,
} from '../shared/contract.js'
import type { ContextLensStore } from './store.js'

export class ContextLensReconstructionError extends Error {
  constructor(public readonly code: 'SESSION_NOT_FOUND' | 'SESSION_LOG_INCOMPLETE', message: string) {
    super(message)
    this.name = 'ContextLensReconstructionError'
  }
}

interface EventSource {
  events: readonly SessionEvent[]
  source: 'live-session' | 'session-persistence'
}

async function eventSource(ctx: Context, sessionId: string): Promise<EventSource> {
  const id = SessionId(sessionId)
  const live = ctx.sessions.get(id)
  if (live !== undefined) return { events: live.events, source: 'live-session' }
  const persistence = ctx.get('sessionPersistence')
  if (persistence === undefined) {
    throw new ContextLensReconstructionError(
      'SESSION_NOT_FOUND',
      `session "${sessionId}" is not live and no sessionPersistence service is available`,
    )
  }
  try {
    const inspected = await persistence.inspect(id)
    return { events: inspected.events, source: 'session-persistence' }
  } catch (error) {
    throw new ContextLensReconstructionError(
      'SESSION_NOT_FOUND',
      `session "${sessionId}" could not be inspected: ${error instanceof Error ? error.message : String(error)}`,
    )
  }
}

function asJson(value: unknown): JsonValue {
  return value as JsonValue
}

function fingerprintMatches(store: ContextLensStore, expected: string, value: unknown): boolean {
  return store.fingerprint(value).hmacSha256 === expected
}

/** Rebuild raw request values exclusively from official session events. */
export async function reconstructAttempt(
  ctx: Context,
  store: ContextLensStore,
  attempt: ContextLensAttempt,
): Promise<ContextLensAttemptDetail> {
  const source = await eventSource(ctx, attempt.sessionId)
  const warnings: string[] = []
  let complete = true
  const header = foldRequestHeader(source.events.slice(0, attempt.requestHeaderSeq + 1))
  if (header === undefined) {
    throw new ContextLensReconstructionError(
      'SESSION_LOG_INCOMPLETE',
      `request/header at or before seq ${attempt.requestHeaderSeq} is unavailable`,
    )
  }

  const messages: JsonValue[] = []
  for (const seq of attempt.messageEventSeqs) {
    const event = source.events[seq]
    if (event === undefined) {
      warnings.push(`message event seq ${seq} is unavailable`)
      complete = false
      continue
    }
    const message = deriveEventMessage(event)
    if (message === null) {
      warnings.push(`event seq ${seq} no longer derives a message`)
      complete = false
      continue
    }
    messages.push(asJson(message))
  }

  const config = header.config
  const system = header.system ?? ''
  const tools = header.tools ?? []
  const request: ReconstructedRequest = {
    provider: config.provider,
    model: config.model,
    ...config.reasoningEffort === undefined ? {} : { reasoningEffort: String(config.reasoningEffort) },
    ...config.temperature === undefined ? {} : { temperature: config.temperature },
    ...config.maxTokens === undefined ? {} : { maxTokens: config.maxTokens },
    ...config.stop === undefined ? {} : { stop: [...config.stop] },
    ...header.system === undefined ? {} : { system: header.system },
    ...header.tools === undefined ? {} : { tools: asJson(header.tools) as JsonValue[] },
    messages,
  }
  const configJson = {
    provider: config.provider,
    model: config.model,
    ...config.reasoningEffort === undefined ? {} : { reasoningEffort: config.reasoningEffort },
    ...config.temperature === undefined ? {} : { temperature: config.temperature },
    ...config.maxTokens === undefined ? {} : { maxTokens: config.maxTokens },
    ...config.stop === undefined ? {} : { stop: config.stop },
  }
  // Preserve capture.ts insertion order and optional-field presence for the
  // keyed total fingerprint. The user-facing request object may evolve its
  // presentation order without changing this canonical integrity check.
  const totalRequest = {
    ...configJson,
    messages,
    ...header.system === undefined ? {} : { system: header.system },
    ...header.tools === undefined ? {} : { tools: header.tools },
  }
  const checks: Array<[string, string, unknown]> = [
    ['config', attempt.config.hmacSha256, configJson],
    ['system', attempt.system.hmacSha256, system],
    ['messages', attempt.messages.hmacSha256, messages],
    ['tools', attempt.tools.hmacSha256, tools],
    ['total request', attempt.total.hmacSha256, totalRequest],
  ]
  for (const [name, expected, value] of checks) {
    if (fingerprintMatches(store, expected, value)) continue
    warnings.push(`${name} fingerprint does not match the capture metadata`)
    complete = false
  }

  const reconstructedSections: ReconstructedSection[] = []
  for (const section of attempt.assembly?.finalSections ?? []) {
    const span = section.span
    if (span === undefined
      || span.start < 0
      || span.end < span.start
      || span.end > system.length) {
      warnings.push(`section "${section.name}" has an invalid final-system span`)
      complete = false
      continue
    }
    const text = system.slice(span.start, span.end)
    if (!fingerprintMatches(store, section.hmacSha256, text)) {
      warnings.push(`section "${section.name}" fingerprint does not match its span`)
      complete = false
      continue
    }
    reconstructedSections.push({ ...section, text })
  }

  if (request.provider !== attempt.provider || request.model !== attempt.model) {
    warnings.push('provider/model differs from capture metadata')
    complete = false
  }

  return {
    ...attempt,
    request,
    reconstructedSections,
    reconstruction: { source: source.source, complete, warnings },
  }
}
