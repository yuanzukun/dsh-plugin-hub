import type { PromptAssembly } from '@deepseek-ai/dsh-system-prompt'
import { renderContextSections, renderPrompt } from '@deepseek-ai/dsh-system-prompt'
import type {
  AssemblyMetadata,
  AssemblyStageMetadata,
  NamedValueFingerprint,
  ValueFingerprint,
} from '../shared/contract.js'

export interface CapturedAssembly {
  capturedAt: number
  pre: PromptAssembly
  post: PromptAssembly
}

type Fingerprint = (value: unknown) => ValueFingerprint

/** Detach the public assembly fields; no Scope/Fiber ownership is inferred. */
export function cloneAssembly(assembly: PromptAssembly): PromptAssembly {
  return {
    sections: assembly.sections.map(section => ({ name: section.name, text: section.text })),
    contexts: assembly.contexts.map(context => ({ name: context.name, text: context.text })),
    tools: structuredClone(assembly.tools),
    variables: { ...assembly.variables },
  }
}

function named(
  name: string,
  index: number,
  value: unknown,
  fingerprint: Fingerprint,
  span?: { start: number; end: number },
): NamedValueFingerprint {
  return {
    name,
    index,
    attribution: name === 'unattributed:final-system' ? 'unattributed' : 'named',
    ...fingerprint(value),
    ...span === undefined ? {} : { span },
  }
}

function renderSection(assembly: PromptAssembly, index: number): string {
  const section = assembly.sections[index]
  if (section === undefined) return ''
  return renderPrompt({ ...assembly, sections: [section] })
}

function stageMetadata(assembly: PromptAssembly, fingerprint: Fingerprint): AssemblyStageMetadata {
  const renderedContexts = renderContextSections(assembly)
  return {
    sections: assembly.sections.map((section, index) => {
      let value: string
      try { value = renderSection(assembly, index) } catch { value = section.text }
      return named(section.name, index, value, fingerprint)
    }),
    contexts: renderedContexts.map((context, index) => named(context.name, index, context.text, fingerprint)),
    toolNames: assembly.tools.map(tool => tool.name),
    variableNames: Object.keys(assembly.variables),
  }
}

function exactJoinedSections(
  assembly: PromptAssembly,
  finalSystem: string,
  fingerprint: Fingerprint,
): NamedValueFingerprint[] | undefined {
  let rendered: string[]
  try {
    rendered = assembly.sections.map((_section, index) => renderSection(assembly, index))
  } catch {
    return undefined
  }
  const visible = rendered
    .map((text, index) => ({ text, index }))
    .filter(entry => entry.text.length > 0)
  if (visible.map(entry => entry.text).join('\n\n') !== finalSystem) return undefined
  let cursor = 0
  return visible.map((entry, outputIndex) => {
    const section = assembly.sections[entry.index]
    // entry.index is derived from assembly.sections.
    const start = cursor
    const end = start + entry.text.length
    cursor = end + (outputIndex === visible.length - 1 ? 0 : 2)
    return named(section?.name ?? 'unattributed:final-system', entry.index, entry.text, fingerprint, { start, end })
  })
}

function exactSingleSection(
  capture: CapturedAssembly,
  finalSystem: string,
  fingerprint: Fingerprint,
): NamedValueFingerprint[] | undefined {
  const candidates: Array<{ name: string; index: number; text: string }> = []
  for (const assembly of [capture.pre, capture.post]) {
    for (const [index, section] of assembly.sections.entries()) {
      try {
        const text = renderSection(assembly, index)
        if (text === finalSystem) candidates.push({ name: section.name, index, text })
      } catch {
        // An unrenderable public assembly cannot prove a mapping.
      }
    }
  }
  // The same named contribution may appear unchanged in both snapshots; that
  // is one candidate, not ambiguity. Distinct names remain deliberately unknown.
  const unique = new Map<string, { name: string; index: number; text: string }>()
  for (const candidate of candidates) unique.set(`${candidate.name}\u0000${candidate.text}`, candidate)
  if (unique.size !== 1) return undefined
  const candidate = [...unique.values()][0]
  if (candidate === undefined) return undefined
  return [named(candidate.name, candidate.index, candidate.text, fingerprint, {
    start: 0,
    end: finalSystem.length,
  })]
}

/**
 * Prove section spans only by exact equality. Anything else becomes one
 * explicitly unattributed synthetic section; this function never guesses.
 */
export function assemblyMetadata(
  capture: CapturedAssembly,
  finalSystem: string,
  fingerprint: Fingerprint,
): AssemblyMetadata {
  const pre = stageMetadata(capture.pre, fingerprint)
  const post = stageMetadata(capture.post, fingerprint)
  if (finalSystem.length === 0) {
    return {
      capturedAt: capture.capturedAt,
      pre,
      post,
      finalSystemMapping: 'empty',
      finalSections: [],
    }
  }
  const exact = exactJoinedSections(capture.post, finalSystem, fingerprint)
  if (exact !== undefined) {
    return {
      capturedAt: capture.capturedAt,
      pre,
      post,
      finalSystemMapping: 'exact-sections',
      finalSections: exact,
    }
  }
  const complete = exactSingleSection(capture, finalSystem, fingerprint)
  if (complete !== undefined) {
    return {
      capturedAt: capture.capturedAt,
      pre,
      post,
      finalSystemMapping: 'exact-single-section',
      finalSections: complete,
    }
  }
  return {
    capturedAt: capture.capturedAt,
    pre,
    post,
    finalSystemMapping: 'synthetic',
    finalSections: [named('unattributed:final-system', 0, finalSystem, fingerprint, {
      start: 0,
      end: finalSystem.length,
    })],
  }
}
