import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver'
import { SessionId } from '@deepseek-ai/dsh-session'
import {
  CONTEXT_LENS_API_PREFIX,
  CONTEXT_LENS_SCHEMA_VERSION,
  isAttemptId,
  type ErrorResponse,
  type ExportResponse,
  type CaptureDiagnosticsSnapshot,
  type HealthResponse,
  type JsonValue,
  type SessionAttemptsResponse,
  type SessionsResponse,
} from '../shared/contract.js'
import { ContextLensReconstructionError, reconstructAttempt } from './reconstruct.js'
import type { ContextLensStore } from './store.js'

const EMPTY_CAPTURE_DIAGNOSTICS: CaptureDiagnosticsSnapshot = {
  assemblyEvents: 0,
  preStepEvents: 0,
  llmStreamEvents: 0,
  markedAgentLoopRequests: 0,
  structurallyVerifiedAgentLoopRequests: 0,
  ignoredLlmStreams: 0,
  recordedAttempts: 0,
  failures: 0,
}

function isLoopbackAddress(address: string | undefined): boolean {
  if (address === undefined) return false
  if (address === '::1') return true
  const ipv4 = address.startsWith('::ffff:') ? address.slice(7) : address
  const parts = ipv4.split('.')
  return parts.length === 4
    && parts[0] === '127'
    && parts.every(part => /^\d{1,3}$/.test(part) && Number(part) <= 255)
}

function isLoopbackHostname(hostname: string): boolean {
  if (hostname === 'localhost' || hostname === '[::1]') return true
  const parts = hostname.split('.')
  return parts.length === 4
    && parts[0] === '127'
    && parts.every(part => /^\d{1,3}$/.test(part) && Number(part) <= 255)
}

function trustedRequest(req: IncomingMessage, port: number): boolean {
  if (!isLoopbackAddress(req.socket.remoteAddress)) return false
  const authority = req.headers.host
  if (typeof authority !== 'string') return false
  let host: URL
  try { host = new URL(`http://${authority}`) } catch { return false }
  if (!isLoopbackHostname(host.hostname)) return false
  const authorityPort = host.port === '' ? 80 : Number(host.port)
  if (authorityPort !== port) return false
  if (req.headers['sec-fetch-site'] === 'cross-site') return false
  const origin = req.headers.origin
  if (origin === undefined) return true
  if (typeof origin !== 'string') return false
  try { return new URL(origin).origin === host.origin } catch { return false }
}

function jsonBody(value: JsonValue): string {
  return `${JSON.stringify(value)}\n`
}

function sendJson(
  req: IncomingMessage,
  res: ServerResponse,
  status: number,
  value: unknown,
  headers: Record<string, string> = {},
): void {
  const body = jsonBody(value as JsonValue)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': String(Buffer.byteLength(body, 'utf8')),
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    ...headers,
  })
  res.end(req.method === 'HEAD' ? undefined : body)
}

function sendError(
  req: IncomingMessage,
  res: ServerResponse,
  status: number,
  code: string,
  message: string,
): void {
  const response: ErrorResponse = {
    schemaVersion: CONTEXT_LENS_SCHEMA_VERSION,
    error: { code, message },
  }
  sendJson(req, res, status, response)
}

function decodeSegment(segment: string | undefined): string | undefined {
  if (segment === undefined || segment.length === 0) return undefined
  try { return decodeURIComponent(segment) } catch { return undefined }
}

async function routeRequest(
  ctx: Context,
  store: ContextLensStore,
  capture: CaptureDiagnosticsSnapshot,
  req: IncomingMessage,
  res: ServerResponse,
): Promise<void> {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.setHeader('allow', 'GET, HEAD')
    sendError(req, res, 405, 'METHOD_NOT_ALLOWED', 'Only GET and HEAD are supported.')
    return
  }
  const pathname = new URL(req.url ?? '/', 'http://context-lens.invalid').pathname
  const suffix = pathname.slice(CONTEXT_LENS_API_PREFIX.length)
  const segments = suffix.split('/').filter(Boolean)

  if (segments.length === 1 && segments[0] === 'health') {
    const response: HealthResponse = {
      schemaVersion: CONTEXT_LENS_SCHEMA_VERSION,
      status: (!store.persistenceConfigured || (store.storageEnabled && store.lastError === undefined)) ? 'ok' : 'degraded',
      captureEnabled: true,
      persistenceConfigured: store.persistenceConfigured,
      storageEnabled: store.storageEnabled,
      attempts: store.attemptCount,
      sessions: store.sessionCount,
      capture: { ...capture },
      ...store.lastError === undefined ? {} : { lastError: store.lastError },
    }
    sendJson(req, res, 200, response)
    return
  }

  if (segments.length === 1 && segments[0] === 'sessions') {
    const response: SessionsResponse = {
      schemaVersion: CONTEXT_LENS_SCHEMA_VERSION,
      sessions: store.listSessions(),
    }
    sendJson(req, res, 200, response)
    return
  }

  if (segments[0] !== 'sessions') {
    sendError(req, res, 404, 'NOT_FOUND', 'Context Lens API route not found.')
    return
  }
  const sessionId = decodeSegment(segments[1])
  if (sessionId === undefined) {
    sendError(req, res, 400, 'INVALID_SESSION_ID', 'The session id is missing or malformed.')
    return
  }
  const attempts = store.attemptsFor(sessionId)
    ?? (ctx.sessions.get(SessionId(sessionId)) === undefined ? undefined : [])
  if (attempts === undefined) {
    sendError(req, res, 404, 'SESSION_NOT_FOUND', `No Context Lens capture exists for session "${sessionId}".`)
    return
  }

  if (segments.length === 2) {
    const response: SessionAttemptsResponse = {
      schemaVersion: CONTEXT_LENS_SCHEMA_VERSION,
      sessionId,
      attempts,
    }
    sendJson(req, res, 200, response)
    return
  }

  if (segments.length === 3 && segments[2] === 'export') {
    const details = await Promise.all(attempts.map(attempt => reconstructAttempt(ctx, store, attempt)))
    const response: ExportResponse = {
      schemaVersion: CONTEXT_LENS_SCHEMA_VERSION,
      generatedAt: Date.now(),
      sessionId,
      attempts: details,
    }
    sendJson(req, res, 200, response, {
      'content-disposition': 'attachment; filename="context-lens-export.json"',
    })
    return
  }

  if (segments.length === 4 && segments[2] === 'attempts') {
    const id = decodeSegment(segments[3])
    if (id === undefined || !isAttemptId(id)) {
      sendError(req, res, 400, 'INVALID_ATTEMPT_ID', 'The attempt id must have the form turn:step:attempt.')
      return
    }
    const attempt = store.attempt(sessionId, id)
    if (attempt === undefined) {
      sendError(req, res, 404, 'ATTEMPT_NOT_FOUND', `Attempt "${id}" was not retained.`)
      return
    }
    sendJson(req, res, 200, {
      schemaVersion: CONTEXT_LENS_SCHEMA_VERSION,
      sessionId,
      attempt: await reconstructAttempt(ctx, store, attempt),
    })
    return
  }

  sendError(req, res, 404, 'NOT_FOUND', 'Context Lens API route not found.')
}

/** Mount one official WebServer prefix route, owned by the plugin Fiber. */
export function installApi(
  ctx: Context,
  store: ContextLensStore,
  capture: CaptureDiagnosticsSnapshot = EMPTY_CAPTURE_DIAGNOSTICS,
): void {
  const route: WebRoute = {
    kind: 'prefix',
    path: CONTEXT_LENS_API_PREFIX,
    handler: async (req, res) => {
      if (!trustedRequest(req, ctx.webServer.port)) {
        sendError(req, res, 403, 'FORBIDDEN', 'Context Lens is available only to this loopback Web origin.')
        return
      }
      try {
        await routeRequest(ctx, store, capture, req, res)
      } catch (error) {
        if (error instanceof ContextLensReconstructionError) {
          sendError(req, res, error.code === 'SESSION_NOT_FOUND' ? 404 : 409, error.code, error.message)
          return
        }
        ctx.logger.warn(error)
        sendError(req, res, 500, 'INTERNAL_ERROR', 'Context Lens could not complete this read.')
      }
    },
  }
  ctx.effect(
    () => ctx.webServer.register(route),
    `context-lens: ${CONTEXT_LENS_API_PREFIX} route`,
  )
}

export const apiSecurity = { isLoopbackAddress, isLoopbackHostname, trustedRequest }
