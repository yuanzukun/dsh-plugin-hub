import { createHmac } from 'node:crypto'
import type { ValueFingerprint, ValueMetrics } from '../shared/contract.js'

function jsonText(value: unknown): string {
  const serialized = JSON.stringify(value)
  if (serialized === undefined) throw new Error('context-lens: measured value is not JSON-serializable')
  return serialized
}

/** Measure a value without retaining it. Strings use their model-visible text. */
export function measureValue(value: unknown, charsPerEstimatedToken: number): ValueMetrics {
  if (!Number.isFinite(charsPerEstimatedToken) || charsPerEstimatedToken <= 0) {
    throw new Error('context-lens: charsPerEstimatedToken must be a positive finite number')
  }
  const logical = jsonText(value)
  const visible = typeof value === 'string' ? value : logical
  return {
    utf8Bytes: Buffer.byteLength(visible, 'utf8'),
    utf16CodeUnits: visible.length,
    codePoints: [...visible].length,
    logicalJsonBytes: Buffer.byteLength(logical, 'utf8'),
    estimatedTokens: Math.ceil(visible.length / charsPerEstimatedToken),
  }
}

/** HMAC the typed JSON representation so low-entropy prompts are not guessable. */
export function fingerprintValue(
  key: Buffer,
  value: unknown,
  charsPerEstimatedToken: number,
): ValueFingerprint {
  const logical = jsonText(value)
  return {
    hmacSha256: createHmac('sha256', key).update(logical, 'utf8').digest('hex'),
    metrics: measureValue(value, charsPerEstimatedToken),
  }
}

export function addMetrics(...values: ValueMetrics[]): ValueMetrics {
  return values.reduce<ValueMetrics>((total, value) => ({
    utf8Bytes: total.utf8Bytes + value.utf8Bytes,
    utf16CodeUnits: total.utf16CodeUnits + value.utf16CodeUnits,
    codePoints: total.codePoints + value.codePoints,
    logicalJsonBytes: total.logicalJsonBytes + value.logicalJsonBytes,
    estimatedTokens: total.estimatedTokens + value.estimatedTokens,
  }), emptyMetrics())
}

export function subtractMetrics(current: ValueMetrics, previous?: ValueMetrics): ValueMetrics {
  if (previous === undefined) return { ...current }
  return {
    utf8Bytes: current.utf8Bytes - previous.utf8Bytes,
    utf16CodeUnits: current.utf16CodeUnits - previous.utf16CodeUnits,
    codePoints: current.codePoints - previous.codePoints,
    logicalJsonBytes: current.logicalJsonBytes - previous.logicalJsonBytes,
    estimatedTokens: current.estimatedTokens - previous.estimatedTokens,
  }
}

export function emptyMetrics(): ValueMetrics {
  return {
    utf8Bytes: 0,
    utf16CodeUnits: 0,
    codePoints: 0,
    logicalJsonBytes: 0,
    estimatedTokens: 0,
  }
}
