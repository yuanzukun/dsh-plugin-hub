import type { ISessions, SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import {
  ContextLensControllerRegistry,
  contextLensExportUrl,
} from './api-controller.ts'
import {
  contextLensRevisionDefinition,
  contextLensViewDefinition,
} from './conversation-revision.ts'
import { ContextLensView, type ContextLensViewInjected } from './ContextLensView.tsx'
import { en, NS, zh } from './locales.ts'

/** Required browser services for the session view contribution. */
export const inject = ['slots', 'conversationEvents', 'conversationViews', 'sessions', 'locale']

/** Register Context Lens replay signals and the session-scoped view tab. */
export function apply(ctx: ClientContext): void {
  const controllers = new ContextLensControllerRegistry()
  // The dual Host/browser package is typechecked in one program, where the
  // Host and Client both declaration-merge a service named `sessions`.
  // This browser entry narrows the injected service to its Client face.
  const sessions = ctx.get('sessions') as unknown as ISessions
  ctx.effect(() => () => { controllers.dispose() }, 'context-lens: controller registry')
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'context-lens: dictionaries')
  ctx.conversationEvents.register(contextLensRevisionDefinition)
  ctx.conversationViews.register(contextLensViewDefinition)
  const t = ctx.locale.bind(NS)

  ctx.slots.inject('conversation.view', () => ctx.slots.register({
    name: 'conversation.view',
    id: 'context-lens',
    order: 20,
    locale: NS,
    label: () => t('view.context'),
    inject: (sessionId: SessionId): ContextLensViewInjected => {
      const session = sessions.binding(sessionId)?.session
      if (session === undefined) {
        throw new Error(`context-lens: session "${sessionId}" is unavailable`)
      }
      const controller = controllers.get(String(sessionId), session)
      return {
        hooks: { contextLens: controller },
        refresh: () => controller.refresh(),
        loadAttempt: (id: string) => controller.loadAttempt(id),
        loadAllHistory: async () => {
          for (;;) {
            const before = session.getSnapshot()
            if (!before.hasMore || before.loadingOlder) return
            const firstSeq = before.views.get('context-lens')?.firstSeq
            await session.loadOlder()
            const after = session.getSnapshot()
            if (!after.hasMore || after.views.get('context-lens')?.firstSeq === firstSeq) return
          }
        },
        exportUrl: contextLensExportUrl(String(sessionId)),
      }
    },
  }, ContextLensView))
}
