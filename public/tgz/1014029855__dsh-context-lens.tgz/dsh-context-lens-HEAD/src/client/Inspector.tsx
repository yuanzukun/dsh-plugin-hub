import type { ReactNode } from 'react'
import { contextDiff } from './diff-model.ts'
import type { ContextSourceNode } from './source-model.ts'
import { sourceRaw } from './source-model.ts'
import type { ContextLensTranslate, InspectorMode } from './view-types.ts'
import css from './ContextLens.module.css'

interface InspectorProps {
  readonly source: ContextSourceNode | undefined
  readonly previous: ContextSourceNode | undefined
  readonly hasPreviousAttempt: boolean
  readonly mode: InspectorMode
  readonly onModeChange: (mode: InspectorMode) => void
  readonly t: ContextLensTranslate
}

function modeLabel(mode: InspectorMode, t: ContextLensTranslate): string {
  return t(`inspector.${mode}`)
}

function DiffBody({
  source,
  previous,
  hasPreviousAttempt,
  t,
}: Pick<InspectorProps, 'source' | 'previous' | 'hasPreviousAttempt' | 't'>): ReactNode {
  if (source === undefined) return null
  if (!hasPreviousAttempt) return <p className={css.inspectorNotice}>{t('inspector.noPrevious')}</p>
  if (!source.rawAvailable || previous?.rawAvailable === false) {
    const sameFingerprint = previous !== undefined
      && source.fingerprint !== undefined
      && previous.fingerprint !== undefined
      && source.fingerprint.hmacSha256 === previous.fingerprint.hmacSha256
    return <p className={css.inspectorNotice}>{sameFingerprint
      ? t('inspector.unchanged')
      : t('inspector.diffUnavailable')}</p>
  }
  const lines = contextDiff(previous?.raw ?? '', source.raw)
  if (previous !== undefined && lines.every(line => line.kind === 'same')) {
    return <p className={css.inspectorNotice}>{t('inspector.unchanged')}</p>
  }
  return (
    <pre className={css.diffCode} aria-label={t('inspector.diff')}>
      {lines.map((line, index) => (
        <span
          key={`${index}:${line.kind}`}
          className={line.kind === 'added'
            ? css.diffAdded
            : line.kind === 'removed' ? css.diffRemoved : css.diffSame}
        >
          <b aria-label={line.kind === 'added'
            ? t('inspector.added')
            : line.kind === 'removed' ? t('inspector.removed') : undefined}
          >{line.kind === 'added' ? '+' : line.kind === 'removed' ? '−' : ' '}</b>
          {line.text || ' '}
          {'\n'}
        </span>
      ))}
    </pre>
  )
}

/** Raw, structural JSON, and previous-attempt inspection of one source. */
export function Inspector({
  source,
  previous,
  hasPreviousAttempt,
  mode,
  onModeChange,
  t,
}: InspectorProps): ReactNode {
  return (
    <section className={css.inspector} aria-labelledby="context-lens-inspector-title">
      <div className={css.inspectorHeader}>
        <div>
          <h2 id="context-lens-inspector-title">{t('inspector.title')}</h2>
          {source === undefined ? null : <p>{source.label}</p>}
        </div>
        <div className={css.inspectorTabs} role="tablist" aria-label={t('inspector.title')}>
          {(['raw', 'diff', 'json'] as const).map(candidate => (
            <button
              key={candidate}
              type="button"
              role="tab"
              aria-selected={candidate === mode}
              className={candidate === mode ? css.inspectorTabActive : css.inspectorTab}
              onClick={() => { onModeChange(candidate) }}
            >
              {modeLabel(candidate, t)}
            </button>
          ))}
        </div>
      </div>
      {source === undefined
        ? <p className={css.inspectorEmpty}>{t('inspector.noSelection')}</p>
        : (
          <div className={css.inspectorContent} role="tabpanel">
            <dl className={css.sourceFacts}>
              <div><dt>{t('metrics.tokens')}</dt><dd>≈{source.metrics.estimatedTokens.toLocaleString()}</dd></div>
              <div><dt>{t('metrics.bytes')}</dt><dd>{source.metrics.utf8Bytes.toLocaleString()}</dd></div>
              <div><dt>{t('metrics.codeUnits')}</dt><dd>{source.metrics.utf16CodeUnits.toLocaleString()}</dd></div>
              {source.span === undefined ? null : (
                <div className={css.factWide}>
                  <dt>{t('inspector.span', { start: source.span.start, end: source.span.end })}</dt>
                  <dd>{source.span.end - source.span.start}</dd>
                </div>
              )}
              {source.fingerprint === undefined ? null : (
                <div className={css.factWide}>
                  <dt>{t('inspector.hmac')}</dt>
                  <dd title={source.fingerprint.hmacSha256}>
                    {source.fingerprint.hmacSha256.slice(0, 16)}…
                  </dd>
                </div>
              )}
            </dl>
            {mode === 'diff'
              ? <DiffBody source={source} previous={previous} hasPreviousAttempt={hasPreviousAttempt} t={t} />
              : mode === 'raw' && !source.rawAvailable
                ? <p className={css.inspectorNotice}>{t('inspector.rawUnavailable')}</p>
              : (
                <pre className={css.rawCode}>
                  {mode === 'json' ? sourceRaw(source.value) : source.raw}
                </pre>
              )}
          </div>
        )}
    </section>
  )
}
