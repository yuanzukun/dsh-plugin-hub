import type { CSSProperties, ReactNode } from 'react'
import type {
  ContextLensAttempt,
  ContextLensAttemptDetail,
  ValueMetrics,
} from '../shared/contract.ts'
import type { ContextSourceNode } from './source-model.ts'
import type { ContextLensTranslate } from './view-types.ts'
import css from './ContextLens.module.css'

interface BudgetSummaryProps {
  readonly attempt: ContextLensAttempt
  readonly detail: ContextLensAttemptDetail | undefined
  readonly sources: readonly ContextSourceNode[]
  readonly t: ContextLensTranslate
}

function compactNumber(value: number): string {
  return new Intl.NumberFormat(undefined, { notation: 'compact', maximumFractionDigits: 1 }).format(value)
}

function sumMetrics(nodes: readonly ContextSourceNode[]): ValueMetrics {
  return nodes.reduce<ValueMetrics>((total, source) => ({
    utf8Bytes: total.utf8Bytes + source.metrics.utf8Bytes,
    utf16CodeUnits: total.utf16CodeUnits + source.metrics.utf16CodeUnits,
    codePoints: total.codePoints + source.metrics.codePoints,
    logicalJsonBytes: total.logicalJsonBytes + source.metrics.logicalJsonBytes,
    estimatedTokens: total.estimatedTokens + source.metrics.estimatedTokens,
  }), { utf8Bytes: 0, utf16CodeUnits: 0, codePoints: 0, logicalJsonBytes: 0, estimatedTokens: 0 })
}

function MetricCard({ label, metrics }: { label: string; metrics: ValueMetrics }): ReactNode {
  return (
    <div className={css.metricCard}>
      <span>{label}</span>
      <strong>{compactNumber(metrics.estimatedTokens)}</strong>
      <small>{compactNumber(metrics.utf8Bytes)} B</small>
    </div>
  )
}

/** Exact byte/unit budget and explicitly heuristic token density. */
export function BudgetSummary({ attempt, detail, sources, t }: BudgetSummaryProps): ReactNode {
  const metrics = attempt.total.metrics
  const components = [
    { key: 'system', label: t('metrics.system'), value: attempt.system.metrics },
    { key: 'messages', label: t('metrics.messages'), value: attempt.messages.metrics },
    { key: 'tools', label: t('metrics.tools'), value: attempt.tools.metrics },
    { key: 'config', label: t('metrics.config'), value: attempt.config.metrics },
  ] as const
  const denominator = Math.max(1, components.reduce((sum, item) => sum + item.value.estimatedTokens, 0))
  const contexts = sumMetrics(sources.filter(source => source.group === 'context'))

  return (
    <section className={css.budget} aria-labelledby="context-lens-budget-title">
      <div className={css.budgetLead}>
        <div>
          <h2 id="context-lens-budget-title">{t('metrics.title')}</h2>
          <p>{t('metrics.estimated')}</p>
        </div>
        <div className={css.totalTokens}>
          <strong>{compactNumber(metrics.estimatedTokens)}</strong>
          <span>{t('metrics.tokens')}</span>
        </div>
      </div>
      <div className={css.budgetBar} aria-hidden="true">
        {components.map(item => (
          <span
            key={item.key}
            className={`${css.budgetSegment} ${css[`budgetSegment_${item.key}`]}`}
            style={{ '--lens-share': item.value.estimatedTokens / denominator } as CSSProperties}
          />
        ))}
      </div>
      <div className={css.metricGrid}>
        <MetricCard label={t('metrics.system')} metrics={attempt.system.metrics} />
        <MetricCard label={t('metrics.context')} metrics={contexts} />
        <MetricCard label={t('metrics.messages')} metrics={attempt.messages.metrics} />
        <MetricCard label={t('metrics.tools')} metrics={attempt.tools.metrics} />
        <MetricCard label={t('metrics.config')} metrics={attempt.config.metrics} />
      </div>
      <dl className={css.exactMetrics}>
        <div><dt>{t('metrics.bytes')}</dt><dd>{metrics.utf8Bytes.toLocaleString()}</dd></div>
        <div><dt>{t('metrics.codeUnits')}</dt><dd>{metrics.utf16CodeUnits.toLocaleString()}</dd></div>
        <div><dt>{t('metrics.codePoints')}</dt><dd>{metrics.codePoints.toLocaleString()}</dd></div>
        <div><dt>{t('metrics.jsonBytes')}</dt><dd>{metrics.logicalJsonBytes.toLocaleString()}</dd></div>
      </dl>
      <div className={css.healthRow}>
        <span>{attempt.health.captureProof === 'marker'
          ? t('health.markerProof') : t('health.sessionStructureProof')}</span>
        <span>{attempt.health.assembly === 'captured'
          ? t('health.assemblyCaptured') : t('health.assemblyUnavailable')}</span>
        <span>{attempt.health.messageMapping === 'exact'
          ? t('health.messageExact') : t('health.messageMismatch')}</span>
        <span>{attempt.health.persisted ? t('health.persisted') : t('health.notPersisted')}</span>
        {detail === undefined ? null : (
          <span>{detail.reconstruction.complete
            ? t('health.reconstructionComplete') : t('health.reconstructionPartial')}</span>
        )}
      </div>
    </section>
  )
}
