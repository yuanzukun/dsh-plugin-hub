import { diffLines } from 'diff'

export interface ContextDiffLine {
  readonly kind: 'same' | 'added' | 'removed'
  readonly text: string
}

/** Exact line diff used by the inspector's previous-attempt mode. */
export function contextDiff(previous: string, current: string): readonly ContextDiffLine[] {
  return diffLines(previous, current).flatMap((change) => {
    const kind: ContextDiffLine['kind'] = change.added
      ? 'added'
      : change.removed ? 'removed' : 'same'
    const text = change.value.endsWith('\n') ? change.value.slice(0, -1) : change.value
    return text.split('\n').map(line => ({ kind, text: line }))
  })
}
