import type { ReactNode } from 'react'
import type { ContextLensAttempt } from '../shared/contract.ts'
import type { ContextLensTranslate } from './view-types.ts'
import css from './ContextLens.module.css'

interface AttemptRailProps {
  readonly attempts: readonly ContextLensAttempt[]
  readonly selectedId: string | undefined
  readonly query: string
  readonly onSelect: (id: string) => void
  readonly t: ContextLensTranslate
}

function formatCapturedAt(timestamp: number): string {
  return new Intl.DateTimeFormat(undefined, {
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).format(timestamp)
}

function attemptText(attempt: ContextLensAttempt): string {
  return [
    attempt.id,
    attempt.provider,
    attempt.model,
    attempt.turn,
    attempt.step,
    attempt.attempt,
  ].join(' ').toLocaleLowerCase()
}

/** Ordered rail of every provider-neutral dispatch attempt. */
export function AttemptRail({ attempts, selectedId, query, onSelect, t }: AttemptRailProps): ReactNode {
  const normalized = query.trim().toLocaleLowerCase()
  const shown = normalized === ''
    ? attempts
    : attempts.filter(attempt => attemptText(attempt).includes(normalized))
  const latestId = attempts.at(-1)?.id

  return (
    <aside className={css.attemptRail} aria-labelledby="context-lens-attempts-title">
      <div className={css.paneHeader}>
        <h2 id="context-lens-attempts-title">{t('attempts.title')}</h2>
        <span>{t('attempts.count', { count: attempts.length })}</span>
      </div>
      {shown.length === 0
        ? <p className={css.paneEmpty}>{t('attempts.noMatch')}</p>
        : (
          <ol className={css.attemptList}>
            {shown.map((attempt) => {
              const selected = attempt.id === selectedId
              const changed = Object.values(attempt.diffFromPrevious.changed).some(Boolean)
              return (
                <li key={attempt.id}>
                  <button
                    type="button"
                    className={selected ? `${css.attemptButton} ${css.attemptButtonSelected}` : css.attemptButton}
                    aria-current={selected ? 'true' : undefined}
                    onClick={() => { onSelect(attempt.id) }}
                  >
                    <span className={css.attemptIndex} aria-hidden="true">
                      {String(attempts.indexOf(attempt) + 1).padStart(2, '0')}
                    </span>
                    <span className={css.attemptBody}>
                      <span className={css.attemptTopline}>
                        <strong>{t('attempts.turnStep', { turn: attempt.turn, step: attempt.step })}</strong>
                        {attempt.id === latestId
                          ? <span className={css.latestBadge}>{t('attempts.latest')}</span>
                          : null}
                      </span>
                      <span className={css.attemptModel}>{attempt.provider} / {attempt.model}</span>
                      <span className={css.attemptMeta}>
                        {t('attempts.attempt', { attempt: attempt.attempt })}
                        <span aria-hidden="true"> · </span>
                        {formatCapturedAt(attempt.capturedAt)}
                      </span>
                    </span>
                    <span
                      className={changed ? css.changeDot : css.stableDot}
                      title={changed ? t('diff.changed') : t('diff.unchanged')}
                    />
                  </button>
                </li>
              )
            })}
          </ol>
        )}
    </aside>
  )
}
