import type {
  ContextLensAttemptDetail,
  JsonValue,
  ValueFingerprint,
  ValueMetrics,
} from '../shared/contract.ts'

export type ContextSourceGroup = 'system' | 'context' | 'messages' | 'tools' | 'config'

/** One selectable piece of the exact reconstructed model request. */
export interface ContextSourceNode {
  readonly id: string
  readonly group: ContextSourceGroup
  readonly label: string
  readonly secondary?: string
  readonly raw: string
  /** False when the current Session window retained metadata but not raw text. */
  readonly rawAvailable: boolean
  readonly value: unknown
  readonly metrics: ValueMetrics
  readonly fingerprint?: ValueFingerprint
  readonly span?: { readonly start: number; readonly end: number }
  readonly searchText: string
}

const encoder = new TextEncoder()

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/** Stable readable JSON, retaining strings as their exact raw text. */
export function sourceRaw(value: unknown): string {
  if (typeof value === 'string') return value
  const encoded = JSON.stringify(value, null, 2)
  return encoded ?? String(value)
}

/** Exact browser-side sizes plus the same clearly labelled token heuristic. */
export function measureSource(value: unknown, charsPerEstimatedToken: number): ValueMetrics {
  const logical = JSON.stringify(value) ?? String(value)
  const visible = typeof value === 'string' ? value : logical
  return {
    utf8Bytes: encoder.encode(visible).byteLength,
    utf16CodeUnits: visible.length,
    codePoints: [...visible].length,
    logicalJsonBytes: encoder.encode(logical).byteLength,
    estimatedTokens: Math.ceil(visible.length / charsPerEstimatedToken),
  }
}

function messageRole(value: JsonValue): string {
  return isRecord(value) && typeof value.role === 'string' ? value.role : 'unknown'
}

function messageSource(value: JsonValue): Record<string, unknown> | undefined {
  return isRecord(value) && isRecord(value.source) ? value.source : undefined
}

function sourceName(source: Record<string, unknown>): string {
  for (const key of ['plugin', 'path', 'skill', 'kind'] as const) {
    if (typeof source[key] === 'string' && source[key] !== '') return source[key]
  }
  return 'unknown'
}

function textOfSection(value: unknown): string | undefined {
  return isRecord(value) && typeof value.text === 'string' ? value.text : undefined
}

function nameOfSection(value: unknown, fallback: string): string {
  return isRecord(value) && typeof value.name === 'string' && value.name !== ''
    ? value.name
    : fallback
}

function node(input: Omit<ContextSourceNode, 'metrics' | 'searchText' | 'rawAvailable'> & {
  readonly metrics?: ValueMetrics
  readonly rawAvailable?: boolean
}, charsPerEstimatedToken: number): ContextSourceNode {
  const metrics = input.metrics ?? measureSource(input.value, charsPerEstimatedToken)
  return {
    ...input,
    rawAvailable: input.rawAvailable ?? true,
    metrics,
    searchText: `${input.label}\n${input.secondary ?? ''}\n${input.raw}`.toLocaleLowerCase(),
  }
}

function systemNodes(detail: ContextLensAttemptDetail): ContextSourceNode[] {
  if (detail.reconstructedSections.length > 0) {
    return detail.reconstructedSections.map(section => node({
      id: `system:${section.index}:${section.name}`,
      group: 'system',
      label: section.name,
      secondary: section.attribution,
      raw: section.text,
      value: section.text,
      metrics: section.metrics,
      fingerprint: section,
      ...(section.span === undefined ? {} : { span: section.span }),
    }, detail.charsPerEstimatedToken))
  }
  if (detail.request.system === undefined) return []
  return [node({
    id: 'system:final',
    group: 'system',
    label: 'unattributed',
    raw: detail.request.system,
    value: detail.request.system,
    metrics: detail.system.metrics,
    fingerprint: detail.system,
  }, detail.charsPerEstimatedToken)]
}

function contextNodes(detail: ContextLensAttemptDetail): ContextSourceNode[] {
  const output: ContextSourceNode[] = []
  for (const [messageIndex, message] of detail.request.messages.entries()) {
    if (messageRole(message) !== 'user') continue
    const source = messageSource(message)
    if (source === undefined || source.kind === 'user') continue
    const sections = Array.isArray(source.sections) ? source.sections : []
    if (sections.length > 0) {
      for (const [sectionIndex, section] of sections.entries()) {
        const text = textOfSection(section)
        if (text === undefined) continue
        const name = nameOfSection(section, sourceName(source))
        output.push(node({
          id: `context:${messageIndex}:${sectionIndex}:${name}`,
          group: 'context',
          label: name,
          secondary: sourceName(source),
          raw: text,
          value: section,
          metrics: measureSource(text, detail.charsPerEstimatedToken),
        }, detail.charsPerEstimatedToken))
      }
      continue
    }
    output.push(node({
      id: `context:${messageIndex}:${sourceName(source)}`,
      group: 'context',
      label: sourceName(source),
      ...(typeof source.form === 'string' ? { secondary: source.form } : {}),
      raw: sourceRaw(message),
      value: message,
    }, detail.charsPerEstimatedToken))
  }
  // Named assembly contexts are metadata-only when their durable source
  // message could not be reconstructed in the current Session window.
  if (output.length === 0 && detail.assembly !== undefined) {
    for (const context of detail.assembly.post.contexts) {
      output.push(node({
        id: `context:assembly:${context.index}:${context.name}`,
        group: 'context',
        label: context.name,
        secondary: context.attribution,
        raw: '',
        rawAvailable: false,
        value: context,
        metrics: context.metrics,
        fingerprint: context,
      }, detail.charsPerEstimatedToken))
    }
  }
  return output
}

function messageNodes(detail: ContextLensAttemptDetail): ContextSourceNode[] {
  return detail.request.messages.map((message, index) => {
    const role = messageRole(message)
    const source = messageSource(message)
    return node({
      id: `messages:${index}`,
      group: 'messages',
      label: `${index + 1}:${role}`,
      ...(source === undefined ? {} : { secondary: sourceName(source) }),
      raw: sourceRaw(message),
      value: message,
    }, detail.charsPerEstimatedToken)
  })
}

function toolNodes(detail: ContextLensAttemptDetail): ContextSourceNode[] {
  return (detail.request.tools ?? []).map((tool, index) => {
    const fingerprint = detail.toolEntries.find(entry => entry.index === index)
    const name = isRecord(tool) && typeof tool.name === 'string'
      ? tool.name
      : fingerprint?.name ?? `#${index + 1}`
    return node({
      id: `tools:${index}:${name}`,
      group: 'tools',
      label: name,
      raw: sourceRaw(tool),
      value: tool,
      ...(fingerprint === undefined ? {} : {
        metrics: fingerprint.metrics,
        fingerprint,
      }),
    }, detail.charsPerEstimatedToken)
  })
}

function configNodes(detail: ContextLensAttemptDetail): ContextSourceNode[] {
  const config: Record<string, unknown> = {
    provider: detail.request.provider,
    model: detail.request.model,
    ...detail.request.reasoningEffort === undefined
      ? {} : { reasoningEffort: detail.request.reasoningEffort },
    ...detail.request.temperature === undefined ? {} : { temperature: detail.request.temperature },
    ...detail.request.maxTokens === undefined ? {} : { maxTokens: detail.request.maxTokens },
    ...detail.request.stop === undefined ? {} : { stop: detail.request.stop },
  }
  return Object.entries(config).map(([name, value]) => node({
    id: `config:${name}`,
    group: 'config',
    label: name,
    raw: sourceRaw(value),
    value,
  }, detail.charsPerEstimatedToken))
}

/** Build the five ordered source groups from an exact request reconstruction. */
export function buildContextSources(detail: ContextLensAttemptDetail): readonly ContextSourceNode[] {
  return [
    ...systemNodes(detail),
    ...contextNodes(detail),
    ...messageNodes(detail),
    ...toolNodes(detail),
    ...configNodes(detail),
  ]
}

/** Find the semantically corresponding source in the previous attempt. */
export function previousSource(
  current: ContextSourceNode,
  previous: readonly ContextSourceNode[],
): ContextSourceNode | undefined {
  return previous.find(candidate => candidate.id === current.id)
    ?? previous.find(candidate => candidate.group === current.group && candidate.label === current.label)
}
