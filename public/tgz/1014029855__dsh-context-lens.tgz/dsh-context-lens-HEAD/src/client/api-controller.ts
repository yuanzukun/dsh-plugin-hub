import type {
  AttemptDetailResponse,
  ContextLensAttempt,
  ContextLensAttemptDetail,
  SessionAttemptsResponse,
  ValueFingerprint,
  ValueMetrics,
} from '../shared/contract.ts'
import { CONTEXT_LENS_API_PREFIX, CONTEXT_LENS_SCHEMA_VERSION } from '../shared/contract.ts'

/** User-presentable failure categories; transport details stay out of the UI. */
export type ContextLensErrorCode = 'network' | 'not-found' | 'invalid-response' | 'unknown'

/** Immutable per-session Host API snapshot. */
export interface ContextLensClientSnapshot {
  readonly status: 'idle' | 'loading' | 'ready' | 'error'
  readonly error: ContextLensErrorCode | null
  readonly attempts: readonly ContextLensAttempt[]
  readonly details: Readonly<Record<string, ContextLensAttemptDetail>>
  readonly detailLoading: readonly string[]
  readonly detailErrors: Readonly<Record<string, ContextLensErrorCode>>
  readonly refreshedAt: number | null
}

interface RevisionSource {
  getSnapshot(): { readonly views: { get(key: string): unknown } }
  subscribe(listener: () => void): () => void
}

interface RevisionLike {
  readonly revision?: unknown
  readonly lastSeq?: unknown
}

type FetchLike = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>

const INITIAL: ContextLensClientSnapshot = Object.freeze({
  status: 'idle',
  error: null,
  attempts: Object.freeze([]),
  details: Object.freeze({}),
  detailLoading: Object.freeze([]),
  detailErrors: Object.freeze({}),
  refreshedAt: null,
})

class ContextLensWireError extends Error {
  constructor(readonly code: ContextLensErrorCode) {
    super(code)
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value)
}

function assertMetrics(value: unknown, allowNegative = false): asserts value is ValueMetrics {
  if (!isRecord(value)) throw new ContextLensWireError('invalid-response')
  for (const key of [
    'utf8Bytes', 'utf16CodeUnits', 'codePoints', 'logicalJsonBytes', 'estimatedTokens',
  ] as const) {
    if (!isFiniteNumber(value[key]) || (!allowNegative && value[key] < 0)) {
      throw new ContextLensWireError('invalid-response')
    }
  }
}

function assertFingerprint(value: unknown): asserts value is ValueFingerprint {
  if (!isRecord(value)
    || typeof value.hmacSha256 !== 'string'
    || !/^[a-f\d]{64}$/i.test(value.hmacSha256)) {
    throw new ContextLensWireError('invalid-response')
  }
  assertMetrics(value.metrics)
}

function assertNonNegativeInteger(value: unknown): asserts value is number {
  if (!isFiniteNumber(value) || !Number.isInteger(value) || value < 0) {
    throw new ContextLensWireError('invalid-response')
  }
}

function assertNamedFingerprint(value: unknown): void {
  assertFingerprint(value)
  if (!isRecord(value)
    || typeof value.name !== 'string'
    || (value.attribution !== 'named' && value.attribution !== 'unattributed')) {
    throw new ContextLensWireError('invalid-response')
  }
  assertNonNegativeInteger(value.index)
  if (value.span !== undefined) {
    if (!isRecord(value.span)) throw new ContextLensWireError('invalid-response')
    assertNonNegativeInteger(value.span.start)
    assertNonNegativeInteger(value.span.end)
    if (value.span.end < value.span.start) throw new ContextLensWireError('invalid-response')
  }
}

function assertAssemblyStage(value: unknown): void {
  if (!isRecord(value)
    || !Array.isArray(value.sections)
    || !Array.isArray(value.contexts)
    || !Array.isArray(value.toolNames)
    || !value.toolNames.every(name => typeof name === 'string')
    || !Array.isArray(value.variableNames)
    || !value.variableNames.every(name => typeof name === 'string')) {
    throw new ContextLensWireError('invalid-response')
  }
  for (const entry of [...value.sections, ...value.contexts]) assertNamedFingerprint(entry)
}

function assertAssembly(value: unknown): void {
  if (!isRecord(value)
    || !isFiniteNumber(value.capturedAt)
    || !['exact-sections', 'exact-single-section', 'synthetic', 'empty']
      .includes(String(value.finalSystemMapping))
    || !Array.isArray(value.finalSections)) {
    throw new ContextLensWireError('invalid-response')
  }
  assertAssemblyStage(value.pre)
  assertAssemblyStage(value.post)
  for (const entry of value.finalSections) assertNamedFingerprint(entry)
}

function assertAttempt(value: unknown): asserts value is ContextLensAttempt {
  if (!isRecord(value)) throw new ContextLensWireError('invalid-response')
  for (const key of ['id', 'sessionId', 'provider', 'model'] as const) {
    if (typeof value[key] !== 'string') throw new ContextLensWireError('invalid-response')
  }
  for (const key of ['turn', 'step', 'attempt', 'capturedAt', 'stepStartSeq', 'requestHeaderSeq'] as const) {
    assertNonNegativeInteger(value[key])
  }
  if (!isFiniteNumber(value.charsPerEstimatedToken) || value.charsPerEstimatedToken <= 0) {
    throw new ContextLensWireError('invalid-response')
  }
  if (!Array.isArray(value.messageEventSeqs)
    || !value.messageEventSeqs.every(item =>
      isFiniteNumber(item) && Number.isInteger(item) && item >= 0)) {
    throw new ContextLensWireError('invalid-response')
  }
  for (const key of ['config', 'system', 'messages', 'tools', 'total'] as const) {
    assertFingerprint(value[key])
  }
  if (!Array.isArray(value.toolEntries)) throw new ContextLensWireError('invalid-response')
  for (const entry of value.toolEntries) assertNamedFingerprint(entry)
  if (!isRecord(value.diffFromPrevious) || !isRecord(value.health)) {
    throw new ContextLensWireError('invalid-response')
  }
  const diff = value.diffFromPrevious
  if ((diff.previousAttemptId !== undefined && typeof diff.previousAttemptId !== 'string')
    || !isRecord(diff.changed)) {
    throw new ContextLensWireError('invalid-response')
  }
  for (const key of ['config', 'system', 'messages', 'tools'] as const) {
    if (typeof diff.changed[key] !== 'boolean') throw new ContextLensWireError('invalid-response')
  }
  assertMetrics(diff.totalsDelta, true)
  const health = value.health
  if (health.exactAgentLoopRequest !== true
    || (health.captureProof !== 'marker' && health.captureProof !== 'session-structure')
    || (health.messageMapping !== 'exact' && health.messageMapping !== 'mismatch')
    || (health.assembly !== 'captured' && health.assembly !== 'unavailable')
    || typeof health.persisted !== 'boolean') {
    throw new ContextLensWireError('invalid-response')
  }
  if (value.assembly !== undefined) assertAssembly(value.assembly)
}

function assertSessionResponse(value: unknown): asserts value is SessionAttemptsResponse {
  if (!isRecord(value)
    || value.schemaVersion !== CONTEXT_LENS_SCHEMA_VERSION
    || typeof value.sessionId !== 'string'
    || !Array.isArray(value.attempts)) {
    throw new ContextLensWireError('invalid-response')
  }
  for (const attempt of value.attempts) assertAttempt(attempt)
}

function assertDetailResponse(value: unknown): asserts value is AttemptDetailResponse {
  if (!isRecord(value)
    || value.schemaVersion !== CONTEXT_LENS_SCHEMA_VERSION
    || typeof value.sessionId !== 'string') {
    throw new ContextLensWireError('invalid-response')
  }
  assertAttempt(value.attempt)
  const attempt = value.attempt as unknown as Record<string, unknown>
  if (!isRecord(attempt.request)
    || !Array.isArray(attempt.reconstructedSections)
    || !isRecord(attempt.reconstruction)) {
    throw new ContextLensWireError('invalid-response')
  }
  const request = attempt.request
  if (typeof request.provider !== 'string'
    || typeof request.model !== 'string'
    || !Array.isArray(request.messages)
    || (request.system !== undefined && typeof request.system !== 'string')
    || (request.tools !== undefined && !Array.isArray(request.tools))
    || (request.reasoningEffort !== undefined && typeof request.reasoningEffort !== 'string')
    || (request.temperature !== undefined && !isFiniteNumber(request.temperature))
    || (request.maxTokens !== undefined
      && (!isFiniteNumber(request.maxTokens) || request.maxTokens < 0))
    || (request.stop !== undefined
      && (!Array.isArray(request.stop) || !request.stop.every(stop => typeof stop === 'string')))) {
    throw new ContextLensWireError('invalid-response')
  }
  for (const section of attempt.reconstructedSections) {
    assertNamedFingerprint(section)
    if (!isRecord(section) || typeof section.text !== 'string') {
      throw new ContextLensWireError('invalid-response')
    }
  }
  const reconstruction = attempt.reconstruction
  if ((reconstruction.source !== 'live-session' && reconstruction.source !== 'session-persistence')
    || typeof reconstruction.complete !== 'boolean'
    || !Array.isArray(reconstruction.warnings)
    || !reconstruction.warnings.every(warning => typeof warning === 'string')) {
    throw new ContextLensWireError('invalid-response')
  }
}

async function readJson(response: Response): Promise<unknown> {
  if (response.status === 404) throw new ContextLensWireError('not-found')
  if (!response.ok) throw new ContextLensWireError('network')
  try {
    return await response.json() as unknown
  } catch {
    throw new ContextLensWireError('invalid-response')
  }
}

function failureCode(error: unknown): ContextLensErrorCode {
  if (error instanceof ContextLensWireError) return error.code
  if (error instanceof TypeError) return 'network'
  return 'unknown'
}

function revisionOf(source: RevisionSource): string {
  const candidate = source.getSnapshot().views.get('context-lens') as RevisionLike | undefined
  return `${String(candidate?.revision ?? '')}:${String(candidate?.lastSeq ?? '')}`
}

/**
 * Bare observable owning all Host reads for one Session. React receives only
 * the framework-bound selector hook over this object.
 */
export class ContextLensSessionController {
  private snapshot: ContextLensClientSnapshot = INITIAL
  private readonly listeners = new Set<() => void>()
  private readonly requests = new Map<string, Promise<void>>()
  private readonly aborts = new Set<AbortController>()
  private readonly stopRevision: () => void
  private refreshPromise: Promise<void> | undefined
  private refreshRequested = false
  private refreshQueued = false
  private revision: string
  private disposed = false

  constructor(
    readonly sessionId: string,
    source: RevisionSource,
    private readonly fetcher: FetchLike = (input, init) => globalThis.fetch(input, init),
  ) {
    this.revision = revisionOf(source)
    this.stopRevision = source.subscribe(() => {
      const next = revisionOf(source)
      if (next === this.revision) return
      this.revision = next
      this.scheduleRefresh()
    })
    queueMicrotask(() => {
      if (!this.disposed) void this.refresh()
    })
  }

  /** Current stable snapshot. */
  readonly getSnapshot = (): ContextLensClientSnapshot => this.snapshot

  /** Subscribe to immutable snapshot replacement. */
  readonly subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener)
    return () => { this.listeners.delete(listener) }
  }

  private publish(patch: Partial<ContextLensClientSnapshot>): void {
    if (this.disposed) return
    this.snapshot = Object.freeze({ ...this.snapshot, ...patch })
    for (const listener of [...this.listeners]) {
      try {
        listener()
      } catch (error) {
        console.error('context-lens subscriber crashed:', error)
      }
    }
  }

  private scheduleRefresh(): void {
    if (this.disposed || this.refreshQueued) return
    this.refreshQueued = true
    queueMicrotask(() => {
      this.refreshQueued = false
      if (this.disposed) return
      void this.refresh()
    })
  }

  private async fetchJson(path: string): Promise<unknown> {
    if (this.disposed) throw new ContextLensWireError('unknown')
    const abort = new AbortController()
    this.aborts.add(abort)
    try {
      const response = await this.fetcher(path, {
        method: 'GET',
        credentials: 'same-origin',
        headers: { Accept: 'application/json' },
        signal: abort.signal,
      })
      return await readJson(response)
    } finally {
      this.aborts.delete(abort)
    }
  }

  private async readAttempts(): Promise<void> {
    try {
      const value = await this.fetchJson(
        `${CONTEXT_LENS_API_PREFIX}/sessions/${encodeURIComponent(this.sessionId)}`,
      )
      assertSessionResponse(value)
      if (value.sessionId !== this.sessionId) throw new ContextLensWireError('invalid-response')
      const retained = new Set(value.attempts.map(attempt => attempt.id))
      const details = Object.fromEntries(
        Object.entries(this.snapshot.details).filter(([id]) => retained.has(id)),
      )
      const detailErrors = Object.fromEntries(
        Object.entries(this.snapshot.detailErrors).filter(([id]) => retained.has(id)),
      )
      this.publish({
        status: 'ready',
        error: null,
        attempts: Object.freeze([...value.attempts]),
        details: Object.freeze(details),
        detailErrors: Object.freeze(detailErrors),
        refreshedAt: Date.now(),
      })
      const newest = value.attempts.at(-1)
      if (newest !== undefined) void this.loadAttempt(newest.id, true)
    } catch (error) {
      this.publish({ status: 'error', error: failureCode(error) })
    }
  }

  private async drainRefreshes(): Promise<void> {
    while (this.refreshRequested && !this.disposed) {
      this.refreshRequested = false
      await this.readAttempts()
    }
  }

  /** Re-read retained attempt metadata and eagerly hydrate the newest pair. */
  refresh(): Promise<void> {
    if (this.disposed) return Promise.resolve()
    this.refreshRequested = true
    if (this.refreshPromise !== undefined) return this.refreshPromise
    this.publish({
      status: this.snapshot.status === 'idle' ? 'loading' : this.snapshot.status,
      error: null,
    })
    const task = this.drainRefreshes()
    const settled = task.finally(() => {
      if (this.refreshPromise !== settled) return
      this.refreshPromise = undefined
      if (this.refreshRequested && !this.disposed) void this.refresh()
    })
    this.refreshPromise = settled
    return this.refreshPromise
  }

  /** Hydrate one exact request and, when requested, its predecessor for diff. */
  loadAttempt(id: string, includePrevious = true): Promise<void> {
    if (this.disposed) return Promise.resolve()
    if (this.snapshot.details[id] !== undefined) {
      if (includePrevious) this.loadPrevious(id)
      return Promise.resolve()
    }
    const inFlight = this.requests.get(id)
    if (inFlight !== undefined) return inFlight
    this.publish({
      detailLoading: Object.freeze([...new Set([...this.snapshot.detailLoading, id])]),
      detailErrors: Object.freeze(Object.fromEntries(
        Object.entries(this.snapshot.detailErrors).filter(([key]) => key !== id),
      )),
    })
    const task = (async () => {
      try {
        const value = await this.fetchJson(
          `${CONTEXT_LENS_API_PREFIX}/sessions/${encodeURIComponent(this.sessionId)}/attempts/${encodeURIComponent(id)}`,
        )
        assertDetailResponse(value)
        if (value.sessionId !== this.sessionId || value.attempt.id !== id) {
          throw new ContextLensWireError('invalid-response')
        }
        this.publish({
          details: Object.freeze({ ...this.snapshot.details, [id]: value.attempt }),
        })
        if (includePrevious) this.loadPrevious(id)
      } catch (error) {
        this.publish({
          detailErrors: Object.freeze({ ...this.snapshot.detailErrors, [id]: failureCode(error) }),
        })
      } finally {
        this.publish({
          detailLoading: Object.freeze(this.snapshot.detailLoading.filter(key => key !== id)),
        })
      }
    })()
    this.requests.set(id, task)
    return task.finally(() => { this.requests.delete(id) })
  }

  private loadPrevious(id: string): void {
    const index = this.snapshot.attempts.findIndex(attempt => attempt.id === id)
    const previous = index > 0 ? this.snapshot.attempts[index - 1] : undefined
    if (previous !== undefined) void this.loadAttempt(previous.id, false)
  }

  /** Stop timers and subscriptions when the plugin Fiber leaves. */
  dispose(): void {
    if (this.disposed) return
    this.disposed = true
    this.stopRevision()
    this.refreshRequested = false
    for (const abort of this.aborts) abort.abort()
    this.aborts.clear()
    this.listeners.clear()
  }
}

/** Apply-world cache preserving one observable identity per live Session source. */
export class ContextLensControllerRegistry {
  private readonly controllers = new Map<string, {
    readonly source: RevisionSource
    readonly controller: ContextLensSessionController
  }>()

  constructor(private readonly fetcher?: FetchLike) {}

  /** Return the stable controller associated with one live Session instance. */
  get(sessionId: string, source: RevisionSource): ContextLensSessionController {
    const current = this.controllers.get(sessionId)
    if (current?.source === source) return current.controller

    // SessionRuntime may prune a Session and later mint a new source for the
    // same id. The old source can no longer drive revision-based refreshes.
    current?.controller.dispose()
    const controller = new ContextLensSessionController(sessionId, source, this.fetcher)
    this.controllers.set(sessionId, { source, controller })
    return controller
  }

  /** Dispose every per-Session source on plugin teardown. */
  dispose(): void {
    for (const { controller } of this.controllers.values()) controller.dispose()
    this.controllers.clear()
  }
}

/** Same-origin diagnostic export URL for a Session. */
export function contextLensExportUrl(sessionId: string): string {
  return `${CONTEXT_LENS_API_PREFIX}/sessions/${encodeURIComponent(sessionId)}/export`
}
