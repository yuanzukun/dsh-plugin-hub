import { useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-runtime/client'
import type { InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots'
import type { ContextLensClientSnapshot, ContextLensErrorCode } from './api-controller.ts'
import { AttemptRail } from './AttemptRail.tsx'
import { BudgetSummary } from './BudgetSummary.tsx'
import { ContextLensToolbar } from './ContextLensToolbar.tsx'
import { EMPTY_CONTEXT_LENS_REVISION } from './conversation-revision.ts'
import { Inspector } from './Inspector.tsx'
import {
  buildContextSources,
  previousSource,
} from './source-model.ts'
import { SourceTree } from './SourceTree.tsx'
import type { InspectorMode } from './view-types.ts'
import css from './ContextLens.module.css'

/** Session-specific capabilities assembled in the registration's apply world. */
export interface ContextLensViewInjected {
  hooks: {
    /** Host API snapshot bound by the renderer as useContextLens. */
    contextLens: ObservableSnapshot<ContextLensClientSnapshot>
  }
  /** Explicit user-driven Host refresh. */
  refresh: () => Promise<void>
  /** Hydrate one request plus its predecessor for comparison. */
  loadAttempt: (id: string) => Promise<void>
  /** Page backward until the Session event window is complete. */
  loadAllHistory: () => Promise<void>
  /** Same-origin read-only diagnostic export. */
  exportUrl: string
}

/** Full four-share props for the conversation view entry. */
export type ContextLensViewProps =
  ConvViewProps
  & PropsLocale<'context-lens'>
  & InjectFace<ContextLensViewInjected>

function errorText(code: ContextLensErrorCode | null, t: ContextLensViewProps['t']): string {
  return t(`error.${code ?? 'unknown'}`)
}

/** Render the complete provider-neutral request inspector for one Session. */
export function ContextLensView(props: ContextLensViewProps): ReactNode {
  const {
    useSession,
    useContextLens,
    refresh,
    loadAttempt,
    loadAllHistory,
    exportUrl,
    t,
  } = props
  const [query, setQuery] = useState('')
  const [chosenAttemptId, setChosenAttemptId] = useState<string | undefined>()
  const [chosenSourceId, setChosenSourceId] = useState<string | undefined>()
  const [mode, setMode] = useState<InspectorMode>('raw')
  const lens = useContextLens(snapshot => snapshot)
  const revision = useSession(snapshot =>
    snapshot.views.get('context-lens') ?? EMPTY_CONTEXT_LENS_REVISION)
  const hasOlderHistory = useSession(snapshot => snapshot.hasMore)
  const historyLoading = useSession(snapshot => snapshot.loadingOlder)
  const attempts = lens.attempts
  const selectedAttempt = attempts.find(attempt => attempt.id === chosenAttemptId)
    ?? attempts.at(-1)
  const selectedDetail = selectedAttempt === undefined
    ? undefined
    : lens.details[selectedAttempt.id]
  const selectedIndex = selectedAttempt === undefined
    ? -1
    : attempts.findIndex(attempt => attempt.id === selectedAttempt.id)
  const previousAttempt = selectedIndex > 0 ? attempts[selectedIndex - 1] : undefined
  const previousDetail = previousAttempt === undefined ? undefined : lens.details[previousAttempt.id]
  const sources = useMemo(
    () => selectedDetail === undefined ? [] : buildContextSources(selectedDetail),
    [selectedDetail],
  )
  const previousSources = useMemo(
    () => previousDetail === undefined ? [] : buildContextSources(previousDetail),
    [previousDetail],
  )
  const normalizedQuery = query.trim().toLocaleLowerCase()
  const visibleSources = normalizedQuery === ''
    ? sources
    : sources.filter(source => source.searchText.includes(normalizedQuery))
  const selectedSource = visibleSources.find(source => source.id === chosenSourceId)
    ?? visibleSources[0]
  const comparedSource = selectedSource === undefined
    ? undefined
    : previousSource(selectedSource, previousSources)

  if (lens.status === 'loading' && attempts.length === 0) {
    return <div className={css.centerState} role="status">{t('state.loading')}</div>
  }
  if (lens.status === 'error' && attempts.length === 0) {
    return (
      <div className={css.centerState} role="alert">
        <h2>{t('state.error')}</h2>
        <p>{errorText(lens.error, t)}</p>
        <button type="button" className={css.primaryButton} onClick={() => { void refresh() }}>
          {t('state.retry')}
        </button>
      </div>
    )
  }
  if (lens.status === 'ready' && attempts.length === 0) {
    return (
      <div className={css.centerState}>
        <span className={css.emptyMark} aria-hidden="true">∅</span>
        <h2>{t('state.emptyTitle')}</h2>
        <p>{t('state.emptyBody')}</p>
      </div>
    )
  }

  return (
    <div className={css.root} data-conversation-composer-overlay="">
      <ContextLensToolbar
        query={query}
        onQueryChange={setQuery}
        onRefresh={() => { void refresh() }}
        exportUrl={exportUrl}
        t={t}
      />
      {hasOlderHistory
        ? (
          <div className={css.historyWarning} role="status">
            <span className={css.warningGlyph} aria-hidden="true">!</span>
            <span>
              <strong>{t('history.partialTitle')}</strong>
              <small>{t('history.partialBody')}</small>
            </span>
            <button
              type="button"
              disabled={historyLoading}
              onClick={() => { void loadAllHistory() }}
            >
              {historyLoading ? t('history.loading') : t('history.loadAll')}
            </button>
          </div>
        )
        : null}
      {lens.status === 'error'
        ? <div className={css.inlineError} role="alert">{errorText(lens.error, t)}</div>
        : null}
      {selectedAttempt === undefined
        ? null
        : (
          <BudgetSummary
            attempt={selectedAttempt}
            detail={selectedDetail}
            sources={sources}
            t={t}
          />
        )}
      <div className={css.workspace}>
        <AttemptRail
          attempts={attempts}
          selectedId={selectedAttempt?.id}
          query={query}
          onSelect={(id) => {
            setChosenAttemptId(id)
            setChosenSourceId(undefined)
            setMode('raw')
            void loadAttempt(id)
          }}
          t={t}
        />
        {selectedAttempt !== undefined && lens.detailErrors[selectedAttempt.id] !== undefined
          ? (
            <section className={css.detailError} role="alert">
              <p>{errorText(lens.detailErrors[selectedAttempt.id] ?? null, t)}</p>
              <button type="button" onClick={() => { void loadAttempt(selectedAttempt.id) }}>
                {t('state.retry')}
              </button>
            </section>
          )
          : selectedDetail === undefined
            ? <section className={css.detailLoading} role="status">{t('inspector.loading')}</section>
            : (
              <SourceTree
                sources={sources}
                selectedId={selectedSource?.id}
                query={query}
                onSelect={setChosenSourceId}
                t={t}
              />
            )}
        <Inspector
          source={selectedSource}
          previous={comparedSource}
          hasPreviousAttempt={previousAttempt !== undefined}
          mode={mode}
          onModeChange={setMode}
          t={t}
        />
      </div>
      <footer className={css.statusLine}>
        <span>{selectedAttempt === undefined
          ? null
          : t('attempts.seq', { seq: selectedAttempt.stepStartSeq })}</span>
        <span aria-hidden="true">rev {revision.revision}</span>
      </footer>
    </div>
  )
}
