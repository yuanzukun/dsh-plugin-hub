import type { ReactNode } from 'react'
import type { ContextLensTranslate } from './view-types.ts'
import css from './ContextLens.module.css'

interface ContextLensToolbarProps {
  readonly query: string
  readonly onQueryChange: (value: string) => void
  readonly onRefresh: () => void
  readonly exportUrl: string
  readonly t: ContextLensTranslate
}

/** Compact command strip for search, refresh, and safe JSON export. */
export function ContextLensToolbar({
  query,
  onQueryChange,
  onRefresh,
  exportUrl,
  t,
}: ContextLensToolbarProps): ReactNode {
  return (
    <div className={css.toolbar} role="toolbar" aria-label={t('toolbar.aria')}>
      <label className={css.searchField}>
        <span className={css.visuallyHidden}>{t('toolbar.search')}</span>
        <svg className={css.searchIcon} viewBox="0 0 16 16" aria-hidden="true">
          <circle cx="7" cy="7" r="4.25" />
          <path d="m10.25 10.25 3 3" />
        </svg>
        <input
          className={css.searchInput}
          type="search"
          value={query}
          spellCheck={false}
          placeholder={t('toolbar.searchPlaceholder')}
          onChange={event => { onQueryChange(event.target.value) }}
        />
      </label>
      <button type="button" className={css.toolbarButton} onClick={onRefresh}>
        <svg viewBox="0 0 16 16" aria-hidden="true">
          <path d="M13 5.5A5.5 5.5 0 1 0 13.25 10M13 2.5v3h-3" />
        </svg>
        <span>{t('toolbar.refresh')}</span>
      </button>
      <a className={css.toolbarButton} href={exportUrl} download>
        <svg viewBox="0 0 16 16" aria-hidden="true">
          <path d="M8 2v8m-3-3 3 3 3-3M3 12.5v1h10v-1" />
        </svg>
        <span>{t('toolbar.export')}</span>
      </a>
    </div>
  )
}
