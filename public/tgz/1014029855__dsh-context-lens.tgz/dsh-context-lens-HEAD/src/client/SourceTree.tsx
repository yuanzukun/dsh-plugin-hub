import type { ReactNode } from 'react'
import type { ContextSourceGroup, ContextSourceNode } from './source-model.ts'
import type { ContextLensTranslate } from './view-types.ts'
import css from './ContextLens.module.css'

interface SourceTreeProps {
  readonly sources: readonly ContextSourceNode[]
  readonly selectedId: string | undefined
  readonly query: string
  readonly onSelect: (id: string) => void
  readonly t: ContextLensTranslate
}

const GROUPS: readonly ContextSourceGroup[] = ['system', 'context', 'messages', 'tools', 'config']

function groupLabel(group: ContextSourceGroup, t: ContextLensTranslate): string {
  return t(`tree.${group}`)
}

function nodeLabel(source: ContextSourceNode, t: ContextLensTranslate): string {
  if (source.group === 'system') {
    return source.label === 'unattributed' ? t('tree.unattributed') : source.label
  }
  if (source.group === 'messages') {
    const [index, role] = source.label.split(':')
    return t('tree.message', { index, role: role ?? t('tree.unknownRole') })
  }
  if (source.group === 'tools') {
    const index = source.id.split(':')[1]
    return t('tree.tool', { index: Number(index) + 1, name: source.label })
  }
  if (source.group === 'context') return source.label
  return t('tree.configItem', { name: source.label })
}

/** Five-group request source navigator. */
export function SourceTree({ sources, selectedId, query, onSelect, t }: SourceTreeProps): ReactNode {
  const normalized = query.trim().toLocaleLowerCase()
  const filtered = normalized === ''
    ? sources
    : sources.filter(source => source.searchText.includes(normalized))

  return (
    <nav className={css.sourceTree} aria-labelledby="context-lens-sources-title">
      <div className={css.paneHeader}>
        <h2 id="context-lens-sources-title">{t('tree.title')}</h2>
        <span>{filtered.length}</span>
      </div>
      {filtered.length === 0
        ? <p className={css.paneEmpty}>{t('tree.noMatch')}</p>
        : (
          <div className={css.sourceGroups}>
            {GROUPS.map((group) => {
              const rows = filtered.filter(source => source.group === group)
              if (rows.length === 0) return null
              return (
                <section key={group} className={css.sourceGroup}>
                  <h3>
                    <span>{groupLabel(group, t)}</span>
                    <small>{rows.length}</small>
                  </h3>
                  <ul>
                    {rows.map(source => (
                      <li key={source.id}>
                        <button
                          type="button"
                          className={source.id === selectedId
                            ? `${css.sourceButton} ${css.sourceButtonSelected}`
                            : css.sourceButton}
                          aria-pressed={source.id === selectedId}
                          onClick={() => { onSelect(source.id) }}
                        >
                          <span className={css.sourceGlyph} data-group={group} aria-hidden="true" />
                          <span className={css.sourceBody}>
                            <strong>{nodeLabel(source, t)}</strong>
                            {source.secondary === undefined
                              ? null : <small>{source.secondary}</small>}
                            {source.rawAvailable ? null : <small>{t('tree.metadataOnly')}</small>}
                          </span>
                          <span className={css.sourceTokens}>
                            ≈{source.metrics.estimatedTokens.toLocaleString()}
                          </span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </section>
              )
            })}
          </div>
        )}
    </nav>
  )
}
