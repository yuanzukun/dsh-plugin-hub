import type {
  ConversationMatch,
  ConversationNodeContext,
  ConversationNodeDefinition,
  ConversationViewBuilder,
  ConversationViewDefinition,
  ConversationViewNode,
} from '@deepseek-ai/dsh-client-runtime/client'

const REFRESH_EVENTS = new Set([
  'turn/start',
  'turn/end',
  'step/start',
  'step/end',
  'request/header',
  'user/message',
  'assistant/message',
  'tool/result',
])

interface RevisionState {
  readonly seq: number
  readonly type: string
}

interface ContextLensRevisionNode extends ConversationViewNode {
  readonly target: 'context-lens'
  readonly anchorSeq: number
  readonly eventType: string
}

/** Small replay-derived signal used only to refresh Host-owned lens data. */
export interface ContextLensRevisionSnapshot {
  readonly revision: number
  readonly firstSeq: number | null
  readonly lastSeq: number | null
}

declare module '@deepseek-ai/dsh-client-runtime/client' {
  interface ConversationViewSnapshotMap {
    /** Revision signal for the Context Lens Host-side attempt ledger. */
    'context-lens': ContextLensRevisionSnapshot
  }
}

export const EMPTY_CONTEXT_LENS_REVISION: ContextLensRevisionSnapshot = Object.freeze({
  revision: 0,
  firstSeq: null,
  lastSeq: null,
})

function stateFrom(match: ConversationMatch): RevisionState {
  return { seq: match.event.seq, type: match.event.type }
}

/** Definition that projects only low-frequency request lifecycle anchors. */
export const contextLensRevisionDefinition: ConversationNodeDefinition<RevisionState> = {
  kind: 'context-lens-revision',
  target: 'context-lens',
  match: event => REFRESH_EVENTS.has(event.type)
    ? { id: String(event.seq), role: 'start' }
    : null,
  start: (_context, match) => stateFrom(match),
  update: (_context, match) => stateFrom(match),
  buildViewNode: context => context.state === undefined
    ? null
    : {
      key: context.key,
      kind: context.kind,
      id: context.id,
      target: 'context-lens',
      data: null,
      anchorSeq: context.state.seq,
      eventType: context.state.type,
    },
}

/** Incremental builder retaining only event anchors, never prompt content. */
export class ContextLensRevisionBuilder implements ConversationViewBuilder<
  ContextLensRevisionNode,
  ContextLensRevisionSnapshot
> {
  readonly empty = EMPTY_CONTEXT_LENS_REVISION
  private readonly nodes = new Map<string, ContextLensRevisionNode>()
  private snapshot = EMPTY_CONTEXT_LENS_REVISION

  replace(input: { readonly nodes: readonly ContextLensRevisionNode[] }): ContextLensRevisionSnapshot {
    this.nodes.clear()
    for (const node of input.nodes) this.nodes.set(node.key, node)
    return this.rebuild()
  }

  apply(input: { readonly upserts: readonly ContextLensRevisionNode[] }): ContextLensRevisionSnapshot {
    if (input.upserts.length === 0) return this.snapshot
    for (const node of input.upserts) this.nodes.set(node.key, node)
    return this.rebuild()
  }

  private rebuild(): ContextLensRevisionSnapshot {
    let firstSeq: number | null = null
    let lastSeq: number | null = null
    for (const node of this.nodes.values()) {
      firstSeq = firstSeq === null ? node.anchorSeq : Math.min(firstSeq, node.anchorSeq)
      lastSeq = lastSeq === null ? node.anchorSeq : Math.max(lastSeq, node.anchorSeq)
    }
    this.snapshot = Object.freeze({
      revision: this.snapshot.revision + 1,
      firstSeq,
      lastSeq,
    })
    return this.snapshot
  }
}

/** Session-local snapshot builder registered under the lens view target. */
export const contextLensViewDefinition: ConversationViewDefinition<
  ContextLensRevisionNode,
  ContextLensRevisionSnapshot
> = {
  target: 'context-lens',
  create: () => new ContextLensRevisionBuilder(),
}

/** Build a node directly in focused tests. */
export function revisionNode(
  context: ConversationNodeContext<RevisionState>,
): ContextLensRevisionNode | null {
  return context.state === undefined
    ? null
    : {
      key: context.key,
      kind: context.kind,
      id: context.id,
      target: 'context-lens',
      data: null,
      anchorSeq: context.state.seq,
      eventType: context.state.type,
    }
}
