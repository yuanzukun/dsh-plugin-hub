/**
 * dsh-context-lens — provider-neutral request diagnostics for DeepSeek Harness.
 *
 * The Host half observes official waterfalls, stores metadata-only sidecars,
 * and serves a loopback-fenced read API. It never appends a session event.
 */

import { join } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import Schema from '@deepseek-ai/schemastery'
import { resolveDshHome } from '@deepseek-ai/dsh-home-paths'
import type {} from '@deepseek-ai/dsh-agent'
import type {} from '@deepseek-ai/dsh-host-webserver'
import type {} from '@deepseek-ai/dsh-llm'
import type {} from '@deepseek-ai/dsh-session'
import type {} from '@deepseek-ai/dsh-system-prompt'
import { installApi } from './host/api.js'
import { installCapture } from './host/capture.js'
import { ContextLensStore } from './host/store.js'

export const name = 'dsh-context-lens'
export const inject = ['llm', 'sessions', 'systemPrompt', 'webServer']

export interface Config {
  /** Write metadata-only sidecars; false keeps captures process-local. */
  persistMetadata: boolean
  /** Retained metadata attempts per session; older entries are dropped. */
  maxAttemptsPerSession: number
  /** Fixed-density token estimate denominator; estimates are labelled as such. */
  charsPerEstimatedToken: number
}

export const Config: Schema<Config> = Schema.object({
  persistMetadata: Schema.boolean().default(true),
  maxAttemptsPerSession: Schema.number()
    .step(1)
    .min(1)
    .max(Number.MAX_SAFE_INTEGER)
    .default(500),
  charsPerEstimatedToken: Schema.number()
    .min(Number.MIN_VALUE)
    .max(Number.MAX_SAFE_INTEGER)
    .default(4),
})

/** Install all registrations after required official services are ready. */
export async function apply(ctx: Context, config: Config): Promise<void> {
  const store = await ContextLensStore.open({
    rootDir: join(resolveDshHome(), 'context-lens', 'v1'),
    persistMetadata: config.persistMetadata,
    maxAttemptsPerSession: config.maxAttemptsPerSession,
    charsPerEstimatedToken: config.charsPerEstimatedToken,
    logger: ctx.logger,
  })

  // Registered first so reverse-order unload removes routes/listeners before
  // awaiting the last sidecar commit.
  ctx.effect(() => async () => { await store.flush() }, 'context-lens: flush sidecar')
  const capture = installCapture(ctx, store)
  installApi(ctx, store, capture)
}

export * from './shared/contract.js'
