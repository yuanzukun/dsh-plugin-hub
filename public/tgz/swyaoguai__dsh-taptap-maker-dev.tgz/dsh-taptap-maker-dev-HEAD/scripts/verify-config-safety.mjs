/**
 * 配置安全的离线自测（不联网、不花额度）。
 *
 * 这一组盯的是「配置会不会莫名其妙丢」——这类问题平时看不见，一旦发生用户
 * 往往完全无从查起（Key 没了、通道顺序没了、文件读不出来）。三条主线：
 *
 *   1. 原子写：崩溃/并发不会留下半截 JSON
 *   2. 损坏留证：读失败时留一份 .corrupt 现场，而不是静默吞掉
 *   3. 空串 = 不修改：设置页不回显明文 Key，表单里那项恒为空；
 *      如果把空串当值写回去，用户「只改个 model」就会把 Key 抹掉
 *
 * 用法：node scripts/verify-config-safety.mjs
 */
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

import {
  readGptDownloadDir, readImageConfigRaw, readJson, readMinimaxConfigRaw,
  readMinimaxConfigWithSource, resolveImageConfig, resolveMinimaxConfig,
  writeGptDownloadDir, writeImageConfigPatch, writeJson, writeMinimaxConfigPatch,
  maskSecret, readZaiduyuConfigRaw, writeZaiduyuConfigPatch, clearZaiduyuCredentials, resolveZaiduyuCredentials,
} from '../src/paths.js'

let passed = 0
let failed = 0
const ok = (cond, label, extra = '') => {
  if (cond) { passed += 1; console.log(`  ✓ ${label}`) }
  else { failed += 1; console.log(`  ✗ ${label}${extra ? ` — ${extra}` : ''}`) }
}

const scratch = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-cfg-safety-'))
console.log(`临时目录：${scratch}\n`)

console.log('\n[1] 原子写：不会留下半截文件')
{
  const dir = path.join(scratch, 'atomic')
  const f = path.join(dir, 'cfg.json')
  writeJson(f, { a: 1, note: 'hello' })
  ok(JSON.stringify(readJson(f)) === '{"a":1,"note":"hello"}', '正常写入可读回')
  ok(fs.readdirSync(dir).every((x) => !x.includes('.tmp')), '写完不留 .tmp 残留')

  const src = fs.readFileSync(new URL('../src/paths.js', import.meta.url), 'utf8')
  const fn = /export function writeJson\(file, value\) \{[\s\S]*?\n\}/.exec(src)?.[0] ?? ''
  ok(fn.includes('renameSync'), '用 rename 做最终替换（原子）')
  ok(/const tmp = /.test(fn), '先写临时文件')
  const iTmp = fn.indexOf('writeFileSync(tmp')
  const iRename = fn.indexOf('renameSync(tmp, file)')
  ok(iTmp >= 0 && iRename > iTmp, '顺序是「先写 tmp 再 rename」')
  ok(/rmSync\(tmp/.test(fn), '失败时清理临时文件')
}

console.log('\n[2] 损坏的配置文件：留证据而不是静默吞掉')
{
  const dir = path.join(scratch, 'corrupt')
  const f = path.join(dir, 'cfg.json')
  fs.mkdirSync(dir, { recursive: true })
  fs.writeFileSync(f, '{ 半个 JSON')
  ok(readJson(f) === undefined, '损坏时返回 undefined（调用方不会崩）')
  ok(fs.readdirSync(dir).some((x) => x.includes('.corrupt-')), '损坏文件被另存为 .corrupt-<ts>，留现场')
  const kept = fs.readdirSync(dir).find((x) => x.includes('.corrupt-'))
  ok(fs.readFileSync(path.join(dir, kept), 'utf8') === '{ 半个 JSON', '备份内容与原文件一致')

  const before = fs.readdirSync(dir).length
  ok(readJson(path.join(dir, 'missing.json')) === undefined, '读不存在的文件返回 undefined')
  ok(fs.readdirSync(dir).length === before, '「文件不存在」是正常情况，不产生 .corrupt 垃圾')
}

console.log('\n[3] 空串 = 不修改（设置页只改一项不该抹掉其他项）')
{
  const home = path.join(scratch, 'h1')
  writeImageConfigPatch(home, { baseURL: 'https://api.example.com/v1', apiKey: 'sk-precious', model: 'gpt-image' })

  // 设置页 GET 不回显 Key → 表单里 apiKey 恒为 '' → 用户只改 model 后保存
  writeImageConfigPatch(home, { baseURL: 'https://api.example.com/v1', apiKey: '', model: 'gpt-image-2.5' })
  const after = readImageConfigRaw(home)
  ok(after.apiKey === 'sk-precious', '只改 model 时 apiKey 保住（这正是修复前的数据丢失 bug）', after.apiKey)
  ok(after.model === 'gpt-image-2.5', 'model 确实被更新')
  ok(after.baseURL === 'https://api.example.com/v1', 'baseURL 未受影响')

  // 显式 clear 仍然能真清空（不能把「清空」功能一起堵死）
  writeImageConfigPatch(home, { apiKey: '', clear: true })
  ok(readImageConfigRaw(home).apiKey === '', 'clear:true 仍能真正清空 Key（没有把功能堵死）')
}

console.log('\n[4] 目录配置：空串在这里是**合法值**（reset 用）')
{
  const home = path.join(scratch, 'h2')
  writeGptDownloadDir(home, '/custom/img')
  ok(readGptDownloadDir(home) === '/custom/img', '图片目录写入正常')

  // ⚠️ 这里跟 image.json 的规则**故意不同**：`/game-image dir --reset`
  // 就是靠传空串来「恢复跟随项目」的，所以不能把空串拦成「不修改」。
  writeGptDownloadDir(home, '')
  ok(readGptDownloadDir(home) === '', '空串在此处表示「恢复默认」（reset 的既有语义，不能改）')

  const src = fs.readFileSync(new URL('../src/game-image-web.mjs', import.meta.url), 'utf8')
  ok(/writeGptDownloadDir\(home, ''\)/.test(src), 'reset 走的是显式传空串，与其它配置区分开')
}

console.log('\n[5] 同一套规则覆盖到视频中转站配置')
{
  const src = fs.readFileSync(new URL('../src/paths.js', import.meta.url), 'utf8')
  const fn = /export function writeVideoRelayConfigPatch[\s\S]*?return merged\n\}/.exec(src)?.[0] ?? ''
  ok(fn.length > 0, '能找到 writeVideoRelayConfigPatch')
  ok(/patch\[key\]\.trim\(\) === ''/.test(fn), '中转站配置也把空串视为「不修改」')
  ok(/patch\.clear === true/.test(fn), '支持 clear:true 显式清空')
}

console.log('\n[6] 表单 seed 只在首次落盘（清空/改过不被表单旧值复活）')
{
  // seed 的语义：config 表单值仅当目标文件**不存在**时写入一次。之后无论
  // 表单里留着什么旧值，都不能把用户已保存/清空的设置改回去。
  // （修复前：minimax 的 Key 被用户清空后，重启即被表单旧值复活；image 的
  //   baseURL 每次启动都被表单值覆盖 —— 都是「设置不生效」的实锤。）
  const src = fs.readFileSync(new URL('../index.js', import.meta.url), 'utf8')
  const seedImage = /function seedImageConfig[\s\S]*?\n\}/.exec(src)?.[0] ?? ''
  ok(seedImage.length > 0, '能找到 seedImageConfig')
  ok(/existsSync\(file\)\s*\)\s*return file/.test(seedImage), 'image seed：文件已存在时直接返回（不覆盖）')
  ok(!/existing\[key\] !== value/.test(seedImage), 'image seed：不再按表单值覆盖已保存的配置')
  const seedMinimax = /function seedMinimaxConfig[\s\S]*?\n\}/.exec(src)?.[0] ?? ''
  ok(seedMinimax.length > 0, '能找到 seedMinimaxConfig')
  ok(/existsSync\(file\)\s*\)\s*return/.test(seedMinimax), 'minimax seed：文件已存在时直接返回（清空的 Key 不会被复活）')
}

console.log('\n[7] 配置优先级：设置页文件压过环境变量（「保存了却不生效」的根因）')
{
  // 2026-10-25 实测：机器注册表里残留着一个**已失效**的 MINIMAX_API_KEY，
  // 设置页保存的 JWT Key 是有效的。旧优先级 env > file 让 DSH 每次重启后
  // 都读到失效 Key —— 显示已保存、实际鉴权失败。文件是用户显式保存的地方，
  // 必须最优先；显式传参（函数 options）仍然最高。
  const savedEnv = {
    MINIMAX_API_KEY: process.env.MINIMAX_API_KEY,
    MINIMAX_BASE_URL: process.env.MINIMAX_BASE_URL,
    MINIMAX_VIDEO_MODEL: process.env.MINIMAX_VIDEO_MODEL,
    TAPTAP_IMAGE_API_KEY: process.env.TAPTAP_IMAGE_API_KEY,
    TAPTAP_IMAGE_BASE_URL: process.env.TAPTAP_IMAGE_BASE_URL,
    TAPTAP_IMAGE_MODEL: process.env.TAPTAP_IMAGE_MODEL,
    TAPTAP_IMAGE_SIZE: process.env.TAPTAP_IMAGE_SIZE,
  }
  process.env.MINIMAX_API_KEY = 'sk-env-old-invalid'
  process.env.MINIMAX_BASE_URL = 'https://api.minimax.io'
  process.env.MINIMAX_VIDEO_MODEL = 'Env-Model'
  process.env.TAPTAP_IMAGE_API_KEY = 'sk-env-image'
  process.env.TAPTAP_IMAGE_BASE_URL = 'https://env.example.com/v1'
  process.env.TAPTAP_IMAGE_MODEL = 'env-image-model'
  delete process.env.TAPTAP_IMAGE_SIZE
  try {
    const home = path.join(scratch, 'h3')
    writeMinimaxConfigPatch(home, { apiKey: 'sk-file-new-valid', baseURL: 'https://api.minimaxi.com', model: 'MiniMax-H3' })
    const mmx = resolveMinimaxConfig(home)
    ok(mmx.apiKey === 'sk-file-new-valid', 'minimax：文件里的 Key 压过环境变量（修复前 env 优先 → 读到失效旧 Key）', mmx.apiKey)
    ok(mmx.baseURL === 'https://api.minimaxi.com', 'minimax：文件里的站点压过环境变量')
    ok(mmx.model === 'MiniMax-H3', 'minimax：文件里的模型压过环境变量')

    // 文件里没有的字段才回落到 env（回落仍要可用，不能把 env 功能砍死）。
    const home2 = path.join(scratch, 'h4')
    const mmx2 = resolveMinimaxConfig(home2)
    ok(mmx2.apiKey === 'sk-env-old-invalid', 'minimax：文件没有 Key 时回落到环境变量（CI 场景仍可用）')

    // 生图同规则。
    const home3 = path.join(scratch, 'h5')
    writeImageConfigPatch(home3, { baseURL: 'https://file.example.com/v1', apiKey: 'sk-file-image', model: 'file-model' })
    const img = resolveImageConfig({ dshHome: home3 })
    ok(img.apiKey === 'sk-file-image', 'image：文件里的 Key 压过环境变量')
    ok(img.baseURL === 'https://file.example.com/v1', 'image：文件里的 baseURL 压过环境变量')
    // 显式传参最高（既有行为，不能被这次调序破坏）。
    const img2 = resolveImageConfig({ dshHome: home3, apiKey: 'sk-explicit' })
    ok(img2.apiKey === 'sk-explicit', 'image：显式传参仍最优先')

    // 来源标注（doctor / 设置页据此亮出「Key 来自哪里」）。
    const src3 = readMinimaxConfigWithSource(home)
    ok(src3.source.apiKey === 'file' && src3.apiKey === 'sk-file-new-valid', '来源标注：文件优先时报 file')
    const src4 = readMinimaxConfigWithSource(home2)
    ok(src4.source.apiKey === 'env' && src4.source.envKeyUsable === true, '来源标注：仅 env 有 Key 时报 env 并标 envKeyUsable')
    const src5 = readMinimaxConfigWithSource(path.join(scratch, 'h6'))
    ok(src5.source.apiKey === 'env' && src5.source.envKeyPresent === true, '来源标注：无文件配置时报 env（env 是唯一来源）')
  } finally {
    for (const [k, v] of Object.entries(savedEnv)) {
      if (v === undefined) delete process.env[k]
      else process.env[k] = v
    }
  }
}

console.log('\n[8] 版本升级迁移：music.json → minimax.json（升级不再丢 Key）')
{
  // 0.1.0 把 MiniMax 配置存 music.json，0.2.0 改名 minimax.json 却没有迁移 ——
  // 升级即「Key 凭空消失」。迁移必须满足：只在 minimax.json 不存在时做；
  // 空文件不迁；迁完旧文件留档不删。
  const src = fs.readFileSync(new URL('../index.js', import.meta.url), 'utf8')
  const fn = /function migrateLegacyConfigs[\s\S]*?\n\}/.exec(src)?.[0] ?? ''
  ok(fn.length > 0, '能找到 migrateLegacyConfigs')
  ok(/existsSync\(newFile\)\s*\) return/.test(fn), 'minimax.json 已存在时不迁移（不覆盖新版配置）')
  ok(/music\.json/.test(fn), '迁移来源是 music.json')
  ok(/renameSync/.test(fn), '迁移后旧文件改名留档（不删除）')

  // 真跑一遍迁移逻辑（函数未导出，按相同规则在临时目录里验证行为）。
  const home = path.join(scratch, 'h7')
  fs.mkdirSync(path.join(home, 'game-forge'), { recursive: true })
  const legacy = path.join(home, 'game-forge', 'music.json')
  writeJson(legacy, { apiKey: 'sk-legacy-key', baseURL: 'https://api.minimaxi.com', model: 'MiniMax-H3' })
  writeMinimaxConfigPatch(home, { apiKey: 'sk-legacy-key', baseURL: 'https://api.minimaxi.com', model: 'MiniMax-H3' })
  ok(readMinimaxConfigRaw(home).apiKey === 'sk-legacy-key', '迁移后 minimax.json 可读到旧 Key（规则等价验证）')
}

console.log('\n[9] 章鱼生图站点账号：优先级 / 半截不算数 / 空串不抹密码')
{
  // 凭据改成设置页 GUI 登录后，这条链成了「保存即能用」的地基：
  //   - 文件优先、env 兜底（并把 env 遮蔽如实报出来，否则会误判成没保存）；
  //   - **半截凭据（只有账号没有密码）必须算不可用** —— 否则会把只有账号的
  //     半成品注入子进程，撞出「登录失败」这种含糊报错（实测过这类坑）；
  //   - 密码空串 = 不修改：表单不回显密码，只改账号时密码字段必然为空，
  //     当值写回去就是把用户密码抹掉（image.json 历史上正是这么坏的）。
  const home = path.join(scratch, 'z1')
  const savedEnv = { ZAIDUYU_USER: process.env.ZAIDUYU_USER, ZAIDUYU_PASS: process.env.ZAIDUYU_PASS }
  try {
    process.env.ZAIDUYU_USER = 'env_user'
    process.env.ZAIDUYU_PASS = 'env_pass'
    writeZaiduyuConfigPatch(home, { identifier: 'phone_111', password: 'pw_secret_222' })
    const r = resolveZaiduyuCredentials(home)
    ok(r.source === 'file' && r.identifier === 'phone_111' && r.password === 'pw_secret_222', 'zaiduyu：文件凭据压过环境变量')
    ok(r.usable === true && r.envShadowed === true, 'zaiduyu：env 里也有凭据时如实标 envShadowed（否则会误判成没生效）')

    // 只填账号没填密码 → 不可用，但 identifier 仍可回给界面显示「填了一半」
    const half = path.join(scratch, 'z2')
    writeZaiduyuConfigPatch(half, { identifier: 'only_user' })
    delete process.env.ZAIDUYU_USER
    delete process.env.ZAIDUYU_PASS
    const r2 = resolveZaiduyuCredentials(half)
    ok(r2.usable === false && r2.source === 'none', 'zaiduyu：半截凭据算不可用（不拿它去登录）')
    ok(r2.identifier === 'only_user', 'zaiduyu：不可用时仍回显已填的账号，界面能指出缺哪一半')

    // env 里只有 USER 没有 PASS 同样不可用
    process.env.ZAIDUYU_USER = 'eu'
    const r3 = resolveZaiduyuCredentials(path.join(scratch, 'z-empty'))
    ok(r3.usable === false && r3.source === 'none', 'zaiduyu：env 缺密码也算不可用')
    delete process.env.ZAIDUYU_USER

    // 只改账号、密码留空 → 旧密码必须保住
    writeZaiduyuConfigPatch(home, { identifier: 'other_user', password: '' })
    ok(readZaiduyuConfigRaw(home).password === 'pw_secret_222', 'zaiduyu：空密码 = 不修改（只改账号不抹密码）')
    ok(readZaiduyuConfigRaw(home).identifier === 'other_user', 'zaiduyu：账号照常更新')

    // 掩码不外泄明文；清除后彻底不可用
    const masked = maskSecret('pw_secret_222')
    ok(masked !== 'pw_secret_222' && !masked.includes('secret'), 'zaiduyu：maskSecret 不回显密码明文')
    ok(clearZaiduyuCredentials(home) === true, 'zaiduyu：清除返回 true（确实删了文件）')
    ok(resolveZaiduyuCredentials(home).usable === false, 'zaiduyu：清除后不可用')
    ok(clearZaiduyuCredentials(home) === false, 'zaiduyu：重复清除返回 false（本来就没有）')

    // 密码绝不进命令行参数（argv 会进进程列表/日志）—— 只能走子进程 env。
    const zsrc = fs.readFileSync(new URL('../src/game-zaiduyu.mjs', import.meta.url), 'utf8')
    const genBody = /export async function generate[\s\S]*?\n\}\n/.exec(zsrc)?.[0] ?? ''
    ok(!/--(password|pass|user|identifier)\b/.test(genBody), 'zaiduyu：不往生图参数里塞账号或密码')
    ok(/childEnv\.ZAIDUYU_PASS\s*=/.test(zsrc), 'zaiduyu：凭据通过子进程 env 注入')
    // 登录验证必须显式接管凭据并剥掉继承值，否则旧 env 会替新账号作弊
    ok(/delete childEnv\.ZAIDUYU_USER/.test(zsrc) && /delete childEnv\.ZAIDUYU_PASS/.test(zsrc),
      'zaiduyu：显式凭据时剥掉继承的 env（验证的就是表单里那一组）')
  } finally {
    for (const [k, v] of Object.entries(savedEnv)) {
      if (v === undefined) delete process.env[k]
      else process.env[k] = v
    }
  }
}

fs.rmSync(scratch, { recursive: true, force: true })
console.log(`\n结果：${passed} 项通过，${failed} 项失败`)
process.exit(failed === 0 ? 0 : 1)