import { LocalDataService } from './local-data.js'
import { PluginUpdateService } from './plugin-update.js'
import { ReferenceFilesService } from './reference-files.js'
import { OtherMemoryService } from './other-memory.js'
import { OtherMemoryFilesService } from './other-memory-files.js'
import { TopicArchiveService } from './topic-archive.js'
import { TopicTermsService } from './topic-terms.js'
import { EmbeddingService } from './embedding.js'
import { MemorySearchService } from './memory-search.js'
import { HistoryService } from './history.js'
import { RecordIndexService } from './record-index.js'
import { createTranslationFramework } from './framework.js'
import { installQuickTranslation, type QuickHostContext } from './quick-translation.js'
import { installTopicTools, type TopicHostContext } from './topic-tools.js'
import { PLUGIN_REMOTE } from '../shared/plugin-remote.js'
import { BatchProcessingService } from './batch-processing.js'
import { installObjectAssets } from './object-assets.js'
import { installViewFiles } from './view-files.js'
import { installTranslationMaterials, type TranslationMaterialHostContext } from './translation-materials.js'
import { installNormalTranslation } from './normal-translation.js'
import { installTranslationSources } from './translation-sources.js'
import { TerminologyAnalysisService } from './terminology-analysis.js'
import { installTranslationPreparation } from './translation-preparation.js'
import { installDocumentPlanning } from './document-planning-service.js'
import { installDocumentExecution } from './document-execution-service.js'
import { installDocumentCorrection } from './document-correction-service.js'
import { installDocumentReview } from './document-review-service.js'
import { installFileJobs } from './file-jobs.js'
import { TermHandleRegistry } from './term-handles.js'
import type { AnalysisNotification, AnalysisRun } from '../shared/translation-preparation.js'
import type { TaskPhaseEvent, TranslationExchangeService } from 'dsh-composer-extension/contracts'

export { createTranslationFramework } from './framework.js'
export { OtherMemoryService } from './other-memory.js'
export { OtherMemoryFilesService } from './other-memory-files.js'
export { TopicArchiveService } from './topic-archive.js'
export { TopicTermsService } from './topic-terms.js'
export { EmbeddingService } from './embedding.js'
export { MemorySearchService } from './memory-search.js'
export { HistoryService } from './history.js'
export { RecordIndexService } from './record-index.js'
export type * from '../shared/record-index.js'
export type * from '../shared/history-bundle.js'
export type * from '../shared/history-remote.js'
export type * from '../shared/embedding.js'
export type * from '../shared/other-memory.js'
export type * from '../shared/other-memory-files.js'
export type * from '../shared/topic-archive-remote.js'
export type * from '../shared/topic-terms-remote.js'
export { TextTranslationRuntime } from './text-runtime.js'
export { QuickTranslationService, installQuickTranslation } from './quick-translation.js'
export { DshTextExecutionAdapter } from './dsh-text-adapter.js'
export { TopicToolsService, installTopicTools } from './topic-tools.js'
export { ObjectAssetsService, installObjectAssets } from './object-assets.js'
export { ViewFilesService, installViewFiles } from './view-files.js'
export { TranslationMaterialsService, installTranslationMaterials } from './translation-materials.js'
export { NormalTranslationService, installNormalTranslation } from './normal-translation.js'
export { TranslationSourcesService, installTranslationSources } from './translation-sources.js'
export { loadTranslationSourceStorage } from './source-storage.js'
export { TerminologyAnalysisService } from './terminology-analysis.js'
export { TranslationPreparationService, installTranslationPreparation } from './translation-preparation.js'
export { DocumentPlanningService, installDocumentPlanning } from './document-planning-service.js'
export { DocumentPlanner } from './document-planner.js'
export { DocumentExecutionService, installDocumentExecution } from './document-execution-service.js'
export { DocumentReviewService, installDocumentReview } from './document-review-service.js'
export { FileJobsService, installFileJobs } from './file-jobs.js'
export type * from '../shared/file-jobs.js'
export type * from '../shared/document-execution.js'
export type * from '../shared/document-planning.js'
export type * from '../shared/translation-preparation.js'
export type * from './source-storage.js'
export type { SourceIdentity } from '../shared/translation-sources.js'
export type * from '../shared/translation-source-storage.js'
export type * from '../shared/domain-contracts.js'

export const name = 'deepseek-translation-framework'
export const provide = ['translationFramework', 'translationQuick', 'translationTopics', 'translationObjects', 'translationViews', 'translationMaterials', 'translationNormal', 'translationNormalV2', 'translationSources', 'translationAnalysis', 'translationPreparation', 'translationPlanning', 'translationBatch', 'translationBatchProcessing', 'translationCorrection', 'translationReview', 'translationReferences', 'translationOtherMemory', 'translationOtherMemoryFiles', 'translationArchive', 'translationTerms', 'translationEmbedding', 'translationMemorySearch', 'translationHistory', 'translationRecordIndex', 'translationLocalData', 'translationFileJobs', 'translationPluginUpdate'] as const

function phaseEvent(exchange: TranslationExchangeService, run: AnalysisRun): TaskPhaseEvent | null {
  if (!['completed', 'failed', 'unknown'].includes(run.status)) return null
  return { eventId: JSON.stringify(['terminology_analysis', run.scope.translationSessionId, run.operationId, run.analysisId, run.version, run.status]),
    hostGeneration: exchange.hostGeneration, scope: { mainSessionId: run.scope.mainSessionId, topicId: run.scope.topicId, translationSessionId: run.scope.translationSessionId }, operationId: run.operationId,
    phase: `terminology_analysis_${run.status}` as TaskPhaseEvent['phase'],
    result: { kind: 'analysis', analysisId: run.analysisId, version: run.version, sourceVersion: run.sourceVersion,
      material: { requestId: run.target.requestId, materialId: run.target.materialId } }, coverageComplete: run.coverageComplete }
}

/** T supplies analysis facts; E alone owns identity-checked main-Agent queue notifications. */
export function installTerminologyAnalysis(ctx: TopicHostContext): TerminologyAnalysisService {
  let disposed = false
  let attached: { readonly exchange: TranslationExchangeService; readonly hostGeneration: string; readonly unregister: () => void } | undefined
  const capability = () => {
    const exchange = ctx.get?.('translationExchange') as TranslationExchangeService | undefined
    if (disposed || typeof exchange?.registerTaskPhaseInspector !== 'function' || typeof exchange.notifyTaskPhase !== 'function' ||
      typeof exchange.taskPhaseCapabilities !== 'function') return { phaseProtocol: 2 as const, ready: false, reason: 'composer_phase_notification_unavailable' }
    try {
      const result = exchange.taskPhaseCapabilities()
      return result.phaseProtocol === 2 ? result : { phaseProtocol: 2 as const, ready: false, reason: 'composer_phase_protocol_mismatch' }
    } catch { return { phaseProtocol: 2 as const, ready: false, reason: 'composer_phase_notification_unavailable' } }
  }
  const service = new TerminologyAnalysisService(ctx, {
    phaseNotificationCapabilities: capability,
    phaseNotifier: () => {
      if (!capability().ready) return undefined
      const exchange = ctx.get?.('translationExchange') as TranslationExchangeService
      if (attached?.hostGeneration !== exchange.hostGeneration) {
        attached?.unregister()
        const unregister = exchange.registerTaskPhaseInspector(ctx as unknown as Parameters<TranslationExchangeService['registerTaskPhaseInspector']>[0], {
          inspectTaskPhase: event => {
            const live = ctx.get?.('translationExchange') as TranslationExchangeService | undefined
            if (disposed || live?.hostGeneration !== exchange.hostGeneration || event.hostGeneration !== exchange.hostGeneration || event.result.version !== 1) return null
            const run = service.inspectPhase({ scope: { ...event.scope, ownerId: event.scope.mainSessionId }, analysisId: event.result.analysisId, operationId: event.operationId,
              version: 1, sourceVersion: event.result.sourceVersion })
            return run && phaseEvent(exchange, run)
          },
        })
        attached = { exchange, hostGeneration: exchange.hostGeneration, unregister }
      }
      const fixed = attached
      return async (run: AnalysisRun): Promise<AnalysisNotification> => {
        const live = ctx.get?.('translationExchange') as TranslationExchangeService | undefined
        if (disposed || attached !== fixed || live?.hostGeneration !== fixed.hostGeneration) return { state: 'unavailable', reason: 'composer_phase_generation_lost' }
        const event = phaseEvent(exchange, run)
        if (!event) return { state: 'unavailable', reason: 'analysis_not_terminal' }
        const result = await fixed.exchange.notifyTaskPhase(ctx as unknown as Parameters<TranslationExchangeService['notifyTaskPhase']>[0], event)
        return !result.ok ? { state: 'unavailable', reason: result.error.code }
          : { state: result.value.state === 'not_enqueued' ? 'unavailable' : result.value.state,
            reason: result.value.state === 'unavailable' || result.value.state === 'not_enqueued' ? 'composer_phase_notification_not_enqueued' : null }
      }
    },
  })
  ctx.provide('translationAnalysis', service)
  ctx.effect?.(() => () => { disposed = true; attached?.unregister(); attached = undefined; service.dispose() }, 'terminology analysis lifetime')
  return service
}

export function apply(ctx: QuickHostContext): void {
  const update = new PluginUpdateService(ctx)
  ctx.provide('translationPluginUpdate', update)
  ctx.effect?.(() => () => update.dispose(), 'translation plugin update lifetime')
  ctx.provide('translationLocalData', new LocalDataService(ctx as TopicHostContext))
  const embedding = new EmbeddingService(ctx as TopicHostContext)
  ctx.provide('translationEmbedding', embedding)
  ctx.effect?.(() => () => { void embedding.dispose() }, 'embedding lifetime')
  // Model-facing short handles for term query results; shared by the query projection and the direct call.
  ctx.provide('translationTermHandles', new TermHandleRegistry())
  installTopicTools(ctx as TopicHostContext, undefined, false)
  const references = new ReferenceFilesService(ctx as TopicHostContext)
  ctx.provide('translationReferences', references)
  ctx.effect?.(() => () => references.dispose(), 'reference files lifetime')
  const otherMemory = new OtherMemoryService(ctx as TopicHostContext)
  ctx.provide('translationOtherMemory', otherMemory)
  const otherMemoryFiles = new OtherMemoryFilesService(ctx as TopicHostContext, otherMemory)
  ctx.provide('translationOtherMemoryFiles', otherMemoryFiles)
  ctx.effect?.(() => async () => { await otherMemoryFiles.dispose(); await otherMemory.dispose() }, 'other memory lifetime')
  const archive = new TopicArchiveService(ctx as TopicHostContext, otherMemory)
  ctx.provide('translationArchive', archive)
  ctx.effect?.(() => () => archive.dispose(), 'topic archive lifetime')
  const memorySearch = new MemorySearchService(ctx as TopicHostContext, otherMemory, archive, otherMemoryFiles, embedding)
  ctx.provide('translationMemorySearch', memorySearch)
  ctx.effect?.(() => () => memorySearch.dispose(), 'memory search lifetime')
  const history = new HistoryService(ctx as TopicHostContext, otherMemory)
  ctx.provide('translationHistory', history)
  ctx.effect?.(() => () => history.dispose(), 'history lifetime')
  const recordIndex = new RecordIndexService(ctx as TopicHostContext, otherMemory, history)
  ctx.provide('translationRecordIndex', recordIndex)
  ctx.effect?.(() => () => recordIndex.dispose(), 'record index lifetime')
  const terms = new TopicTermsService(ctx as TopicHostContext, otherMemory)
  ctx.provide('translationTerms', terms)
  ctx.effect?.(() => () => terms.dispose(), 'topic terms lifetime')
  installObjectAssets(ctx, {}, false)
  installViewFiles(ctx, {}, false)
  installTranslationMaterials(ctx as TranslationMaterialHostContext, undefined, false)
  installNormalTranslation(ctx as TopicHostContext, undefined, false)
  installTranslationSources(ctx, false)
  const batches = new BatchProcessingService(ctx as TopicHostContext)
  ctx.provide('translationBatchProcessing', batches)
  ctx.effect?.(() => () => batches.dispose(), 'batch processing lifetime')
  installTerminologyAnalysis(ctx as TopicHostContext)
  installTranslationPreparation(ctx as TopicHostContext)
  installDocumentPlanning(ctx as TopicHostContext)
  installDocumentExecution(ctx as TopicHostContext)
  installDocumentCorrection(ctx as TopicHostContext)
  installDocumentReview(ctx as TopicHostContext)
  installFileJobs(ctx as TopicHostContext, false)
  const quick = installQuickTranslation(ctx, undefined, false)
  const register = (scope: QuickHostContext): void => {
    const registry = scope.get ? scope.get('typert') as QuickHostContext['typert'] : scope.typert
    registry?.register({ package: PLUGIN_REMOTE.package, face: 'host', schemas: [], invocations: PLUGIN_REMOTE.descriptors,
      model: { package: PLUGIN_REMOTE.package, face: 'host', classes: [], events: [], objects: [] } })
  }
  if (ctx.inject) ctx.inject(['typert'], register)
  else register(ctx)
  ctx.provide('translationFramework', createTranslationFramework({ ...(quick ? { executionAdapter: quick.adapter, runtime: quick.runtime } : {}) }))
}
