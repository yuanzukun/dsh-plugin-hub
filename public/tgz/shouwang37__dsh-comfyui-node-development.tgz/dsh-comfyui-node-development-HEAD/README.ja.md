# dsh-comfyui-node-development

[中文](README.md) | 日本語

**DeepSeek Harness（DSH）プラグイン**：**ComfyUI カスタムノード開発**の要点をまとめたバイリンガル（中文中心、英語用語併記）ガイドを、ランタイムスキル `comfyui-node-dev` として同梱します。

DSH エージェントは必要に応じてこのスキルを読み込めます——ノードクラスの契約（`INPUT_TYPES`、`RETURN_TYPES`、`CATEGORY`、`FUNCTION`）、ノード登録とライフサイクル、データ型、隠し/フレキシブル入力、遅延評価、リスト処理、フロントエンド JavaScript 拡張、i18n、ノードドキュメント、V1 → V3 移行の要点まで網羅しています。

> 内容は ComfyUI 公式ドキュメント（[docs.comfy.org](https://docs.comfy.org/custom-nodes/overview)、中国語ミラー [docs.comfy.org/zh](https://docs.comfy.org/zh/custom-nodes/overview)）を要約したものです。学習用の補助であり、公式ドキュメントの代わりにはなりません。

## 特徴

- **スキルひとつで完結**：`comfyui-node-dev` —— ComfyUI カスタムノードに関わるあらゆる会話で読み込み可能。
- **深掘りリファレンス同梱**：`assets/skill/references/` に `backend.md`、`frontend.md`、`datatypes.md`、`links.md` を収録。
- **人間向け要約**：`docs/SUMMARY.zh.md` と `docs/SUMMARY.en.md`。
- **ランタイム依存ゼロ**：`ctx.skills` によるスキル登録のみ。peer 依存は DSH プロファイル標準搭載の2パッケージ（`@deepseek-ai/cordis`、`@deepseek-ai/dsh-skill`）だけです。

## DSH へのインストール

DSH プロファイル（例：`web`）が必要です。ターミナルで実行：

```bash
# GitHub からインストール（推奨。ビルド不要ですぐ使える）
dsh plugin --profile web add "github:shouwang37/dsh-comfyui-node-development"

# またはローカルパス
dsh plugin --profile web add "file:C:/path/to/dsh-comfyui-node-development"
```

その後、DSH Web サービス（またはプロファイルのプロセスマネージャ）を再起動してください。プラグインはプロファイルレイヤー `comfyui-node-dev` としてマウントされ、`comfyui-node-dev` スキルが登録されます。

## 使い方

任意の会話で、たとえば次のように質問します：

- 「ComfyUI のカスタムノードを作って」
- 「ComfyUI ノードの INPUT_TYPES はどう書くの？」
- 「ComfyUI ノードにフロントエンド JS 拡張を追加するには？」
- 「このノードコードを V1 から V3 に移行して」

タスクがスキルの `whenToUse` ガイドに合致すると、エージェントが自動的にスキルを読み込みます。

## 開発

```bash
pnpm install
pnpm build        # tsc -> lib/
pnpm smoke        # スモークテスト：スタブコンテキストでスキルを登録
```

> 補足：ビルド成果物 `lib/` はリポジトリにコミットしてあります。GitHub からインストールする際にビルドスクリプトの実行が不要になるためです（pnpm は git 依存のビルドスクリプトをブロックします）。

## リポジトリ構成

```text
.
├── src/                     # プラグインソース（Cordis プラグインエントリ + スキル登録）
├── assets/skill/            # スキル本体とリファレンス（エージェントへ配布）
├── docs/                    # 人間向け要約（中/英）
├── cordis.patch.yml         # DSH バンドルパッチ（プロファイルレイヤーのマウント）
├── package.json             # dsh.bundle を宣言
└── scripts/smoke.mjs        # スモークテスト
```

## ライセンス

MIT —— [LICENSE](LICENSE) を参照。

## 関連リンク

- 公式ドキュメント：<https://docs.comfy.org/custom-nodes/overview>
- ComfyUI ソース：<https://github.com/comfyanonymous/ComfyUI>
- 公式カスタムノードサンプル：<https://github.com/Comfy-Org/ComfyUI_examples_custom_node>
