/**
 * Smoke test: load the built plugin against a stub Cordis context and assert
 * that applying the plugin registers the `comfyui-node-dev` skill, that the
 * skill body is non-empty, and that the disposer unregisters it.
 *
 * Usage: node scripts/smoke.mjs   (after `pnpm build`)
 */

import { createRequire } from 'node:module'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const require = createRequire(import.meta.url)
const root = resolve(fileURLToPath(new URL('..', import.meta.url)))
const plugin = require(resolve(root, 'lib/index.js'))

const failures = []
const check = (label, ok, detail = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${detail ? ` — ${detail}` : ''}`)
  if (!ok) failures.push(label)
}

// --- stub context ---------------------------------------------------------
const registered = []
const ctx = {
  skills: {
    register(skill) {
      registered.push(skill)
      return () => {
        const index = registered.indexOf(skill)
        if (index >= 0) registered.splice(index, 1)
      }
    },
  },
  logger: {
    info: (...args) => console.log(`[logger.info] ${args.join(' ')}`),
    warn: () => {},
    error: (...args) => console.error(`[logger.error] ${args.join(' ')}`),
  },
}

// --- assertions ------------------------------------------------------------
check('plugin exports name', plugin.name === 'dsh-comfyui-node-development', plugin.name)
check('plugin declares skills injection', Array.isArray(plugin.inject) && plugin.inject.includes('skills'))

const disposer = await plugin.apply(ctx)
check('apply() returns a disposer', typeof disposer === 'function')

check('exactly one skill registered', registered.length === 1, `count=${registered.length}`)
const skill = registered[0]
check('skill name is comfyui-node-dev', skill?.name === 'comfyui-node-dev', skill?.name)
check('skill has description', typeof skill?.description === 'string' && skill.description.length > 0)
check('skill has whenToUse', typeof skill?.whenToUse === 'string' && skill.whenToUse.length > 0)
check('skill source is runtime', skill?.source === 'runtime')
check(
  'skill resourceBase points at assets/skill',
  skill?.resourceBase?.kind === 'directory' && /assets[\\/]skill[\\/]?$/.test(skill?.resourceBase?.path ?? ''),
  skill?.resourceBase?.path,
)
check('skill content is non-empty', typeof skill?.content === 'string' && skill.content.length > 1000, `${skill?.content?.length ?? 0} chars`)
check(
  'skill content mentions INPUT_TYPES',
  skill?.content?.includes('INPUT_TYPES') && skill?.content?.includes('NODE_CLASS_MAPPINGS'),
)

disposer()
check('disposer unregisters the skill', registered.length === 0)

// --- asset references exist ------------------------------------------------
import { existsSync } from 'node:fs'
for (const file of ['backend.md', 'frontend.md', 'datatypes.md', 'links.md']) {
  check(`reference asset exists: ${file}`, existsSync(resolve(skill.resourceBase.path, 'references', file)))
}

if (failures.length > 0) {
  console.error(`\nsmoke test failed: ${failures.join(', ')}`)
  process.exit(1)
}
console.log('\nsmoke test passed')
