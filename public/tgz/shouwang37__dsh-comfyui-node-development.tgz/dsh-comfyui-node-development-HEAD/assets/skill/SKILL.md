# comfyui-node-dev

ComfyUI 自定义节点（Custom Node / Custom Node Pack）开发的浓缩指南（中文为主，保留英文术语）。
本技能来自对 ComfyUI 官方文档（docs.comfy.org）的系统总结。需要更深细节时，可查阅本技能
资源目录 `references/` 下的分册（backend.md / frontend.md / datatypes.md / links.md），
以及文末的官方链接。

---

## 1. 核心概念：客户端-服务端模型

Comfy 采用客户端-服务端架构：

- **服务端（Python）**：负责全部实际工作——数据处理、模型加载、扩散采样等。
- **客户端（JavaScript）**：负责用户界面（节点画布、控件、右键菜单等）。
- **API 模式**：非 Comfy 客户端（脚本、其他 UI）可以直接把 workflow JSON 提交给服务端执行。

自定义节点分为四类：

| 类型 | 说明 |
|---|---|
| 仅服务端（Server side only） | 绝大多数节点：定义一个 Python 类，声明输入/输出类型，提供处理函数 |
| 仅客户端（Client side only） | 只修改 UI，可能不新增任何节点（如主题、右键菜单扩展） |
| 客户端+服务端独立（Independent） | 同时提供服务端功能与配套 UI；两者通过 Comfy 数据流通信 |
| 客户端+服务端联动（Connected） | UI 与服务端需要直接交互（如 PromptServer.send_sync 消息）；**这类节点无法在 API 模式下使用** |

## 2. 项目结构与加载生命周期（Lifecycle）

Comfy 启动时扫描 `ComfyUI/custom_nodes/` 目录下的 Python 模块（含 `__init__.py` 的目录）并尝试导入。
模块只要导出 `NODE_CLASS_MAPPINGS` 即被视为自定义节点包；导入失败时 Comfy 会继续运行，但在控制台报告该模块加载失败——**一定要看 Python 控制台输出**。

```text
ComfyUI/
└── custom_nodes/
    └── my_node_pack/            # 你的插件目录（通常用 comfy node scaffold 生成）
        ├── __init__.py          # 入口：导出注册映射
        ├── src/
        │   └── nodes.py         # 节点类定义
        └── web/js/              # 可选：前端 JS 扩展目录（WEB_DIRECTORY）
```

`__init__.py` 最简写法：

```python
from .src.nodes import MyCustomNode

NODE_CLASS_MAPPINGS = {
    "My Custom Node": MyCustomNode,
}
NODE_DISPLAY_NAME_MAPPINGS = {      # 可选：显示名，缺省时用注册名
    "My Custom Node": "我的自定义节点",
}
__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS"]
```

- `NODE_CLASS_MAPPINGS`：`dict`，键是**全 Comfy 安装内唯一**的节点名，值是节点类。
- `NODE_DISPLAY_NAME_MAPPINGS`：可选，把唯一名映射为 UI 显示名。
- `WEB_DIRECTORY`：可选，导出相对模块的 JS 目录路径（惯例为 `./js`）。**只有 `.js` 文件会被自动加载**；
  `.css` 等资源需通过 `extensions/<节点子目录>/<文件>` 路径程序化引用。旧版本要求把 JS 复制进 Comfy web 目录，现在**不要**这样做。
- 修改节点代码后**必须重启 ComfyUI** 才能生效。

快速起步：安装 [comfy-cli](https://docs.comfy.org/comfy-cli/getting-started) 后，在 `custom_nodes` 下执行 `comfy node scaffold` 交互式生成项目骨架。

## 3. 最小可用节点（完整骨架）

```python
import torch

class ImageSelector:
    CATEGORY = "example"                       # Add Node 菜单路径，可用斜杠分级如 "example/trivial"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": { "images": ("IMAGE",) },
            "optional": { "mode": (["brightest", "reddest", "greenest", "bluest"],) },
        }

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("image_out",)              # 可选；缺省用 RETURN_TYPES 小写
    FUNCTION = "choose_image"                  # 执行时调用的函数名

    def choose_image(self, images, mode="brightest"):
        # IMAGE 是 torch.Tensor，形状 [B,H,W,C]
        brightness = [torch.mean(img.flatten()).item() for img in images]
        best = brightness.index(max(brightness))
        result = images[best].unsqueeze(0)     # [H,W,C] -> [1,H,W,C]
        return (result,)                       # 必须返回 tuple，单个输出记得逗号

NODE_CLASS_MAPPINGS = { "Image Selector": ImageSelector }
```

## 4. 节点类契约（Properties）

每个自定义节点就是一个 Python 类，关键属性：

| 属性 | 必填 | 说明 |
|---|---|---|
| `INPUT_TYPES` | ✅ | `@classmethod`，返回 dict，**必须**含 `required`，可选含 `optional` / `hidden`。值形如 `{ "输入名": ("类型", {参数}) }` |
| `RETURN_TYPES` | ✅ | 输出类型 tuple；无输出也要写 `RETURN_TYPES = ()`；单输出记得尾逗号 `("IMAGE",)` |
| `RETURN_NAMES` | 可选 | 输出标签 tuple；缺省为类型名小写 |
| `CATEGORY` | ✅ | 节点在 "Add Node" 菜单中的位置，如 `"image/batch"` |
| `FUNCTION` | ✅ | 执行函数的字符串名；函数按名接收 `required`+`hidden` 输入；`optional` 输入**仅在已连接时**传入，故必须给默认值或用 `**kwargs`；返回值是与 `RETURN_TYPES` 对应的 tuple |

`INPUT_TYPES` 是 classmethod 的原因：下拉选项（如 checkpoint 文件名列表）需要在运行时由 Comfy 计算。

### 执行控制与缓存优化

Comfy 会缓存节点输出，只重跑可能变化的节点。两个可选属性参与该机制：

- `OUTPUT_NODE = True`：声明本节点是输出节点（如 Preview/Save 类节点），**始终执行**。
- `IS_CHANGED`：`@classmethod`，接收与 `FUNCTION` 相同的参数，返回任意 Python 对象，与上次结果比较决定是否重跑。
  - **不要返回 bool**（`True == True` 会被判定为“未变化”）。
  - 需要总是重跑时返回 `float("NaN")`（NaN 不等于任何值，包括自己）——尽量别用，会禁用缓存优化。
  - 参考内置 `LoadImage`：对文件内容做 sha256 返回 hex 摘要。
- `SEARCH_ALIASES`：可选，搜索别名列表（会出现在 `/object_info` API 响应的 `search_aliases` 中）。

### 其他属性

- `INPUT_IS_LIST` / `OUTPUT_IS_LIST`：控制列表式数据处理（见第 7 节）。
- `VALIDATE_INPUTS`：`@classmethod`，工作流执行前调用，返回 `True` 或错误消息 `str`（阻止执行）。
  - 只收到 workflow 中**常量**输入；来自其他节点的输入不在其中。
  - 只接收签名中声明的参数（通过 `inspect.getfullargspec` 分析），声明的参数会跳过默认校验。
  - 声明参数 `input_types` 时，会收到「输入名 → 已连接输出的类型」字典，且跳过全部默认类型校验——实现 `"*"` 通配输入时必备。

## 5. 数据类型（Datatypes）

类型在客户端用于阻止错误连线（类似强类型）。

### 内置基础类型

| 类型 | INPUT_TYPES 附加参数 | Python 类型 |
|---|---|---|
| `COMBO` | 无（用 `list[str]` 作为类型即下拉框，首项为默认） | `str` |
| `INT` | `default` 必填；`min`/`max` 可选 | `int` |
| `FLOAT` | `default` 必填；`min`/`max`/`step` 可选 | `float` |
| `STRING` | `default` 必填 | `str` |
| `BOOLEAN` | `default` 必填 | `bool` |
| `IMAGE` | 无 | `torch.Tensor` 形状 `[B,H,W,C]`（一般 C=3 RGB） |
| `LATENT` | 无 | `dict`，含键 `samples`：`torch.Tensor` 形状 `[B,C,H,W]`（一般 C=4，宽高为图像的 1/8） |
| `MASK` | 无 | `torch.Tensor` 形状 `[H,W]` 或 `[B,C,H,W]` |
| `AUDIO` | 无 | `dict`：`waveform`（`[B,C,T]`）+ `sample_rate` |
| `NOISE` | — | 提供 `generate_noise(input_latent)->Tensor` 与 `seed` 属性的对象 |
| `SAMPLER` | — | 提供 `sample` 方法的对象 |
| `SIGMAS` | — | 长度 `steps+1` 的一维张量（各步前后噪声值） |
| `GUIDER` | — | 提供 `__call__` 的可调用对象（噪声预测） |
| `MODEL` / `CLIP` / `VAE` / `CONDITIONING` | — | 扩散模型相关类型（进阶） |

注意：`IMAGE` 语义是**图像批次**，单张图即 batch=1。

### 输入附加参数（options 字典）

官方支持的键：`default`、`min`、`max`、`step`、`label_on`/`label_off`（BOOL）、`defaultInput`（默认连输入口而非控件）、`forceInput`（强制输入口且禁止转控件——自定义类型必备）、`multiline`（STRING 多行）、`placeholder`、`dynamicPrompts`、`lazy`（惰性求值）、`rawLink`（收到 `["nodeId", idx]` 链接而非值，用于节点展开）。
自定义控件可加自己的键，但**不要复用**上述官方键的语义。

### 自定义类型 / 通配符 / 动态输入

- **自定义类型**：用唯一大写字符串命名（如 `"CHEESE"`），客户端只允许同类型相连；因客户端不认识它，需在 options 里加 `{"forceInput": True}`。值可以是任意 Python 对象。
- **通配符 `"*"`**：`("anything", ("*", {}))` 表示可连任意类型；配合 `VALIDATE_INPUTS(s, input_types)` 返回 `True` 跳过后端校验，由节点自己处理数据。
- **动态输入**：客户端动态创建的输入无法预声明，可用 `ContainsAnyDict(dict)`（重写 `__contains__` 恒真）作为 `optional` 的值，主函数用 `**kwargs` 接收。

## 6. 隐藏输入（Hidden Inputs）

`INPUT_TYPES` 返回的 dict 可含 `hidden` 键（`dict[str, str]`），向服务端请求额外信息：

```python
"hidden": {
    "unique_id": "UNIQUE_ID",        # 节点唯一 id（与客户端节点 id 一致），常用于客户端-服务端通信
    "prompt": "PROMPT",              # 客户端提交的完整 prompt 对象
    "extra_pnginfo": "EXTRA_PNGINFO",# 会写入保存的 PNG 元数据；--disable_metadata 时不保存
    "dynprompt": "DYNPROMPT",        # comfy_execution.graph.DynamicPrompt，可随节点展开变化（高级：实现循环）
}
```

## 7. 惰性求值（Lazy Evaluation，v0.2.0+）与列表处理

### 惰性求值

默认所有输入先求值再执行节点。当某个输入可能用不上时（如 Switch、比例=0/1 的合并节点），可以延迟求值省 VRAM/时间：

1. 在 options 中声明 `{"lazy": True}`；
2. 定义**实例方法** `check_lazy_status(self, ...)`（不是 classmethod）：接收与主函数相同的参数，未就绪的惰性输入值为 `None`，返回还需要求值的输入名列表（空列表=全部就绪）。该方法可能被多次调用。

```python
def check_lazy_status(self, mask, image1, image2):
    mask_min, mask_max = mask.min(), mask.max()
    needed = []
    if image1 is None and (mask_min != 1.0 or mask_max != 1.0):
        needed.append("image1")
    if image2 is None and (mask_min != 0.0 or mask_max != 0.0):
        needed.append("image2")
    return needed
```

- 尽量给输入加惰性，成本极低。
- 想禁用某个输出节点时：加 `enabled` 输入（默认 True），其余输入全部 lazy，`enabled` 为 False 时不求值它们。
- 不想自己实现惰性的输出节点，可返回 `comfy_execution.graph.ExecutionBlocker(None)`（静默阻断）或 `ExecutionBlocker("错误消息")`（显示错误）。收到 ExecutionBlocker 的节点会跳过执行并原样传递，**无法中途停止传播**。

### 数据列表（List Processing）

服务端内部节点间数据以 Python `list` 传递（通常长度 1，Comfy 自动包装/解包，一般无需关心）。

- 多个数据实例时（如逐张处理图片防爆显存），默认**顺序处理**：短列表用末值补齐；主函数对每个值调用一次；输出为与最长输入等长的列表。
- `OUTPUT_IS_LIST = (True, ...)`（与 RETURN_TYPES 等长的 bool tuple）：声明某输出是“一系列数据”，不要包装成单条。
- `INPUT_IS_LIST = True`：节点级开关，所有输入以完整列表一次性传入（此时 `batch_size[0]` 才是控件值），参考内置 `ImageRebatch`。
- 相关实现见 `execution.py` 的 `map_node_over_list`。

## 8. 前端 JavaScript 扩展（Client Side）

三步：导出 `WEB_DIRECTORY` → 放入 `.js` 文件 → 用 `app.registerExtension` 注册。

```python
WEB_DIRECTORY = "./js"
__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS", "WEB_DIRECTORY"]
```

```javascript
import { app } from "../../scripts/app.js";
app.registerExtension({
    name: "a.unique.name",
    async setup() { ... },          // 页面加载时调用
    // 还有 beforeRegisterNodeDef / nodeCreated / getCustomWidgets 等 hooks
})
```

- 页面加载时自动加载该目录下所有 `.js`；不需要声明入口文件。
- 服务端→客户端消息：`PromptServer.instance.send_sync("唯一消息类型", {...})`，客户端 `app.api.addEventListener("消息类型", handler)`，数据在 `event.detail`。
- 更多内容（hooks 清单、Comfy 对象、示例）见官方 `custom-nodes/js/*` 系列页面，本技能 `references/frontend.md` 有索引。

## 9. 国际化（i18n）

ComfyUI 支持 en / zh / zh-TW / fr / ko / ru / es / ja / ar。
在自定义节点下建 `locales/` 目录：

```text
your_custom_node/
├── __init__.py
├── your_node.py
└── locales/
    ├── en/   # 建议以英文为基准
    │   ├── main.json      # 通用文案 + settingsCategories
    │   ├── nodeDefs.json  # 节点定义翻译（display_name/description/inputs/outputs/tooltip/options）
    │   ├── settings.json  # 设置项翻译（可选）
    │   └── commands.json  # 命令翻译（可选）
    └── zh/   # 其他语言同名结构
```

- `nodeDefs.json` 按节点类名作键；输出用**索引**（`"0"`, `"1"`...）而非输出名。
- 菜单设置（`app.registerExtension({ settings: [...] })`）的翻译键把 id 中的 `.` 换成 `_`（如 `I18nDemo.EnableDebugMode` → `I18nDemo_EnableDebugMode`），分类名在 `main.json` 的 `settingsCategories` 中翻译。
- 官方演示：<https://github.com/comfyui-wiki/ComfyUI-i18n-demo>

## 10. 为节点编写文档（Node Docs）

在 `WEB_DIRECTORY/docs/` 下按节点注册名放 Markdown，UI 会优先按用户语言加载：

```text
web/docs/
├── MyNode.md          # 默认（fallback）文档
└── MyNode/
    ├── en.md          # 英文
    └── zh.md          # 中文
```

支持标准 Markdown、图片、`<video>/<source>`（属性限 controls/autoplay/loop/muted/preload/poster）。
节点定义中给每个参数加 `tooltip` 后，节点文档面板也能直接展示基础信息。

## 11. V3 新 API（迁移要点）

官方正在推进从 V1（`INPUT_TYPES` 类方法式）迁移到 V3（`define_schema` 装饰器 + 类型化 schema）：

- 基类改为 `ComfyNode`，用 `define_schema(...)` 声明输入输出（类型化，支持 `control_after_generate` 等控件）。
- 执行方法改为 `execute(...)`（可 async）。
- 校验用 `validate(...)`、缓存控制用 `cache_control(...)` 等特殊方法替代 V1 属性。
- 通过 `comfy_cli` + `pyproject.toml` 打包（`comfy node create` / `comfy node publish`）。
- 详见官方 V3 Migration 指南与 `references/links.md`。

## 12. 官方文档地图（快速导航）

| 主题 | 地址 |
|---|---|
| 自定义节点总览 | https://docs.comfy.org/custom-nodes/overview |
| 起步走查（Getting Started） | https://docs.comfy.org/custom-nodes/walkthrough |
| 节点类契约（Properties） | https://docs.comfy.org/custom-nodes/backend/server_overview |
| 生命周期与注册 | https://docs.comfy.org/custom-nodes/backend/lifecycle |
| 数据类型 | https://docs.comfy.org/custom-nodes/backend/datatypes |
| 隐藏/灵活输入 | https://docs.comfy.org/custom-nodes/backend/more_on_inputs |
| 惰性求值 | https://docs.comfy.org/custom-nodes/backend/lazy_evaluation |
| 数据列表 | https://docs.comfy.org/custom-nodes/backend/lists |
| 代码示例 | https://docs.comfy.org/custom-nodes/backend/snippets |
| JS 扩展总览 | https://docs.comfy.org/custom-nodes/js/javascript_overview |
| i18n | https://docs.comfy.org/custom-nodes/i18n |
| 节点文档 | https://docs.comfy.org/custom-nodes/help_page |
| V3 迁移 | https://docs.comfy.org/custom-nodes/v3_migration |
| ComfyUI 源码 | https://github.com/comfyanonymous/ComfyUI |
| 官方节点示例仓库 | https://github.com/Comfy-Org/ComfyUI_examples_custom_node |
| 中文文档镜像 | https://docs.comfy.org/zh/custom-nodes/overview |

中文文档：docs.comfy.org 页面右上角可切换简体中文（部分页面）。

---

**常见坑速查**：单输出忘了尾逗号；`INPUT_TYPES` 忘了 `@classmethod`；节点改名后没更新 `NODE_CLASS_MAPPINGS`；改代码没重启 Comfy；`IS_CHANGED` 返回了 bool；自定义类型没加 `forceInput`；JS 扩展忘记导出 `WEB_DIRECTORY`。
