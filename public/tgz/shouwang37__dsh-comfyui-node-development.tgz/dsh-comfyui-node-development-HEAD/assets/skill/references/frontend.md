# Frontend 深度参考（JavaScript）

> ComfyUI 前端扩展开发细节，来源：docs.comfy.org/custom-nodes/js/*。

## 三步接入

1. 在 `__init__.py` 导出 `WEB_DIRECTORY`（相对模块的目录，惯例 `./js`）：

```python
WEB_DIRECTORY = "./js"
__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS", "WEB_DIRECTORY"]
```

2. 把 `.js` 文件放入该目录 —— 页面加载时**自动全部加载**，无需声明入口。
   只有 `.js` 会被注入页面；`.css` 等通过 `extensions/<节点目录>/<文件>` URL 程序化引用
   （注意该路径不含 WEB_DIRECTORY 子目录名，由服务端插入）。

3. 注册扩展：

```javascript
import { app } from "../../scripts/app.js";
app.registerExtension({
    name: "a.unique.name.for.an.extension",
    async setup() { /* 页面加载完成后调用 */ },
})
```

## 常用 hooks（钩子）

| Hook | 时机 |
|---|---|
| `setup()` | 页面加载完成 |
| `beforeRegisterNodeDef(nodeType, nodeData, app)` | 每个节点类型定义注册前（最常用，用于给特定节点类型加自定义行为） |
| `nodeCreated(node)` | 每个节点实例创建后 |
| `getCustomWidgets()` | 返回自定义 widget 类型 |
| `getCustomNodeDefs()` | 返回自定义节点定义 |

## 服务端 ↔ 客户端消息

服务端（Python）：

```python
from server import PromptServer
PromptServer.instance.send_sync("example.imageselector.textmessage", {"message": "Picked image 1"})
```

客户端（JS）：

```javascript
import { app } from "../../scripts/app.js";
app.registerExtension({
    name: "example.imageselector",
    async setup() {
        app.api.addEventListener("example.imageselector.textmessage", (event) => {
            alert(event.detail.message);   // 数据在 event.detail
        });
    },
})
```

消息类型字符串应全局唯一（惯例：`<包名>.<功能>.<事件名>`）。

## 常用 Comfy 对象

- `app`：主应用对象（`app.graph`、`app.canvas`、`app.registerExtension`...）。
- `app.api`：API 客户端（`addEventListener` / `fetchApi`）。
- `LiteGraph`：图引擎。
- `ComfyWidgets`：内置 widget 工厂（`ComfyWidgets["STRING"]` 等）。
- 节点对象属性：`node.widgets`、`node.inputs`、`node.outputs`、`node.properties`、`node.getInputData`、`node.onExecuted`。

## 官方 JS 主题页面索引

| 页面 | 地址 |
|---|---|
| JS 总览 | https://docs.comfy.org/custom-nodes/js/javascript_overview |
| hooks | https://docs.comfy.org/custom-nodes/js/javascript_hooks |
| 对象与劫持 | https://docs.comfy.org/custom-nodes/js/javascript_objects_and_hijacking |
| 示例代码 | https://docs.comfy.org/custom-nodes/js/javascript_examples |
| 设置项 | https://docs.comfy.org/custom-nodes/js/javascript_settings |
| 顶部菜单 | https://docs.comfy.org/custom-nodes/js/javascript_topbar_menu |
| 侧边栏标签页 | https://docs.comfy.org/custom-nodes/js/javascript_sidebar_tabs |
| 底部面板标签页 | https://docs.comfy.org/custom-nodes/js/javascript_bottom_panel_tabs |
| 右键菜单 | https://docs.comfy.org/custom-nodes/js/javascript_selection_toolbox |
| 对话框 | https://docs.comfy.org/custom-nodes/js/javascript_dialog |
| Toast 通知 | https://docs.comfy.org/custom-nodes/js/javascript_toast |
| 命令与快捷键 | https://docs.comfy.org/custom-nodes/js/javascript_commands_keybindings |
| 关于面板徽章 | https://docs.comfy.org/custom-nodes/js/javascript_about_panel_badges |
| 上下文菜单迁移 | https://docs.comfy.org/custom-nodes/js/context-menu-migration |
| 子图（subgraphs） | https://docs.comfy.org/custom-nodes/js/subgraphs |

## 前端模板/脚手架（官方推荐）

- cookiecutter-comfy-extension（`comfy node scaffold` 使用）
- ComfyUI-React-Extension-Template
- ComfyUI_frontend_vue_basic
