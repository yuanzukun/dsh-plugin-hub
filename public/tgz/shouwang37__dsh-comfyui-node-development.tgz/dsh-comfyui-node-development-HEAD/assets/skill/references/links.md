# 官方链接与资源（Links）

## 官方文档（docs.comfy.org）

| 主题 | 地址 |
|---|---|
| 文档首页 | https://docs.comfy.org |
| 完整文档索引（llms.txt） | https://docs.comfy.org/llms.txt |
| 自定义节点总览 | https://docs.comfy.org/custom-nodes/overview |
| Getting Started 走查 | https://docs.comfy.org/custom-nodes/walkthrough |
| Python 后端：节点类契约 | https://docs.comfy.org/custom-nodes/backend/server_overview |
| Python 后端：生命周期 | https://docs.comfy.org/custom-nodes/backend/lifecycle |
| Python 后端：数据类型 | https://docs.comfy.org/custom-nodes/backend/datatypes |
| Python 后端：图像/Latent/Mask | https://docs.comfy.org/custom-nodes/backend/images_and_masks |
| Python 后端：隐藏/灵活输入 | https://docs.comfy.org/custom-nodes/backend/more_on_inputs |
| Python 后端：惰性求值 | https://docs.comfy.org/custom-nodes/backend/lazy_evaluation |
| Python 后端：节点展开 | https://docs.comfy.org/custom-nodes/backend/expansion |
| Python 后端：数据列表 | https://docs.comfy.org/custom-nodes/backend/lists |
| Python 后端：torch.Tensor | https://docs.comfy.org/custom-nodes/backend/tensors |
| Python 后端：代码示例 | https://docs.comfy.org/custom-nodes/backend/snippets |
| Python 后端：节点替换 | https://docs.comfy.org/custom-nodes/backend/node-replacement |
| JS 前端：总览 | https://docs.comfy.org/custom-nodes/js/javascript_overview |
| JS 前端：hooks | https://docs.comfy.org/custom-nodes/js/javascript_hooks |
| JS 前端：对象与劫持 | https://docs.comfy.org/custom-nodes/js/javascript_objects_and_hijacking |
| JS 前端：示例 | https://docs.comfy.org/custom-nodes/js/javascript_examples |
| i18n 国际化 | https://docs.comfy.org/custom-nodes/i18n |
| 节点文档（Node Docs） | https://docs.comfy.org/custom-nodes/help_page |
| V3 迁移指南 | https://docs.comfy.org/custom-nodes/v3_migration |
| Workflow 模板 | https://docs.comfy.org/custom-nodes/workflow_templates |
| 子图蓝图 | https://docs.comfy.org/custom-nodes/subgraph_blueprints |
| 中文文档 | https://docs.comfy.org/zh/custom-nodes/overview |

## GitHub 仓库

| 仓库 | 说明 |
|---|---|
| https://github.com/comfyanonymous/ComfyUI | ComfyUI 主仓库（节点源码在 nodes.py / comfy_extras/） |
| https://github.com/Comfy-Org/ComfyUI_examples_custom_node | 官方自定义节点示例 |
| https://github.com/comfyui-wiki/ComfyUI-i18n-demo | i18n 演示节点 |
| https://github.com/Comfy-Org/ComfyUI_frontend | 前端仓库（ComfyUI_frontend） |

## 模板与工具

| 工具 | 说明 |
|---|---|
| comfy-cli | 官方 CLI：`comfy node scaffold` 生成项目；`comfy node publish` 发布到 Comfy Registry |
| cookiecutter-comfy-extension | 官方脚手架模板 |
| ComfyUI-React-Extension-Template | React 扩展模板 |
| ComfyUI_frontend_vue_basic | Vue 扩展模板 |
| Comfy Registry | 官方节点注册表（打包发布目标） |

## 其他

- 官方文档的 Markdown 源文件：https://github.com/Comfy-Org/docs
- Claude Code 的 ComfyUI Custom Node Skills（官方维护，9 个技能，覆盖 V1/V3 API）可在 Claude Code marketplace 安装。
