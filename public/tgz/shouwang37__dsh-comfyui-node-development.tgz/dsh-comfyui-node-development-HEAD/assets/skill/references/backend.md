# Backend 深度参考（Python）

> ComfyUI 自定义节点后端开发细节，来源：docs.comfy.org/custom-nodes/backend/*。

## 节点类完整契约

```python
class InvertImageNode:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": { "image_in" : ("IMAGE", {}) },
        }

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("image_out",)
    CATEGORY = "examples"
    FUNCTION = "invert"

    def invert(self, image_in):
        image_out = 1 - image_in
        return (image_out,)
```

### INPUT_TYPES
- 返回 dict，**必须**含 `required`，可含 `optional`、`hidden`。
- `required` 与 `optional` 的唯一区别：optional 允许悬空（未连接）。
- 每个输入：`名字 -> (类型字符串, 参数字典)`。
- 是 `@classmethod`，以便下拉选项在运行时计算（如 `folder_paths.get_filename_list("checkpoints")`）。

### FUNCTION 的执行函数
- 以**命名参数**调用；`required` + `hidden` 一定传入；`optional` 仅在已连接时传入 → 必须给默认值或用 `**kwargs`。
- 返回与 `RETURN_TYPES` 对应的 tuple（无输出时 `return ()`）；单输出必须带尾逗号。

### OUTPUT_NODE
默认节点不是输出节点。`OUTPUT_NODE = True` 声明为输出节点（始终执行），如 PreviewImage / SaveImage。

### IS_CHANGED
- `@classmethod`，参数与 FUNCTION 相同，返回任意 Python 对象，与上次返回值比较（`!=`）决定是否重跑。
- 不要返回 bool（True == True 恒等，等于“从不变化”）。
- 总是变化 → `return float("NaN")`（NaN != NaN）。会禁用缓存优化，尽量避免。
- 内置 LoadImage 示例：对文件做 sha256：

```python
@classmethod
def IS_CHANGED(s, image):
    image_path = folder_paths.get_annotated_filepath(image)
    m = hashlib.sha256()
    with open(image_path, 'rb') as f:
        m.update(f.read())
    return m.digest().hex()
```

### SEARCH_ALIASES
搜索别名列表，会出现在 `/object_info` 响应的 `search_aliases` 字段。

### VALIDATE_INPUTS
- 工作流执行前调用；返回 `True` 或错误消息字符串（阻止执行）。
- 只收到 workflow 中的**常量**输入；连接自其他节点的输入不可见。
- 只接收签名中声明的参数名（`inspect.getfullargspec` 分析）；声明过的输入跳过默认校验规则。
- 声明 `input_types` 参数 → 收到 `{输入名: 已连接输出类型}` 字典，且跳过全部默认类型校验：

```python
@classmethod
def VALIDATE_INPUTS(s, input_types):
    if input_types["input1"] not in ("INT", "FLOAT"):
        return "input1 must be an INT or FLOAT type"
    return True
```

## 隐藏输入

```python
"hidden": {
    "unique_id": "UNIQUE_ID",          # 节点 id，常用于客户端-服务端通信
    "prompt": "PROMPT",                # 完整 prompt 对象
    "extra_pnginfo": "EXTRA_PNGINFO",  # 写入 PNG 元数据（--disable_metadata 时不保存）
    "dynprompt": "DYNPROMPT",          # DynamicPrompt（可随节点展开变化，高级）
}
```

## 惰性求值

步骤：1) options 加 `{"lazy": True}`；2) 定义实例方法 `check_lazy_status`。
- 未就绪的惰性输入以 `None` 传入 `check_lazy_status`；返回仍需的输入名列表；可能被调用多次。
- 阻止执行：返回 `ExecutionBlocker(None)`（静默）或 `ExecutionBlocker("消息")`（显示错误）；会沿图传播且不可中途停止。

## 数据列表

- 内部数据流是 Python list（通常长度 1）；Comfy 自动包装/解包。
- 顺序处理：短列表重复末值补齐；主函数逐值调用；输出与最长输入等长（`map_node_over_list`）。
- `OUTPUT_IS_LIST = (True,)`：输出不包装，作为序列处理。
- `INPUT_IS_LIST = True`：节点级，所有输入一次传完整 list（widget 值也要取 `[0]`）。

## 代码示例（snippets）

```python
# 读图 → batch=1
i = Image.open(image_path); i = ImageOps.exif_transpose(i)
if i.mode == 'I': i = i.point(lambda i: i * (1 / 255))
image = i.convert("RGB")
image = np.array(image).astype(np.float32) / 255.0
image = torch.from_numpy(image)[None,]

# 存图批次
for (batch_number, image) in enumerate(images):
    i = 255. * image.cpu().numpy()
    img = Image.fromarray(np.clip(i, 0, 255).astype(np.uint8))
    img.save(f"path_{batch_number}.png")

# 反相 mask（mask 归一化到 [0,1]）
mask = 1.0 - mask

# mask → 图像形状 [B,H,W,1]
if len(mask.shape) == 2:        mask = mask[None,:,:,None]
elif len(mask.shape) == 3 and mask.shape[2] == 1: mask = mask[None,:,:,:]
elif len(mask.shape) == 3:      mask = mask[:,:,:,None]

# mask 作透明度通道
mask = 1.0 - mask
rgba_image = torch.cat((rgb_image, mask.unsqueeze(-1)), dim=-1)

# 混合噪声（NOISE 类型）
class Noise_MixedNoise:
    def __init__(self, noise1, noise2, weight2):
        self.noise1, self.noise2, self.weight2 = noise1, noise2, weight2
    @property
    def seed(self): return self.noise1.seed
    def generate_noise(self, input_latent):
        n1 = self.noise1.generate_noise(input_latent)
        n2 = self.noise2.generate_noise(input_latent)
        return n1 * (1.0 - self.weight2) + n2 * self.weight2
```
