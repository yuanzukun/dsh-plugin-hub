# 数据类型速查（Datatypes）

> 来源：https://docs.comfy.org/custom-nodes/backend/datatypes

## 输入附加参数（options 官方键）

| 键 | 说明 |
|---|---|
| `default` | 控件默认值 |
| `min` / `max` | 数值下限/上限（FLOAT/INT） |
| `step` | 数值步进 |
| `label_on` / `label_off` | BOOL 为 True/False 时的标签 |
| `defaultInput` | 默认生成输入口而非控件 |
| `forceInput` | 同 defaultInput，且禁止转换为控件（自定义类型必备） |
| `multiline` | STRING 多行文本框 |
| `placeholder` | 空值时的占位提示 |
| `dynamicPrompts` | 前端求值动态提示词 |
| `lazy` | 声明惰性求值（配合 check_lazy_status） |
| `rawLink` | 收到 `["nodeId", outputIndex]` 链接而非值（配合节点展开） |

## 核心类型表

| 类型 | Python 值 | 说明 |
|---|---|---|
| `COMBO` | `str` | 下拉框；INPUT_TYPES 中用 `list[str]` 表达；可运行时动态生成 |
| `INT` | `int` | default 必填 |
| `FLOAT` | `float` | default 必填 |
| `STRING` | `str` | default 必填 |
| `BOOLEAN` | `bool` | default 必填 |
| `IMAGE` | `torch.Tensor [B,H,W,C]` | 图像批次，C 一般 3（RGB） |
| `LATENT` | `dict{ samples: Tensor[B,C,H,W], ... }` | C 一般 4；宽高为图像 1/8；可含 latent mask 等 |
| `MASK` | `Tensor[H,W]` 或 `[B,C,H,W]` | 归一化到 [0,1] |
| `AUDIO` | `dict{ waveform: Tensor[B,C,T], sample_rate }` | C=2 立体声 / C=1 单声道 |
| `NOISE` | 对象 | `generate_noise(input_latent)->Tensor` + `seed: Optional[int]` |
| `SAMPLER` | 对象 | 提供 `sample` 方法 |
| `SIGMAS` | `Tensor[steps+1]` | 调度器产生的各步噪声值 |
| `GUIDER` | 可调用对象 | `__call__(noisy_latents)->noise_prediction` |
| `MODEL`/`CLIP`/`VAE`/`CONDITIONING` | 模型对象 | 进阶话题 |

## 特殊说明

- **COMBO 动态生成**：`"ckpt_name": (folder_paths.get_filename_list("checkpoints"), )`。
- **Primitive/Reroute**：纯客户端节点，无固有类型，连接后继承对方类型（因此不能连 `*` 输入）。
- **自定义类型**：唯一大写字符串（如 `CHEESE`），客户端只允许同类型互连；配合 `forceInput`。
- **通配符 `*`**：`("anything", ("*", {}))` + `VALIDATE_INPUTS(s, input_types)` 返回 True。
- **动态输入**：`ContainsAnyDict`（`__contains__` 恒真）作为 optional，`**kwargs` 接收。
- 附加键可以自定义，但不要改变官方键的语义。

## 张量形状速记

| 数据 | 形状 |
|---|---|
| IMAGE | `[B,H,W,C]` |
| LATENT samples | `[B,C,H,W]`（H,W 为图像 1/8） |
| MASK | `[H,W]` 或 `[B,C,H,W]` |
| AUDIO waveform | `[B,C,T]` |
| SIGMAS | `[steps+1]` |
