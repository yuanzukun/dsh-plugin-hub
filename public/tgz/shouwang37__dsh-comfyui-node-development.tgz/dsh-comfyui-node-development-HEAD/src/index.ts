/**
 * dsh-comfyui-node-development — DSH bundle plugin.
 *
 * Mounts the `comfyui-node-dev` runtime skill (a distilled bilingual guide to
 * ComfyUI custom node development) into the DSH skill registry. Loading the
 * skill makes the guide available to any agent that asks about ComfyUI node
 * development.
 * @module dsh-comfyui-node-development
 */

import type { Context } from '@deepseek-ai/cordis'
import { COMFYUI_NODE_DEV_SKILL } from './skill.ts'

export const name = 'dsh-comfyui-node-development'

export const inject = ['skills']

/** Plugin entry: register the skill, dispose on teardown. */
export function apply(ctx: Context): () => void {
  const disposer = ctx.skills.register(COMFYUI_NODE_DEV_SKILL)
  ctx.logger.info('dsh-comfyui-node-development: registered skill "%s"', COMFYUI_NODE_DEV_SKILL.name)
  return disposer
}
