/**
 * DSH skill registration for the ComfyUI custom node development guide.
 *
 * The skill body lives in `assets/skill/SKILL.md`; supporting deep-dive
 * references are shipped beside it under `assets/skill/references/` and are
 * reachable through the skill's directory resource base.
 * @module dsh-comfyui-node-development/skill
 */

import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import type { SkillRegistration } from '@deepseek-ai/dsh-skill'

/** Stable catalog / invocation name of the bundled guide skill. */
export const COMFYUI_NODE_DEV_SKILL_NAME = 'comfyui-node-dev'

/** Packaged resource root for the skill references. */
export const COMFYUI_NODE_DEV_SKILL_RESOURCE_BASE = fileURLToPath(
  new URL('../assets/skill/', import.meta.url),
)

/** Exact bundled instructions used as the skill body. */
export const COMFYUI_NODE_DEV_SKILL_CONTENT = readFileSync(
  new URL('../assets/skill/SKILL.md', import.meta.url),
  'utf8',
)

/** Runtime skill registration mounted by the plugin entry. */
export const COMFYUI_NODE_DEV_SKILL: SkillRegistration = {
  name: COMFYUI_NODE_DEV_SKILL_NAME,
  description: 'Bilingual (中文/English) distilled guide to ComfyUI custom node development: node class contract (INPUT_TYPES, RETURN_TYPES, CATEGORY, FUNCTION), registration via NODE_CLASS_MAPPINGS, built-in and custom datatypes, hidden/flexible inputs, lazy evaluation, data lists, client-side JavaScript extensions, i18n, node documentation, and the official documentation map.',
  whenToUse: 'Use whenever a task involves writing, fixing, reviewing, or explaining ComfyUI custom nodes: backend Python node classes, INPUT_TYPES/return contracts, node registration and lifecycle, datatypes (IMAGE, LATENT, MASK, COMBO, ...), lazy evaluation, list processing, frontend JS extensions (WEB_DIRECTORY, app.registerExtension), i18n locales, node docs, or the V1 → V3 migration.',
  source: 'runtime',
  resourceBase: {
    kind: 'directory',
    path: COMFYUI_NODE_DEV_SKILL_RESOURCE_BASE,
  },
  content: COMFYUI_NODE_DEV_SKILL_CONTENT,
}
