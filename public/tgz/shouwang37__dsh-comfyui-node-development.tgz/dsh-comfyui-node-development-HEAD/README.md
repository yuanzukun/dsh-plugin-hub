# dsh-comfyui-node-development

中文 | [日本語](README.ja.md)

**DeepSeek Harness（DSH）插件**：把 **ComfyUI 自定义节点开发**的浓缩双语指南（中文为主，保留英文术语）打包为运行时技能 `comfyui-node-dev`。

任何 DSH 智能体都可以按需加载该技能——它涵盖节点类契约（`INPUT_TYPES`、`RETURN_TYPES`、`CATEGORY`、`FUNCTION`）、节点注册与生命周期、数据类型、隐藏/灵活输入、惰性求值、列表处理、前端 JavaScript 扩展、国际化（i18n）、节点文档，以及 V1 → V3 迁移要点。

> 内容总结自 ComfyUI 官方文档（[docs.comfy.org](https://docs.comfy.org/custom-nodes/overview)，中文镜像 [docs.comfy.org/zh](https://docs.comfy.org/zh/custom-nodes/overview)）。本插件是学习辅助，不能替代官方文档。

## 特性

- **一个技能搞定一切**：`comfyui-node-dev` —— 任何涉及 ComfyUI 自定义节点的对话中都可加载。
- **深度参考分册**：`assets/skill/references/` 内置 `backend.md`、`frontend.md`、`datatypes.md`、`links.md`。
- **人类可读总结**：`docs/SUMMARY.zh.md` 与 `docs/SUMMARY.en.md`。
- **零运行时依赖**：插件仅通过 `ctx.skills` 注册运行时技能；peer 依赖只有 DSH profile 自带的两个包（`@deepseek-ai/cordis`、`@deepseek-ai/dsh-skill`）。

## 安装到 DSH

需要一个 DSH profile（如 `web`）。在终端执行：

```bash
# 从 GitHub 安装（推荐，零构建开箱即用）
dsh plugin --profile web add "github:shouwang37/dsh-comfyui-node-development"

# 或使用本地路径
dsh plugin --profile web add "file:C:/path/to/dsh-comfyui-node-development"
```

然后重启 DSH web 服务（或 profile 对应的进程管理器）。插件会作为 profile 图层 `comfyui-node-dev` 挂载，并注册 `comfyui-node-dev` 技能。

## 使用方法

在任意对话中提问，例如：

- "帮我写一个 ComfyUI 自定义节点"
- "ComfyUI 节点的 INPUT_TYPES 怎么写？"
- "怎么给 ComfyUI 节点加前端 JS 扩展？"
- "把这段节点代码从 V1 迁移到 V3"

任务匹配技能的 `whenToUse` 指引时，智能体会自动加载该技能。

## 开发

```bash
pnpm install
pnpm build        # tsc -> lib/
pnpm smoke        # 冒烟测试：在桩上下文中注册技能
```

> 说明：编译产物 `lib/` 会提交进仓库，这样从 GitHub 安装时无需执行构建脚本（pnpm 会拦截 git 依赖的构建脚本）。

## 仓库结构

```text
.
├── src/                     # 插件源码（Cordis 插件入口 + 技能注册）
├── assets/skill/            # 技能正文与分册（随插件分发给智能体）
├── docs/                    # 人类可读总结（中/英）
├── cordis.patch.yml         # DSH bundle 补丁（profile 图层挂载）
├── package.json             # 声明 dsh.bundle
└── scripts/smoke.mjs        # 冒烟测试
```

## 许可证

MIT —— 见 [LICENSE](LICENSE)。

## 相关链接

- 官方文档：<https://docs.comfy.org/custom-nodes/overview>
- ComfyUI 源码：<https://github.com/comfyanonymous/ComfyUI>
- 官方自定义节点示例：<https://github.com/Comfy-Org/ComfyUI_examples_custom_node>
