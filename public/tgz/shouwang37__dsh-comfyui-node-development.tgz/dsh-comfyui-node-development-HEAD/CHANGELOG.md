# Changelog

## 0.1.1 — 2025-07-17

- README.md is now the Chinese primary readme (the former English primary is
  superseded by `docs/SUMMARY.en.md`).
- Added `README.ja.md` (日本語版).
- Removed the now-redundant `README.zh.md` (Chinese content lives in `README.md`).

## 0.1.0 — 2025-07-17

- Initial release.
- Ships the `comfyui-node-dev` runtime skill: distilled bilingual guide to ComfyUI
  custom node development (node class contract, registration/lifecycle, datatypes,
  hidden/flexible inputs, lazy evaluation, lists, frontend JS extensions, i18n,
  node docs, V1 → V3 migration, official link map).
- Bundles deep-dive references under `assets/skill/references/` and human-readable
  summaries under `docs/`.
