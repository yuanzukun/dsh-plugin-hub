/**
 * dsh-comfyui-node-development — DSH bundle plugin.
 *
 * Mounts the `comfyui-node-dev` runtime skill (a distilled bilingual guide to
 * ComfyUI custom node development) into the DSH skill registry. Loading the
 * skill makes the guide available to any agent that asks about ComfyUI node
 * development.
 * @module dsh-comfyui-node-development
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "dsh-comfyui-node-development";
export declare const inject: string[];
/** Plugin entry: register the skill, dispose on teardown. */
export declare function apply(ctx: Context): () => void;
//# sourceMappingURL=index.d.ts.map