/**
 * DSH skill registration for the ComfyUI custom node development guide.
 *
 * The skill body lives in `assets/skill/SKILL.md`; supporting deep-dive
 * references are shipped beside it under `assets/skill/references/` and are
 * reachable through the skill's directory resource base.
 * @module dsh-comfyui-node-development/skill
 */
import type { SkillRegistration } from '@deepseek-ai/dsh-skill';
/** Stable catalog / invocation name of the bundled guide skill. */
export declare const COMFYUI_NODE_DEV_SKILL_NAME = "comfyui-node-dev";
/** Packaged resource root for the skill references. */
export declare const COMFYUI_NODE_DEV_SKILL_RESOURCE_BASE: string;
/** Exact bundled instructions used as the skill body. */
export declare const COMFYUI_NODE_DEV_SKILL_CONTENT: string;
/** Runtime skill registration mounted by the plugin entry. */
export declare const COMFYUI_NODE_DEV_SKILL: SkillRegistration;
//# sourceMappingURL=skill.d.ts.map