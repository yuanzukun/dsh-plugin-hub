# ComfyUI Custom Node Development — Summary (English)

A distilled, practical summary of the official ComfyUI custom node development documentation
(<https://docs.comfy.org/custom-nodes/overview>). The Chinese version lives in `docs/SUMMARY.zh.md`;
the DSH skill ships this guide as `assets/skill/SKILL.md`.

## 1. Client-Server Model

Comfy runs a client-server architecture:

- **Server (Python)**: all real work — data processing, models, diffusion.
- **Client (JavaScript)**: the user interface (canvas, widgets, menus).
- **API mode**: non-Comfy clients can submit a workflow JSON to the server directly.

Custom nodes fall into four categories:

| Category | Description |
|---|---|
| Server side only | Most nodes: a Python class declaring input/output types plus a processing function |
| Client side only | UI-only modifications; may not even add nodes |
| Independent client + server | Server features plus related UI; communicate through Comfy data flow |
| Connected client + server | UI and server talk directly (e.g. `PromptServer.send_sync`); **incompatible with API mode** |

## 2. Project Layout & Lifecycle

Comfy scans `ComfyUI/custom_nodes/` for Python modules (directories with `__init__.py`) at startup.
A module exporting `NODE_CLASS_MAPPINGS` is treated as a custom node pack. On import errors Comfy
keeps running but reports the module as failed — **always check the Python console**.

```
ComfyUI/
└── custom_nodes/
    └── my_node_pack/
        ├── __init__.py          # entry: export registration mappings
        ├── src/nodes.py         # node classes
        └── web/js/              # optional: frontend JS (WEB_DIRECTORY)
```

Minimal `__init__.py`:

```python
from .src.nodes import MyCustomNode

NODE_CLASS_MAPPINGS = { "My Custom Node": MyCustomNode }
NODE_DISPLAY_NAME_MAPPINGS = { "My Custom Node": "My Custom Node" }
__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS"]
```

- `NODE_CLASS_MAPPINGS`: dict of unique node names → classes (unique across the whole install).
- `NODE_DISPLAY_NAME_MAPPINGS`: optional display names.
- `WEB_DIRECTORY`: optional path to your JS directory (convention `./js`). **Only `.js` files are
  auto-loaded**; other assets are served under `extensions/<node_subdir>/<file>`.
- Restart ComfyUI after code changes.
- Quick start: `comfy node scaffold` (comfy-cli) inside `custom_nodes`.

## 3. Minimal Node Skeleton

```python
import torch

class ImageSelector:
    CATEGORY = "example"                       # Add Node menu path ("example/trivial" for submenus)

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": { "images": ("IMAGE",) },
            "optional": { "mode": (["brightest", "reddest", "greenest", "bluest"],) },
        }

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("image_out",)              # optional
    FUNCTION = "choose_image"

    def choose_image(self, images, mode="brightest"):
        brightness = [torch.mean(img.flatten()).item() for img in images]  # IMAGE: [B,H,W,C]
        best = brightness.index(max(brightness))
        return (images[best].unsqueeze(0),)    # must return a tuple — keep the trailing comma
```

## 4. Node Class Contract

| Attribute | Required | Notes |
|---|---|---|
| `INPUT_TYPES` | ✅ | `@classmethod` returning a dict; must contain `required`, may contain `optional`/`hidden`. Entries: `"name": ("TYPE", {options})` |
| `RETURN_TYPES` | ✅ | Tuple of output types; use `()` for no outputs; single output needs the trailing comma |
| `RETURN_NAMES` | optional | Output labels; defaults to lowercased types |
| `CATEGORY` | ✅ | Menu location, e.g. `"image/batch"` |
| `FUNCTION` | ✅ | Name of the execution method; receives `required`+`hidden` by name; `optional` only when connected (give defaults or `**kwargs`); returns a tuple |

`INPUT_TYPES` is a classmethod so dropdown options (e.g. checkpoint lists) can be computed at runtime.

### Execution control & caching

- `OUTPUT_NODE = True` — mark as an output node (always executed; e.g. Preview/Save).
- `IS_CHANGED` — `@classmethod` with the same args as FUNCTION; returns any Python object compared
  (`!=`) with the previous run. **Never return a bool** (`True == True` means "unchanged").
  Return `float("NaN")` to always re-run (NaN != NaN) — avoid unless necessary; it disables caching.
  Built-in `LoadImage` returns a sha256 hex digest of the file.
- `SEARCH_ALIASES` — optional search aliases (surfaced in `/object_info`).
- `VALIDATE_INPUTS` — `@classmethod` called before execution; return `True` or an error string.
  Receives only constant inputs; only args declared in its signature skip default validation.
  Declaring an `input_types` arg receives `{input_name: connected_output_type}` and skips all
  default type validation (required for `"*"` wildcard inputs).

## 5. Datatypes

| Type | Extra options | Python value |
|---|---|---|
| `COMBO` | none (`list[str]` as type = dropdown) | `str` |
| `INT` | `default` required; `min`/`max` optional | `int` |
| `FLOAT` | `default` required; `min`/`max`/`step` | `float` |
| `STRING` | `default` required | `str` |
| `BOOLEAN` | `default` required | `bool` |
| `IMAGE` | none | `torch.Tensor [B,H,W,C]` (C=3 RGB) |
| `LATENT` | none | `dict` with `samples: Tensor [B,C,H,W]` (C=4; H,W = image/8) |
| `MASK` | none | `Tensor [H,W]` or `[B,C,H,W]` |
| `AUDIO` | none | `dict`: `waveform [B,C,T]` + `sample_rate` |
| `NOISE` | — | object with `generate_noise(input_latent)->Tensor` and `seed` |
| `SAMPLER` | — | object with a `sample` method |
| `SIGMAS` | — | 1-D tensor of `steps+1` values |
| `GUIDER` | — | callable predicting noise |
| `MODEL`/`CLIP`/`VAE`/`CONDITIONING` | — | advanced model types |

Supported input option keys: `default`, `min`, `max`, `step`, `label_on`, `label_off`,
`defaultInput`, `forceInput`, `multiline`, `placeholder`, `dynamicPrompts`, `lazy`, `rawLink`.
Custom keys are allowed but must not reuse the official semantics.

- **Custom datatypes**: unique uppercase string (e.g. `"CHEESE"`); only same-type connections allowed;
  add `{"forceInput": True}` since the client doesn't know the type. Any Python object.
- **Wildcard `"*"`**: `("anything", ("*", {}))` + `VALIDATE_INPUTS(s, input_types)` returning `True`.
- **Dynamic inputs**: a dict subclass with `__contains__` always True as `optional`, receive via `**kwargs`.

## 6. Hidden Inputs

```python
"hidden": {
    "unique_id": "UNIQUE_ID",         # node id (matches client-side node id); used for comms
    "prompt": "PROMPT",               # full prompt object
    "extra_pnginfo": "EXTRA_PNGINFO", # written into saved PNG metadata (skipped with --disable_metadata)
    "dynprompt": "DYNPROMPT",         # comfy_execution.graph.DynamicPrompt (advanced: loops)
}
```

## 7. Lazy Evaluation & Lists

### Lazy evaluation (v0.2.0+)

1. Mark inputs `{"lazy": True}` in `INPUT_TYPES`.
2. Define an instance method `check_lazy_status(self, ...)` (not a classmethod): unavailable lazy
   inputs arrive as `None`; return the list of input names still needed (empty = all ready).
   May be called multiple times.

```python
def check_lazy_status(self, mask, image1, image2):
    mask_min, mask_max = mask.min(), mask.max()
    needed = []
    if image1 is None and (mask_min != 1.0 or mask_max != 1.0): needed.append("image1")
    if image2 is None and (mask_min != 0.0 or mask_max != 0.0): needed.append("image2")
    return needed
```

- Cheap to add; do it whenever an input may be unused.
- To disable an output node you control: add an `enabled` input (default True) and make other inputs lazy.
- Otherwise return `comfy_execution.graph.ExecutionBlocker(None)` (silent) or
  `ExecutionBlocker("message")` (error). Blockers propagate forward; there is no way to stop them —
  use lazy evaluation instead.

### Data lists

- Internally data flows as Python lists (normally length 1; Comfy wraps/unwraps automatically).
- Sequential processing by default: shorter lists repeat their last value; the main method runs once
  per value; outputs are lists as long as the longest input (`map_node_over_list` in `execution.py`).
- `OUTPUT_IS_LIST = (True,)` — treat the output as a series, don't wrap it.
- `INPUT_IS_LIST = True` — node-level; all inputs arrive as full lists (`batch_size[0]` for widgets).
  See built-in `ImageRebatch`.

## 8. Frontend JavaScript Extensions

Three steps: export `WEB_DIRECTORY` → drop `.js` files into it → register with `app.registerExtension`.

```python
WEB_DIRECTORY = "./js"
__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS", "WEB_DIRECTORY"]
```

```javascript
import { app } from "../../scripts/app.js";
app.registerExtension({
    name: "a.unique.name",
    async setup() { /* called on page load */ },
    // also: beforeRegisterNodeDef, nodeCreated, getCustomWidgets, ...
})
```

- All `.js` files load automatically with the page; no entry file declaration needed.
- Server → client messages: `PromptServer.instance.send_sync("unique.type", {...})` in Python;
  `app.api.addEventListener("unique.type", handler)` in JS; payload in `event.detail`.
- Useful objects: `app`, `app.api`, `LiteGraph`, `ComfyWidgets`.

## 9. i18n

Supported locales: en, zh, zh-TW, fr, ko, ru, es, ja, ar.
Create a `locales/` folder in your custom node:

```
locales/
├── en/   # recommended base
│   ├── main.json      # general strings + settingsCategories
│   ├── nodeDefs.json  # node definition translations (display_name/description/inputs/outputs/options)
│   ├── settings.json  # settings translations (optional)
│   └── commands.json  # command translations (optional)
└── zh/   # same structure per locale
```

- `nodeDefs.json` keys are node class names; outputs are keyed by **index** (`"0"`, `"1"`, ...).
- Settings translation keys replace `.` with `_` (`I18nDemo.EnableDebugMode` → `I18nDemo_EnableDebugMode`).
- Demo: <https://github.com/comfyui-wiki/ComfyUI-i18n-demo>

## 10. Node Documentation

Put markdown docs under `WEB_DIRECTORY/docs/` named after the registered node names; the UI picks
the user's locale automatically:

```
web/docs/
├── MyNode.md          # fallback
└── MyNode/
    ├── en.md
    └── zh.md
```

Standard markdown, images, and `<video>/<source>` (attributes limited to
controls/autoplay/loop/muted/preload/poster) are supported. Adding `tooltip` to input options also
enriches the node documentation panel.

## 11. V3 Migration (new API)

- Base class `ComfyNode`; `define_schema(...)` replaces `INPUT_TYPES`; typed schemas with controls
  like `control_after_generate`.
- `execute(...)` (async-capable) replaces the `FUNCTION` method.
- `validate(...)` and `cache_control(...)` replace V1 attributes.
- Packaging moves to `comfy_cli` + `pyproject.toml`.
- See the official V3 Migration guide.

## 12. Official Links

| Topic | URL |
|---|---|
| Overview | https://docs.comfy.org/custom-nodes/overview |
| Getting Started walkthrough | https://docs.comfy.org/custom-nodes/walkthrough |
| Properties (node contract) | https://docs.comfy.org/custom-nodes/backend/server_overview |
| Lifecycle | https://docs.comfy.org/custom-nodes/backend/lifecycle |
| Datatypes | https://docs.comfy.org/custom-nodes/backend/datatypes |
| Hidden/flexible inputs | https://docs.comfy.org/custom-nodes/backend/more_on_inputs |
| Lazy evaluation | https://docs.comfy.org/custom-nodes/backend/lazy_evaluation |
| Data lists | https://docs.comfy.org/custom-nodes/backend/lists |
| Snippets | https://docs.comfy.org/custom-nodes/backend/snippets |
| JS overview | https://docs.comfy.org/custom-nodes/js/javascript_overview |
| i18n | https://docs.comfy.org/custom-nodes/i18n |
| Node docs | https://docs.comfy.org/custom-nodes/help_page |
| V3 migration | https://docs.comfy.org/custom-nodes/v3_migration |
| ComfyUI source | https://github.com/comfyanonymous/ComfyUI |
| Official examples | https://github.com/Comfy-Org/ComfyUI_examples_custom_node |
| Chinese docs | https://docs.comfy.org/zh/custom-nodes/overview |

**Common pitfalls**: missing trailing comma for a single output; forgetting `@classmethod` on
`INPUT_TYPES`; renaming nodes without updating `NODE_CLASS_MAPPINGS`; not restarting Comfy after
changes; `IS_CHANGED` returning a bool; custom datatypes without `forceInput`; forgetting to export
`WEB_DIRECTORY` for JS extensions.
