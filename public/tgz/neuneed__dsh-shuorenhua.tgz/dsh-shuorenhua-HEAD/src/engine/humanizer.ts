/**
 * Core Humanizer Rule Engine (Offline/Local Fallback).
 * Transforms robotic, verbose, and buzzword-heavy AI text into clean, direct, human-friendly speech.
 */

import type { HumanizeOptions, HumanizeResult, HumanizeStats } from '../types.js'
import { protectVerbatim, restoreVerbatim } from './placeholders.js'
import {
  BUZZWORD_REPLACEMENTS,
  CLOSING_BOILERPLATES,
  FILLER_SENTENCES,
  META_FILLERS,
  OPENING_GREETINGS,
  applyDenominalization,
  stripRepetitiveEchoes,
} from './rules.js'

/**
 * Humanize a given text using unified rules.
 * @param input - Original text to humanize.
 * @param options - Behavior options.
 * @returns HumanizeResult containing simplified text and metrics.
 */
export function humanize(input: string, options: HumanizeOptions = {}): HumanizeResult {
  const rawInput = input ?? ''
  if (!rawInput.trim()) {
    return {
      text: '',
      original: rawInput,
      mode: 'default',
      source: 'rule',
      stats: {
        originalLength: 0,
        humanizedLength: 0,
        savedPercentage: 0,
        removedOpeners: 0,
        removedClosers: 0,
        replacedBuzzwords: 0,
      },
    }
  }

  // 1. Protect code blocks, math, inline code, and URLs unless disabled
  const preserveCode = options.preserveCode !== false
  const { text: protectedContent, placeholders } = preserveCode
    ? protectVerbatim(rawInput)
    : { text: rawInput, placeholders: new Map<string, string>() }
  let processed = protectedContent.trim()
  let removedOpeners = 0
  let removedClosers = 0
  let replacedBuzzwords = 0

  // 2. Iteratively strip opening greetings until none remain
  let openerMatched = true
  while (openerMatched) {
    openerMatched = false
    for (const regex of OPENING_GREETINGS) {
      if (regex.test(processed)) {
        processed = processed.replace(regex, '').trim()
        removedOpeners++
        openerMatched = true
      }
    }
  }

  // 3. Iteratively strip closing boilerplates until none remain
  let closerMatched = true
  while (closerMatched) {
    closerMatched = false
    for (const regex of CLOSING_BOILERPLATES) {
      if (regex.test(processed)) {
        processed = processed.replace(regex, '').trim()
        removedClosers++
        closerMatched = true
      }
    }
  }

  // 4. Strip filler sentences
  for (const regex of FILLER_SENTENCES) {
    if (regex.test(processed)) {
      processed = processed.replaceAll(regex, '')
    }
  }

  // 4.5 Strip meta-commentary and transition fillers (MrGeDiao/shuorenhua)
  for (const regex of META_FILLERS) {
    if (regex.test(processed)) {
      processed = processed.replaceAll(regex, '')
    }
  }

  // 4.6 Apply de-nominalization (e.g. 完成了对重试策略的调整 -> 调整了重试策略)
  processed = applyDenominalization(processed)

  // 4.7 Strip repetitive echoes and circular restatements (e.g. 重试策略已经调整过了)
  processed = stripRepetitiveEchoes(processed)

  // 4.8 Smooth commas between action and metric result
  processed = processed.replace(/([。])\s*(重复请求|失败请求|请求数|耗时|延迟|错误率|吞吐量|QPS|中位数|失败数)/g, '，$2')

  // 5. Replace buzzwords
  for (const item of BUZZWORD_REPLACEMENTS) {
    const matches = processed.match(item.pattern)
    if (matches && matches.length > 0) {
      replacedBuzzwords += matches.length
      processed = processed.replaceAll(item.pattern, item.replacement)
    }
  }

  // 6. Break mechanical tripartite openers into crisp points & remove transitional clutter
  processed = processed
    .replace(/(^|\n)首先[，,]?\s*/g, '$11. ')
    .replace(/(^|\n)其次[，,]?\s*/g, '$12. ')
    .replace(/(^|\n)再次[，,]?\s*/g, '$13. ')
    .replace(/(^|\n)最后[，,]?\s*/g, '$14. ')
    .replace(/(^|\n)第一[，、]?\s*/g, '$11. ')
    .replace(/(^|\n)第二[，、]?\s*/g, '$12. ')
    .replace(/(^|\n)第三[，、]?\s*/g, '$13. ')
    .replace(/[，,]?(总的来说|总而言之|综上所述)[，,]?/g, '')
    .replace(/[，,]?(显而易见|毋庸置疑)[，,]?/g, '')

  // Clean excessive blank lines (more than 2 consecutive newlines)
  processed = processed.replace(/\n{3,}/g, '\n\n').trim()

  // 7. Restore code blocks and verbatim elements
  const finalResult = restoreVerbatim(processed, placeholders)

  const originalLength = rawInput.length
  const humanizedLength = finalResult.length
  const savedRatio = originalLength > 0
    ? Math.max(0, Math.round(((originalLength - humanizedLength) / originalLength) * 100))
    : 0

  const stats: HumanizeStats = {
    originalLength,
    humanizedLength,
    savedPercentage: savedRatio,
    removedOpeners,
    removedClosers,
    replacedBuzzwords,
  }

  return {
    text: finalResult,
    original: rawInput,
    mode: 'default',
    source: 'rule',
    stats,
  }
}
