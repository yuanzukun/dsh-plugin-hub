// dsh-zh-output 官方同步器：
// 以官方 shipped 预设的 agent.cordis.yml 为骨架整文件重建中文预设，把本仓库
// git HEAD 里同 id 行、同文本键（text/description/section 等）的中文值整体
// 移植回去，并把压缩引擎行换成 dsh-zh-compaction。
//
// 用法：node tools/sync-from-official.mjs
// 环境变量：
//   OFFICIAL_PRESETS  官方预设目录（默认取 dsh 安装包内
//                     @deepseek-ai/dsh-agent-presets/presets，可指向官方仓库
//                     packages/preset/agent-presets/presets 的最新 checkout）
//   ZH_PRESETS        本仓库 presets 目录（默认自动推断）
//
// 运行后注意：
//   1) 输出的 AUDIT 段落 = 官方新增、旧中文版没有译文（或未中文化）的文本值，
//      需人工补译（参考同风格相邻译文）。
//   2) 预设重建后结构=官方，故旧 zh 文件中任何“绕开官方结构”的定制会丢失；
//      zh-compaction 引擎行是本脚本唯一保留的结构差异。
import { readFileSync, writeFileSync } from 'node:fs';
import { execSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = join(here, '..');
const OFF = process.env.OFFICIAL_PRESETS
  ?? 'C:/ytsProgramFiles/software/nodejs/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-agent-presets/presets';
const REPO = process.env.ZH_PRESETS ?? join(REPO_ROOT, 'presets');

const PAIRS = [
  ['standard', 'standard-zh'],
  ['ptc', 'code-zh'],
  ['cordis', 'cordis-zh'],
  ['minimal', 'minimal-zh'],
];

const TEXT_KEYS = new Set(['text', 'description', 'prompt', 'guidance', 'template', 'instruction', 'section']);

function oldZhSource(id) {
  // 原始中文文件 = git HEAD 版本（未被本脚本覆盖）
  return execSync(`git -C "${REPO_ROOT}" show HEAD:presets/${id}/agent.cordis.yml`, { encoding: 'utf8' });
}

// 把文件切为 id -> { indent, blockLines } 的“行块”(id 所在行及其后直到下一个同级或更浅 id 行)。
// 注意只处理以 '-' 开头携带 id: 的行（含嵌套）。
function segmentize(lines) {
  // find all row-start indexes (any indent)
  const starts = [];
  for (let i = 0; i < lines.length; i++) {
    if (/^\s*-\s*id:\s*\S/.test(lines[i]) && !/^\s*#/.test(lines[i])) starts.push(i);
  }
  const segs = [];
  for (let s = 0; s < starts.length; s++) {
    const from = starts[s];
    const to = s + 1 < starts.length ? starts[s + 1] : lines.length;
    const idm = lines[from].match(/^\s*-\s*id:\s*(\S+)/);
    segs.push({ id: idm[1], from, to, lines: lines.slice(from, to) });
  }
  return segs;
}

function keyIndentOf(line) {
  const m = line.match(/^(\s*)(text|description|prompt|guidance|template|instruction|section):/);
  return m ? m[1].length : -1;
}

// 在 segment lines(行块内)找指定文本键的值跨度(整体行范围，含键行)
function findKeySpan(segLines, key) {
  for (let i = 0; i < segLines.length; i++) {
    const m = segLines[i].match(/^(\s*)(?:'+)?(?:- )?(text|description|prompt|guidance|template|instruction|section):\s*(\S.*)?$/);
    if (!m) continue;
    if (m[2] !== key) continue;
    const ki = m[1].length;
    const rest = m[3] ?? '';
    if (rest !== '' && !/^[|>][-+]?/.test(rest)) {
      return { from: i, to: i + 1 }; // 单行标量
    }
    // 块标量或空值：一直收到缩进 <= ki 的行
    let j = i + 1;
    let last = j;
    while (j < segLines.length) {
      const ln = segLines[j];
      const t = ln.trim();
      if (t === '') { j++; continue; }
      const ind = ln.match(/^(\s*)/)[1].length;
      if (ind <= ki) break;
      last = j + 1;
      j++;
    }
    return { from: i, to: last };
  }
  return null;
}

function hasCJK(s) { return /[\u4e00-\u9fff]/.test(s); }

const audit = [];

for (const [offId, zhId] of PAIRS) {
  const offFile = join(OFF, offId, 'agent.cordis.yml');
  const oldZhFile = join(REPO, zhId, 'agent.cordis.yml');
  const outFile = join(REPO, zhId, 'agent.cordis.yml');

  let offLines = readFileSync(offFile, 'utf8').split(/\r?\n/);
  const zhLines = oldZhSource(zhId).split(/\r?\n/);
  const zhSegs = segmentize(zhLines);
  const zhMap = new Map(zhSegs.map((s) => [s.id, s]));
  const offSegs = segmentize(offLines);

  const replaceSpan = (seg, key, srcLines) => {
    const span = findKeySpan(seg.lines, key);
    if (!span) return false;
    const segAbsFrom = seg.from;
    const target = offLines.slice(segAbsFrom + span.from, segAbsFrom + span.to);
    // 目标键行缩进
    const tKeyLine = target[0];
    const ki = keyIndentOf(tKeyLine);
    if (ki < 0) return false;
    // 源(zh)键行与值行，缩进规范化到相同深度
    const sKeyLine = srcLines[0];
    const si = keyIndentOf(sKeyLine);
    if (si < 0) return false;
    const shift = ki - si;
    const shifted = srcLines.map((l) => {
      if (l.trim() === '') return l.trim() === '' ? (l.length === 0 ? '' : l) : l;
      const m = l.match(/^(\s*)/);
      return ' '.repeat(m[1].length + shift) + l.slice(m[1].length);
    });
    offLines = [...offLines.slice(0, segAbsFrom + span.from), ...shifted, ...offLines.slice(segAbsFrom + span.to)];
    return true;
  };

  // 1) 每个官方 segment：若旧 zh 有同名 id 且同键的中文值 → 移植
  // 注意：splice 会改变后续段的行偏移，因此逆序处理（先改后面的段），
  // 且每次成功修改后重新分片，保证 seg.from 实时有效。
  const idOrder = offSegs.map((s) => s.id);
  const touched = new Set();
  const DBG = !!process.env.DBG;
  for (let oi = idOrder.length - 1; oi >= 0; oi--) {
    const id = idOrder[oi];
    const zseg = zhSegs.find((s) => s.id === id);
    const seg = segmentize(offLines).find((s) => s.id === id);
    if (DBG) console.log(`[dbg ${zhId}] official seg id=${id} ${seg ? '' : '(not found in current)'}`);
    if (!seg || !zseg) continue;
    let changed = false;
    for (const key of TEXT_KEYS) {
      const zspan = findKeySpan(zseg.lines, key);
      if (!zspan) continue;
      const zval = zseg.lines.slice(zspan.from, zspan.to);
      if (DBG) console.log(`  zh has key ${key} cjk=${hasCJK(zval.join('\n'))}`);
      if (!hasCJK(zval.join('\n'))) continue; // 旧 zh 该键非中文，不移植
      const segCur = segmentize(offLines).find((s) => s.id === id);
      if (replaceSpan(segCur, key, zval)) {
        touched.add(`${id}:${key}`);
        changed = true;
        break;
      }
    }
    if (changed) offLines = offLines; // 已在 replaceSpan 中重赋值
  }

  // 2) 压缩引擎行替换：官方 compaction-basic -> dsh-zh-compaction
  offLines = offLines.map((l) => {
    if (/^\s*-\s*id:\s*compaction-basic\s*$/.test(l)) return l.replace('compaction-basic', 'zh-compaction');
    if (/^\s*name:\s*['"]@deepseek-ai\/dsh-compaction-basic['"]\s*$/.test(l)) return l.replace('@deepseek-ai/dsh-compaction-basic', 'dsh-zh-compaction');
    return l;
  });

  writeFileSync(outFile, offLines.join('\n') + '\n', { encoding: 'utf8', flag: 'w' });

  // 3) 审计：输出文件中残留的英文文本值（含中文的跳过）
  const newLines = readFileSync(outFile, 'utf8').split(/\r?\n/);
  for (const seg of segmentize(newLines)) {
    for (const key of TEXT_KEYS) {
      const span = findKeySpan(seg.lines, key);
      if (!span) continue;
      const val = seg.lines.slice(span.from + (span.to - span.from > 1 ? 1 : 0), span.to).join(' ').trim();
      const cjk = hasCJK(val);
      const alpha = /[A-Za-z]{4}/.test(val);
      if (alpha && !cjk && val.length > 0) {
        audit.push(`${zhId}\t${seg.id}\t${key}\t${val.slice(0, 110).replace(/\s+/g, ' ')}`);
      }
    }
  }
  console.log(`[done] ${zhId}: transplanted=${[...touched].join(', ') || '(none)'}`);
}

console.log('\n==== AUDIT: leftover English text values ====');
for (const a of audit) console.log(a);
console.log(`\n(${audit.length} leftover entries)`);
