# Registry submission (awesome-dsh-plugin)

`entries/` holds one ready-to-submit file per craft plugin for the curated
[awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin)
registry, which dshmarket.com and the in-app market read.

## Status

The first twelve subpackage entries were merged upstream in four pull requests
(#9374, #9405, #9406, #9408). The 2026-11 release adds two more applications —
FigCraft and TextureCraft — whose entries are in this directory and are not yet
submitted; both fit in one pull request under the three-entry cap.

## Why the first attempt was closed

[PR #7314](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/pull/7314) submitted the
**repository root** as one entry. A maintainer closed it because the root is a pure
aggregation bundle — rule 7 in `contributing.md`: its `cordis.patch.yml` only inserts the
twelve subpackage rows and it ships no behaviour of its own, so it is not listed. The rule is
"list the plugins, not the bundle".

The good news the same comment gives: **each of the twelve subpackages carries its own
`dsh.bundle` and installs independently**, so each qualifies as its own entry.

## The correct entry shape

A monorepo subpackage entry points `url` at the subdirectory and uses
`owner/repo#label` as `name`:

```yaml
url: https://github.com/lznnnnn1998/dsh-artcraft/tree/main/dsh-plugins/plugin-gridcraft
name: lznnnnn1998/dsh-artcraft#plugin-gridcraft
category: tools
description:
  en: ...
  zh: ...
```

The filename is `owner__repo--<subpath with / replaced by ->.yml`, which is why these files
are named `lznnnnn1998__dsh-artcraft--dsh-plugins-plugin-<craft>.yml`.

## Submission rules that shape the plan

- **At most 3 entries per pull request.** Checked first, before anything is fetched.
- **"Split *and* pick"** — send what you would keep if you could only keep a few, not
  everything that works. Batching more than one PR is expected; dumping all twelve in one go
  is not.
- **The 1-day repo-age bar** is met (the repository was created 2026-10-12).
- `dsh.bundle` is resolved by walking the repository's manifests, so the `dsh-plugins/`
  directory name is fine — the `packages/` · `plugins/` · `apps/` names in the docs are
  examples, not a whitelist.

## Batches

The twelve merged entries went in as four batches of three. The current pending
batch is the two 2026-11 applications:

| Batch | Crafts | Status |
|---|---|---|
| 1 | gridcraft, cadcraft, soundcraft | merged (#9374) |
| 2 | wordcraft, photocraft, vectorcraft | merged (#9405) |
| 3 | deckcraft, pdfcraft, designcraft | merged (#9406) |
| 4 | filmcraft, effectcraft, lightcraft | merged (#9408) |
| 5 | figcraft, texturecraft | prepared, not yet submitted |

## How to submit

For each file, create it at `data/plugins/<filename>` in the registry repository. Opening the
"new file" page on the upstream repository auto-proposes a fork and pull request:

<https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/new/main/data/plugins>

Paste the file's contents, name the file exactly as above, choose
**Create a new branch for this commit and start a pull request**, and open the PR. For a batch,
do all three files in one commit so they form a single PR.

Check the result against the rules before opening: `url` matches the repository and
subdirectory, `name` names the same repository, `category` is from the valid list, and both
descriptions state what the plugin does with no superlatives.

## Local validation

```sh
node scripts/validate-registry-entries.mjs
```

It parses each entry with a real YAML parser (taken from the harness checkout this repository
already needs) and checks the rules the registry's own CI checks: the URL shape, that the
subdirectory exists and declares `dsh.bundle.patch`, that official `@deepseek-ai/*` packages are
peers rather than dependencies, the filename convention, that `name` names the same repository, a
valid `category`, and both non-empty descriptions without superlatives.

**Parse before you paste.** An unquoted `: ` inside a description — `Drive GridCraft from the
agent: build …` — makes YAML read the rest of the line as a nested mapping, and the entry fails
with `bad indentation of a mapping entry`. Descriptions here are double-quoted for that reason,
which also keeps the apostrophes in text like `CADCraft's` legal. A regex check cannot catch this;
only a parser can.
