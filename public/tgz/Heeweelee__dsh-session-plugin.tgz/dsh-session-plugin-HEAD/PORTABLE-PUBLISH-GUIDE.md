# 发布随身包使用说明（0.1.6）

生成时间：2026-09-01
目标：把 `@heeweelee/dsh-session-plugin@0.1.6` 发布到 npm，推送 GitHub `v0.1.6` 标签，并把条目更新进 1024Store。

0.1.6 是**面向 DSH 2.0.4 的兼容性修复**：npm 上的 `latest` 是 0.1.5，而 0.1.5 在 DSH 2.0.4 上 `↑`/`↓` 完全无响应（composer 已从 `<textarea>` 换成 Lexical contenteditable）。所以这次发布有实际紧迫性，不是版本号装饰。

## 本机已完成（无需重复）

- [x] 代码修复：`dist/client.js` 的 composer 表面判定统一为 `isComposerSurface` / `findComposerSurface`
- [x] `package.json` 版本 0.1.5 → 0.1.6；`CHANGELOG.md` / `README.md` / `1024store-entry.json` 同步
- [x] `pnpm pack` 产物：`heeweelee-dsh-session-plugin-0.1.6.tgz`（仓库工作区内）
  - **不进 git**：`.gitignore` 有 `*.tgz`（0.1.5 当时也是这样，tarball 靠文件拷贝携带）
  - 同时存于 `C:\Users\<you>\.dsh\dsh-session-plugin-0.1.6.tgz`（同字节）
  - integrity：见 `RELEASE-NOTES-0.1.6.md`，与 profile lock 中的 `resolution.integrity` 一致
- [x] **本地已安装并跑通**：profile 的 `file:` 钉到 0.1.6 tarball，`pnpm install --lockfile-only --offline` 通过，
      `node_modules/@heeweelee/dsh-session-plugin` 内容与 tarball 逐字节一致
- [x] `git tag v0.1.6` + `dsh-session-plugin-v0.1.6.bundle`（含全部分支与标签）

## 随身包含两个文件

（两者都只存在于工作区、不进 git：tarball 被 `.gitignore` 的 `*.tgz` 排除，bundle 本身就是脱离 git 的携带载体。）

1. `heeweelee-dsh-session-plugin-0.1.6.tgz` — 官方发布 tarball（`pnpm pack` 产物）。**npm publish 就用它。**
2. `dsh-session-plugin-v0.1.6.bundle` — git bundle（全部提交 + `v0.1.6` 标签），用于在另一台电脑还原完整历史。

## 第 1 步：npm 发布（需要你的凭据）

本机 `npm whoami` 返回 **401 Unauthorized**（`~/.npmrc` 里的 token 失效），所以这一步换到有凭据的电脑做：

```bash
npm whoami                       # 401 就先 npm login
npm publish heeweelee-dsh-session-plugin-0.1.6.tgz --access public
npm view @heeweelee/dsh-session-plugin versions   # 应出现 0.1.6
```

发布前若想复核包内容：

```bash
tar -xzf heeweelee-dsh-session-plugin-0.1.6.tgz -O package/dist/client.js | sha1sum
# 期望 2c3324ff6d28ffeb3634e8d93ad5bdbb3011acab（与仓库 dist/client.js 同一份字节）
```

## 第 2 步：GitHub 推送

```bash
git push origin main
git push origin v0.1.6
```

若本机到 GitHub 不通，用 bundle 在能直连的机器上还原：

```bash
git clone dsh-session-plugin-v0.1.6.bundle dsh-session-plugin && cd dsh-session-plugin
git remote set-url origin https://github.com/Heeweelee/dsh-session-plugin.git
git push origin main --tags
```

注意：`git remote -v` 显示 origin 已配好，但本机 `git branch -a` 里没有 `remotes/origin/*`，
说明这个工作区从未 fetch/push 过——推送前请先 `git pull --rebase origin main` 确认没有分叉。

## 第 3 步：1024Store 条目更新

把 `1024store-entry.json` 的 0.1.6 版本记录合并进
[imsai-sh/awesome-deepseek-harness-plugins](https://github.com/imsai-sh/awesome-deepseek-harness-plugins)
（按其 registry 格式，开 PR）。条目要点与 0.1.5 相同：`id` = `Heeweelee/dsh-session-plugin`、
`url` = GitHub 仓库、`installMethods[0].revision` 更新到 `0.1.6`，才会进入商店**可安装**列表。

## 第 4 步：发布后验收

见 `RELEASE-NOTES-0.1.6.md` 的「发布后请按这 4 步验收」。核心是：空输入框按 `↑` 能回填、
`↓` 到底清空不留幽灵、中文输入法候选不被劫持。

## 遗留备忘

- [ ] npm publish 0.1.6（本机 401 → 换机）
- [ ] git push origin main + v0.1.6（本机从未推送过）
- [ ] 1024Store PR：把 `revision` 更新到 0.1.6
- [ ] 上一版遗留：0.1.5 已在 npm（registry `dist-tags.latest`），其 GitHub 标签与商店条目是否已同步需在那台机器确认
