# 发布到 npm + 上架 DSH 1024Store 的步骤

我在这里只能生成可发布物，**无法替你执行**下面三步——它们需要你本人的凭据：

- `npm publish` 需要你的 npm 账号登录权限；
- 创建 `Heeweelee/dsh-session-plugin` GitHub 仓库需要你的 GitHub 账号；
- 把条目提交进 1024Store（`awesome-deepseek-harness-plugins`）需要向该仓库开 PR。

下面按顺序做即可。

## 0. 关于包名大小写

你指定的 `@Heeweelee/dsh-session-plugin` 里 scope 带了大小写，但 **npm 包名强制小写**，
所以 `package.json` 和 1024Store 条目里的 npm 名已规范为 `@heeweelee/dsh-session-plugin`。
GitHub 仓库 `Heeweelee/dsh-session-plugin` 仍按你写的大小写保留（GitHub 不区分大小写）。

## 1. 核对并重新生成 Client bundle（重要）

`dist/client.js` 是手写的 `window.__ModuleLoader__.load({ id, factory })` 预打包文件。
生产发布前建议用 DSH 插件构建链重新生成，并确认 `id` 等于你的包名
`@heeweelee/dsh-session-plugin`（若 DSH 对 scoped 包使用其它 id 规则，以构建产出的 id 为准）。

## 2. 建仓库并推送

```bash
cd dsh-session-plugin
git init
git add -A
git commit -m "dsh-session-plugin 0.1.0: input history + right-click archive"
# 在 GitHub 上创建 Heeweelee/dsh-session-plugin 后：
git remote add origin https://github.com/Heeweelee/dsh-session-plugin.git
git push -u origin main
```

## 3. 发布到 npm

```bash
npm login
npm publish --access public
```

发布后确认可见：`npm view @heeweelee/dsh-session-plugin@0.1.0`。

## 4. 本地验证受管安装可用

```bash
dsh plugin add @heeweelee/dsh-session-plugin@0.1.0
# 重启 DSH，确认标题栏出现「↑ 历史」、右键会话出现「删除该会话」
```

商店受管安装器会复核：精确稳定版本、官方 tarball + SHA-512、`dsh.bundle.patch`
指向包内文件、无 install 生命周期脚本、`@deepseek-ai/dsh*` 依赖兼容 `0.1.0-rc.7`、
`engines.node` 接受 DSH 内置 Node，以及 npm `repository` 与目录条目一致。

## 5. 上架 DSH 1024Store

把 `1024store-entry.json` 的内容提交到
[imsai-sh/awesome-deepseek-harness-plugins](https://github.com/imsai-sh/awesome-deepseek-harness-plugins)
（按其仓库的 registry 格式合并该条目，开一个 PR）。条目要点：

- `id` = `Heeweelee/dsh-session-plugin`（owner/repo，用于 `repository_backlink` 校验）；
- `url` = `https://github.com/Heeweelee/dsh-session-plugin`；
- `installMethods[0]` = `{ kind: "npm", spec: "@heeweelee/dsh-session-plugin", verification: "verified", code: "repository_backlink", requiresBuildAllowance: false, revision: "0.1.0" }`。

只有目录给出「精确稳定版本 + repository_backlink + 规范仓库」时，该条目才会进入
商店的**可安装**列表；`pushedAt`/`added`/`stars` 等展示字段按 1024Store 实际格式补齐即可。