# dsh-session-plugin 0.1.9 发布说明

发布日期：2026-09-05　·　版本：0.1.9　·　上一版本：0.1.8

> 修幽灵行版本：0.1.8 删文件后工作区还留着一行，点进去才报“会话删除了”。0.1.9 让被删会话即时从工作区彻底消失。

## 变更一览

- Host：文件 `rm` 成功后（以及文件已不在 / header 已不可解析的 404 路径同样）依次执行 `workspaceRegistry.detachSession`（清各工作区 `sessionIds` 挂载）+ `workspaceRegistry.archiveSession`（官方隐藏 feed，客户端全局过滤）。均为 best-effort、永不把成功变 500；`archivedSessionIds` 会留一条不可见标记（无官方清理接口，无害）。
- Client：不再只 `rowEl.style.display='none'`（React 重渲染会复活）。成功后清自有 `/sessions` 回退缓存，调 `ctx.get('sessions').handleSessionRemoved(sid)` 即时移除 + `refresh()` 拉新基线；工作区 feed + 列表刷新双通道，草稿与滚动不受影响。
- `GET /sessions` 过滤已归档 id，标题回退不再匹配到已删除会话。

## 升级

```bash
dsh plugin add @heeweelee/dsh-session-plugin@0.1.9
```

重启生效。0.1.8 已删过但还留着幽灵行的会话：升级后随便点一次删除（会报 404“已不存在”）即会触发同样的 detach+archive 清理，行即消失；或重启后按标题确认行已不在。

## 验收（建议在测试会话上做）

1. 建可丢弃测试会话，发两条消息后切换到别的会话，右键测试会话 → 删除 → 二次确认 → 该行即时消失，toast「已彻底删除本地记录」。
2. 不重启、不刷新页面等 5 秒确认行不复活；点工作区其他会话正常打开，不报“会话删除了”。
3. 重启 DSH 后被删会话不回魂；磁盘上该会话目录已消失。
4. 右键正在使用的当前会话 → 删除 → 仍被拒「正在使用中，请先切换」。
5. 被删会话的 `↑` 历史不再出现其文本。

## 给审核者：0.1.8 → 0.1.9 包内差异

| 文件 | 变化 |
| --- | --- |
| `index.js` | 新增 `cleanupWorkspaceAfterDelete`（detach 全工作区 + archive，最佳努力）；`rm` 成功 / 文件已不在 / header 缺失三处均调用；`GET /sessions` 过滤 `archivedSessionIds` |
| `dist/client.js` | 成功态新增清 `sessionsCache` + `handleSessionRemoved` + `refresh()`，保留 DOM 隐藏作首层 |
| `package.json` | 0.1.8 → 0.1.9 |
| `README.md` / `CHANGELOG.md` | 幽灵行 bug 与双通道消失语义同步 |
