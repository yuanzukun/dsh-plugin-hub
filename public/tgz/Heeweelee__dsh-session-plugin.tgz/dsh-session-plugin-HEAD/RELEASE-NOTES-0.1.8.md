# dsh-session-plugin 0.1.8 发布说明

发布日期：2026-09-05　·　版本：0.1.8　·　上一版本：0.1.7

> ⚠️ **本版是破坏性语义变更**：右键「删除该会话」从 0.1.7 的归档隐藏改为**彻底删除本地会话记录，不可恢复**。请确认接受后再升级；删前请三思。

## 变更一览

- 新增 `POST /api/dsh-session-plugin/delete`（`{sessionId}` 真删除）；旧 `POST /archive` 保留为兼容别名，**行为同样改为真删除**（旧客户端调它也会删文件，特此声明）。
- 删除流程：白名单校验 → 拒绝 live（409）→ `sessionPersistence.list()` / `sessionQuery.listSessions()` 解析 header → `locate(header).path` → 严格校验 `session.jsonl[.zstd]` 形态 → `rm` 会话目录（含另一编码 sibling 兜底 + 空父目录修剪）→ 清理本插件该会话全部缓存。
- 客户端：文案归档→删除 + 确认态不可恢复警告；409/404/501 分开提示；成功清 `localStorage forgotten:<sid>`，派发 `deleted`（兼容保留 `archived`）事件；被删行即时隐藏，不 reload。
- 不删：附件、工作区注册、`archivedSessionIds` 旧标记（DSH 无官方清理接口）。

## 升级与回滚

```bash
dsh plugin add @heeweelee/dsh-session-plugin@0.1.8
```

重启生效。0.1.7 已归档（隐藏）的会话升级后仍只是隐藏，需再手动删除一次。回滚到 0.1.7 即回到归档语义：`dsh plugin add @heeweelee/dsh-session-plugin@0.1.7`。

## 验收（建议在测试会话上做）

1. 建一个可丢弃的测试会话，发两条消息后切换到别的会话，右键测试会话 → 删除 → 二次确认 → 该行消失，toast「已彻底删除本地记录」。
2. 右键正在使用的当前会话 → 删除 → 应被拒「正在使用中，请先切换」。
3. 被删会话的 `↑` 历史不再出现其文本（插件缓存已清）。
4. 磁盘上该会话目录（`session.jsonl[.zstd]`）已消失；DSH 重启后该会话不回魂。
5. 旧 `/archive` 路径（如有脚本在调）同样真删除——不要再把它当归档用。

## 给审核者：0.1.7 → 0.1.8 包内差异

| 文件 | 变化 |
| --- | --- |
| `index.js` | 新增 `deleteSessionLocally`（live 拒绝/header 解析/locate/形态校验/rm/清缓存）；`POST /delete` 主路由 + `/archive` 同行为别名；`409/404/501` 细分 |
| `dist/client.js` | `deleteApi` 主调；删除文案 + 警告行；409/404/501 分提示；成功清 localStorage + `deleted` 事件 |
| `package.json` | 0.1.7 → 0.1.8，描述 archive→permanently delete |
| `README.md` / `CHANGELOG.md` | 破坏性语义、恢复政策（不可恢复）、验收同步 |
