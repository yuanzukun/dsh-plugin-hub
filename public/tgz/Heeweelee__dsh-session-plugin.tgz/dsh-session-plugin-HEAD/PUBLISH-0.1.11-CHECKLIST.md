# 0.1.11 发布执行单（dsh 插件市场）

生成时间：2026-09-05 · 对象：`@heeweelee/dsh-session-plugin@0.1.11`

## 包状态（已在本机验证 ✅）

| 项目 | 结果 |
| --- | --- |
| tarball | `push-repo/heeweelee-dsh-session-plugin-0.1.11.tgz`（39,669 字节，2026-09-05 17:03 重打） |
| 内容 | 7 文件：`index.js` / `dist/client.js` / `cordis.patch.yml` / `README.md` / `CHANGELOG.md` / `LICENSE` / `package.json`，与工作区源码 `fc` 零差异 |
| 版本 | 包内 `0.1.11`；`index.js` 含 `agentBusyReason`，`dist/client.js` 含 `currentSidRef`+409 reason，`README` 安装命令已是 0.1.11 |
| 语法 | `node --check` 双文件通过 |
| 受管安装器前置 | 无 `scripts`、无运行期依赖、peerDeps 仅 3 个 `@deepseek-ai/*`、`dsh.bundle.patch` 指向包内文件、`engines.node` 匹配 DSH 内置 Node |
| SHA256 | `c62600d9bcf890f43bf8dba6a5caaccf1881f111cfd19027312ea0b24bf65665` |
| shasum | `54b5feac979b09be8cec3dd85f93af788a1d31c4` |
| integrity | `sha512-3XpJIv2qLDBfy[...]ZIqhwjrPfQ0wQ==`（完整值见 `npm pack` 输出） |
| 线上现状 | npm `versions = 0.1.0/0.1.5/0.1.6`，`latest = 0.1.6` → 本次发布会把 latest 推到 0.1.11（0.1.7~0.1.10 均未发布，为本地迭代） |

## 第 1 步 · npm 发布（⚠️ 需你的凭据，本机未登录）

本机 `~/.npmrc` 默认 registry 是 `npmmirror`，且无有效登录（`npm whoami` → ENEEDAUTH）。
换到有凭据的机器（或本机 `npm login` 后）执行——**必须显式指到 npmjs**：

```bash
cd push-repo
npm whoami --registry=https://registry.npmjs.org   # 非 401 再继续
npm publish heeweelee-dsh-session-plugin-0.1.11.tgz --access public \
  --registry=https://registry.npmjs.org
npm view @heeweelee/dsh-session-plugin versions --registry=https://registry.npmjs.org
# 应出现 0.1.11，且 dist-tags.latest = 0.1.11
```

## 第 2 步 · GitHub 推送（打 tag + 推 main）

`push-repo/` 是 git 工作区，当前有 6 个已修改未提交 + 5 个新增 RELEASE-NOTES。
按 0.1.6 的成功经验（快进、不改写历史）：

```bash
cd push-repo
git add -A
git commit -m "0.1.11: delete rule busy-only (idle current deletable, 409 reason)"
git tag v0.1.11
git pull --rebase origin main   # 确认无分叉（0.1.6 时本机从未 fetch 过，先 pull 再推）
git push origin main
git push origin v0.1.11
```

线上确认：`main/package.json` 应为 `version: 0.1.11`。

## 第 3 步 · 市场收录（两家，按现状二选一/都做）

### A. 1024Store（deepseek1024 / imsai-sh）

- 条目已在目录内（`Heeweelee/dsh-session-plugin`）；现行 schema **无 version 字段**，网站自动探测 npm latest。
- **npm 一发出去，安装命令自动指向 0.1.11，无需 PR。**（见 PUBLISH-0.1.6-HANDOFF.md 第 3 步结论）
- 若其 schema 恢复 `revision` 字段，再按 `1024store-entry.json` 开 PR 即可。

### B. dshmarket（awesome-dsh-plugin，设置 > 插件市场）

- 0.1.6 的 PR #4139（单文件 `data/plugins/Heeweelee__dsh-session-plugin.yml`）若已合并：**无需新 PR**，市场跟 npm latest 走。
- 若 #4139 仍未合并：保持原 PR（条目与版本无关），合并后自动指向 0.1.11。
- 草稿与 PR 正文模板：根目录 `dshmarket-entry.yml` / `dshmarket-pr-body.md`（内容仍有效，删除语义已覆盖 0.1.8+ 真删除）。

## 第 4 步 · 发布后验收（测试会话上做）

1. `dsh plugin add @heeweelee/dsh-session-plugin@0.1.11` + 重启，标题栏有 `↑ 历史`，右键有「删除该会话…」。
2. 空闲当前会话右键删除 → 成功、无需切换（0.1.10 会 409）；确认框有“当前会话”提醒。
3. 生成中 / 有后台任务的会话 → 409 精确提示（running/jobs）。
4. 被删行即时消失、不复活；重启不回魂；`↑` 历史无残留。
5. `npm view` 与市场安装命令均指向 0.1.11。

## 回滚

```bash
dsh plugin add @heeweelee/dsh-session-plugin@0.1.6
```

回滚即回到“挂载即拒 + 无幽灵行修复”的 0.1.6 语义，仅排障时短暂使用。
