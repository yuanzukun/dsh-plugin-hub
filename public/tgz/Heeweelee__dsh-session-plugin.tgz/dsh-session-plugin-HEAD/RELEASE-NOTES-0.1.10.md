# dsh-session-plugin 0.1.10 发布说明

发布日期：2026-09-05　·　版本：0.1.10　·　上一版本：0.1.9

> 缺陷修复版：无破坏性变更、无新交互，修掉审计出的 7 个 Host 缺陷并对齐文档。所有 0.1.9 用户建议升。

## 变更一览

- 缓存：v1 旧条目只在默认窗口下有效，调大 `historyLimit` 后自动重读补满；`lastForceAt` 节流表加 256 上限；崩溃残留 `*.tmp` 启动清理。
- 删除判定：agent/会话挂载判空同时接受 `null`/`undefined`（部分宿主返回 `null` 此前被误判 live）；`flush` 后复查一次 agent 挂载再 `rm`。
- 删除路径：父目录须与会话 id 同名、排除 home/配置根、产物与父目录均非 symlink；`registry.list()` 兼容同步/异步（异步注册表此前静默跳过全部 detach）。
- `disableDiskCache:true` 启动时删掉旧明文缓存。
- 文档：安装命令 0.1.10；修正“不再依赖 `archiveSession`”过时描述；CHANGELOG 链接修为完整 URL。

## 升级

```bash
dsh plugin add @heeweelee/dsh-session-plugin@0.1.10
```

重启生效。无数据迁移：旧磁盘缓存（v1/v2）可读，`historyLimit` 非默认时旧 v1 条目首次读取自动重建。

## 验收（建议在测试会话上做）

1. `historyLimit` 改大后重启，`↑` 历史能回填出超出旧窗口的老消息（证明旧截断缓存已失效重读）。
2. 建可丢弃测试会话，发两条消息后切换走，右键删除 → 该行即时消失，重启不回魂。
3. 右键当前正在使用的会话 → 仍被拒「正在使用中，请先切换」。
4. `dsh-session-plugin.json` 加 `"disableDiskCache": true` 重启后，旧 `dsh-session-plugin-history-cache.json` 已被删除且不再重建。
5. `~/.dsh` 下无 `dsh-session-plugin-history-cache.json.*.tmp` 残留。

## 给审核者：0.1.9 → 0.1.10 包内差异

| 文件 | 变化 |
| --- | --- |
| `index.js` | v1 缓存有效性、`!= null` live 判定、flush 后复查、路径收紧（目录名/home/symlink）、async `registry.list()`、`disableDiskCache` 清旧文件、tmp 清理、`noteForceAt` 上限 |
| `dist/client.js` | 未变 |
| `package.json` | 0.1.9 → 0.1.10 |
| `README.md` / `CHANGELOG.md` | 安装版本、兼容性修正、0.1.10 段、链接修复 |
| `RELEASE-NOTES-0.1.10.md` | 新增（本文件） |
