// @local/dsh-vcprag — client half
//
// 单个 bundle 文件。DSH 的 dsh.client 只认 platform / immediately / inject /
// external，bundle 入口固定是 package.json exports 的 "./client"；dsh.client.files
// 不是有效键，写在那里不会让额外脚本被加载。所以四个 Tab 必须全部内联在本文件里。
//
// 挂载点：settings.section（设置 → 插件 → 记忆召回）。
// 必须通过 ctx.slots.inject(...) 包 ctx.slots.register(...)，否则 DSH 根本不知道
// 有这么一个面板 —— 只 exports 组件是没用的。

window.__ModuleLoader__.load({
  id: '@local/dsh-vcprag',
  factory: (require) => {
    var module = { exports: {} }
    var exports = module.exports
    var React = require('react')
    var h = React.createElement

    var API = 'api/vcprag'
    /** 解析成绝对 URL：页面挂在子路径下时也不会打到错误的 origin 根。 */
    var endpoint = (suffix, params) => {
      var qs = ''
      if (params) {
        var parts = []
        for (var key in params) {
          var value = params[key]
          if (value === undefined || value === null || value === '') continue
          parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(value))
        }
        if (parts.length > 0) qs = '?' + parts.join('&')
      }
      return new URL(API + suffix + qs, document.baseURI).href
    }

    function get(suffix, params) {
      return fetch(endpoint(suffix, params))
        .then(function (r) { return r.json() })
        .catch(function (e) { return { ok: false, error: String(e && e.message ? e.message : e) } })
    }

    function post(suffix, body) {
      return fetch(endpoint(suffix), {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body || {}),
      })
        .then(function (r) { return r.json() })
        .catch(function (e) { return { ok: false, error: String(e && e.message ? e.message : e) } })
    }

    // 只使用宿主主题 token，不写字面色值，浅色/深色都跟着走。
    var TOKEN = {
      label: 'var(--dsw-alias-label-primary)',
      label2: 'var(--dsw-alias-label-secondary)',
      border: 'var(--dsw-alias-border-l1)',
      border2: 'var(--dsw-alias-border-l2)',
      surface: 'var(--dsw-alias-bg-layer-1)',
      surface2: 'var(--dsw-alias-bg-layer-2)',
      error: 'var(--dsw-alias-state-error-primary)',
      success: 'var(--dsw-alias-state-success-primary)',
      brand: 'var(--dsw-alias-brand-primary)',
      hover: 'var(--dsw-alias-interactive-bg-hover, rgba(127, 127, 127, 0.12))',
      mono: 'var(--dsw-alias-font-family-mono, ui-monospace, SFMono-Regular, Menlo, monospace)',
    }

    var TONE = {
      ok: { bg: 'rgba(46, 160, 67, 0.16)', fg: TOKEN.success },
      warn: { bg: 'rgba(210, 153, 34, 0.18)', fg: 'var(--dsw-alias-state-warning-primary, #d29922)' },
      err: { bg: 'rgba(248, 81, 73, 0.16)', fg: TOKEN.error },
      info: { bg: 'rgba(56, 139, 253, 0.16)', fg: TOKEN.brand },
      muted: { bg: 'var(--dsw-alias-bg-layer-2)', fg: TOKEN.label2 },
    }

    var S = {
      page: { padding: '18px 24px 40px', fontSize: 13, color: TOKEN.label, boxSizing: 'border-box', lineHeight: '20px' },
      tabs: { display: 'flex', gap: 2, borderBottom: '0.5px solid ' + TOKEN.border, marginBottom: 16 },
      tab: function (active) {
        return {
          font: 'inherit',
          fontSize: 13,
          padding: '8px 14px',
          cursor: 'pointer',
          background: 'transparent',
          border: 'none',
          borderBottom: active ? '2px solid ' + TOKEN.brand : '2px solid transparent',
          color: active ? TOKEN.label : TOKEN.label2,
          fontWeight: active ? 600 : 400,
        }
      },
      row: { display: 'flex', gap: 16, alignItems: 'flex-start' },
      col: { flex: 1, minWidth: 0 },
      card: {
        background: TOKEN.surface,
        border: '0.5px solid ' + TOKEN.border,
        borderRadius: 8,
        padding: 14,
        marginBottom: 12,
      },
      label: { display: 'block', fontSize: 12, color: TOKEN.label2, marginBottom: 4 },
      input: {
        width: '100%',
        boxSizing: 'border-box',
        padding: '6px 9px',
        background: TOKEN.surface2,
        color: TOKEN.label,
        border: '0.5px solid ' + TOKEN.border2,
        borderRadius: 6,
        fontSize: 13,
        fontFamily: 'inherit',
        lineHeight: '18px',
      },
      button: function (primary) {
        return {
          font: 'inherit',
          fontSize: 13,
          lineHeight: '18px',
          padding: '6px 13px',
          cursor: 'pointer',
          borderRadius: 8,
          background: primary ? TOKEN.brand : 'transparent',
          color: primary ? TOKEN.label : TOKEN.label2,
          border: primary ? 'none' : '0.5px solid ' + TOKEN.border2,
        }
      },
      badge: function (tone) {
        var t = TONE[tone] || TONE.muted
        return {
          display: 'inline-block',
          padding: '1px 7px',
          borderRadius: 4,
          fontSize: 11,
          lineHeight: '16px',
          background: t.bg,
          color: t.fg,
          marginRight: 6,
          marginBottom: 3,
        }
      },
      mono: { fontFamily: TOKEN.mono, fontSize: 12, lineHeight: '18px', color: TOKEN.label2 },
      listItem: function (active) {
        return {
          padding: '7px 10px',
          cursor: 'pointer',
          borderRadius: 6,
          background: active ? TOKEN.surface2 : 'transparent',
          color: TOKEN.label,
          marginBottom: 2,
        }
      },
      pre: { whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontFamily: TOKEN.mono, fontSize: 12, lineHeight: '18px', margin: 0 },
      hint: { fontSize: 11, color: TOKEN.label2, marginTop: 4, lineHeight: '17px' },
      // 行内代码：块标记这类东西要跟正文区分开，否则读者分不清哪段是要照抄的
      code: {
        fontFamily: TOKEN.mono,
        fontSize: 11,
        padding: '1px 4px',
        borderRadius: 3,
        background: TOKEN.surface2,
        color: TOKEN.label,
      },
      divider: { height: 1, background: TOKEN.border, margin: '12px 0' },
    }

    /** 通用确认弹窗（覆盖层）。 */
    function ConfirmDialog(props) {
      var overlay = {
        position: 'fixed',
        inset: 0,
        background: 'rgba(0,0,0,0.55)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999,
      }
      var box = {
        width: 560,
        maxWidth: '90vw',
        background: TOKEN.surface,
        border: '0.5px solid ' + TOKEN.error,
        borderRadius: 10,
        padding: 20,
        boxShadow: '0 8px 32px rgba(0,0,0,0.45)',
        color: TOKEN.label,
      }
      return h('div', { style: overlay },
        h('div', { style: box },
          h('div', { style: { fontSize: 15, fontWeight: 700, marginBottom: 12, color: TOKEN.error } },
            props.title),
          h('div', { style: { fontSize: 13, lineHeight: '21px', marginBottom: 12, whiteSpace: 'pre-wrap' } },
            props.message),
          props.consequences && props.consequences.length > 0
            ? h('div', {
              style: {
                background: TOKEN.surface2,
                borderRadius: 6,
                padding: 10,
                marginBottom: 14,
                fontSize: 12,
                lineHeight: '21px',
                fontFamily: TOKEN.mono,
                color: TOKEN.label2,
              },
            }, props.consequences.map(function (line, i) {
              return h('div', { key: i }, '· ' + line)
            }))
            : null,
          h('div', { style: { display: 'flex', gap: 8, justifyContent: 'flex-end' } },
            (props.actions || []).map(function (action) {
              return h('button', {
                key: action.id,
                style: S.button(action.primary === true),
                onClick: function () { props.onChoose(action.id) },
              }, action.label)
            }))
        ))
    }

    // ================= Tab 4：设置 =================

    function SettingsTab() {
      var st = React.useState({
        data: null,
        draft: null,
        msg: null,
        testResult: null,
        models: null,
        dialog: null,
        runtimeDraft: null,
        aliasText: '',
        folders: null,
        template: null,
        templateText: '',
        // 语义写自检：贴进来的正文 + 解析结果
        previewText: '',
        preview: null,
        // 当前分区（设置页左导航）+ 是否有未保存改动（底部 savebar 用）
        sectionId: 'embed',
        dirty: false,
      })
      var s = st[0]
      var set = st[1]

      function merge(patch) {
        set(function (prev) { return Object.assign({}, prev, patch) })
      }

      function setTemplateState(patch) {
        set(function (prev) {
          return Object.assign({}, prev, {
            template: Object.assign({}, prev.template, patch),
            templateText: patch.template !== undefined ? patch.template : prev.templateText,
          })
        })
      }

      function setPreviewState(patch) {
        set(function (prev) { return Object.assign({}, prev, patch) })
      }

      /**
       * 自检：把一段正文发给后端，只看解析结果、不落盘。
       *
       * 语义写入的失败几乎都出在格式细节（漏空行、target 太短），
       * 而这类问题在运行日志里只表现为「没写进去」—— 有这个框，
       * 用户不用翻日志就能看到系统到底把它读成了什么。
       */
      function runPreview(text) {
        var body = (text === undefined ? s.previewText : text) || ''
        if (body.trim() === '') {
          merge({ preview: { found: 0, rows: [], hint: '请先粘贴一段带块的正文。' } })
          return
        }
        // 用 POST：一整篇日记塞进 query string 会被长度限制截断，
        // 而截断后的正文里往往还剩块起始标记、却没了结束标记 ——
        // 解析结果变成 0 个块，看起来像功能坏了。
        post('/diary/semantic/preview', { text: body }).then(function (r) {
          if (r.ok) merge({ preview: r })
          else merge({ preview: { found: 0, rows: [], hint: r.error || '解析失败' } })
        })
      }

      function load() {
        get('/settings').then(function (r) {
          if (r.ok) merge({ data: r, draft: JSON.parse(JSON.stringify(r.config)) })
        })
        get('/runtime').then(function (r) {
          if (r.ok) merge({ runtimeDraft: JSON.parse(JSON.stringify(r.memories)) })
        })
        get('/aliases').then(function (r) {
          if (r.ok) merge({ aliasText: JSON.stringify(r.aliases, null, 2) })
        })
        get('/diary/folders').then(function (r) {
          if (r.ok) merge({ folders: r })
        })
        loadTemplate()
      }

      React.useEffect(function () { load() }, [])

      /**
       * 注入位置选择器。
       *
       * 两个选项对应两种物理位置，差异是「上游清空 system prompt 时谁存活」：
       *   section/context → 进 system，缓存最优，但 system 被清空就全丢
       *   message         → 进对话历史，survive 上游清空，但历史里删不掉
       *
       * 所以文案必须把这个取舍讲清楚，否则用户不知道什么时候该切。
       *
       * opts.maxMessages 有值时（= message 模式的条数上限）：
       * 选中「对话消息」后展开一个数字输入框。只在 message 模式显示，
       * 因为 prompt 模式不落库、没有上限这回事。
       */
      function injectModePicker(opts) {
        var value = opts.value === 'message' ? 'message' : (opts.defaultMode || 'prompt')
        // 统一归一化：两条通道都叫「系统提示词 / 对话消息」两种位置，
        // 但值不同 —— runtime 的 system 位置是 'section'，inject 的是 'context'。
        // 默认值各自不同（runtime=section、inject=message），由调用方的 systemValue 决定。
        var isMessage = opts.value === 'message'
        var hasCap = opts.maxMessages !== undefined && opts.maxMessages !== null
        return h('div', { style: { marginBottom: 10 } },
          h('label', { style: S.label }, opts.label),
          h('div', { style: { display: 'flex', gap: 8, marginBottom: 6 } },
            h('button', {
              style: S.button(!isMessage),
              onClick: function () { if (isMessage) opts.onChange(opts.systemValue || 'section') },
            }, '系统提示词'),
            h('button', {
              style: S.button(isMessage),
              onClick: function () { if (!isMessage) opts.onChange('message') },
            }, '对话消息')),

          (isMessage && hasCap)
            ? h('div', { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 } },
              h('label', { style: Object.assign({}, S.label, { marginBottom: 0, flexShrink: 0 }) },
                '最多保留几条'),
              h('input', {
                style: Object.assign({}, S.input, { width: 90 }),
                type: 'number',
                min: 0,
                max: 200,
                // 标明这个框属于哪条通道，便于自检脚本定位（不参与渲染）
                'data-cap': opts.capKey || '',
                value: String(opts.maxMessages),
                onChange: function (e) {
                  var raw = e.target.value
                  // 空输入不立刻写 0，否则用户删光重打的过程中会被当成「不限制」
                  if (raw === '') return
                  var n = Math.round(Number(raw))
                  if (!Number.isFinite(n)) return
                  opts.onMaxMessages(Math.max(0, Math.min(200, n)))
                },
              }),
              h('span', { style: Object.assign({}, S.hint, { marginBottom: 0 }) },
                String(opts.maxMessages) === '0' ? '0 = 不限制' : '条'))
            : null,

          h('div', { style: S.hint },
            opts.help,
            (isMessage && hasCap)
              ? ' 上限只在「有新内容想进但进不去」时才有意义：到顶后旧消息删不掉，'
                + '调高上限（或填 0 不限）就能继续追加。'
              : ''))
      }

      /**
       * 分词器状态文案。
       *
       * 三态必须同时暴露，缺一个就会让人误判：
       *   configured（下拉框里选的） / active（实际能用的） / indexed（索引建的时候用的）
       *
       * 典型坑：选 auto 但机器上没装 jieba → active 是 gram 而界面毫无提示，
       * 用户会以为是 jieba 效果不好。反过来，装了之后 indexed 还是 gram，
       * 不重建索引的话查询词表与索引词表对不上，BM25 静默全 0 分。
       */
      function activeTokenizerText(s) {
        // 状态挂在 /settings 响应上（s.data.tokenizer），不在 draft 里 ——
        // draft 只有用户「想选什么」，active/indexed 是服务端事实。
        var t = s.data && s.data.tokenizer
        if (!t) return '分词器状态未知'
        var lines = []
        var configLabel = t.configured === 'gram' ? 'gram（强制）' : (t.configured === 'jieba' ? 'jieba（强制）' : 'auto')
        lines.push('已选：' + configLabel + ' · 实际生效：' + (t.active || '?'))
        if (t.configured !== 'gram' && t.active === 'gram') {
          lines.push('⚠ jieba 未装上，已自动降级为 1-gram + 2-gram'
            + (t.loadError ? '（' + String(t.loadError).slice(0, 80) + '）' : ''))
        }
        if (t.indexed && t.active && t.indexed !== t.active) {
          lines.push('⚠ 索引是用 ' + t.indexed + ' 建的，与当前 ' + t.active + ' 不一致 —— 请重建索引，否则词表对不上、BM25 会全 0 分。')
        }
        return lines.join(' ')
      }

      /** 改 draft 的某个路径。 */
      function patch(path, value) {
        var next = JSON.parse(JSON.stringify(s.draft))
        var parts = path.split('.')
        var target = next
        for (var i = 0; i < parts.length - 1; i += 1) {
          // 中间段可能不存在：老版本配置文件里没有 judge 段，
          // 此时 target['judge'] 是 undefined，下一行赋值就会 TypeError
          // 把整个设置页炸掉。这里按需补出来。
          if (target[parts[i]] === null || typeof target[parts[i]] !== 'object') {
            target[parts[i]] = {}
          }
          target = target[parts[i]]
        }
        target[parts[parts.length - 1]] = value
        // 任何一次字段改动都置脏。savebar 靠它决定说「无未保存改动」
        // 还是「有未保存的改动」—— 这比让用户自己记要可靠。
        merge({ draft: next, dirty: true })
      }

      function save(force) {
        merge({ msg: '保存中…' })
        post('/settings/save', { config: s.draft, force: force === true }).then(function (r) {
          if (r.requiresConfirm) {
            // 维度保护：弹窗让用户选
            merge({
              msg: null,
              dialog: {
                title: r.title || '配置变更将导致索引失效',
                message: r.message,
                consequences: r.consequences,
                actions: r.actions,
              },
            })
            return
          }
          if (r.ok) {
            merge({
              msg: '已保存' + (r.warning ? '（' + r.warning + '）' : ''),
              data: Object.assign({}, s.data, { config: r.config }),
              // 保存成功 = 磁盘与草稿一致，脏标记清掉。
              dirty: false,
            })
            setTimeout(function () { merge({ msg: null }) }, 5000)
          } else {
            merge({ msg: '保存失败：' + (r.error || '未知') })
          }
        })
      }

      function onDialogChoose(id) {
        merge({ dialog: null })
        if (id === 'cancel') return
        if (id === 'rebuild') {
          post('/settings/save', { config: s.draft, force: true }).then(function (r) {
            if (!r.ok) {
              merge({ msg: '保存失败：' + (r.error || '未知') })
              return
            }
            merge({ msg: '配置已保存，开始重建索引…' })
            post('/index/rebuild', { force: true }).then(function (rb) {
              if (rb.ok) merge({ msg: '重建已启动，切到「索引」Tab 看进度' })
              else merge({ msg: '重建启动失败：' + (rb.error || '未知') })
            })
          })
          return
        }
        if (id === 'save') save(true)
      }

      function testConnection() {
        merge({ testResult: { pending: true } })
        post('/settings/test', { embedding: s.draft.embedding }).then(function (r) {
          merge({ testResult: r })
        })
      }

      function fetchModels() {
        merge({ models: { pending: true } })
        get('/models', { baseUrl: s.draft.embedding.baseUrl }).then(function (r) {
          merge({ models: r })
        })
      }

      function saveRuntime() {
        post('/runtime/save', { memories: s.runtimeDraft }).then(function (r) {
          if (r.ok) {
            merge({ msg: r.warning || '已保存' })
            setTimeout(function () { merge({ msg: null }) }, 6000)
          } else {
            merge({ msg: '保存失败：' + (r.error || '未知') })
          }
        })
      }

      function saveAliases() {
        var parsed
        try {
          parsed = JSON.parse(s.aliasText)
        } catch (e) {
          merge({ msg: '别名表不是合法 JSON：' + e.message })
          return
        }
        post('/aliases/save', { aliases: parsed }).then(function (r) {
          merge({ msg: r.ok ? '别名表已保存（' + r.count + ' 组）' : ('保存失败：' + r.error) })
          setTimeout(function () { merge({ msg: null }) }, 4000)
        })
      }

      // ---- 日记模板 ----
      function loadTemplate() {
        get('/diary/template').then(function (r) {
          if (r.ok) merge({ template: r, templateText: r.template })
        })
      }

      function saveTemplate(text, enabled) {
        merge({ msg: '保存模板中…' })
        post('/diary/template/save', {
          template: text === undefined ? s.templateText : text,
          enabled: enabled,
        }).then(function (r) {
          if (r.ok) {
            merge({ msg: r.warning || '日记模板已保存' })
            loadTemplate()
            setTimeout(function () { merge({ msg: null }) }, 8000)
          } else {
            merge({ msg: '模板保存失败：' + (r.error || '未知') })
          }
        })
      }

      if (s.data === null) return h('div', { style: S.hint }, '加载中…')

      var d = s.draft
      // 裁判配置的兜底：老版本的 config 里没有 judge 段，直接读 d.judge.enabled
      // 会 TypeError 把整个设置页炸掉。这里给一份与 lib/config.js DEFAULTS.judge
      // 对齐的默认值 —— 两处必须一起改，否则面板显示的和实际生效的会不一致。
      var jd = Object.assign({
        enabled: false,
        threshold: 0.7,
        maxCandidates: 12,
        concurrency: 8,
        timeoutMs: 4000,
        candidateChars: 400,
        queryChars: 400,
      }, d.judge || {})
      var manifest = s.data.manifestEmbedding

      // ---- A. Embedding 渠道 ----
      var channelCard = h('div', { style: S.card },
        h('div', { style: { fontWeight: 600, marginBottom: 10 } }, 'A. Embedding 渠道'),
        h('div', null,
          h('div', { style: { marginBottom: 8 } },
            h('span', { style: S.badge(d.embedding.enabled ? 'ok' : 'muted') },
              d.embedding.enabled ? '已启用' : '已关闭'),
            manifest
              ? h('span', { style: S.badge('info') },
                '索引记录：' + manifest.dimensions + ' 维 / ' + manifest.model)
              : h('span', { style: S.badge('warn') }, '尚无索引'),
            s.data.keyPresent
              ? h('span', { style: S.badge('ok') }, '密钥已配置')
              : h('span', { style: S.badge('err') }, '密钥缺失')),

          h('label', { style: S.label }, 'Base URL（必须含 /v1，否则会打到网关首页返回 HTML）'),
          h('input', {
            style: Object.assign({}, S.input, { marginBottom: 8 }),
            value: d.embedding.baseUrl,
            onChange: function (e) { patch('embedding.baseUrl', e.target.value) },
          }),

          h('label', { style: S.label }, 'API Key（留空则用环境变量 VCPRAG_EMBEDDING_KEY）'),
          h('input', {
            style: Object.assign({}, S.input, { marginBottom: 8 }),
            type: 'password',
            placeholder: s.data.keyPresent ? '••••••••（已配置，留空不修改）' : '未配置',
            value: d.embedding.apiKey && d.embedding.apiKey.indexOf('•') === -1 ? d.embedding.apiKey : '',
            onChange: function (e) { patch('embedding.apiKey', e.target.value) },
          }),

          h('div', { style: { display: 'flex', gap: 8 } },
            h('div', { style: { flex: 2 } },
              h('label', { style: S.label }, '模型'),
              h('input', {
                style: Object.assign({}, S.input, { marginBottom: 8 }),
                value: d.embedding.model,
                onChange: function (e) { patch('embedding.model', e.target.value) },
              })),
            h('div', { style: { flex: 1 } },
              h('label', { style: S.label }, '维度'),
              h('input', {
                style: Object.assign({}, S.input, { marginBottom: 8 }),
                type: 'number',
                value: d.embedding.dimensions,
                onChange: function (e) { patch('embedding.dimensions', Number(e.target.value)) },
              }))),

          h('div', { style: { display: 'flex', gap: 8 } },
            h('div', { style: { flex: 1 } },
              h('label', { style: S.label }, '批量大小（实测上限 16，超过会 ECONNRESET）'),
              h('input', {
                style: Object.assign({}, S.input, { marginBottom: 8 }),
                type: 'number',
                min: 1,
                max: 16,
                value: d.embedding.batchSize,
                onChange: function (e) { patch('embedding.batchSize', Number(e.target.value)) },
              })),
            h('div', { style: { flex: 1 } },
              h('label', { style: S.label }, '并发（网关限流 100 请求/分钟）'),
              h('input', {
                style: Object.assign({}, S.input, { marginBottom: 8 }),
                type: 'number',
                min: 1,
                max: 8,
                value: d.embedding.concurrency,
                onChange: function (e) { patch('embedding.concurrency', Number(e.target.value)) },
              })),
            h('div', { style: { flex: 1 } },
              h('label', { style: S.label }, '请求间隔 ms'),
              h('input', {
                style: Object.assign({}, S.input, { marginBottom: 8 }),
                type: 'number',
                value: d.embedding.minIntervalMs,
                onChange: function (e) { patch('embedding.minIntervalMs', Number(e.target.value)) },
              }))),

          h('div', { style: { display: 'flex', gap: 8, alignItems: 'center' } },
            h('button', { style: S.button(false), onClick: testConnection }, '测试连接'),
            h('button', { style: S.button(false), onClick: fetchModels }, '拉取模型列表'),
            s.testResult && s.testResult.pending
              ? h('span', { style: S.hint }, '测试中…')
              : null,
            s.testResult && !s.testResult.pending
              ? h('span', {
                style: { fontSize: 12, color: s.testResult.ok && s.testResult.match ? TOKEN.success : TOKEN.error },
              },
                s.testResult.ok
                  ? (s.testResult.match
                    ? '✓ 连接正常 · ' + s.testResult.dimensions + ' 维 · ' + s.testResult.elapsedMs + 'ms'
                    : '⚠ 维度不符：配置 ' + s.testResult.expected + '，实际返回 ' + s.testResult.dimensions)
                  : '✗ ' + (s.testResult.error || '失败'))
              : null),

          s.models
            ? h('div', { style: Object.assign({}, S.hint, { marginTop: 8 }) },
              s.models.pending
                ? '拉取中…'
                : s.models.ok
                  ? '共 ' + s.models.total + ' 个模型，其中 embedding 类 ' + s.models.embeddings.length + ' 个：'
                    + (s.models.embeddings.length ? s.models.embeddings.join(' · ') : '（无）')
                  : '拉取失败：' + (s.models.error || '未知'))
            : null)
      )

      // ---- B. 召回参数 ----
      var recallCard = h('div', { style: S.card },
        h('div', { style: { fontWeight: 600, marginBottom: 10 } }, 'B. 召回参数'),
        h('div', { style: { display: 'flex', gap: 8, flexWrap: 'wrap' } },
          [['kBase', '基础 K'], ['kMin', '最小 K'], ['kMax', '最大 K']].map(function (pair) {
            return h('div', { key: pair[0], style: { width: 110 } },
              h('label', { style: S.label }, pair[1]),
              h('input', {
                style: Object.assign({}, S.input, { marginBottom: 8 }),
                type: 'number',
                value: d.recall[pair[0]],
                onChange: function (e) { patch('recall.' + pair[0], Number(e.target.value)) },
              }))
          }),
          [['lexicalLimit', '词法候选'], ['semanticLimit', '向量候选'], ['maxChars', '注入上限字数']].map(function (pair) {
            return h('div', { key: pair[0], style: { width: 130 } },
              h('label', { style: S.label }, pair[1]),
              h('input', {
                style: Object.assign({}, S.input, { marginBottom: 8 }),
                type: 'number',
                value: d.recall[pair[0]],
                onChange: function (e) { patch('recall.' + pair[0], Number(e.target.value)) },
              }))
          })),
        // ---- 分词器 ----
        // 这一项决定整张词表，改了必须重建索引才生效。所以除了 select，
        // 还要把「当前实际生效的引擎」摊开显示 —— 用户选了 auto，
        // 但机器上可能根本没装 jieba，光看 select 是发现不了的。
        h('div', { style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 4, alignItems: 'flex-end' } },
          h('div', { style: { width: 190 } },
            h('label', { style: S.label }, '分词器（改后需重建索引）'),
            h('select', {
              style: Object.assign({}, S.input, { marginBottom: 8 }),
              value: d.recall.tokenizer || 'auto',
              onChange: function (e) { patch('recall.tokenizer', e.target.value) },
            },
              h('option', { value: 'auto' }, 'auto（有 jieba 就用）'),
              h('option', { value: 'jieba' }, 'jieba（真词典分词）'),
              h('option', { value: 'gram' }, 'gram（1-gram，零依赖）'))),
          h('div', { style: Object.assign({}, S.hint, { flex: 1, marginBottom: 10 }) },
            activeTokenizerText(s))),

        // ---- 相关性闸门 ----
        // 不加这两个开关，无论查询多无关都会硬返回 k 条「最不无关」的结果，
        // 日志显示注入成功、内容是噪声。实测见 lib/config.js 的 minSemantic。
        h('div', { style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 4, alignItems: 'flex-end' } },
          h('div', { style: { width: 150 } },
            h('label', { style: S.label }, '相关性闸门（余弦下限）'),
            h('input', {
              style: Object.assign({}, S.input, { marginBottom: 8 }),
              type: 'number',
              step: 0.05,
              min: 0,
              max: 0.99,
              value: d.recall.minSemantic,
              onChange: function (e) { patch('recall.minSemantic', Number(e.target.value)) },
            })),
          h('div', { style: { width: 190 } },
            h('label', { style: S.label }, '必须被语义通道命中'),
            h('label', { style: Object.assign({}, S.label, { display: 'flex', alignItems: 'center', gap: 6, marginBottom: 12 }) },
              h('input', {
                type: 'checkbox',
                checked: d.recall.requireSemantic !== false,
                onChange: function (e) { patch('recall.requireSemantic', e.target.checked) },
              }),
              '开（推荐）')),
          h('div', { style: Object.assign({}, S.hint, { flex: 1, marginBottom: 10 }) },
            '低于下限的候选直接丢弃；全被丢光就不注入。填 0 关闭闸门。只在语义通道可用时生效。')),

        // ---- 相关性裁判（可选，默认关闭）----
        // 实词判据问的是「query 里有没有罕见词」，裁判问的是「这条日记跟
        // query 讲的是不是同一件事」。实测「条目级去重」被 jieba 切成
        // 条目/级/重 之后，主题词消失、只剩通用词过闸门 —— 判据问错了问题。
        //
        // 这里只暴露数值项。**密钥不在这里**：配置文件会被 UI 读出来回显到
        // 浏览器，把 key 塞进面板等于把它摊在明面上。key 只走环境变量。
        h('div', {
          style: {
            marginTop: 14,
            paddingTop: 12,
            borderTop: '1px solid ' + (TOKEN.border || '#e5e7eb'),
          },
        },
          h('div', { style: { fontWeight: 600, marginBottom: 8 } }, '相关性裁判（可选）'),
          h('div', { style: Object.assign({}, S.hint, { marginBottom: 10 }) },
            '用一个判断模型直接判「这条记忆与当前查询是不是同一个主题」，',
            '绕开分词（「去重」被切成「去/重」也不影响）。',
            '代价是每次召回多一笔外部请求（实测 12 条约 1.2~2.0 秒）。'),
          h('div', { style: { display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' } },
            h('div', { style: { width: 140 } },
              h('label', { style: S.label }, '启用裁判'),
              h('label', { style: Object.assign({}, S.label, { display: 'flex', alignItems: 'center', gap: 6, marginBottom: 12 }) },
                h('input', {
                  type: 'checkbox',
                  checked: jd.enabled === true,
                  onChange: function (e) { patch('judge.enabled', e.target.checked) },
                }),
                jd.enabled === true ? '开' : '关（默认）')),
            h('div', { style: { width: 130 } },
              h('label', { style: S.label }, '剔除阈值（0~1）'),
              h('input', {
                style: Object.assign({}, S.input, { marginBottom: 8 }),
                type: 'number',
                step: 0.05,
                min: 0,
                max: 1,
                value: jd.threshold,
                onChange: function (e) { patch('judge.threshold', Number(e.target.value)) },
              })),
            h('div', { style: { width: 110 } },
              h('label', { style: S.label }, '最多判几条'),
              h('input', {
                style: Object.assign({}, S.input, { marginBottom: 8 }),
                type: 'number',
                min: 1,
                max: 50,
                value: jd.maxCandidates,
                onChange: function (e) { patch('judge.maxCandidates', Number(e.target.value)) },
              })),
            h('div', { style: { width: 100 } },
              h('label', { style: S.label }, '并发数'),
              h('input', {
                style: Object.assign({}, S.input, { marginBottom: 8 }),
                type: 'number',
                min: 1,
                max: 16,
                value: jd.concurrency,
                onChange: function (e) { patch('judge.concurrency', Number(e.target.value)) },
              })),
            h('div', { style: { width: 120 } },
              h('label', { style: S.label }, '超时（毫秒）'),
              h('input', {
                style: Object.assign({}, S.input, { marginBottom: 8 }),
                type: 'number',
                min: 200,
                max: 60000,
                value: jd.timeoutMs,
                onChange: function (e) { patch('judge.timeoutMs', Number(e.target.value)) },
              }))),

          // ---- 连接信息：端点 / 模型 / 代理 / 密钥 ----
          // 这四项以前只认环境变量，改一次要重启宿主进程。现在面板可改。
          // 留空 = 回落到环境变量或内置默认，两种用法可以共存。
          h('div', { style: { marginTop: 10 } },
            h('label', { style: S.label }, '端点 URL（留空用官方端点）'),
            h('input', {
              style: Object.assign({}, S.input, { marginBottom: 8 }),
              placeholder: 'https://api.typesafe.ai/v1/systemone',
              value: jd.baseUrl || '',
              onChange: function (e) { patch('judge.baseUrl', e.target.value) },
            }),

            h('div', { style: { display: 'flex', gap: 8, flexWrap: 'wrap' } },
              h('div', { style: { flex: 1, minWidth: 180 } },
                h('label', { style: S.label }, '模型名（留空用 jev-latest）'),
                h('input', {
                  style: Object.assign({}, S.input, { marginBottom: 8 }),
                  placeholder: 'jev-latest',
                  value: jd.model || '',
                  onChange: function (e) { patch('judge.model', e.target.value) },
                })),
              h('div', { style: { flex: 1, minWidth: 180 } },
                h('label', { style: S.label }, '代理地址（451 地区必填）'),
                h('input', {
                  style: Object.assign({}, S.input, { marginBottom: 8 }),
                  placeholder: 'http://127.0.0.1:7897',
                  value: jd.proxyUrl || '',
                  onChange: function (e) { patch('judge.proxyUrl', e.target.value) },
                }))),

            h('label', { style: S.label }, 'API Key（留空则用 VCPRAG_JUDGE_KEY）'),
            // 掩码回显：后端把已配置的 key 回成八个圆点，保存时含圆点的值
            // 一律视为「没改动」—— 与上面 embedding.apiKey 同一套机制。
            h('input', {
              style: Object.assign({}, S.input, { marginBottom: 8 }),
              type: 'password',
              placeholder: jd.apiKey && jd.apiKey.indexOf('•') !== -1
                ? '••••••••（已配置，留空不修改）'
                : '未配置',
              value: jd.apiKey && jd.apiKey.indexOf('•') === -1 ? jd.apiKey : '',
              onChange: function (e) { patch('judge.apiKey', e.target.value) },
            })),
          h('div', { style: Object.assign({}, S.hint, { marginTop: 6 }) },
            // 阈值是实测值，直接把依据写出来，否则用户只会看到一个大而空的 0.7
            '阈值默认 0.7 是实测值：5 个查询 × 8 篇真实日记，「相关」最低 0.94、',
            '「全无关」最高 0.12；取中点 0.53 会让一条 0.61 的噪声漏进来。',
            '换语料请重新校准。'),
          h('div', { style: Object.assign({}, S.hint, { marginTop: 4 }) },
            '密钥只走环境变量 ',
            h('code', { style: { fontFamily: 'monospace' } }, 'VCPRAG_JUDGE_KEY'),
            '（可选 ',
            h('code', { style: { fontFamily: 'monospace' } }, 'VCPRAG_JUDGE_URL'),
            ' / ',
            h('code', { style: { fontFamily: 'monospace' } }, 'VCPRAG_JUDGE_MODEL'),
            '）。开了开关但没设 key 会在日志里告警并按关闭处理。'),
          h('div', { style: Object.assign({}, S.hint, { marginTop: 4 }) },
            '官方端点对部分地区返回 451（Typesafe is not available in your region）。',
            '两种绕法：① 填上面的「代理地址」（如 http://127.0.0.1:7897）走 CONNECT 隧道；',
            '② 把「端点 URL」换成自建的反向代理（插件自带一个 Cloudflare Worker，',
            '见 worker/jev-proxy/README.md），那样代理地址留空即可。',
            '两者都没配时直连会静默失败 —— 开关是开的、日志也不报错，只是裁判不生效。'),
          h('div', { style: Object.assign({}, S.hint, { marginTop: 4 }) },
            '四项连接信息留空则回落到环境变量：',
            h('code', { style: { fontFamily: 'monospace' } }, 'VCPRAG_JUDGE_KEY'),
            ' / ',
            h('code', { style: { fontFamily: 'monospace' } }, 'VCPRAG_JUDGE_URL'),
            ' / ',
            h('code', { style: { fontFamily: 'monospace' } }, 'VCPRAG_JUDGE_MODEL'),
            ' / ',
            h('code', { style: { fontFamily: 'monospace' } }, 'VCPRAG_JUDGE_PROXY'),
            '。环境变量优先级更高，便于临时换 key 而不动配置文件。'),
          jd.enabled === true
            ? h('div', { style: Object.assign({}, S.hint, { marginTop: 4, color: TOKEN.warn || '#b45309' }) },
              '提示：面板和环境变量都没给 API Key 时，这一项不会生效（日志会告警）。改完点「保存」即可，无需重启。')
            : null),

        h('div', { style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 14 } },
          h('div', { style: { width: 130 } },
            h('label', { style: S.label }, '时间衰减半衰期（天）'),
            h('input', {
              style: S.input,
              type: 'number',
              value: d.timeDecay.halfLifeDays,
              onChange: function (e) { patch('timeDecay.halfLifeDays', Number(e.target.value)) },
            })),
          h('div', { style: { width: 130 } },
            h('label', { style: S.label }, '衰减下限（0~1）'),
            h('input', {
              style: S.input,
              type: 'number',
              step: 0.05,
              value: d.timeDecay.floor,
              onChange: function (e) { patch('timeDecay.floor', Number(e.target.value)) },
            })),
          h('div', { style: { width: 150 } },
            h('label', { style: S.label }, '分块大小'),
            h('input', {
              style: S.input,
              type: 'number',
              value: d.chunkSize,
              onChange: function (e) { patch('chunkSize', Number(e.target.value)) },
            })),
          h('div', { style: { width: 150 } },
            h('label', { style: S.label }, '分块重叠'),
            h('input', {
              style: S.input,
              type: 'number',
              value: d.chunkOverlap,
              onChange: function (e) { patch('chunkOverlap', Number(e.target.value)) },
            }))),
        h('div', { style: S.hint },
          '改动分块参数会导致现有 chunk 与新切分不一致，建议重建索引。')
      )

      // ---- C. 冻结行为 ----
      var freezeCard = h('div', { style: S.card },
        h('div', { style: { fontWeight: 600, marginBottom: 10 } }, 'C. 冻结行为'),
        h('label', { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 } },
          h('input', {
            type: 'checkbox',
            checked: d.freeze.onUserMessage,
            onChange: function (e) { patch('freeze.onUserMessage', e.target.checked) },
          }),
          h('span', null, '用户发新消息时重新召回')),
        h('label', { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 } },
          h('input', {
            type: 'checkbox',
            checked: d.freeze.onTodoCheck,
            onChange: function (e) { patch('freeze.onTodoCheck', e.target.checked) },
          }),
          h('span', null, 'todo 出现新勾选时重新召回（阶段推进）')),
        h('div', { style: S.hint },
          '其余轮次（模型连续干活、普通工具调用）召回内容保持不变 → 前缀缓存全程命中。'
          + '关掉这两项等于回到「每轮都追加」，命中率会掉。')
      )

      // ---- D. runtime 记忆（常驻注入） ----
      var runtimeCard = h('div', { style: S.card },
        h('div', { style: { fontWeight: 600, marginBottom: 10 } }, 'D. runtime 记忆（常驻注入）'),
        h('div', { style: Object.assign({}, S.hint, { marginBottom: 10 }) },
          '这些内容每次对话都会全量注入。因为内容恒定，不影响前缀缓存；'
          + '但修改后会重建一次缓存前缀，建议改完开新会话。'),
        injectModePicker({
          label: '常驻记忆注入位置',
          value: d.runtime.mode,
          systemValue: 'section',
          maxMessages: d.runtime.maxMessages,
          capKey: 'runtime',
          help: '「system prompt」是缓存最优路径：内容恒定，一次写入永久命中。'
            + '若你的反代上游会对 system prompt 做指纹检测并清空它，内容会整体丢失 —— '
            + '此时切到「对话消息」：消息在对话历史里，不受 system 被清空影响（代价是历史里删不掉旧版本）。',
          onChange: function (v) { patch('runtime.mode', v) },
          onMaxMessages: function (n) { patch('runtime.maxMessages', n) },
        }),
        (s.runtimeDraft || []).map(function (mem, i) {
          return h('div', { key: i, style: { marginBottom: 10 } },
            h('div', { style: { display: 'flex', gap: 8, marginBottom: 4 } },
              h('select', {
                style: Object.assign({}, S.input, { width: 110, flexShrink: 0 }),
                value: mem.importance,
                onChange: function (e) {
                  var next = s.runtimeDraft.slice()
                  next[i] = Object.assign({}, mem, { importance: e.target.value })
                  merge({ runtimeDraft: next })
                },
              },
                h('option', { value: 'critical' }, '必须遵守'),
                h('option', { value: 'normal' }, '一般事实')),
              h('select', {
                style: Object.assign({}, S.input, { width: 100, flexShrink: 0 }),
                value: mem.target,
                onChange: function (e) {
                  var next = s.runtimeDraft.slice()
                  next[i] = Object.assign({}, mem, { target: e.target.value })
                  merge({ runtimeDraft: next })
                },
              },
                h('option', { value: 'memory' }, 'memory'),
                h('option', { value: 'user' }, 'user')),
              h('button', {
                style: S.button(false),
                onClick: function () {
                  var next = s.runtimeDraft.slice()
                  next.splice(i, 1)
                  merge({ runtimeDraft: next })
                },
              }, '删除')),
            h('textarea', {
              style: Object.assign({}, S.input, { height: 68, resize: 'vertical', lineHeight: '19px' }),
              value: mem.content,
              onChange: function (e) {
                var next = s.runtimeDraft.slice()
                next[i] = Object.assign({}, mem, { content: e.target.value })
                merge({ runtimeDraft: next })
              },
            }))
        }),
        h('div', { style: { display: 'flex', gap: 8, marginTop: 8 } },
          h('button', {
            style: S.button(false),
            onClick: function () {
              var next = (s.runtimeDraft || []).concat([{
                content: '',
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString(),
                target: 'memory',
                importance: 'normal',
              }])
              merge({ runtimeDraft: next })
            },
          }, '+ 新增一条'),
          h('button', { style: S.button(true), onClick: saveRuntime }, '保存 runtime 记忆'))
      )

      // ---- E. 别名表 ----
      var aliasCard = h('div', { style: S.card },
        h('div', { style: { fontWeight: 600, marginBottom: 10 } }, 'E. 同义词别名表'),
        h('div', { style: Object.assign({}, S.hint, { marginBottom: 8 }) },
          '解决「缩写 ↔ 全称」这类字面零重叠的问题。格式：'
          + ' { "规范名": ["别名1", "别名2"] }。命中任一词即把整组词都注入检索。'),
        h('textarea', {
          style: Object.assign({}, S.input, {
            height: 200,
            resize: 'vertical',
            fontFamily: TOKEN.mono,
            fontSize: 12,
            lineHeight: '18px',
          }),
          value: s.aliasText,
          onChange: function (e) { merge({ aliasText: e.target.value }) },
        }),
        h('div', { style: { marginTop: 8 } },
          h('button', { style: S.button(true), onClick: saveAliases }, '保存别名表'))
      )

      // ---- F. 日记存放 ----
      var folderOptions = [{ name: '', label: '（根目录）' }]
        .concat(((s.folders && s.folders.folders) || []).filter(function (f) { return f.name !== '' }))
      var diaryCard = h('div', { style: S.card },
        h('div', { style: { fontWeight: 600, marginBottom: 10 } }, 'F. 日记存放'),
        h('label', { style: S.label }, '日记根目录（新写的 .txt 全部落在这里）'),
        h('input', {
          style: Object.assign({}, S.input, { marginBottom: 6 }),
          value: d.diaryRoot || '',
          placeholder: '留空则用 $VCPRAG_DIARY_DIR 或 <cwd>/diaries',
          onChange: function (e) { patch('diaryRoot', e.target.value) },
        }),
        s.folders && s.folders.root
          ? h('div', { style: Object.assign({}, S.hint, { marginBottom: 10 }) },
            '当前实际路径：' + s.folders.root
            + '（根目录 ' + ((s.folders.folders[0] && s.folders.folders[0].count) || 0) + ' 篇）')
          : null,

        h('label', { style: S.label }, '默认分类子目录（写入时可选覆盖）'),
        h('div', { style: { display: 'flex', gap: 8, marginBottom: 10 } },
          h('input', {
            style: S.input,
            value: d.diary.folder || '',
            placeholder: '留空 = 直接写根目录',
            onChange: function (e) { patch('diary.folder', e.target.value) },
          }),
          h('select', {
            style: Object.assign({}, S.input, { width: 200, flexShrink: 0 }),
            value: d.diary.folder || '',
            onChange: function (e) { patch('diary.folder', e.target.value) },
          }, folderOptions.map(function (f) {
            return h('option', { key: f.name || '__root', value: f.name },
              f.label + (f.count !== undefined ? '（' + f.count + '）' : ''))
          }))),

        h('div', { style: { display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 8 } },
          h('div', { style: { width: 160 } },
            h('label', { style: S.label }, '写入格式'),
            h('select', {
              style: S.input,
              value: d.diary.format,
              onChange: function (e) { patch('diary.format', e.target.value) },
            },
              h('option', { value: 'txt' }, 'txt（纯文本日记）'),
              h('option', { value: 'md' }, 'md（带 frontmatter）'))),
          h('div', { style: { width: 200 } },
            h('label', { style: S.label }, 'runtime 记忆文件'),
            h('input', {
              style: S.input,
              value: d.diary.runtimeFile || '',
              placeholder: '留空 = <语料>/runtime/memories.json',
              onChange: function (e) { patch('diary.runtimeFile', e.target.value) },
            }))),

        h('label', { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 } },
          h('input', {
            type: 'checkbox',
            checked: d.diary.timePrefix,
            onChange: function (e) { patch('diary.timePrefix', e.target.checked) },
          }),
          h('span', null, '强制正文以 [HH:MM] 开头（不合规时警告而非阻拦）')),
        h('label', { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 } },
          h('input', {
            type: 'checkbox',
            checked: d.diary.requireTag,
            onChange: function (e) { patch('diary.requireTag', e.target.checked) },
          }),
          h('span', null, '强制正文末行是 Tag: ...')),
        h('div', { style: S.hint },
          '改动目录或格式不会动已存在的文件；改完记得重建索引让新目录进场。')
      )

      // ---- G. 注入文案与占位符 ----
      var injectCard = h('div', { style: S.card },
        h('div', { style: { fontWeight: 600, marginBottom: 10 } }, 'G. 注入文案与占位符'),
        h('div', { style: Object.assign({}, S.hint, { marginBottom: 10 }) },
          '召回块的外层标签与措辞。不同模型对「这是背景知识」还是「这是待办」的敏感度不同，值得自己调。'),

        injectModePicker({
          label: '召回注入位置',
          value: d.inject.mode,
          systemValue: 'context',
          maxMessages: d.inject.maxMessages,
          capKey: 'inject',
          help: '默认进「对话消息」（插在你这次发言之后）。召回内容是会变的，'
            + '放在消息流里变化不影响 system 消息，也就不会连累后面的对话历史重算 —— '
            + '这是缓存最优的一档。「系统提示词」只在你的上游必须把所有内容塞进 system 时才选。',
          onChange: function (v) { patch('inject.mode', v) },
          onMaxMessages: function (n) { patch('inject.maxMessages', n) },
        }),

        h('div', { style: { display: 'flex', gap: 8, marginBottom: 8 } },
          h('div', { style: { width: 200 } },
            h('label', { style: S.label }, '外层标签名'),
            h('input', {
              style: S.input,
              value: d.inject.blockName,
              placeholder: 'vcprag-recall',
              onChange: function (e) { patch('inject.blockName', e.target.value) },
            })),
          h('div', { style: { width: 120 } },
            h('label', { style: S.label }, '注入顺序'),
            h('input', {
              style: S.input,
              type: 'number',
              value: d.inject.order,
              onChange: function (e) { patch('inject.order', Number(e.target.value)) },
            }))),

        h('label', { style: S.label }, '召回块首行说明'),
        h('input', {
          style: Object.assign({}, S.input, { marginBottom: 8 }),
          value: d.inject.header,
          onChange: function (e) { patch('inject.header', e.target.value) },
        }),

        h('label', { style: S.label }, '免责声明（避免模型把记忆当指令执行）'),
        h('input', {
          style: Object.assign({}, S.input, { marginBottom: 8 }),
          value: d.inject.disclaimer,
          onChange: function (e) { patch('inject.disclaimer', e.target.value) },
        }),

        h('label', { style: S.label }, '单条命中前缀（可用 {n} {date} {title}）'),
        h('input', {
          style: Object.assign({}, S.input, { marginBottom: 12 }),
          value: d.inject.itemPrefix,
          onChange: function (e) { patch('inject.itemPrefix', e.target.value) },
        }),

        h('div', { style: { fontWeight: 600, marginBottom: 8 } }, '常驻记忆 section 标题'),
        h('div', { style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 8 } },
          h('div', { style: { flex: 2, minWidth: 180 } },
            h('label', { style: S.label }, '区块标题'),
            h('input', {
              style: S.input,
              value: d.runtime.title,
              onChange: function (e) { patch('runtime.title', e.target.value) },
            })),
          h('div', { style: { flex: 1, minWidth: 120 } },
            h('label', { style: S.label }, '「必须遵守」标题'),
            h('input', {
              style: S.input,
              value: d.runtime.criticalTitle,
              onChange: function (e) { patch('runtime.criticalTitle', e.target.value) },
            })),
          h('div', { style: { flex: 1, minWidth: 120 } },
            h('label', { style: S.label }, '「一般事实」标题'),
            h('input', {
              style: S.input,
              value: d.runtime.normalTitle,
              onChange: function (e) { patch('runtime.normalTitle', e.target.value) },
            }))),
        h('label', { style: S.label }, '引导语'),
        h('input', {
          style: Object.assign({}, S.input, { marginBottom: 8 }),
          value: d.runtime.intro,
          onChange: function (e) { patch('runtime.intro', e.target.value) },
        }),
        h('label', { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 } },
          h('input', {
            type: 'checkbox',
            checked: d.runtime.toolGuidance,
            onChange: function (e) { patch('runtime.toolGuidance', e.target.checked) },
          }),
          h('span', null, '附带 6 个工具的用法说明')),
        h('div', { style: S.hint },
          '这些文案改动会让 system prompt 变化 → 触发一次缓存前缀重建。改完建议开新会话。')
      )

      // ---- H. 日记写作规范（模板注入）----
      var templateCard = h('div', { style: S.card },
        h('div', { style: { fontWeight: 600, marginBottom: 10 } }, 'H. 日记写作规范（注入 system prompt）'),
        h('div', { style: Object.assign({}, S.hint, { marginBottom: 10 }) },
          '这段提示词决定日记质量，是全插件杠杆最大的一处。留空则用内置模板。'
          + '模板作为 section 常驻注入，逐字节恒定 → 不破坏前缀缓存。'),
        h('div', { style: { display: 'flex', gap: 10, alignItems: 'center', marginBottom: 8 } },
          h('label', { style: { display: 'flex', alignItems: 'center', gap: 8 } },
            h('input', {
              type: 'checkbox',
              checked: !!d.diary.templateEnabled,
              onChange: function (e) {
                patch('diary.templateEnabled', e.target.checked)
                saveTemplate(undefined, e.target.checked)
              },
            }),
            h('span', null, '注入日记规范')),
          h('div', { style: { width: 120 } },
            h('input', {
              style: S.input,
              type: 'number',
              value: d.diary.templateOrder,
              title: '注入顺序',
              onChange: function (e) { patch('diary.templateOrder', Number(e.target.value)) },
            })),
          s.template
            ? h('span', { style: S.badge(s.template.isCustom ? 'info' : 'muted') },
              s.template.isCustom ? '自定义模板' : '内置模板')
            : null),
        h('textarea', {
          style: Object.assign({}, S.input, {
            height: 360,
            resize: 'vertical',
            fontFamily: TOKEN.mono,
            fontSize: 12,
            lineHeight: '18px',
          }),
          value: s.templateText,
          placeholder: '留空 = 使用内置模板',
          onChange: function (e) { setTemplateState({ template: e.target.value }) },
        }),
        h('div', { style: { display: 'flex', gap: 8, marginTop: 8, alignItems: 'center' } },
          h('button', {
            style: S.button(true),
            onClick: function () { saveTemplate(s.templateText, undefined) },
          }, '保存模板'),
          h('button', {
            style: S.button(false),
            onClick: function () {
              var builtIn = (s.template && s.template.builtIn) || ''
              setTemplateState({ template: builtIn })
            },
          }, '填入内置模板'),
          h('button', {
            style: S.button(false),
            onClick: function () {
              setTemplateState({ template: '' })
              saveTemplate('', undefined)
            },
          }, '清空（回退内置）'),
          h('span', { style: S.hint }, '改动需重启 DSH 才生效'))
      )

      // ---- I. 语义写入（正文结构化块）----
      var semantic = d.diary.semantic || {}
      var semanticCard = h('div', { style: S.card },
        h('div', { style: { fontWeight: 600, marginBottom: 10 } }, 'I. 语义写入（在回复正文里写日记块）'),
        h('div', { style: Object.assign({}, S.hint, { marginBottom: 10 }) },
          '开一条不经过工具往返的写入通道：模型直接在正文里落一段 '
          + h('code', { style: S.code }, '<<<' + (semantic.blockName || 'DailyNote') + 'Start>>> … <<<' + (semantic.blockName || 'DailyNote') + 'End>>>')
          + '，系统解析后写盘。与工具调用并存，默认优先 —— 省一轮上下文，且块本身可读可校对。'),

        h('div', { style: { display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'center', marginBottom: 10 } },
          h('label', { style: { display: 'flex', alignItems: 'center', gap: 8 } },
            h('input', {
              type: 'checkbox',
              checked: semantic.enabled !== false,
              onChange: function (e) { patch('diary.semantic.enabled', e.target.checked) },
            }),
            h('span', null, '启用语义写入')),
          h('label', { style: { display: 'flex', alignItems: 'center', gap: 8 } },
            h('input', {
              type: 'checkbox',
              checked: semantic.allowUpdate !== false,
              onChange: function (e) { patch('diary.semantic.allowUpdate', e.target.checked) },
            }),
            h('span', null, '允许 update 改已有日记')),
          h('label', { style: { display: 'flex', alignItems: 'center', gap: 8 } },
            h('input', {
              type: 'checkbox',
              checked: semantic.stripFromDisplay !== false,
              onChange: function (e) { patch('diary.semantic.stripFromDisplay', e.target.checked) },
            }),
            h('span', null, '气泡里隐藏块'))),

        h('div', { style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 10 } },
          h('div', { style: { flex: 1, minWidth: 160 } },
            h('label', { style: S.label }, '块标记名'),
            h('input', {
              style: S.input,
              value: semantic.blockName || 'DailyNote',
              placeholder: 'DailyNote',
              onChange: function (e) { patch('diary.semantic.blockName', e.target.value) },
            })),
          h('div', { style: { width: 160 } },
            h('label', { style: S.label }, 'update 锚点最短字数'),
            h('input', {
              style: S.input,
              type: 'number',
              min: 5,
              max: 500,
              value: semantic.updateMinTarget === undefined ? 15 : semantic.updateMinTarget,
              onChange: function (e) { patch('diary.semantic.updateMinTarget', Number(e.target.value)) },
            }))),

        h('div', { style: Object.assign({}, S.hint, { marginBottom: 6 }) },
          '安全阀：update 的 target 太短会命中多处，替换就成了随机破坏。'
          + '15 字是稳妥下限，调低请自行承担风险。'),

        // ---- 自检：贴一段正文，验证一下解析结果 ----
        h('div', { style: { fontWeight: 600, margin: '12px 0 6px' } }, '自检：贴一段正文看解析结果'),
        h('textarea', {
          style: Object.assign({}, S.input, {
            height: 130,
            resize: 'vertical',
            fontFamily: TOKEN.mono,
            fontSize: 12,
            lineHeight: '18px',
          }),
          value: s.previewText,
          placeholder: '把带块的回复正文贴进来，下面会显示系统会解析成什么。',
          onChange: function (e) { setPreviewState({ previewText: e.target.value }) },
        }),
        h('div', { style: { display: 'flex', gap: 8, marginTop: 8, alignItems: 'center' } },
          h('button', {
            style: S.button(true),
            onClick: function () { runPreview(s.previewText) },
          }, '解析看看'),
          s.preview
            ? h('span', { style: S.badge(s.preview.found > 0 ? 'ok' : 'warn') },
              '解析到 ' + s.preview.found + ' 个块')
            : null),
        s.preview
          ? h('div', { style: Object.assign({}, S.mono, { marginTop: 8 }) },
            (s.preview.rows || []).map(function (row, i) {
              return h('div', {
                key: 'pv' + i,
                style: {
                  padding: '6px 8px',
                  marginBottom: 6,
                  borderRadius: 4,
                  background: TOKEN.surface2,
                  borderLeft: '3px solid ' + (row.ok ? TOKEN.success : TOKEN.error),
                },
              },
                h('div', null, '#' + (i + 1) + ' command=' + (row.command || '(无)')
                  + (row.title ? ' · title=' + row.title : '')
                  + (row.bodyChars ? ' · 正文 ' + row.bodyChars + ' 字' : '')),
                row.target ? h('div', { style: { color: TOKEN.label2 } }, 'target(' + row.target.length + ' 字): ' + row.target.slice(0, 60)) : null,
                row.tags && row.tags.length ? h('div', { style: { color: TOKEN.label2 } }, 'tags: ' + row.tags.join(', ')) : null,
                (row.errors || []).length ? h('div', { style: { color: TOKEN.error } }, '✗ ' + row.errors.join(' / ')) : null,
                (row.problems || []).length ? h('div', { style: { color: TOKEN.label2 } }, '⚠ ' + row.problems.join(' / ')) : null)
            }),
            s.preview.hint ? h('div', { style: { color: TOKEN.label2, marginTop: 4 } }, s.preview.hint) : null)
          : null
      )

      // ---- 分区 ----
      //
      // 卡片原来是十张一路往下滚，找个「判官超时」要翻半天。这里按
      // **它影响什么** 归成五段，左边给一排锚点。分类原则：
      //   语料目录   它去哪里找东西
      //   嵌入模型   向量怎么算（换它必须重建索引）
      //   召回策略   怎么排序、怎么过滤、注入到哪
      //   判官重排   可选的第二道裁判
      //   日记与写作 它写出去的东西长什么样
      //
      // 每段是 {id, label, cards[]}，渲染时只显示当前段 —— 不隐藏而是
      // 不渲染，避免十张卡片同时挂载时那些受控输入互相干扰。
      // 卡片与分区的对应关系按**卡片自己的标题**来，别凭名字猜：
      //   channelCard  = 「A. Embedding 渠道」  → 嵌入模型
      //   recallCard   = 「B. 召回参数」（判官是它内部子块）→ 召回策略
      //   freezeCard   = 「C. 冻结行为」        → 召回策略
      //   runtimeCard  = 「D. runtime 记忆」    → 常驻注入
      //   aliasCard    = 「E. 同义词别名表」    → 召回策略（它影响分词）
      //   diaryCard    = 「F. 日记存放」        → 日记
      //   injectCard   = 「G. 注入文案与占位符」→ 召回策略
      //   templateCard = 「H. 日记写作规范」    → 日记
      //   semanticCard = 「I. 语义写入」        → 日记
      //
      // 语料目录（corpusRoot / diaryRoot / 递归层数 / 文件类型）目前没有
      // 独立卡片 —— 它散在 A 和 F 里。所以这一段直接复用 channelCard 的
      // 目录部分不现实，改为把 A/F 都放进来更诚实：用户要找路径就在这两段。
      // runtimeCard 和 injectCard 放在同一段是有意的：两者的「注入位置 +
      // 保留几条」是同一组语义（常驻记忆 vs 动态召回），用户调其中一个
      // 时几乎必然要看另一个。拆到两段里等于逼他来回切。
      var SECTIONS = [
        { id: 'embed', label: '嵌入模型', cards: [channelCard] },
        { id: 'recall', label: '召回与注入', cards: [recallCard, freezeCard, runtimeCard, injectCard, aliasCard] },
        { id: 'diary', label: '日记与写作', cards: [diaryCard, templateCard, semanticCard] },
      ]
      var activeId = s.sectionId || 'embed'
      var activeSection = SECTIONS.filter(function (x) { return x.id === activeId })[0] || SECTIONS[0]

      var setNav = h('nav', { className: 'vcp-setnav', 'aria-label': '设置分区' },
        SECTIONS.map(function (x) {
          return h('button', {
            key: x.id,
            type: 'button',
            'aria-current': x.id === activeSection.id ? 'true' : undefined,
            onClick: function () { merge({ sectionId: x.id }) },
          }, x.label)
        }))

      // ---- 底部保存栏 ----
      var dirty = s.dirty === true
      var footer = h('div', { className: 'vcp-savebar' },
        h('span', { className: 'saved', 'data-dirty': dirty ? '1' : undefined },
          dirty ? '有未保存的改动' : (s.msg || '无未保存改动')),
        h('button', { style: S.button(false), onClick: load }, '重置'),
        h('button', { style: S.button(true), onClick: function () { save(false) } }, '保存'))

      var body = h('div', { className: 'vcp-set' },
        setNav,
        h('div', null,
          activeSection.cards,
          footer))

      if (s.dialog === null) return body

      return h('div', null, body,
        h(ConfirmDialog, {
          title: s.dialog.title,
          message: s.dialog.message,
          consequences: s.dialog.consequences,
          actions: s.dialog.actions,
          onChoose: onDialogChoose,
        }))
    }

    // ================= 页 1：记忆库 =================
    //
    // 原来的 LibraryTab 是「左列表 300px + 右详情」的主从分栏。窄面板下那套
    // 会挤成两条窄缝，所以改成单栏行列表：点一行原地展开，不跳转、不分栏。

    function LibraryPage() {
      var state = React.useState({
        rows: [], total: 0, sources: [], q: '',
        open: null, doc: null, editing: false, draft: '', msg: null,
        confirmDel: null,
      })
      var s = state[0]
      var set = state[1]

      function merge(patch) {
        set(function (prev) { return Object.assign({}, prev, patch) })
      }

      var load = React.useCallback(function (q) {
        get('/library', { q: q }).then(function (r) {
          if (r.ok) merge({ rows: r.rows, total: r.total, sources: r.sources || [] })
        })
      }, [])

      React.useEffect(function () { load('') }, [load])

      function toggle(row) {
        if (s.open === row.docId) {
          merge({ open: null, doc: null, editing: false, msg: null })
          return
        }
        get('/document', { docId: row.docId }).then(function (r) {
          if (r.ok) merge({ open: row.docId, doc: r, editing: false, draft: r.body, msg: null })
        })
      }

      function save() {
        if (s.doc === null) return
        merge({ msg: '保存中…' })
        post('/document/save', { docId: s.doc.docId, body: s.draft }).then(function (r) {
          if (r.ok) {
            merge({
              msg: '已保存，该篇索引已增量更新',
              editing: false,
              doc: Object.assign({}, s.doc, { body: s.draft }),
            })
            load(s.q)
          } else {
            merge({ msg: '保存失败：' + (r.error || '未知错误') })
          }
        })
      }

      /**
       * 删除一篇日记。
       *
       * 两步确认走的是原生 window.confirm 而不是自绘弹窗 —— 这个动作
       * 不可逆，弹窗被误关/被样式搞坏都比「多问一句」代价大。
       */
      function removeDoc(row) {
        var ok = window.confirm(
          '删除这篇日记？\n\n' + (row.title || row.filename)
          + '\n\n文件会被删掉，索引也会同步摘掉（' + row.chunks + ' 块）。此操作不可撤销。'
        )
        if (!ok) return
        merge({ msg: '删除中…' })
        post('/document/delete', { docId: row.docId }).then(function (r) {
          if (!r.ok) {
            merge({ msg: '删除失败：' + (r.error || '未知错误') })
            return
          }
          merge({
            msg: r.warning ? r.warning : ('已删除，索引同步摘掉 ' + ((r.index && r.index.chunkCount) || 0) + ' 块'),
            open: null, doc: null, editing: false,
          })
          load(s.q)
        })
      }

      /** 重新扫描目录：等价于一次全量重建，走索引页那条端点。 */
      function rescan() {
        merge({ msg: '正在重新扫描…' })
        post('/index/rebuild', { force: false }).then(function (r) {
          if (r.requiresConfirm) {
            var go = window.confirm((r.message || '索引配置不兼容') + '\n\n仍然重建？')
            if (!go) { merge({ msg: null }); return }
            post('/index/rebuild', { force: true }).then(function (r2) {
              merge({ msg: r2.ok ? '已开始重建，去索引页看进度' : ('重建失败：' + (r2.error || '未知')) })
            })
            return
          }
          merge({ msg: r.ok ? '已开始重建，去索引页看进度' : ('重建失败：' + (r.error || '未知')) })
          if (r.ok) load(s.q)
        })
      }

      /** 导出：把当前列表拼成一段 Markdown 让浏览器存盘。 */
      function exportList() {
        if (s.rows.length === 0) { merge({ msg: '没有可导出的条目' }); return }
        var lines = ['# 记忆库导出', '', '共 ' + s.rows.length + ' 条', '']
        s.rows.forEach(function (row) {
          lines.push('## ' + (row.title || row.filename))
          lines.push('')
          lines.push('- 日期：' + (row.date || '无'))
          lines.push('- 文件：' + row.filename)
          lines.push('- 分块：' + row.chunks)
          lines.push('')
        })
        var blob = new Blob([lines.join('\n')], { type: 'text/markdown;charset=utf-8' })
        var url = URL.createObjectURL(blob)
        var a = document.createElement('a')
        a.href = url
        a.download = 'vcprag-记忆库-' + new Date().toISOString().slice(0, 10) + '.md'
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        URL.revokeObjectURL(url)
        merge({ msg: '已导出 ' + s.rows.length + ' 条' })
      }

      var rows = s.rows.map(function (row) {
        var isOpen = s.open === row.docId
        var doc = isOpen ? s.doc : null

        var more = null
        if (isOpen && doc !== null) {
          more = h('div', { className: 'vcp-mem-more' },
            h('div', { className: 'vcp-more' },
              s.editing
                ? h('textarea', {
                  className: 'vcp-field',
                  style: { width: '100%', height: 360, lineHeight: '19px', resize: 'vertical' },
                  value: s.draft,
                  onChange: function (e) { merge({ draft: e.target.value }) },
                })
                : h('p', { style: { whiteSpace: 'pre-wrap', margin: 0 } }, doc.body),
              h('div', { className: 'vcp-acts' },
                h('button', {
                  className: 'vcp-btn',
                  onClick: function (e) {
                    e.stopPropagation()
                    merge({ editing: !s.editing, draft: doc.body })
                  },
                }, s.editing ? '取消编辑' : '编辑正文'),
                s.editing
                  ? h('button', {
                    className: 'vcp-btn pri',
                    onClick: function (e) { e.stopPropagation(); save() },
                  }, '保存并重建该篇索引')
                  : null,
                // 只有 .txt 日记给删除入口。语料目录里的 .md 属于别的工具，
                // 面板不该越界去删（端点也拦着，这里只是不显示）。
                row.deletable === true
                  ? h('button', {
                    className: 'vcp-btn danger',
                    onClick: function (e) { e.stopPropagation(); removeDoc(row) },
                  }, '删除')
                  : null,
                s.msg ? h('span', {
                  style: { fontSize: 11, color: 'var(--dsw-alias-label-tertiary)' },
                }, s.msg) : null)))
        }

        return h('article', {
          key: row.docId,
          className: 'vcp-mem',
          'data-open': isOpen ? '1' : undefined,
          onClick: function () { toggle(row) },
        },
          h('div', { className: 'vcp-mem-h' },
            h('h4', null, row.title || row.filename),
            h('time', null, row.date || '无日期')),
          h('p', { className: 'vcp-mem-ex' }, row.description || row.filename),
          h('div', { className: 'vcp-mem-meta' },
            h('span', null, row.chunks + ' 块'),
            doc !== null && doc.frontmatter ? h('span', null, doc.frontmatter.title ? '有标题' : '无标题') : null,
            h('span', null, isOpen ? '收起' : '展开')),
          more)
      })

      // 来源分布：按日期月份聚合块数，条形长度按最大那一项归一。
      // 一条都没有时不画空条 —— 那看着像坏了。
      var maxCount = 0
      s.sources.forEach(function (row) { if (row.count > maxCount) maxCount = row.count })
      var sourceCard = h('div', { className: 'vcp-card' },
        h('p', { className: 'vcp-card-t' }, '来源分布'),
        s.sources.length === 0
          ? h('p', { style: { margin: 0, fontSize: 11.5, color: 'var(--dsw-alias-label-tertiary)' } }, '索引里还没有内容。')
          : s.sources.map(function (row) {
            return h('div', { className: 'vcp-bar', key: row.label },
              h('div', { className: 'vcp-bar-lab' },
                h('span', null, row.label),
                h('b', null, String(row.count))),
              h('div', { className: 'vcp-track' },
                h('i', { style: { width: Math.max(3, Math.round((row.count / maxCount) * 100)) + '%' } })))
          }))

      var sides = h('aside', null,
        h('div', { className: 'vcp-card' },
          h('p', { className: 'vcp-card-t' }, '语料概况'),
          h('div', { className: 'vcp-kv' }, h('span', null, '匹配'), h('b', null, s.rows.length + ' 篇')),
          h('div', { className: 'vcp-kv' }, h('span', null, '全部'), h('b', null, s.total + ' 篇')),
          h('div', { className: 'vcp-kv' }, h('span', null, '展开'), h('b', null, s.open === null ? '—' : '1 篇'))),
        sourceCard)

      return h('div', null,
        h(PageHead, {
          eyebrow: '语料',
          title: '记忆库',
          sub: '这里每一行都是一条可被召回的记忆。点开能读原文、改正文，保存后该篇索引会增量更新。',
          actions: [
            h('input', {
              key: 'q',
              className: 'vcp-btn',
              style: { flex: '1 1 200px', minWidth: 0, fontWeight: 400, textAlign: 'left' },
              placeholder: '按标题过滤…',
              value: s.q,
              onChange: function (e) {
                var q = e.target.value
                merge({ q: q })
                load(q)
              },
            }),
            h('button', { key: 'rescan', className: 'vcp-btn', onClick: rescan }, '重新扫描目录'),
            h('button', { key: 'export', className: 'vcp-btn', onClick: exportList }, '导出'),
            s.msg
              ? h('span', {
                key: 'msg',
                style: { fontSize: 11, color: 'var(--dsw-alias-label-tertiary)', flex: '1 1 100%' },
              }, s.msg)
              : null,
          ],
        }),
        h('div', { className: 'vcp-cols' },
          h('div', null,
            h('div', { className: 'vcp-sect' },
              h('h3', null, '记忆条目'),
              h('span', { className: 'meta' }, s.q ? '匹配 ' + s.rows.length + ' 篇' : '共 ' + s.total + ' 篇')),
            rows.length === 0
              ? h('div', { className: 'vcp-card' }, '没有匹配的条目。换个关键词，或去索引页重新扫描目录。')
              : rows),
          sides))
    }

    // ================= 页 2：召回调试 =================

    function RecallPage() {
      var state = React.useState({ q: '', only: 'both', limit: 10, result: null, busy: false, error: null })
      var s = state[0]
      var set = state[1]

      function merge(patch) {
        set(function (prev) { return Object.assign({}, prev, patch) })
      }

      function run() {
        if (s.q.trim() === '') return
        merge({ busy: true, error: null })
        get('/recall', {
          q: s.q,
          limit: s.limit,
          only: s.only === 'both' ? undefined : s.only,
        }).then(function (r) {
          merge({ busy: false, result: r.ok ? r : null, error: r.ok ? null : (r.error || '请求失败') })
        })
      }

      var search = h('div', { className: 'vcp-search' },
        h('input', {
          placeholder: '输入查询，回车执行…',
          value: s.q,
          onChange: function (e) { merge({ q: e.target.value }) },
          onKeyDown: function (e) { if (e.key === 'Enter') run() },
        }),
        h('button', { className: 'vcp-btn pri', onClick: run, disabled: s.busy },
          s.busy ? '检索中…' : '召回'))

      var body = null
      if (s.error !== null) {
        body = h('div', { className: 'vcp-card' }, s.error)
      } else if (s.result === null) {
        body = h('div', { className: 'vcp-card' },
          '输入查询后回车。这里能看到「词法 / 向量 / 融合」三路分别的分数，以及 BM25 实际看到的 token，'
          + '用来判断是哪一路在起作用、为什么某次召回是零命中。')
      } else {
        var res = s.result
        var t = res.timing
        var stat = h('div', { className: 'vcp-card' },
          h('p', { className: 'vcp-card-t' }, '本次召回'),
          h('div', { className: 'vcp-kv' }, h('span', null, 'K'), h('b', null, res.k)),
          h('div', { className: 'vcp-kv' }, h('span', null, '词法'), h('b', null, t.lexicalCount + ' 条 / ' + t.lexicalMs + 'ms')),
          h('div', { className: 'vcp-kv' }, h('span', null, '向量'), h('b', null, t.semanticSkipped ? '未参与' : (t.semanticCount + ' 条 / ' + t.semanticMs + 'ms'))),
          h('div', { className: 'vcp-kv' }, h('span', null, '融合'), h('b', null, t.fusedCount + ' → 去重 ' + t.dedupedCount)),
          h('div', { className: 'vcp-kv' }, h('span', null, '耗时'), h('b', null, t.totalMs + 'ms')),
          t.semanticSkipped
            ? h('p', { style: { margin: '10px 0 0', fontSize: 11, lineHeight: 1.75, color: 'var(--dsw-alias-label-tertiary)' } },
              '向量通道未参与：' + t.semanticSkipped)
            : null)

        var tokenCard = h('div', { className: 'vcp-card' },
          h('p', { className: 'vcp-card-t' }, 'BM25 token（' + res.queryTokens.length + '）'),
          h('div', { style: { fontSize: 11.5, lineHeight: 1.9, wordBreak: 'break-all', color: 'var(--dsw-alias-label-secondary)' } },
            res.queryTokens.slice(0, 100).join(' · ')),
          h('p', { style: { margin: '10px 0 0', fontSize: 11, lineHeight: 1.75, color: 'var(--dsw-alias-label-tertiary)' } },
            '零命中时先看这里：查询词与文档用词若没有字面重叠，纯词法路就是空的。'))

        var hits = res.hits.length === 0
          ? h('div', { className: 'vcp-card' }, '零命中。对照上方的分词结果，检查查询词是否与文档用词有字面重叠。')
          : h('div', null, res.hits.map(function (hit, i) {
            return h('article', { key: hit.chunkId, className: 'vcp-hit' },
              h('div', { className: 'vcp-hit-top' },
                h('span', { className: 'vcp-rank' }, String(i + 1).padStart(2, '0')),
                h('h4', null, hit.title || hit.filename),
                h('span', { className: 'vcp-score' }, String(hit.final))),
              h('p', null, hit.excerpt + '…'),
              h('div', { className: 'vcp-scores' },
                h('span', null, '词法 ', h('em', null, String(hit.lexical))),
                h('span', null, '向量 ', h('em', null, hit.semantic === null ? '—' : String(hit.semantic))),
                h('span', null, 'RRF ', h('em', null, String(hit.rrf))),
                hit.moreChunks > 0
                  ? h('span', null, '同文档另 ', h('em', null, hit.moreChunks + ' 块（已折叠）'))
                  : null,
                hit.matched.length > 0
                  ? h('span', null, '命中 ', h('em', null, hit.matched.join(', ')))
                  : null))
          }))

        body = h('div', { className: 'vcp-cols' },
          h('div', null,
            h('div', { className: 'vcp-sect' },
              h('h3', null, '命中 ' + res.hits.length + ' 条'),
              h('span', { className: 'meta' }, '上限 ' + res.k)),
            hits),
          h('aside', null, stat, tokenCard))
      }

      return h('div', null,
        h(PageHead, {
          eyebrow: '调试',
          title: '召回调试',
          sub: '用一句话问它，看它翻出什么、每块分别得了多少分。分数不对时，问题通常出在权重或分块粒度上。',
        }),
        search,
        body)
    }

    // ================= 页 3：索引 =================

    function IndexPage() {
      var state = React.useState({ state: null, progress: null, verify: null, busy: false })
      var s = state[0]
      var set = state[1]
      var timer = React.useRef(null)

      function merge(patch) {
        set(function (prev) { return Object.assign({}, prev, patch) })
      }

      function loadOnce() {
        get('/state').then(function (r) {
          if (r.ok) merge({ state: r })
        })
        get('/index/progress').then(function (r) {
          if (!r.ok) return
          merge({ progress: r })
          if (r.building) {
            if (timer.current) clearTimeout(timer.current)
            timer.current = setTimeout(loadOnce, 1200)
          }
        })
      }

      React.useEffect(function () {
        loadOnce()
        return function () { if (timer.current) clearTimeout(timer.current) }
      }, [])

      function rebuild(force) {
        merge({ busy: true })
        post('/index/rebuild', { force: force === true }).then(function (r) {
          merge({ busy: false })
          if (r.requiresConfirm) {
            var ok = window.confirm(
              (r.message || '索引配置不兼容') + '\n\n' + (r.hint || '') + '\n\n仍然重建？'
            )
            if (ok) rebuild(true)
            return
          }
          if (r.ok) setTimeout(loadOnce, 400)
          else window.alert('重建失败：' + (r.error || '未知'))
        })
      }

      function verify() {
        merge({ busy: true })
        post('/index/verify', {}).then(function (r) {
          merge({ busy: false, verify: r.verify || r })
        })
      }

      /**
       * 对账清理：摘掉索引里磁盘上已不存在的文档。
       *
       * 和「重建索引」的区别要说清楚 —— 重建要重算全部嵌入（几分钟），
       * 对账只做差集（几秒），所以它是个日常按钮而不是危险操作。
       */
      function prune() {
        merge({ busy: true })
        post('/index/prune', {}).then(function (r) {
          merge({ busy: false })
          if (!r.ok) { window.alert('对账失败：' + (r.error || '未知')); return }
          var n = (r.removed || []).length
          window.alert(
            n === 0
              ? '对账完成：索引与磁盘一致（' + r.live + ' 篇），没有需要清理的条目。'
              : '对账完成：摘掉 ' + n + ' 篇幽灵文档、' + r.chunkCount + ' 块、' + r.vectorCount + ' 条向量。'
          )
          loadOnce()
        })
      }

      if (s.state === null) {
        return h('div', null,
          h(PageHead, { eyebrow: '索引', title: '索引' }),
          h('div', { className: 'vcp-card' }, '加载中…'))
      }

      var idx = s.state.index
      var prog = s.progress && s.progress.status
      var building = s.progress && s.progress.building

      var band = h('div', { className: 'vcp-band' },
        h('div', { className: 'vcp-stat' },
          h('b', null, String(idx.chunkCount)),
          h('span', null, '已索引分块'),
          h('span', { className: 'tag' }, idx.hybridReady ? '● 已同步' : '● 仅关键词')),
        h('div', { className: 'vcp-stat' },
          h('b', null, String(idx.vectorized)),
          h('span', null, '已向量化')),
        h('div', { className: 'vcp-stat' },
          h('b', null, idx.embedding ? String(idx.embedding.dimensions) : '—'),
          h('span', null, '向量维数')),
        h('div', { className: 'vcp-stat' },
          h('b', null, String(idx.bm25.vocabularySize)),
          h('span', null, '词表大小')))

      var detail = h('div', null,
        h('div', { className: 'vcp-dir' },
          h('span', { className: 'nm' }, '文档'),
          h('span', { className: 'pt' }, idx.indexDir),
          h('span', { className: 'n1' }, String(idx.docCount) + ' 篇'),
          h('span', { className: 'n2' }, String(idx.vectorized) + ' 块')),
        h('div', { className: 'vcp-dir' },
          h('span', { className: 'nm' }, '模型'),
          h('span', { className: 'pt' }, idx.embedding ? idx.embedding.model : '—'),
          h('span', { className: 'n1' }, ''),
          h('span', { className: 'n2' }, idx.embedding ? String(idx.embedding.dimensions) + 'd' : '—')),
        h('div', { className: 'vcp-dir' },
          h('span', { className: 'nm' }, '分块'),
          h('span', { className: 'pt' }, idx.chunkSize + ' / 重叠 ' + idx.chunkOverlap),
          h('span', { className: 'n1' }, ''),
          h('span', { className: 'n2' }, '')),
        h('div', { className: 'vcp-dir' },
          h('span', { className: 'nm' }, 'BM25'),
          h('span', { className: 'pt' }, idx.bm25.docCount + ' 文档'),
          h('span', { className: 'n1' }, ''),
          h('span', { className: 'n2' }, idx.bm25.vocabularySize + ' 词')),
        h('div', { className: 'vcp-dir' },
          h('span', { className: 'nm' }, '建立于'),
          h('span', { className: 'pt' }, idx.builtAt || '尚未建立'),
          h('span', { className: 'n1' }, ''),
          h('span', { className: 'n2' }, '')))

      var progress = null
      if (building && prog) {
        progress = h('div', { className: 'vcp-card' },
          h('p', { className: 'vcp-card-t' }, '正在重建'),
          h('div', { className: 'vcp-bar-lab' },
            h('span', null, prog.message),
            h('b', null, prog.doneBatches + '/' + prog.totalBatches + ' 批')),
          h('div', { className: 'vcp-track' },
            h('i', { style: { width: Math.max(2, prog.progress) + '%' } })),
          h('p', { style: { margin: '10px 0 0', fontSize: 11, lineHeight: 1.75, color: 'var(--dsw-alias-label-tertiary)' } },
            '构建期间召回降级为纯关键词，对话不受影响。'))
      }

      var verifyCard = null
      if (s.verify !== null) {
        var samples = s.verify.error
          ? h('p', { style: { margin: 0, fontSize: 12 } }, s.verify.error)
          : h('div', { style: { fontSize: 11, lineHeight: 1.9 } },
            (s.verify.samples || []).map(function (row) {
              return h('div', { key: row.chunkId },
                (row.similarity >= 0.999 ? '✓ ' : '✗ ') + row.similarity + '  ' +
                (row.title || row.chunkId) + (row.error ? '  [' + row.error + ']' : ''))
            }))
        verifyCard = h('div', { className: 'vcp-card' },
          h('p', { className: 'vcp-card-t' }, s.verify.ok ? '完整性通过' : '完整性异常'),
          samples,
          h('p', { style: { margin: '10px 0 0', fontSize: 11, lineHeight: 1.75, color: 'var(--dsw-alias-label-tertiary)' } },
            '抽查 5 个 chunk 重新 embed 并与磁盘向量比对。低于 0.999 说明配置不一致或索引损坏。'))
      }

      var warn = idx.compatible && idx.compatible.ok === false
        ? h('div', { className: 'vcp-card', style: { borderColor: 'var(--dsw-alias-state-error-primary)' } },
          h('p', { className: 'vcp-card-t' }, '配置不兼容'),
          h('p', { style: { margin: 0, fontSize: 12, lineHeight: 1.8, whiteSpace: 'pre-wrap' } },
            (idx.compatible.reason || '') + '\n' + (idx.compatible.message || '')))
        : null

      return h('div', null,
        h(PageHead, {
          eyebrow: '索引',
          title: '索引',
          sub: '重建是全量重算嵌入；校验只比对元数据，几秒就能跑完。换过嵌入模型之后必须重建，否则新旧向量不在同一空间。',
          actions: [
            h('button', {
              key: 'r', className: 'vcp-btn pri',
              onClick: function () { rebuild(false) }, disabled: s.busy || building,
            }, building ? '构建中…' : '重建索引'),
            h('button', {
              key: 'v', className: 'vcp-btn',
              onClick: verify, disabled: s.busy || building,
            }, '校验一致性'),
            h('button', {
              key: 'p', className: 'vcp-btn',
              onClick: prune, disabled: s.busy || building,
            }, '对账清理'),
            h('button', { key: 'f', className: 'vcp-btn quiet', onClick: loadOnce }, '刷新'),
          ],
        }),
        band,
        warn,
        h('div', { className: 'vcp-sect' }, h('h3', null, '明细'), h('span', { className: 'meta' }, '')),
        detail,
        progress,
        verifyCard)
    }

    // 设置页：内容逻辑沿用原 SettingsTab（字段太多且都有真实端点），
    // 这里只加页头，让它和其它三页共用同一骨架。
    function SettingsPage() {
      return h('div', null,
        h(PageHead, {
          eyebrow: '设置',
          title: '设置',
          sub: '这些决定它去哪里找东西、怎么算相似度。改动立刻生效；要让旧分块用上新模型，还得去索引页重建。',
        }),
        h(SettingsTab, null))
    }

    // ================= 新外壳：左导航 + 分页 =================
    //
    // 容器查询（@container）内联 style 表达不了，所以和宿主自己的
    // @deepseek-ai/dsh-client-ui-sidebar-browser 一样注入一个 <style> 标签。
    // 全部颜色走 --dsw-* 语义 token，深浅色自动跟随宿主，不写字面色值。

    var CSS_TAG = 'vcprag/panel.css'
    /** 右栏 tab 的 kind 与注册 id，两处必须是同一个值。 */
    var KIND = 'vcprag'

    function cssText() {
      return [
        // 只负责当容器查询的参照物。宽度/高度必须钉死，否则它会跟着内容长。
        // 字体栈：设计稿用衬线做标题、等宽做数字。这里不写死具体字体名，
        // 而是给一串联级 —— 用户机器上有哪个就用哪个，全都没有就落回系统
        // 无衬线，不会出现「装了这个插件文字变成方块」。
        // 只影响 .vcp-app 内部，不外溢到宿主其它界面。
        '.vcp-app{container-type:inline-size;width:100%;height:100%;min-width:0;min-height:0;overflow:hidden;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);font-size:13.5px;line-height:1.75;box-sizing:border-box;--vcp-serif:"Source Han Serif SC","Noto Serif SC","Songti SC",SimSun,Georgia,serif;--vcp-mono:"JetBrains Mono","Cascadia Mono",Consolas,ui-monospace,monospace}',
        // 真正的网格。容器查询的规则全部落在这一层 —— 它是 .vcp-app 的后代。
        '.vcp-split{display:grid;grid-template-columns:236px minmax(0,1fr);height:100%;min-height:0;width:100%;overflow:hidden}',
        '.vcp-rail{display:flex;flex-direction:column;min-width:0;padding:26px 12px 14px;background:var(--dsw-alias-bg-layer-1);border-right:.5px solid var(--dsw-alias-border-l3)}',
        '.vcp-brand{padding:0 10px 24px;min-width:0}',
        '.vcp-brand h1{margin:0;font-family:var(--vcp-serif);font-size:16px;font-weight:600;letter-spacing:.055em;line-height:1.4}',
        '.vcp-brand p{margin:5px 0 0;font-family:var(--vcp-mono);font-size:10px;letter-spacing:.1em;color:var(--dsw-alias-label-tertiary)}',
        '.vcp-nav{display:flex;flex-direction:column;gap:2px}',
        '.vcp-item{display:flex;align-items:center;gap:11px;padding:10px 11px;border:0;border-radius:6px;background:none;color:var(--dsw-alias-label-secondary);font:inherit;font-size:13px;text-align:left;cursor:pointer;min-width:0;transition:background .11s ease,color .11s ease}',
        '.vcp-item:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}',
        '.vcp-item:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:2px}',
        '.vcp-item[aria-current="page"]{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);font-weight:600}',
        '.vcp-item svg{flex:0 0 16px;width:16px;height:16px;opacity:.75}',
        '.vcp-item[aria-current="page"] svg{opacity:1;color:var(--dsw-alias-brand-primary)}',
        '.vcp-item .lbl{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
        '.vcp-item .num{margin-left:auto;font-family:var(--vcp-mono);font-size:10px;font-weight:400;color:var(--dsw-alias-label-tertiary)}',
        '.vcp-foot{margin-top:auto;padding-top:13px;border-top:.5px solid var(--dsw-alias-border-l3)}',
        '.vcp-status{font-family:var(--vcp-mono);font-size:10px;line-height:1.95;color:var(--dsw-alias-label-tertiary);white-space:nowrap;overflow:hidden}',
        '.vcp-status b{font-weight:400;color:var(--dsw-alias-state-success-primary)}',
        '.vcp-main{overflow-y:auto;overflow-x:hidden;min-width:0;height:100%}',
        '.vcp-wrap{max-width:1020px;margin:0 auto;padding:42px 46px 88px}',
        '.vcp-page{display:none}',
        '.vcp-page[data-active="true"]{display:block}',
        '.vcp-he{margin:0 0 40px;max-width:72ch}',
        '.vcp-eb{margin:0 0 11px;font-family:var(--vcp-mono);font-size:10px;letter-spacing:.19em;text-transform:uppercase;color:var(--dsw-alias-brand-primary)}',
        '.vcp-he h2{margin:0;font-family:var(--vcp-serif);font-size:28px;font-weight:600;letter-spacing:-.005em;line-height:1.32}',
        '.vcp-he .vcp-sub{margin:13px 0 0;font-size:13px;line-height:1.85;color:var(--dsw-alias-label-secondary)}',
        '.vcp-acts{margin-top:22px;display:flex;gap:8px;flex-wrap:wrap;align-items:center}',
        '.vcp-btn{font:inherit;font-size:12.5px;line-height:1;padding:9px 16px;cursor:pointer;border-radius:6px;border:.5px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary)}',
        '.vcp-btn:hover{background:var(--dsw-alias-interactive-bg-hover)}',
        '.vcp-btn:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:2px}',
        '.vcp-btn:disabled{opacity:.5;cursor:default}',
        '.vcp-btn.pri{background:var(--dsw-alias-brand-primary);border-color:transparent;color:var(--dsw-alias-label-inverse,#fff);font-weight:600}',
        '.vcp-btn.quiet{background:none;border-color:transparent;color:var(--dsw-alias-label-secondary);padding:9px 10px}',
        '.vcp-btn.quiet:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}',
        // 危险操作。只在删除这类不可逆的地方用 —— 满屏红按钮等于没有重点。
        '.vcp-btn.danger{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}',
        '.vcp-btn.danger:hover{background:var(--dsw-alias-state-error-primary);color:var(--dsw-alias-label-inverse,#fff)}',
        '.vcp-cols{display:grid;grid-template-columns:minmax(0,1fr);gap:40px;align-items:start}',
        '.vcp-sect{display:flex;align-items:baseline;justify-content:space-between;gap:12px;margin:0 0 16px}',
        '.vcp-sect h3{margin:0;font-size:13px;font-weight:600;letter-spacing:.02em}',
        '.vcp-sect .meta{font-size:10.5px;color:var(--dsw-alias-label-tertiary);text-align:right}',
        '.vcp-card{background:var(--dsw-alias-bg-layer-1);border:.5px solid var(--dsw-alias-border-l2);border-radius:10px;padding:20px 18px}',
        '.vcp-card + .vcp-card{margin-top:16px}',
        '.vcp-card-t{margin:0 0 14px;font-size:10px;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--dsw-alias-label-tertiary)}',
        '.vcp-bar{margin-bottom:14px}',
        '.vcp-bar:last-child{margin-bottom:0}',
        '.vcp-bar-lab{display:flex;justify-content:space-between;align-items:baseline;gap:10px;font-size:12px;color:var(--dsw-alias-label-secondary);margin-bottom:6px}',
        '.vcp-bar-lab b{font-family:var(--vcp-mono);font-size:10.5px;font-weight:400;color:var(--dsw-alias-label-tertiary);white-space:nowrap}',
        '.vcp-track{height:5px;border-radius:3px;overflow:hidden;background:var(--dsw-alias-bg-layer-2)}',
        '.vcp-track i{display:block;height:100%;border-radius:3px;background:var(--dsw-alias-brand-primary)}',
        '.vcp-kv{display:flex;justify-content:space-between;gap:12px;padding:9px 0;font-size:12px;border-bottom:.5px solid var(--dsw-alias-border-l3)}',
        '.vcp-kv:last-child{border-bottom:0;padding-bottom:0}',
        '.vcp-kv span{color:var(--dsw-alias-label-tertiary);white-space:nowrap}',
        '.vcp-kv b{font-weight:400;color:var(--dsw-alias-label-secondary);text-align:right;word-break:break-all;font-variant-numeric:tabular-nums}',
        '.vcp-mem{padding:20px 0;border-bottom:.5px solid var(--dsw-alias-border-l3);cursor:pointer}',
        '.vcp-mem:first-of-type{border-top:.5px solid var(--dsw-alias-border-l3)}',
        '.vcp-mem-h{display:flex;align-items:baseline;gap:12px}',
        '.vcp-mem-h h4{margin:0;font-size:13.5px;font-weight:600;line-height:1.55;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
        '.vcp-mem-h time{margin-left:auto;flex:0 0 auto;font-family:var(--vcp-mono);font-size:10.5px;color:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums}',
        '.vcp-mem-ex{margin:8px 0 0;font-size:12.5px;line-height:1.85;max-width:72ch;color:var(--dsw-alias-label-secondary)}',
        '.vcp-mem-meta{margin:10px 0 0;display:flex;gap:16px;flex-wrap:wrap;font-family:var(--vcp-mono);font-size:10.5px;color:var(--dsw-alias-label-tertiary)}',
        '.vcp-mem-more{display:none}',
        '.vcp-mem[data-open="1"] .vcp-mem-more{display:block;margin-top:15px}',
        '.vcp-mem[data-open="1"] .vcp-mem-h h4{color:var(--dsw-alias-brand-primary);white-space:normal}',
        '.vcp-more{background:var(--dsw-alias-bg-layer-2);border-radius:8px;padding:16px 18px}',
        '.vcp-more p{margin:0 0 12px;font-size:12.5px;line-height:1.85;color:var(--dsw-alias-label-secondary)}',
        '.vcp-more p:last-of-type{margin-bottom:0}',
        '.vcp-search{display:flex;gap:9px;margin:0 0 32px;flex-wrap:wrap}',
        '.vcp-search input{flex:1 1 220px;min-width:0;font:inherit;font-size:13.5px;padding:13px 16px;border-radius:8px;border:.5px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary)}',
        '.vcp-search input::placeholder{color:var(--dsw-alias-label-tertiary)}',
        '.vcp-search input:focus{outline:none;border-color:var(--dsw-alias-brand-primary)}',
        '.vcp-hit{padding:18px 0;border-bottom:.5px solid var(--dsw-alias-border-l3)}',
        '.vcp-hit:first-of-type{border-top:.5px solid var(--dsw-alias-border-l3)}',
        '.vcp-hit-top{display:flex;align-items:baseline;gap:11px}',
        '.vcp-rank{flex:0 0 16px;font-family:var(--vcp-mono);font-size:10.5px;color:var(--dsw-alias-brand-primary)}',
        '.vcp-hit-top h4{margin:0;font-size:13px;font-weight:600;min-width:0}',
        '.vcp-score{margin-left:auto;flex:0 0 auto;font-family:var(--vcp-mono);font-size:12px;font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-secondary)}',
        '.vcp-hit p{margin:7px 0 0 27px;font-size:12.5px;line-height:1.85;max-width:68ch;color:var(--dsw-alias-label-secondary)}',
        '.vcp-scores{margin:9px 0 0 27px;display:flex;gap:18px;flex-wrap:wrap;font-family:var(--vcp-mono);font-size:10.5px;color:var(--dsw-alias-label-tertiary)}',
        '.vcp-scores em{font-style:normal;color:var(--dsw-alias-label-secondary)}',
        '.vcp-band{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1px;background:var(--dsw-alias-border-l3);border:.5px solid var(--dsw-alias-border-l2);border-radius:10px;overflow:hidden;margin:0 0 38px}',
        '.vcp-stat{background:var(--dsw-alias-bg-layer-1);padding:20px 18px;min-width:0}',
        '.vcp-stat b{display:block;font-family:var(--vcp-mono);font-size:25px;font-weight:600;letter-spacing:-.025em;line-height:1.15;font-variant-numeric:tabular-nums}',
        '.vcp-stat span{display:block;margin-top:7px;font-size:11px;color:var(--dsw-alias-label-tertiary)}',
        '.vcp-stat .tag{display:inline-block;margin-top:9px;padding:2px 8px;border-radius:20px;font-size:10px;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-state-success-primary)}',
        '.vcp-dir{padding:16px 0;border-bottom:.5px solid var(--dsw-alias-border-l3);display:flex;align-items:baseline;gap:14px;flex-wrap:wrap}',
        '.vcp-dir:first-of-type{border-top:.5px solid var(--dsw-alias-border-l3)}',
        '.vcp-dir .nm{font-size:12.5px;flex:1 1 120px;min-width:0}',
        '.vcp-dir .pt{font-size:10.5px;color:var(--dsw-alias-label-tertiary);word-break:break-all}',
        '.vcp-dir .n1{font-size:11px;margin-left:auto;color:var(--dsw-alias-label-secondary)}',
        '.vcp-dir .n2{font-size:11px;min-width:52px;text-align:right;color:var(--dsw-alias-label-tertiary)}',
        // ---- 设置页：左侧分区导航 + 底部保存栏 ----
        //
        // 设计稿里这块是 `.set-layout` 两栏。**不能用固定像素栅格**：
        // 面板宽度由宿主拖拽决定（300 ~ 视口*0.7），写死宽度必然在
        // 某个档位把输入框挤变形 —— 那正是旧版踩过的坑。
        // 这里用 minmax + 容器查询兜：宽了并排，窄了自动堆成一栏。
        '.vcp-set{display:grid;grid-template-columns:minmax(0,1fr);gap:0}',
        '.vcp-setnav{display:flex;gap:6px;overflow-x:auto;padding:0 0 14px;margin:0 0 22px;border-bottom:.5px solid var(--dsw-alias-border-l3);scrollbar-width:none}',
        '.vcp-setnav::-webkit-scrollbar{display:none}',
        '.vcp-setnav button{flex:0 0 auto;font:inherit;font-size:12px;padding:7px 13px;border-radius:20px;border:.5px solid transparent;background:none;color:var(--dsw-alias-label-tertiary);cursor:pointer;white-space:nowrap}',
        '.vcp-setnav button:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}',
        '.vcp-setnav button[aria-current="true"]{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);font-weight:600}',
        '.vcp-setnav button:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:2px}',
        '.vcp-savebar{position:sticky;bottom:0;display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:12px 0;margin-top:8px;background:var(--dsw-alias-bg-base);border-top:.5px solid var(--dsw-alias-border-l3)}',
        '.vcp-savebar .saved{font-size:11px;color:var(--dsw-alias-label-tertiary);margin-right:auto}',
        '.vcp-savebar .saved[data-dirty="1"]{color:var(--dsw-alias-state-warning-primary)}',
        '.vcp-form{margin:0 0 40px}',
        '.vcp-form > h3{margin:0 0 7px;font-size:14px;font-weight:600}',
        '.vcp-form > .hint{margin:0 0 22px;font-size:12px;line-height:1.8;max-width:66ch;color:var(--dsw-alias-label-tertiary)}',
        '.vcp-field{margin:0 0 22px;max-width:500px}',
        '.vcp-field > label{display:block;font-size:12px;font-weight:600;margin-bottom:7px}',
        '.vcp-field > .desc{display:block;margin:0 0 8px;font-size:11.5px;line-height:1.75;color:var(--dsw-alias-label-tertiary)}',
        '.vcp-field input,.vcp-field select,.vcp-field textarea{width:100%;font:inherit;font-size:12.5px;padding:10px 12px;border-radius:6px;border:.5px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);box-sizing:border-box}',
        '.vcp-field input:focus,.vcp-field select:focus,.vcp-field textarea:focus{outline:none;border-color:var(--dsw-alias-brand-primary)}',
        // 820 以下：侧栏收成纯图标（不占文字宽度），正文让出来。
        // 这是用户说的「窄度压过文字就直接隐藏文字只显示图标」那一档。
        '@container (max-width:819px){.vcp-split{grid-template-columns:56px minmax(0,1fr)}.vcp-rail{padding:20px 6px 12px;align-items:center}.vcp-brand{display:none}.vcp-item{justify-content:center;padding:11px 0;width:100%;gap:0}.vcp-item .lbl,.vcp-item .num{display:none}.vcp-foot{display:none}.vcp-wrap{padding:32px 24px 72px}.vcp-he h2{font-size:24px}.vcp-he{margin-bottom:30px}.vcp-he{max-width:none}}',
        // 600-819：留一点文字宽度不够，但比图标好认 —— 折中成 168px 窄侧栏。
        // 不能只靠上面那条：168px 刚好放得下「召回调试」四个字 + 图标。
        "@container (min-width:820px) and (max-width:1029px){.vcp-split{grid-template-columns:168px minmax(0,1fr)}.vcp-rail{padding:22px 9px 12px}.vcp-brand{padding:0 8px 20px}.vcp-item{gap:9px;padding:9px 9px;font-size:12.5px}.vcp-wrap{padding:36px 30px 80px}}",
        // 420 以下：导航横过来当顶栏，图标 + 文字都保留（横向空间比纵向宽裕）。
        '@container (max-width:419px){.vcp-split{grid-template-columns:minmax(0,1fr);grid-template-rows:auto minmax(0,1fr)}.vcp-rail{flex-direction:row;align-items:center;gap:2px;padding:7px 8px;border-right:0;border-bottom:.5px solid var(--dsw-alias-border-l3);overflow-x:auto}.vcp-nav{flex-direction:row;gap:2px;flex:0 0 auto}.vcp-item{padding:7px 9px;width:auto;gap:6px}.vcp-item .lbl{display:inline;font-size:12px}.vcp-wrap{padding:22px 14px 60px}.vcp-he h2{font-size:20px}.vcp-he{margin-bottom:24px}.vcp-search{margin-bottom:24px}.vcp-search input{flex:1 1 100%}.vcp-search .vcp-btn{width:100%}.vcp-hit p,.vcp-scores{margin-left:0}.vcp-dir .pt{display:none}.vcp-cols{gap:28px}}',
        // 419-599：图标栏但页面留白收紧，正文继续让宽度。
        "@container (min-width:420px) and (max-width:599px){.vcp-wrap{padding:26px 18px 64px}.vcp-he h2{font-size:21px}.vcp-he{margin-bottom:26px}.vcp-search{margin-bottom:26px}.vcp-search input{flex:1 1 100%}.vcp-search .vcp-btn{width:100%}.vcp-hit p,.vcp-scores{margin-left:0}}",
        // 设置页两栏只在「面板够宽」时出现。断点跟 .vcp-cols 同一档，
        // 保证同一个面板宽度下四页的排版节奏一致。
        '@container (min-width:1030px){.vcp-split{grid-template-columns:236px minmax(0,1fr)}.vcp-cols{grid-template-columns:minmax(0,1fr) 272px;gap:40px}.vcp-band{grid-template-columns:1.4fr 1fr 1fr 1fr}.vcp-set{grid-template-columns:150px minmax(0,1fr);gap:36px}.vcp-setnav{flex-direction:column;gap:2px;overflow:visible;position:sticky;top:0;padding:0 0 0 0;margin:0;border-bottom:0}.vcp-setnav button{text-align:left;border-radius:6px;padding:8px 11px;font-size:12.5px}}',
        '@container (min-width:1240px){.vcp-wrap{padding:48px 56px 100px;max-width:1080px}.vcp-he h2{font-size:31px}.vcp-mem{padding:23px 0}.vcp-he{max-width:none}}',
        '@media (prefers-reduced-motion:reduce){.vcp-item,.vcp-btn{transition:none}}',
      ].join('\n')
    }

    function ensureCss() {
      // 运行在真实页面里才注入；测试环境里 document 可能是精简 mock，
      // 这时安静跳过即可 —— 样式不是逻辑，缺了不影响断言。
      if (typeof document === 'undefined') return
      if (typeof document.createElement !== 'function') return
      var head = document.head
      if (!head || typeof head.appendChild !== 'function') return
      try {
        if (typeof document.querySelector === 'function'
          && document.querySelector('style[data-plugin-css="' + CSS_TAG + '"]') !== null) return
        var tag = document.createElement('style')
        if (tag && tag.dataset) tag.dataset.pluginCss = CSS_TAG
        tag.textContent = cssText()
        head.appendChild(tag)
      } catch (error) {
        console.warn('[vcprag] 样式注入失败：', error)
      }
    }

    /** 导航小图标：只描边，跟宿主 nav 视觉一致。 */
    function Icon(props) {
      var kids = []
      if (props.name === 'lib') {
        kids.push(h('rect', { key: 'a', x: 2.6, y: 3.2, width: 4.1, height: 9.6 }))
        kids.push(h('rect', { key: 'b', x: 9.3, y: 3.2, width: 4.1, height: 9.6 }))
        kids.push(h('path', { key: 'c', d: 'M4.3 5.6h1M4.3 8h1M11 5.6h1M11 8h1' }))
      } else if (props.name === 'recall') {
        kids.push(h('circle', { key: 'a', cx: 7, cy: 7, r: 4.1 }))
        kids.push(h('path', { key: 'b', d: 'M10.1 10.1 13.4 13.4' }))
      } else if (props.name === 'index') {
        kids.push(h('path', { key: 'a', d: 'M2.6 13.4V7.2M6.3 13.4V3.6M10 13.4V9.2M13.7 13.4V5.6' }))
      } else {
        kids.push(h('circle', { key: 'a', cx: 8, cy: 8, r: 2.1 }))
        kids.push(h('path', { key: 'b', d: 'M8 1.9v1.5M8 12.6v1.5M1.9 8h1.5M12.6 8h1.5M3.7 3.7l1 1M11.3 11.3l1 1M12.3 3.7l-1 1M4.7 11.3l-1 1' }))
      }
      return h('svg', {
        viewBox: '0 0 16 16',
        fill: 'none',
        stroke: 'currentColor',
        strokeWidth: 1.3,
        'aria-hidden': 'true',
      }, kids)
    }

    var PAGES = [
      { id: 'lib', label: '记忆库', icon: 'lib' },
      { id: 'recall', label: '召回调试', icon: 'recall' },
      { id: 'index', label: '索引', icon: 'index' },
      { id: 'settings', label: '设置', icon: 'settings' },
    ]

    /** 页头：四页共用同一骨架，保证切换时视觉基线不跳。 */
    function PageHead(props) {
      return h('header', { className: 'vcp-he' },
        h('p', { className: 'vcp-eb' }, props.eyebrow),
        h('h2', null, props.title),
        props.sub ? h('p', { className: 'vcp-sub' }, props.sub) : null,
        props.actions && props.actions.length > 0
          ? h('div', { className: 'vcp-acts' }, props.actions)
          : null)
    }

    /** 左导航 + 分页外壳。 */
    function AppShell() {
      ensureCss()

      var pageState = React.useState('lib')
      var active = pageState[0]
      var setActive = pageState[1]

      var statState = React.useState({ docs: null, chunks: null, ready: null })
      var stat = statState[0]
      var setStat = statState[1]

      React.useEffect(function () {
        function refresh() {
          get('/state').then(function (r) {
            if (!r.ok || !r.index) return
            setStat({
              docs: r.index.docCount,
              chunks: r.index.chunkCount,
              ready: r.index.hybridReady === true,
            })
          })
        }
        refresh()
        var timer = setInterval(refresh, 25000)
        return function () { clearInterval(timer) }
      }, [])

      var nav = h('nav', { className: 'vcp-nav', role: 'tablist', 'aria-label': '记忆召回导航' },
        PAGES.map(function (p) {
          var isOn = active === p.id
          return h('button', {
            key: p.id,
            className: 'vcp-item',
            role: 'tab',
            'aria-current': isOn ? 'page' : undefined,
            'aria-selected': isOn ? 'true' : 'false',
            title: p.label,
            onClick: function () { setActive(p.id) },
          },
            h(Icon, { name: p.icon }),
            h('span', { className: 'lbl' }, p.label),
            p.id === 'lib' && stat.docs !== null
              ? h('span', { className: 'num' }, String(stat.docs))
              : null)
        }))

      var rail = h('aside', { className: 'vcp-rail' },
        h('div', { className: 'vcp-brand' },
          h('h1', null, '记忆召回'),
          h('p', null, 'VCPRAG')),
        nav,
        h('div', { className: 'vcp-foot' },
          h('div', { className: 'vcp-status' },
            h('div', null, '索引 ', h('b', null, stat.ready === false ? '● 仅关键词' : '● 就绪')),
            stat.chunks !== null ? h('div', null, String(stat.chunks) + ' 分块') : null)))

      var bodyOf = {
        lib: LibraryPage,
        recall: RecallPage,
        index: IndexPage,
        settings: SettingsPage,
      }

      return h('div', { className: 'vcp-app' },
        h('div', { className: 'vcp-split' },
          rail,
          h('main', { className: 'vcp-main' },
          h('div', { className: 'vcp-wrap' },
            PAGES.map(function (p) {
              var Body = bodyOf[p.id]
              return h('section', {
                key: p.id,
                className: 'vcp-page',
                'data-page': p.id,
                  'data-active': active === p.id ? 'true' : undefined,
                  role: 'tabpanel',
                }, h(Body, null))
              })))))
    }

    //
    // ## 兜底抽屉为什么挂在 shell.overlay
    //
    // 这个槽位活在整个 frame 里，不随会话或主面板卸载，所以「开着面板
    // 切会话」不会把它关掉。position:fixed 靠右，不参与主区域路由。
    // 宽度在这里自己算（宿主那份契约拿不到），照同样的比例取。
    var drawer = {
      open: false,
      listeners: new Set(),
      subscribe: function (fn) {
        drawer.listeners.add(fn)
        return function () { drawer.listeners.delete(fn) }
      },
      set: function (next) {
        if (drawer.open === next) return
        drawer.open = next
        drawer.listeners.forEach(function (fn) {
          try { fn(next) } catch (error) { console.warn('[vcprag] 抽屉监听器抛错', error) }
        })
        syncEntryActive()
      },
      toggle: function () { drawer.set(!drawer.open) },
    }

    /** 抽屉宽度：窄屏按比例收，避免在 1280 宽的小窗里把会话挤没。 */
    function drawerWidth() {
      var vw = (typeof window !== 'undefined' && window.innerWidth) || 1440
      return Math.max(360, Math.min(560, Math.round(vw * 0.34)))
    }

    /**
     * 抽屉本体。挂在 `shell.overlay` 上 —— 这个槽位活在整个 frame 里，
     * 不随会话或主面板卸载，所以「开着抽屉切会话」不会把它关掉。
     */
    function Drawer(props) {
      var st = React.useState(drawer.open)
      var open = st[0]
      var setOpen = st[1]

      React.useEffect(function () {
        return drawer.subscribe(function (next) { setOpen(next) })
      }, [])

      // Esc 关闭：抽屉是覆盖层，用户期望能一键退出来。
      React.useEffect(function () {
        if (!open) return undefined
        function onKey(e) {
          if (e.key === 'Escape') drawer.set(false)
        }
        document.addEventListener('keydown', onKey)
        return function () { document.removeEventListener('keydown', onKey) }
      }, [open])

      if (!open) return null

      var width = drawerWidth()

      var shell = {
        position: 'fixed',
        top: 0,
        right: 0,
        bottom: 0,
        width: width,
        maxWidth: '92vw',
        zIndex: 60,
        display: 'flex',
        flexDirection: 'column',
        background: TOKEN.surface,
        color: TOKEN.label,
        borderLeft: '0.5px solid ' + TOKEN.border2,
        boxShadow: '-18px 0 48px rgba(0, 0, 0, 0.28)',
        fontFamily: 'inherit',
      }

      var head = h('div', {
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          padding: '14px 16px',
          borderBottom: '0.5px solid ' + TOKEN.border,
          flexShrink: 0,
        },
      },
        h('div', { style: { flex: 1, minWidth: 0 } },
          h('div', { style: { fontSize: 14, fontWeight: 700, lineHeight: '20px' } }, '记忆召回'),
          h('div', { style: { fontSize: 11, color: TOKEN.label2 } }, 'vcprag · 日记与语料')),
        h('button', {
          type: 'button',
          title: '关闭（Esc）',
          'aria-label': '关闭记忆召回面板',
          onClick: function () { drawer.set(false) },
          style: {
            font: 'inherit',
            fontSize: 16,
            lineHeight: '20px',
            width: 28,
            height: 28,
            flexShrink: 0,
            cursor: 'pointer',
            borderRadius: 6,
            border: 'none',
            background: 'transparent',
            color: TOKEN.label2,
          },
        }, '×'))

      var body = h('div', {
        style: Object.assign({}, S.page, { flex: 1, minHeight: 0, overflowY: 'auto', padding: '14px 16px 32px' }),
      }, h(AppShell, null))

      return h('div', { style: shell, 'data-dsh-plugin': 'dsh-vcprag', 'data-dsh-part': 'drawer' },
        head,
        body)
    }

    // ---- 左侧入口按钮：DOM 自愈挂载 ----
    //
    // 目标位置是「新建会话」那一行下方（= 会话列表上方）。宿主既没给
    // 这个位置留插槽，也没给锚点，所以只能靠选择器找。选择器全部是
    // mnemon 在真实客户端上验证过的那几个，命中任一即可：
    //
    //   [data-pane="sidebar"]   新版侧栏列
    //   [class*="sidebarCol"]   旧版列
    //   .dshDesktopUpstreamSidebar  桌面端上游侧栏
    //
    // 找不到就什么都不做（并在 body 上监听，等它出现)。

    var ENTRY_ATTR = 'data-dsh-vcprag-entry'
    var ENTRY_TEXT = '记忆召回'
    var entryNode = null

    function sidebarRoot() {
      var column = document.querySelector(
        '[data-pane="sidebar"], [class*="sidebarCol"], .dshDesktopUpstreamSidebar'
      )
      if (column === null) return null
      var logo = column.querySelector('[class*="logoRow"]')
      return (logo && logo.parentElement) || column.firstElementChild
    }

    function newSessionButton(root) {
      var nested = root.querySelector('button[class*="newSession"]')
      if (nested !== null) return nested
      for (var i = 0; i < root.children.length; i += 1) {
        if (root.children[i].tagName === 'BUTTON') return root.children[i]
      }
      return null
    }

    var entryOnOpen = null

    function buildEntry() {
      var btn = document.createElement('button')
      btn.type = 'button'
      btn.setAttribute(ENTRY_ATTR, '')
      btn.setAttribute('aria-label', ENTRY_TEXT)
      btn.title = ENTRY_TEXT
      btn.style.cssText = [
        'display:flex',
        'align-items:center',
        'gap:8px',
        'width:100%',
        'box-sizing:border-box',
        'margin:2px 0 6px',
        'padding:7px 10px',
        'border:0',
        'border-radius:8px',
        'background:transparent',
        'color:inherit',
        'font:inherit',
        'font-size:13px',
        'line-height:18px',
        'text-align:left',
        'cursor:pointer',
      ].join(';')
      var icon = document.createElement('span')
      icon.textContent = '◈'
      icon.style.cssText = 'font-size:14px;line-height:18px;opacity:.75'
      var label = document.createElement('span')
      label.textContent = ENTRY_TEXT
      label.style.cssText = 'flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap'
      btn.appendChild(icon)
      btn.appendChild(label)
      btn.addEventListener('click', function (event) {
        event.preventDefault()
        event.stopPropagation()
        if (typeof entryOnOpen === 'function') entryOnOpen()
        else drawer.toggle()
        // openTab 是同步的，展开态立刻可见；重算一次高亮，否则点击后按钮不变色
        syncEntryActive()
      })
      btn.addEventListener('mouseenter', function () { btn.style.background = TOKEN.hover })
      btn.addEventListener('mouseleave', function () { syncEntryActive() })
      return btn
    }

    /** 面板开着时把入口按钮标成选中态，跟宿主的导航行视觉一致。 */
    function syncEntryActive() {
      if (entryNode === null) return
      var open = drawer.open
      // 走原生右栏时抽屉不用，此时靠 sidebarRight.isExpanded 判断；
      // 拿不到就退化成「不自作主张」，避免按钮永远高亮。
      if (entryOnOpen !== null && typeof entryIsOpen === 'function') {
        try { open = entryIsOpen() } catch { open = drawer.open }
      }
      if (open) {
        entryNode.style.background = TOKEN.surface2
        entryNode.setAttribute('aria-current', 'page')
      } else {
        entryNode.style.background = 'transparent'
        entryNode.removeAttribute('aria-current')
      }
    }

    var entryIsOpen = null

    function placeEntry(root) {
      var anchor = newSessionButton(root)
      if (anchor === null) return false
      var row = anchor.closest('[class*="logoRow"]')
      var base = row !== null && row.parentElement === root ? row : anchor
      var parent = base.parentElement
      if (parent === null) return false
      if (entryNode !== null && entryNode.parentElement === parent) return true
      parent.insertBefore(entryNode, base.nextSibling)
      return true
    }

    function mountSidebarEntry(options) {
      entryOnOpen = options && typeof options.onOpen === 'function' ? options.onOpen : null
      entryIsOpen = options && typeof options.isOpen === 'function' ? options.isOpen : null
      if (entryNode !== null) return
      entryNode = buildEntry()
      syncEntryActive()

      var root = null
      var observer = null

      function tryPlace() {
        if (root !== null && !root.isConnected) {
          root = null
          if (observer !== null) { observer.disconnect(); observer = null }
        }
        if (root !== null && root.contains(entryNode)) return
        root = sidebarRoot()
        if (root === null) return
        if (!placeEntry(root)) return
        if (observer === null) {
          // 侧栏切工作区时会整块重建，节点被摘掉后要能自己回去。
          observer = new MutationObserver(function () {
            if (root === null || !root.isConnected) { root = null; tryPlace(); return }
            if (!root.contains(entryNode)) placeEntry(root)
          })
          observer.observe(root, { childList: true, subtree: true })
        }
      }

      // 侧栏本身可能还没渲染出来，盯着 body 等它出现。
      var waiting = new MutationObserver(tryPlace)
      waiting.observe(document.body, { childList: true, subtree: true })
      tryPlace()
    }

    // ---- DSH client 插件契约：必须是 { name, inject, apply } ----
    // 只 exports 组件是没用的 —— DSH 只认 slots 注册出来的面板。
    // 旧版就是漏了这一步，所以设置页里根本找不到入口。
    exports.name = 'vcprag'
    exports.inject = ['slots', 'sidebarRight', 'sidebarRightTabs']
    exports.apply = function apply(ctx) {
      var disposers = []

      // 注入的服务直接挂在 ctx 上。ctx.get 只作兜底 —— 先 get 后取属性会把
      // 已注入的服务误判成不可用（本轮就是这么静默失效的）。
      function service(name) {
        if (ctx === null || ctx === undefined) return undefined
        if (ctx[name] !== undefined && ctx[name] !== null) return ctx[name]
        if (typeof ctx.get === "function") {
          try { return ctx.get(name) } catch { return undefined }
        }
        return undefined
      }

      var slots = service('slots')
      var sidebarRight = service('sidebarRight')
      var tabs = service('sidebarRightTabs')

      // ---- 不再注册 settings.section ----
      //
      // 0.3.x 时面板挂在「设置 → 插件 → 记忆召回」，0.4.0 起搬进了宿主原生
      // 右侧栏。两个位置都挂着的话，同一个 AppShell 会渲染两遍 —— 用户在
      // 设置页看到一整块和右栏一模一样的界面，分不清哪个才是真的。
      //
      // 所以这里只保留右栏一处入口（左侧栏按钮打开它）。右栏不可用时走
      // 下面的兜底抽屉（shell.overlay），那条路渲染的也是同一个 AppShell，
      // 配置能力一点不少。

      // ---- 注册成宿主原生右侧栏的一个 tab 类型 ----
      //
      // 两步缺一不可，少做一步宿主不报错、也永远不显示：
      //   1. sidebarRightTabs.register  声明「有这么一个 kind」
      //   2. slots.register('sidebar.right.pane.tab', key=id)  提供正文
      var canOpenPane = false
      if (tabs && typeof tabs.register === 'function') {
        try {
          disposers.push(tabs.register({
            id: KIND,
            kind: KIND,
            title: function () { return '记忆召回' },
            priority: 'extension',
          }))
          canOpenPane = true
        } catch (error) {
          console.warn('[vcprag] 右栏 tab 类型注册失败：', error)
        }
      } else {
        console.warn('[vcprag] sidebarRightTabs 不可用，退回自绘抽屉')
      }

      if (canOpenPane && slots) {
        try {
          // 用 slots.inject 包一层：宿主自己的 sidebar-browser 也是这么写的。
          // 直接 register 在槽位尚未声明时会被丢掉，而且不报错。
          if (typeof slots.inject === 'function' && typeof slots.register === 'function') {
            disposers.push(slots.inject('sidebar.right.pane.tab', function () {
              return slots.register(
                { name: 'sidebar.right.pane.tab', key: KIND },
                AppShell,
              )
            }))
          } else {
            disposers.push(slots.register(
              { name: 'sidebar.right.pane.tab', key: KIND },
              AppShell,
            ))
          }
        } catch (error) {
          canOpenPane = false
          console.warn('[vcprag] 右栏正文注册失败：', error)
        }
      }

      // ---- 兜底：右栏不可用时就地画抽屉 ----
      //
      // 这条路径以前是主路径，现在是兜底。留着它的理由很实际：右栏
      // 服务缺失时，点按钮必须还有东西弹出来，不能静默无反应。
      if (!canOpenPane && slots) {
        try {
          if (typeof slots.inject === 'function' && typeof slots.register === 'function') {
            disposers.push(slots.inject('shell.overlay', function () {
              return slots.register({ name: 'shell.overlay', id: 'vcprag', order: 90 }, Drawer)
            }))
          }
        } catch (error) {
          console.warn('[vcprag] 兜底抽屉未挂载：', error)
        }
      }

      // 注册结果写进日志 —— 出问题时先看这一行，比猜快得多。
      console.info('[vcprag] 面板注册：'
        + '右栏tab=' + canOpenPane
        + ' sidebarRight=' + (sidebarRight !== undefined && sidebarRight !== null)
        + ' sidebarRightTabs=' + (tabs !== undefined && tabs !== null)
        + ' slots=' + (slots !== undefined && slots !== null))

      // ---- 左侧原生侧栏里的入口按钮 ----
      // 宿主侧栏会整块重建，MutationObserver 负责补回去。
      if (typeof document !== 'undefined' && typeof MutationObserver === 'function') {
        try {
          mountSidebarEntry({
            onOpen: function openPane() {
            if (canOpenPane && sidebarRight && typeof sidebarRight.openTab === 'function') {
              try {
                sidebarRight.openTab(KIND, {})
                return
              } catch (error) {
                console.warn('[vcprag] 打开右栏失败，回退抽屉：', error)
              }
            }
              drawer.set(true)
            },
            isOpen: function () {
              if (!canOpenPane || !sidebarRight) return drawer.open
              if (typeof sidebarRight.isExpanded === 'function') {
                try { return sidebarRight.isExpanded() === true } catch { return drawer.open }
              }
              return drawer.open
            },
          })
        } catch (error) {
          console.warn('[vcprag] 左侧入口按钮未挂载：', error)
        }
      }

      return function dispose() {
        disposers.forEach(function (fn) { try { fn() } catch { /* 卸载期忽略 */ } })
        if (entryNode !== null) { entryNode.remove(); entryNode = null }
        drawer.set(false)
      }
    }

    // 注意：不要额外导出 `default` / `Panel`。
    // DSH 的 bundle loader 会优先把 `default` 当作 ESM 默认导出，
    // 于是把 React 组件当插件调用 → 返回 React element → 激活失败
    // （web boot: "@local/dsh-vcprag: failed"）。
    // 只导出 name / inject / apply 三件套。
    return module.exports
  },
})
