/** Type surface for the offline session-marker repair tool. */

export const EVENT_TYPE: string
export const MARKER_TEXT: string
export const SINGLETON_LOCK_PATH: string
export function desktopRunning(): boolean
export function singletonOwnerPid(lockPath?: string): number | undefined
export function parseZstdFrames(buffer: Buffer): Buffer[]
export function markLine(line: string): string | null
export interface RepairResult {
  readonly results: readonly { readonly file: string; readonly changed: number; readonly written?: boolean; readonly backupPath?: string }[]
  readonly totals: {
    readonly files: number
    readonly repairedFiles: number
    readonly repairedRows: number
    readonly written: boolean
    readonly backupDir: string | null
  }
}
export function repairSessionEvents(options?: {
  sessionsRoot?: string
  backupRoot?: string
  backupDir?: string
  write?: boolean
  force?: boolean
  isRunning?: () => boolean
}): RepairResult
