import { useEffect, useRef, useState, useSyncExternalStore, type KeyboardEvent, type MouseEvent as ReactMouseEvent, type PointerEvent } from 'react'
import type { WhaleEffect } from './activity.ts'
import { WhalePetService, type WhaleHitZone } from './runtime/whale-pet-service.ts'
import type { WhalePetChat } from './runtime/whale-pet-chat.ts'
import type { WhaleChatOptions, WhaleModelCatalog } from './llm.ts'
import { forgetFact, loadWhaleMemory, rememberFacts, saveWhaleMemory } from './memory.ts'
import {
  browserStorage,
  WHALE_PET_SIZE_MAX,
  WHALE_PET_SIZE_MIN,
  WHALE_PET_SIZE_STEP,
} from './persistence.ts'
import styles from './WhalePet.module.css'

export interface WhalePetProps {
  whalePet: WhalePetService
  /** Optional LLM chat coordinator; adds the "和鲸鲸聊天" menu entry. */
  whalePetChat?: WhalePetChat
}

interface WhaleMenuState {
  x: number
  y: number
}

/** The chat input bubble position (fixed, follows where the menu opened). */
type ChatBoxState = WhaleMenuState

const MENU_WIDTH = 156
const MENU_HEIGHT = 200
/**
 * Inline panels (name, memory, size) are wider than the menu — their CSS
 * min-width plus padding/border — so they carry their own clamp; reusing the
 * menu width would push the ＋ button and the percentage readout off-screen
 * when the menu opens near the right edge.
 */
const PANEL_WIDTH = 264
const PANEL_HEIGHT = 132
/** Ignore the click that browsers fire right after a context menu. */
const CLICK_AFTER_CONTEXT_MENU_MS = 400
/** How long the pet keeps listening after the input loses focus. */
const USER_TYPING_BLUR_DELAY_MS = 800

/** Clamp a fixed-position overlay so a box of the given size stays on screen. */
const clampOverlay = (x: number, y: number, width: number, height: number): WhaleMenuState => ({
  x: Math.max(8, Math.min(x, (window.innerWidth ?? 0) - width - 8)),
  y: Math.max(8, Math.min(y, (window.innerHeight ?? 0) - height - 8)),
})

const isEditableTarget = (target: EventTarget | null): boolean => {
  if (!(target instanceof HTMLElement)) return false
  if (target instanceof HTMLTextAreaElement) return true
  if (target instanceof HTMLInputElement) return true
  return target.isContentEditable
}

/** Cut long display text to a bounded length; the full value rides in `title`. */
const truncate = (text: string, max: number): string => (text.length > max ? `${text.slice(0, max)}…` : text)

/** The frame-wide interactive whale pet surface (view only). */
export function WhalePet({ whalePet, whalePetChat }: WhalePetProps): React.ReactElement {
  const rootRef = useRef<HTMLDivElement | null>(null)
  const petRef = useRef<HTMLDivElement | null>(null)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const shadowRef = useRef<HTMLSpanElement | null>(null)
  const chatBoxRef = useRef<HTMLDivElement | null>(null)
  const memoryBoxRef = useRef<HTMLDivElement | null>(null)
  const nameBoxRef = useRef<HTMLDivElement | null>(null)
  const sizeBoxRef = useRef<HTMLDivElement | null>(null)
  const lastContextMenuAt = useRef(0)
  const [error, setError] = useState('')
  const [menu, setMenu] = useState<WhaleMenuState | null>(null)
  const [chatBox, setChatBox] = useState<ChatBoxState | null>(null)
  const [chatText, setChatText] = useState('')
  const [memoryBox, setMemoryBox] = useState<WhaleMenuState | null>(null)
  const [memoryFacts, setMemoryFacts] = useState<string[]>([])
  const [memoryDraft, setMemoryDraft] = useState('')
  const [nameBox, setNameBox] = useState<WhaleMenuState | null>(null)
  const [nameDraft, setNameDraft] = useState('')
  const [sizeBox, setSizeBox] = useState<WhaleMenuState | null>(null)
  const [catalog, setCatalog] = useState<WhaleModelCatalog | null>(null)
  const [catalogError, setCatalogError] = useState('')
  const [modelKey, setModelKey] = useState('')
  const [effort, setEffort] = useState('')

  const snapshot = useSyncExternalStore(
    onChange => whalePet.subscribe(onChange),
    () => whalePet.getSnapshot(),
  )

  useEffect(() => {
    const root = rootRef.current
    const pet = petRef.current
    const canvas = canvasRef.current
    const shadow = shadowRef.current
    if (root === null || pet === null || canvas === null || shadow === null) return

    const started = whalePet.mount(
      { root, pet, canvas, shadow },
      {
        onError: setError,
        onRelease: (x, y) => whalePet.persistPosition(x, y),
      },
    )
    if (!started) return

    return () => {
      whalePet.unmount()
    }
  }, [whalePet])

  // Close the context menu on outside clicks, Escape, or window blur.
  useEffect(() => {
    if (menu === null) return
    const close = (): void => setMenu(null)
    const onKey = (event: globalThis.KeyboardEvent): void => {
      if (event.key === 'Escape') close()
    }
    document.addEventListener('click', close)
    document.addEventListener('keydown', onKey)
    window.addEventListener('blur', close)
    return () => {
      document.removeEventListener('click', close)
      document.removeEventListener('keydown', onKey)
      window.removeEventListener('blur', close)
    }
  }, [menu])

  // The chat bubble closes on outside presses or Escape.
  //
  // Listens to `mousedown` instead of `click` on purpose: the menu item that
  // opens the bubble dispatches a click, and React may flush the bubble into
  // the DOM before that same click finishes bubbling to document (React 18
  // flushes discrete events synchronously in real browsers). A click-based
  // closer would then treat the menu-item click as an outside click and close
  // the bubble the instant it opens.
  useEffect(() => {
    if (chatBox === null) return
    const close = (event: MouseEvent): void => {
      const target = event.target
      if (target instanceof Node && chatBoxRef.current !== null && chatBoxRef.current.contains(target)) return
      setChatBox(null)
    }
    const onKey = (event: globalThis.KeyboardEvent): void => {
      if (event.key === 'Escape') setChatBox(null)
    }
    document.addEventListener('mousedown', close)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', close)
      document.removeEventListener('keydown', onKey)
    }
  }, [chatBox])

  // The memory panel closes on outside presses or Escape, mirroring the chat
  // bubble (mousedown, so the opening menu-item click never closes it).
  useEffect(() => {
    if (memoryBox === null) return
    const close = (event: MouseEvent): void => {
      const target = event.target
      if (target instanceof Node && memoryBoxRef.current !== null && memoryBoxRef.current.contains(target)) return
      setMemoryBox(null)
    }
    const onKey = (event: globalThis.KeyboardEvent): void => {
      if (event.key === 'Escape') setMemoryBox(null)
    }
    document.addEventListener('mousedown', close)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', close)
      document.removeEventListener('keydown', onKey)
    }
  }, [memoryBox])

  // The naming panel closes on outside presses or Escape, mirroring the other
  // inline panels (mousedown, so the opening menu-item click never closes it).
  //
  // This panel exists because `window.prompt` is not implemented by Electron:
  // the desktop shell logs "prompt() is and will not be supported" and never
  // shows a dialog, which made the "命名…" menu entry look dead.
  useEffect(() => {
    if (nameBox === null) return
    const close = (event: MouseEvent): void => {
      const target = event.target
      if (target instanceof Node && nameBoxRef.current !== null && nameBoxRef.current.contains(target)) return
      setNameBox(null)
    }
    const onKey = (event: globalThis.KeyboardEvent): void => {
      if (event.key === 'Escape') setNameBox(null)
    }
    document.addEventListener('mousedown', close)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', close)
      document.removeEventListener('keydown', onKey)
    }
  }, [nameBox])

  // The size panel closes on outside presses or Escape, mirroring the other
  // inline panels (mousedown, so the opening menu-item click never closes it).
  useEffect(() => {
    if (sizeBox === null) return
    const close = (event: MouseEvent): void => {
      const target = event.target
      if (target instanceof Node && sizeBoxRef.current !== null && sizeBoxRef.current.contains(target)) return
      setSizeBox(null)
    }
    const onKey = (event: globalThis.KeyboardEvent): void => {
      if (event.key === 'Escape') setSizeBox(null)
    }
    document.addEventListener('mousedown', close)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', close)
      document.removeEventListener('keydown', onKey)
    }
  }, [sizeBox])

  // Load the model catalog (and the persisted selection) when the bubble opens.
  useEffect(() => {
    if (chatBox === null || whalePetChat === undefined) return
    let cancelled = false
    const prefs = whalePetChat.getPreferences()
    if (prefs !== null) {
      setModelKey(`${prefs.provider}::${prefs.model}`)
      if (prefs.effort !== undefined) setEffort(prefs.effort)
    }
    whalePetChat.listModels()
      .then(next => {
        if (cancelled) return
        setCatalog(next)
        setModelKey(current => {
          if (current !== '') {
            const stillThere = next.providers.some(provider => provider.models.some(model => `${provider.id}::${model.id}` === current))
            if (stillThere) return current
          }
          return `${next.default.provider}::${next.default.model}`
        })
      })
      .catch(() => {
        if (!cancelled) setCatalogError('模型列表加载失败')
      })
    return () => {
      cancelled = true
    }
  }, [chatBox, whalePetChat])

  // Keep the effort selection valid for the currently chosen model.
  useEffect(() => {
    if (catalog === null || modelKey === '') return
    const [provider, model] = modelKey.split('::')
    const entry = catalog.providers.find(candidate => candidate.id === provider)?.models.find(candidate => candidate.id === model)
    if (entry === undefined || entry.efforts.length === 0) {
      setEffort('')
      return
    }
    setEffort(current => (current !== '' && entry.efforts.some(candidate => candidate.id === current) ? current : entry.defaultEffort ?? ''))
  }, [catalog, modelKey])

  // The pet listens (floating "？") only while the user is composing a reply
  // in the chat input; a short grace period avoids flicker when focus moves
  // between the input and its toolbar.
  useEffect(() => {
    let blurTimer: ReturnType<typeof setTimeout> | null = null
    const onFocusIn = (event: globalThis.FocusEvent): void => {
      if (!isEditableTarget(event.target)) return
      if (blurTimer !== null) {
        clearTimeout(blurTimer)
        blurTimer = null
      }
      whalePet.setUserTyping(true)
    }
    const onFocusOut = (): void => {
      if (blurTimer !== null) clearTimeout(blurTimer)
      blurTimer = setTimeout(() => {
        whalePet.setUserTyping(false)
      }, USER_TYPING_BLUR_DELAY_MS)
    }
    document.addEventListener('focusin', onFocusIn, true)
    document.addEventListener('focusout', onFocusOut, true)
    return () => {
      if (blurTimer !== null) clearTimeout(blurTimer)
      document.removeEventListener('focusin', onFocusIn, true)
      document.removeEventListener('focusout', onFocusOut, true)
    }
  }, [whalePet])

  const isPetDescendant = (target: EventTarget | null): boolean => {
    const pet = petRef.current
    return target instanceof Node && pet !== null && pet.contains(target)
  }

  const react = (): void => {
    whalePet.playEffect('heart')
  }

  const pointerEnter = (event: PointerEvent<HTMLElement>): void => {
    if (whalePet.isDizzy() || isPetDescendant(event.relatedTarget)) return
    whalePet.wake()
    whalePet.setHover(true)
    react()
  }

  const pointerLeave = (event: PointerEvent<HTMLElement>): void => {
    if (isPetDescendant(event.relatedTarget)) return
    whalePet.setHover(false)
  }

  const pointerDown = (event: PointerEvent<HTMLElement>): void => {
    event.preventDefault()
    event.stopPropagation()
    if (whalePet.isDizzy()) return
    event.currentTarget.setPointerCapture(event.pointerId)
    whalePet.wake()
    whalePet.beginDrag(event.clientX, event.clientY, event.timeStamp)
  }

  const clickZone = (zone: WhaleHitZone) => (event: ReactMouseEvent<HTMLElement>): void => {
    event.stopPropagation()
    if (whalePet.isDizzy()) return
    if (Date.now() - lastContextMenuAt.current < CLICK_AFTER_CONTEXT_MENU_MS) return
    if (whalePet.handleZoneClick(zone)) return
    if (whalePet.wasClick() === true) {
      // While the agent is busy, a click reports live progress ("正在跑
      // bash，已经 3 分钟") instead of cycling the recap history. The coarse
      // line shows instantly, then the fine-grained probe (event log + jobs
      // registry) upgrades the bubble when it differs.
      const progressText = whalePetChat?.getProgressText() ?? null
      if (progressText !== null) {
        whalePet.showBubble(progressText, 6_000)
        void whalePetChat?.refreshProgressBubble()
      } else {
        whalePet.nextRecap()
      }
    }
  }

  const openMenu = (event: ReactMouseEvent<HTMLElement>): void => {
    event.preventDefault()
    event.stopPropagation()
    if (whalePet.isDizzy()) return
    lastContextMenuAt.current = Date.now()
    setMenu(clampOverlay(event.clientX, event.clientY, MENU_WIDTH, MENU_HEIGHT))
  }

  // Open the inline naming panel. `window.prompt` is unavailable in the
  // Electron desktop shell, so the rename flow owns its own input.
  const rename = (): void => {
    if (menu === null) return
    setChatBox(null)
    setMemoryBox(null)
    setSizeBox(null)
    setNameDraft(snapshot.name)
    setNameBox(clampOverlay(menu.x, menu.y, PANEL_WIDTH, PANEL_HEIGHT))
  }

  const confirmRename = (): void => {
    if (nameBox === null) return
    const next = nameDraft.trim()
    if (next !== '') whalePet.setName(next)
    setNameBox(null)
  }

  const chat = (): void => {
    if (whalePetChat === undefined || menu === null) return
    setMemoryBox(null)
    setNameBox(null)
    setSizeBox(null)
    setChatBox({ x: menu.x, y: menu.y })
    setChatText('')
    setCatalogError('')
  }

  const openMemory = (): void => {
    if (menu === null) return
    setChatBox(null)
    setNameBox(null)
    setSizeBox(null)
    setMemoryBox(clampOverlay(menu.x, menu.y, PANEL_WIDTH, PANEL_HEIGHT))
    setMemoryFacts(loadWhaleMemory(browserStorage()).facts)
    setMemoryDraft('')
  }

  // Open the inline size control. Sizing is render-only: the value scales the
  // pet box after its translation/rotation, so the motion path is untouched.
  const openSize = (): void => {
    if (menu === null) return
    setChatBox(null)
    setMemoryBox(null)
    setNameBox(null)
    setSizeBox(clampOverlay(menu.x, menu.y, PANEL_WIDTH, PANEL_HEIGHT))
  }

  const remember = (): void => {
    const fact = memoryDraft.trim()
    if (fact === '') return
    const storage = browserStorage()
    const next = rememberFacts(loadWhaleMemory(storage), [fact])
    saveWhaleMemory(storage, next)
    setMemoryFacts(next.facts)
    setMemoryDraft('')
  }

  const forget = (fact: string): void => {
    const storage = browserStorage()
    const next = forgetFact(loadWhaleMemory(storage), fact)
    saveWhaleMemory(storage, next)
    setMemoryFacts(next.facts)
  }

  const sendChat = (): void => {
    const text = chatText.trim()
    if (text === '' || whalePetChat === undefined) return
    const [provider, model] = modelKey.split('::')
    const options: WhaleChatOptions = {}
    if (provider !== undefined && provider !== '' && model !== undefined && model !== '') {
      options.provider = provider
      options.model = model
      if (effort !== '') options.effort = effort
      whalePetChat.setPreferences({ provider, model, ...(effort !== '' ? { effort } : {}) })
    }
    setChatText('')
    setChatBox(null)
    void whalePetChat.ask(text, options)
  }

  const keyDown = (event: KeyboardEvent<HTMLButtonElement>): void => {
    if (event.key !== 'Enter' && event.key !== ' ') return
    event.preventDefault()
    whalePet.nextRecap()
  }

  const zoneEvents = (zone: WhaleHitZone) => ({
    onPointerEnter: pointerEnter,
    onPointerLeave: pointerLeave,
    onPointerDown: pointerDown,
    onClick: clickZone(zone),
    onContextMenu: openMenu,
  })
  const sleeping = snapshot.activity.mood === 'sleeping'
  const dizzy = snapshot.activity.mood === 'dizzy'
  const listening = snapshot.activity.mood === 'listening' || snapshot.activity.mood === 'awaiting'
  const hearts = snapshot.effects.filter(effect => effect.kind === 'heart')
  const bubbles = snapshot.effects.filter(effect => effect.kind === 'bubble')
  const sweat = snapshot.effects.filter(effect => effect.kind === 'sweat')

  return (
    <div
      ref={rootRef}
      className={`${styles.layer}${snapshot.hidden ? ` ${styles.hidden}` : ''}`}
      style={{ pointerEvents: 'none' }}
    >
      <div
        ref={petRef}
        className={styles.pet}
        data-whale-activity={snapshot.activity.mood}
        data-whale-bridge={snapshot.bridge}
        data-whale-size={Math.round(snapshot.size * 100)}
      >
        <span ref={shadowRef} className={styles.shadow} aria-hidden="true" />
        <canvas ref={canvasRef} className={styles.canvas} aria-hidden="true" />
        <button
          type="button"
          className={`${styles.hitZone} ${styles.hitBody}`}
          aria-label="DeepSeek 3D whale pet"
          onKeyDown={keyDown}
          {...zoneEvents('body')}
        />
        <div className={`${styles.hitZone} ${styles.hitTail}`} aria-hidden="true" {...zoneEvents('tail')} />
        <div className={`${styles.hitZone} ${styles.hitDorsal}`} aria-hidden="true" {...zoneEvents('dorsal')} />
        <div className={`${styles.hitZone} ${styles.hitFin}`} aria-hidden="true" {...zoneEvents('fin')} />
        {snapshot.recap !== null ? (
          <div key={snapshot.recap.id} className={styles.speech} role="status">
            {snapshot.recap.text}
          </div>
        ) : null}
        {listening ? <span className={styles.listeningMark} aria-hidden="true">？</span> : null}
        {snapshot.activity.mood === 'error' ? <span className={styles.errorMark} aria-hidden="true">！</span> : null}
        {error === '' ? null : <div className={styles.error}>{error}</div>}
        {hearts.map(heart => (
          <HeartPair key={heart.id} id={heart.id} />
        ))}
        {bubbles.map(bubble => (
          <span
            key={bubble.id}
            className={styles.bubble}
            style={{
              left: `${bubble.origin?.x ?? 42}px`,
              top: `${bubble.origin?.y ?? 74}px`,
              '--bubble-drift': `${((bubble.id % 3) - 1) * 12}px`,
              '--bubble-scale': `${0.8 + (bubble.id % 3) * 0.2}`,
            } as React.CSSProperties}
            aria-hidden="true"
          />
        ))}
        {sweat.map(drop => (
          <span key={drop.id} className={styles.sweat} aria-hidden="true">💧</span>
        ))}
        {dizzy ? (
          <span className={styles.dizzyOrbit} aria-hidden="true">
            <span className={`${styles.dizzyStar} ${styles.dizzyStarOne}`}>★</span>
            <span className={`${styles.dizzyStar} ${styles.dizzyStarTwo}`}>★</span>
            <span className={`${styles.dizzyStar} ${styles.dizzyStarThree}`}>★</span>
          </span>
        ) : null}
        {sleeping ? (
          <>
            <span key="zzz-1" className={`${styles.sleepMark} ${styles.sleepMarkOne}`} aria-hidden="true">z</span>
            <span key="zzz-2" className={`${styles.sleepMark} ${styles.sleepMarkTwo}`} aria-hidden="true">Z</span>
            <span key="zzz-3" className={`${styles.sleepMark} ${styles.sleepMarkThree}`} aria-hidden="true">Z</span>
          </>
        ) : null}
      </div>
      {menu !== null ? (
        <div className={styles.menu} style={{ left: menu.x, top: menu.y }} role="menu" aria-label="鲸鲸菜单">
          {whalePetChat !== undefined ? (
            <button
              type="button"
              className={styles.menuItem}
              onClick={() => { setMenu(null); chat() }}
            >
              和鲸鲸聊天…
            </button>
          ) : null}
          <button
            type="button"
            className={styles.menuItem}
            onClick={() => { setMenu(null); openMemory() }}
          >
            鲸鲸记得什么…
          </button>
          <button type="button" className={styles.menuItem} onClick={() => { setMenu(null); rename() }}>命名…</button>
          <button
            type="button"
            className={styles.menuItem}
            onClick={() => { setMenu(null); openSize() }}
          >
            {`调整大小…（${Math.round(snapshot.size * 100)}%）`}
          </button>
          <button
            type="button"
            className={styles.menuItem}
            onClick={() => { setMenu(null); whalePet.setSnapToCorner(!snapshot.snapToCorner) }}
          >
            {snapshot.snapToCorner ? '关闭角落吸附' : '开启角落吸附'}
          </button>
          <button type="button" className={styles.menuItem} onClick={() => { setMenu(null); whalePet.snapToCornerNow() }}>回到角落</button>
          <button type="button" className={styles.menuItem} onClick={() => { setMenu(null); whalePet.setHidden(true) }}>隐藏（Ctrl+Alt+W 恢复）</button>
        </div>
      ) : null}
      {chatBox !== null ? (
        <div
          ref={chatBoxRef}
          className={styles.chatBox}
          style={{ left: chatBox.x, top: chatBox.y }}
          role="dialog"
          aria-label="和鲸鲸聊天"
          data-whale-chat="open"
        >
          <div className={styles.chatRow}>
            <select
              className={styles.chatSelect}
              value={modelKey}
              aria-label="选择模型"
              disabled={catalog === null && catalogError === ''}
              onChange={event => setModelKey(event.target.value)}
            >
              {catalog === null ? (
                <option value="">{catalogError === '' ? '加载模型…' : '模型不可用'}</option>
              ) : (
                catalog.providers.flatMap(provider =>
                  provider.models.map(model => (
                    <option key={`${provider.id}::${model.id}`} value={`${provider.id}::${model.id}`}>
                      {provider.name} · {model.name}
                    </option>
                  )),
                )
              )}
            </select>
            {(() => {
              const [provider, model] = modelKey.split('::')
              const entry = catalog?.providers.find(candidate => candidate.id === provider)?.models.find(candidate => candidate.id === model)
              if (entry === undefined || entry.efforts.length === 0) return null
              return (
                <select
                  className={styles.chatSelect}
                  value={effort}
                  aria-label="思考强度"
                  onChange={event => setEffort(event.target.value)}
                >
                  <option value="">默认</option>
                  {entry.efforts.map(candidate => (
                    <option key={candidate.id} value={candidate.id}>{candidate.name}</option>
                  ))}
                </select>
              )
            })()}
          </div>
          <div className={styles.chatRow}>
            <input
              className={styles.chatInput}
              value={chatText}
              autoFocus
              maxLength={200}
              placeholder="对鲸鲸说…"
              onChange={event => setChatText(event.target.value)}
              onKeyDown={event => {
                if (event.key === 'Enter') sendChat()
                if (event.key === 'Escape') setChatBox(null)
              }}
            />
            <button
              type="button"
              className={styles.chatSend}
              disabled={chatText.trim() === ''}
              onClick={sendChat}
            >
              发送
            </button>
          </div>
        </div>
      ) : null}
      {memoryBox !== null ? (
        <div
          ref={memoryBoxRef}
          className={styles.memoryBox}
          style={{ left: memoryBox.x, top: memoryBox.y }}
          role="dialog"
          aria-label="鲸鲸记得什么"
          data-whale-memory="open"
        >
          <div className={styles.memoryTitle}>鲸鲸记得什么</div>
          {memoryFacts.length === 0 ? (
            <div className={styles.memoryEmpty}>还没有关于你的记忆。说「我叫… / 我喜欢…」或在下面写一条。</div>
          ) : (
            <ul className={styles.memoryList}>
              {memoryFacts.map(fact => (
                <li key={fact} className={styles.memoryItem}>
                  <span className={styles.memoryFact} title={fact}>{truncate(fact, 80)}</span>
                  <button
                    type="button"
                    className={styles.memoryDelete}
                    aria-label={`忘记：${fact}`}
                    onClick={() => forget(fact)}
                  >
                    删除
                  </button>
                </li>
              ))}
            </ul>
          )}
          <div className={styles.memoryAddRow}>
            <input
              className={styles.memoryInput}
              value={memoryDraft}
              maxLength={80}
              placeholder="记一条…"
              onChange={event => setMemoryDraft(event.target.value)}
              onKeyDown={event => {
                if (event.key === 'Enter') remember()
              }}
            />
            <button
              type="button"
              className={styles.memoryAdd}
              disabled={memoryDraft.trim() === ''}
              onClick={remember}
            >
              记住
            </button>
          </div>
        </div>
      ) : null}
      {nameBox !== null ? (
        <div
          ref={nameBoxRef}
          className={styles.nameBox}
          style={{ left: nameBox.x, top: nameBox.y }}
          role="dialog"
          aria-label="给鲸鲸命名"
          data-whale-name="open"
        >
          <div className={styles.nameTitle}>给鲸鲸起个新名字</div>
          <div className={styles.nameRow}>
            <input
              className={styles.nameInput}
              value={nameDraft}
              autoFocus
              maxLength={32}
              placeholder="新的名字…"
              aria-label="鲸鲸的名字"
              onChange={event => setNameDraft(event.target.value)}
              onKeyDown={event => {
                if (event.key === 'Enter') confirmRename()
                if (event.key === 'Escape') setNameBox(null)
              }}
            />
            <button
              type="button"
              className={styles.nameConfirm}
              disabled={nameDraft.trim() === ''}
              onClick={confirmRename}
            >
              确定
            </button>
          </div>
        </div>
      ) : null}
      {sizeBox !== null ? (
        <div
          ref={sizeBoxRef}
          className={styles.sizeBox}
          style={{ left: sizeBox.x, top: sizeBox.y }}
          role="dialog"
          aria-label="调整鲸鲸大小"
          data-whale-size-panel="open"
        >
          <div className={styles.sizeTitle}>鲸鲸大小</div>
          <div className={styles.sizeRow}>
            <button
              type="button"
              className={styles.sizeStep}
              aria-label="缩小鲸鲸"
              disabled={snapshot.size <= WHALE_PET_SIZE_MIN}
              onClick={() => whalePet.setSize(snapshot.size - WHALE_PET_SIZE_STEP)}
            >
              −
            </button>
            <input
              type="range"
              className={styles.sizeSlider}
              aria-label="鲸鲸大小"
              autoFocus
              min={Math.round(WHALE_PET_SIZE_MIN * 100)}
              max={Math.round(WHALE_PET_SIZE_MAX * 100)}
              step={Math.round(WHALE_PET_SIZE_STEP * 100)}
              value={Math.round(snapshot.size * 100)}
              onChange={event => whalePet.setSize(Number(event.target.value) / 100)}
            />
            <button
              type="button"
              className={styles.sizeStep}
              aria-label="放大鲸鲸"
              disabled={snapshot.size >= WHALE_PET_SIZE_MAX}
              onClick={() => whalePet.setSize(snapshot.size + WHALE_PET_SIZE_STEP)}
            >
              ＋
            </button>
            <span className={styles.sizeValue}>{Math.round(snapshot.size * 100)}%</span>
          </div>
          <button
            type="button"
            className={styles.sizeReset}
            disabled={snapshot.size === 1}
            onClick={() => whalePet.setSize(1)}
          >
            恢复默认大小（100%）
          </button>
        </div>
      ) : null}
    </div>
  )
}

function HeartPair({ id }: { id: number }): React.ReactElement {
  return (
    <>
      <span key={`${id}-left`} className={`${styles.heart} ${styles.heartLeft}`} aria-hidden="true">♥</span>
      <span key={`${id}-right`} className={`${styles.heart} ${styles.heartRight}`} aria-hidden="true">♥</span>
    </>
  )
}

export type { WhaleEffect }
