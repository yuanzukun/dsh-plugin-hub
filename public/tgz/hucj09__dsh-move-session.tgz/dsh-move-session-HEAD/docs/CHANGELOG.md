# Changelog

`@hucj/dsh-move-session` 版本历史与发布记录（维护者视角；使用者文档见 README.md）。

仓库：https://github.com/hucj09/dsh-move-session
发布渠道：npm（官方源）+ GitHub（main + tag v0.1.x）

---

## v0.1.3（2026-08-16 · 待发布）

重新发布（无功能改动）：

- **许可证改为 MIT**：`LICENSE` 全文、`package.json.license`、双语 README 同步（此前为 BSD-3-Clause）
- **发布物清理**：README 安装示例不再出现本地路径（`link:/path/to/dsh-move-session` 占位符）；
  Playwright 测试脚本 React UMD 路径改 `~` 动态解析（消除 `C:\Users\hu` 硬编码）
- 因 v0.1.2 tarball 快照仍含旧 README/许可信息，故递增版本重新发布

## v0.1.2（2026-08-16 · 已发布）

修复「打开迁移后的会话」按钮失效（keep 模式成功面板）：

- **根因**：成功面板「打开迁移后的会话」onClick 先 `setState({ open: false, done: null, ... })`
  再读 `dialog.done.sessionId`——`dialog` 是模块级 state 对象的**同一引用**，此时 `done` 已被置
  null，读取抛 TypeError，`openSession` 从未执行，视图停留在原会话；归档模式自动跳转读
  `result.sessionId`（不经共享 state）故不受影响
- **修复**：先 `var doneSessionId = dialog.done.sessionId` 缓存 id，再清空状态，最后
  `openSession(doneSessionId, ...)`
- **回归防护**：`test/client.bundle.test.js` 新增结构用例（断言 onClick 内 `done.sessionId`
  读取必须先于 `setState({ open: false, done: null, ... })`，`node --test` 55 用例全绿）；
  Playwright 新增 keep 模式成功面板端到端场景（提交 → 成功面板 → 点击打开 →
  `window.__openCalls` 含新会话 id 且对话框关闭，且 keep 模式不会自动跳转）

## v0.1.1（2026-08-16 · 未单独发布，并入 v0.1.2）

发布前修复与增强批次：

- **目标目录预检**：迁移创建副本前用宿主 `fs` 服务校验目标工作区目录真实存在（失效注册如
  Temp 目录被清理 → `target-missing-dir`，在任何写入前拒绝，不产生孤儿副本）
- **行菜单注入仅限会话行**：工作区行操作菜单不再注入「迁移会话」——点击捕获记录行类型
  （fiber 无 `node.id` 即工作区行）+ 菜单判定排除工作区菜单双保险；顺带修复 fiber 链遍历
  的 `undefined` 判空（`!= null`）
- **行菜单注入项运行中禁用**：从会话行 fiber 的 `node.running` 读取运行状态，运行中会话的
  「迁移会话」菜单项置灰并带提示（与顶部按钮禁用逻辑一致）
- **弹窗明暗主题跟随**：GUI 无 `--surface/--text-*` 变量，改为读取 body 背景亮度判定明暗，
  自有调色板发布为 `--dsh-ms-*` 变量；rAF 降频轮询跟随主题切换 + 弹窗每次打开时同步刷新
- **副标题当前会话前缀**：弹窗副标题显示「当前会话：{标题}」（Current session: {title}，双语）
- **同名会话区分**：仅当目标工作区存在同名会话时，副本标题追加 `[MS<n>]`（如 `我的会话 [MS1]`，
  `n` 为目标区已有标记最大值 + 1，重复迁移递增不冲突；已带标记副本再迁移时替换而非累积；
  无同名保持原标题）。与分叉数字后缀 ` (1)`/`（1）` 不同；目标工作区列表独立滚动
  （max-height 240px，工作区过多时头部与操作按钮保持固定）
- **测试**：`node --test` 54 用例；Playwright 交互测试（对话框 + 行菜单注入 + 主题跟随）

## v0.1.0（2026-08-16 · 未单独发布，并入 v0.1.1）

首个版本：跨工作区会话迁移插件（dsh Web GUI）。

- **功能**：会话头部操作行「迁移会话」按钮（图标+文字，中英双语）；侧边栏会话行「…」菜单注入
  「迁移会话」项（正式安装版）；目标工作区单选 + 保留/归档原会话单选（默认保留）；仅空闲会话可迁移。
- **迁移语义**：完整事件日志逐事件复制（消息、工具调用、chunk 流、标题、预设选择、模型选择），
  新会话 id + `parentSession` 血缘；副本经 `agents.create` 发布为 live（官方分叉同路径），
  跨标签页即时刷新（`host/session-added` / `host/workspace-changed` / `host/archived-sessions-changed`）。
- **架构**：双端零依赖纯 JS 包（`lib/index.js` 宿主 + `lib/client.js` 浏览器 bundle，源码即产物），
  热插拔挂载（`cordis.patch.yml`），不改 dsh 源码。
- **自定义图标**：用户提供的填充式 SVG（文件夹+移动箭头），`fill="currentColor"` 适配明暗主题。
- **UI 修复历程**（动态演示迭代）：React store force 函数式更新（修复取消无效/弹框无法重开的
  bailout 事故）；close 无条件；默认保留原会话；按钮颜色改 inherit+opacity（GUI 无
  `--text-secondary` 变量）。
- **目标目录预检**（发布前修复）：迁移创建副本前用宿主 `fs` 服务校验目标工作区目录真实存在
  （失效注册如 Temp 目录被清理 → `target-missing-dir`，在任何写入前拒绝，不产生孤儿副本）。
- **行菜单注入仅限会话行**（发布前修复）：工作区行操作菜单（含"重命名工作区/删除工作区"）不再
  注入「迁移会话」——点击捕获记录行类型（fiber 无 `node.id` 即工作区行）+ 菜单判定排除工作区菜单
  双保险；顺带修复 fiber 链遍历的 `undefined` 判空（`!= null`）。
- **行菜单注入项运行中禁用**（发布前修复）：从会话行 fiber 的 `node.running` 读取运行状态，
  运行中的会话其「迁移会话」菜单项置灰并带提示（与顶部按钮禁用逻辑一致）。
- **弹窗明暗主题跟随**（发布前新增）：GUI 无 `--surface/--text-*` 变量，改为读取 body 背景
  亮度判定明暗，将自有调色板发布为 `--dsh-ms-*` 变量；rAF 降频轮询跟随主题切换（MutationObserver
  debounce 与 setInterval 在 headless 下经实测不稳定）+ 弹窗每次打开时同步刷新，深浅两套
  调色板（背景/文字/边框/主色/错误色/阴影）。
- **测试**：`node --test` 41 用例（宿主 `moveSession` 全契约 + 客户端结构不变量）；
  Playwright 交互测试（对话框 + 行菜单注入 + 主题跟随）；真实迁移日志逐事件一致性校验（Python）。
- **验证**：真实迁移数据逐事件对比——源 1042 事件 + 212 chunk 记录 100% 保留。
