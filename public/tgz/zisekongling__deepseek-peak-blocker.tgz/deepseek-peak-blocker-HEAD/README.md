# deepseek-peak-blocker

DSH（DeepSeek Harness）插件：**DeepSeek 官方 API 高峰时段智能管控**。

在高峰时段（北京时间，UTC+8）对发往 DeepSeek 官方 API 的新请求进行**友好拦截与询问**，实时监控时段切换并对进行中的对话发出**非阻塞提醒**，提供**全局状态面板**（可拖动/可收起）与**手动豁免命令**。

> 架构说明：DSH 中浏览器不直接调用 `api.deepseek.com`，所有模型请求由 Host 进程发起。因此本插件是**混合形态**——Node half 在 `agent/request` / `llm/stream` 处真正拦截与计数，browser half 渲染 UI 并经 HTTP 端点轮询/裁决。判定依据是官方适配器唯一 provider 路由 `deepseek-official`（默认 baseURL `https://api.deepseek.com`，即官方直连计费通道）；第三方代理、Ollama、自定义 provider 一律放行。

## 功能

- **阻塞式拦截**：高峰窗口内发起新的官方请求 → 全屏模态框（时段属性 / 距下一阶段切换剩余时间 / 拦截状态），"继续执行"放行本次请求、"取消请求"中止（前端收到 `cancelMessage` 提示，不产生费用）、**"放行此次会话"**——本次请求继续，且该会话在本次高峰周期内不再弹窗（回落低谷后豁免自动重置，下次高峰需重新选择）。
- **主动提醒横幅**：低谷→高峰切换瞬间且存在活跃请求时，顶部滑入横幅（自定义文案），10 秒自动淡出或点 ✕；单高峰周期仅一次，回落低谷后重置。
- **右下角状态面板**：每秒刷新——时段（红/绿指示灯）、拦截启用状态、距下一阶段剩余时间（`X小时X分钟` / `X分钟` / `X秒`）、当前活跃 DeepSeek 请求数。可按住标题栏拖动、可收起为胶囊、半透明。标题栏 ⚙ 打开**独立设置浮层**（固定尺寸，不随面板缩放）：用滑块调整**面板大小**（60%–160%）与**面板透明度**（30%–100%），并可一键恢复默认。
- **面板偏好持久化**：大小、透明度、展开/收起、拖动位置均保存在浏览器 `localStorage`（键 `deepseek-peak-blocker-ui`），页面刷新后自动恢复。
- **斜杠命令**：
  - `/bypass`：当前会话一次性豁免令牌，下一次官方请求直接放行（用后即失效；仅存内存，插件重启清空）。
  - `/status`：向聊天窗口回复面板四项实时状态。
- **长任务**：判定仅基于请求发起瞬间快照；低谷发起的请求跨入高峰不中断；SDK 网络重试作为新请求重新独立判定。
- **精确计数**：`llm/stream` 进出成对维护，完成/报错/中止均释放，无泄漏。

## 高峰时段与生效日期

高峰时段（北京时间）默认：`09:00-12:00`、`14:00-18:00`。**仅在周一至周五生效**；周六、周日全天视为低谷，完全放行。全部按 UTC+8 计算，不受浏览器/系统时区影响。支持任意非连续时段与跨零点时段（如 `22:00-02:00`）。

> 工作日/周末按北京自然日（UTC+8）判定：周五 23:00 仍属周五、可拦截；周六 00:00 起即低谷、不再拦截。

## 可配置参数

通过 DSH 的 settings（namespace `deepseek-peak-blocker`）配置，可在 `settings.yaml` 或设置界面调整；未配置时使用以下默认值：

| 参数 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| `peakHours` | string[] | `["09:00-12:00", "14:00-18:00"]` | 北京时间高峰时段（`HH:MM-HH:MM`） |
| `bufferMinutes` | number | `0` | 高峰前后缓冲分钟数，`0` 关闭（默认关闭） |
| `blockMessage` | string | `当前为 DeepSeek API 高峰时段，是否继续请求？` | 模态框正文 |
| `cancelMessage` | string | `请求已被用户取消。` | 取消时返回给上层的错误提示 |
| `peakNotification` | string | `⏰ 已进入 API 高峰时段，当前有对话正在进行，请注意响应速度可能受影响。` | 顶部横幅文案 |

## 安装 / 更新（官方 `dsh plugin` 命令，跨平台）

本插件遵守 DSH **bundle 插件**发现规则：仓库根 `package.json` 声明 `dsh.bundle.patch`（组合补丁）与 `dsh.client.platform: "web"`（客户端模块），`cordis.patch.yml` 向组合插入插件行，`exports["./client"]` 指向经 `__ModuleLoader__` 加载的客户端 bundle。`dsh plugin` 会**自动把声明了 `dsh.bundle` 的依赖加入 `dsh.profile.bundles`**，无需手改配置。

> 前置：Node.js ≥ 18、pnpm ≥ 9、git（均需在 PATH——pnpm 解析 `github:` 源时会调用 git）。Windows / Linux / macOS 命令完全一致。

**一键安装**（GitHub 源）：

```sh
dsh plugin --profile web add "github:zisekongling/deepseek-peak-blocker#main"
```

**本地目录开发**（改动即时生效，无需每次 push）：

```sh
dsh plugin --profile web add ./deepseek-peak-blocker   # 相对路径以当前执行目录为基准
```

**一键更新**（重新解析 GitHub 分支最新提交；若新版本新增了 bundle 声明也会自动激活）：

```sh
dsh plugin --profile web update deepseek-peak-blocker
```

**卸载**：

```sh
dsh plugin --profile web remove deepseek-peak-blocker
```

- `web` 是默认 profile（`$DSH_HOME/profiles/web`，未设置 `DSH_HOME` 时为 `~/.dsh/profiles/web`）；其他 profile 把 `web` 换成名字即可。
- 装完 / 更新后**重启 DSH**（bundle 层在启动时合成）。Web 端右下角出现状态面板即成功；可输入 `/status` 验证。

**网络提示（国内 / 代理环境）**：

```sh
# git 走代理（pnpm 解析 github: 源需要 git 访问 github.com）
git config --global http.proxy http://127.0.0.1:10808
git config --global https.proxy http://127.0.0.1:10808
# Windows 证书吊销检查失败时：
git config --global http.schannelCheckRevoke false
```

> 若此前用 `link:` 方式装过、从 link 切换回 GitHub 源时遇 `EPERM`，先删除残留的 junction 目录：`rm -rf <profile>/node_modules/deepseek-peak-blocker` 再重试。

## 使用提醒

- `/bypass` 令牌与时段状态记录均存于进程内存：插件重启后令牌清空（页面刷新不影响——令牌在 Host 侧）。
- 若将 `api.deepseek.com` 反代至自定义域名并注册为**新 provider**，本插件无法识别、不拦截（视为绕过官方直连计费通道）；若仅修改官方适配器的 baseURL 环境变量，路由标识不变、仍会拦截。
- 模态框长时间无人应答（默认 30 分钟，`decisionTimeoutMs`）会自动取消该请求，避免请求永久挂起。

## 更新日志

### v0.2.0
- **高峰时段改为仅周一至周五生效**，周六/周日全天视为低谷、完全不拦截（按北京自然日 UTC+8 判定）。
- **取消 5 分钟软缓冲**：`bufferMinutes` 默认改为 `0`，高峰窗口精确为 `peakHours` 本身。
- 状态面板新增 **⚙ 独立设置浮层**（固定尺寸，不随面板缩放）：用滑块调整**面板大小**（60%–160%）与**面板透明度**（30%–100%），可一键恢复默认。
- **面板偏好持久化**：大小、透明度、展开/收起、拖动位置保存到浏览器 `localStorage`（键 `deepseek-peak-blocker-ui`），刷新后自动恢复。

### v0.1.0
- 首个版本：高峰时段智能拦截 / 提醒横幅 / 状态面板 / `/bypass` 与 `/status` 命令。

## License

MIT
