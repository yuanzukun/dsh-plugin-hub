/** dsh-bgm browser entry: music-reactive DSH conversation surfaces. */
import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type { CommandContribution } from '@deepseek-ai/dsh-client-ui-commands/client'
import { BeatSurface } from './BeatSurface.ts'
import { installStyles } from './styles.ts'

export const inject: readonly string[] = ['commandUi']

type LegacyCommandContribution = Omit<CommandContribution, 'description'> & {
  readonly description: string
}

interface CompatibleCommandUi {
  register(contribution: CommandContribution | LegacyCommandContribution): () => void
  readonly hostDescription?: unknown
}

/** DSH 0.1.5 localizes client command descriptions lazily; older releases store plain copy. */
function usesLazyCommandDescriptions(commandUi: CompatibleCommandUi): boolean {
  return typeof commandUi.hostDescription === 'function'
}

/** Mount the non-invasive per-grapheme beat layer for DSH's conversation UI. */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => {
    const disposeStyles = installStyles()
    const beatSurface = new BeatSurface()
    const disposeSurface = beatSurface.mount()
    const commandUi = ctx.commandUi as unknown as CompatibleCommandUi
    const description = '切换对话区两侧的 RGB 音乐氛围律动柱'
    const commandBase: Omit<CommandContribution, 'description'> = {
      name: 'bgm-atmosphere',
      available: () => true,
      ui: {
        kind: 'popupSelect',
        options: () => Promise.resolve([
          {
            id: 'on',
            label: '开启氛围律动',
            detail: '默认开启；在宽屏对话区两侧显示随系统音乐变化的 RGB 律动柱',
            active: beatSurface.atmosphereEnabled(),
          },
          {
            id: 'off',
            label: '关闭氛围律动',
            detail: '保留文字、判定线与音游反馈，只隐藏两侧 RGB 律动柱',
            active: !beatSurface.atmosphereEnabled(),
          },
        ]),
        onSelect: (option) => { beatSurface.setAtmosphereEnabled(option.id === 'on') },
      },
    }
    const atmosphereCommand: CommandContribution | LegacyCommandContribution = usesLazyCommandDescriptions(commandUi)
      ? { ...commandBase, description: () => description }
      : { ...commandBase, description }
    const disposeAtmosphereCommand = commandUi.register(atmosphereCommand)

    return () => {
      disposeAtmosphereCommand()
      disposeSurface()
      disposeStyles()
    }
  }, 'dsh-bgm: conversation beat surface')
}

export { BeatSurface } from './BeatSurface.ts'
