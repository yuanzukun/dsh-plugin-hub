// The model list is the CLI's own answer to `initialize`, not a hand-kept
// table. These rows are the shape CLI 2.1.322 actually returns (trimmed).

import { test } from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)))
const host = fs.readFileSync(path.join(root, 'src/host.dynamic.js'), 'utf8')

function modelRows() {
  const start = host.indexOf('    function modelRows(rows) {')
  const end = host.indexOf('    /**', start)
  assert.ok(start > 0 && end > start, 'modelRows moved')
  return new Function(host.slice(start, end) + '; return modelRows')()
}

const effortful = ['low', 'medium', 'high', 'xhigh', 'max']
const rows = [
  { value: 'default', resolvedModel: 'claude-opus-5-5', displayName: 'Default (recommended)', supportsEffort: true, supportedEffortLevels: effortful },
  { value: 'opus', resolvedModel: 'claude-opus-5-5', displayName: 'Opus 5.5', description: 'For complex work', supportsEffort: true, supportedEffortLevels: effortful },
  { value: 'fable', resolvedModel: 'claude-fable-5-2', displayName: 'Fable 5.2', supportsEffort: true, supportedEffortLevels: effortful },
  { value: 'claude-haiku-4-5-20251001', resolvedModel: 'claude-haiku-4-5-20251001', displayName: 'Haiku 4.5', supportsThinkingOff: true },
  { value: 'claude-opus-4-6', resolvedModel: 'claude-opus-4-6', displayName: 'Opus 4.6', supportsEffort: true, supportedEffortLevels: ['low', 'medium', 'high', 'max'] },
]

test('别名解析成具体 id，default 不单列，重复的只留一行', () => {
  const out = modelRows()(rows)
  assert.deepEqual(out.map((row) => row.id),
    ['claude-opus-5-5', 'claude-fable-5-2', 'claude-haiku-4-5-20251001', 'claude-opus-4-6'])
  assert.equal(out[0].name, 'Claude Opus 5.5')
  assert.equal(out[0].detail, 'For complex work')
})

test('effort 档位按模型走：不吃 effort 的关掉座位，少一档的就少一档', () => {
  const out = modelRows()(rows)
  const haiku = out.find((row) => row.id.startsWith('claude-haiku-4-5'))
  assert.equal(haiku.reasoning, false)
  assert.deepEqual(haiku.efforts, [])
  assert.deepEqual(out.find((row) => row.id === 'claude-opus-4-6').efforts, ['low', 'medium', 'high', 'max'])
})

test('坏数据不炸', () => {
  assert.deepEqual(modelRows()(undefined), [])
  assert.deepEqual(modelRows()([null, 3, { value: 'gpt-x' }]), [])
})

test('init 握手报的版本一变就重新问', () => {
  assert.equal((host.match(/refreshModels\(run\.remote, message\.claude_code_version\)/g) || []).length, 2)
})
