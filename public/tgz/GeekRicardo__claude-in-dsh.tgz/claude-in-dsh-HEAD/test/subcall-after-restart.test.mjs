// A sub-call's result must repeat its start exactly, or dsh refuses to load
// the whole conversation. After a dsh restart the run that reads the result is
// new and has none of the starts in memory.

import { test } from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)))
const source = fs.readFileSync(path.join(root, 'src/host.dynamic.js'), 'utf8')

function sliceFunction(name) {
  const start = source.indexOf(`function ${name}(`)
  assert.notEqual(start, -1, `找不到 ${name}——它被改名或删掉了`)
  const before = source.lastIndexOf('async ', start)
  const from = before !== -1 && source.slice(before + 'async '.length, start).trim() === '' ? before : start
  let depth = 0
  let i = source.indexOf('{', start)
  while (i < source.length) {
    const c = source[i]
    if (c === '"' || c === "'" || c === '`') {
      i += 1
      while (i < source.length && source[i] !== c) i += source[i] === '\\' ? 2 : 1
      i += 1
      continue
    }
    if (c === '/' && source[i + 1] === '/') {
      i = source.indexOf('\n', i)
      if (i === -1) break
      continue
    }
    if (c === '/' && source[i + 1] === '*') {
      i = source.indexOf('*/', i) + 2
      continue
    }
    if (c === '{') depth += 1
    else if (c === '}') {
      depth -= 1
      if (depth === 0) return source.slice(from, i + 1)
    }
    i += 1
  }
  throw new Error(`${name} 的花括号没有配平`)
}

function harness(events) {
  const appended = []
  const session = { events, append: (type, data) => { appended.push({ type, data }); events.push({ type, data }) } }
  const made = new Function('sessionEvents', 'resultBlocksOf', 'uuid', 'dshToolName', 'dshToolArgs', `
    ${['rootCallOf', 'subagentAssistant', 'subCallStart', 'subagentResults'].map(sliceFunction).join('\n')}
    return { subagentAssistant, subagentResults }
  `)((s) => s.events, (content) => content, () => 'u', (name) => name.toLowerCase(), (name, input) => input)
  const run = () => ({ mainCalls: new Set(['root']), subCallParent: new Map(), subCallInfo: new Map() })
  return { session, appended, made, run }
}

test('重启后读到的子调用结果和它的开始记录一致', () => {
  const { session, appended, made, run } = harness([])
  const before = run()
  made.subagentAssistant(session, before, 'root', { content: [{ type: 'tool_use', id: 'sub-1', name: 'WebSearch', input: { query: 'q' } }] })
  // dsh restarts: a fresh run reads the rest of the stream.
  made.subagentResults(session, run(), 'root', { content: [{ type: 'tool_result', tool_use_id: 'sub-1', content: 'ok' }] })
  const start = appended.find((event) => event.type === 'tool/ptc-dispatch-start').data
  const result = appended.find((event) => event.type === 'tool/ptc-dispatch').data
  for (const key of ['rootCallId', 'parentCallId', 'subCallId', 'name']) assert.equal(result[key], start[key], key)
  assert.deepEqual(result.arguments, start.arguments)
})

test('找不到开始记录的结果不写进日志', () => {
  const { session, appended, made, run } = harness([])
  made.subagentResults(session, run(), 'root', { content: [{ type: 'tool_result', tool_use_id: 'ghost', content: 'x' }] })
  assert.equal(appended.length, 0)
})
