/**
 * AI 工具（M2-3）：preset_list / preset_apply / preset_inspect / preset_create。
 * - 注册经 registerPresetTools：**动态 import('@deepseek-ai/dsh-tools')**——静态导入在
 *   模块加载期执行，解析失败会让插件 FAILED → 整应用无法启动（fail-loud 红线）；
 *   动态导入 + try/catch → 服务缺失/包不可解析时静默降级（仅 warn）。
 * - createPresetToolDefs 独立导出（注入 defineTool）：测试可直接调用工具的 execute()
 *   （与 agent 会话实际执行的代码同源）——M2 AI 功能端到端验证路径。
 * - 工具与浏览器 UI 共用同一事实源（预设库目录 + active.json），见决策 #14。
 */
import { existsSync, mkdirSync, readdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { validatePreset, normalizeDanglingCover } from '../core/schema.ts'
import type { Preset, TokenOverride } from '../core/schema.ts'
import { catalog } from '../core/catalog.ts'
import { KNOBS, KNOB_CATEGORIES, knobValuesForSchemes, findKnob } from '../core/knobs.ts'
import { DEMO_PRESETS, isDemoPreset } from '../core/demo-data.ts'
// #111：令牌 → 界面影响面（catalog render 与 check 提示）
import { tokenRelation } from '../core/catalog-relations.ts'
// #111：调色板生成器（preset_palette 工具 + create/update 的 palette 输入）
import { paletteTokens, PALETTE_MOODS, type PaletteContrast, type PaletteMood } from '../core/palette.ts'
// #112：图片尺寸（只读文件头）+ 焦点/缩放 → 帧坐标裁剪
import { imageSizeOfFile } from '../core/image-size.ts'
import { cropFromFocus, cropFrameSize, WIDGET_CROP_RATIOS } from '../core/crop.ts'
// #67 P1：CSS 补丁锚点字典（与 UI 模板库单一事实源）
import { CSS_ANCHORS } from '../core/css-templates.ts'
// #72：AI 质量预检（preset_check 数据源）
import { precheckPreset } from '../core/precheck.ts'
// #73 P0-2：风格术语字典（preset_catalog styles 段）
import { STYLE_GUIDE } from '../core/style-guide.ts'
// #74：令牌中文描述（catalog 输出 description 字段——UI 与 AI 共享语义层）
import { TOKEN_DESCRIPTIONS } from '../core/catalog-zh.ts'

export interface ToolsEnv {
  presetsDir: string
  /** #65 P0-3：壁纸库目录（素材文件 + <id>.json meta sidecar）。 */
  assetsDir: string
  dataDir: string
  activeFile: string
  configFile: string
}

/** 预设 id 安全检查（与路由同款，杜绝路径穿越）。 */
export function safePresetId(id: string): boolean {
  return /^[a-z0-9][a-z0-9-]{0,63}$/.test(id)
}

// ---- #111 AI 输入展开：knobs / palette → tokens，wallpaper_presence → widgets ----

/** 展开 knobs 输入：{ 旋钮 id: 值 } 或 { 旋钮 id: { light, dark } } → 令牌双值。 */
export function expandKnobsInput(knobs: unknown): Record<string, TokenOverride> {
  if (knobs === undefined || knobs === null) return {}
  if (typeof knobs !== 'object' || Array.isArray(knobs)) throw new Error('knobs 必须是对象（旋钮 id → 值）')
  const out: Record<string, TokenOverride> = {}
  for (const [id, raw] of Object.entries(knobs as Record<string, unknown>)) {
    const knob = findKnob(id)
    if (knob === undefined) throw new Error(`knobs: 未知旋钮 ${id}（先用 preset_catalog 查旋钮束）`)
    let value: string | { light: string; dark: string }
    if (typeof raw === 'string') value = raw
    else if (typeof raw === 'object' && raw !== null && typeof (raw as { light?: unknown }).light === 'string' && typeof (raw as { dark?: unknown }).dark === 'string') {
      value = { light: (raw as { light: string }).light, dark: (raw as { dark: string }).dark }
    } else {
      throw new Error(`knobs.${id}: 值必须是字符串或 { light, dark }`)
    }
    Object.assign(out, knobValuesForSchemes(id, value))
  }
  return out
}

/** 展开 palette 输入：{ seed, mood?, contrast? } → 整套令牌双值。 */
export function expandPaletteInput(palette: unknown): Record<string, TokenOverride> {
  if (palette === undefined || palette === null) return {}
  const p = palette as { seed?: unknown; mood?: unknown; contrast?: unknown }
  if (typeof p.seed !== 'string' || p.seed.trim() === '') throw new Error('palette: 需要 seed（品牌色，如 #8A3A70）')
  const mood = (typeof p.mood === 'string' ? p.mood : 'fresh') as PaletteMood
  if (!PALETTE_MOODS.some(m => m.id === mood)) {
    throw new Error(`palette.mood 非法（${String(p.mood)}）——可选 ${PALETTE_MOODS.map(m => m.id).join('/')}`)
  }
  const contrast = (typeof p.contrast === 'string' ? p.contrast : 'AA') as PaletteContrast
  if (contrast !== 'AA' && contrast !== 'AAA') throw new Error('palette.contrast 只能是 AA 或 AAA')
  return paletteTokens(p.seed, mood, contrast)
}

/** 合并令牌来源（后者覆盖前者）：palette → knobs → tokens。 */
function mergeTokenSources(palette: unknown, knobs: unknown, tokens: unknown): Record<string, TokenOverride> {
  const merged: Record<string, TokenOverride> = {}
  Object.assign(merged, expandPaletteInput(palette))
  Object.assign(merged, expandKnobsInput(knobs))
  if (tokens !== undefined && tokens !== null) {
    if (typeof tokens !== 'object' || Array.isArray(tokens)) throw new Error('tokens 必须是对象（令牌名 → { light, dark }）')
    Object.assign(merged, tokens as Record<string, TokenOverride>)
  }
  return merged
}

/** #111：壁纸存在感（0..1）→ 所有壁纸部件的 opacity/opacityDark。 */
function applyWallpaperPresence(widgets: unknown, presence: unknown): unknown {
  if (presence === undefined || presence === null) return widgets
  const n = Number(presence)
  if (!Number.isFinite(n) || n < 0 || n > 1) throw new Error('wallpaper_presence 必须是 0~1 的数字')
  if (!Array.isArray(widgets)) return widgets
  const text = String(Math.round(n * 100) / 100)
  return widgets.map(widget => {
    if (typeof widget !== 'object' || widget === null) return widget
    const w = widget as { id?: unknown; params?: Record<string, string> }
    if (typeof w.id !== 'string' || !['chat-background', 'settings-background', 'sidebar-poster'].includes(w.id)) return widget
    return { ...w, params: { ...(w.params ?? {}), opacity: text, opacityDark: text } }
  })
}

/** #112：定位素材数据文件（<id>.<ext>，排除 <id>.json sidecar）。 */
function assetFileOf(env: ToolsEnv, assetId: string): string | null {
  if (!safePresetId(assetId)) return null
  let files: string[] = []
  try { files = readdirSync(env.assetsDir) } catch { return null }
  const hit = files.find(file => (file === assetId || file.startsWith(`${assetId}.`)) && !file.endsWith('.json'))
  return hit === undefined ? null : join(env.assetsDir, hit)
}

/** #112：素材像素尺寸（读文件头；未知返回 null）。 */
function assetSizeOf(env: ToolsEnv, assetId: string): { width: number; height: number } | null {
  const file = assetFileOf(env, assetId)
  return file === null ? null : imageSizeOfFile(file)
}

const COVER_FRAME = { w: 1920, h: 640 } // 封面 3:1 帧（与预设 cover 坐标一致）

/** #112：解析焦点/缩放参数（数组或 "x,y" 字符串）。 */
function parseFocus(raw: unknown): [number, number] | null {
  if (Array.isArray(raw) && raw.length === 2) {
    const [x, y] = raw.map(Number)
    return Number.isFinite(x) && Number.isFinite(y) ? [x, y] : null
  }
  if (typeof raw === 'string') {
    const parts = raw.split(',').map(Number)
    if (parts.length === 2 && parts.every(Number.isFinite)) return [parts[0], parts[1]]
  }
  return null
}

/** #112：cover 支持 { focus: [x,y], zoom } → 帧坐标裁剪；裸 cropX/Y/W/H 仍原样透传。 */
function resolveCoverInput(env: ToolsEnv, cover: unknown): { assetId: string; cropX?: string; cropY?: string; cropW?: string; cropH?: string } | null | undefined {
  if (cover === undefined) return undefined
  if (cover === null) return null
  const c = cover as { assetId?: unknown; focus?: unknown; zoom?: unknown }
  if (typeof c.assetId !== 'string' || c.assetId === '') throw new Error('cover: 需要 assetId（素材 id，来自 asset_list）')
  if (c.focus === undefined && c.zoom === undefined) return cover as { assetId: string }
  const size = assetSizeOf(env, c.assetId)
  if (size === null) throw new Error(`cover: 无法读取素材 ${c.assetId} 的尺寸（文件缺失或格式不支持）`)
  const focus = parseFocus(c.focus ?? [0.5, 0.5])
  if (focus === null) throw new Error('cover.focus 需要 [x, y]（归一化 0~1）或 "x,y" 字符串')
  const zoom = c.zoom === undefined ? 1 : Number(c.zoom)
  if (!Number.isFinite(zoom) || zoom <= 0 || zoom > 8) throw new Error('cover.zoom 需要 0~8 的数字（1=适配框内）')
  const rect = cropFromFocus(size.width, size.height, COVER_FRAME.w, COVER_FRAME.h, focus[0], focus[1], zoom, 'cover')
  if (rect === null) throw new Error('cover: 裁剪换算失败（图片尺寸异常）')
  return { assetId: c.assetId, cropX: String(rect.x), cropY: String(rect.y), cropW: String(rect.w), cropH: String(rect.h) }
}

/**
 * #112：部件参数支持 focus/zoom（浅色 `focus`/`zoom`，深色 `focusDark`/`zoomDark`），
 * 在写入前折算为 cropX… 并移除语义键。未使用语义键的部件原样返回。
 */
function normalizeWidgetsCrop(env: ToolsEnv, widgets: unknown): unknown {
  if (!Array.isArray(widgets)) return widgets
  return widgets.map(widget => {
    if (typeof widget !== 'object' || widget === null) return widget
    const w = widget as { id?: unknown; params?: Record<string, unknown> }
    const ratio = typeof w.id === 'string' ? WIDGET_CROP_RATIOS[w.id] : undefined
    if (ratio === undefined || w.params === undefined) return widget
    const params: Record<string, unknown> = { ...w.params }
    const apply = (assetKey: string, focusKey: string, zoomKey: string, prefix: string): void => {
      const assetId = params[assetKey]
      if (typeof assetId !== 'string') return
      const hasFocus = params[focusKey] !== undefined
      const hasZoom = params[zoomKey] !== undefined
      if (!hasFocus && !hasZoom) return
      const size = assetSizeOf(env, assetId)
      if (size === null) throw new Error(`widgets: 无法读取素材 ${assetId} 的尺寸（focus/zoom 换算需要）`)
      const frame = cropFrameSize(ratio)
      const focus = parseFocus(params[focusKey] ?? [0.5, 0.5])
      if (focus === null) throw new Error(`widgets.${focusKey} 需要 [x, y]（归一化 0~1）或 "x,y" 字符串`)
      const zoom = params[zoomKey] === undefined ? 1 : Number(params[zoomKey])
      if (!Number.isFinite(zoom) || zoom <= 0 || zoom > 8) throw new Error(`widgets.${zoomKey} 需要 0~8 的数字`)
      const rect = cropFromFocus(size.width, size.height, frame.w, frame.h, focus[0], focus[1], zoom)
      if (rect === null) throw new Error('widgets: 裁剪换算失败（图片尺寸异常）')
      params[`${prefix}cropX`] = String(rect.x)
      params[`${prefix}cropY`] = String(rect.y)
      params[`${prefix}cropW`] = String(rect.w)
      params[`${prefix}cropH`] = String(rect.h)
      delete params[focusKey]
      delete params[zoomKey]
    }
    apply('assetId', 'focus', 'zoom', '')
    apply('assetIdDark', 'focusDark', 'zoomDark', 'Dark')
    return { ...w, params }
  })
}

/** 原子写（tmp + rename 同卷原子替换）。 */
export function writeFileAtomic(file: string, data: string): void {
  const tmp = `${file}.tmp`
  writeFileSync(tmp, data, 'utf8')
  renameSync(tmp, file)
}

export interface ActiveState {
  activePresetId: string | null
  revision: number
}

/** 读 active.json（缺省 {null, 0}；损坏不抛——降级为无活动）。 */
export function readActiveState(env: ToolsEnv): ActiveState {
  try {
    const raw = JSON.parse(readFileSync(env.activeFile, 'utf8')) as { activePresetId?: unknown; revision?: unknown }
    return {
      activePresetId: typeof raw.activePresetId === 'string' && safePresetId(raw.activePresetId) ? raw.activePresetId : null,
      revision: Number.isInteger(raw.revision) && (raw.revision as number) >= 0 ? raw.revision as number : 0,
    }
  } catch {
    return { activePresetId: null, revision: 0 }
  }
}

/** 写 active.json（revision 单调 +1——浏览器 AI bridge 轮询据此发现外部变更）。 */
export function writeActiveState(env: ToolsEnv, id: string | null): void {
  const prev = readActiveState(env)
  mkdirSync(env.dataDir, { recursive: true })
  writeFileAtomic(env.activeFile, JSON.stringify({ activePresetId: id, revision: prev.revision + 1 }))
}

/** 读预设库列表（损坏条目跳过）。 */
export function listLibraryPresets(env: ToolsEnv): Array<{ id: string; name: string; edition: string }> {
  const out: Array<{ id: string; name: string; edition: string }> = []
  let dirs: string[] = []
  try { dirs = readdirSync(env.presetsDir) } catch { /* 目录缺失 = 空库 */ }
  for (const id of dirs) {
    if (!safePresetId(id)) continue
    try {
      const raw = JSON.parse(readFileSync(join(env.presetsDir, id, 'preset.json'), 'utf8')) as { name?: unknown; edition?: unknown }
      out.push({
        id,
        name: typeof raw.name === 'string' ? raw.name : id,
        edition: typeof raw.edition === 'string' ? raw.edition : 'standard',
      })
    } catch { /* 损坏条目跳过 */ }
  }
  out.sort((a, b) => a.id.localeCompare(b.id))
  return out
}

/** 读预设库单个预设（损坏/缺失 → null）。 */
export function readLibraryPreset(env: ToolsEnv, id: string): Preset | null {
  if (!safePresetId(id)) return null
  try {
    const raw = JSON.parse(readFileSync(join(env.presetsDir, id, 'preset.json'), 'utf8'))
    const result = validatePreset(raw)
    return result.ok ? result.preset : null
  } catch { return null }
}

/** 可应用 id：库或内置 demo。 */
export function resolvablePresetId(env: ToolsEnv, id: string): boolean {
  return isDemoPreset(id) || readLibraryPreset(env, id) !== null
}

/** #64 P0-2：读指定预设详情（preset_get 数据源）——库预设或内置 demo；
 * 素材只返回元数据（dataUrl 最多 28M 字符，绝不能塞给 LLM）；
 * hasBackup 供备份还原工具（P1）铺垫。 */
export function getPresetDetail(env: ToolsEnv, id: string): {
  id: string
  name: string
  edition: string
  builtin: boolean
  tokenCount: number
  style: string | null
  tokens: Record<string, { light: string; dark: string }>
  css: Array<{ selector: string; rules: string }>
  theme: { id: string; colorScheme: 'light' | 'dark'; tokens: Record<string, { light: string; dark: string }> } | null
  assets: Array<{ id: string; name: string; mime: string; size: number }>
  widgets: Array<{ id: string; params: Record<string, string> }>
  cover: { assetId: string; cropX?: string; cropY?: string; cropW?: string; cropH?: string } | null
  hasBackup: boolean
} {
  if (!safePresetId(id)) throw new Error('preset_get: 非法 id')
  const library = readLibraryPreset(env, id)
  const demo = library === null ? DEMO_PRESETS.find(p => p.id === id) ?? null : null
  const preset = library ?? demo
  if (preset === null) throw new Error(`preset_get: 预设 ${id} 不存在（先 preset_list）`)
  // #65：素材 size 语义——内嵌 dataUrl 用其长度；壁纸库文件引用（#32 后）查 meta 真实大小
  const wallpaperSizes = new Map(listWallpaperAssets(env).map(asset => [asset.id, asset.size]))
  return {
    id: preset.id,
    name: preset.name,
    edition: preset.edition,
    builtin: demo !== null,
    tokenCount: Object.keys(preset.tokens).length,
    // #73：风格标签（style:xxx）——AI 可读出厂预设作风范例
    style: styleOf(preset.tags),
    tokens: preset.tokens,
    css: preset.css ?? [],
    // #70：theme 可写后 AI 微调需读主题令牌（与预设 tokens 同结构）
    theme: preset.theme !== undefined
      ? { id: preset.theme.id, colorScheme: preset.theme.colorScheme, tokens: preset.theme.tokens }
      : null,
    assets: (preset.assets ?? []).map(asset => ({
      id: asset.id,
      name: asset.name,
      mime: asset.mime,
      // 内嵌 dataUrl 用其长度；壁纸库文件引用查 meta 真实大小（缺文件 0）
      size: typeof asset.dataUrl === 'string' ? asset.dataUrl.length : (wallpaperSizes.get(asset.id) ?? 0),
    })),
    widgets: (preset.widgets ?? []).map(widget => ({ id: widget.id, params: widget.params })),
    cover: preset.cover ?? null,
    hasBackup: existsSync(join(env.presetsDir, id, 'backup.json')),
  }
}

/** #65 P0-3：壁纸库素材清单（asset_list 数据源）——读 <assetsDir>/<id>.json meta sidecar；
 * 损坏 meta 跳过；缺文件条目保留（悬空引用无害——编译跳过缺素材）。
 * #90：分层合成壁纸（layers 字段：动图引用 + 帧坐标矩形）作为元数据输出（无 dataUrl 泄漏）。 */
export function listWallpaperAssets(env: ToolsEnv): Array<{ id: string; name: string; mime: string; size: number; width?: number; height?: number; layers?: unknown }> {
  const out: Array<{ id: string; name: string; mime: string; size: number; width?: number; height?: number; layers?: unknown }> = []
  let files: string[] = []
  try { files = readdirSync(env.assetsDir) } catch { return out }
  for (const file of files) {
    if (!file.endsWith('.json')) continue
    const id = file.slice(0, -5)
    if (!safePresetId(id)) continue
    try {
      const meta = JSON.parse(readFileSync(join(env.assetsDir, file), 'utf8')) as { id?: unknown; name?: unknown; mime?: unknown; size?: unknown; layers?: unknown }
      if (typeof meta.id === 'string' && typeof meta.name === 'string' && typeof meta.mime === 'string') {
        const entry: { id: string; name: string; mime: string; size: number; width?: number; height?: number; layers?: unknown } = {
          id: meta.id, name: meta.name, mime: meta.mime, size: typeof meta.size === 'number' ? meta.size : 0,
        }
        // #112：像素尺寸（只读文件头）——AI 需要它把 focus/zoom 换算成帧坐标裁剪
        const dims = assetSizeOf(env, meta.id)
        if (dims !== null) { entry.width = dims.width; entry.height = dims.height }
        if (meta.layers !== undefined) entry.layers = meta.layers
        out.push(entry)
      }
    } catch { /* 损坏 meta 跳过 */ }
  }
  out.sort((a, b) => a.id.localeCompare(b.id))
  return out
}

/** #66 P1：备份交换式还原（preset_restore_backup 数据源）——与 #62 HTTP 语义一致：
 * 备份写回 preset.json、**当前版本写入 backup.json**（单层备份，可再还原回去）。
 * 无备份 → 抛「没有可用备份」；备份损坏（坏 JSON / 校验失败）→ 抛「备份损坏」。 */
export function restoreBackupFile(env: ToolsEnv, id: string): { name: string } {
  if (!safePresetId(id)) throw new Error('preset_restore_backup: 非法 id')
  const backupFile = join(env.presetsDir, id, 'backup.json')
  if (!existsSync(backupFile)) throw new Error(`preset_restore_backup: 预设 ${id} 没有可用备份（覆盖保存/更新后才会产生）`)
  let backup: Preset
  try {
    const result = validatePreset(JSON.parse(readFileSync(backupFile, 'utf8')))
    if (!result.ok) throw new Error(`备份损坏：${result.errors[0] ?? '校验失败'}`)
    backup = result.preset
  } catch (error) {
    if (error instanceof Error && error.message.startsWith('备份损坏')) throw new Error(`preset_restore_backup: ${error.message}`)
    throw new Error(`preset_restore_backup: 备份损坏：${error instanceof Error ? error.message : String(error)}`)
  }
  // 交换：当前版本（存在时）成为新备份
  const current = readLibraryPreset(env, id)
  const dir = join(env.presetsDir, id)
  mkdirSync(dir, { recursive: true })
  writeFileAtomic(join(dir, 'preset.json'), JSON.stringify(backup, null, 2))
  if (current !== null) writeFileAtomic(join(dir, 'backup.json'), JSON.stringify(current, null, 2))
  return { name: backup.name }
}

/** #102：字节数人性化（asset_list/preset_get render 用）。 */
function formatBytes(n: number): string {
  if (n >= 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(1)}MB`
  if (n >= 1024) return `${(n / 1024).toFixed(1)}KB`
  return `${n}B`
}

/** review P3（全量评审）：id 生成防同毫秒碰撞——时间戳 base36 + 4 位随机后缀。
 * （原 Date.now().toString(36) 同毫秒连发会静默覆盖；UI 人工操作几乎不触发，
 * 但自动化/AI 流程可触发。） */
export function genId(prefix: string): string {
  const rand = Math.floor(Math.random() * 36 ** 4).toString(36).padStart(4, '0')
  return `${prefix}-${Date.now().toString(36)}${rand}`
}

/** 新建预设落盘（id 由 node 生成；返回 id；校验失败抛教学错误）。 */
export function createPresetFile(
  env: ToolsEnv,
  input: { name: string; tokens: unknown; css?: unknown; assets?: unknown; widgets?: unknown; theme?: unknown; cover?: unknown },
): string {
  const name = typeof input.name === 'string' ? input.name.trim() : ''
  if (name === '') throw new Error('preset_create: name 必填')
  const id = genId('preset')
  const preset: Record<string, unknown> = {
    schemaVersion: 1,
    id,
    name,
    edition: 'standard',
    tokens: input.tokens,
  }
  if (input.css !== undefined) preset.css = input.css
  // #65 P0-3：素材引用声明（{id,name,mime}，id 来自 asset_list——壁纸库文件引用，无 dataUrl）
  // + 部件参数写入（widgets.assetId 必须引用本声明——schema 校验）
  if (input.assets !== undefined) preset.assets = input.assets
  if (input.widgets !== undefined) preset.widgets = input.widgets
  // #70：主题注册写入——{ id, colorScheme, tokens? }；tokens 省略 = 自动取预设全部令牌
  // （与 UI「主题令牌取预设全量」同语义）；结构由 validatePreset 校验
  if (input.theme !== undefined && input.theme !== null) {
    const theme = input.theme as { id?: unknown; colorScheme?: unknown; tokens?: unknown }
    if (typeof theme.id !== 'string' || (theme.colorScheme !== 'light' && theme.colorScheme !== 'dark')) {
      throw new Error('preset_create: theme 必须是 { id, colorScheme: light|dark, tokens? }')
    }
    preset.theme = {
      id: theme.id.trim(),
      colorScheme: theme.colorScheme,
      tokens: theme.tokens !== undefined ? theme.tokens : preset.tokens,
    }
  }
  // #111：封面（AI 此前只能手改 preset.json 才能加封面，绕过了校验）
  const cover = resolveCoverInput(env, input.cover)
  if (cover !== undefined && cover !== null) preset.cover = cover
  const result = validatePreset(preset)
  if (!result.ok) throw new Error(`preset_create: ${result.errors.join('；')}`)
  mkdirSync(join(env.presetsDir, id), { recursive: true })
  writeFileAtomic(join(env.presetsDir, id, 'preset.json'), JSON.stringify(result.preset, null, 2))
  return id
}

/** #73：从 tags 提取风格标签（style:xxx）——出厂预设的风格参考标记。 */
function styleOf(tags: string[] | undefined): string | null {
  if (!Array.isArray(tags)) return null
  const tag = tags.find(t => typeof t === 'string' && t.startsWith('style:'))
  return tag !== undefined ? tag.slice(6) : null
}

/** 当前外观快照（preset_inspect 数据源）。
 * #96（审计）：无活动预设时**省略** activePresetId/activeName 键而非置 null——
 * 输出 schema 无法声明 nullable（guard DSL 限制），null 会让宿主运行期校验报错。 */
export function inspectState(env: ToolsEnv): {
  activePresetId?: string
  activeName?: string
  revision: number
  tier: string
  tokenCount: number
  appliedTokenNames: string[]
} {
  const active = readActiveState(env)
  let activeName: string | null = null
  let tokenCount = 0
  let appliedTokenNames: string[] = []
  let found = false
  if (active.activePresetId !== null) {
    const preset = readLibraryPreset(env, active.activePresetId) ?? DEMO_PRESETS.find(p => p.id === active.activePresetId) ?? null
    if (preset !== null) {
      found = true
      activeName = preset.name
      tokenCount = Object.keys(preset.tokens).length
      appliedTokenNames = Object.keys(preset.tokens)
    }
  }
  let tier = 'standard'
  try {
    const raw = JSON.parse(readFileSync(env.configFile, 'utf8')) as { tier?: unknown }
    if (raw.tier === 'simple' || raw.tier === 'standard') tier = raw.tier
  } catch { /* 缺省标准版 */ }
  const out: { revision: number; tier: string; tokenCount: number; appliedTokenNames: string[]; activePresetId?: string; activeName?: string } = {
    revision: active.revision, tier, tokenCount, appliedTokenNames,
  }
  if (found && activeName !== null) {
    out.activePresetId = active.activePresetId ?? undefined
    out.activeName = activeName
  }
  return out
}

/** 更新预设文件（合并 name/tokens/css/assets/widgets/theme，校验后写回 + 备份旧版；#63 mergeTokens 增量合并令牌）。 */
export function updatePresetFile(
  env: ToolsEnv,
  id: string,
  patch: { name?: unknown; tokens?: unknown; css?: unknown; mergeTokens?: unknown; assets?: unknown; widgets?: unknown; theme?: unknown; cover?: unknown },
): string {
  if (!safePresetId(id)) throw new Error('preset_update: 非法 id')
  const existing = readLibraryPreset(env, id)
  if (existing === null) throw new Error(`preset_update: 预设 ${id} 不存在`)
  // #68 P2：extra 平铺（防御双保险——schema 清洗已修复 extra 展开合并；此处保证
  // update 输入无多余 extra 键，且二次校验收集结果保持同一层级，无嵌套加深）
  const merged: Record<string, unknown> = { ...existing, ...(existing.extra ?? {}) }
  delete merged.extra
  if (patch.name !== undefined) merged.name = patch.name
  if (patch.tokens !== undefined) merged.tokens = patch.tokens
  // #63 P0-1：增量合并——只更新提供的令牌键，其余保持（AI 微调场景，避免整体替换覆盖一切）；
  // 与 tokens 整体替换互斥（同时提供时 mergeTokens 优先，description 已说明二选一）。
  if (patch.mergeTokens !== undefined) {
    if (typeof patch.mergeTokens !== 'object' || patch.mergeTokens === null || Array.isArray(patch.mergeTokens)) {
      throw new Error('preset_update: merge_tokens 必须是令牌对象（令牌名 → { light, dark }）')
    }
    const base = (existing.tokens ?? {}) as Record<string, unknown>
    merged.tokens = { ...base, ...(patch.mergeTokens as Record<string, unknown>) }
  }
  if (patch.css !== undefined) merged.css = patch.css
  // #65 P0-3：素材引用声明 + 部件整体替换（与 css 同语义；widgets.assetId 必须引用 assets 声明）
  if (patch.assets !== undefined) merged.assets = patch.assets
  if (patch.widgets !== undefined) merged.widgets = patch.widgets
  // #111：封面可整体替换或清除（null）
  if (patch.cover !== undefined) {
    const cover = resolveCoverInput(env, patch.cover)
    if (cover === null) delete merged.cover
    else if (cover !== undefined) merged.cover = cover
  }
  // #70：主题写入——{ id, colorScheme, tokens? }（tokens 省略 = 取当前预设令牌）或 null（清除主题）
  if (patch.theme !== undefined) {
    if (patch.theme === null) {
      delete merged.theme
    } else {
      const theme = patch.theme as { id?: unknown; colorScheme?: unknown; tokens?: unknown }
      if (typeof theme.id !== 'string' || (theme.colorScheme !== 'light' && theme.colorScheme !== 'dark')) {
        throw new Error('preset_update: theme 必须是 { id, colorScheme: light|dark, tokens? } 或 null（清除）')
      }
      merged.theme = {
        id: theme.id.trim(),
        colorScheme: theme.colorScheme,
        tokens: theme.tokens !== undefined ? theme.tokens : merged.tokens,
      }
    }
  }
  // #104：AI 替换 assets 时 cover 可能悬空（新 assets 不含原封面素材）——先归一化回退
  // 自动生成封面，再校验（与 UI 保存同语义；zip 导入等外部载荷仍 fail-loud）
  const normalized = normalizeDanglingCover(merged as Preset)
  const result = validatePreset(normalized.preset)
  if (!result.ok) throw new Error(`preset_update: ${result.errors.join('；')}`)
  const dir = join(env.presetsDir, id)
  mkdirSync(dir, { recursive: true })
  writeFileAtomic(join(dir, 'preset.json'), JSON.stringify(result.preset, null, 2))
  writeFileAtomic(join(dir, 'backup.json'), JSON.stringify(existing, null, 2))
  return id
}

/** 删除预设文件（目录整体移除）。 */
export function deletePresetFile(env: ToolsEnv, id: string): void {
  if (!safePresetId(id)) throw new Error('preset_delete: 非法 id')
  if (isDemoPreset(id)) throw new Error('preset_delete: 内置示例不可删除')
  rmSync(join(env.presetsDir, id), { recursive: true, force: true })
}

/** 是否已成功注册（/ui-presets/status 暴露，诊断 + e2e 用）。 */
let registered = false
export function isToolsRegistered(): boolean {
  return registered
}

/**
 * 工具定义工厂（M2 AI 功能测试注入点）：四个 preset_* 工具的 defineTool 定义。
 * @param env - 文件环境（测试可指向临时目录；生产指向 DSH_HOME）。
 * @param defineTool - 真实 dsh-tools 的 defineTool（测试可注入恒等 stub——execute 代码同源）。
 */
export function createPresetToolDefs(
  env: ToolsEnv,
  defineTool: (definition: unknown) => unknown,
): unknown[] {
  return [
    defineTool({
      name: 'preset_list',
      description: '列出所有可用的界面外观预设（内置示例 + 用户预设库），含名称/id/档位/令牌数——作为推荐与应用的目录来源。',
      parameters: {},
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            presets: {
              type: 'array',
              required: true,
              items: {
                type: 'object',
                additionalProperties: false,
                properties: {
                  id: { type: 'string', required: true },
                  name: { type: 'string', required: true },
                  edition: { type: 'string', required: true },
                  builtin: { type: 'boolean', required: true },
                  tokenCount: { type: 'integer', required: true },
                  // #96（审计）：execute 返回 style 键（#73 风格参考）——additionalProperties:false
                  // 下未声明键会让宿主输出校验抛 ToolOutputError（测试 stub 掩盖了运行期失败）
                  style: { type: 'string' },
                },
              },
            },
          },
        },
        render: (_args, value) => [{
          type: 'text',
          // #102：render 必须携带 id——LLM 看到的是 render 文本（结构化输出不直达模型），
          // 原实现只拼名称，AI 无法按 id 继续 preset_get/apply
          text: `共 ${value.presets.length} 个预设：${value.presets
            .map((p: { id: string; name: string; builtin: boolean }) => `${p.id}（${p.name}${p.builtin ? '，内置' : ''}）`)
            .join('、')}`,
        }],
      },
      execute: () => {
        const library = listLibraryPresets(env)
        const merged = [
          ...DEMO_PRESETS.map(preset => ({
            id: preset.id, name: preset.name, edition: preset.edition, builtin: true,
            tokenCount: Object.keys(preset.tokens).length,
            // #73：风格标签（style:xxx）——AI 据此选择风格范例
            style: styleOf(preset.tags),
          })),
          ...library
            .filter(item => !isDemoPreset(item.id))
            .map(item => {
              const preset = readLibraryPreset(env, item.id)
              const entry: Record<string, unknown> = {
                ...item, builtin: false,
                tokenCount: preset !== null ? Object.keys(preset.tokens).length : 0,
              }
              // #96：style 无值（null）时省略键而非置 null——输出 schema 无法声明 nullable
              if (preset !== null) {
                const style = styleOf(preset.tags)
                if (style !== null) entry.style = style
              }
              return entry
            }),
        ]
        return Promise.resolve({ presets: merged })
      },
      presentCall: () => ({ card: 'generic', title: '列出外观预设', kind: 'other', rawInput: null }),
    }),
    defineTool({
      name: 'preset_apply',
      description: '应用一个外观预设（id 来自 preset_list）。与用户在界面点击"应用"等价：立即生效并持久化（重启后保持）。',
      parameters: {
        id: { type: 'string', required: true, description: '预设 id（preset_list 返回）' },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ok: { type: 'boolean', required: true },
            id: { type: 'string', required: true },
          },
        },
        render: (_args, value) => [{
          type: 'text',
          text: value.ok ? `已应用预设 ${value.id}` : `应用失败：${value.id}`,
        }],
      },
      execute: (args: { id: string }) => {
        if (!safePresetId(args.id) || !resolvablePresetId(env, args.id)) {
          throw new Error(`preset_apply: 预设 ${args.id} 不存在（先 preset_list）`)
        }
        writeActiveState(env, args.id)
        return Promise.resolve({ ok: true, id: args.id })
      },
      presentCall: args => ({ card: 'generic', title: '应用预设', kind: 'other', rawInput: args }),
    }),
    defineTool({
      name: 'preset_inspect',
      description: '查看当前外观状态：活动预设（名称/令牌数）、对外档位、以及活动预设应用的令牌清单——支持"我现在是什么主题"类提问。',
      parameters: {},
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            // #68 P2 注记：activePresetId/activeName 可为 null，但 dsh-tools guard 的 DSL
            // 不支持联合类型（type: ['string','null'] 会使注册整体失败——已实测）——
            // 保持宽松声明（无 required），这是工具框架限制而非缺陷。
            activePresetId: { type: 'string' },
            activeName: { type: 'string' },
            revision: { type: 'integer', required: true },
            tier: { type: 'string', required: true },
            tokenCount: { type: 'integer', required: true },
            appliedTokenNames: {
              type: 'array',
              required: true,
              items: { type: 'string' },
            },
          },
        },
        render: (_args, value) => {
          // #110：inspect 的核心信息是「到底覆盖了哪些令牌」——原 render 只报数量。
          const names = (value.appliedTokenNames ?? []) as string[]
          const head = value.activeName != null
            ? `当前外观：${value.activeName}（${value.tokenCount} 个令牌覆盖，档位 ${value.tier}，revision ${value.revision}）`
            : `当前为默认外观（档位 ${value.tier}，revision ${value.revision}）`
          const list = names.length === 0
            ? '令牌覆盖：无'
            : `令牌覆盖清单（${names.length}）：${names.join('、')}`
          return [{ type: 'text', text: `${head}\n${list}` }]
        },
      },
      execute: () => Promise.resolve(inspectState(env)),
      presentCall: () => ({ card: 'generic', title: '查看当前外观', kind: 'other', rawInput: null }),
    }),
    defineTool({
      name: 'preset_create',
      description: '按自然语言需求创建外观预设（把用户描述映射为令牌双值）：写入预设库但不自动应用——用户确认后再应用/编辑。'
        + 'tokens 格式：令牌名（-- 开头）→ { light, dark } 双值字符串；明暗一致时重复同一值。'
        + '常用令牌示例：--dsw-alias-bg-base（界面底色）/ --dsw-alias-brand-primary（品牌主色）/ --dsw-alias-label-primary（主文字）'
        + '；品牌色束：--dsw-alias-button-info-fill 与 --dsw-alias-state-business-primary 与品牌主色同值。'
        + '设计流程：先 preset_catalog 查令牌语义与风格字典（styles），风格词可 preset_list 看出厂预设的 style 标签'
        + '或 preset_get <demo id> 读其令牌作风范例（如 default 海洋清爽——唯一出厂预设）；'
        + '创建前可 preset_check 预检。注意 safety 字段：caution 级令牌影响面大，谨慎调整（与界面提示一致）。',
      parameters: {
        name: { type: 'string', required: true, description: '预设名称（≤64 字符）' },
        tokens: {
          type: 'object',
          additionalProperties: true,
          description: '令牌 → { light, dark } 双值映射（可选；与 knobs/palette 三选一，可叠加——显式 tokens 优先级最高）',
        },
        knobs: {
          type: 'object',
          additionalProperties: true,
          description: '可选语义旋钮（推荐，省去手算几十个令牌）：{ 旋钮 id: 值 } 或 { 旋钮 id: { light, dark } }。'
            + '旋钮 id 见 preset_catalog 的 knobs（如 spatial-bg / text-primary / radius-scale / motion-speed / mask-blur / button-family）；'
            + '同束令牌会按派生规则自动生成阶梯（抬升面/悬浮层不再是同色）。',
        },
        palette: {
          type: 'object',
          additionalProperties: true,
          description: '可选整套调色板生成：{ seed: 品牌色（如 "#8A3A70"）, mood?: "fresh"|"night"|"retro"|"mono", contrast?: "AA"|"AAA" }'
            + '——服务端派生背景/层次/文字/按钮/边框/状态/代码面整套双值（文字自动满足对比度目标），可再用 tokens/knobs 覆盖。',
        },
        cover: {
          type: 'object',
          additionalProperties: true,
          description: '可选封面：{ assetId, cropX?, cropY?, cropW?, cropH? }——assetId 必须同时出现在 assets 声明里；裁剪为帧坐标（3:1 帧，长边 1920）。'
            + '推荐用语义裁剪：{ assetId, focus: [x, y]（图片内归一化 0~1，如 [0.5, 0.35]）, zoom?: 1 }——服务端按素材像素尺寸折算帧坐标，cover 模式保证铺满卡片',
        },
        wallpaper_presence: {
          type: 'number',
          description: '可选壁纸存在感 0~1（一次设置所有壁纸部件的 opacity/opacityDark；0=关闭壁纸）',
        },
        css: {
          type: 'array',
          description: '可选 CSS 补丁：{ selector（须 [data- 锚点开头）, rules（禁止花括号）} 数组',
        },
        assets: {
          type: 'array',
          description: '可选素材引用声明（id 来自 asset_list）：[{ id, name, mime }]——壁纸库文件引用，不含图片数据',
        },
        widgets: {
          type: 'array',
          description: '可选注入部件：'
            + '[{ id: "chat-background"|"settings-background"|"sidebar-poster", params: { assetId: <assets 声明中的 id>, opacity: "0~1 字符串" } }]'
            + '——assetId 必须同时出现在 assets 声明里；裁剪交互留给 UI，不要写裁剪参数',
        },
        theme: {
          type: 'object',
          additionalProperties: true,
          description: '可选主题注册（启用后用户可在界面「切换到此主题」）：{ id: 合法标识符（小写字母数字开头，允许中划线，惯例 <预设id>-theme）,'
            + ' colorScheme: "light"|"dark"（决定明暗基色板方向）, tokens?: 主题令牌双值（省略 = 自动使用本预设全部令牌）}',
        },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ok: { type: 'boolean', required: true },
            id: { type: 'string', required: true },
          },
        },
        render: (args, value) => {
          // #110：回执要包含「写了什么」——原实现只回 id，模型无法确认令牌/部件/主题/封面是否被接受。
          const a = args as {
            name?: string; tokens?: Record<string, unknown>; knobs?: Record<string, unknown>; palette?: { seed?: string; mood?: string }
            css?: unknown[]; assets?: unknown[]; widgets?: Array<{ id?: string }>; theme?: { id?: string }
            cover?: { assetId?: string }; wallpaper_presence?: number
          }
          let tokenNames: string[] = Object.keys(a.tokens ?? {})
          try {
            // 与 execute 同源展开：回执要反映 palette/knobs 实际产生了多少令牌
            tokenNames = Object.keys(mergeTokenSources(a.palette, a.knobs, a.tokens))
          } catch { /* 校验错误由 execute 抛出，render 只做回执 */ }
          const parts: string[] = [`${tokenNames.length} 令牌`]
          const names = tokenNames.slice(0, 8).join('、') + (tokenNames.length > 8 ? '…' : '')
          if (names !== '') parts.push(`含 ${names}`)
          if (a.palette !== undefined) parts.push(`调色板 seed=${a.palette.seed ?? ''}${a.palette.mood !== undefined ? `（${a.palette.mood}）` : ''}`)
          if (a.knobs !== undefined) parts.push(`旋钮 ${Object.keys(a.knobs).join('、')}`)
          if (Array.isArray(a.css) && a.css.length > 0) parts.push(`CSS 补丁 ${a.css.length} 段`)
          if (Array.isArray(a.widgets) && a.widgets.length > 0) parts.push(`部件 ${a.widgets.map(w => w.id).join('/')}${a.wallpaper_presence !== undefined ? `（壁纸存在感 ${a.wallpaper_presence}）` : ''}`)
          if (Array.isArray(a.assets) && a.assets.length > 0) parts.push(`素材引用 ${a.assets.length} 个`)
          if (a.cover !== undefined) parts.push(`封面 ${a.cover.assetId ?? ''}`)
          if (a.theme !== undefined) parts.push(`主题 ${a.theme.id ?? ''}`)
          return [{
            type: 'text',
            text: value.ok
              ? `已创建预设 ${value.id}「${a.name ?? ''}」（${parts.join('；')}；未应用，用户确认后生效）`
              : '创建失败',
          }]
        },
      },
      execute: (args: {
        name: string; tokens?: unknown; knobs?: unknown; palette?: unknown; css?: unknown
        assets?: unknown; widgets?: unknown; theme?: unknown; cover?: unknown; wallpaper_presence?: unknown
      }) => {
        const tokens = mergeTokenSources(args.palette, args.knobs, args.tokens)
        if (Object.keys(tokens).length === 0) {
          throw new Error('preset_create: 至少提供 tokens / knobs / palette 之一')
        }
        const widgets = normalizeWidgetsCrop(env, applyWallpaperPresence(args.widgets, args.wallpaper_presence))
        const id = createPresetFile(env, {
          name: args.name, tokens, css: args.css, assets: args.assets, widgets, theme: args.theme, cover: args.cover,
        })
        return Promise.resolve({ ok: true, id })
      },
      presentCall: args => ({ card: 'generic', title: '创建预设', kind: 'other', rawInput: args }),
    }),
    defineTool({
      name: 'preset_catalog',
      description: '查询令牌目录语义与设计参考（设计预设的字典）：按名称/分组过滤返回令牌（名称/分组/明暗默认值/安全等级/取值类型/影响面 scope），'
        + '返回旋钮束映射（旋钮 id/类别/控件类型/数值边界/覆盖的令牌）、CSS 补丁可用锚点（css_anchors）与风格术语字典（styles：'
        + '用户风格词 → 设计手法 + 可参考的出厂预设——如 "清爽" 可 preset_get default 读其令牌作风范例）。'
        + '命中超过 200 条只返回前 200，请用更精确的 query 过滤（提示：分组名可用 alias/specific/static 一次拿全对应组）。'
        + 'preset_create/update 前先查这里，令牌名必须 -- 开头；注意 safety 字段：caution 级令牌影响面大，谨慎调整（与界面提示一致）。',
      parameters: {
        query: { type: 'string', description: '名称子串或分组名过滤（如 "bg" 或 "bg-base"、"alias" 拿全 alias 组；省略 = 全部，最多 200 条）' },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            matched: { type: 'integer', required: true },
            tokens: {
              type: 'array', required: true,
              items: { type: 'object', additionalProperties: true },
            },
            knobs: {
              type: 'array', required: true,
              items: { type: 'object', additionalProperties: true },
            },
            knob_categories: {
              type: 'array', required: true,
              items: { type: 'object', additionalProperties: true },
            },
            css_anchors: {
              type: 'array', required: true,
              items: { type: 'object', additionalProperties: false, properties: { selector: { type: 'string', required: true }, label: { type: 'string', required: true }, note: { type: 'string', required: true } } },
            },
            styles: {
              type: 'array', required: true,
              items: { type: 'object', additionalProperties: false, properties: { term: { type: 'string', required: true }, guidance: { type: 'string', required: true }, demos: { type: 'array', required: true, items: { type: 'string' } } } },
            },
          },
        },
        render: (args, value) => {
          // #110：render 是模型唯一可见的内容（宿主 createSuccessResult 只把 output.render 的
          // 返回值放进 content，结构化 value 不直达模型）。原实现只报「命中 N 条」——模型一条
          // 令牌都看不到，只能去翻 catalog-data.ts。这里输出紧凑表（限 40 行 + 剩余提示）。
          const RENDER_LIMIT = 40
          const shown = value.tokens.slice(0, RENDER_LIMIT) as Array<{
            name: string; group: string; light: string; dark: string; safety: string; valueType: string; scope: string
          }>
          const tokenLines = shown.map(t => {
            // #111：附「影响面」——AI 改色前能判断会波及哪些界面区域
            const relation = tokenRelation(t.name)
            const affects = relation === undefined ? '' : `｜影响：${relation.affects}`
            return `- ${t.name} [${t.group}] light=${t.light} dark=${t.dark} ${t.safety === 'caution' ? '⚠caution' : t.safety} ${t.valueType}${t.scope === 'local' ? ' 局部' : ''}${affects}`
          })
          const rest = value.matched - shown.length
          const knobLine = value.knobs.length === 0
            ? '旋钮束：无'
            : `旋钮束 ${value.knobs.length} 个（每项含 id/名称/类别/控件/边界/覆盖令牌）：`
              + value.knobs.map((k: { id: string; name: string; tokens?: string[] }) =>
                `${k.id}（${k.name}：${(k.tokens ?? []).join('+')}）`).join('；')
          const styleLine = value.styles.length === 0
            ? '风格字典：无'
            : `风格字典 ${value.styles.length} 词：${value.styles.map((s: { term: string }) => s.term).join('、')}`
          const anchorLine = value.css_anchors.length === 0
            ? 'CSS 锚点：无'
            : `CSS 锚点 ${value.css_anchors.length} 个：${value.css_anchors.map((a: { selector: string }) => a.selector).join('、')}`
          return [{
            type: 'text',
            text: [
              `令牌目录：query=${args.query ?? '（无，全部）'} 命中 ${value.matched} 条`
                + (rest > 0 ? `，下列显示前 ${shown.length} 条（还有 ${rest} 条，请用更精确的 query；分组名 alias/specific/static 可一次拿全）` : '，全部列出'),
              tokenLines.length > 0 ? tokenLines.join('\n') : '（无匹配令牌）',
              knobLine,
              anchorLine,
              styleLine,
            ].join('\n'),
          }]
        },
      },
      execute: (args: { query?: string }) => {
        const query = (args.query ?? '').trim().toLowerCase()
        // #68 P2：matched = 全部匹配数（截断前），tokens 只返回前 200——LLM 能感知还有更多
        const matchedEntries = catalog.entries.filter(entry => query === ''
          || entry.name.toLowerCase().includes(query)
          || entry.group.includes(query))
        const tokens = matchedEntries.slice(0, 200).map(entry => ({
          name: entry.name,
          group: entry.group,
          light: entry.light,
          dark: entry.dark,
          safety: entry.safety,
          valueType: entry.valueType,
          // #68 P2：补 scope（global/local 影响面）；#74：description 并入中文语义层（内置）
          scope: entry.scope,
          description: entry.description !== '' ? entry.description : (TOKEN_DESCRIPTIONS[entry.name] ?? ''),
        }))
        // #68 P2：knobs 补控件语义（category/control/数值边界/选项）——LLM 知道 select 的取值集合。
        // #101：可选字段（min/max/step/unit/options）**只在有值时写入**——color 类旋钮这些字段为
        // undefined，宿主输出校验要求无损 JSON（undefined 被 JSON 序列化静默丢弃 → 整体拒收，
        // "value is not lossless JSON"；stub defineTool 掩盖，e2e/verify-tools 均未走宿主校验）。
        const knobs = KNOBS.map(knob => {
          const entry: Record<string, unknown> = {
            id: knob.id,
            name: knob.name,
            description: knob.description,
            tokens: knob.bundle,
            category: knob.category,
            control: knob.control,
          }
          if (knob.min !== undefined) entry.min = knob.min
          if (knob.max !== undefined) entry.max = knob.max
          if (knob.step !== undefined) entry.step = knob.step
          if (knob.unit !== undefined) entry.unit = knob.unit
          if (knob.options !== undefined) entry.options = knob.options
          return entry
        })
        const knobCategories = KNOB_CATEGORIES.map(cat => ({ id: cat.id, name: cat.name, description: cat.description }))
        return Promise.resolve({ matched: matchedEntries.length, tokens, knobs, knob_categories: knobCategories, css_anchors: CSS_ANCHORS, styles: STYLE_GUIDE })
      },
      presentCall: args => ({ card: 'generic', title: '查询令牌目录', kind: 'other', rawInput: args }),
    }),
    defineTool({
      name: 'preset_get',
      description: '读取指定预设的完整详情（id 来自 preset_list）：令牌双值/css 补丁/主题/部件参数/封面/风格标签/备份标记——'
        + 'preset_update 微调前先读现值，避免整体替换覆盖未知内容；内置示例也可读（含 style 风格标签——'
        + '可作为设计范例：如用户要"海洋清爽风格"先 preset_get default 参考其令牌取值手法）。'
        + '素材只返回元数据（id/name/mime/体积，不含图片数据）。',
      parameters: {
        id: { type: 'string', required: true, description: '预设 id（preset_list 返回）' },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ok: { type: 'boolean', required: true },
            preset: { type: 'object', additionalProperties: true, required: true },
          },
        },
        render: (_args, value) => {
          // #102：render 必须给出完整详情（令牌双值/widgets/主题/封面/素材）——LLM 看到的是
          // render 文本（结构化输出不直达模型），原实现只显示「N 令牌，有备份」，无法"先读现值再微调"
          if (value.ok !== true || value.preset === undefined) return [{ type: 'text', text: '读取失败' }]
          const p = value.preset as {
            name: string; id: string; edition: string; builtin: boolean; hasBackup: boolean; tokenCount: number
            tokens: Record<string, { light: string; dark: string }>
            css?: Array<{ selector: string }>
            theme?: { id: string; colorScheme: string; tokens: Record<string, { light: string; dark: string }> } | null
            assets?: Array<{ id: string; name: string; mime: string; size: number }>
            widgets?: Array<{ id: string; params: Record<string, string> }>
            cover?: { assetId: string; cropX?: string; cropY?: string; cropW?: string; cropH?: string } | null
          }
          const tokenNames = Object.keys(p.tokens ?? {})
          // #110：不再截断 30 条（54 个令牌的场景下模型看不到全量，微调必然漏改）。
          // 仅设 200 条上限防病态输入，并在截断时明确提示。
          const TOKEN_RENDER_LIMIT = 200
          const tokenLines = tokenNames.slice(0, TOKEN_RENDER_LIMIT).map(name => {
            const v = p.tokens[name]
            return `- ${name}: light=${v?.light} dark=${v?.dark}`
          })
          const moreTokens = tokenNames.length > TOKEN_RENDER_LIMIT
            ? `（…还有 ${tokenNames.length - TOKEN_RENDER_LIMIT} 个未列出，共 ${tokenNames.length} 个）`
            : ''
          const widgetLines = (p.widgets ?? []).map(w =>
            `- ${w.id}: ${Object.entries(w.params ?? {}).map(([k, v]) => `${k}=${v}`).join(' ')}`)
          const themeLine = p.theme !== null && p.theme !== undefined
            ? `主题 ${p.theme.id}（${p.theme.colorScheme}，${Object.keys(p.theme.tokens ?? {}).length} 令牌）`
            : '主题无'
          const cover = p.cover
          const coverLine = cover !== null && cover !== undefined
            ? `封面 ${cover.assetId}${cover.cropW !== undefined && cover.cropW !== '' ? `（裁剪 ${cover.cropX},${cover.cropY} ${cover.cropW}×${cover.cropH}）` : ''}`
            : '封面无'
          const assetLines = (p.assets ?? []).map(a => `- ${a.id}：${a.name}（${a.mime}，${formatBytes(a.size)}）`)
          return [{
            type: 'text',
            text: [
              `预设「${p.name}」（id=${p.id}，${p.edition}${p.builtin ? '，内置' : ''}${p.hasBackup ? '，有备份' : ''}）：`
                + `${p.tokenCount} 令牌；widgets ${(p.widgets ?? []).length} 个；${themeLine}；${coverLine}；`
                + `CSS 补丁 ${(p.css ?? []).length} 段；素材 ${(p.assets ?? []).length} 个`,
              tokenLines.length > 0 ? `令牌：\n${tokenLines.join('\n')}${moreTokens}` : '',
              widgetLines.length > 0 ? `widgets：\n${widgetLines.join('\n')}` : '',
              assetLines.length > 0 ? `素材：\n${assetLines.join('\n')}` : '',
            ].filter(Boolean).join('\n'),
          }]
        },
      },
      execute: (args: { id: string }) => {
        const detail = getPresetDetail(env, args.id)
        return Promise.resolve({ ok: true, preset: detail })
      },
      presentCall: args => ({ card: 'generic', title: '读取预设详情', kind: 'other', rawInput: args }),
    }),
    defineTool({
      name: 'preset_update',
      description: '更新一个已存在预设（id 来自 preset_list）：按需替换 name/tokens/css/assets/widgets（未提供的字段保持不变），'
        + '校验通过后写回并备份旧版。微调场景（如"把背景改深一点"）推荐用 merge_tokens 增量合并令牌（只更新提供的键，其余保持）——'
        + '避免整体替换覆盖其他令牌。若目标预设是当前生效的活动预设，更新后自动重新应用：界面即时生效（无需再 preset_apply）。'
        + '先 preset_get 读现值、preset_catalog 查语义；safety 为 caution 的令牌影响面大，谨慎调整（与界面提示一致）。'
        + '主题可用 theme（注册/替换）或 clear_theme（清除）。',
      parameters: {
        id: { type: 'string', required: true, description: '目标预设 id' },
        name: { type: 'string', description: '新名称（可选）' },
        tokens: {
          type: 'object',
          additionalProperties: true,
          description: '令牌 → { light, dark } 双值映射（可选；整体替换该字段——与 merge_tokens 二选一，同时提供时 merge_tokens 优先）',
        },
        merge_tokens: {
          type: 'object',
          additionalProperties: true,
          description: '增量合并令牌（可选；只更新提供的键，未提供的保持原值——微调推荐；与 tokens 二选一）',
        },
        knobs: {
          type: 'object',
          additionalProperties: true,
          description: '可选语义旋钮（并入 merge_tokens）：{ 旋钮 id: 值 } 或 { 旋钮 id: { light, dark } }——同束令牌自动派生阶梯',
        },
        palette: {
          type: 'object',
          additionalProperties: true,
          description: '可选整套调色板（并入 merge_tokens）：{ seed, mood?, contrast? }——按品牌色重算整套配色',
        },
        cover: {
          type: 'object',
          additionalProperties: true,
          description: '可选封面（整体替换）：{ assetId, cropX?, cropY?, cropW?, cropH? }；传 null 清空封面',
        },
        wallpaper_presence: {
          type: 'number',
          description: '可选壁纸存在感 0~1（批量改所有壁纸部件 opacity；预设没有部件时需同时提供 widgets）',
        },
        css: { type: 'array', description: '可选 CSS 补丁（整体替换）' },
        assets: {
          type: 'array',
          description: '可选素材引用声明（整体替换；id 来自 asset_list）：[{ id, name, mime }]——壁纸库文件引用，不含图片数据',
        },
        widgets: {
          type: 'array',
          description: '可选注入部件（整体替换）：'
            + '[{ id: "chat-background"|"settings-background"|"sidebar-poster", params: { assetId: <assets 声明中的 id>, opacity: "0~1 字符串" } }]'
            + '——assetId 必须同时出现在 assets 声明里；裁剪交互留给 UI',
        },
        theme: {
          type: 'object',
          additionalProperties: true,
          description: '可选主题（整体替换；与 clear_theme 二选一）：{ id: 合法标识符（惯例 <预设id>-theme）, colorScheme: "light"|"dark",'
            + ' tokens?: 主题令牌双值（省略 = 自动使用当前预设令牌）}',
        },
        clear_theme: {
          type: 'boolean',
          description: '清除主题注册（可选；与 theme 二选一，同时提供时 clear_theme 优先）',
        },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ok: { type: 'boolean', required: true },
            id: { type: 'string', required: true },
          },
        },
        render: (args, value) => {
          // #110：回执列出本次实际变更的字段（整体替换 vs 增量合并要能区分）。
          const a = args as {
            name?: string; tokens?: Record<string, unknown>; merge_tokens?: Record<string, unknown>
            knobs?: Record<string, unknown>; palette?: { seed?: string; mood?: string }
            css?: unknown[]; assets?: unknown[]; widgets?: Array<{ id?: string }>
            theme?: { id?: string }; clear_theme?: boolean
            cover?: { assetId?: string } | null; wallpaper_presence?: number
          }
          const changed: string[] = []
          if (a.name !== undefined) changed.push(`名称→「${a.name}」`)
          if (a.palette !== undefined) changed.push(`调色板 seed=${a.palette.seed ?? ''}${a.palette.mood !== undefined ? `（${a.palette.mood}）` : ''}`)
          if (a.knobs !== undefined) changed.push(`旋钮 ${Object.keys(a.knobs).join('、')}`)
          if (a.merge_tokens !== undefined) changed.push(`增量合并令牌 ${Object.keys(a.merge_tokens).length} 个（${Object.keys(a.merge_tokens).slice(0, 8).join('、')}${Object.keys(a.merge_tokens).length > 8 ? '…' : ''}）`)
          if (a.tokens !== undefined) changed.push(`整体替换令牌 ${Object.keys(a.tokens).length} 个`)
          if (a.css !== undefined) changed.push(`CSS 补丁 ${(a.css ?? []).length} 段`)
          if (a.widgets !== undefined) changed.push(`部件 ${(a.widgets ?? []).map(w => w.id).join('/') || '（清空）'}`)
          if (a.wallpaper_presence !== undefined) changed.push(`壁纸存在感→${a.wallpaper_presence}`)
          if (a.assets !== undefined) changed.push(`素材引用 ${(a.assets ?? []).length} 个`)
          if (a.cover !== undefined) changed.push(a.cover === null ? '清除封面' : `封面 ${a.cover.assetId ?? ''}`)
          if (a.clear_theme === true) changed.push('清除主题')
          else if (a.theme !== undefined) changed.push(`主题 ${a.theme.id ?? ''}`)
          return [{
            type: 'text',
            text: value.ok
              ? `已更新预设 ${value.id}${changed.length > 0 ? `（${changed.join('；')}）` : '（仅落盘，未提供变更字段）'}；旧版已备份`
              : '更新失败',
          }]
        },
      },
      execute: (args: {
        id: string; name?: string; tokens?: unknown; css?: unknown; merge_tokens?: unknown
        knobs?: unknown; palette?: unknown; assets?: unknown; widgets?: unknown; theme?: unknown; clear_theme?: boolean
        cover?: unknown; wallpaper_presence?: unknown
      }) => {
        // #111：palette/knobs 展开后并入增量层；显式 tokens 优先级最高（整体替换）
        const generated = mergeTokenSources(args.palette, args.knobs, undefined)
        let tokensPatch = args.tokens
        let mergePatch: Record<string, unknown> | undefined = args.merge_tokens as Record<string, unknown> | undefined
        if (args.tokens !== undefined) {
          tokensPatch = { ...generated, ...(mergePatch ?? {}), ...(args.tokens as Record<string, unknown>) }
          mergePatch = undefined
        } else if (Object.keys(generated).length > 0) {
          mergePatch = { ...generated, ...(mergePatch ?? {}) }
        }
        // #111：壁纸存在感——没给 widgets 时对预设现有部件批量生效
        let widgetsPatch = args.widgets
        if (args.wallpaper_presence !== undefined) {
          const baseWidgets = args.widgets ?? readLibraryPreset(env, args.id)?.widgets
          if (baseWidgets === undefined) throw new Error('wallpaper_presence: 预设没有壁纸部件，请同时提供 widgets')
          widgetsPatch = applyWallpaperPresence(baseWidgets, args.wallpaper_presence)
        }
        const id = updatePresetFile(env, args.id, {
          name: args.name, tokens: tokensPatch, css: args.css, mergeTokens: mergePatch,
          assets: args.assets, widgets: normalizeWidgetsCrop(env, widgetsPatch), theme: args.clear_theme === true ? null : args.theme,
          cover: args.cover,
        })
        // #63 P0-1：目标为当前活动预设 → 写 active.json（revision+1）驱动浏览器桥重应用——
        // 桥对"id 相同"也会重应用（applyPresetById 内部对已活动预设跳过重复持久化，防自激）。
        if (readActiveState(env).activePresetId === id) writeActiveState(env, id)
        return Promise.resolve({ ok: true, id })
      },
      presentCall: args => ({ card: 'generic', title: '更新预设', kind: 'other', rawInput: args }),
    }),
    defineTool({
      name: 'preset_delete',
      description: '删除一个用户预设（内置示例不可删）。若删除的是当前活动预设，外观自动还原为默认。',
      parameters: {
        id: { type: 'string', required: true, description: '目标预设 id' },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ok: { type: 'boolean', required: true },
            id: { type: 'string', required: true },
          },
        },
        render: (_args, value) => [{
          type: 'text',
          text: value.ok ? `已删除预设 ${value.id}` : '删除失败',
        }],
      },
      execute: (args: { id: string }) => {
        if (!safePresetId(args.id)) throw new Error('preset_delete: 非法 id')
        if (isDemoPreset(args.id)) throw new Error('preset_delete: 内置示例不可删除')
        deletePresetFile(env, args.id)
        // 删除活动预设 → 外观还原默认
        if (readActiveState(env).activePresetId === args.id) writeActiveState(env, null)
        return Promise.resolve({ ok: true, id: args.id })
      },
      presentCall: args => ({ card: 'generic', title: '删除预设', kind: 'other', rawInput: args }),
    }),
    defineTool({
      name: 'preset_revert',
      description: '还原默认外观（清除活动预设）：撤销之前 preset_apply 的效果，回到 DSH 出厂配色。',
      parameters: {},
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ok: { type: 'boolean', required: true },
          },
        },
        render: (_args, value) => [{
          type: 'text',
          text: value.ok ? '已还原默认外观' : '操作失败',
        }],
      },
      execute: () => {
        writeActiveState(env, null)
        return Promise.resolve({ ok: true })
      },
      presentCall: () => ({ card: 'generic', title: '还原默认外观', kind: 'other', rawInput: null }),
    }),
    defineTool({
      name: 'asset_list',
      description: '列出壁纸库已有素材（聊天背景/设置卡背景/侧栏海报可用的图片）：id/名称/mime/体积/像素尺寸——'
        + '设置部件（widgets）前先查这里，用返回的 id 引用素材（id 不能凭空编造）；'
        + 'cover/widgets 支持 focus/zoom（如 focus:[0.5,0.35]、zoom:1.2），服务端按 width/height 折算裁剪坐标；素材上传仍由用户在界面完成。',
      parameters: {},
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            assets: {
              type: 'array',
              required: true,
              items: {
                type: 'object',
                additionalProperties: false,
                properties: {
                  id: { type: 'string', required: true },
                  name: { type: 'string', required: true },
                  mime: { type: 'string', required: true },
                  size: { type: 'integer', required: true },
                  // #112：像素尺寸（读文件头；未知格式缺省）
                  width: { type: 'integer' },
                  height: { type: 'integer' },
                  // #96（审计）：分层合成壁纸（#90）的 layers 元数据随 listWallpaperAssets 输出——
                  // additionalProperties:false 下未声明键会让宿主输出校验抛错（测试 stub 掩盖）
                  layers: {
                    type: 'object',
                    additionalProperties: true,
                    properties: {
                      animAssetId: { type: 'string' },
                      x: { type: 'number' },
                      y: { type: 'number' },
                      w: { type: 'number' },
                      h: { type: 'number' },
                    },
                  },
                },
              },
            },
          },
        },
        render: (_args, value) => [{
          type: 'text',
          // #102：render 必须携带素材 id——LLM 看到的是 render 文本，原实现只拼中文文件名，
          // AI 拿不到合法标识符（实测只能翻磁盘目录找 id）
          text: value.assets.length === 0
            ? '壁纸库为空（素材上传由用户在界面完成）'
            : `壁纸库共 ${value.assets.length} 个素材（widgets 引用请用 id）：\n${value.assets
              .map((a: { id: string; name: string; mime: string; size: number; width?: number; height?: number }) =>
                `- ${a.id}：${a.name}（${a.mime}，${formatBytes(a.size)}${a.width !== undefined && a.height !== undefined ? `，${a.width}×${a.height}` : ''}）`)
              .join('\n')}`,
        }],
      },
      execute: () => Promise.resolve({ assets: listWallpaperAssets(env) }),
      presentCall: () => ({ card: 'generic', title: '列出壁纸库素材', kind: 'other', rawInput: null }),
    }),
    defineTool({
      name: 'preset_restore_backup',
      description: '把预设还原到备份版本（backup.json——覆盖保存/更新时自动保留的旧版；与界面「还原备份」同语义）：'
        + '**交换式还原**——当前版本自动存入备份（单层备份，可再还原回去）。'
        + '用于纠错：preset_update 改坏了可还原；preset_delete 删错了无法恢复（删除会连备份销毁，谨慎）。'
        + '若目标是当前生效的活动预设，还原后自动重新应用：界面即时生效。无备份/备份损坏会报错。',
      parameters: {
        id: { type: 'string', required: true, description: '目标预设 id（preset_list 返回）' },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ok: { type: 'boolean', required: true },
            id: { type: 'string', required: true },
            name: { type: 'string', required: true },
          },
        },
        render: (_args, value) => [{
          type: 'text',
          text: value.ok === true ? `已还原预设「${value.name}」（当前版本已存入备份）` : '还原失败',
        }],
      },
      execute: (args: { id: string }) => {
        const result = restoreBackupFile(env, args.id)
        // #63 同款：目标为活动预设 → revision+1 驱动桥重应用（界面即时生效）
        if (readActiveState(env).activePresetId === args.id) writeActiveState(env, args.id)
        return Promise.resolve({ ok: true, id: args.id, name: result.name })
      },
      presentCall: args => ({ card: 'generic', title: '还原预设备份', kind: 'other', rawInput: args }),
    }),
    defineTool({
      name: 'preset_palette',
      description: '按品牌色生成整套协调配色（#111）：给 seed（品牌色）+ mood（fresh/night/retro/mono）+ contrast（AA/AAA），'
        + '服务端派生背景/层次/文字/按钮/边框/状态/代码面等 40+ 令牌双值，并做对比度收敛（label 家族达到目标等级）。'
        + '返回 tokens 可直接传给 preset_create/update（也可再用 knobs/tokens 覆盖）；附带 preset_check 结果便于先看问题。',
      parameters: {
        seed: { type: 'string', required: true, description: '品牌色（hex/rgb，如 "#8A3A70"）' },
        mood: { type: 'string', description: '情绪风格：fresh（默认，清爽）/ night（深夜）/ retro（复古）/ mono（极简）' },
        contrast: { type: 'string', description: '文字对比度目标：AA（4.5，默认）/ AAA（7）' },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            tokens: { type: 'object', additionalProperties: true, required: true },
            issues: { type: 'array', required: true, items: { type: 'object', additionalProperties: true } },
            summary: { type: 'object', additionalProperties: true, required: true },
          },
        },
        render: (args, value) => {
          const entries = Object.entries(value.tokens as Record<string, { light: string; dark: string }>)
          const LIMIT = 40
          const shown = entries.slice(0, LIMIT)
          const lines = shown.map(([name, v]) => `- ${name}: light=${v.light} dark=${v.dark}`)
          const rest = entries.length - shown.length
          const issues = (value.issues ?? []) as Array<{ token: string; scheme?: string; severity: string; message: string }>
          const errorCount = issues.filter(i => i.severity === 'error').length
          return [{
            type: 'text',
            text: [
              `调色板：seed=${args.seed} mood=${args.mood ?? 'fresh'} contrast=${args.contrast ?? 'AA'} → ${entries.length} 个令牌`
                + (rest > 0 ? `（下列前 ${LIMIT} 条，还有 ${rest} 条；完整值请传 tokens 使用或再查 preset_get）` : ''),
              lines.join('\n'),
              `预检：${errorCount === 0 ? '无阻断问题' : `${errorCount} 个阻断`}，${issues.length} 条提示`,
              ...issues.map(i => `- [${i.severity}]${i.scheme !== undefined ? ` ${i.scheme}` : ''} ${i.token}：${String(i.message).replace(/\n/g, ' ')}`),
            ].join('\n'),
          }]
        },
      },
      execute: (args: { seed: string; mood?: string; contrast?: string }) => {
        const tokens = expandPaletteInput({ seed: args.seed, mood: args.mood, contrast: args.contrast })
        const result = precheckPreset(tokens as Record<string, unknown>)
        return Promise.resolve({ tokens, issues: result.issues, summary: result.summary })
      },
      presentCall: args => ({ card: 'generic', title: '生成调色板', kind: 'other', rawInput: args }),
    }),
    defineTool({
      name: 'preset_check',
      description: '质量预检（创建/更新预设前调用）：校验候选完整载荷（tokens/css/assets/widgets/theme，与 preset_create 同构——'
        + '通过 = 提供的字段必能落盘），并评估文字与按钮对比度（label 家族 vs 各组件面 + 按钮文字 vs 按钮填充，明暗各算；'
        + 'FAIL/仅大文本达标会提示，低对比可保存但建议调整——与界面徽标同语义）、未知令牌、明暗反转。'
        + '输出 issues 逐条说明（error=阻断 / warn=建议）。#111：支持 basePresetId + merge_tokens——在现有预设上做增量微调时，'
        + '不必把全量令牌重发一遍。',
      parameters: {
        tokens: {
          type: 'object',
          additionalProperties: true,
          description: '候选令牌 → { light, dark } 双值映射（可选；与 basePresetId 二选一，同时提供时 tokens 覆盖 base）',
        },
        basePresetId: {
          type: 'string',
          description: '可选：以该预设的现有令牌为基底（id 来自 preset_list；出厂/库预设均可）',
        },
        merge_tokens: {
          type: 'object',
          additionalProperties: true,
          description: '可选：在基底上增量合并的令牌（只覆盖提供的键）',
        },
        css: {
          type: 'array',
          description: '可选候选 CSS 补丁（与 preset_create 的 css 同格式；检查选择器白名单）',
        },
        assets: {
          type: 'array',
          description: '可选候选素材引用声明（与 preset_create 的 assets 同格式；校验结构）',
        },
        widgets: {
          type: 'array',
          description: '可选候选部件（与 preset_create 的 widgets 同格式；校验结构与引用）',
        },
        theme: {
          type: 'object',
          additionalProperties: true,
          description: '可选候选主题（与 preset_create 的 theme 同格式；校验结构）',
        },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            ok: { type: 'boolean', required: true },
            issues: {
              type: 'array',
              required: true,
              items: { type: 'object', additionalProperties: true },
            },
            summary: { type: 'object', additionalProperties: true, required: true },
          },
        },
        render: (_args, value) => {
          // #110：issues 全文输出——原实现只报「通过/未通过 + 条数」，模型看不到是哪条对比度
          // 不足、哪个令牌未知、哪条明暗反转，预检等于白跑。
          const issues = (value.issues ?? []) as Array<{ token: string; scheme?: string; severity: string; message: string }>
          const errors = issues.filter(i => i.severity === 'error')
          const warns = issues.filter(i => i.severity !== 'error')
          const head = value.ok === true
            ? `预检通过（${value.summary.tokenCount} 令牌${warns.length > 0 ? `，${warns.length} 条建议` : ''}）`
            : `预检未通过（${errors.length} 个阻断问题，${warns.length} 条建议）`
          const lines = issues.map(i =>
            `- [${i.severity}]${i.scheme !== undefined ? ` ${i.scheme}` : ''} ${i.token}：${String(i.message).replace(/\n/g, ' ')}`)
          return [{
            type: 'text',
            text: [head, ...(lines.length > 0 ? lines : ['（无问题）'])].join('\n'),
          }]
        },
      },
      execute: (args: {
        tokens?: unknown; basePresetId?: unknown; merge_tokens?: unknown
        css?: unknown; assets?: unknown; widgets?: unknown; theme?: unknown
      }) => {
        // #111：基底预设（库优先，其次出厂）+ 增量合并 + 显式 tokens（优先级最高）
        let baseTokens: Record<string, unknown> = {}
        if (typeof args.basePresetId === 'string' && args.basePresetId !== '') {
          const fromLibrary = readLibraryPreset(env, args.basePresetId)
          const demo = DEMO_PRESETS.find(item => item.id === args.basePresetId)
          const source = fromLibrary ?? demo
          if (source === null || source === undefined) throw new Error(`preset_check: basePresetId ${args.basePresetId} 不存在`)
          baseTokens = { ...(source.tokens as unknown as Record<string, unknown>) }
        }
        if (args.merge_tokens !== undefined && (typeof args.merge_tokens !== 'object' || args.merge_tokens === null || Array.isArray(args.merge_tokens))) {
          throw new Error('preset_check: merge_tokens 必须是令牌对象')
        }
        const mergePart = (args.merge_tokens ?? {}) as Record<string, unknown>
        const explicit = (args.tokens ?? {}) as Record<string, unknown>
        const merged = { ...baseTokens, ...mergePart, ...explicit }
        if (Object.keys(merged).length === 0) throw new Error('preset_check: 至少提供 tokens / basePresetId 之一')
        const result = precheckPreset(
          merged,
          Array.isArray(args.css) ? args.css as Array<{ selector: unknown; rules?: unknown }> : undefined,
          { assets: args.assets, widgets: args.widgets, theme: args.theme },
        )
        return Promise.resolve(result)
      },
      presentCall: args => ({ card: 'generic', title: '质量预检', kind: 'other', rawInput: args }),
    }),
  ]
}

/** 工具注册（零抛错契约：任何失败只 warn，不冒泡）。 */
export async function registerPresetTools(
  tools: { register(definition: unknown): () => void },
  env: ToolsEnv,
): Promise<Array<() => void>> {
  const disposers: Array<() => void> = []
  try {
    const { defineTool } = await import('@deepseek-ai/dsh-tools')
    const defs = createPresetToolDefs(env, defineTool as (definition: unknown) => unknown)
    for (const definition of defs) {
      disposers.push(tools.register(definition))
    }
    registered = true
    // #111：工具清单（新增 preset_palette）
    console.log('[wallpaper-plugin] AI 工具已注册（preset_list/apply/inspect/create/catalog/get/update/delete/revert/restore_backup/check/palette + asset_list）')
    return disposers
  } catch (error) {
    console.warn('[wallpaper-plugin] dsh-tools 不可用，AI 工具未注册（零抛错降级）：', error instanceof Error ? error.message : String(error))
    return disposers
  }
}
