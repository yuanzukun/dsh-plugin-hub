// M3-3 标准版打磨 e2e + #52 裁剪流：素材缩略图 + 一键设为聊天背景（→ 16:9 裁剪框 → 裁剪副本赋值）。
// 验证：缩略图真实渲染 → 快捷按钮弹裁剪框（固定比例/缩放/透明提示）→ 确认后裁剪副本入库并选中
// → 实时注入生效 → 保存落盘引用裁剪副本 → #103 删除分流（共享素材：仅从本预设移除 / 彻底删除）。
import { launchBrowser, dismissBetaNotice } from './e2e-util.mjs'

const BASE = process.argv[2] ?? 'http://127.0.0.1:3180'
// 1×1 透明 PNG
const PNG_BASE64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='

await fetch(`${BASE}/ui-presets/active`, {
  method: 'PUT',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ activePresetId: null }),
}).catch(() => {})
const existingList = await (await fetch(`${BASE}/ui-presets/presets`)).json()
for (const item of existingList.presets ?? []) {
  await fetch(`${BASE}/ui-presets/presets/${encodeURIComponent(item.id)}`, { method: 'DELETE' }).catch(() => {})
}

const browser = await launchBrowser()
const page = await browser.newPage()
let pass = 0
const check = (name, cond) => {
  console.log(`${cond ? 'PASS' : 'FAIL'} ${name}`)
  if (!cond) process.exitCode = 1
  if (cond) pass += 1
}
const errors = []
page.on('pageerror', e => errors.push('pageerror: ' + e.message))

await page.goto(BASE, { waitUntil: 'domcontentloaded', timeout: 60000 })
await page.getByRole('button', { name: '设置', exact: true }).waitFor({ timeout: 120000 })
  await dismissBetaNotice(page)
await page.getByRole('button', { name: '设置', exact: true }).click()
const dialog = page.getByRole('dialog', { name: '设置' })
await dialog.waitFor({ timeout: 30000 })
await dialog.getByRole('button', { name: '外观预设', exact: true }).click()
await dialog.getByRole('button', { name: '打开美化工作室 →' }).click()
const studio = page.locator('[data-up-studio]')
await studio.waitFor({ timeout: 10000 })
await studio.locator('[data-up-card]').first().waitFor({ timeout: 10000 })
await studio.locator('[data-up-card]', { hasText: '默认' }).first().getByRole('button', { name: '编辑' }).click()
await studio.getByLabel('预设名称').waitFor({ timeout: 10000 })

// 1. 上传素材 → 缩略图渲染
const assetInput = studio.locator('[data-up-widget-editor] input[type="file"]')
await assetInput.waitFor({ state: 'attached', timeout: 10000 })
await assetInput.setInputFiles({
  name: 'thumb.png',
  mimeType: 'image/png',
  buffer: Buffer.from(PNG_BASE64, 'base64'),
})
await studio.locator('[data-up-asset]').waitFor({ timeout: 10000 })
await page.waitForTimeout(400)
check('素材芯片出现（thumb.png）', (await studio.locator('[data-up-asset]').innerText()).includes('thumb.png'))
// #89：缩略图改为首帧 canvas（不再全量 <img> 解码动图）——等待首帧绘制完成
await page.waitForFunction(() => {
  const el = document.querySelector('[data-up-asset-thumb]')
  return el !== null && el.tagName === 'CANVAS' && el.width === 22
}, undefined, { timeout: 10000 }).catch(() => {})
const thumbInfo = await studio.locator('[data-up-asset-thumb]').evaluate(el => {
  return { tag: el.tagName, w: el.width, h: el.height }
})
check(`素材缩略图为首帧 canvas（${thumbInfo.tag} ${thumbInfo.w}×${thumbInfo.h}——不全量解码动图）`,
  thumbInfo.tag === 'CANVAS' && thumbInfo.w === 22 && thumbInfo.h === 22)
check('上传后未生效提示指向快捷按钮', (await studio.locator('[data-up-widget-editor] [data-up-status]').filter({ hasText: '尚未生效' }).innerText()).includes('设为聊天背景'))

// 2. 一键设为聊天背景 → 弹 16:9 裁剪框（#52）→ 缩放 → 确认 → 参数写入（#53 不落库）
// 新上传的芯片是列表最后一个（避免与库中遗留同名素材混淆）
await studio.locator('[data-up-asset]').last().getByRole('button', { name: '用 thumb.png 作聊天背景' }).click()
const crop = page.locator('[data-up-crop]')
await crop.waitFor({ timeout: 10000 })
const cropText = await crop.innerText()
check('裁剪框出现（聊天背景图 16:9 + 黑底应用范围提示）', cropText.includes('图片裁剪：聊天背景图')
  && cropText.includes('16:9') && cropText.includes('黑框内即实际应用范围'))
check('裁剪框外为黑底（应用范围外涂黑）', await page.evaluate(() => {
  const canvas = document.querySelector('[data-up-crop-canvas]')
  if (canvas === null) return false
  const wrap = canvas.parentElement
  return wrap !== null && getComputedStyle(wrap).backgroundColor === 'rgb(0, 0, 0)'
}))
await crop.getByLabel('缩放').evaluate(el => {
  const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set
  setter.call(el, '120')
  el.dispatchEvent(new Event('input', { bubbles: true }))
  el.dispatchEvent(new Event('change', { bubbles: true }))
})
await page.waitForTimeout(300)
check('缩放读数 120%', await crop.locator('[data-up-crop-zoom]').innerText() === '120%')
await crop.getByRole('button', { name: '确认裁剪' }).click()
await crop.waitFor({ state: 'detached', timeout: 15000 })
await page.waitForTimeout(600)
// #53：不生成裁剪副本；部件直接引用原图 + 裁剪参数
const chipTexts = (await studio.locator('[data-up-asset]').allTextContents()).join('\n')
check('不产生裁剪副本芯片', !chipTexts.includes('裁剪-'))
const chatSelect = studio.getByLabel('chat-background assetId')
check('聊天背景部件已自动启用且选中原图', (await chatSelect.inputValue()).length > 0
  && (await chatSelect.locator('option:checked').innerText()) === 'thumb.png')
check('原图芯片标记「✓ 聊天背景」', chipTexts.includes('✓ 聊天背景'))
// 未生效提示消失（部件已配置）
const hintCount = await studio.locator('[data-up-widget-editor] [data-up-status]').filter({ hasText: '尚未生效' }).count()
check('提示语消失（部件已配置）', hintCount === 0)

// 3. 实时注入生效（草稿即生效：裁剪标记 + controller 内联样式挂载壁纸 URL）
await page.waitForTimeout(400)
const patchStyle = await page.evaluate(() => document.querySelector('style[data-up-patch]')?.textContent ?? '')
check('裁剪标记已注入（up-crop:chat-background + 壁纸库 url）', patchStyle.includes('up-crop:chat-background')
  && patchStyle.includes('url("/ui-presets/assets/asset-'))
const convBg = await page.evaluate(() => {
  const el = document.querySelector('[data-conversation-scroll]')
  if (el === null) return { exists: false }
  return { exists: true, bgImage: getComputedStyle(el).backgroundImage.slice(0, 80) }
})
check(`聊天区背景真实生效（exists=${convBg.exists} bgImage=${convBg.bgImage}…）`,
  convBg.exists === true && convBg.bgImage.includes('/ui-presets/assets/asset-'))

// 4. 保存 → 落盘：chat-background 引用原图 + 裁剪参数（#53 无裁剪副本）
await studio.getByRole('button', { name: '保存' }).click()
await studio.locator('[data-up-studio-status]').getByText(/已另存为「默认（自定义）」/).waitFor({ timeout: 15000 })
const saved = await (await fetch(`${BASE}/ui-presets/presets/default-custom`)).json()
const preset = saved.preset ?? {}
const chatWidget = (preset.widgets ?? []).find(w => w.id === 'chat-background')
const sourceAsset = (preset.assets ?? []).find(a => a.id === chatWidget?.params.assetId)
check('落盘 chat-background 引用原图 + 裁剪参数', sourceAsset !== undefined && sourceAsset.name === 'thumb.png'
  && chatWidget?.params.cropX !== undefined && chatWidget?.params.cropW !== undefined)

// 5. #103 删除分流（用户实测反馈：共享素材被删 → 其他预设壁纸损坏）：先建第二个预设共享
//    同一素材 → UI 删除弹分流确认 → 「仅从本预设移除」→ 其他预设引用与文件保留；
//    再彻底删除 → 其他预设引用剥离 + 文件删除
const sharedId = chatWidget?.params?.assetId
check('#103 共享素材 id 可查（当前会话素材）', sharedId !== undefined)
if (sharedId !== undefined) {
  await fetch(`${BASE}/ui-presets/presets/asset-share-b`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      preset: {
        schemaVersion: 1, edition: 'standard', id: 'asset-share-b', name: '共享B',
        tokens: { '--dsw-alias-bg-base': { light: '#fff', dark: '#000' } },
        assets: [{ id: sharedId, name: 'thumb.png', mime: 'image/png' }],
        widgets: [{ id: 'chat-background', params: { assetId: sharedId, opacity: '1' } }],
      },
    }),
  })
  await studio.getByRole('button', { name: `删除素材 thumb.png` }).click()
  const choice = page.locator('[data-up-delete-choice]')
  await choice.waitFor({ timeout: 10000 })
  const choiceText = await choice.innerText()
  check(`#103 删除分流弹层出现（列出其他预设：${choiceText.includes('共享B') ? '共享B' : '？'}）`,
    choiceText.includes('1 个其他预设') && choiceText.includes('共享B'))
  await choice.getByRole('button', { name: '仅从本预设移除' }).click()
  await choice.waitFor({ state: 'detached', timeout: 10000 })
  await page.waitForTimeout(500)
  // 本预设草稿已剥离：部件引用清空 + chip 消失
  const chatSelect3 = studio.getByLabel('chat-background assetId')
  check('#103 detach 后本预设部件引用清空', (await chatSelect3.inputValue()) === '')
  const chipTextsAfterDetach = (await studio.locator('[data-up-asset]').allTextContents()).join('\n')
  check('#103 detach 后 chip 消失（批量更新生效）', !chipTextsAfterDetach.includes('thumb.png'))
  // 其他预设引用保留 + 文件保留
  const shareB = await (await fetch(`${BASE}/ui-presets/presets/asset-share-b`)).json()
  check('#103 detach 后其他预设引用保留',
    (shareB.preset?.assets ?? []).some(a => a.id === sharedId)
    && (shareB.preset?.widgets ?? []).some(w => w.params?.assetId === sharedId))
  const fileAfterDetach = await fetch(`${BASE}/ui-presets/assets/${sharedId}`)
  check('#103 detach 后文件保留（HTTP 200）', fileAfterDetach.status === 200)
  // 彻底删除 → 其他预设引用剥离 + 文件删除
  const globalDel = await fetch(`${BASE}/ui-presets/assets/${sharedId}`, { method: 'DELETE' })
  const shareB2 = await (await fetch(`${BASE}/ui-presets/presets/asset-share-b`)).json()
  const fileAfterGlobal = await fetch(`${BASE}/ui-presets/assets/${sharedId}`)
  check('#103 彻底删除后其他预设引用剥离 + 文件删除',
    globalDel.ok === true && (shareB2.preset?.assets ?? []).length === 0
    && fileAfterGlobal.status === 404)
  await fetch(`${BASE}/ui-presets/presets/asset-share-b`, { method: 'DELETE' }).catch(() => {})
}

// 6. #106 内容级去重（用户拍板：重复导入相同图片不存第二份）：
//    同字节二次上传 → 复用 id；zip 导入同内容不同 id → 引用改写为已有 id、不新增库条目
const dupBytes = Buffer.from(PNG_BASE64, 'base64')
const up1 = await fetch(`${BASE}/ui-presets/assets?name=dup-a.png&mime=image/png`, {
  method: 'PUT', headers: { 'content-type': 'image/png' }, body: dupBytes,
})
const up2 = await fetch(`${BASE}/ui-presets/assets?name=dup-b.png&mime=image/png`, {
  method: 'PUT', headers: { 'content-type': 'image/png' }, body: dupBytes,
})
const dup1 = await up1.json()
const dup2 = await up2.json()
check(`#106 同内容二次上传复用 id（${dup1.id} == ${dup2.id}，deduped=${dup2.deduped}）`,
  up1.ok && up2.ok && dup1.id === dup2.id && dup2.deduped === true)
const libAfterDup = await (await fetch(`${BASE}/ui-presets/assets`)).json()
check('#106 库中该内容仅一个条目', (libAfterDup.assets ?? []).filter(a => a.id === dup1.id).length === 1)
// zip 导入同内容（不同 id）→ 引用改写为已有 id（不新增库条目）
const { zipStore } = await import('../src/node/zip-util.ts')
const dupZip = zipStore([
  { name: 'preset.json', data: new TextEncoder().encode(JSON.stringify({
    schemaVersion: 1, id: 'dup-zip-preset', name: '去重导入', edition: 'standard',
    targetDshVersion: '0.1.0-rc.5',
    tokens: { '--dsw-alias-bg-base': { light: '#fff', dark: '#000' } },
    assets: [{ id: 'asset-dupzip-1', name: 'dup-b.png', mime: 'image/png', dataUrl: `data:image/png;base64,${PNG_BASE64}` }],
    widgets: [{ id: 'chat-background', params: { assetId: 'asset-dupzip-1', opacity: '1' } }],
  })) },
  { name: 'cover.svg', data: new TextEncoder().encode('<svg xmlns="http://www.w3.org/2000/svg"/>') },
  { name: 'manifest.json', data: new TextEncoder().encode(JSON.stringify({ id: 'dup-zip-preset', name: '去重导入' })) },
])
const dupZipRes = await fetch(`${BASE}/ui-presets/import-zip`, {
  method: 'POST', headers: { 'content-type': 'application/zip' }, body: Buffer.from(dupZip),
})
const dupZipBody = await dupZipRes.json()
check('#106 zip 导入成功', dupZipRes.ok && dupZipBody.id === 'dup-zip-preset')
const dupPreset = (await (await fetch(`${BASE}/ui-presets/presets/dup-zip-preset`)).json()).preset
check('#106 zip 导入素材引用改写为已有 id',
  (dupPreset.assets ?? []).some(a => a.id === dup1.id)
  && (dupPreset.widgets ?? []).some(w => w.params?.assetId === dup1.id))
const libAfterZip = await (await fetch(`${BASE}/ui-presets/assets`)).json()
check('#106 zip 导入未新增库条目', (libAfterZip.assets ?? []).filter(a => a.id === dup1.id).length === 1)
// 清理
await fetch(`${BASE}/ui-presets/presets/dup-zip-preset`, { method: 'DELETE' }).catch(() => {})
await fetch(`${BASE}/ui-presets/assets/${encodeURIComponent(dup1.id)}`, { method: 'DELETE' }).catch(() => {})

console.log(`\n${pass} checks passed`)
if (errors.length > 0) console.log('browser-errors: ' + JSON.stringify(errors.slice(0, 5)))
await browser.close()
process.exit(process.exitCode ?? 0)
