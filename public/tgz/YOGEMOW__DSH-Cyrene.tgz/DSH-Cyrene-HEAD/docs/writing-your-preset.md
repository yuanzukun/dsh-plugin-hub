# 怎么改自己的人设预设

随包已经带了一份可使用的人设（在 `preset/chat/agent.cordis.yml` 的 `prefix:` 里），
装完即可对话。这份文档写给**想换成自己的人设**的人：该往哪填、填什么、以及会踩的坑。

如果你不需要随包人设，直接清空或替换 `prefix:` 的内容即可——
本插件的装配机制不依赖具体人设。

## 1. 文件位置

0.4.0 起来源直接是仓库/安装包里的 `preset/<id>/`：

```
preset/
├── chat/                昔涟聊天模式
│   ├── preset.yml       模态元信息（名称、描述、排序）
│   └── agent.cordis.yml 人设全文 + 工具挂载
└── cyrene-work/         德谬歌工作模式
    ├── preset.yml
    └── agent.cordis.yml
```

0.4.0 起预设声明由包自带的 `cordis.patch.yml` 注册，所以**改完要重新生成补丁**，
再升级 / 重装插件并重启 DSH：

```bash
node scripts/build-bundle-patch.mjs
```

0.3.x 及更早才使用 `~/.dsh/.agent-presets/<id>/` 目录（改完即时生效）。

## 2. 往哪里填

`agent.cordis.yml` 里 `persona` 那条的 `prefix:` 就是系统提示词正文，
用 YAML 块标量（`|`）承载多行文本，**保持缩进一致**。

```yaml
- id: persona
  name: '@deepseek-ai/dsh-persona'
  config:
    complete: true
    includeRuntimeContext: false
    prefix: |
      你的人设正文写在这里。
      每一行都要比 prefix 多缩进，缩进错了 YAML 会解析失败。
```

写完可以用这条命令自查语法：

```bash
node -e "const Y=require('yaml');Y.parse(require('fs').readFileSync(process.argv[1],'utf8'));console.log('OK')" ~/.dsh/.agent-presets/chat/agent.cordis.yml
```

## 3. 建议人设包含哪几块

按经验，一份能稳定生效的人设至少要有这四块，缺哪块就会在哪块翻车：

| 块 | 作用 | 缺了会怎样 |
|---|---|---|
| **身份定位** | 你是谁、在和谁说话、什么关系 | 模型没有立场，回复发散 |
| **说话方式** | 语气、句长、口癖、称呼 | 角色感靠形容词撑不住 |
| **输出纪律** | 只输出要说的话、长度匹配、不写旁白 | 变成小说腔、动作描写、长篇铺陈 |
| **禁止行为** | 明确的负面清单 | 沿用默认助手腔（「有什么可以帮您」） |

**最容易漏的是输出纪律。** 只写"明亮、活泼、温柔"这类形容词，模型会退回一个通用的
"温柔助手"模板，出现环境描写开场、结尾强行抛问题、客服腔等问题。

## 4. `complete` 开不开

| 值 | 效果 |
|---|---|
| `true` | 这套提示词**就是全部**系统提示词。固定开场白 `You are an AI agent powered by DeepSeek Harness.`、工具规范、编码代理行为准则**全部被遮蔽**。人格纯度最高。 |
| `false` | 退化为叠加模式：你的提示词会加在固定开场白之后，但工具规范与编码代理准则仍在。角色容易漏出助手味。 |

默认给的是 `true`——这是本插件的核心价值。但**代价要清楚**：遮蔽工具规范后，
这个模式就不提供文件读写、Shell、设备控制等能力。

本仓库用**两套预设**来消化这个代价，而不是让你二选一：

| 目录 | 取舍 |
|---|---|
| `preset/chat/` | `complete: true` + 只挂少量工具 —— 人格纯度优先 |
| `preset/cyrene-work/` | 同样 `complete: true`，但把工具条目挂全 —— 干活时也保持人设 |

两者共享同一份长期记忆。**想只留一套就删掉另一个目录** —— 安装脚本是自动发现
`preset/` 下子目录的，删完不用改脚本。

（注意工作模式用的是上游的**轻量人设组**，不含 `soul.md`，语气会比对话模式淡一些。
这是上游的设计取舍，细节见 [`../THIRD_PARTY_NOTICES.md`](../THIRD_PARTY_NOTICES.md) 第 1 节。）

## 5. 工具挂载

文件末尾的 `tool-web` 条目决定这个模式能用什么工具：

```yaml
- id: tool-web
  name: '@deepseek-ai/dsh-tool-web'
  config:
    fetch: true
    searchTimeoutMs: 60000
```

- 想彻底禁止联网：删掉这个条目。
- 想加别的工具：**不建议在这里堆**。`complete: true` 会遮蔽第一方工具规范，
  模型未必知道新工具怎么调；而且能力面越大，角色越容易跑偏。
  需要工具的场景更适合另建一个带工具的预设。

## 6. 常见问题

**改了没生效** —— 0.4.0+：确认改的是仓库里的 `preset/<id>/`，并运行
`node scripts/build-bundle-patch.mjs` 重新生成补丁、重装 / 重启。改
`~/.dsh/.agent-presets/` 只对 0.3.x 及更早有效。

**模式选择器里没有这个预设** —— 0.4.0+ 先确认 DSH >= 0.2.0 并重启一次；
0.3.x 及更早才需要跑 `scripts/install.*`。

**还是有助手口气** —— 检查 `complete` 是不是被改成 `false` 了。

**回复变成小说** —— 输出纪律那块没写死。参考模板里「只输出要说的话」一节，
把禁止项逐条列出来比写"要自然"有效得多。

**YAML 解析失败** —— 多行块标量的缩进不一致，或者人设正文里出现了行首的
`- `／`#` 等被当成 YAML 语法的内容。用 `|` 块标量并按上面命令自查。

## 7. 如果你要发布自己的预设

**不要**把游戏内文本、他人创作的角色卡或美术资源打包进公开仓库。
引用他人开源人设时遵守其许可、保留署名，并自行确认再分发条款。
涉及游戏角色 IP 的衍生物通常禁止商业使用——详见仓库的
[`THIRD_PARTY_NOTICES.md`](../THIRD_PARTY_NOTICES.md)。
