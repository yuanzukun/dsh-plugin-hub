# Changelog

## 0.3.7 - 2026-10-15

- Adapt to Harness 0.2.1-alpha.3. Peer ranges also accept 0.2.0-rc.2, 0.1.5-rc.2, and the 0.1.1-rc.2 baseline.
- Resolve 0.2 Medium icons first and fall back to the 0.1 icon names, so one externalized client bundle loads on both hosts.
- Accept Cordis 4.0.5-alpha alongside ^4.0.1. The invariant companion stays optional because 0.2.1 no longer publishes @deepseek-ai/dsh-invariants.
- Remote codecs keep the 0.1 schema field and add the 0.2 create() factory.
- Probe messages keep their plugin attribution on hosts that no longer declare a plugin message source.

## 0.3.6 - 2026-09-11

- Adapt to Harness 0.1.5-rc.2 while retaining 0.1.1-rc.2 baseline coverage.
- Remove retired client runtime dependencies from Web plugins; preserve official Slot APIs.
- Add explicit compatibility guidance for downloadable archives.

## 0.3.1 - 2026-08-21

- Validate types, tests, builds, and package contents against DeepSeek Harness `0.1.1-rc.1`.
- Retain a peer compatibility branch for DeepSeek Harness `0.1.0-rc.6` through `rc.8`.

## 0.3.0 - 2026-08-19

### 简体中文

- 根据明确的 HTTP 状态、错误代码和错误文本分类常见失败，不进行猜测式自动修复。
- 在失败结果中显示本地化的下一步排查建议。
- 在脱敏诊断报告中加入失败类别和同一条建议，便于提交 Issue 或 Discussion。
- 为分类规则、Host/Client 契约和报告内容补充单元测试。

### English

- Classify common failures from explicit HTTP statuses, error codes, and recognizable messages without speculative automatic fixes.
- Show a localized next-step suggestion in failed probe results.
- Include the failure category and the same guidance in copied redacted diagnostics.
- Add unit coverage for classification, Host/Client contracts, and reports.

## 0.2.0 - 2026-08-19

- Show the active model route's declared text and image input capabilities.
- Keep manually entered or undisclosed model capabilities explicitly unknown.
- Add one-click, paste-ready diagnostics using already-redacted probe results.
- Keep capability display passive: no image request, attachment, background check, or added charge.

## 0.1.0 - 2026-08-19

- Add manual provider/model connectivity probes.
- Report first-token and total latency, finish reason, and token usage.
- Add cancellation, a hard timeout, and a one-probe concurrency guard.
- Redact common secrets and home paths from provider errors.
- Add localized Chinese and English settings UI.
