import type {} from '@deepseek-ai/dsh-commands'
import type { CommandId } from '@deepseek-ai/dsh-commands/brand'
import type { SessionEvent } from '@deepseek-ai/dsh-session/types'
import type { ConversationNodeDefinition } from '@deepseek-ai/dsh-client-ui-conversation/client'

/** Human-entered `/graphify` command projected into the DSH Web conversation. */
export interface GraphifyCommandInputData {
  readonly commandId: CommandId
  readonly text: string
  readonly time: number
}

declare module '@deepseek-ai/dsh-client-ui-chat/client' {
  interface ChatNodeDataMap {
    /** Human-entered `/graphify` command input. */
    'graphify-command-input': GraphifyCommandInputData
  }
}

interface GraphifyCommandInputState extends GraphifyCommandInputData {
  readonly seq: number
}

/**
 * Derives the visible command line from its durable structured run.
 * @param event - `/graphify` command run.
 * @returns Command text with trailing parser whitespace removed.
 */
export function graphifyCommandText(event: SessionEvent<'command/run'>): string {
  return `/${event.data.name}${(event.data.args ?? '').trimEnd()}`
}

/** Graphify-owned command input projection; DSH retains the generic result row. */
export const graphifyCommandInputDefinition: ConversationNodeDefinition<GraphifyCommandInputState> = {
  kind: 'graphify-command-input',
  target: 'chat',
  match: (event) => event.type === 'command/run' && event.data.name === 'graphify'
    ? { id: String(event.data.commandId), role: 'start' }
    : null,
  start: (_context, match) => {
    const event = match.event
    if (event.type !== 'command/run') {
      throw new Error('graphify-command-input start requires command/run')
    }
    return {
      commandId: event.data.commandId,
      seq: event.seq,
      time: event.time,
      text: graphifyCommandText(event),
    }
  },
  update: (context) => context.state,
  buildViewNode: (context) => {
    if (context.state === undefined) return null
    return {
      key: context.key,
      kind: 'graphify-command-input',
      id: context.id,
      target: 'chat',
      anchorSeq: context.state.seq - 0.1,
      location: context.start?.location ?? { kind: 'unresolved' },
      visibility: 'visible',
      data: {
        commandId: context.state.commandId,
        text: context.state.text,
        time: context.state.time,
      },
    }
  },
}
