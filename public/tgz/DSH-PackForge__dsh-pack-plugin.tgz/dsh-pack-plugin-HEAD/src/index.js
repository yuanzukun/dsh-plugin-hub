// DSH host 插件入口（cordis 面）—— 纯方案 B：仅 UI + 后端，不做 AI 驱动。
//
// 契约（已从官方源码确证）：
//   - 第三方 bundle 的宿主→客户端直连 RPC 只能自己 inject webServer 挂前缀路由
//     （ctx.connection.rpc.handle 在官方实现里 owner 绑死 connection 自身 ctx，拿不到
//     webServer，会抛错；/api 拦截又被 gateway 独占）—— 详见 rpc.js 顶部注释。
//   - ctx.profileContext 直接给出 home/当前 profile 事实（零猜路径）。
import { resolveRuntime } from './runtime.js';
import { registerRpc } from './rpc.js';
import { registerBall } from './ball-host.js';
import { getHost } from './host.js';
import { readState } from './profiles.js';
import { createDspackSkillProvider } from './skills/index.js';

export const name = 'dspack-host';

export const inject = ['connection', 'webServer', 'skills'];

export function apply(ctx) {
  // UI ↔ 后端直连 RPC（设置面板按钮走这里，静默、不进聊天栏）。
  const runtime = resolveRuntime(ctx);
  registerRpc(ctx, runtime);
  // 悬浮球：绕过设置页/侧边栏的独立入口（整合包把侧边栏搞坏时仍进得来）。
  // 注入行须尽早注册 —— 桌面壳的注入表是宿主启动时一次性收集的。
  registerBall(ctx);
  // 启动时把已存配置里的代理地址应用到 NodeHost（设置项覆盖环境变量）；读不到/异常不阻塞启动。
  void (async () => {
    try {
      const state = await readState(runtime.home);
      getHost().setProxy(state?.config?.proxy);
    } catch { /* 忽略 */ }
  })();
  // 注册自定义 skill 提供者：把 publish-to-github 送进模型 skill catalog（不走磁盘）。
  // registerProvider 返回 disposer，yield 给 effect 以在插件卸载时反注册。
  ctx.effect(
    () => ctx.skills.registerProvider(() => createDspackSkillProvider()),
    'dspack: skill',
  );
}
