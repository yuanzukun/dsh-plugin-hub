// DSH-PackForge core 公共 API（供 CLI / GUI / 插件以编程方式调用）。
export { Host } from './host.js';
export { isExcluded } from './security.js';
export { scanProfile, selectFiles } from './scan.js';
export { summarizeSpecial } from './special.js';
export {
  buildManifest,
  buildHomeManifest,
  validateManifest,
  validateFileEntry,
  coordsToPkgDeps,
  pkgDepsToCoords,
  coordinatesFromProfileDeps,
  gitCommitFromLock,
  isExactSemver,
  parseGitCoord,
  parsePkgGitSpec,
  resolveLocale,
  isLocaleString,
  extractBundles,
  extractDependencies,
  sanitizeSlug,
  normalizeLaunchers,
  compareLauncherVersions,
} from './manifest.js';
export {
  discoverProfiles,
  discoverHomes,
  listInstalledDshVersions,
  resolveProfileInput,
  skipProfileDir,
  compareVersions,
  sortVersionsDesc,
} from './discovery.js';
export { buildDspack, parseDspack, encodeText, decodeText, dspackMarker, DSPACK_FORMAT, DSPACK_CONTAINER_VERSION } from './dspack.js';
export { packProfile, packHome, dspackEntryPath, summarizeHome } from './pack.js';
export { exportRepo, ReleaseConflictError, renderReadme, renderDspackIgnore, renderGitignore, REPO_CONTENT_LEVELS, REPO_CONTENT_LABEL } from './repo.js';
export { loadWorkspaceConfig, saveWorkspaceConfig, WORKSPACE_KEYS, exportFromWorkspace, exportHomeFromWorkspace } from './workspace.js';
export { inspectProfile, inspectHome, inspectPack } from './inspect.js';
export { installPack, verifyIntegrity, reconcileProfile, resolvePackSource, resolveDshVersion, judgeLaunchers } from './install.js';
export {
  resolveVendoredPlan,
  isDialectSpec,
  directMount,
  materializeVendorBlobs,
  blobRelPath,
  coordDirName,
  allDependencyCoords,
  lockfilePackageNames,
  computeOfflineCoverage,
  listProfileDependencies,
  collectVendoredForExport,
  coordFromDirName,
  repackageFromNodeModules,
} from './vendored.js';
export { untar, buildTarball } from './tar.js';
export { readMarketIndex, fetchMarketPackDetail, normalizeMarketPack, packDirId, DEFAULT_MARKET_INDEX, pickR2Fields, r2Badges, parseLaunchersRegistry, fetchLaunchersRegistry, DEFAULT_LAUNCHERS_REGISTRY_URL, BUILTIN_LAUNCHERS } from './market.js';