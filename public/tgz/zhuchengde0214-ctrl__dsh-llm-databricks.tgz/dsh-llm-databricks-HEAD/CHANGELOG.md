# Changelog

All notable changes follow [Keep a Changelog](https://keepachangelog.com/) and
this project uses [Semantic Versioning](https://semver.org/).

## [0.1.0] - 2026-08-18

### Added

- MLflow Chat Completions and MLflow Responses routes.
- Native Anthropic Messages with bearer-only authentication.
- Native OpenAI Responses with bearer authentication.
- Streaming, tool calls, reasoning metadata, credential references, live
  settings, strict destination validation, retry metadata, and focused tests.
- Native Anthropic routes omit unsupported temperature sampling parameters.
- English and Chinese documentation, CI, and reproducible package checks.
