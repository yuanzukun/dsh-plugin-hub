import { describe, expect, it } from 'vitest'
import { bearerHeaders, sanitizePayload } from '../src/payload.js'

describe('Databricks request shaping', () => {
  it.each(['mlflow-chat', 'mlflow-responses'] as const)(
    'removes store and strict for %s without mutating the source',
    (protocol) => {
      const original = {
        model: 'example-model',
        store: false,
        tools: [
          {
            type: 'function',
            function: {
              name: 'first_tool',
              strict: false,
              parameters: {
                type: 'object',
                properties: { strict: { type: 'boolean' } },
                required: ['strict'],
              },
            },
          },
          {
            type: 'function',
            function: {
              name: 'second_tool',
              strict: true,
              parameters: { type: 'object' },
            },
            strict: false,
          },
        ],
      }

      const sanitized = sanitizePayload(protocol, original)
      expect(sanitized).toEqual({
        model: 'example-model',
        tools: [
          {
            type: 'function',
            function: {
              name: 'first_tool',
              parameters: {
                type: 'object',
                properties: { strict: { type: 'boolean' } },
                required: ['strict'],
              },
            },
          },
          {
            type: 'function',
            function: {
              name: 'second_tool',
              parameters: { type: 'object' },
            },
          },
        ],
      })
      expect(original.store).toBe(false)
      expect(original.tools[0]?.function.strict).toBe(false)
    },
  )

  it('uses bearer-only authentication for Anthropic', () => {
    const headers = bearerHeaders('anthropic-messages', 'unit-test-credential', {
      'x-api-key': 'must-be-removed',
    })
    expect(headers.get('authorization')).toBe('Bearer unit-test-credential')
    expect(headers.has('x-api-key')).toBe(false)
  })
})
