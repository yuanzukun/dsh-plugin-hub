import { describe, expect, it } from 'vitest'
import {
  assertRequestDestination,
  isOfficialDatabricksHost,
  routeUrls,
  validateWorkspaceUrl,
} from '../src/security.js'

describe('Databricks destination policy', () => {
  it.each([
    'dbc-example.cloud.databricks.com',
    'adb-example.azuredatabricks.net',
    'workspace.gcp.databricks.com',
    'legacy.databricks.net',
  ])('accepts official workspace host %s', (host) => {
    expect(isOfficialDatabricksHost(host)).toBe(true)
    expect(validateWorkspaceUrl(`https://${host}`).hostname).toBe(host)
  })

  it.each([
    'cloud.databricks.com.evil.example',
    'notdatabricks.net',
    'azuredatabricks.net.evil.example',
    'databricks.com',
  ])('rejects lookalike or non-workspace host %s', (host) => {
    expect(isOfficialDatabricksHost(host)).toBe(false)
    expect(() => validateWorkspaceUrl(`https://${host}`)).toThrow(/official Databricks host/)
  })

  it('rejects HTTP, userinfo, paths, and nonstandard official ports', () => {
    expect(() => validateWorkspaceUrl('http://dbc-example.cloud.databricks.com')).toThrow(
      /HTTPS/,
    )
    expect(() =>
      validateWorkspaceUrl('https://user@dbc-example.cloud.databricks.com'),
    ).toThrow(/userinfo/)
    expect(() =>
      validateWorkspaceUrl('https://dbc-example.cloud.databricks.com/a'),
    ).toThrow(/only the workspace origin/)
    expect(() =>
      validateWorkspaceUrl('https://dbc-example.cloud.databricks.com:8443'),
    ).toThrow(/port 443/)
  })

  it('requires explicit custom-host and custom-port opt-ins', () => {
    expect(() => validateWorkspaceUrl('https://gateway.example.invalid')).toThrow(
      /allowCustomHost/,
    )
    expect(
      validateWorkspaceUrl('https://gateway.example.invalid', { allowCustomHost: true })
        .hostname,
    ).toBe('gateway.example.invalid')
    expect(() =>
      validateWorkspaceUrl('https://gateway.example.invalid:8443', {
        allowCustomHost: true,
      }),
    ).toThrow(/allowNonStandardPort/)
    expect(
      validateWorkspaceUrl('https://gateway.example.invalid:8443', {
        allowCustomHost: true,
        allowNonStandardPort: true,
      }).port,
    ).toBe('8443')
  })

  it('pins each protocol to its exact gateway request path', () => {
    const workspace = new URL('https://dbc-example.cloud.databricks.com')
    const chat = routeUrls(workspace, 'mlflow-chat')
    expect(chat.requestPath).toBe('/ai-gateway/mlflow/v1/chat/completions')
    expect(() =>
      assertRequestDestination(
        'https://dbc-example.cloud.databricks.com/ai-gateway/mlflow/v1/chat/completions',
        workspace,
        chat.requestPath,
      ),
    ).not.toThrow()
    expect(() =>
      assertRequestDestination(
        'https://dbc-example.cloud.databricks.com.evil.example/ai-gateway/mlflow/v1/chat/completions',
        workspace,
        chat.requestPath,
      ),
    ).toThrow(/refusing/)
    expect(() =>
      assertRequestDestination(
        'https://dbc-example.cloud.databricks.com/ai-gateway/openai/v1/responses',
        workspace,
        chat.requestPath,
      ),
    ).toThrow(/refusing/)
  })
})
