import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  createUserMessage,
  QUOTA_EXCEEDED_CODE,
  type StreamChunk,
} from '@deepseek-ai/dsh-llm'
import { DatabricksAdapter } from '../src/adapter.js'
import { resolveRoutes } from '../src/config.js'
import { buildPiProfile } from '../src/provider.js'

function adapter(): DatabricksAdapter {
  const route = resolveRoutes({
    providers: {
      'databricks-test': {
        workspaceUrl: 'https://gateway.example.invalid:8443',
        protocol: 'mlflow-chat',
        allowCustomHost: true,
        allowNonStandardPort: true,
        models: [
          {
            id: 'example-model',
            contextWindow: 128_000,
            maxTokens: 8_192,
          },
        ],
      },
    },
  }).get('databricks-test')!
  const profile = buildPiProfile(route)
  return new DatabricksAdapter({
    profiles: () => new Map([['databricks-test', profile]]),
    resolveApiKey: () => Promise.resolve('unit-test-credential'),
  })
}

async function finish(adapterInstance: DatabricksAdapter): Promise<Extract<StreamChunk, { type: 'finish' }>> {
  let terminal: Extract<StreamChunk, { type: 'finish' }> | undefined
  for await (const chunk of adapterInstance.stream({
    provider: 'databricks-test',
    model: 'example-model',
    messages: [
      createUserMessage({
        content: [{ type: 'text', text: 'hello' }],
        source: { kind: 'user' },
      }),
    ],
  })) {
    if (chunk.type === 'finish') terminal = chunk
  }
  if (terminal === undefined) throw new Error('missing terminal chunk')
  return terminal
}

afterEach(() => {
  vi.unstubAllGlobals()
})

describe('Databricks error mapping', () => {
  it('preserves quota retry metadata without exposing credentials', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(() =>
        Promise.resolve(
          new Response(
            JSON.stringify({
              error: {
                message: 'Workspace input tokens per minute quota exceeded',
                type: 'rate_limit_error',
              },
            }),
            {
              status: 429,
              headers: {
                'content-type': 'application/json',
                'retry-after': '7',
                'x-databricks-request-id': 'request-example',
              },
            },
          ),
        ),
      ),
    )

    const terminal = await finish(adapter())
    expect(terminal.reason.kind).toBe('error')
    if (terminal.reason.kind !== 'error') throw new Error('expected error')
    expect(terminal.reason.failure).toMatchObject({
      code: QUOTA_EXCEEDED_CODE,
      status: 429,
      providerRetryAfterMs: 7_000,
      requestId: 'request-example',
    })
    expect(terminal.reason.failure.message).not.toContain('unit-test-credential')
  })

  it.each([
    [401, 'AUTH'],
    [403, 'AUTH'],
    [503, 'SERVER'],
  ])('maps HTTP %s to %s', async (status, code) => {
    vi.stubGlobal(
      'fetch',
      vi.fn(() =>
        Promise.resolve(
          new Response(JSON.stringify({ error: { message: 'mock provider error' } }), {
            status,
            headers: { 'content-type': 'application/json' },
          }),
        ),
      ),
    )
    const terminal = await finish(adapter())
    if (terminal.reason.kind !== 'error') throw new Error('expected error')
    expect(terminal.reason.failure).toMatchObject({ code, status })
  })

  it('does not misclassify a bodyless 400 as context overflow', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(() => Promise.resolve(new Response(null, { status: 400 }))),
    )
    const terminal = await finish(adapter())
    if (terminal.reason.kind !== 'error') throw new Error('expected error')
    expect(terminal.reason.failure.code).toBe('INVALID_REQUEST')
    expect(terminal.reason.failure.status).toBe(400)
  })

  it.each([
    [400, 'context_length_exceeded', 'CONTEXT_WINDOW_EXCEEDED'],
    [429, 'insufficient_balance', QUOTA_EXCEEDED_CODE],
  ])('preserves structured %s error classification for %s', async (status, code, expected) => {
    vi.stubGlobal(
      'fetch',
      vi.fn(() =>
        Promise.resolve(
          new Response(JSON.stringify({ error: { message: code, code } }), {
            status,
            headers: { 'content-type': 'application/json' },
          }),
        ),
      ),
    )
    const terminal = await finish(adapter())
    if (terminal.reason.kind !== 'error') throw new Error('expected error')
    expect(terminal.reason.failure.code).toBe(expected)
  })
})
