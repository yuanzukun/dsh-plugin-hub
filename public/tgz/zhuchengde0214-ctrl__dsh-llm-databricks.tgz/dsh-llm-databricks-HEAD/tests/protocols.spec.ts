import { afterEach, describe, expect, it, vi } from 'vitest'
import { Type, type AssistantMessageEvent, type Context } from '@earendil-works/pi-ai'
import { resolveRoutes } from '../src/config.js'
import { buildDatabricksProvider } from '../src/provider.js'
import type { DatabricksProtocol } from '../src/types.js'

const context: Context = {
  messages: [
    {
      role: 'user',
      content: [{ type: 'text', text: 'Use a tool if needed.' }],
      timestamp: 0,
    },
  ],
  tools: [
    {
      name: 'lookup_weather',
      description: 'Look up weather',
      parameters: Type.Object({ city: Type.String() }),
    },
    {
      name: 'lookup_time',
      description: 'Look up local time',
      parameters: Type.Object({ timezone: Type.String() }),
    },
  ],
}

function route(protocol: DatabricksProtocol) {
  return resolveRoutes({
    providers: {
      'databricks-test': {
        workspaceUrl: 'https://gateway.example.invalid:8443',
        protocol,
        allowCustomHost: true,
        allowNonStandardPort: true,
        models: [
          {
            id: 'example-model',
            contextWindow: 128_000,
            maxTokens: 8_192,
          },
        ],
      },
    },
  }).get('databricks-test')!
}

async function requestBody(input: RequestInfo | URL, init?: RequestInit): Promise<unknown> {
  if (input instanceof Request) return JSON.parse(await input.clone().text())
  return JSON.parse(String(init?.body))
}

async function collect(stream: AsyncIterable<AssistantMessageEvent>): Promise<AssistantMessageEvent[]> {
  const events: AssistantMessageEvent[] = []
  for await (const event of stream) events.push(event)
  return events
}

function chatSse(): Response {
  const chunks = [
    {
      id: 'chatcmpl-example',
      object: 'chat.completion.chunk',
      created: 0,
      model: 'example-model',
      choices: [{ index: 0, delta: { role: 'assistant', content: 'hello' }, finish_reason: null }],
    },
    {
      id: 'chatcmpl-example',
      object: 'chat.completion.chunk',
      created: 0,
      model: 'example-model',
      choices: [{ index: 0, delta: {}, finish_reason: 'stop' }],
      usage: { prompt_tokens: 5, completion_tokens: 1, total_tokens: 6 },
    },
  ]
  const body = `${chunks.map((chunk) => `data: ${JSON.stringify(chunk)}\n\n`).join('')}data: [DONE]\n\n`
  return new Response(body, { headers: { 'content-type': 'text/event-stream' } })
}

function anthropicSse(): Response {
  const events = [
    ['message_start', { type: 'message_start', message: { id: 'msg_example', type: 'message', role: 'assistant', model: 'example-model', content: [], stop_reason: null, stop_sequence: null, usage: { input_tokens: 5, output_tokens: 0 } } }],
    ['content_block_start', { type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } }],
    ['content_block_delta', { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: 'hello' } }],
    ['content_block_stop', { type: 'content_block_stop', index: 0 }],
    ['message_delta', { type: 'message_delta', delta: { stop_reason: 'end_turn', stop_sequence: null }, usage: { output_tokens: 1 } }],
    ['message_stop', { type: 'message_stop' }],
  ]
  const body = events
    .map(([event, data]) => `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`)
    .join('')
  return new Response(body, { headers: { 'content-type': 'text/event-stream' } })
}

afterEach(() => {
  vi.unstubAllGlobals()
})

describe('protocol request adapters', () => {
  it('streams MLflow Chat with two tools and no store/strict fields', async () => {
    let capturedBody: any
    let capturedHeaders: Headers | undefined
    vi.stubGlobal(
      'fetch',
      vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
        capturedBody = await requestBody(input, init)
        capturedHeaders = new Headers(input instanceof Request ? input.headers : init?.headers)
        return chatSse()
      }),
    )

    const provider = buildDatabricksProvider(route('mlflow-chat'))
    const model = provider.getModels()[0]!
    const events = await collect(
      provider.streamSimple(model, context, {
        apiKey: 'unit-test-credential',
      }),
    )

    expect(capturedBody.tools).toHaveLength(2)
    expect(capturedBody.store).toBeUndefined()
    expect(capturedBody.tools.every((tool: any) => tool.function.strict === undefined)).toBe(true)
    expect(capturedHeaders?.get('authorization')).toBe('Bearer unit-test-credential')
    expect(events.some((event) => event.type === 'text_delta')).toBe(true)
    expect(events.at(-1)?.type).toBe('done')
  })

  it('streams native Anthropic with bearer-only auth and two tools', async () => {
    let capturedBody: any
    let capturedHeaders: Headers | undefined
    vi.stubGlobal(
      'fetch',
      vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
        capturedBody = await requestBody(input, init)
        capturedHeaders = new Headers(input instanceof Request ? input.headers : init?.headers)
        return anthropicSse()
      }),
    )

    const provider = buildDatabricksProvider(route('anthropic-messages'))
    const model = provider.getModels()[0]!
    const events = await collect(
      provider.streamSimple(model, context, {
        apiKey: 'unit-test-credential',
        temperature: 0,
      }),
    )

    expect(capturedBody.tools).toHaveLength(2)
    expect(capturedBody.temperature).toBeUndefined()
    expect(capturedHeaders?.get('authorization')).toBe('Bearer unit-test-credential')
    expect(capturedHeaders?.has('x-api-key')).toBe(false)
    expect(events.some((event) => event.type === 'text_delta')).toBe(true)
    expect(events.at(-1)?.type).toBe('done')
  })

  it.each([
    ['mlflow-responses', '/ai-gateway/mlflow/v1/responses', true],
    ['openai-responses', '/ai-gateway/openai/v1/responses', false],
  ] as const)('targets %s at the pinned Responses path', async (protocol, path, stripsStore) => {
    let capturedUrl = ''
    let capturedBody: any
    vi.stubGlobal(
      'fetch',
      vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
        capturedUrl = input instanceof Request ? input.url : input.toString()
        capturedBody = await requestBody(input, init)
        return new Response(
          JSON.stringify({ error: { message: 'mock invalid request', type: 'invalid_request_error' } }),
          {
            status: 400,
            headers: { 'content-type': 'application/json' },
          },
        )
      }),
    )

    const provider = buildDatabricksProvider(route(protocol))
    const model = provider.getModels()[0]!
    await collect(
      provider.streamSimple(model, context, {
        apiKey: 'unit-test-credential',
      }),
    )

    expect(new URL(capturedUrl).pathname).toBe(path)
    expect(capturedBody.tools).toHaveLength(2)
    expect(capturedBody.store === undefined).toBe(stripsStore)
  })
})
