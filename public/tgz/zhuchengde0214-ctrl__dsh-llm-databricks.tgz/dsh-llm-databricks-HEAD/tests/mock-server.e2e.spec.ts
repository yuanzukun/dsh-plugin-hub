import { createServer } from 'node:https'
import { afterEach, describe, expect, it } from 'vitest'
import selfsigned from 'selfsigned'
import type { AssistantMessageEvent, Context } from '@earendil-works/pi-ai'
import { resolveRoutes } from '../src/config.js'
import { buildDatabricksProvider } from '../src/provider.js'

const previousTlsSetting = process.env.NODE_TLS_REJECT_UNAUTHORIZED

afterEach(() => {
  if (previousTlsSetting === undefined) delete process.env.NODE_TLS_REJECT_UNAUTHORIZED
  else process.env.NODE_TLS_REJECT_UNAUTHORIZED = previousTlsSetting
})

describe('HTTPS mock gateway', () => {
  it('streams through a non-default custom port without touching a real workspace', async () => {
    const certificate = await selfsigned.generate(
      [{ name: 'commonName', value: 'localhost' }],
      { days: 1, keySize: 2048 },
    )
    let receivedPath = ''
    let receivedAuthorization = ''
    const server = createServer(
      { key: certificate.private, cert: certificate.cert },
      (request, response) => {
        receivedPath = request.url ?? ''
        receivedAuthorization = request.headers.authorization ?? ''
        response.writeHead(200, { 'content-type': 'text/event-stream' })
        response.end(
          [
            `data: ${JSON.stringify({
              id: 'chatcmpl-mock',
              object: 'chat.completion.chunk',
              created: 0,
              model: 'example-model',
              choices: [
                {
                  index: 0,
                  delta: { role: 'assistant', content: 'mock-ok' },
                  finish_reason: null,
                },
              ],
            })}\n\n`,
            `data: ${JSON.stringify({
              id: 'chatcmpl-mock',
              object: 'chat.completion.chunk',
              created: 0,
              model: 'example-model',
              choices: [{ index: 0, delta: {}, finish_reason: 'stop' }],
              usage: { prompt_tokens: 2, completion_tokens: 1, total_tokens: 3 },
            })}\n\n`,
            'data: [DONE]\n\n',
          ].join(''),
        )
      },
    )

    await new Promise<void>((resolve, reject) => {
      server.once('error', reject)
      server.listen(0, '127.0.0.1', resolve)
    })

    try {
      const address = server.address()
      if (address === null || typeof address === 'string') throw new Error('missing mock port')
      const route = resolveRoutes({
        providers: {
          'databricks-mock': {
            workspaceUrl: `https://localhost:${address.port}`,
            protocol: 'mlflow-chat',
            allowCustomHost: true,
            allowNonStandardPort: true,
            models: [
              {
                id: 'example-model',
                contextWindow: 16_384,
                maxTokens: 1_024,
              },
            ],
          },
        },
      }).get('databricks-mock')
      if (route === undefined) throw new Error('missing mock route')
      const provider = buildDatabricksProvider(route)
      const model = provider.getModels()[0]
      if (model === undefined) throw new Error('missing mock model')
      const context: Context = {
        messages: [
          {
            role: 'user',
            content: [{ type: 'text', text: 'hello' }],
            timestamp: 0,
          },
        ],
      }

      process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'
      const events: AssistantMessageEvent[] = []
      for await (const event of provider.streamSimple(model, context, {
        apiKey: 'unit-test-credential',
      })) {
        events.push(event)
      }

      expect(receivedPath).toBe('/ai-gateway/mlflow/v1/chat/completions')
      expect(receivedAuthorization).toBe('Bearer unit-test-credential')
      expect(events.some((event) => event.type === 'text_delta')).toBe(true)
      expect(events.at(-1)?.type).toBe('done')
    } finally {
      await new Promise<void>((resolve, reject) => {
        server.close((error) => (error === undefined ? resolve() : reject(error)))
      })
    }
  })
})
