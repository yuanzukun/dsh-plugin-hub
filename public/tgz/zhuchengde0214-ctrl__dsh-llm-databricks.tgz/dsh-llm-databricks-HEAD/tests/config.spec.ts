import { describe, expect, it } from 'vitest'
import { resolveRoutes } from '../src/config.js'
import type { Config, DatabricksProviderConfig } from '../src/types.js'

function config(overrides: Partial<DatabricksProviderConfig> = {}): Config {
  return {
    providers: {
      'databricks-main': {
        workspaceUrl: 'https://dbc-example.cloud.databricks.com',
        protocol: 'mlflow-chat',
        models: [
          {
            id: 'example-model',
            contextWindow: 128_000,
            maxTokens: 8_192,
          },
        ],
        ...overrides,
      },
    },
  }
}

describe('route configuration', () => {
  it('resolves safe defaults and model metadata', () => {
    const route = resolveRoutes(config()).get('databricks-main')
    expect(route).toMatchObject({
      credentialRef: 'DATABRICKS_TOKEN',
      apiBaseUrl:
        'https://dbc-example.cloud.databricks.com/ai-gateway/mlflow/v1',
      requestPath: '/ai-gateway/mlflow/v1/chat/completions',
      streamIdleTimeoutMs: 300_000,
    })
    expect(route?.models[0]?.input).toEqual(['text'])
  })

  it('rejects empty catalogs, duplicate models, and invalid route names', () => {
    expect(() => resolveRoutes(config({ models: [] }))).toThrow(/must not be empty/)
    expect(() =>
      resolveRoutes(
        config({
          models: [
            { id: 'same', contextWindow: 10, maxTokens: 2 },
            { id: 'same', contextWindow: 10, maxTokens: 2 },
          ],
        }),
      ),
    ).toThrow(/repeats/)
    const invalid = config()
    const original = invalid.providers?.['databricks-main']
    if (original === undefined) throw new Error('missing fixture route')
    invalid.providers = { Bad_Route: original }
    expect(() => resolveRoutes(invalid)).toThrow(/lowercase kebab-case/)
  })

  it('validates reasoning effort maps', () => {
    expect(() =>
      resolveRoutes(
        config({
          models: [
            {
              id: 'reasoning-model',
              contextWindow: 128_000,
              maxTokens: 8_192,
              reasoningEfforts: { high: null },
            },
          ],
        }),
      ),
    ).toThrow(/must name a wire value/)
  })

  it('rejects credential references that the credentials seam cannot resolve', () => {
    expect(() => resolveRoutes(config({ credentialRef: 'bad-ref' }))).toThrow()
  })
})
