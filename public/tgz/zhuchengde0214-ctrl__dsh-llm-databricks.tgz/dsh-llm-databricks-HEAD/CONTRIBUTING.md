# Contributing

Contributions are welcome for Databricks gateway compatibility, tests, and
documentation. Keep the package community-branded and independent from
DeepSeek Harness internals.

## Development

Use Node.js 22.19+ and Corepack:

```sh
corepack pnpm install --frozen-lockfile
pnpm run typecheck
pnpm run lint
pnpm test
pnpm run build
```

Tests must use stub transports or the local HTTPS mock gateway. Never add a
real workspace hostname, workspace ID, token, credentials file, DSH home, or
captured provider log to a fixture, issue, commit, or CI secret.

## Changes

- Add focused request and response tests for every protocol behavior change.
- Preserve bearer-only Anthropic authentication and MLflow `store`/`strict`
  sanitization.
- Keep deterministic 4xx errors non-retryable and preserve valid retry delays.
- Update both READMEs and `CHANGELOG.md` for user-visible changes.
- Use Conventional Commits.

## Packaging

Run:

```sh
pnpm pack --pack-destination .artifacts
tar -tzf .artifacts/dsh-llm-databricks-<version>.tgz
```

The tarball must contain only built runtime files, `cordis.patch.yml`, package
metadata, the two READMEs, changelog, and license. Test tarball installation
with an isolated `DSH_HOME`; do not modify a developer's normal Harness
profile. Maintainers publish npm releases separately after review.
