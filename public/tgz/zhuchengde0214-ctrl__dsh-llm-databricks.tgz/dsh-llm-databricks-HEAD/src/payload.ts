import type { DatabricksProtocol } from './types.js'

type JsonObject = Record<string, unknown>

function isObject(value: unknown): value is JsonObject {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function sanitizeTool(value: unknown): unknown {
  if (!isObject(value)) return value
  const tool: JsonObject = { ...value }
  delete tool.strict
  if (isObject(tool.function)) {
    const declaration: JsonObject = { ...tool.function }
    delete declaration.strict
    tool.function = declaration
  }
  return tool
}

export function sanitizePayload(protocol: DatabricksProtocol, payload: unknown): unknown {
  if (protocol !== 'mlflow-chat' && protocol !== 'mlflow-responses') return payload
  if (!isObject(payload)) return payload

  const sanitized: JsonObject = { ...payload }
  delete sanitized.store
  if (Array.isArray(sanitized.tools)) sanitized.tools = sanitized.tools.map(sanitizeTool)
  return sanitized
}

export function bearerHeaders(
  protocol: DatabricksProtocol,
  token: string,
  existing?: HeadersInit,
): Headers {
  const headers = new Headers(existing)
  headers.set('Authorization', `Bearer ${token}`)
  if (protocol === 'anthropic-messages') headers.delete('x-api-key')
  return headers
}
