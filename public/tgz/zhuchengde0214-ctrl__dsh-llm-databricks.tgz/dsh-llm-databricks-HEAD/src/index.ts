import type { Context } from '@deepseek-ai/cordis'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import {
  assertUsableApiKey,
  LlmError,
  type AdapterRegistrationHandle,
  type DirectoryRegistrationHandle,
} from '@deepseek-ai/dsh-llm'
import {
  deepEqualJson,
  installSettingsSection,
  settingsNamespace,
} from '@deepseek-ai/dsh-settings'
import type { ResolvedPiAiProviderProfile } from '@deepseek-ai/dsh-llm-pi-ai'
import { DatabricksAdapter } from './adapter.js'
import { Config as ConfigSchema, resolveRoutes } from './config.js'
import { buildPiProfile } from './provider.js'
import type { Config as ConfigType } from './types.js'

export type {
  DatabricksModelConfig,
  DatabricksProviderConfig,
  DatabricksProtocol,
} from './types.js'
export {
  isOfficialDatabricksHost,
  validateWorkspaceUrl,
} from './security.js'
export { DATABRICKS_PROTOCOLS } from './types.js'
export { sanitizePayload } from './payload.js'
export type Config = ConfigType
export const Config = ConfigSchema

export const name = 'llm-databricks'
export const inject = ['llm']

const NS = settingsNamespace('llm-databricks')

export function apply(ctx: Context, config: ConfigType): void {
  let current = (): ConfigType => config
  let lastRaw: ConfigType | undefined
  let lastProfiles: ReadonlyMap<string, ResolvedPiAiProviderProfile> | undefined

  const profiles = (): ReadonlyMap<string, ResolvedPiAiProviderProfile> => {
    const raw = current()
    if (raw === lastRaw && lastProfiles !== undefined) return lastProfiles
    const next = new Map(
      [...resolveRoutes(raw).entries()].map(([route, resolved]) => [
        route,
        buildPiProfile(resolved),
      ]),
    )
    lastRaw = raw
    lastProfiles = next
    return next
  }

  profiles()
  const adapter = new DatabricksAdapter({
    profiles,
    resolveApiKey: async (provider, profile) => {
      const ref = profile.apiKeyEnv
      if (ref === undefined) {
        throw new LlmError(
          `llm-databricks: provider route "${provider}" has no credential reference`,
          'MISSING_CREDENTIAL',
        )
      }
      const credentials = ctx.get('credentials')
      const hit = await credentials?.resolve(credentialRef(ref))
      if (hit?.value !== undefined && hit.value.length > 0) {
        return assertUsableApiKey(hit.value, 'llm-databricks', ref)
      }
      throw new LlmError(
        `llm-databricks: no credential for route "${provider}"; store or export the referenced credential ${ref}`,
        'MISSING_CREDENTIAL',
      )
    },
    resolveAttachments: () => ctx.get('attachments'),
    onReplayDegrade: ({ provider, model, reason }) => {
      ctx.logger.warn(
        `llm-databricks: replay metadata for "${provider}/${model}" was ignored (${reason})`,
      )
    },
  })

  let registration: AdapterRegistrationHandle | undefined
  let registeredFacts: unknown
  let directory: DirectoryRegistrationHandle | undefined
  let directoryFacts: unknown

  const synchronize = (): void => {
    const active = profiles()
    const facts = [...active.entries()]
      .map(([provider, profile]) => ({
        provider,
        displayName: profile.displayName,
        retryPolicy: profile.retryPolicy,
      }))
      .sort((left, right) => left.provider.localeCompare(right.provider))

    if (!deepEqualJson(facts, registeredFacts)) {
      const routes = [...active.keys()]
      if (registration === undefined) {
        if (routes.length > 0) registration = ctx.llm.registerAdapter(routes, adapter)
      } else {
        registration.replace(routes)
      }
      registeredFacts = facts
    }

    const entries = [...active.values()].map((profile) => ({
      provider: profile.provider,
      displayName: profile.displayName,
      settingsNs: NS,
      settingsPath: ['providers', profile.provider],
      declared: true,
    }))
    if (!deepEqualJson(entries, directoryFacts)) {
      if (directory === undefined) {
        if (entries.length > 0) directory = ctx.llm.registerConfigurableProviders(entries)
      } else {
        directory.replace(entries)
      }
      directoryFacts = entries
    }
  }

  synchronize()
  installSettingsSection(ctx, NS, Config, config, {
    setSource(next) {
      current = next
      lastRaw = undefined
      lastProfiles = undefined
    },
    onChange: synchronize,
    validate: resolveRoutes,
  })
}
