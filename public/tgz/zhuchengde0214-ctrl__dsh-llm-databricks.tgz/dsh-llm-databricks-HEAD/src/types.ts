import type { RetryPolicyConfig } from '@deepseek-ai/dsh-llm'
import type { ModelThinkingLevel } from '@earendil-works/pi-ai'

export const DATABRICKS_PROTOCOLS = [
  'mlflow-chat',
  'mlflow-responses',
  'anthropic-messages',
  'openai-responses',
] as const

export type DatabricksProtocol = (typeof DATABRICKS_PROTOCOLS)[number]
export type DatabricksModality = 'text' | 'image'

export interface DatabricksModelConfig {
  id: string
  name?: string
  contextWindow: number
  maxTokens: number
  input?: DatabricksModality[]
  reasoningEfforts?: false | Partial<Record<ModelThinkingLevel, string | null>>
}

export interface DatabricksProviderConfig {
  workspaceUrl: string
  protocol: DatabricksProtocol
  credentialRef?: string
  displayName?: string
  models: DatabricksModelConfig[]
  allowCustomHost?: boolean
  allowNonStandardPort?: boolean
  timeoutMs?: number
  streamIdleTimeoutMs?: number
  retryPolicy?: RetryPolicyConfig
}

export interface Config {
  providers?: Record<string, DatabricksProviderConfig>
}

export interface ResolvedDatabricksRoute {
  provider: string
  displayName: string
  protocol: DatabricksProtocol
  credentialRef: string
  workspace: URL
  apiBaseUrl: string
  requestPath: string
  allowCustomHost: boolean
  allowNonStandardPort: boolean
  models: DatabricksModelConfig[]
  timeoutMs?: number
  streamIdleTimeoutMs: number
  retryPolicy?: RetryPolicyConfig
}
