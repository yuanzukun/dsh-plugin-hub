import type { ResolvedPiAiProviderProfile } from '@deepseek-ai/dsh-llm-pi-ai'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import {
  createProvider,
  type Api,
  type Context,
  type Model,
  type ProviderHeaders,
  type ProviderStreams,
  type SimpleStreamOptions,
  type StreamOptions,
} from '@earendil-works/pi-ai'
import { anthropicMessagesApi } from '@earendil-works/pi-ai/api/anthropic-messages.lazy'
import { openAICompletionsApi } from '@earendil-works/pi-ai/api/openai-completions.lazy'
import { openAIResponsesApi } from '@earendil-works/pi-ai/api/openai-responses.lazy'
import { resolvedRetryPolicy } from './config.js'
import { sanitizePayload } from './payload.js'
import { assertRequestDestination } from './security.js'
import type {
  DatabricksProtocol,
  ResolvedDatabricksRoute,
} from './types.js'

export interface RequestMetadata {
  status?: number
  retryAfterMs?: number
  requestId?: string
}

const ERROR_METADATA_PREFIX = '[dsh-databricks-meta:'

function protocolApi(protocol: DatabricksProtocol): Api {
  switch (protocol) {
    case 'mlflow-chat':
      return 'openai-completions'
    case 'mlflow-responses':
    case 'openai-responses':
      return 'openai-responses'
    case 'anthropic-messages':
      return 'anthropic-messages'
  }
}

function delegateStreams(protocol: DatabricksProtocol): ProviderStreams {
  switch (protocol) {
    case 'mlflow-chat':
      return openAICompletionsApi()
    case 'mlflow-responses':
    case 'openai-responses':
      return openAIResponsesApi()
    case 'anthropic-messages':
      return anthropicMessagesApi()
  }
}

function parseRetryAfter(headers: Headers): number | undefined {
  const milliseconds = headers.get('retry-after-ms')
  if (milliseconds !== null) {
    const parsed = Number(milliseconds)
    if (Number.isFinite(parsed) && parsed >= 0) return parsed
  }

  const raw = headers.get('retry-after')
  if (raw === null) return undefined
  const seconds = Number(raw)
  if (Number.isFinite(seconds) && seconds >= 0) return seconds * 1_000
  const date = Date.parse(raw)
  if (!Number.isFinite(date)) return undefined
  return Math.max(0, date - Date.now())
}

function responseMetadata(response: Response): RequestMetadata {
  const metadata: RequestMetadata = { status: response.status }
  const retryAfterMs = parseRetryAfter(response.headers)
  if (retryAfterMs !== undefined) metadata.retryAfterMs = retryAfterMs
  const requestId =
    response.headers.get('x-databricks-request-id') ??
    response.headers.get('x-request-id') ??
    response.headers.get('request-id')
  if (requestId !== null && requestId.trim().length > 0) metadata.requestId = requestId
  return metadata
}

function appendMetadata(body: string, marker: string): string {
  if (body.length === 0) {
    return JSON.stringify({
      error: {
        message: 'HTTP request failed',
        code: marker,
      },
    })
  }
  try {
    const parsed: unknown = JSON.parse(body)
    if (typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed)) {
      const root = parsed as Record<string, unknown>
      const error = root.error
      if (typeof error === 'object' && error !== null && !Array.isArray(error)) {
        const detail = error as Record<string, unknown>
        detail.code = `${typeof detail.code === 'string' ? `${detail.code} ` : ''}${marker}`
        return JSON.stringify(root)
      }
    }
  } catch {
    // Preserve a non-JSON provider error body and add the machine-readable suffix.
  }
  return `${body}\n${marker}`
}

async function markErrorResponse(response: Response, credential: string): Promise<Response> {
  if (response.ok) return response
  const metadata = responseMetadata(response)
  const marker = `${ERROR_METADATA_PREFIX}${Buffer.from(JSON.stringify(metadata)).toString('base64url')}]`
  const body = (await response.text()).split(credential).join('[REDACTED]')
  return new Response(appendMetadata(body, marker), {
    status: response.status,
    statusText: response.statusText,
    headers: response.headers,
  })
}

function secureFetch(
  route: ResolvedDatabricksRoute,
  credential: string,
): typeof globalThis.fetch {
  return async (input: RequestInfo | URL, init?: RequestInit) => {
    assertRequestDestination(input, route.workspace, route.requestPath)
    let securedInput = input
    let securedInit = init
    if (route.protocol === 'anthropic-messages') {
      if (input instanceof Request) {
        const headers = new Headers(input.headers)
        headers.delete('x-api-key')
        securedInput = new Request(input, { headers })
      } else {
        const headers = new Headers(init?.headers)
        headers.delete('x-api-key')
        securedInit = { ...init, headers }
      }
    }
    const response = await globalThis.fetch(securedInput, {
      ...securedInit,
      redirect: 'manual',
    })
    return markErrorResponse(response, credential)
  }
}

function requestHeaders(
  protocol: DatabricksProtocol,
  token: string,
  existing?: ProviderHeaders,
): ProviderHeaders {
  const headers: ProviderHeaders = { ...existing }
  for (const key of Object.keys(headers)) {
    if (key.toLowerCase() === 'authorization' || key.toLowerCase() === 'x-api-key') {
      delete headers[key]
    }
  }
  headers.Authorization = `Bearer ${token}`
  if (protocol === 'anthropic-messages') headers['x-api-key'] = null
  return headers
}

function adaptOptions(
  route: ResolvedDatabricksRoute,
  options: SimpleStreamOptions | undefined,
): SimpleStreamOptions {
  const token = options?.apiKey
  if (token === undefined || token.length === 0) {
    throw new Error(`Databricks route "${route.provider}" requires a resolved credential`)
  }
  const previousPayload = options?.onPayload
  const next = {
    ...options,
    ...(route.protocol === 'anthropic-messages' ? { apiKey: undefined } : { apiKey: token }),
    fetch: secureFetch(route, token),
    headers: requestHeaders(route.protocol, token, options?.headers),
    onPayload: async (payload: unknown, model: Model<Api>) => {
      const previous = await previousPayload?.(payload, model)
      return sanitizePayload(route.protocol, previous ?? payload)
    },
  }
  return next
}

function wrappedStreams(route: ResolvedDatabricksRoute): ProviderStreams {
  const delegate = delegateStreams(route.protocol)
  return {
    stream: (model: Model<Api>, context: Context, options?: StreamOptions) =>
      delegate.stream(model, context, adaptOptions(route, options)),
    streamSimple: (
      model: Model<Api>,
      context: Context,
      options?: SimpleStreamOptions,
    ) => delegate.streamSimple(model, context, adaptOptions(route, options)),
  }
}

function modelCompat(protocol: DatabricksProtocol): NonNullable<Model<Api>['compat']> {
  switch (protocol) {
    case 'mlflow-chat':
      return {
        supportsStore: false,
        supportsStrictMode: false,
        supportsDeveloperRole: false,
      }
    case 'mlflow-responses':
      return {
        supportsStrictMode: false,
        supportsDeveloperRole: false,
        supportsLongCacheRetention: false,
        supportsExplicitPromptCacheMode: false,
      }
    case 'openai-responses':
      return {
        supportsStrictMode: true,
        supportsDeveloperRole: true,
      }
    case 'anthropic-messages':
      return {
        supportsLongCacheRetention: false,
        supportsTemperature: false,
      }
  }
}

function buildModels(route: ResolvedDatabricksRoute): Model<Api>[] {
  const api = protocolApi(route.protocol)
  return route.models.map((entry) => ({
    id: entry.id,
    name: entry.name ?? entry.id,
    api,
    provider: route.provider,
    baseUrl: route.apiBaseUrl,
    reasoning: entry.reasoningEfforts !== undefined && entry.reasoningEfforts !== false,
    ...(entry.reasoningEfforts
      ? { thinkingLevelMap: { ...entry.reasoningEfforts } }
      : {}),
    input: [...(entry.input ?? ['text'])],
    cost: {
      input: 0,
      output: 0,
      cacheRead: 0,
      cacheWrite: 0,
    },
    contextWindow: entry.contextWindow,
    maxTokens: entry.maxTokens,
    compat: modelCompat(route.protocol),
  }))
}

export function buildDatabricksProvider(route: ResolvedDatabricksRoute) {
  const models = buildModels(route)
  return createProvider({
    id: route.provider,
    name: route.displayName,
    baseUrl: route.apiBaseUrl,
    auth: {
      apiKey: {
        name: `${route.displayName} token`,
        resolve: ({ credential }) =>
          Promise.resolve({
            auth: credential?.key === undefined ? {} : { apiKey: credential.key },
            source: route.provider,
          }),
      },
    },
    models,
    api: wrappedStreams(route),
  })
}

export function buildPiProfile(
  route: ResolvedDatabricksRoute,
): ResolvedPiAiProviderProfile {
  const provider = buildDatabricksProvider(route)
  return {
    provider: route.provider,
    displayName: route.displayName,
    api: protocolApi(route.protocol),
    baseURL: route.apiBaseUrl,
    apiKeyEnv: credentialRef(route.credentialRef),
    streamIdleTimeoutMs: route.streamIdleTimeoutMs,
    retryPolicy: resolvedRetryPolicy(route),
    // @ts-expect-error The upstream adapter pins pi-ai 0.82, while request-level
    // fetch injection landed in 0.84. Static Provider methods are runtime-compatible;
    // only the unused dynamic refresh callback changed between these versions.
    piProvider: provider,
    configuredMaxTokens: new Map(
      route.models.map((model) => [model.id, model.maxTokens] as const),
    ),
    ...(route.timeoutMs === undefined ? {} : { timeoutMs: route.timeoutMs }),
  }
}
