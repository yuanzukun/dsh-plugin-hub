import type { DatabricksProtocol } from './types.js'

const OFFICIAL_HOST_SUFFIXES = [
  '.azuredatabricks.net',
  '.cloud.databricks.com',
  '.gcp.databricks.com',
  '.databricks.net',
] as const

const ROUTE_PATHS: Record<DatabricksProtocol, { base: string; request: string }> = {
  'mlflow-chat': {
    base: '/ai-gateway/mlflow/v1',
    request: '/ai-gateway/mlflow/v1/chat/completions',
  },
  'mlflow-responses': {
    base: '/ai-gateway/mlflow/v1',
    request: '/ai-gateway/mlflow/v1/responses',
  },
  'anthropic-messages': {
    base: '/ai-gateway/anthropic',
    request: '/ai-gateway/anthropic/v1/messages',
  },
  'openai-responses': {
    base: '/ai-gateway/openai/v1',
    request: '/ai-gateway/openai/v1/responses',
  },
}

export interface WorkspacePolicy {
  allowCustomHost?: boolean
  allowNonStandardPort?: boolean
}

export function isOfficialDatabricksHost(hostname: string): boolean {
  const normalized = hostname.toLowerCase().replace(/\.$/, '')
  return OFFICIAL_HOST_SUFFIXES.some(
    (suffix) => normalized.length > suffix.length && normalized.endsWith(suffix),
  )
}

export function validateWorkspaceUrl(raw: string, policy: WorkspacePolicy = {}): URL {
  let url: URL
  try {
    url = new URL(raw)
  } catch {
    throw new Error('workspaceUrl must be an absolute URL')
  }

  if (url.protocol !== 'https:') {
    throw new Error('workspaceUrl must use HTTPS')
  }
  if (url.username || url.password) {
    throw new Error('workspaceUrl must not contain userinfo')
  }
  if (url.pathname !== '/' || url.search || url.hash) {
    throw new Error('workspaceUrl must contain only the workspace origin (no path, query, or fragment)')
  }

  const official = isOfficialDatabricksHost(url.hostname)
  if (!official && policy.allowCustomHost !== true) {
    throw new Error(
      'workspaceUrl is not an official Databricks host; set allowCustomHost only after reviewing credential-forwarding risk',
    )
  }
  if (url.port && url.port !== '443') {
    if (official || policy.allowNonStandardPort !== true) {
      throw new Error(
        'workspaceUrl must use port 443; custom hosts require allowNonStandardPort for another port',
      )
    }
  }
  return url
}

export function routeUrls(workspace: URL, protocol: DatabricksProtocol): {
  apiBaseUrl: string
  requestPath: string
} {
  const paths = ROUTE_PATHS[protocol]
  return {
    apiBaseUrl: new URL(paths.base, workspace).toString().replace(/\/$/, ''),
    requestPath: paths.request,
  }
}

export function assertRequestDestination(
  input: RequestInfo | URL,
  workspace: URL,
  requestPath: string,
): void {
  const raw = input instanceof Request ? input.url : input.toString()
  const target = new URL(raw)
  if (
    target.protocol !== 'https:' ||
    target.username ||
    target.password ||
    target.origin !== workspace.origin ||
    target.pathname !== requestPath
  ) {
    throw new Error('refusing to forward a Databricks credential to an unexpected request target')
  }
}
