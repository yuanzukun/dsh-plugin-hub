import {
  CONTEXT_WINDOW_EXCEEDED_CODE,
  ProviderRequestId,
  QUOTA_EXCEEDED_CODE,
  type GenerateOptions,
  type LlmFailure,
  type StreamChunk,
} from '@deepseek-ai/dsh-llm'
import { PiAiAdapter } from '@deepseek-ai/dsh-llm-pi-ai'
import type { RequestMetadata } from './provider.js'

const CONTEXT_OVERFLOW =
  /context(?:[_ -](?:window|length))|context_length_exceeded|maximum context|too many (?:input )?tokens|input.*exceeds.*token/i
const QUOTA =
  /quota|resource[_ -]?exhausted|tokens per minute|input tokens.*(?:per|\/)\s*minute|insufficient[_ -]?(?:balance|credits?)/i

const ERROR_METADATA = /\s*\[dsh-databricks-meta:([A-Za-z0-9_-]+)]/g

function readMetadata(message: string): { message: string; metadata: RequestMetadata } {
  let metadata: RequestMetadata = {}
  const cleaned = message.replace(ERROR_METADATA, (_match, encoded: string) => {
    try {
      const parsed: unknown = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'))
      if (typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed)) {
        metadata = parsed as RequestMetadata
      }
    } catch {
      // An invalid provider-controlled suffix is ordinary text, not trusted metadata.
    }
    return ''
  })
  return { message: cleaned, metadata }
}

function failureCode(status: number | undefined, failure: LlmFailure): string {
  if (
    failure.code === CONTEXT_WINDOW_EXCEEDED_CODE ||
    failure.code === QUOTA_EXCEEDED_CODE
  ) {
    return failure.code
  }
  if (status === 401 || status === 403) return 'AUTH'
  if (status === 429) return QUOTA.test(failure.message) ? QUOTA_EXCEEDED_CODE : 'RATE_LIMIT'
  if (status !== undefined && status >= 500) return 'SERVER'
  if (status === 400) {
    return CONTEXT_OVERFLOW.test(failure.message)
      ? CONTEXT_WINDOW_EXCEEDED_CODE
      : 'INVALID_REQUEST'
  }
  return failure.code
}

function enrichFailure(failure: LlmFailure): LlmFailure {
  const parsed = readMetadata(failure.message)
  const metadata = parsed.metadata
  const status = metadata.status ?? failure.status
  const message = parsed.message
  return {
    message,
    code: failureCode(status, { ...failure, message }),
    ...(status === undefined ? {} : { status }),
    ...(metadata.retryAfterMs === undefined
      ? failure.providerRetryAfterMs === undefined
        ? {}
        : { providerRetryAfterMs: failure.providerRetryAfterMs }
      : { providerRetryAfterMs: metadata.retryAfterMs }),
    ...(metadata.requestId === undefined
      ? failure.requestId === undefined
        ? {}
        : { requestId: failure.requestId }
      : { requestId: ProviderRequestId(metadata.requestId) }),
  }
}

export class DatabricksAdapter extends PiAiAdapter {
  override async *stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    const iterator = super.stream(options)[Symbol.asyncIterator]()
    let exhausted = false
    try {
      while (true) {
        const item = await iterator.next()
        if (item.done) {
          exhausted = true
          return
        }
        const chunk = item.value
        if (
          chunk.type === 'finish' &&
          (chunk.reason.kind === 'error' || chunk.reason.kind === 'aborted')
        ) {
          yield {
            ...chunk,
            reason: {
              ...chunk.reason,
              failure: enrichFailure(chunk.reason.failure),
            },
          }
        } else {
          yield chunk
        }
      }
    } finally {
      if (!exhausted) await iterator.return?.()
    }
  }
}
