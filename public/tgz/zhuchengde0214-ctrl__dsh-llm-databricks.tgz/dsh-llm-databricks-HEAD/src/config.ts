import {
  RetryPolicySchema,
  resolveRetryPolicy,
  type ResolvedRetryPolicy,
} from '@deepseek-ai/dsh-llm'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import z from '@deepseek-ai/schemastery'
import type { ModelThinkingLevel } from '@earendil-works/pi-ai'
import { routeUrls, validateWorkspaceUrl } from './security.js'
import {
  DATABRICKS_PROTOCOLS,
  type Config as ConfigType,
  type DatabricksModelConfig,
  type ResolvedDatabricksRoute,
} from './types.js'

const THINKING_LEVELS: readonly ModelThinkingLevel[] = [
  'off',
  'minimal',
  'low',
  'medium',
  'high',
  'xhigh',
  'max',
]

const reasoningEfforts = z.dict(
  z.union([z.string(), z.const(null)]),
)

const model = z.object({
  id: z.string().required(),
  name: z.string(),
  contextWindow: z.number().step(1).min(1).required(),
  maxTokens: z.number().step(1).min(1).required(),
  input: z.array(z.union(['text', 'image'])).default(['text']),
  reasoningEfforts: z.union([z.const(false), reasoningEfforts]),
})

const provider = z.object({
  workspaceUrl: z.string().required(),
  protocol: z.union(DATABRICKS_PROTOCOLS).required(),
  credentialRef: z.string().role('credential-ref').default('DATABRICKS_TOKEN'),
  displayName: z.string(),
  models: z.array(model).required(),
  allowCustomHost: z.boolean().default(false),
  allowNonStandardPort: z.boolean().default(false),
  timeoutMs: z.number().step(1).min(1),
  streamIdleTimeoutMs: z.number().step(1).min(1).default(300_000),
  retryPolicy: RetryPolicySchema,
})

export const Config: z<ConfigType> = z.object({
  providers: z.dict(provider).default({}),
})

function validateModel(route: string, entry: DatabricksModelConfig, seen: Set<string>): void {
  if (entry.id.trim() !== entry.id || entry.id.length === 0) {
    throw new Error(`llm-databricks: providers.${route}.models has an invalid id`)
  }
  if (seen.has(entry.id)) {
    throw new Error(`llm-databricks: providers.${route}.models repeats "${entry.id}"`)
  }
  seen.add(entry.id)
  if (entry.input !== undefined && entry.input.length === 0) {
    throw new Error(`llm-databricks: providers.${route}.models.${entry.id}.input must not be empty`)
  }
  if (entry.reasoningEfforts) {
    const efforts = Object.entries(entry.reasoningEfforts)
    if (efforts.length === 0) {
      throw new Error(
        `llm-databricks: providers.${route}.models.${entry.id}.reasoningEfforts must not be empty`,
      )
    }
    for (const [level, wire] of efforts) {
      if (!THINKING_LEVELS.includes(level as ModelThinkingLevel)) {
        throw new Error(
          `llm-databricks: providers.${route}.models.${entry.id}.reasoningEfforts.${level} is not supported`,
        )
      }
      if (level !== 'off' && (wire === null || wire.trim().length === 0)) {
        throw new Error(
          `llm-databricks: providers.${route}.models.${entry.id}.reasoningEfforts.${level} must name a wire value`,
        )
      }
    }
  }
}

export function resolveRoutes(config: ConfigType): Map<string, ResolvedDatabricksRoute> {
  const routes = new Map<string, ResolvedDatabricksRoute>()
  for (const [route, source] of Object.entries(config.providers ?? {})) {
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(route)) {
      throw new Error(`llm-databricks: provider route "${route}" must be lowercase kebab-case`)
    }
    if (source.models.length === 0) {
      throw new Error(`llm-databricks: providers.${route}.models must not be empty`)
    }
    const seen = new Set<string>()
    for (const entry of source.models) validateModel(route, entry, seen)
    const resolvedCredentialRef = credentialRef(source.credentialRef ?? 'DATABRICKS_TOKEN')
    const workspace = validateWorkspaceUrl(source.workspaceUrl, source)
    const urls = routeUrls(workspace, source.protocol)
    routes.set(route, {
      provider: route,
      displayName: source.displayName ?? `Databricks (${route})`,
      protocol: source.protocol,
      credentialRef: resolvedCredentialRef,
      workspace,
      ...urls,
      allowCustomHost: source.allowCustomHost ?? false,
      allowNonStandardPort: source.allowNonStandardPort ?? false,
      models: source.models.map((entry) => ({
        ...entry,
        input: [...(entry.input ?? ['text'])],
        ...(entry.reasoningEfforts
          ? { reasoningEfforts: { ...entry.reasoningEfforts } }
          : {}),
      })),
      ...(source.timeoutMs === undefined ? {} : { timeoutMs: source.timeoutMs }),
      streamIdleTimeoutMs: source.streamIdleTimeoutMs ?? 300_000,
      ...(source.retryPolicy === undefined ? {} : { retryPolicy: source.retryPolicy }),
    })
  }
  return routes
}

export function resolvedRetryPolicy(route: ResolvedDatabricksRoute): ResolvedRetryPolicy {
  return resolveRetryPolicy(route.retryPolicy, `llm-databricks.providers.${route.provider}.retryPolicy`)
}
