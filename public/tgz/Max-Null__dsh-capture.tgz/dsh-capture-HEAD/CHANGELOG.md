# Changelog

本项目遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/) 与[语义化版本](https://semver.org/lang/zh-CN/)。

## [0.4.0] - 2026-10-30

### Fixed

- **原图预览的编辑按钮位置错**：`.dsh-img-edit-btn` 用的是 `position:fixed; top:20px; right:64px`，那是相对**视口**定位——按钮永远贴在窗口右上角、压在最小化/最大化/关闭按钮上，跟图片在哪无关。改为按图片矩形计算位置（图片右上角内侧内缩 8px），并随窗口 resize 重算。
- 工具条改挂到 `body`（原先 append 进 dialog），预览关闭时由 MutationObserver 收走，不残留。

### Added

- **复制图片**（⧉）：原图预览里的第二个按钮，把图片写进系统剪贴板。非 PNG 先用 canvas 重编码——`ClipboardItem` 在各浏览器实现里只可靠支持 `image/png`。成功时按钮短暂显示 ✓，失败走原有错误提示。
- 两个按钮合成一组工具条（`.dsh-img-tools`），替换原先单按钮的注入。

## [0.3.2] - 2026-10-18

### Changed

- 适配 DSH 0.2.1：`src/host-context.d.ts` 的类型镜像由 `webRuntime` 改为 `webStartup`。该服务自 0.2.1-alpha.2 起被删除；本插件对该面是可选读取（`ctx.get`），运行时不受影响，改动只是让类型声明与内核一致。
- 补 `repository` 字段：npm 的来源证明（provenance）会校验 package.json 的仓库地址与构建来源一致，缺它会让 `npm publish --provenance` 在最后一步被拒。
