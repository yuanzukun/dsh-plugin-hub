/**
 * ImagePreviewEdit: 官方「原图预览」(ImageLightbox) 的工具入口。
 *
 * MutationObserver 发现预览 dialog（role=dialog + aria-label 原图预览 /
 * Original image preview —— 官方文案，不依赖 CSS hash，草稿附件预览与
 * 消息图片预览共用同一个 ImageLightbox）→ 在图片右上角浮出一组工具：
 *   - 编辑（✎）：打开 CaptureOverlay 整图模式（immediate：跳过框选直接标注）。
 *     有标注投递一张编辑图到输入框；无标注视为未修改，直接关闭不投递。
 *   - 复制（⧉）：把原图写进系统剪贴板。
 *
 * 工具条的定位必须**跟随图片的 rect**，不能用 fixed 的固定 top/right——
 * 那样它会永远贴在视口右上角、压在窗口控制按钮上（2026-10-30 用户实测错位）。
 */
import { createElement, useEffect, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { CaptureOverlay } from './CaptureOverlay'
import { deliverToComposer } from './delivery'

const PREVIEW_LABELS = /^(原图预览|Original image preview)$/

/** 工具按钮尺寸 / 间距 / 距图片边缘的内缩，定位计算与 CSS 必须一致。 */
const TOOL_SIZE = 36
const TOOL_GAP = 6
const TOOL_INSET = 8

const TOOLS_CSS = [
  `.dsh-img-tools{position:fixed;z-index:2147483646;display:flex;gap:${TOOL_GAP}px;pointer-events:auto}`,
  `.dsh-img-tool{display:grid;place-items:center;width:${TOOL_SIZE}px;height:${TOOL_SIZE}px;`
    + 'border:1px solid var(--dsw-alias-border-l2-darkmode-thin,rgba(255,255,255,.14));border-radius:999px;'
    + 'background:var(--dsw-specific-input-major,rgba(20,24,32,.92));color:var(--dsw-alias-label-primary,#e8eaed);'
    + 'cursor:pointer;padding:0;font:16px/1 sans-serif}',
  '.dsh-img-tool:hover{border-color:var(--dsw-alias-brand-primary,#4f8cff);color:var(--dsw-alias-brand-primary,#4f8cff)}',
  '.dsh-img-tool[data-busy="1"]{opacity:.55;cursor:default}',
].join('')

const STYLE_ID = '@max-null/dsh-capture/image-edit.css'

function ensureStyle(): void {
  if (typeof document === 'undefined') return
  if (document.querySelector(`style[data-plugin-css="${STYLE_ID}"]`) !== null) return
  const tag = document.createElement('style')
  tag.dataset.plugin = 'dsh-capture'
  tag.dataset.pluginCss = STYLE_ID
  tag.textContent = TOOLS_CSS
  document.head.appendChild(tag)
}

/** 正在编辑的图片（blob/dataUrl src + 自然尺寸）+ 来源预览 dialog。 */
interface EditTarget {
  src: string
  width: number
  height: number
  dialog: HTMLElement | null
}

/** 触发官方面板关闭：点预览 dialog 内的关闭按钮（aria-label 文案稳定）。
 *  找不到按钮时静默跳过——dialog 由 React 状态驱动,只能经它的控件关闭。 */
function closePreviewDialog(dialog: HTMLElement | null): void {
  if (dialog === null || !dialog.isConnected) return
  for (const btn of Array.from(dialog.querySelectorAll('button'))) {
    if (/^(关闭原图预览|Close original image preview)$/.test(btn.getAttribute('aria-label') ?? '')) {
      btn.click()
      return
    }
  }
}

/**
 * 把一张图片写进系统剪贴板。
 *
 * `ClipboardItem` 在各实现里只可靠支持 `image/png`，所以非 PNG 先用 canvas 重编码；
 * `src` 可能是 blob:/data: 也可能是 http(s)，一律走 fetch 取字节。
 * @param src - 预览里那张图的 src。
 */
async function copyImageToClipboard(src: string): Promise<void> {
  const response = await fetch(src)
  if (!response.ok) throw new Error(`读取图片失败（HTTP ${response.status}）`)
  const blob = await response.blob()
  let png = blob
  if (blob.type !== 'image/png') {
    const bitmap = await createImageBitmap(blob)
    const canvas = document.createElement('canvas')
    canvas.width = bitmap.width
    canvas.height = bitmap.height
    const context = canvas.getContext('2d')
    if (context === null) throw new Error('无法创建画布')
    context.drawImage(bitmap, 0, 0)
    png = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob(result => (result === null ? reject(new Error('图片重编码失败')) : resolve(result)), 'image/png')
    })
  }
  await navigator.clipboard.write([new ClipboardItem({ 'image/png': png })])
}

/** 常驻注入宿主：观察预览对话框并挂上工具条；零视觉输出（null portal）。 */
export function ImagePreviewEditHost(): ReactNode {
  const [edit, setEdit] = useState<EditTarget | null>(null)
  const [error, setError] = useState<string | null>(null)
  const busyRef = useRef(false)
  // 供 MutationObserver 闭包读取的实时引用。
  const editRef = useRef<EditTarget | null>(edit)
  editRef.current = edit

  useEffect(() => {
    ensureStyle()
    const openEdit = (src: string, dialog: HTMLElement | null): void => {
      if (busyRef.current || editRef.current !== null) return
      busyRef.current = true
      const probe = new Image()
      probe.onload = () => {
        busyRef.current = false
        setEdit({ src, width: probe.naturalWidth, height: probe.naturalHeight, dialog })
      }
      probe.onerror = () => {
        busyRef.current = false
        setError('图片加载失败，无法编辑')
      }
      probe.src = src
    }

    /** 当前挂在 body 上的工具条（同一时刻只服务一个预览对话框）。 */
    let tools: HTMLDivElement | null = null
    let activeImage: HTMLImageElement | null = null

    const place = (): void => {
      if (tools === null || activeImage === null) return
      const rect = activeImage.getBoundingClientRect()
      if (rect.width === 0 || rect.height === 0) return
      const width = TOOL_SIZE * 2 + TOOL_GAP
      // 贴图片右上角内侧；图片窄到放不下时退到右边缘内侧。
      const left = Math.max(TOOL_INSET, rect.right - width - TOOL_INSET)
      const top = Math.max(TOOL_INSET, rect.top + TOOL_INSET)
      tools.style.left = `${Math.round(left)}px`
      tools.style.top = `${Math.round(top)}px`
    }

    const dropTools = (): void => {
      tools?.remove()
      tools = null
      activeImage = null
    }

    const injectInto = (dialog: Element, img: HTMLImageElement): void => {
      if (tools !== null && activeImage === img) return
      dropTools()
      const bar = document.createElement('div')
      bar.dataset.dshImageTools = '1'
      bar.className = 'dsh-img-tools'

      const editBtn = document.createElement('button')
      editBtn.type = 'button'
      editBtn.className = 'dsh-img-tool'
      editBtn.dataset.dshImageEdit = '1'
      editBtn.setAttribute('aria-label', '编辑图片')
      editBtn.title = '标注编辑这张图片'
      editBtn.innerHTML = '✎'
      editBtn.addEventListener('click', (event) => {
        event.stopPropagation()
        openEdit(img.src, img.closest('[role="dialog"]'))
      })

      const copyBtn = document.createElement('button')
      copyBtn.type = 'button'
      copyBtn.className = 'dsh-img-tool'
      copyBtn.setAttribute('aria-label', '复制图片')
      copyBtn.title = '复制这张图片到剪贴板'
      copyBtn.innerHTML = '⧉'
      copyBtn.addEventListener('click', (event) => {
        event.stopPropagation()
        if (copyBtn.dataset.busy === '1') return
        copyBtn.dataset.busy = '1'
        void copyImageToClipboard(img.src).then(
          () => { copyBtn.innerHTML = '✓' },
          (reason: unknown) => { setError(reason instanceof Error ? reason.message : String(reason)) },
        ).finally(() => {
          delete copyBtn.dataset.busy
          window.setTimeout(() => { copyBtn.innerHTML = '⧉' }, 1200)
        })
      })

      bar.append(editBtn, copyBtn)
      document.body.appendChild(bar)
      tools = bar
      activeImage = img
      place()
    }

    const scan = (): void => {
      let live = false
      for (const dialog of Array.from(document.querySelectorAll('[role="dialog"]'))) {
        if (!PREVIEW_LABELS.test(dialog.getAttribute('aria-label') ?? '')) continue
        const img = dialog.querySelector('img')
        if (img === null) continue
        live = true
        injectInto(dialog, img)
      }
      // 预览关掉就收走工具条，避免它留在 body 上跟着别的界面走。
      if (!live) dropTools()
    }

    const onResize = (): void => { place() }
    window.addEventListener('resize', onResize)
    const observer = new MutationObserver(scan)
    if (document.body !== null) {
      observer.observe(document.body, { childList: true, subtree: true })
      scan()
    }
    return () => {
      window.removeEventListener('resize', onResize)
      observer.disconnect()
      dropTools()
    }
  }, [])

  // 编辑浮层关闭错误提示
  useEffect(() => {
    if (error !== null) {
      const timer = window.setTimeout(() => setError(null), 2500)
      return () => window.clearTimeout(timer)
    }
    return undefined
  }, [error])

  if (edit === null) return null

  const onDone = (result: { source: string, annotated?: string }): void => {
    const dialog = editRef.current?.dialog ?? null
    setEdit(null)
    // 完成即关闭来源预览窗口(编辑流程收敛;无标注=未修改,同样关闭不投递)。
    closePreviewDialog(dialog)
    // 无标注 = 未修改:不投递;有标注投一张编辑图（原图已在对话里）。
    if (result.annotated === undefined) return
    void deliverToComposer(result.annotated, 'image-edit-annotated.png').catch((err: unknown) => {
      console.warn(`[ssid-screenshot] image edit delivery failed: ${err instanceof Error ? err.message : String(err)}`)
    })
  }

  const overlay = createElement(CaptureOverlay, {
    key: 'image-edit',
    dataUrl: edit.src,
    width: edit.width,
    height: edit.height,
    immediate: true,
    onDone,
    onCancel: () => setEdit(null),
  })

  return createPortal(
    <div>
      {overlay}
      {error !== null ? <div className="dsh-img-edit-error" style={{ position: 'fixed', bottom: 80, left: '50%', transform: 'translateX(-50%)', zIndex: 2147483647, padding: '6px 14px', borderRadius: 8, background: 'var(--dsw-alias-interactive-bg-hover-solid,rgba(30,36,46,.95))', color: 'var(--dsw-alias-state-error-primary,#ff6b6b)', font: '13px/20px sans-serif' }}>{error}</div> : null}
    </div>,
    document.body,
  )
}
