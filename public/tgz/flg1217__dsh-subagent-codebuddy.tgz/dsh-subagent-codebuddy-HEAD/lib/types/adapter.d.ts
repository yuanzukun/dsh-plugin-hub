/**
 * CodeBuddy 模型适配器:provider 路由 `codebuddy`,走 ACP(Agent Client Protocol)。
 *
 * 两条路径(路线 C1 起):
 *
 * 1. **回合泵**(`src/pump.ts`):会话绑定且调用方(agent-loop)已打开 step
 *    的对话轮。一个 CodeBuddy 回合 = 一个 ACP 进程,按**模型调用**切段,
 *    每个 dsh step 消费一段;工具调用注册 per-agent 的回放工具、由 loop
 *    原生写 `assistant/message` / `tool/call` / `tool/result`——适配器自己
 *    零会话写入。这样「一次模型调用 = 一个 step」与 dsh 语义一致:文本/工具
 *    顺序、每步用量、分页、客户端末条胜出渲染全部自然成立。
 * 2. **一次性旁路会话**(压缩/会话标题等 purpose 调用、无会话调用):
 *    纯 chunk 流,零写入。
 *
 * ACP 层的关键机制(两条路径共用):
 * - **会话生命周期官方化**:`session/new` / `session/load`(历史回放)复用
 *   长线会话;`session/prompt` 流式 `session/update`(含 thinking 流);
 * - **协议级取消**:`session/cancel` 对生成流与正在执行的工具都是即时抢占
 *   (实测),abort 信号驱动周期性重发(思考早期单次通知可能被吞);
 * - **静默失败自动重试**:CodeBuddy 服务端偶发静默失败(实测高频)——
 *   end_turn 但零思考零文本零工具。泵在首段无产出时重启一次(恢复同一
 *   会话续跑);已有产出的回合以显式错误收尾;
 * - **假死防御分层**:进展性 update(消息/思考/工具)重置动态空闲阈值;
 *   CLI 心跳(session_info/usage/config)与 stderr 不参与续命;静默超
 *   阈值先发 cancel、5s 仍无响应才 kill——进程退出码与 stderr 全程留证。
 * @module subagent-codebuddy/adapter
 */
import type { Context } from '@deepseek-ai/cordis';
import { LlmAdapter } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions, LlmModelInfo, LlmResolvedModelInfo, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import { ConversationStore } from './conversations.js';
import type { AcpTimeouts } from './acp.js';
import type { ModelCapabilityIndex } from './model-capabilities.js';
/**
 * 会话中最后一个已打开(尚无配对 step/end)的 turn/step。
 *
 * 它是「调用方是 agent-loop 的对话轮」的判据:只有这种调用才走回合泵
 * (路线 C1,一个 CodeBuddy 回合 = 多个原生 step);压缩/标题这类旁路调用
 * 没有打开 step,走一次性会话。
 * @param events - 会话自身的已提交事件(ownEvents)。
 * @returns 打开的 turn/step,没有则为 undefined。
 */
export declare function findOpenStep(events: readonly SessionEvent[]): {
    turn: number;
    step: number;
} | undefined;
/** CodeBuddy CLI 入口配置(由 index.ts 解析)。 */
export interface CodebuddyAdapterOptions {
    /** 可执行入口(node 脚本绝对路径或命令)。 */
    command: string;
    /** 前置参数(如解析出的 CLI 路径)。 */
    prefixArgs: string[];
    /** 读取当前默认模型(调用时求值,设置面板改默认模型后对新请求实时生效)。 */
    modelOf: () => string;
    /** 传给 `--permission-mode` 的权限模式。 */
    permissionMode: string;
    /** 追加的额外 CodeBuddy 参数。 */
    extraArgs: string[];
    /**
     * 工具桥接模式(默认 `mcp`):mcp = spawn 加 `--mcp-config` 连 dsh 的
     * HTTP MCP server;delegate = 旧 DelegateTool 通道(不加该参数)。
     */
    bridgeMode?: 'mcp' | 'delegate';
    /** 动态空闲超时预算(可选,默认见 {@link DEFAULT_ACP_RUN_TIMEOUTS})。 */
    timeouts?: AcpTimeouts;
    /** 静默失败自动重试次数(默认 2:首次 + 1 次续跑)。 */
    maxAttempts?: number;
    /** 重试间隔(毫秒,默认 3s)。 */
    retryDelayMs?: number;
    /** 中途插入轮询间隔(毫秒,默认 1200;测试用小值)。 */
    steerPollMs?: number;
    /** 续接映射存储(默认持久化到 `~/.dsh/codebuddy/conversations.json`;测试传纯内存)。 */
    store?: ConversationStore;
    /** 原生会话文件根目录(默认 `~/.codebuddy/projects`;测试注入临时目录)。 */
    nativeBaseDir?: string;
    /**
     * 模型能力索引(默认读 `<configDir>/models.json` 的 `supportsImages`;
     * 测试注入假索引,避免读真实 `~/.codebuddy`)。
     */
    capabilities?: ModelCapabilityIndex;
}
/**
 * CodeBuddy 模型适配器。stream() 每次调用:
 * spawn `codebuddy --acp` → initialize → session/new(或 session/load 复用)
 * → session/prompt → 消费 session/update(思考/文本/工具)→ finish 收尾。
 * 每次调用一个 ACP 进程,用完退出;会话连续性由 CodeBuddy 会话存储 +
 * session/load 保证(实测回放完整);续接映射持久化,服务重启后自动恢复;
 * 静默失败自动恢复会话续跑。
 */
export declare class CodebuddyLlmAdapter extends LlmAdapter {
    private readonly ctx;
    private readonly options;
    /**
     * dsh 会话 → CodeBuddy ACP 会话的续接映射(持久化,跨服务重启恢复)。
     *
     * 首次调用 `session/new` 建立并记录;之后同一会话的每次 stream 都
     * `session/load` 载入同一会话(官方实现会先回放历史事件,回放不落地)。
     */
    private readonly conversations;
    /** listModels 缓存与并发合并(目录拉取热路径)。 */
    private modelCache;
    private modelFetch;
    /** 中继回退:同一会话最多保留的转发 id 数(防无界增长)。 */
    private static readonly FORWARDED_CAP;
    /** dsh 会话 → todo 列表状态(CodeBuddy 任务工具折算整表快照,跨轮复用)。 */
    private readonly todoStates;
    /** dsh 会话 → 已转发的插入消息 id(续聊补发时跳过,防重复)。 */
    private readonly forwardedInsertions;
    /** dsh attachments 服务面(单图入库;原生 read_image 同法)。 */
    private attachmentsFace;
    /** 标记一条插入为已转发;已标记过返回 false。 */
    private markForwarded;
    /** 查询一条插入是否已投递过。 */
    private isForwarded;
    /** 撤销一条转发标记(投递确认失败时回滚,留给补发路径)。 */
    private unmarkForwarded;
    /** 模型图片能力索引(`models.json` 的 `supportsImages`;未知按仅文本)。 */
    private readonly capabilities;
    constructor(ctx: Context, options: CodebuddyAdapterOptions);
    /** 该模型是否原生支持图片输入(未登记/字段缺失按 false)。 */
    imageCapableOf(model: string): boolean;
    /**
     * 读图引导:读图走 **CLI 原生 Read**(`--tools` 白名单固定放行;CLI 内置
     * 读图管线对任意模型适配,而 MCP 工具结果里的图片会被 CLI 按模型能力过滤
     * ——`function_call_result` → `[Image content filtered]`)。dsh 的 read_image
     * 工具在场即按原生档引导(它同时服务支持图片的模型);工具缺席时才退回
     * AGY 转述/如实说明。tools 服务不可用(极简/测试上下文)时按模型能力回退。
     * @param model - 本次请求路由到的 CodeBuddy 模型 id(仅回退路径使用)。
     * @returns 读图引导档位。
     */
    private imageGuidanceFor;
    /** dsh tools 服务里是否存在该工具(缺席时不指路不存在的工具)。 */
    private hasTool;
    /**
     * 绑定模型元数据与分发流入口(rc.2+ 的 LlmAdapter 接口)。
     * 显式实现而非依赖基类:插件对宿主 dsh-llm 版本保持兼容
     * (rc.6 宿主不调用此方法;rc.2+ 宿主调用本实现)。
     */
    prepareCall(provider: string, model: string, signal?: AbortSignal): Promise<{
        model: LlmResolvedModelInfo;
        stream: (options: GenerateOptions) => AsyncIterable<StreamChunk>;
    }>;
    /** 取(或建)某会话的 todo 状态;首建时从已提交事件折叠最新 todo/write 播种。 */
    private todoStateFor;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
    /**
     * 建立/复用本回合的泵(路线 C1)。同一回合内的每个 step 都到这里:
     * 已有泵 → 直接续段(绝不重发 prompt);没有 → 编译本轮输入并启动泵。
     */
    private startTurn;
    /**
     * 原生种子:新会话且带历史时,把折叠后的历史转成 CodeBuddy 原生记录
     * (由调用方写成会话文件 + session/load 载入)。转换失败返回 undefined,
     * 调用方退回纯提示词路径。
     */
    private buildNativeSeed;
    /**
     * 一次性旁路会话(带 purpose 的辅助调用 / 无会话调用)。可重试失败
     * (静默空跑/半途终止/进程退出/超时)时恢复同一会话续跑;用尽后以显式
     * 错误收尾。不写任何会话事件——调用方不是 agent-loop 的对话轮。
     */
    private streamOneShot;
    /** 单次旁路委托:进程 + 握手 + prompt + update 消费(纯 chunk,零会话写入)。 */
    private oneShotOnce;
    resolveModel(provider: string, model: string, _signal?: AbortSignal): Promise<LlmResolvedModelInfo>;
    /** 主模型选择器里的 provider 分组名。 */
    providerInfo(provider: string): {
        id: string;
        name: string;
    };
    /**
     * 主模型选择器的模型目录:`codebuddy --help` 解析出的 id ∪ 设置里的默认模型。
     *
     * 目录路径会在客户端每次拉取时被调用,且 CLI 可能缺失/挂起——因此
     * 异步 spawn + 超时、成功缓存 10 分钟、失败缓存 60 秒、并发合并,
     * 并且**永不抛错**:CLI 不可用时回退到配置模型,保证 provider 仍可选择。
     */
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
}
