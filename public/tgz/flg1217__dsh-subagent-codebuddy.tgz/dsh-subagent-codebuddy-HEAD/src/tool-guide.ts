/**
 * 模型在 CodeBuddy 与 dsh 原生之间切换时,注入**工具面说明**。
 *
 * dsh 核心只注入一条"模型变了"(core/agent 的 modelSwitchNotice:assistant
 * 历史由旧模型生成、会话继续用新模型)。但两条路由的工具面是**两套**:
 *
 * - CodeBuddy 回合内:CLI 原生工具(Bash/Read/Edit/Write/Glob/Grep 等)全禁,
 *   一律走 dsh 桥工具(mcp__dsh__* / dsh_* 委托);
 * - dsh 原生回合:工具恢复原生形态,而桥的**回放代理**(cli_ 前缀,记录 CLI
 *   曾调用过的原生工具)只在其回合内有效。
 *
 * 这条差异不注入,切换后的第一步模型就会按上一个模型的习惯选错工具
 * (实测:codebuddy → dsh 原生后误选残留 cli_* 读图工具,报"没有运行中的
 * CodeBuddy 回合"而损坏读图)。
 *
 * 时机:`model/selection` 事件记下切换,下一次 pre-step 注入(空步会丢消息,
 * 与 modelSwitchNotice 同一守卫——空步保留待注入,等真正发请求的那一步)。
 * @module subagent-codebuddy/tool-guide
 */

import type { Context } from '@deepseek-ai/cordis'
import { boundContextSummary, createUserMessage } from '@deepseek-ai/dsh-llm'
import type { ContextFormed } from '@deepseek-ai/dsh-llm'

/** 消息 source 名(也是本插件注册的 provider/路由名)。 */
const PLUGIN_NAME = 'codebuddy'

/**
 * 本插件注入消息的 source。
 *
 * 0.2.1 起 `MessageSourceMap` 是 merge-extensible 的:每个生产者在自己的
 * 模块里声明 kind,通用的 `'plugin'` 兜底已退役(会话格式 v4 明确拒绝
 * `kind: 'plugin'`)。UI 按 `form: 'notice' + summary` 渲染折叠行,与 kind 无关。
 */
declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    'codebuddy': { kind: 'codebuddy' } & ContextFormed
  }
}

/** 从 session/event 载荷取会话 id(与 pump 的取法一致)。 */
function sessionIdOf(session: unknown): string | undefined {
  const face = session as { id?: unknown; header?: { id?: unknown } } | undefined
  const id = face?.header?.id ?? face?.id
  return typeof id === 'string' && id.length > 0 ? id : undefined
}

/**
 * 切换说明文本;与 CodeBuddy 无关的切换(两边都不是)返回 undefined。
 * @param from - 切换前路由的 provider(会话首个选择时为 undefined)。
 * @param to - 切换后路由的 provider。
 */
function guideText(from: string | undefined, to: string): string | undefined {
  if (to === PLUGIN_NAME) {
    return '[工具面切换:当前路由是 CodeBuddy 桥] CodeBuddy CLI 的原生工具'
      + '(Bash/Read/Edit/Write/Glob/Grep 等)在该回合内全部禁用——一律改用 dsh 桥工具'
      + ' mcp__dsh__<工具名>(bash、pwsh、read、read_image、write、edit、glob、grep、subagent、'
      + 'send_message…);它们在 dsh 侧执行,受审批/沙箱约束并进会话日志。'
  }
  if (from === PLUGIN_NAME) {
    if (to === 'agy') {
      return '[工具面切换:当前路由是 AGY] 工具调用经 dsh 的 MCP 端点执行(审批/沙箱/审计在 dsh 侧),'
        + '可用工具以当前会话工具列表为准;CodeBuddy 桥的回放代理(cli_ 前缀)只在其回合内有效,不要使用。'
    }
    return '[工具面切换:当前路由是 dsh 原生模型] 工具恢复 dsh 原生形态'
      + '(read、write、edit、pwsh、read_image、glob、grep…直接调用);CodeBuddy 桥的回放代理'
      + '(cli_ 前缀,只在 CodeBuddy 回合内有效)不要使用。'
  }
  return undefined
}

/**
 * 两个会话级 Map 的容量上限(FIFO 淘汰最早条目)。
 *
 * lastRoute/pending 按会话 id 记状态,正常随会话使用自然覆盖;但会话结束
 * 不会回调本插件,长期运行的宿主里死会话条目只增不减(缓慢泄漏)。
 * 上限远大于同时活跃的会话数,淘汰只可能发生在早已闲置的会话上——代价是
 * 该会话的下一次切换可能少一条说明,可接受。
 */
const MAX_TRACKED_SESSIONS = 512

/** 超限时按插入顺序淘汰最老条目(Map 迭代序 = 插入序)。 */
function trimToCap<K, V>(map: Map<K, V>): void {
  while (map.size > MAX_TRACKED_SESSIONS) {
    const oldest = map.keys().next().value as K | undefined
    if (oldest === undefined) return
    map.delete(oldest)
  }
}

/**
 * 安装"路由切换 → 工具面说明"注入。
 * @param ctx - 插件上下文(session/event 与 agent/pre-step 两个事件面)。
 */
export function installModelSwitchToolGuide(ctx: Context): void {
  /** 会话 → 最近一次选中的 provider。 */
  const lastRoute = new Map<string, string>()
  /** 会话 → 待注入的工具面切换(from → to);下一次可用 pre-step 消费。 */
  const pending = new Map<string, { from: string | undefined; to: string }>()

  ctx.on('session/event', (...args: unknown[]) => {
    const event = args[1] as { type?: unknown; data?: unknown } | undefined
    if (event?.type !== 'model/selection') return
    const id = sessionIdOf(args[0])
    if (id === undefined) return
    const to = (event.data as { provider?: unknown } | undefined)?.provider
    if (typeof to !== 'string' || to.length === 0) return
    const from = lastRoute.get(id)
    lastRoute.set(id, to)
    trimToCap(lastRoute)
    if (from === to) return
    // 与 CodeBuddy 无关的切换(如原生模型之间):不注入,仅更新路由记忆。
    if (guideText(from, to) === undefined) return
    pending.set(id, { from, to })
    trimToCap(pending)
  })

  ctx.on('agent/pre-step', async ({ agent, messages, signal, step }, next) => {
    const decision = await next()
    if (decision.kind === 'reject' || signal.aborted) return decision
    const id = agent.session.header.id
    const target = pending.get(id)
    if (target === undefined) return decision
    // 空步会被 loop 跳过(本步没有可发送内容):注入会随空步丢失——保留待注入。
    if (decision.messages.length === 0 && (step === 1 || messages.length > 0)) return decision
    pending.delete(id)
    const text = guideText(target.from, target.to)
    if (text === undefined) return decision
    const ours = createUserMessage({
      content: [{ type: 'text', text }],
      source: {
        kind: 'codebuddy',
        form: 'notice',
        summary: boundContextSummary(`tools: ${target.from ?? '(new)'} → ${target.to}`),
      },
    })
    // 顺序:插到"本步最后一条真实输入"之前——注入若排在真实用户消息之后,
    // 模型回看历史时会把最后一条 user 消息(=注入)当成"用户的最新发言"而搁置
    // 真实输入(与 prompt-inject 25aca6d 同因;核心 UI 会把这类前置注入重锚到
    // 用户气泡之后渲染,故界面观感不变,模型侧顺序才是关键)。
    const list = decision.messages
    let at = -1
    for (let i = list.length - 1; i >= 0; i -= 1) {
      const kind = (list[i] as { source?: { kind?: unknown } } | undefined)?.source?.kind
      if (kind === 'user' || kind === 'agent-message') { at = i; break }
    }
    return {
      ...decision,
      messages: at >= 0
        ? [...list.slice(0, at), ours, ...list.slice(at)]
        : [...list, ours],
    }
  })
}
