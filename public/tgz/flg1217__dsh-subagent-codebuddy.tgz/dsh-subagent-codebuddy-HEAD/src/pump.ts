/**
 * 回合泵(路线 C1):**一个 CodeBuddy 回合 = 一个 ACP 进程 = 多个 dsh step**。
 *
 * 背景:CodeBuddy 的回合内部是「模型调用 → 工具执行 → 模型调用 …」的循环,
 * 而 dsh 的 step 语义是「一次模型调用 = 一个 step」。旧实现把整个 CodeBuddy
 * 回合塞进一次 provider 调用(=一个巨型 step),文本/工具顺序、每步统计、
 * 分页、客户端 last-wins 渲染全部错位。
 *
 * 本模块把那个内部循环显式化:
 * - **泵**:进程/握手/prompt 只做一次,持续消费 ACP update,按模型调用切段
 *   (segment);
 * - **attach()**:每个 dsh step 调一次,消费当前段;段在「工具调用边界」收尾
 *   时返回,agent-loop 于是写原生 `assistant/message` + `tool/call`,并调用
 *   本模块注册的**回放工具**执行工具调用——回放工具只等 ACP 报来的结果,
 *   由 loop 写原生 `tool/result`;随后 loop 开下一个 step,attach() 消费下一段;
 * - **收尾**:最后一段(无工具调用)在 tail 窗口结束后返回,loop 以
 *   `completed` 闭合回合。
 *
 * 边界识别(实测 cb-segment-probe.mjs):
 * - 工具调用以 `tool_call`(in_progress,参数流式)→ `tool_call`(pending,
 *   `toolArgumentsComplete=true`,全参)出现;`tool_call_update`(completed/failed)
 *   带结果;
 * - 模型调用结束的信号:`agentPhase` → `tool_executing`,或首个工具结果到达,
 *   或静默兜底(老 CLI 无 phase);
 * - `usage_update` 每次模型调用一条,在工具开始执行后 ~100ms 到;收段前给它
 *   一个短宽限期,保证每段带上自己的用量。
 * @module subagent-codebuddy/pump
 */

import { randomUUID } from 'node:crypto'
import type { Context } from '@deepseek-ai/cordis'
import type { JsonValue } from '@deepseek-ai/dsh-util-values'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { ToolCallId, createAssistantMessage } from '@deepseek-ai/dsh-llm'
import type { ContentBlock, StreamChunk, TokenUsage } from '@deepseek-ai/dsh-llm'
import { AcpConnection, DEFAULT_ACP_RUN_TIMEOUTS, cliToolPolicyArgs, isProgressUpdate, toolNameOf, usageOfUpdate } from './acp.js'
import type { AcpClientRequest, AcpPromptResult, AcpTimeouts, AcpUpdate } from './acp.js'
import { agentIdFromOutput, SubagentMirror } from './mirror.js'
import { foldPendingInsertions } from './inbox.js'
import type { PendingInsertion } from './inbox.js'
import { todoToolKind } from './todo-bridge.js'
import type { TodoListState } from './todo-bridge.js'
import { failureOfError, formatFailureLine, isFailureOutcome, parseCodebuddyFailure } from './failure.js'
import { toolResultBlocksFromText } from './tool-image.js'
import type { AttachmentsSaveFace } from './tool-image.js'
import { announceDelegateTools, DELEGATE_TOOL_METHOD } from './delegate.js'
import {
  blocksToText,
  bridgeTargetTool,
  CLI_MIRROR_TOOL_PREFIX,
  DSH_MCP_SERVER_NAME,
  listDshBridgeTools,
  McpDispatchAbortedError,
  McpDispatchTimeoutError,
  registerDshMcpServer,
  registerMcpLoopDispatcher,
} from '@flg1217/dsh-mcp'
import type { DshToolRunResult } from '@flg1217/dsh-mcp'
import { syncCliIntegrations } from './cli-integrations.js'
import { steerDebug } from './steer-debug.js'
import { mcpConfigArgs } from './mcp-config.js'
import type { SessionId } from '@deepseek-ai/dsh-session'

/**
 * 泵释放后继续盯一条迟到结果(独立于泵的一次性订阅)。
 *
 * **主路径已改为"答案提交即恢复对话"**:交互式调用默认不设上限
 * (见 {@link INTERACTIVE_MCP_CALL_TIMEOUT_MS}),答案由等待者直接解析、
 * 交回 CLI 模型继续同一条对话;本订阅只覆盖**泵已释放**的异常路径
 * (CLI 回合被杀、客户端断连、注入未被消费等):工具可能仍在 loop 侧执行,
 * 其结果到达时泵已释放、事件订阅已被摘除——若不接管,"真实结果"永远不会
 * 进会话(CLI 收到的只有超时错误,交互式工具的回答更是无人接续)。
 * 这里用一次性 session/event 订阅盯到该 callId 的 tool/result 即补投,
 * 超过 TTL 无果自动摘除(防泄漏)。
 *
 * **TTL 必须覆盖"真人作答"的时长**(2026-09-20 实测事故):`ask_user_question`
 * 转发超时后泵随即释放并把这条转给本订阅;用户 61 分钟后才作答,而当时的 TTL
 * 只有 10 分钟——订阅早已自毁,答案落地进会话但**从未到达 CLI 的模型**
 * (下一步补发只剩"继续完成之前未完成的任务"框架文本,模型以为消息丢了)。
 * 24h 的代价只是每条超时调用一个闭包+订阅(事件本就罕见),远小于丢一条
 * 真人答案的代价。
 */
export const LATE_MCP_RESULT_TTL_MS = 24 * 60 * 60_000

/**
 * @param ctx - 插件上下文(事件面)。
 * @param sessionId - 目标 dsh 会话。
 * @param callId - 等待中的调用 id。
 * @param toolName - 工具名(补投文案)。
 * @param sink - 补投口(经会话注入把结果交给模型)。
 * @param ttlMs - 订阅存活时长(测试可注入;默认 {@link LATE_MCP_RESULT_TTL_MS})。
 */
export function watchLateMcpResult(
  ctx: Context,
  sessionId: string,
  callId: string,
  toolName: string,
  sink?: (toolName: string, text: string) => void,
  ttlMs: number = LATE_MCP_RESULT_TTL_MS,
): void {
  const on = (ctx as unknown as {
    on?: (name: string, handler: (...args: unknown[]) => void) => (() => void) | void
  }).on
  if (on === undefined) return
  let done = false
  const off = on('session/event', (...args: unknown[]): void => {
    if (done) return
    const session = args[0] as { id?: unknown; header?: { id?: unknown } } | undefined
    const event = args[1] as { type?: unknown; data?: unknown } | undefined
    if (event?.type !== 'tool/result') return
    const sid = typeof session?.header?.id === 'string' ? session.header.id : session?.id
    if (sid !== sessionId) return
    const message = (event.data as {
      message?: {
        source?: { callId?: unknown }
        content?: readonly { toolCallId?: unknown; content?: readonly unknown[] }[]
      }
    } | undefined)?.message
    const block = message?.content?.[0]
    const cid = typeof block?.toolCallId === 'string'
      ? block.toolCallId
      : (typeof message?.source?.callId === 'string' ? message.source.callId : undefined)
    if (cid !== callId) return
    done = true
    off?.()
    sink?.(toolName, blocksToText(Array.isArray(block?.content) ? block.content as readonly unknown[] : []))
  })
  const timer = setTimeout(() => { done = true; off?.() }, ttlMs)
  timer.unref?.()
}

/** 工具结果(ACP 报来的原始形态)。 */
interface ToolOutcome {
  text: string
  isError: boolean
}

/** 一次工具调用的泵内状态。 */
interface CallState {
  id: string
  /** CodeBuddy 原始工具名(镜像/别名判定用)。 */
  rawName: string
  /** 落地进 dsh 事件的名字(归一化 + 图片别名)。 */
  dshName: string
  argsJson: string
  /** 是否已向段内发射 tool-call 块(参数完整后才发射)。 */
  announced: boolean
  outcome?: ToolOutcome
  waiting: Array<{
    resolve: (outcome: ToolOutcome) => void
    reject: (error: Error) => void
  }>
}

/** 已发射的 delegate 块的待认领条目(args 用于与请求精确配对)。 */
interface DelegateQueueEntry {
  callId: string
  args: string
}

/** 先到一步的 delegate 请求(等块发射认领)。 */
interface PendingDelegateRequest {
  args: string
  claim: (callId: string) => void
}

/** 一段 = 一次模型调用(文本/思考块 + 工具调用)。 */
interface Segment {
  chunks: StreamChunk[]
  cursor: number
  /** 本段内参数完整的工具调用 id。 */
  calls: string[]
  usage?: TokenUsage
  closed: boolean
  /** 收段原因:tools=工具边界(还有下一段);settle=回合收尾。 */
  outcome: 'tools' | 'settle'
  /** 已发射的块计数(块索引分配)。 */
  blockIndex: number
  /** 当前打开的文本/思考块(收段前闭合)。 */
  open?: { kind: 'text' | 'reasoning'; index: number; messageId: string; text: string }
}

/** 会话面(todo 折叠/插话轮询需要 ownEvents;todo 快照写入需要 append)。 */
export interface PumpSessionFace {
  ownEvents?: () => readonly { type: string; data?: unknown }[]
  append?: (type: string, data: unknown) => unknown
}

/** 泵的宿主依赖(由 adapter 提供;避免与 adapter.ts 形成运行时循环)。 */
export interface PumpHost {
  ctx: Context
  command: string
  prefixArgs: string[]
  extraArgs: string[]
  /**
   * 工具桥接模式(默认 `mcp`):mcp = spawn 加 `--mcp-config` 连 dsh 的 HTTP
   * MCP server、不发 delegate 注册;delegate = 旧 DelegateTool 通道。
   */
  bridgeMode?: 'mcp' | 'delegate'
  /** 推理强度(--effort;未选则不传,保持 CLI 默认)。 */
  reasoningEffort?: string
  timeouts?: AcpTimeouts
  maxAttempts?: number
  retryDelayMs?: number
  steerPollMs?: number
  nativeBaseDir?: string
  /** dsh 会话 id(泵的键,也是回放工具注册的 scope)。 */
  dshSessionId: string
  model: string
  /** 读图引导:按当前模型是否支持图片输入分流(缺省 native,保持旧行为)。 */
  imageGuidance?: ImageReadGuidance
  cwd: string
  acpCwd: string
  /** 已有 CodeBuddy 会话(load 复用);否则 session/new。 */
  resume?: { acpId: string }
  prompt: string
  images: Array<{ data: string; mimeType: string }>
  /** load 失败时回退:完整历史重发的提示词。 */
  fallbackPrompt: () => Promise<{ prompt: string; images: Array<{ data: string; mimeType: string }> }>
  /** 会话登记(续接锚点:sentCount = 本次发送时 dsh 消息总数;lastMessageId = 本次覆盖到的最后一条消息)。 */
  rememberConversation: (acpId: string, sentCount: number, lastMessageId?: string, systemHash?: string) => void
  /**
   * 本次回合 dsh system prompt 的版本哈希(随续接记录落盘):记录"CLI 已见过
   * 哪一版 system prompt",内容变化时适配器才补发(见 adapter.systemHashOf)。
   */
  systemHash?: string
  /** 本次发送覆盖到的最后一条消息 id(补发主锚,写回续接记录)。 */
  sentLastMessageId?: string
  /** 登记失效(CodeBuddy 侧会话丢失)。 */
  forgetConversation: () => void
  sentCount: number
  session?: PumpSessionFace
  /**
   * 本回合打开着的 turn/step(adapter 用 `findOpenStep` 从会话事件算出)。
   * 补写 `assistant/message` 要用它对齐会话事件的字段。
   */
  turnStep?: { turn: number; step: number }
  /** 子会话 header(镜像用)。 */
  childSession?: { header?: { agentPreset?: string; delegationDepth?: number; parentSession?: string } }
  attachmentsOf: () => AttachmentsSaveFace | undefined
  /** 本会话的 todo 折叠状态(跨回合复用;无则 undefined)。 */
  todoStateOf: () => TodoListState | undefined
  /** 转发 id 标记(next-step 插话);已标记过返回 false。 */
  markForwarded: (id: string) => boolean
  /** 查询 id 是否已投递过(悬挂条目每轮重折叠,靠它跳过已发的)。 */
  isForwarded?: (id: string) => boolean
  /** 撤销投递标记(prompt 回退发送失败时回滚,留给补发路径)。 */
  unmarkForwarded?: (id: string) => void
}

/** 仅供测试:释放残留的泵(跨用例隔离)。 */
export function resetPumpStateForTests(): void {
  for (const pump of livePumps.values()) pump.dispose()
  livePumps.clear()
}

/**
 * 回放工具的 presentationMeta 投影:只透传显式 meta(无损 JSON 对象),
 * 缺失/非法一律给 `{}`。
 *
 * dsh 的工具框架对投影结果做无损 JSON 快照——返回 `undefined` 会被判
 * `INVALID_TOOL_OUTPUT` 并把**真实工具结果整个吞掉**(实测:委托工具的子代理
 * 输出因此变成 "returned invalid output",模型只看到报错)。
 * @param value - 回放工具返回值(`{ blocks, meta? }`)。
 * @returns 可快照的投影元数据(至少是空对象)。
 */
export function replayPresentationMeta(value: unknown): Record<string, JsonValue> {
  const meta = (value as { meta?: unknown } | null | undefined)?.meta
  return meta !== null && typeof meta === 'object' && !Array.isArray(meta)
    ? meta as Record<string, JsonValue>
    : {}
}

/** 消息 content blocks → 纯文本(text 块拼接;其余忽略)。 */
function textOfContent(content: unknown): string {
  if (!Array.isArray(content)) return ''
  return content
    .filter((block): block is { type: string; text: string } =>
      block !== null && typeof block === 'object'
      && (block as { type?: unknown }).type === 'text'
      && typeof (block as { text?: unknown }).text === 'string')
    .map(block => block.text)
    .join('')
}

/** 从配对队列取 args 精确匹配的条目;无匹配退回队首(顺序一致性兜底)。 */
function takeMatch<T extends { args: string }>(queue: T[], args: string): T | undefined {
  if (queue.length === 0) return undefined
  const exact = queue.findIndex(entry => entry.args === args)
  const at = exact >= 0 ? exact : 0
  return queue.splice(at, 1)[0]
}

/** 活跃泵:回放工具经此找到当前回合。 */
const livePumps = new Map<string, TurnPump>()

/**
 * 回放工具的返回值形态(与 `output.schema = { type: 'json' }` 对应)。
 *
 * dsh 的 json 逃生口把 execute 的返回类型推成 `never`,所以必须有一次断言。
 * 收口在此处(全文件唯一),各分支直接返回本形态即可,不必各自写
 * `as unknown as never` —— 断言理由只解释一次,也不易漏改。
 */
type ReplayToolValue = { blocks: ContentBlock[]; meta?: unknown }
function asReplayValue(value: ReplayToolValue): never {
  return value as unknown as never
}

/** 段收尾后的 usage 宽限期(毫秒):等本次模型调用的用量样本归段。 */
const USAGE_GRACE_MS = 700
/** 工具边界静默兜底(毫秒):无 phase 信号的老 CLI 用它判定模型调用结束。 */
const BOUNDARY_QUIET_MS = 1_000
/** 泵心跳间隔(毫秒):steer 轮询 / 看门狗 / 收段判定共用。 */
const TICK_MS = 100
/** delegate 请求等待"块发射认领"的超时(毫秒):正常毫秒级,超时即回收挂起。 */
const DELEGATE_PAIR_TIMEOUT_MS = 60_000
/**
 * 尾注里向模型声明的"前台工具调用超时预算"(秒)。
 *
 * ⚠️ **这是未经验证的引导值,不是测得的客户端超时。** 代码里不存在任何 30s
 * 常量(ACP 默认是 firstMs 60s / idleMinMs 150s / idleMaxMs 600s);30s 只是
 * 为了让模型"长命令一律走 run_in_background"而写进尾注的保守口径。
 * **只用于尾注文案,不得再拿它推导服务端看门狗**(2026-09-13 曾这样推导过一次,
 * 见 {@link MCP_CALL_TIMEOUT_MS} 的说明)。
 */
export const CLI_TOOL_CALL_TIMEOUT_S = 30
/**
 * MCP 通道转发看门狗(毫秒):**"注入未被消费"的异常兜底,不是工具执行时长上限**。
 *
 * 正常路径下它不该触发,因为两条腿各有归宿:
 * - 注入的段一旦被 loop 消费,工具就在 dsh 原生管线里跑——跑多久由工具自己与
 *   loop 的静默看门狗(guardCapMs,默认 30 分钟)决定。**长命令本来就该慢慢跑完**,
 *   不该被这一层截断(前台阻塞式长任务同样如此)。
 * - 回合结束 / 泵释放时,`finish()` / `dispose()` 会立刻 reject 所有等待者,
 *   不依赖本看门狗。
 * 所以它唯一覆盖的是"loop 卡死但回合尚未结束"这种异常,取值应当**宽松**。
 *
 * **2026-09-13 修正记录(重要)**:本值一度被改成 25s,依据是"CLI 侧 30 秒超时"。
 * 该 30 秒经查只是尾注里的一句断言({@link CLI_TOOL_CALL_TIMEOUT_S}),代码中并无
 * 对应常量,属**未经验证的数字**。用未验证的数字反推看门狗会带来实际回归:任何
 * 前台耗时 >25s 的命令(构建/测试/迁移)都会被误判超时并回 `McpDispatchTimeoutError`,
 * 而它本来可以正常跑完并把结果交回模型。故恢复宽松兜底。
 *
 * 若将来**实测**出 CLI 客户端的真实超时 T_client(手段:mcp-server.ts 的
 * `clientGoneAt` 日志已带"客户端等待"耗时),再考虑把本值调到略小于 T_client——
 * 那样能在客户端放弃前,把"勿盲目重试"这句更明确的错误先送到模型手里。届时应同时
 * 把 {@link CLI_TOOL_CALL_TIMEOUT_S} 的尾注口径对齐到实测值。
 */
export const MCP_CALL_TIMEOUT_MS = 300_000
/**
 * 交互式工具(等真人作答)的转发兜底窗口:**0 = 不设上限**(真人就是时钟)。
 *
 * 300s/30min 这类上限对 `ask_user_question` / `exit_plan_mode` 是错的层:loop
 * 完全健康(工具正在执行、就等用户点提交),超时掐掉的不是"卡死的注入"而是
 * "还没作答的人"。**答案提交本身就是恢复对话的触发点**——等待者由 tool/result
 * 解析、MCP 响应把答案交回 CLI 的模型继续同一条对话;任何上限都只会在人还没答完
 * 时把这条链掐断,答案随后只能走"迟到补投"绕路(2026-09-20 事故:30 分钟上限
 * 触发 → 泵随 CLI 回合收尾释放 → 用户 61 分钟后作答,答案只落到 dsh 会话,
 * CLI 模型只收到"继续完成之前未完成的任务"框架文本,以为消息丢了)。
 *
 * 泄漏面很小:等待者只在一个 Promise + (可选)定时器上;泵释放/回合中止仍会
 * 立刻拒绝它(dispose 路径,与上限无关)。需要硬顶的部署可用
 * `AcpTimeouts.interactiveMcpCallTimeoutMs` 显式配置(>0 生效)。
 */
export const INTERACTIVE_MCP_CALL_TIMEOUT_MS = 0
/** 需要真人作答、按交互式窗口计时的工具集(与 mcp-server 的注释口径一致)。 */
const INTERACTIVE_MCP_TOOLS: ReadonlySet<string> = new Set(['ask_user_question', 'exit_plan_mode'])
/**
 * 读图引导:多模态模型用原生 `read_image`(图片直接进上下文);仅文本模型用
 * `read_image_agy`(AGY 转述);两者都不可用时如实说明(不指路不存在的工具)。
 */
export type ImageReadGuidance = 'native' | 'agy' | 'unavailable'

/**
 * 按模态生成读图引导句(工具名前缀随桥接模式)。
 * @param guidance - 读图路径选择(见 {@link ImageReadGuidance})。
 * @param prefix - 工具名前缀:delegate 为 `dsh_`,mcp 为 `mcp__dsh__`。
 * @returns 一句可拼进尾注/系统说明的中文引导。
 */
function imageReadLine(guidance: ImageReadGuidance, prefix: 'dsh_' | 'mcp__dsh__'): string {
  if (guidance === 'native') {
    return '读图片用 Read 工具直接读图片文件路径(已放行)——图片会进入你的上下文并由 CodeBuddy 侧适配;不要改用 '
      + `${prefix}read_image_agy 让 AGY 转述,除非用户明确要求 AGY 转述`
  }
  if (guidance === 'agy') {
    return `读图片用 ${prefix}read_image_agy——AGY 读图后返回文字描述(可用 prompt 参数指定关注点);本会话没有可用的原生读图工具`
  }
  return '读图片:本会话没有可用的读图工具(模型不支持图片输入且未启用 AGY 读图)——需要读图时如实告知用户'
}

/**
 * dsh 发起的调用的固定尾注(附在每条 prompt 末端)。
 *
 * CodeBuddy CLI 自带子代理体系(Task/Agent 团队)与自带后台任务(bash
 * run_in_background / docker exec -d),而这条链路里它是被 dsh 拉起的模型
 * 后端:子任务必须交给 dsh 的子代理(委托工具 `dsh_subagent`),长命令必须
 * 走 `dsh_bash`——只有 dsh 通道的任务会进会话树/后台面板,并在完成时唤起
 * 下一轮。尾注同时声明"回合结束后不会自动恢复"的落点:否则模型会承诺
 * "等 X 完成后继续汇报",而外部任务没有完成事件,用户只能主动催。
 * 位置固定在末尾——模型对最新一条输入的尾部指令最敏感。
 * @param guidance - 读图引导(按当前模型是否支持图片输入分流)。
 * @returns 完整尾注文本。
 */
export function dshDelegationNote(guidance: ImageReadGuidance): string {
  return [
  '[dsh 运行环境]',
  '本次调用由 dsh 框架发起:你(CodeBuddy)作为 dsh 的模型后端运行。',
  '本会话的全部 dsh 工具都以 DelegateTool 的 toolId="dsh_<原工具名>" 注册(常见:dsh_bash、dsh_subagent、dsh_read、dsh_grep)——它们在 dsh 侧执行(受沙箱/审批约束、进会话日志与审计):',
  '- toolId 必须用小写下划线原名:dsh_bash ✓、Dsh-bash ✗、dsh-bash ✗。绝不要发空的 DelegateTool 调用(delegate_tool {})来"枚举工具"——它会挂起整个回合且不会有任何返回。不确定某个工具是否存在时,直接按原工具名加 dsh_ 前缀试即可。',
  '- JSON 参数转义:要在文件里写字面反斜杠+n(如 Python 的 print("\\n"))时,JSON 参数必须写 \\\\n(双反斜杠);写单 \\\\n 会按 JSON 标准解析成真实换行——这是 JSON 语义不是工具的错。含大量转义的文件优先用 dsh_write 的 content 配 chr(10)/拼接构造,或分段小步写入。',
  `- DelegateTool 前台执行 ${CLI_TOOL_CALL_TIMEOUT_S} 秒超时:可能超过 20 秒的命令(构建/测试/对战模拟/服务等)一律 dsh_bash + run_in_background:true——任务进侧栏"后台任务",完成时自动通知并唤醒你继续;前台只跑秒级命令。绝不要用 docker exec -d、自写轮询脚本等外部后台方式:它们不进 dsh——面板不显示、完成收不到,回合结束后对话显示"已完成"而任务还在跑,用户只能来催你。`,
  `- CLI 原生工具(Bash/PowerShell/Edit/Write/Glob/Grep/Read 等)已**全部禁用**:同类能力一律直接用 dsh_<原工具名>;${imageReadLine(guidance, 'dsh_')}。不要换方式绕过(例如把命令包成脚本执行)。`,
  '- 规划工作流:不要试图切换 CLI 的模式(EnterPlanMode 已禁用——CLI 的 plan 模式会拒绝后续修改类调用并把整个回合判失败中断)。dsh 有自己的计划模式:dsh 会通过 plan 段落引导你"先探索、出计划"(由用户开启),完成探索后用 dsh_exit_plan_mode 提交计划给用户审批;日常直接干活即可。',
  '- 沙箱拒绝不绕行:dsh_bash 报 [sandbox: file access denied ...] 时,不要改用 CLI 自带工具执行同一命令绕过沙箱;按工具描述用 sandbox_permissions + justification 走提权审批(审批弹窗即用户同意);被拒或会话禁用审批时即为最终结果,不要换路重试。',
  '- 委派子任务:先 dsh_list_subagent_models 查可用路由,再用 dsh_subagent 委派(默认后台;结算通知会唤醒你);继续同一子代理用 dsh_send_message(input.childId)。不要用 CLI 自带的 agent/Task 工具。',
  '- 你的回合结束后不会自动恢复:不要承诺"等 X 完成后我再汇报/继续"——只有走 dsh 通道的任务会在完成时唤醒你;确实必须用外部方式时,请在回复里如实告诉用户"跑完后需要你叫我一声"。',
  ].join('\n')
}

/**
 * MCP 模式(dsh HTTP MCP server)下的固定尾注:与 delegate 版同构,工具名
 * 换成 CLI 呈现的 `mcp__dsh__<工具名>`(参数走各工具的 MCP schema,不再有
 * toolId 中转),并去掉 DelegateTool 形态专属条款。
 */
export function mcpDelegationNote(guidance: ImageReadGuidance): string {
  return [
  '[dsh 运行环境]',
  '本次调用由 dsh 框架发起:你(CodeBuddy)作为 dsh 的模型后端运行。',
  '本会话的全部 dsh 工具以 MCP 工具暴露,名字形如 mcp__dsh__bash / mcp__dsh__edit / mcp__dsh__subagent;输入参数按各工具自带的 schema 传(结构化约束)。它们在 dsh 侧执行(受沙箱/审批约束、进会话日志与审计):',
  '- 一律使用 mcp__dsh__<工具名>(bash、pwsh、read、read_image、write、edit、glob、grep、subagent、send_message、job_output……)。CLI 原生工具已**全部禁用**,不在你的工具列表里,不要尝试。',
  `- ${imageReadLine(guidance, 'mcp__dsh__')}。`,
  `- 前台 MCP 调用 ${CLI_TOOL_CALL_TIMEOUT_S} 秒超时:可能超过 20 秒的命令(构建/测试/对战模拟/服务等)一律 mcp__dsh__bash + run_in_background:true——任务进侧栏"后台任务",完成时自动通知并唤醒你继续;前台只跑秒级命令。绝不要用 docker exec -d、自写轮询脚本等外部后台方式:它们不进 dsh——面板不显示、完成收不到,回合结束后对话显示"已完成"而任务还在跑,用户只能来催你。`,
  '- 沙箱拒绝不绕行:mcp__dsh__bash 报 [sandbox: file access denied ...] 时,按工具描述用 sandbox_permissions + justification 走提权审批(审批弹窗即用户同意);被拒或会话禁用审批时即为最终结果,不要换路重试。',
  '- 委派子任务:先 mcp__dsh__list_subagent_models 查可用路由,再用 mcp__dsh__subagent 委派(默认后台;结算通知会唤醒你);继续同一子代理用 mcp__dsh__send_message(input.childId)。',
  '- JSON 参数转义:要在文件里写字面反斜杠+n(如 Python 的 print("\\n"))时,JSON 参数必须写 \\\\n(双反斜杠);含大量转义的文件优先用 mcp__dsh__write 的 content 配 chr(10)/拼接构造,或分段小步写入。',
  '- 你的回合结束后不会自动恢复:不要承诺"等 X 完成后我再汇报/继续"——只有走 dsh 通道的任务会在完成时唤醒你;确实必须用外部方式时,请在回复里如实告诉用户"跑完后需要你叫我一声"。',
  ].join('\n')
}

/**
 * 按桥接模式取 prompt 尾注(dsh 运行环境说明)。
 * @param bridgeMode - 工具桥接模式(delegate 用 `dsh_` 前缀,mcp 用 `mcp__dsh__`)。
 * @param guidance - 读图引导(按当前模型是否支持图片输入分流)。
 * @returns 以空行开头的尾注文本。
 */
export function promptTailFor(
  bridgeMode: 'mcp' | 'delegate' | undefined,
  guidance: ImageReadGuidance = 'native',
): string {
  const note = (bridgeMode ?? 'delegate') === 'mcp' ? mcpDelegationNote(guidance) : dshDelegationNote(guidance)
  return '\n\n' + note
}

/** 重启跨 attempt 保留的执行状态(重试是同一任务的延续,已学到的间隔不丢)。 */
export interface PumpStepState {
  mirroredCalls: Set<string>
  maxGapMs: number
}

/**
 * 一个 CodeBuddy 回合的 ACP 泵。生命周期 = 从首次 provider 调用到回合收尾
 * (含 tail 窗口);期间 provider 可被调用多次(每个 dsh step 一次)。
 */
export class TurnPump {
  private conn: AcpConnection | undefined
  private acpSessionId = ''
  private capturing = true
  private readonly deps: PumpHost
  private readonly to: typeof DEFAULT_ACP_RUN_TIMEOUTS & AcpTimeouts
  private readonly maxAttempts: number
  private readonly retryDelayMs: number
  private readonly steerPollMs: number
  private readonly boundaryQuietMs: number
  private readonly usageGraceMs: number
  private readonly stepState: PumpStepState

  private attempts = 0
  /**
   * 尝试代次令牌:restart 立即使其失效(与 attempts 不同——attempts 要等
   * 下一次 runAttempt 才 +1,而旧连接的挂起请求会在 restart 之后立刻迟到
   * reject,那段时间里用 attempts 比对拦不住)。
   */
  private attemptToken = 0
  /** 段队列:进行中/已完成的模型调用段(attach 顺序消费)。 */
  private segments: Segment[] = []
  private readonly calls = new Map<string, CallState>()
  /** 本回合是否起过后台任务(工具参数 run_in_background/background)。 */
  private backgroundLaunched = false
  /** 是否产出过文本(静默失败判定:块可能尚未闭合)。 */
  private hasText = false
  private finished = false
  private failed: Error | undefined
  private disposed = false

  /** 看门狗状态(与旧直写实现同一套动态预算)。 */
  private lastProgressAt = Date.now()
  private progressSamples = 0
  private maxGapMs = 0
  private lastBudgetMs: number
  private stallTimedOut = false
  private killTimer: ReturnType<typeof setTimeout> | undefined
  private cancelLoopTimer: ReturnType<typeof setInterval> | undefined

  /** 尾巴窗口状态。 */
  private promptSettled = false
  private stopReason: string | undefined
  private inFlight = 0
  private promptError: Error | undefined
  /** prompt 结果里的失败分类(refusal + _meta errorMessage/outcome)。 */
  private promptFailure: import('./failure.js').CodebuddyFailure | undefined
  private agentPhaseSeen = false
  private sessionEnded = false
  private lastUpdateAt = Date.now()
  private lastContentAt = 0
  private tailStartAt: number | undefined
  /** 疑似卡住诊断的下次打印时刻(节流;0 = 无待打印)。 */
  private nextDiagAt = 0
  private tailDeadline: number | undefined
  /** CLI 报"空闲"相位的时间(agentPhase=idle);undefined = 本轮未报过。 */
  private lastIdlePhaseAt: number | undefined
  /** 最近一次"工具执行中"相位的时间(它算活动;session_info 心跳不算)。 */
  private lastToolExecutingAt = 0

  /** 收段判定辅助。 */
  private boundarySeenAt = 0
  /** 边界/收尾的一次性补判定定时器(心跳粒度不够时的精确收口)。 */
  private checkTimer: ReturnType<typeof setTimeout> | undefined
  private usageGraceUntil = 0
  private toolExecutingSeen = false
  private firstResultSeen = false

  /** steer 轮询。 */
  private lastSteerPoll = 0
  /** 每条 prompt 的固定尾注(按桥接模式,dsh 运行环境说明)。 */
  private readonly promptTail: string
  /** 桥接模式(回放工具的执行语义按它分派,mcp 模式见 ensureReplayTool)。 */
  private readonly bridgeMode: 'mcp' | 'delegate'
  /** 泵构造时刻(回合开始):插入水位线在锚点不可用时的兜底。 */
  private readonly constructedAt = Date.now()

  /** 子代理镜像 / todo 桥。 */
  private readonly mirrors = new Map<string, SubagentMirror>()
  private readonly subagentCallIds = new Set<string>()

  /**
   * 真工具直发的 delegate 请求等待器:callId → 等待者。
   * pump 把 delegate 调用发射为真工具块,loop 执行后写 tool/result 事件,
   * onSessionEvent 按 callId 把结果交给等待中的 `_codebuddy.ai/delegateTool`
   * 请求。
   */
  private readonly delegateWaiters = new Map<string, {
    resolve: (result: { output: string; isError: boolean }) => void
    reject: (error: Error) => void
  }>()
  /**
   * 已发射但请求还没到的 delegate 块:toolId → 队列(FIFO + args 精确优先)。
   * 请求先于 update 到达时反向登记进 pendingDelegateRequests,由
   * claimDelegateRequest 双向认领。
   */
  private readonly unclaimedDelegates = new Map<string, DelegateQueueEntry[]>()
  /** 请求先到、块还没发射的 delegate 请求:toolId → 认领回调队列(FIFO + args 精确优先)。 */
  private readonly pendingDelegateRequests = new Map<string, PendingDelegateRequest[]>()
  /** 结果先到(请求未到)的缓存:callId → 结果,由 awaitDelegateResult 认领。 */
  private readonly delegateResults = new Map<string, { output: string; isError: boolean }>()
  /** session/event 订阅解绑句柄。 */
  private disposeEventHook: (() => void) | undefined
  /** MCP→loop 转发器的注销句柄(泵生命周期内有效)。 */
  private disposeLoopDispatcher: (() => void) | undefined
  /**
   * 本泵注册的回放工具(`cli_*` 镜像)注销器。
   *
   * 镜像只在 CodeBuddy 回合内可用——泵释放时统一注销;不注销则回合结束/
   * 切模型后它们仍留在会话工具面里,被模型选中后只能拿"没有运行中的
   * CodeBuddy 回合"错误(实测:codebuddy → dsh 原生切模型后,读图类调用
   * 误中残留镜像而损坏)。
   */
  private readonly replayToolDisposers: Array<() => void> = []
  /** steer 在飞防重:同一条消息不等响应完成不重复发起。 */
  private readonly inFlightForwards = new Set<string>()
  /**
   * MCP 调用等待:callId → 等待者。dispatchMcpCall 把调用伪装成本步的
   * tool-call 块(独立段)交给 loop 原生执行,tool/result 事件按 callId 回填。
   */
  private readonly mcpWaiters = new Map<string, {
    resolve: (result: DshToolRunResult) => void
    reject: (error: Error) => void
  }>()
  /**
   * 转发超时后仍可能迟到的调用:callId → { 工具名, 迟到投递口 }。
   *
   * 超时不该让结果永久丢失:分发拒绝后 CLI 收到的是超时错误,工具(尤其
   * ask_user_question 这类等真人作答的)稍后完成时,tool/result 到达这里经
   * 投递口补投回会话,CLI 的模型才有机会看到真实结果。
   */
  private readonly lateMcpCalls = new Map<string, {
    name: string
    sink?: (toolName: string, text: string) => void
  }>()
  /**
   * 待投递的插话(id → 文本):**事件驱动探测 + 显式重试**。
   *
   * ## 为什么不再用轮询 + 水位线(2026-09-22 用户报障后重写)
   * 旧实现靠定时轮询,并用水位线在 `ownEvents()` 里**按下标增量扫描**已 claim 的
   * `user/message`。用户报障「插队消息收不到」时:dsh 侧消息被正常 claim 进 step
   * 输入,CLI 侧一个字都没到,而轮询/水位线那套**不落任何痕迹**,只能读源码猜。
   * 更根本的是,下标水位线依赖一个隐含前提——"泵读到的 events 视图会持续增长"。
   * 一旦该视图冻结(或轮询被守卫长期挡住),扫描就**永久跳过**新消息且毫无症状。
   *
   * ## 现在的分工
   * - **探测**:订阅 `session/event`(泵本来就有该订阅,见 subscribeSessionEvents)。
   *   事件到达即入队 —— 不依赖 ownEvents() 视图、不依赖水位线、不依赖轮询周期。
   * - **投递**:入队后立刻尝试 steer;无连接/在飞就**留在队列里**,由 tick 重试,
   *   直到投出或回合结束。投不出就是投不出,不会静默消失(steer-debug 有痕迹)。
   */
  private readonly pendingSteers = new Map<string, string>()
  /** 本轮"投不出去"是否已写过诊断(连接恢复后复位,避免每 tick 刷屏)。 */
  private steerBlockedLogged = false

  private readonly tickTimer: ReturnType<typeof setInterval>
  private wake: (() => void) | undefined
  /** 外部 abort(agent-loop 的回合信号)。 */
  private readonly onAbort = (): void => {
    if (this.acpSessionId !== '') this.conn?.notify('session/cancel', { sessionId: this.acpSessionId })
    this.cancelLoopTimer ??= setInterval(() => {
      if (this.acpSessionId !== '') this.conn?.notify('session/cancel', { sessionId: this.acpSessionId })
    }, 1_000)
    // 消费方(当前 step 的 stream)会自行收尾并释放;但若 abort 落在两次
    // provider 调用之间(上一步已返回、下一步还没开),没有消费方负责释放——
    // 宽限一会儿自行收掉,避免进程/回放工具悬挂到看门狗硬顶。
    const timer = setTimeout(() => this.dispose(), 1_000)
    timer.unref?.()
    this.wakeAll()
  }

  constructor(deps: PumpHost, private readonly signal: AbortSignal | undefined, stepState: PumpStepState) {
    this.deps = deps
    this.stepState = stepState
    this.to = { ...DEFAULT_ACP_RUN_TIMEOUTS, ...deps.timeouts }
    this.maxAttempts = deps.maxAttempts ?? 2
    this.retryDelayMs = deps.retryDelayMs ?? 3_000
    this.steerPollMs = deps.steerPollMs ?? 1_200
    this.promptTail = promptTailFor(deps.bridgeMode, deps.imageGuidance ?? 'native')
    this.bridgeMode = deps.bridgeMode ?? 'delegate'
    this.boundaryQuietMs = this.to.boundaryQuietMs ?? BOUNDARY_QUIET_MS
    this.usageGraceMs = this.to.usageGraceMs ?? USAGE_GRACE_MS
    this.lastBudgetMs = this.to.idleMaxMs
    livePumps.set(deps.dshSessionId, this)
    this.tickTimer = setInterval(() => this.tick(), TICK_MS)
    this.tickTimer.unref?.()
    signal?.addEventListener('abort', this.onAbort, { once: true })
    // 真工具直发的结果通道:loop 执行真工具后写的 tool/result 从这里取回。
    this.disposeEventHook = this.subscribeSessionEvents()
    // MCP 调用转发:回合活着时,mcp__dsh__* 的 tools/call 伪装成工具调用块
    // 灌进 loop 原生执行(见 dispatchMcpCall)。
    this.disposeLoopDispatcher = registerMcpLoopDispatcher(
      deps.dshSessionId,
      (_sessionId, name, input, lateSink) => this.dispatchMcpCall(name, input, lateSink),
    )
    // 常驻任务表重播:CodeBuddy 任务列表跨回合常驻,dsh 的 todos 投影在每个
    // turn/start 清空——回合开头重写一份当前快照,面板跨回合继续显示同一计划。
    this.replayTodos()
    void this.runAttempt() // 首段:握手 + prompt
  }

  /** 回放工具 → 当前泵(未在跑/已收尾时为 undefined)。 */
  static forSession(sessionId: string): TurnPump | undefined {
    return livePumps.get(sessionId)
  }

  /** 回合是否已被调用方中止(abort 交给 loop 的中断语义收尾)。 */
  private get aborted(): boolean { return this.signal?.aborted === true }

  // ── 消费面(provider stream)────────────────────────────────────────────

  /**
   * 附加到本回合的下一段:顺序吐出该段的 chunk;段在工具边界或回合收尾处返回。
   * 每个 dsh step 调一次。abort 直接返回(由 loop 的中断语义收尾)。
   */
  async *attach(): AsyncGenerator<StreamChunk> {
    for (;;) {
      if (this.aborted) return
      const segment = this.segments[0]
      if (segment !== undefined) {
        while (segment.cursor < segment.chunks.length) yield segment.chunks[segment.cursor++]!
        if (!segment.closed) { await this.waitEvent(); continue }
        this.segments.shift()
        if (this.failed !== undefined) { yield* this.yieldError(this.failed); return }
        yield {
          type: 'finish',
          reason: segment.outcome === 'settle' && this.isMaxTokens() ? { kind: 'max-tokens' } : { kind: 'stop' },
        }
        return
      }
      if (this.failed !== undefined) { yield* this.yieldError(this.failed); return }
      if (this.finished) { yield { type: 'finish', reason: { kind: 'stop' } }; return }
      await this.waitEvent()
    }
  }

  /**
   * 以 finish error 收尾(而非抛出):让 agent-loop 走它自己的
   * `agent/request-error` 路径——消息进 LlmError、回合以错误闭合,
   * 与一次性路径的中断语义一致(可重试与否已在泵内决定)。
   */
  private async *yieldError(error: Error): AsyncGenerator<StreamChunk> {
    yield {
      type: 'finish',
      reason: {
        kind: 'error',
        failure: { message: error.message.slice(0, 500), code: 'CODEBUDDY_EXEC_ERROR' },
      },
    }
  }

  private isMaxTokens(): boolean {
    const stop = this.stopReason?.toLowerCase()
    return stop === 'max_tokens' || stop === 'max-tokens'
  }

  // ── 回合生命周期 ───────────────────────────────────────────────────────

  /** 起一次 ACP 进程 + 握手 + prompt(重启路径也走它)。 */
  private async runAttempt(): Promise<void> {
    if (this.disposed || this.aborted) return
    this.attempts += 1
    this.capturing = true
    this.promptSettled = false
    this.stopReason = undefined
    this.promptError = undefined
    this.promptFailure = undefined
    this.toolExecutingSeen = false
    this.firstResultSeen = false
    this.boundarySeenAt = 0
    this.usageGraceUntil = 0
    this.sessionEnded = false
    this.tailStartAt = undefined
    this.tailDeadline = undefined
    this.lastIdlePhaseAt = undefined
    this.lastToolExecutingAt = 0

    // 参数与旧实现逐字一致(实测过的组合):`--dangerously-skip-permissions`
    // 而非 `--permission-mode`——后者虽是配置项,但从未在此路径生效,不顺手改
    // 行为(改权限参数等于换一套 CLI 行为,需要单独实测)。
    // 端点可能因 owner(先 apply 的插件)被卸载而消失:幂等补注册再生成配置,
    // 否则 mcpConfigArgs 拿不到 URL → CLI 以"内置工具全禁 + 无 --mcp-config"
    // 启动,该回合零工具且完全静默。
    if (this.bridgeMode === 'mcp') registerDshMcpServer(this.deps.ctx)
    const argv = [
      this.deps.command,
      ...this.deps.prefixArgs,
      '--acp',
      '--model',
      this.deps.model,
      ...this.deps.reasoningEffort === undefined ? [] : ['--effort', this.deps.reasoningEffort],
      '--dangerously-skip-permissions',
      ...cliToolPolicyArgs(this.bridgeMode),
      ...mcpConfigArgs(this.bridgeMode, this.deps.dshSessionId),
      ...this.deps.extraArgs,
    ]
    // CLI 进程将在启动时读取 ~/.codebuddy/mcp.json 与 skills 目录:每次
    // 启动前同步一次(dsh 的 MCP 配置 / skills → CLI 原生通道),保证最新。
    syncCliIntegrations({ projectCwd: this.deps.cwd })
    const conn = new AcpConnection(
      argv,
      this.deps.cwd,
      update => this.onUpdate(update),
      request => this.handleClientRequest(request),
    )
    this.conn = conn
    conn.onExit(info => {
      if (conn.wasKilled || this.stallTimedOut || this.disposed) return
      // 进程退出沿用旧语义:不可续跑(重试会重复已完成部分),显式中止。
      this.failRun(new Error(
        `CodeBuddy ACP 进程退出(code ${info.code ?? 'null'}${info.signal !== null ? `,signal ${info.signal}` : ''})${conn.stderrNote()}`,
      ), false)
    })

    try {
      await conn.request('initialize', {
        protocolVersion: 1,
        clientCapabilities: { fs: { readTextFile: false, writeTextFile: false } },
      }, this.to.firstMs)

      if (this.deps.resume !== undefined) {
        try {
          await conn.request('session/load', { sessionId: this.deps.resume.acpId, cwd: this.deps.acpCwd, mcpServers: [] })
          this.acpSessionId = this.deps.resume.acpId
        } catch {
          // CodeBuddy 侧会话存储丢失:回退新会话 + 完整历史重发。
          this.deps.forgetConversation()
          this.deps.resume = undefined
          const full = await this.deps.fallbackPrompt()
          this.deps.prompt = full.prompt
          this.deps.images = full.images
          const created = await conn.request<{ sessionId: string }>('session/new', { cwd: this.deps.acpCwd, mcpServers: [] }, this.to.firstMs)
          this.acpSessionId = created.sessionId
        }
      } else {
        const created = await conn.request<{ sessionId: string }>('session/new', { cwd: this.deps.acpCwd, mcpServers: [] }, this.to.firstMs)
        this.acpSessionId = created.sessionId
      }
      // 锚点必须在 prompt 请求真正发车后才记:早于此进程死掉的话,"从未发出
      // 的输入"会被标记为已发,下轮补发静默丢失(宁可不记:下轮重发只是重复,
      // 不丢内容)。request 已写入连接即视为发出;请求层失败(resolve false,
      // 含 restart 作废旧代次)不记,留给重试/下轮补发。
      const sentAcpId = this.acpSessionId
      // 统一委托面:当前会话可见的全部 dsh 工具以 `dsh_<原名>` 注册为
      // CodeBuddy 的 delegate tools(含 bash/subagent——原生本就是后台任务
      // 与可续用子代理);调用经 dsh 官方工具管线执行(审批/沙箱/事件一致)。
      // MCP 工具走 CLI 原生 MCP 通道、Skill 走 CLI 的 skill 目录,都不在此列。
      // 分批注册(数量上限未知)。**必须等全部批次确认完成再发 prompt**:
      // 注册与 prompt 并发时,CLI 忙于回放大历史会晚处理注册,模型首轮工具
      // 列表就缺 dsh_*(实测:调 dsh_bash 报 "Tool 'dsh_bash' not found",
      // 间歇性、哪批丢看时序——正是"部分工具掉线"的形态)。失败重试一轮,
      // 仍有失败则 failRun 交上层重启回合:没有桥工具的回合是废回合。
      // bridgeMode=mcp:工具经 dsh 的 HTTP MCP server 暴露(spawn 已带
      // --mcp-config),不再发 delegate 注册;delegate 注册整体跳过。
      const parentAgent = this.deps.ctx.get('agents')?.get(this.deps.dshSessionId as SessionId)
      const bridgeTools = this.bridgeMode === 'mcp' || parentAgent === undefined
        ? []
        : listDshBridgeTools(this.deps.ctx, parentAgent)
      // 诊断:名单与注册结果落 dsh-start.log——"某桥工具 not found"时第一时间
      // 区分"名单就没生成它"(dsh 侧 schemas 缺失)还是"CLI 侧注册丢失"。
      console.error(`[codebuddy-bridge] session=${this.deps.dshSessionId} mode=${this.bridgeMode} announce ${bridgeTools.length}: ${bridgeTools.map(tool => tool.id).join(',') || '(none)'}`)
      const BRIDGE_BATCH = 20
      let failedBatches: typeof bridgeTools[] = []
      for (let offset = 0; offset < bridgeTools.length; offset += BRIDGE_BATCH) {
        failedBatches.push(bridgeTools.slice(offset, offset + BRIDGE_BATCH))
      }
      for (let round = 0; round < 2 && failedBatches.length > 0; round += 1) {
        const pending = failedBatches
        failedBatches = []
        for (const batch of pending) {
          try {
            await announceDelegateTools(
              (method, params) => conn.request(method, params, this.to.firstMs),
              this.acpSessionId,
              batch,
            )
          } catch {
            failedBatches.push(batch)
          }
        }
      }
      if (failedBatches.length > 0) {
        throw new Error(`CodeBuddy delegate 工具注册失败(${failedBatches.length}/${Math.ceil(bridgeTools.length / BRIDGE_BATCH)} 批):模型将无法调用 dsh 工具,需重启回合重试`)
      }
      this.capturing = false
      void this.sendPrompt(this.deps.prompt, this.deps.images).then(ok => {
        if (ok && sentAcpId !== '') {
          this.deps.rememberConversation(
            sentAcpId,
            this.deps.sentCount,
            this.deps.sentLastMessageId,
            this.deps.systemHash,
          )
        }
      })
      this.armProgress()
    } catch (error) {
      if (this.aborted || this.disposed) return
      this.failRun(error instanceof Error ? error : new Error(String(error)))
    }
  }

  /**
   * 发一次 `session/prompt`。
   * @returns 请求是否被 CLI 成功处理(false = 连接缺失或请求层失败,供投递
   *   回滚判断——注意 resolve 代表整段 prompt 处理完毕,可能很晚)。
   */
  private sendPrompt(prompt: string, images: Array<{ data: string; mimeType: string }>): Promise<boolean> {
    const conn = this.conn
    if (conn === undefined) return Promise.resolve(false)
    this.inFlight += 1
    this.promptSettled = false
    // 捕获本次尝试代次:restart 会立即令其失效——旧连接的挂起请求在 kill 后
    // 异步迟到 reject,不设防会把旧请求的错误写进新 attempt 的 promptError,
    // 重试刚发车就被判失败。
    const token = this.attemptToken
    return conn.request<AcpPromptResult>(
      'session/prompt',
      {
        sessionId: this.acpSessionId,
        prompt: [
          { type: 'text', text: prompt + this.promptTail },
          ...images.map(image => ({ type: 'image', data: image.data, mimeType: image.mimeType })),
        ],
      },
      0,
    ).then(
      value => {
        if (this.attemptToken !== token) return true
        this.stopReason = value.stopReason
        // 失败详情优先取顶层 errorMessage;refusal 场景只有
        // `_meta["codebuddy.ai/errorMessage"]`(JSON:code/category/statusCode/
        // displayMsg)与 `codebuddy.ai/outcome`(FAILED_MODEL_REQUEST 等)。
        const metaError = value._meta?.['codebuddy.ai/errorMessage']
        const metaOutcome = value._meta?.['codebuddy.ai/outcome']
        const raw = value.errorMessage !== undefined && value.errorMessage.length > 0
          ? value.errorMessage
          : (typeof metaError === 'string' ? metaError : undefined)
        const outcome = isFailureOutcome(metaOutcome) ? metaOutcome : undefined
        if (raw !== undefined || outcome !== undefined) {
          this.promptFailure = parseCodebuddyFailure(raw, undefined, outcome)
        }
        return true
      },
      error => {
        if (this.attemptToken !== token) return false
        this.promptError = error instanceof Error ? error : new Error(String(error))
        return false
      },
    ).finally(() => {
      this.inFlight -= 1
      if (this.attemptToken !== token) return
      if (this.promptError === undefined && this.promptFailure === undefined) this.promptSettled = true
      this.wakeAll()
    })
  }

  /** 回合收尾:断开进程、清空活跃表、唤醒所有等待者。 */
  private finishTurn(): void {
    if (this.finished) return
    this.finished = true
    // 只摘自己:上一回合的泵迟到收尾时,同 id 的新回合泵可能已经登记。
    if (livePumps.get(this.deps.dshSessionId) === this) livePumps.delete(this.deps.dshSessionId)
    this.dispose()
  }

  /** 失败:首段无产出 → 重启;否则整体失败(消费方抛出,loop 收错误回合)。 */
  private failRun(error: Error, retryable = true): void {
    if (this.finished || this.disposed) return
    if (this.canRestart(retryable)) { this.restart(); return }
    this.failed = error
    this.appendFailureClosingMessage(error)
    for (const segment of this.segments) {
      if (!segment.closed) {
        this.closeOpenBlock(segment)
        segment.closed = true
      }
    }
    for (const call of this.calls.values()) {
      for (const waiter of call.waiting.splice(0)) waiter.reject(error)
    }
    this.finishTurn()
    this.wakeAll()
  }

  /**
   * 子代理会话的「临终遗言」:零产出失败时补一条 assistant 文本,让失败原因
   * 随 dsh 的结算通知回到主代理。
   *
   * **为什么必须补**(2026-09-21 实测):dsh 的通知构造
   * (`subagent/src/continuation-messages.ts`)只带一句通用结论 + 子代理**最后一
   * 条 assistant 消息**;而硬失败(401/配额/传输错)时 agent-loop 直接
   * `throw LlmError`,不产生 assistant 消息 → 主代理只收到
   * "Background subagent X failed before it finished. / It left no closing
   * message.",**失败原因整条丢失**(用户报障:子代理错误完全没反馈)。
   * 补写后 `AssistantOutputFold` 会选中它,通知里出现 "Its closing message:
   * CodeBuddy 中断:…401…"。
   *
   * **两道闸门**:
   * - 只在**子会话**(header.parentSession 存在)补:主会话的失败 UI 本来就有
   *   "本轮运行失败"卡,补一条"模型没说过的话"只会污染转录。
   * - 只在**本回合零文本产出**时补:`hasText` 为真时 agent-loop 的
   *   `assistant/attempt` 流文本已经是临终遗言,而 `AssistantOutputFold`
   *   优先选 `assistant/message`——补写会把它顶掉。
   * @param error - 本回合的失败(已含可读原因,如 failure.ts 分类后的文案)。
   */
  private appendFailureClosingMessage(error: Error): void {
    if (this.hasText) return
    if (this.deps.childSession?.header?.parentSession === undefined) return
    const append = this.deps.session?.append
    const at = this.deps.turnStep
    if (append === undefined || at === undefined) return
    try {
      append('assistant/message', {
        turn: at.turn,
        step: at.step,
        message: createAssistantMessage({
          content: [{ type: 'text', text: `CodeBuddy 回合失败:${error.message}` }],
          source: { provider: 'codebuddy', model: this.deps.model },
        }),
        stream: [],
      })
    } catch { /* 补写失败不改变失败本身的语义,消费方仍会拿到 error */ }
  }

  /** 重启资格:失败可续跑、仍是首段、本回合无任何产出、还有重试次数。 */
  private canRestart(retryable: boolean): boolean {
    return retryable
      && this.attempts < this.maxAttempts
      && !this.hasText
      && this.calls.size === 0
      && !this.aborted
  }

  private restart(): void {
    this.disposeProcess()
    this.capturing = true
    // 立即作废旧连接的全部在途回调(迟到 reject 不得污染新 attempt)。
    this.attemptToken += 1
    // 已登记的 CodeBuddy 会话继续复用之(避免重试丢历史)。
    if (this.acpSessionId !== '') this.deps.resume = { acpId: this.acpSessionId }
    this.acpSessionId = ''
    this.promptError = undefined
    this.promptFailure = undefined
    this.stallTimedOut = false
    this.lastProgressAt = Date.now()
    this.segments = []
    this.backgroundLaunched = false
    this.calls.clear()
    // attempt 级判定状态必须整体复位:新 attempt 发 prompt 前,旧的 settled/
    // 相位/尾巴时间戳会让 checkTail 走「正常尾巴」或「静默失败」路径——零产出
    // 首段恰好命中 failRun(段为空 + promptSettled 旧值),重试刚发车即被判死。
    this.promptSettled = false
    this.stopReason = undefined
    this.agentPhaseSeen = false
    this.sessionEnded = false
    this.lastIdlePhaseAt = undefined
    this.lastContentAt = 0
    this.lastToolExecutingAt = 0
    this.lastUpdateAt = Date.now()
    this.tailStartAt = undefined
    this.tailDeadline = undefined
    this.nextDiagAt = 0
    this.boundarySeenAt = 0
    this.usageGraceUntil = 0
    this.toolExecutingSeen = false
    this.firstResultSeen = false
    const timer = setTimeout(() => { void this.runAttempt() }, this.retryDelayMs)
    timer.unref?.()
    this.wakeAll()
  }

  /** 补一次「到期即判定」的定时器(收段宽限/尾巴静默预算)。 */
  private armCheck(delayMs: number): void {
    if (this.checkTimer !== undefined) clearTimeout(this.checkTimer)
    const timer = setTimeout(() => {
      this.checkTimer = undefined
      this.tick()
    }, Math.max(5, delayMs))
    timer.unref?.()
    this.checkTimer = timer
  }

  /** 释放进程与计时器(幂等;不改变 finished 状态)。 */
  private disposeProcess(): void {
    if (this.checkTimer !== undefined) { clearTimeout(this.checkTimer); this.checkTimer = undefined }
    if (this.killTimer !== undefined) { clearTimeout(this.killTimer); this.killTimer = undefined }
    if (this.cancelLoopTimer !== undefined) { clearInterval(this.cancelLoopTimer); this.cancelLoopTimer = undefined }
    try { this.conn?.kill() } catch { /* 已退出 */ }
    this.conn = undefined
  }

  /** 整体收尾:释放一切,唤醒等待者。 */
  dispose(): void {
    if (this.disposed) return
    this.disposed = true
    // 摘掉自己的登记:否则已释放的泵会遮蔽同会话下一回合的新泵。
    if (livePumps.get(this.deps.dshSessionId) === this) livePumps.delete(this.deps.dshSessionId)
    clearInterval(this.tickTimer)
    this.signal?.removeEventListener('abort', this.onAbort)
    // 未完成的工具调用:拒绝所有等待者,避免回放工具悬挂。
    for (const call of this.calls.values()) {
      for (const waiter of call.waiting.splice(0)) waiter.reject(new Error('CodeBuddy 回合已结束'))
    }
    // 真工具直发的等待者与结果通道一并清空(请求挂在旧泵上即回合结束)。
    for (const waiter of this.delegateWaiters.values()) waiter.reject(new Error('CodeBuddy 回合已结束'))
    this.delegateWaiters.clear()
    this.delegateResults.clear()
    this.unclaimedDelegates.clear()
    this.pendingDelegateRequests.clear()
    // 在飞投递的标记不落 forwarded:未确认发出的消息留给下回合补发。
    this.inFlightForwards.clear()
    // 重试队列随之作废:泵没了就没有重试者。未投出的消息仍未 markForwarded,
    // 下回合的 delta 补发会带上(与旧行为一致:不假装投过)。
    this.pendingSteers.clear()
    // MCP 等待者用**专用错误**拒绝:这些调用已注入 loop(可能已开始执行),
    // 端点收到普通 Error 会按"泵不在、尚未执行"回落直执——同一副作用跑两次
    // (生产实测:一条 shell 命令被重复执行)。McpDispatchAbortedError 让端点
    // 走"不回落重执"分支,与兜底超时同待遇。
    for (const waiter of this.mcpWaiters.values()) {
      waiter.reject(new McpDispatchAbortedError('CodeBuddy 回合已收尾,该调用结果未能回填'))
    }
    this.mcpWaiters.clear()
    // 迟到补投不再随泵消亡:未决的 MCP 调用(超时/收尾)若之后完成,真实结果
    // 仍要进会话(CLI 当时只收到超时错误)——交给独立的一次性订阅继续盯。
    for (const [callId, late] of this.lateMcpCalls) {
      watchLateMcpResult(this.deps.ctx, this.deps.dshSessionId, callId, late.name, late.sink)
    }
    this.lateMcpCalls.clear()
    this.disposeEventHook?.()
    this.disposeEventHook = undefined
    this.disposeLoopDispatcher?.()
    this.disposeLoopDispatcher = undefined
    // 注销本泵注册的 `cli_*` 镜像:回合结束它们不再可用,留在工具面里
    // 只会被模型选中后报错(切模型后读图类调用误中残留镜像即由此而来)。
    for (const dispose of this.replayToolDisposers.splice(0)) {
      try { dispose() } catch { /* 注销失败不阻断释放 */ }
    }
    for (const mirror of this.mirrors.values()) void mirror.finish()
    this.mirrors.clear()
    this.disposeProcess()
    this.wakeAll()
  }

  // ── 回放工具 ───────────────────────────────────────────────────────────

  /**
   * 等一次工具调用的结果(回放工具的 execute 调用面)。
   * 结果文本截断 2000 字符(与旧直写路径一致);图片结果转 attachment 内容块,
   * 避免 base64 进会话。
   */
  async awaitResult(callId: string, signal?: AbortSignal): Promise<{ blocks: ContentBlock[]; meta?: unknown }> {
    const call = this.calls.get(callId)
    if (call === undefined) throw new Error(`CodeBuddy: 未知的工具调用 ${callId}(该调用不属于当前回合)`)
    // 已中止的调用方不再登记等待者:否则要等回合收尾的兜底才失败。
    if (call.outcome === undefined && signal?.aborted === true) throw new Error('tool call aborted')
    const outcome = call.outcome ?? await new Promise<ToolOutcome>((resolve, reject) => {
      const waiter: CallState['waiting'][number] = {
        // 包装 resolve:结果到达(或失败)时同步摘掉 abort 监听器——信号是
        // 回合级的,裸注册会随每次工具调用在信号上累积监听器直到 abort。
        resolve: value => { signal?.removeEventListener('abort', onAbort); resolve(value) },
        reject: error => { signal?.removeEventListener('abort', onAbort); reject(error) },
      }
      const onAbort = (): void => {
        const index = call.waiting.indexOf(waiter)
        if (index >= 0) call.waiting.splice(index, 1)
        waiter.reject(new Error('tool call aborted'))
      }
      call.waiting.push(waiter)
      signal?.addEventListener('abort', onAbort, { once: true })
    })
    if (outcome.isError) throw new Error(outcome.text.slice(0, 2000))
    let blocks: ContentBlock[] = [{ type: 'text', text: outcome.text.slice(0, 2000) }]
    // CLI 侧以文本 JSON 交付的图片结果(重放的历史里仍可能出现)→ 转 image 块。
    const converted = await toolResultBlocksFromText(this.deps.attachmentsOf(), outcome.text)
    if (converted !== undefined) blocks = converted as unknown as ContentBlock[]
    return { blocks }
  }

  /**
   * 为此 agent 注册一个回放工具(以**工具注册表**为准判重)。
   *
   * 为什么不用进程内 Set 记账(2026-09-18 修):Set 在生产路径从不失效——
   * 一次注册失败(服务未就绪/抛错)或 agent scope 回收重建后工具已不在,而
   * Set 仍说"已注册"→ 该会话的原生工具调用永久报 `unknown tool "cli_read"`
   * (实测:偶发、不可恢复)。直接查注册表则每次都自愈:缺了就补注册,注册
   * 失败下次调用自然重试。
   * @param name - 镜像工具名(cli_ 前缀)。
   * @param nonBlocking - 立即返回占位而非等待 CLI 的 completed(MCP 模式下
   *   仅 DeferExecuteTool 需要:它的真实执行走 MCP 通道,等待会形成
   *   CLI↔MCP↔loop 三方死锁)。
   */
  private ensureReplayTool(name: string, nonBlocking = false): void {
    const sessionId = this.deps.dshSessionId
    try {
      const agents = (this.deps.ctx as unknown as { get?: (key: string) => unknown }).get?.('agents') as
        | { get?: (id: string) => { ctx?: unknown } | undefined }
        | undefined
      const agent = agents?.get?.(sessionId)
      const tools = (agent?.ctx as { get?: (key: string) => unknown } | undefined)?.get?.('tools') as
        | {
            register?: (definition: unknown) => unknown
            schemas?: (scope?: unknown) => readonly { name?: unknown }[]
          }
        | undefined
      if (tools?.register === undefined) return
      // 注册表里已有同名工具(此前注册过、scope 仍在)→ 不重复注册
      // (同 scope 重复注册会抛错,且抛错本身不影响对话)。
      if ((tools.schemas?.(agent) ?? []).some(schema => schema?.name === name)) return
      const dispose = tools.register(defineTool({
        name,
        description: `“${name}” was executed by the CodeBuddy CLI on this session; this tool records`
          + ' the CLI-reported outcome back into the conversation.',
        parameters: {},
        output: {
          // 值 = { blocks: ContentBlock[], meta?: JSON }:内容由 CLI 输出转换而来,
          // 形态不由 dsh 约束(不透明重放),用 json 逃生口。
          schema: { type: 'json' },
          render: (_args, value) => (value as unknown as { blocks: ContentBlock[] }).blocks,
          presentationMeta: (_args, value) => replayPresentationMeta(value),
        },
        isConcurrencySafe: () => true,
        execute: async (_args, exec) => {
          const pump = TurnPump.forSession(sessionId)
          if (pump === undefined) {
            // 残留镜像(泵已释放但工具还没被注销;正常路径由 dispose 统一注销)。
            // 文案给模型指路:换用同名 dsh 原生工具,而不是停在错误上。
            throw new Error(`CodeBuddy: "${name}" 是 CodeBuddy 桥的回放代理,仅在该会话`
              + '运行中的 CodeBuddy 回合内可用(回合已结束或模型已切换);请改用 dsh 原生同名工具。')
          }
          // MCP 模式死锁破环(仅 DeferExecuteTool):它的真实执行经 MCP 通道
          // 直接回 CLI(tools/call),而 CLI 只有在 MCP 响应后才发 ACP 的
          // completed——等待即三方死锁。此处立即返回占位,让 loop 继续
          // (dispatchMcpCall 注入的段随后执行真工具)。其余原生工具
          // (ToolSearch/Read 等)的真实结果只走 ACP,照旧等待 completed。
          if (nonBlocking) {
            return asReplayValue({
              blocks: [{ type: 'text', text: '(executed on the dsh side via the MCP bridge)' }],
            })
          }
          return asReplayValue(await pump.awaitResult(exec.callId, exec.signal))
        },
      }))
      // 记下注销器:镜像只在 CodeBuddy 回合内可用,泵释放时统一注销
      // (见 replayToolDisposers 字段说明)。
      if (typeof dispose === 'function') this.replayToolDisposers.push(dispose as () => void)
    } catch (error: unknown) {
      // 不记账:下次调用重试(把失败永久化正是 2026-09-18 修的 bug),留痕可查。
      console.error(`[codebuddy-bridge] 回放工具 "${name}" 注册失败(下次调用重试):`
        + (error instanceof Error ? error.message : String(error)))
    }
  }

  // ── CLI → 客户端的请求(extMethod)─────────────────────────────────────

  /**
   * CLI 发来的方法请求:统一入口——`dsh_<工具名>` 的委托工具执行。
   * 返回 undefined 表示本客户端不支持该方法(AcpConnection 会回 -32601)。
   */
  private async handleClientRequest(request: AcpClientRequest): Promise<unknown | undefined> {
    if (request.method !== DELEGATE_TOOL_METHOD) return undefined
    const toolId = typeof request.params['toolId'] === 'string' ? request.params['toolId'] : ''
    const rawInput = request.params['input']
    const input = rawInput !== null && typeof rawInput === 'object' && !Array.isArray(rawInput)
      ? rawInput as Record<string, unknown>
      : {}
    // 空 toolId(空 DelegateTool 调用的"枚举试探"):回工具清单而不是错误。
    // CLI 对空调用通常会挂起不转发;万一转发到客户端,明确的清单能让模型
    // 的试探得到答案(而不是一个语焉不详的错误)。
    if (toolId.length === 0) {
      const parent = this.deps.ctx.get('agents')?.get(this.deps.dshSessionId as SessionId)
      const ids = parent === undefined ? [] : listDshBridgeTools(this.deps.ctx, parent).map(tool => tool.id)
      return {
        status: 'success',
        output: ids.length > 0
          ? `Available dsh tools (call via DelegateTool toolId=<id>):\n${ids.join('\n')}`
          : 'No dsh tools are currently available in this session.',
      }
    }
    // 统一桥:`dsh_<工具名>` → **真工具直发**——调用块已(或即将)作为真工具
    // 名发射进 dsh step,loop 直接执行 dsh 真工具(审批/沙箱/事件/原生卡片),
    // 这里只等 loop 写出的 tool/result 事件,不再代执行(避免双执行)。
    const bridged = bridgeTargetTool(toolId)
    if (bridged !== undefined) {
      try {
        const result = await this.awaitDelegateResult(toolId, input, this.signal)
        return result.isError
          ? { status: 'error', error: { message: result.output } }
          : { status: 'success', output: result.output }
      } catch (error: unknown) {
        return {
          status: 'error',
          error: { message: `dsh tool "${bridged}": ${error instanceof Error ? error.message : String(error)}` },
        }
      }
    }
    return { status: 'error', error: { message: `unknown delegate tool: ${JSON.stringify(toolId)}` } }
  }

  // ── update 处理(同步状态机)────────────────────────────────────────────

  private onUpdate(update: AcpUpdate): void {
    if (this.capturing || this.disposed) return
    this.applyUpdate(update)
    // 事件驱动的收段判定:边界信号(phase=tool_executing / 工具结果)一到就
    // 收口,不等心跳——否则下一段内容可能漏进上一段(实测:慢心跳 + 快速续跑)。
    this.checkSegmentBoundary()
  }

  /** 单条 update 的状态机(不触发收段判定)。 */
  private applyUpdate(update: AcpUpdate): void {
    this.lastUpdateAt = Date.now()
    const kind = update.sessionUpdate
    if (kind === 'session_info_update') {
      const phase = (update._meta?.['codebuddy.ai/agentPhase'] as { phase?: unknown } | undefined)?.phase
      if (typeof phase === 'string') {
        this.agentPhaseSeen = true
        if (phase === 'tool_executing') {
          this.toolExecutingSeen = true
          this.lastToolExecutingAt = Date.now()
        }
        if (phase === 'idle') this.lastIdlePhaseAt = Date.now()
      }
    } else if (kind === 'session_end') {
      this.sessionEnded = true
    }
    if (isProgressUpdate(update)) {
      this.lastContentAt = Date.now()
      this.armProgress()
    }
    switch (kind) {
      case 'agent_thought_chunk':
      case 'agent_message_chunk': {
        const text = update.content?.text ?? ''
        if (text.length === 0) return
        const blockKind = kind === 'agent_thought_chunk' ? 'reasoning' : 'text'
        const messageId = update.messageId ?? `${blockKind}-anonymous`
        const segment = this.openSegment()
        if (segment.open === undefined || segment.open.kind !== blockKind || segment.open.messageId !== messageId) {
          this.closeOpenBlock(segment)
          const index = segment.blockIndex++
          segment.open = { kind: blockKind, index, messageId, text: '' }
          segment.chunks.push({ type: 'block-start', index, blockType: blockKind })
        }
        if (blockKind === 'text') this.hasText = true
        segment.open.text += text
        segment.chunks.push({
          type: blockKind === 'reasoning' ? 'reasoning-delta' : 'text-delta',
          index: segment.open.index,
          text,
        })
        this.wakeAll()
        return
      }
      case 'usage_update': {
        const sample = usageOfUpdate(update)
        if (sample === undefined) return
        // 归段:当前未收尾的段(收段前等 usage 的宽限期依赖它);样本同时作为
        // chunk 交给 loop,统计/上下文占用才有数(assembler 取流内末位样本)。
        const segment = this.openSegment()
        segment.usage = sample
        segment.chunks.push({ type: 'usage', usage: sample })
        this.wakeAll()
        return
      }
      case 'tool_call': {
        if (update.toolCallId === undefined) return
        if (update._meta?.['codebuddy.ai/isSubagent'] === true) this.subagentCallIds.add(update.toolCallId)
        const complete = update._meta?.['codebuddy.ai/toolArgumentsComplete'] === true || update.status === 'pending'
        const known = this.calls.get(update.toolCallId)
        if (known === undefined) {
          if (!complete) {
            // 参数流式生成中:先登记名字,等完整形态再发射。
            this.calls.set(update.toolCallId, {
              id: update.toolCallId,
              rawName: toolNameOf(update),
              dshName: toolNameOf(update),
              argsJson: JSON.stringify(update.rawInput ?? {}),
              announced: false,
              waiting: [],
            })
            return
          }
          this.announceCall(update.toolCallId, toolNameOf(update), update.rawInput ?? {})
          return
        }
        if (!known.announced && complete) {
          const rawInput = Object.keys(update.rawInput ?? {}).length > 0 ? update.rawInput! : {}
          this.announceCall(update.toolCallId, toolNameOf(update), rawInput)
        }
        return
      }
      case 'tool_call_update': {
        if (update.toolCallId === undefined) return
        if (update.status !== 'completed' && update.status !== 'failed') return
        if (update._meta?.['codebuddy.ai/isSubagent'] === true) this.subagentCallIds.add(update.toolCallId)
        let known = this.calls.get(update.toolCallId)
        if (known === undefined) {
          // 兜底:缺 pending 直达 completed 的路径,用 update 自带 rawInput 补发。
          const rawInput = Object.keys(update.rawInput ?? {}).length > 0 ? update.rawInput! : {}
          this.announceCall(update.toolCallId, toolNameOf(update), rawInput)
          known = this.calls.get(update.toolCallId)!
        }
        if (!known.announced) this.announceCall(update.toolCallId, known.rawName, {})
        this.firstResultSeen = true
        const outcome: ToolOutcome = { text: update.rawOutput?.text ?? '', isError: update.status === 'failed' }
        known.outcome = outcome
        for (const waiter of known.waiting.splice(0)) waiter.resolve(outcome)
        this.confirmTodo(update.toolCallId, known.rawName, outcome.text)
        this.finishMirror(update.toolCallId, outcome.text)
        this.wakeAll()
        return
      }
      default:
        return
    }
  }

  // ── 真工具直发的 delegate 结果通道 ────────────────────────────────────

  /** 订阅会话事件(取 loop 执行真工具后的 tool/result)。 */
  private subscribeSessionEvents(): (() => void) | undefined {
    const ctx = this.deps.ctx as unknown as {
      on?: (name: string, handler: (...args: unknown[]) => void) => (() => void) | void
    }
    if (ctx.on === undefined) return undefined
    const handler = (...args: unknown[]): void => {
      this.onSessionEvent(
        args[0] as { id?: unknown; header?: { id?: unknown } } | undefined,
        args[1] as { type?: unknown; data?: unknown } | undefined,
      )
    }
    const dispose = ctx.on('session/event', handler)
    return typeof dispose === 'function' ? dispose : undefined
  }

  /** 会话事件入口:tool/result → 交付等待中的 delegate 请求(或缓存结果)。 */
  private onSessionEvent(
    session: { id?: unknown; header?: { id?: unknown } } | undefined,
    event: { type?: unknown; data?: unknown } | undefined,
  ): void {
    if (this.disposed) return
    const sessionId = typeof session?.header?.id === 'string' ? session.header.id : session?.id
    if (sessionId !== this.deps.dshSessionId) return
    // 插话/注入的**探测**走事件通道(见 pendingSteers 的注释):不依赖
    // ownEvents() 视图与任何水位线。
    if (event?.type === 'user/message') {
      const data = event.data as { id?: unknown; content?: unknown } | undefined
      if (typeof data?.id === 'string' && data.id.length > 0) this.queueSteer(data.id, textOfContent(data.content))
      return
    }
    if (event?.type === 'agent/inbox/spliced') {
      // 悬挂队列(尚未 claim)也即时投一次:claim 发生在 step 边界,等 claim
      // 再投就晚了一个边界。折叠只在 splice 事件到达时做(罕见),不做轮询。
      for (const insertion of foldPendingInsertions(this.deps.session?.ownEvents?.() ?? [])) {
        if (insertion.steer) this.queueSteer(insertion.id, insertion.text)
      }
      return
    }
    if (event?.type !== 'tool/result') return
    const message = (event.data as {
      message?: {
        source?: { callId?: unknown }
        content?: readonly { toolCallId?: unknown; content?: readonly unknown[]; isError?: unknown }[]
      }
    } | undefined)?.message
    const block = message?.content?.[0]
    const callId = typeof block?.toolCallId === 'string'
      ? block.toolCallId
      : (typeof message?.source?.callId === 'string' ? message.source.callId : undefined)
    if (callId === undefined) return
    // MCP 转发调用:结果回填 MCP 响应(先于 delegate 通道匹配)。
    const mcpWaiter = this.mcpWaiters.get(callId)
    if (mcpWaiter !== undefined) {
      this.mcpWaiters.delete(callId)
      // content 原样回传:MCP 端点据此把图片块转成 MCP image 内容块(纯文本
      // 时端点仍用 output,逐字与历史一致)。
      const content = Array.isArray(block?.content) ? block.content as readonly unknown[] : []
      mcpWaiter.resolve({
        output: blocksToText(content),
        isError: block?.isError === true,
        content,
      })
      return
    }
    // 转发已超时、结果迟到的 MCP 调用:经投递口补投回会话(CLI 当时只收到
    // 超时错误,真实结果必须补上——交互式工具的答案全靠这条通道)。
    const late = this.lateMcpCalls.get(callId)
    if (late !== undefined) {
      this.lateMcpCalls.delete(callId)
      late.sink?.(late.name, blocksToText(Array.isArray(block?.content) ? block.content as readonly unknown[] : []))
      return
    }
    const waiter = this.delegateWaiters.get(callId)
    if (waiter !== undefined) {
      this.delegateWaiters.delete(callId)
      waiter.resolve({
        output: blocksToText(Array.isArray(block?.content) ? block.content as readonly unknown[] : []),
        isError: block?.isError === true,
      })
      return
    }
    // 只缓存 **delegate 直发的**未认领结果:真工具直发后所有工具执行都写
    // tool/result,不过滤会把每个普通工具的全量输出留在这张表里,长回合
    // 内存持续膨胀(读取大文件/长命令输出)。delegate 调用由 announceCall
    // 登记,rawName 恒为 'delegate_tool'。
    const call = this.calls.get(callId)
    if (call === undefined || call.rawName !== 'delegate_tool') return
    // 结果先到(loop 执行快、delegateTool 请求稍后才来):缓存,认领时取走。
    this.delegateResults.set(callId, {
      output: blocksToText(Array.isArray(block?.content) ? block.content as readonly unknown[] : []),
      isError: block?.isError === true,
    })
  }

  /** 发射真工具块后,认领可能已挂起的 delegate 请求(请求先到场景)。 */
  private claimDelegateRequest(callId: string, toolId: string, input: Record<string, unknown>): void {
    const args = JSON.stringify(input)
    const pending = this.pendingDelegateRequests.get(toolId)
    const request = pending === undefined ? undefined : takeMatch(pending, args)
    if (request !== undefined) {
      if (pending !== undefined && pending.length === 0) this.pendingDelegateRequests.delete(toolId)
      request.claim(callId)
      return
    }
    const queue = this.unclaimedDelegates.get(toolId) ?? []
    queue.push({ callId, args })
    this.unclaimedDelegates.set(toolId, queue)
  }

  /**
   * MCP 调用转发进 loop(原生执行)。
   *
   * 把外部(MCP 端点)发来的调用伪装成本步的一个工具调用块,**追加进当前打开
   * 的段**后随该段一并收尾——loop 按真实工具名原生执行(审批/沙箱/事件/UI
   * 卡片全原生),tool/result 写入会话时间线并由 onSessionEvent 按 callId
   * 回填 MCP 响应。CLI 模型侧同时从 MCP 通道拿到结果,时间线里的这一步则是
   * "原生记录"。
   *
   * 为什么不能另起独立段(历史竞态,2026-09-13 实测):CLI 的 tools/call(本
   * 方法)与 ACP tool_call 事件先后不定。若本方法先到、只把"无工具调用的旧
   * 段"收尾,loop 会判定"模型输出完成(无工具)"直接 turn/end——独立注入段
   * 永远无人消费(子进程被挂到 300s 超时回落直执),且 CLI 随后的最终答复因
   * 回合已关而无法镜像,整条回答消失。追加进当前段后,该段必然带真工具调用,
   * loop 必定继续执行;镜像回放事件后到时只会另开新段,由后续 step 正常消费。
   * @param name - dsh 真工具名(已由端点做白名单校验)。
   * @param input - 工具参数。
   * @returns 工具结果(文本 + isError + 原始内容块;端点用 content 回传图片)。
   */
  async dispatchMcpCall(
    name: string,
    input: Record<string, unknown>,
    lateSink?: (toolName: string, text: string) => void,
  ): Promise<DshToolRunResult> {
    if (this.finished || this.disposed) throw new Error('CodeBuddy 回合已结束(模型可能已切换)')
    const callId = `mcp_${randomUUID()}`
    // 与 announceCall 同一发射模式:闭合开放块 → 分配块索引 → 记 calls →
    // 追加 tool-call 块。追加与收尾之间没有 await,不存在"段先收、调用后到"
    // 的窗口;留在这里的任何块都随该段被 loop 消费。
    const segment = this.openSegment()
    this.closeOpenBlock(segment)
    const index = segment.blockIndex++
    segment.calls.push(callId)
    segment.chunks.push({
      type: 'block-end',
      index,
      block: { type: 'tool-call', id: ToolCallId(callId), name, arguments: JSON.stringify(input) },
    })
    for (const open of this.segments) {
      if (!open.closed) this.closeSegment(open, 'tools')
    }
    this.wakeAll()
    // 交互式工具(等用户作答)默认**不设上限**:答案提交时由 tool/result 解析
    // 等待者,直接把答案交回 CLI 的模型继续对话(见 INTERACTIVE_MCP_CALL_TIMEOUT_MS
    // 的说明)。显式配置 >0 时仍按配置计时。
    const configuredTimeout = INTERACTIVE_MCP_TOOLS.has(name)
      ? this.to.interactiveMcpCallTimeoutMs
      : this.to.mcpCallTimeoutMs
    const timeoutMs = configuredTimeout !== undefined && configuredTimeout > 0
      ? configuredTimeout
      : INTERACTIVE_MCP_TOOLS.has(name) ? INTERACTIVE_MCP_CALL_TIMEOUT_MS : MCP_CALL_TIMEOUT_MS
    return await new Promise((resolve, reject) => {
      // 0/负 = 不设上限:等待者只由 dispose/abort 或 tool/result 收尾。
      const timer = timeoutMs > 0
        ? setTimeout(() => {
          this.mcpWaiters.delete(callId)
          // 兜底触发(正常不该发生):注入的段迟迟没被 loop 消费,或 loop 卡死。
          // 此时**无法确定**工具是否已在 loop 侧开始执行——所以端点必须原样回
          // isError、**不得回落重执**(重跑会让同一副作用执行两次)。
          // 记录 callId → 迟到投递口:结果若在超时之后到达,由 onSessionEvent
          // 经投递口补投回会话(CLI 已收到超时错误,补投不是重复上报)。
          this.lateMcpCalls.set(callId, { name, ...lateSink === undefined ? {} : { sink: lateSink } })
          reject(new McpDispatchTimeoutError(
            `MCP 调用 ${name} 注入后 ${Math.round(timeoutMs / 1000)}s 内未被 loop 消费`,
          ))
        }, timeoutMs)
        : undefined
      timer?.unref?.()
      this.mcpWaiters.set(callId, {
        resolve: result => { if (timer !== undefined) clearTimeout(timer); resolve(result) },
        reject: error => { if (timer !== undefined) clearTimeout(timer); reject(error) },
      })
    })
  }

  /**
   * 等一次真工具直发的 delegate 调用结果。
   * 块已发射 → 直接绑 callId;请求先到 → 挂起等块发射认领;
   * 结果先到 → 取缓存。同 toolId 并发调用优先按参数精确配对(乱序不错配),
   * 无精确匹配时退回队首。abort/dispose 统一拒绝。
   */
  private awaitDelegateResult(
    toolId: string,
    input: Record<string, unknown>,
    signal: AbortSignal | undefined,
  ): Promise<{ output: string; isError: boolean }> {
    const args = JSON.stringify(input)
    const queue = this.unclaimedDelegates.get(toolId)
    const entry = queue === undefined ? undefined : takeMatch(queue, args)
    if (queue !== undefined && queue.length === 0) this.unclaimedDelegates.delete(toolId)
    if (entry === undefined) {
      return new Promise((resolve, reject) => {
        // 请求先到但块始终没发射(CLI 的 update 丢失等):限时挂起,超时明确
        // 报错并回收回调,不给回合留永久悬挂的等待者。
        const timer = setTimeout(() => {
          const list = this.pendingDelegateRequests.get(toolId)
          if (list !== undefined) {
            const at = list.findIndex(item => item.claim === request.claim)
            if (at >= 0) list.splice(at, 1)
            if (list.length === 0) this.pendingDelegateRequests.delete(toolId)
          }
          reject(new Error(`delegate call for "${toolId}" 未等到对应的工具调用发射(可能丢失)`))
        }, DELEGATE_PAIR_TIMEOUT_MS)
        timer.unref?.()
        const request: PendingDelegateRequest = {
          args,
          claim: claimedCallId => {
            clearTimeout(timer)
            this.bindDelegateWaiter(claimedCallId, resolve, reject, signal)
          },
        }
        const list = this.pendingDelegateRequests.get(toolId) ?? []
        list.push(request)
        this.pendingDelegateRequests.set(toolId, list)
      })
    }
    const cached = this.delegateResults.get(entry.callId)
    if (cached !== undefined) {
      this.delegateResults.delete(entry.callId)
      return Promise.resolve(cached)
    }
    return new Promise((resolve, reject) => {
      this.bindDelegateWaiter(entry.callId, resolve, reject, signal)
    })
  }

  /** 把等待者绑定到某个 callId(含 abort 清理)。 */
  private bindDelegateWaiter(
    callId: string,
    resolve: (result: { output: string; isError: boolean }) => void,
    reject: (error: Error) => void,
    signal: AbortSignal | undefined,
  ): void {
    const onAbort = (): void => {
      if (this.delegateWaiters.get(callId) === waiter) this.delegateWaiters.delete(callId)
      waiter.reject(new Error('delegate tool call aborted'))
    }
    const waiter = {
      resolve: (result: { output: string; isError: boolean }): void => {
        signal?.removeEventListener('abort', onAbort)
        resolve(result)
      },
      reject: (error: Error): void => {
        signal?.removeEventListener('abort', onAbort)
        reject(error)
      },
    }
    if (signal?.aborted === true) {
      waiter.reject(new Error('delegate tool call aborted'))
      return
    }
    this.delegateWaiters.set(callId, waiter)
    signal?.addEventListener('abort', onAbort, { once: true })
  }

  /**
   * 是否 MCP 桥属调用(其真实卡片由注入 loop 的原生调用呈现,镜像应静默)。
   *
   * mcp 模式下两类:CLI 未禁用延迟加载时的 DeferExecuteTool 执行器调用;以及
   * 工具直接展开后的 mcp__dsh__* 直连调用。delegate 模式不该出现这两类名字,
   * 保持原有镜像行为不变。
   */
  private isSuppressedBridgeCall(rawName: string): boolean {
    if (this.bridgeMode !== 'mcp') return false
    if (rawName === 'defer_execute_tool') return true
    return rawName.startsWith(`mcp__${DSH_MCP_SERVER_NAME}__`)
  }

  /** 参数完整的工具调用:注册回放工具 → 段内发射 tool-call 块。 */
  private announceCall(callId: string, rawName: string, rawInput: Record<string, unknown>): void {
    // MCP 桥属调用(DeferExecuteTool 延迟执行器 / 直连的 mcp__dsh__* 调用)不落
    // 镜像卡片:真实执行经端点注入 loop、由原生工具卡片呈现(见 dispatchMcpCall),
    // 镜像只会产生 "cli_defer_execute_tool 套壳" 噪音。但仍需登记 calls
    // (announced=true)——tool_call_update 的兜底路径依赖这条记录,不然会重入本方法。
    if (this.isSuppressedBridgeCall(rawName)) {
      this.calls.set(callId, {
        id: callId,
        rawName,
        dshName: rawName,
        argsJson: JSON.stringify(rawInput),
        announced: true,
        waiting: [],
      })
      return
    }
    const argsJson = JSON.stringify(rawInput)
    const existing = this.calls.get(callId)
    if (existing?.announced === true) return
    // 空/坏参数的 DelegateTool 调用(模型偶发):CLI 本地会把它改写成合法 JSON
    // 后继续(实测 callModelInputFilter "Rewrote 1 unrepairable JSON
    // function_call(s)"),但**不一定再回 completed 更新**——本侧若一直等它,
    // 回放工具会挂到回合被回收为止(实测 12 分钟,期间 dsh 侧整个 step 不动)。
    // 这类调用 CLI 是本地兜底执行的,直接给回放工具一个终局结果。
    const malformedDelegate = rawName === 'delegate_tool'
      && (typeof rawInput['toolId'] !== 'string' || (rawInput['toolId'] as string).length === 0)
    // delegate 调用(正常目标):**真工具直发**——把 dsh_<工具名> 翻译成真工具名
    // 与参数,作为普通 tool-call 块发射,loop 直接执行 dsh 真工具(审批/沙箱/
    // 事件/原生 UI 卡片全走原生路径),结果由 loop 写 tool/result 事件,泵从
    // 事件取回给 CLI 的 delegateTool 请求。旧路径(cli_delegate_tool 镜像 +
    // handleClientRequest 执行)只剩"未知目标/坏参数"异常调用在用。
    const delegateTarget = !malformedDelegate && rawName === 'delegate_tool'
      ? bridgeTargetTool(String(rawInput['toolId']))
      : undefined
    const delegateInput = ((): Record<string, unknown> => {
      const raw = rawInput['input']
      if (raw !== null && typeof raw === 'object' && !Array.isArray(raw)) return raw as Record<string, unknown>
      // 兼容:参数平铺在顶层的 DelegateTool 调用——实测模型高频把 dsh 工具
      // 参数与 toolId 平铺(`{"pattern":...,"path":...,"toolId":"dsh_grep"}`,
      // 无 input 包装;白名单模式下占比很高)。取除 toolId 外的顶层字段当
      // 参数;真空调用(只有 toolId)仍解析为空对象,行为不变。
      const rest: Record<string, unknown> = {}
      for (const [key, value] of Object.entries(rawInput)) {
        if (key === 'toolId') continue
        rest[key] = value
      }
      return rest
    })()
    const callArgsJson = delegateTarget === undefined ? argsJson : JSON.stringify(delegateInput)
    const callDshName = delegateTarget ?? rawName
    // 诊断:delegate 调用参数缺失(工具报 missing required property)时的现场
    // ——打印 update 侧 rawInput 的完整形态,定位参数在哪一层丢失。
    if (delegateTarget !== undefined && Object.keys(delegateInput).length === 0) {
      console.error(`[codebuddy-bridge] WARN delegate "${delegateTarget}" 参数为空! callId=${callId} rawInput=${JSON.stringify(rawInput).slice(0, 600)}`)
    }
    this.calls.set(callId, {
      id: callId,
      rawName,
      dshName: callDshName,
      argsJson: callArgsJson,
      announced: true,
      waiting: existing?.waiting ?? [],
      ...(existing?.outcome === undefined ? {} : { outcome: existing.outcome }),
      ...(malformedDelegate && existing?.outcome === undefined
        ? {
            outcome: {
              text: 'DelegateTool 调用缺少 toolId(空参数/坏 JSON):CodeBuddy CLI 已把该调用改写成合法 JSON 继续,本侧不执行。'
                + '正确形态:{"toolId":"dsh_<工具名>","input":{…}}。',
              isError: true,
            } satisfies ToolOutcome,
          }
        : {}),
    })
    // 后台任务识别:只认 CLI **自己**的后台调用(原生 Bash/Task 的 background
    // 参数)。delegate 调用(dsh_bash 的 run_in_background 等)是 dsh 侧 job:
    // 立即返回、完成由 dsh 唤醒新回合,与 CLI 本回合的收尾无关——此前一并误判,
    // 回合尾巴被拉到 10 分钟 bg 宽限(实测:任务完成仍显示"进行中"9 分多钟)。
    const isDelegateCall = rawName === 'delegate_tool'
    if (!isDelegateCall && /"run_in_background"\s*:\s*true|"background"\s*:\s*true/.test(argsJson)) this.backgroundLaunched = true
    // 镜像代理一律加保留前缀:同名注册会**遮蔽 dsh 真工具**,桥的
    // `dsh_<name>` 调用就会打到镜像上(实测 dsh_read 全程报"未知的工具调用",
    // 模型据此判定工具坏掉)。`cli_read` 只承接 CLI 原生调用,与桥彻底分名。
    // 曾有的例外(图片别名的裸名 `read_image`)已删除:CLI 内置工具全部禁用后
    // 图片走 dsh 真工具,裸名只会把真工具遮蔽掉(见 acp.ts 的工具策略)。
    // 真工具直发的 delegate 调用**不注册回放工具**(真工具已在 agent plane)。
    const mirrorName = delegateTarget ?? `${CLI_MIRROR_TOOL_PREFIX}${rawName}`
    // MCP 模式下 DeferExecuteTool 的镜像不阻塞(死锁破环,见 ensureReplayTool)。
    const nonBlockingReplay = this.bridgeMode === 'mcp' && rawName === 'defer_execute_tool'
    if (delegateTarget === undefined) this.ensureReplayTool(mirrorName, nonBlockingReplay)
    const segment = this.openSegment()
    this.closeOpenBlock(segment)
    const index = segment.blockIndex++
    segment.calls.push(callId)
    segment.chunks.push({
      type: 'block-end',
      index,
      block: { type: 'tool-call', id: ToolCallId(callId), name: mirrorName, arguments: callArgsJson },
    })
    if (delegateTarget !== undefined) this.claimDelegateRequest(callId, String(rawInput['toolId']), delegateInput)
    this.landTodo(callId, rawName, rawInput)
    this.maybeStartMirror(callId, rawInput)
    this.wakeAll()
  }

  /** 取(或建)当前打开的段。 */
  private openSegment(): Segment {
    const last = this.segments[this.segments.length - 1]
    if (last !== undefined && !last.closed) return last
    const segment: Segment = { chunks: [], cursor: 0, calls: [], closed: false, outcome: 'settle', blockIndex: 0 }
    this.segments.push(segment)
    return segment
  }

  private closeOpenBlock(segment: Segment): void {
    const open = segment.open
    if (open === undefined) return
    segment.open = undefined
    if (open.text.length === 0) return
    if (open.kind === 'text') this.hasText = true
    segment.chunks.push({
      type: 'block-end',
      index: open.index,
      block: open.kind === 'text' ? { type: 'text', text: open.text } : { type: 'reasoning', text: open.text },
    })
  }

  private closeSegment(segment: Segment, outcome: Segment['outcome']): void {
    if (segment.closed) return
    this.closeOpenBlock(segment)
    segment.closed = true
    segment.outcome = outcome
    this.boundarySeenAt = 0
    this.usageGraceUntil = 0
    this.toolExecutingSeen = false
    this.firstResultSeen = false
    this.wakeAll()
  }

  /** 心跳:插话重试 → 看门狗 → 收段判定 → tail 收尾。 */
  private tick(): void {
    if (this.disposed || this.finished) return
    // 插话的**探测**是事件驱动的(queueSteer);这里只负责把**没投出去的再试**,
    // 按 steerPollMs 节流(投递本身有 inFlight 防重,不会叠加请求)。
    const now = Date.now()
    if (now - this.lastSteerPoll >= this.steerPollMs) {
      this.lastSteerPoll = now
      this.flushPendingSteers()
    }
    this.checkStall()
    if (this.disposed || this.finished) return
    this.checkSegmentBoundary()
    this.checkTail()
    this.diagStuck()
  }

  /**
   * 疑似卡住时的现场诊断:真实活动静默 >20s 且回合未收尾时,每 30s 打一行
   * 完整状态到日志——"跑完仍显示进行中"类问题据此一眼定位(卡在哪个条件)。
   */
  private diagStuck(): void {
    const now = Date.now()
    const lastActivityAt = Math.max(this.lastContentAt, this.lastToolExecutingAt)
    if (lastActivityAt === 0 || now - lastActivityAt < 20_000) {
      this.nextDiagAt = 0
      return
    }
    if (now < this.nextDiagAt) return
    this.nextDiagAt = now + 30_000
    const pending = [...this.calls.values()].filter(call => call.announced && call.outcome === undefined).length
    console.error('[codebuddy-bridge] diag'
      + ` session=${this.deps.dshSessionId}`
      + ` silent=${Math.round((now - lastActivityAt) / 1000)}s`
      + ` settled=${this.promptSettled} inflight=${this.inFlight}`
      + ` idlePhase=${this.lastIdlePhaseAt === undefined ? 'never' : `${Math.round((now - this.lastIdlePhaseAt) / 1000)}s ago`}`
      + ` pendingMirrors=${pending} bgLaunched=${this.backgroundLaunched}`
      + ` stop=${this.stopReason ?? '-'} seg=${this.segments.length}`)
  }

  /** 收段判定:工具边界。 */
  private checkSegmentBoundary(): void {
    const segment = this.segments[this.segments.length - 1]
    if (segment === undefined || segment.closed || segment.calls.length === 0) return
    const now = Date.now()
    // 模型调用结束的三种信号:phase=tool_executing / 首个工具结果 / 静默兜底。
    if (this.boundarySeenAt === 0) {
      const boundary = this.toolExecutingSeen
        || this.firstResultSeen
        || now - this.lastProgressAt > this.boundaryQuietMs
      if (!boundary) return
      this.boundarySeenAt = now
      // 用量样本可能晚到 ~100ms;给它一个短宽限期,让本段带上自己的用量。
      this.usageGraceUntil = segment.usage === undefined ? now + this.usageGraceMs : 0
      this.armCheck(this.usageGraceUntil - now + 5)
      return
    }
    if (segment.usage === undefined && this.usageGraceUntil > 0 && now < this.usageGraceUntil) return
    this.closeSegment(segment, 'tools')
  }

  /** tail 窗口:prompt 干净收尾后继续抽流(后台任务会自发续跑)。 */
  private checkTail(): void {
    // 失败分类:prompt 结果里的 refusal/_meta 错误(配额/认证等不重试),
    // 或 JSON-RPC/传输层错误(带 code/data 分类)。两者都翻成一行可读原因。
    if (this.promptFailure !== undefined) {
      this.failRun(
        new Error(`CodeBuddy 中断:${formatFailureLine(this.promptFailure, this.conn?.stderrNote())}`),
        this.promptFailure.retryable,
      )
      return
    }
    if (this.promptError !== undefined) {
      const failure = failureOfError(this.promptError)
      this.failRun(
        new Error(`CodeBuddy ACP 请求失败:${formatFailureLine(failure, this.conn?.stderrNote())}`),
        failure.retryable,
      )
      return
    }
    if (!this.promptSettled || this.inFlight > 0 || this.aborted) {
      // CLI 端回合已实际结束(agentPhase=idle、内容推完)但 session/prompt 的
      // RPC 结果迟迟不回:CLI 的 turn 结束判定偶尔被内部状态挂住(后台任务/
      // 子代理未结算,实测反复出现)。此短路会让下面的尾巴窗口逻辑整体失效,
      // 而看门狗又只咬"在途镜像工具"——纯等待状态下 dsh 永远显示"进行中"。
      // 静默判定与下方尾巴窗口同一套口径:CLI 报过 idle(且在最后一次真实活动
      // 之后) + 真实活动静默超过空闲预算(起过后台任务用长预算)即强制收尾,
      // 放弃 prompt 结果,dispose 杀进程兜底。零产出仍留给静默失败分类。
      // 预算用 idleWrapMs(默认 30s)而不是 tailQuietMs(5s):CLI 回合内部会
      // 静默重试(工具名不存在 → ModelBehaviorError → error-recovery 重新请求
      // 模型,首个内容块 5-8s 才到),5s 会误杀重试并让对话无声中断。
      if (!this.aborted && this.agentPhaseSeen && this.lastIdlePhaseAt !== undefined
        && (this.hasText || this.calls.size > 0)) {
        const quietMs = this.to.idleWrapMs ?? 30_000
        const bgQuietMs = this.to.tailBgQuietMs ?? 600_000
        const lastActivityAt = Math.max(this.lastContentAt, this.lastToolExecutingAt)
        const silentFor = Date.now() - lastActivityAt
        const budget = this.backgroundLaunched ? bgQuietMs : quietMs
        const armed = this.lastIdlePhaseAt >= lastActivityAt
        if (armed && budget > 0 && silentFor >= budget) {
          console.error(`[codebuddy-bridge] session=${this.deps.dshSessionId} prompt 结果挂起但 CLI 已空闲(真实活动静默 ${Math.round(silentFor / 1000)}s)——强制收尾(放弃 RPC 结果,杀进程兜底)`)
          const seg = this.segments[this.segments.length - 1]
          if (seg !== undefined && !seg.closed) this.closeSegment(seg, 'settle')
          this.finishTurn()
          return
        }
        // 静默未满:CLI 心跳停了就没有 update 驱动重入——定时器补刀,到期再判。
        if (armed && budget > 0) {
          this.armCheck(budget - silentFor + 10)
          return
        }
      }
      return
    }
    // 静默失败:end_turn 但零文本零工具(配额/服务端异常)——首段重启,否则报错。
    if (this.progressSamples === 0 || (!this.hasText && this.calls.size === 0)) {
      this.failRun(new Error(`CodeBuddy 静默失败(stopReason: ${this.stopReason ?? 'none'};`
        + `${this.progressSamples} 次进展、0 次文本/工具产出)——可能是配额受限或服务端异常`))
      return
    }
    const segment = this.segments[this.segments.length - 1]
    if (segment === undefined || segment.closed) { this.finishTurn(); return }
    const tailQuietMs = this.to.tailQuietMs ?? 5_000
    const tailBgQuietMs = this.to.tailBgQuietMs ?? 600_000
    const tailCapMs = this.to.tailCapMs ?? 1_800_000
    // 老 CLI 无 agentPhase 心跳:无从判断空闲,立即收尾(与旧行为一致)。
    if (!this.agentPhaseSeen || tailQuietMs <= 0 || tailCapMs <= 0 || this.sessionEnded) {
      this.closeSegment(segment, 'settle')
      this.finishTurn()
      return
    }
    const now = Date.now()
    this.tailStartAt ??= now
    this.tailDeadline ??= this.tailStartAt + tailCapMs
    // 起了后台任务且尚未见续跑内容:放宽到 tailBgQuietMs(任务期间 CLI 可以
    // 长时间零 update);续跑内容一出现即回到短阈值。
    const continuationSeen = this.lastContentAt >= this.tailStartAt + tailQuietMs
    // CLI 已报空闲(agentPhase=idle):不再等后台宽限,用最短预算收尾。
    const cliIdle = this.lastIdlePhaseAt !== undefined && this.lastIdlePhaseAt >= this.tailStartAt
    const budgetMs = cliIdle ? tailQuietMs
      : this.backgroundLaunched && !continuationSeen ? tailBgQuietMs : tailQuietMs
    // 静默判定只看"真实活动"(内容 / 工具执行中相位):session_info 心跳不算
    // 活动,否则空闲的 CLI 靠心跳无限续命,只能等满 tailCapMs(实测:会话跑完
    // 仍显示"进行中"最长 30 分钟)。
    const lastActivityAt = Math.max(this.lastContentAt, this.lastToolExecutingAt)
    if (now - lastActivityAt >= budgetMs || now >= this.tailDeadline) {
      this.closeSegment(segment, 'settle')
      this.finishTurn()
      return
    }
    this.armCheck(Math.min(lastActivityAt + budgetMs, this.tailDeadline) - now + 5)
  }

  /** 看门狗:静默判死已整体移除——只保留"在途工具永不返回"的硬顶兜底。 */
  private checkStall(): void {
    if (this.stallTimedOut || this.disposed) return
    const idleFor = Date.now() - this.lastProgressAt
    const pendingTools = [...this.calls.values()].some(call => call.announced && call.outcome === undefined)
    if (pendingTools) {
      // 在途工具(长工具分钟级无心跳)的硬顶兜底:正常工具靠结果收尾,
      // 只有"工具永不返回 + 消费方被回收"才会走到这里(防进程泄漏/回合悬空)。
      const cap = this.to.guardCapMs ?? 1_800_000
      if (cap > 0 && idleFor > cap) this.stall(cap)
      return
    }
    // 纯等待(等上游响应/长思考)不再判死:CLI 可以长时间零事件,只要进程
    // 还活着就继续等;终止交给用户手动停止或回合取消。tail 窗口内的收尾
    // 由 armCheck 的阈值负责,不在此列。
  }

  private stall(capMs: number = this.lastBudgetMs): void {
    this.stallTimedOut = true
    if (this.acpSessionId !== '') this.conn?.notify('session/cancel', { sessionId: this.acpSessionId })
    if (this.killTimer === undefined) {
      const timer = setTimeout(() => { try { this.conn?.kill() } catch { /* 已退出 */ } }, 5_000)
      timer.unref?.()
      this.killTimer = timer
    }
    this.failRun(new Error('CodeBuddy ACP 调用超时(在途工具超过'
      + ` ${Math.round(capMs / 1000)}s 无响应,本回合历史最大进展间隔 ${Math.round(this.maxGapMs / 1000)}s)`
      + `${this.conn?.stderrNote() ?? ''}`))
  }

  private armProgress(): void {
    const now = Date.now()
    this.maxGapMs = Math.max(this.maxGapMs, now - this.lastProgressAt)
    this.stepState.maxGapMs = this.maxGapMs
    this.lastProgressAt = now
    this.progressSamples += 1
    this.lastBudgetMs = this.progressSamples <= this.to.idleWarmupLines
      ? this.to.idleMaxMs
      : Math.min(Math.max(this.maxGapMs * this.to.idleFactor, this.to.idleMinMs), this.to.idleMaxMs)
  }

  // ── 插话投递(事件驱动探测 + 显式重试) / todo / 镜像 ─────────────────

  /**
   * 入队一条待投递的插话/注入,并立刻尝试投递。
   *
   * 探测来自 `session/event`(见 onSessionEvent):回合中途新注入的一切
   * ——用户插话、子代理结算通知、agent 间消息、插件上下文(UI 上显示为
   * "上下文注入")——模型每步都该看到,而 codebuddy 链路的 prompt 只在回合
   * 开始发一次,中途没有重发通道(实测漏投后果:子代理做完并结算,主代理
   * 同回合内永远收不到通知,一直"等待"到下个回合)。
   * @param id - 消息 id(与 `user/message` 事件同 id,用于去重)。
   * @param text - 文本内容(空白串不入队)。
   */
  private queueSteer(id: string, text: string): void {
    if (id.length === 0 || text.trim().length === 0) return
    if (this.deps.isForwarded?.(id) === true) return
    if (!this.pendingSteers.has(id)) {
      steerDebug(`steer 入队 session=${this.deps.dshSessionId} id=${id}`
        + ` text=${JSON.stringify(text.slice(0, 40))}`)
    }
    this.pendingSteers.set(id, text)
    this.flushPendingSteers()
  }

  /**
   * 重试队列里的每一条待投递。
   *
   * 由 tick 按 `steerPollMs` 节流驱动:投不出去(无连接/在飞)就留在队列里,
   * 下轮再试——**这是"投不出"与"静默消失"的分界**。旧的轮询扫描在守卫挡住时
   * 只是 return,消息再也无人过问。
   */
  private flushPendingSteers(): void {
    if (this.pendingSteers.size === 0) return
    for (const [id, text] of [...this.pendingSteers]) {
      if (this.deps.isForwarded?.(id) === true) {
        this.pendingSteers.delete(id)
        continue
      }
      this.steerMessage(id, text)
    }
  }

  /**
   * 单条消息的 steer 投递。
   *
   * markForwarded 只在**确认发出后**才落(steer 成功,或回退 prompt 实际发车):
   * 早前先标记再投递,回合收尾竞态(conn 已散)下消息会「标了已投却从未发出」,
   * 且 skipIds 永久跳过、下回合也不补——通知永久丢。在飞期间用
   * inFlightForwards 防重复发起。
   */
  private steerMessage(id: string, text: string): void {
    if (this.inFlightForwards.has(id) || this.deps.isForwarded?.(id) === true) {
      return
    }
    const conn = this.conn
    // 连接未就绪(进程未起 / session/new 未回)也留在队列:由 tick 重试。
    // 诊断只在**本轮阻塞的第一次**写一行,否则每 1.2s 刷一条。
    if (conn === undefined || this.acpSessionId === '') {
      if (!this.steerBlockedLogged) {
        this.steerBlockedLogged = true
        steerDebug(`steer 排队等待连接 session=${this.deps.dshSessionId}`
          + ` 原因=${conn === undefined ? 'no-conn' : 'no-acp-session'} 队首=${id}`)
      }
      return
    }
    this.steerBlockedLogged = false
    this.inFlightForwards.add(id)
    const fallback = (): void => {
      this.inFlightForwards.delete(id)
      const current = this.conn
      // 连接已散:不标记、**留在队列里**由 tick 重试(投不出 ≠ 静默消失)。
      if (current === undefined) {
        steerDebug(`steer 回退失败(连接已散,留在队列重试)id=${id}`)
        return
      }
      steerDebug(`steer 回退为独立 prompt id=${id}`)
      this.markDelivered(id)
      // sendPrompt 请求层失败(连接抖动)时回滚标记:重试/下回合补发仍会带上。
      void this.sendPrompt(text, []).then(ok => {
        if (!ok) {
          this.deps.unmarkForwarded?.(id)
          this.pendingSteers.set(id, text)
        }
      })
    }
    void conn.request<{ steered?: boolean }>(
      'session/steer',
      { sessionId: this.acpSessionId, contentBlocks: [{ type: 'text', text }] },
      20_000,
    ).then(
      result => {
        if (result?.steered === true) {
          this.inFlightForwards.delete(id)
          this.markDelivered(id)
          steerDebug(`steer 成功(ACP session/steer)id=${id}`)
          return
        }
        steerDebug(`steer 被拒(steered=${String(result?.steered)})id=${id}`)
        fallback()
      },
      (error: unknown) => {
        steerDebug(`steer 请求失败 id=${id} err=${String(error).slice(0, 120)}`)
        fallback()
      },
    )
  }

  /** 投递成功:落去重标记并从重试队列摘除。 */
  private markDelivered(id: string): void {
    this.deps.markForwarded(id)
    this.pendingSteers.delete(id)
  }

  private replayTodos(): void {
    try {
      const state = this.deps.todoStateOf()
      if (state !== undefined && state.snapshot().length > 0) this.emitTodo(state)
    } catch { /* 展示性桥接不阻断对话 */ }
  }

  private emitTodo(state: TodoListState): void {
    try {
      this.deps.session?.append?.('todo/write', { todos: state.snapshot() })
    } catch { /* 展示性桥接不阻断对话 */ }
  }

  private landTodo(callId: string, name: string, rawInput: Record<string, unknown>): void {
    const state = this.deps.todoStateOf()
    if (state === undefined) return
    const kind = todoToolKind(name)
    if (kind === undefined) return
    try {
      if (kind === 'taskupdate') { state.deferTaskUpdate(callId, rawInput); return }
      if (state.applyToolCall(name, rawInput)) this.emitTodo(state)
    } catch { /* 展示性桥接不阻断对话 */ }
  }

  private confirmTodo(callId: string, name: string, text: string): void {
    const state = this.deps.todoStateOf()
    if (state === undefined || todoToolKind(name) === undefined) return
    try {
      state.applyToolResult(name, text)
      if (state.resolveTaskUpdate(callId, text)) this.emitTodo(state)
    } catch { /* 展示性桥接不阻断对话 */ }
  }

  private maybeStartMirror(callId: string, rawInput: Record<string, unknown>): void {
    if (!this.subagentCallIds.has(callId) || this.mirrors.has(callId)) return
    if (this.stepState.mirroredCalls.has(callId)) return
    if (this.acpSessionId === '') return
    const sessions = (this.deps.ctx as unknown as { get?: (key: string) => unknown }).get?.('sessions') as
      | { create?: (id?: unknown, options?: { meta?: Record<string, unknown> }) => { readonly id: string; append: (type: string, data: unknown, opts?: unknown) => { readonly seq: number } | undefined } }
      | undefined
    if (sessions?.create === undefined) return
    const description = rawInput['description']
    const prompt = rawInput['prompt']
    const attachments = this.deps.attachmentsOf()
    const mirror = new SubagentMirror({
      sessions: sessions as never,
      parentSessionId: this.deps.dshSessionId,
      cwd: this.deps.cwd,
      acpSessionId: this.acpSessionId,
      ...(this.deps.nativeBaseDir !== undefined ? { projectsRoot: this.deps.nativeBaseDir } : {}),
      ...(this.deps.childSession?.header?.agentPreset === undefined
        ? {}
        : { agentPreset: this.deps.childSession.header.agentPreset }),
      ...(attachments === undefined
        ? {}
        : { attachments: { saveImage: (data, mediaType) => attachments.saveImage({ data, mediaType }) } }),
    })
    mirror.start({
      label: typeof description === 'string' && description.length > 0 ? description : 'CodeBuddy 子代理',
      prompt: typeof prompt === 'string' ? prompt : '',
      delegationDepth: (this.deps.childSession?.header?.delegationDepth ?? 0) + 1,
    })
    this.mirrors.set(callId, mirror)
    this.stepState.mirroredCalls.add(callId)
  }

  private finishMirror(callId: string, outputText: string): void {
    const mirror = this.mirrors.get(callId)
    if (mirror === undefined) return
    void mirror.finish(agentIdFromOutput(outputText))
    this.mirrors.delete(callId)
  }

  // ── 唤醒机制 ───────────────────────────────────────────────────────────

  private waitEvent(): Promise<void> {
    return new Promise<void>(resolve => { this.wake = resolve })
  }

  private wakeAll(): void {
    const wake = this.wake
    this.wake = undefined
    wake?.()
  }
}
