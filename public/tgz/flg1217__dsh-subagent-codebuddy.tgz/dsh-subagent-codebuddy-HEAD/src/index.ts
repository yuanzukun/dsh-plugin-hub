/**
 * CodeBuddy CLI(Tencent)作为 dsh 的 LLM 提供方(模型供应商模式)。
 *
 * 结构对齐 dsh-llm-agy:
 *  1. 注册 `codebuddy` LLM provider 路由(CodebuddyLlmAdapter,ACP 协议)——
 *     主代理可直接在模型选择器里选用 CodeBuddy 模型(该轮由 CodeBuddy
 *     CLI 全权驱动,用它自己的工具链;dsh 的沙箱/审批不参与);同时
 *     通用 `subagent` 工具可通过 subagent-model-selection 委派
 *     `{provider: codebuddy, model: <id>}` 的进程内子代理。
 *  2. 可选注册自定义委派工具 `subagent_codebuddy` 与 `list_codebuddy_models`
 *     ——工具描述里内置"完整上下文"指引,作为通用工具之外的 opt-in 路径。
 *     开关在**设置面板**(设置 → 插件 → CodeBuddy,`registerSubagentTools`,
 *     默认关闭)实时生效,也可用插件行配置兜底。
 *
 * 模型目录:adapter `listModels()` 解析 `codebuddy --help` 的支持列表,
 * 供主模型选择器与 list_subagent_models 使用(带缓存,永不抛错)。
 * @module subagent-codebuddy
 */

import type { Context, Volatile } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { CodebuddyLlmAdapter } from './adapter.js'
import { ConversationStore } from './conversations.js'
import { mountCompactCommand, registerCompactDelegation } from './compact-command.js'
import { registerCompactMirror } from './compact-mirror.js'
import { syncCliIntegrations } from './cli-integrations.js'
import { registerSubagentTool } from './subagent-tool.js'
import { registerCodebuddyModelsTool } from './models.js'
import { registerCodebuddySettings, resolveSpawnableCommand } from './settings.js'
import type { EffectiveCodebuddySettings } from './settings.js'
import { registerCodebuddyModelsRoute } from './models-route.js'
import { createModelCapabilityIndex } from './model-capabilities.js'
import { registerDshMcpServer } from '@flg1217/dsh-mcp'
import { sweepStaleMcpConfigs } from './mcp-config.js'
import { installModelSwitchToolGuide } from './tool-guide.js'
import type {} from '@deepseek-ai/dsh-settings'

export const name = 'subagent-codebuddy'
// provider 是核心面:仅 `tools`/`subagents`/`systemPrompt` 是 opt-in 工具所需,
// 经 ctx.inject 惰性获取,LLM-only 组合下插件照常加载。
export const inject = ['llm']

/** 设置输入面(profile patch 条目 config / 表单写入的原始值;缺省走 schema 默认)。 */
export interface CodebuddyConfigInput {
  command?: string
  model?: string
  permissionMode?: string
  registerSubagentTools?: boolean
  bridgeMode?: 'mcp' | 'delegate'
  extraArgs?: string[]
  providerName?: string
  toolName?: string
  longToolCapMinutes?: number
  tailQuietSeconds?: number
  tailBgQuietMinutes?: number
  tailCapMinutes?: number
  idleWrapSeconds?: number
}

/**
 * 本插件配置面(profile 条目 id = `subagent-codebuddy`;即设置表单)。
 * 前 5 个字段 volatile = 设置面板可编辑、读取即活引用;其余仅 profile
 * patch 可编辑(不进表单,普通配置)。
 */
export interface Config {
  /** 可执行文件,默认 `codebuddy`。 */
  command: Volatile<string>
  /** 默认 CodeBuddy 模型 ID,默认 `deepseek-v4.1-flash`。 */
  model: Volatile<string>
  /** 传给 `--permission-mode` 的权限模式,默认 `bypassPermissions`(自动放行)。 */
  permissionMode: Volatile<string>
  /** 是否注册 opt-in 委派工具(默认关闭)。 */
  registerSubagentTools: Volatile<boolean>
  /** 工具桥接模式(默认 `mcp`)。 */
  bridgeMode: Volatile<'mcp' | 'delegate'>
  /** 追加的额外 CodeBuddy 参数。 */
  extraArgs: string[]
  /** LLM provider 路由名,默认 `codebuddy`。 */
  providerName: string
  /** opt-in 工具名,默认 `subagent_codebuddy`。 */
  toolName: string
  /**
   * 静默长工具硬顶(分钟,默认 30;0 = 关闭硬顶)。
   * 只影响「发起后零事件」的工具段——任何中间进展(文本/思考/工具 update)
   * 都会重置计时,会冒泡的长工具不受影响。超顶时中止本次 CodeBuddy 调用
   * 并**自动续跑**(stall 重试);被误杀的工具通常工作已落盘,重跑代价可控。
   * 设为 0 则永不因静默中止(接受 CLI 卡死时进程泄漏、子会话回合悬空的风险)。
   */
  longToolCapMinutes: number
  /**
   * 尾巴窗口静默阈值(秒,默认 5;0 = 关闭)。
   *
   * CodeBuddy 的 `end_turn` 不等于空闲:后台任务(后台 bash / agent 任务)完成时
   * CLI 会**自发续跑**,续跑内容以普通流式事件推过来。若回合在 `end_turn` 处
   * 直接收尾,插件就不再抽流,这些内容全丢——用户永远等不到模型承诺的
   * "跑完我继续/给你最终结果"。尾巴窗口:干净收尾后继续抽流,直到 CLI 报
   * `idle` 且静默达到本阈值(普通回合的额外延迟就是这个值)、或 CLI 广播
   * `session_end`(真正空闲,立即收尾)、或撞上 {@link tailCapMinutes}。
   */
  tailQuietSeconds: number
  /**
   * 起了后台任务的回合的静默阈值(分钟,默认 10)。
   *
   * 后台任务在跑时 CLI 可以长时间零事件;识别到本轮起过后台任务
   * (工具参数 `run_in_background`/`background`)后,尾巴窗口放宽到本阈值,
   * 等它跑完的自发续跑;续跑内容一出现即回到 tailQuietSeconds。
   */
  tailBgQuietMinutes: number
  /** 尾巴窗口硬顶(分钟,默认 30):后台任务最长可拖着回合不闭合的时长。 */
  tailCapMinutes: number
  /**
   * 「prompt 结果挂起但 CLI 已空闲」的强制收尾预算(秒,默认 30;0 = 关闭)。
   *
   * 这条兜底在 prompt **未 settled** 时也会走,而 CLI 回合内部会静默重试
   * (工具名不存在 → ModelBehaviorError → error-recovery 重新请求模型,首个
   * 内容块 5-8s 才到)。预算太小会把重试连同进程一起杀掉,对话无声中断。
   */
  idleWrapSeconds: number
}

export const Config: z<CodebuddyConfigInput, Config> = z.object({
  command: z.string().default('codebuddy')
    .description('codebuddy 可执行文件命令(默认 codebuddy)').volatile(),
  model: z.string().default('deepseek-v4.1-flash')
    .description('子代理使用的默认模型(委派时可传 model 参数覆盖)').volatile(),
  permissionMode: z.string().default('bypassPermissions')
    .description('--permission-mode:子代理工具调用自动放行').volatile(),
  registerSubagentTools: z.boolean().default(false)
    .description('提供旧版自定义委派工具(subagent_codebuddy / list_codebuddy_models);默认关闭,推荐用通用 subagent 工具 + 模型选择').volatile(),
  bridgeMode: z.union([z.const('mcp'), z.const('delegate')]).default('mcp')
    .description('工具桥接模式:mcp=dsh 提供 HTTP MCP server(完整 schema,推荐);delegate=旧 DelegateTool 通道(回退用)').volatile(),
  extraArgs: z.array(z.string()).default([]),
  providerName: z.string().default('codebuddy'),
  toolName: z.string().default('subagent_codebuddy'),
  longToolCapMinutes: z.number().default(30),
  tailQuietSeconds: z.number().default(5),
  tailBgQuietMinutes: z.number().default(10),
  tailCapMinutes: z.number().default(30),
  idleWrapSeconds: z.number().default(30),
})

export function apply(ctx: Context, config: Config): void {
  const providerName = config.providerName
  const toolName = config.toolName

  // 设置面板:本插件自带页面(客户端 plugins.item,「插件列表」条目详情),关掉按 schema
  // 自动生成表单的策略(0.2.1 起替代旧 installSection;策略不移除配置读写)。
  ctx.inject(['settings'], (child) => {
    child.effect(() => child.settings.configure({ auto: false }, ctx.fiber))
  })

  // 装载时先同步一次 dsh→CodeBuddy 的原生接入(MCP 配置 / skills 目录);
  // 每个 CodeBuddy 进程启动前(pump/adapter)还会再同步,保证读到最新。
  syncCliIntegrations()

  // dsh MCP server(共享包 @flg1217/dsh-mcp):把会话可见的 dsh 工具以 MCP
  // 暴露给 CLI(bridgeMode=mcp 时 spawn 以 --mcp-config 连接)。注册幂等:
  // 共享包 / llm-agy / 本插件同时调用时只有第一个生效,key 不会被覆盖。
  // 用 ctx.effect 接管释放函数:插件卸载/热重载时摘掉路由并作废端点 key。
  ctx.effect(() => registerDshMcpServer(ctx))
  // 清扫陈旧的 --mcp-config 文件(本插件方言:文件名含会话+内容摘要、只增不删)。
  sweepStaleMcpConfigs()
  // 路由在 CodeBuddy 与 dsh 原生之间切换时,注入工具面说明(核心只注入
  // "模型变了";工具面差异不注入,切后的第一步就会按旧习惯选错工具)。
  installModelSwitchToolGuide(ctx)

  // opt-in 工具的注册状态:设置面板开关实时同步(开 → 注册,关 → 注销)。
  let toolCtx: Context | undefined
  let disposers: Array<() => void> = []

  // 设置通道:模型探测注册走 registerCodebuddySettings;生效配置从 volatile
  // 活引用实时读取(空串视为未配置,回退内建默认;面板清空字段时不能因
  // '' 覆盖兜底值导致 spawn ENOENT)。返回的 thunk 供 adapter / 路由实时读。
  const filled = (value: string): string | undefined => value.trim().length > 0 ? value : undefined
  const settingsOf = (): EffectiveCodebuddySettings => ({
    command: filled(config.command.get()) ?? 'codebuddy',
    model: filled(config.model.get()) ?? 'deepseek-v4.1-flash',
    permissionMode: filled(config.permissionMode.get()) ?? 'bypassPermissions',
    registerSubagentTools: config.registerSubagentTools.get(),
    bridgeMode: config.bridgeMode.get(),
  })
  registerCodebuddySettings(ctx, settingsOf)
  const eff = settingsOf()
  const resolved = resolveSpawnableCommand(eff.command)

  // 模型图片能力索引(读 CLI 的 models.json):适配器声明 inputModalities、
  // 目录条目文案、设置卡模型列表共用同一份,避免多处各读一次。
  const capabilities = createModelCapabilityIndex()

  // 设置面板的模型列表路由:插件卡槽位拿不到会话级 remote,发现只能自建
  // (围栏与 /api 网关行为一致,见 models-route.ts 模块头)。
  ctx.effect(() => registerCodebuddyModelsRoute(ctx, () => settingsOf().command, capabilities))

  // LLM provider 路由:主代理选择与子代理委派的推理都走 CodeBuddy。
  // /compact 转发与 adapter 共用同一会话映射(acpId → dsh 会话)。
  const conversations = new ConversationStore()
  ctx.llm.registerAdapter([providerName], new CodebuddyLlmAdapter(ctx, {
    command: resolved.command,
    prefixArgs: resolved.args,
    modelOf: () => settingsOf().model,
    permissionMode: eff.permissionMode,
    extraArgs: config.extraArgs,
    bridgeMode: eff.bridgeMode,
    store: conversations,
    capabilities,
    // 静默长工具硬顶(分钟 → 毫秒;0 = 关闭)。看门狗超顶时 cancel+强杀,走
    // stall 重试自动续跑——防止 CLI 卡死时进程泄漏、子会话回合悬空。
    // 尾巴窗口(秒/分钟 → 毫秒;0 = 关闭)见 Config.tailQuietSeconds。
    timeouts: {
      guardCapMs: config.longToolCapMinutes * 60_000,
      tailQuietMs: config.tailQuietSeconds * 1_000,
      tailBgQuietMs: config.tailBgQuietMinutes * 60_000,
      tailCapMs: config.tailCapMinutes * 60_000,
      idleWrapMs: config.idleWrapSeconds * 1_000,
    },
  }))

  // codebuddy 会话的 /compact 转发给 CLI(per-agent 命令覆盖;其它会话回落 dsh);
  // 转发跑在 agent 的 maintenance 相位里,压缩期间消息按原生行为排队。
  mountCompactCommand({
    ctx,
    command: resolved.command,
    prefixArgs: resolved.args,
    extraArgs: config.extraArgs,
    modelOf: () => settingsOf().model,
    conversations,
    providerName,
  })

  // 自动压缩(阈值触发)也交给 CLI:插件接管 compaction 服务的自动压缩入口。
  registerCompactDelegation({
    ctx,
    command: resolved.command,
    prefixArgs: resolved.args,
    extraArgs: config.extraArgs,
    modelOf: () => settingsOf().model,
    conversations,
    providerName,
  })

  // CLI 自己压完之后,dsh 界面得有压缩卡(纯逻辑同步:照抄 CLI 的摘要原文,
  // 不调模型、不消耗 token)。
  registerCompactMirror({ ctx, conversations, providerName })

  /**
   * opt-in 委派工具:spawn 子代理(进程内、continuable 可续聊),模型路由指
   * 向 codebuddy provider。自定义注册以在工具描述里内置"完整上下文"指引
   * (子代理看不到当前会话、无法追问,委派必须自带全部上下文)。
   */
  function subagentToolOptions(): Parameters<typeof registerSubagentTool>[1] {
    return {
      provider: 'spawn',
      toolName,
      agentOptions: () => ({ provider: providerName, model: settingsOf().model }),
      description:
        'Delegate a self-contained task to a CodeBuddy subagent (a separate process running Tencent CodeBuddy with its own tools) '
        + 'to offload focused, independent work — research, a scoped implementation, an analysis — so it does not consume '
        + 'this conversation\'s context. The subagent returns its result, not its intermediate steps.\n\n'
        + 'Provide COMPLETE context for every delegation — the subagent does not see this conversation and cannot ask '
        + 'follow-up questions: (1) the goal and acceptance criteria; (2) exact file/directory paths to touch or inspect; '
        + '(3) constraints and boundaries (what NOT to do, what to preserve); (4) the expected output format. Split complex '
        + 'tasks into independent subagents and run them in parallel. '
        + 'Optionally pass a `model` argument with an exact model id (query `list_codebuddy_models` or the main model '
        + `selector for the currently supported ids); omit it to use the plugin-configured default model (\`${settingsOf().model}\`). `
        + 'This tool runs in the background by default: it immediately returns a durable subagent id and keeps the child '
        + 'conversation available for later turns; when the run settles, the runtime sends you a notice containing its '
        + 'outcome and any final assistant message. Set `run_in_background: false` only when your next action depends on '
        + 'receiving the result; `send_message` starts a later turn in the same child conversation.',
      promptDescription:
        'The complete, self-contained task for the subagent. It does not share this conversation\'s context, so include '
        + 'everything it needs: the goal, acceptance criteria, exact file paths, constraints, and the expected output format. '
        + 'Always instruct the subagent to keep working until the task is FULLY complete — no interim stop-and-report rounds; '
        + 'it should only stop on a blocking decision that only the user can make. '
        + 'If the task involves starting a dev server or any long-running process, instruct the subagent to run it via '
        + 'Bash with run_in_background: true (never in the foreground — a foreground server never returns and stalls the run).',
    }
  }

  /** 按当前生效设置同步 opt-in 工具注册;服务未就绪时先跳过,注入回调会再同步。 */
  function syncTools(): void {
    if (toolCtx === undefined) return
    // 按最新设置重建:工具描述里带"当前默认模型",设置改动要随之更新。
    for (const dispose of disposers) dispose()
    disposers = []
    if (!settingsOf().registerSubagentTools) return
    disposers = [
      registerSubagentTool(toolCtx, subagentToolOptions()),
      registerCodebuddyModelsTool(toolCtx, {
        command: resolved.command,
        prefixArgs: resolved.args,
        toolName: 'list_codebuddy_models',
      }),
    ]
  }

  ctx.inject(['tools', 'subagents', 'systemPrompt'], (injected) => {
    toolCtx = injected
    syncTools()
    return () => {
      for (const dispose of disposers) dispose()
      disposers = []
      toolCtx = undefined
    }
  })

  // 设置保存后实时同步 opt-in 工具注册(旧 installSection onChange 的替代;
  // 0.2.1 起设置事件名为 settings/document-updated,ns = profile 条目 id)。
  ctx.on('settings/document-updated', (ns: string) => {
    if (ns === 'subagent-codebuddy') syncTools()
  })
}
