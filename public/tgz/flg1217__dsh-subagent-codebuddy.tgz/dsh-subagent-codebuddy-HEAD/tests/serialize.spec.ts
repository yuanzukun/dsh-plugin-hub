/**
 * serialize(CodeBuddy prompt 序列化)单元测试:
 * - 系统提示 + 消息按顺序拼接;
 * - 图片块以 ACP 原生 image 内容块(base64)返回,不落盘、不走路径提示;
 * - 超长 prompt 内联返回(经 ACP stdin 发送,无命令行长度限制)。
 */
import { describe, expect, it, vi } from 'vitest'
import { buildPrompt, lastUserPrompt, resumeReplayPrompt } from '../src/serialize.ts'
import type { Message } from '@deepseek-ai/dsh-llm'

/** 伪附件服务:readImage 返回图片字节与媒体类型。 */
function makeCtx() {
  const readImage = vi.fn(async () => ({
    data: new Uint8Array([1, 2, 3, 4]),
    ref: { mediaType: 'image/png' },
  }))
  const ctx = { get: (key: string) => (key === 'attachments' ? { readImage } : undefined) }
  return { ctx, readImage }
}

function textMessage(role: Message['role'], text: string): Message {
  return { role, content: [{ type: 'text', text }] }
}

describe('buildPrompt:文本序列化', () => {
  it('系统提示与消息按顺序拼接', async () => {
    const { ctx } = makeCtx()
    const { prompt, images } = await buildPrompt(ctx as never, {
      system: '你是子代理。',
      messages: [
        textMessage('user', '你好'),
        textMessage('assistant', '你好,有什么可以帮你?'),
        textMessage('user', '分析这段代码'),
      ],
    })
    expect(prompt).toBe([
      'System instructions:\n你是子代理。',
      'User: 你好',
      'Assistant: 你好,有什么可以帮你?',
      'User: 分析这段代码',
    ].join('\n\n'))
    expect(images).toEqual([])
  })

  it('无系统提示时只拼接消息', async () => {
    const { ctx } = makeCtx()
    const { prompt } = await buildPrompt(ctx as never, {
      messages: [textMessage('user', 'hello')],
    })
    expect(prompt).toBe('User: hello')
  })

  it('同一消息多个文本块拼接在一起', async () => {
    const { ctx } = makeCtx()
    const { prompt } = await buildPrompt(ctx as never, {
      messages: [{ role: 'user', content: [{ type: 'text', text: 'a' }, { type: 'text', text: 'b' }] }],
    })
    expect(prompt).toBe('User: ab')
  })
})

describe('buildPrompt:图片处理(ACP 原生内容块 + 落盘 Read 通道)', () => {
  it('图片块转为 base64 内容块,并落盘路径提示(Read 通道)', async () => {
    const { ctx, readImage } = makeCtx()
    const { prompt, images } = await buildPrompt(ctx as never, {
      messages: [{
        role: 'user',
        content: [
          { type: 'text', text: '看图' },
          { type: 'image', attachment: { attachmentId: 'img-1' } },
        ],
      }],
    })
    expect(readImage).toHaveBeenCalledTimes(1)
    expect(prompt).toContain('User: 看图')
    // 落盘路径提示:CLI 对不支持图片的模型会过滤 ACP/工具结果图片,
    // 模型按此路径用 Read 读图(CLI 原生 Read 不过滤)。
    expect(prompt).toContain('[图片已保存到本地文件:')
    expect(prompt).toContain('(用 Read 工具读取查看)]')
    expect(prompt).not.toContain('附带图片')
    expect(images).toEqual([{ data: Buffer.from([1, 2, 3, 4]).toString('base64'), mimeType: 'image/png' }])
  })

  it('图片读取失败时静默跳过,不影响文本', async () => {
    const ctx = { get: () => ({ readImage: vi.fn(async () => { throw new Error('boom') }) }) }
    const { prompt, images } = await buildPrompt(ctx as never, {
      messages: [{
        role: 'user',
        content: [
          { type: 'text', text: '正文' },
          { type: 'image', attachment: { attachmentId: 'img-broken' } },
        ],
      }],
    })
    expect(prompt).toBe('User: 正文')
    expect(images).toEqual([])
  })

  it('lastUserPrompt:只取最后一条用户消息(含其图片内容块)', async () => {
    const { ctx } = makeCtx()
    const { prompt, images } = await lastUserPrompt(ctx as never, [
      textMessage('user', '旧问题'),
      textMessage('assistant', '旧回答'),
      {
        role: 'user',
        content: [
          { type: 'text', text: '新问题带图' },
          { type: 'image', attachment: { attachmentId: 'img-2' } },
        ],
        source: { kind: 'user' },
      } as unknown as Message,
    ])
    expect(prompt).toContain('新问题带图')
    expect(prompt).toContain('[图片已保存到本地文件:')
    expect(images.length).toBe(1)
  })

  it('tool 结果消息里的图片(read_image 结果)被收集为内容块', async () => {
    const { ctx, readImage } = makeCtx()
    const { prompt, images } = await buildPrompt(ctx as never, {
      messages: [
        textMessage('user', '看这张图'),
        {
          role: 'assistant',
          content: [{ type: 'tool-call', id: 'c1', name: 'read_image', arguments: '{}' }],
        },
        {
          role: 'tool',
          toolCallId: 'c1',
          content: [
            { type: 'text', text: '[图片: 1272x2800]' },
            { type: 'image', attachment: { attachmentId: 'img-tool-1' } },
          ],
          source: { kind: 'tool', callId: 'c1' },
        } as unknown as Message,
      ],
    })
    expect(readImage).toHaveBeenCalledTimes(1)
    expect(prompt).toContain('[图片: 1272x2800]')
    expect(images).toEqual([{ data: Buffer.from([1, 2, 3, 4]).toString('base64'), mimeType: 'image/png' }])
  })
})

describe('buildPrompt:超长 prompt 内联直发', () => {
  it('无论多长都内联返回原文,不再生成任务文件引用', async () => {
    const { ctx } = makeCtx()
    const long = '长'.repeat(30_000)
    const { prompt } = await buildPrompt(ctx as never, {
      messages: [textMessage('user', long)],
    })
    expect(prompt).toContain(long)
    expect(prompt).not.toContain('请先读取任务描述文件')
  })
})

describe('resumeReplayPrompt:已转发插入的去重', () => {
  it('skipIds 里的插入消息被跳过,不重复补发', async () => {
    const { ctx } = makeCtx()
    const messages = [
      { id: 'u1', role: 'user', content: [{ type: 'text', text: '第一问' }], source: { kind: 'user' } },
      { id: 'a1', role: 'assistant', content: [{ type: 'text', text: '第一答' }], source: { kind: 'model', provider: 'codebuddy', model: 'x' } },
      { id: 'ins-1', role: 'user', content: [{ type: 'text', text: '插话:先别做别的' }], source: { kind: 'user' } },
      { id: 'a2', role: 'assistant', content: [{ type: 'text', text: '插话的回复' }], source: { kind: 'model', provider: 'codebuddy', model: 'x' } },
      { id: 'u2', role: 'user', content: [{ type: 'text', text: '新问题' }], source: { kind: 'user' } },
    ] as unknown as Message[]
    const { resumeReplayPrompt } = await import('../src/serialize.ts')
    const { prompt } = await resumeReplayPrompt(ctx as never, messages, 2, new Set(['ins-1']))
    expect(prompt).toContain('新问题')
    expect(prompt).not.toContain('插话')
  })
})

describe('lastUserPrompt:插件注入上下文不顶掉用户输入', () => {
  it('系统提醒(plugin)排在用户消息之后时,仍取用户消息(压缩后排队消息丢失回归)', async () => {
    const { ctx } = makeCtx()
    const messages = [
      { role: 'user', content: [{ type: 'text', text: '账本设计还是过度设计' }], source: { kind: 'user' } },
      {
        role: 'user',
        content: [{ type: 'text', text: '<system-reminder>技能目录已更新</system-reminder>' }],
        source: { kind: 'plugin', plugin: '@deepseek-ai/dsh-skill' },
      },
      {
        role: 'user',
        content: [{ type: 'text', text: 'Current runtime context…' }],
        source: { kind: 'plugin', plugin: '@deepseek-ai/dsh-system-prompt' },
      },
    ] as unknown as Message[]
    const { prompt } = await lastUserPrompt(ctx as never, messages)
    expect(prompt).toBe('账本设计还是过度设计')
  })

  it('只有插件上下文时退回 CONTINUE_PROMPT(不把提醒当用户输入)', async () => {
    const { ctx } = makeCtx()
    const messages = [
      {
        role: 'user',
        content: [{ type: 'text', text: '<system-reminder>技能目录</system-reminder>' }],
        source: { kind: 'plugin', plugin: '@deepseek-ai/dsh-skill' },
      },
    ] as unknown as Message[]
    const { prompt } = await lastUserPrompt(ctx as never, messages)
    expect(prompt).toContain('继续完成之前未完成的任务')
  })
})

describe('resumeReplayPrompt:只有已插话投递的消息可跳过', () => {
  /** 用户消息(带 id,便于 skipIds 命中)。 */
  function userMessage(id: string, text: string): Message {
    return { id, role: 'user', content: [{ type: 'text', text }], source: { kind: 'user' } } as unknown as Message
  }

  it('锚点之后全是"已插话投递"的消息 → skippedForwarded=true(调用方空跑,不发 CONTINUE_PROMPT)', async () => {
    const { ctx } = makeCtx()
    const messages = [
      userMessage('m-old', '旧输入'),
      userMessage('m-steer', '插句话:先别做别的'),
    ]
    const replay = await resumeReplayPrompt(ctx as never, messages, 1, new Set(['m-steer']))
    expect(replay.skippedForwarded).toBe(true)
    expect(replay.prompt).toContain('继续完成之前未完成的任务')   // 兜底文本仍在,由调用方决定不用
  })

  it('跳过的是 CodeBuddy 自己的消息 → skippedForwarded 不置位(仍走续跑)', async () => {
    const { ctx } = makeCtx()
    const messages = [
      userMessage('m-old', '旧输入'),
      {
        id: 'm-own',
        role: 'assistant',
        content: [{ type: 'text', text: '我自己产出的' }],
        source: { kind: 'model', provider: 'codebuddy', model: 'glm-5.3' },
      } as unknown as Message,
    ]
    const replay = await resumeReplayPrompt(ctx as never, messages, 1, new Set())
    expect(replay.skippedForwarded).toBe(false)
  })

  it('切换其他模型再切回:期间其他模型的回答被补发(只跳过 CodeBuddy 自己的)', async () => {
    const { ctx } = makeCtx()
    const messages = [
      userMessage('m-old', '旧输入'),
      {
        id: 'm-own',
        role: 'assistant',
        content: [{ type: 'text', text: '我自己的回答' }],
        source: { kind: 'model', provider: 'codebuddy', model: 'glm-5.3' },
      } as unknown as Message,
      {
        id: 'm-other',
        role: 'assistant',
        content: [{ type: 'text', text: '别的模型的回答' }],
        source: { kind: 'model', provider: 'sensenova', model: 'kimi-k3' },
      } as unknown as Message,
      userMessage('m-new', '切回后的新输入'),
    ]
    const replay = await resumeReplayPrompt(ctx as never, messages, 1, new Set())
    expect(replay.prompt).toContain('别的模型的回答')
    expect(replay.prompt).toContain('切回后的新输入')
    expect(replay.prompt).not.toContain('我自己的回答')
  })

  it('锚点之后还有新输入 → 正常序列化新输入(S 不置位)', async () => {
    const { ctx } = makeCtx()
    const messages = [
      userMessage('m-old', '旧输入'),
      userMessage('m-steer', '插句话'),
      userMessage('m-new', '新的输入'),
    ]
    const replay = await resumeReplayPrompt(ctx as never, messages, 1, new Set(['m-steer']))
    expect(replay.skippedForwarded).toBeUndefined()
    expect(replay.prompt).toContain('新的输入')
    expect(replay.prompt).not.toContain('插句话')
  })
})

describe('resumeReplayPrompt:补发完整性(tool-call / 压缩 / own 过滤)', () => {
  /** 消息构造(带 id 与来源,便于 own/forwarded/checkpoint 判定)。 */
  function userMessage(id: string, text: string): Message {
    return { id, role: 'user', content: [{ type: 'text', text }], source: { kind: 'user' } } as unknown as Message
  }

  function ownAssistant(id: string, text: string): Message {
    return {
      id,
      role: 'assistant',
      content: [{ type: 'text', text }],
      source: { kind: 'model', provider: 'codebuddy', model: 'glm-5.3' },
    } as unknown as Message
  }

  function otherAssistant(id: string, text: string): Message {
    return {
      id,
      role: 'assistant',
      content: [{ type: 'text', text }],
      source: { kind: 'model', provider: 'sensenova', model: 'kimi-k3' },
    } as unknown as Message
  }

  function toolCallMessage(id: string, name: string, args: string): Message {
    return {
      id,
      role: 'assistant',
      content: [{ type: 'tool-call', id: 'c1', name, arguments: args }],
      source: { kind: 'model', provider: 'sensenova', model: 'kimi-k3' },
    } as unknown as Message
  }

  function toolResultMessage(id: string, text: string): Message {
    // 0.2.1:工具结果是独立的 tool 角色消息,callId/isError 在消息级。
    return {
      id,
      role: 'tool',
      content: [{ type: 'text', text }],
      source: { kind: 'tool', callId: 'c1' },
      toolCallId: 'c1',
    } as unknown as Message
  }

  /** 压缩 checkpoint(0.2.1 的 source kind 是 'compact-checkpoint')。 */
  function checkpoint(id: string, text: string): Message {
    return {
      id,
      role: 'user',
      content: [{ type: 'text', text }],
      source: { kind: 'compact-checkpoint', compactionId: 'cp-1' },
    } as unknown as Message
  }

  it('其他模型的工具调用被补发:纯 tool-call 消息不再整条丢失', async () => {
    const { ctx } = makeCtx()
    const messages = [
      userMessage('u1', '第一问'),
      ownAssistant('a1', 'own 的回答'),
      toolCallMessage('a2', 'Bash', '{"command":"ls"}'),
      toolResultMessage('t1', 'ls 的输出'),
      userMessage('u2', '新问题'),
    ]
    const replay = await resumeReplayPrompt(ctx as never, messages, 2)
    expect(replay.prompt).toContain('[tool call: Bash')
    expect(replay.prompt).toContain('ls 的输出')
    expect(replay.prompt).toContain('新问题')
    expect(replay.prompt).not.toContain('own 的回答')
  })

  it('数量锚遇到压缩 checkpoint 不可信:从最后一次 checkpoint 起补发(摘要+其后)', async () => {
    const { ctx } = makeCtx()
    // 前 4 条"已发"(sentCount=4),但其中混入了压缩 checkpoint——遮蔽段落在
    // 已发区内,索引已错位,数量锚不可信。此时补发起点取**最后一次 checkpoint**:
    // 摘要本身 + 其后 CLI 没见过的一切。checkpoint 之前的内容 CLI 已有原文,
    // 不重发(旧的"不整体重建"顾虑仍然成立)。
    const messages = [
      userMessage('u1', '第一问'),
      checkpoint('cp1', '压缩摘要内容'),
      ownAssistant('a1', 'own 的回答'),
      userMessage('u3', '中间消息'),
      userMessage('u4', '新问题'),
    ]
    const replay = await resumeReplayPrompt(ctx as never, messages, 4)
    expect(replay.prompt).toContain('压缩摘要内容')
    expect(replay.prompt).toContain('中间消息')
    expect(replay.prompt).toContain('新问题')
    // checkpoint 之前的内容不重发;own 轮仍跳过。
    expect(replay.prompt).not.toContain('第一问')
    expect(replay.prompt).not.toContain('own 的回答')
  })

  it('锚点被压缩遮蔽:从最后一次 checkpoint 起补发,不再丢中途内容(回归)', async () => {
    // 事故(2026-09-24 用户报障):从 cli 切到 dsh 再切回 cli,中途增量的消息与
    // 压缩摘要都没补上。实测链条:
    //   09:21 切回 codebuddy(锚点记在 seq 8284)
    //   09:32 dsh 侧压缩,遮蔽 7941→8489 —— 锚点被吞
    //   之后切回 CLI → findIndex 失败 → 旧实现只发最后一条用户输入 → 全丢
    // 现在锚点找不到就退到"最后一次 checkpoint"(摘要 + 其后全部)。
    const { ctx } = makeCtx()
    const messages = [
      checkpoint('cp1', '压缩摘要内容'),
      ownAssistant('a1', 'own 的尾部回答'),
      userMessage('f1', '已转发的插话'),
      userMessage('u2', '新问题'),
    ]
    const replay = await resumeReplayPrompt(ctx as never, messages, 3, new Set(['f1']), 'a-gone')
    expect(replay.prompt).toContain('压缩摘要内容')
    expect(replay.prompt).toContain('新问题')
    // own 轮与已转发插入仍不重发。
    expect(replay.prompt).not.toContain('own 的尾部回答')
    expect(replay.prompt).not.toContain('已转发的插话')
  })

  it('锚点丢失 + checkpoint 之后全是已插话投递的消息:补发摘要(不再空跑)', async () => {
    // checkpoint 本身就是要补的内容(CLI 没见过 dsh 侧的这次压缩),所以不再
    // 置 skippedForwarded —— 那会让调用方空跑,摘要永远到不了 CLI。
    const { ctx } = makeCtx()
    const messages = [
      checkpoint('cp1', '压缩摘要内容'),
      userMessage('f1', '已转发的插话'),
    ]
    const replay = await resumeReplayPrompt(ctx as never, messages, 1, new Set(['f1']), 'a-gone')
    expect(replay.prompt).toContain('压缩摘要内容')
    expect(replay.prompt).not.toContain('已转发的插话')
    expect(replay.skippedForwarded).toBeFalsy()
  })

  it('锚点丢失且没有任何 checkpoint:才退回只发最后一条用户输入', async () => {
    const { ctx } = makeCtx()
    const messages = [
      userMessage('u1', '第一问'),
      ownAssistant('a1', 'own 的回答'),
      userMessage('u2', '新问题'),
    ]
    const replay = await resumeReplayPrompt(ctx as never, messages, 3, undefined, 'a-gone')
    expect(replay.prompt).toContain('新问题')
    expect(replay.prompt).not.toContain('第一问')
    expect(replay.prompt).not.toContain('own 的回答')
  })

  it('正常补发:起点之后穿插的 own 轮不重发(CLI 已有)', async () => {
    const { ctx } = makeCtx()
    const messages = [
      userMessage('u1', '旧输入'),
      ownAssistant('a1', 'own 的回答'),
      otherAssistant('a2', '别的模型的回答'),
      ownAssistant('a3', '期间穿插的 own 回答'),
      userMessage('u2', '新问题'),
    ]
    const replay = await resumeReplayPrompt(ctx as never, messages, 2)
    expect(replay.prompt).toContain('别的模型的回答')
    expect(replay.prompt).toContain('新问题')
    expect(replay.prompt).not.toContain('own 的回答')
    expect(replay.prompt).not.toContain('期间穿插的 own 回答')
  })
})
