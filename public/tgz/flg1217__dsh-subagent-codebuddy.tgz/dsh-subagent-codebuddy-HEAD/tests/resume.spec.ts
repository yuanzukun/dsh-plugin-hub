/**
 * 续聊补发与跨重启恢复测试:
 * - 首轮全量、次轮只补发锚点之后的消息(跳过 CodeBuddy 自己产生的消息);
 * - 切换其他模型期间缺失的轮次被完整补发;
 * - 服务重启(新 adapter + 同一持久化 store)从 CodeBuddy 持久会话恢复(session/load);
 * - 锚点缺失/会话存储丢失的兜底路径。
 */
import { describe, expect, it, vi, beforeEach } from 'vitest'
import { mkdtempSync, readdirSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import type { GenerateOptions, Message } from '@deepseek-ai/dsh-llm'
import { CodebuddyLlmAdapter } from '../src/adapter.ts'
import { ConversationStore } from '../src/conversations.ts'
import { projectSlug } from '../src/native-session.ts'
import { asSpawnResult, fakeAcpProc, message } from './fake-acp.ts'
import { promptTailFor } from '../src/pump.ts'
import type { ModelCapabilityIndex } from '../src/model-capabilities.ts'

/** 假能力索引:测试里的模型按多模态处理(读图引导 = 原生 read_image)。 */
function imageCapable(): ModelCapabilityIndex {
  return {
    capabilityOf: () => ({ supportsImages: true, known: true }),
    path: () => '(fake)',
    invalidate: () => {},
  }
}

vi.mock('node:child_process', async (importOriginal) => {
  const actual = await importOriginal<typeof import('node:child_process')>()
  return { ...actual, spawn: vi.fn() }
})
const { spawn } = await import('node:child_process')
const mockedSpawn = vi.mocked(spawn)

/** 一条简单消息。 */
function msg(id: string, role: 'user' | 'assistant', text: string, source?: Record<string, unknown>): Message {
  return {
    id,
    role,
    content: [{ type: 'text', text }],
    source: source ?? (role === 'assistant' ? { kind: 'model', provider: 'codebuddy', model: 'glm-5.3' } : { kind: 'user' }),
  } as unknown as Message
}

function toolResult(id: string, callId: string, text: string): Message {
  // 0.2.1:工具结果是独立的 tool 角色消息,callId/isError 在消息级。
  return {
    id,
    role: 'tool',
    content: [{ type: 'text', text }],
    source: { kind: 'tool', callId },
    toolCallId: callId,
  } as unknown as Message
}

interface Harness {
  adapter: CodebuddyLlmAdapter
  prompts: string[]
  requests: () => string[]
}

function makeHarness(
  store: ConversationStore,
  sessionId = 's1',
  failLoad = false,
  nativeBaseDir?: string,
  failPrompt = false,
  closedStep = false,
): Harness {
  const prompts: string[] = []
  const session = {
    header: { cwd: process.cwd(), parentSession: 'p1', origin: 'subagent' },
    append: () => ({ seq: 0 }),
    ownEvents: () => closedStep
      ? [
          { type: 'turn/start', data: { turn: 1 } },
          { type: 'step/start', data: { turn: 1, step: 1 } },
          { type: 'step/end', data: { turn: 1, step: 1 } },
          { type: 'turn/end', data: { turn: 1 } },
        ]
      : [
          { type: 'turn/start', data: { turn: 1 } },
          { type: 'step/start', data: { turn: 1, step: 1 } },
        ],
  }
  const ctx = {
    get: (key: string) => (key === 'sessions' ? { get: () => session } : undefined),
  } as unknown as Context
  const adapter = new CodebuddyLlmAdapter(ctx, {
    command: 'codebuddy.js',
    prefixArgs: [],
    modelOf: () => 'glm-5.3',
    permissionMode: 'bypassPermissions',
    extraArgs: [],
    store,
    maxAttempts: 1,
    capabilities: imageCapable(),
    ...(nativeBaseDir !== undefined ? { nativeBaseDir } : {}),
  })
  mockedSpawn.mockImplementation(() => {
    const p = fakeAcpProc()
    p.onRequest(request => {
      if (request.method === 'initialize') {
        p.respond(request.id, { protocolVersion: 1, agentCapabilities: { loadSession: true } })
      } else if (request.method === 'session/new') {
        p.respond(request.id, { sessionId: 'cb-1' })
      } else if (request.method === 'session/load') {
        if (failLoad) p.respondError(request.id, { code: -1, message: 'session not found' })
        else p.respond(request.id, {})
      } else if (request.method === 'session/prompt') {
        if (failPrompt) {
          p.respondError(request.id, { code: -1, message: 'prompt rejected' })
          return
        }
        const prompt = (request.params['prompt'] as Array<{ text: string }>)[0]
        prompts.push(prompt?.text ?? '')
        setTimeout(() => p.respond(request.id, { stopReason: 'end_turn' }), 5)
      }
    })
    setTimeout(() => { p.update(message('回复')) }, 5)
    return asSpawnResult(p)
  })
  return { adapter, prompts, requests: () => fakeAcpProcCalls() }
}

/** 最近一次假进程的请求记录。 */
function fakeAcpProcCalls(): string[] {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const last = (vi.mocked(spawn).mock.results.at(-1)?.value as any)
  return last?.requestLog?.() ?? []
}

function options(messages: Message[]): GenerateOptions {
  return {
    model: 'glm-5.3',
    provider: 'codebuddy',
    sessionId: 's1',
    messages,
  } as unknown as GenerateOptions
}

async function drain(adapter: CodebuddyLlmAdapter, opts: GenerateOptions): Promise<void> {
  for await (const _ of adapter.stream(opts)) { /* drain */ }
}

beforeEach(() => {
  mockedSpawn.mockReset()
})

describe('续聊补发', () => {
  it('首轮全量;次轮只补发新轮次(跳过 CodeBuddy 自己的回复)', async () => {
    const store = new ConversationStore(null)
    const { adapter, prompts } = makeHarness(store)
    const u1 = msg('u1', 'user', '第一问')
    await drain(adapter, options([u1]))
    expect(prompts[0]).toContain('第一问')

    const u2 = msg('u2', 'user', '第二问')
    await drain(adapter, options([u1, msg('a1', 'assistant', '第一答'), u2]))
    expect(prompts[1]).toContain('第二问')
    expect(prompts[1]).not.toContain('第一问')
    expect(prompts[1]).not.toContain('第一答')
  })

  it('切换其他模型后的缺失轮次被完整补发', async () => {
    const store = new ConversationStore(null)
    const { adapter, prompts } = makeHarness(store)
    const u1 = msg('u1', 'user', '第一问')
    await drain(adapter, options([u1]))

    // 期间:CodeBuddy 回 a1;切到其他模型跑了一轮(u2/a2/工具结果);回到 CodeBuddy(u3)。
    const messages = [
      u1,
      msg('a1', 'assistant', 'CodeBuddy 的第一答'),
      msg('u2', 'user', '其他模型的问题'),
      msg('a2', 'assistant', '其他模型的回答', { kind: 'model', provider: 'cpa', model: 'kimi-k3' }),
      toolResult('t1', 'call_x', '工具输出内容'),
      msg('u3', 'user', '回到 CodeBuddy 的问题'),
    ]
    await drain(adapter, options(messages))
    const prompt = prompts.at(-1)!
    expect(prompt).toContain('其他模型的问题')
    expect(prompt).toContain('其他模型的回答')
    expect(prompt).toContain('工具输出内容')
    expect(prompt).toContain('回到 CodeBuddy 的问题')
    expect(prompt).not.toContain('第一问')
    expect(prompt).not.toContain('CodeBuddy 的第一答')
  })
})

describe('原生会话种子(已有历史切换)', () => {
  it('写原生会话文件 + session/load,prompt 只带当前输入', async () => {
    const store = new ConversationStore(null)
    const baseDir = mkdtempSync(join(tmpdir(), 'cb-native-'))
    try {
      const { adapter, prompts, requests } = makeHarness(store, 's1', false, baseDir)
      await drain(adapter, options([
        msg('u1', 'user', '历史问题一'),
        msg('a1', 'assistant', '历史回答一'),
        msg('u2', 'user', '当前问题'),
      ]))
      expect(requests()).toContain('session/load')
      expect(requests()).not.toContain('session/new')
      // prompt 只带当前输入,历史不在提示词里。
      expect(prompts.at(-1)?.startsWith('当前问题')).toBe(true)
      expect(prompts.at(-1)?.endsWith(promptTailFor('delegate', 'native'))).toBe(true)
      // 原生文件已写入:含历史消息,不含当前输入(它作为 prompt 发送)。
      const dir = join(baseDir, projectSlug(process.cwd()))
      const files = readdirSync(dir).filter(f => f.endsWith('.jsonl'))
      expect(files.length).toBe(1)
      const content = readFileSync(join(dir, files[0]!), 'utf8')
      expect(content).toContain('历史问题一')
      expect(content).toContain('历史回答一')
      expect(content).not.toContain('当前问题')
    } finally {
      rmSync(baseDir, { recursive: true, force: true })
    }
  })

  it('system prompt 随原生 seed 发送:进首条记录,不进 prompt 正文', async () => {
    const store = new ConversationStore(null)
    const baseDir = mkdtempSync(join(tmpdir(), 'cb-native-'))
    try {
      const { adapter, prompts } = makeHarness(store, 's1', false, baseDir)
      await drain(adapter, {
        ...options([
          msg('u1', 'user', '历史问题一'),
          msg('a1', 'assistant', '历史回答一'),
          msg('u2', 'user', '当前问题'),
        ]),
        system: 'DSS-SYSTEM-PROMPT',
      } as GenerateOptions)
      // prompt 只带当前输入(尾注仍是 dsh 委派说明),system 走 seed 首条记录。
      expect(prompts.at(-1)).toContain('当前问题')
      expect(prompts.at(-1)).not.toContain('DSS-SYSTEM-PROMPT')
      const dir = join(baseDir, projectSlug(process.cwd()))
      const files = readdirSync(dir).filter(f => f.endsWith('.jsonl'))
      const lines = readFileSync(join(dir, files[0]!), 'utf8').trim().split(/\r?\n/)
      // 头部 session-meta 之后的第一条消息记录就是 system 指令。
      const firstMessage = lines.find(line => line.includes('"type":"message"'))!
      expect(firstMessage).toContain('DSS-SYSTEM-PROMPT')
      // 哈希落盘:重启后不重发。
      expect(store.get('s1')?.systemHash).toBeTruthy()
    } finally {
      rmSync(baseDir, { recursive: true, force: true })
    }
  })

  it('已存在的会话:system 变化才补发一次(哈希记录已发版本)', async () => {
    const store = new ConversationStore(null)
    store.set('s1', { acpId: 'cb-1', sentCount: 0 })
    const { adapter, prompts } = makeHarness(store)
    const u1 = msg('u1', 'user', '第一问')
    await drain(adapter, { ...options([u1]), system: 'SYS-A' } as GenerateOptions)
    expect(prompts[0]).toContain('SYS-A')
    const hashA = store.get('s1')?.systemHash
    expect(hashA).toBeTruthy()

    const u2 = msg('u2', 'user', '第二问')
    await drain(adapter, { ...options([u1, u2]), system: 'SYS-A' } as GenerateOptions)
    expect(prompts[1]).not.toContain('SYS-A')

    const u3 = msg('u3', 'user', '第三问')
    await drain(adapter, { ...options([u1, u2, u3]), system: 'SYS-B' } as GenerateOptions)
    expect(prompts[2]).toContain('SYS-B')
    expect(prompts[2]).toContain('updated')
    expect(store.get('s1')?.systemHash).not.toBe(hashA)
  })

  it('原生载入被拒 → 回退新会话 + 全量提示词', async () => {
    const store = new ConversationStore(null)
    const baseDir = mkdtempSync(join(tmpdir(), 'cb-native-'))
    try {
      const { adapter, prompts, requests } = makeHarness(store, 's1', true, baseDir)
      await drain(adapter, options([
        msg('u1', 'user', '历史问题一'),
        msg('a1', 'assistant', '历史回答一'),
        msg('u2', 'user', '当前问题'),
      ]))
      expect(requests()).toContain('session/load')
      expect(requests()).toContain('session/new')
      const prompt = prompts.at(-1)!
      expect(prompt).toContain('历史问题一')
      expect(prompt).toContain('当前问题')
    } finally {
      rmSync(baseDir, { recursive: true, force: true })
    }
  })

  it('单条消息的新会话不开原生种子(子代理首派发走 session/new)', async () => {
    const store = new ConversationStore(null)
    const baseDir = mkdtempSync(join(tmpdir(), 'cb-native-'))
    try {
      const { adapter, prompts, requests } = makeHarness(store, 's1', false, baseDir)
      await drain(adapter, options([msg('u1', 'user', '任务描述')]))
      expect(requests()).toContain('session/new')
      expect(requests()).not.toContain('session/load')
      expect(prompts.at(-1)).toContain('任务描述')
    } finally {
      rmSync(baseDir, { recursive: true, force: true })
    }
  })
})

describe('跨重启恢复', () => {
  it('重启后(新 adapter + 持久化 store)走 session/load,不再 session/new', async () => {
    const store = new ConversationStore(null)
    const first = makeHarness(store)
    await drain(first.adapter, options([msg('u1', 'user', '问题一')]))
    expect(first.requests()).toContain('session/new')

    // “重启”:同一个持久化 store 构造新 adapter。
    const second = makeHarness(store)
    await drain(second.adapter, options([msg('u1', 'user', '问题一'), msg('a1', 'assistant', '答一'), msg('u2', 'user', '问题二')]))
    expect(second.requests()).toContain('session/load')
    expect(second.requests()).not.toContain('session/new')
  })

  it('CodeBuddy 侧会话丢失:回退新会话 + 完整历史重发', async () => {
    const store = new ConversationStore(null)
    const first = makeHarness(store)
    await drain(first.adapter, options([msg('u1', 'user', '问题一')]))

    const second = makeHarness(store, 's1', true) // load 失败
    await drain(second.adapter, options([msg('u1', 'user', '问题一'), msg('a1', 'assistant', '答一'), msg('u2', 'user', '问题二')]))
    expect(second.requests()).toContain('session/load')
    expect(second.requests()).toContain('session/new')
    const prompt = second.prompts.at(-1)!
    expect(prompt).toContain('问题一')
    expect(prompt).toContain('问题二')
  })

  it('锚点被压缩移除(历史收缩):只发最后一条用户输入兜底,不整体重发', async () => {
    const store = new ConversationStore(null)
    const { adapter, prompts } = makeHarness(store)
    await drain(adapter, options([msg('u1', 'user', '很长的问题一'), msg('a1', 'assistant', '答一'), msg('u2', 'user', '问题二')]))
    // 下一次:历史被压缩收缩(锚点消息已被移除)——CLI 有自己的持久上下文,
    // 不能整体重建(重发已知内容会膨胀且会被当作新任务从头重跑),只发
    // 最后一条用户输入兜底。
    await drain(adapter, options([msg('u3', 'user', '压缩后的新问题')]))
    const prompt = prompts.at(-1)!
    expect(prompt).toContain('压缩后的新问题')
    expect(prompt).not.toContain('很长的问题一')
    expect(prompt).not.toContain('问题二')
    expect(prompt.endsWith(promptTailFor('delegate', 'native'))).toBe(true)
  })
})

describe('续接锚点的写入时机与字段完整性', () => {
  it('prompt 请求失败:锚点不写(下轮补发重发该输入,而不是静默丢失)', async () => {
    const store = new ConversationStore(null)
    const { adapter, requests } = makeHarness(store, 's1', false, undefined, true)
    await drain(adapter, options([msg('u1', 'user', '第一问')]))
    // 会话已建立(new),但 prompt 被拒:此刻绝不能记锚点——记了就把
    // "从未发出的输入"标记为已发,下轮补发会静默吞掉它。
    expect(requests()).toContain('session/new')
    expect(store.get('s1')).toBeUndefined()
  })

  it('旁路路径(oneShot)写锚点:主锚与 system 哈希不丢(不覆盖回数量锚)', async () => {
    const store = new ConversationStore(null)
    // 泵路径先写一条带主锚的记录(模拟上一轮)。
    store.set('s1', { acpId: 'cb-0', sentCount: 2, lastSentMessageId: 'a1', systemHash: 'hash-a' })
    const baseDir = mkdtempSync(join(tmpdir(), 'cb-oneshot-'))
    try {
      // closedStep:无打开 step → 适配器走一次性旁路会话(oneShot)。
      const { adapter } = makeHarness(store, 's1', false, baseDir, false, true)
      await drain(adapter, options([msg('u1', 'user', '问题一'), msg('a1', 'assistant', '答一'), msg('u2', 'user', '问题二')]))
      const record = store.get('s1')
      expect(record).toBeDefined()
      // set 是整体替换:主锚必须随写,否则压缩/编辑后数量锚错位丢上下文。
      expect(record?.lastSentMessageId).toBe('u2')
      expect(record?.sentCount).toBe(3)
    } finally {
      rmSync(baseDir, { recursive: true, force: true })
    }
  })
})
