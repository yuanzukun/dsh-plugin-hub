# quant-repo —— 量化大厂开源 repo 专刊

收录量化机构的**开源仓库**介绍：每个 repo 讲清「是什么、为什么开源、
能学到什么」。首批：**Jane Street · Optiver · Citadel**。

> 与 `quant-history/` 分开：历史讲人与事，这里讲代码与工程。
> 欢迎 PR 补充遗漏 repo 或新机构。

## 首批专刊

| 机构 | 开源姿态 | 专刊 |
|---|---|---|
| Jane Street | 极度开放（~90 repos，OCaml 生态）| [janestreet.md](janestreet.md) |
| Optiver | 教育型开源（做市竞赛 SDK）| [optiver.md](optiver.md) |
| Susquehanna (SIG) | 零开源（母体的沉默）| [sig.md](sig.md) |
| Citadel | 几乎为零（保密文化）| [citadel.md](citadel.md) |
| Millennium | 几乎为零（pod 保密叠加）| [millennium.md](millennium.md) |
| WorldQuant | 论文与平台型（101 Alphas/BRAIN）| [worldquant.md](worldquant.md) |
| Jump Trading | 基础设施开源（Firedancer/Wormhole/Pyth）| [jumptrading.md](jumptrading.md) |
| Hudson River Trading | 极少（谜题文化输出）| [hrt.md](hrt.md) |
| Point72 | 首个开源库 csp（流处理）| [point72.md](point72.md) |
| Squarepoint | 零开源（隐身端）| [squarepoint.md](squarepoint.md) |
| Two Sigma | 研究基础设施开源（flint/beakerx）| [twosigma.md](twosigma.md) |
| Virtu | 零开源（披露文件型）| [virtu.md](virtu.md) |
| DE Shaw | 近零（DESRES 科研输出）| [deshaw.md](deshaw.md) |
| Renaissance | 永远为零（光谱终点）| [rentec.md](rentec.md) |
| Man Group | 数据栈开源（ArcticDB）| [mangroup.md](mangroup.md) |
| AQR | 论文+数据集型（AQR Data Sets）| [aqr.md](aqr.md) |
| GSA | 零开源（伦敦低调）| [gsa.md](gsa.md) |
| Bridgewater | 思想开源（Principles）| [bridgewater.md](bridgewater.md) |
| Balyasny | 零开源（平台保密）| [balyasny.md](balyasny.md) |
| IMC | 竞赛 SDK（imc-prosperity）| [imc.md](imc.md) |
| XTX | 极少（披露文件型）| [xtx.md](xtx.md) |
| Five Rings | 零开源（神秘双极）| [fiverings.md](fiverings.md) |
| QRT / Capula / Winton / DRW / Tower | 五家集中专刊（低调系统化一族，公开资产替代物）| [quiet-five.md](quiet-five.md) |
| Wintermute / Wolverine / Akuna / CTC / Alameda | 做市加密批集中专刊（做市系零开源铁律 + 负面教材）| [market-making-crypto-five.md](market-making-crypto-five.md) |
| Marshall Wace / ExodusPoint / Schonfeld / Aspect / Verition | 系统化五强集中专刊（欧洲系统化全封闭 + 公开资产多样性）| [systematic-europe-five.md](systematic-europe-five.md) |
| Tudor / BH / Rokos / PDT / Dimensional | 宏观传奇批集中专刊（公开资产形态清单补全：影像+学术库）| [macro-legends-five.md](macro-legends-five.md) |
| 幻方 / 九坤 / 明汯 / 衍复 / 世纪前沿 | 中国篇集中专刊（幻方=DeepSeek 开源旗帜，血缘闭环）| [china-five.md](china-five.md) |

## 收录规则（欢迎 PR）

- 每个 repo：一句话 + 技术栈 + 能学到什么
- 只收机构官方 org 下的仓库（个人移植标注说明）
- 标注活跃度（stars/更新状态）与许可证
