/** Diagnostic facts only; no connection capabilities or Agent credentials. */
export interface AcpPermissionCheck {
  readonly reason:
    | 'auto-approved'
    | 'approval-required'
    | 'policy-unavailable'
    | 'bridge-unavailable'
    | 'inactive-connection'
    | 'inactive-prompt'
    | 'identity-unmatched'
    | 'invalid-tool-name'
    | 'not-coordination'
    | 'allow-once-unavailable'
  readonly toolName?: string
  readonly identitySource?:
    | 'codex-input'
    | 'codebuddy-deferred-input'
    | 'name'
    | 'claude-meta'
    | 'devin-meta'
    | 'devin-title'
    | 'kimi-title'
    | 'antigravity-meta'
    | 'antigravity-title'
  readonly structuredIdentityPresent?: boolean
  readonly titleMatchesCurrentTool?: boolean
}
