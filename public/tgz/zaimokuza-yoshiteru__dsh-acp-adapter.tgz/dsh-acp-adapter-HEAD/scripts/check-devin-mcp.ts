/** Verify real Devin config contents via ACP's built-in /mcp command. No login or model call. */
import assert from 'node:assert/strict'
import { randomUUID } from 'node:crypto'
import { execFile, spawn } from 'node:child_process'
import { mkdtemp, mkdir, readFile, writeFile, rm } from 'node:fs/promises'
import { tmpdir, userInfo } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { createInterface } from 'node:readline'
import { promisify } from 'node:util'
import { fileURLToPath } from 'node:url'
import { Context } from '@deepseek-ai/cordis'
import LocalSubprocess from '@deepseek-ai/dsh-subprocess-local'
import { narrowSubprocessSeam } from '../src/runtime/process/subprocess.ts'
import { prepareDevinMcp } from '../src/host/tools/devin-config.ts'

const executable = process.argv[2]
assert.ok(executable, 'Pass the real Devin executable path')
const root = await mkdtemp(join(tmpdir(), 'dsh-real-devin-'))
let prepared: Awaited<ReturnType<typeof prepareDevinMcp>> | undefined
let nativeFile: string | undefined
let originalNativeFile: Buffer | undefined
let nativeFileWritten = false

interface Inspection {
  _meta?: { mcpConfigPath?: string }
  mcpListing: string
}

async function inspectMcp(env: NodeJS.ProcessEnv): Promise<Inspection> {
  const child = spawn(executable!, ['acp'], { cwd: root, env, stdio: ['pipe', 'pipe', 'pipe'] })
  const closed = new Promise<void>((done) => child.once('close', () => done()))
  child.stderr.resume()
  const lines = createInterface({ input: child.stdout })
  try {
    return await new Promise((done, reject) => {
      const timeout = setTimeout(() => reject(new Error('Devin config inspection timed out')), 30_000)
      const result: Inspection = { mcpListing: '' }
      const send = (id: number, method: string, params: object) => {
        child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n')
      }
      const finish = (error?: Error) => {
        clearTimeout(timeout)
        if (error) reject(error)
        else done(result)
      }
      child.once('error', (error) => finish(error))
      child.stdin.once('error', (error) => finish(error))
      child.once('exit', (code) => finish(new Error(`Devin exited before inspection: ${code}`)))
      lines.on('line', (line) => {
        let message
        try {
          message = JSON.parse(line)
        } catch {
          return
        }
        if (message.method === 'session/update') {
          const update = message.params?.update
          if (update?.sessionUpdate === 'agent_message_chunk' && update.content?.type === 'text')
            result.mcpListing += update.content.text
          return
        }
        if (![1, 2, 3].includes(message.id) || message.method !== undefined) return
        if (message.error) {
          finish(new Error(`Devin config inspection error: ${JSON.stringify(message.error)}`))
          return
        }
        if (message.id === 1) {
          result._meta = message.result._meta
          send(2, 'session/new', { cwd: root, mcpServers: [] })
        } else if (message.id === 2) {
          send(3, 'session/prompt', { sessionId: message.result.sessionId, prompt: [{ type: 'text', text: '/mcp' }] })
        } else finish()
      })
      send(1, 'initialize', {
        protocolVersion: 1,
        clientCapabilities: {},
        clientInfo: { name: 'dsh-mcp-discovery-test', version: '1' },
      })
    })
  } finally {
    child.kill('SIGKILL')
    await closed
    lines.close()
  }
}

try {
  const source = join(root, 'config')
  await mkdir(join(source, 'devin'), { recursive: true })
  await writeFile(join(source, 'devin', 'config.json'), '{}')
  const sourceEnv = {
    XDG_CONFIG_HOME: source,
    APPDATA: source,
    XDG_DATA_HOME: join(root, 'data'),
    XDG_CACHE_HOME: join(root, 'cache'),
  }
  // Windows cannot be isolated through XDG/APPDATA. Only write its real profile
  // in the disposable ordinary-user CI account, never in a developer's profile.
  const windowsNativeRoot = process.argv[3]
  if (process.platform === 'win32') {
    assert.ok(windowsNativeRoot, 'Pass the disposable CI account native APPDATA directory')
    assert.equal(userInfo().username, 'dsh-acp-ci', 'Native Windows config test requires the disposable CI account')
    assert.equal(
      resolve(windowsNativeRoot),
      resolve(process.env.APPDATA!),
      'Use the actual profile APPDATA before overriding it',
    )
  }
  nativeFile = join(process.platform === 'win32' ? windowsNativeRoot! : source, 'devin', 'mcp_config.json')
  await mkdir(dirname(nativeFile), { recursive: true })
  try {
    originalNativeFile = await readFile(nativeFile)
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error
  }
  const nativeServer = `dshteam_native_config_probe_${randomUUID().replaceAll('-', '')}`
  await writeFile(
    nativeFile,
    JSON.stringify({
      mcpServers: {
        [nativeServer]: { url: 'http://127.0.0.1:43210/native-config-probe', transport: 'http' },
      },
    }),
    { mode: 0o600 },
  )
  nativeFileWritten = true
  const nativeEnv = process.platform === 'win32' ? process.env : { ...process.env, ...sourceEnv }
  const baseline = await inspectMcp(nativeEnv)
  assert.equal(
    resolve(baseline._meta?.mcpConfigPath ?? ''),
    resolve(nativeFile),
    'Devin must report the documented native MCP file',
  )
  assert.ok(
    baseline.mcpListing.includes(nativeServer),
    'ACP /mcp must list the server written to the documented native file',
  )
  console.log(
    JSON.stringify({
      check: 'native-config-content',
      platform: process.platform,
      file: nativeFile,
      serverVisibleInAcp: true,
    }),
  )
  console.log('PASS: ACP /mcp reads the server from the documented native MCP config')
  // Let Devin itself locate and update its native config, including the fixed
  // stdio entry proposed for Windows. This does not start the MCP launcher.
  const runMcp = async (...args: string[]) =>
    await promisify(execFile)(executable!, ['mcp', ...args], {
      cwd: root,
      env: nativeEnv,
      timeout: 30_000,
    })
  const httpName = `http_probe_${randomUUID().replaceAll('-', '')}`
  const stdioName = `stdio_probe_${randomUUID().replaceAll('-', '')}`
  const launcher = fileURLToPath(new URL('../src/runtime/session/team-mcp-stdio.ts', import.meta.url))
  await runMcp('add', '--scope', 'user', httpName, 'http://127.0.0.1:43210/add-command-probe')
  await runMcp('add', '--scope', 'user', stdioName, '--', process.execPath, launcher)
  const added = JSON.parse(await readFile(nativeFile, 'utf8')).mcpServers
  assert.equal(added[httpName].url, 'http://127.0.0.1:43210/add-command-probe')
  assert.equal(added[stdioName].command, process.execPath)
  assert.deepEqual(added[stdioName].args, [launcher])
  assert.equal(
    added[nativeServer].url,
    'http://127.0.0.1:43210/native-config-probe',
    'mcp add must preserve existing servers',
  )
  const addedInspection = await inspectMcp(nativeEnv)
  assert.ok(addedInspection.mcpListing.includes(httpName), 'ACP must discover the HTTP server registered by mcp add')
  assert.ok(addedInspection.mcpListing.includes(stdioName), 'ACP must discover the stdio server registered by mcp add')
  await runMcp('remove', '--scope', 'user', httpName)
  await runMcp('remove', '--scope', 'user', stdioName)
  const removed = JSON.parse(await readFile(nativeFile, 'utf8')).mcpServers
  assert.equal(removed[httpName], undefined)
  assert.equal(removed[stdioName], undefined)
  assert.equal(
    removed[nativeServer].url,
    'http://127.0.0.1:43210/native-config-probe',
    'mcp remove must preserve other servers',
  )
  console.log(
    JSON.stringify({
      check: 'native-mcp-cli',
      platform: process.platform,
      httpAdd: true,
      stdioAdd: true,
      visibleInFreshAcp: true,
      remove: true,
      existingServerPreserved: true,
    }),
  )
  console.log('PASS: native mcp add/remove and ACP discovery for HTTP and stdio entries')
  const ctx = new Context()
  await ctx.plugin(LocalSubprocess)
  try {
    const options = {
      command: executable,
      args: ['acp'],
      cwd: root,
      subprocess: narrowSubprocessSeam(ctx.subprocess)!,
      env: { ...(process.platform === 'win32' ? {} : sourceEnv), HOME: root },
      lease: {
        signal: new AbortController().signal,
        servers: [{ type: 'http' as const, name: 'dsh', url: 'http://127.0.0.1:43210/test', headers: [] }],
        beginPrompt() {},
        endPrompt() {},
        permission: () => undefined,
        async close() {},
      },
    }
    prepared = await prepareDevinMcp(options)
    const config = JSON.parse(await readFile(nativeFile, 'utf8'))
    assert.equal(config.mcpServers.dsh.command, process.execPath)
    assert.equal(config.mcpServers.dsh.env.ELECTRON_RUN_AS_NODE, '1')
    assert.ok(config.mcpServers[nativeServer], 'Registration must preserve existing servers')
    assert.ok(!JSON.stringify(config).includes('/test'), 'Session endpoint must not be persisted')
    assert.equal(prepared.env.DSH_ACP_TEAM_MCP_URL, 'http://127.0.0.1:43210/test')
    const result = await inspectMcp({ ...process.env, ...prepared.env })
    assert.equal(resolve(result._meta?.mcpConfigPath ?? ''), resolve(nativeFile))
    assert.ok(result.mcpListing.includes('dsh'), 'Real Devin must discover the fixed DSH entry')
    console.log('PASS: production registration, native discovery, preserved user servers and private session routing')
    // Real `mcp get` redacts values; both missing and incorrect env must be repaired
    // even when the executable and launcher are already correct.
    for (const environment of [{}, { ELECTRON_RUN_AS_NODE: '0' }]) {
      const before = JSON.parse(await readFile(nativeFile, 'utf8'))
      before.mcpServers.dsh.env = environment
      await writeFile(nativeFile, JSON.stringify(before), { mode: 0o600 })
      await prepared.lease.close()
      prepared = await prepareDevinMcp(options)
      const repaired = JSON.parse(await readFile(nativeFile, 'utf8'))
      assert.equal(repaired.mcpServers.dsh.env.ELECTRON_RUN_AS_NODE, '1')
      assert.deepEqual(repaired.mcpServers.dsh.args, config.mcpServers.dsh.args)
      assert.equal(repaired.mcpServers.dsh.command, process.execPath)
      assert.deepEqual(Object.keys(repaired.mcpServers).sort(), Object.keys(before.mcpServers).sort())
      assert.deepEqual(repaired.mcpServers[nativeServer], before.mcpServers[nativeServer])
    }
    console.log('PASS: matching-command registration repairs missing/wrong Electron Node mode without adding servers')
  } finally {
    await ctx.fiber.dispose()
  }
} finally {
  await prepared?.lease.close()
  if (nativeFileWritten && nativeFile !== undefined) {
    if (originalNativeFile === undefined) await rm(nativeFile, { force: true })
    else await writeFile(nativeFile, originalNativeFile)
  }
  await rm(root, { recursive: true, force: true })
}
