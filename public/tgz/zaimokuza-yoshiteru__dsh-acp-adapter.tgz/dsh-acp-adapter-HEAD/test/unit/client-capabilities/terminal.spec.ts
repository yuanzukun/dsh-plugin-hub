import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { PassThrough, Writable } from 'node:stream'
import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import {
  ACP_TERMINAL_MAX_ACTIVE,
  ACP_TERMINAL_MAX_OUTPUT_BYTES,
  createAcpTerminalHandlers,
} from '../../../src/runtime/client-capabilities/terminal.ts'
import type { SubprocessSeam } from '../../../src/runtime/process/subprocess.ts'
import type { AcpSubprocessHandle } from '../../../src/runtime/process/subprocess.ts'
import { sharedTestSubprocess } from '../../fixtures/subprocess-seam-testing.ts'

let subprocess: SubprocessSeam
let root = ''

beforeAll(async () => {
  subprocess = (await sharedTestSubprocess()).seam
  root = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-acp-terminal-'))
})

afterAll(() => {
  fs.rmSync(root, { recursive: true, force: true })
})

function host(audit?: (event: import('../../../src/domain/policy/events.ts').AcpTerminalAuditData) => Promise<void>) {
  return createAcpTerminalHandlers({
    subprocess,
    profileId: 'codex',
    dshSessionId: 'dsh-terminal-test',
    cwd: root,
    env: Object.fromEntries(
      Object.entries(process.env).filter((entry): entry is [string, string] => entry[1] !== undefined),
    ),
    releaseWaitMs: 500,
    ...(audit === undefined ? {} : { audit }),
  })
}

describe('ACP v1 terminal host', () => {
  it('runs a structured command, merges stdout/stderr, enforces UTF-8 byte truncation and invalidates the released protocol ID', async () => {
    const events: unknown[] = []
    const terminals = host(async (event) => {
      events.push(event)
    })
    const created = await terminals.createTerminal({
      sessionId: 'acp-terminal-1',
      command: process.execPath,
      args: ['-e', "process.stdout.write('a');process.stderr.write('中');process.stdout.write('z')"],
      env: [{ name: 'TERM_SECRET', value: 'do-not-audit' }],
      cwd: root,
      outputByteLimit: 4,
    })
    await expect(
      terminals.waitForExit({ sessionId: 'acp-terminal-1', terminalId: created.terminalId }),
    ).resolves.toMatchObject({ exitCode: 0, signal: null })
    const output = await terminals.terminalOutput({ sessionId: 'acp-terminal-1', terminalId: created.terminalId })
    expect(output.truncated).toBe(true)
    expect(Buffer.byteLength(output.output, 'utf8')).toBeLessThanOrEqual(4)
    expect(output.output).toContain('z')
    await terminals.releaseTerminal({ sessionId: 'acp-terminal-1', terminalId: created.terminalId })
    await expect(
      terminals.terminalOutput({ sessionId: 'acp-terminal-1', terminalId: created.terminalId }),
    ).rejects.toThrow('unknown or already released')
    expect(events.map((event) => (event as { operation: string }).operation)).toEqual([
      'create',
      'exit',
      'output-summary',
      'release',
    ])
    expect(JSON.stringify(events)).not.toContain('TERM_SECRET')
    await terminals.dispose()
  })

  it('does not turn a presentation observer failure into a failed process result', async () => {
    const terminals = createAcpTerminalHandlers({
      subprocess: {
        resolveExecutable: async (command) => command,
        spawn: () => ({
          stdin: new PassThrough(),
          stdout: new PassThrough(),
          stderr: new PassThrough(),
          done: Promise.resolve({ exitCode: 17, signal: null }),
          terminate: () => {},
          waitForExit: async () => true,
        }),
      },
      profileId: 'observer',
      dshSessionId: 'observer-owner',
      cwd: root,
      env: {},
      onExit: () => {
        throw new Error('presentation unavailable')
      },
    })
    try {
      const created = await terminals.createTerminal({ sessionId: 'observer-session', command: 'fake' })
      await expect(
        terminals.waitForExit({ sessionId: 'observer-session', terminalId: created.terminalId }),
      ).resolves.toEqual({ exitCode: 17, signal: null })
    } finally {
      await terminals.dispose()
    }
  })

  it('rejects cross-session access and keeps a killed terminal ID valid until release', async () => {
    const terminals = host()
    const created = await terminals.createTerminal({
      sessionId: 'owner',
      command: process.execPath,
      args: ['-e', 'setInterval(() => process.stdout.write("tick"), 10)'],
      cwd: root,
      outputByteLimit: 128,
    })
    await expect(terminals.terminalOutput({ sessionId: 'other', terminalId: created.terminalId })).rejects.toThrow(
      'different ACP session',
    )
    await expect
      .poll(
        async () => (await terminals.terminalOutput({ sessionId: 'owner', terminalId: created.terminalId })).output,
        { timeout: 5000 },
      )
      .toContain('tick')
    await terminals.killTerminal({ sessionId: 'owner', terminalId: created.terminalId })
    const exit = await terminals.waitForExit({ sessionId: 'owner', terminalId: created.terminalId })
    expect(exit.exitCode !== null || exit.signal !== null).toBe(true)
    await expect(
      terminals.terminalOutput({ sessionId: 'owner', terminalId: created.terminalId }),
    ).resolves.toHaveProperty('output')
    await terminals.releaseTerminal({ sessionId: 'owner', terminalId: created.terminalId })
    await terminals.dispose()
  })

  it('release kills a running process and invalidates the protocol ID', async () => {
    const terminals = host()
    const created = await terminals.createTerminal({
      sessionId: 'release-session',
      command: process.execPath,
      args: ['-e', 'setInterval(() => {}, 1000)'],
      cwd: root,
    })
    await terminals.releaseTerminal({ sessionId: 'release-session', terminalId: created.terminalId })
    await expect(
      terminals.killTerminal({ sessionId: 'release-session', terminalId: created.terminalId }),
    ).rejects.toThrow('unknown or already released')
    await terminals.dispose()
  })

  it('does not report truncation when the host cap is larger than actual output', async () => {
    const terminals = host()
    const created = await terminals.createTerminal({
      sessionId: 'small-output',
      command: process.execPath,
      args: ['-e', "process.stdout.write('tiny')"],
      cwd: root,
      outputByteLimit: ACP_TERMINAL_MAX_OUTPUT_BYTES + 1,
    })
    await terminals.waitForExit({ sessionId: 'small-output', terminalId: created.terminalId })
    await expect(
      terminals.terminalOutput({ sessionId: 'small-output', terminalId: created.terminalId }),
    ).resolves.toMatchObject({ output: 'tiny', truncated: false })
    await terminals.dispose()
  })

  it('bounds active terminals and frees their slots after release', async () => {
    const fake: SubprocessSeam = {
      spawn: () => {
        const handle: AcpSubprocessHandle = {
          stdin: new PassThrough(),
          stdout: new PassThrough(),
          stderr: new PassThrough(),
          done: Promise.resolve({ exitCode: 0, signal: null }),
          terminate: () => {},
          waitForExit: async () => true,
        }
        return handle
      },
      resolveExecutable: async (command) => command,
    }
    const terminals = createAcpTerminalHandlers({
      subprocess: fake,
      profileId: 'bounded',
      dshSessionId: 'dsh-bounded',
      cwd: root,
      env: {},
    })
    const active = []
    for (let i = 0; i < ACP_TERMINAL_MAX_ACTIVE; i += 1) {
      active.push(await terminals.createTerminal({ sessionId: 'bounded-session', command: 'fake' }))
    }
    await expect(terminals.createTerminal({ sessionId: 'bounded-session', command: 'fake' })).rejects.toThrow(
      'active terminal limit',
    )
    const releasedId = active[0]!.terminalId
    await terminals.releaseTerminal({ sessionId: 'bounded-session', terminalId: releasedId })
    await expect(terminals.terminalOutput({ sessionId: 'bounded-session', terminalId: releasedId })).rejects.toThrow(
      'unknown or already released',
    )
    await expect(terminals.createTerminal({ sessionId: 'bounded-session', command: 'fake' })).resolves.toHaveProperty(
      'terminalId',
    )
    await terminals.dispose()
  })

  it('disposes many terminals concurrently under one shared deadline', async () => {
    let terminateCount = 0
    const fake: SubprocessSeam = {
      spawn: () => ({
        stdin: new PassThrough(),
        stdout: new PassThrough(),
        stderr: new PassThrough(),
        done: new Promise<never>(() => {}),
        terminate: () => {
          terminateCount += 1
        },
        waitForExit: async () => false,
      }),
      resolveExecutable: async (command) => command,
    }
    const terminals = createAcpTerminalHandlers({
      subprocess: fake,
      profileId: 'dispose',
      dshSessionId: 'dsh-dispose',
      cwd: root,
      env: {},
      releaseWaitMs: 20,
    })
    for (let i = 0; i < 3; i += 1) await terminals.createTerminal({ sessionId: 'dispose-session', command: 'fake' })
    const started = Date.now()
    await terminals.dispose()
    expect(Date.now() - started).toBeLessThan(100)
    expect(terminateCount).toBe(3)
  })

  it('does not claim release when the subprocess seam cannot prove tree exit; the ID remains retryable', async () => {
    let terminateCount = 0
    const neverDone = new Promise<never>(() => {})
    const handle: AcpSubprocessHandle = {
      stdin: new PassThrough(),
      stdout: new PassThrough(),
      stderr: new PassThrough(),
      done: neverDone,
      terminate: () => {
        terminateCount += 1
      },
      waitForExit: async () => false,
    }
    const fake: SubprocessSeam = {
      spawn: () => handle,
      resolveExecutable: async (command) => command,
    }
    const terminals = createAcpTerminalHandlers({
      subprocess: fake,
      profileId: 'fake',
      dshSessionId: 'dsh-fake',
      cwd: root,
      env: {},
      releaseWaitMs: 1,
    })
    const created = await terminals.createTerminal({ sessionId: 'stubborn', command: 'fake' })
    await expect(terminals.releaseTerminal({ sessionId: 'stubborn', terminalId: created.terminalId })).rejects.toThrow(
      'retry release',
    )
    expect(terminateCount).toBe(1)
    await expect(
      terminals.terminalOutput({ sessionId: 'stubborn', terminalId: created.terminalId }),
    ).resolves.toHaveProperty('truncated', false)
  })

  it('does not release a settled command while its provider cannot prove range exit', async () => {
    let observable = false
    let terminations = 0
    const fake: SubprocessSeam = {
      spawn: () => ({
        stdin: new PassThrough(),
        stdout: new PassThrough(),
        stderr: new PassThrough(),
        done: Promise.resolve({ exitCode: 0, signal: null }),
        terminate: () => {
          terminations += 1
        },
        waitForExit: async () => {
          if (!observable) throw new Error('provider unavailable')
          return true
        },
      }),
      resolveExecutable: async (command) => command,
    }
    const terminals = createAcpTerminalHandlers({
      subprocess: fake,
      profileId: 'range',
      dshSessionId: 'dsh-range',
      cwd: root,
      env: {},
      releaseWaitMs: 5,
    })
    const created = await terminals.createTerminal({
      sessionId: 'range-session',
      command: 'fixture',
      args: ['--fixture'],
    })
    await terminals.waitForExit({ sessionId: 'range-session', terminalId: created.terminalId })
    await expect(
      terminals.releaseTerminal({ sessionId: 'range-session', terminalId: created.terminalId }),
    ).rejects.toThrow('retry release')
    expect(terminations).toBe(1)
    await expect(
      terminals.terminalOutput({ sessionId: 'range-session', terminalId: created.terminalId }),
    ).resolves.toHaveProperty('output')
    observable = true
    await expect(
      terminals.releaseTerminal({ sessionId: 'range-session', terminalId: created.terminalId }),
    ).resolves.toEqual({})
    await expect(
      terminals.terminalOutput({ sessionId: 'range-session', terminalId: created.terminalId }),
    ).rejects.toThrow('unknown or already released')
    await terminals.dispose()
  })

  it('falls back to the platform shell for a shell command sent as command with no args', async () => {
    const calls: string[][] = []
    const fake: SubprocessSeam = {
      spawn: ({ argv }) => {
        calls.push([...argv])
        const shell = argv[0] === '/bin/sh' || argv[0] === 'cmd.exe'
        if (!shell) {
          const error = Object.assign(new Error('spawn ENOENT'), { code: 'ENOENT', syscall: 'spawn missing-binary' })
          return {
            stdin: new PassThrough(),
            stdout: new PassThrough(),
            stderr: new PassThrough(),
            done: Promise.reject(error),
            terminate: () => {},
            waitForExit: async () => true,
          }
        }
        return {
          stdin: new PassThrough(),
          stdout: new PassThrough(),
          stderr: new PassThrough(),
          done: Promise.resolve({ exitCode: 0, signal: null }),
          terminate: () => {},
          waitForExit: async () => true,
        }
      },
      resolveExecutable: async (command) => command,
    }
    const terminals = createAcpTerminalHandlers({
      subprocess: fake,
      profileId: 'shell',
      dshSessionId: 'dsh-shell',
      cwd: root,
      env: {},
    })
    const created = await terminals.createTerminal({ sessionId: 'shell-session', command: 'uname -s' })
    await expect(
      terminals.waitForExit({ sessionId: 'shell-session', terminalId: created.terminalId }),
    ).resolves.toMatchObject({ exitCode: 0 })
    expect(calls).toEqual([
      ['uname -s'],
      process.platform === 'win32' ? ['cmd.exe', '/d', '/s', '/c', 'uname -s'] : ['/bin/sh', '-c', 'uname -s'],
    ])
    await terminals.dispose()
  })

  it('never replays a command for a provider file-not-found error', async () => {
    let spawns = 0
    const error = Object.assign(new Error('provider state file not found: ENOENT'), { code: 'ENOENT', syscall: 'open' })
    const terminals = createAcpTerminalHandlers({
      profileId: 'provider-error',
      dshSessionId: 'dsh-provider-error',
      cwd: root,
      env: {},
      subprocess: {
        resolveExecutable: async (command) => command,
        spawn: () => {
          spawns += 1
          return {
            stdin: new PassThrough(),
            stdout: new PassThrough(),
            stderr: new PassThrough(),
            done: Promise.reject(error),
            terminate() {},
            waitForExit: async () => true,
          }
        },
      },
    })
    const created = await terminals.createTerminal({ sessionId: 'provider-error', command: 'echo important' })
    await expect(terminals.waitForExit({ sessionId: 'provider-error', terminalId: created.terminalId })).rejects.toBe(
      error,
    )
    expect(spawns).toBe(1)
    await terminals.dispose()
  })

  it('does not start a shell fallback after cancellation during launch cleanup', async () => {
    let spawns = 0
    const observing = Promise.withResolvers<void>()
    const exited = Promise.withResolvers<boolean>()
    const error = Object.assign(new Error('spawn ENOENT'), { code: 'ENOENT', syscall: 'spawn missing-binary' })
    const terminals = createAcpTerminalHandlers({
      profileId: 'cancel-launch',
      dshSessionId: 'dsh-cancel-launch',
      cwd: root,
      env: {},
      subprocess: {
        resolveExecutable: async (command) => command,
        spawn: () => {
          spawns += 1
          return {
            stdin: new PassThrough(),
            stdout: new PassThrough(),
            stderr: new PassThrough(),
            done: Promise.reject(error),
            terminate() {},
            waitForExit: async () => {
              observing.resolve()
              return exited.promise
            },
          }
        },
      },
    })
    const created = await terminals.createTerminal({ sessionId: 'cancel-launch', command: 'echo important' })
    await observing.promise
    await terminals.killTerminal({ sessionId: 'cancel-launch', terminalId: created.terminalId })
    exited.resolve(true)
    await expect(terminals.waitForExit({ sessionId: 'cancel-launch', terminalId: created.terminalId })).rejects.toBe(
      error,
    )
    expect(spawns).toBe(1)
    await terminals.dispose()
  })

  it('runs a real shell-style command through the shared subprocess seam', async () => {
    const terminals = host()
    const command = process.platform === 'win32' ? 'ver' : 'uname -s'
    const created = await terminals.createTerminal({ sessionId: 'real-shell-session', command })
    await expect(
      terminals.waitForExit({ sessionId: 'real-shell-session', terminalId: created.terminalId }),
    ).resolves.toMatchObject({ exitCode: 0 })
    await expect(
      terminals.terminalOutput({ sessionId: 'real-shell-session', terminalId: created.terminalId }),
    ).resolves.toMatchObject({ output: expect.any(String) })
    await terminals.dispose()
  })

  it('reports a rejected spawn as error instead of a running terminal', async () => {
    const events: unknown[] = []
    const error = Object.assign(new Error('spawn ENOENT'), { code: 'ENOENT', syscall: 'spawn missing-binary' })
    const fake: SubprocessSeam = {
      spawn: () => ({
        stdin: new PassThrough(),
        stdout: new PassThrough(),
        stderr: new PassThrough(),
        done: Promise.reject(error),
        terminate: () => {},
        waitForExit: async () => true,
      }),
      resolveExecutable: async (command) => command,
    }
    const terminals = createAcpTerminalHandlers({
      subprocess: fake,
      profileId: 'error',
      dshSessionId: 'dsh-error',
      cwd: root,
      env: {},
      audit: async (event) => {
        events.push(event)
      },
    })
    const created = await terminals.createTerminal({
      sessionId: 'error-session',
      command: 'missing-binary',
      args: ['--flag'],
    })
    await expect(terminals.waitForExit({ sessionId: 'error-session', terminalId: created.terminalId })).rejects.toThrow(
      'spawn ENOENT',
    )
    await expect(
      terminals.terminalOutput({ sessionId: 'error-session', terminalId: created.terminalId }),
    ).resolves.toMatchObject({ output: '', exitStatus: null })
    expect(events).toContainEqual(expect.objectContaining({ operation: 'exit', outcome: 'error' }))
    await terminals.dispose()
  })
})

describe('ACP terminal native job lifecycle', () => {
  it('checks job admission before spawning a process', async () => {
    let spawned = false
    const terminals = createAcpTerminalHandlers({
      subprocess: {
        ...subprocess,
        spawn: () => {
          spawned = true
          throw new Error('unexpected spawn')
        },
      },
      profileId: 'devin',
      dshSessionId: 'owner',
      cwd: root,
      env: {},
      startJob: () => {
        throw new Error('job limit reached')
      },
    })
    await expect(
      terminals.createTerminal({ sessionId: 'acp', command: process.execPath, args: ['-e', 'process.exit(0)'] }),
    ).rejects.toThrow('job limit reached')
    expect(spawned).toBe(false)
    await terminals.dispose()
  })

  it('keeps the job running until the managed range exits and leaves output readable to ACP', async () => {
    let finishCommand!: (fact: { exitCode: number; signal: null }) => void
    let finishRange!: (value: boolean) => void
    const commandDone = new Promise<{ exitCode: number; signal: null }>((resolve) => {
      finishCommand = resolve
    })
    const rangeDone = new Promise<boolean>((resolve) => {
      finishRange = resolve
    })
    const stdout = new PassThrough()
    const handle: AcpSubprocessHandle = {
      stdin: new PassThrough(),
      stdout,
      stderr: new PassThrough(),
      done: commandDone,
      waitForExit: () => rangeDone,
      terminate() {},
    }
    let hooks!: import('../../../src/runtime/client-capabilities/terminal-job.ts').AcpTerminalJobHooks
    const output: { text: string; channel: 'stdout' | 'stderr' }[] = []
    const terminals = createAcpTerminalHandlers({
      subprocess: { ...subprocess, spawn: () => handle },
      profileId: 'devin',
      dshSessionId: 'owner',
      cwd: root,
      env: {},
      startJob: (_label, run) => {
        hooks = run((text, channel) => output.push({ text, channel }))
        return { cancel: () => hooks.cancel(), release: () => {} }
      },
    })
    const { terminalId } = await terminals.createTerminal({
      sessionId: 'acp',
      command: 'fixture',
      args: ['structured'],
    })
    let settled = false
    void hooks.done.then(() => {
      settled = true
    })
    stdout.write('retained ACP output')
    expect(output).toEqual([{ text: 'retained ACP output', channel: 'stdout' }])
    expect((await terminals.terminalOutput({ sessionId: 'acp', terminalId })).output).toBe('retained ACP output')
    finishCommand({ exitCode: 0, signal: null })
    await terminals.waitForExit({ sessionId: 'acp', terminalId })
    expect(settled).toBe(false)
    stdout.write(' and final chunk')
    finishRange(true)
    await expect(hooks.done).resolves.toEqual({ status: 'completed', detail: 'exit code: 0' })
    expect(output).toEqual([
      { text: 'retained ACP output', channel: 'stdout' },
      { text: ' and final chunk', channel: 'stdout' },
    ])
    expect((await terminals.terminalOutput({ sessionId: 'acp', terminalId })).output).toBe(
      'retained ACP output and final chunk',
    )
    await terminals.dispose()
  })

  it('forwards output emitted inside the admitted starter before it returns', async () => {
    const stdout = new PassThrough()
    const chunks: string[] = []
    let hooks!: import('../../../src/runtime/client-capabilities/terminal-job.ts').AcpTerminalJobHooks
    const terminals = createAcpTerminalHandlers({
      subprocess: {
        ...subprocess,
        spawn: () => ({
          stdin: new Writable({
            final(callback) {
              stdout.write('admitted output')
              callback()
            },
          }),
          stdout,
          stderr: undefined,
          done: Promise.resolve({ exitCode: 0, signal: null }),
          waitForExit: async () => true,
          terminate() {},
        }),
      },
      profileId: 'devin',
      dshSessionId: 'owner',
      cwd: root,
      env: {},
      startJob: (_label, run) => {
        hooks = run((text) => chunks.push(text))
        expect(chunks).toEqual(['admitted output'])
        return { cancel: () => hooks.cancel(), release: () => {} }
      },
    })
    const { terminalId } = await terminals.createTerminal({ sessionId: 'acp', command: 'fixture' })
    await expect(hooks.done).resolves.toMatchObject({ status: 'completed' })
    expect(chunks).toEqual(['admitted output'])
    await expect(terminals.terminalOutput({ sessionId: 'acp', terminalId })).resolves.toHaveProperty(
      'output',
      'admitted output',
    )
    await terminals.dispose()
  })

  it('streams both decoded pipes independently of ACP snapshot reads and its byte limit', async () => {
    const command = Promise.withResolvers<{ exitCode: number; signal: null }>()
    const stdout = new PassThrough()
    const stderr = new PassThrough()
    const chunks: { text: string; channel: 'stdout' | 'stderr' }[] = []
    let hooks!: import('../../../src/runtime/client-capabilities/terminal-job.ts').AcpTerminalJobHooks
    const terminals = createAcpTerminalHandlers({
      subprocess: {
        ...subprocess,
        spawn: () => ({
          stdin: new PassThrough(),
          stdout,
          stderr,
          done: command.promise,
          waitForExit: async () => true,
          terminate() {},
        }),
      },
      profileId: 'devin',
      dshSessionId: 'owner',
      cwd: root,
      env: {},
      startJob: (_label, run) => {
        hooks = run((text, channel) => chunks.push({ text, channel }))
        return { cancel: () => hooks.cancel(), release: () => {} }
      },
    })
    const { terminalId } = await terminals.createTerminal({
      sessionId: 'acp',
      command: 'fixture',
      outputByteLimit: 4,
    })
    stdout.write('prefix|')
    const chinese = Buffer.from('中')
    stdout.write(chinese.subarray(0, 1))
    expect(chunks).toEqual([{ text: 'prefix|', channel: 'stdout' }])
    stdout.write(chinese.subarray(1))
    const emoji = Buffer.from('😀')
    stderr.write(emoji.subarray(0, 2))
    stderr.write(emoji.subarray(2))
    stdout.write('tail')
    expect(chunks).toEqual([
      { text: 'prefix|', channel: 'stdout' },
      { text: '中', channel: 'stdout' },
      { text: '😀', channel: 'stderr' },
      { text: 'tail', channel: 'stdout' },
    ])
    const read = () => terminals.terminalOutput({ sessionId: 'acp', terminalId })
    await expect(read()).resolves.toMatchObject({ output: 'tail', truncated: true, exitStatus: null })
    // A native consumer taking its chunks cannot advance or empty ACP's snapshot.
    chunks.splice(0)
    await expect(read()).resolves.toMatchObject({ output: 'tail', truncated: true })
    stdout.write('last')
    // Even without an end/close event, the terminal outcome flushes the decoder
    // before the job ring settles; otherwise the incomplete last byte is lost.
    stderr.write(Buffer.from([0xe4]))
    command.resolve({ exitCode: 0, signal: null })
    await expect(hooks.done).resolves.toMatchObject({ status: 'completed' })
    expect(chunks).toEqual([
      { text: 'last', channel: 'stdout' },
      { text: '�', channel: 'stderr' },
    ])
    await terminals.dispose()
  })

  it.each(['end', 'close'] as const)('flushes each native decoder once at pipe %s before settlement', async (event) => {
    const command = Promise.withResolvers<{ exitCode: number; signal: null }>()
    const stdout = new PassThrough()
    const chunks: string[] = []
    let hooks!: import('../../../src/runtime/client-capabilities/terminal-job.ts').AcpTerminalJobHooks
    const terminals = createAcpTerminalHandlers({
      subprocess: {
        ...subprocess,
        spawn: () => ({
          stdin: new PassThrough(),
          stdout,
          stderr: undefined,
          done: command.promise,
          waitForExit: async () => true,
          terminate() {},
        }),
      },
      profileId: 'devin',
      dshSessionId: 'owner',
      cwd: root,
      env: {},
      startJob: (_label, run) => {
        hooks = run((text) => chunks.push(text))
        return { cancel: () => hooks.cancel(), release: () => {} }
      },
    })
    const { terminalId } = await terminals.createTerminal({ sessionId: 'acp', command: 'fixture' })
    expect(stdout.listenerCount('data')).toBe(2)
    stdout.write(Buffer.from([0x61, 0xe4]))
    expect(chunks).toEqual(['a'])
    const ended = new Promise<void>((resolve) => stdout.once(event, resolve))
    if (event === 'end') stdout.end()
    else stdout.destroy()
    await ended
    expect(chunks).toEqual(['a', '�'])
    expect(stdout.listenerCount('data')).toBe(1)
    expect(stdout.listenerCount('end')).toBe(0)
    expect(stdout.listenerCount('close')).toBe(0)
    command.resolve({ exitCode: 0, signal: null })
    await expect(hooks.done).resolves.toMatchObject({ status: 'completed' })
    expect(chunks).toEqual(['a', '�'])
    await expect(terminals.terminalOutput({ sessionId: 'acp', terminalId })).resolves.toHaveProperty('output', 'a�')
    await terminals.dispose()
  })

  it('cancels a still-live managed range after its main command already exited', async () => {
    let finishRange!: (value: boolean) => void
    const rangeDone = new Promise<boolean>((resolve) => {
      finishRange = resolve
    })
    let terminated = false
    const handle: AcpSubprocessHandle = {
      stdin: new PassThrough(),
      stdout: new PassThrough(),
      stderr: new PassThrough(),
      done: Promise.resolve({ exitCode: 0, signal: null }),
      waitForExit: () => rangeDone,
      terminate() {
        terminated = true
        finishRange(true)
      },
    }
    let hooks!: import('../../../src/runtime/client-capabilities/terminal-job.ts').AcpTerminalJobHooks
    const terminals = createAcpTerminalHandlers({
      subprocess: { ...subprocess, spawn: () => handle },
      profileId: 'devin',
      dshSessionId: 'owner',
      cwd: root,
      env: {},
      startJob: (_label, run) => {
        hooks = run(() => {})
        return { cancel: () => hooks.cancel(), release: () => {} }
      },
    })
    const { terminalId } = await terminals.createTerminal({
      sessionId: 'acp',
      command: 'fixture',
      args: ['structured'],
    })
    await terminals.waitForExit({ sessionId: 'acp', terminalId })
    terminals.cancelSession?.('acp')
    await expect(hooks.done).resolves.toMatchObject({ status: 'killed' })
    expect(terminated).toBe(true)
    await terminals.dispose()
  })

  it('settles a native job within the cleanup budget when range observation never settles', async () => {
    const neverExits = new Promise<boolean>(() => {})
    let rangeExited = false
    const handle: AcpSubprocessHandle = {
      stdin: new PassThrough(),
      stdout: new PassThrough(),
      stderr: new PassThrough(),
      done: Promise.resolve({ exitCode: 0, signal: null }),
      waitForExit: async () => (rangeExited ? true : await neverExits),
      terminate() {},
    }
    let hooks!: import('../../../src/runtime/client-capabilities/terminal-job.ts').AcpTerminalJobHooks
    let activeJobs = 0
    const terminals = createAcpTerminalHandlers({
      subprocess: { ...subprocess, spawn: () => handle },
      profileId: 'devin',
      dshSessionId: 'owner',
      cwd: root,
      env: {},
      releaseWaitMs: 20,
      startJob: (_label, run) => {
        hooks = run(() => {})
        activeJobs += 1
        void hooks.done.finally(() => {
          activeJobs -= 1
        })
        return { cancel: () => hooks.cancel(), release: () => {} }
      },
    })
    const { terminalId } = await terminals.createTerminal({ sessionId: 'acp', command: 'fixture' })

    const started = Date.now()
    await expect(hooks.done).resolves.toMatchObject({
      status: 'failed',
      detail: expect.stringContaining('cleanup remains unconfirmed'),
    })
    expect(Date.now() - started).toBeLessThan(500)
    await Promise.resolve()
    expect(activeJobs).toBe(0)
    // The job registry slot settles, but the ACP terminal ID remains usable
    // until a later release can prove the provider-owned range is gone.
    await expect(terminals.terminalOutput({ sessionId: 'acp', terminalId })).resolves.toHaveProperty('output')
    await expect(terminals.releaseTerminal({ sessionId: 'acp', terminalId })).rejects.toThrow('retry release')
    rangeExited = true
    await expect(terminals.releaseTerminal({ sessionId: 'acp', terminalId })).resolves.toEqual({})
    await expect(terminals.terminalOutput({ sessionId: 'acp', terminalId })).rejects.toThrow(
      'unknown or already released',
    )
    await terminals.dispose()
  })

  it('cleans up terminals when the native owner cancels and preserves the killed result on release', async () => {
    let hooks!: import('../../../src/runtime/client-capabilities/terminal-job.ts').AcpTerminalJobHooks
    const terminals = createAcpTerminalHandlers({
      subprocess,
      profileId: 'devin',
      dshSessionId: 'owner',
      cwd: root,
      env: {},
      startJob: (_label, run) => {
        hooks = run(() => {})
        return { cancel: () => hooks.cancel(), release: () => {} }
      },
    })
    try {
      const { terminalId } = await terminals.createTerminal({
        sessionId: 'acp',
        command: process.execPath,
        args: ['-e', 'console.log("ready");setInterval(()=>{},1000)'],
      })
      await expect
        .poll(async () => (await terminals.terminalOutput({ sessionId: 'acp', terminalId })).output)
        .toContain('ready')
      hooks.cancel()
      await expect(hooks.done).resolves.toMatchObject({ status: 'killed' })
      await terminals.releaseTerminal({ sessionId: 'acp', terminalId })
      await expect(hooks.done).resolves.toMatchObject({ status: 'killed' })
    } finally {
      await terminals.dispose()
    }
  })
})
