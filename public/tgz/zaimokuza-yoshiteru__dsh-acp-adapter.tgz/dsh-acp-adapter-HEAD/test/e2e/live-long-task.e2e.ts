import { createHash, createHmac, randomBytes, randomUUID } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { appendFileSync, chmodSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import type { SessionId, SessionEvent } from '@deepseek-ai/dsh-session'
import type { RequestPermissionRequest } from '@agentclientprotocol/sdk'
import type { AcpNativeUserQuestionService } from '../../src/domain/policy/elicitation.ts'
import { summarizeRawInputForAudit } from '../../src/domain/policy/events.ts'
import { acpPermissionAudit } from './acp-permission-audit.ts'
import { permitsTeamReviewTool } from './live-long-task-team-scope.ts'
import type { GenerateOptions } from '@deepseek-ai/dsh-llm'
import type { Page } from 'playwright'
import { describe, expect, it, vi } from 'vitest'
import { connectFreshWorkspace, writeComposerDraft } from '#host-support'
import type { TestBrowser } from './browser.ts'
import { launchBrowser, newEnglishPage } from './browser.ts'
import { required } from './required.ts'
import { observeLiveExternalApprovals, type ExternalApprovalObservation } from './live-external-approval-observer.ts'
import { launchAdapterWorld, root } from './scaffold.ts'
import type { AdapterWorld } from './scaffold.ts'
import type { LongTaskBudget, LongTaskScene } from './live-long-task-budget.ts'
import {
  admitLongTaskTool,
  createLongTaskBudget,
  LONG_TASK_BUDGET,
  longTaskEffectFingerprint,
  observeLongTaskProviderToolCall,
  recordLongTaskApprovalRequest,
  recordLongTaskToolResult,
} from './live-long-task-budget.ts'
import { createNativeReadObserver, wrapObservedCallback } from './live-long-task-native-read.ts'
import type { NativeReadDiagnostic, NativeReadEvidence, NativeReadSource } from './live-long-task-native-read.ts'
import {
  classifyExecutionRoute,
  createNativeExecuteObserver,
  nativeExecuteRefusalResponse,
} from './live-long-task-native-execute.ts'
import { isMemberApprovalCoordination, memberCoordinationArguments } from './live-long-task-coordination.ts'
import type { ExecuteRegistration, ExecutionRoute } from './live-long-task-native-execute.ts'
import {
  confirmsRejectedCancellation,
  leadControlClaimMarker,
  type RejectedCancellationExpectation,
  type RejectedCancellationFacts,
} from './live-long-task-rejection-cancel.ts'
import type { LiveDiagnosticEvent, LiveDiagnosticTraceSink } from '../../src/contract/live-diagnostic-trace.ts'
import type { AcpRemoteService } from '../../src/remote/service.js'
import { waitForLongTask } from './live-long-task-wait.ts'
import {
  finalLongTaskFailure,
  longTaskFailure,
  longTaskOutcome,
  settleLongTaskAction,
} from './live-long-task-lifecycle.ts'
import type { LongTaskFailure, LongTaskSettlement } from './live-long-task-lifecycle.ts'

const SOURCE_COMMIT = '639ed015397290b3745d163aafe02ffee4aa3f84'
const UPSTREAM = process.env.DSH_UPSTREAM_CHECKOUT ?? resolve(root, '../reference/deepseek-harness')
const SOURCE_FILES = [
  'packages/core/agent-loop/src/inbox.ts',
  'packages/core/agent-loop/src/runtime-context.ts',
  'packages/core/agent-loop/src/tool-calls.ts',
  'packages/experimental/agent-team/src/mailbox.ts',
  'packages/experimental/agent-team/src/task-board.ts',
  'packages/experimental/agent-team/src/types.ts',
] as const
const SOURCE_MAX_BYTES = 64 * 1024

const agentProfiles = {
  devin: {
    id: 'devin',
    provider: 'acp-devin',
    command: 'devin',
    args: ['acp'],
    model: 'swe-2-high',
    versionArgs: ['--version'],
  },
  codebuddy: {
    id: 'codebuddy-code',
    provider: 'acp-codebuddy-code',
    command: 'codebuddy',
    args: ['--acp'],
    model: 'minimax-m2.7',
    versionArgs: ['--version'],
    runtime: 'codebuddy',
    catalogId: 'codebuddy-code',
  },
} as const
type ProfileName = keyof typeof agentProfiles
type ScenarioSelection = 'all' | 'teams' | 'teams-only' | 'controls' | 'approvals' | 'stop-only'

function selectedScenarios(): ScenarioSelection {
  const selected = process.env.DSH_E2E_LIVE_LONG_TASK_SCENARIOS ?? 'all'
  if (
    selected !== 'all' &&
    selected !== 'teams' &&
    selected !== 'teams-only' &&
    selected !== 'controls' &&
    selected !== 'approvals' &&
    selected !== 'stop-only'
  )
    throw new Error(
      'DSH_E2E_LIVE_LONG_TASK_SCENARIOS must be all, teams, teams-only, controls, approvals, or stop-only',
    )
  return selected
}

type SessionEventRow = (SessionEvent | ExternalApprovalObservation) & { readonly sessionId: SessionId }
function isApprovalAsked(
  event: SessionEventRow | undefined,
): event is Extract<SessionEventRow, { type: 'approval/asked' | 'acp-approval/asked' }> {
  return event?.type === 'approval/asked' || event?.type === 'acp-approval/asked'
}
function isApprovalDecided(
  event: SessionEventRow | undefined,
): event is Extract<SessionEventRow, { type: 'approval/decided' | 'acp-approval/decided' }> {
  return event?.type === 'approval/decided' || event?.type === 'acp-approval/decided'
}
type ToolEvidence = {
  readonly name: string
  readonly session: string
  readonly callId: string
  readonly isError: boolean
  readonly eventCount: number
  readonly taskId?: string
  readonly readPath?: string
  readonly readOffset?: number
  readonly readLimit?: number
  readonly readLines?: number
  readonly operationId?: string
  readonly assignment?: {
    readonly descriptionIdentity: string
    readonly sourcePaths: readonly string[]
    readonly reportMarkers: readonly string[]
    readonly requiresRead: boolean
    readonly requiresOwnDiscovery: boolean
  }
}
type RuntimePrompt = (
  this: {
    readonly acpSessionId?: string
    readonly configOptions?: readonly {
      readonly type: string
      readonly id?: string
      readonly category?: string
      readonly currentValue?: string
    }[]
    readonly options: { readonly diagnosticDshSessionId?: string }
  },
  ...args: unknown[]
) => unknown
type NativeRuntimeModule = { AcpSessionRuntime: { prototype: { prompt: RuntimePrompt } } }
type NativeDiagnosticModule = {
  installLiveDiagnosticTrace: (sink: LiveDiagnosticTraceSink) => () => void
  liveDiagnosticTraceFailureCount: () => number
  liveDiagnosticTraceEnabled: () => boolean
  liveDiagnosticId: (kind: string, value: unknown) => string | undefined
}

type PromptTrace = {
  readonly scene: LongTaskScene
  readonly phase: string
  readonly owner: string
  readonly acpSession: string
  readonly signal?: AbortSignal
  promptOrdinal?: number
  leaseId?: string
  stopReason?: string
  signalAbortedAtEnd?: boolean
}

type RejectedCancellationState = {
  readonly expected: RejectedCancellationExpectation
  readonly prompt: PromptTrace
  readonly requestIdRaw: string
  readonly requestEventIndex: number
  readonly destination: string
  turnEndEventIndex?: number
  permissionResponse?: {
    readonly callId: string
    readonly outcome: string
    readonly optionKind: string
    readonly signalAborted: boolean
    readonly responseCount: number
  }
  confirmed: boolean
  consumed: boolean
}

function explicitProfile(): ProfileName {
  const name = process.env.DSH_E2E_LIVE_LONG_TASK_PROFILE
  if (name !== 'devin' && name !== 'codebuddy')
    throw new Error('Set DSH_E2E_LIVE_LONG_TASK_PROFILE to devin or codebuddy')
  return name
}

function writePrivate(path: string, value: string): void {
  writeFileSync(path, value, { mode: 0o600 })
  chmodSync(path, 0o600)
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function abortSignalLike(value: unknown): AbortSignal | undefined {
  if (!isRecord(value) || typeof value.aborted !== 'boolean') return undefined
  return value as unknown as AbortSignal
}

function sourcePathFor(workspace: string, path: string): string {
  return join(workspace, 'public-dsh-source', ...path.split('/'))
}

function exportPinnedSource(workspace: string): {
  files: { path: string; bytes: number; sha256: string }[]
  totalBytes: number
} {
  const resolvedCommit = execFileSync('git', ['-C', UPSTREAM, 'rev-parse', `${SOURCE_COMMIT}^{commit}`], {
    encoding: 'utf8',
  }).trim()
  if (resolvedCommit !== SOURCE_COMMIT) throw new Error('LONG_TASK_SOURCE_COMMIT_MISMATCH')
  const files: { path: string; bytes: number; sha256: string }[] = []
  for (const relative of SOURCE_FILES) {
    const source = execFileSync('git', ['-C', UPSTREAM, 'show', `${SOURCE_COMMIT}:${relative}`], {
      maxBuffer: SOURCE_MAX_BYTES,
    })
    const destination = sourcePathFor(workspace, relative)
    mkdirSync(join(destination, '..'), { recursive: true })
    writeFileSync(destination, source, { mode: 0o444 })
    chmodSync(destination, 0o444)
    files.push({
      path: relative,
      bytes: source.byteLength,
      sha256: createHash('sha256').update(source).digest('hex'),
    })
  }
  const totalBytes = files.reduce((sum, file) => sum + file.bytes, 0)
  if (totalBytes > SOURCE_MAX_BYTES) throw new Error('LONG_TASK_SOURCE_INPUT_BUDGET')
  return { files, totalBytes }
}

function diagnosticSink(secret: Buffer, onEvent: (event: LiveDiagnosticEvent) => void): LiveDiagnosticTraceSink {
  const id = (kind: string, value: unknown): string => {
    const encoded = `${kind}\0${JSON.stringify(value)}`
    return `h:${createHmac('sha256', secret).update(encoded).digest('hex').slice(0, 24)}`
  }
  const fingerprint = (kind: string, value: unknown) => {
    const encoded = JSON.stringify(value)
    const bytes = Buffer.byteLength(encoded ?? '')
    return { hmac: id(kind, value), bytes, complete: true }
  }
  return Object.assign((event: LiveDiagnosticEvent) => onEvent(event), { id, fingerprint })
}

describe.skipIf(process.env.DSH_E2E_LIVE_LONG_TASK !== '1')('opt-in live ACP long-task regression', () => {
  it(
    'runs source reading, Teams, Ask, and cancellation scenarios for one exact Agent/model',
    async () => {
      const profileName = explicitProfile()
      const scenarios = selectedScenarios()
      const profile = agentProfiles[profileName]
      const runId = randomUUID()
      const evidenceDir = join(root, '.local', 'live-long-task', profileName, runId)
      mkdirSync(evidenceDir, { recursive: true, mode: 0o700 })
      chmodSync(evidenceDir, 0o700)
      const tracePath = join(evidenceDir, 'trace.jsonl')
      writePrivate(tracePath, '')
      let host!: AdapterWorld
      let browser: TestBrowser | undefined
      let page: Page | undefined
      let removeTrace: (() => void) | undefined
      let restoreRuntimePrompt: (() => void) | undefined
      const restoreRuntimePermissionHandlers: Array<() => void> = []
      const wrappedPermissionOptions = new WeakSet<object>()
      const bPermissionRequests = new Map<string, RequestPermissionRequest>()
      const bQuestionViews = new Map<string, Parameters<AcpNativeUserQuestionService['ask']>[0]>()
      const bPermissionEvidence: Record<string, unknown>[] = []
      const countedApprovalRequests = new Set<string>()
      const answeredBPermissions = new Set<string>()
      let restoreBQuestionObserver: (() => void) | undefined
      let answerBPermissions: (() => Promise<void>) | undefined
      let removeJobEvents: (() => void) | undefined
      let runtimePromptChecks = 0
      let nativeTraceEvents = 0
      let nativeDiagnosticModule: NativeDiagnosticModule | undefined
      let primaryFailure: unknown
      let primaryFailureRecord: LongTaskFailure | undefined
      let evidenceFailure: unknown
      const evidenceOutcomes: LongTaskSettlement[] = []
      const recordEvidenceFailure = (owner: string, error: unknown): void => {
        evidenceFailure ??= error
        const outcome: LongTaskSettlement = { owner, status: 'rejected', failure: longTaskFailure(error, activePhase) }
        evidenceOutcomes.push(outcome)
        console.error(JSON.stringify({ longTaskEvidenceFailure: outcome }))
      }
      let nativeReadSources: NativeReadSource[] = []
      const nativeReadEvidence: (NativeReadEvidence & { readonly scene: LongTaskScene })[] = []
      const nativeReadDiagnostics: (NativeReadDiagnostic & {
        readonly scene: LongTaskScene
        readonly phase: string
      })[] = []
      let completedRunRecord: Record<string, unknown> | undefined
      let runFailed = false
      let leadSessionId: SessionId | undefined
      let leadAgent: ReturnType<AdapterWorld['ctx']['agents']['get']> | undefined
      let activeScene: LongTaskScene = 'A'
      let sceneStartedAt = Date.now()
      let activePhase = 'setup'
      let phaseDeadlineAt = Date.now() + LONG_TASK_BUDGET.phaseMs
      const startedAt = Date.now()
      const budget: LongTaskBudget = createLongTaskBudget(startedAt)
      const scenarioStatuses: Record<'A' | 'B' | 'C' | 'D', 'pending' | 'passed' | 'partial' | 'not-run'> = {
        A: scenarios === 'all' ? 'pending' : 'not-run',
        B: scenarios === 'controls' || scenarios === 'approvals' || scenarios === 'stop-only' ? 'not-run' : 'pending',
        C: scenarios === 'stop-only' || scenarios === 'teams-only' ? 'not-run' : 'pending',
        D: scenarios === 'teams-only' ? 'not-run' : 'pending',
      }
      let runtimeReaderId: SessionId | undefined
      const events: SessionEventRow[] = []
      const tools: ToolEvidence[] = []
      const operationAdmissions = new Map<string, number>()
      const eventChangeWaiters = new Set<(failure?: Error) => void>()
      const jobEvidence: {
        readonly event: 'registered' | 'stopping' | 'settled' | 'removed'
        readonly id: string
        readonly owner?: string
        readonly kind: string
        readonly status: string
        readonly startedAt: number
        readonly finishedAt?: number
        readonly cause?: string
        readonly awaited?: boolean
        readonly label: string
      }[] = []
      let registeredLongCommand: string | undefined
      let dJobQuiescence: 'host-job-settlement' | 'unknown' = 'unknown'
      let dExecutionRoute: ExecutionRoute = 'unknown'
      const dJobSettled = (): boolean => dJobQuiescence === 'host-job-settlement'
      const dUsesHostTool = (): boolean => dExecutionRoute === 'host-tool'
      const pendingScreenshotPromises = new Set<Promise<void>>()
      const screenshotFailures: string[] = []
      const approvals: { scene: LongTaskScene; session: string; outcome: string }[] = []
      const approvalEvidence: {
        operation: string
        session: string
        request: string
        requestEventIndex: number
        toolName: string
        outcome: string
        auditOwner: 'native-session' | 'acp-sidecar'
        permissionRoute?: 'host-approval' | 'native-permission' | 'both' | 'team-coordination'
      }[] = []
      const operationPermissionRoutes = new Map<
        string,
        'host-approval' | 'native-permission' | 'both' | 'team-coordination'
      >()
      const operationExecutionRoutes = new Map<string, ExecutionRoute>()
      const teamMessages: {
        scene: LongTaskScene
        session: string
        type: string
        eventIndex: number
        messageId?: string
        targetId?: string
        senderId?: string
        reportMarker?: string
      }[] = []
      const teamReceipts: {
        scene: LongTaskScene
        session: string
        messageId: string
        senderId: string
        reportMarker?: string
        eventIndex: number
        seq: number
      }[] = []
      const memberSessionIds = new Set<string>()
      const teamMemberFacts: { id: string; name: string; role: string }[] = []
      const turns: { scene: LongTaskScene; session: string; turn?: number; reason: string }[] = []
      const claimedTurnByMarker = new Map<string, number>()
      const answers: { scene: LongTaskScene; session: string; text: string; eventIndex: number }[] = []
      const errorTexts: string[] = []
      let stickyViolation: string | undefined
      let expectingDStop = false
      let expectedDAbortTurn: number | undefined
      let cancelPromise: Promise<void> | undefined
      const cancellationOutcomes: LongTaskSettlement[] = []
      const failureController = new AbortController()
      const modeBySession = new Map<string, string | null>()

      const cancelAll = (reason: string): Promise<void> => {
        if (cancelPromise !== undefined) return cancelPromise
        cancelPromise = (async () => {
          const enumeration = await settleLongTaskAction(
            'agent-enumeration',
            async () => {
              const agents = (host?.ctx.agents.list() ?? []).filter(
                (agent) => agent.options.provider === profile.provider,
              )
              cancellationOutcomes.push(
                ...(await Promise.all(
                  agents.map((agent) =>
                    settleLongTaskAction(
                      safeId(String(agent.id)),
                      () => agent.cancel({ kind: 'hook', reason }, { keepInbox: true }),
                      'cancel',
                    ),
                  ),
                )),
              )
            },
            'cancel',
          )
          if (enumeration.status === 'rejected') cancellationOutcomes.push(enumeration)
        })()
        return cancelPromise
      }

      const violate = (reason: string): void => {
        if (stickyViolation !== undefined) return
        stickyViolation = reason
        budget.violation ??= reason
        failureController.abort(new Error(reason))
        for (const waiter of [...eventChangeWaiters]) waiter(new Error(reason))
        queueMicrotask(() => void cancelAll(reason))
      }

      const assertHealthy = (): void => {
        if (stickyViolation !== undefined) throw new Error(stickyViolation)
        if (failureController.signal.aborted) throw failureController.signal.reason
        if (screenshotFailures.length > 0) {
          violate('LONG_TASK_SCREENSHOT_FAILURE')
          throw new Error('LONG_TASK_SCREENSHOT_FAILURE')
        }
        if (errorTexts.length > 0) {
          violate('LONG_TASK_PAGE_ERROR')
          throw new Error('LONG_TASK_PAGE_ERROR')
        }
        if ((nativeDiagnosticModule?.liveDiagnosticTraceFailureCount() ?? 0) > 0) {
          violate('LONG_TASK_DIAGNOSTIC_TRACE_FAILURE')
          throw new Error('LONG_TASK_DIAGNOSTIC_TRACE_FAILURE')
        }
        if (Date.now() - startedAt >= LONG_TASK_BUDGET.totalMs) {
          violate('LONG_TASK_TOTAL_DEADLINE')
          throw new Error('LONG_TASK_TOTAL_DEADLINE')
        }
        if (Date.now() - sceneStartedAt >= LONG_TASK_BUDGET.sceneMs) {
          violate(`LONG_TASK_SCENE_DEADLINE_${activeScene}`)
          throw new Error(`LONG_TASK_SCENE_DEADLINE_${activeScene}`)
        }
        if (Date.now() >= phaseDeadlineAt) {
          violate(`LONG_TASK_PHASE_DEADLINE_${activePhase}`)
          throw new Error(`LONG_TASK_PHASE_DEADLINE_${activePhase}`)
        }
      }

      const waitFor = <T>(
        action: () => T | Promise<T>,
        options?: { timeout?: number; interval?: number },
      ): Promise<T> =>
        waitForLongTask(action, {
          timeout: options?.timeout ?? Math.max(1, phaseDeadlineAt - Date.now()),
          interval: options?.interval ?? 100,
          checkHealth: assertHealthy,
          signal: failureController.signal,
        })

      const waitForEventChange = (): Promise<void> =>
        new Promise((resolve, reject) => {
          assertHealthy()
          let timer: ReturnType<typeof setTimeout> | undefined
          const waiter = (failure?: Error): void => {
            eventChangeWaiters.delete(waiter)
            if (timer !== undefined) clearTimeout(timer)
            if (failure === undefined) resolve()
            else reject(failure)
          }
          eventChangeWaiters.add(waiter)
          timer = setTimeout(
            () => {
              eventChangeWaiters.delete(waiter)
              try {
                assertHealthy()
                reject(new Error('LONG_TASK_EVENT_WAIT_TIMEOUT'))
              } catch (error: unknown) {
                reject(error)
              }
            },
            Math.max(1, phaseDeadlineAt - Date.now()),
          )
        })

      const withPhase = async <T>(
        phase: string,
        action: () => Promise<T>,
        phaseTimeoutMs: number = LONG_TASK_BUDGET.phaseMs,
      ): Promise<T> => {
        activePhase = phase
        phaseDeadlineAt = Math.min(
          Date.now() + phaseTimeoutMs,
          sceneStartedAt + LONG_TASK_BUDGET.sceneMs,
          startedAt + LONG_TASK_BUDGET.totalMs,
        )
        assertHealthy()
        let timer: ReturnType<typeof setTimeout> | undefined
        let removeFailureListener = (): void => {}
        let pumping = true
        const permissions = phase.startsWith('B:')
          ? (async () => {
              try {
                while (pumping) {
                  assertHealthy()
                  await required(answerBPermissions, 'B permission responder must be installed')()
                  await new Promise<void>((resolve) => setTimeout(resolve, 50))
                }
              } catch (error: unknown) {
                violate('LONG_TASK_B_PERMISSION_RESPONSE_FAILED')
                throw error
              }
            })()
          : undefined
        try {
          return await Promise.race([
            ...(permissions === undefined ? [] : [permissions.then(() => new Promise<never>(() => {}))]),
            new Promise<never>((_, reject) => {
              const failed = (): void => reject(failureController.signal.reason)
              failureController.signal.addEventListener('abort', failed, { once: true })
              removeFailureListener = () => failureController.signal.removeEventListener('abort', failed)
              if (failureController.signal.aborted) failed()
            }),
            Promise.resolve().then(() => {
              assertHealthy()
              return action()
            }),
            new Promise<never>((_, reject) => {
              timer = setTimeout(
                () => {
                  const failure = stickyViolation ?? `LONG_TASK_PHASE_DEADLINE_${phase}`
                  violate(failure)
                  reject(new Error(failure))
                },
                Math.max(0, phaseDeadlineAt - Date.now()),
              )
            }),
          ])
        } finally {
          pumping = false
          if (timer !== undefined) clearTimeout(timer)
          removeFailureListener()
          await permissions?.catch(() => {})
        }
      }

      const capture = async (
        scene: LongTaskScene,
        stage: string,
        facts: Record<string, unknown> = {},
      ): Promise<void> => {
        if (page === undefined) return
        await page.screenshot({ path: join(evidenceDir, `${scene}-${stage}.png`), fullPage: true })
        writePrivate(
          join(evidenceDir, `${scene}-${stage}.json`),
          JSON.stringify(
            {
              runId,
              agent: profileName,
              model: profile.model,
              scene,
              stage,
              elapsedMs: Date.now() - startedAt,
              hostDispatches: budget.totalDispatches,
              sceneDispatches: budget.sceneDispatches[scene],
              approvalRequests: budget.approvalRequests,
              providerToolCalls: budget.providerToolCallIds.size,
              jobs: jobSnapshot(),
              ...facts,
            },
            null,
            2,
          ),
        )
      }

      const scheduleCapture = (scene: LongTaskScene, stage: string, facts: Record<string, unknown>): void => {
        let task!: Promise<void>
        task = capture(scene, stage, facts)
          .catch((error: unknown) => {
            screenshotFailures.push(error instanceof Error ? error.name : 'UnknownError')
          })
          .finally(() => pendingScreenshotPromises.delete(task))
        pendingScreenshotPromises.add(task)
      }

      const checkModelSnapshot = async (sessionId: string, source: string): Promise<void> => {
        const service = host.ctx.get('dshAcp') as AcpRemoteService
        const snapshot = await service.agentSessionSnapshot(sessionId)
        const option = snapshot.configOptions?.find(
          (candidate) => candidate.type === 'select' && (candidate.category === 'model' || candidate.id === 'model'),
        )
        if (snapshot.freshness !== 'live' || option?.type !== 'select') {
          throw new Error(`LONG_TASK_MODEL_SNAPSHOT_UNAVAILABLE:${source}:${snapshot.freshness}`)
        }
        if (option.currentValue !== profile.model) {
          throw new Error(`LONG_TASK_MODEL_SNAPSHOT_MISMATCH:${source}`)
        }
        const hasPreviousMode = modeBySession.has(sessionId)
        const modePreserved = hasPreviousMode && modeBySession.get(sessionId) === snapshot.currentModeId
        modeBySession.set(sessionId, snapshot.currentModeId)
        modelSnapshots.push({
          source,
          session: safeId(sessionId),
          freshness: snapshot.freshness,
          model: option.currentValue,
          modeObserved: snapshot.currentModeId !== null,
          ...(hasPreviousMode ? { modePreserved } : {}),
        })
      }
      const modelSnapshots: {
        source: string
        session: string
        freshness: string
        model: string
        modeObserved: boolean
        modePreserved?: boolean
      }[] = []

      const addEvent = (sessionId: SessionId, event: SessionEvent | ExternalApprovalObservation): void => {
        events.push({ sessionId, ...event })
        for (const waiter of [...eventChangeWaiters]) waiter()
        const scope = String(sessionId)
        const scene = activeScene
        if (
          event.type === 'user/message' &&
          scene === 'B' &&
          leadSessionId === undefined &&
          JSON.stringify(event.data.content).includes(`LONGTASK_B_${runId.slice(0, 8)}`)
        ) {
          leadSessionId = sessionId
          leadAgent = host.ctx.agents.get(sessionId)
        }
        if (event.type === 'turn/end') {
          turns.push({
            scene,
            session: safeId(scope),
            ...('turn' in event.data && typeof event.data.turn === 'number' ? { turn: event.data.turn } : {}),
            reason: event.data.reason.kind,
          })
          let acceptedRejectedCancellation = false
          const cancelState = rejectionCancellation
          if (
            event.data.reason.kind === 'aborted' &&
            cancelState !== undefined &&
            !cancelState.consumed &&
            'turn' in event.data
          ) {
            const nativeCalls = nativeExecuteObserver
              .evidence()
              .filter((entry) => entry.scene === 'C' && entry.operation === cancelState.expected.operation)
            const permission = cancelState.permissionResponse
            const decisionRow = events.find(
              (candidate, index) =>
                index > cancelState.requestEventIndex &&
                isApprovalDecided(candidate) &&
                candidate.sessionId === sessionId &&
                candidate.data.id === cancelState.requestIdRaw,
            )
            const facts: RejectedCancellationFacts = {
              profile: profileName,
              scene,
              phase: activePhase,
              operation: cancelState.expected.operation,
              owner: nativeDiagnosticModule?.liveDiagnosticId('dsh-session', String(sessionId)) ?? 'unavailable',
              acpSession: cancelState.prompt.acpSession,
              requestId: safeId(`approval-request:${cancelState.requestIdRaw}`),
              decidedOutcome: isApprovalDecided(decisionRow) ? decisionRow.data.outcome : '',
              promptOrdinal: cancelState.prompt.promptOrdinal ?? -1,
              leaseId: cancelState.prompt.leaseId ?? '',
              stopReason: cancelState.prompt.stopReason ?? 'unknown',
              promptSignalAbortedAtEnd: cancelState.prompt.signalAbortedAtEnd ?? true,
              permissionCallId: permission?.callId ?? '',
              permissionOutcome: permission?.outcome ?? 'unknown',
              permissionOptionKind: permission?.optionKind ?? 'unknown',
              permissionResponses: permission?.responseCount ?? 0,
              permissionSignalAbortedAtReturn: permission?.signalAborted ?? true,
              nativeCalls: nativeCalls.map((entry) => ({ callId: entry.callId, status: entry.status })),
              turn: event.data.turn,
              turnReason: event.data.reason.kind,
              hostAdmissions: operationAdmissions.get(cancelState.expected.operation) ?? 0,
              hostResults: tools.filter((tool) => tool.operationId === cancelState.expected.operation).length,
              fileExists: existsSync(cancelState.destination),
              localStop: expectingDStop,
              guardCancelled:
                stickyViolation !== undefined || budget.violation !== undefined || cancelPromise !== undefined,
            }
            acceptedRejectedCancellation = confirmsRejectedCancellation(cancelState.expected, facts)
            if (acceptedRejectedCancellation) {
              cancelState.confirmed = true
              cancelState.consumed = true
              cancelState.turnEndEventIndex = events.length - 1
              rejectionCancellationEvidence.push({
                status: 'confirmed-remote-rejected-cancellation',
                operation: cancelState.expected.operation,
                owner: cancelState.expected.owner,
                acpSession: cancelState.expected.acpSession,
                request: cancelState.expected.requestId,
                promptOrdinal: cancelState.expected.promptOrdinal,
                leaseId: cancelState.expected.leaseId,
                nativeCall: cancelState.expected.callId,
                nativeStatus: nativeCalls[0]?.status ?? 'unknown',
                turn: event.data.turn,
                turnEndEventIndex: events.length - 1,
              })
            }
          }
          if (
            event.data.reason.kind !== 'completed' &&
            !acceptedRejectedCancellation &&
            !(
              scene === 'D' &&
              expectingDStop &&
              String(sessionId) === String(leadSessionId) &&
              event.data.reason.kind === 'aborted' &&
              'turn' in event.data &&
              event.data.turn === expectedDAbortTurn
            )
          )
            violate(`LONG_TASK_UNEXPECTED_TURN_END_${event.data.reason.kind}`)
        }
        if (event.type.startsWith('error/')) violate('LONG_TASK_SESSION_ERROR_EVENT')
        if (event.type === 'assistant/message') {
          const text = event.data.message.content
            .filter((block) => block.type === 'text')
            .map((block) => block.text)
            .join('')
          if (text.length > 0) answers.push({ scene, session: safeId(scope), text, eventIndex: events.length - 1 })
        }
        if (event.type === 'approval/asked' || event.type === 'acp-approval/asked') {
          const key = `${scope}:${event.data.id}`
          if (!countedApprovalRequests.has(key)) {
            countedApprovalRequests.add(key)
            const violation = recordLongTaskApprovalRequest(budget, scene)
            if (violation !== undefined) violate(violation)
          }
        }
        if (event.type === 'approval/decided' || event.type === 'acp-approval/decided') {
          approvals.push({ scene, session: safeId(scope), outcome: event.data.outcome })
        }
        // Inbox acceptance and later user/message admission are distinct native
        // facts. Neither a send tool result nor acceptance proves model processing.
        if (event.type === 'agent/inbox/spliced') {
          for (const message of event.data.inserted) {
            const source = message.source
            if (source.kind !== 'agent-message' || source.form !== 'relay') continue
            teamMessages.push({
              scene,
              session: safeId(scope),
              type: event.type,
              eventIndex: events.length - 1,
              messageId: message.id,
              targetId: scope,
              senderId: source.senderSessionId,
              reportMarker: ['B_REPORT_RUNTIME', 'B_REPORT_TEAMS'].find((marker) =>
                message.content.some(
                  (block) => block.type === 'text' && block.text.includes(`${marker}_${runId.slice(0, 8)}`),
                ),
              ),
            })
          }
        }
        if (event.type === 'user/message') {
          const source = event.data.source
          if (source.kind === 'agent-message' && source.form === 'relay')
            teamReceipts.push({
              scene,
              session: safeId(scope),
              messageId: event.data.id,
              senderId: source.senderSessionId,
              reportMarker: ['B_REPORT_RUNTIME', 'B_REPORT_TEAMS'].find((marker) =>
                event.data.content.some(
                  (block) => block.type === 'text' && block.text.includes(`${marker}_${runId.slice(0, 8)}`),
                ),
              ),
              eventIndex: events.length - 1,
              seq: event.seq,
            })
        }
      }

      const safeId = (value: string): string => createHmac('sha256', runSecret).update(value).digest('hex').slice(0, 24)
      const runSecret = randomBytes(32)
      const safeJobView = (job: {
        readonly id: string
        readonly owner?: string
        readonly kind: string
        readonly status: string
        readonly startedAt: number
        readonly finishedAt?: number
      }) => ({
        id: safeId(`job:${job.id}`),
        ...(job.owner === undefined ? {} : { owner: safeId(`dsh-session:${job.owner}`) }),
        kind: job.kind,
        status: job.status,
        startedAt: job.startedAt,
        ...(job.finishedAt === undefined ? {} : { finishedAt: job.finishedAt }),
      })
      const jobSnapshot = () => {
        if (leadSessionId === undefined)
          return { visibleJobs: [], exactCommandJobCount: 0, exactCommandActiveCount: 0, otherLiveJobCount: 0 }
        const visibleJobs = host.ctx.jobs.list(leadSessionId)
        const exactCommandJobs =
          registeredLongCommand === undefined ? [] : visibleJobs.filter((job) => job.label === registeredLongCommand)
        const exactCommandIds = new Set(exactCommandJobs.map((job) => String(job.id)))
        return {
          visibleJobs: visibleJobs.map(safeJobView),
          exactCommandJobCount: exactCommandJobs.length,
          exactCommandActiveCount: exactCommandJobs.filter(
            (job) => job.status === 'running' || job.status === 'stopping',
          ).length,
          otherLiveJobCount: visibleJobs.filter(
            (job) => !exactCommandIds.has(String(job.id)) && (job.status === 'running' || job.status === 'stopping'),
          ).length,
          unownedJobCount: visibleJobs.filter((job) => job.owner === undefined).length,
        }
      }
      const nativeExecuteRegistrations: ExecuteRegistration[] = []
      const nativeExecuteObserver = createNativeExecuteObserver({
        registrations: () => nativeExecuteRegistrations,
        hashIdentifier: (kind, value) => safeId(`${kind}:${value}`),
        onViolation: violate,
      })
      const registerNativeExecute = (registration: ExecuteRegistration): void => {
        nativeExecuteRegistrations.push(registration)
      }
      const modelRouteObservations: { provider: string; model: string; session: string }[] = []
      const runtimePromptObservations: { model: string; session: string }[] = []
      const promptTraces: PromptTrace[] = []
      const pendingPromptInvocations = new Map<string, PromptTrace[]>()
      let rejectionCancellation: RejectedCancellationState | undefined
      const rejectionCancellationEvidence: {
        readonly status: 'confirmed-remote-rejected-cancellation'
        readonly operation: string
        readonly owner: string
        readonly acpSession: string
        readonly request: string
        readonly promptOrdinal: number
        readonly leaseId: string
        readonly nativeCall: string
        readonly nativeStatus: string
        readonly turn: number
        readonly turnEndEventIndex: number
      }[] = []

      const postPrompt = async (
        text: string,
        marker: string,
        expectedSession?: SessionId,
      ): Promise<{ sessionId: SessionId; userIndex: number }> => {
        assertHealthy()
        const input = required(page).locator('[data-composer-input]').first()
        await writeComposerDraft(required(page), input, `${text} Reference marker: ${marker}`)
        const before = events.length
        await required(page).getByRole('button', { name: 'Send message', exact: true }).click()
        let userIndex = -1
        let sessionId: SessionId | undefined
        await waitFor(
          () => {
            const candidate = events.findIndex(
              (event, index) =>
                index >= before && event.type === 'user/message' && JSON.stringify(event.data.content).includes(marker),
            )
            expect(candidate).toBeGreaterThanOrEqual(0)
            userIndex = candidate
            sessionId = events[candidate]?.sessionId
            expect(sessionId).toBeDefined()
          },
          { timeout: Math.max(1, phaseDeadlineAt - Date.now()), interval: 100 },
        )
        const id = required(sessionId)
        if (expectedSession !== undefined) expect(id).toBe(expectedSession)
        if (leadSessionId === undefined) leadSessionId = id
        if (leadSessionId === id) leadAgent = host.ctx.agents.get(id)
        return { sessionId: id, userIndex }
      }

      const waitForTurn = async (sessionId: SessionId, userIndex: number): Promise<void> => {
        // Polling assertions retry every thrown error, including fatal scope violations.
        // Session events already wake this waiter; violate() rejects it and clears its timer.
        while (true) {
          assertHealthy()
          const ending = events.find(
            (event, index) => index > userIndex && event.sessionId === sessionId && event.type === 'turn/end',
          )
          if (ending?.type === 'turn/end') {
            expect(ending.data.reason.kind).toBe('completed')
            expect(
              events.some(
                (event, index) =>
                  index > userIndex && event.sessionId === sessionId && event.type === 'assistant/message',
              ),
            ).toBe(true)
            break
          }
          await waitForEventChange()
        }
        await checkModelSnapshot(String(sessionId), 'after-turn')
      }

      const sendPrompt = async (text: string, marker: string, expectedSession?: SessionId): Promise<SessionId> => {
        const posted = await postPrompt(text, marker, expectedSession)
        await waitForTurn(posted.sessionId, posted.userIndex)
        const userPrompt = required(page)
          .locator(`[data-conversation-session="${posted.sessionId}"] [data-chat-flow-kind="user"]`)
          .filter({ hasText: marker })
        await userPrompt.first().waitFor({
          state: 'visible',
          timeout: Math.max(1, Math.min(10_000, phaseDeadlineAt - Date.now())),
        })
        expect(await userPrompt.count()).toBe(1)
        return posted.sessionId
      }

      const requireRead = (sessionId: string, paths: readonly string[], fromToolIndex: number): void => {
        const observed = tools.slice(fromToolIndex)
        for (const path of paths)
          expect(
            observed.some(
              (tool) =>
                tool.session === safeId(sessionId) &&
                tool.name === 'read' &&
                tool.readPath === path &&
                (tool.readLines ?? 0) > 0 &&
                !tool.isError,
            ),
            `Expected this turn to successfully use DSH read for ${path}`,
          ).toBe(true)
      }

      const requireReadFromHostOrNative = (
        sessionId: string,
        paths: readonly string[],
        fromToolIndex: number,
      ): void => {
        const hostReads = tools.slice(fromToolIndex)
        for (const path of paths) {
          const source = nativeReadSources.find((candidate) => candidate.absolutePath === path)
          expect(source, `Expected a fixed public source mapping for ${path}`).toBeDefined()
          const hostVerified = hostReads.some(
            (tool) =>
              tool.session === safeId(sessionId) &&
              tool.name === 'read' &&
              tool.readPath === path &&
              (tool.readLines ?? 0) > 0 &&
              !tool.isError,
          )
          const nativeVerified = nativeReadEvidence.some(
            (read) =>
              read.scene === 'B' &&
              read.session === safeId(`dsh-session:${sessionId}`) &&
              read.path === source?.relativePath,
          )
          expect(
            hostVerified || nativeVerified,
            `Expected a successful Host or source-verified native read for ${path}`,
          ).toBe(true)
        }
      }

      const resetScene = (scene: LongTaskScene): void => {
        activeScene = scene
        sceneStartedAt = Date.now()
        phaseDeadlineAt = Math.min(sceneStartedAt + LONG_TASK_BUDGET.phaseMs, startedAt + LONG_TASK_BUDGET.totalMs)
        activePhase = `${scene}:start`
      }

      try {
        host = await launchAdapterWorld({ teams: true, teamMembers: 3 })
        removeJobEvents = host.ctx.jobs.events.subscribe({ owners: 'all' }, (event) => {
          if (event.type === 'progress' || event.type === 'output') return
          if (jobEvidence.length >= 512) {
            violate('LONG_TASK_JOB_EVIDENCE_LIMIT')
            return
          }
          const job = event.job
          jobEvidence.push({
            event: event.type,
            id: safeId(`job:${String(job.id)}`),
            ...(job.owner === undefined ? {} : { owner: safeId(`dsh-session:${String(job.owner)}`) }),
            kind: job.kind,
            status: job.status,
            startedAt: job.startedAt,
            ...(job.finishedAt === undefined ? {} : { finishedAt: job.finishedAt }),
            ...(event.type === 'settled' ? { cause: event.cause, awaited: event.awaited } : {}),
            label: job.label,
          })
        })
        const nativeLoader = host.ctx.loader as unknown as {
          internal?: unknown
          import(specifier: string): Promise<unknown>
        }
        if (nativeLoader.internal === undefined) throw new Error('LONG_TASK_NATIVE_LOADER_UNAVAILABLE')
        const runtimeModule = (await nativeLoader.import(
          pathToFileURL(resolve(root, 'lib/runtime/session/session-runtime.js')).href,
        )) as NativeRuntimeModule
        nativeDiagnosticModule = (await nativeLoader.import(
          pathToFileURL(resolve(root, 'lib/contract/live-diagnostic-trace.js')).href,
        )) as NativeDiagnosticModule
        if (
          typeof (nativeDiagnosticModule as { liveDiagnosticTraceEnabled?: unknown }).liveDiagnosticTraceEnabled !==
          'function'
        )
          throw new Error('LONG_TASK_NATIVE_DIAGNOSTIC_ENABLEMENT_CHECK_UNAVAILABLE')
        const runtimePrototype = (
          runtimeModule.AcpSessionRuntime as unknown as { prototype: { prompt: RuntimePrompt } }
        ).prototype
        const originalRuntimePrompt = runtimePrototype.prompt
        runtimePrototype.prompt = function (
          this: ThisParameterType<RuntimePrompt>,
          ...args: Parameters<RuntimePrompt>
        ) {
          runtimePromptChecks += 1
          const options = this.configOptions
          assertHealthy()
          const modelOption = options?.find(
            (option) => option.type === 'select' && (option.category === 'model' || option.id === 'model'),
          )
          if (modelOption?.type !== 'select' || modelOption.currentValue !== profile.model) {
            violate('LONG_TASK_RUNTIME_MODEL_SNAPSHOT_MISMATCH')
            throw new Error('LONG_TASK_RUNTIME_MODEL_SNAPSHOT_MISMATCH')
          }
          const runtimeState = this as unknown as {
            readonly acpSessionId?: string
            readonly options: {
              readonly diagnosticDshSessionId?: string
              onPermissionRequest?: (this: unknown, ...callbackArgs: unknown[]) => Promise<unknown>
            }
          }
          const runtimeDshSessionId = runtimeState.options.diagnosticDshSessionId
          if (typeof runtimeDshSessionId === 'string')
            runtimePromptObservations.push({ model: modelOption.currentValue, session: safeId(runtimeDshSessionId) })
          const originalPermissionRequest = runtimeState.options.onPermissionRequest
          if (typeof originalPermissionRequest === 'function' && !wrappedPermissionOptions.has(runtimeState.options)) {
            const wrappedPermissionRequest = function (this: unknown, ...callbackArgs: unknown[]): Promise<unknown> {
              const params = callbackArgs[0]
              if (
                activeScene === 'B' &&
                typeof runtimeDshSessionId === 'string' &&
                isRecord(params) &&
                typeof params.sessionId === 'string' &&
                isRecord(params.toolCall) &&
                typeof params.toolCall.toolCallId === 'string'
              ) {
                bPermissionRequests.set(
                  `${runtimeDshSessionId}:${params.sessionId}:${params.toolCall.toolCallId}`,
                  params as unknown as RequestPermissionRequest,
                )
              }
              try {
                const decision = nativeExecuteObserver.observePermission(params, {
                  scene: activeScene,
                  ownerDshSessionId: runtimeDshSessionId,
                  activeAcpSessionId: runtimeState.acpSessionId,
                })
                if (decision.kind === 'refuse') return Promise.resolve(decision.response)
              } catch {
                violate('LONG_TASK_NATIVE_EXECUTE_OBSERVER_FAILURE')
                return Promise.resolve(nativeExecuteRefusalResponse(params))
              }
              const result = originalPermissionRequest.apply(this, callbackArgs)
              return result.then((response: unknown) => {
                try {
                  const state = rejectionCancellation
                  if (
                    state !== undefined &&
                    state.expected.scene === activeScene &&
                    state.expected.phase === activePhase &&
                    state.prompt.promptOrdinal === state.expected.promptOrdinal &&
                    state.prompt.leaseId === state.expected.leaseId &&
                    state.prompt.stopReason === undefined &&
                    state.expected.owner ===
                      nativeDiagnosticModule?.liveDiagnosticId('dsh-session', runtimeDshSessionId) &&
                    state.expected.acpSession ===
                      nativeDiagnosticModule?.liveDiagnosticId('acp-session', runtimeState.acpSessionId) &&
                    isRecord(params) &&
                    params.sessionId === runtimeState.acpSessionId &&
                    isRecord(params.toolCall) &&
                    typeof params.toolCall.toolCallId === 'string' &&
                    safeId(`acp-tool-call:${params.toolCall.toolCallId}`) === state.expected.callId
                  ) {
                    const signal = callbackArgs[1]
                    const signalAborted = !isRecord(signal) || signal.aborted !== false
                    const options = Array.isArray(params.options) ? params.options : []
                    const selected = isRecord(response) && isRecord(response.outcome) ? response.outcome : undefined
                    const selectedOptionId = selected?.optionId
                    const selectedOption =
                      typeof selectedOptionId === 'string'
                        ? options.find((option) => isRecord(option) && option.optionId === selectedOptionId)
                        : undefined
                    state.permissionResponse = {
                      callId: state.expected.callId,
                      outcome: typeof selected?.outcome === 'string' ? selected.outcome : 'unknown',
                      optionKind:
                        isRecord(selectedOption) && typeof selectedOption.kind === 'string'
                          ? selectedOption.kind
                          : 'unknown',
                      signalAborted,
                      responseCount: (state.permissionResponse?.responseCount ?? 0) + 1,
                    }
                  }
                } catch {
                  violate('LONG_TASK_NATIVE_EXECUTE_OBSERVER_FAILURE')
                }
                return response
              })
            }
            runtimeState.options.onPermissionRequest = wrappedPermissionRequest
            wrappedPermissionOptions.add(runtimeState.options)
            restoreRuntimePermissionHandlers.push(() => {
              if (runtimeState.options.onPermissionRequest === wrappedPermissionRequest)
                runtimeState.options.onPermissionRequest = originalPermissionRequest
            })
          }
          const originalOnUpdate = args[1]
          if (typeof originalOnUpdate !== 'function') {
            violate('LONG_TASK_NATIVE_READ_UPDATE_CALLBACK_UNAVAILABLE')
            return originalRuntimePrompt.apply(this, args)
          }
          let observeNativeRead: ((notification: unknown) => NativeReadEvidence[]) | undefined
          const wrappedOnUpdate = wrapObservedCallback(
            originalOnUpdate as (this: unknown, ...callbackArgs: unknown[]) => unknown,
            (notification) => {
              const activeAcpSessionId = runtimeState.acpSessionId
              nativeExecuteObserver.observeUpdate(notification, {
                scene: activeScene,
                ownerDshSessionId: runtimeDshSessionId,
              })
              if (activeAcpSessionId !== undefined) {
                observeNativeRead ??= createNativeReadObserver({
                  activeSessionId: activeAcpSessionId,
                  ...(typeof runtimeDshSessionId === 'string' ? { sessionEvidenceId: runtimeDshSessionId } : {}),
                  sources: nativeReadSources,
                  hashIdentifier: (kind, value) => safeId(`${kind}:${value}`),
                  onDiagnostic: (diagnostic) => {
                    if (nativeReadDiagnostics.length < 2048)
                      nativeReadDiagnostics.push({ ...diagnostic, scene: activeScene, phase: activePhase })
                    else violate('LONG_TASK_NATIVE_READ_DIAGNOSTIC_LIMIT')
                  },
                })
                nativeReadEvidence.push(
                  ...observeNativeRead(notification).map((read) => ({ ...read, scene: activeScene })),
                )
              }
            },
            () => violate('LONG_TASK_NATIVE_READ_OBSERVER_FAILURE'),
          )
          const wrappedArgs = [...args]
          wrappedArgs[1] = wrappedOnUpdate
          const promptTrace: PromptTrace = {
            scene: activeScene,
            phase: activePhase,
            owner: nativeDiagnosticModule?.liveDiagnosticId('dsh-session', runtimeDshSessionId) ?? 'unavailable',
            acpSession:
              nativeDiagnosticModule?.liveDiagnosticId('acp-session', runtimeState.acpSessionId) ?? 'unavailable',
            ...(abortSignalLike(args[2]) === undefined ? {} : { signal: abortSignalLike(args[2]) }),
          }
          const promptKey = JSON.stringify([promptTrace.owner, promptTrace.acpSession])
          const pendingPrompts = pendingPromptInvocations.get(promptKey) ?? []
          pendingPrompts.push(promptTrace)
          pendingPromptInvocations.set(promptKey, pendingPrompts)
          const removePendingPrompt = (): void => {
            const current = pendingPromptInvocations.get(promptKey)
            if (current === undefined) return
            const index = current.indexOf(promptTrace)
            if (index >= 0) current.splice(index, 1)
            if (current.length === 0) pendingPromptInvocations.delete(promptKey)
          }
          try {
            const result = originalRuntimePrompt.apply(this, wrappedArgs)
            if (isRecord(result) && typeof result.then === 'function')
              return Promise.resolve(result).finally(removePendingPrompt)
            removePendingPrompt()
            return result
          } catch (error: unknown) {
            removePendingPrompt()
            throw error
          }
        }
        restoreRuntimePrompt = () => {
          runtimePrototype.prompt = originalRuntimePrompt
        }
        const cliVersionOutput = execFileSync(profile.command, profile.versionArgs, {
          encoding: 'utf8',
          timeout: 10_000,
        }).trim()
        const cliVersion = cliVersionOutput.match(/\d+\.\d+\.\d+(?:[-+][\w.-]+)?/u)?.[0]
        if (cliVersion === undefined) throw new Error('LONG_TASK_CLI_VERSION_UNAVAILABLE')
        const configuredEnvKeys = (process.env[`DSH_E2E_LIVE_LONG_TASK_${profileName.toUpperCase()}_ENV_KEYS`] ?? '')
          .split(',')
          .filter(Boolean)
        const env = Object.fromEntries(
          configuredEnvKeys.map((key) => {
            if (process.env[key] === undefined)
              throw new Error(`Missing explicitly listed environment variable: ${key}`)
            return [key, process.env[key]]
          }),
        )
        const agentConfig = {
          name: profileName,
          command: profile.command,
          args: [...profile.args],
          env,
          ...('runtime' in profile ? { runtime: profile.runtime } : {}),
          ...('catalogId' in profile ? { catalogId: profile.catalogId } : {}),
        }
        await host.ctx.settings.replace('dsh-acp-adapter', {
          toolApprovalDefault: 'auto',
          agents: { [profile.id]: agentConfig },
        })
        await waitFor(() =>
          expect(host.ctx.llm.listProviders().some((entry) => entry.id === profile.provider)).toBe(true),
        )
        const models = await host.ctx.llm.listModels(profile.provider)
        expect(
          models.some((entry) => entry.id === profile.model),
          `Exact candidate ${profile.model} is absent from live catalog`,
        ).toBe(true)
        await host.ctx.agentDefaultModel.saveSelection({ provider: profile.provider, model: profile.model })

        // Observe the native question owner and exact request ID without answering or changing policy.
        const nativeQuestions = host.ctx.get('userQuestions') as AcpNativeUserQuestionService
        const originalAsk = nativeQuestions.ask.bind(nativeQuestions)
        const questionObserver = vi.spyOn(nativeQuestions, 'ask').mockImplementation((request) => {
          if (activeScene === 'B')
            for (const question of request.questions) {
              if (question.id.startsWith('acp-permission:'))
                bQuestionViews.set(question.id.slice('acp-permission:'.length), request)
            }
          return originalAsk(request)
        })
        restoreBQuestionObserver = () => questionObserver.mockRestore()
        answerBPermissions = async () => {
          if (bPermissionRequests.size === 0) return
          const decided = acpPermissionAudit(host, 'decided')
          const pending = acpPermissionAudit(host, 'asked').filter(
            (row) =>
              bPermissionRequests.has(`${row.sessionId}:${row.data.agentSessionId}:${row.data.toolCall.toolCallId}`) &&
              !decided.some((entry) => entry.data.requestId === row.data.requestId) &&
              !answeredBPermissions.has(row.data.requestId),
          )
          if (pending.length > 0)
            writePrivate(
              join(evidenceDir, 'B-permission-audit.json'),
              JSON.stringify(
                {
                  asked: pending,
                  decided,
                  bridge: acpPermissionAudit(host, 'bridge'),
                },
                null,
                2,
              ),
            )
          for (const asked of pending) {
            assertHealthy()
            const owner = required(host.ctx.agents.get(asked.sessionId as SessionId), 'B approval owner must be live')
            const membership = host.ctx.agentTeams.tryMembership(owner)
            expect(String(membership?.root.id)).toBe(String(leadSessionId))
            const role = membership?.role === 'lead' ? 'lead' : membership?.name
            expect(['lead', 'runtime-reader', 'teams-reader']).toContain(role)
            expect(owner.options).toMatchObject({ provider: profile.provider, model: profile.model })
            const original = required(
              bPermissionRequests.get(
                `${asked.sessionId}:${asked.data.agentSessionId}:${asked.data.toolCall.toolCallId}`,
              ),
            )
            expect(asked.data.options).toEqual(original.options)
            expect(asked.data.optionCount).toBe(original.options.length)
            expect(asked.data.omittedOptionCount ?? 0).toBe(0)
            expect(asked.data.toolCall.rawInputHash).toBe(summarizeRawInputForAudit(original.toolCall.rawInput).hash)
            const bridge = acpPermissionAudit(host, 'bridge').filter(
              (row) =>
                row.sessionId === asked.sessionId &&
                row.data.agentSessionId === asked.data.agentSessionId &&
                row.data.toolCallId === asked.data.toolCall.toolCallId,
            )
            expect(bridge).toHaveLength(1)
            const checked = required(bridge[0]).data
            expect(checked.reason).toBe('approval-required')
            expect(checked.structuredIdentityPresent).toBe(true)
            expect(profileName === 'devin' ? ['devin-meta'] : ['name', 'codebuddy-deferred-input']).toContain(
              checked.identitySource,
            )
            const paths = SOURCE_FILES.map((path) => sourcePathFor(join(host.workspaceCwd, 'workspace'), path))
            expect(
              permitsTeamReviewTool(required(checked.toolName), original.toolCall.rawInput, {
                role: role as 'lead' | 'runtime-reader' | 'teams-reader',
                sources: { 'runtime-reader': paths.slice(0, 3), 'teams-reader': paths.slice(3) },
                reportMarkers: {
                  'runtime-reader': `B_REPORT_RUNTIME_${runId.slice(0, 8)}`,
                  'teams-reader': `B_REPORT_TEAMS_${runId.slice(0, 8)}`,
                },
                tasks: host.ctx.agentTeams.listTasks(required(leadAgent)),
              }),
              'Only the assigned Team coordination and public source reads may receive a once decision',
            ).toBe(true)
            const budgetKey = `${asked.sessionId}:${asked.data.requestId}`
            if (!countedApprovalRequests.has(budgetKey)) {
              countedApprovalRequests.add(budgetKey)
              const violation = recordLongTaskApprovalRequest(budget, 'B')
              if (violation !== undefined) {
                violate(violation)
                throw new Error(violation)
              }
            }
            const view = bQuestionViews.get(asked.data.requestId)
            // The asked audit precedes native rendering; retry until this exact question is registered.
            if (view === undefined) continue
            expect(view.agent).toBe(leadAgent)
            expect(view.questions).toHaveLength(1)
            const question = required(view.questions[0])
            expect(question.id).toBe(`acp-permission:${asked.data.requestId}`)
            expect(question.options?.map((option) => option.label)).toEqual(
              original.options.map((option) => option.name),
            )
            const choices = original.options.filter((option) => option.kind === 'allow_once')
            expect(choices).toHaveLength(1)
            let card = required(page)
              .locator('[data-question-key]')
              .filter({ visible: true })
              .filter({ hasText: question.question })
            if (question.header !== undefined) card = card.filter({ hasText: question.header })
            if ((await card.count()) === 0) continue
            expect(
              await card.count(),
              'Concurrent permission cards must have an unambiguous request/owner projection',
            ).toBe(1)
            expect(await card.getByRole('radio').count()).toBe(original.options.length)
            for (const option of original.options)
              await card.getByRole('radio', { name: option.name, exact: true }).waitFor()
            const evidence = {
              owner: safeId(asked.sessionId),
              root: safeId(String(leadSessionId)),
              agentSession: safeId(asked.data.agentSessionId),
              request: safeId(asked.data.requestId),
              callId: safeId(asked.data.toolCall.toolCallId),
              toolName: checked.toolName,
              identitySource: checked.identitySource,
              rawInputHash: asked.data.toolCall.rawInputHash,
              options: original.options,
              optionId: required(choices[0]).optionId,
              status: 'pending',
              admissionsBefore: budget.sceneDispatches.B,
            }
            bPermissionEvidence.push(evidence)
            await capture('B', `permission-${bPermissionEvidence.length}-pending`, evidence)
            assertHealthy()
            await card.getByRole('radio', { name: required(choices[0]).name, exact: true }).click()
            assertHealthy()
            await card.getByRole('button', { name: /^(Submit|Send)$/ }).click()
            answeredBPermissions.add(asked.data.requestId)
            await waitFor(() => {
              const result = acpPermissionAudit(host, 'decided').filter(
                (row) => row.data.requestId === asked.data.requestId,
              )
              expect(result).toHaveLength(1)
              expect(result[0]).toMatchObject({
                sessionId: asked.sessionId,
                data: {
                  agentSessionId: asked.data.agentSessionId,
                  toolCallId: asked.data.toolCall.toolCallId,
                  outcome: 'selected',
                  selectedOptionKind: 'allow_once',
                  optionId: required(choices[0]).optionId,
                },
              })
              if (role !== 'lead')
                expect(required(result[0]).data.presentation).toMatchObject({
                  rootSessionId: String(leadSessionId),
                  path: [asked.sessionId],
                })
            })
            evidence.status = 'allowed-once'
            writePrivate(join(evidenceDir, 'B-permissions.json'), JSON.stringify(bPermissionEvidence, null, 2))
          }
        }

        const allowedTeamTools = new Set(['spawn_teammate', 'wait_agent', 'list_agents'])
        const sourcePaths = new Set(
          SOURCE_FILES.map((path) => sourcePathFor(join(host.workspaceCwd, 'workspace'), path)),
        )
        const operationCommands = new Map<string, string>()
        const operationOwners = new Map<string, string>()
        const successfulMemberRelays = new Set<string>()
        const dLongCallIds = new Set<string>()
        let taskCreateAttempts = 0
        let dLongAdmissions = 0
        host.ctx.tools.guard((execution) => {
          if (execution.agent?.options.provider !== profile.provider) return undefined
          const scene = activeScene
          const toolName = execution.name
          try {
            assertHealthy()
          } catch {
            const violation = stickyViolation ?? 'LONG_TASK_DEADLINE'
            violate(violation)
            return `LIVE_LONG_TASK_BUDGET:${violation}`
          }
          const actorId = String(execution.agent.id)
          const args = execution.arguments as Record<string, unknown> | undefined
          let allowed = false
          if (scene === 'A') {
            allowed = toolName === 'read' && typeof args?.file_path === 'string' && sourcePaths.has(args.file_path)
          } else if (scene === 'B') {
            const membership = host.ctx.agentTeams.tryMembership(execution.agent)
            const isLead = membership?.role === 'lead' && String(membership.root.id) === String(leadSessionId)
            const isExpectedMember =
              membership?.role === 'teammate' &&
              String(membership.root.id) === String(leadSessionId) &&
              ['runtime-reader', 'teams-reader'].includes(membership.name)
            if (toolName === 'team_task_create') {
              if (!isLead) {
                violate('LONG_TASK_TEAM_ROLE_VIOLATION')
                return 'LIVE_LONG_TASK_SCOPE_TEAM_ROLE'
              }
              taskCreateAttempts += 1
              if (taskCreateAttempts > 2) {
                violate('LONG_TASK_TASK_CREATE_BUDGET')
                return 'LIVE_LONG_TASK_SCOPE_TASK_CREATE_BUDGET'
              }
            }
            const teamTaskAllowed =
              toolName.startsWith('team_task_') &&
              (isLead || (isExpectedMember && ['team_task_get', 'team_task_update'].includes(toolName)))
            const target = typeof args?.target === 'string' ? args.target : ''
            const teamMessageAllowed =
              toolName === 'send_message' &&
              ((isExpectedMember && target === 'lead') ||
                (isLead && ['runtime-reader', 'teams-reader'].includes(target)))
            allowed =
              (toolName === 'read' && typeof args?.file_path === 'string' && sourcePaths.has(args.file_path)) ||
              (allowedTeamTools.has(toolName) &&
                (toolName !== 'spawn_teammate' || isLead) &&
                (toolName !== 'wait_agent' || isLead) &&
                (toolName !== 'list_agents' || isLead || isExpectedMember)) ||
              teamTaskAllowed ||
              teamMessageAllowed
          } else if (scene === 'C') {
            const command = typeof args?.command === 'string' ? args.command : ''
            const relay = typeof args?.message === 'string' ? args.message : ''
            const expectedRelay = [...operationCommands.values()].some((command) => relay.includes(command))
            const operationRelay = [...operationCommands.keys()].some((id) => relay.includes(`${id}-${runId}`))
            const operation = [...operationCommands].find(([, expected]) => expected === command)?.[0]
            if (operation !== undefined && (operationAdmissions.get(operation) ?? 0) > 0) {
              violate('LONG_TASK_OPERATION_DUPLICATE_DISPATCH')
              return 'LIVE_LONG_TASK_OPERATION_DUPLICATE_DISPATCH'
            }
            allowed =
              isMemberApprovalCoordination({
                scene,
                phase: activePhase,
                owner: actorId,
                lead: leadSessionId === undefined ? undefined : String(leadSessionId),
                member: runtimeReaderId === undefined ? undefined : String(runtimeReaderId),
                toolName,
                args,
                relaySucceeded: successfulMemberRelays.has(activePhase.slice(2)),
              }) ||
              (toolName === 'send_message' &&
                ((actorId === String(leadSessionId) && args?.target === 'runtime-reader' && expectedRelay) ||
                  (memberSessionIds.has(actorId) && args?.target === 'lead' && operationRelay))) ||
              (toolName === 'bash' && operation !== undefined && operationOwners.get(operation) === actorId)
          } else {
            const command = typeof args?.command === 'string' ? args.command : ''
            const timeout = args?.timeoutMs
            const runInBackground = args?.run_in_background
            const foregroundMode = (timeout === undefined || timeout === 120_000) && runInBackground !== true
            allowed = toolName === 'bash' && command === operationCommands.get('D:long-running') && foregroundMode
            if (allowed && dLongAdmissions > 0) {
              violate('LONG_TASK_STOPPED_COMMAND_DUPLICATE_DISPATCH')
              return 'LIVE_LONG_TASK_STOPPED_COMMAND_DUPLICATE_DISPATCH'
            }
          }
          if (!allowed) {
            violate(`LONG_TASK_TOOL_SCOPE_${scene}_${toolName}`)
            return `LIVE_LONG_TASK_SCOPE_DENIED:${scene}:${toolName}`
          }
          const scopedCallId = `${actorId}:${String(execution.callId)}`
          const effectFingerprint = ['bash', 'write', 'edit', 'apply_patch', 'create_file', 'send_message'].includes(
            toolName,
          )
            ? longTaskEffectFingerprint(runSecret.toString('hex'), toolName, { actorId, args })
            : undefined
          const violation = admitLongTaskTool(budget, {
            scene,
            toolName,
            callId: scopedCallId,
            effectFingerprint,
          })
          if (violation !== undefined) {
            violate(violation)
            return `LIVE_LONG_TASK_BUDGET:${violation}`
          }
          if (scene === 'C' && toolName === 'bash') {
            const operation = [...operationCommands].find(([, command]) => command === args?.command)?.[0]
            if (operation !== undefined)
              operationAdmissions.set(operation, (operationAdmissions.get(operation) ?? 0) + 1)
          }
          if (scene === 'D' && toolName === 'bash') {
            dLongAdmissions += 1
            dLongCallIds.add(scopedCallId)
          }
          if (toolName === 'read' && (scene === 'A' || scene === 'B')) {
            const path = typeof args?.file_path === 'string' ? args.file_path : ''
            scheduleCapture(scene, `tool-admitted-${safeId(path).slice(0, 6)}`, {
              toolAdmission: 'accepted',
              readPath: path,
              captureRequestedAt: 'guard-accepted-before-tool-body',
            })
          }
          return undefined
        })
        host.ctx.on('tools/result', (execution, result) => {
          if (execution.agent?.options.provider !== profile.provider) return
          const sessionId = String(execution.agent.id)
          const args = execution.arguments as Record<string, unknown> | undefined
          const currentMemberOperation = activePhase.slice(2)
          const relayedCommand = operationCommands.get(currentMemberOperation)
          if (
            activeScene === 'C' &&
            ['member-allow', 'member-reject'].includes(currentMemberOperation) &&
            sessionId === String(leadSessionId) &&
            execution.name === 'send_message' &&
            args?.target === 'runtime-reader' &&
            typeof args.message === 'string' &&
            relayedCommand !== undefined &&
            args.message.includes(relayedCommand) &&
            !result.isError
          )
            successfulMemberRelays.add(currentMemberOperation)
          const readPath = execution.name === 'read' && typeof args?.file_path === 'string' ? args.file_path : undefined
          const readResult = result as unknown as { value?: { lines?: unknown } }
          const readLines = Array.isArray(readResult.value?.lines) ? readResult.value.lines.length : undefined
          const command = typeof args?.command === 'string' ? args.command : ''
          const operation = command.match(
            new RegExp(`(lead-allow|member-allow|lead-reject|member-reject)-${runId}`, 'u'),
          )
          const operationId = command === operationCommands.get('D:long-running') ? 'D:long-running' : operation?.[1]
          const assignmentText =
            activeScene === 'B' && ['spawn_teammate', 'team_task_create'].includes(execution.name)
              ? [args?.prompt, args?.description]
                  .filter((value): value is string => typeof value === 'string')
                  .join('\n')
              : undefined
          const evidence: ToolEvidence = {
            name: execution.name,
            session: safeId(sessionId),
            callId: safeId(String(execution.callId)),
            isError: result.isError,
            eventCount: events.length,
            ...(typeof args?.task_id === 'string' ? { taskId: safeId(args.task_id) } : {}),
            ...(readPath === undefined ? {} : { readPath }),
            ...(typeof args?.offset === 'number' ? { readOffset: args.offset } : {}),
            ...(typeof args?.limit === 'number' ? { readLimit: args.limit } : {}),
            ...(readLines === undefined ? {} : { readLines }),
            ...(operationId === undefined ? {} : { operationId }),
            ...(assignmentText === undefined
              ? {}
              : {
                  assignment: {
                    descriptionIdentity: safeId(assignmentText),
                    sourcePaths: SOURCE_FILES.filter((path) => assignmentText.includes(path)),
                    reportMarkers: ['B_REPORT_RUNTIME', 'B_REPORT_TEAMS'].filter((marker) =>
                      assignmentText.includes(marker),
                    ),
                    requiresRead: /\bread\b/iu.test(assignmentText),
                    requiresOwnDiscovery: /discover/iu.test(assignmentText),
                  },
                }),
          }
          tools.push(evidence)
          recordLongTaskToolResult(budget, `${sessionId}:${String(execution.callId)}`, result.isError)
        })
        host.ctx.on('session/event', (session, event) => addEvent(session.id, event))
        observeLiveExternalApprovals(host, addEvent)
        host.ctx.on('agent/inbox/claimed', (value: unknown) => {
          const claim = value as {
            agent?: { id?: string }
            message?: { content?: unknown }
            turn?: number
          }
          if (claim.agent?.id !== String(leadSessionId) || typeof claim.turn !== 'number') return
          const content = JSON.stringify(claim.message?.content ?? '')
          const cMarker = leadControlClaimMarker(content, runId.slice(0, 8))
          if (cMarker !== undefined) claimedTurnByMarker.set(cMarker, claim.turn)
          for (const marker of ['LONGTASK_D_RUNNING_', 'LONGTASK_D_QUEUED_', 'LONGTASK_D_RESUME_']) {
            const match = content.match(new RegExp(`${marker}[a-f0-9]{8}`, 'u'))
            if (match !== null) {
              claimedTurnByMarker.set(match[0], claim.turn)
              if (marker === 'LONGTASK_D_RUNNING_') expectedDAbortTurn = claim.turn
            }
          }
        })
        host.ctx.on('llm/stream', (request: GenerateOptions, next) => {
          if (request.provider !== profile.provider || request.model !== profile.model) {
            violate('LONG_TASK_UNEXPECTED_PROVIDER_OR_MODEL')
            throw new Error('LONG_TASK_UNEXPECTED_PROVIDER_OR_MODEL')
          }
          assertHealthy()
          const sessionId = String(request.sessionId)
          modelRouteObservations.push({ provider: request.provider, model: request.model, session: safeId(sessionId) })
          return next()
        })
        if (nativeDiagnosticModule === undefined) throw new Error('LONG_TASK_NATIVE_DIAGNOSTIC_MODULE_UNAVAILABLE')
        const removeSink = nativeDiagnosticModule.installLiveDiagnosticTrace(
          diagnosticSink(runSecret, (event) => {
            nativeTraceEvents += 1
            if (event.type === 'adapter-prompt/start') {
              const key = JSON.stringify([event.sessionId, event.acpSessionId ?? 'unavailable'])
              const pending = pendingPromptInvocations.get(key) ?? []
              const matchingIndexes = pending
                .map((candidate, index) => ({ candidate, index }))
                .filter(
                  ({ candidate }) =>
                    candidate.scene === activeScene &&
                    candidate.phase === activePhase &&
                    candidate.promptOrdinal === undefined,
                )
              if (matchingIndexes.length > 1) violate('LONG_TASK_PROMPT_TRACE_AMBIGUOUS')
              const invocationIndex = matchingIndexes.length === 1 ? matchingIndexes[0]?.index : undefined
              const invocation = invocationIndex === undefined ? undefined : pending[invocationIndex]
              if (invocation !== undefined && invocationIndex !== undefined) {
                invocation.promptOrdinal = event.promptOrdinal
                invocation.leaseId = event.leaseId
                pending.splice(invocationIndex, 1)
                if (pending.length === 0) pendingPromptInvocations.delete(key)
                promptTraces.push(invocation)
              }
            } else if (event.type === 'adapter-prompt/end') {
              const prompt = promptTraces.find(
                (candidate) =>
                  candidate.owner === event.sessionId &&
                  candidate.acpSession === event.acpSessionId &&
                  candidate.promptOrdinal === event.promptOrdinal &&
                  candidate.leaseId === event.leaseId &&
                  candidate.stopReason === undefined,
              )
              if (prompt !== undefined) {
                prompt.stopReason = event.stopReason ?? 'unknown'
                prompt.signalAbortedAtEnd = prompt.signal?.aborted ?? true
              }
            }
            const safeEvent: Record<string, unknown> = {
              ...event,
              sessionId: safeId(event.sessionId),
              ...(event.acpSessionId === undefined ? {} : { acpSessionId: safeId(event.acpSessionId) }),
              ...('leaseId' in event && event.leaseId !== undefined ? { leaseId: safeId(event.leaseId) } : {}),
              ...('mcpRequestId' in event && event.mcpRequestId !== undefined
                ? { mcpRequestId: safeId(event.mcpRequestId) }
                : {}),
              ...('hostCallId' in event && event.hostCallId !== undefined
                ? { hostCallId: safeId(event.hostCallId) }
                : {}),
              ...('providerModelCallId' in event && event.providerModelCallId !== undefined
                ? { providerModelCallId: safeId(event.providerModelCallId) }
                : {}),
              ...('providerToolCallId' in event && event.providerToolCallId !== undefined
                ? { providerToolCallId: safeId(event.providerToolCallId) }
                : {}),
              ...('messageId' in event && event.messageId !== undefined ? { messageId: safeId(event.messageId) } : {}),
              phase: activePhase,
              elapsedMs: Date.now() - startedAt,
            }
            appendFileSync(tracePath, `${JSON.stringify(safeEvent)}\n`)
            if (event.type === 'acp-tool/update' && event.adapterPromptOrdinal !== undefined) {
              const scopedId = `${event.acpSessionId ?? event.sessionId}:${event.providerToolCallId}`
              if (observeLongTaskProviderToolCall(budget, scopedId) && budget.violation !== undefined)
                violate(budget.violation)
            }
          }),
        )
        removeTrace = removeSink
        if (!nativeDiagnosticModule.liveDiagnosticTraceEnabled())
          throw new Error('LONG_TASK_NATIVE_DIAGNOSTIC_SINK_NOT_ENABLED')

        const evidenceSource = exportPinnedSource(join(host.workspaceCwd, 'workspace'))
        expect(evidenceSource.totalBytes).toBeLessThanOrEqual(SOURCE_MAX_BYTES)
        nativeReadSources = evidenceSource.files.map((file) => ({
          absolutePath: sourcePathFor(join(host.workspaceCwd, 'workspace'), file.path),
          relativePath: file.path,
          content: readFileSync(sourcePathFor(join(host.workspaceCwd, 'workspace'), file.path), 'utf8'),
        }))
        const packageJson = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')) as { version: string }
        const browserOptions = {
          headless: process.env.DSH_E2E_RETAIN !== '1',
          ...(process.env.DSH_E2E_BROWSER_CHANNEL ? { channel: process.env.DSH_E2E_BROWSER_CHANNEL } : {}),
        }
        browser = await launchBrowser(browserOptions)
        page = await newEnglishPage(browser)
        page.setDefaultTimeout(10_000)
        page.on('pageerror', (error) => errorTexts.push(error.message))
        await page.goto(host.authenticatedUrl)
        await connectFreshWorkspace(page, host.workspaceCwd)

        writePrivate(
          join(evidenceDir, 'run.json'),
          JSON.stringify(
            {
              status: 'running',
              agent: profileName,
              provider: profile.provider,
              model: profile.model,
              cliVersion,
              dshCommit: SOURCE_COMMIT,
              dshPluginVersion: packageJson.version,
              platform: process.platform,
              arch: process.arch,
              node: process.version,
              source: evidenceSource,
              scenarios: scenarioStatuses,
              startedAt: new Date(startedAt).toISOString(),
            },
            null,
            2,
          ),
        )

        // A: six real turns on one ACP session, each using the DSH filesystem read tool.
        if (scenarios === 'all') {
          resetScene('A')
          await capture('A', 'start', { session: 'pending' })
          const aPrompts = [
            ['inbox.ts', 'Read the exact inbox module. Explain its responsibility and cite paths.'],
            [
              'tool-calls.ts',
              'Read tool-calls.ts. Refine your explanation of how the agent loop admits and dispatches tools.',
            ],
            ['mailbox.ts', 'Read mailbox.ts. Compare message delivery to the inbox behavior you already read.'],
            ['task-board.ts', 'Read task-board.ts. Revise the summary to explain task ownership and revision checks.'],
            ['types.ts', 'Read types.ts. Identify the source types that constrain the APIs you summarized.'],
            [
              'runtime-context.ts',
              'Re-read runtime-context.ts. Answer this challenge by correcting or defending your earlier summary with exact source paths.',
            ],
          ] as const
          for (let index = 0; index < aPrompts.length; index += 1) {
            const [fileName, instruction] = aPrompts[index]
            const fullPath = sourcePathFor(
              join(host.workspaceCwd, 'workspace'),
              SOURCE_FILES.find((path) => path.endsWith(fileName))!,
            )
            const fullPaths =
              index === 0
                ? [fullPath, sourcePathFor(join(host.workspaceCwd, 'workspace'), SOURCE_FILES[1])]
                : [fullPath]
            const readInstruction = fullPaths
              .map((path) => `Use the DSH filesystem read tool (not shell cat or grep) to read ${path}.`)
              .join(' ')
            const marker = `LONGTASK_A_${index + 1}_${runId.slice(0, 8)}`
            await withPhase(`A${index + 1}`, async () => {
              const toolIndex = tools.length
              const answerIndex = answers.length
              const id = await sendPrompt(
                `${instruction} ${readInstruction} Keep the answer concise and point to source paths.`,
                marker,
                leadSessionId,
              )
              leadSessionId ??= id
              requireRead(String(id), fullPaths, toolIndex)
              expect(
                answers
                  .slice(answerIndex)
                  .some((answer) => answer.session === safeId(String(id)) && answer.text.includes(fileName)),
                `Expected this turn's answer to cite ${fileName}`,
              ).toBe(true)
            })
            if (index === 0) await capture('A', 'progress', { completedRounds: 1 })
          }
          expect(leadSessionId).toBeDefined()
          expect(new Set(turns.filter((turn) => turn.scene === 'A').map((turn) => turn.session)).size).toBe(1)
          await capture('A', 'end', {
            completedRounds: 6,
            sourceReads: tools.filter((tool) => tool.name === 'read').length,
          })
          scenarioStatuses.A = 'passed'
        } else {
          writePrivate(
            join(evidenceDir, 'A-not-run.json'),
            JSON.stringify({ status: 'not-run', reason: `DSH_E2E_LIVE_LONG_TASK_SCENARIOS=${scenarios}` }),
          )
        }

        if (scenarios === 'controls' || scenarios === 'approvals' || scenarios === 'stop-only') {
          writePrivate(
            join(evidenceDir, 'B-not-run.json'),
            JSON.stringify({ status: 'not-run', reason: `DSH_E2E_LIVE_LONG_TASK_SCENARIOS=${scenarios}` }),
          )
        } else {
          // B: create exactly two real DSH members, source-read distinct module groups, then consume their messages.
          resetScene('B')
          await capture('B', 'start', { expectedMembers: 3 })
          const teamMarker = `LONGTASK_B_${runId.slice(0, 8)}`
          const teamSourcePaths = SOURCE_FILES.map((path) => sourcePathFor(join(host.workspaceCwd, 'workspace'), path))
          const bToolIndex = tools.length
          await withPhase(
            'B:team',
            async () => {
              await sendPrompt(
                `Use only the current DSH tools MCP connection identified in the latest host instructions. Discover exact names and complete input schemas only for these tools needed by this task: read, spawn_teammate, send_message, list_agents, wait_agent, team_task_create, team_task_get, team_task_list, team_task_update. If discovery is truncated, narrow discovery using the discovery capabilities actually available to you; do not use execute, terminal, or shell to read an overflow file. If complete required schemas cannot be discovered, report the limitation and end the turn. Create two shared tasks and exactly two members named runtime-reader and teams-reader. Then use task update to assign each task to its named owner. Assign runtime-reader to read these exact files with the DSH filesystem read tool: ${teamSourcePaths.slice(0, 3).join(', ')}. Assign teams-reader to read: ${teamSourcePaths.slice(3).join(', ')}. In each member's task, require it to discover its own current DSH connection's exact names and schemas only for read, team_task_get, team_task_update, and send_message; never pass your connection's tool names to it, and forbid execute, terminal, or shell for discovery and reading. Put the full file paths and this ordered checklist in both the spawn prompt and the shared task description: (1) get the assigned task; (2) discover the member's own current DSH read tool and actually call it for each of the three assigned files; (3) only after receiving all three read results, update the task to completed with source findings; (4) send the Lead one concise source-based report with file paths. A task description, another member's summary, or prior knowledge does not substitute for the member's own read calls. If any file cannot be read, leave the task incomplete and report that limitation. The runtime-reader report must include B_REPORT_RUNTIME_${runId.slice(0, 8)}, and the teams-reader report must include B_REPORT_TEAMS_${runId.slice(0, 8)}. After assigning both tasks, finish this turn without waiting for the reports; I will ask you to inspect and consume them in a follow-up. Do not use external subagents or shell to read source. Reference marker ${teamMarker}.`,
                teamMarker,
                leadSessionId,
              )
            },
            180_000,
          )
          const lead = required(leadAgent)
          const roster = host.ctx.agentTeams.listMembers(lead)
          expect(roster).toHaveLength(3)
          const runtimeReader = required(roster.find((member) => member.name === 'runtime-reader'))
          runtimeReaderId = runtimeReader.id
          const teamsReader = required(roster.find((member) => member.name === 'teams-reader'))
          const memberIds = [runtimeReader.id, teamsReader.id]
          memberIds.forEach((id) => memberSessionIds.add(String(id)))
          teamMemberFacts.push(
            ...[runtimeReader, teamsReader].map((member) => ({
              id: String(member.id),
              name: member.name,
              role: String(member.role),
            })),
          )
          await withPhase(
            'B:members-and-receipts',
            async () => {
              await waitFor(
                () => {
                  assertHealthy()
                  const tasks = host.ctx.agentTeams.listTasks(lead)
                  expect(
                    tasks.filter((task) => ['runtime-reader', 'teams-reader'].includes(task.ownerName ?? '')),
                  ).toHaveLength(2)
                  expect(
                    tasks
                      .filter((task) => ['runtime-reader', 'teams-reader'].includes(task.ownerName ?? ''))
                      .every((task) => task.status === 'completed'),
                  ).toBe(true)
                  const accepted = teamMessages.filter(
                    (message) =>
                      message.scene === 'B' &&
                      message.session === safeId(String(leadSessionId)) &&
                      message.type === 'agent/inbox/spliced' &&
                      message.reportMarker !== undefined,
                  )
                  const receipts = teamReceipts.filter(
                    (receipt) =>
                      receipt.scene === 'B' && accepted.some((entry) => entry.messageId === receipt.messageId),
                  )
                  expect(accepted).toHaveLength(2)
                  expect(receipts).toHaveLength(2)
                  expect(receipts.map((receipt) => receipt.messageId).sort()).toEqual(
                    accepted.map((message) => message.messageId).sort(),
                  )
                  expect(receipts.every((receipt) => receipt.session === safeId(String(leadSessionId)))).toBe(true)
                  expect(new Set(accepted.map((message) => message.senderId))).toEqual(new Set(memberIds.map(String)))
                  expect(new Set(accepted.map((message) => message.reportMarker))).toEqual(
                    new Set(['B_REPORT_RUNTIME', 'B_REPORT_TEAMS']),
                  )
                  for (const [sender, marker] of [
                    [runtimeReader.id, 'B_REPORT_RUNTIME'],
                    [teamsReader.id, 'B_REPORT_TEAMS'],
                  ] as const)
                    expect(accepted.find((message) => message.senderId === sender)?.reportMarker).toBe(marker)
                  expect(
                    memberIds.every((id) =>
                      turns.some(
                        (turn) =>
                          turn.scene === 'B' && turn.session === safeId(String(id)) && turn.reason === 'completed',
                      ),
                    ),
                  ).toBe(true)
                  expect(
                    receipts.every((receipt) =>
                      accepted.some(
                        (message) =>
                          message.messageId === receipt.messageId &&
                          message.senderId === receipt.senderId &&
                          message.reportMarker === receipt.reportMarker,
                      ),
                    ),
                  ).toBe(true)
                  expect(new Set(accepted.map((message) => message.targetId))).toEqual(new Set([String(leadSessionId)]))
                  for (const acceptedMessage of accepted) {
                    const receipt = required(receipts.find((entry) => entry.messageId === acceptedMessage.messageId))
                    expect(acceptedMessage.eventIndex).toBeLessThan(receipt.eventIndex)
                  }
                },
                { timeout: Math.max(1, phaseDeadlineAt - Date.now()), interval: 500 },
              )
            },
            180_000,
          )
          for (const [memberId, paths] of [
            [runtimeReader.id, SOURCE_FILES.slice(0, 3)],
            [teamsReader.id, SOURCE_FILES.slice(3)],
          ] as const) {
            requireReadFromHostOrNative(
              String(memberId),
              paths.map((path) => sourcePathFor(join(host.workspaceCwd, 'workspace'), path)),
              bToolIndex,
            )
            expect(
              runtimePromptObservations.some(
                (observation) =>
                  observation.session === safeId(String(memberId)) && observation.model === profile.model,
              ),
            ).toBe(true)
            expect(
              modelRouteObservations.some(
                (observation) =>
                  observation.session === safeId(String(memberId)) &&
                  observation.provider === profile.provider &&
                  observation.model === profile.model,
              ),
            ).toBe(true)
          }
          const leadExecutions = tools.filter((tool) => tool.session === safeId(String(leadSessionId)) && !tool.isError)
          expect(tools.filter((tool) => tool.name === 'spawn_teammate' && !tool.isError)).toHaveLength(2)
          expect(leadExecutions.some((tool) => tool.name === 'team_task_create')).toBe(true)
          for (const memberId of memberIds) {
            const memberTools = tools.filter((tool) => tool.session === safeId(String(memberId)) && !tool.isError)
            expect(memberTools.some((tool) => tool.name === 'team_task_get')).toBe(true)
            expect(memberTools.some((tool) => tool.name === 'team_task_update')).toBe(true)
          }
          expect(
            tools.filter(
              (tool) =>
                memberIds.some((id) => tool.session === safeId(String(id))) &&
                tool.name === 'send_message' &&
                !tool.isError,
            ),
          ).toHaveLength(2)
          const bConsumeStart = events.length
          await withPhase('B:lead-consumes-reports', async () => {
            await sendPrompt(
              `Use the task list tool to confirm both assigned tasks are completed, then use the task get tool for each task to inspect its result. Retrieve both member reports and compare their source-based findings. Quote both reports' B_REPORT markers exactly in your answer. Cite actual module paths and explain one relationship between session/runtime and Teams. Do not run shell or alter files. Marker ${teamMarker}_CONSUME.`,
              `${teamMarker}_CONSUME`,
              leadSessionId,
            )
          })
          const bConsumeUserIndex = events.findIndex(
            (event, index) =>
              index >= bConsumeStart &&
              event.sessionId === lead.id &&
              event.type === 'user/message' &&
              event.data.source.kind === 'user' &&
              event.data.content.some((block) => block.type === 'text' && block.text.includes(`${teamMarker}_CONSUME`)),
          )
          expect(bConsumeUserIndex).toBeGreaterThanOrEqual(bConsumeStart)
          const bConsumeEnd = events.findIndex(
            (event, index) => index > bConsumeUserIndex && event.sessionId === lead.id && event.type === 'turn/end',
          )
          expect(bConsumeEnd).toBeGreaterThan(bConsumeUserIndex)
          const consumedLeadExecutions = tools.filter(
            (tool) =>
              tool.session === safeId(String(leadSessionId)) &&
              !tool.isError &&
              tool.eventCount > bConsumeUserIndex &&
              tool.eventCount <= bConsumeEnd,
          )
          expect(leadExecutions.some((tool) => tool.name === 'team_task_update')).toBe(true)
          for (const toolName of ['team_task_list', 'team_task_get'])
            expect(consumedLeadExecutions.some((tool) => tool.name === toolName)).toBe(true)
          for (const task of host.ctx.agentTeams
            .listTasks(lead)
            .filter((task) => ['runtime-reader', 'teams-reader'].includes(task.ownerName ?? '')))
            expect(
              consumedLeadExecutions.some(
                (tool) => tool.name === 'team_task_get' && tool.taskId === safeId(String(task.id)),
              ),
              'Lead follow-up must inspect each completed task',
            ).toBe(true)
          expect(
            teamReceipts
              .filter((receipt) => receipt.scene === 'B')
              .every((receipt) => receipt.eventIndex < bConsumeEnd),
          ).toBe(true)
          const consumedAnswer = required(
            answers.findLast(
              (answer) =>
                answer.scene === 'B' &&
                answer.session === safeId(String(leadSessionId)) &&
                answer.eventIndex > bConsumeUserIndex &&
                answer.eventIndex < bConsumeEnd,
            ),
            'Expected the Lead model to answer after receiving both member reports',
          )
          const reportReceipts = teamReceipts.filter(
            (receipt) =>
              receipt.scene === 'B' &&
              receipt.session === safeId(String(leadSessionId)) &&
              receipt.reportMarker !== undefined,
          )
          expect(reportReceipts).toHaveLength(2)
          for (const receipt of reportReceipts) {
            expect(receipt.eventIndex).toBeLessThan(consumedAnswer.eventIndex)
            expect(consumedAnswer.text).toContain(`${receipt.reportMarker}_${runId.slice(0, 8)}`)
          }
          const leadLog = await host.ctx.sessionPersistence.open(lead.id, 'read')
          try {
            const log = (await leadLog.read()).events
            expect(log.some((event) => event.type === 'assistant/message')).toBe(true)
            const lastAssistant = log.findLast((event) => event.type === 'assistant/message')
            for (const receipt of reportReceipts) {
              expect(log.some((event) => event.type === 'user/message' && event.data.id === receipt.messageId)).toBe(
                true,
              )
              expect(required(lastAssistant).seq).toBeGreaterThan(receipt.seq)
            }
            const answer = lastAssistant?.data.message.content
              .filter((block) => block.type === 'text')
              .map((block) => block.text)
              .join('')
            expect(answer).toContain('inbox.ts')
            expect(answer).toContain('mailbox.ts')
            for (const receipt of reportReceipts)
              expect(answer).toContain(`${receipt.reportMarker}_${runId.slice(0, 8)}`)
          } finally {
            await leadLog.close()
          }
          await capture('B', 'end', {
            roster: roster.map((member) => member.name),
            tasks: host.ctx.agentTeams.listTasks(lead).length,
            nativeReads: nativeReadEvidence.filter((read) => read.scene === 'B'),
          })
          scenarioStatuses.B = 'passed'
        }

        if (scenarios === 'teams-only') {
          for (const scene of ['C', 'D'] as const)
            writePrivate(
              join(evidenceDir, `${scene}-not-run.json`),
              JSON.stringify({ status: 'not-run', reason: 'teams-only lane' }),
            )
        } else {
          // C: Ask controls run either Lead-only or Lead-and-member according to the selected lane.
          resetScene('C')
          const controlsLane = scenarios === 'controls' || scenarios === 'stop-only'
          const operationIds =
            scenarios === 'stop-only'
              ? ([] as const)
              : controlsLane
                ? (['lead-allow', 'lead-reject'] as const)
                : (['lead-allow', 'member-allow', 'lead-reject', 'member-reject'] as const)
          await capture('C', 'start', {
            coverage:
              scenarios === 'stop-only'
                ? 'not-run'
                : controlsLane
                  ? 'lead-only-2-decisions'
                  : 'lead-and-member-4-decisions',
            requiredDecisions: operationIds.length,
            memberDecisions: controlsLane ? 'not-run' : 'included',
          })
          if (controlsLane) {
            writePrivate(
              join(evidenceDir, 'C-members-not-run.json'),
              JSON.stringify({
                status: 'not-run',
                reason:
                  scenarios === 'stop-only'
                    ? 'stop-only lane skips all C approvals'
                    : 'controls lane covers Lead approvals only',
              }),
            )
          }
          if (controlsLane || scenarios === 'approvals') {
            await withPhase('C:lead-warmup', async () => {
              const toolCount = tools.length
              const dispatchCount = budget.totalDispatches
              const marker = `LONGTASK_CONTROLS_WARMUP_${runId.slice(0, 8)}`
              await sendPrompt(`Reply exactly READY without using any tools. Marker ${marker}.`, marker)
              expect(leadSessionId).toBeDefined()
              expect(leadAgent).toBeDefined()
              expect(tools).toHaveLength(toolCount)
              expect(budget.totalDispatches).toBe(dispatchCount)
            })
          }
          if (scenarios === 'approvals') {
            // A real native child is fixture setup here, independent of B's source-reading task.
            // This lane does not certify an Agent invocation of spawn_teammate.
            const setupController = new AbortController()
            try {
              await withPhase('C:member-setup', async () => {
                const lead = required(leadAgent)
                expect(host.ctx.agentTeams.listMembers(lead)).toHaveLength(1)
                const before = events.length
                const toolCount = tools.length
                const dispatchCount = budget.totalDispatches
                const approvalCount = approvalEvidence.length
                const marker = `LONGTASK_MEMBER_READY_${runId.slice(0, 8)}`
                const { member } = await host.ctx.agentTeams.spawnTeammate(lead, {
                  name: 'runtime-reader',
                  description: 'Isolated member approval regression',
                  prompt: [{ type: 'text', text: `Reply exactly ${marker} without using any tools.` }],
                  context: 'fresh',
                  provider: 'spawn',
                  signal: setupController.signal,
                })
                runtimeReaderId = member.id
                memberSessionIds.add(String(member.id))
                teamMemberFacts.push({ id: String(member.id), name: member.name, role: String(member.role) })
                expect(member).toMatchObject({ name: 'runtime-reader', provider: 'spawn', context: 'fresh' })
                const child = required(host.ctx.agents.get(member.id))
                expect(child.options).toMatchObject({ provider: profile.provider, model: profile.model })
                expect(child.session.header.cwd).toBe(lead.session.header.cwd)
                await waitForTurn(member.id, before - 1)
                expect(
                  answers.some(
                    (answer) => answer.session === safeId(String(member.id)) && answer.text.includes(marker),
                  ),
                ).toBe(true)
                expect(host.ctx.agentTeams.listMembers(lead)).toHaveLength(2)
                await waitFor(
                  () =>
                    expect(
                      host.ctx.agentTeams
                        .listMembers(lead)
                        .every((entry) => ['idle', 'inactive'].includes(entry.status)),
                    ).toBe(true),
                  { timeout: Math.max(1, Math.min(10_000, phaseDeadlineAt - Date.now())), interval: 100 },
                )
                expect(tools).toHaveLength(toolCount)
                expect(budget.totalDispatches).toBe(dispatchCount)
                expect(approvalEvidence).toHaveLength(approvalCount)
                expect(events.filter((event) => isApprovalAsked(event))).toHaveLength(0)
                await capture('C', 'member-setup', {
                  setupRoute: 'host-service',
                  agentSpawnToolVerified: false,
                  members: 2,
                  member: safeId(String(member.id)),
                  context: 'fresh',
                  model: child.options.model,
                })
              })
            } catch (error) {
              setupController.abort(error)
              throw error
            }
          }
          if (scenarios === 'stop-only')
            writePrivate(
              join(evidenceDir, 'C-not-run.json'),
              JSON.stringify({ status: 'not-run', reason: 'stop-only lane validates D without C approvals' }),
            )
          const operationDir = join(host.workspaceCwd, 'workspace', 'long-task-operations')
          mkdirSync(operationDir, { recursive: true, mode: 0o700 })
          const destinations = new Map(operationIds.map((id) => [id, join(operationDir, `${id}-${runId}.txt`)]))
          for (const target of destinations.values()) expect(existsSync(target)).toBe(false)
          await (host.ctx.get('dshAcp') as AcpRemoteService).setToolApprovalPolicy(required(leadAgent).id, {
            policy: 'ask',
          })
          if (scenarios === 'approvals')
            expect(
              await (host.ctx.get('dshAcp') as AcpRemoteService).toolApprovalPolicy(String(required(runtimeReaderId))),
            ).toMatchObject({ policy: 'ask', source: 'lead', editable: false })

          const handleApproval = async (
            actor: 'lead' | 'member',
            operation: (typeof operationIds)[number],
            outcome: 'Allow once' | 'Reject',
          ): Promise<void> => {
            const memberId = runtimeReaderId
            if (actor === 'member' && memberId === undefined) throw new Error('LONG_TASK_MEMBER_CONTROLS_NOT_RUN')
            const owner = actor === 'lead' ? String(leadSessionId) : String(required(memberId))
            const destination = required(destinations.get(operation))
            const command = `printf '%s' '${operation}-${runId}' >> '${destination}'`
            const operationMarker = `${operation}-${runId}`
            operationCommands.set(operation, command)
            operationOwners.set(operation, owner)
            registerNativeExecute({ scene: 'C', ownerDshSessionId: owner, operation, command })
            const start = events.length
            const posted = await postPrompt(
              actor === 'lead'
                ? `Use the native DSH bash tool to run exactly this command once: ${command}. It writes only a unique file under the test workspace. Do not use a different tool. Wait for DSH Ask approval. If rejected, do not retry; report the rejection and complete the turn. Marker LONGTASK_C_${operation}_${runId.slice(0, 8)}.`
                : `Use the DSH send_message tool to ask runtime-reader to run exactly this command once using its normal bash tool: ${command}. Tell it not to retry if rejected and to report the result to you, including operation ID ${operationMarker}. Wait for its result and report the outcome. For this bounded test phase, if you use the DSH wait_agent tool, pass only {"timeout_ms":30000}; do not pass target or any other arguments. Use list_agents({}) before waiting as required by the current DSH instructions. Marker LONGTASK_C_${operation}_${runId.slice(0, 8)}.`,
              `LONGTASK_C_${operation}_${runId.slice(0, 8)}`,
              leadSessionId,
            )
            const handledRequestIds = new Set<string>()
            let targetDecisionSeen = false
            let operationActorCompleted = false
            while (!operationActorCompleted) {
              assertHealthy()
              const ownerEnd =
                actor === 'member'
                  ? events.find(
                      (event, index) =>
                        index >= start && event.sessionId === required(runtimeReaderId) && event.type === 'turn/end',
                    )
                  : undefined
              const leadEnd = events.find(
                (event, index) =>
                  index >= posted.userIndex && event.sessionId === posted.sessionId && event.type === 'turn/end',
              )
              operationActorCompleted =
                targetDecisionSeen &&
                (actor === 'member'
                  ? ownerEnd?.type === 'turn/end' && ownerEnd.data.reason.kind === 'completed'
                  : (leadEnd?.type === 'turn/end' && leadEnd.data.reason.kind === 'completed') ||
                    (profileName === 'codebuddy' &&
                      actor === 'lead' &&
                      operation === 'lead-reject' &&
                      rejectionCancellation?.confirmed === true))
              if (operationActorCompleted) break
              const pendingAsk = events
                .slice(start)
                .find(
                  (event) =>
                    isApprovalAsked(event) &&
                    !handledRequestIds.has(event.data.id) &&
                    !events.some(
                      (candidate) =>
                        isApprovalDecided(candidate) &&
                        candidate.sessionId === event.sessionId &&
                        candidate.data.id === event.data.id,
                    ),
                )
              if (pendingAsk === undefined) {
                await waitForEventChange()
                continue
              }
              const asked = pendingAsk
              if (!isApprovalAsked(asked)) throw new Error('LONG_TASK_APPROVAL_REQUEST_MISSING')
              handledRequestIds.add(asked.data.id)
              const requestEventIndex = events.findIndex(
                (event) =>
                  isApprovalAsked(event) && event.sessionId === asked.sessionId && event.data.id === asked.data.id,
              )
              expect(requestEventIndex).toBeGreaterThan(posted.userIndex)
              const requestOwner = String(asked.sessionId)
              const isReadOnlyCoordinationAsk = isMemberApprovalCoordination({
                scene: 'C',
                phase: activePhase,
                owner: requestOwner,
                lead: leadSessionId === undefined ? undefined : String(leadSessionId),
                member: runtimeReaderId === undefined ? undefined : String(runtimeReaderId),
                toolName: asked.data.toolName,
                args: memberCoordinationArguments(asked.data.toolName, asked.data.reason),
                relaySucceeded: successfulMemberRelays.has(operation),
              })
              if (!isReadOnlyCoordinationAsk) expect(JSON.stringify(asked.data)).toContain(operationMarker)
              const card =
                requestOwner === String(leadSessionId)
                  ? required(page)
                      .locator('[data-approval-key]')
                      .filter({ hasText: isReadOnlyCoordinationAsk ? asked.data.toolName : operationMarker })
                  : required(page)
                      .locator('[data-acp-team-approvals] [data-team-pending-member="runtime-reader"]')
                      .filter({ hasText: isReadOnlyCoordinationAsk ? asked.data.toolName : operationMarker })
              await card.waitFor({ state: 'visible', timeout: Math.max(1, phaseDeadlineAt - Date.now()) })
              expect(await card.count()).toBe(1)
              const cardText = await card.innerText()
              const nativeApproval = nativeExecuteObserver.matchApproval({
                scene: 'C',
                ownerDshSessionId: requestOwner,
                operation,
                reason: asked.data.reason,
                cardText,
              })
              const isHostOperation =
                asked.type === 'approval/asked' && asked.data.toolName === 'bash' && requestOwner === owner
              const isNativeOperation = nativeApproval !== undefined
              const isOperation = isHostOperation || isNativeOperation
              const isCoordinationAsk =
                !isOperation &&
                actor === 'member' &&
                (asked.data.toolName === 'send_message' || isReadOnlyCoordinationAsk)
              const permissionRoute =
                isNativeOperation && isHostOperation
                  ? 'both'
                  : isNativeOperation
                    ? 'native-permission'
                    : isHostOperation
                      ? 'host-approval'
                      : 'team-coordination'
              assertHealthy()
              expect(isOperation || isCoordinationAsk).toBe(true)
              if (isNativeOperation) {
                const command = required(operationCommands.get(operation))
                expect(asked.data.reason).toContain(command)
                expect(cardText).toContain(command)
                expect(asked.data.reason).toContain(operationMarker)
                expect(cardText).toContain(operationMarker)
              }
              if (
                profileName === 'codebuddy' &&
                actor === 'lead' &&
                operation === 'lead-reject' &&
                outcome === 'Reject' &&
                isOperation &&
                isNativeOperation
              ) {
                if (rejectionCancellation !== undefined) throw new Error('LONG_TASK_REJECTION_GATE_ALREADY_ACTIVE')
                const diagnosticOwner = nativeDiagnosticModule?.liveDiagnosticId('dsh-session', requestOwner)
                const prompt = [...promptTraces]
                  .reverse()
                  .find(
                    (candidate) =>
                      candidate.scene === 'C' &&
                      candidate.phase === activePhase &&
                      candidate.owner === diagnosticOwner &&
                      candidate.promptOrdinal !== undefined &&
                      candidate.leaseId !== undefined &&
                      candidate.stopReason === undefined,
                  )
                const promptOrdinal = prompt?.promptOrdinal
                const leaseId = prompt?.leaseId
                const marker = `LONGTASK_C_${operation}_${runId.slice(0, 8)}`
                const turn = claimedTurnByMarker.get(marker)
                if (
                  prompt === undefined ||
                  diagnosticOwner === undefined ||
                  turn === undefined ||
                  promptOrdinal === undefined ||
                  leaseId === undefined ||
                  nativeApproval === undefined
                )
                  throw new Error('LONG_TASK_REJECTION_GATE_EVIDENCE_UNAVAILABLE')
                rejectionCancellation = {
                  expected: {
                    profile: 'codebuddy',
                    scene: 'C',
                    phase: activePhase,
                    operation,
                    owner: diagnosticOwner,
                    acpSession: prompt.acpSession,
                    requestId: safeId(`approval-request:${asked.data.id}`),
                    promptOrdinal,
                    leaseId,
                    turn,
                    callId: nativeApproval.callId,
                  },
                  prompt,
                  requestIdRaw: asked.data.id,
                  requestEventIndex,
                  destination,
                  confirmed: false,
                  consumed: false,
                }
              }
              if (isOperation) expect(existsSync(destination)).toBe(false)
              await capture('C', `${operation}-pending-${handledRequestIds.size}`, {
                actor,
                session: safeId(requestOwner),
                expectedOutcome: isOperation ? outcome : 'Allow once',
                approvalTool: asked.data.toolName,
                permissionRoute,
              })
              await card.getByRole('button', { name: isOperation ? outcome : 'Allow once', exact: true }).click()
              const expectedDecision = isOperation
                ? outcome === 'Allow once'
                  ? 'allowed-once'
                  : 'rejected'
                : 'allowed-once'
              await waitFor(
                () => {
                  assertHealthy()
                  const decided = events.find(
                    (event) =>
                      isApprovalDecided(event) &&
                      String(event.sessionId) === requestOwner &&
                      event.data.id === asked.data.id,
                  )
                  expect(isApprovalDecided(decided) ? decided.data.outcome : undefined).toBe(expectedDecision)
                },
                { timeout: Math.max(1, phaseDeadlineAt - Date.now()), interval: 150 },
              )
              approvalEvidence.push({
                operation,
                session: safeId(requestOwner),
                request: safeId(asked.data.id),
                requestEventIndex,
                toolName: asked.data.toolName,
                outcome: expectedDecision,
                auditOwner: asked.type === 'acp-approval/asked' ? 'acp-sidecar' : 'native-session',
                permissionRoute,
              })
              if (isNativeOperation) {
                const remoteCancelledReject =
                  profileName === 'codebuddy' &&
                  actor === 'lead' &&
                  operation === 'lead-reject' &&
                  outcome === 'Reject' &&
                  rejectionCancellation !== undefined
                if (!remoteCancelledReject) {
                  const terminal = outcome === 'Allow once' ? ['completed'] : ['failed', 'cancelled']
                  await waitFor(
                    () => {
                      assertHealthy()
                      const matching = nativeExecuteObserver
                        .evidence()
                        .filter(
                          (entry) =>
                            entry.scene === 'C' &&
                            entry.owner === safeId(`dsh-session:${requestOwner}`) &&
                            entry.operation === operation,
                        )
                      expect(matching).toHaveLength(1)
                      expect(terminal).toContain(matching[0]?.status)
                    },
                    { timeout: Math.max(1, phaseDeadlineAt - Date.now()), interval: 150 },
                  )
                }
              }
              if (isOperation) operationPermissionRoutes.set(operation, permissionRoute)
              if (isOperation) targetDecisionSeen = true
            }
            expect(
              approvalEvidence.filter(
                (entry) => entry.operation === operation && entry.permissionRoute !== 'team-coordination',
              ),
            ).toHaveLength(1)
            if (outcome === 'Allow once') {
              await waitFor(() => expect(readFileSync(destination, 'utf8')).toBe(`${operation}-${runId}`), {
                timeout: Math.max(1, phaseDeadlineAt - Date.now()),
              })
            } else expect(existsSync(destination)).toBe(false)
            if (actor === 'lead') {
              if (rejectionCancellation?.expected.operation !== operation || !rejectionCancellation.confirmed)
                await waitForTurn(posted.sessionId, posted.userIndex)
            } else {
              await waitFor(
                () => {
                  assertHealthy()
                  const memberEnd = events.find(
                    (event, index) =>
                      index >= start && event.sessionId === required(runtimeReaderId) && event.type === 'turn/end',
                  )
                  expect(memberEnd?.type === 'turn/end' ? memberEnd.data.reason.kind : undefined).toBe('completed')
                },
                { timeout: Math.max(1, phaseDeadlineAt - Date.now()), interval: 150 },
              )
              await waitForTurn(posted.sessionId, posted.userIndex)
            }
            await capture('C', `${operation}-settled`, { actor, outcome, fileWritten: outcome === 'Allow once' })
            const nativeCalls = nativeExecuteObserver
              .evidence()
              .filter((entry) => entry.scene === 'C' && entry.operation === operation)
            const operationTools = tools.filter((tool) => tool.operationId === operation)
            const classifiedExecutionRoute = classifyExecutionRoute({
              decision: outcome === 'Allow once' ? 'allow' : 'reject',
              hostAdmissions: operationAdmissions.get(operation) ?? 0,
              hostResults: operationTools,
              nativeCalls,
              fileExists: existsSync(destination),
              fileContents: existsSync(destination) ? readFileSync(destination, 'utf8') : undefined,
              expectedContents: `${operation}-${runId}`,
            })
            const executionRoute =
              profileName === 'codebuddy' &&
              actor === 'lead' &&
              operation === 'lead-reject' &&
              rejectionCancellation?.confirmed === true
                ? 'not-dispatched'
                : classifiedExecutionRoute
            operationExecutionRoutes.set(operation, executionRoute)
            if (outcome === 'Allow once') expect(['host-tool', 'native-execute']).toContain(executionRoute)
            else expect(executionRoute).toBe('not-dispatched')
          }
          const approvalPlan =
            scenarios === 'stop-only'
              ? ([] as const)
              : controlsLane
                ? ([
                    ['lead', 'lead-allow', 'Allow once'],
                    ['lead', 'lead-reject', 'Reject'],
                  ] as const)
                : ([
                    ['lead', 'lead-allow', 'Allow once'],
                    ['member', 'member-allow', 'Allow once'],
                    ['lead', 'lead-reject', 'Reject'],
                    ['member', 'member-reject', 'Reject'],
                  ] as const)
          for (const [actor, operation, outcome] of approvalPlan)
            await withPhase(`C:${operation}`, () => handleApproval(actor, operation, outcome))
          for (const operation of operationIds) {
            const allowed = operation.endsWith('-allow')
            if (allowed)
              expect(readFileSync(required(destinations.get(operation)), 'utf8')).toBe(`${operation}-${runId}`)
            else expect(existsSync(required(destinations.get(operation)))).toBe(false)
            const route = required(operationExecutionRoutes.get(operation))
            if (allowed) expect(['host-tool', 'native-execute']).toContain(route)
            else expect(route).toBe('not-dispatched')
          }
          if (operationIds.length > 0) {
            const resumeMarker = `LONGTASK_C_RESUME_${runId.slice(0, 8)}`
            const resumeStartIndex = events.length
            const resumedSession = await withPhase('C:resume-summary', () =>
              sendPrompt(
                `Continue the same session. Summarize these approval outcomes using their operation IDs: ${operationIds.join(', ')}. Do not run more tools. Marker LONGTASK_C_RESUME_${runId.slice(0, 8)}.`,
                resumeMarker,
                leadSessionId,
              ),
            )
            await checkModelSnapshot(String(resumedSession), 'after-approval-resume')
            if (rejectionCancellation !== undefined) {
              const resumeOwner = nativeDiagnosticModule?.liveDiagnosticId('dsh-session', String(resumedSession))
              const resumePrompt = [...promptTraces]
                .reverse()
                .find(
                  (candidate) =>
                    candidate.scene === 'C' &&
                    candidate.phase === 'C:resume-summary' &&
                    candidate.owner === resumeOwner &&
                    candidate.stopReason !== undefined,
                )
              expect(resumePrompt, 'Expected the follow-up to use a real ACP prompt').toBeDefined()
              expect(resumePrompt?.acpSession).toBe(rejectionCancellation.expected.acpSession)
              expect(resumePrompt?.stopReason).toBe('end_turn')
              const resumeUserIndex = events.findIndex(
                (event) =>
                  event.sessionId === resumedSession &&
                  event.type === 'user/message' &&
                  JSON.stringify(event.data.content).includes(resumeMarker),
              )
              expect(resumeUserIndex).toBeGreaterThanOrEqual(0)
              const previousOperationMarker = `LONGTASK_C_lead-reject_${runId.slice(0, 8)}`
              expect(
                events.some(
                  (event, index) =>
                    index < resumeUserIndex &&
                    event.sessionId === resumedSession &&
                    event.type === 'user/message' &&
                    JSON.stringify(event.data.content).includes(previousOperationMarker),
                ),
              ).toBe(true)
              const endIndex = rejectionCancellation.turnEndEventIndex
              if (controlsLane && rejectionCancellation.confirmed) {
                expect(endIndex).toBeDefined()
                const recoveryMessages = events.filter(
                  (event, index) =>
                    index > required(endIndex) && event.sessionId === resumedSession && event.type === 'user/message',
                )
                expect(recoveryMessages).toHaveLength(1)
                expect(
                  recoveryMessages.some(
                    (event) =>
                      event.type === 'user/message' && JSON.stringify(event.data.content).includes(resumeMarker),
                  ),
                ).toBe(true)
              }
              await capture(
                'C',
                rejectionCancellation.confirmed ? 'after-rejected-cancel-resume' : 'after-approval-resume',
                {
                  sameAcpBinding: true,
                  rejectedCancellationConfirmed: rejectionCancellation.confirmed,
                  priorOperationRetainedInSessionEvents: true,
                  followupAssistantObserved: events.some(
                    (event, index) =>
                      index >= resumeStartIndex &&
                      event.sessionId === resumedSession &&
                      event.type === 'assistant/message',
                  ),
                  followupMarker: resumeMarker,
                  followupUserCount: controlsLane ? 1 : 'not-counted',
                },
              )
            }
          }
          const cModelSnapshots = modelSnapshots.filter((entry) => entry.session === safeId(String(leadSessionId)))
          if (cModelSnapshots.some((entry) => entry.modeObserved))
            expect(
              cModelSnapshots.filter((entry) => entry.modeObserved).every((entry) => entry.modePreserved !== false),
            ).toBe(true)
          await capture('C', scenarios === 'stop-only' ? 'not-run' : 'end', {
            coverage:
              scenarios === 'stop-only'
                ? 'not-run'
                : controlsLane
                  ? 'lead-only-2-decisions'
                  : 'lead-and-member-4-decisions',
            memberDecisions: controlsLane ? 'not-run' : 'completed',
            allowed: operationIds.filter((operation) => operation.endsWith('-allow')).length,
            rejected: operationIds.filter((operation) => operation.endsWith('-reject')).length,
            acpExecutePermissions: nativeExecuteObserver.evidence().filter((entry) => entry.scene === 'C'),
            rejectedCancellation: rejectionCancellationEvidence,
            permissionRoutes: Object.fromEntries(operationPermissionRoutes),
            executionRoutes: Object.fromEntries(operationExecutionRoutes),
            sideEffects: {
              allowed: operationIds.filter((operation) => operation.endsWith('-allow')).length,
              rejected: 0,
            },
          })
          scenarioStatuses.C = scenarios === 'stop-only' ? 'not-run' : controlsLane ? 'partial' : 'passed'

          // D: a genuine shell process is interrupted, the page reloads, and queued input remains unsent.
          resetScene('D')
          await capture('D', 'start', { session: safeId(String(leadSessionId)) })
          const longStarted = join(operationDir, `long-start-${runId}.txt`)
          const longFinished = join(operationDir, `long-finished-${runId}.txt`)
          const queuedMarker = `LONGTASK_D_QUEUED_${runId.slice(0, 8)}`
          const longMarker = `LONGTASK_D_RUNNING_${runId.slice(0, 8)}`
          const resumeMarker = `LONGTASK_D_RESUME_${runId.slice(0, 8)}`
          const shellCommand = `printf '%s' '${longMarker}' >> '${longStarted}'; sleep 120; printf '%s' '${runId}' > '${longFinished}'`
          registeredLongCommand = shellCommand
          operationCommands.set('D:long-running', shellCommand)
          registerNativeExecute({
            scene: 'D',
            ownerDshSessionId: String(leadSessionId),
            operation: 'D:long-running',
            command: shellCommand,
          })
          await (host.ctx.get('dshAcp') as AcpRemoteService).setToolApprovalPolicy(required(leadAgent).id, {
            policy: 'ask',
          })
          const turnBefore = events.filter(
            (event) => event.sessionId === leadSessionId && event.type === 'user/message',
          ).length
          const dText = `Use the native DSH bash tool to run exactly this long shell command once: ${shellCommand}. Set timeoutMs to 120000 and run_in_background to false. Do not cancel it yourself and do not run another command. Marker ${longMarker}.`
          await withPhase('D:stop-refresh-queue-resume', async () => {
            await writeComposerDraft(required(page), required(page).locator('[data-composer-input]').first(), dText)
            const dBefore = events.length
            await required(page).getByRole('button', { name: 'Send message', exact: true }).click()
            await waitFor(
              () =>
                expect(
                  events
                    .slice(dBefore)
                    .some(
                      (event) =>
                        event.type === 'user/message' && JSON.stringify(event.data.content).includes(longMarker),
                    ),
                ).toBe(true),
              {
                timeout: Math.max(1, phaseDeadlineAt - Date.now()),
              },
            )
            const dUserIndex = events.findIndex(
              (event, index) =>
                index >= dBefore &&
                event.type === 'user/message' &&
                JSON.stringify(event.data.content).includes(longMarker),
            )
            const approval = required(page).locator('[data-approval-key]')
            await approval.waitFor({ timeout: Math.max(1, phaseDeadlineAt - Date.now()) })
            const dAsked = events
              .slice(dBefore)
              .find(
                (event) =>
                  isApprovalAsked(event) &&
                  event.sessionId === leadSessionId &&
                  event.data.reason?.includes(shellCommand),
              )
            const dNativeMatch = nativeExecuteObserver.matchApproval({
              scene: 'D',
              ownerDshSessionId: String(leadSessionId),
              operation: 'D:long-running',
              reason: isApprovalAsked(dAsked) ? dAsked.data.reason : undefined,
              cardText: await approval.innerText(),
            })
            assertHealthy()
            const dHostApproval = dAsked?.type === 'approval/asked' && dAsked.data.toolName === 'bash'
            const dPermissionRoute =
              dNativeMatch !== undefined && dHostApproval
                ? 'both'
                : dNativeMatch !== undefined
                  ? 'native-permission'
                  : 'host-approval'
            operationPermissionRoutes.set('D:long-running', dPermissionRoute)
            expect(dNativeMatch !== undefined || dHostApproval).toBe(true)
            if (dNativeMatch !== undefined) {
              expect(isApprovalAsked(dAsked) ? dAsked.data.reason : undefined).toContain(shellCommand)
              expect(await approval.innerText()).toContain(shellCommand)
              expect(isApprovalAsked(dAsked) ? dAsked.data.reason : undefined).toContain(longMarker)
              expect(await approval.innerText()).toContain(longMarker)
            }
            await approval.getByRole('button', { name: 'Allow once', exact: true }).click()
            if (isApprovalAsked(dAsked)) {
              const requestEventIndex = events.findIndex(
                (event) =>
                  isApprovalAsked(event) && event.sessionId === dAsked.sessionId && event.data.id === dAsked.data.id,
              )
              approvalEvidence.push({
                operation: 'D:long-running',
                session: safeId(String(leadSessionId)),
                request: safeId(dAsked.data.id),
                requestEventIndex,
                toolName: dAsked.data.toolName,
                outcome: 'allowed-once',
                auditOwner: dAsked.type === 'acp-approval/asked' ? 'acp-sidecar' : 'native-session',
                permissionRoute: dPermissionRoute,
              })
            }
            await waitFor(() => expect(readFileSync(longStarted, 'utf8')).toBe(longMarker), {
              timeout: Math.max(1, phaseDeadlineAt - Date.now()),
            })
            dExecutionRoute =
              dLongAdmissions === 1 && dLongCallIds.size === 1
                ? 'host-tool'
                : dLongAdmissions === 0 && dLongCallIds.size === 0 && dNativeMatch !== undefined
                  ? 'native-execute'
                  : 'unknown'
            operationExecutionRoutes.set('D:long-running', dExecutionRoute)
            expect(dExecutionRoute).not.toBe('unknown')
            const composer = required(page).locator('[data-composer-input]').first()
            await writeComposerDraft(required(page), composer, queuedMarker)
            await required(page).getByRole('button', { name: 'Queue message', exact: true }).click()
            const queued = required(page)
              .locator('[data-queue-dock]')
              .getByRole('listitem')
              .filter({ hasText: queuedMarker })
            await queued.waitFor()
            await waitFor(
              async () => {
                assertHealthy()
                expect(await queued.getAttribute('data-submission-echo')).toBeNull()
              },
              { timeout: Math.max(1, phaseDeadlineAt - Date.now()), interval: 150 },
            )
            expect(
              events.find(
                (event, index) => index >= dUserIndex && event.sessionId === leadSessionId && event.type === 'turn/end',
              ),
            ).toBeUndefined()
            await capture('D', 'running-queued', {
              startedMarker: true,
              queued: true,
              acpExecutePermissions: nativeExecuteObserver.evidence().filter((entry) => entry.scene === 'D'),
              jobs: jobSnapshot(),
            })
            await required(page).reload()
            await queued.waitFor()
            await waitFor(
              async () => {
                assertHealthy()
                expect(await queued.getAttribute('data-submission-echo')).toBeNull()
              },
              { timeout: Math.max(1, phaseDeadlineAt - Date.now()), interval: 150 },
            )
            await capture('D', 'after-refresh', {
              queued: true,
              acpExecutePermissions: nativeExecuteObserver.evidence().filter((entry) => entry.scene === 'D'),
              jobs: jobSnapshot(),
            })
            expect(
              events.find(
                (event, index) => index > dUserIndex && event.sessionId === leadSessionId && event.type === 'turn/end',
              ),
            ).toBeUndefined()
            expect(tools.filter((tool) => tool.operationId === 'D:long-running')).toHaveLength(0)
            expect(expectedDAbortTurn).toBe(claimedTurnByMarker.get(longMarker))
            expectingDStop = true
            await required(page).getByRole('button', { name: 'Stop generating', exact: true }).click()
            await waitFor(
              () => {
                assertHealthy()
                const end = events.find(
                  (event, index) =>
                    index > dUserIndex &&
                    event.sessionId === leadSessionId &&
                    event.type === 'turn/end' &&
                    event.data.turn === expectedDAbortTurn,
                )
                expect(end?.type === 'turn/end' ? end.data.reason.kind : undefined).toBe('aborted')
              },
              { timeout: Math.max(1, phaseDeadlineAt - Date.now()), interval: 150 },
            )
            expectingDStop = false
            expect(readFileSync(longStarted, 'utf8')).toBe(longMarker)
            expect(existsSync(longFinished)).toBe(false)
            if (dNativeMatch !== undefined) {
              await waitFor(
                () => {
                  assertHealthy()
                  const matching = nativeExecuteObserver
                    .evidence()
                    .filter((entry) => entry.scene === 'D' && entry.operation === 'D:long-running')
                  expect(matching).toHaveLength(1)
                  expect(['completed', 'failed', 'cancelled']).toContain(matching[0]?.status)
                  if (dExecutionRoute === 'native-execute')
                    expect(['failed', 'cancelled']).toContain(matching[0]?.status)
                },
                { timeout: Math.max(1, phaseDeadlineAt - Date.now()), interval: 150 },
              )
            }
            const expectedJobOwner = safeId(`dsh-session:${String(leadSessionId)}`)
            const matchingJobEvents = () =>
              jobEvidence.filter(
                (entry) => entry.label === shellCommand && entry.owner === expectedJobOwner && entry.kind === 'bash',
              )
            if (matchingJobEvents().length > 0) {
              await waitFor(
                () => {
                  assertHealthy()
                  const settledByHost = matchingJobEvents().some(
                    (entry) => entry.event === 'settled' && entry.cause === 'kill' && entry.awaited === true,
                  )
                  expect(settledByHost).toBe(true)
                  expect(jobSnapshot().exactCommandActiveCount).toBe(0)
                },
                { timeout: Math.max(1, phaseDeadlineAt - Date.now()), interval: 150 },
              )
              dJobQuiescence = 'host-job-settlement'
            }
            const dNativeEvidence = nativeExecuteObserver
              .evidence()
              .filter((entry) => entry.scene === 'D' && entry.operation === 'D:long-running')
            if (dExecutionRoute === 'host-tool') {
              expect(dLongAdmissions).toBe(1)
              expect(dLongCallIds.size).toBe(1)
              expect(tools.filter((tool) => tool.operationId === 'D:long-running')).toHaveLength(1)
              expect(required(tools.find((tool) => tool.operationId === 'D:long-running')).isError).toBe(true)
            } else {
              expect(tools.filter((tool) => tool.operationId === 'D:long-running')).toHaveLength(0)
              expect(dNativeEvidence).toHaveLength(1)
              expect(['failed', 'cancelled']).toContain(dNativeEvidence[0]?.status)
            }
            expect(
              events.filter(
                (event, index) =>
                  index > dUserIndex &&
                  event.sessionId === leadSessionId &&
                  event.type === 'user/message' &&
                  JSON.stringify(event.data.content).includes(queuedMarker),
              ),
            ).toHaveLength(0)
            await queued.waitFor()
            await capture('D', 'stopped-queued', {
              turnAborted: true,
              queued: true,
              acpExecutePermissions: nativeExecuteObserver.evidence().filter((entry) => entry.scene === 'D'),
              jobs: jobSnapshot(),
            })
            await writeComposerDraft(
              required(page),
              composer,
              `Resume queued input once, then reply without tools. Marker ${resumeMarker}`,
            )
            await required(page).getByRole('button', { name: 'Send message', exact: true }).click()
            while (true) {
              assertHealthy()
              try {
                expect(
                  events.filter(
                    (event) =>
                      event.sessionId === leadSessionId &&
                      event.type === 'user/message' &&
                      JSON.stringify(event.data.content).includes(queuedMarker),
                  ),
                ).toHaveLength(1)
                expect(
                  events.filter(
                    (event) =>
                      event.sessionId === leadSessionId &&
                      event.type === 'user/message' &&
                      JSON.stringify(event.data.content).includes(resumeMarker),
                  ),
                ).toHaveLength(1)
                const queuedIndex = events.findIndex(
                  (event, index) =>
                    index > dUserIndex &&
                    event.sessionId === leadSessionId &&
                    event.type === 'user/message' &&
                    JSON.stringify(event.data.content).includes(queuedMarker),
                )
                const resumeIndex = events.findIndex(
                  (event, index) =>
                    index > dUserIndex &&
                    event.sessionId === leadSessionId &&
                    event.type === 'user/message' &&
                    JSON.stringify(event.data.content).includes(resumeMarker),
                )
                expect(queuedIndex).toBeGreaterThan(dUserIndex)
                expect(resumeIndex).toBeGreaterThan(queuedIndex)
                expect(
                  events.filter(
                    (event, index) =>
                      index > dUserIndex &&
                      event.sessionId === leadSessionId &&
                      event.type === 'turn/end' &&
                      event.data.reason.kind === 'completed',
                  ),
                ).toHaveLength(2)
                const queuedTurn = claimedTurnByMarker.get(queuedMarker)
                const resumeTurn = claimedTurnByMarker.get(resumeMarker)
                expect(queuedTurn).toBeDefined()
                expect(resumeTurn).toBeDefined()
                expect(queuedTurn).not.toBe(resumeTurn)
                const completedTurns = events
                  .filter(
                    (event, index) =>
                      index > dUserIndex &&
                      event.sessionId === leadSessionId &&
                      event.type === 'turn/end' &&
                      event.data.reason.kind === 'completed',
                  )
                  .map((event) => (event.type === 'turn/end' ? event.data.turn : undefined))
                expect(completedTurns).toContain(queuedTurn)
                expect(completedTurns).toContain(resumeTurn)
                break
              } catch {
                assertHealthy()
                await waitForEventChange()
              }
            }
            assertHealthy()
            expect(
              events.filter((event) => event.sessionId === leadSessionId && event.type === 'user/message'),
            ).toHaveLength(turnBefore + 3)
            const finalDRoute = required(operationExecutionRoutes.get('D:long-running'))
            expect(dLongAdmissions).toBe(finalDRoute === 'host-tool' ? 1 : 0)
            expect(tools.filter((tool) => tool.operationId === 'D:long-running')).toHaveLength(
              finalDRoute === 'host-tool' ? 1 : 0,
            )
            await checkModelSnapshot(String(leadSessionId), 'after-stop-queue-resume')
            const dModelSnapshots = modelSnapshots.filter((entry) => entry.session === safeId(String(leadSessionId)))
            if (dModelSnapshots.some((entry) => entry.modeObserved))
              expect(
                dModelSnapshots.filter((entry) => entry.modeObserved).every((entry) => entry.modePreserved !== false),
              ).toBe(true)
            await capture('D', 'end', {
              turnAborted: true,
              longCommandFinished: false,
              queuedInputDeliveredOnce: true,
              acpExecutePermissions: nativeExecuteObserver.evidence().filter((entry) => entry.scene === 'D'),
              jobs: jobSnapshot(),
              jobQuiescence: {
                hostJobSettlement: dJobQuiescence,
                managedRangeExit: 'not-observed',
              },
              acpExecutePermissionFacts: {
                executionRoute: dExecutionRoute,
                permissionRoute: dPermissionRoute,
                count: dNativeEvidence.length,
                status: dNativeEvidence[0]?.status ?? 'not-observed',
              },
            })
          })
          scenarioStatuses.D = dJobSettled() && dUsesHostTool() ? 'passed' : 'partial'
        }

        expect(stickyViolation).toBeUndefined()
        expect(errorTexts).toEqual([])
        expect(nativeDiagnosticModule.liveDiagnosticTraceFailureCount()).toBe(0)
        expect(nativeTraceEvents).toBeGreaterThan(0)
        expect(screenshotFailures).toEqual([])
        await Promise.all([...pendingScreenshotPromises])
        expect(screenshotFailures).toEqual([])
        expect(modelRouteObservations.length).toBeGreaterThan(0)
        expect(
          modelRouteObservations.every((entry) => entry.provider === profile.provider && entry.model === profile.model),
        ).toBe(true)
        expect(modelSnapshots.length).toBeGreaterThan(0)
        expect(modelSnapshots.every((entry) => entry.freshness === 'live' && entry.model === profile.model)).toBe(true)
        expect(runtimePromptChecks).toBeGreaterThan(0)
        const finalSource = evidenceSource.files.map((file) => {
          const digest = createHash('sha256')
            .update(readFileSync(sourcePathFor(join(host.workspaceCwd, 'workspace'), file.path)))
            .digest('hex')
          expect(digest, `Pinned source changed during the run: ${file.path}`).toBe(file.sha256)
          return { path: file.path, sha256: digest }
        })
        completedRunRecord = {
          status: Object.values(scenarioStatuses).some((status) => status === 'not-run' || status === 'partial')
            ? 'passed-with-skipped-scenarios'
            : 'passed',
          scenarios: scenarioStatuses,
          scenarioSelection: scenarios,
          nativeReads: nativeReadEvidence,
          nativeReadDiagnostics,
          acpExecutePermissions: nativeExecuteObserver.evidence(),
          teamPermissionEvidence: bPermissionEvidence,
          permissionRoutes: Object.fromEntries(operationPermissionRoutes),
          executionRoutes: Object.fromEntries(operationExecutionRoutes),
          rejectedCancellation: rejectionCancellationEvidence,
          jobQuiescence: {
            hostJobSettlement: dJobQuiescence,
            managedRangeExit: 'not-observed',
          },
          jobEvents: jobEvidence.map(({ event, id, owner, kind, status, startedAt, finishedAt, cause, awaited }) => ({
            event,
            id,
            ...(owner === undefined ? {} : { owner }),
            kind,
            status,
            startedAt,
            ...(finishedAt === undefined ? {} : { finishedAt }),
            ...(cause === undefined ? {} : { cause }),
            ...(awaited === undefined ? {} : { awaited }),
          })),
          agent: profileName,
          provider: profile.provider,
          model: profile.model,
          cliVersion,
          dshCommit: SOURCE_COMMIT,
          dshPluginVersion: packageJson.version,
          platform: process.platform,
          arch: process.arch,
          durationMs: Date.now() - startedAt,
          budget: {
            hostDispatches: budget.totalDispatches,
            sceneDispatches: budget.sceneDispatches,
            approvalRequests: budget.approvalRequests,
            providerToolCallsSoft: budget.providerToolCallIds.size,
            spawnAttempts: budget.spawnAttempts,
            repeatedEffects: [...budget.successfulEffectCounts.values()],
          },
          source: evidenceSource,
          sourceEnd: finalSource,
          tools,
          approvals,
          approvalEvidence,
          teamMessages: teamMessages.map((message) => ({
            scene: message.scene,
            session: message.session,
            type: message.type,
            ...(message.messageId === undefined ? {} : { messageId: safeId(message.messageId) }),
            ...(message.targetId === undefined ? {} : { target: safeId(message.targetId) }),
            ...(message.senderId === undefined ? {} : { sender: safeId(message.senderId) }),
            ...(message.reportMarker === undefined ? {} : { reportMarker: message.reportMarker }),
            eventIndex: message.eventIndex,
          })),
          teamReceipts: teamReceipts.map((receipt) => ({
            scene: receipt.scene,
            session: receipt.session,
            messageId: safeId(receipt.messageId),
            sender: receipt.senderId === undefined ? 'unavailable' : safeId(receipt.senderId),
            ...(receipt.reportMarker === undefined ? {} : { reportMarker: receipt.reportMarker }),
            eventIndex: receipt.eventIndex,
            seq: receipt.seq,
          })),
          turns,
          teamMembers: teamMemberFacts.map((member) => ({ ...member, id: safeId(member.id) })),
          modelSnapshots,
          modelRouteObservations,
          runtimePromptObservations,
          nativeRuntimePromptChecks: runtimePromptChecks,
          nativeTraceEvents,
          pageErrors: errorTexts,
          modelReviewFile: 'model-review.json',
        }
        writePrivate(join(evidenceDir, 'model-review.json'), JSON.stringify(answers, null, 2))
      } catch (error) {
        primaryFailure = error
        primaryFailureRecord = longTaskFailure(error, activePhase)
        failureController.abort(error)
        runFailed = true
        const cancelling = cancelAll(stickyViolation ?? 'LONG_TASK_PRIMARY_FAILURE')
        await capture(activeScene, 'failed', {
          phase: activePhase,
          failure: primaryFailureRecord,
          violation: stickyViolation,
        }).catch((captureError: unknown) => recordEvidenceFailure('failure-screenshot', captureError))
        try {
          writePrivate(join(evidenceDir, 'model-review.json'), JSON.stringify(answers, null, 2))
          writePrivate(
            join(evidenceDir, 'run.json'),
            JSON.stringify(
              {
                status: 'failed',
                primaryFailure: primaryFailureRecord,
                scenarios: scenarioStatuses,
                scenarioSelection: scenarios,
                nativeReads: nativeReadEvidence,
                nativeReadDiagnostics,
                acpExecutePermissions: nativeExecuteObserver.evidence(),
                teamPermissionEvidence: bPermissionEvidence,
                rejectedCancellation: rejectionCancellationEvidence,
                permissionRoutes: Object.fromEntries(operationPermissionRoutes),
                executionRoutes: Object.fromEntries(operationExecutionRoutes),
                jobQuiescence: {
                  hostJobSettlement: dJobQuiescence,
                  managedRangeExit: 'not-observed',
                },
                jobEvents: jobEvidence.map(
                  ({ event, id, owner, kind, status, startedAt, finishedAt, cause, awaited }) => ({
                    event,
                    id,
                    ...(owner === undefined ? {} : { owner }),
                    kind,
                    status,
                    startedAt,
                    ...(finishedAt === undefined ? {} : { finishedAt }),
                    ...(cause === undefined ? {} : { cause }),
                    ...(awaited === undefined ? {} : { awaited }),
                  }),
                ),
                agent: profileName,
                provider: profile.provider,
                model: profile.model,
                phase: activePhase,
                violation: stickyViolation,
                dispatches: budget.totalDispatches,
                approvals: budget.approvalRequests,
                tools,
                approvalEvidence,
                teamMessages: teamMessages.map((message) => ({
                  scene: message.scene,
                  session: message.session,
                  type: message.type,
                  ...(message.messageId === undefined ? {} : { messageId: safeId(message.messageId) }),
                  ...(message.targetId === undefined ? {} : { target: safeId(message.targetId) }),
                  ...(message.senderId === undefined ? {} : { sender: safeId(message.senderId) }),
                  ...(message.reportMarker === undefined ? {} : { reportMarker: message.reportMarker }),
                  eventIndex: message.eventIndex,
                })),
                teamReceipts: teamReceipts.map((receipt) => ({
                  scene: receipt.scene,
                  session: receipt.session,
                  messageId: safeId(receipt.messageId),
                  sender: safeId(receipt.senderId),
                  ...(receipt.reportMarker === undefined ? {} : { reportMarker: receipt.reportMarker }),
                  eventIndex: receipt.eventIndex,
                  seq: receipt.seq,
                })),
                turns,
                teamMembers: teamMemberFacts.map((member) => ({ ...member, id: safeId(member.id) })),
                modelSnapshots,
                modelRouteObservations,
                runtimePromptObservations,
                pageErrors: errorTexts,
                modelReviewFile: 'model-review.json',
                nativeRuntimePromptChecks: runtimePromptChecks,
                nativeTraceEvents,
                errorName: error instanceof Error ? error.name : 'UnknownError',
              },
              null,
              2,
            ),
          )
        } catch (writeError: unknown) {
          recordEvidenceFailure('failure-record', writeError)
        }
        await cancelling
        throw primaryFailure
      } finally {
        const cleanup: LongTaskSettlement[] = []
        cleanup.push(
          await settleLongTaskAction('screenshots', () => Promise.all([...pendingScreenshotPromises]), 'cleanup'),
        )
        if (runFailed || stickyViolation !== undefined) await cancelAll(stickyViolation ?? 'LONG_TASK_PRIMARY_FAILURE')
        cleanup.push(await settleLongTaskAction('host', host === undefined ? undefined : () => host.close(), 'cleanup'))
        cleanup.push(await settleLongTaskAction('job-observer', removeJobEvents, 'cleanup'))
        cleanup.push(await settleLongTaskAction('B-question-observer', restoreBQuestionObserver, 'cleanup'))
        for (const [index, restorePermissionHandler] of restoreRuntimePermissionHandlers.reverse().entries())
          cleanup.push(await settleLongTaskAction(`permission-observer-${index}`, restorePermissionHandler, 'cleanup'))
        cleanup.push(await settleLongTaskAction('prompt-observer', restoreRuntimePrompt, 'cleanup'))
        cleanup.push(await settleLongTaskAction('trace-observer', removeTrace, 'cleanup'))
        cleanup.push(
          await settleLongTaskAction(
            'browser',
            browser === undefined ? undefined : () => required(browser).close(),
            'cleanup',
          ),
        )
        // A scope violation remains a test failure even when every resource closes.
        // It is never relabelled as a cleanup failure merely because it was sticky.
        if (primaryFailureRecord === undefined) {
          const lateFailure =
            stickyViolation ??
            (screenshotFailures.length > 0
              ? 'LONG_TASK_SCREENSHOT_FAILURE'
              : errorTexts.length > 0
                ? 'LONG_TASK_PAGE_ERROR'
                : (nativeDiagnosticModule?.liveDiagnosticTraceFailureCount() ?? 0) > 0
                  ? 'LONG_TASK_DIAGNOSTIC_TRACE_FAILURE'
                  : undefined)
          if (lateFailure !== undefined) {
            primaryFailure = new Error(lateFailure)
            primaryFailureRecord = longTaskFailure(primaryFailure, activePhase)
            runFailed = true
          }
        }
        const lifecycle = {
          ...longTaskOutcome(primaryFailureRecord, cancellationOutcomes, cleanup),
          evidence: evidenceOutcomes,
        }
        try {
          writePrivate(join(evidenceDir, 'lifecycle.json'), JSON.stringify(lifecycle, null, 2))
          if (lifecycle.cleanupFailed)
            writePrivate(join(evidenceDir, 'cleanup.json'), JSON.stringify(lifecycle, null, 2))
          if (runFailed && existsSync(join(evidenceDir, 'run.json'))) {
            const failedRecord = JSON.parse(readFileSync(join(evidenceDir, 'run.json'), 'utf8')) as Record<
              string,
              unknown
            >
            writePrivate(join(evidenceDir, 'run.json'), JSON.stringify({ ...failedRecord, lifecycle }, null, 2))
          } else if (completedRunRecord !== undefined) {
            writePrivate(
              join(evidenceDir, 'run.json'),
              JSON.stringify(
                {
                  ...completedRunRecord,
                  ...(runFailed || lifecycle.finalizationFailed
                    ? { status: 'failed', primaryFailure: primaryFailureRecord }
                    : {}),
                  lifecycle,
                },
                null,
                2,
              ),
            )
          }
        } catch (writeError: unknown) {
          recordEvidenceFailure('final-record', writeError)
        }
        const finalFailure = finalLongTaskFailure(
          primaryFailureRecord === undefined ? undefined : { error: primaryFailure },
          evidenceOutcomes.length === 0 ? undefined : { error: evidenceFailure },
          lifecycle.finalizationFailed,
        )
        if (finalFailure !== undefined) throw finalFailure.error
      }
    },
    22 * 60_000,
  )
})
