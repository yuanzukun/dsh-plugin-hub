import type { Locator } from 'playwright'
import type { AcpRemoteService } from '../../src/remote/service.js'
import { required } from './required.ts'
import type { TestBrowser } from './browser.ts'
import { launchBrowser, newEnglishPage } from './browser.ts'
import type { ObservedEvent } from './types.ts'
import type { Page } from 'playwright'
import { LlmAdapter } from '@deepseek-ai/dsh-llm'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { join } from 'node:path'
import { mkdirSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
import { it, expect, vi } from 'vitest'
import { connectFreshWorkspace, writeComposerDraft } from '#host-support'
import { launchAdapterWorld, root } from './scaffold.ts'
import {
  installTeamFixtureApprovals,
  teamMemberSetupSteps,
  teamReplySteps,
  teamStartSteps,
} from './team-fixture-approval.ts'

it(
  'shows per-profile mode menus with dormant mode persistence and approval protection and preserves Lead approval layout',
  async () => {
    const host = await launchAdapterWorld({ teams: true })
    let browser!: TestBrowser
    let page!: Page
    const events: ObservedEvent[] = [],
      errors: string[] = []
    host.ctx.on('session/event', (session, event) => events.push({ sessionId: session.id, ...event }))
    const retain = process.env.DSH_E2E_RETAIN_MANAGEMENT === '1'
    const policyGate = join(host.workspaceCwd, 'team-management-policy-ready')
    type SetupCall = {
      owner: string
      callId: string
      tool: string
      args: Record<string, unknown> | ((agent: Agent) => Record<string, unknown>)
    }
    const calls = (owner: string, entries: readonly [string, SetupCall['args']][]): SetupCall[] =>
      entries.map(([tool, args], index) => ({ owner, callId: `team-${index + 1}`, tool, args }))
    const memberContinuation = (owner: string) =>
      calls(owner, [
        ['list_agents', {}],
        ['send_message', { target: 'lead', message: 'E2E_TEAM_REPLY continued' }],
      ])
    const tasks = new Map<string, ReturnType<typeof host.ctx.agentTeams.listTasks>[number]>()
    const originalTask = (agent: Agent, subject: string) => {
      const key = `${agent.id}:${subject}`
      if (!tasks.has(key))
        tasks.set(
          key,
          structuredClone(required(host.ctx.agentTeams.listTasks(agent).find((task) => task.subject === subject))),
        )
      return required(tasks.get(key))
    }
    let setupAnswers: ReturnType<typeof installTeamFixtureApprovals> | undefined
    try {
      await host.ctx.settings.replace('dsh-acp-adapter', {
        toolApprovalDefault: 'auto',
        agents: {
          devin: {
            name: 'ACP demo',
            command: process.execPath,
            args: [join(root, 'test/mock-agent/mock-agent.ts')],
            env: {
              HOME: host.workspaceCwd,
              MOCK_SCENARIO: 'regression',
              MOCK_PROFILE: 'devin',
              MOCK_MCP_HTTP: '1',
              MOCK_SESSION_NEW_DELAY_MS: '5000',
              MOCK_TEAM_PERMISSION_GATE: policyGate,
            },
          },
        },
      })
      await vi.waitFor(() => expect(host.ctx.llm.listProviders().some((p) => p.id === 'acp-devin')).toBe(true))
      await host.ctx.agentDefaultModel.saveSelection({ provider: 'acp-devin', model: 'mock-model-a' })
      browser = await launchBrowser({
        channel: process.env.DSH_E2E_BROWSER_CHANNEL,
        headless: !retain,
        ...(retain ? { args: ['--window-size=1440,1000'] } : {}),
      })
      page = retain
        ? await browser.newPage({ viewport: null, locale: 'en-US', timezoneId: 'Asia/Shanghai' })
        : await newEnglishPage(browser)
      page.on('pageerror', (e) => errors.push(e.message))
      await page.goto(host.authenticatedUrl)
      await connectFreshWorkspace(page, host.workspaceCwd)
      const send = async (text: string) => {
        const input = page.locator('[data-composer-input]').first()
        // Clear through the native editor first, then commit Unicode text as an
        // input event. keyboard.type() mixes insertText for CJK with key events
        // for ASCII and can outrun Lexical's select-all selection update.
        await writeComposerDraft(page, input, '')
        await input.press('End')
        await page.keyboard.insertText(text)
        await expect.poll(() => input.innerText()).toBe(text)
        await page.getByRole('button', { name: 'Send message', exact: true }).click()
      }
      setupAnswers = installTeamFixtureApprovals(host, {
        initialPrompt: 'E2E_TEAM_START',
        entries: [...teamStartSteps(host), ...teamMemberSetupSteps('calculator')],
      })
      await send('E2E_TEAM_START')
      await page.getByText('E2E_TEAM_READY', { exact: true }).waitFor()
      const lead = required(host.ctx.agents.list().find((a) => host.ctx.agentTeams.tryMembership(a)?.role === 'lead'))
      const childId = required(host.ctx.agentTeams.listMembers(lead).find((m) => m.role === 'teammate')).id
      const url = page.url()
      const panel = page.locator('[data-acp-team-management], [data-acp-team-panel]')
      const modeMenu = page.getByRole('menu')
      const evidence = join(root, '.local/shared-session-menu')
      mkdirSync(evidence, { recursive: true })
      const enterMode = async () => {
        await modeMenu.getByRole('menuitem', { name: /^(?:Session Mode|Mode|模式)(?:\s|$)/ }).click()
      }
      // Capture the pre-session/new window before waiting for the child approval
      // gate, which can outlast the mock's deliberate startup delay.
      await panel.getByRole('button', { name: 'Manage members · 1', exact: true }).click()
      const row = panel.locator('[data-acp-managed-member="calculator"]')
      const managementPanel = page.locator('[data-acp-team-panel]')
      await row.waitFor()
      await managementPanel.getByText('Manage members', { exact: true }).click()
      await expect.poll(() => managementPanel.count()).toBe(1)
      await page.locator('[data-composer-input]').first().click()
      await expect.poll(() => managementPanel.count()).toBe(0)
      await panel.getByRole('button', { name: 'Manage members · 1', exact: true }).click()
      await managementPanel.waitFor()
      expect(await row.getByRole('button', { name: 'Choose a model for calculator', exact: true }).isDisabled()).toBe(
        true,
      )
      await vi.waitFor(
        () =>
          expect(
            readdirSync(host.workspaceCwd).filter(
              (name) => name.startsWith('team-management-policy-ready.') && name.endsWith('.ready'),
            ),
          ).toHaveLength(1),
        { timeout: 30000 },
      )
      setupAnswers.finish()
      setupAnswers = undefined
      await (host.ctx.get('dshAcp') as AcpRemoteService).setToolApprovalPolicy(lead.id, { policy: 'ask' })
      writeFileSync(policyGate, 'ready')
      // The catalog must load automatically once the child's binding is ready.
      await row.getByText('Mock Model A', { exact: true }).waitFor()
      expect(await row.innerText()).not.toContain('not authorized')
      expect(await row.getByText('Mock Model A', { exact: true }).count()).toBe(1)
      expect(await row.getByRole('textbox').count()).toBe(0)
      expect(await row.getByRole('button', { name: 'Interrupt turn', exact: true }).count()).toBe(0)
      await row.getByRole('button', { name: /^(?:Session|会话) ·/ }).click()
      await enterMode()
      await modeMenu.getByRole('menuitem', { name: /^Plan(?:\s|$)/i }).waitFor()
      await expect.poll(() => modeMenu.evaluate((element) => element.contains(document.activeElement))).toBe(true)
      for (const item of await modeMenu
        .getByRole('menuitem')
        .filter({ hasNotText: /Back to session settings|返回会话设置/ })
        .all())
        expect(await item.isDisabled()).toBe(true)
      expect(await modeMenu.innerText()).not.toMatch(/Model:|Reasoning:/)
      await modeMenu.screenshot({ path: join(evidence, 'member-readonly.png') })
      await page.keyboard.press('Escape')
      await page.evaluate(
        () => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))),
      )
      await expect.poll(() => page.getByRole('menu').count()).toBe(0)
      expect(await page.locator('[data-acp-team-panel]').count()).toBe(1)
      expect(
        await row.getByRole('button', { name: /^(?:Session|会话) ·/ }).evaluate((el) => el === document.activeElement),
      ).toBe(true)
      const group = panel.locator('[data-acp-mode-group="devin"]')
      expect(await panel.locator('[data-acp-mode-group]').count()).toBe(1)
      await group.getByRole('button', { name: 'Change modes together', exact: true }).click()
      await enterMode()
      await modeMenu.getByRole('menuitem', { name: /^Plan(?:\s|$)/i }).waitFor()
      await expect.poll(() => modeMenu.evaluate((element) => element.contains(document.activeElement))).toBe(true)
      for (const item of await modeMenu
        .getByRole('menuitem')
        .filter({ hasNotText: /Back to session settings|返回会话设置/ })
        .all())
        expect(await item.isDisabled()).toBe(true)
      await page.keyboard.press('Escape')
      await page.evaluate(
        () => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))),
      )
      expect(
        await group
          .getByRole('button', { name: 'Change modes together', exact: true })
          .evaluate((el) => el === document.activeElement),
      ).toBe(true)
      await panel.getByRole('button', { name: 'Close member management', exact: true }).click()
      await expect(
        (host.ctx.get('dshAcp') as AcpRemoteService).setTeamMemberMode(lead.id, childId, 'plan'),
      ).rejects.toThrow()
      const memberApprovals = page.locator('[data-acp-team-approvals]')
      // This ordinary tool was requested while the inherited policy was Ask.
      // Returning the Lead to Auto must leave its native card pending.
      await memberApprovals.getByRole('button', { name: 'Allow once', exact: true }).waitFor()
      await (host.ctx.get('dshAcp') as AcpRemoteService).setToolApprovalPolicy(lead.id, { policy: 'auto' })
      expect(await memberApprovals.getByRole('button', { name: 'Allow once', exact: true }).count()).toBe(1)
      await memberApprovals.getByRole('button', { name: 'Allow once', exact: true }).click()
      await expect
        .poll(
          async () => (await (host.ctx.get('dshAcp') as AcpRemoteService).agentSessionSnapshot(childId)).freshness,
          { timeout: 15000 },
        )
        .toBe('stale')
      rmSync(policyGate, { force: true })
      await expect(
        (host.ctx.get('dshAcp') as AcpRemoteService).setAgentSessionOption(childId, {
          kind: 'config',
          id: 'mode',
          value: 'plan',
        }),
      ).rejects.toThrow()
      expect(page.url()).toBe(url)
      await page.reload()
      await panel.getByRole('button', { name: 'Manage members · 1', exact: true }).click()
      await row.getByText('Mock Model A', { exact: true }).waitFor()
      const beforeModeNotice = await row.boundingBox()
      expect(required(await row.locator('[data-member-mode-notice]').boundingBox()).height).toBeGreaterThanOrEqual(18)
      await row.getByRole('button', { name: /^(?:Session|会话) ·/ }).click()
      await enterMode()
      await modeMenu.getByRole('menuitem', { name: /^plan(?:\s|$)/i }).waitFor()
      await modeMenu.getByRole('menuitem', { name: /^plan(?:\s|$)/i }).click()
      await row
        .locator('[data-member-pending-mode]')
        .getByText(/current: Code|当前：Code/)
        .waitFor()
      expect(await row.boundingBox()).toMatchObject({
        x: beforeModeNotice!.x,
        y: beforeModeNotice!.y,
        width: beforeModeNotice!.width,
      })
      expect(await row.locator('[data-member-mode-notice]').evaluate((el) => el.scrollHeight <= el.clientHeight)).toBe(
        true,
      )
      const original = await (host.ctx.get('dshAcp') as AcpRemoteService).agentSessionSnapshot(childId)
      expect(original.pendingModeId).toBe('plan')
      expect(await modeMenu.count()).toBe(0)
      expect(await page.locator('[data-acp-team-panel]').count()).toBe(1)
      await row.getByRole('button', { name: /^(?:Session|会话) · Plan$/ }).click()
      await modeMenu.screenshot({ path: join(evidence, 'member-settings.png') })
      await enterMode()
      await modeMenu.screenshot({ path: join(evidence, 'member-options.png') })
      const menuBox = required(await modeMenu.boundingBox())
      expect(menuBox.x).toBeGreaterThanOrEqual(12)
      expect(menuBox.x + menuBox.width).toBeLessThanOrEqual(await page.evaluate(() => innerWidth - 12))
      expect(
        await modeMenu
          .getByRole('menuitem', { name: /^Plan(?:\s|$)/ })
          .locator('svg')
          .count(),
      ).toBe(1)
      expect(
        await modeMenu
          .getByRole('menuitem', { name: /^Code(?:\s|$)/ })
          .locator('svg')
          .count(),
      ).toBe(0)
      await page.keyboard.press('Escape')
      const styleOf = (button: Locator) =>
        button.evaluate((el) => {
          const css = getComputedStyle(el)
          return {
            font: css.fontFamily,
            size: css.fontSize,
            border: css.borderWidth,
            radius: css.borderRadius,
            height: css.height,
          }
        })
      expect(await styleOf(row.getByRole('button', { name: 'Choose a model for calculator', exact: true }))).toEqual(
        await styleOf(row.getByRole('button', { name: /^(?:Session|会话) ·/ })),
      )
      const typography = (locator: Locator) =>
        locator.evaluate((el) => {
          const css = getComputedStyle(el)
          return [css.fontFamily, css.fontSize, css.fontWeight, css.lineHeight]
        })
      expect(await typography(row.getByRole('button', { name: /^(?:Session|会话) ·/ }))).toEqual(
        await typography(row.getByText('Mode', { exact: true })),
      )
      expect(await panel.getByRole('button', { name: 'Interrupt all members', exact: true }).isDisabled()).toBe(true)
      mkdirSync(join(root, '.local/team-management'), { recursive: true })
      await page.screenshot({ path: join(root, '.local/team-management/mode-pending.en.png') })
      await group.getByRole('button', { name: 'Change modes together', exact: true }).click()
      await enterMode()
      await modeMenu.getByRole('menuitem', { name: /^ask(?:\s|$)/i }).click()
      await row
        .locator('[data-member-pending-mode]')
        .getByText(/current: Code|当前：Code/)
        .waitFor()
      await row.getByRole('button', { name: /^(?:Session|会话) · Ask$/ }).waitFor()
      expect(await row.boundingBox()).toMatchObject({
        x: beforeModeNotice!.x,
        y: beforeModeNotice!.y,
        width: beforeModeNotice!.width,
      })
      expect(await row.locator('[data-member-mode-notice]').evaluate((el) => el.scrollHeight <= el.clientHeight)).toBe(
        true,
      )
      await page.reload()
      await panel.getByRole('button', { name: 'Manage members · 1', exact: true }).click()
      await row
        .locator('[data-member-pending-mode]')
        .getByText(/current: Code|当前：Code/)
        .waitFor()
      await row.getByRole('button', { name: /^(?:Session|会话) · Ask$/ }).waitFor()
      await panel.getByRole('button', { name: 'Close member management', exact: true }).click()
      setupAnswers = installTeamFixtureApprovals(host, {
        root: lead,
        entries: [
          ...calls('lead', [
            ['list_agents', {}],
            ['send_message', { target: 'calculator', message: 'E2E_TEAM_CONTINUE' }],
          ]),
          ...memberContinuation('calculator'),
          ...teamReplySteps(),
        ],
      })
      const wakeStart = events.length
      await send('E2E_TEAM_WAKE')
      await page.getByText('E2E_TEAM_WOKEN', { exact: true }).waitFor()
      await expect
        .poll(
          () =>
            events.some(
              (event) =>
                event.sessionId === childId &&
                event.type === 'assistant/message' &&
                JSON.stringify(event).includes('E2E_TEAM_MEMBER_MODE ask'),
            ),
          { timeout: 15000 },
        )
        .toBe(true)
      await expect
        .poll(
          () =>
            events
              .slice(wakeStart)
              .some(
                (event) =>
                  event.sessionId === lead.id &&
                  event.type === 'assistant/message' &&
                  JSON.stringify(event).includes('E2E_TEAM_LEAD_RECEIVED'),
              ),
          { timeout: 15000 },
        )
        .toBe(true)
      // Dormant children release their Agent runtime. Observe this wake's
      // actual completion rather than retaining the already-disposed instance.
      await expect
        .poll(
          () =>
            events
              .slice(wakeStart)
              .some(
                (event) =>
                  event.sessionId === childId && event.type === 'turn/end' && event.data.reason.kind === 'completed',
              ),
          { timeout: 15000 },
        )
        .toBe(true)
      await lead.whenIdle()
      setupAnswers.finish()
      setupAnswers = undefined
      await panel.getByRole('button', { name: 'Manage members · 1', exact: true }).click()
      await row.getByRole('button', { name: /^(?:Session|会话) · Ask$/ }).waitFor()
      expect(await row.locator('[data-member-pending-mode]').count()).toBe(0)
      if (!retain) await page.setViewportSize({ width: 680, height: 900 })
      expect(await page.locator('[data-acp-team-panel]').evaluate((el) => el.scrollWidth <= el.clientWidth)).toBe(true)
      await page.keyboard.press('Escape')
      await expect.poll(() => page.locator('[data-acp-team-panel]').count()).toBe(0)
      if (!retain) await page.setViewportSize({ width: 1440, height: 719 })
      await page.getByRole('button', { name: 'New session', exact: true }).last().click()
      // Navigation replaces the old composer asynchronously. Do not type into
      // that editor just before it is unmounted and loses the new draft.
      await page.getByText('E2E_TEAM_WOKEN', { exact: true }).waitFor({ state: 'detached' })
      await page
        .locator(
          '[data-composer-input][contenteditable="true"][data-placeholder="Describe what you want to build, / commands, @ files or sessions"]',
        )
        .waitFor()
      setupAnswers = installTeamFixtureApprovals(host, {
        initialPrompt: '演示成员管理与集中审批 E2E_TEAM_DEMO',
        entries: [
          ...calls('lead', [
            ['list_agents', {}],
            ['team_task_create', { subject: '整理需求', description: '梳理成员管理和集中审批的验收要点' }],
            [
              'team_task_create',
              (agent) => ({
                subject: '复核方案',
                description: '等待需求整理完成，再检查边界',
                blocked_by: [originalTask(agent, '整理需求').id],
              }),
            ],
            [
              'spawn_teammate',
              {
                name: 'analyst',
                description: '整理需求与验收要点',
                prompt: 'E2E_TEAM_MEMBER calculate 1+1',
                context: 'fresh',
              },
            ],
            [
              'spawn_teammate',
              {
                name: 'reviewer',
                description: '检查实现与审批边界',
                prompt: 'E2E_TEAM_MEMBER calculate 1+1',
                context: 'fresh',
              },
            ],
          ]),
          ...teamMemberSetupSteps('analyst'),
          ...teamMemberSetupSteps('reviewer'),
        ],
      })
      await send('演示成员管理与集中审批 E2E_TEAM_DEMO')
      await page.getByText('团队演示已就绪。', { exact: false }).waitFor()
      await vi.waitFor(
        () =>
          expect(
            readdirSync(host.workspaceCwd).filter(
              (name) => name.startsWith('team-management-policy-ready.') && name.endsWith('.ready'),
            ),
          ).toHaveLength(3),
        { timeout: 30000 },
      )
      const demoLead = required(
        host.ctx.agents.list().find((a) => a.id !== lead.id && host.ctx.agentTeams.tryMembership(a)?.role === 'lead'),
      )
      setupAnswers.finish()
      setupAnswers = undefined
      await (host.ctx.get('dshAcp') as AcpRemoteService).setToolApprovalPolicy(demoLead.id, { policy: 'ask' })
      writeFileSync(policyGate, 'ready')
      expect(
        events
          .filter(
            (event) =>
              event.type === 'user/message' &&
              event.data.content.some(
                (block) => block.type === 'text' && block.text === '演示成员管理与集中审批 E2E_TEAM_DEMO',
              ),
          )
          .map((event) => event.sessionId),
      ).toEqual([demoLead.id])
      if (!retain) {
        await send('E2E_STOP')
        await page.getByText('E2E_RUNNING', { exact: true }).waitFor()
        expect(demoLead.status).toBe('running')
      }
      await panel.getByRole('button', { name: 'Manage members · 2', exact: true }).click()
      await host.ctx.settings.replace('locale', { preference: 'zh' })
      await panel.getByRole('button', { name: '成员管理 · 2', exact: true }).waitFor()
      const approvals = page.locator('[data-acp-team-approvals]')
      await approvals.getByText('需要你处理 · 2 个子会话', { exact: true }).waitFor()
      await expect.poll(() => approvals.locator('[data-team-pending-member]').count()).toBe(2)
      // Changing the Lead's policy must not decide either pending child request.
      await (host.ctx.get('dshAcp') as AcpRemoteService).setToolApprovalPolicy(demoLead.id, { policy: 'auto' })
      expect(await approvals.locator('[data-team-pending-member]').count()).toBe(2)
      const triggerBox = required(await panel.getByRole('button', { name: '成员管理 · 2', exact: true }).boundingBox())
      expect(triggerBox.y).toBeLessThan(100)
      expect(triggerBox.x).toBeGreaterThan((await page.evaluate(() => innerWidth)) / 2)
      const popupBox = required(await page.locator('[data-acp-team-panel]').boundingBox())
      expect(popupBox.x).toBeGreaterThanOrEqual(0)
      expect(popupBox.x + popupBox.width).toBeLessThanOrEqual(await page.evaluate(() => innerWidth))
      // Member cards contain only mode controls, with one batch entry for this ACP profile.
      expect(await panel.getByRole('textbox').count()).toBe(0)
      expect(await panel.getByRole('button', { name: '批量调整模式', exact: true }).count()).toBe(1)
      await panel.getByRole('button', { name: '关闭成员管理', exact: true }).click()
      const allowAll = required(await approvals.getByRole('button', { name: '全部允许', exact: true }).boundingBox())
      const collapse = required(await approvals.getByRole('button', { name: '收起', exact: true }).boundingBox())
      expect(allowAll.x).toBeLessThan(collapse.x)
      expect(Math.abs(allowAll.y - collapse.y)).toBeLessThan(12)
      const first = approvals.locator('[data-team-pending-member]').first()
      const detail = first.locator('[data-team-approval-reason]')
      const one = required(await first.getByRole('button', { name: '允许一次', exact: true }).boundingBox())
      expect(required(await detail.boundingBox()).y).toBeGreaterThanOrEqual(one.y + one.height)
      const font = await detail.evaluate((el) => ({
        size: getComputedStyle(el).fontSize,
        line: getComputedStyle(el).lineHeight,
        family: getComputedStyle(el).fontFamily,
        parentFamily: getComputedStyle(el.parentElement!).fontFamily,
      }))
      expect(font).toMatchObject({ size: '15px', line: '24px' })
      expect(font.family).toBe(font.parentFamily)
      await panel.getByRole('button', { name: '成员管理 · 2', exact: true }).click()
      await expect.poll(() => panel.getByRole('button', { name: /^(?:Session|会话) ·/ }).count()).toBe(2)
      expect(errors).toEqual([])
      if (!retain) {
        const interrupt = panel.getByRole('button', { name: '中断所有成员', exact: true })
        const interruptBox = required(await interrupt.boundingBox())
        const batchBox = required(await panel.getByRole('button', { name: '批量调整模式', exact: true }).boundingBox())
        expect(interruptBox.x + interruptBox.width).toBeLessThanOrEqual(batchBox.x)
        expect(interruptBox.height).toBe(24)
        expect(batchBox.height).toBe(24)
        const firstCardBox = required(await panel.locator('[data-acp-managed-member]').first().boundingBox())
        expect(firstCardBox.y - (batchBox.y + batchBox.height)).toBeGreaterThanOrEqual(12)
        const dshAcp = host.ctx.get('dshAcp') as AcpRemoteService
        const initialReadFailure = vi
          .spyOn(dshAcp, 'teamMembers')
          .mockRejectedValueOnce(new Error('fixture read failure'))
        const interruptSpy = vi.spyOn(host.ctx.subagents, 'interruptByParent')
        const failedLookupCount = initialReadFailure.mock.calls.length
        await interrupt.click()
        const teamPanel = page.locator('[data-acp-team-panel]')
        await teamPanel.getByText('无法读取成员状态，未发送中断，请重试。', { exact: true }).waitFor()
        await expect.poll(() => initialReadFailure.mock.calls.length).toBe(failedLookupCount + 1)
        expect(initialReadFailure.mock.calls).toHaveLength(failedLookupCount + 1)
        expect(interruptSpy).not.toHaveBeenCalled()
        expect(await teamPanel.locator('[data-acp-managed-member]').count()).toBe(2)
        initialReadFailure.mockRestore()

        const readMembers = dshAcp.teamMembers.bind(dshAcp)
        let membershipReads = 0
        let finishMetadataRefresh: () => void = () => undefined
        const metadataRefreshGate = new Promise<void>((resolve) => {
          finishMetadataRefresh = resolve
        })
        let allowMetadataRefresh = false
        let explicitRefreshReads = 0
        const refreshReadFailure = vi.spyOn(dshAcp, 'teamMembers').mockImplementation(async (leadId) => {
          membershipReads++
          if (membershipReads === 1) return readMembers(leadId)
          if (!allowMetadataRefresh) throw new Error('fixture refresh failure')
          explicitRefreshReads++
          await metadataRefreshGate
          return readMembers(leadId)
        })
        await interrupt.click()
        await teamPanel.getByRole('status').filter({ hasText: '已向 2 个成员发送中断' }).waitFor()
        await teamPanel.getByRole('alert').filter({ hasText: '无法读取成员状态，请刷新重试。' }).waitFor()
        await expect.poll(() => membershipReads > 1).toBe(true)
        expect(await teamPanel.getByRole('status').filter({ hasText: '已向 2 个成员发送中断' }).count()).toBe(1)
        expect(await teamPanel.getByRole('alert').filter({ hasText: '无法读取成员状态，请刷新重试。' }).count()).toBe(1)
        const demoMembers = host.ctx.agentTeams.listMembers(demoLead).filter((m) => m.role === 'teammate')
        expect(interruptSpy.mock.calls.map((args) => args[0]).sort()).toEqual(demoMembers.map((m) => m.id).sort())
        expect(interruptSpy.mock.calls.every((args) => args[1] === demoLead.id && args[2] === 'continuable')).toBe(true)
        interruptSpy.mockRestore()
        allowMetadataRefresh = true
        await teamPanel.getByRole('button', { name: '刷新', exact: true }).click()
        await teamPanel.getByText('正在读取 ACP 成员设置…', { exact: true }).waitFor()
        await expect.poll(() => explicitRefreshReads > 0).toBe(true)
        expect(membershipReads).toBeGreaterThan(2)
        finishMetadataRefresh()
        await teamPanel.getByText('正在读取 ACP 成员设置…', { exact: true }).waitFor({ state: 'detached' })
        await expect.poll(() => teamPanel.getByRole('alert').count()).toBe(0)
        refreshReadFailure.mockRestore()
        await expect.poll(() => approvals.locator('[data-team-pending-member]').count()).toBe(0)
        await expect(
          (host.ctx.get('dshAcp') as AcpRemoteService).setTeamMemberMode(lead.id, demoMembers[0].id, 'plan'),
        ).rejects.toThrow()
        await expect(
          (host.ctx.get('dshAcp') as AcpRemoteService).setTeamMemberMode(demoLead.id, demoLead.id, 'plan'),
        ).rejects.toThrow()
        await expect
          .poll(async () =>
            Promise.all(
              demoMembers.map(
                async (m) => (await (host.ctx.get('dshAcp') as AcpRemoteService).agentSessionSnapshot(m.id)).freshness,
              ),
            ),
          )
          .toEqual(['stale', 'stale'])
        await expect.poll(() => interrupt.isDisabled()).toBe(true)
        expect(demoLead.status).toBe('running')
        await panel.getByRole('button', { name: '批量调整模式', exact: true }).click()
        await enterMode()
        await modeMenu.getByRole('menuitem', { name: /^plan(?:\s|$)/i }).click()
        await expect.poll(() => panel.locator('[data-member-pending-mode]').count()).toBe(2)
        expect(await panel.locator('[data-member-pending-mode]').allTextContents()).toEqual([
          '下次请求生效；当前：Code',
          '下次请求生效；当前：Code',
        ])
        expect(await panel.getByRole('status').filter({ hasText: '已保存' }).innerText()).toContain('已保存 2 个')
        await expect.poll(() => panel.getByRole('button', { name: /^(?:Session|会话) · Plan$/ }).count()).toBe(2)
        await page.screenshot({ path: join(root, '.local/team-management/mode-pending.zh.png') })
        // With native Teams still installed, a fresh native-model session owns neither ACP control.
        class NativeFixture extends LlmAdapter {
          providerInfo(id: string) {
            return { id, name: 'Native fixture' }
          }
          async listModels(provider: string) {
            return [{ provider, id: 'native-model', name: 'Native Model' }]
          }
          async *stream(): ReturnType<LlmAdapter['stream']> {
            yield { type: 'block-start', index: 0, blockType: 'text' }
            yield { type: 'text-delta', index: 0, text: 'E2E_NATIVE_MODE_ONLY' }
            yield { type: 'block-end', index: 0, block: { type: 'text', text: 'E2E_NATIVE_MODE_ONLY' } }
            yield { type: 'finish', reason: { kind: 'stop' } }
          }
        }
        host.ctx.effect(() => host.ctx.llm.registerAdapter(['native-mode-control'], new NativeFixture()))
        await host.ctx.settings.replace('locale', { preference: 'en' })
        await panel.getByRole('button', { name: 'Close member management', exact: true }).click()
        await page.getByRole('button', { name: 'Stop generating', exact: true }).click()
        await expect.poll(() => demoLead.status).toBe('idle')
        setupAnswers = installTeamFixtureApprovals(host, {
          root: demoLead,
          entries: [...memberContinuation('analyst'), ...teamReplySteps()],
        })
        const analystId = required(demoMembers.find((member) => member.name === 'analyst')).id
        const analystWakeStart = events.length
        await host.ctx.agentTeams.sendMessage(demoLead, {
          target: 'analyst',
          content: [{ type: 'text', text: 'E2E_TEAM_CONTINUE' }],
          signal: new AbortController().signal,
        })
        await expect
          .poll(
            () =>
              events
                .slice(analystWakeStart)
                .some(
                  (event) =>
                    event.sessionId === analystId &&
                    event.type === 'assistant/message' &&
                    JSON.stringify(event).includes('E2E_TEAM_MEMBER_MODE plan'),
                ),
            { timeout: 15000 },
          )
          .toBe(true)
        await expect
          .poll(
            () =>
              events
                .slice(analystWakeStart)
                .some(
                  (event) =>
                    event.sessionId === demoLead.id &&
                    event.type === 'assistant/message' &&
                    JSON.stringify(event).includes('E2E_TEAM_LEAD_RECEIVED'),
                ),
            { timeout: 15000 },
          )
          .toBe(true)
        // The interrupted child may already have released its runtime. Require
        // this wake's new native turn to complete on the same durable session.
        await expect
          .poll(
            () => {
              const wakeEvents = events.slice(analystWakeStart)
              const started = wakeEvents.find((event) => event.sessionId === analystId && event.type === 'turn/start')
              return (
                started?.type === 'turn/start' &&
                wakeEvents.some(
                  (event) =>
                    event.sessionId === analystId &&
                    event.type === 'turn/end' &&
                    event.data.turn === started.data.turn &&
                    event.seq > started.seq &&
                    event.data.reason.kind === 'completed',
                )
              )
            },
            { timeout: 15000 },
          )
          .toBe(true)
        await demoLead.whenIdle()
        setupAnswers.finish()
        setupAnswers = undefined
        await host.ctx.agentDefaultModel.saveSelection({ provider: 'native-mode-control', model: 'native-model' })
        await page.getByRole('button', { name: 'New session', exact: true }).last().click()
        await page.getByText('Into the Unknown', { exact: true }).waitFor()
        await send('Check native controls')
        await page.getByText('E2E_NATIVE_MODE_ONLY', { exact: true }).waitFor()
        expect(await panel.count()).toBe(0)
        expect(await page.getByRole('button', { name: /^(?:Session|会话) ·/ }).count()).toBe(0)
        expect(await page.getByRole('button', { name: 'Agent Team', exact: true }).count()).toBeGreaterThan(0)
      }
      if (retain) {
        await panel.getByRole('button', { name: '关闭成员管理', exact: true }).click()
        await approvals.getByRole('button', { name: '拒绝', exact: true }).first().click()
        const demoChild = required(host.ctx.agentTeams.listMembers(demoLead).find((m) => m.name === 'analyst'))
        await expect
          .poll(
            async () =>
              (await (host.ctx.get('dshAcp') as AcpRemoteService).agentSessionSnapshot(demoChild.id)).freshness,
          )
          .toBe('stale')
        await panel.getByRole('button', { name: '成员管理 · 2', exact: true }).click()
        await panel
          .locator('[data-acp-managed-member="analyst"]')
          .getByRole('button', { name: /^(?:Session|会话) ·/ })
          .click()
        await enterMode()
        await modeMenu.getByRole('menuitem', { name: /^smart(?:\s|$)/i }).click()
        await panel
          .locator('[data-member-pending-mode]')
          .getByText(/current: Code|当前：Code/)
          .waitFor()
        await panel.getByRole('button', { name: /^(?:Session|会话) · Smart$/ }).waitFor()
        const modeButtons = await panel.getByRole('button', { name: /^(?:Session|会话) ·/ }).all()
        const boxes = await Promise.all(modeButtons.map((button) => button.boundingBox()))
        expect(Math.abs(required(boxes[0]).y - required(boxes[1]).y)).toBeLessThan(2)
        mkdirSync(join(root, '.local/team-management'), { recursive: true })
        writeFileSync(
          join(root, '.local/team-management/instance.json'),
          JSON.stringify(
            { url: page.url(), leadId: demoLead.id, workspace: host.workspaceCwd, pid: process.pid },
            null,
            2,
          ),
        )
        await panel.getByRole('button', { name: /^(?:Session|会话) · Smart$/ }).click()
        await enterMode()
        expect(
          await modeMenu
            .getByRole('menuitem', { name: /^Smart(?:\s|$)/ })
            .locator('svg')
            .count(),
        ).toBe(1)
        await page.screenshot({ path: join(root, '.local/team-management/preview.png') })
        console.log('TEAM_MANAGEMENT_READY', page.url())
        await new Promise((resolve) => process.once('SIGTERM', resolve))
      }
    } catch (error) {
      if (page) {
        mkdirSync(join(root, '.local/e2e-failures'), { recursive: true })
        await page.screenshot({ path: join(root, '.local/e2e-failures/team-management.png') })
        writeFileSync(join(root, '.local/e2e-failures/team-management.json'), JSON.stringify(events, null, 2))
      }
      throw error
    } finally {
      setupAnswers?.dispose()
      await browser?.close()
      await host.close()
    }
  },
  process.env.DSH_E2E_RETAIN_MANAGEMENT === '1' ? 86400000 : 90000,
)
