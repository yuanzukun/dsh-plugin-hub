import { acpPermissionAudit } from './acp-permission-audit.ts'
import { teamBoundaryDiagnostics } from './team-boundary-diagnostics.ts'
import { waitForTeamSettlement } from './team-settlement.ts'
import {
  installTeamFixtureApprovals,
  teamMemberSetupSteps,
  teamReplySteps,
  teamStartSteps,
} from './team-fixture-approval.ts'
import type { SessionRequestId } from '@deepseek-ai/dsh-api-session-controller'
import { required } from './required.ts'
import { launchBrowser, newEnglishPage } from './browser.ts'
import type { ObservedEvent } from './types.ts'
import { writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { LlmAdapter } from '@deepseek-ai/dsh-llm'
import { expect, it, vi } from 'vitest'
import { connectFreshWorkspace, writeComposerDraft } from '#host-support'
import { launchAdapterWorld, root } from './scaffold.ts'

class NativeTeamControl extends LlmAdapter {
  providerInfo(id: string) {
    return { id, name: 'Native team control' }
  }
  async listModels(provider: string) {
    return ['native-a', 'native-b'].map((id) => ({ provider, id, name: id }))
  }
  providerRetryPolicy(): ReturnType<LlmAdapter['providerRetryPolicy']> {
    return { mode: 'normal', maxRetries: 0, retryableCodes: [], initialDelayMs: 0, maxDelayMs: 0, jitterRatio: 0 }
  }
  async *stream(options: Parameters<LlmAdapter['stream']>[0]): ReturnType<LlmAdapter['stream']> {
    expect((options.tools ?? []).some((tool) => tool.name === 'spawn_teammate')).toBe(true)
    if (options.messages.some((message) => JSON.stringify(message.content).includes('Calculate 1+1'))) {
      expect(JSON.stringify(options.messages)).toContain('Approval prompts are disabled in this session')
    }
    const text = `NATIVE_TEAM_DONE ${options.model}`
    yield { type: 'block-start', index: 0, blockType: 'text' }
    yield { type: 'text-delta', index: 0, text }
    yield { type: 'block-end', index: 0, block: { type: 'text', text } }
    yield { type: 'finish', reason: { kind: 'stop' } }
  }
}

async function setup(teams: boolean, native = false, mockLog?: string) {
  const host = await launchAdapterWorld({ teams })
  const profile = (id: string) => ({
    name: `Fixture ${id}`,
    command: process.execPath,
    args: [join(root, 'test/mock-agent/mock-agent.ts')],
    env: {
      HOME: host.workspaceCwd,
      MOCK_SCENARIO: 'regression',
      MOCK_PROFILE: id,
      MOCK_MCP_HTTP: '1',
      ...(mockLog === undefined ? {} : { MOCK_LOG: mockLog }),
    },
  })
  await host.ctx.settings.replace('dsh-acp-adapter', {
    toolApprovalDefault: 'auto',
    agents: { devin: profile('devin'), codex: profile('codex') },
  })
  await vi.waitFor(() => expect(host.ctx.llm.listProviders().some((item) => item.id === 'acp-devin')).toBe(true))
  if (native) host.ctx.effect(() => host.ctx.llm.registerAdapter(['native-control'], new NativeTeamControl()))
  await host.ctx.agentDefaultModel.saveSelection(
    native ? { provider: 'native-control', model: 'native-a' } : { provider: 'acp-devin', model: 'mock-model-a' },
  )
  const browser = await launchBrowser({ channel: process.env.DSH_E2E_BROWSER_CHANNEL, headless: true })
  const page = await newEnglishPage(browser)
  await page.goto(host.authenticatedUrl)
  await connectFreshWorkspace(page, host.workspaceCwd)
  const send = async (text: string) => {
    await writeComposerDraft(page, page.locator('[data-composer-input]').first(), text)
    await page.getByRole('button', { name: 'Send message', exact: true }).click()
  }
  return { host, browser, page, send }
}

it('does not expose Teams UI or services when the native profile is off', async () => {
  const { host, browser, page, send } = await setup(false)
  try {
    await send('E2E_MESSAGE')
    await page.getByText('E2E_DONE mock-model-a', { exact: true }).waitFor()
    expect(await page.locator('[data-team-action]').count()).toBe(0)
    expect(host.ctx.get('agentTeams')).toBeUndefined()
    expect(host.ctx.tools.get('spawn_teammate', host.ctx.agents.list()[0])).toBeUndefined()
  } finally {
    await browser.close()
    await host.close()
  }
})

it('keeps one ACP Agent across multiple models, isolates approvals and prevents cross-Agent teams', async (context) => {
  const diagnostics = teamBoundaryDiagnostics(join(root, '.local/teams-review'), context.signal)
  const { host, browser, page, send } = await setup(true, false, diagnostics.logPath)
  const drivers: ReturnType<typeof installTeamFixtureApprovals>[] = []
  const setupDecisions = (options: Parameters<typeof installTeamFixtureApprovals>[1]) => {
    const driver = installTeamFixtureApprovals(host, options)
    drivers.push(driver)
    return driver
  }
  const memberAudit = <P extends 'asked' | 'decided'>(phase: P) =>
    acpPermissionAudit(host, phase).filter((entry) => {
      const requestId = 'requestId' in entry.data ? entry.data.requestId : undefined
      return requestId !== undefined && !drivers.some((driver) => driver.requestIds.has(requestId))
    })
  const evidence: Record<string, unknown> = {},
    events: ObservedEvent[] = []
  diagnostics.attach(host, () => new Set(drivers.flatMap((driver) => [...driver.requestIds])))
  const stopEvents = host.ctx.on('session/event', (session, event) => {
    const observed = { sessionId: session.id, ...event }
    events.push(observed)
    diagnostics.event(observed)
  })
  let cleanupPromise: Promise<void> | undefined
  const cleanup = () =>
    (cleanupPromise ??= (async () => {
      try {
        diagnostics.capture('teardown')
        diagnostics.dispose()
        stopEvents()
        for (const driver of drivers) driver.dispose()
        writeFileSync(join(root, '.local/teams-review/routing.json'), JSON.stringify({ ...evidence, events }, null, 2))
      } finally {
        try {
          await browser.close()
        } finally {
          await host.close()
        }
      }
    })())
  // Vitest's deadline does not unwind a pending body promise. Preserve the
  // same fixture teardown even when its ordinary finally cannot be reached.
  context.onTestFinished(cleanup)
  try {
    diagnostics.stage('bootstrap-send')
    const bootstrap = setupDecisions({
      initialPrompt: 'E2E_TEAM_START',
      entries: [...teamStartSteps(host), ...teamMemberSetupSteps('calculator')],
    })
    await send('E2E_TEAM_START')
    diagnostics.stage('bootstrap-ready')
    await page.getByText('E2E_TEAM_READY', { exact: true }).waitFor()
    const lead = required(
      host.ctx.agents.list().find((agent) => host.ctx.agentTeams.tryMembership(agent)?.role === 'lead'),
    )
    const childAId = required(host.ctx.agentTeams.listMembers(lead).find((member) => member.role === 'teammate')).id
    diagnostics.stage('bootstrap-member-permission')
    await expect
      .poll(
        () =>
          memberAudit('asked').filter(
            (entry) => entry.sessionId === childAId && entry.data.toolCall.toolCallId === 'member-shell',
          ),
        { timeout: 30000 },
      )
      .toHaveLength(1)
    bootstrap.finish()
    diagnostics.stage('lead-select-model-b')
    await page.getByRole('button', { name: /^Select model/ }).click()
    await page.getByRole('menuitem', { name: /^Model/ }).click()
    await page
      .getByLabel('Fixture devin · ACP', { exact: true })
      .getByRole('menuitemradio', { name: 'Mock Model B', exact: true })
      .click()
    await page.getByRole('button', { name: /^Select model, current Mock Model B/ }).waitFor()
    expect(await page.getByRole('dialog').count()).toBe(0)
    const pendingCard = page.locator('[data-acp-team-approvals]')
    await pendingCard.getByRole('button', { name: 'Collapse', exact: true }).click()
    expect(await pendingCard.getByRole('button', { name: 'calculator · Pending request', exact: true }).count()).toBe(0)
    // A waiting child must not disable the lead, and ordinary messages must not approve it.
    const siblingSetup = setupDecisions({
      root: lead,
      entries: [
        { owner: 'lead', callId: 'team-1', tool: 'list_agents', args: {} },
        {
          owner: 'lead',
          callId: 'team-2',
          tool: 'spawn_teammate',
          args: {
            name: 'calculator-b',
            description: 'Model B member',
            prompt: 'E2E_TEAM_MEMBER calculate 1+1',
            context: 'fresh',
          },
        },
        ...teamMemberSetupSteps('calculator-b'),
      ],
    })
    diagnostics.stage('sibling-send')
    await send('E2E_TEAM_SECOND')
    diagnostics.stage('sibling-ready')
    await page.getByText('E2E_TEAM_SECOND_READY', { exact: true }).waitFor()
    const childBId = required(host.ctx.agentTeams.listMembers(lead).find((member) => member.name === 'calculator-b')).id
    diagnostics.stage('sibling-member-permission')
    await expect
      .poll(
        () =>
          memberAudit('asked').filter(
            (entry) => entry.sessionId === childBId && entry.data.toolCall.toolCallId === 'member-shell',
          ),
        { timeout: 30000 },
      )
      .toHaveLength(1)
    siblingSetup.finish()
    diagnostics.stage('two-pending-layout')
    expect(required(host.ctx.agents.get(childBId)).options).toMatchObject({
      provider: 'acp-devin',
      model: 'mock-model-b',
    })
    expect(required(host.ctx.agents.get(childAId)).options).toMatchObject({
      provider: 'acp-devin',
      model: 'mock-model-a',
    })
    await page.getByRole('button', { name: 'calculator · Pending request', exact: true }).waitFor()
    await page.getByRole('button', { name: 'calculator-b · Pending request', exact: true }).waitFor()
    expect(await pendingCard.locator('[data-team-pending-member]').count()).toBe(2)
    expect(await pendingCard.getByRole('button', { name: 'Collapse', exact: true }).getAttribute('aria-expanded')).toBe(
      'true',
    )
    expect(memberAudit('decided')).toHaveLength(0)
    const cardBox = required(await pendingCard.boundingBox())
    const composerBox = required(await page.locator('[data-composer-input]').first().boundingBox())
    expect(cardBox.y + cardBox.height).toBeLessThanOrEqual(composerBox.y + 1)
    await page.reload()
    diagnostics.stage('reload-pending')
    await pendingCard.getByRole('button', { name: 'calculator-b · Pending request', exact: true }).waitFor()
    expect(await pendingCard.locator('[data-team-pending-member]').count()).toBe(2)
    await host.ctx.settings.replace('locale', { preference: 'zh' })
    diagnostics.stage('locale-zh-pending')
    // The locale-bound translate function causes the component to revalidate
    // member eligibility, briefly removing rows while its fresh read settles.
    await expect
      .poll(async () => {
        const [title, approvals, members] = await Promise.all([
          pendingCard.getByText('需要你处理 · 2 个子会话', { exact: true }).count(),
          pendingCard.getByText('等待审批', { exact: true }).count(),
          pendingCard.locator('[data-team-pending-member]').count(),
        ])
        return { title, approvals, members }
      })
      .toEqual({ title: 1, approvals: 2, members: 2 })
    diagnostics.stage('locale-zh-layout')
    await page.setViewportSize({ width: 680, height: 720 })
    const narrow = required(await pendingCard.boundingBox())
    expect(narrow.x).toBeGreaterThanOrEqual(0)
    expect(narrow.x + narrow.width).toBeLessThanOrEqual(680)
    expect(await pendingCard.evaluate((element) => element.scrollWidth <= element.clientWidth)).toBe(true)
    await pendingCard.getByRole('button', { name: '收起', exact: true }).click()
    await pendingCard.getByRole('button', { name: '展开', exact: true }).click()
    await page.setViewportSize({ width: 1680, height: 1000 })
    await host.ctx.settings.replace('locale', { preference: 'en' })
    diagnostics.stage('locale-en-restored')
    const leadUrl = page.url()
    for (const name of ['calculator-b', 'calculator']) {
      diagnostics.stage(`${name}-open-approval`)
      await page.getByRole('button', { name: `${name} · Pending request`, exact: true }).click()
      // The native sidebar can keep both children visible in separate panes.
      // Resolve the member's own conversation, including after approval settles.
      const description = name === 'calculator' ? 'Compute fixture' : 'Model B member'
      const memberTab = page
        .getByRole('tab', { selected: true })
        .filter({ has: page.getByText(description, { exact: true }) })
      const sidebar = page
        .locator('[data-dockkit-pane]')
        .filter({ has: memberTab })
        .locator('[data-sidebar-chat]:visible')
      await sidebar.locator('[data-approval-key]').waitFor()
      expect(await sidebar.getByRole('button', { name: /^Select model/ }).count()).toBe(0)
      expect(page.url()).toBe(leadUrl)
      const id = name === 'calculator' ? childAId : childBId
      const completion = setupDecisions({
        root: lead,
        entries: [
          {
            owner: name,
            callId: 'team-3',
            tool: 'send_message',
            args: { target: 'lead', message: 'E2E_TEAM_REPLY result=2' },
          },
          ...teamReplySteps(),
        ],
      })
      const completionStart = events.length
      await sidebar.locator('[data-approval-key]').getByRole('button', { name: 'Allow once', exact: true }).click()
      diagnostics.stage(`${name}-member-done`)
      await sidebar.getByText('E2E_TEAM_MEMBER_DONE', { exact: true }).waitFor()
      diagnostics.stage(`${name}-member-turn-end`)
      await vi.waitFor(
        () => expect(events.some((event) => event.sessionId === id && event.type === 'turn/end')).toBe(true),
        { timeout: 20_000 },
      )
      diagnostics.stage(`${name}-parent-settlement`)
      await waitForTeamSettlement(events, { parentId: lead.id, childId: id, after: completionStart })
      diagnostics.stage(`${name}-lead-idle`)
      await lead.whenIdle()
      diagnostics.stage(`${name}-completion-plan`)
      completion.finish()
      expect(page.url()).toBe(leadUrl)
      if (name === 'calculator-b') {
        await page.getByRole('button', { name: 'calculator · Pending request', exact: true }).waitFor()
        expect(events.some((event) => event.sessionId === childAId && event.type === 'turn/end')).toBe(false)
      }
    }
    diagnostics.stage('all-members-idle')
    await vi.waitFor(async () => expect(await pendingCard.count()).toBe(0))
    await vi.waitFor(
      () =>
        expect(
          host.ctx.agentTeams.listMembers(lead).every((member) => ['idle', 'inactive'].includes(member.status)),
        ).toBe(true),
      { timeout: 30_000 },
    )
    // Cold resume A after the Lead changed to B: A must keep its own configuration.
    const before = events
      .filter((event) => event.type === 'request/header')
      .filter((event) => event.sessionId === childAId).length
    const continuation = setupDecisions({
      root: lead,
      entries: [
        { owner: 'calculator', callId: 'team-1', tool: 'list_agents', args: {} },
        {
          owner: 'calculator',
          callId: 'team-2',
          tool: 'send_message',
          args: { target: 'lead', message: 'E2E_TEAM_REPLY continued' },
        },
        ...teamReplySteps(),
      ],
    })
    const continuationStart = events.length
    diagnostics.stage('continuation-send')
    await host.ctx.agentTeams.sendMessage(lead, {
      target: 'calculator',
      content: [{ type: 'text', text: 'E2E_TEAM_CONTINUE' }],
      signal: new AbortController().signal,
    })
    diagnostics.stage('continuation-header')
    await vi.waitFor(
      () =>
        expect(
          events.filter((event) => event.type === 'request/header').filter((event) => event.sessionId === childAId)
            .length,
        ).toBeGreaterThan(before),
      { timeout: 30_000 },
    )
    expect(
      required(
        events.filter((event) => event.type === 'request/header').findLast((event) => event.sessionId === childAId),
      ).data.header.config,
    ).toMatchObject({ provider: 'acp-devin', model: 'mock-model-a' })
    diagnostics.stage('continuation-child-idle')
    await required(host.ctx.agents.get(childAId)).whenIdle()
    diagnostics.stage('continuation-parent-settlement')
    await waitForTeamSettlement(events, { parentId: lead.id, childId: childAId, after: continuationStart })
    diagnostics.stage('continuation-lead-idle')
    await lead.whenIdle()
    diagnostics.stage('continuation-plan')
    continuation.finish()
    diagnostics.stage('cross-agent-restore-dialog')
    const selectModel = host.ctx.sessionController.selectModel.bind(host.ctx.sessionController)
    let failSourceRestore = true
    const failedSourceRestore = vi
      .spyOn(host.ctx.sessionController, 'selectModel')
      .mockImplementation(async (request) => {
        if (request.provider === 'acp-devin' && failSourceRestore) {
          failSourceRestore = false
          throw new Error('E2E_CROSS_BACKEND_RESTORE_RAW')
        }
        return selectModel(request)
      })
    await page.getByRole('button', { name: /^Select model/ }).click()
    await page.getByRole('menuitem', { name: /^Model/ }).click()
    await page
      .getByLabel('Fixture codex · ACP', { exact: true })
      .getByRole('menuitemradio', { name: 'Mock Model B', exact: true })
      .click()
    const dialog = page.getByRole('dialog').last()
    try {
      await dialog.getByText('New session required', { exact: true }).waitFor()
      await host.ctx.settings.replace('locale', { preference: 'zh' })
      await expect.poll(() => dialog.getByText('无法恢复当前会话原先使用的模型', { exact: true }).count()).toBe(1)
      expect(await dialog.locator('pre').count()).toBe(0)
      const diagnostics = dialog.getByRole('button', { name: '查看技术详情', exact: true })
      await diagnostics.click()
      await expect.poll(() => diagnostics.getAttribute('aria-expanded')).toBe('true')
      await dialog.locator('pre').waitFor({ state: 'visible' })
      await expect.poll(() => dialog.locator('pre').textContent()).toBe('restore-source\nE2E_CROSS_BACKEND_RESTORE_RAW')
      await dialog.getByRole('button', { name: '取消', exact: true }).last().click()
    } finally {
      failedSourceRestore.mockRestore()
      await host.ctx.settings.replace('locale', { preference: 'en' })
    }
    const selected = required(host.ctx.sessionProjections.stateOf(lead.session, 'modelSelection'))
    expect(selected.pending ?? selected.lastUsed).toMatchObject({ provider: 'acp-devin', model: 'mock-model-b' })
    Object.assign(evidence, {
      leadId: lead.id,
      childAId,
      childBId,
      selected,
      roster: host.ctx.agentTeams.listMembers(lead),
      ordinaryApprovals: memberAudit('asked')
        .filter((entry) => entry.sessionId === childAId || entry.sessionId === childBId)
        .map((entry) => ({ sessionId: entry.sessionId, tool: entry.data.toolCall })),
    })
    expect(evidence.ordinaryApprovals).toHaveLength(2)
    await page.screenshot({ path: join(root, '.local/teams-review/multiple-models.png'), fullPage: true })
    diagnostics.stage('cross-agent-new-session')
    await page.getByRole('button', { name: /^Select model/ }).click()
    await page.getByRole('menuitem', { name: /^Model/ }).click()
    await page
      .getByLabel('Fixture codex · ACP', { exact: true })
      .getByRole('menuitemradio', { name: 'Mock Model B', exact: true })
      .click()
    await dialog.getByRole('button', { name: 'Continue', exact: true }).click()
    await send('E2E_MESSAGE')
    diagnostics.stage('cross-agent-new-session-done')
    await page.getByText('E2E_DONE mock-model-b', { exact: true }).waitFor()
    const destinationId = required(
      events.findLast((event) => event.type === 'request/header' && event.data.header.config.provider === 'acp-codex'),
    ).sessionId
    expect(destinationId).not.toBe(lead.id)
    expect(host.ctx.agentTeams.listMembers(required(host.ctx.agents.get(destinationId)))).toHaveLength(1)
    expect(host.ctx.agentTeams.listMembers(lead)).toHaveLength(3)
    evidence.crossAgentDestinationId = destinationId
    // No browser coordinator is present: a direct Remote selection must not bypass host execution policy.
    await page.goto('about:blank')
    diagnostics.stage('cross-agent-negative-idle')
    await vi.waitFor(() => expect(lead.status).toBe('idle'), { timeout: 30_000 })
    await host.ctx.sessionController.selectModel({ sessionId: lead.id, provider: 'acp-codex', model: 'mock-model-a' })
    diagnostics.stage('cross-agent-negative-prompt')
    await host.ctx.sessionController.prompt(
      {
        requestId: 'cross-agent-negative' as SessionRequestId,
        sessionId: lead.id,
        mode: 'queue',
        content: [{ type: 'text', text: 'E2E_MESSAGE' }],
      },
      new AbortController().signal,
    )
    diagnostics.stage('cross-agent-negative-error')
    await vi.waitFor(
      () =>
        expect(
          events.some(
            (event) =>
              event.sessionId === lead.id &&
              event.type === 'turn/end' &&
              event.data.reason.kind === 'error' &&
              event.data.reason.error.message.includes('changes the execution backend'),
          ),
        ).toBe(true),
      { timeout: 20_000 },
    )
    expect(
      events.some(
        (event) =>
          event.sessionId === lead.id &&
          event.type === 'request/header' &&
          event.data.header.config.provider === 'acp-codex',
      ),
    ).toBe(false)
    evidence.crossAgentExecutionRejected = true
    diagnostics.stage('complete')
  } finally {
    await cleanup()
  }
}, 120_000)

it('preserves native Teams model inheritance and switching with the ACP plugin installed', async () => {
  const { host, browser, page, send } = await setup(true, true)
  const headers: { id: string; config: { provider: string; model: string } }[] = [],
    settled: { id: string; reason: unknown }[] = []
  host.ctx.on('session/event', (session, event) => {
    if (event.type === 'request/header') headers.push({ id: session.id, config: event.data.header.config })
    if (event.type === 'turn/end') settled.push({ id: session.id, reason: event.data.reason })
  })
  try {
    await send('native baseline')
    await page.getByText('NATIVE_TEAM_DONE native-a', { exact: true }).first().waitFor()
    const lead = host.ctx.agents.list().find((agent) => host.ctx.agentTeams.tryMembership(agent)?.role === 'lead')
    const spawn = (name: string) =>
      host.ctx.agentTeams.spawnTeammate(required(lead), {
        name,
        description: name,
        prompt: [{ type: 'text', text: 'Calculate 1+1' }],
        context: 'fresh',
        provider: 'spawn',
        signal: new AbortController().signal,
      })
    const first = await spawn('native-first')
    await vi.waitFor(
      () => expect(headers.some((item) => item.id === first.member.id && item.config.model === 'native-a')).toBe(true),
      { timeout: 20_000 },
    )
    await page.getByRole('button', { name: /^Select model/ }).click()
    await page.getByRole('menuitem', { name: /^Model/ }).click()
    await page.getByRole('menuitemradio', { name: 'native-b', exact: true }).click()
    await send('use model B')
    await page.getByText('NATIVE_TEAM_DONE native-b', { exact: true }).first().waitFor()
    const second = await spawn('native-second')
    await vi.waitFor(
      () => expect(headers.some((item) => item.id === second.member.id && item.config.model === 'native-b')).toBe(true),
      { timeout: 20_000 },
    )
    await vi.waitFor(
      () => {
        for (const id of [first.member.id, second.member.id])
          expect(settled.find((item) => item.id === id)?.reason).toMatchObject({ kind: 'completed' })
      },
      { timeout: 20_000 },
    )
    expect(
      headers.filter((item) => item.id === first.member.id).every((item) => item.config.model === 'native-a'),
    ).toBe(true)
    expect(await page.getByRole('dialog').count()).toBe(0)
    expect(await page.locator('[data-team-action]').isVisible()).toBe(true)
    expect(required(host.ctx.tools.get('spawn_teammate', lead)).parameters).toMatchObject({
      properties: { context: { enum: expect.arrayContaining(['fork']) } },
    })
  } finally {
    await browser.close()
    await host.close()
  }
}, 90_000)
