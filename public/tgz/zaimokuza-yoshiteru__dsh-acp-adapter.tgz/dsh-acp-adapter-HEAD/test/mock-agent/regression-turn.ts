import type { MockSession, PromptMessage, MockPeer } from './types.ts'
// Keyless product scenarios. Profiles vary wire representations, never assertions.
import fs from 'node:fs'
import { basename, dirname, join } from 'node:path'
import { teamTurn } from './team-turn.ts'
import { teamWaitTurn } from './team-wait-turn.ts'
import { hostToolsTurn } from './host-tools-turn.ts'
import { settlementTurn } from './settlement-turn.ts'
import { scheduleTurn } from './schedule-turn.ts'
import { longConversationTurn } from './long-conversation-turn.ts'
import { optionalToolsTurn } from './optional-tools-turn.ts'
import { workDetailsTurn } from './work-details-turn.ts'
import { richMixedTurn } from './rich-mixed-turn.ts'
import { committedRepliesTurn } from './committed-replies-turn.ts'
import { permissionOptionsTurn } from './permission-options-turn.ts'

export async function regressionTurn(
  session: MockSession,
  msg: PromptMessage,
  { sendUpdate, sendAgentRequest, respond, log }: MockPeer,
) {
  if (await teamWaitTurn(session, msg, { sendUpdate, sendAgentRequest, respond, log })) return
  if (await permissionOptionsTurn(session, msg, { sendUpdate, sendAgentRequest, respond, log })) return
  if (await committedRepliesTurn(session, msg, { sendUpdate, sendAgentRequest, respond, log })) return
  if (await richMixedTurn(session, msg, { sendUpdate, sendAgentRequest, respond, log })) return
  if (await workDetailsTurn(session, msg, { sendUpdate, sendAgentRequest, respond, log })) return
  if (await optionalToolsTurn(session, msg, { sendUpdate, sendAgentRequest, respond, log })) return
  if (await teamTurn(session, msg, { sendUpdate, sendAgentRequest, respond, log })) return
  if (await scheduleTurn(session, msg, { sendUpdate, sendAgentRequest, respond, log })) return
  if (await longConversationTurn(session, msg, { sendUpdate, sendAgentRequest, respond, log })) return
  if (await settlementTurn(session, msg, { sendUpdate, sendAgentRequest, respond, log })) return
  if (await hostToolsTurn(session, msg, { sendUpdate, sendAgentRequest, respond })) return
  const prompt = msg.params.prompt
    .filter((block) => block.type === 'text')
    .map((block) => block.text)
    .join('\n')
  const profile = process.env.MOCK_PROFILE
  const model = session.configOptions?.find((option) => option.id === 'model')?.currentValue
  const thoughtLevel = session.configOptions?.find((option) => option.id === 'thought_level')?.currentValue
  log(
    `regression prompt=${JSON.stringify(prompt)} model=${model} thought_level=${String(thoughtLevel)} session=${session.id}`,
  )
  const file = /verbatim read-only copy saved at ("(?:[^"\\]|\\.)*")/.exec(prompt)
  if (file) log(`regression file-bytes=${fs.readFileSync(JSON.parse(file[1]), 'utf8')}`)
  let release!: () => void
  const cancelled = new Promise<void>((resolve) => {
    release = resolve
  })
  session.turn = {
    cancelled: false,
    cancel() {
      this.cancelled = true
      release()
    },
  }
  const say = (text: string) =>
    sendUpdate(session.id, { sessionUpdate: 'agent_message_chunk', content: { type: 'text', text } })
  const waitForFileGate = async (
    directory: string,
    filename: string,
    description: string,
    signal: AbortSignal,
  ): Promise<boolean> => {
    const marker = join(directory, filename)
    if (signal.aborted) return false
    if (fs.existsSync(marker)) return true
    return new Promise<boolean>((resolve, reject) => {
      let watcher: ReturnType<typeof fs.watch> | undefined
      let timer: NodeJS.Timeout | undefined
      const cleanup = (): void => {
        watcher?.close()
        if (timer !== undefined) clearTimeout(timer)
        signal.removeEventListener('abort', onAbort)
      }
      const finish = (released: boolean): void => {
        cleanup()
        resolve(released)
      }
      const onAbort = (): void => finish(false)
      watcher = fs.watch(dirname(marker), (_event, filename) => {
        if (filename?.toString() !== basename(marker) || !fs.existsSync(marker)) return
        finish(true)
      })
      watcher.once('error', (error) => {
        cleanup()
        reject(error)
      })
      signal.addEventListener('abort', onAbort, { once: true })
      timer = setTimeout(() => {
        cleanup()
        reject(new Error(`Timed out waiting for ${description} test gate`))
      }, 20_000)
      if (signal.aborted) finish(false)
      else if (fs.existsSync(marker)) finish(true)
    })
  }
  const waitForRenderGate = async (index: number, signal: AbortSignal): Promise<boolean> => {
    const directory = process.env.MOCK_RENDER_GATE_DIR
    if (directory === undefined) throw new Error('MOCK_RENDER_GATE_DIR is required for E2E_RENDER_STREAM')
    return waitForFileGate(directory, `continue-${index}`, 'render', signal)
  }
  const waitForSteeringAckGate = async (signal: AbortSignal): Promise<boolean> => {
    const directory = process.env.MOCK_STEERING_ACK_GATE_DIR
    if (directory === undefined) throw new Error('MOCK_STEERING_ACK_GATE_DIR is required for E2E_STEERING_ACK_RACE')
    return waitForFileGate(directory, 'release-steering-ack', 'steering acknowledgement', signal)
  }
  try {
    if (prompt.includes('E2E_UNFINISHED_TOOL_STOP')) {
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call',
        toolCallId: 'unfinished-fixture',
        title: 'Scripted tool without terminal update',
        kind: 'execute',
        status: 'in_progress',
      })
      say('E2E_UNFINISHED_STOP_RUNNING')
      await cancelled
      return respond(msg.id, { stopReason: 'cancelled' })
    }
    if (prompt.includes('E2E_UNFINISHED_TOOL_FIRST')) {
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call',
        toolCallId: 'unfinished-fixture',
        title: 'Scripted tool without terminal update',
        kind: 'read',
        status: 'in_progress',
      })
      say('E2E_UNFINISHED_FIRST_DONE')
      return respond(msg.id, { stopReason: 'end_turn' })
    }
    if (prompt.includes('E2E_UNFINISHED_TOOL_NEXT')) {
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call',
        toolCallId: 'next-turn-terminal-fixture',
        title: 'Next turn terminal tool',
        kind: 'read',
        status: 'completed',
        rawOutput: 'fixture complete',
      })
      say('E2E_UNFINISHED_NEXT_DONE')
      return respond(msg.id, { stopReason: 'end_turn' })
    }
    const recoveryCrash = /E2E_RECOVERY_(QUEUE|PERMISSION)_CRASH/.exec(prompt)?.[1]
    if (profile === 'devin' && recoveryCrash !== undefined) {
      const directory = process.env.MOCK_RECOVERY_GATE_DIR
      if (directory === undefined) throw new Error('MOCK_RECOVERY_GATE_DIR is required for recovery E2E')
      fs.mkdirSync(directory, { recursive: true })
      const key = recoveryCrash.toLowerCase()
      if (recoveryCrash === 'PERMISSION') {
        say('E2E_RECOVERY_PERMISSION_RUNNING')
        fs.writeFileSync(join(directory, `${key}-started.ready`), 'ready')
        const proceedToPermission = await waitForFileGate(
          directory,
          `release-${key}-request`,
          `${key} permission request`,
          new AbortController().signal,
        )
        if (!proceedToPermission) throw new Error('Failed to release the permission request gate')
        sendUpdate(session.id, {
          sessionUpdate: 'tool_call',
          toolCallId: 'recovery-permission-crash',
          title: 'Write recovery approval marker',
          kind: 'execute',
          status: 'pending',
          rawInput: { command: 'echo E2E_RECOVERY_PERMISSION_APPROVED' },
        })
        void sendAgentRequest('session/request_permission', {
          sessionId: session.id,
          toolCall: {
            toolCallId: 'recovery-permission-crash',
            title: 'Write recovery approval marker',
            kind: 'execute',
            status: 'pending',
            rawInput: { command: 'echo E2E_RECOVERY_PERMISSION_APPROVED' },
          },
          options: [
            { optionId: 'allow-recovery-once', kind: 'allow_once', name: 'Allow this operation' },
            { optionId: 'reject-recovery-once', kind: 'reject_once', name: 'Reject this operation' },
          ],
        })
          .then((answer) => {
            log(`recovery permission answer=${JSON.stringify(answer)}`)
            if (answer?.outcome?.optionId === 'allow-recovery-once')
              fs.writeFileSync(`${session.cwd}/recovery-approval-marker.txt`, 'E2E_RECOVERY_PERMISSION_APPROVED')
          })
          .catch((error: unknown) => {
            log(`recovery permission request closed=${error instanceof Error ? error.message : String(error)}`)
          })
        fs.writeFileSync(join(directory, `${key}-permission-requested.ready`), 'ready')
      } else {
        say('E2E_RECOVERY_QUEUE_CRASH_RUNNING')
        fs.writeFileSync(join(directory, `${key}-started.ready`), 'ready')
      }
      const released = await waitForFileGate(
        directory,
        `release-${key}-crash`,
        `${key} recovery crash`,
        new AbortController().signal,
      )
      if (!released) throw new Error(`Failed to release the ${key} recovery crash gate`)
      process.exit(49)
    }
    if (prompt.includes('E2E_RECOVERY_FOLLOWUP')) {
      say('E2E_RECOVERY_FOLLOWUP_DONE')
      return respond(msg.id, { stopReason: 'end_turn' })
    }
    const externalChildScenario = /E2E_EXTERNAL_CHILD_(SUCCESS|FAILURE|PARENT_CANCELLED)/.exec(prompt)?.[1]
    if (profile === 'devin' && externalChildScenario !== undefined) {
      const directory = process.env.MOCK_EXTERNAL_CHILD_GATE_DIR
      if (directory === undefined) throw new Error('MOCK_EXTERNAL_CHILD_GATE_DIR is required for external-child E2E')
      fs.mkdirSync(directory, { recursive: true })
      const key = externalChildScenario.toLowerCase().replaceAll('_', '-')
      const toolCallId = `external-child-${key}`
      const agentId = `external-${key}`
      const startedFile = `${key}-started.ready`
      const releaseLaunch = `release-${key}-launch-tool`
      const toolCompleteFile = `${key}-launch-tool-completed.ready`
      const releaseChild = `release-${key}-child-terminal`
      const terminalFile = `${key}-child-terminal.ready`
      const turnAbort = new AbortController()
      void cancelled.then(() => turnAbort.abort())
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call',
        toolCallId,
        title: 'Inspect fixture',
        kind: 'other',
        status: 'in_progress',
        rawInput: { prompt: `Inspect ${key} fixture` },
        ...(externalChildScenario === 'SUCCESS'
          ? { content: [{ type: 'content', content: { type: 'text', text: 'Success child tool output fixture.' } }] }
          : {}),
        _meta: {
          'cognition.ai/subagent_started': {
            agentId,
            title: `${key} research`,
            task: `Inspect external child lifecycle: ${key}`,
          },
        },
      })
      fs.writeFileSync(join(directory, startedFile), 'ready')
      if (externalChildScenario === 'SUCCESS') {
        sendUpdate(session.id, {
          sessionUpdate: 'tool_call',
          toolCallId: `${toolCallId}:0:content`,
          title: 'Parent validation',
          kind: 'other',
          status: 'completed',
          rawInput: { file_path: '/work/fixture/parent-check.ts' },
          rawOutput: { result: 'Parent validation completed.' },
        })
      }
      if (!(await waitForFileGate(directory, releaseLaunch, 'external child launch tool', turnAbort.signal)))
        return respond(msg.id, { stopReason: 'cancelled' })
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call_update',
        toolCallId,
        status: 'completed',
        rawOutput: { result: 'Child launched; awaiting its independent report.' },
      })
      fs.writeFileSync(join(directory, toolCompleteFile), 'ready')
      const releasedChild = await waitForFileGate(directory, releaseChild, 'external child terminal', turnAbort.signal)
      if (!releasedChild || session.turn?.cancelled === true) return respond(msg.id, { stopReason: 'cancelled' })
      const failed = externalChildScenario === 'FAILURE'
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call_update',
        toolCallId,
        status: 'completed',
        _meta: {
          'cognition.ai/subagent_completed': {
            agentId,
            success: !failed,
            ...(failed ? {} : { summary: `Inspection complete for ${key}.` }),
          },
        },
      })
      fs.writeFileSync(join(directory, terminalFile), 'ready')
      say(`E2E_EXTERNAL_CHILD_${externalChildScenario}_DONE`)
      return respond(msg.id, { stopReason: 'end_turn' })
    }
    if (prompt.includes('E2E_STEERING_ACK_RACE')) {
      const inputs: string[] = []
      let acknowledgedSteers = 0
      let acknowledgementAvailable: (() => void) | undefined
      const gateAbort = new AbortController()
      void cancelled.then(() => {
        gateAbort.abort()
        acknowledgementAvailable?.()
        acknowledgementAvailable = undefined
      })
      const waitForSteeringAcks = async (count: number): Promise<void> => {
        while (acknowledgedSteers < count && !session.turn?.cancelled)
          await new Promise<void>((resolve, reject) => {
            const timer = setTimeout(
              () => reject(new Error('Timed out waiting for steering RPC acknowledgements')),
              20_000,
            )
            acknowledgementAvailable = () => {
              clearTimeout(timer)
              resolve()
            }
          })
      }
      session.turn.steer = async (blocks) => {
        const text = blocks
          .filter((block) => block.type === 'text')
          .map((block) => block.text)
          .join('\n')
        inputs.push(text)
        log(`regression steer=${JSON.stringify(text)} session=${session.id}`)
        if (inputs.length === 1) {
          log(`steering-ack-pending session=${session.id}`)
          if (!(await waitForSteeringAckGate(gateAbort.signal)))
            throw new Error('Steering acknowledgement gate cancelled')
        }
      }
      session.turn.steerAcknowledged = () => {
        acknowledgedSteers += 1
        acknowledgementAvailable?.()
        acknowledgementAvailable = undefined
      }
      say('E2E_STEERING_ACK_RACE_RUNNING')
      await waitForSteeringAcks(2)
      if (session.turn.cancelled) return respond(msg.id, { stopReason: 'cancelled' })
      say('E2E_STEERING_ACK_RACE_DONE')
      gateAbort.abort()
      return respond(msg.id, { stopReason: 'end_turn' })
    }
    if (prompt.includes('E2E_STEERING_HOLD')) {
      let receive!: (text: string) => void
      const steered = new Promise<string>((resolve) => {
        receive = resolve
      })
      session.turn.steer = (blocks) => {
        const text = blocks
          .filter((block) => block.type === 'text')
          .map((block) => block.text)
          .join('\n')
        log(`regression steer=${JSON.stringify(text)} session=${session.id}`)
        receive(text)
      }
      say('E2E_STEERING_RUNNING')
      log(`regression steering-held session=${session.id}`)
      const input = await Promise.race([steered, cancelled.then(() => null)])
      if (input === null) {
        log(`regression steering-cancelled session=${session.id}`)
        // Verify the adapter drains late updates before starting the next prompt.
        await new Promise((resolve) => setTimeout(resolve, 50))
        say('E2E_OLD_TURN_DRAINED')
        return respond(msg.id, { stopReason: 'cancelled' })
      }
      await new Promise((resolve) => setTimeout(resolve, 50))
      say(input.includes('E2E_INPUT_REWRITTEN') ? 'E2E_STEER_DONE' : 'E2E_STEER_WRONG_INPUT')
      return respond(msg.id, { stopReason: 'end_turn' })
    }
    if (prompt.includes('E2E_NATIVE_PLAN_DIFF')) {
      const prefix = 'unchanged line\n'.repeat(6000)
      sendUpdate(session.id, {
        sessionUpdate: 'plan',
        entries: [{ content: 'E2E_PLAN_REMAINS', status: 'in_progress', priority: 'high' }],
      })
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call',
        toolCallId: 'long-edit',
        title: 'Edit full.txt',
        kind: 'edit',
        status: 'completed',
        content: [
          { type: 'diff', path: 'full.txt', oldText: prefix + 'E2E_OLD_TAIL\n', newText: prefix + 'E2E_NEW_TAIL\n' },
        ],
      })
      say('E2E_NATIVE_PLAN_DIFF_DONE')
      return respond(msg.id, { stopReason: 'end_turn' })
    }
    if (prompt.includes('E2E_CRASH')) process.exit(49)
    if (prompt.includes('E2E_STREAM_SEGMENTS')) {
      const emit = async (kind: string, text: string, messageId?: string) => {
        sendUpdate(session.id, {
          sessionUpdate: kind,
          content: { type: 'text', text },
          ...(messageId ? { messageId } : {}),
        })
        await new Promise((resolve) => setTimeout(resolve, 200))
      }
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call',
        toolCallId: 'segment-setup',
        title: '准备计数器工作区',
        kind: 'execute',
        status: 'in_progress',
        rawInput: { command: 'printf ready' },
      })
      await emit('agent_thought_chunk', '\n\n先规划计数器页面。')
      await emit('agent_message_chunk', '页面骨架', 'answer-1')
      // The setup tool started before this answer. Its delayed completion must
      // not split two chunks that still belong to the same ACP message.
      sendUpdate(session.id, { sessionUpdate: 'tool_call_update', toolCallId: 'segment-setup', status: 'completed' })
      await emit('agent_message_chunk', '已完成。', 'answer-1')
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call',
        toolCallId: 'segment-plan',
        title: 'list_agents',
        kind: 'execute',
        status: 'completed',
        rawInput: { server: 'dshteam_0867544f17003968', tool: '0867544f17003968_list_agents', arguments: {} },
      })
      await emit('agent_thought_chunk', '再检查按钮事件。')
      await emit('agent_message_chunk', '按钮交互已完成。', 'answer-2')
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call',
        toolCallId: 'segment-check',
        title: 'send_message',
        kind: 'execute',
        status: 'in_progress',
        rawInput: {
          server: 'dshteam_0867544f17003968',
          tool: '0867544f17003968_send_message',
          arguments: { target: 'repo-codex', message: 'Review the counter' },
        },
      })
      sendUpdate(session.id, { sessionUpdate: 'tool_call_update', toolCallId: 'segment-check', status: 'completed' })
      await emit('agent_message_chunk', '检查结果正常。', 'answer-3')
      await emit('agent_message_chunk', '演示结束。', 'answer-4')
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call',
        toolCallId: 'segment-tail',
        title: '保存检查结果',
        kind: 'edit',
        status: 'completed',
      })
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call_update',
        toolCallId: 'segment-setup',
        status: 'completed',
        rawOutput: { formatted_output: 'ready', exit_code: 0 },
      })
      if (prompt.includes('CANCEL')) {
        await cancelled
        return respond(msg.id, { stopReason: 'cancelled' })
      }
    } else if (prompt.includes('E2E_JOB_START')) {
      const stopFile = `${session.cwd}/job-stop-${Date.now()}`
      const readyFile = `${stopFile}.ready`
      const outputFile = `${stopFile}.output`
      // Keep the output marker out of the command label so the native UI test
      // cannot mistake the command text for received process output.
      fs.writeFileSync(outputFile, 'E2E_JOB_TICK\n')
      const immediate = prompt.includes('E2E_JOB_START_IMMEDIATE')
      const script = `const fs=require('node:fs'); process.stdout.write(fs.readFileSync(${JSON.stringify(outputFile)})); fs.writeFileSync(${JSON.stringify(readyFile)},'ready'); ${immediate ? 'process.exit(0)' : `setInterval(()=>{if(fs.existsSync(${JSON.stringify(stopFile)})) process.exit(Number(fs.readFileSync(${JSON.stringify(stopFile)},'utf8')));},25)`}`
      const created = await sendAgentRequest('terminal/create', {
        sessionId: session.id,
        command: process.execPath,
        args: ['-e', script],
        cwd: session.cwd,
      })
      session.backgroundTerminal = created.terminalId
      log(`regression job=${JSON.stringify({ terminalId: created.terminalId, stopFile, readyFile })}`)
      if (immediate)
        await sendAgentRequest('terminal/wait_for_exit', { sessionId: session.id, terminalId: created.terminalId })
      say('E2E_JOB_STARTED')
    } else if (prompt.includes('E2E_JOB_STOP')) {
      await sendAgentRequest('terminal/kill', { sessionId: session.id, terminalId: session.backgroundTerminal })
      await sendAgentRequest('terminal/wait_for_exit', {
        sessionId: session.id,
        terminalId: session.backgroundTerminal,
      })
      say('E2E_JOB_STOPPED')
    } else if (prompt.includes('E2E_JOB_READ')) {
      const output = await sendAgentRequest('terminal/output', {
        sessionId: session.id,
        terminalId: session.backgroundTerminal,
      })
      say(`E2E_JOB_OUTPUT ${JSON.stringify(output)}`)
      await sendAgentRequest('terminal/release', { sessionId: session.id, terminalId: session.backgroundTerminal })
    } else if (prompt.includes('E2E_JOB_OTHER')) {
      say('E2E_JOB_OTHER_DONE')
    } else if (prompt.includes('E2E_RECOVERED')) {
      say('E2E_RECOVERED_DONE')
    } else if (prompt.includes('E2E_RENDER_STREAM')) {
      const renderAbort = new AbortController()
      void cancelled.then(() => renderAbort.abort())
      const releaseOrCancel = async (index: number): Promise<boolean> => waitForRenderGate(index, renderAbort.signal)
      sendUpdate(session.id, {
        sessionUpdate: 'agent_message_chunk',
        content: { type: 'text', text: 'E2E_RENDER_READY' },
        messageId: 'render-probe-answer',
      })
      try {
        if (!(await releaseOrCancel(-1))) return respond(msg.id, { stopReason: 'cancelled' })
        for (let index = 0; index < 5; index++) {
          sendUpdate(session.id, {
            sessionUpdate: 'agent_message_chunk',
            content: { type: 'text', text: `E2E_RENDER_CHUNK_${index}` },
            messageId: 'render-probe-answer',
          })
          if (!(await releaseOrCancel(index))) return respond(msg.id, { stopReason: 'cancelled' })
        }
        return respond(msg.id, { stopReason: 'end_turn' })
      } finally {
        renderAbort.abort()
      }
    } else if (prompt.includes('E2E_SCROLL')) {
      for (let i = 0; i < 60; i++) {
        say(`Paragraph ${i}: deterministic streaming content for native scrolling.\n\n`)
        await new Promise((resolve) => setTimeout(resolve, 10))
      }
      say('E2E_SCROLL_END')
    } else if (prompt.includes('E2E_RICH')) {
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call',
        toolCallId: 'read-1',
        title: 'Read fixture file',
        kind: 'read',
        status: 'completed',
        rawInput: { path: 'fixture.txt' },
        rawOutput: '1\tE2E_READ_LINE\n',
      })
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call',
        toolCallId: 'edit-1',
        title: 'Edit fixture file',
        kind: 'edit',
        status: 'completed',
        content: [{ type: 'diff', path: 'fixture.txt', oldText: 'E2E_OLD_LINE\n', newText: 'E2E_NEW_LINE\n' }],
      })
      sendUpdate(session.id, {
        sessionUpdate: 'agent_message_chunk',
        content: {
          type: 'image',
          mimeType: 'image/png',
          data: 'iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAEklEQVQImWMImHYnYNodBggFAC8WBwlf8b0ZAAAAAElFTkSuQmCC',
        },
      })
      say('E2E_RICH_DONE')
    } else if (prompt.includes('E2E_CONTROLS_WAIT')) {
      say('E2E_CONTROLS_RUNNING')
      while (!session.turn.cancelled && !fs.existsSync(process.env.MOCK_CONTROLS_READY_FILE ?? '')) {
        await Promise.race([cancelled, new Promise((resolve) => setTimeout(resolve, 25))])
      }
      if (!session.turn.cancelled) {
        const mode = session.configOptions?.find((option) => option.id === 'mode')
        if (!mode || !session.modes) throw new Error('Missing fixture mode controls')
        mode.currentValue = 'plan'
        session.modes.currentModeId = 'plan'
        sendUpdate(session.id, { sessionUpdate: 'config_option_update', configOptions: session.configOptions })
        sendUpdate(session.id, { sessionUpdate: 'current_mode_update', currentModeId: 'plan' })
        say('E2E_CONTROLS_UPDATED')
        await cancelled
      }
      return respond(msg.id, { stopReason: 'cancelled' })
    } else if (prompt.includes('E2E_STOP')) {
      say('E2E_RUNNING')
      await cancelled
      log('regression cancelled')
      return respond(msg.id, { stopReason: 'cancelled' })
    } else if (prompt.includes('E2E_PERMISSION')) {
      const options = [
        { optionId: 'permit-single', kind: 'allow_once', name: 'Allow this operation' },
        { optionId: 'deny-single', kind: 'reject_once', name: 'Reject this operation' },
      ]
      const answer = await Promise.race([
        sendAgentRequest('session/request_permission', {
          sessionId: session.id,
          toolCall: {
            toolCallId: 'permission-1',
            title: 'Write approval marker',
            kind: 'execute',
            rawInput: { command: 'echo E2E_APPROVED' },
          },
          options: profile === 'kimi' ? [...options].reverse() : options,
        }),
        cancelled.then(() => null),
      ])
      log(`regression permission=${JSON.stringify(answer)}`)
      if (session.turn.cancelled) return respond(msg.id, { stopReason: 'cancelled' })
      const allowed = answer?.outcome?.optionId === 'permit-single'
      if (allowed) fs.writeFileSync(`${session.cwd}/approval-marker.txt`, 'E2E_APPROVED')
      say(allowed ? 'E2E_APPROVED' : 'E2E_DENIED')
    } else if (prompt.includes('E2E_PLUGIN_FOLLOWUP')) {
      if (prompt.includes('E2E_SYSTEM_A') || prompt.includes('E2E_CONTEXT_A'))
        throw new Error('Redundant host instructions or earlier user input was replayed')
      say('E2E_FOLLOWUP_DONE')
    } else if (/E2E_CONTEXT_[AB]/.test(prompt)) {
      const version = prompt.includes('E2E_CONTEXT_B') ? 'B' : 'A'
      for (const marker of [`E2E_SYSTEM_${version}`, `E2E_RUNTIME_${version}`, 'E2E_PLUGIN_INPUT']) {
        if (!prompt.includes(marker)) throw new Error(`Missing host contribution: ${marker}`)
      }
      if (version === 'B' && (prompt.includes('E2E_CONTEXT_A') || prompt.includes('E2E_RUNTIME_A')))
        throw new Error('Earlier host input was replayed')
      say(`E2E_CONTEXT_${version}_DONE`)
    } else if (prompt.includes('E2E_CHILD')) {
      const toolCallId = 'delegation-1'
      if (profile === 'claude') {
        sendUpdate(session.id, {
          sessionUpdate: 'tool_call',
          toolCallId,
          title: 'Inspect fixture',
          kind: 'other',
          status: 'in_progress',
          rawInput: { prompt: 'E2E_CHILD_TASK', description: 'Inspect fixture' },
          _meta: { claudeCode: { subagent: true } },
        })
        sendUpdate(session.id, {
          sessionUpdate: 'tool_call_update',
          toolCallId,
          status: 'completed',
          _meta: {
            claudeCode: {
              toolResponse: {
                agentId: 'child-1',
                status: 'completed',
                prompt: 'E2E_CHILD_TASK',
                content: [{ type: 'text', text: 'E2E_CHILD_RESULT' }],
              },
            },
          },
        })
      } else if (profile === 'devin') {
        sendUpdate(session.id, {
          sessionUpdate: 'tool_call',
          toolCallId,
          title: 'Inspect fixture',
          kind: 'other',
          status: 'in_progress',
          _meta: {
            'cognition.ai/subagent_started': { agentId: 'child-1', task: 'E2E_CHILD_TASK', title: 'Inspect fixture' },
          },
        })
        sendUpdate(session.id, {
          sessionUpdate: 'tool_call_update',
          toolCallId,
          status: 'completed',
          _meta: {
            'cognition.ai/subagent_completed': { agentId: 'child-1', summary: 'E2E_CHILD_RESULT', success: true },
          },
        })
      } else {
        // These profiles do not supply the identity/task/result evidence needed
        // by the current projector. The product must not invent a child.
        sendUpdate(session.id, {
          sessionUpdate: 'tool_call',
          toolCallId,
          title: 'Delegation without child evidence',
          kind: 'other',
          status: 'completed',
        })
      }
      say('E2E_PARENT_DONE')
    } else {
      const command = 'echo E2E_TOOL_OUTPUT'
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call',
        toolCallId: 'execute-1',
        title: command,
        kind: 'execute',
        status: 'in_progress',
        rawInput: { command, cwd: session.cwd },
      })
      sendUpdate(session.id, {
        sessionUpdate: 'tool_call_update',
        toolCallId: 'execute-1',
        status: 'completed',
        ...(profile === 'codex'
          ? { rawOutput: { formatted_output: 'E2E_TOOL_OUTPUT\n', exit_code: 0 } }
          : {
              content: [{ type: 'content', content: { type: 'text', text: 'E2E_TOOL_OUTPUT\n' } }],
              rawOutput: { exitCode: 0 },
            }),
      })
      say('E2E_')
      await new Promise((resolve) => setTimeout(resolve, 30))
      say(`DONE ${model}`)
    }
    respond(msg.id, { stopReason: 'end_turn' })
  } finally {
    session.turn = null
  }
}
