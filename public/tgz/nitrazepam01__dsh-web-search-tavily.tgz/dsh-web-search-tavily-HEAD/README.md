# dsh-web-search-tavily

A Tavily-backed search provider **bundle** for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) (`dsh`). It registers a Tavily backend for the `ctx.web` web-search seam and ships a **hot-switchable backend selector** (Tavily / DeepSeek search).

## Features

- **Tavily provider** — calls `POST /search` and normalizes results to `{ url, title, snippet, publishedAt }`. Tavily returns content excerpts, so the model can quote snippets directly.
- **Hot backend switcher** — a delegating provider (`search-switch`) sits behind the `web` row and resolves the active backend from the `web-search` settings section on every search. **Saving the section takes effect immediately: no restart, no loader-row reload.**
- Full `WebError` taxonomy (`WEB_PROVIDER_ERROR` / `WEB_PROVIDER_CREDENTIAL_MISSING` / `WEB_ABORTED`).
- Credential resolution chain: literal `apiKey` → `credentials` service → launch environment.
- Settings sections:
  - `web-search-tavily` — `apiKey` / `apiKeyEnv` / `baseURL` / `maxResults`
  - `web-search` — `backend` selection (`tavily` | `deepseek-official`)

## Install

```sh
# From git (recommended — plain JS, no build step, no allowBuilds required)
dsh plugin --profile web add github:nitrazepam01/dsh-web-search-tavily

# From npm
dsh plugin --profile web add dsh-web-search-tavily

# From a local checkout
dsh plugin --profile web add ./dsh-web-search-tavily
```

Restart `dsh web` after installing (bundle layers are frozen at boot). To uninstall: `dsh plugin --profile web remove dsh-web-search-tavily`.

## Configuration

### 1. Credential

Store your Tavily key in `$DSH_HOME/.credentials.yaml`:

```yaml
TAVILY_API_KEY: tvly-your-key
```

### 2. Backend selection

The `web` row's `searchProvider` is set to `search-switch` (the delegating provider) by this bundle. The active backend lives in the `web-search` section of `$DSH_HOME/settings.yaml` and **hot-reloads on save**:

```yaml
web-search:
  backend: tavily            # tavily | deepseek-official
```

- `tavily` — this plugin's Tavily provider (results carry content excerpts)
- `deepseek-official` — delegates to the shipped `web-search-deepseek` provider (DeepSeek Anthropic-compatible Messages endpoint; no excerpts)

### 3. Tavily options (`web-search-tavily` section)

| Field | Default | Description |
|---|---|---|
| `apiKey` | none | Literal key (secret, stored via the credentials domain) |
| `apiKeyEnv` | `TAVILY_API_KEY` | Credential reference name |
| `baseURL` | `https://api.tavily.com` | Tavily REST endpoint |
| `maxResults` | `5` | Max results per search |

## How it works

```
web_search tool → ctx.web (searchProvider: search-switch)
  → switcher delegates by web-search.backend:
      tavily            → this plugin's provider → POST https://api.tavily.com/search
      deepseek-official → shipped provider       → Anthropic Messages + web_search_20250305
```

Why a delegating provider instead of editing the `web` row directly? Changing the `web` row's config **restarts the dsh-web plugin and disposes every registered provider** (Cordis `Fiber.update → restart` semantics). The switcher keeps the selection in the settings layer only, sidestepping that hazard entirely.

## Development

```sh
# Install a local checkout into a profile
dsh plugin --profile web add ./dsh-web-search-tavily

# Inspect the composed config without booting
dsh --profile web --dump-config

dsh web
```

## License

[MIT](LICENSE)
