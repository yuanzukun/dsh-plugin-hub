# dsh-session-delete

DSH（DeepSeek Harness）会话删除插件：官方「归档」只把会话移出侧栏，磁盘日志永久堆积——本插件补上真正的删除，先进回收站可还原。

- **归档会话**：已归档会话行内「还原」解除归档（侧栏原分组立即可见），或一键真删，支持勾选批量
- **全部会话**：按工作区分组，支持搜索、过滤、全选、批量删除，点击整行即可选中；父会话带「子会话 ×N」标记，孤儿会话可一键过滤清理
- **回收站**：按会话名称识别被删条目，多选批量还原（自动解除归档，一步回到侧栏）/ 彻底删除，或一键清空
- **级联删除**（v0.6.0）：删除任一会话时，以其 `parentSession` 链为据连带删除全部子代理子会话（运行中的跳过并提示）；还原主会话时它们一并归位
- 正在运行的会话拒绝删除；删除当前打开的会话时自动切到空白会话

## 安装

`dsh plugin add` 会自动完成依赖链接与 profile 注册，装完重启 `dsh web` 生效。卸载：`dsh plugin --profile web remove dsh-session-delete`。

**方式一：GitHub 直装（推荐）**

```sh
dsh plugin --profile web add github:xohmai/dsh-session-delete
# 锁定版本更安全：github:xohmai/dsh-session-delete#<commit-sha>
```

本插件零构建（纯 JS，无 TypeScript / 无打包步骤），git 安装不会踩「源码拉下来没跑 build」的坑，也无需 pnpm allowBuilds 授权。

**方式二：tarball 离线分发（内网场景）**

```sh
npm pack                                               # 产出 dsh-session-delete-0.6.0.tgz
dsh plugin --profile web add ./dsh-session-delete-0.6.0.tgz
```

## 使用

1. 打开 **设置 → 归档会话**
2. 首次加载为流式拉取：居中过渡动画实时显示「已加载 N / M 个会话」，会话很多时也能看到进度；重新加载（已有数据）则静默刷新，旧列表保持可操作。标题优先走 DSH 投影缓存（与侧栏同源、零解压），几百个会话也是亚秒级；仅缓存未命中的会话批量补一次解压
3. 在侧栏右键归档的会话出现在「归档会话」页签：行内「还原」解除归档（侧栏原分组立即可见），或删除；「全部会话」页签可处理任意会话
4. 删除先入回收站（`~/.dsh/trash/sessions/`），「还原」时文件归位并自动解除归档；确定不要再「彻底删除」
5. **级联删除**（v0.6.0，issue #5）：删除任一会话时，按其 header 的 `parentSession` 链递归连带全部子代理子会话（含子代理再派的子代理）；运行中的子会话跳过并在通知里点名，单个失败不影响其余。随删的子会话在回收站里带「子代理」标记，还原主会话时一并归位；只删单个会话可对 API 传 `cascade: false`。审计日志为每个子会话各写一行 `delete`（带 `cascadeOf`）并附 `delete-cascade` 汇总行，`purge-all` 也记录全部条目 id
6. **历史孤儿清理**：v0.6.0 之前删除主会话遗留的孤儿子会话（父已不在磁盘）在「全部会话」页签带红色「孤儿」标记，工具条出现「孤儿 (N)」过滤按钮——点开、全选、删除即完成清理（插件绝不在启动时自动删任何数据）
7. **删除后不会回到侧栏**：会话的归档 id 在运行期间有意保留（它只是侧栏的隐藏标记；没有行数据的 ghost id 在官方 UI 里不渲染任何东西）。运行期间摘除它会广播归档变更，把已连接客户端列表缓存里的残留行重新显示出来——因此 ghost 统一在重启 DSH 时由启动 reconcile 清理（此刻所有客户端都用全新基线，摘除绝对安全）
8. 回收站还原不受此限制：文件归位 + 自动解除归档，会话立即回到侧栏原分组

**旧版 DSH 回退**：在线解除归档走 workspaceRegistry 内部状态机，插件启动时自动探测能力；不可用时隐藏还原入口，可在 DSH 停止时运行 `node tools/unhide.mjs <sessionId>` 离线找回。旧版同样无法在重启时清理归档 ghost（能力缺失时 reconcile 静默跳过）。

**任意渠道 id（IM 等）**：DSH 核心约定 SessionId 是 unvalidated 字符串（核心落盘前也一律转义），插件同理——id 白名单只做防注入（`/ \ 空白` 等仍拒绝），不假设字符集。含 `:`/`@` 的 IM 渠道 id（如 `im:weixin_...@im.wechat`）可正常删除/还原；回收站条目名用与核心 `encodeSegment` 相同的 `~XXXX` 转义（Windows 保留字符安全），还原/清空的会话 id 始终取自条目内 `meta.json`，绝不反解条目名。

**兼容性**：同时支持新版（0.1.5+，`sessionPersistence.list()` 返回 `{header, revision, sizeBytes}` 快照）与旧版（≤0.1.1-rc.x，直接返回 header 数组）两代持久化接口——v0.4.0 在 DSH 0.1.5 上 `/list`、`/trash` 全部 500（"reading 'length'"）的问题已在 v0.4.1 修复。

## 开发

```sh
npm test   # node test/smoke.mjs && node test/render.mjs
```

## License

Apache-2.0
