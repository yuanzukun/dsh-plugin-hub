# 🌸百合资讯 · Lily News

> ###  它解决了菲尔兹奖得主提出的世纪难题
> *「有哪些优秀的百合同人作品？」—— 邓煜（2026菲尔兹奖得主）*
>
>  输入任意番名，AI 并行检索动画 / 漫画 / 实体书 / 动态 / 同人，
> AI 一键提炼**黑体**头条，词条首图 + 🔥 聚焦热链，玻璃拟态资讯页。同时注册 koin_research 模型工具，会话里的 AI 也能一键调用同款检索管线。
>
> **当前版本：v3.0.0**
>
> 相较v2.2.2(上一版本)：重构了代码，使得koin_lily_news现在是独立的dsh插件

## 实机安装效果展示

<img width="1783" height="1380" alt="Screenshot_20260826172729" src="https://github.com/user-attachments/assets/b207bbbf-8ef8-4488-803a-d249cdabed42" />

<img width="1783" height="1118" alt="Screenshot_20260821204036" src="https://github.com/user-attachments/assets/7634c574-027b-464f-b33c-4447f78b70d7" />

---

##  为什么值得一试？

| 卖点 | 一句话安利 |
| --- | --- |
| 🏆 **菲奖级眼光** | 连菲尔兹奖得主都在用的百合资讯面板（邓煜认证：百合同好狂喜） |
| 🔎 **任意番名秒搜** | 输入作品名，AI 自动脑补中/日/英全部别名并**并行开搜** |
| 🤖 **AI 头条提炼** | 每个板块顶部 AI 精炼黑体头条：「全13话（更新中）」「单行本第8卷发售中」，一行时自动放大 |
| 🖼️ **词条首图** | 1:1 圆角缩略图异步加载，加载成功稳定保留，绝不闪退 |
| 🔥 **聚焦热链** | 自动锁定**热度最高且有图**的链接作大卡片，配图直接当全页玻璃背景 |
| 🕶️ **玻璃拟态 UI** | 半透明水玻璃卡片 + backdrop-blur，聚焦美图若隐若现，明暗主题自适应 |
| 🔵 **蓝V 认证标识** | 「动态」栏命中作者/制作组/官方账号的词条自动加 🔵V |
| ⏱️ **加载环 + 实时网速** | 搜索框内转圈圈 + KB/s / MB/s 实时网速，等待也有仪式感 |
| 💾 **结果缓存** | 打开页面不重复搜索，点「↻ 强制刷新」才重新联网 |
| 🛠️ **AI 可用工具** | 注册 `koin_research` 工具，对话里的 AI 也能一键调用同款检索管线 |

## 📺 五类资讯，一页看全

| 栏目 | 内容 |
| --- | --- |
| 📺 动画进度 | TV 动画更新到第几集 |
| 📖 漫画更新 | 网页版连载更新到第几话 |
| 📚 实体书 | 单行本出版到第几卷 |
| 📣 动态 | 作者 / 制作组 / 官方近一周动态 |
| 🎨 同人创作 | 近一周同人文 / 图 / 漫 |

##  技术架构


- 平台：DeepSeek Harness（DSH）Web —— 正式插件（非动态插件）
- Host 半段：`koinNews` Remote 服务（`koinNews/load` `search` `progress` `images`）+ `koin_research` 工具
- Client 半段：`conversation.view`「百合资讯」标签页
- 依赖能力：`web`（搜索）、`llm` + `agentDefaultModel`（AI 提炼）、`slots`/`timer`/`connection`（页面）。均为 DSH 标准组件，开箱即用；`shell` 缺席时自动降级为仅 `web.fetch` 抓图。

## 安装

### 方式一：`dsh plugin`（推荐，自动注册 bundle 层）

```bash
# GitHub 安装（仓库内 package.json 位于仓库根目录）
dsh plugin --profile web add github:<你的用户名>/dsh-koin-lily-news

# 或 npm 安装（发布到 npm 后）
dsh plugin --profile web add dsh-koin-lily-news
```

安装完成后 **重启 DeepSeek Harness**（组合在启动时加载）。

### 方式二：手动安装（不依赖 pnpm）

1. 把本目录复制（或 junction 链接）到 profile 的 node_modules：
   - Windows：`C:\Users\<你>\.dsh\profiles\web\node_modules\dsh-koin-lily-news`
   - Linux/macOS：`~/.dsh/profiles/web/node_modules/dsh-koin-lily-news`
2. 在 `C:\Users\<你>\.dsh\profiles\web\cordis.patch.yml` 追加：

   ```yaml
   - insert:
       - id: dsh-koin-lily-news
         name: 'dsh-koin-lily-news'
   ```

3. 重启 DeepSeek Harness。

> 说明：profile 安装的插件通过 `$DSH_HOME/profiles/node_modules` 的自动愈合链接
> 解析 `@deepseek-ai/*` 运行时依赖（与官方插件一致），无需自行安装这些包。

## 使用

- 会话标题栏点击 **「百合资讯」** 标签；输入番名回车即搜；「↻ 强制刷新」重新联网。
- 对话中直接说“查一下 XX 的最新进度”，AI 会调用 `koin_research` 工具。

## 开发

- `lib/index.js`（Host，ESM）：`KoinNewsService extends TypertRemoteService`，
  `@Remote` 端点经 Typert Gateway 的 SRC 标记发现（无需生成 typert manifest；
  该实现以 `Remote()` 普通调用等价装饰器语义，兼容无装饰器语法的 Node 构建）。
- `lib/client.js`（Browser）：`window.__ModuleLoader__.load({ id, factory })`
  单文件 bundle（DSH 浏览器模块内核格式），`require` 解析 `react` 与运行时服务。
- 改完直接替换 `lib/` 下文件即可生效（重启后），无构建步骤。

## 许可

GPL-3.0（见 `LICENSE`）。数据来自公开网络搜索，AI 头条仅供参考，请以官方渠道为准。

## 📌 使用提示

- 💾 **缓存**：打开页面展示上次结果（顶部琥珀色提示），不自动重搜；
- ↻ **刷新**：「↻ 强制刷新」强制重新联网检索；
- 🔎 **换番**：输入新番名回车即搜，AI 自动生成该作品别名查询计划；
- ⚠️ **数据说明**：内容来自公开网络搜索，AI 头条仅供参考，请以官方渠道为准。

## 🐛 已知限制

- 部分站点反爬（manhuagui、plex 等）抓图失败，词条保持纯文字；
- 部分搜索源混入同名词条（如「死了都要爱」歌曲），AI 头条会尽量甄别；
- 动态插件随进程重启消失，需重新 define/run（或方式三转正式插件持久化）。

---

## 开发者的碎碎念

> 每一次迭代都有你的反馈参与——感谢陪伴，继续一起为爱发电！⚡

---
*百合资讯 v3.0.0 · x1shang · 由 DSH 动态 Cordis 插件技术构建* 
