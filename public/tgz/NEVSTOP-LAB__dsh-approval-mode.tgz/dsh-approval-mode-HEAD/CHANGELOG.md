# 变更记录

本文件记录每个发布版本的用户可见变更。发布工作流
（[`.github/workflows/release.yml`](./.github/workflows/release.yml)）会调用
`scripts/release-notes.mjs`，把与 tag 对应的 `## [<版本>]` 小节抄进 GitHub Release
正文——所以**发版前先在这里写一节**，否则 Release 只会退化成提交列表。

更早的版本（`0.1.0` – `0.1.1-rc.3`）没有条目：当时 Release 正文只有安装说明，
历史内容见 [Releases](https://github.com/NEVSTOP-LAB/dsh-approval-mode/releases)。

## [Unreleased]

## [0.2.1] - 2026-11-13

### 修复

- **手机布局下审批模式按钮仍显示文字，与相邻的权限控件不一致。** 权限选择器在 composer 行窄于
  460px 时用容器查询隐藏文字标签、只留图标与箭头；本插件没有同一条规则，于是文字一直显示，
  按钮比旁边宽。改为采用同一断点与 `:has()` 条件，只影响显示，读写与会话寻址不变。

## [0.2.0] - 2026-09-29

### 修复

- **DSH 0.2.0-rc.1 上插件被判为不兼容，插件行不激活。** 现象：DSH Desktop 2.0.16 升级后，
  插件页卡片报「dsh-approval-mode@0.1.5 与 DSH 0.2.0-rc.1 不兼容（要求
  `@deepseek-ai/dsh-llm ^0.1.1-rc.2`），运行它可能导致崩溃或数据丢失」；`Config.listConfigs`
  把插件行报成 `inactive`，界面上的审批模式按钮消失。

  - **原因**：宿主在组合期用 `evaluatePluginCompatibility` 检查 manifest 里所有
    `@deepseek-ai/dsh` / `@deepseek-ai/dsh-*` 的 peer 范围，不满足就把插件行 `disabled`。
    0.2.0 起 `@deepseek-ai/dsh-llm` 与核心同线跳到 `0.2.0-rc.1`，`^0.1.1-rc.2` 落在它下面。
    同一版本还有一处真实契约变化：`ApprovalRequestEvent.agent` 收窄为 `{ id }`（会话 id），
    不再有 `agent.session`——按会话解析审批模式的代码会读不到地址。
  - **修复**：不再声明、也不再 import 任何带版本号的 `@deepseek-ai/dsh-*` 包。通知消息改在
    插件内构造（`node:crypto` 的 `randomUUID` + 本地 `deepFreeze`），与宿主
    `createUserMessage` 同形（新标识、深冻结的 user 消息、producer 自有的 source kind）。
    会话地址改由 `sessionIdOf` 解析，同时接受 0.2.0 的 `agent.id` 与更早的 `agent.session.id`。
    `engines.dsh` 从 `^0.1.1-rc.2` 改为无上界的 `>=0.1.1-rc.2`。
  - **影响面**：只影响插件能否挂载；按会话模式文件（`$DSH_HOME/approval-mode/sessions.json`）
    与默认模式（插件 `Config.defaultMode`）的存取格式都没变，升级后不需要重设。

### 新增

- **插件图标**：`icon.svg`（盾牌 + 闪电）通过 manifest 的 `icon` 声明，插件页与插件市场的
  卡片、插件详情页都会显示；`locale/en.json`、`locale/zh.json` 提供双语显示名与描述
  （此前卡片上的标题退回包名 `dsh-approval-mode`）。

### 文档

- README（中/英）：版本说明补上 `0.2.0-rc.1`（DSH Desktop 2.0.16）的验证记录与
  「不再声明 `@deepseek-ai/dsh-*` peer」这一事实；tarball 示例文件名同步到 0.2.0。
- `CONTRIBUTING.md`：§3.1 的声明表删掉 `@deepseek-ai/dsh-llm`、`engines.dsh` 改为
  `>=0.1.1-rc.2`，并说明「peer 只留真的被 import 的包」；§3.2 补 0.2.0 的教训；
  §3.5 补 0.2.0 也没有 `settingsScope` / `settings.plugin.item`；§2 与 §4 补图标/元数据、
  Agent 双形状、消息构造的检查项与反向验证；§4.1 新增 0.2.0-rc.1 的校验记录。
- `doc/design.md`：依赖与兼容章节同步；新增 0.2.0 的验证记录。

### 版本

- 本次把第二位从 `0.1` 提到 `0.2`（跳过 `0.1.6`）：插件的宿主声明面发生了代际变化——开始支持
  DSH `0.2.0-rc.1` 线，并去掉了唯一一条随 DSH 版本线漂移的 peer。规则与依据见
  [CONTRIBUTING.md §3.4](./CONTRIBUTING.md#34-版本号与发布的关系)；它仍然不是与 DSH 版本对齐，
  兼容范围由 `engines.dsh`（`>=0.1.1-rc.2`）表达。

### 验证

- `npm run check`：语法检查 + `scripts/check-client.mjs` + `scripts/check-host.mjs` 全绿。
  `check-host.mjs` 新增两条硬约束——**任何 `@deepseek-ai/dsh-*` 说明符在加载期直接报错**
  （重新引入这类 import 会在离线检查里失败），以及 Agent 双形状、消息构造（新标识/深冻结/
  v4 source 准入）的断言。
- 反向验证：把 `import "@deepseek-ai/dsh-llm"` 加回 `index.js` ⇒ 加载期报错；
  把 `sessionIdOf` 改回只读 `agent.session.id` ⇒ 8 条 `FAIL`（实测）。
- 用宿主自己的判定函数离线复核新 manifest：`evaluatePluginCompatibility` 返回
  `undefined`、dsh-market 的 `deriveHostCompatibility` 为 `compatible`、
  `readPluginMeta` 解析出 `data:image/svg+xml;base64` 的图标与中英标题；同一脚本对
  profile 里已装的 0.1.5 复现出插件页那条不兼容（记录见 CONTRIBUTING §4.1）。
- 未完成：DSH Desktop 2.0.16 界面上没有热装载本版（替换已安装包需要重启 Desktop），
  因此宿主渲染的默认模式表单与按钮外观只做了接口层核对。

## [0.1.5] - 2026-09-25

### 修复

- **0.1.4 会让会话写入失败：每一轮都报 `format v4 message requires a producer-owned source kind`。**
  现象：切换审批模式之后，该会话之后每一轮都失败（宿主日志
  `[jsonl-session-persistence] background write … failed`、
  `[dsh-agent-error] agent turn failed … SessionFormatError: format v4 message requires a
  producer-owned source kind`），标题生成、投影缓存写入一并失败。

  - **原因**：通知在线代理的那条注入消息沿用了 v3 的 source 包装
    `{ kind: "plugin", plugin: "approval-mode" }`。0.1.7 的会话格式 v4 只接受 **producer 自有**的
    source kind，并明确拒绝 `plugin`（`@deepseek-ai/dsh-session-format-v3-to-v4` 的
    `assertV4RowAdmission`）。0.1.4 之前插件在 0.1.7 上根本不挂载，这条注入路径从未被执行到；
    0.1.4 修好挂载后它才第一次运行。
  - **修复**：source 改为插件自己的 producer kind `{ kind: "dsh-approval-mode" }` —— 与第一方
    producer（`cordis-host-runner`、`dsh-session-title-llm`）同一约定，也正是宿主自己的 v3→v4
    迁移会把 legacy plugin source 变成的形态。
  - **影响面与恢复**：只在**切换审批模式**（通知在线代理）时触发；坏事件被会话写入拒绝，
    没有落到磁盘（v4 会话文件与投影缓存均无 `"kind":"plugin"`），重启 DSH 即恢复。

- **0.1.4 已撤回**：GitHub Release 与 tag `v0.1.4` 均已删除（它把上述回归带进了正式发布）。
  请使用 0.1.5。

### 验证

- `scripts/check-host.mjs` 新增两条断言：「注入的消息通过 session-format v4 的 source 准入」
  「通知携带插件自己的 producer kind」；把 source 改回 `{kind:"plugin"}` ⇒ 2 条 FAIL（实测）。
- 用真实宿主代码复核：以 `@deepseek-ai/dsh-session-format-v3-to-v4@0.1.7-rc.1` 的
  `assertV4RowAdmission` 对**插件自己的常量**取值——旧包装被拒（错误文本与线上一致），
  新常量通过。

## [0.1.4] - 2026-09-25

### 修复

- **DSH 0.1.7 起插件不挂载，按钮显示「审批模式未知」。** DSH 0.1.7 把 settings 服务从
  「插件注册命名空间 + settings 文档」换成了「插件 Config + profile patch 配置表单」：
  `ctx.settings.register` 已不存在。旧版 `index.js` 在 `apply` 第一行就抛
  `TypeError: ctx.settings.register is not a function`，宿主半根本没挂载 ⇒
  `/approval-mode` 控制路由不存在 ⇒ 浏览器读设置失败（落到 SPA fallback）⇒
  store 置 `known=false` ⇒ 工具栏按钮与插件页卡片都显示「审批模式未知」。修复后的分工：

  - **默认模式 = 本插件自己的配置字段** `Config.defaultMode`（`.volatile()`）。
    0.1.7+ 由宿主按 Config schema 在「设置 → 插件」自动渲染表单读写，改值只更新引用、
    不重挂插件；0.1.6 及更早的宿主没有这套投影，仍走原来的 `approval-mode`
    settings 命名空间（该服务存在时注册并读写）。
  - **按会话模式改存插件自有文件** `$DSH_HOME/approval-mode/sessions.json`（原子写入：
    临时文件 + rename）。0.1.7+ 的 settings 服务只能编辑插件 Config，按会话的运行期状态
    不该进 profile patch；该文件首次加载时会把旧 settings 文档里的 `sessions` 映射
    迁移过来，之后不再读它。
  - **`inject` 不再要求 settings 服务**：只要求 `webServer`。settings 通过
    `ctx.inject` 可选接入，因此两代 settings 服务、以及完全没有 settings 服务的组合
    都能挂载（应答器 + 控制路由 + 会话存储照常）。

- **升级提示**：0.1.7 已弃用旧的 settings 文档通道（`settings.yaml` 被改名成
  `settings.yaml.imported`），升级前写在 `approval-mode` 命名空间里的**默认模式**
  在 0.1.7+ 无法再读取——请在「设置 → 插件 → dsh-approval-mode」重新选一次默认模式。
  按会话的模式由插件自动迁移，无需手动处理。

### 变更

- **`@deepseek-ai/dsh-settings` 不再作为 peer 声明**：插件不再 import 该包（只使用宿主
  注入的 settings 服务，且两代服务都兼容）。peer 范围只剩 `@deepseek-ai/cordis`、
  `@deepseek-ai/dsh-llm`、`@deepseek-ai/schemastery`、`react`。

### 验证

- `npm run check`：`scripts/check-host.mjs` 重写并覆盖两代 settings 服务——新增断言含
  「没有 `register` 的 settings 服务能挂载（本次回归）」「live config 引用决定默认值」
  「默认写入按插件自己的 loader entry id 走 settings 服务」「会话映射跨重启存活」
  「坏文件退化为空、写入时修复」「旧文档的 sessions 一次性迁移」「宿主侧 volatile 变更只通知一次」。
  逐条反向验证：把 `inject` 与 `ctx.settings.register` 恢复成旧写法，该脚本报 4 条
  `FAIL`（含「能挂载而不抛异常」），确认后改回。
- 真实宿主实测（DSH Desktop 2.0.14 / DSH 0.1.7-rc.1）见 CONTRIBUTING §4.1。

## [0.1.3] - 2026-09-22

### 新增

- **第三个审批模式「绕过审批（提权除外）」**：工具调用照常自动放行，但工作区外写文件、
  执行需要更宽沙箱的命令所需的**提权仍会弹窗**，由你决定是否放行这一次。此前只有两种
  模式，其中「绕过审批」连提权一起自动批准；现在两档都在，按任务选择。（#9）

### 变更

- **默认审批模式与当前会话的审批模式拆成两个值**：插件页配置卡片只写「打开会话时使用的
  默认模式」，工具栏的「审批模式」按钮只改**当前会话**，两者不再互相改写；会话模式按
  会话持久保存，重启后保持。（#11）
- **升级兼容**：0.1.2 及更早版本写入的全局 `mode` 升级后仍然决定默认值，无需手动重设。
- **宿主共享包标记为 optional peer**：`pnpm peers check` 不再报那五条 `missing peer`
  （这些包由 DSH 共享层提供，在 profile 里必然「缺失」）；宿主版本下界改由 `engines.dsh`
  显式声明，dsh-market 浏览期的「低于声明下界」判定因此不受影响。（#10）

### 文档

- README（中/英）：新增第三个模式的说明与「提权仍会弹窗」的风险提示；配置章节改为两个值、
  两个入口，并说明改默认值对没有自己模式的会话（含正在运行的）立即生效。
- `doc/design.md`：新增三个模式的对照表与提权识别判据（§3.1.1）、按会话的状态模型（§3.3）、
  控制路由契约（§3.3.1），同步插件页卡片、打包与依赖声明说明。
- `CONTRIBUTING.md`：`engines.dsh` 与 optional peer 的判定依据、唯一被削弱的信号与实测方法；
  新增 `scripts/check-host.mjs` 的存在理由与反向验证清单；版本号规则改为陈述实际做法。

### 验证

- `npm run check`：语法检查 + `scripts/check-client.mjs` + 新增的
  `scripts/check-host.mjs`（Host 半离线契约检查：用 `module.registerHooks` 给
  `@deepseek-ai/*` 打桩后加载真实的 `index.js`，覆盖三模式应答、按会话解析、
  遗留值迁移与控制路由地址语义）。每条新断言都做过反向验证（退回修复 ⇒ 对应用例失败）。
- 实测（pnpm 11.8、`autoInstallPeers: false`）：旧清单复现 issue #10 的五条
  `missing peer`，新清单输出 `No peer dependency issues found`。
- 修复了 Copilot 在 #12 上提出的 5 条问题（默认值对继承会话的生效范围、两处「绕动」错别字、
  §1 目标句未限定提权），5 个 review thread 已 resolve。

## [0.1.2] - 2026-09-17

### 新增

- **插件页配置卡片**：`设置 → 插件 → 插件配置` 中新增本插件的卡片，可设置打开会话时使用的
  审批模式（默认审批 / 绕过审批）。它与输入框工具栏的「审批模式」按钮写的是同一个全局设置，
  两个界面实时同步；切换后仍会通知在线代理。

### 变更

- **审批模式状态机**：读取失败时两个界面显示「审批模式未知」（工具栏置灰、卡片不选中任何
  选项），不再把 schema 默认值当作当前设置；写入失败回滚到 Host 最后确认过的值，而不是上一次
  乐观值；并发的选择、被取代的读取与乱序返回的响应都不会让界面显示 Host 从未接受过的模式。
- **版本要求**：`@deepseek-ai/dsh-settings` 对齐到 `^0.1.1-rc.2`，与 `@deepseek-ai/dsh-llm`
  同属一条 DSH 版本线；DSH 共享宿主包仍然只声明在 `peerDependencies`。声明的下界是
  `0.1.1-rc.2`，无上界。
- **发布包内容**：`CONTRIBUTING.md`、`doc/` 与 `CHANGELOG.md` 进入 tarball，
  README 中的相对链接对 tarball 用户同样有效（此前指向的文档根本不在包里）。

### 文档

- README（中/英）：版本说明只陈述用户需要行动的事实——需要 DSH `0.1.1-rc.2` 及以上、
  实测 `0.1.5-rc.2`。
- 新增 `CONTRIBUTING.md`：本地检查、版本要求的逐条依据、兼容性校验方法与记录、打包发版清单、
  开发坑。
- `doc/design.md`：补齐插件页卡片的派发机制（settings 命名空间 ∩ slot key）与状态机的三条
  不变式（`known` / `confirmed` / `generation`）。

### 验证

- `npm run check`：5 个文件的 `node --check` + 离线 client bundle 契约检查（26 条断言）全绿；
  每条新断言都做过反向验证（退回修复 ⇒ 对应用例失败）。
- 兼容性：按 API 逐项对照 DSH `0.1.5-rc.2`（`settings`、`webServer`、`approval/request`
  水瀑布、`createUserMessage`、slot `locale`、`settings.plugin.item` + `settingsScope`），
  记录见 CONTRIBUTING §4.1。
- 修复了 Copilot 在 #8 上提出的 4 类问题（未知态、回滚目标、被取代的读取、发布包死链），
  相关 3 个 review thread 已 resolve。
