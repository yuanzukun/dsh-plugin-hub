/** Browser half: a session-bound Git Graph page in the native right sidebar. */
import type { Context } from '@deepseek-ai/cordis';
export declare const inject: string[];
export declare function apply(ctx: Context): void;
