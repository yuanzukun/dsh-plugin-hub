/** A ref label attached to a commit in the Git graph. */
export interface GitGraphRef {
  readonly kind: 'head' | 'remote' | 'tag'
  readonly name: string
}

/**
 * One commit row required by the graph and the commit summary list.
 * Phase 0 extends the graph row with the data vscode-git-graph loads lazily
 * for the details view; the coarse graph list keeps the original fields.
 */
export interface GitGraphCommit {
  readonly hash: string
  readonly parents: string[]
  readonly author: string
  readonly email: string
  /** ISO-8601 author timestamp. */
  readonly date: string
  /** ISO-8601 committer timestamp, independent of author date. */
  readonly committerDate: string
  /** Commit subject (first line). */
  readonly subject: string
  readonly refs: GitGraphRef[]
  readonly isHead: boolean
}

/**
 * Repository availability state. These three states must be distinguishable so
 * a caller can tell "this directory is not a Git repository" apart from "this
 * is a Git repository with no commits yet" apart from "history is readable".
 * Git failures, cancellation and size overflows are reported through the
 * transport error result, never collapsed into `empty`.
 */
export type GitGraphRepoState = 'not-git' | 'empty' | 'ready'

/**
 * One local or remote-tracking branch with its tip commit. This is what makes
 * read-only branch navigation possible: the Client can jump to a tip and ask
 * for exactly that branch without ever running a write command.
 */
export interface GitGraphBranch {
  /** Short name: `main` locally, `origin/main` for a remote-tracking branch. */
  readonly name: string
  /** Commit the branch points at. */
  readonly hash: string
  readonly kind: 'local' | 'remote'
  /** True for the checked-out local branch. */
  readonly isCurrent: boolean
}

/** The bounded, replayable result sent from the Host tool to the Client view. */
export interface GitGraphSnapshot {
  /** Git worktree root; session cwd remains a request context, not repository identity. */
  readonly path: string
  /** `not-git` | `empty` | `ready`. */
  readonly state: GitGraphRepoState
  readonly branch: string | null
  readonly head: string | null
  /** Actual configured remote names; names may contain slashes. */
  readonly remotes: string[]
  /**
   * Local branches followed by remote-tracking branches; symbolic refs excluded.
   * Always populated by the Host, including empty and non-Git snapshots.
   */
  readonly branches: GitGraphBranch[]
  readonly workingTree: {
    readonly changed: boolean
    readonly summary: string
  }
  readonly commits: GitGraphCommit[]
  /** True when more commits exist beyond the requested page (Host uses maxCommits+1). */
  readonly hasMore: boolean
  /** Search reached its scan limit; a missing match is not proof of absence. */
  readonly searchTruncated: boolean
}

/** How the Host orders the returned commit stream. */
export type GitGraphSort = 'date' | 'author-date' | 'topological'

/** The accepted tool input after schema validation and local bounds checks. */
export interface GitGraphInput {
  readonly path?: string
  readonly maxCommits?: number
  readonly all?: boolean
  readonly firstParent?: boolean
  /** Branch-name glob filters (OR). Normalized by the Host. */
  readonly glob?: string[]
  /**
   * Exact short branch names to restrict history to (OR). Unlike `glob` this is
   * an equality match, so focusing `main` never drags in `main-old`.
   */
  readonly branches?: string[]
  /** Free-text search applied to hash, subject, author, email, ref name and date. */
  readonly search?: string
  readonly sort?: GitGraphSort
}

/** Browser queries read the current session workspace; only the model tool accepts a path. */
export type GitGraphQuery = Omit<GitGraphInput, 'path'>

/* ------------------------------------------------------------------ *
 * Phase 0 read-only data pipeline types.
 * ------------------------------------------------------------------ */

/** GPG signature status of a commit or annotated tag (matches %G? codes). */
export type GitGraphSignatureStatus =
  | 'G'  // good (valid)
  | 'U'  // good, unknown validity
  | 'X'  // good, but expired
  | 'Y'  // good, but made by expired key
  | 'R'  // good, but made by revoked key
  | 'E'  // cannot be checked
  | 'B'  // bad

/** GPG signature detail for a commit or annotated tag. */
export interface GitGraphSignature {
  readonly status: GitGraphSignatureStatus
  /** Key id (for commits, %GK; for tags, the verify-tag key). */
  readonly key: string | null
  /** Signer name for commits (%GS). */
  readonly signer: string | null
}

/** Timestamps distinguish author and committer (vscode-git-graph does too). */
export interface GitGraphTimestamps {
  /** ISO-8601 author date (defaults to the row date). */
  readonly authorDate: string
  /** ISO-8601 committer date. */
  readonly committerDate: string
}

/** A single changed file within a commit or comparison. */
export interface GitGraphFileChange {
  readonly type: 'A' | 'M' | 'D' | 'R' | 'T' | 'U'
  readonly oldPath: string
  readonly newPath: string
  /** Number of lines added, when known (text file). */
  readonly additions: number | null
  /** Number of lines deleted, when known (text file). */
  readonly deletions: number | null
}

/** Full detail for one commit, loaded on demand for the details view. */
export interface GitGraphCommitDetails {
  readonly hash: string
  readonly parents: string[]
  readonly author: string
  readonly authorEmail: string
  readonly committer: string
  readonly committerEmail: string
  readonly timestamps: GitGraphTimestamps
  readonly signature: GitGraphSignature | null
  /** Full commit message body (multi-line). */
  readonly body: string
  readonly fileChanges: GitGraphFileChange[]
}

/** An annotated or lightweight tag. */
export interface GitGraphTag {
  readonly name: string
  readonly annotated: boolean
  /** Populated only for annotated tags. */
  readonly detail: GitGraphTagDetails | null
}

/** Detail of an annotated tag (object + tagger + message + signature). */
export interface GitGraphTagDetails {
  /** Hash the tag points to (the object). */
  readonly objectHash: string
  readonly tagger: string
  readonly taggerEmail: string
  /** ISO-8601 tagger timestamp. */
  readonly taggerDate: string
  readonly message: string
  readonly signature: GitGraphSignature | null
}

/** A stash that is mapped onto the graph at a commit. */
export interface GitGraphStash {
  readonly selector: string
  readonly hash: string
  readonly baseHash: string
  /** Present when the stash has an untracked-files commit (3 parents). */
  readonly untrackedFilesHash: string | null
  readonly author: string
  readonly email: string
  readonly date: string
  readonly message: string
}

/** Read-only repository and user configuration (vscode-git-graph config surface). */
export interface GitGraphRepoConfig {
  /** Per-branch upstream/pushremote (from local config). */
  readonly branches: Record<string, { readonly remote: string | null; readonly pushRemote: string | null }>
  readonly diffTool: string | null
  readonly guiDiffTool: string | null
  readonly pushDefault: string | null
  /** Remote name -> url / pushUrl from local config. */
  readonly remotes: Array<{ readonly name: string; readonly url: string | null; readonly pushUrl: string | null }>
  readonly user: {
    readonly name: { readonly local: string | null; readonly global: string | null }
    readonly email: { readonly local: string | null; readonly global: string | null }
  }
}

/** Inventory of working-tree changes (deleted + untracked + modified counts). */
export interface GitGraphWorkingTree {
  readonly changed: boolean
  readonly deleted: string[]
  readonly untracked: string[]
  readonly modified: string[]
}

/** Upper bound for persisted graph metadata in one tool result. */
export const MAX_COMMITS = 500
/** Search resource budget, independent of the number of matches displayed. */
export const MAX_SEARCH_COMMITS = MAX_COMMITS * 4
/** Upper bound on exact branch names accepted in one query. */
export const MAX_BRANCH_FILTER = 64

/* ------------------------------------------------------------------ *
 * On-demand detail protocol DTOs (readCommit / readFile / compare).
 * These are loaded per request and never embedded in the graph snapshot.
 * ------------------------------------------------------------------ */

/** Request body for `gitGraph/readCommit`. */
export interface GitGraphCommitRequest {
  readonly hash: string
}

/** Content read from one version of a file. */
export interface GitGraphFileContent {
  readonly hash: string
  readonly path: string
  /** `text` when the bytes decoded cleanly, `binary` otherwise. */
  readonly kind: 'text' | 'binary'
  /** Decoded content; `null` for binary files. */
  readonly text: string | null
  /** Byte size of the raw blob. */
  readonly size: number
  /** True when the blob exceeded the configured per-file size cap. */
  readonly truncated: boolean
}

/** Request body for `gitGraph/readFile`. */
export interface GitGraphFileRequest {
  readonly hash: string
  readonly path: string
}

/** One rendered line inside a file diff hunk. */
export interface GitGraphDiffLine {
  readonly type: 'context' | 'added' | 'removed'
  /** Line content without the leading +/-/space marker. */
  readonly content: string
  /** Line number in the base version (null for pure-added lines). */
  readonly oldLine: number | null
  /** Line number in the new version (null for pure-removed lines). */
  readonly newLine: number | null
}

/**
 * Per-file change between a base and target commit. A request without an
 * explicit base compares the target with its first parent (empty tree for a
 * root commit), matching `loadCommitDetails`.
 */
export interface GitGraphFileDiff {
  readonly hash: string
  readonly path: string
  readonly oldPath: string
  readonly status: GitGraphFileChange['type']
  /** True when Git reports binary content rather than a textual patch. */
  readonly binary: boolean
  readonly additions: number
  readonly deletions: number
  /** A context line where the file is entirely added/deleted has no head. */
  readonly lines: GitGraphDiffLine[]
}

/** Request body for `gitGraph/readFileDiff`. */
export interface GitGraphFileDiffRequest {
  readonly hash: string
  readonly path: string
  /** Explicit comparison base; omitted for the target commit's own changes. */
  readonly baseHash?: string
}

/** The list of files changed in the working tree relative to HEAD (or empty tree). */
export interface GitGraphWorkingTreeChanges {
  readonly changes: GitGraphFileChange[]
}

/** Request body for `gitGraph/readWorkingTree` (the working directory is implicit). */
export type GitGraphWorkingTreeRequest = Record<string, never>

/** Request body for `gitGraph/readWorkingTreeFile`: diff one file vs the working tree. */
export interface GitGraphWorkingTreeFileRequest {
  readonly path: string
}

/** File-change comparison between two commits (left → right). */
export interface GitGraphCompareResult {
  readonly baseHash: string
  readonly targetHash: string
  readonly changes: GitGraphFileChange[]
}

/** Request body for `gitGraph/compare`. */
export interface GitGraphCompareRequest {
  readonly baseHash: string
  readonly targetHash: string
}

/** Repository-level read-only metadata requested on demand (not per commit). */
export interface GitGraphMetadata {
  readonly tags: GitGraphTag[]
  readonly stashes: GitGraphStash[]
}

/** Empty request for repository-level metadata in the current session. */
export type GitGraphMetadataRequest = Record<string, never>

/** Avatar reads are bound to actual commit authors in the current workspace. */
export const MAX_AVATAR_BATCH = 24
export interface GitGraphAvatarRequest {
  readonly hashes: string[]
  readonly source: 'auto' | 'gravatar'
}
export interface GitGraphAvatar {
  readonly email: string
  /** Only bounded raster data URLs are sent; null keeps the local initials. */
  readonly image: string | null
  /** `host` is the repository's own Git service (Gitea/Gogs avatar endpoint). */
  readonly provider: 'github' | 'gravatar' | 'host' | null
}
export interface GitGraphAvatarResult {
  readonly avatars: GitGraphAvatar[]
}
