/** Host half of the DSH Git Graph plugin. */
import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-system-prompt'
import type { GitGraphInput } from './domain.ts'
import { MAX_COMMITS } from './domain.ts'
import { loadGitGraph } from './git.ts'
import { GitGraphRemoteService } from './remote-service.ts'

export const GRAPH_OUTPUT_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    path: { type: 'string', required: true },
    state: { type: 'string', required: true, enum: ['not-git', 'empty', 'ready'] },
    branch: { oneOf: [{ type: 'string' }, { type: 'null' }], required: true },
    head: { oneOf: [{ type: 'string' }, { type: 'null' }], required: true },
    remotes: { type: 'array', required: true, items: { type: 'string' } },
    // Every snapshot lists branch tips; the tool output accepts the same field
    // the Host sends instead of dropping the read as an invalid result.
    branches: {
      type: 'array',
      required: true,
      items: {
        type: 'object',
        additionalProperties: false,
        properties: {
          name: { type: 'string', required: true },
          hash: { type: 'string', required: true },
          kind: { type: 'string', required: true, enum: ['local', 'remote'] },
          isCurrent: { type: 'boolean', required: true },
        },
      },
    },
    workingTree: {
      type: 'object',
      additionalProperties: false,
      required: true,
      properties: {
        changed: { type: 'boolean', required: true },
        summary: { type: 'string', required: true },
      },
    },
    commits: {
      type: 'array',
      required: true,
      items: {
        type: 'object',
        additionalProperties: false,
        properties: {
          hash: { type: 'string', required: true },
          parents: { type: 'array', required: true, items: { type: 'string' } },
          author: { type: 'string', required: true },
          email: { type: 'string', required: true },
          date: { type: 'string', required: true },
          committerDate: { type: 'string', required: true },
          subject: { type: 'string', required: true },
          refs: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                kind: { type: 'string', required: true, enum: ['head', 'remote', 'tag'] },
                name: { type: 'string', required: true },
              },
            },
          },
          isHead: { type: 'boolean', required: true },
        },
      },
    },
    hasMore: { type: 'boolean', required: true },
    searchTruncated: { type: 'boolean', required: true },
  },
} as const

function summaryText(value: { path: string; state: string; branch: string | null; head: string | null; workingTree: { summary: string }; commits: readonly { hash: string; subject: string; refs: readonly { name: string }[] }[] }): string {
  const branch = value.branch === null ? 'detached/unknown' : value.branch
  const head = value.head === null ? 'no commits' : value.head.slice(0, 12)
  const lines = [`Git graph: ${value.path}`, `state=${value.state}, branch=${branch}, head=${head}, ${value.workingTree.summary}`, `commits=${value.commits.length}`]
  for (const commit of value.commits.slice(0, 8)) {
    const refs = commit.refs.length === 0 ? '' : ` [${commit.refs.map(ref => ref.name).join(', ')}]`
    lines.push(`${commit.hash.slice(0, 8)} ${commit.subject}${refs}`)
  }
  return lines.join('\n')
}

/** Register the single read-only Git graph tool. */
export function apply(ctx: Context): void {
  // The service resolves each request's Agent workspace. Sidebar reads use
  // Typert RPC directly, independently of the model-facing tool.
  new GitGraphRemoteService(ctx)

  ctx.systemPrompt.section({
    name: 'tool:git_graph',
    order: 116,
    text: `Use git_graph to inspect the repository commit topology, branch/tag/remote references, and working-tree state. It accepts an optional path, max_commits from 1 to ${MAX_COMMITS}, all, and first_parent. It is read-only; do not infer that it can mutate Git.`,
  })

  ctx.tools.register(defineTool({
    name: 'git_graph',
    description: 'Read a repository Git graph with commits, parents, branch/tag/remote references, HEAD, and working-tree state. This tool is read-only.',
    parameters: {
      path: { type: 'string', description: 'Repository directory. Defaults to the current session workspace.' },
      max_commits: { type: 'number', description: `Maximum commits to load, from 1 to ${MAX_COMMITS}. Defaults to 100.` },
      all: { type: 'boolean', description: 'Include all reachable refs. Defaults to true.' },
      first_parent: { type: 'boolean', description: 'Follow only first parents. Defaults to false.' },
      glob: { type: 'array', description: 'Branch-name glob filters (OR); overrides --all when provided.', items: { type: 'string' } },
      search: { type: 'string', description: 'Bounded free-text search (result indicates truncation) across hash, subject, author, email, ref name and date.' },
      sort: { type: 'string', description: 'Commit ordering: date, author-date, or topological. Defaults to date.', enum: ['date', 'author-date', 'topological'] },
    },
    output: {
      schema: GRAPH_OUTPUT_SCHEMA,
      render: (_args, value) => [{ type: 'text', text: summaryText(value) }],
      presentationMeta: (_args, value) => value,
    },
    timeoutMs: 30_000,
    execute: (args, exec) => loadGitGraph(ctx, {
      ...(args.path === undefined ? {} : { path: args.path }),
      ...(args.max_commits === undefined ? {} : { maxCommits: args.max_commits }),
      ...(args.all === undefined ? {} : { all: args.all }),
      ...(args.first_parent === undefined ? {} : { firstParent: args.first_parent }),
      ...(args.glob === undefined ? {} : { glob: args.glob }),
      ...(args.search === undefined ? {} : { search: args.search }),
      ...(args.sort === undefined ? {} : { sort: args.sort }),
    } satisfies GitGraphInput, exec),
    presentCall: args => ({
      card: 'generic',
      title: 'Load Git graph',
      kind: 'read',
      ...args.path === undefined ? {} : { locations: [{ path: args.path, line: 1 }] },
    }),
  }))
  console.info('[git-graph] Read-only Host service and tool registered')
}
