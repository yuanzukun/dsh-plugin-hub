/**
 * Host-side Git adapter. The only process seam is ctx.subprocess; no shell
 * interpolation is used, so a repository path never becomes command text.
 */
import { isAbsolute, relative, resolve, sep } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { SubprocessHandle, SubprocessSpawnSpec } from '@deepseek-ai/dsh-subprocess'
import type {
  GitGraphBranch,
  GitGraphCommit,
  GitGraphCommitDetails,
  GitGraphCompareRequest,
  GitGraphCompareResult,
  GitGraphDiffLine,
  GitGraphFileChange,
  GitGraphFileContent,
  GitGraphFileDiff,
  GitGraphFileDiffRequest,
  GitGraphFileRequest,
  GitGraphInput,
  GitGraphMetadata,
  GitGraphRef,
  GitGraphRepoConfig,
  GitGraphSignature,
  GitGraphSignatureStatus,
  GitGraphSnapshot,
  GitGraphStash,
  GitGraphTag,
  GitGraphWorkingTree,
  GitGraphWorkingTreeChanges,
  GitGraphWorkingTreeFileRequest,
} from './domain.ts'
import { MAX_AVATAR_BATCH, MAX_BRANCH_FILTER, MAX_COMMITS, MAX_SEARCH_COMMITS } from './domain.ts'
import type { AvatarAuthor } from './avatars.ts'

const LOG_FORMAT = '%H%x00%P%x00%aN%x00%aE%x00%aI%x00%cI%x00%s%x00%D%x00%x1e'
const OUTPUT_MAX_BYTES = 8 * 1024 * 1024
const STDERR_MAX_BYTES = 64 * 1024
const GRACE_MS = 3_000

/** Minimal execution identity shared by the tool and the independent view. */
export interface GitGraphExecutionContext {
  readonly agent?: Agent
  readonly signal: AbortSignal
}

/** A stable error type for all Git acquisition failures. */
export class GitGraphError extends Error {
  constructor(message: string, options?: ErrorOptions) {
    super(message, options)
    this.name = 'GitGraphError'
  }
}

interface GitCommandResult {
  readonly exitCode: number | null
  readonly signal: NodeJS.Signals | null
  readonly stdout: string
  readonly stderr: string
}

function outputOf(handle: SubprocessHandle, stream: 'stdout' | 'stderr'): string {
  const reader = handle.collected[stream]
  if (reader === undefined) throw new GitGraphError(`git ${stream} output was not collected`)
  const result = reader.readFrom(0)
  if (result.lossy) throw new GitGraphError(`git ${stream} output exceeded the capture limit`)
  return result.text
}

async function runGit(
  ctx: Context,
  cwd: string,
  args: readonly string[],
  signal: AbortSignal,
  allowedExitCodes: readonly number[] = [0],
): Promise<GitCommandResult> {
  signal.throwIfAborted()
  let handle: SubprocessHandle
  try {
    const spec: SubprocessSpawnSpec = {
      // Read-only views must not refresh the index as an optional side effect;
      // file names are literal pathspecs, even when they contain Git glob syntax.
      argv: ['git', '--no-optional-locks', '--literal-pathspecs', ...args],
      cwd,
      stdio: {
        stdin: 'ignore',
        stdout: { maxBytes: OUTPUT_MAX_BYTES },
        stderr: { maxBytes: STDERR_MAX_BYTES },
      },
      graceMs: GRACE_MS,
      signal,
    }
    handle = ctx.subprocess.spawn(spec)
  } catch (error: unknown) {
    throw new GitGraphError(`无法启动 Git：${String(error)}`, { cause: error })
  }

  let outcome: { exitCode: number | null; signal: NodeJS.Signals | null }
  try {
    outcome = await handle.done
  } catch (error: unknown) {
    throw new GitGraphError(`Git 进程启动失败：${String(error)}`, { cause: error })
  }
  if (signal.aborted) throw new GitGraphError('Git 图谱请求已取消')

  const stdout = outputOf(handle, 'stdout')
  const stderr = outputOf(handle, 'stderr')
  if (outcome.signal !== null || outcome.exitCode === null) {
    throw new GitGraphError(`Git 进程被信号终止：${outcome.signal ?? 'unknown'}`)
  }
  if (!allowedExitCodes.includes(outcome.exitCode)) {
    const detail = stderr.trim()
    throw new GitGraphError(`Git 命令失败（退出码 ${outcome.exitCode}）${detail.length > 0 ? `：${detail}` : ''}`)
  }
  return { ...outcome, stdout, stderr }
}

function parseRefs(decorations: string): GitGraphRef[] {
  const refs: GitGraphRef[] = []
  for (const raw of decorations.split(', ').map(item => item.trim()).filter(item => item.length > 0)) {
    if (raw.startsWith('HEAD -> refs/heads/')) {
      refs.push({ kind: 'head', name: raw.slice('HEAD -> refs/heads/'.length) })
      continue
    }
    if (raw === 'HEAD') {
      // HEAD is represented by isHead, not by a fabricated local branch.
      continue
    }
    if (raw.startsWith('tag: refs/tags/')) {
      refs.push({ kind: 'tag', name: raw.slice('tag: refs/tags/'.length) })
      continue
    }
    if (raw.startsWith('refs/remotes/')) {
      refs.push({ kind: 'remote', name: raw.slice('refs/remotes/'.length) })
      continue
    }
    if (raw.startsWith('refs/heads/')) refs.push({ kind: 'head', name: raw.slice('refs/heads/'.length) })
    // Other namespaces (e.g. refs/stash) are not branch labels. The Git
    // command supplies full decorations, so slash guessing is unnecessary.
  }
  return refs
}

/** Parse the NUL/record-separated log format independently of the process seam. */
export function parseGitLog(text: string): GitGraphCommit[] {
  const commits: GitGraphCommit[] = []
  for (const rawRecord of text.split('\u001e')) {
    // `git log --format` inserts a line break between formatted records. After
    // splitting on RS, that separator prefixes every record except the first;
    // leaving it attached to the hash breaks exact parent-hash lookup.
    const record = rawRecord.replace(/^[\r\n]+/u, '')
    if (record.trim().length === 0) continue
    const fields = record.split('\u0000')
    if (fields.length < 9) throw new GitGraphError('Git log 输出格式不完整')
    const hash = fields[0]
    const parents = fields[1]
    const author = fields[2]
    const email = fields[3]
    const date = fields[4]
    const committerDate = fields[5]
    const subject = fields[6]
    const decorations = fields[7]
    if (hash === undefined || parents === undefined || author === undefined || email === undefined
      || date === undefined || committerDate === undefined || subject === undefined || decorations === undefined || hash.length === 0) {
      throw new GitGraphError('Git log 输出包含空提交记录')
    }
    const refs = parseRefs(decorations)
    commits.push({
      hash,
      parents: parents.length === 0 ? [] : parents.split(' '),
      author,
      email,
      date,
      committerDate,
      subject,
      refs,
      isHead: decorations.split(', ').some(ref => ref.trim() === 'HEAD' || ref.trim().startsWith('HEAD -> ')),
    })
  }
  return commits
}

/** Parse `git status --porcelain=v1 -b` without interpreting file contents. */
export function parseGitStatus(text: string): { branch: string | null; changed: boolean; summary: string } {
  const lines = text.split(/\r?\n/u).filter(line => line.length > 0)
  const header = lines[0]?.startsWith('## ') === true ? lines[0].slice(3) : ''
  const rawBranch = header.split('...')[0]?.trim() ?? ''
  const branch = rawBranch.length === 0 || rawBranch === 'HEAD' || rawBranch.startsWith('HEAD (') || rawBranch.startsWith('No commits yet')
    ? null
    : rawBranch
  const changedCount = lines.slice(header.length > 0 ? 1 : 0).length
  return {
    branch,
    changed: changedCount > 0,
    summary: changedCount === 0 ? '工作区干净' : `${changedCount} 个路径有未提交变更`,
  }
}

function validateInput(input: GitGraphInput): Required<Pick<GitGraphInput, 'maxCommits' | 'all' | 'firstParent' | 'sort' | 'glob' | 'branches' | 'search'>> & GitGraphInput {
  const maxCommits = input.maxCommits ?? 100
  if (!Number.isSafeInteger(maxCommits) || maxCommits < 1 || maxCommits > MAX_COMMITS) {
    throw new GitGraphError(`max_commits 必须是 1 到 ${MAX_COMMITS} 之间的整数`)
  }
  const sort = input.sort ?? 'date'
  if (sort !== 'date' && sort !== 'author-date' && sort !== 'topological') {
    throw new GitGraphError('sort 必须是 date、author-date 或 topological')
  }
  const glob = (input.glob ?? []).map(item => item.trim()).filter(item => item.length > 0)
  if (glob.length > MAX_BRANCH_FILTER) throw new GitGraphError(`glob 最多 ${MAX_BRANCH_FILTER} 项`)
  // Exact branch focus is bounded for the same reason as globs: the value is
  // joined into one bounded query, not an unbounded selector list.
  const branches = (input.branches ?? []).map(item => item.trim()).filter(item => item.length > 0)
  if (branches.length > MAX_BRANCH_FILTER) {
    throw new GitGraphError(`branches 最多 ${MAX_BRANCH_FILTER} 项`)
  }
  const search = (input.search ?? '').trim()
  return {
    ...input,
    maxCommits,
    all: input.all ?? true,
    firstParent: input.firstParent ?? false,
    sort,
    glob,
    branches,
    search,
  }
}

/** Case-insensitive substring match against the full search surface of a commit. */
function commitMatchesSearch(commit: GitGraphCommit, query: string): boolean {
  const needle = query.toLocaleLowerCase()
  const haystack = [
    commit.hash,
    commit.subject,
    commit.author,
    commit.email,
    commit.date,
    commit.committerDate,
    ...commit.refs.map(ref => ref.name),
  ].join('\n').toLocaleLowerCase()
  return haystack.includes(needle)
}

/** Wire format for one branch row: full ref, tip, short name, symbolic target. */
const BRANCH_FORMAT = '%(refname)%00%(objectname)%00%(refname:short)%00%(symref)'

/** Pure parser for the branch listing, exported so it can be tested alone. */
export function parseBranches(stdout: string, currentBranch: string | null): GitGraphBranch[] {
  const branches: GitGraphBranch[] = []
  for (const line of stdout.split(/\r?\n/u)) {
    if (line.length === 0) continue
    const [refname, hash, short, symref] = line.split('\u0000')
    if (refname === undefined || hash === undefined || short === undefined) continue
    if (short.length === 0 || hash.length === 0) continue
    if (symref !== undefined && symref.length > 0) continue
    const kind = refname.startsWith('refs/heads/') ? 'local'
      : refname.startsWith('refs/remotes/') ? 'remote'
        : undefined
    if (kind === undefined) continue
    const name = refname.slice(kind === 'local' ? 'refs/heads/'.length : 'refs/remotes/'.length)
    branches.push({ name, hash, kind, isCurrent: kind === 'local' && name === currentBranch })
  }
  return branches
}

/** Load every branch once per snapshot; one command covers local and remote. */
async function loadBranches(ctx: Context, cwd: string, currentBranch: string | null, signal: AbortSignal, globs: readonly string[] = []): Promise<GitGraphBranch[]> {
  // Delegate wildmatch (negation, ranges and malformed classes) to Git itself.
  // Preserve the UI's plain-prefix convention while constraining namespaces.
  const refs = globs.length === 0 ? ['refs/heads', 'refs/remotes']
    : globs.flatMap(pattern => {
      const suffix = /[*?[]/u.test(pattern) ? pattern : `${pattern}*`
      return [`refs/heads/${suffix}`, `refs/remotes/${suffix}`]
    })
  const result = await runGit(ctx, cwd, ['for-each-ref', `--format=${BRANCH_FORMAT}`, ...refs], signal)
  return parseBranches(result.stdout, currentBranch)
}

function workingDirectory(input: GitGraphInput, exec: GitGraphExecutionContext): string {
  const candidate = input.path?.trim() || exec.agent?.session.header.cwd || process.cwd()
  if (candidate.length === 0) throw new GitGraphError('path 不能为空')
  return resolve(candidate)
}

function isNotGitRepositoryError(error: unknown): boolean {
  return error instanceof GitGraphError && /not a git repository/iu.test(error.message)
}

function nonGitRepositorySnapshot(cwd: string): GitGraphSnapshot {
  return {
    path: cwd,
    state: 'not-git',
    branch: null,
    head: null,
    remotes: [],
    branches: [],
    workingTree: {
      changed: false,
      summary: '不是 Git 仓库',
    },
    commits: [],
    hasMore: false,
    searchTruncated: false,
  }
}

/** Load the bounded graph snapshot used by the model result and Client renderer. */
export async function loadGitGraph(
  ctx: Context,
  input: GitGraphInput,
  exec: GitGraphExecutionContext,
): Promise<GitGraphSnapshot> {
  const validated = validateInput(input)
  const requestedCwd = workingDirectory(validated, exec)
  let cwd = requestedCwd
  let status: GitCommandResult
  try {
    status = await runGit(ctx, cwd, ['status', '--porcelain=v1', '-b'], exec.signal)
  } catch (error: unknown) {
    if (isNotGitRepositoryError(error)) return nonGitRepositorySnapshot(cwd)
    throw error
  }
  const statusInfo = parseGitStatus(status.stdout)
  cwd = await repositoryRoot(ctx, requestedCwd, exec.signal)
  // `rev-parse --verify HEAD` on a fresh repo (no commits yet) exits 128, so a
  // missing HEAD is treated as an empty repository, not a query failure.
  const headResult = await runGit(ctx, cwd, ['rev-parse', '--verify', 'HEAD'], exec.signal, [0, 1, 128])
  const headText = headResult.exitCode === 0 ? headResult.stdout.trim() : ''
  const head = headText.length > 0 ? headText : null
  const remoteResult = await runGit(ctx, cwd, ['remote'], exec.signal)
  const remotes = remoteResult.stdout.split(/\r?\n/u).filter(name => name.length > 0)
  // Listed once per snapshot so the Client can jump to a branch tip and focus
  // exactly that branch without running any write command of its own.
  const branches = await loadBranches(ctx, cwd, statusInfo.branch, exec.signal)
  const orderFlag = validated.sort === 'author-date' ? '--author-date-order'
    : validated.sort === 'topological' ? '--topo-order'
    : '--date-order'
  // Two filters select branches by resolving the real ref list and passing the
  // matched full refs as fixed rev arguments. Exact names win when both are sent:
  // focusing one branch must never silently widen into a glob.
  const nameFilterActive = validated.branches.length > 0 || validated.glob.length > 0
  const selectedBranches = validated.branches.length > 0
    ? branches.filter(branch => validated.branches.includes(branch.name))
    : validated.glob.length > 0
      ? await loadBranches(ctx, cwd, statusInfo.branch, exec.signal, validated.glob)
      : []
  const refArgs =
    nameFilterActive
      ? selectedBranches.map(branch => `refs/${branch.kind === 'local' ? 'heads' : 'remotes'}/${branch.name}`)
      : validated.all ? ['--all'] : []
  // A branch filter that matches nothing yields an empty graph rather than
  // falling back to HEAD history. The repository itself may still be non-empty.
  if (nameFilterActive && selectedBranches.length === 0) {
    return {
      path: cwd,
      state: head === null ? 'empty' : 'ready',
      branch: statusInfo.branch,
      head,
      remotes,
      branches,
      workingTree: {
        changed: statusInfo.changed,
        summary: statusInfo.summary,
      },
      commits: [],
      hasMore: false,
      searchTruncated: false,
    }
  }
  // Search scans beyond the displayed page up to its explicit resource budget;
  // paging is applied to matches and truncation is reported independently.
  const searching = validated.search.length > 0
  // One extra record detects truncation without presenting it as a search hit.
  const cap = searching ? MAX_SEARCH_COMMITS + 1 : validated.maxCommits + 1
  const logArgs = [
    'log',
    '--decorate=full',
    ...refArgs,
    orderFlag,
    ...(validated.firstParent ? ['--first-parent'] : []),
    `--max-count=${cap}`,
    `--format=${LOG_FORMAT}`,
  ]
  // A fresh repository (no commits) makes `git log` exit 128 with "Needed a
  // single revision"; treat that as an empty repository, not a failure.
  let log: GitCommandResult
  try {
    log = await runGit(ctx, cwd, logArgs, exec.signal)
  } catch (error: unknown) {
    if (error instanceof GitGraphError && /Needed a single revision|does not have any commits/iu.test(error.message)) {
      log = { exitCode: 128, signal: null, stdout: '', stderr: '' }
    } else {
      throw error
    }
  }
  const parsed = parseGitLog(log.stdout)
  const searchTruncated = searching && parsed.length > MAX_SEARCH_COMMITS
  const allCommits = (searching ? parsed.slice(0, MAX_SEARCH_COMMITS) : parsed).map(commit => ({ ...commit, isHead: commit.hash === head }))
  const searched = validated.search.length === 0
    ? allCommits
    : allCommits.filter(commit => commitMatchesSearch(commit, validated.search))
  const hasMore = searched.length > validated.maxCommits
  const commits = searched.slice(0, validated.maxCommits)
  return {
    path: cwd,
    state: allCommits.length === 0 ? 'empty' : 'ready',
    branch: statusInfo.branch,
    head,
    remotes,
    branches,
    workingTree: {
      changed: statusInfo.changed,
      summary: statusInfo.summary,
    },
    commits,
    hasMore,
    searchTruncated,
  }
}

/* ------------------------------------------------------------------ *
 * Phase 0 — read-only data pipeline (commit details, tags, stashes,
 * config, working-tree inventory). Pure parsers are exported for tests;
 * command loaders reuse the no-shell runGit seam.
 * ------------------------------------------------------------------ */

/** NUL/record separator used between records and fields (matches the log). */
const DETAILS_FORMAT = [
  '%H',      // 0 hash
  '%P',      // 1 parents
  '%aN',     // 2 author name
  '%aE',     // 3 author email
  '%aI',     // 4 author ISO date
  '%cN',     // 5 committer name
  '%cE',     // 6 committer email
  '%cI',     // 7 committer ISO date
  '%G?',     // 8 signature status (G/U/X/Y/R/E/B or empty)
  '%GS',     // 9 signature signer
  '%GK',     // 10 signature key
  '%B',      // 11 body
  '%x1e',    // record separator
].join('%x00')

const DETAILS_FIELD_COUNT = 12

/** Parse an empty-or-status signature string ("", or G/U/X/Y/R/E/B) into a signature. */
export function parseSignatureStatus(status: string, signer: string, key: string): GitGraphSignature | null {
  const trimmed = status.trim()
  if (trimmed.length === 0) return null
  const statuses: GitGraphSignatureStatus[] = ['G', 'U', 'X', 'Y', 'R', 'E', 'B']
  if (!(statuses as string[]).includes(trimmed)) return null
  return {
    status: trimmed as GitGraphSignatureStatus,
    key: key.trim() || null,
    signer: signer.trim() || null,
  }
}

/** Parse one `git show --quiet` details record into a details object. */
function parseCommitDetailsRecord(record: string): GitGraphCommitDetails {
  const fields = record.split('\u0000')
  if (fields.length < DETAILS_FIELD_COUNT) throw new GitGraphError('Git commit details 输出格式不完整')
  const [
    hash, parents, author, authorEmail, authorDate,
    committer, committerEmail, committerDate, sigStatus, sigSigner, sigKey, body,
  ] = fields
  // Root commits have no parents, so `parents` is allowed to be empty; the
  // remaining header fields must all be populated.
  for (const field of [hash, author, authorEmail, authorDate, committer, committerEmail, committerDate]) {
    if (field === undefined || field.length === 0) throw new GitGraphError('Git commit details 包含空字段')
  }
  return {
    hash: hash!,
    parents: parents!.length === 0 ? [] : parents!.split(' '),
    author: author!,
    authorEmail: authorEmail!,
    committer: committer!,
    committerEmail: committerEmail!,
    timestamps: {
      authorDate: authorDate!,
      committerDate: committerDate!,
    },
    signature: parseSignatureStatus(sigStatus ?? '', sigSigner ?? '', sigKey ?? ''),
    body: (body ?? '').replace(/\s+$/u, ''),
    fileChanges: [],
  }
}

/** Parse the whole `git show --quiet` stream (may contain one record). */
export function parseCommitDetails(text: string): GitGraphCommitDetails {
  for (const rawRecord of text.split('\u001e')) {
    const record = rawRecord.replace(/^[\r\n]+/u, '')
    if (record.trim().length === 0) continue
    return parseCommitDetailsRecord(record)
  }
  throw new GitGraphError('Git commit details 输出为空')
}

/** Parse `git diff-tree/diff --name-status -z` records into path/status pairs. */
export function parseDiffNameStatus(text: string): Array<{ readonly type: GitGraphFileChange['type']; readonly oldPath: string; readonly newPath: string }> {
  const tokens = text.split('\u0000')
  const result: Array<{ readonly type: GitGraphFileChange['type']; readonly oldPath: string; readonly newPath: string }> = []
  let i = 0
  while (i < tokens.length) {
    const statusToken = tokens[i]
    if (statusToken === undefined || statusToken.length === 0) { i += 1; continue }
    // Rename/copy status come as "R100" / "C80" with two paths after.
    const isRename = /^[RC]/u.test(statusToken)
    if (isRename) {
      const oldPath = tokens[i + 1]
      const newPath = tokens[i + 2]
      if (oldPath === undefined || newPath === undefined) throw new GitGraphError('Git diff name-status 重命名记录不完整')
      result.push({ type: 'R', oldPath, newPath })
      i += 3
    } else {
      const path = tokens[i + 1]
      if (path === undefined) throw new GitGraphError('Git diff name-status 记录不完整')
      const type = (statusToken[0] ?? 'M') as GitGraphFileChange['type']
      result.push({ type, oldPath: path, newPath: path })
      i += 2
    }
  }
  return result
}

/** Parse `git diff-tree/diff --numstat -z` records: "add\tdel\tpath" (or old/new for renames). */
export function parseDiffNumStat(text: string): Map<string, { readonly additions: number | null; readonly deletions: number | null }> {
  // With -z a rename has an empty path field followed by old/new NUL tokens.
  // Read only the first two TAB separators; a filename may itself contain TAB.
  const records = text.split('\u0000')
  const map = new Map<string, { readonly additions: number | null; readonly deletions: number | null }>()
  let index = 0
  while (index < records.length) {
    const record = records[index++]
    if (record === undefined || record.length === 0) continue
    const fields = /^(-|\d+)\t(-|\d+)\t([\s\S]*)$/u.exec(record)
    if (fields === null) throw new GitGraphError('Git numstat 记录格式不完整')
    let path = fields[3] ?? ''
    if (path.length === 0) {
      const oldPath = records[index++]
      const newPath = records[index++]
      if (!oldPath || !newPath) throw new GitGraphError('Git numstat 重命名记录不完整')
      path = newPath
    }
    const additions = fields[1] === '-' ? null : Number(fields[1])
    const deletions = fields[2] === '-' ? null : Number(fields[2])
    if ((additions !== null && !Number.isSafeInteger(additions)) || (deletions !== null && !Number.isSafeInteger(deletions))) {
      throw new GitGraphError('Git numstat 行数超出安全整数范围')
    }
    map.set(path, { additions, deletions })
  }
  return map
}

/** Merge name-status and numstat into file changes (reusing vscode semantics). */
export function mergeFileChanges(
  nameStatus: ReadonlyArray<{ readonly type: GitGraphFileChange['type']; readonly oldPath: string; readonly newPath: string }>,
  numStat: Map<string, { readonly additions: number | null; readonly deletions: number | null }>,
): GitGraphFileChange[] {
  return nameStatus.map(entry => {
    const stat = numStat.get(entry.newPath)
    if (stat === undefined) throw new GitGraphError(`Git numstat 缺少文件记录：${entry.newPath}`)
    return {
      type: entry.type,
      oldPath: entry.oldPath,
      newPath: entry.newPath,
      additions: stat?.additions ?? null,
      deletions: stat?.deletions ?? null,
    }
  })
}

/**
 * Load the full details of one commit: `git show --quiet` for the header +
 * `diff-tree --name-status/--numstat` against its first parent (or root).
 */
export async function loadCommitDetails(
  ctx: Context,
  cwd: string,
  hash: string,
  signal: AbortSignal,
): Promise<GitGraphCommitDetails> {
  assertValidHash(hash)
  const show = await runGit(ctx, cwd, ['-c', 'log.showSignature=false', 'show', '--quiet', hash, `--format=${DETAILS_FORMAT}`], signal)
  const details = parseCommitDetails(show.stdout)

  // Explicitly compare merge commits to the first parent; single-commit
  // diff-tree output otherwise omits merge changes. Root commits use --root.
  const revisions = details.parents[0] === undefined ? ['--root', hash] : [details.parents[0], hash]
  const common = ['-c', 'log.showSignature=false', 'diff-tree', '-r', '--no-commit-id', '--find-renames', '--diff-filter=AMDRTU', '-z']
  const nameArgs = [...common, '--name-status', ...revisions]
  const numArgs = [...common, '--numstat', ...revisions]
  const [nameResult, numResult] = await Promise.all([
    runGit(ctx, cwd, nameArgs, signal),
    runGit(ctx, cwd, numArgs, signal),
  ])
  const nameEntries = parseDiffNameStatus(nameResult.stdout)
  const numMap = parseDiffNumStat(numResult.stdout)
  return { ...details, fileChanges: mergeFileChanges(nameEntries, numMap) }
}

/** Parse `git reflog refs/stash --format=<fmt>` into stash entries. */
export function parseStashReflog(text: string): GitGraphStash[] {
  const stashes: GitGraphStash[] = []
  for (const rawRecord of text.split('\u001e')) {
    const record = rawRecord.replace(/^[\r\n]+/u, '')
    if (record.trim().length === 0) continue
    const fields = record.split('\u0000')
    if (fields.length < 6) throw new GitGraphError('Git stash reflog 输出格式不完整')
    const [hash, parents, selector, author, email, date, subject] = fields
    if (hash === undefined || parents === undefined || selector === undefined || author === undefined || email === undefined || date === undefined || subject === undefined) {
      throw new GitGraphError('Git stash reflog 包含空字段')
    }
    const parentHashes = parents.length === 0 ? [] : parents.split(' ')
    const baseHash = parentHashes[0] ?? ''
    // A 3-parent stash has an untracked-files commit as the third parent.
    const untrackedFilesHash = parentHashes.length >= 3 ? parentHashes[2] ?? null : null
    stashes.push({
      selector,
      hash,
      baseHash,
      untrackedFilesHash,
      author,
      email,
      date,
      message: subject,
    })
  }
  return stashes
}

/** Load all stashes (`git reflog refs/stash`). */
export async function loadStashes(ctx: Context, cwd: string, signal: AbortSignal): Promise<GitGraphStash[]> {
  const stashFormat = ['%H', '%P', '%gD', '%aN', '%aE', '%aI', '%s', '%x1e'].join('%x00')
  // When no stash exists, `git reflog refs/stash` exits 128 ("bad revision").
  // Those exit codes mean "no stashes", not a query failure.
  const result = await runGit(ctx, cwd, ['reflog', `--format=${stashFormat}`, 'refs/stash', '--'], signal, [0, 1, 128])
  if (result.exitCode !== 0 && result.stdout.trim().length === 0) return []
  return parseStashReflog(result.stdout)
}

/** Load all tags and their details in one bounded subprocess capture. */
export async function loadTags(ctx: Context, cwd: string, signal: AbortSignal): Promise<GitGraphTag[]> {
  // Fixed-width NUL fields preserve multiline messages and separator characters.
  // Git adds one newline after each record; only strip it from the next hash.
  const fields = ['%(objectname)', '%(refname)', '%(objecttype)', '%(taggername)', '%(taggeremail)', '%(taggerdate:iso-strict)', '%(contents:signature)', '%(contents)']
  const result = await runGit(ctx, cwd, ['for-each-ref', 'refs/tags', `--format=${fields.join('%00')}%00`], signal)
  const tokens = result.stdout.split('\u0000')
  const tags: GitGraphTag[] = []
  for (let index = 0; index + 7 < tokens.length; index += 8) {
    const [rawHash = '', ref = '', kind = '', tagger = '', email = '', date = '', signature = '', message = ''] = tokens.slice(index, index + 8)
    const objectHash = rawHash.replace(/^[\r\n]+/u, '')
    if (!ref.startsWith('refs/tags/') || objectHash.length === 0) throw new GitGraphError('Git tag 输出格式不完整')
    const annotated = kind === 'tag'
    tags.push({
      name: ref.slice('refs/tags/'.length),
      annotated,
      detail: annotated ? {
        objectHash,
        tagger: tagger.trim(),
        taggerEmail: email.trim(),
        taggerDate: date,
        message: message.replace(/\s+$/u, ''),
        // Signature presence does not establish verification or signer identity.
        signature: signature.trim().length > 0 ? { status: 'E', key: null, signer: null } : null,
      } : null,
    })
  }
  return tags
}

/** Parse `git config --list -z --includes [--local|--global]` into key/value pairs. */
export function parseConfigList(text: string): Map<string, string> {
  const map = new Map<string, string>()
  // --null terminates each key with a newline and each value with NUL, so each
  // NUL token is "<key>\n<value>" (value may itself be multi-line). Accept LF or
  // CRLF separators to stay robust across git versions/platforms.
  for (const pair of text.split('\u0000')) {
    if (pair.length === 0) continue
    const match = /^(.*?)(?:\r?\n)([\s\S]*)$/u.exec(pair)
    if (match === null) continue
    const key = match[1] ?? ''
    const value = (match[2] ?? '').replace(/\r$/u, '')
    map.set(key, value)
  }
  return map
}

/** Load consolidated/local/global config lists and build the read-only repo config. */
export async function loadRepoConfig(ctx: Context, cwd: string, remotes: readonly string[], signal: AbortSignal): Promise<GitGraphRepoConfig> {
  const [consolidated, local, global] = await Promise.all([
    runGit(ctx, cwd, ['--no-pager', 'config', '--list', '-z', '--includes'], signal),
    runGit(ctx, cwd, ['--no-pager', 'config', '--list', '-z', '--includes', '--local'], signal),
    runGit(ctx, cwd, ['--no-pager', 'config', '--list', '-z', '--includes', '--global'], signal),
  ])
  const consolidatedMap = parseConfigList(consolidated.stdout)
  const localMap = parseConfigList(local.stdout)
  const globalMap = parseConfigList(global.stdout)

  const branches: Record<string, { readonly remote: string | null; readonly pushRemote: string | null }> = {}
  for (const key of localMap.keys()) {
    const remoteMatch = /^branch\.(.+)\.remote$/u.exec(key)
    const pushMatch = /^branch\.(.+)\.pushremote$/u.exec(key)
    if (remoteMatch !== null) {
      const name = remoteMatch[1]!
      branches[name] = { ...(branches[name] ?? { remote: null, pushRemote: null }), remote: localMap.get(key) ?? null }
    } else if (pushMatch !== null) {
      const name = pushMatch[1]!
      branches[name] = { ...(branches[name] ?? { remote: null, pushRemote: null }), pushRemote: localMap.get(key) ?? null }
    }
  }

  return {
    branches,
    diffTool: consolidatedMap.get('diff.tool') ?? null,
    guiDiffTool: consolidatedMap.get('diff.guitool') ?? null,
    pushDefault: consolidatedMap.get('remote.pushdefault') ?? null,
    remotes: remotes.map(remote => ({
      name: remote,
      url: localMap.get(`remote.${remote}.url`) ?? null,
      pushUrl: localMap.get(`remote.${remote}.pushurl`) ?? null,
    })),
    user: {
      name: { local: localMap.get('user.name') ?? null, global: globalMap.get('user.name') ?? null },
      email: { local: localMap.get('user.email') ?? null, global: globalMap.get('user.email') ?? null },
    },
  }
}

/** Parse `git status -s --porcelain -z` into modified/deleted/untracked inventories. */
export function parseWorkingTreeStatus(text: string): GitGraphWorkingTree {
  const tokens = text.split('\u0000').filter(t => t.length > 0)
  const modified: string[] = []
  const deleted: string[] = []
  const untracked: string[] = []
  let i = 0
  while (i < tokens.length) {
    const token = tokens[i]
    if (token === undefined) break
    // In porcelain v1 -z the destination comes first; the next token is the
    // source path. Both index and worktree columns can report a rename/copy.
    const status = token.slice(0, 2)
    const path = token.slice(3)
    const consumedPath = path.length > 0
    i += /[RC]/u.test(status) ? 2 : 1
    if (consumedPath && path.length > 0) {
      if (status.includes('D') && !status.includes('A')) deleted.push(path)
      else if (status.startsWith('?')) untracked.push(path)
      else modified.push(path)
    }
  }
  const changed = modified.length > 0 || deleted.length > 0 || untracked.length > 0
  return { changed, deleted, untracked, modified }
}

/** Load the working-tree change inventory. */
export async function loadWorkingTree(ctx: Context, cwd: string, includeUntracked: boolean, signal: AbortSignal): Promise<GitGraphWorkingTree> {
  const untracked = includeUntracked ? 'all' : 'no'
  const result = await runGit(ctx, cwd, ['status', '-s', `--untracked-files=${untracked}`, '--porcelain', '-z'], signal)
  return parseWorkingTreeStatus(result.stdout)
}

/* ------------------------------------------------------------------ *
 * On-demand file read and commit comparison (tickets 04).
 * Paths are validated to stay repo-relative; no shell is used.
 * ------------------------------------------------------------------ */

/** Per-file content cap for `gitGraph/readFile`. */
export const FILE_MAX_BYTES = 1 * 1024 * 1024

/**
 * Reject absolute paths, NUL bytes and path traversal outside the repository.
 * Git reports every path in its output relative to the repository root, so
 * `root` is that top level — never the session working directory, which may be
 * a subdirectory of it.
 */
export function assertRepoRelativePath(path: string, root: string): void {
  if (path.length === 0) throw new GitGraphError('文件路径不能为空')
  if (path.includes('\u0000')) throw new GitGraphError('文件路径不能包含 NUL 字节')
  if (path.startsWith('/') || path.startsWith('\\')) throw new GitGraphError('文件路径不能是绝对路径')
  if (/^[A-Za-z]:/u.test(path)) throw new GitGraphError('文件路径不能包含盘符')
  const parts = path.split(/[/\\]+/u)
  if (parts.includes('..')) throw new GitGraphError('文件路径不能包含路径穿越')
  const resolved = resolve(root, path)
  const within = relative(resolve(root), resolved)
  if (within === '..' || within.startsWith(`..${sep}`) || isAbsolute(within)) {
    throw new GitGraphError('文件路径超出工作区范围')
  }
  if (within.length === 0) throw new GitGraphError('文件路径不能指向工作区本身')
}

/**
 * Resolve the repository top level for a working directory that may be any
 * subdirectory of it. Every path Git prints — and every path this module uses
 * as a pathspec or file-system path — is relative to that root, while a bare
 * pathspec is resolved against the process working directory. Reading files and
 * diffs therefore run at the root, so both sides agree.
 */
async function repositoryRoot(ctx: Context, cwd: string, signal: AbortSignal): Promise<string> {
  const result = await runGit(ctx, cwd, ['rev-parse', '--show-toplevel'], signal)
  const root = result.stdout.trim()
  // A worktree-less (bare) or unusual layout still resolves paths the old way.
  return root.length === 0 ? cwd : resolve(root)
}

/**
 * Reject a malformed commit hash up front (defense-in-depth). The Typert wire
 * schema already enforces a full 40-hex hash; this guard also protects any
 * direct loader call and yields a stable GitGraphError instead of a git spell.
 */
function assertValidHash(hash: string): void {
  if (!/^[0-9a-f]{40}$/u.test(hash)) throw new GitGraphError('提交 Hash 必须为 40 位十六进制')
}

/** Detect whether decoded blob text looks like text rather than binary data. */
function isTextContent(text: string): boolean {
  // A NUL or replacement character indicates binary bytes were decoded.
  return !text.includes('\u0000') && !text.includes('\uFFFD')
}

/** Read one version of a repo-relative file at a full commit hash. */
export async function loadFile(
  ctx: Context,
  cwd: string,
  request: GitGraphFileRequest,
  signal: AbortSignal,
): Promise<GitGraphFileContent> {
  // The Typert schema already enforces a full 40-char hash.
  assertValidHash(request.hash)
  const root = await repositoryRoot(ctx, cwd, signal)
  assertRepoRelativePath(request.path, root)
  const specifier = `${request.hash}:${request.path}`
  const sizeResult = await runGit(ctx, root, ['cat-file', '-s', specifier], signal)
  const size = Number.parseInt(sizeResult.stdout.trim(), 10)
  if (Number.isNaN(size) || size < 0) throw new GitGraphError('无法读取文件大小')
  if (size > FILE_MAX_BYTES) {
    return { hash: request.hash, path: request.path, kind: 'binary', text: null, size, truncated: true }
  }
  const content = await runGit(ctx, root, ['cat-file', 'blob', specifier], signal)
  const text = content.stdout
  return {
    hash: request.hash,
    path: request.path,
    kind: isTextContent(text) ? 'text' : 'binary',
    text: isTextContent(text) ? text : null,
    size,
    truncated: false,
  }
}

/** The empty-tree object Git uses as a synthetic root-parent base. */
const EMPTY_TREE_HASH = '4b825dc642cb6eb9a060e54bf8d69288fbee4904'

const HUNK_HEAD_RE = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/u

/** Parse a `git diff` hunk header like `@@ -a,b +c,d @@` into base/new heads. */
export function parseHunkHeader(line: string): { oldStart: number; newStart: number } | null {
  const match = HUNK_HEAD_RE.exec(line)
  if (match === null) return null
  return {
    oldStart: Number.parseInt(match[1] ?? '1', 10),
    newStart: Number.parseInt(match[3] ?? '1', 10),
  }
}

/**
 * Parse the unified text of ONE file diff (`git diff --unified=<n> <base> <new>
 * -- <path>`, where the output is guaranteed to describe a single file) into
 * line records. Old/new line numbers track the two heads so the renderer can
 * show line numbers exactly like vscode-git-graph.
 */
export function parseFileDiff(text: string): GitGraphDiffLine[] {
  const lines: GitGraphDiffLine[] = []
  let oldNo = 0
  let newNo = 0
  let inHunk = false
  for (const rawLine of text.split(/\r?\n/u)) {
    if (rawLine.length === 0) continue
    const head = parseHunkHeader(rawLine)
    if (head !== null) {
      inHunk = true
      oldNo = head.oldStart
      newNo = head.newStart
      continue
    }
    if (!inHunk) continue
    const marker = rawLine[0]
    if (marker === '+') {
      lines.push({ type: 'added', content: rawLine.slice(1), oldLine: null, newLine: newNo })
      newNo += 1
    } else if (marker === '-') {
      lines.push({ type: 'removed', content: rawLine.slice(1), oldLine: oldNo, newLine: null })
      oldNo += 1
    } else if (marker === ' ') {
      lines.push({ type: 'context', content: rawLine.slice(1), oldLine: oldNo, newLine: newNo })
      oldNo += 1
      newNo += 1
    }
    // Any other line (`diff --git`, `index`, `old mode`, `\ No newline`, …)
    // is a patch header and is skipped, never treated as context content.
  }
  return lines
}

/**
 * Load one file's diff using the same range as its enclosing file list. An
 * explicit base compares both selected commits; otherwise use the target's
 * first parent (empty tree for a root commit).
 */
export async function loadFileDiff(
  ctx: Context,
  cwd: string,
  request: GitGraphFileDiffRequest,
  signal: AbortSignal,
): Promise<GitGraphFileDiff> {
  assertValidHash(request.hash)
  // Paths in the file list are repository-root-relative, so they are resolved
  // (and read) at the top level rather than at the session working directory.
  const root = await repositoryRoot(ctx, cwd, signal)
  assertRepoRelativePath(request.path, root)
  let base: string
  let changes: readonly GitGraphFileChange[]
  if (request.baseHash !== undefined) {
    assertValidHash(request.baseHash)
    base = request.baseHash
    // The target's last commit may not touch this file. Resolve status and
    // rename paths from the selected pair, never from its first-parent diff.
    changes = (await loadCompare(ctx, root, { baseHash: base, targetHash: request.hash }, signal)).changes
  } else {
    const details = await loadCommitDetails(ctx, root, request.hash, signal)
    base = details.parents[0] ?? EMPTY_TREE_HASH
    changes = details.fileChanges
  }
  const change = changes.find(file => file.newPath === request.path || file.oldPath === request.path)
  if (change === undefined) throw new GitGraphError(`文件在所选比较范围内不存在或没有变更：${request.path}`)
  // Keep both rename paths in the pathspec so Git can recognize the rename.
  const diff = await runGit(ctx, root, [
    'diff', '--no-color', '--no-ext-diff', '--no-textconv', '--find-renames', '--unified=3',
    base, request.hash, '--', change.oldPath, change.newPath,
  ], signal)
  return {
    hash: request.hash,
    path: change.newPath,
    oldPath: change.oldPath,
    status: change.type,
    binary: change.additions === null || change.deletions === null,
    additions: change.additions ?? 0,
    deletions: change.deletions ?? 0,
    lines: parseFileDiff(diff.stdout),
  }
}

/** The sentinel hash used for the non-committed working-tree side of a diff. */
export const WORKTREE_HASH = 'WORKTREE'

/**
 * The set of files with uncommitted changes relative to HEAD (or to the empty
 * tree in a repository with no commits yet). Tracked modifications come from
 * `git diff HEAD`; untracked files are listed separately as additions. Binary
 * or truncated diffs keep `additions`/`deletions` as `null`.
 */
export async function loadWorkingTreeChanges(
  ctx: Context,
  cwd: string,
  signal: AbortSignal,
): Promise<GitGraphWorkingTreeChanges> {
  const headResult = await runGit(ctx, cwd, ['rev-parse', '--verify', 'HEAD'], signal, [0, 1, 128])
  const base = headResult.exitCode === 0 ? 'HEAD' : EMPTY_TREE_HASH
  const common = ['diff', '--no-ext-diff', '--no-textconv', base, '--find-renames', '--diff-filter=AMDRTU', '-z']
  const [nameResult, numResult] = await Promise.all([
    runGit(ctx, cwd, [...common, '--name-status'], signal),
    runGit(ctx, cwd, [...common, '--numstat'], signal),
  ])
  const tracked = mergeFileChanges(parseDiffNameStatus(nameResult.stdout), parseDiffNumStat(numResult.stdout))
  const statusResult = await runGit(ctx, cwd, ['status', '--porcelain', '--untracked-files=all', '-z'], signal)
  const { untracked } = parseWorkingTreeStatus(statusResult.stdout)
  const changes: GitGraphFileChange[] = [
    ...tracked,
    ...untracked.map(path => ({ type: 'A' as const, oldPath: path, newPath: path, additions: null, deletions: null })),
  ]
  return { changes }
}

/**
 * Diff one file in the working tree against HEAD (or the empty tree for an
 * untracked file). This is the working-tree counterpart of `loadFileDiff` and
 * drives the per-file diff view for uncommitted changes.
 */
export async function loadWorkingTreeFile(
  ctx: Context,
  cwd: string,
  request: GitGraphWorkingTreeFileRequest,
  signal: AbortSignal,
): Promise<GitGraphFileDiff> {
  // The path came from the change inventory, which Git reports relative to the
  // repository root; a pathspec, by contrast, is resolved against the process
  // working directory. Resolve both at the root so a session that runs in a
  // subdirectory still matches its own files.
  const root = await repositoryRoot(ctx, cwd, signal)
  assertRepoRelativePath(request.path, root)
  const { changes } = await loadWorkingTreeChanges(ctx, cwd, signal)
  const change = changes.find(file => file.newPath === request.path || file.oldPath === request.path)
  if (change === undefined) throw new GitGraphError(`文件在工作区不存在或没有变更：${request.path}`)
  const statusResult = await runGit(ctx, root, ['status', '--porcelain', '--untracked-files=all', '-z'], signal)
  const isUntracked = parseWorkingTreeStatus(statusResult.stdout).untracked.includes(request.path)
  let diff: GitCommandResult
  if (isUntracked) {
    diff = await runGit(ctx, root, [
      'diff', '--no-index', '--no-color', '--no-ext-diff', '--no-textconv', '--unified=3',
      '/dev/null', resolve(root, request.path),
    ], signal, [0, 1])
  } else {
    const headResult = await runGit(ctx, root, ['rev-parse', '--verify', 'HEAD'], signal, [0, 1, 128])
    const base = headResult.exitCode === 0 ? 'HEAD' : EMPTY_TREE_HASH
    diff = await runGit(ctx, root, [
      'diff', '--no-color', '--no-ext-diff', '--no-textconv', '--find-renames', '--unified=3',
      base, '--', change.oldPath, change.newPath,
    ], signal)
  }
  const lines = parseFileDiff(diff.stdout)
  const binary = isUntracked ? /^Binary files /mu.test(diff.stdout) : change.additions === null || change.deletions === null
  return {
    hash: WORKTREE_HASH,
    path: change.newPath,
    oldPath: change.oldPath,
    status: change.type,
    binary,
    additions: isUntracked ? lines.filter(line => line.type === 'added').length : change.additions ?? 0,
    deletions: isUntracked ? 0 : change.deletions ?? 0,
    lines,
  }
}

/** Compare two commits (left → right) and return file status/line counts. */
export async function loadCompare(
  ctx: Context,
  cwd: string,
  request: GitGraphCompareRequest,
  signal: AbortSignal,
): Promise<GitGraphCompareResult> {
  assertValidHash(request.baseHash)
  assertValidHash(request.targetHash)
  const range = `${request.baseHash}..${request.targetHash}`
  const common = ['-c', 'log.showSignature=false', 'diff', '--no-commit-id', '--find-renames', '--diff-filter=AMDRTU', '-z', range]
  const [nameResult, numResult] = await Promise.all([
    runGit(ctx, cwd, [...common, '--name-status'], signal),
    runGit(ctx, cwd, [...common, '--numstat'], signal),
  ])
  const nameEntries = parseDiffNameStatus(nameResult.stdout)
  const numMap = parseDiffNumStat(numResult.stdout)
  return {
    baseHash: request.baseHash,
    targetHash: request.targetHash,
    changes: mergeFileChanges(nameEntries, numMap),
  }
}

/** Load repository-level metadata (tags + stashes) for the on-demand view. */
export async function loadMetadata(ctx: Context, cwd: string, signal: AbortSignal): Promise<GitGraphMetadata> {
  const [tags, stashes] = await Promise.all([
    loadTags(ctx, cwd, signal),
    loadStashes(ctx, cwd, signal),
  ])
  return { tags, stashes }
}

/** Resolve identity from Git, never from an email or URL supplied by the browser. */
export async function loadAvatarAuthors(ctx: Context, cwd: string, hashes: readonly string[], signal: AbortSignal): Promise<{ authors: AvatarAuthor[]; remote: string | null }> {
  if (hashes.length === 0 || hashes.length > MAX_AVATAR_BATCH) throw new GitGraphError('头像请求数量超出范围')
  for (const hash of hashes) assertValidHash(hash)
  const [log, remote] = await Promise.all([
    runGit(ctx, cwd, ['log', '--no-walk=unsorted', '--format=%aE%x00%ae%x1e', ...hashes, '--'], signal),
    runGit(ctx, cwd, ['config', '--get', 'remote.origin.url'], signal, [0, 1]),
  ])
  const authors = log.stdout.split('\u001e').filter(record => record.trim().length > 0).map(record => {
    const [email, sourceEmail] = record.replace(/^[\r\n]+/u, '').split('\u0000')
    if (email === undefined || sourceEmail === undefined) throw new GitGraphError('Git 头像作者字段不完整')
    return { email: email.trim(), sourceEmail: sourceEmail.trim() }
  })
  return { authors, remote: remote.exitCode === 0 ? remote.stdout.trim() : null }
}
