import { createHash } from 'node:crypto'
import type { GitGraphAvatar, GitGraphAvatarRequest } from './domain.ts'

export interface AvatarAuthor {
  readonly email: string
  /** GitHub searches the original commit identity; mailmap controls display. */
  readonly sourceEmail: string
}

export const AVATAR_MAX_BYTES = 64 * 1024
const CACHE_SIZE = 128
const SUCCESS_TTL = 24 * 60 * 60 * 1000
const FAILURE_TTL = 15 * 60 * 1000
const MAX_CONCURRENT = 4

export function githubRepository(remote: string | null): string | null {
  if (remote === null) return null
  const ssh = /^git@github\.com:([^/]+)\/([^/]+)\/?$/u.exec(remote)
  let path: string
  if (ssh !== null) path = `${ssh[1]}/${ssh[2]}`
  else {
    try {
      const url = new URL(remote)
      if (url.hostname !== 'github.com' || !['https:', 'http:', 'ssh:'].includes(url.protocol)) return null
      path = url.pathname.replace(/^\/+|\/+$/gu, '')
    } catch { return null }
  }
  path = path.replace(/\.git$/u, '')
  return /^[\w.-]+\/[\w.-]+$/u.test(path) ? path : null
}

export function gravatarUrl(email: string): string {
  return `https://www.gravatar.com/avatar/${emailDigest(email, 'sha256')}?s=64&d=404&r=g`
}

function emailDigest(email: string, algorithm: 'md5' | 'sha256'): string {
  return createHash(algorithm).update(email.trim().toLowerCase()).digest('hex')
}

/**
 * The web origin of the repository's own Git service (Gitea, Gogs, GitLab…).
 * Those services answer the Gravatar-compatible `GET <origin>/avatar/<md5>` with
 * the avatar the account uploaded there, so a self-hosted team gets real photos
 * even when nobody registered with gravatar.com.
 */
export function gitHostOrigin(remote: string | null): string | null {
  if (remote === null) return null
  const ssh = /^(?:[\w.-]+@)?([\w.-]+):(?!\/\/)(.+)$/u.exec(remote)
  const address = ssh !== null ? `https://${ssh[1]}` : remote
  try {
    const url = new URL(address)
    if (url.protocol === 'ssh:' && url.password === '' && url.hostname !== '') return `https://${url.hostname}`
    if (!['https:', 'http:'].includes(url.protocol)) return null
    if (url.username !== '' || url.password !== '') return null
    return url.origin
  } catch { return null }
}

/**
 * GitHub writes `123456+user@users.noreply.github.com` as a commit email when the
 * author hides their address. That address resolves to a public avatar without
 * any repository context, so a repo hosted elsewhere still gets the photo.
 */
const GITHUB_NOREPLY_RE = /^(?<id>\d+)\+[^@\s]+@users\.noreply\.github\.com$/u

export function githubNoreplyAvatarUrl(email: string): string | null {
  const match = GITHUB_NOREPLY_RE.exec(email.trim().toLowerCase())
  const id = match?.groups?.id
  return id === undefined ? null : `https://avatars.githubusercontent.com/u/${id}?s=64`
}

function object(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value) ? value as Record<string, unknown> : undefined
}

/**
 * Restrict every request and redirect, including URLs returned by GitHub. The
 * repository's own Git host is allowed in addition, because its `/avatar/<hash>`
 * endpoint is the team's own avatar store; `allowHostAvatar` limits it to the
 * exact origin the repository is configured against.
 */
function allowedUrl(url: URL, hostOrigin: string | null): boolean {
  if (url.username !== '' || url.password !== '') return false
  if (hostOrigin !== null && url.origin === hostOrigin && /^\/avatar\/[0-9a-f]{32,64}$/u.test(url.pathname)) return true
  return url.protocol === 'https:' && (url.port === '' || url.port === '443')
    && (url.hostname === 'api.github.com' || /^avatars\d*\.githubusercontent\.com$/u.test(url.hostname)
      || ['www.gravatar.com', 'gravatar.com', 'secure.gravatar.com'].includes(url.hostname))
}

async function boundedBody(response: Response, max: number): Promise<Buffer> {
  if (Number(response.headers.get('content-length')) > max) { await response.body?.cancel(); throw new Error('Avatar response is too large') }
  if (response.body === null) throw new Error('Avatar response has no body')
  const reader = response.body.getReader()
  const chunks: Uint8Array[] = []
  let size = 0
  try {
    while (true) {
      const chunk = await reader.read()
      if (chunk.done) break
      size += chunk.value.byteLength
      if (size > max) { await reader.cancel(); throw new Error('Avatar response is too large') }
      chunks.push(chunk.value)
    }
  } finally { reader.releaseLock() }
  return Buffer.concat(chunks, size)
}

function rasterType(body: Buffer): string | null {
  if (body.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return 'png'
  if (body[0] === 255 && body[1] === 216 && body[2] === 255) return 'jpeg'
  if (['GIF87a', 'GIF89a'].includes(body.subarray(0, 6).toString('ascii'))) return 'gif'
  if (body.subarray(0, 4).toString('ascii') === 'RIFF' && body.subarray(8, 12).toString('ascii') === 'WEBP') return 'webp'
  return null
}

/** Fiber-owned, bounded memory cache. No Git files, credentials or disk writes. */
export class AvatarStore {
  private readonly cache = new Map<string, { avatar: GitGraphAvatar; expires: number }>()
  private readonly pending = new Map<string, { task: Promise<GitGraphAvatar>; controller: AbortController; users: number }>()
  private readonly queue: Array<() => void> = []
  private active = 0
  private githubRetryAt = 0

  constructor(private readonly fetcher: typeof fetch = fetch, private readonly now: () => number = Date.now) {}

  private async request(address: string, signal: AbortSignal, accept: string, hostOrigin: string | null = null): Promise<Response> {
    let url = new URL(address)
    const timeout = AbortSignal.any([signal, AbortSignal.timeout(4000)])
    for (let redirects = 0; redirects <= 2; redirects += 1) {
      if (!allowedUrl(url, hostOrigin)) throw new Error('Unsupported avatar URL')
      const response = await this.fetcher(url, { signal: timeout, redirect: 'manual',
        headers: { Accept: accept, 'User-Agent': 'dsh-git-graph' } })
      if (response.status < 300 || response.status >= 400) return response
      const location = response.headers.get('location')
      await response.body?.cancel()
      if (location === null) throw new Error('Avatar redirect has no location')
      const next = new URL(location, url)
      // A redirect must stay inside one provider: the Git host, GitHub's API,
      // GitHub's image CDN, or Gravatar. Anything else is refused.
      const provider = (candidate: URL): string => {
        if (hostOrigin !== null && candidate.origin === hostOrigin) return 'host'
        if (candidate.hostname.endsWith('gravatar.com')) return 'gravatar'
        return candidate.hostname === 'api.github.com' ? 'api' : 'github-image'
      }
      if (provider(next) !== provider(url)) throw new Error('Avatar redirect changed provider')
      url = next
    }
    throw new Error('Too many avatar redirects')
  }

  private async image(url: string, signal: AbortSignal, hostOrigin: string | null = null): Promise<string | null> {
    const response = await this.request(url, signal, 'image/png,image/jpeg,image/webp,image/gif', hostOrigin)
    if (!response.ok) {
      await response.body?.cancel()
      if (response.status === 404 || response.status === 410) return null
      throw new Error(`Avatar provider returned ${response.status}`)
    }
    const body = await boundedBody(response, AVATAR_MAX_BYTES)
    const type = rasterType(body)
    return type === null ? null : `data:image/${type};base64,${body.toString('base64')}`
  }

  /**
   * Ask the repository's own Git service for the avatar of this email. Gitea and
   * Gogs expose `/avatar/<md5>` (Gravatar compatible) and answer with the photo
   * uploaded in that account, so a self-hosted team resolves avatars even when
   * nobody registered with gravatar.com.
   */
  private async hostImage(origin: string, email: string, signal: AbortSignal): Promise<string | null> {
    // Gitea/Gogs index the MD5 form; some deployments also accept the SHA256 form.
    for (const hash of [emailDigest(email, 'md5'), emailDigest(email, 'sha256')]) {
      const image = await this.image(`${origin}/avatar/${hash}?s=64&d=404`, signal, origin)
      if (image !== null) return image
    }
    return null
  }

  private async githubImage(repo: string, author: AvatarAuthor, signal: AbortSignal): Promise<string | null> {
    if (this.githubRetryAt > this.now()) throw new Error('GitHub avatar lookup is rate-limited')
    const url = new URL(`https://api.github.com/repos/${repo}/commits`)
    url.searchParams.set('author', author.sourceEmail)
    url.searchParams.set('per_page', '1')
    const response = await this.request(url.href, signal, 'application/vnd.github+json')
    if (response.status === 429 || (response.status === 403 && response.headers.get('x-ratelimit-remaining') === '0')) this.githubRetryAt = this.now() + FAILURE_TTL
    if (!response.ok) {
      await response.body?.cancel()
      if (response.status === 404 || response.status === 410) return null
      throw new Error(`GitHub avatar lookup returned ${response.status}`)
    }
    const parsed: unknown = JSON.parse((await boundedBody(response, 256 * 1024)).toString('utf8'))
    const entry = Array.isArray(parsed) ? object(parsed[0]) : undefined
    const commitAuthor = object(object(entry?.commit)?.author)
    if (typeof commitAuthor?.email !== 'string' || commitAuthor.email.trim().toLowerCase() !== author.sourceEmail.trim().toLowerCase()) return null
    const account = object(entry?.author)
    if (typeof account?.avatar_url !== 'string') return null
    const imageUrl = new URL(account.avatar_url)
    if (!/^avatars\d*\.githubusercontent\.com$/u.test(imageUrl.hostname)) return null
    imageUrl.searchParams.set('s', '64')
    return this.image(imageUrl.href, signal)
  }

  private async resolveAuthor(author: AvatarAuthor, repo: string | null, host: string | null, source: GitGraphAvatarRequest['source'], key: string, signal: AbortSignal): Promise<GitGraphAvatar> {
    const email = author.email.trim().toLowerCase()
    let image: string | null = null
    let provider: GitGraphAvatar['provider'] = null
    let failed = false
    const lookup = async (read: () => Promise<string | null>) => {
      try { return await read() } catch { signal.throwIfAborted(); failed = true; return null }
    }
    if (/^[^\s@<>]+@[^\s@<>]+$/u.test(email)) {
      // A GitHub noreply address identifies the account on its own, so it works
      // even when the repository has no GitHub remote to search.
      const noreply = source === 'auto' ? githubNoreplyAvatarUrl(email) : null
      if (noreply !== null) {
        image = await lookup(() => this.image(noreply, signal))
        if (image !== null) provider = 'github'
      }
      if (image === null && source === 'auto' && repo !== null) {
        image = await lookup(() => this.githubImage(repo, author, signal))
        if (image !== null) provider = 'github'
      }
      // The repository's own Git service knows its members, so ask it before the
      // public Gravatar directory. GitHub remotes are already covered above.
      if (image === null && source === 'auto' && repo === null && host !== null) {
        image = await lookup(() => this.hostImage(host, email, signal))
        if (image !== null) provider = 'host'
      }
      if (image === null) {
        image = await lookup(() => this.image(gravatarUrl(email), signal))
        if (image !== null) provider = 'gravatar'
      }
    }
    signal.throwIfAborted()
    const unavailable = image === null && failed
    const avatar: GitGraphAvatar = { email, image, provider, unavailable }
    if (unavailable) return avatar
    this.cache.delete(key)
    this.cache.set(key, { avatar, expires: this.now() + (image === null ? FAILURE_TTL : SUCCESS_TTL) })
    if (this.cache.size > CACHE_SIZE) {
      const oldest = this.cache.keys().next().value
      if (oldest !== undefined) this.cache.delete(oldest)
    }
    return avatar
  }

  private async schedule(read: () => Promise<GitGraphAvatar>): Promise<GitGraphAvatar> {
    if (this.active < MAX_CONCURRENT) this.active += 1
    else await new Promise<void>(resume => { this.queue.push(resume) })
    try { return await read() } finally {
      const next = this.queue.shift()
      if (next === undefined) this.active -= 1
      else next()
    }
  }

  private async author(author: AvatarAuthor, repo: string | null, host: string | null, source: GitGraphAvatarRequest['source'], signal: AbortSignal): Promise<GitGraphAvatar> {
    signal.throwIfAborted()
    const identity = source === 'auto' && repo !== null ? author.sourceEmail.trim().toLowerCase() : ''
    const key = JSON.stringify([source, repo ?? host, author.email.trim().toLowerCase(), identity])
    const cached = this.cache.get(key)
    if (cached !== undefined && cached.expires > this.now()) return cached.avatar
    let work = this.pending.get(key)
    if (work === undefined) {
      const controller = new AbortController()
      const task = this.schedule(() => {
        controller.signal.throwIfAborted()
        return this.resolveAuthor(author, repo, host, source, key, controller.signal)
      }).finally(() => {
        if (this.pending.get(key)?.controller === controller) this.pending.delete(key)
      })
      work = { task, controller, users: 0 }
      this.pending.set(key, work)
    }
    work.users += 1
    let abort: (() => void) | undefined
    try {
      const cancelled = new Promise<never>((_, reject) => {
        abort = () => reject(signal.reason)
        signal.addEventListener('abort', abort, { once: true })
      })
      return await Promise.race([work.task, cancelled])
    } finally {
      if (abort !== undefined) signal.removeEventListener('abort', abort)
      work.users -= 1
      if (work.users === 0 && this.pending.get(key) === work) {
        this.pending.delete(key)
        work.controller.abort()
      }
    }
  }

  async read(authors: readonly AvatarAuthor[], remote: string | null, source: GitGraphAvatarRequest['source'], signal: AbortSignal): Promise<GitGraphAvatar[]> {
    const repo = githubRepository(remote)
    const host = gitHostOrigin(remote)
    const unique = [...new Map(authors.map(author => [author.email.trim().toLowerCase(), author])).values()]
    const result: GitGraphAvatar[] = []
    let next = 0
    await Promise.all(Array.from({ length: Math.min(4, unique.length) }, async () => {
      while (next < unique.length) {
        signal.throwIfAborted()
        const author = unique[next++]
        if (author !== undefined) result.push(await this.author(author, repo, host, source, signal))
      }
    }))
    return result
  }
}
