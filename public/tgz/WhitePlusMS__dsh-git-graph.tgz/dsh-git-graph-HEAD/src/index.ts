/**
 * DSH Loader entry. The browser half is discovered from package.json
 * `dsh.client` and `exports["./client"]`; it is intentionally not imported by
 * this Host module.
 */
// Keep the Loader name aligned with the bundle row and the visible product title.
export const name = 'dsh-git-graph'
export const inject = ['subprocess', 'tools', 'systemPrompt']
export { apply } from './runtime.ts'
export { GitGraphRemoteService } from './remote-service.ts'
export type * from './domain.ts'
