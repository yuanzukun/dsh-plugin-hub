import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve, sep } from 'node:path'
import { registerDevTask } from './lib/dev-task.js'
import { newTask, validateWorkflow, verificationBlockers } from './lib/engine.js'
import { adoptRecommendation, resolveFlow, retainStageBindings } from './lib/workflows.js'
import Controller from './lib/controller.js'
import { registerShippedSkills } from './lib/shipped-skills.js'

test('switching to minimal drops only stages outside its graph', () => {
  const requirement = { skills: [{ skill: { source: 'project', name: 'requirements' }, rules: [] }] }
  const development = { skills: [{ skill: { source: 'project', name: 'implement' }, rules: [] }] }
  const result = retainStageBindings('minimal', { '需求': requirement, '开发': development })
  assert.deepEqual(result.dropped, ['需求'])
  assert.deepEqual(result.bindings, { '开发': development })
  const resolved = resolveFlow('minimal', { flow: 'minimal', stage_bindings: result.bindings })
  assert.deepEqual(validateWorkflow(resolved.config), [])
})

/**
 * The preset as a project would actually run it: the skeleton plus the shipped
 * recommendation, adopted exactly the way a user adopts it. A test that asserts
 * on bindings, commit rules or artifacts wants this, because those no longer come
 * from the preset itself.
 * @param {string} id - preset id.
 * @returns {import('./lib/engine.js').WorkflowConfig} the adopted config.
 */
function adoptedFlow(id, extra) {
  const base = adoptRecommendation(id)
  if (base === undefined) throw new Error('unknown preset: ' + id)
  return resolveFlow(id, { ...base, ...extra }).config
}


function fixture(stage = '开发', extra = {}, services = {}) {
  const cwd = resolve('test-project')
  // A project running the standard flow: the skeleton plus the adopted
  // recommendation, with one extra skill mounted on 完成 for the tests that need
  // a binding beyond the shipped set. The bindings are MERGED, not replaced —
  // replacing them would drop the recommended skills and artifacts the tests
  // assert on, since the preset skeleton itself carries none.
  const adopted = adoptRecommendation('standard')
  const config = resolveFlow('standard', {
    ...adopted,
    stage_bindings: {
      ...adopted.stage_bindings,
      完成: { skills: [{ skill: { source: 'project', name: 'software-testing' }, rules: [] }] },
    },
  }).config
  const state = newTask({ id: 'LIVE-1', title: 'EAM regression', branch: 'test', work_size: 'standard', risk_level: 'standard', flow: { flow: 'standard', version: 3, config }, root: cwd })
  Object.assign(state, { stage, execution_version: 1, files: ['app.js'], requirement_confirmed: true, solution_confirmed: true, ...extra })
  const records = new Map([[join(cwd, '.dsh/task-LIVE-1.json'), JSON.stringify(state)],
    [join(cwd, 'app.js'), 'source'],
    [join(cwd, '.dsh/skills/software-testing/SKILL.md'), 'test instructions'],
    [join(cwd, '.dsh/skills/human-check/SKILL.md'), 'manual check instructions']])
  const events = [], runs = []
  const session = { id: 'test-session', header: { cwd }, snapshotEvents: () => events }
  const policy = { mode: 'workspace-write', workspaceRoot: cwd, sessionId: session.id }
  const abort = new AbortController()
  let execute
  const key = (path, options) => join(options?.cwd ?? cwd, path)
  const fs = {
    resolve: async (path, options) => ({ targetKey: key(path, options) }),
    readText: async target => records.get(target.targetKey),
    listDir: async () => [...records.keys()].filter(path => /task-.+\.json$/.test(path)).map(path => ({ name: path.split(/[\\/]/).at(-1) })),
    lstat: async (path, options) => records.has(key(path, options)) ? { version: 'v' } : undefined,
    writeText: async (target, content) => { records.set(target.targetKey, content) },
  }
  const ctx = { fs, tools: { register(tool) { execute = tool.execute; return () => {} } }, get(name) {
    if (Object.hasOwn(services, name)) return services[name]
    if (name === 'sandboxPolicy') return { resolve(request) { assert.equal(request.session, session); return policy } }
    if (name === 'shell') return { resolve(request) { runs.push(request); return request }, async execute(request) {
      const fail = request.command === 'fail'
      const outcome = { exitCode: fail ? 1 : 0, timedOut: false, aborted: false, sandbox: { mode: 'workspace-write', denied: false }, stdout: { text: request.command.startsWith('git -c core.quotepath=false log') ? 'abcdef1234567890abcdef1234567890abcdef12\n【LIVE-1】【TASK】done\n\napp.js\n' : request.command.includes('status --porcelain') ? '' : (request.command === 'git rev-parse HEAD' || request.command.startsWith('git rev-parse --verify')) ? 'abcdef1234567890abcdef1234567890abcdef12' : request.command.includes('ls-tree') ? '100644 blob ffffffffffffffffffffffffffffffffffffffff\tapp.js\0' : request.command.startsWith('git hash-object') ? 'ffffffffffffffffffffffffffffffffffffffff' : '# tests 1\n# pass 1' }, stderr: { text: '' } }
      return { result: async () => outcome }
    } }
    return undefined
  } }
  registerDevTask(ctx)
  const exec = { agent: { session }, signal: abort.signal }
  function load(name, success = true) {
    const callId = `call-${events.length}`
    events.push({ type: 'tool/call', data: { name: 'skill', callId, arguments: JSON.stringify({ name }) } })
    events.push({ type: 'tool/result', data: { message: { content: [{ type: 'tool-result', toolCallId: callId, isError: !success }] } } })
  }
  return { call: args => execute(JSON.parse(JSON.stringify({ task_id: 'LIVE-1', ...args })), exec), load, runs, policy, exec, records, cwd,
    state: () => JSON.parse(records.get(join(cwd, '.dsh/task-LIVE-1.json'))) }
}

test('manual skill evidence is approved by the host without a shell command', async () => {
  const config = resolveFlow('minimal', { flow: 'minimal', stage_bindings: {
    '开发': { skills: [{ skill: { source: 'project', name: 'human-check' }, rules: [], evidence: 'manual' }] },
  } }).config
  const approvals = []
  const f = fixture('开发', { flow: { flow: 'minimal', version: 3, config } }, {
    approval: { request: async request => { approvals.push(request); return 'allowed-once' } },
  })
  f.load('human-check')
  await f.call({ operation: 'skill_result', skill_name: 'human-check', evidence: ['checked by owner'] })
  assert.equal(f.runs.length, 0)
  assert.equal(approvals.length, 1)
  assert.equal(f.state().skill_results['开发']['human-check'].approved, true)
  const manualStatus = JSON.parse(await f.call({ operation: 'status' }))
  assert.deepEqual(manualStatus.skill_blockers, [])
  assert.deepEqual(manualStatus.evidence_blockers, [])
  const denied = fixture('开发', { flow: { flow: 'minimal', version: 3, config } }, {
    approval: { request: async () => 'rejected' },
  })
  denied.load('human-check')
  await assert.rejects(denied.call({ operation: 'skill_result', skill_name: 'human-check', evidence: ['claimed approval'] }), /not approved/)
  assert.equal(denied.state().skill_results?.['开发']?.['human-check'], undefined)
})

test('completion rejects unresolved terminal skills and rules', async () => {
  const config = resolveFlow('minimal', { flow: 'minimal', stage_bindings: {
    '交付': { skills: [{ skill: { source: 'project', name: 'must-run' }, rules: [{ source: 'project', name: 'missing' }], evidence: 'command' }] },
  } }).config
  const f = fixture('交付', {
    flow: { flow: 'minimal', version: 3, config },
    items: [{ id: 'A', title: 'small', status: 'done', review: { spec: { outcome: 'pass' }, quality: { outcome: 'pass' } } }],
    commits: [{ label: 'TASK', hash: 'abcdef1' }],
  })
  const status = JSON.parse(await f.call({ operation: 'status' }))
  assert.ok(status.skill_blockers.length > 0)
  assert.ok(status.missing_rules.length > 0)
  await assert.rejects(f.call({ operation: 'complete' }), /cannot complete.*must-run|cannot complete.*missing/)
  assert.equal(f.state().completed, undefined)
})

test('same-named skill and rule freeze separately and disclose the rule body', async () => {
  const f = fixture()
  f.records.delete(join(f.cwd, '.dsh/task-LIVE-1.json'))
  f.records.set(join(f.cwd, '.dsh/eng.json'), JSON.stringify({ flow: 'minimal', stage_bindings: {
    '开发': { skills: [{ skill: { source: 'project', name: 'custom' }, rules: [{ source: 'project', name: 'custom' }], evidence: 'none' }] },
  } }))
  f.records.set(join(f.cwd, '.dsh/skills/custom/SKILL.md'), 'SKILL BODY')
  f.records.set(join(f.cwd, '.dsh/rules/custom.md'), 'RULE BODY')
  await f.call({ operation: 'create', title: 'collision', branch: 'main', files: ['app.js'] })
  const resources = f.state().flow.resources.filter(resource => resource.ref.name === 'custom')
  assert.deepEqual(resources.map(resource => resource.kind).sort(), ['rule', 'skill'])
  assert.equal(JSON.parse(await f.call({ operation: 'status' })).bindings.rules[0].content, 'RULE BODY')
  f.records.set(join(f.cwd, '.dsh/skills/custom/SKILL.md'), 'CHANGED SKILL')
  const status = JSON.parse(await f.call({ operation: 'status' }))
  assert.equal(status.bindings.skill_contents[0].content, 'CHANGED SKILL')
  assert.ok(status.changed_source_skills.some(ref => ref.includes('project:custom')))
  f.records.delete(join(f.cwd, '.dsh/skills/custom/SKILL.md'))
  const missing = JSON.parse(await f.call({ operation: 'status' }))
  assert.ok(missing.missing_skills.includes('project:custom'))
  assert.equal(missing.bindings.skill_contents.length, 0)
})

test('task creation applies skill_profiles rules even when legacy inline bindings are empty', async () => {
  const f = fixture()
  const skill = { source: 'project', name: 'custom' }
  const rule = { source: 'project', name: 'my-rule' }
  f.records.delete(join(f.cwd, '.dsh/task-LIVE-1.json'))
  f.records.set(join(f.cwd, '.dsh/eng.json'), JSON.stringify({ flow: 'minimal',
    stage_bindings: {
      '开发': { skills: [{ skill, rules: [], evidence: 'none' }] },
      '交付': { skills: [{ skill, rules: [], evidence: 'none' }] },
    },
    skill_profiles: { 'project:custom': { rules: [rule], evidence: 'none' } },
  }))
  f.records.set(join(f.cwd, '.dsh/skills/custom/SKILL.md'), 'SKILL BODY')
  await assert.rejects(f.call({ operation: 'create', title: 'profile regression', branch: 'main', files: ['app.js'] }), /rule:project:my-rule/)
  f.records.set(join(f.cwd, '.dsh/rules/my-rule.md'), 'RULE BODY')
  await f.call({ operation: 'create', title: 'profile regression', branch: 'main', files: ['app.js'] })
  assert.deepEqual(f.state().flow.config.stage_bindings['开发'].skills[0].rules, [rule])
  assert.deepEqual(f.state().flow.config.stage_bindings['交付'].skills[0].rules, [rule])
  assert.equal(f.state().flow.resources.find(resource => resource.kind === 'rule')?.content, 'RULE BODY')
  assert.equal(JSON.parse(await f.call({ operation: 'status' })).bindings.rules[0].content, 'RULE BODY')
})

test('task creation rejects an unavailable skill or rule before writing a record', async () => {
  const f = fixture()
  f.records.delete(join(f.cwd, '.dsh/task-LIVE-1.json'))
  f.records.set(join(f.cwd, '.dsh/eng.json'), JSON.stringify({ flow: 'minimal', stage_bindings: {
    '开发': { skills: [{ skill: { source: 'project', name: 'missing-skill' }, rules: [] }] },
  } }))
  await assert.rejects(f.call({ operation: 'create', title: 'missing', branch: 'main' }), /unreadable bound resources/)
  assert.equal(f.records.has(join(f.cwd, '.dsh/task-LIVE-1.json')), false)
})

test('审查通过后更新状态并激活下一项，保留已完成项的审计', async () => {
  const f = fixture()
  await f.call({ operation: 'items', items: [{ id: 'A', title: 'first', status: 'doing' }, { id: 'B', title: 'second' }] })
  await f.call({ operation: 'dispatch', item_id: 'A', description: 'implemented by worker' })
  await f.call({ operation: 'review_item', item_id: 'A', spec_outcome: 'pass', quality_outcome: 'pass' })
  await f.call({ operation: 'items', items: [{ id: 'A', title: 'first', status: 'done' }, { id: 'B', title: 'second', status: 'doing' }] })
  assert.equal(f.state().items[0].review.spec.outcome, 'pass')
  assert.equal(f.state().items[0].dispatch.description, 'implemented by worker')
  await f.call({ operation: 'items', items: [{ id: 'A', title: 'changed', status: 'doing' }, { id: 'B', title: 'second', status: 'todo' }] })
  assert.equal(f.state().items[0].review, undefined)
  await assert.rejects(f.call({ operation: 'items', items: [{ id: 'A', title: 'x' }, { id: 'A', title: 'y' }] }), /unique/)
})

test('追加修复项可按 id 保留旧标题，拒绝已完成项改名后静默丢审核', async () => {
  const f = fixture()
  await f.call({ operation: 'items', items: [{ id: 'A', title: 'reviewed models', status: 'doing' }] })
  await f.call({ operation: 'review_item', item_id: 'A', spec_outcome: 'pass', quality_outcome: 'pass' })
  await f.call({ operation: 'items', items: [{ id: 'A', status: 'done' }, { id: 'B', title: 'fix race', status: 'doing' }] })
  assert.equal(f.state().items[0].title, 'reviewed models')
  assert.equal(f.state().items[0].review.quality.outcome, 'pass')
  await assert.rejects(f.call({ operation: 'items', items: [{ id: 'A', title: 'rewritten summary', status: 'done' }, { id: 'B', status: 'doing' }] }), /omit title|reopen/)
  assert.equal(f.state().items[0].review.quality.outcome, 'pass')
  assert.equal(f.state().items.length, 2)
  await assert.rejects(f.call({ operation: 'items', items: [{ id: 'NEW' }] }), /title/)
})

test('重排实施项时不静默丢弃已完成项和审查记录', async () => {
  const f = fixture()
  await f.call({ operation: 'items', items: [
    { id: 'I1', title: 'models', status: 'doing' },
    { id: 'I2', title: 'mapper', status: 'todo' },
  ] })
  await f.call({ operation: 'dispatch', item_id: 'I1', description: 'direct implementation' })
  await f.call({ operation: 'review_item', item_id: 'I1', spec_outcome: 'pass', quality_outcome: 'pass' })
  await f.call({ operation: 'items', items: [{ id: 'I1', status: 'done' }, { id: 'I2' }] })
  await f.call({ operation: 'items', items: [{ id: 'I3', title: 'service', status: 'todo' }] })
  assert.deepEqual(f.state().items.map(item => item.id), ['I1', 'I2', 'I3'])
  assert.equal(f.state().items[0].status, 'done')
  assert.equal(f.state().items[0].review.quality.outcome, 'pass')
  assert.equal(f.state().items[0].dispatch.description, 'direct implementation')
  await f.call({ operation: 'items', items_mode: 'replace', items: [{ id: 'I3', title: 'service', status: 'todo' }] })
  assert.deepEqual(f.state().items.map(item => item.id), ['I3', 'I1'])
})

test('Gradle projects default to wrapper test with a visible summary', async () => {
  const f = fixture('测试')
  f.records.set(join(f.cwd, 'build.gradle'), 'plugins { id "java" }')
  f.records.set(join(f.cwd, process.platform === 'win32' ? 'gradlew.bat' : 'gradlew'), 'wrapper')
  await f.call({ operation: 'verify' })
  assert.equal(f.runs[0].command, process.platform === 'win32' ? 'gradlew.bat test --rerun-tasks' : './gradlew test --rerun-tasks')
})

test('Gradle verify accepts fresh JUnit XML and refuses a stale report', async () => {
  const root = mkdtempSync(join(tmpdir(), 'dsh-gradle-verify-'))
  const reportDir = join(root, 'build', 'test-results', 'test')
  let writeReport = true
  const shell = { resolve: request => request, execute: async () => ({ result: async () => {
    if (writeReport) {
      mkdirSync(reportDir, { recursive: true })
      writeFileSync(join(reportDir, 'TEST-example.xml'), '<testsuite tests="2" failures="0" errors="0" skipped="0"/>')
    }
    return { exitCode: 0, timedOut: false, aborted: false, stdout: { text: 'BUILD SUCCESSFUL' }, stderr: { text: '' } }
  } }) }
  try {
    const f = fixture('测试', { root }, { shell })
    await f.call({ operation: 'verify', command: 'gradle test --rerun-tasks' })
    assert.equal(f.state().verification.passed, true)
    assert.deepEqual(f.state().verification.receipt.gradle_report, { count: 2, files: 1 })
    writeReport = false
    await f.call({ operation: 'verify', command: 'gradle test --rerun-tasks' })
    assert.equal(f.state().verification.passed, false)
  } finally { rmSync(root, { recursive: true, force: true }) }
})

test('Maven verify rejects zero or missing Surefire tests even when the command exits zero', async () => {
  let output = 'Tests run: 0, Failures: 0, Errors: 0, Skipped: 0'
  const shell = { resolve: request => request, execute: async () => ({ result: async () => ({
    exitCode: 0, timedOut: false, aborted: false, stdout: { text: output }, stderr: { text: '' },
  }) }) }
  const f = fixture('交付', {}, { shell })
  await f.call({ operation: 'verify', command: 'mvn -q test' })
  assert.equal(f.state().verification.passed, false)
  assert.equal(f.state().verification.receipt.test_summary.count, 0)
  output = 'BUILD SUCCESS'
  await f.call({ operation: 'verify', command: 'mvn -q test' })
  assert.equal(f.state().verification.passed, false)
  assert.equal(f.state().verification.receipt.test_summary.count, null)
  output = 'Tests run: 23, Failures: 0, Errors: 0, Skipped: 0'
  await f.call({ operation: 'verify', command: 'mvn test' })
  assert.equal(f.state().verification.passed, true)
  assert.equal(f.state().verification.receipt.test_summary.count, 23)
})

test('a previously stored Maven zero-test pass is blocked by current workflow gates', () => {
  const f = fixture('代码审核')
  const state = f.state()
  state.verification = { passed: true, evidence: [], receipt: { command: 'mvn test', exit_code: 0,
    timed_out: false, aborted: false, started_at: 'now', finished_at: 'now',
    stdout: 'Tests run: 0, Failures: 0, Errors: 0, Skipped: 0', stderr: '' } }
  assert.match(verificationBlockers(state, state.flow.config).join(' '), /no evidence of executed tests/)
})

test('派发立即反映进行中，重派不复用旧审核且保持单一进行项', async () => {
  const f = fixture()
  await f.call({ operation: 'items', items: [{ id: 'A', title: 'models' }, { id: 'B', title: 'api' }] })
  await f.call({ operation: 'dispatch', item_id: 'A', description: 'implement models' })
  assert.equal(f.state().items[0].status, 'doing')
  await assert.rejects(f.call({ operation: 'dispatch', item_id: 'B' }), /current doing item/)
  await f.call({ operation: 'review_item', item_id: 'A', spec_outcome: 'pass', quality_outcome: 'pass' })
  await f.call({ operation: 'dispatch', item_id: 'A', description: 'rework models' })
  assert.equal(f.state().items[0].review, undefined)
})

test('无任务 id 的 status 发现当前工作区任务并支持分支过滤', async () => {
  const f = fixture()
  assert.equal(JSON.parse(await f.call({ operation: 'status', task_id: undefined })).tasks[0].id, 'LIVE-1')
  assert.equal(JSON.parse(await f.call({ operation: 'status', task_id: undefined, branch: 'other' })).tasks.length, 0)
})

test('verify 升级审批不可用时不得先执行命令', async () => {
  const f = fixture('交付')
  const before = JSON.stringify(f.state())
  await assert.rejects(f.call({ operation: 'verify', command: 'npm test', sandbox_permissions: 'danger-full-access', justification: 'Retry the denied test command' }), /approval/)
  assert.equal(f.runs.length, 0, 'approval must precede shell execution')
  assert.equal(JSON.stringify(f.state()), before)
})

test('verify 拒绝、取消及无效升级参数均不执行命令或改写台账', async () => {
  for (const outcome of ['rejected', 'cancelled', 'unavailable']) {
    const f = fixture('交付', {}, { approval: { request: async () => outcome } })
    const before = JSON.stringify(f.state())
    await assert.rejects(f.call({ operation: 'verify', command: 'npm test', sandbox_permissions: 'danger-full-access', justification: 'Retry denied command' }), /not approved/)
    assert.equal(f.runs.length, 0)
    assert.equal(JSON.stringify(f.state()), before)
  }
  for (const args of [{ sandbox_permissions: 'danger-full-access' }, { justification: 'orphan justification' }]) {
    const f = fixture('交付')
    await assert.rejects(f.call({ operation: 'verify', command: 'npm test', ...args }), /invalid escalation/)
    assert.equal(f.runs.length, 0)
  }
})

test('验证命令审批先于执行，只授权本次命令且回执写入不重复审批', async () => {
  for (const operation of ['verify', 'skill_result']) {
    const approvals = []
    const f = fixture('完成', {}, { approval: { request: async request => {
      assert.equal(f.runs.length, 0)
      approvals.push(request)
      return 'allowed-once'
    } } })
    f.load('software-testing')
    await f.call({ operation, command: 'npm test', skill_name: 'software-testing', evidence: ['real checks'], sandbox_permissions: 'danger-full-access', justification: 'Retry denied test command' })
    assert.equal(approvals.length, 1)
    assert.match(approvals[0].reason, /npm test/)
    assert.equal(f.runs[0].sandboxPolicy.mode, 'danger-full-access')
    assert.equal(f.runs[0].sandboxPolicy.workspaceRoot, f.cwd)
    assert.equal(f.runs[0].sandboxPolicy.sessionId, f.policy.sessionId)
    assert.equal(f.runs[0].signal, f.exec.signal)
    assert.equal(f.policy.mode, 'workspace-write')
    await f.call({ operation: 'verify', command: 'npm test' })
    assert.equal(f.runs[1].sandboxPolicy, f.policy)
    assert.equal(approvals.length, 1)
  }
})

test('skill_result 审批拒绝时不执行命令、不写入技能回执', async () => {
  const f = fixture('完成', {}, { approval: { request: async () => 'rejected' } })
  f.load('software-testing')
  const before = JSON.stringify(f.state())
  await assert.rejects(f.call({ operation: 'skill_result', skill_name: 'software-testing', command: 'npm test', evidence: ['test'], sandbox_permissions: 'danger-full-access', justification: 'Retry denied tests' }), /not approved/)
  assert.equal(f.runs.length, 0)
  assert.equal(JSON.stringify(f.state()), before)
})

test('状态明确区分内置节点门禁与附加技能命令回执，避免重复验证', async () => {
  const f = fixture('代码审核')
  const status = JSON.parse(await f.call({ operation: 'status' }))
  assert.deepEqual(status.skill_obligations.find(row => row.stage === '代码审核').command_receipts_required, [])
  assert.deepEqual(status.skill_obligations.find(row => row.stage === '完成').command_receipts_required, ['software-testing'])
})

test('status 披露当前阶段记录字段和缺项，字段误用不写入且可按提示恢复', async () => {
  const f = fixture('需求评审')
  const before = JSON.stringify(f.state())
  const status = JSON.parse(await f.call({ operation: 'status' }))
  assert.deepEqual(status.artifact_requirements, [{ id: 'requirement', name: '需求说明', fields: ['scope', 'acceptance_criteria'], missing_fields: ['scope', 'acceptance_criteria'] }])
  assert.equal(JSON.stringify(f.state()), before)
  await assert.rejects(f.call({ operation: 'record', artifact: 'requirement', fields: { scope: 'goal', 待确认取舍: 'question' } }), /status.artifact_requirements/)
  assert.equal(JSON.stringify(f.state()), before)
  await f.call({ operation: 'record', artifact: 'requirement', fields: { scope: '目标及待确认取舍', acceptance_criteria: '  ' } })
  assert.deepEqual(JSON.parse(await f.call({ operation: 'status' })).artifact_requirements[0].missing_fields, ['acceptance_criteria'])
  await f.call({ operation: 'record', artifact: 'requirement', fields: { acceptance_criteria: '可执行验收' } })
  assert.deepEqual(JSON.parse(await f.call({ operation: 'status' })).artifact_requirements[0].missing_fields, [])
})

test('记录字段来自冻结流程，精简流程不硬编码标准字段，无记录阶段返回空列表', async () => {
  const config = adoptedFlow('agile')
  const f = fixture('需求', { flow: { flow: 'agile', version: 1, config } })
  assert.deepEqual(JSON.parse(await f.call({ operation: 'status' })).artifact_requirements, [{ id: 'requirement', name: '需求说明', fields: ['scope'], missing_fields: ['scope'] }])
  await f.call({ operation: 'record', artifact: 'requirement', fields: { scope: '目标、验收与疑问' } })
  assert.deepEqual(JSON.parse(await f.call({ operation: 'status' })).artifact_requirements[0].missing_fields, [])
  assert.deepEqual(JSON.parse(await fixture('开发').call({ operation: 'status' })).artifact_requirements, [])
  assert.deepEqual(JSON.parse(await fixture('设计').call({ operation: 'status' })).artifact_requirements[0].fields, ['approach', 'risks', 'impact'])
})

test('空绑定流程不会因范围变更产生额外技能门禁', async () => {
  const f = fixture('需求评审', { artifacts: { requirement: { scope: 'device picker', acceptance_criteria: 'contract and selection' } } })
  await f.call({ operation: 'scope', files: ['app.js', 'new-vo.java'] })
  await f.call({ operation: 'advance', target_stage: '设计' })
  assert.equal(f.state().stage, '设计')
})

test('验证使用会话策略与取消信号，并明确返回失败及沙箱信息', async () => {
  const f = fixture('交付')
  const result = JSON.parse(await f.call({ operation: 'verify', command: 'fail' }))
  assert.equal(result.ok, false)
  assert.equal(f.runs[0].sandboxPolicy, f.policy)
  assert.equal(f.runs[0].signal, f.exec.signal)
  assert.equal(result.verification.receipt.sandbox.mode, 'workspace-write')
})

test('测试执行期间修改任务文件不会生成有效回执', async () => {
  let f
  const shell = { resolve: request => request, async execute() {
    f.records.set(join(f.cwd, 'app.js'), 'changed during tests')
    return { result: async () => ({ exitCode: 0, timedOut: false, aborted: false,
      stdout: { text: '# tests 1\n# pass 1' }, stderr: { text: '' } }) }
  } }
  f = fixture('交付', {}, { shell })
  const result = JSON.parse(await f.call({ operation: 'verify', command: 'npm test' }))
  assert.equal(result.verification.passed, false)
  assert.equal(result.verification.receipt.scope_changed_during_run, true)
})

test('只声明已测试、或加载失败，均不能冒充执行绑定技能', async () => {
  // 代码审核坐在验证门之后，所以该阶段本就要求验证通过；
  // 不给出验证状态会让验证阻塞先于本用例要测的技能阻塞。
  const f = fixture('代码审核', { verification: { passed: true, evidence: ['checks passed'] } })
  await f.call({ operation: 'verify', command: 'npm test', evidence: ['real checks'] })
  f.load('code-review'); f.load('code-commit'); f.load('software-testing', false)
  await assert.rejects(f.call({ operation: 'skill_result', target_stage: '完成', skill_name: 'software-testing', command: 'check', evidence: ['tested'] }), /load skill/)
  await assert.rejects(f.call({ operation: 'advance', target_stage: '完成' }), /software-testing/)
  f.load('software-testing')
  await assert.rejects(f.call({ operation: 'skill_result', target_stage: '完成', skill_name: 'software-testing', evidence: ['claimed pass'] }), /real validation command/)
})

test('绑定技能失败阻止完成；成功后仍须提交真实 Git 回执', async () => {
  const f = fixture('代码审核', { review: { outcome: 'pass' }, artifacts: { review: { conclusion: 'pass', issues: 'none' } }, verification: { passed: true, evidence: ['checks'] } })
  f.load('code-review'); f.load('code-commit'); f.load('software-testing')
  await f.call({ operation: 'verify', command: 'npm test', evidence: ['real checks'] })
  await f.call({ operation: 'skill_result', target_stage: '完成', skill_name: 'software-testing', command: 'fail', evidence: ['scenario failed'] })
  await f.call({ operation: 'review', outcome: 'pass' })
  await assert.rejects(f.call({ operation: 'advance', target_stage: '完成' }), /skill_result/)
  await f.call({ operation: 'skill_result', target_stage: '完成', skill_name: 'software-testing', command: 'check', evidence: ['scenario passed'] })
  await assert.rejects(f.call({ operation: 'advance', target_stage: '完成' }), /commit required/)
  await f.call({ operation: 'commit', files: ['app.js'], message: '【LIVE-1】【TASK】done' })
  await assert.rejects(f.call({ operation: 'commit', files: ['app.js'], message: '【LIVE-1】【TASK】done', hash: 'bbbbbbb' }), /does not match/)
  await f.call({ operation: 'commit', files: ['app.js'], message: '【LIVE-1】【TASK】done', hash: 'abcdef1' })
  await f.call({ operation: 'advance', target_stage: '完成' })
  assert.equal(f.state().stage, '完成')
  assert.equal(f.state().skill_results.完成['software-testing'].load_call_id.startsWith('call-'), true)
})

test('验证后修改代码会使旧回执失效，必须重新验证', async () => {
  const f = fixture('交付')
  f.load('code-verify')
  await f.call({ operation: 'verify', command: 'npm test' })
  f.records.set(join(f.cwd, 'app.js'), 'modified source')
  await assert.rejects(f.call({ operation: 'advance', target_stage: '代码审核' }), /stale/)
  await f.call({ operation: 'verify', command: 'npm test' })
  await f.call({ operation: 'advance', target_stage: '代码审核' })
  assert.equal(f.state().stage, '代码审核')
})

test('status 提交提示与真实门禁一致，分别披露过期验证和附加技能回执且不改台账', async () => {
  const f = fixture('代码审核', { review: { outcome: 'pass' }, artifacts: { review: { conclusion: 'pass', issues: 'none' } } })
  await f.call({ operation: 'verify', command: 'npm test' })
  assert.equal(JSON.parse(await f.call({ operation: 'status' })).commit.allowed, false)
  f.load('code-review'); f.load('code-commit'); f.load('software-testing')
  await f.call({ operation: 'skill_result', target_stage: '完成', skill_name: 'software-testing', command: 'check', evidence: ['tested'] })
  await f.call({ operation: 'review', outcome: 'pass' })
  assert.equal(JSON.parse(await f.call({ operation: 'status' })).commit.allowed, true)
  f.records.set(join(f.cwd, 'app.js'), 'changed after testing')
  const before = JSON.stringify(f.state())
  const stale = JSON.parse(await f.call({ operation: 'status' }))
  assert.equal(stale.commit.allowed, false)
  assert.match(stale.commit.reason, /stale/)
  assert.equal(stale.evidence_blockers.length, 3)
  assert.equal(JSON.stringify(f.state()), before)
  await assert.rejects(f.call({ operation: 'commit', files: ['app.js'], message: '【LIVE-1】【TASK】done' }), /stale/)
  await f.call({ operation: 'verify', command: 'npm test' })
  const partial = JSON.parse(await f.call({ operation: 'status' }))
  assert.equal(partial.commit.allowed, false)
  assert.equal(partial.evidence_blockers.length, 2)
  assert.ok(partial.evidence_blockers.some(problem => /software-testing/.test(problem)))
  await f.call({ operation: 'skill_result', target_stage: '完成', skill_name: 'software-testing', command: 'check', evidence: ['retested'] })
  await f.call({ operation: 'review', outcome: 'pass' })
  const current = JSON.parse(await f.call({ operation: 'status' }))
  assert.equal(current.commit.allowed, true)
  assert.deepEqual(current.evidence_blockers, [])
})

test('同名技能与规则在项目和个人目录各自保留管理入口', async t => {
  const root = mkdtempSync(join(tmpdir(), 'engine-catalog-'))
  const original = process.env.DSH_HOME
  t.after(() => { if (original === undefined) delete process.env.DSH_HOME; else process.env.DSH_HOME = original; assert.ok(resolve(root).startsWith(resolve(tmpdir()) + sep)); rmSync(root, { recursive: true, force: true }) })
  process.env.DSH_HOME = join(root, 'user')
  const project = join(root, 'project')
  for (const base of [join(project, '.dsh'), process.env.DSH_HOME]) {
    mkdirSync(join(base, 'skills/software-testing'), { recursive: true })
    mkdirSync(join(base, 'rules'), { recursive: true })
    writeFileSync(join(base, 'skills/software-testing/SKILL.md'), '\uFEFF---\r\nname: software-testing\r\ndescription: tests\r\n---\r\nRun tests.\r\n')
    writeFileSync(join(base, 'rules/test-rule.md'), 'Test rule\n')
  }
  const receiver = { authorizedPath: async path => path }
  const skills = await Controller.prototype.listSkills.call(receiver, project)
  const rules = await Controller.prototype.listRules.call(receiver, project)
  assert.deepEqual(skills.skills.filter(x => x.name === 'software-testing').map(x => x.source), ['project', 'user'])
  assert.deepEqual(rules.rules.filter(x => x.name === 'test-rule').map(x => x.source), ['project', 'user'])
  const read = await Controller.prototype.readSkill.call(receiver, { path: project, level: 'project', name: 'software-testing' })
  assert.equal(read.ok, true)
  assert.match(read.content, /Run tests/)
})

test('安装包注册会话编排和元技能，阶段目录只隐藏会话编排技能', async () => {
  const registered = []
  registerShippedSkills({ get: name => name === 'skills' ? { register: skill => { registered.push(skill); return () => {} } } : undefined })
  const expected = ['architecture-design', 'code-development', 'code-review', 'eng-delivery',
    'requirements-analysis', 'task-orchestration', 'test-validation']
  assert.deepEqual(registered.map(skill => skill.name).sort(), expected)
  assert.ok(registered.every(skill => skill.content.trim().length > 0))
  const catalog = await Controller.prototype.listSkills.call({ authorizedPath: async path => path }, '')
  assert.deepEqual(catalog.skills.filter(skill => skill.source === 'bundled').map(skill => skill.name).sort(),
    expected.filter(name => name !== 'eng-delivery'))
})
