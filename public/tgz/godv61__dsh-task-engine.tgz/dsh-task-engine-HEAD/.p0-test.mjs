// P0 acceptance test for dsh-task-engine 0.18.0: runs the pure engine +
// workflows functions and the registered `dev_task` tool against an in-memory
// fs, checking every P0 gate: capability binding, frozen snapshot, fail-closed
// unknown flow, core-rule shadow protection, and init three-phase flow.
import { readFileSync } from 'node:fs'
import { registerDevTask } from './lib/dev-task.js'
import { assertAdvance, checkFileScope, newTask, taskIdFromMessage, validateWorkflow } from './lib/engine.js'
import {


  FLOW_PRESETS,
  HIGH_RISK_REQUIRED_CAPABILITIES,
  flowSatisfies,
  resolveFlow,
  adoptRecommendation,
} from './lib/workflows.js'

/**
 * The preset as a project would actually run it: the skeleton plus the shipped
 * recommendation, adopted exactly the way a user adopts it. A test that asserts
 * on bindings, commit rules or artifacts wants this, because those no longer come
 * from the preset itself.
 * @param {string} id - preset id.
 * @returns {import('./lib/engine.js').WorkflowConfig} the adopted config.
 */
function adoptedFlow(id, extra) {
  const base = adoptRecommendation(id)
  if (base === undefined) throw new Error('unknown preset: ' + id)
  return resolveFlow(id, { ...base, ...extra }).config
}

let passed = 0
function assert(cond, msg) {
  if (!cond) {
    console.error('FAIL:', msg)
    throw new Error(msg)
  }
  passed++
  if (process.env.DSH_TEST_DETAILS === '1') console.log(`PASS ${passed}: ${msg}`)
}
async function assertThrows(fn, fragment, msg) {
  try {
    await fn()
  } catch (err) {
    const text = err instanceof Error ? err.message : String(err)
    assert(text.includes(fragment), `${msg} (got: ${text})`)
    return
  }
  throw new Error(`${msg}: expected throw containing "${fragment}"`)
}

function makeFs(initial = {}) {
  const files = new Map(Object.entries(initial))
  const versions = new Map()
  return {
    async resolve(relPath, opts) {
      const base = opts && opts.cwd ? String(opts.cwd).replace(/\\/g, '/') : ''
      const key = base ? `${base}/${relPath}` : relPath
      return { targetKey: key, displayPath: key }
    },
    async readText(target) {
      return files.get(target.targetKey)
    },
    async lstat(path, opts) {
      const base = opts && opts.cwd ? String(opts.cwd).replace(/\\/g, '/') : ''
      const key = base ? `${base}/${path}` : path
      if (!files.has(key)) return undefined
      return { version: `v${versions.get(key) ?? 0}` }
    },
    async writeText(target, content, expected, signal, sandboxPolicy) {
      const key = target.targetKey
      if (expected !== undefined && expected !== null) {
        if (expected.kind === 'createIfAbsent' && files.has(key)) {
          const err = new Error('already exists')
          err.code = 'FS_NOT_OBSERVED'
          throw err
        }
        if (expected.kind === 'replaceIfVersion') {
          const current = `v${versions.get(key) ?? 0}`
          if (!files.has(key) || current !== expected.version) {
            const err = new Error('stale version')
            err.code = 'FS_STALE_VERSION'
            throw err
          }
        }
      }
      files.set(key, content)
      versions.set(key, (versions.get(key) ?? 0) + 1)
    },
    _files: files,
  }
}
function makeCtx(fs, approval) {
  const tools = []
  return {
    fs,
    tools: { register(tool) { tools.push(tool); return () => {} } },
    get(service) {
      if (service === 'approval') return approval
      return undefined
    },
    _tools: tools,
  }
}
async function registered(fs, approval) {
  const ctx = makeCtx(fs, approval)
  registerDevTask(ctx)
  return ctx._tools[0].execute
}
const EXEC = { agent: undefined, callId: undefined, signal: undefined }
// A tool call whose session workspace is `cwd` (the harness process directory is
// deliberately different, exactly like a web session running in e2e-project).
function sessionExec(cwd) {
  return { agent: { session: { header: { cwd } } }, callId: undefined, signal: undefined }
}

// ── 1. capability derivation and high-risk binding ────────────────────────
assert(flowSatisfies('standard', HIGH_RISK_REQUIRED_CAPABILITIES), 'standard satisfies high-risk capabilities')
assert(!flowSatisfies('agile', HIGH_RISK_REQUIRED_CAPABILITIES), 'agile lacks a high-risk capability')
assert(!flowSatisfies('minimal', HIGH_RISK_REQUIRED_CAPABILITIES), 'minimal lacks a high-risk capability')
// Version 3 is the skeleton/recommendation split: the preset now carries only
// state control, and its former bindings, commit text and artifacts are a
// separate recommendation a user adopts. The version number is what makes an
// already-created task keep its frozen config instead of silently changing.
assert(FLOW_PRESETS.standard.version === 3, 'standard preset carries the skeleton/recommendation version')
// Versions are per-preset because they record per-preset changes: agile moved
// again when 审查 gained a completion guard, and a task created before that
// keeps its frozen version and behaves exactly as it did.
assert(FLOW_PRESETS.standard.version === 3, 'standard carries the skeleton/recommendation version')
assert(FLOW_PRESETS.minimal.version === 3, 'minimal carries the skeleton/recommendation version')
assert(FLOW_PRESETS.agile.version === 4, 'agile moved again for the completion guard')

// ── 2. unknown flow fails closed ───────────────────────────────────────────
// `resolveFlow` is called directly here: this test is about the fail-closed
// result, and the adoption helper throws instead of returning one.
const unknown = resolveFlow('nope')
assert(unknown.ok === false && unknown.code === 'UNKNOWN_FLOW', 'unknown flow returns UNKNOWN_FLOW')
assert(unknown.knownFlows.includes('standard'), 'known flow list is surfaced')

// ── 3. the user's bindings are taken as given, not merged with a preset's ────
// The old invariant here was "a preset's core skill survives any override", which
// meant a project could never drop a shipped skill and a project's own rule list
// for that skill was discarded because the skill reference already existed. The
// contract is now the opposite: what the user configured IS the configuration,
// and the preset offers its setup only through explicit adoption.
const bare = resolveFlow('standard', { flow: 'standard' })
assert(bare.ok && Object.keys(bare.config.stage_bindings ?? {}).length === 0,
  'the preset skeleton carries no bindings of its own')

const emptied = resolveFlow('standard', { flow: 'standard', stage_bindings: { '开发': { skills: [] } } })
assert(emptied.ok && (emptied.config.stage_bindings['开发'].skills ?? []).length === 0,
  'a project that binds nothing to a stage keeps it empty; nothing is merged back in')

const adopted = adoptedFlow('standard')
assert(Object.keys(adopted.stage_bindings ?? {}).length === 0,
  'adopting the recommendation does not supply skills')

// And a user who gives a project skill their own rule list gets that list — the
// defect this replaces was that the entry was skipped as a duplicate reference.
const ownRules = resolveFlow('standard', {
  flow: 'standard',
  stage_bindings: {
    '开发': { skills: [{ skill: { source: 'project', name: 'my-implementation' }, rules: [{ source: 'project', name: 'only-mine' }] }] },
  },
}).config
const implementBinding = ownRules.stage_bindings['开发'].skills.find(entry => entry.skill.name === 'my-implementation')
assert(implementBinding.rules.length === 1 && implementBinding.rules[0].name === 'only-mine',
  'a project rule list for a project skill is used as given, not discarded as a duplicate')

// ── 4. newTask freezes the snapshot ────────────────────────────────────────
const snapshot = { flow: 'standard', version: 1, config: adoptedFlow('standard') }
const state = newTask({ id: 'T1', title: 'x', branch: 'main', work_size: 'standard', risk_level: 'standard', flow: snapshot })
assert(state.flow?.flow === 'standard' && state.flow.version === 1, 'newTask stores the frozen snapshot')
assert(state.stage === '需求评审', 'newTask starts at the frozen start stage')

// ── 5. high_risk create on minimal is rejected ─────────────────────────────
await assertThrows(
  () => registered(makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('minimal')) }))
    .then(exe => exe({ operation: 'create', task_id: 'T2', title: 'x', branch: 'main', risk_level: 'high_risk' }, EXEC)),
  'high_risk',
  'high_risk on minimal is rejected',
)

// ── 6. a task keeps its frozen snapshot after eng.json changes ─────────────
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  const exe = await registered(fs)
  const created = await exe({ operation: 'create', task_id: 'T3', title: 'x', branch: 'main' }, EXEC)
  assert(created.includes('需求评审'), 'standard create starts at 需求评审')
  fs._files.set('.dsh/eng.json', JSON.stringify(adoptRecommendation('minimal')))
  const status = JSON.parse(await exe({ operation: 'status', task_id: 'T3' }, EXEC))
  assert(status.flow?.flow === 'standard' && status.flow.version === 3, 'status re-reads the frozen snapshot')
  assert(Array.isArray(status.legal_next) && status.legal_next.includes('设计'),
    'gates come from the frozen standard flow, not the live minimal flow')
}

// ── 7. unknown flow blocks state-changing operations ───────────────────────
await assertThrows(
  () => registered(makeFs({ '.dsh/eng.json': JSON.stringify({ flow: 'nope' }) }))
    .then(exe => exe({ operation: 'create', task_id: 'X', title: 'y', branch: 'z' }, EXEC)),
  'unknown flow',
  'create on an unknown flow fails closed',
)

// ── 8. a file missing its flow field fails closed ──────────────────────────
await assertThrows(
  () => registered(makeFs({ '.dsh/eng.json': JSON.stringify({}) }))
    .then(exe => exe({ operation: 'create', task_id: 'X', title: 'y', branch: 'z' }, EXEC)),
  'missing a "flow" field',
  'eng.json without a flow field is a config error',
)

// ── 9. init: inspect → propose → apply, no direct overwrite ────────────────
{
  const fs = makeFs()
  const exe = await registered(fs)
  const insp = await exe({ operation: 'init', phase: 'inspect' }, EXEC)
  assert(insp.includes('no AGENTS.md'), 'inspect on empty project prompts a scan')
  const prop = await exe({ operation: 'init', phase: 'propose', content: '# 项目\n示例' }, EXEC)
  assert(prop.includes('proposed create'), 'propose previews without writing')
  assert(fs._files.get('AGENTS.md') === undefined, 'propose writes nothing')
  const hash9 = /content hash: ([0-9a-f]{64})/.exec(prop)[1]
  const app = await exe({ operation: 'init', phase: 'apply', content: '# 项目\n示例', expected_hash: hash9 }, EXEC)
  assert(app.includes('wrote ./AGENTS.md'), 'apply writes the file')
  assert(fs._files.get('AGENTS.md') === '# 项目\n示例', 'apply persisted the draft')
}

// ── 10. init protects an existing governance file ─────────────────────────
{
  const fs = makeFs({ 'AGENTS.md': '# 已有治理文件\n' })
  const exe = await registered(fs)
  const prop10 = await exe({ operation: 'init', phase: 'propose', content: '# new' }, EXEC)
  const hash10 = /content hash: ([0-9a-f]{64})/.exec(prop10)[1]
  const existingHash10 = /existing hash: ([0-9a-f]{64})/.exec(prop10)[1]
  assert(existingHash10 !== undefined, 'propose returns the existing-file hash when the file exists')
  await assertThrows(
    () => exe({ operation: 'init', phase: 'apply', content: '# new', expected_hash: hash10 }, EXEC),
    'requires existing_hash',
    'apply without existing_hash on an existing file is rejected',
  )
  await assertThrows(
    () => exe({ operation: 'init', phase: 'apply', content: '# new', expected_hash: hash10, existing_hash: '0'.repeat(64) }, EXEC),
    'existing_hash mismatch',
    'apply with a stale existing_hash is rejected (TOCTOU)',
  )
  await assertThrows(
    () => exe({ operation: 'init', phase: 'apply', content: '# new', expected_hash: hash10, existing_hash: existingHash10 }, EXEC),
    'protected',
    'apply without overwrite on an existing file is rejected',
  )
  await assertThrows(
    () => exe({ operation: 'init', phase: 'apply', content: '# new', expected_hash: hash10, existing_hash: existingHash10, overwrite: true }, EXEC),
    'approval',
    'overwrite requires an approval service',
  )
  await assertThrows(
    () => exe({ operation: 'init', phase: 'apply', content: '# new' }, EXEC),
    'requires expected_hash',
    'apply without expected_hash is rejected',
  )
}

// ── 11. a bound rule resolves from the layer the reference names ────────────
// Rules used to be looked up by bare name through a precedence chain, so a
// project file named like a bundled one silently replaced the shipped body.
// A reference now names its layer (`bundled:` / `project:` / `user:`), so there
// is no chain to walk and no shadowing to defend against: the same name in two
// layers is two distinct resources, and the binding says which one it means.
{
  const fs = makeFs({
    // A project file with the same NAME but a different body. Under the old
    // bare-name lookup this would have replaced the bundled rule silently.
    '.dsh/eng.json': JSON.stringify({
      flow: 'standard',
      stage_bindings: {
        '需求评审': { skills: [{
          skill: { source: 'project', name: 'requirement-analysis' },
          rules: [{ source: 'project', name: 'security-redlines' }],
        }] },
      },
    }),
    '.dsh/rules/security-redlines.md': '# 弱化的安全红线，前端校验即可',
    '.dsh/skills/requirement-analysis/SKILL.md': '# Project requirement analysis',
  })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'T9', title: 'x', branch: 'main' }, EXEC)
  const status = JSON.parse(await exe({ operation: 'status', task_id: 'T9' }, EXEC))
  const sec = status.bindings.rules.find(r => r.name === 'security-redlines')
  assert(sec !== undefined, 'the bound project rule is disclosed at the start stage')
  assert(sec.source === 'project', 'the disclosed rule reports the layer it was resolved from')
  assert(sec.content.includes('前端校验即可'), 'the PROJECT body is what gets disclosed, because the reference names the project layer')
}

// ── 11b. a deleted bundled rule is reported as missing ───────────────────────
{
  const fs = makeFs({
    '.dsh/eng.json': JSON.stringify({
      flow: 'standard',
      stage_bindings: {
        '需求评审': { skills: [{
          skill: { source: 'project', name: 'requirement-analysis' },
          rules: [{ source: 'bundled', name: 'security-redlines' }],
        }] },
      },
    }),
    '.dsh/rules/security-redlines.md': '# 弱化的安全红线，前端校验即可',
    '.dsh/skills/requirement-analysis/SKILL.md': '# Project requirement analysis',
  })
  const exe = await registered(fs)
  await assertThrows(() => exe({ operation: 'create', task_id: 'T10', title: 'x', branch: 'main' }, EXEC),
    'unreadable', 'a reference to a removed bundled rule fails closed')
}

// ── 12. session cwd drives every relative path (init regression) ──────────
{
  const cwd = 'C:/users/ggbond/.dsh-verify/e2e-project'
  const fs = makeFs({
    [`${cwd}/AGENTS.md`]: '# e2e 项目治理文件\n两行\n',
    'D:/dsharness/deepseek-harness/AGENTS.md': '# DeepSeek Harness monorepo (packages/pnpm)\n',
  })
  const exe = await registered(fs)
  const insp = await exe({ operation: 'init', phase: 'inspect' }, sessionExec(cwd))
  assert(insp.includes('# e2e 项目治理文件'), 'inspect reads the session workspace AGENTS.md')
  assert(!insp.includes('monorepo'), 'inspect does not read the harness repo AGENTS.md')
}

// ── 13. create writes the task record into the session workspace ──────────
{
  const cwd = 'C:/users/ggbond/.dsh-verify/e2e-project'
  const fs = makeFs({ [`${cwd}/.dsh/eng.json`]: JSON.stringify(adoptRecommendation('standard')) })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'T12', title: 'x', branch: 'main' }, sessionExec(cwd))
  assert(fs._files.get(`${cwd}/.dsh/task-T12.json`) !== undefined, 'task record lands in the session workspace')
  assert(fs._files.get('.dsh/task-T12.json') === undefined, 'task record does not land in the backend base')
}

// ── 14. K: artifact ids must be unique across ALL stages ────────────────────
{
  const withDup = { ...adoptedFlow('standard'), artifacts: [
    { stage: '需求评审', id: 'doc', name: '需求', fields: ['scope'] },
    { stage: '设计', id: 'doc', name: '设计', fields: ['approach'] },
  ] }
  const problems = validateWorkflow(withDup)
  assert(problems.some(p => p.includes('duplicate artifact id "doc"')),
    'cross-stage duplicate artifact id is rejected')
}

// ── 15. K: record rejects an artifact owned by another stage ─────────────────
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'K1', title: 'x', branch: 'main' }, EXEC)
  await assertThrows(
    () => exe({ operation: 'record', task_id: 'K1', artifact: 'design', fields: { approach: 'a', risks: 'r', impact: 'i' } }, EXEC),
    'belongs to stage',
    'recording an artifact at a non-owning stage is rejected',
  )
}

// ── 16. L/4.2: high-risk verification requires a REAL command receipt ────────
{
  const cfg = adoptedFlow('standard')
  const receipt = overrides => ({
    command: 'npm test', exit_code: 0, timed_out: false, aborted: false,
    started_at: '2026-01-01T00:00:00Z', finished_at: '2026-01-01T00:00:01Z',
    stdout: '# tests 1\n# pass 1', stderr: '', ...overrides,
  })
  const mk = () => {
    const s = newTask({ id: 'L1', title: 'x', branch: 'main', work_size: 'standard', risk_level: 'high_risk', flow: snapshot })
    s.stage = '交付'
    return s
  }
  let s = mk(); s.verification = { passed: true, evidence: ['单测通过'] }
  assert(!assertAdvance(s, '代码审核', cfg).ok, 'high_risk with text-only evidence is blocked (no command receipt)')
  s = mk(); s.verification = { passed: true, evidence: [], receipt: receipt({}) }
  assert(assertAdvance(s, '代码审核', cfg).ok, 'high_risk with an exit-0 receipt passes the verified gate')
  s = mk(); s.verification = { passed: true, evidence: [], receipt: receipt({ exit_code: 1 }) }
  assert(!assertAdvance(s, '代码审核', cfg).ok, 'high_risk with a non-zero exit receipt is blocked')
  s = mk(); s.verification = { passed: true, evidence: [], receipt: receipt({ timed_out: true }) }
  assert(!assertAdvance(s, '代码审核', cfg).ok, 'high_risk with a timed-out receipt is blocked')
  s = mk(); s.verification = { passed: true, evidence: [], receipt: receipt({ aborted: true }) }
  assert(!assertAdvance(s, '代码审核', cfg).ok, 'high_risk with an aborted receipt is blocked')
}

// ── 17. J: task id extracted from the summary (the hook uses it, not a guess) ─
{
  const cfg = adoptedFlow('standard')
  assert(taskIdFromMessage('【GREET-001】【TASK】实现登录', cfg) === 'GREET-001', 'standard summary yields its task id')
  assert(taskIdFromMessage('【GREET-001】【T1】实现登录', cfg) === 'GREET-001', 'item-label summary yields its task id')
  assert(taskIdFromMessage('实现登录', cfg) === undefined, 'non-matching summary yields no task id')
  assert(taskIdFromMessage('随意', adoptedFlow('minimal')) === undefined, 'pattern-less flow yields no task id')
}

// ── 18. N: engine bookkeeping files are exempt from file scope ───────────────
{
  const s = newTask({ id: 'N1', title: 'x', branch: 'main', work_size: 'standard', risk_level: 'standard', flow: snapshot })
  s.files = ['src/a.ts']
  assert(checkFileScope(s, ['src/a.ts', '.dsh/task-N1.json', '.dsh/eng.json'], adoptedFlow('standard')).ok,
    'task record and eng.json do not violate file scope')
  assert(!checkFileScope(s, ['src/b.ts'], adoptedFlow('standard')).ok,
    'an out-of-scope code file is still flagged')
}

// ── 19. H/I: hook reads raw-byte paths, NUL-separated, including deletions ───
{
  const hook = readFileSync('./hooks/commit-msg', 'utf8')
  assert(hook.includes('-c core.quotePath=false'), 'hook disables git octal path quoting')
  assert(hook.includes('-z'), 'hook reads NUL-separated raw-byte paths')
  assert(hook.includes('--diff-filter=ACMRDT'), 'hook includes deletions and type changes in the scope check')
}

// ── 20. 4.1/4.3: hook uses the frozen snapshot; writeInit guards overwrite ──
{
  const hook = readFileSync('./hooks/commit-msg', 'utf8')
  assert(hook.includes('config = state.flow.config'), 'hook checks the task frozen flow snapshot')
  assert(hook.includes('function extractTaskId'), 'hook extracts the task id independent of the live config')
  assert(!hook.includes('const FLOWS'), 'hook bundles the single source (workflows.ts), not a hand mirror')
}
{
  const controller = readFileSync('./lib/controller.js', 'utf8')
  assert(controller.includes('AGENTS.md 已存在且受保护'), 'workbench writeInit refuses to overwrite without an explicit intent')
  assert(controller.includes('overwrite'), 'writeInit request carries an overwrite field')
}

// ── 21. 0.21-A: project adapter — type detection, root discovery, default verify commands ──
const project = await import('./lib/project.js')

function memProbe(files) {
  return {
    async read(dir, relPath) {
      const key = `${dir.replace(/\\/g, '/')}/${relPath}`.replace(/\/+/g, '/')
      return files[key]
    },
  }
}

{
  const probe = memProbe({ '/repo/package.json': '{}' })
  assert(await project.detectType(probe, '/repo') === 'node', 'node marker resolves to node')
  assert(await project.detectRoot(probe, '/repo/src/nested') === '/repo', 'root discovery climbs to the package.json directory')
}
{
  const probe = memProbe({ '/repo/pom.xml': '<project/>' })
  assert(await project.detectType(probe, '/repo') === 'java', 'pom.xml resolves to java')
}
{
  const probe = memProbe({ '/repo/go.mod': 'module x' })
  assert(await project.detectType(probe, '/repo') === 'go', 'go.mod resolves to go')
}
{
  const probe = memProbe({ '/repo/Cargo.toml': '[package]' })
  assert(await project.detectType(probe, '/repo') === 'rust', 'Cargo.toml resolves to rust')
}
{
  const probe = memProbe({ '/repo/requirements.txt': 'flask' })
  assert(await project.detectType(probe, '/repo') === 'python', 'requirements.txt resolves to python')
}
{
  const probe = memProbe({})
  assert(await project.detectType(probe, '/empty') === 'unknown', 'empty tree reports unknown type')
  assert(await project.detectRoot(probe, '/empty/deep/dir') === '/empty/deep/dir', 'root discovery falls back to the start directory')
}
{
  const probe = memProbe({ '/repo/package.json': '{}', '/repo/pyproject.toml': '[tool]' })
  assert(await project.detectType(probe, '/repo') === 'unknown', 'mixed tree reports unknown, never a silent single-language guess')
}
{
  const probe = memProbe({ '/repo/.git/HEAD': 'ref: refs/heads/main' })
  assert(await project.detectRoot(probe, '/repo/sub/module') === '/repo', 'root discovery stops at the git repository')
}
{
  assert(project.defaultVerifyCommand('node') === 'npm test', 'node default verify command')
  assert(project.defaultVerifyCommand('java') === 'mvn -B test', 'java default verify command')
  assert(project.defaultVerifyCommand('go') === 'go test -json ./...', 'go default verify command')
  assert(project.defaultVerifyCommand('unknown') === undefined, 'unknown type has no default command')
}
{
  const probe = memProbe({ '/repo/AGENTS.md': '# a', '/repo/CLAUDE.md': '# c' })
  const present = await project.presentGovernanceFiles(probe, '/repo')
  assert(present.includes('AGENTS.md') && present.includes('CLAUDE.md'), 'governance files are recognized as present')
  assert(!present.includes('.cursorrules'), 'absent governance files are not listed')
}

// ── 22. 0.21-C/D/E: out-of-root write guard, hook risk policy, project binding dirs ──
{
  const { assertInsideRoot } = await import('./lib/dev-task.js')
  assertInsideRoot('/repo', '/repo/sub', 'AGENTS.md')
  assertInsideRoot('/repo/sub', '/repo/sub', 'AGENTS.md')
  await assertThrows(
    () => assertInsideRoot('/repo', '/repo', '../outside.txt'),
    'escapes the project root',
    'init write escaping the root is rejected',
  )
  await assertThrows(
    () => assertInsideRoot('/repo', '/repo', 'C:/elsewhere/x.txt'),
    'escapes the project root',
    'absolute target outside the root is rejected',
  )
}
{
  const hook = readFileSync('./hooks/commit-msg', 'utf8')
  assert(hook.includes('sensitive_paths'), 'hook bundles the risk policy table (single source)')
  assert(hook.includes('risk_level === "high_risk"') || hook.includes('risk_level === \'high_risk\''), 'hook requires high_risk before touching sensitive paths')
}
{
  const probe = {
    async read(dir, relPath) {
      const key = `${dir}/${relPath}`.replace(/\/+/g, '/')
      return files[key]
    },
    async list(dir, relPath) {
      const prefix = `${dir}/${relPath}`.replace(/\/+/g, '/')
      return Object.keys(files).filter(k => k.startsWith(prefix + '/')).map(k => k.slice(prefix.length + 1).split('/')[0])
    },
  }
  const files = {
    '/repo/.dsh/rules/api-conventions.md': '# r',
    '/repo/.dsh/rules/README.md': '# meta',
    '/repo/.dsh/skills/java-dev/SKILL.md': '# s',
    '/repo/.dsh/skills/empty/': '# no skill file',
  }
  const rules = await project.listProjectRules(probe, '/repo')
  assert(rules.length === 2 && rules.includes('api-conventions'), 'project rules list from .dsh/rules/*.md')
  const skills = await project.listProjectSkills(probe, '/repo')
  assert(skills.length === 1 && skills.includes('java-dev'), 'project skills list only dirs carrying SKILL.md')
}

// ── 23. 0.22-A: snapshot hash integrity ────────────────────────────────────
{
  const { hashConfig } = await import('./lib/snapshot.js')
  const config = adoptedFlow('standard')
  const h1 = hashConfig(config)
  const h2 = hashConfig(JSON.parse(JSON.stringify(config)))
  assert(h1 === h2 && /^[0-9a-f]{64}$/.test(h1), 'hashConfig is a deterministic sha256')
  const tampered = JSON.parse(JSON.stringify(config))
  tampered.commit.file_scope = false
  assert(hashConfig(tampered) !== h1, 'editing the frozen config changes the hash')
}
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'HASH-1', title: 'x', branch: 'main' }, EXEC)
  const record = JSON.parse(fs._files.get('.dsh/task-HASH-1.json'))
  record.flow.config.commit.file_scope = false
  fs._files.set('.dsh/task-HASH-1.json', JSON.stringify(record))
  await assertThrows(
    () => exe({ operation: 'status', task_id: 'HASH-1' }, EXEC),
    'hash mismatch',
    'status on a tampered snapshot is rejected',
  )
}
{
  const hook = readFileSync('./hooks/commit-msg', 'utf8')
  assert(hook.includes('hashConfig'), 'hook reuses the single hashConfig source')
  assert(hook.includes('sha256') || hook.includes('createHash'), 'hook bundles the sha256 snapshot check')
}

// ── 24. Hook installation must never guess the process directory ──────────
{
  const fs = makeFs({})
  const exe = await registered(fs)
  await assertThrows(
    () => exe({ operation: 'install_hook' }, EXEC),
    'requires a project workspace',
    'install_hook refuses a session without a workspace',
  )
}

// ── 25. 0.22-B: risk downgrade approval + bindings fingerprint ─────────────
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'RISK-1', title: 'x', branch: 'main', risk_level: 'high_risk' }, EXEC)
  await assertThrows(
    () => exe({ operation: 'set_risk', task_id: 'RISK-1', risk_level: 'standard' }, EXEC),
    'approval',
    'downgrade without an approval service is rejected',
  )
  assert((await exe({ operation: 'set_risk', task_id: 'RISK-1', risk_level: 'high_risk' }, EXEC)).includes('already'),
    'same-risk set_risk is a no-op')
}
{
  const approval = { async request() { return 'allowed-once' } }
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  const exe = await registered(fs, approval)
  await exe({ operation: 'create', task_id: 'RISK-2', title: 'x', branch: 'main', risk_level: 'high_risk' }, EXEC)
  assert((await exe({ operation: 'set_risk', task_id: 'RISK-2', risk_level: 'standard' }, EXEC)).includes('risk_level set to standard'),
    'approved downgrade succeeds')
  const status = JSON.parse(await exe({ operation: 'status', task_id: 'RISK-2' }, EXEC))
  assert(status.risk_level === 'standard' && status.risk_downgrades.length === 1,
    'downgrade is recorded in the audit trail')
}
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'FP-1', title: 'x', branch: 'main' }, EXEC)
  const status = JSON.parse(await exe({ operation: 'status', task_id: 'FP-1' }, EXEC))
  assert(status.bindings_drift === undefined, 'fresh task has no bundled-rule drift marker')
  const record = JSON.parse(fs._files.get('.dsh/task-FP-1.json'))
  assert(record.bindings_fingerprint === undefined,
    'create does not record a fingerprint for removed bundled rules')
}

// ── 26. 0.22-C: multi-language verify command chain + parallel tasks ────────
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify({ flow: 'standard', verify_command: 'mvn test' }) })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'V-1', title: 'x', branch: 'main' }, EXEC)
  await assertThrows(
    () => exe({ operation: 'verify', task_id: 'V-1' }, EXEC),
    'shell',
    'verify falls back to the eng.json command and fails loud without a shell service',
  )
}
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')), 'package.json': '{}' })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'V-2', title: 'x', branch: 'main' }, EXEC)
  await assertThrows(
    () => exe({ operation: 'verify', task_id: 'V-2' }, EXEC),
    'shell',
    'verify falls back to the language default (node → npm test) and fails loud without a shell service',
  )
}
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'V-3', title: 'x', branch: 'main' }, EXEC)
  await assertThrows(() => exe({ operation: 'verify', task_id: 'V-3', passed: true }, EXEC),
    'real validation command', 'new tasks refuse self-reported verification')
  const legacy = JSON.parse(fs._files.get('.dsh/task-V-3.json'))
  delete legacy.execution_version
  fs._files.set('.dsh/task-V-3.json', JSON.stringify(legacy))
  await assertThrows(() => exe({ operation: 'verify', task_id: 'V-3', passed: true }, EXEC),
    'real validation command', 'deleting execution_version cannot enable self-reported verification')
}
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'A-1', title: 'x', branch: 'main' }, EXEC)
  await exe({ operation: 'create', task_id: 'B-2', title: 'y', branch: 'main' }, EXEC)
  await exe({ operation: 'scope', task_id: 'A-1', files: ['src/a.ts'] }, EXEC)
  const a = JSON.parse(await exe({ operation: 'status', task_id: 'A-1' }, EXEC))
  const b = JSON.parse(await exe({ operation: 'status', task_id: 'B-2' }, EXEC))
  assert(a.files.length === 1 && b.files.length === 0, 'two tasks in one repo advance independently')
}

// ── 27. 9.4: init apply validates the expected hash ─────────────────────────
{
  const fs = makeFs({})
  const exe = await registered(fs)
  const propose = await exe({ operation: 'init', phase: 'propose', content: 'hello' }, EXEC)
  const match = /content hash: ([0-9a-f]{64})/.exec(propose)
  assert(match !== null, 'propose returns the content hash')
  await assertThrows(
    () => exe({ operation: 'init', phase: 'apply', content: 'hello', expected_hash: '0'.repeat(64) }, EXEC),
    'expected_hash mismatch',
    'apply with a mismatched hash is rejected',
  )
  assert((await exe({ operation: 'init', phase: 'apply', content: 'hello', expected_hash: match[1] }, EXEC)).includes('wrote'),
    'apply with the matching hash writes the file')
}

// ── 28. risk policy excludes project binding dirs ───────────────────────────
{
  const policy = project.DEFAULT_RISK_POLICY
  assert(!policy.sensitive_paths.includes('.dsh'),
    'project binding dir (.dsh/rules, .dsh/skills) stays committable by normal tasks')
  assert(policy.sensitive_paths.includes('.env'), 'env files remain sensitive')
}

// ── 29. dev_task writes carry the per-call sandbox policy ───────────────────
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  let seenPolicy
  const origWrite = fs.writeText
  fs.writeText = async (target, content, expected, signal, sandboxPolicy) => {
    seenPolicy = sandboxPolicy
    return origWrite(target, content)
  }
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'POL-1', title: 'x', branch: 'main' }, EXEC)
  assert(seenPolicy !== undefined && seenPolicy.mode === 'workspace-write',
    'dev_task writes carry the sandbox mode (default workspace-write)')
  assert(seenPolicy.workspaceRoot === process.cwd(),
    'dev_task writes carry the session workspace root so in-workspace paths are never misjudged as out-of-root')
  await assertThrows(
    () => exe({ operation: 'create', task_id: 'POL-2', title: 'x', branch: 'main', sandbox_permissions: 'danger-full-access' }, EXEC),
    'requires a justification',
    'escalation without a justification is rejected',
  )
}

// ── 30. 0.22.x: sandbox escalation requires a human one-shot approval ───────
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  let seenPolicy
  const origWrite = fs.writeText
  fs.writeText = async (target, content, expected, signal, sandboxPolicy) => {
    seenPolicy = sandboxPolicy
    return origWrite(target, content)
  }
  const approval = { async request() { return 'allowed-once' } }
  const exe = await registered(fs, approval)
  await exe({
    operation: 'create', task_id: 'POL-3', title: 'x', branch: 'main',
    sandbox_permissions: 'danger-full-access', justification: 'the task record must land despite the sandbox denial',
  }, EXEC)
  assert(seenPolicy.mode === 'danger-full-access',
    'approved escalation upgrades the per-call write mode')
}

{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  const exe = await registered(fs) // no approval service
  await assertThrows(
    () => exe({
      operation: 'create', task_id: 'POL-4', title: 'x', branch: 'main',
      sandbox_permissions: 'danger-full-access', justification: 'why',
    }, EXEC),
    'approval service is unavailable',
    'escalation without an approval service fails closed',
  )
}

// ── 31. 0.22.x: set_risk cannot raise risk past the flow's capabilities ─────
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('minimal')) })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'SR-1', title: 'x', branch: 'main' }, EXEC)
  await assertThrows(
    () => exe({ operation: 'set_risk', task_id: 'SR-1', risk_level: 'high_risk' }, EXEC),
    'lacks the required capabilities',
    'raising risk on a minimal flow is rejected (same gate as create)',
  )
}
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'SR-2', title: 'x', branch: 'main' }, EXEC)
  assert((await exe({ operation: 'set_risk', task_id: 'SR-2', risk_level: 'high_risk' }, EXEC)).includes('high_risk'),
    'raising risk on the standard flow succeeds')
}

// ── 32. 0.22.x: remote rejects non-absolute / system-root workspace paths ───
{
  const controller = readFileSync('./lib/controller.js', 'utf8')
  assert(controller.includes('workspace path must be absolute'), 'remote rejects non-absolute workspace paths')
  assert(controller.includes('not an allowed workspace'), 'remote rejects system-wide roots')
}

// ── 33. 0.23: verify runs in the task's recorded project root ──────────────
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')), 'package.json': '{}' })
  const seenWorkdirs = []
  const shell = {
    resolve(request) { return { command: request.command, workdir: request.workdir ?? '', timeoutMs: request.timeoutMs } },
    async run(spec) { seenWorkdirs.push(spec.workdir); return { exitCode: 0, timedOut: false, aborted: false, stdout: { text: 'ok' }, stderr: { text: '' } } },
  }
  const ctx = makeCtx(fs, undefined)
  ctx.get = (service) => (service === 'shell' ? shell : service === 'approval' ? undefined : undefined)
  registerDevTask(ctx)
  const exe = ctx._tools[0].execute
  await exe({ operation: 'create', task_id: 'VR-1', title: 'x', branch: 'main' }, EXEC)
  await exe({ operation: 'verify', task_id: 'VR-1' }, EXEC)
  const record = JSON.parse(fs._files.get('.dsh/task-VR-1.json'))
  assert(seenWorkdirs.length === 1, 'bare verify ran the default command')
  assert(seenWorkdirs[0] === (record.root ?? ''), 'verify ran in the recorded project root, not the session cwd')
  assert(record.verification.receipt.root === record.root, 'receipt binds the recorded project root')
}

// ── 34. 0.23: revision increments on every write (CAS foundation) ───────────
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'CAS-1', title: 'x', branch: 'main' }, EXEC)
  const r1 = JSON.parse(fs._files.get('.dsh/task-CAS-1.json')).revision
  await exe({ operation: 'scope', task_id: 'CAS-1', files: ['a'] }, EXEC)
  const r2 = JSON.parse(fs._files.get('.dsh/task-CAS-1.json')).revision
  assert(r1 === 1 && r2 === 2, 'revision increments on every write')
  const devtask = readFileSync('./lib/task-store.js', 'utf8')
  assert(devtask.includes('changed concurrently'), 'concurrent-write CAS guard is present')
}

// ── 35. 0.23: Remote path guard + workspace registry ────────────────────────
{
  const ctl = await import('./lib/controller.js')
  const one = process.platform === 'win32' ? 'D:/proj/one' : '/proj/one'
  const system = process.platform === 'win32' ? 'C:/Windows/system32' : '/etc'
  assert(ctl.checkedPath(one) === one, 'native absolute workspace passes')
  assert(ctl.checkedPath(one + '/') === one, 'trailing slash is normalized')
  await assertThrows(() => ctl.checkedPath('relative/path'), 'must be absolute', 'relative path is rejected')
  await assertThrows(() => ctl.checkedPath(system), 'not an allowed workspace', 'native system root is rejected')
  ctl.registerWorkspace(one)
  if (process.platform === 'win32') {
    await assertThrows(() => ctl.checkedPath('c:/windows'), 'not an allowed workspace', 'case variant of a system root is rejected')
    assert(ctl.checkedPath('D:/PROJ/one') === 'D:/PROJ/one', 'Windows registered workspace passes under any case')
  } else {
    await assertThrows(() => ctl.checkedPath('/PROJ/one'), 'not registered', 'POSIX workspace case remains significant')
    await assertThrows(() => ctl.checkedPath('D:/proj/one'), 'must be absolute', 'foreign Windows path is not a POSIX workspace')
  }
  await assertThrows(() => ctl.checkedPath(one + '-other'), 'not registered', 'unregistered workspace is rejected once the registry is active')
  ctl.enableStrictWorkspaces()
  await assertThrows(() => ctl.checkedPath(one + '-unregistered'), 'not registered', 'strict mode keeps rejecting unregistered workspaces')
  assert(ctl.checkedPath(one) === one, 'strict mode still admits registered workspaces')
}


// A second writer between content read and write must not be silently overwritten.
{
  const fs = makeFs({ '.dsh/eng.json': JSON.stringify(adoptRecommendation('standard')) })
  const exe = await registered(fs)
  await exe({ operation: 'create', task_id: 'CAS-RACE', title: 'race', branch: 'main' }, EXEC)
  const originalRead = fs.readText.bind(fs)
  let taskReads = 0
  fs.readText = async target => {
    const value = await originalRead(target)
    if (target.targetKey === '.dsh/task-CAS-RACE.json' && ++taskReads === 2) {
      const other = JSON.parse(value)
      other.title = 'concurrent writer'
      other.revision++
      await fs.writeText(target, JSON.stringify(other))
    }
    return value
  }
  await assertThrows(() => exe({ operation: 'scope', task_id: 'CAS-RACE', files: ['a'] }, EXEC), 'changed concurrently', 'CAS rejects writes when version changes after the content read')
  assert(JSON.parse(fs._files.get('.dsh/task-CAS-RACE.json')).title === 'concurrent writer', 'CAS preserves the concurrent writer record')
}

// ── 36. 0.23.3: the path guard normalizes BEFORE the forbidden-prefix test ──
// Testing the raw string let `D:/proj/../../Windows` through: it matches no
// forbidden prefix as written, yet every later join() resolves it to C:/Windows.
// NOTE: block 35 above already activated the module-level registry and strict
// mode, so every path asserted VALID here must be registered first.
{
  const ctl = await import('./lib/controller.js')
  if (process.platform !== 'win32') {
    const valid = ['/work/my project', '/mydir/users-guide', '/proj/one/', '/home/alice/projects/app']
    for (const good of valid) ctl.registerWorkspace(good)
    for (const good of valid) assert(ctl.checkedPath(good) === good.replace(/\/$/u, ''), 'native POSIX workspace passes')
    for (const bad of ['/proj/../../etc', '/home/x/../../usr', '/proj/../../../root', '/var/cache'])
      await assertThrows(() => ctl.checkedPath(bad), 'not an allowed workspace', 'normalized POSIX system path is rejected')
    await assertThrows(() => ctl.checkedPath('/'), 'filesystem root', 'POSIX root is rejected')
    await assertThrows(() => ctl.checkedPath('relative/path'), 'must be absolute', 'relative POSIX path is rejected')
  } else {
  const valid = ['D:/work/my project', 'D:/mydir/users-guide', 'D:/proj/one/', 'C:/Users/alice/projects/app']
  for (const good of valid) ctl.registerWorkspace(good)
  // Must still accept ordinary workspaces, including names that merely look risky.
  for (const good of valid) {
    try {
      ctl.checkedPath(good)
    } catch (error) {
      throw new Error(`checkedPath wrongly rejected a valid workspace "${good}": ${error.message}`)
    }
  }
  assert(ctl.checkedPath('D:/proj/one/') === 'D:/proj/one', 'trailing slash is still normalized away')
  assert(ctl.checkedPath('D:/work/my project') === 'D:/work/my project', 'a space in a workspace name is preserved')
  // Traversal must not smuggle a system directory past the guard.
  await assertThrows(() => ctl.checkedPath('D:/proj/../../Windows'), 'not an allowed workspace', 'traversal into a system dir is rejected after normalization')
  await assertThrows(() => ctl.checkedPath('C:/Users/x/../../Windows'), 'not an allowed workspace', 'traversal out of C:/Users into Windows is rejected')
  await assertThrows(() => ctl.checkedPath('D:/proj/../../../Users'), 'not an allowed workspace', 'traversal into a user tree is rejected')
  await assertThrows(() => ctl.checkedPath('C:/Users/alice/AppData/Roaming'), 'not an allowed workspace', 'user application data is rejected')
  // The system list is drive-agnostic: matching only c:/windows left D:/Windows open.
  await assertThrows(() => ctl.checkedPath('D:/Windows'), 'not an allowed workspace', 'a system dir on a non-C drive is rejected')
  await assertThrows(() => ctl.checkedPath('E:/Program Files/x'), 'not an allowed workspace', 'Program Files on any drive is rejected')
  await assertThrows(() => ctl.checkedPath('C:/ProgramData/x'), 'not an allowed workspace', 'ProgramData is rejected')
  // A bare filesystem root is not a workspace.
  await assertThrows(() => ctl.checkedPath('D:/'), 'filesystem root', 'a drive root is rejected')
  await assertThrows(() => ctl.checkedPath('C:/'), 'filesystem root', 'C:/ is rejected')
  // Regression guard for behaviour block 35 already covered.
  await assertThrows(() => ctl.checkedPath('C:/Windows/system32'), 'not an allowed workspace', 'the original system-root case still fails closed')
  await assertThrows(() => ctl.checkedPath('relative/path'), 'must be absolute', 'a relative path is still rejected')
  }
}

// ── 37. 0.23.3: init writes never escape the authorized workspace ──────────
{
  const ctl = await import('./lib/controller.js')
  assert(typeof ctl.isInside === 'function', 'the containment helper is exported for host integrations')
  // Segment-level comparison: a name-prefix sibling is NOT inside its neighbour.
  assert(ctl.isInside('D:/a/b', 'D:/a/b/c') === true, 'a descendant is inside')
  assert(ctl.isInside('D:/a/b', 'D:/a/b') === true, 'the root itself is inside')
  assert(ctl.isInside('D:/a/b', 'D:/a/bc') === false, 'a name-prefix sibling is NOT inside')
  assert(ctl.isInside('D:/a/b', 'D:/a') === false, 'a parent is not inside')
  assert(ctl.isInside('D:/a/b', 'D:/a/b/../c') === false, 'a traversal out of the workspace is NOT inside')
  const controllerSrc = readFileSync('./lib/controller.js', 'utf8')
  assert(controllerSrc.includes('定位到工作区之外'), 'writeInit refuses a target located outside the workspace')
  assert(controllerSrc.includes('INIT_MAX_ANCESTOR_CLIMB'), 'the ancestor walk is bounded rather than unbounded')
}

console.log(`\nP0 acceptance: ${passed} checks passed`)
