/**
 * DSH codec-contract compatibility check.
 *
 * The plugin's Typert Remote contribution must satisfy whichever strict-codec
 * contract the installed DSH expects. DSH 0.1.6-alpha.2 replaced the
 * materialized `schema` field with a lazy `create: () => TypertSchema` factory
 * and rejects the old shape at plugin load, which took the whole contribution
 * down at boot — a failure the unit tests could not see, because they never
 * load the descriptors through a real registry.
 *
 * npm semver cannot wildcard prereleases, so the peer range enumerates them and
 * a new DSH alpha silently falls outside it; pnpm only warns at install time.
 * This check runs against a real DSH checkout, where the contract actually
 * lives, and fails loudly when the two drift apart again.
 *
 * Run: `node scripts/verify-dsh-compat.mjs [path-to-dsh-checkout]`
 * @module dsh-task-engine/scripts/verify-dsh-compat
 */

import { existsSync, readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

const problems = []
function check(name, ok, detail = '') {
  console.log(`${ok ? 'ok  ' : 'FAIL'} ${name}${detail === '' ? '' : `: ${detail}`}`)
  if (!ok) problems.push(name)
}

/** Locate the typert protocol package inside a DSH checkout. */
function protocolDir(root) {
  const candidates = [
    join(root, 'packages', 'typert', 'protocol'),
    join(root, 'node_modules', '@deepseek-ai', 'dsh-typert-protocol'),
  ]
  return candidates.find(dir => existsSync(join(dir, 'package.json')))
}

const dshRoot = process.argv[2] ?? process.env.DSH_SOURCE_ROOT
if (!dshRoot) {
  console.error('Specify a DSH checkout: npm run verify:dsh -- <path> or set DSH_SOURCE_ROOT')
  process.exit(2)
}
console.log(`DSH checkout: ${dshRoot}`)

if (!existsSync(dshRoot)) {
  // Absent checkout is not a failure: this script is advisory outside CI.
  console.log('ok   (skipped) no DSH checkout at that path')
  process.exit(0)
}

const dir = protocolDir(dshRoot)
if (dir === undefined) {
  check('locate the typert protocol package', false, 'not found under the DSH checkout')
  process.exit(1)
}
const protocol = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8'))
console.log(`     typert protocol version: ${protocol.version}`)

// 1. Which contract does this DSH expect? Read the type, not a guess.
const typesPath = [
  join(dir, 'src', 'types.ts'),
  join(dir, 'lib', 'types', 'types.d.ts'),
].find(path => existsSync(path))
const typesText = typesPath === undefined ? '' : readFileSync(typesPath, 'utf8')
const wantsCreate = /readonly create: \(\) => TypertSchema/u.test(typesText)
const wantsSchema = /readonly schema: TypertSchema/u.test(typesText)
console.log(`     contract: ${wantsCreate ? 'create() factory' : wantsSchema ? 'schema field' : 'unknown'}`)

// 2. Our descriptors must satisfy it. Import the built contribution and inspect
//    every strict codec exactly as the DSH registry would.
const pluginRoot = fileURLToPath(new URL('..', import.meta.url))
const controllerPath = join(pluginRoot, 'src', 'controller.ts')
const remotePath = join(pluginRoot, 'src', 'client', 'remote.ts')
if (existsSync(controllerPath) && existsSync(remotePath)) {
  const controllerSource = readFileSync(controllerPath, 'utf8')
  const remoteSource = readFileSync(remotePath, 'utf8')
  const exposedMethods = [...controllerSource.matchAll(/@Remote\s+async\s+(\w+)\s*\(/gu)].map(match => match[1])
  const declaredMethods = new Set([...remoteSource.matchAll(/method:\s*'(\w+)'/gu)].map(match => match[1]))
  // previewResource/importResource share a descriptor factory in remote.ts.
  for (const match of remoteSource.matchAll(/\(\['(\w+)',\s*'(\w+)'\]\s+as const\)\.map\(method/gu)) {
    declaredMethods.add(match[1])
    declaredMethods.add(match[2])
  }
  check('every host Remote method has a browser descriptor', exposedMethods.every(method => declaredMethods.has(method)),
    exposedMethods.filter(method => !declaredMethods.has(method)).join(', ') || `${exposedMethods.length} methods`)
} else {
  console.log('skip host/browser source-method comparison (installed package has no src/); checking built codec contract below')
}
const clientBundle = join(pluginRoot, 'lib', 'client.js')
if (!existsSync(clientBundle)) {
  check('built client bundle exists', false, 'run `npm run build` first')
  process.exit(1)
}
const bundleText = readFileSync(clientBundle, 'utf8')
const strictCodecs = (bundleText.match(/mode:\s*"strict"/gu) ?? []).length
const withCreate = (bundleText.match(/create:\s*\(\)\s*=>/gu) ?? []).length
const withSchema = (bundleText.match(/schema:/gu) ?? []).length

check('the bundle carries strict codecs', strictCodecs > 0, `${strictCodecs} found`)
if (wantsCreate) {
  check('every strict codec provides create()', withCreate >= strictCodecs,
    `${withCreate} of ${strictCodecs}`)
}
if (wantsSchema) {
  check('every strict codec provides schema', withSchema >= strictCodecs,
    `${withSchema} of ${strictCodecs}`)
}

// The shipped composition must not retain removed prompt variables or one-shot/Job configuration.
const patchPath = join(pluginRoot, 'cordis.patch.yml')
const patchText = readFileSync(patchPath, 'utf8')
check('preset uses managed directory context and activation configuration', !/\{\{cwd\}\}|backgroundMode:|enableRunInBackground:|toolFilter:/u.test(patchText))
check('preset declares the guarded readonly reviewer', patchText.includes('id: task-engine-review') && patchText.includes('@godv61/dsh-task-engine/reviewer'))
const subagentTypePath = join(dshRoot, 'packages', 'subagent', 'subagent', 'src', 'index.ts')
if (existsSync(subagentTypePath)) check('host exposes managed startActivation', /startActivation\(/u.test(readFileSync(subagentTypePath, 'utf8')))

// Validate public preset subpaths; startActivation alone cannot detect a
// removed plugin export such as tool-subagent-control/list-agents.
const packages = new Map()
function collectPackages(path) {
  if (!existsSync(path)) return
  const manifest = join(path, 'package.json')
  if (existsSync(manifest)) {
    const pkg = JSON.parse(readFileSync(manifest, 'utf8'))
    if (pkg.name?.startsWith('@deepseek-ai/')) packages.set(pkg.name, { pkg, path })
  }
  for (const entry of readdirSync(path, { withFileTypes: true }))
    if (entry.isDirectory() && !['node_modules', 'src', 'lib', 'tests', 'test', '.git'].includes(entry.name)) collectPackages(join(path, entry.name))
}
collectPackages(join(dshRoot, 'packages'))
if (!packages.size) collectPackages(join(dshRoot, 'node_modules', '@deepseek-ai'))
for (const specifier of new Set([...patchText.matchAll(/name:\s*'(@deepseek-ai\/[^']+)'/gu)].map(match => match[1]))) {
  const parts = specifier.split('/'), name = parts.slice(0, 2).join('/'), subpath = parts.slice(2).join('/')
  const host = packages.get(name)?.pkg
  const exported = !subpath || host?.exports?.[`./${subpath}`] !== undefined
  check(`preset public entry ${specifier}`, host !== undefined && exported)
}
const hostTools = packages.get('@deepseek-ai/dsh-tools')
const toolTypes = hostTools && [join(hostTools.path, 'src', 'index.ts'), join(hostTools.path, 'lib', 'types', 'index.d.ts')].find(existsSync)
const api = toolTypes ? readFileSync(toolTypes, 'utf8') : ''
check('host has scoped restrictions and execution guards', /\brestrict\(/u.test(api) && /\bguard\(/u.test(api))
check('host exposes a supported executor API', /\bpresentAs\(/u.test(api) || /\bsetExecutor\(/u.test(api))
if (!/\bpresentAs\(/u.test(api)) check('host ships the public native executor', packages.has('@deepseek-ai/dsh-tool-executor-native'))
if (!/\bpresentAs\(/u.test(api)) for (const file of ['delivery-access', 'reviewer']) {
  const implementation = readFileSync(join(pluginRoot, 'lib', `${file}.js`), 'utf8')
  check(`${file} uses the executor compatibility layer`, !/\.presentAs\(/u.test(implementation))
}
console.log('     Full preset behavior: npm run verify:preset (separate runtime check)')

// 3. The peer range must actually admit the installed DSH version, because npm
//    semver will not match a prerelease the range does not name. Implemented
//    here rather than via the `semver` package: that is a devDependency, so a
//    consumer running this script from the installed tarball has no copy, and
//    the whole point of this check is to run against whatever DSH is present.
const pkg = JSON.parse(readFileSync(join(pluginRoot, 'package.json'), 'utf8'))
for (const [name, range] of Object.entries(pkg.peerDependencies).filter(([name]) => name.startsWith('@deepseek-ai/dsh-'))) {
  check(`${name} peer range admits DSH ${protocol.version}`, rangeAdmits(range, protocol.version), range)
}

/**
 * Whether one of a `||`-joined range's comparators admits `version`.
 *
 * npm semver matches a prerelease only when the comparator names a prerelease
 * on the SAME major.minor.patch, which is why enumerating versions is the only
 * way to cover a DSH alpha. This mirrors that rule for the caret and exact
 * forms the manifest actually uses; it is deliberately conservative, and an
 * unrecognized comparator reports `false` so the check fails loudly rather than
 * passing by accident.
 * @param range - the peer range expression.
 * @param version - the installed DSH version to test.
 * @returns true when the range admits the version.
 */
function rangeAdmits(range, version) {
  const parse = text => {
    const match = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/u.exec(text.trim())
    return match === null
      ? undefined
      : { major: +match[1], minor: +match[2], patch: +match[3], pre: match[4] }
  }
  const target = parse(version)
  if (target === undefined) return false
  for (const part of range.split('||').map(text => text.trim()).filter(Boolean)) {
    const caret = /^\^(.+)$/u.exec(part)
    const lower = parse(caret === null ? part : caret[1])
    if (lower === undefined) continue
    if (caret === null) { if (part === version) return true; continue }
    // Same prerelease tuple, or a plain release on the same caret line.
    const sameTuple = target.major === lower.major
      && target.minor === lower.minor
      && target.patch === lower.patch
    if (lower.pre !== undefined) {
      if (sameTuple) return true
    } else if (target.pre === undefined && target.major === lower.major) {
      if (caret === null ? sameTuple : target.minor >= lower.minor) return true
    }
  }
  return false
}

if (problems.length > 0) {
  console.error(`\n${problems.length} DSH compatibility problem(s)`)
  console.error('Check the failed item: codecs, runtime API and peer version are separate compatibility requirements. Do not widen peers without runtime/preset validation.')
  process.exit(1)
}
console.log('\nDSH compatibility verified')
