/** Correlate successful skill calls with the trusted session log, never model claims. */
import type { EvidenceKind, TaskState, WorkflowConfig } from './engine.ts'
import { skillCommandProblem } from './verification-tests.ts'
import { requiredSkill } from './skill-loading.ts'

export interface SkillSession {
  id?: string
  snapshotEvents(): readonly { type: string; data: unknown }[]
}

/** Return successful loader call ids in the calling session, including task-scoped Codex project loads. */
export function loadedSkills(session?: SkillSession): Map<string, string> {
  const calls = new Map<string, string>()
  const loaded = new Map<string, string>()
  for (const event of session?.snapshotEvents?.() ?? []) {
    if (event.type === 'tool/call') {
      const data = event.data as { name?: string; callId?: string; arguments?: string }
      if ((data.name !== 'skill' && data.name !== 'dev_task') || !data.callId) continue
      try {
        const args = JSON.parse(data.arguments ?? '{}') as { name?: unknown; operation?: unknown; skill_name?: unknown; task_id?: unknown }
        if (data.name === 'skill' && typeof args.name === 'string') calls.set(data.callId, args.name)
        if (data.name === 'dev_task' && args.operation === 'load_skill' && typeof args.skill_name === 'string'
          && typeof args.task_id === 'string')
          calls.set(data.callId, `${args.task_id}#${args.skill_name}`)
      } catch { /* Failed or malformed loader requests are not loading evidence. */ }
    } else if (event.type === 'tool/result') {
      const data = event.data as { error?: unknown; message?: { toolCallId?: string; isError?: boolean; content?: { type?: string; toolCallId?: string; isError?: boolean }[] } }
      if (data.error || data.message?.isError) continue
      // DSH 0.2 stores the call id on the tool message itself. Older session
      // logs carried it on a tool-result content block; accept both shapes.
      const messageCallId = data.message?.toolCallId
      if (messageCallId) {
        const name = calls.get(messageCallId)
        if (name) loaded.set(name, messageCallId)
      }
      for (const block of data.message?.content ?? []) {
        if (block.type !== 'tool-result' || block.isError || !block.toolCallId) continue
        const name = calls.get(block.toolCallId)
        if (name) loaded.set(name, block.toolCallId)
      }
    }
  }
  return loaded
}

/** A real successful load may be reused across stages, but never across task/session identities. */
export function skillLoadForSession(state: TaskState, name: string, session?: SkillSession, inputHash?: string,
  calls = loadedSkills(session)): { stage: string; load: NonNullable<TaskState['skill_loads']>[string][string] } | undefined {
  if (!session?.id || !calls.has(`${state.id}#${name}`)) return undefined
  for (const [stage, loads] of Object.entries(state.skill_loads ?? {})) {
    const load = loads[name]
    if (load?.session_id === session.id && (inputHash === undefined || load.input_hash === inputHash)) return { stage, load }
  }
  return undefined
}

/** Terminal bindings run before entering the terminal state, not after reporting completion. */
export function obligationStages(state: TaskState, workflow: WorkflowConfig): string[] {
  const terminalTargets = workflow.transitions.filter(t => t.from === state.stage
    && !workflow.transitions.some(edge => edge.from === t.to)).map(t => t.to)
  return [...new Set([state.stage, ...terminalTargets])]
}

/**
 * Whether a skill must supply a command receipt, given what it declared.
 *
 * A binding may declare how it proves execution. A requirement or design skill
 * produces a document, and demanding a "real validation command" from it forced an
 * irrelevant command to satisfy a gate — the evidence existed, just in another
 * form. An undeclared evidence type defaults to a command receipt for every
 * skill, regardless of its name.
 * @param name - the bound skill's name.
 * @param evidence - the declared evidence kind, if the binding named one.
 * @returns true when a command receipt is what this binding owes.
 */
export function needsSkillReceipt(_name: string, evidence?: EvidenceKind): boolean {
  if (evidence === 'none' || evidence === 'artifact' || evidence === 'review' || evidence === 'manual') return false
  if (evidence === 'command') return true
  return true
}

/**
 * Whether a skill's declared evidence is present for this stage.
 *
 * Each kind is satisfied by the record that actually carries that proof, so a
 * document-producing skill is checked against a recorded artifact and a judging
 * skill against a review verdict, rather than all of them against a shell receipt.
 * @param kind - the declared evidence kind.
 * @param state - the task state.
 * @param stage - the stage being checked.
 * @param name - the skill name, which keys `skill_results`.
 * @param workflow - the effective workflow, for artifact declarations.
 * @returns the blocker text when the evidence is absent, or an empty array.
 */
function evidenceBlockers(
  kind: EvidenceKind,
  state: TaskState,
  stage: string,
  name: string,
  workflow: WorkflowConfig,
): string[] {
  switch (kind) {
    case 'none':
      return []
    case 'artifact': {
      // Shared stage evidence is complete only when every declared document is present.
      const declared = workflow.artifacts.filter(artifact => artifact.stage === stage)
      if (declared.length === 0) return [`${stage}: "${name}" declares artifact evidence, but the stage has no artifact declaration`]
      const recorded = state.artifacts ?? {}
      const present = declared.every(artifact => artifact.fields.every(field => (recorded[artifact.id]?.[field] ?? '').trim() !== ''))
      return present ? [] : [`${stage}: "${name}" declares artifact evidence, but no artifact is recorded at this stage`]
    }
    case 'review':
      return state.review?.outcome === 'pass'
        ? []
        : [`${stage}: "${name}" declares review evidence, but no passing review is recorded`]
    case 'manual':
      // A human statement is recorded as evidence text on the skill_result; the
      // engine cannot verify the judgement itself, only that it was made explicitly.
      return state.skill_results?.[stage]?.[name]?.approved === true
        ? []
        : [`${stage}: "${name}" declares manual evidence and needs an explicit recorded statement`]
    case 'command':
      return []
  }
}

export function skillBlockers(state: TaskState, workflow: WorkflowConfig, session?: SkillSession): string[] {
  const loaded = loadedSkills(session)
  return obligationStages(state, workflow).flatMap(stage => (workflow.stage_bindings?.[stage]?.skills ?? []).flatMap(entry => {
    if (!requiredSkill(entry)) return []
    // The host skill tool uses a bare name. A Codex project Skill instead uses
    // a task-scoped, source-qualified dev_task load so a same-named Skill or a
    // load for another task cannot satisfy this binding.
    const exact = `${state.id}#${entry.skill.source}:${entry.skill.name}`
    if (state.skill_loads && !skillLoadForSession(state, `${entry.skill.source}:${entry.skill.name}`, session, undefined, loaded))
      return [`${stage}: load skill "${entry.skill.source}:${entry.skill.name}" with dev_task operation=load_skill in this task/session before leaving this stage`]
    const name = state.complexity !== undefined || entry.skill.source === 'codex-project'
      ? `${entry.skill.source}:${entry.skill.name}` : entry.skill.name
    const isLoaded = loaded.has(exact) || (state.complexity === undefined && entry.skill.source !== 'codex-project'
      && loaded.has(entry.skill.name))
    if (!isLoaded) return [`${stage}: load skill "${entry.skill.source}:${entry.skill.name}" with dev_task operation=load_skill before leaving this stage`]
    // A declared non-command kind is checked against its own record rather than
    // falling through to the command requirement, which would demand evidence of a
    // kind this binding never asked for.
    if (entry.evidence !== undefined && entry.evidence !== 'command') {
      return evidenceBlockers(entry.evidence, state, stage, name, workflow)
    }
    if (!needsSkillReceipt(name, entry.evidence)) return []
    const result = state.skill_results?.[stage]?.[name]
    if (!result || !result.receipt || skillCommandProblem(result.receipt.command) || result.receipt.exit_code !== 0 || result.receipt.aborted || result.receipt.timed_out
      || result.receipt.sandbox?.denied || result.receipt.sandbox?.runnerFailed) {
      return [`${stage}: execute "${name}" and record skill_result with skill_name, target_stage, evidence and a real validation command`]
    }
    return []
  }))
}
