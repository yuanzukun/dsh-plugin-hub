/**
 * dsh-superpowers smoke test — runs the real plugin apply() against mock
 * Cordis services and asserts the two integration contracts:
 *   1. the `superpowers` skills provider lists all 14 vendored bundles and
 *      loads frontmatter-stripped bodies with correct resource bases;
 *   2. the bootstrap system-prompt section is registered (or suppressed by
 *      config) with the expected content.
 * Plus a shape check of cordis.patch.yml.
 *
 * Usage: node test/smoke.mjs   (or: npm test)
 */

import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { join } from 'node:path'
import { homedir } from 'node:os'

const ROOT = fileURLToPath(new URL('..', import.meta.url))
const { apply, inject } = await import(new URL('../index.js', import.meta.url))

function mockCtx(config = { bootstrap: true }) {
  const ctx = {
    config,
    providers: [],
    sections: [],
    skills: {
      registerProvider(factory) {
        ctx.providers.push(factory({ signal: new AbortController().signal, invalidate() {} }))
      },
    },
    systemPrompt: {
      section(section) {
        ctx.sections.push(section)
      },
    },
  }
  return ctx
}

let failures = 0
async function check(name, fn) {
  try {
    await fn()
    console.log(`  ok  ${name}`)
  } catch (err) {
    failures++
    console.error(`FAIL  ${name}: ${err.message}`)
  }
}

// ── apply with bootstrap enabled ─────────────────────────────────────────
const ctx = mockCtx()
apply(ctx, { bootstrap: true })

check('registers exactly one provider named superpowers', () => {
  assert.equal(ctx.providers.length, 1)
  assert.equal(ctx.providers[0].name, 'superpowers')
})

const candidates = await ctx.providers[0].list()
check('list() returns 14 candidates', () => {
  assert.equal(candidates.length, 14)
})

check('every candidate is well-formed', () => {
  for (const c of candidates) {
    assert.match(c.name, /^[a-z0-9]+(?:-[a-z0-9]+)*$/, `name ${c.name}`)
    assert.ok(c.description.length > 10, `description for ${c.name}`)
    assert.equal(c.provider, 'superpowers')
    assert.equal(c.source, 'bundled')
    assert.equal(c.rank, 600)
    assert.equal(c.invocation.modelInvocable, true)
    assert.equal(c.invocation.userInvocable, true)
    assert.equal(c.resourceBase.kind, 'directory')
    assert.ok(c.resourceBase.path.endsWith(c.name), `resourceBase path for ${c.name}`)
  }
})

check('expected skill names are present', () => {
  const names = new Set(candidates.map((c) => c.name))
  for (const n of [
    'brainstorming', 'writing-plans', 'executing-plans',
    'subagent-driven-development', 'test-driven-development',
    'systematic-debugging', 'requesting-code-review', 'receiving-code-review',
    'using-git-worktrees', 'dispatching-parallel-agents',
    'verification-before-completion', 'finishing-a-development-branch',
    'writing-skills', 'using-superpowers',
  ]) assert.ok(names.has(n), `missing ${n}`)
})

check('get() loads body without frontmatter', async () => {
  const c = candidates.find((x) => x.name === 'brainstorming')
  const def = await ctx.providers[0].get(c)
  assert.ok(def)
  assert.ok(!def.content.includes('---\nname: brainstorming'), 'frontmatter block leaked into body')
  assert.match(def.content, /^\n*# Brainstorming Ideas Into Designs/)
  assert.match(def.content, /HARD-GATE/)
  assert.equal(def.resourceBase.path, c.resourceBase.path)
})

check('bootstrap section registered with expected content', () => {
  assert.equal(ctx.sections.length, 1)
  const s = ctx.sections[0]
  assert.equal(s.name, 'superpowers')
  assert.equal(s.order, 50)
  assert.ok(s.text.includes('<EXTREMELY_IMPORTANT>'))
  assert.ok(s.text.includes('You have superpowers.'))
  assert.ok(s.text.includes('using-superpowers'))
  assert.ok(s.text.includes('## DeepSeek Harness tool mapping'))
  assert.ok(s.text.includes('`subagent`'))
  assert.ok(s.text.includes('The Rule')) // from using-superpowers body
  assert.ok(!s.text.includes('---\nname: using-superpowers'), 'raw frontmatter leaked into bootstrap')
})

// ── apply with bootstrap disabled ────────────────────────────────────────
const off = mockCtx({ bootstrap: false })
apply(off, { bootstrap: false })
check('bootstrap:false suppresses section but keeps provider', async () => {
  assert.equal(off.sections.length, 0)
  assert.equal(off.providers.length, 1)
  assert.equal((await off.providers[0].list()).length, 14)
})

// ── inject contract (this bit caught the production boot failure) ────────
check('inject declares every service apply() touches', async () => {
  for (const svc of ['skills', 'systemPrompt']) {
    assert.ok(inject.includes(svc), `inject missing "${svc}"`)
  }
  // cordis has no `config` service: config arrives as apply()'s second
  // argument. Declaring it in inject would keep the fiber waiting forever,
  // and reading ctx.config throws "cannot get property ... without inject".
  assert.ok(!inject.includes('config'), 'inject must NOT declare config')
  const src = await readFile(new URL('../index.js', import.meta.url), 'utf8')
  assert.ok(!/ctx\.config/.test(src), 'apply() must not read ctx.config')
})

// ── real Cordis context (enforces the inject proxy) ───────────────────────
// Resolve @deepseek-ai/cordis from the harness installation so apply() runs
// under the same service-resolution proxy as a real profile boot. Skipped
// when no cordis copy is reachable.
async function findCordis() {
  const candidates = [
    join(process.env.DSH_HOME ?? join(homedir(), '.dsh'), 'profiles', 'web', 'node_modules', '@deepseek-ai', 'cordis', 'lib', 'index.js'),
    join(process.env.APPDATA ?? join(homedir(), 'AppData', 'Roaming'), 'npm', 'node_modules', '@deepseek-ai', 'dsh', 'node_modules', '@deepseek-ai', 'cordis', 'lib', 'index.js'),
  ]
  for (const p of candidates) if (existsSync(p)) return p
  return null
}
const cordisPath = await findCordis()
if (cordisPath) {
  const { Context } = await import(pathToFileURL(cordisPath).href)
  const pluginModule = await import(new URL('../index.js', import.meta.url).href)
  const realApply = async (cfg) => {
    const root = new Context()
    const seen = { providers: 0, sections: [] }
    root.provide('skills', { registerProvider() { seen.providers++ } })
    root.provide('systemPrompt', { section(s) { seen.sections.push(s) } })
    await root.plugin(pluginModule, cfg)
    return seen
  }
  check('apply() runs under a real Cordis context with inject enforcement', async () => {
    const seen = await realApply({ bootstrap: true })
    assert.equal(seen.providers, 1)
    assert.equal(seen.sections.length, 1)
  })
  check('real context honors bootstrap:false config', async () => {
    const seen = await realApply({ bootstrap: false })
    assert.equal(seen.providers, 1)
    assert.equal(seen.sections.length, 0)
  })
} else {
  console.log('  ??  real Cordis context check skipped (no @deepseek-ai/cordis found)')
}

// ── cordis.patch.yml shape ───────────────────────────────────────────────
const patch = await readFile(join(ROOT, 'cordis.patch.yml'), 'utf8')
check('cordis.patch.yml names the row correctly', () => {
  assert.match(patch, /- id: superpowers/)
  assert.match(patch, /name: 'dsh-superpowers'/)
  assert.match(patch, /bootstrap: true/)
})

if (failures > 0) {
  console.error(`\n${failures} check(s) failed`)
  process.exit(1)
}
console.log('\nAll checks passed')
