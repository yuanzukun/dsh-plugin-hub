/**
 * dsh-superpowers sync tool — re-vendor skill bundles from obra/superpowers.
 *
 * Downloads the pinned upstream ref as a source tarball (one request, no API
 * rate limits) and mirrors its `skills/` tree into ./skills/, preserving this
 * port's own additions:
 *   - skills/using-superpowers/references/dsh-tools.md (port-owned, untouched)
 *   - the "DeepSeek Harness" row in the Platform Adaptation table of
 *     using-superpowers/SKILL.md (re-added after overwrite)
 *
 * Usage: node scripts/sync.mjs [ref]   (default: UPSTREAM_REF below)
 * Requires `tar` on PATH (Windows 10+ ships bsdtar as tar.exe).
 * Network: uses node fetch (this machine's schannel stack is broken; node's
 * undici TLS works and needs no proxy).
 */

import { mkdir, writeFile, readFile, rm, rmdir, readdir, stat } from 'node:fs/promises'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createWriteStream } from 'node:fs'
import { Readable } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import { gunzipSync } from 'node:zlib'

const ROOT = fileURLToPath(new URL('..', import.meta.url))
const UPSTREAM_REF = 'v6.3.0'
const TARBALL = (ref) =>
  `https://codeload.github.com/obra/superpowers/tar.gz/refs/tags/${ref}`

const DSH_ROW = '- DeepSeek Harness: `references/dsh-tools.md`'
const HERMES_ROW = '- Hermes Agent: `references/hermes-tools.md`'
const PORT_OWNED = new Set(['skills/using-superpowers/references/dsh-tools.md'])

async function download(url, dest) {
  const res = await fetch(url, { redirect: 'follow' })
  if (!res.ok || !res.body) throw new Error(`HTTP ${res.status} for ${url}`)
  await pipeline(Readable.fromWeb(res.body), createWriteStream(dest))
}

/** Minimal ustar reader: gunzip + walk 512-byte records into {name, data}. */
async function untarGz(tgzPath, outDir) {
  const tar = gunzipSync(await readFile(tgzPath))
  const files = []
  let offset = 0
  let longName = null
  let paxPath = null
  while (offset + 512 <= tar.length) {
    const block = tar.subarray(offset, offset + 512)
    if (block.every((b) => b === 0)) break // end-of-archive
    const name = block.subarray(0, 100).toString('utf8').replace(/\0.*$/, '')
    const size = parseInt(block.subarray(124, 136).toString('utf8').replace(/\0.*$/, '').trim(), 8) || 0
    const type = String.fromCharCode(block[156])
    const dataStart = offset + 512
    const data = tar.subarray(dataStart, dataStart + size)
    if (type === 'L') longName = data.toString('utf8').replace(/\0.*$/, '') // GNU longname
    else if (type === 'x') { // pax extended header: extract path= override
      const m = /(?:^|\n)path=([^\n]*)/.exec(data.toString('utf8'))
      if (m) paxPath = m[1]
    } else if (type === 'g') { paxPath = null }
    else if (type === '0' || type === '\0') {
      const finalName = longName ?? paxPath ?? name
      longName = null
      paxPath = null
      files.push({ name: finalName, data: Buffer.from(data) })
    }
    offset = dataStart + Math.ceil(size / 512) * 512
  }
  for (const { name, data } of files) {
    const dest = join(outDir, ...name.split('/'))
    await mkdir(dirname(dest), { recursive: true })
    await writeFile(dest, data)
  }
  return files.map((f) => f.name)
}

async function walk(dir) {
  const out = []
  for (const entry of await readdir(dir)) {
    const full = join(dir, entry)
    if ((await stat(full)).isDirectory()) out.push(...(await walk(full)))
    else out.push(full)
  }
  return out
}

async function main() {
  const ref = process.argv[2] ?? UPSTREAM_REF
  console.log(`Syncing skills from obra/superpowers @ ${ref} ...`)

  const tmp = join(ROOT, '.sync-tmp')
  await rm(tmp, { recursive: true, force: true })
  await mkdir(tmp, { recursive: true })
  const tgz = join(tmp, 'src.tar.gz')
  try {
    await download(TARBALL(ref), tgz)
    console.log('  downloaded source tarball')

    const extracted = join(tmp, 'extracted')
    const all = await untarGz(tgz, extracted)
    const prefix = all.find((n) => n.endsWith('/skills/brainstorming/SKILL.md'))
    if (!prefix) throw new Error('tarball has no skills tree; upstream layout changed')
    const srcSkills = join(extracted, ...prefix.split('/').slice(0, -2))
    const dstSkills = join(ROOT, 'skills')

    // Mirror: drop stale files, then copy the upstream tree verbatim.
    const incoming = (await walk(srcSkills)).map((f) => 'skills/' + f.slice(srcSkills.length + 1).replaceAll('\\', '/'))
    for (const f of await walk(dstSkills)) {
      const rel = 'skills/' + f.slice(dstSkills.length + 1).replaceAll('\\', '/')
      if (!PORT_OWNED.has(rel) && !incoming.includes(rel)) {
        await rm(f)
        console.log(`  removed stale ${rel}`)
      }
    }
    for (const f of incoming) {
      const src = join(srcSkills, ...f.slice('skills/'.length).split('/'))
      const dest = join(ROOT, ...f.split('/'))
      await mkdir(dirname(dest), { recursive: true })
      await writeFile(dest, await readFile(src), 'utf8')
    }
    // Prune directories left empty by the mirror (bottom-up).
    const pruneDirs = async (dir) => {
      for (const entry of await readdir(dir)) {
        const full = join(dir, entry)
        if ((await stat(full)).isDirectory()) {
          await pruneDirs(full)
          if ((await readdir(full)).length === 0) await rmdir(full)
        }
      }
    }
    await pruneDirs(dstSkills)
    console.log(`  mirrored ${incoming.length} files to skills/`)
  } finally {
    await rm(tmp, { recursive: true, force: true })
  }

  // Restore port-owned Platform Adaptation row in using-superpowers/SKILL.md.
  const uspPath = join(ROOT, 'skills', 'using-superpowers', 'SKILL.md')
  const usp = await readFile(uspPath, 'utf8')
  if (!usp.includes(DSH_ROW)) {
    if (!usp.includes(HERMES_ROW)) {
      throw new Error('using-superpowers/SKILL.md no longer has the expected Platform Adaptation table; update DSH_ROW/HERMES_ROW anchors in this script')
    }
    await writeFile(uspPath, usp.replace(HERMES_ROW, `${HERMES_ROW}\n${DSH_ROW}`), 'utf8')
    console.log('  restored DeepSeek Harness Platform Adaptation row')
  } else {
    console.log('  Platform Adaptation row already present')
  }

  console.log('Done. Verify with: npm test')
}

main().catch((err) => {
  console.error('sync failed:', err.message)
  process.exit(1)
})
