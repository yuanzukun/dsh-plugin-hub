# DeepSeek Harness Tool Mapping

Superpowers skills speak in actions ("dispatch a subagent", "create a todo",
"read a file"). On DeepSeek Harness (DSH) these resolve to the tools below.
This mapping is also embedded in every session's system prompt by the
`dsh-superpowers` plugin.

## Tools

| Action skills request | DSH tool |
|---|---|
| Read a file | `read` |
| Create a new file | `write` |
| Edit a file (targeted patch) | `edit` |
| Find files by name | `glob` |
| Search file contents | `grep` |
| Run a shell command | `pwsh` on Windows, `bash` on Linux/macOS (long-running work: `run_in_background: true`, collect with `job_output`, stop with `job_kill`) |
| Run a long remote job (GPU/experiments) | `remlab_exec` / `remlab_experiment_launch` when the project is bound to a remote workspace |
| Invoke a skill | `skill` tool with the skill's bare kebab-case name (e.g. `brainstorming`, not `superpowers:brainstorming`) |
| Dispatch a subagent (isolated context) | `subagent` (background, continuable by default) or `subagent_fork` (inherits this conversation); collect results when the runtime reports them |
| Task tracking | `todo_write` (replace the whole list on every call) |
| Ask the human partner a question | `ask_user_question` |
| Search the web | `web_search` |
| Wait for a condition | poll with a `pwsh`/`bash` sleep loop and a bounded timeout — never busy-poll a background job; wait for its completion notice instead |
| Exit plan mode / present a plan | `exit_plan_mode` (only while plan mode is active) |
| Git operations (worktrees, branches) | `pwsh` running `git ...` (or `bash` on POSIX) |
| Long-running same-session objective | `create_goal` / `get_goal` / `update_goal` |

## Skill addressing

DSH exposes superpowers skills through the skill catalog (the initial
`available_skills` list in the system prompt) and loads bodies with the
`skill` tool. Skills are addressed by bare kebab-case names:
`brainstorming`, `writing-plans`, `executing-plans`,
`subagent-driven-development`, `test-driven-development`,
`systematic-debugging`, `requesting-code-review`, `receiving-code-review`,
`using-git-worktrees`, `dispatching-parallel-agents`,
`verification-before-completion`, `finishing-a-development-branch`,
`writing-skills`, `using-superpowers`.

Relative paths inside a skill body (`references/...`, `scripts/...`) resolve
against that skill's own directory.

## Subagent dispatch

`subagent`/`subagent_fork` accept a complete standalone prompt; they do not
inherit this conversation (`subagent`) or inherit completed turns only
(`subagent_fork`). Follow the skill's prompt-construction instructions, set
`run_in_background: true` for parallel dispatch (the default), and collect
results when the completion notice arrives. Use `send_message` for follow-ups
to the same child, `list_agents` to recall children, `interrupt_agent` to stop
a child's current turn.

## Shell environment

DSH sessions run on the local machine; the shell tools honor the sandbox
policy. Superpowers skills that expect a POSIX shell (a few helper scripts
under `skills/*/scripts/`) are best run on Linux/macOS, a remote workspace
bound through the remote-lab plugin, or translated to `pwsh` — when a script
cannot run, follow the skill's own inline fallback instead of blocking.

## Plan mode

DSH has a plan mode: while it is active, no mutating action is allowed and
plans are presented through `exit_plan_mode`. `using-superpowers` says to
invoke `brainstorming` before entering plan mode — honor that, and treat plan
mode as the mechanism `writing-plans`/`executing-plans` describe when they
speak of written plans and implementation checkpoints.

## Instructions files

When a skill mentions "your instructions file", on DSH the equivalents are the
agent preset's persona/prompt sections and project-level instructions the
session was started with; there is no user-editable global instructions file
to write to.
