/**
 * dsh-superpowers — DeepSeek Harness port of obra/superpowers.
 *
 * Host-only bundle plugin. Follows the harness's bundled-skill pattern
 * (@deepseek-ai/dsh-skill-badge): a `skills` provider serving the vendored
 * `skills/` tree, plus a global system-prompt section that injects the
 * using-superpowers bootstrap at the start of every session — the entire
 * integration superpowers requires (skills + tool mapping + bootstrap).
 *
 * It publishes no services and only consumes host-plane registries
 * (`skills`, `systemPrompt`), so the bundle row needs no isolate realm.
 *
 * Config (bundle row): { bootstrap: false } disables the system-prompt
 * injection while keeping the skills provider.
 */

import { readFile, readdir } from 'node:fs/promises'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { join } from 'node:path'

export const name = 'superpowers'
export const inject = ['skills', 'systemPrompt']

// Rank constant from @deepseek-ai/dsh-skill (BUNDLED_SKILL_RANK = 600):
// project (100/200) and user (400/500) skills shadow bundled ones, runtime
// skills (250) shadow us. Hardcoded to avoid a runtime dependency on the
// registry package.
const BUNDLED_SKILL_RANK = 600
const PROVIDER_NAME = 'superpowers'

const SKILLS_DIR = fileURLToPath(new URL('./skills/', import.meta.url))

const KEBAB = /^[a-z0-9]+(?:-[a-z0-9]+)*$/

/**
 * Parse the two-field frontmatter of a vendored SKILL.md. Upstream skills
 * carry only `name` and `description` (single- or multi-line quoted scalars);
 * the optional `whenToUse` and invocation fields are parsed when present.
 * Unknown fields are ignored. Returns null when the block is missing or
 * malformed, so the caller can skip loudly instead of guessing.
 */
function parseFrontmatter(text) {
  const match = /^\uFEFF?---\r?\n([\s\S]*?)\r?\n---\r?\n?/.exec(text)
  if (!match) return null
  const fm = match[1]
  const nameMatch = /^name:\s*(.+?)\s*$/m.exec(fm)
  if (!nameMatch) return null
  const name = unquote(nameMatch[1])
  if (!KEBAB.test(name)) return null

  const descMatch = /^description:\s*(.*)$/m.exec(fm)
  let description = ''
  if (descMatch) description = unquoteMultiline(fm, descMatch[1], descMatch.index)
  if (!description.trim()) return null

  const scalar = (key) => {
    const m = new RegExp(`^${key}:\\s*(true|false|yes|no|on|off|1|0)\\s*$`, 'im').exec(fm)
    return m ? /^(true|yes|on|1)$/i.test(m[1]) : undefined
  }
  const whenToUseMatch = /^whenToUse:\s*(.*)$/m.exec(fm)
  const whenToUse = whenToUseMatch ? unquoteMultiline(fm, whenToUseMatch[1], whenToUseMatch.index) : undefined
  const modelOff = scalar('disable-model-invocation')
  const userOff = scalar('user-invocable')

  return {
    name,
    description,
    whenToUse,
    invocation: {
      modelInvocable: modelOff !== true,
      userInvocable: userOff !== false,
    },
  }
}

function unquote(value) {
  const v = value.trim()
  if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
    return v.slice(1, -1)
  }
  return v
}

/** Unquote a scalar that may wrap across following frontmatter lines. */
function unquoteMultiline(fm, firstLine, firstIndex) {
  const head = firstLine.trim()
  const quote = head[0]
  if (quote !== '"' && quote !== "'") return head
  if (head.length > 1 && head.endsWith(quote)) return head.slice(1, -1)
  const rest = fm.slice(firstIndex)
  const close = rest.indexOf(quote, rest.indexOf('\n'))
  if (close === -1) return head.slice(1)
  return (head.slice(1) + '\n' + rest.slice(rest.indexOf('\n') + 1, close)).trim()
}

function stripFrontmatter(text) {
  const match = /^\uFEFF?---\r?\n[\s\S]*?\r?\n---\r?\n?/.exec(text)
  return match ? text.slice(match[0].length) : text
}

const bootstrap = {
  name: 'superpowers',
  order: 50, // after persona (0), before tool guidance (100)
  text: '',
}

export function apply(ctx, config) {
  const log = (line) => console.log(`dsh-superpowers: ${line}`)

  // ── skills provider ────────────────────────────────────────────────────
  const provider = {
    name: PROVIDER_NAME,
    async list() {
      let entries
      try {
        entries = await readdir(SKILLS_DIR)
      } catch (err) {
        log(`skills dir unreadable (${err.code ?? err.message}); provider empty`)
        return { candidates: [], complete: false }
      }
      const candidates = []
      for (const entry of entries) {
        const skillDir = join(SKILLS_DIR, entry)
        const file = join(skillDir, 'SKILL.md')
        let raw
        try {
          raw = await readFile(file, 'utf8')
        } catch {
          continue // not a skill bundle
        }
        const meta = parseFrontmatter(raw)
        if (!meta) {
          log(`skipping ${entry}: missing or malformed frontmatter`)
          continue
        }
        candidates.push({
          name: meta.name,
          description: meta.description,
          whenToUse: meta.whenToUse,
          invocation: meta.invocation,
          provider: PROVIDER_NAME,
          source: 'bundled',
          resourceBase: { kind: 'directory', path: skillDir },
          rank: BUNDLED_SKILL_RANK,
          locator: { file, dir: skillDir },
          path: file,
        })
      }
      return candidates
    },
    async get(candidate) {
      let raw
      try {
        raw = await readFile(candidate.path, 'utf8')
      } catch {
        return undefined
      }
      const meta = parseFrontmatter(raw)
      if (!meta || meta.name !== candidate.name) return undefined
      return {
        name: meta.name,
        description: meta.description,
        whenToUse: meta.whenToUse,
        invocation: meta.invocation,
        provider: PROVIDER_NAME,
        source: 'bundled',
        resourceBase: candidate.resourceBase,
        path: candidate.path,
        content: stripFrontmatter(raw),
      }
    },
  }
  ctx.skills.registerProvider(() => provider)
  log(`registered provider "${PROVIDER_NAME}" for ${SKILLS_DIR}`)

  // ── session-start bootstrap (system-prompt section) ───────────────────
  // Cordis delivers the row config as apply()'s second argument; there is no
  // `config` service to inject, and declaring `inject: ['config']` would keep
  // the fiber waiting forever.
  if (config?.bootstrap === false) {
    log('bootstrap disabled by bundle config')
    return
  }

  let uspBody = ''
  let toolsBody = ''
  try {
    uspBody = stripFrontmatter(readFileSync(join(SKILLS_DIR, 'using-superpowers', 'SKILL.md'), 'utf8'))
  } catch (err) {
    log(`using-superpowers missing (${err.code ?? err.message}); bootstrap degraded`)
  }
  try {
    toolsBody = readFileSync(join(SKILLS_DIR, 'using-superpowers', 'references', 'dsh-tools.md'), 'utf8')
  } catch (err) {
    log(`dsh-tools.md missing (${err.code ?? err.message}); bootstrap degraded`)
  }

  bootstrap.text = [
    '<EXTREMELY_IMPORTANT>',
    'You have superpowers.',
    '',
    "**Below is the full content of your 'using-superpowers' skill — your introduction to using skills. For all other skills, invoke the 'skill' tool with the skill's bare kebab-case name:**",
    '',
    uspBody,
    '## DeepSeek Harness tool mapping',
    '',
    toolsBody,
    '</EXTREMELY_IMPORTANT>',
  ].join('\n')

  ctx.systemPrompt.section(bootstrap)
  log('bootstrap system-prompt section registered')
}
