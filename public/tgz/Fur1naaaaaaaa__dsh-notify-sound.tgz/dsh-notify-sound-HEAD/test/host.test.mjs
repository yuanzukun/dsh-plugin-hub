/**
 * 主机侧半边的单元测试：用假的 ctx / req / res 驱动插件，不依赖真实 DSH 运行时。
 *
 * 跑法（仓库根目录）：
 *   node --test test/
 * 或用 DSH 自带 node：
 *   "<DSH>/dependencies/node/bin/node.exe" --test test/
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import test from 'node:test'

import { apply, inject, name, normalizeConfig } from '../lib/index.js'

/**
 * 测试隔离：把 DSH_HOME 指到一个空目录。
 * 否则测试会读到用户真实的 ~/.dsh/dsh-notify-sound.json，
 * 而设置页写过的配置会（按设计）盖过测试里传的条目 config。
 */
const TEST_HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-notify-test-home-'))
process.env.DSH_HOME = TEST_HOME
process.on('exit', () => {
  try {
    fs.rmSync(TEST_HOME, { recursive: true, force: true })
  } catch { /* 忽略 */ }
})

/**
 * 造一个假的插件上下文，把监听器/路由/index tap 都摊开给测试看。
 * @returns {{ ctx, listeners, routes, taps, logs, disposeAll }}
 */
function makeCtx() {
  const listeners = new Map()
  const routes = new Map()
  const taps = []
  const logs = []
  const disposers = []
  const ctx = {
    logger: {
      info: (message) => logs.push(['info', message]),
      warn: (message) => logs.push(['warn', message]),
      error: (message) => logs.push(['error', message]),
    },
    on(event, listener) {
      const list = listeners.get(event) || []
      list.push(listener)
      listeners.set(event, list)
      const dispose = () => {
        const current = listeners.get(event) || []
        listeners.set(event, current.filter((item) => item !== listener))
      }
      disposers.push(dispose)
      return dispose
    },
    effect(callback) {
      const dispose = callback()
      if (typeof dispose === 'function') disposers.push(dispose)
      return dispose
    },
    webServer: {
      register(route) {
        if (routes.has(route.path)) throw new Error(`duplicate route ${route.path}`)
        routes.set(route.path, route)
        const dispose = () => routes.delete(route.path)
        disposers.push(dispose)
        return dispose
      },
      tapIndex(transform) {
        taps.push(transform)
        const dispose = () => {
          const index = taps.indexOf(transform)
          if (index !== -1) taps.splice(index, 1)
        }
        disposers.push(dispose)
        return dispose
      },
    },
  }
  return {
    ctx,
    listeners,
    routes,
    taps,
    logs,
    disposeAll: () => {
      for (const dispose of disposers.slice().reverse()) {
        try { dispose() } catch { /* 忽略 */ }
      }
    },
  }
}

/**
 * 触发某个事件的所有监听器。
 * @param listeners - makeCtx 返回的监听器表。
 * @param event - 事件名。
 * @param args - 事件参数。
 * @returns 监听器返回值数组。
 */
function emit(listeners, event, ...args) {
  const list = listeners.get(event) || []
  return list.map((listener) => listener(...args))
}

/**
 * 触发 waterfall 事件：自动补一个 next。
 * @param listeners - 监听器表。
 * @param event - 事件名。
 * @param args - 除 next 外的事件参数。
 * @returns { calls, nextCalls }
 */
function emitWaterfall(listeners, event, ...args) {
  let nextCalls = 0
  const next = () => {
    nextCalls += 1
    return Promise.resolve({ claimed: false })
  }
  const results = emit(listeners, event, ...args, next)
  return { results, nextCalls }
}

/**
 * 造一个假的 ServerResponse。
 * @returns 带 status/headers/body 的记录对象。
 */
function makeRes() {
  return {
    status: 0,
    headers: null,
    body: '',
    closed: false,
    writeHead(status, headers) {
      this.status = status
      this.headers = headers || null
      return this
    },
    write(chunk) {
      this.body += String(chunk)
      return true
    },
    end(chunk) {
      if (chunk !== undefined && chunk !== null) this.body += String(chunk)
      this.closed = true
      return this
    },
    flushHeaders() {},
    on() { return this },
  }
}

/**
 * 造一个假的 IncomingMessage（只需要 url / on）。
 * @param url - 请求 URL。
 * @returns 假请求对象。
 */
function makeReq(url) {
  return { url, on() { return this } }
}

/**
 * 调一个已注册的路由。
 * @param routes - 路由表。
 * @param routePath - 路径。
 * @param url - 请求 URL（含查询串）。
 * @returns 响应记录对象。
 */
async function callRoute(routes, routePath, url) {
  const route = routes.get(routePath)
  assert.ok(route, `路由未注册：${routePath}`)
  const res = makeRes()
  await route.handler(makeReq(url === undefined ? routePath : url), res)
  return res
}

/**
 * 调一个带请求体的路由（POST）。
 * @param routes - 路由表。
 * @param routePath - 路径。
 * @param method - HTTP 方法。
 * @param payload - 任意可序列化对象（或直接给字符串）。
 * @returns 响应记录对象。
 */
async function callRouteWithBody(routes, routePath, method, payload) {
  const route = routes.get(routePath)
  assert.ok(route, `路由未注册：${routePath}`)
  const listeners = new Map()
  const req = {
    method,
    url: routePath,
    headers: {},
    on(event, listener) {
      const list = listeners.get(event) || []
      list.push(listener)
      listeners.set(event, list)
      return this
    },
  }
  const res = makeRes()
  const pending = route.handler(req, res)
  const text = typeof payload === 'string' ? payload : JSON.stringify(payload)
  for (const listener of listeners.get('data') || []) listener(text)
  for (const listener of listeners.get('end') || []) listener()
  await pending
  return res
}

/**
 * 解析 JSON 响应体。
 * @param res - 响应记录对象。
 * @returns 解析结果。
 */
function body(res) {
  return JSON.parse(res.body)
}

/** 一个会话对象（session/event 的第一个参数）。 */
const session = (id) => ({ id })

test('导出 name / inject，apply 会注册路由、index tap 与全部监听器', () => {
  const { ctx, listeners, routes, taps } = makeCtx()
  assert.equal(name, 'dsh-notify-sound')
  assert.deepEqual(inject, ['webServer'])

  apply(ctx, {})

  assert.deepEqual(
    [...routes.keys()].sort(),
    [
      '/dsh-notify/ack',
      '/dsh-notify/client.js',
      '/dsh-notify/config',
      '/dsh-notify/config.json',
      '/dsh-notify/events',
      '/dsh-notify/ping',
      '/dsh-notify/stream',
      '/dsh-notify/test',
      '/dsh-notify/ui-report',
    ].sort(),
  )
  assert.equal(taps.length, 1)
  for (const event of ['session/event', 'approval/request', 'user-questions/request', 'subagent/start', 'subagent/end']) {
    assert.equal((listeners.get(event) || []).length, 1, `缺少监听器：${event}`)
  }
})

test('一轮对话正常结束 -> 产生 turn-end 通知', async () => {
  const { ctx, listeners, routes } = makeCtx()
  apply(ctx, {})

  emit(listeners, 'session/event', session('s1'), { type: 'turn/end', seq: 9, time: 1, data: { turn: 2, reason: { kind: 'completed' } } })

  const payload = body(await callRoute(routes, '/dsh-notify/events', '/dsh-notify/events?after=0'))
  assert.equal(payload.ok, true)
  assert.equal(payload.now, 1)
  assert.equal(payload.events.length, 1)
  assert.equal(payload.events[0].type, 'turn-end')
  assert.equal(payload.events[0].reason, 'completed')
  assert.equal(payload.events[0].reasonText, '正常完成')
  assert.equal(payload.events[0].sessionId, 's1')
  assert.equal(payload.events[0].turn, 2)
})

test('用户主动中断 / 其它事件不会响', async () => {
  const { ctx, listeners, routes } = makeCtx()
  apply(ctx, {})

  emit(listeners, 'session/event', session('s1'), { type: 'turn/end', data: { reason: { kind: 'aborted', reason: { kind: 'user' } } } })
  emit(listeners, 'session/event', session('s1'), { type: 'turn/end', data: { reason: { kind: 'interrupted' } } })
  emit(listeners, 'session/event', session('s1'), { type: 'turn/start', data: { turn: 3 } })
  emit(listeners, 'session/event', session('s1'), { type: 'assistant/message', data: { turn: 3 } })

  const payload = body(await callRoute(routes, '/dsh-notify/events', '/dsh-notify/events?after=0'))
  assert.deepEqual(payload.events, [])
  assert.equal(payload.now, 0)
})

test('出错结束也会响（用 error 提示音）', async () => {
  const { ctx, listeners, routes } = makeCtx()
  apply(ctx, {})

  emit(listeners, 'session/event', session('s1'), { type: 'turn/end', data: { reason: { kind: 'error', error: { message: 'boom' } } } })

  const payload = body(await callRoute(routes, '/dsh-notify/events', '/dsh-notify/events?after=0'))
  assert.equal(payload.events.length, 1)
  assert.equal(payload.events[0].reason, 'error')
  assert.equal(payload.events[0].reasonText, '执行出错')
})

test('子代理子会话的轮次结束被忽略（skipSubagents）', async () => {
  const { ctx, listeners, routes } = makeCtx()
  apply(ctx, {})

  emit(listeners, 'subagent/start', { runId: 'r1', provider: 'subagent', id: 'child-1', local: true })
  emit(listeners, 'session/event', session('child-1'), { type: 'turn/end', data: { reason: { kind: 'completed' } } })
  emit(listeners, 'session/event', session('parent-1'), { type: 'turn/end', data: { reason: { kind: 'completed' } } })

  const payload = body(await callRoute(routes, '/dsh-notify/events', '/dsh-notify/events?after=0'))
  assert.equal(payload.events.length, 1)
  assert.equal(payload.events[0].sessionId, 'parent-1')

  // 关掉过滤：子会话也要响
  const { ctx: ctx2, listeners: listeners2, routes: routes2 } = makeCtx()
  apply(ctx2, { skipSubagents: false })
  emit(listeners2, 'subagent/start', { id: 'child-2' })
  emit(listeners2, 'session/event', session('child-2'), { type: 'turn/end', data: { reason: { kind: 'completed' } } })
  const payload2 = body(await callRoute(routes2, '/dsh-notify/events', '/dsh-notify/events?after=0'))
  assert.equal(payload2.events.length, 1)
  assert.equal(payload2.events[0].sessionId, 'child-2')
})

test('approval/request：通知 + 必须把请求交还给后续应答者', async () => {
  const { ctx, listeners, routes } = makeCtx()
  apply(ctx, {})

  const { results, nextCalls } = emitWaterfall(listeners, 'approval/request', {
    agent: { id: 's1' },
    toolName: 'bash',
    reason: '需要执行命令',
    displayReason: { en: 'run a command', zh: '需要执行命令' },
  })
  assert.equal(nextCalls, 1, 'waterfall 监听器必须调用 next()')
  assert.ok(results[0] && typeof results[0].then === 'function', '应该返回 next() 的 Promise')

  const payload = body(await callRoute(routes, '/dsh-notify/events', '/dsh-notify/events?after=0'))
  assert.equal(payload.events.length, 1)
  assert.equal(payload.events[0].type, 'approval')
  assert.equal(payload.events[0].toolName, 'bash')
  assert.equal(payload.events[0].text, '需要执行命令')
  assert.equal(payload.events[0].sessionId, 's1')
})

test('user-questions/request：普通提问与计划确认都能识别', async () => {
  const { ctx, listeners, routes } = makeCtx()
  apply(ctx, {})

  const first = emitWaterfall(listeners, 'user-questions/request', {
    agent: { id: 's1' },
    questions: [{ id: 'q1', header: '数据库', question: '用哪个数据库？' }],
  })
  assert.equal(first.nextCalls, 1)
  const second = emitWaterfall(listeners, 'user-questions/request', {
    agent: { id: 's1' },
    questions: [{ id: 'q2', question: '批准这个计划吗？', intent: { kind: 'plan-review', approve: '开始' } }],
  })
  assert.equal(second.nextCalls, 1)

  const payload = body(await callRoute(routes, '/dsh-notify/events', '/dsh-notify/events?after=0'))
  assert.equal(payload.events.length, 2)
  assert.equal(payload.events[0].type, 'question')
  assert.equal(payload.events[0].planReview, false)
  assert.equal(payload.events[0].header, '数据库')
  assert.equal(payload.events[0].text, '用哪个数据库？')
  assert.equal(payload.events[1].planReview, true)
})

test('/events：不带 after 不回放历史，带 after 只回增量', async () => {
  const { ctx, listeners, routes } = makeCtx()
  apply(ctx, {})

  emit(listeners, 'session/event', session('s1'), { type: 'turn/end', data: { reason: { kind: 'completed' } } })
  emit(listeners, 'session/event', session('s1'), { type: 'turn/end', data: { reason: { kind: 'completed' } } })

  const noAfter = body(await callRoute(routes, '/dsh-notify/events', '/dsh-notify/events'))
  assert.equal(noAfter.now, 2)
  assert.deepEqual(noAfter.events, [])

  const afterOne = body(await callRoute(routes, '/dsh-notify/events', '/dsh-notify/events?after=1'))
  assert.equal(afterOne.events.length, 1)
  assert.equal(afterOne.events[0].seq, 2)

  const afterAll = body(await callRoute(routes, '/dsh-notify/events', '/dsh-notify/events?after=2'))
  assert.deepEqual(afterAll.events, [])

  const invalid = await callRoute(routes, '/dsh-notify/events', '/dsh-notify/events?after=abc')
  assert.equal(invalid.status, 400)
  assert.equal(body(invalid).ok, false)
})

test('配置优先级：条目 config 是默认值，$DSH_HOME/dsh-notify-sound.json 覆盖它', async () => {
  const { ctx, routes } = makeCtx()
  apply(ctx, { volume: 0.3 })

  // 还没有配置文件时，用条目 config
  const base = body(await callRoute(routes, '/dsh-notify/config.json'))
  assert.equal(base.ok, true)
  assert.equal(base.config.volume, 0.3, '没有配置文件时用条目 config')
  assert.equal(base.config.pollMs, 700)
  assert.equal(typeof base.seq, 'number')

  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-notify-home-'))
  const previous = process.env.DSH_HOME
  try {
    process.env.DSH_HOME = home
    fs.writeFileSync(path.join(home, 'dsh-notify-sound.json'), JSON.stringify({ volume: 0.9, turnEnd: false, toast: 'always' }))
    const overridden = body(await callRoute(routes, '/dsh-notify/config.json'))
    // 设置页写的就是这个文件，所以它必须压得住条目 config，否则界面上改了不生效
    assert.equal(overridden.config.volume, 0.9, '配置文件应覆盖条目 config')
    assert.equal(overridden.config.turnEnd, false)
    assert.equal(overridden.config.toast, 'always')
    assert.equal(overridden.config.approval, true, '文件里没写的字段仍回落默认值')
  } finally {
    if (previous === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = previous
    fs.rmSync(home, { recursive: true, force: true })
  }
})

test('/events 与 /config.json 都带 bootId，主机换代时可被前端识别', async () => {
  const { ctx, listeners, routes } = makeCtx()
  apply(ctx, {})

  const config = body(await callRoute(routes, '/dsh-notify/config.json'))
  assert.equal(typeof config.bootId, 'string')
  assert.ok(config.bootId.length > 0)

  const events = body(await callRoute(routes, '/dsh-notify/events', '/dsh-notify/events?after=0'))
  assert.equal(events.bootId, config.bootId, '同一次挂载内 bootId 必须一致')

  const ping = body(await callRoute(routes, '/dsh-notify/ping'))
  assert.equal(ping.bootId, config.bootId)

  // 重新挂载（真实场景是插件被重新 import 了一遍）= 新的一代
  const fresh = await import(`../lib/index.js?boot=${Date.now()}`)
  const reloaded = makeCtx()
  fresh.apply(reloaded.ctx, {})
  const nextConfig = body(await callRoute(reloaded.routes, '/dsh-notify/config.json'))
  assert.notEqual(nextConfig.bootId, config.bootId, '新一轮挂载应产生新的 bootId')

  emit(listeners, 'session/event', session('s1'), { type: 'turn/end', data: { reason: { kind: 'completed' } } })
  assert.equal(body(await callRoute(routes, '/dsh-notify/events', '/dsh-notify/events?after=0')).events.length, 1)
})

test('POST /config：设置页写配置，落到 $DSH_HOME/dsh-notify-sound.json 并做归一化', async () => {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-notify-write-'))
  const previous = process.env.DSH_HOME
  process.env.DSH_HOME = home
  try {
    const { ctx, routes } = makeCtx()
    apply(ctx, {})

    // 写音量 + 两个开关；volume 故意给超范围、再塞一个不该被写入的键
    const saved = body(await callRouteWithBody(routes, '/dsh-notify/config', 'POST', {
      volume: 5,
      turnEnd: false,
      onlyWhenHidden: true,
      bogusKey: '不该落盘',
    }))
    assert.equal(saved.ok, true)

    const file = path.join(home, 'dsh-notify-sound.json')
    assert.equal(saved.file, file)
    const written = JSON.parse(fs.readFileSync(file, 'utf8'))
    assert.equal(written.volume, 1, '越界音量应被裁剪到 1')
    assert.equal(written.turnEnd, false)
    assert.equal(written.onlyWhenHidden, true)
    assert.equal(written.bogusKey, undefined, '白名单之外的键不写文件')
    assert.equal(written.approval, true, '其余字段写默认值，配置文件本身就是一份说明')

    // 再写一次：只改一个字段，之前写进去的其它字段要保住
    await callRouteWithBody(routes, '/dsh-notify/config', 'POST', { volume: 0.25 })
    const second = JSON.parse(fs.readFileSync(file, 'utf8'))
    assert.equal(second.volume, 0.25)
    assert.equal(second.turnEnd, false, '未提交的字段应保留')

    // 读回来的有效配置与文件一致
    const effective = body(await callRoute(routes, '/dsh-notify/config.json'))
    assert.equal(effective.config.volume, 0.25)
    assert.equal(effective.config.turnEnd, false)

    // 坏请求体 / 错方法
    const bad = await callRouteWithBody(routes, '/dsh-notify/config', 'POST', '不是 JSON')
    assert.equal(bad.status, 400)
    const wrongMethod = await callRoute(routes, '/dsh-notify/config', '/dsh-notify/config')
    assert.equal(wrongMethod.status, 405)
  } finally {
    if (previous === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = previous
    fs.rmSync(home, { recursive: true, force: true })
  }
})

test('POST /ui-report：设置页挂载状态能在 /ping 的 ui 里看到（按来源分开记）', async () => {
  const { ctx, routes } = makeCtx()
  apply(ctx, {})

  await callRouteWithBody(routes, '/dsh-notify/ui-report', 'POST', {
    source: 'module',
    mounted: true,
    tabRegistered: true,
    detail: { base: '/dsh-notify' },
  })
  await callRouteWithBody(routes, '/dsh-notify/ui-report', 'POST', {
    source: 'script',
    mounted: true,
    tabRegistered: false,
    detail: { version: '0.1.0', transport: 'sse' },
  })

  const ping = body(await callRoute(routes, '/dsh-notify/ping'))
  assert.equal(ping.ui.module.tabRegistered, true)
  assert.equal(ping.ui.module.mounted, true)
  assert.equal(ping.ui.script.mounted, true)
  assert.equal(ping.ui.script.detail.transport, 'sse')

  // 报错也要留痕
  await callRouteWithBody(routes, '/dsh-notify/ui-report', 'POST', {
    source: 'module',
    mounted: true,
    tabRegistered: false,
    error: 'require is not a function',
  })
  const after = body(await callRoute(routes, '/dsh-notify/ping'))
  assert.equal(after.ui.module.tabRegistered, false)
  assert.equal(after.ui.module.error, 'require is not a function')
})

test('normalizeConfig：坏值一律回落默认值', () => {
  const cfg = normalizeConfig({ volume: '大声', pollMs: 1, turnEndReasons: ['nonsense'], toast: 'loud' })
  assert.equal(cfg.volume, 0.5)
  assert.equal(cfg.pollMs, 200)
  assert.deepEqual(cfg.turnEndReasons, ['completed', 'error', 'blocked', 'max-tokens'])
  assert.equal(cfg.toast, 'auto')
})

test('/dsh-notify/client.js 返回浏览器脚本本体', async () => {
  const { ctx, routes } = makeCtx()
  apply(ctx, {})

  const res = await callRoute(routes, '/dsh-notify/client.js')
  assert.equal(res.status, 200)
  assert.match(String(res.headers['Content-Type']), /javascript/)
  assert.match(res.body, /__dshNotifySoundInstalled/)
  assert.match(res.body, /dshNotifySound/)
})

test('index tap 会往 </body> 前注入脚本标签，且不会重复注入', () => {
  const { ctx, taps } = makeCtx()
  apply(ctx, {})
  const html = '<!doctype html><html><body><div id="app"></div></body></html>'

  const once = taps[0](html)
  assert.match(once, /<script defer src="\/dsh-notify\/client\.js" data-dsh-notify-base="\/dsh-notify"><\/script><\/body>/)

  const twice = taps[0](once)
  assert.equal(twice, once)
  assert.equal(twice.match(/\/dsh-notify\/client\.js/g).length, 1)
})

test('没有 </body> 时脚本仍然会被注入', () => {
  const { ctx, taps } = makeCtx()
  apply(ctx, {})
  const html = '<!doctype html><div id="app"></div>'
  const out = taps[0](html)
  assert.ok(out.startsWith(html))
  assert.match(out, /<script defer src="\/dsh-notify\/client\.js"/)
})

test('/stream：先发 hello，之后新通知即时推送', async () => {
  const { ctx, listeners, routes } = makeCtx()
  apply(ctx, {})

  const route = routes.get('/dsh-notify/stream')
  const res = makeRes()
  await route.handler(makeReq('/dsh-notify/stream'), res)
  assert.equal(res.status, 200)
  assert.match(String(res.headers['Content-Type']), /text\/event-stream/)
  assert.match(res.body, /"type":"hello"/)

  emit(listeners, 'session/event', session('s1'), { type: 'turn/end', data: { reason: { kind: 'completed' } } })
  assert.match(res.body, /"type":"turn-end"/)
  assert.match(res.body, /"seq":1/)
})

test('/test 可以手动推一条通知试听（默认 turn-end，可指定类型）', async () => {
  const { ctx, routes } = makeCtx()
  apply(ctx, {})

  const first = body(await callRoute(routes, '/dsh-notify/test', '/dsh-notify/test'))
  assert.equal(first.ok, true)
  assert.equal(first.pushed, 'turn-end')

  const second = body(await callRoute(routes, '/dsh-notify/test', '/dsh-notify/test?type=approval'))
  assert.equal(second.pushed, 'approval')

  const third = body(await callRoute(routes, '/dsh-notify/test', '/dsh-notify/test?type=question&plan=1'))
  assert.equal(third.pushed, 'question')

  // 第四种音效：异常结束（内部仍是一条 reason=error 的 turn-end）
  const errorCue = body(await callRoute(routes, '/dsh-notify/test', '/dsh-notify/test?type=error'))
  assert.equal(errorCue.pushed, 'error')

  // 非法类型回落到 turn-end
  const fourth = body(await callRoute(routes, '/dsh-notify/test', '/dsh-notify/test?type=乱写'))
  assert.equal(fourth.pushed, 'turn-end')

  const payload = body(await callRoute(routes, '/dsh-notify/events', '/dsh-notify/events?after=0'))
  assert.equal(payload.events.length, 5)
  assert.equal(payload.events[2].planReview, true)
  assert.equal(payload.events[0].test, true)
  assert.equal(payload.events[3].type, 'turn-end')
  assert.equal(payload.events[3].reason, 'error')
})

test('/ack 记录浏览器回执，并出现在 /ping 里', async () => {
  const { ctx, routes } = makeCtx()
  apply(ctx, {})

  const route = routes.get('/dsh-notify/ack')
  const res = makeRes()
  const listeners = new Map()
  const req = {
    method: 'POST',
    url: '/dsh-notify/ack',
    headers: { 'user-agent': 'unit-test-agent' },
    on(event, listener) {
      const list = listeners.get(event) || []
      list.push(listener)
      listeners.set(event, list)
      return this
    },
  }
  const pending = route.handler(req, res)
  for (const listener of listeners.get('data') || []) listener('{"seq":3,"type":"approval","played":true,"blocked":false,"outcome":"played","transport":"sse"}')
  for (const listener of listeners.get('end') || []) listener()
  await pending

  assert.equal(res.status, 200)
  const ping = body(await callRoute(routes, '/dsh-notify/ping'))
  assert.equal(ping.lastAck.seq, 3)
  assert.equal(ping.lastAck.type, 'approval')
  assert.equal(ping.lastAck.outcome, 'played')
  assert.equal(ping.lastAck.played, true)
  assert.equal(ping.lastAck.ua, 'unit-test-agent')

  // GET 不被接受
  const rejected = await callRoute(routes, '/dsh-notify/ack', '/dsh-notify/ack')
  assert.equal(rejected.status, 405)
})

test('/ping 汇总状态；卸载后路由被归还', async () => {
  const { ctx, listeners, routes, disposeAll } = makeCtx()
  apply(ctx, {})
  emit(listeners, 'session/event', session('s1'), { type: 'turn/end', data: { reason: { kind: 'completed' } } })

  const ping = body(await callRoute(routes, '/dsh-notify/ping'))
  assert.equal(ping.ok, true)
  assert.equal(ping.name, 'dsh-notify-sound')
  assert.equal(ping.counts.turnEnd, 1)
  assert.equal(ping.buffered, 1)
  assert.equal(ping.lastEvents.length, 1)

  disposeAll()
  assert.equal(routes.size, 0)
})
