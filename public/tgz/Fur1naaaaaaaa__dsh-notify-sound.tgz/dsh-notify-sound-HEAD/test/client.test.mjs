/**
 * 客户端模块（lib/client.js）的单元测试。
 *
 * 这个文件平时跑在浏览器里、由 DSH 的客户端模块加载器装载，Node 直接 import 会炸。
 * 所以这里用最小的桩把它跑起来：
 *   - window.__ModuleLoader__.load 捕获模块声明；
 *   - require('react') 给一个极小的 React 桩（createElement / useState / useRef / useEffect）；
 *   - ctx 桩分别模拟「清单里声明了 inject」与「运行中没声明、要靠 ctx.inject 补」两条路。
 *
 * 覆盖的是最容易写错、又最难在浏览器里看一眼的部分：依赖声明、插槽注册的字段、
 * 组件能不能正常渲染出音量滑杆与四个试听按钮。
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import test from 'node:test'
import { fileURLToPath } from 'node:url'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const SOURCE = fs.readFileSync(path.join(HERE, '..', 'lib', 'client.js'), 'utf8')

/** 极小的 React 桩：够渲染函数组件用。 */
function makeReactStub() {
  const hooks = { states: [], index: 0 }
  return {
    hooks,
    createElement(type, props, ...children) {
      return { type, props: props || {}, children }
    },
    useState(initial) {
      const value = hooks.index < hooks.states.length ? hooks.states[hooks.index] : initial
      hooks.index += 1
      return [value, () => {}]
    },
    useRef(initial) {
      hooks.index += 1
      return { current: initial }
    },
    useEffect() {
      hooks.index += 1
    },
  }
}

/**
 * 装载客户端模块，拿到它声明的插件对象。
 * @param options - { stateValues, fetchStub, documentStub }。
 * @returns { declaration, plugin, calls }
 */
function loadClientModule(options = {}) {
  const calls = { registered: null, injectedDeps: null, reported: [], fetch: [] }
  const react = makeReactStub()
  react.hooks.states = options.stateValues || []

  const windowStub = {
    __ModuleLoader__: { load: (declaration) => { calls.declaration = declaration } },
    __dshNotifySoundInstalled: options.runtimeInstalled === true,
    dshNotifySound: options.runtime,
  }
  const documentStub = options.documentStub || {
    head: { appendChild: (node) => calls.appended = node },
    createElement: (tag) => ({ tag, setAttribute: () => {} }),
  }
  const fetchStub = (url, init) => {
    calls.fetch.push({ url, init })
    return Promise.resolve({
      ok: true,
      status: 200,
      json: () => Promise.resolve(options.fetchPayload || { ok: true, config: { volume: 0.5 } }),
    })
  }
  const requireStub = (name) => {
    if (name === 'react') return react
    throw new Error('unexpected require: ' + name)
  }

  const factory = new Function('window', 'document', 'fetch', 'console', SOURCE)
  factory(windowStub, documentStub, fetchStub, console)
  const plugin = calls.declaration.factory(requireStub)
  return { declaration: calls.declaration, plugin, calls, react }
}

/**
 * 造一个 slots 挂载桩。
 * @returns { scope, record }
 */
function makeSlotsScope() {
  const record = { key: null, registration: null, component: null }
  const scope = {
    slots: {
      inject(key, callback) {
        record.key = key
        callback()
      },
      register(registration, component) {
        record.registration = registration
        record.component = component
      },
    },
  }
  return { scope, record }
}

/**
 * 把渲染结果里的所有字符串收集出来（用于断言文案）。
 * @param node - createElement 出来的节点。
 * @param out - 收集数组。
 * @returns 字符串数组。
 */
function collectStrings(node, out = []) {
  if (node === null || node === undefined || node === false) return out
  if (typeof node === 'string') {
    out.push(node)
    return out
  }
  if (Array.isArray(node)) {
    for (const item of node) collectStrings(item, out)
    return out
  }
  if (typeof node === 'object') {
    if (typeof node.type === 'function') {
      // 子组件（Toggle）也渲染一遍，保证它本身没问题
      collectStrings(node.type(node.props), out)
      return out
    }
    for (const child of node.children || []) collectStrings(child, out)
  }
  return out
}

test('模块声明：id 正确，apply 会把运行时脚本注入页面', () => {
  const { declaration, plugin, calls } = loadClientModule()
  assert.equal(declaration.id, 'dsh-notify-sound')
  assert.equal(typeof declaration.factory, 'function')
  assert.equal(typeof plugin.apply, 'function')

  // 注入脚本：src 指向主机路由，并带上 base 属性
  const scope = makeSlotsScope()
  plugin.apply({ inject: (deps, callback) => callback(scope.scope) })
  assert.ok(calls.appended, '应注入浏览器侧运行时脚本')
  assert.equal(calls.appended.src, '/dsh-notify/client.js')
  assert.equal(calls.appended.async, true)
})

test('清单里已声明 inject 时走直连：ctx.slots 可用', () => {
  const { plugin } = loadClientModule({
    fetchPayload: { ok: true, config: { volume: 0.5 } },
  })
  const { scope, record } = makeSlotsScope()
  plugin.apply({ slots: scope.slots })
  assert.equal(record.key, 'settings.plugins.tab')
  assert.equal(record.registration.id, 'notify-sound')
  assert.equal(record.registration.name, 'settings.plugins.tab')
  assert.equal(record.registration.order, 70)
  assert.equal(record.registration.label(), '提示音')
})

test('运行中没声明 inject 时：用 ctx.inject 就地补依赖（真实遇到过的报错）', () => {
  const { plugin, calls } = loadClientModule()
  const { scope, record } = makeSlotsScope()
  let injectedDeps = null
  const ctx = {
    // 模拟 cordis 的守卫：没声明 inject 时读 slots 直接抛
    get slots() {
      throw new Error('cannot get property "slots" without inject')
    },
    inject(deps, callback) {
      injectedDeps = deps
      callback(scope)
    },
  }
  plugin.apply(ctx)
  assert.deepEqual(injectedDeps, ['slots'], '应就地补声明 slots 依赖')
  assert.equal(record.key, 'settings.plugins.tab')
  assert.equal(record.registration.id, 'notify-sound')

  // 补声明成功后要回报给主机（/ping 的 ui.module.tabRegistered）
  const reports = calls.fetch.filter((call) => String(call.url).includes('/ui-report'))
  assert.equal(reports.length, 1)
  const payload = JSON.parse(reports[0].init.body)
  assert.equal(payload.source, 'module')
  assert.equal(payload.tabRegistered, true)
  assert.equal(payload.detail.via, 'inject')
})

test('拿不到 slots 时如实回报错误，而不是静默失败', () => {
  const { plugin, calls } = loadClientModule()
  plugin.apply({ inject: undefined, get slots() { throw new Error('cannot get property "slots" without inject') } })
  const reports = calls.fetch.filter((call) => String(call.url).includes('/ui-report'))
  assert.equal(reports.length, 1)
  const payload = JSON.parse(reports[0].init.body)
  assert.equal(payload.tabRegistered, false)
  assert.match(payload.error, /slots/)
})

test('设置页组件：渲染出音量滑杆、四个试听按钮与各开关', () => {
  const { plugin, react } = loadClientModule()
  const { scope, record } = makeSlotsScope()
  plugin.apply({ slots: scope.slots })

  // 让 useState 依次拿到：config / error / status / busy / volume
  const config = {
    volume: 0.5,
    turnEnd: true,
    approval: true,
    question: true,
    skipSubagents: true,
    onlyWhenHidden: false,
    enabled: true,
    flashTitle: true,
    toast: 'auto',
  }
  react.hooks.states = [config, null, '已载入', false, 0.5]
  react.hooks.index = 0
  const tree = record.component({})
  const texts = collectStrings(tree)

  for (const expected of ['音量', '什么时候响', '其它', '50%', '试听 · 完成', '提问', '授权', '异常',
    '对话完成', '需要你授权', '弹出提问 / 计划确认', '忽略子代理的轮次结束', '只在页面处于后台时响',
    '提示音总开关', '页面在后台时闪烁标题', '提示气泡']) {
    assert.ok(texts.includes(expected), `设置页缺少文案：${expected}`)
  }

  // 滑杆与下拉框的取值来自配置
  const slider = findNode(tree, (node) => node.props && node.props.type === 'range')
  assert.ok(slider, '应有音量滑杆')
  assert.equal(slider.props.value, 0.5)
  assert.equal(slider.props.min, 0)
  assert.equal(slider.props.max, 1)
  const select = findNode(tree, (node) => node.type === 'select')
  assert.ok(select, '应有提示气泡下拉框')
  assert.equal(select.props.value, 'auto')
})

test('设置页组件：读配置失败时显示错误而不是白屏', () => {
  const { plugin, react } = loadClientModule()
  const { scope, record } = makeSlotsScope()
  plugin.apply({ slots: scope.slots })
  react.hooks.states = [null, 'HTTP 500', '读取配置失败', false, null]
  react.hooks.index = 0
  const tree = record.component({})
  const texts = collectStrings(tree)
  assert.ok(texts.includes('提示音'))
  assert.ok(texts.some((line) => line.includes('读取配置失败')), '应显示失败原因')
})

test('试听按钮：优先用页面里的运行时，没有则退回主机自检路由', () => {
  const previews = []
  const runtime = {
    test: (cue) => { previews.push(cue) },
    refreshConfig: () => {},
    overrides: () => ({ volume: 0.9 }),
  }
  const loaded = loadClientModule({ runtime })
  const { scope, record } = makeSlotsScope()
  loaded.plugin.apply({ slots: scope.slots })
  loaded.react.hooks.states = [{ volume: 0.5, toast: 'auto' }, null, '', false, 0.5]
  loaded.react.hooks.index = 0
  const tree = record.component({})
  const buttons = []
  collectNodes(tree, (node) => { if (node.type === 'button') buttons.push(node) })
  const previewButtons = buttons.filter((node) => String(node.children[0] || '').startsWith('试听') || ['提问', '授权', '异常'].includes(node.children[0]))
  assert.equal(previewButtons.length, 4, '应有四个试听按钮')
  for (const button of previewButtons) button.props.onClick()
  assert.deepEqual(previews, ['turnEnd', 'question', 'approval', 'error'])
  // 有本机覆盖时，设置页要能提示并给出一键清除
  const texts = collectStrings(tree)
  assert.ok(texts.some((line) => line.includes('本机浏览器有覆盖设置')), '应提示本机覆盖')
})

/**
 * 在渲染树里找第一个满足条件的节点。
 * @param node - 树根。
 * @param predicate - 判定函数。
 * @returns 节点或 null。
 */
function findNode(node, predicate) {
  let found = null
  collectNodes(node, (candidate) => {
    if (found === null && predicate(candidate)) found = candidate
  })
  return found
}

/**
 * 深度遍历渲染树。
 * @param node - 树根。
 * @param visit - 访问函数。
 */
function collectNodes(node, visit) {
  if (node === null || node === undefined || typeof node !== 'object') return
  if (Array.isArray(node)) {
    for (const item of node) collectNodes(item, visit)
    return
  }
  visit(node)
  if (typeof node.type === 'function') {
    collectNodes(node.type(node.props), visit)
    return
  }
  for (const child of node.children || []) collectNodes(child, visit)
}
