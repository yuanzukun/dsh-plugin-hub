/**
 * 浏览器侧运行时的单元测试：用最小的 DOM / AudioContext / fetch 桩把
 * lib/browser.js 跑起来，验证「什么事件响什么音」「开关与静音」「SSE 与轮询」。
 *
 * 跑法：node --test test/
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import test from 'node:test'
import { fileURLToPath } from 'node:url'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const SOURCE = fs.readFileSync(path.join(HERE, '..', 'lib', 'browser.js'), 'utf8')

/** 造一个元素桩。 */
function makeElement(tag) {
  const element = {
    tagName: String(tag).toUpperCase(),
    className: '',
    id: '',
    type: '',
    textContent: '',
    style: {},
    attrs: {},
    children: [],
    onclick: null,
    appendChild(child) {
      this.children.push(child)
      return child
    },
    setAttribute(key, value) {
      this.attrs[key] = value
    },
    getAttribute(key) {
      return Object.prototype.hasOwnProperty.call(this.attrs, key) ? this.attrs[key] : null
    },
    addEventListener() {},
    classList: {
      add() {},
      remove() {},
      contains() {
        return false
      },
    },
  }
  return element
}

/** 记录提示音（音符）的假 AudioContext。 */
class FakeAudioContext {
  static instances = []

  constructor() {
    this.state = 'running'
    this.currentTime = 10
    this.sampleRate = 48000
    this.destination = { name: 'destination' }
    this.notes = []
    this.resumeCalls = 0
    FakeAudioContext.instances.push(this)
  }

  createOscillator() {
    const ctx = this
    const note = { freq: 0, type: 'sine', start: 0, stop: 0 }
    return {
      type: 'sine',
      frequency: {
        set value(value) { note.freq = value },
        get value() { return note.freq },
      },
      connect() {},
      start(at) { note.start = at },
      stop(at) {
        note.stop = at
        note.type = this.type === undefined ? 'sine' : this.type
        ctx.notes.push({ ...note })
      },
    }
  }

  createGain() {
    return {
      gain: { value: 1, setValueAtTime() {}, exponentialRampToValueAtTime() {} },
      connect() {},
    }
  }

  resume() {
    this.resumeCalls += 1
    this.state = 'running'
    return Promise.resolve()
  }
}

/** 记录 SSE 连接的假 EventSource。 */class FakeEventSource {
  static instances = []

  constructor(url) {
    this.url = url
    this.closed = false
    this.onopen = null
    this.onmessage = null
    this.onerror = null
    FakeEventSource.instances.push(this)
  }

  close() {
    this.closed = true
  }

  emit(payload) {
    if (this.onmessage) this.onmessage({ data: JSON.stringify(payload) })
  }
}

/**
 * 建一个浏览器环境并把 browser.js 跑起来。
 * @param options - { hostConfig, store, withEventSource, currentScript }。
 * @returns 环境句柄。
 */
function createHarness(options = {}) {
  const timeouts = new Set()
  const intervals = new Set()
  const intervalDelays = []
  const fetchCalls = []
  const domListeners = []
  const hostEvents = []
  let hostSeq = 0
  const state = { bootId: options.bootId || 'boot-1', hostConfig: options.hostConfig || {} }

  const documentStub = {
    title: 'DeepSeek Harness',
    hidden: false,
    readyState: 'complete',
    currentScript: options.currentScript === null
      ? null
      : { getAttribute: (key) => (key === 'data-dsh-notify-base' ? '/dsh-notify' : null) },
    head: makeElement('head'),
    body: makeElement('body'),
    createElement: (tag) => makeElement(tag),
    addEventListener(type, listener) { domListeners.push({ type, listener }) },
    removeEventListener() {},
  }

  const windowStub = {
    AudioContext: FakeAudioContext,
    addEventListener() {},
    removeEventListener() {},
  }

  const store = new Map()
  if (options.store) {
    for (const [key, value] of Object.entries(options.store)) store.set(key, JSON.stringify(value))
  }
  const localStorageStub = {
    getItem: (key) => (store.has(key) ? store.get(key) : null),
    setItem: (key, value) => { store.set(key, String(value)) },
    removeItem: (key) => { store.delete(key) },
  }

  const fetchStub = (url) => {
    fetchCalls.push(url)
    if (url.indexOf('/config.json') !== -1) {
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve({ ok: true, version: '0.1.0', bootId: state.bootId, seq: hostSeq, config: state.hostConfig }),
      })
    }
    const query = /after=(\d+)/.exec(url)
    if (!query) {
      return Promise.resolve({ ok: true, json: () => Promise.resolve({ ok: true, bootId: state.bootId, now: hostSeq, events: [] }) })
    }
    const after = Number(query[1])
    const pending = hostEvents.filter((event) => event.seq > after)
    return Promise.resolve({ ok: true, json: () => Promise.resolve({ ok: true, bootId: state.bootId, now: hostSeq, events: pending }) })
  }

  const setTimeoutStub = (fn, ms) => {
    const id = setTimeout(fn, ms)
    timeouts.add(id)
    return id
  }
  const clearTimeoutStub = (id) => {
    timeouts.delete(id)
    clearTimeout(id)
  }
  const setIntervalStub = (fn, ms) => {
    const id = setInterval(fn, ms)
    intervals.add(id)
    intervalDelays.push(ms)
    return id
  }
  const clearIntervalStub = (id) => {
    intervals.delete(id)
    clearInterval(id)
  }

  const factory = new Function(
    'window',
    'document',
    'localStorage',
    'fetch',
    'AudioContext',
    'EventSource',
    'setTimeout',
    'clearTimeout',
    'setInterval',
    'clearInterval',
    'console',
    SOURCE,
  )
  factory(
    windowStub,
    documentStub,
    localStorageStub,
    fetchStub,
    FakeAudioContext,
    options.withEventSource ? FakeEventSource : undefined,
    setTimeoutStub,
    clearTimeoutStub,
    setIntervalStub,
    clearIntervalStub,
    console,
  )

  return {
    window: windowStub,
    document: documentStub,
    api: windowStub.dshNotifySound,
    fetchCalls,
    intervalDelays,
    domListeners,
    get store() { return store },
    /** 主机侧推一条通知（模拟 SSE / 轮询的增量）。 */
    push(event) {
      hostSeq += 1
      hostEvents.push({ seq: hostSeq, ts: Date.now(), ...event })
      return hostSeq
    },
    /** 模拟主机换代：插件重载后序号归零、bootId 换新。 */
    restartHost(bootId) {
      hostSeq = 0
      hostEvents.length = 0
      state.bootId = bootId
    },
    /** 模拟用户改了 ~/.dsh/dsh-notify-sound.json。 */
    setHostConfig(next) {
      state.hostConfig = next
    },
    /** 读浏览器 localStorage 里存下来的显式覆盖。 */
    storedOverrides() {
      const raw = store.get('dsh-notify-sound.prefs')
      return raw ? JSON.parse(raw) : null
    },
    /** 等待若干轮微任务，让 fetch 链跑完。 */
    async flush(rounds = 6) {
      for (let i = 0; i < rounds; i += 1) await Promise.resolve()
      await new Promise((resolve) => realSetTimeout(resolve, 0))
    },
    /** 清理定时器，避免测试进程被挂住。 */
    cleanup() {
      for (const id of timeouts) clearTimeout(id)
      for (const id of intervals) clearInterval(id)
      timeouts.clear()
      intervals.clear()
    },
  }
}

const realSetTimeout = setTimeout

test('启动：先拉 /config.json，没有 EventSource 时退回轮询', async (t) => {
  const harness = createHarness({ hostConfig: { volume: 0.2, pollMs: 900 } })
  t.after(() => harness.cleanup())
  await harness.flush()

  assert.equal(harness.fetchCalls[0], '/dsh-notify/config.json')
  assert.equal(harness.api.status().prefs.volume, 0.2, '主机配置应生效')
  assert.equal(harness.api.status().transport, 'polling')
  // 配置响应带回了主机当前序号 -> 第一次轮询就是增量拉取（after=0），不会回放历史
  assert.equal(harness.api.debug.getCursor(), 0)
  assert.equal(harness.fetchCalls[1], '/dsh-notify/events?after=0')
  assert.equal(harness.intervalDelays[0], 900)
})

test('localStorage 里的客户端偏好优先于主机配置', async (t) => {
  const harness = createHarness({
    hostConfig: { volume: 0.2 },
    store: { 'dsh-notify-sound.prefs': { volume: 0.8 } },
  })
  t.after(() => harness.cleanup())
  await harness.flush()
  assert.equal(harness.api.status().prefs.volume, 0.8)
})

test('四类通知各响各的音：turnEnd / question / approval / error', async (t) => {
  const harness = createHarness()
  FakeAudioContext.instances = []
  t.after(() => harness.cleanup())
  await harness.flush()

  const cases = [
    { event: { type: 'turn-end', reason: 'completed' }, expected: 'turnEnd', notes: 2 },
    { event: { type: 'question' }, expected: 'question', notes: 2 },
    { event: { type: 'approval', toolName: 'bash' }, expected: 'approval', notes: 3 },
    { event: { type: 'turn-end', reason: 'error' }, expected: 'error', notes: 2 },
  ]
  let seq = 100
  for (const item of cases) {
    assert.equal(harness.api.debug.cueFor(item.event), item.expected)
    seq += 1
    harness.api.debug.handleEvent({ seq, ...item.event })
  }

  const status = harness.api.status()
  assert.ok(status.audio, 'AudioContext 应已被创建')
  assert.equal(status.stats.received, 4)
  assert.equal(status.stats.played, 4)
  assert.equal(status.stats.blocked, 0)

  const ctx = FakeAudioContext.instances[0]
  assert.equal(ctx.notes.length, 9, '2+2+3+2 = 9 个音符')
  assert.deepEqual(ctx.notes.map((note) => note.freq), [
    880, 1318.51,
    659.25, 987.77,
    1046.5, 1046.5, 1396.91,
    587.33, 415.3,
  ])
})

test('门控与去重：重复 seq 只响一次，关掉的类型不响', async (t) => {
  const harness = createHarness()
  t.after(() => harness.cleanup())
  await harness.flush()

  harness.api.debug.handleEvent({ seq: 7, type: 'turn-end', reason: 'completed' })
  harness.api.debug.handleEvent({ seq: 7, type: 'turn-end', reason: 'completed' })
  assert.equal(harness.api.status().stats.received, 1)
  assert.equal(harness.api.status().stats.played, 1)

  harness.api.set('question', false)
  harness.api.debug.handleEvent({ seq: 8, type: 'question' })
  assert.equal(harness.api.status().stats.played, 1)
  assert.equal(harness.api.status().stats.skipped, 1)
})

test('静音后不再出声，但会给出“恢复声音”的视觉提示', async (t) => {
  const harness = createHarness()
  t.after(() => harness.cleanup())
  await harness.flush()

  harness.api.setEnabled(false)
  assert.equal(harness.api.debug.getPrefs().enabled, false)
  const before = harness.api.status().stats.played

  harness.api.debug.handleEvent({ seq: 21, type: 'approval' })
  assert.equal(harness.api.status().stats.played, before, '静音时不应播放')
  assert.equal(harness.api.status().stats.skipped, 1)

  const toast = harness.document.body.children.find((child) => child.id === 'dsh-notify-toast')
  assert.ok(toast, '应该出现 toast')
  assert.equal(toast.children[2].textContent, '恢复声音')
})

test('分类开关：关掉 question 后提问不再响', async (t) => {
  const harness = createHarness()
  t.after(() => harness.cleanup())
  await harness.flush()

  harness.api.set('question', false)
  harness.api.debug.handleEvent({ seq: 31, type: 'question' })
  assert.equal(harness.api.status().stats.played, 0)
  assert.equal(harness.api.status().stats.skipped, 1)

  harness.api.debug.handleEvent({ seq: 32, type: 'approval' })
  assert.equal(harness.api.status().stats.played, 1)
})

test('自检通知（test:true）不受分类开关与 onlyWhenHidden 限制，试听一定出声', async (t) => {
  const harness = createHarness({ hostConfig: { onlyWhenHidden: true, turnEnd: false, approval: false } })
  t.after(() => harness.cleanup())
  await harness.flush()

  // 普通通知：分类被关 + 前台 -> 不响
  harness.api.debug.handleEvent({ seq: 33, type: 'turn-end', reason: 'completed' })
  assert.equal(harness.api.status().stats.played, 0)

  // 自检通知：照响
  harness.api.debug.handleEvent({ seq: 34, type: 'turn-end', reason: 'completed', test: true })
  assert.equal(harness.api.status().stats.played, 1)
  harness.api.debug.handleEvent({ seq: 35, type: 'approval', test: true })
  assert.equal(harness.api.status().stats.played, 2)
  harness.api.debug.handleEvent({ seq: 36, type: 'turn-end', reason: 'error', test: true })
  assert.equal(harness.api.status().stats.played, 3)

  // 总开关仍然压得住它
  harness.api.setEnabled(false)
  harness.api.debug.handleEvent({ seq: 37, type: 'question', test: true })
  assert.equal(harness.api.status().stats.played, 3)
})

test('onlyWhenHidden：页面在前台时不响', async (t) => {
  const harness = createHarness({ hostConfig: { onlyWhenHidden: true } })
  t.after(() => harness.cleanup())
  await harness.flush()

  harness.api.debug.handleEvent({ seq: 41, type: 'turn-end', reason: 'completed' })
  assert.equal(harness.api.status().stats.played, 0)

  harness.document.hidden = true
  harness.api.debug.handleEvent({ seq: 42, type: 'turn-end', reason: 'completed' })
  assert.equal(harness.api.status().stats.played, 1)
})

test('浏览器挂起音频时：先 resume 再补播', async (t) => {
  const harness = createHarness()
  FakeAudioContext.instances = []
  t.after(() => harness.cleanup())
  await harness.flush()

  // 先借一次试听把 AudioContext 建出来，再手工挂起它
  harness.api.test('turnEnd')
  const ctx = FakeAudioContext.instances[0]
  assert.ok(ctx, 'AudioContext 应已创建')
  ctx.state = 'suspended'
  const playedBefore = harness.api.status().stats.played

  harness.api.debug.handleEvent({ seq: 71, type: 'turn-end', reason: 'completed' })
  await harness.flush()
  assert.ok(ctx.resumeCalls >= 1, '挂起时应尝试 resume')
  assert.equal(harness.api.status().stats.played, playedBefore + 1, 'resume 之后应补播')
})

test('页面在后台时闪标题，回到前台后还原', async (t) => {
  const harness = createHarness()
  t.after(() => harness.cleanup())
  await harness.flush()

  harness.document.hidden = true
  harness.document.title = 'DeepSeek Harness'
  harness.api.debug.handleEvent({ seq: 51, type: 'turn-end', reason: 'completed' })

  const deadline = Date.now() + 2500
  while (Date.now() < deadline && harness.document.title.indexOf('🔔') === -1) {
    await new Promise((resolve) => realSetTimeout(resolve, 100))
  }
  assert.match(harness.document.title, /🔔/, '后台时应闪烁标题')

  harness.document.hidden = false
  for (const entry of harness.domListeners) {
    if (entry.type === 'visibilitychange') entry.listener()
  }
  assert.equal(harness.document.title, 'DeepSeek Harness')
})

test('SSE 可用时走推送；失败两次后自动退回轮询', async (t) => {
  FakeEventSource.instances = []
  const harness = createHarness({ withEventSource: true })
  t.after(() => harness.cleanup())
  await harness.flush()

  assert.equal(FakeEventSource.instances.length, 1)
  const stream = FakeEventSource.instances[0]
  assert.equal(stream.url, '/dsh-notify/stream')

  if (stream.onopen) stream.onopen()
  assert.equal(harness.api.status().transport, 'sse')

  stream.emit({ type: 'hello', now: 5 })
  stream.emit({ seq: 6, type: 'approval', toolName: 'write' })
  assert.equal(harness.api.status().stats.received, 1)
  assert.equal(harness.api.status().stats.lastEvent.type, 'approval')

  stream.onerror()
  assert.equal(stream.closed, false, '第一次失败交给 EventSource 自己重连')
  stream.onerror()
  assert.equal(stream.closed, true, '连续失败两次应关掉 SSE')
  assert.equal(harness.api.status().transport, 'polling')

  // 退回轮询后：注册了 30s 的 SSE 重试，并且页面回到前台时立刻重连
  assert.ok(harness.intervalDelays.includes(30000), '应注册 SSE 重试定时器')
  assert.equal(FakeEventSource.instances.length, 1)

  harness.document.hidden = false
  for (const entry of harness.domListeners) {
    if (entry.type === 'visibilitychange') entry.listener()
  }
  assert.equal(FakeEventSource.instances.length, 2, '页面可见时应重新建立 SSE')
  assert.equal(harness.api.status().transport, 'sse')
})

test('轮询：先同步序号，再按增量取；游标只增不减', async (t) => {
  const harness = createHarness()
  t.after(() => harness.cleanup())
  await harness.flush()

  const seq1 = harness.push({ type: 'turn-end', reason: 'completed' })
  assert.equal(seq1, 1)

  harness.api.debug.setCursor(0)
  harness.api.debug.pollOnce()
  await harness.flush()

  assert.equal(harness.api.debug.getCursor(), 1)
  assert.equal(harness.api.status().stats.played, 1)

  // 再拉一次不会重复播
  harness.api.debug.pollOnce()
  await harness.flush()
  assert.equal(harness.api.status().stats.played, 1)
})

test('重复注入：脚本跑两次只装一个实例', async (t) => {
  const harness = createHarness()
  t.after(() => harness.cleanup())
  await harness.flush()

  const firstApi = harness.api
  const listenersBefore = harness.domListeners.length

  const factory = new Function(
    'window', 'document', 'localStorage', 'fetch', 'AudioContext', 'EventSource',
    'setTimeout', 'clearTimeout', 'setInterval', 'clearInterval', 'console',
    SOURCE,
  )
  factory(
    harness.window, harness.document, harness.store, () => Promise.resolve({ ok: true, json: () => Promise.resolve({}) }),
    FakeAudioContext, undefined, setTimeout, clearTimeout, setInterval, clearInterval, console,
  )
  await harness.flush()

  assert.equal(harness.window.dshNotifySound, firstApi, '不应被第二次注入替换')
  assert.equal(harness.domListeners.length, listenersBefore, '不应重复注册手势监听')
})

test('主机换代（bootId 变化）后重置游标，不补播上一代的提示音', async (t) => {
  const harness = createHarness({ bootId: 'boot-1' })
  t.after(() => harness.cleanup())
  await harness.flush()

  harness.push({ type: 'turn-end', reason: 'completed' })
  harness.api.debug.setCursor(0)
  harness.api.debug.pollOnce()
  await harness.flush()
  assert.equal(harness.api.status().stats.played, 1)
  assert.equal(harness.api.debug.getCursor(), 1)

  // 主机重载：序号归零、bootId 换新，并立刻产生一条新通知（seq 1）
  harness.restartHost('boot-2')
  harness.push({ type: 'approval', toolName: 'bash' })
  harness.api.debug.pollOnce()
  await harness.flush()

  assert.equal(harness.api.status().stats.played, 1, '换代那一次只同步游标，不补播')
  assert.equal(harness.api.debug.getCursor(), 1, '游标应重置到新一代的当前序号')

  // 换代完成之后的新通知照常响
  harness.push({ type: 'question' })
  harness.api.debug.pollOnce()
  await harness.flush()
  assert.equal(harness.api.status().stats.played, 2)
})

test('浏览器端只记住显式改过的键：改过音量后，主机配置里的其它字段仍然跟着变', async (t) => {
  const harness = createHarness({ hostConfig: { volume: 0.2, onlyWhenHidden: true, toast: 'never' } })
  t.after(() => harness.cleanup())
  await harness.flush()

  assert.equal(harness.api.status().prefs.volume, 0.2)
  assert.equal(harness.api.status().prefs.onlyWhenHidden, true)
  assert.equal(harness.api.status().prefs.toast, 'never')

  harness.api.setVolume(0.9)
  assert.deepEqual(harness.storedOverrides(), { volume: 0.9 }, 'localStorage 只应存显式改过的那一个键')

  // 用户随后去改 ~/.dsh/dsh-notify-sound.json
  harness.setHostConfig({ volume: 0.2, onlyWhenHidden: false, toast: 'always' })
  harness.api.refreshConfig()
  await harness.flush()

  const status = harness.api.status()
  assert.equal(status.prefs.volume, 0.9, '浏览器里显式设过的音量应压过主机配置')
  assert.equal(status.prefs.onlyWhenHidden, false, '没被浏览器改过的字段应跟随主机配置')
  assert.equal(status.prefs.toast, 'always')
  assert.deepEqual(status.overrides, { volume: 0.9 })

  // 一键清掉浏览器覆盖，完全回到主机配置
  harness.api.reset()
  assert.equal(harness.api.status().prefs.volume, 0.2)
  assert.equal(harness.storedOverrides(), null)
})

test('控制台 API：setVolume / set / status 往返正确', async (t) => {
  const harness = createHarness()
  t.after(() => harness.cleanup())
  await harness.flush()

  assert.equal(harness.api.setVolume(2), 1)
  assert.equal(harness.api.setVolume(-1), 0)
  assert.equal(harness.api.set('flashTitle', false), false)

  const status = harness.api.status()
  assert.equal(status.prefs.volume, 0)
  assert.equal(status.prefs.flashTitle, false)
  assert.equal(status.transport, 'polling')
  assert.equal(typeof status.stats.polls, 'number')
})

test('损坏的 localStorage 不会让脚本崩溃', async (t) => {
  const harness = createHarness()
  harness.store.set('dsh-notify-sound.prefs', '{不是 JSON')
  t.after(() => harness.cleanup())
  await harness.flush()

  assert.equal(harness.api.status().prefs.enabled, true)
  harness.api.debug.handleEvent({ seq: 61, type: 'question' })
  assert.equal(harness.api.status().stats.played, 1)
})
