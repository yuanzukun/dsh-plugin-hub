"""按顺序试听四段提示音：推一条 -> 等页面回执 -> 再推下一条。

页面可能处于后台节流的轮询模式，所以不能按固定间隔硬推（会挤在一起），
这里用浏览器自己的 /ack 回执来驱动节奏，保证每一段都单独响完。

用法：
    python scripts/preview-cues.py                          # 默认 http://127.0.0.1:19387
    python scripts/preview-cues.py http://127.0.0.1:8080
    DSH_WEB_URL=http://127.0.0.1:8080 python scripts/preview-cues.py
端口用 `dsh web` 启动时打印的地址，或环境变量 DSH_WEB_URL。
"""
import json
import os
import sys
import time
import urllib.request

DEFAULT_ORIGIN = os.environ.get('DSH_WEB_URL', 'http://127.0.0.1:19387')
ORIGIN = (sys.argv[1] if len(sys.argv) > 1 else DEFAULT_ORIGIN).rstrip('/')
BASE = ORIGIN + '/dsh-notify'


def get(path, timeout=5):
    with urllib.request.urlopen(BASE + path, timeout=timeout) as response:
        return json.load(response)


CUES = [
    ('turn-end', '对话完成', '上行两声清亮音 A5 → E6'),
    ('question', '需要你回答 / 弹出提问', '上行两声询问音 E5 → B5（三角波）'),
    ('approval', '需要你授权', '三声急促方波 C6 C6 F6'),
    ('error', '异常结束（出错 / 被拦截）', '下行两声低沉音 D5 → G#4（锯齿波）'),
]

print('目标:', BASE)
try:
    print('页面状态:', get('/ping')['metrics'])
except Exception as error:  # noqa: BLE001 - 连不上就直说，别抛一堆栈
    raise SystemExit('连不上 %s（%s）。确认 DSH 在跑，或用 dsh web 打印的地址作为参数。' % (BASE, error))

for index, (cue, label, describe) in enumerate(CUES, 1):
    pushed = get('/test?type=' + cue)
    seq = pushed['seq']
    print('\n[%d/4] %s —— %s   (seq=%d, 正在播放…)' % (index, label, describe, seq), flush=True)
    deadline = time.time() + 40
    acked = None
    while time.time() < deadline:
        time.sleep(1.5)
        ack = get('/ping').get('lastAck') or {}
        if ack.get('seq') == seq:
            acked = ack
            break
    if acked:
        print('      浏览器回执: outcome=%s transport=%s' % (acked.get('outcome'), acked.get('transport')), flush=True)
    else:
        print('      未收到回执（页面可能没连上 / 被静音）', flush=True)
    time.sleep(2.5)

print('\n全部播放完毕。')
