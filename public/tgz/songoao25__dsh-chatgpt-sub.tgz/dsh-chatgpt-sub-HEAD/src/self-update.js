// Package self-updates: verified archive, package-only writes, backup and rollback.
import { copyFileSync, existsSync, lstatSync, mkdirSync, readFileSync, readdirSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { dirname, isAbsolute, join, resolve, sep } from 'node:path'
import { gunzipSync } from 'node:zlib'

import { PACKAGE_NAME, UPDATE_REGISTRY_ORIGIN, compareSemver, parseSemver } from './version.js'
// 下游（测试）从本模块取版本 API：名字不变，转交 version.js（唯一的定义处）。
export { PACKAGE_NAME, compareSemver, parseSemver }

// 允许被自更新替换的路径：正好是 package.json 的 files 字段声明的分发内容。
// 白名单而非黑名单——新增一种分发内容时必须显式加进来，不允许"顺手"写到别处。
const PAYLOAD_ROOTS = ['lib/', 'locale/', 'docs/']
const PAYLOAD_FILES = ['package.json', 'cordis.patch.yml', 'LICENSE', 'README.md', 'README.zh-CN.md']

export function isAllowedPayloadPath(relative) {
  if (typeof relative !== 'string' || relative.length === 0) return false
  return PAYLOAD_FILES.includes(relative) || PAYLOAD_ROOTS.some((root) => relative.startsWith(root))
}

// 把相对路径安全地接到基准目录下：拒绝绝对路径、盘符、空段、'.'、'..' 与 NUL，
// 并再断言解析结果确实在基准目录内（双保险，防规范化边界情况）。
export function resolveSafePath(baseDir, relative) {
  if (typeof relative !== 'string' || relative.length === 0) return null
  const normalized = relative.split('\\').join('/')
  if (normalized.startsWith('/') || isAbsolute(relative)) return null
  if (/^[A-Za-z]:/.test(normalized)) return null
  if (normalized.includes('\0')) return null
  const parts = normalized.split('/')
  if (parts.some((part) => part === '' || part === '.' || part === '..')) return null
  const base = resolve(baseDir)
  const full = resolve(base, normalized)
  // 基准目录自身以分隔符结尾时（最典型的是根目录 '/'）不能直接拼 sep，否则 '//x' 永远匹配不上，
  // 合法路径会被误判成逃逸 —— 2026-09-25 由 tests/test-self-update.mjs 首次跑到该分支时抓出。
  const boundary = base.endsWith(sep) ? base : base + sep
  if (full !== base && !full.startsWith(boundary)) return null
  return full
}

// 词法路径在包目录内还不够：若已有的中间目录是符号链接，`lib/x.js` 仍可能写到包外。
// 自更新只支持实体目录安装；遇到链接不猜其目标，直接拒绝整次更新。叶子文件本身是链接时
// rename 会替换链接而不会跟随它，因此只检查目录链即可。
function resolveSafePayloadTarget(baseDir, relative) {
  const full = resolveSafePath(baseDir, relative)
  if (!full || !isAllowedPayloadPath(relative)) return null
  const base = resolve(baseDir)
  try {
    if (lstatSync(base).isSymbolicLink()) return null
    let cursor = dirname(full)
    while (cursor !== base) {
      if (existsSync(cursor) && lstatSync(cursor).isSymbolicLink()) return null
      const parent = dirname(cursor)
      if (parent === cursor) return null
      cursor = parent
    }
  } catch {
    return null
  }
  return full
}

// 失败原因归一（2026-09-25 第三轮加入）：state.lastError 原来直接存技术报错（如
// "unexpected end of file"），界面只能把它原样甩给用户 —— 用户看到一行英文报错，既不懂也不知道
// 自己有没有风险。这里把报错映射成稳定代号，由界面翻译成人话；原始报错仍写进 update-log.jsonl
// 供排查（见 runOnce 的 catch）。
// 映射同时认「代号」与「原始报错」，因此历史 state 文件里存的老值也能被正确翻译。
// 顺序即优先级：更具体的模式必须排在更宽的模式前面，否则会被宽模式抢先命中
// （「download failed: too large」曾被 download-failed 抢走，2026-09-25 由新增的归一单测抓出）。
const UPDATE_ERROR_PATTERNS = [
  ['incomplete-download', /unexpected end of file|invalid tar|incorrect header check|invalid distance|invalid checksum|too short|not in gzip/i],
  ['integrity-mismatch', /integrity mismatch/i],
  ['too-large', /too large/i],
  ['download-failed', /download failed|empty body|fetch failed|abort/i],
  ['payload-mismatch', /package name mismatch|version mismatch|has no package\.json|not valid JSON|not semver/i],
  ['payload-unsafe', /path not allowed|path escapes|refusing to write outside/i],
  ['check-failed', /check-failed/i],
]
export const UPDATE_ERROR_KINDS = ['incomplete-download', 'integrity-mismatch', 'download-failed', 'too-large', 'payload-mismatch', 'payload-unsafe', 'check-failed', 'unknown']

export function describeUpdateError(value) {
  const text = typeof value === 'string' ? value : (value && value.message) || ''
  if (text.length === 0) return 'unknown'
  if (UPDATE_ERROR_KINDS.includes(text)) return text
  for (const [kind, pattern] of UPDATE_ERROR_PATTERNS) {
    if (pattern.test(text)) return kind
  }
  return 'unknown'
}

// parseSemver / compareSemver 见 version.js（唯一的定义处，本模块顶部转交）。

// ---------- tar 解析 ----------
// npm 的 tarball 是 gzip + ustar（长路径用 pax 扩展头）。只为解包自己的包服务，
// 因此只认常规文件与目录，忽略符号链接等其余类型（我们的分发内容里没有）。

function readTarText(header, start, length) {
  const slice = header.subarray(start, start + length)
  let end = slice.length
  while (end > 0 && (slice[end - 1] === 0 || slice[end - 1] === 0x20)) end--
  return slice.subarray(0, end).toString('utf8')
}

// pax 扩展头的内容是若干条 "总长度 key=value\n" 记录；我们只关心 path。
function readPaxPath(chunk) {
  const text = chunk.toString('utf8')
  let cursor = 0
  let path = null
  while (cursor < text.length) {
    const space = text.indexOf(' ', cursor)
    if (space < 0) break
    const length = Number(text.slice(cursor, space))
    if (!Number.isFinite(length) || length <= 0 || cursor + length > text.length) break
    const record = text.slice(space + 1, cursor + length)
    const eq = record.indexOf('=')
    if (eq > 0 && record.slice(0, eq) === 'path') path = record.slice(eq + 1).replace(/\n$/, '')
    cursor += length
  }
  return path
}

export function parseTar(buffer) {
  const entries = []
  let offset = 0
  let paxPath = null
  while (offset + 512 <= buffer.length) {
    const header = buffer.subarray(offset, offset + 512)
    // 连续的全零块表示归档结束
    let allZero = true
    for (let i = 0; i < header.length; i++) {
      if (header[i] !== 0) { allZero = false; break }
    }
    if (allZero) break
    const rawName = readTarText(header, 0, 100)
    const size = parseInt(readTarText(header, 124, 12).replace(/[^0-7]/g, ''), 8)
    if (!Number.isFinite(size) || size < 0) break
    const typeflag = String.fromCharCode(header[156] || 0x30)
    const prefix = readTarText(header, 345, 155)
    const dataStart = offset + 512
    const dataEnd = dataStart + size
    const next = dataStart + Math.ceil(size / 512) * 512
    if (dataEnd > buffer.length) break
    if (typeflag === 'x') {
      paxPath = readPaxPath(buffer.subarray(dataStart, dataEnd))
      offset = next
      continue
    }
    const name = paxPath || (prefix.length > 0 ? prefix + '/' + rawName : rawName)
    paxPath = null
    if (typeflag === '0' || typeflag === '\0') {
      entries.push({ path: name, data: buffer.subarray(dataStart, dataEnd) })
    }
    offset = next > dataStart ? next : dataStart + 512
  }
  return entries
}

// gzip 解开后只取 package/ 前缀下的条目，并剥掉该前缀。tarball 里其它前缀（不存在）一律忽略。
export function extractPackageFiles(tarballBuffer) {
  const entries = parseTar(gunzipSync(tarballBuffer))
  const files = []
  for (const entry of entries) {
    const normalized = entry.path.split('\\').join('/')
    if (!normalized.startsWith('package/')) continue
    const relative = normalized.slice('package/'.length)
    if (relative.length === 0) continue
    files.push({ path: relative, data: entry.data })
  }
  return files
}

// 校验：完整性（registry 给的 sha512）→ 包身份（name / version）→ 路径白名单。
// 任一条不过就抛出，调用方据此放弃整次更新（绝不落盘）。
export function verifyPayload(files, options) {
  const { integrity, version } = options || {}
  if (!Array.isArray(files)) throw new Error('payload files are invalid')
  const seenPaths = new Set()
  for (const file of files) {
    if (!file || typeof file.path !== 'string' || seenPaths.has(file.path)) {
      throw new Error('payload has duplicate or invalid path: ' + String(file && file.path))
    }
    seenPaths.add(file.path)
  }
  const manifestFile = files.find((file) => file.path === 'package.json')
  if (!manifestFile) throw new Error('payload has no package.json')
  let manifest
  try {
    manifest = JSON.parse(manifestFile.data.toString('utf8'))
  } catch {
    throw new Error('payload package.json is not valid JSON')
  }
  if (manifest.name !== PACKAGE_NAME) throw new Error('payload package name mismatch: ' + String(manifest.name))
  if (version && manifest.version !== version) throw new Error('payload version mismatch: ' + String(manifest.version) + ' != ' + version)
  if (parseSemver(manifest.version) === null) throw new Error('payload version is not semver: ' + String(manifest.version))
  if (typeof integrity === 'string' && integrity.length > 0) {
    const [algorithm, expected] = integrity.split('-')
    // 给了校验值就必须验得动：算法不是 sha512 一律拒绝，绝不「看不懂就跳过校验」。
    if (algorithm !== 'sha512' || !expected) throw new Error('payload integrity uses an unsupported algorithm: ' + String(algorithm))
    const digest = createHash('sha512').update(options.tarball).digest('base64')
    if (digest !== expected) throw new Error('payload integrity mismatch')
  }
  for (const file of files) {
    if (!isAllowedPayloadPath(file.path)) throw new Error('payload path not allowed: ' + file.path)
    if (resolveSafePath('/', file.path) === null) throw new Error('payload path escapes: ' + file.path)
  }
  return manifest
}

// ---------- 落盘 ----------
// 备份 + 替换 + 回滚。替换以「单文件原子写（临时文件 + rename）」进行；整批不是原子的，
// 所以失败时必须回滚到备份状态：先删掉本次新增的文件，再把备份里的文件覆盖回去。
function listPayloadFiles(baseDir) {
  const found = []
  const walk = (dir, prefix) => {
    let names
    try { names = readdirSync(dir) } catch { return }
    for (const name of names) {
      const full = join(dir, name)
      const relative = prefix ? prefix + '/' + name : name
      let info
      // 不跟随符号链接：备份阶段绝不能因为一个异常链接而读取包目录以外的文件。
      try { info = lstatSync(full) } catch { continue }
      if (info.isSymbolicLink()) continue
      if (info.isDirectory()) walk(full, relative)
      else if (isAllowedPayloadPath(relative)) found.push(relative)
    }
  }
  walk(baseDir, '')
  return found
}

export function applyPayload(files, context) {
  const { packageDir, backupDir, log } = context || {}
  if (!packageDir || !backupDir) throw new Error('applyPayload needs packageDir and backupDir')
  if (!Array.isArray(files)) throw new Error('applyPayload needs files')
  // 先完整预检，避免一个后置的异常路径导致前面的合法文件已经被替换。
  const targets = files.map((file) => {
    const path = file && file.path
    const target = resolveSafePayloadTarget(packageDir, path)
    if (!target) throw new Error('refusing to write outside package or through a symbolic link: ' + String(path))
    return { file, target }
  })
  const before = listPayloadFiles(packageDir)
  // 备份当前内容（含目录结构），用于失败回滚
  rmSync(backupDir, { recursive: true, force: true })
  mkdirSync(backupDir, { recursive: true })
  const backedUp = []
  for (const relative of before) {
    const source = resolveSafePath(packageDir, relative)
    const target = resolveSafePath(backupDir, relative)
    if (!source || !target || !existsSync(source)) continue
    mkdirSync(dirname(target), { recursive: true })
    copyFileSync(source, target)
    backedUp.push(relative)
  }
  const restoredFiles = () => {
    rmSync(backupDir, { recursive: true, force: true })
  }
  const written = []
  try {
    for (const entry of targets) {
      const { file, target } = entry
      mkdirSync(dirname(target), { recursive: true })
      const temp = target + '.update-tmp'
      writeFileSync(temp, file.data)
      renameSync(temp, target)
      written.push(file.path)
    }
  } catch (error) {
    rollbackPayload({ packageDir, backupDir, before: backedUp, written })
    restoredFiles()
    if (typeof log === 'function') log('update rolled back: ' + error.message)
    throw error
  }
  return { before: backedUp, written, backupDir }
}

export function rollbackPayload(context) {
  const { packageDir, backupDir, before, written } = context || {}
  if (!packageDir || !backupDir) return { restored: [], removed: [] }
  const keep = new Set(Array.isArray(before) ? before : [])
  const removed = []
  for (const relative of Array.isArray(written) ? written : []) {
    if (keep.has(relative)) continue
    const target = resolveSafePath(packageDir, relative)
    if (!target) continue
    rmSync(target, { force: true })
    removed.push(relative)
  }
  const restored = []
  if (existsSync(backupDir)) {
    for (const relative of keep) {
      const source = resolveSafePath(backupDir, relative)
      const target = resolveSafePath(packageDir, relative)
      if (!source || !target || !existsSync(source)) continue
      mkdirSync(dirname(target), { recursive: true })
      copyFileSync(source, target)
      restored.push(relative)
    }
  }
  return { restored, removed }
}

// ---------- 引擎 ----------
// 依赖全部由外部注入，便于单测：不注入就走真实实现（fetch / 真实目录 / 真实时钟）。
export function createSelfUpdater(options) {
  const config = options || {}
  const packageDir = config.packageDir
  const dataDir = config.dataDir
  const runningVersion = typeof config.runningVersion === 'string' ? config.runningVersion : '0.0.0'
  const fetchImpl = config.fetch || ((...args) => fetch(...args))
  const now = config.now || (() => Date.now())
  const log = typeof config.log === 'function' ? config.log : () => {}
  const stateFile = join(dataDir, 'update-state.json')
  const logFile = join(dataDir, 'update-log.jsonl')
  const backupRoot = join(dataDir, 'update-backup')
  const keepBackups = Number.isInteger(config.keepBackups) ? config.keepBackups : 3
  const timeoutMs = Number.isFinite(config.timeoutMs) ? config.timeoutMs : 60000
  const maxBytes = Number.isFinite(config.maxBytes) ? config.maxBytes : 8 * 1024 * 1024
  const autoInstallAllowed = typeof config.autoInstallAllowed === 'function' ? config.autoInstallAllowed : () => true

  // holdVersion：用户回滚过的版本。回滚是「新版有问题」时的逃生门，若重启后 8 秒的自动检查又把它
  // 装回来，等于逃生门自己会关上。因此回滚后只暂缓「正好等于该版本」的更新，更高版本照常进行。
  let state = { autoUpdate: true, pendingVersion: null, holdVersion: null, updatedAt: null, lastError: null, lastCheckAt: null }
  // 并发去重按动作分槽：检查是纯读、安装是写，两者语义不同，不能共用一个在途 promise ——
  // 共用会让「检查在跑时来的安装请求」变成什么都不做的空转（拿到的是检查的结果）。
  const inFlight = { check: null, install: null }

  function loadState() {
    try {
      const parsed = JSON.parse(readFileSync(stateFile, 'utf8'))
      if (parsed && typeof parsed === 'object') {
        state = {
          autoUpdate: parsed.autoUpdate !== false,
          pendingVersion: typeof parsed.pendingVersion === 'string' ? parsed.pendingVersion : null,
          holdVersion: typeof parsed.holdVersion === 'string' ? parsed.holdVersion : null,
          updatedAt: typeof parsed.updatedAt === 'number' ? parsed.updatedAt : null,
          lastError: typeof parsed.lastError === 'string' ? parsed.lastError : null,
          lastCheckAt: typeof parsed.lastCheckAt === 'number' ? parsed.lastCheckAt : null,
        }
      }
    } catch { /* 首次运行或文件损坏：用默认值 */ }
    return state
  }

  function saveState() {
    try {
      mkdirSync(dataDir, { recursive: true })
      const temp = stateFile + '.tmp'
      writeFileSync(temp, JSON.stringify(state, null, 2) + '\n')
      renameSync(temp, stateFile)
    } catch (error) {
      log('failed to persist update state: ' + error.message)
    }
  }

  function appendLog(entry) {
    try {
      mkdirSync(dataDir, { recursive: true })
      writeFileSync(logFile, JSON.stringify(Object.assign({ ts: now() }, entry)) + '\n', { flag: 'a' })
    } catch { /* 日志失败不影响更新本身 */ }
  }

  function diskVersion() {
    try {
      const pkg = JSON.parse(readFileSync(join(packageDir, 'package.json'), 'utf8'))
      return typeof pkg.version === 'string' ? pkg.version : null
    } catch { return null }
  }

  async function fetchLatestRelease() {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), timeoutMs)
    try {
      const response = await fetchImpl(UPDATE_REGISTRY_ORIGIN + '/' + PACKAGE_NAME + '/latest', {
        headers: { accept: 'application/json' },
        signal: controller.signal,
      })
      if (!response.ok) return null
      const body = await response.json()
      if (!body || typeof body.version !== 'string') return null
      // 纵深防御：版本号会被拼进下载地址、写进状态文件、并参与版本比对，只接受规范 x.y.z。
      if (parseSemver(body.version) === null) return null
      const integrity = body.dist && typeof body.dist.integrity === 'string' ? body.dist.integrity : null
      // 拿不到校验值就不更新：宁可停在当前版本，也不去装一个无法验证的包 ——
      // 本模块会替换自己的全部文件，校验链上不允许有"静默跳过"的分支。
      // npm 对已发布版本始终提供 dist.integrity，缺失只可能是应答被动了手脚。
      if (!integrity) return null
      return { version: body.version, integrity }
    } catch {
      return null
    } finally {
      clearTimeout(timer)
    }
  }

  async function downloadTarball(version) {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), timeoutMs)
    try {
      const url = UPDATE_REGISTRY_ORIGIN + '/' + PACKAGE_NAME + '/-/' + PACKAGE_NAME + '-' + version + '.tgz'
      const response = await fetchImpl(url, { headers: { accept: 'application/octet-stream' }, signal: controller.signal })
      if (!response.ok) throw new Error('download failed: http ' + response.status)
      const buffer = Buffer.from(await response.arrayBuffer())
      if (buffer.length === 0) throw new Error('download failed: empty body')
      if (buffer.length > maxBytes) throw new Error('download failed: too large (' + buffer.length + ' bytes)')
      return buffer
    } finally {
      clearTimeout(timer)
    }
  }

  // 备份目录只保留最近若干份，避免长期堆积占用户空间。
  function pruneBackups() {
    try {
      const names = readdirSync(backupRoot).filter((name) => name !== 'previous').sort()
      for (const name of names.slice(0, Math.max(0, names.length - keepBackups))) {
        rmSync(join(backupRoot, name), { recursive: true, force: true })
      }
    } catch { /* 目录不存在即无需清理 */ }
  }

  async function performUpdate(target, manual) {
    const tarball = await downloadTarball(target.version)
    const files = extractPackageFiles(tarball)
    verifyPayload(files, { integrity: target.integrity, version: target.version, tarball })
    // 用户打开设置页后，即使启动时的自动下载已经开始，也不得在当前页面替换插件文件。
    if (!manual && !autoInstallAllowed()) return false
    const result = applyPayload(files, { packageDir, backupDir: join(backupRoot, target.version), log })
    pruneBackups()
    return !!result
  }

  async function runOnce(options) {
    const manual = !!(options && options.manual)
    const force = !!(options && options.force)
    // 2026-09-26：「看一眼」与「装上去」必须是两个动作。
    // 用户点「检查更新」只是想确认有没有新版，而本引擎从前的 runOnce 只有一条路 —— 检查、下载、
    // 替换一气做完，于是「检查更新」按钮等于「立即安装」（用户原话：「点了一下就直接装好了」）。
    // mode:'check' 在确认远端确实更高之后立刻返回：不下载、不替换、不碰备份、不记 lastError
    // （除非这次检查本身失败），因此它对磁盘是纯读的。
    const checkOnly = !!(options && options.mode === 'check')
    const latest = await fetchLatestRelease()
    state.lastCheckAt = now()
    if (!latest) {
      state.lastError = manual ? 'check-failed' : state.lastError
      saveState()
      appendLog({ event: 'check-failed' })
      return Object.assign({}, state, { latest: null })
    }
    // 只升不降：等于或低于运行中版本一律不动
    if (compareSemver(latest.version, runningVersion) <= 0) {
      // 这里绝不抹掉 pendingVersion。它同时承担两个身份：① 「刚替换到磁盘的版本」；
      // ② 回滚时定位备份目录的唯一线索。升级成功→用户重启→运行版本追平 latest，重启后
      // 8 秒的这次检查就会走到本分支；若在此清空，用户「新版有问题想回滚」时逃生门已被焊死
      // （rollback() 会返回 nothing-to-roll-back）。「待重启」由 UI 用 diskVersion 与 runningVersion
      // 是否相等判定，不依赖本字段被清空 —— 2026-09-25 由 tests/test-self-update.mjs 抓出。
      state.lastError = null
      saveState()
      return Object.assign({}, state, { latest: latest.version })
    }
    if (checkOnly) {
      // 到这里已经证明「远端确实比在跑的版本高」，检查的使命就结束了。
      // 上一次检查的失败记录在这里清掉（网络恢复了）；更新失败的记录必须留着 ——
      // 「上次更新失败」是界面上的逃生门依据，不能被一次顺利的检查顺手抹掉。
      if (state.lastError && describeUpdateError(state.lastError) === 'check-failed') state.lastError = null
      saveState()
      return Object.assign({}, state, { latest: latest.version, checkedOnly: true })
    }
    // 用户回滚过的版本不再装回来（自动与手动都跳过）；更高版本照常。force 是「我就要这个版本」的
    // 显式表达（设置页的「允许更新到 X」按钮），只有它能把暂缓解除。
    if (state.holdVersion && latest.version === state.holdVersion && !force) {
      saveState()
      return Object.assign({}, state, { latest: latest.version, skipped: 'held' })
    }
    if (diskVersion() === latest.version) {
      // 磁盘已是新版：等用户重启，别重复下载。
      // 这里**不能**再挂 `&& !manual`：手动点「检查更新」只表示「用户在自动关掉时授权下载」，
      // 不是「绕过防重」—— 原来那样写会让手动方式下连点几次就重复下载、重复替换、多留几份备份
      // （2026-09-25 第三轮用户问「更新到底实现没有」时顺手查出来的）。
      state.pendingVersion = latest.version
      state.lastError = null
      saveState()
      return Object.assign({}, state, { latest: latest.version })
    }
    if (!state.autoUpdate && !manual) {
      saveState()
      return Object.assign({}, state, { latest: latest.version, skipped: 'auto-disabled' })
    }
    if (!manual && !autoInstallAllowed()) {
      saveState()
      return Object.assign({}, state, { latest: latest.version, skipped: 'page-visited' })
    }
    try {
      if (!await performUpdate(latest, manual)) {
        saveState()
        return Object.assign({}, state, { latest: latest.version, skipped: 'page-visited' })
      }
      state.pendingVersion = latest.version
      // 装上了一个「不等于暂缓版本」的新版：暂缓自动解除（回滚过的那个旧版本已被越过）
      state.holdVersion = null
      state.updatedAt = now()
      state.lastError = null
      saveState()
      appendLog({ event: 'updated', version: latest.version })
    } catch (error) {
      // 状态里只存代号（界面据此翻译成人话），原始报错写进日志供排查。
      const raw = error && error.message ? error.message : 'update-failed'
      state.lastError = describeUpdateError(raw)
      saveState()
      appendLog({ event: 'update-failed', version: latest.version, kind: state.lastError, message: raw })
    }
    return Object.assign({}, state, { latest: latest.version })
  }

  return {
    loadState,
    getState() {
      return Object.assign({}, state, {
        runningVersion,
        diskVersion: diskVersion(),
        updated: state.pendingVersion !== null && state.pendingVersion !== runningVersion,
        // 失败原因额外给出代号：界面据此翻译成人话。历史 state 文件里存的是原始报错，
        // 由 describeUpdateError 现场归一，因此老数据同样能显示成人话。
        lastErrorKind: state.lastError ? describeUpdateError(state.lastError) : null,
      })
    },
    // 检查与安装共用一条流水线（runOnce 内部按 mode 分支），各自去重：
    //   run()               → 安装（全自动模式的启动流程；有新版就装）
    //   run({ mode: 'check' }) → 只检查（用户点「检查更新」；对磁盘纯读）
    //   run({ manual: true })  → 安装（用户点「更新到 X」；自动方式关掉时的显式授权）
    run(options) {
      const slot = options && options.mode === 'check' ? 'check' : 'install'
      // 启动自动更新在途时，用户确认的手动安装必须随后真正执行，不能复用自动任务的跳过结果。
      if (slot === 'install' && options && options.manual && inFlight.install) {
        return inFlight.install.then(() => this.run(options))
      }
      if (inFlight[slot]) return inFlight[slot]
      const pending = runOnce(options).finally(() => { inFlight[slot] = null })
      inFlight[slot] = pending
      return pending
    },
    setAutoUpdate(enabled) {
      state.autoUpdate = enabled !== false
      saveState()
      return this.getState()
    },
    // 回滚：把最近一次成功更新的备份恢复回去（供新版启动异常时人工兜底）。
    // 同时把被回滚掉的版本记入 holdVersion —— 否则重启后 8 秒的自动检查会把它装回来，
    // 逃生门等于白开。解除方式是设置页的「允许更新到 X」（runUpdateCheck 带 force）。
    rollback() {
      const target = state.pendingVersion
      if (!target) return { restored: false, reason: 'nothing-to-roll-back' }
      const backupDir = join(backupRoot, target)
      if (!existsSync(backupDir)) return { restored: false, reason: 'no-backup' }
      const before = listPayloadFiles(backupDir)
      const current = listPayloadFiles(packageDir)
      const result = rollbackPayload({ packageDir, backupDir, before, written: current })
      state.pendingVersion = null
      state.holdVersion = target
      state.updatedAt = now()
      state.lastError = null
      saveState()
      appendLog({ event: 'rolled-back', version: target, restored: result.restored.length })
      return { restored: true, version: target, holdVersion: target, files: result.restored.length }
    },
    _internal: { fetchLatestRelease, downloadTarball, performUpdate, listPayloadFiles },
  }
}
