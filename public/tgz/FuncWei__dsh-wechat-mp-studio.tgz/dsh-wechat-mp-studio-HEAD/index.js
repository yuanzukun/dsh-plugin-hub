// dsh-wechat-mp-studio — skill provider plugin.
//
// Registers a single bundled skill `wechat-mp-studio` on the DeepSeek Harness
// skills registry (ctx.skills). The skill body, references, scripts, and
// templates all ship inside this package under skills/wechat-mp-studio/ and
// resolve relative to that directory.
//
// Zero runtime dependencies: only node: builtins are imported.
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'

const PROVIDER_NAME = 'wechat-mp-studio'
const SKILL_DIR_URL = new URL('./skills/wechat-mp-studio/', import.meta.url)
const SKILL_BODY_URL = new URL('./skills/wechat-mp-studio/SKILL.md', import.meta.url)
const SKILL_DIR = fileURLToPath(SKILL_DIR_URL)

const RESOURCE_BASE = { kind: 'directory', path: SKILL_DIR }
const INVOCATION = { modelInvocable: true, userInvocable: true }

const DESCRIPTION = [
  '微信公众号内容生产工作台。',
  '当以下任一情形出现时使用：运营微信公众号并要写周期性内容（图文文章或小绿书/图片消息）；',
  '要防止内容被判「低创作度」或正在整改恢复推荐；',
  '要生成公众号封面（2.35:1 横幅）或正文配图（1080x1440）并用 OCR 验收图上文字；',
  '要把内容同步到公众号草稿箱（文章或小绿书），或排查同步失败；',
  '要为问候/祝福/知识/家常类公众号设计互动引导与转发钩子。',
].join('')

/** @typedef {import('@deepseek-ai/dsh-skill').SkillCandidate} SkillCandidate */
/** @typedef {import('@deepseek-ai/dsh-skill').SkillDefinition} SkillDefinition */
/** @typedef {import('@deepseek-ai/dsh-skill').SkillProvider} SkillProvider */

/** @type {SkillCandidate} */
const CANDIDATE = {
  name: 'wechat-mp-studio',
  description: DESCRIPTION,
  invocation: INVOCATION,
  provider: PROVIDER_NAME,
  source: 'bundled',
  resourceBase: RESOURCE_BASE,
  rank: 300,
  locator: SKILL_BODY_URL,
}

/** @type {SkillProvider} */
const provider = {
  name: PROVIDER_NAME,
  list: () => Promise.resolve([CANDIDATE]),
  async get(candidate) {
    /** @type {SkillDefinition} */
    return {
      name: candidate.name,
      description: candidate.description,
      invocation: candidate.invocation,
      provider: PROVIDER_NAME,
      source: 'bundled',
      resourceBase: RESOURCE_BASE,
      content: await readFile(SKILL_BODY_URL, 'utf8'),
    }
  },
}

/** Cordis plugin name. */
export const name = 'wechat-mp-studio'
/** Service required to register the bundled provider. */
export const inject = ['skills']

/**
 * Register the bundled `wechat-mp-studio` provider on `ctx.skills`.
 * @param {import('@deepseek-ai/cordis').Context} ctx - Cordis context.
 */
export function apply(ctx) {
  ctx.skills.registerProvider(() => provider)
}
