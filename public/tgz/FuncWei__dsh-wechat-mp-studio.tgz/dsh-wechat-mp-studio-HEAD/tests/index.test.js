import test from 'node:test'
import assert from 'node:assert/strict'
import * as plugin from '../index.js'

test('exports the cordis plugin contract', () => {
  assert.equal(plugin.name, 'wechat-mp-studio')
  assert.deepEqual(plugin.inject, ['skills'])
  assert.equal(typeof plugin.apply, 'function')
})

test('provider registers exactly one loadable skill', async () => {
  let registered = null
  const ctx = {
    skills: {
      registerProvider(factory) {
        registered = factory()
      },
    },
  }
  plugin.apply(ctx)
  assert.ok(registered, 'provider should be registered on ctx.skills')
  assert.equal(registered.name, 'wechat-mp-studio')

  const candidates = await registered.list()
  assert.equal(candidates.length, 1)
  const candidate = candidates[0]
  assert.equal(candidate.name, 'wechat-mp-studio')
  assert.equal(candidate.provider, 'wechat-mp-studio')
  assert.ok(candidate.description.length > 20, 'description must be a real catalog entry')
  assert.equal(candidate.invocation.modelInvocable, true)
  assert.equal(candidate.invocation.userInvocable, true)
  assert.equal(candidate.resourceBase.kind, 'directory')

  const definition = await registered.get(candidate)
  assert.equal(definition.name, 'wechat-mp-studio')
  assert.ok(definition.content.includes('微信公众号内容生产工作台'), 'skill body must load')
  assert.ok(definition.content.includes('红线清单'), 'skill body must contain the pipeline checklist')
})
