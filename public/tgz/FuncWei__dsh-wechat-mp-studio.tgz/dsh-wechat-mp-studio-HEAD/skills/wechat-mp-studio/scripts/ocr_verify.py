#!/usr/bin/env python3
"""OCR 验收：验证生成图片上的祝福语无错字、居中完整。

双后端：
  auto    本机是 macOS 用原生 Vision（零 key 零联网）；否则用 MiniMax M3 视觉 API
  macos   强制 macOS Vision（需要 swift 编译器，Xcode CLT 自带）
  minimax 强制 MiniMax M3（走 OpenCode Go 的 /chat/completions 兼容端点）

用法:
  python3 ocr_verify.py --image cover.png --expected "今天也要记得添杯水"
  python3 ocr_verify.py --image content.png --expected "..." --backend minimax

环境变量（minimax 后端）:
  OPENCODE_GO_API_KEY  OpenCode Go key（MiniMax M3 视觉走这个端点）
  OCR_BASE_URL         默认 https://opencode.ai/zen/go/v1
  OCR_MODEL            默认 minimax-m3

退出码: 0=文字一致（通过）；1=不一致（重生成）；2=工具错误。
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import platform
import re
import subprocess
import sys
import tempfile
import urllib.request
from pathlib import Path

SWIFT_OCR_SOURCE = r"""
import Foundation
import Vision
import AppKit

let path = CommandLine.arguments[1]
guard let img = NSImage(contentsOfFile: path),
      let tiff = img.tiffRepresentation,
      let rep = NSBitmapImageRep(data: tiff),
      let cg = rep.cgImage else {
    FileHandle.standardError.write("cannot load image\n".data(using: .utf8)!)
    exit(2)
}
let request = VNRecognizeTextRequest { req, _ in
    guard let obs = req.results as? [VNRecognizedTextObservation] else { return }
    for o in obs {
        if let top = o.topCandidates(1).first {
            print(top.string)
        }
    }
}
request.recognitionLevel = .accurate
request.recognitionLanguages = ["zh-Hans", "en-US"]
let handler = VNImageRequestHandler(cgImage: cg, options: [:])
try? handler.perform([request])
"""


def normalize(text: str) -> str:
    """归一化：去空白/标点/常见混淆，保留汉字字母数字。"""
    text = text.replace(" ", "").replace("\u3000", "")
    text = re.sub(r"[\s，。！？、；：,.!?;:'\"“”‘’\-—_·()\[\]{}【】]", "", text)
    # 常见 OCR 混淆对：模型容易把「上」写成「山」这类不在归一化处理，逐字比才对
    return text


def ocr_macos(image_path: str) -> str:
    """macOS Vision OCR，返回识别出的全部文本。"""
    with tempfile.NamedTemporaryFile("w", suffix=".swift", delete=False) as f:
        f.write(SWIFT_OCR_SOURCE)
        swift_file = f.name
    try:
        proc = subprocess.run(
            ["swift", swift_file, image_path],
            capture_output=True, text=True, timeout=120,
        )
    finally:
        os.unlink(swift_file)
    if proc.returncode != 0:
        sys.exit(f"[ocr_verify] Vision 失败（swift 不可用？）: {proc.stderr.strip()[:300]}")
    return proc.stdout


def ocr_minimax(image_path: str, api_key: str, base_url: str, model: str) -> str:
    """MiniMax M3 视觉 OCR（OpenCode Go 兼容端点）。"""
    b64 = base64.b64encode(Path(image_path).read_bytes()).decode()
    ext = Path(image_path).suffix.lstrip(".").lower() or "png"
    mime = "jpeg" if ext in ("jpg", "jpeg") else ext
    payload = {
        "model": model,
        "max_tokens": 1024,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/{mime};base64,{b64}"},
                    },
                    {
                        "type": "text",
                        "text": "逐字写出这张图片上的所有文字，只输出文字本身，不要任何解释。",
                    },
                ],
            }
        ],
    }
    req = urllib.request.Request(
        base_url.rstrip("/") + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")
        sys.exit(f"[ocr_verify] HTTP {exc.code}: {body[:400]}")
    except urllib.error.URLError as exc:
        sys.exit(f"[ocr_verify] 网络错误: {exc.reason}")
    return data["choices"][0]["message"]["content"]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--image", required=True, help="要验收的图片路径")
    parser.add_argument("--expected", required=True, help="期望的祝福语文字")
    parser.add_argument("--backend", choices=["auto", "macos", "minimax"], default="auto")
    parser.add_argument("--base-url", default=os.environ.get("OCR_BASE_URL", "https://opencode.ai/zen/go/v1"))
    parser.add_argument("--model", default=os.environ.get("OCR_MODEL", "minimax-m3"))
    args = parser.parse_args()

    if not Path(args.image).is_file():
        sys.exit(f"[ocr_verify] 图片不存在: {args.image}")

    backend = args.backend
    if backend == "auto":
        backend = "macos" if platform.system() == "Darwin" else "minimax"

    if backend == "macos":
        recognized = ocr_macos(args.image)
    else:
        api_key = os.environ.get("OPENCODE_GO_API_KEY", "")
        if not api_key:
            sys.exit("[ocr_verify] minimax 后端需要 OPENCODE_GO_API_KEY")
        recognized = ocr_minimax(args.image, api_key, args.base_url, args.model)

    expected_norm = normalize(args.expected)
    recognized_norm = normalize(recognized)
    print(f"[ocr_verify] 期望: {args.expected!r}")
    print(f"[ocr_verify] 识别: {recognized.strip()!r}")

    if expected_norm and expected_norm in recognized_norm:
        print("[ocr_verify] ✅ 通过：期望文字完整出现在图中")
        sys.exit(0)
    # 逐字对比给出诊断
    if expected_norm and recognized_norm:
        common = ""
        for a, b in zip(expected_norm, recognized_norm):
            if a == b:
                common += a
            else:
                break
        print(f"[ocr_verify] 公共前缀: {common!r}")
    print("[ocr_verify] ❌ 不通过：图上文字与期望不一致（错字/漏字/杂字），请重生成")
    sys.exit(1)


if __name__ == "__main__":
    main()
