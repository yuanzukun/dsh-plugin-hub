#!/usr/bin/env python3
"""生成公众号封面（原生 2.35:1 超宽）与正文配图（1080x1440）。

调用任意 OpenAI 兼容的图片生成接口（gpt-image-1 / gpt-image-2 或自建代理）。
提示词模板内置了本 skill 的硬规则：
  - 封面把「超宽横幅 2.35:1」写进提示词，让模型原生出图，禁止补边/硬裁；
  - 图上文字带「笔画清晰端正、不要其他文字」防错字；
  - 图上只印当天那句独特祝福语，不印固定问候词。

用法:
  python3 generate_images.py cover --text "今天也要记得添杯水" --anchor "晨光里的茶杯热气"
  python3 generate_images.py post  --text "今天也要记得添杯水" --anchor "露珠叶脉" --out out/

环境变量:
  IMAGE_API_KEY    API key（也可用 --api-key 传入）
  IMAGE_BASE_URL   OpenAI 兼容端点，默认 https://api.openai.com/v1
  IMAGE_MODEL      模型名，默认 gpt-image-2
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import urllib.request
from pathlib import Path

DEFAULT_BASE_URL = "https://api.openai.com/v1"
DEFAULT_MODEL = "gpt-image-2"

# 封面：原生超宽横幅（模型会直出 ~1920x820，之后缩到 900x383）。
COVER_SIZE_HINT = (
    "超宽横幅构图，宽高比 2.35:1（电影宽银幕比例，横向非常宽，画面内容铺满左右两侧）"
)
# 正文图/小绿书：3:4 竖版。
POST_SIZE_HINT = "竖版 3:4 构图，主体占半、留白 25%–35% 放字"

TEXT_RULES = (
    "文字要求：粗黑体大字，笔画清晰端正、不要其他文字，"
    "居中排版，实色字加单层描边，不超过两行"
)


def build_prompt(kind: str, anchor: str, text: str, style: str) -> str:
    """按 kind 组装提示词，锚点/祝福语/风格可填。"""
    size_hint = COVER_SIZE_HINT if kind == "cover" else POST_SIZE_HINT
    parts = [
        anchor,
        style,
        f"画面上的文字：{text}",
        TEXT_RULES,
        "整体：明亮暖色、中高饱和、具象丰盈、自然实景质感，" + size_hint,
    ]
    return "\n".join(p for p in parts if p)


def call_image_api(base_url: str, api_key: str, model: str, prompt: str,
                   size: str | None) -> list[bytes]:
    """调用 /images/generations，返回解码后的 PNG 字节列表。"""
    payload: dict = {
        "model": model,
        "prompt": prompt,
        "n": 1,
        "image_format": "png",
        "quality": "high",
    }
    if size:
        payload["size"] = size
    req = urllib.request.Request(
        base_url.rstrip("/") + "/images/generations",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=300) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")
        sys.exit(f"[generate_images] HTTP {exc.code}: {body[:500]}")
    except urllib.error.URLError as exc:
        sys.exit(f"[generate_images] 网络错误: {exc.reason}")
    images: list[bytes] = []
    for item in data.get("data", []):
        b64 = item.get("b64_json")
        if b64:
            images.append(base64.b64decode(b64))
        url = item.get("url")
        if url:
            with urllib.request.urlopen(url, timeout=120) as resp:
                images.append(resp.read())
    if not images:
        sys.exit("[generate_images] 接口未返回图片（检查 model/key/额度）")
    return images


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="kind", required=True)
    for k, help_text in (("cover", "封面（原生 2.35:1 超宽横幅）"),
                         ("post", "正文图/小绿书（1080x1440，3:4）")):
        p = sub.add_parser(k, help=help_text)
        p.add_argument("--text", required=True, help="图上文字：当天那句独特祝福语（12–20 字）")
        p.add_argument("--anchor", required=True, help="今日语义锚点：画面主体描述")
        p.add_argument("--style", default="写实摄影质感、晨光侧照",
                       help="视觉语言定位（默认：写实摄影质感、晨光侧照）")
        p.add_argument("--out", default=".", help="输出目录（默认当前目录）")
    parser.add_argument("--api-key", default=os.environ.get("IMAGE_API_KEY", ""))
    parser.add_argument("--base-url", default=os.environ.get("IMAGE_BASE_URL", DEFAULT_BASE_URL))
    parser.add_argument("--model", default=os.environ.get("IMAGE_MODEL", DEFAULT_MODEL))
    parser.add_argument("--size", default=None,
                        help="显式尺寸（如 1024x1536）；缺省时靠提示词驱动原生比例")
    args = parser.parse_args()

    if not args.api_key:
        sys.exit("[generate_images] 缺 API key：设 IMAGE_API_KEY 或传 --api-key")

    prompt = build_prompt(args.kind, args.anchor, args.text, args.style)
    print(f"[generate_images] model={args.model} kind={args.kind}")
    print(f"[generate_images] prompt:\n{prompt}\n")

    images = call_image_api(args.base_url, args.api_key, args.model, prompt, args.size)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    for i, img in enumerate(images, start=1):
        suffix = "cover" if args.kind == "cover" else "content"
        path = out_dir / f"{suffix}.png" if len(images) == 1 else out_dir / f"{suffix}-{i}.png"
        path.write_bytes(img)
        print(f"[generate_images] 已保存 {path}（{len(img) // 1024} KB）")

    print("[generate_images] 下一步：用 ocr_verify.py 验收图上文字")


if __name__ == "__main__":
    main()
