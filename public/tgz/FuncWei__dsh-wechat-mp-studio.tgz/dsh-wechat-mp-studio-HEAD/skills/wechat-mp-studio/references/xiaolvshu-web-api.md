# 小绿书（图片消息 / newspic）草稿网页接口实测

> 微信公众号内部网页接口，无公开文档。以下参数来自开源实现逆向 + 真机验证（2026 实测通过）。**接口随时可能变化，使用前先按 §四 的方法重新调研验证。**

## 一、认知前提

- **小绿书 = 图片消息（newspic）**，也叫「贴图」或「图片/文字」：多张图片（≤20 张，首张即封面）+ 标题（≤64 字）+ 描述（≤1000 字，3:4 竖版最佳）。
- **网页接口路线不需要 AppSecret**：复用浏览器登录会话（和「文章同步助手」类工具同路线）。
- 官方 API（`draft/add` + `article_type: newspic`）需要 AppID+Secret+IP 白名单——仅作备选。
- **文章和小绿书共用同一个保存接口**：`operate_appmsg?sub=create&type=77`，区别全在表单参数。

## 二、网页接口（无需 AppSecret，复用浏览器会话）

### 1. 上传图片到素材库（scene=5 动态场景）

```
POST https://mp.weixin.qq.com/cgi-bin/filetransfer
  ?action=upload_material&f=json&scene=5&writetype=doublewrite&groupid=1
  &ticket_id=<userName>&ticket=<ticket>&svr_time=<ts>&token=<token>&lang=zh_CN&seq=<ts>&t=<random>
multipart/form-data: type, id, name, lastModifiedDate, size, file
```

- **scene=5 = 动态/小绿书**；文章用 scene=8。传错 scene 会导致 fileid 拿不到或素材类型不符。
- 返回：`{ base_resp: {err_msg: "ok"}, cdn_url: "https://mmbiz.qpic.cn/...", content: "<fileid数字字符串>" }`
- `content` 字段 = file_id（**必须转数字**），`cdn_url` = 图片 URL。

### 2. 创建小绿书草稿

```
POST https://mp.weixin.qq.com/cgi-bin/operate_appmsg
  ?t=ajax-response&sub=create&type=77&token=<token>&lang=zh_CN
Content-Type: application/x-www-form-urlencoded
```

关键表单字段（**粗体为必须**）：

| 字段 | 值 | 说明 |
|---|---|---|
| token / lang / f=json / ajax=1 / random | — | 公共参数 |
| AppMsgId | 空 | 新建时为空 |
| count / articlenum | 1 | |
| data_seq / operate_from=Chrome / isnew | 0 / Chrome / 0 | |
| autosave_log | true | |
| pre_timesend_set | 0 | |
| **title0** | ≤64 字 | 标题 |
| is_user_title0 | 1 | |
| author0 / writerid0 / fileid0 | 空 / 0 / 空 | |
| digest0 / auto_gen_digest0 | 空 / 1 | |
| **content0** | ≤1000 字 | 描述正文 |
| sourceurl0 | 空 | |
| need_open_comment0 / only_fans_can_comment0 / only_fans_days_can_comment0 | 1 / 0 / 0 | 评论开关 |
| reply_flag0 / not_pay_can_comment0 / auto_elect_comment0 / auto_elect_reply0 / open_fansmsg0 | 2 / 0 / 0 / 0 / 0 | |
| **share_imageinfo0** | `{"list":[{url, file_id, width, height, theme_color:"rgb(187,166,135)", disable_theme:0, disable_live:0, cdn_url}]}` | 图片列表，**file_id 数字** |
| **share_page_type0** | "8"（有图）/"0"（无图） | |
| music_id0 / video_id0 / voteid0 / voteismlt0 / supervoteid0 / vid_type0 | 空 | |
| show_cover_pic0 / shortvideofileid0 / copyright_type0 / releasefirst0 / platform0 / reprint_permit_type0 / allow_reprint0 / allow_reprint_modify0 / original_article_type0 / ori_white_list0 / free_content0 / fee0 / ad_id0 | 空/0 | |
| **guide_words0** | 同 content0 | |
| is_share_copyright0 / share_copyright_url0 / source_article_type0 / reprint_recommend_title0 / reprint_recommend_content0 / share_video_id0 | 0 / 空 | |
| dot0 | `{}` | |
| share_voice_id0 / insert_ad_mode0 | 空 | |
| categories_list0 | `[]` | |
| compose_info0 | `{"list":""}` | |
| is_pay_subscribe0 / pay_fee0 / pay_preview_percent0 / pay_desc0 / pay_album_info0 | 0 / 空 | |
| appmsg_album_info0 | `{"appmsg_album_infos":[]}` | |
| open_keyword_ad0 | 1 | |
| audio_info0 / danmu_pub_type0_0 / mp_video_info0 | 空 / 0 / `{"list":[]}` | |
| is_set_sync_to_finder0 / sync_to_finder_cover0 / sync_to_finder_cover_source0 / import_to_finder0 / import_from_finder_export_id0 | 0 / 空 | |
| **style_type0** | **"3"** | 小绿书样式开关 |
| sticker_info0 | `{}` | |
| **new_pic_process0** | **"1"** | 新图片流程 |
| disable_recommend0 / claim_source_type0 / msg_index_id0 / convert_to_image_share_page0 / convert_from_image_share_page0 / multi_picture_cover0 | 0 / 空 | |
| **is_auto_type_setting** | **"3"** | 自动类型设置 |
| **save_type** | **"1"** | 保存为图片消息 |
| **isneedsave** | **"0"** | |

返回：`{ appMsgId: "100000xxx" }`。编辑 URL：

```
https://mp.weixin.qq.com/cgi-bin/appmsg?t=media/appmsg_edit&action=edit&type=77&appmsgid=<id>&token=<token>&lang=zh_CN
```

**注意**：`style_type0=3 + new_pic_process0=1 + is_auto_type_setting=3 + save_type=1 + isneedsave=0` 这组开关决定草稿存成「图片消息」而非普通文章。**漏掉任何一个都可能存成文章形态。**

## 三、官方 API 备选（需要 AppSecret）

网页接口不可用时才走这条路：

```
POST https://api.weixin.qq.com/cgi-bin/draft/add?access_token=<token>
{"articles":[{"article_type":"newspic","title":"...","content":"...","need_open_comment":1,"only_fans_can_comment":0,"image_info":{"image_list":[{"image_media_id":"<永久素材media_id>"}]}}]}
```

- 图片先 `material/add_material`（type=image）传**永久素材**拿 media_id（临时素材不行，报 40007）。
- 需要 AppID+Secret 换 access_token + IP 白名单（否则 40164）。
- 个人订阅号 `draft/add` 可用，但 `freepublish/submit`（发布）仅认证企业号可用——**发布环节无论哪条路线都要人工**，本链路只到草稿箱。

## 四、动手前必须先调研（不猜参数）

网页接口是内部接口、无公开文档，参数随时变。动手前：

1. Sourcegraph 代码搜索：`curl -s "https://sourcegraph.com/.api/search/stream?q=context:global+operate_appmsg" -H "Accept: text/event-stream"`
2. 找实测过的开源实现（已知参考：`leaperone/MultiPost-Extension` 的 `src/sync/dynamic/weixin.ts`，小绿书完整表单；`huanz/wechat-mp-hack` 老版逆向）。
3. 官方 API 文档（developers.weixin.qq.com）确认参数结构作对照。
4. 每改一次表单，用真实草稿箱验证形态（图片卡片 vs 文章排版）。

## 五、验证要点与踩坑

- 接口返回 appMsgId 只代表保存成功；**形态是否正确要看后台草稿箱**（图片卡片 vs 文章排版）。
- 本地图片路径必须转 base64 data URI（`data:image/png;base64,...`），扩展 service worker 无法 fetch 本地文件。
- 图片体积 >2MB 容易卡审核，压缩到 2MB 内；`64737` 报错与图片大小无关，是标题/描述字段触发的，二分排障。
- 图床外链会被防盗链卡死：图必须用本地图或 data URI。
- **只推草稿、不自动群发**；定时群发由人工在后台设置。
- **同步报 `200040`（保存受限，实测）**：是微信对「重复提交同一内容」的频控——判定只看**标题+描述**、跟图片无关、且**不随短时冷却解除**（实测等 8 小时仍报）。解法：**标题+描述换个措辞再推即可秒过**；别傻等冷却，别连环重推（越推越锁）。
