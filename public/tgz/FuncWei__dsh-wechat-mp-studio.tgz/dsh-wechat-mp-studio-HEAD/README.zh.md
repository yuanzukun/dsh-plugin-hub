# dsh-wechat-mp-studio

> 微信公众号内容生产工作台 —— DeepSeek Harness 插件
> WeChat Official Account content studio for DeepSeek Harness

[English](./README.md) | 中文

**第一个把「防低创作度」实战方法论开源的公众号内容生产插件。** 沉淀自真实账号被平台判定「低创作度」→ 整改 → 恢复的完整实战，而不是纸上规则。

## 解决什么问题

周期性更新的公众号（早安问候、晚安、节气、知识卡片、家常感悟、祝福卡……）最大的风险不是「写得不好」，而是被平台判**低创作度**、关闭公域推荐。平台打的是【品类 × 形态 × 频率 × 固定词】组合信号：

- 每天同样的固定问候词大字、固定标题前缀、固定话题标签；
- 一天多篇同品类内容互相稀释；
- 结构套路化：五篇一个骨架 = 低创作度信号。

这个插件给出一套可执行的**反同质化生产流水线**：结构签名轮换写作法 + 增量铁律 + 配图视觉基线 + OCR 验收 + 互动引导 + 草稿箱同步（含小绿书内部接口实测参数）。

## 功能清单

| 能力 | 内容 |
|---|---|
| 结构轮换写作法 | 六变量结构签名、反近期选择、防同质化自查六项、防 AI 味语言纪律 |
| 增量铁律 | 删除测试/替换测试、七类话头来源轮换 |
| 低创作度整改实战 | 病根分析、整改方向、恢复节奏、常见建议取舍原则（脱敏） |
| 视觉基线 | 祝福图「一眼喜庆二眼清楚三眼可信」量化标准、成图自查八项 |
| 配图管线 | 封面原生 2.35:1 提示词模板、图上文字防错字规则、OCR 验收 SOP、故障排查 |
| 互动引导 | 一个主动作 + 至多一个次动作、固定话术、红线、文末三段式 |
| 发布链路 | 小绿书（newspic）草稿网页接口实测参数：上传 scene=5、`operate_appmsg type=77` 完整表单与形态开关 |
| 可执行脚本 | `generate_images.py`（内置模板出图）、`ocr_verify.py`（macOS Vision / MiniMax M3 双后端验收） |
| 日志模板 | 结构日志/配图日志模板（轮换记账本） |

## 安装

```sh
# 从 GitHub 安装（推荐：可审查源码）
dsh plugin --profile web add github:FuncWei/dsh-wechat-mp-studio

# pnpm ≥10 首次安装会要求允许该包的 prepare 构建（纯 JS 包，无构建步骤，直接允许）
# 或从 npm 安装预构建版本
dsh plugin --profile web add dsh-wechat-mp-studio
```

安装后，模型会在需要时自动加载 `wechat-mp-studio` skill（写公众号内容、生成配图、同步草稿、排查低创作度时）。也可在对话中直接点名：「用 wechat-mp-studio 帮我写今天的推送」。

## 使用方法

1. **写内容**：告诉模型你的账号定位（受众/人设/变现），让它按 skill 流水线产出文案+结构签名。
2. **出图**：`python3 skills/wechat-mp-studio/scripts/generate_images.py cover --text "当天祝福语" --anchor "画面主体"`（`IMAGE_API_KEY` 环境变量指向 gpt-image 兼容端点）。
3. **验收**：`python3 skills/wechat-mp-studio/scripts/ocr_verify.py --image cover.png --expected "当天祝福语"`。
4. **同步草稿**：按 `references/xiaolvshu-web-api.md` 推草稿箱（只推草稿，群发人工确认）。
5. **记日志**：结构日志/配图日志各追加一行，下一篇做反近期选择。

## 目录结构

```
skills/wechat-mp-studio/
├── SKILL.md                              # 操作入口：八步流水线 + 红线清单
├── references/
│   ├── anti-homogenization.md            # 结构轮换写作法（六变量/反近期/自查六项）
│   ├── low-creativity-recovery.md        # 低创作度整改实战（病根/方向/恢复节奏）
│   ├── visual-baseline.md                # 祝福图视觉基线（量化标准/成图自查八项）
│   ├── gpt-image-2-prompts.md            # 配图提示词模板/防错字/OCR 验收 SOP
│   ├── xiaolvshu-web-api.md              # 小绿书草稿网页接口实测参数
│   └── interaction-and-hooks.md          # 互动引导与转发钩子
├── scripts/
│   ├── generate_images.py                # 封面/正文图生成（模板内置）
│   └── ocr_verify.py                     # 图上文字 OCR 验收（双后端）
└── templates/
    ├── structure-log.md                  # 结构日志模板
    └── image-log.md                      # 配图日志模板
```

## 免责声明

- 微信公众号网页接口（`operate_appmsg` 等）是**内部接口、无公开文档、随时可能变化**；本仓库参数为某一时点的实测记录，使用前请按 `references/xiaolvshu-web-api.md` §四 的方法重新调研验证。
- 本插件提供方法论与工具，不承诺任何流量/推荐结果；请遵守平台规则与相关法律法规。
- 涉及第三方服务（gpt-image、MiniMax、OpenCode Go）的脚本需要你自己的 key/额度。

## License

[MIT](./LICENSE)
