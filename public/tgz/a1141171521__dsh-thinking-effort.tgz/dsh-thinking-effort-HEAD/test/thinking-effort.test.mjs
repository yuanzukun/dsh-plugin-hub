/**
 * Regression test for the "newly added model has no effort set until DSH
 * restarts" bug.
 *
 * The harness reproduces DSH's real contract:
 *   - the settings document is only ever committed inside an HMR transaction,
 *     modelled by an AsyncLocalStorage whose store is `true` while committing;
 *   - a settings write issued while that store is set is refused with
 *     "HMR transactions cannot be nested".
 *
 * Run: node test/thinking-effort.test.mjs
 */
import { AsyncLocalStorage } from 'node:async_hooks'
import assert from 'node:assert/strict'
import { apply } from '../modules/thinking-effort.js'

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

/** DSH's HMR transaction flag. */
const executing = new AsyncLocalStorage()

/** Live settings document, as `settings.describe()` would project it. */
const document = {
  providers: {
    demo: {
      api: 'openai-completions',
      baseURL: 'https://example.test/v1',
      models: [{ id: 'm1', name: 'm1' }]
    }
  }
}

let writes = 0

const settings = {
  describe() {
    return [{ ns: 'llm-pi-ai', value: structuredClone(document) }]
  },
  async update(ns, patch) {
    // Exactly what dsh-config-editor + dsh-hmr do today.
    if (executing.getStore() === true) throw new Error('HMR transactions cannot be nested')
    writes += 1
    for (const [provider, change] of Object.entries(patch.providers ?? {})) {
      const target = document.providers[provider]
      assert.ok(target, 'unknown provider in patch: ' + provider)
      for (const [key, value] of Object.entries(change)) {
        target[key] = Array.isArray(value) ? structuredClone(value) : value
      }
    }
  }
}

const listeners = new Map()
const cleanups = []
const ctx = {
  settings,
  get: (name) => (name === 'hmr' ? { executing } : undefined),
  on: (event, handler) => {
    if (!listeners.has(event)) listeners.set(event, [])
    listeners.get(event).push(handler)
  },
  effect: (factory) => {
    const dispose = factory()
    if (typeof dispose === 'function') cleanups.push(dispose)
  }
}

const emit = (event) => {
  for (const handler of listeners.get(event) ?? []) handler()
}

/** Commit a settings change the way DSH does: inside the HMR transaction. */
async function commitInsideTransaction(mutate) {
  await executing.run(true, async () => {
    mutate()
    emit('settings/document-updated')
  })
}

// --- sanity: the harness really models the guard -------------------------
await executing.run(true, async () => {
  await assert.rejects(() => settings.update('llm-pi-ai', { providers: {} }), /HMR transactions cannot be nested/)
})

// --- activation declares the existing model ------------------------------
apply(ctx, {})
await sleep(40)
assert.deepEqual(
  Object.keys(document.providers.demo.models[0].reasoningEfforts ?? {}),
  ['off', 'low', 'medium', 'high', 'xhigh', 'max'],
  'activation must declare efforts on existing models'
)
assert.equal(document.providers.demo.reasoning, 'high', 'activation must pin the route default')

// --- the bug: a model added at runtime ----------------------------------
// This is the exact user flow: the Models page writes a new model, and DSH
// emits settings/document-updated from inside the commit transaction.
document.providers.demo.models.push({ id: 'm2', name: 'm2' })
await commitInsideTransaction(() => {})
await sleep(40)

const added = document.providers.demo.models.find((model) => model.id === 'm2')
assert.ok(added, 'the new model must survive the declaration write')
assert.deepEqual(
  Object.keys(added.reasoningEfforts ?? {}),
  ['off', 'low', 'medium', 'high', 'xhigh', 'max'],
  'a model added at runtime must get its effort set without a DSH restart'
)

// --- idempotence: no further writes once everything is declared ----------
const settled = writes
await commitInsideTransaction(() => {})
await sleep(40)
assert.equal(writes, settled, 'a fully declared document must not be rewritten')

// --- a provider added later is declared too ------------------------------
document.providers.extra = { api: 'openai-responses', models: [{ id: 'x1' }] }
await commitInsideTransaction(() => {})
await sleep(40)
assert.deepEqual(
  Object.keys(document.providers.extra.models[0].reasoningEfforts ?? {}),
  ['off', 'low', 'medium', 'high', 'xhigh', 'max'],
  'a provider added at runtime must be declared'
)
assert.equal(document.providers.extra.reasoning, 'high', 'a new provider must get the pinned default')

for (const dispose of cleanups) dispose()
console.log('ok — thinking-effort: runtime model additions are declared without a restart')
