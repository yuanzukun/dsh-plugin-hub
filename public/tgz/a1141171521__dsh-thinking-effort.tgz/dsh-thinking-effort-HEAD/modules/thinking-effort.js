/**
 * dsh-thinking-effort — 推理档位模块
 *
 * Declares reasoning effort levels for OpenAI-compatible third-party models
 * configured under `llm-pi-ai`, so the built-in model selector shows its
 * Effort row for those models — the same shape built-in deepseek models
 * have — and pins a route-level default effort so re-selecting a model keeps
 * your chosen level instead of falling back to the provider default.
 *
 * Background: DSH's llm service only accepts a reasoning effort for a model
 * whose adapter reports it. The pi-ai adapter reports efforts only when the
 * model profile declares `reasoningEfforts`. Third-party (custom) models
 * usually omit that declaration, so the selector hides the Effort row and any
 * explicit effort is rejected with `UNSUPPORTED_REASONING_EFFORT`. This module
 * fills the gap: on activation (and whenever the settings document changes) it
 * patches each OpenAI-compatible model served by either the
 * `openai-completions` or `openai-responses` adapter (adding missing levels
 * without touching existing ones), and pins the route-level `reasoning`
 * default to {@link DEFAULT_EFFORT} (config `defaultEffort`, default `high`).
 *
 * The route-level `reasoning` value is what the adapter reports as each
 * model's `defaultEffort`; the built-in model selector sends that value when
 * a model row is picked, so switching away and back keeps your choice rather
 * than clearing it.
 *
 * Timing: the `llm-pi-ai` settings namespace is registered by the pi-ai
 * adapter plugin, which may activate after this module. Activation therefore
 * polls briefly for the namespace, and the `settings/document-updated`
 * listener keeps declarations in sync afterwards.
 *
 * Settings API: this module reads through whichever surface the running DSH
 * exposes — the legacy `settings.get(ns)`, or the current
 * `settings.describe()` descriptor list (matched tolerantly, because the
 * namespace may be reported as the bare entry id or an `include:`-prefixed
 * one). Writes always go through `settings.update`.
 *
 * Hot-reload caveat: DSH serializes configuration replacement through an
 * `AsyncLocalStorage` HMR transaction, and a settings write issued from inside
 * one is refused with "HMR transactions cannot be nested". A plugin activated
 * by a hot install (plugin manager / live enable) runs inside such a
 * transaction, so its write is deferred to the next non-transactional
 * opportunity: a later settings-document change (any namespace), or the next
 * DSH start. The refusal is reported with an actionable warning instead of
 * being swallowed.
 */

/** Effort set declared for models that declare none. The wire spelling equals
 * the level id (DeepSeek-protocol gateways accept these). `off: null` means
 * "supported, send nothing". Levels the deployment endpoint rejects (e.g.
 * `minimal`) are left out; see README.
 */
const EFFORTS = { off: null, low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh', max: 'max' }

/** Route-level default effort pinned when the provider declares none of its own. */
const DEFAULT_EFFORT = 'high'

/** How long to keep polling for the `llm-pi-ai` namespace at activation. */
const NAMESPACE_POLL_MS = 250
const NAMESPACE_POLL_ATTEMPTS = 24

/** The HMR transaction guard's rejection, recognized for an actionable warning. */
const HMR_NESTING = 'HMR transactions cannot be nested'

export const inject = ['settings']

/** Namespace string actually used by the last successful read. */
let lastNamespace = 'llm-pi-ai'

/** Whether the last write was refused by the HMR transaction guard. */
let refusedByHmr = false

/**
 * Read one settings namespace across the legacy and current DSH APIs.
 * @param settings - the injected settings service.
 * @param namespace - the namespace to read.
 * @returns the resolved section, or undefined while unavailable.
 */
function readSettingsSection(settings, namespace) {
  if (settings === undefined || settings === null) return undefined
  if (typeof settings.get === 'function') return settings.get(namespace)
  if (typeof settings.describe !== 'function') return undefined
  const described = settings.describe()
  const list = Array.isArray(described)
    ? described
    : (described !== null && typeof described === 'object' ? Object.values(described) : [])
  const descriptor = list.find((entry) => {
    if (entry === undefined || entry === null || typeof entry !== 'object') return false
    const id = String(entry.ns ?? entry.id ?? '')
    return id === namespace || id === 'include:' + namespace || id.endsWith(':' + namespace)
  })
  if (descriptor === undefined) return undefined
  lastNamespace = String(descriptor.ns ?? descriptor.id ?? namespace)
  return descriptor.value ?? descriptor.resolved ?? descriptor.data ?? descriptor.section
}

export function apply(ctx, config) {
  const defaultEffort = config?.defaultEffort ?? DEFAULT_EFFORT

  const declare = async () => {
    try {
      const section = readSettingsSection(ctx.settings, 'llm-pi-ai')
      if (section === undefined || section === null || typeof section !== 'object') return
      const providers = section.providers
      if (providers === undefined || providers === null || typeof providers !== 'object') return
      const patch = {}
      let touched = false
      for (const provider of Object.keys(providers)) {
        const profile = providers[provider]
        if (profile === undefined || profile === null || typeof profile !== 'object') continue
        if (profile.api !== 'openai-completions' && profile.api !== 'openai-responses') continue
        const providerPatch = {}
        // Pin the route-level default effort so re-selecting a model keeps
        // the level. Only when the deployment left it unset.
        if (profile.reasoning === undefined && defaultEffort !== undefined) {
          providerPatch.reasoning = defaultEffort
        }
        const models = Array.isArray(profile.models) ? profile.models : undefined
        if (models !== undefined) {
          const next = models.map((entry) => {
            if (entry === undefined || entry === null || typeof entry !== 'object') return entry
            const existing = entry.reasoningEfforts
            // Explicitly disabled reasoning: leave the model alone.
            if (existing === false) return entry
            if (existing === undefined || existing === null) {
              return Object.assign({}, entry, { reasoningEfforts: EFFORTS })
            }
            // Already declared: add missing levels only, preserving the
            // deployment's own values (including `null` pins).
            let missing = false
            const merged = Object.assign({}, existing)
            for (const level of Object.keys(EFFORTS)) {
              if (!(level in merged)) {
                merged[level] = EFFORTS[level]
                missing = true
              }
            }
            if (!missing) return entry
            return Object.assign({}, entry, { reasoningEfforts: merged })
          })
          const changed = next.some((entry, index) => entry !== models[index])
          if (changed) providerPatch.models = next
        }
        if (Object.keys(providerPatch).length === 0) continue
        patch[provider] = providerPatch
        touched = true
      }
      if (!touched) return
      await ctx.settings.update(lastNamespace, { providers: patch })
      refusedByHmr = false
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      if (message.includes(HMR_NESTING)) {
        if (!refusedByHmr) {
          refusedByHmr = true
          console.warn('[dsh-thinking-effort] DSH refused the reasoning-effort write because this plugin was activated'
            + ' inside a hot-reload transaction (' + HMR_NESTING + '). The declaration is applied by the next settings'
            + ' change or DSH start — restart DSH to apply it now.')
        }
        return
      }
      console.error('[dsh-thinking-effort] failed to declare reasoning efforts', message)
    }
  }

  // The pi-ai adapter registers the `llm-pi-ai` namespace during activation;
  // poll briefly for it before the first declaration attempt.
  let attempts = NAMESPACE_POLL_ATTEMPTS
  let timer = null
  const poll = () => {
    const section = readSettingsSection(ctx.settings, 'llm-pi-ai')
    if (section !== undefined && section !== null && typeof section === 'object') {
      void declare()
      return
    }
    attempts -= 1
    if (attempts <= 0) {
      console.warn('[dsh-thinking-effort] llm-pi-ai settings namespace never appeared; declarations deferred to settings/document-updated')
      return
    }
    timer = setTimeout(poll, NAMESPACE_POLL_MS)
  }
  poll()

  // Re-declare whenever the settings document changes. Any namespace counts:
  // a write issued from outside the HMR transaction (the settings UI, the CLI,
  // another plugin) is exactly the non-transactional context an earlier
  // refused write needs in order to succeed.
  ctx.on('settings/document-updated', () => {
    void declare()
  })

  // Stop the poll timer on teardown.
  ctx.effect(() => () => {
    if (timer !== null) clearTimeout(timer)
  })
}
