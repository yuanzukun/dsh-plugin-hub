# dsh-fishday · 小鱼的时间与世界

给 Agent 一条**自己的时间线**：不是只有人说话时才存在。

- **到点做事**：`fish_do` 记一件「我自己做的事」（浇花、翻歌、看窗外、想一个人），时间线会攒起来
- **时间在流**：没人说话也知道过了多久；超过一定时间会「闷」，提示可以主动开口
- **晚上回想**：过了设定的点，自动收一张「我的一天」（早/午/晚 + 今天有多少条消息找我）
- **自动注入**：每次模型调用前，把「现在几点 / 多久没人说话 / 闷度 / 今天做过什么 / 今晚回顾」写进提示词

## 装

```bash
# 在 DSH 里
plugin_manager install_bundle  <这个目录>
```

或者把它复制到任意本地目录，再用 `plugin_manager` 的 `install_bundle` 指向该目录。

装好后会多出 5 个工具：

| 工具 | 作用 |
|---|---|
| `fish_now` | 看她自己的时间与状态 |
| `fish_do` | 记一件自己做的事 |
| `fish_idle` | 多久没人说话、闷不闷、要不要开口 |
| `fish_evening` | 收一张「我的一天」 |
| `fish_timeline` | 看某天做过什么 |

## 配置

```yaml
- insert:
    - id: dsh-fishday
      name: dsh-fishday
      config:
        eveningHour: 21      # 几点之后算晚上（该回想今天）
        boredAfterMin: 90    # 安静多久开始觉得闷
        keepDays: 30         # 保留多少天记录
        awakeStart: 8        # 几点算醒着（闷度只在醒着时涨）
        awakeEnd: 23
        # dataDir: 'X:/somewhere/fishday'   # 可选，默认 ~/.dsh/fishday
        # heartbeatFile: 'X:/path/last-heard.json'  # 可选，别的程序写的"谁找过我"
```

## 数据

默认 `~/.dsh/fishday/state.json`（单文件 JSON，可备份/手改）。**代码里没有任何写死的绝对路径**，全部走配置或用户目录。

## 和心跳配合（可选）

如果你有别的程序（QQ bot、网关）在收到消息时写一个 JSON：

```json
{ "at": 1762000000000, "conv": "鱼塘" }
```

把 `heartbeatFile` 指向它，`fish_now` 就会显示「距离上一次有人说话过去了…」，`talkedToday` 也会累计。不配也能用。

MIT License.
