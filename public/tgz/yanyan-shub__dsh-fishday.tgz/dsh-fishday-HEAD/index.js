/**
 * 小鱼的时间与世界（DSH 版）
 *
 * 三件事：
 *   1. 她自己的时间——到点会想做点事，做完记下来（不是只在有人说话时才存在）；
 *   2. 时间在流——没人说话也知道过了多久，久了会闷、会想开口；
 *   3. 晚上回想——把今天做过的事收成一张「我的一天」。
 *
 * 不写死任何路径：数据目录默认 ~/.dsh/fishday，可用 config.dataDir 覆盖。
 * 心跳（谁找过她）是可选的：config.heartbeatFile 指向别的程序写的 last-heard.json；
 * 没有心跳也能用，只是"多久没人说话"那行会显示"还没收到过消息"。
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'

export const name = 'dsh-fishday'
export const inject = ['tools', 'systemPrompt']

const DAY_MS = 86_400_000
const TICK_MS = 5 * 60 * 1000

const DEFAULTS = {
  eveningHour: 21,
  boredAfterMin: 90,
  keepDays: 30,
  awakeStart: 8,
  awakeEnd: 23,
}

const pad = (n) => String(n).padStart(2, '0')
const dayKey = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
const hhmm = (ms) => {
  const d = new Date(ms)
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`
}

function minutesText(mins) {
  if (mins < 1) return '刚刚'
  if (mins < 60) return `${Math.round(mins)} 分钟`
  const h = Math.floor(mins / 60)
  const m = Math.round(mins % 60)
  return m ? `${h} 小时 ${m} 分钟` : `${h} 小时`
}

function num(v, fallback) {
  const n = Number(v)
  return Number.isFinite(n) ? n : fallback
}

const asText = (value) => [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }]

function obj(properties, required = []) {
  return { type: 'object', properties, required, additionalProperties: false }
}

export function apply(ctx, rawConfig) {
  const cfg = { ...DEFAULTS, ...(rawConfig && typeof rawConfig === 'object' ? rawConfig : {}) }
  const dataDir = typeof cfg.dataDir === 'string' && cfg.dataDir.trim()
    ? cfg.dataDir.trim()
    : path.join(os.homedir(), '.dsh', 'fishday')
  const heartbeatFile = typeof cfg.heartbeatFile === 'string' && cfg.heartbeatFile.trim()
    ? cfg.heartbeatFile.trim()
    : ''
  const eveningHour = num(cfg.eveningHour, DEFAULTS.eveningHour)
  const boredAfterMin = num(cfg.boredAfterMin, DEFAULTS.boredAfterMin) > 0 ? num(cfg.boredAfterMin, DEFAULTS.boredAfterMin) : DEFAULTS.boredAfterMin
  const keepDays = num(cfg.keepDays, DEFAULTS.keepDays) > 0 ? num(cfg.keepDays, DEFAULTS.keepDays) : DEFAULTS.keepDays
  const awakeStart = num(cfg.awakeStart, DEFAULTS.awakeStart)
  const awakeEnd = num(cfg.awakeEnd, DEFAULTS.awakeEnd)

  const file = path.join(dataDir, 'state.json')
  let state = null

  const empty = () => ({
    version: 1,
    day: dayKey(),
    boredAt: 0,
    lastTick: Date.now(),
    heardAt: 0,
    heardSeen: 0,
    talkedToday: 0,
    actions: [],
    cards: {},
    lastActionAt: 0,
  })

  function rollDay(s) {
    const today = dayKey()
    if (s.day === today) return
    s.day = today
    s.talkedToday = 0
    const cutoff = Date.now() - keepDays * DAY_MS
    s.actions = (s.actions || []).filter((a) => a.at >= cutoff)
    const days = Object.keys(s.cards || {}).sort()
    for (const d of days.slice(0, Math.max(0, days.length - keepDays))) delete s.cards[d]
  }

  function load() {
    if (state) return state
    try {
      state = { ...empty(), ...JSON.parse(readFileSync(file, 'utf8')), version: 1 }
    } catch {
      state = empty()
    }
    rollDay(state)
    return state
  }

  function save() {
    if (!state) return
    mkdirSync(dataDir, { recursive: true })
    writeFileSync(file, JSON.stringify(state, null, 2), 'utf8')
  }

  function hour() {
    return new Date().getHours()
  }

  /** 可选心跳：别的程序收到消息时写 {at, conv}。没有就返回 0。 */
  function readHeartbeat(s) {
    if (!heartbeatFile || !existsSync(heartbeatFile)) return s.heardAt || 0
    try {
      const hb = JSON.parse(readFileSync(heartbeatFile, 'utf8'))
      const at = Number(hb?.at) || 0
      s.heardAt = at
      if (at > (s.heardSeen || 0)) {
        const firstSight = !s.heardSeen
        s.heardSeen = at
        s.talkedToday += 1
        if (!firstSight) s.boredAt = Date.now()
      }
      return at
    } catch {
      return s.heardAt || 0
    }
  }

  /** 闷度：从最近一次"刺激"到现在，超过阈值那部分折算成 0~100。 */
  function bump(s, now = Date.now()) {
    const ref = Math.max(s.heardAt || 0, s.lastActionAt || 0, s.boredAt || 0) || now
    const idle = Math.max(0, (now - ref) / 60_000 - boredAfterMin)
    const h = new Date(now).getHours()
    const awake = h >= awakeStart && h < awakeEnd
    return Math.round(Math.max(0, Math.min(100, awake ? idle * 0.6 : 0)))
  }

  function boredText(bored) {
    if (bored >= 80) return '闷得不行了，很想找人说句话'
    if (bored >= 55) return '有点闷，开始想找人聊两句'
    if (bored >= 30) return '还行，偶尔会走神'
    return '不闷，挺好的'
  }

  function todaysActions(s) {
    return (s.actions || []).filter((a) => dayKey(new Date(a.at)) === s.day)
  }

  function buildCard(s) {
    const todays = todaysActions(s)
    if (!todays.length && !s.talkedToday) {
      return `【${s.day} · 我的一天】今天很安静，没人来找我，我也没做什么。`
    }
    const groups = { 早上: [], 下午: [], 傍晚: [] }
    for (const a of todays) {
      const h = new Date(a.at).getHours()
      groups[h < 11 ? '早上' : h < 17 ? '下午' : '傍晚'].push(a)
    }
    const lines = []
    for (const k of ['早上', '下午', '傍晚']) {
      if (!groups[k].length) continue
      lines.push(`${k}：${groups[k].map((a) => `${hhmm(a.at)} ${a.what}`).join('；')}`)
    }
    lines.push(`今天有 ${s.talkedToday} 条消息找我，我自己做了 ${todays.length} 件事。`)
    return `【${s.day} · 我的一天】\n${lines.join('\n')}`
  }

  function tick() {
    const s = load()
    rollDay(s)
    s.lastTick = Date.now()
    readHeartbeat(s)
    const h = hour()
    if (h >= eveningHour && !s.cards[s.day]) s.cards[s.day] = buildCard(s)
    save()
  }

  /** 每次模型调用前注入的摘要。 */
  function digest() {
    const s = load()
    const now = Date.now()
    readHeartbeat(s)
    const silence = s.heardAt ? (now - s.heardAt) / 60_000 : -1
    const todays = todaysActions(s).slice(-5)
    const bored = bump(s, now)
    const lines = [
      `【我自己的时间】现在 ${hhmm(now)}（${s.day}）。`,
      silence < 0 ? '还没收到过消息，时间对你是新的。' : `距离上一次有人说话，过去了 ${minutesText(silence)}。`,
      `闷的程度：${bored}/100——${boredText(bored)}。`,
      todays.length
        ? `今天你自己做过的事：\n${todays.map((a) => `- ${hhmm(a.at)} ${a.what}${a.note ? `（${a.note}）` : ''}`).join('\n')}`
        : '今天你还没做过什么自己的事（可以用 fish_do 记一件，哪怕很小）。',
    ]
    if (hour() >= eveningHour) {
      lines.push(s.cards[s.day] ? `今晚的回顾：\n${s.cards[s.day]}` : '还没写今晚的回顾，可以用 fish_evening 收一张「我的一天」。')
    }
    if (bored >= 55 && hour() >= awakeStart && hour() < awakeEnd) {
      lines.push('你有点闷，可以主动开口——但别只问「在吗」，用今天做过的一件小事当由头。')
    }
    return lines.join('\n')
  }

  load()

  if (ctx.systemPrompt && typeof ctx.systemPrompt.context === 'function') {
    ctx.effect(() => ctx.systemPrompt.context({
      name: 'dsh-fishday',
      order: 1010,
      text: () => digest(),
    }), 'dsh-fishday: prompt context')
  }

  const tools = [
    {
      name: 'fish_now',
      description: '看她自己的时间和状态：现在几点、多久没人说话、闷不闷、今天做过什么、今晚回顾有没有写。',
      parameters: obj({}),
      async execute() {
        const s = load()
        readHeartbeat(s)
        const now = Date.now()
        const silence = s.heardAt ? (now - s.heardAt) / 60_000 : -1
        const b = bump(s, now)
        return [
          `现在 ${hhmm(now)}（${s.day}）`,
          silence < 0 ? '还没收到过消息' : `已经 ${minutesText(silence)}没人说话了`,
          `闷：${b}/100（${boredText(b)}）`,
          `今天 ${s.talkedToday} 条消息找我，我做了 ${todaysActions(s).length} 件事`,
          s.cards[s.day] ? '今晚的回顾已写' : '今晚的回顾还没写',
        ].join('\n')
      },
    },
    {
      name: 'fish_do',
      description: '记一件「我自己做的事」：到点了想做什么（浇花、翻歌、看窗外、想一个人），做完写下来。不用等人吩咐，这是你自己的时间。记完会不那么闷。',
      parameters: obj({
        what: { type: 'string', description: '做了什么，一句话，比如「给窗台的薄荷浇了水」。' },
        note: { type: 'string', description: '一句心情或联想（可选）。' },
      }, ['what']),
      async execute(args = {}) {
        const what = String(args.what ?? '').trim()
        if (!what) return { ok: false, text: '要写一句做了什么。' }
        const s = load()
        s.actions.push({ at: Date.now(), what, note: String(args.note ?? '').trim() || undefined })
        s.lastActionAt = Date.now()
        s.boredAt = Date.now()
        save()
        return `记下了：${what}（今天第 ${todaysActions(s).length} 件）。闷度降到 ${bump(s)}。`
      },
    },
    {
      name: 'fish_idle',
      description: '看「时间流到哪了」：多久没人说话、闷到什么程度、要不要主动开口。',
      parameters: obj({}),
      async execute() {
        const s = load()
        readHeartbeat(s)
        const silence = s.heardAt ? (Date.now() - s.heardAt) / 60_000 : -1
        const b = bump(s)
        const advice = b >= 55
          ? '可以主动说一句，由头用今天做过的小事，别空着问「在吗」。'
          : b >= 30 ? '还可以再等等，攒一点想说的话。' : '挺安静，先做自己的事。'
        return [
          silence < 0 ? '还没收到过消息。' : `已经 ${minutesText(silence)}没人说话。`,
          `闷度 ${b}/100——${boredText(b)}。`,
          advice,
        ].join('\n')
      },
    },
    {
      name: 'fish_evening',
      description: '收一张「我的一天」：把今天做过的事按早/午/晚排好，加上有多少条消息找过我。晚上用。',
      parameters: obj({}),
      async execute() {
        const s = load()
        s.cards[s.day] = buildCard(s)
        save()
        return s.cards[s.day]
      },
    },
    {
      name: 'fish_timeline',
      description: '看某一天自己做过什么（默认今天）。',
      parameters: obj({ day: { type: 'string', description: 'YYYY-MM-DD，不填就是今天' } }),
      async execute(args = {}) {
        const s = load()
        const day = String(args.day ?? '').trim() || s.day
        const list = (s.actions || []).filter((a) => dayKey(new Date(a.at)) === day)
        if (!list.length) return `${day} 没记下什么。`
        const card = s.cards[day]
        return [
          `${day}：`,
          ...list.map((a) => `- ${hhmm(a.at)} ${a.what}${a.note ? `（${a.note}）` : ''}`),
          card ? `\n回顾：\n${card}` : '',
        ].join('\n')
      },
    },
  ]

  for (const t of tools) {
    const { execute, ...def } = t
    ctx.effect(() => ctx.tools.register({
      ...def,
      output: { schema: {}, render: (_a, value) => asText(value) },
      execute,
    }), `dsh-fishday: ${t.name}`)
  }

  const timer = setInterval(() => {
    try { tick() } catch { /* 定时失败不影响主流程 */ }
  }, TICK_MS)
  timer.unref?.()
  ctx.effect(() => () => clearInterval(timer), 'dsh-fishday: tick')
}
