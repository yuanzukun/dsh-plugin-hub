/**
 * dsh-monitor 类型声明
 */
import type { Context } from '@deepseek-ai/cordis';

export interface TokenUsage {
    inputTokens: number;
    outputTokens: number;
    cacheReadTokens?: number;
    cacheWriteTokens?: number;
    reasoningTokens?: number;
}

export interface MonitorStats {
    date: string;
    tokens: number;
    cost: number;
    sessions: number;
    avgPerSession: number;
    inputTokens: number;
    outputTokens: number;
    cacheReadTokens: number;
    peakCost: number;
    valleyCost: number;
}

export interface MonitorPayload {
    ok: true;
    isValley: boolean;
    tier: 'peak' | 'valley';
    stats: MonitorStats;
    quota: { used: number; limit: number; pct: number };
    prices: {
        model: string;
        peak: { cached: number; uncached: number; output: number };
        offpeak: { cached: number; uncached: number; output: number };
    };
    demoMode: false;
    updatedAt: number;
    peakHours: string;
    valleyHours: string;
}

export declare function apply(ctx: Context): void;
export declare const inject: string[];
export declare const name: string;
export default { apply, inject, name };
