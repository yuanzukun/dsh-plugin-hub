/**
 * 样式：dci- 前缀，注入一次。
 * 工具行/菜单/发送按钮的属性值逐条复刻官方 InputBar.module.css 与
 * PermissionSelect/ModelSelection 的触发器与菜单（含 --dsw-* 主题变量，
 * 随宿主主题自动切换）；编辑器/设置等自有部分用 currentColor 适配。
 * 主题/皮肤插件兼容约定：官方走 --dsw-* token 的取值这里也走 token（皮肤
 * 改 token 即全盘跟随）；官方写死的（发送钮前景 #fff、小圈 tools 紫）同样
 * 写死保持逐值对齐——多跟一分就会在换肤下与官方脱队。
 */

import { markdownStyles } from './markdown';
import { heavyMarkdownStyles } from './markdown/heavy';

const STYLE_ID = 'dsh-codinput-styles';

const CSS = `
/* ===== 拖文件入卡片：落区提示（粘贴/拖入附件入口）===== */
.dci-card[data-drop] { outline: 2px solid var(--dsw-alias-state-business-primary, currentColor); outline-offset: -2px; }

/* ===== 侧栏重复标签提示（同会话第二个 Codinput 标签不渲染第二个编辑面）===== */
.dci-side-notice { box-sizing: border-box; width: 100%; padding: 24px 16px; text-align: center;
  color: var(--dsw-alias-label-tertiary, currentColor); font-size: 13px; line-height: 20px; }

/* ===== 官方卡片（InputBar .card）：编辑器+预览+工具行合入一张卡 ===== */
.dci-surface { display: flex; flex-direction: column; gap: 6px; min-width: 0; color: inherit; }
/* 宽度默认继承空白态（hero）卡宽（官方 max-width 变量，回退 760px）：
   会话态（无包裹约束）不再被拉满，左右居中；拖边调节后由内联 max-width 接管。 */
.dci-card { box-sizing: border-box; width: 100%; max-width: var(--dsh-composer-card-max-width, 760px); margin-inline: auto;
  background: var(--dsw-specific-input-major, color-mix(in srgb, currentColor 4%, transparent));
  box-shadow: var(--dsw-elevation-soft, none); font-size: var(--dsh-content-font-size, 14px);
  line-height: calc(24px + var(--dsh-content-font-delta, 0px));
  border: 0; border-radius: var(--dsw-radius-panel, 22px); flex-direction: column; gap: 0; padding-top: 4px; display: flex; position: relative; min-width: 0; }
/* 主模式 surface 复刻官方 composer root：侧向 clearance 内缩 + 底部 4px，
   卡片与数据行由数据行自身 padding-top 定距（官方 root 无 gap，dock 上边距 4px）。
   side/float 形态自带铺满布局，不参与。 */
.dci-surface:not([data-side]):not([data-float]) { padding: 0 var(--dsh-composer-side-clearance, 0px) 4px; align-items: center; gap: 0; }
/* 卡片边缘调节把手：左右调宽、上下调高（对称灵敏度），悬停显形。 */
.dci-rip { position: absolute; z-index: 60; touch-action: none; }
.dci-rip[data-axis="y"] { left: 12px; right: 12px; height: 9px; cursor: ns-resize; }
.dci-rip[data-axis="y"][data-side="top"] { top: -4px; }
.dci-rip::after { content: ''; position: absolute; inset: 0; margin: auto; border-radius: 3px; background: transparent; transition: background 0.12s; }
.dci-rip[data-axis="y"]::after { height: 3px; width: 44px; }
.dci-rip:hover::after, .dci-rip[data-dragging="true"]::after { background: var(--dsw-alias-state-business-primary, currentColor); }
.dci-accessory { align-items: center; gap: 2px; padding: 6px 12px 0; display: flex; }
.dci-iconbtn {
  display: inline-flex; align-items: center; justify-content: center;
  width: 26px; height: 26px; padding: 0; border: none; border-radius: 6px;
  background: transparent; color: inherit; opacity: 0.62; cursor: pointer;
}
.dci-iconbtn:hover { opacity: 1; background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 8%, transparent)); }
.dci-iconbtn[data-on="true"] { opacity: 1; background: var(--dsw-alias-interactive-bg-hover-solid, color-mix(in srgb, currentColor 12%, transparent)); }
.dci-iconbtn:disabled { opacity: 0.3; cursor: default; background: transparent; }

/* ===== 编辑区（无框，由卡片承担外观）===== */
/* 拖过上下缘后 body 固定高（--dci-body-h），未拖时高度随内容、46vh 封顶。 */
.dci-body { position: relative; display: flex; gap: 0; min-height: 60px; max-height: var(--dci-body-max, 46vh); overflow: hidden; }
.dci-body[style*="--dci-body-h"] { height: var(--dci-body-h); }
/* 分屏：grid 等宽两栏（fr 计入 padding/border，两栏边界严格居中；flex
 * 会把预览栏的横向 padding 泄漏进空间分配，做不到对半）。行高必须
 * minmax(0,1fr)+两栏 min-height:0：隐式 auto 行随内容撑高、不受 max-height
 * 钳制，内容一高整行溢出被 overflow:hidden 裁掉，两栏都出不了滚动条。 */
.dci-body[data-split="true"] { display: grid; grid-template-columns: 1fr 1fr; grid-template-rows: minmax(0, 1fr); }
.dci-body[data-split="true"] > * { min-height: 0; }
/* 分屏同步滚动：只留编辑栏一个滚动条，预览栏藏起但滚轮仍可反向带动编辑器。 */
.dci-body[data-split="true"] .dci-preview { scrollbar-width: none; }
.dci-body[data-split="true"] .dci-preview::-webkit-scrollbar { display: none; }
.dci-body[data-split="true"] .dci-editor-wrap { border-right: 1px solid var(--dsw-alias-border-l2, color-mix(in srgb, currentColor 12%, transparent)); }
.dci-editor-wrap { position: relative; flex: 1 1 100%; min-width: 0; box-sizing: border-box; display: flex; flex-direction: column; }
.dci-editor-wrap[data-solo="true"] { flex-basis: 100%; }
.dci-cm-host { flex: 1; min-height: 0; overflow-y: auto; }
.dci-cm-host .cm-editor { height: 100%; background: transparent; }
.dci-pos { position: absolute; right: 10px; bottom: 6px; font-size: 11px; color: var(--dsw-alias-label-caption, currentColor); opacity: 0.75;
  pointer-events: none; font-variant-numeric: tabular-nums; z-index: 3; }

/* Markdown 排版（.dci-preview 预览排版 + .dci-md 扩展块）已迁到
   src/client/markdown/styles.ts，由本文件末尾拼接 markdownStyles 注入。 */

/* ===== 工具行（官方 0.2.2 InputBar .row / .tools / .modes / .trailing 逐值）=====
   row 兼作容器查询容器（官方 container-type:inline-size）：模型紧凑态、权限
   触发器 @container (width<=460px) 收起标签等官方子组件规则都按行宽求值。
   --dci-model-icon = 官方 primitives IconDataOutlineRegular（regular 描边 1、
   viewBox 16、fill+stroke 双 path，逐字取自宿主 app.asar 的 icon 表）。 */
.dci-row { flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 12px; min-width: 0; padding: 2px 8px 6px;
  display: flex; container-type: inline-size;
  --dci-model-icon: url("data:image/svg+xml,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2016%2016'%20fill%3D'none'%20stroke-width%3D'1'%3E%3Cpath%20d%3D'M7.8667%200.349609C8.96906%200.349634%2010.0601%200.481272%2011.0317%200.735352C11.9973%200.987845%2012.8453%201.362%2013.4644%201.84766C14.0744%202.32629%2014.507%202.95539%2014.5161%203.69336H14.5171V8.53516C14.0843%208.32076%2013.6108%208.17679%2013.1108%208.11816C13.1831%207.96848%2013.2162%207.82856%2013.2163%207.70312V5.76758C12.6269%206.16618%2011.8739%206.47995%2011.0317%206.7002C10.0602%206.95423%208.96896%207.08494%207.8667%207.08496C6.76461%207.08493%205.67411%206.95415%204.70264%206.7002C3.85994%206.48006%203.10694%206.1662%202.51709%205.76758V7.70312L2.521%207.78418C2.56374%208.19554%202.93361%208.74414%203.91357%209.23145C4.9281%209.73585%206.35004%2010.0371%207.8667%2010.0371C8.26373%2010.0371%208.6543%2010.0141%209.03271%209.97461C8.75596%2010.3799%208.54664%2010.8349%208.42041%2011.3232C8.23666%2011.3313%208.0518%2011.3369%207.8667%2011.3369C6.20108%2011.3369%204.57025%2011.01%203.33447%2010.3955C3.04163%2010.2499%202.76658%2010.0836%202.51709%209.90039V11.6738C2.51728%2012.1379%202.88589%2012.7556%203.92236%2013.292C4.93457%2013.8157%206.35342%2014.1289%207.8667%2014.1289C8.12318%2014.1289%208.37694%2014.1161%208.62646%2014.0986C8.82021%2014.5535%209.08999%2014.9682%209.41943%2015.3271C8.91285%2015.3934%208.39149%2015.4287%207.8667%2015.4287C6.19761%2015.4287%204.56379%2015.0869%203.32568%2014.4463C2.11244%2013.8185%201.21649%2012.8562%201.21631%2011.6738V3.76367C1.21595%203.74853%201.21438%203.733%201.21436%203.71777C1.21436%202.96917%201.65103%202.33053%202.26807%201.84668C2.88747%201.36112%203.73675%200.987685%204.70264%200.735352C5.67413%200.481376%206.76457%200.349636%207.8667%200.349609ZM7.8667%201.65039C6.86269%201.65042%205.88326%201.77028%205.03076%201.99316C4.17183%202.2176%203.50421%202.52956%203.06982%202.87012C2.65043%203.19909%202.52622%203.48898%202.51709%203.69336V3.74414C2.52719%203.94845%202.65185%204.23772%203.06982%204.56543C3.50425%204.90601%204.17172%205.21795%205.03076%205.44238C5.88326%205.66527%206.8627%205.78513%207.8667%205.78516C8.8707%205.78513%209.85015%205.66525%2010.7026%205.44238C11.5611%205.21787%2012.2286%204.9049%2012.6626%204.56445C13.0982%204.22252%2013.2163%203.9231%2013.2163%203.71777L13.2104%203.63574C13.1818%203.43623%2013.044%203.16941%2012.6626%202.87012C12.2286%202.52957%2011.5614%202.21773%2010.7026%201.99316C9.85009%201.77025%208.8708%201.65041%207.8667%201.65039Z'%20fill%3D'%23fff'%2F%3E%3Cpath%20d%3D'M12.8936%2010.0361L13.2061%2010.5566C13.2296%2010.5959%2013.2651%2010.6562%2013.3027%2010.707C13.3469%2010.7666%2013.4148%2010.8431%2013.5195%2010.9023C13.6244%2010.9617%2013.725%2010.9801%2013.7988%2010.9873C13.8619%2010.9934%2013.9318%2010.9932%2013.9775%2010.9932H14.6162L14.8896%2011.4502L14.5947%2011.9443C14.5698%2011.9859%2014.5312%2012.0483%2014.5029%2012.1084C14.4781%2012.1611%2014.4514%2012.2312%2014.4395%2012.3164L14.4326%2012.4072L14.4395%2012.4971C14.4514%2012.5825%2014.4781%2012.6532%2014.5029%2012.7061C14.5312%2012.7661%2014.5689%2012.8287%2014.5938%2012.8701L14.8896%2013.3633L14.6162%2013.8213H13.9775C13.9318%2013.8213%2013.8619%2013.821%2013.7988%2013.8271C13.7433%2013.8326%2013.6728%2013.8442%2013.5967%2013.875L13.5195%2013.9121C13.4148%2013.9714%2013.3469%2014.0478%2013.3027%2014.1074C13.265%2014.1583%2013.2296%2014.2186%2013.2061%2014.2578L12.8936%2014.7783H12.3115L11.999%2014.2578C11.9755%2014.2186%2011.9401%2014.1583%2011.9023%2014.1074C11.8693%2014.0628%2011.823%2014.0083%2011.7578%2013.959L11.6855%2013.9121L11.6074%2013.875C11.5316%2013.8445%2011.4615%2013.8325%2011.4062%2013.8271C11.3432%2013.821%2011.2733%2013.8213%2011.2275%2013.8213H10.5889L10.3135%2013.3633L10.6104%2012.8701C10.6352%2012.8287%2010.6739%2012.7661%2010.7021%2012.7061C10.7352%2012.6357%2010.7724%2012.534%2010.7725%2012.4072C10.7724%2012.2804%2010.7352%2012.1788%2010.7021%2012.1084C10.6739%2012.0483%2010.6353%2011.9859%2010.6104%2011.9443L10.3135%2011.4502L10.5889%2010.9932H11.2275C11.2733%2010.9932%2011.3432%2010.9934%2011.4062%2010.9873C11.4801%2010.9801%2011.5808%2010.9616%2011.6855%2010.9023C11.7903%2010.843%2011.8582%2010.7666%2011.9023%2010.707C11.94%2010.6562%2011.9755%2010.5959%2011.999%2010.5566L12.3115%2010.0361H12.8936Z'%20stroke%3D'%23fff'%20stroke-miterlimit%3D'10'%2F%3E%3C%2Fsvg%3E"); }
/* 官方 data-model-compact（observeControlRow）：隐藏模型文字/强度，显示图标。 */
.dci-row[data-model-compact] .dci-trigger[data-model] .dci-triggerLabel,
.dci-row[data-model-compact] .dci-trigger[data-model] .dci-triggerEffort { display: none; }
.dci-row[data-model-compact] .dci-trigger[data-model]::before { content: ''; flex: none; width: 16px; height: 16px;
  background-color: currentColor; -webkit-mask: var(--dci-model-icon) center / 16px 16px no-repeat;
  mask: var(--dci-model-icon) center / 16px 16px no-repeat; }
.dci-tools, .dci-modes, .dci-trailing { align-items: center; min-width: 0; display: flex; }
.dci-tools, .dci-modes { gap: 12px; }
.dci-trailing { flex: none; gap: 12px; margin-left: auto; }
@container (max-width: 560px) { .dci-tools, .dci-modes, .dci-trailing { gap: 8px; } }
/* 官方 [hidden] 兜底：.tools/.standardControls 的 display:flex 是类选择器，
   会盖过 UA 的 [hidden]{display:none}，官方 CSS 显式补同款规则。 */
.dci-tools[hidden], .dci-standard-controls[hidden] { display: none; }
.dci-trailing-active { flex: 1; margin-left: 0; }

/* ===== 语音输入座位（官方 .standardControls / .activity / .activityExpanded）=====
   按钮本体是官方 activity 槽位条目组件（Gyyz9a_* 样式由语音插件自带注入）；
   这里只负责座位：展开时 capture 行接管整行、左侧工具与模型控件让位
   （官方 hidden 属性隐藏，见 Toolbar）。
   注意：官方 renderSlot 即使槽位无占用者也会输出 data-slot 包装（display:contents），
   所以官方 .activity 永远不会命中 :empty ——实测（0.2.2 隔离宿主）无 voice 时
   activity 是 display:flex 的 0×0 flex item，仍占一个 row gap（官方 trailing=306.6；
   若隐藏则 294.6，少 12px）。因此这里不能加 :empty{display:none}；「旧宿主没有
   该槽位」的情况由 Toolbar 用 useSlotDeclaration 决定是否渲染座位。 */
.dci-standard-controls { align-items: center; min-width: 0; gap: 12px; display: flex; }
.dci-voice-seat { flex: none; align-items: center; display: flex; }
.dci-voice-seat-expanded { flex: 1; min-width: 0; }

/* 圆形图标按钮（官方 .add）*/
.dci-add { background: var(--dsw-specific-selector, color-mix(in srgb, currentColor 8%, transparent));
  width: 28px; height: 28px; color: var(--dsw-alias-label-primary, currentColor); cursor: pointer; border: none;
  border-radius: 999px; corner-shape: round; flex: none; place-items: center; display: grid; }
.dci-add:hover:not(:disabled) { background: var(--dsw-alias-interactive-bg-hover-solid, color-mix(in srgb, currentColor 14%, transparent)); }
.dci-add:disabled { opacity: 0.5; cursor: default; }

/* 下拉触发（官方 PermissionSelect / ModelSelect .trigger）。radius 官方走
 * --dsw-radius-sm，无 token 的旧宿主（0.1.5-rc.3）回退原 24px 视觉；
 * 模型触发器官方 font-weight 400（权限 500），经 [data-model] 区分。*/
.dci-trigger { min-width: 0; max-width: 220px; height: 28px; color: var(--dsw-alias-label-secondary, currentColor); cursor: pointer;
  background: transparent; border: none; border-radius: var(--dsw-radius-sm, 24px); outline: none; align-items: center; gap: 4px;
  padding: 0 4px 0 8px; font-size: 13px; font-weight: 500; line-height: 20px; display: inline-flex; }
.dci-trigger[data-model] { font-weight: 400; }
.dci-trigger:hover:not(:disabled) { background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 8%, transparent)); }
.dci-trigger:focus-visible { box-shadow: 0 0 0 2px var(--dsw-alias-border-l3, transparent); }
.dci-trigger:disabled { color: var(--dsw-alias-label-dimmed, currentColor); cursor: default; opacity: 0.5; }
.dci-triggerIcon { flex: none; display: inline-flex; }
.dci-triggerIcon svg { width: 14px; height: 14px; }
.dci-triggerLabel { text-overflow: ellipsis; white-space: nowrap; min-width: 0; overflow: hidden; }
.dci-triggerEffort { color: var(--dsw-alias-label-caption, currentColor); flex-shrink: 1000; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.dci-chev { color: var(--dsw-alias-label-caption, currentColor); flex: none; transition: transform 0.12s; display: inline-flex; }
.dci-chev[data-open="true"] { transform: rotate(180deg); }

/* 发送（官方 .primary）*/
.dci-send { background: var(--dsw-alias-button-info-fill, color-mix(in srgb, currentColor 85%, transparent)); color: #fff; cursor: pointer;
  border: none; border-radius: 999px; corner-shape: round; flex: none; place-items: center; width: 34px; height: 34px;
  transition: background-color 0.1s; display: grid; transform: translateY(-2px); }
.dci-send:hover:not(:disabled) { background: var(--dsw-alias-button-info-hover, color-mix(in srgb, currentColor 70%, transparent)); }
.dci-send:disabled { opacity: 0.4; cursor: default; }
/* 官方 .primary[data-sending]:disabled —— sending spinner 态不降透明度、光标 progress。 */
.dci-send[data-sending]:disabled { opacity: 1; cursor: progress; }
.dci-sending-spinner { animation: 0.8s linear infinite dci-input-sending; }
@media (prefers-reduced-motion: reduce) { .dci-sending-spinner { animation-duration: 2.4s; } }
@keyframes dci-input-sending { to { transform: rotate(360deg); } }

/* ===== 菜单（官方 primitives Menu / ModelSelect .menu 逐值复刻：r20 卡片 / item r10 / 上方弹出）
   卡片 overflow:hidden + max-height:min(360px,100vh-96px)（官方 .menu 同款），
   列表在 .dci-viewport 内滚；--dsh-scrollbar-thumb(l2) 由卡片注入（官方同款），
   宿主全局 ::-webkit-scrollbar-thumb{background:var(--dsh-scrollbar-thumb)} 据此出条。 ===== */
.dci-menu { position: fixed; z-index: 1100; box-sizing: border-box; padding: 4px; display: flex; flex-direction: column;
  min-width: 218px; max-width: min(360px, 100vw - 24px); max-height: min(360px, calc(100vh - 96px)); overflow: hidden;
  --dsh-scrollbar-thumb: var(--dsw-alias-scrollbar-bg-l2, color-mix(in srgb, currentColor 18%, transparent));
  --dsh-scrollbar-thumb-hover: var(--dsw-alias-scrollbar-hover-l2, color-mix(in srgb, currentColor 26%, transparent));
  background: var(--dsw-menu-surface-fill, var(--dsw-specific-menu, rgba(28, 28, 32, 0.98)));
  backdrop-filter: var(--dsw-menu-backdrop-filter, none); color: var(--dsw-alias-label-primary, #ececf1);
  --dsw-elevation-stroke-color: var(--dsw-alias-border-l1, transparent);
  box-shadow: var(--dsw-elevation-prominent, 0 10px 34px rgba(0, 0, 0, 0.35)); border: 0; border-radius: var(--dsw-radius-lg, 20px); font-size: 13px; }
.dci-viewport { display: flex; flex-direction: column; min-height: 0; overflow-y: auto; }
.dci-menuLabel { padding: 8px 10px; font-size: 12px; line-height: 16px; color: var(--dsw-alias-label-tertiary, currentColor);
  user-select: none; text-align: left; }
.dci-item { display: flex; align-items: center; gap: 8px; width: 100%; min-height: 40px; padding: 8px 10px; border: none;
  border-radius: 10px; background: transparent; cursor: pointer; font-size: 14px; line-height: 22px;
  color: var(--dsw-alias-label-primary, inherit); text-align: left; }
.dci-item:hover:not(:disabled) { background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 10%, transparent)); }
.dci-item:disabled { opacity: 0.4; cursor: not-allowed; }
.dci-itemIcon { display: inline-flex; flex: none; width: 16px; height: 16px; align-items: center; justify-content: center;
  color: var(--dsw-alias-label-tertiary, currentColor); }
.dci-itemIcon svg { width: 14px; height: 14px; }
.dci-itemLabel { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dci-check { flex: none; color: var(--dsw-alias-label-primary, currentColor); display: grid; place-items: center; }

/* ===== 候选菜单（官方 MenuView.module.css 逐值复刻：卡片顶锚定全宽浮层）
   0.1.7-rc.2 起菜单本体不再带背景，亚克力在 primitives MenuSurface 的 material 层
   （--dsw-menu-surface-fill + --dsw-menu-backdrop-filter）；单元素复刻把两层合并到这里，
   token 链兼容旧宿主（无新 token 时回退 rc.3 形态：不透明 --dsw-specific-menu、r20、无 blur）===== */
.dci-slash-menu { z-index: 100; box-sizing: border-box; --dsh-scrollbar-thumb: var(--dsw-alias-scrollbar-bg-l2, transparent);
  --dsh-scrollbar-thumb-hover: var(--dsw-alias-scrollbar-hover-l2, transparent);
  background: var(--dsw-menu-surface-fill, var(--dsw-specific-menu, rgba(30, 30, 34, 0.98)));
  backdrop-filter: var(--dsw-menu-backdrop-filter, none); color: var(--dsw-alias-label-primary, inherit);
  --dsw-elevation-stroke-color: var(--dsw-alias-border-l1, transparent);
  max-height: 400px; box-shadow: var(--dsw-elevation-prominent, 0 10px 34px rgba(0, 0, 0, 0.35));
  border: 0; border-radius: var(--dsw-radius-lg, 20px); flex-direction: column; padding: 4px; display: flex; position: absolute;
  bottom: calc(100% + 4px); left: 0; right: 0; overflow: hidden; }
/* dropdown（侧栏/悬浮形态）：portal 到 body 的自适应浮层——位置/宽度/最大高度由
   SlashMenu 量卡片（.dci-card）与视口后内联注入；fixed 不受面板/卡片裁剪，层级盖过
   悬浮卡（.dci-float z-index:940）但低于模态/灯箱（1000）。normal 形态仍走上面的
   卡片顶锚定 absolute 规则，几何不变。 */
.dci-slash-menu[data-dropdown] { position: fixed; z-index: 950; left: auto; right: auto; top: auto; bottom: auto; }
.dci-slash-viewport { flex-direction: column; min-height: 0; display: flex; overflow-y: auto; }
.dci-slash-item { cursor: pointer; width: 100%; min-height: 34px; color: var(--dsw-alias-label-primary, inherit);
  text-align: left; background: transparent; border: none; border-radius: var(--dsw-radius-md, 10px); align-items: center; gap: 6px;
  padding: 6px 8px; font-size: 13px; line-height: 20px; display: flex; }
.dci-slash-item[data-active="true"], .dci-slash-item:hover { background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 8%, transparent)); }
.dci-slash-sectionTitle { min-height: 23px; color: var(--dsw-alias-label-tertiary, currentColor); flex: none;
  padding: 5px 8px 2px; font-size: 11px; font-weight: 500; line-height: 16px; }
.dci-slash-sectionTitle:not(:first-child) { margin-top: 3px; }
.dci-slash-itemIcon { width: 14px; height: 14px; color: var(--dsw-alias-menu-icon, var(--dsw-alias-label-tertiary, currentColor)); flex: none;
  justify-content: center; align-items: center; display: inline-flex; }
.dci-slash-itemIcon svg { width: 14px; height: 14px; }
.dci-slash-itemName { text-overflow: ellipsis; white-space: nowrap; flex: none; max-width: 40%; overflow: hidden; }
.dci-slash-itemAlias { text-overflow: ellipsis; white-space: nowrap; max-width: 20%; color: var(--dsw-alias-label-tertiary, currentColor); flex: none;
  font-size: 12px; line-height: 18px; overflow: hidden; }
.dci-slash-itemDescription { text-overflow: ellipsis; white-space: nowrap; text-align: right; min-width: 0;
  color: var(--dsw-alias-label-tertiary, currentColor); flex: 1; font-size: 12px; line-height: 18px; overflow: hidden; }
.dci-slash-trailing { flex: none; align-items: center; gap: 3px; margin-left: auto; display: inline-flex; }
.dci-slash-drillHintText { color: var(--dsw-alias-label-caption, currentColor); white-space: nowrap; font-size: 10px;
  line-height: 16px; display: none; }
.dci-slash-drillHint { border-radius: var(--dsw-radius-xs, 4px); background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 8%, transparent));
  color: var(--dsw-alias-label-caption, currentColor); padding: 0 4px; font-family: inherit;
  font-size: 10px; line-height: 16px; display: none; }
.dci-slash-item[data-active="true"] .dci-slash-drillHintText, .dci-slash-item[data-active="true"] .dci-slash-drillHint { display: inline-flex; }
.dci-slash-drill { width: 18px; height: 18px; border-radius: var(--dsw-radius-xs, 4px); color: var(--dsw-alias-menu-icon, var(--dsw-alias-label-caption, currentColor));
  flex: none; place-items: center; display: inline-grid; cursor: pointer; }
.dci-slash-drill:hover { background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 8%, transparent));
  color: var(--dsw-alias-label-primary, inherit); }
.dci-slash-groupTitle { color: var(--dsw-alias-label-tertiary, currentColor); padding: 6px 8px; font-size: 11px; line-height: 15px; }
.dci-slash-skeletonRow { box-sizing: border-box; align-items: center; min-height: 34px; padding: 6px 8px; display: flex; }
.dci-slash-skeletonBar { background: var(--dsw-alias-bg-skeleton, color-mix(in srgb, currentColor 10%, transparent));
  border-radius: var(--dsw-radius-xs, 4px); height: 18px; animation: dci-slash-skeleton 2s cubic-bezier(0.36, 0, 0.64, 1) infinite; }
@keyframes dci-slash-skeleton { 0% { opacity: 1; } 40% { opacity: 0.6; } 80%, 100% { opacity: 1; } }
.dci-slash-crumbs { border-bottom: 0.5px solid var(--dsw-alias-border-l1, transparent); flex-wrap: wrap; flex: none;
  align-items: center; gap: 2px; margin-bottom: 2px; padding: 3px 3px 5px; display: flex; }
.dci-slash-crumb { max-width: 40%; color: var(--dsw-alias-label-tertiary, currentColor); cursor: pointer;
  text-overflow: ellipsis; white-space: nowrap; background: transparent; border: none; border-radius: var(--dsw-radius-sm, 6px);
  flex: 0 auto; padding: 2px 5px; font-family: inherit; font-size: 11px; line-height: 16px; overflow: hidden; }
.dci-slash-crumb:hover:not(:disabled) { background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 8%, transparent));
  color: var(--dsw-alias-label-primary, inherit); }
.dci-slash-crumb:disabled { color: var(--dsw-alias-label-primary, inherit); cursor: default; background: transparent; }
.dci-slash-crumbSeparator { color: var(--dsw-alias-menu-icon, var(--dsw-alias-label-caption, currentColor)); flex: none; display: inline-flex; }

.dci-crumb-row { display: flex; flex-wrap: wrap; gap: 2px; padding: 4px 6px; }
.dci-crumb { border: none; background: transparent; color: var(--dsw-alias-label-secondary, inherit); cursor: pointer;
  padding: 2px 6px; border-radius: 5px; font-size: 11.5px; display: inline-flex; }
.dci-crumb:hover { background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 9%, transparent)); }
.dci-crumb[data-current="true"] { color: var(--dsw-alias-label-primary, inherit); cursor: default; }
.dci-empty { padding: 10px; color: var(--dsw-alias-label-tertiary, currentColor); text-align: left; }
.dci-search { width: calc(100% - 8px); margin: 2px 4px 4px; padding: 5px 9px; font-size: 13px;
  border-radius: 8px; border: 1px solid var(--dsw-alias-border-l2, color-mix(in srgb, currentColor 18%, transparent));
  background: transparent; color: inherit; outline: none; }
.dci-error { padding: 6px 10px; color: var(--dsw-alias-state-error-primary, #d54941); font-size: 12px; }

/* ===== 模型/推理等级 cell 行（官方 ModelSelection .cell）===== */
.dci-cell { box-sizing: border-box; width: auto; min-width: 100%; height: 40px; color: var(--dsw-alias-label-primary, inherit);
  cursor: pointer; text-align: left; background: transparent; border: none; border-radius: 10px;
  align-items: center; gap: 8px; padding: 0 10px; font-size: 14px; line-height: 22px; display: flex; }
.dci-cell:hover { background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 10%, transparent)); }
.dci-cellLabel { white-space: nowrap; flex: none; }
.dci-cellValue { text-overflow: ellipsis; white-space: nowrap; text-align: right; min-width: 0;
  color: var(--dsw-alias-label-tertiary, currentColor); flex: auto; overflow: hidden; }
.dci-cellChevron { color: var(--dsw-alias-label-tertiary, currentColor); flex: none; display: inline-flex; }

/* ===== 完全权限确认（官方 RiskConfirmation 语义）===== */
.dci-confirm-warning { display: flex; align-items: flex-start; gap: 10px; color: var(--dsw-alias-label-secondary, currentColor);
  font-size: 14px; line-height: 22px; padding: 6px 8px 0; }
.dci-confirm-warning svg { flex: none; margin-top: 2px; color: var(--dsw-alias-state-error-primary, #d54941); }
.dci-confirm-warning p { margin: 0; }
.dci-confirm-ack { display: flex; align-items: flex-start; gap: 10px; margin: 14px 8px 0; cursor: pointer;
  color: var(--dsw-alias-label-primary, inherit); font-size: 14px; line-height: 22px; }
.dci-confirm-ack input { flex: none; width: 16px; height: 16px; margin: 3px 0 0;
  accent-color: var(--dsw-alias-button-primary-fill, currentColor); cursor: pointer; }
.dci-confirm-actions { display: flex; justify-content: flex-end; gap: 8px; padding: 16px 8px 4px; }
.dci-confirm-actions .dci-btn { min-width: 72px; }
.dci-confirm-actions .dci-btn[data-primary="true"] { min-width: 136px; }
.dci-btn { border: 1px solid var(--dsw-alias-border-l2, color-mix(in srgb, currentColor 22%, transparent)); border-radius: 10px;
  background: transparent; color: inherit; padding: 6px 14px; cursor: pointer; font-size: 14px; line-height: 20px; }
.dci-btn[data-primary="true"] { background: var(--dsw-alias-button-primary-fill, color-mix(in srgb, currentColor 85%, transparent));
  color: var(--dsw-alias-label-primary-foreground, #fff); border-color: transparent; }
.dci-btn:disabled { opacity: 0.4; cursor: default; }

/* ===== 草稿附件轨（官方 ComposerAttachments/AttachmentRail/FileCard 逐值复刻）=====
 * 值取自官方 dsh-client-ui-attachment：轨道 gap 10 / 隐藏滚动条 / 64px 项；
 * 图片缩略图 64×64 r16 cover；文件卡 240×64 r16（icon 28 + name 14/500 +
 * meta 12）；移除钮 18px 圆（button-contrast-fill，悬停显形）；翻页箭头 24px 圆。 */
.dci-attach-root { position: relative; min-width: 0; margin: 6px 12px 0; }
.dci-attach-rail { display: flex; align-items: stretch; gap: 10px; overflow: auto hidden;
  scrollbar-width: none; --dsh-scrollbar-thumb: var(--dsw-alias-scrollbar-bg-l2, transparent);
  --dsh-scrollbar-thumb-hover: var(--dsw-alias-scrollbar-hover-l2, transparent); }
.dci-attach-rail::-webkit-scrollbar { display: none; }
.dci-attach-item { position: relative; flex: none; height: 64px; }
.dci-attach-thumb { box-sizing: border-box; width: 64px; height: 64px; padding: 0; overflow: hidden;
  cursor: zoom-in; border: 0.5px solid var(--dsw-alias-border-l2-darkmode-thin, color-mix(in srgb, currentColor 12%, transparent));
  border-radius: 16px; background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 8%, transparent));
  display: grid; place-items: center; color: var(--dsw-alias-label-tertiary, currentColor); }
.dci-attach-thumb img { display: block; width: 100%; height: 100%; object-fit: cover; }
/* 移除钮（图片项：卡片右上角浮层）。 */
.dci-attach-remove { position: absolute; top: 4px; right: 4px; z-index: 1; box-sizing: border-box;
  width: 18px; height: 18px; padding: 0; border: none; border-radius: 50%; corner-shape: round;
  background: var(--dsw-alias-button-contrast-fill, rgba(0, 0, 0, 0.72));
  color: var(--dsw-alias-label-primary-inverted, #fff); cursor: pointer; opacity: 0;
  display: grid; place-items: center; transition: opacity 0.2s ease-in-out; }
.dci-attach-item:hover .dci-attach-remove, .dci-attach-remove:focus-visible { opacity: 1; }
@media (pointer: coarse) { .dci-attach-remove { opacity: 1; } }
@media (prefers-reduced-motion: reduce) { .dci-attach-remove { transition: none; } }
/* 文件卡（非图片）。 */
.dci-attach-card { box-sizing: border-box; position: relative; display: inline-flex; align-items: center;
  gap: 10px; width: 240px; height: 64px; padding: 0 12px; text-align: left;
  border: 0.5px solid var(--dsw-alias-border-l2, color-mix(in srgb, currentColor 12%, transparent));
  border-radius: 16px; background: var(--dsw-specific-input-major, color-mix(in srgb, currentColor 4%, transparent)); }
.dci-attach-cardFailed { border-color: var(--dsw-alias-state-error-primary, #d54941); }
.dci-attach-icon { flex: none; display: inline-flex; align-items: center; justify-content: center;
  width: 28px; height: 28px; color: var(--dsw-alias-label-secondary, currentColor); }
.dci-attach-spinner { box-sizing: border-box; width: 20px; height: 20px; border: 2px solid; border-top-color: transparent;
  border-radius: 50%; corner-shape: round; animation: dci-attach-spin 0.8s linear infinite; }
@keyframes dci-attach-spin { to { transform: rotate(360deg); } }
.dci-attach-body { display: flex; flex-direction: column; flex: 1; min-width: 0; padding: 8px 0; }
button.dci-attach-body { color: inherit; font: inherit; text-align: left; background: none; border: 0; cursor: pointer; }
.dci-attach-name { overflow: hidden; white-space: nowrap; text-overflow: ellipsis;
  color: var(--dsw-alias-label-primary, inherit); font-size: 14px; font-weight: 500; line-height: 22px; }
.dci-attach-card:hover .dci-attach-name, .dci-attach-card:focus-within .dci-attach-name { padding-right: 18px; }
.dci-attach-meta { overflow: hidden; white-space: nowrap; text-overflow: ellipsis;
  color: var(--dsw-alias-label-tertiary, currentColor); font-size: 12px; line-height: 15px; }
.dci-attach-metaFailed { color: var(--dsw-alias-state-error-primary, #d54941); }
/* 文件卡的移除钮（卡内右下角，非浮层）。 */
.dci-attach-removeInline { position: absolute; top: 6px; right: 6px; box-sizing: border-box;
  width: 18px; height: 18px; padding: 0; border: none; border-radius: 50%; corner-shape: round;
  background: var(--dsw-alias-button-contrast-fill, rgba(0, 0, 0, 0.72));
  color: var(--dsw-alias-label-primary-inverted, #fff); cursor: pointer; opacity: 0;
  display: inline-flex; align-items: center; justify-content: center; transition: opacity 0.2s ease-in-out; }
.dci-attach-card:hover .dci-attach-removeInline, .dci-attach-removeInline:focus-visible { opacity: 1; }
.dci-attach-cardFailedRemove { background: var(--dsw-alias-state-error-primary, #d54941); color: #fff; opacity: 1; }
/* 上传进度（有 loaded/total 时按比例，否则官方同款往返动画）。 */
.dci-attach-progress { position: absolute; bottom: 5px; left: 12px; right: 12px; height: 2px;
  border-radius: 1px; background: var(--dsw-alias-fill-tertiary, color-mix(in srgb, currentColor 8%, transparent));
  overflow: hidden; }
.dci-attach-item .dci-attach-progress { left: 4px; right: 4px; }
.dci-attach-progressBar { display: block; height: 100%; border-radius: inherit;
  background: var(--dsw-alias-brand-primary, currentColor); animation: dci-attach-progress 1.2s ease-in-out infinite alternate; }
.dci-attach-progressBar[style*="width"] { animation: none; }
@keyframes dci-attach-progress { 0% { transform: translate(-70%); } to { transform: translate(220%); } }
/* 翻页箭头（轨道两端，溢出时才出现）。 */
.dci-attach-arrow { position: absolute; top: 50%; transform: translateY(-50%); z-index: 2; box-sizing: border-box;
  width: 24px; height: 24px; padding: 0; border: 0; border-radius: 999px; corner-shape: round;
  background: var(--dsw-specific-input-major, color-mix(in srgb, currentColor 8%, transparent));
  color: var(--dsw-alias-label-secondary, currentColor); box-shadow: var(--dsw-elevation-panel, none);
  --dsw-elevation-stroke-color: var(--dsw-alias-border-l2-darkmode-thin, transparent);
  cursor: pointer; display: grid; place-items: center; }
.dci-attach-arrow:hover { background: var(--dsw-alias-interactive-bg-hover-solid, color-mix(in srgb, currentColor 14%, transparent)); }
.dci-attach-arrowLeft { left: 4px; }
.dci-attach-arrowRight { right: 4px; }

/* ===== 数据行（卡片下方，官方 data-composer-stats 位置）===== */
.dci-stats { display: flex; align-items: center; gap: 4px; font-size: 11.5px; color: var(--dsw-alias-label-caption, currentColor);
  padding: 0 6px; font-variant-numeric: tabular-nums; user-select: none; }

/* ===== 悬浮模式（拖顶部行空白区脱出；拖回底部输入区回普通；prefs 记忆）===== */
.dci-float { position: fixed; z-index: 940; min-width: 0; display: flex; flex-direction: column; }
.dci-float .dci-surface { flex: 1 1 auto; min-height: 0; }
.dci-float .dci-card { max-width: none; margin-inline: 0; width: 100%; }
/* 手动缩放过高度后（data-sized）：卡片吃满外壳，编辑区吃满卡片剩余高度。 */
.dci-float[data-sized="true"] .dci-card { flex: 1 1 auto; min-height: 0; }
.dci-float[data-sized="true"] .dci-body { flex: 1 1 auto; max-height: none; min-height: 0; }
/* 缩放把手：四条边 + 四个角落，1:1 跟手（窗口式）；透明热区，骑在卡片边缘上。 */
.dci-float-grip { position: absolute; z-index: 61; touch-action: none; }
.dci-float-grip[data-dir="n"] { top: calc(-1 * var(--dci-grip-edge)); left: var(--dci-grip-corner); right: var(--dci-grip-corner);
  height: var(--dci-grip-edge); cursor: ns-resize; }
.dci-float-grip[data-dir="s"] { bottom: calc(-1 * var(--dci-grip-edge)); left: var(--dci-grip-corner); right: var(--dci-grip-corner);
  height: var(--dci-grip-edge); cursor: ns-resize; }
.dci-float-grip[data-dir="w"] { left: calc(-1 * var(--dci-grip-edge)); top: var(--dci-grip-corner); bottom: var(--dci-grip-corner);
  width: var(--dci-grip-edge); cursor: ew-resize; }
.dci-float-grip[data-dir="e"] { right: calc(-1 * var(--dci-grip-edge)); top: var(--dci-grip-corner); bottom: var(--dci-grip-corner);
  width: var(--dci-grip-edge); cursor: ew-resize; }
.dci-float-grip[data-dir="nw"] { top: calc(-1 * var(--dci-grip-edge)); left: calc(-1 * var(--dci-grip-edge));
  width: var(--dci-grip-corner); height: var(--dci-grip-corner); cursor: nwse-resize; }
.dci-float-grip[data-dir="ne"] { top: calc(-1 * var(--dci-grip-edge)); right: calc(-1 * var(--dci-grip-edge));
  width: var(--dci-grip-corner); height: var(--dci-grip-corner); cursor: nesw-resize; }
.dci-float-grip[data-dir="sw"] { bottom: calc(-1 * var(--dci-grip-edge)); left: calc(-1 * var(--dci-grip-edge));
  width: var(--dci-grip-corner); height: var(--dci-grip-corner); cursor: nesw-resize; }
.dci-float-grip[data-dir="se"] { bottom: calc(-1 * var(--dci-grip-edge)); right: calc(-1 * var(--dci-grip-edge));
  width: var(--dci-grip-corner); height: var(--dci-grip-corner); cursor: nwse-resize; }
/* 拖动区：accessory 行里开关右侧的空白，按住移动整卡（普通态拖出=悬浮）。 */
.dci-float-dragzone { flex: 1 1 auto; align-self: stretch; min-width: 24px; cursor: grab; touch-action: none; }
.dci-float-dragzone[data-dragging="true"] { cursor: grabbing; }
/* 悬浮卡片：数据行收进卡片底部；高度拖把不适用。 */
.dci-surface[data-float] .dci-rip { display: none; }
.dci-surface[data-float] .dci-stat-root { padding: 2px 16px 8px; }
.dci-surface[data-float] .dci-card { box-shadow: var(--dsw-elevation-prominent, 0 10px 34px rgba(0, 0, 0, 0.35)); }

/* ===== 右上角小球（侧栏收起后的 Codinput 唤出入口）=====
 * 位置由 JS 量标题栏（会话头部）后内联注入：标题栏下方、右对齐（与官方角落
 * 按钮同内缩 12px、贴头部底边下 8px）——不占官方槽位，因此官方侧栏展开/
 * 收起按钮原样留在标题栏里，小球不覆盖它。悬于内容之上，故带圆形描边与
 * 极淡底色（取值同官方控件的 resting 面色）以免被对话内容淹没；图标为品牌
 * glyph（lucide file-code-corner，README 图标）。
 * corner-shape: round 是必需的：宿主设计语言在根节点设了
 * corner-shape: superellipse(1.5)（全局超椭圆/squircle），只写 50% 会渲染
 * 成圆角方而非圆——官方自己的圆形控件（spinner/dot/tag/switch/thumb）也都
 * 逐条 opt-out 回 round，此处照同一约定。 */
.dci-ball { position: fixed; z-index: 900; box-sizing: border-box; width: 36px; height: 36px;
  color: var(--dsw-alias-label-secondary, currentColor); cursor: pointer;
  background: var(--dsw-alias-bg-module-platform, color-mix(in srgb, currentColor 6%, transparent));
  border: 2px solid var(--dsw-alias-border-l3, color-mix(in srgb, currentColor 30%, transparent));
  border-radius: 50%; corner-shape: round; flex: none; justify-content: center; align-items: center; padding: 0; display: inline-flex;
  transition: background-color 0.12s, border-color 0.12s; }
.dci-ball svg { width: 18px; height: 18px; }
/* 悬停：描边提亮到标签色 + 面色加深，指针在内容之上也能看出可点。 */
.dci-ball:hover { background: var(--dsw-alias-interactive-bg-hover-solid, color-mix(in srgb, currentColor 14%, transparent));
  border-color: var(--dsw-alias-label-tertiary, currentColor); color: var(--dsw-alias-label-primary, inherit); }
.dci-ball:focus-visible { outline: 2px solid var(--dsw-alias-brand-primary, currentColor); outline-offset: 2px; }

/* ===== 侧栏形态（dockkit 标签页）：适应整个面板而非照搬主输入卡片 =====
 * 卡片去壳铺满 paneBody（官方 _paneBody 为 position:relative + overflow:auto，
 * 包裹层 absolute inset:0 精确铺满），编辑区吃满剩余高度——VS Code 面板式。 */
.dci-surface[data-side] { flex: 1 1 auto; min-height: 0; }
.dci-surface[data-side] .dci-card { flex: 1 1 auto; min-height: 0; max-width: none; margin-inline: 0;
  background: transparent; box-shadow: none; border-radius: 0; padding-top: 0; }
.dci-surface[data-side] .dci-rip { display: none; }
.dci-surface[data-side] .dci-accessory { padding: 8px 12px 6px;
  border-bottom: 0.5px solid var(--dsw-alias-border-l1, transparent); }
.dci-surface[data-side] .dci-body { flex: 1 1 auto; max-height: none; min-height: 0; }
.dci-surface[data-side] .dci-row { padding: 6px 8px;
  border-top: 0.5px solid var(--dsw-alias-border-l1, transparent); }
/* 候选菜单的 side/float 形态已改为 portal 自适应浮层（见 .dci-slash-menu[data-dropdown]），
   不再挂在 surface 下，故此处不再需要布局覆盖。 */

/* ===== 设置分区（官方 T1PP 行结构 + 控件样式）===== */
.dci-settings { display: flex; flex-direction: column; font-size: 14px; color: inherit; }
.dci-set-row { border-bottom: 0.5px solid var(--dsw-alias-border-l2, color-mix(in srgb, currentColor 10%, transparent));
  align-items: center; gap: 8px; padding: 16px 0; display: flex; }
.dci-set-rowText { flex-direction: column; flex: 1 1 0%; gap: 4px; min-width: 0; padding-right: 48px; display: flex; }
.dci-set-title { color: var(--dsw-alias-label-primary, inherit); font-size: 14px; font-weight: 400; line-height: 22px; }
.dci-set-desc { color: var(--dsw-alias-label-tertiary, currentColor); font-size: 12px; font-weight: 400; line-height: 18px; }
.dci-set-control { display: flex; align-items: center; }
.dci-set-selector { background: var(--dsw-alias-bg-module-platform, color-mix(in srgb, currentColor 6%, transparent));
  height: 36px; color: var(--dsw-alias-label-primary, inherit); cursor: pointer; border: none; border-radius: 18px;
  align-items: center; gap: 12px; padding: 0 14px; font-size: 14px; line-height: 22px; display: inline-flex; }
.dci-set-selector:hover { background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 10%, transparent)); }
.dci-set-selector[data-recording="true"] { color: var(--dsw-alias-state-business-primary, currentColor); }
.dci-set-selector[data-conflict="true"] { color: var(--dsw-alias-state-error-primary, currentColor); }
.dci-set-input { background: var(--dsw-alias-bg-module-platform, color-mix(in srgb, currentColor 6%, transparent));
  height: 36px; color: var(--dsw-alias-label-primary, inherit); border: none; border-radius: 18px; outline: none;
  padding: 0 14px; font-size: 13px; min-width: 260px; max-width: 320px; }
.dci-set-input:focus { outline: 2px solid var(--dsw-alias-border-l3, transparent); }
/* 开关：官方 primitives Switch 逐值（Switch.module.css）。ON 轨道走
   --dsw-alias-brand-primary——该 token 自 0.2.0-rc.2 起浅色主题即近黑（#0f1115）、
   深色主题近白（#f9fafb），桌面 rc.3 同款；同 token 跟随宿主主题，就是官方样式的来源。 */
.dci-switch { box-sizing: border-box; position: relative; flex: none; width: 36px; height: 20px; padding: 2px;
  border: 0; border-radius: 999px; corner-shape: round;
  background: var(--dsw-alias-border-l3, color-mix(in srgb, currentColor 30%, transparent));
  cursor: pointer; }
.dci-switch[aria-checked="true"] { background: var(--dsw-alias-brand-primary, color-mix(in srgb, currentColor 70%, transparent)); }
.dci-switch:disabled { cursor: default; opacity: 0.5; }
.dci-switch:focus-visible { outline: var(--dsw-focus-ring-width, 2px) solid var(--dsw-focus-ring-color, var(--dsw-alias-state-business-primary, currentColor)); outline-offset: 2px; }
.dci-switch::after { content: ''; display: block; width: 16px; height: 16px; border-radius: 50%; corner-shape: round;
  background: var(--dsw-alias-label-primary-foreground, #fff); transition: transform 120ms ease; }
.dci-switch[aria-checked="false"]::after { background: var(--dsw-alias-switch-thumb, #fff); }
.dci-switch[aria-checked="true"]::after { transform: translateX(16px); }


/* ===== 原图预览（官方 primitives ImageLightbox 逐值复刻）===== */
.dci-lightbox { position: fixed; inset: 0; z-index: 1000; display: grid; place-items: center; padding: 40px; }
.dci-lightbox-mask { position: absolute; inset: 0; background: var(--dsw-alias-bg-mask-1, rgba(0, 0, 0, 0.55));
  backdrop-filter: var(--dsw-mask-blur, blur(4px)); }
.dci-lightbox-image { position: relative; max-width: min(100%, 1600px); max-height: calc(100vh - 80px);
  object-fit: contain; border-radius: var(--dsw-radius-lg, 16px); background: var(--dsw-specific-input-major);
  border: 0; box-shadow: var(--dsw-elevation-prominent, 0 10px 34px rgba(0, 0, 0, 0.35)); }
.dci-lightbox-close { position: fixed; top: 20px; right: 20px; z-index: 1; display: grid; place-items: center;
  width: 36px; height: 36px; border: 0.5px solid var(--dsw-alias-border-l2-darkmode-thin, var(--dsw-alias-border-l2, transparent));
  border-radius: 999px; corner-shape: round; background: var(--dsw-specific-input-major);
  color: var(--dsw-alias-label-primary, currentColor); cursor: pointer; }
.dci-lightbox-close:focus-visible { outline: var(--dsw-focus-ring-width, 2px) solid var(--dsw-focus-ring-color, var(--dsw-alias-state-business-primary, currentColor)); outline-offset: 3px; }

/* ===== 数据行（官方 uV2eYG_dock 复刻：root 内居中、无横向 padding）===== */
.dci-stat-root { max-width: 100%; box-sizing: border-box; width: 100%;
  padding: 4px 0 0; font-size: calc(var(--dsh-content-font-size-secondary, 13px) - 1px);
  line-height: calc(20px + var(--dsh-content-font-delta-secondary, 0px));
  justify-content: center; gap: 12px; display: flex; }
.dci-stat-anchor { min-width: 0; display: inline-flex; }

/* 数据行详情面板（官方 bRhRbq 复刻：portal 到 body、fixed、锚点上方弹出）。
   背景与圆角逐值同官方：--dsw-specific-menu 优先（macOS 桌面上官方把它覆写成不透明），
   旧宿主/皮肤缺该 token 时回退 --dsw-menu-surface-fill 链，不落到硬编码深色。 */
.dci-stat-panel { z-index: 1100; box-sizing: border-box; background: var(--dsw-specific-menu, var(--dsw-menu-surface-fill, rgba(30, 30, 34, 0.98)));
  backdrop-filter: var(--dsw-menu-backdrop-filter, none);
  color: var(--dsw-alias-label-secondary, inherit); --dsw-elevation-stroke-color: var(--dsw-alias-border-l1, transparent);
  width: max-content; min-width: min(300px, 100vw - 24px); max-width: min(440px, 100vw - 24px); text-align: left;
  box-shadow: var(--dsw-elevation-prominent, 0 10px 34px rgba(0, 0, 0, 0.35)); cursor: default; border: 0;
  border-radius: var(--dsw-radius-lg, 12px); padding: 16px; font-size: 12px; line-height: 18px; position: fixed; }
.dci-stat-panelTitle { color: var(--dsw-alias-label-primary, inherit); justify-content: space-between; gap: 16px;
  margin-bottom: 8px; font-weight: 500; display: flex; }
.dci-stat-panelLabel { align-items: center; gap: 6px; min-width: 0; display: inline-flex; }
.dci-stat-panelLabel svg { flex: none; width: 14px; height: 14px; }
.dci-stat-panelValue { font-variant-numeric: tabular-nums; }
.dci-stat-panelRule { border-top: 0.5px solid var(--dsw-alias-border-l2, color-mix(in srgb, currentColor 10%, transparent)); margin-bottom: 10px; }
.dci-stat-details { color: var(--dsw-alias-label-tertiary, currentColor); grid-template-columns: minmax(76px, auto) minmax(0, 1fr);
  gap: 6px 16px; margin: 0; display: grid; }
.dci-stat-details dt, .dci-stat-details dd { min-width: 0; margin: 0; }
.dci-stat-details dd { color: var(--dsw-alias-label-secondary, inherit); font-variant-numeric: tabular-nums; text-align: right; }
.dci-stat-pill { font: inherit; box-sizing: border-box; max-width: 100%; color: var(--dsw-alias-label-tertiary, currentColor);
  white-space: nowrap; background: transparent; border: none; border-radius: 999px; corner-shape: round;
  line-height: inherit; align-items: center; gap: 6px;
  padding: 1px 8px; display: inline-flex; cursor: pointer; font-variant-numeric: tabular-nums; }
.dci-stat-pill svg { flex: none; width: 14px; height: 14px; }
.dci-stat-pill:hover, .dci-stat-pill[aria-expanded="true"] { background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 8%, transparent));
  color: var(--dsw-alias-label-secondary, inherit); }
.dci-stat-label { text-overflow: ellipsis; min-width: 0; overflow: hidden; }
.dci-stat-sep { color: var(--dsw-alias-separator-primary, currentColor); margin: 0 6px; }

/* ===== 上下文小圈（官方 JObwrW 复刻：双环仪表 + 分段面板）
   0.1.7-rc.2 起官方把它挪进卡片下方 dock 行（stats 胶囊之后），trigger 变为「圈+百分比」药丸 ===== */
.dci-gauge-root { flex: none; display: inline-flex; }
.dci-gauge-trigger { border-radius: var(--dsw-radius-sm, 8px); color: var(--dsw-alias-label-tertiary, currentColor);
  font-family: inherit; font-size: var(--dsh-content-font-size-secondary, 13px); font-variant-numeric: tabular-nums;
  line-height: calc(20px + var(--dsh-content-font-delta-secondary, 0px)); white-space: nowrap;
  cursor: pointer; background: transparent; border: none; flex: none; align-items: center; gap: 6px; padding: 1px 8px; display: inline-flex; }
.dci-gauge-trigger:hover, .dci-gauge-trigger[aria-expanded="true"] { background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 8%, transparent));
  color: var(--dsw-alias-label-secondary, inherit); }
.dci-gauge-track { fill: none; stroke: var(--dsw-alias-border-l3, currentColor); stroke-width: 2px; }
.dci-gauge-fill { fill: none; stroke: var(--dsw-alias-label-tertiary, currentColor); stroke-width: 2px; stroke-linecap: round; }
/* 面板 portal 到 body + fixed，left/top 由 useAnchoredPanel（官方 useAnchoredPosition
   移植：面板左缘对齐锚点左缘、面板底距锚点顶 8px、视口 margin 12 夹取）下发。 */
.dci-gauge-panel { z-index: 1100; box-sizing: border-box; background: var(--dsw-specific-menu, var(--dsw-menu-surface-fill, rgba(30, 30, 34, 0.98)));
  backdrop-filter: var(--dsw-menu-backdrop-filter, none);
  --dsw-elevation-stroke-color: var(--dsw-alias-border-l1, transparent); width: min(264px, 100vw - 24px);
  box-shadow: var(--dsw-elevation-prominent, 0 10px 34px rgba(0, 0, 0, 0.35));
  color: var(--dsw-alias-label-secondary, inherit); cursor: default; border: 0; border-radius: var(--dsw-radius-lg, 12px); padding: 12px;
  font-size: 12px; line-height: 20px; position: fixed; }
.dci-gauge-header { align-items: center; gap: 6px; display: flex; }
.dci-gauge-figures { font-variant-numeric: tabular-nums; color: var(--dsw-alias-label-primary, inherit); margin-left: auto; font-weight: 500; }
.dci-gauge-percent { color: var(--dsw-alias-label-primary, inherit); font-weight: 500; }
.dci-gauge-headline { color: var(--dsw-alias-label-tertiary, currentColor); }
.dci-gauge-bar { background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 8%, transparent));
  border-radius: 999px; corner-shape: round; gap: 1px; height: 4px; margin: 10px 0 12px; display: flex; overflow: hidden; }
.dci-gauge-segment { background: var(--meter-tint, var(--dsw-alias-label-tertiary, currentColor)); border-radius: 1px;
  flex: 0 0 auto; min-width: 2px; height: 100%; }
.dci-gauge-swatch { background: var(--meter-tint, currentColor); vertical-align: baseline; border-radius: 2px;
  width: 8px; height: 8px; margin-right: 6px; display: inline-block; }
.dci-gauge-colorSystem { --meter-tint: var(--dsw-static-neutral-bluish-400, #7d8590); }
.dci-gauge-colorTools { --meter-tint: #a78bfa; }
.dci-gauge-colorMessages { --meter-tint: var(--dsw-static-blue-450, #4c8dff); }
.dci-gauge-rows { margin: 6px 0 0; }
.dci-gauge-row { justify-content: space-between; align-items: center; gap: 12px; padding: 2px 0; display: flex; }
.dci-gauge-row dt { color: var(--dsw-alias-label-secondary, inherit); }
.dci-gauge-row dd { font-variant-numeric: tabular-nums; color: var(--dsw-alias-label-primary, inherit); margin: 0; }

/* ===== 完全权限确认（官方 Modal + RiskConfirmation 复刻）===== */
.dci-modal-root { position: fixed; inset: 0; z-index: 1000; display: flex; align-items: center; justify-content: center; padding: 24px; }
.dci-modal-mask { position: absolute; inset: 0; background: var(--dsw-alias-bg-mask-1, rgba(0, 0, 0, 0.5));
  backdrop-filter: var(--dsw-mask-blur, blur(2px)); }
.dci-modal-dialog { position: relative; z-index: 1; display: flex; flex-direction: column; gap: 20px;
  width: min(440px, 100%); max-height: calc(100vh - 48px); padding: 0 0 24px; overflow: hidden; border: 0;
  border-radius: 24px; background: var(--dsw-alias-bg-layer-2, #232327); color: var(--dsw-alias-label-primary, #ececf1);
  --dsw-elevation-stroke-color: var(--dsw-alias-border-l1, transparent);
  box-shadow: var(--dsw-elevation-prominent, 0 10px 34px rgba(0, 0, 0, 0.35)); }
.dci-modal-content { display: flex; flex-direction: column; width: 100%; min-height: 0; overflow-y: auto; }
.dci-modal-header { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 22px 14px 12px 24px; }
.dci-modal-title { margin: 0; font-size: 16px; line-height: 24px; font-weight: 500; color: var(--dsw-alias-label-primary, inherit); }
.dci-modal-close { flex: none; display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px;
  border: none; border-radius: 8px; background: transparent; cursor: pointer; color: var(--dsw-alias-label-secondary, inherit); }
.dci-modal-close:hover { background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 8%, transparent)); }
.dci-modal-body { display: flex; flex-direction: column; min-width: 0; margin-top: 20px; padding: 0 24px; }
.dci-modal-footer { display: flex; align-items: center; justify-content: flex-end; gap: 8px; padding: 0 24px; }
.dci-confirm-warning { display: flex; align-items: flex-start; gap: 10px; color: var(--dsw-alias-label-secondary, inherit);
  font-size: 14px; line-height: 22px; }
.dci-confirm-warning p { margin: 0; }
.dci-confirm-warningIcon { flex: none; margin-top: 2px; color: var(--dsw-alias-state-error-primary, #d54941); }
.dci-confirm-ack { display: flex; align-items: flex-start; gap: 10px; margin-top: 20px; cursor: pointer;
  color: var(--dsw-alias-label-primary, inherit); font-size: 14px; line-height: 22px; }
.dci-confirm-ack input { flex: none; width: 16px; height: 16px; margin: 3px 0 0; cursor: pointer;
  accent-color: var(--dsw-alias-button-primary-fill, currentColor); }
.dci-btn { display: inline-flex; align-items: center; justify-content: center; gap: 4px; border: none; border-radius: 18px;
  cursor: pointer; font-size: 14px; line-height: 22px; color: var(--dsw-alias-label-primary, inherit);
  background: transparent; padding: 0 14px; height: 36px; }
.dci-btn:disabled { cursor: not-allowed; opacity: 0.4; }
.dci-btn-outline { border: 0.5px solid var(--dsw-alias-border-l3, color-mix(in srgb, currentColor 25%, transparent)); background: transparent; }
.dci-btn-outline:hover:not(:disabled) { background: var(--dsw-alias-interactive-bg-hover, color-mix(in srgb, currentColor 8%, transparent)); }
.dci-btn-primary { background: var(--dsw-alias-button-primary-fill, currentColor); color: var(--dsw-alias-label-primary-foreground, #fff); }
.dci-btn-primary:hover:not(:disabled) { background: var(--dsw-alias-button-primary-hover, currentColor); }
.dci-btn-cancel { min-width: 72px; }
.dci-btn-confirm { min-width: 136px; }

/* ===== 用户消息 Markdown（chat.node 键控座遮蔽条目）=====
   气泡/操作行/附件行取值逐条移植官方 MessageItem.module.css 与
   MessageIconActions.module.css；Markdown 排版逐条移植官方
   MarkdownText.module.css；引用 chip 逐条移植官方 user-text.module.css。
   官方走 --dsw-* token 的取值这里同样走 token（换肤全盘跟随）。 */
.dci-umsg-row { flex-direction: column; align-items: flex-end; gap: 6px; display: flex; }
.dci-umsg-stack { min-width: 0; max-width: min(calc(var(--dsh-chat-content-width, 748px) * 0.702), 82%);
  flex-direction: column; align-items: flex-end; gap: 8px; display: flex; }
.dci-umsg-bubble { background: var(--dsw-specific-bubble); border-radius: var(--dsw-radius-xl); max-width: 100%;
  font-size: var(--dsh-content-font-size, 14px); line-height: calc(22px + var(--dsh-content-font-delta, 0px));
  color: var(--dsw-alias-label-primary); white-space: pre-wrap; word-break: break-word; padding: 10px 16px; }
.dci-umsg-refsum { color: var(--dsw-alias-label-tertiary);
  font-size: var(--dsh-content-font-size-secondary, 13px); line-height: calc(18px + var(--dsh-content-font-delta-secondary, 0px)); }
.dci-umsg-attrow { flex-wrap: wrap; justify-content: flex-end; gap: 8px; max-width: 100%; display: flex; }
.dci-umsg-file { border: 0.5px solid var(--dsw-alias-border-l2, #0000001f); border-radius: var(--dsw-radius-xl);
  background: var(--dsw-specific-input-major, transparent); box-sizing: border-box; flex: 0 0 240px;
  align-items: center; gap: 10px; width: 240px; min-height: 64px; padding: 8px 12px; display: inline-flex; }
.dci-umsg-fileglyph { flex: none; width: 28px; height: 28px; }
.dci-umsg-filecontent { flex-direction: column; flex: 1; min-width: 0; display: flex; }
.dci-umsg-filename { white-space: nowrap; text-overflow: ellipsis; color: var(--dsw-alias-label-primary);
  font-size: 14px; font-weight: 500; line-height: 22px; overflow: hidden; }
.dci-umsg-filemeta { white-space: nowrap; text-overflow: ellipsis; color: var(--dsw-alias-label-tertiary, #00000073);
  font-size: 12px; line-height: 15px; overflow: hidden; }
.dci-umsg-actions { height: calc(28px + var(--dsh-content-font-delta, 0px)); align-items: center; gap: 8px; display: flex; }
.dci-umsg-time { font-size: var(--dsh-content-font-size-secondary, 13px);
  line-height: calc(24px + var(--dsh-content-font-delta, 0px)); color: var(--dsw-alias-label-tertiary); white-space: nowrap; padding-right: 12px; }
.dci-umsg-action { width: calc(28px + var(--dsh-content-font-delta, 0px)); height: calc(28px + var(--dsh-content-font-delta, 0px));
  border-radius: var(--dsw-radius-sm); color: var(--dsw-alias-label-tertiary); cursor: pointer; background: 0 0;
  border: none; justify-content: center; align-items: center; padding: 6px; display: inline-flex; }
.dci-umsg-action svg { width: calc(15px + var(--dsh-content-font-delta, 0px)); height: calc(15px + var(--dsh-content-font-delta, 0px)); }
.dci-umsg-action:hover { background: var(--dsw-alias-interactive-bg-hover); color: var(--dsw-alias-label-secondary); }
/* 悬停显形（官方 MessageItem.module.css 同款）：data-actions-reveal 挂在 assistant 的
   turn-tail 根上、不在用户消息的祖先链里，用户消息的实际驱动只有 flowItem 的
   data-chat-flow-kind 兄弟关系（后一条 user/steering 存在即隐藏，悬停/聚焦显形）。 */
@media (hover: hover) {
  :is([data-chat-flow-kind="user"], [data-chat-flow-kind="steering"]):has(~ :is([data-chat-flow-kind="user"], [data-chat-flow-kind="steering"])) .dci-umsg-actions { opacity: 0; transition: opacity 80ms; }
  :is([data-chat-flow-kind="user"], [data-chat-flow-kind="steering"]):hover .dci-umsg-actions,
  :is([data-chat-flow-kind="user"], [data-chat-flow-kind="steering"]):focus-within .dci-umsg-actions { opacity: 1; }
}
.dci-umsg-extra { margin: 8px 0 0; padding: 8px; border: 0.5px solid var(--dsw-alias-border-l2);
  border-radius: var(--dsw-radius-sm); font-family: var(--ds-font-family-code); font-size: 12px; line-height: 18px;
  overflow: auto; max-height: 200px; white-space: pre; }

/* Markdown 排版（官方 MarkdownText.module.css 逐条移植，.markdown → 本根）。 */
.dci-umsg-md { min-width: 0; overflow-wrap: anywhere; font: var(--dsw-font-markdown-base);
  color: var(--dsw-alias-label-primary); white-space: normal; }
.dci-umsg-md strong { font-weight: 600; }
.dci-umsg-md h1 { font: var(--dsw-font-markdown-h1); margin: 32px 0 16px; }
.dci-umsg-md h2 { font: var(--dsw-font-markdown-h2); margin: 32px 0 16px; }
.dci-umsg-md h3 { font: var(--dsw-font-markdown-h3); margin: 32px 0 16px; }
.dci-umsg-md h4 { font: var(--dsw-font-markdown-h4); margin: 16px 0; }
.dci-umsg-md :where(h5, h6) { font: var(--dsw-font-markdown-base-strong); margin: 16px 0; }
.dci-umsg-md :where(h1, h2, h3, h4, h5, h6) strong { font-weight: inherit; }
.dci-umsg-md p { margin: 16px 0; }
.dci-umsg-md :where(h4, h5, h6) + :where(ul, ol) { margin-top: 8px; }
.dci-umsg-md :where(h4, h5, h6):has(+ :where(ul, ol)) { margin-bottom: 8px; }
.dci-umsg-md a { color: var(--dsw-alias-link); font-weight: 500;
  transition: box-shadow var(--ds-transition-duration) var(--ds-ease-in-out); position: relative; text-decoration: none;
  border-left: 3px solid rgb(255 255 255 / 0); border-right: 3px solid rgb(255 255 255 / 0);
  border-top: 2px solid rgb(255 255 255 / 0); border-bottom: 2px solid rgb(255 255 255 / 0);
  margin-left: -3px; margin-right: -3px; }
.dci-umsg-md a:hover, .dci-umsg-md a:focus { outline: none; text-decoration: underline dotted var(--dsw-alias-link); text-underline-offset: 3px; }
.dci-umsg-md a:focus-visible { box-shadow: 0 0 0 2px var(--dsw-focus-ring-color, var(--dsw-alias-state-business-primary)); }
.dci-umsg-md :where(ul, ol) { margin: 16px 0; padding-left: 18px; }
.dci-umsg-md li:not(:first-child) { margin-top: 6px; }
.dci-umsg-md li > :where(ul, ol) { margin-top: 4px; }
.dci-umsg-md li::marker { line-height: 24px; color: var(--dsw-alias-label-secondary); }
.dci-umsg-md :where(ul, ol) ol { list-style-position: inside; padding-left: 0; }
.dci-umsg-md :where(ul, ol) ol li p { display: inline; }
.dci-umsg-md li > p { margin: 8px 0; }
.dci-umsg-md li > *:first-child { margin-top: 0; }
.dci-umsg-md hr { display: block; border: none; height: 0.5px; margin: 32px 0; background: var(--dsw-alias-border-l2); }
.dci-umsg-md blockquote { border-left: 2px solid var(--dsw-alias-label-caption); margin: 16px 0 0; padding-left: 14px; }
/* 围栏代码块：官方 CodeBlock.module.css 的 .block :where(pre) 逐值——底色/圆角/
   字体走官方 token（换肤跟随），气泡内靠底色与气泡面区分。语言横幅仍不做
   （组件头注释的已知边界）。 */
.dci-umsg-md pre { margin: 16px 0; padding: 16px; font: var(--dsw-font-markdown-code-block, var(--ds-font-family-code));
  background: var(--dsw-alias-markdown-code-block, color-mix(in srgb, currentColor 6%, transparent));
  color: var(--dsw-alias-label-primary); white-space: pre-wrap; word-break: break-all; overflow-x: auto;
  border-radius: var(--dsw-radius-lg); }
.dci-umsg-md pre code { font: inherit; background: none; padding: 0; }
.dci-umsg-md :not(pre) > code { display: inline-flex; align-items: center; box-sizing: border-box;
  font: var(--dsw-font-markdown-code); font-family: var(--ds-font-family-code); font-size: 0.875em !important;
  /* 底色与围栏代码块同一 token（--dsw-alias-markdown-code-block，产品决策 2026-10-29：
     两种代码面同色）。官方 --dsw-alias-markdown-inline-code 对页面底设计（深色
     rgb(41,41,41)），进用户气泡（深色 rgb(44,44,46)）只差 3/255 不可辨，故不取它。 */
  background-color: var(--dsw-alias-markdown-code-block, color-mix(in srgb, currentColor 6%, transparent));
  border: 0.5px solid var(--dsw-alias-border-l1);
  border-radius: var(--dsw-radius-sm); padding: 0 5px; }
.dci-umsg-md :where(h1, h2, h3, h4, h5, h6) code { font: inherit; font-family: var(--ds-font-family-code); }
.dci-umsg-md input[type='checkbox'] { margin: 0 8px 0 0; accent-color: var(--dsw-alias-label-secondary); }
/* 用户消息图片：width 由统一管线按 Obsidian 尺寸语法（![alt|120](url)）写成
   width 属性；这里不能写 width:auto（CSS 会覆盖 presentational hint，尺寸语法
   在用户消息侧失效）。只保留 max-width 约束，未带 width 的图片行为不变。 */
.dci-umsg-md img { display: block; max-width: 100%; height: auto; margin: 0;
  border-radius: var(--dsw-radius-md); background: var(--dsw-alias-bg-base); object-fit: contain; }
.dci-umsg-tscroll { max-width: 100%; overflow-x: auto; overscroll-behavior-x: contain; }
.dci-umsg-tscroll table { border-collapse: collapse; width: max-content; max-width: max-content; }
.dci-umsg-tscroll th { text-align: start; padding: 10px 16px; border-bottom: 0.5px solid var(--dsw-alias-border-l3);
  border-top: none; font: var(--dsw-font-markdown-table-head); max-width: min(30vw, 320px); min-width: 100px; }
.dci-umsg-tscroll td { padding: 10px 16px; border-bottom: 0.5px solid var(--dsw-alias-border-l2);
  font: var(--dsw-font-markdown-table); max-width: min(30vw, 320px); min-width: 100px; }
.dci-umsg-tscroll th:first-child, .dci-umsg-tscroll td:first-child { padding-left: 0; }
.dci-umsg-tscroll td:last-child { padding-right: 0; }
.dci-umsg-tscroll table code { font-size: 11px; }
.dci-umsg-md > :first-child, .dci-umsg-md p:first-child { margin-top: 0 !important; }
.dci-umsg-md > :last-child, .dci-umsg-md p:last-child { margin-bottom: 0 !important; }

/* 引用 chip（官方 user-text.module.css 逐条移植）：inline 走消费方基线，
   可点 chip 用官方 fileMention 的链接语言。 */
.dci-umsg-chip { display: inline; max-width: 100%; margin: 0 2px; color: var(--dsw-alias-state-business-primary);
  font-weight: 500; white-space: inherit; overflow-wrap: anywhere; text-align: inherit; }
button.dci-umsg-chip { margin: 0; padding: 0; border: none; background: none; font: inherit;
  color: var(--dsw-alias-link); text-decoration: none; cursor: pointer; }
button.dci-umsg-chip:hover, button.dci-umsg-chip:focus { outline: none; text-decoration: underline dotted var(--dsw-alias-link); text-underline-offset: 3px; }
button.dci-umsg-chip:focus-visible { box-shadow: 0 0 0 2px var(--dsw-focus-ring-color, var(--dsw-alias-state-business-primary)); }
.dci-umsg-chip[data-chip="slash"] { font-family: var(--dsw-font-markdown-code-font-family); }
.dci-umsg-chipicon { width: 1em; height: 1em; margin-right: 4px; vertical-align: -0.125em; }
` + markdownStyles + heavyMarkdownStyles;

export function injectStyles(): void {
  const el = document.getElementById(STYLE_ID);
  // 已有本插件样式（宿主热替换/原地更新插件后重 apply）时按内容原位刷新：
  // 旧 <style> 还挂着会让新版新增的类（如 dci-umsg-*）永远注入不进去。
  if (el) {
    if (el.textContent !== CSS) el.textContent = CSS;
    return;
  }
  const tag = document.createElement('style');
  tag.id = STYLE_ID;
  tag.textContent = CSS;
  document.head.appendChild(tag);
}
