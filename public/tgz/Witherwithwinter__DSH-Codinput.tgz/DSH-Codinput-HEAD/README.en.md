<p align="center">
  <img src="./assets/icon.png" width="128" alt="DSH-Codinput" />
</p>

<h1 align="center">DSH-Codinput</h1>

<p align="center">
  <a href="https://www.npmjs.com/package/dsh-codinput"><img src="https://img.shields.io/npm/v/dsh-codinput" alt="npm Version" /></a>
  <a href="https://github.com/deepseek-ai/deepseek-harness"><img src="https://img.shields.io/badge/DSH-0.2.2--rc.1%2B-blue" alt="DSH Version" /></a>
  <a href="https://www.npmjs.com/package/dsh-codinput"><img src="https://img.shields.io/npm/dm/dsh-codinput" alt="Downloads" /></a>
  <a href="https://github.com/Witherwithwinter/DSH-Codinput/stargazers"><img src="https://img.shields.io/github/stars/Witherwithwinter/DSH-Codinput" alt="GitHub Stars" /></a>
  <a href="./LICENSE"><img src="https://img.shields.io/github/license/Witherwithwinter/DSH-Codinput" alt="License" /></a>
</p>

<p align="center"><a href="./README.md">中文</a> | English</p>

<p align="center">An editor-style input panel, right where the DeepSeek Harness chat composer used to be.</p>

<table>
  <tr>
    <td width="50%"><img src="./assets/preview-normal.webp" alt="Default mode" /><br /><sub>Default mode (takes over the original composer slot)</sub></td>
    <td width="50%"><img src="./assets/preview-split.webp" alt="Edit + preview split" /><br /><sub>Edit + preview split (exactly half and half)</sub></td>
  </tr>
  <tr>
    <td width="50%"><img src="./assets/preview-float.webp" alt="Floating mode" /><br /><sub>Floating mode (draggable, resizable from all 8 edges/corners)</sub></td>
    <td width="50%"><img src="./assets/preview-side.webp" alt="Sidebar tab mode" /><br /><sub>Sidebar tab mode (full-height, VS Code panel style)</sub></td>
  </tr>
</table>

## Features

**Three modes, one instance** — the input surface exists in exactly one of three states at any moment, and never coexists with the official composer:

| Mode | How to enter | Behaviour |
| --- | --- | --- |
| Normal `normal` | default | The takeover card sits in the composer's own place |
| Floating `float` | drag the blank area of the card's top row | Pops out into a floating window: draggable, resizable from all four edges and four corners (position and size are remembered) |
| Sidebar tab `side` | open the “Codinput” tab in the right sidebar | The input lives in the sidebar panel; **collapsing the sidebar does not give the composer back** — the round ball under the title bar brings it back; `/codinput` from the sidebar exits to the official composer and closes the tab |

- **Editor**: line numbers (optional), current-line and gutter highlighting, soft wrap, Tab indentation, a line/column indicator, and an **edit + preview split** (live markdown, exactly half and half); **the editor always renders literal characters** (no ligatures — `->` / `//` stay as typed, which avoids host font-shaping differences and “missing character” misreads, and matches the preview / message plain-text rendering).
- **Undo history that survives mode switches**: drag into floating mode, hop into the sidebar, come back — `Ctrl+Z` still works. All three modes share the same official input machine, whose draft is the single source of truth (it survives mode switches, `/codinput` exit/re-entry, plugin toggles and reloads).
- **`/` `@`**: entirely the official trigger pipeline (track → official menu store → a faithful MenuView replica): candidate menu, drill-down, crumbs and skeletons match the official UI; `/codinput` slots into the head of the commands section alphabetically; everything else keeps the official usage order. In floating / sidebar modes the candidate menu becomes an adaptive four-way flyout around the card (top / bottom / left / right free space) so it never covers the input area or reflows the card.
- **Bottom control row (0.4.0)**: value-for-value aligned with the official `0.2.2-rc.1` InputBar — `+` commands button, `conversation.input.permission` / `.plan` slot mirrors (official permission selector / plan chip), `input.left` / `.right` / `.model` seats, the voice activity seat (microphone), the official separate stop button and sending spinner, official stop / sending / steer·queue labels, `@container` narrow-width gaps and model-text compaction.
- **Model & reasoning effort**: read from the official shared directory (the same state source as `/model`). **Permissions**: the three official presets plus the RiskConfirmation modal for full access.
- **Attachments**: slash Add · File (the takeover surface binds the shell's file-picker contract, so the entry keeps working while Codinput owns the composer), **paste images directly**, or **drop files onto the card** (clicking an image thumbnail opens the original-image lightbox, an ImageLightbox replica; the rail is a faithful replica of the official one: 64×64 image thumbnails, file cards with type glyph/name/size, upload spinner, progress bar, retry on failure).
- **Voice input sync (official desktop app)**: when the official desktop composer ships a voice button, Codinput renders **the very same button in the very same place** — it renders the official voice component itself (mic trigger, recording waveform, transcription, setup prompt and all copy are official code); hosts without the native voice button (all web channels) render none.
- **Performance & usage**: a replica of the official stats dock — turns/steps · tok/s, total tok · cache hit, plus the context-usage dial — with value-for-value parity in data and formatting, each opening a detail panel; available in all three modes. The three detail panels (session stats / token usage / context segments) are portal-positioned, follow scrolling and size changes, close on Escape or outside click, and only one is open at a time.
- **User-message Markdown (0.3.7 / 0.4.0)**: messages sent by the user render as Markdown through the **same rendering pipeline as the editor preview** (unified in 0.4.0), while keeping the official bubble chrome — attachment rows, @file/@session//skill reference chips (clickable), copy button and timestamp, reference summary and hover reveal; **image attachments render through the official image slot (thumbnails + the official full-image lightbox on click), and raw HTML is escaped to text (chips cannot be forged)**. Settings → Codinput → User-message Markdown rendering (on by default); turning it off restores official plain text without a reload.
- **Markdown rendering (0.4.0, Obsidian-style, fully bundled and offline)**: GFM tables (alignment, horizontally scrollable when wide) / task lists (read-only checkboxes, nesting) / strikethrough / autolinks; **footnotes** (superscripts + end-of-document footnote area + back-jump); **Obsidian callouts** (`> [!note|tip|warning|danger|info|success|question|quote]`, icons/colours/collapsible, readable in light and dark themes); Obsidian syntax `==highlight==`, `%%comments%%` (hidden, never mis-parsed inside code), `[[wikilink|alias]]` (chip, click copies the target), `![[file]]` (styled text fallback), image sizing `![alt|300](url)`; Markdown images open a lightbox on click. **Code blocks**: highlight.js with 46 languages + language label + copy button; **math**: KaTeX inline `$...$` and block `$$...$$` (20 woff2 fonts inlined as data URIs — **zero network requests**, failed formulas fall back to source); **Mermaid**: 13 diagram types (flowchart / sequence / class / state / ER / gantt / pie / journey / gitGraph / info / mindmap / timeline), lazily rendered when visible, follows the light/dark theme, `securityLevel:'strict'`, syntax errors and unsupported diagram types fall back to “source + error note”. Security: raw HTML is always escaped, external links get `target=_blank rel=noopener noreferrer`, `javascript:`/`data:` protocols are blocked, KaTeX runs with `trust:false`, and Mermaid SVGs go through DOMPurify.
- **Plugin-page icon (0.3.7)**: the packaged `assets/icon.png` is exposed through the `package.json` top-level `icon` field (manifest-relative path, SVG/PNG/JPEG/WebP, 256 KiB max), so the installed-plugins list no longer falls back to the default image.
- **Markdown body ligatures (0.4.0, on by default)**: the preview and user-message **body text uses the JetBrains Mono monospace font**, so `->` / `=>` / `//` etc. are drawn as ligature arrows (the DOM text and the sent message stay literal — no character replacement); it can be turned off in Settings (body returns to the reading font); **the editor keeps literal characters** (the host Chromium 152 CodeMirror ligature bug has no workaround). Code blocks and inline code use their own code font (**and also show the ligature arrows**).
- **Settings**: Settings → Codinput (takeover on/off, line numbers, font, **Markdown body ligatures (on by default)**, **fully custom send / line-break shortcuts** via a recorder, default view); with the takeover off, **opening the Codinput tab in the right sidebar enables it directly**.

## Installation

Requires the host `@deepseek-ai/dsh` (see compatibility below).

### Method A: npm package

```bash
dsh plugin --profile web add dsh-codinput
```

That single command is enough: `dsh plugin` goes through the official profile package manager, which reads this package's `dsh.bundle` metadata, validates the `cordis.patch.yml` it ships (`dsh.bundle.patch`), and appends the package name to the profile's `bundles` — no hand-written patch entry.

Then start it with `dsh web` (if it is already running, just hard-reload the page — profiles default to `patchReload: live`).

### Method B: GitHub source

```bash
dsh plugin --profile web add github:Witherwithwinter/DSH-Codinput
```

The repository ships the built `lib/`, so a source install **does not need a local build** either. If pnpm asks for build authorisation (for example if you install your own fork with `lib/` removed), write the key it prints into the profile's `pnpm-workspace.yaml` and re-run:

```yaml
allowBuilds:
  esbuild@0.25.12: true
```

### Method C: local source (development)

```bash
git clone https://github.com/Witherwithwinter/DSH-Codinput.git
dsh plugin --profile web add link:/abs/path/to/DSH-Codinput
```

A `link:` install copies nothing, so `npm run build` plus a page reload is enough.

### Method D: the equivalent manual config

To pin a version or maintain the profile by hand, the manual equivalent of **Method A** is (`~/.dsh/profiles/web/package.json`):

```jsonc
{
  "dependencies": {
    "dsh-codinput": "^0.4.1"          // for local development: "link:/abs/path/to/DSH-Codinput"
  },
  "dsh": {
    "profile": {
      "bundles": [
        "@deepseek-ai/dsh-base",
        "@deepseek-ai/dsh-web-app",
        "dsh-codinput"                // ← append last
      ],
      "patchReload": "live"           // after rebuilding lib/client.js, just reload the page
    }
  }
}
```

After editing the profile by hand, run `pnpm install` inside the profile directory (or `dsh plugin --profile web install`), then `dsh web`.

## Compatibility

The host publishes **rc** builds on npm: `latest` is the current stable rc, `next` the following rc, `alpha` further ahead (as of 2026-11-06, `latest` / `next` both point at `0.2.2-rc.1`, `alpha` is `0.2.2-alpha.3`), so a plain install gives you an rc.

| Host version | Status |
| --- | --- |
| Desktop app (Electron, `0.2.2-rc.1`) | ✅ 0.4.0 target snapshot: the bottom control row, microphone, user-message images and drafts were checked value by value against that version's official packages (npm `@deepseek-ai/dsh@0.2.2-rc.1`, the same version bundled in the desktop `app.asar`) and verified on an isolated web host of the same version with headless Edge probes (see CHANGELOG); 0.4.0 was additionally run on an isolated desktop instance (Electron 44.7 / Chromium 152, separate `--user-data-dir` plus a copied `DSH_HOME`, never touching a live instance) to verify literal-character rendering (ligatures removed) and typing regressions; final desktop eyeballing is confirmed by the user. The `0.2.1-rc.2` voice end-to-end run recorded in 0.3.2 still holds |
| web `0.2.0-rc.2` | ✅ Verified on a real instance (this machine's earlier web host; the slot mirrors, model-seat delegation, user-message Markdown and three-panel exclusivity from 0.3.5–0.3.7 were verified on this build with Chromium automation probes; the 0.3.8 portal-panel placement/Escape/outside-close and Markdown hardening were additionally re-checked in an isolated host with headless Edge; the 0.4.0 draft retention on `/codinput` exit, ligature and floating/sidebar candidate-menu flyout were verified on this build in an isolated host with headless Edge probes — see CHANGELOG) |
| web `0.2.2-rc.1` | ✅ Verified on a real instance (0.3.9 menu-fix pass 33/33 assertions; the 0.4.0 bottom-row parity, microphone seat, official image thumbnails + lightbox, single official question-reply card, and the prefs migration / stats boundary work were verified on this build in an isolated host with headless Edge probes; 0.4.0's Markdown rendering upgrade — unified pipeline / GFM / footnotes / callouts / Obsidian syntax / image sizing and lightbox / code highlighting + copy / KaTeX (offline inlined fonts) / Mermaid with 13 diagram types — was fully verified on this build in an isolated host with headless Edge probes, see CHANGELOG; the 0.4.1 issue #8 sub-seat fix (third-party `composer.dock` entries mirrored, unmirrored-seat audit) was verified on this build in an isolated host with `dsh-cost-meter@1.9.64` / `dsh-context@0.84.1`) |
| `0.1.7-rc.2` | ✅ Verified on a real instance (the acrylic candidate menu, the relocated context meter and the dock row layout are aligned to this build) |
| `0.1.5-rc.2` | ✅ Verified on a real instance |
| `0.1.6-alpha.2` | ✅ Current development baseline; every feature verified end to end |
| others (incl. current `latest` / `next` = `0.2.2-rc.1`) | untested; older hosts lack the rc.2 tokens, so the fallback chain keeps each host's official look |

For `0.1.7-rc.2` / web `0.2.0-rc.2`, on top of the real-instance run, the official CSS for the candidate menu, the context meter, the stats dock and the user-message bubble were extracted value by value from the corresponding version's client packages (`dsh-client-ui-theme` / `dsh-client-ui-input-trigger` / `dsh-client-ui-conversation` / `dsh-client-ui-chat`) and checked against the replicas. The contracts this plugin relies on were verified per version: the slots it uses (`conversation.composer.bar`, `sidebar.right.pane.tab`, `settings.section`, plus `conversation.chat.node` and the `conversation.input.*` sub-seats), the `sidebarRight` / `sidebarRightTabs` / `locale` services and `openTabIn`, the sidebar expansion planner (dockkit `planSetExpanded`), the file-picker and tab-close contracts (`shell.bindFilePicker` / `tab.actions.close`), and the official primitives the replicas are copied from (`fileSizeText` / `fileExtension` and the attachment glyph paths, byte for byte); the 0.3.9 menu fix was additionally verified on an isolated web `0.2.2-rc.1` host with headless Edge automation (33/33 assertions); the 0.4.0 draft retention, ligature and candidate-menu flyout work was verified on an isolated web `0.2.0-rc.2` host with headless Edge automation; the 0.4.0 bottom-row parity, microphone, user-message image lightbox and prefs/stats work was verified on an isolated web `0.2.2-rc.1` host with headless Edge automation; 0.4.0 was additionally verified on an isolated desktop Electron 44.7 (Chromium 152) instance for literal-character rendering (no ligatures; `->` / `//` stay as typed) and typing regressions; 0.4.0's Markdown rendering upgrade was fully verified on an isolated web `0.2.2-rc.1` host with headless Edge probes (GFM / footnotes / callouts / Obsidian syntax / image sizing and lightbox / code highlighting + copy / offline KaTeX / Mermaid / security / consistency and regressions), with the final desktop eyeballing confirmed by the user. The desktop `0.2.2-rc.1` build is the same package version as that isolated host. For how to re-run this on another channel, see the “Verifying on another channel” section of [TESTING.md](./TESTING.md).

The plugin leans on host internals (slot shadowing, `useTabInfo`, `sidebarRight`, `--dsw-*` tokens). Every call site guards with `typeof` checks and degrades gracefully, but a major host upgrade can still break it. **After upgrading the host, walk through [TESTING.md](./TESTING.md).**

### Theme / skin plugin compatibility (for skin authors)

Codinput ships no colors of its own: every color comes from the host's `--dsw-*` design tokens (light/dark follows the host). How theme/skin plugins for the host get along with Codinput:

- **Overriding host tokens restyles everything at once** — once you override `--dsw-*` variables, Codinput's card, menus, buttons and badges follow along with the official UI; no per-plugin adaptation needed. Note the host defines its tokens on `body` (`body[data-ds-dark-theme]`), so overrides must live on that same level: ones written on `:root` are shadowed by the `body` definitions.
- **Values the official UI hardcodes, Codinput hardcodes too** (the white foreground of the send-button icon, the purple of the context meter's tools segment, etc.) — value-for-value parity with how the official UI behaves under a reskin. These do not follow tokens; that is expected.
- **To target Codinput precisely**: every element uses the stable `dci-` class prefix (card `.dci-card`, send button `.dci-send`, menus `.dci-menu` / `.dci-slash-menu`, stats row `.dci-stat-root`, recall ball `.dci-ball`, …) — use them directly as skin selectors. The plugin injects its styles once as `<style id="dsh-codinput-styles">`; skin styles injected later win by normal CSS specificity.
- The editor (CodeMirror) font is a user preference (monospace stack by default) and does not follow skin fonts; its colors do follow the tokens.

## Known limitations

- `/` `@` candidates come from host directories (skills / commands / files / sessions); when the host provides none, the menu is empty — the plugin cannot fill that in.
- **The editor has no syntax highlighting** (the preview, messages and code blocks do have highlight.js highlighting) and **no Esc behaviour** — deliberate product decisions (this is an input panel, not a code reader; the edit side stays plain and WYSIWYG).
- **Markdown rendering is fully bundled and offline-first** (0.4.0): KaTeX fonts, highlight.js and Mermaid all ship with the plugin with zero runtime network requests; the trade-off is `lib/client.js` growing from ~540KB to ~3.4MB (gzip ~1.1MB).
- **Mermaid bundles only 13 common diagram types**: the other 24 (sankey, xychart, kanban, quadrantChart, …) are not shipped and fall back to “source + error note”; the ELK / cytoscape layout engines are not shipped either (licence and size), so diagrams requesting ELK fall back to dagre as mermaid itself does.
- **`[[wikilink]]` is a styled chip (click copies the target name)**, with no repository navigation (the host has no such target); `![[image]]` likewise only degrades to styled text and never loads repository files.
- **Raw HTML in Markdown is always escaped** (security decision): unlike Obsidian, `<div>` / `<script>` etc. are shown as visible text — never executed, never part of the layout.
- While a Codinput sidebar tab exists the composer is hidden entirely (single input surface rule; browsing another tab in the same pane does not bring it back). The official stats dock and context dial live inside the official composer, so they disappear with it and the replicated stats row takes over.
- **Third-party sub-seat mirroring boundary**: mirrored seats are `input.left` / `.right` / `.model` / `.model.label` / `.permission` / `.plan` / `.activity` and `composer.dock` (so cost-meter-style dock items are back; only **third-party** entries are mirrored — the host's own `ActivityPill` / `UsagePill` are covered by Codinput's replicated stats row, so mirroring the whole seat would duplicate them); **`input.overlay` / `input.attachments` are not mirrored** — third-party tenants such as dsh-context's context overlay and `@knyazevai/dsh-client-ui-attachment`'s attachment row are invisible while takeover is active. Host-side reason: the official slot authorises only the entry that declares a child to render it (one live owner per declaration), so shadowing `composer.bar` orphans its children and there is no native passthrough — a takeover plugin can only mirror each seat by hand (`conversation.input.dock` sits outside the bar and is unaffected). When an unmirrored seat has **third-party** occupants, the plugin records `slot.unmirrored` in `__dshCodinputErrs` and warns in the console; shipped occupants (`slash-menu` / `command-popup` / `feedback-dialog` / `ComposerAttachments`) are skipped silently (their UI is covered by Codinput's own surfaces or other host render paths), so a clean host is not spammed.
- Duplicating the “Codinput” tab into a second split pane shows a notice instead of a second editor (the input surface stays unique).
- The floating gesture only keeps “drag back to the composer area = normal”; “drag into the right sidebar = sidebar mode” was dropped by product decision.
- After a page reload, if the sidebar layout restores a Codinput tab that has not been opened yet, the composer shows up first — dockkit mounts restored tab bodies lazily; opening the tab once restores the sidebar carry.
- **No font ligatures in the editor**: `->`, `//` etc. are drawn literally (no arrow / merged glyphs). Reason: ligature glyphs read as “missing characters”, and DSH desktop `0.2.2-rc.1` (Electron 44.7 / Chromium 152) has a `calt` shaping bug (the first cell of a ligature followed by any subsequent character is drawn blank) that no CSS can reliably work around; the preview / message area is plain text anyway, so the editor now matches it — what you see is what is stored.

## Development

```bash
npm install
npm run build        # release bundle → lib/client.js (minified)
npm run build:dev    # unminified + inline sourcemap (readable TypeScript in the browser)
npm run typecheck
```

- `src/client/` holds the whole client side; host APIs are described by local structural types (zero runtime dependency on the host — only `react`/`react-dom` are treated as platform externals).
- `lib/index.js` is the host half (a bare mounting carrier); `lib/client.js` comes from the build and is **committed alongside the source** (that is what lets a source install skip building).
- **CI is a static gate only**: `npm ci` + `tsc --noEmit` + the release build + artifact checks (bundle non-empty, contains `__ModuleLoader__.load`, no inline sourcemap). It never loads a page or connects to the host, so it gives **zero coverage of runtime behaviour** — that lives in the manual checklist in [TESTING.md](./TESTING.md).
- Diagnostics (also present in production): `window.__dshCodinputDebug / __dshCodinputErrs / __dshCodinputSessionId / __dshCodinputTriggers / __dshCodinputKeyboard / __dshCodinputShell / __dshCodinputCtx`.
- Dev helpers: `node scripts/extract-official-css.mjs <host client.js> [out.css]` extracts an official CSS module verbatim (used to replicate official styling value by value).

### Host facts worth knowing before changing code

- **Takeover point**: `conversation.composer.bar` (a `single` slot; `priority:-1` shadows the official entry). Disposing the entry restores the official composer untouched.
- **Single input surface**: a sidebar tab body **counts as carrying the input the moment it mounts** (not based on visibility — collapsing the sidebar is CSS hiding plus a translate, the body stays mounted). The main entry renders `null` accordingly, and the mode is derived as `carrying ? 'side' : prefs.mode`, so coexistence is impossible by construction. The carry claim lives on the body's lifetime, so the tab definition sets `keepMounted: true`: dockkit unmounts inactive tab bodies by default, and switching to another tab in the same pane would drop the claim and bring the composer back (same switch the official browser tab uses; note a tab restored after a reload only mounts its body once it has been activated).
- **Undo history**: switching modes remounts the editor, so `EditorState` is cached per session (`take/putEditorSnapshot`); extension callbacks go through a module-level hooks slot so a reused state never calls into an unmounted instance's props.
- **Official-side writes** (pick / claim / submit-clears) carry `externalAnnotation` + `Transaction.addToHistory.of(false)`, so undo only ever reverts what you typed.
- **Drawing a circle needs `corner-shape: round`**: the host root sets `corner-shape: superellipse(1.5)` globally, so a plain `border-radius:50%` renders as a rounded square.
- **The ball occupies no slot**: `conversation.session.header.corner` is the official sidebar expand button's seat (a `single` slot — taking it would remove the official button), so the ball is portalled to `body` and positioned from the measured header rect.
- **The slash File entry lives on the filePicker binding**: the official `file` contribution's `available` reads `shell.canPickFiles()`, and the picker is bound by the official InputBar when it mounts (`bindFilePicker`) and unbound on unmount — the takeover surface must re-bind it on mount (`attachments.bindSessionFilePicker`) or the entry disappears. **Never register a same-name contribution**: the host rejects duplicates at `register` time, fail-loud.
- **Closing a tab goes through the tab-domain action face**: `useTabInfo().tab.actions.close()` closes the tab itself (dockkit semantics; with a single docked tab it lays a guide down and collapses). To locate the session, do not use the diagnostic `__dshCodinputSessionId` (surface unmounts null it) — read the carry snapshot from the sideinput bus.

## Third-party attribution

Parts of this project **replicate DeepSeek Harness** (`@deepseek-ai/dsh`, MIT License, Copyright (c) 2026 DeepSeek): several SVG icon paths (the permission shield set, plus, paperclip, close, arrow-up, the generic file glyph, …) and CSS values for the composer card, the attachment rail and the original-image lightbox. They are used under the MIT license; the original copyright and permission notice are retained in [NOTICE](./NOTICE) alongside [LICENSE](./LICENSE).

Bundled third-party dependencies: CodeMirror 6 (MIT), marked (MIT), DOMPurify (Apache-2.0 / MPL-2.0 dual licensed, used under Apache-2.0) — the minified bundle strips license comments, so their copyright and license notices are retained in [NOTICE](./NOTICE).

## Support

If this project helps you, you are welcome to buy me a bowl of rice 🍚:

<img src="./assets/donate-qr.jpg" alt="0x2f's tip QR code (buy me a bowl of rice)" width="280" />

## License

[MIT](./LICENSE)
