﻿# Requires PowerShell 5.1+, Python 3.10+ and ffmpeg/ffprobe.
param(
  [ValidatePattern('^[A-Za-z0-9_-]+$')][string]$Profile = 'web',
  [switch]$SkipDeps,
  [switch]$Uninstall
)
$ErrorActionPreference = 'Stop'
$sourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$dshRoot = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $env:USERPROFILE '.dsh' }
$profileDir = [IO.Path]::GetFullPath((Join-Path $dshRoot "profiles\$Profile"))
$nodeDir = [IO.Path]::GetFullPath((Join-Path $profileDir 'node_modules\bili-vision'))
$manifest = Join-Path $profileDir 'package.json'
if (-not (Test-Path -LiteralPath $manifest)) { throw "找不到 profile：$manifest" }
$pkg = Get-Content -LiteralPath $manifest -Raw -Encoding UTF8 | ConvertFrom-Json
if (-not $pkg.dsh -or -not $pkg.dsh.profile) { throw 'profile 缺少 dsh.profile 配置' }
$bundles = @($pkg.dsh.profile.bundles | Where-Object { $null -ne $_ })

function Write-Manifest($value) {
  $json = $value | ConvertTo-Json -Depth 100
  $null = $json | ConvertFrom-Json
  $backup = "$manifest.bak.$([DateTime]::Now.ToString('yyyyMMddHHmmssfff'))"
  $temp = "$manifest.$([Guid]::NewGuid().ToString('N')).tmp"
  [IO.File]::WriteAllText($temp, $json + [Environment]::NewLine, (New-Object Text.UTF8Encoding($false)))
  try { [IO.File]::Replace($temp, $manifest, $backup) }
  finally { if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp } }
}

if ($Uninstall) {
  $pkg.dsh.profile | Add-Member -MemberType NoteProperty -Name bundles -Value @($bundles | Where-Object { $_ -ne 'bili-vision' }) -Force
  Write-Manifest $pkg
  if (Test-Path -LiteralPath $nodeDir) {
    $resolved = (Resolve-Path -LiteralPath $nodeDir).Path
    $expected = [IO.Path]::GetFullPath((Join-Path $profileDir 'node_modules\bili-vision'))
    if ($resolved -ne $expected -or (((Get-Item -LiteralPath $nodeDir -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
      throw "拒绝删除非预期目录或链接：$resolved"
    }
    Remove-Item -LiteralPath $resolved -Recurse -Force
  }
  Write-Host '插件已卸载；视频缓存及独立 Python 环境保留。重启 DSH 后生效。'
  return
}

$ff = if ($env:BILI_VISION_FFMPEG) { $env:BILI_VISION_FFMPEG } else { (Get-Command ffmpeg -ErrorAction SilentlyContinue).Source }
$fp = if ($env:BILI_VISION_FFPROBE) { $env:BILI_VISION_FFPROBE } elseif ($ff) { Join-Path (Split-Path $ff -Parent) 'ffprobe.exe' }
if (-not $fp -or -not (Test-Path -LiteralPath $fp)) { $fp = (Get-Command ffprobe -ErrorAction SilentlyContinue).Source }
if (-not $ff -or -not (Test-Path -LiteralPath $ff) -or -not $fp -or -not (Test-Path -LiteralPath $fp)) {
  throw '需要 ffmpeg 和 ffprobe；加入 PATH 或设置 BILI_VISION_FFMPEG / BILI_VISION_FFPROBE。'
}
$venv = Join-Path $dshRoot 'bili-vision-venv'
$venvPy = Join-Path $venv 'Scripts\python.exe'
$py = $env:BILI_VISION_PYTHON
if (-not $py -and (Test-Path -LiteralPath $venvPy)) { $py = $venvPy }
if (-not $py) {
  $bundled = Join-Path $dshRoot 'dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe'
  $py = if (Test-Path -LiteralPath $bundled) { $bundled } else { (Get-Command python -ErrorAction SilentlyContinue).Source }
}
if (-not $py) { throw '找不到 Python；设置 BILI_VISION_PYTHON 为 Python 3.10+ 路径。' }
& $py -c 'import sys; sys.exit(sys.version_info < (3,10))'
if ($LASTEXITCODE -ne 0) { throw 'Python 版本必须为 3.10+' }
if (-not $SkipDeps) {
  if (-not $env:BILI_VISION_PYTHON -and $py -ne $venvPy) {
    & $py -m venv $venv
    if ($LASTEXITCODE -ne 0) { throw '创建独立 Python 环境失败' }
    $py = $venvPy
  }
  & $py -m pip install --disable-pip-version-check -r (Join-Path $sourceDir 'requirements.txt')
  if ($LASTEXITCODE -ne 0) { throw '依赖安装失败，尚未注册插件' }
}
New-Item -ItemType Directory -Force -Path $nodeDir | Out-Null
if ([IO.Path]::GetFullPath($sourceDir) -ne $nodeDir) {
  foreach ($name in @('index.js','bv.py','README.md','requirements.txt','package.json','cordis.patch.yml','install.ps1','smoke.mjs','LICENSE','CHANGELOG.md')) {
    Copy-Item -LiteralPath (Join-Path $sourceDir $name) -Destination (Join-Path $nodeDir $name) -Force
  }
  $testDest = Join-Path $nodeDir 'tests'
  New-Item -ItemType Directory -Force -Path $testDest | Out-Null
  Get-ChildItem -LiteralPath (Join-Path $sourceDir 'tests') -File | Copy-Item -Destination $testDest -Force
  $localeDest = Join-Path $nodeDir 'locale'
  New-Item -ItemType Directory -Force -Path $localeDest | Out-Null
  Get-ChildItem -LiteralPath (Join-Path $sourceDir 'locale') -Filter '*.json' -File | Copy-Item -Destination $localeDest -Force
}
# Persist the interpreter actually used by installation, including custom paths.
$quotedPython = ConvertTo-Json -InputObject ([string]$py) -Compress
$patch = "- insert:`n    - id: bili-vision`n      name: 'bili-vision'`n      inject: [tools]`n      config:`n        python: $quotedPython`n        defaultPolicy: auto`n"
[IO.File]::WriteAllText((Join-Path $nodeDir 'cordis.patch.yml'), $patch, (New-Object Text.UTF8Encoding($false)))
if ($bundles -notcontains 'bili-vision') { $bundles += 'bili-vision' }
$pkg.dsh.profile | Add-Member -MemberType NoteProperty -Name bundles -Value @($bundles) -Force
Write-Manifest $pkg
Write-Host "已安装 bili-vision 到 $Profile，Python: $py"
Write-Host '重启 DSH 后生效。默认 inspect 把画面直接交给当前视觉模型，不额外调用独立 API。'
