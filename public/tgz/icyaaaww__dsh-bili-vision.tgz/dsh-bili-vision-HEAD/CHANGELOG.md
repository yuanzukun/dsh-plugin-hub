# Changelog

## 0.2.0 — 2026-10-23

- Return timestamped video evidence as native DSH image attachments with subtitles, local ASR and OCR.
- Preserve optional independent vision API analysis through `action=run`; direct evidence uses `action=inspect`.
- Add full-video temporal coverage, focused time ranges, configurable grids and exact image deduplication.
- Cache transcripts, frames, OCR and independent model answers; isolate multipart videos and incomplete downloads.
- Validate tool schemas and image-capable routes; cancel child processes when the tool is cancelled.
- Fix frame tail extraction, JPEG encoding and PowerShell profile manifest updates.
- Package as a DSH bundle with public exports, localized metadata and explicit compatibility range.

Tested host: DSH 0.2.0-rc.2 on Windows. Other host versions and operating systems require validation.
No claim of exhaustive frame-by-frame understanding or measured latency/cost savings is made.
