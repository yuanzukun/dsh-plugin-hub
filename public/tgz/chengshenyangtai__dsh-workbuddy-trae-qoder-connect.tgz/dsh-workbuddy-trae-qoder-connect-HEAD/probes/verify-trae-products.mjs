/**
 * Trae「产品变体」离线验证（确定性，不依赖 DSH 重启、默认不打上游）
 *
 * 覆盖 2026-10-07「接入 Trae CN」、2026-10-11「SOLO 独立客户端被并入 Trae CN IDE」
 * 两次改动的全部承重逻辑：
 *   1. `resolveProduct` / `activeProduct` 的判定优先级（配置 > 快照声明 > 双向嗅探 > 现役兜底）；
 *      兜底值这次从 solo 翻成了 cn，所以**存量 SOLO 快照必须靠嗅探命中**，
 *      否则它们会在某次重启之后突然掉模型、掉倍率、掉档位。
 *   2. `TRAE_PRODUCTS` 两张变体表的字段完整性与内部一致性；
 *   3. `decodeModelId` 的 function 白名单**按产品**放行（CN 侧只剩 IDE 的三个分组）；
 *   4. 账号写接口的 `req_source` 确实由产品决定（CN=1 / SOLO=2）；
 *   5. 模型目录按产品分文件、per-function 的档位与窗口不丢、
 *      `maxTokens` 不越过任一 dev 窗口（越界会**静默开 Max、5× 计费**）；
 *   6. 倍率查询集**恰好等于**该产品的目录分组，多一个名字都没有。
 *
 * ⚠️ 第 5 组依赖宿主导出的真实快照（`~/.dsh/trae-cn/models.json` 等）。
 * 没装 Trae 的机器上这些断言**自动跳过**并说明原因 —— 本脚本必须能在任何机器上跑绿，
 * 否则它在 CI / 别人手里就是个永久红灯，反而掩盖真问题。
 *
 * 做法（与同目录其它 verify-* 一致）：provider 的 peer 依赖打包在应用 asar 里，
 * 外部 import 会 MODULE_NOT_FOUND，所以把源码拷进临时目录、用极小的桩替换那几个
 * import，**被测函数体一个字节都不改**。
 *
 * 用法：
 *   node probes/verify-trae-products.mjs            # 验证仓库自己的源码
 *   node probes/verify-trae-products.mjs --installed # 验证已安装的那份
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pathToFileURL } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO = path.join(HERE, '..');
const INSTALLED = path.join(os.homedir(), '.dsh', 'profiles', 'desktop', 'node_modules', process.env.DSH_CONNECT_DIR ?? 'dsh-workbuddy-trae-qoder-connect');
const USE_INSTALLED = process.argv.includes('--installed');
const SRC_ROOT = USE_INSTALLED ? INSTALLED : REPO;
const HOME = path.join(os.homedir(), '.dsh');

const SRC = path.join(SRC_ROOT, 'lib', 'providers', 'trae', 'index.js');
if (!fs.existsSync(SRC)) {
  console.error(`找不到 trae provider：${SRC}\n（用 --installed 可以改测已安装的那份）`);
  process.exit(2);
}
/** provider 源码文本：给"取值优先级"这类结构性断言用。 */
const traeSrc = fs.readFileSync(SRC, 'utf8');

// ── 沙箱：peer 依赖打桩，源码本体不动 ──────────────────────────────────────
const SANDBOX = path.join(os.tmpdir(), 'dsh-trae-products-sandbox');
fs.rmSync(SANDBOX, { recursive: true, force: true });
fs.mkdirSync(SANDBOX, { recursive: true });
// 沙箱根声明 ESM：原包靠 package.json 的 "type":"module"，拷出来必须自己补，
// 否则 .js 被当 CommonJS，import 直接语法错。
fs.writeFileSync(path.join(SANDBOX, 'package.json'), JSON.stringify({ name: 'trae-provider-sandbox', type: 'module', private: true }, null, 1));
// 只拷 trae provider 与它 import 的 shared/*.js：垫片 `withLegacyImageBudget` 在
// shared/http.js，`readBody`/`pollInterval`/`writeState` 在 shared/node.js。
// 不再需要 providers/workbuddy/**（它会把 variants-CnrmSn0Q.js 一并拖进来）。
//
// ⚠️ 这份清单**按目录扫**而不是手写：以前是写死的两个路径，2026-10-08 把三个
// 重复函数提到 shared/node.js 之后探针直接 ERR_MODULE_NOT_FOUND。扫描能自动跟上
// 后续的拆分，不必每次记得改这里。
for (const rel of fs.readdirSync(path.join(SRC_ROOT, 'lib/shared')).filter((f) => f.endsWith('.js')).map((f) => `lib/shared/${f}`).concat(['lib/providers/trae/index.js'])) {
  const dst = path.join(SANDBOX, rel);
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.copyFileSync(path.join(SRC_ROOT, rel), dst);
}

const stubs = {
  // 两个说明符（`.` 与子路径）**都要**带 openAICompletionsApi —— Node 按导出名校验。
  '@earendil-works/pi-ai': 'export function createProvider(o){return o;}\nexport function openAICompletionsApi(){return {id:"stub"};}',
  '@deepseek-ai/dsh-llm-pi-ai': 'export class PiAiAdapter{constructor(o){this.o=o;}}',
  '@deepseek-ai/dsh-llm': 'export function resolveRetryPolicy(_v,label){return {label};}',
  '@deepseek-ai/dsh-home-paths': `import { homedir } from "node:os";
import { join } from "node:path";
export function resolveDshHome(){ const c = process.env.DSH_HOME?.trim(); return c === undefined || c === "" ? join(homedir(), ".dsh") : c; }`,
  // schemastery 走桩：真实那份带传递依赖，桩足够让模块顶层的 Config 跑起来即可。
  '@deepseek-ai/schemastery': `const leaf = { default(){ return leaf; }, description(){ return leaf; }, volatile(){ return leaf; }, array(){ return leaf; }, object(){ return leaf; }, enum(){ return leaf; } };
const z = new Proxy({}, { get: () => () => leaf });
export default z;`,
};
const subpaths = {
  '@earendil-works/pi-ai': { './api/openai-completions.lazy': { file: './lazy.js', body: 'export function openAICompletionsApi(){return {id:"stub"};}' } },
};
for (const [pkg, body] of Object.entries(stubs)) {
  const dir = path.join(SANDBOX, 'node_modules', ...pkg.split('/'));
  fs.mkdirSync(dir, { recursive: true });
  const exports = { '.': './index.js' };
  for (const [sub, { file, body: subBody }] of Object.entries(subpaths[pkg] ?? {})) {
    exports[sub] = file;
    fs.writeFileSync(path.join(dir, file.replace(/^\.\//, '')), `${subBody}\n`);
  }
  fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({ name: pkg, type: 'module', main: 'index.js', exports }, null, 1));
  fs.writeFileSync(path.join(dir, 'index.js'), `${body}\n`);
}

const mod = await import(pathToFileURL(path.join(SANDBOX, 'lib/providers/trae/index.js')).href);
const { resolveProduct, activeProduct, createCatalog, createTraeAccountClient, createTraeClient, createTraeRateClient, decodeModelId, TRAE_PRODUCTS } = mod;

// ── 断言工具 ────────────────────────────────────────────────────────────────
let pass = 0;
let fail = 0;
let skipped = 0;
const ok = (label, cond, extra = '') => {
  if (cond) { pass += 1; console.log(`  OK    ${label}${extra ? '   ' + extra : ''}`); }
  else { fail += 1; console.log(`  FAIL  ${label}${extra ? '   ' + extra : ''}`); }
};
/** 依赖宿主导出快照的断言：文件不在就跳过，不算失败。 */
const okIf = (label, cond, ready, extra = '') => {
  if (!ready) { skipped += 1; console.log(`  SKIP  ${label}   （缺快照：${ready === false ? '本机未装/未导出' : ''}）`); return; }
  ok(label, cond, extra);
};
const CN_CRED = path.join(HOME, 'connect-auth', 'trae.json');
const CN_CATALOG = path.join(HOME, 'trae-cn', 'models.json');
/** 并入前那份 SOLO 快照留在本机的备份 —— 只用来复算「老快照认得出吗」这一条。 */
const SOLO_STASH = path.join(HOME, 'connect-auth', 'trae.json.solo-stash');
const readJson = (p) => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return undefined; } };
const cnCred = readJson(CN_CRED);
const cnCatalog = readJson(CN_CATALOG);
const soloStash = readJson(SOLO_STASH);

console.log(`验证目标：${USE_INSTALLED ? '已安装副本' : '仓库源码'}  (${SRC})\n`);

console.log('[1] resolveProduct：判定优先级 = 配置 > 快照声明 > 双向嗅探 > 现役产品兜底');
const SYN_CN = { token: 't', product: 'cn', packageType: 'TRAE_CN', appVersionCode: TRAE_PRODUCTS.cn.appVersionCode };
const SYN_SOLO = { token: 't', product: 'solo', packageType: 'SOLO_CN', appVersionCode: TRAE_PRODUCTS.solo.appVersionCode };
/** 并入前导出的 v1 快照：没有 product / packageType，只有一个 SOLO 的 buildId。 */
const SYN_OLD = { token: 't', appVersionCode: TRAE_PRODUCTS.solo.appVersionCode };
ok('显式声明 cn → cn', resolveProduct({}, SYN_CN).id === 'cn');
ok('显式声明 solo → solo', resolveProduct({}, SYN_SOLO).id === 'solo');
/**
 * 这条是 2026-10-11 翻转 `TRAE_DEFAULT_PRODUCT`（solo → cn）之后**最要紧**的一条：
 * 老快照不再靠兜底命中，只能靠 buildId 嗅探。嗅探一旦写坏，存量 SOLO 用户就会
 * 被当成 CN —— 表现是掉模型、掉倍率、思考档位静默失效，而不是任何一条错误。
 */
ok('老快照（无 product/packageType，只有 SOLO buildId）→ solo', resolveProduct({}, SYN_OLD).id === 'solo');
okIf('本机那份真·老快照也认成 solo', resolveProduct({}, soloStash).id === 'solo', soloStash !== undefined,
  soloStash === undefined ? '' : `buildId=${soloStash.appVersionCode}，无 product 字段`);
ok('只有 packageType=SOLO_CN 也认 solo', resolveProduct({}, { packageType: 'SOLO_CN' }).id === 'solo');
ok('只有 packageType=TRAE_CN 也能判 cn', resolveProduct({}, { packageType: 'TRAE_CN' }).id === 'cn');
ok('只有 buildId 也能判 cn（嗅探）', resolveProduct({}, { appVersionCode: TRAE_PRODUCTS.cn.appVersionCode }).id === 'cn');
ok('配置可强制覆盖快照', resolveProduct({ product: 'solo' }, SYN_CN).id === 'solo');
ok('配置乱填 → 忽略、按快照判', resolveProduct({ product: 'nope' }, SYN_CN).id === 'cn');
ok('空文档 → cn（兜底 = 现役产品；SOLO 独立客户端已被并入 IDE）', resolveProduct({}, undefined).id === 'cn');
ok('什么都认不出（buildId 谁都不像）→ cn 且不抛', resolveProduct({}, { appVersionCode: 1 }).id === 'cn');

console.log('\n[2] activeProduct：只读文件，不判 token 过期（未登录也要有答案）');
ok('从凭据文件判定', activeProduct(() => ({ credentialFile: CN_CRED })) !== undefined);
ok('配置强制生效', activeProduct({ product: 'solo' }).id === 'solo');
ok('文件不存在 → cn 且不抛', activeProduct({ credentialFile: path.join(HOME, 'definitely-missing.json') }).id === 'cn');

console.log('\n[3] TRAE_PRODUCTS 变体表完整性（缺一个字段就是半套配置）');
for (const p of Object.values(TRAE_PRODUCTS)) {
  const need = ['id', 'label', 'appDir', 'packageType', 'reqSource', 'appVersionCode', 'appVersion', 'defaultFunction', 'functions', 'rateFunctions', 'catalogGroups', 'fallbackModels', 'catalogSubdir'];
  const missing = need.filter((k) => p[k] === undefined || (Array.isArray(p[k]) && p[k].length === 0));
  ok(`${p.id}：字段齐全`, missing.length === 0, missing.join(','));
  ok(`${p.id}：defaultFunction 在自己的白名单里`, p.functions.includes(p.defaultFunction), p.defaultFunction);
  ok(`${p.id}：catalogGroups ⊆ functions（档位键名取得到）`, p.catalogGroups.every((g) => p.functions.includes(g)), p.catalogGroups.filter((g) => !p.functions.includes(g)).join(','));
}
ok('两条产品线的 buildId 不同（倍率接口按它筛选，相同就静默降级）', TRAE_PRODUCTS.cn.appVersionCode !== TRAE_PRODUCTS.solo.appVersionCode, `${TRAE_PRODUCTS.cn.appVersionCode} / ${TRAE_PRODUCTS.solo.appVersionCode}`);
ok('两条产品线的 reqSource 不同（SOLO=2 / CN=1）', TRAE_PRODUCTS.cn.reqSource === 1 && TRAE_PRODUCTS.solo.reqSource === 2);
ok('SOLO 的兜底名单保持历史 7 条（逐字不变）', TRAE_PRODUCTS.solo.fallbackModels.length === 7, `n=${TRAE_PRODUCTS.solo.fallbackModels.length}`);
ok('SOLO 的目录子目录仍是 trae/（旧快照不用重导）', TRAE_PRODUCTS.solo.catalogSubdir === 'trae');
ok('CN 用独立的 trae-cn/（不与 SOLO 目录混）', TRAE_PRODUCTS.cn.catalogSubdir === 'trae-cn');
/**
 * SOLO 已被厂商并进 IDE —— 名字上必须说清楚，否则面板里那条 chip 还在宣传一个
 * 装不回来的产品。这是 2026-10-11「描述与代码一起改」的那一半。
 */
ok('SOLO 的 label 写明已并入 IDE', TRAE_PRODUCTS.solo.label.includes('已并入'), TRAE_PRODUCTS.solo.label);
/**
 * CN 侧三个身份（可推理白名单 / 倍率查询键 / 目录分组）在代码里是**同一份常量**。
 *
 * 钉死成 IDE 的三个分组，就是钉死这次清理：把 SOLO 那 4 个槽位名或 `multimodal` /
 * `refactor` 加回来，这里立刻红。依据是实测 —— 11 个名字与 3 个名字对目录的倍率
 * 覆盖都是 24/24（2026-10-11，同一份凭据，250 ms vs 962 ms），而档位与窗口数据
 * 只有这三个分组有，多出来的名字只会带来静默丢档位。
 */
ok('CN 白名单恰好是 IDE 的三个分组', TRAE_PRODUCTS.cn.functions.join() === 'solo_agent,chat_v3,builder_v3', TRAE_PRODUCTS.cn.functions.join(','));
ok('CN 的倍率查询集 / 目录分组与白名单同源', ['rateFunctions', 'catalogGroups']
  .every((k) => TRAE_PRODUCTS.cn[k].join() === TRAE_PRODUCTS.cn.functions.join()));
ok('SOLO 整条冻结：白名单 9 个、倍率查询集 11 个（历史逐字）',
  TRAE_PRODUCTS.solo.functions.length === 9 && TRAE_PRODUCTS.solo.rateFunctions.length === 11,
  `functions=${TRAE_PRODUCTS.solo.functions.length} rateFunctions=${TRAE_PRODUCTS.solo.rateFunctions.length}`);

console.log('\n[4] decodeModelId：function 白名单按产品');
ok('CN 放行 solo_agent', decodeModelId('glm-5.3@solo_agent', 'chat_v3', TRAE_PRODUCTS.cn.functions).functionName === 'solo_agent');
ok('CN 拒绝 solo 专有 solo_coder → 退回默认', decodeModelId('glm-5.3@solo_coder', 'solo_agent', TRAE_PRODUCTS.cn.functions).functionName === 'solo_agent');
ok('CN 也拒绝 solo_work_lite（快照里没有它的档位/窗口数据，放行=静默丢档位）',
  decodeModelId('glm-5.3@solo_work_lite', 'solo_agent', TRAE_PRODUCTS.cn.functions).functionName === 'solo_agent');
ok('SOLO 放行 solo_coder', decodeModelId('glm-5.3@solo_coder', 'solo_work_lite', TRAE_PRODUCTS.solo.functions).functionName === 'solo_coder');
ok('无 @ 后缀 → 用默认 function', decodeModelId('glm-5.3', 'solo_agent', TRAE_PRODUCTS.cn.functions).functionName === 'solo_agent');
ok('未知后缀 → 退回默认 function，且模型名保持原样（不静默剥后缀，让上游报 model is unknown）', (() => {
  const d = decodeModelId('glm-5.3@bogus', 'solo_agent', TRAE_PRODUCTS.cn.functions);
  return d.functionName === 'solo_agent' && d.model === 'glm-5.3@bogus';
})());

console.log('\n[5] 账号写接口的 req_source 由产品决定（桩 fetch，不打上游）');
const seen = [];
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, init) => {
  seen.push({ url: String(url), body: JSON.parse(init.body) });
  return new Response(JSON.stringify({ code: 0, message: 'ok', enable: true, checked_in: true, credits: 100, usage_summary: { total_amount: 100, consumed_amount: 1 } }), { status: 200, headers: { 'Content-Type': 'application/json' } });
};
const account = createTraeAccountClient({});
const credFor = (p) => ({ token: 't', userId: 'u', account: '', gateway: 'https://x', accountBase: 'https://api.trae.cn', appId: 'a', appVersionCode: 1, deviceId: 'd', product: p });
await account.fetchCheckinStatus(credFor(TRAE_PRODUCTS.cn));
await account.fetchCheckinStatus(credFor(TRAE_PRODUCTS.solo));
ok('CN → req_source=1', seen[0]?.body?.req_source === 1, JSON.stringify(seen[0]?.body));
ok('SOLO → req_source=2（历史行为不变）', seen[1]?.body?.req_source === 2, JSON.stringify(seen[1]?.body));

console.log('\n[6] 推理请求走 llm_utils_chat 并透传 function（桩 fetch）');
const sent = [];
globalThis.fetch = async (url, init) => {
  sent.push({ url: String(url), body: JSON.parse(init.body) });
  return new Response('event:output\ndata:{"response":"hi"}\n\nevent:done\ndata:{"finish_reason":"stop"}\n\n', { status: 200, headers: { 'Content-Type': 'text/event-stream' } });
};
await createTraeClient({}).chatStream(credFor(TRAE_PRODUCTS.cn), { model: 'glm-5.3', function: 'solo_agent', messages: [{ role: 'user', content: [{ type: 'text', text: 'x' }] }] }, undefined);
ok('端点 = /api/agent/v3/llm_utils_chat', /\/api\/agent\/v3\/llm_utils_chat$/.test(sent[0]?.url ?? ''), sent[0]?.url);
ok('function 原样透传', sent[0]?.body?.function === 'solo_agent');

/**
 * 倍率查询集**不传参数**时取自哪里 —— 这一组是这次清理的核心。
 *
 * 上游对 `functions` 长度的延迟是**非线性**的（实测 9 个名字一批能回、12 个整条被掐住），
 * 而目录里每个模型的倍率只要被查过一次就够了，所以名单必须**不多不少**：
 * 少了漏价，多的那些名字只会带回不在目录里的内部模型（refactor_scoper 等）。
 * 这里用桩 fetch 抓**实际发出去的 body**，比读源码文本强：改错顺序、多塞名字、
 * 把 CN 的名单发给 SOLO，都会立刻红。
 */
console.log('\n[7] 倍率查询集 = 该产品的目录分组（桩 fetch）');
const RATE_DOC = JSON.stringify({
  function_configs: [{
    function: 'solo_agent',
    config_info_list: [{
      config_name: 'glm-5.3',
      display_contact_config: JSON.stringify({ consumption_rate: JSON.stringify({ data: { rate: 3 } }) }),
    }],
  }],
});
const batches = [];
globalThis.fetch = async (_url, init) => {
  batches.push(JSON.parse(init.body).functions);
  return new Response(RATE_DOC, { status: 200, headers: { 'Content-Type': 'application/json' } });
};
const rateClient = createTraeRateClient({});
await rateClient.fetchRates({ token: 't', appVersionCode: 1, product: TRAE_PRODUCTS.cn });
ok('CN：一次请求，名单恰好等于 catalogGroups', batches.length === 1 && batches[0].join() === TRAE_PRODUCTS.cn.catalogGroups.join(), JSON.stringify(batches));
await rateClient.fetchRates({ token: 't', appVersionCode: 1, product: TRAE_PRODUCTS.solo });
const soloBatches = batches.slice(1);
ok('SOLO：历史 11 个名字逐字保留', soloBatches.flat().join() === TRAE_PRODUCTS.solo.rateFunctions.join(), JSON.stringify(soloBatches.flat()));
ok('SOLO：11 个名字被 RATE_QUERY_CHUNK=9 切成两批（分批这条路径还活着）', soloBatches.length === 2, `批次数=${soloBatches.length}`);
/**
 * 不传 functions 时的兜底要认得**快照那种字符串形态**的 product。
 * 探针和排查脚本手上只有 `product: "cn"`，写坏就是 TypeError，而且报不出根因。
 */
let strOk = true;
try {
  await rateClient.fetchRates({ token: 't', appVersionCode: 1, product: 'solo' });
} catch {
  strOk = false;
}
ok('字符串形态的 product 也能取到默认名单（不抛）', strOk);
globalThis.fetch = realFetch;

console.log('\n[8] 真实快照（宿主导出后才有；没装 Trae 的机器自动跳过）');
okIf('CN 快照判成 cn', cnCred?.product === 'cn', cnCred !== undefined, cnCred ? `label=${resolveProduct({}, cnCred).label}` : '');
okIf('CN 快照的 reqSource=1', cnCred?.reqSource === 1, cnCred !== undefined);
/**
 * buildId **不钉成"必须等于变体表"**（2026-10-10 修正）。
 *
 * 它和模型总数是同一类东西：厂商随时会变。本机 Trae 一升级，快照里的
 * `appVersionCode` 就是新值，而运行时的取值优先级是
 * `config() ?? doc.appVersionCode ?? product.appVersionCode` —— **快照的值本来就赢**，
 * 表里那个只是"快照没带时"的兜底。钉相等等于把一次正常的厂商升级判成故障。
 *
 * 实测两个 buildId（旧 1232067209986 / 新 1238290756610）打倍率接口，
 * 返回**逐字节相同**（815552 B、194 处 consumption_rate），所以新值不会降级成空壳。
 *
 * 真正该钉的是两件事：快照带了可用的 buildId，以及**优先级不能被写反**
 * （反了就会拿旧值去查新值，静默回空壳 —— 表现是"倍率列全空"）。
 */
okIf('CN 快照带了可用 buildId', Number.isFinite(cnCred?.appVersionCode) && cnCred.appVersionCode > 0, cnCred !== undefined, `buildId=${cnCred?.appVersionCode}`);
okIf('运行时优先取快照的 buildId（表值只作兜底）', /appVersionCode:\s*config\(\)\.appVersionCode \?\? doc\.appVersionCode \?\? product\.appVersionCode/.test(traeSrc), true);
// 不写死模型总数：上游随时加模型（22 → 24 就是这么来的），写死只会在每次
// 厂商更新后误红。这里钉的是"CN 快照确实加载出了非空、形状正确的目录"；
// CN/SOLO 分文件由上一条 product === 'cn' 保证。
okIf('CN 目录加载出非空模型列表', Array.isArray(cnCatalog?.models) && cnCatalog.models.length > 0 && cnCatalog.models.every((m) => typeof m.id === 'string' && m.id.length > 0), cnCatalog !== undefined, `n=${cnCatalog?.models?.length}`);
okIf('目录里的中文 display_name 没乱码', (cnCatalog?.models ?? []).every((m) => !m.name.includes('\uFFFD')), cnCatalog !== undefined);
okIf('maxTokens 不越过任一分组 dev 窗口（越界=静默开 Max、5× 计费）', (cnCatalog?.models ?? []).every((m) => {
  const devs = Object.values(m.contextWindowByGroup ?? {}).map((t) => t?.dev).filter((n) => Number.isFinite(n) && n > 0);
  return devs.length === 0 || m.maxTokens <= Math.min(...devs);
}), cnCatalog !== undefined);
/**
 * 目录里的分组键必须全落在 CN 的白名单内 —— 这是 [3]/[4] 那两条收口的**反向验证**：
 * 如果哪天上游在 `model_list_map` 里新增一个分组、导出脚本把它收了进来，而白名单
 * 没跟着加，这些模型的档位与窗口就会静默失效。真出现时这条会先红，而不是等到
 * 用户报告"档位没用"。
 */
okIf('目录里出现的分组全在白名单内', (cnCatalog?.models ?? []).every((m) => [...new Set([
  ...Object.keys(m.contextWindowByGroup ?? {}),
  ...Object.keys(m.reasoningByGroup ?? {}),
])].every((g) => TRAE_PRODUCTS.cn.functions.includes(g))), cnCatalog !== undefined,
(() => {
  const groups = new Set((cnCatalog?.models ?? []).flatMap((m) => [...Object.keys(m.contextWindowByGroup ?? {}), ...Object.keys(m.reasoningByGroup ?? {})]));
  return [...groups].join(',');
})());
const g53 = (cnCatalog?.models ?? []).find((m) => m.id === 'glm-5.3');
okIf('glm-5.3 带 per-function 档位与窗口', !!g53?.reasoningByGroup?.solo_agent && !!g53?.contextWindowByGroup?.solo_agent, cnCatalog !== undefined);
okIf('CN 独占模型 4 个全在', ['glm-5.3-flash', 'glm-5.3-flashx', 'kimi-k2.8-preview', 'qwen3.8-flash'].every((id) => (cnCatalog?.models ?? []).some((m) => m.id === id)), cnCatalog !== undefined);
okIf('快照的 defaultFunction 与变体表一致', cnCatalog?.defaultFunction === TRAE_PRODUCTS.cn.defaultFunction, cnCatalog !== undefined, cnCatalog?.defaultFunction);
/**
 * 目录按产品分文件 —— 两条一起判，比只判「加载成功」强得多。
 *
 * 只判 `source() !== 'fallback'` 是个**假绿**：本机上两份目录都在，嗅探一旦写坏，
 * SOLO 快照会去读 `trae-cn/models.json`，照样非空、照样不抛，探针还是绿的。
 * 所以这里比的是**读出来的模型 id 列表等于哪一份文件**。
 */
const SOLO_CATALOG = path.join(HOME, 'trae', 'models.json');
const soloCatalog = readJson(SOLO_CATALOG);
const idsOf = (cat) => (cat?.models ?? []).map((m) => m.id).join();
const readySolo = soloStash !== undefined && soloCatalog !== undefined;
okIf('SOLO 快照读 trae/models.json（不是 trae-cn/）',
  createCatalog({ config: () => ({ credentialFile: SOLO_STASH }) }).current().map((m) => m.id).join() === idsOf(soloCatalog),
  readySolo, `n=${soloCatalog?.models?.length}`);
okIf('CN 快照读 trae-cn/models.json',
  createCatalog({ config: () => ({ credentialFile: CN_CRED }) }).current().map((m) => m.id).join() === idsOf(cnCatalog),
  cnCred !== undefined && cnCatalog !== undefined, `n=${cnCatalog?.models?.length}`);

console.log(`\n结果：${pass} 通过 / ${fail} 失败${skipped > 0 ? ` / ${skipped} 跳过（无本机快照）` : ''}`);
process.exit(fail === 0 ? 0 : 1);
