/**
 * The `dsh-omp-advisor` settings namespace: master switch, review trigger,
 * interrupt policy, and the advisor roster. Models are picked from the DSH
 * model list (provider route + model id), stored here, and used verbatim for
 * `ctx.llm.stream` calls.
 */
import z from '@deepseek-ai/schemastery'
import { normalizeMemorySettings } from './memory/engines'
import type { AdvisorEntry, AdvisorSettings, AdvisorSeverity, ToolGateSettings } from './types'

export const SETTINGS_NAMESPACE = 'dsh-omp-advisor'

const advisorEntrySchema = z.object({
  name: z.string().required().description('Advisor display name (unique within the roster).'),
  provider: z.string().required().description('DSH provider route id, from the model list.'),
  model: z.string().required().description('Model id served by that provider route.'),
  reasoningEffort: z.string().description('Optional adapter-owned reasoning effort for this model.'),
  maxTurns: z
    .number()
    .min(1)
    .max(10)
    .default(4)
    .description('Max advisor tool-loop turns per review (investigation budget).'),
  instructions: z.string().description('Optional specialization appended to the shared advisor baseline.'),
  skills: z
    .array(z.string())
    .default([])
    .description('Packaged skill ids injected into this advisor\'s context (see skills/ in the plugin).'),
  skillMode: z
    .union(['inject', 'lazy'])
    .default('inject')
    .description(
      'inject = embed full skill bodies in the advisor system prompt; lazy = embed id+description only and grant a load_skill tool (saves tokens, costs one extra call per loaded skill).'
    ),
  preset: z.string().description('Id of the built-in preset this advisor was created from (for skill resets).'),
  workspaces: z
    .array(z.string())
    .default([])
    .description(
      'Workspace scoping: substring patterns matched against the session cwd (e.g. "Qwest Chain"). Empty = advisor runs in every session.'
    ),
  disabledWorkspaces: z
    .array(z.string())
    .default([])
    .description(
      'Workspace exclusions: if the session cwd matches any pattern here the advisor does not run there, overriding `workspaces`. Written by the sidebar\'s workspace-scoped "Disable here".'
    ),
  enabled: z.boolean().default(true).description('Per-advisor on/off toggle.'),
  memoryEngines: z
    .array(z.string())
    .default([])
    .description(
      'Memory engine ids this advisor may use (see the Memory tab). Empty = the built-in plaintext store only.'
    )
})

export const advisorSettingsSchema = z.object({
  enabled: z.boolean().default(false).description('Master switch: attach advisors to sessions.'),
  reviewTrigger: z
    .union(['step', 'turn'])
    .default('turn')
    .description('Feed transcript deltas to advisors at step boundaries or turn boundaries.'),
  interruptSeverities: z
    .array(z.union(['nit', 'concern', 'blocker']))
    .default(['concern', 'blocker'])
    .description('Severities delivered as steering (nearest step boundary); others ride non-interrupting context.'),
  adviceCoalesceMs: z
    .number()
    .min(0)
    .max(10000)
    .default(0)
    .description(
      '0 = deliver each advice note individually. >0 = collect notes from all advisors for this many ms and deliver them as one batched advisory message (interrupting severities still flush immediately).'
    ),
  autoRetry: z
    .boolean()
    .default(true)
    .description(
      'Automatically retry failed work: failed advisor reviews re-run after the retry delay, and a failed primary-model turn receives an automatic "continue" followup message. Aborts and permanent errors (unknown model/provider) never retry.'
    ),
  autoRetryDelayMs: z
    .number()
    .min(1000)
    .max(300000)
    .default(5000)
    .description('Delay in ms before an auto-retry fires (advisor review retry or primary "continue" message).'),
  autoRetryMax: z
    .number()
    .min(0)
    .max(999)
    .default(3)
    .description(
      'Max auto-retry attempts per failed advisor review, and per primary-model failure episode. 0 = unlimited (permanent errors still never retry).'
    ),
  interveneOnBlocker: z
    .boolean()
    .default(false)
    .description(
      'Escalation: when an advisor raises a blocker while the primary agent is running, cancel the running step (undispatched tool calls are aborted) and wake the agent with the advisory. Off by default — advice stays advice.'
    ),
  toolGate: z
    .object({
      enabled: z
        .boolean()
        .default(false)
        .description(
          'Hard gate: stop a tool call BEFORE its body runs while an advisor has an unresolved finding for the session. Unlike interveneOnBlocker — which cancels the running step after advice was already raised — this refuses the call itself and hands the reason back to the model.'
        ),
      mode: z
        .union(['deny', 'ask'])
        .default('deny')
        .description(
          "deny = the call is refused and the reason goes to the model. ask = the call is held for your decision (localized prompt in the UI)."
        ),
      tools: z
        .array(z.string())
        .default([])
        .description(
          'Tool names the gate may stop. Empty = the mutating set (bash, write, edit). Add others explicitly to gate a custom or transport tool.'
        ),
      severities: z
        .array(z.union(['nit', 'concern', 'blocker']))
        .default(['blocker'])
        .description('Advisor severities that arm the gate. Defaults to blockers only.'),
      maxDenials: z
        .number()
        .min(0)
        .max(20)
        .default(2)
        .description(
          'How many times ONE unresolved finding may stop a call before the gate stands down for it, so a disagreeing advisor can never deadlock the agent. A new finding re-arms it. 0 = no bound (stopped until the finding is cleared).'
        ),
      note: z
        .string()
        .default('')
        .description('Extra guidance appended to the refusal reason the model sees.')
    })
    .default({})
    .description(
      'Tool-call interception (v0.9.0): convert advisor verdicts into real PreToolDecision gates — deny or ask — evaluated by the host before the tool body executes.'
    ),
  restorePoints: z
    .boolean()
    .default(false)
    .description(
      'Snapshot the workspace into side-effect-free git restore points (hidden refs under refs/dsh-omp-advisor/**) at turn boundaries, so advisors can recommend rewinds after destructive steps and verify completion against the session baseline. Your index/HEAD/branch are never touched; the primary model performs any restore.'
    ),
  restorePointKeep: z
    .number()
    .min(1)
    .max(100)
    .default(20)
    .description('How many restore points to keep per session; oldest are pruned first.'),
  restorePointOnMutation: z
    .boolean()
    .default(true)
    .description(
      'Also snapshot before mutating tools (fs write/edit intents and bash/write/edit executions). Best-effort: a bounded wait, never blocks your tools.'
    ),
  completionGate: z
    .boolean()
    .default(true)
    .description(
      'Completion gate: before the agent claims completion, the advisor verifies the ask is actually implemented, demands an honest done/not-done report otherwise, and reminds the agent to commit the accepted state to its working branch.'
    ),
  minDeltaChars: z
    .number()
    .min(0)
    .max(100000)
    .default(0)
    .description(
      'Skip advisor reviews whose rendered transcript delta is smaller than this many characters (0 = review everything). Skipped deltas are not replayed later.'
    ),
  advisors: z.array(advisorEntrySchema).default([]).description('Advisor roster.'),
  memory: z
    .any()
    .default({})
    .description(
      'Advisor memory (v0.7.0): engine roster, write gate (approval/auto/readonly), and recall budgets. Normalized by the plugin; see the Memory tab.'
    )
})

/** Clamp the advice coalesce window to the schema bounds (ms; 0 = off). */
function coerceCoalesceMs(raw: unknown): number {
  const value = typeof raw === 'number' && Number.isFinite(raw) ? raw : 0
  return Math.min(10000, Math.max(0, Math.round(value)))
}

/** Clamp the auto-retry delay to the schema bounds (ms). */
function coerceAutoRetryDelayMs(raw: unknown): number {
  const value = typeof raw === 'number' && Number.isFinite(raw) ? raw : 5000
  return Math.min(300000, Math.max(1000, Math.round(value)))
}

/** Clamp the auto-retry attempt cap to the schema bounds (0 = unlimited). */
function coerceAutoRetryMax(raw: unknown): number {
  const value = typeof raw === 'number' && Number.isFinite(raw) ? raw : 3
  return Math.min(999, Math.max(0, Math.round(value)))
}

/** Clamp the restore-point retention to the schema bounds. */
function coerceRestorePointKeep(raw: unknown): number {
  const value = typeof raw === 'number' && Number.isFinite(raw) ? raw : 20
  return Math.min(100, Math.max(1, Math.round(value)))
}

/** Clamp the minimum review delta size to the schema bounds (chars; 0 = off). */
function coerceMinDeltaChars(raw: unknown): number {
  const value = typeof raw === 'number' && Number.isFinite(raw) ? raw : 0
  return Math.min(100000, Math.max(0, Math.round(value)))
}

/**
 * Workspace scoping match: an advisor with no usable patterns runs everywhere;
 * otherwise one of its patterns must match the session cwd. A plain pattern is
 * a SUBSTRING match (so 'Qwest Chain' matches any path containing it); a
 * pattern prefixed with '=' matches the cwd EXACTLY — use it for broad paths
 * like '/home/sama' that would otherwise swallow every subdirectory.
 */
export function advisorMatchesWorkspace(
  entry: Pick<AdvisorEntry, 'workspaces' | 'disabledWorkspaces'>,
  cwd: string
): boolean {
  // Exclusions win: if the cwd matches any disabledWorkspaces pattern the
  // advisor does not run here, regardless of its inclusion patterns.
  const disabled = (entry.disabledWorkspaces ?? [])
    .map(pattern => pattern.trim())
    .filter(pattern => pattern !== '')
  if (
    disabled.some(pattern => {
      if (pattern.startsWith('=')) return cwd === pattern.slice(1).trim()
      return cwd.includes(pattern)
    })
  ) {
    return false
  }
  const patterns = (entry.workspaces ?? [])
    .map(pattern => pattern.trim())
    .filter(pattern => pattern !== '')
  if (patterns.length === 0) return true
  return patterns.some(pattern => {
    if (pattern.startsWith('=')) return cwd === pattern.slice(1).trim()
    return cwd.includes(pattern)
  })
}

/** Normalize a resolved settings value (defensive; the schema already validates). */
function coerceToolGateMaxDenials(raw: unknown): number {
  const value = typeof raw === 'number' && Number.isFinite(raw) ? Math.round(raw) : 2
  return Math.min(20, Math.max(0, value))
}

/**
 * Normalize the tool-gate policy (v0.9.0). Unknown keys are dropped; an empty
 * severity list falls back to blockers so enabling the gate can never arm it for
 * nothing.
 */
export function normalizeToolGate(raw: unknown): ToolGateSettings {
  const value = (raw ?? {}) as Partial<ToolGateSettings>
  const severities = Array.isArray(value.severities)
    ? value.severities.filter((s): s is AdvisorSeverity => s === 'nit' || s === 'concern' || s === 'blocker')
    : []
  return {
    enabled: value.enabled === true,
    mode: value.mode === 'ask' ? 'ask' : 'deny',
    tools: Array.isArray(value.tools)
      ? value.tools
          .filter((t): t is string => typeof t === 'string' && t.trim() !== '')
          .map(t => t.trim())
      : [],
    severities: severities.length > 0 ? severities : (['blocker'] as AdvisorSeverity[]),
    maxDenials: coerceToolGateMaxDenials(value.maxDenials),
    note: typeof value.note === 'string' ? value.note.trim() : ''
  }
}

export function normalizeSettings(raw: unknown): AdvisorSettings {
  const value = (raw ?? {}) as Partial<AdvisorSettings>
  const advisors = Array.isArray(value.advisors) ? value.advisors : []
  const seen = new Set<string>()
  const deduped = []
  for (const entry of advisors) {
    if (!entry || typeof entry.name !== 'string' || !entry.name.trim()) continue
    if (typeof entry.provider !== 'string' || !entry.provider.trim()) continue
    if (typeof entry.model !== 'string' || !entry.model.trim()) continue
    const name = entry.name.trim()
    if (seen.has(name)) continue
    seen.add(name)
    deduped.push({
      name,
      provider: entry.provider,
      model: entry.model,
      ...(typeof entry.reasoningEffort === 'string' && entry.reasoningEffort
        ? { reasoningEffort: entry.reasoningEffort }
        : {}),
      maxTurns: Math.min(10, Math.max(1, Math.round(entry.maxTurns || 4))),
      ...(typeof entry.instructions === 'string' && entry.instructions.trim()
        ? { instructions: entry.instructions.trim() }
        : {}),
      ...(Array.isArray(entry.skills)
        ? {
            skills: entry.skills.filter(
              (s): s is string => typeof s === 'string' && s.trim() !== ''
            )
          }
        : {}),
      ...(entry.skillMode === 'lazy' ? { skillMode: 'lazy' as const } : {}),
      ...(typeof entry.preset === 'string' && entry.preset ? { preset: entry.preset } : {}),
      ...(Array.isArray(entry.workspaces)
        ? {
            workspaces: entry.workspaces
              .filter((w): w is string => typeof w === 'string' && w.trim() !== '')
              .map(w => w.trim())
          }
        : {}),
      ...(Array.isArray(entry.disabledWorkspaces)
        ? {
            disabledWorkspaces: entry.disabledWorkspaces
              .filter((w): w is string => typeof w === 'string' && w.trim() !== '')
              .map(w => w.trim())
          }
        : {}),
      ...(Array.isArray(entry.memoryEngines)
        ? {
            memoryEngines: entry.memoryEngines
              .filter((e): e is string => typeof e === 'string' && e.trim() !== '')
              .map(e => e.trim())
          }
        : {}),
      enabled: entry.enabled !== false
    })
  }
  const severities = Array.isArray(value.interruptSeverities)
    ? value.interruptSeverities.filter((s): s is 'nit' | 'concern' | 'blocker' =>
        s === 'nit' || s === 'concern' || s === 'blocker'
      )
    : (['concern', 'blocker'] as AdvisorSettings['interruptSeverities'])
  return {
    enabled: value.enabled === true,
    reviewTrigger: value.reviewTrigger === 'step' ? 'step' : 'turn',
    interruptSeverities: severities,
    adviceCoalesceMs: coerceCoalesceMs((value as { adviceCoalesceMs?: unknown }).adviceCoalesceMs),
    autoRetry: (value as { autoRetry?: unknown }).autoRetry !== false,
    autoRetryDelayMs: coerceAutoRetryDelayMs((value as { autoRetryDelayMs?: unknown }).autoRetryDelayMs),
    autoRetryMax: coerceAutoRetryMax((value as { autoRetryMax?: unknown }).autoRetryMax),
    interveneOnBlocker: (value as { interveneOnBlocker?: unknown }).interveneOnBlocker === true,
    toolGate: normalizeToolGate((value as { toolGate?: unknown }).toolGate),
    restorePoints: (value as { restorePoints?: unknown }).restorePoints === true,
    restorePointKeep: coerceRestorePointKeep((value as { restorePointKeep?: unknown }).restorePointKeep),
    restorePointOnMutation: (value as { restorePointOnMutation?: unknown }).restorePointOnMutation !== false,
    completionGate: (value as { completionGate?: unknown }).completionGate !== false,
    minDeltaChars: coerceMinDeltaChars((value as { minDeltaChars?: unknown }).minDeltaChars),
    advisors: deduped,
    memory: normalizeMemorySettings((value as { memory?: unknown }).memory)
  }
}

/**
 * Editor round-trip normalizer: type-coerces like `normalizeSettings` but is
 * NON-destructive — it keeps entries whose name/provider/model is empty (the
 * user may be mid-edit) and does not trim text. The settings section folds
 * the host's reply into the form, so a strict reply would delete the card
 * being edited and yank characters out of focused inputs. The runtime keeps
 * reading through the strict `normalizeSettings`, so an incomplete advisor
 * never actually runs.
 */
export function normalizeSettingsLenient(raw: unknown): AdvisorSettings {
  const value = (raw ?? {}) as Partial<AdvisorSettings>
  const advisors = Array.isArray(value.advisors) ? value.advisors : []
  const preserved: AdvisorEntry[] = []
  for (const entry of advisors) {
    if (!entry || typeof entry !== 'object') continue
    const e = entry as Partial<AdvisorEntry>
    preserved.push({
      name: typeof e.name === 'string' ? e.name : '',
      provider: typeof e.provider === 'string' ? e.provider : '',
      model: typeof e.model === 'string' ? e.model : '',
      ...(typeof e.reasoningEffort === 'string' && e.reasoningEffort
        ? { reasoningEffort: e.reasoningEffort }
        : {}),
      maxTurns: Math.min(10, Math.max(1, Math.round(e.maxTurns || 4))),
      ...(typeof e.instructions === 'string' ? { instructions: e.instructions } : {}),
      ...(Array.isArray(e.skills)
        ? { skills: e.skills.filter((s): s is string => typeof s === 'string') }
        : {}),
      ...(e.skillMode === 'lazy' ? { skillMode: 'lazy' as const } : {}),
      ...(typeof e.preset === 'string' ? { preset: e.preset } : {}),
      ...(Array.isArray(e.workspaces)
        ? { workspaces: e.workspaces.filter((w): w is string => typeof w === 'string') }
        : {}),
      ...(Array.isArray(e.disabledWorkspaces)
        ? { disabledWorkspaces: e.disabledWorkspaces.filter((w): w is string => typeof w === 'string') }
        : {}),
      ...(Array.isArray(e.memoryEngines)
        ? { memoryEngines: e.memoryEngines.filter((m): m is string => typeof m === 'string') }
        : {}),
      enabled: e.enabled !== false
    })
  }
  const severities = Array.isArray(value.interruptSeverities)
    ? value.interruptSeverities.filter((s): s is 'nit' | 'concern' | 'blocker' =>
        s === 'nit' || s === 'concern' || s === 'blocker'
      )
    : (['concern', 'blocker'] as AdvisorSettings['interruptSeverities'])
  return {
    enabled: value.enabled === true,
    reviewTrigger: value.reviewTrigger === 'step' ? 'step' : 'turn',
    interruptSeverities: severities,
    adviceCoalesceMs: coerceCoalesceMs((value as { adviceCoalesceMs?: unknown }).adviceCoalesceMs),
    autoRetry: (value as { autoRetry?: unknown }).autoRetry !== false,
    autoRetryDelayMs: coerceAutoRetryDelayMs((value as { autoRetryDelayMs?: unknown }).autoRetryDelayMs),
    autoRetryMax: coerceAutoRetryMax((value as { autoRetryMax?: unknown }).autoRetryMax),
    interveneOnBlocker: (value as { interveneOnBlocker?: unknown }).interveneOnBlocker === true,
    toolGate: normalizeToolGate((value as { toolGate?: unknown }).toolGate),
    restorePoints: (value as { restorePoints?: unknown }).restorePoints === true,
    restorePointKeep: coerceRestorePointKeep((value as { restorePointKeep?: unknown }).restorePointKeep),
    restorePointOnMutation: (value as { restorePointOnMutation?: unknown }).restorePointOnMutation !== false,
    completionGate: (value as { completionGate?: unknown }).completionGate !== false,
    minDeltaChars: coerceMinDeltaChars((value as { minDeltaChars?: unknown }).minDeltaChars),
    advisors: preserved,
    memory: normalizeMemorySettings((value as { memory?: unknown }).memory)
  }
}
