/**
 * rc.8 Host 契约测试（阶段 0，T-A3）。
 * 目的：把 rc.8 实测结论固化成"防错误假设回归"——rc 升级时，若本文档 §5 的关键结论漂移，这里第一时间红。
 * 边界（明确）：
 *  - 仅 import 插件**实际直接依赖**的包（storage-domain / llm / tools / zod 等）；
 *  - 依赖注入的 ctx 服务（agents / agentPresets / sessionPersistence / webServer / workflow / jobs / schedule）
 *    不是插件直接依赖，由宿主运行时注入——其契约应在 **Profile 集成验证**（真实 dsh 进程）中冒烟，
 *    不属于本单元测试；本测试只锁定"这些包不应被插件误引入"的事实。
 *  - 本轮不引入 Subagent 依赖（未使用）。
 * @module pipeline-kernel/test/contract-rc8-host
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { defineDomain, domainTable } from '@deepseek-ai/dsh-storage-domain'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { z } from 'zod'

test('rc.8：storageDomain defineDomain/open 契约（域打开形状）', async () => {
  const spec = defineDomain({
    name: 'contract_test',
    version: 1,
    tables: {
      kv: domainTable(z.object({ id: z.string(), n: z.number().default(0) })),
    },
  })
  assert.equal(spec.name, 'contract_test')
  assert.equal(spec.version, 1)
  assert.ok(spec.tables.kv, 'tables 应有 kv')
  assert.ok(spec.tables.kv.valueSchema, 'domainTable 暴露 valueSchema')
})

test('rc.8：dsh-llm createUserMessage 契约（唤醒消息构造）', () => {
  const msg = createUserMessage({
    content: [{ type: 'text', text: 'hello' }],
    source: { kind: 'plugin', plugin: 'pipeline-kernel' },
  })
  assert.ok(msg, 'createUserMessage 返回消息')
  assert.ok(Array.isArray(msg.content), 'content 是数组')
})

test('rc.8：dsh-tools defineTool 契约（工具注册形状）', () => {
  const tool = defineTool({
    name: 'pipeline_contract_probe',
    description: 'contract probe',
    parameters: { x: { type: 'string', description: 'x' } },
    output: { schema: { type: 'string' } },
    execute: async () => 'ok',
  })
  assert.equal(tool.name, 'pipeline_contract_probe')
  assert.equal(typeof tool.execute, 'function')
})

test('rc.8：宿主注入服务包不应出现在插件直接依赖（防误引入）', () => {
  // 这些服务由 ctx 注入，插件只消费、不直接 import——若被误加进依赖即 red。
  const NOT_DIRECT = [
    '@deepseek-ai/dsh-session-persistence',
    '@deepseek-ai/dsh-workflow',
    '@deepseek-ai/dsh-jobs',
    '@deepseek-ai/dsh-schedule',
    '@deepseek-ai/dsh-subagent',
    '@deepseek-ai/dsh-workspace',
    '@deepseek-ai/dsh-host-webserver',
  ]
  const pkgRaw = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))
  const all = { ...(pkgRaw.peerDependencies ?? {}), ...(pkgRaw.devDependencies ?? {}) }
  const offender = NOT_DIRECT.filter((p) => Object.prototype.hasOwnProperty.call(all, p))
  assert.deepEqual(offender, [], '这些宿主注入服务不应被插件直接依赖（本轮：不引入未使用能力）')
})
