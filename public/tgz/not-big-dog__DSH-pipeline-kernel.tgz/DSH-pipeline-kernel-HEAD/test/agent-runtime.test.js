/**
 * agent-runtime 窄适配层契约测试（验收 P2 补强）。
 * 用 stub ctx 模拟 DSH 各服务，验证 agent-runtime 的：
 *  - 透传（createAgent/mountPreset/resolvePreset）
 *  - 降级（deliverWake/inspectSessionCwd/resolveWorkspace/currentModel 在服务缺失时安全返回）
 *  - 不依赖真实宿主进程（纯单元测试）。
 * @module pipeline-kernel/test/agent-runtime
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createAgentRuntime } from '../lib/agent-runtime.js'

/** 构造带可选服务的 stub ctx（agents/agentPresets 为注入服务属性，其余走 get）。 */
function makeStubCtx(services = {}) {
  const provided = new Map(Object.entries(services))
  const ctx = {
    agents: services.agents,        // 注入属性（DSH 中为 ctx.agents 服务）
    agentPresets: services.agentPresets,
    get(name) { return provided.get(name) },
  }
  return ctx
}

test('deliverWake：agent 在线 → woken:true 且调用 followup', () => {
  const followed = []
  const agent = { followup: (m) => followed.push(m) }
  const rt = createAgentRuntime({ ctx: makeStubCtx({ agents: { get: () => agent } }) })
  const out = rt.deliverWake({ sessionId: 's1', text: 'hi' })
  assert.equal(out.woken, true)
  assert.equal(out.sessionId, 's1')
  assert.equal(followed.length, 1)
  assert.equal(followed[0].content[0].text, 'hi')
})

test('deliverWake：agent 不在线 → woken:false 降级', () => {
  const rt = createAgentRuntime({ ctx: makeStubCtx({ agents: { get: () => undefined } }) })
  const out = rt.deliverWake({ sessionId: 's1', text: 'hi' })
  assert.equal(out.woken, false)
  assert.match(out.reason, /不在线/)
})

test('inspectSessionCwd：live agent 读 session.header.cwd', async () => {
  const agent = { session: { header: { cwd: 'C:/proj' } } }
  const rt = createAgentRuntime({ ctx: makeStubCtx({ agents: { get: () => agent } }) })
  assert.equal(await rt.inspectSessionCwd('s1'), 'C:/proj')
})

test('inspectSessionCwd：非 live 走 sessionPersistence.inspect().meta.cwd', async () => {
  const persistence = { inspect: async () => ({ meta: { cwd: 'C:/proj2' } }) }
  const rt = createAgentRuntime({ ctx: makeStubCtx({ sessionPersistence: persistence }) })
  assert.equal(await rt.inspectSessionCwd('s1'), 'C:/proj2')
})

test('inspectSessionCwd：无 persistence / inspect 抛错 → undefined 降级', async () => {
  const noP = createAgentRuntime({ ctx: makeStubCtx() })
  assert.equal(await noP.inspectSessionCwd('s1'), undefined)
  const badP = createAgentRuntime({ ctx: makeStubCtx({ sessionPersistence: { inspect: async () => { throw new Error('not found') } } }) })
  assert.equal(await badP.inspectSessionCwd('s1'), undefined)
})

test('resolveWorkspace：无 workspaceRegistry → null 降级', async () => {
  const rt = createAgentRuntime({ ctx: makeStubCtx() })
  assert.equal(await rt.resolveWorkspace('C:/proj'), null)
})

test('resolveWorkspace：有 registry → resolveByPath 优先，回退 create', async () => {
  const ws = { path: 'C:/proj' }
  const wsCalls = []
  const registry = {
    resolveByPath: async () => { wsCalls.push('resolve'); return ws },
    create: async () => { wsCalls.push('create'); return ws },
  }
  const rt = createAgentRuntime({ ctx: makeStubCtx({ workspaceRegistry: registry }) })
  assert.equal(await rt.resolveWorkspace('C:/proj'), ws)
  assert.deepEqual(wsCalls, ['resolve'])
})

test('resolveWorkspace：resolveByPath 未命中 → 走 create fallback', async () => {
  const ws = { path: 'C:/new' }
  const wsCalls = []
  const registry = {
    resolveByPath: async () => { wsCalls.push('resolve'); return undefined },
    create: async () => { wsCalls.push('create'); return ws },
  }
  const rt = createAgentRuntime({ ctx: makeStubCtx({ workspaceRegistry: registry }) })
  assert.equal(await rt.resolveWorkspace('C:/new'), ws)
  assert.deepEqual(wsCalls, ['resolve', 'create'], 'resolve 未命中应回退 create')
})

test('currentModel：无 agentDefaultModel → undefined 降级', () => {
  const rt = createAgentRuntime({ ctx: makeStubCtx() })
  assert.equal(rt.currentModel(), undefined)
})

test('currentModel：有服务 → 返回选择', () => {
  const model = { model: 'm', provider: 'p' }
  const rt = createAgentRuntime({ ctx: makeStubCtx({ agentDefaultModel: { currentSelection: () => model } }) })
  assert.deepEqual(rt.currentModel(), model)
})

test('createAgent / mountPreset / resolvePreset：透传真实服务', async () => {
  const created = []
  const mounted = []
  const agents = { create: async (opts) => { created.push(opts); return { agent: { id: 'a1' } } } }
  const agentPresets = {
    mount: async (agentCtx) => { mounted.push(agentCtx); return { id: 'preset' } },
    resolve: async () => ({ id: 'preset' }),
  }
  const ctx = makeStubCtx({ agents, agentPresets })
  const rt = createAgentRuntime({ ctx })
  const handle = await rt.createAgent({ sessionId: 's1', meta: {}, setup: async () => {} })
  assert.equal(handle.agent.id, 'a1')
  assert.equal(created[0].sessionId, 's1')
  await rt.mountPreset({ scope: 'x' }, 'preset')
  assert.equal(mounted.length, 1)
  const resolved = await rt.resolvePreset('preset')
  assert.equal(resolved.id, 'preset')
})

test('attachSession：服务缺失/无方法 → 安全 no-op', () => {
  const rt = createAgentRuntime({ ctx: makeStubCtx() })
  assert.equal(rt.attachSession(null, 's1'), undefined)
})

test('attachSession：正常透传（调用 workspace.attachSession）', async () => {
  const attached = []
  const ws = { attachSession: async (id) => { attached.push(id) } }
  const rt = createAgentRuntime({ ctx: makeStubCtx() })
  await rt.attachSession(ws, 's1')
  assert.deepEqual(attached, ['s1'])
  assert.equal(rt.attachSession({}, 's1'), undefined, '无 attachSession 方法的 workspace → no-op')
})

test('sendMessage：对 live agent 发消息（followup 统一构造，不直接依赖 dsh-llm）', () => {
  const followed = []
  const agent = { followup: (m) => followed.push(m) }
  const rt = createAgentRuntime({ ctx: makeStubCtx() })
  const ok = rt.sendMessage(agent, 'hello supervisor')
  assert.equal(ok, true)
  assert.equal(followed.length, 1)
  assert.equal(followed[0].content[0].text, 'hello supervisor')
  assert.equal(followed[0].source.kind, 'plugin')
})

test('sendMessage：非 agent / 无 followup → false 降级', () => {
  const rt = createAgentRuntime({ ctx: makeStubCtx() })
  assert.equal(rt.sendMessage(null, 'x'), false)
  assert.equal(rt.sendMessage({}, 'x'), false)
})
