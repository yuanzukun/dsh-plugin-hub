/**
 * definePipeline 校验测试（审查 P1-3）：
 * partial schema 拒绝非法结构（roles:"abc" / chain:"designer" 不落库）；
 * 原子合并：更新只覆盖显式字段，漏传保留旧值；id 格式校验。
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createFakeDomain } from './helpers/fake-domain.js'
import { makeConfig } from './helpers/setup.js'
import { definePipeline } from '../lib/deploy.js'

function makeEnv() {
  const { config, cleanup } = makeConfig()
  return { domain: createFakeDomain(), config, cleanup }
}

const fullDef = {
  id: 'pic',
  title: '图片管线',
  roles: { supervisor: { preset: 'pipeline-supervisor' }, designer: {}, prompter: {}, reviewer: {} },
  chain: ['designer', 'prompter', 'reviewer'],
  gates: { g1: { after: 'reviewer', desc: '' } },
  artifactRoot: 'design/',
  inboxDir: 'exchange/收件箱',
  strikeOut: 3,
  entry: { default: 'designer' },
  modelDefaults: { reviewer: 'mimo-v2.5' },
}

test('合法定义可创建', async () => {
  const env = makeEnv()
  try {
    const def = await definePipeline({ ...env, input: fullDef })
    assert.equal(def.id, 'pic')
    assert.equal(Object.keys(def.roles).length, 4)
    assert.equal(def.strikeOut, 3)
  } finally {
    env.cleanup()
  }
})

test('非法结构拒绝：roles 非对象 / chain 非数组 / strikeOut 非数字 → BAD_INPUT 且不落库', async () => {
  const env = makeEnv()
  try {
    await assert.rejects(definePipeline({ ...env, input: { ...fullDef, roles: 'abc' } }), (err) => err.code === 'BAD_INPUT')
    await assert.rejects(definePipeline({ ...env, input: { ...fullDef, chain: 'designer' } }), (err) => err.code === 'BAD_INPUT')
    await assert.rejects(definePipeline({ ...env, input: { ...fullDef, strikeOut: 'three' } }), (err) => err.code === 'BAD_INPUT')
    assert.equal(env.domain.table('pipelines').get('pic'), undefined, '校验失败不得落库')
  } finally {
    env.cleanup()
  }
})

test('原子合并：更新只覆盖显式字段，漏传保留旧值（roles 不被清空）', async () => {
  const env = makeEnv()
  try {
    await definePipeline({ ...env, input: fullDef })
    // 只更新 title —— roles/chain/gates 必须保留
    const updated = await definePipeline({ ...env, input: { id: 'pic', title: '新标题' } })
    assert.equal(updated.title, '新标题')
    assert.equal(Object.keys(updated.roles).length, 4, '漏传 roles 必须保留旧值（P1-3 核心）')
    assert.deepEqual(updated.chain, fullDef.chain)
    assert.deepEqual(updated.gates, fullDef.gates)
    assert.equal(updated.modelDefaults.reviewer, 'mimo-v2.5')
    assert.equal(updated.artifactRoot, 'design/')
    // 显式传部分 roles → 只替换 roles
    const updated2 = await definePipeline({ ...env, input: { id: 'pic', roles: { supervisor: {} } } })
    assert.deepEqual(Object.keys(updated2.roles), ['supervisor'])
    assert.deepEqual(updated2.chain, fullDef.chain, 'chain 不受 roles 更新影响')
  } finally {
    env.cleanup()
  }
})

test('id 校验：非法 id 拒绝', async () => {
  const env = makeEnv()
  try {
    await assert.rejects(definePipeline({ ...env, input: { id: '../evil' } }), (err) => err.code === 'BAD_INPUT')
    await assert.rejects(definePipeline({ ...env, input: { id: 'x'.repeat(65) } }), (err) => err.code === 'BAD_INPUT')
    await assert.rejects(definePipeline({ ...env, input: {} }), (err) => err.code === 'BAD_INPUT')
  } finally {
    env.cleanup()
  }
})
