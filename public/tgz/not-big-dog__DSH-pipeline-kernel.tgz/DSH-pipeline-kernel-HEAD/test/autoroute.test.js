/**
 * autoRoute 后继完整性测试（审查 §九 invariant 3 + P1-1/P2-4）：
 * done→auto 后继必建（routing:pending 清除 + parent 标签）；rework attempt+1；三振 blocked；
 * 门控→主管；无 route→主管；僵尸任务 reconcile 补投幂等；route 解析容错（全角冒号/等号/返工）。
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createFakeDomain } from './helpers/fake-domain.js'
import { makeConfig, makeCtx, makePipelineDef } from './helpers/setup.js'
import {
  createTask, claimTask, doneTask, autoRoute, reconcileZombies,
  routeOf, isRework, cleanupRegistry, listTasks, targetRole, routeKeyOf,
} from '../lib/pipeline.js'

function makeEnv() {
  const { config, cleanup } = makeConfig()
  const domain = createFakeDomain()
  const ctx = makeCtx()
  const def = makePipelineDef()
  domain.table('pipelines').put(def.id, def)
  // 注册表：UID → 角色（wakeTarget 用）
  domain.table('registry').put('tpl/supervisor', { pipeline: 'tpl', role: 'supervisor', sessionId: 'session-sup', updatedAt: 0 })
  domain.table('registry').put('tpl/designer', { pipeline: 'tpl', role: 'designer', sessionId: 'session-des', updatedAt: 0 })
  domain.table('registry').put('tpl/reviewer', { pipeline: 'tpl', role: 'reviewer', sessionId: 'session-rev', updatedAt: 0 })
  return { domain, config, ctx, cleanup }
}

/** 走完整流程到 done（不自动路由），返回记录。 */
async function pushClaimDone(env, title = 'T', tags = [], result = 'done route:reviewer 产物:design/x.png') {
  const t = await createTask({ ...env, input: { title, tags, source: 'test' } })
  await claimTask({ ...env, taskId: t.id, claimedBy: 'session-x' })
  return doneTask({ ...env, taskId: t.id, result })
}

const baseTags = ['target:designer', 'pipeline:tpl', 'task:T-1', 'attempt:1']

test('done route:reviewer → auto 建下一环：routing:pending 清除 + parent 标签 + 同 task 编号', async () => {
  const env = makeEnv()
  try {
    const done = await pushClaimDone(env, 'T', [...baseTags], 'done route:reviewer 产物:design/x.png')
    const out = await autoRoute({ ...env, record: done })
    assert.equal(out.routed, 'auto')
    const next = env.domain.table('tasks').get(out.nextTask)
    assert.ok(next, '下一环必须创建')
    assert.equal(targetRole(next.tags), 'reviewer')
    assert.ok(next.tags.includes(`parent:${done.id}`), '下一环必须带 parent:<上一环id>（P1-1 溯源判据）')
    assert.ok(next.tags.includes('pipeline:tpl'), '下一环必须带 pipeline:<管线id>（否则唤醒查 default 注册表失败 + UI 不可见）')
    assert.ok(next.tags.includes('task:T-1'), '同链 task 编号延续')
    // 上一环 routing:pending 已清除
    const after = env.domain.table('tasks').get(done.id)
    assert.ok(!after.tags.includes('routing:pending'), '正常路由后必须清除 routing:pending')
  } finally {
    env.cleanup()
  }
})

test('rework → 自动投返工（attempt+1）；中文冒号/等号/返工 容错解析', async () => {
  const env = makeEnv()
  try {
    // 全角冒号 + 返工
    const d1 = await pushClaimDone(env, 'T', [...baseTags], '返工 route：designer 问题：xxx')
    assert.equal(routeOf(d1.result), 'designer')
    assert.equal(isRework(d1.result), true)
    const o1 = await autoRoute({ ...env, record: d1 })
    assert.equal(o1.routed, 'auto')
    const n1 = env.domain.table('tasks').get(o1.nextTask)
    assert.ok(n1.tags.includes('attempt:2'), `rework 必须 attempt+1，实际 ${n1.tags.join(',')}`)
    assert.equal(targetRole(n1.tags), 'designer')
    // 等号形式（换链槽 T-2，避免与上一返工的活跃槽 B-7 冲突）
    const d2 = await pushClaimDone(env, 'T', ['target:designer', 'pipeline:tpl', 'task:T-2', 'attempt:1'], 'rework route=reviewer')
    assert.equal(routeOf(d2.result), 'reviewer')
    const o2 = await autoRoute({ ...env, record: d2 })
    assert.equal(o2.routed, 'auto')
    assert.equal(targetRole(env.domain.table('tasks').get(o2.nextTask).tags), 'reviewer')
  } finally {
    env.cleanup()
  }
})

test('三振：attempt 达阈值 → blocked + 主管，不再投下一环', async () => {
  const env = makeEnv()
  try {
    const tags = ['target:designer', 'pipeline:tpl', 'task:T-1', 'attempt:3'] // strikeOut=3 → 3 次已满
    const done = await pushClaimDone(env, 'T', tags, 'rework route:designer')
    const out = await autoRoute({ ...env, record: done })
    assert.equal(out.routed, 'blocked')
    const after = env.domain.table('tasks').get(done.id)
    assert.ok(after.tags.includes('blocked'), '必须打 blocked 标签')
    assert.equal(listTasks({ domain: env.domain, filter: { status: 'open' } }).length, 0, '三振后不得再投')
  } finally {
    env.cleanup()
  }
})

test('门控环节 → 主管（routed: gate），不自动投', async () => {
  const env = makeEnv()
  try {
    const gated = makePipelineDef({ gates: { g1: { after: 'designer', desc: '' } } })
    env.domain.table('pipelines').put('tpl', gated)
    const done = await pushClaimDone(env, 'T', [...baseTags], 'done route:designer')
    const out = await autoRoute({ ...env, record: done })
    assert.equal(out.routed, 'gate')
    assert.equal(listTasks({ domain: env.domain, filter: { status: 'open' } }).length, 0)
  } finally {
    env.cleanup()
  }
})

test('无 route → 主管（routed: supervisor）', async () => {
  const env = makeEnv()
  try {
    const done = await pushClaimDone(env, 'T', [...baseTags], '完成了，无 route')
    assert.equal(routeOf(done.result), undefined)
    const out = await autoRoute({ ...env, record: done })
    assert.equal(out.routed, 'supervisor')
  } finally {
    env.cleanup()
  }
})

test('未知 route → failed + 主管兜底，不得静默清除 pending', async () => {
  const env = makeEnv()
  try {
    const done = await pushClaimDone(env, 'T', [...baseTags], 'done route:ghost')
    const out = await autoRoute({ ...env, record: done })
    assert.equal(out.routed, 'failed')
    assert.equal(listTasks({ domain: env.domain, filter: { status: 'open' } }).length, 0)
    const after = env.domain.table('tasks').get(done.id)
    assert.ok(after.tags.includes('route:failed'))
    assert.ok(after.tags.includes('routing:pending'), '失败路径应保留 pending 供人工/恢复处理')
    assert.match(after.routeError, /ghost/)
  } finally {
    env.cleanup()
  }
})

test('僵尸自愈（P1-1）：done 残留 routing:pending 无后继 → reconcile 补投且幂等', async () => {
  const env = makeEnv()
  try {
    const done = await pushClaimDone(env, 'T', [...baseTags], 'done route:reviewer')
    // 模拟崩溃：done 提交后未跑 autoRoute —— routing:pending 残留、无后继
    assert.ok(done.tags.includes('routing:pending'))
    assert.equal(listTasks({ domain: env.domain, filter: { status: 'open' } }).length, 0)
    // 自愈：补投下一环
    const r1 = await reconcileZombies({ ...env })
    assert.equal(r1.found, 1)
    assert.equal(r1.recovered.length, 1)
    assert.equal(r1.recovered[0].routed, 'auto')
    const next = listTasks({ domain: env.domain, filter: { status: 'open' } })
    assert.equal(next.length, 1, '自愈必须恰好补投 1 个')
    assert.ok(next[0].tags.includes(`parent:${done.id}`))
    // 幂等：再次扫描 → 0 个僵尸
    const r2 = await reconcileZombies({ ...env })
    assert.equal(r2.found, 0, '有后继后不再重复补投')
    assert.equal(listTasks({ domain: env.domain, filter: { status: 'open' } }).length, 1)
  } finally {
    env.cleanup()
  }
})

test('僵尸自愈跳过 route:failed 任务', async () => {
  const env = makeEnv()
  try {
    const done = await pushClaimDone(env, 'T', [...baseTags], 'done route:reviewer')
    // 手工制造 route:failed 状态（模拟 autoRoute 崩溃前已落 failed 标记）
    await env.domain.table('tasks').update(done.id, (cur) => ({ ...cur, tags: [...cur.tags, 'route:failed'] }))
    const r = await reconcileZombies({ ...env })
    assert.equal(r.found, 0, 'route:failed 是已知失败（已唤主管），不重复补投')
  } finally {
    env.cleanup()
  }
})

test('父任务已有终态后继时：reconcile 只收敛标记，不重复创建', async () => {
  const env = makeEnv()
  try {
    const done = await pushClaimDone(env, 'T', [...baseTags], 'done route:reviewer')
    const key = routeKeyOf({ parentTaskId: done.id, role: 'reviewer', attempt: 1, kind: 'done' })
    const successor = await createTask({
      ...env,
      input: {
        title: 'T',
        tags: ['target:reviewer', 'pipeline:tpl', 'task:T-1', `parent:${done.id}`, 'attempt:1'],
        routeKey: key,
        source: 'pipeline-kernel:auto-route',
      },
    })
    await env.domain.table('tasks').update(successor.id, (cur) => ({ ...cur, status: 'done' }))
    const report = await reconcileZombies({ ...env })
    assert.equal(report.found, 0)
    assert.equal(report.recovered[0].routed, 'already-exists')
    assert.equal(listTasks({ domain: env.domain }).filter((t) => t.tags.includes(`parent:${done.id}`)).length, 1)
    assert.ok(!env.domain.table('tasks').get(done.id).tags.includes('routing:pending'))
  } finally {
    env.cleanup()
  }
})

test('两个 reconcile 并发执行：routeKey 保证最多创建一个后继', async () => {
  const env = makeEnv()
  try {
    const done = await pushClaimDone(env, 'T', [...baseTags], 'done route:reviewer')
    const reports = await Promise.all([
      reconcileZombies({ ...env }),
      reconcileZombies({ ...env }),
    ])
    const successors = listTasks({ domain: env.domain }).filter((t) => t.tags.includes(`parent:${done.id}`))
    assert.equal(successors.length, 1)
    assert.ok(reports.every((report) => report.recovered.length === 1))
  } finally {
    env.cleanup()
  }
})

test('孤儿注册行清理（P2-6）：管线已删且无任务引用 → 删除；有引用保留', async () => {
  const env = makeEnv()
  try {
    env.domain.table('registry').put('ghost/designer', { pipeline: 'ghost', role: 'designer', sessionId: 's1', updatedAt: 0 })
    // default 管线无定义但有无标签任务引用 → 保留
    env.domain.table('registry').put('default/supervisor', { pipeline: 'default', role: 'supervisor', sessionId: 's2', updatedAt: 0 })
    await createTask({ ...env, input: { title: 'untagged', tags: ['target:designer'], source: 'test' } })
    const out = await cleanupRegistry({ ...env })
    assert.deepEqual(out.removed, ['ghost/designer'], '只清真孤儿（ghost），default 有任务引用保留')
  } finally {
    env.cleanup()
  }
})
