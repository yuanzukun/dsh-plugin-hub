/**
 * ledger 台账测试（审查 P2-5 + I-2）：
 * 并发双首写同键 → history 不丢不重（串行锁 + 写链内重读改写）；
 * 同键更新追加变更记录；taskId 关联透传。
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createFakeDomain } from './helpers/fake-domain.js'
import { makeConfig } from './helpers/setup.js'
import { ledgerWrite, ledgerList, strikeCount } from '../lib/ledger.js'

function makeEnv() {
  const { config, cleanup } = makeConfig()
  return { domain: createFakeDomain(), config, cleanup }
}

test('并发双首写同键：history 两条都在，无丢失无重复', async () => {
  const env = makeEnv()
  try {
    const results = await Promise.allSettled([
      ledgerWrite({ ...env, input: { type: 'design', name: 'item', status: 'pending', note: 'a' } }),
      ledgerWrite({ ...env, input: { type: 'design', name: 'item', status: 'pending', note: 'b' } }),
    ])
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 2)
    const row = env.domain.table('ledger').get('design/item')
    assert.ok(row, '条目必须存在')
    assert.equal(row.history.length, 2, `并发首写不得丢 history，实际 ${row.history.length}`)
    const notes = row.history.map((h) => h.note).sort()
    assert.deepEqual(notes, ['a', 'b'])
    assert.equal(row.status, 'pending')
  } finally {
    env.cleanup()
  }
})

test('同键更新：追加 history，状态/路径/备注覆盖', async () => {
  const env = makeEnv()
  try {
    await ledgerWrite({ ...env, input: { type: 'generate', name: 'img-1', path: 'design/1.png', status: 'pending', note: '登记' } })
    await ledgerWrite({ ...env, input: { type: 'generate', name: 'img-1', path: 'design/1.png', status: 'done', note: '过审', taskId: 'T1' } })
    const row = env.domain.table('ledger').get('generate/img-1')
    assert.equal(row.status, 'done')
    assert.equal(row.taskId, 'T1')
    assert.equal(row.history.length, 2)
    assert.equal(row.history[0].status, 'pending')
    assert.equal(row.history[1].status, 'done')
    const rows = ledgerList({ domain: env.domain, filter: { type: 'generate' } })
    assert.equal(rows.length, 1)
  } finally {
    env.cleanup()
  }
})

test('参数缺失 → BAD_INPUT', async () => {
  const env = makeEnv()
  try {
    await assert.rejects(ledgerWrite({ ...env, input: { name: 'x' } }), (err) => err.code === 'BAD_INPUT')
    await assert.rejects(ledgerWrite({ ...env, input: { type: 'x' } }), (err) => err.code === 'BAD_INPUT')
  } finally {
    env.cleanup()
  }
})

test('三振使用原子 update：并发调用只留下一个 blocked 标签且保留其他字段', async () => {
  const env = makeEnv()
  try {
    await env.domain.table('tasks').put('T-strike', {
      id: 'T-strike', title: 'strike', description: '', priority: 'normal', status: 'open',
      tags: ['pipeline:default', 'attempt:3', 'routing:pending'], source: 'test',
      claimedBy: null, doneAt: null, result: 'route:reviewer', lastWakeAt: 123,
      routeKey: null, successorTaskId: null, routeError: null, updatedAt: 1, createdAt: 1,
    })
    await Promise.all([
      strikeCount({ ...env, taskId: 'T-strike' }),
      strikeCount({ ...env, taskId: 'T-strike' }),
    ])
    const task = env.domain.table('tasks').get('T-strike')
    assert.equal(task.tags.filter((tag) => tag === 'blocked').length, 1)
    assert.ok(task.tags.includes('routing:pending'))
    assert.equal(task.lastWakeAt, 123)
  } finally {
    env.cleanup()
  }
})
