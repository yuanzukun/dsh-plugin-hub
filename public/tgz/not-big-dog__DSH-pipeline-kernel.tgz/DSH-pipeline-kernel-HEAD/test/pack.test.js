import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { createFakeDomain } from './helpers/fake-domain.js'
import { makeConfig, makePipelineDef } from './helpers/setup.js'
import { ledgerWrite } from '../lib/ledger.js'
import { packPipeline } from '../lib/pack.js'

test('打包按 pipelineId 隔离台账和产物：同名条目不得串入另一条管线', async () => {
  const { config, cleanup } = makeConfig()
  const domain = createFakeDomain()
  try {
    const alpha = makePipelineDef({ id: 'alpha', projectRoot: 'alpha', artifactRoot: 'artifacts' })
    const beta = makePipelineDef({ id: 'beta', projectRoot: 'beta', artifactRoot: 'artifacts' })
    await domain.table('pipelines').put('alpha', alpha)
    await domain.table('pipelines').put('beta', beta)

    const alphaFile = join(config.projectRoot, 'alpha', 'design', 'same.png')
    const betaFile = join(config.projectRoot, 'beta', 'design', 'same.png')
    mkdirSync(join(config.projectRoot, 'alpha', 'design'), { recursive: true })
    mkdirSync(join(config.projectRoot, 'beta', 'design'), { recursive: true })
    writeFileSync(alphaFile, 'alpha')
    writeFileSync(betaFile, 'beta')
    await ledgerWrite({ domain, input: { pipelineId: 'alpha', type: 'generate', name: 'same', path: 'design/same.png', status: 'done' } })
    await ledgerWrite({ domain, input: { pipelineId: 'beta', type: 'generate', name: 'same', path: 'design/same.png', status: 'done' } })

    const report = await packPipeline({ domain, config, pipelineId: 'alpha' })

    assert.equal(report.deliverables.total, 1)
    assert.equal(report.deliverables.done, 1)
    const records = domain.table('ledger').entries().map(([, row]) => row)
    assert.ok(records.some((row) => row.pipelineId === 'alpha' && row.type === 'pack'))
    assert.ok(records.some((row) => row.pipelineId === 'beta' && row.type === 'generate'))
    assert.equal(records.filter((row) => row.type === 'pack').length, 1)
  } finally {
    cleanup()
  }
})
