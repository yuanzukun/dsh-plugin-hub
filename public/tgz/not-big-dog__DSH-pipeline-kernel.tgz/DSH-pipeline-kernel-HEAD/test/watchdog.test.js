import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createFakeDomain } from './helpers/fake-domain.js'
import { makeConfig, makePipelineDef } from './helpers/setup.js'
import { startWatchdog } from '../lib/watchdog.js'

function makeTask({ id, pipeline, status = 'open', createdAt, updatedAt = createdAt }) {
  return {
    id,
    title: `${pipeline} task`,
    description: '',
    priority: 'normal',
    status,
    tags: [`pipeline:${pipeline}`, 'target:designer'],
    source: 'test',
    claimedBy: null,
    doneAt: status === 'done' ? updatedAt : null,
    result: '',
    lastWakeAt: null,
    routeKey: null,
    successorTaskId: null,
    routeError: null,
    updatedAt,
    createdAt,
  }
}

function makeWatchdogEnv(overrides = {}) {
  const { config, cleanup } = makeConfig({
    watchdogStallMs: 1_000,
    watchdogReportCooldownMs: 0,
    watchdogWakeCooldownMs: 60_000,
    ...overrides,
  })
  const domain = createFakeDomain()
  const messages = []
  let tick
  const ctx = {
    interval: (fn) => {
      tick = fn
      return () => {}
    },
    agents: {
      get: (sessionId) => ({
        status: 'idle',
        followup: (message) => messages.push({ sessionId, message }),
      }),
    },
    logger: { warn: () => {} },
  }
  startWatchdog({ ctx, config, getDomain: async () => domain })
  return { domain, config, messages, getTick: () => tick, cleanup }
}

test('watchdog 按管线独立判断静止：一条管线近期活动不应抑制另一条管线告警', async () => {
  const env = makeWatchdogEnv()
  try {
    const now = Date.now()
    env.domain.table('pipelines').put(makePipelineDef({ id: 'alpha' }).id, makePipelineDef({ id: 'alpha' }))
    env.domain.table('pipelines').put(makePipelineDef({ id: 'beta' }).id, makePipelineDef({ id: 'beta' }))
    env.domain.table('registry').put('alpha/supervisor', { pipeline: 'alpha', role: 'supervisor', sessionId: 'sup-alpha', updatedAt: now })
    env.domain.table('registry').put('beta/supervisor', { pipeline: 'beta', role: 'supervisor', sessionId: 'sup-beta', updatedAt: now })
    await env.domain.table('tasks').put('old-alpha', makeTask({ id: 'old-alpha', pipeline: 'alpha', createdAt: now - 10_000 }))
    await env.domain.table('tasks').put('recent-beta', makeTask({ id: 'recent-beta', pipeline: 'beta', status: 'done', createdAt: now - 20_000, updatedAt: now }))

    await env.getTick()()

    const alpha = env.messages.filter((x) => x.sessionId === 'sup-alpha')
    const beta = env.messages.filter((x) => x.sessionId === 'sup-beta')
    assert.equal(alpha.length, 1)
    assert.match(alpha[0].message.content[0].text, /alpha/)
    assert.equal(beta.length, 0)
  } finally {
    env.cleanup()
  }
})

test('watchdog tick 正在执行时再次触发会被抑制，避免重入和重复唤醒', async () => {
  const { config, cleanup } = makeConfig({ watchdogStallMs: 1_000 })
  const domain = createFakeDomain()
  let tick
  let getDomainCalls = 0
  let release
  const domainReady = new Promise((resolve) => { release = resolve })
  const ctx = {
    interval: (fn) => { tick = fn; return () => {} },
    agents: { get: () => undefined },
    logger: { warn: () => {} },
  }
  startWatchdog({
    ctx,
    config,
    getDomain: async () => {
      getDomainCalls++
      await domainReady
      return domain
    },
  })
  try {
    const first = tick()
    const second = tick()
    assert.equal(await second, undefined)
    release()
    await first
    assert.equal(getDomainCalls, 1)
  } finally {
    cleanup()
  }
})
