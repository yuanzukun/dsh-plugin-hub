/**
 * Web 路由生命周期测试（验收 P1 补强）。
 * 回归验证：
 *  - 7 条路由注册时**必须挂在 webCtx.effect** 而非 ctx.effect（服务卸载时随子 Fiber 释放）；
 *  - 服务"提供→撤销→再提供"在不同服务实例间不冲突（不把旧实例的路由当冲突）。
 *
 * 实现说明：
 *  - 用 stub 模拟 ctx.inject（存下回调）→ invoke() 模拟服务加载触发注册；
 *  - 直连真实 `registerWebSurface`，handler 不触发（不需要真实 domain/snapshot）；
 *  - 由于 cordis 的 fiber 注销/重载属于运行时行为，本测试用两部分覆盖验收意图：
 *      a) 行为测试：加载注册 7 条、重载（新实例）再注册 7 条无冲突；
 *      b) 源码断言：web.js 的路由注册必须走 webCtx.effect，`ctx.effect` 不得用于路由注册
 *         （若未来改回 ctx.effect 会在测试 (b) 红，`ctx.effect 被调用`会在行为测试报错——见下）。
 * @module pipeline-kernel/test/web-lifecycle
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { registerWebSurface } from '../lib/web.js'

const NOOP_CONFIG = { projectRoot: 'C:/x', inboxDir: 'exchange/收件箱', defaultPipeline: 'default' }
const NOOP_DOMAIN = { table: () => ({ get: () => undefined, entries: () => [], size: () => 0 }) }

/** fake webServer：register 记录/校验重复，返回撤销 disposer。 */
function makeFakeWebServer() {
  const registered = []
  const history = []
  return {
    get registered() { return [...registered] },
    get history() { return [...history] },
    register(route) {
      if (registered.includes(route.path)) throw new Error(`duplicate ${route.kind} ${route.path}`)
      registered.push(route.path)
      history.push(['register', route.path])
      return () => {
        const i = registered.indexOf(route.path)
        if (i !== -1) registered.splice(i, 1)
        history.push(['dispose', route.path])
      }
    },
  }
}

/** stub ctx：inject 只存回调；logger/get/on 存在；若路由注册误用 ctx.effect，这里显式抛错暴露。 */
function makeStubCtx() {
  let injectCallback = null
  let ctxEffectCalls = 0
  const ctx = {
    inject(keys, cb) {
      assert.deepEqual([...keys], ['webServer'], '应注入 webServer')
      injectCallback = cb
    },
    on() {},
    logger: { warn() {} },
    get() { return undefined },
    effect() {
      // 若 web.js 用父 ctx.effect 注册路由，则 ctx.effect 会被调用 → 违背 P1，测试红
      ctxEffectCalls++
      return () => {}
    },
    get ctxEffectCalls() { return ctxEffectCalls },
  }
  // 每次 invoke 模拟一次"webServer 服务加载"：创建新 webCtx Fiber，收集其 effect disposer。
  // disposeWebCtx(disposers) 模拟"服务卸载"：执行该 Fiber 的全部 disposer（路由被释放）。
  const invoke = (webServer) => {
    const disposers = []
    const webCtx = {
      webServer,
      effect(fn) {
        const d = fn()
        if (typeof d === 'function') disposers.push(d)
        return d
      },
      logger: { warn() {} },
      get() { return undefined },
    }
    injectCallback(webCtx)
    return disposers
  }
  const disposeWebCtx = (disposers) => {
    for (const d of disposers) d()
    disposers.length = 0
  }
  return { ctx, invoke, disposeWebCtx }
}

test('P1：服务加载注册 7 条路由，且不误用父 ctx.effect', () => {
  const server = makeFakeWebServer()
  const { ctx, invoke } = makeStubCtx()
  registerWebSurface({ ctx, config: NOOP_CONFIG, getDomain: async () => NOOP_DOMAIN })
  invoke(server)
  assert.equal(server.registered.length, 7, '应注册 7 条路由')
  assert.ok(server.registered.includes('/plugins/pipeline-kernel/state'))
  assert.ok(server.registered.includes('/plugins/pipeline-kernel/open-folder'))
  assert.equal(ctx.ctxEffectCalls, 0, '路由注册不得用父 ctx.effect（P1）')
})

test('P1：服务卸载 → 路由真正释放（disposer 执行，registered=0）；重载同一容器可再注册', () => {
  const server = makeFakeWebServer()
  const { ctx, invoke, disposeWebCtx } = makeStubCtx()
  registerWebSurface({ ctx, config: NOOP_CONFIG, getDomain: async () => NOOP_DOMAIN })

  // 第一代服务加载 → 7 条
  const d1 = invoke(server)
  assert.equal(server.registered.length, 7)
  assert.equal(d1.length, 7, 'webCtx.effect 应收集 7 个 disposer（7 条路由注册的 teardown）')

  // 服务卸载：执行 7 个 disposer → 路由全部释放
  disposeWebCtx(d1)
  assert.equal(server.registered.length, 0, '卸载后 7 条路由应从注册容器释放')
  const disposeOps = server.history.filter(([op]) => op === 'dispose').length
  assert.equal(disposeOps, 7, '应有 7 次 dispose 记录')

  // 重载（同一路由容器，新 Fiber）：再注册 7 条，不因旧的误判冲突
  const d2 = invoke(server)
  assert.equal(server.registered.length, 7, '重载后应重新注册 7 条')
  assert.equal(d2.length, 7)
})

test('P1 源码断言：web.js 路由注册处使用 webCtx.effect，禁用 ctx.effect 路由注册', () => {
  const src = readFileSync(new URL('../lib/web.js', import.meta.url), 'utf8')
  // 路由注册必须是 webCtx.effect(...webServer.register...) —— 7 处
  const routeRegs = src.match(/webCtx\.effect\(\(\) => webServer\.register\(/g) ?? []
  assert.equal(routeRegs.length, 7, '7 条路由必须全部经 webCtx.effect 注册')
  // 不得存在"ctx.effect(() => webServer.register"（父级挂载路由）
  const bad = src.match(/ctx\.effect\(\(\) => webServer\.register\(/g) ?? []
  assert.equal(bad.length, 0, '路由不得经父 ctx.effect 注册（P1）')
})
