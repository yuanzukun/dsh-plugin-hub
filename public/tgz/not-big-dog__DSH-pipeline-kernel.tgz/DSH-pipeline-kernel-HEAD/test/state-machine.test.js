/**
 * 状态机 invariant 测试（审查 §九 invariant 1）：
 * 合法链 open→claimed→done；非法转换全拒（BAD_STATE）；并发双 done 恰 1 成功；cancel 两态；missing-key。
 * 统一错误协议：一律 throw KernelError（code: BAD_STATE / MISSING_KEY / BAD_INPUT / DUPLICATE_SLOT）。
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { createFakeDomain } from './helpers/fake-domain.js'
import { makeConfig } from './helpers/setup.js'
import { createTask, claimTask, doneTask, cancelTask, listTasks } from '../lib/pipeline.js'

/** 建一套隔离环境（临时根 + 假域），返回 { domain, config, cleanup }。 */
function makeEnv() {
  const { config, cleanup } = makeConfig()
  return { domain: createFakeDomain(), config, cleanup }
}

/** 投一条任务并返回记录。 */
async function push({ domain, config }, title = 'T1', tags = []) {
  return createTask({ domain, config, input: { title, tags, source: 'test' } })
}

test('合法链：push(open) → claim(claimed) → done(done)，done 打 routing:pending', async () => {
  const env = makeEnv()
  try {
    const t = await push(env, 'T1', ['target:designer', 'pipeline:tpl', 'task:T-1'])
    assert.equal(t.status, 'open')
    const claimed = await claimTask({ ...env, taskId: t.id, claimedBy: 'session-x' })
    assert.equal(claimed.status, 'claimed')
    assert.equal(claimed.claimedBy, 'session-x')
    const done = await doneTask({ ...env, taskId: t.id, result: 'done route:reviewer' })
    assert.equal(done.status, 'done')
    assert.ok(done.tags.includes('routing:pending'), 'done 必须带 routing:pending（P1-1 僵尸检测标记）')
    assert.ok(done.doneAt > 0)
    // 任务单文件投影存在（临时根内）
    const file = existsSync(join(env.config.projectRoot, 'exchange/收件箱/designer', `任务单-${t.id}.md`))
    assert.ok(file, '任务单 md 应落盘')
  } finally {
    env.cleanup()
  }
})

test('非法转换全拒（BAD_STATE）：重复 claim / claim 后 done 前 done / 双 done / cancel 后重复 cancel / done 后 cancel', async () => {
  const env = makeEnv()
  try {
    // 重复 claim
    const t1 = await push(env, 'T1', ['target:designer'])
    await claimTask({ ...env, taskId: t1.id, claimedBy: 'a' })
    await assert.rejects(claimTask({ ...env, taskId: t1.id, claimedBy: 'b' }), (err) => {
      assert.equal(err.code, 'BAD_STATE')
      assert.match(err.message, /claimed/)
      return true
    })
    // open 任务直接 done（未认领）
    const t2 = await push(env, 'T2', ['target:designer'])
    await assert.rejects(doneTask({ ...env, taskId: t2.id, result: 'done route:reviewer' }), (err) => err.code === 'BAD_STATE')
    // 双 done：只成功一次
    const t3 = await push(env, 'T3', ['target:designer'])
    await claimTask({ ...env, taskId: t3.id, claimedBy: 'a' })
    await doneTask({ ...env, taskId: t3.id, result: 'done route:reviewer' })
    await assert.rejects(doneTask({ ...env, taskId: t3.id, result: 'done route:reviewer' }), (err) => err.code === 'BAD_STATE')
    // cancel 后重复 cancel
    const t4 = await push(env, 'T4', ['target:designer'])
    await claimTask({ ...env, taskId: t4.id, claimedBy: 'a' })
    await cancelTask({ ...env, taskId: t4.id, reason: 'x' })
    await assert.rejects(cancelTask({ ...env, taskId: t4.id, reason: 'y' }), (err) => err.code === 'BAD_STATE')
    // done 后 cancel
    const t5 = await push(env, 'T5', ['target:designer'])
    await claimTask({ ...env, taskId: t5.id, claimedBy: 'a' })
    await doneTask({ ...env, taskId: t5.id, result: 'ok' })
    await assert.rejects(cancelTask({ ...env, taskId: t5.id, reason: 'z' }), (err) => err.code === 'BAD_STATE')
    // 状态最终集
    const rows = listTasks({ domain: env.domain })
    assert.equal(rows.filter((r) => r.status === 'claimed').length, 1, '只有 t1 停在 claimed')
    assert.equal(rows.filter((r) => r.status === 'done').length, 2, 't3/t5 done')
    assert.equal(rows.filter((r) => r.status === 'cancelled').length, 1, 't4 cancelled')
  } finally {
    env.cleanup()
  }
})

test('并发双 done 同一任务：恰 1 成功（写链内 BAD_STATE 防重入）', async () => {
  const env = makeEnv()
  try {
    const t = await push(env, 'T1', ['target:designer'])
    await claimTask({ ...env, taskId: t.id, claimedBy: 'a' })
    const results = await Promise.allSettled([
      doneTask({ ...env, taskId: t.id, result: 'done route:reviewer' }),
      doneTask({ ...env, taskId: t.id, result: 'done route:reviewer' }),
    ])
    const okCount = results.filter((r) => r.status === 'fulfilled').length
    const badStateCount = results.filter((r) => r.status === 'rejected' && r.reason.code === 'BAD_STATE').length
    assert.equal(okCount, 1, '并发双 done 只允许一个成功')
    assert.equal(badStateCount, 1, '另一个必须 BAD_STATE')
    // 且只有一条 done 记录
    const done = listTasks({ domain: env.domain, filter: { status: 'done' } })
    assert.equal(done.length, 1)
  } finally {
    env.cleanup()
  }
})

test('missing-key：不存在的任务 claim/done/cancel 均 MISSING_KEY', async () => {
  const env = makeEnv()
  try {
    await assert.rejects(claimTask({ ...env, taskId: 'T-none', claimedBy: 'a' }), (err) => err.code === 'MISSING_KEY')
    await assert.rejects(doneTask({ ...env, taskId: 'T-none', result: 'x' }), (err) => err.code === 'MISSING_KEY')
    await assert.rejects(cancelTask({ ...env, taskId: 'T-none', reason: 'x' }), (err) => err.code === 'MISSING_KEY')
  } finally {
    env.cleanup()
  }
})

test('输入校验：非法 title / 非法 target 角色（路径穿越）拒绝', async () => {
  const env = makeEnv()
  try {
    await assert.rejects(push(env, '', ['target:designer']), (err) => err.code === 'BAD_INPUT')
    await assert.rejects(push(env, 'x', ['target:../evil']), (err) => err.code === 'BAD_ROLE')
    await assert.rejects(push(env, 'x'.repeat(201), ['target:designer']), (err) => err.code === 'BAD_INPUT')
  } finally {
    env.cleanup()
  }
})
