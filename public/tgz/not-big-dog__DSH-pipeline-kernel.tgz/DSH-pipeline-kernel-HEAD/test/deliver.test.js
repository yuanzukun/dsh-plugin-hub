/**
 * deliverArtifacts 硬化测试（审查 P1-2）：
 * taskId 强关联（不扫全表）；根外路径拒绝（S-1 扩展）；同名不覆盖；节点内移动/节点外复制；
 * .tmp- 原子搬移与崩溃残留清扫；result `产物:` 显式声明。
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync, existsSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { createFakeDomain } from './helpers/fake-domain.js'
import { makeConfig, makePipelineDef } from './helpers/setup.js'
import { ensureNodeDirs, deliverArtifacts, createTask } from '../lib/pipeline.js'
import { ledgerWrite } from '../lib/ledger.js'

function makeEnv() {
  const { config, cleanup } = makeConfig()
  const domain = createFakeDomain()
  const def = makePipelineDef()
  domain.table('pipelines').put(def.id, def)
  ensureNodeDirs({ domain, config, pipelineId: def.id, scope: 'all' })
  // 节点目录：节点1=designer，节点2=reviewer
  return { domain, config, cleanup }
}

/** 写文件 + 台账关联 taskId。 */
async function registerArtifact(env, taskId, type, name, relPath) {
  const abs = join(env.config.projectRoot, relPath)
  mkdirSync(join(abs, '..'), { recursive: true })
  writeFileSync(abs, `${type}:${name}`, 'utf8')
  return ledgerWrite({
    ...env,
    input: { type, name, path: relPath, status: 'done', taskId },
  })
}

test('只搬本任务强关联产物：节点内移动、节点外复制、他任务不动', async () => {
  const env = makeEnv()
  try {
    const root = env.config.projectRoot
    const t1 = await createTask({ ...env, input: { title: 'T1', tags: ['target:reviewer', 'pipeline:tpl'], source: 'test' } })
    const t2 = await createTask({ ...env, input: { title: 'T2', tags: ['target:designer', 'pipeline:tpl'], source: 'test' } })
    // T1 关联两条：节点内(节点1/designer 产物) + 节点外(根外资源库)
    await registerArtifact(env, t1.id, 'design', 'a', '节点1/a.png')
    await registerArtifact(env, t1.id, 'design', 'b', '资源库/b.png')
    // T2 关联一条（不该被搬）
    await registerArtifact(env, t2.id, 'design', 'c', '节点2/c.png')
    const out = deliverArtifacts({ ...env, pipelineId: 'tpl', taskId: t1.id })
    assert.equal(out.moved.length, 1, '节点内产物应移动')
    assert.equal(out.moved[0].path, '节点1/a.png')
    assert.equal(out.copied.length, 1, '节点外产物应复制')
    assert.equal(out.copied[0].path, '资源库/b.png')
    // 搬移结果：a 已到 交付/，节点1 里没了；b 复制后原文件还在
    assert.ok(existsSync(join(root, '交付/a.png')), 'a 应到交付目录')
    assert.ok(!existsSync(join(root, '节点1/a.png')), '节点内 a 应被移走')
    assert.ok(existsSync(join(root, '交付/b.png')), 'b 副本应到交付目录')
    assert.ok(existsSync(join(root, '资源库/b.png')), '资源库 b 原件应保留（目录外只复制）')
    // T2 的产物原封不动
    assert.ok(existsSync(join(root, '节点2/c.png')), '他任务产物不得搬动')
    assert.ok(!existsSync(join(root, '交付/c.png')), '他任务产物不得进交付')
  } finally {
    env.cleanup()
  }
})

test('根外路径拒绝（S-1 扩展）：../../ 越界路径不读不复制', async () => {
  const env = makeEnv()
  try {
    const t = await createTask({ ...env, input: { title: 'T', tags: ['target:reviewer', 'pipeline:tpl'], source: 'test' } })
    await ledgerWrite({
      ...env,
      input: { type: 'design', name: 'evil', path: '../../etc/passwd', status: 'done', taskId: t.id },
    })
    const out = deliverArtifacts({ ...env, pipelineId: 'tpl', taskId: t.id })
    assert.equal(out.moved.length + out.copied.length, 0)
    assert.equal(out.skipped.length, 1)
    assert.match(out.skipped[0].reason, /项目根外路径拒绝/)
  } finally {
    env.cleanup()
  }
})

test('同名不覆盖：不同目录同 basename → 第二个 skip', async () => {
  const env = makeEnv()
  try {
    const root = env.config.projectRoot
    const t = await createTask({ ...env, input: { title: 'T', tags: ['target:reviewer', 'pipeline:tpl'], source: 'test' } })
    await registerArtifact(env, t.id, 'design', 'x1', '节点1/同名.png')
    await registerArtifact(env, t.id, 'design', 'x2', '节点2/同名.png')
    const out = deliverArtifacts({ ...env, pipelineId: 'tpl', taskId: t.id })
    assert.equal(out.moved.length, 1, '第一个搬成功')
    assert.equal(out.skipped.length, 1, '第二个因同名 skip')
    assert.match(out.skipped[0].reason, /已有同名文件/)
    assert.ok(existsSync(join(root, '交付/同名.png')))
    assert.ok(existsSync(join(root, '节点2/同名.png')), '被 skip 的原件保留')
  } finally {
    env.cleanup()
  }
})

test('.tmp- 崩溃残留清扫 + result 显式声明路径也搬', async () => {
  const env = makeEnv()
  try {
    const root = env.config.projectRoot
    const t = await createTask({ ...env, input: { title: 'T', tags: ['target:reviewer', 'pipeline:tpl'], source: 'test' } })
    // 制造上次崩溃残留
    mkdirSync(join(root, '交付'), { recursive: true })
    writeFileSync(join(root, '交付/.tmp-x.png-deadbeef'), '残留', 'utf8')
    // result 显式声明产物（不走台账）
    const done = { ...t, result: 'done route:archive 产物:节点1/result.png 产物：节点2/result2.png' }
    writeFileSync(join(root, '节点1/result.png'), 'r1', 'utf8')
    writeFileSync(join(root, '节点2/result2.png'), 'r2', 'utf8')
    const out = deliverArtifacts({ ...env, pipelineId: 'tpl', taskId: t.id, record: done })
    assert.equal(out.moved.length, 2, 'result 声明两条都搬')
    // 残留清扫
    const leftovers = readdirSync(join(root, '交付')).filter((f) => f.startsWith('.tmp-'))
    assert.equal(leftovers.length, 0, '.tmp- 残留必须被清扫')
    assert.ok(existsSync(join(root, '交付/result.png')))
    assert.ok(existsSync(join(root, '交付/result2.png')))
  } finally {
    env.cleanup()
  }
})

test('taskId 必填：缺失 → BAD_INPUT', () => {
  const env = makeEnv()
  try {
    assert.throws(() => deliverArtifacts({ ...env, pipelineId: 'tpl' }), (err) => err.code === 'BAD_INPUT')
  } finally {
    env.cleanup()
  }
})
