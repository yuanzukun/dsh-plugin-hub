/**
 * 快照失效契约测试（验收 P2 补强第 3 点）。
 * 验证：
 *  - createDirtyFlag 独立实例：invalidate → consume 返回 true 且清脏，再 consume 返回 false；
 *  - 源码断言：index.js 订阅 `domain/changed` 且 filter domain === 'pipeline_kernel'（统一失效源）；
 *  - 源码断言：web.js /state 用 consumeDirty（重建后清脏）。
 * 不依赖真实 storageDomain 运行时（domain/changed 发射由宿主负责，本测试验证内核侧订阅语义 + 失效状态机）。
 * @module pipeline-kernel/test/dirty
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { createDirtyFlag } from '../lib/dirty.js'

test('createDirtyFlag：初始脏，invalidate 置脏，consume 取走并清空', () => {
  const flag = createDirtyFlag()
  assert.equal(flag.consume(), true, '初始应为脏（首次 /state 必重建）')
  assert.equal(flag.consume(), false, '消费后应清脏')
  flag.invalidate()
  assert.equal(flag.consume(), true, 'invalidate 后应转脏')
  assert.equal(flag.consume(), false)
})

test('createDirtyFlag：实例间状态隔离（测试不污染单例）', () => {
  const a = createDirtyFlag()
  const b = createDirtyFlag()
  a.invalidate()
  a.consume() // 清 a
  assert.equal(a.consume(), false)
  assert.equal(b.consume(), true, 'b 不受 a 影响，仍初始脏')
})

test('T-D1 源码：index.js 订阅 domain/changed 且只对 pipeline_kernel 域失效', () => {
  const src = readFileSync(new URL('../lib/index.js', import.meta.url), 'utf8')
  assert.match(src, /ctx\.on\('domain\/changed'/, '应订阅 domain/changed')
  assert.match(src, /change\?\.domain === 'pipeline_kernel'/, '应 filter pipeline_kernel 域')
  assert.match(src, /invalidateSnapshot\(\)/, 'filter 通过后应调用统一失效')
})

test('T-D1 源码：web.js /state 用 consumeDirty 取脏（重建后清脏）', () => {
  const src = readFileSync(new URL('../lib/web.js', import.meta.url), 'utf8')
  assert.match(src, /consumeDirty\(\)/, '/state 应以 consumeDirty 取脏')
})

/**
 * 完整行为链组合测试：模拟 web.js /state 缓存逻辑 + index.js 的 domain/changed 订阅。
 * 覆盖验收条件"Domain 写入后下一次 GET 返回新快照"：
 *   旧快照已缓存 → pipeline_kernel domain/changed → 置脏 → 下一次 /state 重建 → 返回新数据。
 * 用 createDirtyFlag 独立实例 + 仿 web.js 的 buildCached（同结构），真实执行而非正则。
 */
test('T-D1 行为链：事件置脏 → 下一次 GET 重建返回新数据，未置脏走缓存', () => {
  const flag = createDirtyFlag()
  flag.consume() // 清初始脏，模拟"已建过快照"

  // 仿 web.js /state：缓存 + TTL 兜底 + consumeDirty 失效判断
  let builds = 0
  let served = 0
  let dataVersion = 1
  const buildSnapshot = () => {
    builds++
    return { generatedAt: Date.now(), version: dataVersion }
  }
  const cache = { live: null, archived: null }
  const buildCached = (archived, domain) => {
    const key = archived ? 'archived' : 'live'
    const cached = cache[key]
    const now = Date.now()
    if (cached && now - cached.generatedAt < 30000) return cached
    cache[key] = buildSnapshot()
    return cache[key]
  }
  // 模拟 index.js 的 domain/changed 订阅（filter pipeline_kernel → invalidate）
  const onDomainChanged = (change) => {
    if (change?.domain === 'pipeline_kernel') flag.invalidate()
  }
  // 仿 web.js /state handler 的取快照逻辑（isDirty ? 重建两视图 : buildCached）
  const getSnapshot = (archived) => {
    served++
    if (flag.consume()) {
      cache.live = buildSnapshot()
      cache.archived = buildSnapshot()
      return cache[archived ? 'archived' : 'live']
    }
    return buildCached(archived)
  }

  // 1) 首次 GET：live 缓存为空 → 建一次（builds=1）；连续第二次未置脏 → 走缓存不重建
  const first = getSnapshot(false)
  assert.equal(first.version, 1)
  assert.equal(builds, 1, '首次 live 缓存为空应建一次')
  getSnapshot(false)
  assert.equal(builds, 1, 'TTL 内缓存命中不应重建')

  // 2) pipeline_kernel domain 写入 → domain/changed → 置脏
  onDomainChanged({ domain: 'pipeline_kernel', table: 'tasks', key: 't', operation: 'put' })
  // 下一个 /state：重建（两视图）+ 返回新数据
  dataVersion = 2
  const after = getSnapshot(false)
  assert.equal(after.version, 2, '事件置脏后 GET 应返回新数据')
  assert.equal(builds, 3, '置脏应重建两视图（live+archived）= +2')

  // 3) 非 pipeline_kernel 域：不影响快照缓存
  const before = getSnapshot(false)
  onDomainChanged({ domain: 'other', table: 'x', key: 'y', operation: 'put' })
  const afterOther = getSnapshot(false)
  assert.equal(afterOther.generatedAt, before.generatedAt, '非 pipeline_kernel 域不应触发重建（走缓存）')
  assert.equal(builds, 3, '非本域事件不应增加重建')
})
