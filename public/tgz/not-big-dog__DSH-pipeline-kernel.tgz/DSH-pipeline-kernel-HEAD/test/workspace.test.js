/** workspace resolver 测试：非默认 projectRoot、pack 路径和工作区越界。 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { createFakeDomain } from './helpers/fake-domain.js'
import { makeConfig, makePipelineDef } from './helpers/setup.js'
import {
  artifactRootOf,
  inboxRootOf,
  resolveAllowedWorkspacePath,
  resolvePackPath,
  workspaceRootOf,
} from '../lib/workspace.js'

test('workspace resolver 统一解析管线专属根、收件箱和产物根', () => {
  const { config, cleanup } = makeConfig()
  try {
    const domain = createFakeDomain()
    domain.table('pipelines').put('tpl', makePipelineDef({
      projectRoot: 'projects/tpl',
      inboxDir: 'exchange/inbox',
      artifactRoot: 'artifacts',
    }))
    assert.equal(workspaceRootOf({ domain, config }, 'tpl'), join(config.projectRoot, 'projects/tpl'))
    assert.equal(inboxRootOf({ domain, config }, 'tpl'), join(config.projectRoot, 'projects/tpl', 'exchange/inbox'))
    assert.equal(artifactRootOf({ domain, config }, 'tpl'), join(config.projectRoot, 'projects/tpl', 'artifacts'))
  } finally {
    cleanup()
  }
})

test('workspace path traversal 被拒绝，pack 相对路径可按已知管线根查找', () => {
  const { config, cleanup } = makeConfig()
  try {
    const domain = createFakeDomain()
    domain.table('pipelines').put('tpl', makePipelineDef({ projectRoot: 'projects/tpl', artifactRoot: 'artifacts' }))
    const pack = join(config.projectRoot, 'projects/tpl/artifacts/packs/demo-v1.json')
    mkdirSync(join(pack, '..'), { recursive: true })
    writeFileSync(pack, '{}', 'utf8')
    assert.equal(resolvePackPath({ domain, config, pipelineId: 'tpl', input: 'artifacts/packs/demo-v1.json' }), pack)
    assert.throws(
      () => resolveAllowedWorkspacePath({ domain, config, input: join(config.projectRoot, '..', 'outside') }),
      (err) => err.code === 'BAD_INPUT',
    )
    domain.table('pipelines').put('unsafe', makePipelineDef({ id: 'unsafe', artifactRoot: '../outside' }))
    assert.throws(() => artifactRootOf({ domain, config }, 'unsafe'), (err) => err.code === 'BAD_INPUT')
    domain.table('pipelines').put('unsafe-inbox', makePipelineDef({ id: 'unsafe-inbox', inboxDir: '../outside' }))
    assert.throws(() => inboxRootOf({ domain, config }, 'unsafe-inbox'), (err) => err.code === 'BAD_INPUT')
  } finally {
    cleanup()
  }
})
