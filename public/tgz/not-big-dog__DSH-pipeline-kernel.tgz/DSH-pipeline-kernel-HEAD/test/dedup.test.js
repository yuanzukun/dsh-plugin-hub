/**
 * B-7 同链槽去重测试（审查 §九 invariant 2 + §四-2）：
 * 并发双 push 同槽（同 task:<编号> + 同 target:<角色>）→ 恰好 1 个 open（串行锁 + 写链内查重）。
 * 不同槽 / 已 done 的旧任务 → 允许再投。
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createFakeDomain } from './helpers/fake-domain.js'
import { makeConfig } from './helpers/setup.js'
import { createTask, claimTask, doneTask, listTasks } from '../lib/pipeline.js'

function makeEnv() {
  const { config, cleanup } = makeConfig()
  return { domain: createFakeDomain(), config, cleanup }
}

const slotTags = ['target:designer', 'pipeline:tpl', 'task:T-1', 'attempt:1']

test('并发双 push 同槽：恰 1 个 open，另一个 DUPLICATE_SLOT', async () => {
  const env = makeEnv()
  try {
    const results = await Promise.allSettled([
      createTask({ ...env, input: { title: 'A', tags: [...slotTags], source: 'a' } }),
      createTask({ ...env, input: { title: 'B', tags: [...slotTags], source: 'b' } }),
    ])
    const ok = results.filter((r) => r.status === 'fulfilled')
    const dup = results.filter((r) => r.status === 'rejected' && r.reason.code === 'DUPLICATE_SLOT')
    assert.equal(ok.length, 1, `并发双 push 只能成功 1 个，实际 ${ok.length}`)
    assert.equal(dup.length, 1, '另一个必须是 DUPLICATE_SLOT')
    const open = listTasks({ domain: env.domain, filter: { status: 'open' } })
    assert.equal(open.length, 1, '任务板恰好 1 个 open')
    assert.equal(open[0].title, ok[0].value.title)
  } finally {
    env.cleanup()
  }
})

test('同槽已 done（返工完成）→ 允许再投新 attempt', async () => {
  const env = makeEnv()
  try {
    const t = await createTask({ ...env, input: { title: 'A', tags: [...slotTags], source: 'a' } })
    await claimTask({ ...env, taskId: t.id, claimedBy: 'x' })
    await doneTask({ ...env, taskId: t.id, result: 'done route:reviewer' })
    // 旧任务已 done → 同槽新 attempt 允许
    const again = await createTask({ ...env, input: { title: 'A2', tags: ['target:designer', 'pipeline:tpl', 'task:T-1', 'attempt:2'], source: 'a' } })
    assert.equal(again.status, 'open')
  } finally {
    env.cleanup()
  }
})

test('不同槽（不同 target / 不同 task 编号）互不冲突', async () => {
  const env = makeEnv()
  try {
    await createTask({ ...env, input: { title: 'A', tags: ['target:designer', 'pipeline:tpl', 'task:T-1'], source: 'a' } })
    await createTask({ ...env, input: { title: 'B', tags: ['target:reviewer', 'pipeline:tpl', 'task:T-1'], source: 'a' } })
    await createTask({ ...env, input: { title: 'C', tags: ['target:designer', 'pipeline:tpl', 'task:T-2'], source: 'a' } })
    await createTask({ ...env, input: { title: 'D', tags: ['target:designer'], source: 'a' } }) // 无 task 编号不查重
    assert.equal(listTasks({ domain: env.domain, filter: { status: 'open' } }).length, 4)
  } finally {
    env.cleanup()
  }
})
