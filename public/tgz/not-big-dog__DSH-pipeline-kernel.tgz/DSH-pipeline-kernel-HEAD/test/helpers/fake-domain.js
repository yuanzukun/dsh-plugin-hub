/**
 * 测试用 in-memory domain（复刻 storageDomain 写链语义）：
 * - update(key, fn)：写链内同步读改写；fn 抛错传播；missing-key 抛 { code: 'missing-key' }。
 * - 读写都过 structuredClone——模拟 JSON 持久化的"快照"边界（get 到的对象改动不影响存储）。
 * 零依赖，供 node:test 注入 lib 纯函数（transition/createTask/doneTask/autoRoute/deliverArtifacts…）。
 * @module pipeline-kernel/test/helpers/fake-domain
 */
export function createFakeDomain() {
  const tables = new Map()
  const table = (name) => {
    let map = tables.get(name)
    if (!map) {
      map = new Map()
      tables.set(name, map)
    }
    return {
      get: (key) => (map.has(key) ? structuredClone(map.get(key)) : undefined),
      put: async (key, value) => {
        map.set(key, structuredClone(value))
        return structuredClone(value)
      },
      update: async (key, fn) => {
        if (!map.has(key)) {
          throw Object.assign(new Error(`missing-key: ${key}`), { code: 'missing-key' })
        }
        const cur = structuredClone(map.get(key))
        const next = fn(cur)
        map.set(key, structuredClone(next))
        return structuredClone(next)
      },
      delete: async (key) => {
        map.delete(key)
      },
      entries: () => [...map.entries()].map(([k, v]) => [k, structuredClone(v)]),
      size: () => map.size,
    }
  }
  return { table, tables }
}
