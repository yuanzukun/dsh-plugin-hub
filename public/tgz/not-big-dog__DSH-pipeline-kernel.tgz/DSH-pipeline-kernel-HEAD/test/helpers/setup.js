/**
 * 测试公共配置：临时项目根（lib 的 writeTaskFile/deliverArtifacts 会真实落盘，指到临时目录，测后清理）。
 * @module pipeline-kernel/test/helpers/setup
 */
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

/** 建临时根 + 默认配置。返回 { config, cleanup }。 */
export function makeConfig(overrides = {}) {
  const root = mkdtempSync(join(tmpdir(), 'pk-test-'))
  const config = {
    projectRoot: root,
    inboxDir: 'exchange/收件箱',
    defaultPipeline: 'default',
    strikeOut: 3,
    ...overrides,
  }
  return {
    config,
    cleanup: () => rmSync(root, { recursive: true, force: true }),
  }
}

/** 测试用 ctx 桩：无 live agent（唤醒一律 woken:false），logger 收集警告。 */
export function makeCtx() {
  const warns = []
  return {
    agents: { get: () => undefined },
    logger: { warn: (msg) => warns.push(String(msg)) },
    warns,
  }
}

/** 测试用管线定义（roles 含 supervisor/designer/reviewer，chain 单链）。 */
export function makePipelineDef(overrides = {}) {
  return {
    id: 'tpl',
    title: 'test pipeline',
    projectRoot: '',
    roles: {
      supervisor: { preset: 'pipeline-supervisor' },
      designer: {},
      reviewer: {},
    },
    chain: ['designer', 'reviewer'],
    entry: { default: 'designer' },
    gates: {},
    artifactRoot: 'design/',
    inboxDir: 'exchange/收件箱',
    strikeOut: 3,
    modelDefaults: {},
    updatedAt: Date.now(),
    ...overrides,
  }
}
