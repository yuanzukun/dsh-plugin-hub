# DSH Pipeline Kernel 工程 TODO 清单（本轮：Kernel 削薄 + rc.8 原生接入）

> **状态：✅ 已完工（2026-08-20）**——5 阶段全部完成并提交 `v0.9.0`（阶段 0~4 + 两轮验收修复 + CI 跨平台收尾）；验收复验通过（含 P1 Web 生命周期修复 + P2 测试补强 + 二次验收 P2 证据补强）。
> 生成：2026-08-20 ｜ 基线：宿主 `deepseek-harness 0.1.0-rc.8`（已实测）
> **范围声明（用户拍板）**：本轮**只做**两件事——① Kernel 削薄（把自建的运行时机制替换为 DSH rc.8 原生，行为等价）；② rc.8 原生能力接入（依赖对齐 + 契约 + 事件驱动等）。
> **本轮明确不做**（后续画布施工再议）：见文末"排除清单"。
> 规则：**待验收通过后方可开工**；每项含验收标准，未达标不算完成；打卡表在文末。

---

## 工作区事实（开工前共识 → 完工后实测）

| 事实 | 值 |
|---|---|
| 宿主运行时 | `%APPDATA%\npm\node_modules\@deepseek-ai\dsh` @ `0.1.0-rc.8` |
| 插件工具数 | 20 个 `pipeline_*`（**本轮全部保留**） |
| 插件测试基线 | ✅ **完工后实测 64/64 全绿**（分文件：agent-runtime 15 / autoroute 11 / contract-rc8 4 / dedup 3 / define 4 / deliver 5 / dirty 5 / ledger 4 / pack 1 / state-machine 5 / watchdog 2 / web-lifecycle 3 / workspace 2）——阶段 0 前端为 34/33/1（rc.6 错位环境）；对齐 rc.8 + 补强后全绿 |
| 存量数据 | pipelines 2（pic/233）、tasks 22、ledger 27、registry 5（**本轮全部保留**） |
| 参照核对文档 | `docs/rc8能力核对与改装方案.md`（能力签名与插件用法差异已实测） |

> 基线差异说明：测试通过数取决于 node_modules 来源（独立 checkout / 宿主嵌套树 / 插件的 rc.6 树会给出不同结果）。本清单最终以"阶段 0 后全绿"为验收锚点——完工为 64/64。

**本轮铁律**：
1. **不改变业务语义**：Task 状态机、Gate、Route（含自由文本 `route:` 解析）、收件箱、Registry、工具返回结构——全部保持现状。
2. **不改变用户操作入口**：右下角胶囊、侧栏视图、`/pipeline` 命令、20 个工具——全部保持；**body portal 挂载方式本轮不改**（Slot 迁移属后续 UI/画布阶段）。
3. **削薄 = 实现替换，不是功能删除**：把"内核自己维护的 Agent 运行时机制"换成 DSH rc.8 原生等价物，对外行为不变。
4. 渐变迁移：加可空字段不 bump domain version；不新建 Domain。
5. 编译/测试/运行三态同站（同一套 rc.8 依赖）；**依赖用插件自身 pnpm 安装锁定 rc.8，不链接全局宿主**（宿主仅用于最终 Profile 集成验证）。

---

## 阶段 0：基线对齐与契约测试（前置，阻塞一切）

- [x] **T-A1** peer/dev 依赖对齐 rc.8（插件自身 pnpm 锁定，不链接宿主）
  - 改动（基于 `npm view` 复核的事实）：
    - **保留** `@deepseek-ai/dsh-client-ui-slots@^0.1.0-rc.8`（rc.8 存在；`Translate`/`LocaleNamespaceMap` 类型直接依赖它）；
    - **保留** `@deepseek-ai/dsh-client-runtime@^0.1.0-rc.8`（存在，deps 为 immer/zustand，可公共解析）；
    - **移除** `@deepseek-ai/dsh-client-web-react`（rc.8 **不存在**）；
    - **移除** `@deepseek-ai/dsh-client-schema-form`（rc.8 **不存在**）；
    - `dsh-client-ui-primitives`：rc.8 **存在**，但当前源码未直接 import，按"未使用依赖"移除（**不能写成"rc.8 不存在"**）；
    - host peer（agent/llm/storage-domain/tools）+ `cordis`（**用 4.x，不是 rc.8**）对齐。
  - 验收：`pnpm install --frozen-lockfile` 干净通过；`npm ls @deepseek-ai/*` 无 rc.6；host 测试全绿。
- [x] **T-A2** pnpm-lock.yaml 锁定 rc.8（不依赖宿主安装结构）
  - 改动：以插件自身 devDependencies（精确 `0.1.0-rc.8`）生成 pnpm-lock.yaml；CI 用 `--frozen-lockfile`。
  - 验收：CI 干净环境可 install；本阶段**不引入 `dsh-subagent` 依赖**（本轮不使用 Subagent、不切换执行策略——不为测试未使用能力加依赖）；不再因宿主目录变化而改变测试结果。
- [x] **T-A3** 契约测试（拆 Host / Client 两组）
  - `test/contract-rc8-host.test.js`（Node 冒烟）：`ctx.agents.get/list`、`ctx.agentPresets.mount` 签名、`ctx.sessionPersistence.inspect(id).meta.cwd`、`ctx.storageDomain.open` + `ctx.on('domain/changed')` 订阅、`ctx.webServer.register` 返回 disposer、`ctx.workspaceRegistry`、`ctx.agentDefaultModel`。
  - Client 侧：**不写 `ctx.slots` 行为测试**（本轮不迁 Slot）；以 `npm run typecheck:client` + `npm run build:client` + 浏览器加载冒烟为契约。
  - 验收：Host 契约测试在 rc.8 全绿；client typecheck/build 通过；同上 `npm test`。
- [x] **T-A4** CI 不再降级
  - 改动：`scripts/ci.sh` 依赖缺失降级逻辑改为"rc.8 对齐后必须全量"（CI 用 frozen lockfile）。
  - 验收：CI 在干净环境跑通 install + 测试 + 构建 + 产物 diff。

## 阶段 1：rc.8 兼容修复（真 bug / 死代码，不改业务语义）

- [x] **T-B1** `seed.js` 替换 `sessionPersistence.entryFor`
  - 现状：`entryFor?.(id)` 恒 undefined（rc.8 无此公开方法）→ 静默走"无法判定→复用"分支，非 live 撞车残留不可识别。
  - 改：用 `ctx.sessionPersistence.inspect(id).meta.cwd`（字段是 `meta` 不是 `header`）判 cwd 匹配；`listSnapshots().header.cwd` 为备选。**cwd 判定语义不变**（仅换数据来源）。
  - 验收：播种撞车检测行为等价或更好；无 `entryFor` 残留；Host 契约测试覆盖 inspect 路径。
- [x] **T-B2** 删除死代码双键探测
  - 改：`seed.js` 去掉 `?? ctx.get('workspace')`；`web.js` 删 `WEB_SERVER_KEYS` 中 `httpServer`（rc.8 无此键）。
  - 验收：repo 内无 `ctx.get('workspace')` / `ctx.get('httpServer')`；测试全绿。
- [x] **T-B3** client 依赖引用精简（基于 npm 事实）
  - 事实（`npm view` 复核）：`dsh-client-ui-slots@rc.8` 存在（保留）；`dsh-client-ui-primitives@rc.8` 存在（未使用，可删但**不是"rc.8 不存在"**）；`dsh-client-web-react@rc.8` 不存在（删）；`dsh-client-schema-form@rc.8` 不存在（删）；`dsh-client-runtime@rc.8` 存在（保留）。
  - 改：`package.json` peer/dev 按上述加减；`tsdown.config.ts` PLATFORM_MODULES 同步（删 web-react/schema-form/未用的 primitives；保留 ui-slots）。
  - 验收：`pnpm install --frozen-lockfile` 通过；`npm run build:client` 与 `typecheck:client` 通过。
- [x] **T-B4** client 类型源：保留 `dsh-client-ui-slots` 的 augmentation
  - 事实：`LocaleNamespaceMap` 与 `Translate` 的原始声明确实位于 `@deepseek-ai/dsh-client-ui-slots`；当前写法 `declare module '@deepseek-ai/dsh-client-ui-slots' { interface LocaleNamespaceMap { pipeline: keyof typeof zh } }` 在 rc.8 是**正确**的，`dsh-client-locale/client` 只是 re-export `Translate`。
  - 改：**保留** module augmentation；补齐 rc.8 的 `dsh-client-ui-slots` 依赖；**不使用本地伪 module declaration 兜底**。
  - 可选项：`PipelinePanel.tsx` 可继续从 `@deepseek-ai/dsh-client-ui-slots` 导入 `Translate`，或改用 `dsh-client-locale/client` 的官方 re-export——两者均合法，**无需为了迁移而迁移**。
  - 验收：typecheck 通过；client 产物正常；UI 入口与表现不变。

## 阶段 2：Kernel 削薄 —— DshAgentRuntime 窄 Adapter 收口（行为等价）

> 目的：把散落的 DSH **Agent/Session** 运行时调用收口到一个窄 Adapter；业务模块不再老服务别名/字符串数组探测/手写 `internal/service` 监听。**不改变任何业务逻辑与返回结构；不引入 Role 业务编排。**

- [x] **T-C1** 新建 `lib/agent-runtime.js`（DshAgentRuntime，窄边界）
  - 只含 **Agent/Session/Workspace/Model** 四类：
    - `createAgent({meta, agentOptions, setup})` = `ctx.agents.create(...)`（返回 AgentHandle）
    - `mountPreset(agentCtx, presetId)` = `ctx.agentPresets.mount(agentCtx, presetId)`
    - `inspectSessionCwd(sessionId)` = `ctx.sessionPersistence.inspect(id).meta.cwd`
    - `deliverWake({sessionId, text})` = `ctx.agents.get + agent.followup`（mode=queue 语义不变）
    - `currentModel()` = `ctx.agentDefaultModel.currentSelection`
    - `resolveWorkspace(root)` = `ctx.workspaceRegistry.resolveByPath ?? create`
    - `attachSession(workspace, sessionId)` = `workspace.attachSession`
  - **不含**：`registerRoute`（web 直接 `ctx.webServer`）、`onDomainChange`（快照模块直接订阅 `domain/changed`）、`createRoleSession`（Role 编排留在 seed.js）。
  - 验收：adapter 每个方法都有现状实现映射；无新业务语义；无 `ctx.get('...')` 字符串数组探测。
- [x] **T-C2** `seed.js` 走 Adapter（但保留 Role 业务编排）
  - 改：`agents.create` / `presets.mount` / `workspace` 双键 / `sessionPersistence` → adapter 方法；**pipeline/role/spec 的遍历、会话 id 撞车重试、播种报告等业务编排留在 seed.js**。
  - 验收：播种报告结构不变；pic/233 幂等回归。
- [x] **T-C3** `pipeline.js`/`watchdog.js` 唤醒走 Adapter
  - 改：`wakeUid/wakeTarget/wakeSupervisor` 统一经 adapter.deliverWake；watchdog 巡检逻辑/冷却/触发语义不变。
  - 补：唤醒调用 `agent.followup(message)`（rc.8 无 `mode=queue` 参数——其本身就是普通后续轮次的排队语义，保持现有 follow-up 排队与唤醒语义）。
  - 验收：唤醒消息文本与触发时机不变；测试全绿。
- [x] **T-C4** `web.js` 用 `ctx.inject(['webServer'], ...)` 注册路由
  - 改：`ctx.inject(['webServer'], (webCtx) => { webCtx.effect(() => webCtx.webServer.register(...)) })`；删 `WEB_SERVER_KEYS` 数组探测与 `internal/service` 监听。
  - 目的：WebServer 晚加载时正常注册；无 WebServer 的 headless 环境仍可启动 Kernel；服务卸载时路由随 Fiber 释放。
  - 验收：7 条路由注册正常；headless 环境不崩；插件卸载时路由随 Fiber 释放。
  - 验收措辞说明：**不是"业务模块无 ctx.get"**，而是"无旧服务别名、无字符串数组探测、无手写 internal/service 监听；公开且已注入的稳定服务允许直接使用"。
- [x] **T-C5**（施工纪律）削薄必须真的削薄
  - 若 `lib/agent-runtime.js` 只是增加透传函数、而未删除旧的别名 / 重复服务探测 / 散落的兼容逻辑，则 T-C2/T-C3/T-C4 不得判定"削薄完成"。
  - 验收：新增 Adapter 后，旧 `ctx.get('workspace')`/`ctx.get('httpServer')`/`WEB_SERVER_KEYS`/`internal/service` 监听全部删除（非并存）。

## 阶段 3：接入 rc.8 原生机制（行为不变，实现替换）

- [x] **T-D1** 快照失效统一走 `domain/changed`（服务端缓存失效，浏览器轮询不变）
  - 改：用 `ctx.on('domain/changed')`（过滤 domain=`pipeline_kernel`）做**服务端 snapshot cache 统一失效**；删除各写路径散落的手工 `markDirty()`；浏览器继续现有 1 秒 GET 轮询，30 秒 TTL 继续兜底。
  - 补充：保留一个**独立显式失效入口**（如 `invalidateSnapshot()`），供"非 Domain 文件变化但影响快照"的路径调用（pack 写文件、watchdog 直接改 Agent 状态等不触发 domain/changed 的场景）——不是把 `markDirty` 全删了事。
  - 验收：Domain 写入后服务端 snapshot cache 立即失效；下一次 GET 返回新快照；删各写路径手工 `markDirty()`；**浏览器轮询间隔与数据语义不变**；非 Domain 变更保留独立失效入口。
- [x] **T-D2**（**Deferred — 本轮不迁**）client 挂载 body portal → `ctx.slots.register`
  - **裁定：本轮不迁 conversation.view**。原因：现有 UI 是 body portal（右下角胶囊 + 可钉住右侧面板），conversation.view 是 Session 内 Tab，两者是不同的**入口模型**——迁移必然改变用户操作入口，违反本轮冻结。且 list 槽注册需 `id/order/label` 齐全（如 `{name:'conversation.view', id:'pipeline', order:20, label:() => t('view.pipeline')}`），属新 UI 工程。
  - 本轮完成：仅 client rc.8 依赖对齐 + typecheck + build + 现有 body portal 浏览器冒烟 + 卸载清理。**Slot 迁移进入后续 UI/画布阶段**。
- [x] **T-D3** locale / 会话工作区 API 对齐 rc.8
  - 改：`ctx.locale.register/bind/subscribe/getSnapshot`、`ctx.sessions.list/open`、`ctx.workspaces.pickDirectory` 与 rc.8 类型对齐（签名已实测匹配，此项以 Host/client 契约测试佐证）。
  - 验收：契约覆盖；语言切换重渲染正常。
- [x] **T-D4** watchdog 削薄（仅收口，不改变触发语义）
  - 改：watchdog 巡检继续按原周期/冷却/单飞（ticking guard）/reconcile 顺序运行，仅将"查 Agent idle + deliver"统一走 DshAgentRuntime.deliverWake；**不改事件驱动、不改默认开关、不改消息文本**。
  - 验收：watchdog 测试全绿；行为与现状等价。

## 阶段 4：文档同步

- [x] **T-E1** `重构TODO.md` 收口：标注本轮已完成项；未做项迁到"后续画布阶段"区块（不删历史）。
- [x] **T-E2** `内核接口文档.md`：补 rc.8 基线、DshAgentRuntime（`lib/agent-runtime.js`）窄 Adapter 层说明、domain/changed 使用、peer 依赖要求（工具清单不变）。
- [x] **T-E3** `内核设计文档.md`：补"薄内核：DshAgentRuntime 窄边界"章节；不写画布/图模型。
- [x] **T-E4** README：依赖要求 rc.8；不改安装/使用章节。

---

## 本轮明确排除（后续画布施工再议）

以下项来自 `rc8能力核对与改装方案.md`/外部分析文档的"目标态"，**本轮回合不实施**，仅记录边界、防蔓延：

- [ ] ❌ 无限画布 / Graph 编辑能力 / Node-Edge 数据模型 / 布局
- [ ] ❌ 改变用户操作入口（胶囊、侧栏、/pipeline、工具）
- [ ] ❌ 删除/收缩任意 `pipeline_*` 工具（20 个全保留）
- [ ] ❌ 删除 Registry 表 / `pipeline_register`
- [ ] ❌ 删除 Markdown inbox（任务单文件层）
- [ ] ❌ Domain V2 迁移（`pipeline_kernel_v2` / 迁移器）
- [ ] ❌ 改变 Task/Gate/Route 业务语义（含 route 显式字段化、nodeId/runId/executionRef 新模型）
- [ ] ❌ 执行策略切换（预播种→JIT、one-shot/continuable 重构、supervisor 常驻改边）
- [ ] ❌ 工具面收缩、收件箱 UI 替代、watchdog 事件驱动化（触发语义重构）

> 这些项的"能力已经实测确认存在"（如 subagents/workflow/jobs/schedule 的原生 API）继续保留在核对文档中，供画布阶段直接取用，但**本轮不动插件业务**。

---

## 打卡表（已全部完成，完工复核 64/64）

| 阶段 | 任务 | 状态 | 验收依据（达成） |
|---|---|---|---|
| 阶段 0 | 基线对齐 + 契约测试（Host/Client 两组） | ✅ | `pnpm install --frozen-lockfile` 通过；`test/contract-rc8-host.test.js` 4 项；typecheck/build 通过 |
| 阶段 1 | rc.8 兼容修复 | ✅ | 无 entryFor/双键/无效 peer；41/41 绿 |
| 阶段 2 | DshAgentRuntime 窄收口 | ✅ | `lib/agent-runtime.js` 窄边界 + `test/agent-runtime.test.js` 15 项；无旧服务别名/数组探测/手写 internal/service |
| 阶段 3 | rc.8 原生接入 | ✅ | `domain/changed` 服务端缓存失效 + 浏览器轮询不变；`test/dirty.test.js` 5 项；T-D2 Deferred；`test/web-lifecycle.test.js` 3 项（P1 补强） |
| 阶段 4 | 文档同步 | ✅ | 四份文档更新 + `docs/todolist.md` 状态收口，工具清单不变 |

**完工复核（验收后复验）**：64/64 测试（分文件：agent-runtime 15 / autoroute 11 / contract 4 / dedup 3 / define 4 / deliver 5 / dirty 5 / ledger 4 / pack 1 / state-machine 5 / watchdog 2 / web-lifecycle 3 / workspace 2）；`pnpm frozen`；typecheck/build；产物同步；`npm pack --dry-run`（32 文件 ~88KB）；真实宿主 rc.8 集成（/state 200、pipeline_status、pipeline_reconcile）——见验收结论。

---

## 决策点（验收已裁定）

| # | 决策 | 裁定 |
|---|---|---|
| 1 | 依赖对齐方式 | **插件自身 pnpm 安装 + 锁定 rc.8**（精确 devDependencies + pnpm-lock.yaml + CI `--frozen-lockfile`），**不链接全局宿主**；宿主仅用于最终 Profile 集成验证。`cordis` 用自身 4.x，不写成 rc.8 |
| 2 | client 是否本轮迁 Slot | **不迁**。body portal ↔ conversation.view 是不同入口模型，迁移违反入口冻结；本轮仅做 rc.8 依赖对齐 + typecheck + build + 浏览器冒烟，Slot 迁移进后续 UI/画布阶段（T-D2 Deferred） |
| 3 | Watchdog | **批准"仅收口、不改变触发语义"**：deliverWake 走窄 Agent Runtime；保留周期/冷却/single-flight/reconcile 顺序；不改事件驱动、不改默认开关、不改消息文本 |
| 4 | （本轮不含）执行策略、工具收缩、画布 | 已排除，见上 |

---

*（本清单基于 2026-08-20 宿主 rc.8 实测。任何后续 rc 升级须先复审 `rc8能力核对与改装方案.md` §5 结论再动工。）*
