# DSH rc.8 能力核对与改装方案（pipeline-kernel）

> 基线事实（2026-08-20 更新）：宿主运行时 = `deepseek-harness 0.1.0-rc.8`（`%APPDATA%\npm\node_modules\@deepseek-ai\dsh`，用户已升级，`dsh --version` = 0.1.0-rc.8，web PID 33364）
> **rc.8 与参照文档基线（GitHub rc.8 固定提交）一致**；但与插件本地依赖（rc.6）错位——改装第一件事是对齐
> 参照文档：`DSH原生能力替代与薄内核重构分析-2026-08-20.md`（其假设基线 rc.8，现与宿主一致，可直接逐条核对）
> 本文档为"核对记录 + 改装方案"，只做分析与计划；执行前先确认每项结论。

---

## 0. 基线错位事实（已实测）

| 层 | 位置 | 版本 | 影响 |
|---|---|---|---|
| 宿主运行时 | `%APPDATA%\npm\node_modules\@deepseek-ai\dsh\node_modules\@deepseek-ai\*` | **全部 0.1.0-rc.8**（含 subagent/workflow/jobs/schedule/workspace/presets/skill/persistence/storage-domain/agents/webserver） | 运行时注入的 ctx 服务全是 rc.8 |
| 插件 node_modules | `E:\CODE\hermes\dsh-pipeline-kernel\node_modules\@deepseek-ai\*` | 0.1.0-rc.6 | 测试/构建按 rc.6 语义 |
| 参照文档假设 | GitHub deepseek-harness | 0.1.0-rc.8 | **与宿主一致**，可直接采用文档能力分级 |

**rc.8 破坏性变化（vs rc.7，已实测）**：
- ⚠️ **`dsh-client-ui-slots` 已不存在** → 被 `dsh-client-ui-renderer` 取代（新 client/app、scoped-slots、session-provider 类型）。插件 client 侧引用面（tsdown vendor、`Translate` 类型、LocaleNamespaceMap 合并）**必须改**。
- `dsh-client-ui-primitives` 在 rc.8 宿主内不存在（需确认是否并入 runtime/保留独立发布）。
- host 侧关键服务已确认可用：`webServer`（正式 Service，`register({kind:'exact'|'prefix',...})` 直接返回 disposer）、`storageDomain` 的 `domain/changed` 事件（写后持久化优先再内存再 emit，正式机制）。

**结论：改装基线 = rc.8（宿主实际，与参照文档一致）。**

---

## 1. 插件当前对 DSH API 的使用点（代码实核）

### 1.1 Host 侧（lib/*.js）

| 使用点 | 文件:行 | 当前写法 | 备注 |
|---|---|---|---|
| storageDomain | `index.js:42` | `ctx.storageDomain.open(kernelDomain)` | 已是公开服务，保留 |
| tools 注册 | `index.js:56` | `ctx.tools.register(tool)` | 保留 |
| commands 注册 | `commands.js:18` | `ctx.commands.register({...})` | 保留 |
| effect/interval | `index.js / watchdog.js:130` | `ctx.effect(fn)`、`ctx.interval(tick)` | 保留 |
| workspace 服务 | `seed.js:28` | `ctx.get('workspaceRegistry') ?? ctx.get('workspace')` | ⚠️ 双键猜测；rc.8 只有 `workspaceRegistry`，`workspace` 键不存在 |
| presets 服务 | `seed.js:39` | `ctx.get('agentPresets')` | 键名确认为 `agentPresets`（非 presets），签名匹配 |
| 默认模型 | `seed.js:156` | `ctx.get('agentDefaultModel')?.currentSelection?.()` | ⚠️ 非公开假设，收口到 Adapter 时核对 |
| session 持久化 | `seed.js:198` | `ctx.get('sessionPersistence')` + `persistence.entryFor?.(id)` | ⚠️ **`entryFor` 不存在**，改用 `inspect(id).meta.cwd` |
| agents 读取 | `pipeline.js / watchdog.js / snapshot.js` 多处 | `ctx.agents?.get?.(uid)` | 公开 registry，保留；`entries` 不存在（用 `list()`） |
| agents 创建 | `seed.js:98` | `ctx.agents.create({sessionId, agentOptions, meta, setup})` | 公开，保留但收口到 Adapter |
| presets.mount | `seed.js:101` | `presets.mount(agentCtx, resolved.id)` | rc.8 确认官方方法（唯一合法调用点 = agent factory 的 setup 钩子） |
| followup 唤醒 | `seed.js / pipeline.js / watchdog.js` | `agent.followup(createUserMessage({...}))` | 公开（Agent 对象上的方法），但文档建议改 subagent 投递 |
| webServer | `web.js:32` | `ctx.get('webServer') ?? ctx.get('httpServer')` + `ctx.on('internal/service')` 补注册 | ⚠️ `httpServer` 键不存在（死代码）；`webServer` 可直接 inject |
| 路由注册 | `web.js:47` 等 | `webServer.register({kind:'exact', path, handler})` | rc.8 签名完全匹配（返回 disposer） |
| 日志 | 多处 | `ctx.logger?.warn?.(...)` | 保留 |

### 1.2 Client 侧（src/client/*.tsx → lib/client.js）

| 使用点 | 位置 | 当前写法 | 备注 |
|---|---|---|---|
| locale | `index.tsx` | `ctx.locale.register/bind/subscribe/getSnapshot` | rc.8 签名匹配（register 返回 disposer，bind 返回稳定 t） |
| sessions | `index.tsx` | `ctx.sessions.list.getSnapshot()`、`ctx.sessions.open(id)` | rc.8 签名匹配（list/open 均为公开） |
| workspaces | `index.tsx` | `ctx.workspaces.pickDirectory()` | rc.8 签名匹配 |
| UI 挂载 | `PipelinePanel.tsx` | body portal（`document.body` 注入） | ⚠️ 文档建议迁 `conversation.view` / `shell.overlay` |
| 快照轮询 | `PipelinePanel.tsx` | 1s 轮询 /state + dirty flag | ⚠️ 可升级为 domain/changed 事件驱动 |

---

## 2. rc.8 能力核对（探查结果实测填充）

> 各节由探查子代理基于宿主 rc.8 实际磁盘代码逐字核对，非凭记忆。

### 2.1 host 执行层：agents / subagents / workflow / jobs / schedule（已实核）

| 服务 | 服务键 | 关键结论（rc.8 实测签名） |
|---|---|---|
| Agent | `ctx.agents`（`AgentRegistry extends Service`） | `get/create/resume/list/roots/isOwnedBy` 在注册表；`cancel/whenIdle/followup/steer/inject/status/send/runMaintenance` 在 **Agent 对象**上；`dispose` 在 **AgentHandle** 上；**`entries` 不存在**（用 `list()`）。事件：`agent/created`、`agent/disposed`、`agent/status`、`agent/inbox/inserted/claimed/discarded` 等（scope-filtered）。⚠️ 插件当前 `ctx.agents?.get?.()` 用法正确；但文档 §4.1 列的方法分布需要修正 |
| Subagent | `ctx.subagents`（`SubagentRuntime extends Service`） | `start(name, request): Promise<SubagentRun>`（一次性，返回 `{id, localAgent, result, dispose}`）；`startContinuable(spec): {childId, messageId}`；`followup(parent, childId, content, options)`（= 文档的 sendMessage）；`reportFrom(child, content, options)`（子→父）；`interrupt(targetSessionId, authority)`；`listChildren/listDescendants`；`registerProvider`。**`fork` 是 provider 名不是方法**；无公开 dispose（生命周期自动）。**rc.8 新增 `drainContinuableChildren`**。冷恢复：`persistence.inspect(childId)` → 校验 parent → `agents.resume()` |
| Workflow | `ctx.workflowEngine`（abstract 接缝，实现在 dsh-workflow-worker-thread） | 唯一方法 `start(request): WorkflowRun`；前台阻塞、"call returns when the whole script finishes"；**无 journaling**（仅父会话日志事件，失败即弃）；`WorkflowResult` 永不 reject（completed/cancelled/error）。并发 `maxConcurrentAgents` + 每 run `maxTotalAgents`。事件：`workflow/start/phase/log/agent-start/agent-end/end`（end 不含结果值） |
| Jobs | `ctx.jobs`（abstract `JobRegistry`，实现在 dsh-jobs-local） | **`create` 实为 `start(spec): JobId`**；`read/list/get/wait/kill/onJobDone/onJobsChanged` 存在；owner 按 session id 栅栏隔离；完成通知走 **onJobDone/onJobsChanged 监听器**（非 ctx.emit 事件）；并发上限默认 10/owner；**纯内存、重启全丢**。`JobOutcome = {status: completed\|killed\|failed}` |
| Schedule | **⚠️ 无 `ctx.schedule` 服务** | rc.8 中 schedule 是 **Cordis 函数插件**（每 root agent 装 `ScheduleRuntime` + 工具 `schedule_create/schedule_list/schedule_delete`）；记录作为**会话事件 `schedule/change`**（version 1）持久化，重启重放。三类 kind：`after`/`at`/`every`（`every_seconds ≥ 300`）。编程式调度需自行落 `schedule/change` 会话事件或复用纯函数（`createAfterScheduleRecord` 等）。**对改装结论：Schedule 不能替代跨项目 watchdog，仅可做提醒** |

**执行层对改装方案的关键影响**：
1. agents/subagents 的"驱动"方法在 `Agent`/`AgentHandle` 上，不在服务对象上——Adapter 的 `createSupervisor` 应返回 `handle.agent` + `handle.dispose`；
2. jobs/workflow 均无跨重启恢复——管线 Task 不能映射成它们的事实源（与文档 §4.4/§4.3 结论一致）；
3. schedule 无服务化 API——"提醒"类只能走工具或自落会话事件，**watchdog 的跨项目业务 reconcile 必须自持**，不能迁 schedule。

### 2.2 host 资源层：workspace / presets / skill / session-persistence / storage-domain / webserver（已实核）

| 服务 | 服务键 | 关键结论（rc.8 实测签名） | 插件当前用法差异 |
|---|---|---|---|
| Workspace | `ctx.workspaceRegistry`（`WorkspaceRegistry extends Service`） | `create(path,title?): Promise<Workspace>`（realpath 规范化幂等）、`get(id)`、`list()`、`delete(id)`、`resolveByPath(path)`（只读不创建）、`archiveSession(sessionId)`、`insertBefore`。实体：`path/title/sessionIds`（按 header.cwd 过滤）、`attachSession(sessionId)`（**realpath(cwd) === path 严格校验**）、`detachSession`、`status()`。事件：仅经 storageDomain 写链 → `domain/changed`（domain=workspace） | ① `ctx.get('workspaceRegistry') ?? ctx.get('workspace')` — **第一键✅，`workspace` 键不存在**（死代码可删）② `resolveByPath/create/attachSession` 用法✅ 完全匹配 |
| Agent Presets | `ctx.agentPresets`（`super(ctx,'agentPresets')`，**键名不是 `presets`**） | **`mount(agentCtx, id?): Promise<AgentPreset>` 官方方法✅**（唯一合法调用点 = agent factory 的 `setup(agentCtx)` 钩子，发布前；无 scope 抛错；失败整体回滚）。`resolve(id?)`、`list()`、`copy/remove/recompose/composeFrom`、`defaultId`、trust(system/user) | `ctx.get('agentPresets')` + `presets.mount(agentCtx, resolved.id)` **与官方配方完全一致**，无需改动 |
| Skills | `ctx.skills`（**键名是 `skills` 不是 `skill`**） | `registerProvider/register/list/snapshot/get`；ScopedLayers 近层胜出；`skills/change` 事件（emit）；项目根由 `dsh-skill-filesystem` provider 的 `cwd` 决定 | 插件当前未直接用；若需 skill 清单/监视，走 `ctx.skills.list/snapshot` + `skills/change` |
| Session Persistence | `ctx.sessionPersistence`（abstract，后端 dsh-session-persistence-jsonl） | `inspect(id, signal?): Promise<SessionInspection>`（**只读官方入口，返回 `{meta, events}`——字段是 `meta` 不是 `header`**，`meta.cwd` 即会话 cwd）；`listSnapshots(): [{header, revision}]`（此处字段叫 `header`）；`readFrom/list/locate/create/append/load/prepare`。**`entryFor` 不存在**（同名物是内部 `SessionPreparations` 的 private 方法，插件拿不到） | ⚠️ **seed.js 用 `persistence.entryFor?.(id)` → 恒 undefined → 静默走"无法判定→复用"分支，非 live 撞车残留不可识别。必须改 `inspect(id).meta.cwd`** |
| Storage Domain | `ctx.storageDomain`（facility provide，inject `["storage"]`） | `defineDomain({name,version,global?,tables})` / `domainTable(schema)` / `open(spec): Promise<Domain>`（already-open 拒绝；调用方拥有 close）；`Domain.table(name): KvTable`；`KvTable.put`（**全量替换非 merge**）/`update(key, fn)`（**per-domain 单一 Promise 写链串行**，key 缺失 `missing-key`）/`get/entries/keys/size/delete`。**`domain/changed` 事件确认存在**：`ctx.emit('domain/changed', change)`，写成功后触发（后端耐久→内存→emit）；payload `{domain, table, key, operation:'put'|'deleted', value?}`；订阅 `ctx.on('domain/changed', ...)`（emit 模式）。**SQLite 后端未随装（仅 json）** | 插件现有 `defineDomain({...}) + open + table(...)` **完全成立**；**`ctx.on('domain/changed')` 可取代 markDirty 轮询做写后失效** |
| Web Server | `ctx.webServer`（`super(ctx,'webServer')`，**`httpServer` 键不存在**） | `register({kind:'exact'|'prefix', path, handler}): () => void`（**重复路径 throw；返回 disposer**）；`registerUpgrade/registerFallback/tapIndex`；匹配 exact → prefix 最长 → fallback（未注册 404） | ① `ctx.get('webServer') ?? ctx.get('httpServer')` — **第二键永远 undefined（死代码）** ② `register({kind:'exact',...})` **完全匹配**；`ctx.effect(() => register(...))` 中 disposer 被 effect 当 teardown 消费 ✅ ③ `ctx.on('internal/service', name => ...)` 补注册**成立**（cordis 4.0.1 provide 路径触发） |

### 2.3 client 层：slots / modules / locale / 运行时（已实核，rc.8 新 UI 报告）

**重大修正：`dsh-client-ui-slots` 并非物理消失——它是全树 .d.ts 的类型/内核源（devDep ^0.1.0-rc.8），实现被内联进 `dsh-web-frontend` 整包 bundle。插件作者不要安装它；实际注册入口是 `ctx.slots`（dsh-client-runtime 的 SlotRegistry）。**

| 服务 | 关键结论（rc.8 实测签名） | 插件当前用法差异 |
|---|---|---|
| `ctx.slots`（SlotRegistry，来自 dsh-client-runtime） | **`register(options, component) -> disposer`**；options：`name`（目标 slot）、`kind`（list/keyed/chain 需 id/key/select）、`order/label(可函数)`、`children`（子 slot 声明）、`store`、`locale`、`inject((sessionId?,actions?) => face)`、`priority`；另有 `inject(key,cb)/install(renderer)/installLocale(face)/renderSlot('root',owner)`（ctx 级唯一渲染入口，key 必须 root）/pruneStoreScope/subscribe/getVersion/onEntryError | 插件 client 当前**未用 ctx.slots**（body portal 方式）。改装后 ① 移除 `tsdown.config.ts` 的 `@deepseek-ai/dsh-client-ui-slots` external（无需装包）② `src/client/index.tsx` 改为 `ctx.slots.register({name:'conversation.view', kind:'list', ...}, Component)` |
| Slot 座位全清单（确认存在） | **root（勿注册）**、`shell.overlay`（全局浮层）、`sidebar.footer.action`、`sidebar.brand.mark/name`、`sidebar.workspaces/settings`、`conversation.session(.header/.header.actions/.header.utilities)`、**`conversation.view`（list/session，owner ConvViewOwnerProps={inspect?, onInspectDone?}）**、`conversation.chat.node/commandview/turnTail/assistant-actions`、`conversation.message.images`、`conversation.details.tool`、`conversation.composer/composer.bar/composer.dock`、`conversation.input.dock/left/right/plan/model/attachments/overlay`、`conversation.hero.workspace/brand.mark/agentPreset`、`tool.call.toolview`(keyed)、`tool.view.cordis`(keyed,'self')、settings 相关（general.item/plugins.tab/plugin.item/trigger…）、`conversation.hero.workspace.directoryFlow`、`sidebar.workspaces.directoryFlow` | body portal → `conversation.view`（list）+ `shell.overlay`（第二阶段全屏画布）|
| dsh-client-locale | `ctx.locale.register(ns, dictsByLocale)` 或 `(ns, locale, dict)` → disposer；`bind(ns)` → 稳定 t；`getSnapshot/subscribe`（LocaleFace，经 slots.installLocale 安装）；setLocale 持久化到 settingsScope + emit `locale/change`；revision 单调 | 插件当前 `ctx.locale.register('pipeline', {zh,en})` + bind/subscribe/getSnapshot **匹配**；需把类型来源从 `@deepseek-ai/dsh-client-ui-slots` 改到实际类型包 |
| dsh-client-runtime | `ctx.sessions.list(快照源)/open/clear/fork/search/provide`；`ctx.workspaces.list/pickDirectory()/listDirectory/openPath/connectWorkspace/create` | 插件当前 `ctx.sessions.list.getSnapshot()` + `sessions.open(id)` + `workspaces.pickDirectory()` **匹配** |
| dsh-client-modules | browser 半区：`dsh.client={platform:'web',inject,external,immediately}` + `exports['./client']`；bundle = `window.__ModuleLoader__.load({id, factory})`；`window.__DSH_BOOT__ = {rev, entries:[{id, url:'/plugins/<id>/client.js?rev=...'}]}`；`ctx.modules`(import/prefetch/invalidate) | 插件 bundle 协议（tsdown banner/footer）**已匹配**，保留 |

**client 层改装要点**：
1. 类型来源修正：`Translate` / `LocaleNamespaceMap` 的类型从 `@deepseek-ai/dsh-client-ui-slots` 迁到实际类型载体（ui-renderer 或 runtime 的 client types——按 109 个 .d.ts 引用确认实际声明位置）；
2. `tsdown.config.ts` PLATFORM_MODULES：删 `dsh-client-ui-slots`（不装包）、删 `dsh-client-ui-primitives`/`dsh-client-web-react`/`dsh-client-schema-form`（rc.8 宿主无这些包，确认是否仍需 external——若 client 代码不 import 它们则直接从列表移除）；
3. 注册方式：`ctx.slots.register({name:'conversation.view', kind:'list'}, PanelComponent)`，配合 `ctx.locale`、`ctx.sessions`、`ctx.workspaces` 现有注入。

---

## 2.4 插件当前用法不匹配点清单（rc.8 基线，改装实际改动面）

| # | 插件位置 | 当前写法 | rc.8 结论 | 处置 |
|---|---|---|---|---|
| 1 | `seed.js` sessionCwdMatches | `persistence.entryFor?.(id)` → `.header.cwd` | **`entryFor` 不存在** → 恒 undefined → 静默走"无法判定→复用"，撞车残留不可识别 | 改 `await sessionPersistence.inspect(id)` 取 **`result.meta.cwd`**（字段是 `meta` 不是 `header`）或 `listSnapshots().header.cwd` |
| 2 | `seed.js:28` | `ctx.get('workspaceRegistry') ?? ctx.get('workspace')` | **`workspace` 键不存在**（死代码） | 只留 `workspaceRegistry` |
| 3 | `seed.js` agents.create + presets.mount | `ctx.agents.create({...})` → `presets.mount(agentCtx, id)` | **完全匹配**（官方配方） | 保留，收口到 Adapter |
| 4 | `web.js:32` | `ctx.get('webServer') ?? ctx.get('httpServer')` + `internal/service` 补注册 | **`httpServer` 键不存在**（死代码）；`internal/service` 补注册成立（cordis 4.0.1） | 只留 `webServer`；补注册保留但可删（rc.8 webServer 已确认 inject 可用） |
| 5 | `web.js` 路由注册 | `webServer.register({kind:'exact',path,handler})` | **完全匹配**（返回 disposer，effect 消费正确） | 保留 |
| 6 | `src/client/*` body portal | 直接 `document.body` 注入侧栏 | **rec.8 应改用 `ctx.slots.register`** | 迁 `conversation.view`（list）+ `shell.overlay`（第二阶段） |
| 7 | `tsdown.config.ts` PLATFORM_MODULES | external 含 `dsh-client-ui-slots` / `dsh-client-web-react` / `dsh-client-ui-primitives` / `dsh-client-schema-form` | rc.8 宿主**无** `dsh-client-web-react`/`primitives`/`schema-form`；`ui-slots` 类型仍被引用但实现已内联 → 不装包 | 列表精简：删不存在的 3 项；`ui-slots` 类型迁移到实际承载包 |
| 8 | `src/client/i18n.ts` / `PipelinePanel.tsx` | `declare module '@deepseek-ai/dsh-client-ui-slots'` / `import type { Translate } from '@deepseek-ai/dsh-client-ui-slots'` | 类型源是 ui-slots 的 .d.ts（仍在全树引用） | 确认类型实际声明位置（runtime/渲染器），改 import 源；或本地 declare 兜底 |
| 9 | `package.json` peer deps | `@deepseek-ai/*` 声明 `^0.0.1-rc.1`（client）与 rc.6（lockfile 实际） | 宿主全 rc.8；`dsh-client-ui-slots`/primitives/web-react/schema-form 是 rc.8 宿主**没有**的包 | 统一 `^0.1.0-rc.8`；移除宿主没有的 client peer；`dsh-client-ui-renderer`/`dsh-client-locale`/`dsh-client-runtime` 等按宿主实际保留 |
| 10 | `snapshot.js` markDirty 轮询 | 1s 轮询 /state + dirty flag | `domain/changed` 是正式事件（写后触发，payload 含 domain/table/key/operation） | 阶段 B 改为 `ctx.on('domain/changed')` 失效，保留 GET 轮询回退；`domain` 名现在是 `pipeline_kernel`（可加 filter） |

---

## 3. 改装方案（分阶段，按探查结果修订）

### 3.0 依赖对齐（前置，必须先做）

- [ ] 插件 `package.json` 全部 `@deepseek-ai/*` peer 与 dev 依赖对齐到 **`0.1.0-rc.8`**（当前 rc.6 与宿主错位；client peer 从 `^0.0.1-rc.1` → `^0.1.0-rc.8`）
- [ ] 移除宿主 rc.8 不存在的 client peer：`dsh-client-ui-slots`（不装包，类型走全树 .d.ts）、`dsh-client-ui-primitives`、`dsh-client-web-react`、`dsh-client-schema-form`；按宿主实际保留 `dsh-client-locale` / `dsh-client-runtime` / `dsh-client-ui-conversation` 等
- [ ] 插件 node_modules 重新安装/链接到宿主依赖树（link: 到宿主安装或 pnpm 从宿主解析），测试与运行同站
- [ ] 建立"契约测试"：直接对宿主服务冒烟（`ctx.agents.get`、`ctx.slots.register`、`ctx.on('domain/changed')`、`sessionPersistence.inspect`），rc 升级时第一时间暴露漂移
- [ ] `scripts/ci.sh` 的依赖缺失降级逻辑改为"对齐后必须全量"（不再接受 rc.6 跑测试）

### 3.1 阶段 A：DshRuntimeAdapter 收口（适配边界）

把插件对 DSH Runtime 的散落调用全部收口到一个 `lib/runtime-adapter.js`，业务模块不再直接碰 `ctx.agents/presets/sessionPersistence/webServer` 内部假设。

Adapter 接口草案（来自分析文档 §7，按 rc.8 实测签名修正）：

```js
adapter = {
  createSupervisor({ workspaceId, presetId }),        // 保留唯一常驻入口；返回 AgentHandle{agent, dispose}
  runOneShot({ task, roleBinding }),                  // ctx.subagents.start(name, request)
  startContinuable({ task, roleBinding }),            // ctx.subagents.startContinuable(spec) → {childId, messageId}
  continueWorker({ parent, childId, content }),       // ctx.subagents.followup(parent, childId, content, opts)
  reportFrom(child, content, options),                // 子→父 ctx.subagents.reportFrom
  interruptExecution(executionRef),                   // ctx.subagents.interrupt / agents.cancel
  inspectExecution(executionRef),                     // sessionPersistence.inspect(id).meta.cwd（替代 entryFor）
  scheduleReminder(...),                              // ⚠️ rc.8 无 ctx.schedule 服务——只能走 schedule_create 工具或自落 session 事件
  onDomainChange(handler),                            // ctx.on('domain/changed', ...)
  registerRoute({ path, handler }),                   // ctx.webServer.register（直接 inject，去双键）
}
```

改造点：`seed.js`（agents.create + presets.mount + workspace 双键）、`web.js`（webServer 双键 + internal/service 补注册 + 重复 JSON 样板）、`pipeline.js`（wakeUid/wakeTarget/wakeSupervisor 统一走 adapter.deliver）、`snapshot.js`（domain/changed 驱动）。

验收：业务模块无 `ctx.get('xxx')` 探测式调用；升级 rc 时只改 adapter 一个文件。

### 3.2 阶段 B：UI 原生化（Slot 接入）

- [ ] body portal → `conversation.view`（先做 Tab）
- [ ] 增加 `shell.overlay` 全屏画布入口（第二阶段）
- [ ] host 直接 inject `webServer`（去掉双键 + internal/service）
- [ ] snapshot revision 改由 `domain/changed` 驱动（保留 GET/轮询回退）

验收：插件卸载后 Slot/Route/订阅/UI store 全部随 Fiber 释放。

### 3.3 阶段 C：显式路由与任务模型

- [ ] `pipeline_done` 的 route 从自由文本改为工具参数显式传递（删除 route: 正则解析）
- [ ] Task 增加 `nodeId/runId/executionRef` 显式字段（渐变加可空字段，不 bump version）
- [ ] 保留 routeKey/successorTaskId 幂等机制（已有），叠加显式图边推导

### 3.4 阶段 D：执行策略切换（拍板后做）

- [ ] supervisor 常驻（保留一条入口）+ 业务角色默认 continuable + 节点内并行候选 one-shot/Workflow
- [ ] 删除 Worker 预播种，Task 在 ready 时经 adapter 按需起执行
- [ ] registry 表退役（等 UI 画布能替代"打开会话/查看状态"后才删）

### 3.5 阶段 E：收尾清理（画布主界面落地后）

- [ ] 工具面 18→5~7（Canvas 成为主界面后删 CRUD 工具）
- [ ] 删除 Markdown 收件箱（UI Task 卡能展示任务内容后）
- [ ] 删除 watchdog 的 Agent idle 扫描（保留业务 reconcile 兜底）
- [ ] 评估 V2 Domain（只在出现真实 schema 断裂时新建 `pipeline_kernel_v2` + 显式迁移）

---

## 4. 兼容性风险与对策

| 风险 | 对策 |
|---|---|
| RC API 漂移 | Adapter 收口 + 契约测试 + 基线锁 rc.8（宿主实际） |
| domain/changed 事件 payload 结构 | 已实测确认（domain/table/key/operation）；契约测试写死 |
| client 类型包漂移（ui-slots 内联化） | 类型走全树 .d.ts，不装 ui-slots 包；改 import 源并加本地 declare 兜底 |
| SSE 在 Desktop/Electron Carrier 兼容 | 未验证前保留低频轮询回退 |
| 常驻→JIT 的 Prompt 上下文差异 | 业务角色用 continuable（subagents.startContinuable），不轻易 one-shot |
| 存量数据（pic/233） | 渐变加字段，不新建 Domain |

---

## 5. 探查方法学与来源（可复现）

- **宿主路径**：`C:\Users\Max\AppData\Roaming\npm\node_modules\@deepseek-ai\dsh\node_modules\@deepseek-ai\`
- **方法**：每个包读完 `package.json`（exports/main）→ 入口 `lib/index.js` → `lib/types/*.d.ts`；对 `domain/changed` 追踪全部 emit 调用点；对插件用法逐条对照磁盘代码。全部结论基于 **rc.8 实际编译产物逐字核对**，非凭记忆。
- **探查子代理**：host 执行层（agents/subagents/workflow/jobs/schedule）、host 资源层（workspace/presets/skill/session-persistence/storage-domain/webserver）、client 新 UI 层（slots/modules/locale/runtime）——三份独立探查报告已收入本核对表。
- **关键实证结论（防回归）**：
  1. `ctx.schedule` **不存在**——schedule 是函数插件（每 root agent 装 ScheduleRuntime + 3 工具），编程式调度只能走工具或自落 `schedule/change` 会话事件；
  2. `subagents.fork` 是 **provider 名**不是方法（对应 `dsh-subagent-fork-in-process`），投递是 `followup(parent, childId, content, options)`；
  3. `jobs.create` 实为 **`start(spec)`**，完成通知走 `onJobDone/onJobsChanged` 监听器（非 ctx.emit），纯内存重启丢失；
  4. `sessionPersistence.entryFor` **不存在**——只读检查用 `inspect(id)` 的 `meta.cwd`；
  5. `dsh-client-ui-slots` 实现被内联进 dsh-web-frontend bundle，注册入口统一是 **`ctx.slots`**（dsh-client-runtime 的 SlotRegistry），插件不装该包；
  6. `domain/changed` 是 storage-domain 的正式机制——写后（后端耐久→内存→emit）触发，payload `{domain, table, key, operation:'put'|'deleted', value?}`，订阅 `ctx.on('domain/changed', fn)`；
  7. `webServer` 是正式 Service（`register` 返回 disposer，重复路径 throw），`httpServer` 键不存在。

---

## 6. 待办与决策点

- [ ] **基线确认**：宿主 `0.1.0-rc.8` ↔ 插件 peer 对齐（§3.0）——改装前必须先做
- [ ] **契约测试**：新建 `test/contract-rc8.test.js`，冒烟 agents/subagents/storageDomain/domain-changed/presets.mount/inspect
- [ ] **决策**：执行策略默认值（supervisor 常驻 + 业务角色 continuable + 并行候选 one-shot/Workflow）——文档 §3.4
- [ ] **决策**：UI 先做 `conversation.view` Tab 还是直接 `shell.overlay` 全屏画布——文档 §3.2
- [ ] **执行顺序**：阶段 A（Adapter 收口）→ 阶段 B（UI Slot + domain/changed）→ 阶段 C（显式路由）→ 阶段 D（执行策略）→ 阶段 E（清理）
- [ ] 本核对表随 rc 升级复审——重点是 §5 的 7 条实证结论是否仍成立