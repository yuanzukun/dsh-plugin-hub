# DSH Pipeline Kernel 重构 TODO

按《审查结论和重构建议.md》的阶段顺序执行；本轮（2026-08-20）并行执行 `docs/todolist.md` 的"rc.8 削薄工程"（阶段五）。已完成项保留验收依据；未完成项不以“代码已改动”视为完成。

## 阶段一：任务链与多管线边界

- [x] unknown route 进入 `route:failed`，保留 `routing:pending` 并通知 Supervisor。
- [x] 引入 `routeKey`，在创建后继前做锁内幂等检查。
- [x] `reconcileZombies` 识别已完成/已取消后继，并只收敛父任务标记。
- [x] 增加并发 reconcile 测试，验证同一 routeKey 最多一个后继。
- [x] watchdog 按 pipeline 独立统计静止状态和报告冷却。
- [x] watchdog tick 增加重入保护并补测试。
- [x] 统一 workspace、inbox、artifact、pack 路径解析和边界校验。
- [x] `fromPack` 读取失败改为显式错误，不再静默使用默认定义。

## 阶段二：一致性与恢复

- [x] `pipeline_strike` 使用原子 `update`，避免旧快照覆盖并发更新。
- [x] `definePipeline` 的首次创建/更新纳入进程锁。
- [x] ledger 增加 `pipelineId`；带管线归属的记录使用管线前缀 key，避免同名覆盖。
- [x] pack 按 pipeline 过滤任务账本，并补充双管线隔离测试。
- [x] 所有 purge 删除操作显式 `await`，并调整删除顺序使中断后可重试。
- [x] 任务单写入采用临时文件后替换正式文件，避免半截投影文件。
- [ ] archive/purge 使用宿主事务或正式可恢复状态机（当前仅做到可重试顺序）。
- [ ] 增加 projection repair 状态和失败重试队列。
- [ ] 补齐真实 storageDomain smoke test。

## 阶段三：系统级测试与工程化

- [x] fake domain：状态机、路由、watchdog、workspace、ledger、pack 基础测试。
- [x] 多管线 watchdog / workspace / pack 隔离测试。
- [ ] 双 define、strike 与 route 交错的真实并发测试。
- [ ] crash recovery / 文件投影失败测试。
- [ ] Cordis apply/effect、agent 生命周期和 HTTP 端点集成测试。
- [x] CI 安装并锁定私有 peer dependencies，避免依赖缺失造成误判。（rc.8 已上公共 npm，T-A4 改 frozen lockfile 全量门禁，见 `docs/todolist.md` 阶段 0）

## 阶段四：延后重构

- [ ] 在阶段一至三稳定后，再拆分 `pipeline.js` 的 routing、lifecycle、projection 子模块。
- [ ] 将自由文本 route 逐步迁移为结构化 route 字段。
- [ ] 生成并校验 host/client 共享类型。

## 阶段五：rc.8 削薄工程（本轮，2026-08-20）

> 范围与验收详见 `docs/todolist.md`（已验收通过）。本轮只做削薄 + rc.8 接入；不施工画布/工具收缩/执行策略切换。

- [x] T-A1/A2 依赖对齐 rc.8（插件自身 pnpm + frozen lockfile；cordis 4.x）＋契约测试拆分 Host/Client。
- [x] T-A3 `test/contract-rc8-host.test.js`（storageDomain/llm/tools 契约 + 防误引入宿主服务包）。
- [x] T-A4 CI 全量门禁（scripts/ci.sh 必装必全量 + GitHub Actions frozen）。
- [x] T-B1 seed `sessionCwdMatches` 用 `inspect(id).meta.cwd`（rc.8 无 entryFor）。
- [x] T-B2 删死代码双键（seed `workspace` / web `httpServer`）。
- [x] T-B3/B4 client peer/tsdown 对齐 rc.8；保留 `dsh-client-ui-slots` augmentation。
- [x] T-C1~C5 `lib/agent-runtime.js` 窄 AgentRuntime 收口（createAgent/mountPreset/inspectSessionCwd/deliverWake/currentModel/resolveWorkspace/attachSession）；web 用 `ctx.inject(['webServer'])`。
- [x] T-D1 `domain/changed` 统一快照失效，删散落 `markDirty()`，保留 `invalidateSnapshot()` 独立入口。
- [x] T-D3 locale/会话工作区 API 由契约 + client typecheck/build 佐证。
- [x] T-D2（Deferred）conversation.view Slot 迁移——本轮不迁，留后续 UI/画布阶段。
- [x] T-E1~E4 文档同步（本文件、`内核接口文档.md`、`内核设计文档.md`、README）。

**后续（不在本轮）**：Canvas/Graph/Node-Edge、工具收缩、执行策略切换、Slot 迁移、registry/inbox 退役、V2 Domain——见 `docs/todolist.md` 排除清单。

