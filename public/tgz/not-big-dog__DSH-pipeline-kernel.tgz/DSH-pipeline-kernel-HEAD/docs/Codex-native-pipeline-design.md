# Codex-native Pipeline Design

## 1. 目标

本设计只覆盖四个需求：

1. 多任务排布；
2. 任务状态显示；
3. 一键打包 Skill；
4. 一键播种 Skill、创建并打开对应角色会话；
5. 多 Agent 协作期间的任务稳定性。

核心原则：

> Codex 负责 Agent 的执行、并行和会话；Pipeline Layer 只负责持久化任务状态、产物边界和恢复。

不再实现一个完整的 Agent Runtime，不自行维护常驻 Agent、消息队列和复杂唤醒循环。

---

## 2. 总体架构

```text
                         Codex Project
                              │
                    AGENTS.md + Skill Packs
                              │
                 ┌────────────┴────────────┐
                 │                         │
          Supervisor Chat             Subagent Chats
                 │              researcher / producer / reviewer
                 │                         │
                 └────────────┬────────────┘
                              │
                  Pipeline Control Plane
                 task state / leases / events
                              │
             artifacts / reviews / pack manifests
```

Codex 原生能力负责：

- 并行 subagent；
- 角色指令和模型配置；
- 独立 chat/thread；
- Goal 长任务；
- Project 文件上下文；
- 代码场景下的 worktree 隔离。

最小自定义层负责：

- Task 状态机；
- 任务 ownership 和 lease；
- 事件记录；
- 产物引用；
- Pack/Seed manifest；
- 状态快照显示。

---

## 3. 项目目录

```text
project/
├── AGENTS.md
├── skills/
│   └── <pack-id>/
│       ├── SKILL.md
│       ├── agents/
│       ├── templates/
│       └── manifest.json
├── .pipeline/
│   ├── pipeline.yaml
│   ├── runs/
│   │   └── <run-id>/
│   │       ├── manifest.json
│   │       ├── tasks.json
│   │       ├── events.jsonl
│   │       ├── sessions.json
│   │       └── status.md
│   └── artifacts/
└── output/
```

建议把 `.pipeline/runs/<run-id>` 视为一个生产批次。不同批次之间不共享可变状态。

---

## 4. 多任务排布

### 4.1 Pipeline manifest

```yaml
id: image-campaign
version: 1
roles:
  supervisor:
    skill: pipeline-supervisor
  researcher:
    skill: research-worker
  producer:
    skill: image-producer
  reviewer:
    skill: artifact-reviewer
stages:
  - id: research
    role: researcher
    next: planning
  - id: planning
    role: supervisor
    next: production
  - id: production
    role: producer
    next: review
  - id: review
    role: reviewer
    gate: true
```

### 4.2 Task 状态

```text
queued
  → assigned
  → running
  → awaiting_review
  → approved
  → completed

running → failed → retrying → running
running → blocked
任意非终态 → cancelled
```

Task 最小字段：

```json
{
  "id": "T-001",
  "runId": "run-2026-001",
  "stage": "production",
  "role": "producer",
  "status": "running",
  "ownerSessionId": "thread-123",
  "attempt": 1,
  "version": 3,
  "leaseUntil": 1780000000000,
  "inputRefs": ["tasks/T-001-input.json"],
  "outputRefs": [],
  "updatedAt": 1780000000000
}
```

### 4.3 排布策略

Supervisor 将任务分成两类：

- 可并行：彼此没有写冲突、没有前置依赖的任务，交给多个 subagent；
- 必须串行：共享同一产物、需要前一阶段结果或需要 Gate 的任务，按 stage 推进。

不要让多个 Agent 同时写同一个正式产物。并行任务使用独立目录，最后由 Integrator 或 Supervisor 合并。

---

## 5. 任务状态显示

### MVP

每次状态变更同时更新：

- `tasks.json`：当前状态快照；
- `events.jsonl`：追加式审计记录；
- `status.md`：给人阅读的状态板。

`status.md` 示例：

```text
Pipeline: image-campaign
Run: run-2026-001

queued          2
running         1
awaiting_review 1
completed       4
failed          0

T-001 researcher   completed
T-002 producer     running       owner=thread-123
T-003 reviewer     awaiting_review
```

### UI 版本

如果需要真正的可视化面板，只做一个只读状态面板：

```text
GET /pipeline/state?runId=...
```

面板只读取 `tasks.json` 和 `events.jsonl`，不直接修改任务。所有状态改变必须经过统一的 Task API 或 MCP tool。

这样可以保留你当前项目中的快照/面板经验，但不再让 UI 参与 Agent 调度。

---

## 6. 一键打包 Skill

### Pack 输入

```text
pipeline.yaml
AGENTS.md 角色片段
各角色 SKILL.md
templates/
examples/
review rules
```

### Pack 输出

```text
<pack-id>-v<version>.zip
├── manifest.json
├── AGENTS.md
├── skills/
├── agents/
├── templates/
└── README.md
```

`manifest.json` 至少包含：

```json
{
  "format": "codex-pipeline-pack-v1",
  "id": "image-campaign",
  "version": 1,
  "roles": ["supervisor", "researcher", "producer", "reviewer"],
  "pipeline": "pipeline.yaml",
  "checksums": {},
  "generatedAt": "2026-08-18T00:00:00.000Z"
}
```

Pack 必须是可验证、可重复生成的。打包时不包含：

- 旧会话 ID；
- 旧任务状态；
- 临时文件；
- 个人凭据；
- 运行时产物，除非显式声明为模板。

---

## 7. 一键播种 Skill 和打开会话

### Seed 流程

```text
选择 Pack
  → 校验 manifest/checksum
  → 安装 skills/<pack-id>
  → 创建 run-id
  → 初始化任务板
  → 生成角色会话启动 prompt
  → 创建 Supervisor / Worker 会话
  → 写入 sessions.json
  → 打开 Supervisor 会话
```

`sessions.json`：

```json
{
  "runId": "run-2026-001",
  "sessions": {
    "supervisor": { "threadId": "thread-sup" },
    "researcher": { "threadId": "thread-research" },
    "producer": { "threadId": "thread-producer" },
    "reviewer": { "threadId": "thread-review" }
  }
}
```

每个角色会话的启动 prompt 只包含：

- 角色身份；
- `runId`；
- 可访问目录；
- 当前分配的 Task；
- 完成协议；
- 禁止修改的目录。

角色不依赖前一个 chat 的隐式上下文，而是通过任务文件和产物引用协作。

### 重要边界

Codex 原生 subagent 可以很好地完成并行工作和结果汇总，但“永久注册一个会话、随时向它投递新任务”不应作为稳定基础契约。`sessions.json` 只保存当前运行的会话映射；如果会话失效，Supervisor 应重新分配 Task，而不是假设原会话永远存在。

---

## 8. 多 Agent 协作稳定性

### 8.1 单一状态写入口

Agent 不直接修改 `tasks.json`。它们只能调用：

```text
task_claim(taskId, expectedVersion)
task_heartbeat(taskId, expectedVersion)
task_complete(taskId, outputRefs, expectedVersion)
task_fail(taskId, error, expectedVersion)
task_request_review(taskId, outputRefs, expectedVersion)
```

状态更新使用 `expectedVersion` 做 CAS，失败时重新读取任务，而不是覆盖别人刚写入的状态。

### 8.2 Lease 防止僵尸任务

`running` 任务必须带 `leaseUntil`：

- Agent 正常工作时定期 heartbeat；
- lease 过期后，Supervisor 将任务标记为 `stale`；
- `stale` 任务可以重试，但必须增加 `attempt`；
- 旧 Agent 迟到提交时，因 version/lease 不匹配而被拒绝。

### 8.3 事件与快照分离

每次状态变化先追加事件，再更新快照：

```text
task_claimed
task_heartbeat
task_completed
task_review_requested
task_failed
```

快照损坏时，可以从 `events.jsonl` 重建。这样比只维护一个可变 JSON 文件更容易恢复。

### 8.4 产物不可变

不要让 Reviewer 覆盖 Producer 的原文件：

```text
artifacts/T-002/v1/output.png
reviews/T-002/review-v1.json
artifacts/T-002/v2/output.png
```

Gate 只引用某个产物版本。返工生成新版本，而不是覆盖旧版本。

### 8.5 代码任务使用 worktree

如果角色会修改代码：

- 每个并行实现 Agent 使用独立 worktree；
- Reviewer 只读目标分支或提交；
- Integrator 负责合并；
- 不允许两个 Agent 同时修改同一工作目录。

对于图片、文档、素材生产，则使用角色专属目录即可。

---

## 9. 最小实现范围

### 第一版不写

- Agent 常驻进程；
- 自己的消息队列；
- 自己的 session heartbeat；
- 复杂 watchdog；
- 完整数据库；
- 自定义 Agent Runtime。

### 第一版只写

```text
1. pipeline.yaml 解析
2. tasks.json + events.jsonl
3. task_claim/task_complete/task_fail
4. status.md 生成
5. pack/seed 命令
6. sessions.json 记录
7. 基础版本号和 lease
```

如果 Codex 原生工具已经能完成 Agent 委派，那么这部分可以先实现为一个 Skill 或 MCP server，而不是继续扩展现有 Kernel 的 Agent 管理代码。

---

## 10. 从现有 DSH Kernel 迁移

### 保留

- Task 状态机；
- `routeKey` / 幂等思想；
- Ledger 和产物引用；
- Pack/Seed 概念；
- reconcile 思路；
- 路径边界和临时文件写入。

### 删除或弱化

- registry 中的常驻 Agent 假设；
- watchdog 对 Agent 的主动唤醒；
- pipeline.js 中的会话投递逻辑；
- 复杂的 Supervisor session 管理；
- 为 Agent Runtime 服务的底层抽象。

### 替换

```text
DSH wakeTarget       → Codex subagent delegation / session prompt
DSH registry         → sessions.json（运行时映射）
DSH deploy/seed      → Skill Pack install + session bootstrap
DSH watchdog         → lease expiry + Supervisor reconcile
DSH web dashboard    → status.md，后续再加只读面板
```

---

## 11. 最终判断

这个需求不需要继续维护一个完整的 DSH Agent Kernel。

最合适的形态是：

```text
Codex-native execution
+
small persistent pipeline control plane
+
immutable artifacts and versioned review
```

这样可以把大部分 Agent 编排代码交给 Codex，同时保留生产系统真正需要的任务稳定性和可恢复性。

参考：

- [Codex Subagents](https://learn.chatgpt.com/docs/agent-configuration/subagents)
- [Codex Long-running work](https://learn.chatgpt.com/docs/long-running-work)
- [Codex Projects and chats](https://learn.chatgpt.com/docs/projects)

