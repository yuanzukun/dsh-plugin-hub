---
name: pipeline-comm-sync
description: 管线会话间通讯与信息同步协议——任务板是唯一事实源、收件箱任务单是输入、done 必带 route、台账由管理维护、进度 = 台账清单完成度。所有管线角色会话（supervisor/designer/prompter/reviewer…）都应遵守本协议。
---

# pipeline-comm-sync：会话间通讯与信息同步协议

> 适用：管线内所有角色会话。本 skill 是**会话间通讯的约定**，不依赖直连对话——投递语义上移，一切以内核域表为准。

## 一、核心原则

1. **任务板是唯一事实源**：会话间通讯 = 任务板上的任务。不搞会话间直连对话，消息丢失不丢任务。
2. **收件箱任务单是输入**：任务投递后，在对应角色收件箱出现任务单文件（`exchange/收件箱/<角色>/任务单-<任务id>.md`），以此为准开始工作。
3. **完成必带 route 标记**：`pipeline_done` 的 result 必须携带路由信息，否则链路断裂。
4. **台账由管理维护**：台账（ledger）是进度档案，由管理AI/主管AI登记与更新。
5. **进度 = 台账清单完成度**：管理建台账时登记产物清单（每项一条），每过审交付一条标 `done`，进度即 done/总数。

## 二、角色行为约定

### 管理AI/主管（supervisor）
- 对接人工：收集需求、确认打包、处理例外/门控/归档。
- 发布设计：`pipeline_push` 分发任务，带 `task:<编号>` 链标签。
- 管理进度：`pipeline_ledger_write` 维护台账（产物清单逐条登记，交付一条标 done）。
- 门控落账：`/pipeline gate <gateId> <pass|fail> [taskId]`。

### 执行角色（designer/prompter/reviewer…）
- 看到任务单 → `pipeline_claim` 认领 → 产出 → `pipeline_done`。
- **done 的 result 格式**：
  - 前进：`done route:<角色|UID> 产物:<路径>`
  - 返工：`rework route:<角色|UID> <原因>`
  - 推荐 `route:session-xxx`（UID 直连无歧义），也可角色名（注册表解析，兼容简称 design→designer）。
- 审查角色：判定 `done`（通过）或 `rework`（退回），必须写清原因。

## 三、路由约定（内核自动执行）

- `done route:<目标>` → 内核自动投下一环（目标无门控时）。
- `rework route:<目标>` → 内核自动投返工（attempt+1）；达三振自动 blocked + 升级主管。
- 门控环节（gates.after=角色）→ 内核唤醒主管等人 `/pipeline gate`。
- `done` 无 route / fluke / 异常 → 唤醒主管人工处理。

## 四、台账约定

- 类型建议：`design`（设计）/ `prompt`（提示词）/ `generate`（产物）/ `review`（审查）/ `gate`（门控）/ `pack`（打包）/ `archive`（归档）/ `other`。
- 产物清单：管理登记 N 条（如每张图一条），`status=pending`；每过审交付一条标 `done`。
- 同 type+name 再次登记 = 更新状态 + 自动追加变更记录（history），不重复建条目。
- 可带 `taskId` 关联任务（打包检查/产物核对用）。

## 五、打包约定

- 项目完成后，向管理AI提出"打包"，管理AI**重复确认命令**后执行 `pipeline_pack`。
- 打包产出：状态检查报告 + 绿色可复用全节点管线文档（JSON + MD），落 `<artifactRoot>/packs/`，台账登记 `type=pack`。
- 复用：新管线可从打包文档一键恢复定义与播种。

