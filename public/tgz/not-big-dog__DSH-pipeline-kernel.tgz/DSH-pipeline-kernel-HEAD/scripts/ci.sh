#!/usr/bin/env bash
# pipeline-kernel 门禁脚本（T-A4：rc.8 对齐后必装必全量，不再降级）：
#   1. 语法门：node --check 全部 lib/*.js
#   2. 依赖安装：pnpm install --frozen-lockfile（rc.8 已在公共 npm，无降级理由）
#   3. 测试集（状态机/B-7 去重/autoRoute 自愈/deliver/ledger/define/contract-rc8-host）
#   4. client typecheck + build
#   5. 产物同步门：build 后 lib/client* 与 lib/types/client 无 diff（改 src 忘构建 → 红）
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== [1/5] host 语法门 =="
for f in lib/*.js; do
  node --check "$f"
done
echo "  语法 OK"

echo "== [2/5] 依赖安装（frozen lockfile） =="
pnpm install --frozen-lockfile
echo "  依赖 OK"

echo "== [3/5] 测试集 =="
npm test

echo "== [4/5] client typecheck + build =="
npm run typecheck:client
npm run build:client

echo "== [5/5] 产物同步门 =="
git diff --exit-code -- lib/client.js lib/client.js.map lib/client lib/types/client
echo "  产物与 src 同步"

echo "== 门禁通过 ✅ =="
