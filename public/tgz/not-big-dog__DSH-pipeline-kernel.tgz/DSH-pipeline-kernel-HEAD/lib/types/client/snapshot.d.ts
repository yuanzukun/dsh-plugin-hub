/**
 * pipeline-kernel client 面快照类型（host /state 返回的 JSON 形状，纯类型）。
 * 与 lib/snapshot.js 的 buildUiSnapshot 输出保持同步。
 * @module pipeline-kernel/client/snapshot
 */
/** 会话链节点：角色 + 注册 UID + 活动状态。 */
export interface ChainNode {
    role: string;
    sessionId: string;
    status: 'running' | 'idle' | 'offline' | 'unregistered';
    stale?: boolean;
}
/** 任务统计。 */
export interface TaskStats {
    open: number;
    claimed: number;
    done: number;
    cancelled: number;
}
/** 任务行（进行中/最近完成/失败共用）。 */
export interface TaskRow {
    id: string;
    title: string;
    status: string;
    tags: string[];
    claimedBy: string | null;
    updatedAt: number;
    cancelled?: boolean;
}
/** 收件箱挂起数（角色 → 数量）。 */
export interface InboxCounts {
    [role: string]: number;
}
/** 角色活动摘要（活动页）。 */
export interface RoleStateRow {
    role: string;
    state: 'running' | 'idle' | 'offline' | 'unregistered';
    running: number;
    done: number;
}
/** 打包产物。 */
export interface PackInfo {
    name: string;
    path: string;
    green: boolean;
    generatedAt?: number;
}
/** 管线快照。 */
export interface PipelineSnapshot {
    id: string;
    title: string;
    projectRoot: string;
    archivedAt: number | null;
    archiveNote: string;
    roles: string[];
    chain: ChainNode[];
    gates: string[];
    taskStats: TaskStats;
    openTasks: TaskRow[];
    recentDone: TaskRow[];
    failedTasks: TaskRow[];
    roleState: RoleStateRow[];
    packs: PackInfo[];
    packCount: number;
    inbox: InboxCounts;
}
/** 台账条目投影。 */
export interface LedgerItem {
    id: string;
    type: string;
    name: string;
    path: string;
    status: string;
    note: string;
    createdAt: number;
    updatedAt: number;
    historyCount: number;
    taskId?: string;
}
/** /state 完整快照。 */
export interface UiSnapshot {
    generatedAt: number;
    archived: boolean;
    pipelines: PipelineSnapshot[];
    ledger: LedgerItem[];
}
