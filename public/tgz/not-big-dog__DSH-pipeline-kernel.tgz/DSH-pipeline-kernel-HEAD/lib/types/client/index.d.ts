import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** 必需服务：会话导航 + 工作区（目录选择器）+ 官方 locale（中英词典）。 */
export declare const inject: string[];
/**
 * 挂载活动面板（body portal，照 agent-teams：web shell 无右上角 slot）。
 * 面板由 /state 快照轮询驱动，点会话节点用 sessions.open 跳转。
 */
export declare function apply(ctx: ClientContext): void;
