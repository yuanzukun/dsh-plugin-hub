/**
 * pipeline-kernel client 面 — 词典（zh/en，官方 locale 机制）。
 * 命名空间 "pipeline"：ctx.locale.register('pipeline', { zh, en })；
 * 面板用 locale.bind('pipeline')(key, params) 取翻译（fallback 中文，{param} 插值）。
 * 原则：UI 文案全部走词典，不硬编码。
 * @module pipeline-kernel/client/i18n
 */
/** 把 "pipeline" 命名空间并入官方合并表（register/bind 获得类型检查，双语键必须一致）。 */
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        pipeline: keyof typeof zh;
    }
}
/** 中文词典（默认/回退）。 */
export declare const zh: {
    'nav.activity': string;
    'nav.pipelines': string;
    'nav.new': string;
    'nav.archive': string;
    'panel.aria': string;
    'panel.expand': string;
    'panel.collapse': string;
    'panel.title': string;
    'new.title': string;
    'new.id': string;
    'new.displayName': string;
    'new.folder': string;
    'new.pickFolder': string;
    'new.folderRequired': string;
    'new.create': string;
    'new.creating': string;
    'new.cancel': string;
    'new.requestFailed': string;
    'activity.empty': string;
    'activity.new': string;
    'activity.running': string;
    'activity.exception': string;
    'activity.idle': string;
    'activity.recentDone': string;
    'activity.openFolder': string;
    'activity.openFolderTitle': string;
    'activity.stats': string;
    'activity.noRoles': string;
    'status.running': string;
    'status.idle': string;
    'status.offline': string;
    'status.unregistered': string;
    'status.open': string;
    'status.claimed': string;
    'status.done': string;
    'status.cancelled': string;
    'task.target': string;
    'task.priority': string;
    'task.updated': string;
    'task.claimedBy': string;
    'task.unclaimed': string;
    'task.openSession': string;
    'task.viewTicket': string;
    'task.detail': string;
    'task.back': string;
    'pipelines.empty': string;
    'pipelines.new': string;
    'pipelines.kpi': string;
    'pipelines.packed': string;
    'pipelines.noChain': string;
    'pipelines.packs': string;
    'pipelines.open': string;
    'pipelines.archive': string;
    'pipelines.archiveConfirm': string;
    'archive.empty': string;
    'archive.archived': string;
    'archive.archivedAt': string;
    'archive.stats': string;
    'archive.restore': string;
    'archive.purge': string;
    'archive.purgeConfirm': string;
    'action.failed': string;
    'action.network': string;
    'action.dismiss': string;
    'time.justNow': string;
    'time.minutesAgo': string;
    'time.hoursAgo': string;
    'time.daysAgo': string;
};
/** 英文词典。 */
export declare const en: typeof zh;
/** 词典命名空间。 */
export declare const NS = "pipeline";
