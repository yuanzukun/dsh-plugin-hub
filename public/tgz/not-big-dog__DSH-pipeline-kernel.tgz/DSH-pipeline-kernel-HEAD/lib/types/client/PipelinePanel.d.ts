import type { Translate } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client';
/** 主面板：右下角胶囊开关 + 右侧全高侧栏（点胶囊展开/收起）。 */
export declare function PipelinePanel({ openSession, pickFolder, t, localeSubscribe, localeGetSnapshot }: {
    openSession: (id: SessionId) => Promise<void>;
    pickFolder: () => Promise<string | null>;
    t: Translate;
    localeSubscribe: (fn: () => void) => () => void;
    localeGetSnapshot: () => {
        revision: number;
    };
}): import("react").JSX.Element | null;
