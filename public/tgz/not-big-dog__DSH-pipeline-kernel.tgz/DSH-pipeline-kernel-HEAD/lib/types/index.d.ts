/**
 * pipeline-kernel 最小类型声明（供 TS 消费者 import）。
 * 实现为纯 JS 插件，运行时契约见 docs/内核接口文档.md。
 * v0.8：Config 已从 schemastery 统一到 zod（审查 P3-1），类型同步。
 * @module pipeline-kernel
 */
import type { Context } from '@deepseek-ai/cordis'
import type { ZodType } from 'zod'

/** 内核配置（与 index.js Config 字段一致）。 */
export interface KernelConfig {
  projectRoot: string
  inboxDir: string
  defaultPipeline: string
  watchdogEnabled: boolean
  watchdogIntervalMs: number
  watchdogStallMs: number
  watchdogWakeCooldownMs: number
  watchdogReportCooldownMs: number
  strikeOut: number
}

export declare const name: 'pipeline-kernel'

export declare const inject: readonly ['tools', 'storageDomain', 'agents', 'commands', 'timer']

export declare const Config: ZodType<KernelConfig>

export declare function apply(ctx: Context, config: KernelConfig): void
