/**
 * pipeline-kernel client 面 — 浏览器入口。
 * UI 只管显示，功能内核实现：所有数据来自 host `/plugins/pipeline-kernel/state` 快照，
 * 所有动作转发给 host（HTTP 端点 / 官方 Service）。
 * @module pipeline-kernel/client
 */
import { jsx as _jsx } from 'react/jsx-runtime'
import { createRoot } from 'react-dom/client'
import type { ClientContext, SessionId } from '@deepseek-ai/dsh-client-runtime/client'
// 引入官方 locale 类型增强（Context.locale / LocaleNamespaceMap 合并）
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-slots'
import { PipelinePanel } from './PipelinePanel.js'
import { NS, zh, en } from './i18n.js'

/** 必需服务：会话导航 + 工作区（目录选择器）+ 官方 locale（中英词典）。 */
export const inject = ['sessions', 'workspaces', 'locale']

/**
 * 挂载活动面板（body portal，照 agent-teams：web shell 无右上角 slot）。
 * 面板由 /state 快照轮询驱动，点会话节点用 sessions.open 跳转。
 */
export function apply(ctx: ClientContext): void {
  // 注册中英词典（官方 locale 机制：UI 文案按当前语言自动切换，fallback 中文）
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'pipeline-kernel: dictionaries')
  const host = document.createElement('div')
  host.dataset.pipelineKernelHost = ''
  document.body.appendChild(host)
  const root = createRoot(host)
  root.render(_jsx(PipelinePanel, {
    // 跳转会话：sessions.open 官方契约要求 id 已在客户端列表（unknown id fail loud）。
    // 新播种的会话由 host 刚创建，列表经 host stream 增量更新——轮询列表快照直到出现再 open（最多 ~6s）
    openSession: async (id: SessionId) => {
      const deadline = Date.now() + 6000
      for (;;) {
        const state = ctx.sessions.list.getSnapshot()
        if (state.ids.includes(id)) {
          ctx.sessions.open(id)
          return
        }
        if (Date.now() >= deadline) return
        await new Promise((resolve) => setTimeout(resolve, 250))
      }
    },
    // 借用"添加工作区"的宿主原生目录选择器（pickDirectory），不手填路径
    pickFolder: () => ctx.workspaces.pickDirectory(),
    // 翻译：官方 locale 绑定（bind 返回 (key, params) => string，fallback 中文）
    t: ctx.locale.bind(NS),
    // 语言切换感知：locale face 订阅（revision 变化触发面板重渲染）
    localeSubscribe: ctx.locale.subscribe.bind(ctx.locale),
    localeGetSnapshot: ctx.locale.getSnapshot.bind(ctx.locale),
  }))
  ctx.effect(() => () => {
    root.unmount()
    host.remove()
  }, 'pipeline-kernel: panel')
}
