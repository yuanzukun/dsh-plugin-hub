/**
 * pipeline-kernel 控制面板（K7 边栏）：右下角状态灯 + 可钉住右侧边栏。
 * 数据：1s 轮询 host /plugins/pipeline-kernel/state（cache:no-store）+ ?archived=1。
 * 交互：状态灯开关；活动/管线/归档三入口；任务点击展开 Task Inspector（不直接跳会话）；
 *       钉住 = 右侧全高侧栏（对话区让位，body 属性切换）；窄屏自动 overlay。
 * 原则：UI 只管显示，功能内核实现。
 * @module pipeline-kernel/client/panel
 */
import { useEffect, useMemo, useState, useSyncExternalStore } from 'react'
import type { FormEvent } from 'react'
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots'
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type {
  ChainNode, LedgerItem, PipelineSnapshot, RoleStateRow, TaskRow, UiSnapshot,
} from './snapshot.js'
import css from './PipelinePanel.module.css'

/** 快照轮询周期。 */
const POLL_MS = 1000
/** host 快照路由。 */
const STATE_URL = '/plugins/pipeline-kernel/state'
/** 打开文件夹端点。 */
const OPEN_FOLDER_URL = '/plugins/pipeline-kernel/open-folder'
/** 新建管线端点。 */
const PIPELINE_CREATE_URL = '/plugins/pipeline-kernel/pipeline-create'
/** 归档/恢复/清除端点。 */
const ARCHIVE_URL = '/plugins/pipeline-kernel/pipeline-archive'
const UNARCHIVE_URL = '/plugins/pipeline-kernel/pipeline-unarchive'
const PURGE_URL = '/plugins/pipeline-kernel/pipeline-purge'

/** 侧栏展开时对话区让位（body 属性，照 agent-teams 先例）。 */
const PANEL_DOCKED_ATTRIBUTE = 'data-pipeline-kernel-docked'

/** 会话活动状态标签（i18n）。 */
function statusLabel(t: Translate, status: string): string {
  const map: Record<string, string> = {
    running: t('status.running'),
    idle: t('status.idle'),
    offline: t('status.offline'),
    unregistered: t('status.unregistered'),
  }
  return map[status] ?? status
}

/** 任务状态 → 图标 + 文字（第一层信息；颜色只是第三层）。 */
function taskState(t: Translate, status: string): { icon: string; label: string } {
  const map: Record<string, { icon: string; label: string }> = {
    open: { icon: '○', label: t('status.open') },
    claimed: { icon: '◐', label: t('status.claimed') },
    running: { icon: '●', label: t('status.running') },
    done: { icon: '✓', label: t('status.done') },
    cancelled: { icon: '⊘', label: t('status.cancelled') },
  }
  return map[status] ?? { icon: '○', label: status }
}

/** 相对时间（i18n）。 */
function relTime(t: Translate, ts: number): string {
  if (!ts) return ''
  const diff = Date.now() - ts
  if (diff < 60_000) return t('time.justNow')
  if (diff < 3600_000) return t('time.minutesAgo', { n: Math.floor(diff / 60_000) })
  if (diff < 86_400_000) return t('time.hoursAgo', { n: Math.floor(diff / 3600_000) })
  return t('time.daysAgo', { n: Math.floor(diff / 86_400_000) })
}

/** 任务的目标角色。 */
function targetRoleOf(tags: string[]): string {
  for (const tag of tags) {
    const m = /^target:(.+)$/.exec(tag)
    if (m) return m[1] ?? ''
  }
  return ''
}

/** 任务所属管线。 */
function pipelineOf(tags: string[]): string {
  for (const tag of tags) {
    const m = /^pipeline:(.+)$/.exec(tag)
    if (m) return m[1] ?? ''
  }
  return ''
}

/** 主面板：右下角胶囊开关 + 右侧全高侧栏（点胶囊展开/收起）。 */
export function PipelinePanel({ openSession, pickFolder, t, localeSubscribe, localeGetSnapshot }: {
  openSession: (id: SessionId) => Promise<void>
  pickFolder: () => Promise<string | null>
  t: Translate
  localeSubscribe: (fn: () => void) => () => void
  localeGetSnapshot: () => { revision: number }
}) {
  // 语言切换感知：locale revision 变化触发重渲染（t 在调用时读当前语言）
  useSyncExternalStore(localeSubscribe, localeGetSnapshot)
  const [snapshot, setSnapshot] = useState<UiSnapshot | null>(null)
  const [archived, setArchived] = useState<UiSnapshot | null>(null)
  const [open, setOpen] = useState(false)
  const [tab, setTab] = useState<'activity' | 'pipelines' | 'archive'>('activity')
  const [activePipeline, setActivePipeline] = useState<string | null>(null)
  const [inspected, setInspected] = useState<TaskRow | null>(null)
  const [creating, setCreating] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [newId, setNewId] = useState('')
  const [newTitle, setNewTitle] = useState('')
  const [newFolder, setNewFolder] = useState('')
  const [newError, setNewError] = useState('')
  const [lastError, setLastError] = useState('') // 审查 P3-3：破坏性操作失败不再静默

  // 轮询主快照 + 归档箱
  useEffect(() => {
    let cancelled = false
    let inFlight = false
    const tick = async () => {
      if (inFlight || cancelled) return
      inFlight = true
      try {
        const [live, arch] = await Promise.all([
          fetch(STATE_URL, { cache: 'no-store' }),
          fetch(`${STATE_URL}?archived=1`, { cache: 'no-store' }),
        ])
        if (live.ok && !cancelled) setSnapshot(await live.json())
        if (arch.ok && !cancelled) setArchived(await arch.json())
      } catch {
        // host 重启中，保留上次快照
      } finally {
        inFlight = false
      }
    }
    void tick()
    const timer = setInterval(() => { void tick() }, POLL_MS)
    return () => { cancelled = true; clearInterval(timer) }
  }, [])

  // 展开时对话区让位；收起时恢复
  useEffect(() => {
    const root = document.documentElement
    if (open) root.setAttribute(PANEL_DOCKED_ATTRIBUTE, '')
    else root.removeAttribute(PANEL_DOCKED_ATTRIBUTE)
    return () => { root.removeAttribute(PANEL_DOCKED_ATTRIBUTE) }
  }, [open])

  const pipelines = snapshot?.pipelines ?? []
  const archivedPipelines = archived?.pipelines ?? []
  const busy = pipelines.some((p) => p.roleState.some((r) => r.state === 'running') || p.openTasks.length > 0)

  const current = pipelines.find((p) => p.id === activePipeline) ?? pipelines[0] ?? null
  const inspectedDetail = useMemo(() => {
    if (!inspected) return null
    const pipelineId = pipelineOf(inspected.tags) || current?.id
    return { ...inspected, pipelineId }
  }, [inspected, current?.id])

  const chooseFolder = async (): Promise<void> => {
    try {
      const path = await pickFolder()
      if (path) setNewFolder(path)
    } catch { /* 选择器失败静默 */ }
  }

  const createPipeline = async (e: FormEvent): Promise<void> => {
    e.preventDefault()
    const id = newId.trim()
    const folder = newFolder.trim()
    if (!id || !folder || submitting) {
      if (!folder) setNewError(t('new.folderRequired'))
      return
    }
    setSubmitting(true)
    setNewError('')
    try {
      const res = await fetch(PIPELINE_CREATE_URL, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ id, title: newTitle.trim() || id, folder }),
      })
      const body: unknown = await res.json()
      if (!res.ok) {
        const err = body !== null && typeof body === 'object' && 'error' in body
          ? String((body as { error: unknown }).error)
          : `HTTP ${res.status}`
        setNewError(err)
        return
      }
      setNewId('')
      setNewTitle('')
      setNewFolder('')
      setNewError('')
      const data = body as { seed?: { seeded?: Array<{ role: string; sessionId: string }> } }
      const supervisor = data.seed?.seeded?.find((s) => s.role === 'supervisor')
      if (supervisor) {
        void openSession(supervisor.sessionId as SessionId).catch(() => { /* 跳转失败不阻断 */ })
      }
    } catch {
      setNewError(t('new.requestFailed'))
    } finally {
      setSubmitting(false)
    }
  }

  /** POST 内核动作：非 2xx 提取 error 文本返回（空串 = 成功）。审查 P3-3：失败可见。 */
  const postAction = async (url: string, body: Record<string, unknown>): Promise<string> => {
    const res = await fetch(url, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    })
    if (res.ok) return ''
    const data: unknown = await res.json().catch(() => null)
    return data !== null && typeof data === 'object' && 'error' in data
      ? String((data as { error: unknown }).error)
      : `HTTP ${res.status}`
  }

  const archivePipeline = async (id: string): Promise<void> => {
    if (!window.confirm(t('pipelines.archiveConfirm', { id }))) return
    try {
      const err = await postAction(ARCHIVE_URL, { pipelineId: id })
      if (err) { setLastError(t('action.failed', { action: t('pipelines.archive'), error: err })); return }
      setLastError('')
      if (activePipeline === id) setActivePipeline(null)
    } catch { setLastError(t('action.network')) }
  }

  const unarchivePipeline = async (id: string): Promise<void> => {
    try {
      const err = await postAction(UNARCHIVE_URL, { pipelineId: id })
      if (err) { setLastError(t('action.failed', { action: t('archive.restore'), error: err })); return }
      setLastError('')
    } catch { setLastError(t('action.network')) }
  }

  const purgePipeline = async (id: string): Promise<void> => {
    const typed = window.prompt(t('archive.purgeConfirm', { id }))
    if (typed !== id) return
    try {
      const err = await postAction(PURGE_URL, { pipelineId: id })
      if (err) { setLastError(t('action.failed', { action: t('archive.purge'), error: err })); return }
      setLastError('')
    } catch { setLastError(t('action.network')) }
  }

  const openFolder = async (path: string): Promise<void> => {
    try {
      const err = await postAction(OPEN_FOLDER_URL, { path })
      if (err) { setLastError(t('action.failed', { action: t('activity.openFolder'), error: err })); return }
      setLastError('')
    } catch { setLastError(t('action.network')) }
  }

  if (pipelines.length === 0) return null

  return (
    <>
      {/* 右下角胶囊开关：点开 = 全高侧栏常驻；再点 = 收起只剩胶囊 */}
      <button
        type="button"
        className={css['pknl-pill']}
        data-open={open}
        onClick={() => setOpen((v) => !v)}
        aria-label={t('panel.aria')}
        title={open ? t('panel.collapse') : t('panel.expand')}
      >
        <span className={css['pknl-pill-dot']} data-busy={busy} aria-hidden="true" />
        {t('panel.title')}
      </button>

      {open && (
        <aside
          className={css['pknl-sidebar']}
          data-pipeline-kernel-activity
        >
          <header className={css['pknl-head']}>
            <span className={css['pknl-title']}>
              {t('panel.title')}
              <span className={css['pknl-dot']} data-busy={busy} aria-hidden="true" />
            </span>
          </header>

          {/* 审查 P3-3：破坏性操作失败提示条（可手动关闭） */}
          {lastError && (
            <div className={css['pknl-error']} role="alert">
              <span className={css['pknl-error-text']}>{lastError}</span>
              <button
                type="button"
                className={css['pknl-error-close']}
                onClick={() => setLastError('')}
                aria-label={t('action.dismiss')}
              >✕</button>
            </div>
          )}

          {/* 顶部横排导航：活动 · 管线 · 新建 · 归档（平均分布） */}
          <nav className={css['pknl-nav']} aria-label={t('panel.title')}>
            <NavItem
              active={tab === 'activity' && !creating}
              icon="●"
              label={t('nav.activity')}
              count={pipelines.reduce((n, p) => n + p.roleState.filter((r) => r.state === 'running').length, 0)}
              onClick={() => { setTab('activity'); setInspected(null); setCreating(false) }}
            />
            <NavItem
              active={tab === 'pipelines' && !creating}
              icon="▤"
              label={t('nav.pipelines')}
              count={pipelines.reduce((n, p) => n + p.packCount, 0)}
              onClick={() => { setTab('pipelines'); setInspected(null); setCreating(false) }}
            />
            <NavItem
              active={creating}
              icon="+"
              label={t('nav.new')}
              count={0}
              onClick={() => { setCreating(true); setInspected(null) }}
            />
            <NavItem
              active={tab === 'archive' && !creating}
              icon="🗄"
              label={t('nav.archive')}
              count={archivedPipelines.length}
              onClick={() => { setTab('archive'); setInspected(null); setCreating(false) }}
            />
          </nav>

          {/* 内容区 */}
          <div className={css['pknl-content']}>
            {tab === 'activity' && (
              <ActivityView
                pipelines={pipelines}
                onInspect={setInspected}
                onOpenSession={openSession}
                onOpenFolder={openFolder}
                t={t}
              />
            )}
            {tab === 'pipelines' && (
              <PipelinesView
                pipelines={pipelines}
                current={current}
                onSelect={setActivePipeline}
                onOpenSession={openSession}
                onOpenFolder={openFolder}
                onArchive={archivePipeline}
                onCreate={() => setCreating(true)}
                t={t}
              />
            )}
            {tab === 'archive' && (
              <ArchiveView
                pipelines={archivedPipelines}
                onRestore={unarchivePipeline}
                onPurge={purgePipeline}
                t={t}
              />
            )}

            {/* Task Inspector */}
            {inspectedDetail && (
              <TaskInspector
                task={inspectedDetail}
                pipeline={current}
                onClose={() => setInspected(null)}
                onOpenSession={openSession}
                onOpenFolder={openFolder}
                t={t}
              />
            )}

            {/* 新建管线表单 */}
            {creating && (
              <form className={css['pknl-create']} onSubmit={createPipeline}>
                <span className={css['pknl-section-title']}>{t('new.title')}</span>
                <input
                  className={css['pknl-input']}
                  placeholder={t('new.id')}
                  value={newId}
                  onChange={(e) => setNewId(e.target.value)}
                  disabled={submitting}
                />
                <input
                  className={css['pknl-input']}
                  placeholder={t('new.displayName')}
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  disabled={submitting}
                />
                <div className={css['pknl-folder-row']}>
                  <input
                    className={css['pknl-input']}
                    placeholder={t('new.folder')}
                    value={newFolder}
                    onChange={(e) => setNewFolder(e.target.value)}
                    disabled={submitting}
                  />
                  <button type="button" className={css['pknl-action']} onClick={chooseFolder} disabled={submitting}>
                    {t('new.pickFolder')}
                  </button>
                </div>
                {newError && <span className={css['pknl-error']}>{newError}</span>}
                <div className={css['pknl-create-actions']}>
                  <button type="submit" className={css['pknl-action']} disabled={submitting || !newId.trim() || !newFolder.trim()}>
                    {submitting ? t('new.creating') : t('new.create')}
                  </button>
                  <button type="button" className={css['pknl-action']} onClick={() => { setCreating(false); setNewError('') }}>
                    {t('new.cancel')}
                  </button>
                </div>
              </form>
            )}
          </div>
        </aside>
      )}
    </>
  )
}

/** 竖向导航项。 */
function NavItem({ active, icon, label, count, onClick }: {
  active: boolean
  icon: string
  label: string
  count: number
  onClick: () => void
}) {
  return (
    <button type="button" className={css['pknl-nav-item']} data-active={active} onClick={onClick} title={label}>
      <span className={css['pknl-nav-icon']} aria-hidden="true">{icon}</span>
      <span className={css['pknl-nav-label']}>{label}</span>
      {count > 0 && <span className={css['pknl-nav-count']}>{count}</span>}
    </button>
  )
}

/** 活动页：每管线运行摘要卡（角色状态点 + 最近完成 + 失败置顶）。 */
function ActivityView({ pipelines, onInspect, onOpenSession, onOpenFolder, t }: {
  pipelines: PipelineSnapshot[]
  onInspect: (t: TaskRow) => void
  onOpenSession: (id: SessionId) => Promise<void>
  onOpenFolder: (path: string) => Promise<void>
  t: Translate
}) {
  const ordered = useMemo(() => {
    const withActivity = pipelines.filter((p) => p.roleState.some((r) => r.state === 'running') || p.openTasks.length > 0)
    const rest = pipelines.filter((p) => !withActivity.includes(p))
    return [...withActivity, ...rest]
  }, [pipelines])
  if (ordered.length === 0) return <EmptyState text={t('activity.empty')} action={t('activity.new')} onCreate={() => {}} />
  return (
    <div className={css['pknl-view']}>
      {ordered.map((p) => (
        <ActivityCard key={p.id} pipeline={p} onInspect={onInspect} onOpenSession={onOpenSession} onOpenFolder={onOpenFolder} t={t} />
      ))}
    </div>
  )
}

/** 活动摘要卡。 */
function ActivityCard({ pipeline, onInspect, onOpenSession, onOpenFolder, t }: {
  pipeline: PipelineSnapshot
  onInspect: (t: TaskRow) => void
  onOpenSession: (id: SessionId) => Promise<void>
  onOpenFolder: (path: string) => Promise<void>
  t: Translate
}) {
  const running = pipeline.roleState.filter((r) => r.state === 'running').length
  const failed = pipeline.failedTasks
  return (
    <section className={css['pknl-activity-card']} data-failed={failed.length > 0}>
      <header className={css['pknl-card-head']}>
        <span className={css['pknl-card-title']}>{pipeline.title || pipeline.id}</span>
        <span className={css['pknl-card-state']} data-running={running > 0}>
          {running > 0 ? `● ${running} ${t('activity.running')}` : failed.length > 0 ? `! ${t('activity.exception')}` : t('activity.idle')}
        </span>
      </header>
      {failed.length > 0 && (
        <div className={css['pknl-failed-list']}>
          {failed.map((task) => (
            <button key={task.id} type="button" className={css['pknl-failed-row']} onClick={() => onInspect(task)} title={t('task.detail')}>
              <span className={css['pknl-task-icon']} data-state="failed">!</span>
              <span className={css['pknl-task-title']}>{task.title}</span>
              <span className={css['pknl-task-meta']}>{targetRoleOf(task.tags)}</span>
            </button>
          ))}
        </div>
      )}
      <div className={css['pknl-role-rows']}>
        {pipeline.roleState.map((r) => (
          <RoleRow key={r.role} row={r} t={t} />
        ))}
        {pipeline.roleState.length === 0 && <span className={css['pknl-empty']}>{t('activity.noRoles')}</span>}
      </div>
      {pipeline.openTasks.length > 0 && (
        <div className={css['pknl-open-tasks']}>
          {pipeline.openTasks.slice(0, 5).map((task) => (
            <button key={task.id} type="button" className={css['pknl-task-row']} onClick={() => onInspect(task)}>
              <span className={css['pknl-task-icon']} data-state={task.status}>{taskState(t, task.status).icon}</span>
              <span className={css['pknl-task-title']}>{task.title}</span>
              <span className={css['pknl-task-meta']}>{targetRoleOf(task.tags)} · {relTime(t, task.updatedAt)}</span>
            </button>
          ))}
        </div>
      )}
      {pipeline.recentDone.length > 0 && (
        <div className={css['pknl-recent']}>
          <span className={css['pknl-recent-head']}>{t('activity.recentDone')}</span>
          {pipeline.recentDone.slice(0, 3).map((task) => (
            <span key={task.id} className={css['pknl-recent-row']}>
              {task.cancelled ? '⊘' : '✓'} {task.title}
            </span>
          ))}
        </div>
      )}
      <footer className={css['pknl-card-foot']}>
        <button type="button" className={css['pknl-action']} onClick={() => onOpenFolder(pipeline.projectRoot || '.')} title={t('activity.openFolderTitle', { path: pipeline.projectRoot || '.' })}>
          {t('activity.openFolder')}
        </button>
        <span className={css['pknl-card-stats']}>
          {t('activity.stats', { pending: pipeline.taskStats.open + pipeline.taskStats.claimed, done: pipeline.taskStats.done })}
        </span>
      </footer>
    </section>
  )
}

/** 角色状态行。 */
function RoleRow({ row, t }: { row: RoleStateRow; t: Translate }) {
  return (
    <div className={css['pknl-role-row']}>
      <span className={css['pknl-task-icon']} data-state={row.state}>
        {row.state === 'running' ? '●' : row.state === 'unregistered' ? '○' : row.state === 'offline' ? '◌' : '✓'}
      </span>
      <span className={css['pknl-role-name']}>{row.role}</span>
      <span className={css['pknl-role-meta']}>
        {statusLabel(t, row.state)}
        {row.running > 0 ? ` · ${row.running} ${t('status.open')}` : ''}
        {row.done > 0 ? ` · ${row.done} ${t('status.done')}` : ''}
      </span>
    </div>
  )
}

/** 管线页：Graph 缩略图 + Overview。 */
function PipelinesView({ pipelines, current, onSelect, onOpenSession, onOpenFolder, onArchive, onCreate, t }: {
  pipelines: PipelineSnapshot[]
  current: PipelineSnapshot | null
  onSelect: (id: string) => void
  onOpenSession: (id: SessionId) => Promise<void>
  onOpenFolder: (path: string) => Promise<void>
  onArchive: (id: string) => Promise<void>
  onCreate: () => void
  t: Translate
}) {
  const selected = current ?? pipelines[0] ?? null
  if (pipelines.length === 0) return <EmptyState text={t('pipelines.empty')} action={t('pipelines.new')} onCreate={onCreate} />
  return (
    <div className={css['pknl-view']}>
      {pipelines.length > 1 && (
        <div className={css['pknl-badges']}>
          {pipelines.map((p) => (
            <button key={p.id} type="button" className={css['pknl-badge']} data-active={p.id === selected?.id} onClick={() => onSelect(p.id)}>
              {p.title || p.id}
            </button>
          ))}
        </div>
      )}
      {selected && (
        <PipelineCard
          pipeline={selected}
          onOpenSession={onOpenSession}
          onOpenFolder={onOpenFolder}
          onArchive={onArchive}
          t={t}
        />
      )}
    </div>
  )
}

/** 管线卡（一等实体：Graph 缩略图 + KPI + 打包）。 */
function PipelineCard({ pipeline, onOpenSession, onOpenFolder, onArchive, t }: {
  pipeline: PipelineSnapshot
  onOpenSession: (id: SessionId) => Promise<void>
  onOpenFolder: (path: string) => Promise<void>
  onArchive: (id: string) => Promise<void>
  t: Translate
}) {
  const running = pipeline.roleState.filter((r) => r.state === 'running').length
  return (
    <section className={css['pknl-pipeline-card']}>
      <header className={css['pknl-card-head']}>
        <span className={css['pknl-card-title']}>{pipeline.title || pipeline.id}</span>
        <span className={css['pknl-card-state']} data-running={running > 0}>
          {running > 0 ? `● ${running} ${t('activity.running')}` : t('activity.idle')}
        </span>
      </header>
      <div className={css['pknl-pipeline-kpi']}>
        {t('pipelines.kpi', {
          roles: pipeline.roles.length,
          pending: pipeline.taskStats.open + pipeline.taskStats.claimed,
          done: pipeline.taskStats.done,
        })}
        {pipeline.packCount > 0 && ` · ${t('pipelines.packed', { n: pipeline.packCount })}`}
      </div>
      {/* Graph 缩略图：chain 方向 */}
      <div className={css['pknl-graph']}>
        {pipeline.chain.length === 0 && <span className={css['pknl-empty']}>{t('pipelines.noChain')}</span>}
        {pipeline.chain.map((node, idx) => (
          <span key={`${node.role}-${idx}`} className={css['pknl-graph-item']}>
            {idx > 0 && <span className={css['pknl-arrow']} aria-hidden="true">→</span>}
            <button
              type="button"
              className={css['pknl-graph-node']}
              data-state={node.status}
              disabled={!node.sessionId || node.status === 'unregistered'}
              onClick={() => { if (node.sessionId && node.status !== 'unregistered') void onOpenSession(node.sessionId as SessionId) }}
              title={`${node.role}（${statusLabel(t, node.status)}）`}
            >
              {node.role}
            </button>
          </span>
        ))}
      </div>
      {/* 打包产物 */}
      {pipeline.packs.length > 0 && (
        <div className={css['pknl-packs']}>
          <span className={css['pknl-section-title']}>{t('pipelines.packs')}</span>
          {pipeline.packs.map((pack) => (
            <div key={pack.name} className={css['pknl-pack-row']}>
              <span className={css['pknl-pack-icon']} data-green={pack.green}>{pack.green ? '🟢' : '🟡'}</span>
              <span className={css['pknl-pack-name']}>{pack.name}</span>
              <button type="button" className={css['pknl-action']} onClick={() => void onOpenFolder(pack.path)}>{t('pipelines.open')}</button>
            </div>
          ))}
        </div>
      )}
      <footer className={css['pknl-card-foot']}>
        <button type="button" className={css['pknl-action']} onClick={() => void onOpenFolder(pipeline.projectRoot || '.')}>{t('activity.openFolder')}</button>
        <button type="button" className={css['pknl-action']} onClick={() => void onArchive(pipeline.id)}>{t('pipelines.archive')}</button>
      </footer>
    </section>
  )
}

/** 归档页：冷存储卡。 */
function ArchiveView({ pipelines, onRestore, onPurge, t }: {
  pipelines: PipelineSnapshot[]
  onRestore: (id: string) => Promise<void>
  onPurge: (id: string) => Promise<void>
  t: Translate
}) {
  if (pipelines.length === 0) return <EmptyState text={t('archive.empty')} action="" onCreate={() => {}} />
  return (
    <div className={css['pknl-view']}>
      {pipelines.map((p) => (
        <section key={p.id} className={css['pknl-archive-card']}>
          <header className={css['pknl-card-head']}>
            <span className={css['pknl-card-title']}>{p.title || p.id}</span>
            <span className={css['pknl-card-state']}>🗄 {t('archive.archived')}</span>
          </header>
          <div className={css['pknl-archive-meta']}>
            {p.archivedAt ? t('archive.archivedAt', { time: new Date(p.archivedAt).toLocaleString() }) : ''}
            {p.archiveNote ? ` · ${p.archiveNote}` : ''}
          </div>
          <div className={css['pknl-archive-stats']}>
            {t('archive.stats', {
              tasks: p.taskStats.open + p.taskStats.claimed + p.taskStats.done + p.taskStats.cancelled,
              roles: p.roles.length,
            })}
            {p.packCount > 0 ? ` · ${t('pipelines.packed', { n: p.packCount })}` : ''}
          </div>
          <footer className={css['pknl-card-foot']}>
            <button type="button" className={css['pknl-action']} onClick={() => void onRestore(p.id)}>{t('archive.restore')}</button>
            <button type="button" className={css['pknl-action-danger']} onClick={() => void onPurge(p.id)}>{t('archive.purge')}</button>
          </footer>
        </section>
      ))}
    </div>
  )
}

/** Task Inspector：任务 = 信息实体，会话 = 执行载体。 */
function TaskInspector({ task, pipeline, onClose, onOpenSession, onOpenFolder, t }: {
  task: TaskRow & { pipelineId?: string }
  pipeline: PipelineSnapshot | null
  onClose: () => void
  onOpenSession: (id: SessionId) => Promise<void>
  onOpenFolder: (path: string) => Promise<void>
  t: Translate
}) {
  const role = targetRoleOf(task.tags)
  const node = pipeline?.chain.find((n) => n.role === role)
  const state = taskState(t, task.status)
  return (
    <div className={css['pknl-inspector']}>
      <header className={css['pknl-inspector-head']}>
        <button type="button" className={css['pknl-icon-btn']} onClick={onClose} aria-label={t('task.back')}>
          ←
        </button>
        <span className={css['pknl-section-title']}>{t('task.detail')}</span>
      </header>
      <div className={css['pknl-inspector-title']}>{task.title}</div>
      <div className={css['pknl-inspector-id']}>{task.pipelineId ?? pipeline?.id ?? '-'} / {task.id}</div>
      <div className={css['pknl-inspector-state']}>
        <span className={css['pknl-task-icon']} data-state={task.status}>{state.icon}</span>
        {state.label}
      </div>
      <dl className={css['pknl-inspector-dl']}>
        <dt>{t('task.target')}</dt><dd>{role || '-'}</dd>
        <dt>{t('task.priority')}</dt><dd>{task.tags.find((tag) => tag.startsWith('priority:'))?.slice(9) ?? 'normal'}</dd>
        <dt>{t('task.updated')}</dt><dd>{task.updatedAt ? new Date(task.updatedAt).toLocaleString() : '-'}</dd>
        <dt>{t('task.claimedBy')}</dt><dd>{task.claimedBy || t('task.unclaimed')}</dd>
      </dl>
      <div className={css['pknl-inspector-actions']}>
        <button
          type="button"
          className={css['pknl-action']}
          disabled={!node?.sessionId || node.status === 'unregistered'}
          onClick={() => { if (node?.sessionId) void onOpenSession(node.sessionId as SessionId) }}
        >
          {t('task.openSession')}
        </button>
        <button type="button" className={css['pknl-action']} onClick={() => void onOpenFolder('exchange/收件箱')}>
          {t('task.viewTicket')}
        </button>
      </div>
    </div>
  )
}

/** 空态。 */
function EmptyState({ text, action, onCreate }: { text: string; action: string; onCreate: () => void }) {
  return (
    <div className={css['pknl-empty-state']}>
      <span>{text}</span>
      {action && (
        <button type="button" className={css['pknl-action']} onClick={onCreate}>{action}</button>
      )}
    </div>
  )
}
