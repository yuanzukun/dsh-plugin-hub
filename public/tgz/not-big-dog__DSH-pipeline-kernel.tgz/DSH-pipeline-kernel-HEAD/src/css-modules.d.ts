/** CSS Modules 类型声明（client program 需要）。 */
declare module '*.module.css' {
  const classes: Record<string, string>
  export default classes
}
