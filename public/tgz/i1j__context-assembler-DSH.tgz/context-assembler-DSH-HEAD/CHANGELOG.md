# Changelog

## 2026-08-25 — 开发线里程碑同步：三阶段接力架构 + 跨块回溯 traceback 上线 + M2 评估口径对齐

> 公开代码快照仍为 **V0.99.0**（2026-08-18 首发）；以下为开发线（私有工作区，v7.x）进展同步，
> 完整实现与文档随下个公开版本发布。

- **三阶段接力架构**：操作块生命周期「原文 → step 改写 → 折叠」逐级压缩——块未闭合保留原文
  （Fct 异步生成）；块闭合后近区（hard∪near）已闭合轮做 step 改写（真 Fct / 内容型豁免）；
  轮闭合滑出保护区由折叠接管（操作级摘要）。互斥解除：step 改写不再下线折叠。
- **跨块回溯 traceback 上线**：动态分配（默认 512）+ 评估/实现口径共享（laterRefs 对齐
  laterModelTextOf）——referenced 挽回 **98.7%**、L 42.0%（26 会话实证）。
- **E 组豁免裁定执行**：browser_eval + subagent 入内容型豁免集（改写层信息保存优先）；workflow 不入。
- **M2 评估口径对齐**：评估脚本 nearTurnIds 近区边界 + deterministicFctEnabled 默认关镜像生产；
  近区重跑：计划 step 562→279、ρ +2.21pp、η +0.004、真实损失 377（全 run_code）——M2 维持
  dry-run 观察。
- 测试基线：**72 文件 / 931 用例全绿** + tsc 干净（≥5 次连续零失败自证）。

## 2026-08-20 — 精简仓库标题与描述

- README 中/英 H1 精简：删去「上下文汇编插件 / Context Assembler plugin」重复表述，
  中文「# 上下文汇编（Context Assembler DSH）— DeepSeek Harness 插件」、
  英文「# Context Assembler DSH — a DeepSeek Harness plugin」。
- GitHub/Gitee 仓库描述统一精简为：Context Assembler DSH — DeepSeek Harness 上下文汇编插件：
  按话题块编排上下文，最大化每 token 互信息密度。

## 2026-08-20 — 新增硬件要求 + 观察镜示例软硬件说明

- README（中/英）新增 **硬件要求** 小节：插件核心纯计算、零主机依赖；但汇编摘要/工具改写依赖
  本地小模型（Ollama 兼容，4B 级），**建议约 10G 显存显卡**（可流畅运行 4B 量化模型），
  无独显时 CPU 推理也可用。
- 观察镜截图 caption 下方补充 **示例软硬件配置**（通用描述：本地 Ollama 兼容服务 / 4B 量化 /
  ~10G 显存 / DSH Web 0.1.x，不暴露主机、端口、路径等隐私细节）。

## 2026-08-20 — 插件简介定稿：互信息密度理论为核心 + 算力置换/缓存纪律写回

- README（中/英）「插件简介」定稿：以**互信息量密度最大化**为理论核心，写回
  **算力置换**（本地离散低带宽算力 ↔ 云端瞬发高带宽算力）与**缓存纪律**——按话题块打包：
  块内前缀稳定至尾部原始数据保护区（`tailN`）、`topicSplitStartChars→topicSplitPeakChars`
  动态降门槛切块（峰值即使内容一致也强制切块）、仅切换话题时重估摘要组合。
  机制描述依据与外部专家对话（2026-08-19/20）中用户亲述的准确定义撰写。
- 观察镜截图 caption 下方@原作者致谢：fork 自
  [bowenliang123/dsh-context](https://github.com/bowenliang123/dsh-context)（中英双语）。

## 2026-08-20 — 插件简介重写（落实专家建议）+ 上下文观察镜截图

- README（中/英）「插件简介」按外部专家对话收敛的**核心要点**重写：算力置换（本地离散低带宽
  算力 ↔ 云端瞬发高带宽算力）→ 主动编排而非压缩 → 按话题块打包的缓存纪律 → 每 token 互信息
  密度度量 → 效果可观测；末句点明与 DSH 原生压缩（被动、溢出才裁）互补。
- 新增 `docs/images/context-obs-trend.png`：上下文观察镜·历史趋势截图（真实会话 T11–T16
  逐轮 token 累积趋势，上下镜像、倒像 = 虚拟推算不压缩对照，× = 压缩/剪枝；第 16 轮 token
  构成拆解），嵌入插件简介。

## 2026-08-20 — 规划摘要 + 进度汇编 + 项目介绍修订（docs）

- 新增 `docs/PLANNING-2026-08-20.md`：外部专家设计评审对话收敛的**规划基线**——算力置换洞察
  （本地离散低带宽算力 ↔ 云端瞬发高带宽算力）、按话题块打包的缓存纪律、三条工程红线、
  与 DSH 生态定位、路线图 R1-R3、GitHub/Gitee 运营约定。
- 新增 `docs/PROGRESS-2026-08-20.md`：基于当前工作区上下文的**进度汇编**——发布状态（V0.99.0，
  466 用例全绿）、核心能力 8 项、近期进展（P2-5 收尾兜底改写 / ca-db v4 / 观察镜 / B7-B10 /
  MI 评估体系）、评审与质量（需求 v1.10、69+168 条闭环、T1-T11）。
- README（中/英）：项目介绍补「算力置换 + 单位 token 互信息密度」设计理念段；文档清单挂接
  PLANNING/PROGRESS；开发节测试数 429→466 对齐徽章。
- 同步：GitHub 主仓 + Gitee 镜像双平台推送。

## 0.99.0 (2026-08-18) — Context Assembler DSH V0.99 首次公开发布（中文全称：上下文汇编）

Context Assembler（上下文汇编）的 DeepSeek Harness 插件版公开首发，承接 Hermes
`ca_assembler` 的设计意图（见 [docs/DESIGN.md](docs/DESIGN.md)），在 DSH 插件框架下实现。

### 核心能力

- **话题块上下文汇编**：按话题块构建「本块视角」的会话摘要版本，块内前缀稳定、云端缓存友好；
- **水位压力话题切割**：ctx 字符上涨线性扣减 Jaccard，满压必切（`forceAtPeak`），单话题长会话不再锁死；
- **话题定级与冻结**：切换时快照 ACT/REL/FAR 定级、块内复用、新轮 ACT（确定性、无 LLM）；
- **工具轮压缩**：`toolCall`/`toolResult` 结构化摘要（确定性）+ wire 级工具结果改写（可 dry-run）；
- **reality 召回注入**：本地 4B embedding + 拣选，话题块开头注入背景资料（fail-open）；
- **思考卡（OODA）装配**：thought+tool 合流 + L1 事实附录（本地 4B，默认关、渐进验证）；
- **handoff 规划**：压力触发会话交接（分支摘要 / 边强度 / 视角 / 路由策略）；
- **`ca-db` 公开库**：话题 / realities 持久化 DDL 与辅助导出。

### 工程

- 测试 38 文件 429 用例全绿；`tsc --noEmit` 干净；
- 修复发布前隐私问题：默认路径改为中立相对路径、路径脱敏改用 `os.homedir()`；
- MIT 许可开源（GitHub 主仓 + Gitee 镜像）。
