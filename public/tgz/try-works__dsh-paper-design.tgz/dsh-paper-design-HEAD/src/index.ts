/**
 * dsh-paper-design bundle entry: the Paper MCP bridge.
 *
 * Connects to the Paper Desktop MCP server (http://127.0.0.1:29979/mcp),
 * registers every Paper tool as a native `paper_*` tool with image-content
 * support (screenshots reach the model as durable attachment-backed image
 * blocks), injects Cursor-parity standing rules and the early-turn full
 * guide, registers the paper skills, and exposes /paper-reconnect.
 *
 * @module dsh-paper-design/src/index
 */

import type { Context } from '@deepseek-ai/cordis'
import Schema from '@deepseek-ai/schemastery'
// Type-only imports activate the cordis Context augmentations below (services
// are read via ctx.get at runtime; only the augmentation is needed for types).
import type { CommandDefinition } from '@deepseek-ai/dsh-commands'
import type { AttachmentStore, ImageMediaType } from '@deepseek-ai/dsh-attachment'
import type {} from '@deepseek-ai/dsh-skill'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import type { ToolDefinition, ToolRunContext } from '@deepseek-ai/dsh-tools'
import type { JsonValue } from '@deepseek-ai/dsh-util-values'
import { PaperMcpClient, MCP_URL, type McpCallToolResult, type McpContentPart } from './mcp-client.ts'
import { PaperAuthManager, openBrowser } from './auth.ts'
import { normalizeToolSchema } from './schema.ts'
import {
  PAPER_GUIDE_INJECT_TURNS,
  buildPaperSystemPromptSuffix,
  extractGuideText,
} from './guide.ts'
import { applySkills } from './skills.ts'

/**
 * This bridge is its own context producer, and the harness has no shared
 * catch-all `plugin` source kind: `MessageSourceMap` is merge-extensible with
 * one `kind` declared by each producer in its own module (mirroring
 * `dsh-tools`' `tool-registry` and `dsh-user-approval`'s `user-approval`).
 */
declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    /** Image/text context the Paper bridge defers to its parent agent. */
    'paper-design': { kind: 'paper-design' }
  }
}

export const name = 'dsh-paper-design'
// `skills` and `commands` are read optionally through `ctx.get`: Cordis refuses
// to read a service off `ctx` without a matching `inject`, and hard-injecting
// them would stop the plugin activating in a profile that lacks them. Tools and
// the prompt section are the contract, so only those are hard dependencies.
export const inject = ['tools', 'systemPrompt']

/** Source kind carried by context this bridge defers to a parent agent. */
const CONTEXT_SOURCE_KIND = 'paper-design'

/** Default interval between connection attempts while Paper Desktop is closed. */
const DEFAULT_RETRY_MS = 10_000

/** Bridge configuration; every field is optional so the bundle patch can omit it. */
export interface BridgeConfig {
  /** Paper Desktop MCP endpoint. */
  endpoint?: string
  /** Retry interval (ms) while Paper Desktop is unavailable. */
  retryMs?: number
}

export const Config = Schema.object({
  endpoint: Schema.string().default(MCP_URL).description('Paper Desktop MCP endpoint.'),
  retryMs: Schema.number().default(DEFAULT_RETRY_MS).description('Retry interval (ms) while Paper Desktop is unavailable.'),
})

/** Prompt section order inside the tool-guidance band (100–199). */
const STANDING_SECTION_ORDER = 150

/** Prefix every registered Paper tool. */
const TOOL_PREFIX = 'paper_'

/** Never bridge an auth tool even if the server starts advertising one. */
const FILTERED_TOOLS = new Set(['mcp_auth'])

/** Image media types the Paper server emits; must intersect attachment limits. */
const IMAGE_MEDIA_TYPES: Readonly<Record<string, ImageMediaType>> = {
  'image/png': 'image/png',
  'image/jpeg': 'image/jpeg',
  'image/jpg': 'image/jpeg',
  'image/webp': 'image/webp',
  'image/gif': 'image/gif',
}

interface PaperToolInfo {
  rawName: string
  publicName: string
  description: string
  parameters: Record<string, unknown>
}

interface BridgeState {
  client: PaperMcpClient
  /** OAuth client auth manager (dormant until the server advertises/challenges auth). */
  auth: PaperAuthManager
  tools: PaperToolInfo[]
  guideText: string | null
  /** Remaining turns (counted at agent running transitions) that receive the full guide. */
  injectTurnsLeft: number
  /** Turn-count per session id, for the per-step assembly read. */
  sessionTurns: Map<string, number>
  toolDisposers: Array<() => void>
}

/** Total the session/event feed to count turn starts per session. */
function countTurnStarts(state: BridgeState, sessionId: string, event: { type?: string }): void {
  if (event.type !== 'turn/start') return
  const current = state.sessionTurns.get(sessionId) ?? 0
  state.sessionTurns.set(sessionId, current + 1)
}

/** Whether the full guide should be included for one agent assembly. */
function includeGuideFor(state: BridgeState, agentId: string): boolean {
  if (state.injectTurnsLeft <= 0) return false
  const turns = state.sessionTurns.get(agentId) ?? 0
  return turns < PAPER_GUIDE_INJECT_TURNS
}

/**
 * Render an MCP result into model content blocks, forwarding images through
 * the attachment store when one is mounted. Returns the blocks plus the
 * structured content (unmodified) for the canonical value.
 */
async function renderMcpResult(
  state: BridgeState,
  exec: ToolRunContext,
  rawName: string,
  result: McpCallToolResult,
  attachments: AttachmentStore | undefined,
): Promise<{ blocks: ContentBlock[]; structured?: JsonValue }> {
  const parts = result.content ?? []
  const blocks: ContentBlock[] = []
  const textParts: string[] = []

  for (const part of parts) {
    if (typeof part !== 'object' || part === null || Array.isArray(part)) continue
    const block = part as McpContentPart
    if (block.type === 'text' && typeof block.text === 'string') {
      textParts.push(block.text)
      continue
    }
    if (block.type === 'image') {
      const mime = (block as { mimeType?: unknown }).mimeType
      const data = (block as { data?: unknown }).data
      if (typeof data !== 'string' || data.length === 0) {
        textParts.push(`[image: ${typeof mime === 'string' ? mime : 'unknown'}, content discarded]`)
        continue
      }
      if (attachments === undefined) {
        textParts.push(`[image: ${typeof mime === 'string' ? mime : 'unknown'}, content discarded (no attachment store)]`)
        continue
      }
      const mediaType = typeof mime === 'string' ? IMAGE_MEDIA_TYPES[mime.toLowerCase()] : undefined
      if (mediaType === undefined) {
        textParts.push(`[image: ${typeof mime === 'string' ? mime : 'unknown'}, unsupported media type]`)
        continue
      }
      if (!attachments.imageLimits.mediaTypes.includes(mediaType)) {
        textParts.push(`[image: ${mediaType}, not accepted by this deployment]`)
        continue
      }
      try {
        const bytes = Buffer.from(data, 'base64')
        const ref = await attachments.saveImage({ data: bytes, mediaType, name: `${rawName}.${mediaType.split('/')[1] ?? 'img'}` })
        blocks.push({ type: 'image', attachment: ref })
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        textParts.push(`[image: ${mediaType}, failed to attach: ${message}]`)
      }
      continue
    }
    // Fall through for resource/audio/unknown: emit a compact note.
    textParts.push(`[${(block.type as string) ?? 'unknown'}: content discarded]`)
  }

  if (textParts.length > 0) blocks.unshift({ type: 'text', text: textParts.join('\n') })
  const structured = typeof result.structuredContent === 'object' && result.structuredContent !== null && !Array.isArray(result.structuredContent)
    ? result.structuredContent as JsonValue
    : undefined
  return { blocks, structured }
}

/** One registerable raw ToolDefinition for a Paper tool. */
function createToolDefinition(
  state: BridgeState,
  info: PaperToolInfo,
  withAttachments: (fn: (attachments: AttachmentStore | undefined) => Promise<void>) => Promise<void>,
): ToolDefinition {
  const { rawName, publicName, description, parameters } = info

  return {
    name: publicName,
    description: `[Paper Design MCP] ${description}`.trim(),
    parameters,
    output: {
      // Canonical value: the full MCP result (text content, structuredContent),
      // projected through the enforced subset. Images render as attachment refs.
      schema: {
        type: 'object',
        properties: {
          content: { type: 'array', items: {} },
          structuredContent: {},
        },
        additionalProperties: false,
      },
      render(_args: unknown, value: JsonValue): ContentBlock[] {
        // Re-render the canonical value; images are represented by refs in
        // content when they were attachable, and text is re-joined.
        const record = (value ?? {}) as { content?: JsonValue[]; structuredContent?: JsonValue }
        const textParts: string[] = []
        for (const entry of record.content ?? []) {
          if (typeof entry === 'string') { textParts.push(entry); continue }
          if (entry !== null && typeof entry === 'object' && (entry as Record<string, unknown>).text !== undefined) {
            textParts.push(String((entry as Record<string, unknown>).text))
            continue
          }
        }
        const blocks: ContentBlock[] = []
        if (textParts.length > 0) blocks.unshift({ type: 'text', text: textParts.join('\n') })
        if (record.structuredContent !== undefined) {
          blocks.push({ type: 'text', text: JSON.stringify(record.structuredContent, null, 2) })
        }
        return blocks
      },
    },
    async execute(args: unknown, exec: ToolRunContext): Promise<unknown> {
      // Raw registrations receive unvalidated args; coerce to a plain record.
      const record = (typeof args === 'object' && args !== null && !Array.isArray(args)) ? args as Record<string, unknown> : {}
      const response = await state.client.callTool(rawName, record, exec.signal)
      if (response.error) {
        throw new Error(`paper_${rawName}: ${response.error.message}`)
      }
      const result = response.result as McpCallToolResult | undefined
      if (result === undefined) {
        throw new Error(`paper_${rawName}: empty MCP result`)
      }
      if (result.isError === true) {
        throw new Error(`paper_${rawName}: MCP error`)
      }
      // Capture guide text early so get_guide populates the cache.
      if (rawName === 'get_guide') {
        const guide = extractGuideText(result)
        if (guide !== null) state.guideText = guide
      }
      let blocks: ContentBlock[] = []
      await withAttachments(async (attachments) => {
        const rendered = await renderMcpResult(state, exec, rawName, result, attachments)
        blocks = rendered.blocks
      })
      // Defer image context to the parent agent when nested (composite/run_code).
      if (exec.parent !== undefined && blocks.length > 0) {
        exec.deferContext(createUserMessage({
          content: blocks,
          source: { kind: CONTEXT_SOURCE_KIND },
        }))
      }
      // Canonical value mirrors the MCP content; text blocks stored as strings.
      const content = (result.content ?? []).map((part): JsonValue => {
        if (typeof part === 'object' && part !== null && (part as { type?: unknown }).type === 'text') {
          return String((part as { text?: unknown }).text ?? '')
        }
        if (typeof part === 'object' && part !== null && (part as { type?: unknown }).type === 'image') {
          return { type: 'image', note: 'attachment-forwarded' }
        }
        return null
      })
      return {
        content,
        ...(result.structuredContent !== undefined ? { structuredContent: result.structuredContent as JsonValue } : {}),
      }
    },
  }
}

/** Resolve the attachment store via runtime ctx.get, if mounted. */
function resolveAttachments(ctx: Context): AttachmentStore | undefined {
  const attachments = ctx.get('attachments')
  if (attachments === undefined || typeof (attachments as { saveImage?: unknown }).saveImage !== 'function') return undefined
  return attachments as AttachmentStore
}

/** One-line auth status appended to the standing-rules section. */
function renderAuthLine(status: { mode: string; configured: boolean; authenticated: boolean }): string {
  if (status.mode === 'unauthenticated') return ''
  const state = status.authenticated ? 'authenticated' : (status.configured ? 'configured (token present, may need refresh)' : 'not authenticated')
  return `\n### Paper MCP auth\nOAuth mode; ${state}. Use /paper-auth-status for details, /paper-auth-login to (re)authenticate, /paper-auth-logout to clear tokens.\n`
}

/** Runs a callback with the attachment store resolved at call time. */
type AttachmentsRunner = (fn: (attachments: AttachmentStore | undefined) => Promise<void>) => Promise<void>

/** Outcome of one connect + discover + register attempt. */
interface ConnectionResult {
  ok: boolean
  toolCount: number
  error?: string
}

/** Filter a raw `tools/list` payload into registerable Paper tool infos. */
function toToolInfos(rawTools: unknown): PaperToolInfo[] {
  const infos: PaperToolInfo[] = []
  if (!Array.isArray(rawTools)) return infos
  for (const raw of rawTools) {
    if (typeof raw !== 'object' || raw === null) continue
    const entry = raw as { name?: unknown; description?: unknown; inputSchema?: unknown }
    if (typeof entry.name !== 'string' || FILTERED_TOOLS.has(entry.name)) continue
    if (!/^[a-zA-Z0-9_-]+$/.test(entry.name)) continue
    const publicName = `${TOOL_PREFIX}${entry.name}`
    const description = typeof entry.description === 'string' ? entry.description : entry.name
    const parameters = normalizeToolSchema(entry.inputSchema) as unknown as Record<string, unknown>
    infos.push({ rawName: entry.name, publicName, description, parameters })
  }
  return infos
}

/** Replace `state.tools` from the server; returns a message when the listing failed. */
async function discoverTools(state: BridgeState): Promise<string | undefined> {
  const listed = await state.client.listTools()
  if (listed.error) return listed.error.message
  state.tools = toToolInfos((listed.result as { tools?: unknown } | undefined)?.tools)
  return undefined
}

/**
 * Publish every discovered tool, disposing any previous registrations first so
 * the call is idempotent and re-running it after a late connection replaces the
 * set instead of failing on duplicate names.
 * @returns how many tools are now registered.
 */
function registerTools(state: BridgeState, ctx: Context, withAttachments: AttachmentsRunner): number {
  for (const dispose of state.toolDisposers) dispose()
  state.toolDisposers = []
  for (const info of state.tools) {
    try {
      state.toolDisposers.push(ctx.tools.register(createToolDefinition(state, info, withAttachments)))
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      ctx.logger('dsh-paper-design').warn(`failed to register ${info.publicName}: ${message}`)
    }
  }
  return state.toolDisposers.length
}

/**
 * Connect, discover, and publish the Paper tools. Safe to call repeatedly:
 * Paper Desktop is often started long after DSH boots, so the same path serves
 * the initial attempt, the background retry, and `/paper-reconnect`.
 */
async function connectBridge(
  state: BridgeState,
  ctx: Context,
  withAttachments: AttachmentsRunner,
): Promise<ConnectionResult> {
  const initialize = await state.client.initialize()
  if (initialize.error) return { ok: false, toolCount: state.toolDisposers.length, error: initialize.error.message }
  const discoveryError = await discoverTools(state)
  if (discoveryError !== undefined) return { ok: false, toolCount: state.toolDisposers.length, error: discoveryError }
  return { ok: true, toolCount: registerTools(state, ctx, withAttachments) }
}

/**
 * Apply the bridge: register the prompt section, skills, and commands first so
 * the recovery surface exists even when Paper Desktop is closed, then connect
 * and publish tools. While the server is unreachable the plugin keeps retrying
 * in the background, because DSH is typically booted long before Paper Desktop.
 */
export function apply(ctx: Context, config: BridgeConfig = {}) {
  ctx.effect(async function* () {
    const endpoint = config.endpoint ?? MCP_URL
    const retryMs = config.retryMs ?? DEFAULT_RETRY_MS
    const client = new PaperMcpClient(endpoint)
    const auth = new PaperAuthManager(endpoint)
    const state: BridgeState = {
      client,
      auth,
      tools: [],
      guideText: null,
      injectTurnsLeft: PAPER_GUIDE_INJECT_TURNS,
      sessionTurns: new Map(),
      toolDisposers: [],
    }

    // Auth manager owns OAuth discovery/token storage; the client attaches
    // any bearer token and reports 401/403 challenges back to it.
    await auth.init()
    client.setAuthProvider(auth)

    // Resolved per call, so an attachment store mounted later is still honored.
    const withAttachments: AttachmentsRunner = async (fn) => {
      await fn(resolveAttachments(ctx))
    }

    // Prompt section: standing rules always; full guide for early turns.
    const sectionDisposer = ctx.systemPrompt.section({
      name: 'paper-design:standing',
      order: STANDING_SECTION_ORDER,
      text: (context) => {
        const agentId = (context as { agent?: { id?: string } }).agent?.id
        const includeGuide = agentId !== undefined && includeGuideFor(state, agentId)
        const authLine = renderAuthLine(state.auth.status())
        return buildPaperSystemPromptSuffix({
          includeGuide,
          guideText: state.guideText,
        }) + authLine
      },
    })

    // Observe session/event (global) to count turn starts per session id.
    const sessionObserver = ctx.on('session/event', (session, event) => {
      if (typeof (session as { id?: unknown }).id === 'string') {
        countTurnStarts(state, (session as { id: string }).id, event)
      }
    }, { global: true })

    // Register skills when the profile mounts a skill registry.
    const skillsService = ctx.get('skills')
    const skillsDisposer = skillsService === undefined
      ? (): void => {}
      : applySkills(skillsService)

    // `commands` is optional by design: a profile without the commands service
    // must still get the tools and the prompt section.
    const commandsService = ctx.get('commands')
    if (commandsService === undefined) {
      ctx.logger('dsh-paper-design').warn('commands service is not mounted; /paper-* commands are unavailable')
    }
    const registerCommand = (definition: CommandDefinition): (() => void) =>
      commandsService === undefined ? (): void => {} : commandsService.register(definition)

    // /paper-reconnect: reconnect AND republish the tools. The initial attempt
    // may have failed because Paper Desktop was closed when DSH booted, so this
    // must be able to publish the tools later rather than only refreshing state.
    const commandDisposer = registerCommand({
      name: 'paper-reconnect',
      description: 'Reconnect to the Paper Desktop MCP server, (re)register the paper_* tools, and refresh the guide cache.',
      handler: async () => {
        const result = await attempt()
        if (!result.ok) return { kind: 'error', text: `Paper MCP reconnect failed: ${result.error}` }
        state.guideText = null
        state.injectTurnsLeft = PAPER_GUIDE_INJECT_TURNS
        state.sessionTurns.clear()
        return {
          kind: 'success',
          text: `Paper MCP connected; ${result.toolCount} paper_* tools registered. Guide cache and injection budget refreshed.`,
        }
      },
    })

    // /paper-auth-status: report the current auth state without side effects.
    const authStatusDisposer = registerCommand({
      name: 'paper-auth-status',
      description: 'Show Paper MCP authentication state (unauthenticated localhost vs OAuth-configured).',
      handler: async () => {
        const status = state.auth.status()
        const lines: string[] = [
          `Paper MCP auth (${status.mode}):`,
          `  server: ${status.serverUrl}`,
          `  configured: ${status.configured ? 'yes' : 'no'}`,
          `  authenticated: ${status.authenticated ? 'yes' : 'no'}`,
        ]
        if (status.expiresAt !== undefined) {
          lines.push(`  access token expires: ${new Date(status.expiresAt).toISOString()}`)
        }
        if (status.discovery !== undefined) {
          lines.push('  OAuth discovery:')
          if (status.discovery.issuer !== undefined) lines.push(`    issuer: ${status.discovery.issuer}`)
          if (status.discovery.authorizationEndpoint !== undefined) {
            lines.push(`    authorization endpoint: ${status.discovery.authorizationEndpoint}`)
          }
          if (status.discovery.tokenEndpoint !== undefined) {
            lines.push(`    token endpoint: ${status.discovery.tokenEndpoint}`)
          }
        }
        if (status.challenge !== undefined) {
          lines.push(`  last challenge: ${status.challenge}`)
        }
        if (status.lastError !== undefined) {
          lines.push(`  last error: ${status.lastError}`)
        }
        return { kind: 'success', text: lines.join('\n') }
      },
    })

    // /paper-auth-login: start the OAuth authorization flow (loops back to the
    // loopback receiver; the URL is also returned for the user to open).
    const authLoginDisposer = registerCommand({
      name: 'paper-auth-login',
      description: 'Start the Paper MCP OAuth authorization flow (PKCE, loopback redirect).',
      handler: async () => {
        const status = state.auth.status()
        if (status.mode !== 'oauth') {
          return {
            kind: 'error',
            text: 'Paper Desktop MCP does not advertise OAuth; it is unauthenticated on localhost. No login needed.',
          }
        }
        try {
          const { url } = await state.auth.beginAuthorization()
          openBrowser(url)
          return {
            kind: 'success',
            text: `Paper authorization started. If the browser did not open, visit:
${url}`,
          }
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error)
          return { kind: 'error', text: `Paper authorization failed: ${message}` }
        }
      },
    })

    // /paper-auth-logout: drop stored tokens.
    const authLogoutDisposer = registerCommand({
      name: 'paper-auth-logout',
      description: 'Clear stored Paper MCP OAuth tokens.',
      handler: async () => {
        await state.auth.logout()
        return { kind: 'success', text: 'Paper MCP OAuth tokens cleared.' }
      },
    })

    // Connect to Paper Desktop. DSH is normally booted long before Paper is
    // opened, so a failed first attempt must not be terminal: keep retrying in
    // the background and publish the tools as soon as the server answers.
    let retryTimer: ReturnType<typeof setTimeout> | undefined
    let polling = false
    const stopPolling = (): void => {
      polling = false
      if (retryTimer !== undefined) {
        clearTimeout(retryTimer)
        retryTimer = undefined
      }
    }
    const attempt = async (): Promise<ConnectionResult> => {
      const result = await connectBridge(state, ctx, withAttachments)
      if (result.ok) stopPolling()
      return result
    }
    const scheduleRetry = (): void => {
      if (!polling) return
      retryTimer = setTimeout(() => {
        retryTimer = undefined
        void (async () => {
          if (!polling) return
          const result = await attempt()
          if (result.ok) {
            ctx.logger('dsh-paper-design').info(
              `Paper MCP connected at ${endpoint}; registered ${result.toolCount} paper_* tools.`,
            )
          } else {
            scheduleRetry()
          }
        })()
      }, retryMs)
      // A pending retry must never hold the host process open.
      const handle = retryTimer as unknown as { unref?: () => void }
      if (typeof handle.unref === 'function') handle.unref()
    }

    polling = true
    const initialConnection = await attempt()
    if (initialConnection.ok) {
      ctx.logger('dsh-paper-design').info(
        `Paper MCP connected at ${endpoint}; registered ${initialConnection.toolCount} paper_* tools.`,
      )
    } else {
      ctx.logger('dsh-paper-design').warn(
        `Paper MCP unavailable at ${endpoint}: ${initialConnection.error}. `
        + 'No paper_* tools are registered yet; they appear automatically once Paper Desktop is '
        + `running with a file open (retrying every ${retryMs}ms), or run /paper-reconnect.`,
      )
      scheduleRetry()
    }

    yield () => {
      stopPolling()
      for (const dispose of state.toolDisposers) dispose()
      skillsDisposer()
      commandDisposer()
      authStatusDisposer()
      authLoginDisposer()
      authLogoutDisposer()
      sectionDisposer()
      sessionObserver()
      state.auth.dispose()
    }
  })
}
