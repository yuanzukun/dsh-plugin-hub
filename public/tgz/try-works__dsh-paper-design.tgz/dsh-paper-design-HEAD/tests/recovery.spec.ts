/**
 * Regression tests for the "Paper Desktop opened after DSH booted" failure:
 * the bridge used to attempt one connection during activation and then give up
 * for the life of the process, leaving zero paper_* tools even though
 * /paper-reconnect reported success.
 *
 * These tests use a stub MCP server so they do not need Paper Desktop running.
 */
import { describe, it, expect, afterEach } from 'vitest'
import { createServer, type Server } from 'node:http'
import type { AddressInfo } from 'node:net'
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { Context } from '@deepseek-ai/cordis'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import CommandRuntime from '@deepseek-ai/dsh-commands'
import SkillRegistry from '@deepseek-ai/dsh-skill'
import * as plugin from '../src/index.ts'

const require = createRequire(import.meta.url)
const fixtureTools: unknown[] = JSON.parse(
  readFileSync(require.resolve('../scripts/fixtures/paper-tools.json'), 'utf8'),
) as unknown[]

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms))

/** Ask the OS for a free port, then release it so the port starts closed. */
async function freePort(): Promise<number> {
  const probe = createServer()
  await new Promise<void>(resolve => probe.listen(0, '127.0.0.1', resolve))
  const { port } = probe.address() as AddressInfo
  await new Promise<void>(resolve => probe.close(() => resolve()))
  return port
}

/** Minimal Streamable-HTTP MCP server standing in for Paper Desktop. */
function stubMcp(): Server {
  return createServer((req, res) => {
    let body = ''
    req.on('data', chunk => { body += chunk })
    req.on('end', () => {
      let message: { id?: unknown; method?: string } = {}
      try { message = JSON.parse(body || '{}') } catch { /* ignore */ }
      const send = (payload: unknown) => {
        res.writeHead(200, { 'content-type': 'application/json', 'mcp-session-id': 'stub' })
        res.end(JSON.stringify(payload))
      }
      switch (message.method) {
        case 'initialize':
          return send({
            jsonrpc: '2.0',
            id: message.id,
            result: {
              protocolVersion: '2024-11-05',
              capabilities: { tools: {} },
              serverInfo: { name: 'paper-stub', version: '1.0.0' },
            },
          })
        case 'notifications/initialized':
          res.writeHead(202)
          return res.end()
        case 'tools/list':
          return send({ jsonrpc: '2.0', id: message.id, result: { tools: fixtureTools } })
        case 'tools/call':
          return send({
            jsonrpc: '2.0',
            id: message.id,
            result: { content: [{ type: 'text', text: JSON.stringify({ artboards: [] }) }] },
          })
        default:
          return send({ jsonrpc: '2.0', id: message.id, error: { code: -32601, message: 'unsupported' } })
      }
    })
  })
}

const openServers: Server[] = []

async function listen(server: Server, port: number): Promise<void> {
  openServers.push(server)
  await new Promise<void>(resolve => server.listen(port, '127.0.0.1', resolve))
}

afterEach(async () => {
  for (const server of openServers.splice(0)) {
    await new Promise<void>(resolve => server.close(() => resolve()))
  }
})

/** Mount the services the bridge needs, then the bridge itself. */
async function mountBridge(config: { endpoint: string; retryMs: number }) {
  const ctx = new Context()
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(CommandRuntime)
  await ctx.plugin(SkillRegistry)

  // Capture command handlers so a test can invoke /paper-reconnect directly.
  const handlers = new Map<string, () => Promise<unknown>>()
  const commands = ctx.commands as unknown as {
    register: (definition: { name: string; handler: () => Promise<unknown> }) => () => void
  }
  const register = commands.register.bind(commands)
  commands.register = (definition) => {
    handlers.set(definition.name, definition.handler)
    return register(definition)
  }

  const fiber = await ctx.plugin(plugin as never, config as never)
  return { ctx, fiber, handlers }
}

const paperToolNames = (ctx: Context): string[] =>
  ctx.tools.schemas().map(schema => schema.name).filter(name => name.startsWith('paper_'))

describe('paper bridge recovery when Paper Desktop starts late', () => {
  it('publishes the tools automatically once the server appears', async () => {
    const port = await freePort()
    const { ctx, fiber } = await mountBridge({
      endpoint: `http://127.0.0.1:${port}/mcp`,
      retryMs: 150,
    })

    // Phase 1: server down. No tools, but the recovery surface must exist.
    await sleep(500)
    expect(paperToolNames(ctx)).toHaveLength(0)

    // Phase 2: Paper Desktop "opens" 16 hours later.
    await listen(stubMcp(), port)
    let names: string[] = []
    for (let i = 0; i < 60 && names.length === 0; i++) {
      await sleep(100)
      names = paperToolNames(ctx)
    }
    expect(names.length).toBe(fixtureTools.length)
    expect(names).toContain('paper_get_basic_info')
    expect(names).toContain('paper_get_screenshot')

    await (fiber as unknown as { dispose: () => Promise<void> }).dispose()
    expect(paperToolNames(ctx)).toHaveLength(0)
  }, 30_000)

  it('/paper-reconnect publishes tools when the first attempt failed', async () => {
    const port = await freePort()
    // A long retry interval keeps the background poller out of this test.
    const { ctx, fiber, handlers } = await mountBridge({
      endpoint: `http://127.0.0.1:${port}/mcp`,
      retryMs: 60_000,
    })

    await sleep(400)
    expect(paperToolNames(ctx)).toHaveLength(0)

    // The command must be registered even though the MCP server was absent.
    const reconnect = handlers.get('paper-reconnect')
    expect(reconnect).toBeTypeOf('function')

    await listen(stubMcp(), port)

    const result = await reconnect?.() as { kind: string; text: string }
    expect(result.kind).toBe('success')
    expect(result.text).toContain('paper_* tools registered')
    expect(paperToolNames(ctx).length).toBe(fixtureTools.length)

    await (fiber as unknown as { dispose: () => Promise<void> }).dispose()
  }, 30_000)
})
