/** Workspace-confined path validation and resolution helpers. */
import { isAbsolute, relative, resolve, sep } from 'node:path'
import { lstat, realpath } from 'node:fs/promises'
import { Buffer } from 'node:buffer'
import { HttpError } from './errors.js'
export function normalizeRelativePath(value) {
  if (typeof value !== 'string') throw new HttpError(400, 'invalid-path', '文件路径必须是工作区内的相对路径')
  if (value === '') return ''
  if (/\u0000|[\u0001-\u001f\u007f\u2028\u2029]/u.test(value)
    || value.includes('\\') || value.startsWith('/') || isAbsolute(value)
    /* Colons are illegal in Windows names and drive-relative forms (`C:` -> the workspace root, `a:b` -> another drive) resolve surprisingly under path.win32.resolve: reject them on Windows so no request can alias the root or probe other drives; POSIX keeps them. */
    || (process.platform === 'win32' && value.includes(':'))) {
    throw new HttpError(400, 'invalid-path', '文件路径必须是工作区内的相对路径')
  }
  const parts = value.split('/')
  if (parts.some(part => part === '' || part === '.' || part === '..')) {
    throw new HttpError(400, 'invalid-path', '文件路径包含无效段')
  }
  /* Windows name rules apply per segment (normalizeEntryName guards only the final name): a MIDDLE `foo.` aliases `foo` on NTFS, and `CON` fails with a raw EINVAL normalizeFailure does not classify. */
  for (const part of parts) {
    if (/[. ]$/.test(part)) throw new HttpError(400, 'invalid-path', '路径段不能以点或空格结尾')
    const base = part.split('.')[0].toUpperCase()
    /* CONIN$/CONOUT$ are also reserved NT namespace names (raw EINVAL on access) even though they do not match the COMMON device-name rule. */
    if (/^(CON|PRN|AUX|NUL|CONIN\$|CONOUT\$|COM[1-9]|LPT[1-9])$/.test(base)) {
      throw new HttpError(400, 'invalid-path', '路径段不能使用 Windows 保留名称')
    }
  }
  return parts.join('/')
}
export function isInside(root, target) {
  const tail = relative(root, target)
  return tail === '' || (tail !== '..' && !tail.startsWith(`..${sep}`) && !isAbsolute(tail))
}
export async function resolveWorkspacePath(root, relativePath) {
  const candidate = relativePath === '' ? root : resolve(root, ...relativePath.split('/'))
  let target
  try {
    target = await realpath(candidate)
  } catch (error) {
    if (error?.code === 'ENOENT' || error?.code === 'ENOTDIR') throw new HttpError(404, 'path-not-found', '文件或目录不存在')
    throw error
  }
  if (!isInside(root, target)) throw new HttpError(403, 'path-outside-workspace', '拒绝访问工作区之外的路径')
  return target
}
export function entryPath(parent, name) {
  return parent === '' ? name : `${parent}/${name}`
}

export function parentPath(path) {
  const index = path.lastIndexOf('/')
  return index < 0 ? '' : path.slice(0, index)
}
export function normalizeEntryName(value, maxEntryNameBytes) {
  if (typeof value !== 'string') throw new HttpError(400, 'invalid-path', '文件名必须是工作区内的单个名称')
  /* Check trailing dot/space on the RAW value: trim() would strip the space and silently turn "a " into "a" instead of refusing it. */
  if (/[. ]$/.test(value)) throw new HttpError(400, 'invalid-path', '文件名不能以点或空格结尾')
  const name = value.trim()
  if (name === '' || name === '.' || name === '..' || name.includes('/') || name.includes('\\')
    || /\u0000|[\u0001-\u001f\u007f\u2028\u2029]/u.test(name)
    /* Same Windows colon rule as normalizeRelativePath: `C:foo` resolves to `foo` and `a:b` becomes drive-relative, so without it a create/rename would land at a DIFFERENT name than the response claims. */
    || (process.platform === 'win32' && name.includes(':'))) {
    throw new HttpError(400, 'invalid-path', '文件名必须是工作区内的单个名称')
  }
  /* Windows refuses names ending in a dot/space or matching its reserved device names (CON, PRN, AUX, NUL, CONIN$/CONOUT$, COM1-9, LPT1-9) even with an extension: reject up front so a create/rename returns a clean 400 instead of a raw 500. Non-Windows hosts keep the rule for consistency. */
  const base = name.split('.')[0].toUpperCase()
  if (/^(CON|PRN|AUX|NUL|CONIN\$|CONOUT\$|COM[1-9]|LPT[1-9])$/.test(base)) {
    throw new HttpError(400, 'invalid-path', '文件名不能使用 Windows 保留名称')
  }
  if (Buffer.byteLength(name, 'utf8') > maxEntryNameBytes) {
    throw new HttpError(413, 'entry-name-too-large', `文件名不能超过 ${maxEntryNameBytes} 字节`)
  }
  return name
}
export async function hasSymlinkComponent(root, relativePath) {
  let current = root
  for (const part of relativePath.split('/')) {
    current = resolve(current, part)
    if ((await lstat(current)).isSymbolicLink()) return true
  }
  return false
}
