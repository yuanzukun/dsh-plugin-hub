/** Self-update support: check this plugin's GitHub repo (main-branch package.json
    version vs the installed version — the repo publishes releases as plain version
    bumps, no tags/releases) and, on request, atomically swap the checked source
    tarball into the installed package directory.

    Transport note: MANY machines redirect github.com / api.github.com /
    raw.githubusercontent.com to a local TLS proxy via hosts entries (GitHub
    accelerators); Node's own CA store rejects that proxy's certificate while
    codeload.github.com is never redirected. The whole check + install path
    therefore uses ONLY codeload.github.com. The check downloads the main-branch
    tarball and CACHES the extracted payload; the install consumes exactly those
    cached bytes (verified again), so no check→install race exists and no commit
    pin is needed.

    The running process keeps executing the OLD code until dsh is restarted, so the
    check reports restartPending (on-disk version vs the version this loaded module
    was built with) for the UI to surface a restart notice. */
import { gunzipSync } from 'node:zlib'
import { readFileSync } from 'node:fs'
import { promises as fsp } from 'node:fs'
import { basename, dirname, join, sep } from 'node:path'
import { fileURLToPath } from 'node:url'
import { homedir } from 'node:os'
import { HttpError } from './errors.js'
import { readJsonStrict, writeJsonAtomic } from './drafts.js'
import { quarantineFile } from './quarantine.js'

const PACKAGE_NAME = '@yishengjun8/dsh-workspace-studio'
const GITHUB_REPO = 'yishengjun8/dsh-workspace-studio'
const GITHUB_BRANCH = 'main'
const USER_AGENT = 'dsh-workspace-studio-updater'
const CHECK_TIMEOUT_MS = 30_000
const DOWNLOAD_TIMEOUT_MS = 120_000
const MAX_TARBALL_BYTES = 50 * 1024 * 1024
const SEMVER_RE = /^\d+\.\d+\.\d+$/
/* Reuse window for the cached check payload: an unforced check with younger metadata skips the (~MB) tarball download; 重新检查 / 重试 pass force=true and always fetch. */
const CHECK_CACHE_TTL_MS = 15 * 60_000
const CHECK_BASE = join(homedir(), '.dsh-plugin', 'dsh-workspace-studio', 'updates')
const CHECKED_META = 'checked.json'
const CHECKED_CONTENT = 'checked-content'

let updateInProgress = false
/* Serialize the checked-content directory exchange: concurrent downloadAndCache calls would interleave their rename pairs — on Windows the second rename fails, and a worse interleaving can leave the meta pointing at content that was renamed over. Downloads may run concurrently; only the exchange is serialized. */
let contentSwapChain = Promise.resolve()

/** Own installed package directory: the host bundle is inlined into a single lib/index.js, so the root is found by walking up from this module's file to the package.json naming this plugin. import.meta.url points at the bundle the profile actually loads, so the swap targets the INSTALLED copy (in the dev layout, the checkout). */
function ownPackageDir() {
  let dir = fileURLToPath(new URL('.', import.meta.url))
  for (let depth = 0; depth < 6; depth += 1) {
    try {
      const pkg = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8'))
      if (typeof pkg?.name === 'string' && pkg.name === PACKAGE_NAME) return dir
    } catch {
      /* keep walking */
    }
    dir = dirname(dir)
  }
  return fileURLToPath(new URL('.', import.meta.url))
}

function readOwnPackageJson() {
  try {
    return JSON.parse(readFileSync(join(ownPackageDir(), 'package.json'), 'utf8'))
  } catch {
    return null
  }
}

/* Version captured when THIS module loaded = the running code's version. After a successful swap the on-disk package.json differs — exactly the "update installed, restart required" signal. */
const LOADED_VERSION = readOwnPackageJson()?.version ?? null

function parseSemver(value) {
  if (typeof value !== 'string' || !SEMVER_RE.test(value.trim())) return null
  return value.trim().split('.').map(Number)
}

/** -1 | 0 | 1, or null when either side is not a plain x.y.z version. */
function compareVersions(a, b) {
  const pa = parseSemver(a)
  const pb = parseSemver(b)
  if (pa === null || pb === null) return null
  for (let i = 0; i < 3; i += 1) {
    if (pa[i] !== pb[i]) return pa[i] < pb[i] ? -1 : 1
  }
  return 0
}

/* Install mode of the profile manifest's dependency spec: 'file' (local checkout / local path — the swap only replaces the profile copy), 'git' (fetched from GitHub, pinned by the profile lockfile), 'other' (anything else, including installs that are not laid out under a profile at all). Every source the README documents must land in one bucket: the settings panel picks its note from this, and the Desktop profile's plugin page writes the `git+https://github.com/...` form — the old `file:`/`github:` prefix test reported that install as 'other', so its note never appeared. */
const GIT_SPEC_PREFIXES = ['git+', 'github:', 'git@', 'git://']
const GITHUB_URL_RE = /^https?:\/\/(?:www\.)?github\.com\//i
const LOCAL_PATH_RE = /^(?:[A-Za-z]:[\\/]|[\\/]|\.{1,2}[\\/])/
function classifySpec(spec) {
  if (spec.startsWith('file:')) return 'file'
  if (GIT_SPEC_PREFIXES.some(prefix => spec.startsWith(prefix))) return 'git'
  if (GITHUB_URL_RE.test(spec)) return 'git'
  if (LOCAL_PATH_RE.test(spec)) return 'file'
  return 'other'
}

/** The profile root this module is installed under, or null. Recognizes the hoisted tree (`<profile>/node_modules/<name>`) and pnpm's virtual store (`<profile>/node_modules/.pnpm/<pkg>@<v>/node_modules/<name>`). A `link:` install resolves import.meta.url to the LINKED directory, so no profile is found — exactly the case the swap must refuse. */
function profileDirOf(packageDir) {
  let dir = packageDir
  for (let depth = 0; depth < 8; depth += 1) {
    if (basename(dir) === 'node_modules') {
      const candidate = dirname(dir)
      if (basename(dirname(candidate)) === 'profiles') return candidate
    }
    const parent = dirname(dir)
    if (parent === dir) break
    dir = parent
  }
  return null
}

/** Resolve the install layout once: the directory the swap would replace, the profile it must belong to, whether it really sits inside that profile's node_modules, and the mode the settings note keys on. */
async function inspectInstall() {
  const packageDir = ownPackageDir()
  const profileDir = profileDirOf(packageDir)
  let installMode = 'other'
  if (profileDir !== null) {
    try {
      const manifest = JSON.parse(await fsp.readFile(join(profileDir, 'package.json'), 'utf8'))
      const spec = manifest?.dependencies?.[PACKAGE_NAME] ?? manifest?.devDependencies?.[PACKAGE_NAME]
      if (typeof spec === 'string') installMode = classifySpec(spec)
    } catch {
      /* unreadable manifest — keep 'other' */
    }
  }
  const nodeModulesDir = profileDir === null ? null : join(profileDir, 'node_modules')
  return {
    packageDir,
    profileDir,
    /* Both sides come from the same walk up from import.meta.url, so a plain prefix test is exact (no case or separator drift). */
    insideProfile: nodeModulesDir !== null
      && (packageDir === nodeModulesDir || packageDir.startsWith(`${nodeModulesDir}${sep}`)),
    installMode,
  }
}

/* Check-cache metadata: an unparseable file, or one lacking the current fields, can never satisfy
   the version comparison below — quarantine it and treat as "no cache yet" (one re-download). */
async function readCheckedMeta() {
  const path = join(CHECK_BASE, CHECKED_META)
  const read = await readJsonStrict(path)
  if (read.status === 'missing') return { version: null, at: 0 }
  if (read.status !== 'ok' || typeof read.value.version !== 'string' || !Number.isFinite(Number(read.value.at))) {
    await quarantineFile(path, 'unusable update-check cache metadata')
    return { version: null, at: 0 }
  }
  return { version: read.value.version, at: Number(read.value.at) }
}

async function cachedContentValid(meta) {
  try {
    const pkg = JSON.parse(await fsp.readFile(join(CHECK_BASE, CHECKED_CONTENT, 'package.json'), 'utf8'))
    return pkg?.name === PACKAGE_NAME && pkg?.version === meta.version
  } catch {
    return false
  }
}

/** Download the main-branch tarball, extract, verify, and atomically refresh the checked cache (extracted payload + meta). Returns the checked version. */
async function downloadAndCache(timeoutMs) {
  await fsp.mkdir(CHECK_BASE, { recursive: true })
  const staging = await fsp.mkdtemp(join(CHECK_BASE, 'dl-'))
  try {
    let response
    try {
      response = await fetch(`https://codeload.github.com/${GITHUB_REPO}/tar.gz/${GITHUB_BRANCH}`, {
        headers: { 'user-agent': USER_AGENT },
        signal: AbortSignal.timeout(timeoutMs),
        redirect: 'follow',
      })
    } catch {
      throw new HttpError(502, 'update-check-failed', '无法连接 GitHub，请检查网络后重试')
    }
    if (!response.ok) {
      throw new HttpError(502, 'update-check-failed', `GitHub 下载失败（HTTP ${response.status}）`)
    }
    const declared = Number(response.headers.get('content-length'))
    if (Number.isFinite(declared) && declared > MAX_TARBALL_BYTES) {
      throw new HttpError(413, 'update-check-failed', '更新包过大，已拒绝下载')
    }
    const bytes = Buffer.from(await response.arrayBuffer())
    if (bytes.byteLength > MAX_TARBALL_BYTES) {
      throw new HttpError(413, 'update-check-failed', '更新包过大，已拒绝下载')
    }
    const tarballPath = join(staging, 'update.tar.gz')
    await fsp.writeFile(tarballPath, bytes)
    /* The tarball extracts to <repo>-<ref>/; resolve the single top-level dir. */
    const extractRoot = join(staging, 'content')
    await fsp.mkdir(extractRoot, { recursive: true })
    await extractTarball(tarballPath, extractRoot)
    const topEntries = (await fsp.readdir(extractRoot, { withFileTypes: true }))
      .filter(entry => entry.isDirectory())
    if (topEntries.length !== 1) {
      throw new HttpError(502, 'update-check-failed', '更新包结构无效')
    }
    const extracted = join(extractRoot, topEntries[0].name)
    let pkg
    try {
      pkg = JSON.parse(await fsp.readFile(join(extracted, 'package.json'), 'utf8'))
    } catch {
      throw new HttpError(502, 'update-check-failed', '更新包缺少有效的 package.json')
    }
    if (pkg?.name !== PACKAGE_NAME || typeof pkg.version !== 'string' || !SEMVER_RE.test(pkg.version)) {
      throw new HttpError(502, 'update-check-failed', '更新包不是本插件或版本无效')
    }
    const version = pkg.version
    await verifyPackage(extracted, version)
    /* Atomically replace the cached payload: old content aside → new in → drop the old; the meta is written only after the content landed, so a crash mid-swap leaves a stale meta whose content check fails (→ the next check re-downloads). Runs under the module-level swap chain so concurrent callers cannot interleave renames. */
    const contentDir = join(CHECK_BASE, CHECKED_CONTENT)
    const runSwap = contentSwapChain.then(async () => {
      const oldContent = join(CHECK_BASE, `${CHECKED_CONTENT}.old-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`)
      try {
        await fsp.rename(contentDir, oldContent)
      } catch (error) {
        if (error?.code !== 'ENOENT') throw error
      }
      try {
        await fsp.rename(extracted, contentDir)
      } catch (error) {
        try { await fsp.rename(oldContent, contentDir) } catch { /* best-effort restore */ }
        throw error
      }
      try {
        await fsp.rm(oldContent, { recursive: true, force: true })
      } catch { /* best-effort cleanup */ }
    })
    contentSwapChain = runSwap.catch(() => {})
    await runSwap
    await writeJsonAtomic(join(CHECK_BASE, CHECKED_META), { version, at: Date.now() })
    return version
  } finally {
    try { await fsp.rm(staging, { recursive: true, force: true }) } catch { /* best-effort cleanup */ }
  }
}

/** Local-only facts for the settings panel's permanently visible 「当前版本」 badge: the on-disk version in this profile, the install mode, whether the swap target is a profile copy, and whether the running code is stale (an update landed after startup). No network, no cache write, no install mutation — the panel can call it the moment it opens (and offline). */
export async function installedInfo(config) {
  const disk = readOwnPackageJson()
  const current = typeof disk?.version === 'string' ? disk.version : null
  const install = await inspectInstall()
  return {
    enabled: config.enableUpdateCheck !== false,
    current,
    installMode: install.installMode,
    /* False when the swap target is not a copy inside a profile (a link: install resolves to the linked directory, a built-in one into the app bundle): the client then explains instead of offering a download whose request would be refused, and downloadUpdate refuses it too. */
    updateSupported: install.insideProfile,
    /* On-disk version differs from the version this loaded module was built with: an update (or a host rebuild) landed after startup, so the running code is stale until the user restarts dsh. */
    restartPending: current !== null && LOADED_VERSION !== null && current !== LOADED_VERSION,
  }
}

/** Query the repo (codeload tarball, cached for CHECK_CACHE_TTL_MS unless force) and compare against the installed version. Never mutates the installation. */
export async function checkForUpdate(ctx, config, force) {
  if (config.enableUpdateCheck === false) return { enabled: false }
  let fresh = false
  const meta = await readCheckedMeta()
  if (force !== true && meta.version !== null && Date.now() - meta.at < CHECK_CACHE_TTL_MS) {
    fresh = await cachedContentValid(meta)
  }
  const latest = fresh ? meta.version : await downloadAndCache(CHECK_TIMEOUT_MS)
  const local = await installedInfo(config)
  if (local.current === null) {
    throw new HttpError(500, 'update-check-failed', '无法读取插件自身的 package.json')
  }
  const cmp = compareVersions(latest, local.current)
  return {
    ...local,
    enabled: true,
    latest,
    updateAvailable: cmp !== null && cmp > 0,
  }
}

function readTarString(block, offset, length) {
  const end = block.indexOf(0, offset)
  const limit = end === -1 ? offset + length : Math.min(end, offset + length)
  return block.subarray(offset, limit).toString('utf8')
}

function parseOctal(block, offset, length) {
  const raw = readTarString(block, offset, length).trim()
  if (raw === '') return 0
  if (!/^[0-7]+$/.test(raw)) return -1
  return parseInt(raw, 8)
}

function parsePaxRecords(data) {
  const records = []
  let cursor = 0
  while (cursor < data.length) {
    const space = data.indexOf(0x20, cursor)
    if (space === -1) break
    const length = Number(data.subarray(cursor, space).toString('ascii'))
    if (!Number.isInteger(length) || length <= 0 || cursor + length > data.length) break
    const record = data.subarray(space + 1, cursor + length).toString('utf8')
    const eq = record.indexOf('=')
    if (eq !== -1) {
      /* pax values are newline-terminated ("len key=value\n"); that newline is record framing, NOT part of the value — a 'path' carrying it would extract a name with an embedded newline. */
      records.push({ key: record.slice(0, eq), value: record.slice(eq + 1).replace(/\r?\n$/, '') })
    }
    cursor += length
  }
  return records
}

/* Tar-entry path guard: pax/GNU overrides come from the archive itself, so every extracted path is validated against traversal before touching disk. */
function validEntryPath(path) {
  if (typeof path !== 'string' || path === '') return false
  if (path.startsWith('/') || path.includes('\\')) return false
  const parts = path.split('/')
  if (parts.some(part => part === '' || part === '.' || part === '..')) return false
  /* Windows strips trailing dots/spaces from path components when resolving (NTFS aliasing): a segment like `.. ` resolves as `..` and `a.` as `a`, so a crafted archive could write outside destDir. Reject trailing dot/space segments on every platform. */
  if (parts.some(part => /[. ]$/.test(part))) return false
  return true
}

/** Minimal tar extraction: gunzip (node:zlib) + a ustar reader that also understands pax extended headers ('x' — git archive emits these for long paths) and GNU long names ('L'). Regular files/directories only; any other entry type or invalid path fails the archive. */
async function extractTarball(tarballPath, destDir) {
  let tar
  try {
    tar = gunzipSync(await fsp.readFile(tarballPath))
  } catch {
    throw new HttpError(502, 'update-check-failed', '下载的更新包无法解压')
  }
  let offset = 0
  let pendingPath = null // pax 'path' / GNU longname for the NEXT entry
  while (offset + 512 <= tar.length) {
    const block = tar.subarray(offset, offset + 512)
    if (block.every(byte => byte === 0)) break // end-of-archive zero blocks
    const rawName = readTarString(block, 0, 100)
    const type = String.fromCharCode(block[156])
    const size = parseOctal(block, 124, 12)
    const prefix = readTarString(block, 345, 155)
    const dataStart = offset + 512
    if (size < 0 || dataStart + size > tar.length) {
      throw new HttpError(502, 'update-check-failed', '更新包格式无效')
    }
    const data = tar.subarray(dataStart, dataStart + size)
    offset = dataStart + size + (size % 512 === 0 ? 0 : 512 - (size % 512))
    if (type === 'x' || type === 'g') {
      for (const record of parsePaxRecords(data)) {
        if (record.key === 'path') pendingPath = record.value
      }
      continue
    }
    if (type === 'L') {
      pendingPath = readTarString(data, 0, data.length)
      continue
    }
    const entryPath = (pendingPath !== null ? pendingPath : (prefix !== '' ? `${prefix}/${rawName}` : rawName)).replace(/\/+$/, '')
    pendingPath = null
    if (!validEntryPath(entryPath)) {
      throw new HttpError(502, 'update-check-failed', '更新包包含非法路径')
    }
    const target = join(destDir, ...entryPath.split('/'))
    if (type === '5') {
      await fsp.mkdir(target, { recursive: true })
    } else if (type === '0' || type === '\0') {
      await fsp.mkdir(dirname(target), { recursive: true })
      await fsp.writeFile(target, data)
    } else {
      throw new HttpError(502, 'update-check-failed', `更新包包含不支持的条目（${type}）`)
    }
  }
}

async function verifyPackage(dir, expectedVersion) {
  let pkg
  try {
    pkg = JSON.parse(await fsp.readFile(join(dir, 'package.json'), 'utf8'))
  } catch {
    throw new HttpError(502, 'update-verify-failed', '更新包缺少有效的 package.json')
  }
  if (pkg?.name !== PACKAGE_NAME) {
    throw new HttpError(502, 'update-verify-failed', '更新包不是本插件')
  }
  if (pkg?.version !== expectedVersion) {
    throw new HttpError(502, 'update-verify-failed', `更新包版本与检查结果不一致（${String(pkg?.version)} ≠ ${expectedVersion}）`)
  }
  for (const required of ['lib/index.js', 'lib/client.js', 'cordis.patch.yml']) {
    try {
      if (!(await fsp.stat(join(dir, required))).isFile()) throw new Error('not a file')
    } catch {
      throw new HttpError(502, 'update-verify-failed', `更新包缺少 ${required}`)
    }
  }
}

function uniqueSuffix() {
  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`
}

/** Atomic swap: rename the installed package dir aside, move the verified new copy in, re-verify, then KEEP the backup (a dev-layout install would otherwise destroy the previous working copy, including uncommitted changes). Any failure rolls back to the backup before surfacing. */
async function swapPackage(extractedDir, version) {
  const packageDir = ownPackageDir()
  const parent = dirname(packageDir)
  const base = basename(packageDir)
  const backup = join(parent, `.${base}.bak-${uniqueSuffix()}`)
  try {
    await fsp.rename(packageDir, backup)
  } catch (error) {
    throw new HttpError(409, 'update-swap-failed', `无法移动当前安装（可能正被占用）：${error instanceof Error ? error.message : String(error)}`)
  }
  try {
    await fsp.rename(extractedDir, packageDir)
  } catch (error) {
    try { await fsp.rename(backup, packageDir) } catch { /* best-effort restore */ }
    throw new HttpError(409, 'update-swap-failed', `无法写入新版本：${error instanceof Error ? error.message : String(error)}`)
  }
  try {
    await verifyPackage(packageDir, version)
    /* Keep the backup directory (do NOT rm it): the previous copy is the user's only rollback if the new version misbehaves, and in a dev layout it holds the checkout's uncommitted work. Log its location so it can be removed manually once the new version is confirmed. */
    console.warn(`[workspace-studio] update installed; previous copy kept at ${backup} (remove it once the new version is confirmed)`)
  } catch (error) {
    try {
      await fsp.rm(packageDir, { recursive: true, force: true })
      await fsp.rename(backup, packageDir)
    } catch { /* give up on rollback */ }
    throw error
  }
}

/** Install the version the client received from the check: the payload is the CACHED checked tarball content (re-verified), fetched again only when the cache is missing or its version no longer matches — the user must then re-check first. Staging/swap shares the install's volume in the standard layout; a cross-volume failure surfaces as a clear swap error and the backup rollback keeps the old install intact. */
export async function downloadUpdate(ctx, config, payload) {
  if (config.enableUpdateCheck === false) {
    throw new HttpError(403, 'update-disabled', '已禁用检查更新')
  }
  const version = typeof payload?.version === 'string' && SEMVER_RE.test(payload.version) ? payload.version : null
  if (version === null) {
    throw new HttpError(400, 'update-invalid-request', '更新请求缺少有效的版本信息')
  }
  if (updateInProgress) {
    throw new HttpError(409, 'update-in-progress', '已有更新任务正在进行')
  }
  updateInProgress = true
  try {
    const contentDir = join(CHECK_BASE, CHECKED_CONTENT)
    const meta = await readCheckedMeta()
    if (!(meta.version === version && await cachedContentValid(meta))) {
      /* The checked payload is gone or stale (e.g. a cleared updates dir, or the user checked a long time ago): re-check NOW and compare — the install must match the version the user was shown. */
      const fresh = await downloadAndCache(DOWNLOAD_TIMEOUT_MS)
      if (fresh !== version) {
        throw new HttpError(409, 'update-version-changed', '检查结果已过期，请重新检查后再更新')
      }
    }
    const install = await inspectInstall()
    /* Refuse BEFORE downloading or touching anything when the swap target is not a copy inside this profile: a link: install resolves import.meta.url to the LINKED directory (the user's own checkout), so the swap below would rename that tree away instead of a profile copy. */
    if (!install.insideProfile) {
      throw new HttpError(409, 'update-target-unsupported', `当前安装不在 profile 内（${install.packageDir}），已拒绝自动更新；请从插件页重装`)
    }
    /* Consume the cached content under the SAME swap chain as downloadAndCache: a concurrent forced check renames checked-content away between cachedContentValid() and the install's renames — the install would fail (ENOENT → 409) or the verify-rollback would destroy the racing download's cached payload. */
    const runInstall = contentSwapChain.then(() => swapPackage(contentDir, version))
    contentSwapChain = runInstall.catch(() => {})
    await runInstall
    return { ok: true, version, installMode: install.installMode }
  } catch (error) {
    if (error instanceof HttpError) throw error
    try { ctx.logger?.warn?.(`[workspace-studio] update failed: ${String(error)}`) } catch { /* no logger */ }
    throw new HttpError(500, 'update-swap-failed', `更新失败：${error instanceof Error ? error.message : String(error)}`)
  } finally {
    updateInProgress = false
  }
}
