/* Change-review resources: the bridge from the harness chat's
 * `ctx.sidebarRight.openResource` path into this plugin's own preview column.
 *
 * The chat's changed-files card asks ui-deliverables to open
 * `dsh-resource://changes-review/session/<sessionId>/<seq>/<turn>` in the harness
 * right Sidebar. This root layout never mounts that seat, so the address would
 * reach no surface and the shipped implementation would throw "no session surface
 * is mounted". This module recognizes the address, carries the requested file
 * index to the mounted explorer, and reads the two Host routes ui-deliverables
 * itself reads — the summary and one file's comparison — so the plugin renders
 * the review without re-deriving anything the Host already computed and without
 * writing to the session log.
 *
 * The address grammar, route paths, and payload shapes mirror
 * @deepseek-ai/dsh-client-ui-deliverables' changes.ts/host-read-store.ts, so the
 * bundle needs no new harness dependency.
 */
import { REVIEW_DIFF_MIN, REVIEW_LIST_DEFAULT, REVIEW_LIST_MAX_FALLBACK, REVIEW_LIST_MIN } from './constants.js'
import { readHarnessJson } from './api.js'
import { isAbsoluteWorkspacePath, joinAbsolutePath, normalizeAbsolutePath } from './paths.js'
import { createRequestStore } from './request-store.js'

/* Resource-address prefix of one turn's review; the tail is
   `<percent-encoded sessionId>/<seq>/<turn>`. */
const REVIEW_PREFIX = 'dsh-resource://changes-review/session/'

/* Document-relative Host routes (no leading slash), the same URLs the harness client
   fetches: they sit inside the connection's authentication fence, so a same-origin
   fetch from this bundle is authenticated exactly like the harness's own read. */
const CHANGES_SUMMARY_ROUTE = 'api/changes.summary'
const CHANGES_DIFF_ROUTE = 'api/changes.diff'

/* The view draws at most this many comparison lines, the same cap
   ui-deliverables applies in its own review tab. */
export const MAX_RENDERED_LINES = 5000

/**
 * Recognize a change-review resource address.
 * @param address - a caller-supplied `dsh-resource://…` address.
 * @returns the review coordinates, or undefined for any other address.
 */
export function parseChangesReviewAddress(address) {
  if (typeof address !== 'string' || !address.startsWith(REVIEW_PREFIX)) return undefined
  const parts = address.slice(REVIEW_PREFIX.length).split('/')
  if (parts.length !== 3) return undefined
  const [rawId, seq, turn] = parts
  if (rawId === '' || !/^\d+$/.test(seq) || !/^[1-9]\d*$/.test(turn)) return undefined
  const seqNumber = Number(seq)
  const turnNumber = Number(turn)
  if (!Number.isSafeInteger(seqNumber) || !Number.isSafeInteger(turnNumber)) return undefined
  try {
    return { sessionId: decodeURIComponent(rawId), seq: seqNumber, turn: turnNumber }
  } catch {
    // decodeURIComponent throws URIError on a malformed escape: not an address this package minted.
    return undefined
  }
}

/** Document-relative URL of one announced change summary (authenticated inside the connection's fence). */
function changesSummaryUrl(sessionId, seq) {
  return `${CHANGES_SUMMARY_ROUTE}?${new URLSearchParams({ sessionId: String(sessionId), seq: String(seq) })}`
}

/** Document-relative URL of one listed file's turn-start / turn-end comparison. */
function changesDiffUrl(sessionId, seq, index) {
  return `${CHANGES_DIFF_ROUTE}?${new URLSearchParams({ sessionId: String(sessionId), seq: String(seq), index: String(index) })}`
}

function isRecord(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function isCount(value) {
  return Number.isSafeInteger(value) && value >= 0
}

/** Whether one changed-file record carries a path, a display path and line counts. */
function isChangedFile(value) {
  if (!isRecord(value)) return false
  const { path, display, added, deleted, binary, oversized } = value
  return typeof path === 'string' && path.length > 0 && typeof display === 'string' && display.length > 0
    && isCount(added) && isCount(deleted)
    && (binary === undefined || binary === true) && (oversized === undefined || oversized === true)
}

/** Whether a summary identifies a turn, a complete file list and the line totals. */
function isChangesSummary(value) {
  if (!isRecord(value)) return false
  const { turn, files, total, added, deleted } = value
  return Number.isSafeInteger(turn) && turn >= 1 && isCount(total) && isCount(added) && isCount(deleted)
    && Array.isArray(files) && files.every(isChangedFile)
}

function isHunk(value) {
  if (!isRecord(value)) return false
  const { oldStart, oldLines, newStart, newLines, lines } = value
  return [oldStart, oldLines, newStart, newLines].every(isCount)
    && Array.isArray(lines) && lines.every(line => typeof line === 'string' && /^[+ -]/.test(line))
}

/** Whether a comparison is a text diff with well-formed hunks, or a binary/oversized refusal. */
function isChangesDiff(value) {
  if (!isRecord(value)) return false
  const { kind, path, display } = value
  if (typeof path !== 'string' || path.length === 0 || typeof display !== 'string' || display.length === 0) return false
  if (kind === 'binary' || kind === 'oversized') return true
  if (kind !== 'text') return false
  const { before, after, hunks, coarse } = value
  return typeof before === 'boolean' && typeof after === 'boolean' && typeof coarse === 'boolean'
    && Array.isArray(hunks) && hunks.every(isHunk)
}

/* One drawn line of a hunk, numbered on each side: context counts on both, deletions
   on the old side, additions on the new (the shipped rule). */
export function hunkRows(hunk) {
  let oldNo = hunk.oldStart
  let newNo = hunk.newStart
  return hunk.lines.map((line) => {
    const text = line.slice(1)
    switch (line[0]) {
      case '+': return { kind: 'add', old: undefined, new: newNo++, text }
      case '-': return { kind: 'del', old: oldNo++, new: undefined, text }
      default: return { kind: 'context', old: oldNo++, new: newNo++, text }
    }
  })
}

/** The `@@ … @@` range header of one hunk. */
export function hunkHeader(hunk) {
  return `@@ -${hunk.oldStart},${hunk.oldLines} +${hunk.newStart},${hunk.newLines} @@`
}

/** The hunks to draw, cut at {@link MAX_RENDERED_LINES} total: a turn that rewrote a huge file
 * must not build an unbounded DOM. */
export function cappedHunks(hunks) {
  const kept = []
  let budget = MAX_RENDERED_LINES
  for (const hunk of hunks) {
    if (budget === 0) return { hunks: kept, truncated: true }
    kept.push(hunk.lines.length <= budget ? hunk : { ...hunk, lines: hunk.lines.slice(0, budget) })
    budget -= Math.min(budget, hunk.lines.length)
  }
  return { hunks: kept, truncated: kept.some((hunk, at) => hunk !== hunks[at]) }
}

/**
 * Resolve one listed file's `path` into what a file-open request needs.
 *
 * The summary spells `path` relative to the Session's cwd, and may spell it absolute for a file
 * outside it. With the cwd known the result is absolute, so the request decides inside-versus-outside
 * against the workspace root; without it only a path that stays inside the root can be requested at
 * all — a `..` segment with no cwd is exactly the case that cannot be resolved here.
 */
export function resolveReviewFilePath(cwd, path) {
  if (typeof path !== 'string' || path === '') return undefined
  const normalized = path.replace(/\\/g, '/')
  if (isAbsoluteWorkspacePath(normalized)) return normalizeAbsolutePath(normalized)
  if (typeof cwd === 'string' && cwd !== '') return normalizeAbsolutePath(joinAbsolutePath(cwd, normalized))
  return normalized.split('/').includes('..') ? undefined : normalized
}

/* Read one JSON route into its view state through `readHarnessJson` (document-relative URL, shared
   timeout/error contract). A non-OK answer, or a payload that fails validation (Host and bundle
   disagree about a shape the view could not render), becomes `failed`; an aborted read stays a
   rejection so its caller ignores it. Nothing is cached module-wide — each mounted tab holds its own
   state, so a Host restart can never leave a stale "missing" answer standing. */
async function readJson(url, signal, failed, decode) {
  try {
    const value = await readHarnessJson(url, signal)
    return decode(value) ?? failed
  } catch (error) {
    if (error?.name === 'AbortError') throw error
    /* A 404 is re-thrown: the diff route maps it to `missing`, which is a different answer from a
       transport failure. */
    if (error?.status === 404) throw error
    return failed
  }
}

/** The summary, or `'missing'` once the Host no longer serves it (or the read failed). */
export function loadChangesSummary(sessionId, seq, signal) {
  return readJson(changesSummaryUrl(sessionId, seq), signal, 'missing',
    value => (isChangesSummary(value) ? value : undefined)).catch((error) => {
    if (error?.name === 'AbortError') throw error
    // A transport failure is the same dead end as a summary the Host no longer has.
    return 'missing'
  })
}

/** The comparison, or the `'missing'` / `'error'` state a retry may replace. */
export function loadChangesDiff(sessionId, seq, index, signal) {
  return readJson(changesDiffUrl(sessionId, seq, index), signal, 'error',
    value => (isChangesDiff(value) ? value : undefined)).catch((error) => {
    if (error?.name === 'AbortError') throw error
    return error?.status === 404 ? 'missing' : 'error'
  })
}

/* Module-wide open-request bridge: the openResource router publishes one review open, and the
   explorer whose previewSessionId matches the request's expectFamily consumes it. An unrelated
   session's explorer never adopts a request aimed at another session, and a mount arriving later
   still consumes the pending request. */
const pendingOpen = createRequestStore()

export const reviewOpenStore = {
  ...pendingOpen,
  open(address, index, expectFamily) {
    /* The addressed session is the request's key, so the host explorer (which
       only knows the addresses it accepts) is the whole match rule. */
    pendingOpen.request(expectFamily, {
      address: String(address),
      index: Number.isSafeInteger(index) && index >= 0 ? index : 0,
    })
  },
}

/* The review tab's inner split: the file list beside the comparison. The width lives in memory for
   the page — it survives switching preview tabs, sessions, and workspaces (each of which remounts
   the explorer) but is deliberately never persisted: a review tab itself does not survive a reload,
   so a durable width would restore a pane nothing could show. */

/** The split's min/max for one container width (a stored width before the first measure) and a
 * width always inside them. */
export function reviewListBounds(stored, bodyWidth) {
  const measured = Number.isFinite(bodyWidth) && bodyWidth > 0
  /* Before the first measure the stored value must stand as the user left it:
     the fallback ceiling is generous rather than derived from a width of zero. */
  const room = measured ? bodyWidth - REVIEW_DIFF_MIN : REVIEW_LIST_MAX_FALLBACK
  /* `max` never drops below `min`: in too narrow a column the list takes its
     minimum and the comparison scrolls, instead of the clamp inverting. */
  const max = Math.max(REVIEW_LIST_MIN, Math.min(room, REVIEW_LIST_MAX_FALLBACK))
  const requested = Number.isFinite(stored) ? stored : REVIEW_LIST_DEFAULT
  return { min: REVIEW_LIST_MIN, max, width: Math.max(REVIEW_LIST_MIN, Math.min(requested, max)) }
}

/* The split's accessors are plain functions, NOT object methods: the review body
   hands them to React's `useSyncExternalStore` as bare references, where a
   `this`-based accessor would read `this` as undefined and return nothing. */
let splitSnapshot = { width: REVIEW_LIST_DEFAULT }
const splitListeners = new Set()

/** Subscribe to the split width; returns the unsubscribe function. */
export function subscribeReviewSplit(listener) {
  splitListeners.add(listener)
  return () => { splitListeners.delete(listener) }
}

/** The current split width snapshot. Stable between changes, as React requires. */
export function readReviewSplit() { return splitSnapshot }

/** Set the split width for every mounted review tab: an unusable value is ignored and an unchanged
 * one notifies nobody, so a same-pixel drag step costs nothing. */
export function setReviewSplitWidth(width) {
  const next = Number.isFinite(width) ? Math.round(width) : splitSnapshot.width
  if (next === splitSnapshot.width) return
  splitSnapshot = { width: next }
  for (const listener of [...splitListeners]) listener()
}
