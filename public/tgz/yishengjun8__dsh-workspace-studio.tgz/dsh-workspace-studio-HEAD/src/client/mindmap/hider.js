import { MINDMAP_HIDER_THROTTLE_MS } from '../constants.js'
import { createStyleSheet } from '../style-sheet.js'
import { currentSessionOf } from '../controllers.js'
import { isMindmapFamilySession } from './panel.js'
import { mindmapRegistry } from './registry.js'

/* Hides mind-map family sessions (root + every fork descendant) from the
   sidebar list; each mind map is shown by its self-drawn entry instead. Rows
   are matched by title — a title hides a row only when every session with it is
   hidden — and rescanned on DOM mutations / index changes; the current blank
   session is matched structurally (selected row without a time cell), only
   inside a mind-map family.

   Scan cost is bounded: records are filtered to row/overflow mutations before a
   scan is scheduled, an unchanged scan signature skips every DOM write, and the
   body guard re-anchors only when the observed target was replaced. Class
   attributes are watched because React's className rewrite on becoming the
   current session wipes the hidden class with no childList record; those
   rewrites are re-hidden in the same animation frame, so no flash.

   Hiding has TWO outputs on purpose (a stylesheet plus the row class). The
   Harness sidebar's row animation is a FLIP that measures post-update row rects
   INSIDE the React commit (AnimatedRows' getSnapshotBeforeUpdate /
   componentDidUpdate) and translates each row by the measured delta; a row
   removed only AFTER that measurement (the observer callback runs after the
   commit) makes every delta below it stale by the removed height, so those rows
   start above their final place and glide too far — "the group expands and
   everything under it rolls down from far above". The decision is therefore
   ALSO published as selectors (same idiom as the collections filter): a row the
   census already knows carries `display:none` from the moment React inserts it,
   so it never enters that measurement. The class pass stays as belt-and-braces
   — it is also what the overflow COUNT pass reads. The count is patched from
   the Harness's own `sessions.expand` number and only the hidden rows the
   Harness still counts (hidden, not rendered) are subtracted: the Harness now
   computes that number from its archived filter and its session watermark, so
   recomputing it locally would encode a sidebar model that no longer exists.
   The archived filter itself is read from ui-workspace's persisted view state
   (`dsh.workspace.view.v<n>`) with a rendered-rows fallback, never from a
   Workspace snapshot field: the snapshot never carried one. */

/* The published-sheet id; one sheet per install, removed on dispose. */
const HIDDEN_ROWS_STYLE_ID = 'dsh-ws-mindmap-hidden-rows'
/* THE sheet the census hides rows through (see style-sheet.js). */
const hiddenRowsSheet = createStyleSheet(HIDDEN_ROWS_STYLE_ID)
/* Same ceiling as the collections filter: a pathological profile must not build
   a giant sheet (the class pass still hides whatever falls outside it). */
const HIDDEN_SESSION_RULE_MAX = 4000
const REGION = '[data-slot="sidebar.workspaces"]'

/* Selectors are built from Harness-minted ids (never user text) but are still
   escaped: a quote inside an id would break out of the attribute selector. */
const escapeAttribute = (value) => String(value).replaceAll('\\', '\\\\').replaceAll('"', '\\"')

/** Selectors that keep the census-hidden rows and pointless overflow buttons out of layout.
 *  @param hiddenIds - session ids the census decided to hide (data-side twin of the row pass).
 *  @param buttonKeys - group keys (`workspaceId`, `''` for the ungrouped bucket) whose every
 *    session is already hidden, i.e. whose overflow button has nothing left to reveal.
 *  @returns the sheet text (empty when nothing is hidden). */
function hiddenRowsCss(hiddenIds, buttonKeys) {
  const rules = []
  let count = 0
  for (const id of hiddenIds) {
    if (count >= HIDDEN_SESSION_RULE_MAX) break
    rules.push(`${REGION} [data-row-key="session:${escapeAttribute(id)}"]{display:none}`)
    count += 1
  }
  for (const key of buttonKeys) {
    rules.push(`${REGION} [data-row-key="overflow:${escapeAttribute(key)}"]{display:none}`)
  }
  return rules.join('\n')
}

/* The archived-row filter is ui-workspace's private view-store choice: the
   Workspace snapshot never exposed it, so the count logic reads it where the
   feature itself persists it (`dsh.workspace.view.v<n>`) and falls back to what
   is on screen when that storage is absent or unreadable. `show`/`only` both
   render archived rows; `default` hides them. */
function archivedFilterOf(renderedIds, archived) {
  try {
    if (typeof localStorage !== 'undefined') {
      for (let index = 0; index < localStorage.length; index += 1) {
        const key = localStorage.key(index)
        if (key === null || !/^dsh\.workspace\.view\.v\d+$/u.test(key)) continue
        const state = JSON.parse(localStorage.getItem(key) ?? 'null')
        const filter = state?.archivedFilter
        if (filter === 'default' || filter === 'show' || filter === 'only') return filter
      }
    }
  } catch {
    /* Storage unavailable or holding a foreign shape: use the rendered rows. */
  }
  for (const id of renderedIds) if (archived.has(id)) return 'show'
  return 'default'
}

export function installMindmapBranchHider(getSessionList, getArchivedSessionIds, getWorkspaces) {
  if (typeof document === 'undefined') return () => {}
  let timer = 0
  let lastRun = 0
  /* Pending frame-coalesced re-hide (row-class rewrite path below). */
  let frame = 0
  /* Signature of the last applied scan (all driving inputs + the resulting
     row states + overflow-button texts): an identical scan writes nothing. */
  let lastSignature = null
  /* Original textContent of every overflow button whose count this hider
     patched, so it can be restored when the patch no longer applies (all docs
     gone, group fully hidden, or dispose): the harness re-renders the button on
     session changes, but a static group would keep the patched number forever.
     Also marks a button as "patched by us" for the mutation filter below. */
  /* Original text and the text this hider wrote, per patched button: `base` is
     the Harness's own count, `written` lets a later pass tell a React rewrite
     (current text is a fresh baseline) from our own leftover patch. */
  const patchedButtons = new WeakMap()
  const restoreButtonText = (button) => {
    const original = patchedButtons.get(button)
    if (original !== undefined) {
      button.textContent = original.base
      /* Unmark: a later foreign rewrite of the SAME node must rescan again
         (the marker deletion costs at most one extra no-op scan). */
      patchedButtons.delete(button)
    }
  }
  /* The published sheet (see the module header): the shared style-sheet primitive owns create-lazily / reuse / write-on-change / dispose in one place. */
  const publishHiddenRows = (css) => hiddenRowsSheet.publish(css)
  /* Whether a mutation batch can change what this hider renders: a session row
     or overflow button added / removed / rewritten — everything else (panel
     button/label renders, seat re-anchors, decorative nodes, this hider's own
     count patches) cannot alter any hidden class or count. */
  const mutatesHiderState = (records) => {
    for (const record of records) {
      /* Attribute records are handled exclusively by wipesHiddenRowClass below
         (row-class rewrites → frame path): every other attribute change cannot
         alter hiding or counts and must not schedule the throttled scan. */
      if (record.type === 'attributes') continue
      /* Text rewrites matter in two places the row/button passes READ: the
         overflow button's count (the archived-filter switch and watermark
         changes rewrite just that number) and a row's title. React writes text
         through characterData, which carries no childList record, so without
         this branch a filter switch leaves a stale count. Our own count write is
         not news; anything else is. */
      if (record.type === 'characterData') {
        const parent = record.target.parentElement
        if (!(parent instanceof Element)) continue
        const button = parent.closest('button[aria-expanded]')
        if (button !== null) {
          const stored = patchedButtons.get(button)
          if (stored !== undefined && record.target.nodeValue === stored.written) continue
          return true
        }
        if (parent.closest('[role="treeitem"]') !== null) return true
        continue
      }
      const target = record.target
      if (target instanceof Element) {
        if (target.tagName === 'BUTTON') {
          /* Our own count-patch / restore writes target a button we patched:
             skip (de-self-trigger). A foreign overflow-button rewrite (text
             set on the same node) must rescan — its count may be stale again.
             Plain panel buttons cannot affect hiding or counts either. */
          if (patchedButtons.has(target)) continue
          if (target.getAttribute('aria-expanded') !== null) return true
          continue
        }
        /* Any rewrite INSIDE a session row (title span replaced, row rebuilt
           from within) changes what the row pass reads. */
        if (target.closest('[role="treeitem"]') !== null) return true
      }
      for (const node of record.addedNodes) {
        if (node.nodeType !== 1 && node.nodeType !== 11) continue
        if (node.matches?.('[role="treeitem"],button[aria-expanded]') === true
          || node.querySelector?.('[role="treeitem"],button[aria-expanded]') !== null) return true
      }
      for (const node of record.removedNodes) {
        if (node.nodeType !== 1 && node.nodeType !== 11) continue
        if (node.matches?.('[role="treeitem"],button[aria-expanded]') === true
          || node.querySelector?.('[role="treeitem"],button[aria-expanded]') !== null) return true
      }
    }
    return false
  }
  const apply = () => {
    timer = 0
    lastRun = Date.now()
    /* Re-anchor the observer to the sidebar slot whenever this runs: the slot
       may have appeared (initial fallback was body) or been re-created. */
    ensureObserved()
    /* No mind-map docs: skip the session walk (the observer may still fire on
       container/body mutations) but clear any applied hidden class so rows
       self-heal the moment the last doc disappears. */
    if (mindmapRegistry.getDocs().length === 0) {
      const browser = document.querySelector('[data-slot="sidebar.workspaces"]')
      if (browser !== null) {
        for (const row of browser.querySelectorAll('[role="treeitem"].dsh-ws-mindmap-hidden-row')) {
          row.classList.remove('dsh-ws-mindmap-hidden-row')
        }
        for (const button of browser.querySelectorAll('button.dsh-ws-mindmap-no-overflow')) {
          button.classList.remove('dsh-ws-mindmap-no-overflow')
          restoreButtonText(button)
        }
      }
      publishHiddenRows('')
      lastSignature = null
      return
    }
    const list = getSessionList()
    const archived = new Set((getArchivedSessionIds?.() ?? []).map(String))
    /* In-flight mind-map blank sessions: prune what the registry now knows as
       a doc branch (or what vanished / got archived after a failed doc write
       — the view archives the fresh session so it cannot outlive its entry).
       Never prune on "not in list": the store projection may lag the creation
       RPC, and dropping the mark there would leave the row visible. */
    for (const id of [...mindmapBlankSessions]) {
      if (archived.has(id) || mindmapRegistry.isBranch(id)) mindmapBlankSessions.delete(id)
    }
    /* The harness renders ONLY the current blank session (a provisional New
       Session row), with the localized placeholder title — the stored title
       is empty, so title matching cannot see it. It counts as family when it
       is a registry root/branch, resolves to one through the parent chain, or
       was created by this plugin's mind-map createSession (in-flight set). A
       plus-button blank session is none of those and stays visible. */
    const currentId = currentSessionOf(list.byId) ?? null
    const currentSummary = currentId !== null ? list.byId[currentId] : undefined
    const blankFamilyCurrent = currentSummary !== undefined && currentSummary.blank === true
      && (mindmapRegistry.isBranch(currentId)
        || isMindmapFamilySession(list, currentId)
        || mindmapBlankSessions.has(currentId))
    /* The sidebar on screen is the truth for two things the Workspace snapshot
       cannot answer: which sessions are rendered at all (the Harness folds
       groups with a watermark) and whether archived rows are being shown
       (`WorkspaceSnapshot` has no archived filter — that choice lives in
       ui-workspace's private view store). Read both off the rendered rows,
       which carry `data-row-key="session:<id>"`. */
    const browser = document.querySelector('[data-slot="sidebar.workspaces"]')
    if (browser === null) return
    /* Collect the rows ONCE: the per-group count pass reuses this list (via
       section.contains) instead of re-querying the DOM once per group. */
    const rows = [...browser.querySelectorAll('[role="treeitem"]')]
    const renderedIds = new Set()
    for (const row of rows) {
      const rowKey = row.getAttribute('data-row-key')
      if (rowKey !== null && rowKey.startsWith('session:')) renderedIds.add(rowKey.slice('session:'.length))
    }
    /* The archived filter decides which sessions the Harness counts as rows at
       all. Read it from ui-workspace's persisted view state (with a DOM
       fallback), then derive the two modes the census and count need. */
    const archivedFilter = archivedFilterOf(renderedIds, archived)
    const archivedShown = archivedFilter !== 'default'
    const onlyArchived = archivedFilter === 'only'
    const byTitle = new Map()
    /* All driving inputs folded into the scan signature (see header): the row
       pass and the per-group count pass only run when one of them changed. */
    const sessionSig = []
    for (const id of list.ids) {
      const summary = list.byId[id]
      if (summary === undefined) continue
      const title = typeof summary.displayTitle === 'string' ? summary.displayTitle.trim() : ''
      const isFamily = isMindmapFamilySession(list, id)
      sessionSig.push(`${id}\u0001${title}\u0001${summary.blank ? 1 : 0}\u0001${summary.origin ?? ''}\u0001${archived.has(String(id)) ? 1 : 0}\u0001${isFamily ? 1 : 0}\u0001${String(id) === String(currentId) ? 1 : 0}`)
      /* Subagent rows TAKE PART in the title census (the row pass hides by
         title regardless of origin): a family subagent's unique title must
         produce a hidden vote, and a non-family subagent sharing a family
         title must count as a visible vote — otherwise the double guarantee
         is computed over a different population than the rows it hides.
         Blank rows stay excluded (matched structurally below, never by the
         stored title). Archived rows vote only while the Harness renders them:
         under the default filter they can never appear, so they must not vote;
         with "show"/"only" they are exactly the family rows that would leak. */
      if (summary.blank) continue
      if (!archivedShown && archived.has(String(id))) continue
      if (title === '') continue
      if (!byTitle.has(title)) byTitle.set(title, { hidden: 0, visible: 0 })
      const entry = byTitle.get(title)
      if (isFamily) entry.hidden += 1
      else entry.visible += 1
    }
    const hideTitles = new Set()
    for (const [title, entry] of byTitle) {
      if (entry.hidden > 0 && entry.visible === 0) hideTitles.add(title)
    }
    const rowDecisions = []
    const rowSig = []
    for (const row of rows) {
      // Workspace group headers expose aria-expanded — not session rows, so
      // never hidden even when a group title equals a family title.
      if (row.hasAttribute('aria-expanded')) continue
      // Match the title via its title span, not any leaf span: badges / empty
      // spacer spans would be caught by a numeric or empty family title.
      const titleSpan = row.querySelector('span[class*="title"]')
      const title = titleSpan !== null ? (titleSpan.textContent ?? '').trim() : ''
      /* Blank current row of a mind-map family: matched structurally, not by
         title. The harness renders blank rows with the localized New Session
         label (never the stored title) and omits the time cell on blank rows,
         while non-blank rows always have one — so "selected + title cell + no
         time cell" can only be the current blank session's row (blank rows
         never enter search, and group headers carry aria-expanded instead). */
      const matched = hideTitles.has(title)
        || (blankFamilyCurrent
          && titleSpan !== null
          && row.getAttribute('aria-selected') === 'true'
          && row.querySelector('span[class*="time"]') === null)
      rowDecisions.push({ row, matched })
      rowSig.push(`${title}\u0001${matched ? 1 : 0}\u0001${row.classList.contains('dsh-ws-mindmap-hidden-row') ? 1 : 0}`)
    }
    /* Current overflow-button texts: a foreign (harness) button rewrite shows
       up here and forces the count pass even when rows/sessions look unchanged. */
    const buttonTextSig = [...browser.querySelectorAll('button[aria-expanded]')]
      .map(button => (button.textContent ?? ''))
      .join('\u0004')
    const workspaces = getWorkspaces?.() ?? []
    const wsSig = workspaces
      .map(w => `${String(w.title ?? '')}\u0001${(w.sessionIds ?? []).map(String).sort().join('\u0003')}`)
      .join('\u0002')
    const signature = `${sessionSig.join('\u0002')}\u0003${wsSig}\u0003${rowSig.join('\u0002')}\u0003${buttonTextSig}\u0003${blankFamilyCurrent ? 1 : 0}\u0003${archivedShown ? 1 : 0}`
    /* Identical inputs → the DOM already reflects the desired state: skip
       every write (class toggles, count patches) and the per-group pass. */
    if (signature === lastSignature) return
    lastSignature = signature
    /* Data-side twin of the row pass below — the same census keyed by session id
       instead of a rendered row: the sheet must be in place BEFORE the Harness
       renders these rows to keep them out of its animation measurement (header). */
    const hiddenIds = new Set()
    for (const id of list.ids) {
      const summary = list.byId[id]
      if (summary === undefined) continue
      const key = String(id)
      const title = typeof summary.displayTitle === 'string' ? summary.displayTitle.trim() : ''
      /* Exactly the row pass's rule: a title vote hides the row whatever its
         archive flag, and a blank row only ever renders for the CURRENT session
         — the shape the structural branch there detects. */
      const matched = summary.blank
        ? blankFamilyCurrent && key === String(currentId)
        : title !== '' && hideTitles.has(title)
      if (matched) hiddenIds.add(key)
    }
    /* An overflow button whose whole group is hidden has nothing left to reveal
       (that group's mind-map entries are its access path), so it must leave the
       layout with those rows — a frame later it would skew the same animation by
       its own height. The test is strict: every group session is hidden, or one
       the Harness would not render here anyway (unknown id, non-current blank,
       archived while no archived row is on screen). */
    /* The Harness's row population: subagents are never rendered as session
       rows, non-current blanks are dropped, and archived sessions appear only
       while the filter shows them. */
    const countedByHarness = (key) => {
      const summary = list.byId[key]
      if (summary === undefined) return false
      if (summary.origin === 'subagent') return false
      if (summary.blank) return false
      if (onlyArchived) return archived.has(key)
      return archivedShown || !archived.has(key)
    }
    const buttonKeys = []
    const allHidden = (ids) => ids.length > 0 && ids.every((id) => {
      const key = String(id)
      if (hiddenIds.has(key)) return true
      const summary = list.byId[key]
      if (summary === undefined || summary.origin === 'subagent') return true
      if (summary.blank === true && key !== String(currentId)) return true
      if (onlyArchived) return !archived.has(key)
      return !archivedShown && archived.has(key)
    })
    const accounted = new Set(workspaces.flatMap(workspace => (workspace.sessionIds ?? []).map(String)))
    for (const workspace of workspaces) {
      const workspaceId = String(workspace?.workspaceId ?? '')
      if (workspaceId === '') continue
      if (allHidden(workspace.sessionIds ?? [])) buttonKeys.push(workspaceId)
    }
    /* The ungrouped bucket (group key, and therefore button key, `''`) owns the sessions no workspace lists — the same set the count pass derives. */
    if (allHidden(list.ids.map(String).filter(id => !accounted.has(id)))) buttonKeys.push('')
    publishHiddenRows(hiddenRowsCss(hiddenIds, buttonKeys))
    for (const decision of rowDecisions) {
      decision.row.classList.toggle('dsh-ws-mindmap-hidden-row', decision.matched)
    }
    /* The Harness's own `sessions.expand` number is the baseline: it already
       reflects the archived filter and the session watermark (how many rows the
       group keeps folded). This hider only subtracts the rows IT hides that the
       Harness still counts — hidden sessions that are not rendered at all.
       Hidden rendered rows are already outside that baseline. */
    for (const header of browser.querySelectorAll('[role="treeitem"][aria-expanded]')) {
      /* Real-workspace headers sit inside a HoverCard span (ungrouped header
         does not); walk up to the section holding the overflow button. */
      let section = header.parentElement
      while (section !== null && section !== browser
          && section.querySelector(':scope > button[aria-expanded]') === null) {
        section = section.parentElement
      }
      if (section === null || section === browser) continue
      const button = section.querySelector(':scope > button[aria-expanded]')
      if (button === null) continue
      /* Expanded list shows the collapse label — nothing to fix. */
      if (button.getAttribute('aria-expanded') === 'true') continue
      /* Match group by header title: real workspace -> its sessionIds; else
         the ungrouped bucket (sessions no workspace has). */
      const titleEl = header.querySelector('span[class*="title"]')
      const groupTitle = (titleEl?.textContent ?? '').trim()
      const workspace = workspaces.find(w => w.title === groupTitle)
      let ids
      if (workspace !== undefined) {
        ids = (workspace.sessionIds ?? []).map(String)
      } else {
        const accounted = new Set(workspaces.flatMap(w => (w.sessionIds ?? []).map(String)))
        ids = list.ids.filter(id => !accounted.has(String(id)))
      }
      /* `base` is the Harness's untouched text; `written` is our own last patch.
         A different current text means the Harness (React) rewrote this node, so
         the fresh text — not the stored base — is the new baseline. */
      const stored = patchedButtons.get(button)
      const currentText = button.textContent ?? ''
      const base = stored !== undefined && currentText === stored.written ? stored.base : currentText
      const baseNumber = base.match(/\d+/)
      if (baseNumber === null) {
        restoreButtonText(button)
        continue
      }
      let hiddenUnrendered = 0
      for (const id of ids) {
        const key = String(id)
        if (hiddenIds.has(key) && !renderedIds.has(key) && countedByHarness(key)) hiddenUnrendered += 1
      }
      const remaining = Number(baseNumber[0]) - hiddenUnrendered
      if (remaining > 0) {
        button.classList.remove('dsh-ws-mindmap-no-overflow')
        if (Number(baseNumber[0]) === remaining) {
          if (stored !== undefined) restoreButtonText(button)
          continue
        }
        /* The button's only number is the count — swap it in place, keeping the
           baseline so a later restore writes the real count back. */
        const written = base.replace(/\d+/, String(remaining))
        patchedButtons.set(button, { base, written })
        button.textContent = written
      } else {
        button.classList.add('dsh-ws-mindmap-no-overflow')
        restoreButtonText(button)
      }
    }
  }
  /* Whether a mutation batch ADDS session rows or overflow buttons — the
     expand/collapse case. These appear only when the user expands a group (rows)
     or collapses it (button); hiding / count patches must run BEFORE the browser
     paints them, or the 400 ms throttle leaves rows visible for a flash. */
  const addsHiderNodes = (records) => {
    for (const record of records) {
      for (const node of record.addedNodes) {
        if (node.nodeType !== 1 && node.nodeType !== 11) continue
        if (node.matches?.('[role="treeitem"],button[aria-expanded]') === true
          || node.querySelector?.('[role="treeitem"],button[aria-expanded]') !== null) return true
      }
    }
    return false
  }
  /* Whether a mutation batch REWROTE a session row's class attribute. The
     harness re-renders rows through React, and React owns each row's className:
     when a hidden family row becomes (or stops being) the CURRENT session, the
     selected-class toggle rewrites the whole class list and wipes
     dsh-ws-mindmap-hidden-row. Only class writes ON the row element itself can
     do that, so the filter matches the row exactly — panel buttons and the
     overflow button (constant className in the harness) never match, and this
     hider's own toggles re-enter here once and settle on an identical signature. */
  const wipesHiddenRowClass = (records) => {
    for (const record of records) {
      if (record.type !== 'attributes' || record.attributeName !== 'class') continue
      const target = record.target
      if (target instanceof Element && target.matches('[role="treeitem"]')) return true
    }
    return false
  }
  /* Time throttle: the observer fires per DOM mutation; one scan per throttle
     window keeps hiding fresh without global jank. The slot may be re-created by
     the harness WITHOUT a body-direct childList change (deep subtree
     replacement, invisible to the body guard), so re-anchor here inside the
     throttled callback — a stale slot must never leave the hider dead. */
  const schedule = (records) => {
    if (records !== undefined && records.length > 0 && addsHiderNodes(records)) {
      /* Expansion/collapse: scan synchronously — the observer callback runs
         at the microtask checkpoint, before paint, so rows are hidden before
         the first frame (no flash). A pending throttled scan is superseded. */
      if (timer !== 0) { clearTimeout(timer); timer = 0 }
      apply()
      return
    }
    if (records !== undefined && records.length > 0 && wipesHiddenRowClass(records)) {
      /* Row-class rewrite (React wiped our hidden class): re-hide within the
         same animation frame, BEFORE the next paint — the wiped row is never
         painted visible, unlike a 400 ms throttled scan. Coalesced to one
         scan per frame; apply() reads the current DOM, so a coalesced scan
         that follows further rewrites still lands on the final state. */
      if (timer !== 0) { clearTimeout(timer); timer = 0 }
      if (frame === 0) {
        frame = window.requestAnimationFrame(() => {
          frame = 0
          ensureObserved()
          apply()
        })
      }
      return
    }
    if (timer !== 0) return
    /* Mutation filter (header): scan only when the batch can change hiding state
       (a row or overflow button touched). Registry pushes (no records) always scan. */
    if (records !== undefined && records.length > 0 && !mutatesHiderState(records)) return
    const wait = Math.max(0, MINDMAP_HIDER_THROTTLE_MS - (Date.now() - lastRun))
    timer = window.setTimeout(() => { timer = 0; ensureObserved(); apply() }, wait)
  }
  /* Observe ONLY the sidebar workspaces slot (the hider only touches rows there),
     so chat streaming churn no longer schedules scans. The slot may be re-created
     by the harness, so a body-level childList guard re-anchors the observer when
     it is replaced (or first appears — until then the observer falls back to
     body, whose subtree mutations cover the slot's creation). */
  let observedTarget = null
  const ensureObserved = () => {
    const target = document.querySelector('[data-slot="sidebar.workspaces"]') ?? document.body
    if (observedTarget === target) return
    observer.disconnect()
    observedTarget = target
    /* Class attributes are watched for the row-rewrite path above: React wiping
       dsh-ws-mindmap-hidden-row emits NO childList record. */
    observer.observe(target, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'], characterData: true })
  }
  const observer = new MutationObserver(schedule)
  /* Guard: re-anchor ONLY when the observed target was actually replaced
     (disconnected) — plain body churn (portals, toasts, dialogs) does zero work,
     and the slot's own creation/replacement is one of these mutations. */
  const guardObserver = new MutationObserver(() => {
    if (observedTarget === null || !observedTarget.isConnected) {
      ensureObserved()
      /* A replaced slot arrives with no hidden classes and an unpatched count;
         re-anchoring alone would leave the fresh DOM stale until the next
         unrelated mutation (the archived-filter switch replaces the list and
         then goes quiet). Re-apply against the new target now. */
      apply()
    }
  })
  guardObserver.observe(document.body, { childList: true })
  ensureObserved()
  const unsubscribe = mindmapRegistry.subscribe(schedule)
  apply()
  return () => {
    observer.disconnect()
    guardObserver.disconnect()
    unsubscribe()
    if (timer !== 0) { clearTimeout(timer); timer = 0 }
    if (frame !== 0) { window.cancelAnimationFrame(frame); frame = 0 }
    /* Restore every touched row so hot reload / uninstall cannot leave the
       hidden class stuck on the DOM. */
    const browser = document.querySelector('[data-slot="sidebar.workspaces"]')
    if (browser !== null) {
      for (const row of browser.querySelectorAll('[role="treeitem"].dsh-ws-mindmap-hidden-row')) {
        row.classList.remove('dsh-ws-mindmap-hidden-row')
      }
      for (const button of browser.querySelectorAll('button.dsh-ws-mindmap-no-overflow')) {
        button.classList.remove('dsh-ws-mindmap-no-overflow')
        restoreButtonText(button)
      }
    }
    /* And the published sheet, for the same reason: a stale one would hide rows
       nothing owns any more, and no scan would ever clear it. */
    hiddenRowsSheet.dispose()
  }
}

/* Sessions the user has converted to a mind map this app session. The doc
   index refreshes only every 30 s, so right after a conversion `isMember` is
   still false: without this set the button would re-offer the convert dialog.
   Entries are pruned when the registry catches up (see MindmapHeaderButton),
   so the set only ever holds in-flight conversions. */
export const mindmapConvertedSessions = new Set()

/* BLANK sessions this plugin created for a mind map (root-node new-session / the
   blank-card menu — every caller funnels through mindmapActions.createSession).
   The registry learns them as doc branches only after the doc write + index
   refresh, but the harness renders the CURRENT blank session immediately as a
   provisional New Session row; without this set that row would stay visible
   during the adoption window. The hider prunes entries once the registry
   knows the branch (or the session vanished / got archived after a failed
   doc write), so the set only ever holds in-flight creations. Sessions the
   user creates with the sidebar's own plus button never enter this set and
   stay visible — the two are deliberately distinct. */
export const mindmapBlankSessions = new Set()
