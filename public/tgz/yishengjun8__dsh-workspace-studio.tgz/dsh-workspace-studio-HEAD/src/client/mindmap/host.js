import { createElement as h, Fragment, useMemo, useSyncExternalStore } from 'react'
import { createPortal } from 'react-dom'
import { mindmapTabPath } from '../preview-tabs.js'
import { mindmapRegistry } from './registry.js'
import { MindMapView } from './view.js'

/* The GLOBAL mind-map view host: every docked map body lives here, mounted once per family
   root, independent of the per-session explorer (whose React key tears the preview column
   down on every session switch). One STABLE container div per body; the explorer parks that
   element (plain appendChild) into its strip placeholder while the tab is shown, and into
   the hidden holding node while away. Constant container identity for the body's lifetime is
   what makes the keep-alive real: same fibers, DOM parked wherever the tab shows. */

/* Hidden holding node: the stable containers live here while no strip shows their tab
   (display:none keeps the bodies invisible but MOUNTED — background sync keeps folding turns
   while the user is on another session). Created lazily: the bundle is injected before the
   body may exist, so module evaluation must never touch the document. */
let holdingEl = null
const mindmapHolding = () => {
  if (holdingEl === null) {
    holdingEl = document.createElement('div')
    holdingEl.hidden = true
    holdingEl.style.display = 'none'
    document.body.appendChild(holdingEl)
  }
  return holdingEl
}

export const mindmapViewHost = {
  /* rootId -> { fresh }: every map that currently has a live tab somewhere. `fresh` marks a body
     whose tab a DOCK REQUEST just created: its MindMapView may land the chat on the map's
     remembered session. Captured by the view's mount-time useRef and CONSUMED via consumeFresh()
     — a stale true flag must never replay restoreLastSession on a later remount of the body. */
  _roots: new Map(),
  /* Monotonic id for the React key of each body: a map that is RE-ANCHORED to a new root keeps
     its body alive (same bodyKey, same portal container) while its rootId prop changes. Keying the
     body by rootId would remount it on every root replacement and rebuild the whole map. */
  _bodySeq: 0,
  /* rootId -> { el, host }: the map's STABLE portal container. `el` is created once per body
     (lazily, by containerOf) and its identity NEVER changes while the body lives — the
     MindMapBody portal targets it forever, which is what keeps React from remounting the map.
     `host` is the placeholder the container currently sits in (null = the hidden holding node);
     parking is a plain DOM move. */
  _containers: new Map(),
  /* The strip API of the explorer currently mounted (one at a time): doc-gone and title updates
     reach the tab strip only while it is displayed; otherwise the host fixes the snapshot. */
  _strip: null,
  /* rootId -> last map-internal session id: highlight fallback when the harness current session
     is not a family member (hero page / transient). */
  _sessions: new Map(),
  /* Registered by MindMapHost (AppFrame): away-case snapshot fixups write
     through the preview-sessions store (see docGone/titleChange). */
  storeRef: { current: null },
  _version: 0,
  _listeners: new Set(),

  subscribe(listener) {
    this._listeners.add(listener)
    return () => { this._listeners.delete(listener) }
  },
  getVersion() { return this._version },
  _notify() {
    this._version += 1
    for (const listener of [...this._listeners]) listener()
  },
  roots() { return [...this._roots.entries()].map(([rootId, entry]) => ({ bodyKey: entry.bodyKey, rootId })) },
  /* The map's STABLE portal container: created once per body, parked in the hidden holding node
     until an explorer places it into a strip placeholder. Idempotent — both ensure() and a
     (defensive) bare render may call it; the returned element identity is constant for the body's
     lifetime, which is the whole point of this design. */
  containerOf(rootId) {
    const key = String(rootId)
    let entry = this._containers.get(key)
    if (entry === undefined) {
      const el = document.createElement('div')
      el.className = 'dsh-ws-mindmap-host-body'
      mindmapHolding().appendChild(el)
      entry = { el, host: null }
      this._containers.set(key, entry)
    }
    return entry.el
  },
  isFresh(rootId) {
    return this._roots.get(String(rootId))?.fresh === true
  },
  /* The body's MindMapView captured the fresh flag into its mount-time ref: clear it so no later
     (accidental) remount can replay restoreLastSession with a stale fresh=true — that would yank
     the chat onto the map's remembered session instead of the one the user actually opened. */
  consumeFresh(rootId) {
    const entry = this._roots.get(String(rootId))
    if (entry === undefined || entry.fresh !== true) return
    entry.fresh = false
  },
  sessionOf(rootId) {
    const value = this._sessions.get(String(rootId))
    return value === undefined ? null : value
  },
  /* A map tab needs a body: the explorer calls this when a dock request is consumed (fresh = true)
     and when a snapshot-restored tab mounts (fresh = false). Idempotent: an already-mounted body
     keeps its state — a re-dock of an open tab must never remount it (or flip its fresh flag). */
  ensure(rootId, fresh) {
    const key = String(rootId)
    if (this._roots.has(key)) return
    this._bodySeq += 1
    this._roots.set(key, { bodyKey: `mindmap-body-${this._bodySeq}`, fresh: Boolean(fresh) })
    this.containerOf(key)
    this._notify()
  },
  /* The tab was closed (× button, doc gone, archive whole map): the body unmounts and its sync
     timers die; its stable container is destroyed with it. A later dock mounts a FRESH body in a
     new container. */
  drop(rootId) {
    const key = String(rootId)
    if (!this._roots.delete(key)) return
    const entry = this._containers.get(key)
    if (entry !== undefined) {
      entry.el.remove()
      this._containers.delete(key)
    }
    this._sessions.delete(key)
    this._notify()
  },
  /* A root replacement moved this map's document to a NEW root (the old root was archived or its
     card truncated). Migrate the open body in place: the entry keeps its bodyKey and its portal
     container, so React re-renders the SAME MindMapView with a new rootId prop (doc, viewport and
     sync timers survive); the docked tab and the persisted family snapshot follow to the new key.
     Returns false when no body is open for the old root (nothing to migrate). */
  rekey(oldRoot, newRoot, title) {
    const from = String(oldRoot)
    const to = String(newRoot)
    if (from === '' || to === '' || from === to) return false
    const entry = this._roots.get(from)
    if (entry === undefined) return false
    this._roots.delete(from)
    this._roots.set(to, entry)
    const container = this._containers.get(from)
    if (container !== undefined) {
      this._containers.delete(from)
      this._containers.set(to, container)
    }
    if (this._sessions.has(from)) {
      const last = this._sessions.get(from)
      this._sessions.set(to, String(last) === from ? to : last)
      this._sessions.delete(from)
    }
    this._migrateSnapshot(from, to, title)
    this._notify()
    return true
  },
  /* Move the family's persisted preview snapshot to the new key and rewrite its map tab (the tab's
     synthetic path and its stamps are the old root). The retired key is emptied, which deletes it:
     a later session switch must never restore the dead map. */
  _migrateSnapshot(from, to, title) {
    const store = this._snapshotStore()
    if (store === null) return
    const fromPath = mindmapTabPath(from)
    const toPath = mindmapTabPath(to)
    const mapTab = (name) => ({ kind: 'mindmap', path: toPath, name, sessionId: to, dockedAt: to })
    const value = this._snapshotValue(from)
    if (value !== null) {
      const tabs = []
      let moved = false
      for (const tab of Array.isArray(value.tabs) ? value.tabs : []) {
        if (tab === null || tab === undefined || tab.kind !== 'mindmap' || tab.path !== fromPath) {
          tabs.push(tab)
          continue
        }
        moved = true
        tabs.push({
          ...tab,
          path: toPath,
          sessionId: to,
          dockedAt: to,
          ...(typeof title === 'string' && title !== '' ? { name: title } : {}),
        })
      }
      /* The snapshot write can lag the dock by one commit: the body is provably open (rekey only
         runs for a mounted one), so a missing map tab is re-synthesized instead of silently
         dropping the tab on the key flip. */
      if (!moved && typeof title === 'string' && title !== '') tabs.push(mapTab(title))
      store.actions.rememberPreviewSession(to, {
        ...value,
        activePath: value.activePath === fromPath ? toPath : value.activePath,
        tabs,
      })
    } else if (typeof title === 'string' && title !== '') {
      store.actions.rememberPreviewSession(to, { activePath: toPath, tabs: [mapTab(title)], expanded: [] })
    }
    store.actions.rememberPreviewSession(from, null)
  },
  /* Park the map's STABLE container into the explorer's strip placeholder for this tab: a plain
     appendChild move — container identity never changes, so the body's fibers (doc, viewport,
     highlight, sync timers) survive untouched. Idempotent per placeholder (re-placing into the
     same element is a no-op; tab churn must not move the body). The placeholder's own display:none
     keeps an inactive tab's body hidden while it stays mounted. */
  place(rootId, el) {
    if (el === null || el === undefined) return
    const entry = this._containers.get(String(rootId))
    if (entry === undefined || (entry.host === el && entry.el.parentElement === el)) return
    el.appendChild(entry.el)
    entry.host = el
  },
  /* The tab left the strip (closed elsewhere, explorer unmounted): park the stable container back
     into the hidden holding node. Works even when React ALREADY removed the placeholder (explorer
     teardown) — appendChild re-parents the (possibly detached) container. No notification:
     placement is pure DOM, no React state depends on it. */
  unplace(rootId) {
    const entry = this._containers.get(String(rootId))
    if (entry === undefined || entry.host === null) return
    mindmapHolding().appendChild(entry.el)
    entry.host = null
  },
  noteSession(rootId, sessionId) {
    this._sessions.set(String(rootId), String(sessionId))
  },
  /* Strip API: the mounted explorer registers one object with hasTab/closeTab/updateTab; doc-gone
     and title updates route through it while the tab is displayed, else through snapshot fixups. */
  registerStrip(api) { this._strip = api },
  unregisterStrip(api) { if (this._strip === api) this._strip = null },
  /* The map's doc is gone (root archived outside the map): close the tab when a strip shows it
     (the explorer's closeTab drops the body); otherwise fix the persisted family snapshot so the
     dead tab never restores, and drop the body. */
  docGone(rootId) {
    const key = String(rootId)
    const path = mindmapTabPath(key)
    const strip = this._strip
    if (strip !== null && strip.hasTab(path)) {
      strip.closeTab(path)
      return
    }
    this._removeFromSnapshot(key, path)
    this.drop(key)
  },
  /* The map's OWN title (doc.rootTitle) changed: keep the tab label in sync while the strip shows
     it, and always keep the persisted family snapshot current (a rename while the user is on
     another session must survive). Both paths carry the name-equality guard — a title fires on
     every sync fingerprint change (each folded turn) and a redundant updateTab re-renders for
     nothing. */
  titleChange(rootId, title) {
    const key = String(rootId)
    const path = mindmapTabPath(key)
    const strip = this._strip
    if (strip !== null && strip.hasTab(path) && strip.tabName(path) !== title) {
      strip.updateTab(path, { name: title })
    }
    this._patchSnapshot(key, path, (tab) => {
      if (typeof tab.name === 'string' && tab.name === title) return tab
      return { ...tab, name: title }
    })
  },
  _snapshotStore() {
    return this.storeRef?.current ?? null
  },
  _snapshotValue(key) {
    const store = this._snapshotStore()
    if (store === null) return null
    const snap = store.getSnapshot()
    const value = snap?.previewSessions?.[key]
    return value !== undefined && value !== null && typeof value === 'object' ? value : null
  },
  /* Remove the map tab from the persisted family snapshot (key = root id, which restore prefers for
     member sessions). The store action normalizes activePath and deletes an emptied entry. */
  _removeFromSnapshot(key, path) {
    const store = this._snapshotStore()
    if (store === null) return
    const value = this._snapshotValue(key)
    if (value === null || !Array.isArray(value.tabs)) return
    const kept = value.tabs.filter(tab => tab === null || tab === undefined || tab.path !== path)
    if (kept.length === value.tabs.length) return
    store.actions.rememberPreviewSession(key, { ...value, tabs: kept })
  },
  _patchSnapshot(key, path, patch) {
    const store = this._snapshotStore()
    if (store === null) return
    const value = this._snapshotValue(key)
    if (value === null || !Array.isArray(value.tabs)) return
    let changed = false
    const tabs = value.tabs.map(tab => {
      if (tab === null || tab === undefined || tab.path !== path) return tab
      const next = patch(tab)
      if (next === tab) return tab
      changed = true
      return next
    })
    if (!changed) return
    store.actions.rememberPreviewSession(key, { ...value, tabs })
  },
}

/* React calls the useSyncExternalStore subscribe/getSnapshot as BARE function
   references — a detached object method would lose `this` (subscribe would
   throw on `this._listeners`). Same wrapper convention as useMindmapRegistry. */
const subscribeHost = listener => mindmapViewHost.subscribe(listener)
const hostVersion = () => mindmapViewHost.getVersion()

/* Rendered once by AppFrame (always mounted, even without a workspace): owns every open map body,
   each portal'd into its own STABLE container (per body, never re-keyed) that the current explorer
   parks into a strip placeholder or the holding node with plain DOM moves. */
export function MindMapHost({ currentSession, useSessions, mindmapActions, settingsStore, previewSessionsStore }) {
  /* The away-case snapshot fixups need the store; it is stable for the app's
     lifetime, so an inline assignment is idempotent. */
  mindmapViewHost.storeRef.current = previewSessionsStore
  useSyncExternalStore(subscribeHost, hostVersion)
  const roots = mindmapViewHost.roots()
  return h(Fragment, null,
    ...roots.map(({ bodyKey, rootId }) => h(MindMapBody, {
      currentSession,
      key: bodyKey,
      mindmapActions,
      rootId,
      settingsStore,
      useSessions,
    })))
}

function MindMapBody({ rootId, currentSession, useSessions, mindmapActions, settingsStore }) {
  /* Read at mount (MindMapView captures the prop into a ref, then consumes it via onFreshConsumed):
     a later dock of the already-open tab must not flip this body into "land the chat on the
     remembered session" mode, and no later remount may replay it. */
  const freshDock = mindmapViewHost.isFresh(String(rootId))
  /* The map's session follows the HARNESS current session whenever it is a member of this family (a
     sidebar-entry / switcher switch drives the chat directly, so the highlight must follow);
     otherwise the last map-internal selection, falling back to the root. */
  const sessionId = useMemo(() => {
    const current = currentSession === undefined || currentSession === null
      ? undefined
      : String(currentSession)
    if (current !== undefined
      && (current === String(rootId) || mindmapRegistry.rootOf(current) === String(rootId))) {
      return current
    }
    return mindmapViewHost.sessionOf(String(rootId)) ?? String(rootId)
  }, [currentSession, rootId])
  /* Portal target: the body's OWN stable container (created once per body, never re-keyed).
     Placement is a plain DOM move by the explorer, invisible to React: same fibers, so the body's
     state (doc, viewport, highlight) survives every session switch. */
  const target = mindmapViewHost.containerOf(String(rootId))
  return createPortal(h(MindMapView, {
    archiveSession: mindmapActions.archiveSession,
    createSession: mindmapActions.createSession,
    deleteDoc: mindmapActions.deleteDoc,
    forkAt: mindmapActions.forkAt,
    freshDock,
    listWorkspaces: mindmapActions.listWorkspaces,
    loadDoc: mindmapActions.loadDoc,
    onDocGone: () => mindmapViewHost.docGone(String(rootId)),
    onFreshConsumed: () => mindmapViewHost.consumeFresh(String(rootId)),
    onRootChange: (from, to, title, familyIds) => {
      mindmapViewHost.rekey(String(from), String(to), title)
      mindmapRegistry.rekeyRoot(String(from), String(to), familyIds)
    },
    onTitleChange: (title) => mindmapViewHost.titleChange(String(rootId), title),
    openSession: (id) => {
      mindmapActions.openSession(String(id))
      mindmapViewHost.noteSession(String(rootId), String(id))
    },
    renameDoc: mindmapActions.renameDoc,
    renameSession: mindmapActions.renameSession,
    saveDoc: mindmapActions.saveDoc,
    sessionId,
    settingsStore,
    syncDoc: mindmapActions.syncDoc,
    useSessions,
  }), target)
}