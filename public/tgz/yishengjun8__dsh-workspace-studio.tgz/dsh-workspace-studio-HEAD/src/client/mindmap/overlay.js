import { createElement as h, Fragment, useState, useEffect } from 'react'
import { createPortal } from 'react-dom'
import { translate } from '../locale/index.js'
import { Modal } from '../components/dialogs.js'
import { mindmapConvertedSessions } from './hider.js'
import { MINDMAP_ICON } from './panel.js'
import { mindmapDockStore, mindmapRegistry, useMindmapRegistry } from './registry.js'

/* Session-header mind-map button: docks the current session's map as a
   preview tab; on a normal session the first click asks before converting. */
export function MindmapHeaderButton({ sessionId }) {
  // Re-render on registry changes so a fresh conversion is seen immediately.
  const registry = useMindmapRegistry()
  const registryVersion = registry.getVersion()
  const [confirmTarget, setConfirmTarget] = useState(null)
  /* Declared before the Escape effect so the effect can reference it. */
  const closeConfirm = () => setConfirmTarget(null)
  useEffect(() => {
    if (sessionId !== undefined && sessionId !== null && registry.isMember(String(sessionId))) {
      mindmapConvertedSessions.delete(String(sessionId))
    }
  }, [registryVersion, sessionId])
  useEffect(() => {
    if (confirmTarget === null) return undefined
    const onKeyDown = event => { if (event.key === 'Escape') closeConfirm() }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [closeConfirm, confirmTarget])
  /* No current session (hero page / transient): nothing to map yet. */
  if (sessionId === undefined || sessionId === null) return null
  const key = String(sessionId)
  /* The background index may lag a fresh conversion: also check in-flight ones. */
  const member = mindmapRegistry.isMember(key) || mindmapConvertedSessions.has(key)
  const label = translate('view.mindmap')
  /* Resolve the map's root session (the doc is keyed by root) and its title. */
  const rootDocOf = (id) => {
    const docs = mindmapRegistry.getDocs()
    for (const doc of docs) {
      if (String(doc?.sessionId) === String(id)) return doc
      if ((doc?.branchSessionIds ?? []).some(b => String(b) === String(id))) return doc
    }
    return null
  }
  const dockMap = (id) => {
    const doc = rootDocOf(id)
    const rootId = doc?.sessionId ?? String(id)
    /* expectFamily = the map's root: the mounted explorer already matches the
       current session's family, so the gate only stops other sessions' mounts. */
    mindmapDockStore.dock(rootId, doc?.rootTitle ?? '', rootId)
  }
  const onButtonClick = () => {
    /* Registry confirms membership: drop the redundant converted-set entry. */
    if (mindmapRegistry.isMember(key)) mindmapConvertedSessions.delete(key)
    /* Already a mind-map member (root or branch): dock the map as a tab. */
    if (member) { dockMap(key); return }
    /* A normal session: ask before converting it into a mind map. */
    setConfirmTarget(key)
  }
  const confirmConvert = () => {
    setConfirmTarget(null)
    /* Remember the conversion so the next click docks until the background
       index catches up (see mindmapConvertedSessions). */
    mindmapConvertedSessions.add(key)
    dockMap(key)
  }
  /* Portal the confirm dialog to body: .dsh-ws-chat clips fixed-position
     descendants, so the modal would be cut to the chat column. */
  const confirmView = confirmTarget !== null ? createPortal(
    h(Modal, {
      actions: [
        /* The confirm keeps its own button classes (the mind-map confirm has extra styling hooks). */
        { key: 'cancel', label: translate('dialog.cancel'), onClick: closeConfirm, className: 'dsh-ws-text-button dsh-ws-mindmap-confirm-button dsh-ws-mindmap-confirm-cancel' },
        { key: 'ok', label: translate('mindmap.confirm.action'), onClick: confirmConvert, className: 'dsh-ws-text-button dsh-ws-mindmap-confirm-button dsh-ws-mindmap-confirm-ok' },
      ],
      className: 'dsh-ws-mindmap-confirm-dialog',
      onCancel: closeConfirm,
      title: translate('mindmap.confirm.title'),
    },
    h('div', { className: 'dsh-ws-dialog-message' }, translate('mindmap.confirm.message'))),
    document.body) : null
  return h(Fragment, null,
    h('button', {
      'aria-label': label,
      className: 'dsh-ws-mindmap-header-button',
      onClick: onButtonClick,
      title: label,
      type: 'button',
    },
      h('svg', { 'aria-hidden': true, className: 'dsh-ws-mindmap-header-icon', fill: 'none', viewBox: '0 0 24 24' }, MINDMAP_ICON),
      h('span', { className: 'dsh-ws-mindmap-header-label' }, label)),
    confirmView)
}
