import { createElement as h, Fragment, useRef, useState, useEffect, useLayoutEffect, useMemo, useCallback, useSyncExternalStore } from 'react'
import { createPortal } from 'react-dom'
import { COLLECTION_ALL_ID, COLLECTION_UNOWNED_ID, CONTEXT_MENU_WIDTH, EDITOR_CONTEXT_PROVIDER, EXPLORER_MAX_RATIO, MINDMAP_END_COLOR_DEFAULT, MINDMAP_HEAD_COLOR_DEFAULT, MINDMAP_SPIN_BASE_DURATION_S, MINDMAP_SPIN_STOP_DURATION_S, MOBILE_HEADER_FALLBACK_H, PACKAGE_ID, PREVIEW_MAX, PREVIEW_MIN, SIDEBAR_COLLAPSED, SIDEBAR_MAX_FALLBACK, SIDEBAR_MAX_RATIO, SIDEBAR_MIN, TREE_MAX, TREE_MIN, WORKSPACE_GROUP_BY_DEFAULT } from './constants.js'
import { installLocaleService, translate, useLocaleText } from './locale/index.js'
import { setDrawerOpen, setMobile, useMobile } from './mobile.js'
import { styles } from './styles.js'
import { clamp, FILE_COLOR_GROUPS, fileColorOf } from './format.js'
import { previewSnapshotFingerprint, selectStoredPreviewSession } from './preview-tabs.js'
import { sanitizePersistedClientState } from './persisted-state.js'
import { checkFileChange, createWorkspaceEntry, deleteDraft, deleteMindmapDoc, putFile, readDraft, renameWorkspaceEntry, requestDraftTree, requestJson, writeDraft } from './api.js'
import { createExplorerPaneStore, createExplorerSettingsStore, createLayoutStore, createPreviewSessionStore, LayoutController } from './stores.js'
import { currentSessionOf, EditorContextController, openHarnessSession, PromptContextBridge, recentWorkspaceIdOf, selectWorkspaceForSession, workspaceOfSession } from './controllers.js'
import { EditorContextPrefix, installEditorContextMessageCompactor } from './context-bridge.js'
/* The session-row context menu is a fixed 3 items + separator; clamp its top edge
   against its real height so the last item stays reachable. */
const SESSION_CONTEXT_MENU_HEIGHT = 140
import { ThemePresenter } from './theme.js'
import { mindmapRegistry, useMindmapRegistry } from './mindmap/registry.js'
import { installForeignForkWatch } from './mindmap/fork-watch.js'
import { installMindmapBranchHider } from './mindmap/hider.js'
import { MindmapSessionsPanel } from './mindmap/panel.js'
import { MindmapHeaderButton } from './mindmap/overlay.js'
import { ResizeHandle, SessionInlineRename, SidebarTopActions } from './components/menus.js'
import { EmptyWorkspaceExplorer } from './components/explorer/empty.js'
import { ExplorerSettingsSection } from './components/settings.js'
import { MobileHeaderControls, MobileHeroControls, MobileModeToggle } from './components/mobile.js'
import { WorkspaceExplorer } from './components/explorer/index.js'
import { MindMapHost } from './mindmap/host.js'
import { buildMindmapActions } from './mindmap-actions.js'
import { useChatDropMask } from './hooks/chat-drop.js'
import { useChatTailPin } from './hooks/chat-tail-pin.js'
import { useSessionMenu } from './hooks/session-menu.js'
import { useCollectionGroupBy, useCollectionsFilter, useWorkspaceCollectionMenu } from './hooks/sidebar-collections.js'
import { useSidebarChrome } from './hooks/sidebar-chrome.js'
import { useThinkCard } from './hooks/think-card.js'
import { CollectionsDropdown, CollectionsWorkspaceMenu } from './components/collections.js'
import { applyCollectionsPatch, collectionById, collectionClickAction, collectionsStore, loadCollections, newestSessionOfCollection } from './collections.js'
import { registerStudioFileMutationToolview } from './toolview.js'
import { installOpenResourceRouter } from './open-resource.js'
import { resourceNoticeStore } from './ui-notice.js'
import { installPlanResources } from './plan-open.js'
import { installOfficeFaces, installRemoteFaces } from './renderers/remote.js'
/* The shared icon set of the harness shell. ui-commands dresses its own built-in Host
   commands (goal/plan/compact/…) from a table it owns; a client-registered command gets no
   glyph unless it brings one, so /init takes its row face from the same set. */
import { IconDeliverDocRegular } from '@deepseek-ai/dsh-client-ui-primitives'

export function AppFrame(props) {
  const panels = props.useStore(state => state)
  const previewPanels = useSyncExternalStore(props.previewSessionsStore.subscribe, props.previewSessionsStore.getSnapshot)
  const settings = useSyncExternalStore(props.settingsStore.subscribe, props.settingsStore.getSnapshot)
  const panes = useSyncExternalStore(props.explorerPaneStore.subscribe, props.explorerPaneStore.getSnapshot)
  const mobile = useMobile()
  // Mirror the sidebar width into the persisted pane store: the layout store owns the
  // live value but cannot persist wholesale, so the pane store's small layout value is the durable copy.
  const sidebarMirrorRef = useRef(null)
  // Viewport-driven sidebar width ceiling, declared before the mirror effect below so the
  // persisted value is not clamped to the 420 fallback while the live grid allows more.
  const viewportRef = useRef(null)
  const chatSectionRef = useRef(null)
  const [viewportWidth, setViewportWidth] = useState(0)
  const sidebarMax = viewportWidth > 0
    ? Math.max(SIDEBAR_MIN, Math.floor(viewportWidth * SIDEBAR_MAX_RATIO))
    : SIDEBAR_MAX_FALLBACK
  useLayoutEffect(() => {
    // Mobile's sidebar width is a transient force-expand: persisting it would make a
    // mobile-mode refresh lose the user's collapsed preference, so only the ref tracks it.
    if (mobile.on) {
      sidebarMirrorRef.current = { value: panels.sidebar, max: sidebarMax }
      return
    }
    // Before the first viewport measure (viewportWidth === 0) the ceiling is the 420
    // fallback: writing would clamp a wider PERSISTED width into the durable pane store
    // (whose own value already equals the layout seed, so no write is needed). Track the
    // mirror and let the effect re-run with the measured max (sidebarMax changes) before persisting.
    if (viewportWidth === 0) {
      sidebarMirrorRef.current = { value: panels.sidebar, max: sidebarMax }
      return
    }
    // Re-mirror when the value changed; on a ceiling-only change (viewport
    // resize) keep the ref current without rewriting the persisted store.
    const previousMirror = sidebarMirrorRef.current
    if (previousMirror?.value !== panels.sidebar) {
      sidebarMirrorRef.current = { value: panels.sidebar, max: sidebarMax }
      props.explorerPaneStore.actions.setSidebar(panels.sidebar, sidebarMax)
    } else if (previousMirror?.max !== sidebarMax) {
      sidebarMirrorRef.current = { value: panels.sidebar, max: sidebarMax }
    }
  }, [mobile.on, panels.sidebar, props.explorerPaneStore, sidebarMax, viewportWidth])
  // In mobile file-fullscreen the conversation header stays pinned above the
  // file browsing page; its live height feeds --dsh-ws-mobile-header-h.
  const sessionsById = props.useSessions(state => state.byId)
  const currentSession = currentSessionOf(sessionsById)
  const sessionIds = props.useSessions(state => state.ids)
  /* Arrival lifecycle of the harness session list: `pending` until its first successful
     pull, so every fallback that reads `sessionsById` has to wait for `ready`. */
  const sessionsReady = props.useSessions(state => state.phase === 'ready')
  const [mobileHeaderHeight, setMobileHeaderHeight] = useState(MOBILE_HEADER_FALLBACK_H)
  useLayoutEffect(() => {
    // A session switch may swap or blank the header element; reset to the
    // fallback on every pass, then re-measure when present.
    setMobileHeaderHeight(MOBILE_HEADER_FALLBACK_H)
    if (!mobile.on || !mobile.files) return undefined
    const section = chatSectionRef.current
    if (section === null) return undefined
    const attach = (headerElement) => {
      const measure = () => {
        const height = headerElement.getBoundingClientRect().height
        if (height > 0) setMobileHeaderHeight(height)
      }
      measure()
      if (typeof ResizeObserver !== 'function') return undefined
      const observer = new ResizeObserver(measure)
      observer.observe(headerElement)
      return () => { observer.disconnect() }
    }
    /* The header may mount a frame or two after this layout effect, so retry for a few frames;
       both paths funnel observer cleanup through detachObserver so a late header never leaks. */
    let detachObserver = undefined
    let rafId = 0
    const findHeader = () => section.querySelector('[data-slot="conversation.session.header"]')
    let header = findHeader()
    if (header !== null) {
      detachObserver = attach(header)
    } else {
      let retries = 0
      const rafRetry = () => {
        if (retries >= 10) return
        retries += 1
        header = findHeader()
        if (header === null) {
          rafId = requestAnimationFrame(rafRetry)
        } else {
          detachObserver = attach(header)
        }
      }
      rafId = requestAnimationFrame(rafRetry)
    }
    return () => { cancelAnimationFrame(rafId); detachObserver?.() }
  }, [currentSession, mobile.files, mobile.on])
  /* Sidebar mind-map entry icon spin: the user speed multiplier becomes the animation
     duration var; speed 0 freezes the spin. The schema guarantees the range, so no re-clamp here. */
  const mindmapSpinSpeed = settings.mindmapSpinSpeed
  const mindmapSpinDuration = mindmapSpinSpeed > 0
    ? `${(MINDMAP_SPIN_BASE_DURATION_S / mindmapSpinSpeed).toFixed(3)}s`
    : `${MINDMAP_SPIN_STOP_DURATION_S}s`
  // One accent custom property per color group; unset groups resolve to their
  // default inside the CSS rule's var() fallback.
  const fileColorVars = {}
  for (const { group } of FILE_COLOR_GROUPS) fileColorVars[`--dsh-ws-file-${group}`] = fileColorOf(settings, group)
  // The session rename dialog targets the current session id.
  const sessionId = currentSession
  // The workspace-files header names the current session (its durable title)
  // instead of a fixed label; fall back when none is selected.
  const currentSummary = currentSession === undefined ? undefined : sessionsById[currentSession]
  const sessionTitle = currentSummary?.title
  const currentCwd = currentSummary?.cwd
  const detailsCapable = currentSession !== undefined && currentSummary?.blank === false
  const workspaces = props.useWorkspaces(state => state.items)
  /* The workspace list's own arrival lifecycle. Both phases gate the no-session
     fallback: while either list is still pending its snapshot is partial. */
  const workspacesReady = props.useWorkspaces(state => state.phase === 'ready')
  /* Archived sessions are hidden from the collection switch's auto-jump target. */
  const archivedSessionIds = props.useWorkspaces(state => state.archivedSessionIds)
  const collections = useSyncExternalStore(collectionsStore.subscribe, collectionsStore.getSnapshot)
  const collectionsDoc = collections.doc
  /* No session selected → follow the workspace the harness itself would
     reconnect (the same recent-workspace policy it applies to New Session). */
  const recent = useMemo(
    () => recentWorkspaceIdOf(workspaces, sessionsById),
    [sessionsById, workspaces],
  )
  // The session-list context menu, the in-place rename overlay and archive/reveal feedback
  // are owned here: the target rows live in the harness sidebar slot this component renders.
  const mountedRef = useRef(true)
  useEffect(() => {
    mountedRef.current = true
    return () => { mountedRef.current = false }
  }, [])
  const [resizing, setResizing] = useState(false)
  const chatDrop = useChatDropMask({ chatSectionRef })
  useThinkCard({ chatSectionRef })
  useChatTailPin({ chatSectionRef, currentSession })
  /* Locale changes re-render the frame so the collection chips/copy follow the active language. */
  const localeRevision = useLocaleText()
  /* Workspace collections own the section title only in the Harness's 按工作区 grouping mode; the
     mode lives in the Harness's own persisted view store (see collections.js). */
  const collectionGroupBy = useCollectionGroupBy()
  const collectionsActive = collectionGroupBy === WORKSPACE_GROUP_BY_DEFAULT
  const sidebarChromeState = useSidebarChrome({ collections: collectionsActive })  /* One notice for interactions the resource router could not complete (an
     address of a type this layout does not host); it replaces what used to be an
     uncaught throw inside the harness's own click handler. */
  const resourceNotice = useSyncExternalStore(resourceNoticeStore.subscribe, resourceNoticeStore.getSnapshot)
  const sessionMenu = useSessionMenu({ props, mountedRef, currentSession })
  const { asideRef, sidebarChrome } = sidebarChromeState
  const { chatDropActive, chatDropSuppressed, setChatDropActive } = chatDrop
  const {
    sessionContextMenu, sessionMenuRef, sessionInlineRename, sessionInlineRenameBusy,
    sessionInlineRenameError, sessionNotice, beginSessionInlineRename,
    cancelSessionInlineRename, confirmSessionInlineRename, archiveSessionFromMenu,
    revealSessionById, revealSessionFromMenu, openMindmapSession, showSessionNotice,
  } = sessionMenu

  /* Same two-stage resolution as workspaceOfSession (membership first, then cwd): the
     explorer mount and the editor-context injection must never disagree for one session.
     The no-session branch is a FALLBACK, and it may only run once both harness snapshots
     have arrived: `ui-workspace` gates its own recent-workspace resolution on
     `workspace.phase === 'ready' && sessions.phase === 'ready'` and restores the saved
     selection immediately after, so resolving any earlier names a workspace the harness is
     about to leave. Mounting the explorer there is what makes the first paint disagree
     with the settled one: it pulls that workspace's tree and VCS status, then repaints on
     the real workspace a couple of seconds later, once the session list has returned. */
  const workspaceReady = sessionsReady && workspacesReady
  const workspace = useMemo(() => {
    if (currentSession !== undefined) return selectWorkspaceForSession(workspaces, currentSession, currentCwd)
    if (!workspaceReady) return undefined
    return workspaces.find(item => item.workspaceId === recent)
  }, [currentCwd, currentSession, recent, workspaceReady, workspaces])
  const workspaceId = workspace?.workspaceId
  /* Workspace collections: read once per page load (the Host owns the durable copy), filtered in the
     sidebar by a generated stylesheet, and switched with an explicit jump to the collection's newest
     session. `collectionsActive` is false in the Harness's own 按工作区树 / 单列表 modes, where the
     feature stays out of the way entirely (dropdown removed, no filtering). */
  useEffect(() => {
    const controller = new AbortController()
    void loadCollections(controller.signal)
    return () => controller.abort()
  }, [])
  const collectionLabels = useMemo(() => ({
    outside: translate('collections.badge.outside'),
    /* The unowned view is a filter, not a collection: its "kept visible" marker must not claim the
       workspace is outside a collection. */
    outsideView: translate('collections.badge.outsideView'),
    iconNone: translate('collections.icon.none'),
    iconMember: translate('collections.icon.member'),
    emptyUnowned: translate('collections.empty.unowned'),
    emptyCollection: translate('collections.empty.collection'),
  }), [localeRevision])
  useCollectionsFilter({
    currentWorkspaceId: workspaceId,
    doc: collectionsDoc,
    labels: collectionLabels,
    paused: !collectionsActive,
    workspaces,
  })
  /* The icon's tooltips need the same document/membership the filter uses, so both hooks share one
     localized copy object (a fresh object per render would re-apply the icons every time). */
  const workspaceCollectionMenu = useWorkspaceCollectionMenu({ doc: collectionsDoc, labels: collectionLabels })
  const patchCollections = useCallback(patch => applyCollectionsPatch(patch), [])
  const switchCollection = useCallback(async (id) => {
    /* A click on the view already on screen is a no-op for state: it must not rewrite the same
       selection to the Host, and it must certainly not re-run the auto-jump below (that would move
       the user off the session they are working in). The LIVE store is read, not the render copy: a
       click that follows another patch (delete, create) has to compare against the merged value. */
    const live = collectionsStore.getSnapshot().doc
    const click = collectionClickAction(live, id)
    if (click.same === true) {
      showSessionNotice(translate(click.notice.key, click.notice.params))
      return
    }
    const result = await applyCollectionsPatch({ selectedId: id })
    if (result?.ok !== true) {
      showSessionNotice(translate('collections.switchFailed'), true)
      return
    }
    const collection = collectionById(result.doc, id)
    /* A built-in view is not a collection: say what actually happened, and do not jump (there is no
       "newest member session" to open — under "all workspaces" every session qualifies). */
    if (id === COLLECTION_ALL_ID) {
      showSessionNotice(translate('collections.showAll'))
      return
    }
    if (id === COLLECTION_UNOWNED_ID) {
      showSessionNotice(translate('collections.showUnowned'))
      return
    }
    const name = collection === undefined ? translate('collections.all') : collection.name
    showSessionNotice(translate('collections.switched', { name }))
    const target = newestSessionOfCollection(result.doc, id, workspaces, sessionsById, archivedSessionIds)
    if (target !== undefined) props.openSession(target)
  }, [archivedSessionIds, props.openSession, sessionsById, showSessionNotice, workspaces])
  const publishEditorContext = useCallback((value) => {
    if (currentSession !== undefined) props.publishEditorContext(String(currentSession), value)
  }, [currentSession, props.publishEditorContext])
  /* One session's working directory: a preview tab that is handed a path from a
     harness surface (a turn's changed files) resolves it against this, since such
     a path is spelled relative to the SESSION's cwd, not to the workspace root. */
  const sessionCwdOf = useCallback(id => sessionsById[id]?.cwd, [sessionsById])
  useEffect(() => {
    if (currentSession !== undefined) props.activateEditorSession(String(currentSession))
  }, [currentSession, props.activateEditorSession])
  /* Shared dsh-ws-preview persistence: every session of the same mind map (root + all
     branches) reads and writes one snapshot keyed by the map's root session id; sessions
     outside a map keep their own key. The explorer's React key uses the same id, so
     switching between member sessions keeps the whole preview area mounted. */
  const mindmapRegistryState = useMindmapRegistry()
  const previewSessionId = currentSession === undefined
    ? undefined
    : (mindmapRegistryState.rootOf(currentSession) ?? String(currentSession))
  const previewSessionSelection = selectStoredPreviewSession(previewPanels.previewSessions, workspace, previewSessionId, workspaceId)
  const previewSessionKey = previewSessionSelection.key
  const storedPreviewSession = previewSessionSelection.value
  // Skip a rewrite when this key-set already holds the same snapshot: each
  // write serializes the whole previewSessions value, so identical repeat
  // writes are pure cost.
  const lastPersistedSnapshotRef = useRef(new Map())
  const persistPreviewSession = useCallback((value) => {
    // Write the snapshot to every key restore may pick: the current session's persistence
    // key (its mind-map root id when a map member) and the workspace anchor. The selected
    // key joins them only when it is one of those two; a borrowed template key is no target.
    const keys = new Set()
    if (previewSessionId !== undefined) keys.add(previewSessionId)
    if (workspaceId !== undefined) keys.add(String(workspaceId))
    if (previewSessionKey !== undefined
      && (previewSessionKey === previewSessionId || previewSessionKey === String(workspaceId))) {
      keys.add(previewSessionKey)
    }
    if (keys.size === 0) return
    const keySet = [...keys].sort().join('|')
    const fingerprint = previewSnapshotFingerprint(value)
    if (lastPersistedSnapshotRef.current.get(keySet) === fingerprint) return
    lastPersistedSnapshotRef.current.set(keySet, fingerprint)
    /* LRU-style bound: evict the oldest single entry instead of clearing the
       whole table, which would re-serialize every key on the next change. */
    if (lastPersistedSnapshotRef.current.size > 128) {
      const oldest = lastPersistedSnapshotRef.current.keys().next().value
      if (oldest !== undefined) lastPersistedSnapshotRef.current.delete(oldest)
    }
    for (const key of keys) props.previewSessionsStore.actions.rememberPreviewSession(key, value)
  }, [previewSessionId, previewSessionKey, props.previewSessionsStore, workspaceId])
  const last = useRef(currentSession)
  useEffect(() => {
    const liveSessionIds = sessionIds.map(String)
    props.retainEditorSessions(liveSessionIds)
  }, [props.retainEditorSessions, sessionIds])
  useLayoutEffect(() => {
    if (!detailsCapable) props.actions.closeDetails()
    else if (last.current !== undefined && last.current !== currentSession) props.actions.closeDetails()
    last.current = currentSession
  }, [detailsCapable, currentSession, props.actions])
  useLayoutEffect(() => {
    const viewport = viewportRef.current
    if (viewport === null) return undefined
    const measure = () => { setViewportWidth(viewport.getBoundingClientRect().width) }
    measure()
    if (typeof ResizeObserver !== 'function') return undefined
    const observer = new ResizeObserver(() => { measure() })
    observer.observe(viewport)
    return () => { observer.disconnect() }
  }, [])
  const collapsed = panels.sidebar === 0
  // Mobile expands the sidebar so the drawer shows the full browsing content; the previous
  // collapsed state is restored when mobile turns off. Declared after `collapsed` so the
  // dependency array reads an initialized binding (TDZ-safe).
  const sidebarWasCollapsedRef = useRef(null)
  useEffect(() => {
    if (mobile.on) {
      if (sidebarWasCollapsedRef.current === null) {
        sidebarWasCollapsedRef.current = collapsed
        if (collapsed) props.toggleSidebar()
      }
    } else if (sidebarWasCollapsedRef.current !== null) {
      if (sidebarWasCollapsedRef.current) props.toggleSidebar()
      sidebarWasCollapsedRef.current = null
    }
  }, [collapsed, mobile.on, props.toggleSidebar])
  const view = panels.view === 'files' ? 'files' : 'sessions'
  const filesMode = view === 'files'
  const filesActive = filesMode && !collapsed
  const sidebar = collapsed ? SIDEBAR_COLLAPSED : clamp(panels.sidebar, SIDEBAR_MIN, sidebarMax)
  // Measure the viewport, not the grid frame: the conversation column can shrink without a fixed floor.
  const leftStackMax = viewportWidth > 0
    ? Math.max(sidebar + TREE_MIN + PREVIEW_MIN, Math.floor(viewportWidth * EXPLORER_MAX_RATIO))
    : SIDEBAR_MAX_FALLBACK + TREE_MAX + PREVIEW_MAX
  const explorerMax = Math.max(TREE_MIN + PREVIEW_MIN, leftStackMax - sidebar)
  // The workspace file tree lives only in the sidebar files region, revealed
  // only in the files view; the main frame's tree track stays at zero, so
  // opening the explorer shows only the file preview next to the chat.
  const tree = 0
  const previewMax = settings.previewRight === true
    ? Math.max(PREVIEW_MIN, viewportWidth > 0 ? Math.floor(viewportWidth * EXPLORER_MAX_RATIO) : PREVIEW_MAX)
    : Math.max(PREVIEW_MIN, explorerMax - tree)
  const preview = clamp(panes.preview, PREVIEW_MIN, previewMax)
  const previewBoundary = sidebar + preview
  const treePortalTarget = sidebarChrome?.files ?? null
  return h('div',{ref:viewportRef,className:'dsh-ws-viewport'},h('main',{className:'dsh-ws-frame','data-sidebar-collapsed':collapsed||undefined,'data-sidebar-files':filesActive||undefined,'data-resizing':resizing||undefined,'data-preview-right':settings.previewRight===true||undefined,style:{'--dsh-ws-preview':`${preview}px`,'--dsh-ws-sidebar':`${sidebar}px`,'--dsh-ws-row-height':`${settings.rowHeight}px`,'--dsh-ws-mobile-header-h':`${mobileHeaderHeight}px`,'--dsh-ws-mindmap-spin-duration':mindmapSpinDuration,...fileColorVars}},h('aside',{className:'dsh-ws-sidebar',ref:asideRef},props.renderSlot('sidebar',{collapsed,width:sidebar}),sidebarChrome?.top?createPortal(h(SidebarTopActions,{collapsed,view,width:sidebar,onSelectSessions:()=>{props.actions.setView('sessions')},onSelectFiles:()=>{if(collapsed)props.toggleSidebar();props.actions.setView('files')}}),sidebarChrome.top):null,sidebarChrome&&(sidebarChrome.groups.length>0?sidebarChrome.groups.map(group=>createPortal(h(MindmapSessionsPanel,{useSessions:props.useSessions,useWorkspaces:props.useWorkspaces,groupTitle:group.title,openSession:openMindmapSession,revealSession:revealSessionById}),group.container)):sidebarChrome.fallback?createPortal(h(MindmapSessionsPanel,{useSessions:props.useSessions,useWorkspaces:props.useWorkspaces,groupTitle:undefined,openSession:openMindmapSession,revealSession:revealSessionById}),sidebarChrome.fallback):null)),workspace?h(WorkspaceExplorer,{key:`${workspace.workspaceId}:${previewSessionId ?? 'workspace'}`,createEntry:props.createEntry,listDirectory:props.listDirectory,mindmapActions:props.mindmapActions,persistPreviewSession,previewSessionId,publishEditorContext,readFile:props.readFile,renameEntry:props.renameEntry,saveFile:props.saveFile,loadDraft:props.loadDraft,persistDraftFile:props.persistDraftFile,removeDraftFile:props.removeDraftFile,draftTree:props.draftTree,checkFileChange:props.checkFileChange,settingsStore:props.settingsStore,sessionCwdOf,storedPreviewSession,sessionTitle,sessionId,renameSession:props.renameSession,treePortalTarget,useSessions:props.useSessions,workspace}):h(EmptyWorkspaceExplorer,{loading:!workspaceReady,sessionTitle,treePortalTarget}),h(MindMapHost,{currentSession,mindmapActions:props.mindmapActions,previewSessionsStore:props.previewSessionsStore,settingsStore:props.settingsStore,useSessions:props.useSessions}),h('section',{className:'dsh-ws-chat',ref:chatSectionRef},props.renderSlot('main',{}, {entryKey:panels.panelInfo.activePanelId ?? 'conversation'}),chatDropActive?h('div',{className:'dsh-ws-chat-drop-mask',role:'presentation'},h('button',{'aria-label':translate('drop.closeAria'),className:'dsh-ws-chat-drop-close',onClick:()=>{chatDropSuppressed.current=true;setChatDropActive(false)},title:translate('drop.closeTitle'),type:'button'},'×'),h('div',{className:'dsh-ws-chat-drop-card'},translate('drop.releaseImages'))):null),!collapsed?h(ResizeHandle,{label:translate('resize.sidebar'),left:sidebar,max:sidebarMax,min:SIDEBAR_MIN,onDragging:setResizing,onResize:width=>props.actions.setSidebar(width,sidebarMax),value:sidebar}):null,h(ResizeHandle,{label:translate('resize.preview'),left:settings.previewRight===true?Math.max(0,viewportWidth-preview):previewBoundary,max:previewMax,min:PREVIEW_MIN,onDragging:setResizing,onResize:width=>props.explorerPaneStore.actions.setPreview(width,previewMax),value:preview,invert:settings.previewRight===true||undefined}),h('aside',{className:'dsh-ws-details','data-closed':!panels.detailsOpen||!detailsCapable||undefined},h(props.SessionProvider,null,props.renderSlot('details',{}))),mobile.on&&mobile.drawerOpen?h('div',{className:'dsh-ws-mobile-scrim',onClick:()=>setDrawerOpen(false)}):null,h('div',{className:'dsh-ws-overlay','data-shell-overlay':true},props.renderSlot('shell.overlay',{})),sidebarChrome?.header&&collectionsActive?createPortal(h(CollectionsDropdown,{doc:collectionsDoc,notice:showSessionNotice,onPatch:patchCollections,onSelect:switchCollection,unavailable:collections.phase==='error',workspaces}),sidebarChrome.header):null,workspaceCollectionMenu.menu?h(CollectionsWorkspaceMenu,{anchor:{x:workspaceCollectionMenu.menu.x,y:workspaceCollectionMenu.menu.y},doc:collectionsDoc,notice:showSessionNotice,onClose:workspaceCollectionMenu.closeMenu,onPatch:patchCollections,workspaceId:workspaceCollectionMenu.menu.workspaceId,workspaces}):null,sessionContextMenu?h('div',{className:'dsh-ws-context-menu',ref:sessionMenuRef,role:'menu',style:{left:Math.max(4,Math.min(sessionContextMenu.x,window.innerWidth-CONTEXT_MENU_WIDTH-4)),top:Math.max(4,Math.min(sessionContextMenu.y,window.innerHeight-SESSION_CONTEXT_MENU_HEIGHT-8))}},h('button',{className:'dsh-ws-context-item',onClick:beginSessionInlineRename,role:'menuitem',type:'button',title:sessionContextMenu.ambiguous?translate('context.ambiguousTitle',{id:String(sessionContextMenu.sessionId).slice(0,8)}):undefined},translate('context.renameSession')+(sessionContextMenu.ambiguous?` · ${String(sessionContextMenu.sessionId).slice(0,8)}`:'')),h('button',{className:'dsh-ws-context-item',onClick:archiveSessionFromMenu,role:'menuitem',type:'button',title:sessionContextMenu.ambiguous?translate('context.ambiguousTitle',{id:String(sessionContextMenu.sessionId).slice(0,8)}):undefined},translate('context.archiveSession')+(sessionContextMenu.ambiguous?` · ${String(sessionContextMenu.sessionId).slice(0,8)}`:'')),h('div',{className:'dsh-ws-context-separator',role:'separator'}),h('button',{className:'dsh-ws-context-item',onClick:revealSessionFromMenu,role:'menuitem',type:'button'},translate('context.reveal'))):null,sessionInlineRename?h(SessionInlineRename,{busy:sessionInlineRenameBusy,error:sessionInlineRenameError,key:sessionInlineRename.sessionId,onCancel:cancelSessionInlineRename,onConfirm:confirmSessionInlineRename,row:sessionInlineRename.row,title:sessionInlineRename.title}):null,sessionNotice?h('div',{className:'dsh-ws-copy-notice','data-error':sessionNotice.error||undefined,role:'status'},sessionNotice.text):null,resourceNotice?h('div',{className:'dsh-ws-copy-notice','data-error':resourceNotice.error||undefined,role:'status'},resourceNotice.text):null))}

export const inject = ['slots', 'theme', 'sessions', 'workspaces']
export function mountStudio(ctx) {
  /* Before ANY store is created: drop the keys of every previous persisted format and make the
     current keys canonical on disk. The harness's persistence rehydrates a store by replacing its
     whole state with the raw JSON, so a value that does not match the current schema has to be
     cleaned here — the readers trust the schema and carry no per-field fallbacks. */
  sanitizePersistedClientState()
  const layoutStore = createLayoutStore()
  /* The root store instance is shared between the slot registration and the
     panelInfo root contribution: this plugin's patch disables ui-layout, so
     the plugin must provide the usePanelInfo hook the harness's
     WorkspaceBrowser/SidebarRoot read. */
  const layoutInstance = layoutStore.create()
  const store = { ...layoutStore, create: () => layoutInstance }
  const panelInfo = {
    getSnapshot: () => layoutInstance.getSnapshot().panelInfo,
    subscribe: listener => layoutInstance.subscribe(listener),
  }
  /* ctx.layout carries that same selection for the plugins that reach the
     panel face instead of the hook, so it is built from the source above. */
  const layout = new LayoutController(panelInfo)
  const previewSessionsStore = createPreviewSessionStore().create()
  const settingsStore = createExplorerSettingsStore().create()
  const explorerPaneStore = createExplorerPaneStore().create()
  /* Publish the user's mind-map highlight colors as document-wide CSS custom
     properties so changing a setting updates open maps instantly. */
  ctx.effect(() => {
    if (typeof document === 'undefined') return undefined
    const applyMindmapColors = () => {
      const state = settingsStore.getSnapshot()
      const root = document.documentElement
      root.style.setProperty('--dsh-ws-mindmap-hover', state?.mindmapHoverColor || 'var(--dsw-alias-state-warn-primary)')
      root.style.setProperty('--dsh-ws-mindmap-selected', state?.mindmapSelectedColor || 'var(--dsw-alias-state-business-primary)')
      root.style.setProperty('--dsh-ws-mindmap-head', state?.mindmapHeadColor || MINDMAP_HEAD_COLOR_DEFAULT)
      root.style.setProperty('--dsh-ws-mindmap-end', state?.mindmapEndColor || MINDMAP_END_COLOR_DEFAULT)
    }
    applyMindmapColors()
    return settingsStore.subscribe(applyMindmapColors)
  }, 'workspace-studio: mind-map highlight colors')
  /* Publish the Think-card viewport height (in lines) as a document-wide CSS
     custom property so moving the settings slider restyles open cards. */
  ctx.effect(() => {
    if (typeof document === 'undefined') return undefined
    const applyThinkLines = () => {
      const state = settingsStore.getSnapshot()
      document.documentElement.style.setProperty('--dsh-ws-think-lines', String(state.thinkLines))
    }
    applyThinkLines()
    return settingsStore.subscribe(applyThinkLines)
  }, 'workspace-studio: think card lines')
  /* Publish the edit-row viewport height (in lines) as a document-wide CSS
     custom property — the same mechanism as the Think-card count, but
     independent (the 编辑显示行数 slider drives --dsh-ws-edit-lines). */
  ctx.effect(() => {
    if (typeof document === 'undefined') return undefined
    const applyEditLines = () => {
      const state = settingsStore.getSnapshot()
      document.documentElement.style.setProperty('--dsh-ws-edit-lines', String(state.editLines))
    }
    applyEditLines()
    return settingsStore.subscribe(applyEditLines)
  }, 'workspace-studio: edit row lines')
  const editorContexts = new EditorContextController()
  /* Follow the harness language setting when the locale plugin is present: register this
     plugin's dictionaries, bind the active-locale translator and expose the locale face to
     useLocaleText. Without the service everything stays on the zh dictionary. Registered via
     a deferred inject so a locale service activating later still gets wired up. */
  ctx.inject(['locale'], scope => {
    scope.effect(() => {
      const localeService = scope.get('locale')
      if (localeService === undefined) return undefined
      return installLocaleService(localeService)
    }, 'workspace-studio: locale dictionaries')
  })
  /* Standard workspace-files Remote faces for the renderer views (image bytes, HTML
     relative assets, paged read-only browse, and the read-only preview of paths OUTSIDE
     the workspace): installed when the harness Remote service is available; the views
     degrade to a failure line without it.
     The Remote's single `readBytes(scope, path, { baseFile, range })` answers with `data`,
     native bytes, not base64 (migration table: dev-notes §26). Calling a method that is not there
     throws SYNCHRONOUSLY inside the renderer's effect, which the harness root error
     boundary answers by replacing the whole layout — so install no face at all when the
     methods are absent (the views then report "unavailable"), and defer every call through
     a promise so any other throw becomes a displayable Remote failure instead. */
  ctx.inject(['remote', 'remote.workspaceFiles'], scope => {
    scope.effect(() => {
      const remote = scope.get('remote')
      if (remote === undefined) return undefined
      const files = remote.workspaceFiles
      if (files === undefined || files === null) return undefined
      if (typeof files.read !== 'function' || typeof files.readBytes !== 'function') return undefined
      /* Aborts stay rejections (callers already ignore them); everything else — a renamed
         method, a transport fault — becomes the failure line the renderer can already draw. */
      const safe = call => (...args) => Promise.resolve().then(() => call(...args)).catch((error) => {
        if (error?.name === 'AbortError') throw error
        return {
          ok: false,
          error: {
            code: 'renderer-remote-failed',
            message: error instanceof Error ? error.message : String(error),
          },
        }
      })
      return installRemoteFaces({
        readPage: safe((sessionId, path, offset, signal) => files.read(sessionId, path, { offset }, signal)),
        readAll: safe((sessionId, path, signal) => files.readBytes(sessionId, path, {}, signal)),
        /* A relative dependency resolves from the DOCUMENT's directory: the
           document path travels as `baseFile`, the dependency as `path`. */
        readRelated: safe((sessionId, basePath, relativePath, signal) => files.readBytes(sessionId, relativePath, { baseFile: basePath }, signal)),
      })
    }, 'workspace-studio: renderer remote faces')
  })
  /* Office → PDF conversion face for the document preview: the harness Host provider owns
     LibreOffice, its bounded queue and its content cache; this bundle only asks for the
     bytes. Installed under its own service, so the face appears whenever `remote.officeToPdf`
     does (and stays absent — the view then reports "unavailable" — when the Host does not
     mount it). A missing or renamed method must resolve to no face at all: calling it throws
     SYNCHRONOUSLY inside the view's effect and the harness root error boundary replaces the layout. */
  ctx.inject(['remote', 'remote.officeToPdf'], scope => {
    scope.effect(() => {
      const remote = scope.get('remote')
      if (remote === undefined) return undefined
      const office = remote.officeToPdf
      if (office === undefined || office === null) return undefined
      if (typeof office.render !== 'function') return undefined
      const safe = call => (...args) => Promise.resolve().then(() => call(...args)).catch((error) => {
        if (error?.name === 'AbortError') throw error
        return {
          ok: false,
          error: {
            code: 'renderer-remote-failed',
            message: error instanceof Error ? error.message : String(error),
          },
        }
      })
      return installOfficeFaces({
        /* Foreground priority: this is a user-visible preview, so the Host's
           conversion queue serves it ahead of speculative work. */
        renderOffice: safe((sessionId, path, signal) => office.render(sessionId, path, 'foreground', signal)),
      })
    }, 'workspace-studio: office render face')
  })
  ctx.effect(() => {
    if (typeof document === 'undefined') return undefined
    for (const stale of document.querySelectorAll(`style[data-plugin-css="${PACKAGE_ID}/layout"]`)) stale.remove()
    const tag = document.createElement('style')
    tag.dataset.plugin = PACKAGE_ID
    tag.dataset.pluginCss = `${PACKAGE_ID}/layout`
    tag.textContent = styles
    document.head.append(tag)
    return () => tag.remove()
  }, 'workspace-studio: styles')
  ctx.effect(() => {
    if (typeof document === 'undefined') return undefined
    // Mobile mode is transient and the document classes are plugin-owned
    // global state; clear stale classes on activation and disposal.
    setMobile(false)
    return () => { setMobile(false) }
  }, 'workspace-studio: mobile class lifecycle')
  ctx.effect(() => installEditorContextMessageCompactor(), 'workspace-studio: compact logged editor context')
  const listDirectory = (workspaceId, path, signal) => requestJson('tree', String(workspaceId), path, signal)
  const readFile = (workspaceId, path, signal, encoding) => requestJson('file', String(workspaceId), path, signal, encoding)
  const saveFile = (workspaceId, path, content, revision, signal, encoding) => putFile(workspaceId, path, content, revision, signal, encoding)
  const loadDraft = (workspaceId, path, signal, owner) => readDraft(String(workspaceId), path, signal, owner)
  const persistDraftFile = (workspaceId, path, payload, signal, options) => writeDraft(String(workspaceId), path, payload, signal, options)
  const removeDraftFile = (workspaceId, path, signal, owner, generation) => deleteDraft(String(workspaceId), path, signal, owner, generation)
  const draftTree = (workspaceId, payload, signal) => requestDraftTree(String(workspaceId), payload, signal)
  const checkFileChangeBound = (workspaceId, path, previous, signal) => checkFileChange(String(workspaceId), path, previous, signal)


  ctx.effect(() => {
    const disposeService = ctx.reflect.provide('layout', layout)
    const disposePanelInfo = ctx.slots.provideRoot({ hooks: { panelInfo } })
    const disposeRegistration = ctx.slots.register({
      name: 'root',
      children: {
        sidebar: { kind: 'single', scope: 'root' },
        /* The harness's conversation moved into the keyed `main` slot; the chat column
           renders it through renderSlot('main', …, { entryKey }). */
        main: { kind: 'keyed', scope: 'root' },
        details: { kind: 'single', scope: 'session' },
        'shell.overlay': { kind: 'list', scope: 'root' },
      },
      store,
      inject: (actions) => {
        layout.attach(actions)
        return {
          createEntry: (workspaceId, path, kind, name, signal) => createWorkspaceEntry(workspaceId, path, kind, name, signal),
          listDirectory,
          publishEditorContext: (sessionId, value) => { editorContexts.update(sessionId, value) },
          activateEditorSession: sessionId => { editorContexts.activate(sessionId) },
          renameEntry: (workspaceId, path, name, signal) => renameWorkspaceEntry(workspaceId, path, name, signal),
          retainEditorSessions: sessionIds => { editorContexts.retain(sessionIds) },
          readFile,
          explorerPaneStore,
          previewSessionsStore,
          saveFile,
          loadDraft,
          persistDraftFile,
          removeDraftFile,
          draftTree,
          checkFileChange: checkFileChangeBound,
          settingsStore,
          toggleSidebar: () => { layout.toggleSidebar() },
          renameSession: async (sessionId, title) => {
            const session = ctx.sessions.binding(String(sessionId))?.session
            if (session === undefined) throw new Error(`unknown session "${sessionId}"`)
            const result = await session.rename(title)
            if (!result.ok) throw new Error(result.error.message)
          },
          // Right-click session-list actions: archive via the harness workspaces service, read session/workspace snapshots imperatively.
          archiveSession: sessionId => ctx.workspaces.archiveSession(sessionId),
          getSessionList: () => ctx.sessions.list.getSnapshot(),
          getWorkspaceItems: () => ctx.workspaces.list.getSnapshot().items,
          // Mind-map sidebar entry: open the root session and dock the map as a preview tab.
          openSession: sessionId => { openHarnessSession(ctx, sessionId) },
          deleteMindmapDoc: (sessionId, signal) => deleteMindmapDoc(sessionId, signal),
          // The docked mind-map view's document/fork/archive action face.
          mindmapActions: buildMindmapActions(ctx),
        }
      },
    }, AppFrame)
    return () => {
      disposeRegistration()
      disposePanelInfo()
      void disposeService()
    }
  }, 'workspace-studio: service and root registration')
  const promptContextBridge = new PromptContextBridge(ctx, editorContexts)
  ctx.inject(['conversation'], scope => {
    scope.effect(
      () => promptContextBridge.install(),
      'workspace-studio: prompt context bridge',
    )
  })
  /* The /init slash command: the workspace-task entry point. Its popupSelect lists the tasks
     (AGENTS.md generation/merge, the project logic audit, and the stale-content cleanup);
     the picked option's id IS the locale key of the instruction handed to the model through
     the session's send seam. Only direct sessions can run it; registered when ui-commands is present. */
  ctx.inject(['commandUi'], scope => {
    scope.effect(() => {
      const commandUi = scope.get('commandUi')
      // A deferred inject scope can fire without the service present: degrade
      // to "no command" instead of throwing inside the effect run.
      if (commandUi === undefined) return undefined
      const dispose = commandUi.register({
        name: 'init',
        /* The row face of a built-in row: localized title, the command name as its trailing
           alias, a 14px glyph from the shared set, and a one-line description. A contribution
           without a label falls back to the raw name, which is what made /init read unlike
           the shipped commands. */
        label: () => translate('init.menu.label'),
        description: () => translate('init.menu.description'),
        icon: IconDeliverDocRegular,
        available: session => {
          const row = ctx.sessions.list.getSnapshot().byId[String(session.sessionId)]
          return row !== undefined && row.origin !== 'subagent'
        },
        ui: {
          kind: 'popupSelect',
          options: async (session, signal) => {
            const id = String(session.sessionId)
            const workspace = workspaceOfSession(ctx, id)
            if (workspace === undefined) throw new Error(translate('init.error.no-workspace'))
            const root = workspace.path
            let exists = false
            try {
              const tree = await listDirectory(workspace.workspaceId, '', signal)
              exists = (tree?.entries ?? []).some(entry => entry.kind === 'file' && entry.name === 'AGENTS.md')
            } catch (error) {
              // A failed scan must not block the command: the agent re-checks
              // existence itself; this only decides the option wording.
              if (error?.name === 'AbortError') throw error
            }
            const agents = {
              id: 'init.prompt',
              label: translate(exists ? 'init.option.update' : 'init.option.generate'),
              detail: translate(exists ? 'init.option.update.detail' : 'init.option.generate.detail', { root }),
            }
            return [
              agents,
              { id: 'init.prompt.audit', label: translate('init.option.audit'), detail: translate('init.option.audit.detail', { root }) },
              {
                id: 'init.prompt.cleanup',
                label: translate('init.option.cleanup'),
                detail: translate('init.option.cleanup.detail', { root }),
                /* Deletion is the one task here that cannot be undone in place, so the shared
                   shell gates it behind its risk confirmation instead of running on the pick. */
                confirmation: {
                  title: translate('init.confirm.cleanup.title'),
                  description: translate('init.confirm.cleanup.description', { root }),
                  acknowledgeLabel: translate('init.confirm.cleanup.acknowledge'),
                  cancelLabel: translate('dialog.cancel'),
                  confirmLabel: translate('init.confirm.cleanup.confirm'),
                },
              },
              { id: 'cancel', label: translate('dialog.cancel') },
            ]
          },
          onSelect: async (option, session) => {
            if (option.id === 'cancel') return
            await promptContextBridge.runInitCommand(String(session.sessionId), option.id)
          },
        },
      })
      return dispose
    }, 'workspace-studio: init command')
  })
  ctx.slots.inject('conversation.input.dock', () => ctx.slots.register({
    name: 'conversation.input.dock',
    id: EDITOR_CONTEXT_PROVIDER,
    order: 30,
    inject: sessionId => ({
      hooks: { editorContext: editorContexts.storeFor(String(sessionId)) },
      toggle: () => { editorContexts.toggle(String(sessionId)) },
      ensureSession: id => { promptContextBridge.ensure(id) },
    }),
  }, EditorContextPrefix))
  /* Chat edit/write rows: default-open Studio row with the merged diff view,
     shadowing the shipped FileMutationRow for the edit/write keys. */
  registerStudioFileMutationToolview(ctx)
  /* Route the chat's resource-open path (ctx.sidebarRight.openResource) into the
     plugin's own preview tabs, since the harness right-Sidebar seat never
     mounts under this root layout. A plan address resolves through the harness
     `plan` resource provider, so the reader is installed alongside. */
  installOpenResourceRouter(ctx)
  installPlanResources(ctx)
  ctx.effect(() => () => { editorContexts.dispose() }, 'workspace-studio: editor context state')
  /* Mobile mode entries: the sidebar-footer toggle, the session-header whale + file-content
     browsing controls, and the hero-page whale. Every contribution installs with its slot. */
  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
    name: 'sidebar.footer.action', id: 'workspace-mobile-toggle', order: 110,
  }, MobileModeToggle))
  ctx.slots.inject('conversation.session.header.actions', () => ctx.slots.register({
    name: 'conversation.session.header.actions', id: 'workspace-mobile-controls', order: -300,
  }, MobileHeaderControls))
  /* The session-header mind-map button: opens the current session's mind map
     as a preview tab. */
  ctx.slots.inject('conversation.session.header.actions', () => ctx.slots.register({
    name: 'conversation.session.header.actions', id: 'workspace-mindmap-toggle', order: -350,
  }, MindmapHeaderButton))
  /* Mind-map family sessions (roots + every fork descendant) are hidden from the harness
     sidebar session list; each map is represented by its own sidebar entry instead. */
  ctx.effect(() => installMindmapBranchHider(
    () => ctx.sessions.list.getSnapshot(),
    () => ctx.workspaces.list.getSnapshot().archivedSessionIds,
    () => ctx.workspaces.list.getSnapshot().items,
    /* Archived-row visibility is NOT passed: the Workspace snapshot carries no
       archived filter (that choice lives in ui-workspace's private view store).
       The hider reads whether archived rows are on screen from the rendered
       rows themselves. */
  ), 'workspace-studio: mind-map branch hider')
  /* Background mind-map doc index (feeds the sidebar entries and the hider). */
  ctx.effect(() => {
    if (typeof document === 'undefined') return undefined
    mindmapRegistry.start()
    return () => mindmapRegistry.stop()
  }, 'workspace-studio: mind-map index registry')
  /* Forks the plugin does not own (the chat's own branch button, the workspace navigation
     fork) bypass the map's fork actions: watch the client session service so such a child
     is cleaned of the parent's inherited pending input and lands in the map document. */
  ctx.effect(() => installForeignForkWatch(ctx), 'workspace-studio: foreign fork watch')
  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay', id: 'workspace-mobile-hero', order: -100,
  }, MobileHeroControls))
  // The Settings page owns every explorer preference as one stack of seven cards (maintenance
  // & statistics, browsing & preview, icon & highlight colours, version control, mind map,
  // conversation, interpreters; dev-notes §46).
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section', id: 'workspace-explorer', order: 5, label: () => translate('settings.section.title'),
    inject: () => ({ settingsStore }),
  }, ExplorerSettingsSection))
  ctx.effect(() => {
    /* Every other DOM-touching effect in this file guards on document; the
       ThemePresenter constructs DOM immediately, so it must too. */
    if (typeof document === 'undefined') return undefined
    const presenter = new ThemePresenter()
    presenter.apply(ctx.theme.getTheme())
    const off = ctx.on('theme/change', snapshot => presenter.apply(snapshot))
    return () => {
      off()
      presenter.dispose()
    }
  }, 'workspace-studio: theme presenter')
}
