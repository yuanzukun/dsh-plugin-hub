import { defineStore } from '@deepseek-ai/dsh-client-store'
import { AUTO_SYNC_MODE_AUTO, AUTO_SYNC_MODE_WATCH_ONLY, clampMountBulge, CONFLICT_FONT_SIZE_DEFAULT, CONFLICT_FONT_SIZE_MAX, CONFLICT_FONT_SIZE_MIN, cssColorToHex, DIFF_RULER_DEFAULT, DIFF_RULER_SPAN_DEFAULT, DIFF_RULER_THUMB_DEFAULT, DIFF_RULER_WIDTH_DEFAULT, DIFF_RULER_WIDTH_MAX, DIFF_RULER_WIDTH_MIN, DIFF_TINT_DEFAULT, EDIT_LINES_DEFAULT, EDIT_LINES_MAX, EDIT_LINES_MIN, EXPLORER_LAYOUT_STORE_KEY, EXPLORER_SETTINGS_STORE_KEY, FONT_SCALE_DEFAULT, stepFontPercent, MINDMAP_END_COLOR_DEFAULT, MINDMAP_HEAD_COLOR_DEFAULT, MINDMAP_HOVER_COLOR_FALLBACK, MINDMAP_HOVER_THEME_VAR, MINDMAP_MOUNT_BULGE_DEFAULT_X, MINDMAP_SELECTED_COLOR_FALLBACK, MINDMAP_SELECTED_THEME_VAR, MINDMAP_SPIN_SPEED_DEFAULT_X, MINDMAP_SPIN_SPEED_MAX_X, MINDMAP_SPIN_SPEED_MIN_X, MINDMAP_SUMMARY_DEFAULT_LENGTH, MINDMAP_SUMMARY_LENGTH_STEP, MINDMAP_SUMMARY_MAX_LENGTH, MINDMAP_SUMMARY_MIN_LENGTH, MINDMAP_SUMMARY_SESSION_DEFAULT_LENGTH, MINDMAP_SUMMARY_SESSION_LENGTH_STEP, MINDMAP_SUMMARY_SESSION_MAX_LENGTH, MINDMAP_SUMMARY_SESSION_MIN_LENGTH, mindmapEffectiveColor, PREVIEW_DEFAULT, PREVIEW_MAX, PREVIEW_MIN, PREVIEW_RIGHT_DEFAULT, PREVIEW_SESSION_STORE_KEY, ROW_HEIGHT_DEFAULT, ROW_HEIGHT_MAX, ROW_HEIGHT_MIN, SEARCH_MATCH_EXPAND_DEFAULT, SIDEBAR_DEFAULT, SIDEBAR_MAX_FALLBACK, SIDEBAR_MIN, THINK_LINES_DEFAULT, THINK_LINES_MAX, THINK_LINES_MIN, TREE_DEFAULT, TREE_MAX, TREE_MIN, VCS_HIDE_METADATA_DEFAULT, WATCH_FILES_DEFAULT } from './constants.js'
import { clamp, diffColorDefault, fileColorDefault, highlightPresetDefaultFor, vcsStatusColorDefault } from './format.js'
import { normalizePreviewSession, prunePreviewSessions } from './preview-tabs.js'
import { readPersistedState } from './persisted-state.js'

// The persisted sidebar width lives with the explorer pane geometry
// (EXPLORER_LAYOUT_STORE_KEY), so this rehydrates it on load; 0 means
// collapsed. The schema in persisted-state.js owns the shape, so the value is
// either canonical or absent — a missing key falls back to the default width.
function readPersistedSidebarWidth() {
  const layout = readPersistedState(EXPLORER_LAYOUT_STORE_KEY)
  return layout === null ? SIDEBAR_DEFAULT : layout.sidebar
}
export function createLayoutStore() {
  return defineStore({
    init: () => ({
      sidebar: readPersistedSidebarWidth(),
      detailsOpen: false,
      // Sidebar browsing region: 'sessions' = workspace/session browser; 'files' swaps the same region for the file tree.
      view: 'sessions',
      /* Selected global main panel (the harness's PanelInfo contract); the chat column renders the conversation whenever no panel is selected. */
      panelInfo: { activePanelId: null },
    }),
    actions: {
      setSidebar: (draft, width, max = SIDEBAR_MAX_FALLBACK) => { draft.sidebar = width === 0 ? 0 : clamp(width, SIDEBAR_MIN, max) },
      toggleSidebar: (draft) => { draft.sidebar = draft.sidebar === 0 ? SIDEBAR_DEFAULT : 0 },
      openDetails: (draft) => { draft.detailsOpen = true },
      closeDetails: (draft) => { draft.detailsOpen = false },
      setView: (draft, view) => { draft.view = view === 'files' ? 'files' : 'sessions' },
      selectPanel: (draft, panelId) => {
        draft.panelInfo = { activePanelId: panelId === null || panelId === undefined ? null : String(panelId) }
      },
    },
  })
}
/* Explorer pane geometry shared by every session: file-tree width, preview width, and sidebar width (0 = collapsed). */
export function createExplorerPaneStore() {
  return defineStore({
    init: () => ({
      tree: TREE_DEFAULT,
      preview: PREVIEW_DEFAULT,
      sidebar: SIDEBAR_DEFAULT,
    }),
    persist: EXPLORER_LAYOUT_STORE_KEY,
    actions: {
      setTree: (draft, width, max = TREE_MAX) => { draft.tree = clamp(width, TREE_MIN, max) },
      setPreview: (draft, width, max = PREVIEW_MAX) => { draft.preview = clamp(width, PREVIEW_MIN, max) },
      setSidebar: (draft, width, max = SIDEBAR_MAX_FALLBACK) => { draft.sidebar = width === 0 ? 0 : clamp(width, SIDEBAR_MIN, max) },
    },
  })
}
export function createPreviewSessionStore() {
  return defineStore({
    init: () => ({
      previewSessions: {},
    }),
    persist: PREVIEW_SESSION_STORE_KEY,
    actions: {
      rememberPreviewSession: (draft, key, value) => {
        // Live values arrive from the explorer; the persisted shape is owned by
        // persisted-state.js, so a malformed call only has to keep the map usable.
        if (draft.previewSessions === undefined || draft.previewSessions === null || typeof draft.previewSessions !== 'object') draft.previewSessions = {}
        const normalized = normalizePreviewSession(value)
        if (normalized.tabs.length === 0 && (normalized.expanded ?? []).length === 0) delete draft.previewSessions[String(key)]
        else {
          // Timestamp every write so stale sessions can be pruned below.
          draft.previewSessions[String(key)] = { ...normalized, updatedAt: Date.now() }
          prunePreviewSessions(draft)
        }
      },
    },
  })
}
export function createExplorerSettingsStore() {
  return defineStore({
    init: () => ({
      rowHeight: ROW_HEIGHT_DEFAULT,
      conflictFontSize: CONFLICT_FONT_SIZE_DEFAULT,
      /* Preview content text size (percent): the base a tab without its own fontPercent follows. */
      previewFontScale: FONT_SCALE_DEFAULT,
      wrap: false,
      expandSearchMatches: SEARCH_MATCH_EXPAND_DEFAULT,
      thinkLines: THINK_LINES_DEFAULT,
      editLines: EDIT_LINES_DEFAULT,
      mindmapSpinSpeed: MINDMAP_SPIN_SPEED_DEFAULT_X,
      mindmapHoverColor: undefined,
      mindmapSelectedColor: undefined,
      mindmapHeadColor: undefined,
      mindmapEndColor: undefined,
      mindmapMountBulge: MINDMAP_MOUNT_BULGE_DEFAULT_X,
      /* AI card summaries: off by default (no hidden token cost); model undefined = "follow the session's model". */
      mindmapSummaryEnabled: false,
      mindmapSummaryModel: undefined,
      mindmapSummaryLength: MINDMAP_SUMMARY_DEFAULT_LENGTH,
      mindmapSummarySessionLength: MINDMAP_SUMMARY_SESSION_DEFAULT_LENGTH,
      fileColors: {},
      highlightPresets: {},
      previewRight: PREVIEW_RIGHT_DEFAULT,
      watchFiles: WATCH_FILES_DEFAULT,
      autoSyncMode: AUTO_SYNC_MODE_AUTO,
      /* Version-control status display (git / svn): all display-only, so the feature never
         depends on a persisted value being well-formed. */
      vcsEnabled: true,
      vcsShowIgnored: false,
      vcsHideDirs: VCS_HIDE_METADATA_DEFAULT,
      vcsAutoRefresh: true,
      vcsColors: {},
      /* Editor change gutter: its own tone palette (defaults green / blue / red) plus the line wash. */
      diffColors: {},
      diffLineTint: DIFF_TINT_DEFAULT,
      /* Scrollbar change ruler: the widened track and its mark geometry. */
      diffRuler: DIFF_RULER_DEFAULT,
      diffRulerWidth: DIFF_RULER_WIDTH_DEFAULT,
      diffRulerSpan: DIFF_RULER_SPAN_DEFAULT,
      diffRulerThumb: DIFF_RULER_THUMB_DEFAULT,
    }),
    persist: EXPLORER_SETTINGS_STORE_KEY,
    actions: {
      setRowHeight: (draft, value) => { draft.rowHeight = clamp(value, ROW_HEIGHT_MIN, ROW_HEIGHT_MAX) },
      setConflictFontSize: (draft, value) => { draft.conflictFontSize = clamp(value, CONFLICT_FONT_SIZE_MIN, CONFLICT_FONT_SIZE_MAX) },
      /* The base preview text size walks the same 10% grid its slider renders, so the stored value
         always sits on a step (a typed per-tab value is deliberately NOT snapped). */
      setPreviewFontScale: (draft, value) => { draft.previewFontScale = stepFontPercent(value, 0) },
      setWrap: (draft, value) => { draft.wrap = Boolean(value) },
      setExpandSearchMatches: (draft, value) => { draft.expandSearchMatches = Boolean(value) },
      setThinkLines: (draft, value) => { draft.thinkLines = clamp(value, THINK_LINES_MIN, THINK_LINES_MAX) },
      setEditLines: (draft, value) => { draft.editLines = clamp(value, EDIT_LINES_MIN, EDIT_LINES_MAX) },
      setMindmapSpinSpeed: (draft, value) => {
        const speed = Number(value)
        const bounded = Number.isFinite(speed)
          ? Math.min(MINDMAP_SPIN_SPEED_MAX_X, Math.max(MINDMAP_SPIN_SPEED_MIN_X, speed))
          : MINDMAP_SPIN_SPEED_DEFAULT_X
        draft.mindmapSpinSpeed = Math.round(bounded * 10) / 10
      },
      setMindmapHoverColor: (draft, value) => {
        const hex = cssColorToHex(value)
        if (hex === null) return
        const defaultHex = mindmapEffectiveColor(undefined, MINDMAP_HOVER_THEME_VAR, MINDMAP_HOVER_COLOR_FALLBACK)
        if (hex === defaultHex) delete draft.mindmapHoverColor
        else draft.mindmapHoverColor = hex
      },
      resetMindmapHoverColor: (draft) => { delete draft.mindmapHoverColor },
      setMindmapSelectedColor: (draft, value) => {
        const hex = cssColorToHex(value)
        if (hex === null) return
        const defaultHex = mindmapEffectiveColor(undefined, MINDMAP_SELECTED_THEME_VAR, MINDMAP_SELECTED_COLOR_FALLBACK)
        if (hex === defaultHex) delete draft.mindmapSelectedColor
        else draft.mindmapSelectedColor = hex
      },
      resetMindmapSelectedColor: (draft) => { delete draft.mindmapSelectedColor },
      setMindmapHeadColor: (draft, value) => {
        const hex = cssColorToHex(value)
        if (hex === null) return
        /* The default head color is the fixed violet (not a theme var): picking it back means "use the default". */
        if (hex === MINDMAP_HEAD_COLOR_DEFAULT) delete draft.mindmapHeadColor
        else draft.mindmapHeadColor = hex
      },
      resetMindmapHeadColor: (draft) => { delete draft.mindmapHeadColor },
      setMindmapEndColor: (draft, value) => {
        const hex = cssColorToHex(value)
        if (hex === null) return
        /* The default end-card color is the fixed success green (not a theme var): picking it back means "use the default". */
        if (hex === MINDMAP_END_COLOR_DEFAULT) delete draft.mindmapEndColor
        else draft.mindmapEndColor = hex
      },
      resetMindmapEndColor: (draft) => { delete draft.mindmapEndColor },
      setMindmapMountBulge: (draft, value) => { draft.mindmapMountBulge = clampMountBulge(value) },
      setMindmapSummaryEnabled: (draft, value) => { draft.mindmapSummaryEnabled = Boolean(value) },
      setMindmapSummaryModel: (draft, value) => {
        if (value === null || value === undefined) delete draft.mindmapSummaryModel
        else if (typeof value?.provider === 'string' && value.provider !== ''
          && typeof value?.model === 'string' && value.model !== '') {
          draft.mindmapSummaryModel = { provider: value.provider, model: value.model }
        }
      },
      setMindmapSummaryLength: (draft, value) => {
        const raw = Number(value)
        if (!Number.isFinite(raw)) { draft.mindmapSummaryLength = MINDMAP_SUMMARY_DEFAULT_LENGTH; return }
        const stepped = Math.round(raw / MINDMAP_SUMMARY_LENGTH_STEP) * MINDMAP_SUMMARY_LENGTH_STEP
        draft.mindmapSummaryLength = Math.min(MINDMAP_SUMMARY_MAX_LENGTH, Math.max(MINDMAP_SUMMARY_MIN_LENGTH, stepped))
      },
      setMindmapSummarySessionLength: (draft, value) => {
        const raw = Number(value)
        if (!Number.isFinite(raw)) { draft.mindmapSummarySessionLength = MINDMAP_SUMMARY_SESSION_DEFAULT_LENGTH; return }
        const stepped = Math.round(raw / MINDMAP_SUMMARY_SESSION_LENGTH_STEP) * MINDMAP_SUMMARY_SESSION_LENGTH_STEP
        draft.mindmapSummarySessionLength = Math.min(MINDMAP_SUMMARY_SESSION_MAX_LENGTH, Math.max(MINDMAP_SUMMARY_SESSION_MIN_LENGTH, stepped))
      },
      setFileColor: (draft, group, value) => {
        if (draft.fileColors === undefined) draft.fileColors = {}
        if (String(value).toLowerCase() === fileColorDefault(group).toLowerCase()) delete draft.fileColors[group]
        else draft.fileColors[group] = String(value)
      },
      resetFileColor: (draft, group) => { if (draft.fileColors !== undefined) delete draft.fileColors[group] },
      resetFileColors: (draft) => { draft.fileColors = {} },
      setHighlightPreset: (draft, group, presetId) => {
        if (draft.highlightPresets === undefined) draft.highlightPresets = {}
        if (presetId === highlightPresetDefaultFor(group)) delete draft.highlightPresets[group]
        else draft.highlightPresets[group] = String(presetId)
      },
      resetHighlightPreset: (draft, group) => { if (draft.highlightPresets !== undefined) delete draft.highlightPresets[group] },
      resetHighlightPresets: (draft) => { draft.highlightPresets = {} },
      setPreviewRight: (draft, value) => { draft.previewRight = Boolean(value) },
      setWatchFiles: (draft, value) => { draft.watchFiles = Boolean(value) },
      setAutoSyncMode: (draft, value) => {
        draft.autoSyncMode = value === AUTO_SYNC_MODE_WATCH_ONLY ? AUTO_SYNC_MODE_WATCH_ONLY : AUTO_SYNC_MODE_AUTO
      },
      /* Version-control display preferences: every one of them only affects rendering. */
      setVcsEnabled: (draft, value) => { draft.vcsEnabled = Boolean(value) },
      setVcsShowIgnored: (draft, value) => { draft.vcsShowIgnored = Boolean(value) },
      setVcsHideDirs: (draft, value) => { draft.vcsHideDirs = Boolean(value) },
      setVcsAutoRefresh: (draft, value) => { draft.vcsAutoRefresh = Boolean(value) },
      setVcsColor: (draft, group, value) => {
        if (draft.vcsColors === undefined) draft.vcsColors = {}
        if (String(value).toLowerCase() === vcsStatusColorDefault(group).toLowerCase()) delete draft.vcsColors[group]
        else draft.vcsColors[group] = String(value)
      },
      resetVcsColor: (draft, group) => { if (draft.vcsColors !== undefined) delete draft.vcsColors[group] },
      resetVcsColors: (draft) => { draft.vcsColors = {} },
      setDiffColor: (draft, group, value) => {
        if (draft.diffColors === undefined) draft.diffColors = {}
        if (String(value).toLowerCase() === diffColorDefault(group).toLowerCase()) delete draft.diffColors[group]
        else draft.diffColors[group] = String(value)
      },
      resetDiffColor: (draft, group) => { if (draft.diffColors !== undefined) delete draft.diffColors[group] },
      resetDiffColors: (draft) => { draft.diffColors = {} },
      setDiffLineTint: (draft, value) => { draft.diffLineTint = Boolean(value) },
      setDiffRuler: (draft, value) => { draft.diffRuler = Boolean(value) },
      /* Snap onto the slider's 2px grid (10 / 12 / 14 / 16 / 18) so the thumb always sits on a step. */
      setDiffRulerWidth: (draft, value) => {
        const number = Number(value)
        const bounded = Number.isFinite(number)
          ? Math.min(DIFF_RULER_WIDTH_MAX, Math.max(DIFF_RULER_WIDTH_MIN, number))
          : DIFF_RULER_WIDTH_DEFAULT
        draft.diffRulerWidth = DIFF_RULER_WIDTH_MIN + Math.round((bounded - DIFF_RULER_WIDTH_MIN) / 2) * 2
      },
      setDiffRulerSpan: (draft, value) => { draft.diffRulerSpan = value === 'full' ? 'full' : 'inset' },
      setDiffRulerThumb: (draft, value) => { draft.diffRulerThumb = value === 'full' ? 'full' : 'slim' },
    },
  })
}
export class LayoutController { constructor(panelInfo){this.panelInfo=panelInfo} attach(actions){this.actions=actions} requireActions(){if(!this.actions)throw new Error('workspace-studio: root store actions are not attached');return this.actions} toggleSidebar(){this.requireActions().toggleSidebar()} openDetails(){this.requireActions().openDetails()} closeDetails(){this.requireActions().closeDetails()} /* The harness ILayout face this plugin's root layout must satisfy: panelInfo is the root store's central-panel selection, which global-panel plugins read through ctx.layout; selectPanel drives the main slot's entryKey; the right-panel verbs are no-ops because this layout has no rightbar track. */ selectPanel(panelId){this.requireActions().selectPanel(panelId)} beginNavigation(){return new AbortController().signal} openRightbar(){} closeRightbar(){} }