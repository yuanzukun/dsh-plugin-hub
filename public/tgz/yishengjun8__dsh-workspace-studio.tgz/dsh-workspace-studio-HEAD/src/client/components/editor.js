import { createElement as h, useRef, useState, useEffect } from 'react'
import { closeSearchPanel, findNext, findPrevious, gotoLine, highlightSelectionMatches, openSearchPanel, search, selectNextOccurrence, selectSelectionMatches } from '@codemirror/search'
import { EditorState, Compartment, RangeSet, RangeSetBuilder, StateEffect, StateField } from '@codemirror/state'
import { defaultKeymap, history, historyKeymap, indentWithTab } from '@codemirror/commands'
import { closeBrackets, closeBracketsKeymap } from '@codemirror/autocomplete'
import { bracketMatching, defaultHighlightStyle, foldable, foldEffect, foldGutter, foldKeymap, indentOnInput, syntaxHighlighting, unfoldAll } from '@codemirror/language'
import { Decoration, EditorView, GutterMarker, drawSelection, dropCursor, gutter, highlightActiveLine, highlightActiveLineGutter, keymap, lineNumbers, panels } from '@codemirror/view'
import { localeIsZh, translate, useLocaleText } from '../locale/index.js'
import { languageFor, tokenHighlight } from '../languages.js'
import { HIGHLIGHT_PRESET_DEFAULT, lineSeparator } from '../format.js'
import { DIFF_GUTTER_DEBOUNCE_MS, DIFF_GUTTER_MAX_LINES } from '../constants.js'
import { diffMarks, rulerLayers } from '../diff-gutter.js'

/* CodeMirror search/goto-line panel phrases (EditorState.phrases keys; keep the $ placeholders); only installed for the Chinese surface, since English is CodeMirror's default. */
const CM_PHRASES_ZH = Object.freeze({
  'Find': '查找',
  'Replace': '替换为',
  'next': '下一个',
  'previous': '上一个',
  'all': '全部',
  'match case': '区分大小写',
  'regexp': '正则',
  'by word': '全字匹配',
  'replace': '替换',
  'replace all': '全部替换',
  'close': '关闭',
  'Go to line': '跳转到行',
  'go': '跳转',
  'current match': '当前匹配',
  'on line': '行',
  'replaced match on line $': '已在第 $ 行替换匹配',
  'replaced $ matches': '已替换 $ 个匹配项',
})

function revealPosition(view, reveal) {
  /* NaN/non-numeric line data must not reach Text.line: Math.min/max propagate
     NaN and the line() guard treats NaN as in-bounds, landing on a wrong line. */
  const rawLine = Number(reveal?.line)
  const lineNumber = Number.isFinite(rawLine)
    ? Math.min(Math.max(1, Math.round(rawLine)), view.state.doc.lines)
    : 1
  const line = view.state.doc.line(lineNumber)
  const rawColumn = Number(reveal?.column)
  const startColumn = Number.isFinite(rawColumn)
    ? Math.min(Math.max(1, Math.round(rawColumn)), line.length + 1)
    : 1
  const rawEndColumn = Number(reveal?.endColumn)
  const endColumn = Number.isFinite(rawEndColumn)
    ? Math.min(Math.max(startColumn, Math.round(rawEndColumn)), line.length + 1)
    : startColumn
  const from = line.from + startColumn - 1
  const to = line.from + endColumn - 1
  view.dispatch({ selection: { anchor: from, head: to }, effects: EditorView.scrollIntoView(from, { y: 'center' }) })
}

/* Code-folding helpers backing Ctrl+K+J / Ctrl+K+<n>; nesting depth is 1-based. */
function collectFoldableRanges(view) {
  const state = view.state
  const seen = new Set()
  const ranges = []
  for (let pos = 0; pos < state.doc.length;) {
    const line = view.lineBlockAt(pos)
    const range = foldable(state, line.from, line.to)
    if (range) {
      const key = `${range.from}:${range.to}`
      if (!seen.has(key)) {
        seen.add(key)
        ranges.push(range)
      }
    }
    pos = line.to + 1
  }
  return ranges
}
/* Nesting depth per foldable range: 1 for top-level, +1 per enclosing region;
   one stack sweep computes all depths in linear time. */
function foldLevelsOf(ranges) {
  const ordered = [...ranges].sort((a, b) => a.from - b.from || b.to - a.to)
  const levels = new Array(ordered.length)
  const stack = []
  for (let index = 0; index < ordered.length; index += 1) {
    const range = ordered[index]
    while (stack.length > 0 && stack[stack.length - 1].to <= range.from) stack.pop()
    levels[index] = stack.length + 1
    stack.push(range)
  }
  return { ordered, levels }
}
/* Fold every foldable region whose nesting depth is exactly `level`. */
function foldLevel(view, level) {
  const ranges = collectFoldableRanges(view)
  const { ordered, levels } = foldLevelsOf(ranges)
  const effects = []
  for (let index = 0; index < ordered.length; index += 1) {
    if (levels[index] === level) effects.push(foldEffect.of(ordered[index]))
  }
  if (effects.length) {
    view.dispatch({ effects })
    return true
  }
  return false
}

/* --- Live-editor bridge ------------------------------------------------
 * The update listener is part of the EditorState CONFIGURATION: a state retained for a
 * later tab re-activation carries an earlier instance's listener. All listeners delegate
 * through this module-level bridge, which always points at the currently mounted
 * instance's refs, so stale and fresh listeners reach the same live callbacks (dev-notes §23). */
const liveEditorBridge = { current: null }
let editorInstanceSeq = 0
function handleEditorUpdate(update) {
  const bridge = liveEditorBridge.current
  if (bridge === null) return
  if (update.docChanged) {
    /* One sliceDoc per change, shared by the autosave and the context publish;
       the docChanged flag lets it rebuild its CRLF prefix table only on change. */
    const text = update.state.sliceDoc()
    bridge.dirtyRef.current(text)
    bridge.contextRef.current(update.state, true, text)
    /* The change gutter follows the LIVE buffer, so an edit schedules its recompute here (throttled
       by the instance; the marks themselves stay mapped by the document until it lands). */
    bridge.scheduleDiff?.()
  } else if (update.selectionSet) {
    bridge.contextRef.current(update.state, false)
  }
  const sink = bridge.stateSinkRef.current
  if (sink !== null) {
    const comps = bridge.compartmentsRef.current
    sink(bridge.path, {
      state: update.state,
      editable: comps.editable,
      wrap: comps.wrap,
      phrases: comps.phrases,
      name: bridge.name,
    })
  }
}

/* ------------------------------------------------------------------------
 * Change gutter: the repository base versus the live buffer.
 *
 * CodeMirror has no "git gutter" primitive, so the marks live in a StateField an
 * effect replaces; between recomputes the mapped ranges follow the document, keeping
 * the bars roughly in place while typing instead of blanking. The diff is merge.js's
 * budgeted Myers (diff-gutter.js), so a second diff implementation never ships.
 * ---------------------------------------------------------------------- */

/** One line's mark: a colour bar (`kind`) and/or a deletion triangle (`deleted`). */
class DiffLineMarker extends GutterMarker {
  constructor(kind, deleted) {
    super()
    this.kind = kind === undefined ? null : kind
    this.deleted = deleted === undefined ? null : deleted
  }
  eq(other) { return other.kind === this.kind && other.deleted === this.deleted }
  toDOM() {
    const node = document.createElement('div')
    node.className = 'dsh-ws-diffMark'
    if (this.kind !== null) node.dataset.kind = this.kind
    if (this.deleted !== null) node.dataset.deleted = this.deleted
    return node
  }
}
const setDiffDecorations = StateEffect.define()
const diffDecorationsField = StateField.define({
  create: () => ({ gutter: RangeSet.empty, lines: Decoration.none }),
  update(value, transaction) {
    let next = transaction.docChanged
      ? { gutter: value.gutter.map(transaction.changes), lines: value.lines.map(transaction.changes) }
      : value
    for (const effect of transaction.effects) {
      if (effect.is(setDiffDecorations)) next = effect.value
    }
    return next
  },
  provide: field => EditorView.decorations.from(field, value => value.lines),
})
const emptyDiffDecorations = () => ({ gutter: RangeSet.empty, lines: Decoration.none })

/** Paint (or clear) the scrollbar change ruler: two CSS gradients the scroller's track reads through
 *  custom properties, so the marks live UNDER the native slider and no scroll behaviour changes.
 *  Passing null clears both, which is what every "no base to compare against" path wants. */
function applyRuler(view, marks, totalLines) {
  const style = view.scrollDOM.style
  const layers = marks === null || marks === undefined ? null : rulerLayers(marks, totalLines)
  for (const [property, value] of [
    ['--dsh-ws-ruler-bands', layers?.bands ?? null],
    ['--dsh-ws-ruler-ticks', layers?.ticks ?? null],
  ]) {
    if (typeof value === 'string' && value !== '') style.setProperty(property, value)
    else style.removeProperty(property)
  }
}

/** Gutter markers plus (optionally) the line wash of one mark list; line numbers are 1-based. */
function diffDecorationSets(state, marks, tint) {
  const gutterBuilder = new RangeSetBuilder()
  const lineRanges = []
  for (const mark of marks) {
    const number = Math.min(Math.max(1, mark.line), state.doc.lines)
    const line = state.doc.line(number)
    gutterBuilder.add(line.from, line.from, new DiffLineMarker(mark.kind, mark.deleted))
    if (tint !== true) continue
    const classes = []
    if (mark.kind === 'added') classes.push('dsh-ws-diff-line-added')
    else if (mark.kind === 'modified') classes.push('dsh-ws-diff-line-modified')
    if (mark.deleted === 'top') classes.push('dsh-ws-diff-line-deleted-top')
    else if (mark.deleted === 'bottom') classes.push('dsh-ws-diff-line-deleted-bottom')
    if (classes.length > 0) lineRanges.push(Decoration.line({ class: classes.join(' ') }).range(line.from))
  }
  return { gutter: gutterBuilder.finish(), lines: Decoration.set(lineRanges, true) }
}

/* Fold gutter marker: one vector chevron that rotates while folded, replacing
   CodeMirror's default ⌄ / › TEXT glyphs (font-dependent metrics, no rotation). */
function foldMarkerDOM(open) {
  const ns = 'http://www.w3.org/2000/svg'
  const svg = document.createElementNS(ns, 'svg')
  svg.setAttribute('aria-hidden', 'true')
  svg.setAttribute('class', 'fold-mark')
  svg.setAttribute('data-open', open ? 'true' : 'false')
  svg.setAttribute('viewBox', '0 0 10 10')
  const path = document.createElementNS(ns, 'path')
  path.setAttribute('d', 'M2 3.6 5 6.6l3-3')
  path.setAttribute('fill', 'none')
  path.setAttribute('stroke', 'currentColor')
  path.setAttribute('stroke-width', '1.4')
  path.setAttribute('stroke-linecap', 'round')
  path.setAttribute('stroke-linejoin', 'round')
  svg.append(path)
  const wrap = document.createElement('span')
  wrap.className = 'dsh-ws-foldMark'
  wrap.title = translate(open ? 'editor.foldLine' : 'editor.unfoldLine')
  wrap.append(svg)
  return wrap
}
const diffGutterExtension = [
  diffDecorationsField,
  gutter({ class: 'dsh-ws-diffGutter', markers: view => view.state.field(diffDecorationsField).gutter }),
]

/* `restore` (optional) is a retained EditorSession of a file previously shown:
   { state, editable, wrap, phrases, name }. Mounting from the same EditorState preserves
   the doc, undo history, selection and fold state across tab switches; without it the view
   is built fresh from `file.content`. `onViewState` (optional) reports the live
   { state, ...compartments, name } on every update and at mount. */
export function CodeEditor({ file, editing, wrap, onContext, onDirty, onSaveShortcut, onScroll, reveal, scrollTop, editorRef, highlightPreset, searchPanelContainer, readEpoch, onRevealApplied, restore = null, onViewState = null, diffBase = null, diffLineTint = true, diffColors = null, onDiffSummary = null }) {
  const host = useRef(null)
  /* Lazy compartments: useRef(new Compartment()) would construct a discarded object on every
     render. A view mounted from a restored state must reconfigure the compartments that state
     carries, so every dispatch targets `compartments` (restored when present, own otherwise). */
  const [editableCompartment] = useState(() => new Compartment())
  const [wrapCompartment] = useState(() => new Compartment())
  const [phrasesCompartment] = useState(() => new Compartment())
  const localeTick = useLocaleText()
  const compartments = restore !== null
    ? { editable: restore.editable, wrap: restore.wrap, phrases: restore.phrases }
    : { editable: editableCompartment, wrap: wrapCompartment, phrases: phrasesCompartment }
  const contextRef = useRef(onContext)
  const dirtyRef = useRef(onDirty)
  const saveRef = useRef(onSaveShortcut)
  const scrollRef = useRef(onScroll)
  const revealRef = useRef(null)
  const onRevealAppliedRef = useRef(onRevealApplied)
  const revealAppliedRef = useRef(null)
  const stateSinkRef = useRef(onViewState)
  const compartmentsRef = useRef(compartments)
  contextRef.current = onContext
  dirtyRef.current = onDirty
  saveRef.current = onSaveShortcut
  scrollRef.current = onScroll
  revealRef.current = reveal
  onRevealAppliedRef.current = onRevealApplied
  stateSinkRef.current = onViewState
  compartmentsRef.current = compartments
  // A reveal is consumed the first time it is applied, so returning to the tab
  // restores the persisted scroll instead of re-jumping to a stale match.
  const markRevealApplied = (target) => {
    if (target === null || revealAppliedRef.current === target) return
    revealAppliedRef.current = target
    onRevealAppliedRef.current?.()
  }
  /* The render-time instance owns the live bridge; a per-instance token keeps
     an unmount cleanup from nulling a bridge a newer instance already took
     over. */
  const bridgeSelfRef = useRef(null)
  if (bridgeSelfRef.current === null) {
    bridgeSelfRef.current = {
      token: ++editorInstanceSeq,
      path: file.path,
      name: file.name,
      dirtyRef,
      contextRef,
      stateSinkRef,
      compartmentsRef,
      /* Assigned below, once the change-gutter scheduler exists (see handleEditorUpdate). */
      scheduleDiff: null,
    }
  } else {
    bridgeSelfRef.current.path = file.path
    bridgeSelfRef.current.name = file.name
  }
  liveEditorBridge.current = bridgeSelfRef.current

  /* ---- Change gutter: recompute the marks from the live buffer ----
   * Runs on the throttled schedule above, never inside a keystroke's transaction: the field keeps
   * the mapped previous marks until the new ones land, so typing never blanks the gutter. */
  const diffBaseRef = useRef(diffBase)
  const diffTintRef = useRef(diffLineTint)
  const diffSummaryRef = useRef(onDiffSummary)
  const diffTimerRef = useRef(undefined)
  diffBaseRef.current = diffBase
  diffTintRef.current = diffLineTint
  diffSummaryRef.current = onDiffSummary
  const applyDiff = () => {
    const view = editorRef.current
    if (view === undefined || view === null) return
    const base = diffBaseRef.current
    /* No base to compare against (no repository, feature off, still loading): say nothing at all
       rather than claiming "not computed" — the status strip already explains a missing repository. */
    if (base === null || base === undefined) {
      view.dispatch({ effects: setDiffDecorations.of(emptyDiffDecorations()) })
      applyRuler(view, null, 0)
      diffSummaryRef.current?.({ status: 'pending', baseLabel: '' })
      return
    }
    const lines = view.state.doc.lines
    if (lines > DIFF_GUTTER_MAX_LINES) {
      view.dispatch({ effects: setDiffDecorations.of(emptyDiffDecorations()) })
      applyRuler(view, null, 0)
      diffSummaryRef.current?.({ status: 'unavailable', reason: 'too-large', baseLabel: base?.baseLabel ?? '' })
      return
    }
    let outcome
    if (base !== null && base !== undefined && base.newFile === true) {
      /* A file the repository does not have yet: every line is new (matches the tree's ? / A badge). */
      const marks = []
      for (let number = 1; number <= lines; number += 1) marks.push({ line: number, kind: 'added' })
      outcome = { status: 'ok', marks, summary: { added: lines, modified: 0, deleted: 0 } }
    } else {
      const baseText = base !== null && base !== undefined && base.exists === true && typeof base.content === 'string'
        ? base.content
        : undefined
      outcome = diffMarks(baseText, view.state.sliceDoc())
    }
    view.dispatch({
      effects: setDiffDecorations.of(outcome.status === 'ok'
        ? diffDecorationSets(view.state, outcome.marks, diffTintRef.current === true)
        : emptyDiffDecorations()),
    })
    /* The ruler rides the SAME marks (one diff per recompute) but ignores the line-tint setting:
       it is a map of the file, not another way to wash the rows. */
    applyRuler(view, outcome.status === 'ok' ? outcome.marks : null, lines)
    diffSummaryRef.current?.(outcome.status === 'ok'
      ? { status: 'ok', summary: outcome.summary, baseLabel: base?.baseLabel ?? '', newFile: base?.newFile === true }
      : { status: 'unavailable', reason: outcome.reason, baseLabel: base?.baseLabel ?? '' })
  }
  const applyDiffRef = useRef(applyDiff)
  applyDiffRef.current = applyDiff
  /* Throttled rather than trailing-debounced: at most one recompute per window while typing. */
  const scheduleDiff = () => {
    if (diffTimerRef.current !== undefined) return
    diffTimerRef.current = setTimeout(() => {
      diffTimerRef.current = undefined
      applyDiffRef.current()
    }, DIFF_GUTTER_DEBOUNCE_MS)
  }
  bridgeSelfRef.current.scheduleDiff = scheduleDiff
  /* The base text, the tint setting or a reload changed: recompute once the view exists (a macrotask,
     so the mount effect below has already created it). */
  useEffect(() => {
    const timer = setTimeout(() => { applyDiffRef.current() }, 0)
    return () => { clearTimeout(timer) }
  }, [diffBase, diffLineTint, readEpoch])
  useEffect(() => () => {
    if (diffTimerRef.current !== undefined) clearTimeout(diffTimerRef.current)
  }, [])

  useEffect(() => {
    const comps = compartments
    const retained = restore === null ? null : restore.state
    let view
    if (retained !== null) {
      /* Restored session: build the view around the retained EditorState so the doc, undo
         history, selection and folds come back as they were; that state already carries its
         update listener, which routes through the live bridge. */
      view = new EditorView({ parent: host.current, state: retained })
    } else {
      const descriptor = languageFor(file.name)
      const separator = lineSeparator(file.lineEnding)
      const separatorExtension = file.lineEnding === 'mixed'
        ? []
        : EditorState.lineSeparator.of(separator)
      view = new EditorView({
        parent: host.current,
        state: EditorState.create({
          doc: file.content,
          extensions: [
            /* Gutter order is extension order, and it is the user-facing order: line numbers,
               then the change marks, then the fold arrows (all left of the code). */
            lineNumbers(), diffGutterExtension, highlightActiveLineGutter(), history(),
            foldGutter({ markerDOM: foldMarkerDOM }), drawSelection(), dropCursor(),
            EditorState.allowMultipleSelections.of(true), indentOnInput(), bracketMatching(), closeBrackets(),
            highlightSelectionMatches(), highlightActiveLine(), syntaxHighlighting(defaultHighlightStyle, { fallback: true }),
            /* The search panel renders into a container div between the file header (and its
               notices) and the preview body: top:true puts it in the top panel group, and
               panels({ topContainer }) places that group in the plugin-owned container. */
            search({ top: true }),
            panels(searchPanelContainer?.current ? { topContainer: searchPanelContainer.current } : undefined),
            /* Search/goto-line panel labels render through EditorState.phrase();
               without this map they show English. */
            comps.phrases.of(localeIsZh() ? EditorState.phrases.of(CM_PHRASES_ZH) : []),
            syntaxHighlighting(tokenHighlight),
            keymap.of([
              /* Mod-s is deliberately not bound here: the window-level capture
                 handler owns it so saving works from every focus state. */
              indentWithTab, ...closeBracketsKeymap, ...defaultKeymap,
              /* Editor-only search keys stay in the keymap: Escape closes the panel;
                 Ctrl+D / Ctrl+Shift+L / Ctrl+Alt+G select occurrences, matches, or jump
                 to a line. Find is deliberately unbound — the window capture handler owns it. */
              { key: 'Escape', run: closeSearchPanel, scope: 'editor search-panel' },
              { key: 'Mod-Shift-l', run: selectSelectionMatches },
              { key: 'Mod-Alt-g', run: gotoLine },
              { key: 'Mod-d', run: selectNextOccurrence, preventDefault: true },
              ...historyKeymap, ...foldKeymap,
            ]),
            /* The listener is part of the state configuration: retained states keep
               it across view rebuilds; handleEditorUpdate delegates to the live bridge. */
            EditorView.updateListener.of(handleEditorUpdate),
            comps.editable.of([
              EditorView.editable.of(editing),
              EditorState.readOnly.of(!editing),
            ]),
            comps.wrap.of(wrap ? EditorView.lineWrapping : []),
            descriptor.extension,
            separatorExtension,
            EditorView.theme({
              '&': { backgroundColor: 'var(--dsw-alias-markdown-code-block)', color: 'var(--dsw-alias-label-primary)' },
              '.cm-content': { caretColor: 'var(--dsw-alias-label-primary)' },
              '&.cm-focused': { outline: 'none' },
            }, { dark: false }),
          ],
        }),
      })
    }
    if (onViewState !== null) {
      onViewState(file.path, {
        state: view.state,
        editable: comps.editable,
        wrap: comps.wrap,
        phrases: comps.phrases,
        name: file.name,
      })
    }
    const reportScroll = () => {
      scrollRef.current?.(file.path, view.scrollDOM.scrollTop)
    }
    view.scrollDOM.addEventListener('scroll', reportScroll)
    editorRef.current = view
    // A reveal consumes itself, so the second pass must not fall through to the
    // persisted scrollTop; the closure flag scopes that.
    let revealHandled = false
    const restoreScroll = () => {
      const target = revealRef.current
      if (target !== null && target.path === file.path) {
        revealPosition(view, target)
        markRevealApplied(target)
        revealHandled = true
        return
      }
      if (revealHandled) return
      if (Number.isFinite(scrollTop) && scrollTop > 0) view.scrollDOM.scrollTop = scrollTop
    }
    restoreScroll()
    // Second pass after layout: the first assignment can be clamped before the browser
    // sizes the fresh content. rAF is paused while the tab is backgrounded, so a file
    // opened in a hidden tab restores its scroll on the next visible frame.
    const animation = requestAnimationFrame(restoreScroll)
    contextRef.current(view.state)
    return () => {
      cancelAnimationFrame(animation)
      // React removes the editor DOM before passive cleanups, so a detached
      // scroller reads scrollTop as 0; only report while still connected.
      if (view.scrollDOM.isConnected) scrollRef.current?.(file.path, view.scrollDOM.scrollTop)
      view.scrollDOM.removeEventListener('scroll', reportScroll)
      if (editorRef.current === view) editorRef.current = undefined
      if (liveEditorBridge.current === bridgeSelfRef.current) liveEditorBridge.current = null
      view.destroy()
    }
    // Rebuild only on a real re-read (path/encoding/read epoch), never on save,
    // which would wipe the undo history and caret position.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [file.path, file.encoding, readEpoch])

  useEffect(() => {
    editorRef.current?.dispatch({
      effects: compartments.editable.reconfigure([
        EditorView.editable.of(editing),
        EditorState.readOnly.of(!editing),
      ]),
    })
  }, [editing])

  useEffect(() => {
    editorRef.current?.dispatch({
      effects: compartments.wrap.reconfigure(wrap ? EditorView.lineWrapping : []),
    })
  }, [wrap])

  useEffect(() => {
    editorRef.current?.dispatch({
      effects: compartments.phrases.reconfigure(localeIsZh() ? EditorState.phrases.of(CM_PHRASES_ZH) : []),
    })
  }, [localeTick])

  useEffect(() => {
    const view = editorRef.current
    if (view === undefined || reveal === null) return
    /* Same path guard as the mount-time restoreScroll: in a fast file switch the effect can
       fire with a stale reveal while editorRef already points at the new file's editor. */
    if (reveal.path !== file.path) return
    revealPosition(view, reveal)
    markRevealApplied(reveal)
  }, [reveal])

  // Ctrl+K+J / Ctrl+K+<n> are handled at the window level (capture phase) so they
  // work in every focus state; the editor keymap deliberately does not bind them.
  // Keys are consumed only for the Ctrl+K prefix and its completion J / 1..9.
  useEffect(() => {
    let armed = false
    let timer
    const cancel = () => { armed = false; clearTimeout(timer) }
    const onKeyDown = (event) => {
      const view = editorRef.current
      if (view === undefined) return
      // IME composition must never arm or complete the fold sequence; composing
      // keystrokes pass through untouched.
      if (event.isComposing) { cancel(); return }
      const target = event.target
      // Outside text fields (chat, rename, search, dialogs) keep their keys; the editor's contenteditable is inside host.
      const insideEditor = host.current !== null && target instanceof Node && host.current.contains(target)
      /* Element (not HTMLElement) so SVG targets are covered too; closest()
         handles nested inputs inside custom controls. */
      const inTextField = target instanceof Element
        && (target.isContentEditable || target.closest('input, textarea, select') !== null)
      if (!insideEditor && inTextField) {
        cancel()
        return
      }
      const key = String(event.key).toLowerCase()
      const isCtrlK = key === 'k' && (event.ctrlKey || event.metaKey) && !event.altKey && !event.shiftKey
      /* The prefix is consumed only while the editor is focused or focus sits on the
         explorer's own chrome (tree rows, tabs, panel headers); anywhere else Ctrl+K
         passes through to the harness. */
      const foldChrome = target instanceof Element
        && target.closest('.dsh-ws-tree-row, .dsh-ws-preview-tab, .dsh-ws-panel-header') !== null
      if (isCtrlK && (insideEditor || foldChrome)) {
        // (Re-)arm the prefix; a repeated Ctrl+K keeps the sequence alive.
        event.preventDefault()
        event.stopPropagation()
        armed = true
        clearTimeout(timer)
        timer = setTimeout(cancel, 1000)
        return
      }
      if (!armed) return
      cancel()
      /* The arm window may have outlived the focus: if focus moved to an external input
         after arming, the completion key belongs to that field — pass it through instead
         of folding. */
      if (!insideEditor && target instanceof Element
        && (target.isContentEditable || target.closest('input, textarea, select') !== null)) {
        return
      }
      /* Completion keys must carry no modifiers: within the 1 s arm window a plain J / 1..9
         completes the sequence, but modified shortcuts pass through untouched. */
      const hasModifier = event.ctrlKey || event.metaKey || event.altKey || event.shiftKey
      if (!hasModifier && key === 'j') {
        event.preventDefault()
        event.stopPropagation()
        unfoldAll(view)
        return
      }
      if (!hasModifier && key.length === 1 && key >= '1' && key <= '9') {
        event.preventDefault()
        event.stopPropagation()
        foldLevel(view, Number(key))
        return
      }
    }
    window.addEventListener('keydown', onKeyDown, true)
    return () => {
      window.removeEventListener('keydown', onKeyDown, true)
      cancel()
    }
  }, [])

  // Find shortcuts (Ctrl/Cmd+F, Ctrl/Cmd+G, Ctrl/Cmd+Shift+G, F3, Shift+F3) are
  // handled at the window level (capture phase) so they work in every focus state;
  // with no editor mounted, keys pass through so the browser's own find still works.
  useEffect(() => {
    const onKeyDown = (event) => {
      const view = editorRef.current
      if (view === undefined) return
      // IME composition must never trigger find shortcuts; composing keystrokes
      // pass through untouched.
      if (event.isComposing) return
      /* A modal dialog is open: the search panel would render behind its
         backdrop and the keys belong to the dialog — pass through. */
      if (typeof document !== 'undefined' && document.querySelector('.dsh-ws-dialog-backdrop') !== null) return
      const target = event.target
      // Outside text fields (chat, rename, dialogs) keep their keys; the editor's
      // contenteditable and the search panel input are editor-internal and still reach here.
      const panelContainer = searchPanelContainer?.current
      const insideEditor = (host.current !== null && target instanceof Node && host.current.contains(target))
        || (panelContainer !== null && target instanceof Node && panelContainer.contains(target))
      if (!insideEditor && target instanceof Element
        && (target.isContentEditable || target.closest('input, textarea, select') !== null)) return
      const mod = (event.ctrlKey || event.metaKey) && !event.altKey
      const key = String(event.key).toLowerCase()
      const plainF3 = event.key === 'F3' && !event.ctrlKey && !event.metaKey && !event.altKey
      let handled = false
      if (key === 'f' && mod && !event.shiftKey) {
        openSearchPanel(view)
        handled = true
      } else if (key === 'g' && mod && !event.shiftKey) {
        findNext(view)
        handled = true
      } else if (key === 'g' && mod && event.shiftKey) {
        findPrevious(view)
        handled = true
      } else if (plainF3 && !event.shiftKey) {
        findNext(view)
        handled = true
      } else if (plainF3 && event.shiftKey) {
        findPrevious(view)
        handled = true
      }
      if (handled) {
        event.preventDefault()
        event.stopPropagation()
      }
    }
    window.addEventListener('keydown', onKeyDown, true)
    return () => window.removeEventListener('keydown', onKeyDown, true)
  }, [])

  // Save shortcut (Ctrl/Cmd+S) at the window level (capture phase) so it works from
  // every focus state; the editor keymap path only fired while the editor itself was
  // focused. The save callback no-ops when the tab is clean or saving.
  useEffect(() => {
    const onKeyDown = (event) => {
      if (event.isComposing) return
      /* A modal dialog is open (same rule as the find shortcuts): the save belongs to
         the dialog's context, since acting behind its backdrop would save a file the
         user cannot see. */
      if (typeof document !== 'undefined' && document.querySelector('.dsh-ws-dialog-backdrop') !== null) return
      const key = String(event.key).toLowerCase()
      const isSave = key === 's' && (event.ctrlKey || event.metaKey) && !event.altKey && !event.shiftKey
      if (!isSave) return
      const view = editorRef.current
      if (view === undefined) return
      event.preventDefault()
      event.stopPropagation()
      saveRef.current()
    }
    window.addEventListener('keydown', onKeyDown, true)
    return () => window.removeEventListener('keydown', onKeyDown, true)
  }, [])

  // Search field drag-to-resize grip: CodeMirror builds the panel DOM itself
  // and SearchPanel is not exported, so watch the panel container and wrap its
  // [main-field] input in an inline-flex wrapper with a col-resize handle.
  useEffect(() => {
    const container = searchPanelContainer?.current
    if (container === null || container === undefined) return undefined
    let detach = undefined
    const enhance = () => {
      /* The panel can close while a drag is in flight; detach the window
         pointer listeners as soon as the panel leaves the DOM. */
      if (container.querySelector('.cm-panel.cm-search') === null) {
        detach?.()
        return
      }
      const input = container.querySelector('.cm-panel.cm-search [main-field]')
      if (input === null || input.dataset.dshWelResize === '1') return
      input.dataset.dshWelResize = '1'
      const wrap = document.createElement('span')
      wrap.className = 'dsh-ws-search-field-wrap'
      const handle = document.createElement('span')
      handle.className = 'dsh-ws-search-resize'
      handle.title = translate('editor.searchResize')
      input.before(wrap)
      wrap.append(input, handle)
      let startX = 0
      let startWidth = 0
      let moveListener = undefined
      let upListener = undefined
      const detachPointer = () => {
        if (moveListener !== undefined) window.removeEventListener('pointermove', moveListener)
        if (upListener !== undefined) window.removeEventListener('pointerup', upListener)
        moveListener = undefined
        upListener = undefined
      }
      detach = detachPointer
      const onPointerDown = (event) => {
        event.preventDefault()
        startX = event.clientX
        startWidth = input.getBoundingClientRect().width
        const onPointerMove = (moveEvent) => {
          input.style.width = `${Math.max(60, Math.min(480, startWidth + (moveEvent.clientX - startX)))}px`
        }
        const onPointerUp = () => { detachPointer() }
        // Replace any prior drag state so a second drag cannot leak a stale
        // pair; the cleanup also detaches on unmount.
        detachPointer()
        moveListener = onPointerMove
        upListener = onPointerUp
        window.addEventListener('pointermove', onPointerMove)
        window.addEventListener('pointerup', onPointerUp)
      }
      handle.addEventListener('pointerdown', onPointerDown)
    }
    enhance()
    const observer = new MutationObserver(enhance)
    observer.observe(container, { childList: true, subtree: true })
    return () => { observer.disconnect(); detach?.() }
  }, [searchPanelContainer])

  return h('div', { className: 'dsh-ws-editor-host', 'data-highlight-preset': highlightPreset ?? HIGHLIGHT_PRESET_DEFAULT, ref: host, style: diffColors ?? undefined })
}
