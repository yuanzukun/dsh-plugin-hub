/** Search panel state, request lifecycle and debounce. */
import { useCallback, useEffect, useRef, useState } from 'react'
import { SEARCH_MATCH_EXPAND_DEFAULT } from '../../../constants.js'
import { requestSearch } from '../../../api.js'

export function useSearchState({ workspaceId, settings }) {
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [searchCaseSensitive, setSearchCaseSensitive] = useState(false)
  const [searchNameOnly, setSearchNameOnly] = useState(false)
  const [searchState, setSearchState] = useState({ state: 'idle' })
  const [searchExpanded, setSearchExpanded] = useState(() => new Set())
  const searchController = useRef()
  /* The last submitted query+option combo: the debounce timer must not fire a second request for a combo already submitted via Enter, and toggling options re-runs the search. */
  const lastSubmittedQueryRef = useRef('')
  const searchComboKey = (query, caseSensitive, nameOnly) => `${query}|${caseSensitive ? 'cs' : ''}|${nameOnly ? 'no' : ''}`
    const runSearch=useCallback(async(query)=>{searchController.current?.abort();if(query.trim()===''){setSearchState({state:'idle'});setSearchExpanded(new Set());return}lastSubmittedQueryRef.current=searchComboKey(query,searchCaseSensitive,searchNameOnly);const controller=new AbortController();searchController.current=controller;setSearchState({state:'searching'});try{const result=await requestSearch(workspaceId,query,searchCaseSensitive,searchNameOnly,controller.signal);if(searchController.current===controller){setSearchState({state:'done',result});setSearchExpanded(new Set((settings.expandSearchMatches ?? SEARCH_MATCH_EXPAND_DEFAULT)?result.files.map(file=>file.path):[]))}}catch(error){/* A TIMEOUT is a real failure, not a cancellation (the AbortError name is shared); surface it or the panel stays "searching" forever. */if(error?.name==='AbortError'&&error?.reason?.name!=='TimeoutError')return;if(searchController.current===controller)setSearchState({state:'error',message:error instanceof Error?error.message:String(error)})}},[searchCaseSensitive,searchNameOnly,settings.expandSearchMatches,workspaceId])
  const closeSearch=useCallback(()=>{searchController.current?.abort();searchController.current=undefined;setSearchExpanded(new Set());setSearchOpen(false);setSearchQuery('');setSearchState({state:'idle'});lastSubmittedQueryRef.current=''},[])
    const toggleSearchFile=useCallback((path)=>{setSearchExpanded(prev=>{const next=new Set(prev);if(next.has(path))next.delete(path);else next.add(path);return next})},[])
  useEffect(() => {
    if (!searchOpen) return undefined
    const timer = setTimeout(() => {
      if (lastSubmittedQueryRef.current !== searchComboKey(searchQuery, searchCaseSensitive, searchNameOnly)) void runSearch(searchQuery)
    }, 300)
    return () => clearTimeout(timer)
  }, [runSearch, searchOpen, searchQuery])
  useEffect(() => () => {
    searchController.current?.abort()
    searchController.current = undefined
  }, [])
  return {
    searchOpen, setSearchOpen, searchQuery, setSearchQuery,
    searchCaseSensitive, setSearchCaseSensitive, searchNameOnly, setSearchNameOnly,
    searchState, searchExpanded, runSearch, closeSearch, toggleSearchFile,
  }
}
