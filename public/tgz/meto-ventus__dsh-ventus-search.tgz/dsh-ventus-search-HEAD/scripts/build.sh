#!/bin/bash
# Build dsh-ventus-search: compile src/ -> lib/ with the dsh checkout's tsc,
# then dev_build_plugin runs npm run build:client for the browser bundle.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

CHECKOUT="${DSH_CHECKOUT:-}"
if [ -z "$CHECKOUT" ]; then
  for candidate in "$HOME/dsh-harness" "$HOME/dsh" "$HOME/.dsh/dsh-harness" "E:/ProgramData/deepseek-harness"; do
    if [ -d "$candidate/packages" ]; then CHECKOUT="$candidate"; break; fi
  done
fi
if [ -z "$CHECKOUT" ] || [ ! -d "$CHECKOUT/packages" ]; then
  echo "build: cannot locate the dsh checkout (set DSH_CHECKOUT)" >&2
  exit 1
fi

TSC="$CHECKOUT/node_modules/.bin/tsc"
if [ ! -x "$TSC" ] && [ ! -f "$TSC.cmd" ]; then
  echo "build: tsc not found at $TSC" >&2
  exit 1
fi

link_pkg() {
  local target="$CHECKOUT/$2"
  if [ ! -e "$target" ]; then
    echo "build: dependency target missing: $target" >&2
    exit 1
  fi
  node -e "
    const fs = require('fs');
    const path = require('path');
    const link = path.resolve(process.argv[1]);
    const target = path.resolve(process.argv[2]);
    fs.rmSync(link, { recursive: true, force: true });
    fs.mkdirSync(path.dirname(link), { recursive: true });
    fs.symlinkSync(target, link, process.platform === 'win32' ? 'junction' : 'dir');
  " "node_modules/$1" "$target"
}

echo "=== Linking build dependencies (checkout: $CHECKOUT) ==="
mkdir -p node_modules/@deepseek-ai
node -e "const fs=require('fs');fs.rmSync('node_modules/@standard-schema',{recursive:true,force:true})"
link_pkg @deepseek-ai/cordis vendor/cordis
link_pkg cosmokit vendor/cosmokit
link_pkg schemastery vendor/schemastery
link_pkg @deepseek-ai/dsh-tools packages/core/tools
link_pkg @deepseek-ai/dsh-llm packages/llm/llm
link_pkg @deepseek-ai/dsh-credentials packages/credentials/credentials
link_pkg @deepseek-ai/dsh-host-webserver packages/host/webserver
link_pkg @deepseek-ai/dsh-web packages/web/web
link_pkg @deepseek-ai/dsh-client-ui-slots packages/client/ui-slots
# @types/node（编译类型；checkout 自带）
link_pkg @types/node node_modules/@types/node

STD_SCHEMA=$(find "$CHECKOUT/node_modules/.pnpm" -maxdepth 1 -type d -iname '@standard-schema+spec@*' 2>/dev/null | head -1)
if [ -n "$STD_SCHEMA" ]; then
  node -e "
    const fs = require('fs');
    const path = require('path');
    fs.rmSync('node_modules/@standard-schema', { recursive: true, force: true });
    fs.mkdirSync('node_modules/@standard-schema', { recursive: true });
    fs.symlinkSync(path.resolve(process.argv[1]), path.resolve('node_modules/@standard-schema/spec'), process.platform === 'win32' ? 'junction' : 'dir');
  " "$STD_SCHEMA/node_modules/@standard-schema/spec"
fi

# react + @types/react（client 类型检查；从插件所在 workspace 的 .pnpm 探测，找不到时跳过）
WS="$(cd "$ROOT/.." && pwd)"
link_from_pnpm() {
  local pkg="$1" subpath="$2"
  local found
  found=$(find "$WS/node_modules/.pnpm" -maxdepth 1 -type d -iname "$pkg" 2>/dev/null | head -1)
  if [ -z "$found" ] && [ "$WS" != "$CHECKOUT" ]; then
    found=$(find "$CHECKOUT/node_modules/.pnpm" -maxdepth 1 -type d -iname "$pkg" 2>/dev/null | head -1)
  fi
  if [ -z "$found" ]; then
    echo "build: warning: $pkg not found in .pnpm stores; client typecheck may fail" >&2
    return 0
  fi
  node -e "
    const fs = require('fs');
    const path = require('path');
    const link = path.resolve(process.argv[1]);
    const target = path.resolve(process.argv[2]);
    fs.rmSync(link, { recursive: true, force: true });
    fs.mkdirSync(path.dirname(link), { recursive: true });
    fs.symlinkSync(target, link, process.platform === 'win32' ? 'junction' : 'dir');
  " "node_modules/$subpath" "$found/node_modules/$subpath"
}
link_from_pnpm 'react@*' react
link_from_pnpm '@types+react@*' @types/react

echo "=== Compiling src -> lib ==="
"$TSC" -p tsconfig.json
echo "=== Build complete ==="
