# Archived sessions start fresh; /reset clears memory

## Archived Weixin sessions

Archiving a session in the Harness Web UI (`menu.archiveSession`) keeps its
session log but removes it from every grouping surface. dsh-weixin must not
keep appending Weixin messages to an archived session.

The gateway now checks `ctx.workspaceRegistry.archivedSessionIds` (the
authoritative archive set maintained by the `workspaceRegistry` service)
before attaching or resuming a chat's persisted session:

- When the in-memory `ChatState` belongs to an archived agent, the binding is
  dropped before the message is routed.
- When the durable chat -> session mapping points at an archived session, the
  mapping is deleted and a brand-new session is created; the archived session
  is never resumed or attached to.
- When the `workspaceRegistry` service is unavailable, the check degrades to
  the previous behavior (no archive detection).

## /reset command

`/reset` drops the current chat binding and replies
`记忆已清空。下一条消息将开启一个全新的会话。` The next inbound message
starts a brand-new session, so the model no longer sees any prior context.
`/new` keeps its original "next message starts a new session" behavior; the
two commands are interchangeable in effect and both leave the gateway state
mapping cleared.

## Verification

- `npm run typecheck` passes.
- `npm test` passes 48 tests, including two new integration cases: a persisted
  archived session starts a fresh session (create called, resume not called,
  durable mapping repointed), and `/reset` clears the mapping so the next
  message creates a new session again.
