# dsh-plugin-image-wallpaper

上传一张图片，把它作为整个 Web 页面的背景壁纸（cover 铺满、固定背景），并支持实时调整：

- **暗色遮罩**（0–80%，默认 30%）— 半透明黑层盖在壁纸上，文字更易读
- **壁纸透明度**（0–100%）— 壁纸向图片平均色渐变淡出
- **模糊**（0–40px）— 只模糊壁纸本身（`backdrop-filter`），界面内容保持清晰

入口：侧边栏 **设置 → 自定义主题**。文字颜色会随图片明暗与遮罩强度自动适配。

壁纸设置会持久化到浏览器 `localStorage`，**重启 Web 服务或刷新页面后自动恢复**（图片以 data URL 保存，过大时自动转 JPEG 压缩；移除壁纸即清除）。

## 实现说明

- 纯浏览器端插件（client bundle），宿主行仅用于让 `client-modules` 扫描到包。
- 壁纸挂在 `body` 背景 + `body::before`（scrim / blur，`z-index: -1`，不遮挡 UI）。
- 通过 `ctx.theme.overrideTokens` 覆盖 `--dsw-alias-*` 令牌层；停止插件自动还原。
- 状态保存在插件作用域，切换设置页不丢失；移除壁纸一键还原。

## 打包/安装（规范）

```
dsh plugin --profile web add 工具/dsh-plugin-image-wallpaper
dsh --profile web --dump-config   # 验证 "# == dsh-plugin-image-wallpaper" 层
# 重启 dsh web 后刷新页面生效
```
