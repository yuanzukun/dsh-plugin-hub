import { describe, expect, it } from 'vitest'
import {
  applyModelEdit,
  buildDrafts,
  buildRouteModelsWrite,
  routeOps,
  validateEnabledLevels,
  type ModelDraft,
  type RouteDraft,
  type SectionInput,
} from '../src/client/model-thinking.ts'

/** A hand-declared custom route as the adapter stores it. */
const input: SectionInput = {
  providers: {
    jasper: {
      displayName: 'Jasper',
      models: [
        {
          id: 'deepseek-v4-flash',
          name: 'DeepSeek-V4-Flash',
          contextWindow: 1000000,
          maxTokens: 32768,
          input: ['text' as const, 'image' as const],
        },
        { id: 'acme-think', name: 'Acme Think', reasoningEfforts: { off: null, high: 'high' } },
        { id: 'acme-plain', name: 'Acme Plain', reasoningEfforts: false },
      ],
    },
  },
  userProviders: {
    jasper: { models: [{ id: 'deepseek-v4-flash', reasoningEfforts: false }] },
  },
  present: true,
  writable: true,
  revision: 3,
}

describe('buildDrafts', () => {
  it('reads per-model capability, levels, and overridden flags', () => {
    const routes = buildDrafts(input)
    expect(routes).toHaveLength(1)
    const jasper = routes[0]!
    expect(jasper.route).toBe('jasper')
    expect(jasper.catalogOnly).toBe(false)
    expect(jasper.defaultLevel).toBe('inherit')
    const [plain, think, disabled] = jasper.models
    expect(plain!.capability).toBe('inherit')
    expect(plain!.overridden).toBe(true) // user layer carries reasoningEfforts
    expect(think!.capability).toBe('enabled')
    expect(think!.levels).toEqual({ off: '', high: 'high' })
    expect(disabled!.capability).toBe('disabled')
  })

  it('keeps raw models verbatim (unknown fields survive a save)', () => {
    const routes = buildDrafts(input)
    const raw = routes[0]!.rawModels[0] as Record<string, unknown>
    expect(raw.contextWindow).toBe(1000000)
    expect(raw.maxTokens).toBe(32768)
    expect(raw.input).toEqual(['text', 'image'])
  })

  it('treats a missing namespace as not present', () => {
    const routes = buildDrafts({ ...input, present: false, providers: undefined })
    expect(routes).toEqual([])
  })
})

describe('validateEnabledLevels', () => {
  it('rejects only-off tables', () => {
    expect(validateEnabledLevels({ off: '' })).toMatch(/一个非 off/)
  })
  it('rejects a non-off level with an empty wire value', () => {
    expect(validateEnabledLevels({ off: '', high: '' })).toMatch(/high/)
  })
  it('accepts a well-formed table', () => {
    expect(validateEnabledLevels({ off: '', low: 'low', high: 'high' })).toBeUndefined()
  })
})

describe('applyModelEdit', () => {
  const routes = buildDrafts(input)
  const raw = routes[0]!.rawModels[0]
  const base: ModelDraft = {
    route: 'jasper',
    index: 0,
    id: 'deepseek-v4-flash',
    name: 'DeepSeek-V4-Flash',
    overridden: true,
    capability: 'inherit',
    levels: {},
    thinkingFormat: 'inherit',
    supportsEffort: 'inherit',
    dirty: true,
  }

  it('enables thinking while preserving unedited fields', () => {
    const edited = applyModelEdit(raw, {
      ...base,
      capability: 'enabled',
      levels: { off: '', high: 'high', max: 'ultra' },
    }) as Record<string, unknown>
    expect(edited.id).toBe('deepseek-v4-flash')
    expect(edited.contextWindow).toBe(1000000)
    expect(edited.reasoningEfforts).toEqual({ off: null, high: 'high', max: 'ultra' })
    expect(edited.compat).toBeUndefined()
  })

  it('disables thinking', () => {
    const edited = applyModelEdit(raw, { ...base, capability: 'disabled' }) as Record<string, unknown>
    expect(edited.reasoningEfforts).toBe(false)
  })

  it('clears the reasoningEfforts override when inheriting', () => {
    const withEfforts = applyModelEdit(raw, {
      ...base,
      capability: 'enabled',
      levels: { high: 'high' },
    }) as Record<string, unknown>
    expect(withEfforts.reasoningEfforts).toEqual({ high: 'high' })
    const cleared = applyModelEdit(withEfforts, base) as Record<string, unknown>
    expect(cleared.reasoningEfforts).toBeUndefined()
  })

  it('writes compat switches and drops the compat block when both inherit', () => {
    const edited = applyModelEdit(raw, {
      ...base,
      capability: 'enabled',
      levels: { high: 'high' },
      thinkingFormat: 'deepseek',
      supportsEffort: 'true',
    }) as Record<string, unknown>
    expect(edited.compat).toEqual({ thinkingFormat: 'deepseek', supportsReasoningEffort: true })
    const cleared = applyModelEdit(edited as never, { ...base, capability: 'enabled', levels: { high: 'high' } })
    expect((cleared as Record<string, unknown>).compat).toBeUndefined()
  })
})

describe('buildRouteModelsWrite / routeOps', () => {
  it('rewrites the whole models array: dirty rows rebuilt, others verbatim', () => {
    const routes = buildDrafts(input)
    const jasper = routes[0]!
    const dirty: RouteDraft = {
      ...jasper,
      dirty: true,
      models: jasper.models.map((model, index) =>
        index === 0
          ? { ...model, capability: 'enabled' as const, levels: { off: '', high: 'high' }, dirty: true }
          : model,
      ),
    }
    const write = buildRouteModelsWrite(dirty)!
    expect(write).toHaveLength(3)
    expect((write[0] as Record<string, unknown>).reasoningEfforts).toEqual({ off: null, high: 'high' })
    expect((write[0] as Record<string, unknown>).contextWindow).toBe(1000000)
    expect(write[1]).toEqual(jasper.rawModels[1]) // untouched, same reference shape
    expect(write[2]).toEqual(jasper.rawModels[2])
    const ops = routeOps(dirty)
    expect(ops).toContainEqual({ op: 'set', path: ['providers', 'jasper', 'models'], value: write })
  })

  it('sets the route default level', () => {
    const routes = buildDrafts(input)
    const jasper = routes[0]!
    const ops = routeOps({ ...jasper, defaultLevel: 'high', dirty: true })
    expect(ops).toContainEqual({ op: 'set', path: ['providers', 'jasper', 'reasoning'], value: 'high' })
    expect(ops.some(op => op.path[2] === 'models')).toBe(false) // no dirty model: no models rewrite
  })

  it('clears the route default when inheriting', () => {
    const routes = buildDrafts({ ...input, providers: { jasper: { ...input.providers!.jasper!, reasoning: 'max' } } })
    const jasper = routes[0]!
    const ops = routeOps({ ...jasper, defaultLevel: 'inherit', dirty: true })
    expect(ops).toContainEqual({ op: 'unset', path: ['providers', 'jasper', 'reasoning'] })
  })
})
