/**
 * dsh-model-thinking host plugin body.
 *
 * The browser half ships via exports["./client"], discovered through the
 * package.json dsh.client declaration; this node half exists so the plugin
 * row mounts in the host cordis.yml / Loader and the client bundle is served
 * at /plugins/dsh-model-thinking/client.js. There is deliberately no
 * host-side behavior: every knob this plugin touches lives in the existing
 * `llm-pi-ai` user-settings section (providers.<route>.models[].reasoningEfforts
 * / compat, providers.<route>.reasoning), which the pi-ai adapter already
 * validates, materializes, and applies per request — the plugin only renders
 * that configuration surface in the web GUI.
 */
import type { Context } from '@deepseek-ai/cordis'

/** Required services: none. */
export const inject: never[] = []

/**
 * Mount the plugin row. No-op by design (see the module doc); the entry keeps
 * the signature so the loader treats this package as a real plugin.
 * @param _ctx - host cordis context.
 */
export function apply(_ctx: Context): void {
  // Configuration surface is browser-side; see src/client.
}
