/**
 * Pure model and settings-op builder for the thinking-intensity
 * configuration surface. No DOM, no cordis — unit-testable in isolation.
 *
 * The target configuration lives in the existing `llm-pi-ai` user-settings
 * section and is understood by the pi-ai adapter:
 *
 *   providers:
 *     <route>:
 *       reasoning: <default level>            # route default, materialized
 *                                             # when a request omits an effort
 *       models:
 *         - id: <model>
 *           reasoningEfforts:                 # selectable levels + wire spellings
 *               off: null                     # off may send nothing (null)
 *               low: low
 *               high: high
 *           compat:                           # openai-completions reasoning dispatch
 *               thinkingFormat: openai        # or deepseek / qwen / ...
 *               supportsReasoningEffort: true
 *
 * Writes are emitted as settings.mutate path ops. The seam's path machine
 * (applyPathOp) recurses PLAIN OBJECTS ONLY — a set whose intermediate child
 * is an array replaces that array with an object — so no op may walk INTO an
 * array. A route's model catalog is therefore written as one whole-array
 * replace (`set providers.<route>.models`), rebuilt from the effective
 * models with every unedited field carried over verbatim.
 */

/** pi-ai ModelThinkingLevel, in escalation order (mirror of the adapter's THINKING_LEVELS). */
export const THINKING_LEVELS = ['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'] as const
export type ThinkingLevel = (typeof THINKING_LEVELS)[number]

/** Wire thinking formats an openai-completions model may name (chat-template variants withheld, as the adapter withholds them). */
export const THINKING_FORMATS = ['openai', 'openrouter', 'deepseek', 'together', 'zai', 'qwen', 'string-thinking', 'ant-ling'] as const
export type ThinkingFormat = (typeof THINKING_FORMATS)[number]

/** The pi-ai provider-profile shapes this surface reads (subset; unlisted fields ride through verbatim in rawModels). */
export interface PiAiModelProfile {
  id: string
  name?: string
  /** Context capacity (carried through untouched by a save). */
  contextWindow?: number
  /** Output capability (carried through untouched by a save). */
  maxTokens?: number
  /** Request modalities (carried through untouched by a save). */
  input?: readonly unknown[]
  reasoningEfforts?: false | Partial<Record<ThinkingLevel, string | null>> | undefined
  compat?: {
    thinkingFormat?: ThinkingFormat | undefined
    supportsReasoningEffort?: boolean | undefined
  } | undefined
}

export interface PiAiProviderProfile {
  displayName?: string
  reasoning?: ThinkingLevel | undefined
  models?: PiAiModelProfile[] | undefined
}

/** The `llm-pi-ai` user-section shape this surface reads (subset). */
export interface PiAiSection {
  providers?: Record<string, PiAiProviderProfile> | undefined
}

/** Per-model capability posture. */
export type ModelCapability = 'inherit' | 'enabled' | 'disabled'

/** Tri-state compat switch. */
export type TriState = 'inherit' | 'true' | 'false'

/** One model row as the form drafts it. */
export interface ModelDraft {
  /** Provider route id. */
  route: string
  /** Index of this model inside providers.<route>.models (display position). */
  index: number
  /** Model id sent to the provider. */
  id: string
  /** Display name (falls back to the id). */
  name: string
  /** Whether the model carries an explicit reasoning capability in the user section. */
  overridden: boolean
  capability: ModelCapability
  /**
   * Wire spelling per checked level; `''` renders as an empty wire value
   * (valid only for `off`, where it means "send nothing").
   */
  levels: Partial<Record<ThinkingLevel, string>>
  thinkingFormat: ThinkingFormat | 'inherit'
  supportsEffort: TriState
  /** Whether the user edited this row (drives the save and the dirty badge). */
  dirty: boolean
}

/** One provider route card as the form drafts it. */
export interface RouteDraft {
  /** Provider route id. */
  route: string
  /** Display name (falls back to the route id). */
  displayName: string
  /** Whether the route profile lives in the user section (removable/editable posture). */
  overridden: boolean
  /** Route default thinking level; 'inherit' preserves the adapter's own default. */
  defaultLevel: ThinkingLevel | 'inherit'
  dirty: boolean
  /** Models listed under the route profile. */
  models: ModelDraft[]
  /**
   * The effective model objects verbatim (JSON-shaped), so a save rebuilds the
   * whole `models` array with every unedited field (contextWindow, maxTokens,
   * input, ...) carried over.
   */
  rawModels: readonly unknown[]
  /** True when the route profile carries no explicit models list (catalog-served route). */
  catalogOnly: boolean
}

/** A redacted namespace view reduced to what this surface edits. */
export interface SectionInput {
  /** Resolved providers (composition base → user layer). */
  providers: Record<string, PiAiProviderProfile> | undefined
  /** Raw user layer providers (field presence marks an override). */
  userProviders: Record<string, PiAiProviderProfile> | undefined
  /** Whether the `llm-pi-ai` namespace is exposed at all. */
  present: boolean
  /** Whether the settings provider accepts writes. */
  writable: boolean
  /** Namespace revision fencing the next write. */
  revision: number | undefined
}

/** True when a value is a declared thinking level. */
export function isThinkingLevel(value: unknown): value is ThinkingLevel {
  return typeof value === 'string' && (THINKING_LEVELS as readonly string[]).includes(value)
}

/** True when a value is a wire thinking format. */
export function isThinkingFormat(value: unknown): value is ThinkingFormat {
  return typeof value === 'string' && (THINKING_FORMATS as readonly string[]).includes(value)
}

/** JSON-shaped deep clone (settings data never carries functions or cycles). */
export function cloneJson<T>(value: T): T {
  if (value === null || typeof value !== 'object') return value
  if (Array.isArray(value)) return value.map(entry => cloneJson(entry)) as T
  const out: Record<string, unknown> = {}
  for (const [key, entry] of Object.entries(value as Record<string, unknown>)) {
    if (entry === undefined) continue
    out[key] = cloneJson(entry)
  }
  return out as T
}

/** Build every route draft from a redacted namespace view. */
export function buildDrafts(input: SectionInput): RouteDraft[] {
  const providers = input.providers ?? {}
  const userProviders = input.userProviders ?? {}
  const routes: RouteDraft[] = []
  for (const [route, profile] of Object.entries(providers)) {
    const userProfile = userProviders[route]
    const models = Array.isArray(profile.models) ? profile.models : undefined
    const routeDraft: RouteDraft = {
      route,
      displayName: profile.displayName ?? route,
      overridden: userProfile !== undefined,
      defaultLevel: isThinkingLevel(profile.reasoning) ? profile.reasoning : 'inherit',
      dirty: false,
      catalogOnly: models === undefined,
      rawModels: models === undefined ? [] : cloneJson(models),
      models: [],
    }
    if (models !== undefined) {
      models.forEach((model, index) => {
        const userModel = userProfile?.models?.[index]
        const efforts = model.reasoningEfforts
        const capability: ModelCapability = efforts === false
          ? 'disabled'
          : efforts !== undefined && efforts !== null
            ? 'enabled'
            : 'inherit'
        const levels: Partial<Record<ThinkingLevel, string>> = {}
        if (efforts !== undefined && efforts !== null && efforts !== false) {
          for (const level of THINKING_LEVELS) {
            if (Object.prototype.hasOwnProperty.call(efforts, level)) {
              levels[level] = efforts[level] ?? ''
            }
          }
        }
        routeDraft.models.push({
          route,
          index,
          id: model.id,
          name: model.name ?? model.id,
          overridden: userModel !== undefined && (userModel.reasoningEfforts !== undefined || userModel.compat !== undefined),
          capability,
          levels,
          thinkingFormat: isThinkingFormat(model.compat?.thinkingFormat) ? model.compat.thinkingFormat : 'inherit',
          supportsEffort: model.compat?.supportsReasoningEffort === undefined
            ? 'inherit'
            : model.compat.supportsReasoningEffort
              ? 'true'
              : 'false',
          dirty: false,
        })
      })
    }
    routes.push(routeDraft)
  }
  return routes
}

/** Whether a level's wire value may be empty. */
export function levelWireAllowed(level: ThinkingLevel, wire: string): boolean {
  return wire !== '' || level === 'off'
}

/** Validate one enabled model's level table (mirror of the adapter's validator). */
export function validateEnabledLevels(levels: Partial<Record<ThinkingLevel, string>>): string | undefined {
  const entries = Object.entries(levels) as Array<[ThinkingLevel, string]>
  const nonOff = entries.filter(([level]) => level !== 'off')
  if (nonOff.length === 0) {
    return 'reasoningEfforts 至少需要一个非 off 的思考级别（仅 off 会被适配器拒绝）'
  }
  for (const [level, wire] of nonOff) {
    if (!levelWireAllowed(level, wire)) {
      return `级别 "${level}" 需要填写线格式值（线格式参数要发给端点）`
    }
  }
  return undefined
}

/** One path-addressed settings edit (the wire shape of settings.mutate ops). */
export type PathOp =
  | { op: 'set'; path: string[]; value: unknown }
  | { op: 'unset'; path: string[] }

/**
 * Apply one dirty model draft onto its raw stored object, returning the
 * rebuilt model object (all unedited fields carried over verbatim).
 * @param raw - the effective stored model object.
 * @param draft - the edited model row.
 * @returns the model object to store.
 */
export function applyModelEdit(raw: unknown, draft: ModelDraft): unknown {
  const next = cloneJson(raw)
  const record = next as Record<string, unknown>
  if (draft.capability === 'inherit') {
    delete record.reasoningEfforts
  } else if (draft.capability === 'disabled') {
    record.reasoningEfforts = false
  } else {
    const wire: Record<string, string | null> = {}
    for (const [level, value] of Object.entries(draft.levels) as Array<[ThinkingLevel, string]>) {
      wire[level] = value === '' ? null : value
    }
    record.reasoningEfforts = wire
  }
  if (draft.thinkingFormat === 'inherit' && draft.supportsEffort === 'inherit') {
    delete record.compat
  } else {
    const compat = (isPlainRecord(record.compat) ? record.compat : {}) as Record<string, unknown>
    if (draft.thinkingFormat === 'inherit') delete compat.thinkingFormat
    else compat.thinkingFormat = draft.thinkingFormat
    if (draft.supportsEffort === 'inherit') delete compat.supportsReasoningEffort
    else compat.supportsReasoningEffort = draft.supportsEffort === 'true'
    record.compat = compat
  }
  return next
}

/** True for a plain data record (not an array or null). */
function isPlainRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/**
 * Build the whole `providers.<route>.models` array a save should store:
 * every raw model carried over verbatim, dirty rows rebuilt by
 * {@link applyModelEdit}. Returns undefined when no row is dirty.
 * @param draft - the route card.
 * @returns the models array to persist, or undefined for no-op.
 */
export function buildRouteModelsWrite(draft: RouteDraft): unknown[] | undefined {
  const dirty = draft.models.some(model => model.dirty)
  if (!dirty || draft.catalogOnly) return undefined
  const out: unknown[] = []
  for (let index = 0; index < draft.rawModels.length; index++) {
    const raw = draft.rawModels[index]
    const model = draft.models[index]
    out.push(model !== undefined && model.dirty && raw !== undefined ? applyModelEdit(raw, model) : raw)
  }
  // 草稿里可能有新增/删除模型（本分区不支持增删，仅防御性保留长度一致性）
  for (const model of draft.models) {
    if (model.index >= out.length && model.dirty) out.push(applyModelEdit(undefined, model))
  }
  return out
}

/** Build the ops that turn one route draft into the stored section. */
export function routeOps(draft: RouteDraft): PathOp[] {
  const ops: PathOp[] = []
  if (draft.defaultLevel === 'inherit') {
    ops.push({ op: 'unset', path: ['providers', draft.route, 'reasoning'] })
  } else {
    ops.push({ op: 'set', path: ['providers', draft.route, 'reasoning'], value: draft.defaultLevel })
  }
  const modelsWrite = buildRouteModelsWrite(draft)
  if (modelsWrite !== undefined) {
    ops.push({ op: 'set', path: ['providers', draft.route, 'models'], value: modelsWrite })
  }
  return ops
}

/** Human text for a rejected wire call (transport errors reject with anything). */
export function messageOf(error: unknown): string {
  if (error instanceof Error && error.message !== '') return error.message
  if (typeof error === 'string' && error !== '') return error
  try {
    return JSON.stringify(error)
  } catch {
    return String(error)
  }
}