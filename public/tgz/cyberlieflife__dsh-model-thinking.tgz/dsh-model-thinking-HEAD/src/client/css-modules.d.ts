/** CSS Modules type shim (the tsdown css plugin compiles .module.css to hashed class maps). */
declare module '*.module.css' {
  const classes: Record<string, string>
  export default classes
}
