/**
 * Section controller: loads the `llm-pi-ai` settings namespace through the
 * connection's settings API, keeps an editable draft per provider route and
 * per model, and writes precise path ops on save. The Host stays the single
 * fact source — every mutation writes through the wire and the surface
 * re-renders from the next describe, pushed or refetched.
 */
import type { IApiClient } from '@deepseek-ai/dsh-api-remotes/client'
import {
  buildDrafts,
  messageOf,
  routeOps,
  validateEnabledLevels,
  type ModelCapability,
  type ModelDraft,
  type RouteDraft,
  type SectionInput,
  type ThinkingFormat,
  type ThinkingLevel,
  type TriState,
} from './model-thinking.ts'

/** The settings wire face this controller needs. */
export type SettingsApi = Pick<IApiClient, 'settings'>

/** One settings namespace view reduced from a describe response. */
interface NamespaceView {
  value: unknown
  user: unknown
  revision: number | undefined
}

/** Full section snapshot the component renders from. */
export interface ThinkingSectionState {
  status: 'loading' | 'ready' | 'unavailable' | 'error'
  /** Whole-load failure text; row-level write failures stay in the footer. */
  error: string | null
  /** Whether the settings provider accepts writes. */
  writable: boolean
  /** Provider route cards. */
  routes: readonly RouteDraft[]
  /** Whether any draft differs from the stored section. */
  dirty: boolean
  /** Blocking validation message (a dirty draft the adapter would reject). */
  invalid: string | null
  /** Whether a save is crossing the wire. */
  saving: boolean
  /** Last save failure text; cleared by the next edit or save. */
  saveFailed: string | null
}

/** The actions the section's slot entry injects. */
export interface ThinkingActions {
  /** Set one route's default thinking level ('inherit' clears it). */
  setDefaultLevel: (route: string, level: ThinkingLevel | 'inherit') => void
  /** Set one model's reasoning capability. */
  setCapability: (route: string, index: number, capability: ModelCapability) => void
  /** Check/uncheck one thinking level of an enabled model. */
  toggleLevel: (route: string, index: number, level: ThinkingLevel, checked: boolean) => void
  /** Edit one level's wire spelling. */
  setLevelWire: (route: string, index: number, level: ThinkingLevel, wire: string) => void
  /** Set one model's compat.thinkingFormat ('inherit' clears it). */
  setThinkingFormat: (route: string, index: number, format: ThinkingFormat | 'inherit') => void
  /** Set one model's compat.supportsReasoningEffort ('inherit' clears it). */
  setSupportsEffort: (route: string, index: number, value: TriState) => void
  /** Write every dirty draft as path ops, then re-seed from the Host. */
  save: () => void
  /** Drop every dirty draft. */
  discard: () => void
  /** Re-describe the namespace (pushed invalidation or retry). */
  reload: () => void
}

/** Minimal snapshot store (uSES-safe: stable reference between changes). */
export interface SnapshotStore<T> {
  getSnapshot(): T
  subscribe(listener: () => void): () => void
}

/** Remote event surface the controller subscribes to (structural subset). */
export interface RemoteEvents {
  $on(event: string, handler: (payload: unknown) => void): () => void
}

const PI_AI_NS = 'llm-pi-ai'

/** Human text for one RPC failure branch. */
function errorText(error: unknown): string {
  if (typeof error === 'object' && error !== null) {
    const message = (error as { message?: unknown }).message
    if (typeof message === 'string' && message !== '') return message
  }
  return messageOf(error)
}

/** Pull the llm-pi-ai namespace out of a describe response. */
function findNamespace(describe: unknown): NamespaceView | undefined {
  const value = describe as { namespaces?: unknown } | undefined
  const namespaces = Array.isArray(value?.namespaces) ? value.namespaces : []
  for (const ns of namespaces) {
    const view = ns as { ns?: unknown; value?: unknown; user?: unknown; revision?: unknown }
    if (view.ns === PI_AI_NS) {
      return {
        value: view.value,
        user: view.user,
        revision: typeof view.revision === 'number' ? view.revision : undefined,
      }
    }
  }
  return undefined
}

/**
 * Owns the section's draft state and its wire writes. One instance per
 * settings surface mount (created when the slot declaration is available).
 */
export class ThinkingController {
  private readonly listeners = new Set<() => void>()
  private snapshot: ThinkingSectionState = {
    status: 'loading',
    error: null,
    writable: false,
    routes: [],
    dirty: false,
    invalid: null,
    saving: false,
    saveFailed: null,
  }
  private revision: number | undefined = undefined
  private loadGeneration = 0
  private remoteDisposer: (() => void) | undefined

  /** @param api - the settings wire face. */
  constructor(private readonly api: SettingsApi) {}

  /** The store the renderer binds. */
  readonly store: SnapshotStore<ThinkingSectionState> = {
    getSnapshot: () => this.snapshot,
    subscribe: (listener) => {
      this.listeners.add(listener)
      return () => { this.listeners.delete(listener) }
    },
  }

  /** Subscribe to pushed namespace invalidations and load once. */
  start(remote?: RemoteEvents): () => void {
    this.remoteDisposer = remote === undefined
      ? undefined
      : remote.$on('settings/document-updated', () => {
          // The surface must not fight an in-flight save; re-seed after it lands.
          if (!this.snapshot.saving) void this.load()
        })
    void this.load()
    return () => {
      this.remoteDisposer?.()
      this.remoteDisposer = undefined
    }
  }

  /** The face the section's slot registration injects. */
  inject(): ThinkingActions & { hooks: { thinkingSection: SnapshotStore<ThinkingSectionState> } } {
    return {
      hooks: { thinkingSection: this.store },
      setDefaultLevel: (route, level) => this.editRoute(route, (draft) => {
        draft.defaultLevel = level
      }),
      setCapability: (route, index, capability) => this.editModel(route, index, (draft) => {
        if (capability === 'enabled' && Object.keys(draft.levels).length === 0) {
          // Friendly default: off (send nothing) plus high (the OpenAI-compatible
          // standard wire spelling); the user adjusts per endpoint.
          draft.levels.off = ''
          draft.levels.high = 'high'
        }
        draft.capability = capability
      }),
      toggleLevel: (route, index, level, checked) => this.editModel(route, index, (draft) => {
        if (checked) draft.levels[level] = level === 'off' ? '' : level
        else delete draft.levels[level]
      }),
      setLevelWire: (route, index, level, wire) => this.editModel(route, index, (draft) => {
        draft.levels[level] = wire
      }),
      setThinkingFormat: (route, index, format) => this.editModel(route, index, (draft) => {
        draft.thinkingFormat = format
      }),
      setSupportsEffort: (route, index, value) => this.editModel(route, index, (draft) => {
        draft.supportsEffort = value
      }),
      save: () => { void this.save() },
      discard: () => {
        if (!this.snapshot.dirty && this.snapshot.saveFailed === null) return
        void this.load()
      },
      reload: () => { void this.load() },
    }
  }

  /** Re-describe the namespace and rebuild drafts. Latest load wins. */
  async load(): Promise<void> {
    const generation = ++this.loadGeneration
    this.publish({ ...this.snapshot, status: 'loading', error: null, saveFailed: null })
    try {
      const response = await this.api.settings.describe({})
      if (generation !== this.loadGeneration) return
      if (!response.result.ok) {
        this.publish({
          ...this.snapshot,
          status: 'error',
          error: errorText(response.result.error),
          routes: [],
          dirty: false,
          invalid: null,
        })
        return
      }
      const view = findNamespace(response.result.value)
      if (view === undefined) {
        this.publish({
          ...this.snapshot,
          status: 'unavailable',
          error: null,
          writable: false,
          routes: [],
          dirty: false,
          invalid: null,
        })
        return
      }
      const input: SectionInput = {
        providers: (view.value as { providers?: unknown } | undefined)?.providers as SectionInput['providers'],
        userProviders: (view.user as { providers?: unknown } | undefined)?.providers as SectionInput['userProviders'],
        present: true,
        writable: response.result.value.writable,
        revision: view.revision,
      }
      this.revision = view.revision
      const routes = buildDrafts(input)
      this.publish({
        ...this.snapshot,
        status: 'ready',
        error: null,
        writable: input.writable,
        routes,
        dirty: false,
        invalid: null,
        saveFailed: null,
      })
    } catch (error) {
      if (generation !== this.loadGeneration) return
      this.publish({
        ...this.snapshot,
        status: 'error',
        error: errorText(error),
        routes: [],
        dirty: false,
        invalid: null,
      })
    }
  }

  /** Stage one route edit and recompute the shell flags. */
  private editRoute(route: string, edit: (draft: RouteDraft) => void): void {
    const routes = this.snapshot.routes.map((entry) => {
      if (entry.route !== route) return entry
      const next: RouteDraft = { ...entry, models: entry.models }
      edit(next)
      next.dirty = true
      return next
    })
    this.afterEdit(routes)
  }

  /** Stage one model edit and recompute the shell flags. */
  private editModel(route: string, index: number, edit: (draft: ModelDraft) => void): void {
    const routes = this.snapshot.routes.map((entry) => {
      if (entry.route !== route) return entry
      const models = entry.models.map((model) => {
        if (model.index !== index) return model
        const next: ModelDraft = { ...model, levels: { ...model.levels } }
        edit(next)
        next.dirty = true
        return next
      })
      const next: RouteDraft = { ...entry, models }
      return next
    })
    this.afterEdit(routes)
  }

  /** Recompute dirty/invalid from the drafts and publish. */
  private afterEdit(routes: readonly RouteDraft[]): void {
    const dirty = routes.some((route) => route.dirty || route.models.some((model) => model.dirty))
    let invalid: string | null = null
    if (dirty) {
      for (const route of routes) {
        for (const model of route.models) {
          if (model.dirty && model.capability === 'enabled') {
            const problem = validateEnabledLevels(model.levels)
            if (problem !== undefined) {
              invalid = `${model.name}（${model.id}）：${problem}`
              break
            }
          }
        }
        if (invalid !== null) break
      }
    }
    this.publish({ ...this.snapshot, routes, dirty, invalid, saveFailed: null })
  }

  /** Write every dirty draft as one revision-fenced mutate, then re-seed. */
  private async save(): Promise<void> {
    if (this.snapshot.saving || !this.snapshot.dirty || this.snapshot.invalid !== null) return
    const ops = this.snapshot.routes
      .filter((route) => route.dirty || route.models.some((model) => model.dirty))
      .flatMap(routeOps)
    if (ops.length === 0) return
    this.publish({ ...this.snapshot, saving: true, saveFailed: null })
    try {
      const response = await this.api.settings.mutate({
        ns: PI_AI_NS,
        ops,
        expectedRevision: this.revision,
      })
      if (!response.result.ok) {
        const error = response.result.error
        const code = typeof error === 'object' && error !== null
          ? (error as { code?: unknown }).code
          : undefined
        if (code === 'settings-conflict') {
          // Another writer landed first: re-read and ask the user to retry.
          await this.load()
          this.publish({ ...this.snapshot, saving: false, saveFailed: '配置已被其他修改覆盖，已重新加载，请重试' })
          return
        }
        this.publish({ ...this.snapshot, saving: false, saveFailed: errorText(error) })
        return
      }
      await this.load()
      this.publish({ ...this.snapshot, saving: false })
    } catch (error) {
      this.publish({ ...this.snapshot, saving: false, saveFailed: errorText(error) })
    }
  }

  /** Replace the snapshot and notify subscribers. */
  private publish(next: ThinkingSectionState): void {
    this.snapshot = next
    for (const listener of [...this.listeners]) listener()
  }
}
