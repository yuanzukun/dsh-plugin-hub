/**
 * The Thinking settings section: one card per llm-pi-ai provider route,
 * editing the route's default thinking intensity and each model's reasoning
 * capability, thinking levels (+ wire spellings), and reasoning-dispatch
 * compat switches. All writes go through the controller as path ops against
 * the `llm-pi-ai` user section.
 *
 * Visual language mirrors the official Models settings section
 * (dsh-client-ui-settings-models): the same `--dsw-alias-*` design tokens,
 * row cards, field layout, pill buttons, and focus rings — so the surface
 * follows the active theme automatically.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { ThinkingActions, ThinkingSectionState } from './controller.ts'
import { THINKING_FORMATS, THINKING_LEVELS, type ModelCapability, type ThinkingFormat, type ThinkingLevel, type TriState } from './model-thinking.ts'
import type { ThinkingKey } from './locales.ts'
import css from './section.module.css'

/** The face the section's slot registration injects. */
export interface ThinkingSectionFace extends ThinkingActions {
  hooks: {
    /** Section snapshot bound by the renderer as useThinkingSection. */
    thinkingSection: { getSnapshot(): ThinkingSectionState; subscribe(l: () => void): () => void }
  }
}

/** Props the renderer binds for the section. */
export type ThinkingSectionProps =
  PropsRuntime<'settings.section'>
  & PropsLocale<'model-thinking'>
  & InjectFace<ThinkingSectionFace>

/** Localized display name of one thinking level. */
function levelLabel(t: (key: ThinkingKey) => string, level: ThinkingLevel): string {
  return t(`level.${level}` as ThinkingKey)
}

/** Localized display name of one wire thinking format. */
function formatLabel(t: (key: ThinkingKey) => string, format: ThinkingFormat): string {
  return t(`format.${format}` as ThinkingKey)
}

/**
 * Render the Thinking settings section.
 * @param props - the section snapshot, its actions, and locale copy.
 * @returns the section content.
 */
export function ThinkingSection(props: ThinkingSectionProps) {
  const { t } = props
  const state = props.useThinkingSection(snapshot => snapshot)
  const disabled = !state.writable || state.saving

  if (state.status === 'loading') {
    return <p className={css.notice} role="status">{t('section.loading')}</p>
  }
  if (state.status === 'unavailable') {
    return (
      <div className={css.noticeBlock} role="status">
        <p className={css.noticeTitle}>{t('section.unavailable')}</p>
        <p className={css.advancedHint}>{t('section.unavailableHint')}</p>
      </div>
    )
  }
  if (state.status === 'error') {
    return (
      <div className={css.noticeBlock} role="alert">
        <p className={css.noticeTitle}>{t('section.error')}</p>
        <p className={css.error}>{state.error}</p>
        <button type="button" className={css.secondaryButton} onClick={props.reload}>{t('section.retry')}</button>
      </div>
    )
  }

  if (state.routes.length === 0) {
    return (
      <div className={css.noticeBlock}>
        <p className={css.noticeTitle}>{t('section.empty')}</p>
        <p className={css.advancedHint}>{t('section.emptyHint')}</p>
      </div>
    )
  }

  return (
    <section className={css.section}>
      <p className={css.intro}>{t('section.description')}</p>
      {!state.writable
        ? <p className={css.notice} role="status">{t('section.readOnly')}</p>
        : null}
      <ul className={css.rows}>
        {state.routes.map(route => (
          <li key={route.route} className={css.rowCard}>
            <div className={css.rowHead}>
              <span className={css.rowIdentity}>
                <span className={css.rowName}>{route.displayName}</span>
                <span className={css.rowTag}>{route.route}</span>
                {route.dirty || route.models.some(model => model.dirty)
                  ? <span className={css.rowTagWarn}>{t('section.unsaved')}</span>
                  : null}
                {route.overridden ? <span className={css.rowTag}>{t('route.overridden')}</span> : null}
              </span>
              <span className={css.rowActions}>
                <label className={css.inlineField}>
                  <span className={css.fieldLabel}>{t('route.defaultLevel')}</span>
                  <select
                    className={`${css.input} ${css.selectInput}`}
                    value={route.defaultLevel}
                    disabled={disabled}
                    onChange={(event) => {
                      const value = event.target.value
                      props.setDefaultLevel(route.route, value === 'inherit' ? 'inherit' : value as ThinkingLevel)
                    }}
                  >
                    <option value="inherit">{t('inherit')}</option>
                    {THINKING_LEVELS.map(level => (
                      <option key={level} value={level}>{levelLabel(t, level)}</option>
                    ))}
                  </select>
                </label>
              </span>
            </div>

            {route.catalogOnly ? (
              <p className={css.advancedHint}>{t('route.catalogOnly')} {t('route.catalogOnlyHint')}</p>
            ) : (
              <div className={css.modelCatalog}>
                {route.models.map(model => (
                  <div key={model.id} className={css.modelEntry}>
                    <div className={css.modelRow}>
                      <span className={css.modelIdentity}>
                        <span className={css.rowName}>{model.name}</span>
                        <span className={css.rowTag}>{model.id}</span>
                        {model.overridden ? <span className={css.rowTag}>{t('model.overridden')}</span> : null}
                        {model.dirty ? <span className={css.dotWarn} aria-hidden="true" /> : null}
                      </span>
                      <label className={css.inlineField}>
                        <select
                          className={`${css.input} ${css.selectInput}`}
                          value={model.capability}
                          disabled={disabled}
                          title={t('model.capabilityHint')}
                          onChange={(event) => props.setCapability(route.route, model.index, event.target.value as ModelCapability)}
                        >
                          <option value="inherit">{t('model.capability.inherit')}</option>
                          <option value="enabled">{t('model.capability.enabled')}</option>
                          <option value="disabled">{t('model.capability.disabled')}</option>
                        </select>
                      </label>
                      <label className={css.inlineField}>
                        <select
                          className={`${css.input} ${css.selectInput}`}
                          value={model.thinkingFormat}
                          disabled={disabled}
                          title={t('model.compat.thinkingFormatHint')}
                          onChange={(event) => {
                            const value = event.target.value
                            props.setThinkingFormat(route.route, model.index, value === 'inherit' ? 'inherit' : value as ThinkingFormat)
                          }}
                        >
                          <option value="inherit">{t('inherit')}</option>
                          {THINKING_FORMATS.map(format => (
                            <option key={format} value={format}>{formatLabel(t, format)}</option>
                          ))}
                        </select>
                      </label>
                      <label className={css.inlineField}>
                        <select
                          className={`${css.input} ${css.selectInput}`}
                          value={model.supportsEffort}
                          disabled={disabled}
                          title={t('model.compat.supportsEffortHint')}
                          onChange={(event) => props.setSupportsEffort(route.route, model.index, event.target.value as TriState)}
                        >
                          <option value="inherit">{t('inherit')}</option>
                          <option value="true">{t('true')}</option>
                          <option value="false">{t('false')}</option>
                        </select>
                      </label>
                    </div>

                    {model.capability === 'enabled' ? (
                      <div className={css.modelAdvanced}>
                        <div className={css.levelGrid}>
                          {THINKING_LEVELS.map(level => {
                            const checked = Object.prototype.hasOwnProperty.call(model.levels, level)
                            const wire = model.levels[level] ?? ''
                            return (
                              <label key={level} className={checked ? css.levelCellChecked : css.levelCell}>
                                <input
                                  type="checkbox"
                                  checked={checked}
                                  disabled={disabled}
                                  onChange={(event) => props.toggleLevel(route.route, model.index, level, event.target.checked)}
                                />
                                <span className={css.chipLabel}>{levelLabel(t, level)}</span>
                                {checked ? (
                                  <input
                                    className={level === 'off' && wire === '' ? `${css.wireInput} ${css.wireEmpty}` : css.wireInput}
                                    type="text"
                                    value={wire}
                                    placeholder={level === 'off' ? t('inherit') : level}
                                    title={t('model.levelWireHint')}
                                    disabled={disabled}
                                    onClick={(event) => event.stopPropagation()}
                                    onChange={(event) => props.setLevelWire(route.route, model.index, level, event.target.value)}
                                  />
                                ) : null}
                              </label>
                            )
                          })}
                        </div>
                        <p className={css.advancedHint}>{t('model.levelWireHint')}</p>
                      </div>
                    ) : null}
                  </div>
                ))}
              </div>
            )}
          </li>
        ))}
      </ul>

      {state.invalid !== null ? <p className={css.error} role="alert">{state.invalid}</p> : null}
      {state.saveFailed !== null ? <p className={css.error} role="alert">{t('section.saveFailed')}：{state.saveFailed}</p> : null}

      <div className={css.editorActions}>
        <button
          type="button"
          className={css.secondaryButton}
          disabled={!state.dirty || state.saving}
          onClick={props.discard}
        >
          {t('section.discard')}
        </button>
        <button
          type="button"
          className={css.primaryButton}
          disabled={!state.dirty || state.invalid !== null || state.saving}
          onClick={props.save}
        >
          {state.saving ? t('section.saving') : t('section.save')}
        </button>
      </div>
    </section>
  )
}
