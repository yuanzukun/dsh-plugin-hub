/**
 * Locale dictionaries for the thinking-intensity settings section. The
 * namespace key union is declared in client/index.tsx's LocaleNamespaceMap
 * merge; the bilingual balance (zh + en) is enforced by ctx.locale.register.
 */

/** Locale namespace this plugin owns. */
export const NS = 'model-thinking'

/** Dictionary key union of the `model-thinking` namespace. */
export type ThinkingKey =
  | 'nav'
  | 'section.title'
  | 'section.description'
  | 'section.loading'
  | 'section.unavailable'
  | 'section.unavailableHint'
  | 'section.error'
  | 'section.retry'
  | 'section.readOnly'
  | 'section.save'
  | 'section.saving'
  | 'section.discard'
  | 'section.saveFailed'
  | 'section.unsaved'
  | 'section.saved'
  | 'section.empty'
  | 'section.emptyHint'
  | 'section.hint.effects'
  | 'section.hint.effectsDefault'
  | 'route.defaultLevel'
  | 'route.catalogOnly'
  | 'route.catalogOnlyHint'
  | 'route.overridden'
  | 'model.capability'
  | 'model.capability.inherit'
  | 'model.capability.enabled'
  | 'model.capability.disabled'
  | 'model.capabilityHint'
  | 'model.levels'
  | 'model.levelWire'
  | 'model.levelWireHint'
  | 'model.compat'
  | 'model.compat.thinkingFormat'
  | 'model.compat.thinkingFormatHint'
  | 'model.compat.supportsEffort'
  | 'model.compat.supportsEffortHint'
  | 'model.overridden'
  | 'inherit'
  | 'true'
  | 'false'
  | 'level.off'
  | 'level.minimal'
  | 'level.low'
  | 'level.medium'
  | 'level.high'
  | 'level.xhigh'
  | 'level.max'
  | 'format.openai'
  | 'format.openrouter'
  | 'format.deepseek'
  | 'format.together'
  | 'format.zai'
  | 'format.qwen'
  | 'format.string-thinking'
  | 'format.ant-ling'

/** zh dictionary. */
export const zh: Record<ThinkingKey, string> = {
  'nav': '思考强度',
  'section.title': '自定义模型思考强度',
  'section.description': '为 llm-pi-ai 自定义模型配置思考（reasoning）能力、思考强度级别与线格式；写入 llm-pi-ai 设置，模型选择器与请求默认值随即生效。',
  'section.loading': '加载中…',
  'section.unavailable': '未检测到 llm-pi-ai 适配器',
  'section.unavailableHint': '思考强度配置作用于 OpenAI-compatible 自定义模型（llm-pi-ai 提供方）。请先在「模型」页添加自定义提供方，或确认 llm-pi-ai 插件已加载。',
  'section.error': '加载失败',
  'section.retry': '重试',
  'section.readOnly': '当前设置只读，无法保存。',
  'section.save': '保存',
  'section.saving': '保存中…',
  'section.discard': '放弃',
  'section.saveFailed': '保存失败',
  'section.unsaved': '未保存',
  'section.saved': '已保存',
  'section.empty': '还没有可配置的模型',
  'section.emptyHint': '在「模型」页添加自定义提供方后，这里会列出它的每个模型。',
  'section.hint.effects': '每个模型的思考强度级别会出现在会话模型选择器中；未选择级别时，使用提供方的「默认思考强度」。',
  'section.hint.effectsDefault': '默认思考强度会在请求未显式指定级别时自动生效（即每次会话默认思考）。',
  'route.defaultLevel': '默认思考强度',
  'route.catalogOnly': '此提供方未声明模型列表（走内置目录）。',
  'route.catalogOnlyHint': '仍可设置该提供方的默认思考强度；目录模型各自声明的思考能力会与它取交集。',
  'route.overridden': '用户已配置',
  'model.capability': '思考能力',
  'model.capability.inherit': '继承',
  'model.capability.enabled': '启用思考',
  'model.capability.disabled': '关闭思考',
  'model.capabilityHint': '启用后模型选择器会显示可选的思考强度级别。',
  'model.levels': '思考强度级别',
  'model.levelWire': '线格式',
  'model.levelWireHint': '发送给端点的参数值；off 留空表示不发送。',
  'model.compat': '推理分派兼容',
  'model.compat.thinkingFormat': 'thinkingFormat',
  'model.compat.thinkingFormatHint': '端点期望的思考参数格式；继承 = 目录/自动检测。',
  'model.compat.supportsEffort': 'supportsReasoningEffort',
  'model.compat.supportsEffortHint': '端点是否接受 reasoning_effort 参数；继承 = 目录/自动检测。',
  'model.overridden': '已覆盖',
  'inherit': '继承',
  'true': '支持',
  'false': '不支持',
  'level.off': '关闭',
  'level.minimal': '最低',
  'level.low': '低',
  'level.medium': '中',
  'level.high': '高',
  'level.xhigh': '较高',
  'level.max': '最高',
  'format.openai': 'openai（reasoning_effort）',
  'format.openrouter': 'openrouter',
  'format.deepseek': 'deepseek（thinking / reasoning_effort）',
  'format.together': 'together',
  'format.zai': 'zai',
  'format.qwen': 'qwen（enable_thinking）',
  'format.string-thinking': 'string-thinking（thinking 字符串）',
  'format.ant-ling': 'ant-ling',
}

/** en dictionary. */
export const en: Record<ThinkingKey, string> = {
  'nav': 'Thinking',
  'section.title': 'Custom Model Thinking Intensity',
  'section.description': 'Configure reasoning capability, thinking-intensity levels and wire formats for llm-pi-ai custom models. Writes into the llm-pi-ai settings; the model picker and request defaults pick it up.',
  'section.loading': 'Loading…',
  'section.unavailable': 'llm-pi-ai adapter not detected',
  'section.unavailableHint': 'Thinking-intensity configuration applies to OpenAI-compatible custom models (llm-pi-ai providers). Add a custom provider on the Models page first, or make sure the llm-pi-ai plugin is loaded.',
  'section.error': 'Failed to load',
  'section.retry': 'Retry',
  'section.readOnly': 'Settings are read-only; saving is disabled.',
  'section.save': 'Save',
  'section.saving': 'Saving…',
  'section.discard': 'Discard',
  'section.saveFailed': 'Save failed',
  'section.unsaved': 'Unsaved',
  'section.saved': 'Saved',
  'section.empty': 'No models configured yet',
  'section.emptyHint': 'After you add a custom provider on the Models page, its models appear here.',
  'section.hint.effects': 'Each model\'s thinking levels show up in the conversation model picker; when no level is picked, the provider\'s Default thinking intensity applies.',
  'section.hint.effectsDefault': 'The default thinking intensity applies to requests that do not pick an explicit level (thinking by default in every conversation).',
  'route.defaultLevel': 'Default thinking intensity',
  'route.catalogOnly': 'This provider declares no model list (serves its built-in catalog).',
  'route.catalogOnlyHint': 'You can still set the provider\'s default thinking intensity; it intersects with each catalog model\'s declared reasoning capability.',
  'route.overridden': 'user-configured',
  'model.capability': 'Reasoning',
  'model.capability.inherit': 'Inherit',
  'model.capability.enabled': 'Thinking on',
  'model.capability.disabled': 'Thinking off',
  'model.capabilityHint': 'When enabled, the model picker offers the levels below.',
  'model.levels': 'Thinking intensity levels',
  'model.levelWire': 'Wire value',
  'model.levelWireHint': 'The parameter value sent to the endpoint; leave off empty to send nothing.',
  'model.compat': 'Reasoning dispatch',
  'model.compat.thinkingFormat': 'thinkingFormat',
  'model.compat.thinkingFormatHint': 'The thinking parameter format the endpoint expects; inherit = catalog/auto-detected.',
  'model.compat.supportsEffort': 'supportsReasoningEffort',
  'model.compat.supportsEffortHint': 'Whether the endpoint accepts the reasoning_effort parameter; inherit = catalog/auto-detected.',
  'model.overridden': 'overridden',
  'inherit': 'Inherit',
  'true': 'Yes',
  'false': 'No',
  'level.off': 'Off',
  'level.minimal': 'Minimal',
  'level.low': 'Low',
  'level.medium': 'Medium',
  'level.high': 'High',
  'level.xhigh': 'X-High',
  'level.max': 'Max',
  'format.openai': 'openai (reasoning_effort)',
  'format.openrouter': 'openrouter',
  'format.deepseek': 'deepseek (thinking / reasoning_effort)',
  'format.together': 'together',
  'format.zai': 'zai',
  'format.qwen': 'qwen (enable_thinking)',
  'format.string-thinking': 'string-thinking (thinking string)',
  'format.ant-ling': 'ant-ling',
}
