/**
 * dsh-model-thinking client plugin: registers the locale dictionaries and
 * contributes the Thinking settings section once the `settings.section`
 * declaration is on the ledger.
 *
 * Failure policy: registration problems surface through the slot machinery;
 * the section itself never throws — wire failures render inline.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only: pulls the locale plugin's Context merge (ctx.locale) and its
// LocaleNamespaceMap merge table.
import type {} from '@deepseek-ai/dsh-client-locale/client'
// Type-only: pulls the slot registry types (ctx.slots) and the slots merge tables.
import type {} from '@deepseek-ai/dsh-client-ui-slots'
// Type-only: pulls the settings.section slot declaration (ui-settings contract).
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
// Type-only: pulls the connection service types (ctx.get('connection')).
import type {} from '@deepseek-ai/dsh-client-connection/client'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type {} from '@deepseek-ai/dsh-api-remotes/client'
import { ThinkingController, type RemoteEvents } from './controller.ts'
import { ThinkingSection } from './thinking-section.tsx'
import { en, NS, zh, type ThinkingKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The thinking-intensity settings surface copy. */
    'model-thinking': ThinkingKey
  }
}

/** Required services (fiber inject waiting — slots and connection first). */
export const inject = ['slots', 'locale', 'connection', 'remote']

/**
 * Register the Thinking section and its controller.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'model-thinking: dictionaries')
  const t = ctx.locale.bind(NS)

  ctx.slots.inject('settings.section', () => {
    const connection = ctx.get('connection') as ConnectionHandle
    const controller = new ThinkingController(connection.api)
    const stop = controller.start(ctx.remote as unknown as RemoteEvents)
    ctx.effect(() => stop, 'model-thinking: controller')
    return ctx.slots.register({
      name: 'settings.section',
      id: 'model-thinking',
      // Between the Models page (order 10) and the Plugins page (order 15).
      order: 12,
      label: () => t('nav'),
      locale: NS,
      inject: () => controller.inject(),
    }, ThinkingSection)
  })
}
