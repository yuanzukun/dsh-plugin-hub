/**
 * Minimal invariant helper (no dependencies): guards programmer errors with
 * a fail-loud throw that names the violated assumption. Mirrors the family
 * plugins' standalone invariant slice.
 */
/** Assert a condition, throwing a descriptive Error when it fails. */
export function invariant(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(`[dsh-model-thinking] ${message}`)
}
