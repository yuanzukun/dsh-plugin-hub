import { readFileSync, writeFileSync } from 'node:fs'
const src = process.argv[2]
const c = readFileSync(src, 'utf8')
const out = []
const startMarker = 'const css$'
let i = 0
while (true) {
  const at = c.indexOf(startMarker, i)
  if (at < 0) break
  const eq = c.indexOf('=', at)
  let p = c.indexOf('"', eq)
  if (p < 0) break
  p += 1
  let buf = ''
  let closed = false
  while (p < c.length) {
    const ch = c[p]
    if (ch === '\\') { buf += '\\' + (c[p + 1] ?? ''); p += 2; continue }
    if (ch === '"') { closed = true; break }
    buf += ch
    p += 1
  }
  if (!closed) break
  out.push('=== css#' + out.length + ' ===\n' + buf)
  i = p + 1
}
writeFileSync('D:/Code/dsh-model-thinking/tmp-official-css.txt', out.join('\n\n'))
console.log('blocks:', out.length, 'chars:', out.join('').length)
