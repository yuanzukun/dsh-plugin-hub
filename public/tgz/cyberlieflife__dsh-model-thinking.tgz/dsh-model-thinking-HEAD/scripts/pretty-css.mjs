import { readFileSync, writeFileSync } from 'node:fs'
const text = readFileSync('D:/Code/dsh-model-thinking/tmp-official-css.txt', 'utf8')
const parts = text.split('=== css#')
for (let i = 1; i < parts.length; i++) {
  const nl = parts[i].indexOf('\n')
  const body = parts[i].slice(nl + 1).replace(/}/g, '}\n')
  writeFileSync('D:/Code/dsh-model-thinking/tmp-css-' + i + '.css', body)
}
console.log('done', parts.length - 1)
