/** 核对账本、真实观察、断言、附件及离线报告。不会调用模型或测试工具。 */
import { readFile, writeFile, mkdir, cp } from "node:fs/promises";
import { createHash } from "node:crypto";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import assert from "node:assert/strict";
import { chromium } from "playwright";
import { rebuild, ledgerEvents } from "../dist/recorder.js";
import { mcpResult } from "../dist/adapters.js";
import { field } from "../dist/contracts.js";
const dir = resolve(process.argv[2]);
const run = JSON.parse(await readFile(join(dir, "results.json"), "utf8"));
assert.deepEqual(await rebuild(dir), run);
const producers = new Set(
  run.instances.flatMap((i) =>
    i.steps.flatMap((s) => s.observations.map((o) => o.producer.call_id)),
  ),
);
const boundCalls = new Map(),
  finishedCalls = new Map();
let eventCount = 0;
for await (const event of ledgerEvents(dir)) {
  eventCount++;
  if (!producers.has(event.payload?.call_id)) continue;
  if (event.type === "tool_bound")
    boundCalls.set(event.payload.call_id, event.seq);
  if (event.type === "tool_finished")
    finishedCalls.set(event.payload.call_id, event.seq);
}
for (const e of run.evidence) {
  const bytes = await readFile(join(dir, e.relative_path));
  assert.equal(createHash("sha256").update(bytes).digest("hex"), e.sha256);
}
for (const instance of run.instances)
  for (const step of instance.steps) {
    for (const o of step.observations) {
      assert.equal(o.binding.case_run_id, instance.case_run_id);
      const bound = boundCalls.get(o.producer.call_id);
      const settled = finishedCalls.get(o.producer.call_id);
      assert(bound !== undefined && settled !== undefined && bound < settled);
      const evidence = run.evidence.find(
        (e) => e.evidence_id === o.evidence_refs[0],
      );
      const raw = JSON.parse(
        await readFile(join(dir, evidence.relative_path), "utf8"),
      );
      if (o.producer.adapter === "playwright-dom-v1")
        assert.deepEqual(
          field(mcpResult(raw.value), o.producer.field),
          o.value,
        );
      if (o.producer.adapter === "http-json-v1")
        assert.deepEqual(field(raw.value, o.producer.field), o.value);
    }
    if (step.assertion) {
      const observation = instance.steps
        .flatMap((s) => s.observations)
        .find(
          (o) =>
            o.observation_id ===
            step.assertion.operand_snapshot.actual_observation_id,
        );
      const snap = step.assertion.operand_snapshot;
      assert.deepEqual(
        field(
          observation.value,
          snap.actual_path.split(".").slice(2).join("."),
        ),
        step.assertion.actual,
      );
      const definition = instance.effective_steps.find(
        (s) => s.step_id === step.step_id,
      ).assertion;
      const expectedObservation = instance.steps
        .flatMap((s) => s.observations)
        .find((o) => o.observation_id === snap.expected_observation_id);
      const expected = expectedObservation
        ? field(
            expectedObservation.value,
            snap.expected_path.split(".").slice(2).join("."),
          )
        : definition.expected_ref
          ? field({ data: instance.data }, definition.expected_ref)
          : definition.literal;
      assert.deepEqual(step.assertion.expected, expected);
      if (["eq", "neq"].includes(definition.operator)) {
        const same =
          JSON.stringify(step.assertion.actual) === JSON.stringify(expected);
        const pass =
          definition.operator === "eq"
            ? same
            : typeof step.assertion.actual === typeof expected && !same;
        assert.equal(step.assertion.status, pass ? "PASS" : "FAIL");
      }
    }
  }
if (process.argv.includes("--data-only")) {
  console.log(
    JSON.stringify({
      run_id: run.suite_run_id,
      data_integrity: "PASS",
      evidence_count: run.evidence.length,
      statuses: run.instances.map((i) => i.status),
    }),
  );
  process.exit(0);
}
const copied = resolve("artifacts/validation/offline", run.suite_run_id);
await mkdir(copied, { recursive: true });
await cp(dir, copied, { recursive: true });
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({
  offline: true,
  viewport: { width: 1440, height: 900 },
});
const page = await context.newPage();
const errors = [],
  network = [];
page.on("pageerror", (e) => errors.push(String(e)));
page.on("request", (r) => {
  if (/^https?:/.test(r.url())) network.push(r.url());
});
try {
  await page.goto(pathToFileURL(join(copied, "report.html")).href);
  assert.equal(
    await page.locator("article.case").count(),
    run.instances.length,
  );
  for (const [i, instance] of run.instances.entries()) {
    const article = page.locator("article.case").nth(i);
    assert.equal(await article.getAttribute("data-status"), instance.status);
    for (const step of instance.steps) {
      const row = article.locator(
        `.step[data-step-id=${JSON.stringify(step.step_id)}]`,
      );
      assert.equal(
        await row.locator(".step-copy strong").textContent(),
        step.description,
      );
      if (step.assertion) {
        const values = [
          await row.locator(".actual-value").textContent(),
          await row.locator(".frozen-value").textContent(),
        ];
        assert.deepEqual(values, [
          JSON.stringify(step.assertion.actual, null, 2),
          JSON.stringify(step.assertion.expected, null, 2),
        ]);
        assert.equal(
          await row.locator("summary > .badge").getAttribute("title"),
          step.assertion.status,
        );
      }
    }
  }
  let evidenceNavigationChecked = false;
  const evidenceButton = page
    .locator("article.case:visible [data-evidence]:visible")
    .first();
  if (await evidenceButton.count()) {
    const targetId = await evidenceButton.getAttribute("data-evidence");
    await evidenceButton.click();
    await page
      .locator("article.case:visible .attachments img")
      .evaluateAll((images) =>
        Promise.all(images.map((image) => image.decode().catch(() => {}))),
      );
    const target = page.locator(`[id=${JSON.stringify(targetId)}]`);
    await page.waitForFunction(
      (id) => document.activeElement?.id === id,
      targetId,
    );
    const box = await target.boundingBox();
    // 滚动位置按整数像素结算，允许不足 1 CSS px 的边界舍入误差。
    assert(
      box && box.y >= -1 && box.y < 900,
      `截图完成加载后，证据目标必须仍在视口中：${JSON.stringify(box)}`,
    );
    evidenceNavigationChecked = true;
    await page.getByRole("tab", { name: "执行过程", exact: true }).click();
  }
  // CSV 按原用例模板分组；行实例的 case_id 不一定是筛选选项值。
  const caseFilter = await page
    .locator("article.case")
    .first()
    .getAttribute("data-case");
  assert(caseFilter, "报告缺少用例筛选分组");
  await page.locator("#case").selectOption(caseFilter);
  await page.locator("#data").selectOption(run.instances[0].data_id);
  await page.locator("#status").selectOption(run.instances[0].status);
  assert.equal(await page.locator("article.case:visible").count(), 1);
  await page.locator("#status").evaluate((el) => {
    el.add(new Option("不存在", "NONE"));
    el.value = "NONE";
    el.dispatchEvent(new Event("change"));
  });
  assert.equal(await page.locator("#empty").isVisible(), true);
  await page.locator("#clear").click();
  assert.equal(await page.locator("article.case:visible").count(), 1);
  assert.equal(
    await page.locator(".case-row:visible").count(),
    run.instances.length,
  );
  await page
    .locator("details")
    .evaluateAll((es) => es.forEach((e) => (e.open = true)));
  const link = page.locator("a.evidence").first();
  if (await link.count()) {
    const href = await link.getAttribute("href");
    const attachment = await context.newPage();
    await attachment.goto(pathToFileURL(join(copied, href)).href);
    await attachment.close();
  }
  await page
    .locator("details")
    .evaluateAll((es) => es.forEach((e) => (e.open = false)));
  for (const viewport of [
    { width: 1440, height: 900 },
    { width: 1920, height: 1080 },
  ]) {
    await page.setViewportSize(viewport);
    assert.equal(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
      true,
    );
    await page.screenshot({
      path: join(
        dir,
        `report-verified-${viewport.width}x${viewport.height}.png`,
      ),
      fullPage: true,
    });
  }
  assert.deepEqual(errors, []);
  assert.deepEqual(network, []);
  const result = {
    run_id: run.suite_run_id,
    instance_count: run.instances.length,
    evidence_count: run.evidence.length,
    event_count: eventCount,
    rebuild_equal: true,
    observations_match_raw: true,
    expected_values_match_plan: true,
    rendered_assertions_match: true,
    attachment_hashes: true,
    offline_filters: true,
    evidence_navigation_checked: evidenceNavigationChecked,
    empty_filter: true,
    desktop_viewports: ["1440x900", "1920x1080"],
    desktop_no_horizontal_overflow: true,
    script_errors: errors,
    network_requests: network,
  };
  await writeFile(
    join(dir, "report-verification.json"),
    JSON.stringify(result, null, 2),
  );
  console.log(result);
} finally {
  await browser.close();
}
