/** 会话进度与只读画面组件；所有业务状态来自服务端快照。 */
import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import type {
  InjectFace,
  PropsRuntime,
} from "@deepseek-ai/dsh-client-ui-slots";
import type {} from "@deepseek-ai/dsh-client-ui-conversation/client";
import type {} from "@deepseek-ai/dsh-client-ui-sidebar-right/client";
import type {} from "@deepseek-ai/dsh-client-ui-session/client";
import type { ProgressSnapshot, ProgressStep } from "../progress-model.js";

import {
  duration,
  elapsed,
  phaseLabels,
  selectedInstance,
  statusLabels,
  tone,
} from "./progress-view.js";
import { ProgressCard } from "./progress-dock.js";
import { RebuildReport, type ReportActions } from "./report-controls.js";
import {
  IconCheckOutlineRegular,
  IconWarningOutlineRegular,
} from "@deepseek-ai/dsh-client-ui-primitives";

export interface ProgressActions extends ReportActions {
  notice: {
    getSnapshot: () => string;
    subscribe: (listener: () => void) => () => void;
    dismiss: () => void;
  };
  read: (signal: AbortSignal) => Promise<ProgressSnapshot | null>;
  openDetails: () => void;
  previewVisible: {
    getSnapshot: () => boolean;
    subscribe: (listener: () => void) => () => void;
  };
  openPreview: (state: ProgressSnapshot) => void;
  followPreview: (state: ProgressSnapshot) => void;
}
function useProgress(actions: ProgressActions, visible = true) {
  const [snapshot, setSnapshot] = useState<ProgressSnapshot | null>();
  const [failed, setFailed] = useState(false);
  const [tick, setTick] = useState(0);
  const received = useRef(0);
  useEffect(() => {
    if (!visible) return;
    let stopped = false;
    let timer: ReturnType<typeof setTimeout>;
    let controller: AbortController | undefined;
    const poll = async () => {
      if (stopped || document.hidden) return;
      controller = new AbortController();
      const timeout = setTimeout(() => controller?.abort(), 5000);
      try {
        const next = await actions.read(controller.signal);
        if (!stopped) {
          received.current = performance.now();
          setSnapshot(next);
          setFailed(false);
        }
      } catch {
        if (!stopped) setFailed(true);
      } finally {
        clearTimeout(timeout);
        controller = undefined;
        if (!stopped) timer = setTimeout(poll, 1000);
      }
    };
    const visibility = () => {
      clearTimeout(timer);
      if (document.hidden) controller?.abort();
      else if (!controller) void poll();
    };
    document.addEventListener("visibilitychange", visibility);
    void poll();
    return () => {
      stopped = true;
      clearTimeout(timer);
      controller?.abort();
      document.removeEventListener("visibilitychange", visibility);
    };
  }, [actions.read, visible]);
  useEffect(() => {
    if (!visible || !snapshot || snapshot.finished_at || failed) return;
    const timer = setInterval(() => setTick((value) => value + 1), 1000);
    return () => clearInterval(timer);
  }, [snapshot?.run_id, snapshot?.finished_at, visible, failed]);
  void tick;
  const now = snapshot
    ? Date.parse(snapshot.server_now) +
      (failed || snapshot.finished_at
        ? 0
        : performance.now() - received.current)
    : Date.now();
  return { snapshot, failed, now };
}
function StepFlow({
  steps,
  now,
  details = false,
}: {
  steps: ProgressStep[];
  now: number;
  details?: boolean;
}) {
  return (
    <ol className="dsh-test-flow" aria-label="测试业务步骤">
      {steps.map((step, index) => (
        <li
          className={`dsh-test-${tone(step.status)}`}
          key={step.id}
          data-test-step={step.id}
          data-step-status={step.status}
          aria-current={step.status === "RUNNING" ? "step" : undefined}
        >
          <span className="dsh-test-node" aria-hidden="true">
            {["PASS", "SUCCEEDED"].includes(step.status) ? (
              <IconCheckOutlineRegular size={16} />
            ) : ["FAIL", "ERROR", "BLOCKED", "INCONCLUSIVE"].includes(
                step.status,
              ) ? (
              <IconWarningOutlineRegular size={16} />
            ) : (
              index + 1
            )}
          </span>
          <span className="dsh-test-step-name">{step.description}</span>
          <span className="dsh-test-step-time">
            {statusLabels[step.status] ?? step.status}
            {step.started_at ? ` · ${duration(elapsed(step, now))}` : ""}
          </span>
          {details && step.checks.length > 0 && (
            <ul className="dsh-test-checks">
              {step.checks.map((check, i) => (
                <li key={i}>
                  {check.text} · {statusLabels[check.status] ?? check.status}
                </li>
              ))}
            </ul>
          )}
          {details && step.reason && (
            <div className="dsh-test-reason">{step.reason}</div>
          )}
        </li>
      ))}
    </ol>
  );
}
function Heading({
  state,
  now,
  failed,
}: {
  state: ProgressSnapshot;
  now: number;
  failed: boolean;
}) {
  const total = Math.max(
    0,
    Date.parse(state.finished_at ?? new Date(now).toISOString()) -
      Date.parse(state.created_at),
  );
  return (
    <div className="dsh-test-heading">
      <strong className="dsh-test-phase">
        {failed ? "连接暂不可用" : phaseLabels[state.phase]}
      </strong>
      <span>
        {state.settled_steps} / {state.total_steps} 步已结算
      </span>
      <span className="dsh-test-time">已用 {duration(total)}</span>
    </div>
  );
}

export function ProgressDock(
  props: PropsRuntime<"conversation.input.dock"> & InjectFace<ProgressActions>,
) {
  const notice = useSyncExternalStore(
    props.notice.subscribe,
    props.notice.getSnapshot,
  );
  const { snapshot, failed, now } = useProgress(props);
  useEffect(() => {
    if (snapshot && !failed) props.followPreview(snapshot);
  }, [snapshot, failed, props.followPreview]);
  return (
    <>
      {notice && (
        <section
          className="dsh-test-command-notice"
          data-test-command-notice
          aria-label="测试命令提示"
        >
          <p role="alert">{notice}</p>
          <div className="dsh-test-actions">
            <button type="button" onClick={props.notice.dismiss}>
              关闭提示
            </button>
          </div>
        </section>
      )}
      {snapshot && (
        <ProgressCard
          snapshot={snapshot}
          now={now}
          failed={failed}
          actions={props}
        />
      )}
    </>
  );
}

/** 原生审核接管输入区时，标题旁的入口仍可查看步骤和持续观察状态。 */
export function ProgressHeader(
  props: PropsRuntime<"conversation.session.header.actions"> &
    InjectFace<ProgressActions>,
) {
  const { snapshot, failed } = useProgress(props);
  useEffect(() => {
    if (snapshot && !failed) props.followPreview(snapshot);
  }, [snapshot, failed, props.followPreview]);
  if (!snapshot) return null;
  return (
    <button
      type="button"
      className="dsh-test-header"
      aria-label="查看测试进度"
      onClick={props.openDetails}
      title={
        failed
          ? "连接暂不可用"
          : `${phaseLabels[snapshot.phase]} · ${snapshot.settled_steps}/${snapshot.total_steps} 步已结算`
      }
      data-test-progress-header
    >
      测试进度{" "}
      <span>
        {snapshot.settled_steps}/{snapshot.total_steps}
      </span>
    </button>
  );
}
export function ProgressDetails(
  props: PropsRuntime<"sidebar.right.pane.tab"> & InjectFace<ProgressActions>,
) {
  const info = props.useTabInfo();
  const { snapshot, failed, now } = useProgress(props, info.tab.visible);
  const [selected, setSelected] = useState<string>();
  const previewVisible = useSyncExternalStore(
    props.previewVisible.subscribe,
    props.previewVisible.getSnapshot,
  );
  useEffect(() => setSelected(undefined), [snapshot?.run_id]);
  if (!snapshot)
    return <p className="dsh-test-preview-message">当前会话还没有测试计划</p>;
  const instance =
    snapshot.instances.find((entry) => entry.id === selected) ??
    selectedInstance(snapshot);
  return (
    <section className="dsh-test-details" aria-label="测试步骤详情">
      <h2>{snapshot.title}</h2>
      <Heading state={snapshot} now={now} failed={failed} />
      {snapshot.rationale && (
        <p className="dsh-test-muted">{snapshot.rationale}</p>
      )}
      {snapshot.instances.length > 1 && (
        <select
          aria-label="查看测试实例"
          value={instance?.id ?? ""}
          onChange={(event) => setSelected(event.target.value)}
        >
          {snapshot.instances.map((entry, i) => (
            <option key={entry.id} value={entry.id}>
              {i + 1}. {entry.name} · {entry.data_id} ·{" "}
              {statusLabels[entry.status] ?? entry.status}
            </option>
          ))}
        </select>
      )}
      {instance && (
        <>
          <StepFlow steps={instance.steps} now={now} details />
          {(["setup", "cleanup"] as const).map(
            (phase) =>
              instance[phase].length > 0 && (
                <details key={phase}>
                  <summary>
                    {phase === "setup" ? "环境准备" : "资源清理"}
                  </summary>
                  {instance[phase].map((step) => (
                    <p key={step.id}>
                      {step.description} ·{" "}
                      {statusLabels[step.status] ?? step.status} ·{" "}
                      {duration(elapsed(step, now))}
                    </p>
                  ))}
                </details>
              ),
          )}
        </>
      )}
      <div className="dsh-test-actions">
        {snapshot.preview.ready && !failed && snapshot.phase !== "finished" && (
          <button
            type="button"
            aria-pressed={previewVisible}
            onClick={() => props.openPreview(snapshot)}
          >
            {previewVisible ? "隐藏实时画面" : "显示实时画面"}
          </button>
        )}
        {snapshot.report_url && (
          <a href={snapshot.report_url} target="_blank" rel="noreferrer">
            查看测试报告
          </a>
        )}
        {snapshot.phase === "finished" && (
          <RebuildReport
            rebuildReport={props.rebuildReport}
            runId={snapshot.run_id}
          />
        )}
        <small>时间包含等待</small>
      </div>
    </section>
  );
}
export function PreviewPanel(
  props: PropsRuntime<"sidebar.right.pane.tab"> & InjectFace<ProgressActions>,
) {
  const info = props.useTabInfo();
  const { snapshot, failed } = useProgress(props, info.tab.visible);
  useEffect(() => {
    if (snapshot?.phase === "finished" || snapshot === null)
      info.tab.actions.close();
  }, [snapshot?.phase, snapshot === null, info.tab.actions]);
  return (
    <section
      className="dsh-test-preview"
      data-test-browser-preview
      aria-label="浏览器实时画面"
    >
      {snapshot?.preview.ready && snapshot.preview.src && !failed ? (
        <iframe
          title="浏览器实时画面"
          src={snapshot.preview.src}
          sandbox="allow-scripts allow-same-origin"
        />
      ) : (
        <p className="dsh-test-preview-message">
          {failed
            ? "画面连接暂不可用"
            : (snapshot?.preview.reason ?? "正在连接当前浏览器画面")}
        </p>
      )}
    </section>
  );
}
