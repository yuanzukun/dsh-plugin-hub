/** 当前Agent的测试增强：宿主驱动对话，插件提供约束、可信采集和确定性结果。 */
import type { Context } from "@deepseek-ai/cordis";
import type { Agent } from "@deepseek-ai/dsh-agent";
import { createUserMessage } from "@deepseek-ai/dsh-llm";
import { ToolCallId } from "@deepseek-ai/dsh-llm/brand";
import type {
  ToolExecutionResult,
  ToolRunContext,
  ToolDefinition,
} from "@deepseek-ai/dsh-tools";
import type {} from "@deepseek-ai/dsh-system-prompt";
import type {} from "@deepseek-ai/dsh-plan-mode/types";
import type {} from "@deepseek-ai/dsh-session-projection";
import { randomUUID } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import {
  aggregate,
  ajv,
  expand,
  field,
  parsePlan,
  actionSchema,
  assertionSchema,
  statistics,
  captureSchema,
  validateCaptures,
  type Capture,
  type Binding,
  type CallRecord,
  type CaseRun,
  type Phase,
  type Step,
  type StepResult,
  type SuiteRun,
} from "./contracts.js";
import { Recorder } from "./recorder.js";
import { RecoveryManager } from "./recovery.js";
import { captureStep } from "./adapters.js";
import { RunBridge, runbridgePrefix } from "./runbridge.js";
import { evaluate } from "./assertions.js";
import { writeReport } from "./report.js";
import { ReportAccess } from "./report-access.js";
import { PreviewManager } from "./preview.js";
import {
  projectProgress,
  type ProgressSnapshot,
  type ProgressPhase,
} from "./progress-model.js";
import { defaults, type TestConfig } from "./config.js";
import {
  parseTextPlan,
  textPlanSchema,
  textReview,
  validateTextExpectation,
  parseTextExpected,
  batchTextPlanSchema,
  parseBatchPlan,
  announcementParts,
} from "./text-plan.js";
import type { TextInput } from "./case-input.js";
import { testLanguage, languageGuide } from "./language.js";
import { applyRevision } from "./revisions.js";
import {
  compositeOperation,
  operationTool,
  operationToolNames,
  runbridgeOperationNames,
  operationSchemaVersion,
  sealOperations,
} from "./actual-operations.js";
import type { ActualOperation } from "./contracts.js";
import { writeManualCases } from "./manual-case.js";
import { ManualSource } from "./manual-source.js";

declare module "@deepseek-ai/dsh-llm" {
  interface MessageSourceMap {
    "plugin:test": { kind: "plugin:test"; form: "notice"; summary: string };
  }
}
const empty = {
  type: "object" as const,
  properties: {},
  additionalProperties: false,
};
const output = {
  schema: { type: "object" as const },
  render: (_: unknown, value: unknown) => [
    { type: "text" as const, text: JSON.stringify(value, null, 2) },
  ],
};
const guide = `当前对话已启用测试增强，仍由本会话正常推理、工具调用、审批、追问和回复完成任务，不创建其他会话或后台任务。
规划阶段只根据用户描述分析目标、业务步骤、输入和预期。禁止访问网站、运行命令、调用API或提前验证用例；不能通过预跑寻找选择器。只可使用test_submit_plan、test_current、todo_write和ask_user_question。已给目标、输入和预期时直接形成计划；缺少必要信息时在本会话追问。
test_submit_plan按工具schema提交：普通任务为{name,rationale:"一两句面向用户的拆分说明",steps:[{description,checks?:string[]}]}；文件/参数化批量模式为{name,rationale,cases:[{instance_id,name,rationale,steps}]}，按planning_input.instances每个id恰好提交一次，使用对应已展开task与参数，不能合并、遗漏或自行改参数。把用户的一段话按常规理解拆成几个业务动作短句，checks只写用户预期的自然语言。不要提供suite_id、执行工具、选择器、能力类型、URL白名单、输出Schema、字段路径或比较器；不要为了未知页面结构追问用户。例如steps:[{description:"访问ceshiren.com"},{description:"搜索agent"},{description:"打开第一条搜索结果"},{description:"查看帖子的点赞数",checks:["点赞数不为0"]}]。用户没有提供的操作细节无需在规划期补齐。rationale简要说明为什么按这些业务动作拆分、怎样核对目标，不展开详细推理。/test提交成功后，必须先在正常对话中用原始任务、拆分思路、步骤清单三个部分通报返回的plan_summary，再执行第一个动作；/test-plan通过原生审核卡片展示这三部分。
文字计划执行：每次只处理test_current的当前步骤。需要操作目标时先test_define_step({capability:"browser"或"api",allowed_targets:[本步目标网址],reason:"当前步骤依据"})设定操作范围，无需填写outputs。随后使用原生工具观察、操作、调整；了解实际页面后直接test_capture采集。采集时插件按采集方式自动登记输出类型，无需先写输出Schema；已有成功观察不可覆盖，但可补采其他输出。API通常以response保存完整响应。不是在执行开始时编译整份计划，不能配置未来步骤。
实际操作说明：浏览器访问、点击、输入、按键、选择、拖动、业务等待等必须调用test_execute_operation({description:"面向用户的简短操作说明，说明对象、动作和必要目的",tool_name:"mcp__playwright__browser_click",arguments:{原工具参数}})。tool_name从Schema的完整名称中选择，必须保留mcp__playwright__前缀。先观察真实页面，再提交当前一个动作的说明并执行，不能一次编造后续操作。常规导航、点击、输入和提交必须逐个使用原子动作工具，不得用browser_run_code或browser_evaluate把这些常规交互合并成脚本。只有原子工具无法表达的动作才使用复合脚本，并保留需复核标记。点击搜索按钮与输入关键词分别调用；browser_type不要submit:true，输入后单独browser_press_key提交Enter；多个表单字段优先逐字段填写。说明随同一次调用保存，不需要另一个登记工具或额外模型轮次。原生browser_snapshot、截图及只读browser_evaluate仍可直接用于分析；evaluate仅允许观察，脚本操作必须带说明并标为复合操作，无法证明内部每个动作都完成。API请求继续test_capture，不调用新的浏览器入口或直接test_api_get。操作成功仅表示工具结算，断言仍按可信采集计算。定位失败可调整后产生新记录，保留旧失败；插件自行生成身份、顺序和状态。用户要求的准备与清理遵守当前冻结阶段，自动复位、关闭继续test_capture({})。
文字检查点：获得可信观察后，对当前步骤的每个checks，调用test_bind_check({check_index:从0开始,assertion:{observation_ref:"step_编号.输出名.可选嵌套路径",operator:"eq/neq/...",expected_value:"用户预期原文，例如agent或0；不加引号或数组包装"}})。也可用expected_observation_ref比较前一步观察（例如第一条搜索结果链接）。rule_ref由插件绑定文字检查点；不用提交actual。预期来自原文和文字检查，不能按实际值改写；数字不为0用neq和expected_value直接填"0"（按数字条件解析为数值0）。正文或文本不为空必须用text采集、operator:"neq"、expected_value:""（空字符串），不能填0或字符串0，也不能以元素可见替代正文非空。每个文字检查都必须绑定程序断言，不能靠口头宣布通过；纯检查步骤可以直接引用前一步的可信观察。绑定后test_finish_step结算当前步骤并计算断言。无法完成用test_fail_step说明原因。
接口数组检查：接口数组的长度检查必须引用step_id.response.body.length；字段如step_id.response.body.0.iid，标签数量用step_id.response.body.0.labels.length。不要把整个数组与数量比较；只复用已采集响应，不重复请求。unit只表示展示单位，不会把数组转换成长度；长度断言必须在observation_ref引用.length，不能使用整个body配合unit:"length"。
执行阶段：文字计划提交（/test-plan还需批准）后按test_current执行当前业务目标。此时才使用正常Playwright工具查看页面、点击、输入、等待和检查DOM，可根据实际状态调整定位、操作组合和重试，无需重跑整条用例；只完成当前步骤，不提前执行后续步骤。browser_evaluate可用于实际页面结构检查，断言实际值仍只接受test_capture可信采集。JSON文件计划已提交时直接按test_current继续，不能重复提交计划或预跑。
运行时采集：完成当前动作后，按页面/接口实际情况调用test_capture({capture:{输出名:采集定义},reason:"依据当前页面选择或修正定位的原因"})。它不接受actual或任意执行代码。dom mode支持text/number/count/visible/url/attribute/value；selector为真实CSS，可用index定位集合。页面路径用{kind:"dom",mode:"url",field:"pathname"}；元素href用{kind:"dom",mode:"attribute",attribute:"href",selector:"实际选择器",index:0,field:"pathname"}；数字用mode:number；文本框用mode:value；http仅用于返回JSON的GET接口。HTTP采集本身会发送请求，直接调用test_capture，无需先用test_api_get预发一次。完整响应为{status:number,body:JSON}，不含headers；可声明单一object输出，用{kind:"http",url:"授权URL",field:""}一次采集，再通过step_id.output_name.status及step_id.output_name.body的嵌套路径断言。必要输出都要采集。采集定义可根据实际页面修正，保留每次原因和调用记录；已有成功观察不可覆盖，只补采尚缺的输出。不能改变输出含义、输出类型、目标范围或断言预期。静态JSON的capture和自动清理已有采集定义，直接test_capture({})即可。
采集成功后调用test_finish_step；程序计算断言，模型不能填写实际值或口头改判。定位失败可修正重试；确实无法完成时test_fail_step说明原因。用户停止后不再执行业务，只按同会话收尾指导执行预授权清理。全部完成调用test_finish，并在原生最终回复写明逐步结果、断言实际/预期、保存位置和工具返回的报告链接。BLOCKED、SKIPPED或缺证据不能写成通过。`;

function notice(text: string) {
  return createUserMessage({
    source: { kind: "plugin:test", form: "notice", summary: "测试增强上下文" },
    content: [{ type: "text", text }],
  });
}
function closeStep(id: string, description: string): Step {
  return {
    step_id: id,
    kind: "action",
    description,
    required: true,
    depends_on: [],
    ...(id === "__close"
      ? { run_if: "resource_exists" as const, resource_ref: "browser_context" }
      : {}),
    action: {
      goal: "调用test_capture关闭并验证浏览器上下文释放，然后test_finish_step。",
      capability: "browser",
      allowed_targets: [],
      inputs: {},
      outputs: { released: { type: "boolean" } },
      completion_requirements: ["released"],
      capture: { released: { kind: "browser_close" } },
    },
  };
}
/** JSON 字符串避开原生工具对无类型嵌套数组的转换；保留原对象入口。 */
function nativeOperationArguments(input: {
  arguments?: unknown;
  arguments_json?: string;
}): Record<string, unknown> {
  if ((input.arguments !== undefined) === (input.arguments_json !== undefined))
    throw new Error(
      "请仅提供 arguments 参数对象或 arguments_json 完整 JSON 字符串中的一种",
    );
  let value = input.arguments;
  if (input.arguments_json !== undefined) {
    try {
      value = JSON.parse(input.arguments_json);
    } catch {
      throw new Error("arguments_json 必须是有效 JSON，不执行表达式");
    }
  }
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error("原工具参数必须是 JSON 对象");
  return value as Record<string, unknown>;
}
interface Entry {
  instance: CaseRun;
  step: Step;
  phase: Phase;
}

export class NativeTests {
  readonly config: TestConfig;
  readonly reports: ReportAccess;
  readonly preview: PreviewManager;
  readonly recovery: RecoveryManager;
  readonly sessions = new Map<string, NativeTest>();
  private readonly historicalProgress = new Map<string, SuiteRun | null>();
  private starting = false;
  constructor(
    readonly ctx: Context,
    config: Partial<TestConfig>,
    private readonly preparePreview?: () => Promise<void>,
  ) {
    this.config = { ...defaults, ...config };
    this.preview = new PreviewManager(this.config.preview);
    this.recovery = new RecoveryManager(
      this.config.outputRoot,
      this.config.cleanupTimeoutMs,
      () =>
        this.starting ||
        [...this.sessions.values()].some((s) => !s.closed || s.disposing),
      () => this.preview.shutdown(),
    );
    for (const key of [
      "stepTimeoutMs",
      "cleanupTimeoutMs",
      "cancelGraceMs",
      "maxRevisions",
    ] as const)
      if (!Number.isFinite(this.config[key]) || this.config[key] <= 0)
        throw new Error("配置必须为有限正数: " + key);
    mkdirSync(this.config.outputRoot, { recursive: true });
    const released = new Set<string>();
    for (const file of readdirSync(this.config.outputRoot).filter((n) =>
      /^release-.*\.json$/.test(n),
    )) {
      try {
        released.add(
          JSON.parse(readFileSync(join(this.config.outputRoot, file), "utf8"))
            .quarantine.details.run_id,
        );
      } catch {
        /* 不是有效处置证据。 */
      }
    }
    for (const id of readdirSync(this.config.outputRoot).filter((n) =>
      /^run-[\w-]+$/.test(n),
    )) {
      try {
        const run = JSON.parse(
          readFileSync(
            join(this.config.outputRoot, id, "results.json"),
            "utf8",
          ),
        ) as SuiteRun;
        if (
          run.manifest.execution === "native-conversation" &&
          run.lifecycle !== "FINISHED" &&
          !released.has(id)
        )
          this.quarantine(
            run,
            "宿主重启发现未结算测试；请检查外部操作和资源，不能自动重放",
          );
      } catch {
        /* 不读取或修改宿主会话数据。 */
      }
    }
    this.reports = new ReportAccess(this.config.outputRoot);
  }
  async start(
    agent: Agent,
    task: string,
    plan?: unknown,
    review = false,
    input?: TextInput,
  ): Promise<string> {
    if (!task.trim()) throw new Error("请提供动作、输入和可验证预期");
    if (agent.status !== "idle")
      throw new Error("请等待当前对话轮次结束后再启动测试");
    const quarantine = this.recovery.status().quarantine;
    if (quarantine)
      throw new Error(
        `测试环境尚未释放，已隔离：${quarantine.reason}。${quarantine.overdue ? "隔离时间已超过清理超时，可能异常卡住。" : ""}请进入“设置 → 测试插件 → 测试环境”，确认旧操作已停止后处理并释放，再重新执行测试命令；无法自动处理时，在同一设置页提交实际处置证据。`,
      );
    if (
      this.starting ||
      this.recovery.busy ||
      [...this.sessions.values()].some((s) => !s.closed || s.disposing)
    )
      throw new Error("已有测试使用共享浏览器，请先结束或停止该测试");
    if (review && !this.ctx.commands.find(agent, "plan"))
      throw new Error(
        "/test-plan 需要宿主启用原生 dsh-plan-mode 和用户审核通道",
      );
    this.starting = true;
    try {
      await this.preparePreview?.();
      const test = new NativeTest(this, agent, task, review, input);
      this.sessions.set(agent.id, test);
      try {
        await test.preparePlanning();
        if (review) await test.enterPlanMode();
        test.attach();
        if (plan !== undefined) test.submit(plan, true);
        return await test.start(task);
      } catch (error) {
        await test.dispose();
        throw error;
      }
    } finally {
      this.starting = false;
    }
  }
  reportId(sessionId: string): string | undefined {
    const current = this.sessions.get(sessionId);
    if (current) return current.run.suite_run_id;
    for (const id of readdirSync(this.config.outputRoot)
      .filter((id) => /^run-[\w-]+$/.test(id))
      .sort()
      .reverse()) {
      try {
        const run = JSON.parse(
          readFileSync(
            join(this.config.outputRoot, id, "results.json"),
            "utf8",
          ),
        ) as SuiteRun;
        if (
          run.manifest.origin_session_id === sessionId &&
          run.lifecycle === "FINISHED" &&
          existsSync(join(this.config.outputRoot, id, "report.html"))
        )
          return id;
      } catch {
        /* 不把损坏记录作为当前会话报告。 */
      }
    }
  }
  presentation(sessionId: string): ProgressSnapshot | null {
    const current = this.sessions.get(sessionId);
    if (current) return current.presentation();
    if (!this.historicalProgress.has(sessionId)) {
      const id = this.reportId(sessionId);
      this.historicalProgress.set(
        sessionId,
        id
          ? (JSON.parse(
              readFileSync(
                join(this.config.outputRoot, id, "results.json"),
                "utf8",
              ),
            ) as SuiteRun)
          : null,
      );
    }
    const run = this.historicalProgress.get(sessionId);
    return run
      ? projectProgress({
          run,
          phase: "finished",
          reportUrl: this.reports.url(run.suite_run_id),
        })
      : null;
  }
  quarantine(run: SuiteRun, reason: string): void {
    run.resource_quarantined = true;
    this.recovery.mark(run, reason);
  }
  release(evidenceFile: string): void {
    this.recovery.release(evidenceFile);
  }
  async shutdown(): Promise<void> {
    this.recovery.cancel();
    for (const test of this.sessions.values())
      if (!test.closed) await test.shutdown();
      else await test.dispose();
    await this.preview.shutdown();
  }
}

export class NativeTest {
  readonly recorder: Recorder;
  readonly run: SuiteRun;
  readonly agent: Agent;
  readonly browser?: RunBridge;
  closed = false;
  private planned = false;
  private reportReady = false;
  private cancelled = false;
  private cleanupTurn = false;
  private finalizing = false;
  private finishing?: Promise<unknown>;
  private disposal?: Promise<void>;
  private disposalDone = false;
  private nudges = 0;
  private planningQuestion = false;
  private cursor = 0;
  private entries: Entry[] = [];
  private current?: Entry & { result: StepResult; binding: Binding };
  private calls = new Map<string, CallRecord>();
  private pendingTools = new Set<string>();
  private trustedCalls = new Map<string, ToolRunContext["token"]>();
  private operations = new Map<string, ActualOperation>();
  private delegatedFailures = new Map<string, ToolExecutionResult>();
  private disposers: (() => void)[] = [];
  private timer?: ReturnType<typeof setTimeout>;
  private stoppingTimer?: ReturnType<typeof setTimeout>;
  private mediaDeadline?: number;
  private task: string;
  private readonly originalTask: string;
  private readonly manualSource: ManualSource;
  private draft?: SuiteRun["plan"];
  private reviewCall?: string;
  private reviewDismissed = false;
  private previousPlanMode?: boolean;
  private announcement?: { summary: string; required: string[]; text: string };
  constructor(
    private owner: NativeTests,
    agent: Agent,
    task: string,
    private review = false,
    private input?: TextInput,
  ) {
    this.agent = agent;
    this.task = task;
    this.originalTask = task;
    this.input = input ? structuredClone(input) : undefined;
    const id =
      "run-" +
      new Date().toISOString().replace(/[:.]/g, "-") +
      "-" +
      randomUUID().slice(0, 8);
    this.recorder = new Recorder(owner.config.outputRoot, id);
    this.run = {
      schema_version: "1",
      suite_run_id: id,
      name: "测试：" + task.slice(0, 80),
      created_at: new Date().toISOString(),
      lifecycle: "RUNNING",
      plan: {
        schema_version: "1",
        suite_id: "native",
        name: task,
        source_refs: [],
        cases: [],
      },
      instances: [],
      evidence: [],
      incomplete: false,
      resource_quarantined: false,
      manifest: {
        plugin_version: "0.15.0",
        plan_review: review,
        execution: "native-conversation",
        origin_session_id: agent.id,
        tools_mode: "native",
        actual_operations_schema: operationSchemaVersion,
      },
    };
    this.manualSource = new ManualSource(this.recorder.directory, id);
    if (owner.config.browser?.backend === "runbridge")
      this.browser = new RunBridge(
        owner.config.browser,
        owner.config.workspace,
        () => {
          if (this.browser?.lease.record)
            this.run.node_lease = structuredClone(this.browser.lease.record);
          if (this.current && this.browser?.resource) {
            this.current.instance.resources.browser_context = structuredClone(
              this.browser.resource,
            );
          }
          this.save();
        },
        {
          credentialFile: join(
            owner.config.outputRoot,
            ".runbridge-access",
            id + ".json",
          ),
          cleanupTimeoutMs: owner.config.cleanupTimeoutMs,
          invalid: (reason) => {
            if (!this.closed && !this.finishing && !this.reportReady)
              this.stop(reason);
          },
          retainAccessFile: () =>
            this.run.resource_quarantined ||
            this.run.incomplete ||
            this.run.instances.some((instance) => {
              const resource = instance.resources.browser_context;
              return (
                !!resource?.remote &&
                ["exists", "unknown"].includes(resource.state)
              );
            }),
        },
      );
  }
  async preparePlanning(): Promise<void> {
    await this.browser?.preparePlanning();
  }
  private get browserPrefix(): string {
    return this.browser?.prefix ?? "mcp__playwright__";
  }
  private get closeTool(): string {
    return this.browser
      ? this.browser.prefix + "browser_stop"
      : "mcp__playwright__browser_close";
  }
  private guidance(): string {
    if (!this.browser) return guide;
    return guide
      .split("\n")
      .map((line) => {
        if (line.startsWith("实际操作说明："))
          return '实际操作说明：浏览器动作必须调用test_execute_operation，tool_name从Schema中选择完整的mcp__runbridge__名称。导航、填写、点击、按键和等待逐个执行并附面向用户的说明。观察可直接browser_snapshot、browser_inspect_dom、browser_read或browser_tabs(action=list)。会话和页面参数由插件注入，不能传入node_id/session_id/page_id；只有browser_tabs明确选页时提供其返回的page_id。目标使用target.by/value/name；by=role时value只填button、textbox等角色，name填真实可访问名称，不能把snapshot整行作为value。含数组参数通过test_execute_operation的arguments_json传完整JSON字符串，例如{"target":{"by":"css","value":"#type"},"values":["api"]}；不要同时传arguments。iframe用frame_selector；没有Playwright snapshot ref、evaluate或run_code。先观察页面，再选择下一动作。断言实际值仅接受test_capture的固定DOM采集，覆盖text/number/count/visible/url/attribute/value；API仍在DSH宿主采集。初始化与释放只调用test_capture({})。截图与动作成功不能宣布PASS，写操作结果未知不得盲目再次提交；已取得原动作request_id时，用tool_request_status查询原结果，不能传入或覆盖会话身份，查询成功仍需test_capture验证业务结果。';
        if (line.startsWith("执行阶段："))
          return "执行阶段：按test_current完成当前业务目标，使用当前RunBridge原子工具操作虚拟机页面；不能调用本机Playwright或换另一会话。browser_fill替换整个输入，按Enter另用browser_press_key；select_option按value选择；触发弹窗前用browser_handle_dialog设置一次性策略。当前步骤的允许目标与冻结预期不可改变。浏览器由Node新建，网络回环地址指虚拟机；每条会话最多3600秒，整批Node使用权由插件领取、按需续租并在test_finish等待归还。租约失效后不能领取新令牌续跑旧步骤。";
        return line;
      })
      .join("\n");
  }
  private initialStep(): Step {
    if (!this.browser)
      return closeStep("__reset", "初始化本次测试浏览器上下文");
    return {
      step_id: "__reset",
      kind: "action",
      description: "启动并确认本次远程浏览器",
      required: true,
      depends_on: [],
      action: {
        goal: "调用test_capture({})申请本次远程浏览器，再test_finish_step。",
        capability: "browser",
        allowed_targets: [],
        inputs: {},
        outputs: { initialized: { type: "boolean" } },
        completion_requirements: ["initialized"],
        capture: { initialized: { kind: "browser_open" } },
      },
    };
  }
  get id(): string {
    return this.agent.id;
  }
  async enterPlanMode(): Promise<void> {
    // Web预设将planMode放在隔离组中；通过官方命令解析当前Agent的有效服务。
    const state = this.agent.ctx.sessionProjections.stateOf(
      this.agent.session,
      "plan",
    );
    this.previousPlanMode =
      state?.running?.wanted ?? state?.wanted ?? state?.active ?? false;
    await this.setPlanMode(true);
  }
  private async setPlanMode(active: boolean): Promise<void> {
    const executed = await this.owner.ctx.commands.execute(
      this.agent,
      active ? "/plan" : "/plan off",
      [],
      new AbortController().signal,
    );
    if (executed?.result.kind !== "success")
      throw new Error(executed?.result.text ?? "宿主未提供原生/plan命令");
  }
  attach(): void {
    const scope = this.agent.ctx;
    const own = (dispose: () => void) => {
      this.disposers.push(dispose);
    };
    if (this.browser) own(this.browser.register(scope));
    own(
      scope.systemPrompt.section({
        name: "plugin:test-guidance",
        order: 10500,
        interpolate: false,
        text: () =>
          languageGuide(this.outputLanguage()) +
          "\n" +
          (this.reportReady
            ? "测试报告已生成。请在本轮回复中只总结test_finish返回的权威统计、逐步状态和断言。BLOCKED或缺少断言记录绝不能写成PASS；页面口头观察不能替代程序断言。给出报告链接。"
            : this.guidance() +
              (this.review && !this.planned
                ? "\n本次为审核入口（/test-plan或/test-data）：原生plan模式中只规划。test_submit_plan仅保存可修改草案，不会执行。提交成功后，将返回的review_markdown原样作为exit_plan_mode的plan参数展示审核。不要自行缩写或替换审核内容。用户要求修改时重新test_submit_plan再审核；同意后插件自动冻结已审草案并开始执行。关闭plan模式不代表批准。"
                : "") +
              "\n当前测试状态：" +
              JSON.stringify(this.state())),
      }),
    );
    const tool = (
      name: string,
      description: string,
      parameters: any,
      execute: (args: any, exec: ToolRunContext) => unknown,
    ) =>
      own(
        scope.tools.register({
          name,
          description,
          parameters,
          output,
          execute: async (args, exec) => {
            // 可选TypeScript字段不得以undefined进入宿主的无损JSON工具边界。
            return JSON.parse(JSON.stringify(await execute(args, exec)));
          },
        }),
      );
    tool(
      "test_submit_plan",
      "提交本对话文字测试计划；审核入口只保存草案。从原文提取预期，不能提交实际结果。批量模式每个instance_id恰好规划一次。",
      this.input ? batchTextPlanSchema : textPlanSchema,
      (args) => this.submit(args),
    );
    tool(
      "test_current",
      "读取当前步骤、冻结目标、输入及已计算断言。",
      empty,
      () => this.state(),
    );
    const operationParameters = {
      type: "object",
      required: ["description", "tool_name"],
      additionalProperties: false,
      properties: {
        description: { type: "string", minLength: 1, maxLength: 2000 },
        tool_name: {
          type: "string",
          enum: this.browser ? runbridgeOperationNames : operationToolNames,
          description: `选择完整的原生MCP工具名，必须带${this.browserPrefix}前缀；不要只填browser_click等短名称。`,
        },
        arguments: { type: "object" },
        arguments_json: {
          type: "string",
          description:
            "原工具参数的完整 JSON 字符串；含数组或多层对象时使用，不能同时传 arguments。",
        },
      },
    } satisfies ToolDefinition["parameters"];
    const validateOperation = ajv.compile(operationParameters);
    own(
      scope.tools.register({
        name: "test_execute_operation",
        description:
          "保存当前一个实际浏览器动作的简短说明，再经同一Agent原生管线执行工具。常规点击、输入、提交必须分别选对应动作工具，不得用脚本合并；脚本只用于原子工具无法表达的复合操作并需复核。不接受成功声明或断言实际值。",
        parameters: operationParameters,
        output: {
          schema: {
            type: "object",
            required: ["content"],
            properties: { content: { type: "array" } },
          },
          render: (_, value) =>
            (value as unknown as { content: ToolExecutionResult["content"] })
              .content,
        },
        execute: async (args, exec) => {
          if (!validateOperation(args))
            throw new Error(
              "操作参数无效：" +
                ajv.errorsText(validateOperation.errors) +
                `。请提供description、完整tool_name（例如${this.browserPrefix}browser_click），并选择arguments对象或arguments_json字符串。`,
            );
          const input = args as {
            description: string;
            tool_name: string;
            arguments?: Record<string, unknown>;
            arguments_json?: string;
          };
          const toolArguments = nativeOperationArguments(input);
          this.requireSettled(exec);
          if (this.releaseStep())
            throw new Error("当前只允许释放浏览器，请调用test_capture({})");
          if (
            !this.current?.step.action ||
            this.current.step.action.capability !== "browser"
          )
            throw new Error("当前步骤没有浏览器操作范围");
          if (!input.description.trim())
            throw new Error("请说明当前操作的对象与动作");
          if (!operationTool(input.tool_name, toolArguments))
            throw new Error(
              "此入口只转交浏览器业务操作；tool_name必须是完整名称，例如mcp__playwright__browser_click。观察用原生工具，API用test_capture",
            );
          const response = await this.call(
            input.tool_name,
            toolArguments,
            exec,
            {
              description: input.description.trim(),
              description_source: "model",
            },
          );
          if (response.result.isError)
            this.delegatedFailures.set(exec.callId, response.result);
          else {
            for (const context of response.result.additionalContexts ?? [])
              exec.deferContext(context);
            if (response.result.concludesTurn) exec.concludeTurn();
          }
          return {
            tool_call_id: response.callId,
            content: response.result.content,
            ...(!response.result.isError
              ? { result: response.result.value }
              : {}),
          };
        },
      }),
    );
    tool(
      "test_define_step",
      "仅在执行当前文字步骤时确定能力与目标；观察页面后直接test_capture，输出由采集方式自动登记。",
      {
        type: "object",
        required: ["capability", "allowed_targets", "reason"],
        additionalProperties: false,
        properties: {
          capability: actionSchema.properties.capability,
          allowed_targets: actionSchema.properties.allowed_targets,
          reason: { type: "string", minLength: 1 },
        },
      },
      async (args, exec) => {
        this.requireSettled(exec);
        const c = this.current;
        if (!c || c.phase !== "test" || c.step.checks === undefined)
          throw new Error(
            "仅当前文字步骤可以在运行时定义，不能修改JSON计划或未来步骤",
          );
        if (
          c.result.observations.length ||
          c.instance.effective_steps.some(
            (s) =>
              s.step_id.startsWith(c.step.step_id + "_check_") && s.assertion,
          )
        )
          throw new Error("本步已有观察或断言，不能重写定义");
        const step: Step = {
          ...c.step,
          kind: "action",
          action: {
            goal: c.step.description,
            capability: args.capability,
            allowed_targets: args.allowed_targets,
            inputs: {},
            outputs: {},
            completion_requirements: [],
            capture_mode: "runtime",
          },
        };
        const effective = c.instance.effective_steps.map((s) =>
          s.step_id === step.step_id ? step : s,
        );
        this.validateEffective(c.instance, effective);
        c.step = step;
        c.instance.effective_steps = effective;
        this.recorder.event(
          "step_defined",
          { step, reason: args.reason },
          c.binding,
        );
        if (
          args.capability === "browser" &&
          !c.instance.resources.browser_context
        ) {
          // 直到实际遇到浏览器步骤才初始化；接口步骤不触碰浏览器。
          if (!this.browser)
            c.instance.resources.browser_context = {
              id: this.id,
              state: "exists",
            };
          const after = this.entries.findIndex(
            (e, n) => n >= this.cursor && e.instance !== c.instance,
          );
          this.entries.splice(after < 0 ? this.entries.length : after, 0, {
            instance: c.instance,
            phase: "cleanup",
            step: closeStep("__close", "关闭并确认浏览器上下文释放"),
          });
          this.save();
          const reset = await this.call(
            this.browser
              ? this.browser.prefix + "browser_start"
              : this.closeTool,
            {},
            exec,
          );
          if (reset.result.isError) {
            this.finishStep("ERROR", "初始化浏览器上下文失败");
            this.advance();
            throw new Error("浏览器初始化失败，已进入收尾");
          }
        }
        this.save();
        return this.state();
      },
    );
    tool(
      "test_bind_check",
      "把当前步骤的一个文字检查点绑定为程序断言；预期来自已批准文字，实际值只能引用可信观察，绑定后不能改判。",
      {
        type: "object",
        required: ["check_index", "assertion"],
        additionalProperties: false,
        properties: {
          check_index: { type: "integer", minimum: 0 },
          assertion: {
            type: "object",
            required: ["observation_ref", "operator"],
            additionalProperties: false,
            properties: {
              observation_ref: {
                ...assertionSchema.properties.observation_ref,
                description:
                  "点分隔的可信观察路径，例如step_1.response.status、step_1.response.body.0.iid；数组长度用step_1.response.body.length，标签数量用step_1.response.body.0.labels.length。数组索引用数字路径段，不使用[0]语法。",
              },
              operator: assertionSchema.properties.operator,
              expected_value: {
                type: "string",
                description:
                  '用户预期原文。例如agent、dsh、0或200；不加JSON引号、不包数组或value对象。正文/文本不为空用neq及expected_value:""（空字符串）。数字/布尔按检查和观察类型解析；仅对象、数组或range预期写JSON。与expected_observation_ref二选一',
              },
              expected_observation_ref:
                assertionSchema.properties.expected_observation_ref,
              unit: {
                ...assertionSchema.properties.unit,
                description:
                  "仅表示展示单位，不执行取长度、计数或其他转换；数组长度必须在 observation_ref 引用 .length。",
              },
              tolerance: assertionSchema.properties.tolerance,
            },
          },
        },
      },
      (args, exec) => {
        this.requireSettled(exec);
        const c = this.current;
        const text = c?.step.checks?.[args.check_index];
        if (!c || c.phase !== "test" || !text)
          throw new Error("当前步骤没有此文字检查点");
        const id = `${c.step.step_id}_check_${args.check_index + 1}`;
        if (c.instance.effective_steps.some((s) => s.step_id === id))
          throw new Error("检查点已经绑定，不能改写预期");
        const { expected_value, ...definition } = args.assertion;
        if (
          [
            definition.observation_ref,
            definition.expected_observation_ref,
          ].some((ref) => typeof ref === "string" && /\[\d+\]/.test(ref))
        )
          throw new Error(
            "观察引用使用点分隔路径，数组索引用数字路径段，例如step_1.response.body.0.iid；不能使用body[0]。修正字段引用，不修改用户预期。",
          );
        const [producer, outputName, ...path] = String(
          definition.observation_ref,
        ).split(".");
        const observation = c.instance.steps
          .find((s) => s.step_id === producer)
          ?.observations.find((o) => o.output_name === outputName);
        if (!observation) throw new Error("请先采集可信观察，再绑定文字检查");
        const actual = field(observation.value, path.join("."));
        const step: Step = {
          step_id: id,
          kind: "assertion",
          description: text,
          required: true,
          depends_on: [c.step.step_id],
          assertion: {
            ...definition,
            ...(expected_value === undefined
              ? {}
              : {
                  literal: parseTextExpected(
                    text,
                    expected_value,
                    actual,
                    definition.operator,
                  ),
                }),
            rule_ref: id,
          },
        };
        validateTextExpectation(text, step.assertion!);
        const effective = [...c.instance.effective_steps];
        const position = effective.findIndex(
          (s) => s.step_id === c.step.step_id,
        );
        const earlierIds = c.step
          .checks!.slice(0, args.check_index)
          .map((_, n) => `${c.step.step_id}_check_${n + 1}`);
        const preceding = effective.filter((s) =>
          earlierIds.includes(s.step_id),
        ).length;
        effective.splice(position + 1 + preceding, 0, step);
        this.validateEffective(c.instance, effective);
        c.instance.effective_steps = effective;
        this.entries.splice(this.cursor + preceding, 0, {
          instance: c.instance,
          phase: "test",
          step,
        });
        this.recorder.event(
          "check_bound",
          { step, check_index: args.check_index },
          c.binding,
        );
        this.save();
        return this.state();
      },
    );
    tool(
      "test_capture",
      "执行可信采集。运行时绑定传capture与reason，只能补采尚缺输出；固定计划和清理调用test_capture({})，也接受capture:{}，沿用既有采集定义。",
      {
        type: "object",
        properties: {
          capture: captureSchema,
          reason: { type: "string", minLength: 1 },
        },
        additionalProperties: false,
      },
      async (args, exec) => {
        const c = this.current;
        if (!c?.step.action) throw new Error("没有当前采集步骤");
        this.requireSettled(exec);
        let action = c.step.action;
        let captures = action.capture ?? {};
        if (action.capture_mode === "runtime") {
          if (
            !args.capture ||
            !Object.keys(args.capture).length ||
            !args.reason?.trim()
          )
            throw new Error(
              "请根据当前页面提供capture及reason；不要提交实际值",
            );
          if (c.step.checks !== undefined) {
            const outputs = { ...action.outputs };
            for (const [name, value] of Object.entries(args.capture) as [
              string,
              Capture,
            ][]) {
              if (c.result.observations.some((o) => o.output_name === name))
                continue;
              outputs[name] =
                value.kind === "dom"
                  ? {
                      type: ["number", "count"].includes(value.mode ?? "")
                        ? "number"
                        : value.mode === "visible"
                          ? "boolean"
                          : "string",
                    }
                  : value.kind === "http" && !value.field
                    ? { type: "object" }
                    : {};
            }
            const nextAction = {
              ...action,
              outputs,
              completion_requirements: Object.keys(outputs),
            };
            validateCaptures(nextAction, args.capture);
            const step = { ...c.step, action: nextAction };
            const effective = c.instance.effective_steps.map((s) =>
              s.step_id === c.step.step_id ? step : s,
            );
            this.validateEffective(c.instance, effective);
            c.step = step;
            c.instance.effective_steps = effective;
            action = nextAction;
            this.recorder.event(
              "step_defined",
              { step, reason: "依据当前采集方式登记输出：" + args.reason },
              c.binding,
            );
          }
          validateCaptures(action, args.capture);
          for (const name of Object.keys(args.capture))
            if (c.result.observations.some((o) => o.output_name === name))
              throw new Error(
                "已有可信观察不能覆盖: " + name + "；只补采缺少的输出",
              );
          captures = structuredClone(args.capture);
        } else if (args.capture && Object.keys(args.capture).length) {
          throw new Error(
            "该步骤使用固定采集定义，调用test_capture({})，不要提供非空capture覆盖定义",
          );
        }
        if (
          !Object.keys(captures).some(
            (name) =>
              !c.result.observations.some((o) => o.output_name === name),
          )
        )
          throw new Error("本步骤已有观察，不能覆盖");
        const attempt: NonNullable<StepResult["capture_attempts"]>[number] = {
          capture: captures as Record<string, Capture>,
          reason: args.reason ?? "使用计划中的固定采集定义",
          started_at: new Date().toISOString(),
        };
        (c.result.capture_attempts ??= []).push(attempt);
        this.recorder.event("capture_configured", attempt, c.binding);
        this.save();
        try {
          await captureStep(
            this,
            this.recorder,
            this.run,
            { ...c.step, action: { ...action, capture: captures } },
            c.result,
            c.binding,
            exec,
          );
        } catch (error) {
          attempt.error = String(error);
          this.recorder.event(
            "capture_failed",
            { error: attempt.error },
            c.binding,
          );
          throw error;
        } finally {
          this.save();
        }
        return {
          observations: c.result.observations.map((o) => ({
            name: o.output_name,
            value: o.value,
          })),
          missing: action.completion_requirements.filter(
            (name) =>
              !c.result.observations.some((o) => o.output_name === name),
          ),
          next: "如有缺少输出，按实际页面修正后只补采缺少输出；完整后test_finish_step",
        };
      },
    );
    tool(
      "test_finish_step",
      "必要观察完整后结算本步骤并计算后续断言，返回下一动作。",
      empty,
      async (_, exec) => {
        const c = this.current;
        if (!c) throw new Error("没有当前步骤");
        this.requireSettled(exec);
        const pending = (c.step.checks ?? []).filter(
          (_, n) =>
            !c.instance.effective_steps.some(
              (s) =>
                s.step_id === `${c.step.step_id}_check_${n + 1}` && s.assertion,
            ),
        );
        if (pending.length)
          throw new Error("尚未绑定文字检查点: " + pending.join("；"));
        if (!c.step.action && !c.step.checks?.length)
          throw new Error("请先根据当前情况配置并完成本步骤");
        if (
          !(c.step.action?.completion_requirements ?? []).every((n) =>
            c.result.observations.some((o) => o.output_name === n),
          )
        )
          throw new Error("缺少必要观察；先完成动作并调用test_capture");
        if (
          c.step.action &&
          !c.step.action.completion_requirements.length &&
          !c.step.checks?.length &&
          !c.result.calls.some(
            (call) =>
              !call.name.startsWith("test_") &&
              call.finished_at &&
              !call.isError &&
              !call.name.endsWith("browser_close"),
          )
        )
          throw new Error("尚无本步骤实际动作或可信观察，不能只配置后宣布完成");
        this.finishStep("SUCCEEDED");
        this.save();
        await this.owner.preview.drain(this.run.suite_run_id);
        if (this.closed) throw new Error("测试已封存，录像结算不再推进步骤");
        this.advance();
        return this.state();
      },
    );
    tool(
      "test_fail_step",
      "当前动作无法完成时记录真实错误并进入后续可用步骤或清理，不伪造观察。",
      {
        type: "object",
        required: ["reason"],
        properties: { reason: { type: "string" } },
        additionalProperties: false,
      },
      (args, exec) => {
        this.requireSettled(exec);
        if (!this.current) throw new Error("没有当前步骤");
        this.finishStep("ERROR", args.reason);
        this.advance();
        return this.state();
      },
    );
    tool(
      "test_finish",
      "全部步骤及清理完成后生成静态报告，返回最终回复应使用的链接与保存位置。",
      empty,
      async (_, exec) => {
        this.requireSettled(exec);
        if (this.current || this.cursor < this.entries.length || !this.planned)
          throw new Error("测试尚未完成，请按test_current继续");
        await this.owner.preview.finishRun(this.run);
        if (this.closed) throw new Error("测试已封存，不能更改结果");
        return this.finish();
      },
    );
    tool(
      "test_api_get",
      "内部HTTP GET采集工具，仅供test_capture子调用；模型直接使用test_capture发送请求并保存可信响应。",
      {
        type: "object",
        required: ["url"],
        properties: { url: { type: "string" } },
        additionalProperties: false,
      },
      async (args, exec) => {
        const response = await fetch(args.url, {
          signal: exec.signal,
          redirect: "error",
        });
        return { status: response.status, body: await response.json() };
      },
    );
    tool(
      "test_propose_checkpoint",
      "追加具有现有冻结规则来源的必需断言，不能修改已有预期。",
      {
        type: "object",
        required: [
          "reason",
          "source_refs",
          "added_steps",
          "target_instance_ids",
          "insertion_boundary",
          "post_hoc",
        ],
        properties: {
          reason: { type: "string" },
          source_refs: { type: "array", items: { type: "object" } },
          added_steps: { type: "array", items: { type: "object" } },
          target_instance_ids: { type: "array", items: { type: "string" } },
          insertion_boundary: { type: "string" },
          post_hoc: { type: "boolean" },
        },
      },
      (args) => {
        // 先验证运行边界，再提交不可回滚的修订事件。
        const positions = new Map<string, number>();
        for (const id of args.target_instance_ids ?? []) {
          const position = this.entries.findIndex(
            (e, index) =>
              index >= this.cursor &&
              e.instance.case_run_id === id &&
              (args.insertion_boundary === "end"
                ? e.phase === "cleanup"
                : e.step.step_id === args.insertion_boundary),
          );
          if (position < 0) throw new Error("插入边界已执行或不存在");
          positions.set(id, position);
        }
        const revision = applyRevision(
          this.run,
          this.recorder,
          args,
          this.owner.config.maxRevisions,
        );
        for (const [id, position] of [...positions].sort(
          (a, b) => b[1] - a[1],
        )) {
          const instance = this.run.instances.find(
            (i) => i.case_run_id === id,
          )!;
          this.entries.splice(
            position,
            0,
            ...revision.added_steps.map((step) => ({
              instance,
              step,
              phase: "test" as const,
            })),
          );
        }
        this.save();
        return { accepted: true, revision: revision.revision };
      },
    );
    own(
      scope.on("session/event", (session, event) => {
        if (session.id !== this.id || this.closed) return;
        // 仅观察官方事件；不写入或重写宿主会话日志。
        this.recorder.event("native_session_event", {
          session_id: this.id,
          type: event.type,
        });
        if (event.type === "assistant/message" && this.announcement) {
          this.announcement.text += event.data.message.content
            .filter((block) => block.type === "text")
            .map((block) => (block as { text: string }).text)
            .join("\n");
          if (!this.missingAnnouncement().length) {
            this.announcement = undefined;
            this.recorder.event("plan_announced", { session_id: this.id });
          }
        }
        if (event.type === "tool/call") {
          try {
            this.bind(
              event.data.callId,
              event.data.name,
              JSON.parse(event.data.arguments || "{}"),
            );
          } catch {
            /* 原生工具管线处理无效参数。 */
          }
        }
        if (
          event.type === "user/message" &&
          event.data.source.kind === "user" &&
          !this.planned
        ) {
          const text = event.data.content
            .filter((b) => b.type === "text")
            .map((b) => (b as { text: string }).text)
            .join("\n");
          if (!this.review && this.planningQuestion)
            this.timer = setTimeout(
              () => this.stop("规划执行超时"),
              this.owner.config.stepTimeoutMs,
            );
          if (text !== this.task) this.task += "\n" + text;
          this.planningQuestion = false;
        }
        if (event.type === "turn/end")
          void this.turnEnded(event.data.reason.kind === "aborted").catch(
            (error) => this.emergency(error),
          );
      }),
    );
    own(
      scope.on("tools/pre-execute", async (exec, next) => {
        if (exec.agent?.id !== this.id) return next();
        this.pendingTools.add(exec.callId);
        this.bind(exec.callId, exec.name, exec.arguments);
        const decision = await next();
        if (
          decision.kind === "allow" &&
          this.current?.step.action?.approval &&
          !exec.name.startsWith("test_")
        )
          return { kind: "ask", reason: "当前冻结步骤需要审批" };
        return decision;
      }),
    );
    own(
      scope.on("tools/execute", async (exec, next) => {
        if (exec.agent?.id === this.id) {
          if (!this.planned && exec.name === "ask_user_question")
            this.planningQuestion = true;
          if (this.review && !this.planned && exec.name === "exit_plan_mode")
            this.reviewCall = exec.callId;
          const call = this.calls.get(exec.callId);
          if (
            exec.name === "mcp__playwright__browser_evaluate" &&
            !this.isTrusted(exec) &&
            this.current
          ) {
            const notes = (this.current.result.actual_operation_notes ??= []);
            const note = "存在直接页面分析脚本，其内部是否包含操作尚未逐项确认";
            if (!notes.includes(note)) notes.push(note);
          }
          if (call)
            this.recorder.event(
              "tool_dispatched",
              { call_id: exec.callId, name: exec.name },
              call.binding,
            );
          const operation = this.operations.get(exec.callId);
          if (
            operation &&
            !operation.dispatch_observed &&
            operation.state === "REGISTERED"
          ) {
            operation.dispatch_observed = true;
            operation.dispatched_at = new Date().toISOString();
            operation.state = "DISPATCHED";
            this.recorder.event(
              "operation_dispatched",
              operation,
              operation.binding,
              "operation-dispatched:" + exec.callId,
            );
            this.save();
          }
        }
        const result = await next();
        if (
          exec.agent?.id === this.id &&
          !this.planned &&
          exec.name === "ask_user_question" &&
          result.isError
        )
          this.planningQuestion = false;
        // 公开SDK允许around-dispatch返回规范失败；保留子调用的错误、内容和上下文。
        // 不能将子调用失败仅放进成功JSON，也不能覆盖外层管线自身的失败。
        return exec.name === "test_execute_operation" && !result.isError
          ? (this.delegatedFailures.get(exec.callId) ?? result)
          : result;
      }),
    );
    own(
      scope.on("tools/result", (exec, result) => {
        if (exec.agent?.id !== this.id) return;
        this.pendingTools.delete(exec.callId);
        this.settle(exec.callId, result, exec.signal.aborted);
        this.delegatedFailures.delete(exec.callId);
        if (exec.callId === this.reviewCall) {
          this.reviewCall = undefined;
          const approved =
            !result.isError &&
            (result.value as { approved?: boolean })?.approved === true;
          this.reviewDismissed = !approved;
          if (approved && !this.cancelled && !this.closed && this.draft) {
            this.recorder.event("plan_approved", { call_id: exec.callId });
            this.freeze(this.draft);
          }
        }
      }),
    );
    own(
      scope.tools.guard((exec) => {
        if (this.closed || this.reportReady) return;
        if (this.finishing && exec.agent?.id === this.id)
          return "正在等待本批 Node 使用权收尾，暂不派发新工具";
        if (this.recorder.failed) return "测试账本写入失败，停止工具派发";
        if (this.cancelled && !this.cleanupTurn)
          return "停止后禁止新业务动作，等待在途结算";
        if (exec.agent?.id !== this.id) return;
        if (
          /^mcp__.+__browser_/.test(exec.name) &&
          !exec.name.startsWith(this.browserPrefix)
        )
          return "本次测试只允许所选浏览器后端，不能切换浏览器";
        if (
          this.browser &&
          exec.name.startsWith(this.browser.prefix) &&
          this.current?.step.action?.capability !== "browser"
        )
          return "当前步骤不是浏览器步骤，不允许远程工具或领取 Node";
        if (
          this.browser &&
          this.current?.step.action?.capture &&
          Object.values(this.current.step.action.capture).every(
            (item) => item.kind === "browser_open",
          ) &&
          ![
            "test_capture",
            "test_current",
            "test_finish_step",
            "test_fail_step",
            "test_finish",
          ].includes(exec.name) &&
          !(
            exec.name === this.browser.prefix + "browser_start" &&
            this.isTrusted(exec)
          )
        )
          return "初始化阶段只允许test_capture申请并核对本次远程浏览器";
        if (
          this.browser &&
          ["browser_start", "browser_stop", "browser_capture"].some(
            (name) => exec.name === this.browser!.prefix + name,
          ) &&
          !this.isTrusted(exec)
        )
          return "远程生命周期和可信采集由test_capture控制";
        if (this.releaseStep() && !this.releaseAllowed(exec))
          return "当前只允许释放浏览器，请调用test_capture({})，取得释放证据后test_finish_step";
        if (
          (this.cleanupTurn || this.current?.phase === "cleanup") &&
          !this.cleanupAllowed(exec)
        )
          return "收尾轮次仅允许当前冻结清理步骤的预授权工具";
        if (
          !exec.parent &&
          this.pendingTools.size &&
          !this.pendingTools.has(exec.callId)
        )
          return "测试增强按步骤串行；请等待在途工具结算后重试";
        if (
          !this.planned &&
          ![
            "test_submit_plan",
            "test_current",
            "todo_write",
            "ask_user_question",
            ...(this.review ? ["exit_plan_mode"] : []),
          ].includes(exec.name)
        )
          return "规划阶段禁止执行：请仅根据用户描述提交业务计划，运行后再识别页面并调整操作";
        if (
          this.announcement &&
          !this.cancelled &&
          !["test_current", "ask_user_question", "todo_write"].includes(
            exec.name,
          )
        )
          return (
            "执行前请先补齐正常对话中的通报内容（无需用户确认）。缺少：" +
            JSON.stringify(this.missingAnnouncement()) +
            "\n完整计划如下：\n" +
            this.announcement.summary
          );
        if (this.review && !this.planned && exec.name === "exit_plan_mode") {
          if (!this.draft) return "请先test_submit_plan保存待审核草案";
          if (
            (exec.arguments as { plan?: string }).plan !== this.reviewMarkdown()
          )
            return "审核内容必须与草案一致；请将test_current返回的review_markdown原样传给exit_plan_mode";
        }
        if (
          this.current?.step.kind === "intent" &&
          ![
            "test_define_step",
            "test_bind_check",
            "test_current",
            "test_finish_step",
            "test_fail_step",
            "ask_user_question",
            "todo_write",
          ].includes(exec.name)
        )
          return "请在当前步骤调用test_define_step确定操作目标；不需要提前定义未来步骤";
        if (this.planned && exec.name === "test_api_get" && !exec.parent)
          return "HTTP请求由test_capture发送并记录，请勿预先直接请求；用一个response对象观察供多个断言引用";
        if (
          this.planned &&
          exec.name === "test_api_get" &&
          !this.isTrusted(exec)
        )
          return "HTTP请求仅由test_capture的受信子调用发送";
        if (
          this.planned &&
          operationTool(exec.name, exec.arguments) &&
          exec.name !== "mcp__playwright__browser_evaluate" &&
          !this.isTrusted(exec)
        )
          return "请使用test_execute_operation携带当前动作说明，再转交此浏览器工具；观察与可信采集保持原入口";
        if (
          this.planned &&
          operationTool(exec.name, exec.arguments) &&
          this.current?.step.action?.capability !== "browser"
        )
          return "当前步骤不允许浏览器业务操作";
        if (this.planned && typeof (exec.arguments as any)?.url === "string") {
          const url = (exec.arguments as any).url;
          if (
            url !== "about:blank" &&
            !this.current?.step.action?.allowed_targets.some(
              (t) => new URL(t).origin === new URL(url).origin,
            )
          )
            return "目标不在当前冻结步骤范围内";
        }
      }),
    );
    own(
      scope.on("agent/turn-stopping", ({ agent }) => {
        if (
          agent.id !== this.id ||
          this.closed ||
          this.reportReady ||
          (this.cancelled && !this.cleanupTurn)
        )
          return;
        if (!this.planned) {
          if (this.review && !this.reviewDismissed && this.nudges++ < 2)
            agent.steer(
              notice(
                "本次/test-plan必须通过原生审核卡片确认。请先test_submit_plan保存草案，再将review_markdown原样交给exit_plan_mode；不要只输出文字计划或等待口头同意。这些工具只记录计划和审核，不执行业务。缺少必要信息时正常追问。",
              ),
            );
          return;
        }
        if (this.nudges++ < 2)
          agent.steer(
            notice(
              "测试尚未结算。请按test_current继续；无法完成调用test_fail_step，完成后调用test_finish并给出报告链接。",
            ),
          );
      }),
    );
    own(
      this.owner.ctx.effect(() => () => {
        if (!this.closed) return this.shutdown();
      }),
    );
  }
  private missingAnnouncement(): string[] {
    if (!this.announcement) return [];
    const compact = (text: string) => text.replace(/[\s#*>`_]/g, "");
    return this.announcement.required.filter(
      (part) => !compact(this.announcement!.text).includes(compact(part)),
    );
  }
  private outputLanguage(): string {
    return testLanguage(
      this.owner.ctx,
      this.task + "\n" + (this.input?.instances[0]?.task ?? ""),
    );
  }
  async start(task: string): Promise<string> {
    if (this.input) this.recorder.json("input.json", this.input);
    this.save();
    if (!this.planned)
      this.timer = setTimeout(
        () => this.stop("规划执行超时"),
        this.owner.config.stepTimeoutMs,
      );
    this.agent.followup(
      createUserMessage({
        source: { kind: "user" },
        content: [{ type: "text", text: task }],
      }),
    );
    return this.review
      ? "已在当前对话进入plan模式；先规划并展示审核，用户同意后才执行测试。"
      : "测试已在当前对话启动；执行步骤、工具结果和最终报告将在本对话中显示。";
  }
  submit(input: unknown, trustedFile = false): unknown {
    if (this.planned) throw new Error("计划已冻结；不能替换预期");
    const plan = trustedFile
      ? parsePlan(input)
      : this.input
        ? parseBatchPlan(
            input,
            this.input,
            this.task,
            this.id,
            this.outputLanguage(),
            this.originalTask,
          )
        : parseTextPlan(
            input,
            this.task,
            this.id,
            this.originalTask,
            this.outputLanguage(),
          );
    if (this.timer) clearTimeout(this.timer);
    if (this.review) {
      this.draft = plan;
      this.reviewDismissed = false;
      this.recorder.event("plan_drafted", { plan });
      this.recorder.json("plan-draft.json", plan);
      this.save();
      return this.state();
    }
    this.freeze(plan);
    const summary = textReview(plan, false, this.outputLanguage());
    if (!trustedFile) {
      this.announcement = {
        summary,
        text: "",
        required: announcementParts(plan, this.outputLanguage()),
      };
    }
    return {
      ...this.state(),
      plan_summary: summary,
    };
  }
  private validateEffective(instance: CaseRun, steps: Step[]): void {
    const original = this.run.plan.cases.find(
      (c) => c.case_id === instance.case_id,
    )!;
    parsePlan({ ...this.run.plan, cases: [{ ...original, steps }] }, true);
  }
  private reviewMarkdown(): string {
    if (!this.draft) return "";
    return textReview(this.draft, true, this.outputLanguage());
  }
  private freeze(plan: SuiteRun["plan"]): unknown {
    if (this.timer) clearTimeout(this.timer);
    this.planned = true;
    this.nudges = 0;
    this.run.name = plan.name;
    this.run.plan = plan;
    this.run.instances = expand(plan);
    this.recorder.protect(plan);
    this.recorder.json("plan.json", plan);
    for (const instance of this.run.instances) {
      instance.session_id = this.id;
      instance.cleanup_session_id = this.id;
      const c = plan.cases.find((c) => c.case_id === instance.case_id)!;
      const browser = [...c.preconditions, ...c.steps, ...c.cleanup].some(
        (s) => s.action?.capability === "browser",
      );
      if (browser) {
        this.entries.push({
          instance,
          phase: "setup",
          step: this.initialStep(),
        });
      }
      this.entries.push(
        ...c.preconditions.map((step) => ({
          instance,
          step,
          phase: "setup" as const,
        })),
        ...instance.effective_steps.map((step) => ({
          instance,
          step,
          phase: "test" as const,
        })),
        ...c.cleanup.map((step) => ({
          instance,
          step,
          phase: "cleanup" as const,
        })),
      );
      if (
        browser &&
        !c.cleanup.some((s) =>
          Object.values(s.action?.capture ?? {}).some(
            (x) => x.kind === "browser_close",
          ),
        )
      )
        this.entries.push({
          instance,
          phase: "cleanup",
          step: closeStep("__close", "关闭并确认浏览器上下文释放"),
        });
    }
    this.owner.reports.select(this.run, "report.html", false);
    this.advance();
    return this.state();
  }
  private advance(): void {
    this.current = undefined;
    while (this.cursor < this.entries.length) {
      const e = this.entries[this.cursor++];
      e.instance.lifecycle = "RUNNING";
      e.instance.status = "RUNNING";
      const result: StepResult = {
        step_id: e.step.step_id,
        phase: e.phase,
        description: e.step.description,
        required: e.step.required,
        status: "RUNNING",
        started_at: new Date().toISOString(),
        duration_ms: 0,
        calls: [],
        observations: [],
        ...(e.phase === "cleanup" ? { cleanup_applicable: true } : {}),
      };
      const binding: Binding = {
        suite_run_id: this.run.suite_run_id,
        case_run_id: e.instance.case_run_id,
        phase: e.phase,
        step_id: e.step.step_id,
        attempt_id: "1",
      };
      e.instance.steps.push(result);
      this.current = { ...e, result, binding };
      this.recorder.event("step_started", { step: e.step }, binding);
      if (
        !this.cancelled &&
        e.phase === "setup" &&
        e.step.step_id === "__reset" &&
        !this.browser
      )
        e.instance.resources.browser_context = { id: this.id, state: "exists" };
      if (
        e.phase === "cleanup" &&
        e.step.run_if === "resource_exists" &&
        !["exists", "unknown"].includes(
          e.instance.resources[e.step.resource_ref!]?.state ?? "absent",
        )
      ) {
        result.cleanup_applicable = false;
        this.finishStep("SKIPPED", "资源不存在，无需清理");
        continue;
      }
      if (this.cancelled && e.phase !== "cleanup") {
        e.instance.cancelled = true;
        this.finishStep("SKIPPED", "用户停止");
        continue;
      }
      if (
        e.phase !== "cleanup" &&
        (e.instance.steps.some(
          (s) =>
            s.required &&
            s.phase !== "cleanup" &&
            ["FAIL", "ERROR", "INCONCLUSIVE", "BLOCKED"].includes(s.status),
        ) ||
          e.step.depends_on.some(
            (id) =>
              !e.instance.steps.some(
                (s) =>
                  s.step_id === id && ["SUCCEEDED", "PASS"].includes(s.status),
              ),
          ))
      ) {
        e.instance.blocked = true;
        this.finishStep("BLOCKED", "依赖未满足");
        continue;
      }
      if (e.step.assertion) {
        result.assertion = evaluate(e.step, e.instance);
        this.recorder.event("assertion_evaluated", result.assertion, binding);
        this.finishStep(result.assertion.status);
        continue;
      }
      this.mediaDeadline =
        e.phase === "cleanup"
          ? Date.now() + this.owner.config.cleanupTimeoutMs
          : undefined;
      this.timer = setTimeout(
        () => {
          this.recorder.event("step_timeout", {}, binding);
          e.instance.incomplete = true;
          e.instance.issues.push("步骤执行超时");
          this.stop("步骤执行超时");
        },
        e.phase === "cleanup"
          ? this.owner.config.cleanupTimeoutMs
          : this.owner.config.stepTimeoutMs,
      );
      break;
    }
    this.save();
  }
  private finishStep(status: StepResult["status"], reason?: string): void {
    if (!this.current) return;
    if (this.timer) clearTimeout(this.timer);
    const c = this.current;
    c.result.status = status;
    if (
      c.phase === "cleanup" &&
      status === "SUCCEEDED" &&
      Object.values(c.step.action?.capture ?? {}).some(
        (x) => x.kind === "browser_close",
      )
    ) {
      if (c.instance.resources.browser_context)
        c.instance.resources.browser_context.state = "absent";
    }
    if (reason) c.result.reason = reason;
    c.result.finished_at = new Date().toISOString();
    c.result.duration_ms = Date.now() - Date.parse(c.result.started_at);
    this.recorder.event("step_finished", c.result, c.binding);
    this.current = undefined;
    if (
      c.phase === "cleanup" &&
      this.releaseStep(c.step) &&
      !["SUCCEEDED", "SKIPPED"].includes(status) &&
      !this.cancelled
    ) {
      this.owner.quarantine(this.run, "浏览器释放失败，禁止后续业务");
      c.instance.incomplete = true;
      this.stop("浏览器释放失败，禁止后续业务");
    }
  }
  private publicLease() {
    if (!this.run.node_lease) return undefined;
    const { access_file: _privateFile, ...lease } = this.run.node_lease;
    return lease;
  }
  state() {
    const c = this.current;
    return {
      run_id: this.run.suite_run_id,
      session_id: this.id,
      ...(this.run.node_lease ? { node_lease: this.publicLease() } : {}),
      ...(this.browser
        ? {
            browser_backend: "runbridge",
            ...(this.browser.resource?.remote
              ? {
                  remote_browser: Object.fromEntries(
                    Object.entries(this.browser.resource.remote).filter(
                      ([key]) => key !== "access_file",
                    ),
                  ),
                }
              : {}),
          }
        : {}),
      ...(!this.planned && this.input ? { planning_input: this.input } : {}),
      phase: this.reportReady
        ? "finished"
        : this.finishing
          ? "cleanup"
          : this.planned
            ? this.cleanupTurn || c?.phase === "cleanup"
              ? "cleanup"
              : "executing"
            : this.draft
              ? "reviewing"
              : "planning",
      ...(this.review && !this.planned && this.draft
        ? { review_markdown: this.reviewMarkdown() }
        : {}),
      ...(this.announcement
        ? {
            plan_summary: this.announcement.summary,
            announcement_required:
              "先在正常对话完整输出plan_summary，再调用执行工具；无需用户确认",
          }
        : {}),
      current: c
        ? {
            instance: c.instance.case_run_id,
            step: c.step,
            checks: (c.step.checks ?? []).map((text, n) => ({
              check_index: n,
              text,
              bound: c.instance.effective_steps.some(
                (s) =>
                  s.step_id === `${c.step.step_id}_check_${n + 1}` &&
                  s.assertion,
              ),
            })),
            observations: c.instance.steps.flatMap((s) =>
              s.observations.map((o) => ({
                ref: `${s.step_id}.${o.output_name}`,
                value: o.value,
              })),
            ),
            inputs: Object.fromEntries(
              Object.entries(c.step.action?.inputs ?? {}).map(
                ([key, value]) => [
                  key,
                  value &&
                  typeof value === "object" &&
                  !Array.isArray(value) &&
                  typeof value.input_ref === "string"
                    ? field({ data: c.instance.data }, value.input_ref)
                    : value,
                ],
              ),
            ),
            phase: c.phase,
          }
        : null,
      assertions: this.run.instances.flatMap((i) =>
        i.steps.filter((s) => s.assertion).map((s) => s.assertion),
      ),
      next: !this.planned
        ? this.draft
          ? "将review_markdown原样传入exit_plan_mode的plan参数，由原生审核等待用户批准；修改时重新test_submit_plan"
          : "理解任务并提交test_submit_plan；信息不足时正常追问"
        : c
          ? this.releaseStep()
            ? "当前进入浏览器释放阶段：test_capture({})取得释放证据后test_finish_step；已完成检查保持冻结，随后按test_current进入下一实例或生成报告"
            : c.phase === "cleanup"
              ? "只完成当前冻结清理步骤及可信采集，再test_finish_step；已完成业务及检查保持冻结"
              : c.step.checks !== undefined
                ? "只执行当前文字步骤：test_define_step确定本步目标，观察操作后test_capture；逐项test_bind_check，最后test_finish_step"
                : "完成当前动作、test_capture、test_finish_step"
          : "调用test_finish生成报告并在回复中给出链接",
    };
  }
  presentation(): ProgressSnapshot {
    const phase: ProgressPhase =
      this.finishing || this.cleanupTurn || this.current?.phase === "cleanup"
        ? "cleanup"
        : this.cancelled
          ? "stopping"
          : this.planned
            ? "executing"
            : this.draft
              ? "reviewing"
              : "planning";
    return this.recorder.sanitize(
      projectProgress({
        run: this.run,
        plan: this.draft ?? this.run.plan,
        phase,
        ...(this.current
          ? {
              current: {
                case_run_id: this.current.instance.case_run_id,
                step_id: this.current.step.step_id,
              },
            }
          : {}),
        reportUrl: this.owner.reports.url(this.run.suite_run_id),
      }),
    ) as unknown as ProgressSnapshot;
  }
  private bind(id: string, name: string, args: unknown): void {
    if (!this.current || this.calls.has(id) || this.reportReady) return;
    const call: CallRecord = {
      call_id: id,
      binding: { ...this.current.binding },
      name,
      args_redacted: this.recorder.sanitize(args),
      started_at: new Date().toISOString(),
      body_started: "unknown",
    };
    this.calls.set(id, call);
    this.current.result.calls.push(call);
    this.recorder.event("tool_bound", call, call.binding, "bound:" + id);
  }
  private isTrusted(exec: Pick<ToolRunContext, "callId" | "parent">): boolean {
    return !!exec.parent && this.trustedCalls.get(exec.callId) === exec.parent;
  }
  private settle(
    id: string,
    result: ToolExecutionResult,
    aborted = false,
  ): void {
    const call = this.calls.get(id);
    if (!call || call.finished_at) return;
    if (this.closed || (this.reportReady && this.operations.has(id))) {
      this.recorder.event(
        "late_tool_result",
        { call_id: id, result },
        call.binding,
      );
      return;
    }
    call.finished_at = new Date().toISOString();
    call.isError = result.isError;
    call.result = this.recorder.sanitize(result);
    this.recorder.event("tool_finished", call, call.binding, "finished:" + id);
    const operation = this.operations.get(id);
    if (operation && ["REGISTERED", "DISPATCHED"].includes(operation.state)) {
      operation.finished_at = call.finished_at;
      const code = result.isError ? result.error?.info?.code : undefined;
      operation.state =
        !operation.dispatch_observed || code === "ABORTED_BEFORE_DISPATCH"
          ? "NOT_DISPATCHED"
          : code === "ABORTED" ||
              aborted ||
              this.browser?.outcome(id) === "OUTCOME_UNKNOWN"
            ? "UNKNOWN"
            : result.isError
              ? "ERROR"
              : "SUCCEEDED";
      if (result.isError)
        operation.reason = String(
          this.recorder.sanitize(
            result.error?.message ??
              result.content
                .filter((b) => b.type === "text")
                .map((b) => (b as { text: string }).text)
                .join("\n"),
          ),
        );
      this.recorder.event(
        "operation_finished",
        operation,
        operation.binding,
        "operation-finished:" + id,
      );
    }
    this.save();
    if (this.reportReady)
      writeReport(
        this.recorder.directory,
        this.recorder.sanitize(this.run) as unknown as SuiteRun,
      );
  }
  async call(
    name: string,
    args: unknown,
    parent: ToolRunContext,
    explanation?: Pick<ActualOperation, "description" | "description_source">,
  ) {
    const id = ToolCallId(randomUUID());
    this.bind(id, name, args);
    if (explanation && this.current) {
      const records = (this.current.result.actual_operations ??= []);
      const operation: ActualOperation = {
        operation_id: randomUUID(),
        order_in_step: records.length + 1,
        binding: { ...this.current.binding },
        description: String(this.recorder.sanitize(explanation.description)),
        description_source: explanation.description_source,
        parent_call_id: parent.callId,
        tool_call_id: id,
        granularity: compositeOperation(name, args) ? "composite" : "atomic",
        dispatch_observed: false,
        state: "REGISTERED",
        created_at: new Date().toISOString(),
      };
      records.push(operation);
      this.operations.set(id, operation);
      this.manualSource.record(operation, name, args, explanation.description);
      this.recorder.event("operation_registered", operation, operation.binding);
      this.recorder.event(
        "operation_linked",
        {
          operation_id: operation.operation_id,
          tool_call_id: id,
          parent_call_id: parent.callId,
        },
        operation.binding,
      );
      // 必需记录落盘后才进入原生派发；写入失败不能执行未记录动作。
      this.save();
    }
    this.trustedCalls.set(id, parent.token);
    try {
      const result = await this.agent.ctx.tools.execute({
        callId: id,
        rootCallId: parent.rootCallId,
        parent: parent.token,
        name,
        arguments: args,
        agent: this.agent,
        signal: parent.signal,
      });
      this.settle(id, result, parent.signal.aborted);
      if (this.closed) throw new Error("测试已封存，迟到结果不改变最终事实");
      return { callId: id, result };
    } finally {
      this.trustedCalls.delete(id);
    }
  }
  stop(reason = "用户停止"): void {
    if (this.closed || this.reportReady || this.finishing) return;
    this.cancelled = true;
    this.run.lifecycle = "CANCELLING";
    this.run.manifest.stop_reason = reason;
    if (reason !== "用户停止") this.run.incomplete = true;
    this.recorder.event("stop_requested", { session_id: this.id, reason });
    this.agent.cancel({ kind: "user" });
    this.armStopDeadline();
    if (this.agent.status === "idle")
      void this.turnEnded(true).catch((error) => this.emergency(error));
  }
  private async turnEnded(aborted: boolean): Promise<void> {
    if (this.closed || this.finalizing) return;
    this.finalizing = true;
    try {
      if (aborted) {
        this.cancelled = true;
        this.run.lifecycle = "CANCELLING";
      }
      // 事件表示原生轮次结束；whenIdle只用于确认同一Agent的在途操作已经排空。
      if (aborted) this.armStopDeadline();
      await this.agent.whenIdle();
      if (this.closed) return;
      if (this.stoppingTimer) clearTimeout(this.stoppingTimer);
      if (this.reportReady) {
        await this.dispose();
        return;
      }
      if (!aborted && !this.planned) {
        if (this.review || this.planningQuestion) {
          if (this.timer) clearTimeout(this.timer);
          return;
        }
        if (this.nudges++ === 0) {
          this.recorder.event("planning_retry_requested", {
            reason: "轮次结束但未提交计划",
          });
          this.agent.followup(
            notice(
              "本次测试尚未提交执行计划，业务没有开始。请按当前test_submit_plan工具Schema保存文字规划；文件用例按planning_input的每个instance_id提交，不要只回复文字分析。保留原文中的动作、输入和预期；提交后按test_current继续。缺少必要信息时使用ask_user_question。",
            ),
          );
          // 保留最初的规划计时，不因提醒重新获得完整预算。
          return;
        }
        if (this.timer) clearTimeout(this.timer);
        this.run.incomplete = true;
        this.run.manifest.stop_reason =
          "模型结束规划轮次但未提交有效计划，测试未执行";
      }
      if (aborted) {
        this.cancelled = true;
        this.run.lifecycle = "CANCELLING";
      }
      if (
        this.pendingTools.size ||
        [...this.calls.values()].some((c) => !c.finished_at)
      ) {
        this.owner.quarantine(this.run, "在途工具未结算");
        this.run.incomplete = true;
        await this.emergency("原生轮次结束后仍有未结算工具，不能启动清理");
        return;
      }
      if (this.cleanupTurn) {
        await this.emergency("清理轮次未正常完成");
        return;
      }
      if (this.current)
        this.finishStep(
          aborted ? "CANCELLED" : "ERROR",
          aborted ? "用户停止" : "模型结束轮次但未结算步骤",
        );
      this.cancelled = true;
      for (const i of this.run.instances) i.cancelled = aborted;
      if (!this.planned) {
        if (this.input) {
          // 未批准的批量计划也保留全部输入实例，不能缩成一个规划占位实例。
          this.run.manifest.plan_approved = false;
          this.run.plan = this.draft ?? {
            ...this.run.plan,
            planning: {
              original_task: this.originalTask,
              rationale: "规划未完成，未执行",
              input: structuredClone(this.input),
            },
            cases: this.input.instances.map((i) => ({
              case_id: i.id,
              name: `用例${i.case_number} · 数据行${i.data_row ?? "—"}（未执行）`,
              preconditions: [],
              steps: [],
              cleanup: [],
              datasets: [
                {
                  data_id: i.data_row ? `row_${i.data_row}` : "default",
                  inputs: { ...i.parameters },
                  expected: {},
                },
              ],
            })),
          };
          this.run.instances = expand(this.run.plan);
          for (const instance of this.run.instances) {
            instance.session_id = this.id;
            instance.cancelled = aborted;
          }
          this.recorder.json("plan.json", this.run.plan);
        } else {
          // 规划没有触碰外部环境，只记录未完成的规划实例，不派发清理工具。
          const instance = expand({
            ...this.run.plan,
            cases: [
              {
                case_id: "planning",
                name: "规划未完成",
                preconditions: [],
                steps: [],
                cleanup: [],
                datasets: [{ data_id: "default", inputs: {}, expected: {} }],
              },
            ],
          })[0]!;
          instance.session_id = this.id;
          instance.cancelled = aborted;
          this.run.instances.push(instance);
        }
      }
      this.cleanupTurn = true;
      this.nudges = 0;
      this.advance();
      if (!this.current) {
        await this.finish();
        await this.dispose();
        return;
      }
      this.agent.followup(
        notice(
          "测试已停止业务动作；在途工具已结算。现在仅执行test_current指定的冻结清理步骤（禁止业务步骤和新增目标）。按当前步骤完成清理、test_capture、test_finish_step，最后test_finish，并在正常回复中说明取消结果和报告链接。",
        ),
      );
    } finally {
      this.finalizing = false;
    }
  }
  private finish(): Promise<unknown> {
    return (this.finishing ??= this.finalize());
  }
  private async finalize(): Promise<unknown> {
    if (!this.reportReady) {
      if (this.timer) clearTimeout(this.timer);
      if (this.stoppingTimer) clearTimeout(this.stoppingTimer);
      try {
        await this.browser?.close();
      } catch {
        this.run.incomplete = true;
        this.run.manifest.node_lease_cleanup_error =
          "Node 使用权归还未获确认，请按原租约处理";
        this.owner.quarantine(this.run, "Node 使用权归还未获确认");
      }
      sealOperations(this.run, "测试已封存，在途操作未获得最终结果");
      for (const i of this.run.instances) {
        if (this.run.incomplete) {
          i.incomplete = true;
          i.issues.push(
            String(this.run.manifest.stop_reason ?? "运行未完整结算"),
          );
        }
        if (
          i.resources.browser_context?.state === "exists" ||
          (i.resources.browser_context?.remote &&
            i.resources.browser_context.state === "unknown")
        ) {
          i.resource_quarantined = true;
          this.owner.quarantine(this.run, "浏览器释放未获确认");
        }
        i.status = aggregate(i);
        i.lifecycle = "FINISHED";
      }
      this.run.lifecycle = "FINISHED";
      this.run.finished_at = new Date().toISOString();
      this.save();
      this.exportManualCases();
      writeReport(
        this.recorder.directory,
        this.recorder.sanitize(this.run) as unknown as SuiteRun,
      );
      this.owner.reports.select(this.run);
      this.reportReady = true;
    }
    return {
      statistics: statistics(this.run),
      stop_reason: this.run.manifest.stop_reason,
      assertions: this.state().assertions,
      steps: this.run.instances.map((i) => ({
        instance: i.case_run_id,
        status: i.status,
        steps: i.steps.map((s) => ({
          step: s.step_id,
          description: s.description,
          status: s.status,
          reason: s.reason,
          assertion: s.assertion,
        })),
      })),
      report: {
        path: join(this.recorder.directory, "report.html"),
        url: this.owner.reports.url(this.run.suite_run_id),
        markdown: `[查看测试报告](${this.owner.reports.url(this.run.suite_run_id)})`,
      },
      actual_steps: join(this.recorder.directory, "actual-steps.json"),
      manual_cases: join(this.recorder.directory, "manual-cases.md"),
      actual_steps_export_error: this.run.manifest.actual_steps_export_error,
      ...(this.run.node_lease ? { node_lease: this.publicLease() } : {}),
      message:
        "请在正常最终回复中提供以上统计、断言实际/预期、保存位置和Markdown报告链接。报告为静态HTML，可离线打开。",
    };
  }
  private requireSettled(exec: ToolRunContext): void {
    if ([...this.pendingTools].some((id) => id !== exec.callId))
      throw new Error("其他工具尚未结算");
  }
  private cleanupAllowed(
    exec: Pick<ToolRunContext, "name" | "parent" | "arguments" | "callId">,
  ): boolean {
    if (this.releaseStep()) return this.releaseAllowed(exec);
    if (
      [
        "test_capture",
        "test_current",
        "test_finish_step",
        "test_fail_step",
        "test_finish",
      ].includes(exec.name)
    )
      return true;
    const action =
      this.current?.phase === "cleanup" ? this.current.step.action : undefined;
    if (!action) return false;
    if (exec.name === "test_execute_operation") {
      const input = exec.arguments as {
        tool_name?: string;
        arguments?: unknown;
        arguments_json?: string;
      };
      let arguments_: unknown;
      try {
        arguments_ = nativeOperationArguments(input);
      } catch {
        return false;
      }
      return (
        !!input.tool_name &&
        operationTool(input.tool_name, arguments_) &&
        this.cleanupAllowed({ ...exec, name: input.tool_name })
      );
    }
    if (action.capability === "browser") {
      if (
        Object.values(action.capture ?? {}).every(
          (c) => c.kind === "browser_close",
        )
      )
        return this.isTrusted(exec) && exec.name === this.closeTool;
      return (
        exec.name.startsWith(this.browserPrefix) &&
        ![
          "mcp__playwright__browser_run_code",
          "mcp__playwright__browser_install",
        ].includes(exec.name)
      );
    }
    return action.capability === "api" && exec.name === "test_api_get";
  }
  private releaseStep(step = this.current?.step): boolean {
    const action = step?.action;
    const capture = Object.values(action?.capture ?? {});
    return (
      action?.capability === "browser" &&
      capture.length > 0 &&
      capture.every((item) => item.kind === "browser_close")
    );
  }
  private releaseAllowed(
    exec: Pick<ToolRunContext, "name" | "parent" | "callId">,
  ): boolean {
    return (
      [
        "test_capture",
        "test_current",
        "test_finish_step",
        "test_fail_step",
        "test_finish",
      ].includes(exec.name) ||
      (exec.name === this.closeTool && this.isTrusted(exec))
    );
  }
  private armStopDeadline(): void {
    if (this.stoppingTimer) return;
    this.stoppingTimer = setTimeout(() => {
      if (this.closed || this.finishing) return;
      this.owner.quarantine(this.run, "停止等待在途操作超时，禁止启动清理");
      void this.emergency(
        "在途操作未在取消宽限期内结算，请人工确认外部停止并重置环境",
      );
    }, this.owner.config.cancelGraceMs);
  }
  private exportManualCases(): void {
    try {
      writeManualCases(
        this.recorder.directory,
        this.recorder.sanitize(this.run) as unknown as SuiteRun,
      );
    } catch (error) {
      const message =
        "实际步骤文件导出失败；已保存的运行数据可通过报告重建重新生成：" +
        String(this.recorder.sanitize(String(error)));
      this.run.manifest.actual_steps_export_error = message;
      this.owner.ctx.logger?.warn(message);
      this.save();
    }
  }
  private save(): void {
    this.recorder.snapshot(this.run);
    this.manualSource.save(this.run);
    try {
      if (this.browser) {
        this.owner.preview.syncRemote(this.run, this.browser);
        return;
      }
      this.owner.preview.sync(this.run, {
        directory: this.recorder.directory,
        deadline: () =>
          Math.min(
            this.mediaDeadline ??
              (this.current
                ? Date.parse(this.current.result.started_at) +
                  this.owner.config.stepTimeoutMs
                : Infinity),
            Date.now() + this.owner.config.cleanupTimeoutMs,
          ),
        emit: (event, recording, evidence) => {
          try {
            if (this.closed || this.reportReady) return;
            const records = (this.run.recordings ??= []);
            const index = records.findIndex(
              (r) => r.recording_id === recording.recording_id,
            );
            if (index < 0) records.push(recording);
            else records[index] = recording;
            if (evidence) this.run.evidence.push(evidence);
            this.recorder.event(event, {
              recording,
              ...(evidence ? { evidence } : {}),
            });
            this.recorder.snapshot(this.run);
          } catch (error) {
            this.owner.ctx.logger.warn("保存录像记录失败：%s", String(error));
          }
        },
      });
    } catch (error) {
      this.owner.ctx.logger.warn("更新浏览器预览归属失败：%s", String(error));
    }
  }
  private async emergency(error: unknown): Promise<void> {
    this.mediaDeadline = Date.now();
    this.owner.preview.sealRecordings(
      this.run.suite_run_id,
      "测试紧急截止，视频收尾未获确认",
    );
    this.run.incomplete = true;
    if (this.current) this.finishStep("ERROR", String(error));
    for (const i of this.run.instances) {
      i.incomplete = true;
      i.issues.push(String(error));
    }
    try {
      await this.finish();
    } catch {
      this.owner.ctx.logger?.warn("测试报告封存失败，保留原记录与隔离供核查");
    } finally {
      await this.dispose();
    }
  }
  get disposing(): boolean {
    return !!this.disposal && !this.disposalDone;
  }
  dispose(): Promise<void> {
    if (this.disposal) return this.disposal;
    this.closed = true;
    if (this.timer) clearTimeout(this.timer);
    if (this.stoppingTimer) clearTimeout(this.stoppingTimer);
    for (const dispose of this.disposers.splice(0).reverse()) dispose();
    this.disposal = (async () => {
      try {
        await this.browser?.close();
      } catch {
        if (!this.reportReady) {
          this.run.incomplete = true;
          this.owner.quarantine(this.run, "Node 使用权归还未获确认");
          this.save();
        }
      }
      if (this.previousPlanMode !== undefined && !this.planned)
        await this.setPlanMode(this.previousPlanMode).catch((error) =>
          this.owner.ctx.logger?.warn("恢复计划模式失败: %s", String(error)),
        );
    })().finally(() => {
      this.disposalDone = true;
    });
    return this.disposal;
  }
  async shutdown(): Promise<void> {
    if (this.closed) return this.dispose();
    this.finalizing = true;
    this.agent.cancel({ kind: "user" });
    this.owner.quarantine(this.run, "插件卸载，需确认外部操作停止和环境重置");
    await this.emergency("插件卸载，测试中断；不再派发工具");
  }
}
