/** 设置页只读检查；不分配会话，不回传访问令牌或远程原始错误。 */
import { createHash } from "node:crypto";
import { resolve } from "node:path";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/client";
import {
  createRunBridgeClient,
  hubPath,
  readRunBridgeAccess,
  runbridgeResult,
} from "./runbridge.js";
import { field } from "./contracts.js";
import { readRunBridgeHubCredentials } from "./runbridge-access.js";
import {
  queryNodeLease,
  readNodeCatalog,
  RunBridgeHttpError,
  type NodeLeaseState,
} from "./runbridge-lease.js";

export interface RunBridgeFileInfo {
  hub_url: string;
  mcp_url: string;
  node_id: string;
  grant_id?: string;
  expires_at?: string;
  revision: string;
}
export interface RunBridgeResourceInfo {
  resource_id: string;
  readiness: string;
  occupancy: string;
}
export interface RunBridgeSettingsResult {
  ok: boolean;
  code: string;
  message: string;
  file?: RunBridgeFileInfo;
  hub_connected?: boolean;
  node_status?: string;
  resources?: RunBridgeResourceInfo[];
  checked_at?: string;
  node_lease?: NodeLeaseState;
  pool_lease?: { state: string; claimable: boolean };
}

export interface RunBridgeSettingsInput {
  accessFile: string;
  resourceId: string;
  connect: boolean;
  connectionSource?: "access-file" | "hub";
  hubFile?: string;
  nodeId?: string;
}

function managedResources(node: any): RunBridgeResourceInfo[] {
  return (
    Array.isArray(node?.capabilities?.resources)
      ? node.capabilities.resources
      : []
  )
    .filter(
      (r: any) =>
        r.kind === "MANAGED_CHROMIUM" &&
        /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/.test(r.resource_id),
    )
    .map((r: any) => ({
      resource_id: r.resource_id,
      readiness: [
        "READY",
        "NEEDS_PROBE",
        "NEEDS_AUTHORIZATION",
        "UNAVAILABLE",
      ].includes(r.readiness)
        ? r.readiness
        : "UNAVAILABLE",
      occupancy: ["FREE", "BUSY", "UNKNOWN"].includes(r.occupancy)
        ? r.occupancy
        : "UNKNOWN",
    }));
}

async function checkHubSettings(
  workspace: string,
  input: RunBridgeSettingsInput,
  signal: AbortSignal,
): Promise<RunBridgeSettingsResult> {
  let credentials: ReturnType<typeof readRunBridgeHubCredentials>;
  try {
    if (!input.hubFile?.trim())
      throw new Error("请填写 DSH 运行机器上的 Hub 认证文件路径。");
    credentials = readRunBridgeHubCredentials(
      resolve(workspace, input.hubFile),
    );
  } catch (error) {
    return {
      ok: false,
      code: "ACCESS_FILE_INVALID",
      message: (error as Error).message,
    };
  }
  if (!/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/.test(input.nodeId ?? ""))
    return {
      ok: false,
      code: "NODE_ID_INVALID",
      message: "请填写有效的目标 Node ID。",
    };
  const file: RunBridgeFileInfo = {
    hub_url: credentials.hub_url,
    mcp_url: hubPath(credentials.hub_url, "/mcp").href,
    node_id: input.nodeId!,
    revision: createHash("sha256")
      .update(JSON.stringify([credentials, input.nodeId]))
      .digest("hex"),
  };
  if (!input.connect)
    return {
      ok: true,
      code: "FILE_VALID",
      message: "Hub 认证文件已解析；尚未检测目录，也未领取 Node。",
      file,
    };
  try {
    const { node } = await readNodeCatalog(credentials, input.nodeId!, signal);
    const resources = managedResources(node);
    const pool = {
      state: ["UNCLAIMED", "HELD", "RELEASING", "QUARANTINED"].includes(
        node.lease?.state,
      )
        ? node.lease.state
        : "UNKNOWN",
      claimable: node.lease?.claimable === true,
    };
    const ready =
      node.connection_status === "ONLINE" &&
      !node.capabilities_stale &&
      pool.claimable &&
      resources.some(
        (r) =>
          r.resource_id === input.resourceId &&
          r.readiness === "READY" &&
          r.occupancy === "FREE",
      );
    return {
      ok: ready,
      code: ready ? "HUB_CATALOG_READY" : "NODE_NOT_CLAIMABLE",
      message: ready
        ? "Hub 申请凭据与只读工具目录可用；检测没有领取 Node 或建立 MCP 执行连接。"
        : "Hub 目录可达，目标 Node 的使用权或浏览器资源当前不可领取；检测没有改变占用。",
      file,
      hub_connected: true,
      node_status: String(node.connection_status ?? "UNKNOWN"),
      resources,
      pool_lease: pool,
      checked_at: new Date().toISOString(),
    };
  } catch (error) {
    return {
      ok: false,
      code: signal.aborted
        ? "CHECK_CANCELLED"
        : error instanceof RunBridgeHttpError
          ? error.code
          : "HUB_UNAVAILABLE",
      message: signal.aborted
        ? "检测已取消。"
        : "无法验证 Hub 申请凭据与节点目录，请核对地址、凭据、节点及服务版本。",
      file,
      checked_at: new Date().toISOString(),
    };
  }
}

export async function checkRunBridgeSettings(
  workspace: string,
  input: RunBridgeSettingsInput,
  signal: AbortSignal,
): Promise<RunBridgeSettingsResult> {
  if (input.connectionSource === "hub")
    return checkHubSettings(workspace, input, signal);
  let access: ReturnType<typeof readRunBridgeAccess>;
  try {
    if (!input.accessFile.trim())
      throw new Error("请填写 DSH 运行机器上的访问 YAML 或 JSON 文件路径。");
    access = readRunBridgeAccess(resolve(workspace, input.accessFile));
  } catch (error) {
    return {
      ok: false,
      code: "ACCESS_FILE_INVALID",
      message: (error as Error).message,
    };
  }
  const expires =
    typeof access.expires_at === "string" &&
    Number.isFinite(Date.parse(access.expires_at))
      ? access.expires_at
      : undefined;
  const file: RunBridgeFileInfo = {
    hub_url: access.hub_url,
    mcp_url: hubPath(access.hub_url, "/mcp").href,
    node_id: access.node_id,
    grant_id: access.grant_id,
    ...(expires ? { expires_at: expires } : {}),
    revision: createHash("sha256").update(JSON.stringify(access)).digest("hex"),
  };
  if (!input.connect)
    return {
      ok: true,
      code: "FILE_VALID",
      message: "文件格式已通过，连接尚未检测。",
      file,
    };
  const client = createRunBridgeClient();
  const deadline = AbortSignal.any([signal, AbortSignal.timeout(10000)]);
  let cancel: () => void = () => {};
  let hub = false;
  let lease: NodeLeaseState | undefined;
  const done = (
    ok: boolean,
    code: string,
    message: string,
    details: Partial<RunBridgeSettingsResult> = {},
  ): RunBridgeSettingsResult => ({
    ok,
    code,
    message,
    file,
    hub_connected: hub,
    checked_at: new Date().toISOString(),
    ...(lease ? { node_lease: lease } : {}),
    ...details,
  });
  try {
    return await Promise.race([
      (async () => {
        deadline.throwIfAborted();
        lease = await queryNodeLease(access, deadline);
        hub = true;
        if (lease.state !== "HELD")
          return done(
            false,
            "NODE_LEASE_INACTIVE",
            "这份 Node 使用权已失效或正在回收，不能继续执行；请重新领取或使用 Hub 自动模式。",
          );
        await client.connect(
          new StreamableHTTPClientTransport(new URL(file.mcp_url), {
            requestInit: {
              headers: { Authorization: `Bearer ${access.access_token}` },
            },
          }),
        );
        deadline.throwIfAborted();
        const list = await client.listTools();
        deadline.throwIfAborted();
        hub = true;
        if (
          ![
            "node_inspect",
            "browser_start",
            "browser_stop",
            "browser_capture",
            "browser_status",
          ].every((name) => list.tools.some((t) => t.name === name))
        )
          return done(
            false,
            "MCP_TOOLS_MISSING",
            "Hub 已连接，但缺少所需浏览器工具，请检查 MCP 启用状态和服务版本。",
          );
        const result = await client.callTool(
          { name: "node_inspect", arguments: { node_id: access.node_id } },
          { signal: deadline, timeout: 5000 },
        );
        deadline.throwIfAborted();
        const node = runbridgeResult(result);
        if (result.isError) {
          const code = String(node.code);
          return done(
            false,
            "NODE_QUERY_DENIED",
            code === "NODE_NOT_FOUND"
              ? "Hub 已连接，但授权节点不存在，请核对访问文件。"
              : "Hub 已连接，但节点查询被拒绝，请核对许可是否过期、撤销或不包含目标节点。",
          );
        }
        if (
          node.node_id !== access.node_id ||
          !["ONLINE", "OFFLINE", "PREPARING"].includes(node.connection_status)
        )
          return done(
            false,
            "NODE_RESULT_INVALID",
            "Hub 返回的节点身份或状态无效，请核对服务版本。",
          );
        const resources = managedResources(node);
        const details = { node_status: node.connection_status, resources };
        if (node.connection_status !== "ONLINE")
          return done(
            false,
            "NODE_OFFLINE",
            "Hub 已连接，节点尚未在线。请让 Node 所有者检查节点服务。",
            details,
          );
        if (node.capabilities_stale)
          return done(
            false,
            "CAPABILITIES_STALE",
            "Hub 已连接，节点能力快照已过期，请等待节点重新上报。",
            details,
          );
        const resource = resources.find(
          (r) => r.resource_id === input.resourceId,
        );
        if (!resource)
          return done(
            false,
            "RESOURCE_NOT_FOUND",
            "节点已在线，但没有找到所选受管理浏览器资源，请核对资源 ID。",
            details,
          );
        if (resource.readiness !== "READY")
          return done(
            false,
            "RESOURCE_NOT_READY",
            "节点已在线，但所选浏览器资源尚未就绪。",
            details,
          );
        if (resource.occupancy !== "FREE")
          return done(
            false,
            "RESOURCE_BUSY",
            "连接检测通过，但浏览器资源被占用或占用状态未知，请稍后再试。",
            details,
          );
        return done(
          true,
          "CONNECTION_READY",
          "连接检测通过，所选浏览器资源当前可用；检测未启动浏览器。",
          details,
        );
      })(),
      new Promise<never>((_resolve, reject) => {
        cancel = () => reject(deadline.reason);
        if (deadline.aborted) cancel();
        else deadline.addEventListener("abort", cancel, { once: true });
      }),
    ]);
  } catch (error) {
    const status =
      error instanceof RunBridgeHttpError
        ? error.status
        : Number(field(error, "data.status"));
    return done(
      false,
      signal.aborted
        ? "CHECK_CANCELLED"
        : deadline.aborted
          ? "CHECK_TIMEOUT"
          : [401, 403].includes(status)
            ? "ACCESS_DENIED"
            : status === 404
              ? "MCP_NOT_FOUND"
              : "HUB_UNAVAILABLE",
      signal.aborted
        ? "检测已取消。"
        : deadline.aborted
          ? "连接检测超时，请检查 Hub 地址、网络和服务状态。"
          : [401, 403].includes(status)
            ? "访问许可被拒绝，请核对令牌、有效期及 Hub 允许的访问来源。"
            : status === 404
              ? "未找到 MCP 入口，请核对 Hub 基址并确认已启用 /mcp。"
              : "无法完成 Hub MCP 检测，请核对地址、网络、服务和版本。",
    );
  } finally {
    deadline.removeEventListener("abort", cancel);
    await client.close().catch(() => {});
  }
}
