/** 隔离提示与用户确认后的资源恢复；时间超限只说明可能卡住。 */
import type { Agent } from "@deepseek-ai/dsh-agent";
import { ToolCallId } from "@deepseek-ai/dsh-llm/brand";
import { createHash, randomUUID } from "node:crypto";
import { existsSync, readFileSync, unlinkSync } from "node:fs";
import { join, resolve } from "node:path";
import type { SuiteRun } from "./contracts.js";
import { atomicJson } from "./recorder.js";
import {
  RunBridge,
  runbridgeResult,
  remoteReleaseConfirmed,
} from "./runbridge.js";
import { browserPreferenceDefaults } from "./browser-preferences.js";
import { readRunBridgeAccess } from "./runbridge-access.js";
import { NodeLease } from "./runbridge-lease.js";

export interface QuarantineState {
  token: string;
  run_id?: string;
  reason: string;
  created_at?: string;
  elapsed_ms?: number;
  timeout_ms: number;
  overdue: boolean;
  can_recover: boolean;
  unavailable_reason?: string;
  browser_backend?: "playwright" | "runbridge";
}
export interface RecoverySnapshot {
  quarantine: QuarantineState | null;
  recovering: boolean;
  last_error?: string;
}
interface Marker {
  created_at?: string;
  details?: { run_id?: string; reason?: string };
}

export class RecoveryManager {
  busy = false;
  private lastError?: string;
  private cancelPending?: () => void;
  private readonly path: string;
  constructor(
    private readonly outputRoot: string,
    private readonly timeoutMs: number,
    private readonly active: () => boolean,
    private readonly stopPreview: () => Promise<void>,
  ) {
    this.path = join(outputRoot, "quarantine.json");
  }

  private read(): { raw: string; marker: Marker } | undefined {
    if (!existsSync(this.path)) return;
    const raw = readFileSync(this.path, "utf8");
    try {
      const value = JSON.parse(raw);
      return { raw, marker: value && typeof value === "object" ? value : {} };
    } catch {
      return { raw, marker: {} };
    }
  }
  private token(raw: string): string {
    return createHash("sha256").update(raw).digest("hex");
  }
  status(now = Date.now()): RecoverySnapshot {
    const current = this.read();
    if (!current) return { quarantine: null, recovering: this.busy };
    const id = current.marker.details?.run_id;
    const created = current.marker.created_at;
    const timestamp = typeof created === "string" ? Date.parse(created) : NaN;
    const validTime = Number.isFinite(timestamp) && timestamp <= now;
    const validId = typeof id === "string" && /^run-[\w-]+$/.test(id);
    let browser = false;
    let missingLeaseCredentials = false;
    let backend: "playwright" | "runbridge" | undefined;
    if (validId) {
      try {
        const run = JSON.parse(
          readFileSync(join(this.outputRoot, id, "results.json"), "utf8"),
        ) as SuiteRun;
        missingLeaseCredentials =
          !!run.node_lease &&
          !(run.node_lease.grant_id && run.node_lease.access_file);
        browser =
          run.suite_run_id === id &&
          (!!(run.node_lease?.grant_id && run.node_lease.access_file) ||
            run.instances.some(
              (instance) =>
                instance.resources.browser_context?.state === "exists" ||
                (instance.resources.browser_context?.remote &&
                  instance.resources.browser_context.state === "unknown"),
            ));
        backend =
          run.node_lease ||
          run.instances.some(
            (instance) => instance.resources.browser_context?.remote,
          )
            ? "runbridge"
            : "playwright";
      } catch {
        /* 缺少资源归属时保留手工处置入口。 */
      }
    }
    const unavailable = this.busy
      ? "正在处理释放，请等待结果。"
      : this.active()
        ? "当前测试尚未结束，请先停止测试并等待收尾。"
        : !validTime || !validId
          ? "隔离记录或时间异常，请核实后在设置页提交处置证据。"
          : missingLeaseCredentials
            ? "原 Node 领取没有取得可恢复的节点令牌，请由 Hub 维护者核查后提交处置证据。"
            : !browser
              ? "未能确认浏览器资源归属，请核实外部环境后在设置页提交处置证据。"
              : undefined;
    return {
      quarantine: {
        token: this.token(current.raw),
        ...(backend ? { browser_backend: backend } : {}),
        ...(validId ? { run_id: id } : {}),
        reason:
          typeof current.marker.details?.reason === "string"
            ? current.marker.details.reason
            : "隔离记录无法完整读取",
        ...(validTime
          ? { created_at: created, elapsed_ms: now - timestamp }
          : {}),
        timeout_ms: this.timeoutMs,
        overdue: validTime && now - timestamp >= this.timeoutMs,
        can_recover: unavailable === undefined,
        ...(unavailable ? { unavailable_reason: unavailable } : {}),
      },
      recovering: this.busy,
      ...(this.lastError ? { last_error: this.lastError } : {}),
    };
  }
  mark(run: SuiteRun, reason: string): void {
    const previous = this.read()?.marker;
    if (previous?.details?.run_id !== run.suite_run_id)
      this.lastError = undefined;
    atomicJson(this.path, {
      created_at:
        previous?.details?.run_id === run.suite_run_id
          ? (previous.created_at ?? new Date().toISOString())
          : new Date().toISOString(),
      details: { run_id: run.suite_run_id, reason },
    });
  }
  private ensureIdle(): void {
    if (this.busy || this.active())
      throw new Error("活动测试或释放操作尚未结束，不能解除隔离");
  }
  cancel(): void {
    this.cancelPending?.();
  }
  private commit(token: string, proof: unknown): void {
    const current = this.read();
    if (!current || this.token(current.raw) !== token)
      throw new Error("隔离状态已变化，请重新查看并确认，未解除新的隔离");
    atomicJson(join(this.outputRoot, "release-" + randomUUID() + ".json"), {
      quarantine: current.marker,
      proof,
      released_at: new Date().toISOString(),
    });
    unlinkSync(this.path);
    this.lastError = undefined;
  }
  release(evidenceFile: string, token?: string): void {
    this.ensureIdle();
    const proof = JSON.parse(readFileSync(evidenceFile, "utf8"));
    if (
      proof.external_stopped !== true ||
      proof.environment_reset !== true ||
      !proof.operator ||
      !proof.details ||
      !proof.evidence
    )
      throw new Error("需提供外部停止、环境重置、操作者与处置证据");
    const current = this.read();
    if (!current) throw new Error("当前没有需要解除的隔离");
    JSON.parse(current.raw);
    this.commit(token ?? this.token(current.raw), proof);
  }

  async recover(
    agent: Agent,
    token: string,
    signal: AbortSignal,
  ): Promise<string> {
    this.ensureIdle();
    if (agent.status !== "idle")
      throw new Error("请等待当前对话轮次结束后再处理释放");
    const state = this.status().quarantine;
    if (!state || state.token !== token)
      throw new Error("隔离状态已变化，请重新查看并确认");
    if (!state.can_recover) throw new Error(state.unavailable_reason);
    if (signal.aborted) throw new Error("释放已取消，隔离仍保留");
    const saved = JSON.parse(
      readFileSync(
        join(this.outputRoot, state.run_id!, "results.json"),
        "utf8",
      ),
    ) as SuiteRun;
    if (saved.node_lease) return this.recoverNodeLease(saved, token, signal);
    const resource = saved.instances
      .map((instance) => instance.resources.browser_context)
      .find(
        (item) => item?.remote && ["exists", "unknown"].includes(item.state),
      );
    let remote: RunBridge | undefined;
    let unregister: (() => void) | undefined;
    const name = resource
      ? "mcp__runbridge__browser_stop"
      : "mcp__playwright__browser_close";
    if (resource) {
      if (!resource.remote?.access_file)
        throw new Error(
          "远程恢复记录缺少原私有访问文件，请提交所有者的处置证据",
        );
      remote = new RunBridge(
        {
          ...browserPreferenceDefaults,
          backend: "runbridge",
          accessFile: resource.remote.access_file,
          resourceId: resource.remote.resource_id,
          previewEnabled: false,
        },
        process.cwd(),
      );
      remote.restore(resource);
      this.busy = true;
      try {
        await remote.connect();
        unregister = remote.register(agent.ctx, ["browser_stop"]);
      } catch (error) {
        this.busy = false;
        await remote.close();
        throw error;
      }
    }
    if (!remote && !agent.ctx.tools.get(name, agent))
      throw new Error(
        "当前没有可用的 Playwright 关闭工具，请恢复 MCP 连接后重试，或在设置页提交实际处置证据",
      );
    this.busy = true;
    this.lastError = undefined;
    const controller = new AbortController();
    const callId = ToolCallId(randomUUID());
    const startedAt = new Date().toISOString();
    let timer: ReturnType<typeof setTimeout>;
    let abort!: () => void;
    const interrupted = new Promise<never>((_resolve, reject) => {
      abort = () => {
        controller.abort("释放已取消");
        reject(new Error("释放已取消，隔离仍保留；等待在途关闭操作结算"));
      };
      signal.addEventListener("abort", abort, { once: true });
      timer = setTimeout(() => {
        controller.abort("释放操作超时");
        reject(
          new Error(
            "释放操作超时，浏览器状态仍未获确认，隔离仍保留；请检查 MCP 连接并等待在途操作结算",
          ),
        );
      }, this.timeoutMs);
    });
    this.cancelPending = abort;
    const operation = (async () => {
      const result = await agent.ctx.tools.execute({
        callId,
        name,
        arguments: {},
        agent,
        signal: controller.signal,
      });
      if (controller.signal.aborted)
        throw new Error("释放未在期限内确认，隔离仍保留");
      if (result.isError)
        throw new Error(
          "浏览器关闭未成功（可能审批被拒绝或连接失败），隔离仍保留",
        );
      const remoteProof = remote ? runbridgeResult(result.value) : undefined;
      if (remote && !remoteReleaseConfirmed(remoteProof, remote.resource))
        throw new Error("远程会话清理未确认，隔离仍保留");
      await remote?.close();
      await this.stopPreview();
      if (controller.signal.aborted)
        throw new Error("释放未在期限内确认，隔离仍保留");
      this.commit(token, {
        operator: "DSH 页面确认的操作者",
        external_stopped: true,
        environment_reset: true,
        details:
          remoteProof?.request && !remoteProof.session
            ? "用户确认旧测试及外部操作已停止；原许可核对确认本次请求未分配浏览器，并停止本插件预览。旧测试结果保持原样。"
            : "用户确认旧测试及外部操作已停止；原生工具关闭测试专用浏览器，并停止本插件预览。旧测试结果保持原样。",
        evidence: {
          method: "confirmed-browser-recovery",
          session_id: agent.id,
          tool: name,
          call_id: callId,
          started_at: startedAt,
          finished_at: new Date().toISOString(),
          browser_close_is_error: false,
          ...(remote?.lease.record
            ? {
                node_lease: Object.fromEntries(
                  Object.entries(remote.lease.record).filter(
                    ([key]) => key !== "access_file",
                  ),
                ),
              }
            : {}),
          ...(remoteProof?.session
            ? { remote_session: remoteProof.session }
            : {}),
          ...(remoteProof?.request
            ? { remote_request: remoteProof.request }
            : {}),
          preview_stopped: true,
        },
      });
      return "测试环境已释放。请重新发送原测试命令；旧测试结果未修改。";
    })().finally(async () => {
      unregister?.();
      await remote?.close().catch(() => {});
      clearTimeout(timer);
      signal.removeEventListener("abort", abort);
      this.busy = false;
      this.cancelPending = undefined;
    });
    try {
      return await Promise.race([operation, interrupted]);
    } catch (error) {
      this.lastError = error instanceof Error ? error.message : String(error);
      throw error;
    }
  }

  /** 节点租约统一回收负责原租约下遗留会话，不用新许可接管旧资源。 */
  private async recoverNodeLease(
    saved: SuiteRun,
    token: string,
    signal: AbortSignal,
  ): Promise<string> {
    const original = saved.node_lease!;
    if (!original.grant_id || !original.access_file)
      throw new Error(
        "原 Node 领取缺少执行令牌，需由 Hub 维护者核查后提交处置证据",
      );
    const access = readRunBridgeAccess(original.access_file);
    if (
      access.hub_url !== original.hub_url ||
      access.node_id !== original.node_id ||
      access.grant_id !== original.grant_id
    )
      throw new Error("访问文件与原 Node 租约不一致，不能使用新许可解除隔离");
    const lease = new NodeLease({
      kind: "access-file",
      access,
      file: original.access_file,
    });
    const controller = new AbortController();
    const deadline = AbortSignal.any([
      signal,
      controller.signal,
      AbortSignal.timeout(this.timeoutMs),
    ]);
    this.busy = true;
    this.lastError = undefined;
    this.cancelPending = () => controller.abort();
    const started = new Date().toISOString();
    try {
      await lease.inspectExisting(deadline);
      await lease.release(this.timeoutMs, deadline);
      deadline.throwIfAborted();
      await this.stopPreview();
      deadline.throwIfAborted();
      const { access_file: _privateFile, ...proof } = lease.record!;
      this.commit(token, {
        operator: "DSH 页面确认的操作者",
        external_stopped: true,
        environment_reset: true,
        details:
          "原节点令牌核对确认原租约 RELEASED 且清理 COMPLETE；停止预览，旧业务断言与 UNKNOWN 记录保持原样。",
        evidence: {
          method: "confirmed-node-lease-recovery",
          started_at: started,
          finished_at: new Date().toISOString(),
          node_lease: proof,
          preview_stopped: true,
        },
      });
      if (
        original.source === "hub" &&
        resolve(original.access_file) ===
          resolve(
            this.outputRoot,
            ".runbridge-access",
            saved.suite_run_id + ".json",
          )
      ) {
        try {
          unlinkSync(original.access_file);
        } catch {
          /* 已确认归还；本机文件回收失败不更改原结果。 */
        }
      }
      return "原 Node 使用权已确认归还。请重新发送测试命令；旧测试结果未修改。";
    } catch (error) {
      this.lastError = deadline.aborted
        ? "节点归还已取消或超时，隔离仍保留"
        : error instanceof Error
          ? error.message
          : "节点归还未获确认，隔离仍保留";
      throw new Error(this.lastError);
    } finally {
      this.busy = false;
      this.cancelPending = undefined;
    }
  }
}
