import { afterEach, expect, it, vi } from "vitest";
import { mkdtempSync, readFileSync, rmSync, existsSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { NativeTests } from "../../src/native-test.js";
import { sample } from "../fixtures/plan.js";
import { rebuild } from "../../src/recorder.js";
import { projectActualCase } from "../../src/actual-operations.js";
import { ManualSource } from "../../src/manual-source.js";

const cleanups: (() => void | Promise<void>)[] = [];
afterEach(async () => {
  for (const cleanup of cleanups.splice(0)) await cleanup();
  vi.useRealTimers();
});
// 生命周期替身只驱动官方公开接口；真实宿主与模型在网页验收中单独验证。
function setup(value = 3, preparePreview?: () => Promise<void>) {
  const root = mkdtempSync(join(tmpdir(), "native-test-"));
  const events = new Map<string, Set<Function>>();
  const definitions = new Map<string, any>();
  const guards = new Set<Function>();
  const sections = new Set<unknown>();
  const followups: any[] = [];
  const toolNames: string[] = [];
  const dispatched: string[] = [];
  let domResult: any = { values: { likes: value } };
  let sequence = 0;
  let approval = "allow";
  const on = (name: string, fn: Function) => {
    const set = events.get(name) ?? new Set();
    set.add(fn);
    events.set(name, set);
    return () => set.delete(fn);
  };
  const emit = async (name: string, ...args: any[]) => {
    for (const fn of [...(events.get(name) ?? [])]) await fn(...args);
  };
  const waterfall = async (name: string, exec: any, last: () => any) => {
    const fns = [...(events.get(name) ?? [])];
    const next = (n: number): any =>
      fns[n] ? fns[n](exec, () => next(n + 1)) : last();
    return next(0);
  };
  const agent: any = {
    id: "origin",
    status: "idle",
    followup: vi.fn((message: unknown) => {
      followups.push(message);
      agent.status = "running";
    }),
    steer: vi.fn(),
    cancel: vi.fn(),
    whenIdle: vi.fn(async () => {}),
  };
  const execute = async (exec: any) => {
    const full = {
      callId: `call-${++sequence}`,
      signal: new AbortController().signal,
      agent,
      arguments: {},
      ...exec,
    };
    full.rootCallId ??= full.callId;
    full.token = {};
    const contexts: unknown[] = [];
    let concludesTurn = false;
    full.deferContext = (context: unknown) => contexts.push(context);
    full.concludeTurn = () => {
      concludesTurn = true;
    };
    toolNames.push(full.name);
    await emit(
      "session/event",
      { id: agent.id },
      {
        type: "tool/call",
        data: {
          callId: full.callId,
          name: full.name,
          arguments: JSON.stringify(full.arguments),
        },
      },
    );
    let result: any;
    try {
      const decision = await waterfall("tools/pre-execute", full, () => {
        for (const guard of guards) {
          const reason = guard(full);
          if (reason) return { kind: "deny", reason };
        }
        return { kind: "allow" };
      });
      if (
        decision.kind !== "allow" &&
        !(decision.kind === "ask" && approval === "allow")
      )
        throw new Error(decision.reason ?? "审批拒绝");
      result = await waterfall("tools/execute", full, async () => {
        dispatched.push(full.name);
        try {
          const def = definitions.get(full.name);
          const response = def
            ? await def.execute(full.arguments, full)
            : full.name.endsWith("browser_evaluate")
              ? {
                  content: [
                    {
                      type: "text",
                      text: "### Result\n" + JSON.stringify(domResult),
                    },
                  ],
                }
              : {};
          // 宿主要求工具值为无损JSON；替身也验证这一公开边界。
          expect(response).toStrictEqual(JSON.parse(JSON.stringify(response)));
          return {
            value: response,
            isError: false,
            content:
              def?.output?.render(full.arguments, response) ??
              response.content ??
              [],
            ...(contexts.length ? { additionalContexts: contexts } : {}),
            ...(concludesTurn ? { concludesTurn: true } : {}),
          };
        } catch (error: any) {
          return {
            isError: true,
            error: {
              message: error.message,
              ...(error.code
                ? { info: { name: error.name, code: error.code } }
                : {}),
            },
            content: [{ type: "text", text: String(error) }],
          };
        }
      });
    } catch (error) {
      result = {
        isError: true,
        error: { message: String(error) },
        content: [{ type: "text", text: String(error) }],
      };
    }
    try {
      await emit("tools/result", full, result);
    } catch {
      /* 官方结果观察器的失败不会改写执行结果。 */
    }
    return result;
  };
  const planMode = { get: vi.fn(() => ({ active: false })), set: vi.fn() };
  agent.ctx = {
    sessionProjections: {
      stateOf: () => ({ active: false, wanted: null, running: null }),
    },
    on,
    systemPrompt: {
      section: (s: unknown) => {
        sections.add(s);
        return () => sections.delete(s);
      },
    },
    tools: {
      register: (def: any) => {
        definitions.set(def.name, def);
        return () => definitions.delete(def.name);
      },
      guard: (fn: Function) => {
        guards.add(fn);
        return () => guards.delete(fn);
      },
      execute,
    },
  };
  const effects = new Set<Function>();
  const ctx: any = {
    commands: {
      find: () => ({}),
      execute: async (agent: any, line: string) => {
        planMode.set(agent, line !== "/plan off");
        return { result: { kind: "success" } };
      },
    },
    effect: (fn: Function) => {
      const dispose = fn();
      effects.add(dispose);
      return () => {
        if (effects.delete(dispose)) dispose();
      };
    },
  };
  const manager = new NativeTests(
    ctx,
    { outputRoot: root, cancelGraceMs: 25 },
    preparePreview,
  );
  cleanups.push(async () => {
    for (const test of manager.sessions.values()) await test.dispose();
    rmSync(root, { recursive: true, force: true });
  });
  const end = async (aborted = false) => {
    agent.status = "idle";
    await emit(
      "session/event",
      { id: agent.id },
      {
        type: "turn/end",
        data: { reason: { kind: aborted ? "aborted" : "complete" } },
      },
    );
    await new Promise((resolve) => setTimeout(resolve, 0));
  };
  const call = (name: string, args = {}) => execute({ name, arguments: args });
  const announce = (text: string, sessionId = "origin") =>
    emit(
      "session/event",
      { id: sessionId },
      {
        type: "assistant/message",
        data: { message: { content: [{ type: "text", text }] } },
      },
    );
  const step = async () => {
    expect((await call("test_capture")).isError).toBe(false);
    expect((await call("test_finish_step")).isError).toBe(false);
  };
  return {
    manager,
    planMode,
    unload: async () => {
      for (const dispose of [...effects]) await dispose();
    },
    agent,
    followups,
    toolNames,
    dispatched,
    setDomResult: (value: unknown) => {
      domResult = value;
    },
    sections,
    definitions,
    setApproval: (value: string) => {
      approval = value;
    },
    guards,
    root,
    end,
    call,
    announce,
    step,
    emit,
    execute,
  };
}

it("两个实际动作分别保存说明与子调用，父封装不重复编号；原生图片和上下文正常返回", async () => {
  const t = setup();
  await t.manager.start(t.agent, "搜索agent并检查点赞", sample());
  await t.step();
  const test = t.manager.sessions.get("origin")!;
  const content = [
    { type: "text", text: "点击完成" },
    { type: "image", mimeType: "image/png", data: "aW1hZ2U=" },
  ];
  t.definitions.set("mcp__playwright__browser_click", {
    output: { render: () => content },
    execute: (_: any, exec: any) => {
      const saved = JSON.parse(
        readFileSync(join(test.recorder.directory, "results.json"), "utf8"),
      );
      expect(
        saved.instances[0].steps.at(-1).actual_operations[0].dispatch_observed,
      ).toBe(true);
      exec.deferContext({
        source: { kind: "plugin:test", form: "notice", summary: "子调用" },
        content: [{ type: "text", text: "上下文" }],
      });
      return { clicked: true };
    },
  });
  const click = await t.call("test_execute_operation", {
    description: "点击页面搜索按钮，展开输入框",
    tool_name: "mcp__playwright__browser_click",
    arguments: { element: "搜索按钮", ref: "e1" },
  });
  expect(click.isError).toBe(false);
  expect(click.content).toEqual(content);
  expect(click.additionalContexts).toHaveLength(1);
  const type = await t.call("test_execute_operation", {
    description: "在搜索输入框输入关键词",
    tool_name: "mcp__playwright__browser_type",
    arguments: { element: "搜索框", ref: "e2", text: "agent" },
  });
  expect(type.isError).toBe(false);
  await t.step();
  await t.step();
  await t.call("test_finish");
  const c = projectActualCase(test.run, test.run.instances[0]!);
  expect(c.steps.map((r) => r.number)).toEqual([1, 2, 3]);
  expect(c.steps.map((r) => r.kind)).toEqual([
    "operation",
    "operation",
    "check",
  ]);
  expect(c.steps[1]!.inputs.text).toBe("agent");
  expect(
    c.steps.every(
      (r) =>
        r.operation?.binding.case_run_id ===
          test.run.instances[0]!.case_run_id || r.kind === "check",
    ),
  ).toBe(true);
  expect(new Set(c.call_records.map((c) => c.call_id)).size).toBe(2);
  expect(
    readFileSync(join(test.recorder.directory, "manual-cases.md"), "utf8"),
  ).toContain("| 2 | 在搜索框中输入「agent」");
  expect(
    JSON.parse(
      readFileSync(join(test.recorder.directory, "actual-steps.json"), "utf8"),
    ).cases[0].steps,
  ).toHaveLength(3);
});

it("手工原始输入在派发前落盘，导出真实值且运行审计继续脱敏", async () => {
  const t = setup();
  const password = "manual-native-test-only-password";
  const plan = sample();
  plan.cases[0]!.datasets[0]!.inputs = { password };
  await t.manager.start(t.agent, "登录并检查", plan);
  await t.step();
  const test = t.manager.sessions.get("origin")!;
  t.definitions.set("mcp__playwright__browser_type", {
    execute: () => {
      const source = JSON.parse(
        readFileSync(
          join(test.recorder.directory, "manual-source.json"),
          "utf8",
        ),
      );
      expect(
        Object.values(source.operations).some(
          (op: any) => op.inputs.text === password,
        ),
      ).toBe(true);
      expect(
        readFileSync(join(test.recorder.directory, "results.json"), "utf8"),
      ).not.toContain(password);
      return { typed: true };
    },
  });
  const typed = await t.call("test_execute_operation", {
    description: "输入密码 " + password,
    tool_name: "mcp__playwright__browser_type",
    arguments: { element: "密码框", ref: "e1", text: password },
  });
  expect(typed.isError).toBe(false);
  await t.step();
  await t.step();
  await t.call("test_finish");
  expect(
    readFileSync(join(test.recorder.directory, "manual-cases.md"), "utf8"),
  ).toContain(`在密码框中输入「${password}」`);
  expect(
    readFileSync(join(test.recorder.directory, "events.jsonl"), "utf8"),
  ).not.toContain(password);
  expect(
    readFileSync(join(test.recorder.directory, "report.html"), "utf8"),
  ).not.toContain(password);
});

it("原始手工输入保存失败时不派发业务工具", async () => {
  const t = setup();
  await t.manager.start(t.agent, "输入关键词", sample());
  await t.step();
  const write = vi
    .spyOn(ManualSource.prototype, "save")
    .mockImplementationOnce(() => {
      throw new Error("测试原始资料写失败");
    });
  try {
    const result = await t.call("test_execute_operation", {
      description: "输入关键词",
      tool_name: "mcp__playwright__browser_type",
      arguments: { element: "搜索框", ref: "e1", text: "agent" },
    });
    expect(result.isError).toBe(true);
    expect(t.dispatched).not.toContain("mcp__playwright__browser_type");
  } finally {
    write.mockRestore();
  }
});

it("工具Schema给出完整MCP名称，省略前缀提示正确名称且不会派发", async () => {
  const t = setup();
  await t.manager.start(t.agent, "访问页面", sample());
  await t.step();
  const names = t.definitions.get("test_execute_operation").parameters
    .properties.tool_name.enum;
  expect(names).toContain("mcp__playwright__browser_navigate");
  expect(names).not.toContain("browser_navigate");
  const result = await t.call("test_execute_operation", {
    description: "访问页面",
    tool_name: "browser_navigate",
    arguments: { url: "https://example.test" },
  });
  expect(result.isError).toBe(true);
  expect(result.content[0].text).toContain("mcp__playwright__browser_click");
  for (const input of [
    { description: "访问", arguments: {} },
    {
      description: "访问",
      tool_name: "mcp__playwright__browser_navigate",
      arguments: [],
      state: "SUCCEEDED",
    },
  ]) {
    const invalid = await t.call("test_execute_operation", input);
    expect(invalid.isError).toBe(true);
    expect(invalid.content[0].text).toContain("操作参数无效");
  }
  expect(t.dispatched).not.toContain("mcp__playwright__browser_navigate");
});

it("原生定位失败仍返回错误，调整重试保留两条同名操作", async () => {
  const t = setup();
  await t.manager.start(t.agent, "搜索agent", sample());
  await t.step();
  const body = vi
    .fn()
    .mockRejectedValueOnce(
      Object.assign(new Error("定位未命中"), {
        code: "LOCATOR_MISSING",
        name: "LocatorError",
      }),
    )
    .mockResolvedValueOnce({ ok: true });
  t.definitions.set("mcp__playwright__browser_click", { execute: body });
  const args = {
    description: "点击搜索按钮",
    tool_name: "mcp__playwright__browser_click",
    arguments: { ref: "e1" },
  };
  const failed = await t.call("test_execute_operation", args);
  expect(failed.isError).toBe(true);
  expect(failed.error).toMatchObject({
    message: "定位未命中",
    info: { code: "LOCATOR_MISSING" },
  });
  expect(failed.content[0].text).toContain("定位未命中");
  expect(
    (
      await t.call("test_execute_operation", {
        ...args,
        arguments: { ref: "e2" },
      })
    ).isError,
  ).toBe(false);
  const test = t.manager.sessions.get("origin")!;
  const c = projectActualCase(test.run, test.run.instances[0]!);
  expect(c.steps.map((r) => r.state)).toEqual(["ERROR", "SUCCEEDED"]);
  expect(c.steps[0]!.operation!.operation_id).not.toBe(
    c.steps[1]!.operation!.operation_id,
  );
  expect(body).toHaveBeenCalledTimes(2);
});

it("裸调业务工具得到带说明入口提示，目标拒绝及原生审批拒绝不派发、不占主编号", async () => {
  const t = setup();
  const plan = sample();
  (plan.cases[0]!.steps[0]!.action as any).approval = true;
  await t.manager.start(t.agent, "搜索agent", plan);
  await t.step();
  const raw = await t.call("mcp__playwright__browser_click", { ref: "e1" });
  expect(raw.content[0].text).toContain("test_execute_operation");
  expect(raw.isError).toBe(true);
  const navigate = {
    description: "访问搜索页面",
    tool_name: "mcp__playwright__browser_navigate",
    arguments: { url: "https://foreign.test" },
  };
  expect((await t.call("test_execute_operation", navigate)).isError).toBe(true);
  t.setApproval("reject");
  expect(
    (
      await t.call("test_execute_operation", {
        description: "点击搜索",
        tool_name: "mcp__playwright__browser_click",
        arguments: { ref: "e1" },
      })
    ).isError,
  ).toBe(true);
  const test = t.manager.sessions.get("origin")!;
  const c = projectActualCase(test.run, test.run.instances[0]!);
  expect(c.steps).toEqual([]);
  expect(c.not_dispatched).toHaveLength(2);
  expect(
    c.not_dispatched.every(
      (r) => r.state === "NOT_DISPATCHED" && r.number === undefined,
    ),
  ).toBe(true);
  expect(t.dispatched).not.toContain("mcp__playwright__browser_click");
  expect(t.dispatched).not.toContain("mcp__playwright__browser_navigate");
});

it("复合输入提交标为需复核，原生终止标记随成功子调用传递", async () => {
  const t = setup();
  await t.manager.start(t.agent, "输入agent", sample());
  await t.step();
  t.definitions.set("mcp__playwright__browser_type", {
    execute: (_: any, exec: any) => {
      exec.concludeTurn();
      return {};
    },
  });
  const r = await t.call("test_execute_operation", {
    description: "输入并提交搜索",
    tool_name: "mcp__playwright__browser_type",
    arguments: { ref: "e2", text: "agent", submit: true },
  });
  expect(r.concludesTurn).toBe(true);
  const test = t.manager.sessions.get("origin")!;
  expect(projectActualCase(test.run, test.run.instances[0]!).completeness).toBe(
    "PARTIAL",
  );
});

it("取消宽限截止封存未知操作，迟到结果只入审计，不改写手工步骤文件", async () => {
  const t = setup();
  await t.manager.start(t.agent, "点击搜索", sample());
  await t.step();
  let release!: () => void, entered!: () => void;
  const started = new Promise<void>((r) => {
    entered = r;
  });
  t.definitions.set("mcp__playwright__browser_click", {
    execute: () =>
      new Promise((r) => {
        entered();
        release = () => r({ ok: true });
      }),
  });
  const pending = t.call("test_execute_operation", {
    description: "点击搜索按钮",
    tool_name: "mcp__playwright__browser_click",
    arguments: { ref: "e1" },
  });
  await started;
  const test = t.manager.sessions.get("origin")!;
  t.agent.whenIdle.mockImplementation(() => new Promise(() => {}));
  test.stop();
  await new Promise((r) => setTimeout(r, 55));
  expect(test.closed).toBe(true);
  const before = readFileSync(
    join(test.recorder.directory, "actual-steps.json"),
    "utf8",
  );
  expect(JSON.parse(before).cases[0].steps[0].state).toBe("UNKNOWN");
  release();
  await pending;
  expect(
    readFileSync(join(test.recorder.directory, "actual-steps.json"), "utf8"),
  ).toBe(before);
  expect(
    readFileSync(join(test.recorder.directory, "events.jsonl"), "utf8"),
  ).toContain("late_tool_result");
  expect(
    projectActualCase(
      await rebuild(test.recorder.directory),
      test.run.instances[0]!,
    ).steps[0]!.state,
  ).toBe("UNKNOWN");
});

it("MCP以普通错误返回取消时仍使用原生信号标为未知，不依赖取消错误码或文字", async () => {
  const t = setup();
  await t.manager.start(t.agent, "取消点击", sample());
  await t.step();
  const controller = new AbortController();
  t.definitions.set("mcp__playwright__browser_click", {
    execute: () => {
      controller.abort();
      throw new Error("transport request cancelled");
    },
  });
  const result = await t.execute({
    name: "test_execute_operation",
    arguments: {
      description: "点击搜索按钮",
      tool_name: "mcp__playwright__browser_click",
      arguments: { ref: "e1" },
    },
    signal: controller.signal,
  });
  expect(result.isError).toBe(true);
  const test = t.manager.sessions.get("origin")!;
  expect(
    projectActualCase(test.run, test.run.instances[0]!).steps[0]!.state,
  ).toBe("UNKNOWN");
  expect(projectActualCase(test.run, test.run.instances[0]!).completeness).toBe(
    "PARTIAL",
  );
});

it("必需说明快照写入失败时原生业务工具不派发", async () => {
  const t = setup();
  await t.manager.start(t.agent, "点击搜索", sample());
  await t.step();
  const test = t.manager.sessions.get("origin")!;
  const snapshot = vi
    .spyOn(test.recorder, "snapshot")
    .mockImplementation(() => {
      test.recorder.failed = new Error("模拟磁盘写失败");
      throw test.recorder.failed;
    });
  try {
    expect(
      (
        await t.call("test_execute_operation", {
          description: "点击搜索",
          tool_name: "mcp__playwright__browser_click",
          arguments: { ref: "e1" },
        })
      ).isError,
    ).toBe(true);
    expect(t.dispatched).not.toContain("mcp__playwright__browser_click");
    expect(
      [...t.guards]
        .map((guard) =>
          guard({
            agent: t.agent,
            name: "mcp__playwright__browser_snapshot",
            callId: "future",
            arguments: {},
          }),
        )
        .some((reason) => String(reason).includes("账本写入失败")),
    ).toBe(true);
  } finally {
    snapshot.mockRestore();
  }
});

it("真实正文为空时，非空文字检查不能以与字符串0比较放行，导出仍显示原空字符串预期", async () => {
  const t = setup();
  await t.manager.start(t.agent, "检查帖子正文不为空");
  await t.announce(
    (
      await t.call("test_submit_plan", {
        name: "空正文",
        steps: [{ description: "检查正文", checks: ["帖子正文不为空"] }],
      })
    ).value.plan_summary,
  );
  await t.call("test_define_step", {
    capability: "browser",
    allowed_targets: ["https://example.test"],
    reason: "读取真实正文",
  });
  t.setDomResult({ values: { body: "" } });
  await t.call("test_capture", {
    capture: { body: { kind: "dom", mode: "text", selector: "article" } },
    reason: "当前正文位置",
  });
  const bind = {
    check_index: 0,
    assertion: {
      observation_ref: "step_1.body",
      operator: "neq",
      expected_value: "0",
    },
  };
  expect((await t.call("test_bind_check", bind)).isError).toBe(true);
  expect(
    (
      await t.call("test_bind_check", {
        ...bind,
        assertion: { ...bind.assertion, expected_value: "" },
      })
    ).isError,
  ).toBe(false);
  await t.call("test_finish_step");
  await t.step();
  expect((await t.call("test_finish")).value.statistics.FAIL).toBe(1);
  const test = t.manager.sessions.get("origin")!;
  const row = projectActualCase(test.run, test.run.instances[0]!).steps[0]!;
  expect(row.assertion).toMatchObject({
    status: "FAIL",
    expected: "",
    actual: "",
  });
});

it("派生文件导出失败提示重建，保留已结算断言和原生运行结果", async () => {
  const t = setup();
  await t.manager.start(t.agent, "核对点赞", sample());
  await t.step();
  await t.step();
  await t.step();
  const module = await import("../../src/manual-case.js");
  const exportFile = vi
    .spyOn(module, "writeManualCases")
    .mockImplementation(() => {
      throw new Error("模拟派生文件导出失败");
    });
  try {
    const final = await t.call("test_finish");
    expect(final.isError).toBe(false);
    expect(final.value.statistics.PASS).toBe(1);
    expect(final.value.actual_steps_export_error).toContain("重建");
    const test = t.manager.sessions.get("origin")!;
    expect(test.recorder.failed).toBeUndefined();
    expect((await rebuild(test.recorder.directory)).instances[0]!.status).toBe(
      "PASS",
    );
    expect(
      readFileSync(join(test.recorder.directory, "report.html"), "utf8"),
    ).toContain("实际步骤文件导出失败");
  } finally {
    exportFile.mockRestore();
  }
});

it.each([
  [3, "PASS"],
  [0, "FAIL"],
])(
  "同一原生Agent采集 %s 并结算 %s；不创建子会话或伪造会话事件",
  async (value, expected) => {
    const t = setup(Number(value));
    await t.manager.start(t.agent, "点赞不为0", sample());
    expect(t.followups).toHaveLength(1);
    expect(t.followups[0].source.kind).toBe("user");
    const run = t.manager.sessions.get("origin")!;
    expect(run.run.manifest.plugin_version).toBe(
      JSON.parse(
        readFileSync(new URL("../../package.json", import.meta.url), "utf8"),
      ).version,
    );
    await t.step();
    await t.step();
    await t.step();
    const final = await t.call("test_finish");
    expect(final.value.statistics[expected]).toBe(1);
    expect(final.value.assertions[0]).toMatchObject({
      actual: value,
      expected: 0,
      status: expected,
    });
    await t.end();
    expect(run.closed).toBe(true);
    expect(t.definitions.size).toBe(0);
    expect(t.sections.size).toBe(0);
    expect(t.guards.size).toBe(0);
    expect(run.run.instances[0].session_id).toBe("origin");
    expect(run.run.instances[0].cleanup_session_id).toBe("origin");
    expect((await rebuild(run.recorder.directory)).instances[0].status).toBe(
      expected,
    );
    expect(
      run.run.instances[0].steps
        .flatMap((s) => s.calls)
        .every((c) => c.finished_at),
    ).toBe(true);
    expect(
      readFileSync(join(run.recorder.directory, "report.html"), "utf8"),
    ).toContain("本次实际值");
    expect(t.manager.reportId("other")).toBeUndefined();
  },
);

it("固定采集与清理接受空capture而不允许覆盖冻结定义", async () => {
  const t = setup();
  await t.manager.start(t.agent, "点赞不为0", sample());
  await t.step();
  const run = t.manager.sessions.get("origin")!;
  const plan = structuredClone(run.run.plan);
  expect(
    (
      await t.call("test_capture", {
        capture: { likes: { kind: "dom", mode: "number", selector: "#other" } },
      })
    ).isError,
  ).toBe(true);
  expect((await t.call("test_capture", { capture: {} })).isError).toBe(false);
  expect((await t.call("test_finish_step")).isError).toBe(false);
  expect(
    (
      await t.call("test_capture", {
        capture: {
          released: { kind: "dom", mode: "visible", selector: "body" },
        },
      })
    ).isError,
  ).toBe(true);
  expect((await t.call("test_capture", { capture: {} })).isError).toBe(false);
  expect((await t.call("test_finish_step")).isError).toBe(false);
  expect((await t.call("test_finish")).value.statistics.PASS).toBe(1);
  expect(run.run.plan).toEqual(plan);
  expect(
    run.run.instances[0].steps.find((s) => s.step_id === "__close")?.status,
  ).toBe("SUCCEEDED");
});

it.each(["setup", "pass-close", "fail-close"])(
  "纯释放阶段 %s 拒绝业务工具与伪造子调用，可信关闭仍可完成",
  async (phase) => {
    const t = setup(phase === "fail-close" ? 0 : 3);
    await t.manager.start(t.agent, "点赞不为0", sample());
    if (phase !== "setup") {
      await t.step();
      await t.step();
    }
    const run = t.manager.sessions.get("origin")!;
    expect(run.state().next).toContain("浏览器释放阶段");
    const before = t.dispatched.length;
    for (const name of [
      "mcp__playwright__browser_click",
      "mcp__playwright__browser_snapshot",
      "mcp__playwright__browser_evaluate",
      "mcp__playwright__browser_run_code",
      "mcp__playwright__browser_close",
      "test_api_get",
      "shell",
    ])
      expect((await t.call(name)).isError).toBe(true);
    expect(
      (
        await t.call("test_execute_operation", {
          description: "修改旧正文",
          tool_name: "mcp__playwright__browser_click",
          arguments: { ref: "old" },
        })
      ).isError,
    ).toBe(true);
    expect(
      (
        await t.execute({
          name: "mcp__playwright__browser_close",
          parent: {},
        })
      ).isError,
    ).toBe(true);
    expect(t.dispatched.length).toBe(before);
    await t.step();
    if (phase === "setup") {
      await t.step();
      await t.step();
    }
    const result = await t.call("test_finish");
    expect(result.isError).toBe(false);
    expect(
      result.value.statistics[phase === "fail-close" ? "FAIL" : "PASS"],
    ).toBe(1);
    expect(run.run.resource_quarantined).toBe(false);
  },
);

it("默认失败收尾完成后继续下一实例，前一实例FAIL保持冻结", async () => {
  const t = setup(0);
  const plan = sample();
  plan.cases[0]!.datasets.push({
    ...structuredClone(plan.cases[0]!.datasets[0]!),
    data_id: "second",
  });
  await t.manager.start(t.agent, "逐实例核对点赞", plan);
  await t.step();
  await t.step();
  expect(t.manager.sessions.get("origin")!.state().phase).toBe("cleanup");
  await t.step();
  t.setDomResult({ values: { likes: 3 } });
  await t.step();
  await t.step();
  await t.step();
  expect((await t.call("test_finish")).value.statistics).toMatchObject({
    FAIL: 1,
    PASS: 1,
  });
});

it("释放步骤明确失败后立即隔离，不派发下一实例业务", async () => {
  const t = setup();
  const plan = sample();
  plan.cases[0]!.datasets.push({
    ...structuredClone(plan.cases[0]!.datasets[0]!),
    data_id: "second",
  });
  await t.manager.start(t.agent, "资源释放失败", plan);
  await t.step();
  await t.step();
  await t.call("test_fail_step", { reason: "浏览器关闭未获得确认" });
  expect(existsSync(join(t.root, "quarantine.json"))).toBe(true);
  expect((await t.call("mcp__playwright__browser_click")).isError).toBe(true);
  expect(
    t.manager.sessions
      .get("origin")!
      .run.instances[1]!.steps.filter((s) => s.phase === "test")
      .every((s) => s.status === "SKIPPED"),
  ).toBe(true);
  await t.end(true);
});

it("允许正常追问并等待同一会话补充；其他会话不继承测试上下文", async () => {
  const t = setup();
  await t.manager.start(t.agent, "检查点赞");
  await t.call("ask_user_question");
  await t.end();
  expect(t.manager.sessions.get("origin")!.closed).toBe(false);
  expect(t.sections.size).toBe(1);
  expect(t.manager.sessions.has("other")).toBe(false);
  expect(t.manager.reportId("other")).toBeUndefined();
  expect(t.followups).toHaveLength(1);
});

it("停止先等待原生在途结算，再在同一会话运行预授权清理并保留取消状态", async () => {
  // 由受控时钟推进取消宽限期，避免调度负载把正常结算误判为超时。
  vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout"] });
  const t = setup();
  await t.manager.start(t.agent, "点赞不为0", sample());
  await t.step();
  let drain!: () => void;
  t.agent.whenIdle.mockImplementation(
    () =>
      new Promise<void>((resolve) => {
        drain = resolve;
      }),
  );
  const run = t.manager.sessions.get("origin")!;
  run.stop();
  const stopping = t.end(true);
  await vi.advanceTimersByTimeAsync(t.manager.config.cancelGraceMs - 1);
  await stopping;
  expect(t.followups).toHaveLength(1);
  expect(run.closed).toBe(false);
  drain();
  await vi.advanceTimersByTimeAsync(0);
  expect(t.followups).toHaveLength(2);
  expect(t.followups[1].source.kind).toBe("plugin:test");
  expect(
    (
      await t.call("test_execute_operation", {
        description: "打开目标页面以读取点赞",
        tool_name: "mcp__playwright__browser_navigate",
        arguments: { url: "https://example.test" },
      })
    ).isError,
  ).toBe(true);
  await t.step();
  expect((await t.call("test_finish")).value.statistics.CANCELLED).toBe(1);
  t.agent.whenIdle.mockResolvedValue(undefined);
  const finished = t.end();
  await vi.advanceTimersByTimeAsync(0);
  await finished;
  expect(run.closed).toBe(true);
  expect(run.run.instances[0].cleanup_session_id).toBe("origin");
});

it("在途无法结算时不启动清理，持久隔离并拒绝后续共享环境运行", async () => {
  const t = setup();
  await t.manager.start(t.agent, "点赞不为0", sample());
  const run = t.manager.sessions.get("origin")!;
  t.agent.whenIdle.mockImplementation(() => new Promise(() => {}));
  run.stop();
  await t.end(true);
  await new Promise((resolve) => setTimeout(resolve, 45));
  expect(t.followups).toHaveLength(1);
  expect(run.closed).toBe(true);
  expect(existsSync(join(t.root, "quarantine.json"))).toBe(true);
  await expect(t.manager.start(t.agent, "重试", sample())).rejects.toThrow(
    "隔离",
  );
});

it("模型不能绕过可信采集直接完成，必需动作失败会阻断后续业务", async () => {
  const t = setup();
  await t.manager.start(t.agent, "点赞不为0", sample());
  await t.step();
  expect((await t.call("test_finish_step")).isError).toBe(true);
  await t.call("test_fail_step", { reason: "无法读取" });
  expect(t.manager.sessions.get("origin")!.state().current?.phase).toBe(
    "cleanup",
  );
  await t.step();
  const result = await t.call("test_finish");
  expect(result.value.statistics.ERROR).toBe(1);
  expect(result.value.assertions).toEqual([]);
  await t.end();
});

it("停止后保留自定义冻结清理，不把清理改成业务或跳过", async () => {
  const t = setup();
  const plan = sample() as any;
  plan.cases[0].cleanup = [
    {
      ...structuredClone(plan.cases[0].steps[0]),
      step_id: "custom_cleanup",
      run_if: "always",
      description: "授权的浏览器只读清理检查",
    },
  ];
  await t.manager.start(t.agent, "按计划执行", plan);
  await t.step();
  const run = t.manager.sessions.get("origin")!;
  run.stop();
  await t.end(true);
  expect(run.state().current?.step.step_id).toBe("custom_cleanup");
  expect(run.state().current?.phase).toBe("cleanup");
  expect((await t.call("mcp__playwright__browser_snapshot")).isError).toBe(
    false,
  );
  await t.step();
  await t.step();
  await t.call("test_finish");
  await t.end();
  expect(
    run.run.instances[0].steps.find((s) => s.step_id === "custom_cleanup")
      ?.status,
  ).toBe("SUCCEEDED");
  expect(run.run.instances[0].status).toBe("CANCELLED");
});

it("重启发现未结算测试时隔离，不创建Agent或重放工具", async () => {
  const t = setup();
  await t.manager.start(t.agent, "测试", sample());
  t.manager.sessions.get("origin")!.dispose();
  const restarted = new NativeTests({} as never, { outputRoot: t.root });
  expect(existsSync(join(t.root, "quarantine.json"))).toBe(true);
  expect(restarted.sessions.size).toBe(0);
  expect(t.followups).toHaveLength(1);
});

it("追加有规则来源的必需断言会改变本实例结果且保留修订适用实例", async () => {
  const t = setup(3);
  const plan = sample();
  // 保留一个未执行动作作为追加断言前的运行边界。
  plan.cases[0].steps.splice(1, 0, {
    ...structuredClone(plan.cases[0].steps[0]),
    step_id: "second",
    depends_on: ["read"],
  });
  await t.manager.start(t.agent, "按计划执行", plan);
  await t.step();
  await t.step();
  const added = {
    ...structuredClone(plan.cases[0].steps.at(-1)),
    step_id: "extra",
    assertion: {
      observation_ref: "read.likes",
      operator: "eq",
      literal: 0,
      rule_ref: "r",
    },
  };
  const result = await t.call("test_propose_checkpoint", {
    reason: "补充已授权检查",
    source_refs: plan.source_refs,
    added_steps: [added],
    target_instance_ids: ["one--a"],
    insertion_boundary: "end",
    post_hoc: true,
  });
  expect(result.isError).toBe(false);
  await t.step();
  await t.step();
  await t.call("test_finish");
  await t.end();
  const run = t.manager.sessions.get("origin")!.run;
  expect(run.instances[0].status).toBe("FAIL");
  expect(run.instances[0].revision_history?.[0].target_instance_ids).toEqual([
    "one--a",
  ]);
});

it("预先提交JSON计划只保留当前步骤计时器，释放后不遗留取消计时器", async () => {
  vi.useFakeTimers();
  try {
    const t = setup();
    await t.manager.start(t.agent, "测试", sample());
    expect(vi.getTimerCount()).toBe(1);
    t.manager.sessions.get("origin")!.dispose();
    expect(vi.getTimerCount()).toBe(0);
  } finally {
    vi.clearAllTimers();
    vi.useRealTimers();
  }
});

it("插件作用域卸载会取消当前原生Agent并隔离未清理资源", async () => {
  const t = setup();
  await t.manager.start(t.agent, "测试", sample());
  await t.unload();
  expect(t.agent.cancel).toHaveBeenCalledOnce();
  expect(t.manager.sessions.get("origin")!.closed).toBe(true);
  expect(existsSync(join(t.root, "quarantine.json"))).toBe(true);
  expect(t.definitions.size).toBe(0);
});

it("自然语言计划由插件补齐固定字段，不要求模型编造版本和规则来源", async () => {
  const t = setup();
  await t.manager.start(t.agent, "点赞不为0");
  const result = await t.call("test_submit_plan", reviewPlan());
  expect(result.isError).toBe(false);
  expect(result.value.plan_summary).toContain("原始任务");
  expect(result.value.plan_summary).toContain("拆分思路");
  const frozen = t.manager.sessions.get("origin")!.run.plan;
  expect(frozen.schema_version).toBe("1");
  expect(frozen.cases[0].cleanup).toEqual([]);
  expect(frozen.source_refs[0].excerpt).toBe("点赞不为0");
});

it("普通规划只输出文字时提醒一次，再次结束未提交则明确 ERROR 并释放会话", async () => {
  const t = setup();
  await t.manager.start(t.agent, "访问站点，检查标题");
  const run = t.manager.sessions.get("origin")!;
  await t.end();
  expect(t.followups).toHaveLength(2);
  expect(t.followups[1].source.kind).toBe("plugin:test");
  expect(JSON.stringify(t.followups[1])).toContain("test_submit_plan");
  expect(run.closed).toBe(false);
  await t.end();
  expect(run.closed).toBe(true);
  expect(run.run.instances[0].status).toBe("ERROR");
  expect(run.run.manifest.stop_reason).toContain("未提交有效计划");
  expect(t.followups).toHaveLength(2);
  expect(t.dispatched).toEqual([]);
});

it("规划提醒保留原始超时预算，不重新延长且不会派发业务", async () => {
  vi.useFakeTimers();
  const t = setup();
  try {
    t.manager.config.stepTimeoutMs = 40;
    await t.manager.start(t.agent, "查询接口并核对状态");
    const run = t.manager.sessions.get("origin")!;
    const first = t.end();
    await vi.advanceTimersByTimeAsync(0);
    await first;
    expect(t.followups).toHaveLength(2);
    await vi.advanceTimersByTimeAsync(41);
    expect(run.run.manifest.stop_reason).toBe("规划执行超时");
    const stopped = t.end(true);
    await vi.advanceTimersByTimeAsync(0);
    await stopped;
    expect(run.run.instances[0].status).toBe("ERROR");
    expect(t.dispatched).toEqual([]);
  } finally {
    vi.useRealTimers();
  }
});

it("规划阶段已经追问时等待用户，不把待补充信息判为缺少计划", async () => {
  const t = setup();
  await t.manager.start(t.agent, "登录但没有提供账号");
  await t.call("ask_user_question");
  await t.end();
  expect(t.followups).toHaveLength(1);
  expect(t.manager.sessions.get("origin")!.closed).toBe(false);
});

it("必要信息等待不计预算，用户补充后恢复规划超时", async () => {
  vi.useFakeTimers();
  const t = setup();
  try {
    t.manager.config.stepTimeoutMs = 40;
    await t.manager.start(t.agent, "登录但没有账号");
    const run = t.manager.sessions.get("origin")!;
    await t.call("ask_user_question");
    const waiting = t.end();
    await vi.advanceTimersByTimeAsync(0);
    await waiting;
    await vi.advanceTimersByTimeAsync(80);
    expect(run.run.manifest.stop_reason).toBeUndefined();
    await t.emit(
      "session/event",
      { id: t.agent.id },
      {
        type: "user/message",
        data: {
          source: { kind: "user" },
          content: [{ type: "text", text: "必要信息已补充" }],
        },
      },
    );
    await vi.advanceTimersByTimeAsync(41);
    expect(run.run.manifest.stop_reason).toBe("规划执行超时");
    expect(run.run.instances[0].status).toBe("ERROR");
    expect(t.dispatched.filter((name) => name !== "ask_user_question")).toEqual(
      [],
    );
  } finally {
    vi.useRealTimers();
  }
});

it("规划超时记录ERROR，且没有执行或清理浏览器", async () => {
  const t = setup();
  await t.manager.start(t.agent, "点赞不为0");
  const run = t.manager.sessions.get("origin")!;
  run.stop("规划执行超时");
  await t.end(true);
  expect(run.run.instances[0].status).toBe("ERROR");
  expect(run.run.manifest.stop_reason).toBe("规划执行超时");
  expect(t.dispatched).toEqual([]);
  expect(t.followups).toHaveLength(1);
});

it("规划阶段禁止浏览器、API、命令和其他执行工具，仍允许正常分析与追问", async () => {
  const t = setup();
  await t.manager.start(t.agent, "访问站点检查点赞");
  for (const name of [
    "mcp__playwright__browser_navigate",
    "mcp__playwright__browser_snapshot",
    "test_api_get",
    "exec_command",
    "unknown_external_tool",
  ])
    expect((await t.call(name, { url: "https://example.test" })).isError).toBe(
      true,
    );
  for (const name of ["test_current", "todo_write", "ask_user_question"])
    expect((await t.call(name)).isError).toBe(false);
  expect(t.dispatched).toEqual([
    "test_current",
    "todo_write",
    "ask_user_question",
  ]);
  expect(t.manager.sessions.get("origin")!.state().phase).toBe("planning");
});

it("JSON运行时采集可修正定位且不改预期", async () => {
  const t = setup();
  const plan: any = sample();
  delete plan.cases[0].steps[0].action.capture;
  plan.cases[0].steps[0].action.capture_mode = "runtime";
  await t.manager.start(t.agent, "点赞不为0", plan);
  const run = t.manager.sessions.get("origin")!;
  const frozen = JSON.stringify(run.run.plan);
  expect(t.dispatched).toEqual([]);
  await t.step();
  expect(
    (
      await t.call("test_execute_operation", {
        description: "打开目标页面以读取点赞",
        tool_name: "mcp__playwright__browser_navigate",
        arguments: { url: "https://example.test" },
      })
    ).isError,
  ).toBe(false);
  expect(
    (
      await t.call("mcp__playwright__browser_evaluate", {
        function: "() => document.title",
      })
    ).isError,
  ).toBe(false);
  t.setDomResult({ values: {} });
  await t.call("test_capture", {
    capture: { likes: { kind: "dom", mode: "number", selector: "#old" } },
    reason: "按当前页面定位",
  });
  expect((await t.call("test_finish_step")).isError).toBe(true);
  t.setDomResult({ values: { likes: 3 } });
  expect(
    (
      await t.call("test_capture", {
        capture: { likes: { kind: "dom", mode: "number", selector: "#new" } },
        reason: "页面更新，修正同一点赞元素定位",
      })
    ).isError,
  ).toBe(false);
  expect((await t.call("test_finish_step")).isError).toBe(false);
  await t.step();
  const final = await t.call("test_finish");
  expect(final.value.assertions[0]).toMatchObject({
    actual: 3,
    expected: 0,
    status: "PASS",
  });
  expect(JSON.stringify(run.run.plan)).toBe(frozen);
  expect(
    run.run.instances[0].steps.find((s) => s.step_id === "read")!
      .capture_attempts,
  ).toHaveLength(2);
  expect(await rebuild(run.recorder.directory)).toEqual(run.run);
  await t.end();
});

it("运行时采集只允许已声明输出，不能修改预期或覆盖既有观察", async () => {
  const t = setup();
  const p: any = sample();
  p.cases[0].steps[0].action.capture_mode = "runtime";
  delete p.cases[0].steps[0].action.capture;
  await t.manager.start(t.agent, "点赞不为0", p);
  await t.step();
  expect(
    (
      await t.call("test_capture", {
        capture: { fake: { kind: "dom", mode: "number", selector: "#likes" } },
        reason: "非法新增输出",
      })
    ).isError,
  ).toBe(true);
  expect(
    (
      await t.call("test_capture", {
        capture: { likes: { kind: "http", url: "https://other.test" } },
        reason: "越界采集",
      })
    ).isError,
  ).toBe(true);
  const capture = {
    likes: { kind: "dom", mode: "number", selector: "#likes" },
  };
  expect(
    (await t.call("test_capture", { capture, reason: "读取原目标点赞" }))
      .isError,
  ).toBe(false);
  expect(
    (await t.call("test_capture", { capture, reason: "覆盖实际值" })).isError,
  ).toBe(true);
});

it("采集部分成功后可只补采缺少输出，不丢失或覆盖已有证据", async () => {
  const t = setup();
  const p: any = sample();
  Object.assign(p.cases[0].steps[0].action, {
    capture_mode: "runtime",
    capture: undefined,
    outputs: { likes: { type: "number" }, path: { type: "string" } },
    completion_requirements: ["likes", "path"],
  });
  delete p.cases[0].steps[0].action.capture;
  await t.manager.start(t.agent, "点赞不为0", p);
  await t.step();
  const cap = {
    likes: { kind: "dom", mode: "number", selector: "#likes" },
    path: { kind: "dom", mode: "url", field: "pathname" },
  };
  await t.call("test_capture", { capture: cap, reason: "读取当前帖子" });
  const run = t.manager.sessions.get("origin")!;
  const first = structuredClone(
    run.run.instances[0].steps.find((s) => s.step_id === "read")!
      .observations[0],
  );
  t.setDomResult({ values: { path: "/topic/1" } });
  expect(
    (
      await t.call("test_capture", {
        capture: { path: cap.path },
        reason: "仅补采路径",
      })
    ).isError,
  ).toBe(false);
  expect(
    run.run.instances[0].steps.find((s) => s.step_id === "read")!
      .observations[0],
  ).toEqual(first);
  expect((await t.call("test_finish_step")).isError).toBe(false);
});

function reviewPlan() {
  return {
    name: "查看帖子点赞",
    steps: [{ description: "查看帖子的点赞数", checks: ["点赞数不为0"] }],
  };
}
async function finishTextStep(t: ReturnType<typeof setup>) {
  expect(
    (
      await t.call("test_define_step", {
        capability: "browser",
        allowed_targets: ["https://example.test"],
        reason: "当前帖子",
      })
    ).isError,
  ).toBe(false);
  expect(
    (
      await t.call("test_capture", {
        capture: { likes: { kind: "dom", mode: "number", selector: "#likes" } },
        reason: "查看后确定点赞计数",
      })
    ).isError,
  ).toBe(false);
  expect(
    (
      await t.call("test_bind_check", {
        check_index: 0,
        assertion: {
          observation_ref: "step_1.likes",
          operator: "neq",
          expected_value: "0",
        },
      })
    ).isError,
  ).toBe(false);
  expect((await t.call("test_finish_step")).isError).toBe(false);
}

it("test-plan进入原生模式，草案可修改；只有原生审核批准同一草案后才能执行", async () => {
  const t = setup();
  await t.manager.start(t.agent, "点赞不为0", undefined, true);
  expect(t.planMode.set).toHaveBeenCalledWith(t.agent, true);
  const run = t.manager.sessions.get("origin")!;
  expect(
    (await t.call("exit_plan_mode", { plan: "# 未提交草案" })).isError,
  ).toBe(true);
  const first = await t.call("test_submit_plan", reviewPlan());
  expect(first.value.phase).toBe("reviewing");
  expect(run.run.instances).toEqual([]);
  expect(existsSync(join(run.recorder.directory, "plan.json"))).toBe(false);
  expect((await t.call("test_capture")).isError).toBe(true);
  expect(
    (await t.call("test_api_get", { url: "https://example.test" })).isError,
  ).toBe(true);
  expect(
    (await t.call("exit_plan_mode", { plan: "# 省略具体预期的计划" })).isError,
  ).toBe(true);
  t.definitions.set("exit_plan_mode", {
    execute: () => {
      throw new Error("用户要求修改");
    },
  });
  expect(
    (await t.call("exit_plan_mode", { plan: first.value.review_markdown }))
      .isError,
  ).toBe(true);
  await t.end();
  expect(run.closed).toBe(false);
  expect(run.run.instances).toEqual([]);
  const revised = reviewPlan();
  revised.name = "修改后的计划";
  const second = await t.call("test_submit_plan", revised);
  expect(second.value.review_markdown).toContain("修改后的计划");
  expect(
    (await t.call("exit_plan_mode", { plan: first.value.review_markdown }))
      .isError,
  ).toBe(true);
  t.definitions.set("exit_plan_mode", { execute: () => ({ approved: true }) });
  expect(
    (await t.call("exit_plan_mode", { plan: second.value.review_markdown }))
      .isError,
  ).toBe(false);
  expect(run.state().phase).toBe("executing");
  expect(run.run.plan.name).toBe("修改后的计划");
  expect((await t.call("test_submit_plan", reviewPlan())).isError).toBe(true);
  await finishTextStep(t);
  await t.step();
  expect((await t.call("test_finish")).value.statistics.PASS).toBe(1);
  await t.end();
});

it("等待审核没有执行计时器；取消审核不执行业务或浏览器清理并恢复原模式", async () => {
  vi.useFakeTimers();
  try {
    const t = setup();
    await t.manager.start(t.agent, "点赞不为0", undefined, true);
    await t.call("test_submit_plan", reviewPlan());
    expect(vi.getTimerCount()).toBe(0);
    await vi.advanceTimersByTimeAsync(600000);
    expect(t.agent.cancel).not.toHaveBeenCalled();
    vi.useRealTimers();
    t.manager.sessions.get("origin")!.stop();
    await t.end(true);
    expect(t.manager.sessions.get("origin")!.run.instances[0].status).toBe(
      "CANCELLED",
    );
    expect(t.dispatched).toEqual(["test_submit_plan"]);
    expect(t.planMode.set).toHaveBeenLastCalledWith(t.agent, false);
  } finally {
    vi.useRealTimers();
  }
});

it("test入口提交后直接执行，不进入原生审核", async () => {
  const t = setup();
  await t.manager.start(t.agent, "点赞不为0");
  expect((await t.call("test_submit_plan", reviewPlan())).value.phase).toBe(
    "executing",
  );
  expect(t.planMode.set).not.toHaveBeenCalled();
});

it("直接执行先观察本会话完整计划通报，不以工具结果或其他会话消息代替", async () => {
  const t = setup();
  await t.manager.start(t.agent, "点赞不为0");
  const submitted = await t.call("test_submit_plan", reviewPlan());
  const args = {
    capability: "browser",
    allowed_targets: ["https://example.test"],
    reason: "执行当前步骤",
  };
  expect((await t.call("test_define_step", args)).isError).toBe(true);
  await t.announce("计划已批准，开始执行");
  expect((await t.call("test_define_step", args)).isError).toBe(true);
  await t.announce(submitted.value.plan_summary, "other");
  expect((await t.call("test_define_step", args)).isError).toBe(true);
  expect(t.dispatched.filter((name) => name.includes("playwright"))).toEqual(
    [],
  );
  await t.announce(submitted.value.plan_summary);
  expect((await t.call("test_define_step", args)).isError).toBe(false);
  const run = t.manager.sessions.get("origin")!;
  expect(
    readFileSync(join(run.recorder.directory, "events.jsonl"), "utf8"),
  ).toContain('"plan_announced"');
});

it.each([
  [200, "PASS"],
  [201, "FAIL"],
])(
  "纯API响应经过通用采集与报告，预期状态码%s时结果为%s",
  async (expected, status) => {
    const t = setup();
    const plan = JSON.parse(readFileSync("examples/httpbin-get.json", "utf8"));
    plan.cases[0].datasets[0].expected.status = expected;
    const response = {
      args: { keyword: "agent", client: "dsh" },
      url: "https://httpbin.org/get?keyword=agent&client=dsh",
    };
    const fetchSpy = vi
      .spyOn(globalThis, "fetch")
      .mockResolvedValue(
        new Response(JSON.stringify(response), { status: 200 }),
      );
    try {
      await t.manager.start(t.agent, "接口回显验证", plan);
      expect(
        (
          await t.call("test_api_get", {
            url: "https://httpbin.org/get?keyword=agent&client=dsh",
          })
        ).isError,
      ).toBe(true);
      await t.step();
      expect((await t.call("test_finish")).value.statistics[status]).toBe(1);
      const run = t.manager.sessions.get("origin")!;
      expect(fetchSpy).toHaveBeenCalledTimes(1);
      expect(t.dispatched).not.toContainEqual(
        expect.stringContaining("playwright"),
      );
      expect(run.run.instances[0].steps.map((s) => s.step_id)).toEqual([
        "request",
        "assert_status",
        "assert_keyword",
        "assert_client",
      ]);
      const observation = run.run.instances[0].steps[0].observations[0];
      expect(observation.producer.adapter).toBe("http-json-v1");
      const evidence = JSON.parse(
        readFileSync(
          join(run.recorder.directory, run.run.evidence[0].relative_path),
          "utf8",
        ),
      );
      expect(evidence.value).toEqual(observation.value);
      expect(observation.value).toEqual({ status: 200, body: response });
      expect(run.run.instances[0].steps[1].assertion).toMatchObject({
        actual: 200,
        expected,
        status,
      });
      expect(await rebuild(run.recorder.directory)).toEqual(run.run);
      const html = readFileSync(
        join(run.recorder.directory, "report.html"),
        "utf8",
      );
      expect(html).toContain("断言 HTTP 状态码为 200");
      expect(html).toContain("test_api_get");
      await t.end();
    } finally {
      fetchSpy.mockRestore();
    }
  },
);

it.each(["要求修改", "关闭审核"])(
  "计划只输出文字时提醒原生提交，%s 后不催促用户或自动执行",
  async (outcome) => {
    const t = setup();
    await t.manager.start(t.agent, "点赞不为0", undefined, true);
    await t.emit("agent/turn-stopping", { agent: t.agent });
    expect(t.agent.steer).toHaveBeenCalledOnce();
    await t.call("test_submit_plan", reviewPlan());
    const run = t.manager.sessions.get("origin")!;
    t.definitions.set("exit_plan_mode", {
      execute: (_: unknown, exec: any) => {
        if (outcome === "关闭审核") {
          exec.concludeTurn();
          return { approved: false };
        }
        throw new Error("要求修改");
      },
    });
    const result = await t.call("exit_plan_mode", {
      plan: run.state().review_markdown,
    });
    if (outcome === "关闭审核") {
      expect(result.isError).toBe(false);
      expect(result.concludesTurn).toBe(true);
    }
    t.agent.steer.mockClear();
    await t.emit("agent/turn-stopping", { agent: t.agent });
    expect(t.agent.steer).not.toHaveBeenCalled();
    expect(run.run.instances).toEqual([]);
    expect(existsSync(join(run.recorder.directory, "plan.json"))).toBe(false);
    await t.end();
    expect(run.closed).toBe(false);
    expect(run.state().phase).toBe("reviewing");
    const revised = reviewPlan();
    revised.name = "用户反馈后的计划";
    const submitted = await t.call("test_submit_plan", revised);
    t.definitions.set("exit_plan_mode", {
      execute: () => ({ approved: true }),
    });
    await t.call("exit_plan_mode", { plan: submitted.value.review_markdown });
    expect(run.state().phase).toBe("executing");
    expect(run.run.plan.name).toBe("用户反馈后的计划");
  },
);

it("文字计划只冻结短句，运行时按采集方式登记输出；缺少检查不能通过", async () => {
  const t = setup();
  await t.manager.start(t.agent, "打开帖子检查点赞不为0");
  await t.announce(
    (await t.call("test_submit_plan", reviewPlan())).value.plan_summary,
  );
  const run = t.manager.sessions.get("origin")!;
  const frozen = structuredClone(run.run.plan);
  expect(frozen.cases[0].steps[0]).toMatchObject({
    kind: "intent",
    checks: ["点赞数不为0"],
  });
  expect(frozen.cases[0].steps[0].action).toBeUndefined();
  expect((await t.call("test_finish_step")).isError).toBe(true);
  const base = {
    capability: "browser",
    allowed_targets: ["https://example.test"],
    reason: "执行当前步骤，先看页面",
  };
  expect((await t.call("test_define_step", base)).isError).toBe(false);
  expect(
    (
      await t.call("test_execute_operation", {
        description: "打开目标页面以读取点赞",
        tool_name: "mcp__playwright__browser_navigate",
        arguments: { url: "https://example.test" },
      })
    ).isError,
  ).toBe(false);
  expect(
    (
      await t.call("test_define_step", {
        ...base,
      })
    ).isError,
  ).toBe(false);
  await t.call("test_capture", {
    capture: { likes: { kind: "dom", mode: "number", selector: "#likes" } },
    reason: "实际页面定位",
  });
  expect((await t.call("test_define_step", base)).isError).toBe(true);
  expect((await t.call("test_finish_step")).isError).toBe(true);
  const check = {
    check_index: 0,
    assertion: {
      observation_ref: "step_1.likes",
      operator: "neq",
      expected_value: "0",
    },
  };
  for (const expected_value of ['["0"]', '"0"', "{"])
    expect(
      (
        await t.call("test_bind_check", {
          ...check,
          assertion: { ...check.assertion, expected_value },
        })
      ).isError,
    ).toBe(true);
  expect((await t.call("test_bind_check", check)).isError).toBe(false);
  expect((await t.call("test_bind_check", check)).isError).toBe(true);
  await t.call("test_finish_step");
  await t.step();
  expect((await t.call("test_finish")).value.statistics.PASS).toBe(1);
  expect(run.run.plan).toEqual(frozen);
  expect(await rebuild(run.recorder.directory)).toEqual(run.run);
  await t.end();
});

it.each([false, true])(
  "完整 HTTP 响应与状态码不能直接绑定，修正字段后复用同一观察（后续步骤=%s）",
  async (laterStep) => {
    const t = setup();
    const spy = vi
      .spyOn(globalThis, "fetch")
      .mockResolvedValue(
        new Response(JSON.stringify({ amount: 100 }), { status: 200 }),
      );
    try {
      await t.manager.start(t.agent, "GET 请求并检查状态码为200");
      const submitted = await t.call("test_submit_plan", {
        name: "HTTP 字段绑定",
        steps: laterStep
          ? [
              { description: "发送请求" },
              { description: "检查响应", checks: ["HTTP 状态码等于200"] },
            ]
          : [
              {
                description: "发送请求并检查响应",
                checks: ["HTTP 状态码等于200"],
              },
            ],
      });
      await t.announce(submitted.value.plan_summary);
      await t.call("test_define_step", {
        capability: "api",
        allowed_targets: ["https://httpbin.org"],
        reason: "按用户原文发送 GET",
      });
      await t.call("test_capture", {
        capture: {
          response: { kind: "http", url: "https://httpbin.org/get", field: "" },
        },
        reason: "保存完整 HTTP 响应供状态码检查复用",
      });
      if (laterStep) await t.call("test_finish_step");
      const run = t.manager.sessions.get("origin")!;
      const rejected = await t.call("test_bind_check", {
        check_index: 0,
        assertion: {
          observation_ref: "step_1.response",
          operator: "eq",
          expected_value: "200",
        },
      });
      expect(rejected.isError).toBe(true);
      expect(
        run.run.instances[0].effective_steps.filter((s) => s.assertion),
      ).toHaveLength(0);
      expect(
        (
          await t.call("test_bind_check", {
            check_index: 0,
            assertion: {
              observation_ref: "step_1.response.status",
              operator: "eq",
              expected_value: "200",
            },
          })
        ).isError,
      ).toBe(false);
      await t.call("test_finish_step");
      expect((await t.call("test_finish")).value.statistics.PASS).toBe(1);
      expect(spy).toHaveBeenCalledOnce();
      await t.end();
    } finally {
      spy.mockRestore();
    }
  },
);

it("数组观察引用拒绝错误括号语法，索引与长度复用同一可信响应", async () => {
  const t = setup();
  const spy = vi
    .spyOn(globalThis, "fetch")
    .mockResolvedValue(
      new Response(JSON.stringify([{ iid: 3, labels: [] }]), { status: 200 }),
    );
  try {
    await t.manager.start(
      t.agent,
      "查询 Issue，检查第一条 iid 等于3、数组长度1和标签数量0",
    );
    const submitted = await t.call("test_submit_plan", {
      name: "数组引用",
      steps: [
        {
          description: "查询并检查 Issue",
          checks: [
            "第一条 iid 等于3",
            "响应数组长度等于1",
            "第一条标签数量等于0",
          ],
        },
      ],
    });
    await t.announce(submitted.value.plan_summary);
    await t.call("test_define_step", {
      capability: "api",
      allowed_targets: ["https://httpbin.org"],
      reason: "查询列表",
    });
    await t.call("test_capture", {
      capture: {
        response: { kind: "http", url: "https://httpbin.org/get", field: "" },
      },
      reason: "保存列表响应",
    });
    expect(
      (
        await t.call("test_bind_check", {
          check_index: 0,
          assertion: {
            observation_ref: "step_1.response.body[0].iid",
            operator: "eq",
            expected_value: "3",
          },
        })
      ).isError,
    ).toBe(true);
    const run = t.manager.sessions.get("origin")!;
    expect(
      run.run.instances[0].effective_steps.filter((s) => s.assertion),
    ).toHaveLength(0);
    expect(
      (
        await t.call("test_bind_check", {
          check_index: 0,
          assertion: {
            observation_ref: "step_1.response.body.0.iid",
            operator: "eq",
            expected_value: "3",
          },
        })
      ).isError,
    ).toBe(false);
    for (const [check_index, observation_ref, expected_value] of [
      [1, "step_1.response.body.length", "1"],
      [2, "step_1.response.body.0.labels.length", "0"],
    ] as const) {
      expect(
        (
          await t.call("test_bind_check", {
            check_index,
            assertion: {
              observation_ref,
              operator: "eq",
              expected_value,
              unit: "length",
            },
          })
        ).isError,
      ).toBe(false);
    }
    await t.call("test_finish_step");
    expect(
      run.run.instances[0].steps
        .filter((s) => s.assertion)
        .map((s) => s.assertion?.actual),
    ).toEqual([3, 1, 0]);
    expect((await t.call("test_finish")).value.statistics.PASS).toBe(1);
    expect(spy).toHaveBeenCalledOnce();
    await t.end();
  } finally {
    spy.mockRestore();
  }
});

it("正文子字段类型异常仍保留业务 FAIL，不以完整响应保护拒绝业务观察", async () => {
  const t = setup();
  const spy = vi.spyOn(globalThis, "fetch").mockResolvedValue(
    new Response(JSON.stringify({ amount: { unexpected: true } }), {
      status: 200,
    }),
  );
  try {
    await t.manager.start(t.agent, "GET 后检查金额等于100");
    const submitted = await t.call("test_submit_plan", {
      name: "正文类型异常",
      steps: [{ description: "发送请求并核对金额", checks: ["金额等于100"] }],
    });
    await t.announce(submitted.value.plan_summary);
    await t.call("test_define_step", {
      capability: "api",
      allowed_targets: ["https://httpbin.org"],
      reason: "请求接口",
    });
    await t.call("test_capture", {
      capture: {
        amount: {
          kind: "http",
          url: "https://httpbin.org/get",
          field: "body.amount",
        },
      },
      reason: "读取金额字段",
    });
    expect(
      (
        await t.call("test_bind_check", {
          check_index: 0,
          assertion: {
            observation_ref: "step_1.amount",
            operator: "eq",
            expected_value: "100",
          },
        })
      ).isError,
    ).toBe(false);
    await t.call("test_finish_step");
    const run = t.manager.sessions.get("origin")!;
    const result = run.run.instances[0].steps.find(
      (s) => s.assertion,
    )!.assertion!;
    expect(result.status).toBe("FAIL");
    expect(result.expected).toBe(100);
    expect(result.actual).toEqual({ unexpected: true });
    expect((await t.call("test_finish")).value.statistics.FAIL).toBe(1);
    expect(spy).toHaveBeenCalledOnce();
    await t.end();
  } finally {
    spy.mockRestore();
  }
});

it("纯接口文字步骤运行时确定响应结构，下一步只核对已采集响应，不重复请求", async () => {
  const t = setup();
  const spy = vi.spyOn(globalThis, "fetch").mockResolvedValue(
    new Response(JSON.stringify({ args: { keyword: "agent" } }), {
      status: 200,
    }),
  );
  try {
    await t.manager.start(t.agent, "发送请求并验证状态码");
    const submitted = await t.call("test_submit_plan", {
      name: "接口检查",
      steps: [
        { description: "请求httpbin接口" },
        { description: "检查响应", checks: ["状态码为200", "关键字为agent"] },
      ],
    });
    await t.announce(submitted.value.plan_summary);
    const run = t.manager.sessions.get("origin")!;
    await t.call("test_define_step", {
      capability: "api",
      allowed_targets: ["https://httpbin.org"],
      reason: "本步请求接口",
    });
    await t.call("test_capture", {
      capture: {
        response: { kind: "http", url: "https://httpbin.org/get", field: "" },
      },
      reason: "保存完整响应",
    });
    expect(
      (
        await t.call("test_propose_checkpoint", {
          reason: "不得覆盖尚未绑定的文字检查",
          source_refs: run.run.plan.source_refs,
          added_steps: [
            {
              step_id: "step_2_check_1",
              kind: "assertion",
              description: "覆盖",
              required: true,
              depends_on: ["step_1"],
              assertion: {
                observation_ref: "step_1.response.status",
                operator: "eq",
                literal: 200,
                rule_ref: "user_task",
              },
            },
          ],
          target_instance_ids: ["scenario--default"],
          insertion_boundary: "step_2",
          post_hoc: true,
        })
      ).isError,
    ).toBe(true);
    await t.call("test_finish_step");
    expect(run.state().current?.step.step_id).toBe("step_2");
    expect(
      (
        await t.call("test_bind_check", {
          check_index: 1,
          assertion: {
            observation_ref: "step_1.response.body.args.keyword",
            operator: "eq",
            expected_value: "agent",
          },
        })
      ).isError,
    ).toBe(false);
    expect(
      (
        await t.call("test_bind_check", {
          check_index: 0,
          assertion: {
            observation_ref: "step_1.response.status",
            operator: "eq",
            expected_value: "200",
          },
        })
      ).isError,
    ).toBe(false);
    await t.call("test_finish_step");
    expect((await t.call("test_finish")).value.statistics.PASS).toBe(1);
    expect(spy).toHaveBeenCalledOnce();
    expect(t.dispatched.some((n) => n.includes("playwright"))).toBe(false);
    expect(run.run.instances[0].effective_required_assertion_ids).toEqual([
      "step_2_check_1",
      "step_2_check_2",
    ]);
    expect(
      run.run.instances[0].steps
        .filter((s) => s.assertion)
        .map((s) => s.step_id),
    ).toEqual(["step_2_check_1", "step_2_check_2"]);
    await t.end();
  } finally {
    spy.mockRestore();
  }
});

it("文件与CSV四实例只在完整原生审核后执行，参数、证据和失败状态相互隔离", async () => {
  const { createTextInput, parseCases } = await import(
    "../../src/case-input.js"
  );
  const source = createTextInput(
    parseCases(
      "请求https://httpbin.org/get?keyword=${keyword}，核对keyword为${keyword}\n再次请求并核对keyword为${keyword}",
      ".txt",
    ),
    { path: "data.csv", content: "keyword\nagent\ntesting" },
  );
  const t = setup();
  const fetchSpy = vi.spyOn(globalThis, "fetch");
  try {
    await t.manager.start(
      t.agent,
      "data.csv --file cases.txt",
      undefined,
      true,
      source,
    );
    const draft = {
      name: "四实例",
      cases: source.instances.map((i) => ({
        instance_id: i.id,
        name: i.id,
        steps: [
          {
            description: i.task,
            checks: ["keyword等于" + i.parameters.keyword],
          },
        ],
      })),
    };
    const first = await t.call("test_submit_plan", draft);
    expect(first.value.phase).toBe("reviewing");
    expect(fetchSpy).not.toHaveBeenCalled();
    expect(
      (
        await t.call("test_define_step", {
          capability: "api",
          allowed_targets: ["https://httpbin.org"],
          reason: "提前请求",
        })
      ).isError,
    ).toBe(true);
    t.definitions.set("exit_plan_mode", {
      execute: () => ({ approved: true }),
    });
    const updated = structuredClone(draft);
    updated.cases[0]!.steps[0]!.description += "，在运行时决定字段";
    const second = await t.call("test_submit_plan", updated);
    expect(
      (await t.call("exit_plan_mode", { plan: first.value.review_markdown }))
        .isError,
    ).toBe(true);
    expect(
      (await t.call("exit_plan_mode", { plan: second.value.review_markdown }))
        .isError,
    ).toBe(false);
    const run = t.manager.sessions.get("origin")!;
    const frozen = structuredClone(run.run.plan);
    for (const [n, i] of source.instances.entries()) {
      expect(run.state().current!.instance).toBe(i.id + "--row_" + i.data_row);
      fetchSpy.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            args: { keyword: n === 1 ? "wrong" : i.parameters.keyword },
          }),
          { status: 200 },
        ),
      );
      expect(
        (
          await t.call("test_define_step", {
            capability: "api",
            allowed_targets: ["https://httpbin.org"],
            reason: "执行当前实例",
          })
        ).isError,
      ).toBe(false);
      expect(
        (
          await t.call("test_capture", {
            capture: {
              response: {
                kind: "http",
                url: "https://httpbin.org/get?keyword=" + i.parameters.keyword,
                field: "",
              },
            },
            reason: "请求并采集当前参数对应的响应",
          })
        ).isError,
      ).toBe(false);
      const id = run.state().current!.step.step_id;
      expect(
        (
          await t.call("test_bind_check", {
            check_index: 0,
            assertion: {
              observation_ref: id + ".response.body.args.keyword",
              operator: "eq",
              expected_value: i.parameters.keyword,
            },
          })
        ).isError,
      ).toBe(false);
      expect((await t.call("test_finish_step")).isError).toBe(false);
    }
    const final = await t.call("test_finish");
    expect(final.value.statistics).toMatchObject({
      total: 4,
      PASS: 3,
      FAIL: 1,
    });
    expect(fetchSpy).toHaveBeenCalledTimes(4);
    expect(t.dispatched.some((name) => name.includes("playwright"))).toBe(
      false,
    );
    expect(run.run.plan).toEqual(frozen);
    expect(await rebuild(run.recorder.directory)).toEqual(run.run);
    const html = readFileSync(
      join(run.recorder.directory, "report.html"),
      "utf8",
    );
    expect(html).toContain("原始用例 2 条 · CSV 数据 2 行 · 执行实例 4 个");
    expect(html).toContain("用例来源与参数");
    expect(html).toContain('data-case="case_1"');
    expect(html).toContain('data-case="case_2"');
    await t.end();
  } finally {
    fetchSpy.mockRestore();
  }
});

it("两个文字浏览器实例分别初始化清理，第一例失败不污染下一例的断言", async () => {
  const { createTextInput, parseCases } = await import(
    "../../src/case-input.js"
  );
  const source = createTextInput(
    parseCases("检查第一页点赞不为0\n检查第二页点赞不为0", ".txt"),
  );
  const t = setup();
  await t.manager.start(t.agent, "cases.txt", undefined, false, source);
  const submitted = await t.call("test_submit_plan", {
    name: "浏览器集合",
    cases: source.instances.map((i) => ({
      instance_id: i.id,
      name: i.id,
      steps: [{ description: i.task, checks: ["点赞数不为0"] }],
    })),
  });
  await t.announce(submitted.value.plan_summary);
  const run = t.manager.sessions.get("origin")!;
  for (const likes of [0, 3]) {
    expect(
      (
        await t.call("test_define_step", {
          capability: "browser",
          allowed_targets: ["https://example.test"],
          reason: "当前实例读取点赞",
        })
      ).isError,
    ).toBe(false);
    t.setDomResult({ values: { likes } });
    expect(
      (
        await t.call("test_capture", {
          capture: {
            likes: { kind: "dom", mode: "number", selector: "#likes" },
          },
          reason: "当前页面点赞",
        })
      ).isError,
    ).toBe(false);
    const step = run.state().current!.step.step_id;
    expect(
      (
        await t.call("test_bind_check", {
          check_index: 0,
          assertion: {
            observation_ref: step + ".likes",
            operator: "neq",
            expected_value: "0",
          },
        })
      ).isError,
    ).toBe(false);
    await t.call("test_finish_step");
    expect(run.state().current!.step.step_id).toBe("__close");
    await t.step();
  }
  expect((await t.call("test_finish")).value.statistics).toMatchObject({
    total: 2,
    FAIL: 1,
    PASS: 1,
  });
  expect(
    t.dispatched.filter((name) => name.endsWith("browser_close")),
  ).toHaveLength(4);
  expect(
    run.run.instances.every(
      (i) => i.resources.browser_context.state === "absent",
    ),
  ).toBe(true);
});

it("Markdown无参数时不要求通报空对象，缺少实质内容仍明确拦截", async () => {
  const { createTextInput, parseCases } = await import(
    "../../src/case-input.js"
  );
  const source = createTextInput(
    parseCases("- 访问页面，检查点赞不为0", ".md"),
  );
  const t = setup();
  await t.manager.start(t.agent, "cases.md", undefined, false, source);
  const submitted = await t.call("test_submit_plan", {
    name: "MD",
    cases: [
      {
        instance_id: "case_1",
        name: "页面",
        steps: [{ description: "读取点赞", checks: ["点赞数不为0"] }],
      },
    ],
  });
  const args = {
    capability: "browser",
    allowed_targets: ["https://example.test"],
    reason: "读取",
  };
  const rejected = await t.call("test_define_step", args);
  expect(rejected.content[0].text).toContain("缺少");
  await t.announce(submitted.value.plan_summary.replaceAll("```\n{}\n```", ""));
  expect((await t.call("test_define_step", args)).isError).toBe(false);
});

it("CSV审核前取消保留全部未执行实例，不请求接口或派发清理", async () => {
  const { createTextInput, parseCases } = await import(
    "../../src/case-input.js"
  );
  const source = createTextInput(parseCases("验证${x}\n再次验证${x}", ".txt"), {
    path: "data.csv",
    content: "x\n001\n002",
  });
  const t = setup();
  await t.manager.start(
    t.agent,
    "data.csv --file cases.txt",
    undefined,
    true,
    source,
  );
  const run = t.manager.sessions.get("origin")!;
  run.stop();
  await t.end(true);
  expect(run.closed).toBe(true);
  expect(run.run.instances).toHaveLength(4);
  expect(
    run.run.instances.every(
      (i) => i.status === "CANCELLED" && i.steps.length === 0,
    ),
  ).toBe(true);
  expect(run.run.manifest.plan_approved).toBe(false);
  expect(t.dispatched).toEqual([]);
  expect(
    readFileSync(join(run.recorder.directory, "report.html"), "utf8"),
  ).toContain("计划未获批准");
});

it("进度只属于原会话，准备清理与业务分别呈现；读状态不会派发工具", async () => {
  const t = setup(3);
  await t.manager.start(t.agent, "点赞不为0", sample());
  const dispatched = t.dispatched.length;
  expect(t.manager.presentation("other-session")).toBeNull();
  expect(t.manager.presentation("origin")).toMatchObject({
    session_id: "origin",
    total_steps: 2,
    settled_steps: 0,
  });
  expect(t.dispatched).toHaveLength(dispatched);
  await t.step();
  expect(t.manager.presentation("origin")).toMatchObject({
    current_step_id: "read",
    phase: "executing",
  });
  await t.step();
  expect(t.manager.presentation("origin")).toMatchObject({
    phase: "cleanup",
    settled_steps: 2,
  });
  await t.step();
  await t.call("test_finish");
  const state = t.manager.presentation("origin")!;
  expect(state).toMatchObject({
    phase: "finished",
    settled_steps: 2,
    total_steps: 2,
  });
  expect(state.instances[0]?.setup).toHaveLength(1);
  expect(state.instances[0]?.cleanup).toHaveLength(1);
  expect(state.report_url).toContain("report.html");
  expect((await t.manager.preview.state(state.run_id)).ready).toBe(false);
  await t.end();
});

it("预览接入准备也保持互斥，不能在准备过程中启动第二条测试", async () => {
  let release!: () => void;
  const prepare = vi.fn(
    () =>
      new Promise<void>((done) => {
        release = done;
      }),
  );
  const t = setup(3, prepare);
  const first = t.manager.start(t.agent, "检查预览准备", sample());
  expect(prepare).toHaveBeenCalledTimes(1);
  expect(t.manager.sessions.size).toBe(0);
  await expect(
    t.manager.start({ ...t.agent, id: "other" }, "另一条测试", sample()),
  ).rejects.toThrow("已有测试");
  release();
  await first;
  expect(t.manager.sessions.size).toBe(1);
});

async function remoteSetup(hub = false) {
  const { RunBridge } = await import("../../src/runbridge.js");
  const { writeFileSync } = await import("node:fs");
  const { browserPreferenceDefaults } = await import(
    "../../src/browser-preferences.js"
  );
  const t = setup();
  const access = join(t.root, "access.json");
  writeFileSync(
    access,
    JSON.stringify({
      hub_url: "http://hub.test",
      node_id: "node_own",
      grant_id: "grant_own",
      access_token: "x".repeat(48),
    }),
  );
  t.manager.config.browser = {
    ...browserPreferenceDefaults,
    backend: "runbridge",
    accessFile: access,
    previewEnabled: false,
  };
  if (hub) {
    const hubFile = join(t.root, "hub.yaml");
    writeFileSync(
      hubFile,
      'hub_url: "http://hub.test"\nhub_token: "' + "h".repeat(48) + '"\n',
    );
    Object.assign(t.manager.config.browser!, {
      connectionSource: "hub",
      hubFile,
      nodeId: "node_own",
    });
  }
  let claimHandler: (() => Promise<Response>) | undefined;
  let releaseHandler: (() => Promise<Response>) | undefined;
  let cleanup = "COMPLETE";
  const session = {
    session_id: "session_own",
    node_id: "node_own",
    grant_id: "grant_own",
    resource_id: "chromium",
    connection_generation: 2,
    state: "ACTIVE",
    cleanup: "PENDING",
  };
  const remoteTools = [
    "browser_start",
    "browser_stop",
    "browser_capture",
    "browser_click",
    "browser_select_option",
    "browser_screenshot",
  ].map((name) => ({
    name,
    inputSchema: {
      type: "object",
      properties: {
        values: { type: "array", items: { type: "string" } },
        target: { type: "object" },
        captures: { type: "object" },
        allowed_origins: { type: "array", items: { type: "string" } },
        full_page: { type: "boolean" },
      },
      additionalProperties: false,
    },
  }));
  const wire = vi.fn(async ({ name }: any) => {
    const data =
      name === "browser_start"
        ? { session, page_id: "page_own" }
        : name === "browser_stop"
          ? { session: { ...session, state: "CLOSED", cleanup } }
          : name === "browser_capture"
            ? {
                url: "https://example.test/",
                truncated: false,
                values: { likes: 3 },
              }
            : { completed: true };
    return {
      content: [{ type: "text", text: JSON.stringify(data) }],
      structuredContent: data,
    };
  });
  const leaseState = (ended = false) => ({
    node_id: "node_own",
    grant_id: "grant_own",
    state: ended ? "RELEASED" : "HELD",
    cleanup: "COMPLETE",
    expires_at: new Date(Date.now() + 3600000).toISOString(),
    idle_deadline_at: new Date(Date.now() + 600000).toISOString(),
    inflight: false,
    close_reason: ended ? "RELEASED_BY_HOLDER" : null,
  });
  const originalFetch = globalThis.fetch;
  const leaseHttp = vi
    .spyOn(globalThis, "fetch")
    .mockImplementation(async (input, init) => {
      const url = new URL(String(input));
      if (url.host === "api.test")
        return new Response(JSON.stringify({ likes: 3 }));
      if (url.host !== "hub.test") return originalFetch(input, init);
      if (url.pathname === "/v1/pool/nodes/node_own/tools")
        return new Response(
          JSON.stringify({
            node: { node_id: "node_own" },
            tools: remoteTools,
          }),
        );
      if (url.pathname === "/v1/nodes/node_own/grants") {
        if (claimHandler) return claimHandler();
        const state = leaseState();
        return new Response(
          JSON.stringify({
            ...state,
            token_available: true,
            access_token: "x".repeat(48),
            access_config: {
              hub_url: "http://hub.test",
              node_id: "node_own",
              grant_id: "grant_own",
              access_token: "x".repeat(48),
              expires_at: state.expires_at,
            },
          }),
          { status: 201 },
        );
      }
      if (url.pathname === "/v1/grants/grant_own") {
        if (init?.method === "DELETE" && releaseHandler)
          return releaseHandler();
        return new Response(
          JSON.stringify(leaseState(init?.method === "DELETE")),
        );
      }
      throw new Error("本夹具未授权的 HTTP 路径");
    });
  cleanups.push(() => leaseHttp.mockRestore());
  const spy = vi
    .spyOn(RunBridge.prototype, "connect")
    .mockImplementation(async function (this: RunBridge) {
      const internal = this as any;
      internal.connected = true;
      internal.client.callTool = wire;
      internal.definitions = remoteTools;
    });
  cleanups.push(() => spy.mockRestore());
  return {
    ...t,
    wire,
    leaseHttp,
    connectSpy: spy,
    leaseState,
    setClaimHandler: (handler: () => Promise<Response>) => {
      claimHandler = handler;
    },
    setReleaseHandler: (handler: () => Promise<Response>) => {
      releaseHandler = handler;
    },
    setCleanup: (value: string) => {
      cleanup = value;
    },
  };
}

it("远程后端在可信初始化中申请资源，旧 MCP 和直接生命周期调用被拒绝，原生操作绑定本会话", async () => {
  const t = await remoteSetup();
  await t.manager.start(t.agent, "读取并检查点赞", sample());
  const test = t.manager.sessions.get("origin")!;
  expect(t.wire).not.toHaveBeenCalled();
  expect((await t.call("mcp__playwright__browser_click")).isError).toBe(true);
  expect((await t.call("mcp__runbridge__browser_start")).isError).toBe(true);
  expect(t.wire).not.toHaveBeenCalled();
  await t.step();
  expect(
    test.run.instances[0].resources.browser_context?.remote?.session_id,
  ).toBe("session_own");
  const op = await t.call("test_execute_operation", {
    description: "点击唯一按钮",
    tool_name: "mcp__runbridge__browser_click",
    arguments: { target: { by: "css", value: "#button" } },
  });
  expect(op.isError).toBe(false);
  expect(t.wire.mock.calls.at(-1)![0].arguments).toMatchObject({
    session_id: "session_own",
    page_id: "page_own",
  });
  expect(test.run.instances[0].steps.at(-1)?.actual_operations?.[0].state).toBe(
    "SUCCEEDED",
  );
  const invalid = await t.call("test_execute_operation", {
    description: "选择类型",
    tool_name: "mcp__runbridge__browser_select_option",
    arguments: {
      target: { by: "css", value: "#category" },
      values: { item: "api" },
    },
  });
  expect(invalid.isError).toBe(true);
  const count = t.wire.mock.calls.length;
  const valid = await t.call("test_execute_operation", {
    description: "选择接口",
    tool_name: "mcp__runbridge__browser_select_option",
    arguments_json: JSON.stringify({
      target: { by: "css", value: "#category" },
      values: ["api"],
    }),
  });
  expect(valid.isError).toBe(false);
  expect(t.wire.mock.calls).toHaveLength(count + 1);
  expect(t.wire.mock.calls.at(-1)![0].arguments.values).toEqual(["api"]);
  await t.step();
  expect(test.state().phase).toBe("cleanup");
  await t.step();
  await t.call("test_finish");
  expect(test.run.instances[0].status).toBe("PASS");
  expect(test.run.instances[0].resources.browser_context?.state).toBe("absent");
  expect(test.run.manifest.plugin_version).toBe(
    JSON.parse(
      readFileSync(new URL("../../package.json", import.meta.url), "utf8"),
    ).version,
  );
  expect(JSON.stringify(test.state())).not.toContain("access.json");
});

it.each(["FAILED", "NOT_FOUND"])(
  "远程初始化响应丢失后原请求为 %s，原生收尾仅凭确定未分配证据释放",
  async (state) => {
    const t = await remoteSetup();
    await t.manager.start(t.agent, "读取并检查点赞", sample());
    const test = t.manager.sessions.get("origin")!;
    t.wire.mockRejectedValueOnce(new Error("lost start response"));
    expect((await t.call("test_capture")).isError).toBe(true);
    expect(test.run.instances[0].resources.browser_context?.state).toBe(
      "unknown",
    );
    await t.call("test_fail_step", {
      reason: "初始化结果未知，先按原请求核对",
    });
    expect(test.state().phase).toBe("cleanup");
    const request = {
      request_id:
        test.run.instances[0].resources.browser_context?.remote?.request_id,
      node_id: "node_own",
      grant_id: "grant_own",
      state,
      session_id: null,
      error_code: "RESOURCE_BUSY",
      execution_outcome: "NOT_STARTED",
    };
    t.wire.mockResolvedValueOnce({
      content: [
        { type: "text", text: JSON.stringify({ request, sessions: [] }) },
      ],
      structuredContent: { request, sessions: [] },
    } as any);
    if (state === "FAILED") {
      await t.step();
      expect(test.run.instances[0].resources.browser_context?.state).toBe(
        "absent",
      );
      const cleanup = test.run.instances[0].steps.find(
        (step) => step.phase === "cleanup",
      )!;
      expect(cleanup.observations[0].producer.field).toContain(
        "execution_outcome=NOT_STARTED",
      );
      const evidence = test.run.evidence.find(
        (item) => item.evidence_id === cleanup.observations[0].evidence_refs[0],
      )!;
      expect(
        readFileSync(
          join(t.root, test.run.suite_run_id, evidence.relative_path),
          "utf8",
        ),
      ).toContain(request.request_id!);
      expect(test.run.resource_quarantined).toBe(false);
    } else {
      expect((await t.call("test_capture")).isError).toBe(true);
      await t.call("test_fail_step", { reason: "无记录不能证明未分配" });
      expect(test.run.instances[0].resources.browser_context?.state).toBe(
        "unknown",
      );
      expect(test.run.resource_quarantined).toBe(true);
    }
    await t.call("test_finish");
    expect(
      test.run.instances[0].steps.find((step) => step.phase === "setup")
        ?.status,
    ).toBe("ERROR");
    if (state === "FAILED") expect(test.run.instances[0].status).toBe("ERROR");
    else expect(test.run.instances[0].status).not.toBe("PASS");
    expect(t.wire.mock.calls.map(([input]) => input.name)).toEqual([
      "browser_start",
      "browser_sessions",
    ]);
  },
);

it("远程写响应丢失记录 UNKNOWN；清理 UNKNOWN 不得解除隔离或伪造 PASS", async () => {
  const t = await remoteSetup();
  await t.manager.start(t.agent, "点击后核对", sample());
  await t.step();
  const test = t.manager.sessions.get("origin")!;
  t.wire.mockRejectedValueOnce(new Error("network"));
  expect(
    (
      await t.call("test_execute_operation", {
        description: "点击保存",
        tool_name: "mcp__runbridge__browser_click",
        arguments: { target: { by: "css", value: "#save" } },
      })
    ).isError,
  ).toBe(true);
  expect(test.run.instances[0].steps.at(-1)?.actual_operations?.[0].state).toBe(
    "UNKNOWN",
  );
  await t.step();
  t.setCleanup("UNKNOWN");
  expect((await t.call("test_capture")).isError).toBe(true);
  await t.call("test_fail_step", { reason: "节点清理未确认" });
  await t.call("test_finish");
  expect(test.run.resource_quarantined).toBe(true);
  expect(test.run.instances[0].resources.browser_context?.state).toBe(
    "unknown",
  );
  expect(test.run.instances[0].status).not.toBe("PASS");
});

it("Hub 模式审核与取消只读目录，批准本身也不会提前领取设备", async () => {
  const t = await remoteSetup(true);
  await t.manager.start(t.agent, "核对点赞", undefined, true);
  const submitted = await t.call("test_submit_plan", reviewPlan());
  expect(submitted.isError).toBe(false);
  expect(
    (
      await t.call("test_define_step", {
        capability: "browser",
        allowed_targets: ["https://example.test"],
        reason: "不得在审核前执行",
      })
    ).isError,
  ).toBe(true);
  expect(t.leaseHttp.mock.calls.map(([, init]) => init?.method)).toEqual([
    "GET",
  ]);
  expect(t.connectSpy).not.toHaveBeenCalled();
  t.definitions.set("exit_plan_mode", { execute: () => ({ approved: true }) });
  await t.call("exit_plan_mode", { plan: submitted.value.review_markdown });
  expect(t.leaseHttp.mock.calls.map(([, init]) => init?.method)).toEqual([
    "GET",
  ]);
  const run = t.manager.sessions.get("origin")!;
  run.stop();
  await t.end(true);
  expect(run.closed).toBe(true);
  expect(run.run.node_lease).toBeUndefined();
  expect(t.connectSpy).not.toHaveBeenCalled();
});
it("Hub 模式的纯接口计划不领取、不续租、不释放 Node，也不建立执行 MCP", async () => {
  const t = await remoteSetup(true),
    plan = sample();
  const action = plan.cases[0].steps[0].action!;
  action.capability = "api";
  action.allowed_targets = ["https://api.test"];
  action.capture = {
    likes: { kind: "http", url: "https://api.test/get", field: "body.likes" },
  } as any;
  await t.manager.start(t.agent, "只检查接口", plan);
  expect((await t.call("mcp__runbridge__browser_screenshot")).isError).toBe(
    true,
  );
  await t.step();
  expect((await t.call("test_finish")).isError).toBe(false);
  const run = t.manager.sessions.get("origin")!;
  expect(run.run.instances[0].status).toBe("PASS");
  expect(run.run.node_lease).toBeUndefined();
  expect(t.connectSpy).not.toHaveBeenCalled();
  expect(
    t.leaseHttp.mock.calls.filter(([url]) => String(url).includes("/grants")),
  ).toHaveLength(0);
});
it("Hub 整批两实例只领取一次，逐用例关闭浏览器，报告前才归还 Node", async () => {
  const t = await remoteSetup(true),
    plan = sample();
  plan.cases[0].datasets.push({
    data_id: "b",
    inputs: {},
    expected: { likes: 0 },
  });
  await t.manager.start(t.agent, "两实例", plan);
  const run = t.manager.sessions.get("origin")!;
  expect(run.run.node_lease).toBeUndefined();
  for (let i = 0; i < 6; i++) await t.step();
  expect(
    t.wire.mock.calls.filter(([input]) => input.name === "browser_start"),
  ).toHaveLength(2);
  expect(
    t.wire.mock.calls.filter(([input]) => input.name === "browser_stop"),
  ).toHaveLength(2);
  expect(
    t.leaseHttp.mock.calls.filter(([url]) =>
      String(url).endsWith("/nodes/node_own/grants"),
    ),
  ).toHaveLength(1);
  expect(
    t.leaseHttp.mock.calls.filter(([, init]) => init?.method === "DELETE"),
  ).toHaveLength(0);
  expect(run.run.node_lease?.state).toBe("HELD");
  const file = run.run.node_lease!.access_file!;
  expect(file).not.toContain(run.recorder.directory + "/");
  expect(existsSync(file)).toBe(true);
  await t.call("test_finish");
  expect(run.run.node_lease).toMatchObject({
    state: "RELEASED",
    cleanup: "COMPLETE",
  });
  expect(existsSync(file)).toBe(false);
  expect(
    t.leaseHttp.mock.calls.filter(([, init]) => init?.method === "DELETE"),
  ).toHaveLength(1);
  expect(JSON.stringify(run.state())).not.toContain("x".repeat(48));
  expect(JSON.stringify(run.state())).not.toContain("h".repeat(48));
  expect(JSON.stringify(run.state())).not.toContain(".runbridge-access");
  expect((await rebuild(run.recorder.directory)).node_lease).toEqual(
    run.run.node_lease,
  );
});
it("报告封存和下一批启动都等待异步 Node 释放，不把浏览器 COMPLETE 当作整 Node 归还", async () => {
  const t = await remoteSetup(true);
  await t.manager.start(t.agent, "等待归还", sample());
  const run = t.manager.sessions.get("origin")!;
  for (let i = 0; i < 3; i++) await t.step();
  let release!: (response: Response) => void;
  const called = vi.fn();
  t.setReleaseHandler(() => {
    called();
    return new Promise<Response>((done) => {
      release = done;
    });
  });
  const pending = t.call("test_finish");
  await vi.waitFor(() => expect(called).toHaveBeenCalledOnce());
  expect(run.run.lifecycle).toBe("RUNNING");
  expect(existsSync(join(run.recorder.directory, "report.html"))).toBe(false);
  await expect(
    t.manager.start(
      { ...t.agent, id: "other", status: "idle" },
      "下一批",
      sample(),
    ),
  ).rejects.toThrow("已有测试");
  release(new Response(JSON.stringify(t.leaseState(true))));
  expect((await pending).isError).toBe(false);
  expect(run.run.lifecycle).toBe("FINISHED");
  expect(
    readFileSync(join(run.recorder.directory, "report.html"), "utf8"),
  ).toContain("Node 使用权：已归还");
});
it("节点清理 UNKNOWN 时仍保留原业务断言并隔离，恢复令牌不删除", async () => {
  const t = await remoteSetup(true);
  await t.manager.start(t.agent, "业务成功但设备待核查", sample());
  const run = t.manager.sessions.get("origin")!;
  for (let i = 0; i < 3; i++) await t.step();
  t.setReleaseHandler(
    async () =>
      new Response(
        JSON.stringify({
          ...t.leaseState(true),
          state: "QUARANTINED",
          cleanup: "UNKNOWN",
        }),
      ),
  );
  await t.call("test_finish");
  await t.end();
  expect(run.run.node_lease).toMatchObject({
    state: "QUARANTINED",
    cleanup: "UNKNOWN",
  });
  expect(run.run.resource_quarantined).toBe(true);
  expect(
    run.run.instances[0].steps.find((step) => step.assertion)?.assertion
      ?.status,
  ).toBe("PASS");
  expect(existsSync(run.run.node_lease!.access_file!)).toBe(true);
  expect(t.manager.recovery.status().quarantine?.can_recover).toBe(true);
  expect(
    readFileSync(join(run.recorder.directory, "report.html"), "utf8"),
  ).toContain("归还未获确认");
});
it("领取响应丢失先保留原请求记录，不重放领取，报告与恢复保持未知隔离", async () => {
  const t = await remoteSetup(true);
  await t.manager.start(t.agent, "响应丢失", sample());
  const run = t.manager.sessions.get("origin")!;
  t.setClaimHandler(async () => {
    expect(
      JSON.parse(
        readFileSync(join(run.recorder.directory, "results.json"), "utf8"),
      ).node_lease.state,
    ).toBe("CLAIMING");
    throw new Error("h".repeat(48));
  });
  expect((await t.call("test_capture")).isError).toBe(true);
  expect((await t.call("test_capture")).isError).toBe(true);
  expect(
    t.leaseHttp.mock.calls.filter(([url]) =>
      String(url).endsWith("/nodes/node_own/grants"),
    ),
  ).toHaveLength(1);
  await t.call("test_fail_step", { reason: "领取结果未知，不能继续业务" });
  await t.call("test_finish");
  expect(run.run.node_lease?.state).toBe("UNKNOWN");
  expect(run.run.resource_quarantined).toBe(true);
  expect(t.manager.recovery.status().quarantine?.can_recover).toBe(false);
  expect(JSON.stringify(run.run)).not.toContain("h".repeat(48));
});

it("旧浏览器 UNKNOWN 隔离在 Node 已归还后仍保留恢复凭据，用户确认原租约后才回收", async () => {
  const t = await remoteSetup(true);
  await t.manager.start(t.agent, "保留原隔离", sample());
  const run = t.manager.sessions.get("origin")!;
  await t.step();
  await t.step();
  t.setCleanup("UNKNOWN");
  expect((await t.call("test_capture")).isError).toBe(true);
  await t.call("test_fail_step", { reason: "原浏览器清理未知，不得改写" });
  await t.end(true);
  expect(run.run.node_lease).toMatchObject({
    state: "RELEASED",
    cleanup: "COMPLETE",
  });
  expect(run.run.resource_quarantined).toBe(true);
  const file = run.run.node_lease!.access_file!;
  expect(existsSync(file)).toBe(true);
  const original = readFileSync(
    join(run.recorder.directory, "results.json"),
    "utf8",
  );
  const marker = t.manager.recovery.status().quarantine!;
  expect(marker.can_recover).toBe(true);
  await t.manager.recovery.recover(
    t.agent,
    marker.token,
    new AbortController().signal,
  );
  expect(existsSync(file)).toBe(false);
  expect(t.manager.recovery.status().quarantine).toBeNull();
  expect(
    readFileSync(join(run.recorder.directory, "results.json"), "utf8"),
  ).toBe(original);
});
