import { afterEach, expect, it } from "vitest";
import { Writable } from "node:stream";
import {
  mkdtempSync,
  mkdirSync,
  copyFileSync,
  writeFileSync,
  rmSync,
  readFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { ReportAccess } from "../../src/report-access.js";
const roots: string[] = [];
afterEach(() =>
  roots.splice(0).forEach((r) => rmSync(r, { recursive: true, force: true })),
);
function setup() {
  const root = mkdtempSync(join(tmpdir(), "video-http-"));
  roots.push(root);
  const dir = join(root, "run-one/evidence");
  mkdirSync(dir, { recursive: true });
  copyFileSync(
    new URL("../fixtures/minimal.mp4", import.meta.url),
    join(dir, "browser-one.mp4"),
  );
  writeFileSync(
    join(root, "run-one/report.html"),
    '<video src="evidence/browser-one.mp4" controls></video><a href="evidence/browser-one.mp4?download=1" download>下载视频</a>',
  );
  writeFileSync(join(root, "run-one/events.jsonl"), '{"seq":0}\n');
  return {
    access: new ReportAccess(root),
    bytes: readFileSync(join(dir, "browser-one.mp4")),
  };
}
async function request(
  access: ReportAccess,
  url: string,
  range?: string,
  method = "GET",
) {
  let status = 200;
  const headers: Record<string, string> = {};
  const chunks: Buffer[] = [];
  const res: any = new Writable({
    write(chunk, _encoding, done) {
      chunks.push(Buffer.from(chunk));
      done();
    },
  });
  res.statusCode = 200;
  res.setHeader = (k: string, v: string) => (headers[k] = String(v));
  res.writeHead = (code: number, values: Record<string, string> = {}) => {
    status = code;
    Object.assign(headers, values);
  };
  const pending = new Promise<void>((done, reject) => {
    res.once("finish", done);
    res.once("error", reject);
  });
  access.serve({ url, method, headers: range ? { range } : {} } as never, res);
  await pending;
  return {
    status: status === 200 ? res.statusCode : status,
    headers,
    body: Buffer.concat(chunks),
  };
}
it.each([
  [undefined, 200, 0, 1507],
  ["bytes=0-99", 206, 0, 99],
  ["bytes=1400-", 206, 1400, 1507],
  ["bytes=-10", 206, 1498, 1507],
])("整文件与单段 %s 支持流式播放", async (range, status, start, end) => {
  const t = setup();
  const r = await request(
    t.access,
    "/test-reports/run-one/evidence/browser-one.mp4",
    range,
  );
  expect(r.status).toBe(status);
  expect(r.body).toEqual(t.bytes.subarray(start, end + 1));
  expect(r.headers["Content-Type"]).toBe("video/mp4");
  expect(r.headers["Accept-Ranges"]).toBe("bytes");
  expect(Number(r.headers["Content-Length"])).toBe(end - start + 1);
});
it.each(["bytes=2000-", "bytes=20-10", "bytes=-0"])(
  "无效区间 %s 返回416",
  async (range) => {
    expect(
      (
        await request(
          setup().access,
          "/test-reports/run-one/evidence/browser-one.mp4",
          range,
        )
      ).status,
    ).toBe(416);
  },
);
it("HEAD 不传输视频，越界文件仍拒绝", async () => {
  const t = setup();
  const r = await request(
    t.access,
    "/test-reports/run-one/evidence/browser-one.mp4",
    undefined,
    "HEAD",
  );
  expect(r.body.length).toBe(0);
  expect(Number(r.headers["Content-Length"])).toBe(t.bytes.length);
  expect(
    (await request(t.access, "/test-reports/run-one/evidence/../../secret.mp4"))
      .status,
  ).toBe(404);
});
it("下载链接给出附件响应，并持有同一个文件的只读票据", async () => {
  const t = setup();
  const report = await request(t.access, "/test-reports/run-one/report.html");
  const url = report.body
    .toString()
    .match(/href="([^"]+)"/)![1]
    .replaceAll("&amp;", "&");
  const req = { url: "/test-reports/run-one/" + url, method: "GET" } as never;
  expect(t.access.authorizeFile(req)).toBe(true);
  const r = await request(t.access, (req as any).url);
  expect(r.headers["Content-Disposition"]).toBe(
    'attachment; filename="browser-one.mp4"',
  );
  expect(r.body).toEqual(t.bytes);
});
it("报告在认证后的响应里签发文件专用票据，不能用来访问其他文件或写入", async () => {
  const t = setup();
  const report = await request(t.access, "/test-reports/run-one/report.html");
  const url = report.body.toString().match(/src="([^"]+)"/)![1];
  const req = { url: "/test-reports/run-one/" + url, method: "GET" } as never;
  expect(t.access.authorizeFile(req)).toBe(true);
  expect(
    t.access.authorizeFile({
      ...(req as any),
      url: (req as any).url.replace("browser-one", "browser-other"),
    }),
  ).toBe(false);
  expect(t.access.authorizeFile({ ...(req as any), method: "POST" })).toBe(
    false,
  );
  expect(
    t.access.authorizeFile({
      ...(req as any),
      url: (req as any).url.replace(".mp4", ".json"),
    }),
  ).toBe(false);
  expect(
    t.access.authorizeFile({
      ...(req as any),
      url: (req as any).url.replace(/media=.*/, "media=1." + "a".repeat(64)),
    }),
  ).toBe(false);
  expect(report.headers["Content-Security-Policy"]).toContain("sandbox");
  expect(report.headers["Content-Security-Policy"]).toContain(
    "media-src 'self'",
  );
});

it("账本以独立流式附件下载，票据只准入指定运行文件和GET/HEAD", async () => {
  const t = setup();
  const directory = join(roots.at(-1)!, "run-one");
  writeFileSync(
    join(directory, "report.html"),
    '<a href="events.jsonl?download=1" download>账本</a>',
  );
  const report = await request(t.access, "/test-reports/run-one/report.html");
  const link = report.body
    .toString()
    .match(/href="([^"]+)"/)![1]
    .replaceAll("&amp;", "&");
  const url = "/test-reports/run-one/" + link;
  expect(t.access.authorizeFile({ url, method: "GET" } as never)).toBe(true);
  expect(t.access.authorizeFile({ url, method: "HEAD" } as never)).toBe(true);
  for (const invalid of [
    url.replace("run-one", "run-other"),
    url.replace("events.jsonl", "results.json"),
    url.replace("events.jsonl", "events.jsonl.gz"),
  ])
    expect(
      t.access.authorizeFile({ url: invalid, method: "GET" } as never),
    ).toBe(false);
  expect(t.access.authorizeFile({ url, method: "POST" } as never)).toBe(false);
  const download = await request(t.access, url);
  expect(download.body.toString()).toBe('{"seq":0}\n');
  expect(download.headers["Content-Disposition"]).toContain("attachment");
  const head = await request(t.access, url, undefined, "HEAD");
  expect(head.body.length).toBe(0);
  expect(Number(head.headers["Content-Length"])).toBe(download.body.length);
  expect(readFileSync(join(directory, "report.html"), "utf8")).not.toContain(
    "media=",
  );
});

it("手工用例独立下载，原始资料不开放；票据不能换实例、文件或写入", async () => {
  const t = setup();
  const directory = join(roots.at(-1)!, "run-one");
  const manual = "# 用例名称：登录\n\n| 1 | 输入 qa_user_1 |  |\n";
  writeFileSync(join(directory, "manual-cases-1.md"), manual);
  writeFileSync(join(directory, "manual-source.json"), '{"private":true}');
  writeFileSync(
    join(directory, "report.html"),
    '<a href="manual-cases-1.md?download=1" download>手工用例</a>',
  );
  const report = await request(t.access, "/test-reports/run-one/report.html");
  const link = report.body
    .toString()
    .match(/href="([^"]+)"/)![1]
    .replaceAll("&amp;", "&");
  const url = "/test-reports/run-one/" + link;
  expect(t.access.authorizeFile({ url, method: "GET" } as never)).toBe(true);
  expect(t.access.authorizeFile({ url, method: "HEAD" } as never)).toBe(true);
  expect(t.access.authorizeFile({ url, method: "POST" } as never)).toBe(false);
  for (const target of [
    url.replace("-1.md", "-2.md"),
    url.replace("-1.md", "-1-rebuilt.md"),
    url.replace("manual-cases-1.md", "manual-source.json"),
  ])
    expect(
      t.access.authorizeFile({ url: target, method: "GET" } as never),
    ).toBe(false);
  const file = await request(t.access, url);
  expect(file.body.toString()).toBe(manual);
  expect(file.headers["Content-Disposition"]).toContain("attachment");
  expect(
    (await request(t.access, "/test-reports/run-one/manual-source.json"))
      .status,
  ).toBe(404);
  expect(
    (await request(t.access, "/test-reports/run-one/manual-cases-0.md")).status,
  ).toBe(404);
  expect(readFileSync(join(directory, "report.html"), "utf8")).not.toContain(
    "media=",
  );
});
