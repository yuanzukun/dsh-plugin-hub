/**
 * Host-side bundle entry.
 *
 * The feature is implemented entirely in the declared Web client extension.
 * Keeping the host entry inert is deliberate: this package neither modifies
 * DSH configuration nor reaches into a Harness runtime implementation.
 */
export const name = 'tobewin-dsh-temporary-chat';

export function apply(): void {
  // Client-only plugin: the public Host RPC remains owned by DeepSeek Harness.
}
