window.__ModuleLoader__.load({
  id: '@tobewin/dsh-temporary-chat',
  factory: (require) => {
    const React = require('react');
    const { jsx, jsxs } = require('react/jsx-runtime');
    const {
      FishLogo,
      IconAgentPresetOutline16,
      IconChevronDownOutline14,
      IconNewChatOutline16,
      IconSendOutline16,
      Tooltip,
    } = require('@deepseek-ai/dsh-client-ui-primitives');

    const NS = 'temporaryChat';
    // `host.describe().version` is the Web Host app version, rather than the
    // npm version of @deepseek-ai/dsh (currently 0.1.0-rc.6).
    const SUPPORTED_HOST_VERSION = '0.0.1';
    const inject = ['slots', 'locale', 'connection', 'sessions'];
    const temporarySessionStorageKey = '@tobewin/dsh-temporary-chat/session-ids/v1';

    const zh = {
      'action.label': '临时对话',
      'action.aria': '新建临时对话',
      'action.creating': '正在创建临时对话',
      'action.unsupported': '当前 DeepSeek Harness 版本暂不受支持',
      'action.connecting': '正在连接 DeepSeek Harness',
      'error.create': '无法创建临时对话：{message}',
      'error.unsupported': '此版本尚未通过兼容性验证。',
      'composer.title': '临时对话',
      'composer.hint': '此对话不会归入任何工作区。发送首条消息后将使用 Harness 原生会话界面。',
      'composer.placeholder': '描述你想构建的内容',
      'composer.send': '发送',
      'composer.send.aria': '发送临时对话消息',
      'hero.headline': '探索未知',
      'hero.preview': '预览',
      'agent.standard': '标准模式',
      'agent.loading': '正在加载模式…',
      'agent.unavailable': '标准模式',
      'agent.error': '无法读取 Agent 模式：{message}',
      'model.label': '模型',
      'model.loading': '正在加载模型…',
      'model.unavailable': '模型选择暂不可用',
      'model.error': '无法读取模型列表：{message}',
      'reasoning.label': '推理强度',
      'reasoning.default': '默认',
      'permission.label': '权限模式',
      'permission.unavailable': '当前 Host 未提供权限预设',
      'permission.error': '无法切换权限模式：{message}',
      'permission.readOnly': '只读',
      'permission.workspaceWrite': '工作区写入',
      'permission.fullAccess': '完全访问',
    };

    const en = {
      'action.label': 'Temporary chat',
      'action.aria': 'Start a temporary chat',
      'action.creating': 'Creating temporary chat',
      'action.unsupported': 'This DeepSeek Harness version is not supported yet',
      'action.connecting': 'Connecting to DeepSeek Harness',
      'error.create': 'Could not create a temporary chat: {message}',
      'error.unsupported': 'This version has not passed compatibility verification yet.',
      'composer.title': 'Temporary chat',
      'composer.hint': 'This chat is not assigned to a workspace. After the first message, Harness returns to its native session UI.',
      'composer.placeholder': 'Describe what you want to build',
      'composer.send': 'Send',
      'composer.send.aria': 'Send temporary chat message',
      'hero.headline': 'Into the Unknown',
      'hero.preview': 'Preview',
      'agent.standard': 'Standard mode',
      'agent.loading': 'Loading modes…',
      'agent.unavailable': 'Standard mode',
      'agent.error': 'Could not load Agent modes: {message}',
      'model.label': 'Model',
      'model.loading': 'Loading models…',
      'model.unavailable': 'Model selection is unavailable',
      'model.error': 'Could not load models: {message}',
      'reasoning.label': 'Reasoning effort',
      'reasoning.default': 'Default',
      'permission.label': 'Access mode',
      'permission.unavailable': 'This Host does not expose permission presets',
      'permission.error': 'Could not change access mode: {message}',
      'permission.readOnly': 'Read-only',
      'permission.workspaceWrite': 'Workspace Write',
      'permission.fullAccess': 'Full access',
    };

    const styleId = '@tobewin/dsh-temporary-chat/sidebar-action.css';
    function installStyles() {
      if (document.querySelector(`style[data-plugin-css="${styleId}"]`)) return;
      const style = document.createElement('style');
      style.dataset.pluginCss = styleId;
      style.textContent = `
        .tobewin-temp-chat-action { display: flex; min-width: 0; flex: 1; flex-direction: column; gap: 6px; }
        .tobewin-temp-chat-button { display: inline-flex; width: 100%; min-height: 36px; align-items: center; gap: 8px; border: 0; border-radius: 8px; padding: 6px 8px; color: var(--dsw-alias-label-primary); background: transparent; font: inherit; text-align: left; cursor: pointer; }
        .tobewin-temp-chat-button:hover:not(:disabled) { background: var(--dsw-alias-interactive-bg-hover); }
        .tobewin-temp-chat-button:focus-visible { outline: 2px solid var(--dsw-alias-state-business-primary); outline-offset: -2px; }
        .tobewin-temp-chat-button:disabled { cursor: not-allowed; color: var(--dsw-alias-label-tertiary); }
        .tobewin-temp-chat-button svg { flex: none; }
        .tobewin-temp-chat-label { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .tobewin-temp-chat-error { margin: 0 4px; color: var(--dsw-alias-state-error-primary); font-size: 12px; line-height: 16px; overflow-wrap: anywhere; }
        .tobewin-temp-chat-rail { justify-content: center; padding-inline: 0; }
        .tobewin-temp-composer { display: flex; width: 100%; max-width: none; flex-direction: column; gap: 8px; border: 1px solid var(--dsw-alias-border-secondary); border-radius: 22px; padding: 14px 16px 12px; background: var(--dsw-specific-input-major, var(--dsw-alias-bg-primary)); box-shadow: var(--dsw-shadow-lv2); }
        .tobewin-temp-composer-root { display: flex; width: 100%; min-height: 100%; justify-content: center; align-items: center; padding: 28px calc(var(--dsh-composer-side-clearance, 0px) + 16px) 36px; box-sizing: border-box; }
        .tobewin-temp-composer-hero { display: flex; width: min(100%, 1440px); flex-direction: column; gap: 0; }
        .tobewin-temp-composer-headline { display: grid; grid-template-columns: 34px auto auto; justify-content: center; align-items: center; column-gap: 10px; margin-bottom: 20px; color: var(--dsw-alias-label-primary); font-size: 26px; font-weight: 500; line-height: 32px; }
        .tobewin-temp-composer-fish { color: var(--dsw-alias-label-primary); }
        .tobewin-temp-composer-preview { margin-left: -3px; align-self: start; border: 1px solid var(--dsw-alias-interactive-bg-hover); border-radius: 24px; padding: 1px 7px 0; color: var(--dsw-alias-label-primary-bluish); background: var(--dsw-alias-state-business-tertiary); font-family: var(--ds-font-family-code); font-size: 12px; font-weight: 500; line-height: 18px; white-space: nowrap; }
        .tobewin-temp-composer-meta { display: flex; align-items: center; min-height: 28px; margin-bottom: 8px; padding-left: 8px; }
        .tobewin-temp-composer-agent { display: inline-flex; align-items: center; gap: 5px; border: 0; border-radius: 16px; padding: 4px 8px; color: var(--dsw-alias-label-primary); background: transparent; font: inherit; font-size: 13px; font-weight: 500; line-height: 20px; }
        .tobewin-temp-composer-agent svg { color: var(--dsw-alias-label-caption); }
        .tobewin-temp-composer-textarea { width: 100%; min-height: 76px; resize: vertical; box-sizing: border-box; border: 0; outline: none; color: var(--dsw-alias-label-primary); background: transparent; font: inherit; line-height: 22px; }
        .tobewin-temp-composer-textarea::placeholder { color: var(--dsw-alias-label-tertiary); }
        .tobewin-temp-composer-controls { display: flex; align-items: center; min-height: 36px; gap: 4px; }
        .tobewin-temp-composer-control { display: inline-flex; min-width: 0; align-items: center; }
        .tobewin-temp-composer-model-group { display: inline-flex; align-items: center; gap: 0; margin-left: auto; }
        .tobewin-temp-picker { position: relative; display: inline-flex; min-width: 0; }
        .tobewin-temp-picker-trigger { display: inline-flex; max-width: 310px; min-height: 28px; align-items: center; gap: 4px; border: 0; border-radius: 16px; padding: 4px 8px; color: var(--dsw-alias-label-secondary); background: transparent; font: inherit; font-size: 13px; font-weight: 500; line-height: 20px; cursor: pointer; }
        .tobewin-temp-picker-trigger:hover:not(:disabled), .tobewin-temp-picker-trigger:focus-visible { background: var(--dsw-alias-interactive-bg-hover); outline: none; }
        .tobewin-temp-picker-trigger:disabled { color: var(--dsw-alias-label-tertiary); cursor: default; }
        .tobewin-temp-picker-label { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .tobewin-temp-picker-chevron { flex: none; color: var(--dsw-alias-label-caption); transition: transform .12s ease; }
        .tobewin-temp-picker-trigger[aria-expanded='true'] .tobewin-temp-picker-chevron { transform: rotate(180deg); }
        .tobewin-temp-picker-menu { position: absolute; z-index: 12; bottom: calc(100% + 8px); min-width: 188px; max-width: 320px; overflow: hidden auto; border: 1px solid var(--dsw-alias-border-secondary); border-radius: 12px; padding: 4px; color: var(--dsw-alias-label-primary); background: var(--dsw-specific-input-major, var(--dsw-alias-bg-primary)); box-shadow: var(--dsw-shadow-lv3, 0 8px 24px rgba(0,0,0,.14)); }
        .tobewin-temp-picker-menu-end { right: 0; }
        .tobewin-temp-picker-item { display: flex; width: 100%; align-items: center; border: 0; border-radius: 8px; padding: 7px 8px; color: inherit; background: transparent; font: inherit; font-size: 13px; line-height: 20px; text-align: left; cursor: pointer; }
        .tobewin-temp-picker-item:hover:not(:disabled), .tobewin-temp-picker-item[aria-selected='true'] { background: var(--dsw-alias-interactive-bg-hover); }
        .tobewin-temp-picker-item:disabled { color: var(--dsw-alias-label-tertiary); cursor: default; }
        .tobewin-temp-picker-separator { height: 1px; margin: 4px; background: var(--dsw-alias-border-secondary); }
        .tobewin-temp-composer-status { margin: 0; color: var(--dsw-alias-label-tertiary); font-size: 12px; line-height: 16px; }
        .tobewin-temp-composer-status-error { color: var(--dsw-alias-state-error-primary); }
        /* The model/reasoning group owns the flexible spacer.  Giving the
           send wrapper a second auto margin split the controls across the
           entire row, unlike the native composer where they stay together. */
        .tobewin-temp-composer-actions { display: flex; margin-left: 8px; justify-content: flex-end; }
        .tobewin-temp-composer-send { display: inline-flex; width: 38px; height: 38px; align-items: center; justify-content: center; border: 0; border-radius: 50%; padding: 0; color: var(--dsw-alias-label-on-solid, #fff); background: var(--dsw-alias-state-business-primary); cursor: pointer; }
        .tobewin-temp-composer-send:disabled { cursor: not-allowed; opacity: .45; }
        .tobewin-temp-composer-send:focus-visible { outline: 2px solid var(--dsw-alias-state-business-primary); outline-offset: 2px; }
      `;
      document.head.appendChild(style);
    }

    function isCompatible(connection) {
      const version = connection.hostDescription.getSnapshot()?.version;
      return version === SUPPORTED_HOST_VERSION
        && typeof connection.api?.sessions?.create === 'function';
    }

    function temporarySessionIds() {
      try {
        const raw = window.localStorage.getItem(temporarySessionStorageKey);
        const parsed = raw === null ? [] : JSON.parse(raw);
        return Array.isArray(parsed) ? new Set(parsed.filter((value) => typeof value === 'string')) : new Set();
      } catch {
        return new Set();
      }
    }

    function rememberTemporarySession(sessionId) {
      try {
        const ids = temporarySessionIds();
        ids.add(sessionId);
        window.localStorage.setItem(temporarySessionStorageKey, JSON.stringify([...ids].slice(-100)));
      } catch {
        // Storage is only a UX hint. A blocked browser storage policy must not
        // prevent a real native Session from being created and opened.
      }
    }

    function isRememberedTemporarySession(sessionId) {
      return typeof sessionId === 'string' && temporarySessionIds().has(sessionId);
    }

    function waitForSession(ctx, sessionId, timeoutMs = 3000) {
      if (ctx.sessions.list.getSnapshot().byId[sessionId] !== undefined) return Promise.resolve();
      return new Promise((resolve, reject) => {
        let settled = false;
        let unsubscribe = () => {};
        let timeout;
        const finish = (error) => {
          if (settled) return;
          settled = true;
          clearTimeout(timeout);
          unsubscribe();
          if (error === undefined) resolve();
          else reject(error);
        };
        const observe = () => {
          if (ctx.sessions.list.getSnapshot().byId[sessionId] !== undefined) finish();
        };
        unsubscribe = ctx.sessions.list.subscribe(observe);
        timeout = setTimeout(() => {
          finish(new Error('DeepSeek Harness did not publish the new session in time.'));
        }, timeoutMs);
        observe();
      });
    }

    function usePluginLocale(locale) {
      React.useSyncExternalStore(
        locale.subscribe.bind(locale),
        locale.getSnapshot.bind(locale),
        locale.getSnapshot.bind(locale),
      );
      return locale.bind(NS);
    }

    function TemporaryChatAction({ wide, connection, locale, onCreate }) {
      const t = usePluginLocale(locale);
      const hostDescription = React.useSyncExternalStore(
        connection.hostDescription.subscribe.bind(connection.hostDescription),
        connection.hostDescription.getSnapshot.bind(connection.hostDescription),
        () => undefined,
      );
      const [pending, setPending] = React.useState(false);
      const [error, setError] = React.useState(undefined);
      const supported = hostDescription !== undefined && isCompatible(connection);
      const stateLabel = hostDescription === undefined
        ? t('action.connecting')
        : supported
          ? pending ? t('action.creating') : t('action.label')
          : t('action.unsupported');

      async function handleClick() {
        if (pending || !supported) return;
        setPending(true);
        setError(undefined);
        try {
          await onCreate();
        } catch (cause) {
          setError(cause instanceof Error ? cause.message : String(cause));
        } finally {
          setPending(false);
        }
      }

      const button = jsx('button', {
        type: 'button',
        className: `tobewin-temp-chat-button${wide ? '' : ' tobewin-temp-chat-rail'}`,
        disabled: !supported || pending,
        'aria-label': t('action.aria'),
        onClick: handleClick,
        children: jsxs(React.Fragment, {
          children: [
            jsx(IconNewChatOutline16, { size: 16 }),
            wide && jsx('span', { className: 'tobewin-temp-chat-label', children: stateLabel }),
          ],
        }),
      });

      return jsxs('div', {
        className: 'tobewin-temp-chat-action',
        children: [
          wide ? button : jsx(Tooltip, { label: stateLabel, side: 'right', children: button }),
          error && jsx('p', { className: 'tobewin-temp-chat-error', role: 'alert', children: t('error.create', { message: error }) }),
        ],
      });
    }

    function modelKey(provider, model) {
      return `${provider}\u0000${model}`;
    }

    function findModel(groups, provider, model) {
      return groups.find((group) => group.id === provider)?.models.find((entry) => entry.id === model);
    }

    function permissionLabel(option, t) {
      const common = {
        'read-only': 'permission.readOnly',
        'workspace-write': 'permission.workspaceWrite',
        'danger-full-access': 'permission.fullAccess',
      };
      return common[option.value] === undefined ? option.name : t(common[option.value]);
    }

    /**
     * A plugin-owned picker. It intentionally has no dependency on Harness's
     * internal menu/components: all data and mutations arrive through public
     * contracts supplied by the caller.
     */
    function Picker({ ariaLabel, disabled = false, end = false, icon, items, label, onSelect }) {
      const [open, setOpen] = React.useState(false);
      const root = React.useRef(null);
      React.useEffect(() => {
        if (!open) return undefined;
        const dismiss = (event) => {
          if (event.target instanceof Node && root.current?.contains(event.target)) return;
          setOpen(false);
        };
        const escape = (event) => {
          if (event.key === 'Escape') setOpen(false);
        };
        document.addEventListener('pointerdown', dismiss);
        document.addEventListener('keydown', escape);
        return () => {
          document.removeEventListener('pointerdown', dismiss);
          document.removeEventListener('keydown', escape);
        };
      }, [open]);

      return jsxs('span', {
        ref: root,
        className: 'tobewin-temp-picker',
        children: [
          jsxs('button', {
            type: 'button',
            className: 'tobewin-temp-picker-trigger',
            'aria-label': ariaLabel ?? label,
            'aria-haspopup': 'listbox',
            'aria-expanded': open,
            disabled,
            onClick: () => setOpen((value) => !value),
            children: [
              icon,
              jsx('span', { className: 'tobewin-temp-picker-label', children: label }),
              jsx(IconChevronDownOutline14, { className: 'tobewin-temp-picker-chevron', size: 14 }),
            ],
          }),
          open && jsx('div', {
            className: `tobewin-temp-picker-menu${end ? ' tobewin-temp-picker-menu-end' : ''}`,
            role: 'listbox',
            'aria-label': ariaLabel ?? label,
            children: items.map((item) => item.separator === true
              ? jsx('div', { className: 'tobewin-temp-picker-separator', role: 'separator' }, item.id)
              : jsx('button', {
                type: 'button',
                className: 'tobewin-temp-picker-item',
                role: 'option',
                'aria-selected': item.selected === true,
                disabled: item.disabled === true,
                onClick: () => {
                  setOpen(false);
                  onSelect(item.id);
                },
                children: item.label,
              }, item.id)),
          }),
        ],
      });
    }

    function useAgentPresetDirectory(connection, sessionId, useSession) {
      const sessionPreset = useSession((session) => session?.agentPreset);
      const [state, setState] = React.useState({ status: 'loading', current: sessionPreset ?? '', options: [], error: null });

      React.useEffect(() => {
        let active = true;
        if (typeof connection.api?.agentPresets?.list !== 'function') {
          setState({ status: 'unavailable', current: sessionPreset ?? '', options: [], error: null });
          return () => { active = false; };
        }
        setState((previous) => ({ ...previous, status: 'loading', error: null }));
        connection.api.agentPresets.list({}).then((response) => {
          if (!active) return;
          if (!response.result.ok) {
            setState({ status: 'error', current: sessionPreset ?? '', options: [], error: response.result.error.message });
            return;
          }
          const options = response.result.value.presets.filter((preset) => preset.broken === undefined);
          const fallback = options.find((preset) => preset.isDefault)?.id ?? options[0]?.id ?? '';
          setState({ status: 'ready', current: sessionPreset ?? fallback, options, error: null });
        }).catch((cause) => {
          if (active) setState({ status: 'error', current: sessionPreset ?? '', options: [], error: cause instanceof Error ? cause.message : String(cause) });
        });
        return () => { active = false; };
      }, [connection, sessionId]);

      React.useEffect(() => {
        if (sessionPreset === undefined || sessionPreset === '') return;
        setState((previous) => ({ ...previous, current: sessionPreset }));
      }, [sessionPreset]);

      return [state, setState];
    }

    // Agent preset names arrive from the Host as persisted data. The built-in
    // `standard` preset may therefore carry the language it was first created
    // with (for example, 中文 in an otherwise English UI). Its identifier is a
    // stable public contract, so render that one through the active locale.
    // User-created preset names remain user content and must not be translated.
    function displayAgentPreset(preset, t) {
      if (preset?.id === 'standard') return t('agent.standard');
      return preset?.name ?? preset?.id ?? t('agent.standard');
    }

    function AgentPresetControl({ connection, noteAgentPreset, sessionId, t, useSession }) {
      const [state, setState] = useAgentPresetDirectory(connection, sessionId, useSession);
      const selectable = state.status === 'ready' && state.options.length > 1 && typeof connection.api?.agentPresets?.select === 'function';
      const currentPreset = state.options.find((preset) => preset.id === state.current);
      const display = currentPreset === undefined
        ? (state.current || t('agent.standard'))
        : displayAgentPreset(currentPreset, t);

      async function select(agentPreset) {
        if (agentPreset === state.current) return;
        setState((previous) => ({ ...previous, status: 'selecting', error: null }));
        try {
          const response = await connection.api.agentPresets.select({ sessionId, agentPreset });
          if (!response.result.ok) throw new Error(response.result.error.message);
          noteAgentPreset(sessionId, response.result.value.agentPreset);
          setState((previous) => ({ ...previous, status: 'ready', current: response.result.value.agentPreset, error: null }));
        } catch (cause) {
          setState((previous) => ({ ...previous, status: 'ready', error: cause instanceof Error ? cause.message : String(cause) }));
        }
      }

      return jsxs('span', {
        className: 'tobewin-temp-composer-agent',
        title: state.error === null ? undefined : t('agent.error', { message: state.error }),
        children: [
          selectable
            ? jsx(Picker, {
              ariaLabel: t('agent.standard'),
              icon: jsx(IconAgentPresetOutline16, { size: 16 }),
              items: state.options.map((preset) => ({ id: preset.id, label: displayAgentPreset(preset, t), selected: preset.id === state.current })),
              disabled: state.status === 'selecting',
              label: display,
              onSelect: select,
            })
            : jsxs(React.Fragment, { children: [jsx(IconAgentPresetOutline16, { size: 16 }), jsx('span', { children: state.status === 'loading' ? t('agent.loading') : display })] }),
        ],
      });
    }

    function useModelDirectory(connection, sessionId) {
      const [state, setState] = React.useState({ status: 'loading', current: null, groups: [], error: null });
      React.useEffect(() => {
        let active = true;
        setState({ status: 'loading', current: null, groups: [], error: null });
        if (typeof connection.api?.sessions?.models !== 'function') {
          setState({ status: 'unavailable', current: null, groups: [], error: null });
          return () => { active = false; };
        }
        connection.api.sessions.models({ sessionId }).then((response) => {
          if (!active) return;
          if (!response.result.ok) {
            setState({ status: 'error', current: null, groups: [], error: response.result.error.message });
            return;
          }
          setState({
            status: 'ready',
            current: response.result.value.current,
            groups: response.result.value.groups,
            error: null,
          });
        }).catch((cause) => {
          if (active) setState({ status: 'error', current: null, groups: [], error: cause instanceof Error ? cause.message : String(cause) });
        });
        return () => { active = false; };
      }, [connection, sessionId]);
      return [state, setState];
    }

    function ModelControls({ connection, sessionId, t }) {
      const [state, setState] = useModelDirectory(connection, sessionId);
      const current = state.current;
      const selectedModel = current === null ? undefined : findModel(state.groups, current.provider, current.model);
      const efforts = selectedModel?.reasoning?.efforts ?? [];
      const disabled = state.status !== 'ready' || typeof connection.api?.sessions?.selectModel !== 'function';

      async function select(nextProvider, nextModel, reasoningEffort) {
        setState((previous) => ({ ...previous, status: 'selecting', error: null }));
        try {
          const response = await connection.api.sessions.selectModel({
            sessionId,
            provider: nextProvider,
            model: nextModel,
            ...(reasoningEffort === undefined ? {} : { reasoningEffort }),
          });
          if (!response.result.ok) throw new Error(response.result.error.message);
          setState((previous) => ({ ...previous, status: 'ready', current: response.result.value.selected, error: null }));
        } catch (cause) {
          setState((previous) => ({ ...previous, status: 'ready', error: cause instanceof Error ? cause.message : String(cause) }));
        }
      }

      if (state.status === 'loading') return jsx('p', { className: 'tobewin-temp-composer-status', children: t('model.loading') });
      if (state.status === 'unavailable') return jsx('p', { className: 'tobewin-temp-composer-status', children: t('model.unavailable') });
      if (state.status === 'error' && state.groups.length === 0) return jsx('p', { className: 'tobewin-temp-composer-status tobewin-temp-composer-status-error', children: t('model.error', { message: state.error }) });

      const currentEffort = efforts.find((effort) => effort.id === current?.reasoningEffort);
      const modelLabel = selectedModel?.name ?? current?.model ?? t('model.unavailable');
      const label = currentEffort === undefined ? modelLabel : `${modelLabel} ${currentEffort.name}`;
      const modelItems = state.groups.flatMap((group) => group.models.map((model) => ({
        id: `model:${modelKey(group.id, model.id)}`,
        label: model.name,
        selected: current?.provider === group.id && current?.model === model.id,
      })));
      const effortItems = efforts.length === 0 ? [] : [
        { id: 'separator:effort', separator: true },
        { id: 'effort:', label: t('reasoning.default'), selected: (current?.reasoningEffort ?? '') === '' },
        ...efforts.map((effort) => ({ id: `effort:${effort.id}`, label: effort.name, selected: current?.reasoningEffort === effort.id })),
      ];

      return jsxs(React.Fragment, {
        children: [
          jsx('span', {
            className: 'tobewin-temp-composer-control',
            children: jsx(Picker, {
              ariaLabel: t('model.label'),
              disabled,
              end: true,
              items: [...modelItems, ...effortItems],
              label,
              onSelect: (id) => {
                if (id.startsWith('model:')) {
                  const [provider, model] = id.slice('model:'.length).split('\u0000');
                  const choice = findModel(state.groups, provider, model);
                  select(provider, model, choice?.reasoning?.defaultEffort);
                } else if (id.startsWith('effort:') && current !== null) {
                  select(current.provider, current.model, id.slice('effort:'.length) || undefined);
                }
              },
            }),
          }),
          state.error !== null && jsx('p', { className: 'tobewin-temp-composer-status tobewin-temp-composer-status-error', children: t('model.error', { message: state.error }) }),
        ],
      });
    }

    function PermissionControl({ command, sessionId, useProjection, t }) {
      const permission = useProjection('permissions');
      const [error, setError] = React.useState(null);
      if (permission === undefined || permission.options.length === 0) {
        return jsx('p', { className: 'tobewin-temp-composer-status', children: t('permission.unavailable') });
      }

      async function select(preset) {
        if (preset === permission.currentValue) return;
        setError(null);
        try {
          const result = await command(sessionId, `/permission ${preset}`);
          if (!result.ok) throw new Error(result.error.message);
          if (!result.value.matched) throw new Error('The current DeepSeek Harness Host does not provide the /permission command.');
        } catch (cause) {
          setError(cause instanceof Error ? cause.message : String(cause));
        }
      }

      return jsxs(React.Fragment, {
        children: [
          jsx('span', {
            className: 'tobewin-temp-composer-control',
            children: jsx(Picker, {
              ariaLabel: t('permission.label'),
              items: permission.options.map((option) => ({
                id: option.value,
                label: permissionLabel(option, t),
                disabled: option.value === 'custom',
                selected: option.value === permission.currentValue,
              })),
              label: permissionLabel(permission.options.find((option) => option.value === permission.currentValue) ?? { value: permission.currentValue, name: permission.currentValue }, t),
              onSelect: select,
            }),
          }),
          error !== null && jsx('p', { className: 'tobewin-temp-composer-status tobewin-temp-composer-status-error', children: t('permission.error', { message: error }) }),
        ],
      });
    }

    function TemporaryComposer({ command, connection, locale, noteAgentPreset, sessionId, useInput, inputActions, useProjection, useSession }) {
      const t = usePluginLocale(locale);
      const input = useInput((snapshot) => snapshot);
      const draft = input?.draft ?? '';
      const canSubmit = inputActions !== undefined && draft.trim() !== '';

      function handleKeyDown(event) {
        if (event.key !== 'Enter' || event.shiftKey || event.nativeEvent?.isComposing) return;
        event.preventDefault();
        if (canSubmit) inputActions.submit();
      }

      return jsx('div', {
        className: 'tobewin-temp-composer-root',
        children: jsxs('div', {
          className: 'tobewin-temp-composer-hero',
          children: [
            jsxs('div', {
              className: 'tobewin-temp-composer-headline',
              children: [
                jsx(FishLogo, { size: 34, className: 'tobewin-temp-composer-fish' }),
                jsx('span', { children: t('hero.headline') }),
                jsx('span', { className: 'tobewin-temp-composer-preview', children: t('hero.preview') }),
              ],
            }),
            jsx('div', {
              className: 'tobewin-temp-composer-meta',
              children: jsx(AgentPresetControl, { connection, noteAgentPreset, sessionId, t, useSession }),
            }),
            jsxs('section', {
              className: 'tobewin-temp-composer',
              'aria-label': t('composer.title'),
              children: [
                jsx('textarea', {
                  className: 'tobewin-temp-composer-textarea',
                  value: draft,
                  placeholder: t('composer.placeholder'),
                  'aria-label': t('composer.placeholder'),
                  autoFocus: true,
                  disabled: inputActions === undefined,
                  onChange: (event) => inputActions?.setDraft(event.target.value),
                  onKeyDown: handleKeyDown,
                }),
                jsxs('div', {
                  className: 'tobewin-temp-composer-controls',
                  children: [
                    jsx(PermissionControl, { command, sessionId, useProjection, t }),
                    jsx('div', {
                      className: 'tobewin-temp-composer-model-group',
                      children: jsx(ModelControls, { connection, sessionId, t }),
                    }),
                    jsx('div', {
                      className: 'tobewin-temp-composer-actions',
                      children: jsx('button', {
                        type: 'button',
                        className: 'tobewin-temp-composer-send',
                        disabled: !canSubmit,
                        'aria-label': t('composer.send.aria'),
                        onClick: () => inputActions?.submit(),
                        children: jsx(IconSendOutline16, { size: 16 }),
                      }),
                    }),
                  ],
                }),
              ],
            }),
          ],
        }),
      });
    }

    function apply(ctx) {
      installStyles();
      ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'temporary-chat: dictionaries');
      const connection = ctx.get('connection');
      const t = ctx.locale.bind(NS);

      async function createTemporaryChat() {
        if (!isCompatible(connection)) throw new Error(t('error.unsupported'));
        const response = await connection.api.sessions.create({});
        if (!response.result.ok) throw new Error(response.result.error.message);
        const { sessionId } = response.result.value;
        rememberTemporarySession(sessionId);
        await waitForSession(ctx, sessionId);
        ctx.sessions.open(sessionId);
      }

      ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
        name: 'sidebar.footer.action',
        id: 'tobewin-temporary-chat',
        locale: NS,
        inject: () => ({ connection, locale: ctx.locale, onCreate: createTemporaryChat }),
      }, TemporaryChatAction));

      ctx.slots.inject('conversation.composer', () => ctx.slots.register({
        name: 'conversation.composer',
        id: 'tobewin-temporary-chat-first-message',
        locale: NS,
        priority: 0,
        inject: () => ({
          connection,
          locale: ctx.locale,
          noteAgentPreset: (sessionId, agentPreset) => ctx.sessions.noteAgentPreset(sessionId, agentPreset),
          command: (sessionId, line) => {
            const session = ctx.sessions.binding(sessionId)?.session;
            if (session === undefined) return Promise.resolve({ ok: false, error: { message: 'Temporary session is not available.' } });
            return session.command(line);
          },
        }),
        select: ({ interactions, session }) => (
          interactions.length === 0
          && session?.composerPhase === 'blank'
          && isRememberedTemporarySession(session.sessionId)
            ? session.sessionId
            : null
        ),
      }, TemporaryComposer));
    }

    return { NS, apply, inject };
  },
});
