# Changelog

All notable changes to this project will be documented in this file.

## Unreleased

- Replace the static “Standard mode” label with an Agent-preset selector backed
  by the public `agentPresets.list` and `agentPresets.select` contracts.
- Refine the Hero composer proportions and keep the model, reasoning, and send
  controls together at the trailing edge of the input bar.
- Replace browser-native selects with plugin-owned picker menus so the temporary
  composer remains visually controlled without importing Harness UI internals.
- Subscribe to the public Harness locale store so every plugin-owned label
  changes immediately when the user switches the language in Settings.

## 0.1.0 - Unreleased

- Add a sidebar entry for workspace-free temporary conversations.
- Create native ungrouped DSH Sessions using the public `session.create({})`
  contract and open them through the public session service.
- Add a DSH `0.1.0-rc.6` compatibility gate and user-visible failure state.
- Replace the disabled no-workspace composer with a native-style Hero input
  surface: no Workspace picker, while preserving model, reasoning-effort, and
  permission-preset choices.
- Read and select models through the public `session.models` and
  `session.selectModel` contracts.
- Switch permission presets through the public session-command contract rather
  than routing a slash command through the model prompt path.
