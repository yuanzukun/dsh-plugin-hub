<h1 align="center">DSH Temporary Chat</h1>

<p align="center">Start talking first. Choose a project only when you actually need one.</p>

<p align="center">
  <a href="https://www.npmjs.com/package/@tobewin/dsh-temporary-chat"><img src="https://img.shields.io/npm/v/@tobewin/dsh-temporary-chat?color=2563eb&label=npm" alt="npm version"></a>
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-111827" alt="MIT license"></a>
  <img src="https://img.shields.io/badge/workspace-not%20required-0f766e" alt="Workspace not required">
  <img src="https://img.shields.io/badge/language-English%20%7C%20%E4%B8%AD%E6%96%87-7c3aed" alt="English and Chinese">
</p>

<p align="center"><a href="#quick-start">Quick start</a> · <a href="#中文说明">中文说明</a> · <a href="https://github.com/ToBeWin/DSH-Plugin-Market">All ToBeWin plugins</a></p>

`@tobewin/dsh-temporary-chat` adds **workspace-free temporary conversations** to [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness).

It brings the familiar “start a chat without opening a project” workflow to Harness while preserving its native Session model. A temporary chat is a real ungrouped DSH Session, not a fake workspace or a forked interface.

> This is an independent community project by [ToBeWin](https://github.com/ToBeWin). It is not affiliated with or endorsed by DeepSeek.

## See it in Harness

<p align="center">
  <img src="docs/images/temporary-chat.png" alt="Workspace-free temporary conversation composer in DeepSeek Harness" width="92%">
</p>

## What it does

- Adds a **Temporary chat** action to the DSH sidebar.
- Creates a native Session without Workspace registration, so it appears in Harness's normal **Ungrouped** area.
- Shows a focused first-message composer with Agent preset, access mode, model, and reasoning-effort choices.
- Hands the conversation back to the native Harness session interface after the first message.
- Follows the English/Chinese language selected in Harness Settings in real time.

## Quick start

```bash
dsh plugin --profile web add @tobewin/dsh-temporary-chat
```

Restart the DSH Web Host, then select **Temporary chat** from the sidebar.

### Development install

```bash
git clone https://github.com/ToBeWin/DSH-Temporary-Chat.git
cd DSH-Temporary-Chat
pnpm install
pnpm build
dsh plugin --profile web add "link:$(pwd)"
```

Restart DSH after installation. Re-run `pnpm build` whenever the client source changes, then restart the Web Host to reload the plugin.

## How a temporary chat behaves

1. Choose **Temporary chat** in the sidebar.
2. The plugin creates an ungrouped native DSH Session.
3. Before the first message, choose any Agent preset, model, reasoning effort, and permission preset exposed by the active Host.
4. Send the first message. The normal Harness session UI then takes over.

The first-message controls are intentionally constrained by the Host. Agent presets can only be changed while DSH considers the Session blank. Available models and access modes are the ones configured in your Host; the plugin does not invent, store, or transmit credentials.

## Architecture and privacy

This plugin is deliberately decoupled from Harness internals. It uses only declared extension slots and public contracts for Session creation, input, models, Agent presets, and session commands. It does **not**:

- modify, copy, patch, or fork DeepSeek Harness source code;
- import private Harness runtime components;
- scrape or patch rendered DSH DOM nodes;
- upload conversation data, project files, or model credentials.

Temporary means “not registered under a DSH Workspace.” The public DSH Session creation contract may still use the Host's default working directory for tool execution. Temporary chat is not a claim that tools are sandboxed; choose a read-only permission preset when appropriate.

## Compatibility

The first release is tested against the DeepSeek Harness `0.1.0-rc.6` package line and Web Host app version `0.0.1`. The plugin checks the public Host version and disables itself outside the tested range. New Harness versions require a separate compatibility check before support is enabled.

## Development and contributing

```bash
pnpm install
pnpm check
pnpm build
```

Please report the DSH version, operating system, selected Profile, and a minimal reproduction when opening an issue. Remove private paths, keys, tokens, and conversation content before posting.

## License

[MIT](LICENSE) © ToBeWin

---

## 中文说明

`@tobewin/dsh-temporary-chat` 为 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 增加**无需工作区的临时对话**。

它让 Harness 具备“不开项目也能直接对话”的体验，同时仍然使用原生 Session 模型。临时对话是真实的未分组 DSH Session，不会伪造工作区，也不会 fork 官方界面。

> 本项目由 [ToBeWin](https://github.com/ToBeWin) 独立维护，与 DeepSeek 无隶属或官方背书关系。

### 功能

- 在侧栏增加 **临时对话** 入口。
- 创建不注册到 Workspace 的原生 Session，并显示在 Harness 的 **Ungrouped / 未分组** 区域。
- 在首条消息前提供 Agent 预设、权限模式、模型和推理强度选择。
- 发送第一条消息后，无缝交回 Harness 原生会话界面。
- 自动实时跟随 Harness 设置中的中文 / English 切换。

### 安装

从 npm 安装：

```bash
dsh plugin --profile web add @tobewin/dsh-temporary-chat
```

重启 DSH Web Host 后，在侧栏点击 **临时对话**。

本地开发安装：

```bash
git clone https://github.com/ToBeWin/DSH-Temporary-Chat.git
cd DSH-Temporary-Chat
pnpm install
pnpm build
dsh plugin --profile web add "link:$(pwd)"
```

修改客户端代码后，需要重新执行 `pnpm build` 并重启 DSH Web Host。

### 使用方式

1. 在侧栏点击 **临时对话**。
2. 插件创建一个原生、未分组的 DSH Session。
3. 首条消息前，选择当前 Host 已配置的 Agent 预设、模型、推理强度和权限模式。
4. 发送消息后，后续会话使用 Harness 原生界面。

可选模型和权限完全以 Host 配置为准，插件不会新增模型、保存或上传任何凭据。Agent 预设只能在 Session 仍为空白时修改，这是 Host 的正常限制。

### 解耦与安全边界

本插件只使用公开的扩展槽与 API：Session 创建、输入、模型、Agent 预设和会话命令。它不会修改、复制、patch 或 fork Harness 源码；不会导入私有运行时组件；不会抓取或篡改 DSH DOM；也不会上传聊天内容、项目文件或模型密钥。

“临时”仅表示不归属 DSH Workspace。官方 Session 创建 API 仍可能使用 Host 的默认工作目录执行工具，因此临时对话不等于工具沙箱。需要限制本地文件操作时，请选择只读权限模式。

### 兼容性与开发

首个版本已针对 DeepSeek Harness `0.1.0-rc.6` 和 Web Host `0.0.1` 验证。插件会检查公开 Host 版本，未验证版本会自动禁用入口；新的 Harness 版本需重新验证后才会支持。

```bash
pnpm install
pnpm check
pnpm build
```

欢迎提交 Issue 和 PR。请提供 DSH 版本、操作系统、Profile 名称和最小复现步骤；提交前务必移除私有路径、密钥、Token 与聊天内容。

### 许可证

[MIT](LICENSE) © ToBeWin
