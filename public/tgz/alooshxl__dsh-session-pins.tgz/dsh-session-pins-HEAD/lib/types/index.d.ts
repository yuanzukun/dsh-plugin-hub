import type { Context } from '@deepseek-ai/cordis';
export declare const name = "dsh-session-pins";
/**
 * Registers the session pins package for client-module discovery.
 *
 * All product behavior is implemented by this package's `./client` entry.
 */
export declare function apply(_ctx: Context): void;
//# sourceMappingURL=index.d.ts.map