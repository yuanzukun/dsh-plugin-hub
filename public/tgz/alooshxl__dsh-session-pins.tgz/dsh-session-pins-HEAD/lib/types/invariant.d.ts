import type { Context } from '@deepseek-ai/cordis';
export declare const name = "dsh-session-pins-invariant";
export declare const inject: string[];
/**
 * Registers this package's invariant ownership.
 *
 * @returns The registration disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map