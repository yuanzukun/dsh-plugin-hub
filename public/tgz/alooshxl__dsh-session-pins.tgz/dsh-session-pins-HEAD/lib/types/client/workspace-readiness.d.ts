import type { WorkspaceListState } from '@deepseek-ai/dsh-client-runtime/client';
export type WorkspaceSessionStatus = 'not-ready' | 'archived' | 'openable';
export declare function workspaceSessionStatus(snapshot: WorkspaceListState, sessionId: string): WorkspaceSessionStatus;
//# sourceMappingURL=workspace-readiness.d.ts.map