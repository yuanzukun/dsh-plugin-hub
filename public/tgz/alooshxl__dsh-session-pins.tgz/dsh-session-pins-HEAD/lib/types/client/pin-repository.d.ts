export interface PinnedSessionsSnapshot {
    readonly ids: readonly string[];
}
export interface StorageLike {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
}
export interface StorageEventLike {
    readonly key: string | null;
    readonly newValue: string | null;
    readonly storageArea?: StorageLike | null;
}
export interface StorageEventSource {
    addEventListener(type: 'storage', listener: (event: StorageEventLike) => void): void;
    removeEventListener(type: 'storage', listener: (event: StorageEventLike) => void): void;
}
export declare const PIN_STORAGE_KEY = "dsh.session-pins.v1";
export declare const MAX_PINNED_SESSIONS = 100;
export declare class PinRepository {
    private readonly listeners;
    private readonly storage;
    private snapshot;
    constructor(storage?: StorageLike);
    getSnapshot(): PinnedSessionsSnapshot;
    subscribe(listener: () => void): () => void;
    pin(id: string): void;
    unpin(id: string): void;
    connect(eventSource: StorageEventSource): () => void;
    private commit;
}
//# sourceMappingURL=pin-repository.d.ts.map