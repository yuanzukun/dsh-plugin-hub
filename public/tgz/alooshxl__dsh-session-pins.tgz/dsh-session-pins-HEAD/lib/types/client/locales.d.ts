export declare const NS = "sessionPins";
export declare const zh: {
    'trigger.label': string;
    'trigger.aria': string;
    'menu.heading': string;
    'menu.empty': string;
    'action.open': string;
    'action.unpin': string;
    'action.back': string;
    'action.pinCurrent': string;
    'action.unpinCurrent': string;
    'session.unavailable': string;
    'session.availabilityNotReady': string;
    'session.archivedUnsupported': string;
    'current.noSession': string;
    'current.blank': string;
    'current.subagent': string;
    'error.openFailed': string;
};
export type SessionPinsKey = keyof typeof zh;
export declare const en: {
    'trigger.label': string;
    'trigger.aria': string;
    'menu.heading': string;
    'menu.empty': string;
    'action.open': string;
    'action.unpin': string;
    'action.back': string;
    'action.pinCurrent': string;
    'action.unpinCurrent': string;
    'session.unavailable': string;
    'session.availabilityNotReady': string;
    'session.archivedUnsupported': string;
    'current.noSession': string;
    'current.blank': string;
    'current.subagent': string;
    'error.openFailed': string;
};
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        sessionPins: SessionPinsKey;
    }
}
//# sourceMappingURL=locales.d.ts.map