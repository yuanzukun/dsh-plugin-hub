import type { SVGProps } from 'react';
export declare function PinIcon({ width, height, ...props }: SVGProps<SVGSVGElement>): import("react").JSX.Element;
//# sourceMappingURL=PinIcon.d.ts.map