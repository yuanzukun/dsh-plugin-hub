import type { HostObservable, InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { PinnedSessionsSnapshot } from './pin-repository.ts';
export interface SessionPinsFace {
    hooks: {
        pinnedSessions: HostObservable<PinnedSessionsSnapshot>;
    };
    pinSession(id: string): boolean;
    unpinSession(id: string): void;
    openSession(id: string): boolean;
}
export type PinnedSessionsActionProps = PropsRuntime<'sidebar.footer.action'> & InjectFace<SessionPinsFace> & PropsLocale<'sessionPins'>;
export declare function PinnedSessionsAction({ wide, useSessions, useWorkspaces, usePinnedSessions, pinSession, unpinSession, openSession, t, }: PinnedSessionsActionProps): import("react").JSX.Element;
//# sourceMappingURL=PinnedSessionsAction.d.ts.map