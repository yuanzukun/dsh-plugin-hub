# DSH Session Pins Design

## Context

DeepSeek Harness does not currently accept external pull requests. Its contribution guide instead asks community members to publish standalone profile-bundle plugins and tag their repositories with `dsh-plugin`.

GitHub Discussion [deepseek-ai/deepseek-harness#63](https://github.com/deepseek-ai/deepseek-harness/discussions/63) requests a way to keep valuable sessions easy to reach. The stock workspace browser hides archived sessions and does not expose an external session-row action slot. Replacing that browser would duplicate core UI and couple this plugin to private implementation details.

The supported extension point is the sidebar's public `sidebar.footer.action` list slot. The plugin will use that slot to provide a persistent pinned-session menu without modifying or monkey-patching DeepSeek Harness.

## Goals

- Let a user pin or unpin the current ordinary session.
- Keep pinned sessions available after a page reload.
- Open pinned ordinary sessions that Harness permits the public session runtime to select.
- Keep archived pins visible and removable, with localized copy explaining the Harness version limitation.
- Remain a standalone installable DeepSeek Harness profile bundle.
- Use only public client services and slot contracts.
- Provide English and Chinese UI copy.
- Work without API credentials.
- Ship with automated tests, CI, installation documentation, and an MIT license.

## Non-goals

- Add controls inside the stock session rows.
- Replace or fork the stock workspace browser.
- Change session archive state or add an unarchive operation.
- Bypass Harness archive behavior through private APIs, host patches, or timing workarounds.
- Synchronize pins through the host or across different browsers.
- Modify the official DeepSeek Harness repository.
- Publish an npm package in the initial release.

## Repository and package identity

- GitHub repository: `alooshxl/dsh-session-pins`
- Package name: `@dsh-external/dsh-session-pins`
- Cordis plugin id: `dsh-session-pins`
- Browser storage key: `dsh.session-pins.v1`
- License: MIT
- Discovery topic: `dsh-plugin`

The package manifest will declare both:

- `dsh.bundle.patch`, pointing to `cordis.patch.yml`; and
- `dsh.client`, declaring the browser module and its official client-package dependencies.

The bundle patch will mount the package's Node half. The Node half has no product behavior; mounting it lets the Harness client-module registry discover and serve the browser half.

## User experience

The plugin contributes one footer action above the stock Settings action.

### Wide sidebar

The action shows a pin icon and the label **Pinned sessions**.

### Collapsed sidebar

The action shows the same icon with an accessible label and tooltip.

### Menu

Activating the action opens a portaled menu above the footer:

1. A heading identifies the pinned-session list.
2. Each resolvable pin shows its current display title.
3. Each resolvable, non-archived pin offers **Open** and **Unpin** actions.
4. An archived pin keeps its current title, omits **Open**, explains that this Harness version cannot reopen archived sessions, and still offers **Unpin**.
5. Until the workspace baseline is ready, pin details fail closed: they omit **Open**, explain that session availability is not ready, and retain **Unpin**.
6. A persisted id that is not currently resolvable is shown as unavailable and still offers **Unpin**.
7. A footer action shows **Pin current session** or **Unpin current session**.
8. With no pins, the menu shows an explicit empty state.

The current session can be pinned only when it is non-blank and is not a subagent-origin session. This keeps persisted pins addressable through the ordinary session list after reload. Archived ordinary sessions remain in the runtime list, so the menu can preserve their current titles and distinguish them from stale ids.

DeepSeek Harness `0.1.0-rc.6` exposes archived ids through the public workspace snapshot but immediately clears any archived id selected through `sessions.open()`. It exposes no public unarchive operation. The plugin therefore treats archived pins as version-limited records: visible by title and removable, but not openable. Archive membership is treated as actionable only when `baselinesReady`, `phase === 'ready'`, and `state === 'idle'`; pending, loading, and error snapshots fail closed. This avoids exposing a transient **Open** action or reporting a false success.

The most recently pinned session appears first. Re-pinning an existing id moves it to the front without creating a duplicate.

## Client architecture

The browser plugin injects:

- `slots`, to register into `sidebar.footer.action`;
- `sessions`, to read the list and open a selected session;
- `workspaces`, to guard baseline readiness and archived ids through the public workspace snapshot; and
- `locale`, to register English and Chinese dictionaries.

Registration waits through `ctx.slots.inject('sidebar.footer.action', ...)`, so activation order does not matter and the contribution follows the declaring slot's lifecycle.

The component receives:

- the slot owner's `wide` flag;
- the standard `useSessions` selector hook;
- the standard `useWorkspaces` selector hook, including baseline lifecycle state and `archivedSessionIds`;
- a plugin-private `usePinnedSessions` selector hook; and
- plain callbacks for `open`, `pin`, and `unpin`.

The component never receives or reads `ctx`.

## Persistence

A small React-free `PinnedSessionStore` owns a reference-stable snapshot of pinned ids.

On startup it:

1. reads `dsh.session-pins.v1`;
2. parses a versioned JSON object;
3. accepts at most 100 non-empty string ids;
4. removes duplicates while preserving order; and
5. falls back to an empty list when storage is absent, malformed, or unavailable.

Writes replace the complete versioned value. Storage failures do not break the UI. A `storage` event listener updates the snapshot when another tab in the same browser changes the pins. The listener and slot registration are disposed with the plugin fiber.

The persisted format is:

```ts
interface PersistedPinsV1 {
  version: 1
  ids: string[]
}
```

## Error handling

- Missing or blocked `localStorage`: pins remain usable for the current page but are not persisted.
- Malformed stored data: ignore it and start with no pins.
- Unknown persisted id: render an unavailable entry with an unpin action.
- Workspace baseline not ready: omit the open action, show localized availability copy, and re-evaluate when the standard workspace hook publishes.
- Archived persisted id: retain its title, omit the open action, show the localized Harness limitation, and keep it removable.
- Session disappears between render and activation: contain the `sessions.open` failure, show localized menu feedback, keep the menu usable, and leave the pin removable.
- Session becomes archived between render and activation: reject the open callback after re-reading the workspace archive snapshot.
- No eligible current session: disable the pin-current action with explanatory copy.
- Duplicate activation or slot declaration loss: Cordis lifecycle disposal prevents retained registrations and listeners.

## Styling and accessibility

- Consume Harness semantic CSS variables; do not hardcode theme colors.
- Use the official `Menu` and `Tooltip` primitives.
- Use a package-owned inline SVG pin icon because the current primitive set has no pin icon.
- Keep all actions keyboard reachable.
- Supply visible focus treatment, `aria-label` text, menu roles, and tooltips in both supported locales.
- Truncate long titles visually while preserving the full title in accessible text and tooltip copy.

## Testing

### Unit tests

- valid storage hydration;
- malformed and unavailable storage fallback;
- duplicate removal and bounded validation;
- pin, repin, unpin, and persistence;
- cross-tab storage-event reconciliation;
- reference-stable snapshots between changes.

### Component tests

- wide and collapsed action rendering;
- empty menu;
- eligible and ineligible current sessions;
- pin/unpin current;
- open and unpin pinned sessions;
- unavailable persisted ids;
- pending, loading, and error workspace states fail closed and transition correctly when readiness changes;
- archived sessions omit **Open**, show localized limitation copy, and remain removable;
- an archive race is rejected by the callback;
- a ready detail becoming archived preserves focus on a remaining menu action;
- English and Chinese copy;
- keyboard and accessible labels.

### Composition and artifact tests

- registration waits for and fills `sidebar.footer.action`;
- disposal removes the contribution and storage listener;
- package manifest and patch declarations are valid;
- built Node, invariant, and client entry points exist;
- packed contents include every exported artifact;
- an isolated DeepSeek Harness profile loads the bundle, publishes the package-name boot row, and serves the browser module route;
- profile smoke teardown awaits the server child's exit before deleting temporary state.

### Required verification

- formatting check;
- TypeScript typecheck;
- lint;
- unit/component tests;
- production build;
- package-content verification;
- local profile installation smoke test;
- browser visual check in wide and collapsed sidebar states.

No test requires `DEEPSEEK_API_KEY`.

## Compatibility

DeepSeek Harness is in developer preview and publishes breaking release candidates. The README will state the exact tested Harness release. CI will pin that release for reproducibility, while a separate non-blocking compatibility check may track the current `next` tag.

The implementation will import value-bearing client APIs only through documented `./client` entry points and will not depend on monorepo source paths.

Archive handling is explicitly version-scoped: `0.1.0-rc.6` publishes archive membership but no supported reopen or unarchive operation. A later Harness release may allow the plugin to restore **Open** after an acceptance test proves the public contract works.

## Publication

After verification:

1. create `alooshxl/dsh-session-pins`;
2. push the tested source and prebuilt Git-install artifacts;
3. add the repository description and `dsh-plugin` topic;
4. create a tagged initial release;
5. fork `AdamPlatin123/awesome-dsh-plugins`;
6. add the plugin to `PLUGINS.md`;
7. open a catalog pull request from `alooshxl`; and
8. reply to DeepSeek Harness Discussion #63 with the plugin link and tested installation command.

No pull request will be opened against `deepseek-ai/deepseek-harness` while its contribution policy rejects external code.

## Acceptance criteria

- A user can pin the current ordinary session in at most two interactions.
- Pinned ids survive reload and reconcile across same-origin tabs.
- A pinned archived session stays identifiable and removable without presenting an action that rc.6 cannot complete.
- A pin cannot present **Open** until the public workspace baseline makes archive membership authoritative.
- Invalid storage and stale session ids cannot crash the client.
- Disposing the plugin fiber in supported lifecycle paths leaves no slot registration, listener, or style element behind.
- Every automated check is green.
- The public repository is installable from its documented GitHub reference.
- The plugin is submitted through a pull request authored by `alooshxl` to the community catalog.
