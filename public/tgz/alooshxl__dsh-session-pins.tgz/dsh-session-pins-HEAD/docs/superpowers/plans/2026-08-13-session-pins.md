# DSH Session Pins Implementation Plan

> **For agent:** REQUIRED SUB-SKILL: Use executing-plans to implement this plan task-by-task.

**Goal:** Publish an installable DeepSeek Harness plugin that lets users persistently pin and reopen non-archived ordinary sessions from a supported sidebar footer menu, keeps archived pins identifiable and removable under the rc.6 host limitation, then submit it to the community plugin catalog from `alooshxl`.

**Architecture:** A browser-only Cordis client plugin registers one `sidebar.footer.action` component. A small React-free repository validates and persists ordered session ids in `localStorage`, exposes an observable snapshot to the slot renderer, and reconciles same-origin tab changes. The React component consumes the official global `useSessions` and `useWorkspaces` hooks, plugin-owned pin snapshots, locale dictionaries, and callback-only business actions; the Node half is an empty package-registration shell.

**Tech Stack:** TypeScript 6, React 18, Cordis, DeepSeek Harness `0.1.0-rc.6` client contracts, tsdown, Lightning CSS, Vitest, Testing Library, jsdom, oxlint, Prettier, pnpm 11, GitHub Actions.

**Pinned references:**

- Community template: `omdsh-dev/plugin-template@68e1a7dce77471d0850c2c8e4e68d508be885917`
- DeepSeek Harness contracts: `deepseek-ai/deepseek-harness@47f943859bef60e4160492346772ded9b24f765a`
- Tested package release: `@deepseek-ai/dsh@0.1.0-rc.6`
- Approved design: `docs/superpowers/specs/2026-08-13-session-pins-design.md`

---

## Task 1: Bootstrap a reproducible standalone plugin package

**Files:**

- Add template baseline: `.gitignore`, `AGENTS.md`, `docs/dsh-plugin-contracts.md`, `scripts/verify-self-contained.mjs`
- Add/replace: `package.json`
- Add/replace: `pnpm-workspace.yaml`
- Add/replace: `tsconfig.base.json`
- Add/replace: `tsconfig.json`
- Add: `tsconfig.build.json`
- Add/replace: `tsconfig.vitest.json`
- Add/replace: `vitest.config.ts`
- Add/replace: `tsdown.config.ts`
- Add: `Makefile`
- Add: `.prettierignore`
- Add: `.prettierrc.json`
- Add: `LICENSE`

### Step 1: Import only the template's repository-local baseline

Copy the pinned template revision without its `.git`, placeholder README, source, tests, generated lockfile, or design docs. Preserve this repository's existing `docs/superpowers/` files.

Expected baseline:

```text
AGENTS.md
docs/dsh-plugin-contracts.md
scripts/verify-self-contained.mjs
```

Remove template behavior, host-patch machinery, install-time build scripts, and references that do not apply to a browser-only plugin. Keep every source, config, and documentation path inside this repository.

### Step 2: Define package identity and compatibility

Set these manifest fields:

```json
{
  "name": "@dsh-external/dsh-session-pins",
  "version": "0.1.0",
  "private": true,
  "type": "module",
  "packageManager": "pnpm@11.7.0",
  "engines": { "node": "^22.19.0 || >=24.0.0" },
  "main": "lib/index.js",
  "types": "lib/types/index.d.ts"
}
```

Expose `.`, `./client`, `./invariant`, `./src/*`, `./cordis.patch.yml`, and `./package.json`. Include tracked `lib/`, `src/`, `cordis.patch.yml`, both READMEs, and `LICENSE` in packed contents.

Declare:

```json
{
  "dsh": {
    "bundle": { "patch": "./cordis.patch.yml" },
    "client": {
      "inject": [
        "@deepseek-ai/dsh-client-runtime",
        "@deepseek-ai/dsh-client-locale",
        "@deepseek-ai/dsh-client-ui-sidebar"
      ],
      "platform": "web"
    }
  }
}
```

Use `@deepseek-ai/cordis@^4.0.1` as the only peer dependency. Pin all imported DeepSeek Harness development packages to `0.1.0-rc.6`; use React 18.2 to match the host. Install current compatible test/build tools through pnpm rather than inventing versions.

Do not declare an install-time `prepare` lifecycle: initial GitHub distribution ships reviewed, tracked `lib/` artifacts, so installation does not request permission to execute build scripts.

### Step 3: Add mandatory commands

Provide scripts for:

```json
{
  "build": "tsc -p tsconfig.build.json && tsdown",
  "clean": "node scripts/clean.mjs",
  "format": "prettier --write .",
  "format:check": "prettier --check .",
  "lint": "oxlint --deny-warnings src tests scripts *.ts",
  "test": "vitest run",
  "typecheck": "tsc -p tsconfig.json --noEmit && tsc -p tsconfig.vitest.json --noEmit",
  "verify:self-contained": "node scripts/verify-self-contained.mjs",
  "verify:package": "node scripts/verify-package.mjs"
}
```

`Makefile` must map `fmt`, `test`, and `lint` to the corresponding pnpm commands, with `lint` including typechecking.

### Step 4: Install and lock dependencies

Run:

```sh
pnpm install
pnpm run verify:self-contained
```

Expected: lockfile generated and no source/config path escapes the repository.

### Step 5: Commit the bootstrap

```sh
git add .
git commit -m "build: scaffold standalone session pins plugin"
```

---

## Task 2: Build the validated pin repository test-first

**Files:**

- Add: `src/client/pin-repository.ts`
- Add: `tests/pin-repository.spec.ts`

### Step 1: Write failing hydration tests

Cover:

- absent value produces `{ ids: [] }`;
- `{ version: 1, ids: [...] }` hydrates;
- malformed JSON, wrong version, and a non-array `ids` field fall back to empty;
- invalid array entries (non-strings and empty strings) are discarded while valid ids remain;
- duplicate ids preserve their first occurrence;
- input is capped at `MAX_PINNED_SESSIONS = 100`;
- repeated `getSnapshot()` calls return the same object until state changes.

Use a fake `StorageLike`; do not depend on jsdom for pure repository tests.

Run:

```sh
pnpm vitest run tests/pin-repository.spec.ts
```

Expected: FAIL because the repository does not exist.

### Step 2: Implement strict parsing and a reference-stable snapshot

Implement:

```ts
export interface PinnedSessionsSnapshot {
  readonly ids: readonly string[]
}

export interface StorageLike {
  getItem(key: string): string | null
  setItem(key: string, value: string): void
}

export const PIN_STORAGE_KEY = 'dsh.session-pins.v1'
export const MAX_PINNED_SESSIONS = 100
```

Validate unknown JSON structurally before accepting it. Store ids as immutable ordered strings and publish a new frozen snapshot only when the normalized sequence changes.

### Step 3: Write failing mutation and failure tests

Cover:

- pin prepends;
- pinning an existing id moves it to the front;
- unpin removes exactly that id;
- pinning past the cap drops the oldest id;
- writes serialize `{ version: 1, ids }`;
- a throwing `getItem` starts empty;
- a throwing `setItem` still updates in-memory state;
- subscribers fire once per actual state change and can unsubscribe.

Run the focused test and confirm the new cases fail.

### Step 4: Implement mutations

Keep one private `commit(ids, persist)` path. Do not publish or write for a no-op sequence. Catch storage exceptions at the boundary.

### Step 5: Write failing cross-tab lifecycle tests

Define a narrow event source:

```ts
export interface StorageEventLike {
  readonly key: string | null
  readonly newValue: string | null
  readonly storageArea?: StorageLike | null
}
```

Test that `connect(eventSource)`:

- adopts valid changes for the owned key;
- adopts `[]` when the key is removed;
- ignores unrelated keys and different storage areas;
- sanitizes malformed external values;
- returns a disposer that removes the event listener.

### Step 6: Implement event reconciliation and verify

Run:

```sh
pnpm vitest run tests/pin-repository.spec.ts
```

Expected: PASS.

### Step 7: Commit repository behavior

```sh
git add src/client/pin-repository.ts tests/pin-repository.spec.ts
git commit -m "feat: add resilient pinned-session persistence"
```

---

## Task 3: Build the footer menu component test-first

**Files:**

- Add: `src/client/locales.ts`
- Add: `src/client/PinIcon.tsx`
- Add: `src/client/PinnedSessionsAction.tsx`
- Add: `src/client/PinnedSessionsAction.module.css`
- Add: `src/css-modules.d.ts`
- Add: `tests/platform/primitives-stub.tsx`
- Add: `tests/pinned-sessions-action.spec.tsx`

### Step 1: Define locale contracts

Create symmetric `zh` and `en` dictionaries for:

- trigger and menu title;
- empty state;
- open, pin current, unpin current, and unpin actions;
- unavailable-session label;
- archived-session limitation;
- workspace-availability-not-ready explanation;
- no-current, blank-current, and subagent-current explanations;
- generic open failure.

Make Chinese the key-set source and check English with `satisfies Record<SessionPinsKey, string>`.

### Step 2: Write failing render and accessibility tests

The component props must compose:

```ts
PropsRuntime<'sidebar.footer.action'>
  & InjectFace<SessionPinsFace>
  & PropsLocale<'sessionPins'>
```

Test:

- wide trigger includes icon, label, count, and `aria-expanded`;
- rail trigger renders only the icon but keeps an accessible name and tooltip;
- empty state appears after activation;
- Escape and outside-close callbacks close the menu;
- all actions are keyboard-reachable buttons;
- English and Chinese dictionaries have exactly the same keys.

Stub only the official primitives' presentation boundary; preserve `Menu` selection, disabled rows, footer entries, and `Tooltip` child behavior.

Run:

```sh
pnpm vitest run tests/pinned-sessions-action.spec.tsx
```

Expected: FAIL because the component does not exist.

### Step 3: Implement the trigger and empty menu

Use the official `Menu` with `portal`, `side="top"`, and compact rows. Use the official `Tooltip` only in rail mode. The package-owned pin SVG uses `currentColor`, is decorative, and has no hardcoded theme color.

Use only Harness semantic variables in CSS. Match the official footer action dimensions:

- wide: 49px row, 12px radius;
- rail: 36px circular action;
- hover: `--dsw-alias-interactive-bg-hover-solid`;
- text: `--dsw-alias-label-primary` and tertiary count.

### Step 4: Write failing session behavior tests

Provide fake `useSessions`, `useWorkspaces`, and `usePinnedSessions` selector hooks. Cover:

- current ordinary non-blank session can be pinned;
- blank current session is disabled with an explanation;
- subagent-origin current session is disabled with an explanation;
- current pinned session offers unpin;
- resolvable pins use live `displayTitle`;
- pending, loading, and error workspace states fail closed without **Open**, then transition to openable or archived when readiness changes;
- a ready/openable detail that becomes archived removes **Open**, preserves keyboard focus inside the menu, and shows the archived explanation;
- archived-but-listed pins retain their title, omit **Open**, explain the Harness limitation, and remain removable;
- stale ids render unavailable but remain removable;
- most-recent pin order is preserved;
- failed open produces localized `role="alert"` feedback without closing the only recovery path.

### Step 5: Implement menu derivation and callbacks

Selecting a stable pin entry opens a scroll-safe drill-down action view, and every generated menu action dispatches through an exact action `Map` without parsing or casting opaque IDs. Resolve persisted strings through `sessions.byId`; read baseline lifecycle and archive membership through the public workspace snapshot. Show **Open** only when `baselinesReady`, `phase === 'ready'`, and `state === 'idle'`.

The footer contains the current-session action. Derive eligibility from:

```ts
summary !== undefined && !summary.blank && summary.origin !== 'subagent'
```

Do not read Cordis context, browser storage, or service objects in the component; consume only the standard selector hooks and injected callback face.

### Step 6: Verify component behavior

Run:

```sh
pnpm vitest run tests/pinned-sessions-action.spec.tsx
```

Expected: PASS.

### Step 7: Commit the UI

```sh
git add src/client src/css-modules.d.ts tests/platform tests/pinned-sessions-action.spec.tsx
git commit -m "feat: add accessible pinned sessions menu"
```

---

## Task 4: Register the client plugin and package shells

**Files:**

- Add: `src/client/index.ts`
- Add: `src/index.ts`
- Add: `src/invariant.ts`
- Add: `cordis.patch.yml`
- Add: `tests/client-activation.spec.ts`
- Add/replace: `tests/harness.ts`
- Add/replace: `tests/plugin.spec.ts`

### Step 1: Write failing activation tests

With a lifecycle-aware fake client context, assert that `apply`:

- registers `sessionPins` dictionaries;
- waits for `sidebar.footer.action`;
- registers id `session-pins` exactly once;
- supplies the pin repository observable and business callbacks;
- removes locale, slot, repository subscription, and storage listener effects on disposal.

Exercise callbacks against fake session snapshots:

- `pinSession(id)` rejects missing, blank, and subagent summaries;
- `openSession(id)` rejects stale, subagent, archived, and workspace-not-ready states after re-reading public snapshots, and catches `sessions.open` failures;
- `unpinSession(id)` always removes the stored id.

### Step 2: Implement the browser entry

Declare:

```ts
export const inject = ['slots', 'locale', 'sessions', 'workspaces']
```

Register locale and storage listeners through Cordis-owned effects. Register into the slot through:

```ts
ctx.slots.inject('sidebar.footer.action', () =>
  ctx.slots.register(
    {
      name: 'sidebar.footer.action',
      id: 'session-pins',
      order: 20,
      locale: 'sessionPins',
      inject: () => ({
        hooks: { pinnedSessions: repository },
        pinSession,
        unpinSession,
        openSession,
      }),
    },
    PinnedSessionsAction,
  ),
)
```

Return booleans from guarded business actions so the component can show localized feedback without receiving exceptions or `ctx`.

### Step 3: Implement Node and invariant entries

`src/index.ts` exports the stable name and an empty `apply` function with a package-specific explanation: all product behavior is in `./client`.

`src/invariant.ts` exports a separate function plugin and registers package ownership with `ctx.invariants`. Its installer is intentionally empty because the plugin owns no host events or cross-plugin state; document that exact reason.

### Step 4: Compose the bundle

`cordis.patch.yml` inserts one row:

```yaml
- insert:
    - id: dsh-session-pins
      name: '@dsh-external/dsh-session-pins'
```

Do not mount a second package row solely for the invariant; the browser module must be discovered once.

### Step 5: Add Loader and composition tests

Using real scoped Cordis/Loader packages:

- load `src/index.ts` and confirm the function-plugin namespace survives Loader unwrapping;
- load `src/invariant.ts` and confirm its package registration disposes;
- parse the patch and confirm package/id alignment;
- confirm the client export declares only supported service dependencies.

Run:

```sh
pnpm vitest run tests/client-activation.spec.ts tests/plugin.spec.ts
```

Expected: PASS.

### Step 6: Commit activation and composition

```sh
git add src/index.ts src/invariant.ts src/client/index.ts cordis.patch.yml tests
git commit -m "feat: register session pins with the Harness sidebar"
```

---

## Task 5: Produce self-contained browser and Node artifacts

**Files:**

- Update: `tsdown.config.ts`
- Update: `tsconfig.build.json`
- Add: `scripts/clean.mjs`
- Add: `scripts/verify-package.mjs`
- Add: `tests/artifacts.spec.ts`
- Generate and track: `lib/index.js`
- Generate and track: `lib/invariant.js`
- Generate and track: `lib/client.js`
- Generate and track: `lib/client.js.map`
- Generate and track: `lib/types/**`

### Step 1: Write failing artifact checks

Assert after a build:

- every manifest export target exists;
- Node entries are ESM;
- the browser entry is a `window.__ModuleLoader__.load` closure;
- the browser bundle externalizes React and official platform modules;
- CSS is inlined with `data-plugin="@dsh-external/dsh-session-pins"` so ownership matches the package-name client graph row;
- packed contents contain no parent paths, secrets, temporary profiles, or unrelated template files.

### Step 2: Configure the build

Create two tsdown configurations:

1. Node ESM for `src/index.ts` and `src/invariant.ts`, externalizing `@deepseek-ai/*`.
2. Browser CJS closure for `src/client/index.ts`, externalizing exactly the Harness platform modules and runtime client contract.

Compile CSS Modules with Lightning CSS into idempotent plugin-owned style tags. Set `process.env.NODE_ENV` at build time. Emit declarations separately through `tsconfig.build.json`.

### Step 3: Build and verify

Run:

```sh
pnpm run clean
pnpm run build
pnpm vitest run tests/artifacts.spec.ts
pnpm run verify:package
```

Expected: all export targets and packed files are present.

### Step 4: Confirm tracked artifacts are reproducible

Run the build twice and compare the second git diff. The second build must not change `lib/`.

### Step 5: Commit distribution artifacts

```sh
git add tsdown.config.ts tsconfig.build.json scripts tests/artifacts.spec.ts lib package.json
git commit -m "build: ship self-contained Git install artifacts"
```

---

## Task 6: Add user documentation and continuous verification

**Files:**

- Add: `README.md`
- Add: `README.zh.md`
- Update: `AGENTS.md`
- Update: `docs/dsh-plugin-contracts.md`
- Add: `.github/workflows/ci.yml`
- Add: `CHANGELOG.md`

### Step 1: Document the public contract

Both READMEs must include:

- the community request and supported-slot rationale;
- wide/rail menu behavior;
- ordinary-session, blank-session, subagent, archived, and stale-id behavior;
- browser-local persistence and same-origin tab synchronization;
- exact tested Harness version;
- install, upgrade-to-tag, remove, and pin-to-commit commands;
- no credentials and no host patch;
- local development and every verification command;
- developer-preview compatibility warning;
- MIT license and contribution links.

Use this Git installation form:

```sh
dsh plugin --profile web add github:alooshxl/dsh-session-pins#v0.1.0
```

Explain that tracked build artifacts mean no install-time build allowlist is required.

### Step 2: Add CI

On pushes and pull requests, GitHub Actions must:

1. install Node 22 and pnpm 11.7;
2. run `pnpm install --frozen-lockfile`;
3. run formatting check, lint, typecheck, tests, build, self-contained verification, and package verification;
4. fail if rebuilding changes tracked `lib/`;
5. inspect `pnpm pack --dry-run --json`.

### Step 3: Run the mandatory checkpoint

Run:

```sh
make fmt && make test && make lint
pnpm run build
pnpm run format:check
pnpm run verify:self-contained
pnpm run verify:package
```

Every command must exit zero with no warnings treated as accepted debt.

### Step 4: Commit docs and CI

```sh
git add README.md README.zh.md AGENTS.md docs .github CHANGELOG.md Makefile pnpm-lock.yaml
git commit -m "docs: document and continuously verify session pins"
```

---

## Task 7: Run profile and browser acceptance checks

**Files:**

- Update: `package.json`
- Update: `pnpm-lock.yaml`
- Update if the dependency-policy window requires it: `pnpm-workspace.yaml`
- Update: `src/client/PinnedSessionsAction.tsx`
- Update: `src/client/locales.ts`
- Update: `src/client/index.ts`
- Update: `tests/pinned-sessions-action.spec.tsx`
- Update: `tests/pinned-sessions-action.integration.spec.tsx`
- Update: `tests/client-activation.spec.ts`
- Update: `tests/harness.ts`
- Update: `tests/documentation-ci.spec.ts`
- Update: `README.md`
- Update: `README.zh.md`
- Update: `CHANGELOG.md`
- Update: `AGENTS.md`
- Update: `docs/dsh-plugin-contracts.md`
- Add: `tests/smoke-profile.spec.ts`
- Regenerate and track: `lib/**`
- Add after visual approval: `docs/assets/session-pins.png`

### Step 1: Make archived-pin behavior honest for Harness rc.6

Use the public `useWorkspaces` hook to read baseline lifecycle and `archivedSessionIds`. Unless `baselinesReady`, `phase === 'ready'`, and `state === 'idle'`, every pin detail fails closed without **Open** and shows localized availability copy. Once actionable, an archived pin keeps its live title but its detail view omits **Open**, shows localized version-limitation copy, and retains **Unpin** and **Back**. The business callback must independently reject non-actionable and archived snapshots from `ctx.workspaces.list.getSnapshot()` to contain render-to-activation races.

Update the bilingual READMEs, changelog, documentation-contract tests, lifecycle harness, component tests, and generated artifacts. Do not add a private unarchive call, host patch, delayed selection workaround, or false-success close path.

### Step 2: Write a keyless profile smoke test

Add `@deepseek-ai/dsh@0.1.0-rc.6` as an exact development dependency. Use a temporary `DSH_HOME`, the local package, and that CLI to:

1. initialize the built-in `web` profile;
2. resolve the frozen root install's store path through the same pnpm 11.7 CLI, then add this package through a repository-relative pnpm file dependency using that explicit `--store-dir` and `--offline`;
3. dump the composed config;
4. assert the `dsh-session-pins` row appears once;
5. start the keyless web profile through the published CLI, parse its ephemeral loopback URL, and fetch the root boot manifest;
6. assert the package-name boot row appears once and its browser module route serves the built `lib/client.js` handoff;
7. assert the development graph allows only the exact rc.6 subprocess helper and `node-pty@1.1.0` host setup scripts needed by the stock Linux Web profile, while every other discovered lifecycle script remains denied; and
8. stop the child process and remove the temporary home.

The profile installation itself must still pass `--ignore-scripts`; the two version-qualified build approvals apply only to transitive development dependencies of the published compatibility CLI and do not enter the distributable plugin. No source checkout outside this repository and no API key may be required.

Treat the published `@deepseek-ai/dsh@0.1.0-rc.6` package as executable authority: the pinned public source commit predates that tarball.

Resolve the CLI package and bin through `createRequire`, spawn it with `process.execPath` and argument arrays (`shell: false`), keep `DSH_HOME` temporary, boot from an empty temporary workspace, blank inherited API credentials, and use event-driven stdout plus a bounded timeout to detect readiness. Do not use platform shell shims, sleeps, polling loops, or raw profile-file edits. Register the child's `close` event immediately after spawn. In `finally`, send the normal termination signal, await `close` within a bound, escalate to a forced kill only if needed, await `close` again, and only then recursively remove the temporary workspace and home.

### Step 3: Run the profile smoke

```sh
pnpm vitest run tests/smoke-profile.spec.ts
```

Expected: PASS.

### Step 4: Boot and visually inspect

Start the isolated profile in a background terminal, open the reported local URL, and verify:

- wide trigger layout and count;
- menu opens above the footer without clipping;
- empty state and current-session explanation;
- a validated stored pin renders in expected order;
- pins fail closed while workspace availability is not ready;
- an archived pin keeps its title, has no **Open** action, explains the rc.6 limitation, and remains removable;
- a stale stored id is removable;
- rail trigger tooltip and menu placement;
- keyboard focus, Escape close, and visible focus treatment;
- English and Chinese copy;
- reload and second-tab storage reconciliation.

Use browser snapshots plus screenshots. Stop on an authentication or browser-permission blocker rather than bypassing it.

### Step 5: Fix all observed defects and rerun the full checkpoint

Any visual, console, formatting, test, or lint issue is blocking. After fixes:

```sh
make fmt && make test && make lint
pnpm run build
git status --short --untracked-files=all -- lib
pnpm run format:check
pnpm run typecheck
pnpm run verify:self-contained
pnpm run verify:package
git diff --check
```

### Step 6: Commit acceptance support

```sh
git add package.json pnpm-lock.yaml pnpm-workspace.yaml AGENTS.md CHANGELOG.md README.md README.zh.md src tests scripts docs lib
git commit -m "test: verify installation and sidebar integration"
```

---

## Task 8: Publish under `alooshxl` and open the community PR

**Files:**

- Main repository: all verified plugin files and tracked artifacts
- Catalog fork: `PLUGINS.md`

### Step 1: Final repository audit

Run:

```sh
git status --short --branch
git diff
git log --oneline --decorate -10
make fmt && make test && make lint
pnpm run build
git status --short --untracked-files=all -- lib
pnpm run format:check
pnpm run typecheck
pnpm run verify:self-contained
pnpm run verify:package
git diff --check
git status --short --branch
```

Confirm GitHub CLI identity is `alooshxl`, no secret-bearing files are tracked, the `lib` drift command prints nothing, and the final worktree status is clean after rebuilding.

### Step 2: Create and push the public repository

```sh
gh repo create alooshxl/dsh-session-pins \
  --public \
  --source . \
  --remote origin \
  --push \
  --description "Persistent pinned-session menu for DeepSeek Harness"
gh repo edit alooshxl/dsh-session-pins \
  --add-topic dsh-plugin \
  --add-topic deepseek-harness \
  --add-topic cordis \
  --add-topic typescript
```

Verify the pushed default branch and CI before release.

### Step 3: Tag the verified initial release

Create annotated tag `v0.1.0`, push it, create the GitHub release, and attach the verified package tarball. Do not publish to npm in this task.

### Step 4: Prepare the catalog change on an `alooshxl` fork

Fork `AdamPlatin123/awesome-dsh-plugins`, clone the fork into its own project root, create branch `add-dsh-session-pins`, and append:

```md
| dsh-session-pins | [alooshxl/dsh-session-pins](https://github.com/alooshxl/dsh-session-pins) | 持久置顶并快速打开可用的 DeepSeek Harness 会话；归档项可识别并移除（运行级实测 ✅） |
```

Run the catalog's documented checks. Commit:

```sh
git commit -m "docs: add dsh-session-pins"
```

Push the branch and open a PR to `AdamPlatin123/awesome-dsh-plugins:main` with:

- a concise feature summary;
- the Discussion #63 link;
- the exact tested Harness release;
- installation and test evidence;
- the rc.6 archived-session limitation;
- confirmation of the `dsh-plugin` topic and package naming convention.

### Step 5: Respond to the original community request

Reply to [DeepSeek Harness Discussion #63](https://github.com/deepseek-ai/deepseek-harness/discussions/63) as `alooshxl` with:

- the plugin repository;
- the release/tag;
- the installation command;
- the supported sidebar-menu design, ordinary-session scope, and rc.6 archived-session limitation.

Do not open a code PR against `deepseek-ai/deepseek-harness`; its current contribution policy explicitly rejects external code PRs.

### Step 6: Return verifiable links

Return:

- `alooshxl/dsh-session-pins`;
- the `v0.1.0` release;
- the catalog pull request;
- the Discussion #63 response;
- CI status and exact local verification commands.

