# Standalone DSH Session Pins Contracts

This reference keeps the package, runtime, test, and distribution boundaries for this plugin explicit and repository-local.

## Repository boundary

All source, TypeScript configuration, tests, scripts, and contributor guidance live below the repository root. Describe files with project-root paths such as `docs/dsh-plugin-contracts.md`. Parent-directory navigation and local dependency specifications are not valid project inputs.

The DeepSeek Harness host consumes the finished package. It is not a source checkout or build input for this repository. Host contracts used during development come from registry packages pinned in `package.json`.

`README.md` and `README.zh.md` are equivalent public contracts. Behavior, compatibility, post-release Git commands, security boundaries, and verification guidance must change in both languages together.

## Package forms

The package exposes three function-plugin entry points:

- `.` mounts the Node registration shell;
- `./client` owns browser behavior; and
- `./invariant` registers package-owned invariant metadata.

Each entry preserves named function-plugin exports and has no default export. The Node entry contains no product behavior. The client entry is the only entry that reads browser APIs or contributes UI.

## Supported client boundary

The client plugin uses the official runtime, locale, sidebar, slots, primitives, and React bridge packages. It contributes one component through `sidebar.footer.action`. It must not replace the stock session browser, import Harness monorepo source paths, patch host code, or depend on private React component internals.

The manifest declares the runtime, locale, and sidebar packages in `dsh.client.inject` and uses the `web` platform. Value-bearing client APIs must be imported through published client entry points.

The browser plugin's Cordis injection list includes the public `workspaces` service supplied by the runtime package. The package-level `dsh.client.inject` list remains package based: the runtime package already owns that service, so no additional package dependency or host patch is required.

## Archived-session readiness boundary

Archive membership is actionable only when the public workspace snapshot reports `baselinesReady === true`, `phase === 'ready'`, and `state === 'idle'`. Pending, loading, error, and otherwise non-actionable snapshots fail closed: a resolvable pin keeps **Unpin** and **Back**, omits **Open**, and shows localized availability-not-ready copy.

DeepSeek Harness `0.1.0-rc.6` immediately clears an archived id selected through `sessions.open()` and exposes no public unarchive operation. Once the workspace snapshot is actionable, an archived pin keeps its live title and recovery actions but remains non-openable with localized version-limitation copy. The plugin does not call `sessions.open()` for that id, report a false success, use a timer, invoke a private API, or patch the host.

The activation callback independently re-reads both `ctx.sessions.list` and `ctx.workspaces.list` before opening. Missing, subagent, non-actionable, and archived ids are rejected before `sessions.open()` is called, containing render-to-activation races.

## Lifecycle ownership

Every listener, registry entry, observable subscription, and callback registered by the plugin belongs to its Cordis fiber. Effects return disposers, and tests verify cleanup. State is published only after the owning operation succeeds or a documented boundary error is contained.

## Invariant companion

`./invariant` is a separate function plugin that registers package ownership with the Harness invariants service. An empty installer is valid because session pins own no host event or cross-plugin data relationship. The source must explain that reason.

## Bundle composition

`package.json` declares `dsh.bundle.patch` as `./cordis.patch.yml`. The patch inserts one package row so Harness can discover the Node and browser modules. It does not modify source files, compiler settings, launchers, catalogs, or host code.

The patch row uses Cordis id `dsh-session-pins`, but the browser module graph identity is the full package name `@dsh-external/dsh-session-pins`. The client bundle handoff id, injected style `data-plugin` value, CSS ownership id prefix, and package manifest name must retain that exact package-name identity.

## Build and distribution

The package uses TypeScript for declarations and tsdown for runtime artifacts. `lib/` is generated from repository source, reviewed, and tracked for Git installation. The package does not declare `prepare` or another install-time lifecycle script.

Both READMEs are mandatory package files. The explicit dry-run inventory consists only of `package.json`, `LICENSE`, `cordis.patch.yml`, `README.md`, `README.zh.md`, and files below `lib/` and `src/`. It must contain every runtime and declaration target, report the expected package name and version, use nonempty unique safe root-relative paths, and leave no tarball behind.

The supported local checkpoint is:

```sh
make fmt
make test
make lint
```

Its exact command equivalent on systems without GNU Make is:

```sh
pnpm run format
pnpm run test
pnpm run lint
pnpm run typecheck
```

The remaining release verification sequence is:

```sh
pnpm run build
pnpm run format:check
pnpm run typecheck
pnpm run verify:self-contained
pnpm run verify:package
git diff --check
git status --short --untracked-files=all -- lib
```

`pnpm run verify:package` performs local dry-run pack validation through the repository's compatible package-manager resolver.

The final status command must produce no output. A rebuild that changes a tracked `lib/` file or creates an untracked `lib/` file is generated-artifact drift and fails CI.

`scripts/verify-self-contained.mjs` accepts an optional repository-root argument only for isolated fixture tests. Normal repository verification uses `pnpm run verify:self-contained` without that override.

The distributable plugin declares no install-time lifecycle script and its profile installation always uses `--ignore-scripts`. The repository development graph approves exactly two version-qualified host setup scripts: `@deepseek-ai/dsh-subprocess-local@0.1.0-rc.6` and `node-pty@1.1.0`. They are transitive dependencies of the exact rc.6 CLI used by the Linux smoke, are absent from the packed plugin contract, and are required for the stock Web profile to boot on Ubuntu. Every other discovered `allowBuilds` decision remains explicitly `false`. The minimum-release-age exemptions name only the exact approved Harness rc.6 and scoped Cordis dependency graph published inside the active policy window.

## Isolated profile evidence

The exact `@deepseek-ai/dsh@0.1.0-rc.6` development dependency is the executable compatibility authority. `tests/smoke-profile.spec.ts` also locks the two audited `allowBuilds: true` entries by full package version, rejects any broader build allowance, creates a temporary `DSH_HOME`, resolves pnpm 11.7 from the frozen root installation, initializes the built-in Web profile, and installs this repository through an offline repository-relative file dependency and the explicit root store.

The smoke test dumps the composed config and requires exactly one `dsh-session-pins` row. It then boots the published CLI from an empty temporary workspace on an OS-assigned loopback port, with inherited API credentials blanked so a project `.env` cannot refill them. It fetches the real root page, requires exactly one `@dsh-external/dsh-session-pins` boot entry, and verifies that entry's route serves the tracked `lib/client.js` bytes with JavaScript and no-cache headers. Teardown registers the child's `close` event immediately after spawn, sends the normal termination signal, waits within a bound, escalates only when necessary, awaits `close`, and only then removes the temporary workspace and home.

## Continuous verification

Push and pull-request CI uses read-only repository permissions, cancels superseded runs in the same concurrency group, and runs on Ubuntu 24.04 with a 20-minute job timeout. External actions are pinned to immutable commit SHAs, and checkout credentials are not persisted. CI installs Node 22 first with automatic package-manager caching disabled, then uses `pnpm/action-setup` with pnpm 11.7.0, `standalone: false`, action-managed installation disabled, and no pnpm store cache.

After a frozen install, CI runs formatting, lint, typecheck, tests, build, tracked-plus-untracked `lib/` drift detection, self-contained verification, package verification, and a separate semantic inspection of `pnpm pack --dry-run --json`. That direct command is CI-only: the standalone pnpm 11.7.0 executable does not support its `--dry-run` option, while the deliberately non-standalone JavaScript CLI does. The independent inspection does not delegate to `scripts/verify-package.mjs`; it checks package identity, nonempty unique safe paths, both READMEs, runtime entries, and absence of tarball creation.

## Evidence

Behavior changes require focused tests, real Cordis lifecycle coverage, export-shape checks, bundle-composition checks, and artifact verification. Browser-visible changes additionally require accessibility checks and visual acceptance in both wide and collapsed sidebar layouts.

Publishing, pushing, tagging, profile installation, and external catalog changes remain separately authorized actions.
