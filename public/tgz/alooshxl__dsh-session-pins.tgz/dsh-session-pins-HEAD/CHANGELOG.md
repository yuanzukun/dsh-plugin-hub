# Changelog

## [0.1.0] - 2026-08-13

### Added

- A browser-only `sidebar.footer.action` menu for pinning, opening, and
  removing ordinary DeepSeek Harness sessions in wide and rail sidebar modes.
- Validated browser-local persistence for up to 100 ordered pins, including
  same-origin tab reconciliation and stale-id recovery.
- English and Chinese UI dictionaries and public documentation.
- Public workspace-readiness and archived-session safeguards that fail closed
  for non-actionable state and the Harness rc.6 reopen limitation.
- Reproducible tracked Node, invariant, client, declaration, and source-map
  artifacts for Git installation without install-time lifecycle scripts.
- Lifecycle, accessibility, package-content, self-containment, and continuous
  verification coverage targeting `@deepseek-ai/dsh@0.1.0-rc.6`.
- An isolated, keyless rc.6 profile smoke that installs the local package
  offline, verifies composed and browser boot rows, and fetches `lib/client.js`
  through the live Harness module route, with only the two exact transitive
  host setup scripts needed by the stock Linux profile approved in the frozen
  development graph.
