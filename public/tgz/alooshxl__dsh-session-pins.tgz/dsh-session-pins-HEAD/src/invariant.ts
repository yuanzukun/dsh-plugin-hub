import type { Context } from '@deepseek-ai/cordis'
import type { InvariantInstaller } from '@deepseek-ai/dsh-invariants'

const PACKAGE_NAME = '@dsh-external/dsh-session-pins'

export const name = 'dsh-session-pins-invariant'
export const inject = ['invariants']

/**
 * No runtime invariant: browser-local pure-consumer plugin owns no host events or mutable cross-plugin state.
 */
const install: InvariantInstaller = () => {}

/**
 * Registers this package's invariant ownership.
 *
 * @returns The registration disposer after setup succeeds.
 */
export const apply = (ctx: Context): Promise<() => void> =>
  Promise.resolve(ctx.invariants.register(PACKAGE_NAME, install))
