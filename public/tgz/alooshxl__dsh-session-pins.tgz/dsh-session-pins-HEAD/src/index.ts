import type { Context } from '@deepseek-ai/cordis'

export const name = 'dsh-session-pins'

/**
 * Registers the session pins package for client-module discovery.
 *
 * All product behavior is implemented by this package's `./client` entry.
 */
export function apply(_ctx: Context): void {}
