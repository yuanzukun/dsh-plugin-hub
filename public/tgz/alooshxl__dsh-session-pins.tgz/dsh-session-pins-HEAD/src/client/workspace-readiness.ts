import type { WorkspaceListState } from '@deepseek-ai/dsh-client-runtime/client'

export type WorkspaceSessionStatus = 'not-ready' | 'archived' | 'openable'

export function workspaceSessionStatus(
  snapshot: WorkspaceListState,
  sessionId: string,
): WorkspaceSessionStatus {
  if (snapshot.baselinesReady !== true || snapshot.phase !== 'ready' || snapshot.state !== 'idle') {
    return 'not-ready'
  }

  return snapshot.archivedSessionIds.some((archivedId) => archivedId === sessionId)
    ? 'archived'
    : 'openable'
}
