import type { ClientContext, SessionSummary } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'

import { PinnedSessionsAction, type SessionPinsFace } from './PinnedSessionsAction.tsx'
import { en, NS, zh } from './locales.ts'
import { PinRepository, type StorageLike } from './pin-repository.ts'
import { workspaceSessionStatus } from './workspace-readiness.ts'

export const inject = ['slots', 'locale', 'sessions', 'workspaces']

function resolveBrowserWindow(): Window | undefined {
  return typeof window === 'undefined' ? undefined : window
}

function resolveStorage(browserWindow: Window | undefined): StorageLike | undefined {
  if (browserWindow === undefined) return undefined

  try {
    return browserWindow.localStorage
  } catch {
    return undefined
  }
}

function findSummary(ctx: ClientContext, id: string): SessionSummary | undefined {
  return Object.values(ctx.sessions.list.getSnapshot().byId).find((summary) => summary.id === id)
}

export function apply(ctx: ClientContext): void {
  const browserWindow = resolveBrowserWindow()
  const repository = new PinRepository(resolveStorage(browserWindow))

  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'session-pins.locale')

  if (browserWindow !== undefined) {
    ctx.effect(() => repository.connect(browserWindow), 'session-pins.storage')
  }

  const pinSession = (id: string): boolean => {
    const summary = findSummary(ctx, id)
    if (summary === undefined || summary.blank || summary.origin === 'subagent') return false

    repository.pin(summary.id)
    return true
  }

  const unpinSession = (id: string): void => {
    repository.unpin(id)
  }

  const openSession = (id: string): boolean => {
    const summary = findSummary(ctx, id)
    const workspaceStatus = workspaceSessionStatus(ctx.workspaces.list.getSnapshot(), id)
    if (summary === undefined || summary.origin === 'subagent' || workspaceStatus !== 'openable') {
      return false
    }

    try {
      ctx.sessions.open(summary.id)
      return true
    } catch {
      return false
    }
  }

  ctx.slots.inject('sidebar.footer.action', () =>
    ctx.slots.register(
      {
        name: 'sidebar.footer.action',
        id: 'session-pins',
        order: 20,
        locale: NS,
        inject: (): SessionPinsFace => ({
          hooks: { pinnedSessions: repository },
          pinSession,
          unpinSession,
          openSession,
        }),
      },
      PinnedSessionsAction,
    ),
  )
}
