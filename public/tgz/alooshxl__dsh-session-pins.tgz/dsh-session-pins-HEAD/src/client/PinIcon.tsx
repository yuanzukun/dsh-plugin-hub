import type { SVGProps } from 'react'

export function PinIcon({ width = 18, height = 18, ...props }: SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      width={width}
      height={height}
      viewBox="0 0 18 18"
      fill="none"
      aria-hidden="true"
      focusable="false"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill="currentColor"
        d="M11.93 1.5a.75.75 0 0 1 .53 1.28l-.72.72 2.76 2.76.72-.72a.75.75 0 1 1 1.06 1.06l-1.25 1.25a2.75 2.75 0 0 1-2.51.75l-1.63 1.63.44 2.08a.75.75 0 0 1-.2.68l-.88.88a.75.75 0 0 1-1.06 0L7.1 11.79l-3.57 3.57a.75.75 0 0 1-1.06-1.06l3.57-3.57-2.08-2.08a.75.75 0 0 1 0-1.06l.88-.88a.75.75 0 0 1 .68-.2l2.08.44 1.63-1.63a2.75 2.75 0 0 1 .75-2.51l1.25-1.25a.75.75 0 0 1 .7-.06Zm-.89 2.37a1.25 1.25 0 0 0-.25 1.4.75.75 0 0 1-.17.8L8.37 8.32a.75.75 0 0 1-.68.2l-2.08-.44-.06.06 4.17 4.17.06-.06-.44-2.08a.75.75 0 0 1 .2-.68l2.25-2.25a.75.75 0 0 1 .8-.17 1.25 1.25 0 0 0 1.4-.25l-2.7-2.7-.25.25Z"
      />
    </svg>
  )
}
