import { Menu, Tooltip } from '@deepseek-ai/dsh-client-ui-primitives'
import type { SessionSummary } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import type {
  HostObservable,
  InjectFace,
  PropsLocale,
  PropsRuntime,
} from '@deepseek-ai/dsh-client-ui-slots'
import {
  useCallback,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentProps,
} from 'react'

import styles from './PinnedSessionsAction.module.css'
import { PinIcon } from './PinIcon.tsx'
import type { PinnedSessionsSnapshot } from './pin-repository.ts'
import { workspaceSessionStatus } from './workspace-readiness.ts'

export interface SessionPinsFace {
  hooks: {
    pinnedSessions: HostObservable<PinnedSessionsSnapshot>
  }
  pinSession(id: string): boolean
  unpinSession(id: string): void
  openSession(id: string): boolean
}

export type PinnedSessionsActionProps = PropsRuntime<'sidebar.footer.action'> &
  InjectFace<SessionPinsFace> &
  PropsLocale<'sessionPins'>

type MenuEntry = ComponentProps<typeof Menu>['items'][number]
type MenuItem = Exclude<MenuEntry, { type: 'separator' | 'label' }>

export function PinnedSessionsAction({
  wide,
  useSessions,
  useWorkspaces,
  usePinnedSessions,
  pinSession,
  unpinSession,
  openSession,
  t,
}: PinnedSessionsActionProps) {
  const [open, setOpen] = useState(false)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [openFailure, setOpenFailure] = useState<{
    readonly failedId: string
    readonly attempt: number
  } | null>(null)
  const idPrefix = useId()
  const triggerRef = useRef<HTMLButtonElement>(null)
  const focusMenuOnRenderRef = useRef(false)
  const focusedMenuItemRef = useRef<HTMLElement | null>(null)
  const outsidePointerCloseRef = useRef(false)
  const pinnedIds = usePinnedSessions((snapshot) => snapshot.ids)
  const sessionsById = useSessions((snapshot) => snapshot.byId)
  const currentId = useSessions((snapshot) => snapshot.current)
  const workspaces = useWorkspaces((snapshot) => snapshot)
  const summariesByStringId = new Map<string, SessionSummary>()

  for (const summary of Object.values(sessionsById)) {
    summariesByStringId.set(summary.id, summary)
  }

  const actionsById = new Map<string, () => void>()
  const registerAction = (id: string, action: () => void) => {
    actionsById.set(id, action)
    return id
  }
  const closeMenu = (restoreTriggerFocus = true) => {
    setOpen(false)
    setSelectedId(null)
    setOpenFailure(null)
    focusMenuOnRenderRef.current = false
    focusedMenuItemRef.current = null
    if (restoreTriggerFocus) triggerRef.current?.focus()
  }
  const registerUnpin = (actionId: string, sessionId: string) =>
    registerAction(actionId, () => {
      unpinSession(sessionId)
      closeMenu()
    })
  const focusLabel = (label: string) => (
    <span data-session-pins-focus-owner={idPrefix}>{label}</span>
  )
  const activeSelectedId = selectedId !== null && pinnedIds.includes(selectedId) ? selectedId : null
  const selectedWorkspaceStatus =
    activeSelectedId === null ? null : workspaceSessionStatus(workspaces, activeSelectedId)
  const titleFor = (persistedId: string) => {
    const summary = summariesByStringId.get(persistedId)
    return summary === undefined
      ? t('session.unavailable', { id: persistedId })
      : summary.displayTitle
  }
  const items: MenuEntry[] = []
  let availabilityAnnouncement = ''

  if (activeSelectedId === null) {
    items.push({
      type: 'label',
      id: `${idPrefix}-heading`,
      text: t('menu.heading'),
    })

    if (pinnedIds.length === 0) {
      items.push({
        type: 'label',
        id: `${idPrefix}-empty`,
        text: t('menu.empty'),
      })
    } else {
      for (const persistedId of pinnedIds) {
        const title = titleFor(persistedId)
        items.push({
          id: registerAction(`${idPrefix}-session-${persistedId}`, () => {
            setOpenFailure(null)
            focusMenuOnRenderRef.current = true
            setSelectedId(persistedId)
          }),
          label: (
            <span
              className={styles.sessionTitle}
              title={title}
              aria-label={title}
              data-session-pins-focus-owner={idPrefix}
            >
              {title}
            </span>
          ),
        })
      }
    }
  } else {
    const selectedSummary = summariesByStringId.get(activeSelectedId)
    items.push({
      type: 'label',
      id: `${idPrefix}-detail-heading`,
      text: titleFor(activeSelectedId),
    })

    if (selectedSummary !== undefined && selectedWorkspaceStatus === 'openable') {
      items.push({
        id: registerAction(`${idPrefix}-open-${activeSelectedId}`, () => {
          if (openSession(selectedSummary.id)) {
            closeMenu()
            return
          }

          setOpenFailure((failure) => ({
            failedId: activeSelectedId,
            attempt: (failure?.attempt ?? 0) + 1,
          }))
        }),
        label: focusLabel(t('action.open')),
      })
    } else if (selectedSummary !== undefined && selectedWorkspaceStatus !== null) {
      availabilityAnnouncement = t(
        selectedWorkspaceStatus === 'archived'
          ? 'session.archivedUnsupported'
          : 'session.availabilityNotReady',
      )
      items.push({
        type: 'label',
        id: `${idPrefix}-availability-${activeSelectedId}`,
        text: availabilityAnnouncement,
      })
    }

    items.push(
      {
        id: registerUnpin(`${idPrefix}-unpin-${activeSelectedId}`, activeSelectedId),
        label: focusLabel(t('action.unpin')),
      },
      {
        id: registerAction(`${idPrefix}-detail-back`, () => {
          setOpenFailure(null)
          focusMenuOnRenderRef.current = true
          setSelectedId(null)
        }),
        label: focusLabel(t('action.back')),
      },
    )
  }

  const currentSummary = currentId === undefined ? undefined : summariesByStringId.get(currentId)
  let currentAction: MenuItem
  let currentFooterLayout: readonly unknown[]
  if (currentId !== undefined && pinnedIds.includes(currentId)) {
    currentAction = {
      id: registerUnpin(`${idPrefix}-current-action`, currentId),
      label: focusLabel(t('action.unpinCurrent')),
    }
    currentFooterLayout = [currentId, 'unpin', t('action.unpinCurrent')]
  } else {
    let disabledReason: string | undefined

    if (currentSummary === undefined) {
      disabledReason = t('current.noSession')
    } else if (currentSummary.blank) {
      disabledReason = t('current.blank')
    } else if (currentSummary.origin === 'subagent') {
      disabledReason = t('current.subagent')
    }

    if (currentSummary !== undefined && disabledReason === undefined) {
      currentAction = {
        id: registerAction(`${idPrefix}-current-action`, () => {
          if (pinSession(currentSummary.id)) closeMenu()
        }),
        label: focusLabel(t('action.pinCurrent')),
      }
      currentFooterLayout = [currentId, 'pin', t('action.pinCurrent')]
    } else {
      currentAction = {
        id: `${idPrefix}-current-action`,
        disabled: true,
        label: (
          <span className={styles.currentAction} data-session-pins-focus-owner={idPrefix}>
            <span>{t('action.pinCurrent')}</span>
            <span className={styles.disabledReason}>{disabledReason}</span>
          </span>
        ),
      }
      currentFooterLayout = [currentId, 'disabled', t('action.pinCurrent'), disabledReason]
    }
  }

  const anchorLayoutKey = JSON.stringify([
    activeSelectedId,
    selectedWorkspaceStatus,
    pinnedIds.map((persistedId) => [persistedId, titleFor(persistedId)]),
    currentFooterLayout,
  ])
  const getAnchorRect = useCallback(
    () => triggerRef.current?.getBoundingClientRect() ?? null,
    [anchorLayoutKey],
  )
  const focusFirstEnabledMenuItem = useCallback(() => {
    const markers = document.querySelectorAll<HTMLElement>('[data-session-pins-focus-owner]')
    let ownedMenu: HTMLElement | null = null
    for (const marker of markers) {
      if (marker.dataset.sessionPinsFocusOwner !== idPrefix) continue
      ownedMenu ??= marker.closest<HTMLElement>('[role="menu"]')
      const item = marker.closest<HTMLButtonElement>('button[role="menuitem"]')
      if (item === null || item.disabled || !item.isConnected) continue
      item.focus()
      focusedMenuItemRef.current = item
      return
    }

    if (ownedMenu !== null && ownedMenu.isConnected) {
      ownedMenu.tabIndex = -1
      ownedMenu.focus()
      focusedMenuItemRef.current = ownedMenu
      return
    }

    triggerRef.current?.focus()
  }, [idPrefix])

  useEffect(() => {
    if (!open) return

    const handleFocusIn = (event: FocusEvent) => {
      if (!(event.target instanceof HTMLElement)) return
      const item = event.target.closest<HTMLButtonElement>('button[role="menuitem"]')
      if (item === null) return
      const ownedMarker = [
        ...item.querySelectorAll<HTMLElement>('[data-session-pins-focus-owner]'),
      ].some((marker) => marker.dataset.sessionPinsFocusOwner === idPrefix)
      if (ownedMarker) focusedMenuItemRef.current = item
    }
    const handlePointerDown = (event: PointerEvent) => {
      if (!(event.target instanceof Node)) return
      outsidePointerCloseRef.current = triggerRef.current?.contains(event.target) !== true
    }
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') outsidePointerCloseRef.current = false
    }

    document.addEventListener('focusin', handleFocusIn)
    document.addEventListener('pointerdown', handlePointerDown, true)
    document.addEventListener('keydown', handleKeyDown, true)
    return () => {
      document.removeEventListener('focusin', handleFocusIn)
      document.removeEventListener('pointerdown', handlePointerDown, true)
      document.removeEventListener('keydown', handleKeyDown, true)
    }
  }, [idPrefix, open])

  useEffect(() => {
    if (selectedId !== null && !pinnedIds.includes(selectedId)) {
      setSelectedId(null)
    }
    if (openFailure !== null && !pinnedIds.includes(openFailure.failedId)) {
      setOpenFailure(null)
    }
  }, [openFailure, pinnedIds, selectedId])

  useLayoutEffect(() => {
    if (!open) return
    const focusedItemWasRemoved =
      focusedMenuItemRef.current !== null && !focusedMenuItemRef.current.isConnected
    if (!focusMenuOnRenderRef.current && !focusedItemWasRemoved) return

    focusMenuOnRenderRef.current = false
    focusFirstEnabledMenuItem()
  }, [activeSelectedId, anchorLayoutKey, focusFirstEnabledMenuItem, open])

  const accessibleLabel = t('trigger.aria', { count: pinnedIds.length })
  const visibleOpenFailure = openFailure?.failedId === activeSelectedId ? openFailure : null
  const trigger = (
    <button
      ref={triggerRef}
      type="button"
      className={`${styles.trigger} ${wide ? styles.wideTrigger : styles.railTrigger}`}
      aria-label={accessibleLabel}
      aria-haspopup="menu"
      aria-expanded={open}
      onClick={(event) => {
        if (open) {
          closeMenu()
          return
        }

        outsidePointerCloseRef.current = false
        focusMenuOnRenderRef.current = event.detail === 0
        setOpenFailure(null)
        setOpen(true)
      }}
    >
      <PinIcon />
      {wide ? (
        <>
          <span className={styles.triggerLabel}>{t('trigger.label')}</span>
          <span className={styles.count}>{pinnedIds.length}</span>
        </>
      ) : null}
    </button>
  )

  return (
    <>
      <Menu
        open={open}
        anchor={
          <Tooltip label={accessibleLabel} delayMs={500} disabled={wide || open}>
            {trigger}
          </Tooltip>
        }
        items={items}
        footer={[currentAction]}
        onSelect={(id) => {
          actionsById.get(id)?.()
        }}
        onClose={() => {
          closeMenu(!outsidePointerCloseRef.current)
        }}
        side="top"
        portal
        getAnchorRect={getAnchorRect}
        dense
        compact
        className={`${styles.menuRoot} ${wide ? styles.menuWide : styles.menuRail}`}
      />
      <span className={styles.visuallyHidden} role="status" aria-live="polite" aria-atomic="true">
        {availabilityAnnouncement}
      </span>
      {visibleOpenFailure !== null ? (
        <span
          key={`${visibleOpenFailure.failedId}-${visibleOpenFailure.attempt}`}
          className={styles.visuallyHidden}
          role="alert"
        >
          {t('error.openFailed')}
        </span>
      ) : null}
    </>
  )
}
