export const NS = 'sessionPins'

export const zh = {
  'trigger.label': '固定会话',
  'trigger.aria': '固定会话（{count}）',
  'menu.heading': '固定会话',
  'menu.empty': '暂无固定会话',
  'action.open': '打开',
  'action.unpin': '取消固定',
  'action.back': '返回',
  'action.pinCurrent': '固定当前会话',
  'action.unpinCurrent': '取消固定当前会话',
  'session.unavailable': '不可用：{id}',
  'session.availabilityNotReady': '会话可用性尚未就绪。',
  'session.archivedUnsupported': 'DeepSeek Harness 0.1.0-rc.6 无法重新打开已归档会话。',
  'current.noSession': '请选择要固定的会话',
  'current.blank': '无法固定空白会话',
  'current.subagent': '无法固定子代理会话',
  'error.openFailed': '无法打开固定的会话',
}

export type SessionPinsKey = keyof typeof zh

export const en = {
  'trigger.label': 'Pinned sessions',
  'trigger.aria': 'Pinned sessions ({count})',
  'menu.heading': 'Pinned sessions',
  'menu.empty': 'No pinned sessions',
  'action.open': 'Open',
  'action.unpin': 'Unpin',
  'action.back': 'Back',
  'action.pinCurrent': 'Pin current session',
  'action.unpinCurrent': 'Unpin current session',
  'session.unavailable': 'Unavailable: {id}',
  'session.availabilityNotReady': 'Session availability is not ready yet.',
  'session.archivedUnsupported': 'DeepSeek Harness 0.1.0-rc.6 cannot reopen archived sessions.',
  'current.noSession': 'Select a session to pin it',
  'current.blank': 'Blank sessions cannot be pinned',
  'current.subagent': 'Subagent sessions cannot be pinned',
  'error.openFailed': 'Could not open the pinned session',
} satisfies Record<SessionPinsKey, string>

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    sessionPins: SessionPinsKey
  }
}
