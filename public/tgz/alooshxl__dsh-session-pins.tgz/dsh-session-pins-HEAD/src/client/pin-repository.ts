export interface PinnedSessionsSnapshot {
  readonly ids: readonly string[]
}

export interface StorageLike {
  getItem(key: string): string | null
  setItem(key: string, value: string): void
}

export interface StorageEventLike {
  readonly key: string | null
  readonly newValue: string | null
  readonly storageArea?: StorageLike | null
}

export interface StorageEventSource {
  addEventListener(type: 'storage', listener: (event: StorageEventLike) => void): void
  removeEventListener(type: 'storage', listener: (event: StorageEventLike) => void): void
}

export const PIN_STORAGE_KEY = 'dsh.session-pins.v1'
export const MAX_PINNED_SESSIONS = 100

interface PersistedPinsCandidate {
  readonly version?: unknown
  readonly ids?: unknown
}

function createSnapshot(ids: readonly string[]): PinnedSessionsSnapshot {
  const frozenIds = Object.freeze([...ids])
  return Object.freeze({ ids: frozenIds })
}

function isUnknownArray(value: unknown): value is readonly unknown[] {
  return Array.isArray(value)
}

function isValidId(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0
}

function normalizeIds(values: readonly unknown[]): readonly string[] {
  const ids: string[] = []
  const seen = new Set<string>()

  for (const value of values) {
    if (!isValidId(value) || seen.has(value)) {
      continue
    }

    seen.add(value)
    ids.push(value)

    if (ids.length === MAX_PINNED_SESSIONS) {
      break
    }
  }

  return ids
}

function parseStoredIds(serialized: string | null): readonly string[] {
  if (serialized === null) {
    return []
  }

  let parsed: unknown
  try {
    parsed = JSON.parse(serialized)
  } catch {
    return []
  }

  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
    return []
  }

  const candidate = parsed as PersistedPinsCandidate
  if (candidate.version !== 1 || !isUnknownArray(candidate.ids)) {
    return []
  }

  return normalizeIds(candidate.ids)
}

function haveEqualIds(left: readonly string[], right: readonly string[]): boolean {
  return left.length === right.length && left.every((id, index) => id === right[index])
}

export class PinRepository {
  private readonly listeners = new Set<() => void>()
  private readonly storage: StorageLike | undefined
  private snapshot = createSnapshot([])

  constructor(storage?: StorageLike) {
    this.storage = storage

    let serialized: string | null = null
    try {
      serialized = this.storage?.getItem(PIN_STORAGE_KEY) ?? null
    } catch {}

    this.commit(parseStoredIds(serialized), false)
  }

  getSnapshot(): PinnedSessionsSnapshot {
    return this.snapshot
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)

    return () => {
      this.listeners.delete(listener)
    }
  }

  pin(id: string): void {
    if (!isValidId(id)) {
      return
    }

    this.commit([id, ...this.snapshot.ids.filter((existingId) => existingId !== id)], true)
  }

  unpin(id: string): void {
    this.commit(
      this.snapshot.ids.filter((existingId) => existingId !== id),
      true,
    )
  }

  connect(eventSource: StorageEventSource): () => void {
    const listener = (event: StorageEventLike) => {
      if (event.key !== PIN_STORAGE_KEY && event.key !== null) {
        return
      }

      if (
        event.storageArea !== undefined &&
        event.storageArea !== null &&
        event.storageArea !== this.storage
      ) {
        return
      }

      if (this.storage === undefined) {
        this.commit(parseStoredIds(event.newValue), false)
        return
      }

      let serialized: string | null
      try {
        serialized = this.storage.getItem(PIN_STORAGE_KEY)
      } catch {
        return
      }

      this.commit(parseStoredIds(serialized), false)
    }
    let connected = true

    eventSource.addEventListener('storage', listener)

    return () => {
      if (!connected) {
        return
      }

      connected = false
      eventSource.removeEventListener('storage', listener)
    }
  }

  private commit(ids: readonly unknown[], persist: boolean): void {
    const normalizedIds = normalizeIds(ids)
    if (haveEqualIds(this.snapshot.ids, normalizedIds)) {
      return
    }

    this.snapshot = createSnapshot(normalizedIds)

    if (persist && this.storage !== undefined) {
      try {
        this.storage.setItem(PIN_STORAGE_KEY, JSON.stringify({ version: 1, ids: normalizedIds }))
      } catch {}
    }

    for (const listener of Array.from(this.listeners)) {
      listener()
    }
  }
}
