# DSH Session Pins Contributor Notes

This repository is the standalone `@dsh-external/dsh-session-pins` plugin for DeepSeek Harness.

- Keep product behavior in the browser client entry. The Node entry only enables package registration and client-module discovery.
- Preserve function-plugin named exports and do not add default exports to the Node, client, or invariant entries.
- Register only through public Harness client services and the `sidebar.footer.action` slot.
- Treat workspace archive data as actionable only when `baselinesReady === true`, `phase === 'ready'`, and `state === 'idle'`. Harness `0.1.0-rc.6` has no public way to reopen archived sessions, so fail closed without private APIs, host patches, timers, or false-success workarounds.
- Keep listeners, slot registrations, locale registrations, and other effects scoped to the owning Cordis fiber, with disposal covered by tests.
- Keep host-provided Cordis as the sole peer dependency. Development imports must resolve from dependencies declared by this package.
- Do not add host patches, compatibility layers, install-time lifecycle scripts, or paths that leave this repository.
- Describe repository files with project-root paths such as `docs/dsh-plugin-contracts.md`; never use parent-directory navigation in documentation.
- Keep `README.md` and `README.zh.md` behavior, compatibility, installation, security, and verification guidance equivalent when either language changes.
- Keep generated `lib/` artifacts reproducible and reviewed because Git installs do not run a prepare script. After every build, `git status --short --untracked-files=all -- lib` must be empty; tracked and untracked drift is blocking.
- Keep the browser module graph id and every injected CSS `data-plugin` owner equal to the full package name `@dsh-external/dsh-session-pins`. The Cordis row id remains `dsh-session-pins`.
- Keep `tests/smoke-profile.spec.ts` keyless and isolated: use the exact published rc.6 CLI, a temporary `DSH_HOME`, an empty temporary workspace, the frozen pnpm 11.7 store in offline mode, an ephemeral loopback port, the root boot manifest, and the package-name browser route. Register and await the child's `close` event before removing temporary state.
- Dependency build decisions in `pnpm-workspace.yaml` must stay explicit. Only the exact `@deepseek-ai/dsh-subprocess-local@0.1.0-rc.6` and `node-pty@1.1.0` host dependencies may be `true`, solely so the published rc.6 CLI smoke can boot on Linux; every other discovered lifecycle script stays `false`.
- Update source, tests, package exports, `cordis.patch.yml`, bilingual user documentation, generated artifacts, and package checks together when their contracts change.
- Run checks in CI order: frozen install, `format:check`, lint, typecheck, tests, build, generated-artifact drift, self-contained verification, package verification, then an independent dry-run pack inspection.
- Use `pnpm run verify:package` for local pack validation. CI installs Node first, then uses `pnpm/action-setup` with `standalone: false` so its independent `pnpm pack --dry-run --json` inspection runs through the compatible JavaScript CLI.
- Treat the CI dry-run inventory as an explicit contract: it must identify this package and version, contain nonempty unique safe root-relative paths, include both READMEs and all runtime entries, and create no tarball.
- Before release, run `make fmt`, `make test`, `make lint`, `pnpm run build`, `pnpm run format:check`, `pnpm run typecheck`, `pnpm run verify:self-contained`, `pnpm run verify:package`, and `git diff --check`.
