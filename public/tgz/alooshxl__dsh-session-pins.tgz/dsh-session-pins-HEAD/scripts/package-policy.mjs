import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const sourceFile = /^src\/.+/
const allowedSourceExtension = /\.(?:css|ts|tsx)$/i
const sensitiveName =
  /(?:^|\/)(?:\.env(?:\.|$)|\.netrc$|\.npmrc$|\.pypirc$|\.yarnrc(?:\.yml)?$|authorized_keys$|cookies$|credentials(?:\.[^/]*)?$|history$|id_(?:dsa|ecdsa|ed25519|rsa)(?:\.pub)?$|local state$|login data$|web data$)/i
const keyMaterialExtension = /\.(?:jks|kdbx|key|keystore|p12|pem|pfx)$/i
const secretLikeName =
  /(?:^|\/)[^/]*(?:auth[-_. ]?token|credential|private[-_. ]?key|secret)[^/]*$/i
const browserProfilePath = /(?:^|\/)(?:browser-profile|profile \d+|user data)(?:\/|$)/i

export function packedPathPolicyError(packedPath) {
  if (packedPath.includes('\\')) return 'package paths must use forward slashes'
  if (sensitiveName.test(packedPath)) return 'credential or browser data filename'
  if (keyMaterialExtension.test(packedPath)) return 'credential key material'
  if (secretLikeName.test(packedPath)) return 'secret-like filename'
  if (browserProfilePath.test(packedPath)) return 'browser profile content'
  if (sourceFile.test(packedPath) && !allowedSourceExtension.test(packedPath)) {
    return 'source files must use .css, .ts, or .tsx'
  }
  return undefined
}

const invokedPath = process.argv[1]
if (invokedPath !== undefined && resolve(invokedPath) === fileURLToPath(import.meta.url)) {
  const packedPath = process.argv[2]
  if (packedPath === undefined || process.argv.length !== 3) {
    console.error('usage: node scripts/package-policy.mjs <packed-path>')
    process.exitCode = 2
  } else {
    const error = packedPathPolicyError(packedPath)
    if (error === undefined) {
      console.log(`allowed packed path: ${packedPath}`)
    } else {
      console.error(`forbidden packed path: ${packedPath} (${error})`)
      process.exitCode = 1
    }
  }
}
