import { existsSync, readFileSync, readdirSync, realpathSync } from 'node:fs'
import { dirname, extname, isAbsolute, join, relative, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'
import ts from 'typescript'

// Usage: node scripts/verify-self-contained.mjs [repository-root]
// The optional root override is for isolated verifier fixtures; normal runs omit it.
const defaultRoot = dirname(dirname(fileURLToPath(import.meta.url)))
const rootArgument = process.argv[2]
if (process.argv.length > 3) {
  console.error('usage: node scripts/verify-self-contained.mjs [repository-root]')
  process.exit(1)
}
const requestedRoot = rootArgument === undefined ? defaultRoot : resolve(rootArgument)
if (!existsSync(requestedRoot)) {
  console.error(`verification root does not exist: ${requestedRoot}`)
  process.exit(1)
}
const root = realpathSync(requestedRoot)
const ignoredDirectories = new Set(['.git', '.pnpm-store', 'coverage', 'lib', 'node_modules'])
const textExtensions = new Set([
  '.cjs',
  '.css',
  '.cts',
  '.js',
  '.json',
  '.jsx',
  '.md',
  '.mjs',
  '.mts',
  '.ts',
  '.tsx',
  '.yaml',
  '.yml',
])
const codeExtensions = new Set(['.cjs', '.cts', '.js', '.jsx', '.mjs', '.mts', '.ts', '.tsx'])
const failures = []
const textFiles = []

function isInsideRoot(target) {
  const rel = relative(root, target)
  return rel === '' || (!rel.startsWith(`..${sep}`) && rel !== '..' && !isAbsolute(rel))
}

function toRepositoryPath(target) {
  return relative(root, target).split(sep).join('/')
}

function isPosixPathBoundary(character) {
  return character === undefined || /[\s"'`(=,:[{]/.test(character)
}

function isPosixPathTerminator(character) {
  return character === undefined || /[\s"'`<>)\]},;]/.test(character)
}

function findPosixAbsolutePath(source) {
  for (let index = 0; index < source.length; index += 1) {
    if (source[index] !== '/' || source[index + 1] === '/') continue
    if (!isPosixPathBoundary(source[index - 1])) continue

    let end = index + 1
    while (!isPosixPathTerminator(source[end])) end += 1
    return source.slice(index, end)
  }
  return undefined
}

function findAbsoluteFilePath(source) {
  const fileUrl = source.match(/(?:^|[\s"'`(=,])(file:(?:\/\/)?[^\s"'`<>]+)/im)
  if (fileUrl !== null) return fileUrl[1]

  const uncPath = source.match(/(?:^|[\s"'`(=,])((?:\\\\|\/\/)[^\\/\s"'`<>]+[\\/][^\s"'`<>]+)/m)
  if (uncPath !== null) return uncPath[1]

  const windowsPath = source.match(/(?:^|[\s"'`(=,:])([A-Za-z]:[\\/][^\s"'`<>]+)/m)
  if (windowsPath !== null) return windowsPath[1]

  const homePath = source.match(/(?:^|[\s"'`(=,:])(~\/[^\s"'`<>]+)/m)
  if (homePath !== null) return homePath[1]

  return findPosixAbsolutePath(source)
}

function scriptKindForExtension(extension) {
  if (extension === '.js' || extension === '.mjs' || extension === '.cjs') {
    return ts.ScriptKind.JS
  }
  if (extension === '.jsx') return ts.ScriptKind.JSX
  if (extension === '.tsx') return ts.ScriptKind.TSX
  return ts.ScriptKind.TS
}

function findAbsoluteFilePathInCode(filePath, source) {
  const extension = extname(filePath)
  const sourceFile = ts.createSourceFile(
    filePath,
    source,
    ts.ScriptTarget.Latest,
    false,
    scriptKindForExtension(extension),
  )
  let absolutePath

  function inspectText(text) {
    if (absolutePath === undefined) absolutePath = findAbsoluteFilePath(text)
  }

  function visit(node) {
    if (absolutePath !== undefined) return

    if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) {
      inspectText(node.text)
    } else if (ts.isTemplateExpression(node)) {
      inspectText(node.head.text)
      for (const span of node.templateSpans) inspectText(span.literal.text)
    } else if (node.kind === ts.SyntaxKind.JsxText) {
      inspectText(node.getText(sourceFile))
    }

    ts.forEachChild(node, visit)
  }

  visit(sourceFile)
  if (absolutePath !== undefined) return absolutePath

  const languageVariant =
    extension === '.jsx' || extension === '.tsx'
      ? ts.LanguageVariant.JSX
      : ts.LanguageVariant.Standard
  const scanner = ts.createScanner(ts.ScriptTarget.Latest, false, languageVariant, source)
  for (let token = scanner.scan(); token !== ts.SyntaxKind.EndOfFileToken; token = scanner.scan()) {
    if (
      token !== ts.SyntaxKind.SingleLineCommentTrivia &&
      token !== ts.SyntaxKind.MultiLineCommentTrivia
    ) {
      continue
    }

    const tokenText = scanner.getTokenText()
    const commentText =
      token === ts.SyntaxKind.SingleLineCommentTrivia ? tokenText.slice(2) : tokenText.slice(2, -2)
    inspectText(commentText)
    if (absolutePath !== undefined) return absolutePath
  }

  return undefined
}

function stripCssComments(source) {
  let result = ''
  let quote

  for (let index = 0; index < source.length; index += 1) {
    const character = source[index]
    if (quote !== undefined) {
      result += character
      if (character === '\\' && source[index + 1] !== undefined) {
        index += 1
        result += source[index]
      } else if (character === quote) {
        quote = undefined
      }
      continue
    }

    if (character === '"' || character === "'") {
      quote = character
      result += character
      continue
    }

    if (character === '/' && source[index + 1] === '*') {
      const commentEnd = source.indexOf('*/', index + 2)
      if (commentEnd === -1) return result
      result += ' '
      index = commentEnd + 1
      continue
    }

    result += character
  }

  return result
}

function findAbsoluteCssReference(target) {
  const value = target.trim()
  if (value.length === 0 || /^data:/i.test(value)) return undefined
  if (/^file:(?:\/\/)?/i.test(value)) return value
  if (/^[A-Za-z]:[\\/]/.test(value)) return value
  if (/^(?:\\\\|\/\/)[^\\/]+[\\/]/.test(value)) return value
  if (value.startsWith('/')) return value
  return undefined
}

function findAbsoluteFilePathInCss(source) {
  const css = stripCssComments(source)
  const patterns = [
    /@import\s+(?!url\s*\()(?:"((?:\\.|[^"\\])*)"|'((?:\\.|[^'\\])*)'|([^\s;)]+))/gi,
    /url\s*\(\s*(?:"((?:\\.|[^"\\])*)"|'((?:\\.|[^'\\])*)'|([^)]*?))\s*\)/gi,
  ]

  for (const pattern of patterns) {
    for (const match of css.matchAll(pattern)) {
      const target = match[1] ?? match[2] ?? match[3]
      const absolutePath = findAbsoluteCssReference(target)
      if (absolutePath !== undefined) return absolutePath
    }
  }

  return undefined
}

function isRegistryVersionOrTag(spec) {
  const trimmed = spec.trim()
  return (
    trimmed.length > 0 &&
    trimmed === spec &&
    !/^[a-z][a-z0-9+.-]*:/i.test(trimmed) &&
    !/^[A-Za-z]:/.test(trimmed) &&
    !/^git@/i.test(trimmed) &&
    !/[\\/]/.test(trimmed)
  )
}

function isRegistryDependencySpec(spec) {
  if (typeof spec !== 'string') return false
  if (!spec.startsWith('npm:')) return isRegistryVersionOrTag(spec)

  const alias = spec.slice('npm:'.length)
  const match = alias.match(/^((?:@[^/@\s]+\/)?[^/@\s]+)(?:@(.+))?$/)
  return match !== null && (match[2] === undefined || isRegistryVersionOrTag(match[2]))
}

function walk(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    if (entry.isDirectory() && ignoredDirectories.has(entry.name)) continue

    const fullPath = join(directory, entry.name)
    if (entry.isSymbolicLink()) {
      try {
        const target = realpathSync(fullPath)
        if (!isInsideRoot(target)) {
          failures.push(`${toRepositoryPath(fullPath)}: symlink leaves repository`)
        }
      } catch (error) {
        failures.push(`${toRepositoryPath(fullPath)}: broken symlink (${error.message})`)
      }
      continue
    }

    if (entry.isDirectory()) {
      walk(fullPath)
    } else if (entry.isFile() && textExtensions.has(extname(entry.name))) {
      textFiles.push(fullPath)
    }
  }
}

walk(root)

for (const filePath of textFiles) {
  const rel = toRepositoryPath(filePath)
  const source = readFileSync(filePath, 'utf8')

  if (rel !== 'scripts/verify-self-contained.mjs') {
    const extension = extname(filePath)
    const absolutePath = codeExtensions.has(extension)
      ? findAbsoluteFilePathInCode(filePath, source)
      : extension === '.css'
        ? findAbsoluteFilePathInCss(source)
        : findAbsoluteFilePath(source)
    if (absolutePath !== undefined) {
      failures.push(`${rel}: contains absolute path ${absolutePath}`)
    }
  }

  if (extname(filePath) === '.md') {
    if (/\.\.[/\\]/.test(source)) {
      failures.push(`${rel}: documentation uses parent-directory navigation`)
    }

    for (const match of source.matchAll(/\[[^\]]+\]\(([^)]+)\)/g)) {
      const rawTarget = match[1].trim().replace(/^<|>$/g, '')
      if (
        rawTarget.startsWith('#') ||
        rawTarget.startsWith('mailto:') ||
        /^[a-z][a-z+.-]*:/i.test(rawTarget)
      ) {
        continue
      }

      const targetPath = resolve(dirname(filePath), rawTarget.split('#')[0])
      if (!isInsideRoot(targetPath)) {
        failures.push(`${rel}: Markdown link leaves repository: ${rawTarget}`)
      } else if (!existsSync(targetPath)) {
        failures.push(`${rel}: broken Markdown link: ${rawTarget}`)
      }
    }
  }

  if (codeExtensions.has(extname(filePath))) {
    const pathPatterns = [
      /(?:from\s+|import\s*\(\s*|require\s*\(\s*|require\.resolve\s*\(\s*|import\s+)['"](\.{1,2}\/[^'"]+)['"]/g,
      /\/\/\/\s*<reference\s+path=['"](\.{1,2}\/[^'"]+)['"]/g,
    ]
    for (const pattern of pathPatterns) {
      for (const match of source.matchAll(pattern)) {
        const targetPath = resolve(dirname(filePath), match[1])
        if (!isInsideRoot(targetPath)) {
          failures.push(`${rel}: code path leaves repository: ${match[1]}`)
        }
      }
    }
  }
}

const packageJson = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))
for (const field of [
  'dependencies',
  'devDependencies',
  'optionalDependencies',
  'peerDependencies',
]) {
  for (const [name, spec] of Object.entries(packageJson[field] ?? {})) {
    if (!isRegistryDependencySpec(spec)) {
      failures.push(`package.json: ${field}.${name} uses non-registry spec ${spec}`)
    }
  }
}

for (const lifecycle of ['preinstall', 'install', 'postinstall', 'prepare', 'pnpm:devPreinstall']) {
  if (packageJson.scripts?.[lifecycle] !== undefined) {
    failures.push(`package.json: install-time lifecycle script ${lifecycle} is not allowed`)
  }
}

const lockfilePath = join(root, 'pnpm-lock.yaml')
if (!existsSync(lockfilePath)) {
  failures.push('missing pnpm-lock.yaml')
} else {
  const lockfileSource = readFileSync(lockfilePath, 'utf8')
  const localLockSpec = lockfileSource.match(
    /(?:^|[\s'"])(?:file|link|portal|workspace):[^\s'",}\]]+/m,
  )
  if (localLockSpec !== null) {
    failures.push(`pnpm-lock.yaml: contains local dependency spec ${localLockSpec[0].trim()}`)
  }
}

for (const fileName of readdirSync(root).filter((name) => /^tsconfig.*\.json$/.test(name))) {
  const config = JSON.parse(readFileSync(join(root, fileName), 'utf8'))
  const candidates = []
  if (typeof config.extends === 'string' && config.extends.startsWith('.')) {
    candidates.push(config.extends)
  }
  for (const reference of config.references ?? []) {
    if (typeof reference.path === 'string') candidates.push(reference.path)
  }
  for (const values of Object.values(config.compilerOptions?.paths ?? {})) {
    if (Array.isArray(values)) candidates.push(...values)
  }
  for (const candidate of candidates) {
    const targetPath = resolve(root, candidate.replace(/\*$/, ''))
    if (!isInsideRoot(targetPath)) {
      failures.push(`${fileName}: compiler path leaves repository: ${candidate}`)
    }
  }
}

if (failures.length > 0) {
  console.error(failures.join('\n'))
  process.exit(1)
}

console.log(`self-contained repository verified (${textFiles.length} text files)`)
