import { spawnSync } from 'node:child_process'
import { existsSync, readFileSync, readdirSync } from 'node:fs'
import { builtinModules } from 'node:module'
import { homedir } from 'node:os'
import { delimiter, dirname, isAbsolute, join, sep } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

import { parse } from 'yaml'
import { packedPathPolicyError } from './package-policy.mjs'

const PACKAGE_NAME = '@dsh-external/dsh-session-pins'
const PLUGIN_ID = 'dsh-session-pins'
const FORWARD_SLASH = String.fromCharCode(47)
const repositoryRoot = dirname(dirname(fileURLToPath(import.meta.url)))
const failures = []

const REQUIRED_PUBLIC_READMES = ['README.md', 'README.zh.md']

const expectedClientRequires = new Set([
  '@deepseek-ai/dsh-client-ui-primitives',
  'react',
  'react/jsx-runtime',
])
const expectedRuntimeArtifacts = new Set([
  'lib/client.js',
  'lib/client.js.map',
  'lib/index.js',
  'lib/invariant.js',
])
const expectedDshMetadata = {
  bundle: { patch: './cordis.patch.yml' },
  client: {
    inject: [
      '@deepseek-ai/dsh-client-runtime',
      '@deepseek-ai/dsh-client-locale',
      '@deepseek-ai/dsh-client-ui-sidebar',
    ],
    platform: 'web',
  },
}
const expectedPatch = [
  {
    insert: [
      {
        id: PLUGIN_ID,
        name: PACKAGE_NAME,
      },
    ],
  },
]

function addFailure(message) {
  failures.push(message)
}

function walkFiles(directory) {
  const absoluteDirectory = join(repositoryRoot, directory)
  if (!existsSync(absoluteDirectory)) return []

  const files = []
  for (const entry of readdirSync(absoluteDirectory, { withFileTypes: true })) {
    const relativePath = join(directory, entry.name)
    if (entry.isDirectory()) {
      files.push(...walkFiles(relativePath))
    } else if (entry.isFile()) {
      files.push(relativePath.split(sep).join(FORWARD_SLASH))
    }
  }
  return files.sort((left, right) => left.localeCompare(right, 'en'))
}

function readRequiredText(relativePath) {
  const filePath = join(repositoryRoot, relativePath)
  if (!existsSync(filePath)) {
    addFailure(`${relativePath}: required file is missing; run "pnpm run build"`)
    return undefined
  }
  return readFileSync(filePath, 'utf8')
}

function readRequiredJson(relativePath) {
  const source = readRequiredText(relativePath)
  if (source === undefined) return undefined
  try {
    return JSON.parse(source)
  } catch (error) {
    addFailure(`${relativePath}: invalid JSON (${error.message})`)
    return undefined
  }
}

function normalizeTarget(target, label, allowDotPrefix) {
  if (typeof target !== 'string' || target.length === 0) {
    addFailure(`${label}: target must be a non-empty string`)
    return undefined
  }
  if (target.includes('\\')) {
    addFailure(`${label}: target must use forward slashes: ${target}`)
    return undefined
  }
  if (allowDotPrefix && !target.startsWith('./')) {
    addFailure(`${label}: export target must start with "./": ${target}`)
    return undefined
  }

  const packagePath = target.replace(/^\.\//, '')
  if (
    isAbsolute(packagePath) ||
    /^[A-Za-z]:\//.test(packagePath) ||
    packagePath.split(FORWARD_SLASH).includes('..')
  ) {
    addFailure(`${label}: target leaves the package: ${target}`)
    return undefined
  }
  return packagePath
}

function validateTarget(target, label, allowDotPrefix = true) {
  const packagePath = normalizeTarget(target, label, allowDotPrefix)
  if (packagePath === undefined) return undefined

  const wildcard = packagePath.indexOf('*')
  const checkPath =
    wildcard === -1
      ? packagePath
      : packagePath.slice(0, wildcard).replace(/\/$/, '') || dirname(packagePath)
  if (!existsSync(join(repositoryRoot, checkPath))) {
    addFailure(`${label}: target does not exist: ${target}`)
  }
  return packagePath
}

function collectExportTargets(value, label, targets) {
  if (typeof value === 'string') {
    const packagePath = validateTarget(value, label)
    if (packagePath !== undefined) targets.add(packagePath)
    return
  }
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    addFailure(`${label}: export value must be a string or condition object`)
    return
  }
  for (const [condition, target] of Object.entries(value)) {
    collectExportTargets(target, `${label}.${condition}`, targets)
  }
}

function expectedDeclarationArtifacts() {
  const declarations = new Set()
  for (const sourcePath of walkFiles('src')) {
    if (!/\.tsx?$/.test(sourcePath) || sourcePath.endsWith('.d.ts')) continue
    const declarationPath = sourcePath.replace(/^src\//, 'lib/types/').replace(/\.tsx?$/, '.d.ts')
    declarations.add(declarationPath)
    declarations.add(`${declarationPath}.map`)
  }
  return declarations
}

function findAbsolutePath(source) {
  const normalizedRoot = repositoryRoot.split(sep).join(FORWARD_SLASH)
  const escapedRoot = repositoryRoot.replaceAll('\\', '\\\\')
  for (const candidate of [
    repositoryRoot,
    normalizedRoot,
    pathToFileURL(repositoryRoot).href,
    escapedRoot,
  ]) {
    if (source.includes(candidate)) return candidate
  }

  const fileUrl = source.match(/(?:^|[\s"'`(=,:])(file:(?:\/\/)?[^\s"'`<>]+)/im)
  if (fileUrl !== null) return fileUrl[1]
  const windowsPath = source.match(
    /(?:^|[\s"'`(=,:])((?:[A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])[^\s"'`<>]*)/m,
  )
  if (windowsPath !== null) return windowsPath[1]
  const posixPath = source.match(
    /(?:^|[\s"'`(=,:])(\/(?:home|Users|private|tmp|var\/folders)\/[^\s"'`<>]*)/m,
  )
  return posixPath?.[1]
}

function requireSpecifiers(source) {
  return new Set([...source.matchAll(/\brequire\((["'])([^"']+)\1\)/g)].map((match) => match[2]))
}

function setsEqual(left, right) {
  return left.size === right.size && [...left].every((value) => right.has(value))
}

function rootArchives() {
  return readdirSync(repositoryRoot)
    .filter((fileName) => /\.(?:tgz|tar|tar\.gz)$/i.test(fileName))
    .sort((left, right) => left.localeCompare(right, 'en'))
}

function resolvePnpmInvocation() {
  const npmExecPath = process.env.npm_execpath
  if (npmExecPath !== undefined && existsSync(npmExecPath)) {
    if (/\.(?:cjs|mjs|js)$/i.test(npmExecPath)) {
      return { command: process.execPath, prefix: [npmExecPath] }
    }
    return { command: npmExecPath, prefix: [] }
  }

  const packageManager = JSON.parse(
    readFileSync(join(repositoryRoot, 'package.json'), 'utf8'),
  ).packageManager
  const version =
    typeof packageManager === 'string' ? /^pnpm@(.+)$/.exec(packageManager)?.[1] : undefined
  if (version !== undefined) {
    const dataRoots = new Set([
      process.env.PNPM_HOME,
      process.env.LOCALAPPDATA === undefined
        ? join(homedir(), 'AppData', 'Local', 'pnpm')
        : join(process.env.LOCALAPPDATA, 'pnpm'),
      process.env.XDG_DATA_HOME === undefined
        ? join(homedir(), '.local', 'share', 'pnpm')
        : join(process.env.XDG_DATA_HOME, 'pnpm'),
    ])
    for (const dataRoot of dataRoots) {
      if (dataRoot === undefined) continue
      for (const scriptPath of [
        join(dataRoot, '.tools', 'pnpm', version, 'node_modules', 'pnpm', 'bin', 'pnpm.cjs'),
        join(dataRoot, '.tools', 'pnpm', version, 'node_modules', 'pnpm', 'dist', 'pnpm.cjs'),
      ]) {
        if (existsSync(scriptPath)) {
          return { command: process.execPath, prefix: [scriptPath] }
        }
      }
    }
  }

  if (process.platform !== 'win32') return { command: 'pnpm', prefix: [] }

  const pathEntries = (process.env.Path ?? process.env.PATH ?? '')
    .split(delimiter)
    .filter((entry) => entry.length > 0)
  for (const pathEntry of pathEntries) {
    const executable = join(pathEntry, 'pnpm.exe')
    if (existsSync(executable)) return { command: executable, prefix: [] }
  }

  for (const pathEntry of pathEntries) {
    for (const scriptPath of [
      join(pathEntry, 'pnpm.cjs'),
      join(pathEntry, 'pnpm.js'),
      join(pathEntry, 'node_modules', 'pnpm', 'bin', 'pnpm.cjs'),
      join(pathEntry, 'node_modules', 'corepack', 'dist', 'pnpm.js'),
    ]) {
      if (existsSync(scriptPath)) {
        return { command: process.execPath, prefix: [scriptPath] }
      }
    }
  }

  return { command: 'pnpm.exe', prefix: [] }
}

function runPnpm(invocation, args) {
  return spawnSync(invocation.command, [...invocation.prefix, ...args], {
    cwd: repositoryRoot,
    encoding: 'utf8',
    windowsHide: true,
  })
}

function parsePackResult(stdout) {
  let parsed
  try {
    parsed = JSON.parse(stdout)
  } catch (error) {
    addFailure(`pnpm pack: invalid JSON output (${error.message})`)
    return undefined
  }

  const result = Array.isArray(parsed) ? parsed[0] : parsed
  if (result === null || typeof result !== 'object' || !Array.isArray(result.files)) {
    addFailure('pnpm pack: JSON output has no files array')
    return undefined
  }
  for (const file of result.files) {
    if (file === null || typeof file !== 'object' || typeof file.path !== 'string') {
      addFailure('pnpm pack: JSON output contains an invalid file entry')
      return undefined
    }
  }
  return result
}

function dryRunPack() {
  const invocation = resolvePnpmInvocation()
  const result = runPnpm(invocation, ['pack', '--dry-run', '--json'])

  if (result.error !== undefined) {
    addFailure(`pnpm pack: could not start package manager (${result.error.message})`)
    return undefined
  }
  if (result.status !== 0) {
    addFailure(
      `pnpm pack: dry-run failed with exit ${String(result.status)}: ${result.stderr.trim()}`,
    )
    return undefined
  }
  if (result.stderr.trim().length > 0) {
    addFailure(`pnpm pack: unexpected stderr: ${result.stderr.trim()}`)
  }
  return parsePackResult(result.stdout)
}

const manifest = readRequiredJson('package.json')
const expectedDeclarations = expectedDeclarationArtifacts()
const expectedLibFiles = new Set([...expectedRuntimeArtifacts, ...expectedDeclarations])
const exportTargets = new Set()

if (manifest !== undefined) {
  if (manifest.name !== PACKAGE_NAME) {
    addFailure(`package.json: expected name ${PACKAGE_NAME}, received ${String(manifest.name)}`)
  }

  const mainTarget = validateTarget(manifest.main, 'package.json.main', false)
  const typesTarget = validateTarget(manifest.types, 'package.json.types', false)
  if (mainTarget !== 'lib/index.js') {
    addFailure(`package.json.main: expected lib/index.js, received ${String(manifest.main)}`)
  }
  if (typesTarget !== 'lib/types/index.d.ts') {
    addFailure(
      `package.json.types: expected lib/types/index.d.ts, received ${String(manifest.types)}`,
    )
  }
  if (mainTarget !== undefined) exportTargets.add(mainTarget)
  if (typesTarget !== undefined) exportTargets.add(typesTarget)

  if (manifest.exports === null || typeof manifest.exports !== 'object') {
    addFailure('package.json.exports: expected an export map')
  } else {
    for (const [exportName, target] of Object.entries(manifest.exports)) {
      collectExportTargets(
        target,
        `package.json.exports[${JSON.stringify(exportName)}]`,
        exportTargets,
      )
    }
    for (const [exportName, expectedDefault, expectedTypes] of [
      ['.', './lib/index.js', './lib/types/index.d.ts'],
      ['./client', './lib/client.js', './lib/types/client/index.d.ts'],
      ['./invariant', './lib/invariant.js', './lib/types/invariant.d.ts'],
    ]) {
      const exportValue = manifest.exports[exportName]
      if (
        exportValue === null ||
        typeof exportValue !== 'object' ||
        exportValue.default !== expectedDefault ||
        exportValue.types !== expectedTypes
      ) {
        addFailure(
          `package.json.exports[${JSON.stringify(exportName)}]: expected default ${expectedDefault} and types ${expectedTypes}`,
        )
      }
    }
  }

  if (JSON.stringify(manifest.dsh) !== JSON.stringify(expectedDshMetadata)) {
    addFailure('package.json.dsh: patch/client metadata does not match the Harness contract')
  }
  if (
    !Array.isArray(manifest.files) ||
    JSON.stringify(manifest.files) !==
      JSON.stringify(['lib', 'src', 'cordis.patch.yml', 'README.md', 'README.zh.md', 'LICENSE'])
  ) {
    addFailure('package.json.files: expected lib, src, patch, both READMEs, and LICENSE')
  }
  if (manifest.scripts?.build !== 'pnpm run clean && tsc -p tsconfig.build.json && tsdown') {
    addFailure('package.json.scripts.build: build must start with "pnpm run clean"')
  }
  if (manifest.scripts?.clean !== 'node scripts/clean.mjs') {
    addFailure('package.json.scripts.clean: expected the cross-platform Node clean script')
  }
  for (const lifecycle of [
    'preinstall',
    'install',
    'postinstall',
    'prepare',
    'pnpm:devPreinstall',
  ]) {
    if (manifest.scripts?.[lifecycle] !== undefined) {
      addFailure(`package.json.scripts.${lifecycle}: install-time lifecycle is not allowed`)
    }
  }
}

const patchSource = readRequiredText('cordis.patch.yml')
if (patchSource !== undefined) {
  try {
    if (JSON.stringify(parse(patchSource)) !== JSON.stringify(expectedPatch)) {
      addFailure('cordis.patch.yml: expected one dsh-session-pins package insertion')
    }
  } catch (error) {
    addFailure(`cordis.patch.yml: invalid YAML (${error.message})`)
  }
}

for (const expectedLibFile of expectedLibFiles) {
  if (!existsSync(join(repositoryRoot, expectedLibFile))) {
    addFailure(`${expectedLibFile}: required build artifact is missing`)
  }
}
for (const actualLibFile of walkFiles('lib')) {
  if (!expectedLibFiles.has(actualLibFile)) {
    addFailure(`${actualLibFile}: unexpected build artifact; clean and rebuild`)
  }
}

const nodeSource = readRequiredText('lib/index.js')
const invariantSource = readRequiredText('lib/invariant.js')
for (const [relativePath, source] of [
  ['lib/index.js', nodeSource],
  ['lib/invariant.js', invariantSource],
]) {
  if (source === undefined) continue
  if (!/\bexport\s*\{/.test(source)) addFailure(`${relativePath}: expected named ESM exports`)
  if (/\bexport\s+default\b/.test(source) || source.includes('exports.default')) {
    addFailure(`${relativePath}: accidental default export detected`)
  }
  if (source.includes('module.exports')) addFailure(`${relativePath}: CommonJS output detected`)
}

if (nodeSource !== undefined && invariantSource !== undefined) {
  try {
    const cacheKey = `verify-${Date.now()}`
    const nodeUrl = pathToFileURL(join(repositoryRoot, 'lib/index.js'))
    const invariantUrl = pathToFileURL(join(repositoryRoot, 'lib/invariant.js'))
    nodeUrl.searchParams.set('verify-package', cacheKey)
    invariantUrl.searchParams.set('verify-package', cacheKey)
    const [nodePlugin, invariantPlugin] = await Promise.all([
      import(nodeUrl.href),
      import(invariantUrl.href),
    ])
    if (JSON.stringify(Object.keys(nodePlugin).sort()) !== JSON.stringify(['apply', 'name'])) {
      addFailure('lib/index.js: imported namespace must expose only apply and name')
    }
    if (
      JSON.stringify(Object.keys(invariantPlugin).sort()) !==
      JSON.stringify(['apply', 'inject', 'name'])
    ) {
      addFailure('lib/invariant.js: imported namespace must expose only apply, inject, and name')
    }
  } catch (error) {
    addFailure(`Node artifact import failed: ${error.message}`)
  }
}

const clientSource = readRequiredText('lib/client.js')
if (clientSource !== undefined) {
  try {
    new Function(clientSource)
  } catch (error) {
    addFailure(`lib/client.js: syntax parsing failed (${error.message})`)
  }
  for (const [signature, description] of [
    ['window.__ModuleLoader__.load({', 'Harness ModuleLoader wrapper'],
    [`id: "${PACKAGE_NAME}"`, 'package-name module id'],
    ['factory: (require) => {', 'require factory'],
    ['return module.exports', 'factory namespace return'],
    ['style[data-plugin-css=', 'idempotent CSS selector'],
    [`tag.dataset.plugin = "${PACKAGE_NAME}"`, 'package style ownership'],
    ['tag.dataset.pluginCss = tagId', 'unique CSS module ownership'],
    [`${PACKAGE_NAME}${FORWARD_SLASH}PinnedSessionsAction.module.css`, 'CSS module tag id'],
  ]) {
    if (!clientSource.includes(signature)) {
      addFailure(`lib/client.js: missing ${description} signature`)
    }
  }

  const clientRequires = requireSpecifiers(clientSource)
  if (!setsEqual(clientRequires, expectedClientRequires)) {
    addFailure(
      `lib/client.js: unexpected external requires (${[...clientRequires].sort().join(', ')})`,
    )
  }
  const builtins = new Set(builtinModules.map((name) => name.replace(/^node:/, '')))
  for (const specifier of clientRequires) {
    const normalized = specifier.replace(/^node:/, '').split(FORWARD_SLASH)[0]
    if (builtins.has(normalized)) addFailure(`lib/client.js: imports Node builtin ${specifier}`)
  }
  if (clientSource.includes('process.env.NODE_ENV')) {
    addFailure('lib/client.js: production environment constant was not replaced')
  }
  const absolutePath = findAbsolutePath(clientSource)
  if (absolutePath !== undefined) {
    addFailure(`lib/client.js: contains absolute local path ${absolutePath}`)
  }
}

const clientMapSource = readRequiredText('lib/client.js.map')
if (clientMapSource !== undefined) {
  const absolutePath = findAbsolutePath(clientMapSource)
  if (absolutePath !== undefined) {
    addFailure(`lib/client.js.map: contains absolute local path ${absolutePath}`)
  }
  try {
    const sourceMap = JSON.parse(clientMapSource)
    if (sourceMap.file !== 'client.js') {
      addFailure(`lib/client.js.map: expected file "client.js", received ${String(sourceMap.file)}`)
    }
    if (!Array.isArray(sourceMap.sources) || sourceMap.sources.length === 0) {
      addFailure('lib/client.js.map: expected at least one source')
    } else {
      for (const source of sourceMap.sources) {
        if (typeof source !== 'string' || isAbsolute(source) || /^[A-Za-z]:\//.test(source)) {
          addFailure(`lib/client.js.map: non-portable source ${String(source)}`)
        }
      }
    }
  } catch (error) {
    addFailure(`lib/client.js.map: invalid JSON (${error.message})`)
  }
}

for (const libFile of walkFiles('lib')) {
  if (!/\.(?:js|map|d\.ts)$/.test(libFile)) continue
  const source = readFileSync(join(repositoryRoot, libFile), 'utf8')
  const absolutePath = findAbsolutePath(source)
  if (absolutePath !== undefined)
    addFailure(`${libFile}: contains absolute local path ${absolutePath}`)
}

const archivesBeforePack = rootArchives()
if (archivesBeforePack.length > 0) {
  addFailure(`repository contains unexpected tarball(s): ${archivesBeforePack.join(', ')}`)
}
for (const readme of REQUIRED_PUBLIC_READMES) {
  if (!existsSync(join(repositoryRoot, readme))) {
    addFailure(`${readme}: required public documentation is missing`)
  }
}
const packResult = dryRunPack()
const archivesAfterPack = rootArchives()
if (JSON.stringify(archivesAfterPack) !== JSON.stringify(archivesBeforePack)) {
  addFailure('pnpm pack dry-run mutated the repository by creating a tarball')
}

if (packResult !== undefined) {
  const packedPaths = new Set(
    packResult.files.map((file) => file.path.replaceAll('\\', FORWARD_SLASH)),
  )
  const requiredPackedPaths = new Set([
    'package.json',
    'LICENSE',
    'cordis.patch.yml',
    ...walkFiles('src'),
    ...expectedLibFiles,
    ...[...exportTargets].filter((target) => !target.includes('*')),
    ...REQUIRED_PUBLIC_READMES,
  ])
  for (const requiredPath of requiredPackedPaths) {
    if (!packedPaths.has(requiredPath)) addFailure(`packed package is missing ${requiredPath}`)
  }

  const allowedPath =
    /^(?:package\.json|LICENSE|cordis\.patch\.yml|README(?:\.zh)?\.md|lib\/.+|src\/.+)$/
  for (const packedPath of packedPaths) {
    if (!allowedPath.test(packedPath))
      addFailure(`packed package has unexpected file ${packedPath}`)
    if (
      /(?:^|\/)(?:tests?|node_modules|coverage|docs\/superpowers|\.pnpm-store|temp|tmp)(?:\/|$)/.test(
        packedPath,
      )
    ) {
      addFailure(`packed package includes forbidden directory ${packedPath}`)
    }
    const policyError = packedPathPolicyError(packedPath)
    if (policyError !== undefined) {
      addFailure(`packed package includes forbidden file ${packedPath} (${policyError})`)
    }
    if (
      packedPath.split(FORWARD_SLASH).includes('..') ||
      isAbsolute(packedPath) ||
      /^[A-Za-z]:\//.test(packedPath)
    ) {
      addFailure(`packed package path leaves package root: ${packedPath}`)
    }
    if (packedPath.startsWith(`lib${FORWARD_SLASH}`) && !expectedLibFiles.has(packedPath)) {
      addFailure(`packed package includes unexpected artifact ${packedPath}`)
    }
  }
}

if (failures.length > 0) {
  console.error(failures.join('\n'))
  process.exit(1)
}

console.log(
  `package verified (${expectedLibFiles.size} artifacts, ${packResult.files.length} packed files; both public READMEs included)`,
)
