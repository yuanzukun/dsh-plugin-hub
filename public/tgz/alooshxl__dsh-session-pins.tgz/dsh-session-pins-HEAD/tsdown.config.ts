import { existsSync } from 'node:fs'
import { readFile } from 'node:fs/promises'
import { basename, dirname, isAbsolute, relative, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'

import { transform } from 'lightningcss'
import { defineConfig, type TsdownPlugin } from 'tsdown'

const PACKAGE_NAME = '@dsh-external/dsh-session-pins'
const CSS_VIRTUAL_PREFIX = '\0dsh-css:'
const CSS_VIRTUAL_SUFFIX = '.mjs'
const FORWARD_SLASH = String.fromCharCode(47)
const repositoryRoot = dirname(fileURLToPath(import.meta.url))

// These are the official Harness browser module-table seeds. Runtime/client is
// the standalone bundle exemption used by official client packages.
const CLIENT_EXTERNALS = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-web-react',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-attachment',
  '@deepseek-ai/dsh-client-schema-form',
  '@deepseek-ai/dsh-client-runtime/client',
] as const

function toRepositoryPath(filePath: string): string {
  const repositoryPath = relative(repositoryRoot, filePath)
  if (
    repositoryPath === '..' ||
    repositoryPath.startsWith(`..${sep}`) ||
    isAbsolute(repositoryPath)
  ) {
    throw new Error(`build input leaves repository: ${filePath}`)
  }
  return repositoryPath.split(sep).join(FORWARD_SLASH)
}

function portableSourcePath(source: string): string {
  if (!isAbsolute(source)) return source.replaceAll('\\', FORWARD_SLASH)
  return `../${toRepositoryPath(source)}`
}

function cssModulesPlugin(): TsdownPlugin {
  return {
    name: 'dsh-session-pins-css-modules',
    resolveId(source, importer) {
      if (!source.endsWith('.module.css')) return null
      if (importer === undefined) throw new Error(`CSS Module has no importer: ${source}`)

      const filePath = resolve(dirname(importer), source)
      if (!existsSync(filePath)) throw new Error(`CSS Module does not exist: ${filePath}`)
      return `${CSS_VIRTUAL_PREFIX}${toRepositoryPath(filePath)}${CSS_VIRTUAL_SUFFIX}`
    },
    async load(virtualId) {
      if (!virtualId.startsWith(CSS_VIRTUAL_PREFIX) || !virtualId.endsWith(CSS_VIRTUAL_SUFFIX)) {
        return null
      }

      const repositoryPath = virtualId.slice(CSS_VIRTUAL_PREFIX.length, -CSS_VIRTUAL_SUFFIX.length)
      const filePath = resolve(repositoryRoot, repositoryPath)
      this.addWatchFile(filePath)

      const result = transform({
        filename: repositoryPath,
        projectRoot: '.',
        code: await readFile(filePath),
        cssModules: { pattern: 'dsp_[hash]_[local]' },
        minify: true,
      })
      if (result.warnings.length > 0) {
        throw new Error(
          `Lightning CSS warnings in ${repositoryPath}: ${result.warnings
            .map((warning) => warning.message)
            .join('; ')}`,
        )
      }

      const classMap: Record<string, string> = {}
      for (const [localName, cssExport] of Object.entries(result.exports ?? {}).sort(
        ([left], [right]) => left.localeCompare(right, 'en'),
      )) {
        classMap[localName] = cssExport.name
      }

      const css = new TextDecoder().decode(result.code)
      const tagId = `${PACKAGE_NAME}${FORWARD_SLASH}${basename(repositoryPath)}`
      // Harness ModuleLoader removes tags owned through data-plugin on unload.
      return [
        `const css = ${JSON.stringify(css)};`,
        `const tagId = ${JSON.stringify(tagId)};`,
        "if (typeof document !== 'undefined' && document.querySelector('style[data-plugin-css=' + JSON.stringify(tagId) + ']') === null) {",
        "  const tag = document.createElement('style');",
        `  tag.dataset.plugin = ${JSON.stringify(PACKAGE_NAME)};`,
        '  tag.dataset.pluginCss = tagId;',
        '  tag.textContent = css;',
        '  document.head.appendChild(tag);',
        '}',
        `export default ${JSON.stringify(classMap)};`,
      ].join('\n')
    },
  }
}

export default defineConfig([
  {
    name: 'dsh-session-pins/node',
    entry: {
      index: 'src/index.ts',
      invariant: 'src/invariant.ts',
    },
    outDir: 'lib',
    format: 'esm',
    platform: 'node',
    target: 'es2024',
    fixedExtension: false,
    dts: false,
    clean: false,
    cjsDefault: false,
    failOnWarn: true,
    deps: {
      neverBundle: [/^@deepseek-ai\//, /^cordis(?:\/|$)/],
    },
  },
  {
    name: 'dsh-session-pins/client',
    entry: { client: 'src/client/index.ts' },
    outDir: 'lib',
    format: 'cjs',
    platform: 'browser',
    target: 'es2024',
    fixedExtension: false,
    dts: false,
    sourcemap: true,
    clean: false,
    cjsDefault: false,
    failOnWarn: true,
    define: {
      'process.env.NODE_ENV': JSON.stringify('production'),
      'import.meta.env.MODE': JSON.stringify('production'),
      'import.meta.env': JSON.stringify({ MODE: 'production' }),
    },
    deps: {
      neverBundle: [...CLIENT_EXTERNALS],
      alwaysBundle: (id) =>
        CLIENT_EXTERNALS.includes(id as (typeof CLIENT_EXTERNALS)[number]) ? undefined : true,
    },
    plugins: [cssModulesPlugin()],
    outputOptions: {
      entryFileNames: 'client.js',
      sourcemapPathTransform: portableSourcePath,
      banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify(PACKAGE_NAME)}, factory: (require) => {`,
      footer: 'return module.exports; } });',
      intro: 'var module = { exports: {} }; var exports = module.exports;',
    },
  },
])
