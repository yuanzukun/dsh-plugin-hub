import { expect, it } from 'vitest'

it('provides jsdom globals and Testing Library matchers', () => {
  const element = document.createElement('div')
  document.body.append(element)

  expect(element).toBeInTheDocument()
})
