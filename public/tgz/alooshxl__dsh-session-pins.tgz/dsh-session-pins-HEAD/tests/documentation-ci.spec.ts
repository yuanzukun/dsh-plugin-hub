import { spawnSync } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { describe, expect, it } from 'vitest'
import { parse } from 'yaml'

const repositoryRoot = fileURLToPath(new URL('../', import.meta.url))
const readmePaths = ['README.md', 'README.zh.md'] as const

function readRequired(relativePath: string): string {
  const absolutePath = join(repositoryRoot, relativePath)
  expect(existsSync(absolutePath), `${relativePath} must exist`).toBe(true)
  return readFileSync(absolutePath, 'utf8')
}

function record(value: unknown, label: string): Readonly<Record<string, unknown>> {
  expect(value, `${label} must be an object`).not.toBeNull()
  expect(typeof value, `${label} must be an object`).toBe('object')
  expect(Array.isArray(value), `${label} must be an object`).toBe(false)
  return value as Readonly<Record<string, unknown>>
}

function workflowSteps(value: unknown): readonly Readonly<Record<string, unknown>>[] {
  expect(Array.isArray(value), 'verify.steps must be an array').toBe(true)
  return (value as readonly unknown[]).map((step, index) => record(step, `verify.steps[${index}]`))
}

describe('public documentation contract', () => {
  it.each(readmePaths)('%s carries the complete post-release command surface', (readmePath) => {
    const source = readRequired(readmePath)

    for (const expected of [
      '@deepseek-ai/dsh@0.1.0-rc.6',
      'sidebar.footer.action',
      'dsh.session-pins.v1',
      'https://github.com/deepseek-ai/deepseek-harness/discussions/63',
      'https://github.com/alooshxl/dsh-session-pins/issues',
      'dsh plugin --profile web add github:alooshxl/dsh-session-pins#v0.1.0',
      'dsh plugin --profile web add github:alooshxl/dsh-session-pins#<40-character-commit-sha>',
      'dsh plugin --profile web remove @dsh-external/dsh-session-pins',
      'dsh web',
      'dsh --profile web',
      'pnpm install --frozen-lockfile',
      'pnpm run format',
      'pnpm run test',
      'pnpm run lint',
      'pnpm run build',
      'pnpm run format:check',
      'pnpm run typecheck',
      'pnpm run verify:self-contained',
      'pnpm run verify:package',
      'git diff --check',
      'MIT',
    ]) {
      expect(source, `${readmePath} is missing ${expected}`).toContain(expected)
    }

    expect(source).toMatch(/localStorage/)
    expect(source).toMatch(/100/)
    expect(source).not.toContain('--profile default')
    expect(source).not.toMatch(/dsh plugin[^\n]*\bupdate\b/)
    expect(source).not.toContain('pnpm pack --dry-run --json')
  })

  it('keeps English and Chinese behavior coverage equivalent', () => {
    const english = readRequired('README.md')
    const chinese = readRequired('README.zh.md')

    for (const source of [english, chinese]) {
      expect(source).toMatch(/wide|展开/)
      expect(source).toMatch(/rail|收起/)
      expect(source).toMatch(/blank|空白/)
      expect(source).toMatch(/subagent|子代理/i)
      expect(source).toMatch(/archived|归档/i)
      expect(source).toMatch(/stale|失效/i)
      expect(source).toMatch(/same-origin|同源/i)
      expect(source).toMatch(/developer preview|开发者预览/i)
      expect(source).toMatch(/Task 7/)
    }
  })

  it('documents the rc.6 archived-session safeguard without an openable claim', () => {
    const english = readRequired('README.md')
    const chinese = readRequired('README.zh.md')
    const contract = readRequired('docs/dsh-plugin-contracts.md')
    const agents = readRequired('AGENTS.md')

    for (const source of [english, chinese, contract, agents]) {
      expect(source).toContain('baselinesReady === true')
      expect(source).toContain("phase === 'ready'")
      expect(source).toContain("state === 'idle'")
    }

    expect(english).toMatch(/immediately clears an archived id[\s\S]{0,160}`sessions\.open\(\)`/)
    expect(english).toMatch(/does not call `sessions\.open\(\)`[\s\S]{0,160}false success/)
    expect(english).not.toContain('An archived ordinary session remains openable')

    expect(chinese).toMatch(/立即清除[\s\S]{0,160}`sessions\.open\(\)`[\s\S]{0,160}归档 id/)
    expect(chinese).toMatch(/不会调用 `sessions\.open\(\)`[\s\S]{0,160}虚假成功/)
    expect(chinese).not.toContain('也仍可从本菜单打开')

    expect(contract).toContain('no public unarchive operation')
    expect(contract).toContain('false success')
    expect(agents).toContain('Harness `0.1.0-rc.6`')
  })

  it('records the isolated keyless profile smoke evidence and audited build policy', () => {
    const english = readRequired('README.md')
    const chinese = readRequired('README.zh.md')
    const contract = readRequired('docs/dsh-plugin-contracts.md')
    const agents = readRequired('AGENTS.md')
    const changelog = readRequired('CHANGELOG.md')
    const manifest = JSON.parse(readRequired('package.json')) as {
      readonly devDependencies?: Readonly<Record<string, string>>
    }
    const workspace = parse(readRequired('pnpm-workspace.yaml')) as {
      readonly allowBuilds?: Readonly<Record<string, boolean>>
    }

    expect(english).toContain('isolated, keyless rc.6 profile smoke')
    expect(chinese).toContain('隔离、无凭据的 rc.6 profile 冒烟测试')
    expect(contract).toContain('tests/smoke-profile.spec.ts')
    expect(contract).toContain('empty temporary workspace')
    expect(contract).toContain('`close` event')
    expect(contract).toContain('@deepseek-ai/dsh-subprocess-local@0.1.0-rc.6')
    expect(contract).toContain('node-pty@1.1.0')
    expect(agents).toContain('tests/smoke-profile.spec.ts')
    expect(agents).toContain('empty temporary workspace')
    expect(agents).toContain('`close` event')
    expect(changelog).toContain('isolated, keyless rc.6 profile smoke')
    expect(english).toContain('@deepseek-ai/dsh-subprocess-local@0.1.0-rc.6')
    expect(english).toContain('node-pty@1.1.0')
    expect(chinese).toContain('@deepseek-ai/dsh-subprocess-local@0.1.0-rc.6')
    expect(chinese).toContain('node-pty@1.1.0')
    expect(manifest.devDependencies?.['@deepseek-ai/dsh']).toBe('0.1.0-rc.6')
    const buildDecisions = Object.entries(workspace.allowBuilds ?? {})
    expect(
      buildDecisions.filter(([, allowed]) => allowed).map(([dependency]) => dependency),
    ).toStrictEqual(['@deepseek-ai/dsh-subprocess-local@0.1.0-rc.6', 'node-pty@1.1.0'])
    for (const [dependency, allowed] of buildDecisions) {
      if (allowed) continue
      expect(allowed, dependency).toBe(false)
    }
  })

  it('uses the corrected web profile in the approved plan', () => {
    const plan = readRequired('docs/superpowers/plans/2026-08-13-session-pins.md')

    expect(plan).toContain('dsh plugin --profile web add github:alooshxl/dsh-session-pins#v0.1.0')
    expect(plan).not.toContain('dsh plugin --profile default add')
    expect(plan).not.toMatch(/pnpm run verify:package\r?\npnpm pack --dry-run --json/)
  })

  it('distinguishes local package verification from the CI-only direct dry-run', () => {
    const contract = readRequired('docs/dsh-plugin-contracts.md')

    expect(contract).toContain('pnpm run verify:package')
    expect(contract).toContain('pnpm pack --dry-run --json')
    expect(contract).toContain('pnpm/action-setup')
    expect(contract).toContain('standalone: false')
  })
})

describe('continuous verification workflow', () => {
  it('keeps the workflow inside the repository boundary', () => {
    const verifierPath = join(repositoryRoot, 'scripts/verify-self-contained.mjs')
    const result = spawnSync(process.execPath, [verifierPath], {
      cwd: repositoryRoot,
      encoding: 'utf8',
    })

    expect(result.status, result.stderr).toBe(0)
    expect(result.stdout).toContain('self-contained repository verified')
  })

  it('pins Node before a non-standalone pnpm 11 verification job', () => {
    const source = readRequired('.github/workflows/ci.yml')
    const workflow = record(parse(source), 'workflow')
    const triggers = record(workflow.on, 'workflow.on')
    const permissions = record(workflow.permissions, 'workflow.permissions')
    const concurrency = record(workflow.concurrency, 'workflow.concurrency')
    const jobs = record(workflow.jobs, 'workflow.jobs')
    const verifyJob = record(jobs.verify, 'workflow.jobs.verify')
    const environment = record(verifyJob.env, 'workflow.jobs.verify.env')
    const steps = workflowSteps(verifyJob.steps)

    expect(Object.keys(triggers).sort()).toStrictEqual(['pull_request', 'push'])
    expect(permissions).toStrictEqual({ contents: 'read' })
    expect(concurrency.group).toContain('${{')
    expect(concurrency['cancel-in-progress']).toBe(true)
    expect(verifyJob['runs-on']).toBe('ubuntu-24.04')
    expect(verifyJob['timeout-minutes']).toBe(20)
    expect(environment.CI).toBe('true')

    const actionSteps = steps.filter((step) => typeof step.uses === 'string')
    expect(actionSteps.map((step) => step.uses)).toStrictEqual([
      'actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1',
      'actions/setup-node@820762786026740c76f36085b0efc47a31fe5020',
      'pnpm/action-setup@0977fd99725f1db4007ccb2928dbb4e90d06cc86',
    ])
    for (const step of actionSteps) {
      expect(step.uses).toMatch(/^[^@]+@[0-9a-f]{40}$/)
    }
    expect(source).toContain('# v7.0.1')
    expect(source).toContain('# v7.0.0')
    expect(source).toContain('# v6.0.10')
    expect(source).not.toContain('pnpm/setup@')

    const checkout = record(actionSteps[0]?.with, 'checkout.with')
    expect(checkout['persist-credentials']).toBe(false)

    const setupNode = record(actionSteps[1]?.with, 'setup-node.with')
    expect(setupNode).toStrictEqual({
      'node-version': '22',
      'package-manager-cache': false,
    })

    const setupPnpm = record(actionSteps[2]?.with, 'pnpm action setup.with')
    expect(setupPnpm).toStrictEqual({
      version: '11.7.0',
      standalone: false,
      cache: false,
    })
  })

  it('runs the complete checks and independently inspects dry-run pack semantics', () => {
    const workflow = record(parse(readRequired('.github/workflows/ci.yml')), 'workflow')
    const jobs = record(workflow.jobs, 'workflow.jobs')
    const verifyJob = record(jobs.verify, 'workflow.jobs.verify')
    const runs = workflowSteps(verifyJob.steps)
      .map((step) => step.run)
      .filter((run): run is string => typeof run === 'string')

    const orderedCommands = [
      'pnpm install --frozen-lockfile',
      'pnpm run format:check',
      'pnpm run lint',
      'pnpm run typecheck',
      'pnpm run test',
      'pnpm run build',
      'pnpm run verify:self-contained',
      'pnpm run verify:package',
    ]
    const commandIndexes = orderedCommands.map((command) =>
      runs.findIndex((run) =>
        run
          .split(/\r?\n/)
          .map((line) => line.trim())
          .includes(command),
      ),
    )
    expect(commandIndexes.every((index) => index >= 0)).toBe(true)
    expect(commandIndexes).toStrictEqual([...commandIndexes].sort((left, right) => left - right))

    const driftCheck = runs.find((run) =>
      run.includes('git status --short --untracked-files=all -- lib'),
    )
    expect(driftCheck).toContain('exit 1')

    const packInspection = runs.find((run) => run.includes('pnpm pack --dry-run --json'))
    expect(packInspection).toBeDefined()
    for (const expected of [
      '@dsh-external/dsh-session-pins',
      '0.1.0',
      'README.md',
      'README.zh.md',
      'lib/index.js',
      'lib/invariant.js',
      'lib/client.js',
      'new Set',
      'isAbsolute',
      'archivesBefore',
      'archivesAfter',
    ]) {
      expect(packInspection, `pack inspection is missing ${expected}`).toContain(expected)
    }
  })
})
