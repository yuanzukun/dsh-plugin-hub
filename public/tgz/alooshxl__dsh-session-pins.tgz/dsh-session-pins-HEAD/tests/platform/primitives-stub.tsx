import {
  cloneElement,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type FocusEventHandler,
  type MouseEventHandler,
  type ReactElement,
  type ReactNode,
} from 'react'
import { createPortal } from 'react-dom'

export interface MenuItem {
  id: string
  label: ReactNode
  disabled?: boolean
  icon?: ReactNode
  danger?: boolean
  submenu?: readonly MenuItem[]
}

export interface MenuSeparator {
  type: 'separator'
  id: string
}

export interface MenuLabel {
  type: 'label'
  id: string
  text: string
}

export type MenuEntry = MenuItem | MenuSeparator | MenuLabel

function isSeparator(entry: MenuEntry): entry is MenuSeparator {
  return 'type' in entry && entry.type === 'separator'
}

function isLabel(entry: MenuEntry): entry is MenuLabel {
  return 'type' in entry && entry.type === 'label'
}

export function Menu({
  open,
  anchor,
  items,
  footer,
  selectedId,
  selectedIds,
  onSelect,
  onClose,
  portal = false,
  getAnchorRect,
  className,
}: {
  open: boolean
  anchor: ReactNode
  items: readonly MenuEntry[]
  footer?: readonly MenuEntry[]
  selectedId?: string
  selectedIds?: readonly string[]
  onSelect: (id: string) => void
  onClose: () => void
  align?: 'start' | 'end'
  side?: 'bottom' | 'top' | 'right'
  portal?: boolean
  closeOnPointerLeave?: boolean
  dense?: boolean
  compact?: boolean
  getAnchorRect?: () => DOMRect | null
  className?: string
}) {
  const rootRef = useRef<HTMLSpanElement>(null)
  const listRef = useRef<HTMLDivElement>(null)
  const [openSubmenuId, setOpenSubmenuId] = useState<string | null>(null)

  useLayoutEffect(() => {
    if (open) getAnchorRect?.()
  }, [getAnchorRect, open])

  useEffect(() => {
    if (!open) {
      setOpenSubmenuId(null)
      return
    }

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
    }
    const handlePointerDown = (event: PointerEvent) => {
      if (!(event.target instanceof Node)) return
      if (rootRef.current?.contains(event.target) === true) return
      if (listRef.current?.contains(event.target) === true) return
      onClose()
    }

    document.addEventListener('keydown', handleKeyDown)
    document.addEventListener('pointerdown', handlePointerDown)
    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.removeEventListener('pointerdown', handlePointerDown)
    }
  }, [onClose, open])

  const renderEntry = (entry: MenuEntry) => {
    if (isSeparator(entry)) {
      return <div key={entry.id} role="separator" />
    }
    if (isLabel(entry)) {
      return (
        <div key={entry.id} role="presentation">
          {entry.text}
        </div>
      )
    }

    const hasSubmenu = entry.submenu !== undefined && entry.submenu.length > 0
    const submenuOpen = hasSubmenu && openSubmenuId === entry.id
    const selected = entry.id === selectedId || selectedIds?.includes(entry.id) === true

    return (
      <div
        key={entry.id}
        onMouseEnter={() => {
          setOpenSubmenuId(hasSubmenu ? entry.id : null)
        }}
        onMouseLeave={() => {
          setOpenSubmenuId(null)
        }}
      >
        <button
          type="button"
          role="menuitem"
          disabled={entry.disabled}
          data-selected={selected || undefined}
          aria-haspopup={hasSubmenu ? 'menu' : undefined}
          aria-expanded={hasSubmenu ? submenuOpen : undefined}
          onFocus={() => {
            setOpenSubmenuId(hasSubmenu ? entry.id : null)
          }}
          onClick={() => {
            if (hasSubmenu) {
              setOpenSubmenuId(entry.id)
              return
            }
            onSelect(entry.id)
          }}
        >
          {entry.icon}
          {entry.label}
          {selected ? <span aria-hidden="true">✓</span> : null}
        </button>
        {submenuOpen && entry.submenu !== undefined ? (
          <div role="menu">
            {entry.submenu.map((submenuItem) => (
              <button
                key={submenuItem.id}
                type="button"
                role="menuitem"
                disabled={submenuItem.disabled}
                onClick={() => {
                  onSelect(submenuItem.id)
                }}
              >
                {submenuItem.icon}
                {submenuItem.label}
              </button>
            ))}
          </div>
        ) : null}
      </div>
    )
  }

  const list = open ? (
    <div ref={listRef} role="menu">
      <div role="presentation">{items.map(renderEntry)}</div>
      {footer !== undefined && footer.length > 0 ? (
        <div role="presentation">{footer.map(renderEntry)}</div>
      ) : null}
    </div>
  ) : null

  return (
    <span ref={rootRef} className={className}>
      {anchor}
      {portal && list !== null ? createPortal(list, document.body) : list}
    </span>
  )
}

interface TooltipAnchorProps {
  onMouseEnter?: MouseEventHandler
  onMouseLeave?: MouseEventHandler
  onFocus?: FocusEventHandler
  onBlur?: FocusEventHandler
}

export function Tooltip({
  label,
  delayMs = 0,
  disabled = false,
  children,
}: {
  label: string | (() => string)
  side?: 'right' | 'bottom' | 'top'
  delayMs?: number
  disabled?: boolean
  maxWidth?: number
  children: ReactElement<TooltipAnchorProps>
}) {
  const timerRef = useRef<number | null>(null)
  const [visible, setVisible] = useState(false)

  const clearTimer = () => {
    if (timerRef.current === null) return
    window.clearTimeout(timerRef.current)
    timerRef.current = null
  }

  useEffect(() => {
    if (!disabled) return
    clearTimer()
    setVisible(false)
  }, [disabled])

  useEffect(
    () => () => {
      clearTimer()
    },
    [],
  )

  const anchor = cloneElement(children, {
    onMouseEnter: (event) => {
      children.props.onMouseEnter?.(event)
      if (disabled) return
      clearTimer()
      timerRef.current = window.setTimeout(() => {
        timerRef.current = null
        setVisible(true)
      }, delayMs)
    },
    onMouseLeave: (event) => {
      children.props.onMouseLeave?.(event)
      clearTimer()
      setVisible(false)
    },
    onFocus: (event) => {
      children.props.onFocus?.(event)
      if (!disabled) setVisible(true)
    },
    onBlur: (event) => {
      children.props.onBlur?.(event)
      clearTimer()
      setVisible(false)
    },
  })

  return (
    <>
      {anchor}
      {visible && !disabled
        ? createPortal(
            <div role="tooltip">{typeof label === 'function' ? label() : label}</div>,
            document.body,
          )
        : null}
    </>
  )
}
