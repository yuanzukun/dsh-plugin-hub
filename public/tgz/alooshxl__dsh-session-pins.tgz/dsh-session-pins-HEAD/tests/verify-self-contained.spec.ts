import { spawnSync } from 'node:child_process'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { afterEach, describe, expect, it } from 'vitest'

const verifierPath = fileURLToPath(new URL('../scripts/verify-self-contained.mjs', import.meta.url))
const forwardSlash = String.fromCharCode(47)
const fixtureRoots: string[] = []

interface FixturePackageJson {
  readonly dependencies?: Readonly<Record<string, string>>
  readonly scripts?: Readonly<Record<string, string>>
}

async function createFixture(packageJson: FixturePackageJson = {}) {
  const fixtureRoot = await mkdtemp(join(tmpdir(), 'dsh-session-pins-verifier-'))
  fixtureRoots.push(fixtureRoot)
  await writeFile(join(fixtureRoot, 'package.json'), `${JSON.stringify(packageJson, null, 2)}\n`)
  await writeFile(join(fixtureRoot, 'pnpm-lock.yaml'), "lockfileVersion: '9.0'\n")
  return fixtureRoot
}

function runVerifier(fixtureRoot: string) {
  return spawnSync(process.execPath, [verifierPath, fixtureRoot], {
    cwd: fixtureRoot,
    encoding: 'utf8',
  })
}

afterEach(async () => {
  await Promise.all(
    fixtureRoots.splice(0).map((fixtureRoot) => rm(fixtureRoot, { force: true, recursive: true })),
  )
})

describe('absolute file paths', () => {
  it.each([
    ['POSIX filesystem root', forwardSlash],
    ['POSIX root path', ['', 'tmp'].join(forwardSlash)],
    ['unlisted POSIX root path', ['', 'workspace'].join(forwardSlash)],
    ['Windows drive path', ['C:', 'temp', 'secret.txt'].join('\\')],
    ['UNC path', ['', '', 'server', 'share', 'secret.txt'].join('\\')],
    ['file URL', ['file', ['', '', '', 'tmp', 'secret.txt'].join(forwardSlash)].join(':')],
  ])('rejects a %s', async (_label, absolutePath) => {
    const fixtureRoot = await createFixture()
    await writeFile(join(fixtureRoot, 'notes.md'), `location: ${absolutePath}\n`)

    const result = runVerifier(fixtureRoot)

    expect(result.status).toBe(1)
    expect(result.stderr).toContain('notes.md: contains absolute path')
  })

  it('rejects a backticked filesystem root in package context', async () => {
    const fixtureRoot = await createFixture()
    const absolutePath = ['', 'workspace'].join(forwardSlash)
    await writeFile(join(fixtureRoot, 'notes.md'), `Use the package entry \`${absolutePath}\`.\n`)

    const result = runVerifier(fixtureRoot)

    expect(result.status).toBe(1)
    expect(result.stderr).toContain('notes.md: contains absolute path')
  })

  it('rejects a backticked filesystem root without package context', async () => {
    const fixtureRoot = await createFixture()
    const absolutePath = ['', 'workspace'].join(forwardSlash)
    await writeFile(join(fixtureRoot, 'notes.md'), `Use the filesystem root \`${absolutePath}\`.\n`)

    const result = runVerifier(fixtureRoot)

    expect(result.status).toBe(1)
    expect(result.stderr).toContain('notes.md: contains absolute path')
  })

  it('rejects an absolute path inside a line comment', async () => {
    const fixtureRoot = await createFixture()
    await writeFile(
      join(fixtureRoot, 'example.ts'),
      `${forwardSlash}${forwardSlash} cache: ${forwardSlash}workspace\n`,
    )

    const result = runVerifier(fixtureRoot)

    expect(result.status).toBe(1)
    expect(result.stderr).toContain('example.ts: contains absolute path')
  })

  it.each([
    ['string', 'example.ts', (path: string) => `const root = '${path}'\n`],
    ['template', 'example.ts', (path: string) => `const root = \`${path}\`\n`],
    ['JSX text', 'example.tsx', (path: string) => `const view = <div>${path}</div>\n`],
    [
      'block comment',
      'example.ts',
      (path: string) => `${forwardSlash}* cache: ${path} *${forwardSlash}\n`,
    ],
  ])('rejects an absolute path in code %s', async (_label, fileName, sourceFor) => {
    const fixtureRoot = await createFixture()
    const absolutePath = ['', 'workspace'].join(forwardSlash)
    await writeFile(join(fixtureRoot, fileName), sourceFor(absolutePath))

    const result = runVerifier(fixtureRoot)

    expect(result.status).toBe(1)
    expect(result.stderr).toContain(`${fileName}: contains absolute path`)
  })

  it('permits a regex literal after an arrow expression', async () => {
    const fixtureRoot = await createFixture()
    await writeFile(
      join(fixtureRoot, 'example.ts'),
      `const matches = (value) => ${forwardSlash}workspace${forwardSlash}.test(value)\n`,
    )

    const result = runVerifier(fixtureRoot)

    expect(result.status).toBe(0)
    expect(result.stdout).toContain('self-contained repository verified')
  })

  it('permits a regex literal after unbraced control flow', async () => {
    const fixtureRoot = await createFixture()
    await writeFile(
      join(fixtureRoot, 'example.ts'),
      `if (enabled) ${forwardSlash}workspace${forwardSlash}.test(value)\n`,
    )

    const result = runVerifier(fixtureRoot)

    expect(result.status).toBe(0)
    expect(result.stdout).toContain('self-contained repository verified')
  })

  it('permits URL, regex, package subpath, and comment syntax', async () => {
    const fixtureRoot = await createFixture()
    await writeFile(
      join(fixtureRoot, 'example.ts'),
      [
        `const endpoint = 'https:${forwardSlash}${forwardSlash}example.com${forwardSlash}path'`,
        `const matcher = ${forwardSlash}workspace${forwardSlash}`,
        `const ratio = width ${forwardSlash} height`,
        `${forwardSlash}${forwardSlash} repository comment`,
      ].join('\n'),
    )
    await writeFile(
      join(fixtureRoot, 'notes.md'),
      `Use the \`.${forwardSlash}client\` package entry.\n`,
    )

    const result = runVerifier(fixtureRoot)

    expect(result.status).toBe(0)
    expect(result.stdout).toContain('self-contained repository verified')
  })
})

describe('CSS source paths', () => {
  it.each([
    ['absolute import', `@import '${['', 'workspace', 'theme.css'].join(forwardSlash)}';\n`],
    [
      'file URL',
      `.root { background-image: url(${[
        'file',
        ['', '', '', 'tmp', 'asset.png'].join(forwardSlash),
      ].join(':')}); }\n`,
    ],
    [
      'Windows drive URL',
      `.root { background-image: url('${['C:', 'assets', 'image.png'].join('\\')}'); }\n`,
    ],
    [
      'UNC URL',
      `.root { background-image: url('${['', '', 'server', 'share', 'image.png'].join('\\')}'); }\n`,
    ],
  ])('rejects a CSS %s', async (_label, source) => {
    const fixtureRoot = await createFixture()
    await writeFile(join(fixtureRoot, 'styles.module.css'), source)

    const result = runVerifier(fixtureRoot)

    expect(result.status).toBe(1)
    expect(result.stderr).toContain('styles.module.css: contains absolute path')
  })

  it.each([
    [
      'relative module references',
      "@import './theme.css';\n.root { background-image: url('./asset.png'); }\n",
    ],
    [
      'block comments',
      `${forwardSlash}* component styles *${forwardSlash}\n.root { display: block; }\n`,
    ],
    ['calc division', `.root { width: calc(100% ${forwardSlash} 3); }\n`],
    ['data URLs', '.root { background-image: url(data:image/png;base64,AAAA); }\n'],
  ])('permits CSS %s', async (_label, source) => {
    const fixtureRoot = await createFixture()
    await writeFile(join(fixtureRoot, 'styles.module.css'), source)

    const result = runVerifier(fixtureRoot)

    expect(result.status).toBe(0)
    expect(result.stdout).toContain('self-contained repository verified')
  })
})

describe('dependency specifications', () => {
  it.each([
    'github:owner/repository',
    ['github:', 'owner', 'repository'].join(forwardSlash),
    'git://github.com/owner/repository.git',
    'git+ssh://git@github.com/owner/repository.git',
    'https://registry.example/package.tgz',
    ['file', 'vendor/package'].join(':'),
    'link:vendor/package',
    'workspace:*',
    'owner/repository',
  ])('rejects non-registry spec %s', async (dependencySpec) => {
    const fixtureRoot = await createFixture({
      dependencies: { dependency: dependencySpec },
    })

    const result = runVerifier(fixtureRoot)

    expect(result.status).toBe(1)
    expect(result.stderr).toContain(
      `package.json: dependencies.dependency uses non-registry spec ${dependencySpec}`,
    )
  })

  it.each([
    '1.2.3',
    '^1.2.3',
    '~1.2.3',
    '>=1.2.3',
    'latest',
    'next',
    'npm:registry-package@^1.2.3',
  ])('permits registry spec %s', async (dependencySpec) => {
    const fixtureRoot = await createFixture({
      dependencies: { dependency: dependencySpec },
    })

    const result = runVerifier(fixtureRoot)

    expect(result.status).toBe(0)
    expect(result.stdout).toContain('self-contained repository verified')
  })
})

describe('install-time lifecycle scripts', () => {
  it('rejects pnpm:devPreinstall', async () => {
    const fixtureRoot = await createFixture({
      scripts: { 'pnpm:devPreinstall': 'node scripts/dev-preinstall.mjs' },
    })

    const result = runVerifier(fixtureRoot)

    expect(result.status).toBe(1)
    expect(result.stderr).toContain(
      'package.json: install-time lifecycle script pnpm:devPreinstall is not allowed',
    )
  })
})
