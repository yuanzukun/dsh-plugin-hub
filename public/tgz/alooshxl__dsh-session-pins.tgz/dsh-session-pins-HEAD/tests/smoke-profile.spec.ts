import { spawn, spawnSync, type ChildProcess } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { createRequire } from 'node:module'
import { homedir, tmpdir } from 'node:os'
import { delimiter, dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { describe, expect, it } from 'vitest'
import { parse } from 'yaml'

const repositoryRoot = fileURLToPath(new URL('../', import.meta.url))
const require = createRequire(import.meta.url)
const packageName = '@dsh-external/dsh-session-pins'
const profileName = 'web'
const repositoryFileSpec = ['file', '.'].join(':')
const commandTimeoutMs = 30_000
const shutdownTimeoutMs = 7_000

interface PackageManifest {
  readonly bin?: Readonly<Record<string, string>>
  readonly devDependencies?: Readonly<Record<string, string>>
  readonly packageManager?: string
}

interface BootEntry {
  readonly id: string
  readonly url: string
}

interface BootManifest {
  readonly entries: readonly BootEntry[]
}

interface WorkspaceConfig {
  readonly allowBuilds?: Readonly<Record<string, boolean>>
}

function readManifest(path: string): PackageManifest {
  return JSON.parse(readFileSync(path, 'utf8')) as PackageManifest
}

function packageManagerInvocation(): {
  readonly command: string
  readonly pathDirectory?: string
  readonly prefix: readonly string[]
} {
  const version = /^pnpm@(.+)$/.exec(
    readManifest(join(repositoryRoot, 'package.json')).packageManager ?? '',
  )?.[1]
  if (version !== undefined) {
    for (const dataRoot of [
      process.env.PNPM_HOME,
      process.env.LOCALAPPDATA === undefined
        ? join(homedir(), 'AppData', 'Local', 'pnpm')
        : join(process.env.LOCALAPPDATA, 'pnpm'),
      process.env.XDG_DATA_HOME === undefined
        ? join(homedir(), '.local', 'share', 'pnpm')
        : join(process.env.XDG_DATA_HOME, 'pnpm'),
    ]) {
      if (dataRoot === undefined) continue
      const toolRoot = join(dataRoot, '.tools', 'pnpm', version)
      for (const scriptPath of [
        join(toolRoot, 'node_modules', 'pnpm', 'bin', 'pnpm.cjs'),
        join(toolRoot, 'node_modules', 'pnpm', 'dist', 'pnpm.cjs'),
      ]) {
        if (existsSync(scriptPath)) {
          return {
            command: process.execPath,
            pathDirectory: join(toolRoot, 'bin'),
            prefix: [scriptPath],
          }
        }
      }
    }
  }

  const packageManagerPath = process.env.npm_execpath
  if (packageManagerPath !== undefined && existsSync(packageManagerPath)) {
    return /\.(?:cjs|mjs|js)$/i.test(packageManagerPath)
      ? { command: process.execPath, prefix: [packageManagerPath] }
      : { command: packageManagerPath, pathDirectory: dirname(packageManagerPath), prefix: [] }
  }

  return { command: process.platform === 'win32' ? 'pnpm.exe' : 'pnpm', prefix: [] }
}

function runSync(
  command: string,
  args: readonly string[],
  environment: NodeJS.ProcessEnv,
  cwd = repositoryRoot,
): string {
  const result = spawnSync(command, args, {
    cwd,
    env: environment,
    encoding: 'utf8',
    shell: false,
    timeout: commandTimeoutMs,
    windowsHide: true,
  })

  if (result.error !== undefined) throw result.error
  if (result.status !== 0) {
    throw new Error(
      [
        `command failed (${String(result.status)}): ${command} ${args.join(' ')}`,
        result.stdout,
        result.stderr,
      ].join('\n'),
    )
  }
  return result.stdout
}

function keylessEnvironment(dshHome: string, packageManagerPath?: string): NodeJS.ProcessEnv {
  const environment: NodeJS.ProcessEnv = {
    ...process.env,
    CI: '1',
    DSH_HOME: dshHome,
    DSH_TELEMETRY_DISABLED: '1',
    FORCE_COLOR: '0',
    NO_COLOR: '1',
  }
  if (packageManagerPath !== undefined) {
    environment.PATH = `${packageManagerPath}${delimiter}${environment.PATH ?? ''}`
  }
  for (const key of [
    'ANTHROPIC_API_KEY',
    'AWS_ACCESS_KEY_ID',
    'AWS_SECRET_ACCESS_KEY',
    'DEEPSEEK_API_KEY',
    'DSH_API_KEY',
    'GEMINI_API_KEY',
    'GOOGLE_API_KEY',
    'OPENAI_API_KEY',
  ]) {
    environment[key] = ''
  }
  return environment
}

function parseBootManifest(html: string): BootManifest {
  const prefix = 'window.__DSH_BOOT__ = '
  const start = html.indexOf(prefix)
  const end = html.indexOf('</script>', start)
  if (start === -1 || end === -1) throw new Error('root page did not publish window.__DSH_BOOT__')
  return JSON.parse(html.slice(start + prefix.length, end)) as BootManifest
}

async function fetchFromHarness(
  input: string | URL,
  output: { stderr: string; stdout: string },
): Promise<Response> {
  try {
    return await fetch(input, { signal: AbortSignal.timeout(commandTimeoutMs) })
  } catch (error) {
    throw new Error(['Harness fetch failed', output.stdout, output.stderr].join('\n'), {
      cause: error,
    })
  }
}

function waitForWebUrl(
  child: ChildProcess,
  output: { stderr: string; stdout: string },
): Promise<string> {
  const stdout = child.stdout
  const stderr = child.stderr
  if (stdout === null || stderr === null) {
    return Promise.reject(new Error('Harness child did not expose stdout and stderr'))
  }

  stdout.setEncoding('utf8')
  stderr.setEncoding('utf8')
  return new Promise((resolve, reject) => {
    const finish = (error?: Error, url?: string) => {
      clearTimeout(timeout)
      child.off('error', onError)
      child.off('exit', onExit)
      if (error !== undefined) reject(error)
      else resolve(url!)
    }
    const inspect = () => {
      const match = /dsh web:\s+(http:\/\/127\.0\.0\.1:\d+)/.exec(output.stdout)
      if (match !== null) finish(undefined, match[1])
    }
    const onError = (error: Error) => {
      finish(error)
    }
    const onExit = (code: number | null, signal: NodeJS.Signals | null) => {
      finish(
        new Error(
          [
            `Harness exited before readiness (code=${String(code)}, signal=${String(signal)})`,
            output.stdout,
            output.stderr,
          ].join('\n'),
        ),
      )
    }
    const timeout = setTimeout(() => {
      finish(
        new Error(
          [
            `Harness did not publish a loopback URL within ${String(commandTimeoutMs)}ms`,
            output.stdout,
            output.stderr,
          ].join('\n'),
        ),
      )
    }, commandTimeoutMs)

    stdout.on('data', (chunk: string) => {
      output.stdout += chunk
      inspect()
    })
    stderr.on('data', (chunk: string) => {
      output.stderr += chunk
    })
    child.once('error', onError)
    child.once('exit', onExit)
  })
}

function waitForClose(closed: Promise<void>, timeoutMs: number): Promise<boolean> {
  return new Promise((resolve) => {
    const finish = (didClose: boolean) => {
      clearTimeout(timeout)
      resolve(didClose)
    }
    const timeout = setTimeout(() => {
      finish(false)
    }, timeoutMs)

    void closed.then(() => {
      finish(true)
    })
  })
}

async function stopChild(child: ChildProcess, closed: Promise<void>): Promise<void> {
  if (child.exitCode === null && child.signalCode === null) child.kill('SIGTERM')
  const gracefulTermination = waitForClose(closed, shutdownTimeoutMs)
  if (await gracefulTermination) return

  child.kill('SIGKILL')
  if (!(await waitForClose(closed, shutdownTimeoutMs))) {
    throw new Error('Harness child did not close after SIGKILL')
  }
}

describe('isolated Harness web profile', () => {
  it('pins and resolves the published rc.6 CLI authority', () => {
    const repositoryManifest = readManifest(join(repositoryRoot, 'package.json'))

    expect(repositoryManifest.devDependencies?.['@deepseek-ai/dsh']).toBe('0.1.0-rc.6')

    const dshManifestPath = require.resolve('@deepseek-ai/dsh/package.json')
    const dshManifest = readManifest(dshManifestPath)
    const dshBin = dshManifest.bin?.dsh

    expect(dshBin).toBeDefined()
    expect(existsSync(join(dirname(dshManifestPath), dshBin!))).toBe(true)
  })

  it('installs, composes, boots, and serves the built browser module without credentials', async () => {
    const dshHome = await mkdtemp(join(tmpdir(), 'dsh-session-pins-'))
    const bootWorkspace = await mkdtemp(join(tmpdir(), 'dsh-session-pins-workspace-'))
    const dshManifestPath = require.resolve('@deepseek-ai/dsh/package.json')
    const dshManifest = readManifest(dshManifestPath)
    const packageManager = packageManagerInvocation()
    const environment = keylessEnvironment(dshHome, packageManager.pathDirectory)
    const dshBin = join(dirname(dshManifestPath), dshManifest.bin?.dsh ?? '')
    let child: ChildProcess | undefined
    let childClosed: Promise<void> | undefined

    try {
      expect(
        runSync(
          packageManager.command,
          [...packageManager.prefix, '--version'],
          environment,
        ).trim(),
      ).toBe('11.7.0')
      const storePath = runSync(
        packageManager.command,
        [...packageManager.prefix, 'store', 'path', '--silent'],
        environment,
      ).trim()

      runSync(
        process.execPath,
        [
          dshBin,
          'plugin',
          '--profile',
          profileName,
          'install',
          '--offline',
          '--ignore-scripts',
          '--store-dir',
          storePath,
        ],
        environment,
      )
      runSync(
        process.execPath,
        [
          dshBin,
          'plugin',
          '--profile',
          profileName,
          'add',
          repositoryFileSpec,
          '--offline',
          '--ignore-scripts',
          '--store-dir',
          storePath,
        ],
        environment,
      )
      const dump = runSync(
        process.execPath,
        [dshBin, '--profile', profileName, '--dump-config'],
        environment,
      )
      expect(
        dump.split(/\r?\n/).filter((line) => line.trim() === '- id: dsh-session-pins'),
      ).toHaveLength(1)

      const workspace = parse(
        await readFile(join(repositoryRoot, 'pnpm-workspace.yaml'), 'utf8'),
      ) as WorkspaceConfig
      const buildDecisions = Object.entries(workspace.allowBuilds ?? {})
      expect(
        buildDecisions.filter(([, allowed]) => allowed).map(([dependency]) => dependency),
      ).toStrictEqual(['@deepseek-ai/dsh-subprocess-local@0.1.0-rc.6', 'node-pty@1.1.0'])
      for (const [dependency, allowed] of buildDecisions) {
        if (allowed) continue
        expect(allowed, dependency).toBe(false)
      }

      const profileWorkspace = parse(
        await readFile(join(dshHome, 'profiles', profileName, 'pnpm-workspace.yaml'), 'utf8'),
      ) as WorkspaceConfig
      expect(profileWorkspace.allowBuilds).toBeUndefined()

      const output = { stderr: '', stdout: '' }
      child = spawn(
        process.execPath,
        [dshBin, '--profile', profileName, '--host', '127.0.0.1', '--port', '0'],
        {
          cwd: bootWorkspace,
          env: environment,
          shell: false,
          stdio: ['ignore', 'pipe', 'pipe'],
          windowsHide: true,
        },
      )
      childClosed = new Promise((resolve) => {
        child!.once('close', () => {
          resolve()
        })
      })
      const webUrl = await waitForWebUrl(child, output)
      const rootResponse = await fetchFromHarness(webUrl, output)
      expect(rootResponse.status).toBe(200)
      const rootHtml = await rootResponse.text()
      const boot = parseBootManifest(rootHtml)
      const packageRows = boot.entries.filter((entry) => entry.id === packageName)

      expect(packageRows).toHaveLength(1)
      expect(packageRows[0]?.url).toMatch(
        /^\/plugins\/@dsh-external\/dsh-session-pins\/client\.js\?rev=[0-9a-f]{12}$/,
      )

      const moduleResponse = await fetchFromHarness(new URL(packageRows[0]!.url, webUrl), output)
      expect(moduleResponse.status).toBe(200)
      expect(moduleResponse.headers.get('content-type')).toContain('text/javascript')
      expect(moduleResponse.headers.get('cache-control')).toBe('no-cache')
      expect(await moduleResponse.text()).toBe(
        await readFile(join(repositoryRoot, 'lib', 'client.js'), 'utf8'),
      )
    } finally {
      if (child !== undefined && childClosed !== undefined) await stopChild(child, childClosed)
      await Promise.all([
        rm(bootWorkspace, { force: true, recursive: true }),
        rm(dshHome, { force: true, recursive: true }),
      ])
    }
  }, 90_000)
})
