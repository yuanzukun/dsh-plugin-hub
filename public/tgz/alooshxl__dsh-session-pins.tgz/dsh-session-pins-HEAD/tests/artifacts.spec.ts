import { spawnSync } from 'node:child_process'
import { builtinModules } from 'node:module'
import { existsSync, readFileSync, readdirSync } from 'node:fs'
import { homedir } from 'node:os'
import { isAbsolute, join, relative, resolve, sep } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

import { describe, expect, it } from 'vitest'

const repositoryRoot = fileURLToPath(new URL('../', import.meta.url))
const manifestPath = join(repositoryRoot, 'package.json')
const forwardSlash = String.fromCharCode(47)

interface PackageManifest {
  readonly files: readonly string[]
  readonly main: string
  readonly name: string
  readonly packageManager: string
  readonly types: string
  readonly exports: Readonly<Record<string, unknown>>
  readonly scripts: Readonly<Record<string, string>>
}

interface PackedFile {
  readonly path: string
}

interface PackResult {
  readonly files: readonly PackedFile[]
}

interface BrowserHandoff {
  readonly id: string
  readonly factory: (require: (specifier: string) => unknown) => Record<string, unknown>
}

interface InjectedStyle {
  readonly dataset: Record<string, string>
  textContent: string
}

function executeBrowserBundle(source: string): {
  readonly handoff: BrowserHandoff
  readonly styles: InjectedStyle[]
} {
  let handoff: BrowserHandoff | undefined
  const styles: InjectedStyle[] = []
  const documentStub = {
    querySelector(selector: string): InjectedStyle | null {
      const prefix = 'style[data-plugin-css='
      if (!selector.startsWith(prefix) || !selector.endsWith(']')) return null
      const tagId = JSON.parse(selector.slice(prefix.length, -1)) as string
      return styles.find((style) => style.dataset.pluginCss === tagId) ?? null
    },
    createElement(tagName: string): InjectedStyle {
      if (tagName !== 'style') throw new Error(`unexpected element: ${tagName}`)
      return { dataset: {}, textContent: '' }
    },
    head: {
      appendChild(style: InjectedStyle): void {
        styles.push(style)
      },
    },
  }
  const windowStub = {
    __ModuleLoader__: {
      load(candidate: BrowserHandoff): void {
        handoff = candidate
      },
    },
  }

  new Function('window', 'document', source)(windowStub, documentStub)
  if (handoff === undefined) throw new Error('browser bundle did not register a factory')
  return { handoff, styles }
}

function readManifest(): PackageManifest {
  return JSON.parse(readFileSync(manifestPath, 'utf8')) as PackageManifest
}

function packagePath(target: string): string {
  return target.replace(/^\.\//, '')
}

function collectConditionTargets(value: unknown, targets: Set<string>, selected = false): void {
  if (typeof value === 'string') {
    if (selected && !value.includes('*')) targets.add(packagePath(value))
    return
  }
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return

  for (const [condition, target] of Object.entries(value)) {
    collectConditionTargets(
      target,
      targets,
      selected || condition === 'default' || condition === 'types',
    )
  }
}

function exportedArtifactPaths(manifest: PackageManifest): string[] {
  const targets = new Set([packagePath(manifest.main), packagePath(manifest.types)])
  for (const value of Object.values(manifest.exports)) collectConditionTargets(value, targets)
  return [...targets].sort()
}

function repositoryFiles(directory: string): string[] {
  const absoluteDirectory = join(repositoryRoot, directory)
  if (!existsSync(absoluteDirectory)) return []

  const files: string[] = []
  for (const entry of readdirSync(absoluteDirectory, { withFileTypes: true })) {
    const relativePath = join(directory, entry.name)
    if (entry.isDirectory()) {
      files.push(...repositoryFiles(relativePath))
    } else if (entry.isFile()) {
      files.push(relativePath.split(sep).join(forwardSlash))
    }
  }
  return files
}

function parsePackResult(stdout: string): PackResult {
  const parsed = JSON.parse(stdout) as unknown
  const candidate = Array.isArray(parsed) ? parsed[0] : parsed
  if (candidate === null || typeof candidate !== 'object' || !('files' in candidate)) {
    throw new Error('pnpm pack returned no package file inventory')
  }

  const files = (candidate as { readonly files?: unknown }).files
  if (!Array.isArray(files)) throw new Error('pnpm pack returned an invalid package file inventory')
  for (const file of files) {
    if (
      file === null ||
      typeof file !== 'object' ||
      !('path' in file) ||
      typeof file.path !== 'string'
    ) {
      throw new Error('pnpm pack returned an invalid package file entry')
    }
  }
  return candidate as PackResult
}

function packageManagerInvocation(): {
  readonly command: string
  readonly prefix: readonly string[]
} {
  const packageManagerPath = process.env.npm_execpath
  if (packageManagerPath !== undefined && existsSync(packageManagerPath)) {
    return /\.(?:cjs|mjs|js)$/i.test(packageManagerPath)
      ? { command: process.execPath, prefix: [packageManagerPath] }
      : { command: packageManagerPath, prefix: [] }
  }

  const version = /^pnpm@(.+)$/.exec(readManifest().packageManager)?.[1]
  if (version !== undefined) {
    const dataRoots = new Set([
      process.env.PNPM_HOME,
      process.env.LOCALAPPDATA === undefined
        ? join(homedir(), 'AppData', 'Local', 'pnpm')
        : join(process.env.LOCALAPPDATA, 'pnpm'),
      process.env.XDG_DATA_HOME === undefined
        ? join(homedir(), '.local', 'share', 'pnpm')
        : join(process.env.XDG_DATA_HOME, 'pnpm'),
    ])
    for (const dataRoot of dataRoots) {
      if (dataRoot === undefined) continue
      for (const scriptPath of [
        join(dataRoot, '.tools', 'pnpm', version, 'node_modules', 'pnpm', 'bin', 'pnpm.cjs'),
        join(dataRoot, '.tools', 'pnpm', version, 'node_modules', 'pnpm', 'dist', 'pnpm.cjs'),
      ]) {
        if (existsSync(scriptPath)) return { command: process.execPath, prefix: [scriptPath] }
      }
    }
  }

  return { command: process.platform === 'win32' ? 'pnpm.exe' : 'pnpm', prefix: [] }
}

function dryRunPack(): PackResult {
  const tarballPath = join(repositoryRoot, 'dsh-external-dsh-session-pins-0.1.0.tgz')
  expect(existsSync(tarballPath), 'unexpected package tarball before dry-run').toBe(false)

  const invocation = packageManagerInvocation()
  const result = spawnSync(
    invocation.command,
    [...invocation.prefix, 'pack', '--dry-run', '--json'],
    {
      cwd: repositoryRoot,
      encoding: 'utf8',
    },
  )

  expect(result.error?.message).toBeUndefined()
  expect(result.status, result.stderr).toBe(0)
  expect(existsSync(tarballPath), 'pnpm pack --dry-run created a tarball').toBe(false)
  return parsePackResult(result.stdout)
}

function importFresh(relativePath: string): Promise<Record<string, unknown>> {
  const artifactUrl = pathToFileURL(join(repositoryRoot, relativePath))
  artifactUrl.searchParams.set('artifact-test', String(Date.now()))
  return import(artifactUrl.href) as Promise<Record<string, unknown>>
}

function containsAbsolutePath(source: string): boolean {
  const normalizedRoot = repositoryRoot.split(sep).join(forwardSlash)
  const candidates = [
    repositoryRoot,
    normalizedRoot,
    pathToFileURL(repositoryRoot).href,
    resolve(repositoryRoot).replaceAll('\\', '\\\\'),
  ]
  return (
    candidates.some((candidate) => source.includes(candidate)) ||
    /(?:^|[\s"'`(=,:])(?:[A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])/m.test(source) ||
    /(?:^|[\s"'`(=,:])\/(?:home|Users|private|tmp|var\/folders)\//m.test(source)
  )
}

describe('distribution artifacts', () => {
  it('chains every build through the cross-platform clean script', () => {
    const manifest = readManifest()

    expect(manifest.scripts.clean).toBe('node scripts/clean.mjs')
    expect(manifest.scripts.build).toBe('pnpm run clean && tsc -p tsconfig.build.json && tsdown')
    expect(existsSync(join(repositoryRoot, 'scripts/clean.mjs'))).toBe(true)
  })

  it('emits every manifest runtime and declaration target', () => {
    const manifest = readManifest()
    const artifactPaths = exportedArtifactPaths(manifest)

    expect(artifactPaths).toEqual(
      expect.arrayContaining([
        'lib/index.js',
        'lib/invariant.js',
        'lib/client.js',
        'lib/types/index.d.ts',
        'lib/types/invariant.d.ts',
        'lib/types/client/index.d.ts',
      ]),
    )
    for (const artifactPath of artifactPaths) {
      expect(existsSync(join(repositoryRoot, artifactPath)), artifactPath).toBe(true)
    }

    for (const supportingType of [
      'lib/types/client/PinnedSessionsAction.d.ts',
      'lib/types/client/PinIcon.d.ts',
      'lib/types/client/locales.d.ts',
      'lib/types/client/pin-repository.d.ts',
    ]) {
      expect(existsSync(join(repositoryRoot, supportingType)), supportingType).toBe(true)
    }
  })

  it('keeps the Node entries as importable named ESM plugin namespaces', async () => {
    const indexSource = readFileSync(join(repositoryRoot, 'lib/index.js'), 'utf8')
    const invariantSource = readFileSync(join(repositoryRoot, 'lib/invariant.js'), 'utf8')

    for (const source of [indexSource, invariantSource]) {
      expect(source).toMatch(/\bexport\s*\{/)
      expect(source).not.toMatch(/\bexport\s+default\b/)
      expect(source).not.toContain('module.exports')
      expect(source).not.toContain('exports.default')
    }

    const nodePlugin = await importFresh('lib/index.js')
    const invariantPlugin = await importFresh('lib/invariant.js')
    expect(Object.keys(nodePlugin).sort()).toStrictEqual(['apply', 'name'])
    expect(Object.keys(invariantPlugin).sort()).toStrictEqual(['apply', 'inject', 'name'])
  })

  it('hands an executable factory to the package-name graph row with package-owned CSS', () => {
    const manifest = readManifest()
    const clientPath = join(repositoryRoot, 'lib/client.js')
    const clientSource = readFileSync(clientPath, 'utf8')

    expect(() => new Function(clientSource)).not.toThrow()
    const { handoff, styles } = executeBrowserBundle(clientSource)
    expect(handoff.id).toBe(manifest.name)

    const requiredSpecifiers: string[] = []
    const moduleExports = handoff.factory((specifier) => {
      requiredSpecifiers.push(specifier)
      return {}
    })
    expect(Object.keys(moduleExports).sort()).toStrictEqual(['apply', 'inject'])

    const externalRequires = new Set(requiredSpecifiers)
    expect(externalRequires).toStrictEqual(
      new Set(['@deepseek-ai/dsh-client-ui-primitives', 'react', 'react/jsx-runtime']),
    )

    expect(styles).toHaveLength(1)
    expect(styles[0]?.dataset.plugin).toBe(manifest.name)
    expect(styles[0]?.dataset.pluginCss).toBe(
      `${manifest.name}${forwardSlash}PinnedSessionsAction.module.css`,
    )
    expect(styles[0]?.textContent).toContain('dsp_')
    expect(clientSource).toContain('//# sourceMappingURL=client.js.map')
    expect(clientSource).not.toContain('process.env.NODE_ENV')
    expect(containsAbsolutePath(clientSource)).toBe(false)

    const builtins = new Set(builtinModules.map((name) => name.replace(/^node:/, '')))
    for (const specifier of externalRequires) {
      const normalizedSpecifier = specifier.replace(/^node:/, '').split(forwardSlash)[0]!
      expect(builtins.has(normalizedSpecifier), specifier).toBe(false)
    }
  })

  it('emits a portable client source map without local checkout paths', () => {
    const sourceMapPath = join(repositoryRoot, 'lib/client.js.map')
    expect(existsSync(sourceMapPath)).toBe(true)

    const sourceMapText = readFileSync(sourceMapPath, 'utf8')
    const sourceMap = JSON.parse(sourceMapText) as {
      readonly file?: string
      readonly sourceRoot?: string
      readonly sources?: readonly string[]
    }

    expect(sourceMap.file).toBe('client.js')
    expect(sourceMap.sourceRoot === undefined || !isAbsolute(sourceMap.sourceRoot)).toBe(true)
    expect(sourceMap.sources?.length).toBeGreaterThan(0)
    for (const source of sourceMap.sources ?? []) {
      expect(containsAbsolutePath(source), source).toBe(false)
    }
    expect(containsAbsolutePath(sourceMapText)).toBe(false)
  })

  it('packs only the complete installable package surface', () => {
    const manifest = readManifest()
    const packResult = dryRunPack()
    const packedPaths = new Set(
      packResult.files.map((file) => file.path.replaceAll('\\', forwardSlash)),
    )
    const requiredPaths = new Set([
      'package.json',
      'LICENSE',
      'cordis.patch.yml',
      'README.md',
      'README.zh.md',
      ...exportedArtifactPaths(manifest),
      ...repositoryFiles('src'),
      ...repositoryFiles('lib'),
    ])

    expect(manifest.files).toStrictEqual([
      'lib',
      'src',
      'cordis.patch.yml',
      'README.md',
      'README.zh.md',
      'LICENSE',
    ])
    for (const requiredPath of requiredPaths) {
      expect(packedPaths.has(requiredPath), requiredPath).toBe(true)
    }

    const allowedPath =
      /^(?:package\.json|LICENSE|cordis\.patch\.yml|README(?:\.zh)?\.md|lib\/.+|src\/.+)$/
    for (const packedPath of packedPaths) {
      expect(allowedPath.test(packedPath), `unexpected packed file: ${packedPath}`).toBe(true)
      expect(packedPath).not.toMatch(
        /(?:^|\/)(?:tests?|node_modules|coverage|docs\/superpowers|\.pnpm-store|temp|tmp)(?:\/|$)/,
      )
      expect(packedPath).not.toMatch(/(?:^|\/)(?:\.env(?:\.|$)|.*\.(?:tgz|tar|tmp))$/i)
      expect(packedPath).not.toMatch(
        /(?:^|\/).*?(?:secret|credential|private[-_.]?key|auth[-_.]?token).*$/i,
      )
      expect(relative(repositoryRoot, join(repositoryRoot, packedPath))).not.toMatch(/^\.\./)
    }
  })
})
