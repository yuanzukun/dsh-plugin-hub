import { describe, expect, it } from 'vitest'

import {
  MAX_PINNED_SESSIONS,
  PIN_STORAGE_KEY,
  PinRepository,
  type StorageEventLike,
  type StorageEventSource,
  type StorageLike,
} from '../src/client/pin-repository.ts'

class MemoryStorage implements StorageLike {
  readonly reads: string[] = []
  readonly writes: Array<{ readonly key: string; readonly value: string }> = []

  constructor(private value: string | null = null) {}

  getItem(key: string): string | null {
    this.reads.push(key)
    return this.value
  }

  setItem(key: string, value: string): void {
    this.writes.push({ key, value })
    this.value = value
  }

  replaceValue(value: string | null): void {
    this.value = value
  }
}

class ThrowingReadStorage implements StorageLike {
  getItem(key: string): string | null {
    throw new Error(`blocked read for ${key}`)
  }

  setItem(_key: string, _value: string): void {}
}

class ThrowingWriteStorage extends MemoryStorage {
  readonly writeAttempts: Array<{ readonly key: string; readonly value: string }> = []

  override setItem(key: string, value: string): void {
    this.writeAttempts.push({ key, value })
    throw new Error('blocked write')
  }
}

class FailingReconciliationReadStorage extends MemoryStorage {
  private hasRead = false

  override getItem(key: string): string | null {
    if (this.hasRead) {
      throw new Error('blocked reconciliation read')
    }

    this.hasRead = true
    return super.getItem(key)
  }
}

type StorageListener = (event: StorageEventLike) => void

class MemoryStorageEventSource implements StorageEventSource {
  readonly addedListeners: StorageListener[] = []
  readonly removedListeners: StorageListener[] = []
  private readonly listeners = new Set<StorageListener>()

  addEventListener(_type: 'storage', listener: StorageListener): void {
    this.addedListeners.push(listener)
    this.listeners.add(listener)
  }

  removeEventListener(_type: 'storage', listener: StorageListener): void {
    this.removedListeners.push(listener)
    this.listeners.delete(listener)
  }

  emit(event: StorageEventLike): void {
    for (const listener of Array.from(this.listeners)) {
      listener(event)
    }
  }
}

describe('PinRepository hydration', () => {
  it('starts empty when the storage key is absent', () => {
    const storage = new MemoryStorage()
    const repository = new PinRepository(storage)

    const snapshot = repository.getSnapshot()

    expect(storage.reads).toEqual([PIN_STORAGE_KEY])
    expect(snapshot.ids).toEqual([])
    expect(Object.isFrozen(snapshot)).toBe(true)
    expect(Object.isFrozen(snapshot.ids)).toBe(true)
    expect(repository.getSnapshot()).toBe(snapshot)
  })

  it('hydrates a valid versioned value', () => {
    const storage = new MemoryStorage(
      JSON.stringify({ version: 1, ids: ['session-a', 'session-b'] }),
    )

    const repository = new PinRepository(storage)

    expect(repository.getSnapshot().ids).toEqual(['session-a', 'session-b'])
  })

  it.each([
    ['malformed JSON', '{'],
    ['the wrong version', JSON.stringify({ version: 2, ids: ['session-a'] })],
    ['a non-array ids field', JSON.stringify({ version: 1, ids: 'session-a' })],
  ])('falls back to empty for %s', (_caseName, storedValue) => {
    const repository = new PinRepository(new MemoryStorage(storedValue))

    expect(repository.getSnapshot().ids).toEqual([])
  })

  it('discards invalid entries without changing valid opaque ids or their first occurrence', () => {
    const opaqueId = '  opaque/session?id=1  '
    const storage = new MemoryStorage(
      JSON.stringify({
        version: 1,
        ids: [null, 42, '', ' \t ', opaqueId, 'session-b', opaqueId, false, 'session-b'],
      }),
    )

    const repository = new PinRepository(storage)

    expect(repository.getSnapshot().ids).toEqual([opaqueId, 'session-b'])
  })

  it('keeps only the first one hundred valid unique ids', () => {
    const ids = Array.from({ length: MAX_PINNED_SESSIONS + 5 }, (_, index) => `session-${index}`)
    const storage = new MemoryStorage(JSON.stringify({ version: 1, ids }))

    const repository = new PinRepository(storage)

    expect(repository.getSnapshot().ids).toEqual(ids.slice(0, MAX_PINNED_SESSIONS))
  })
})

describe('PinRepository mutations', () => {
  it('prepends a pin, publishes a new frozen snapshot, and writes the full value', () => {
    const storage = new MemoryStorage(JSON.stringify({ version: 1, ids: ['session-b'] }))
    const repository = new PinRepository(storage)
    const before = repository.getSnapshot()

    repository.pin('session-a')

    const after = repository.getSnapshot()
    expect(after).not.toBe(before)
    expect(after.ids).toEqual(['session-a', 'session-b'])
    expect(Object.isFrozen(after)).toBe(true)
    expect(Object.isFrozen(after.ids)).toBe(true)
    expect(repository.getSnapshot()).toBe(after)
    expect(storage.writes).toEqual([
      {
        key: PIN_STORAGE_KEY,
        value: JSON.stringify({ version: 1, ids: ['session-a', 'session-b'] }),
      },
    ])
  })

  it('moves an existing pin to the front without duplicating it', () => {
    const storage = new MemoryStorage(
      JSON.stringify({ version: 1, ids: ['session-a', 'session-b', 'session-c'] }),
    )
    const repository = new PinRepository(storage)

    repository.pin('session-b')

    expect(repository.getSnapshot().ids).toEqual(['session-b', 'session-a', 'session-c'])
  })

  it('unpins only the exact id', () => {
    const storage = new MemoryStorage(
      JSON.stringify({ version: 1, ids: ['session', 'session-long'] }),
    )
    const repository = new PinRepository(storage)

    repository.unpin('session')

    expect(repository.getSnapshot().ids).toEqual(['session-long'])
  })

  it('drops the oldest pin when a new pin exceeds the cap', () => {
    const ids = Array.from({ length: MAX_PINNED_SESSIONS }, (_, index) => `session-${index}`)
    const storage = new MemoryStorage(JSON.stringify({ version: 1, ids }))
    const repository = new PinRepository(storage)

    repository.pin('new-session')

    expect(repository.getSnapshot().ids).toEqual([
      'new-session',
      ...ids.slice(0, MAX_PINNED_SESSIONS - 1),
    ])
  })

  it('starts empty when storage throws while reading', () => {
    expect(() => new PinRepository(new ThrowingReadStorage())).not.toThrow()
    expect(new PinRepository(new ThrowingReadStorage()).getSnapshot().ids).toEqual([])
  })

  it('keeps the memory update and notification when storage throws while writing', () => {
    const storage = new ThrowingWriteStorage()
    const repository = new PinRepository(storage)
    let notifications = 0
    repository.subscribe(() => {
      notifications += 1
    })

    expect(() => repository.pin('session-a')).not.toThrow()

    expect(repository.getSnapshot().ids).toEqual(['session-a'])
    expect(notifications).toBe(1)
    expect(storage.writeAttempts).toHaveLength(1)
  })

  it('does not write or notify for invalid input or normalized no-op sequences', () => {
    const storage = new MemoryStorage(JSON.stringify({ version: 1, ids: ['session-a'] }))
    const repository = new PinRepository(storage)
    const snapshot = repository.getSnapshot()
    let notifications = 0
    const unsubscribe = repository.subscribe(() => {
      notifications += 1
    })
    const pinUnknown = repository.pin as unknown as (this: PinRepository, id: unknown) => void

    repository.pin('')
    repository.pin(' \t ')
    pinUnknown.call(repository, 42)
    repository.pin('session-a')
    repository.unpin('missing-session')

    expect(repository.getSnapshot()).toBe(snapshot)
    expect(storage.writes).toEqual([])
    expect(notifications).toBe(0)

    repository.pin('session-b')
    expect(notifications).toBe(1)

    unsubscribe()
    repository.unpin('session-b')
    expect(notifications).toBe(1)
  })
})

describe('PinRepository cross-tab reconciliation', () => {
  it('re-reads the same storage and accepts shims without a storage area', () => {
    const storage = new MemoryStorage(JSON.stringify({ version: 1, ids: ['session-a'] }))
    const repository = new PinRepository(storage)
    const eventSource = new MemoryStorageEventSource()
    let notifications = 0
    repository.subscribe(() => {
      notifications += 1
    })
    repository.connect(eventSource)

    storage.replaceValue(JSON.stringify({ version: 1, ids: ['session-b'] }))
    eventSource.emit({
      key: PIN_STORAGE_KEY,
      newValue: JSON.stringify({ version: 1, ids: ['session-b'] }),
      storageArea: storage,
    })
    storage.replaceValue(
      JSON.stringify({
        version: 1,
        ids: ['', 'session-c', 'session-c', '  opaque-id  '],
      }),
    )
    eventSource.emit({
      key: PIN_STORAGE_KEY,
      newValue: JSON.stringify({
        version: 1,
        ids: ['', 'session-c', 'session-c', '  opaque-id  '],
      }),
    })

    expect(repository.getSnapshot().ids).toEqual(['session-c', '  opaque-id  '])
    expect(notifications).toBe(2)
    expect(storage.writes).toEqual([])
  })

  it('does not regress to a delayed event payload after a newer local pin', () => {
    const staleValue = JSON.stringify({ version: 1, ids: ['session-old'] })
    const storage = new MemoryStorage(staleValue)
    const repository = new PinRepository(storage)
    const eventSource = new MemoryStorageEventSource()
    repository.connect(eventSource)

    repository.pin('session-new')
    const currentSnapshot = repository.getSnapshot()
    eventSource.emit({
      key: PIN_STORAGE_KEY,
      newValue: staleValue,
      storageArea: storage,
    })

    expect(repository.getSnapshot()).toBe(currentSnapshot)
    expect(repository.getSnapshot().ids).toEqual(['session-new', 'session-old'])
    expect(storage.reads).toEqual([PIN_STORAGE_KEY, PIN_STORAGE_KEY])
    expect(storage.writes).toHaveLength(1)
  })

  it('reconciles the owned key when localStorage is cleared', () => {
    const storage = new MemoryStorage(JSON.stringify({ version: 1, ids: ['session-a'] }))
    const repository = new PinRepository(storage)
    const eventSource = new MemoryStorageEventSource()
    repository.connect(eventSource)

    storage.replaceValue(null)
    eventSource.emit({
      key: null,
      newValue: null,
      storageArea: storage,
    })

    expect(repository.getSnapshot().ids).toEqual([])
    expect(storage.reads).toEqual([PIN_STORAGE_KEY, PIN_STORAGE_KEY])
    expect(storage.writes).toEqual([])
  })

  it('preserves memory when the reconciliation read fails', () => {
    const storage = new FailingReconciliationReadStorage(
      JSON.stringify({ version: 1, ids: ['session-current'] }),
    )
    const repository = new PinRepository(storage)
    const currentSnapshot = repository.getSnapshot()
    const eventSource = new MemoryStorageEventSource()
    let notifications = 0
    repository.subscribe(() => {
      notifications += 1
    })
    repository.connect(eventSource)

    expect(() =>
      eventSource.emit({
        key: PIN_STORAGE_KEY,
        newValue: JSON.stringify({ version: 1, ids: ['session-stale'] }),
        storageArea: storage,
      }),
    ).not.toThrow()

    expect(repository.getSnapshot()).toBe(currentSnapshot)
    expect(repository.getSnapshot().ids).toEqual(['session-current'])
    expect(notifications).toBe(0)
  })

  it('uses the event payload for a storage-less shim', () => {
    const repository = new PinRepository()
    const eventSource = new MemoryStorageEventSource()
    repository.connect(eventSource)

    eventSource.emit({
      key: PIN_STORAGE_KEY,
      newValue: JSON.stringify({ version: 1, ids: ['session-a'] }),
    })

    expect(repository.getSnapshot().ids).toEqual(['session-a'])
  })

  it('adopts an empty snapshot when the owned key is removed', () => {
    const storage = new MemoryStorage(JSON.stringify({ version: 1, ids: ['session-a'] }))
    const repository = new PinRepository(storage)
    const eventSource = new MemoryStorageEventSource()
    repository.connect(eventSource)

    storage.replaceValue(null)
    eventSource.emit({
      key: PIN_STORAGE_KEY,
      newValue: null,
      storageArea: null,
    })

    expect(repository.getSnapshot().ids).toEqual([])
    expect(storage.writes).toEqual([])
  })

  it('ignores unrelated keys and a different non-null storage area', () => {
    const storage = new MemoryStorage(JSON.stringify({ version: 1, ids: ['session-a'] }))
    const repository = new PinRepository(storage)
    const snapshot = repository.getSnapshot()
    const eventSource = new MemoryStorageEventSource()
    let notifications = 0
    repository.subscribe(() => {
      notifications += 1
    })
    repository.connect(eventSource)

    eventSource.emit({
      key: 'another.key',
      newValue: JSON.stringify({ version: 1, ids: ['session-b'] }),
      storageArea: storage,
    })
    eventSource.emit({
      key: PIN_STORAGE_KEY,
      newValue: JSON.stringify({ version: 1, ids: ['session-c'] }),
      storageArea: new MemoryStorage(),
    })

    expect(repository.getSnapshot()).toBe(snapshot)
    expect(notifications).toBe(0)
    expect(storage.writes).toEqual([])
  })

  it('sanitizes malformed external values to empty without writing back', () => {
    const storage = new MemoryStorage(JSON.stringify({ version: 1, ids: ['session-a'] }))
    const repository = new PinRepository(storage)
    const eventSource = new MemoryStorageEventSource()
    repository.connect(eventSource)

    storage.replaceValue('{')
    eventSource.emit({
      key: PIN_STORAGE_KEY,
      newValue: '{',
      storageArea: storage,
    })

    expect(repository.getSnapshot().ids).toEqual([])
    expect(storage.writes).toEqual([])
  })

  it('keeps the snapshot reference and skips notification for an equal normalized event', () => {
    const storage = new MemoryStorage(JSON.stringify({ version: 1, ids: ['session-a'] }))
    const repository = new PinRepository(storage)
    const snapshot = repository.getSnapshot()
    const eventSource = new MemoryStorageEventSource()
    let notifications = 0
    repository.subscribe(() => {
      notifications += 1
    })
    repository.connect(eventSource)

    storage.replaceValue(JSON.stringify({ version: 1, ids: ['session-a', '', 'session-a'] }))
    eventSource.emit({
      key: PIN_STORAGE_KEY,
      newValue: JSON.stringify({ version: 1, ids: ['session-a', '', 'session-a'] }),
    })

    expect(repository.getSnapshot()).toBe(snapshot)
    expect(notifications).toBe(0)
    expect(storage.writes).toEqual([])
  })

  it('removes the exact listener with an idempotent disposer', () => {
    const repository = new PinRepository()
    const eventSource = new MemoryStorageEventSource()

    const dispose = repository.connect(eventSource)

    expect(eventSource.addedListeners).toHaveLength(1)
    dispose()
    dispose()
    expect(eventSource.removedListeners).toEqual([eventSource.addedListeners[0]])

    eventSource.emit({
      key: PIN_STORAGE_KEY,
      newValue: JSON.stringify({ version: 1, ids: ['session-a'] }),
    })
    expect(repository.getSnapshot().ids).toEqual([])
  })
})
