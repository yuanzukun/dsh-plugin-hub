import { act, cleanup, render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { useSyncExternalStore } from 'react'
import { afterEach, describe, expect, it, vi } from 'vitest'

import type {
  SessionId,
  SessionListState,
  SessionSummary,
  WorkspaceListState,
} from '@deepseek-ai/dsh-client-runtime/client'
import type { SnapshotSelectorHook, TranslateNS } from '@deepseek-ai/dsh-client-ui-slots'

import {
  PinnedSessionsAction,
  type PinnedSessionsActionProps,
} from '../src/client/PinnedSessionsAction.tsx'
import { en, type SessionPinsKey } from '../src/client/locales.ts'
import { PinRepository, type PinnedSessionsSnapshot } from '../src/client/pin-repository.ts'

afterEach(cleanup)

const EMPTY_WORKSPACES: WorkspaceListState = {
  items: [],
  archivedSessionIds: [],
  state: 'idle',
  phase: 'ready',
  error: null,
  baselinesReady: true,
  recentWorkspaceId: undefined,
}

function summary(index: number): SessionSummary {
  return {
    id: `session-${String(index).padStart(3, '0')}` as SessionId,
    displayTitle: `Pinned session ${index}`,
    running: false,
    blank: false,
    updatedAt: index,
  }
}

function sessionsSnapshot(summaries: readonly SessionSummary[]): SessionListState {
  const byId: SessionListState['byId'] = {}
  for (const session of summaries) byId[session.id] = session

  return {
    ids: summaries.map(({ id }) => id),
    byId,
    current: undefined,
    phase: 'ready',
    subagentsByParent: {},
    jobsBySession: {},
    currentAddress: undefined,
  }
}

const t: TranslateNS<'sessionPins'> = (key, params) => {
  let value = en[key as SessionPinsKey]
  for (const [name, replacement] of Object.entries(params ?? {})) {
    value = value.replaceAll(`{${name}}`, () => String(replacement))
  }
  return value
}

function repositoryHook(repository: PinRepository): SnapshotSelectorHook<PinnedSessionsSnapshot> {
  const subscribe = (listener: () => void) => repository.subscribe(listener)
  return (selector) =>
    useSyncExternalStore(
      subscribe,
      () => selector(repository.getSnapshot()),
      () => selector(repository.getSnapshot()),
    )
}

function props(
  summaries: readonly SessionSummary[],
  repository: PinRepository,
): PinnedSessionsActionProps {
  const sessions = sessionsSnapshot(summaries)
  const useSessions: SnapshotSelectorHook<SessionListState> = (selector) => selector(sessions)
  const useWorkspaces: SnapshotSelectorHook<WorkspaceListState> = (selector) =>
    selector(EMPTY_WORKSPACES)

  return {
    wide: true,
    useSessions,
    useWorkspaces,
    usePinnedSessions: repositoryHook(repository),
    pinSession: vi.fn(() => true),
    unpinSession: (id) => {
      repository.unpin(id)
    },
    openSession: vi.fn(() => false),
    t,
  }
}

describe('PinnedSessionsAction with the installed rc.6 primitives', () => {
  it('keeps all 100 root pins scrollable, submenu-free, and keyboard reachable', async () => {
    const user = userEvent.setup()
    const summaries = Array.from({ length: 100 }, (_, index) => summary(index + 1))
    const repository = new PinRepository()
    for (const session of [...summaries].reverse()) repository.pin(session.id)

    render(
      <>
        <button type="button">Before pins</button>
        <PinnedSessionsAction {...props(summaries, repository)} />
        <button type="button">After pins</button>
      </>,
    )

    await user.tab()
    await user.tab()
    await user.keyboard('{Enter}')

    const pinRows = screen.getAllByRole('menuitem', { name: /^Pinned session \d+$/ })
    expect(pinRows).toHaveLength(100)
    expect(pinRows[0]).toHaveFocus()
    for (const row of pinRows) expect(row).not.toHaveAttribute('aria-haspopup')

    pinRows[98]!.focus()
    expect(pinRows[98]).toHaveFocus()
    await user.tab()
    expect(pinRows[99]).toHaveFocus()
    expect(pinRows[99]).toHaveAccessibleName('Pinned session 100')
  })

  it('owns focus across drill-down, external removal, Escape, and outside pointer close', async () => {
    const user = userEvent.setup()
    const summaries = [summary(1), summary(2), summary(3)]
    const repository = new PinRepository()
    for (const session of [...summaries].reverse()) repository.pin(session.id)

    render(
      <>
        <button type="button">Before pins</button>
        <PinnedSessionsAction {...props(summaries, repository)} />
        <button type="button">After pins</button>
      </>,
    )

    const before = screen.getByRole('button', { name: 'Before pins' })
    before.focus()
    expect(before).toHaveFocus()
    await user.tab()
    const trigger = screen.getByRole('button', { name: 'Pinned sessions (3)' })
    expect(trigger).toHaveFocus()
    await user.keyboard('{Enter}')
    expect(screen.getByRole('menuitem', { name: 'Pinned session 1' })).toHaveFocus()

    act(() => {
      repository.unpin('session-001')
    })
    const second = screen.getByRole('menuitem', { name: 'Pinned session 2' })
    expect(second).toHaveFocus()

    await user.keyboard('{Enter}')
    expect(screen.getByRole('menuitem', { name: 'Open' })).toHaveFocus()

    act(() => {
      repository.unpin('session-002')
    })
    expect(screen.getByRole('menuitem', { name: 'Pinned session 3' })).toHaveFocus()

    await user.keyboard('{Escape}')
    expect(trigger).toHaveFocus()

    await user.click(trigger)
    const outside = screen.getByRole('button', { name: 'After pins' })
    await user.click(outside)
    expect(outside).toHaveFocus()
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
  })

  it('focuses the real menu container when no enabled item remains', async () => {
    const user = userEvent.setup()
    const finalPin = summary(1)
    const repository = new PinRepository()
    repository.pin(finalPin.id)

    render(<PinnedSessionsAction {...props([finalPin], repository)} />)

    const trigger = screen.getByRole('button', { name: 'Pinned sessions (1)' })
    trigger.focus()
    await user.keyboard('{Enter}')
    expect(screen.getByRole('menuitem', { name: 'Pinned session 1' })).toHaveFocus()

    act(() => {
      repository.unpin(finalPin.id)
    })

    let menu = screen.getByRole('menu')
    expect(screen.getByText('No pinned sessions')).toBeVisible()
    expect(menu).toHaveAttribute('tabindex', '-1')
    expect(menu).toHaveFocus()

    await user.keyboard('{Escape}')
    expect(trigger).toHaveFocus()
    await user.keyboard('{Enter}')

    menu = screen.getByRole('menu')
    expect(menu).toHaveAttribute('tabindex', '-1')
    expect(menu).toHaveFocus()
  })
})
