import { afterEach, describe, expect, it, vi } from 'vitest'

import { PinnedSessionsAction } from '../src/client/PinnedSessionsAction.tsx'
import * as clientPlugin from '../src/client/index.ts'
import { en, NS, zh } from '../src/client/locales.ts'
import { PIN_STORAGE_KEY } from '../src/client/pin-repository.ts'
import {
  createClientHarness,
  sessionSummary,
  sessionsSnapshot,
  workspacesSnapshot,
  type ClientHarness,
  type HarnessSlotRegistration,
} from './harness.ts'

afterEach(() => {
  vi.unstubAllGlobals()
  vi.restoreAllMocks()
  window.localStorage.clear()
})

function registrationOf(harness: ClientHarness): HarnessSlotRegistration {
  expect(harness.slots.registrations).toHaveLength(1)
  return harness.slots.registrations[0]!
}

function faceOf(harness: ClientHarness) {
  const registration = registrationOf(harness)
  expect(registration.options.inject).toBeTypeOf('function')
  return registration.options.inject!()
}

describe('session pins client activation', () => {
  it('waits for the sidebar slot and owns one complete registration lifecycle', async () => {
    window.localStorage.setItem(
      PIN_STORAGE_KEY,
      JSON.stringify({ version: 1, ids: ['hydrated-session'] }),
    )
    const addEventListener = vi.spyOn(window, 'addEventListener')
    const removeEventListener = vi.spyOn(window, 'removeEventListener')
    const harness = await createClientHarness()

    try {
      expect(clientPlugin.inject).toStrictEqual(['slots', 'locale', 'sessions', 'workspaces'])

      const firstFiber = harness.activate(clientPlugin)
      await firstFiber

      expect(harness.locale.registrations).toStrictEqual([
        { namespace: NS, dictionaries: { zh, en } },
      ])
      expect(harness.slots.injectedKeys).toStrictEqual(['sidebar.footer.action'])
      expect(harness.slots.registrations).toHaveLength(0)
      expect(firstFiber.getEffects().map(({ label }) => label)).toEqual(
        expect.arrayContaining(['session-pins.locale', 'session-pins.storage']),
      )

      harness.slots.declareSidebarFooter()

      const firstRegistration = registrationOf(harness)
      expect(Object.keys(firstRegistration.options).sort()).toStrictEqual([
        'id',
        'inject',
        'locale',
        'name',
        'order',
      ])
      expect(firstRegistration.options).toMatchObject({
        name: 'sidebar.footer.action',
        id: 'session-pins',
        order: 20,
        locale: NS,
      })
      expect(firstRegistration.component).toBe(PinnedSessionsAction)

      const firstFace = faceOf(harness)
      const repeatedFace = faceOf(harness)
      expect(repeatedFace.hooks.pinnedSessions).toBe(firstFace.hooks.pinnedSessions)
      expect(repeatedFace.pinSession).toBe(firstFace.pinSession)
      expect(repeatedFace.unpinSession).toBe(firstFace.unpinSession)
      expect(repeatedFace.openSession).toBe(firstFace.openSession)
      expect(firstFace.hooks.pinnedSessions.getSnapshot().ids).toStrictEqual(['hydrated-session'])

      const storageListener = addEventListener.mock.calls.find(([type]) => type === 'storage')?.[1]
      expect(storageListener).toBeDefined()

      await firstFiber.dispose()

      expect(harness.locale.registrations).toHaveLength(0)
      expect(harness.slots.activeInjectionCount).toBe(0)
      expect(harness.slots.registrations).toHaveLength(0)
      expect(removeEventListener).toHaveBeenCalledWith('storage', storageListener)

      const secondFiber = harness.activate(clientPlugin)
      await secondFiber

      expect(harness.locale.registrations).toHaveLength(1)
      expect(harness.slots.registrations).toHaveLength(1)
      expect(harness.slots.registrationHistory).toHaveLength(2)
      expect(faceOf(harness).hooks.pinnedSessions).not.toBe(firstFace.hooks.pinnedSessions)

      await secondFiber.dispose()
      expect(harness.locale.registrations).toHaveLength(0)
      expect(harness.slots.registrations).toHaveLength(0)
    } finally {
      await harness.dispose()
    }
  })

  it('re-reads sessions and workspaces for pin, open, and stale render races', async () => {
    const ordinary = sessionSummary('ordinary-session')
    const archived = sessionSummary('archived-session')
    const blank = sessionSummary('blank-session', { blank: true })
    const subagent = sessionSummary('subagent-session', { origin: 'subagent' })
    const throwing = sessionSummary('throwing-session')
    const race = sessionSummary('race-session')
    const harness = await createClientHarness(
      sessionsSnapshot({
        summaries: [ordinary, archived, blank, subagent, throwing, race],
        listedIds: [ordinary.id, blank.id, subagent.id, throwing.id, race.id],
      }),
      workspacesSnapshot({ archivedSessionIds: [archived.id] }),
    )

    try {
      const fiber = harness.activate(clientPlugin)
      await fiber
      harness.slots.declareSidebarFooter()
      const face = faceOf(harness)
      const repository = face.hooks.pinnedSessions

      expect(face.pinSession('missing-session')).toBe(false)
      expect(face.pinSession(blank.id)).toBe(false)
      expect(face.pinSession(subagent.id)).toBe(false)
      expect(face.pinSession(ordinary.id)).toBe(true)
      expect(repository.getSnapshot().ids).toStrictEqual([ordinary.id])

      harness.sessions.list.set(sessionsSnapshot({ summaries: [race] }))
      harness.sessions.list.set(sessionsSnapshot())
      expect(face.pinSession(race.id)).toBe(false)
      expect(repository.getSnapshot().ids).toStrictEqual([ordinary.id])

      harness.sessions.list.set(
        sessionsSnapshot({
          summaries: [ordinary, archived, blank, subagent, throwing],
          listedIds: [ordinary.id, blank.id, subagent.id, throwing.id],
        }),
      )
      harness.sessions.failOpen(throwing.id)

      expect(face.openSession(ordinary.id)).toBe(true)
      expect(face.openSession(archived.id)).toBe(false)
      expect(face.openSession(blank.id)).toBe(true)
      expect(face.openSession('missing-session')).toBe(false)
      expect(face.openSession(subagent.id)).toBe(false)
      expect(face.openSession(throwing.id)).toBe(false)
      expect(harness.sessions.opened).toStrictEqual([ordinary.id, blank.id, throwing.id])

      harness.sessions.list.set(sessionsSnapshot({ summaries: [race] }))
      for (const nonActionable of [
        workspacesSnapshot({ baselinesReady: false }),
        workspacesSnapshot({ phase: 'pending' }),
        workspacesSnapshot({ state: 'loading' }),
        workspacesSnapshot({ state: 'error' }),
      ]) {
        harness.workspaces.list.set(nonActionable)
        expect(face.openSession(race.id)).toBe(false)
      }
      harness.workspaces.list.set(workspacesSnapshot({ archivedSessionIds: [race.id] }))
      expect(face.openSession(race.id)).toBe(false)
      expect(harness.sessions.opened).not.toContain(race.id)

      harness.workspaces.list.set(workspacesSnapshot())
      harness.sessions.list.set(sessionsSnapshot())
      expect(face.openSession(race.id)).toBe(false)

      const stale = sessionSummary('stale-persisted-id')
      harness.sessions.list.set(sessionsSnapshot({ summaries: [stale] }))
      expect(face.pinSession(stale.id)).toBe(true)
      harness.sessions.list.set(sessionsSnapshot())
      face.unpinSession('stale-persisted-id')
      expect(repository.getSnapshot().ids).toStrictEqual([ordinary.id])
    } finally {
      await harness.dispose()
    }
  })

  it('reconciles storage events until the plugin fiber is disposed', async () => {
    window.localStorage.setItem(
      PIN_STORAGE_KEY,
      JSON.stringify({ version: 1, ids: ['initial-session'] }),
    )
    const harness = await createClientHarness()

    try {
      const fiber = harness.activate(clientPlugin)
      await fiber
      harness.slots.declareSidebarFooter()
      const repository = faceOf(harness).hooks.pinnedSessions
      const notification = vi.fn()
      const unsubscribe = repository.subscribe(notification)

      window.localStorage.setItem(
        PIN_STORAGE_KEY,
        JSON.stringify({ version: 1, ids: ['external-session'] }),
      )
      window.dispatchEvent(
        new StorageEvent('storage', {
          key: PIN_STORAGE_KEY,
          newValue: window.localStorage.getItem(PIN_STORAGE_KEY),
          storageArea: window.localStorage,
        }),
      )

      expect(repository.getSnapshot().ids).toStrictEqual(['external-session'])
      expect(notification).toHaveBeenCalledTimes(1)

      await fiber.dispose()
      window.localStorage.setItem(
        PIN_STORAGE_KEY,
        JSON.stringify({ version: 1, ids: ['after-disposal'] }),
      )
      window.dispatchEvent(
        new StorageEvent('storage', {
          key: PIN_STORAGE_KEY,
          newValue: window.localStorage.getItem(PIN_STORAGE_KEY),
          storageArea: window.localStorage,
        }),
      )

      expect(repository.getSnapshot().ids).toStrictEqual(['external-session'])
      expect(notification).toHaveBeenCalledTimes(1)
      unsubscribe()
    } finally {
      await harness.dispose()
    }
  })

  it('stays memory-only when no browser window exists', async () => {
    const browserWindow = window
    vi.stubGlobal('window', undefined)
    const harness = await createClientHarness(
      sessionsSnapshot({ summaries: [sessionSummary('memory-session')] }),
    )

    try {
      const fiber = harness.activate(clientPlugin)
      await fiber
      expect(fiber.getEffects().map(({ label }) => label)).not.toContain('session-pins.storage')

      harness.slots.declareSidebarFooter()
      const face = faceOf(harness)
      expect(face.pinSession('memory-session')).toBe(true)
      expect(face.hooks.pinnedSessions.getSnapshot().ids).toStrictEqual(['memory-session'])
    } finally {
      await harness.dispose()
      vi.stubGlobal('window', browserWindow)
    }
  })

  it('contains a throwing localStorage getter without console noise', async () => {
    const descriptor = Object.getOwnPropertyDescriptor(window, 'localStorage')
    const consoleError = vi.spyOn(console, 'error').mockImplementation(() => {})
    const consoleWarn = vi.spyOn(console, 'warn').mockImplementation(() => {})
    Object.defineProperty(window, 'localStorage', {
      configurable: true,
      get() {
        throw new Error('localStorage is blocked')
      },
    })
    let harness: ClientHarness | undefined

    try {
      harness = await createClientHarness()
      const fiber = harness.activate(clientPlugin)
      await fiber
      harness.slots.declareSidebarFooter()
      const repository = faceOf(harness).hooks.pinnedSessions

      window.dispatchEvent(
        new StorageEvent('storage', {
          key: PIN_STORAGE_KEY,
          newValue: JSON.stringify({ version: 1, ids: ['event-session'] }),
        }),
      )
      expect(repository.getSnapshot().ids).toStrictEqual(['event-session'])
      expect(consoleError).not.toHaveBeenCalled()
      expect(consoleWarn).not.toHaveBeenCalled()

      await fiber.dispose()
      window.dispatchEvent(
        new StorageEvent('storage', {
          key: PIN_STORAGE_KEY,
          newValue: JSON.stringify({ version: 1, ids: ['after-disposal'] }),
        }),
      )
      expect(repository.getSnapshot().ids).toStrictEqual(['event-session'])
    } finally {
      if (harness !== undefined) await harness.dispose()
      if (descriptor === undefined) {
        Reflect.deleteProperty(window, 'localStorage')
      } else {
        Object.defineProperty(window, 'localStorage', descriptor)
      }
    }
  })
})
