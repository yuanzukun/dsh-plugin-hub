import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

import { describe, expect, it } from 'vitest'

const policyPath = fileURLToPath(new URL('../scripts/package-policy.mjs', import.meta.url))

function checkPackedPath(packedPath: string) {
  return spawnSync(process.execPath, [policyPath, packedPath], {
    encoding: 'utf8',
  })
}

describe('packed path policy', () => {
  it.each([
    'src/client/index.ts',
    'src/client/PinnedSessionsAction.tsx',
    'src/client/PinnedSessionsAction.module.css',
    'lib/client.js',
    'README.md',
  ])('accepts expected package content: %s', (packedPath) => {
    const result = checkPackedPath(packedPath)

    expect(result.status, result.stderr).toBe(0)
  })

  it.each([
    'src/id_rsa',
    'src/client.pem',
    'src/client.key',
    'src/.aws/credentials',
    'src/.npmrc',
    'src/browser/User Data/Default/Login Data',
    'src/browser-profile/Preferences.json',
    'src/auth-token.ts',
  ])('rejects credential or profile content: %s', (packedPath) => {
    const result = checkPackedPath(packedPath)

    expect(result.status).toBe(1)
    expect(result.stderr).toContain(`forbidden packed path: ${packedPath}`)
  })
})
