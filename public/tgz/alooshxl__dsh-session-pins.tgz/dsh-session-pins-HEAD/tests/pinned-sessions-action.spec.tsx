import { readFileSync } from 'node:fs'

import { act, cleanup, render, screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { useSyncExternalStore } from 'react'
import { afterEach, describe, expect, it, vi } from 'vitest'

import type {
  SessionId,
  SessionListState,
  SessionSummary,
  WorkspaceListState,
} from '@deepseek-ai/dsh-client-runtime/client'
import type { SnapshotSelectorHook, TranslateNS } from '@deepseek-ai/dsh-client-ui-slots'

import {
  PinnedSessionsAction,
  type PinnedSessionsActionProps,
} from '../src/client/PinnedSessionsAction.tsx'
import { PinRepository, type PinnedSessionsSnapshot } from '../src/client/pin-repository.ts'
import { en, NS, type SessionPinsKey, zh } from '../src/client/locales.ts'

afterEach(cleanup)

const EMPTY_WORKSPACES: WorkspaceListState = {
  items: [],
  archivedSessionIds: [],
  state: 'idle',
  phase: 'ready',
  error: null,
  baselinesReady: true,
  recentWorkspaceId: undefined,
}

function workspacesSnapshot(overrides: Partial<WorkspaceListState> = {}): WorkspaceListState {
  return {
    ...EMPTY_WORKSPACES,
    ...overrides,
  }
}

function sessionId(id: string): SessionId {
  return id as SessionId
}

function summary(
  id: string,
  displayTitle: string,
  overrides: Partial<Omit<SessionSummary, 'id' | 'displayTitle'>> = {},
): SessionSummary {
  return {
    id: sessionId(id),
    displayTitle,
    running: false,
    blank: false,
    updatedAt: 1,
    ...overrides,
  }
}

function sessionsSnapshot({
  summaries = [],
  listedIds = summaries.map(({ id }) => id),
  current,
}: {
  summaries?: readonly SessionSummary[]
  listedIds?: readonly (SessionId | string)[]
  current?: SessionId | string
} = {}): SessionListState {
  const byId: SessionListState['byId'] = {}
  for (const session of summaries) byId[session.id] = session

  return {
    ids: listedIds.map((id) => sessionId(id)),
    byId,
    current: current === undefined ? undefined : sessionId(current),
    phase: 'ready',
    subagentsByParent: {},
    jobsBySession: {},
    currentAddress: undefined,
  }
}

function translator(dictionary: Record<SessionPinsKey, string>): TranslateNS<typeof NS> {
  return (key, params) => {
    let value = dictionary[key as SessionPinsKey] ?? key
    for (const [name, replacement] of Object.entries(params ?? {})) {
      value = value.replaceAll(`{${name}}`, () => String(replacement))
    }
    return value
  }
}

class SnapshotStore<T> {
  readonly #listeners = new Set<() => void>()

  constructor(private snapshot: T) {}

  getSnapshot = () => this.snapshot

  subscribe = (listener: () => void) => {
    this.#listeners.add(listener)
    return () => {
      this.#listeners.delete(listener)
    }
  }

  setSnapshot(snapshot: T) {
    this.snapshot = snapshot
    for (const listener of this.#listeners) listener()
  }
}

interface RenderActionOptions {
  readonly wide?: boolean
  readonly pinnedIds?: readonly string[]
  readonly sessions?: SessionListState
  readonly locale?: 'en' | 'zh'
  readonly pinSession?: (id: string) => boolean
  readonly unpinSession?: (id: string) => void
  readonly openSession?: (id: string) => boolean
  readonly repository?: PinRepository
  readonly sessionsStore?: SnapshotStore<SessionListState>
  readonly workspaces?: WorkspaceListState
  readonly workspacesStore?: SnapshotStore<WorkspaceListState>
}

function actionProps(options: RenderActionOptions = {}): PinnedSessionsActionProps {
  const sessions = options.sessions ?? sessionsSnapshot()
  const pinnedSnapshot: PinnedSessionsSnapshot = {
    ids: options.pinnedIds ?? [],
  }
  const useSessions: SnapshotSelectorHook<SessionListState> =
    options.sessionsStore === undefined
      ? (selector) => selector(sessions)
      : (selector) =>
          useSyncExternalStore(
            options.sessionsStore?.subscribe ?? (() => () => {}),
            () => selector(options.sessionsStore?.getSnapshot() ?? sessions),
            () => selector(options.sessionsStore?.getSnapshot() ?? sessions),
          )
  const workspaces = options.workspaces ?? EMPTY_WORKSPACES
  const useWorkspaces: SnapshotSelectorHook<WorkspaceListState> =
    options.workspacesStore === undefined
      ? (selector) => selector(workspaces)
      : (selector) =>
          useSyncExternalStore(
            options.workspacesStore?.subscribe ?? (() => () => {}),
            () => selector(options.workspacesStore?.getSnapshot() ?? workspaces),
            () => selector(options.workspacesStore?.getSnapshot() ?? workspaces),
          )
  const subscribe = (listener: () => void) => options.repository?.subscribe(listener) ?? (() => {})
  const usePinnedSessions: SnapshotSelectorHook<PinnedSessionsSnapshot> =
    options.repository === undefined
      ? (selector) => selector(pinnedSnapshot)
      : (selector) =>
          useSyncExternalStore(
            subscribe,
            () => selector(options.repository?.getSnapshot() ?? pinnedSnapshot),
            () => selector(options.repository?.getSnapshot() ?? pinnedSnapshot),
          )
  const pinSession = options.pinSession ?? vi.fn(() => true)
  const unpinSession = options.unpinSession ?? vi.fn()
  const openSession = options.openSession ?? vi.fn(() => true)
  return {
    wide: options.wide ?? true,
    useSessions,
    useWorkspaces,
    usePinnedSessions,
    pinSession,
    unpinSession,
    openSession,
    t: translator(options.locale === 'zh' ? zh : en),
  } satisfies PinnedSessionsActionProps
}

function renderAction(options: RenderActionOptions = {}) {
  const props = actionProps(options)

  return {
    ...render(<PinnedSessionsAction {...props} />),
    pinSession: props.pinSession,
    unpinSession: props.unpinSession,
    openSession: props.openSession,
  }
}

describe('PinnedSessionsAction trigger', () => {
  it('renders the wide label, count, decorative icon, and controlled expanded state', async () => {
    const user = userEvent.setup()
    renderAction({ pinnedIds: ['session-a', 'session-b'] })

    const trigger = screen.getByRole('button', { name: 'Pinned sessions (2)' })
    expect(trigger).toHaveAttribute('aria-expanded', 'false')
    expect(trigger).toHaveTextContent('Pinned sessions')
    expect(trigger).toHaveTextContent('2')
    expect(trigger.querySelector('svg')).toHaveAttribute('aria-hidden', 'true')
    expect(trigger.querySelector('svg')).toHaveAttribute('focusable', 'false')

    await user.click(trigger)
    expect(trigger).toHaveAttribute('aria-expanded', 'true')
  })

  it('renders an icon-only rail trigger with the same accessible name and delayed tooltip', async () => {
    const user = userEvent.setup()
    renderAction({ wide: false, pinnedIds: ['session-a', 'session-b'] })

    const trigger = screen.getByRole('button', { name: 'Pinned sessions (2)' })
    expect(trigger).toHaveAttribute('aria-expanded', 'false')
    expect(trigger).toHaveTextContent('')

    await user.hover(trigger)
    expect(
      await screen.findByRole('tooltip', { name: 'Pinned sessions (2)' }, { timeout: 1_000 }),
    ).toBeVisible()

    await user.click(trigger)
    expect(screen.queryByRole('tooltip')).not.toBeInTheDocument()
  })

  it('uses the Chinese dictionary without changing the key set', async () => {
    expect(Object.keys(en).sort()).toEqual(Object.keys(zh).sort())

    const user = userEvent.setup()
    renderAction({ locale: 'zh', pinnedIds: ['session-a'] })

    const trigger = screen.getByRole('button', { name: '固定会话（1）' })
    await user.click(trigger)
    expect(within(screen.getByRole('menu')).getByText('固定会话')).toBeVisible()
    expect(screen.queryByText('暂无固定会话', { exact: false })).not.toBeInTheDocument()
  })

  it('uses the official solid hover and tertiary count tokens', () => {
    const css = readFileSync('src/client/PinnedSessionsAction.module.css', 'utf8')

    expect(css).toMatch(/\.trigger:hover\s*\{[^}]*--dsw-alias-interactive-bg-hover-solid[^}]*\}/)
    expect(css).toMatch(/\.count\s*\{[^}]*--dsw-alias-label-tertiary[^}]*\}/)
  })
})

describe('PinnedSessionsAction menu state', () => {
  it('shows the heading and empty state, toggles from the trigger, and closes on Escape', async () => {
    const user = userEvent.setup()
    renderAction()

    const trigger = screen.getByRole('button', { name: 'Pinned sessions (0)' })
    await user.click(trigger)
    const menu = screen.getByRole('menu')
    expect(menu).toBeVisible()
    expect(within(menu).getByText('Pinned sessions')).toBeVisible()
    expect(within(menu).getByText('No pinned sessions')).toBeVisible()

    await user.click(trigger)
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()

    await user.click(trigger)
    await user.keyboard('{Escape}')
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
    expect(trigger).toHaveAttribute('aria-expanded', 'false')
  })

  it('closes through the controlled onClose path after an outside pointer action', async () => {
    const user = userEvent.setup()
    renderAction()

    const trigger = screen.getByRole('button', { name: 'Pinned sessions (0)' })
    await user.click(trigger)
    expect(screen.getByRole('menu')).toBeVisible()

    await user.click(document.body)
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
    expect(trigger).toHaveAttribute('aria-expanded', 'false')
  })

  it('moves keyboard focus into the portaled menu and restores it on Escape only', async () => {
    const user = userEvent.setup()
    const pinned = summary('focus-session', 'Focus session')
    const props = actionProps({
      pinnedIds: [pinned.id],
      sessions: sessionsSnapshot({ summaries: [pinned] }),
    })

    render(
      <>
        <button type="button">Before pins</button>
        <PinnedSessionsAction {...props} />
        <button type="button">After pins</button>
      </>,
    )

    await user.tab()
    await user.tab()
    const trigger = screen.getByRole('button', { name: 'Pinned sessions (1)' })
    await user.keyboard('{Enter}')
    expect(screen.getByRole('menuitem', { name: 'Focus session' })).toHaveFocus()

    await user.keyboard('{Escape}')
    expect(trigger).toHaveFocus()

    await user.click(trigger)
    const outside = screen.getByRole('button', { name: 'After pins' })
    await user.click(outside)
    expect(outside).toHaveFocus()
  })

  it('focuses an empty menu container when its footer action is disabled', async () => {
    const user = userEvent.setup()
    renderAction()

    const trigger = screen.getByRole('button', { name: 'Pinned sessions (0)' })
    trigger.focus()
    await user.keyboard('{Enter}')

    const menu = screen.getByRole('menu')
    expect(within(menu).getByText('No pinned sessions')).toBeVisible()
    expect(menu).toHaveAttribute('tabindex', '-1')
    expect(menu).toHaveFocus()
  })

  it('remeasures from the trigger ref when the menu drills down and back', async () => {
    const user = userEvent.setup({ skipHover: true })
    const pinned = summary('anchor-session', 'Anchor session')
    renderAction({
      pinnedIds: [pinned.id],
      sessions: sessionsSnapshot({ summaries: [pinned] }),
    })
    const trigger = screen.getByRole('button', { name: 'Pinned sessions (1)' })
    const getBoundingClientRect = vi.spyOn(trigger, 'getBoundingClientRect')

    await user.click(trigger)
    await user.click(screen.getByRole('menuitem', { name: 'Anchor session' }))
    await user.click(screen.getByRole('menuitem', { name: 'Back' }))

    expect(getBoundingClientRect).toHaveBeenCalledTimes(3)
  })

  it('remeasures when same-current-id eligibility changes the footer layout', async () => {
    const user = userEvent.setup()
    const blankCurrent = summary('current-session', 'Current session', { blank: true })
    const sessionsStore = new SnapshotStore(
      sessionsSnapshot({
        summaries: [blankCurrent],
        current: blankCurrent.id,
      }),
    )
    renderAction({ sessionsStore })
    const trigger = screen.getByRole('button', { name: 'Pinned sessions (0)' })
    const getBoundingClientRect = vi.spyOn(trigger, 'getBoundingClientRect')

    await user.click(trigger)
    expect(getBoundingClientRect).toHaveBeenCalledTimes(1)

    act(() => {
      sessionsStore.setSnapshot(
        sessionsSnapshot({
          summaries: [summary('current-session', 'Current session')],
          current: blankCurrent.id,
        }),
      )
    })

    expect(screen.getByRole('menuitem', { name: 'Pin current session' })).toBeEnabled()
    expect(getBoundingClientRect).toHaveBeenCalledTimes(2)
  })

  it('pins an eligible ordinary current session and keeps the menu usable', async () => {
    const user = userEvent.setup()
    const current = summary('current-session', 'Current session')
    const pinSession = vi.fn((_id: string) => true)
    renderAction({
      sessions: sessionsSnapshot({ summaries: [current], current: current.id }),
      pinSession,
    })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (0)' }))
    await user.click(screen.getByRole('menuitem', { name: 'Pin current session' }))

    expect(pinSession).toHaveBeenCalledWith('current-session')
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
  })

  it('keeps the menu open when current-session pin eligibility changes concurrently', async () => {
    const user = userEvent.setup()
    const current = summary('current-session', 'Current session')
    const pinSession = vi.fn(() => false)
    renderAction({
      sessions: sessionsSnapshot({ summaries: [current], current: current.id }),
      pinSession,
    })

    const trigger = screen.getByRole('button', { name: 'Pinned sessions (0)' })
    await user.click(trigger)
    await user.click(screen.getByRole('menuitem', { name: 'Pin current session' }))

    expect(pinSession).toHaveBeenCalledWith('current-session')
    expect(screen.getByRole('menu')).toBeVisible()
    expect(trigger).toHaveAttribute('aria-expanded', 'true')
    expect(screen.queryByRole('alert')).not.toBeInTheDocument()
  })

  it.each([
    {
      state: 'no current session',
      sessions: sessionsSnapshot(),
      explanation: 'Select a session to pin it',
    },
    {
      state: 'blank current session',
      sessions: sessionsSnapshot({
        summaries: [summary('blank-session', 'Blank session', { blank: true })],
        current: 'blank-session',
      }),
      explanation: 'Blank sessions cannot be pinned',
    },
    {
      state: 'subagent current session',
      sessions: sessionsSnapshot({
        summaries: [summary('subagent-session', 'Subagent session', { origin: 'subagent' })],
        current: 'subagent-session',
      }),
      explanation: 'Subagent sessions cannot be pinned',
    },
  ])('disables pinning for a $state with its explanation', async ({ sessions, explanation }) => {
    const user = userEvent.setup()
    const pinSession = vi.fn((_id: string) => true)
    renderAction({ sessions, pinSession })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (0)' }))
    const action = screen.getByRole('menuitem', { name: new RegExp(explanation) })

    expect(action).toBeDisabled()
    expect(action).toHaveTextContent('Pin current session')
    expect(action).toHaveTextContent(explanation)
    expect(pinSession).not.toHaveBeenCalled()
  })

  it('allows an ineligible current session to be unpinned for recovery', async () => {
    const user = userEvent.setup()
    const current = summary('subagent-session', 'Subagent session', {
      blank: true,
      origin: 'subagent',
    })
    const unpinSession = vi.fn()
    renderAction({
      pinnedIds: [current.id],
      sessions: sessionsSnapshot({ summaries: [current], current: current.id }),
      unpinSession,
    })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (1)' }))
    await user.click(screen.getByRole('menuitem', { name: 'Unpin current session' }))

    expect(unpinSession).toHaveBeenCalledWith('subagent-session')
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
  })

  it('keeps the current-session action identity stable across external pin state changes', async () => {
    const user = userEvent.setup()
    const current = summary('current-session', 'Current session')
    const repository = new PinRepository()
    renderAction({
      repository,
      sessions: sessionsSnapshot({ summaries: [current], current: current.id }),
      unpinSession: (id) => {
        repository.unpin(id)
      },
    })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (0)' }))
    const pinCurrent = screen.getByRole('menuitem', { name: 'Pin current session' })

    act(() => {
      repository.pin(current.id)
    })

    expect(screen.getByRole('menuitem', { name: 'Unpin current session' })).toBe(pinCurrent)
  })

  it('pins the current session from a pinned-session detail view', async () => {
    const user = userEvent.setup({ skipHover: true })
    const pinned = summary('pinned-session', 'Pinned session')
    const current = summary('current-session', 'Current session')
    const pinSession = vi.fn(() => true)
    renderAction({
      pinnedIds: [pinned.id],
      sessions: sessionsSnapshot({
        summaries: [pinned, current],
        current: current.id,
      }),
      pinSession,
    })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (1)' }))
    await user.click(screen.getByRole('menuitem', { name: 'Pinned session' }))
    await user.click(screen.getByRole('menuitem', { name: 'Pin current session' }))

    expect(pinSession).toHaveBeenCalledWith('current-session')
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
  })

  it('unpins the current session from another pinned-session detail view', async () => {
    const user = userEvent.setup({ skipHover: true })
    const pinned = summary('pinned-session', 'Pinned session')
    const current = summary('current-session', 'Current session')
    const unpinSession = vi.fn()
    renderAction({
      pinnedIds: [pinned.id, current.id],
      sessions: sessionsSnapshot({
        summaries: [pinned, current],
        current: current.id,
      }),
      unpinSession,
    })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (2)' }))
    await user.click(screen.getByRole('menuitem', { name: 'Pinned session' }))
    await user.click(screen.getByRole('menuitem', { name: 'Unpin current session' }))

    expect(unpinSession).toHaveBeenCalledWith('current-session')
    expect(unpinSession).not.toHaveBeenCalledWith('pinned-session')
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
  })
})

describe('PinnedSessionsAction persisted entries', () => {
  it('keeps a remaining session row and its exact action identity stable after an earlier pin is removed', async () => {
    const user = userEvent.setup({ skipHover: true })
    const earlier = summary('earlier:pin/open?', 'Earlier session')
    const remaining = summary('remaining:pin/unpin?', 'Remaining session')
    const unpinSession = vi.fn()
    const initialProps = actionProps({
      pinnedIds: [earlier.id, remaining.id],
      sessions: sessionsSnapshot({ summaries: [earlier, remaining] }),
      unpinSession,
    })
    const view = render(<PinnedSessionsAction {...initialProps} />)

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (2)' }))
    const originalRemainingRow = screen.getByRole('menuitem', { name: 'Remaining session' })

    view.rerender(
      <PinnedSessionsAction
        {...actionProps({
          pinnedIds: [remaining.id],
          sessions: sessionsSnapshot({ summaries: [remaining] }),
          unpinSession,
        })}
      />,
    )

    const remainingRow = screen.getByRole('menuitem', { name: 'Remaining session' })
    expect(remainingRow).toBe(originalRemainingRow)
    await user.click(remainingRow)
    await user.click(screen.getByRole('menuitem', { name: 'Unpin' }))
    expect(unpinSession).toHaveBeenCalledWith('remaining:pin/unpin?')
  })

  it('uses submenu-free root rows and a same-menu detail view with Back', async () => {
    const user = userEvent.setup({ skipHover: true })
    const pinned = summary('detail-session', 'Detail session')
    renderAction({
      pinnedIds: [pinned.id],
      sessions: sessionsSnapshot({ summaries: [pinned] }),
    })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (1)' }))
    const row = screen.getByRole('menuitem', { name: 'Detail session' })
    expect(row).not.toHaveAttribute('aria-haspopup')

    await user.click(row)
    expect(screen.getByRole('menuitem', { name: 'Open' })).toBeVisible()
    expect(screen.getByRole('menuitem', { name: 'Unpin' })).toBeVisible()
    const back = screen.getByRole('menuitem', { name: 'Back' })
    expect(back).toBeVisible()

    await user.click(back)
    expect(screen.getByRole('menuitem', { name: 'Detail session' })).toBeVisible()
    expect(screen.queryByRole('menuitem', { name: 'Open' })).not.toBeInTheDocument()
  })

  it.each([
    {
      condition: 'pending',
      workspaces: workspacesSnapshot({ baselinesReady: false, phase: 'pending' }),
    },
    {
      condition: 'loading',
      workspaces: workspacesSnapshot({ state: 'loading' }),
    },
    {
      condition: 'error',
      workspaces: workspacesSnapshot({ state: 'error' }),
    },
  ])('fails closed while workspace availability is $condition', async ({ workspaces }) => {
    const user = userEvent.setup({ skipHover: true })
    const pinned = summary('guarded-session', 'Guarded session')
    renderAction({
      pinnedIds: [pinned.id],
      sessions: sessionsSnapshot({ summaries: [pinned] }),
      workspaces,
    })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (1)' }))
    await user.click(screen.getByRole('menuitem', { name: 'Guarded session' }))

    expect(screen.queryByRole('menuitem', { name: 'Open' })).not.toBeInTheDocument()
    expect(
      within(screen.getByRole('menu')).getByText('Session availability is not ready yet.'),
    ).toBeVisible()
    expect(screen.getByRole('status')).toHaveTextContent('Session availability is not ready yet.')
    expect(screen.getByRole('menuitem', { name: 'Unpin' })).toBeVisible()
    expect(screen.getByRole('menuitem', { name: 'Back' })).toBeVisible()
  })

  it('adds Open when workspace availability becomes actionable', async () => {
    const user = userEvent.setup({ skipHover: true })
    const pinned = summary('becomes-ready', 'Becomes ready')
    const workspacesStore = new SnapshotStore(
      workspacesSnapshot({ baselinesReady: false, phase: 'pending' }),
    )
    renderAction({
      pinnedIds: [pinned.id],
      sessions: sessionsSnapshot({ summaries: [pinned] }),
      workspacesStore,
    })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (1)' }))
    await user.click(screen.getByRole('menuitem', { name: 'Becomes ready' }))
    expect(screen.queryByRole('menuitem', { name: 'Open' })).not.toBeInTheDocument()
    expect(
      within(screen.getByRole('menu')).getByText('Session availability is not ready yet.'),
    ).toBeVisible()

    act(() => {
      workspacesStore.setSnapshot(workspacesSnapshot())
    })

    expect(screen.getByRole('menuitem', { name: 'Open' })).toBeVisible()
    expect(screen.queryByText('Session availability is not ready yet.')).not.toBeInTheDocument()
  })

  it('keeps persisted order and live archived titles while removing opaque stale ids', async () => {
    const user = userEvent.setup({ skipHover: true })
    const archivedTitle =
      'Archived session with a title long enough to require visual truncation in the footer menu'
    const archived = summary('archived-session', archivedTitle)
    const listed = summary('listed-session', 'Live listed title')
    const staleId = 'stale:$&:$$:opaque'
    const openSession = vi.fn((_id: string) => true)
    const unpinSession = vi.fn()
    renderAction({
      pinnedIds: [archived.id, listed.id, staleId],
      sessions: sessionsSnapshot({
        summaries: [listed, archived],
        listedIds: [listed.id],
      }),
      workspaces: workspacesSnapshot({ archivedSessionIds: [archived.id] }),
      openSession,
      unpinSession,
    })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (3)' }))
    const menuItems = within(screen.getByRole('menu')).getAllByRole('menuitem')
    expect(menuItems.slice(0, 3).map((item) => item.textContent)).toEqual([
      archivedTitle,
      'Live listed title',
      `Unavailable: ${staleId}`,
    ])
    for (const item of menuItems.slice(0, 3)) expect(item).not.toHaveAttribute('aria-haspopup')
    expect(screen.getByTitle(archivedTitle)).toHaveAccessibleName(archivedTitle)

    await user.click(screen.getByRole('menuitem', { name: archivedTitle }))
    expect(
      within(screen.getByRole('menu')).getByText(
        'DeepSeek Harness 0.1.0-rc.6 cannot reopen archived sessions.',
      ),
    ).toBeVisible()
    expect(screen.getByRole('status')).toHaveTextContent(
      'DeepSeek Harness 0.1.0-rc.6 cannot reopen archived sessions.',
    )
    expect(screen.queryByRole('menuitem', { name: 'Open' })).not.toBeInTheDocument()
    expect(screen.getByRole('menuitem', { name: 'Unpin' })).toBeVisible()
    expect(screen.getByRole('menuitem', { name: 'Back' })).toBeVisible()
    expect(openSession).not.toHaveBeenCalled()

    await user.click(screen.getByRole('menuitem', { name: 'Back' }))
    await user.click(screen.getByRole('menuitem', { name: `Unavailable: ${staleId}` }))
    expect(screen.queryByRole('menuitem', { name: 'Open' })).not.toBeInTheDocument()
    expect(screen.getByRole('menuitem', { name: 'Back' })).toBeVisible()
    await user.click(screen.getByRole('menuitem', { name: 'Unpin' }))
    expect(unpinSession).toHaveBeenCalledWith(staleId)
    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
  })

  it('localizes the archived-session limitation in Chinese', async () => {
    const user = userEvent.setup({ skipHover: true })
    const archived = summary('archived-zh', '已归档会话')
    renderAction({
      locale: 'zh',
      pinnedIds: [archived.id],
      sessions: sessionsSnapshot({ summaries: [archived] }),
      workspaces: workspacesSnapshot({ archivedSessionIds: [archived.id] }),
    })

    await user.click(screen.getByRole('button', { name: '固定会话（1）' }))
    await user.click(screen.getByRole('menuitem', { name: '已归档会话' }))

    expect(
      within(screen.getByRole('menu')).getByText(
        'DeepSeek Harness 0.1.0-rc.6 无法重新打开已归档会话。',
      ),
    ).toBeVisible()
  })

  it('keeps focus on a connected action when a ready session becomes archived', async () => {
    const user = userEvent.setup()
    const pinned = summary('archive-race', 'Archive race')
    const workspacesStore = new SnapshotStore(workspacesSnapshot())
    renderAction({
      pinnedIds: [pinned.id],
      sessions: sessionsSnapshot({ summaries: [pinned] }),
      workspacesStore,
    })

    const trigger = screen.getByRole('button', { name: 'Pinned sessions (1)' })
    trigger.focus()
    await user.keyboard('{Enter}')
    await user.keyboard('{Enter}')
    expect(screen.getByRole('menuitem', { name: 'Open' })).toHaveFocus()

    act(() => {
      workspacesStore.setSnapshot(workspacesSnapshot({ archivedSessionIds: [pinned.id] }))
    })

    expect(screen.queryByRole('menuitem', { name: 'Open' })).not.toBeInTheDocument()
    expect(screen.getByRole('menuitem', { name: 'Unpin' })).toHaveFocus()
    expect(screen.getByRole('status')).toHaveTextContent(
      'DeepSeek Harness 0.1.0-rc.6 cannot reopen archived sessions.',
    )
    expect(screen.getByRole('menuitem', { name: 'Back' })).toBeVisible()
  })

  it('closes after a successful open', async () => {
    const user = userEvent.setup({ skipHover: true })
    const pinned = summary('pinned-session', 'Pinned session')
    renderAction({
      pinnedIds: [pinned.id],
      sessions: sessionsSnapshot({ summaries: [pinned] }),
      openSession: vi.fn((_id: string) => true),
    })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (1)' }))
    await user.click(screen.getByRole('menuitem', { name: 'Pinned session' }))
    await user.click(screen.getByRole('menuitem', { name: 'Open' }))

    expect(screen.queryByRole('menu')).not.toBeInTheDocument()
  })

  it('keeps a failed open visible, announces the error, and clears it on recovery', async () => {
    const user = userEvent.setup({ skipHover: true })
    const pinned = summary('pinned-session', 'Pinned session')
    const unpinSession = vi.fn()
    renderAction({
      pinnedIds: [pinned.id],
      sessions: sessionsSnapshot({ summaries: [pinned] }),
      openSession: vi.fn((_id: string) => false),
      unpinSession,
    })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (1)' }))
    await user.click(screen.getByRole('menuitem', { name: 'Pinned session' }))
    await user.click(screen.getByRole('menuitem', { name: 'Open' }))

    expect(screen.getAllByRole('menu')[0]).toBeVisible()
    const firstAlert = screen.getByRole('alert')
    expect(firstAlert).toHaveTextContent('Could not open the pinned session')

    await user.click(screen.getByRole('menuitem', { name: 'Open' }))
    const repeatedAlert = screen.getByRole('alert')
    expect(repeatedAlert).not.toBe(firstAlert)
    expect(repeatedAlert).toHaveTextContent('Could not open the pinned session')

    await user.click(screen.getByRole('menuitem', { name: 'Unpin' }))
    expect(unpinSession).toHaveBeenCalledWith('pinned-session')
    expect(screen.queryByRole('alert')).not.toBeInTheDocument()
  })

  it('clears a failed open announcement when navigating Back', async () => {
    const user = userEvent.setup({ skipHover: true })
    const pinned = summary('failed-session', 'Failed session')
    renderAction({
      pinnedIds: [pinned.id],
      sessions: sessionsSnapshot({ summaries: [pinned] }),
      openSession: vi.fn(() => false),
    })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (1)' }))
    await user.click(screen.getByRole('menuitem', { name: 'Failed session' }))
    await user.click(screen.getByRole('menuitem', { name: 'Open' }))
    expect(screen.getByRole('alert')).toBeVisible()

    await user.click(screen.getByRole('menuitem', { name: 'Back' }))

    expect(screen.queryByRole('alert')).not.toBeInTheDocument()
    expect(screen.getByRole('menuitem', { name: 'Failed session' })).toBeVisible()
  })

  it('does not carry a failed open announcement into a different pin detail', async () => {
    const user = userEvent.setup({ skipHover: true })
    const failed = summary('failed-session', 'Failed session')
    const different = summary('different-session', 'Different session')
    renderAction({
      pinnedIds: [failed.id, different.id],
      sessions: sessionsSnapshot({ summaries: [failed, different] }),
      openSession: vi.fn(() => false),
    })

    await user.click(screen.getByRole('button', { name: 'Pinned sessions (2)' }))
    await user.click(screen.getByRole('menuitem', { name: 'Failed session' }))
    await user.click(screen.getByRole('menuitem', { name: 'Open' }))
    expect(screen.getByRole('alert')).toBeVisible()

    await user.click(screen.getByRole('menuitem', { name: 'Back' }))
    await user.click(screen.getByRole('menuitem', { name: 'Different session' }))

    expect(screen.queryByRole('alert')).not.toBeInTheDocument()
    expect(screen.getByText('Different session')).toBeVisible()
  })

  it('clears a failed announcement and returns to a focused root fallback after external removal', async () => {
    const user = userEvent.setup({ skipHover: true })
    const failed = summary('failed-session', 'Failed session')
    const fallback = summary('fallback-session', 'Fallback session')
    const repository = new PinRepository()
    repository.pin(fallback.id)
    repository.pin(failed.id)
    renderAction({
      repository,
      sessions: sessionsSnapshot({ summaries: [failed, fallback] }),
      openSession: vi.fn(() => false),
      unpinSession: (id) => {
        repository.unpin(id)
      },
    })

    const trigger = screen.getByRole('button', { name: 'Pinned sessions (2)' })
    trigger.focus()
    await user.keyboard('{Enter}')
    await user.keyboard('{Enter}')
    await user.keyboard('{Enter}')
    expect(screen.getByRole('alert')).toBeVisible()

    act(() => {
      repository.unpin(failed.id)
    })

    expect(screen.queryByRole('alert')).not.toBeInTheDocument()
    expect(screen.getByRole('menuitem', { name: 'Fallback session' })).toHaveFocus()
    expect(screen.queryByRole('menuitem', { name: 'Back' })).not.toBeInTheDocument()
  })

  it('focuses a connected enabled fallback when an active root row disappears externally', async () => {
    const user = userEvent.setup()
    const first = summary('first-session', 'First session')
    const second = summary('second-session', 'Second session')
    const repository = new PinRepository()
    repository.pin(second.id)
    repository.pin(first.id)
    renderAction({
      repository,
      sessions: sessionsSnapshot({ summaries: [first, second] }),
    })

    const trigger = screen.getByRole('button', { name: 'Pinned sessions (2)' })
    trigger.focus()
    await user.keyboard('{Enter}')
    expect(screen.getByRole('menuitem', { name: 'First session' })).toHaveFocus()

    act(() => {
      repository.unpin(first.id)
    })

    expect(screen.getByRole('menuitem', { name: 'Second session' })).toHaveFocus()
  })

  it('focuses the menu container when the final focused pin disappears externally', async () => {
    const user = userEvent.setup()
    const finalPin = summary('final-session', 'Final session')
    const repository = new PinRepository()
    repository.pin(finalPin.id)
    renderAction({
      repository,
      sessions: sessionsSnapshot({ summaries: [finalPin] }),
    })

    const trigger = screen.getByRole('button', { name: 'Pinned sessions (1)' })
    trigger.focus()
    await user.keyboard('{Enter}')
    expect(screen.getByRole('menuitem', { name: 'Final session' })).toHaveFocus()

    act(() => {
      repository.unpin(finalPin.id)
    })

    const menu = screen.getByRole('menu')
    expect(within(menu).getByText('No pinned sessions')).toBeVisible()
    expect(menu).toHaveAttribute('tabindex', '-1')
    expect(menu).toHaveFocus()
  })

  it('recovers focus once after detail removal without stealing later outside focus', async () => {
    const user = userEvent.setup()
    const selected = summary('selected-session', 'Selected session')
    const fallback = summary('fallback-session', 'Fallback session')
    const repository = new PinRepository()
    repository.pin(fallback.id)
    repository.pin(selected.id)
    const props = actionProps({
      repository,
      sessions: sessionsSnapshot({ summaries: [selected, fallback] }),
    })
    render(
      <>
        <PinnedSessionsAction {...props} />
        <button type="button">Adjacent control</button>
      </>,
    )

    const trigger = screen.getByRole('button', { name: 'Pinned sessions (2)' })
    trigger.focus()
    await user.keyboard('{Enter}')
    await user.keyboard('{Enter}')
    expect(screen.getByRole('menuitem', { name: 'Open' })).toHaveFocus()

    const focus = vi.spyOn(HTMLElement.prototype, 'focus')
    act(() => {
      repository.unpin(selected.id)
    })
    const fallbackFocusCount = () =>
      focus.mock.instances.filter(
        (element) =>
          element instanceof HTMLElement &&
          element.getAttribute('role') === 'menuitem' &&
          element.textContent === 'Fallback session',
      ).length

    expect(fallbackFocusCount()).toBe(1)
    const adjacent = screen.getByRole('button', { name: 'Adjacent control' })
    adjacent.focus()
    act(() => {
      repository.pin('unrelated-session')
    })

    expect(adjacent).toHaveFocus()
    expect(fallbackFocusCount()).toBe(1)
  })

  it('moves focus into root and detail actions for keyboard navigation', async () => {
    const user = userEvent.setup()
    const pinned = summary('keyboard-session', 'Keyboard session')
    const openSession = vi.fn((_id: string) => false)
    renderAction({
      pinnedIds: [pinned.id],
      sessions: sessionsSnapshot({ summaries: [pinned] }),
      openSession,
    })

    await user.tab()
    const trigger = screen.getByRole('button', { name: 'Pinned sessions (1)' })
    expect(trigger).toHaveFocus()

    await user.keyboard('{Enter}')
    const row = screen.getByRole('menuitem', { name: 'Keyboard session' })
    expect(row).toHaveFocus()
    await user.keyboard('{Enter}')
    const open = screen.getByRole('menuitem', { name: 'Open' })
    expect(open).toHaveFocus()
    await user.keyboard('{Enter}')
    expect(openSession).toHaveBeenCalledWith('keyboard-session')
  })
})
