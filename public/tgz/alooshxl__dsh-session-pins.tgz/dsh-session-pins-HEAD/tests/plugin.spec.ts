import { readFileSync } from 'node:fs'

import { Context } from '@deepseek-ai/cordis'
import Loader from '@deepseek-ai/cordis-plugin-loader'
import InvariantRegistry from '@deepseek-ai/dsh-invariants'
import { describe, expect, it } from 'vitest'
import { parse } from 'yaml'

import * as nodePlugin from '../src/index.ts'
import * as invariantPlugin from '../src/invariant.ts'

const PACKAGE_NAME = '@dsh-external/dsh-session-pins'

interface PackageManifest {
  readonly name: string
  readonly exports: unknown
  readonly peerDependencies: unknown
  readonly dsh: unknown
}

describe('session pins package plugins', () => {
  it('preserves the named Node namespace through a real Loader and Cordis lifecycle', async () => {
    const context = new Context()
    const loaderFiber = context.plugin(Loader, { baseUrl: import.meta.url })
    await loaderFiber

    try {
      expect(Object.keys(nodePlugin).sort()).toStrictEqual(['apply', 'name'])
      expect('default' in nodePlugin).toBe(false)

      const unwrapped = context.loader.unwrapExports(nodePlugin)
      expect(unwrapped).toBe(nodePlugin)
      expect(unwrapped.name).toBe('dsh-session-pins')
      expect(unwrapped.apply).toBe(nodePlugin.apply)

      const pluginFiber = context.plugin(unwrapped)
      await pluginFiber
      expect(pluginFiber.name).toBe('dsh-session-pins')

      await pluginFiber.dispose()
      expect(pluginFiber.uid).toBeNull()
    } finally {
      await loaderFiber.dispose()
    }
  })

  it('registers and releases the exact invariant package through InvariantRegistry', async () => {
    const context = new Context()
    const registryFiber = context.plugin(InvariantRegistry, { enabled: true })
    await registryFiber

    try {
      expect(Object.keys(invariantPlugin).sort()).toStrictEqual(['apply', 'inject', 'name'])
      expect('default' in invariantPlugin).toBe(false)
      expect(invariantPlugin.inject).toStrictEqual(['invariants'])
      expect(invariantPlugin.name).toBe('dsh-session-pins-invariant')

      const invariantFiber = context.plugin(invariantPlugin)
      await invariantFiber
      expect(() => context.invariants.register(PACKAGE_NAME, () => {})).toThrow(
        `package "${PACKAGE_NAME}" is already registered`,
      )

      await invariantFiber.dispose()

      const release = context.invariants.register(PACKAGE_NAME, () => {})
      await release()
    } finally {
      await registryFiber.dispose()
    }

    expect(readFileSync('src/invariant.ts', 'utf8')).toContain(
      'No runtime invariant: browser-local pure-consumer plugin owns no host events or mutable cross-plugin state.',
    )
  })
})

describe('session pins package composition', () => {
  it('inserts exactly one bundle row aligned with the package and plugin names', () => {
    const manifest = JSON.parse(readFileSync('package.json', 'utf8')) as PackageManifest
    const patch = parse(readFileSync('cordis.patch.yml', 'utf8'))

    expect(patch).toStrictEqual([
      {
        insert: [
          {
            id: nodePlugin.name,
            name: manifest.name,
          },
        ],
      },
    ])
    expect(manifest.name).toBe(PACKAGE_NAME)
  })

  it('exposes only the supported package and client discovery contract', () => {
    const manifest = JSON.parse(readFileSync('package.json', 'utf8')) as PackageManifest

    expect(manifest.exports).toStrictEqual({
      '.': {
        types: './lib/types/index.d.ts',
        default: './lib/index.js',
      },
      './client': {
        types: './lib/types/client/index.d.ts',
        default: './lib/client.js',
      },
      './invariant': {
        types: './lib/types/invariant.d.ts',
        default: './lib/invariant.js',
      },
      './src/*': './src/*',
      './cordis.patch.yml': './cordis.patch.yml',
      './package.json': './package.json',
    })
    expect(manifest.peerDependencies).toStrictEqual({
      '@deepseek-ai/cordis': '^4.0.1',
    })
    expect(manifest.dsh).toStrictEqual({
      bundle: {
        patch: './cordis.patch.yml',
      },
      client: {
        inject: [
          '@deepseek-ai/dsh-client-runtime',
          '@deepseek-ai/dsh-client-locale',
          '@deepseek-ai/dsh-client-ui-sidebar',
        ],
        platform: 'web',
      },
    })
  })
})
