import { Context, Service, type Fiber, type Plugin } from '@deepseek-ai/cordis'
import type {
  ClientContext,
  SessionId,
  SessionListState,
  SessionSummary,
  WorkspaceListState,
} from '@deepseek-ai/dsh-client-runtime/client'

import type { SessionPinsFace } from '../src/client/PinnedSessionsAction.tsx'

type Disposer = () => void

interface SlotInjection {
  readonly callback: () => Disposer
  active: Disposer | undefined
}

export interface HarnessSlotRegistration {
  readonly options: {
    readonly name: string
    readonly id: string
    readonly order?: number
    readonly locale?: string
    readonly inject?: () => SessionPinsFace
  }
  readonly component: unknown
}

export class HarnessSlots extends Service {
  readonly injectedKeys: string[] = []
  readonly registrationHistory: HarnessSlotRegistration[] = []
  readonly registrations: HarnessSlotRegistration[] = []

  private declared = false
  private readonly injections = new Set<SlotInjection>()

  constructor(ctx: Context) {
    super(ctx, 'slots')
  }

  inject(key: string, callback: () => Disposer): Disposer {
    const effect = this.ctx.effect(
      () => {
        const injection: SlotInjection = { callback, active: undefined }
        this.injectedKeys.push(key)
        this.injections.add(injection)
        if (this.declared) this.activate(injection)

        return () => {
          this.deactivate(injection)
          this.injections.delete(injection)
        }
      },
      `slots.inject(${JSON.stringify(key)})`,
    )

    return () => {
      void effect()
    }
  }

  register(options: HarnessSlotRegistration['options'], component: unknown): Disposer {
    const registration: HarnessSlotRegistration = { options, component }
    const effect = this.ctx.effect(() => {
      this.registrations.push(registration)
      this.registrationHistory.push(registration)

      return () => {
        const index = this.registrations.indexOf(registration)
        if (index >= 0) this.registrations.splice(index, 1)
      }
    }, 'slots.register()')

    return () => {
      void effect()
    }
  }

  declareSidebarFooter(): void {
    if (this.declared) return

    this.declared = true
    for (const injection of this.injections) this.activate(injection)
  }

  collapseSidebarFooter(): void {
    if (!this.declared) return

    this.declared = false
    for (const injection of this.injections) this.deactivate(injection)
  }

  get activeInjectionCount(): number {
    return this.injections.size
  }

  private activate(injection: SlotInjection): void {
    if (injection.active !== undefined) return
    injection.active = injection.callback()
  }

  private deactivate(injection: SlotInjection): void {
    const dispose = injection.active
    injection.active = undefined
    dispose?.()
  }
}

export interface HarnessLocaleRegistration {
  readonly namespace: string
  readonly dictionaries: unknown
}

export class HarnessLocale extends Service {
  readonly registrations: HarnessLocaleRegistration[] = []

  constructor(ctx: Context) {
    super(ctx, 'locale')
  }

  register(namespace: string, dictionaries: unknown): Disposer {
    const registration: HarnessLocaleRegistration = { namespace, dictionaries }
    this.registrations.push(registration)
    let active = true

    return () => {
      if (!active) return
      active = false
      const index = this.registrations.indexOf(registration)
      if (index >= 0) this.registrations.splice(index, 1)
    }
  }
}

export class MutableSnapshot<T> {
  private readonly listeners = new Set<() => void>()

  constructor(private snapshot: T) {}

  getSnapshot = (): T => this.snapshot

  subscribe = (listener: () => void): Disposer => {
    this.listeners.add(listener)
    return () => {
      this.listeners.delete(listener)
    }
  }

  set(snapshot: T): void {
    this.snapshot = snapshot
    for (const listener of this.listeners) listener()
  }
}

export class HarnessSessions extends Service {
  readonly list: MutableSnapshot<SessionListState>
  readonly opened: SessionId[] = []

  private readonly openFailures = new Map<string, unknown>()

  constructor(ctx: Context, initialSnapshot: SessionListState) {
    super(ctx, 'sessions')
    this.list = new MutableSnapshot(initialSnapshot)
  }

  open(id: SessionId): void {
    this.opened.push(id)
    const failure = this.openFailures.get(id)
    if (failure !== undefined) throw failure
  }

  failOpen(id: string, failure: unknown = new Error(`failed to open ${id}`)): void {
    this.openFailures.set(id, failure)
  }
}

export class HarnessWorkspaces extends Service {
  readonly list: MutableSnapshot<WorkspaceListState>

  constructor(ctx: Context, initialSnapshot: WorkspaceListState) {
    super(ctx, 'workspaces')
    this.list = new MutableSnapshot(initialSnapshot)
  }
}

export interface ClientHarness {
  readonly context: ClientContext
  readonly locale: HarnessLocale
  readonly sessions: HarnessSessions
  readonly slots: HarnessSlots
  readonly workspaces: HarnessWorkspaces
  activate(plugin: Plugin): Fiber & PromiseLike<Fiber>
  dispose(): Promise<void>
}

export async function createClientHarness(
  initialSnapshot: SessionListState = sessionsSnapshot(),
  initialWorkspaces: WorkspaceListState = workspacesSnapshot(),
): Promise<ClientHarness> {
  const context = new Context()
  let locale: HarnessLocale | undefined
  let sessions: HarnessSessions | undefined
  let slots: HarnessSlots | undefined
  let workspaces: HarnessWorkspaces | undefined
  const providerFiber = context.plugin((ctx) => {
    locale = new HarnessLocale(ctx)
    sessions = new HarnessSessions(ctx, initialSnapshot)
    slots = new HarnessSlots(ctx)
    workspaces = new HarnessWorkspaces(ctx, initialWorkspaces)
  })
  await providerFiber

  if (
    locale === undefined ||
    sessions === undefined ||
    slots === undefined ||
    workspaces === undefined
  ) {
    throw new Error('client harness services did not activate')
  }

  const clientFibers: Fiber[] = []

  return {
    context,
    locale,
    sessions,
    slots,
    workspaces,
    activate(plugin) {
      const fiber = context.plugin(plugin)
      clientFibers.push(fiber)
      return fiber
    },
    async dispose() {
      for (const fiber of clientFibers.reverse()) {
        if (fiber.uid !== null) await fiber.dispose()
      }
      await providerFiber.dispose()
    },
  }
}

export function sessionId(id: string): SessionId {
  return id as SessionId
}

export function sessionSummary(
  id: string,
  overrides: Partial<Omit<SessionSummary, 'id' | 'displayTitle'>> = {},
): SessionSummary {
  return {
    id: sessionId(id),
    displayTitle: id,
    running: false,
    blank: false,
    updatedAt: 1,
    ...overrides,
  }
}

export function sessionsSnapshot({
  summaries = [],
  listedIds = summaries.map(({ id }) => id),
  current,
}: {
  readonly summaries?: readonly SessionSummary[]
  readonly listedIds?: readonly (SessionId | string)[]
  readonly current?: SessionId | string
} = {}): SessionListState {
  const byId: SessionListState['byId'] = {}
  for (const summary of summaries) byId[summary.id] = summary

  return {
    ids: listedIds.map(sessionId),
    byId,
    current: current === undefined ? undefined : sessionId(current),
    phase: 'ready',
    subagentsByParent: {},
    jobsBySession: {},
    currentAddress: undefined,
  }
}

export function workspacesSnapshot(
  overrides: Partial<WorkspaceListState> = {},
): WorkspaceListState {
  return {
    items: [],
    archivedSessionIds: [],
    state: 'idle',
    phase: 'ready',
    error: null,
    baselinesReady: true,
    recentWorkspaceId: undefined,
    ...overrides,
  }
}
