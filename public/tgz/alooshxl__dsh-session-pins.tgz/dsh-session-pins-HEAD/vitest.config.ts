import { fileURLToPath } from 'node:url'

import { defineConfig } from 'vitest/config'

const primitivesStub = fileURLToPath(
  new URL('./tests/platform/primitives-stub.tsx', import.meta.url),
)

export default defineConfig({
  test: {
    pool: 'forks',
    restoreMocks: true,
    projects: [
      {
        extends: true,
        test: {
          name: 'node',
          include: ['tests/**/*.spec.ts'],
          exclude: ['tests/client-activation.spec.ts'],
          environment: 'node',
        },
      },
      {
        extends: true,
        test: {
          name: 'jsdom-stub',
          include: ['tests/**/*.spec.tsx', 'tests/client-activation.spec.ts'],
          exclude: ['tests/**/*.integration.spec.tsx'],
          environment: 'jsdom',
          setupFiles: ['./tests/setup.ts'],
          alias: {
            '@deepseek-ai/dsh-client-ui-primitives': primitivesStub,
          },
        },
      },
      {
        extends: true,
        test: {
          name: 'jsdom-real-primitives',
          include: ['tests/**/*.integration.spec.tsx'],
          environment: 'jsdom',
          setupFiles: ['./tests/setup.ts'],
          server: {
            deps: {
              inline: true,
            },
          },
        },
      },
    ],
  },
})
