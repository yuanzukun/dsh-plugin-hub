# dsh-coding-plans

[English](README.md) | 中文

在 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 里用 **多种 coding plan 订阅**，通过 **原生 OAuth / Coding 端点 LLM adapter** 接入——**不依赖 CLIProxyAPI 子进程**。

> 社区插件，与 OpenAI / Anthropic / Google / Moonshot / DeepSeek 均无隶属关系。订阅后端非官方公开 API，可能随时失效，也可能违反厂商 ToS，风险自担。

## 状态

| Provider | 状态 | 认证方式 |
| --- | --- | --- |
| ChatGPT / Codex | **可用** | Settings → **使用 ChatGPT 登录**（浏览器 OAuth / device code） |
| Kimi Code | **可用** | Settings → **使用 Kimi 登录**（设备码）或 Advanced API Key |
| 火山方舟 Coding/Agent Plan | **可用** | Settings → 选套餐 + 粘贴控制台 API Key |
| 智谱 GLM / MiniMax / 百炼 / 腾讯云 | 占位 | 欢迎 PR — [docs/provider-porting.md](docs/provider-porting.md) |
| Gemini / Antigravity | 占位 | 欢迎 PR |
| Claude Max / Pro | **压轴（最后）** | 占位 |
| Copilot / Cursor | 后置 | — |

### Codex 已知限制

- 「已连接」只表示 `$DSH_HOME/coding-plans/codex-auth.json` 已有凭据。
- **免费 ChatGPT 账号通常不能跑 Codex 推理**；需要付费 coding / Codex 套餐。
- 额度条依赖访问 `chatgpt.com`；网络超时不等于未登录。

## 安装

```sh
dsh plugin --profile web add dsh-coding-plans
# 或本地开发：
dsh plugin --profile web add link:/absolute/path/to/dsh-coding-plans
dsh web
```

或：

```sh
dsh plugin --profile web add github:pengzhou267-ai/dsh-coding-plans
```

完整步骤见 [INSTALL.md](INSTALL.md)。

## 怎么用

1. **Settings → Coding Plans**
2. Codex：**使用 ChatGPT 登录**；Kimi：**使用 Kimi 登录**；方舟：选 Coding/Agent Plan 并保存 API Key
3. Models 选 **`coding-plans-codex`** / **`coding-plans-kimi`** / **`coding-plans-ark`**（Agent 为 **`coding-plans-ark-agent`**）

CLI：

```sh
dsh-coding-plans login codex
dsh-coding-plans login kimi
dsh-coding-plans login ark --api-key <key> --plan coding
dsh-coding-plans login ark --api-key <key> --plan agent
dsh-coding-plans status ark
dsh-coding-plans list
```

## 架构

对照成熟开源（pi-ai、CLIProxyAPI kimi/codex、dsh-codex 等）移植协议，用 `ctx.llm.registerAdapter` 挂到 dsh。详见 [docs/design.md](docs/design.md)。

## License

Apache-2.0
