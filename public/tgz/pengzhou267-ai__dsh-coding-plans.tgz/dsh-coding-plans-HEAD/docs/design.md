# Design notes

## Goal

A **multi coding-plan hub** for DeepSeek Harness: one installable `dsh-coding-plans`
bundle, browser OAuth (no API keys), native `ctx.llm.registerAdapter` routes.

## Why not wrap CLIProxyAPI?

CLIProxyAPI is the most mature multi-subscription proxy, but embedding it as a
subprocess ties the plugin to a Go binary lifecycle and shrinks the PR surface.
This project **ports protocols** (OAuth client, streaming) into TypeScript and
plugs into dsh’s LLM seam directly.

## Codex MVP

| Layer | Choice |
| --- | --- |
| OAuth + wire protocol | `@earendil-works/pi-ai` `openaiCodexProvider()` |
| dsh streaming / tools / reasoning | `@deepseek-ai/dsh-llm-pi-ai` `PiAiAdapter` |
| Credential path | `$DSH_HOME/coding-plans/codex-auth.json` |
| dsh route id | `coding-plans-codex` |
| Settings | `/plugins/dsh-coding-plans/codex/auth/{status,login,logout}` |

Closest community references: [dsh-codex](https://github.com/Yan-Zero/dsh-codex),
CLIProxyAPI Codex OAuth. Differences from `dsh-codex`:

- Hub layout under `packages/*` for additional providers
- Dedicated `coding-plans/` credential directory
- Route name `coding-plans-codex` (can coexist with `openai-codex` from other plugins)
- No search / imagegen tools in MVP (out of scope)

## Stubs

`provider-claude` and `provider-gemini` export metadata only and throw if
adapters are constructed. See [provider-porting.md](./provider-porting.md).

## Risks

Unofficial subscription backends can change or conflict with vendor ToS. The
plugin is community-maintained, not affiliated with OpenAI, Anthropic, Google,
or DeepSeek.
