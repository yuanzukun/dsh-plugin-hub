# Provider porting guide

This hub is **runtime-independent of CLIProxyAPI**. New providers should still be
**ported from mature open-source implementations**, not invented from scratch.

## Layout

| Path | Role |
| --- | --- |
| `packages/core` | Credential store under `$DSH_HOME/coding-plans/` |
| `packages/provider-codex` | **Ready** — ChatGPT / Codex OAuth + `PiAiAdapter` |
| `packages/provider-kimi` | **Ready** — Kimi Code device flow / API key + coding headers |
| `packages/provider-glm` | Stub — 智谱 GLM Coding Plan |
| `packages/provider-minimax` | Stub — MiniMax Token/Coding Plan |
| `packages/provider-bailian` | Stub — 阿里云百炼 Coding Plan (often Key + Base URL) |
| `packages/provider-tencent` | Stub — 腾讯云 Coding/Token Plan |
| `packages/provider-ark` | **Ready** — 火山方舟 Coding/Agent Plan（控制台 API Key + 专用 Base URL） |
| `packages/provider-gemini` | Stub — Gemini CLI / Antigravity |
| `packages/provider-claude` | Stub — **deferred last** — Claude Max/Pro |
| `src/index.ts` | Cordis `apply` that registers ready adapters |
| `src/client` | Settings → Coding Plans UI |

## Roadmap order

1. Codex (done) + Kimi (done) + Ark (done)
2. Domestic A stubs → full ports: GLM → MiniMax → Bailian / Tencent
3. Gemini
4. Copilot
5. **Claude last**
6. Cursor only as experimental / maybe never

## Checklist for a new provider

1. **Pick a reference** (cite commit SHA in your PR):
   - Kimi pattern (already done): CLIProxyAPI `internal/auth/kimi` + Coding API `User-Agent: KimiCLI/…`
   - Codex pattern: `@earendil-works/pi-ai` `openai-codex` + [dsh-codex](https://github.com/Yan-Zero/dsh-codex)
   - Claude: [CLIProxyAPI](https://github.com/router-for-me/CLIProxyAPI) Claude OAuth + Messages SSE
   - Gemini: CLIProxyAPI `gemini` / `antigravity`
   - Copilot: LiteLLM `github_copilot/` or [copilot-api](https://github.com/ericc-ch/copilot-api)
   - Domestic cloud plans: often **dedicated API Key + Base URL** (not ChatGPT-style browser OAuth)
2. Implement `login` / `logout` / `status` using `CodingPlanCredentialStore` with a dedicated filename.
3. Implement `createXxxAdapter()` returning a `LlmAdapter` (prefer wrapping pi-ai or subclassing via `@deepseek-ai/dsh-llm`).
4. Register the route in `src/index.ts` as `coding-plans-<id>`.
5. Add Settings card + loopback-only HTTP routes under `/plugins/dsh-coding-plans/<id>/auth/*`.
6. Extend CLI `dsh-coding-plans login <id>`.
7. Document ToS / breakage risk in README.
8. Add mock fixture tests (no live OAuth in CI).

## Auth shape notes (domestic A)

| Provider | Typical auth |
| --- | --- |
| Kimi Code | Device flow OAuth **or** Coding Plan API key; coding endpoint requires agent headers |
| Volcengine Ark | Console API key + plan-specific base: Coding `/api/coding/v3`, Agent `/api/plan/v3` (never pay-as-you-go `/api/v3`) |
| GLM / MiniMax | Vendor coding-plan key or limited OAuth — confirm against current console docs |
| Bailian / Tencent / Ark | Usually Key + OpenAI-compatible Base URL issued by the plan |

## Credential isolation

Do **not** read or write:

- `~/.codex/auth.json`
- `~/.claude` OAuth stores
- other CLI credential files

Two clients refreshing the same token will invalidate each other.

License: Apache-2.0. Cite upstream paths and licenses in every porting PR.
