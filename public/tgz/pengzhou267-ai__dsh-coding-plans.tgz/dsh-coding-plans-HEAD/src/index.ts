/**
 * dsh-coding-plans host entry: registers ready coding-plan LLM adapters.
 * @module dsh-coding-plans
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import {
  createCodexAdapter,
  createCodexCredentialStore,
  registerCodexAuthRoutes,
  codexProviderMeta,
} from '../packages/provider-codex/src/index.ts'
import {
  createKimiAdapter,
  createKimiCredentialStore,
  registerKimiAuthRoutes,
  kimiProviderMeta,
} from '../packages/provider-kimi/src/index.ts'
import {
  createArkAdapter,
  createArkCredentialStore,
  registerArkAuthRoutes,
  arkProviderMeta,
} from '../packages/provider-ark/src/index.ts'
import { claudeProviderMeta } from '../packages/provider-claude/src/index.ts'
import { geminiProviderMeta } from '../packages/provider-gemini/src/index.ts'
import { glmProviderMeta } from '../packages/provider-glm/src/index.ts'
import { minimaxProviderMeta } from '../packages/provider-minimax/src/index.ts'
import { bailianProviderMeta } from '../packages/provider-bailian/src/index.ts'
import { tencentProviderMeta } from '../packages/provider-tencent/src/index.ts'
import type { CodingPlanProviderMeta } from '../packages/core/src/index.ts'

export const name = 'llm-coding-plans'
export const inject = ['llm']

export interface Config {
  /** When false, skip registering the Codex adapter (default true). */
  enableCodex?: boolean
  /** When false, skip registering the Kimi adapter (default true). */
  enableKimi?: boolean
  /** When false, skip registering the Ark adapter (default true). */
  enableArk?: boolean
}

export const Config: z<Config> = z.object({
  enableCodex: z.boolean().default(true),
  enableKimi: z.boolean().default(true),
  enableArk: z.boolean().default(true),
})

/** Catalog of hub providers for docs / CLI status. */
export const PROVIDER_CATALOG: readonly CodingPlanProviderMeta[] = [
  codexProviderMeta,
  kimiProviderMeta,
  arkProviderMeta,
  glmProviderMeta,
  minimaxProviderMeta,
  bailianProviderMeta,
  tencentProviderMeta,
  geminiProviderMeta,
  claudeProviderMeta,
]

export function apply(ctx: Context, config: Config): void {
  if (config.enableCodex !== false) {
    const credentials = createCodexCredentialStore()
    ctx.llm.registerAdapter(['coding-plans-codex'], createCodexAdapter(credentials))
    ctx.inject(['webServer'], webCtx => {
      registerCodexAuthRoutes(webCtx, credentials)
    })
  }
  if (config.enableKimi !== false) {
    const credentials = createKimiCredentialStore()
    ctx.llm.registerAdapter(['coding-plans-kimi'], createKimiAdapter(credentials))
    ctx.inject(['webServer'], webCtx => {
      registerKimiAuthRoutes(webCtx, credentials)
    })
  }
  if (config.enableArk !== false) {
    const credentials = createArkCredentialStore()
    ctx.llm.registerAdapter(
      ['coding-plans-ark', 'coding-plans-ark-agent'],
      createArkAdapter(credentials),
    )
    ctx.inject(['webServer'], webCtx => {
      registerArkAuthRoutes(webCtx, credentials)
    })
  }
}

export {
  loginCodex,
  logoutCodex,
  codexAuthStatus,
  codexAuthPath,
  CODEX_DSH_ROUTE,
  CODEX_PI_PROVIDER,
} from '../packages/provider-codex/src/index.ts'
export type { CodexAuthStatus } from '../packages/provider-codex/src/index.ts'
export {
  loginKimiDevice,
  logoutKimi,
  kimiAuthStatus,
  kimiAuthPath,
  saveKimiApiKey,
  createKimiCredentialStore,
  KIMI_DSH_ROUTE,
  KIMI_PI_PROVIDER,
} from '../packages/provider-kimi/src/index.ts'
export type { KimiAuthStatus } from '../packages/provider-kimi/src/index.ts'
export {
  logoutArk,
  arkAuthStatus,
  arkAuthPath,
  saveArkApiKey,
  createArkCredentialStore,
  ARK_DSH_ROUTE,
  ARK_DSH_ROUTE_AGENT,
  ARK_PI_PROVIDER,
} from '../packages/provider-ark/src/index.ts'
export type { ArkAuthStatus, ArkPlanKind } from '../packages/provider-ark/src/index.ts'
export { codingPlansDir, CodingPlanCredentialStore, safeAuthMessage } from '../packages/core/src/index.ts'
