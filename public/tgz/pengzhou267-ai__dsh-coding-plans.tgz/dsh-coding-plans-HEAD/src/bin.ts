#!/usr/bin/env node
/** Standalone credential CLI: dsh-coding-plans <login|logout|status> [provider] */

import { spawn } from 'node:child_process'
import { realpathSync } from 'node:fs'
import { createInterface } from 'node:readline/promises'
import { fileURLToPath } from 'node:url'
import type { AuthEvent, AuthPrompt } from '@earendil-works/pi-ai'
import {
  PROVIDER_CATALOG,
  loginCodex,
  logoutCodex,
  codexAuthStatus,
  codexAuthPath,
  loginKimiDevice,
  logoutKimi,
  kimiAuthStatus,
  kimiAuthPath,
  saveKimiApiKey,
  createKimiCredentialStore,
  logoutArk,
  arkAuthStatus,
  arkAuthPath,
  saveArkApiKey,
  createArkCredentialStore,
} from './index.ts'
import { isArkPlanKind } from '../packages/provider-ark/src/constants.ts'
import type { ArkPlanKind } from '../packages/provider-ark/src/constants.ts'

type Action = 'login' | 'logout' | 'status' | 'list'
const READY = new Set(['codex', 'kimi', 'ark'])

function openBrowser(rawUrl: string): void {
  const url = new URL(rawUrl)
  if (url.protocol !== 'https:') throw new Error(`refusing to open non-HTTPS authorization URL from ${url.host}`)
  const command = process.platform === 'win32'
    ? { file: 'rundll32.exe', args: ['url.dll,FileProtocolHandler', url.href] }
    : process.platform === 'darwin'
      ? { file: 'open', args: [url.href] }
      : { file: 'xdg-open', args: [url.href] }
  try {
    const child = spawn(command.file, command.args, {
      detached: true,
      stdio: 'ignore',
      windowsHide: true,
    })
    child.on('error', () => {})
    child.unref()
  } catch {
    // printed URL remains the fallback
  }
}

function safeMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error)
  return message
    .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/gu, '[redacted token]')
    .replace(/(\b(?:code|token|refresh_token|access_token)=)[^&\s]+/giu, '$1[redacted]')
}

function notify(event: AuthEvent, useBrowser: boolean): void {
  switch (event.type) {
    case 'auth_url':
      process.stdout.write(`Open this URL to sign in:\n${event.url}\n`)
      if (event.instructions !== undefined) process.stdout.write(`${event.instructions}\n`)
      if (useBrowser) openBrowser(event.url)
      break
    case 'device_code':
      process.stdout.write(`Open this URL to sign in:\n${event.verificationUri}\nEnter code: ${event.userCode}\n`)
      if (useBrowser) openBrowser(event.verificationUri)
      break
    case 'info':
    case 'progress':
      process.stdout.write(`${event.message}\n`)
      break
    default:
      event satisfies never
  }
}

async function answerPrompt(
  prompt: AuthPrompt,
  deviceCode: boolean,
  question: (text: string, options: { signal?: AbortSignal }) => Promise<string>,
): Promise<string> {
  if (prompt.type === 'select') {
    const wanted = deviceCode ? 'device_code' : 'browser'
    if (!prompt.options.some(option => option.id === wanted)) {
      throw new Error(`login did not offer the requested ${wanted} method`)
    }
    return wanted
  }
  const suffix = prompt.placeholder === undefined ? '' : ` (${prompt.placeholder})`
  return question(`${prompt.message}${suffix}: `, {
    ...prompt.signal === undefined ? {} : { signal: prompt.signal },
  })
}

function printHelp(): void {
  process.stdout.write([
    'Usage: dsh-coding-plans <login|logout|status|list> [provider] [options]',
    '',
    '  login [codex|kimi|ark]  sign in (Codex OAuth / Kimi device / Ark API key)',
    '  logout [codex|kimi|ark] remove stored credentials',
    '  status [codex|kimi|ark] report non-secret credential state',
    '  list                   list providers and readiness',
    '  --device-code          Codex: prefer device-code method',
    '  --api-key <key>        Kimi/Ark: store API key',
    '  --plan coding|agent    Ark: which Volcengine plan endpoint to use (default coding)',
    '',
  ].join('\n'))
}

export async function run(argv: readonly string[]): Promise<number> {
  if (argv.length === 0 || argv[0] === '--help' || argv[0] === '-h') {
    printHelp()
    return 0
  }
  const [rawAction, ...rest] = argv
  if (rawAction !== 'login' && rawAction !== 'logout' && rawAction !== 'status' && rawAction !== 'list') {
    process.stderr.write(`dsh-coding-plans: expected login|logout|status|list; got ${JSON.stringify(rawAction)}\n`)
    return 1
  }
  const action: Action = rawAction
  if (action === 'list') {
    for (const p of PROVIDER_CATALOG) {
      process.stdout.write(`${p.id.padEnd(10)} ${p.status.padEnd(12)} ${p.displayName}\n`)
    }
    return 0
  }

  const flags = rest.filter(a => a.startsWith('--'))
  const positional = rest.filter(a => !a.startsWith('--'))
  const provider = positional[0] ?? 'codex'
  const apiKeyFlagIndex = flags.findIndex(flag => flag === '--api-key' || flag.startsWith('--api-key='))
  let apiKey: string | undefined
  let arkPlan: ArkPlanKind = 'coding'
  if (apiKeyFlagIndex >= 0) {
    const flag = flags[apiKeyFlagIndex]!
    if (flag.startsWith('--api-key=')) apiKey = flag.slice('--api-key='.length)
    else {
      apiKey = process.env['KIMI_CODING_API_KEY'] ?? process.env['ARK_API_KEY']
    }
  }
  for (let i = 0; i < rest.length; i++) {
    if (rest[i] === '--api-key' && rest[i + 1] !== undefined && !rest[i + 1]!.startsWith('--')) {
      apiKey = rest[i + 1]
    }
    if (rest[i] === '--plan' && rest[i + 1] !== undefined && isArkPlanKind(rest[i + 1]!)) {
      arkPlan = rest[i + 1] as ArkPlanKind
    }
    if (rest[i]?.startsWith('--plan=') && isArkPlanKind(rest[i]!.slice('--plan='.length))) {
      arkPlan = rest[i]!.slice('--plan='.length) as ArkPlanKind
    }
  }

  const unknown = flags.filter(flag =>
    flag !== '--device-code'
    && flag !== '--api-key'
    && !flag.startsWith('--api-key=')
    && flag !== '--plan'
    && !flag.startsWith('--plan='))
  if (unknown.length > 0 || (flags.includes('--device-code') && action !== 'login')) {
    process.stderr.write(`dsh-coding-plans: invalid options for ${action}: ${flags.join(' ')}\n`)
    return 1
  }
  if (!READY.has(provider)) {
    const meta = PROVIDER_CATALOG.find(p => p.id === provider)
    if (meta === undefined) {
      process.stderr.write(`dsh-coding-plans: unknown provider ${JSON.stringify(provider)}\n`)
      return 1
    }
    process.stderr.write(`dsh-coding-plans: provider "${provider}" is ${meta.status}; ready: codex, kimi, ark\n`)
    return 1
  }

  try {
    if (provider === 'ark') {
      switch (action) {
        case 'status': {
          const status = await arkAuthStatus()
          if (!status.authenticated) {
            process.stdout.write('coding-plans ark: signed out\n')
            return 1
          }
          process.stdout.write(`coding-plans ark: signed in (plan=${status.plan ?? 'coding'})\n`)
          return 0
        }
        case 'logout':
          await logoutArk()
          process.stdout.write(`coding-plans ark: signed out; removed ${arkAuthPath()}\n`)
          return 0
        case 'login': {
          if (apiKey === undefined || apiKey.length === 0) {
            process.stderr.write('dsh-coding-plans: ark login requires --api-key <key> [--plan coding|agent]\n')
            return 1
          }
          await saveArkApiKey(createArkCredentialStore(), apiKey, arkPlan)
          const route = arkPlan === 'agent' ? 'coding-plans-ark-agent' : 'coding-plans-ark'
          process.stdout.write(`coding-plans ark: ${arkPlan} plan key saved to ${arkAuthPath()}; models route ${route}\n`)
          return 0
        }
      }
    }

    if (provider === 'kimi') {
      switch (action) {
        case 'status': {
          const status = await kimiAuthStatus()
          if (!status.authenticated) {
            process.stdout.write('coding-plans kimi: signed out\n')
            return 1
          }
          process.stdout.write(`coding-plans kimi: signed in (${status.mode ?? 'oauth'})\n`)
          return 0
        }
        case 'logout':
          await logoutKimi()
          process.stdout.write(`coding-plans kimi: signed out; removed ${kimiAuthPath()}\n`)
          return 0
        case 'login': {
          if (apiKey !== undefined && apiKey.length > 0) {
            await saveKimiApiKey(createKimiCredentialStore(), apiKey)
            process.stdout.write(`coding-plans kimi: API key saved to ${kimiAuthPath()}\n`)
            return 0
          }
          await loginKimiDevice({
            onChallenge: session => {
              process.stdout.write(`Open this URL to sign in:\n${session.url}\n`)
              if (session.device.userCode.length > 0) {
                process.stdout.write(`Enter code: ${session.device.userCode}\n`)
              }
              openBrowser(session.url)
            },
          })
          process.stdout.write(`coding-plans kimi: signed in; credentials saved to ${kimiAuthPath()}\n`)
          return 0
        }
      }
    }

    switch (action) {
      case 'status': {
        const status = await codexAuthStatus()
        if (!status.authenticated) {
          process.stdout.write('coding-plans codex: signed out\n')
          return 1
        }
        const expires = status.expiresAt
        const suffix = expires === undefined || Number.isNaN(expires.valueOf())
          ? ''
          : `; access token expires ${expires.toISOString()} (refresh is automatic)`
        process.stdout.write(`coding-plans codex: signed in${suffix}\n`)
        return 0
      }
      case 'logout':
        await logoutCodex()
        process.stdout.write(`coding-plans codex: signed out; removed ${codexAuthPath()}\n`)
        return 0
      case 'login': {
        const readline = createInterface({ input: process.stdin, output: process.stdout })
        try {
          await loginCodex({
            prompt: prompt => answerPrompt(prompt, flags.includes('--device-code'), (text, options) => readline.question(text, options)),
            notify: event => notify(event, true),
          })
        } finally {
          readline.close()
        }
        process.stdout.write(`coding-plans codex: signed in; credentials saved to ${codexAuthPath()}\n`)
        return 0
      }
    }
  } catch (error: unknown) {
    process.stderr.write(`dsh-coding-plans: ${action} failed: ${safeMessage(error)}\n`)
    return 1
  }
}

if (process.argv[1] !== undefined && fileURLToPath(import.meta.url) === realpathSync(process.argv[1])) {
  process.exitCode = await run(process.argv.slice(2))
}
