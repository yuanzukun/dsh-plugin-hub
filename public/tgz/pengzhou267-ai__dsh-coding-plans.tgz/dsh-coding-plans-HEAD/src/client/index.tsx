/** Browser half: Coding Plans account page inside dsh Settings. */

import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-slots'
import { CodingPlansSettings } from './CodingPlansSettings.tsx'
import type { CodingPlansSettingsInjected, CodingPlansSettingsKey } from './CodingPlansSettings.tsx'
import { en, zh } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    'settings.coding-plans': CodingPlansSettingsKey
  }
}

export const name = 'dsh-coding-plans-client'
export const inject = ['slots', 'locale']

export function apply(ctx: ClientContext): void {
  const namespace = 'settings.coding-plans'
  ctx.effect(() => ctx.locale.register(namespace, { zh, en }), 'dsh-coding-plans: settings copy')
  const t = ctx.locale.bind(namespace) as CodingPlansSettingsInjected['t']
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'coding-plans',
    order: 16,
    label: () => t('nav'),
    inject: (): CodingPlansSettingsInjected => ({ t }),
  }, CodingPlansSettings))
}
