/** Coding Plans settings: Codex + Kimi cards, domestic stubs. */

import { useCallback, useEffect, useState } from 'react'
import type { CSSProperties } from 'react'
import type { OpenAICodexUsage } from '../../packages/provider-codex/src/usage.ts'

const CODEX_STATUS = '/plugins/dsh-coding-plans/codex/auth/status'
const CODEX_LOGIN = '/plugins/dsh-coding-plans/codex/auth/login'
const CODEX_LOGOUT = '/plugins/dsh-coding-plans/codex/auth/logout'
const KIMI_STATUS = '/plugins/dsh-coding-plans/kimi/auth/status'
const KIMI_LOGIN = '/plugins/dsh-coding-plans/kimi/auth/login'
const KIMI_LOGOUT = '/plugins/dsh-coding-plans/kimi/auth/logout'
const KIMI_API_KEY = '/plugins/dsh-coding-plans/kimi/auth/api-key'
const ARK_STATUS = '/plugins/dsh-coding-plans/ark/auth/status'
const ARK_API_KEY = '/plugins/dsh-coding-plans/ark/auth/api-key'
const ARK_LOGOUT = '/plugins/dsh-coding-plans/ark/auth/logout'
const POLL_INTERVAL_MS = 1_000
const USAGE_POLL_INTERVAL_MS = 60_000

type CodexAccount =
  | { status: 'loading' }
  | { status: 'signed-out' }
  | { status: 'signing-in' }
  | { status: 'signed-in'; usage: OpenAICodexUsage; quotaError?: string }
  | { status: 'error'; message: string }

type KimiAccount =
  | { status: 'loading' }
  | { status: 'signed-out' }
  | { status: 'signing-in'; url?: string; userCode?: string }
  | { status: 'signed-in'; mode: 'oauth' | 'api-key' }
  | { status: 'error'; message: string }

type ArkAccount =
  | { status: 'loading' }
  | { status: 'signed-out' }
  | { status: 'signed-in'; plan: 'coding' | 'agent' }
  | { status: 'error'; message: string }

export type CodingPlansSettingsKey =
  | 'nav'
  | 'title'
  | 'body'
  | 'codexTitle'
  | 'codexNote'
  | 'kimiTitle'
  | 'kimiNote'
  | 'kimiSignIn'
  | 'kimiAdvanced'
  | 'kimiApiKeyPlaceholder'
  | 'kimiSaveKey'
  | 'kimiUserCode'
  | 'arkTitle'
  | 'arkNote'
  | 'arkPlanCoding'
  | 'arkPlanAgent'
  | 'arkApiKeyPlaceholder'
  | 'arkSaveKey'
  | 'signedOut'
  | 'signingIn'
  | 'signedIn'
  | 'signIn'
  | 'signOut'
  | 'openAuthUrl'
  | 'usageLimits'
  | 'percentRemaining'
  | 'fiveHourLimit'
  | 'weeklyLimit'
  | 'hourLimit'
  | 'usageWindow'
  | 'monthlyLimit'
  | 'exactRemaining'
  | 'creditsUnlimited'
  | 'creditsBalance'
  | 'quotaUnavailable'
  | 'stubClaude'
  | 'stubGemini'
  | 'stubGlm'
  | 'stubMinimax'
  | 'stubBailian'
  | 'stubTencent'
  | 'error'

export interface CodingPlansSettingsInjected {
  t: (key: CodingPlansSettingsKey, params?: Record<string, unknown>) => string
}

export type CodingPlansSettingsProps = Partial<CodingPlansSettingsInjected>

const pageStyle: CSSProperties = { display: 'flex', flexDirection: 'column', gap: 18, maxWidth: 720 }
const titleStyle: CSSProperties = { margin: 0, fontSize: 20, lineHeight: '28px', fontWeight: 600, color: 'var(--dsw-alias-label-primary)' }
const bodyStyle: CSSProperties = { margin: 0, fontSize: 14, lineHeight: '22px', color: 'var(--dsw-alias-label-secondary)' }
const cardStyle: CSSProperties = { display: 'flex', flexDirection: 'column', gap: 14, padding: '18px 20px', border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 12, background: 'var(--dsw-alias-bg-module-platform)' }
const rowStyle: CSSProperties = { display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }
const buttonStyle: CSSProperties = { boxSizing: 'border-box', minHeight: 34, padding: '6px 14px', border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 18, background: 'var(--dsw-alias-bg-layer-1)', color: 'var(--dsw-alias-label-primary)', font: 'inherit', fontSize: 14, cursor: 'pointer' }
const primaryButtonStyle: CSSProperties = { ...buttonStyle, borderColor: 'var(--dsw-alias-brand-primary)', background: 'var(--dsw-alias-brand-primary)', color: 'white' }
const errorStyle: CSSProperties = { ...bodyStyle, color: 'var(--dsw-alias-state-error-primary)' }
const progressTrackStyle: CSSProperties = { height: 8, overflow: 'hidden', borderRadius: 999, background: 'var(--dsw-alias-bg-layer-2, rgba(0, 0, 0, 0.08))' }
const inputStyle: CSSProperties = { boxSizing: 'border-box', flex: 1, minWidth: 180, minHeight: 34, padding: '6px 12px', border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 8, background: 'var(--dsw-alias-bg-layer-1)', color: 'var(--dsw-alias-label-primary)', font: 'inherit', fontSize: 14 }

function formatPercent(percent: number): string {
  return new Intl.NumberFormat(undefined, { maximumFractionDigits: 1 }).format(percent)
}

function windowLabel(seconds: number, t: CodingPlansSettingsInjected['t']): string {
  if (seconds === 5 * 60 * 60) return t('fiveHourLimit')
  if (seconds === 7 * 24 * 60 * 60) return t('weeklyLimit')
  const hours = seconds / (60 * 60)
  return Number.isInteger(hours) ? t('hourLimit', { count: hours }) : t('usageWindow')
}

function interpolate(template: string, params?: Record<string, unknown>): string {
  if (params === undefined) return template
  return template.replace(/\{(\w+)\}/gu, (_, key: string) => String(params[key] ?? `{${key}}`))
}

async function fetchCodex(): Promise<CodexAccount> {
  const response = await fetch(CODEX_STATUS, { credentials: 'same-origin', cache: 'no-store' })
  if (!response.ok) throw new Error(`codex status HTTP ${response.status}`)
  return await response.json() as CodexAccount
}

async function fetchKimi(): Promise<KimiAccount> {
  const response = await fetch(KIMI_STATUS, { credentials: 'same-origin', cache: 'no-store' })
  if (!response.ok) throw new Error(`kimi status HTTP ${response.status}`)
  return await response.json() as KimiAccount
}

async function fetchArk(): Promise<ArkAccount> {
  const response = await fetch(ARK_STATUS, { credentials: 'same-origin', cache: 'no-store' })
  if (!response.ok) throw new Error(`ark status HTTP ${response.status}`)
  return await response.json() as ArkAccount
}

export function CodingPlansSettings(props: CodingPlansSettingsProps) {
  const t = (key: CodingPlansSettingsKey, params?: Record<string, unknown>) =>
    interpolate((props.t ?? ((k: CodingPlansSettingsKey) => k))(key, params), params)
  const [codex, setCodex] = useState<CodexAccount>({ status: 'loading' })
  const [kimi, setKimi] = useState<KimiAccount>({ status: 'loading' })
  const [ark, setArk] = useState<ArkAccount>({ status: 'loading' })
  const [codexAuthUrl, setCodexAuthUrl] = useState<string | undefined>()
  const [kimiAuthUrl, setKimiAuthUrl] = useState<string | undefined>()
  const [kimiUserCode, setKimiUserCode] = useState<string | undefined>()
  const [apiKey, setApiKey] = useState('')
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [arkApiKey, setArkApiKey] = useState('')
  const [arkPlan, setArkPlan] = useState<'coding' | 'agent'>('coding')
  const [busy, setBusy] = useState(false)

  const refresh = useCallback(async () => {
    try {
      setCodex(await fetchCodex())
    } catch (error: unknown) {
      setCodex({ status: 'error', message: error instanceof Error ? error.message : String(error) })
    }
    try {
      setKimi(await fetchKimi())
    } catch (error: unknown) {
      setKimi({ status: 'error', message: error instanceof Error ? error.message : String(error) })
    }
    try {
      setArk(await fetchArk())
    } catch (error: unknown) {
      setArk({ status: 'error', message: error instanceof Error ? error.message : String(error) })
    }
  }, [])

  useEffect(() => { void refresh() }, [refresh])

  useEffect(() => {
    const polling = codex.status === 'signing-in' || kimi.status === 'signing-in'
      || codex.status === 'signed-in'
    if (!polling) return
    const ms = codex.status === 'signing-in' || kimi.status === 'signing-in'
      ? POLL_INTERVAL_MS
      : USAGE_POLL_INTERVAL_MS
    const timer = setInterval(() => { void refresh() }, ms)
    return () => clearInterval(timer)
  }, [codex.status, kimi.status, refresh])

  const signInCodex = async () => {
    setBusy(true)
    try {
      const response = await fetch(CODEX_LOGIN, { method: 'POST', credentials: 'same-origin' })
      const body = await response.json() as { url?: string; error?: string }
      if (!response.ok) throw new Error(body.error ?? `login HTTP ${response.status}`)
      if (typeof body.url === 'string') {
        setCodexAuthUrl(body.url)
        window.open(body.url, '_blank', 'noopener,noreferrer')
      }
      await refresh()
    } catch (error: unknown) {
      setCodex({ status: 'error', message: error instanceof Error ? error.message : String(error) })
    } finally {
      setBusy(false)
    }
  }

  const signOutCodex = async () => {
    setBusy(true)
    try {
      await fetch(CODEX_LOGOUT, { method: 'POST', credentials: 'same-origin' })
      setCodexAuthUrl(undefined)
      await refresh()
    } catch (error: unknown) {
      setCodex({ status: 'error', message: error instanceof Error ? error.message : String(error) })
    } finally {
      setBusy(false)
    }
  }

  const signInKimi = async () => {
    setBusy(true)
    try {
      const response = await fetch(KIMI_LOGIN, { method: 'POST', credentials: 'same-origin' })
      const body = await response.json() as { url?: string; userCode?: string; error?: string }
      if (!response.ok) throw new Error(body.error ?? `login HTTP ${response.status}`)
      if (typeof body.url === 'string') {
        setKimiAuthUrl(body.url)
        window.open(body.url, '_blank', 'noopener,noreferrer')
      }
      setKimiUserCode(typeof body.userCode === 'string' ? body.userCode : undefined)
      await refresh()
    } catch (error: unknown) {
      setKimi({ status: 'error', message: error instanceof Error ? error.message : String(error) })
    } finally {
      setBusy(false)
    }
  }

  const signOutKimi = async () => {
    setBusy(true)
    try {
      await fetch(KIMI_LOGOUT, { method: 'POST', credentials: 'same-origin' })
      setKimiAuthUrl(undefined)
      setKimiUserCode(undefined)
      await refresh()
    } catch (error: unknown) {
      setKimi({ status: 'error', message: error instanceof Error ? error.message : String(error) })
    } finally {
      setBusy(false)
    }
  }

  const saveKimiKey = async () => {
    setBusy(true)
    try {
      const response = await fetch(KIMI_API_KEY, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ apiKey }),
      })
      const body = await response.json() as { error?: string }
      if (!response.ok) throw new Error(body.error ?? `api-key HTTP ${response.status}`)
      setApiKey('')
      setShowAdvanced(false)
      await refresh()
    } catch (error: unknown) {
      setKimi({ status: 'error', message: error instanceof Error ? error.message : String(error) })
    } finally {
      setBusy(false)
    }
  }

  const saveArkKey = async () => {
    setBusy(true)
    try {
      const response = await fetch(ARK_API_KEY, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ apiKey: arkApiKey, plan: arkPlan }),
      })
      const body = await response.json() as { error?: string }
      if (!response.ok) throw new Error(body.error ?? `ark api-key HTTP ${response.status}`)
      setArkApiKey('')
      await refresh()
    } catch (error: unknown) {
      setArk({ status: 'error', message: error instanceof Error ? error.message : String(error) })
    } finally {
      setBusy(false)
    }
  }

  const signOutArk = async () => {
    setBusy(true)
    try {
      await fetch(ARK_LOGOUT, { method: 'POST', credentials: 'same-origin' })
      await refresh()
    } catch (error: unknown) {
      setArk({ status: 'error', message: error instanceof Error ? error.message : String(error) })
    } finally {
      setBusy(false)
    }
  }

  const codexLabel =
    codex.status === 'loading' ? '…'
      : codex.status === 'signed-out' ? t('signedOut')
        : codex.status === 'signing-in' ? t('signingIn')
          : codex.status === 'signed-in' ? t('signedIn')
            : codex.message

  const kimiLabel =
    kimi.status === 'loading' ? '…'
      : kimi.status === 'signed-out' ? t('signedOut')
        : kimi.status === 'signing-in' ? t('signingIn')
          : kimi.status === 'signed-in' ? `${t('signedIn')}${kimi.mode === 'api-key' ? ' (API key)' : ''}`
            : kimi.message

  const arkLabel =
    ark.status === 'loading' ? '…'
      : ark.status === 'signed-out' ? t('signedOut')
        : ark.status === 'signed-in'
          ? `${t('signedIn')} (${ark.plan === 'agent' ? t('arkPlanAgent') : t('arkPlanCoding')})`
          : ark.message

  return (
    <div style={pageStyle}>
      <h1 style={titleStyle}>{t('title')}</h1>
      <p style={bodyStyle}>{t('body')}</p>

      <section style={cardStyle}>
        <h2 style={{ ...titleStyle, fontSize: 16 }}>{t('codexTitle')}</h2>
        <p style={bodyStyle}>{t('codexNote')}</p>
        <div style={rowStyle}>
          <span style={{ color: 'var(--dsw-alias-label-primary)', fontWeight: 500 }}>{codexLabel}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            {codex.status === 'signed-in'
              ? <button type="button" style={buttonStyle} disabled={busy} onClick={() => { void signOutCodex() }}>{t('signOut')}</button>
              : <button type="button" style={primaryButtonStyle} disabled={busy || codex.status === 'signing-in'} onClick={() => { void signInCodex() }}>{t('signIn')}</button>}
          </div>
        </div>
        {codexAuthUrl === undefined ? null : (
          <p style={bodyStyle}><a href={codexAuthUrl} target="_blank" rel="noreferrer">{t('openAuthUrl')}</a></p>
        )}
        {codex.status === 'error' ? <p style={errorStyle}>{codex.message}</p> : null}
        {codex.status === 'signed-in' ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <h3 style={{ ...titleStyle, fontSize: 14 }}>{t('usageLimits')}</h3>
            {codex.quotaError !== undefined ? <p style={errorStyle}>{t('quotaUnavailable')}: {codex.quotaError}</p> : null}
            {codex.usage.rateLimits.map(limit => (
              <div key={limit.id}>
                <p style={{ ...bodyStyle, fontWeight: 600, color: 'var(--dsw-alias-label-primary)' }}>{limit.name ?? limit.id}</p>
                {limit.windows.map(window => (
                  <div key={window.windowSeconds} style={{ marginBottom: 8 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: 'var(--dsw-alias-label-secondary)' }}>
                      <span>{windowLabel(window.windowSeconds, t)}</span>
                      <span>{t('percentRemaining', { percent: formatPercent(window.remainingPercent) })}</span>
                    </div>
                    <div style={progressTrackStyle}>
                      <div style={{ width: `${window.remainingPercent}%`, height: '100%', background: 'var(--dsw-alias-brand-primary, #1677ff)', borderRadius: 'inherit' }} />
                    </div>
                  </div>
                ))}
              </div>
            ))}
            {codex.usage.credits?.unlimited === true ? <p style={bodyStyle}>{t('creditsUnlimited')}</p> : null}
            {codex.usage.credits?.balance !== undefined ? <p style={bodyStyle}>{t('creditsBalance', { balance: codex.usage.credits.balance })}</p> : null}
            {codex.usage.individualLimit === undefined ? null : (
              <p style={bodyStyle}>{t('exactRemaining', {
                remaining: codex.usage.individualLimit.remaining,
                limit: codex.usage.individualLimit.limit,
              })}</p>
            )}
          </div>
        ) : null}
      </section>

      <section style={cardStyle}>
        <h2 style={{ ...titleStyle, fontSize: 16 }}>{t('kimiTitle')}</h2>
        <p style={bodyStyle}>{t('kimiNote')}</p>
        <div style={rowStyle}>
          <span style={{ color: 'var(--dsw-alias-label-primary)', fontWeight: 500 }}>{kimiLabel}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            {kimi.status === 'signed-in'
              ? <button type="button" style={buttonStyle} disabled={busy} onClick={() => { void signOutKimi() }}>{t('signOut')}</button>
              : <button type="button" style={primaryButtonStyle} disabled={busy || kimi.status === 'signing-in'} onClick={() => { void signInKimi() }}>{t('kimiSignIn')}</button>}
          </div>
        </div>
        {kimiUserCode === undefined ? null : <p style={bodyStyle}>{t('kimiUserCode', { code: kimiUserCode })}</p>}
        {kimiAuthUrl === undefined ? null : (
          <p style={bodyStyle}><a href={kimiAuthUrl} target="_blank" rel="noreferrer">{t('openAuthUrl')}</a></p>
        )}
        {kimi.status === 'error' ? <p style={errorStyle}>{kimi.message}</p> : null}
        <div>
          <button type="button" style={buttonStyle} onClick={() => setShowAdvanced(v => !v)}>{t('kimiAdvanced')}</button>
          {showAdvanced ? (
            <div style={{ ...rowStyle, marginTop: 10 }}>
              <input
                type="password"
                autoComplete="off"
                style={inputStyle}
                placeholder={t('kimiApiKeyPlaceholder')}
                value={apiKey}
                onChange={event => setApiKey(event.target.value)}
              />
              <button type="button" style={primaryButtonStyle} disabled={busy || apiKey.trim().length === 0} onClick={() => { void saveKimiKey() }}>{t('kimiSaveKey')}</button>
            </div>
          ) : null}
        </div>
      </section>

      <section style={cardStyle}>
        <h2 style={{ ...titleStyle, fontSize: 16 }}>{t('arkTitle')}</h2>
        <p style={bodyStyle}>{t('arkNote')}</p>
        <div style={rowStyle}>
          <span style={{ color: 'var(--dsw-alias-label-primary)', fontWeight: 500 }}>{arkLabel}</span>
          {ark.status === 'signed-in'
            ? <button type="button" style={buttonStyle} disabled={busy} onClick={() => { void signOutArk() }}>{t('signOut')}</button>
            : null}
        </div>
        {ark.status === 'error' ? <p style={errorStyle}>{ark.message}</p> : null}
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button type="button" style={arkPlan === 'coding' ? primaryButtonStyle : buttonStyle} onClick={() => setArkPlan('coding')}>{t('arkPlanCoding')}</button>
          <button type="button" style={arkPlan === 'agent' ? primaryButtonStyle : buttonStyle} onClick={() => setArkPlan('agent')}>{t('arkPlanAgent')}</button>
        </div>
        <div style={rowStyle}>
          <input
            type="password"
            autoComplete="off"
            style={inputStyle}
            placeholder={t('arkApiKeyPlaceholder')}
            value={arkApiKey}
            onChange={event => setArkApiKey(event.target.value)}
          />
          <button type="button" style={primaryButtonStyle} disabled={busy || arkApiKey.trim().length === 0} onClick={() => { void saveArkKey() }}>{t('arkSaveKey')}</button>
        </div>
      </section>

      <section style={cardStyle}>
        <p style={bodyStyle}>{t('stubGlm')}</p>
        <p style={bodyStyle}>{t('stubMinimax')}</p>
        <p style={bodyStyle}>{t('stubBailian')}</p>
        <p style={bodyStyle}>{t('stubTencent')}</p>
        <p style={bodyStyle}>{t('stubGemini')}</p>
        <p style={bodyStyle}>{t('stubClaude')}</p>
      </section>
    </div>
  )
}
