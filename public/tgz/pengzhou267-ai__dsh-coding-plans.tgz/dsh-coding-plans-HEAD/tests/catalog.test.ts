import { describe, expect, it } from 'vitest'
import { describeCodexUsageError, parseOpenAICodexUsage } from '../packages/provider-codex/src/usage.ts'
import { kimiCodingHeaders } from '../packages/provider-kimi/src/device-flow.ts'
import { PROVIDER_CATALOG } from '../src/index.ts'
import { codingPlanAuthPath, CODING_PLANS_DIR } from '../packages/core/src/index.ts'

describe('provider catalog', () => {
  it('lists codex, kimi, ark as ready; other domestic stubs; claude deferred', () => {
    const byId = Object.fromEntries(PROVIDER_CATALOG.map(p => [p.id, p.status]))
    expect(byId.codex).toBe('ready')
    expect(byId.kimi).toBe('ready')
    expect(byId.ark).toBe('ready')
    expect(byId.glm).toBe('stub')
    expect(byId.minimax).toBe('stub')
    expect(byId.bailian).toBe('stub')
    expect(byId.tencent).toBe('stub')
    expect(byId.gemini).toBe('stub')
    expect(byId.claude).toBe('stub')
  })
})

describe('coding plan paths', () => {
  it('keeps credentials under coding-plans/', () => {
    const path = codingPlanAuthPath('codex-auth.json', '/tmp/fake-dsh-home')
    expect(path.replaceAll('\\', '/')).toContain(`/${CODING_PLANS_DIR}/codex-auth.json`)
  })
})

describe('parseOpenAICodexUsage', () => {
  it('maps used_percent to remainingPercent', () => {
    const usage = parseOpenAICodexUsage({
      rate_limit: {
        primary_window: { used_percent: 25, limit_window_seconds: 18000 },
        secondary_window: { used_percent: 10, limit_window_seconds: 604800 },
      },
    })
    expect(usage.rateLimits).toHaveLength(1)
    expect(usage.rateLimits[0]?.windows[0]?.remainingPercent).toBe(75)
    expect(usage.rateLimits[0]?.windows[1]?.remainingPercent).toBe(90)
  })
})

describe('describeCodexUsageError', () => {
  it('maps connect timeouts to a readable network message', () => {
    const error = new TypeError('fetch failed', {
      cause: Object.assign(new Error('Connect Timeout Error'), { code: 'UND_ERR_CONNECT_TIMEOUT' }),
    })
    expect(describeCodexUsageError(error)).toMatch(/chatgpt\.com/i)
    expect(describeCodexUsageError(error)).toMatch(/Sign-in is still valid/i)
  })
})

describe('kimi coding headers', () => {
  it('sets KimiCLI User-Agent required by the coding endpoint', () => {
    const headers = kimiCodingHeaders('device-1')
    expect(headers['User-Agent']).toMatch(/^KimiCLI\//)
    expect(headers['X-Msh-Platform']).toBe('kimi_cli')
    expect(headers['X-Msh-Device-Id']).toBe('device-1')
  })
})

describe('ark plan bases', () => {
  it('keeps coding and agent endpoints distinct from pay-as-you-go', async () => {
    const { ARK_CODING_API_BASE_URL, ARK_AGENT_API_BASE_URL, arkBaseUrl } = await import('../packages/provider-ark/src/constants.ts')
    expect(ARK_CODING_API_BASE_URL).toContain('/api/coding/v3')
    expect(ARK_AGENT_API_BASE_URL).toContain('/api/plan/v3')
    expect(arkBaseUrl('coding')).toBe(ARK_CODING_API_BASE_URL)
    expect(arkBaseUrl('agent')).toBe(ARK_AGENT_API_BASE_URL)
    expect(ARK_CODING_API_BASE_URL).not.toContain('/api/v3')
  })
})
