//#region src/bin.d.ts
/** Standalone credential CLI: dsh-coding-plans <login|logout|status> [provider] */
declare function run(argv: readonly string[]): Promise<number>;
//#endregion
export { run };