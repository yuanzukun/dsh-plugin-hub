import z from "@deepseek-ai/schemastery";
import { AuthInteraction, Credential, CredentialInfo, CredentialStore } from "@earendil-works/pi-ai";
import { PiAiAdapter } from "@deepseek-ai/dsh-llm-pi-ai";
import { Context } from "@deepseek-ai/cordis";
//#region packages/core/src/index.d.ts
declare function codingPlansDir(dshHome?: string): string;
/** Redact token-like fragments from errors shown to users or browsers. */
declare function safeAuthMessage(error: unknown): string;
/**
 * File-backed CredentialStore scoped to one pi-ai provider id.
 * Document path is under `$DSH_HOME/coding-plans/<filename>`.
 */
declare class CodingPlanCredentialStore implements CredentialStore {
  readonly filename: string;
  readonly providerId: string;
  constructor(providerId: string, filename: string, dshHome?: string);
  private readCurrent;
  read(providerId: string): Promise<Credential | undefined>;
  list(): Promise<readonly CredentialInfo[]>;
  modify(providerId: string, fn: (current: Credential | undefined) => Promise<Credential | undefined>): Promise<Credential | undefined>;
  delete(providerId: string): Promise<void>;
}
/** Descriptor for a coding-plan provider package. */
interface CodingPlanProviderMeta {
  /** Stable hub id used in CLI (`login codex`). */
  id: string;
  /** Human label for Settings. */
  displayName: string;
  /** Implementation maturity. */
  status: 'ready' | 'stub' | 'experimental';
}
//#endregion
//#region packages/provider-codex/src/auth.d.ts
declare const CODEX_PI_PROVIDER = "openai-codex";
declare const CODEX_DSH_ROUTE = "coding-plans-codex";
declare function codexAuthPath(dshHome?: string): string;
interface CodexAuthStatus {
  authenticated: boolean;
  expiresAt?: Date;
}
declare function loginCodex(interaction: AuthInteraction, store?: CodingPlanCredentialStore): Promise<void>;
declare function logoutCodex(store?: CodingPlanCredentialStore): Promise<void>;
declare function codexAuthStatus(store?: CodingPlanCredentialStore): Promise<CodexAuthStatus>;
//#endregion
//#region packages/provider-kimi/src/device-flow.d.ts
interface KimiDeviceCode {
  deviceCode: string;
  userCode: string;
  verificationUri: string;
  verificationUriComplete?: string;
  expiresIn: number;
  intervalSeconds: number;
}
//#endregion
//#region packages/provider-kimi/src/auth.d.ts
declare const KIMI_PI_PROVIDER = "kimi-coding";
declare const KIMI_DSH_ROUTE = "coding-plans-kimi";
declare function createKimiCredentialStore(dshHome?: string): CodingPlanCredentialStore;
declare function kimiAuthPath(dshHome?: string): string;
interface KimiAuthStatus {
  authenticated: boolean;
  mode?: 'oauth' | 'api-key';
  expiresAt?: Date;
}
declare function saveKimiApiKey(store: CodingPlanCredentialStore, apiKey: string): Promise<void>;
declare function kimiAuthStatus(store?: CodingPlanCredentialStore): Promise<KimiAuthStatus>;
declare function logoutKimi(store?: CodingPlanCredentialStore): Promise<void>;
interface KimiDeviceLoginSession {
  deviceId: string;
  device: KimiDeviceCode;
  /** Absolute URL to open (prefers verification_uri_complete). */
  url: string;
}
/**
 * CLI helper: run full device flow with optional progress callbacks.
 */
declare function loginKimiDevice(options?: {
  store?: CodingPlanCredentialStore;
  signal?: AbortSignal;
  onChallenge?: (session: KimiDeviceLoginSession) => void;
}): Promise<void>;
//#endregion
//#region packages/provider-ark/src/constants.d.ts
type ArkPlanKind = 'coding' | 'agent';
//#endregion
//#region packages/provider-ark/src/auth.d.ts
declare const ARK_PI_PROVIDER = "ark-coding";
declare const ARK_DSH_ROUTE = "coding-plans-ark";
declare const ARK_DSH_ROUTE_AGENT = "coding-plans-ark-agent";
declare function createArkCredentialStore(dshHome?: string): CodingPlanCredentialStore;
declare function arkAuthPath(dshHome?: string): string;
interface ArkAuthStatus {
  authenticated: boolean;
  plan?: ArkPlanKind;
}
declare function arkAuthStatus(store?: CodingPlanCredentialStore): Promise<ArkAuthStatus>;
declare function logoutArk(store?: CodingPlanCredentialStore): Promise<void>;
declare function saveArkApiKey(store: CodingPlanCredentialStore, apiKey: string, plan?: ArkPlanKind): Promise<void>;
//#endregion
//#region src/index.d.ts
declare const name = "llm-coding-plans";
declare const inject: string[];
interface Config {
  /** When false, skip registering the Codex adapter (default true). */
  enableCodex?: boolean;
  /** When false, skip registering the Kimi adapter (default true). */
  enableKimi?: boolean;
  /** When false, skip registering the Ark adapter (default true). */
  enableArk?: boolean;
}
declare const Config: z<Config>;
/** Catalog of hub providers for docs / CLI status. */
declare const PROVIDER_CATALOG: readonly CodingPlanProviderMeta[];
declare function apply(ctx: Context, config: Config): void;
//#endregion
export { ARK_DSH_ROUTE, ARK_DSH_ROUTE_AGENT, ARK_PI_PROVIDER, type ArkAuthStatus, type ArkPlanKind, CODEX_DSH_ROUTE, CODEX_PI_PROVIDER, type CodexAuthStatus, CodingPlanCredentialStore, Config, KIMI_DSH_ROUTE, KIMI_PI_PROVIDER, type KimiAuthStatus, PROVIDER_CATALOG, apply, arkAuthPath, arkAuthStatus, codexAuthPath, codexAuthStatus, codingPlansDir, createArkCredentialStore, createKimiCredentialStore, inject, kimiAuthPath, kimiAuthStatus, loginCodex, loginKimiDevice, logoutArk, logoutCodex, logoutKimi, name, safeAuthMessage, saveArkApiKey, saveKimiApiKey };