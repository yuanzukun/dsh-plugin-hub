# Install dsh-coding-plans

Idempotent runbook for humans and agents.

## Requirements

- Node.js `^22.19` or `>=24`
- DeepSeek Harness developer preview (`0.1.0-rc.6` or compatible)
- For Codex: a ChatGPT account with Codex / paid plan access
- For Kimi: a Kimi Code / membership plan (device login or Coding API key)

## Install into the web profile

```sh
dsh plugin --profile web add dsh-coding-plans
# or from GitHub:
dsh plugin --profile web add github:pengzhou267-ai/dsh-coding-plans
```

If pnpm blocks `prepare` / build scripts on a git install, allow the package in
the profile `pnpm-workspace.yaml`:

```yaml
allowBuilds:
  dsh-coding-plans: true
```

Then re-run `dsh plugin --profile web add …`.

Local checkout:

```sh
dsh plugin --profile web add link:/absolute/path/to/dsh-coding-plans
```

## Sign in

### Web UI

1. `dsh web`
2. **Settings → Coding Plans**
3. Codex: **Sign in with ChatGPT** — or Kimi: **Sign in with Kimi** (device code) / Advanced API key
4. **Models** → `coding-plans-codex` or `coding-plans-kimi`

### CLI

```sh
dsh-coding-plans login codex
dsh-coding-plans login kimi
dsh-coding-plans login kimi --api-key sk-…
dsh-coding-plans status kimi
dsh-coding-plans logout kimi
dsh-coding-plans list
```

## Credentials

- Codex: `$DSH_HOME/coding-plans/codex-auth.json`
- Kimi: `$DSH_HOME/coding-plans/kimi-auth.json`
- Ark: `$DSH_HOME/coding-plans/ark-auth.json`

Default `$DSH_HOME` is `$HOME/.dsh`. This plugin does **not** read or write
`~/.codex/auth.json` or other CLI auth homes.

## Uninstall

```sh
dsh plugin --profile web remove dsh-coding-plans
```

```sh
dsh-coding-plans logout codex
dsh-coding-plans logout kimi
# or delete $DSH_HOME/coding-plans/
```
