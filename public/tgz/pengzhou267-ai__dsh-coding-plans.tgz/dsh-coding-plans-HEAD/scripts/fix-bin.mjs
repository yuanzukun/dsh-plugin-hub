import { readFileSync, writeFileSync, chmodSync } from 'node:fs'

const path = 'lib/bin.mjs'
let text = readFileSync(path, 'utf8')
if (!text.startsWith('#!')) {
  text = `#!/usr/bin/env node\n${text}`
  writeFileSync(path, text)
}
chmodSync(path, 0o755)
