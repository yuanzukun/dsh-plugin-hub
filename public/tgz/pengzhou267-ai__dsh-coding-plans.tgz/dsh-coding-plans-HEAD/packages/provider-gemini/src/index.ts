/**
 * Gemini CLI / Antigravity coding-plan provider — stub for community PRs.
 *
 * Port target: CLIProxyAPI gemini / antigravity OAuth.
 * See docs/provider-porting.md.
 */

import type { CodingPlanProviderMeta } from '../../core/src/index.ts'

export const GEMINI_DSH_ROUTE = 'coding-plans-gemini'
export const GEMINI_AUTH_FILENAME = 'gemini-auth.json'

export const geminiProviderMeta: CodingPlanProviderMeta = {
  id: 'gemini',
  displayName: 'Gemini CLI / Antigravity',
  status: 'stub',
}

/**
 * Placeholder until OAuth + LlmAdapter land.
 * @throws always — not implemented in MVP.
 */
export function createGeminiAdapter(): never {
  throw new Error(
    'coding-plans: Gemini provider is a stub. See docs/provider-porting.md and packages/provider-gemini to contribute.',
  )
}
