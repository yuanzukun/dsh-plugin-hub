/**
 * Tencent Cloud Coding/Token Plan — stub for community PRs.
 */

import type { CodingPlanProviderMeta } from '../../core/src/index.ts'

export const TENCENT_DSH_ROUTE = 'coding-plans-tencent'
export const TENCENT_AUTH_FILENAME = 'tencent-auth.json'

export const tencentProviderMeta: CodingPlanProviderMeta = {
  id: 'tencent',
  displayName: 'Tencent Cloud Coding/Token Plan',
  status: 'stub',
}

export function createTencentAdapter(): never {
  throw new Error(
    'coding-plans: Tencent provider is a stub. See docs/provider-porting.md and packages/provider-tencent.',
  )
}
