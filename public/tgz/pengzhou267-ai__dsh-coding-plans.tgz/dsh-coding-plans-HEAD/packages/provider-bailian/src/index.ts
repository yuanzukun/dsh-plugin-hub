/**
 * Alibaba Bailian Coding Plan — stub (usually Key + Base URL).
 */

import type { CodingPlanProviderMeta } from '../../core/src/index.ts'

export const BAILIAN_DSH_ROUTE = 'coding-plans-bailian'
export const BAILIAN_AUTH_FILENAME = 'bailian-auth.json'

export const bailianProviderMeta: CodingPlanProviderMeta = {
  id: 'bailian',
  displayName: 'Alibaba Bailian Coding Plan',
  status: 'stub',
}

export function createBailianAdapter(): never {
  throw new Error(
    'coding-plans: Bailian provider is a stub. See docs/provider-porting.md and packages/provider-bailian.',
  )
}
