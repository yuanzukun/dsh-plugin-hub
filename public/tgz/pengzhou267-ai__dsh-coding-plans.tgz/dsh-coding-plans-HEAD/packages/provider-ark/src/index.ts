/**
 * Volcengine Ark Coding Plan / Agent Plan for DeepSeek Harness.
 *
 * Auth is a console-issued API key. Deduction only happens on the plan-specific
 * OpenAI-compatible bases:
 * - Coding: https://ark.cn-beijing.volces.com/api/coding/v3
 * - Agent:  https://ark.cn-beijing.volces.com/api/plan/v3
 * Do not use the pay-as-you-go `/api/v3` URL with these keys.
 */

import type { CodingPlanProviderMeta } from '../../core/src/index.ts'

export {
  ARK_PI_PROVIDER,
  ARK_DSH_ROUTE,
  ARK_DSH_ROUTE_AGENT,
  ARK_AUTH_FILENAME,
  createArkCredentialStore,
  arkAuthPath,
  arkAuthStatus,
  logoutArk,
  saveArkApiKey,
  resolveArkAccessToken,
} from './auth.ts'
export type { ArkAuthStatus } from './auth.ts'
export {
  ARK_CODING_API_BASE_URL,
  ARK_AGENT_API_BASE_URL,
  ARK_MODEL_SPECS,
  arkBaseUrl,
  arkCodingHeaders,
  isArkPlanKind,
} from './constants.ts'
export type { ArkPlanKind, ArkModelSpec } from './constants.ts'
export { createArkAdapter, ARK_STREAM_IDLE_TIMEOUT_MS } from './adapter.ts'
export {
  registerArkAuthRoutes,
  ArkWebAuth,
  ARK_AUTH_STATUS_PATH,
  ARK_AUTH_API_KEY_PATH,
  ARK_AUTH_LOGOUT_PATH,
} from './auth-routes.ts'
export type { ArkWebAuthStatus } from './auth-routes.ts'

export const arkProviderMeta: CodingPlanProviderMeta = {
  id: 'ark',
  displayName: 'Volcengine Ark Coding/Agent Plan',
  status: 'ready',
}
