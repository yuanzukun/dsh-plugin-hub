/** Ark Coding/Agent Plan LlmAdapter via pi-ai openai-completions. */

import { createModels, createProvider } from '@earendil-works/pi-ai'
import type { Model, MutableModels, Provider } from '@earendil-works/pi-ai'
import { openAICompletionsApi } from '@earendil-works/pi-ai/api/openai-completions.lazy'
import { resolveRetryPolicy } from '@deepseek-ai/dsh-llm'
import { PiAiAdapter } from '@deepseek-ai/dsh-llm-pi-ai'
import type { ResolvedPiAiProviderProfile } from '@deepseek-ai/dsh-llm-pi-ai'
import type { CodingPlanCredentialStore } from '../../core/src/index.ts'
import {
  ARK_DSH_ROUTE,
  ARK_DSH_ROUTE_AGENT,
  ARK_PI_PROVIDER,
  resolveArkAccessToken,
} from './auth.ts'
import {
  ARK_MODEL_SPECS,
  arkBaseUrl,
  arkCodingHeaders,
} from './constants.ts'
import type { ArkPlanKind } from './constants.ts'

export const ARK_STREAM_IDLE_TIMEOUT_MS = 300_000

function arkModels(plan: ArkPlanKind): readonly Model<'openai-completions'>[] {
  const baseUrl = arkBaseUrl(plan)
  return ARK_MODEL_SPECS.map(spec => ({
    id: spec.id,
    name: spec.name,
    api: 'openai-completions' as const,
    provider: ARK_PI_PROVIDER,
    baseUrl,
    reasoning: spec.reasoning,
    input: ['text'] as const,
    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
    contextWindow: spec.contextWindow,
    maxTokens: spec.maxTokens,
  }))
}

function arkProvider(plan: ArkPlanKind): Provider<'openai-completions'> {
  const baseUrl = arkBaseUrl(plan)
  return createProvider({
    id: `${ARK_PI_PROVIDER}-${plan}`,
    name: plan === 'agent' ? 'Volcengine Ark Agent Plan' : 'Volcengine Ark Coding Plan',
    baseUrl,
    headers: arkCodingHeaders(),
    auth: {
      apiKey: {
        name: 'Volcengine Ark Coding/Agent Plan API key',
        async resolve({ credential }) {
          const apiKey = credential?.key
          return apiKey === undefined || apiKey.length === 0
            ? undefined
            : { auth: { apiKey }, source: 'api_key' }
        },
      },
    },
    models: arkModels(plan),
    api: openAICompletionsApi(),
  })
}

export function createArkAdapter(credentials: CodingPlanCredentialStore): PiAiAdapter {
  const codingProvider = arkProvider('coding')
  const agentProvider = arkProvider('agent')
  const profiles = new Map<string, ResolvedPiAiProviderProfile>([
    [ARK_DSH_ROUTE, {
      provider: ARK_DSH_ROUTE,
      displayName: 'Coding Plans · Ark Coding',
      streamIdleTimeoutMs: ARK_STREAM_IDLE_TIMEOUT_MS,
      retryPolicy: resolveRetryPolicy(undefined, 'dsh-coding-plans-ark retryPolicy'),
      configuredMaxTokens: new Map(),
      piProvider: codingProvider,
    }],
    [ARK_DSH_ROUTE_AGENT, {
      provider: ARK_DSH_ROUTE_AGENT,
      displayName: 'Coding Plans · Ark Agent',
      streamIdleTimeoutMs: ARK_STREAM_IDLE_TIMEOUT_MS,
      retryPolicy: resolveRetryPolicy(undefined, 'dsh-coding-plans-ark-agent retryPolicy'),
      configuredMaxTokens: new Map(),
      piProvider: agentProvider,
    }],
  ])
  const models: MutableModels = createModels({ credentials })
  models.setProvider(codingProvider)
  models.setProvider(agentProvider)
  return new PiAiAdapter({
    profiles: () => profiles,
    resolveApiKey: async (provider) => {
      const { accessToken, plan } = await resolveArkAccessToken(credentials)
      if (provider === ARK_DSH_ROUTE && plan !== 'coding') return undefined
      if (provider === ARK_DSH_ROUTE_AGENT && plan !== 'agent') return undefined
      return accessToken
    },
  })
}
