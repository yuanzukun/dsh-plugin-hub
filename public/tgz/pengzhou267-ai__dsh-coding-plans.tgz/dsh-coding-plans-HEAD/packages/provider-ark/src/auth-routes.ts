/** Same-origin Web settings routes for Volcengine Ark Coding/Agent Plan API keys. */

import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-host-webserver'
import { safeAuthMessage } from '../../core/src/index.ts'
import type { CodingPlanCredentialStore } from '../../core/src/index.ts'
import { arkAuthStatus, logoutArk, saveArkApiKey } from './auth.ts'
import { isArkPlanKind } from './constants.ts'
import type { ArkPlanKind } from './constants.ts'

export const ARK_AUTH_STATUS_PATH = '/plugins/dsh-coding-plans/ark/auth/status'
export const ARK_AUTH_API_KEY_PATH = '/plugins/dsh-coding-plans/ark/auth/api-key'
export const ARK_AUTH_LOGOUT_PATH = '/plugins/dsh-coding-plans/ark/auth/logout'

export type ArkWebAuthStatus =
  | { status: 'signed-out' }
  | { status: 'signed-in'; plan: ArkPlanKind }
  | { status: 'error'; message: string }

function trustedRequest(req: IncomingMessage): boolean {
  const remote = req.socket.remoteAddress
  if (remote !== '127.0.0.1' && remote !== '::1' && remote !== '::ffff:127.0.0.1') return false
  if (req.headers['sec-fetch-site'] === 'cross-site') return false
  const host = req.headers.host
  if (host === undefined) return false
  const origin = req.headers.origin
  if (origin === undefined) return true
  try {
    return new URL(origin).host === new URL(`http://${host}`).host
  } catch {
    return false
  }
}

function json(res: ServerResponse, status: number, value: unknown): void {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
  })
  res.end(JSON.stringify(value))
}

async function readJsonBody(req: IncomingMessage): Promise<unknown> {
  const chunks: Buffer[] = []
  for await (const chunk of req) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
  const text = Buffer.concat(chunks).toString('utf8').trim()
  if (text.length === 0) return {}
  return JSON.parse(text) as unknown
}

export class ArkWebAuth {
  constructor(private readonly store: CodingPlanCredentialStore) {}

  async status(): Promise<ArkWebAuthStatus> {
    const stored = await arkAuthStatus(this.store)
    if (!stored.authenticated) return { status: 'signed-out' }
    return { status: 'signed-in', plan: stored.plan ?? 'coding' }
  }

  async saveApiKey(apiKey: string, plan: ArkPlanKind): Promise<void> {
    await saveArkApiKey(this.store, apiKey, plan)
  }

  async signOut(): Promise<void> {
    await logoutArk(this.store)
  }
}

export function registerArkAuthRoutes(
  ctx: Context,
  store: CodingPlanCredentialStore,
): void {
  const auth = new ArkWebAuth(store)
  ctx.effect(() => {
    const routes = [
      ctx.webServer.register({
        kind: 'exact',
        path: ARK_AUTH_STATUS_PATH,
        handler: async (req, res) => {
          if (req.method !== 'GET') return json(res, 405, { error: 'method not allowed' })
          if (!trustedRequest(req)) return json(res, 403, { error: 'forbidden' })
          json(res, 200, await auth.status())
        },
      }),
      ctx.webServer.register({
        kind: 'exact',
        path: ARK_AUTH_API_KEY_PATH,
        handler: async (req, res) => {
          if (req.method !== 'POST') return json(res, 405, { error: 'method not allowed' })
          if (!trustedRequest(req)) return json(res, 403, { error: 'forbidden' })
          try {
            const body = await readJsonBody(req) as { apiKey?: unknown; plan?: unknown }
            if (typeof body.apiKey !== 'string') return json(res, 400, { error: 'apiKey required' })
            const plan = typeof body.plan === 'string' && isArkPlanKind(body.plan) ? body.plan : 'coding'
            await auth.saveApiKey(body.apiKey, plan)
            json(res, 200, { ok: true, plan })
          } catch (error: unknown) {
            json(res, 500, { error: safeAuthMessage(error) })
          }
        },
      }),
      ctx.webServer.register({
        kind: 'exact',
        path: ARK_AUTH_LOGOUT_PATH,
        handler: async (req, res) => {
          if (req.method !== 'POST') return json(res, 405, { error: 'method not allowed' })
          if (!trustedRequest(req)) return json(res, 403, { error: 'forbidden' })
          await auth.signOut()
          json(res, 200, { ok: true })
        },
      }),
    ]
    return () => {
      for (const dispose of routes) dispose()
    }
  }, 'dsh-coding-plans: Ark Web auth routes')
}
