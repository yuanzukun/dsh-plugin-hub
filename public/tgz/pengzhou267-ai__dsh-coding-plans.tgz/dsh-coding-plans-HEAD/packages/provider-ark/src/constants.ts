/** Volcengine Ark Coding Plan / Agent Plan endpoints and model catalog. */

/** OpenAI-compatible Coding Plan base (deducts Coding Plan quota). */
export const ARK_CODING_API_BASE_URL = 'https://ark.cn-beijing.volces.com/api/coding/v3'
/** OpenAI-compatible Agent Plan base (deducts Agent Plan quota). */
export const ARK_AGENT_API_BASE_URL = 'https://ark.cn-beijing.volces.com/api/plan/v3'

export type ArkPlanKind = 'coding' | 'agent'

export function arkBaseUrl(plan: ArkPlanKind): string {
  return plan === 'agent' ? ARK_AGENT_API_BASE_URL : ARK_CODING_API_BASE_URL
}

export function isArkPlanKind(value: string): value is ArkPlanKind {
  return value === 'coding' || value === 'agent'
}

/** Headers that identify this harness as a coding agent client. */
export function arkCodingHeaders(): Record<string, string> {
  return {
    'User-Agent': 'dsh-coding-plans/0.1.0',
    'X-Client-Request-Id': 'dsh-coding-plans',
  }
}

export interface ArkModelSpec {
  id: string
  name: string
  reasoning: boolean
  contextWindow: number
  maxTokens: number
}

/** Models commonly offered on Ark coding/agent subscriptions. */
export const ARK_MODEL_SPECS: readonly ArkModelSpec[] = [
  {
    id: 'ark-code-latest',
    name: 'Ark Code Latest',
    reasoning: true,
    contextWindow: 256_000,
    maxTokens: 16_384,
  },
  {
    id: 'doubao-seed-code',
    name: 'Doubao Seed Code',
    reasoning: false,
    contextWindow: 256_000,
    maxTokens: 16_384,
  },
  {
    id: 'doubao-seed-2.0-code',
    name: 'Doubao Seed 2.0 Code',
    reasoning: false,
    contextWindow: 256_000,
    maxTokens: 16_384,
  },
]
