/** Ark Coding/Agent Plan credential helpers under `$DSH_HOME/coding-plans/ark-auth.json`. */

import { CodingPlanCredentialStore } from '../../core/src/index.ts'
import { isArkPlanKind } from './constants.ts'
import type { ArkPlanKind } from './constants.ts'

export const ARK_PI_PROVIDER = 'ark-coding'
export const ARK_DSH_ROUTE = 'coding-plans-ark'
export const ARK_DSH_ROUTE_AGENT = 'coding-plans-ark-agent'
export const ARK_AUTH_FILENAME = 'ark-auth.json'

export function createArkCredentialStore(dshHome?: string): CodingPlanCredentialStore {
  return new CodingPlanCredentialStore(ARK_PI_PROVIDER, ARK_AUTH_FILENAME, dshHome)
}

export function arkAuthPath(dshHome?: string): string {
  return createArkCredentialStore(dshHome).filename
}

export interface ArkAuthStatus {
  authenticated: boolean
  plan?: ArkPlanKind
}

export async function arkAuthStatus(
  store: CodingPlanCredentialStore = createArkCredentialStore(),
): Promise<ArkAuthStatus> {
  const credential = await store.read(ARK_PI_PROVIDER)
  if (credential?.type !== 'oauth') return { authenticated: false }
  const planRaw = String(credential.accountId)
  return {
    authenticated: true,
    plan: isArkPlanKind(planRaw) ? planRaw : 'coding',
  }
}

export async function logoutArk(
  store: CodingPlanCredentialStore = createArkCredentialStore(),
): Promise<void> {
  await store.delete(ARK_PI_PROVIDER)
}

export async function saveArkApiKey(
  store: CodingPlanCredentialStore,
  apiKey: string,
  plan: ArkPlanKind = 'coding',
): Promise<void> {
  const key = apiKey.trim()
  if (key.length < 8) throw new Error('ark: API key looks empty')
  if (!isArkPlanKind(plan)) throw new Error('ark: plan must be coding or agent')
  await store.modify(ARK_PI_PROVIDER, async () => ({
    type: 'oauth',
    access: key,
    refresh: 'api-key',
    expires: Date.now() + 10 * 365 * 24 * 60 * 60_000,
    accountId: plan,
  }))
}

export async function resolveArkAccessToken(
  store: CodingPlanCredentialStore,
): Promise<{ accessToken: string; plan: ArkPlanKind }> {
  const credential = await store.read(ARK_PI_PROVIDER)
  if (credential?.type !== 'oauth') throw new Error('ark: signed out')
  const planRaw = String(credential.accountId)
  return {
    accessToken: String(credential.access),
    plan: isArkPlanKind(planRaw) ? planRaw : 'coding',
  }
}
