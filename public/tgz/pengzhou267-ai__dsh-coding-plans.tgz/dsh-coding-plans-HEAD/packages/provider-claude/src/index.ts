/**
 * Claude Max/Pro coding-plan provider — deferred (implement last).
 *
 * Port target: CLIProxyAPI Claude OAuth + Anthropic Messages SSE.
 * See docs/provider-porting.md.
 */

import type { CodingPlanProviderMeta } from '../../core/src/index.ts'

export const CLAUDE_DSH_ROUTE = 'coding-plans-claude'
export const CLAUDE_AUTH_FILENAME = 'claude-auth.json'

export const claudeProviderMeta: CodingPlanProviderMeta = {
  id: 'claude',
  displayName: 'Claude Max / Pro (deferred)',
  status: 'stub',
}

/**
 * Placeholder — Claude is intentionally last on the roadmap.
 * @throws always — not implemented yet.
 */
export function createClaudeAdapter(): never {
  throw new Error(
    'coding-plans: Claude provider is deferred (last). See docs/provider-porting.md and packages/provider-claude.',
  )
}
