/** Live ChatGPT Codex rate-limit usage for the browser account page. */

import { createModels } from '@earendil-works/pi-ai'
import { openaiCodexProvider } from '@earendil-works/pi-ai/providers/openai-codex'
import type { CodingPlanCredentialStore } from '../../core/src/index.ts'
import { CODEX_PI_PROVIDER } from './auth.ts'

/** Fixed endpoint used by the official Codex client for ChatGPT rate limits. */
export const OPENAI_CODEX_USAGE_URL = 'https://chatgpt.com/backend-api/wham/usage'

const USAGE_REQUEST_TIMEOUT_MS = 15_000

/** One quota window expressed as remaining capacity for direct UI rendering. */
export interface OpenAICodexRateLimitWindow {
  /** Percent still available in this window. */
  readonly remainingPercent: number
  /** Server-declared rolling-window length in seconds. */
  readonly windowSeconds: number
}

/** One separately metered Codex quota bucket. */
export interface OpenAICodexRateLimit {
  /** Stable server feature id. */
  readonly id: string
  /** Optional server-provided display name. */
  readonly name?: string
  /** Available rolling windows for this bucket. */
  readonly windows: readonly OpenAICodexRateLimitWindow[]
}

/** Optional exact prepaid-credit balance returned by ChatGPT. */
export interface OpenAICodexCredits {
  /** Whether the balance is unmetered. */
  readonly unlimited: boolean
  /** Exact provider-formatted balance when finite and disclosed. */
  readonly balance?: string
}

/** Optional exact workspace member spend limit returned by ChatGPT. */
export interface OpenAICodexIndividualLimit {
  /** Exact configured limit. */
  readonly limit: string
  /** Exact amount consumed. */
  readonly used: string
  /** Exact amount still available. */
  readonly remaining: string
  /** Percent still available for progress rendering. */
  readonly remainingPercent: number
}

/** Secret-free quota projection returned to the browser. */
export interface OpenAICodexUsage {
  /** Rolling Codex rate-limit buckets. */
  readonly rateLimits: readonly OpenAICodexRateLimit[]
  /** Exact prepaid-credit balance when supported for this account. */
  readonly credits?: OpenAICodexCredits
  /** Exact workspace member limit when supported for this account. */
  readonly individualLimit?: OpenAICodexIndividualLimit
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function parseWindow(value: unknown): OpenAICodexRateLimitWindow | undefined {
  if (value === undefined || value === null) return undefined
  if (!isRecord(value)) throw new Error('OpenAI Codex returned a malformed rate-limit window')
  const usedPercent = value['used_percent']
  const windowSeconds = value['limit_window_seconds']
  if (typeof usedPercent !== 'number' || !Number.isFinite(usedPercent) || usedPercent < 0 || usedPercent > 100) {
    throw new Error('OpenAI Codex returned an invalid used percentage')
  }
  if (typeof windowSeconds !== 'number' || !Number.isInteger(windowSeconds) || windowSeconds <= 0) {
    throw new Error('OpenAI Codex returned an invalid rate-limit window duration')
  }
  return { remainingPercent: 100 - usedPercent, windowSeconds }
}

function parseLimit(id: string, name: string | undefined, value: unknown): OpenAICodexRateLimit | undefined {
  if (value === undefined || value === null) return undefined
  if (!isRecord(value)) throw new Error('OpenAI Codex returned malformed rate-limit details')
  const windows = [parseWindow(value['primary_window']), parseWindow(value['secondary_window'])]
    .filter(window => window !== undefined)
  return windows.length === 0 ? undefined : { id, ...name === undefined ? {} : { name }, windows }
}

function exactAmount(record: Record<string, unknown>, key: string): string {
  const value = record[key]
  if (typeof value !== 'string' || value.length === 0 || value.length > 64 || !/^-?\d+(?:\.\d+)?$/u.test(value)) {
    throw new Error(`OpenAI Codex returned an invalid ${key} amount`)
  }
  return value
}

function parseCredits(value: unknown): OpenAICodexCredits | undefined {
  if (value === undefined || value === null) return undefined
  if (!isRecord(value) || typeof value['has_credits'] !== 'boolean' || typeof value['unlimited'] !== 'boolean') {
    throw new Error('OpenAI Codex returned malformed credit details')
  }
  if (!value['has_credits']) return undefined
  const balance = value['balance']
  if (balance !== undefined && balance !== null
    && (typeof balance !== 'string' || balance.length === 0 || balance.length > 64 || !/^-?\d+(?:\.\d+)?$/u.test(balance))) {
    throw new Error('OpenAI Codex returned an invalid credit balance')
  }
  return {
    unlimited: value['unlimited'],
    ...typeof balance === 'string' ? { balance } : {},
  }
}

function parseIndividualLimit(value: unknown): OpenAICodexIndividualLimit | undefined {
  if (value === undefined || value === null) return undefined
  if (!isRecord(value)) throw new Error('OpenAI Codex returned malformed spend-control details')
  const individual = value['individual_limit']
  if (individual === undefined || individual === null) return undefined
  if (!isRecord(individual)) throw new Error('OpenAI Codex returned a malformed individual limit')
  const remainingPercent = individual['remaining_percent']
  if (typeof remainingPercent !== 'number' || !Number.isFinite(remainingPercent)
    || remainingPercent < 0 || remainingPercent > 100) {
    throw new Error('OpenAI Codex returned an invalid individual-limit percentage')
  }
  return {
    limit: exactAmount(individual, 'limit'),
    used: exactAmount(individual, 'used'),
    remaining: exactAmount(individual, 'remaining'),
    remainingPercent,
  }
}

/**
 * Convert the provider response into the small secret-free object sent to the browser.
 * @param value - opaque JSON returned by the ChatGPT usage endpoint.
 * @returns core and additionally metered quota buckets with remaining percentages.
 */
export function parseOpenAICodexUsage(value: unknown): OpenAICodexUsage {
  if (!isRecord(value)) throw new Error('OpenAI Codex returned a malformed usage response')
  const limits: OpenAICodexRateLimit[] = []
  const primary = parseLimit('codex', 'Codex', value['rate_limit'])
  if (primary !== undefined) limits.push(primary)

  const additional = value['additional_rate_limits']
  if (additional !== undefined && additional !== null && !Array.isArray(additional)) {
    throw new Error('OpenAI Codex returned malformed additional rate limits')
  }
  for (const item of additional ?? []) {
    if (!isRecord(item)) throw new Error('OpenAI Codex returned a malformed additional rate limit')
    const id = item['metered_feature']
    const name = item['limit_name']
    if (typeof id !== 'string' || id.length === 0) {
      throw new Error('OpenAI Codex returned an additional rate limit without an id')
    }
    if (name !== undefined && name !== null && typeof name !== 'string') {
      throw new Error('OpenAI Codex returned an invalid additional rate-limit name')
    }
    const limit = parseLimit(id, typeof name === 'string' && name.length > 0 ? name : undefined, item['rate_limit'])
    if (limit !== undefined) limits.push(limit)
  }
  const credits = parseCredits(value['credits'])
  const individualLimit = parseIndividualLimit(value['spend_control'])
  return {
    rateLimits: limits,
    ...credits === undefined ? {} : { credits },
    ...individualLimit === undefined ? {} : { individualLimit },
  }
}

/**
 * Read current quota without issuing a model request. OAuth is refreshed through
 * the same provider-native credential lifecycle used by normal Codex turns.
 * @param store - plugin-owned OAuth credential store.
 * @returns current rate-limit buckets safe to expose to the local browser page.
 */
export async function readCodexRateLimits(
  store: CodingPlanCredentialStore,
): Promise<OpenAICodexUsage> {
  const models = createModels({ credentials: store })
  models.setProvider(openaiCodexProvider())
  const auth = await models.getAuth(CODEX_PI_PROVIDER)
  const credential = await store.read(CODEX_PI_PROVIDER)
  const access = auth?.auth.apiKey
  const accountId = credential?.type === 'oauth' ? credential.accountId : undefined
  if (access === undefined || access.length === 0 || typeof accountId !== 'string' || accountId.length === 0) {
    throw new Error('OpenAI Codex is signed out')
  }
  let response: Response
  try {
    response = await fetch(OPENAI_CODEX_USAGE_URL, {
      method: 'GET',
      redirect: 'error',
      headers: {
        authorization: `Bearer ${access}`,
        'chatgpt-account-id': accountId,
        accept: 'application/json',
        'cache-control': 'no-store',
        'user-agent': 'dsh-coding-plans',
      },
      signal: AbortSignal.timeout(USAGE_REQUEST_TIMEOUT_MS),
    })
  } catch (error: unknown) {
    throw new Error(describeCodexUsageError(error), { cause: error })
  }
  if (!response.ok) {
    throw new Error(response.status === 401 || response.status === 403
      ? 'OpenAI Codex sign-in needs to be renewed'
      : `OpenAI Codex usage request failed with HTTP ${response.status}`)
  }
  let value: unknown
  try {
    value = await response.json()
  } catch (error: unknown) {
    throw new Error('OpenAI Codex returned an unreadable usage response', { cause: error })
  }
  return parseOpenAICodexUsage(value)
}

/**
 * Map Node fetch / undici failures into Settings-safe copy.
 * Connect timeouts to chatgpt.com are common behind restricted networks and
 * are unrelated to whether the ChatGPT account holds a paid Codex plan.
 */
export function describeCodexUsageError(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error)
  const cause = error instanceof Error ? error.cause : undefined
  const causeMessage = cause instanceof Error ? cause.message : typeof cause === 'string' ? cause : ''
  const causeCode = cause !== null && typeof cause === 'object' && 'code' in cause
    ? String((cause as { code?: unknown }).code ?? '')
    : ''
  const blob = `${message}\n${causeMessage}\n${causeCode}`
  if (/UND_ERR_CONNECT_TIMEOUT|ConnectTimeout|connect timeout|ETIMEDOUT|ENETUNREACH|ECONNREFUSED|fetch failed/i.test(blob)) {
    return 'Cannot reach chatgpt.com for quota (network timeout). Sign-in is still valid; a free ChatGPT account usually has no Codex quota.'
  }
  if (/AbortError|TimeoutError|aborted/i.test(blob)) {
    return 'Quota request timed out. Sign-in is still valid.'
  }
  return message.length > 0 ? message : 'OpenAI Codex usage request failed'
}
