/** Codex OAuth login/logout/status helpers. */

import { createModels } from '@earendil-works/pi-ai'
import type { AuthInteraction } from '@earendil-works/pi-ai'
import { openaiCodexProvider } from '@earendil-works/pi-ai/providers/openai-codex'
import { CodingPlanCredentialStore } from '../../core/src/index.ts'

export const CODEX_PI_PROVIDER = 'openai-codex'
export const CODEX_DSH_ROUTE = 'coding-plans-codex'
export const CODEX_AUTH_FILENAME = 'codex-auth.json'

export function createCodexCredentialStore(dshHome?: string): CodingPlanCredentialStore {
  return new CodingPlanCredentialStore(CODEX_PI_PROVIDER, CODEX_AUTH_FILENAME, dshHome)
}

export function codexAuthPath(dshHome?: string): string {
  return createCodexCredentialStore(dshHome).filename
}

export interface CodexAuthStatus {
  authenticated: boolean
  expiresAt?: Date
}

/**
 * pi-ai's openai-codex OAuth binds `node:crypto` / `node:http` via fire-and-forget
 * dynamic import. Calling login before those settle throws
 * "only available in Node.js environments" even under Node.
 */
async function waitForPiAiNodeOAuth(): Promise<void> {
  await Promise.all([import('node:crypto'), import('node:http')])
  await new Promise<void>((resolve) => setImmediate(resolve))
}

function isPiAiNodeOAuthRace(error: unknown): boolean {
  return error instanceof Error
    && error.message.includes('OpenAI Codex OAuth is only available in Node.js environments')
}

export async function loginCodex(
  interaction: AuthInteraction,
  store: CodingPlanCredentialStore = createCodexCredentialStore(),
): Promise<void> {
  await waitForPiAiNodeOAuth()
  const models = createModels({ credentials: store })
  models.setProvider(openaiCodexProvider())
  try {
    await models.login(CODEX_PI_PROVIDER, 'oauth', interaction)
  } catch (error) {
    if (!isPiAiNodeOAuthRace(error)) throw error
    await waitForPiAiNodeOAuth()
    await new Promise<void>((resolve) => setTimeout(resolve, 50))
    await models.login(CODEX_PI_PROVIDER, 'oauth', interaction)
  }
}

export async function logoutCodex(
  store: CodingPlanCredentialStore = createCodexCredentialStore(),
): Promise<void> {
  await store.delete(CODEX_PI_PROVIDER)
}

export async function codexAuthStatus(
  store: CodingPlanCredentialStore = createCodexCredentialStore(),
): Promise<CodexAuthStatus> {
  const credential = await store.read(CODEX_PI_PROVIDER)
  return credential?.type === 'oauth'
    ? { authenticated: true, expiresAt: new Date(credential.expires) }
    : { authenticated: false }
}
