/** OpenAI Codex adapter via dsh-llm-pi-ai + pi-ai openai-codex. */

import { createModels } from '@earendil-works/pi-ai'
import type { MutableModels, Provider } from '@earendil-works/pi-ai'
import { openaiCodexProvider } from '@earendil-works/pi-ai/providers/openai-codex'
import { resolveRetryPolicy } from '@deepseek-ai/dsh-llm'
import { PiAiAdapter } from '@deepseek-ai/dsh-llm-pi-ai'
import type { ResolvedPiAiProviderProfile } from '@deepseek-ai/dsh-llm-pi-ai'
import type { CodingPlanCredentialStore } from '../../core/src/index.ts'
import { CODEX_DSH_ROUTE, CODEX_PI_PROVIDER } from './auth.ts'

export const CODEX_STREAM_IDLE_TIMEOUT_MS = 300_000

function requestProvider(provider: Provider): Provider {
  return {
    ...provider,
    auth: {
      ...provider.auth,
      apiKey: {
        name: 'OpenAI Codex OAuth bearer token',
        async resolve({ credential }) {
          const apiKey = credential?.key
          return apiKey === undefined || apiKey.length === 0
            ? undefined
            : { auth: { apiKey }, source: 'OAuth' }
        },
      },
    },
  }
}

export function createCodexAdapter(credentials: CodingPlanCredentialStore): PiAiAdapter {
  const provider = openaiCodexProvider()
  const profiles = new Map<string, ResolvedPiAiProviderProfile>([[CODEX_DSH_ROUTE, {
    provider: CODEX_DSH_ROUTE,
    displayName: 'Coding Plans · Codex',
    streamIdleTimeoutMs: CODEX_STREAM_IDLE_TIMEOUT_MS,
    retryPolicy: resolveRetryPolicy(undefined, 'dsh-coding-plans-codex retryPolicy'),
    configuredMaxTokens: new Map(),
    piProvider: requestProvider(provider),
  }]])
  const models: MutableModels = createModels({ credentials })
  models.setProvider(provider)
  return new PiAiAdapter({
    profiles: () => profiles,
    resolveApiKey: async () => (await models.getAuth(CODEX_PI_PROVIDER))?.auth.apiKey,
  })
}
