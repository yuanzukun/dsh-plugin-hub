/**
 * ChatGPT / Codex coding-plan provider for DeepSeek Harness.
 *
 * Protocol and OAuth follow `@earendil-works/pi-ai` openai-codex (same surface as
 * CLIProxyAPI Codex OAuth and community `dsh-codex`). Credentials are stored under
 * `$DSH_HOME/coding-plans/codex-auth.json` — never `~/.codex/auth.json`.
 */

import type { CodingPlanProviderMeta } from '../../core/src/index.ts'

export {
  CODEX_PI_PROVIDER,
  CODEX_DSH_ROUTE,
  CODEX_AUTH_FILENAME,
  createCodexCredentialStore,
  codexAuthPath,
  loginCodex,
  logoutCodex,
  codexAuthStatus,
} from './auth.ts'
export type { CodexAuthStatus } from './auth.ts'
export { createCodexAdapter, CODEX_STREAM_IDLE_TIMEOUT_MS } from './adapter.ts'
export {
  OPENAI_CODEX_USAGE_URL,
  describeCodexUsageError,
  parseOpenAICodexUsage,
  readCodexRateLimits,
} from './usage.ts'
export type {
  OpenAICodexCredits,
  OpenAICodexIndividualLimit,
  OpenAICodexRateLimit,
  OpenAICodexRateLimitWindow,
  OpenAICodexUsage,
} from './usage.ts'
export {
  registerCodexAuthRoutes,
  CodexWebAuth,
  CODEX_AUTH_STATUS_PATH,
  CODEX_AUTH_LOGIN_PATH,
  CODEX_AUTH_LOGOUT_PATH,
} from './auth-routes.ts'
export type { CodexWebAuthStatus } from './auth-routes.ts'

export const codexProviderMeta: CodingPlanProviderMeta = {
  id: 'codex',
  displayName: 'ChatGPT / Codex',
  status: 'ready',
}
