/**
 * MiniMax Token/Coding Plan — stub for community PRs.
 */

import type { CodingPlanProviderMeta } from '../../core/src/index.ts'

export const MINIMAX_DSH_ROUTE = 'coding-plans-minimax'
export const MINIMAX_AUTH_FILENAME = 'minimax-auth.json'

export const minimaxProviderMeta: CodingPlanProviderMeta = {
  id: 'minimax',
  displayName: 'MiniMax Token/Coding Plan',
  status: 'stub',
}

export function createMinimaxAdapter(): never {
  throw new Error(
    'coding-plans: MiniMax provider is a stub. See docs/provider-porting.md and packages/provider-minimax.',
  )
}
