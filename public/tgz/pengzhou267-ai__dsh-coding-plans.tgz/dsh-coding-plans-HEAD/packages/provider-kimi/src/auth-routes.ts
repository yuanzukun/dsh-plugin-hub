/** Same-origin Web settings routes for Kimi Code device login / API key. */

import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-host-webserver'
import { safeAuthMessage } from '../../core/src/index.ts'
import type { CodingPlanCredentialStore } from '../../core/src/index.ts'
import {
  finishKimiDeviceLogin,
  kimiAuthStatus,
  logoutKimi,
  saveKimiApiKey,
  startKimiDeviceLogin,
} from './auth.ts'
import type { KimiDeviceLoginSession } from './auth.ts'

export const KIMI_AUTH_STATUS_PATH = '/plugins/dsh-coding-plans/kimi/auth/status'
export const KIMI_AUTH_LOGIN_PATH = '/plugins/dsh-coding-plans/kimi/auth/login'
export const KIMI_AUTH_LOGOUT_PATH = '/plugins/dsh-coding-plans/kimi/auth/logout'
export const KIMI_AUTH_API_KEY_PATH = '/plugins/dsh-coding-plans/kimi/auth/api-key'

export type KimiWebAuthStatus =
  | { status: 'signed-out' }
  | { status: 'signing-in'; url: string; userCode?: string }
  | { status: 'signed-in'; mode: 'oauth' | 'api-key' }
  | { status: 'error'; message: string }

function trustedRequest(req: IncomingMessage): boolean {
  const remote = req.socket.remoteAddress
  if (remote !== '127.0.0.1' && remote !== '::1' && remote !== '::ffff:127.0.0.1') return false
  if (req.headers['sec-fetch-site'] === 'cross-site') return false
  const host = req.headers.host
  if (host === undefined) return false
  const origin = req.headers.origin
  if (origin === undefined) return true
  try {
    return new URL(origin).host === new URL(`http://${host}`).host
  } catch {
    return false
  }
}

function json(res: ServerResponse, status: number, value: unknown): void {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
  })
  res.end(JSON.stringify(value))
}

async function readJsonBody(req: IncomingMessage): Promise<unknown> {
  const chunks: Buffer[] = []
  for await (const chunk of req) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
  const text = Buffer.concat(chunks).toString('utf8').trim()
  if (text.length === 0) return {}
  return JSON.parse(text) as unknown
}

export class KimiWebAuth {
  private state: KimiWebAuthStatus = { status: 'signed-out' }
  private operation: Promise<void> | undefined
  private cancellation: AbortController | undefined
  private session: KimiDeviceLoginSession | undefined

  constructor(private readonly store: CodingPlanCredentialStore) {}

  async status(): Promise<KimiWebAuthStatus> {
    if (this.operation !== undefined) return this.state
    if (this.state.status === 'error') return this.state
    const stored = await kimiAuthStatus(this.store)
    if (!stored.authenticated) return { status: 'signed-out' }
    return { status: 'signed-in', mode: stored.mode ?? 'oauth' }
  }

  async signIn(): Promise<{ url: string; userCode?: string }> {
    if (this.operation === undefined) this.startDevice()
    for (let i = 0; i < 50; i++) {
      const session = this.session
      if (session !== undefined) {
        return {
          url: session.url,
          ...session.device.userCode.length > 0 ? { userCode: session.device.userCode } : {},
        }
      }
      if (this.state.status === 'error') throw new Error(this.state.message)
      await new Promise<void>(resolve => setTimeout(resolve, 50))
    }
    throw new Error('kimi: device login challenge was not ready')
  }

  async saveApiKey(apiKey: string): Promise<void> {
    this.cancellation?.abort(new Error('kimi: superseded by API key'))
    await this.operation?.catch(() => undefined)
    await saveKimiApiKey(this.store, apiKey)
    this.state = { status: 'signed-in', mode: 'api-key' }
  }

  async signOut(): Promise<void> {
    this.cancellation?.abort(new Error('kimi: sign-in cancelled'))
    await this.operation?.catch(() => undefined)
    await logoutKimi(this.store)
    this.state = { status: 'signed-out' }
    this.session = undefined
  }

  async dispose(): Promise<void> {
    this.cancellation?.abort(new Error('coding-plans plugin disposed'))
    await this.operation?.catch(() => undefined)
  }

  private startDevice(): void {
    const cancellation = new AbortController()
    this.cancellation = cancellation
    this.session = undefined
    this.state = { status: 'signing-in', url: '' }
    this.operation = (async () => {
      const session = await startKimiDeviceLogin()
      if (cancellation.signal.aborted) throw new Error('kimi: device login cancelled')
      this.session = session
      this.state = {
        status: 'signing-in',
        url: session.url,
        ...session.device.userCode.length > 0 ? { userCode: session.device.userCode } : {},
      }
      await finishKimiDeviceLogin(session, this.store, cancellation.signal)
      this.state = { status: 'signed-in', mode: 'oauth' }
    })().catch((error: unknown) => {
      this.state = { status: 'error', message: safeAuthMessage(error) }
    }).finally(() => {
      this.operation = undefined
      this.cancellation = undefined
      this.session = undefined
    })
  }
}

export function registerKimiAuthRoutes(
  ctx: Context,
  store: CodingPlanCredentialStore,
): void {
  const auth = new KimiWebAuth(store)
  ctx.effect(() => {
    const routes = [
      ctx.webServer.register({
        kind: 'exact',
        path: KIMI_AUTH_STATUS_PATH,
        handler: async (req, res) => {
          if (req.method !== 'GET') return json(res, 405, { error: 'method not allowed' })
          if (!trustedRequest(req)) return json(res, 403, { error: 'forbidden' })
          json(res, 200, await auth.status())
        },
      }),
      ctx.webServer.register({
        kind: 'exact',
        path: KIMI_AUTH_LOGIN_PATH,
        handler: async (req, res) => {
          if (req.method !== 'POST') return json(res, 405, { error: 'method not allowed' })
          if (!trustedRequest(req)) return json(res, 403, { error: 'forbidden' })
          try {
            json(res, 200, await auth.signIn())
          } catch (error: unknown) {
            json(res, 500, { error: safeAuthMessage(error) })
          }
        },
      }),
      ctx.webServer.register({
        kind: 'exact',
        path: KIMI_AUTH_API_KEY_PATH,
        handler: async (req, res) => {
          if (req.method !== 'POST') return json(res, 405, { error: 'method not allowed' })
          if (!trustedRequest(req)) return json(res, 403, { error: 'forbidden' })
          try {
            const body = await readJsonBody(req) as { apiKey?: unknown }
            if (typeof body.apiKey !== 'string') return json(res, 400, { error: 'apiKey required' })
            await auth.saveApiKey(body.apiKey)
            json(res, 200, { ok: true })
          } catch (error: unknown) {
            json(res, 500, { error: safeAuthMessage(error) })
          }
        },
      }),
      ctx.webServer.register({
        kind: 'exact',
        path: KIMI_AUTH_LOGOUT_PATH,
        handler: async (req, res) => {
          if (req.method !== 'POST') return json(res, 405, { error: 'method not allowed' })
          if (!trustedRequest(req)) return json(res, 403, { error: 'forbidden' })
          await auth.signOut()
          json(res, 200, { ok: true })
        },
      }),
    ]
    return async () => {
      for (const dispose of routes) dispose()
      await auth.dispose()
    }
  }, 'dsh-coding-plans: Kimi Web auth routes')
}
