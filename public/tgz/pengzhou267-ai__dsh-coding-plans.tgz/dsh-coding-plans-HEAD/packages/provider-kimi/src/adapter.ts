/** Kimi Code LlmAdapter via pi-ai openai-completions + coding headers. */

import { createModels, createProvider } from '@earendil-works/pi-ai'
import type { Model, MutableModels, Provider } from '@earendil-works/pi-ai'
import { openAICompletionsApi } from '@earendil-works/pi-ai/api/openai-completions.lazy'
import { resolveRetryPolicy } from '@deepseek-ai/dsh-llm'
import { PiAiAdapter } from '@deepseek-ai/dsh-llm-pi-ai'
import type { ResolvedPiAiProviderProfile } from '@deepseek-ai/dsh-llm-pi-ai'
import type { CodingPlanCredentialStore } from '../../core/src/index.ts'
import { KIMI_DSH_ROUTE, KIMI_PI_PROVIDER, resolveKimiAccessToken } from './auth.ts'
import { KIMI_CODING_API_BASE_URL, kimiCodingHeaders } from './device-flow.ts'

export const KIMI_STREAM_IDLE_TIMEOUT_MS = 300_000

const KIMI_MODELS: readonly Model<'openai-completions'>[] = [
  {
    id: 'kimi-for-coding',
    name: 'Kimi For Coding',
    api: 'openai-completions',
    provider: KIMI_PI_PROVIDER,
    baseUrl: KIMI_CODING_API_BASE_URL,
    reasoning: false,
    input: ['text'],
    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
    contextWindow: 262_144,
    maxTokens: 8192,
  },
  {
    id: 'k3',
    name: 'Kimi K3',
    api: 'openai-completions',
    provider: KIMI_PI_PROVIDER,
    baseUrl: KIMI_CODING_API_BASE_URL,
    reasoning: true,
    input: ['text'],
    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
    contextWindow: 1_048_576,
    maxTokens: 16_384,
  },
  {
    id: 'k3-256k',
    name: 'Kimi K3 256k',
    api: 'openai-completions',
    provider: KIMI_PI_PROVIDER,
    baseUrl: KIMI_CODING_API_BASE_URL,
    reasoning: true,
    input: ['text'],
    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
    contextWindow: 262_144,
    maxTokens: 16_384,
  },
  {
    id: 'kimi-for-coding-highspeed',
    name: 'Kimi For Coding Highspeed',
    api: 'openai-completions',
    provider: KIMI_PI_PROVIDER,
    baseUrl: KIMI_CODING_API_BASE_URL,
    reasoning: false,
    input: ['text'],
    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
    contextWindow: 262_144,
    maxTokens: 8192,
  },
]

function kimiProvider(): Provider<'openai-completions'> {
  return createProvider({
    id: KIMI_PI_PROVIDER,
    name: 'Kimi Code',
    baseUrl: KIMI_CODING_API_BASE_URL,
    headers: kimiCodingHeaders(),
    auth: {
      apiKey: {
        name: 'Kimi Coding bearer / API key',
        async resolve({ credential }) {
          const apiKey = credential?.key
          return apiKey === undefined || apiKey.length === 0
            ? undefined
            : { auth: { apiKey }, source: 'OAuth' }
        },
      },
    },
    models: KIMI_MODELS,
    api: openAICompletionsApi(),
  })
}

export function createKimiAdapter(credentials: CodingPlanCredentialStore): PiAiAdapter {
  const provider = kimiProvider()
  const profiles = new Map<string, ResolvedPiAiProviderProfile>([[KIMI_DSH_ROUTE, {
    provider: KIMI_DSH_ROUTE,
    displayName: 'Coding Plans · Kimi',
    streamIdleTimeoutMs: KIMI_STREAM_IDLE_TIMEOUT_MS,
    retryPolicy: resolveRetryPolicy(undefined, 'dsh-coding-plans-kimi retryPolicy'),
    configuredMaxTokens: new Map(),
    piProvider: provider,
  }]])
  const models: MutableModels = createModels({ credentials })
  models.setProvider(provider)
  return new PiAiAdapter({
    profiles: () => profiles,
    resolveApiKey: async () => (await resolveKimiAccessToken(credentials)).accessToken,
  })
}
