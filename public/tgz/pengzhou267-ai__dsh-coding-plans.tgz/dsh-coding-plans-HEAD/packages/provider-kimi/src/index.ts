/**
 * Kimi Code coding-plan provider for DeepSeek Harness.
 *
 * Device-flow OAuth and Coding API headers follow CLIProxyAPI `internal/auth/kimi`
 * and community coding-agent requirements (User-Agent: KimiCLI/…). Credentials
 * live under `$DSH_HOME/coding-plans/kimi-auth.json` — never CLI home auth files.
 */

import type { CodingPlanProviderMeta } from '../../core/src/index.ts'

export {
  KIMI_PI_PROVIDER,
  KIMI_DSH_ROUTE,
  KIMI_AUTH_FILENAME,
  KIMI_API_KEY_ACCOUNT,
  createKimiCredentialStore,
  kimiAuthPath,
  kimiAuthStatus,
  logoutKimi,
  loginKimiDevice,
  startKimiDeviceLogin,
  finishKimiDeviceLogin,
  saveKimiApiKey,
  saveKimiToken,
  resolveKimiAccessToken,
} from './auth.ts'
export type { KimiAuthStatus, KimiDeviceLoginSession } from './auth.ts'
export {
  KIMI_CODING_API_BASE_URL,
  KIMI_CLI_USER_AGENT,
  kimiCodingHeaders,
  requestKimiDeviceCode,
  pollKimiDeviceToken,
  refreshKimiAccessToken,
} from './device-flow.ts'
export type { KimiDeviceCode, KimiTokenData } from './device-flow.ts'
export { createKimiAdapter, KIMI_STREAM_IDLE_TIMEOUT_MS } from './adapter.ts'
export {
  registerKimiAuthRoutes,
  KimiWebAuth,
  KIMI_AUTH_STATUS_PATH,
  KIMI_AUTH_LOGIN_PATH,
  KIMI_AUTH_LOGOUT_PATH,
  KIMI_AUTH_API_KEY_PATH,
} from './auth-routes.ts'
export type { KimiWebAuthStatus } from './auth-routes.ts'

export const kimiProviderMeta: CodingPlanProviderMeta = {
  id: 'kimi',
  displayName: 'Kimi Code',
  status: 'ready',
}
