/**
 * Kimi Code OAuth2 device authorization grant.
 * Ported from CLIProxyAPI `internal/auth/kimi` (RFC 8628).
 */

import { hostname } from 'node:os'
import { randomUUID } from 'node:crypto'

/** Kimi Code OAuth client id (same as CLIProxyAPI / Kimi CLI). */
export const KIMI_OAUTH_CLIENT_ID = '17e5f671-d194-4dfb-9706-5516cb48c098'
export const KIMI_OAUTH_HOST = 'https://auth.kimi.com'
export const KIMI_DEVICE_CODE_URL = `${KIMI_OAUTH_HOST}/api/oauth/device_authorization`
export const KIMI_TOKEN_URL = `${KIMI_OAUTH_HOST}/api/oauth/token`
/** OpenAI-compatible Coding Plan base (with /v1). */
export const KIMI_CODING_API_BASE_URL = 'https://api.kimi.com/coding/v1'
export const KIMI_CLI_USER_AGENT = 'KimiCLI/1.10.6'
export const KIMI_PLUGIN_PLATFORM = 'dsh-coding-plans'
export const KIMI_PLUGIN_VERSION = '0.1.0'

const DEFAULT_POLL_INTERVAL_MS = 5_000
const MAX_POLL_MS = 15 * 60_000
const HTTP_TIMEOUT_MS = 30_000

export interface KimiDeviceCode {
  deviceCode: string
  userCode: string
  verificationUri: string
  verificationUriComplete?: string
  expiresIn: number
  intervalSeconds: number
}

export interface KimiTokenData {
  accessToken: string
  refreshToken: string
  tokenType: string
  expiresAtUnix: number
  scope: string
  deviceId: string
}

function deviceModel(): string {
  return `${process.platform} ${process.arch}`
}

export function kimiCommonHeaders(deviceId: string): Record<string, string> {
  return {
    'User-Agent': KIMI_CLI_USER_AGENT,
    'X-Msh-Platform': KIMI_PLUGIN_PLATFORM,
    'X-Msh-Version': KIMI_PLUGIN_VERSION,
    'X-Msh-Device-Name': hostname() || 'unknown',
    'X-Msh-Device-Model': deviceModel(),
    'X-Msh-Device-Id': deviceId,
  }
}

export function kimiCodingHeaders(deviceId?: string): Record<string, string> {
  return {
    'User-Agent': KIMI_CLI_USER_AGENT,
    'X-Msh-Platform': 'kimi_cli',
    'X-Msh-Version': KIMI_PLUGIN_VERSION,
    ...deviceId !== undefined && deviceId.length > 0 && deviceId !== 'api-key'
      ? { 'X-Msh-Device-Id': deviceId }
      : {},
  }
}

async function postForm(
  url: string,
  body: URLSearchParams,
  headers: Record<string, string>,
): Promise<{ status: number; json: Record<string, unknown> }> {
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'content-type': 'application/x-www-form-urlencoded',
      accept: 'application/json',
      ...headers,
    },
    body,
    signal: AbortSignal.timeout(HTTP_TIMEOUT_MS),
  })
  const text = await response.text()
  let json: Record<string, unknown> = {}
  try {
    json = text.length === 0 ? {} : JSON.parse(text) as Record<string, unknown>
  } catch {
    throw new Error(`kimi: non-JSON response (HTTP ${response.status}): ${text.slice(0, 200)}`)
  }
  return { status: response.status, json }
}

function asString(value: unknown): string {
  return typeof value === 'string' ? value : ''
}

function asNumber(value: unknown): number {
  return typeof value === 'number' && Number.isFinite(value) ? value : 0
}

export async function requestKimiDeviceCode(deviceId: string = randomUUID()): Promise<{
  device: KimiDeviceCode
  deviceId: string
}> {
  const { status, json } = await postForm(
    KIMI_DEVICE_CODE_URL,
    new URLSearchParams({ client_id: KIMI_OAUTH_CLIENT_ID }),
    kimiCommonHeaders(deviceId),
  )
  if (status !== 200) {
    throw new Error(`kimi: device code request failed with HTTP ${status}`)
  }
  const deviceCode = asString(json['device_code'])
  const userCode = asString(json['user_code'])
  const verificationUri = asString(json['verification_uri']) || asString(json['verification_url'])
  const verificationUriComplete = asString(json['verification_uri_complete']) || undefined
  if (deviceCode.length === 0 || verificationUri.length === 0) {
    throw new Error('kimi: device code response missing device_code or verification_uri')
  }
  return {
    deviceId,
    device: {
      deviceCode,
      userCode,
      verificationUri,
      ...verificationUriComplete === undefined ? {} : { verificationUriComplete },
      expiresIn: asNumber(json['expires_in']) || 1800,
      intervalSeconds: Math.max(asNumber(json['interval']) || 5, 5),
    },
  }
}

function parseTokenPayload(json: Record<string, unknown>, deviceId: string): KimiTokenData {
  const accessToken = asString(json['access_token'])
  if (accessToken.length === 0) throw new Error('kimi: empty access_token')
  const expiresIn = asNumber(json['expires_in'])
  return {
    accessToken,
    refreshToken: asString(json['refresh_token']) || 'none',
    tokenType: asString(json['token_type']) || 'Bearer',
    expiresAtUnix: expiresIn > 0 ? Math.floor(Date.now() / 1000) + Math.floor(expiresIn) : 0,
    scope: asString(json['scope']),
    deviceId,
  }
}

/**
 * Poll until the user authorizes the device code.
 * @returns token bundle or throws on denial / expiry.
 */
export async function pollKimiDeviceToken(
  device: KimiDeviceCode,
  deviceId: string,
  signal?: AbortSignal,
): Promise<KimiTokenData> {
  const intervalMs = Math.max(device.intervalSeconds * 1000, DEFAULT_POLL_INTERVAL_MS)
  const deadline = Date.now() + Math.min(
    MAX_POLL_MS,
    device.expiresIn > 0 ? device.expiresIn * 1000 : MAX_POLL_MS,
  )
  while (true) {
    if (signal?.aborted) throw new Error('kimi: device login cancelled')
    if (Date.now() > deadline) throw new Error('kimi: device code expired')
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(resolve, intervalMs)
      const onAbort = () => {
        clearTimeout(timer)
        reject(new Error('kimi: device login cancelled'))
      }
      if (signal === undefined) return
      if (signal.aborted) {
        clearTimeout(timer)
        reject(new Error('kimi: device login cancelled'))
        return
      }
      signal.addEventListener('abort', onAbort, { once: true })
    })
    const { json } = await postForm(
      KIMI_TOKEN_URL,
      new URLSearchParams({
        client_id: KIMI_OAUTH_CLIENT_ID,
        device_code: device.deviceCode,
        grant_type: 'urn:ietf:params:oauth:grant-type:device_code',
      }),
      kimiCommonHeaders(deviceId),
    )
    const error = asString(json['error'])
    if (error === 'authorization_pending' || error === 'slow_down') continue
    if (error === 'expired_token') throw new Error('kimi: device code expired')
    if (error === 'access_denied') throw new Error('kimi: access denied by user')
    if (error.length > 0) {
      throw new Error(`kimi: OAuth error: ${error} ${asString(json['error_description'])}`.trim())
    }
    return parseTokenPayload(json, deviceId)
  }
}

export async function refreshKimiAccessToken(
  refreshToken: string,
  deviceId: string,
): Promise<KimiTokenData> {
  if (refreshToken.length === 0 || refreshToken === 'none' || refreshToken === 'api-key') {
    throw new Error('kimi: refresh token unavailable (API-key credentials cannot refresh)')
  }
  const { status, json } = await postForm(
    KIMI_TOKEN_URL,
    new URLSearchParams({
      client_id: KIMI_OAUTH_CLIENT_ID,
      grant_type: 'refresh_token',
      refresh_token: refreshToken,
    }),
    kimiCommonHeaders(deviceId),
  )
  if (status === 401 || status === 403) {
    throw new Error('kimi: refresh token rejected; sign in again')
  }
  if (status !== 200) throw new Error(`kimi: refresh failed with HTTP ${status}`)
  const next = parseTokenPayload(json, deviceId)
  if (next.refreshToken === 'none') next.refreshToken = refreshToken
  return next
}
