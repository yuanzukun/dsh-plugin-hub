/** Kimi Code login / logout / status against `$DSH_HOME/coding-plans/kimi-auth.json`. */

import type { OAuthCredential } from '@earendil-works/pi-ai'
import { CodingPlanCredentialStore } from '../../core/src/index.ts'
import {
  pollKimiDeviceToken,
  refreshKimiAccessToken,
  requestKimiDeviceCode,
} from './device-flow.ts'
import type { KimiDeviceCode, KimiTokenData } from './device-flow.ts'

export const KIMI_PI_PROVIDER = 'kimi-coding'
export const KIMI_DSH_ROUTE = 'coding-plans-kimi'
export const KIMI_AUTH_FILENAME = 'kimi-auth.json'
/** accountId marker for Advanced API-key credentials. */
export const KIMI_API_KEY_ACCOUNT = 'api-key'
const REFRESH_SKEW_MS = 5 * 60_000

export function createKimiCredentialStore(dshHome?: string): CodingPlanCredentialStore {
  return new CodingPlanCredentialStore(KIMI_PI_PROVIDER, KIMI_AUTH_FILENAME, dshHome)
}

export function kimiAuthPath(dshHome?: string): string {
  return createKimiCredentialStore(dshHome).filename
}

export interface KimiAuthStatus {
  authenticated: boolean
  mode?: 'oauth' | 'api-key'
  expiresAt?: Date
}

function toCredential(token: KimiTokenData): OAuthCredential {
  return {
    type: 'oauth',
    access: token.accessToken,
    refresh: token.refreshToken.length > 0 ? token.refreshToken : 'none',
    expires: token.expiresAtUnix > 0
      ? token.expiresAtUnix * 1000
      : Date.now() + 60 * 60_000,
    accountId: token.deviceId.length > 0 ? token.deviceId : 'kimi',
  }
}

export async function saveKimiToken(
  store: CodingPlanCredentialStore,
  token: KimiTokenData,
): Promise<void> {
  await store.modify(KIMI_PI_PROVIDER, async () => toCredential(token))
}

export async function saveKimiApiKey(
  store: CodingPlanCredentialStore,
  apiKey: string,
): Promise<void> {
  const key = apiKey.trim()
  if (key.length < 8) throw new Error('kimi: API key looks empty')
  await store.modify(KIMI_PI_PROVIDER, async () => ({
    type: 'oauth',
    access: key,
    refresh: 'api-key',
    expires: Date.now() + 10 * 365 * 24 * 60 * 60_000,
    accountId: KIMI_API_KEY_ACCOUNT,
  }))
}

export async function kimiAuthStatus(
  store: CodingPlanCredentialStore = createKimiCredentialStore(),
): Promise<KimiAuthStatus> {
  const credential = await store.read(KIMI_PI_PROVIDER)
  if (credential?.type !== 'oauth') return { authenticated: false }
  return {
    authenticated: true,
    mode: credential.accountId === KIMI_API_KEY_ACCOUNT ? 'api-key' : 'oauth',
    expiresAt: new Date(credential.expires),
  }
}

export async function logoutKimi(
  store: CodingPlanCredentialStore = createKimiCredentialStore(),
): Promise<void> {
  await store.delete(KIMI_PI_PROVIDER)
}

export interface KimiDeviceLoginSession {
  deviceId: string
  device: KimiDeviceCode
  /** Absolute URL to open (prefers verification_uri_complete). */
  url: string
}

export async function startKimiDeviceLogin(): Promise<KimiDeviceLoginSession> {
  const { device, deviceId } = await requestKimiDeviceCode()
  const url = device.verificationUriComplete ?? device.verificationUri
  return { deviceId, device, url }
}

export async function finishKimiDeviceLogin(
  session: KimiDeviceLoginSession,
  store: CodingPlanCredentialStore = createKimiCredentialStore(),
  signal?: AbortSignal,
): Promise<void> {
  const token = await pollKimiDeviceToken(session.device, session.deviceId, signal)
  await saveKimiToken(store, token)
}

/**
 * CLI helper: run full device flow with optional progress callbacks.
 */
export async function loginKimiDevice(
  options: {
    store?: CodingPlanCredentialStore
    signal?: AbortSignal
    onChallenge?: (session: KimiDeviceLoginSession) => void
  } = {},
): Promise<void> {
  const store = options.store ?? createKimiCredentialStore()
  const session = await startKimiDeviceLogin()
  options.onChallenge?.(session)
  await finishKimiDeviceLogin(session, store, options.signal)
}

/** Resolve a usable bearer token, refreshing OAuth when near expiry. */
export async function resolveKimiAccessToken(
  store: CodingPlanCredentialStore,
): Promise<{ accessToken: string; deviceId: string }> {
  const credential = await store.read(KIMI_PI_PROVIDER)
  if (credential?.type !== 'oauth') throw new Error('kimi: signed out')
  const accessToken = String(credential.access)
  const deviceId = String(credential.accountId)
  const refresh = String(credential.refresh)
  if (refresh === 'api-key' || deviceId === KIMI_API_KEY_ACCOUNT) {
    return { accessToken, deviceId }
  }
  if (Number(credential.expires) > Date.now() + REFRESH_SKEW_MS) {
    return { accessToken, deviceId }
  }
  const token = await refreshKimiAccessToken(refresh, deviceId)
  await saveKimiToken(store, token)
  return { accessToken: token.accessToken, deviceId: token.deviceId }
}
