/**
 * Zhipu GLM Coding Plan — stub for community PRs.
 * Port target: GLM Coding Plan key / OAuth (see docs/provider-porting.md).
 */

import type { CodingPlanProviderMeta } from '../../core/src/index.ts'

export const GLM_DSH_ROUTE = 'coding-plans-glm'
export const GLM_AUTH_FILENAME = 'glm-auth.json'

export const glmProviderMeta: CodingPlanProviderMeta = {
  id: 'glm',
  displayName: 'Zhipu GLM Coding Plan',
  status: 'stub',
}

export function createGlmAdapter(): never {
  throw new Error(
    'coding-plans: GLM provider is a stub. See docs/provider-porting.md and packages/provider-glm.',
  )
}
