import { defineConfig } from 'tsdown'

/** Specifiers the dsh web shell seeds into the frozen module table (must stay external). */
const CLIENT_EXTERNALS = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-web-react',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-attachment',
  '@deepseek-ai/dsh-client-schema-form',
  // Documented temporary exemption — same as packages/client/tsdown.client.ts
  '@deepseek-ai/dsh-client-runtime/client',
] as const

const PLUGIN_ID = 'dsh-coding-plans'

export default defineConfig([
  {
    entry: {
      index: 'src/index.ts',
      bin: 'src/bin.ts',
    },
    format: ['esm'],
    dts: true,
    outDir: 'lib',
    platform: 'node',
    target: 'node22',
    clean: true,
    external: [
      /^@deepseek-ai\//,
      /^@earendil-works\//,
      'react',
      'react-dom',
      'react/jsx-runtime',
    ],
  },
  {
    name: `${PLUGIN_ID}/client`,
    entry: {
      client: 'src/client/index.tsx',
    },
    // Lazy CJS factory for window.__ModuleLoader__.load — see dsh clientBundle.
    format: 'cjs',
    dts: false,
    outDir: 'lib',
    platform: 'browser',
    target: 'es2022',
    sourcemap: true,
    clean: false,
    external: [...CLIENT_EXTERNALS],
    define: {
      'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'production'),
      'import.meta.env.MODE': JSON.stringify(process.env.NODE_ENV ?? 'production'),
      'import.meta.env': JSON.stringify({ MODE: process.env.NODE_ENV ?? 'production' }),
    },
    noExternal: (id: string) => (CLIENT_EXTERNALS.includes(id as (typeof CLIENT_EXTERNALS)[number]) ? undefined : true),
    outputOptions: {
      entryFileNames: 'client.js',
      banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify(PLUGIN_ID)}, factory: (require) => {`,
      footer: 'return module.exports; } });',
      intro: 'var module = { exports: {} }; var exports = module.exports;',
    },
  },
])
