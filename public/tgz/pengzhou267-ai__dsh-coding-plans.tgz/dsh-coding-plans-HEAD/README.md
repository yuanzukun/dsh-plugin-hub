# dsh-coding-plans

[中文](README.zh.md) | English

Use **multiple coding-plan subscriptions** inside [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) via **native OAuth / coding-endpoint LLM adapters** — no CLIProxyAPI subprocess.

> Community plugin; not affiliated with OpenAI, Anthropic, Google, Moonshot, or DeepSeek. Upstream APIs are unofficial and may break or violate vendor ToS — use at your own risk.

## Status

| Provider | Status | Auth |
| --- | --- | --- |
| ChatGPT / Codex | **Ready** | Settings → **Sign in with ChatGPT** (browser OAuth / device code) |
| Kimi Code | **Ready** | Settings → **Sign in with Kimi** (device flow) or Advanced API key |
| Volcengine Ark Coding/Agent Plan | **Ready** | Settings → pick plan + paste console API key |
| Zhipu GLM / MiniMax / Bailian / Tencent | Stub | PRs welcome — [docs/provider-porting.md](docs/provider-porting.md) |
| Gemini / Antigravity | Stub | PRs welcome |
| Claude Max / Pro | **Deferred (last)** | Stub |
| Copilot / Cursor | Later | — |

### Codex caveats

- **Connected** only means credentials exist under `$DSH_HOME/coding-plans/codex-auth.json`.
- **Free ChatGPT accounts usually cannot run Codex**; a paid plan is required for inference.
- Quota UI needs reachability to `chatgpt.com`; a network timeout does not mean you are signed out.

## Install

```sh
dsh plugin --profile web add dsh-coding-plans
# local checkout:
dsh plugin --profile web add link:/absolute/path/to/dsh-coding-plans
dsh web
```

or:

```sh
dsh plugin --profile web add github:pengzhou267-ai/dsh-coding-plans
```

See [INSTALL.md](INSTALL.md).

## Usage

1. **Settings → Coding Plans**
2. Codex: **Sign in with ChatGPT**; Kimi: **Sign in with Kimi**; Ark: pick Coding/Agent Plan and save API key
3. Models → **`coding-plans-codex`** / **`coding-plans-kimi`** / **`coding-plans-ark`** (Agent: **`coding-plans-ark-agent`**)

```sh
dsh-coding-plans login codex
dsh-coding-plans login kimi
dsh-coding-plans login ark --api-key <key> --plan coding
dsh-coding-plans login ark --api-key <key> --plan agent
dsh-coding-plans status ark
dsh-coding-plans list
```

## Architecture

TypeScript ports of mature OAuth/protocol implementations (pi-ai openai-codex, CLIProxyAPI kimi/codex patterns, dsh-codex), registered with `ctx.llm.registerAdapter`. See [docs/design.md](docs/design.md).

## License

Apache-2.0
