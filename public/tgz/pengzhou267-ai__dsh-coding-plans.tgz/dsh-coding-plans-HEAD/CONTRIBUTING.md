# Contributing

Thanks for helping grow the coding-plans hub.

1. Read [docs/provider-porting.md](docs/provider-porting.md) and [docs/design.md](docs/design.md).
2. Prefer one provider per PR (`packages/provider-<name>`).
3. Cite the upstream reference (repo + commit) you ported from.
4. Keep credentials under `$DSH_HOME/coding-plans/` only.
5. Add mock tests; do not require live OAuth in CI.
6. Run `pnpm run check` before opening the PR.

By contributing you agree your work is licensed under Apache-2.0.
