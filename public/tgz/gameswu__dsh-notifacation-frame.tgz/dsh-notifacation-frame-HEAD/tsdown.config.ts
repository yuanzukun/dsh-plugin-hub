/**
 * tsdown build for dsh-notifacation-frame —— 只负责客户端半边
 *（宿主 lib/index.js + 声明由 tsc 经 tsconfig.build.json 产出）：
 *
 * - lib/client.js：CJS closure factory，经 window.__ModuleLoader__.load
 *   注册（id = 包名 dsh-notifacation-frame）。
 * - 平台模块保持 external（web shell 的模块表在运行时解析）：react 与
 *   react-dom；DSH 原子控件由 src/client/ui.ts 本地供应商化内联
 *   （选择自足而非依赖共享 primitives，后者在 0.1.5 平台基线仍存在）。
 * - `*.svg?raw` 经 svgRawPlugin 以虚拟模块内联为文本（资源文件仍独立
 *   保存在 assets/，随包发布）：rolldown 的 `?raw` 后缀在 Windows 上会把
 *   问号并入路径导致解析失败，故用与 dsh-plugin-vscode-sidebar 的
 *   makeCssPlugin 同款的虚拟 id 方案。
 */
import { readFileSync } from 'node:fs'
import { dirname, resolve as resolvePath } from 'node:path'
import type { UserConfig } from 'tsdown'

/** 平台模块（web shell 的模块表提供，客户端 bundle 保持 external）。 */
const CLIENT_EXTERNALS = ['react', 'react-dom']

/** A rolldown plugin as tsdown's config accepts it. */
type BuildPlugin = NonNullable<UserConfig['plugins']>

/** `*.svg?raw` → 默认导出文件文本的虚拟模块。 */
function svgRawPlugin(): BuildPlugin {
  const PREFIX = '\0dsh-svg-raw:'
  return {
    name: 'dsh-svg-raw',
    resolveId(source, importer) {
      if (!source.endsWith('.svg?raw')) return null
      const file = source.slice(0, -'?raw'.length)
      const abs = importer === undefined ? file : resolvePath(dirname(importer), file)
      return PREFIX + abs
    },
    load(id) {
      if (!id.startsWith(PREFIX)) return null
      const content = readFileSync(id.slice(PREFIX.length), 'utf8')
      return `export default ${JSON.stringify(content)};`
    },
  }
}

export default [
  {
    entry: { client: 'src/client/entry.ts' },
    outDir: 'lib',
    format: 'cjs',
    platform: 'browser',
    dts: false,
    sourcemap: false,
    // clean 关闭：build 脚本先删 lib/ 再由 tsc 产出宿主产物，最后 tsdown 写入 client.js。
    clean: false,
    external: CLIENT_EXTERNALS,
    define: {
      'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'production'),
    },
    // External 交给模块表；其余（shared.ts、svg 虚拟模块等）全部内联。
    noExternal: (id: string) => (CLIENT_EXTERNALS.includes(id) ? undefined : true),
    plugins: [svgRawPlugin()],
    outputOptions: {
      entryFileNames: 'client.js',
      banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify('dsh-notifacation-frame')}, factory: (require) => {`,
      footer: 'return module.exports; } });',
      intro: 'var module = { exports: {} }; var exports = module.exports;',
      codeSplitting: false,
    },
  },
] satisfies UserConfig[]
