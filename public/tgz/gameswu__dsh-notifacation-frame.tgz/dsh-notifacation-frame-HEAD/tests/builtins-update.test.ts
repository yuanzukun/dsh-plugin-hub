/**
 * 内置通知项 dsh-update 的接线测试：checkForUpdate 被 mock 掉，
 * 验证启动检查 / 周期检查 / 去重 / 包名配置 与 env.notify 的行为。
 */
import { beforeEach, describe, expect, it, vi } from 'vitest'
import type { NotifierEnv } from '../src/shared'
import { builtinNotifiers } from '../src/host/builtins'

const mockControl = vi.hoisted(() => ({
  results: [] as Array<{ status: string; current?: string; latest?: string }>,
  calls: [] as string[],
}))

vi.mock('../src/host/update-check.js', () => ({
  checkForUpdate: async (packageName: string) => {
    mockControl.calls.push(packageName)
    const next = mockControl.results.shift()
    return next ?? { status: 'up-to-date', current: '1.0.0' }
  },
}))

beforeEach(() => {
  mockControl.results = []
  mockControl.calls = []
})

interface FakeCtx {
  intervals: Array<{ callback: () => void; ms: number }>
  interval(callback: () => void, ms: number): () => void
  on(name: string, listener: (...args: never[]) => unknown): () => void
  get(name: string): unknown
}

function makeCtx(): FakeCtx {
  const intervals: FakeCtx['intervals'] = []
  return {
    intervals,
    interval(callback, ms) {
      intervals.push({ callback, ms })
      return () => {
        // noop
      }
    },
    on() {
      return () => {
        // noop
      }
    },
    get() {
      return undefined
    },
  }
}

function activate(config: Record<string, unknown> = {}, ctx: FakeCtx = makeCtx()) {
  const notifications: Array<Parameters<NotifierEnv['notify']>[0]> = []
  const def = builtinNotifiers.find((entry) => entry.id === 'dsh-update')
  if (def === undefined) throw new Error('dsh-update builtin missing')
  const env: NotifierEnv = {
    notify: (payload) => notifications.push(payload),
    config,
    ctx,
  }
  const disposer = def.setup(env)
  return { notifications, ctx, env, disposer }
}

const flush = (): Promise<void> => new Promise((resolve) => setTimeout(resolve, 0))

describe('内置通知 dsh-update', () => {
  it('发现新版本 → 通知一次；同一版本重复检查不再通知', async () => {
    mockControl.results = [
      { status: 'update-available', current: '0.1.0-rc.6', latest: '0.2.0' },
      { status: 'update-available', current: '0.1.0-rc.6', latest: '0.2.0' },
    ]
    const { notifications, ctx } = activate()
    await vi.waitFor(() => expect(notifications).toHaveLength(1))
    expect(notifications[0]?.title).toContain('新版本')
    expect(notifications[0]?.body).toContain('0.1.0-rc.6')
    expect(notifications[0]?.body).toContain('0.2.0')
    expect(notifications[0]?.meta).toEqual({
      package: '@deepseek-ai/dsh',
      current: '0.1.0-rc.6',
      latest: '0.2.0',
    })
    // 等启动检查完全结束（checking 复位）再触发周期检查。
    await flush()
    for (const entry of ctx.intervals) entry.callback()
    await vi.waitFor(() => expect(mockControl.calls).toHaveLength(2))
    expect(notifications).toHaveLength(1)
  })

  it('出现更高版本时再次通知', async () => {
    mockControl.results = [{ status: 'update-available', current: '0.1.0-rc.6', latest: '0.2.0' }]
    const { notifications, ctx } = activate()
    await vi.waitFor(() => expect(notifications).toHaveLength(1))
    await flush()
    mockControl.results = [{ status: 'update-available', current: '0.1.0-rc.6', latest: '0.3.0' }]
    for (const entry of ctx.intervals) entry.callback()
    await vi.waitFor(() => expect(notifications).toHaveLength(2))
    expect(notifications[1]?.meta?.latest).toBe('0.3.0')
  })

  it('已是最新 → 不通知', async () => {
    mockControl.results = [{ status: 'up-to-date', current: '0.1.0-rc.6' }]
    const { notifications } = activate()
    await vi.waitFor(() => expect(mockControl.calls).toHaveLength(1))
    expect(notifications).toHaveLength(0)
  })

  it('checkOnStart 关闭时启动不检查，周期回调仍检查', async () => {
    mockControl.results = [{ status: 'update-available', current: '1.0.0', latest: '2.0.0' }]
    const { notifications, ctx } = activate({ checkOnStart: false })
    await Promise.resolve()
    expect(mockControl.calls).toHaveLength(0)
    for (const entry of ctx.intervals) entry.callback()
    await vi.waitFor(() => expect(notifications).toHaveLength(1))
  })

  it('packageName 配置项决定检查的包名', async () => {
    mockControl.results = [{ status: 'up-to-date', current: '1.0.0' }]
    activate({ packageName: 'my-own-package' })
    await vi.waitFor(() => expect(mockControl.calls).toHaveLength(1))
    expect(mockControl.calls[0]).toBe('my-own-package')
  })

  it('检查失败（unknown）静默，不抛错不通知', async () => {
    mockControl.results = [{ status: 'unknown', current: '0.1.0-rc.6' }]
    const { notifications } = activate()
    await vi.waitFor(() => expect(mockControl.calls).toHaveLength(1))
    expect(notifications).toHaveLength(0)
  })

  it('intervalHours 配置换算为周期毫秒', () => {
    const { ctx } = activate({ intervalHours: 2 })
    expect(ctx.intervals[0]?.ms).toBe(2 * 3600_000)
  })
})
