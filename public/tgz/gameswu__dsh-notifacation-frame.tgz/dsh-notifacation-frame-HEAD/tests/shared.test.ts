/**
 * 共享线缆模型的单元测试：派生插件配置项的解析契约
 * （默认值 / 类型校验 / 范围钳制 / 枚举白名单）与 blob 规范化。
 */
import { describe, expect, it } from 'vitest'
import {
  coerceField,
  normalizeChannels,
  parseOptions,
  resolveBlob,
  makeRecord,
  type NotifierDefinition,
} from '../src/shared'

function makeDef(fields: NotifierDefinition['fields'], extra: Partial<NotifierDefinition> = {}): NotifierDefinition {
  return {
    id: 'demo',
    title: 'demo',
    description: 'demo',
    severity: 'info',
    channels: ['web', 'log'],
    defaultChannels: ['web'],
    fields,
    setup: () => undefined,
    ...extra,
  }
}

describe('parseOptions（派生插件配置项解析）', () => {
  const fields = [
    { key: 'enabledFlag', label: 'e', type: 'boolean' as const, default: true },
    { key: 'threshold', label: 't', type: 'number' as const, default: 10, min: 0, max: 100 },
    { key: 'greet', label: 'g', type: 'string' as const, default: 'hello' },
    {
      key: 'mode',
      label: 'm',
      type: 'select' as const,
      default: 'a',
      options: [
        { value: 'a', label: 'A' },
        { value: 'b', label: 'B' },
      ],
    },
  ]

  it('缺省输入时全部取字段默认值', () => {
    const parsed = parseOptions(makeDef(fields), undefined)
    expect(parsed).toEqual({ enabledFlag: true, threshold: 10, greet: 'hello', mode: 'a' })
  })

  it('合法输入原样保留', () => {
    const parsed = parseOptions(makeDef(fields), { threshold: 42, greet: 'hi', mode: 'b', enabledFlag: false })
    expect(parsed).toEqual({ enabledFlag: false, threshold: 42, greet: 'hi', mode: 'b' })
  })

  it('越界数字被钳制到 min/max', () => {
    expect(parseOptions(makeDef(fields), { threshold: -5 }).threshold).toBe(0)
    expect(parseOptions(makeDef(fields), { threshold: 9999 }).threshold).toBe(100)
  })

  it('垃圾类型回落到默认值', () => {
    const parsed = parseOptions(makeDef(fields), { threshold: 'not-a-number', greet: 42, enabledFlag: 'yes' })
    expect(parsed).toEqual({ enabledFlag: true, threshold: 10, greet: 'hello', mode: 'a' })
  })

  it('select 白名单外的值回落到第一个选项', () => {
    expect(parseOptions(makeDef(fields), { mode: 'zzz' }).mode).toBe('a')
  })

  it('非对象输入整体回落默认', () => {
    expect(parseOptions(makeDef(fields), [1, 2])).toEqual(parseOptions(makeDef(fields), undefined))
  })

  it('无 fields 的通知项返回空对象', () => {
    expect(parseOptions(makeDef(undefined), { anything: true })).toEqual({})
  })
})

describe('coerceField', () => {
  it('number 支持字符串数字的宽容转换之外一律默认', () => {
    expect(coerceField({ key: 'x', label: 'x', type: 'number', default: 3, min: 0, max: 9 }, 7)).toBe(7)
    expect(coerceField({ key: 'x', label: 'x', type: 'number', default: 3 }, 'oops')).toBe(3)
  })
  it('select 无 options 时回落 string default', () => {
    expect(coerceField({ key: 'x', label: 'x', type: 'select', default: 'd' }, 'd')).toBe('d')
    expect(coerceField({ key: 'x', label: 'x', type: 'select', default: 'd' }, 'q')).toBe('d')
  })
})

describe('normalizeChannels', () => {
  it('白名单过滤 + 去重 + 缺省回落', () => {
    expect(normalizeChannels(['web', 'web', 'bogus'], ['log'])).toEqual(['web'])
    expect(normalizeChannels('not-array', ['system'])).toEqual(['system'])
    expect(normalizeChannels([1, 2], ['web', 'log'])).toEqual([])
  })
})

describe('resolveBlob', () => {
  it('缺省启用（defaultEnabled 缺省 true）', () => {
    const config = resolveBlob(makeDef(undefined), undefined)
    expect(config.enabled).toBe(true)
    expect(config.channels).toEqual(['web'])
  })

  it('defaultEnabled: false 的通知项缺省关闭', () => {
    const def = makeDef(undefined, { defaultEnabled: false })
    expect(resolveBlob(def, undefined).enabled).toBe(false)
    expect(resolveBlob(def, { enabled: true }).enabled).toBe(true)
  })

  it('存储 blob 的 options 经 parseOptions 解析', () => {
    const def = makeDef([
      { key: 'n', label: 'n', type: 'number' as const, default: 1, min: 0, max: 5 },
    ])
    const config = resolveBlob(def, { options: { n: 99 } })
    expect(config.options).toEqual({ n: 5 })
  })

  it('音效缺省静音；合法预设原样保留', () => {
    expect(resolveBlob(makeDef(undefined), undefined).sound).toBe('none')
    expect(resolveBlob(makeDef(undefined), { sound: 'ding' }).sound).toBe('ding')
    expect(resolveBlob(makeDef(undefined), { sound: 'bogus' }).sound).toBe('none')
  })

  it('custom 预设保留 URL；非 custom 预设清空 URL', () => {
    const custom = resolveBlob(makeDef(undefined), { sound: 'custom', soundUrl: 'https://x/a.mp3' })
    expect(custom.sound).toBe('custom')
    expect(custom.soundUrl).toBe('https://x/a.mp3')
    const ding = resolveBlob(makeDef(undefined), { sound: 'ding', soundUrl: 'https://x/a.mp3' })
    expect(ding.soundUrl).toBe('')
  })

  it('custom 预设缺 URL 时回落静音语义（URL 空串）', () => {
    const custom = resolveBlob(makeDef(undefined), { sound: 'custom' })
    expect(custom.soundUrl).toBe('')
  })

  it('defaultSound 作为未配置时的回退；用户配置优先', () => {
    const def = makeDef(undefined, { defaultSound: 'chime' })
    expect(resolveBlob(def, undefined).sound).toBe('chime')
    expect(resolveBlob(def, { sound: 'ding' }).sound).toBe('ding')
    expect(resolveBlob(def, { sound: 'none' }).sound).toBe('none')
  })

  it('非法 defaultSound 回落静音', () => {
    const def = makeDef(undefined, { defaultSound: 'bogus' })
    expect(resolveBlob(def, undefined).sound).toBe('none')
  })
})

describe('makeRecord', () => {
  it('生成独立 id 与时间戳', () => {
    const a = makeRecord({ itemId: 'x', severity: 'info', title: 't' })
    const b = makeRecord({ itemId: 'x', severity: 'info', title: 't' })
    expect(a.id).not.toBe(b.id)
    expect(typeof a.at).toBe('number')
    expect(a.itemId).toBe('x')
  })

  it('静音 / 缺省音效不携带 sound 字段', () => {
    expect(makeRecord({ itemId: 'x', severity: 'info', title: 't' }).sound).toBeUndefined()
    expect(makeRecord({ itemId: 'x', severity: 'info', title: 't', sound: { preset: 'none' } }).sound).toBeUndefined()
    expect(makeRecord({ itemId: 'x', severity: 'info', title: 't', sound: { preset: 'bogus' } }).sound).toBeUndefined()
  })

  it('内置预设携带 preset；custom 携带 URL（缺 URL 时省略）', () => {
    const ding = makeRecord({ itemId: 'x', severity: 'info', title: 't', sound: { preset: 'ding' } })
    expect(ding.sound).toEqual({ preset: 'ding' })
    const custom = makeRecord({ itemId: 'x', severity: 'info', title: 't', sound: { preset: 'custom', url: 'https://x/a.mp3' } })
    expect(custom.sound).toEqual({ preset: 'custom', url: 'https://x/a.mp3' })
    const customEmpty = makeRecord({ itemId: 'x', severity: 'info', title: 't', sound: { preset: 'custom' } })
    expect(customEmpty.sound).toEqual({ preset: 'custom' })
  })
})
