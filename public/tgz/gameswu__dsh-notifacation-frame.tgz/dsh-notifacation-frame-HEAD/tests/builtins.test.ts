/**
 * 内置通知项的行为测试（假事件总线）：
 * - session-complete 只在 running → idle 的完整转移后通知一次
 * - ask-user-question 只对询问工具触发并把问题放进正文
 * - tool-error 尊重排除名单
 * - agent-error / agent-loop-config-start-failed 直接通知
 */
import { describe, expect, it } from 'vitest'
import type { NotifierEnv } from '../src/shared'
import { builtinNotifiers } from '../src/host/builtins'

interface FakeBus {
  listeners: Map<string, Array<(...args: never[]) => unknown>>
  on(name: string, listener: (...args: never[]) => unknown): () => void
  emit(name: string, ...args: unknown[]): void
}

function makeBus(): FakeBus {
  const listeners = new Map<string, Array<(...args: never[]) => unknown>>()
  return {
    listeners,
    on(name, listener) {
      const list = listeners.get(name) ?? []
      list.push(listener)
      listeners.set(name, list)
      return () => {
        listeners.set(name, (listeners.get(name) ?? []).filter((entry) => entry !== listener))
      }
    },
    emit(name, ...args) {
      for (const listener of [...(listeners.get(name) ?? [])]) {
        listener(...(args as never[]))
      }
    },
  }
}

interface EnvFace {
  notifications: Array<Parameters<NotifierEnv['notify']>[0]>
  env: NotifierEnv
}

function activate(id: string, bus: FakeBus, config: Record<string, unknown> = {}): EnvFace {
  const notifications: EnvFace['notifications'] = []
  const def = builtinNotifiers.find((entry) => entry.id === id)
  if (def === undefined) throw new Error(`unknown builtin ${id}`)
  const env: NotifierEnv = {
    notify: (payload) => notifications.push(payload),
    config,
    ctx: bus,
  }
  const disposer = def.setup(env)
  return {
    notifications,
    env,
    // disposer intentionally not wired into these assertions
  }
}

describe('内置通知 session-complete', () => {
  it('只有 running→idle 才通知；启动时存量 idle 不打扰', () => {
    const bus = makeBus()
    const { notifications } = activate('session-complete', bus)
    bus.emit('agent/status', { agent: { id: 's1' }, status: 'idle' })
    expect(notifications).toHaveLength(0)
    bus.emit('agent/status', { agent: { id: 's1' }, status: 'running' })
    expect(notifications).toHaveLength(0)
    bus.emit('agent/status', { agent: { id: 's1' }, status: 'idle' })
    expect(notifications).toHaveLength(1)
    expect(notifications[0]?.severity).toBe('success')
    expect(notifications[0]?.sessionId).toBe('s1')
    // 再次 idle 不再重复通知。
    bus.emit('agent/status', { agent: { id: 's1' }, status: 'running' })
    bus.emit('agent/status', { agent: { id: 's1' }, status: 'idle' })
    expect(notifications).toHaveLength(2)
  })

  it('rootsOnly 开启时只通知顶层会话 agent', () => {
    const bus = makeBus()
    ;(bus as unknown as { get: (name: string) => unknown }).get = (name: string) =>
      name === 'agents' ? { roots: () => [{ id: 'root-1' }] } : undefined
    const { notifications } = activate('session-complete', bus, { rootsOnly: true })
    for (const id of ['child-9', 'root-1']) {
      bus.emit('agent/status', { agent: { id }, status: 'running' })
      bus.emit('agent/status', { agent: { id }, status: 'idle' })
    }
    expect(notifications).toHaveLength(1)
    expect(notifications[0]?.sessionId).toBe('root-1')
  })

  it('rootsOnly 开启时 roots() 之外的 teammate 子会话被过滤（Agent Teams）', () => {
    const bus = makeBus()
    ;(bus as unknown as { get: (name: string) => unknown }).get = (name: string) =>
      name === 'agents'
        ? { roots: () => [{ id: 'lead' }], list: () => [{ id: 'lead' }, { id: 'teammate-1' }] }
        : undefined
    const { notifications } = activate('session-complete', bus, { rootsOnly: true })
    for (const id of ['teammate-1', 'lead']) {
      bus.emit('agent/status', { agent: { id }, status: 'running' })
      bus.emit('agent/status', { agent: { id }, status: 'idle' })
    }
    expect(notifications.map((entry) => entry.sessionId)).toEqual(['lead'])
  })

  it('关闭 rootsOnly 后 teammate 完成也会通知（显式选择）', () => {
    const bus = makeBus()
    ;(bus as unknown as { get: (name: string) => unknown }).get = (name: string) =>
      name === 'agents'
        ? { roots: () => [{ id: 'lead' }], list: () => [{ id: 'lead' }, { id: 'teammate-1' }] }
        : undefined
    const { notifications } = activate('session-complete', bus, { rootsOnly: false })
    for (const id of ['teammate-1', 'lead']) {
      bus.emit('agent/status', { agent: { id }, status: 'running' })
      bus.emit('agent/status', { agent: { id }, status: 'idle' })
    }
    expect(notifications.map((entry) => entry.sessionId)).toEqual(['teammate-1', 'lead'])
  })
})

describe('内置通知 ask-user-question', () => {
  it('user-questions/request 在提问呈现时即通知并放行 next', () => {
    const bus = makeBus()
    const { notifications } = activate('ask-user-question', bus, { showQuestion: true })
    let delegated = false
    bus.emit('user-questions/request', {
      agent: { id: 's9' },
      questions: [{ id: 'q1', question: '你喜欢哪个方案？' }],
    }, () => {
      delegated = true
    })
    expect(notifications).toHaveLength(1)
    expect(notifications[0]?.severity).toBe('warning')
    expect(notifications[0]?.sessionId).toBe('s9')
    expect(notifications[0]?.body).toContain('你喜欢哪个方案？')
    expect(delegated).toBe(true)
  })

  it('tools/pre-execute 只对询问工具触发并放行 next（旧版 dsh 路径）', () => {
    const bus = makeBus()
    const { notifications } = activate('ask-user-question', bus, { showQuestion: true })
    let delegated = false
    bus.emit('tools/pre-execute', { name: 'bash', agent: { id: 's9' } }, () => {
      delegated = true
    })
    expect(notifications).toHaveLength(0)
    bus.emit('tools/pre-execute', {
      name: 'ask_user_question',
      agent: { id: 's9' },
      arguments: { questions: [{ id: 'q1', question: '你喜欢哪个方案？' }] },
    }, () => {
      delegated = true
    })
    expect(notifications).toHaveLength(1)
    expect(notifications[0]?.body).toContain('你喜欢哪个方案？')
    expect(delegated).toBe(true)
  })

  it('双源在同一会话 3s 内去重（新老 dsh 路径并存时不重复通知）', () => {
    const bus = makeBus()
    const { notifications } = activate('ask-user-question', bus, { showQuestion: true })
    bus.emit('user-questions/request', {
      agent: { id: 's9' },
      questions: [{ question: '同一个问题？' }],
    }, () => {})
    bus.emit('tools/pre-execute', {
      name: 'ask_user_question',
      agent: { id: 's9' },
      arguments: { questions: [{ question: '同一个问题？' }] },
    }, () => {})
    expect(notifications).toHaveLength(1)
  })

  it('showQuestion 关闭时正文不含问题', () => {
    const bus = makeBus()
    const { notifications } = activate('ask-user-question', bus, { showQuestion: false })
    bus.emit('user-questions/request', {
      agent: { id: 's9' },
      questions: [{ question: 'secret?' }],
    }, () => {})
    expect(notifications[0]?.body).not.toContain('secret?')
  })
})

describe('内置通知 tool-error', () => {
  it('isError 结果触发并遵守排除名单', () => {
    const bus = makeBus()
    const { notifications } = activate('tool-error', bus, { excludeNames: 'bash, grep' })
    bus.emit('tools/result', { name: 'bash', agent: { id: 's1' } }, { isError: true })
    expect(notifications).toHaveLength(0)
    bus.emit('tools/result', { name: 'edit', agent: { id: 's1' } }, { isError: true })
    expect(notifications).toHaveLength(1)
    expect(notifications[0]?.meta?.tool).toBe('edit')
    bus.emit('tools/result', { name: 'edit' }, { isError: false })
    expect(notifications).toHaveLength(1)
  })
})

describe('内置通知 agent-error 与 agent-loop-config-start-failed', () => {
  it('agent/error 触发错误通知', () => {
    const bus = makeBus()
    const { notifications } = activate('agent-error', bus)
    bus.emit('agent/error', { agent: { id: 's5' }, turn: 2, step: 3, error: new Error('model exploded') })
    expect(notifications).toHaveLength(1)
    expect(notifications[0]?.severity).toBe('error')
    expect(notifications[0]?.sessionId).toBe('s5')
    expect(notifications[0]?.body).toContain('model exploded')
  })

  it('agent-loop/config-start-failed 触发错误通知', () => {
    const bus = makeBus()
    const { notifications } = activate('agent-loop-config-start-failed', bus)
    bus.emit('agent-loop/config-start-failed', { sessionId: 's6', error: 'bad preset' })
    expect(notifications).toHaveLength(1)
    expect(notifications[0]?.severity).toBe('error')
    expect(notifications[0]?.body).toContain('bad preset')
  })
})

describe('内置通知的默认音效', () => {
  it('每个内置项都声明了合法且语义合适的默认音效', () => {
    const expected: Record<string, string> = {
      'session-complete': 'chime', // 任务完成 → 钟声（正向确认）
      'ask-user-question': 'ding', // 需要用户注意 → 叮（轻柔提醒）
      'process-crash': 'alert', // 进程崩溃 → 警报
      'agent-error': 'alert', // 运行报错 → 警报
      'agent-loop-config-start-failed': 'alert', // 启动失败 → 警报
      'tool-error': 'pop', // 高频可自愈失败 → 短促轻提示
      'dsh-update': 'ding', // 有新版本 → 叮（信息提示）
    }
    for (const def of builtinNotifiers) {
      expect(def.defaultSound, def.id).toBe(expected[def.id])
    }
  })
})
