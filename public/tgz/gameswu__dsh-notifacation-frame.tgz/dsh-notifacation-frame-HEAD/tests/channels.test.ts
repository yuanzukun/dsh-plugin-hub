/**
 * 通道中枢测试：历史环形缓冲与 log 通道（不触达真实的系统通知/WS）。
 */
import { describe, expect, it, vi } from 'vitest'
import type { NotificationRecord } from '../src/shared'
import { ChannelHub } from '../src/host/channels'

function makeRecord(title: string): NotificationRecord {
  return { id: `id-${title}`, itemId: 't', severity: 'info', title, at: Date.now() }
}

describe('ChannelHub', () => {
  it('deliver 推送历史并限制环形缓冲长度', () => {
    const hub = new ChannelHub({ logFile: '', historyLimit: 2, systemCooldownMs: 0, systemTimeoutMs: 8000 }, () => {})
    hub.deliver(makeRecord('a'), [])
    hub.deliver(makeRecord('b'), [])
    hub.deliver(makeRecord('c'), [])
    expect(hub.recent(10).map((record) => record.title)).toEqual(['c', 'b'])
  })

  it('log 通道写控制台且不写文件（logFile 为空）', () => {
    const lines: string[] = []
    const hub = new ChannelHub({ logFile: '', historyLimit: 10, systemCooldownMs: 0, systemTimeoutMs: 8000 }, (line) => lines.push(line))
    hub.deliver(makeRecord('hello'), ['log'])
    expect(lines.some((line) => line.includes('hello'))).toBe(true)
    expect(lines.some((line) => line.includes('[info]'))).toBe(true)
  })

  it('web 通道广播 JSON 帧；坏 socket 被隔离', () => {
    const hub = new ChannelHub({ logFile: '', historyLimit: 10, systemCooldownMs: 0, systemTimeoutMs: 8000 }, () => {})
    const sent: string[] = []
    hub.webClients.add({ send: (text) => sent.push(text) })
    hub.webClients.add({
      send: () => {
        throw new Error('socket dead')
      },
    })
    expect(() => hub.deliver(makeRecord('x'), ['web'])).not.toThrow()
    expect(sent).toHaveLength(1)
    const frame = JSON.parse(sent[0] as string) as { type: string; record: NotificationRecord }
    expect(frame.type).toBe('notification')
    expect(frame.record.title).toBe('x')
  })
})
