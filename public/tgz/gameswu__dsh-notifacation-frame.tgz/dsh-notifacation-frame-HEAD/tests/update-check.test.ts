/**
 * dsh 新版本检查核心逻辑测试（依赖全部注入，不触网）：
 * compareSemver（含 prerelease 语义）与 checkForUpdate 的结论分支。
 */
import { describe, expect, it, vi } from 'vitest'
import { checkForUpdate, compareSemver } from '../src/host/update-check'

describe('compareSemver（含 prerelease 语义）', () => {
  it('主版本比较', () => {
    expect(compareSemver('1.0.0', '2.0.0')).toBeLessThan(0)
    expect(compareSemver('2.0.0', '1.0.0')).toBeGreaterThan(0)
    expect(compareSemver('1.0.0', '1.0.0')).toBe(0)
  })

  it('缺省 patch 与前导 v', () => {
    expect(compareSemver('1.2', '1.2.0')).toBe(0)
    expect(compareSemver('v2.1.0', '2.1.0')).toBe(0)
  })

  it('prerelease 低于正式版', () => {
    expect(compareSemver('0.1.0-rc.6', '0.1.0')).toBeLessThan(0)
    expect(compareSemver('0.1.0', '0.1.0-rc.6')).toBeGreaterThan(0)
  })

  it('同前缀 prerelease 逐段比较（数字段按数值）', () => {
    expect(compareSemver('0.1.0-rc.6', '0.1.0-rc.7')).toBeLessThan(0)
    expect(compareSemver('0.1.0-rc.10', '0.1.0-rc.2')).toBeGreaterThan(0)
    expect(compareSemver('0.1.0-rc.6', '0.1.0-rc.6')).toBe(0)
  })

  it('数字段优先级低于字母段', () => {
    expect(compareSemver('1.0.0-1', '1.0.0-alpha')).toBeLessThan(0)
  })

  it('无法解析的版本回落到字符串比较且不抛错', () => {
    expect(() => compareSemver('garbage', '1.0.0')).not.toThrow()
    expect(compareSemver('a', 'b')).toBeLessThan(0)
  })
})

function makeDeps(overrides: {
  current?: string | undefined
  distTags?: unknown
  fetchError?: Error
}) {
  return {
    readInstalledVersion: () => overrides.current,
    fetchJson: async () => {
      if (overrides.fetchError !== undefined) throw overrides.fetchError
      return overrides.distTags
    },
    log: vi.fn(),
  }
}

describe('checkForUpdate', () => {
  it('本机版本无法读取 → unknown（不触网、不抛错）', async () => {
    const fetchJson = vi.fn(async () => ({ latest: '9.9.9' }))
    const result = await checkForUpdate('@deepseek-ai/dsh', {
      readInstalledVersion: () => undefined,
      fetchJson,
    })
    expect(result).toEqual({ status: 'unknown' })
    expect(fetchJson).not.toHaveBeenCalled()
  })

  it('latest 高于 current → update-available', async () => {
    const result = await checkForUpdate('@deepseek-ai/dsh', makeDeps({
      current: '0.1.0-rc.6',
      distTags: { latest: '0.2.0' },
    }))
    expect(result).toEqual({ status: 'update-available', current: '0.1.0-rc.6', latest: '0.2.0' })
  })

  it('prerelease 升级（rc.6 → rc.7）同样判定为 update-available', async () => {
    const result = await checkForUpdate('@deepseek-ai/dsh', makeDeps({
      current: '0.1.0-rc.6',
      distTags: { latest: '0.1.0-rc.7' },
    }))
    expect(result.status).toBe('update-available')
    expect((result as { latest: string }).latest).toBe('0.1.0-rc.7')
  })

  it('版本相同 → up-to-date', async () => {
    const result = await checkForUpdate('@deepseek-ai/dsh', makeDeps({
      current: '0.1.0-rc.6',
      distTags: { latest: '0.1.0-rc.6' },
    }))
    expect(result).toEqual({ status: 'up-to-date', current: '0.1.0-rc.6' })
  })

  it('latest 低于 current（本地更新）→ up-to-date', async () => {
    const result = await checkForUpdate('@deepseek-ai/dsh', makeDeps({
      current: '0.3.0',
      distTags: { latest: '0.2.0' },
    }))
    expect(result.status).toBe('up-to-date')
  })

  it('registry 请求失败 → unknown（记录日志，不抛错）', async () => {
    const deps = makeDeps({ current: '0.1.0-rc.6', fetchError: new Error('ECONNREFUSED') })
    const result = await checkForUpdate('@deepseek-ai/dsh', deps)
    expect(result).toEqual({ status: 'unknown', current: '0.1.0-rc.6' })
    expect(deps.log).toHaveBeenCalledOnce()
  })

  it('dist-tags 缺少 latest 字段 → unknown', async () => {
    const result = await checkForUpdate('@deepseek-ai/dsh', makeDeps({
      current: '0.1.0-rc.6',
      distTags: { next: '0.9.0' },
    }))
    expect(result).toEqual({ status: 'unknown', current: '0.1.0-rc.6' })
  })

  it('默认依赖下包不存在 → unknown（验证 readInstalledVersion 的兜底路径不抛错）', async () => {
    const result = await checkForUpdate('__dsh-not-exist-pkg__', {
      fetchJson: async () => ({ latest: '9.9.9' }),
    })
    expect(result.status).toBe('unknown')
  })
})
