/**
 * Strict downstream consumer fixture for QC-002.
 *
 * Imports both this plugin's published root types and @deepseek-ai/dsh-settings
 * so both declaration graphs participate in one skipLibCheck:false program.
 * Before QC-002 this reproduced TS2717 on Context.settings.
 */
import type {} from 'dsh-notifacation-frame'
import type { SettingsNamespace, SettingsProvider, SettingsScope } from '@deepseek-ai/dsh-settings'

/** Reference every imported type so the declarations are retained explicitly. */
export interface StrictConsumerProbe {
  readonly provider?: SettingsProvider
  readonly scope?: SettingsScope<{ items?: Record<string, unknown> }>
  readonly namespace?: SettingsNamespace
}
