/**
 * 注册表核心流程测试：派生插件注册 → 配置解析 → 投递过滤 →
 * 配置热生效（setup 重激活）→ 测试通道 → 外部设置文档 reconcile。
 */
import { describe, expect, it, vi } from 'vitest'
import type { NotifierConfigBlob, NotifierDefinition, NotificationRecord } from '../src/shared'
import { NotificationRegistry, type RegistrySettingsFace } from '../src/host/registry'

function makeHub() {
  const delivered: Array<{ record: NotificationRecord; channels: readonly string[] }> = []
  return {
    delivered,
    webClients: new Set(),
    deliver(record: NotificationRecord, channels: readonly string[]): void {
      delivered.push({ record, channels })
    },
    recent(limit: number): NotificationRecord[] {
      return delivered.slice(-limit).reverse().map((entry) => entry.record)
    },
  }
}

function makeSettings(initial: Record<string, NotifierConfigBlob> = {}) {
  let items = { ...initial }
  return {
    face: {
      getItems: () => items,
      persistItems: async (next: Record<string, NotifierConfigBlob>) => {
        items = { ...next }
      },
    } satisfies RegistrySettingsFace,
    read: () => items,
  }
}

function makeDef(overrides: Partial<NotifierDefinition> = {}): NotifierDefinition {
  return {
    id: 'demo',
    title: 'Demo',
    description: 'demo item',
    severity: 'info',
    channels: ['web', 'system', 'log'],
    defaultChannels: ['web'],
    fields: [
      { key: 'greet', label: 'g', type: 'string', default: 'hello' },
      { key: 'n', label: 'n', type: 'number', default: 1, min: 0, max: 5 },
    ],
    setup: () => undefined,
    ...overrides,
  }
}

describe('NotificationRegistry', () => {
  it('注册即按设置文档解析派生配置并激活 setup', () => {
    const hub = makeHub()
    const settings = makeSettings({ demo: { options: { greet: 'stored', n: 3 }, enabled: false, channels: ['log'] } })
    const registry = new NotificationRegistry({ hub, settings: settings.face })
    const setups: Array<{ config: Record<string, unknown> }> = []
    registry.register(makeDef({
      setup(env) {
        setups.push({ config: env.config })
      },
    }))
    expect(setups).toHaveLength(1)
    expect(setups[0]?.config).toEqual({ greet: 'stored', n: 3 })
    const view = registry.list()[0]
    expect(view?.config.enabled).toBe(false)
    expect(view?.config.channels).toEqual(['log'])
    expect(view?.source).toBe('plugin')
  })

  it('内置注册项 source 标记为 builtin', () => {
    const registry = new NotificationRegistry({ hub: makeHub() })
    registry.registerBuiltin(makeDef())
    expect(registry.list()[0]?.source).toBe('builtin')
  })

  it('禁用项不投递；启用项按通道投递', () => {
    const hub = makeHub()
    const registry = new NotificationRegistry({ hub })
    registry.register(makeDef({
      setup(env) {
        env.notify({ title: 't1' })
      },
    }))
    expect(hub.delivered).toHaveLength(1)
    expect(hub.delivered[0]?.record.itemId).toBe('demo')
    expect(hub.delivered[0]?.channels).toEqual(['web'])

    hub.delivered.length = 0
    registry.register(makeDef({
      id: 'off',
      defaultEnabled: false,
      setup(env) {
        env.notify({ title: 'should-not-fire' })
      },
    }))
    expect(hub.delivered).toHaveLength(0)
  })

  it('updateItem 持久化 + 热重激活（旧 disposer 先执行，新 config 生效）', async () => {
    const hub = makeHub()
    const settings = makeSettings()
    const registry = new NotificationRegistry({ hub, settings: settings.face })
    const events: string[] = []
    registry.register(makeDef({
      setup(env) {
        events.push(`setup:${String(env.config.n)}`)
        return () => events.push('dispose')
      },
    }))
    events.length = 0
    await registry.updateItem('demo', { enabled: true, channels: ['web', 'log'], options: { n: 4 } })
    expect(events).toEqual(['dispose', 'setup:4'])
    expect(settings.read()).toEqual({
      demo: {
        enabled: true,
        channels: ['web', 'log'],
        options: { greet: 'hello', n: 4 },
        sound: 'none',
        soundUrl: '',
      },
    })
    expect(registry.list()[0]?.config.options).toEqual({ greet: 'hello', n: 4 })
  })

  it('updateItem 持久化音效配置并热生效', async () => {
    const hub = makeHub()
    const settings = makeSettings()
    const registry = new NotificationRegistry({ hub, settings: settings.face })
    registry.register(makeDef())
    await registry.updateItem('demo', { sound: 'custom', soundUrl: 'https://x/a.mp3' })
    expect(settings.read()).toEqual({
      demo: {
        enabled: true,
        channels: ['web'],
        options: { greet: 'hello', n: 1 },
        sound: 'custom',
        soundUrl: 'https://x/a.mp3',
      },
    })
    expect(registry.list()[0]?.config.sound).toBe('custom')
    expect(registry.list()[0]?.config.soundUrl).toBe('https://x/a.mp3')
  })

  it('emit 把生效音效附着到通知记录；静音不携带', () => {
    const hub = makeHub()
    const settings = makeSettings({ demo: { sound: 'ding', soundUrl: 'https://x/ignored.mp3' } })
    const registry = new NotificationRegistry({ hub, settings: settings.face })
    registry.register(makeDef({
      setup(env) {
        env.notify({ title: 'with-sound' })
      },
    }))
    expect(hub.delivered[0]?.record.sound).toEqual({ preset: 'ding' })

    const hub2 = makeHub()
    const registry2 = new NotificationRegistry({ hub: hub2 })
    registry2.register(makeDef({
      setup(env) {
        env.notify({ title: 'silent' })
      },
    }))
    expect(hub2.delivered[0]?.record.sound).toBeUndefined()
  })

  it('updateItem 拒绝未知 id', async () => {
    const registry = new NotificationRegistry({ hub: makeHub() })
    await expect(registry.updateItem('nope', {})).rejects.toThrow('unknown notifier')
  })

  it('reconcile 吸收外部设置文档变化并重激活', async () => {
    const hub = makeHub()
    const settings = makeSettings()
    const registry = new NotificationRegistry({ hub, settings: settings.face })
    registry.register(makeDef())
    // 模拟外部写入（绕过 updateItem）。
    await settings.face.persistItems({ demo: { enabled: false, channels: ['log'], options: { n: 2 } } })
    registry.reconcile()
    expect(registry.list()[0]?.config.enabled).toBe(false)
    expect(registry.list()[0]?.config.options).toEqual({ greet: 'hello', n: 2 })
  })

  it('setup 抛错被标记而不是击穿注册流程', () => {
    const registry = new NotificationRegistry({ hub: makeHub() })
    registry.register(makeDef({
      setup() {
        throw new Error('boom')
      },
    }))
    const view = registry.list()[0]
    expect(view?.setupError).toBe('boom')
    expect(registry.list()).toHaveLength(1)
  })

  it('test() 通过该项配置的通道投递测试通知；全关时回落 log', () => {
    const hub = makeHub()
    const registry = new NotificationRegistry({ hub })
    registry.register(makeDef({ defaultChannels: [] }))
    registry.test('demo')
    expect(hub.delivered).toHaveLength(1)
    expect(hub.delivered[0]?.channels).toEqual(['log'])
    expect(hub.delivered[0]?.record.title).toContain('测试通知')
  })

  it('test() 附着该项的生效音效', () => {
    const hub = makeHub()
    const settings = makeSettings({ demo: { sound: 'chime' } })
    const registry = new NotificationRegistry({ hub, settings: settings.face })
    registry.register(makeDef())
    registry.test('demo')
    expect(hub.delivered[0]?.record.sound).toEqual({ preset: 'chime' })
  })

  it('dispatch 旁路通知项开关直接投递', () => {
    const hub = makeHub()
    const registry = new NotificationRegistry({ hub })
    registry.register(makeDef({ defaultEnabled: false }))
    registry.dispatch({ itemId: 'demo', title: 'x', severity: 'error' })
    expect(hub.delivered).toHaveLength(1)
    expect(hub.delivered[0]?.record.severity).toBe('error')
  })

  it('history 返回新在前的最多 limit 条', () => {
    const hub = makeHub()
    const registry = new NotificationRegistry({ hub })
    registry.register(makeDef({
      setup(env) {
        env.notify({ title: 'one' })
        env.notify({ title: 'two' })
        env.notify({ title: 'three' })
      },
    }))
    const history = registry.history(2)
    expect(history).toHaveLength(2)
    expect(history[0]?.title).toBe('three')
    expect(history[1]?.title).toBe('two')
  })

  it('重复注册同一 id 会先 dispose 旧实例', () => {
    const hub = makeHub()
    const registry = new NotificationRegistry({ hub })
    const events: string[] = []
    registry.register(makeDef({ setup: () => () => events.push('old-disposed') }))
    registry.register(makeDef({ setup: () => () => events.push('new-disposed') }))
    expect(events).toEqual(['old-disposed'])
    expect(registry.list()).toHaveLength(1)
    registry.disposeAll()
    expect(events).toEqual(['old-disposed', 'new-disposed'])
    expect(registry.list()).toHaveLength(0)
  })
})
