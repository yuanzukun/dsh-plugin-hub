/**
 * 通知跳转会话的安全打开器测试（0.1.5 Agent Teams / 子会话路径）。
 */
import { describe, expect, it } from 'vitest'
import { createSessionOpener, type NotificationSessionsFace } from '../src/client/session-open'

describe('createSessionOpener', () => {
  it('缺少 sessions 服务或没有任何导航能力时返回 undefined', () => {
    expect(createSessionOpener(undefined)).toBeUndefined()
    expect(createSessionOpener({} as NotificationSessionsFace)).toBeUndefined()
  })

  it('旧版仅有 open 时仍直接打开列表会话', () => {
    const opened: string[] = []
    const opener = createSessionOpener({ open: (id) => opened.push(id) })
    opener?.('s1')
    expect(opened).toEqual(['s1'])
  })

  it('0.1.5 优先走 subagentAddress -> openSubagent（teammate 子会话）', () => {
    const opened: string[] = []
    const addresses: unknown[] = []
    const opener = createSessionOpener({
      open: (id) => opened.push(id),
      subagentAddress: (id) => ({ parentSessionId: 'lead', childSessionId: id, mode: 'continuable' }),
      openSubagent: (address) => addresses.push(address),
    })
    opener?.('teammate-1')
    expect(addresses).toEqual([{ parentSessionId: 'lead', childSessionId: 'teammate-1', mode: 'continuable' }])
    expect(opened).toEqual([])
  })

  it('目录中找不到地址时回退 open', () => {
    const opened: string[] = []
    const opener = createSessionOpener({
      open: (id) => opened.push(id),
      subagentAddress: () => undefined,
      openSubagent: () => { throw new Error('must not be called') },
    })
    opener?.('root-1')
    expect(opened).toEqual(['root-1'])
  })

  it('subagentAddress 抛错时记录并回退 open，不向外抛', () => {
    const opened: string[] = []
    const errors: string[] = []
    const opener = createSessionOpener({
      open: (id) => opened.push(id),
      subagentAddress: () => { throw new Error('catalog gone') },
      openSubagent: () => {},
    }, (message) => errors.push(message))
    expect(() => opener?.('child-9')).not.toThrow()
    expect(opened).toEqual(['child-9'])
    expect(errors).toEqual(['subagent address lookup failed'])
  })

  it('open 对未知/已失效会话 fail loud 时安全降级为 no-op', () => {
    const errors: string[] = []
    const opener = createSessionOpener({
      open: () => { throw new Error('unknown session') },
    }, (message) => errors.push(message))
    expect(() => opener?.('gone')).not.toThrow()
    expect(errors).toEqual(['session open failed'])
  })
})
