/**
 * 入口集成测试：用假 cordis 上下文驱动 apply() 全生命周期——
 * settings 绑定 → 内置项注册 → 服务面提供 → fenced JSON API 路由挂载
 * （含端到端请求往返）→ WS 路由挂载 → 事件投递 → 停机清理。
 */
import { beforeEach, afterEach, describe, expect, it, vi } from 'vitest'

interface FakeScope {
  get(): unknown
  replace(section: object): Promise<void>
  watch(callback: () => void): () => void
}

interface FakeHttpRequest {
  url?: string
  method?: string
  headers: Record<string, string | string[] | undefined>
  body?: string
  [Symbol.asyncIterator](): AsyncIterator<string | Uint8Array>
}

interface FakeHttpResponse {
  statusCode: number
  body: string
  writeHead(status: number, headers?: Record<string, string>): void
  end(body?: string | Uint8Array): void
}

interface FakeHttpRoute {
  kind: string
  path: string
  handler(req: FakeHttpRequest, res: FakeHttpResponse): void | Promise<void>
}

interface FakeCtx {
  listeners: Map<string, Array<(...args: never[]) => unknown>>
  effects: Array<() => void>
  upgradeRoutes: Array<{ path: string }>
  httpRoutes: FakeHttpRoute[]
  provided: Map<string, unknown>
  settingsValue: { items: Record<string, unknown> }
  scope: FakeScope | null
  get(name: string): unknown
  inject(names: readonly string[], callback: (ctx: FakeCtx) => void): void
  provide(name: string, value: unknown): void
  effect(callback: () => void | (() => void), label?: string): void
  on(name: string, listener: (...args: never[]) => unknown): () => void
  emit(name: string, ...args: unknown[]): void
  webServer: {
    register(route: { kind: string; path: string; handler: FakeHttpRoute['handler'] }): () => void
    registerUpgrade(route: { path: string }): () => void
  }
  settings: {
    register(ns: string, schema: unknown, options: unknown): FakeScope
  }
}

function makeCtx(initialItems: Record<string, unknown> = {}): FakeCtx {
  let items = { ...initialItems }
  const ctx: FakeCtx = {
    listeners: new Map(),
    effects: [],
    upgradeRoutes: [],
    httpRoutes: [],
    provided: new Map(),
    settingsValue: { items },
    scope: null,
    get(name: string) {
      return name === 'webRuntime' ? { trustedHosts: ['lan-host.local'] } : undefined
    },
    inject(names, callback) {
      if (names.includes('settings')) {
        callback(ctx)
      }
    },
    provide(name, value) {
      ctx.provided.set(name, value)
    },
    effect(callback) {
      const disposer = callback()
      if (typeof disposer === 'function') ctx.effects.push(disposer)
    },
    on(name, listener) {
      const list = ctx.listeners.get(name) ?? []
      list.push(listener)
      ctx.listeners.set(name, list)
      return () => {
        ctx.listeners.set(name, (ctx.listeners.get(name) ?? []).filter((entry) => entry !== listener))
      }
    },
    emit(name, ...args) {
      for (const listener of [...(ctx.listeners.get(name) ?? [])]) {
        listener(...(args as never[]))
      }
    },
    webServer: {
      register(route) {
        ctx.httpRoutes.push(route as FakeHttpRoute)
        return () => {
          ctx.httpRoutes = ctx.httpRoutes.filter((entry) => entry !== route)
        }
      },
      registerUpgrade(route) {
        ctx.upgradeRoutes.push(route)
        return () => {
          ctx.upgradeRoutes = ctx.upgradeRoutes.filter((entry) => entry !== route)
        }
      },
    },
    settings: {
      register(_ns, _schema, _options) {
        const scope: FakeScope = {
          get: () => ctx.settingsValue,
          replace: async (section) => {
            items = (section as { items: Record<string, unknown> }).items
            ctx.settingsValue = { items }
          },
          watch: () => {
            return () => {
              // noop
            }
          },
        }
        ctx.scope = scope
        return scope
      },
    },
  }
  return ctx
}

async function importPlugin(): Promise<{ apply: (ctx: FakeCtx, config?: unknown) => void }> {
  return await import('../src/host/plugin.js')
}

/** 构造一个经过信任栅栏的 JSON 请求并驱动路由处理器。 */
async function callApi(
  ctx: FakeCtx,
  method: string,
  payload: unknown,
  host = 'localhost',
): Promise<{ status: number; json: { ok?: boolean; value?: unknown; error?: { code?: string; message?: string } } }> {
  const route = ctx.httpRoutes.find((entry) => entry.path === '/notification-frame/api')
  if (route === undefined) throw new Error('api route not registered')
  const request: FakeHttpRequest = {
    method: 'POST',
    url: `/notification-frame/api/${method}`,
    headers: { host },
    async *[Symbol.asyncIterator]() {
      yield JSON.stringify(payload ?? {})
    },
  }
  const response: FakeHttpResponse = {
    statusCode: 200,
    body: '',
    writeHead(status) {
      response.statusCode = status
    },
    end(body) {
      response.body = typeof body === 'string' ? body : Buffer.from(body).toString('utf8')
    },
  }
  await route.handler(request, response)
  return { status: response.statusCode, json: JSON.parse(response.body) as never }
}

describe('插件入口集成（apply 全生命周期）', () => {
  beforeEach(() => {
    // dsh-update 的 checkOnStart 会触发一次真实版本检查：测试环境离线
    // （fetch 直接拒绝），保证测试确定性、不触网。
    vi.stubGlobal('fetch', () => Promise.reject(new Error('offline in tests')))
  })

  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('挂载 API/WS 路由、注册内置项、提供服务面；事件经配置投递', async () => {
    const { apply } = await importPlugin()
    const ctx = makeCtx({
      'session-complete': { enabled: true, channels: ['log'] },
    })
    apply(ctx)

    // 配置卡片 JSON API 路由与 WS 推送路由挂载。
    expect(ctx.httpRoutes.map((route) => route.path)).toContain('/notification-frame/api')
    expect(ctx.upgradeRoutes).toHaveLength(1)
    expect(ctx.upgradeRoutes[0]?.path).toBe('/notification-frame/ws')

    // 服务面提供。
    const service = ctx.provided.get('notificationFrame')
    expect(service).toBeDefined()
    const list = (service as { list(): Array<{ id: string }> }).list()
    expect(list.map((item) => item.id)).toContain('session-complete')
    expect(list.map((item) => item.id)).toContain('process-crash')
    expect(list.map((item) => item.id)).toContain('ask-user-question')
    expect(list.map((item) => item.id)).toContain('dsh-update')
    expect(list).toHaveLength(7)

    // settings 绑定后按文档解析：session-complete 仅 log 通道。
    const item = list.find((entry) => entry.id === 'session-complete') as
      | { config: { channels: string[] } }
      | undefined
    expect(item?.config.channels).toEqual(['log'])

    // 内置项已监听事件：running→idle 投递（投递进入 hub 的 web 集合/history）。
    const history = (service as { history(): Array<{ itemId: string }> }).history()
    expect(history).toHaveLength(0)
    ctx.emit('agent/status', { agent: { id: 's1' }, status: 'running' })
    ctx.emit('agent/status', { agent: { id: 's1' }, status: 'idle' })
    expect((service as { history(): Array<{ itemId: string }> }).history()).toHaveLength(1)

    // 停机清理：effect disposer 回收。
    for (const dispose of [...ctx.effects].reverse()) dispose()
    expect((service as { list(): Array<{ id: string }> }).list()).toHaveLength(0)
  })

  it('fenced API 端到端：catalog 往返 + setItem 持久化 + 栅栏拒绝 + 方法校验', async () => {
    const { apply } = await importPlugin()
    const ctx = makeCtx()
    apply(ctx)

    // catalog：完整往返。
    const catalog = await callApi(ctx, 'catalog', {})
    expect(catalog.status).toBe(200)
    expect(catalog.json.ok).toBe(true)
    const items = (catalog.json.value as { items: Array<{ id: string }> }).items
    expect(items.map((entry) => entry.id)).toContain('session-complete')

    // setItem：写入并热生效 + 持久化到 settings 文档（含音效字段）。
    const setResult = await callApi(ctx, 'setItem', {
      id: 'tool-error',
      blob: { enabled: true, channels: ['web'], options: { excludeNames: 'bash' }, sound: 'ding' },
    })
    expect(setResult.status).toBe(200)
    expect(setResult.json.ok).toBe(true)
    expect(ctx.settingsValue.items['tool-error']).toEqual({
      enabled: true,
      channels: ['web'],
      options: { excludeNames: 'bash' },
      sound: 'ding',
      soundUrl: '',
    })

    // history：事件经配置投递后可读。
    ctx.emit('agent/status', { agent: { id: 's2' }, status: 'running' })
    ctx.emit('agent/status', { agent: { id: 's2' }, status: 'idle' })
    const historyResult = await callApi(ctx, 'history', { limit: 10 })
    expect((historyResult.json.value as { history: unknown[] }).history).toHaveLength(1)

    // 信任栅栏：非回环 Host 被拒绝。
    const foreign = await callApi(ctx, 'catalog', {}, 'evil.example.com')
    expect(foreign.status).toBe(403)
    expect(foreign.json.ok).toBe(false)

    // 方法校验：未知方法 404，缺 id 400。
    const notFound = await callApi(ctx, 'nope', {})
    expect(notFound.status).toBe(404)
    const badRequest = await callApi(ctx, 'test', {})
    expect(badRequest.status).toBe(400)

    for (const dispose of [...ctx.effects].reverse()) dispose()
  })
})
