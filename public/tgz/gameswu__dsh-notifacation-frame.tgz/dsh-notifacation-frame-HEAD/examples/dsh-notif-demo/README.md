# dsh-notif-demo

`dsh-notifacation-frame` 的派生插件示例：演示如何注册自定义通知项、声明配置项，并观察框架对配置的解析与热生效。

> 兼容性：随父框架 v0.4.0 起要求 **DSH ≥ 0.1.5-rc.1**（父包通过 workspace 依赖提供 `notificationFrame` 类型与服务）。

- `demo-turn-counter`：会话 agent 每完成 N 轮任务提醒一次（演示 `number` / `boolean` / `select` 三种字段的解析、钳制与热生效）；
- `demo-subagent-end`：子代理结束时提醒（演示无字段的最小注册）。

## 安装

```bash
# 1. 先构建框架本体
cd ../.. && pnpm install && pnpm run build && cd examples/dsh-notif-demo

# 2. 构建示例（workspace 依赖解析 dsh-notifacation-frame 的类型与运行时）
pnpm install && pnpm run build

# 3. 安装两个包即可（dsh plugin 是 pnpm 转发器：自动把声明了 dsh.bundle
#    的依赖登记进 dsh.profile.bundles，重启时自动合并各包自带的
#    cordis.patch.yml——无需手写挂载行，安装顺序也无关紧要：
#    demo 通过 inject 等待框架服务）
dsh plugin --profile web add "file:$(cd ../.. && pwd)"
dsh plugin --profile web add "file:$(pwd)"

# 4. 重启 DSH，打开 Settings → 通知，即可看到两个“插件”来源的卡片
```

## 验证热生效

1. 打开 Settings → 通知 → “Turn 计数提醒”卡片；
2. 把 `notifyEvery` 改成 1、`tone` 改成“严厉”并保存——卡片写入 settings
   文档，框架立即 dispose 旧 setup 并以新配置重跑（无需重启）；
3. 让会话 agent 跑完一轮任务，观察右上角 toast 文案变化；
4. 点卡片上的“测试”按钮，确认通道配置生效（全关时回落日志通道）。
