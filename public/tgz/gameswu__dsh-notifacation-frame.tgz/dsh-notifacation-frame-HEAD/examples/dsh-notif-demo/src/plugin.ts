/**
 * dsh-notif-demo · 派生插件示例（依赖 dsh-notifacation-frame 通知框架）。
 *
 * 一个派生插件的全部工作就是：
 * 1. `import type {} from 'dsh-notifacation-frame'` —— 获得
 *    `ctx.notificationFrame` 的 Context 增广（注册表服务面）；
 * 2. `export const inject = ['notificationFrame']` —— 等待框架服务挂载
 *    （框架行在组合里的顺序无所谓，cordis 注入解析会等待）；
 * 3. 在 apply 里调用 `ctx.notificationFrame.register(definition)`。
 *
 * definition 里的 `fields` 就是“派生插件的配置项”：框架在设置页为每个
 * 通知项渲染配置卡片（开关 + 通道 + 每个 field 的通用控件），并把解析、
 * 校验、补默认之后的配置经 `env.config` 传给 setup。用户改卡片时框架先
 * dispose 旧 setup、再用新配置重跑 setup——派生插件完全不用碰 settings
 * 命名空间、Remote 网关或任何持久化代码。
 *
 * 本示例注册两个通知项：
 * - demo-turn-counter  每完成 N 轮任务提醒一次（演示 number/boolean/select
 *                      三种字段的解析与钳制）；
 * - demo-subagent-end  子代理结束时提醒（演示无字段的最小注册）。
 */
import type { NotifierDefinition, NotificationFrameService } from 'dsh-notifacation-frame'

export const name = 'dsh-notif-demo'
export const inject = ['notificationFrame'] as string[]

/**
 * 派生插件需要的 cordis 上下文窄面（结构类型）。DSH 的 cordis Context 是
 * 键控泛型（on 按 Events 表收窄），第三方插件事件名不在表内，因此与
 * dsh-pref-kit 一样用自声明的窄面描述真实运行时形状。
 */
interface DemoCtx {
  on(name: string, listener: (...args: never[]) => unknown): () => void
  effect(callback: () => void | (() => void), label?: string): void
  notificationFrame: NotificationFrameService
}

/** 事件载荷面（防御式读取，只取叶子字段）。 */
interface AgentStatusPayload {
  agent?: { id?: unknown }
  status?: unknown
}

interface SubagentEndInfo {
  id?: unknown
  label?: unknown
}

function shortId(id: string): string {
  return id.length <= 12 ? id : `${id.slice(0, 6)}…${id.slice(-4)}`
}

/** 派生插件示例：每完成 N 轮任务提醒一次（字段解析演示）。 */
const turnCounter: NotifierDefinition = {
  id: 'demo-turn-counter',
  title: 'Turn 计数提醒',
  description: '派生插件示例：会话 agent 每完成 N 轮任务提醒一次。演示框架对 number / boolean / select 配置项的解析、钳制与热生效。',
  severity: 'info',
  channels: ['web', 'system', 'log'],
  defaultChannels: ['web', 'log'],
  defaultEnabled: true,
  defaultSound: 'ding',
  fields: [
    {
      key: 'notifyEvery',
      label: '每 N 轮提醒一次',
      type: 'number',
      default: 3,
      min: 1,
      max: 50,
      description: '用户填 0 或 99 都会被钳制回合法范围。',
    },
    {
      key: 'mentionSession',
      label: '正文包含会话 id',
      type: 'boolean',
      default: true,
    },
    {
      key: 'tone',
      label: '提醒语气',
      type: 'select',
      default: 'gentle',
      options: [
        { value: 'gentle', label: '温柔' },
        { value: 'firm', label: '严厉' },
      ],
    },
  ],
  setup(env) {
    // env.config 已经是框架解析好的 { notifyEvery, mentionSession, tone }：
    // 类型合法、范围已钳制、缺失项已补默认——直接使用，无需再校验。
    const notifyEvery = Number(env.config.notifyEvery) || 3
    const mentionSession = env.config.mentionSession === true
    const tone = env.config.tone === 'firm' ? 'firm' : 'gentle'
    const ctx = env.ctx as DemoCtx
    const counters = new Map<string, number>()

    // 监听会话事件；返回的 disposer 交给框架管理（配置热生效时自动清理）。
    return ctx.on('agent/status', ((payload: AgentStatusPayload) => {
      const agentId = payload?.agent?.id
      if (payload?.status !== 'idle' || typeof agentId !== 'string') return
      const next = (counters.get(agentId) ?? 0) + 1
      counters.set(agentId, next)
      if (next % notifyEvery !== 0) return
      env.notify({
        title: tone === 'firm' ? '注意！又完成了一组任务' : '又完成了一组任务',
        body: mentionSession
          ? `会话 ${shortId(agentId)} 已完成第 ${String(next)} 轮任务。`
          : `已完成第 ${String(next)} 轮任务。`,
        sessionId: agentId,
        meta: { turns: next },
      })
    }) as (...args: never[]) => unknown)
  },
}

/** 派生插件示例：子代理结束提醒（最小注册，无配置项）。 */
const subagentEnd: NotifierDefinition = {
  id: 'demo-subagent-end',
  title: '子代理结束',
  description: '派生插件示例：任意子代理（subagent）运行结束时提醒。没有 fields，卡片只显示开关与通道。',
  severity: 'info',
  channels: ['web', 'log'],
  defaultChannels: ['web'],
  setup(env) {
    const ctx = env.ctx as DemoCtx
    return ctx.on('subagent/end', ((info: SubagentEndInfo) => {
      const id = typeof info?.id === 'string' ? shortId(info.id) : '未知'
      const label = typeof info?.label === 'string' ? info.label : ''
      env.notify({
        title: '子代理结束',
        body: `${label === '' ? '' : `${label}（`}${id}${label === '' ? '' : '）'} 已结束运行。`,
      })
    }) as (...args: never[]) => unknown)
  },
}

export function apply(ctx: DemoCtx): void {
  const disposers = [
    ctx.notificationFrame.register(turnCounter),
    ctx.notificationFrame.register(subagentEnd),
  ]
  // 注册表返回 disposer；放进 fiber 生命周期，插件卸载时自动反注册。
  ctx.effect(() => () => {
    for (const dispose of disposers) dispose()
  }, 'dsh-notif-demo: unregister notifiers')
}
