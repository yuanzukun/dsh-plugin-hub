/**
 * dsh-notifacation-frame · 宿主打包入口。
 *
 * 唯一职责：把 host/plugin.js 的运行时与类型面（含 Context 增广）从包根
 * 再导出——布局与 dsh-plugin-vscode-sidebar 的 src/index.ts 一致，消费者
 * `import ... from 'dsh-notifacation-frame'` 或 `import type {} from
 * 'dsh-notifacation-frame'` 都从这里解析（types → lib/types/index.d.ts，
 * default → lib/index.js）。
 */
export * from './host/plugin.js'
