/**
 * dsh-notifacation-frame · 内置通知项（host）。
 *
 * 每个内置项与派生插件走完全相同的注册路径（registerBuiltin），并演示
 * 配置项元数据（fields）的用法：
 * - session-complete     会话 agent 完成任务（agent/status → idle）
 * - ask-user-question    agent 调用询问问题工具（tools/result，工具名过滤）
 * - process-crash        dsh 进程意外报错中止（uncaughtException /
 *                        unhandledRejection / 非零退出码）
 * - agent-error          agent 的 step/turn 报错（agent/error）
 * - agent-loop-config-start-failed 声明式 agent 启动失败
 * - tool-error           工具调用失败（tools/result isError，默认关闭，
 *                        可按逗号分隔名单排除噪声工具）
 * - dsh-update           dsh 包新版本检查（npm registry dist-tags 对比
 *                        本机安装版本，定期 + 启动时）
 *
 * 事件监听通过 env.ctx.on 注册（返回 disposer 交回框架做热重激活），
 * 周期任务通过 env.ctx.interval（timer mixin）注册；载荷只读叶子字段，
 * 不触碰/不复制任何 live data 对象。
 */
import type { NotifierDefinition } from '../shared.js'
import { checkForUpdate } from './update-check.js'

/** 内置项依赖的最小 cordis 上下文面（env.ctx 的窄化）。 */
interface EventCtx {
  on(name: string, listener: (...args: never[]) => unknown): () => void
  get(name: string): unknown
  /** timer mixin（框架行 inject: ['timer'] 后存在；缺位时跳过周期检查）。 */
  interval?(callback: () => void, delay: number): () => void
}

/** 内置项依赖的最小 cordis 上下文面（env.ctx 的窄化）。 */
interface EventCtx {
  on(name: string, listener: (...args: never[]) => unknown): () => void
  get(name: string): unknown
}

/** agents 服务的最小面（rootsOnly 过滤用；缺位时不过滤）。 */
interface AgentsFace {
  roots(): Array<{ id: unknown }>
}

const ctxOf = (env: { ctx: unknown }): EventCtx => env.ctx as EventCtx

function shortId(id: string): string {
  return id.length <= 12 ? id : `${id.slice(0, 6)}…${id.slice(-4)}`
}

function messageOf(error: unknown): string {
  if (error instanceof Error) return error.message
  if (typeof error === 'string') return error
  return 'unknown error'
}

// ── 1. 会话 agent 完成任务 ────────────────────────────────────────────────

const sessionComplete: NotifierDefinition = {
  id: 'session-complete',
  title: 'Agent 任务完成',
  description: '会话中的 agent 结束本轮任务、回到空闲状态时通知（仅对“见过其 running 状态”的 agent 触发，启动时的存量空闲 agent 不打扰）。',
  severity: 'success',
  channels: ['web', 'system', 'log'],
  defaultChannels: ['web'],
  defaultSound: 'chime',
  fields: [
    {
      key: 'rootsOnly',
      label: '仅顶层会话',
      type: 'boolean',
      default: true,
      description: '开启后只通知顶层会话 agent；关闭后子代理（subagent）结束也会通知。',
    },
  ],
  setup(env) {
    const ctx = ctxOf(env)
    const rootsOnly = env.config.rootsOnly === true
    const running = new Set<string>()

    const isRoot = (agentId: string): boolean => {
      if (!rootsOnly) return true
      const agents = ctx.get('agents') as AgentsFace | undefined
      if (agents === undefined || typeof agents.roots !== 'function') return true
      try {
        return agents.roots().some((agent) => agent.id === agentId)
      } catch {
        return true
      }
    }

    const off = ctx.on('agent/status', ((payload: {
      agent?: { id?: unknown }
      status?: unknown
    }) => {
      const agentId = payload?.agent?.id
      if (typeof agentId !== 'string') return
      if (payload.status === 'running') {
        running.add(agentId)
        return
      }
      if (payload.status === 'idle') {
        if (!running.delete(agentId)) return
        if (!isRoot(agentId)) return
        env.notify({
          severity: 'success',
          title: 'Agent 任务完成',
          body: `会话 ${shortId(agentId)} 的 agent 完成了本轮任务。`,
          sessionId: agentId,
        })
      }
    }) as (...args: never[]) => unknown)
    return off
  },
}

// ── 2. agent 调用询问问题工具 ─────────────────────────────────────────────

const askUserQuestion: NotifierDefinition = {
  id: 'ask-user-question',
  title: 'Agent 向你提问',
  description: '会话中的 agent 调用“询问问题”（ask_user_question）工具时通知——模型在等你回答。',
  severity: 'warning',
  channels: ['web', 'system', 'log'],
  defaultChannels: ['web', 'system'],
  defaultSound: 'ding',
  fields: [
    {
      key: 'showQuestion',
      label: '在通知里显示问题内容',
      type: 'boolean',
      default: true,
      description: '开启后通知正文附带模型提出的问题（最多 3 条）。',
    },
  ],
  setup(env) {
    const ctx = ctxOf(env)
    const showQuestion = env.config.showQuestion !== false

    const questionsOf = (rawArgs: unknown): string[] => {
      if (rawArgs === null || typeof rawArgs !== 'object') return []
      const questions = (rawArgs as { questions?: unknown }).questions
      if (!Array.isArray(questions)) return []
      const out: string[] = []
      for (const entry of questions) {
        if (entry === null || typeof entry !== 'object') continue
        const question = (entry as { question?: unknown }).question
        if (typeof question === 'string' && question !== '') out.push(question)
        if (out.length >= 3) break
      }
      return out
    }

    // 双源触发 + 会话级去重：提问呈现的那一刻通知，而不是等用户回答完。
    // - 新版 dsh（0.1.2+）：提问走 user-questions/request 水fall（呈现即触发）；
    // - 旧版 dsh：ask_user_question 工具经 tools/pre-execute（派发前触发）。
    // 两条路径都只是观察者：通知后立即 next() 放行，绝不干预提问流程。
    const lastNotifyAt = new Map<string, number>()
    const notify = (sessionId: string | undefined, questions: string[]): void => {
      const key = sessionId ?? ''
      const now = Date.now()
      const previous = lastNotifyAt.get(key)
      if (previous !== undefined && now - previous < 3000) return
      lastNotifyAt.set(key, now)
      const bodyParts: string[] = []
      if (sessionId !== undefined) bodyParts.push(`会话 ${shortId(sessionId)}`)
      bodyParts.push('的 agent 正在向你提问，请查看会话并回答。')
      let body = bodyParts.join(' ')
      if (showQuestion && questions.length > 0) {
        body += `\n${questions.map((question, index) => `${index + 1}. ${question}`).join('\n')}`
      }
      env.notify({
        severity: 'warning',
        title: 'Agent 向你提问',
        body,
        sessionId,
        meta: { tool: 'ask_user_question', questionCount: questions.length },
      })
    }

    const offUserQuestions = ctx.on('user-questions/request', ((request: {
      agent?: { id?: unknown }
      questions?: unknown
    }, next: () => unknown) => {
      const sessionId = typeof request?.agent?.id === 'string' ? request.agent.id : undefined
      const questions = Array.isArray(request?.questions)
        ? (request.questions as Array<{ question?: unknown }>)
            .filter((entry) => entry !== null && typeof entry === 'object' && typeof entry.question === 'string')
            .map((entry) => entry.question as string)
            .slice(0, 3)
        : []
      notify(sessionId, questions)
      return next()
    }) as (...args: never[]) => unknown)

    const offTools = ctx.on('tools/pre-execute', ((exec: {
      name?: unknown
      arguments?: unknown
      agent?: { id?: unknown }
    }, next: () => unknown) => {
      if (exec?.name === 'ask_user_question') {
        const sessionId = typeof exec.agent?.id === 'string' ? exec.agent.id : undefined
        notify(sessionId, questionsOf(exec.arguments))
      }
      return next()
    }) as (...args: never[]) => unknown)

    return () => {
      offUserQuestions()
      offTools()
    }
  },
}

// ── 3. 进程意外报错中止 ───────────────────────────────────────────────────

const processCrash: NotifierDefinition = {
  id: 'process-crash',
  title: '进程意外中止 / 崩溃',
  description: 'dsh 宿主进程发生未捕获异常、未处理的 Promise 拒绝，或以非零退出码中止时通知。默认走系统通知 + 日志（崩溃时网页可能已不可达）。',
  severity: 'error',
  channels: ['web', 'system', 'log'],
  defaultChannels: ['system', 'log'],
  defaultSound: 'alert',
  fields: [
    {
      key: 'includeUnhandledRejections',
      label: '包含未处理的 Promise 拒绝',
      type: 'boolean',
      default: true,
      description: '关闭后只有 uncaughtException 与非零退出码会通知。',
    },
  ],
  setup(env) {
    const includeRejections = env.config.includeUnhandledRejections !== false
    let crashNotified = false
    let lastRejectionAt = 0

    const notifyCrash = (kind: string, error: unknown): void => {
      crashNotified = true
      env.notify({
        severity: 'error',
        title: 'DSH 进程意外中止',
        body: `${kind}：${messageOf(error)}`,
        meta: { kind },
      })
    }

    const onUncaught = (error: unknown): void => {
      try {
        notifyCrash('uncaughtException', error)
      } catch {
        // 崩溃路径上的二次异常绝不能掩盖原始错误。
      }
      // 若宿主自己没有 uncaughtException 处理器，默认语义是进程中止：
      // 通知完成后以 1 退出，避免把进程留在僵尸状态。宿主有自己的处理器
      // （含终止逻辑）时，这里只是观察者，不做任何决定。
      if (process.listenerCount('uncaughtException') === 1) {
        process.exitCode = 1
      }
    }

    const onRejection = (reason: unknown): void => {
      const now = Date.now()
      if (now - lastRejectionAt < 5000) return
      lastRejectionAt = now
      env.notify({
        severity: 'error',
        title: '未处理的 Promise 拒绝',
        body: messageOf(reason),
        meta: { kind: 'unhandledRejection' },
      })
    }

    const onExit = (code: number): void => {
      if (code === 0) return
      if (crashNotified) return
      try {
        env.notify({
          severity: 'error',
          title: 'DSH 进程异常退出',
          body: `退出码 ${String(code)}（未经 uncaughtException 通知，可能是原生崩溃或外部终止）。`,
          meta: { kind: 'exit', exitCode: code },
        })
      } catch {
        // 退出路径上已无恢复手段。
      }
    }

    process.on('uncaughtException', onUncaught)
    if (includeRejections) process.on('unhandledRejection', onRejection)
    process.on('exit', onExit)
    return () => {
      process.off('uncaughtException', onUncaught)
      process.off('unhandledRejection', onRejection)
      process.off('exit', onExit)
    }
  },
}

// ── 4. agent 报错（我选定的需要通知的错误事件之一）──────────────────────

const agentError: NotifierDefinition = {
  id: 'agent-error',
  title: 'Agent 运行报错',
  description: '会话中 agent 的某个 step 或 turn 出错时通知（agent/error）。',
  severity: 'error',
  channels: ['web', 'system', 'log'],
  defaultChannels: ['web', 'log'],
  defaultSound: 'alert',
  setup(env) {
    const ctx = ctxOf(env)
    const off = ctx.on('agent/error', ((payload: {
      agent?: { id?: unknown }
      turn?: unknown
      step?: unknown
      error?: unknown
    }) => {
      const sessionId = typeof payload?.agent?.id === 'string' ? payload.agent.id : undefined
      const turn = typeof payload?.turn === 'number' ? String(payload.turn) : '?'
      const step = typeof payload?.step === 'number' ? String(payload.step) : '?'
      env.notify({
        severity: 'error',
        title: 'Agent 运行报错',
        body: `会话 ${sessionId === undefined ? '未知' : shortId(sessionId)} 在第 ${turn} 轮第 ${step} 步出错：${messageOf(payload?.error)}`,
        sessionId,
        meta: { turn, step },
      })
    }) as (...args: never[]) => unknown)
    return off
  },
}

// ── 5. 声明式 agent 启动失败（我选定的需要通知的错误事件之二）──────────

const agentLoopConfigStartFailed: NotifierDefinition = {
  id: 'agent-loop-config-start-failed',
  title: 'Agent 启动失败',
  description: '声明式 agent 条目在发布 live agent 之前就失败时通知（agent-loop/config-start-failed）。',
  severity: 'error',
  channels: ['web', 'system', 'log'],
  defaultChannels: ['web', 'system'],
  defaultSound: 'alert',
  setup(env) {
    const ctx = ctxOf(env)
    const off = ctx.on('agent-loop/config-start-failed', ((payload: {
      sessionId?: unknown
      error?: unknown
    }) => {
      const sessionId = typeof payload?.sessionId === 'string' ? payload.sessionId : undefined
      env.notify({
        severity: 'error',
        title: 'Agent 启动失败',
        body: `${sessionId === undefined ? '一个声明式 agent' : `会话 ${shortId(sessionId)} 的 agent`} 启动失败：${messageOf(payload?.error)}`,
        sessionId,
      })
    }) as (...args: never[]) => unknown)
    return off
  },
}

// ── 6. 工具调用失败（我选定的需要通知的错误事件之三，默认关闭）──────────

const toolError: NotifierDefinition = {
  id: 'tool-error',
  title: '工具调用失败',
  description: '某个工具调用以失败结果收尾时通知（tools/result isError）。工具失败很常见且模型通常会自动处理，故默认关闭，按需开启并可用排除名单滤掉噪声。',
  severity: 'warning',
  channels: ['web', 'system', 'log'],
  defaultChannels: ['web'],
  defaultEnabled: false,
  defaultSound: 'pop',
  fields: [
    {
      key: 'excludeNames',
      label: '排除的工具名单',
      type: 'string',
      default: '',
      description: '逗号分隔的工具名，命中即不通知（例如 bash,grep）。',
    },
  ],
  setup(env) {
    const ctx = ctxOf(env)
    const excluded = new Set(
      String(env.config.excludeNames ?? '')
        .split(',')
        .map((name) => name.trim())
        .filter((name) => name !== ''),
    )
    const off = ctx.on('tools/result', ((exec: {
      name?: unknown
      agent?: { id?: unknown }
    }, result: { isError?: unknown }) => {
      if (result?.isError !== true) return
      const name = typeof exec?.name === 'string' ? exec.name : 'unknown'
      if (excluded.has(name)) return
      const sessionId = typeof exec?.agent?.id === 'string' ? exec.agent.id : undefined
      env.notify({
        severity: 'warning',
        title: '工具调用失败',
        body: `工具 ${name} 调用失败${sessionId === undefined ? '' : `（会话 ${shortId(sessionId)}）`}，模型可能会重试。`,
        sessionId,
        meta: { tool: name },
      })
    }) as (...args: never[]) => unknown)
    return off
  },
}

// ── 7. dsh 包新版本检查 ───────────────────────────────────────────────────

const dshUpdate: NotifierDefinition = {
  id: 'dsh-update',
  title: 'DSH 新版本检查',
  description: '定期对比本机安装的 dsh 包与 npm registry 的最新版本，发现新版本时通知一次（每个新版本号只提醒一次）。',
  severity: 'info',
  channels: ['web', 'system', 'log'],
  defaultChannels: ['web', 'system'],
  defaultSound: 'ding',
  fields: [
    {
      key: 'packageName',
      label: '包名',
      type: 'string',
      default: '@deepseek-ai/dsh',
      description: '要检查的 npm 包名（本机未安装该包时静默跳过）。',
    },
    {
      key: 'checkOnStart',
      label: '启动时立即检查',
      type: 'boolean',
      default: true,
    },
    {
      key: 'intervalHours',
      label: '检查间隔（小时）',
      type: 'number',
      default: 24,
      min: 1,
      max: 168,
    },
  ],
  setup(env) {
    const ctx = ctxOf(env)
    const packageName = String(env.config.packageName ?? '').trim() || '@deepseek-ai/dsh'
    const checkOnStart = env.config.checkOnStart !== false
    const intervalMs = Math.max(1, Number(env.config.intervalHours) || 24) * 3600_000
    let notifiedVersion: string | undefined
    let checking = false

    const run = async (): Promise<void> => {
      if (checking) return
      checking = true
      try {
        const result = await checkForUpdate(packageName)
        if (
          result.status === 'update-available'
          && result.latest !== notifiedVersion
        ) {
          notifiedVersion = result.latest
          env.notify({
            severity: 'info',
            title: 'DSH 有新版本可用',
            body: `当前 ${result.current} → 最新 ${result.latest}。用包管理器更新 ${packageName} 后重启 dsh 生效。`,
            meta: { package: packageName, current: result.current, latest: result.latest },
          })
        }
      } catch {
        // 检查异常静默（网络/解析问题不应打扰用户）。
      } finally {
        checking = false
      }
    }

    if (checkOnStart) void run()
    const disposer = ctx.interval?.(() => void run(), intervalMs)
    return () => {
      disposer?.()
    }
  },
}

/** 全部内置通知项（plugin.ts 按序注册）。 */
export const builtinNotifiers: readonly NotifierDefinition[] = [
  sessionComplete,
  askUserQuestion,
  processCrash,
  agentError,
  agentLoopConfigStartFailed,
  toolError,
  dshUpdate,
]
