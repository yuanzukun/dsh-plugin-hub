/**
 * dsh-notifacation-frame · 宿主侧结构类型与 Context 增广。
 *
 * 与 dsh-plugin-vscode-sidebar 的 context-types 同策略：第三方插件在
 * monorepo 外的 cordis 实例解析，上游增广到不了这里，所以本插件消费的
 * 运行时面用结构类型镜像；`notificationFrame` 服务成员通过 declare module
 * 增广，派生插件 `import type {} from 'dsh-notifacation-frame'` 后即可
 * 获得 `ctx.notificationFrame` 的类型。
 */
import type { Context } from '@deepseek-ai/cordis'
import type { NotificationFrameService } from '../shared.js'

/** 结构化 HTTP 请求面（host 路由/升级处理器所见；与 wire.ts 的请求面一致）。 */
export interface NotifHttpRequest {
  url?: string
  method?: string
  headers: Record<string, string | string[] | undefined>
  [Symbol.asyncIterator](): AsyncIterator<string | Uint8Array>
}

/** 结构化 HTTP 响应面。 */
export interface NotifHttpResponse {
  statusCode: number
  writeHead(status: number, headers?: Record<string, string>): void
  end(body?: string | Uint8Array): void
}

/** 结构化升级 socket 面。 */
export interface NotifUpgradeSocket {
  destroy(): void
}

/** 结构化 webServer 服务面。 */
export interface NotifWebServer {
  register(route: {
    kind: 'exact' | 'prefix'
    path: string
    handler: (req: NotifHttpRequest, res: NotifHttpResponse) => void | Promise<void>
  }): () => void
  registerUpgrade(route: {
    path: string
    handler: (req: NotifHttpRequest, socket: NotifUpgradeSocket, head: Uint8Array) => void | Promise<void>
  }): () => void
}

/** webRuntime 服务面（信任栅栏的受信主机列表；缺位时仅回环放行）。 */
export interface NotifWebRuntime {
  trustedHosts: readonly string[]
}

/** settings 服务面（register + namespace 操作）。 */
export interface NotifSettingsProvider {
  register<T>(
    ns: string,
    schema: unknown,
    options?: { base?: Partial<T> },
  ): {
    get(): T
    watch(callback: (next: T, prev: T) => void | Promise<void>): () => void
    update(patch: object): Promise<void>
    replace(section: object): Promise<void>
  }
}

declare module '@deepseek-ai/cordis' {
  interface Context {
    /** dsh-notifacation-frame 提供的通知框架服务（派生插件注册通知项）。 */
    notificationFrame: NotificationFrameService
    webServer: NotifWebServer
  }
}
