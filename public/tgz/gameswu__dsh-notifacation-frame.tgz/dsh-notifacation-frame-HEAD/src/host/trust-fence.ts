/**
 * dsh-notifacation-frame · 宿主信任栅栏。
 *
 * 与 dsh-plugin-vscode-sidebar 的 trust-fence 同源：WebSocket 升级与
 * （未来的）HTTP 路由只接受回环地址或 web 运行时受信主机列表里的来源，
 * 与 /api 网关的信任模型一致——页面本身总是从 localhost 访问，局域网
 * 设备需要 DSH 的 --trusted-host 授权。
 */

/** 结构化的请求面（同 dsh-plugin-vscode-sidebar 的镜像，避免 Node 类型泄漏）。 */
export interface FenceHttpRequest {
  url?: string
  headers: Record<string, string | string[] | undefined>
}

const LOOPBACK_HOSTNAMES = new Set(['localhost', '127.0.0.1', '::1', '[::1]'])

/** 提取 Host 头的纯主机名（去端口、去括号、小写）。 */
export function hostnameOf(req: FenceHttpRequest): string | undefined {
  const raw = req.headers.host
  if (typeof raw !== 'string' || raw === '') return undefined
  const withoutPort = raw.trim().replace(/:\d+$/, '').toLowerCase()
  return withoutPort
}

export function isLoopbackHostname(hostname: string | undefined): boolean {
  if (hostname === undefined) return false
  return LOOPBACK_HOSTNAMES.has(hostname) || hostname === 'localhost.'
}

/**
 * 判断一个请求是否来自受信来源：Host 头是回环地址，或命中
 * webRuntime.trustedHosts（启动采样 + --trusted-host）。缺省放行
 * undefined 头部的场景由调用方决定，这里一律拒绝（fail-closed）。
 */
export function isTrustedRequest(req: FenceHttpRequest, trustedHosts: readonly string[]): boolean {
  const hostname = hostnameOf(req)
  if (hostname === undefined) return false
  if (isLoopbackHostname(hostname)) return true
  const lowered = hostname.toLowerCase()
  return trustedHosts.some((entry) => entry.toLowerCase() === lowered)
}
