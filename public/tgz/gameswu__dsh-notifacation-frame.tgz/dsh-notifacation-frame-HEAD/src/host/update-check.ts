/**
 * dsh-notifacation-frame · dsh 新版本检查（host）。
 *
 * 内置通知项 `dsh-update` 的核心逻辑：读取本机安装的包版本，再请求
 * npm registry 的 dist-tags，对比 semver（含 prerelease 语义），返回
 * 结构化结论。网络与解析全程尽力而为：任何失败都折叠为 `unknown`，
 * 绝不抛出。
 *
 * 依赖全部可注入（deps），单测不触网；默认实现：
 * - fetchJson：globalThis.fetch + AbortSignal.timeout；
 * - readInstalledVersion：从插件模块位置与宿主进程 cwd 两个基点做
 *   require.resolve 解析（pnp/pnpm 的不同安装形态都能命中其一），再向
 *   上攀爬目录读取最近的 package.json 的 version。
 */
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { createRequire } from 'node:module'

export interface UpdateCheckDeps {
  fetchJson(url: string, timeoutMs: number): Promise<unknown>
  readInstalledVersion(packageName: string): string | undefined
  log(line: string): void
}

export type UpdateCheckResult =
  | { status: 'update-available'; current: string; latest: string }
  | { status: 'up-to-date'; current: string }
  | { status: 'unknown'; current?: string }

/**
 * semver 比较（含 prerelease 语义）：返回 a>b 为正、a<b 为负、相等为 0。
 * 支持前导 v、缺省 patch（1.2 = 1.2.0）、prerelease 标识逐段比较
 * （数字段按数值、纯数字段优先级低于字母段、无 prerelease 高于有）。
 */
export function compareSemver(a: string, b: string): number {
  const parse = (raw: string): { core: number[]; pre: string[] } | null => {
    const match = /^[vV]?(\d+)(?:\.(\d+))?(?:\.(\d+))?(?:-([0-9A-Za-z.-]+))?(?:[+].*)?$/.exec(raw.trim())
    if (match === null) return null
    return {
      core: [Number(match[1]), Number(match[2] ?? 0), Number(match[3] ?? 0)],
      pre: match[4] === undefined ? [] : match[4].split('.'),
    }
  }
  const pa = parse(a)
  const pb = parse(b)
  if (pa === null || pb === null) {
    // 无法解析的版本只做字符串比较（保持稳定排序，避免误报）。
    return a < b ? -1 : a > b ? 1 : 0
  }
  for (let i = 0; i < 3; i++) {
    const da = pa.core[i] as number
    const db = pb.core[i] as number
    if (da !== db) return da > db ? 1 : -1
  }
  if (pa.pre.length === 0 && pb.pre.length === 0) return 0
  if (pa.pre.length === 0) return 1
  if (pb.pre.length === 0) return -1
  const length = Math.max(pa.pre.length, pb.pre.length)
  for (let i = 0; i < length; i++) {
    const ta = pa.pre[i]
    const tb = pb.pre[i]
    if (ta === undefined) return -1
    if (tb === undefined) return 1
    if (ta === tb) continue
    const na = /^\d+$/.test(ta)
    const nb = /^\d+$/.test(tb)
    if (na && nb) {
      const da = Number(ta)
      const db = Number(tb)
      if (da !== db) return da > db ? 1 : -1
      continue
    }
    // 纯数字标识符优先级低于字母标识符；其余按字典序。
    if (na !== nb) return na ? -1 : 1
    return ta < tb ? -1 : 1
  }
  return 0
}

const DIST_TAGS_URL = (packageName: string): string =>
  `https://registry.npmjs.org/-/package/${encodeURIComponent(packageName)}/dist-tags`

async function defaultFetchJson(url: string, timeoutMs: number): Promise<unknown> {
  const response = await fetch(url, { signal: AbortSignal.timeout(timeoutMs) })
  if (!response.ok) throw new Error(`registry responded ${String(response.status)}`)
  return await response.json() as unknown
}

function resolveFrom(baseFile: string, spec: string): string | undefined {
  try {
    return createRequire(baseFile).resolve(spec)
  } catch {
    return undefined
  }
}

/**
 * 读取本机安装版本：从两个基点（插件模块位置、宿主进程 cwd）解析包路径
 * （优先 `${pkg}/package.json`，无 exports 声明时才可命中；否则解析主入口
 * 再向上攀爬目录找最近的 package.json）。两个基点覆盖 pnpm/pnp 与全局
 * 安装等不同形态。
 */
function defaultReadInstalledVersion(packageName: string): string | undefined {
  const baseFiles = [import.meta.url, join(process.cwd(), '__dsh_resolve__.js')]
  for (const base of baseFiles) {
    const target = resolveFrom(base, `${packageName}/package.json`) ?? resolveFrom(base, packageName)
    if (target === undefined) continue
    let dir = dirname(target)
    for (let depth = 0; depth < 8; depth++) {
      try {
        const parsed = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8')) as { version?: unknown }
        if (typeof parsed.version === 'string' && parsed.version !== '') return parsed.version
      } catch {
        // 继续向上攀爬。
      }
      const parent = dirname(dir)
      if (parent === dir) break
      dir = parent
    }
  }
  return undefined
}

/**
 * 检查一个包是否有新版本。
 * @param packageName - npm 包名（如 '@deepseek-ai/dsh'）
 * @param deps - 可注入依赖（测试用）；缺省使用真实实现
 */
export async function checkForUpdate(
  packageName: string,
  deps?: Partial<UpdateCheckDeps>,
): Promise<UpdateCheckResult> {
  const resolved: UpdateCheckDeps = {
    fetchJson: defaultFetchJson,
    readInstalledVersion: defaultReadInstalledVersion,
    log: (line) => console.log(line),
    ...deps,
  }
  let current: string | undefined
  try {
    current = resolved.readInstalledVersion(packageName)
  } catch {
    current = undefined
  }
  if (current === undefined) {
    return { status: 'unknown' }
  }
  let payload: unknown
  try {
    payload = await resolved.fetchJson(DIST_TAGS_URL(packageName), 10000)
  } catch (error) {
    resolved.log(`[dsh-notifacation-frame] update check for "${packageName}" failed: ${error instanceof Error ? error.message : String(error)}`)
    return { status: 'unknown', current }
  }
  const latest = payload !== null && typeof payload === 'object'
    && typeof (payload as { latest?: unknown }).latest === 'string'
    ? (payload as { latest: string }).latest
    : undefined
  if (latest === undefined) return { status: 'unknown', current }
  if (compareSemver(latest, current) > 0) {
    return { status: 'update-available', current, latest }
  }
  return { status: 'up-to-date', current }
}
