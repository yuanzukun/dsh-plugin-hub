/**
 * dsh-notifacation-frame · 通道中枢（host）。
 *
 * 一条通知记录按该项配置的通道列表分发：
 * - web：广播给所有已连接的浏览器（WebSocket 由 plugin.ts 注册并注入客户端集合）
 * - log：console + 可选的通知日志文件（config.logFile）
 * - system：操作系统通知（Windows PowerShell 气泡 / Linux notify-send /
 *   macOS osascript），尽力而为，带冷却窗口防刷屏。
 *
 * 同时持有内存历史环形缓冲（设置页的“最近通知”与 toast 首次连接回放）。
 */
import { appendFile } from 'node:fs/promises'
import { spawn } from 'node:child_process'
import type { NotificationChannel, NotificationRecord, NotificationSeverity } from '../shared.js'

/** WebSocket 客户端的最小面（plugin.ts 注入真实 ws 实例）。 */
export interface WebClientLike {
  send(text: string): void
  close?(): void
}

/** 通道中枢的可调参数（来自组合行 config）。 */
export interface ChannelHubOptions {
  logFile: string
  historyLimit: number
  systemCooldownMs: number
  systemTimeoutMs: number
}

export interface ChannelHubLogger {
  (line: string): void
}

const MAX_TITLE = 128
const MAX_BODY = 512

function truncate(text: string, limit: number): string {
  return text.length <= limit ? text : `${text.slice(0, limit - 1)}…`
}

export class ChannelHub {
  /** 已连接的浏览器客户端（plugin.ts 在 WS 接入/断开时增删）。 */
  readonly webClients = new Set<WebClientLike>()
  private readonly history: NotificationRecord[] = []
  private readonly opts: ChannelHubOptions
  private readonly log: ChannelHubLogger
  private lastSystemAt = 0

  constructor(opts: ChannelHubOptions, logger: ChannelHubLogger = (line) => console.log(line)) {
    this.opts = opts
    this.log = logger
  }

  /** 投递一条记录到指定通道（各自尽力而为，永不抛出）。 */
  deliver(record: NotificationRecord, channels: readonly NotificationChannel[]): void {
    this.pushHistory(record)
    for (const channel of channels) {
      try {
        switch (channel) {
          case 'web':
            this.toWeb(record)
            break
          case 'log':
            this.toLog(record)
            break
          case 'system':
            this.toSystem(record)
            break
          default:
            break
        }
      } catch (error) {
        // A failing channel never blocks the others or the emitter.
        this.log(`[dsh-notifacation-frame] channel ${channel} failed: ${error instanceof Error ? error.message : String(error)}`)
      }
    }
  }

  /** 广播到浏览器（无客户端时静默跳过）。 */
  private toWeb(record: NotificationRecord): void {
    if (this.webClients.size === 0) return
    const frame = JSON.stringify({ type: 'notification', record })
    for (const client of this.webClients) {
      try {
        client.send(frame)
      } catch {
        // A dead socket is dropped by the WS close handler.
      }
    }
  }

  /** 控制台 + 可选文件。 */
  private toLog(record: NotificationRecord): void {
    const line = `[dsh-notifacation-frame] [${record.severity}] [${record.itemId}] ${record.title}${record.body !== undefined ? ` — ${record.body}` : ''}`
    this.log(line)
    if (this.opts.logFile === '') return
    const fileLine = `${new Date(record.at).toISOString()} ${JSON.stringify(line)}\n`
    void appendFile(this.opts.logFile, fileLine, 'utf8').catch((error: unknown) => {
      this.log(`[dsh-notifacation-frame] log file write failed: ${error instanceof Error ? error.message : String(error)}`)
    })
  }

  /** 操作系统通知（冷却窗口内跳过）。 */
  private toSystem(record: NotificationRecord): void {
    const now = Date.now()
    if (now - this.lastSystemAt < this.opts.systemCooldownMs) return
    this.lastSystemAt = now
    const title = truncate(`DSH · ${record.title}`, MAX_TITLE)
    const body = truncate(record.body ?? record.itemId, MAX_BODY)
    if (process.platform === 'win32') {
      void spawnPowershellToast(title, body, record.severity, this.opts.systemTimeoutMs, this.log)
    } else if (process.platform === 'darwin') {
      spawn('osascript', ['-e', `display notification ${JSON.stringify(body)} with title ${JSON.stringify(title)}`], {
        stdio: 'ignore',
      }).on('error', (error) => this.log(`[dsh-notifacation-frame] osascript failed: ${error.message}`))
    } else {
      spawn('notify-send', [title, body], { stdio: 'ignore' }).on('error', (error) => {
        this.log(`[dsh-notifacation-frame] notify-send failed: ${error.message}`)
      })
    }
  }

  pushHistory(record: NotificationRecord): void {
    this.history.push(record)
    const excess = this.history.length - this.opts.historyLimit
    if (excess > 0) this.history.splice(0, excess)
  }

  /** 最近通知（新在前）。 */
  recent(limit = 20): NotificationRecord[] {
    return this.history.slice(-limit).reverse()
  }
}

/**
 * Windows 托盘气泡通知（无 BurntToast 依赖）：NotifyIcon + ShowBalloonTip，
 * 通过 -EncodedCommand 传参避免引号转义。派生一个隐藏 powershell，在
 * 气泡展示结束后自毁；失败只记录日志，不影响宿主。
 */
async function spawnPowershellToast(
  title: string,
  body: string,
  severity: NotificationSeverity,
  timeoutMs: number,
  log: ChannelHubLogger,
): Promise<void> {
  const encode = (text: string): string => Buffer.from(text, 'utf8').toString('base64')
  const iconLine = severity === 'error'
    ? '[System.Drawing.SystemIcons]::Error'
    : severity === 'warning'
      ? '[System.Drawing.SystemIcons]::Warning'
      : '[System.Drawing.SystemIcons]::Information'
  const script = [
    'Add-Type -AssemblyName System.Windows.Forms',
    'Add-Type -AssemblyName System.Drawing',
    `$title = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String('${encode(title)}'))`,
    `$body = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String('${encode(body)}'))`,
    '$notify = New-Object System.Windows.Forms.NotifyIcon',
    `$notify.Icon = ${iconLine}`,
    '$notify.Visible = $true',
    '$notify.BalloonTipTitle = $title',
    '$notify.BalloonTipText = $body',
    `$notify.ShowBalloonTip(${Math.max(2000, timeoutMs)})`,
    `Start-Sleep -Milliseconds ${Math.max(2000, timeoutMs) + 500}`,
    '$notify.Dispose()',
  ].join('\n')
  const command = Buffer.from(script, 'utf16le').toString('base64')
  const child = spawn(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-EncodedCommand', command],
    { stdio: 'ignore', windowsHide: true },
  )
  child.on('error', (error) => log(`[dsh-notifacation-frame] powershell toast failed: ${error.message}`))
}
