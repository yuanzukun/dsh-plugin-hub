/**
 * dsh-notifacation-frame · 线缆助手（与 dsh-plugin-vscode-sidebar 的
 * src/wire.ts 同形状）：有界 JSON 请求体读取与 `{ok, value|error}` 信封
 * 响应。设置卡片通过自有 fenced 路由 /notification-frame/api 读写——
 * 不依赖 Remote 网关（vscode-sidebar 同款选择：settings 命名空间的远程
 * 暴露白名单是上游硬编码的，第三方插件用自有路由承载配置 UI）。
 */

/** 结构化 HTTP 请求面（宿主路由处理器所见；与 Node IncomingMessage 结构兼容）。 */
export interface NotifHttpRequest {
  url?: string
  method?: string
  headers: Record<string, string | string[] | undefined>
  [Symbol.asyncIterator](): AsyncIterator<string | Uint8Array>
}

/** 结构化 HTTP 响应面。 */
export interface NotifHttpResponse {
  statusCode: number
  writeHead(status: number, headers?: Record<string, string>): void
  end(body?: string | Uint8Array): void
}

/** 机器可读错误码。 */
export type NotifApiErrorCode =
  | 'bad-request'
  | 'not-found'
  | 'forbidden'
  | 'method-error'
  | 'internal'

/** 单个 API 失败及其线缆码与 HTTP 状态。 */
export class NotifApiError extends Error {
  constructor(
    readonly code: NotifApiErrorCode,
    message: string,
    readonly status = 400,
  ) {
    super(message)
  }
}

/** 单个 JSON 请求体的字节上限。 */
const MAX_BODY_BYTES = 1 << 20

/** 有界读取 + 解析 JSON 请求体（畸形 → bad-request）。 */
export async function readJsonBody(req: NotifHttpRequest): Promise<unknown> {
  const chunks: Buffer[] = []
  let total = 0
  for await (const chunk of req) {
    const buffer = Buffer.from(chunk)
    total += buffer.length
    if (total > MAX_BODY_BYTES) {
      throw new NotifApiError('bad-request', 'request body too large')
    }
    chunks.push(buffer)
  }
  const text = Buffer.concat(chunks).toString('utf8')
  if (text.trim() === '') return {}
  try {
    return JSON.parse(text) as unknown
  } catch {
    throw new NotifApiError('bad-request', 'request body is not valid JSON')
  }
}

/** 以给定状态写出 JSON。 */
export function writeJson(res: NotifHttpResponse, status: number, body: unknown): void {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
  res.end(JSON.stringify(body))
}

/** 成功信封。 */
export function writeOk(res: NotifHttpResponse, value: unknown): void {
  writeJson(res, 200, { ok: true, value })
}

/** 失败信封（未知抛出值 → internal 500）。 */
export function writeError(res: NotifHttpResponse, error: unknown): void {
  if (error instanceof NotifApiError) {
    writeJson(res, error.status, { ok: false, error: { code: error.code, message: error.message } })
    return
  }
  writeJson(res, 500, { ok: false, error: { code: 'internal', message: error instanceof Error ? error.message : String(error) } })
}

/** 窄化载荷字段为字符串，否则 bad-request。 */
export function requireString(payload: unknown, key: string): string {
  const record = payload as Record<string, unknown> | null
  const value = record?.[key]
  if (typeof value !== 'string' || value === '') {
    throw new NotifApiError('bad-request', `missing or invalid "${key}"`)
  }
  return value
}
