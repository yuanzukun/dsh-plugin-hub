/**
 * dsh-notifacation-frame · Host 插件入口（持久形态，唯一入口）。
 *
 * 职责：
 * - 组合行 config（Config schema）提供框架级参数（日志文件、历史长度、
 *   系统通知冷却、WS 路径）；
 * - 注册 settings 命名空间 `dsh-notifacation-frame` 持久化每个通知项的
 *   用户配置（{ items: { [id]: { enabled, channels, options } } }），
 *   组合行 config 之下、用户设置之上；
 * - 构造通知注册表并 `ctx.provide('notificationFrame', registry)`，
 *   供派生插件 `inject: ['notificationFrame']` 后注册自己的通知项；
 * - 注册 7 个内置通知项（session-complete / ask-user-question /
 *   process-crash / agent-error / agent-loop-config-start-failed /
 *   tool-error / dsh-update）；
 * - 注册 fenced JSON 路由 /notification-frame/api（catalog / setItem /
 *   history / test）作为设置页配置卡片的读写通道——与
 *   dsh-plugin-vscode-sidebar 的 /sidebar/api 同款选择：settings 命名空间
 *   的远程暴露白名单是上游硬编码的，第三方插件用自有 fenced 路由承载
 *   配置 UI（信封 {ok, value|error}，信任栅栏与 /api 网关同源）；
 * - 通过 webServer.registerUpgrade 挂载 /notification-frame/ws 推送
 *   通道（信任栅栏与 /api 网关同源），把通知与 catalog 变更推给浏览器。
 */
import z from '@deepseek-ai/schemastery'
import type { Context } from '@deepseek-ai/cordis'
import { WebSocket, WebSocketServer } from 'ws'
import type { IncomingMessage } from 'node:http'
import type { Duplex } from 'node:stream'
import {
  type NotifierConfigBlob,
} from '../shared.js'
import { ChannelHub } from './channels.js'
import { NotificationRegistry, type RegistryOptions, type RegistrySettingsFace } from './registry.js'
import { builtinNotifiers } from './builtins.js'
import { isTrustedRequest, type FenceHttpRequest } from './trust-fence.js'
import {
  NotifApiError,
  readJsonBody,
  requireString,
  writeError,
  writeJson,
  writeOk,
  type NotifHttpRequest,
  type NotifHttpResponse,
} from './wire.js'
import type { NotifSettingsProvider, NotifWebRuntime } from './types.js'

export const name = 'dsh-notifacation-frame'

// 面向派生插件的公开类型（与 Context 增广一起从包入口导出）。
export type {
  NotificationFrameService,
  NotifierDefinition,
  NotifierField,
  NotifierEnv,
  NotifierConfigBlob,
  NotifierItemView,
  NotificationRecord,
  NotificationChannel,
  NotificationSeverity,
  FeedMessage,
} from '../shared.js'
// Context 增广（ctx.notificationFrame / ctx.webServer）必须随包入口显式
// 再导出：type-only import 在 d.ts 发射时会被省略。
export type * from './types.js'

/** 硬依赖：webServer（WS 推送）、timer（内置项周期检查）。settings / webRuntime 可选读取。 */
export const inject = ['webServer', 'timer'] as string[]

/**
 * 组合行 config（官方约定：导出与 Config 同名的 Schemastery schema，
 * loader 在加载时校验并填充默认值）。
 */
export interface Config {
  logFile?: string
  historyLimit?: number
  systemCooldownMs?: number
  systemTimeoutMs?: number
  webSocketPath?: string
}

export const Config = z.object({
  /** 通知日志文件（'' = 仅控制台）。 */
  logFile: z.string().default(''),
  /** 内存历史环形缓冲长度。 */
  historyLimit: z.number().step(1).min(1).max(1000).default(100),
  /** 系统通知冷却（防刷屏）。 */
  systemCooldownMs: z.number().step(1).min(0).max(60000).default(5000),
  /** 系统通知气泡展示时长。 */
  systemTimeoutMs: z.number().step(1).min(2000).max(30000).default(8000),
  /** host→client 推送 WebSocket 路径。 */
  webSocketPath: z.string().default('/notification-frame/ws'),
})

/** 直接调用时的默认值（绕过 loader 校验）。 */
export interface ResolvedConfig {
  logFile: string
  historyLimit: number
  systemCooldownMs: number
  systemTimeoutMs: number
  webSocketPath: string
}

export function resolveConfig(config: Config | undefined): ResolvedConfig {
  return {
    logFile: config?.logFile ?? '',
    historyLimit: config?.historyLimit ?? 100,
    systemCooldownMs: config?.systemCooldownMs ?? 5000,
    systemTimeoutMs: config?.systemTimeoutMs ?? 8000,
    webSocketPath: config?.webSocketPath ?? '/notification-frame/ws',
  }
}

const SETTINGS_NS = 'dsh-notifacation-frame'

/** settings 命名空间 schema：每个通知项的 blob 是开放结构（enabled /
 *  channels / options / sound / soundUrl），options 内部是完全开放的
 *  JSON——派生插件自己的字段不进框架 schema，由注册表按各自 fields
 *  元数据解析校验。 */
const SettingsSchema = z.object({
  items: z.dict(z.object({
    enabled: z.boolean().default(true),
    channels: z.array(z.string()).default([]),
    options: z.dict(z.any()).default({}),
    sound: z.string().default('none'),
    soundUrl: z.string().default(''),
  })).default({}),
})

interface SettingsValue {
  items: Record<string, NotifierConfigBlob>
}

/**
 * 设置页配置卡片的 JSON API 方法表（fenced 路由的处理器，闭包捕获注册表）。
 */
export function apply(ctx: Context, config?: Config): void {
  const resolved = resolveConfig(config)
  const hub = new ChannelHub(resolved)

  // 注册表：settings 面延迟绑定（settings 服务缺位时退化为内存配置）。
  const registryOptions: RegistryOptions = {
    hub,
    boundCtx: ctx,
    onCatalogChanged: () => broadcastCatalog(hub),
  }
  const registry = new NotificationRegistry(registryOptions)

  // ── settings 命名空间（用户配置持久层 + 热生效 watch）─────────────────
  ctx.inject(['settings'], (sctx) => {
    const settings = (sctx as unknown as { settings: NotifSettingsProvider }).settings
    const scope = settings.register<SettingsValue>(SETTINGS_NS, SettingsSchema, { base: {} })
    const face: RegistrySettingsFace = {
      getItems: () => {
        try {
          return scope.get().items ?? {}
        } catch {
          return {}
        }
      },
      persistItems: async (items) => {
        await scope.replace({ items })
      },
    }
    registryOptions.settings = face
    // 绑定后重解析全部配置（此前以默认值激活的内置项对齐到用户设置）。
    registry.reconcile()
    scope.watch(() => registry.reconcile())
  })

  // ── 内置通知项 ──────────────────────────────────────────────────────────
  for (const def of builtinNotifiers) {
    registry.registerBuiltin(def)
  }

  // ── 派生插件服务面 ──────────────────────────────────────────────────────
  ctx.provide('notificationFrame', registry)

  // ── 设置卡片 JSON API（fenced 路由，同 vscode-sidebar 的 /sidebar/api）──
  const apiMethods: Record<string, (payload: unknown) => Promise<unknown> | unknown> = {
    catalog: () => ({ items: registry.list() }),
    setItem: async (payload) => {
      const id = requireString(payload, 'id')
      const record = payload as { blob?: unknown } | null
      const blob = record?.blob
      if (blob === null || typeof blob !== 'object' || Array.isArray(blob)) {
        throw new NotifApiError('bad-request', 'blob must be a plain object')
      }
      await registry.updateItem(id, blob as NotifierConfigBlob)
      return { items: registry.list() }
    },
    history: (payload) => {
      const record = payload as { limit?: unknown } | null
      const limit = typeof record?.limit === 'number' && Number.isFinite(record.limit)
        ? Math.min(200, Math.max(1, Math.floor(record.limit)))
        : 20
      return { history: registry.history(limit) }
    },
    test: (payload) => {
      registry.test(requireString(payload, 'id'))
      return { ok: true }
    },
  }
  const webRuntime = ctx.get('webRuntime') as NotifWebRuntime | undefined
  const fence = (req: FenceHttpRequest): boolean =>
    isTrustedRequest(req, webRuntime?.trustedHosts ?? [])
  ctx.effect(() => ctx.webServer.register({
    kind: 'prefix',
    path: '/notification-frame/api',
    handler: async (req: NotifHttpRequest, res: NotifHttpResponse) => {
      if (!fence(req)) {
        writeJson(res, 403, { ok: false, error: { code: 'forbidden', message: 'forbidden' } })
        return
      }
      if (req.method !== 'POST') {
        writeJson(res, 405, { ok: false, error: { code: 'method-error', message: 'method not allowed' } })
        return
      }
      const pathname = new URL(req.url ?? '/', 'http://dsh.internal').pathname
      const method = pathname.startsWith('/notification-frame/api/')
        ? pathname.slice('/notification-frame/api/'.length)
        : undefined
      if (method === undefined || method.includes('/')) {
        writeError(res, new NotifApiError('not-found', 'unknown notification-frame API method', 404))
        return
      }
      try {
        const payload = await readJsonBody(req)
        const handler = apiMethods[method]
        if (handler === undefined) {
          throw new NotifApiError('not-found', `unknown notification-frame API method "${method}"`, 404)
        }
        writeOk(res, await handler(payload))
      } catch (error) {
        writeError(res, error)
      }
    },
  }), 'dsh-notifacation-frame: /notification-frame/api routes')

  // ── host→client 推送 WebSocket ──────────────────────────────────────────
  const wss = new WebSocketServer({ noServer: true })
  const attach = (ws: WebSocket): void => {
    hub.webClients.add(ws)
    const hello = JSON.stringify({
      type: 'hello',
      items: registry.list(),
      history: registry.history(20),
    })
    try {
      ws.send(hello)
    } catch {
      // Socket died between upgrade and hello — the close handler removes it.
    }
    ws.on('close', () => hub.webClients.delete(ws))
    ws.on('error', () => hub.webClients.delete(ws))
  }
  ctx.effect(() => ctx.webServer.registerUpgrade({
    path: resolved.webSocketPath,
    handler: (req, socket, head) => {
      if (!fence(req)) {
        socket.destroy()
        return
      }
      wss.handleUpgrade(
        req as unknown as IncomingMessage,
        socket as unknown as Duplex,
        head as Buffer,
        (ws) => attach(ws),
      )
    },
  }), 'dsh-notifacation-frame: notification WebSocket feed')

  // ── 停机清理 ────────────────────────────────────────────────────────────
  ctx.effect(() => () => {
    for (const client of hub.webClients) {
      try {
        client.close?.()
      } catch {
        // Socket already gone.
      }
    }
    hub.webClients.clear()
    wss.close()
    registry.disposeAll()
  }, 'dsh-notifacation-frame: teardown')

  const channels = resolved.logFile === '' ? 'console' : `console + ${resolved.logFile}`
  console.log(`[dsh-notifacation-frame] notification framework active: ${registry.list().length} notifiers, log=${channels}, ws=${resolved.webSocketPath}`)
}

/** 目录变化广播（配置热生效后客户端刷新卡片）。 */
function broadcastCatalog(hub: ChannelHub): void {
  if (hub.webClients.size === 0) return
  const frame = JSON.stringify({ type: 'catalog' })
  for (const client of hub.webClients) {
    try {
      client.send(frame)
    } catch {
      // Dead socket — WS close handler drops it.
    }
  }
}
