/**
 * dsh-notifacation-frame · 通知注册表（框架核心，host）。
 *
 * 统一管理通知事件：内置通知与派生插件共用同一个注册入口
 * `register(definition)`，框架负责——
 * 1. 把设置文档里的 blob（enabled / channels / options）解析、校验、
 *    补默认之后形成该项的生效配置；
 * 2. 调用 definition.setup(env) 激活事件监听（env.config 即解析后的
 *    派生配置，env.notify 是统一投递入口）；
 * 3. 用户修改设置卡片时热重激活（先 dispose 旧 setup，再用新配置
 *    重新 setup），派生插件无需关心配置读写与持久化；
 * 4. 投递时按生效配置过滤（禁用项静默丢弃）并按通道分发。
 *
 * 注册表通过 `ctx.provide('notificationFrame', registry)` 暴露给派生插件：
 * `inject: ['notificationFrame']` 后经 `ctx.notificationFrame.register(...)`
 * 使用。设置服务缺位时退化为进程内内存配置（不持久化）。
 */
import type { Context } from '@deepseek-ai/cordis'
import {
  makeRecord,
  normalizeChannels,
  resolveBlob,
  type NotifierConfigBlob,
  type NotifierDefinition,
  type NotifierItemView,
  type NotificationFrameService,
  type NotificationRecord,
} from '../shared.js'
import type { ChannelHub } from './channels.js'

/** 注册表读取/写入设置文档的窄面（plugin.ts 绑定 settings scope）。 */
export interface RegistrySettingsFace {
  /** 读取整个用户设置区（解析后的 { items: { [id]: blob } }）。 */
  getItems(): Record<string, NotifierConfigBlob>
  /** 整区替换写回（含 revision 保护）。 */
  persistItems(items: Record<string, NotifierConfigBlob>): Promise<void>
}

export interface RegistryOptions {
  hub: ChannelHub
  settings?: RegistrySettingsFace
  /** 通知项生效配置变化时回调（plugin.ts 用它向浏览器广播 catalog 刷新）。 */
  onCatalogChanged?: () => void
  logger?: (line: string) => void
  /** 注入派生插件 env.ctx 的真实 cordis 上下文（plugin.ts 构造后绑定）。 */
  boundCtx?: Context
}

interface RegisteredItem {
  def: NotifierDefinition
  source: 'builtin' | 'plugin'
  /** 最近一次 setup 返回的 disposer（配置热生效时先执行）。 */
  disposer: (() => void) | undefined
  /** 当前生效配置缓存。 */
  config: NotifierItemView['config']
  setupError?: string
}

export class NotificationRegistry implements NotificationFrameService {
  private readonly items = new Map<string, RegisteredItem>()
  private readonly opts: RegistryOptions
  private readonly log: (line: string) => void

  constructor(opts: RegistryOptions) {
    this.opts = opts
    this.log = opts.logger ?? ((line) => console.log(line))
  }

  // ── 派生插件入口 ────────────────────────────────────────────────────────

  register(def: NotifierDefinition): () => void {
    return this.registerAs(def, 'plugin')
  }

  /** 框架内置通知项的注册入口（source = 'builtin'，卡片显示内置徽标）。 */
  registerBuiltin(def: NotifierDefinition): () => void {
    return this.registerAs(def, 'builtin')
  }

  private registerAs(def: NotifierDefinition, source: 'builtin' | 'plugin'): () => void {
    const id = def.id
    if (typeof id !== 'string' || id === '') {
      throw new Error('[dsh-notifacation-frame] notifier id must be a non-empty string')
    }
    const previous = this.items.get(id)
    if (previous !== undefined) {
      this.dispose(previous)
      this.log(`[dsh-notifacation-frame] notifier "${id}" re-registered (previous instance disposed)`)
    }
    const item: RegisteredItem = {
      def,
      source,
      disposer: undefined,
      config: this.resolveConfig(def),
    }
    this.items.set(id, item)
    this.activate(id, item)
    this.opts.onCatalogChanged?.()
    this.log(`[dsh-notifacation-frame] notifier "${id}" registered`)
    let disposed = false
    return () => {
      if (disposed) return
      disposed = true
      const current = this.items.get(id)
      if (current !== undefined && current.def === def) {
        this.dispose(current)
        this.items.delete(id)
        this.opts.onCatalogChanged?.()
        this.log(`[dsh-notifacation-frame] notifier "${id}" unregistered`)
      }
    }
  }

  /** 设置文档 + 定义默认值的合并解析（派生插件配置项解析的核心路径）。 */
  private resolveConfig(def: NotifierDefinition): NotifierItemView['config'] {
    const stored = this.opts.settings?.getItems()[def.id]
    return resolveBlob(def, stored)
  }

  /** 用当前生效配置激活一个通知项（setup 抛出时标记错误、不传染）。 */
  private activate(id: string, item: RegisteredItem): void {
    this.dispose(item)
    try {
      const env = {
        notify: (payload: {
          title: string
          body?: string
          severity?: NotifierDefinition['severity']
          sessionId?: string
          meta?: Record<string, unknown>
        }) => {
          this.emit(id, item, payload)
        },
        config: item.config.options,
        ctx: undefined as unknown,
      }
      // plugin.ts 通过 bindCtx 注入真实 cordis 上下文（注册表保持对
      // cordis 类型零依赖，便于单测）。
      const envCtx = this.opts.boundCtx
      if (envCtx !== undefined) env.ctx = envCtx
      const disposer = item.def.setup(env)
      item.disposer = typeof disposer === 'function' ? disposer : undefined
      item.setupError = undefined
    } catch (error) {
      item.setupError = error instanceof Error ? error.message : String(error)
      this.log(`[dsh-notifacation-frame] notifier "${id}" setup failed: ${item.setupError}`)
    }
  }

  private dispose(item: RegisteredItem): void {
    if (item.disposer === undefined) return
    try {
      item.disposer()
    } catch (error) {
      this.log(`[dsh-notifacation-frame] notifier "${item.def.id}" disposer failed: ${error instanceof Error ? error.message : String(error)}`)
    }
    item.disposer = undefined
  }

  // ── 统一投递 ────────────────────────────────────────────────────────────

  /** 从通知项内部投递（遵守 enabled 开关与通道配置）。 */
  private emit(id: string, item: RegisteredItem, payload: {
    title: string
    body?: string
    severity?: NotifierDefinition['severity']
    sessionId?: string
    meta?: Record<string, unknown>
  }): void {
    if (!item.config.enabled) return
    const record = makeRecord({
      itemId: id,
      severity: payload.severity ?? item.def.severity,
      title: payload.title,
      body: payload.body,
      sessionId: payload.sessionId,
      meta: payload.meta,
      sound: { preset: item.config.sound, url: item.config.soundUrl },
    })
    this.opts.hub.deliver(record, item.config.channels)
  }

  /** 外部直接投递（测试按钮 / 其他宿主插件；不经过通知项开关）。 */
  dispatch(payload: {
    itemId: string
    title: string
    body?: string
    severity?: NotifierDefinition['severity']
    sessionId?: string
    meta?: Record<string, unknown>
  }): void {
    const item = this.items.get(payload.itemId)
    const record = makeRecord({
      itemId: payload.itemId,
      severity: payload.severity ?? item?.def.severity ?? 'info',
      title: payload.title,
      body: payload.body,
      sessionId: payload.sessionId,
      meta: payload.meta,
    })
    const channels = item === undefined || item.config.channels.length === 0
      ? (['log'] as const)
      : item.config.channels
    this.opts.hub.deliver(record, channels)
  }

  /** 通过某项配置的通道发送一条测试通知（禁用项也可测试）。 */
  test(id: string): void {
    const item = this.items.get(id)
    if (item === undefined) {
      this.log(`[dsh-notifacation-frame] test failed: unknown notifier "${id}"`)
      return
    }
    const record = makeRecord({
      itemId: id,
      severity: item.def.severity,
      title: `测试通知 · ${item.def.title}`,
      body: '如果你能看到这条消息，说明该项的通道配置生效。',
      sound: { preset: item.config.sound, url: item.config.soundUrl },
    })
    const channels = item.config.channels.length > 0 ? item.config.channels : (['log'] as const)
    this.opts.hub.deliver(record, channels)
  }

  // ── 查询与配置 ──────────────────────────────────────────────────────────

  list(): NotifierItemView[] {
    const views: NotifierItemView[] = []
    for (const [id, item] of this.items) {
      views.push({
        id,
        title: item.def.title,
        description: item.def.description,
        severity: item.def.severity,
        supportedChannels: [...item.def.channels],
        defaultChannels: [...item.def.defaultChannels],
        fields: item.def.fields ?? [],
        source: item.source,
        setupError: item.setupError,
        config: {
          enabled: item.config.enabled,
          channels: [...item.config.channels],
          options: { ...item.config.options },
          sound: item.config.sound,
          soundUrl: item.config.soundUrl,
        },
      })
    }
    return views.sort((a, b) => a.id.localeCompare(b.id))
  }

  history(limit = 20): NotificationRecord[] {
    return this.opts.hub.recent(limit)
  }

  /** 更新一个通知项的用户配置：校验、持久化、热重激活。 */
  async updateItem(id: string, blob: NotifierConfigBlob): Promise<void> {
    const item = this.items.get(id)
    if (item === undefined) {
      throw new Error(`unknown notifier "${id}"`)
    }
    // 先解析成合法配置，再持久化（写入设置文档的永远是干净值）。
    const next = resolveBlob(item.def, blob)
    item.config = next
    if (this.opts.settings !== undefined) {
      const items = { ...this.opts.settings.getItems() }
      items[id] = {
        enabled: next.enabled,
        channels: [...next.channels],
        options: { ...next.options },
        sound: next.sound,
        soundUrl: next.soundUrl,
      }
      await this.opts.settings.persistItems(items)
    }
    this.activate(id, item)
    this.opts.onCatalogChanged?.()
    this.log(`[dsh-notifacation-frame] notifier "${id}" config updated: ${JSON.stringify({ enabled: next.enabled, channels: next.channels, sound: next.sound })}`)
  }

  /** 设置文档变化（外部编辑 / 其他写入方）时整体刷新。 */
  reconcile(): void {
    for (const [id, item] of this.items) {
      const next = this.resolveConfig(item.def)
      const same =
        next.enabled === item.config.enabled
        && next.channels.length === item.config.channels.length
        && next.channels.every((channel, index) => channel === item.config.channels[index])
        && JSON.stringify(next.options) === JSON.stringify(item.config.options)
        && next.sound === item.config.sound
        && next.soundUrl === item.config.soundUrl
      if (same) continue
      item.config = next
      this.activate(id, item)
      this.log(`[dsh-notifacation-frame] notifier "${id}" reconciled from settings document`)
    }
    this.opts.onCatalogChanged?.()
  }

  /** 插件停止时释放全部通知项（setup disposer + 注册表清空）。 */
  disposeAll(): void {
    for (const item of this.items.values()) {
      this.dispose(item)
    }
    this.items.clear()
    this.opts.onCatalogChanged?.()
  }
}
