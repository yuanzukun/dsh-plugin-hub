/**
 * dsh-notifacation-frame · Client 入口（浏览器 bundle，由 tsdown 打包为
 * window.__ModuleLoader__.load 格式，id = dsh-notifacation-frame）。
 *
 * 两部分 UI（控件为本地供应商化的 DSH 原子：src/client/ui.ts——Button /
 * Input / Pill / StateDot / Toast，样式只经 --dsw-* 主题令牌；选择自足而非
 * 依赖共享 primitives，后者在 0.1.5 平台基线仍存在）：
 * 1. Settings → “通知” 页（settings.section）：每个通知项一张配置卡片——
 *    开关（与 dsh-plugin-vscode-sidebar 的 SideCardSection 同款结构）、
 *    通道 Pill 复选、派生插件配置项（Input / 开关 / 原生 select）、测试按钮、
 *    最近通知历史（StateDot 严重级别 + 跳转会话）。读写走 Host 的 fenced
 *    JSON 路由 /notification-frame/api（{ok, value|error} 信封），热生效。
 * 2. 通知横幅（shell.overlay）：用 DSH 原生 Toast 原子逐条展示推送通知
 *    （顶部居中、自动消退；并发到达按队列逐个展示）。
 *
 * 页面级 CSS 只保留布局与令牌着色，不再手写按钮/输入框外观。
 */
import { createElement as h, useEffect, useState, type ReactNode } from 'react'
import { Button, Input, Pill, StateDot, Toast, type StateDotState } from './ui.js'
import bellSvg from '../../assets/icons/bell-outline-16.svg?raw'
import {
  SOUND_PRESETS,
  type NotificationChannel,
  type NotifierField,
  type NotifierItemView,
  type NotificationRecord,
  type NotificationSeverity,
} from '../shared.js'
import { playSound } from './sounds.js'
import { createSessionOpener, type NotificationSessionsFace } from './session-open.js'

/** Cordis context subset the plugin face needs. */
interface PluginCtx {
  slots: {
    register(options: Record<string, unknown>, component: unknown): () => void
    inject(key: string, callback: () => unknown): void
  }
  get(name: string): unknown
  effect(callback: () => void | (() => void), label?: string): void
}

export const name = 'dsh-notifacation-frame'
export const inject = ['slots'] as string[]

// ── 严重级别 → DSH 语义映射 ───────────────────────────────────────────────

const SEVERITY_LABEL: Record<NotificationSeverity, string> = {
  info: '信息',
  success: '完成',
  warning: '提醒',
  error: '错误',
}

const SEVERITY_DOT: Record<NotificationSeverity, StateDotState> = {
  info: 'ongoing',
  success: 'done',
  warning: 'warning',
  error: 'error',
}

const CHANNEL_LABEL: Record<string, string> = {
  web: '网页内提示',
  system: '系统通知',
  log: '日志',
}

/**
 * 通知铃铛字形：独立 SVG 资源文件 assets/icons/bell-outline-16.svg
 * （stroke=currentColor 随主题令牌着色），构建时以 ?raw 内联文本渲染。
 */
function BellIcon(props: { size?: number; className?: string }): ReactNode {
  const size = props.size ?? 16
  return h('span', {
    className: props.className,
    style: { display: 'inline-flex', width: size, height: size },
    'aria-hidden': 'true',
    dangerouslySetInnerHTML: { __html: bellSvg },
  })
}

// ── fenced JSON API（同 vscode-sidebar 的 api.ts：POST + 信封解析）────────

/** 单个线缆失败。 */
class NotifApiError extends Error {
  constructor(
    readonly code: string,
    message: string,
  ) {
    super(message)
  }
}

async function apiCall<T>(method: string, payload: Record<string, unknown>): Promise<T> {
  let response: Response
  try {
    response = await fetch(`/notification-frame/api/${method}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
    })
  } catch (error) {
    throw new NotifApiError('network', error instanceof Error ? error.message : String(error))
  }
  const parsed = await response.json().catch(() => null) as
    | { ok?: boolean; value?: unknown; error?: { code?: string; message?: string } }
    | null
  if (!response.ok || parsed === null || parsed.ok !== true || parsed.value === undefined) {
    throw new NotifApiError(
      parsed?.error?.code ?? 'http',
      parsed?.error?.message ?? `HTTP ${String(response.status)}`,
    )
  }
  return parsed.value as T
}

/** 设置卡片的 API 面（目录 / 写配置 / 历史 / 测试）。 */
const api = {
  catalog: () => apiCall<{ items: NotifierItemView[] }>('catalog', {}),
  setItem: (id: string, blob: Record<string, unknown>) =>
    apiCall<{ items: NotifierItemView[] }>('setItem', { id, blob }),
  history: (limit: number) => apiCall<{ history: NotificationRecord[] }>('history', { limit }),
  test: (id: string) => apiCall<{ ok: boolean }>('test', { id }),
}

// ── 包级布局样式（只做布局与令牌着色，不重画控件外观）────────────────────

const NF_CSS = [
  '.nf-page{display:flex;flex-direction:column;gap:12px;padding:4px 0 24px;max-width:760px;}',
  '.nf-page-hint{font-size:12px;line-height:1.6;color:var(--dsw-alias-label-tertiary,#999);}',
  '.nf-card{border:1px solid var(--dsw-alias-border-l1,rgba(127,127,127,.25));border-radius:12px;padding:12px 14px;display:flex;flex-direction:column;gap:8px;background:var(--dsw-alias-surface-l1,transparent);}',
  '.nf-card-head{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}',
  '.nf-card-title{font-size:14px;font-weight:600;color:var(--dsw-alias-label-primary,inherit);flex:1 1 auto;}',
  '.nf-card-desc{font-size:12px;line-height:1.6;color:var(--dsw-alias-label-tertiary,#999);}',
  '.nf-row{display:flex;align-items:center;gap:10px;flex-wrap:wrap;}',
  '.nf-label{font-size:12px;color:var(--dsw-alias-label-secondary,#777);}',
  '.nf-field{display:flex;flex-direction:column;gap:3px;align-items:flex-start;}',
  '.nf-error{font-size:12px;color:var(--dsw-alias-state-error-primary,#d33);}',
  '.nf-warn{font-size:12px;color:var(--dsw-alias-state-warning-primary,#d97706);}',
  '.nf-select{min-width:160px;border:1px solid var(--dsw-alias-border-l1,rgba(127,127,127,.3));border-radius:6px;background:var(--dsw-alias-interactive-bg-hover-solid,transparent);color:var(--dsw-alias-label-primary,inherit);padding:4px 8px;font-size:13px;}',
  '.nf-history{font-size:12px;color:var(--dsw-alias-label-secondary,#777);border-top:1px dashed var(--dsw-alias-border-l1,rgba(127,127,127,.25));padding-top:8px;display:flex;flex-direction:column;gap:4px;}',
  '.nf-history-row{display:flex;align-items:center;gap:8px;line-height:1.5;}',
  '.nf-history-time{color:var(--dsw-alias-label-tertiary,#999);flex:none;font-variant-numeric:tabular-nums;}',
  '.nf-history-body{flex:1 1 auto;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
  // 开关（与 dsh-plugin-vscode-sidebar 的 Switch 同构：原生 checkbox 保语义，track/thumb 令牌着色）
  '.nf-switch{position:relative;display:inline-block;width:34px;height:18px;flex:none;cursor:pointer;}',
  '.nf-switch input{position:absolute;inset:0;opacity:0;margin:0;cursor:pointer;}',
  '.nf-switch .track{position:absolute;inset:0;border-radius:999px;background:var(--dsw-alias-interactive-bg-hover-solid,rgba(127,127,127,.35));transition:background .15s;}',
  '.nf-switch input:checked + .track{background:var(--dsw-alias-state-success-primary,#16a34a);}',
  '.nf-switch .thumb{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;background:#fff;transition:left .15s;}',
  '.nf-switch input:checked ~ .thumb{left:18px;}',
  // 铃铛字形容器：颜色跟随主标签令牌，svg 填满容器
  '.nf-bell{color:var(--dsw-alias-label-primary,inherit);}',
  '.nf-bell svg{display:block;}',
].join('\n')

function injectCss(): void {
  if (typeof document === 'undefined') return
  const id = 'dsh-notifacation-frame/card.css'
  if (document.querySelector(`style[data-plugin-css=${JSON.stringify(id)}]`) !== null) return
  const tag = document.createElement('style')
  tag.dataset.plugin = 'dsh-notifacation-frame'
  tag.dataset.pluginCss = id
  tag.textContent = NF_CSS
  document.head.appendChild(tag)
}

// ── 推送 feed（WebSocket 客户端 + 订阅者集合）─────────────────────────────

type FeedListener = () => void

interface Feed {
  status: string
  lastRecord: NotificationRecord | null
  connect(): void
  dispose(): void
  onNotification(listener: FeedListener): () => void
  onCatalog(listener: FeedListener): () => void
}

const FEED_PATH = '/notification-frame/ws'

function createFeed(): Feed {
  const notificationListeners = new Set<FeedListener>()
  const catalogListeners = new Set<FeedListener>()
  const feed: Feed = {
    status: 'connecting',
    lastRecord: null,
    connect,
    dispose,
    onNotification(listener) {
      notificationListeners.add(listener)
      return () => notificationListeners.delete(listener)
    },
    onCatalog(listener) {
      catalogListeners.add(listener)
      return () => catalogListeners.delete(listener)
    },
  }
  let socket: WebSocket | null = null
  let disposed = false
  let retryTimer: number | null = null
  let retryDelay = 1000

  function connect(): void {
    if (disposed) return
    try {
      const url = new URL(FEED_PATH, window.location.origin)
      url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:'
      socket = new WebSocket(url.toString())
    } catch {
      scheduleRetry()
      return
    }
    socket.onopen = () => {
      feed.status = 'open'
      retryDelay = 1000
      for (const listener of [...catalogListeners]) listener()
    }
    socket.onmessage = (event) => {
      let message: unknown
      try {
        message = JSON.parse(String(event.data))
      } catch {
        return
      }
      if (message === null || typeof message !== 'object') return
      const record = (message as { type?: unknown }).type
      if (record === 'notification') {
        const payload = (message as { record?: NotificationRecord }).record
        if (payload !== null && typeof payload === 'object' && typeof payload.title === 'string') {
          feed.lastRecord = payload
          for (const listener of [...notificationListeners]) listener()
        }
        return
      }
      if (record === 'catalog' || record === 'hello') {
        for (const listener of [...catalogListeners]) listener()
      }
    }
    socket.onclose = () => {
      feed.status = 'closed'
      socket = null
      scheduleRetry()
    }
    socket.onerror = () => {
      // onclose follows; keep status until then.
    }
  }

  function scheduleRetry(): void {
    if (disposed || retryTimer !== null) return
    retryTimer = window.setTimeout(() => {
      retryTimer = null
      if (disposed) return
      feed.status = 'connecting'
      connect()
    }, retryDelay)
    retryDelay = Math.min(retryDelay * 2, 10000)
  }

  function dispose(): void {
    disposed = true
    if (retryTimer !== null) window.clearTimeout(retryTimer)
    retryTimer = null
    if (socket !== null) {
      socket.onclose = null
      socket.close()
      socket = null
    }
    notificationListeners.clear()
    catalogListeners.clear()
  }

  connect()
  return feed
}

// ── 通知横幅（DSH 原生 Toast，逐条队列展示）───────────────────────────────

const TOAST_QUEUE_MAX = 8

function ToastQueue(props: { feed: Feed }) {
  const [queue, setQueue] = useState<NotificationRecord[]>([])
  const [active, setActive] = useState<{ record: NotificationRecord; show: number } | null>(null)
  const [showSeq, setShowSeq] = useState(0)

  useEffect(() => {
    const off = props.feed.onNotification(() => {
      const record = props.feed.lastRecord
      if (record === null) return
      setQueue((current) => [...current, record].slice(-TOAST_QUEUE_MAX))
    })
    return off
  }, [])

  // 泵：空闲且有排队时取出下一条（show 序号保证同文案重发也重放动画）。
  useEffect(() => {
    if (active !== null || queue.length === 0) return
    const record = queue[0] as NotificationRecord
    setQueue((current) => current.slice(1))
    setShowSeq((seq) => {
      setActive({ record, show: seq + 1 })
      return seq + 1
    })
  }, [active, queue])

  // 横幅出现时播放该通知项配置的音效（静音项不带 sound，跳过）。
  useEffect(() => {
    if (active === null || active.record.sound === undefined) return
    playSound(active.record.sound.preset, active.record.sound.url)
  }, [active])

  if (active === null) return null
  const { record, show } = active
  const text = record.body !== undefined && record.body !== ''
    ? `${SEVERITY_LABEL[record.severity]} · ${record.title}\n${record.body}`
    : `${SEVERITY_LABEL[record.severity]} · ${record.title}`
  return h(Toast, {
    key: `${record.id}:${show}`,
    text,
    icon: h(StateDot, { state: SEVERITY_DOT[record.severity] }),
    onDone: () => setActive(null),
  })
}

// ── 开关（原生 checkbox 保语义 + 令牌着色轨道）────────────────────────────

function Switch(props: {
  checked: boolean
  onChange: (next: boolean) => void
  label: string
}) {
  return h(
    'label',
    { className: 'nf-switch', title: props.label },
    h('input', {
      type: 'checkbox',
      checked: props.checked,
      'aria-label': props.label,
      onChange: (event: { currentTarget: { checked: boolean } }) => props.onChange(event.currentTarget.checked),
    }),
    h('span', { className: 'track', 'aria-hidden': 'true' }),
    h('span', { className: 'thumb', 'aria-hidden': 'true' }),
  )
}

// ── 通用配置字段渲染（派生插件配置项 → DSH 控件）─────────────────────────

function FieldInput(props: {
  field: NotifierField
  value: boolean | number | string
  onChange: (next: boolean | number | string) => void
}) {
  const { field, value } = props
  const id = `nf-field-${field.key}`
  const [draft, setDraft] = useState<string>(String(value ?? ''))

  let control: ReactNode
  switch (field.type) {
    case 'boolean':
      control = h(Switch, {
        checked: value === true,
        onChange: props.onChange,
        label: field.label,
      })
      break
    case 'number':
      control = h(Input, {
        id,
        type: 'number',
        min: field.min,
        max: field.max,
        step: 1,
        value: draft,
        placeholder: typeof field.default === 'number' ? String(field.default) : '',
        onChange: (event: { target: { value: string } }) => setDraft(event.target.value),
        onBlur: () => {
          const parsed = Number(draft)
          if (draft !== '' && Number.isFinite(parsed)) props.onChange(parsed)
          else setDraft(String(value ?? ''))
        },
      })
      break
    case 'select':
      control = h(
        'select',
        {
          id,
          className: 'nf-select',
          value: typeof value === 'string' ? value : '',
          onChange: (event: { target: { value: string } }) => props.onChange(event.target.value),
        },
        (field.options ?? []).map((option) => h('option', { key: option.value, value: option.value }, option.label)),
      )
      break
    case 'string':
    default:
      control = h(Input, {
        id,
        type: 'text',
        value: draft,
        placeholder: typeof field.default === 'string' ? field.default : '',
        onChange: (event: { target: { value: string } }) => setDraft(event.target.value),
        onBlur: () => {
          if (draft !== value) props.onChange(draft)
        },
      })
      break
  }
  return h(
    'div',
    { className: 'nf-field' },
    h('label', { className: 'nf-label', htmlFor: id }, field.label),
    control,
    field.description !== undefined ? h('div', { className: 'nf-page-hint' }, field.description) : null,
  )
}

// ── 自定义音效 URL 输入（草稿态 + blur 提交，同 FieldInput 模式）─────────

function SoundUrlInput(props: {
  value: string
  onCommit: (next: string) => void
}) {
  const [draft, setDraft] = useState<string>(props.value)
  return h(Input, {
    type: 'text',
    value: draft,
    placeholder: '音效文件 URL（.mp3 / .wav / .ogg）',
    onChange: (event: { target: { value: string } }) => setDraft(event.target.value),
    onBlur: () => {
      if (draft !== props.value) props.onCommit(draft.trim())
    },
  })
}

// ── 单个通知项的配置卡片 ─────────────────────────────────────────────────

function ItemCard(props: {
  item: NotifierItemView
  onBlob: (blob: Record<string, unknown>) => void
  onTest: () => void
}) {
  const { item } = props
  const config = item.config

  const setBlob = (patch: Record<string, unknown>): void => {
    props.onBlob({
      enabled: patch.enabled ?? config.enabled,
      channels: patch.channels ?? config.channels,
      options: patch.options ?? config.options,
      sound: patch.sound ?? config.sound,
      soundUrl: patch.soundUrl ?? config.soundUrl,
    })
  }

  const toggleChannel = (channel: NotificationChannel): void => {
    const next = config.channels.includes(channel)
      ? config.channels.filter((entry) => entry !== channel)
      : [...config.channels, channel]
    setBlob({ channels: next })
  }

  const setField = (key: string, value: boolean | number | string): void => {
    setBlob({ options: { ...config.options, [key]: value } })
  }

  return h(
    'div',
    { className: 'nf-card' },
    h(
      'div',
      { className: 'nf-card-head' },
      h(StateDot, { state: SEVERITY_DOT[item.severity] }),
      h('div', { className: 'nf-card-title' }, item.title),
      h(Pill, { active: false }, item.source === 'builtin' ? '内置' : '插件'),
      h(Switch, {
        checked: config.enabled,
        onChange: (next) => setBlob({ enabled: next }),
        label: config.enabled ? `停用 ${item.title}` : `启用 ${item.title}`,
      }),
    ),
    h('div', { className: 'nf-card-desc' }, item.description),
    item.setupError !== undefined
      ? h('div', { className: 'nf-warn' }, `激活失败：${item.setupError}`)
      : null,
    h(
      'div',
      { className: 'nf-row' },
      h('span', { className: 'nf-label' }, '通道'),
      ...item.supportedChannels.map((channel) =>
        h(Pill, {
          key: channel,
          active: config.channels.includes(channel),
          onClick: () => toggleChannel(channel),
        }, CHANNEL_LABEL[channel] ?? channel),
      ),
    ),
    h(
      'div',
      { className: 'nf-row' },
      h('span', { className: 'nf-label' }, '音效'),
      h(
        'select',
        {
          className: 'nf-select',
          value: config.sound,
          onChange: (event: { target: { value: string } }) => setBlob({ sound: event.target.value }),
        },
        SOUND_PRESETS.map((preset) =>
          h('option', { key: preset.id, value: preset.id }, preset.label),
        ),
      ),
      config.sound === 'custom'
        ? h(SoundUrlInput, {
            value: config.soundUrl,
            onCommit: (next) => setBlob({ soundUrl: next }),
          })
        : null,
      h(Button, {
        variant: 'ghost',
        size: 'sm',
        onClick: () => playSound(config.sound, config.soundUrl),
      }, '试听'),
    ),
    item.fields.length > 0
      ? h(
          'div',
          { className: 'nf-row', style: { alignItems: 'flex-end' } },
          ...item.fields.map((field) =>
            h(FieldInput, {
              key: field.key,
              field,
              value: config.options[field.key] as boolean | number | string,
              onChange: (next) => setField(field.key, next),
            }),
          ),
        )
      : null,
    h(
      'div',
      { className: 'nf-row' },
      h(Button, { variant: 'outline', size: 'sm', onClick: props.onTest }, '测试'),
    ),
  )
}

// ── “通知”设置页（settings.section）──────────────────────────────────────

interface SettingsPageProps {
  feed: Feed
  openSession?: (id: string) => void
  /** settings 面板 owner 分享（本页不用，保留在类型里对齐运行时契约）。 */
  close?: () => void
}

function SettingsPage(props: SettingsPageProps) {
  const [items, setItems] = useState<NotifierItemView[]>([])
  const [history, setHistory] = useState<NotificationRecord[]>([])
  const [error, setError] = useState<string | null>(null)

  const refresh = (): void => {
    api.catalog().then(
      (result) => {
        setItems(result.items)
        setError(null)
      },
      (cause: unknown) => setError(cause instanceof Error ? cause.message : 'catalog failed'),
    )
  }

  const refreshHistory = (): void => {
    api.history(20).then(
      (result) => setHistory(result.history),
      () => {},
    )
  }

  useEffect(() => {
    refresh()
    refreshHistory()
    const offCatalog = props.feed.onCatalog(() => refresh())
    const offNotification = props.feed.onNotification(() => {
      const record = props.feed.lastRecord
      if (record !== null) {
        setHistory((current) => [record, ...current].slice(0, 20))
      }
    })
    return () => {
      offCatalog()
      offNotification()
    }
  }, [])

  const commit = (item: NotifierItemView, blob: Record<string, unknown>): void => {
    setError(null)
    api.setItem(item.id, blob).then(
      (result) => setItems(result.items),
      (cause: unknown) => setError(cause instanceof Error ? cause.message : 'setItem failed'),
    )
  }

  const feedDot: StateDotState = props.feed.status === 'open'
    ? 'done'
    : props.feed.status === 'connecting'
      ? 'ongoing'
      : 'error'
  const feedLabel = props.feed.status === 'open'
    ? '已连接'
    : props.feed.status === 'connecting'
      ? '连接中…'
      : '断开（自动重连）'

  return h(
    'div',
    { className: 'nf-page' },
    h(
      'div',
      { className: 'nf-row' },
      h(BellIcon, { size: 16, className: 'nf-bell' }),
      h('div', { className: 'nf-card-title' }, '通知'),
    ),
    h(
      'div',
      { className: 'nf-page-hint' },
      '统一管理 dsh 的通知事件：每个通知项可单独开关并选择通道（网页内提示 / 系统通知 / 日志）。修改热生效，无需重启。',
    ),
    h(
      'div',
      { className: 'nf-row' },
      h(StateDot, { state: feedDot }),
      h('span', { className: 'nf-label' }, `推送状态：${feedLabel}`),
    ),
    error !== null ? h('div', { className: 'nf-error' }, error) : null,
    ...items.map((item) =>
      h(ItemCard, {
        key: item.id,
        item,
        onBlob: (blob) => commit(item, blob),
        onTest: () => {
          setError(null)
          api.test(item.id).then(
            () => {},
            (cause: unknown) => setError(cause instanceof Error ? cause.message : 'test failed'),
          )
        },
      }),
    ),
    h(
      'div',
      { className: 'nf-history' },
      h('div', { className: 'nf-row' },
        h('span', { className: 'nf-card-title' }, '最近通知'),
        h(Button, { variant: 'ghost', size: 'sm', onClick: refreshHistory }, '刷新')),
      history.length === 0
        ? h('div', { className: 'nf-page-hint' }, '暂无通知记录。')
        : history.map((record) =>
            h(
              'div',
              { key: record.id, className: 'nf-history-row' },
              h(StateDot, { state: SEVERITY_DOT[record.severity] }),
              h('span', { className: 'nf-history-time' }, new Date(record.at).toLocaleTimeString()),
              h('span', { className: 'nf-history-body', title: record.body }, record.title),
              record.sessionId !== undefined && props.openSession !== undefined
                ? h(Button, {
                    variant: 'ghost',
                    size: 'sm',
                    onClick: () => props.openSession?.(record.sessionId as string),
                  }, '跳转')
                : null,
            ),
          ),
    ),
  )
}

// ── 入口 ──────────────────────────────────────────────────────────────────

export function apply(ctx: PluginCtx): void {
  injectCss()

  // 每激活周期一个 feed（HMR 安全：dispose 时关闭 socket 与定时器）。
  const feed = createFeed()
  ctx.effect(() => () => feed.dispose(), 'dsh-notifacation-frame: feed teardown')

  // ── 设置面板导航图标覆盖 ────────────────────────────────────────────────
  // 与 dsh-plugin-vscode-sidebar 的 "settings-nav icon" effect 同款手法：
  // 设置 shell 的导航字形按 section id 硬编码（未知 id 一律齿轮兜底），
  // 插件无法经槽位系统替换；本 effect 在自己的导航单元格里把齿轮换成
  // 通知铃铛（保留原 class 使 shell 样式继续生效），并用 MutationObserver
  // 在面板重渲染（locale 切换等）后重新修补。仅匹配本分区的标签文本。
  ctx.effect(() => {
    try {
      const NAV_LIST_SELECTOR = '[class*="navList"]'
      const NAV_ICON_SELECTOR = '[class*="navIcon"]'
      const NAV_LABEL_SELECTOR = '[class*="navLabel"]'
      const SECTION_LABEL = '通知'
      const MARKER = 'data-dsh-notifacation-frame-icon'
      const swap = (): void => {
        const list = document.querySelector(NAV_LIST_SELECTOR)
        if (list === null) return
        for (const cell of list.querySelectorAll('button')) {
          const label = cell.querySelector(NAV_LABEL_SELECTOR)
          if (label === null || label.textContent !== SECTION_LABEL) continue
          const icon = cell.querySelector(NAV_ICON_SELECTOR)
          if (icon === null || icon.getAttribute(MARKER) === '1') continue
          const className = icon.getAttribute('class') ?? ''
          icon.outerHTML = bellSvg.replace(
            '<svg ',
            `<svg ${MARKER}="1" class="${className}" `,
          )
        }
      }
      swap()
      const observer = new MutationObserver(swap)
      observer.observe(document.body, { childList: true, subtree: true })
      return () => {
        observer.disconnect()
      }
    } catch (error) {
      console.error('[dsh-notifacation-frame] settings-nav icon:', error)
      return undefined
    }
  }, 'dsh-notifacation-frame: settings-nav icon')

  // 0.1.5：teammate 等子会话走 subagentAddress -> openSubagent；未知/已失效
  // 的会话安全降级为 no-op（见 session-open.ts）。
  const sessions = ctx.get('sessions') as NotificationSessionsFace | undefined
  const openSession = createSessionOpener(sessions, (message, error) => {
    console.warn(`[dsh-notifacation-frame] ${message}:`, error)
  })

  // 通知横幅（DSH 原生 Toast 的持有者；本槽位组件只负责队列，横幅自身 portal 到顶层）。
  ctx.slots.inject('shell.overlay', () =>
    ctx.slots.register(
      { name: 'shell.overlay', id: 'dsh-notifacation-frame', order: 900 },
      () => h(ToastQueue, { feed }),
    ),
  )

  // Settings → 通知 页（注册方式对齐 dsh-plugin-vscode-sidebar 的
  // SideCardSection：label 用 thunk，业务面经 inject 注入）。
  ctx.slots.inject('settings.section', () =>
    ctx.slots.register(
      {
        name: 'settings.section',
        id: 'notifacation-frame',
        order: 90,
        label: () => '通知',
        inject: () => ({ feed, openSession }),
      },
      SettingsPage,
    ),
  )
}
