/** 资源导入声明（与 dsh-pref-kit 的 src/client/vendor.d.ts 同职责）。 */
declare module '*.svg?raw' {
  const content: string
  export default content
}
