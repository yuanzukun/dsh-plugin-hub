/**
 * dsh-notifacation-frame · 本地供应商化的 DSH 原子控件。
 *
 * 0.1.5 的平台基线仍提供 @deepseek-ai/dsh-client-ui-primitives；本插件
 * 选择把用到的五个原子内联进自己的客户端 bundle（Button / Input / Pill /
 * StateDot / Toast），保持自足并避免跨 rc 版本的 prop 面漂移。
 *
 * API 形状与旧 primitives 的 .d.ts 契约一致，样式只经 --dsw-alias-* /
 * --dsw-static-* 主题令牌（与新版 dsh 主题同源），保证视觉与 dsh 一致。
 */
import { createElement as h, useEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react'
import { createPortal } from 'react-dom'

// ── Button ────────────────────────────────────────────────────────────────

export type ButtonVariant = 'primary' | 'ghost' | 'outline' | 'toolbar'

const BUTTON_BASE: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 4,
  border: 'none',
  borderRadius: 999,
  cursor: 'pointer',
  fontFamily: 'inherit',
  whiteSpace: 'nowrap',
  flex: 'none',
}

const BUTTON_VARIANT: Record<ButtonVariant, CSSProperties> = {
  primary: {
    background: 'var(--dsw-alias-button-primary-fill, var(--dsw-alias-brand-primary, #2b6cb0))',
    color: 'var(--dsw-alias-label-primary-foreground, #fff)',
  },
  ghost: {
    background: 'transparent',
    color: 'var(--dsw-alias-label-primary, inherit)',
  },
  outline: {
    background: 'transparent',
    border: '1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.3))',
    color: 'var(--dsw-alias-label-primary, inherit)',
  },
  toolbar: {
    background: 'var(--dsw-alias-button-tool-bar-fill, rgba(84,85,87,.5))',
    color: 'var(--dsw-alias-label-primary, inherit)',
  },
}

const BUTTON_HOVER: Record<ButtonVariant, CSSProperties> = {
  primary: { background: 'var(--dsw-alias-button-primary-hover, #1d2a4d)' },
  ghost: { background: 'var(--dsw-alias-interactive-bg-hover, rgba(38,49,72,.06))' },
  outline: { background: 'var(--dsw-alias-interactive-bg-hover, rgba(38,49,72,.06))' },
  toolbar: { background: 'var(--dsw-alias-button-tool-bar-hover, rgba(84,85,87,.6))' },
}

export function Button(props: {
  variant?: ButtonVariant
  size?: 'md' | 'sm'
  icon?: ReactNode
  className?: string
  children?: ReactNode
} & Record<string, unknown>): ReactNode {
  const { variant = 'ghost', size = 'md', icon, className, children, ...rest } = props
  const [hovered, setHovered] = useState(false)
  const style: CSSProperties = {
    ...BUTTON_BASE,
    ...BUTTON_VARIANT[variant],
    ...(hovered ? BUTTON_HOVER[variant] : {}),
    ...(size === 'sm'
      ? { height: 28, padding: '0 12px', fontSize: 12, lineHeight: '20px' }
      : { height: 36, padding: '0 16px', fontSize: 13, lineHeight: '24px' }),
  }
  return h('button', {
    type: 'button',
    className,
    style,
    onMouseEnter: () => setHovered(true),
    onMouseLeave: () => setHovered(false),
    ...rest,
  },
    icon,
    children,
  )
}

// ── Input ─────────────────────────────────────────────────────────────────

export function Input(props: {
  icon?: ReactNode
  className?: string
} & Record<string, unknown>): ReactNode {
  const { icon, className, ...rest } = props
  return h(
    'span',
    {
      className,
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        border: '1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.3))',
        borderRadius: 6,
        padding: '4px 8px',
        background: 'var(--dsw-alias-bg-module, transparent)',
        color: 'var(--dsw-alias-label-primary, inherit)',
      },
    },
    icon,
    h('input', {
      ...rest,
      style: {
        border: 'none',
        outline: 'none',
        background: 'transparent',
        color: 'inherit',
        fontFamily: 'inherit',
        fontSize: 13,
        width: '100%',
        minWidth: 0,
      },
    }),
  )
}

// ── Pill ──────────────────────────────────────────────────────────────────

export function Pill(props: {
  active?: boolean
  className?: string
  children?: ReactNode
} & Record<string, unknown>): ReactNode {
  const { active = false, className, children, ...rest } = props
  const style: CSSProperties = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 4,
    padding: '3px 10px',
    borderRadius: 999,
    fontSize: 12,
    lineHeight: '16px',
    cursor: 'pointer',
    fontFamily: 'inherit',
    border: `1px solid ${active
      ? 'var(--dsw-alias-button-ghost-active-border, rgba(38,49,72,.5))'
      : 'var(--dsw-alias-border-l1, rgba(127,127,127,.3))'}`,
    background: active
      ? 'var(--dsw-alias-button-ghost-active-fill, rgba(38,49,72,.12))'
      : 'transparent',
    color: 'var(--dsw-alias-label-primary, inherit)',
  }
  return h('button', { type: 'button', className, style, ...rest }, children)
}

// ── StateDot ──────────────────────────────────────────────────────────────

export type StateDotState = 'done' | 'warning' | 'ongoing' | 'error'

const STATE_DOT_COLOR: Record<StateDotState, string> = {
  done: 'var(--dsw-alias-state-success-primary, #16a34a)',
  warning: 'var(--dsw-alias-state-warning-primary, #d97706)',
  ongoing: 'var(--dsw-static-deepseek-500, #4176e6)',
  error: 'var(--dsw-alias-state-error-primary, #dc2626)',
}

export function StateDot(props: { state: StateDotState; size?: number; className?: string }): ReactNode {
  const size = props.size ?? 10
  const color = STATE_DOT_COLOR[props.state]
  const ring = props.state === 'ongoing'
  return h('span', {
    className: props.className,
    'aria-hidden': 'true',
    style: {
      display: 'inline-block',
      width: size,
      height: size,
      borderRadius: '50%',
      flex: 'none',
      boxSizing: 'border-box',
      background: ring ? 'transparent' : color,
      border: ring ? `2px solid ${color}` : 'none',
    },
  })
}

// ── Toast（顶部居中瞬时横幅）──────────────────────────────────────────────

export function Toast(props: {
  text: string
  icon?: ReactNode
  anchor?: HTMLElement | null
  onDone: () => void
}): ReactNode {
  const { text, icon, anchor, onDone } = props
  const doneRef = useRef(false)
  const [phase, setPhase] = useState<'in' | 'hold' | 'out'>('in')
  const [left, setLeft] = useState<number | undefined>(undefined)

  // 进入动画（强制回流后挂 'hold'），保持 3s，1s 淡出，然后 onDone。
  useEffect(() => {
    const raf = requestAnimationFrame(() => {
      setPhase('hold')
    })
    const holdTimer = window.setTimeout(() => setPhase('out'), 3000)
    const doneTimer = window.setTimeout(() => {
      if (!doneRef.current) {
        doneRef.current = true
        onDone()
      }
    }, 4100)
    return () => {
      cancelAnimationFrame(raf)
      window.clearTimeout(holdTimer)
      window.clearTimeout(doneTimer)
    }
  }, [])

  // 锚定元素水平居中（窗口尺寸变化时重测）。
  useEffect(() => {
    const measure = (): void => {
      if (anchor === null || anchor === undefined) {
        setLeft(undefined)
        return
      }
      const rect = anchor.getBoundingClientRect()
      setLeft(rect.left + rect.width / 2)
    }
    measure()
    window.addEventListener('resize', measure)
    return () => window.removeEventListener('resize', measure)
  }, [anchor])

  const banner = h(
    'div',
    {
      role: 'alert',
      style: {
        position: 'fixed',
        top: 120,
        left: left === undefined ? '50%' : left,
        transform: 'translateX(-50%) translateY(0)',
        zIndex: 2147483100,
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        maxWidth: 'calc(100vw - 48px)',
        padding: '10px 18px',
        borderRadius: 999,
        background: 'var(--dsw-alias-bg-overlay, rgba(28,28,35,.95))',
        color: 'var(--dsw-alias-label-primary-inverted, #fff)',
        fontSize: 13,
        lineHeight: '18px',
        whiteSpace: 'pre-line',
        boxShadow: '0 8px 24px rgba(0,0,0,.28)',
        pointerEvents: 'none',
        opacity: phase === 'out' ? 0 : 1,
        transition: phase === 'out'
          ? 'opacity 1s ease'
          : phase === 'in'
            ? 'transform .18s ease, opacity .18s ease'
            : 'none',
        ...(phase === 'in' ? { transform: 'translateX(-50%) translateY(-8px)' } : {}),
      },
    },
    icon,
    text,
  )
  return createPortal(banner, document.body)
}
