/**
 * dsh-notifacation-frame · 通知跳转会话的安全打开器。
 *
 * DSH 0.1.5 起 `ctx.sessions.open(id)` 只接受列表内或已保留的 catalog
 * 地址；Agent Teams 的 teammate/子代理通常是“已寻址子会话”，直接 open
 * 未知 child id 会 fail loud。这里优先走 0.1.5 新增的目录路径
 * （subagentAddress(id) -> openSubagent(address)），否则退回 open()，
 * 并把所有失败降级为 no-op + 诊断日志，保证通知历史里的“跳转”按钮
 * 永远不会因死链而抛异常。
 */

/** sessions 服务的最小结构面（旧版本可能只有 open）。 */
export interface NotificationSessionsFace {
  open?(id: string): void
  openSubagent?(address: unknown): void
  subagentAddress?(id: string): unknown
}

/**
 * 构造通知点击的会话打开器。
 * @param sessions - 运行时 `ctx.get('sessions')`；缺位时返回 undefined。
 * @param onError - 诊断回调（默认丢弃），只接收降级原因。
 * @returns 打开器；服务不提供任何导航能力时为 undefined。
 */
export function createSessionOpener(
  sessions: NotificationSessionsFace | undefined,
  onError: (message: string, error: unknown) => void = () => {},
): ((id: string) => void) | undefined {
  if (sessions === undefined) return undefined
  const canOpenChild = typeof sessions.subagentAddress === 'function'
    && typeof sessions.openSubagent === 'function'
  if (typeof sessions.open !== 'function' && !canOpenChild) return undefined
  return (id: string): void => {
    if (canOpenChild) {
      try {
        const address = sessions.subagentAddress?.(id)
        if (address !== undefined) {
          sessions.openSubagent?.(address)
          return
        }
      } catch (error) {
        onError('subagent address lookup failed', error)
      }
    }
    try {
      sessions.open?.(id)
    } catch (error) {
      // open() fail loud on unknown ids: a stale/teammate notification link
      // degrades to a no-op instead of an unhandled click-handler error.
      onError('session open failed', error)
    }
  }
}
