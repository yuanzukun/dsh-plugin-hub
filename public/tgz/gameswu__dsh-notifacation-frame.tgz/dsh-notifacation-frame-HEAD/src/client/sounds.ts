/**
 * dsh-notifacation-frame · 客户端音效合成（零资源文件）。
 *
 * 内置音效预设全部用 Web Audio API 实时合成——短促、无文件、无加载：
 * - ding   双音提示（E5→G5 正弦，柔和）
 * - pop    短促提示（A5 单音，0.15s）
 * - chime  三音上行钟声（C5-E5-G5）
 * - alert  双短警告（880Hz 方波 ×2）
 * - custom 播放自定义 URL 音频（HTMLAudioElement）
 *
 * 浏览器自动播放策略：AudioContext 首次使用可能在用户手势前处于
 * suspended，每次播放前尝试 resume()，失败则静默跳过（通知音效是
 * 尽力而为的增强，绝不因它抛错）。
 */

/** 一次振荡器发声（带指数衰减包络）。 */
function tone(
  ctx: AudioContext,
  freq: number,
  start: number,
  duration: number,
  type: OscillatorType = 'sine',
  gain = 0.18,
): void {
  const osc = ctx.createOscillator()
  const envelope = ctx.createGain()
  osc.type = type
  osc.frequency.setValueAtTime(freq, start)
  envelope.gain.setValueAtTime(0, start)
  envelope.gain.linearRampToValueAtTime(gain, start + 0.012)
  envelope.gain.exponentialRampToValueAtTime(0.0001, start + duration)
  osc.connect(envelope)
  envelope.connect(ctx.destination)
  osc.start(start)
  osc.stop(start + duration + 0.06)
}

let audioContext: AudioContext | null = null

/** 惰性创建 + 恢复被自动播放策略挂起的 AudioContext。 */
function context(): AudioContext | null {
  try {
    if (audioContext === null) {
      audioContext = new AudioContext()
    }
    if (audioContext.state === 'suspended') {
      void audioContext.resume().catch(() => {})
    }
    return audioContext
  } catch {
    return null
  }
}

/** 播放一个内置预设（同步合成；失败静默）。 */
function playPreset(preset: string): void {
  const ctx = context()
  if (ctx === null) return
  const t = ctx.currentTime
  switch (preset) {
    case 'ding':
      tone(ctx, 659.25, t, 0.35)
      tone(ctx, 783.99, t + 0.12, 0.4)
      break
    case 'pop':
      tone(ctx, 880, t, 0.15, 'sine', 0.16)
      break
    case 'chime':
      tone(ctx, 523.25, t, 0.3)
      tone(ctx, 659.25, t + 0.12, 0.3)
      tone(ctx, 783.99, t + 0.24, 0.45)
      break
    case 'alert':
      tone(ctx, 880, t, 0.12, 'square', 0.09)
      tone(ctx, 880, t + 0.18, 0.12, 'square', 0.09)
      break
    default:
      break
  }
}

/**
 * 播放一个通知项的音效。
 * @param preset - 内置预设 id；'custom' 时播放 url。
 * @param url - 自定义音频 URL（仅 preset === 'custom' 时使用）。
 */
export function playSound(preset: string, url?: string): void {
  try {
    if (preset === 'custom') {
      if (url === undefined || url === '') return
      const audio = new Audio(url)
      void audio.play().catch(() => {})
      return
    }
    playPreset(preset)
  } catch {
    // 音效失败静默：通知本身不受影响。
  }
}
