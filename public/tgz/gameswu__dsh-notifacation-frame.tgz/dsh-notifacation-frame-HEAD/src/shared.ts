/**
 * dsh-notifacation-frame · 共享线缆模型（同构：host 与 client 共用的纯类型与纯函数，
 * 不 import 任何 node 或运行时模块，保证浏览器 bundle 可以直接内联）。
 *
 * 派生插件（derived plugin）通过 `NotifierDefinition` 描述一个通知项：
 * 它的 `fields` 就是该插件自己的配置项。框架在注册时把这些字段解析成
 * 默认配置，用户设置文档里的 blob 与默认配置合并后，再交给 `setup(env)`
 * ——`env.config` 就是解析、校验、补默认之后的派生配置。解析规则见
 * {@link parseOptions}。
 */

/** 通知严重级别。 */
export type NotificationSeverity = 'info' | 'success' | 'warning' | 'error'

/** 通知通道：web = 浏览器页内 toast；system = 操作系统通知；log = 宿主日志。 */
export type NotificationChannel = 'web' | 'system' | 'log'

/** 全部通道（配置校验用的白名单）。 */
export const ALL_CHANNELS: readonly NotificationChannel[] = ['web', 'system', 'log']

/**
 * 内置音效预设（客户端 Web Audio 合成，无资源文件）：
 * none = 静音（默认），ding/pop/chime/alert = 简短合成提示音。
 * custom = 自定义音频文件 URL（soundUrl）。
 */
export interface SoundPreset {
  id: string
  label: string
}

export const SOUND_PRESETS: readonly SoundPreset[] = [
  { id: 'none', label: '静音' },
  { id: 'ding', label: '叮（双音提示）' },
  { id: 'pop', label: '啵（短促提示）' },
  { id: 'chime', label: '钟声（三音上行）' },
  { id: 'alert', label: '警报（双短警告）' },
  { id: 'custom', label: '自定义 URL' },
]

/** 判断一个原始值是否为合法音效预设 id。 */
export function isSoundPreset(value: unknown): value is string {
  return typeof value === 'string' && SOUND_PRESETS.some((preset) => preset.id === value)
}

/** 一条已经确定要投递的通知记录（纯 JSON，可跨进程/跨线缆）。 */
export interface NotificationRecord {
  /** 通知实例 id（框架生成）。 */
  id: string
  /** 来源通知项 id（notifier id）。 */
  itemId: string
  severity: NotificationSeverity
  title: string
  body?: string
  /** 相关会话 id（存在时客户端 toast 可以点击跳转会话）。 */
  sessionId?: string
  /** 纪元毫秒。 */
  at: number
  /** 附加的标量元数据（如工具名、退出码）。 */
  meta?: Record<string, unknown>
  /** 生效音效（静音时不携带）。 */
  sound?: {
    preset: string
    url?: string
  }
}

/**
 * 派生插件声明的一个配置项。客户端设置卡片完全由该元数据驱动渲染：
 * boolean → 开关，number → 数字输入（min/max），string → 文本输入，
 * select → 下拉框。宿主侧据此生成 schemastery schema 做运行时校验。
 */
export interface NotifierField {
  key: string
  /** 卡片上显示的字段名。 */
  label: string
  description?: string
  type: 'boolean' | 'number' | 'string' | 'select'
  default?: boolean | number | string
  min?: number
  max?: number
  options?: Array<{ value: string; label: string }>
}

/** 通知项收到的环境：把通知投递给框架 + 解析后的配置 + cordis 上下文。 */
export interface NotifierEnv {
  /** 投递一条通知（框架按该项的通道配置分发）。 */
  notify(payload: {
    title: string
    body?: string
    severity?: NotificationSeverity
    sessionId?: string
    meta?: Record<string, unknown>
  }): void
  /** 解析、校验、补默认之后的派生配置项（对应 definition.fields）。 */
  config: Record<string, unknown>
  /** 当前 cordis 上下文（派生插件用它注册 ctx.on 等）。 */
  ctx: unknown
}

/** 一个通知项定义（内置通知与派生插件的注册入口相同）。 */
export interface NotifierDefinition {
  /** 全局唯一 id（设置文档以它为 key）。 */
  id: string
  title: string
  description: string
  severity: NotificationSeverity
  /** 该项允许使用的通道（卡片只展示这些复选项）。 */
  channels: NotificationChannel[]
  /** 未配置时默认开启的通道。 */
  defaultChannels: NotificationChannel[]
  /** 未配置时该项默认是否启用（缺省 true；内置的 tool-error 等默认关闭）。 */
  defaultEnabled?: boolean
  /** 未配置时该项的默认音效预设（缺省 'none' 静音；非法值回落静音）。 */
  defaultSound?: string
  /** 派生插件的配置项元数据（驱动设置卡片与校验）。 */
  fields?: NotifierField[]
  /**
   * 激活回调：框架在注册后以及用户修改该项配置后调用（先 dispose 旧
   * setup，再执行新 setup）。返回值可选 disposer。派生插件在 setup 里
   * 注册事件监听并调用 env.notify。
   */
  setup(env: NotifierEnv): void | (() => void)
}

/** 设置文档里每个通知项的存储 blob。 */
export interface NotifierConfigBlob {
  enabled?: boolean
  channels?: NotificationChannel[]
  /** 派生插件自己的配置项（原始 JSON 值，注册时经 parseOptions 解析）。 */
  options?: Record<string, unknown>
  /** 音效预设 id（内置 + 'custom'；缺省 'none'）。 */
  sound?: string
  /** 自定义音效 URL（仅 sound === 'custom' 时生效）。 */
  soundUrl?: string
}

/** 设置卡片渲染用的通知项视图（目录 + 当前生效配置）。 */
export interface NotifierItemView {
  id: string
  title: string
  description: string
  severity: NotificationSeverity
  supportedChannels: NotificationChannel[]
  defaultChannels: NotificationChannel[]
  fields: NotifierField[]
  /** 'builtin' = 框架内置；'plugin' = 派生插件注册。 */
  source: 'builtin' | 'plugin'
  /** setup 最近一次激活失败的错误信息（卡片显示为警告）。 */
  setupError?: string
  /** 当前生效配置（enabled / channels / options / sound 解析后的值）。 */
  config: {
    enabled: boolean
    channels: NotificationChannel[]
    options: Record<string, unknown>
    /** 生效音效预设 id。 */
    sound: string
    /** 自定义音效 URL（sound !== 'custom' 时恒为空串）。 */
    soundUrl: string
  }
}

/** 派生插件通过 cordis 服务拿到的框架服务面。 */
export interface NotificationFrameService {
  /** 注册（或覆盖）一个通知项；返回 disposer。 */
  register(def: NotifierDefinition): () => void
  /** 列出当前全部通知项及其生效配置。 */
  list(): NotifierItemView[]
  /** 直接投递一条通知（旁路通知项开关，测试/外部派生插件用）。 */
  dispatch(payload: {
    itemId: string
    title: string
    body?: string
    severity?: NotificationSeverity
    sessionId?: string
    meta?: Record<string, unknown>
  }): void
  /** 读取最近的通知历史（仅内存环形缓冲）。 */
  history(limit?: number): NotificationRecord[]
  /** 更新一个通知项的用户配置并热生效。 */
  updateItem(id: string, blob: NotifierConfigBlob): Promise<void>
  /** 通过某项的完整管线发送一条测试通知。 */
  test(id: string): void
}

/** WebSocket 推送帧（host → client）。 */
export type FeedMessage =
  | { type: 'notification'; record: NotificationRecord }
  | { type: 'catalog' }
  | { type: 'hello'; items: NotifierItemView[]; history: NotificationRecord[] }

function isObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

/** 把一个字段的原始值解析为合法值（默认值兜底 + 范围钳制 + 枚举白名单）。 */
export function coerceField(field: NotifierField, raw: unknown): boolean | number | string {
  switch (field.type) {
    case 'boolean': {
      if (typeof raw === 'boolean') return raw
      return typeof field.default === 'boolean' ? field.default : false
    }
    case 'number': {
      let value = typeof raw === 'number' && Number.isFinite(raw)
        ? raw
        : typeof field.default === 'number'
          ? field.default
          : 0
      if (typeof field.min === 'number') value = Math.max(field.min, value)
      if (typeof field.max === 'number') value = Math.min(field.max, value)
      return value
    }
    case 'string': {
      if (typeof raw === 'string') return raw
      return typeof field.default === 'string' ? field.default : ''
    }
    case 'select': {
      const options = field.options ?? []
      if (typeof raw === 'string' && options.some((option) => option.value === raw)) return raw
      return options[0]?.value ?? (typeof field.default === 'string' ? field.default : '')
    }
    default:
      return typeof field.default === 'string' ? field.default : ''
  }
}

/**
 * 解析派生插件的配置项（框架的对外契约之一）：
 * 对 definition.fields 逐字段执行类型校验 + 默认值 + 范围钳制 + 枚举白名单，
 * 输出一个纯标量对象交给 setup(env)。派生插件在 setup 里拿到的一定是
 * 合法值（哪怕设置文档里是垃圾数据或用户手工改了文件）。
 */
export function parseOptions(def: NotifierDefinition, raw: unknown): Record<string, unknown> {
  const source = isObject(raw) ? raw : {}
  const out: Record<string, unknown> = {}
  for (const field of def.fields ?? []) {
    out[field.key] = coerceField(field, source[field.key])
  }
  return out
}

/** 校验并规范化通道列表（白名单 + 去重，空数组 = 全部关闭）。 */
export function normalizeChannels(raw: unknown, fallback: readonly NotificationChannel[]): NotificationChannel[] {
  if (!Array.isArray(raw)) return [...fallback]
  const seen = new Set<NotificationChannel>()
  for (const entry of raw) {
    if (typeof entry === 'string' && (ALL_CHANNELS as readonly string[]).includes(entry)) {
      seen.add(entry as NotificationChannel)
    }
  }
  return [...seen]
}

/** 把设置文档里的 blob 规范化成通知项视图的生效配置。 */
export function resolveBlob(def: NotifierDefinition, blob: unknown): NotifierItemView['config'] {
  const record = isObject(blob) ? blob : {}
  const fallbackSound = isSoundPreset(def.defaultSound) ? def.defaultSound : 'none'
  const sound = isSoundPreset(record.sound) ? record.sound : fallbackSound
  const soundUrl = sound === 'custom' && typeof record.soundUrl === 'string' ? record.soundUrl : ''
  return {
    enabled: typeof record.enabled === 'boolean' ? record.enabled : (def.defaultEnabled ?? true),
    channels: normalizeChannels(record.channels, def.defaultChannels),
    options: parseOptions(def, record.options),
    sound,
    soundUrl,
  }
}

/** 生成一条通知记录（时间戳与 id 由框架生成）。 */
export function makeRecord(payload: {
  itemId: string
  severity: NotificationSeverity
  title: string
  body?: string
  sessionId?: string
  meta?: Record<string, unknown>
  sound?: { preset: string; url?: string }
}): NotificationRecord {
  const sound = payload.sound !== undefined && isSoundPreset(payload.sound.preset) && payload.sound.preset !== 'none'
    ? {
        preset: payload.sound.preset,
        url: payload.sound.preset === 'custom' && typeof payload.sound.url === 'string' && payload.sound.url !== ''
          ? payload.sound.url
          : undefined,
      }
    : undefined
  return {
    id: `nf-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    itemId: payload.itemId,
    severity: payload.severity,
    title: payload.title,
    body: payload.body,
    sessionId: payload.sessionId,
    at: Date.now(),
    meta: payload.meta,
    sound,
  }
}
