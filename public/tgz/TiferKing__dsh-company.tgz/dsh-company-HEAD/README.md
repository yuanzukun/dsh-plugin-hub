# dsh-company 插件公司

**不想当牛马了？来当老板！开插件公司，雇AI牛马，过赛博人生！**


> 面向 [DeepSeek Harness](https://github.com/deepseek-ai)（DSH）的决策驱动 AI 软件公司编排插件 —— HR 治理、货币预算、工作 DAG、工单、审批与完整 Web 控制台。

`dsh-company` 把当前根会话变成**创始人（Founder）**，把持久 continuable 子代理变成**员工**，用一家真正的公司来组织软件开发：分阶段成立方案 + 人类审批、HR 先行的招聘治理、多级组织树、以货币计价的单一权威账本、三档费率模型价格矩阵、带尝试栅栏的依赖 DAG 工作项、人类工单、类型化审批，以及可崩溃恢复的有界滚动审计。

目标宿主：`@deepseek-ai/dsh@0.1.1-rc.2`（精确测试版本）；当前插件版本 `0.17.3`。

[English documentation](README.en.md) · [架构：核心逻辑与工作模式](docs/architecture.md)

---

## 为什么需要它

让 AI 帮你干活很容易，让 AI **替你经营一家研发团队**却很难。当你对一段对话说"把这个产品做出来"，通常会遇到这些痛点：

**委托会退化。** 你想要的是一个统筹全局的决策者，得到的却是一个埋头写码的执行者——CEO 亲自下场修 bug，没人做规划、没人盯进度、没人对结果负责。

**组织会失控。** 代理为了"高效"随手拉起新的帮手：身份不明、不在编制里、不受你约束。事后你甚至说不清这个项目里到底有谁、谁干了什么。

**成本是笔糊涂账。** 模型调用在暗处计费，你不知道这个功能烧了多少钱、哪个环节最贵、预算还剩多少——等发现超支时为时已晚。

**决策没有凭据。** "当时为什么这么做？"没有人能回答。代理换了上下文就忘了承诺，关键变更（预算、发布、人事）既没有审批记录，也没有你的明确背书。

**质量无人把关。** 谁验证过这个实现？谁评审的？能不能发布？没有验收标准和独立审查，"完成了"只是代理的一面之词。

dsh-company 用一家**真正的公司**来回答这些问题：你出决策，公司出执行——有编制、有账本、有审批、有审计。它把"管理一个 AI 团队"变成"经营一家看得见、管得住、算得清的公司"。

## 特性亮点

- **决策先行** —— AI 起草名称/标语/使命/章程/首款产品/公司预算/独立 HR 上限/价格；人类编辑并明确批准后才启动。成立批准只配额一名 HR 负责人。
- **HR 治理** —— 招聘/调整由 HR 评估难度、provider/model、推理强度、员工预算、组织路径与岗位；退休只需难度和理由，当前人员事实由 Host 推导。所有变更再经过人类批准的 `organization_change`。
- **章程即结构化数据** —— 宿主把章程文本解析为条款树（`company.charter_outline`）；Web 端零解析直接渲染为可展开树。
- **招聘页** —— 逐模型启用开关（默认关 = 未启用）把住招聘入口：HR 只能推荐已启用（三档定价完整）的路线。内置 OpenAI / DeepSeek / 智谱 BigModel 常见模型官方价目预设（按公司币种匹配 USD/CNY），打开开关自动预填——预设绝不自动启用任何路线。
- **工单** —— 人类从 Web 控制台提交产品问题工单；创始人（或派驻支持工程师）分级、派发；关联修复工作完成即自动 resolved；关闭时回复人类。
- **单一货币账本** —— 整数微货币是唯一权威；员工执行与 Founder 管理调用都进入同一 usage ledger，Token 统计由此推导。历史 activation-credit/Token 镜像账本已迁出当前 schema。BigInt 汇总只做一次半向上舍入，reasoning 不重复计费；未定价的 Founder 调用记作未知成本而不阻断人机对话。
- **按资源调度** —— 新公司默认不设员工编制上限；自适应执行从 8 个启动名额开始，根据内存、事件循环、写入积压与服务退避调整。工作、HR、邮件和入职共用准入，等待不消耗投递重试。
- **可恢复事务与审计** —— WAL 协调状态、用量、审计和邮箱；用量与完整审计独立追加，`events.jsonl` 保留有界展示窗口。原有公司格式在下一次成功写入时迁移。
- **Web 控制台** —— 回环同源页面即命名会话的参与者；写请求有 Origin、revision 与精确 live-Agent 栅栏，远程客户端严格只读。临时授权的 Web 确认只会创建审批，批准后才原子生效。
- **冷恢复纪律** —— 员工是持久 continuable 会话；宿主重启后恢复 provisioning、staffing、handoff 与同一 work attempt。历史记账先一次性去重再逐 Session 串行补偿，不为每条旧事件并发读取公司状态；每个 attempt 最多投递三次。
- **HR 可继任** —— HR 推荐可显式指定 `designate_as_hr`；新员工成功启动后才转移 singleton HR 权限，旧 HR 随后可正常退休。

## 安装

运行已打包插件要求 Node `^22.19.0 || >=24`；从源码构建因 `tsdown` 要求 Node `>=24.11`。另需 pnpm 与 DSH rc.2 宿主。

```bash
git clone https://github.com/TiferKing/dsh-company.git
cd dsh-company
pnpm install
pnpm verify        # typecheck + test + build + package:check
npm pack --ignore-scripts  # 复用已验证 build，产出 dsh-company-<version>.tgz

dsh plugin --profile web add /absolute/path/to/dsh-company-<version>.tgz
```

重启原有 DSH Web 进程并刷新原 URL——不要另起替代服务器。

## 快速上手

   一个可以直接粘贴的完整样例：

   > 成立一个公司，并且我任命你为公司的CEO，公司的使命是"将知识惠及全球"，公司第一款产品是"以AI为基础的生成式学习平台"，请成立公司并运营，定期汇报产品进度和竞争力，公司总预算300 CNY，其中用于产品的预算为250 CNY，初始 HR 支出上限为10 CNY。成立产品、研发、测试三个部门，并配备相应人员，先进行产品定义，产品经理岗位不要吝啬预算，我要最好的产品定义，在产品定义结束后再根据产品功能招聘相应的架构师、研发和测试。

公司、产品、员工额度共同约束实际消费，设置额度本身不扣款。HR 上限需要明确提出并审阅，示例中的 10 CNY 不是默认值；收费模型还需通过启动准入检查。`company_bootstrap` 必填 `hr_budget`，修改公司总额不会自动改变 HR 上限。成立后可在审计页或通过 `company_request_budget_change` 的 `employee_budgets` 申请调整 HR 及其他员工额度，经人类批准生效。

也可以在成立请求中直接指定：“初始 HR 使用 `provider-id` 的 `model-id`，推理强度使用模型默认值。”将占位符替换为宿主实际配置的 provider/model；HR 可以和 Founder 使用不同模型。对应的 `company_bootstrap` 参数片段如下，需与其余成立字段一起提交：

```json
{
  "hr_provider": "provider-id",
  "hr_model": "model-id",
  "hr_reasoning_effort": "default",
  "hr_budget": 10
}
```

省略 provider/model 时，初始 HR 继承创建时的 Founder 路线并固定保存。批准前可在概览中选择模型目录里的路线或手填；工具编辑路线需同时提供 `hr_provider` 和 `hr_model`。切换模型会在表单中重置推理强度，HR 预算保持原值；选择模型不会自动定价或启用，收费启动仍需完整价格、上下文信息及足够预算。

1. **要一家公司** —— 在一个工作区为产品仓库的 DSH 会话里，明确要求 agent 成立一家有具体使命的公司。它通过 `company_bootstrap` 起草完整方案（staged 状态，什么都不会启动）。

2. **审阅并批准** —— 打开 Web 控制台（会话头的公司按钮）。在概览表单编辑方案（或让 agent 执行 `company_edit_formation`），然后批准。只有 HR 负责人会被配额。
3. **在招聘页启用模型** —— 打开允许 HR 推荐的路线开关；预设价格自动预填；提交审批。
4. **通过 HR 招聘** —— `company_request_staffing` → HR 认领并提交评估 → 你批准 `organization_change` → 创始人应用招聘。
5. **规划工作、提工单** —— 工作项组成带验收条件的依赖 DAG；产品反馈进入工单页，由决策派发为修复工作。
6. **盯紧钱** —— 审计页展示预算、预留与分路线全生命周期成本；每次变更都进审计账本。

## 人数与执行规模

插件配置中的 `maxEmployees` 接受正安全整数或 `unlimited`，默认 `unlimited`，不再有 32 人硬上限。HR、暂停和失败员工占编制；退休员工不占。已保存公司的有限上限继续有效：在概览的治理编辑中申请更改员工上限，或让 Founder 调用 `company_request_governance_change`，传入 `max_employees: "unlimited"`，经人类批准后生效。若安装 profile 仍显式配置有限 `maxEmployees`，它仍是额外上限，需要同时调整。

| 配置 | 行为 |
| --- | --- |
| `executionMode: adaptive`（默认） | `maxConcurrentEmployees: 8` 是初始执行目标，资源宽裕时逐步增加，压力大时减少新启动 |
| `executionMode: fixed` | `maxConcurrentEmployees` 是同一插件宿主内共享的执行名额上限，同时保留资源压力检查 |
| `executionMode: unlimited` | 关闭数值名额及内存、延迟、写入压力准入；仍遵守每员工单轮执行、供应商退避和业务规则 |

默认压力阈值为内存比率 `0.8`、事件循环延迟 `200ms`、持久化及记账待处理量 `32`，资源等待每 `1000ms` 重试。员工、组织和岗位目录默认每页 50 条、最多 100 条，汇总覆盖完整公司。`maxOpenWorkItems` 默认 32，继续单独约束已认领/执行中的普通工作，不是员工编制或统一执行名额。

不设编制上限不代表有限机器可以无限并行。当前事务仍会水合和校验完整业务状态；历史分离减少磁盘写放大，不能保证任意人数、历史长度或运行时间下不会 OOM。详细运行方式与存储兼容边界见[架构文档](docs/architecture.md)。

## Web 控制台

标签页：**概览 / 组织 / 产品 / 工作 / 工单 / 招聘 / 审计 / 审批**。

- **概览** —— 标语与使命、章程树、阻塞事项、实时活动。
- **组织** —— 可折叠组织树（负载分带、内联成员、部门子树金额与模型分布、负责人归属、员工详情与授权面板）。
- **工单** —— Web 提交表单 + 状态分组（待分级/待派发、已解决待关闭、已关闭含回复）；分级、派发与关闭由 Founder/支持工程师工具执行。
- **招聘** —— 上文所述的启用开关价格矩阵。
- **审计** —— 金额统计、用量成本图表、有界审计明细。
- **审批** —— 决策卡：审批内容常显，范围摘要与详细信息默认折叠。

远程浏览器看到只读降级视图；回环页面获得完整参与者视图与变更能力（见[宿主/Web 契约与安全](#宿主web-契约与安全)）。

## 宿主工具

| 工具 | 谁可用 | 用途 |
|---|---|---|
| `company_bootstrap` / `company_edit_formation` / `company_approve` | 创始人 | 起草 / 编辑 / 批准成立方案 |
| `company_request_staffing` / `company_claim_staffing_assessment` / `company_submit_staffing_assessment` | 创始人 / HR | HR 治理招聘流水线 |
| `company_add_employee` / `company_remove_employee` / `company_apply_staffing_adjustment` | 创始人 | 应用已批准的组织变更与可重试 provisioning |
| `company_create_product` / `company_update_product` | 创始人 | 创建产品与受控生命周期转换 |
| `company_create_work` / `company_edit_work` / `company_reassign_work` | 创始人 | 工作 DAG 规划 |
| `company_claim_work` / `company_update_work` | 员工 | 尝试栅栏下的执行与举证 |
| `company_send_message` | 参与者 | 持久跨参与者消息（不可信数据框架） |
| `company_request_approval` / `company_resolve_approval` | 参与者 / 创始人 | 类型化人类审批 |
| `company_request_budget_change` / `company_request_governance_change` / `company_reprobe_models` | 创始人 | 预算与价格审批、目录重探测 |
| `company_triage_ticket` / `company_dispatch_ticket` / `company_close_ticket` / `company_designate_support` | 创始人 / 支持 | 工单生命周期 |
| `company_grant_temporary_authorization` / `company_revoke_temporary_authorization` | 创始人 | 消费已批准请求后应用/撤销有界授权 |
| `company_control` / `company_status` | 创始人 / 参与者 | 暂停/恢复/归档；角色过滤概览与分区分页查询 |

`company_status` 默认返回经营概览；查询任务可用 `{"section":"work","id":"w1"}`，查询待审批可用 `{"section":"approvals","status":"pending"}`，列表使用 `offset` / `limit` 分页。工具结果不再是整份 CompanySnapshot；已有程序化调用需改用分区查询。Web 的 HTTP 快照契约保持不变。

## 状态与数据

```
~/.dsh/dsh-company/v1/workspaces/<工作区哈希>/
├── identity.json      # 工作区锚点（规范路径 + sha256）
├── active/            # 运营中的公司
│   ├── company.json   # 全量状态（schemaVersion 2，旧 v1 原位迁移）
│   ├── events.jsonl   # 有界滚动审计窗口（每次变更一行，超限淘汰最旧行）
│   ├── transaction.json # 仅提交/崩溃恢复期间存在的 WAL
│   └── mailboxes/     # 每参与者持久收件箱
└── archive/<id>/      # 归档公司（同构布局）
```

员工对话转录存放在 DSH 会话存储（`~/.dsh/sessions/`），以其保留的会话 id 索引——重启后带完整上下文恢复。

## 宿主/Web 契约与安全

- `GET /plugins/dsh-company/state?sessionId=…` —— snake_case 投影。回环同源页面获得该会话真实参与者视图（创始人得到可编辑的 founder 视图）；远程客户端（仅 `allowRemoteUi` 开启后可达）获得降级只读视图，私有证据全部剥离。
- `POST /plugins/dsh-company/action` —— 回环页面以命名会话参与者身份执行（必须有同源 `Origin`；修订栅栏；运行时二次校验精确在世创始人与公司绑定）。`Forwarded`/`X-Forwarded-For` 只会让请求降级为 remote，远程客户端固定拒绝（`403 web_mutations_require_loopback`）。
- 快照永不携带 attempt capability、执行 prompt、凭据或私有工作证据。临时授权绝不改变 DSH 工具权限或沙箱。

## 开发

```bash
pnpm verify          # typecheck && test && build && package:check
pnpm test            # test/ 下的 node:test 套件
pnpm build           # tsc（宿主+客户端）+ tsdown 打包
```

CI 在每次 push 和 PR 上运行同一 `pnpm verify` 门禁（见 `.github/workflows/ci.yml`）。

### 发布

1. 同时改 `package.json` 与 `scripts/verify-package.mjs` 中的版本断言。
2. 运行 `pnpm verify && npm pack --ignore-scripts`，避免 prepack 重复构建。
3. 打 `v<version>` 标签并推送；release 工作流校验后把 tarball 附到 GitHub Release。
4. 用 `dsh plugin --profile web add <tarball>` 安装。

## 许可证

MIT —— 见 [LICENSE](LICENSE)。
