import { randomUUID } from 'node:crypto'
import { createTemporaryAuthorization } from '../src/authorizations.js'
import type { CompanyState, GrantTemporaryAuthorizationInput } from '../src/types.js'

export function companyState(overrides: Partial<CompanyState> = {}): CompanyState {
  const now = Date.now()
  return {
    schemaVersion: 2,
    revision: 1,
    id: `c_${randomUUID()}`,
    name: 'Example Company',
    slogan: 'Build verified products.',
    mission: 'Build and verify one bounded example product.',
    governanceRevision: 1,
    workspaceHash: '0'.repeat(64),
    founderSessionId: 'founder-session',
    stagedFromUserMessageId: 'user-message-1',
    phase: 'operating',
    createdAt: now,
    updatedAt: now,
    approvedAt: now,
    limits: {
      maxEmployees: 8,
      maxProducts: 8,
      maxWorkItems: 128,
      maxOpenWorkItems: 32,
      maxAttemptsPerWork: 5,
      maxPendingApprovals: 32,
      maxMailboxMessages: 100,
      maxAuditBytes: 1_048_576,
      maxMessageChars: 16_384,
      maxOutputChars: 65_536,
      memberMaxDepth: 0,
    },
    counters: { employee: 1, product: 1, work: 0, approval: 0, event: 0, orgUnit: 2, position: 1, staffing: 0, authorization: 0, ticket: 0 },
    moneyBudget: {
      unit: 'micro-currency', currency: 'USD', totalMicros: 100_000_000, reservedMicros: 0, spentMicros: 0,
      warningAtMicros: 10_000_000, pricingRevision: 1,
      prices: [{ provider: 'mock', model: 'mock-model', inputCacheMissMicrosPerMillion: 0, inputCacheHitMicrosPerMillion: 0, outputMicrosPerMillion: 0, source: 'manual', revision: 1, updatedAt: now }],
      usage: [], reservations: [], migrationRequired: false,
    },
    modelCatalog: { stale: false, generation: 1, probedAt: now, models: [{ provider: 'mock', model: 'mock-model', name: 'mock-model', contextWindow: 128_000, advertised: true, available: true }], errors: [] },
    temporaryAuthorizations: [],
    formation: { status: 'approved', charter: 'Operate a bounded verified product company.', firstProductId: 'p1', draftedBy: 'ai', lastEditedAt: now, approvedAt: now },
    health: { status: 'healthy', resumable: true },
    orgUnits: [
      { id: 'ou1', name: 'Example Company', kind: 'company', createdAt: now },
      { id: 'ou2', name: 'Engineering', kind: 'department', parentId: 'ou1', managerEmployeeId: 'e1', createdAt: now },
    ],
    positions: [{ id: 'pos1', title: 'Engineer', orgUnitId: 'ou2', responsibilities: ['Implement bounded work'], createdAt: now }],
    staffingRequests: [],
    employees: [{
      id: 'e1',
      name: 'Engineer',
      role: 'Implement bounded work',
      orgUnitId: 'ou2', positionId: 'pos1', budgetMicros: 100_000_000,
      status: 'idle',
      sessionId: 'employee-session',
      joinedAt: now,
      llm: { provider: 'mock', model: 'mock-model', activeProvider: 'mock', activeModel: 'mock-model' },
    }],
    products: [{
      id: 'p1',
      name: 'Example Product',
      summary: 'One bounded product',
      status: 'active',
      productRoot: 'product',
      successCriteria: ['All tests pass'],
      budgetMicros: 100_000_000,
      createdAt: now,
      updatedAt: now,
    }],
    workItems: [],
    tickets: [],
    approvals: [],
    governanceNotifications: [],
    ...overrides,
  }
}

export function approvedTemporaryAuthorization(
  state: CompanyState,
  input: Omit<GrantTemporaryAuthorizationInput, 'approvalId'>,
  limits: { maxMs: number },
  now: number,
) {
  state.counters.approval += 1
  const approvalId = `a${state.counters.approval}`
  state.approvals.push({
    id: approvalId,
    kind: 'temporary_authorization',
    status: 'approved',
    requestedBy: 'founder',
    summary: `Approve temporary authorization for ${input.employeeId}`,
    payload: {
      action: 'grant', employeeId: input.employeeId, reason: input.reason,
      ...(input.startsAt === undefined ? {} : { startsAt: input.startsAt }), expiresAt: input.expiresAt,
    },
    risk: 'high',
    requestedAt: now,
    resolvedAt: now,
    consumedAt: now,
    resolution: { decision: 'approved', source: 'ui', humanStatement: 'Approved in test fixture.' },
  })
  return createTemporaryAuthorization(state, { ...input, approvalId }, limits, now)
}
