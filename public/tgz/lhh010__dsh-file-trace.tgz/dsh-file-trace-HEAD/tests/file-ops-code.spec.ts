import { describe, expect, it } from 'vitest'
import { extractFileOps } from '../src/client/file-ops.ts'
import type { ConversationNode } from '@deepseek-ai/dsh-client-ui-conversation/client'

/** 最小 tool-result node 构造。 */
function codeNode(code: string, name = 'run_code'): ConversationNode {
  return {
    kind: 'tool-result', callId: 'c1', time: 100, isError: false, content: [{ text: 'ok' }],
    call: { name, argsRaw: JSON.stringify({ code }), time: 90 },
    subCalls: [],
  } as unknown as ConversationNode
}

describe('code-op extraction', () => {
  it('finds readFileSync/writeFileSync paths and marks viaCode', () => {
    const ops = extractFileOps([codeNode("const a = readFileSync('D:/x/a.md'); writeFileSync('E:/y/b.txt', 'hi')")], [])
    expect(ops).toHaveLength(2)
    const read = ops.find(o => o.kind === 'read')!
    const write = ops.find(o => o.kind === 'write')!
    expect(read.path).toBe('D:/x/a.md')
    expect(read.viaCode).toBe(true)
    expect(write.path).toBe('E:/y/b.txt')
    expect(write.viaCode).toBe(true)
  })
  it('deduplicates repeated calls to the same path', () => {
    const ops = extractFileOps([codeNode("readFileSync('C:/tmp/a.txt'); readFileSync('C:/tmp/a.txt')")], [])
    expect(ops).toHaveLength(1)
  })
  it('ignores node: protocol and URLs', () => {
    const ops = extractFileOps([codeNode("import('node:fs'); fetch('https://x.com/a.png')")], [])
    expect(ops).toHaveLength(0)
  })
  it('does not touch non-code tools', () => {
    const node = codeNode('readFileSync("a.txt")', 'grep')
    const ops = extractFileOps([node], [])
    expect(ops).toHaveLength(0)
  })
  it('powershell Get-Content/Set-Content detected', () => {
    const ops = extractFileOps([codeNode('Get-Content "C:/a.md" | Out-Null', 'pwsh')], [])
    expect(ops).toHaveLength(1)
    expect(ops[0]!.kind).toBe('read')
    expect(ops[0]!.viaCode).toBe(true)
  })
  it('dynamic paths (variables) produce no ops', () => {
    const ops = extractFileOps([codeNode('readFileSync(p); writeFileSync(q, d)')], [])
    expect(ops).toHaveLength(0)
  })
})

describe('code-op dynamic path rejection', () => {
  it('rejects concatenated base-dir fragments (readFileSync("E:/base/" + p))', () => {
    const ops = extractFileOps([codeNode('const c = readFileSync("E:/deepseek-harness/" + p + "/compatibility.json", "utf8")')], [])
    expect(ops).toHaveLength(0)
  })
  it('rejects directory-prefix literals ending in a separator', () => {
    const ops = extractFileOps([codeNode("readdirSync('E:/dir/')")], [])
    expect(ops).toHaveLength(0)
  })
  it('still accepts complete literal paths', () => {
    const ops = extractFileOps([codeNode("readFileSync('E:/dir/a.json')")], [])
    expect(ops).toHaveLength(1)
  })
})

describe('code-op prose and bare-name rejection', () => {
  it('rejects prose after cmdlet names in documentation text (no quotes)', () => {
    const prose = 'readFileSync / writeFileSync / Get-Content / Set-Content 等字符串字面量路径）现在也进文件追踪面板，标注为「代码读取」'
    const ops = extractFileOps([codeNode(prose)], [])
    expect(ops).toHaveLength(0)
  })
  it('rejects bare relative filenames (no directory component)', () => {
    const ops = extractFileOps([codeNode("readFileSync('compatibility.json')")], [])
    expect(ops).toHaveLength(0)
  })
  it('accepts ./ and ../ relative paths', () => {
    const ops = extractFileOps([codeNode("readFileSync('./src/a.ts')")], [])
    expect(ops).toHaveLength(1)
  })
})
