// @vitest-environment jsdom
/**
 * Component behavior: the trigger derives ops from the conversation hook,
 * the drawer lists files, and selecting an edit op renders a colored diff.
 */
import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type {} from '@deepseek-ai/dsh-client-ui-chat/client'
import { FileTraceButton, resetDrawerRemountStores, type FileTraceButtonProps } from '../src/client/FileTraceButton.tsx'
import { zh } from '../src/client/locales.ts'

afterEach(() => {
  cleanup()
  // Each rendered case simulates a fresh page lifetime: drop the
  // remount-surviving drawer stores so one case's open drawer cannot leak
  // into the next case's initial render.
  resetDrawerRemountStores()
})

/** One settled tool-result node fixture (edit by default). */
function toolNode(callId: string, name: string, args: Record<string, unknown>, time: number, isError: boolean, content: unknown[]) {
  return {
    kind: 'tool-result' as const,
    seq: time,
    time,
    callId,
    call: { name, argsRaw: JSON.stringify(args) },
    callTime: time,
    content,
    isError,
    subCalls: [],
  }
}

function editNode(callId: string, path: string, oldString: string, newString: string, time: number) {
  return toolNode(callId, 'edit', { file_path: path, old_string: oldString, new_string: newString }, time, false, [])
}

/** Conversation snapshot whose chat view serves the legacy node slice. */
function conversationOf(nodes: readonly unknown[]): ConversationSnapshot {
  return {
    views: { get: () => ({ legacy: { nodes, runningCalls: [] } }) },
    activeTargets: new Set(['chat']),
  } as unknown as ConversationSnapshot
}

/** Stub props: scripted useConversation over the fixture + zh translate. */
function propsWith(conversation: ConversationSnapshot): FileTraceButtonProps {
  const t = (key: string, params?: Record<string, string>): string => ((zh as Record<string, string>)[key] ?? key).replace(/\{(\w+)\}/g, (_, name: string) => params?.[name] ?? '')
  return {
    sessionId: 's-1',
    useConversation: ((selector: (s: ConversationSnapshot) => unknown) => selector(conversation)) as never,
    useSession: (() => undefined) as never,
    useSessions: (() => undefined) as never,
    useWorkspaces: (() => []) as never,
    useProjection: (() => undefined) as never,
    useInput: (() => undefined) as never,
    useChat: (() => undefined) as never,
    useSessionPendingInteraction: (() => undefined) as never,
    t: t as unknown as FileTraceButtonProps['t'],
  } as unknown as FileTraceButtonProps
}

describe('FileTraceButton', () => {
  it('shows the op count badge on the trigger', () => {
    const conversation = conversationOf([editNode('e1', 'a.ts', 'x', 'y', 1)])
    render(<FileTraceButton {...propsWith(conversation)} />)
    expect(screen.getByText('1').textContent).toBe('1')
  })

  it('keeps the floating drawer open across a session-switch remount', () => {
    const conversation = conversationOf([editNode('e1', 'a.ts', 'x', 'y', 1)])
    const first = render(<FileTraceButton {...propsWith(conversation)} />)
    fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
    expect(first.container.querySelector('[data-file-trace-drawer]')).not.toBeNull()
    // Session switch: the header (trigger + drawer) unmounts entirely...
    first.unmount()
    // ...and switching back mounts a fresh instance, which must reopen.
    const second = render(<FileTraceButton {...propsWith(conversation)} />)
    expect(second.container.querySelector('[data-file-trace-drawer]')).not.toBeNull()
  })

  it('keeps drawer state independent per session (a closed session stays closed)', () => {
    const conversation = conversationOf([editNode('e1', 'a.ts', 'x', 'y', 1)])
    // Session A opens its drawer.
    const a = render(<FileTraceButton {...propsWith(conversation)} />)
    fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
    expect(a.container.querySelector('[data-file-trace-drawer]')).not.toBeNull()
    a.unmount()
    // Session B (never opened) mounts: its own drawer stays closed...
    const b = render(<FileTraceButton {...{ ...propsWith(conversation), sessionId: 's-2' }} />)
    expect(b.container.querySelector('[data-file-trace-drawer]')).toBeNull()
    b.unmount()
    // ...and switching back to A reopens A's drawer.
    const a2 = render(<FileTraceButton {...propsWith(conversation)} />)
    expect(a2.container.querySelector('[data-file-trace-drawer]')).not.toBeNull()
  })

  it('scopes the persisted split height per session with legacy fallback', () => {
    window.localStorage.setItem('dsh-file-trace:diffHeight:s-1', '480')
    window.localStorage.setItem('dsh-file-trace:diffHeight', '260')
    try {
      const conversation = conversationOf([editNode('e1', 'a.ts', 'x', 'y', 1)])
      // s-1 prefers its own scoped value; s-2 falls back to the legacy key.
      const one = render(<FileTraceButton {...propsWith(conversation)} />)
      fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
      fireEvent.click(one.container.querySelector('[data-op-kind="edit"]') as HTMLElement)
      expect(((one.container.querySelector('[data-file-trace-diff]') as HTMLElement).style.height)).toBe('480px')
      cleanup()
      const two = render(<FileTraceButton {...{ ...propsWith(conversation), sessionId: 's-2' }} />)
      fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
      fireEvent.click(two.container.querySelector('[data-op-kind="edit"]') as HTMLElement)
      expect(((two.container.querySelector('[data-file-trace-diff]') as HTMLElement).style.height)).toBe('260px')
    } finally {
      window.localStorage.removeItem('dsh-file-trace:diffHeight:s-1')
      window.localStorage.removeItem('dsh-file-trace:diffHeight')
    }
  })

  it('restores the diff/list split height from localStorage on remount', () => {
    window.localStorage.setItem('dsh-file-trace:diffHeight:s-1', '480')
    try {
      const conversation = conversationOf([editNode('e1', 'a.ts', 'x', 'y', 1)])
      const { container } = render(<FileTraceButton {...propsWith(conversation)} />)
      fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
      fireEvent.click(container.querySelector('[data-op-kind="edit"]') as HTMLElement)
      const pane = container.querySelector('[data-file-trace-diff]') as HTMLElement
      expect(pane.style.height).toBe('480px')
    } finally {
      window.localStorage.removeItem('dsh-file-trace:diffHeight:s-1')
    }
  })

  it('embedded mount renders the drawer statically without a trigger button', () => {
    const conversation = conversationOf([editNode('e1', 'a.ts', 'x', 'y', 1)])
    const { container } = render(<FileTraceButton {...propsWith(conversation)} embedded />)
    // No header trigger in the embedded variant; the drawer is present and
    // marked embedded (static fill, no dialog semantics).
    expect(container.querySelector('[data-file-trace-trigger]')).toBeNull()
    const drawer = container.querySelector('[data-file-trace-drawer]')
    expect(drawer).not.toBeNull()
    expect(drawer?.getAttribute('data-embedded')).toBe('true')
    expect(drawer?.getAttribute('role')).toBeNull()
    // The file list is live immediately (no open state to toggle).
    expect(screen.getByText('a.ts')).toBeTruthy()
  })

  it('opens the drawer, lists the file, and renders a mod-tinted diff', () => {
    const conversation = conversationOf([editNode('e1', 'src/a.ts', 'old line', 'new line', 1)])
    const { container } = render(<FileTraceButton {...propsWith(conversation)} />)
    fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
    expect(screen.getByText('src/a.ts')).toBeTruthy()
    // Select the edit op row.
    fireEvent.click(screen.getByText('编辑').closest('button') as HTMLElement)
    // The diff pane shows both sides, classed mod (rewrite pair).
    const rows = container.querySelectorAll('[data-file-trace-diff] [data-kind]')
    expect(rows.length).toBeGreaterThanOrEqual(2)
    expect(container.querySelectorAll('[data-kind="mod"]').length).toBe(2)
  })

  it('shows the captured error text instead of a fabricated diff for an errored write', () => {
    const conversation = conversationOf([
      toolNode('w1', 'write', { file_path: 'a.cpp', content: 'x' }, 1, true, [{ type: 'text', text: '写入失败：目标只读' }]),
    ])
    const { container } = render(<FileTraceButton {...propsWith(conversation)} />)
    fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
    fireEvent.click(container.querySelector('[data-op-kind="write"]') as HTMLElement)
    const alert = container.querySelector('[role="alert"]')
    expect(alert?.textContent).toBe('写入失败：目标只读')
    expect(container.querySelectorAll('[data-file-trace-diff] [data-kind="add"]').length).toBe(0)
  })

  it('renders syntax-colored tokens for known-language lines', () => {
    const conversation = conversationOf([
      toolNode('w1', 'write', { file_path: 'a.cpp', content: 'int main() { return 0; } // go' }, 1, false, []),
    ])
    const { container } = render(<FileTraceButton {...propsWith(conversation)} />)
    fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
    fireEvent.click(container.querySelector('[data-op-kind="write"]') as HTMLElement)
    const pane = container.querySelector('[data-file-trace-diff]')
    expect(pane).not.toBeNull()
    expect((pane as HTMLElement).innerHTML).toContain('tokKeyword')
    expect((pane as HTMLElement).innerHTML).toContain('tokComment')
    expect((pane as HTMLElement).innerHTML).toContain('tokNumber')
  })

  it('colors interior lines of a multi-line comment in a diff (state threading)', () => {
    const v1 = ['/* header', ' * interior note', ' */', 'const x = 1', 'const y = 2'].join('\n')
    const v2 = ['/* header', ' * interior note', ' */', 'const x = 1', 'const y = 3'].join('\n')
    const conversation = conversationOf([
      toolNode('w1', 'write', { file_path: 'a.ts', content: v1 }, 1, false, []),
      toolNode('w2', 'write', { file_path: 'a.ts', content: v2 }, 2, false, []),
    ])
    const { container } = render(<FileTraceButton {...propsWith(conversation)} />)
    fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
    fireEvent.click(container.querySelector('[data-op-kind="write"]') as HTMLElement)
    const pane = container.querySelector('[data-file-trace-diff]') as HTMLElement
    // open+interior+close comment lines (3) plus the const keyword rows.
    expect(pane.innerHTML.split('tokComment').length - 1).toBe(3)
    expect(pane.innerHTML).toContain('tokKeyword')
  })

  it('renders the empty hint for a clean window', () => {
    render(<FileTraceButton {...propsWith(conversationOf([]))} />)
    fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
    expect(screen.getByText('本会话窗口内还没有文件操作')).toBeTruthy()
  })

  it('closes on Escape', () => {
    const conversation = conversationOf([editNode('e1', 'a.ts', 'x', 'y', 1)])
    render(<FileTraceButton {...propsWith(conversation)} />)
    fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
    fireEvent.keyDown(window, { key: 'Escape' })
    expect(document.querySelector('[data-file-trace-drawer]')).toBeNull()
  })

  it('ctrl+wheel resizes the list and pane fonts independently with bound toasts', () => {
    const conversation = conversationOf([editNode('e1', 'src/a.ts', 'old line', 'new line', 1)])
    const { container } = render(<FileTraceButton {...propsWith(conversation)} />)
    fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
    const drawer = container.querySelector('[data-file-trace-drawer]') as HTMLElement
    // fireEvent.wheel runs inside act, so the state update re-renders.
    const wheel = (target: Element, deltaY: number): void => {
      fireEvent.wheel(target, { ctrlKey: true, deltaY })
    }
    const listArea = container.querySelector('[data-file-trace-drawer] .drawerBody') ?? drawer
    // Enlarge the list area: 12 → 15.
    for (let i = 0; i < 3; i++) wheel(listArea, -100)
    expect(drawer.style.getPropertyValue('--ft-list-font')).toBe('15px')
    // The pane font is untouched.
    expect(drawer.style.getPropertyValue('--ft-pane-font')).toBe('12px')
    // Open the diff pane and shrink it: 12 → 10. The selection remounts the
    // drawer (error-boundary key), so re-query the live element.
    fireEvent.click(screen.getByText('编辑').closest('button') as HTMLElement)
    const liveDrawer = container.querySelector('[data-file-trace-drawer]') as HTMLElement
    const pane = container.querySelector('[data-file-trace-diff]') as HTMLElement
    for (let i = 0; i < 2; i++) wheel(pane, 100)
    expect(liveDrawer.style.getPropertyValue('--ft-pane-font')).toBe('10px')
    expect(liveDrawer.style.getPropertyValue('--ft-list-font')).toBe('15px')
    // Push far past the minimum: clamps at 9px and toasts.
    for (let i = 0; i < 30; i++) wheel(pane, 100)
    expect(liveDrawer.style.getPropertyValue('--ft-pane-font')).toBe('9px')
    const toast = document.getElementById('dsh-file-trace-font-toast')
    expect(toast?.textContent).toContain('9')
  })

  it('an ERRORED pdf read (the binary-file refusal) still gains the render toggle — the render streams the saved file, not the payload', async () => {
    // jsdom has no blob URL implementation — stub it for the PdfFrame fetch.
    const realCreate = URL.createObjectURL
    const realRevoke = URL.revokeObjectURL
    URL.createObjectURL = (): string => 'blob:mock-' + String(Math.random())
    URL.revokeObjectURL = () => {}
    const fetchMock = vi.fn(async () => ({
      ok: true,
      arrayBuffer: async () => new ArrayBuffer(8),
    })) as unknown as typeof fetch
    const realFetch = globalThis.fetch
    globalThis.fetch = fetchMock
    try {
      const readNode = toolNode('r1', 'read', { file_path: 'C:/work/report.pdf' }, 1, true, [])
      const { container } = render(<FileTraceButton {...propsWith(conversationOf([readNode]))} />)
      fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
      fireEvent.click(screen.getByText('读取').closest('button') as HTMLElement)
      // The toggle shows for an absolute .pdf path; off by default (no iframe).
      const toggle = screen.getByText('渲染').closest('button') as HTMLElement
      expect(container.querySelector('[data-file-trace-pdf-pane]')).toBeNull()
      fireEvent.click(toggle)
      await vi.waitFor(() => {
        expect(container.querySelector('[data-file-trace-pdf-pane] iframe')).toBeTruthy()
      })
      // The bytes streamed through the host asset route…
      expect(fetchMock).toHaveBeenCalledWith('/dsh-file-trace/asset?path=C%3A%2Fwork%2Freport.pdf', expect.anything())
      // …and re-wrapped into an explicitly-typed blob URL (native PDF viewer).
      expect((container.querySelector('[data-file-trace-pdf-pane] iframe') as HTMLIFrameElement).src.startsWith('blob:')).toBe(true)
    } finally {
      URL.createObjectURL = realCreate
      URL.revokeObjectURL = realRevoke
      globalThis.fetch = realFetch
    }
  })

  it('a relative-path pdf read op gains no render toggle (the asset route serves absolute paths only)', () => {
    const readNode = toolNode('r2', 'read', { file_path: 'docs/report.pdf' }, 1, false, [])
    render(<FileTraceButton {...propsWith(conversationOf([readNode]))} />)
    fireEvent.click(screen.getByRole('button', { name: /文件追踪/ }))
    fireEvent.click(screen.getByText('读取').closest('button') as HTMLElement)
    expect(screen.queryByText('渲染')).toBeNull()
  })
})

