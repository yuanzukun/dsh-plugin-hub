/**
 * File-trace plugin, browser half: registers the session-header utilities
 * trigger (with its drawer) that records and reviews every file the model
 * read, wrote, or edited in the loaded window. Export discipline:
 * packages/client/AGENTS.md — only the cordis apply surface and contract
 * types leave this package.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis'
// Type-only: pulls the locale plugin's Context merge (ctx.locale).
import type {} from '@deepseek-ai/dsh-client-locale/client'
// Type-only: pulls the Chat view snapshot types (legacy slice).
import type {} from '@deepseek-ai/dsh-client-ui-chat/client'
// Type-only: pulls the header.utilities slot and the useConversation seat.
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
// Type-only: pulls the renderer-owned slots service (ctx.slots merge).
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
// Type-only: pulls the useSession seat over the Session snapshot.
import type {} from '@deepseek-ai/dsh-client-ui-session/client'
import { FileTraceButton, setCurrentSessionId } from './FileTraceButton.tsx'
import { registerSidebarTab } from './sidebar-tab.tsx'
import { startUpdateChip } from './update-chip.ts'
import { en, zh, type FileTraceKey } from './locales.ts'
import { applyWithCompat } from './compat.ts'
import { setPathActionsRemote } from './path-actions.ts'

export type { FileTraceButtonProps } from './FileTraceButton.tsx'
export type { FileTraceKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The file-trace surfaces' copy. */
    fileTrace: FileTraceKey
  }
}

/** Dictionary namespace owned by this plugin. */
const NS = 'fileTrace'

/**
 * Required services (cordis fiber inject): the slot registry for the header
 * utilities contribution and the locale service for the dictionaries.
 */
export const inject = ['slots', 'locale']

/**
 * Client plugin body: register the `fileTrace` dictionaries and the header
 * trigger behind the graceful-compatibility guard.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  applyWithCompat(
    '@dsh-external/dsh-file-trace',
    '当前 DSH 客户端 API 与插件不匹配',
    [
      '将 DSH 升级到已适配的版本（dsh-v0.1.2-alpha.1，源码构建安装）。',
      '或将插件更新到适配当前 DSH 的版本（仓库最新 tag）。',
      '如仍显示，请在插件目录执行 pnpm run build 后刷新页面。',
    ],
    [
      ['slots.inject', ctx?.slots?.inject],
      ['slots.register', ctx?.slots?.register],
      ['locale.register', ctx?.locale?.register],
    ],
    () => {
      ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'file-trace: dictionaries')

      // Session id for workspace-relative paths (present deliveries): the
      // optional uiSession service names the main-view session (0.1.6-alpha.2+).
      ctx.effect(() => {
        type UISessionCurrent = { getSnapshot(): { key?: unknown } | undefined; subscribe(listener: () => void): () => void }
        const uiSession = ctx.get('uiSession') as { current: UISessionCurrent } | undefined
        if (uiSession === undefined) return () => { /* uiSession absent on this host */ }
        let last = ''
        const sync = (): void => {
          const key = uiSession.current.getSnapshot()?.key
          const id = typeof key === 'string' ? key : ''
          if (id !== last) { last = id; setCurrentSessionId(id) }
        }
        sync()
        const unsubscribe = uiSession.current.subscribe(sync)
        return () => { unsubscribe() }
      }, 'file-trace: session id sync')

      // Host desktop path actions (reveal in file manager / open with the
      // default local app). `remote.session` is a nested cordis dependency:
      // reading it without declaring the inject throws, so the optional
      // feature rides a child fiber — on hosts that never publish the
      // remote (old DSH, headless) the fiber stays pending and the controls
      // simply never mount.
      ctx.inject(['remote', 'remote.session'], sub => {
        sub.effect(() => {
          setPathActionsRemote(sub.get('remote'))
          return () => { setPathActionsRemote(null) }
        }, 'file-trace: path actions remote')
      })

      ctx.slots.inject('conversation.session.header.utilities', () => ctx.slots.register(
        { name: 'conversation.session.header.utilities', id: 'file-trace', order: 10, locale: NS },
        FileTraceButton,
      ))

      // Dual mount: a native better-sidebar tab when that service is present
      // (optional peer); the header trigger above stays either way.
      registerSidebarTab(ctx)

      // Version-check notice chip (green=latest / gray=unreachable / blue=update).
      startUpdateChip()
    },
  )
}
