/**
 * Narrow local contracts for the DSH host services and events this plugin
 * consumes. Keeping these structural copies (instead of importing host source
 * packages) lets the package build self-contained; a composed DSH profile
 * supplies the real implementations at runtime. Field shapes mirror
 * `@deepseek-ai/dsh-agent`, `@deepseek-ai/dsh-session`, and
 * `@deepseek-ai/dsh-user-approval` as of dsh main 2026-08-20 (was 0.0.1-rc.2).
 * P1 alignment: cancel signature, GoalChange clear-tombstone, and Cordis event
 * guards expanded for perfect-plugin roadmap.
 * @module dsh-lark-bridge/host
 */
import type { Context } from '@deepseek-ai/cordis';
/**
 * The live session a host agent drives.
 *
 * `id` is the identity the agent registry and session log share. `seq` and
 * `eventAt` are what the host's `tokenMeter` replays the session log through
 * to price a context — a token meter that is handed only the id cannot read
 * the log, reports zero for every session, and never raises the context
 * pressure warning. Upstream `measure(session: Session, …)` reads
 * `session.seq` and calls `session.eventAt(seq)`.
 */
export interface HostSession {
    /** The session id shared by the agent registry and session log. */
    readonly id: string;
    /** The number of committed events in the session log (the next `eventAt` index). */
    readonly seq: number;
    /** The event stored at one exact sequence number, or undefined past the tail. */
    eventAt(seq: number): unknown;
}
/** Durable metadata for one stored image, from {@link HostAttachments.saveImage}. */
export interface HostImageRef {
    readonly attachmentId: string;
    readonly mediaType: string;
    readonly bytes: number;
    readonly width: number;
    readonly height: number;
    readonly name?: string;
}
/** One model-facing content block this plugin produces. */
export type HostContentBlock = {
    readonly type: 'text';
    readonly text: string;
} | {
    readonly type: 'image';
    readonly attachment: HostImageRef;
};
/** A user-role message accepted by every {@link HostAgent} inbox boundary. */
export interface HostUserMessage {
    /** Stable message identity; a fresh UUID per message. */
    readonly id: string;
    readonly role: 'user';
    /** Model-facing content blocks: the chat's text, plus any images it carried. */
    readonly content: readonly HostContentBlock[];
    /** Producer tag: chat input is a direct human prompt. */
    readonly source: {
        readonly kind: 'user';
    };
}
/** What one image must satisfy to be stored, from the attachment service. */
export interface HostImageLimits {
    readonly maxImageBytes: number;
    readonly maxImagesPerMessage: number;
    readonly maxMessageImageBytes: number;
    readonly mediaTypes: readonly string[];
}
/**
 * The `attachments` store (subset of the host `AttachmentStore`). Images reach
 * a model as an opaque reference to bytes this service owns, never as a path
 * or a URL, so a chat image has to be committed here before it can be sent.
 */
export interface HostAttachments {
    readonly imageLimits: HostImageLimits;
    /** Validate and durably commit one image; the media type is checked against the bytes. */
    saveImage(input: {
        data: Uint8Array;
        mediaType: string;
        name?: string;
    }): Promise<HostImageRef>;
}
/** Public live-agent handle (subset of the host `Agent` interface). */
export interface HostAgent {
    /** The single identity shared with {@link session}. */
    readonly id: string;
    readonly session: HostSession;
    /** Live phase label (`'idle' | 'running'`) when the host agent exposes it; test doubles may omit it. */
    readonly status?: string;
    /** Queue an ordinary follow-up turn and wake the driver. */
    followup(message: HostUserMessage): void;
    /**
     * Submit steering for the nearest step. An idle driver starts a turn; a
     * running driver consumes it at its next step boundary, so a chat can change
     * direction without discarding the work already done.
     *
     * Optional: absent on a host old enough to predate steering, and a test
     * double need not model it. The bridge's `busyPolicy` falls back to
     * `followup` when the boundary it asked for is missing.
     */
    steer?(message: HostUserMessage): void;
    /**
     * Queue model-facing context for the next pre-step WITHOUT waking the
     * driver. A running driver claims it at the nearest later step boundary, so
     * it is the boundary for a note the model should read, not an instruction
     * that must run. Optional for the same reason as {@link steer}.
     */
    inject?(message: HostUserMessage): void;
    /**
     * Clear queued work and abort the active turn. A no-op when nothing is
     * active, so a chat may offer it unconditionally.
     * Signature mirrors Agent.cancel(cause: AgentCancelCause, options?: CancelOptions).
     */
    cancel(cause: string, options?: {
        readonly keepInbox?: boolean;
    }): void;
}
/** An owned agent plus its teardown capability, from `agents.create()`. */
export interface HostAgentHandle {
    readonly agent: HostAgent;
    dispose(): Promise<void>;
}
/** Per-agent provider/model routing accepted by {@link HostAgentRegistry.create}. */
export interface HostAgentOptions {
    readonly provider?: string | undefined;
    readonly model?: string | undefined;
}
/** One persisted session's header, as this plugin's lookup reads it. */
export interface HostSessionHeader {
    /**
     * The session's own header.
     *
     * The persistence store hands back a snapshot with the header one level
     * down, not a flat record — reading `id` off the snapshot reads
     * `undefined`.
     */
    readonly header: {
        readonly id: string;
        /** Unix epoch milliseconds; the newest header for a chat is the one to resume. */
        readonly createdAt: number;
    };
}
/**
 * The `sessionPersistence` store (subset of the host provider). Only headers
 * are read: enough to find a chat's previous session without loading any log.
 */
export interface HostSessionPersistence {
    list(signal?: AbortSignal): Promise<readonly HostSessionHeader[]>;
}
/** The `agents` registry service (subset of the host `AgentRegistry`). */
export interface HostAgentRegistry {
    /** Reopen a persisted session as a live agent, replaying its history. */
    resume(options: {
        readonly resumeSessionId: string;
        readonly agentOptions?: HostAgentOptions;
        readonly setup?: (agentCtx: Context) => Promise<void>;
    }): Promise<HostAgentHandle>;
    create(options: {
        readonly sessionId: string;
        readonly meta?: {
            readonly cwd?: string;
            readonly agentPreset?: string;
        };
        readonly agentOptions?: HostAgentOptions;
        /**
         * Creation-time composition of the agent's scoped world, awaited before
         * the session and agent are published. A rejection rolls the whole
         * creation back, so a broken composition never yields a half-built session.
         */
        readonly setup?: (agentCtx: Context) => Promise<void>;
    }): Promise<HostAgentHandle>;
}
/**
 * The `tools` registry, as this plugin's per-agent composition uses it
 * (subset of the host `ToolRegistry`).
 */
export interface HostTools {
    /**
     * Register a monotonic execution guard. Registered through an agent's scoped
     * context it applies to that agent alone; returning a string denies the call
     * with that reason, and no other guard can force-allow what one denied.
     */
    guard(guard: (execution: {
        readonly name: string;
    }) => string | undefined): () => void;
    /**
     * One visible tool definition in a viewing scope. The scope is an opaque
     * `ScopeKey`; omitted views the global layer, which a deployment with a
     * preset roster leaves empty ({@link HostAgentPresets.standingKeyFor} supplies
     * the roster's).
     */
    get(name: string, scope?: unknown): HostToolDefinition | undefined;
    /**
     * Every tool visible in a viewing scope, with the description a reader
     * would need to tell them apart.
     *
     * This is the seam `/tools` reads, so a reader can answer "what can this
     * machine do" instead of only "what did someone switch off". The scope is
     * the same opaque key {@link HostTools.get} takes; omitted views the
     * global layer, which a deployment with a preset roster leaves empty.
     */
    schemas?(scope?: unknown): readonly {
        readonly name: string;
        readonly description?: string;
    }[];
}
/** The presentation half of a tool definition (subset of the host `ToolDefinition`). */
export interface HostToolDefinition {
    /**
     * Pure projection of one pending call for a UI. Every view variant carries a
     * `title`: a short, always-visible label describing what THIS call does,
     * which is what a log line or card header shows. Absent on tools that accept
     * the generic fallback (title = tool name).
     */
    presentCall?(args: unknown): {
        readonly title?: string;
        readonly kind?: string;
    } | undefined;
}
/** One command this deployment offers, from {@link HostCommands.list}. */
export interface HostCommandDescriptor {
    /** Lowercase name without the leading slash. */
    readonly name: string;
    /** Human-readable summary used in discovery surfaces. */
    readonly description: string;
}
/** One settled command execution (subset of the host `CommandExecution`). */
export interface HostCommandExecution {
    readonly result: {
        readonly kind: 'success';
        readonly text?: string;
    } | {
        readonly kind: 'error';
        readonly text: string;
    };
}
/**
 * The `commands` runtime: slash commands dispatched WITHOUT a model turn, which
 * is why a chat must route them here instead of letting the model read a literal
 * `/clear` as prose.
 */
export interface HostCommands {
    /** Commands available to one agent, for discovery. */
    list(agent: HostAgent): readonly HostCommandDescriptor[];
    /**
     * Run one complete slash-command line. Resolves `undefined` when the syntax
     * or the name does not resolve, which is what distinguishes an unknown
     * command from one that ran and failed.
     */
    execute(agent: HostAgent, line: string, submittedAttachments: readonly unknown[], signal: AbortSignal): Promise<HostCommandExecution | undefined>;
}
/** The `systemPrompt` assembler, as this plugin's per-agent composition uses it. */
export interface HostSystemPrompt {
    /**
     * Register one ordered prompt section in the calling context's scope layer.
     * Tool guidance uses orders 100–199; a duplicate name throws.
     */
    section(section: {
        name: string;
        order: number;
        text: string;
    }): () => void;
}
/**
 * The `agentPresets` roster (subset of the host `AgentPresets`). A deployment
 * that composes one keeps every model-facing row — tools, prompt sections — on
 * the agent plane, so the tool registry's global layer is EMPTY and an agent
 * that joins no preset reaches the model with no tools at all.
 */
export interface HostAgentPresets {
    /** The preset id mounted when a caller names none. */
    readonly defaultId: string;
    /**
     * Resolve a preset id, or the roster default when absent.
     * @throws when the roster supplies no such preset.
     */
    resolve(id?: string): Promise<{
        readonly id: string;
    }>;
    /**
     * Join one agent's scope to a preset's standing composition. Call from the
     * agent factory's `setup(agentCtx)`.
     */
    mount(agentCtx: Context, id?: string): Promise<unknown>;
    /**
     * The standing scope a reader with no agent resolves this preset's
     * registrations in — the view that holds its tools, since a roster keeps
     * every model-facing row off the global layer.
     *
     * dsh 0.1.7 renamed this from `standingKeyFor` and changed the return value:
     * the lease now carries the key plus an async `dispose`. Hold the lease for
     * as long as its scope is read; disposing it revokes the key.
     */
    acquireScope(id?: string): Promise<{
        readonly key: unknown;
    } & AsyncDisposable>;
    /** Every preset the configured roots currently supply, broken ones included. */
    list(): Promise<readonly {
        readonly id: string;
        readonly trust: 'system' | 'user';
        readonly name?: string;
        readonly description?: string;
        readonly broken?: string;
    }[]>;
    /**
     * The preset one live agent runs on, read from its scope chain.
     * @param agentCtx - the live agent's scoped context.
     * @returns the preset id, or undefined for a rosterless join.
     */
    composedPreset(agentCtx: Context): string | undefined;
    /**
     * Re-link one agent to a different preset's standing composition. Valid only
     * while the agent has produced nothing; the caller owns that check.
     * @throws when the id is unknown or the agent already produced.
     */
    recompose(agentCtx: Context, id: string): Promise<unknown>;
}
/** One workspace record (subset of the host `Workspace` entity). */
export interface HostWorkspace {
    readonly id: string;
    /** The record's canonical (realpath) directory. */
    readonly path: string;
    /**
     * Account one session under this workspace. Validates the session header's
     * cwd against {@link path}, so a session created with that exact value
     * attaches and one created with an uncanonicalized variant is rejected.
     */
    attachSession(id: string): Promise<unknown>;
}
/**
 * The `workspaceRegistry` service (subset of the host registry). Grouping is
 * accounted, not derived: a session whose cwd merely matches a workspace stays
 * Ungrouped until something attaches it.
 */
/** The `workspaceRegistry` service (subset of the host registry), extended with the synchronous `list()`. */
export interface HostWorkspaceRegistry {
    /** The record for a canonical path, or undefined when none is registered. */
    resolveByPath(path: string): Promise<HostWorkspace | undefined>;
    /** Register a workspace for a directory; at most one record exists per canonical path. */
    create(path: string, title?: string): Promise<HostWorkspace>;
    /** All registered workspaces in durable order (synchronous, cache-served). */
    list?(): readonly HostWorkspace[];
}
/** One Loader-tree entry as the chat inventory needs it (subset of Cordis's Loader). */
export interface HostLoaderEntry {
    /** The loader entry id from the composition (e.g. `feishu-channel`). */
    options: {
        readonly name?: string;
    };
    /** The module specifier that provided this plugin, when resolvable. */
    specifier?: string;
    /** Whether the entry was disabled by the composition. */
    disabled?: boolean;
    /** Live root fiber; undefined when not mounted (disabled or failed to load). */
    fiber?: {
        readonly state: number;
    } | undefined;
}
/** The `agentDefaultModel` service (subset of `AgentDefaultModelConfig`). */
export interface HostDefaultModel {
    /** The deployment's current default provider/model selection. */
    currentSelection(): HostAgentOptions;
    /**
     * Save a complete user selection (provider/model/reasoningEffort). A no-op
     * without a settings provider; with one, it persists across restarts.
     * Mirrors AgentDefaultModelConfig.saveSelection(selection).
     */
    saveSelection?(selection: HostAgentOptions): Promise<void>;
}
/** The Cordis loader service; awaited so agents never see a half-composed tree. */
export interface HostLoader {
    await(): Promise<unknown>;
    /**
     * The live plugin entries, as the loader sees them.
     *
     * This is the seam `/plugins` reads, so it belongs in the contract: an
     * inventory that silently becomes empty when the host changes is worse
     * than an inventory that reports itself unreachable.
     */
    entries?(): Iterable<unknown>;
}
/** One registered namespace's owner scope (subset of the host `SettingsScope`). */
export interface HostSettingsScope {
    /** The resolved value: schema defaults, then composition base, then the user document. */
    get(): unknown;
    /** Deep-merge a patch into the user section and persist it through the provider. */
    update(patch: object): Promise<unknown>;
}
/** The `settings` user-settings service (subset of `SettingsProvider`). */
export interface HostSettings {
    /**
     * Register a namespace schema; the registration is an effect on the calling
     * fiber. Duplicate namespaces and stored sections the schema rejects fail loud.
     */
    register(ns: string, schema: unknown, options?: {
        base?: unknown;
    }): HostSettingsScope;
}
/** One immutable entry in the host session log; narrowed via the guards below. */
export interface HostSessionEvent {
    readonly type: string;
    readonly data: unknown;
}
/** The `assistant/message` payload fields this plugin renders. */
export interface AssistantMessageData {
    readonly turn: number;
    readonly message: {
        readonly id: string;
        readonly content: readonly {
            readonly type: string;
            readonly text?: string;
        }[];
    };
}
/** The `turn/end` payload fields this plugin reports. */
export interface TurnEndData {
    readonly turn: number;
    readonly reason: {
        readonly kind: string;
        readonly error?: {
            readonly code?: string;
            readonly message?: string;
        };
    };
}
/** The `step/start` payload fields this plugin uses to warm a card up. */
export interface StepStartData {
    readonly turn: number;
    readonly step: number;
}
/** The `todo/write` payload: the agent's whole current list, replaced per call. */
export interface TodoWriteData {
    readonly todos: readonly {
        readonly content: string;
        readonly status: string;
    }[];
}
/** The `goal/change` payload: a whole-value goal snapshot mutation. */
export interface GoalChangeData {
    readonly version?: number;
    readonly operation: string;
    readonly goal?: {
        readonly objective: string;
        readonly phase: string;
        readonly blockedReason?: {
            readonly code?: string;
            readonly message?: string;
        };
        readonly maxGoalRounds?: number;
        readonly id?: string;
        readonly revision?: number;
    };
    /** Present on clear tombstone (no current goal) */
    readonly cleared?: {
        readonly id: string;
        readonly revision?: number;
    };
    readonly clearedAt?: number;
    readonly roundsStarted?: number;
    readonly createdAt?: number;
    readonly updatedAt?: number;
}
/** The `tool-workflow/run-start` payload: one top-level workflow run opens. */
export interface WorkflowRunStartData {
    readonly runId: string;
    readonly name: string;
}
/** The `tool-workflow/agent-start` payload: one workflow member is published. */
export interface WorkflowAgentStartData {
    readonly runId: string;
    readonly seq: number;
    readonly label: string;
    readonly phase?: string;
    readonly childId: string;
}
/** The `tool-workflow/agent-end` payload: one workflow member settles. */
export interface WorkflowAgentEndData {
    readonly runId: string;
    readonly seq: number;
    readonly outcome: 'completed' | 'failed' | 'cancelled';
}
/** The `tool-workflow/run-end` payload: one workflow run closes. */
export interface WorkflowRunEndData {
    readonly runId: string;
    readonly stopReason: 'completed' | 'cancelled' | 'error';
}
/** The `compaction/start` payload: a compaction locks the session log. */
export interface CompactionStartData {
    readonly compactionId: string;
    readonly turn: number | null;
}
/** The `compaction/end` payload: the lock releases (with an error when one occurred). */
export interface CompactionEndData {
    readonly compactionId: string;
    readonly turn: number | null;
    readonly error?: string;
}
/**
 * The `compaction/summary` payload: the summary text that replaced old
 * history, and what it cost. Emitted between `compaction/start` and
 * `compaction/end`; the bridge renders it so the chat sees what a compaction
 * actually produced instead of a silent gap after "正在压缩…".
 */
export interface CompactionSummaryData {
    readonly compactionId: string;
    /** The summary's content blocks (text blocks carry the visible summary). */
    readonly summary: readonly unknown[];
    readonly shadowedSeqs: readonly number[];
    /** Heuristic token price of the shadowed history, for the release line. */
    readonly shadowedTokenCount: number;
    readonly provider: string;
    readonly model: string;
}
/** The `compaction/prune` payload: a model-free trim of old history. */
export interface CompactionPruneData {
    readonly shadowedRange: {
        readonly start: number;
        readonly end: number;
    };
    readonly shadowedSeqs: readonly number[];
    readonly shadowedTokenCount: number;
}
/** The `subagent/descriptor` payload: one session-backed subagent child's durable identity. */
export interface SubagentDescriptorData {
    readonly version: number;
    readonly mode: 'one-shot' | 'continuable';
    readonly provider: string;
    readonly label?: string;
    readonly agentProvider?: string;
    readonly agentModel?: string;
}
/** The `schedule/change` payload: one durable schedule mutation. */
export interface ScheduleChangeData {
    readonly version: number;
    readonly operation: 'create' | 'delete' | 'dispatch';
    readonly schedule?: {
        readonly id: string;
        readonly kind: 'after' | 'at' | 'every';
        readonly prompt: string;
        readonly everySeconds?: number;
    };
    readonly id?: string;
}
/** One active schedule as the bridge tracks it from schedule/change events. */
export interface ScheduleEntry {
    readonly id: string;
    readonly kind: 'after' | 'at' | 'every';
    readonly prompt: string;
    readonly everySeconds?: number;
    /** Unix epoch milliseconds when the bridge saw the create. */
    readonly createdAt: number;
}
/** Per-session operation counters accumulated for `/audit`. */
/** Cordis `agent/status` payload: lifecycle of one live agent. */
export interface AgentStatusData {
    readonly agent: {
        readonly id: string;
    };
    readonly status: 'idle' | 'running';
}
/** Cordis `subagent/start|end` payloads (provider-agnostic). */
export interface SubagentStartData {
    readonly runId: string;
    readonly provider: string;
    readonly id: string;
    readonly local: boolean;
}
export interface SubagentEndData extends SubagentStartData {
    readonly stopReason: 'completed' | 'aborted' | 'error' | 'max-tokens';
    readonly lastAssistantMessage?: readonly unknown[];
}
/** Cordis `workflow/*` run identity carried by every live workflow event. */
export interface WorkflowRunInfoData {
    readonly id: string;
    readonly meta: unknown;
}
export interface AuditStats {
    /** Unix epoch milliseconds when the bridge first saw this session. */
    readonly startedAt: number;
    turns: number;
    steps: number;
    toolCalls: number;
    /** Turns that closed with an error reason. */
    turnErrors: number;
    compactions: number;
    retries: number;
    subagents: number;
    workflows: number;
    schedules: number;
}
/** The `web/deepseek-search-llm-request` payload: one DeepSeek search request was made. */
export interface WebSearchRequestData {
    readonly request?: unknown;
}
/** The `llm/retry` payload: one retry of a failed model call is scheduled. */
export interface LlmRetryData {
    readonly retryId: string;
    readonly turn: number;
    readonly step: number;
    readonly provider: string;
    readonly retry: number;
    readonly maxRetries?: number;
    readonly delayMs?: number;
    readonly failure?: {
        readonly name?: string;
        readonly message?: string;
    };
}
/** The `assistant/chunk` payload fields this plugin streams. */
export interface AssistantChunkData {
    readonly turn: number;
    /**
     * One raw stream chunk. `text-delta` / `reasoning-delta` stream token-wise;
     * `block-end` carries a complete block (a text or reasoning paragraph) when
     * the adapter delivers whole blocks instead of deltas — pi-ai's deepseek
     * route emits `block-end` with `block: { type: 'reasoning', text }` and no
     * reasoning-delta events in between.
     */
    readonly chunk: {
        readonly type: string;
        readonly text?: string;
        readonly block?: {
            readonly type: string;
            readonly text?: string;
        };
    };
}
/** The `tool/result` payload fields a thinking process reports. */
export interface ToolResultData {
    readonly turn: number;
    readonly message: {
        /** The producing call, so a result pairs with the call that asked. */
        readonly source?: {
            readonly callId?: string;
        };
        /**
         * The tool message's model-facing blocks.
         *
         * The host sends these flat: a text block carries its `text` beside its
         * `type`, not inside a nested list. An older host nested them one level
         * deeper, so both shapes are read.
         */
        readonly content: readonly {
            readonly type: string;
            readonly toolCallId?: string;
            /** The block's text, when it carries one. */
            readonly text?: string;
            /** Nested model-facing blocks; the older host's shape. */
            readonly content?: readonly {
                readonly type: string;
                readonly text?: string;
            }[];
        }[];
    };
    readonly error?: {
        readonly name: string;
        readonly code: string;
    };
}
/** The `tool/call` payload fields this plugin surfaces as activity. */
export interface ToolCallData {
    readonly turn: number;
    /** Pairs the call with the approval question that decides it. */
    readonly callId: string;
    readonly name: string;
    /** Raw arguments JSON exactly as the model produced it (unparsed, untrusted). */
    readonly arguments: string;
}
/**
 * Narrow a session event to the assembled assistant message for one step.
 * @param event - any session event.
 * @returns whether `event.data` carries {@link AssistantMessageData}.
 */
export declare function isAssistantMessageEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: AssistantMessageData;
};
/**
 * Narrow a session event to a closed turn boundary.
 * @param event - any session event.
 * @returns whether `event.data` carries {@link TurnEndData}.
 */
export declare function isTurnEndEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: TurnEndData;
};
/**
 * Narrow a session event to the opening of one step.
 * @param event - any session event.
 * @returns whether `event.data` carries {@link StepStartData}.
 */
export declare function isStepStartEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: StepStartData;
};
/**
 * Narrow a session event to one todo-list replacement.
 * @param event - any session event.
 * @returns whether `event.data` carries {@link TodoWriteData}.
 */
export declare function isTodoWriteEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: TodoWriteData;
};
/**
 * Narrow a session event to one goal snapshot mutation.
 * @param event - any session event.
 * @returns whether `event.data` carries {@link GoalChangeData}.
 */
export declare function isGoalChangeEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: GoalChangeData;
};
/** Narrow a session event to one workflow run opening. */
export declare function isWorkflowRunStartEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: WorkflowRunStartData;
};
/** Narrow a session event to one workflow member publication. */
export declare function isWorkflowAgentStartEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: WorkflowAgentStartData;
};
/** Narrow a session event to one workflow member settlement. */
export declare function isWorkflowAgentEndEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: WorkflowAgentEndData;
};
/** Narrow a session event to one workflow run closing. */
export declare function isWorkflowRunEndEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: WorkflowRunEndData;
};
/** Narrow a session event to a compaction lock opening. */
export declare function isCompactionStartEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: CompactionStartData;
};
/** Narrow a session event to a compaction lock releasing. */
export declare function isCompactionEndEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: CompactionEndData;
};
/** Narrow a session event to a compaction summary (what replaced old history). */
export declare function isCompactionSummaryEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: CompactionSummaryData;
};
/** Narrow a session event to a model-free prune of old history. */
export declare function isCompactionPruneEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: CompactionPruneData;
};
/** Narrow a session event to one subagent descriptor. */
/**
 * One file the model declared as a deliverable at the end of a turn.
 *
 * The path is what the model wrote; it can be absolute or relative to the
 * session's working directory. The description is the model's own caption
 * for the file.
 */
export interface PresentedFileData {
    readonly path: string;
    readonly description?: string;
}
/** The data carried by a `deliverables/presented` event. */
export interface PresentedEventData {
    readonly turn: number;
    readonly callId: string;
    readonly files: readonly PresentedFileData[];
}
/**
 * Whether the event declares files the model wants delivered.
 *
 * The guard checks the shape, not just the name: a host that emits the
 * event with a different payload should leave the bridge's delivery path
 * closed rather than deliver something it cannot read.
 */
export declare function isPresentedEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: PresentedEventData;
};
export declare function isSubagentDescriptorEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: SubagentDescriptorData;
};
/**
 * Cordis `subagent/catalog` payload: the DURABLE child record appended to the
 * PARENT session (`subagent/src/catalog.ts` establishCatalogChild). This is the
 * only subagent event a parent-session subscriber can rely on in 0.1.5 —
 * `subagent/descriptor` is appended inside the child's own session by the
 * in-process driver, so wiring a chat panel to it produces a feature that
 * silently never appears (2026-09-15).
 */
export interface SubagentCatalogData {
    readonly version: number;
    /** The child's own session id — the stable key for per-child bookkeeping. */
    readonly childId: string;
    readonly childCreatedAt: number;
    readonly mode: 'one-shot' | 'continuable';
    readonly label?: string;
}
export declare function isSubagentCatalogEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: SubagentCatalogData;
};
/** Narrow a session event to one schedule mutation. */
export declare function isScheduleChangeEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: ScheduleChangeData;
};
/** Narrow a session event to one DeepSeek search request. */
export declare function isWebSearchRequestEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: WebSearchRequestData;
};
/** Narrow a session event to one scheduled model-call retry. */
export declare function isLlmRetryEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: LlmRetryData;
};
/**
 * Narrow a session event to one raw assistant stream chunk.
 * @param event - any session event.
 * @returns whether `event.data` carries {@link AssistantChunkData}.
 */
/**
 * Narrow a Cordis event to agent lifecycle status.
 */
export declare function isAssistantChunkEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: AssistantChunkData;
};
/**
 * Narrow a session event to one completed tool call's result.
 * @param event - any session event.
 * @returns whether `event.data` carries {@link ToolResultData}.
 */
export declare function isToolResultEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: ToolResultData;
};
/**
 * The call one result answers, and the text it produced.
 * @param data - the completed result payload.
 * @returns the call id and its joined text output.
 */
export declare function toolResultText(data: ToolResultData): {
    callId: string | undefined;
    text: string;
};
/**
 * Narrow a session event to one model-requested tool invocation.
 * @param event - any session event.
 * @returns whether `event.data` carries {@link ToolCallData}.
 */
export declare function isToolCallEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: ToolCallData;
};
/**
 * Join the text blocks of a committed assistant message.
 * @param data - the committed message payload.
 * @returns the concatenated text, empty when the step produced none.
 */
export declare function assistantText(data: AssistantMessageData): string;
/**
 * Render a failed turn's reason as one operator-readable line.
 * @param data - the closed turn payload.
 * @returns the error detail, empty when the turn did not fail.
 */
export declare function turnErrorDetail(data: TurnEndData): string;
/** Closed outcome of a host approval question; `'allowed-once'` is the only grant. */
export type HostApprovalOutcome = 'allowed-once' | 'rejected' | 'cancelled' | 'unavailable';
/** Readonly same-process permission question (subset of `ApprovalRequest`). */
export interface HostApprovalRequest {
    /** The agent on whose behalf the question is asked; routes the question. */
    readonly agent: HostAgent;
    /** The tool the question is about (presentation and audit). */
    readonly toolName: string;
    /** The exact tool call being decided, when the asker has one. */
    readonly callId?: string;
    /** The asker's human-readable explanation of WHY it is asking. */
    readonly reason?: string;
    /** Aborting withdraws the question; a late answer is discarded. */
    readonly signal?: AbortSignal;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The host agent registry; required via `inject`. */
        agents: HostAgentRegistry;
    }
    interface Events {
        /** Durable session facts broadcast by the host session store. */
        'session/event'(session: HostSession, event: HostSessionEvent): void;
        /** Waterfall permission question; answer only for owned agents, else delegate via `next()`. */
        'approval/request'(request: HostApprovalRequest, next: () => Promise<HostApprovalOutcome>): Promise<HostApprovalOutcome>;
        /** Live subagent settlement, scoped to the delegating agent. */
        'subagent/end'(info: SubagentEndData): void;
        /** Live workflow run narration (two-argument Cordis events). */
        'workflow/log'(info: WorkflowRunInfoData, message: string): void;
        'workflow/phase'(info: WorkflowRunInfoData, title: string): void;
    }
}
/** One cross-session search hit (subset of the host `SessionSearchHit`). */
export interface HostSessionQueryHit {
    /**
     * The matched session's header.
     *
     * A search hit is a session record, and the record carries the header one
     * level down — the same shape the persistence store returns.
     */
    readonly header: {
        readonly id: string;
        readonly createdAt?: number;
    };
    readonly bestMatch: {
        readonly snippet: string;
    };
}
/**
 * The `sessionQuery` service (subset of the host `SessionQuery`), consumed by
 * `/sessions <keyword>` when the deployment composes a search backend.
 */
export interface HostSessionQuery {
    searchSessions(request: {
        readonly query: string;
        readonly limit?: number;
        readonly signal?: AbortSignal;
    }): Promise<{
        readonly items: readonly HostSessionQueryHit[];
    }>;
}
/** A read-only job projection (subset of the host `JobSnapshot`). */
export interface HostJobSnapshot {
    readonly id: string;
    readonly kind: string;
    readonly label: string;
    readonly status: 'running' | 'stopping' | 'completed' | 'killed' | 'failed';
    readonly detail?: string;
    readonly startedAt: number;
    /**
     * The output ring's coordinates. The projection deliberately carries no
     * text — a reader pulls bytes with `readAt` from `earliest` up to `total`.
     */
    readonly output?: {
        readonly total: number;
        readonly earliest: number;
    };
}
/** One chunk of a job's output ring (subset of the host `JobChunk`). */
export interface HostJobChunk {
    readonly at: number;
    readonly text: string;
}
/** Result of one non-consuming `JobRegistry.readAt`. */
export interface HostJobOutputRead {
    readonly chunks: readonly HostJobChunk[];
    readonly next: number;
    readonly lossy: boolean;
}
/** Completion listener shape of `JobRegistry.onJobDone`. */
export type HostJobDoneListener = (snapshot: HostJobSnapshot, owner: {
    readonly id: string;
} | undefined) => void | PromiseLike<void>;
/** The `jobs` registry (subset of the host `JobRegistry`), per-agent scoped. */
/** A job lifecycle event (subset of the host `JobEvent`). */
export type HostJobEvent = {
    readonly type: 'settled';
    readonly job: HostJobSnapshot;
    /** Whether this settlement already reached a live `wait()` caller. */
    readonly awaited: boolean;
} | {
    readonly type: 'registered' | 'started' | 'chunk' | 'progress';
    readonly job: HostJobSnapshot;
};
/** The registry's event stream (subset of the host `JobEvents`). */
export interface HostJobEvents {
    subscribe(filter: {
        readonly owners?: 'scope' | 'all';
    }, listener: (event: HostJobEvent) => void): () => void;
}
export interface HostJobs {
    /**
     * Lifecycle and output events, filtered per subscription.
     *
     * dsh 0.1.7 replaced the former `onJobDone(listener)` with this stream: a
     * job's terminal state arrives as a `settled` event whose `awaited` flag
     * tells a reporter whether a live `wait()` already delivered it.
     */
    readonly events: HostJobEvents;
    /** List caller-owned and unowned jobs in registration order. */
    list(caller?: string): readonly HostJobSnapshot[];
    /**
     * Read retained ring output WITHOUT moving the model's cursor.
     *
     * This is the read a completion notice wants: `read()` consumes the ring and
     * advances the cursor the agent pulls from, so a notice using it would steal
     * output the agent still expects to see. `readAt` only observes.
     *
     * @param id - job to read.
     * @param from - absolute byte offset (0, or the projection's `earliest`).
     * @param caller - reading session, checked against the job's owner.
     */
    readAt(id: string, from: number, caller?: string): HostJobOutputRead;
}
/** The `messageFeedback` service (subset of the host `MessageFeedback`). */
export interface HostMessageFeedback {
    put(request: {
        readonly sessionId: string;
        readonly messageId: string;
        readonly rating: 'positive' | 'negative';
        readonly note?: string;
        readonly ifVersion: unknown;
    }): Promise<{
        readonly ok: boolean;
        readonly error?: {
            readonly code: string;
        };
    }>;
}
/**
 * The `tokenMeter` service (subset of the host `TokenMeter`).
 *
 * The upstream signature is `measure(session: Session, requestHeader?)`: the
 * meter replays the session's own event log to price the context, so it
 * needs the session object — its `seq` and `eventAt()`. Handing it the id
 * alone makes the replay loop read nothing, and the meter then reports zero
 * tokens for every session without raising, so the context-pressure
 * warning never fires.
 */
export interface HostTokenMeter {
    measure(session: HostSession): {
        readonly totalTokens: number;
        readonly surfaceTokens: number;
    };
}
/** One skill's invocation-neutral summary, as the skill registry lists it. */
export interface HostSkillSummary {
    /** Kebab-case identifier used to address the skill. */
    readonly name: string;
    /** Short routing description shown by discovery consumers. */
    readonly description: string;
    /** Optional extra routing guidance. */
    readonly whenToUse?: string;
    /** Discovery source that produced this winning skill. */
    readonly source: string;
    /** Provider that owns this skill body. */
    readonly provider: string;
}
/** The `skills` registry (subset of the host `SkillRegistry`). */
export interface HostSkills {
    /** List invocation-neutral skill summaries for a workspace. */
    list(): Promise<HostSkillSummary[]>;
    /** Load a full skill by name; `undefined` when absent or invalid. */
    /**
     * One skill's body, as the host returns it.
     *
     * The host names the field `content`; reading `body` off the result
     * reads `undefined`, and trimming that throws.
     */
    get(name: string): Promise<{
        readonly content: string;
    } | undefined>;
}
/**
 * A team member, as the host records it.
 *
 * The shapes mirror the host's `agent-team` package, which versions every
 * team event at 2. They are declared here rather than imported so the
 * bridge stays independent of the host's package layout.
 */
export interface TeamMemberSnapshot {
    /** The member's session id. */
    readonly id: string;
    /** The member's name in the team. */
    readonly name: string;
    /** What the member is for. */
    readonly description: string;
    /** The model provider the member runs on. */
    readonly provider: string;
    /** Whether the member joined fresh or forked from the lead. */
    readonly context: 'fresh' | 'fork';
    /** Where the member is in its lifecycle. */
    readonly phase: 'provisioning' | 'active' | 'failed';
    /** Why the member failed, when it did. */
    readonly error?: string;
}
/** A shared task, as the host records it. */
export interface TeamTaskSnapshot {
    /** The task's id. */
    readonly id: string;
    /** The revision the host last wrote. */
    readonly revision: number;
    /** The task's one-line subject. */
    readonly subject: string;
    /** The task's detail. */
    readonly description: string;
    /** Where the task is. */
    readonly status: 'pending' | 'in_progress' | 'completed' | 'deleted';
    /** The member that owns the task. */
    readonly ownerId?: string;
    /** The tasks this one waits for. */
    readonly blockedBy: string[];
    /** The write scopes the task claims. */
    readonly writeScopes: string[];
}
/** A mailbox message, as the host records it. */
export interface TeamMessageSnapshot {
    /** The message's id. */
    readonly id: string;
    /** The member that sent it. */
    readonly senderId: string;
    /** The member's name at the time it was sent. */
    readonly senderName: string;
    /** The member it was addressed to. */
    readonly targetId: string;
    /** The message body, as content blocks. */
    readonly content: readonly {
        readonly type?: string;
        readonly text?: string;
    }[];
}
/** The payload of a `team/member` event. */
export interface TeamMemberEventData {
    readonly version: 2;
    readonly teamId: string;
    readonly member: TeamMemberSnapshot;
}
/** The payload of a `team/task` event. */
export interface TeamTaskEventData {
    readonly version: 2;
    readonly teamId: string;
    readonly task: TeamTaskSnapshot;
}
/** The payload of a `team/message/queued` event. */
export interface TeamMessageEventData {
    readonly version: 2;
    readonly teamId: string;
    readonly message: TeamMessageSnapshot;
}
/** The payload of a `team/message/delivered` event. */
export interface TeamMessageDeliveredEventData {
    readonly version: 2;
    readonly teamId: string;
    readonly messageId: string;
    readonly targetId: string;
}
/**
 * Whether an event carries a team member.
 *
 * The version is checked, not just the name: a payload that does not carry
 * version 2 is another shape, and rendering it as a member would show fields
 * that are not there.
 * @param event - the session event.
 * @returns true when the event is a `team/member` event.
 */
export declare function isTeamMemberEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: TeamMemberEventData;
};
/**
 * Whether an event carries a shared team task.
 * @param event - the session event.
 * @returns true when the event is a `team/task` event.
 */
export declare function isTeamTaskEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: TeamTaskEventData;
};
/**
 * Whether an event carries a queued mailbox message.
 * @param event - the session event.
 * @returns true when the event is a `team/message/queued` event.
 */
export declare function isTeamMessageEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: TeamMessageEventData;
};
/**
 * Whether an event acknowledges a queued mailbox message.
 * @param event - the session event.
 * @returns true when the event is a `team/message/delivered` event.
 */
export declare function isTeamMessageDeliveredEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: TeamMessageDeliveredEventData;
};
/**
 * A message that came from another agent in a team.
 *
 * The team package does not record a mailbox event when a member messages
 * another; it steers the message into the target's inbox, and it lands there
 * as a `user/message` whose source says who sent it. The mailbox events
 * (`team/message/queued` and `team/message/delivered`) are historical
 * records the host reads but never writes.
 */
export interface TeamRelayMessageData {
    readonly message: {
        readonly id: string;
        readonly content: readonly {
            readonly type: string;
            readonly text?: string;
        }[];
        readonly source: {
            readonly kind: string;
            readonly form?: string;
            readonly senderSessionId?: string;
        };
    };
}
/**
 * Narrow a session event to a message relayed from a teammate.
 *
 * @param event - any session event.
 * @returns whether the event is a `user/message` a teammate sent.
 */
export declare function isTeamRelayMessageEvent(event: HostSessionEvent): event is HostSessionEvent & {
    readonly data: TeamRelayMessageData;
};
//# sourceMappingURL=host.d.ts.map