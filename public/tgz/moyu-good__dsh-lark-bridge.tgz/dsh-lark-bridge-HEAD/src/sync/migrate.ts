/**
 * Device migration — moving a bridge installation (Feishu credentials, shared
 * settings, per-profile plugin lists) from one machine to another. The
 * export is a constructed JSON document, so the live state that must never
 * travel (peer heartbeats, rotating control tokens, lock files,
 * node_modules) is excluded by construction rather than by filtering. See
 * docs/design/设计卡_设备迁移与多机.md.
 * @module dsh-lark-bridge/sync/migrate
 */

import os from 'node:os'
import path from 'node:path'
import fsp from 'node:fs/promises'
import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import type { SharedSettings } from './settings-store.ts'
import { maskSecret, readSettings, syncDir } from './settings-store.ts'
import type { ProfileManifest } from './profile-manifest.ts'
import { readProfileManifest } from './profile-manifest.ts'
import type { SyncPlan, InstallStep } from './plugin-sync.ts'

/** Identifies a well-formed migration document. */
export const MIGRATION_KIND = 'dsh-lark-bridge-migration'
/** Bump when the document shape changes; import rejects anything else. */
export const MIGRATION_VERSION = 1

/** Settings keys that are credentials and get masked by default. */
export const SECRET_KEYS = ['appSecret'] as const

/** The migration document itself. */
export interface MigrationFile {
  kind: typeof MIGRATION_KIND
  version: typeof MIGRATION_VERSION
  exportedAt: string
  from: { profile: string; form: string; host: string }
  settings: SharedSettings
  /** Plugin lists per profile: installed packages + active bundles. */
  profiles: Record<string, { dependencies: Record<string, string>; bundles: string[] }>
  notes?: Record<string, string>
}

export interface ExportOptions {
  /** Include credentials verbatim instead of masked (default: masked). */
  includeSecrets?: boolean
  /** Extra profiles to capture beyond the one this instance runs under. */
  profiles?: readonly string[]
}

/** One profile's plugin list, narrowed for travel. */
export interface TraveledProfile {
  dependencies: Record<string, string>
  bundles: string[]
}

/** Collect the export document from live local state. */
export async function buildMigration(
  home: string | undefined,
  harnessHome: string,
  profile: string,
  form: 'web' | 'desktop',
  options?: ExportOptions,
): Promise<MigrationFile> {
  const settings = await readSettings(home)
  const traveled: SharedSettings = {}
  for (const [key, value] of Object.entries(settings)) {
    const isSecret = (SECRET_KEYS as readonly string[]).includes(key)
    traveled[key as keyof SharedSettings] =
      isSecret && !options?.includeSecrets ? maskSecret(value) : value
  }
  const wanted = [profile, ...(options?.profiles ?? []).filter((p) => p !== profile)]
  const profiles: Record<string, TraveledProfile> = {}
  for (const name of wanted) {
    const manifest = await readProfileManifest(harnessHome, name)
    profiles[name] = manifest === null
      ? { dependencies: {}, bundles: [] }
      : { dependencies: manifest.dependencies, bundles: manifest.bundles }
  }
  return {
    kind: MIGRATION_KIND,
    version: MIGRATION_VERSION,
    exportedAt: new Date().toISOString(),
    from: { profile, form, host: os.hostname() },
    settings: traveled,
    profiles,
    notes: {
      hint: 'sessions live under ~/.dsh (upstream-owned); copy that directory to carry them — this file intentionally excludes live state (peers, tokens, node_modules)',
    },
  }
}

/** Absolute path of the default landing file for migrations. */
export function migrationFilePath(home?: string): string {
  return path.join(syncDir(home), 'migrate.json')
}

/**
 * Resolve the file to import: no argument means the default landing file;
 * an argument must be a bare file name inside the sync directory — path
 * traversal would turn a chat command into an arbitrary file read.
 */
export function resolveMigrationFile(name: string | undefined, home?: string): string {
  const dir = syncDir(home)
  if (name === undefined || name === '') return path.join(dir, 'migrate.json')
  if (name.includes('/') || name.includes('\\') || name === '.' || name === '..' || path.basename(name) !== name) {
    throw new Error(`非法文件名 \`${name}\`——只允许 sync 目录内的裸文件名`)
  }
  return path.join(dir, name)
}

/** Parse and validate an untrusted document. Throws with a readable reason. */
export function validateMigration(parsed: unknown): MigrationFile {
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error('迁移文件不是 JSON 对象')
  }
  const doc = parsed as Record<string, unknown>
  if (doc.kind !== MIGRATION_KIND) throw new Error(`kind 不是 \`${MIGRATION_KIND}\`——这不是桥的迁移文件`)
  if (doc.version !== MIGRATION_VERSION) throw new Error(`版本 ${String(doc.version)} 不受支持（当前 ${MIGRATION_VERSION}）`)
  const from = doc.from as MigrationFile['from'] | undefined
  if (from === undefined || typeof from.host !== 'string') throw new Error('缺 from.host')
  if (typeof doc.exportedAt !== 'string') throw new Error('缺 exportedAt')
  if (doc.settings === null || typeof doc.settings !== 'object' || Array.isArray(doc.settings)) {
    throw new Error('settings 段缺失或形状不对')
  }
  if (doc.profiles === null || typeof doc.profiles !== 'object' || Array.isArray(doc.profiles)) {
    throw new Error('profiles 段缺失或形状不对')
  }
  return doc as unknown as MigrationFile
}

/** Read + validate a migration document from the sync directory. */
export async function readMigration(name: string | undefined, home?: string): Promise<MigrationFile> {
  const file = resolveMigrationFile(name, home)
  let raw: string
  try {
    raw = await fsp.readFile(file, 'utf8')
  } catch {
    throw new Error(`读不到迁移文件 \`${file}\`——先把旧机 /bot export 的产物放进来`)
  }
  let parsed: unknown
  try {
    parsed = JSON.parse(raw)
  } catch {
    throw new Error('迁移文件不是合法 JSON')
  }
  return validateMigration(parsed)
}

/**
 * Plan what importing `imported` means for the local `profile`: packages
 * missing locally (or pinned to another version) become `add` steps through
 * the upstream CLI; anything already present stays untouched. Reuses the
 * plugin-sync plan/apply pipeline so semantics never fork.
 */
export function buildImportPlan(
  local: ProfileManifest | null,
  profile: string,
  imported: TraveledProfile,
): SyncPlan {
  const steps: InstallStep[] = []
  for (const [name, spec] of Object.entries(imported.dependencies)) {
    if (local?.dependencies[name] === spec) continue
    const pinned = spec.includes('@', 1) ? spec : `${name}@${spec}`
    steps.push({
      kind: 'add',
      profile,
      spec: pinned,
      command: `dsh plugin --profile ${profile} add ${pinned}`,
    })
  }
  return { steps, inSync: Object.keys(local?.dependencies ?? {})
    .filter((name) => imported.dependencies[name] !== undefined
      && !steps.some((step) => step.spec.startsWith(`${name}@`))) }
}

/**
 * The cross-host reminder text, or null when importing on the same machine.
 * Same-Feishu-app double delivery is the one migration mistake that bites
 * immediately and confusingly, so the import reply always carries it.
 */
export function crossHostWarning(file: MigrationFile): string | null {
  if (file.from.host === os.hostname()) return null
  return `⚠️ 此文件来自 **${file.from.host}**。若旧机的桥仍在运行，请先停掉它——同一个飞书 appId 两台机器同时连接会导致消息双投递、双回复。`
}

// ── Device state: per-machine, deliberately NOT in the shared settings ──
// A retired flag synced to the other end would retire the new machine too;
// only the retiring machine may mark itself down.

/** Local device lifecycle state. */
export interface DeviceState {
  retired?: boolean
  retiredAt?: string
  activatedAt?: string
  note?: string
  /** Stable per-machine identity, minted on first use. */
  deviceId?: string
  /** Human-readable name (defaults to hostname, settable via `/bot name`). */
  deviceName?: string
  /**
   * Digest of this machine's own identifiers, used to notice that a copied
   * state file landed on a different machine.
   *
   * A digest, never the raw identifier: the file is per-machine local state
   * and may be copied around, and the identifier itself is not needed by
   * anyone else.
   */
  machineFingerprint?: string
  /**
   * The digest this machine was first recorded under, when that digest was
   * computed differently (it used to include the hostname). Kept so a
   * device recorded under the old rule is still recognised as this machine
   * after the rule changed, instead of being treated as a copy.
   */
  machineFingerprintLegacy?: string
}

const DEVICE_STATE_NAME = 'device-state.json'

/** Absolute path of this machine's device-state file. */
export function deviceStateFile(home?: string): string {
  return path.join(syncDir(home), DEVICE_STATE_NAME)
}

/** Read this machine's device state, or `{}` when absent/corrupt. */
export async function readDeviceState(home?: string): Promise<DeviceState> {
  try {
    const parsed = JSON.parse(await fsp.readFile(deviceStateFile(home), 'utf8')) as unknown
    if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) return {}
    return parsed as DeviceState
  } catch {
    return {}
  }
}

/** Persist this machine's device state. */
export async function writeDeviceState(state: DeviceState, home?: string): Promise<void> {
  const file = deviceStateFile(home)
  await fsp.mkdir(path.dirname(file), { recursive: true })
  await fsp.writeFile(file, `${JSON.stringify(state, null, 2)}\n`, 'utf8')
}

/**
 * This machine's stable identity, minted into device-state.json on first
 * use. Hostname and pid are NOT identity (both drift); a device keeps its id
 * across restarts and form switches, and a NEW machine mints its own — the
 * file never travels with a migration (only per-machine state lives there).
 */
/** Options for {@link ensureDeviceId}. */
export interface EnsureDeviceIdOptions {
  /**
   * The machine digest to compare against, overriding the one read from the
   * host. Tests pass a value so they can play both machines.
   */
  fingerprint?: string
}

/**
 * A digest of this machine's own identifiers.
 *
 * Only identifiers that survive a rename belong here. The hostname does
 * not: a host that gets renamed — a WSL distribution, a container, a cloud
 * instance — would otherwise look like a different machine, and the check
 * that follows would re-mint this device's identity and clear the retired
 * flag that an operator set on purpose. The stable sources are the machine
 * id on Linux (both the systemd one and the dbus one) and the machine guid
 * on Windows.
 *
 * A host with none of those is identified by its hostname, and by nothing
 * else: two such hosts that share a name are indistinguishable, which the
 * caller has to know when it reads the digest.
 * @returns a hex digest, or undefined when the host offers no identifier.
 */
export function machineFingerprint(): string | undefined {
  const stable: string[] = []
  for (const file of ['/etc/machine-id', '/var/lib/dbus/machine-id']) {
    try {
      const value = readFileSync(file, 'utf8').trim()
      if (value !== '') stable.push(value)
    } catch {
      // Not this host's kind of identifier.
    }
  }
  if (stable.length > 0) {
    return createHash('sha256').update(stable.join('\u0000')).digest('hex').slice(0, 32)
  }
  const host = os.hostname()
  if (host === '') return undefined
  return createHash('sha256').update(`hostname\u0000${host}`).digest('hex').slice(0, 32)
}

/**
 * The digest the fingerprint used to be: the machine id AND the hostname.
 *
 * It was wrong — a rename changed the digest — but the state file on disk
 * may still carry it, and a device that was recorded under the old digest
 * is the very same device. A state whose digest matches this one is the
 * same machine, so it keeps its identity and its retired flag.
 * @returns a hex digest, or undefined when the host offers no identifier.
 */
export function legacyMachineFingerprint(): string | undefined {
  const parts: string[] = []
  try {
    parts.push(readFileSync('/etc/machine-id', 'utf8').trim())
  } catch {
    // A host without machine-id falls back to the hostname below.
  }
  parts.push(os.hostname())
  if (parts.every(part => part === '')) return undefined
  return createHash('sha256').update(parts.join('\u0000')).digest('hex').slice(0, 32)
}

/**
 * This machine's stable identity, minted into device-state.json on first
 * use. Hostname and pid are NOT identity (both drift); a device keeps its id
 * across restarts and form switches, and a NEW machine mints its own — the
 * file never travels with a migration (only per-machine state lives there).
 *
 * A copied state file is the one way that promise breaks, so the state
 * carries a digest of the machine it was minted on. When the digest does not
 * match, the file belongs to another machine: the identity is re-minted and
 * the retired flag goes with it, because a retirement belongs to the machine
 * that asked for it.
 * @param home - the sync home; defaults to this machine's.
 * @param options - an explicit fingerprint, for tests.
 * @returns the identity this machine answers with.
 */
export async function ensureDeviceId(
  home?: string,
  options: EnsureDeviceIdOptions = {},
): Promise<{ deviceId: string; deviceName: string }> {
  const state = await readDeviceState(home)
  const fingerprint = options.fingerprint ?? machineFingerprint()
  const legacy = options.fingerprint === undefined
    ? legacyMachineFingerprint()
    : undefined
  const deviceName = state.deviceName ?? os.hostname()
  // A state without a digest predates the check: keep the identity, and
  // record the digest so the next start can compare.
  //
  // A digest that was computed the old way — the one that folded the
  // hostname in — still names THIS machine, so a state carrying it is not
  // a copy. That is the difference between a rule change and a machine
  // change, and treating it as a machine change would re-mint the identity
  // and clear a retirement an operator set on purpose.
  const recorded = state.machineFingerprint
  const recordedLegacy = state.machineFingerprintLegacy
  // Either slot naming this machine under either rule is enough.
  const matchesCurrent = fingerprint !== undefined
    && (recorded === fingerprint || recordedLegacy === fingerprint)
  const matchesLegacy = legacy !== undefined
    && (recorded === legacy || recordedLegacy === legacy)
  const sameMachine = matchesCurrent || matchesLegacy
  const arrivedFromAnotherMachine = recorded !== undefined
    && fingerprint !== undefined
    && !sameMachine
  if (state.deviceId !== undefined && !arrivedFromAnotherMachine) {
    const patch: DeviceState = { ...state }
    if (fingerprint !== undefined) {
      if (recorded === undefined) {
        // A state without a digest predates the check: keep the identity
        // and record the digest so the next start can compare.
        patch.machineFingerprint = fingerprint
      } else if (recorded !== fingerprint) {
        // The state was recorded under the old rule, which folded the
        // hostname in. The new digest replaces it — a rename must not
        // change this machine's identity — and the old one is kept beside
        // it, so the next start recognises this machine either way.
        patch.machineFingerprint = fingerprint
        if (patch.machineFingerprintLegacy === undefined) {
          patch.machineFingerprintLegacy = recorded
        }
      }
    }
    if (patch.machineFingerprintLegacy === undefined && legacy !== undefined
      && legacy !== patch.machineFingerprint) {
      patch.machineFingerprintLegacy = legacy
    }
    if (state.machineFingerprint !== patch.machineFingerprint
      || state.machineFingerprintLegacy !== patch.machineFingerprintLegacy) {
      await writeDeviceState(patch, home)
    }
    return { deviceId: state.deviceId, deviceName }
  }
  const deviceId = `dev-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
  const next: DeviceState = { ...state, deviceId, deviceName }
  if (fingerprint !== undefined) next.machineFingerprint = fingerprint
  if (legacy !== undefined && legacy !== fingerprint) next.machineFingerprintLegacy = legacy
  // The retired flag came from the other machine: it said nothing about
  // this one, and honouring it would silence a fresh machine.
  delete next.retired
  delete next.retiredAt
  await writeDeviceState(next, home)
  return { deviceId, deviceName }
}

/** Patch device state in place, preserving unknown/identity fields. */
export async function patchDeviceState(patch: DeviceState, home?: string): Promise<DeviceState> {
  const next = { ...(await readDeviceState(home)), ...patch }
  await writeDeviceState(next, home)
  return next
}
