/**
 * First-contact guide: when a brand-new chat session is created, send a short
 * guide so a user who has never seen this bot knows what it is, what it can
 * do, and what its permission posture is. Existing sessions (resumed across
 * restarts) never get a second copy — the message fires only on `create`,
 * not on `resume`.
 *
 * The guide is written from real first-use failures: a user who typed
 * `/permission` with no argument saw a list and thought it was a menu to
 * answer, and a user who never clicked an approval card watched the bot hang
 * waiting for it. Both are covered explicitly below.
 * @module dsh-lark-bridge/first-contact
 */

import { pricingHumanLine } from './pricing.ts'

/** The sandbox/permission mode the deployment runs under. */
export type PermissionPosture = 'workspace-write' | 'danger-full-access' | 'read-only' | string

/**
 * Derive the permission posture from the same environment knob dsh-base reads
 * (`DSH_PERMISSION_MODE`, default `workspace-write`), so the guide always
 * matches what the session actually enforces.
 * @param env - process environment (injectable for tests).
 * @returns the posture name, defaulting to `workspace-write`.
 */
export function permissionPosture(env: NodeJS.ProcessEnv = process.env): PermissionPosture {
  return env.DSH_PERMISSION_MODE ?? 'workspace-write'
}

/**
 * One sentence describing what the current posture means to the human in the
 * chat.
 */
export function postureLine(posture: PermissionPosture): string {
  switch (posture) {
    case 'danger-full-access':
      return '全自动模式：命令直接执行，不再逐条确认。它和你拥有同等文件权限，请只在你信任的环境使用。'
    case 'read-only':
      return '只读模式：不会修改任何文件，但读取范围仍限工作区。'
    case 'workspace-write':
      return '工作区模式：工作区内可写，工作区外的操作会弹卡片请你确认。'
    default:
      return `当前权限模式：${posture}。`
  }
}

/**
 * The commands every user needs on day one, with the exact invocation that
 * works. Written to prevent the two real first-use failures: `/permission`
 * without an argument (a status line, not a menu) and an unclicked approval
 * card (the bot waits on it forever).
 */
export function commandGuide(posture: PermissionPosture): string {
  const lines = [
    '常用命令：',
    '- `/help` 查看全部命令 · `/manual` 完整使用说明',
    '- `/stop` 停止当前任务（卡住时用它）',
    '- `/plan` 先出计划再执行',
    '- `/permission <模式>` 切换权限：`read-only` / `workspace-write` / `danger-full-access`（注意：**不带参数只显示当前状态，不是选项菜单，不要等它让你选**）',
    '',
    '审批卡片：',
    '- 如果出现**卡片**（权限确认），点卡片上的按钮即可，不点它会一直等',
    '- 如果只是**一段文字**列了几个选项（如 "available: a, b, c"），那不是菜单——直接在输入框发对应的命令，例如 `/permission danger-full-access`',
  ]
  if (posture === 'danger-full-access') {
    lines.splice(4, 0, '- 当前已是全自动模式（danger-full-access），命令不再逐条确认。')
  }
  return lines.join('\n')
}

/**
 * Render the first-contact guide for a brand-new session.
 * @param posture - the deployment's permission posture.
 * @param identity - optional leading clause naming the bot as Feishu names it
 *   (e.g. `「MyBot」（本端：web · web）`), so the very first line answers
 *   "who — and which endpoint of it — am I talking to".
 * @returns the markdown message to send into the chat.
 */
export function onboardingText(posture: PermissionPosture, identity?: string): string {
  const head = identity === undefined
    ? '**你好，我是跑在飞书里的编码智能体（DeepSeek Harness）。**'
    : `**你好，我是飞书上的${identity}，一个跑在 DeepSeek Harness 里的编码智能体。**`
  return [
    head,
    '',
    '直接说你要做的事，我会调用工具（终端/文件/搜索等）去完成。',
    '',
    `权限：${postureLine(posture)}`,
    '',
    commandGuide(posture),
    '',
    pricingHumanLine(),
    '',
    '开始吧——发一句话试试。',
  ].join('\n')
}

/** The first-contact message, as a plain object for `port.send({ markdown })`. */
export function onboardingMessage(
  env: NodeJS.ProcessEnv = process.env,
  identity?: string,
): { markdown: string } {
  return { markdown: onboardingText(permissionPosture(env), identity) }
}
