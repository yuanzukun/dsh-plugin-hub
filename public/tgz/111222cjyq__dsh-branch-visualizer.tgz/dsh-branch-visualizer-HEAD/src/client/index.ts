/**
 * dsh-branch-visualizer — client 装配层（入口）。
 *
 * 拆分说明（2026-08）：原单文件 client/index.ts（~1100 行）按职责拆分——
 *   - index.ts   本文件：apply 装配、state 状态机、HeaderButton/BrvisBridge、槽位注册、样式注入
 *   - layout.ts  纯函数：树布局 / 连线计算 / 尺寸常量
 *   - api.ts     RPC：同源 fetch → host /brvis/api
 *   - styles.ts  全部画布 CSS
 *   - canvas.tsx 画布主组件与工具栏（工厂注入 ctx/timer/state）
 * 出错定位：滚动条错乱→layout.ts；网络/契约问题→api.ts；画布交互→canvas.tsx；样式→styles.ts。
 *
 * 类型说明（TYPECHECK-04）：本文件是装配层，state 最小形状见 makeCanvas 依赖；
 * ctx/slots 为 DSH 运行时注入，用按需最小接口 + 局部断言。
 */
import * as React from 'react'
import { makeCanvas } from './canvas.js'
import { BRVIS_CSS } from './styles.js'
import type { CanvasNode, NodePos } from './canvas-interactions.js'
import { createDshClientServices, DSH_CLIENT_SLOTS } from '../platform/adapters/dsh-preview-2026-08/client.js'

// REV-03（2026-08-18）同步：本文件已并入 tsconfig include，tsc 现在类型检查全部 client。
// OPEN-03（2026-08-18 修订）：`inject` 收敛为最小硬依赖集 `['slots']` ——
// 依据 DSH 官方插件开发规范（cordis-plugin-development skill）：
//   "Declare inject only when a Service is a hard dependency and the Plugin must
//    enter waiting until Cordis reactivates it. Do not overuse inject merely to
//    avoid an undefined check."
// slots = 入口硬依赖（无 UI 即无插件）；sessions/timer 均为运行时可选服务
// （由 client adapter 提供 sessions/timer/workspaces），
// 代码已有 undefined 降级路径 → 不声明，避免缺服务时装配进入 waiting。
// 旧声明 ['slots','sessions','timer'] 过宽（2026-08-18 前版本）。
export const inject = ['slots']

const e = React.createElement

/** slots 服务最小形状（注册入口组件与画布容器）。 */
interface SlotsService {
  inject(entry: string, factory: () => () => void): () => void
  register(
    entry: { name: string; id: string; order?: number; label: () => string },
    render: (props: Record<string, unknown>) => React.ReactElement | null,
  ): () => void
}

/** apply ctx 最小形状。 */
interface ApplyCtx {
  get(name: string): unknown
  effect(fn: () => () => void): unknown
}

/** 会话 store 返回的最小形状（useSessions selector 结果）。 */
interface SessionsStore {
  current?: unknown
  byId?: Record<string, { cwd?: string }>
}

/** 画布视图形状。 */
interface ViewShape { x: number; y: number; zoom: number }

/** 画布状态机（apply 闭包单例，Canvas 组件经 makeCanvas 注入读取）。 */
interface BrvisStateSingleton {
  open: boolean
  currentSessionId: string | null
  selectedIds: Set<string>
  mode: number
  showArchived: boolean
  nodes: CanvasNode[]
  positions: Map<string, NodePos>
  circlePositions: Map<string, NodePos>
  view: ViewShape
  viewScale: number
  listeners: Set<() => void>
  emit(): void
  subscribe(fn: () => void): () => void
  set(partial: Record<string, unknown>): void
}

export function apply(ctx: ApplyCtx) {
    const platform = createDshClientServices(ctx)
    const slots = platform.slots as SlotsService | undefined
    const timer = platform.timer
    if (slots === undefined) return

    // ============ 画布状态机（模块内单例，HeaderButton/BrvisBridge/Canvas 共享） ============
    const state: BrvisStateSingleton = {
      open: false,
      currentSessionId: null,
      selectedIds: new Set(),
      mode: 1,
      // OPEN-01（2026-08-18）：默认"隐藏归档"，兑现 ARCH-03「归档优先不显示，点开才加入」。
      // 旧值 true 会让首载走 includeArchived=true 全量重建（实测 45 节点/44 归档工作区 20.5s），
      // 撞上 10s 快照超时 → 面板打开即「加载失败」= 用户感知"打不开"。
      showArchived: false,
      nodes: [],
      positions: new Map(),
      circlePositions: new Map(),
      view: { x: 60, y: 60, zoom: 1 },
      viewScale: 1,
      listeners: new Set<() => void>(),
      emit() { for (const fn of this.listeners) fn() },
      subscribe(fn: () => void) { this.listeners.add(fn); return () => { this.listeners.delete(fn) } },
      set(partial: Record<string, unknown>) { Object.assign(this, partial); this.emit() },
    }

    function useBrvisState() {
      const [, force] = React.useState(0)
      React.useEffect(() => state.subscribe(() => force((x) => x + 1)), [])
    }

    // ============ 槽位 UI ============

    // REACT-01（2026-08）：槽位 Hook 生命周期重构，文档 §10 正确结构。
    // 入口组件（*Entry）零 Hook：props 探测帧（无 useSessions）→ 直接 null，不挂子组件（hook 数 0 恒定）。
    // 探测到 useSessions 是函数后才挂载稳定 Hook 子组件（*WithSessions，hook 数恒定）。
    // 彻底移除 NO_SESSIONS 普通函数伪装（旧方案同组件真假 props 切换 hook 数 → React #300）。

    function HeaderButtonEntry(props: Record<string, unknown>): React.ReactElement | null {
      if (typeof props?.useSessions !== 'function') return null
      return e(HeaderButtonWithSessions, { sessionId: props.sessionId as string | undefined, useSessions: props.useSessions as (selector: (st: SessionsStore) => unknown) => unknown })
    }

    function HeaderButtonWithSessions({ sessionId, useSessions }: {
      sessionId?: string
      useSessions: (selector: (st: SessionsStore) => unknown) => unknown
    }): React.ReactElement {
      useBrvisState()
      let current: string | undefined = sessionId
      try {
        const s = useSessions((st: SessionsStore) => st.current)
        if (s) current = s as string
      } catch (e) { /* store 读取失败以 sessionId 兜底 */ }
      return e('button', {
        className: 'brvis-toggle' + (state.open ? ' is-active' : ''),
        onClick: () => { state.set({ open: !state.open, currentSessionId: current || null, selectedIds: new Set() }) },
        title: '分支可视化画布',
      }, '◈ 分支图')
    }

    function BridgeEntry(props: Record<string, unknown>): React.ReactElement | null {
      if (typeof props?.useSessions !== 'function') return null
      return e(BridgeWithSessions, { sessionId: props.sessionId as string | undefined, useSessions: props.useSessions as (selector: (st: SessionsStore) => unknown) => unknown })
    }

    function BridgeWithSessions({ sessionId, useSessions }: {
      sessionId?: string
      useSessions: (selector: (st: SessionsStore) => unknown) => unknown
    }): React.ReactElement | null {
      useBrvisState()
      let currentId: string | null = state.currentSessionId || sessionId || null
      let cwd = ''
      try {
        const cur = useSessions((st: SessionsStore) => st.current)
        if (cur) currentId = cur as string
      } catch (e) { /* ignore */ }
      // 7.3（2026-08-18）审查结论：旧动态版 src/client.js 的 FullCanvasBridge 用
      // `props.useWorkspaces` 反查工作区 path，bundle 版此分支被静默删除且无记录。
      // 复核结论——**保持现状是正确选择**，不作为缺陷整改，原因：
      //  1) DSH 槽位 props 契约只注入 useSessions（HeaderButtonEntry/BridgeEntry 探测
      //     即以此为准，见行 115/137）；useWorkspaces hook 在本部署不存在
      //     （client 侧服务目录仅 layout/locale/sessions/slots/theme/timer/workspaces，
      //     workspaces 是命令式服务无 sessionId→path 反查方法）。
      //  2) cwd 读不到时 path='' → 画布按工作区空键降级展示全部会话（host snapshot
      //     空键路径），不会报错；真机环境 useSessions 正常返回 cwd。
      // 故不新增 useWorkspaces 分支，避免凭空假设不存在的运行时契约。
      try {
        const c = useSessions((st: SessionsStore) => {
          const cur2 = st.current as string | undefined
          if (!cur2) return undefined
          const byId = st.byId || {}
          const rec = byId[cur2]
          return rec ? rec.cwd : undefined
        })
        if (c) cwd = c as string
      } catch (e) { /* ignore */ }
      if (!state.open) return null
      return e(Canvas, { sessionId: currentId, path: cwd || '' })
    }

    // ============ 画布组件（工厂注入运行时依赖） ============
    const { Canvas } = makeCanvas(platform, timer, state, useBrvisState)

    // ============ 槽位注册 ============
    const overlayDisposer = slots.inject(DSH_CLIENT_SLOTS.overlay, () => slots.register({ name: DSH_CLIENT_SLOTS.overlay, id: 'brvis-canvas', order: 100, label: () => '分支图' }, (props) => e(BridgeEntry, props)))
    const toggleDisposer = slots.inject(DSH_CLIENT_SLOTS.sessionUtilities, () => slots.register({ name: DSH_CLIENT_SLOTS.sessionUtilities, id: 'brvis-toggle', order: 60, label: () => '分支图' }, (props) => e(HeaderButtonEntry, props)))
    ctx.effect(() => () => { overlayDisposer(); toggleDisposer() })

    // ============ 样式注入 ============
    // ⚠️ 不能走 window.__xxx 全局间接触发：ModuleLoader 打包会树摇掉本地定义
    //（2026-08 实测：failed to apply loader entry — window.__BRVIS_INSERT_STYLES__ is not a function）。
    // 必须在 apply() 作用域内定义局部函数并直接调用，同文件引用者即定义者。
    // N2（2026-08-18）审查结论：手动 createElement('style') 而非 ctx.styles/内建注入是
    // 唯一可行方案——复验 client Service 目录（layout/locale/sessions/slots/theme/timer/
    // workspaces），**没有 styles 服务**，无内建样式注入可用（文档 §4.2-N2）。
    const insertStyles = (cssText: string): (() => void) => {
      const tag = document.createElement('style')
      tag.dataset.plugin = 'dsh-brvis'
      tag.dataset.pluginCss = 'dsh-branch-visualizer/styles'
      tag.textContent = cssText
      if (document.head) document.head.appendChild(tag)
      return () => { if (tag.parentNode) tag.parentNode.removeChild(tag) }
    }
    const disposeStyles = insertStyles(BRVIS_CSS)
    ctx.effect(() => disposeStyles)
}
