/**
 * dsh-brvis — 画布几何纯函数（拆分自 canvas.tsx，2026-08）。
 * 无 React/DOM/副作用：命中检测、框选相交、边锚点、视图适配。
 * 出错只需读本文件 + layout.ts；canvas.tsx 只调这些函数并注入 state/ref。
 */
import { NODE_W, NODE_H, CIRCLE_D } from './layout.js'

const HIT_PAD = 6

export interface Point { x: number; y: number }
// AUD-01（2026-08-18）：ViewState 不再携带 viewScale——state.view 从来没有这个字段
//（viewScale 是 state 上的独立字段），可选字段只诱导误用。有效缩放一律显式传 curEz。
export interface ViewState { x: number; y: number; zoom: number }
export interface GeometryNode { id: string }

/**
 * 屏幕坐标命中检测：返回命中的节点 id（null = 未命中）。rect 为 .brvis-body 的 bounding rect。
 * curEz = 渲染有效缩放（zoom * viewScale），由调用方从 cur.ez 显式传入（AUD-01：
 * 旧实现读 view.viewScale 恒 undefined → 窄面板 viewScale<1 时命中坐标系与渲染不一致）。
 */
export function hitNodeById(ev: { clientX: number; clientY: number }, nodes: GeometryNode[], pos: Map<string, Point>, circleMode: boolean, view: ViewState, rect: { left: number; top: number }, curEz: number): string | null {
  const vx = view.x
  const vy = view.y
  const nw = circleMode ? CIRCLE_D : NODE_W
  const nh = circleMode ? CIRCLE_D : NODE_H
  const px = ev.clientX - rect.left
  const py = ev.clientY - rect.top
  for (const n of nodes) {
    const p = pos.get(n.id)
    if (!p) continue
    const nl = p.x * curEz + vx - HIT_PAD
    const nt = p.y * curEz + vy - HIT_PAD
    if (px >= nl && px <= nl + nw * curEz + HIT_PAD * 2 && py >= nt && py <= nt + nh * curEz + HIT_PAD * 2) return n.id
  }
  return null
}

/** 框选相交：返回与屏幕矩形 (x0,y0,w,h) 相交的全部节点 id。 */
export function intersectNodes(x0: number, y0: number, w: number, h: number, nodes: GeometryNode[], pos: Map<string, Point>, nodeW: number, nodeH: number, curEz: number, vx: number, vy: number): string[] {
  const hitIds: string[] = []
  for (const n of nodes) {
    const p = pos.get(n.id)
    if (!p) continue
    const nLeft = p.x * curEz + vx
    const nTop = p.y * curEz + vy
    const nRight = nLeft + nodeW * curEz
    const nBottom = nTop + nodeH * curEz
    if (!(x0 > nRight || x0 + w < nLeft || y0 > nBottom || y0 + h < nTop)) hitIds.push(n.id)
  }
  return hitIds
}

/** 锚点结果（含外法线方向，曲线控制点用）。 */
export interface Anchor {
  x: number
  y: number
  nx: number
  ny: number
}

/**
 * 边锚点：两节点中心连线方向与各自边框的交点。
 * 拖动时锚点沿边框滑动，指向始终清晰。circleMode 用圆边界。
 */
export function hitAnchor(cx: number, cy: number, dx: number, dy: number, nodeW: number, nodeH: number, circleMode: boolean): Anchor {
  if (circleMode) {
    const r = nodeW / 2
    return { x: cx + dx * r, y: cy + dy * r, nx: dx, ny: dy }
  }
  const hw = nodeW / 2
  const hh = nodeH / 2
  const tx = dx !== 0 ? hw / Math.abs(dx) : Infinity
  const ty = dy !== 0 ? hh / Math.abs(dy) : Infinity
  if (tx < ty) {
    // 命中竖边:法线水平朝外
    return { x: cx + dx * tx, y: cy + dy * tx, nx: dx > 0 ? 1 : -1, ny: 0 }
  }
  // 命中横边:法线垂直朝外
  return { x: cx + dx * ty, y: cy + dy * ty, nx: 0, ny: dy > 0 ? 1 : -1 }
}

/** 视图适配：把节点包围盒中心对齐到视口中心，返回新的 view.x/y。 */
export function fitViewCenter(rectW: number, rectH: number, map: Map<string, Point>, z: number): { x: number; y: number } {
  if (!map || map.size === 0) return { x: 0, y: 0 }
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity
  for (const p of map.values()) {
    if (p.x < minX) minX = p.x
    if (p.x > maxX) maxX = p.x
    if (p.y < minY) minY = p.y
    if (p.y > maxY) maxY = p.y
  }
  const cx = (minX + maxX) / 2
  const cy = (minY + maxY) / 2
  return { x: rectW / 2 - cx * z, y: rectH / 2 - cy * z }
}