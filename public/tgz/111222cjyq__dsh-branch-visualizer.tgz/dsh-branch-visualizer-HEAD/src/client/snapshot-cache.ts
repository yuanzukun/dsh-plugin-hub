/**
 * 画布快照双变体缓存。
 *
 * `visible` 与 `archived` 必须独立保留：隐藏归档时仍可用精简快照轮询，
 * 但不能覆盖已经付出高成本加载的含归档快照。再次显示先同步恢复旧快照，
 * 网络请求只负责后台校准（stale-while-revalidate）。
 */

import type { CanvasNode } from './canvas-interactions.js'

export interface CachedCanvasSnapshot {
  path: string
  nodes: CanvasNode[]
  signature: string
  generatedAt: number
}

export interface CanvasSnapshotVariants {
  visible?: CachedCanvasSnapshot
  archived?: CachedCanvasSnapshot
}

export function canvasSnapshotSignature(nodes: readonly CanvasNode[]): string {
  return nodes.map((node) =>
    node.id + '|' + node.title + '|' + (node.parentId || '') + '|' +
    (node.parentArchivedBridge ? 1 : 0) + '|' + (node.archived ? 1 : 0) + '|' +
    (node.subagent ? 1 : 0) + '|' + (node.status || 'cold') + '|' +
    (node.createdAt || 0),
  ).join('\n')
}

export function readCanvasSnapshot(
  variants: CanvasSnapshotVariants,
  path: string,
  includeArchived: boolean,
): CachedCanvasSnapshot | null {
  const entry = includeArchived ? variants.archived : variants.visible
  return entry?.path === path ? entry : null
}

export function writeCanvasSnapshot(
  variants: CanvasSnapshotVariants,
  path: string,
  includeArchived: boolean,
  nodes: CanvasNode[],
  generatedAt = Date.now(),
): CachedCanvasSnapshot {
  const entry: CachedCanvasSnapshot = {
    path,
    nodes,
    signature: canvasSnapshotSignature(nodes),
    generatedAt,
  }
  if (includeArchived) variants.archived = entry
  else variants.visible = entry
  return entry
}
