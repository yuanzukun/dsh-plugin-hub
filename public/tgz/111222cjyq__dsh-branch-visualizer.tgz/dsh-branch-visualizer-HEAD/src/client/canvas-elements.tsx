/**
 * dsh-brvis — 画布元素构建（纯展示，拆分自 canvas.tsx，2026-08）。
 * 只负责把 state 数据渲染成 React 元素：节点/边/改名输入/归档按钮/工具栏/状态栏。
 * 不持有 refs/效果/事件状态——所有回调由调用方传入。出错只看本文件 + geometries/layout。
 * 类型说明（TYPECHECK-02）：本文件是展示层，props 均传入自 canvas.tsx 的已校验数据；
 * 事件处理用最小签名（React 事件对象 OR 提取字段），不依赖 DSH 自定义类型。
 */

// TYPECHECK-02: 节点最小形状（画布节点所需字段，来自 host 快照；status 可能缺省）
export interface CanvasNodeLite {
  id: string
  title?: string
  parentId?: string | null
  parentArchivedBridge?: boolean
  archived?: boolean
  subagent?: boolean
  status?: string
}

/** 边最小形状（layout 输出）。 */
export interface EdgeLite {
  from: string
  to: string
  dashed?: boolean
  doubleDashed?: boolean
}

/** 锚点（canvas-geometry 输出）。 */
export interface AnchorLite {
  x: number
  y: number
  nx: number
  ny: number
}
import * as React from 'react'
import { NODE_W, NODE_H, CIRCLE_D } from './layout.js'
import { hitAnchor } from './canvas-geometry.js'

const e = React.createElement

/** 工具栏按钮（无状态展示件）。 */
export function ToolButton({ onClick, active, children, title, disabled }: {
  onClick?: () => void
  active?: boolean
  children?: React.ReactNode
  title?: string
  disabled?: boolean
}): React.ReactElement {
  return e('button', {
    className: 'brvis-tb' + (active ? ' is-active' : ''),
    onClick,
    title: title || '',
    disabled: !!disabled,
  }, children)
}

/** 构建全部边元素（含双虚线旁路两条 path）。 */
export function buildEdgeElements(
  edges: EdgeLite[],
  pos: Map<string, { x: number; y: number }>,
  nodeW: number,
  nodeH: number,
  circleMode: boolean,
  currentSessionId: string | null,
  byId: Map<string, unknown>,
): React.ReactElement[] {
  const out: React.ReactElement[] = []
  for (const ed of edges) {
    const a = pos.get(ed.from)
    const b = pos.get(ed.to)
    if (!a || !b) continue
    // 隐藏归档时,端点为归档节点的边不渲染(双虚线跳过线的两端都是可见节点,正常显示)
    if (!byId.has(ed.from) || !byId.has(ed.to)) continue
    // 锚点:两节点中心连线方向与各自边框的交点,拖动时锚点沿边框滑动,指向始终清晰
    const acx = a.x + nodeW / 2
    const acy = a.y + nodeH / 2
    const bcx = b.x + nodeW / 2
    const bcy = b.y + nodeH / 2
    const vx = bcx - acx
    const vy = bcy - acy
    const dist = Math.sqrt(vx * vx + vy * vy) || 1
    const ux = vx / dist
    const uy = vy / dist
    const p1 = hitAnchor(acx, acy, ux, uy, nodeW, nodeH, circleMode)
    const p2 = hitAnchor(bcx, bcy, -ux, -uy, nodeW, nodeH, circleMode)
    // 曲线控制点:沿锚点所在边的法线方向外延,标准 org-chart 圆滑 S 曲线,任意角度拖动都圆润
    const bend = Math.max(44, Math.min(120, dist * 0.55))
    const c1x = p1.x + p1.nx * bend
    const c1y = p1.y + p1.ny * bend
    const c2x = p2.x + p2.nx * bend
    const c2y = p2.y + p2.ny * bend
    const d = 'M ' + p1.x + ' ' + p1.y + ' C ' + c1x + ' ' + c1y + ', ' + c2x + ' ' + c2y + ', ' + p2.x + ' ' + p2.y
    const isCur = ed.to === currentSessionId || ed.from === currentSessionId
    const markerId = ed.dashed ? '-dash' : (isCur ? '-cur' : '')
    if (ed.doubleDashed) {
      // 双虚线:跳过被归档的中间节点,父↔子直接相连(两条错位虚线叠加)
      // 路径与单线 d 相同(同一组锚点/控制点),直接复用 d
      out.push(e('path', {
        key: ed.from + '=>' + ed.to + ':dd1',
        d: d,
        className: 'brvis-edge is-double-dash is-double-1',
        fill: 'none',
      }))
      out.push(e('path', {
        key: ed.from + '=>' + ed.to + ':dd2',
        d: d,
        className: 'brvis-edge is-double-dash is-double-2',
        markerEnd: 'url(#brvis-arrow-dash)',
        fill: 'none',
      }))
    } else {
      out.push(e('path', {
        key: ed.from + '->' + ed.to + (ed.dashed ? ':d' : '') + (isCur ? ':c' : ''),
        d,
        className: 'brvis-edge' + (ed.dashed ? ' is-dashed' : '') + (isCur ? ' is-current-edge' : ''),
        markerEnd: 'url(#brvis-arrow' + markerId + ')',
        fill: 'none',
      }))
    }
  }
  return out
}

/** 构建全部节点元素。fallbackRect:节点缺位置时的兜底视口（用于首次渲染居中）。viewX/viewY 为当前视图偏移。 */
export function buildNodeElements({ nodes, pos, nodeW, nodeH, circleMode, currentSessionId, selectedIds, ez, viewX, viewY, onDoubleJump, fallbackRect }: {
  nodes: CanvasNodeLite[]
  pos: Map<string, { x: number; y: number }>
  nodeW: number
  nodeH: number
  circleMode: boolean
  currentSessionId: string | null
  selectedIds: Set<string>
  ez: number
  viewX: number
  viewY: number
  onDoubleJump: (id: string) => void
  fallbackRect: { width: number; height: number } | null
}): React.ReactElement[] {
  const out: React.ReactElement[] = []
  for (const n of nodes) {
    let p = pos.get(n.id)
    if (!p) {
      const rect = fallbackRect || { width: 600, height: 400 }
      const z = ez || 1
      p = { x: (rect.width / 2 - (viewX != null ? viewX : 0)) / z - nodeW / 2, y: (rect.height / 2 - (viewY != null ? viewY : 0)) / z - nodeH / 2 }
    }
    const isCurrent = n.id === currentSessionId
    const isSelected = selectedIds.has(n.id)
    const isSub = !!n.subagent
    const statusCls = n.status === 'running' ? ' is-running' : (n.status === 'idle' ? ' is-idle' : '')
    const statusSuffix = n.status === 'running' ? ' (运行中)' : (n.status === 'idle' ? ' (空闲)' : '')
    if (circleMode) {
      const cls = 'brvis-circle-node' +
        (isCurrent ? ' is-current' : '') +
        (isSelected ? ' is-selected' : '') +
        (n.archived ? ' is-archived' : '') +
        (isSub ? ' is-subagent' : '') +
        statusCls
      out.push(e('div', {
        key: n.id,
        className: cls,
        style: { left: p.x, top: p.y, width: CIRCLE_D, height: CIRCLE_D },
        onDoubleClick: (ev: React.MouseEvent<HTMLDivElement>) => { ev.stopPropagation(); onDoubleJump(n.id) },
        title: n.title + (isSub ? ' (子代理)' : '') + statusSuffix + ' (双击打开)',
      },
        e('div', { className: 'brvis-circle-core' }),
        n.status === 'running' ? e('div', { className: 'brvis-active-pulse' }) : null,
        n.status === 'idle' ? e('div', { className: 'brvis-active-dot' }) : null,
      ))
    } else {
      const cls = 'brvis-node' +
        (isCurrent ? ' is-current' : '') +
        (isSelected ? ' is-selected' : '') +
        (n.archived ? ' is-archived' : '') +
        (isSub ? ' is-subagent' : '') +
        statusCls
      out.push(e('div', {
        key: n.id,
        className: cls,
        style: { left: p.x, top: p.y, width: NODE_W, height: NODE_H },
        onPointerDown: (ev: React.PointerEvent<HTMLDivElement>) => {
          // 单击选中动画:按下微放大+亮起(transition 自动回退,不依赖 timer)
          ev.currentTarget.classList.add('is-clicked')
        },
        onPointerUp: (ev: React.PointerEvent<HTMLDivElement>) => { ev.currentTarget.classList.remove('is-clicked') },
        onPointerCancel: (ev: React.PointerEvent<HTMLDivElement>) => { ev.currentTarget.classList.remove('is-clicked') },
        onDoubleClick: (ev: React.MouseEvent<HTMLDivElement>) => { ev.stopPropagation(); onDoubleJump(n.id) },
        title: n.title + (isSub ? ' (子代理)' : '') + statusSuffix,
      },
        e('div', { className: 'brvis-node-title' },
          n.archived ? e('span', { className: 'brvis-arch-badge' }, '归档') : null,
          isSub ? e('span', { className: 'brvis-sub-badge' }, '子代理') : null,
          n.title),
        e('div', { className: 'brvis-node-sub' },
          isCurrent ? e('span', { className: 'brvis-current-dot' }, '● 当前会话') :
          (n.archived ? '已归档' : (isSub ? '子代理分支' : (n.parentId ? '分支' : '根会话')))),
        n.status === 'running' ? e('div', { className: 'brvis-active-pulse', title: '运行中' }) : null,
        n.status === 'idle' ? e('div', { className: 'brvis-active-dot', title: '空闲' }) : null,
      ))
    }
  }
  return out
}

/** 改名输入浮层。 */
export function buildRenameElement({ renamingId, byId, pos, nodeH, value, onChange, onCommit, onCancel }: {
  renamingId: string | null
  byId: Map<string, unknown>
  pos: Map<string, { x: number; y: number }>
  nodeH: number
  value: string
  onChange: (v: string) => void
  onCommit: () => void
  onCancel: () => void
}): React.ReactElement | null {
  if (!renamingId) return null
  const n = byId.get(renamingId)
  const p = pos.get(renamingId)
  if (!n) return null
  const baseY = p ? p.y : 0
  return e('div', { className: 'brvis-rename', style: { left: p ? p.x : 0, top: baseY + nodeH + 6, width: NODE_W + 20 } },
    e('input', {
      autoFocus: true,
      value,
      onChange: (ev: React.ChangeEvent<HTMLInputElement>) => onChange(ev.target.value),
      onPointerDown: (ev) => ev.stopPropagation(),
      onKeyDown: (ev) => {
        if (ev.key === 'Enter') onCommit()
        if (ev.key === 'Escape') onCancel()
      },
      onBlur: onCommit,
    }))
}

/** 归档按钮（两步确认）。 */
export function buildArchiveButton({ confirmArchive, selectedCount, pending, onRequest, onConfirm, onCancel }: {
  confirmArchive: boolean
  selectedCount: number
  pending: boolean
  onRequest: () => void
  onConfirm: () => void
  onCancel: () => void
}): React.ReactElement {
  if (confirmArchive) {
    return e('span', { className: 'brvis-archive-confirm' },
      e(ToolButton, { onClick: onConfirm, title: '确认归档选中节点;归档后从默认视图隐藏,当前插件不提供恢复入口' }, '确认归档'),
      e(ToolButton, { onClick: onCancel, title: '取消归档' }, '取消'),
    )
  }
  return e(ToolButton, { onClick: onRequest, title: '归档选中的节点(多选批量)(防误触,需二次确认)', disabled: selectedCount === 0 || pending }, '归档')
}

/** 工具栏处理器形状。 */
export interface ToolbarHandlers {
  pathName: string
  onTitlePointerDown: (ev: React.PointerEvent<Element>) => void
  onTitlePointerMove: (ev: React.PointerEvent<Element>) => void
  onTitlePointerUp: (ev: React.PointerEvent<Element>) => void
  onMode: (m: number) => void
  onZoomIn: () => void
  onZoomOut: () => void
  onRelayout: () => void
  onRename: () => void
  renameDisabled: boolean
  onResetPanel: () => void
  archiveButton: React.ReactElement
  onToggleArchived: () => void
  onClose: () => void
}

/** 工具栏（含模式/缩放/布局/改名/归档/显隐/关闭）。 */
export function buildToolbar({ compact, state, handlers }: {
  compact: boolean
  state: { mode: number; showArchived: boolean }
  handlers: ToolbarHandlers
}): React.ReactElement {
  return e('div', {
    className: 'brvis-toolbar' + (compact ? ' is-compact' : ''),
    onPointerDown: handlers.onTitlePointerDown,
    onPointerMove: handlers.onTitlePointerMove,
    onPointerUp: handlers.onTitlePointerUp,
    title: '拖动标题文字移动悬浮窗',
  },
    e('div', { className: 'brvis-toolbar-title' }, '◈ ' + (handlers.pathName || '分支图')),
    !compact ? e('div', { className: 'brvis-toolbar-group' },
      e(ToolButton, { active: state.mode === 1, onClick: () => handlers.onMode(1), title: '归档模式1:涉及归档节点的连线变虚线,整体形态保留' }, '模式1'),
      e(ToolButton, { active: state.mode === 2, onClick: () => handlers.onMode(2), title: '归档模式2:涉及归档节点的连线完全断开,子树独立' }, '模式2'),
    ) : null,
    e('div', { className: 'brvis-toolbar-spacer' }),
    !compact ? e('div', { className: 'brvis-toolbar-group' },
      e(ToolButton, { onClick: handlers.onZoomIn, title: '放大' }, '＋'),
      e(ToolButton, { onClick: handlers.onZoomOut, title: '缩小' }, '－'),
      e(ToolButton, { onClick: handlers.onRelayout, title: '重新布局' }, '↻'),
      e(ToolButton, { onClick: handlers.onRename, title: '重命名选中的节点(单选时可用)', disabled: handlers.renameDisabled }, '改名'),
    ) : null,
    e(ToolButton, { onClick: handlers.onResetPanel, title: '恢复默认位置与尺寸' }, '⤾'),
    handlers.archiveButton,
    e(ToolButton, { active: state.showArchived, onClick: handlers.onToggleArchived, title: '显示/隐藏归档节点' }, state.showArchived ? '隐藏归档' : '显示归档'),
    e(ToolButton, { onClick: handlers.onClose, title: '关闭' }, '✕'),
  )
}

/** 状态栏文本。 */
export function buildStatusLine({ loading, error, confirmArchive, compact, count, archivedLoading, archivedHydrating }: {
  loading: boolean
  error: string | null
  confirmArchive: boolean
  compact: boolean
  count: number
  /** OPEN-02：含归档的全量快照加载中——大工作区可能数十秒，把慢变成可预期反馈 */
  archivedLoading?: boolean
  /** ARCH-PERF-04：结构已显示，冷会话标题与子代理元数据仍在后台补齐。 */
  archivedHydrating?: boolean
}): React.ReactElement {
  if (loading) {
    if (archivedLoading) return e('div', { className: 'brvis-status is-warn' }, '正在加载全部会话（含归档），大工作区可能需要数十秒…')
    return e('div', { className: 'brvis-status' }, '加载中…')
  }
  if (error) return e('div', { className: 'brvis-status is-error' }, '错误: ' + error)
  if (confirmArchive) return e('div', { className: 'brvis-status is-warn' }, '再次点击「确认归档」执行,点击其他位置取消')
  if (archivedHydrating) return e('div', { className: 'brvis-status is-warn' }, count + ' 个会话 · 归档名称正在后台补齐，可继续浏览')
  if (compact) return e('div', { className: 'brvis-status' }, count + ' 会话 · 缩略树')
  return e('div', { className: 'brvis-status' }, count + ' 个会话 · 拖拽框选 / 空格或Alt+拖拽或滚轮平移 / Ctrl+滚轮或捏合缩放 / 拖动节点改位')
}
