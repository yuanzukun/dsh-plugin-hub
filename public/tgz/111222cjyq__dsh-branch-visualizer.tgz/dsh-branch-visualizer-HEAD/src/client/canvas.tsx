/**
 * dsh-brvis — 画布主组件（骨架）。
 * 拆分（2026-08）：
 *   - canvas.tsx            本文件：state/hooks/effects/组装（职责单一：组件生命周期与编排）
 *   - canvas-geometry.ts    纯函数：命中/框选/锚点/视图适配（无 React）
 *   - canvas-elements.tsx   纯展示：节点/边/改名/归档/工具栏/状态栏元素构建
 *   - canvas-interactions.ts 手势状态机 + 动作（拖拽/缩放/跳转/改名/归档）
 *   - layout.ts             布局/连线/尺寸常量（纯函数）
 *   - api.ts                RPC
 * 出错定位：布局错→layout；点不到→interactions；渲染错→elements；轮询/生命周期→本文件。
 * 注意：本组件内 React hook 次数无条件固定（React #300 教训）。
 */

// TYPECHECK-03：本文件是 React 渲染编排层，类型来自 canvas-interactions/canvas-elements 的
// 已导出接口 + React 内建类型；快照数据用最小形状（CanvasNode），状态对象用 BrvisStateLike。
import * as React from 'react'
import { NODE_W, NODE_H, SIB_GAP, LEVEL_GAP, CIRCLE_D, CIRCLE_SIB, CIRCLE_LEVEL, CIRCLE_ZOOM, COMPACT_W, BASE_W, clamp, layoutTree, computeEdges } from './layout.js'
import { fetchSnapshot } from './api.js'
import { createCanvasInteractions, type BrvisStateLike, type CanvasNode, type NodePos, type BrvisCurrent } from './canvas-interactions.js'
import { buildEdgeElements, buildNodeElements, buildRenameElement, buildArchiveButton, buildToolbar, buildStatusLine, type EdgeLite } from './canvas-elements.js'
import { readCanvasSnapshot, writeCanvasSnapshot, type CanvasSnapshotVariants } from './snapshot-cache.js'
import type { DshClientServices } from '../shared/dsh-contract.js'

/** selectBox 状态形状。 */
interface SelectBox { x: number; y: number; w: number; h: number }

/** panelSize 形状。 */
interface PanelSize { w: number; h: number }

/**
 * 工厂：把 apply 闭包持有的运行时依赖注入画布组件，
 * 画布内部只通过参数访问（不 import 单例、不读 window 全局）。
 */
export function makeCanvas(platform: DshClientServices, timer: unknown, state: BrvisStateLike, useBrvisState: () => void) {
  // apply 生命周期级缓存：关闭/重开画布或显隐切换都保留已付出高成本加载的变体。
  const snapshotVariants: CanvasSnapshotVariants = {}
  let archivedWarm: { path: string; controller: AbortController; promise: Promise<void> } | null = null
  // ⬇ 组件工厂内部返回 React 组件（每次 apply 调用创建独立实例）
  function Canvas({ sessionId, path }: { sessionId?: string | null; path?: string }) {
    const pathStr = path || ''
    useBrvisState()
    const [loading, setLoading] = React.useState(true)
    const [archivedHydrating, setArchivedHydrating] = React.useState(false)
    const [error, setError] = React.useState<string | null>(null)
    const [renamingId, setRenamingId] = React.useState<string | null>(null)
    const [renameValue, setRenameValue] = React.useState('')
    // ARCH-03: 可见性切换的刷新令牌——toggle 显示归档时 +1，重建轮询 effect 立即拉取新变体快照
    const [refreshToken, setRefreshToken] = React.useState(0)
    const didInitRef = React.useRef(false)
    // ARCH-PERF-03: 精简/含归档快照分别保存。隐藏归档时精简轮询不再覆盖
    // 已加载的全量快照，再次显示可同步恢复并在后台校准。
    // 拖动/缩放状态用 ref 而非 state:高频 pointermove 只更新 ref,不触发 React 重渲染
    const dragStateRef = React.useRef<unknown>(null)
    const panelDragRef = React.useRef<unknown>(null)
    const resizeDragRef = React.useRef<unknown>(null)
    // 防重复提交:重命名 Enter/blur 双触发;归档按钮连点
    const renamePendingRef = React.useRef(false)
    const archivePendingRef = React.useRef(false)
    const [autoLayout, setAutoLayout] = React.useState(true)
    const autoLayoutRef = React.useRef(true)
    const setAutoLayoutBoth = (v: boolean) => { autoLayoutRef.current = v; setAutoLayout(v) }
    const [confirmArchive, setConfirmArchive] = React.useState(false)
    const bodyRef = React.useRef<HTMLDivElement | null>(null)
    const panelRef = React.useRef<HTMLDivElement | null>(null)
    const [panelPos, setPanelPos] = React.useState<NodePos | null>(null)
    // UX-01: ref 镜像 panelPos,让 viewport resize 监听器始终读到最新面板位置
    const panelPosRef = React.useRef<NodePos | null>(null)
    const applyPanelPos = (next: NodePos | null) => { panelPosRef.current = next; setPanelPos(next) }
    const [panelSize, setPanelSize] = React.useState<PanelSize | null>(null)
    const [compact, setCompact] = React.useState(false)
    const [selectBox, setSelectBox] = React.useState<SelectBox | null>(null)
    // 空格键状态:光标移出画布或松开后需自动复位,供"空格+左键=平移"使用
    const spaceDownRef = React.useRef(false)
    const lastDragMovedRef = React.useRef(0)
    const pointerDownNodeRef = React.useRef<string | null>(null)
    const tapTimestampRef = React.useRef(0)
    const tapIdRef = React.useRef<string | null>(null)
    const lastJumpRef = React.useRef<{ id: string; t: number } | null>(null)

    const refs = {
      dragStateRef, panelDragRef, resizeDragRef, renamePendingRef, archivePendingRef,
      spaceDownRef, lastDragMovedRef, pointerDownNodeRef, tapTimestampRef, tapIdRef, lastJumpRef,
      bodyRef, panelRef, panelPosRef,
    }

    const setters = {
      setConfirmArchive, setSelectBox, applyPanelPos, setPanelSize, setCompact,
      setRenamingId, setRenameValue, setError, setAutoLayoutBoth,
    }

    // 当前渲染快照（interactions 每次渲染重建闭包时读最新值）
    const view = state.view
    // PERF-03: nodes 过滤结果 useMemo 稳定——若不缓存,每次渲染 filter 出新数组,
    // 下游 byId/edgeElements/nodeElements 的 useMemo 依赖引用全部失效(缓存白搭)。
    const nodes: CanvasNode[] = React.useMemo(
      () => (state.showArchived ? state.nodes : state.nodes.filter((n) => !n.archived)),
      [state.nodes, state.showArchived],
    )
    // PERF-03: byId/edges 用 useMemo 稳定引用——元素缓存依赖它们,每次渲染新建 Map
    // 会让 useMemo 永远失效(旧实现如此,多分支时每帧重建全部边元素)。
    const byId = React.useMemo(() => {
      const m = new Map<string, CanvasNode>()
      for (const n of nodes) m.set(n.id, n)
      return m
    }, [nodes])
    // 边基于全部节点计算;图案结构签名与 mode/showArchived 变化才重算
    const edges: EdgeLite[] = React.useMemo(() => computeEdges(state.nodes, state.mode, state.showArchived), [state.nodes, state.mode, state.showArchived])
    const ez = state.view.zoom * (state.viewScale || 1)
    const circleMode = ez < (compact ? 0.85 : CIRCLE_ZOOM)
    const pos: Map<string, NodePos> = circleMode ? state.circlePositions : state.positions
    const nodeW = circleMode ? CIRCLE_D : NODE_W
    const nodeH = circleMode ? CIRCLE_D : NODE_H

    const current: BrvisCurrent = { nodes, pos, circleMode, nodeW, nodeH, byId, ez }

    // 交互（每次渲染重建，闭包读最新 nodes/pos/状态）
    const interactions = createCanvasInteractions({
      platform, timer, state,
      refs: refs as Parameters<typeof createCanvasInteractions>[0]['refs'],
      view,
      setters: setters as Parameters<typeof createCanvasInteractions>[0]['setters'],
      path: pathStr,
      current,
      renamingId, renameValue,
      COMPACT_W, BASE_W,
    })
    // PERF-03: interactions 每次渲染重建(闭包依赖最新快照),但元素 useMemo 需要稳定依赖。
    // jumpRef 总是持有最新的 jumpToSession / commitRename / archiveSelected——
    // 双击跳转/改名/归档发生在用户事件时刻,必须读最新闭包(不能缓存旧);
    // 元素数组本身依赖数据(nodes/pos)而非交互闭包,二者解耦。
    const jumpRef = React.useRef(interactions.jumpToSession)
    jumpRef.current = interactions.jumpToSession
    const commitRef = React.useRef(interactions.commitRename)
    commitRef.current = interactions.commitRename
    const archiveRef = React.useRef(interactions.archiveSelected)
    archiveRef.current = interactions.archiveSelected

    React.useEffect(() => {
      if (sessionId) state.set({ currentSessionId: sessionId })
    }, [sessionId])

    function startArchivedWarmup(): void {
      if (!pathStr || readCanvasSnapshot(snapshotVariants, pathStr, true)) return
      const running = archivedWarm
      if (running?.path === pathStr) return
      if (running) running.controller.abort()
      const controller = new AbortController()
      const promise = fetchSnapshot(pathStr, { includeArchived: true, signal: controller.signal })
        .then((data) => {
          const snap = (data && typeof data === 'object' ? data : {}) as { nodes?: CanvasNode[]; generatedAt?: number }
          writeCanvasSnapshot(snapshotVariants, pathStr, true, snap.nodes || [], snap.generatedAt)
        })
        // 预热失败不打断精简画布；用户真正切换时仍会走带错误提示的前台请求。
        .catch(() => undefined)
        .finally(() => {
          if (archivedWarm?.promise === promise) archivedWarm = null
        })
      archivedWarm = { path: pathStr, controller, promise }
    }

    React.useEffect(() => () => {
      const running = archivedWarm
      if (running?.path === pathStr) {
        running.controller.abort()
        archivedWarm = null
      }
    }, [pathStr])

    React.useEffect(() => {
      const p = panelRef.current
      if (p) {
        const w = p.getBoundingClientRect().width
        setCompact(w < COMPACT_W)
        state.set({ viewScale: clamp(w / BASE_W, 0.32, 1) })
      }
      // UX-01: viewport resize 后重新夹紧面板（保持标题栏可见，窗口尺寸变化时钳制位置）
      const onWinResize = () => {
        const el = panelRef.current
        if (!el) return
        const rect = el.getBoundingClientRect()
        const vw = window.innerWidth
        const vh = window.innerHeight
        setCompact(rect.width < COMPACT_W)
        state.set({ viewScale: clamp(rect.width / BASE_W, 0.32, 1) })
        // 面板部分越出视口则夹紧（读 ref 拿到最新位置）
        const cur = panelPosRef.current
        if (cur) {
          const pad = 8
          let nx = cur.x
          let ny = cur.y
          if (rect.left < pad) nx = pad
          if (rect.left + rect.width > vw - pad) nx = Math.max(pad, vw - pad - rect.width)
          if (rect.top < pad) ny = pad
          if (rect.top + rect.height > vh - pad) ny = Math.max(pad, vh - pad - rect.height)
          if (nx !== cur.x || ny !== cur.y) applyPanelPos({ x: nx, y: ny })
        }
      }
      window.addEventListener('resize', onWinResize)
      return () => window.removeEventListener('resize', onWinResize)
    }, [])

    React.useEffect(() => {
      let alive = true
      // REV-06（2026-08-18）：删除 `const generation = 0` 死代码——旧版注释宣称
      // "generation 递增隔离"，但常量从不递增、`gen !== generation` 恒 false。
      // 真实的迟到响应隔离 = effect 重建时旧闭包 `alive=false` + 每次轮询独立 AbortController。
      // lastSig:null 哨兵确保首次加载必执行;'' 表示空画布,之后轮询可跳过
      const cachedAtStart = readCanvasSnapshot(snapshotVariants, pathStr, state.showArchived)
      let lastSig: string | null = cachedAtStart?.signature ?? null
      // UX-02 补丁（2026-08-18）：记录本 effect 会话内最近一次请求是否失败——
      // 失败后不再亮 loading 浮层，否则每次退避轮询都会闪浮层并把「加载失败」错误遮住。
      let lastFailed = false
      // ARCH-03: 本次 effect 会话捕获的可见性——显示归档切换(refreshToken)会重建 effect
      const incArch = state.showArchived
      // PERF-02: failStreak=失败退避计数;idleStreak=数据无变化连续轮数(自适应退避
      // 用:稳定数据不需要 2s 高频刷新,host 端全量快照构建成本高——多分支时每 2s 全扫
      // 会让宿主 CPU 高占用,归档/建分支时甚至拖慢整机(用户反馈视频卡顿)。
      // P2（2026-08-18）：注释如实——失败退避 2s→4s→8s→16s→30s 封顶（REV-05 上限 4），
      // 稳定数据（无变化）退避封顶 16s；页面不可见时直接暂停轮询。
      let failStreak = 0
      let idleStreak = 0
      async function load(initial: boolean, signal: AbortSignal | null) {
        if (!alive) return
        // PERF-02: 后台轮询跳过;首次加载(initial)无论可见性都执行,避免 loading 卡死
        if (document.hidden && !initial) return
        // OPEN-02/UX-02（2026-08-18）：切到「显示归档」时 effect 以非 initial 方式重建，
        // 但这是一次“全量含归档”慢请求，必须让 loading=true 触发等待提示。
        // 用 lastSig===null 表示该 effect 尚未拿到本变体快照，只有首次/切到含归档时亮提示；
        // 后续轮询（已有快照）保持静默，避免每次轮询都闪 loading。
        // UX-02 补丁：最近一次已失败（lastFailed）→ 不亮浮层，让状态栏错误可见；
        // 成功或用户重新切换显隐（effect 重建）后恢复。
        const showLoading = lastSig === null && (initial || incArch) && !lastFailed
        try {
          if (showLoading) setLoading(true)
          // ARCH-03: 把可见性传给 host——默认 false 时归档节点连数据都不加载
          const data = await fetchSnapshot(pathStr, {
            includeArchived: incArch,
            // 首次点击“显示归档”先拿结构/旧缓存，不再用空白浮层等待全部冷日志。
            preferCached: incArch,
            signal: signal || undefined,
          })
          if (!alive) return
          failStreak = 0
          lastFailed = false
          // 快照 nodes 字段（host 权威构建）；形状与 CanvasNode 对齐
          const snapData = (data && typeof data === 'object' ? data : {}) as { nodes?: CanvasNode[]; generatedAt?: number; hydrating?: boolean }
          const incomingNodes: CanvasNode[] = snapData.nodes || []
          setArchivedHydrating(incArch && snapData.hydrating === true)
          const cachedIncoming = writeCanvasSnapshot(
            snapshotVariants,
            pathStr,
            incArch,
            incomingNodes,
            snapData.generatedAt,
          )
          // 精简快照先到即可在后台预热归档变体。用户不点“显示归档”时不影响当前 UI；
          // 用户稍后点击时通常已经准备完成。
          if (!incArch) startArchivedWarmup()
          // 成功响应即清除错误标记(即使数据未变化)
          setError(null)
          // 数据指纹:内容未变化时跳过 set({nodes}),避免轮询引发全量重渲染
          const sig = cachedIncoming.signature
          if (sig === lastSig) {
            if (snapData.hydrating === true) {
              // 完整快照仍在后台构建时保持 2s 轮询，不进入 4/8/16s 稳定退避。
              idleStreak = 0
              return
            }
            // PERF-02: 数据无变化→轮询频率退避(2s base,每档 ×2,稳定数据封顶 16s——
            // idleStreak 上限 3 → 2s*2^3=16s，REV-05 与失败路径 30s 封顶分开计数)
            idleStreak = Math.min(idleStreak + 1, 3)
            return
          }
          idleStreak = 0
          lastSig = sig
          if (!autoLayoutRef.current && state.nodes.length) {
            const changed = incomingNodes.some((n) => !state.positions.has(n.id))
            if (changed) {
              const appendPos = (map: Map<string, NodePos>) => {
                let maxY = 0, maxX = 0
                for (const po of map.values()) {
                  if (po.x > maxX) maxX = po.x
                  if (po.y > maxY) maxY = po.y
                }
                let idx = 0
                const next = new Map(map)
                for (const n of incomingNodes) {
                  if (!next.has(n.id)) {
                    next.set(n.id, { x: maxX + NODE_W + SIB_GAP + idx * 30, y: maxY + LEVEL_GAP })
                    idx += 1
                  }
                }
                return next
              }
              state.set({
                positions: appendPos(state.positions),
                circlePositions: appendPos(state.circlePositions),
              })
            }
          }
          // STATE-01: 快照到达即清理残留—删除已不存在节点的选中与位置,当前会话被删则清空
          const pruneUpdates = (() => {
            const live = new Set(incomingNodes.map((n) => n.id))
            let dirty = false
            const newSel: string[] = []
            for (const s of state.selectedIds) if (live.has(s)) newSel.push(s)
            if (newSel.length !== state.selectedIds.size) dirty = true
            let posDirty = false
            for (const id of [...state.positions.keys()]) if (!live.has(id)) { posDirty = true; break }
            if (!posDirty) for (const id of [...state.circlePositions.keys()]) if (!live.has(id)) { posDirty = true; break }
            if (!dirty && !posDirty) return null
            const patch: Record<string, unknown> = {}
            if (dirty) patch.selectedIds = new Set(newSel)
            if (posDirty) {
              const p2 = new Map<string, NodePos>(), c2 = new Map<string, NodePos>()
              for (const n of incomingNodes) {
                const pp = state.positions.get(n.id)
                if (pp) p2.set(n.id, pp)
                const cp = state.circlePositions.get(n.id)
                if (cp) c2.set(n.id, cp)
              }
              patch.positions = p2
              patch.circlePositions = c2
            }
            return patch
          })()
          // 当前会话节点已不存在:清空标记,避免绿色残留(参照 STATE-01 完成标准6)
          const curPrune = state.currentSessionId && !incomingNodes.some((n) => n.id === state.currentSessionId) ? { currentSessionId: null } : null
          state.set(Object.assign({ nodes: incomingNodes }, pruneUpdates || {}, curPrune || {}))
        } catch (err) {
          if (!alive) return
          // 后台刷新失败:保留旧图,显示"数据可能已过期"(参照 UX-01)
          failStreak += 1
          lastFailed = true
          const e = (err && typeof err === 'object' ? err : {}) as { message?: string }
          setError((initial ? '加载失败: ' : '刷新失败,数据可能已过期: ') + (e.message || '未知错误'))
        } finally {
          if (alive && showLoading) setLoading(false)
        }
      }
      // NET-01: 每次轮询独立 AbortController; 卸载/路径变化/新轮询启动时 abort 旧请求
      let lastCtrl: AbortController | null = null
      // ARCH-03: 首次挂载显示 loading；可见性切换(refreshToken 变化)重建 effect 后立即静默刷新。
      // BUGFIX-02: effect 重建分支必须先清 loading —— 旧 effect 可能正卡在 setLoading(true)
      // （切到「显示归档」发全量慢请求），若立即切回「隐藏归档」，新 effect 的 showLoading
      // 恒 false，其 load 永远不会 setLoading(false)；旧 effect 的 finally 因 alive=false 也不清，
      // 导致状态栏/浮层永久"加载中"。先清再决定是否按 showLoading 重新置 true。
      if (!didInitRef.current) {
        didInitRef.current = true
        load(true, null)
      } else {
        setLoading(false)
        load(false, null)
      }
      // CACHE-01/UX-01/REV-05：失败指数退避轮询，成功立即恢复 2s 基准间隔。
      // REV-05（2026-08-18）：幂上限 3→4 —— 旧代码 min(fail+idle,3) 使任何路径 ≤16s，
      // MAX_INTERVAL=30s 是永不触达的死常量，注释宣称的 30s 封顶名不副实。
      // 现上限 4：失败退避 2s→4s→8s→16s→30s 真实封顶；稳定数据（无变化）退避封顶 16s。
      // PERF-02: 成功且数据无变化时同样退避——多分支时快照全量构建成本高,
      // 稳定数据没必要 2s 高频刷新;页面不可见(document.hidden)时暂停,切回立即刷新。
      if (timer) {
        let disposed = false
        const BASE_INTERVAL = 2000
        const MAX_INTERVAL = 30000
        const timerSvc = timer as { timeout(cb: () => void, ms: number): (() => void) }
        // BUGFIX-01: 唯一在排定时器——任何入口(schedule/onVisibility)排定前先取消旧定时器。
        // 旧缺陷: hidden 分支的 30s visDisposer 与 visible 后 onVisibility 排定的轮询定时器
        // 互不知晓,各自触发后各再排一个 → 定时器数量指数翻倍 → 快照请求风暴
        // (放大 PERF-05 已修的宿主重建压力)。现约定同一时刻至多一个 pendingDisposer。
        let pendingDisposer: (() => void) | null = null
        const clearPending = () => {
          if (pendingDisposer) {
            try { pendingDisposer() } catch (e) { /* ignore */ }
            pendingDisposer = null
          }
        }
        const schedule = () => {
          if (disposed || !alive) return
          clearPending()
          // 页面不可见:挂 30s 后再查一次可见性,避免后台空转轮询(多标签/视频播放场景)
          if (document.hidden) {
            const visDisposer = timerSvc.timeout(() => {
              visDisposer()
              pendingDisposer = null
              schedule()
            }, 30000)
            pendingDisposer = visDisposer
            return
          }
          const delay = Math.min(
            BASE_INTERVAL * Math.pow(2, Math.min(failStreak + idleStreak, 4)),
            MAX_INTERVAL,
          )
          const timeoutDisposer = timerSvc.timeout(() => {
            timeoutDisposer()
            pendingDisposer = null
            const ctrl = new AbortController()
            lastCtrl = ctrl
            load(false, ctrl.signal).then(schedule).catch(() => schedule())
          }, delay)
          pendingDisposer = timeoutDisposer
        }
        // 切回前台立即刷新一次（不等下个轮询周期）
        const onVisibility = () => {
          if (!document.hidden) {
            // BUGFIX-01: 先取消可能仍排定的 hidden 30s visDisposer——页面已可见,
            // 它已无意义且 30s 后触发会再排一个轮询,与这里的刷新调度并存翻倍。
            clearPending()
            const ctrl = new AbortController()
            lastCtrl = ctrl
            load(false, ctrl.signal).then(schedule).catch(() => schedule())
          }
        }
        document.addEventListener('visibilitychange', onVisibility)
        schedule()
        return () => {
          alive = false; disposed = true
          document.removeEventListener('visibilitychange', onVisibility)
          // BUGFIX-01: 卸载时取消在排定时器,避免 interval 型 timer 持续触发
          clearPending()
          if (lastCtrl) lastCtrl.abort()
        }
      }
      return () => { alive = false; if (lastCtrl) lastCtrl.abort() }
    }, [pathStr, refreshToken])

    // STATE-01: 布局跟随图结构(id+parentId),而非节点数量;归档/改名触发的 nodes 变更
    // 若结构未变则不重排,避免已手动调整的布局被覆盖
    const graphSig = React.useMemo(() => {
      const parts = state.nodes.map((n) => n.id + '>' + (n.parentId || '') + '>' + (n.parentArchivedBridge ? 1 : 0)).sort()
      return parts.join('|')
    }, [state.nodes])

    React.useEffect(() => {
      if (autoLayout && nodes.length) {
        // ARCH-02: 布局只基于"可见"节点——隐藏归档时归档节点不参与树布局，
        // 否则归档链会让布局尺寸/位置膨胀，且 fitView 边界被归档污染。
        state.set({
          positions: layoutTree(nodes, NODE_W, NODE_H, SIB_GAP, LEVEL_GAP),
          circlePositions: layoutTree(nodes, CIRCLE_D, CIRCLE_D, CIRCLE_SIB, CIRCLE_LEVEL),
        })
      }
    }, [graphSig, autoLayout, state.mode, state.showArchived])

    const prevCircle = React.useRef<boolean | null>(null)
    React.useEffect(() => {
      if (circleMode && !prevCircle.current) {
        interactions.centerOnNodes(circleMode ? state.circlePositions : state.positions)
      }
      prevCircle.current = circleMode
    }, [circleMode])

    // FOCUS-01: 进入对话（currentSessionId 变化）时，当前触发节点平移到视口中心。
    // lastCenteredRef 防止同一 id 在轮询/布局刷新时反复触发；节点位置未就绪时
    // 等 nodes 变化（首次快照/自动布局后）再居中一次。
    const lastCenteredRef = React.useRef<string | null>(null)
    React.useEffect(() => {
      const id = state.currentSessionId
      if (!id || id === lastCenteredRef.current) return
      const map = circleMode ? state.circlePositions : state.positions
      const p = map.get(id)
      const el = bodyRef.current
      if (!p || !el) return
      const rect = el.getBoundingClientRect()
      const z = state.view.zoom * (state.viewScale || 1)
      state.set({
        view: { ...state.view, x: rect.width / 2 - p.x * z, y: rect.height / 2 - p.y * z },
      })
      lastCenteredRef.current = id
    }, [state.currentSessionId, state.nodes])

    // 滚轮: 触控板捏合或 Ctrl+滚轮 = 缩放(按 deltaY 连续映射);普通滚动 = 平移
    React.useEffect(() => {
      const el = bodyRef.current
      if (!el) return
      const onWheel = (ev: WheelEvent) => {
        ev.preventDefault()
        const dMult = ev.deltaMode === 1 ? 40 : ev.deltaMode === 2 ? 400 : 1
        if (ev.ctrlKey) {
          const dz = ev.deltaY * dMult
          const factor = Math.pow(1.002, -dz)
          const z = clamp(state.view.zoom * factor, 0.25, 2.5)
          const rect = el.getBoundingClientRect()
          const mx = ev.clientX - rect.left
          const my = ev.clientY - rect.top
          const curEz = state.view.zoom * (state.viewScale || 1)
          const wx = (mx - state.view.x) / curEz
          const wy = (my - state.view.y) / curEz
          const newEz = z * (state.viewScale || 1)
          state.set({ view: { zoom: z, x: mx - wx * newEz, y: my - wy * newEz } })
        } else {
          const s = 1.15
          state.set({ view: { ...state.view, x: state.view.x - ev.deltaX * dMult * s, y: state.view.y - ev.deltaY * dMult * s } })
        }
      }
      el.addEventListener('wheel', onWheel, { passive: false })
      return () => el.removeEventListener('wheel', onWheel)
    }, [])

    // 空格键状态跟踪(任意焦点下有效):空格+左键拖拽 = 平移画布(鼠标等效触控板双指滑动)
    React.useEffect(() => {
      const isTyping = (ev: KeyboardEvent) => {
        const t = ev.target as HTMLElement | null
        if (!t) return false
        return t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || (t.isContentEditable || false)
      }
      const onKeyDown = (ev: KeyboardEvent) => {
        // UX-01: Escape 取消归档确认（改名输入框内的 Escape 已在 input onKeyDown 处理）
        if (ev.code === 'Escape') {
          setConfirmArchive(false)
          return
        }
        if (ev.code !== 'Space') return
        if (isTyping(ev)) return
        spaceDownRef.current = true
        ev.preventDefault()
      }
      const onKeyUp = (ev: KeyboardEvent) => {
        if (ev.code === 'Space') spaceDownRef.current = false
      }
      const onBlur = () => { spaceDownRef.current = false }
      window.addEventListener('keydown', onKeyDown, true)
      window.addEventListener('keyup', onKeyUp, true)
      window.addEventListener('blur', onBlur)
      return () => {
        window.removeEventListener('keydown', onKeyDown, true)
        window.removeEventListener('keyup', onKeyUp, true)
        window.removeEventListener('blur', onBlur)
      }
    }, [])

    // ============ 元素组装（纯展示，见 canvas-elements.tsx） ============
    // PERF-03: useMemo 缓存——edges/pos/selectedIds 等"数据"变化才重建元素;
    // pan/zoom(仅 view 变化)时组件重渲染但元素数组复用,不再每帧重建全部 DOM 元素
    // (旧实现:拖拽/缩放每次 state.set({view}) → 全组件重渲染 → 重建所有节点/边 React
    // 元素,多分支时每帧几百次 createElement,主线程卡顿甚至页面假死)。
    const edgeElements = React.useMemo(
      () => buildEdgeElements(edges, pos, nodeW, nodeH, circleMode, state.currentSessionId, byId),
      [edges, pos, nodeW, nodeH, circleMode, state.currentSessionId, byId],
    )
    const nodeElements = React.useMemo(
      () => buildNodeElements({
        nodes, pos, nodeW, nodeH, circleMode,
        currentSessionId: state.currentSessionId,
        selectedIds: state.selectedIds,
        ez, viewX: state.view.x, viewY: state.view.y,
        onDoubleJump: jumpRef.current,
        // 7.7（2026-08-18）：不再在 render 期读 getBoundingClientRect（强制回流）。
        // 缺位置节点的兜底视口由 buildNodeElements 内部默认 {600,400} 承担，
        // 真实尺寸由各自 layout/centerOnNodes 路径按需补位（文档 §4.2-7.7）。
        fallbackRect: null,
      }),
      // PERF-03: 依赖仅数据(nodes/pos/选中/模式),不含 interactions——
      // 交互闭包经 jumpRef 转发; view.x/view.y 变化只改外层 transform,不重建节点。
      // 7.7: fallbackRect 已恒 null(不再读 bodyRef),故依赖中移除 bodyRef——
      // 它只是稳定 ref 对象(引用不变),保留纯属噪音。
      // AUD-09（2026-08-18）: ez 移出依赖——buildNodeElements 仅在"无位置节点兜底"
      // 时用 ez，与 viewX/viewY 同待遇（容忍陈旧值，缩放不再每帧全量重建节点元素，
      // 兑现 PERF-03 "pan/zoom 时元素数组复用"）。
      // eslint 角度此依赖不含 jumpRef.current(每次渲染都变,含则缓存失效)→ 语义上
      // jumpRef 永远指向最新闭包,元素只在数据变化时重建,事件时读到最新 jumpToSession。
      [nodes, pos, nodeW, nodeH, circleMode, state.currentSessionId, state.selectedIds],
    )
    const renameEl = buildRenameElement({
      renamingId, byId, pos, nodeH,
      value: renameValue,
      onChange: setRenameValue,
      onCommit: commitRef.current,
      onCancel: () => setRenamingId(null),
    })
    const archiveButton = buildArchiveButton({
      confirmArchive,
      selectedCount: state.selectedIds.size,
      pending: archivePendingRef.current,
      onRequest: () => setConfirmArchive(true),
      onConfirm: () => { setConfirmArchive(false); archiveRef.current() },
      onCancel: () => setConfirmArchive(false),
    })
    const toolbar = buildToolbar({
      compact, state,
      handlers: {
        pathName: pathStr ? pathStr.split(/[\\/]/).pop() : '分支图',
        onTitlePointerDown: interactions.onTitlePointerDown,
        onTitlePointerMove: interactions.onTitlePointerMove,
        onTitlePointerUp: interactions.onTitlePointerUp,
        onMode: (m) => { setConfirmArchive(false); state.set({ mode: m }) },
        onZoomIn: () => interactions.zoomBy(1.2),
        onZoomOut: () => interactions.zoomBy(1 / 1.2),
        onRelayout: () => { setConfirmArchive(false); setAutoLayoutBoth(true); state.set({ positions: layoutTree(nodes, NODE_W, NODE_H, SIB_GAP, LEVEL_GAP), circlePositions: layoutTree(nodes, CIRCLE_D, CIRCLE_D, CIRCLE_SIB, CIRCLE_LEVEL) }) },
        onRename: () => {
          const id = state.selectedIds.size === 1 ? [...state.selectedIds][0] : null
          if (id) interactions.startRename(id)
        },
        renameDisabled: state.selectedIds.size !== 1,
        onResetPanel: () => { applyPanelPos(null); setPanelSize(null); setConfirmArchive(false) },
        archiveButton,
        onToggleArchived: () => {
          setConfirmArchive(false)
          const next = !state.showArchived
          if (!next) setArchivedHydrating(false)
          const cached = readCanvasSnapshot(snapshotVariants, pathStr, next)
          // 命中即同步恢复对应变体；随后 effect 的请求只做后台校准，不遮住画布。
          state.set(cached ? { showArchived: next, nodes: cached.nodes } : { showArchived: next })
          setRefreshToken((t) => t + 1)
        },
        onClose: () => state.set({ open: false }),
      } as Parameters<typeof buildToolbar>[0]['handlers'],
    })
    const statusLine = buildStatusLine({
      loading,
      error,
      confirmArchive,
      compact,
      count: nodes.length,
      archivedLoading: loading && state.showArchived,
      archivedHydrating: archivedHydrating && state.showArchived,
    })

    const panelStyle: React.CSSProperties = {}
    if (panelPos) {
      panelStyle.left = panelPos.x + 'px'
      panelStyle.top = panelPos.y + 'px'
      panelStyle.right = 'auto'
      panelStyle.bottom = 'auto'
    }
    if (panelSize) {
      panelStyle.width = panelSize.w + 'px'
      panelStyle.height = panelSize.h + 'px'
    }
    return React.createElement('div', { className: 'brvis-panel' + (compact ? ' is-compact' : ''), ref: panelRef, style: panelStyle },
      toolbar,
      React.createElement('div', {
        className: 'brvis-body',
        ref: bodyRef,
        onPointerDown: interactions.onBgPointerDown,
        onPointerMove: interactions.onBgPointerMove,
        onPointerUp: interactions.onBgPointerUp,
        // AUD-06（2026-08-18）：触摸被系统打断（来电/手势接管）时 pointerup 不触发，
        // dragState 残留/拖拽卡死；pointercancel 复用 up 的复位逻辑。
        onPointerCancel: interactions.onBgPointerCancel,
      },
        React.createElement('svg', { className: 'brvis-edges' },
          React.createElement('defs', null,
            React.createElement('marker', { id: 'brvis-arrow', markerWidth: '12', markerHeight: '12', refX: '9.5', refY: '4', orient: 'auto', markerUnits: 'userSpaceOnUse' },
              React.createElement('path', { d: 'M0.5,1 L0.5,7 L11,4 z', className: 'brvis-arrow-head' })),
            React.createElement('marker', { id: 'brvis-arrow-dash', markerWidth: '12', markerHeight: '12', refX: '9.5', refY: '4', orient: 'auto', markerUnits: 'userSpaceOnUse' },
              React.createElement('path', { d: 'M0.5,1 L0.5,7 L11,4 z', className: 'brvis-arrow-head-dash' })),
            React.createElement('marker', { id: 'brvis-arrow-cur', markerWidth: '12', markerHeight: '12', refX: '9.5', refY: '4', orient: 'auto', markerUnits: 'userSpaceOnUse' },
              React.createElement('path', { d: 'M0.5,1 L0.5,7 L11,4 z', className: 'brvis-arrow-head-cur' })),
          ),
          React.createElement('g', { transform: 'translate(' + state.view.x + ',' + state.view.y + ') scale(' + ez + ')' }, edgeElements)),
        React.createElement('div', {
          className: 'brvis-world',
          style: { transform: 'translate(' + state.view.x + 'px,' + state.view.y + 'px) scale(' + ez + ')' },
        }, nodeElements.concat(renameEl ? [renameEl] : [])),
        selectBox ? React.createElement('div', {
          className: 'brvis-selectbox',
          style: { left: selectBox.x + 'px', top: selectBox.y + 'px', width: selectBox.w + 'px', height: selectBox.h + 'px' },
        }) : null,
        loading && state.showArchived ? React.createElement('div', { className: 'brvis-loading-overlay' },
          React.createElement('div', { className: 'brvis-loading-box' },
            React.createElement('div', { className: 'brvis-loading-spinner' }),
            '正在加载全部会话（含归档），大工作区可能需要数十秒…',
          ),
        ) : null,
      ),
      statusLine,
      React.createElement('div', { className: 'brvis-resize brvis-resize-se', onPointerDown: (ev: React.PointerEvent<HTMLDivElement>) => interactions.onResizePointerDown(ev, 'se'), onPointerMove: interactions.onResizePointerMove, onPointerUp: interactions.onResizePointerUp, title: '拖动调整窗口大小' }),
      React.createElement('div', { className: 'brvis-resize brvis-resize-sw', onPointerDown: (ev: React.PointerEvent<HTMLDivElement>) => interactions.onResizePointerDown(ev, 'sw'), onPointerMove: interactions.onResizePointerMove, onPointerUp: interactions.onResizePointerUp, title: '拖动调整窗口大小' }),
      React.createElement('div', { className: 'brvis-resize brvis-resize-nw', onPointerDown: (ev: React.PointerEvent<HTMLDivElement>) => interactions.onResizePointerDown(ev, 'nw'), onPointerMove: interactions.onResizePointerMove, onPointerUp: interactions.onResizePointerUp, title: '拖动调整窗口大小' }),
    )
  }
  return { Canvas }
}
