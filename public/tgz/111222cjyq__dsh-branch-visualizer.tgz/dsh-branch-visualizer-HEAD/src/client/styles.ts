/**
 * dsh-brvis — 全部画布样式（集中管理，与逻辑分离）。
 * 拆分自原单文件 client/index.ts（2026-08）。
 * 约定：所有类名带 brvis- 前缀，避免与应用样式冲突。
 * 本文件是纯字符串导出，无类型依赖（仅 TS 字符串模板）。
 */

export const BRVIS_CSS = `
.brvis-panel { position: fixed; top: 72px; right: 28px; width: min(820px, 78vw); height: min(560px, 74vh); z-index: 9999; pointer-events: auto; display: flex; flex-direction: column; background: var(--dsw-alias-bg-layer-1, #1d2128); border: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.12)); border-radius: 14px; box-shadow: 0 18px 60px rgba(0,0,0,.4); overflow: hidden; font-family: var(--dsw-font-ui, system-ui, -apple-system, 'Segoe UI', sans-serif); color: var(--dsw-alias-label-primary, #e6e9ef); }
.brvis-panel.is-compact { border-radius: 12px; box-shadow: 0 12px 40px rgba(0,0,0,.45); }
.brvis-toolbar { flex: none; display: flex; align-items: center; gap: 6px; padding: 8px 10px; border-bottom: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.08)); user-select: none; }
.brvis-toolbar.is-compact { padding: 6px 8px; }
.brvis-toolbar-title { font-size: 13px; font-weight: 600; color: var(--dsw-alias-label-primary, #e6e9ef); margin-right: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 220px; cursor: move; flex: 0 1 auto; }
.brvis-toolbar.is-compact .brvis-toolbar-title { max-width: 90px; font-size: 12px; }
.brvis-toolbar-group { display: flex; gap: 5px; flex: none; align-items: center; }
.brvis-toolbar-spacer { flex: 1; min-width: 6px; }
.brvis-tb { border: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.1)); background: var(--dsw-alias-bg-layer-2, #23282f); color: var(--dsw-alias-label-secondary, #aab2bf); border-radius: 7px; padding: 4px 9px; font-size: 12px; cursor: pointer; transition: background .12s, color .12s, border-color .12s; white-space: nowrap; }
.brvis-tb:hover:not(:disabled) { color: var(--dsw-alias-label-primary, #e6e9ef); border-color: var(--dsw-alias-border-l2, rgba(255,255,255,.2)); }
.brvis-tb:disabled { opacity: .45; cursor: default; }
.brvis-tb.is-active { background: color-mix(in srgb, var(--dsw-alias-brand-primary, #4f7cff) 18%, transparent); border-color: var(--dsw-alias-brand-primary, #4f7cff); color: var(--dsw-alias-label-primary, #e6e9ef); }
.brvis-archive-confirm { display: inline-flex; gap: 5px; align-items: center; }
.brvis-archive-confirm .brvis-tb:first-child { border-color: var(--dsw-alias-state-error-primary, #ff6b6b); color: var(--dsw-alias-state-error-primary, #ff6b6b); }
.brvis-archive-confirm .brvis-tb:first-child:hover { background: color-mix(in srgb, var(--dsw-alias-state-error-primary, #ff6b6b) 14%, transparent); }
.brvis-body { position: relative; flex: 1; overflow: hidden; background: color-mix(in srgb, var(--dsw-alias-bg-base, #14171c) 72%, var(--dsw-alias-bg-layer-1, #1d2128)); touch-action: none; }
.brvis-status { flex: none; font-size: 12px; color: var(--dsw-alias-label-secondary, #aab2bf); border-top: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.08)); padding: 7px 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.brvis-status.is-error { color: var(--dsw-alias-state-error-primary, #ff6b6b); }
.brvis-status.is-warn { color: var(--dsw-alias-state-warn-primary, #ffb340); }
.brvis-world { position: absolute; left: 0; top: 0; width: 0; height: 0; transform-origin: 0 0; }
.brvis-selectbox { position: absolute; z-index: 20; pointer-events: none; border: 1.5px dashed var(--dsw-alias-brand-primary, #4f7cff); background: color-mix(in srgb, var(--dsw-alias-brand-primary, #4f7cff) 12%, transparent); border-radius: 3px; }
.brvis-edges { position: absolute; left: 0; top: 0; width: 100%; height: 100%; pointer-events: none; }
.brvis-edge { stroke: var(--dsw-alias-label-secondary, #8a94a6); stroke-width: 1.6; opacity: .85; vector-effect: non-scaling-stroke; }
.brvis-edge.is-dashed { stroke-dasharray: 6 5; opacity: .55; }
.brvis-edge.is-double-dash { opacity: .7; }
.brvis-edge.is-double-dash.is-double-1 { stroke-dasharray: 7 5; opacity: .45; }
.brvis-edge.is-double-dash.is-double-2 { stroke-dasharray: 3 9; stroke-dashoffset: 4; opacity: .85; }
.brvis-edge.is-current-edge { stroke: var(--dsw-alias-state-success-primary, #34c759); opacity: .95; }
.brvis-arrow-head { fill: var(--dsw-alias-label-secondary, #8a94a6); }
.brvis-arrow-head-dash { fill: var(--dsw-alias-label-secondary, #8a94a6); opacity: .55; }
.brvis-arrow-head-cur { fill: var(--dsw-alias-state-success-primary, #34c759); }
.brvis-node { position: absolute; box-sizing: border-box; border: 1.5px solid var(--dsw-alias-border-l2, rgba(255,255,255,.18)); border-radius: 14px; background: var(--dsw-alias-bg-layer-2, #23282f); box-shadow: 0 4px 14px rgba(0,0,0,.22); display: flex; flex-direction: column; align-items: center; justify-content: center; cursor: grab; user-select: none; padding: 8px 10px; transition: border-color .12s, box-shadow .12s, transform .12s, filter .12s; }
.brvis-node:active { cursor: grabbing; }
.brvis-node.is-clicked { transform: scale(1.04); filter: brightness(1.15); }
.brvis-node.is-selected { border-color: var(--dsw-alias-brand-primary, #4f7cff); box-shadow: 0 0 0 3px color-mix(in srgb, var(--dsw-alias-brand-primary, #4f7cff) 30%, transparent), 0 4px 14px rgba(0,0,0,.22); }
.brvis-node.is-current { border-color: var(--dsw-alias-state-success-primary, #34c759); box-shadow: 0 0 0 3px color-mix(in srgb, var(--dsw-alias-state-success-primary, #34c759) 35%, transparent), 0 4px 14px rgba(0,0,0,.22); }
.brvis-node.is-archived { border-style: dashed; opacity: .62; background: color-mix(in srgb, var(--dsw-alias-bg-layer-2, #23282f) 55%, var(--dsw-alias-bg-base, #14171c)); }
.brvis-node.is-subagent { border-color: var(--dsw-alias-brand-secondary, #a78bfa); box-shadow: 0 0 0 2px color-mix(in srgb, var(--dsw-alias-brand-secondary, #a78bfa) 22%, transparent), 0 4px 14px rgba(0,0,0,.22); }
.brvis-node-title { font-size: 13px; font-weight: 600; line-height: 1.3; color: var(--dsw-alias-label-primary, #e6e9ef); max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: flex; align-items: center; gap: 6px; }
.brvis-arch-badge { font-size: 10px; font-weight: 700; color: var(--dsw-alias-state-warn-primary, #ffb340); border: 1px solid currentColor; border-radius: 4px; padding: 0 4px; line-height: 1.4; flex: none; }
.brvis-sub-badge { font-size: 10px; font-weight: 700; color: var(--dsw-alias-brand-secondary, #a78bfa); border: 1px solid currentColor; border-radius: 4px; padding: 0 4px; line-height: 1.4; flex: none; }
.brvis-node-sub { font-size: 11px; color: var(--dsw-alias-label-secondary, #8a94a6); margin-top: 3px; }
.brvis-current-dot { color: var(--dsw-alias-state-success-primary, #34c759); font-weight: 600; }
.brvis-rename { position: absolute; z-index: 10; }
.brvis-rename input { width: 100%; box-sizing: border-box; border: 1px solid var(--dsw-alias-brand-primary, #4f7cff); border-radius: 8px; background: var(--dsw-alias-bg-overlay, #101318); color: var(--dsw-alias-label-primary, #e6e9ef); font-size: 13px; padding: 6px 8px; outline: none; }
.brvis-toggle { border: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,.1)); background: transparent; color: var(--dsw-alias-label-secondary, #aab2bf); border-radius: 7px; padding: 4px 10px; font-size: 12px; cursor: pointer; }
.brvis-toggle:hover { color: var(--dsw-alias-label-primary, #e6e9ef); }
.brvis-toggle.is-active { color: var(--dsw-alias-brand-primary, #4f7cff); border-color: var(--dsw-alias-brand-primary, #4f7cff); }
.brvis-circle-node {
  position: absolute; box-sizing: border-box;
  border-radius: 50%;
  border: 2px solid var(--dsw-alias-label-secondary, #8a94a6);
  background: color-mix(in srgb, var(--dsw-alias-bg-layer-2, #23282f) 60%, transparent);
  display: flex; align-items: center; justify-content: center;
  cursor: grab; user-select: none;
  transition: border-color .12s, box-shadow .12s, background .12s;
}
.brvis-circle-node:active { cursor: grabbing; }
.brvis-circle-node .brvis-circle-core {
  width: 10px; height: 10px; border-radius: 50%;
  background: var(--dsw-alias-label-secondary, #8a94a6);
}
.brvis-circle-node.is-current {
  border-color: var(--dsw-alias-state-success-primary, #34c759);
  background: color-mix(in srgb, var(--dsw-alias-state-success-primary, #34c759) 22%, transparent);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--dsw-alias-state-success-primary, #34c759) 35%, transparent);
}
.brvis-circle-node.is-current .brvis-circle-core { background: var(--dsw-alias-state-success-primary, #34c759); }
.brvis-circle-node.is-selected {
  border-color: var(--dsw-alias-brand-primary, #4f7cff);
  background: color-mix(in srgb, var(--dsw-alias-brand-primary, #4f7cff) 22%, transparent);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--dsw-alias-brand-primary, #4f7cff) 30%, transparent);
}
.brvis-circle-node.is-selected .brvis-circle-core { background: var(--dsw-alias-brand-primary, #4f7cff); }
.brvis-circle-node.is-archived {
  border-style: dashed;
  opacity: .65;
  background: color-mix(in srgb, var(--dsw-alias-bg-layer-2, #23282f) 40%, transparent);
}
.brvis-circle-node.is-archived .brvis-circle-core { opacity: .6; }
.brvis-circle-node.is-subagent {
  border-color: var(--dsw-alias-brand-secondary, #a78bfa);
  background: color-mix(in srgb, var(--dsw-alias-brand-secondary, #a78bfa) 18%, transparent);
}
.brvis-circle-node.is-subagent .brvis-circle-core { background: var(--dsw-alias-brand-secondary, #a78bfa); }
.brvis-resize {
  position: absolute;
  width: 18px; height: 18px;
  cursor: nwse-resize;
  opacity: .55;
  z-index: 6;
  pointer-events: auto;
}
.brvis-resize:hover { opacity: 1; }
.brvis-resize-se { right: 4px; bottom: 4px; border-right: 2px solid var(--dsw-alias-label-secondary, #8a94a6); border-bottom: 2px solid var(--dsw-alias-label-secondary, #8a94a6); border-bottom-right-radius: 6px; cursor: nwse-resize; }
.brvis-resize-sw { left: 4px; bottom: 4px; border-left: 2px solid var(--dsw-alias-label-secondary, #8a94a6); border-bottom: 2px solid var(--dsw-alias-label-secondary, #8a94a6); border-bottom-left-radius: 6px; cursor: nesw-resize; }
.brvis-resize-nw { left: 4px; top: 4px; border-left: 2px solid var(--dsw-alias-label-secondary, #8a94a6); border-top: 2px solid var(--dsw-alias-label-secondary, #8a94a6); border-top-left-radius: 6px; cursor: nwse-resize; }
/* 运行状态标识:运行中=绿色脉冲动画,空闲=灰色静态点,冷会话无标记 */
.brvis-active-pulse { position: absolute; bottom: 4px; right: 4px; width: 8px; height: 8px; border-radius: 50%; background: var(--dsw-alias-state-success-primary, #34c759); animation: brvis-pulse 1.5s ease-in-out infinite; pointer-events: none; z-index: 5; }
.brvis-active-dot { position: absolute; bottom: 4px; right: 4px; width: 7px; height: 7px; border-radius: 50%; background: var(--dsw-alias-label-secondary, #8a94a6); opacity: .5; pointer-events: none; z-index: 5; }
.brvis-circle-node .brvis-active-pulse { bottom: -2px; right: -2px; width: 7px; height: 7px; }
.brvis-circle-node .brvis-active-dot { bottom: -1px; right: -1px; width: 6px; height: 6px; }
@keyframes brvis-pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: .4; transform: scale(1.3); }
}
.is-running > .brvis-active-pulse, .is-idle > .brvis-active-pulse, .is-running > .brvis-active-dot, .is-idle > .brvis-active-dot {
  position: absolute;
  z-index: 5;
  pointer-events: none;
}
/* OPEN-02/UX-02：显示归档全量加载等待提示（大工作区可能数十秒，必须有明确反馈） */
.brvis-loading-overlay { position: absolute; inset: 0; z-index: 30; display: flex; align-items: center; justify-content: center; background: color-mix(in srgb, var(--dsw-alias-bg-overlay, #101318) 42%, transparent); backdrop-filter: blur(1px); pointer-events: none; }
.brvis-loading-box { display: inline-flex; align-items: center; gap: 10px; background: var(--dsw-alias-bg-layer-2, #23282f); border: 1px solid var(--dsw-alias-border-l2, rgba(255,255,255,.18)); border-radius: 10px; padding: 12px 18px; font-size: 13px; color: var(--dsw-alias-label-primary, #e6e9ef); box-shadow: 0 8px 30px rgba(0,0,0,.35); }
.brvis-loading-spinner { width: 18px; height: 18px; border-radius: 50%; border: 2px solid var(--dsw-alias-border-l2, rgba(255,255,255,.2)); border-top-color: var(--dsw-alias-brand-primary, #4f7cff); animation: brvis-spin .8s linear infinite; }
@keyframes brvis-spin { to { transform: rotate(360deg); } }
`