/**
 * dsh-brvis — 同源 fetch RPC（浏览器 → host webServer /brvis/api）。
 * 拆分自原单文件 client/index.ts（2026-08）。
 * 契约：宿主只返回 { ok:true, data } 或 { ok:false, error:{code,message,retryable} }（CONTRACT-01：共享）。
 * 业务失败与传输失败统一转成带 code/retryable 的 Error。
 *
 * NET-01（2026-08）：AbortSignal + 超时 + 超时常量。
 * 旧工作区路径轮询到达时，generation 检查在调用方（canvas）执行；transport 只负责取消/超时。
 */

import { ROUTE_PREFIX } from '../shared/contract.js'

// NET-01 超时常量（ms）
// OPEN-02（2026-08-18）：超时按快照变体分级——含归档的全量重建实测 20.5s（45 节点/44 归档
// 工作区，共同维护文档 ARCH-03），若仍用 10s 必然 NETWORK_TIMEOUT → 面板打开即报错（"打不开"）。
// 默认（不含归档）快照保持 10s；显式传 timeoutMs 时优先尊重调用方。
const SNAPSHOT_TIMEOUT_MS = 10_000
const SNAPSHOT_ARCHIVED_TIMEOUT_MS = 45_000
const MUTATION_TIMEOUT_MS = 15_000

interface CombinedSignal {
  controller: AbortController
  dispose(): void
}

/** 组合外部 signal + 超时；请求结束后 dispose，避免残留 timer/listener。 */
function combineSignal(external?: AbortSignal, timeoutMs?: number): CombinedSignal {
  const ctrl = new AbortController()
  let timer: ReturnType<typeof setTimeout> | undefined
  let onExternalAbort: (() => void) | undefined
  if (external) {
    if (external.aborted) ctrl.abort(external.reason)
    else {
      onExternalAbort = () => ctrl.abort(external.reason)
      external.addEventListener('abort', onExternalAbort, { once: true })
    }
  }
  if (!ctrl.signal.aborted && timeoutMs && timeoutMs > 0) {
    // AUD-05（2026-08-18）：超时 abort 用 TimeoutError DOMException（对齐 fetch 规范，
    // Node≥17/浏览器均内置）。旧实现 abort(new Error('timeout'))——reason.name==='Error'，
    // callRpc catch 的 NETWORK_TIMEOUT 分支永不命中：超时被误报 NETWORK_ERROR
    // retryable:true（客户端会重试已超时请求，改名的"结果可能未知"提示也永不触发）。
    timer = setTimeout(() => ctrl.abort(new DOMException('请求超时', 'TimeoutError')), timeoutMs)
  }
  return {
    controller: ctrl,
    dispose() {
      if (timer !== undefined) clearTimeout(timer)
      if (external && onExternalAbort) external.removeEventListener('abort', onExternalAbort)
    },
  }
}

export interface FetchSnapshotOpts {
  signal?: AbortSignal
  timeoutMs?: number
  /** ARCH-03: 是否包含归档节点。false（默认）= host 端直接跳过归档节点的
   * 标题读取/子代理收集/布局，快照只含可见节点——归档多的工作区不再卡。 */
  includeArchived?: boolean
  /** 含归档首次加载允许先返回结构快照，完整标题在后台补齐。 */
  preferCached?: boolean
}

export async function fetchSnapshot(path: string, opts?: FetchSnapshotOpts): Promise<unknown> {
  const includeArchived = opts?.includeArchived === true
  // OPEN-02: 显式 timeoutMs 优先；否则按变体默认（含归档 = 45s，默认 = 10s）
  const timeoutMs = opts?.timeoutMs || (includeArchived ? SNAPSHOT_ARCHIVED_TIMEOUT_MS : SNAPSHOT_TIMEOUT_MS)
  return callRpc('brvis.snapshot', {
    path,
    includeArchived,
    ...(opts?.preferCached === true ? { preferCached: true } : {}),
  }, { signal: opts?.signal, timeoutMs })
}

// N3（2026-08-18）说明：`includeArchived` 是 snapshot **专用**请求字段，勿在其他
// mutation（rename/archive/archiveMany）调用中传入——host 端 /rename 等路由不消费
// 该字段，传了会被忽略。callRpc 只是通用同源 fetch 封装，args 原样透传给对应路由。

interface CallRpcOpts {
  signal?: AbortSignal
  timeoutMs?: number
}

export async function callRpc(name: string, args?: unknown, opts?: CallRpcOpts): Promise<unknown> {
  const method = name.replace(/^brvis\./, '')
  const { signal, timeoutMs } = opts || {}
  let res: Response
  const combined = combineSignal(signal, timeoutMs || MUTATION_TIMEOUT_MS)
  try {
    res = await fetch(ROUTE_PREFIX + '/' + method, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-brvis-request': '1',
      },
      body: JSON.stringify(args || {}),
      signal: combined.controller.signal,
    })
  } catch (e) {
    const err = (e && typeof e === 'object' ? e : {}) as { name?: string; message?: string }
    if (err.name === 'AbortError' || err.name === 'TimeoutError') {
      const error = new Error(err.message || '网络超时') as Error & { code?: string; retryable?: boolean }
      error.code = 'NETWORK_TIMEOUT'
      error.retryable = false
      throw error
    }
    const error = new Error('网络请求失败: ' + (err.message || '无法连接宿主')) as Error & { code?: string; retryable?: boolean }
    error.code = 'NETWORK_ERROR'
    error.retryable = true
    throw error
  } finally {
    combined.dispose()
  }
  let body: { ok?: boolean; data?: unknown; error?: { code?: string; message?: string; retryable?: boolean } } | null
  try {
    body = await res.json()
  } catch (e) {
    const error = new Error('宿主返回了无法解析的响应 (HTTP ' + res.status + ')') as Error & { code?: string; retryable?: boolean }
    error.code = 'BAD_RESPONSE'
    error.retryable = true
    throw error
  }
  if (body && body.ok === true) return body.data
  if (body && body.error) {
    const error = new Error(body.error.message || '操作失败') as Error & { code?: string; retryable?: boolean }
    error.code = body.error.code || 'UNKNOWN'
    error.retryable = !!body.error.retryable
    throw error
  }
  const error = new Error('宿主返回异常: ' + JSON.stringify(body).slice(0, 120)) as Error & { code?: string; retryable?: boolean }
  error.code = 'BAD_RESPONSE'
  error.retryable = true
  throw error
}
