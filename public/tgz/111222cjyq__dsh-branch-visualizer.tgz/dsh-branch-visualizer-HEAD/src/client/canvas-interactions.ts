/**
 * dsh-brvis — 画布交互（手势状态机 + 动作，拆分自 canvas.tsx，2026-08）。
 * 纯事件处理逻辑，不构建 React 元素。接收依赖注入（platform/timer/state/refs/setters/当前渲染快照）。
 * 每次渲染由 Canvas 组件调用工厂重建闭包（行为与旧内联一致：handler 依赖最新 nodes/pos/状态）。
 * 出错只看本文件 + canvas-geometry + api。
 */

import { callRpc } from './api.js'
import { hitNodeById, intersectNodes, fitViewCenter, type ViewState } from './canvas-geometry.js'
import { clamp, MIN_W, MIN_H } from './layout.js'
import type { DshClientServices } from '../shared/dsh-contract.js'

// ═══════════════════ 依赖类型（canvas.tsx 注入，见 makeCanvas 调用处） ═══════════════════

/** 画布节点快照中的最小形状（与 host 快照节点对齐；status 可缺省）。 */
export interface CanvasNode {
  id: string
  title: string
  parentId: string | null
  parentArchivedBridge?: boolean
  archived: boolean
  subagent: boolean
  subagentAddress: {
    parentSessionId: string
    childSessionId: string
    mode: string
  } | null
  status?: string
  createdAt?: number
}

/** 节点位置。 */
export interface NodePos { x: number; y: number }

/** 画布状态机（client/index.ts 单例 state 的类型形状）。 */
export interface BrvisStateLike {
  open: boolean
  currentSessionId: string | null
  selectedIds: Set<string>
  mode: number
  showArchived: boolean
  nodes: CanvasNode[]
  positions: Map<string, NodePos>
  circlePositions: Map<string, NodePos>
  view: ViewState
  viewScale: number
  set(partial: Record<string, unknown>): void
}

/** 拖拽状态（三种手势，靠 kind 判别）。AUD-07：绑定发起手势的 pointerId，
 * move/up 校验不匹配即忽略——多指触摸时第二指不再覆盖第一指手势。 */
export type DragState =
  | { kind: 'pan'; pointerId: number; sx: number; sy: number; ox: number; oy: number; moved: boolean }
  | { kind: 'node'; pointerId: number; id: string; sx: number; sy: number; ox: number; oy: number; moved: boolean; group: Array<{ id: string; ox: number; oy: number }> }
  | { kind: 'select'; pointerId: number; sx: number; sy: number; ox: number; oy: number; moved: boolean }

/** 面板拖拽状态。AUD-07：同样绑定 pointerId。 */
interface PanelDragState { pointerId: number; sx: number; sy: number; ox: number; oy: number }

/** 窗口缩放拖拽状态。 */
interface ResizeDragState {
  pointerId: number
  sx: number; sy: number
  ox: number; oy: number
  ow: number; oh: number
  corner: string
}

/** 全部 refs（React ref 集合，canvas.tsx 声明）。 */
export interface BrvisRefs {
  dragStateRef: { current: DragState | null }
  panelDragRef: { current: PanelDragState | null }
  resizeDragRef: { current: ResizeDragState | null }
  renamePendingRef: { current: boolean }
  archivePendingRef: { current: boolean }
  spaceDownRef: { current: boolean }
  lastDragMovedRef: { current: number }
  pointerDownNodeRef: { current: string | null }
  tapTimestampRef: { current: number }
  tapIdRef: { current: string | null }
  lastJumpRef: { current: { id: string; t: number } | null }
  bodyRef: { current: HTMLElement | null }
  panelRef: { current: HTMLElement | null }
  panelPosRef: { current: NodePos | null }
}

/** state setter 集合（React useState dispatch 包一层设置语义）。 */
export interface BrvisSetters {
  setError: (msg: string) => void
  setSelectBox: (box: { x: number; y: number; w: number; h: number } | null) => void
  setAutoLayoutBoth: (v: boolean) => void
  applyPanelPos: (pos: NodePos) => void
  setPanelSize: (size: { w: number; h: number }) => void
  setCompact: (v: boolean) => void
  setConfirmArchive: (v: boolean) => void
  setRenamingId: (id: string | null) => void
  setRenameValue: (v: string) => void
}

/** 当前渲染快照（每次渲染取最新值传入）。 */
export interface BrvisCurrent {
  nodes: CanvasNode[]
  pos: Map<string, NodePos>
  circleMode: boolean
  nodeW: number
  nodeH: number
  byId: Map<string, CanvasNode>
  ez: number
}

/** createCanvasInteractions 依赖注入形状。 */
export interface CanvasInteractionsDeps {
  platform: DshClientServices
  timer: unknown
  state: BrvisStateLike
  refs: BrvisRefs
  view: ViewState
  setters: BrvisSetters
  path: string
  current: BrvisCurrent
  renamingId: string | null
  renameValue: string
  COMPACT_W: number
  BASE_W: number
}

/** 会话导航服务（由 client adapter 提供）的最小形状。 */
interface SessionServiceLite {
  open?(id: string): unknown
  openSubagent?(addr: { parentSessionId: string; childSessionId: string; mode: string }): unknown
}

/** 可独立测试的导航适配器；兼容 DSH 方法同步或返回 Promise。 */
export async function openSessionTarget(sess: SessionServiceLite, id: string, node?: CanvasNode): Promise<void> {
  const addr = node && node.subagentAddress
  if (addr && typeof sess.openSubagent === 'function') {
    await Promise.resolve(sess.openSubagent(addr))
    return
  }
  if (typeof sess.open === 'function') {
    await Promise.resolve(sess.open(id))
    return
  }
  throw new Error('会话导航服务不可用')
}

/** 错误对象最小形状（RPC 抛错）。 */
interface RpcErrorLite { message?: string; code?: string }

function errMsg(e: unknown): string {
  const o = (e && typeof e === 'object' ? e : {}) as RpcErrorLite
  return o.message || '未知错误'
}

function errCode(e: unknown): string {
  const o = (e && typeof e === 'object' ? e : {}) as RpcErrorLite
  return o.code || 'UNKNOWN'
}

export function createCanvasInteractions(deps: CanvasInteractionsDeps) {
  const { platform, state, refs, view, setters, path } = deps
  // 每次渲染传入的当前快照（nodes/pos/circleMode/nodeW/nodeH/byId/ez）
  const cur = deps.current

  // ============ 双击跳转（画布保持打开，仅高亮当前会话） ============
  const jumpToSession = async (id: string) => {
    if (refs.dragStateRef.current && refs.dragStateRef.current.moved) return
    if (Date.now() - refs.lastDragMovedRef.current < 350) return
    const now = Date.now()
    if (refs.lastJumpRef.current && refs.lastJumpRef.current.id === id && now - refs.lastJumpRef.current.t < 500) return
    const sess = platform.sessions as SessionServiceLite | undefined
    if (!sess || (typeof sess.open !== 'function' && typeof sess.openSubagent !== 'function')) {
      setters.setError('跳转失败: 会话导航服务不可用')
      return
    }
    try {
      // 子代理跳转（真实契约）：open(id) 只打开 list 里的常规会话；子代理是独立 session，
      // 必须 openSubagent({parentSessionId, childSessionId, mode})。
      // 地址直接取快照节点自带 subagentAddress（host 侧 listChildren 契约下发），
      // 不依赖 client runtime 的目录保留状态——已归档子代理（官方自动归档）同样能打开。
      const node = cur.byId.get(id)
      // 未命中子代理地址→常规会话；Promise 拒绝必须在这里被 catch，
      // 成功后才更新当前节点，避免界面与 DSH 实际会话不同步。
      await openSessionTarget(sess, id, node)
      refs.lastJumpRef.current = { id, t: now }
      state.set({ currentSessionId: id, selectedIds: new Set() })
    } catch (err) {
      console.error('[brvis] open session failed')
      setters.setError('跳转失败: ' + errMsg(err))
    }
  }

  // ============ 背景 pointer（命中/拖拽/框选/双击计数） ============
  const onBgPointerDown = (ev: ReactPointerEventLike) => {
    if (ev.button !== 0) return
    setters.setConfirmArchive(false)
    ev.currentTarget.setPointerCapture(ev.pointerId)
    const rect = refs.bodyRef.current ? refs.bodyRef.current.getBoundingClientRect() : { left: 0, top: 0 }
    // AUD-01：有效缩放取 cur.ez（= zoom * viewScale，canvas.tsx:105）——view 上没有 viewScale
    refs.pointerDownNodeRef.current = hitNodeById(ev, cur.nodes, cur.pos, cur.circleMode, view, rect, cur.ez)
    const px = ev.clientX - rect.left
    const py = ev.clientY - rect.top
    if (ev.altKey || refs.spaceDownRef.current) {
      refs.dragStateRef.current = { kind: 'pan', pointerId: ev.pointerId, sx: ev.clientX, sy: ev.clientY, ox: view.x, oy: view.y, moved: false }
      return
    }
    // 命中检测已在 pointerDownNodeRef 完成（hitNodeById：同样的 HIT_PAD 几何）——
    // 此处直接复用，不再二次遍历节点找命中。
    const hitId = refs.pointerDownNodeRef.current
    if (hitId) {
      const key = cur.circleMode ? 'circlePositions' : 'positions'
      const map = state[key]
      const p = map.get(hitId) || { x: 0, y: 0 }
      let group: string[]
      if (state.selectedIds.has(hitId)) {
        group = [...state.selectedIds]
      } else {
        group = [hitId]
        state.set({ selectedIds: new Set([hitId]) })
      }
      const base: Array<{ id: string; ox: number; oy: number }> = []
      for (const gid of group) {
        const gp = map.get(gid)
        if (gp) base.push({ id: gid, ox: gp.x, oy: gp.y })
      }
      if (base.length === 0) base.push({ id: hitId, ox: p.x, oy: p.y })
      refs.dragStateRef.current = { kind: 'node', pointerId: ev.pointerId, id: hitId, sx: ev.clientX, sy: ev.clientY, ox: p.x, oy: p.y, moved: false, group: base }
      return
    }
    refs.dragStateRef.current = { kind: 'select', pointerId: ev.pointerId, sx: ev.clientX, sy: ev.clientY, ox: px, oy: py, moved: false }
    setters.setSelectBox({ x: px, y: py, w: 0, h: 0 })
  }

  const onBgPointerMove = (ev: ReactPointerEventLike) => {
    const drag = refs.dragStateRef.current
    // AUD-07：pointerId 不匹配时忽略——多指触摸时第二指不应影响第一指的拖拽/框选
    if (!drag || drag.pointerId !== ev.pointerId) return
    if (drag.kind === 'pan') {
      const dx = ev.clientX - drag.sx
      const dy = ev.clientY - drag.sy
      if (Math.abs(dx) + Math.abs(dy) > 3) {
        refs.dragStateRef.current = { ...drag, moved: true }
        refs.pointerDownNodeRef.current = null
        refs.lastDragMovedRef.current = Date.now()
        state.set({ view: { ...state.view, x: drag.ox + dx, y: drag.oy + dy } })
      }
      return
    }
    if (drag.kind === 'node') {
      // AUD-01：有效缩放取 cur.ez（view 上没有 viewScale，旧换算在窄面板下拖拽位移失真）
      const curEz = cur.ez
      const dx = (ev.clientX - drag.sx) / curEz
      const dy = (ev.clientY - drag.sy) / curEz
      if (Math.abs(ev.clientX - drag.sx) + Math.abs(ev.clientY - drag.sy) > 3) {
        refs.dragStateRef.current = { ...drag, moved: true }
        refs.pointerDownNodeRef.current = null
        refs.lastDragMovedRef.current = Date.now()
        setters.setAutoLayoutBoth(false)
        const key = cur.circleMode ? 'circlePositions' : 'positions'
        const next = new Map(state[key])
        for (const g of drag.group) {
          next.set(g.id, { x: g.ox + dx, y: g.oy + dy })
        }
        state.set({ [key]: next })
      }
      return
    }
    const rect = refs.bodyRef.current ? refs.bodyRef.current.getBoundingClientRect() : { left: 0, top: 0 }
    const cx = ev.clientX - rect.left
    const cy = ev.clientY - rect.top
    if (Math.abs(cx - drag.ox) + Math.abs(cy - drag.oy) > 3) {
      refs.dragStateRef.current = { ...drag, moved: true }
      refs.pointerDownNodeRef.current = null
      refs.lastDragMovedRef.current = Date.now()
    }
    const x0 = Math.min(drag.ox, cx)
    const y0 = Math.min(drag.oy, cy)
    const w = Math.abs(cx - drag.ox)
    const h = Math.abs(cy - drag.oy)
    setters.setSelectBox({ x: x0, y: y0, w, h })
    // AUD-01：框选同用 cur.ez（view.viewScale 恒 undefined，旧换算在窄面板下框选错位）
    const curEz = cur.ez
    const hitIds = intersectNodes(x0, y0, w, h, cur.nodes, cur.pos, cur.nodeW, cur.nodeH, curEz, view.x, view.y)
    state.set({ selectedIds: new Set(hitIds) })
  }

  const onBgPointerUp = (ev: ReactPointerEventLike) => {
    const drag = refs.dragStateRef.current
    // AUD-07：pointerId 不匹配时忽略——触摸被系统打断（来电/手势接管）后抬起的是
    // 与起始不同的 pointer，不应复位本手势状态。
    if (!drag || drag.pointerId !== ev.pointerId) return
    const wasDrag = drag && drag.moved
    if (drag && drag.kind === 'select' && !drag.moved) {
      state.set({ selectedIds: new Set() })
    }
    const hitId = refs.pointerDownNodeRef.current
    // 无论是否拖动都复位命中记录（指针已抬起，本帧的选择/双击判定已完成）
    refs.pointerDownNodeRef.current = null
    if (hitId && !wasDrag) {
      const now = Date.now()
      const lastTap = refs.tapTimestampRef.current
      const lastTapId = refs.tapIdRef.current
      refs.tapTimestampRef.current = now
      refs.tapIdRef.current = hitId
      if (lastTap && lastTapId === hitId && now - lastTap <= 400) {
        if (now - refs.lastDragMovedRef.current > 350) jumpToSession(hitId)
      }
    }
    refs.dragStateRef.current = null
    setters.setSelectBox(null)
    // AUD-08：统一清除 .is-clicked（按下放大+亮起的临时 class）。
    // setPointerCapture 后节点的 onPointerUp/onPointerCancel 不再触发（canvas-elements.tsx
    // 里的 up/cancel 清除逻辑失效），若不清除，单击已选中节点时该 class 永久残留。
    const bodyEl = refs.bodyRef.current
    if (bodyEl) {
      const clicked = bodyEl.querySelectorAll('.is-clicked')
      for (let i = 0; i < clicked.length; i++) clicked[i].classList.remove('is-clicked')
    }
  }

  // AUD-06（2026-08-18）：pointercancel 处理——触摸被系统打断（来电/系统手势接管）时
  // pointerup 不触发，复用 onBgPointerUp 的复位逻辑（pointerId 匹配校验天然放行）。
  const onBgPointerCancel = (ev: ReactPointerEventLike) => {
    onBgPointerUp(ev)
  }

  // ============ 面板拖动 ============
  const onTitlePointerDown = (ev: ReactPointerEventLike) => {
    if (ev.button !== 0) return
    let t = ev.target as HTMLElement | null
    while (t && t !== ev.currentTarget) {
      if (t.tagName === 'BUTTON') return
      t = t.parentElement
    }
    ev.currentTarget.setPointerCapture(ev.pointerId)
    const rect = refs.panelRef.current ? refs.panelRef.current.getBoundingClientRect() : { left: 0, top: 0, width: 800, height: 60 }
    const curPos = refs.panelPosRef.current
    refs.panelDragRef.current = { pointerId: ev.pointerId, sx: ev.clientX, sy: ev.clientY, ox: curPos ? curPos.x : rect.left, oy: curPos ? curPos.y : rect.top }
  }
  const onTitlePointerMove = (ev: ReactPointerEventLike) => {
    const rs = refs.panelDragRef.current
    if (!rs || rs.pointerId !== ev.pointerId) return
    const panelRect = refs.panelRef.current ? refs.panelRef.current.getBoundingClientRect() : { width: 800, height: 60 }
    const nx = rs.ox + (ev.clientX - rs.sx)
    const ny = rs.oy + (ev.clientY - rs.sy)
    // AUD-10（2026-08-18）：面板拖出视口不可回收——至少留标题栏一条边在视口内。
    // 复用 resize 监听器的 clamp 语义（pad=8），但宽宽松一些（标题栏高阈值）。
    const vw = window.innerWidth
    const vh = window.innerHeight
    const pad = 8
    const minVisibleW = 100
    const minVisibleH = Math.min(60, panelRect.height)
    const clampedX = Math.max(pad - panelRect.width + minVisibleW, Math.min(nx, vw - minVisibleW))
    const clampedY = Math.max(pad - panelRect.height + minVisibleH, Math.min(ny, vh - minVisibleH))
    setters.applyPanelPos({ x: Math.round(clampedX), y: Math.round(clampedY) })
  }
  const onTitlePointerUp = (ev: ReactPointerEventLike) => {
    if (refs.panelDragRef.current && refs.panelDragRef.current.pointerId === ev.pointerId) refs.panelDragRef.current = null
  }

  // ============ 窗口缩放（三手柄） ============
  const onResizePointerDown = (ev: ReactPointerEventLike, corner: string) => {
    if (ev.button !== 0) return
    ev.stopPropagation()
    ev.currentTarget.setPointerCapture(ev.pointerId)
    const rect = refs.panelRef.current ? refs.panelRef.current.getBoundingClientRect() : { left: 0, top: 0, width: 800, height: 540 }
    refs.resizeDragRef.current = { pointerId: ev.pointerId, sx: ev.clientX, sy: ev.clientY, ox: rect.left, oy: rect.top, ow: rect.width, oh: rect.height, corner }
  }
  const onResizePointerMove = (ev: ReactPointerEventLike) => {
    const rs = refs.resizeDragRef.current
    if (!rs || rs.pointerId !== ev.pointerId) return
    const dx = ev.clientX - rs.sx
    const dy = ev.clientY - rs.sy
    let l = rs.ox
    let t = rs.oy
    let w = rs.ow
    let h = rs.oh
    if (rs.corner === 'se') { w += dx; h += dy }
    else if (rs.corner === 'sw') { l += dx; w -= dx; h += dy }
    else { l += dx; t += dy; w -= dx; h -= dy }
    if (w < MIN_W) {
      if (rs.corner !== 'se') l = rs.ox + rs.ow - MIN_W
      w = MIN_W
    }
    if (h < MIN_H) {
      if (rs.corner !== 'se') t = rs.oy + rs.oh - MIN_H
      h = MIN_H
    }
    // AUD-10（2026-08-18）：resize 移动同样夹紧视口（标题栏一条边留在视口内）——
    // 旧实现只在 window resize 时 clamp，拖手柄把面板推出视口后无法恢复。
    const vw = window.innerWidth
    const vh = window.innerHeight
    const pad = 8
    const minVisibleW = 100
    const minVisibleH = 60
    l = Math.max(pad - w + minVisibleW, Math.min(l, vw - minVisibleW))
    t = Math.max(pad - h + minVisibleH, Math.min(t, vh - minVisibleH))
    const finalW = Math.round(w)
    const finalH = Math.round(h)
    setters.setCompact(finalW < deps.COMPACT_W)
    setters.setConfirmArchive(false)
    state.set({ viewScale: clamp(finalW / deps.BASE_W, 0.32, 1) })
    setters.applyPanelPos({ x: Math.round(l), y: Math.round(t) })
    setters.setPanelSize({ w: finalW, h: finalH })
  }
  const onResizePointerUp = (ev: ReactPointerEventLike) => {
    if (refs.resizeDragRef.current && refs.resizeDragRef.current.pointerId === ev.pointerId) {
      refs.resizeDragRef.current = null
      if (cur.circleMode) {
        centerOnNodes(state.circlePositions)
      }
    }
  }

  // ============ 改名 ============
  const startRename = (id: string) => {
    if (refs.dragStateRef.current && refs.dragStateRef.current.moved) return
    if (!id) return
    const n = cur.byId.get(id)
    setters.setRenamingId(id)
    setters.setRenameValue(n ? n.title : '')
  }
  const commitRename = async () => {
    const id = deps.renamingId
    const value = deps.renameValue.trim()
    if (!id || !value) { setters.setRenamingId(null); return }
    if (refs.renamePendingRef.current) return
    refs.renamePendingRef.current = true
    try {
      const data = await callRpc('brvis.rename', { sessionId: id, title: value, path })
      const finalTitle = (data && typeof data === 'object' && (data as { title?: string }).title) || value
      setters.setRenamingId(null)
      state.set({ nodes: state.nodes.map((n) => (n.id === id ? { ...n, title: finalTitle } : n)) })
    } catch (err) {
      console.error('[brvis] rename failed')
      // BUGFIX-03: 失败也关闭改名浮层——否则输入框残留,每次 blur 都重复触发
      // commitRename(失败后输入框失去焦点,再点其他区域又触发一次),错误信息
      // 已由状态栏显示,用户可重新点「改名」重试。
      setters.setRenamingId(null)
      const code = errCode(err)
      setters.setError('重命名失败: ' + errMsg(err) + (code === 'NETWORK_TIMEOUT' ? '(结果可能未知,建议刷新快照)' : ' (可重试)'))
    } finally {
      refs.renamePendingRef.current = false
    }
  }

  // ============ 归档 ============
  const archiveSelected = async () => {
    const ids = [...state.selectedIds]
    if (!ids.length || refs.archivePendingRef.current) return
    refs.archivePendingRef.current = true
    try {
      const data = await callRpc('brvis.archiveMany', { path, sessionIds: ids })
      const results = (data && typeof data === 'object' && (data as { results?: unknown }).results) || []
      const arr = Array.isArray(results) ? results as Array<{ sessionId: string; ok?: boolean; code?: string | null }> : []
      const okIds = new Set(arr.filter((r) => r && r.ok).map((r) => r.sessionId))
      const failList = arr.filter((r) => r && !r.ok)
      state.set({
        nodes: state.nodes.map((n) => (okIds.has(n.id) ? { ...n, archived: true } : n)),
        selectedIds: new Set(failList.map((r) => r.sessionId)),
      })
      if (failList.length) {
        setters.setError('已归档 ' + okIds.size + ' 项, ' + failList.length + ' 项失败:' +
          failList.slice(0, 3).map((r) => ' ' + r.sessionId + ' (' + (r.code || 'ARCHIVE_FAILED') + ')').join(',') +
          (failList.length > 3 ? ' …' : ''))
      } else {
        // AUD-11（2026-08-18）：级联项失败不再静默——父归档成功但某后代子代理
        // 归档抛错时会透出 cascadeFailedCount>0，前端提示「部分子代理未归档」。
        const rawData = data && typeof data === 'object' ? data as { cascadeFailedCount?: number } : undefined
        const cascadeFailed = rawData && typeof rawData.cascadeFailedCount === 'number' ? rawData.cascadeFailedCount : 0
        if (cascadeFailed > 0) {
          setters.setError('已归档 ' + okIds.size + ' 项, 但 ' + cascadeFailed + ' 个子代理未归档（请检查其状态后重试）')
        }
      }
      // 两端同步：成功项补调官方 workspaces.archiveSession，官方 runtime installArchived 立即隐藏
      const wsSvc = platform.workspaces
      if (wsSvc && typeof wsSvc.archiveSession === 'function') {
        for (const sid of okIds) {
          try {
            const p = wsSvc.archiveSession(sid)
            if (p && typeof (p as { catch?: unknown }).catch === 'function') (p as { catch: (fn: () => void) => unknown }).catch(() => { /* official sync */ })
          } catch (e) { /* ignore */ }
        }
      }
    } catch (err) {
      console.error('[brvis] archive failed')
      setters.setError('归档失败: ' + errMsg(err))
    } finally {
      refs.archivePendingRef.current = false
    }
  }

  // ============ 视图 ============
  const zoomBy = (factor: number) => {
    const z = clamp(state.view.zoom * factor, 0.25, 2.5)
    state.set({ view: { ...state.view, zoom: z } })
  }
  // ARCH-02: 聚焦视图只计算"当前可见"节点的边界——隐藏归档时归档节点不参与
  // 边界估算，否则"缩小集中展示"会把隐藏归档一起算进去（用户实测缺陷）。
  const centerOnNodes = (map: Map<string, NodePos>) => {
    const el = refs.bodyRef.current
    if (!el || !map || map.size === 0) return
    const rect = el.getBoundingClientRect()
    const z = state.view.zoom * (state.viewScale || 1)
    const visibleIds = new Set(cur.nodes.map((n) => n.id))
    const fitMap = new Map<string, NodePos>()
    for (const [id, p] of map) if (visibleIds.has(id)) fitMap.set(id, p)
    if (fitMap.size === 0) return
    const fit = fitViewCenter(rect.width, rect.height, fitMap, z)
    state.set({ view: { ...state.view, x: fit.x, y: fit.y } })
  }

  return {
    jumpToSession, centerOnNodes,
    onBgPointerDown, onBgPointerMove, onBgPointerUp, onBgPointerCancel,
    onTitlePointerDown, onTitlePointerMove, onTitlePointerUp,
    onResizePointerDown, onResizePointerMove, onResizePointerUp,
    startRename, commitRename, archiveSelected, zoomBy,
  }
}

/**
 * React PointerEvent 在 .ts 文件中的最小形状（.tsx 组件回传给本模块时是
 * React.PointerEvent，此处用结构兼容的最小接口，避免 .ts 依赖 React JSX 命名空间）。
 * currentTarget 用 Element：react 类型里是 EventTarget & T，Element 已含 setPointerCapture。
 */
export interface ReactPointerEventLike {
  button?: number
  altKey?: boolean
  clientX: number
  clientY: number
  pointerId: number
  stopPropagation(): void
  currentTarget: Element
  target: EventTarget | null
}
