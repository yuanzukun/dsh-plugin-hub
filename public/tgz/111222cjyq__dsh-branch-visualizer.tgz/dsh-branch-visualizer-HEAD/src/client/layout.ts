/**
 * dsh-brvis — 树布局与连线计算（纯函数，无 React/DOM 依赖）。
 * 拆分自原单文件 client/index.ts（2026-08）：布局算法独立成模块，
 * 出错只需读本文件，不影响 apply 装配与状态机。
 */

export const NODE_W = 168
export const NODE_H = 54
export const SIB_GAP = 40
export const LEVEL_GAP = 78
export const CIRCLE_D = 34
export const CIRCLE_SIB = 24
export const CIRCLE_LEVEL = 46
export const CIRCLE_ZOOM = 0.6
export const MIN_W = 420
export const MIN_H = 320
export const COMPACT_W = 640
export const BASE_W = 820

export function clamp(v: number, lo: number, hi: number): number { return v < lo ? lo : (v > hi ? hi : v) }

/** 画布节点（布局输入的最小形状）。 */
export interface LayoutNode {
  id: string
  parentId: string | null
  parentArchivedBridge?: boolean
  archived?: boolean
}

/** 边（连线计算输出）。 */
export interface Edge {
  from: string
  to: string
  dashed: boolean
  doubleDashed?: boolean
}

/** 树形布局：叶子从左到右排，父节点取子树中点（经典 tidy-tree 简化版）。 */
export function layoutTree(nodes: LayoutNode[], w: number, h: number, sib: number, level: number): Map<string, { x: number; y: number }> {
  const byId = new Map<string, LayoutNode>()
  for (const n of nodes) byId.set(n.id, n)
  const children = new Map<string, string[]>()
  for (const n of nodes) children.set(n.id, [])
  const roots: string[] = []
  for (const n of nodes) {
    if (n.parentId && byId.has(n.parentId)) children.get(n.parentId)!.push(n.id)
    else roots.push(n.id)
  }
  const depth = new Map<string, number>()
  const queue: string[] = []
  for (const r of roots) { depth.set(r, 0); queue.push(r) }
  for (let i = 0; i < queue.length; i++) {
    const id = queue[i]
    for (const c of children.get(id)!) { depth.set(c, depth.get(id)! + 1); queue.push(c) }
  }
  const leafCounter = { v: 0 }
  const xPos = new Map<string, number>()
  const visited = new Set<string>()
  function assignX(id: string): void {
    if (visited.has(id)) return
    visited.add(id)
    const kids = children.get(id)!
    if (kids.length === 0) {
      xPos.set(id, leafCounter.v * (w + sib))
      leafCounter.v += 1
      return
    }
    let min = Infinity, max = -Infinity
    for (const k of kids) { assignX(k); min = Math.min(min, xPos.get(k)!); max = Math.max(max, xPos.get(k)!) }
    xPos.set(id, (min + max) / 2)
  }
  for (const r of roots) assignX(r)
  for (const n of nodes) if (!visited.has(n.id)) assignX(n.id)
  const pos = new Map<string, { x: number; y: number }>()
  for (const n of nodes) {
    const d = depth.has(n.id) ? depth.get(n.id)! : 0
    // P2（2026-08-18）：`?? 0` 显式化——parent 环时 xPos.get 可能 undefined，
    // 旧 `|| 0` 把合法 0 也兜底（行为巧合正确），`?? 0` 只对 undefined 生效。
    pos.set(n.id, { x: xPos.get(n.id) ?? 0, y: d * (h + level) })
  }
  return pos
}

/**
 * 连线计算（含归档模式）。
 * mode 1 = 归档节点连线变虚线，整体形态保留；mode 2 = 连线完全断开，子树独立。
 * 模式1+隐藏归档时生成"旁路双虚线"：可见节点沿父链跳过归档祖先连到最近可见祖先。
 */
export function computeEdges(nodes: LayoutNode[], mode: number, showArchived: boolean): Edge[] {
  const byId = new Map<string, LayoutNode>()
  for (const n of nodes) byId.set(n.id, n)
  const archived = new Set<string>()
  for (const n of nodes) if (n.archived) archived.add(n.id)
  const edges: Edge[] = []
  for (const n of nodes) {
    if (!n.parentId || !byId.has(n.parentId)) continue
    if (n.parentArchivedBridge) {
      if (mode === 1) edges.push({ from: n.parentId, to: n.id, dashed: false, doubleDashed: true })
      continue
    }
    const parent = byId.get(n.parentId)!
    const parentArchived = archived.has(parent.id)
    const selfArchived = archived.has(n.id)
    const involved = parentArchived || selfArchived
    if (mode === 1) {
      edges.push({ from: parent.id, to: n.id, dashed: involved })
    } else {
      if (!involved) edges.push({ from: parent.id, to: n.id, dashed: false })
    }
  }
  if (mode === 1 && !showArchived) {
    for (const n of nodes) {
      if (n.archived || n.parentArchivedBridge || !n.parentId || !byId.has(n.parentId)) continue
      const firstParent = byId.get(n.parentId)!
      if (!firstParent.archived) continue
      let ancestor: LayoutNode | undefined = firstParent
      const seenAnc = new Set<string>()
      while (ancestor && ancestor.archived && !seenAnc.has(ancestor.id)) {
        seenAnc.add(ancestor.id)
        if (!ancestor.parentId || !byId.has(ancestor.parentId)) break
        ancestor = byId.get(ancestor.parentId)
      }
      const nearestVisible = ancestor && !ancestor.archived ? ancestor : null
      if (nearestVisible) {
        edges.push({ from: nearestVisible.id, to: n.id, dashed: false, doubleDashed: true })
      }
    }
  }
  return edges
}
