/**
 * dsh-brvis — 共享 wire contract（CONTRACT-01）。
 * Host 与 Client 共同引用的类型、错误码、路由常量。
 * 业务源文件只从本模块取契约，避免各自手写字符串。
 */

// ============ RPC 统一契约 ============

export const BrvisErrorCode = {
  BAD_REQUEST: 'BAD_REQUEST',
  INVALID_TITLE: 'INVALID_TITLE',
  WORKSPACE_UNAVAILABLE: 'WORKSPACE_UNAVAILABLE',
  SESSION_NOT_FOUND: 'SESSION_NOT_FOUND',
  SESSION_OUTSIDE_WORKSPACE: 'SESSION_OUTSIDE_WORKSPACE',
  SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE',
  SEQUENCE_CONFLICT: 'SEQUENCE_CONFLICT',
  ARCHIVE_FAILED: 'ARCHIVE_FAILED',
  INTERNAL_ERROR: 'INTERNAL_ERROR',
  // HTTP-01：传输层/安全边界（共享，client 据此提示）
  FORBIDDEN: 'FORBIDDEN',
  METHOD_NOT_ALLOWED: 'METHOD_NOT_ALLOWED',
  UNSUPPORTED_MEDIA_TYPE: 'UNSUPPORTED_MEDIA_TYPE',
  PAYLOAD_TOO_LARGE: 'PAYLOAD_TOO_LARGE',
  NOT_FOUND: 'NOT_FOUND',
} as const

export type BrvisErrorCodeValue = (typeof BrvisErrorCode)[keyof typeof BrvisErrorCode]

export const ROUTE_PREFIX = '/brvis/api'

// ============ RPC 响应 ============

export interface RpcError {
  code: BrvisErrorCodeValue
  message: string
  retryable: boolean
}

export type RpcResult<T> =
  | { ok: true; data: T }
  | { ok: false; error: RpcError }

export type RpcFailure = (code: BrvisErrorCodeValue, message: string, retryable?: boolean) => RpcResult<never>
export type RpcSuccess = <T>(data: T) => RpcResult<T>

// ============ 节点/快照 ============

/** 节点运行状态（client 渲染三态：脉冲/静止/无色）。 */
export type NodeStatus = 'running' | 'idle' | 'cold'

/** 子代理地址（官方契约 SubagentAddress，随快照下发，client 双击直接用）。 */
export interface SubagentAddressWire {
  parentSessionId: string
  childSessionId: string
  mode: 'one-shot' | 'continuable'
}

/** 画布节点（host 权威构建）。 */
export interface BrvisNode {
  id: string
  title: string
  parentId: string | null
  /** 隐藏归档节点时，parentId 是否已被 host 重连到最近可见祖先。 */
  parentArchivedBridge: boolean
  archived: boolean
  subagent: boolean
  subagentAddress: SubagentAddressWire | null
  status: NodeStatus
  createdAt: number
}

/** 快照 payload：按工作区独立缓存，签名含全部视觉字段（含 status，STATUS-01）。 */
export interface SnapshotPayload {
  workspace: string
  generatedAt: number
  nodes: BrvisNode[]
  /** true 表示先返回结构/缓存标题，完整标题与子代理元数据正在后台补齐。 */
  hydrating?: boolean
}

/** 单节点（默认值工厂，供测试/降级构造）。 */
export function makeNode(fields?: Partial<BrvisNode>): BrvisNode {
  return {
    id: '',
    title: '',
    parentId: null,
    parentArchivedBridge: false,
    archived: false,
    subagent: false,
    // 子代理跳转地址（官方契约 SubagentAddress）：{parentSessionId, childSessionId, mode}。
    // host 侧 listChildren 契约下发；非子代理为 null。
    subagentAddress: null,
    status: 'cold', // 'running' | 'idle' | 'cold'
    createdAt: 0,
    ...(fields || {}),
  }
}

/** 快照 payload 默认值工厂（供测试/降级构造）。 */
export function makeSnapshotPayload(fields?: Partial<SnapshotPayload>): SnapshotPayload {
  return {
    workspace: '',
    generatedAt: 0,
    nodes: [],
    ...(fields || {}),
  }
}

// ============ mutation 请求/结果 ============

export interface ArchiveItemResult {
  sessionId: string
  ok: boolean
  code: BrvisErrorCodeValue | null
  /** 单归档成功附加字段（archiveNode 兼容旧前端） */
  archived?: boolean
}

/** archiveMany 逐项结果（并发执行、逐项成败、失败项保持选中）。 */
export function makeArchiveResult(fields?: Partial<ArchiveItemResult>): ArchiveItemResult {
  return {
    sessionId: '',
    ok: false,
    code: null,
    ...(fields || {}),
  }
}

export interface ArchiveManyPayload {
  results: (ArchiveItemResult | undefined)[]
  succeededCount: number
  failedCount: number
  /** AUD-11（2026-08-18）：级联归档（父节点的后代子代理）失败的项数。
   * 级联项不进入 results（前端只关心选中项），但失败必须可见——
   * 父归档成功、某后代子代理归档抛错时，被级联的子代理仍留在工作区，
   * 前端据此提示「部分子代理未归档」。 */
  cascadeFailedCount: number
}
