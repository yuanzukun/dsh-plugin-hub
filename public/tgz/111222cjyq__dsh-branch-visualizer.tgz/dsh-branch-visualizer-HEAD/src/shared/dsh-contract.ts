/**
 * dsh-brvis — DSH 运行时契约类型（COMPAT-01 类型化）。
 * 集中声明业务层依赖的 DSH 服务形状（sessionQuery / sessionPersistence / sessionTitle /
 * sessions / workspaceRegistry / subagents / agents / timer）与 wire DTO。
 *
 * 真实类型来源：node_modules/@deepseek-ai/dsh-*（本模块按业务实际用法收敛，
 * 只声明被消费的最小字段——不追求完整镜像 DSH 类型，避免漂移面扩大）。
 * 新增 DSH 版本适配时优先更新 platform/adapters/，本模块保持稳定。
 */

// ═══════════════ 会话 ═══════════════

export interface SessionHeader {
  id: string
  cwd?: string
  parentSession?: string
  createdAt?: number
  /** client 侧 title 快照回填的字段（readTitleSnapshots 结果） */
  title?: string
}

export interface SessionRecord {
  header?: SessionHeader
  [key: string]: unknown
}

export interface SessionTitleEvent {
  seq: number
  type: string
  time?: number
  data?: { title?: string; messageSeqs?: unknown[]; source?: unknown }
  [key: string]: unknown
}

export interface SessionLog {
  events?: SessionTitleEvent[]
  [key: string]: unknown
}

export interface TitleSnapshotResult {
  status?: string
  sessionId?: string
  value?: { title?: { title?: string } }
  [key: string]: unknown
}

// ═══════════════ 子代理（官方契约 SubagentListEntry / SubagentAddress） ═══════════════

export type SubagentMode = 'one-shot' | 'continuable'
export type SubagentActivity = 'running' | 'inactive'

export interface SubagentListEntry {
  kind?: 'child' | 'diagnostic'
  id: string
  mode: SubagentMode
  activity: SubagentActivity
  hasChildren?: boolean
  label?: string
  [key: string]: unknown
}

export interface SubagentDescendantEntry extends SubagentListEntry {
  parentId?: string
  depth?: number
}

export interface SubagentAddress {
  parentSessionId: string
  childSessionId: string
  mode: SubagentMode
}

export interface SubagentStartRequest {
  label?: string
  prompt: unknown[]
  parent: unknown
  signal?: AbortSignal
  agentOptions?: Record<string, unknown>
  outputSchema?: Record<string, unknown>
}

// ═══════════════ Agent ═══════════════

export type AgentStatus = 'running' | 'idle'

export interface AgentEntry {
  id?: string
  status?: AgentStatus
  session?: { id?: string }
  phase?: unknown
  [key: string]: unknown
}

/** Agent 状态事件（agent/status | agent/created | agent/disposed 的 payload 形状） */
export interface AgentEventPayload {
  agent?: AgentEntry
  status?: AgentStatus
  [key: string]: unknown
}

// ═══════════════ 各服务接口（最小用法） ═══════════════

export interface SessionQueryService {
  listSessions(): Promise<SessionRecord[]>
  readTitleSnapshots?(ids?: string[]): Promise<TitleSnapshotResult[]>
  readSession?(sessionId: string): Promise<SessionLog | null>
}

export interface SessionPersistenceService {
  append(sessionId: string, events: SessionTitleEvent[]): Promise<unknown>
}

export interface SessionTitleService {
  rename?(session: unknown, title: string): unknown
}

export interface WorkspaceRegistryService {
  archiveSession(sessionId: string): Promise<unknown>
  archivedSessionIds?: readonly string[]
  resolveByPath?(path: string): unknown
  list?(): unknown
}

export interface SubagentsService {
  listChildren(parentId: string, signal?: AbortSignal): Promise<SubagentListEntry[]>
  listDescendants?(rootId: string, signal?: AbortSignal): Promise<SubagentDescendantEntry[]>
  start?(name: string, request: SubagentStartRequest): Promise<unknown>
}

export interface AgentsService {
  list?(): AgentEntry[]
  get?(id: string): AgentEntry | undefined
}

export interface TimerService {
  timeout(ms: number): Promise<unknown>
}

/** Host 适配器产出的全部 DSH 服务句柄（缺失的为 undefined，业务做降级）。 */
export interface DshHostServices {
  sessionQuery?: SessionQueryService
  sessionPersistence?: SessionPersistenceService
  sessionTitle?: SessionTitleService
  sessions?: unknown
  workspaceRegistry?: WorkspaceRegistryService
  subagents?: SubagentsService
  agents?: AgentsService
  timer?: TimerService
  on?(event: string, listener: (payload: unknown) => void): (() => void) | undefined
}

// ═══════════════ client 服务（sessions / workspaces） ═══════════════

export interface ClientSessionsService {
  open?(id: string): Promise<unknown>
  openSubagent?(address: SubagentAddress): Promise<unknown>
}

export interface ClientWorkspacesService {
  archiveSession?(sessionId: string): Promise<unknown>
}

/** Client adapter 统一产出的 DSH 服务句柄。 */
export interface DshClientServices {
  slots?: unknown
  timer?: unknown
  sessions?: ClientSessionsService
  workspaces?: ClientWorkspacesService
}
