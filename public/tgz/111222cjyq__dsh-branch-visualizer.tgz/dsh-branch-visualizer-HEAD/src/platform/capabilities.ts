/**
 * dsh-brvis — capabilities 探测（COMPAT-01）。
 * 只做无副作用探测：检查服务/方法/事件是否存在，绝不调用 mutation。
 * 文档：DSH_COMPATIBILITY_STRATEGY.md §2.4、§8.2-8.3。
 */

// 7.5（2026-08-18）：常量迁自 platform/ports/host-platform.ts（原三个 ports 文件已删除）
import { HostCapabilityState, AgentStatusSource, type HostCapabilities } from './const.js'
import type { DshHostServices } from '../shared/dsh-contract.js'

/**
 * 探测 host adapter 暴露的能力（只查形状，不调用）。
 */
export function probeHostCapabilities(platform: DshHostServices | undefined): HostCapabilities {
  const cap: HostCapabilities = {
    sessionRead: HostCapabilityState.MISSING,
    titleRead: HostCapabilityState.MISSING,
    liveRename: HostCapabilityState.MISSING,
    coldRename: HostCapabilityState.MISSING,
    archive: HostCapabilityState.MISSING,
    agentStatus: AgentStatusSource.MISSING,
    subagents: 'missing',
    workspaceIdentity: 'string-fallback',
  }
  if (!platform) return cap

  const sessionQuery = platform.sessionQuery
  // AUD-16（2026-08-18）：sessionRead 只判 listSessions（readTitleSnapshots 是可选增强，
  // 缺失不影响会话读取；旧代码把两者捆绑 → 有 listSessions 无 readTitleSnapshots 时
  // 误报 sessionRead: missing，导致诊断假阴性）。
  if (sessionQuery && typeof sessionQuery.listSessions === 'function') {
    cap.sessionRead = HostCapabilityState.AVAILABLE
  }
  if (sessionQuery && typeof sessionQuery.readTitleSnapshots === 'function') {
    cap.titleRead = HostCapabilityState.AVAILABLE
  }

  const registry = platform.workspaceRegistry
  if (registry) {
    if (typeof registry.archiveSession === 'function') cap.archive = HostCapabilityState.AVAILABLE
    // REV-09（2026-08-18）：workspaceIdentity 由真实的工作区身份能力决定 ——
    // resolveByPath + list 提供 workspace-id 语义（真实 DSH workspaceRegistry 契约）；
    // 旧代码把 archivedSessionIds !== undefined 当作身份标志是**语义错误**
    // （archivedSessionIds 只是归档会话 ID 列表，与"能否以 id 表达工作区身份"无关）。
    if (typeof registry.resolveByPath === 'function' && typeof registry.list === 'function') cap.workspaceIdentity = 'id'
    else cap.workspaceIdentity = 'string-fallback'
  }

  const agents = platform.agents
  if (agents && typeof agents.list === 'function' && typeof agents.get === 'function') {
    cap.agentStatus = typeof platform.on === 'function' ? AgentStatusSource.EVENTS : AgentStatusSource.POLLING
  }

  const subagents = platform.subagents
  if (subagents && typeof subagents.listChildren === 'function') cap.subagents = 'available'

  // liveRename = 实时会话标题改写（sessionTitle.rename）与冷会话追加（sessionPersistence.append）
  // 与 mutations.ts 中 renameNode 分支一致：liveSession 存在 → titleSvc.rename；否则 → appendColdTitle
  const titleSvc = platform.sessionTitle
  if (titleSvc && typeof titleSvc.rename === 'function') cap.liveRename = HostCapabilityState.AVAILABLE
  const persistence = platform.sessionPersistence
  if (persistence && typeof persistence.append === 'function') cap.coldRename = HostCapabilityState.AVAILABLE

  return cap
}
