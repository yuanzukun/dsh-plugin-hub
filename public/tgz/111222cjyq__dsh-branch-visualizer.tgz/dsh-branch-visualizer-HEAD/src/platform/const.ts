/**
 * dsh-brvis — platform 常量与最小类型（COMPAT-01）。
 * 收拢原三个 ports 契约文件中"被实际使用"的常量/类型；未接线的目标契约工厂
 * （makeHostPlatform / makeClientPlatform / makeTransport / makeDefaultHostCapabilities /
 * makeDefaultClientCapabilities、Client 能力段、WorkspaceRefKind）按 2026-08-18 审查
 * （全面审查报告 §八-交接2）删除——它们从未产生运行时代码路径，仅声明未接线，
 * 保留只会制造"设计稿写了机制但实现是壳"的漂移面。
 * 若未来新增第二个适配器且确实需要 HostPlatform/ClientPlatform 接口，
 * 应在 adapter 目录内按真实需求重建，而非恢复此处的空壳。
 */

// ═══════════════ Host 能力常量（capabilities 探测结果，7.5 迁移自 ports/host-platform.ts） ═══════════════

export const HostCapabilityState = {
  AVAILABLE: 'available',
  MISSING: 'missing',
  INCOMPATIBLE: 'incompatible',
} as const

export type HostCapabilityStateValue = (typeof HostCapabilityState)[keyof typeof HostCapabilityState]

export const AgentStatusSource = {
  EVENTS: 'events',
  POLLING: 'polling',
  MISSING: 'missing',
} as const

export type AgentStatusSourceValue = (typeof AgentStatusSource)[keyof typeof AgentStatusSource]

/** Host 能力细分（缺一项只关对应功能，不整体退出）。 */
export interface HostCapabilities {
  sessionRead: HostCapabilityStateValue
  titleRead: HostCapabilityStateValue
  liveRename: HostCapabilityStateValue
  coldRename: HostCapabilityStateValue
  archive: HostCapabilityStateValue
  agentStatus: AgentStatusSourceValue
  subagents: 'available' | 'missing'
  workspaceIdentity: 'id' | 'string-fallback'
}