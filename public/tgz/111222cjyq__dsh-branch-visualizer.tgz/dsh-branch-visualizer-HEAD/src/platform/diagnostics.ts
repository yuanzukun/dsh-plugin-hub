/**
 * dsh-brvis — compatibility report / diagnostics（COMPAT-01）。
 * 输出去敏报告：不含路径、session ID、标题或用户数据。
 * 文档：DSH_COMPATIBILITY_STRATEGY.md §2.10、§8.1-8.2。
 */

/** 构建兼容性报告（host 侧）。capabilities 来自 probeHostCapabilities。 */
export function buildCompatibilityReport({ pluginVersion, hostCapabilities, adapterId, missing }: {
  pluginVersion: string
  hostCapabilities: Record<string, unknown>
  adapterId: string
  missing: string[]
}) {
  return {
    generatedAt: new Date().toISOString(),
    pluginVersion: pluginVersion || 'unknown',
    adapterId: adapterId || 'none',
    capabilities: sanitize(hostCapabilities),
    missing: missing || [],
    // 刻意不含：路径、sessionId、标题、用户数据
  }
}

/** 递归去敏：只保留标量/简单结构，丢弃任意长字符串中的敏感值。 */
function sanitize(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sanitize)
  if (value && typeof value === 'object') {
    const out: Record<string, unknown> = {}
    for (const k of Object.keys(value as Record<string, unknown>)) out[k] = sanitize((value as Record<string, unknown>)[k])
    return out
  }
  if (typeof value === 'string') {
    // 保留短状态值（available/missing/...），其余截断
    if (value.length <= 64 && /^[\w-]+$/.test(value)) return value
    return value.slice(0, 12) + '…'
  }
  return value
}