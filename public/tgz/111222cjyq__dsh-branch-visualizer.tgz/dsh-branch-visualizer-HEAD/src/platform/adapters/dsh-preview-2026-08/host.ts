/**
 * dsh-brvis — DSH Host platform adapter（COMPAT-01 业务迁移）。
 *
 * 唯一集中 DSHS-specific service 名称与事件键的地方（除装配入口外）：
 *   - sessionQuery / sessionPersistence / sessionTitle / sessions
 *   - workspaceRegistry / subagents / agents
 *   - ctx.on('agent/status' | 'agent/created' | 'agent/disposed')
 *
 * 业务层（data.ts / mutations.ts）只接收本模块解好的 typed handles，
 * 不再直接写 ctx.get('...') 或 ctx.on('...')。适配 DSH 下一代时只改这里。
 *
 * adapterId: 'dsh-preview-2026-08'
 */

import type { DshHostServices } from '../../../shared/dsh-contract.js'

export const ADAPTER_ID = 'dsh-preview-2026-08'

export interface DshContext {
  get(name: string): unknown
  on?(event: string, listener: (payload: unknown) => void): (() => void) | undefined
}

/**
 * 解出全部 DSH 服务句柄（不调用任何有副作用方法，只取引用）。
 * 返回的 handles 中缺失的服务为 undefined，由业务层做降级。
 */
export function createDshHostServices(ctx: DshContext): DshHostServices {
  const get = (service: string): unknown => {
    try { return ctx.get(service) } catch { return undefined }
  }
  return {
    get sessionQuery() { return get('sessionQuery') as DshHostServices['sessionQuery'] },
    get sessionPersistence() { return get('sessionPersistence') as DshHostServices['sessionPersistence'] },
    get sessionTitle() { return get('sessionTitle') as DshHostServices['sessionTitle'] },
    get sessions() { return get('sessions') },
    get workspaceRegistry() { return get('workspaceRegistry') as DshHostServices['workspaceRegistry'] },
    get subagents() { return get('subagents') as DshHostServices['subagents'] },
    get agents() { return get('agents') as DshHostServices['agents'] },
    get timer() { return get('timer') as DshHostServices['timer'] },
    /** DSH 事件订阅；返回 disposer（或 undefined 不可用）。 */
    on(event, listener) {
      if (typeof ctx.on !== 'function') return undefined
      try { return ctx.on(event, listener) } catch { return undefined }
    },
  }
}

/**
 * 退化路径（无 adapter 注入时，供测试 mock ctx 或旧装配使用）。
 * 与 createDshHostServices 同构——DSH service 键仍只出现在本 adapter 文件。
 */
export function createFallbackPlatform(ctx: DshContext): DshHostServices {
  const g = (n: string): unknown => {
    try { return ctx.get(n) } catch { return undefined }
  }
  return {
    get sessionQuery() { return g('sessionQuery') as DshHostServices['sessionQuery'] },
    get sessionPersistence() { return g('sessionPersistence') as DshHostServices['sessionPersistence'] },
    get sessionTitle() { return g('sessionTitle') as DshHostServices['sessionTitle'] },
    get sessions() { return g('sessions') },
    get workspaceRegistry() { return g('workspaceRegistry') as DshHostServices['workspaceRegistry'] },
    get subagents() { return g('subagents') as DshHostServices['subagents'] },
    get agents() { return g('agents') as DshHostServices['agents'] },
    get timer() { return g('timer') as DshHostServices['timer'] },
    on(event, listener) {
      if (typeof ctx.on !== 'function') return undefined
      try { return ctx.on(event, listener) } catch { return undefined }
    },
  }
}
