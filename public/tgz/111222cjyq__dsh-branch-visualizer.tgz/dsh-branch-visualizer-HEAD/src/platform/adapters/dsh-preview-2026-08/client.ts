/**
 * DeepSeek Harness client adapter.
 *
 * DSH 的 client service key 与 slot 名称只允许在本文件出现。若实验版发生重大
 * 调整，应新增一个 adapter 目录并修改装配选择，不要改画布、布局或业务动作。
 */
import type { DshClientServices } from '../../../shared/dsh-contract.js'

export const CLIENT_ADAPTER_ID = 'dsh-preview-2026-08'

export const DSH_CLIENT_SLOTS = {
  overlay: 'shell.overlay',
  sessionUtilities: 'conversation.session.header.utilities',
} as const

export interface DshClientContext {
  get(name: string): unknown
}

export function createDshClientServices(ctx: DshClientContext): DshClientServices {
  const get = (service: string): unknown => {
    try { return ctx.get(service) } catch { return undefined }
  }
  return {
    get slots() { return get('slots') },
    get timer() { return get('timer') },
    get sessions() { return get('sessions') as DshClientServices['sessions'] },
    get workspaces() { return get('workspaces') as DshClientServices['workspaces'] },
  }
}
