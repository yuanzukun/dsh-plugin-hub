/**
 * dsh-branch-visualizer — client 半边类型声明。
 * 入口是浏览器 ModuleLoader bundle（window.__ModuleLoader__.load），
 * 本文件只声明插件形态导出，供 consumer 类型解析（exports -> ./client）。
 */
import type * as React from 'react'

// AUD-14（2026-08-18）：删除 `name` 声明——client/index.ts 只导出 inject/apply，
// 声明不存在的运行时导出是类型谎言（import { name } 类型通过、运行时 undefined）。
export const inject: string[]

/** client 装配（Cordis plugin apply）。 */
export function apply(ctx: unknown): void

/** 画布主组件（工厂返回，供内部/测试引用）。 */
export interface CanvasFactoryHooks {
  makeCanvas(
    ctx: unknown,
    timer: unknown,
    state: unknown,
    useBrvisState: () => void,
  ): { Canvas: React.ComponentType<Record<string, unknown>> }
}
