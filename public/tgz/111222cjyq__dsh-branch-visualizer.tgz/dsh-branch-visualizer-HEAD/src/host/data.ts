/**
 * dsh-brvis — host 数据读取层（快照构建 / 授权边界 / 子代理收集 / agent 状态追踪）。
 * 拆分自原单文件 src/index.ts（2026-08）。
 * 工厂 createDataOps(ctx, deps) 注入运行时服务与共享缓存容器；
 * deps.failure / deps.ERR / deps.canonicalWorkspaceKey 由装配层提供（RPC 契约同源）。
 * COMPAT-01: DSH 服务句柄统一来自 deps.platform（adapter）；测试可传 mock ctx 走 fallback。
 */
import { createFallbackPlatform } from '../platform/adapters/dsh-preview-2026-08/host.js'
import type { DshHostServices } from '../shared/dsh-contract.js'
import type {
  BrvisErrorCodeValue, NodeStatus, RpcFailure, RpcSuccess, RpcResult, SnapshotPayload, BrvisNode,
} from '../shared/contract.js'
// REV-01（2026-08-18）：引入 CanonicalKeyResult，WRITE/PATH-01 需消费 degraded 标志
// 7.6（2026-08-18）：退化归一改用 normalizeChar（与原 canonicalKeyInfo 手写 replace 同构）
import type { CanonicalKeyResult } from './canonical-path.js'
import { normalizeChar } from './canonical-path.js'

/** 画布内部会话节点（header + 标题回填）。 */
interface SessionNode {
  id: string
  title: string
  parentId: string | null
  parentArchivedBridge: boolean
  createdAt: number
}

/** 子代理元数据（快照节点 subagentAddress/status 的数据源）。 */
export interface SubagentMeta {
  childId: string
  parentId: string
  mode: 'one-shot' | 'continuable'
  activity: 'running' | 'inactive'
}

/** 子代理缓存条目（TTL 过期整体删除，meta 不再独立残留）。 */
interface SubagentCacheEntry {
  idSet: Set<string>
  metaById: Map<string, SubagentMeta>
  fetchedAt: number
}

/** 快照缓存条目。 */
interface SnapshotCacheEntry {
  payload: SnapshotPayload
  fetchedAt: number
}

/** 会话标题缓存条目。标题日志读取是归档全量快照的主要耗时来源。 */
interface TitleCacheEntry {
  title: string
  fetchedAt: number
}

/** 写操作后的缓存失效范围。归档不改标题，重命名只需失效目标标题。 */
interface InvalidateWorkspaceOptions {
  titleIds?: Iterable<string>
}

// REV-01（2026-08-18）：删除本地重复的 CanonicalKeyResult 定义，
// 统一使用 canonical-path.ts 的权威类型（本文件顶部已 import type）。
export interface CreateDataOpsDeps {
  platform?: DshHostServices
  success: RpcSuccess
  failure: RpcFailure
  ERR: Record<string, BrvisErrorCodeValue>
  canonicalWorkspaceKey?: (input: string) => CanonicalKeyResult
}

type AgentStatusMap = Map<string, 'running' | 'idle'>

export interface AuthFailure {
  sessionId: string | null
  code: BrvisErrorCodeValue
  message: string
}

/** 工作区成员会话 header（授权边界用，PATH-01 权威键比较）。 */
export interface WorkspaceMemberHeader {
  id: string
  cwd?: string
  parentSession?: string
  createdAt?: number
}

export function createDataOps(ctx: unknown, deps: CreateDataOpsDeps) {
  const { failure, ERR, canonicalWorkspaceKey } = deps
  // COMPAT-01: DSH 服务句柄由 adapter 提供（platform 缺失时退化去全部 ctx.get）
  const p = deps.platform || createFallbackPlatform(ctx as { get(name: string): unknown })

  // PATH-01: 权威工作区键（deps 注入 canonicalWorkspaceKey；缺失时退化为字符归一）。
  // REV-01（2026-08-18）：返回 {key, degraded} —— 读路径（快照缓存/比较）允许 degraded 回退键；
  // 写路径（requireWorkspaceMember/authorizeMany）遇到 degraded 应拒绝 mutation（PATH-01 文档 §5）。
  // 7.6（2026-08-18）：退化归一复用 canonical-path.ts 的 normalizeChar，
  // 而非手写 replace —— 避免维护期两份归一逻辑漏同步（文档 §4.2-7.6）。
  function canonicalKeyInfo(input: string): CanonicalKeyResult {
    if (typeof canonicalWorkspaceKey === 'function') {
      const r = canonicalWorkspaceKey(input)
      // 兜底：函数存在但返回 falsy 时
      if (r) return r
    }
    // 退化：仅字符归一（无 canonicalWorkspaceKey 的受限/测试环境；无法判定真实路径 → 不标记 degraded）
    return { key: normalizeChar(String(input || '')), degraded: false }
  }
  // 读路径用：返回规范化 key 字符串
  function canonicalKey(input: string): string {
    return canonicalKeyInfo(input).key
  }

  // ============ 快照缓存(按工作区路径独立,带 TTL) ============
  // 参照 CACHE-01:每个工作区独立缓存,+ 容量上限 LRU。
  // PERF-01 (2026-08): 客户端轮询基准间隔 2s,旧 TTL=1000ms < 轮询周期 ⇒
  // 每一轮轮询都 miss,快照全量重建(多分支时 listSessions+readTitleSnapshots 每 2s 全扫,
  // 宿主 CPU 占用高,归档/多分支时连视频都卡)。改为 2500ms:
  //   - 轮询节奏附近命中率 ~50%,全量重建频率减半;
  //   - 新鲜度由 mutation 的 invalidateWorkspace 兜底(改名/归档立即失效缓存,
  //     用户不会因 TTL 看到 >250ms 的额外陈旧——实际是写操作路径主动清除)。
  const SNAPSHOT_CACHE_MAX = 8
  const SNAPSHOT_TTL = 2500
  // ARCH-PERF-01: 含归档快照构建需要读取大量冷会话日志，不能沿用 2.5s TTL。
  // 插件内写操作会主动失效两个快照变体；60s 期间重复显隐/轮询直接命中，
  // 到期后的刷新也由 client 以 stale-while-revalidate 方式静默完成。
  const ARCHIVED_SNAPSHOT_TTL = 60_000
  const snapshots = new Map<string, SnapshotCacheEntry>()
  // AUD-03（2026-08-18）：按缓存键的失效纪元。invalidateWorkspace 时递增；
  // 在途重建启动时记录 epoch0、写缓存前比对——不一致即"重建期间发生过写失效"，
  // 结果已是失效前数据，丢弃不写缓存（否则旧数据回填并享有完整 TTL → 写后读旧）。
  const cacheEpochs = new Map<string, number>()

  function cacheSnapshot(path: string, payload: SnapshotPayload) {
    // 工作区最近访问优先;缓存满时淘汰最旧的条目
    const now = Date.now()
    snapshots.set(path, { payload, fetchedAt: now })
    if (snapshots.size > SNAPSHOT_CACHE_MAX) {
      let oldestKey: string | null = null
      let oldestAt = Infinity
      for (const [k, entry] of snapshots) {
        if (entry.fetchedAt < oldestAt) { oldestAt = entry.fetchedAt; oldestKey = k }
      }
      if (oldestKey !== null) snapshots.delete(oldestKey)
    }
  }

  function invalidateWorkspace(path: string, options?: InvalidateWorkspaceOptions) {
    // PATH-01: 写操作后按权威键清除工作区缓存（mutation 传来的 path 可能未归一化）
    // ARCH-03: 归档/改名后默认与"显示归档"两个变体缓存都必须失效
    const key = canonicalKey(path)
    snapshots.delete(key)
    snapshots.delete(key + '#arch')
    snapshots.delete(key + '#arch#skeleton')
    // AUD-03: 两个变体的失效纪元都递增（在途重建以此感知"重建期间发生过写失效"）；
    // 插入序上限淘汰，防宿主长生命周期下工作区轮换导致缓慢增长。
    cacheEpochs.set(key, (cacheEpochs.get(key) || 0) + 1)
    cacheEpochs.set(key + '#arch', (cacheEpochs.get(key + '#arch') || 0) + 1)
    // 标题日志缓存与结构快照分开：归档只改变 archived/连线，不应迫使几十个
    // 冷会话重新折叠完整日志；重命名调用方只传被改名的会话 id。
    if (options?.titleIds) {
      for (const id of options.titleIds) titleCache.delete(id)
    }
    if (cacheEpochs.size > 64) {
      const oldest = cacheEpochs.keys().next().value
      if (oldest !== undefined) cacheEpochs.delete(oldest)
    }
  }

  // PERF-05 (2026-08): 快照重建并发合并 + 全局重建信号量。
  // 崩盘复盘：压测 60 并发 snapshot，缓存 miss 后每个请求都独立执行一次
  // listSessions()+readTitleSnapshots()+listChildren() 全量重建 —— 60 倍扩容，
  // 底层服务被挤爆、宿主 OOM 被杀（电脑黑屏）。修复：
  //   1) inflightSnapshots：同一工作区并发请求合并为一次底层重建，其余请求 join；
  //   2) activeRebuilds 信号量：不同工作区并发重建也封顶，超限快速失败（retryable），
  //      避免 webserver 层大面积堆积内存。
  const SNAPSHOT_REBUILD_MAX = 3
  const inflightSnapshots = new Map<string, Promise<RpcResult<SnapshotPayload>>>()
  let activeRebuilds = 0

  // TRACE-01: 重建阶段计时埋点（默认开，仅打印耗时 > 阈值阶段）。
  // 目的：把快照慢在哪个阶段（listSessions / readTitleSnapshots / listChildren）
  // 从猜测变成日志事实，供后续针对性优化（增量重建 / 索引）。
  const TRACE = true
  const TRACE_MIN_MS = 20

  // 子代理收集同样做 in-flight 合并：同一 (path,parentId) 的并发 listChildren 只发一次。
  const subagentInflight = new Map<string, Promise<void>>()

  // ============ 子代理缓存(带 TTL,空结果短 TTL) ============
  // 单一缓存结构 { idSet, metaById, fetchedAt }：meta（childId → {parentId, mode, activity}）
  // 随 id 集合同 TTL 过期一起删除，避免独立 meta 缓存永久残留（内存泄漏）。
  const SUBAGENT_TTL = 10000
  const SUBAGENT_EMPTY_TTL = 3000
  const SUBAGENT_CACHE_MAX = 512
  // PERF-04: 6→4。listChildren 是 DSH 服务调用,快照重建时受限并发即可,
  // 过高并发与归档/其它插件叠加会挤占宿主事件循环。
  const SUBAGENT_CONCURRENCY = 4
  const subagentCache = new Map<string, SubagentCacheEntry>()

  // ============ 会话标题缓存（增量、LRU、显式重命名失效） ============
  // 冷会话 readTitleSnapshots(60) 实测需 9–13s。标题远比运行状态稳定，缓存 5min；
  // 插件内重命名会精确删除目标项，外部改名最迟在 TTL 后收敛。
  const TITLE_TTL = 5 * 60_000
  const TITLE_CACHE_MAX = 4096
  const titleCache = new Map<string, TitleCacheEntry>()

  function titleCached(id: string): string | null {
    const hit = titleCache.get(id)
    if (!hit) return null
    if (Date.now() - hit.fetchedAt > TITLE_TTL) {
      titleCache.delete(id)
      return null
    }
    titleCache.delete(id)
    titleCache.set(id, hit)
    return hit.title
  }

  function cacheTitle(id: string, title: string): void {
    titleCache.delete(id)
    titleCache.set(id, { title, fetchedAt: Date.now() })
    while (titleCache.size > TITLE_CACHE_MAX) {
      const oldest = titleCache.keys().next().value
      if (oldest === undefined) break
      titleCache.delete(oldest)
    }
  }

  // 返回 { idSet, metaById }（未命中/过期返回 null）
  function subagentCached(path: string, parentId: string): SubagentCacheEntry | null {
    const cacheKey = path + '|' + parentId
    const hit = subagentCache.get(cacheKey)
    if (!hit) return null
    const ttl = hit.idSet.size === 0 ? SUBAGENT_EMPTY_TTL : SUBAGENT_TTL
    if (Date.now() - hit.fetchedAt > ttl) {
      subagentCache.delete(cacheKey)
      return null
    }
    // 命中即移到 Map 末尾，作为轻量 LRU。
    subagentCache.delete(cacheKey)
    subagentCache.set(cacheKey, hit)
    return hit
  }

  function cacheSubagent(cacheKey: string, entry: SubagentCacheEntry): void {
    subagentCache.delete(cacheKey)
    subagentCache.set(cacheKey, entry)
    while (subagentCache.size > SUBAGENT_CACHE_MAX) {
      const oldest = subagentCache.keys().next().value
      if (oldest === undefined) break
      subagentCache.delete(oldest)
    }
  }

  // ============ Agent 运行状态追踪（STATUS-01） ============
  // 服务：订阅 DSH 真实事件（agent/status / agent/created / agent/disposed），
  // 初始化时遍历 agents.list()。query 提供 initial live Agent 状态。
  //   live agent 的 status: 'running'|'idle'（事件源）；cold = 无 live agent。
  // 文档 §9 五场景矩阵：
  //   插件加载前已存在 running Agent → 首次快照 running（遍历初始化）
  //   idle → running / running → idle → 事件更新，最多一个轮询周期可见
  //   Agent disposed → cold（agent/disposed 删 Map 项）
  //   只改 status 其他字段不变 → client 仍应用快照（signature 已纳入 status）
  const agentStatus: AgentStatusMap = new Map()
  const agentDisposers: (() => void)[] = []

  function createAgentStatusService(): void {
    const agents = p.agents
    if (!agents) return
    try {
      // 1. 初始化：遍历现有 live agents
      if (typeof agents.list === 'function') {
        for (const ag of agents.list()) {
          const id = ag && (ag.id || (ag.session && ag.session.id))
          if (id) agentStatus.set(id, ag.status === 'running' ? 'running' : 'idle')
        }
      }
      // 2. agent/status：idle ⇄ running（payload.agent.id + payload.status）
      const d1 = p.on?.('agent/status', (payload) => {
        const ev = payload as { agent?: { id?: string; session?: { id?: string } }; status?: string }
        const agent = ev && ev.agent
        const id = agent && (agent.id || (agent.session && agent.session.id))
        if (!id) return
        agentStatus.set(id, ev.status === 'running' ? 'running' : 'idle')
      })
      if (d1) agentDisposers.push(d1)
      // 3. agent/created：新 live agent 的当前状态
      const d2 = p.on?.('agent/created', (payload) => {
        const agent = payload as { agent?: { id?: string; session?: { id?: string }; status?: string } }
        const ag = agent && agent.agent
        const id = ag && (ag.id || (ag.session && ag.session.id))
        if (!id) return
        agentStatus.set(id, ag.status === 'running' ? 'running' : 'idle')
      })
      if (d2) agentDisposers.push(d2)
      // 4. agent/disposed：离开 registry → 删 Map 项 → client 显示 cold
      const d3 = p.on?.('agent/disposed', (payload) => {
        const agent = payload as { agent?: { id?: string; session?: { id?: string } } }
        const ag = agent && agent.agent
        const id = ag && (ag.id || (ag.session && ag.session.id))
        if (id) agentStatus.delete(id)
      })
      if (d3) agentDisposers.push(d3)
    } catch (e) {
      // 事件订阅失败静默降级：仍可用 agents.get(id)?.status 两态
    }
  }

  function disposeAgentTracking(): void {
    for (const d of agentDisposers) { try { d() } catch (e) { /* ignore */ } }
    agentDisposers.length = 0
    agentStatus.clear()
  }

  // getStatus: live agent 的真实 idle/running;无 live agent → cold
  function getAgentStatus(id: string, agents?: DshHostServices['agents']): NodeStatus {
    if (agents && typeof agents.get === 'function') {
      try {
        const ag = agents.get(id)
        if (ag) return agentStatus.get(id) || (ag.status === 'running' ? 'running' : 'idle')
      } catch (e) { /* 查询失败按 cold */ }
    }
    return 'cold'
  }

  // 子代理运行状态（STATUS-01）：agents registry 是权威（子代理 Agent 也在 registry，
  // 生命周期实时：running → idle → 清理后消失）；activity 仅在 registry 未收录时兜底。
  // 实测 DSH 的 listChildren.activity 在子代理结束后仍短暂报 running（Session 采样滞后），
  // 若单用 activity 会残留绿色——因此 registry 优先，activity 只作补充。
  function getSubagentStatus(id: string, agents: DshHostServices['agents'] | undefined, activity: 'running' | 'inactive'): NodeStatus {
    const reg = getAgentStatus(id, agents)
    if (reg !== 'cold') return reg // registry 有该子代理 → idle/running 权威
    return activity === 'running' ? 'running' : 'cold'
  }

  // ============ 数据读取 ============
  // ARCH-03: includeArchived=false 时归档节点不读标题、不收集子代理、不进布局；
  // 但会保留最小 header 索引，把可见后代重连到最近可见祖先，供双虚线桥接。
  async function buildWorkspaceNodes(
    query: NonNullable<DshHostServices['sessionQuery']>,
    path: string,
    includeArchived: boolean,
    archivedIds: Set<string>,
    hydrateTitles = true,
  ): Promise<Map<string, SessionNode> | null> {
    const te0 = Date.now()
    let records
    try {
      records = await query.listSessions()
    } catch (e) {
      console.error('[brvis] listSessions failed')
      return null
    }
    const te1 = Date.now()
    // PATH-01: 两侧都过权威键（h.cwd 是 DSH 记录的工作区路径，可能大小写/分隔符差异）
    const targetKey = canonicalKey(path)
    const ids: string[] = []
    const allHeaderBy = new Map<string, { id: string; cwd?: string; parentSession?: string; createdAt?: number }>()
    for (const rec of records) {
      const h = rec.header
      if (!h || !h.id || canonicalKey(h.cwd || '') !== targetKey) continue
      allHeaderBy.set(h.id, h)
    }
    const headerBy = new Map<string, { id: string; cwd?: string; parentSession?: string; createdAt?: number }>()
    for (const [id, h] of allHeaderBy) {
      if (!includeArchived && archivedIds.has(id)) continue
      ids.push(id)
      headerBy.set(id, h)
    }
    const titles = new Map<string, string>()
    const titleMisses: string[] = []
    for (const id of ids) {
      const cached = titleCached(id)
      if (cached === null) titleMisses.push(id)
      else titles.set(id, cached)
    }
    if (hydrateTitles && titleMisses.length && typeof query.readTitleSnapshots === 'function') {
      try {
        // ARCH-PERF-01: 只折叠新增/过期会话的日志。全量归档快照第一次仍需读取，
        // 之后即使结构缓存因归档操作失效，也不会再次扫描其余几十个标题日志。
        const res = await query.readTitleSnapshots(titleMisses)
        const resolved = new Set<string>()
        for (const item of res) {
          if (item.status === 'fulfilled' && item.sessionId) {
            const title = item.value?.title?.title || item.sessionId
            titles.set(item.sessionId, title)
            cacheTitle(item.sessionId, title)
            resolved.add(item.sessionId)
          }
        }
        // 没有 title 事件同样做负缓存（以 id 展示），避免每轮重复打开完整日志。
        for (const id of titleMisses) {
          if (resolved.has(id)) continue
          titles.set(id, id)
          cacheTitle(id, id)
        }
      } catch (e) {
        console.error('[brvis] readTitleSnapshots failed')
      }
      const te2 = Date.now()
      if (TRACE && te2 - te0 > TRACE_MIN_MS) {
        console.log(`[brvis]   scans: listSessions=${te1 - te0}ms readTitleSnapshots(${titleMisses.length}/${ids.length} misses)=${te2 - te1}ms`)
      }
    }
    const map = new Map<string, SessionNode>()
    for (const h of headerBy.values()) {
      let parentId = h.parentSession || null
      let parentArchivedBridge = false
      if (!includeArchived && parentId && archivedIds.has(parentId)) {
        const visited = new Set<string>()
        while (parentId && archivedIds.has(parentId) && !visited.has(parentId)) {
          visited.add(parentId)
          parentArchivedBridge = true
          parentId = allHeaderBy.get(parentId)?.parentSession || null
        }
        // 循环、缺失或跨工作区父节点不能成为可见桥接端点。
        if (parentId && !headerBy.has(parentId)) parentId = null
      }
      map.set(h.id, {
        id: h.id,
        title: titles.get(h.id) || h.id,
        parentId,
        parentArchivedBridge,
        createdAt: h.createdAt || 0,
      })
    }
    return map
  }

  // ============ 授权边界(B 方案:最小限度) ============
  // 参照 SEC-01。当前 DSH 未提供可信调用者上下文,只能:
  // 1) 校验目标会话确实存在;2) 校验其 cwd 属于当前画布所在工作区。
  // 这阻止误操作与直接跨工作区 ID 修改,不声称完整身份授权。
  // 路径比较基于 PATH-01 权威键（canonicalKey），不再接收 normalizePath。
  function isWorkspaceHeader(h: unknown): h is WorkspaceMemberHeader {
    return !!h && typeof (h as WorkspaceMemberHeader).id === 'string'
  }

  // 查单个会话 header;返回 null 表示不存在或不可读
  async function findSessionHeader(sessionId: string): Promise<WorkspaceMemberHeader | null> {
    const query = p.sessionQuery
    if (!query) return null
    try {
      const records = await query.listSessions()
      for (const rec of records) {
        const h = rec.header
        if (h && h.id === sessionId && isWorkspaceHeader(h)) return h
      }
    } catch (e) {
      console.error('[brvis] findSessionHeader failed')
    }
    return null
  }

  type MemberResult = RpcResult<{ header: WorkspaceMemberHeader }>
  async function requireWorkspaceMember(sessionId: string, path: string): Promise<MemberResult> {
    if (typeof sessionId !== 'string' || !sessionId) {
      return failure(ERR.BAD_REQUEST, '会话参数无效', false)
    }
    if (sessionId.length > 200) {
      return failure(ERR.BAD_REQUEST, '会话参数无效', false)
    }
    if (typeof path !== 'string' || !path) {
      return failure(ERR.WORKSPACE_UNAVAILABLE, '无法确定工作区', false)
    }
    const header = await findSessionHeader(sessionId)
    if (!header) return failure(ERR.SESSION_NOT_FOUND, '会话不存在', false)
    // PATH-01/REV-01：权威键归一化；realpath 失败(degraded)时拒绝写操作
    const pathInfo = canonicalKeyInfo(path)
    if (pathInfo.degraded) {
      return failure(ERR.WORKSPACE_UNAVAILABLE, '无法确认工作区路径', false)
    }
    if (canonicalKey(header.cwd || '') !== pathInfo.key) {
      return failure(ERR.SESSION_OUTSIDE_WORKSPACE, '该会话不属于当前工作区', false)
    }
    return { ok: true, data: { header } } as MemberResult
  }

  // ARCHIVE-01: 批量授权——单次 listSessions 建立 headerById 索引，
  // 一次校验全部 id 的归属，替代"每项 requireWorkspaceMember → 每项全量 listSessions"。
  // 语义：任一 id 格式非法/不存在/越界 → 整批授权失败（不写入）。
  // 返回 { ok, headerById, failures }：ok=false 时 failures 为 {sessionId, code, message} 列表；
  // ok=true 时 headerById 含全部已授权 header，failures 为空。
  type AuthorizeResult =
    | { ok: true; headerById: Map<string, { id: string; cwd?: string }>; failures: AuthFailure[] }
    | { ok: false; headerById: Map<string, { id: string; cwd?: string }>; failures: AuthFailure[] }
  async function authorizeMany(rawIds: string[], path: string): Promise<AuthorizeResult> {
    const query = p.sessionQuery
    // PATH-01/REV-01: 权威键作比较基准；realpath 失败(degraded)时整批拒绝写操作
    const pathInfo = canonicalKeyInfo(path)
    if (pathInfo.degraded) {
      return { ok: false, headerById: new Map(), failures: [{ sessionId: null, code: ERR.WORKSPACE_UNAVAILABLE, message: '无法确认工作区路径' }] }
    }
    const normalized = pathInfo.key
    const failures: AuthFailure[] = []
    // 1. 格式预检（任一非法 → 整批失败）
    for (const id of rawIds) {
      if (typeof id !== 'string' || !id || id.length === 0 || id.length > 200) {
        failures.push({ sessionId: id, code: ERR.BAD_REQUEST, message: '会话参数无效' })
      }
    }
    if (failures.length) return { ok: false, headerById: new Map(), failures }
    if (!normalized) {
      return { ok: false, headerById: new Map(), failures: [{ sessionId: null, code: ERR.WORKSPACE_UNAVAILABLE, message: '无法确定工作区' }] }
    }
    let records: Awaited<ReturnType<NonNullable<SessionQueryRef['listSessions']>>> = []
    if (query && typeof query.listSessions === 'function') {
      try {
        records = await query.listSessions()
      } catch (e) {
        console.error('[brvis] authorizeMany listSessions failed')
        return { ok: false, headerById: new Map(), failures: [{ sessionId: null, code: ERR.SERVICE_UNAVAILABLE, message: '会话查询失败' }] }
      }
    }
    // 2. 一次索引（单次全量扫描，替代每项二次扫描）
    const headerById = new Map<string, { id: string; cwd?: string }>()
    for (const rec of records) {
      const h = rec.header
      if (h && h.id) headerById.set(h.id, h)
    }
    // 3. 逐一归属校验（只查索引，不再次查库）
    for (const id of rawIds) {
      const header = headerById.get(id)
      if (!header) {
        failures.push({ sessionId: id, code: ERR.SESSION_NOT_FOUND, message: '会话不存在' })
        continue
      }
      if (canonicalKey(header.cwd || '') !== normalized) {
        failures.push({ sessionId: id, code: ERR.SESSION_OUTSIDE_WORKSPACE, message: '该会话不属于当前工作区' })
        continue
      }
    }
    if (failures.length) return { ok: false, headerById, failures }
    return { ok: true, headerById, failures: [] }
  }

  function archivedSet(registry?: DshHostServices['workspaceRegistry']): Set<string> {
    const set = new Set<string>()
    try {
      if (registry && typeof registry.archivedSessionIds !== 'undefined') {
        for (const id of registry.archivedSessionIds) set.add(id)
      }
    } catch (e) { /* ignore */ }
    return set
  }

  // 子代理标记:对画布内每个会话收集其直接子代理 id,反向得到哪些节点是子代理。
  // 并发受限,带 TTL 缓存,父会话 id + 工作区路径作键。
  // 返回 Map<childId, {parentId, mode, activity}>:mode/activity 供 client 双击构造
  // SubagentAddress 与运行状态标识——不依赖 client runtime 的目录保留状态。
  // mode/activity 来自 SubagentListEntry（'one-shot'|'continuable' / 'running'|'inactive'）。
  async function collectSubagentMeta(subagents: DshHostServices['subagents'], path: string, ids: string[]): Promise<Map<string, SubagentMeta>> {
    if (!subagents || typeof subagents.listChildren !== 'function') return new Map()
    const out = new Map<string, SubagentMeta>()
    const toQuery: string[] = []
    for (const id of ids) {
      const cached = subagentCached(path, id)
      if (cached) {
        for (const m of cached.metaById.values()) out.set(m.childId, m)
      } else {
        toQuery.push(id)
      }
    }
    let cursor = 0
    // subagents 已在入口 guard 为非空，闭包内 TS 无法保留收窄 → 显式断言
    const subagentsRef = subagents as NonNullable<SubagentsRef>
    async function worker(): Promise<void> {
      while (cursor < toQuery.length) {
        const parentId = toQuery[cursor++]
        // PERF-05: in-flight 合并——同一 (path|parentId) 并发 listChildren 只发一次。
        // 发起者写缓存；join 者等它完成后统一从缓存读取，避免 60 倍查询放大。
        await queryOneSubagent(subagentsRef, path + '|' + parentId, parentId)
        const entry = subagentCache.get(path + '|' + parentId)
        if (entry) {
          for (const m of entry.metaById.values()) out.set(m.childId, m)
        }
      }
    }
    const workers: Promise<void>[] = []
    const n = Math.min(SUBAGENT_CONCURRENCY, Math.max(1, toQuery.length))
    for (let i = 0; i < n; i++) workers.push(worker())
    await Promise.all(workers)
    return out
  }

  /** 快速归档骨架只消费现有子代理缓存，不触发几十次冷 listChildren。 */
  function collectCachedSubagentMeta(path: string, ids: string[]): Map<string, SubagentMeta> {
    const out = new Map<string, SubagentMeta>()
    for (const id of ids) {
      const cached = subagentCached(path, id)
      if (!cached) continue
      for (const meta of cached.metaById.values()) out.set(meta.childId, meta)
    }
    return out
  }

  // ============ 快照 ============
  function sortNodesForStable(nodes: BrvisNode[]): BrvisNode[] {
    // 稳定排序:内容(不含纯顺序)不变时不产生无谓重渲染
    return nodes.slice().sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0))
  }

  // 一次性 listChildren 查询（带 in-flight 合并）：同一 (path|parentId) 并发只发一次，
  // join 者等发起者完成后统一从 subagentCache 读取结果。
  async function queryOneSubagent(subagents: NonNullable<DshHostServices['subagents']>, cacheKey: string, parentId: string): Promise<void> {
    const inflight = subagentInflight.get(cacheKey)
    if (inflight) {
      await inflight
      return
    }
    const p = (async () => {
      let children: Awaited<ReturnType<NonNullable<SubagentsRef['listChildren']>>> = []
      try {
        children = await subagents.listChildren(parentId)
      } catch (e) { /* ignore */ }
      const idSet = new Set<string>()
      const metaById = new Map<string, SubagentMeta>()
      for (const entry of children || []) {
        if (entry && entry.id) {
          idSet.add(entry.id)
          metaById.set(entry.id, {
            childId: entry.id,
            parentId,
            mode: entry.mode === 'continuable' ? 'continuable' : 'one-shot',
            activity: entry.activity === 'running' ? 'running' : 'inactive',
          })
        }
      }
      cacheSubagent(cacheKey, { idSet, metaById, fetchedAt: Date.now() })
    })()
    subagentInflight.set(cacheKey, p)
    try {
      await p
    } finally {
      subagentInflight.delete(cacheKey)
    }
  }

  // ============ 一次性快照重建（PERF-05：合并 + 信号量 + 计时；ARCH-03：可见性变体） ============
  // includeArchived=false（默认）时归档节点根本不进入标题读取/子代理收集/布局。
  async function buildSnapshot(
    cacheKey: string,
    workspaceKey: string,
    path: string,
    includeArchived: boolean,
    epoch0: number,
    hydrateDetails = true,
  ): Promise<RpcResult<SnapshotPayload>> {
    const query = p.sessionQuery
    const apiRegistry = p.workspaceRegistry
    const subagents = p.subagents
    const agents = p.agents
    const t0 = Date.now()

    if (!query) return failure(ERR.SERVICE_UNAVAILABLE, '服务暂不可用', true)
    // ARCH-03: archived 集合提前取，供 buildWorkspaceNodes 在读取标题前过滤归档节点
    const archived = archivedSet(apiRegistry)
    const map = await buildWorkspaceNodes(query, path, includeArchived, archived, hydrateDetails)
    if (!map) return failure(ERR.SERVICE_UNAVAILABLE, '无法读取会话列表', true)
    const t1 = Date.now()

    // ARCH-PERF-02: 两个可见性变体共享同一工作区的子代理缓存。
    // 旧实现把 `#arch` 混进 path，导致全量快照重复查询可见节点的 listChildren。
    const subMeta = hydrateDetails
      ? await collectSubagentMeta(subagents, workspaceKey, [...map.keys()])
      : collectCachedSubagentMeta(workspaceKey, [...map.keys()])
    const t2 = Date.now()

    const nodes: BrvisNode[] = []
    for (const n of map.values()) {
      const sub = subMeta.get(n.id)
      // 子代理活动状态（STATUS-01）：agents registry 为权威（子代理 Agent 在 registry）；
      // activity 仅在 registry 未收录时兜底（实测 DSH activity 对结束子代理有滞后）。
      const status = sub
        ? getSubagentStatus(n.id, agents, sub.activity)
        : getAgentStatus(n.id, agents)
      nodes.push({
        id: n.id,
        title: n.title,
        parentId: n.parentId,
        parentArchivedBridge: n.parentArchivedBridge,
        archived: archived.has(n.id),
        subagent: !!sub,
        // 子代理跳转地址(官方契约):openSubagent({parentSessionId, childSessionId, mode})。
        // 直接随快照下发,client 双击无需依赖 runtime 目录保留(已归档子代理仍可打开)。
        subagentAddress: sub ? { parentSessionId: sub.parentId, childSessionId: n.id, mode: sub.mode } : null,
        status,
        createdAt: n.createdAt,
      })
    }
    const payload: SnapshotPayload = {
      workspace: workspaceKey,
      generatedAt: Date.now(),
      nodes: sortNodesForStable(nodes),
      ...(hydrateDetails ? {} : { hydrating: true }),
    }
    // AUD-03: 重建期间发生过写失效（epoch 已递增）→ 结果是失效前数据，丢弃不写缓存。
    // join 本次 promise 的调用方仍拿到该结果（可接受）——关键是阻断后续轮询命中回填。
    if (hydrateDetails && (cacheEpochs.get(cacheKey) || 0) === epoch0) cacheSnapshot(cacheKey, payload)

    if (TRACE) {
      const total = Date.now() - t0
      const scans = t1 - t0
      const sub = t2 - t1
      // 只报告值得注意的重建（>20ms），常规命中不刷屏
      if (total > TRACE_MIN_MS) {
        console.log(`[brvis] snapshot ${hydrateDetails ? 'rebuild' : 'skeleton'}(${nodes.length} nodes) scans=${scans}ms subagents=${sub}ms total=${total}ms (inflightRebuilds=${activeRebuilds})`)
      }
    }
    return deps.success(payload)
  }

  function startSnapshotRebuild(
    cacheKey: string,
    workspaceKey: string,
    path: string,
    includeArchived: boolean,
  ): Promise<RpcResult<SnapshotPayload>> | null {
    const existing = inflightSnapshots.get(cacheKey)
    if (existing) return existing
    if (activeRebuilds >= SNAPSHOT_REBUILD_MAX) return null

    const epoch0 = cacheEpochs.get(cacheKey) || 0
    activeRebuilds += 1
    const owner: { promise?: Promise<RpcResult<SnapshotPayload>> } = {}
    const promise = (async () => {
      try {
        return await buildSnapshot(cacheKey, workspaceKey, path, includeArchived, epoch0)
      } finally {
        if (owner.promise && inflightSnapshots.get(cacheKey) === owner.promise) inflightSnapshots.delete(cacheKey)
        activeRebuilds -= 1
      }
    })()
    owner.promise = promise
    inflightSnapshots.set(cacheKey, promise)
    return promise
  }

  async function snapshot(args: { path?: string; includeArchived?: boolean; preferCached?: boolean }): Promise<RpcResult<SnapshotPayload>> {
    const query = p.sessionQuery
    const path = args && typeof args.path === 'string' ? args.path : ''
    if (!query) return failure(ERR.SERVICE_UNAVAILABLE, '服务暂不可用', true)
    if (!path) return failure(ERR.WORKSPACE_UNAVAILABLE, '无法确定工作区', false)

    // PATH-01: 权威键作缓存键与工作区标识（C:\Work 与 c:/work/ 命中同一缓存）
    const key = canonicalKey(path)
    // ARCH-03: 可见性变体缓存键——默认（不含归档）与"显示归档"各自独立缓存/in-flight
    const includeArchived = args && args.includeArchived === true
    const preferCached = includeArchived && args?.preferCached === true
    const cacheKey = includeArchived ? key + '#arch' : key

    const now = Date.now()
    const hit = snapshots.get(cacheKey)
    const ttl = includeArchived ? ARCHIVED_SNAPSHOT_TTL : SNAPSHOT_TTL
    if (hit && now - hit.fetchedAt < ttl) return deps.success(hit.payload)

    // PERF-05 并发合并：同 key 已有重建在途 → join（60 并发只发生一次底层查询）
    const inflight = inflightSnapshots.get(cacheKey)
    if (preferCached) {
      // ARCH-PERF-04: 首次显示不等待几十个冷日志。完整重建在后台进行；若有过期
      // 全量快照就先返回旧快照，否则约 200ms 构建只含结构/缓存标题的骨架。
      const background = inflight || startSnapshotRebuild(cacheKey, key, path, true)
      if (background) void background.catch(() => undefined)
      if (hit) return deps.success({ ...hit.payload, hydrating: true })
      const skeletonKey = cacheKey + '#skeleton'
      const skeletonHit = snapshots.get(skeletonKey)
      if (skeletonHit && now - skeletonHit.fetchedAt < ARCHIVED_SNAPSHOT_TTL) {
        return deps.success(skeletonHit.payload)
      }
      const skeletonInflight = inflightSnapshots.get(skeletonKey)
      if (skeletonInflight) return skeletonInflight
      const epoch0 = cacheEpochs.get(cacheKey) || 0
      const skeletonPromise = buildSnapshot(cacheKey, key, path, true, epoch0, false).then((skeleton) => {
        if (skeleton.ok && (cacheEpochs.get(cacheKey) || 0) === epoch0) cacheSnapshot(skeletonKey, skeleton.data)
        return skeleton
      })
      inflightSnapshots.set(skeletonKey, skeletonPromise)
      try {
        return await skeletonPromise
      } finally {
        if (inflightSnapshots.get(skeletonKey) === skeletonPromise) inflightSnapshots.delete(skeletonKey)
      }
    }

    if (inflight) return inflight
    const promise = startSnapshotRebuild(cacheKey, key, path, includeArchived)
    if (!promise) {
      // PERF-05 全局信号量：不同 key 的并发重建封顶，普通请求快速失败不堆积。
      return failure(ERR.SERVICE_UNAVAILABLE, '服务繁忙，请稍后重试', true)
    }
    return promise
  }

  return {
    snapshot,
    requireWorkspaceMember,
    authorizeMany,
    invalidateWorkspace,
    createAgentStatusService,
    disposeAgentTracking,
  }
}

type SubagentsRef = NonNullable<DshHostServices['subagents']>
type SessionQueryRef = NonNullable<DshHostServices['sessionQuery']>
