/**
 * dsh-brvis — 权威工作区键（PATH-01）。
 * 独立模块以便测试与复用在 snapshot/guard/cache/mutation。
 * 语义：绝对化 + realpath（解析 Junction/符号链接/..）+ 统一分隔符 + Windows 驱动器大写。
 * realpath 失败（路径不存在/权限不足）时回退 resolve+归一，并标记 degraded=true，
 * 供调用方决定是否拒绝写操作（文档 §15 第 5 条：规范化失败默认拒绝 mutation）。
 *
 * 本模块只跑在 Host（Node ESM），直接 import node:path / node:fs。
 * 若未来 host 编译目标被限制为无 Node 内置模块的 bundle，
 * 需改为注入依赖（constructor injection），不在此处 try/catch。
 */

import * as nodePath from 'node:path'
import * as nodeFs from 'node:fs'

export interface CanonicalKeyResult {
  key: string
  degraded: boolean
}

// BUGFIX-05: realpathSync 是同步磁盘 I/O——快照重建会对每个会话 header.cwd 各调一次
// canonicalKey()(N 次 realpathSync),全部阻塞宿主事件循环,放大 PERF-05 已修的快照开销。
// 加进程级缓存: 同一 resolved 路径 10s 内复用 realpath 结果;失败(路径暂不存在)短 TTL 2s,
// 路径刚创建后能较快重试成功。缓存按 resolved 路径做键(纯字符串),命中不触发任何 I/O。
const REALPATH_CACHE_MAX = 512
const REALPATH_OK_TTL = 10_000
const REALPATH_FAIL_TTL = 2_000
const realpathCache = new Map<string, { real: string | null; at: number }>()

function cachedRealpath(resolved: string): string | null {
  const hit = realpathCache.get(resolved)
  const now = Date.now()
  if (hit) {
    const ttl = hit.real === null ? REALPATH_FAIL_TTL : REALPATH_OK_TTL
    if (now - hit.at < ttl) return hit.real
    realpathCache.delete(resolved)
  }
  let real: string | null
  try {
    real = nodeFs.realpathSync(resolved)
  } catch {
    real = null
  }
  realpathCache.set(resolved, { real, at: now })
  // 简单淘汰: 超出上限删最旧(容量内 Map 顺序即插入序)
  if (realpathCache.size > REALPATH_CACHE_MAX) {
    const oldest = realpathCache.keys().next().value
    if (oldest !== undefined) realpathCache.delete(oldest)
  }
  return real
}

export function canonicalWorkspaceKey(input: string): CanonicalKeyResult {
  const raw = String(input || '')
  if (!raw) return { key: '', degraded: false }
  let resolved: string
  try {
    resolved = nodePath.resolve(raw)
  } catch {
    resolved = raw
  }
  const real = cachedRealpath(resolved)
  let key = normalizeChar(real || resolved)
  // Windows: 驱动器字母统一大写（文件系统语义对大小写不敏感）
  if (/^[a-z]:/.test(key)) key = key.slice(0, 1).toUpperCase() + key.slice(1)
  return { key, degraded: !real }
}

/** 字符层面归一（统一分隔符/尾部斜杠——调用方决定大小写策略）。 */
export function normalizeChar(p: string): string {
  let s = String(p || '').replace(/\\/g, '/')
  while (s.length > 1 && s.endsWith('/')) s = s.slice(0, -1)
  return s
}