/**
 * dsh-brvis — host 写操作层（重命名 / 归档）。
 * 拆分自原单文件 src/index.ts（2026-08）。
 * 工厂 createMutations(ctx, deps) 注入运行时服务与共享工具；
 * deps 由装配层提供：success / failure / ERR / dataOps（快照授权与失效）。
 * COMPAT-01: DSH 服务句柄统一来自 deps.platform（adapter）；测试 mock 走 fallback。
 */
import { createFallbackPlatform } from '../platform/adapters/dsh-preview-2026-08/host.js'
import type { DshHostServices } from '../shared/dsh-contract.js'
import type {
  ArchiveItemResult, ArchiveManyPayload, BrvisErrorCodeValue, RpcFailure, RpcResult, RpcSuccess,
} from '../shared/contract.js'

interface MutationsDeps {
  platform?: DshHostServices
  success: RpcSuccess
  failure: RpcFailure
  ERR: Record<string, BrvisErrorCodeValue>
  MAX_TITLE_BYTES: number
  dataOps: {
    requireWorkspaceMember(sessionId: string, path: string): Promise<RpcResult<{ header: unknown }> & { ok: boolean }>
    authorizeMany(ids: string[], path: string): Promise<{ ok: boolean; failures: { sessionId: string | null; code: BrvisErrorCodeValue; message: string }[] }>
    invalidateWorkspace(path: string, options?: { titleIds?: Iterable<string> }): void
  }
}

interface RenameArgs { sessionId?: string; title?: string; path?: string }
interface ArchiveArgs { sessionId?: string; path?: string }
interface ArchiveManyArgs { path?: string; sessionIds?: unknown }

export function createMutations(ctx: unknown, deps: MutationsDeps) {
  const { success, failure, ERR, dataOps } = deps
  // COMPAT-01: DSH 服务句柄来自 adapter；fallback 供测试 mock ctx（DSH 键只在 adapter 文件）
  const p = deps.platform || createFallbackPlatform(ctx as { get(name: string): unknown })

  // ============ 重命名 ============
  // TextEncoder 计算标题 UTF-8 字节长度(受 Builtin 约束,不使用 Buffer)
  const _encoder = typeof TextEncoder !== 'undefined' ? new TextEncoder() : null
  function utf8ByteLength(s: string): number {
    if (_encoder) return _encoder.encode(s).byteLength
    // 极度回退:用 1.5 倍估算,宁宽勿窄,不会导致安全问题
    return Math.ceil(s.length * 1.5)
  }

  // 控制字符检测(用码点,避免 JS 转义序列在传递中被误解码)
  function hasControlChar(t: string): boolean {
    for (let i = 0; i < t.length; i++) {
      const c = t.charCodeAt(i)
      if (c < 32 || c === 127) return true
    }
    return false
  }

  function validateTitle(title: unknown): string | null {
    if (typeof title !== 'string') return '标题必须为字符串'
    const t = title.trim()
    if (!t) return '标题不能为空'
    if (hasControlChar(t)) return '标题包含不允许的控制字符'
    if (utf8ByteLength(t) > deps.MAX_TITLE_BYTES) return '标题过长'
    return null
  }

  // 冷会话:按 sessionId 重新查询并追加标题事件。带并发冲突检测 + 有限重试。
  // RENAME-01: 最终冲突必须返回 conflict:true（旧代码冲突分支不可达,永远 false）;
  // 冲突识别用结构化错误码/字段,不用任意错误文本正则作为长期契约。
  async function appendColdTitle(sessionId: string, title: string) {
    const query = p.sessionQuery
    const persistence = p.sessionPersistence
    if (!query || !persistence) return { conflict: false, errorMessages: ['服务不可用'] }

    // 冲突信号:错误对象带 code 字段或消息含明确冲突语义
    //（DSH persistence append 冲突为受控错误,不做模糊匹配;其余错误直接返回）
    // REV-08（2026-08-18）决策记录：下方消息正则兜底是**临时兼容层**（RENAME-01 原文
    // "不用任意错误文本正则作为长期契约"尚未兑现）。取舍：保留正则 + 结构化 code 双通道，
    // 但在此标记——长期应只认结构化 code（如 SEQUENCE_CONFLICT/SEQ_CONFLICT），
    // 删除正则须同步删除依赖"文本冲突"的旧 DSH 兼容案例后再执行。
    function isConflictError(e: unknown): boolean {
      const obj = e && typeof e === 'object' ? e as Record<string, unknown> : null
      if (obj && (obj.code === 'SEQUENCE_CONFLICT' || obj.code === 'SEQ_CONFLICT' || obj.code === 'Conflict')) return true
      // ── 临时兼容（见上方 REV-08 决策记录）：结构化 code 之外的文本兜底 ──
      const text = String(((e as { message?: unknown }) && (e as { message?: unknown }).message) || e)
      return /(^|\s)(seq|sequence|conflict)(\s|$)/i.test(text) ||
        /(序号冲突|并发出错|版本冲突)/.test(text)
    }

    const maxAttempts = 2
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      let log: Awaited<ReturnType<NonNullable<SessionQueryRef['readSession']>>> | undefined
      try {
        // query 已在函数入口 guard，闭包内 TS 无法保留收窄 → 显式断言
        log = await (query as SessionQueryRef).readSession!(sessionId)
      } catch (e) {
        return { conflict: false, errorMessages: [String((e && (e as { message?: unknown }).message) || e)] }
      }
      if (!log || !log.events || !log.events.length) {
        return { conflict: false, errorMessages: ['会话无日志'] }
      }
      const lastEvent = log.events[log.events.length - 1]
      // REV-07（2026-08-18）：防御性校验 —— seq 缺失/非数字时回退为 null 并拒绝写入，
      // 否则 `lastSeq + 1` 得到 NaN，写入带 NaN seq 可能被 DSH persistence 拒绝或毁坏事件序。
      const lastSeq = (lastEvent && typeof lastEvent.seq === 'number' && Number.isFinite(lastEvent.seq))
        ? lastEvent.seq
        : null
      if (lastSeq === null) {
        return { conflict: false, errorMessages: ['会话日志缺少有效序号，无法安全改名'] }
      }
      try {
        await persistence.append(sessionId, [{
          type: 'session/title',
          seq: lastSeq + 1,
          time: Date.now(),
          data: { title, messageSeqs: [], source: { kind: 'user' } },
        }])
        return { conflict: false, errorMessages: [] }
      } catch (e) {
        // 结构化/明确冲突 → 睡 60ms 后重试一轮; 非冲突错误直接返回
        if (isConflictError(e) && attempt < maxAttempts - 1) {
          try {
            const timer = p.timer
            if (timer) await timer.timeout(60)
          } catch (te) { /* timer 不可用时直接重试 */ }
          continue
        }
        // RENAME-01: 两轮都冲突 → conflict:true; 非冲突错误保持原样
        return isConflictError(e)
          ? { conflict: true, errorMessages: ['标题事件发生写入冲突'] }
          : { conflict: false, errorMessages: [String((e && (e as { message?: unknown }).message) || e)] }
      }
    }
    // 理论不可达：循环内所有路径均已 return，保留冲突语义兜底（防御性）
    return { conflict: true, errorMessages: ['标题事件发生写入冲突'] }
  }

  async function renameNode(args: RenameArgs): Promise<RpcResult<unknown>> {
    const sessionId = args && args.sessionId
    const title = args && args.title
    const path = args && typeof args.path === 'string' ? args.path : ''
    const invalid = validateTitle(title)
    if (invalid) return failure(ERR.INVALID_TITLE, invalid, false)
    if (typeof sessionId !== 'string' || !sessionId) {
      return failure(ERR.BAD_REQUEST, '会话参数无效', false)
    }
    const sessionIdStr: string = sessionId

    const auth = await dataOps.requireWorkspaceMember(sessionIdStr, path)
    if (!auth.ok) return auth

    let finalTitle = ((title as string) || '').trim()
    const titleSvc = p.sessionTitle
    const sessions = p.sessions as { get? (id: string): unknown } | undefined
    const getter = sessions && sessions.get
    let liveSession: unknown
    try {
      liveSession = getter ? getter.call(sessions, sessionIdStr) : undefined
    } catch (e) {
      liveSession = undefined
    }
    try {
      if (liveSession && titleSvc && typeof titleSvc.rename === 'function') {
        titleSvc.rename(liveSession, finalTitle)
        // 尝试读取权威最终值;读不到用输入值
        try {
          const snap = await p.sessionQuery?.readTitleSnapshots?.([sessionIdStr])
          if (snap && snap[0] && snap[0].status === 'fulfilled' && snap[0].value && snap[0].value.title && typeof snap[0].value.title.title === 'string') {
            finalTitle = snap[0].value.title.title
          }
        } catch (e) { /* 保持输入值 */ }
      } else {
        const res = await appendColdTitle(sessionIdStr, finalTitle)
        if (res.errorMessages.length) {
          return failure(res.conflict ? ERR.SEQUENCE_CONFLICT : ERR.INTERNAL_ERROR, res.conflict ? '名称保存发生冲突,请重试' : '名称保存失败', res.conflict)
        }
      }
      // 结构快照全部失效，但标题缓存只删除真正被改名的会话。
      dataOps.invalidateWorkspace(path, { titleIds: [sessionIdStr] })
      return success({ sessionId, title: finalTitle })
    } catch (e) {
      console.error('[brvis] rename failed')
      return failure(ERR.INTERNAL_ERROR, '重命名失败', false)
    }
  }

  // ============ 归档 ============
  // 归档级联（2026-08）：DSH 的 workspaceRegistry.archiveSession 只归档单个会话，
  // 不自动归档该会话的子代理。子代理是独立 session（节点在画布中显示为子代理标记）。
  // 真实契约：subagents.listDescendants(rootId) 枚举整棵后代树（含 depth/parentId）。
  // 用户归档父节点时应一并归档其所有后代子代理，否则子代理仍留在工作区（本缺陷根因）。
  async function collectDescendantIds(sessionIds: string[]): Promise<Set<string>> {
    const subagents = p.subagents
    if (!subagents || typeof subagents.listDescendants !== 'function') return new Set()
    const all = new Set<string>()
    // PERF-04: 并行收集后代(受限并发),避免逐条 await 串行排队拖慢归档
    // (旧实现: for..await 逐个 listDescendants,选中多节点时分批串行,宿主阻塞敏感)。
    const CONCURRENT = 4
    let cursor = 0
    // subagents 已在函数入口 guard，闭包内 TS 无法保留收窄 → 显式断言
    const subagentsRef = subagents as NonNullable<typeof subagents>
    async function worker(): Promise<void> {
      while (cursor < sessionIds.length) {
        const id = sessionIds[cursor++]
        try {
          const entries = await subagentsRef.listDescendants!(id)
          for (const entry of entries || []) {
            if (entry && entry.id && entry.id !== id) all.add(entry.id)
          }
        } catch (e) { /* 单棵收集失败不阻塞整体 */ }
      }
    }
    const workers: Promise<void>[] = []
    const n = Math.min(CONCURRENT, Math.max(1, sessionIds.length))
    for (let i = 0; i < n; i++) workers.push(worker())
    await Promise.all(workers)
    return all
  }

  async function archiveMany(args: ArchiveManyArgs): Promise<RpcResult<ArchiveManyPayload>> {
    const path = args && typeof args.path === 'string' ? args.path : ''
    const rawIds = args && Array.isArray(args.sessionIds) ? (args.sessionIds as unknown[]) : []
    if (!path) return failure(ERR.WORKSPACE_UNAVAILABLE, '无法确定工作区', false)
    if (!rawIds.length) return failure(ERR.BAD_REQUEST, '没有要归档的会话', false)
    if (rawIds.length > 100) return failure(ERR.BAD_REQUEST, '单次最多归档 100 个会话', false)

    // ARCHIVE-01: 全格式校验 + 去重（保留首次出现顺序）。任一非法 → 整批 BAD_REQUEST，不写入。
    const sessionIds: string[] = []
    const seen = new Set<string>()
    const badFormat: unknown[] = []
    for (const id of rawIds) {
      const valid = typeof id === 'string' && !!id && id.length > 0 && id.length <= 200
      if (!valid) { badFormat.push(id); continue }
      if (!seen.has(id)) { seen.add(id); sessionIds.push(id) }
    }
    if (badFormat.length) {
      return failure(ERR.BAD_REQUEST, '会话参数无效: 包含非法 ID，整批未归档', false)
    }
    if (!sessionIds.length) return failure(ERR.BAD_REQUEST, '会话参数无效', false)

    // ARCHIVE-01: 单次 listSessions 批量授权（不再每项全量扫描）；
    // 任一 id 不在工作区/不存在 → 整批授权失败，不写入。
    const auth = await dataOps.authorizeMany(sessionIds, path)
    if (!auth.ok) {
      const f = (auth.failures && auth.failures[0]) || { code: undefined, message: undefined }
      const code = (f.code as BrvisErrorCodeValue) || ERR.SESSION_NOT_FOUND
      return failure(code, f.message || '归档授权失败', false)
    }

    // 归档级联：收集选中会话的全部后代子代理 id，一并归档。
    // 结果仍按输入 sessionIds 返回（前端只关心选中项）；级联项计入随后的执行。
    const descendantIds = await collectDescendantIds(sessionIds)
    // BUGFIX-04: 级联后代同样必须通过授权校验——理论上子代理继承父会话 cwd,
    // 但若 DSH 数据异常(子代理 cwd 被改动/跨工作区残留),不校验会把归档写出
    // 工作区边界,违背 ARCHIVE-01"任一 id 越界 → 整批拒绝"语义。去重后单独
    // authorizeMany(单次 listSessions 索引,不逐项全量扫描)。
    const extraDescendantIds: string[] = []
    for (const id of descendantIds) if (!seen.has(id)) extraDescendantIds.push(id)
    if (extraDescendantIds.length) {
      const extraAuth = await dataOps.authorizeMany(extraDescendantIds, path)
      if (!extraAuth.ok) {
        const f = (extraAuth.failures && extraAuth.failures[0]) || { code: undefined, message: undefined }
        const code = (f.code as BrvisErrorCodeValue) || ERR.SESSION_NOT_FOUND
        return failure(code, f.message || '归档授权失败（含子代理后代）', false)
      }
    }
    const execIds = sessionIds.slice()
    for (const id of extraDescendantIds) execIds.push(id)
    // 输入项在 execIds 中的索引即 results 预分配位（去重后 sessionIds 无重复，直接映射）
    const inputIndexById = new Map<string, number>()
    for (let i = 0; i < sessionIds.length; i++) inputIndexById.set(sessionIds[i], i)

    // 并发受限归档；结果按输入顺序预分配（ARCHIVE-01：不按完成顺序 push）
    const results: (ArchiveItemResult | undefined)[] = new Array(sessionIds.length)
    let cursor = 0
    let cascadeFailedCount = 0
    // PERF-04: 6→4。archiveSession 是 DSH 写操作(文件/索引变更),并发过高时
    // 与轮询快照重建叠加会挤占宿主事件循环(用户反馈:归档时视频卡顿)。
    const CONCURRENT = 4
    async function worker(): Promise<void> {
      while (cursor < execIds.length) {
        const idx = cursor++
        const id = execIds[idx]
        const r = await archiveAuthorized(id, path)
        // AUD-11（2026-08-18）：级联项失败不再静默——父归档成功、某后代子代理
        // 归档抛错时必须计数并透出，前端提示「部分子代理未归档」。
        const inputIdx = inputIndexById.get(id)
        if (inputIdx !== undefined) {
          // 输入项写 results 对应位
          results[inputIdx] = r
        } else if (!r.ok) {
          cascadeFailedCount += 1
        }
      }
    }
    const workers: Promise<void>[] = []
    const k = Math.min(CONCURRENT, Math.max(1, execIds.length))
    for (let i = 0; i < k; i++) workers.push(worker())
    await Promise.all(workers)

    // 输入项中有成功即可失效缓存（级联项也一并归档了，缓存必然过期）
    let succeededCount = 0
    for (const r of results) if (r && r.ok) succeededCount += 1
    if (succeededCount) dataOps.invalidateWorkspace(path)
    return success({
      results,
      succeededCount,
      failedCount: sessionIds.length - succeededCount,
      cascadeFailedCount,
    })
  }

  // ARCHIVE-01: 仅接受已授权 ID 的归档执行体——不再次查询授权（已由 authorizeMany 单次完成）。
  async function archiveAuthorized(sessionId: string, _path: string): Promise<ArchiveItemResult> {
    const registry = p.workspaceRegistry
    if (!registry || typeof registry.archiveSession !== 'function') {
      return { sessionId, ok: false, code: ERR.SERVICE_UNAVAILABLE }
    }
    try {
      await registry.archiveSession(sessionId)
      return { sessionId, ok: true, code: null, archived: true }
    } catch (e) {
      console.error('[brvis] archive failed')
      return { sessionId, ok: false, code: ERR.ARCHIVE_FAILED }
    }
  }

  // 单归档:兼容旧前端(按部分成功语义返回结果数组)
  async function archiveNode(args: ArchiveArgs): Promise<RpcResult<unknown>> {
    const sessionId = args && args.sessionId
    const path = args && typeof args.path === 'string' ? args.path : ''
    const res = await archiveMany({ path, sessionIds: sessionId ? [sessionId] : [] })
    if (!res.ok) return res
    const one = res.data.results[0]
    return one && one.ok
      ? success({ sessionId, archived: true })
      : failure(one ? one.code || ERR.INTERNAL_ERROR : ERR.INTERNAL_ERROR, '归档失败', !!(one && (one.code === ERR.ARCHIVE_FAILED || one.code === ERR.SERVICE_UNAVAILABLE)))
  }

  return { renameNode, archiveNode, archiveMany, validateTitle }
}

type SessionQueryRef = NonNullable<DshHostServices['sessionQuery']>
