/**
 * dsh-brvis — HTTP 安全边界（HTTP-01 方案 B）与请求体读取。
 * 从装配层 index.ts 抽出，独立可测。
 *
 * 安全边界:
 *   1. 仅 POST → 405
 *   2. Content-Type: application/json 强制 → 415
 *   3. 自定义 header X-Brvis-Request: 1 强制（跨站无 CORS 许可不能发送）→ 403
 *   4. Sec-Fetch-Site: cross-site 明确拒绝 → 403
 *   5. Origin 存在时只接受当前 server origin → 403
 *   6. body 64KiB 上限 → 413
 *   7. aborted/close 处理
 *   8. 响应 Cache-Control: no-store + X-Content-Type-Options: nosniff
 */

/** 最小请求形状（http.IncomingMessage 的字段子集，测试可注入 mock）。 */
export interface HttpGuardRequest {
  method?: string
  url?: string
  headers: Record<string, string | string[] | undefined>
}

export type HttpGuardResult =
  | { ok: true }
  | { ok: false; status: number; code: string; message: string }

// REV-12（2026-08-18）威胁模型注释声明：
// Origin 校验的"当前 server origin"基准取自 `Host` 请求头，同时接受 http/https。
// **边界**：Host 头理论上可被本机进程伪造，因此本校验
// 防的是"陌生浏览器页面/跨站"（无 CORS 许可发不出 X-Brvis-Request 与自定义 Origin 组合），
// **不声称防同机恶意进程**。
// 7.4（2026-08-18）复查结论：无法做到"从 webServer 装配处注入真实 expectedOrigin"——
// 复核 DSH webServer 契约（register/registerUpgrade/registerFallback/tapIndex/
// applyIndexTaps），**不暴露监听端口/host 读取接口**；host Builtin 亦无 process.env。
// 故运行时基准只能取 Host 请求头。同源访问端口变化不受影响；反向代理必须保留 Host。

/**
 * 校验请求安全边界（在任何业务处理之前执行）。
 * 返回 ok:true 表示通过；否则携带 HTTP 状态码与错误契约。
 */
export function checkHttpGuard(req: HttpGuardRequest): HttpGuardResult {
  // 4. Sec-Fetch-Site: cross-site → 拒绝（CSRF 缓解）
  const secFetchSiteRaw = req.headers['sec-fetch-site']
  const secFetchSite = Array.isArray(secFetchSiteRaw) ? secFetchSiteRaw[0] : secFetchSiteRaw
  if (secFetchSite && secFetchSite === 'cross-site') {
    return { ok: false, status: 403, code: 'FORBIDDEN', message: 'cross-site 请求被拒绝' }
  }
  // 5. Origin 只接受当前 server origin（无 Origin 按本机进程威胁模型处理）
  const origin = req.headers['origin']
  if (origin) {
    const hostRaw = req.headers['host']
    const host = String(Array.isArray(hostRaw) ? hostRaw[0] : (hostRaw || '')).trim()
    const originStr = Array.isArray(origin) ? origin[0] : origin
    if (!host || (originStr !== 'http://' + host && originStr !== 'https://' + host)) {
      return { ok: false, status: 403, code: 'FORBIDDEN', message: 'Origin 校验失败' }
    }
  }
  // 1. 仅 POST
  if (req.method !== 'POST') {
    return { ok: false, status: 405, code: 'METHOD_NOT_ALLOWED', message: '仅支持 POST' }
  }
  // 2. Content-Type 强制 json
  const ctRaw = req.headers['content-type']
  const ct = String(Array.isArray(ctRaw) ? ctRaw[0] : (ctRaw || '')).split(';')[0].trim().toLowerCase()
  if (ct !== 'application/json') {
    return { ok: false, status: 415, code: 'UNSUPPORTED_MEDIA_TYPE', message: 'Content-Type 必须为 application/json' }
  }
  // 3. 自定义 header 强制（CSRF 缓解）
  const markerRaw = req.headers['x-brvis-request']
  const marker = Array.isArray(markerRaw) ? markerRaw[0] : markerRaw
  if (marker !== '1') {
    return { ok: false, status: 403, code: 'FORBIDDEN', message: '缺少 X-Brvis-Request header' }
  }
  return { ok: true }
}

/** 读请求体（HTTP-01：64KiB 上限，超限 reject BODY_TOO_LARGE；处理 aborted/close）。 */
export const MAX_BODY_BYTES = 64 * 1024

// Node http.IncomingMessage 的事件接口子集（测试 mock 需实现）
export interface BodyReadable {
  on(event: 'data' | 'end' | 'error' | 'aborted', listener: (...args: unknown[]) => void): unknown
  removeAllListeners(event: string): unknown
  destroy?(): unknown
}

export function readBody(req: BodyReadable, maxBytes?: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const limit = maxBytes || MAX_BODY_BYTES
    let size = 0
    const chunks: Buffer[] = []
    let settled = false
    const done = <T,>(fn: (v: T) => void, arg: T) => {
      if (settled) return
      settled = true
      fn(arg)
    }
    req.on('data', (c) => {
      size += (c as Buffer).length
      if (size > limit) {
        req.removeAllListeners('data')
        req.removeAllListeners('end')
        // AUD-04（2026-08-18）：不再 destroy socket——destroy 会联动销毁 res，
        // 路由层的 413 永远写不出去（客户端只见 ECONNRESET，且按 NETWORK_ERROR
        // retryable 重试形成循环）。连接由 index.ts 发完 413 后以 connection: close 关闭。
        done(reject, Object.assign(new Error('request body too large'), { code: 'BODY_TOO_LARGE' }))
        return
      }
      chunks.push(c as Buffer)
    })
    req.on('end', () => done(resolve, Buffer.concat(chunks).toString('utf8')))
    req.on('error', (e) => done(reject, e))
    req.on('aborted', () => done(reject, Object.assign(new Error('request aborted'), { code: 'ABORTED' })))
  })
}
