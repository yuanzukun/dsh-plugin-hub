/**
 * dsh-branch-visualizer — host 装配层（入口）。
 * 本文件仅保留 @ts-nocheck：webServer.register 的 handler 签名依赖 DSH 内部
 * IncomingMessage/ServerResponse 类型（非 DOM lib），暂按保守 any 处理；
 * 业务逻辑（data/mutations/adapter/ports）已全部类型化。
 *
 * 拆分说明（2026-08）：原单文件 src/index.ts（~540 行）按职责拆分——
 *   - index.ts              本文件：apply 装配、RPC 契约、webServer 路由注册、生命周期
 *   - host/data.ts          数据读取层：快照构建 / 缓存 / 授权边界 / 子代理收集 / agent 追踪
 *   - host/mutations.ts     写操作层：重命名 / 归档（含标题校验、冷会话追加、并发归档）
 * 出错定位：快照数据错乱→data.ts；改名/归档失败→mutations.ts；路由/生命周期→index.ts。
 *
 * 宿主端不再用 harness.handle RPC，
 * 改为 webServer prefix 路由 /brvis/api（同源 fetch JSON）。
 */
// @ts-nocheck — 见文件头注释（TYPECHECK-01：webServer handler 类型豁免）
export const name = 'dsh-branch-visualizer'
// webServer 是硬依赖（客户端全靠同源 fetch 走这里）；其余服务照旧 ctx.get 可选
export const inject = ['webServer']

import { createDataOps } from './host/data.js'
import { createMutations } from './host/mutations.js'
import { canonicalWorkspaceKey } from './host/canonical-path.js'
import { createDshHostServices, ADAPTER_ID } from './platform/adapters/dsh-preview-2026-08/host.js'
import { BrvisErrorCode as ERR, ROUTE_PREFIX } from './shared/contract.js'
import { probeHostCapabilities } from './platform/capabilities.js'
import { buildCompatibilityReport } from './platform/diagnostics.js'
import { checkHttpGuard, readBody } from './host/http-guard.js'
import { createRequire } from 'node:module'

// RELEASE-01: 版本号从 package.json 读取，避免与 manifest 漂移（diagnostics 报告用）
const PKG_VERSION = (() => {
  try {
    const require2 = createRequire(import.meta.url)
    const pkg = require2('../package.json')
    return (pkg && pkg.version) || '0.1.0'
  } catch { return '0.1.0' }
})()

export function apply(ctx) {
  // ============ RPC 统一契约 ============
  function success(data) {
    return { ok: true, data: data === undefined ? null : data }
  }
  function failure(code, message, retryable) {
    return { ok: false, error: { code, message, retryable: !!retryable } }
  }

  // 公共错误码（CONTRACT-01：来自 src/shared/contract.ts，Host/Client 共用）
  const MAX_TITLE_BYTES = 120

  // ============ 业务模块（工厂注入 ctx + 共享依赖） ============
  // COMPAT-01: DSH 服务句柄由 adapter 提供，业务层不再直接 ctx.get
  const platform = createDshHostServices(ctx)
  const dataOps = createDataOps(ctx, { success, failure, ERR, canonicalWorkspaceKey, platform })
  // 注：mutations 只收 dataOps/platform；授权路径统一走 PATH-01 权威键（normalizePath 已移除）
  const mutations = createMutations(ctx, {
    success, failure, ERR, MAX_TITLE_BYTES,
    dataOps, platform,
  })

  // agent 状态事件追踪（STATUS-01：订阅真实 DSH 事件 agent/status|created|disposed，
  // 初始化遍历 agents.list()；失败静默降级为 agents.get 两态）
  dataOps.createAgentStatusService()

  // ============ webServer API（客户端同源 fetch 走这里；HTTP-01 收紧边界） ============
  // 路由契约（仅 POST）:
  //   POST {ROUTE_PREFIX}/snapshot {path}
  //   POST {ROUTE_PREFIX}/rename   {sessionId,title,path}
  //   POST {ROUTE_PREFIX}/archive  {sessionId,path}
  //   POST {ROUTE_PREFIX}/archiveMany {path,sessionIds}
  //   POST {ROUTE_PREFIX}/diagnostics {}          → 兼容报告（只读，仍走安全校验）
  // 安全边界（HTTP-01 方案 B）:
  //   1. 仅 POST（GET snapshot 已删除，方法不允许 → 405）
  //   2. Content-Type: application/json 强制 → 415
  //   3. 自定义 header X-Brvis-Request: 1 强制（跨站无 CORS 许可不能发送）→ 403
  //   4. Sec-Fetch-Site: cross-site 明确拒绝 → 403
  //   5. Origin 存在时只接受当前 server origin → 403
  //   6. body 64KiB 上限（readBody 实现）→ 413
  //   7. aborted/close 处理
  //   8. 响应 Cache-Control: no-store + X-Content-Type-Options: nosniff
  //   9. 405 / 415 / 400 / 413 正确状态码
  const routeDisposer = ctx.webServer.register({
    kind: 'prefix',
    path: ROUTE_PREFIX,
    handler: async (req, res) => {
      const send = (code, obj, extraHeaders) => {
        // HTTP-01/PERF-05: 连接已断开则不写响应（避免在 destroyed socket 上
        // writeHead 抛 ERR_STREAM_DESTROYED 叠加；压测 P5 断连风暴的防护）。
        if (req.aborted || req.readableAborted || res.destroyed || res.writableEnded) return
        res.writeHead(code, {
          'content-type': 'application/json; charset=utf-8',
          'cache-control': 'no-store',
          'x-content-type-options': 'nosniff',
          ...(extraHeaders || {}),
        })
        res.end(JSON.stringify(obj))
      }
      const errorObj = (code, message, retryable) =>
        ({ ok: false, error: { code, message, retryable: !!retryable } })
      try {
        // ── HTTP-01 安全校验（在任何业务处理之前，已抽离 http-guard.ts） ──
        const guard = checkHttpGuard(req)
        if (!guard.ok) {
          return send(guard.status, errorObj(guard.code, guard.message, false))
        }

        const url = new URL(req.url ?? '/', 'http://localhost')
        const path = url.pathname.replace(new RegExp('^' + ROUTE_PREFIX.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')), '') || '/'
        // 读取 body（64KiB 上限 → 超限 reject BODY_TOO_LARGE）
        let body
        try {
          const raw = await readBody(req)
          body = raw ? JSON.parse(raw) : {}
        } catch (e) {
          if (e && e.code === 'BODY_TOO_LARGE') {
            // AUD-04（2026-08-18）：readBody 已不再提前 destroy socket，413 现在真实可达。
            // connection: close——客户端可能仍在发送超限 body，连接不得回 keep-alive 池；
            // finish 后销毁底层 socket 兜底（响应已刷出，客户端能完整收到 413）。
            send(413, errorObj(ERR.PAYLOAD_TOO_LARGE, '请求体超过 64KiB 上限', false), { connection: 'close' })
            res.on('finish', () => { try { req.destroy() } catch { /* 已销毁则忽略 */ } })
            return
          }
          if (e && e.code === 'ABORTED') return
          return send(400, errorObj(ERR.BAD_REQUEST, '请求体不是合法 JSON', false))
        }
        // PERF-05: body 读取期间客户端已断开 → 直接放弃，不再触发快照重建
        // （压测 P5 的 1ms 超时/立即 abort 风暴会让已断请求白跑全量重建并堆积）
        if (req.aborted || req.readableAborted || res.destroyed) return
        if (path === '/snapshot') {
          const result = await dataOps.snapshot({
            path: String(body?.path ?? ''),
            includeArchived: body?.includeArchived === true,
            preferCached: body?.preferCached === true,
          })
          return send(200, result)
        }
        if (path === '/diagnostics') {
          // COMPAT-01：能力探测（只读形状，不调用 mutation）→ 去敏兼容报告
          const caps = probeHostCapabilities(platform)
          const missing = []
          if (caps.sessionRead !== 'available') missing.push('sessionRead')
          if (caps.archive !== 'available') missing.push('archive')
          if (caps.agentStatus === 'missing') missing.push('agentStatus')
          const report = buildCompatibilityReport({
            pluginVersion: PKG_VERSION,
            hostCapabilities: caps,
            adapterId: ADAPTER_ID,
            missing,
          })
          return send(200, { ok: true, data: report })
        }
        if (path === '/rename') {
          const result = await mutations.renameNode({ sessionId: body?.sessionId, title: body?.title, path: body?.path })
          return send(200, result)
        }
        if (path === '/archive') {
          const result = await mutations.archiveNode({ sessionId: body?.sessionId, path: body?.path })
          return send(200, result)
        }
        if (path === '/archiveMany') {
          const result = await mutations.archiveMany({ path: body?.path, sessionIds: body?.sessionIds })
          return send(200, result)
        }
        return send(404, errorObj(ERR.NOT_FOUND, 'not found: ' + path, false))
      } catch (e) {
        console.error('[brvis] API request failed')
        return send(500, errorObj(ERR.INTERNAL_ERROR, '操作失败,请重试', true))
      }
    },
  })

  // ============ 生命周期 ============
  ctx.effect(() => () => {
    routeDisposer()
    dataOps.disposeAgentTracking()
  })
}
