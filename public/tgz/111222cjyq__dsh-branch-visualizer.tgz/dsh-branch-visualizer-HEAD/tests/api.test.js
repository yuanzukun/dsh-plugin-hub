/**
 * api.test.js — 客户端 RPC 传输层（同源 fetch /brvis/api）。
 * 直接测试 lib/client/api.js（生产产物，TEST-01 同款策略）。
 * 覆盖 callRpc 全路径：成功 / 业务错误 / 网络错误 / 超时 / 坏响应。
 */

'use strict'
const { describe, it, beforeEach, afterEach, before } = require('node:test')
const assert = require('node:assert/strict')
const path = require('node:path')

const BUNDLE_LIB = path.join(__dirname, '..', 'lib')
const apiUrl = require('node:url').pathToFileURL(path.join(BUNDLE_LIB, 'client', 'api.js')).href

let callRpc, fetchSnapshot
let realFetch

before(async () => {
  const mod = await import(apiUrl)
  callRpc = mod.callRpc
  fetchSnapshot = mod.fetchSnapshot
})

beforeEach(() => {
  realFetch = global.fetch
})

afterEach(() => {
  global.fetch = realFetch
})

// 构造 fetch mock：返回预设 Response 形状
function mockFetch(fn) {
  global.fetch = async (url, init) => fn(url, init)
}

function jsonResponse(body, status = 200) {
  return {
    status,
    json: async () => body,
  }
}

describe('callRpc — 传输层（api.ts）', () => {
  it('成功：ok:true → 返回 data', async () => {
    mockFetch(async (url, init) => {
      assert.equal(url, '/brvis/api/snapshot')
      assert.equal(init.method, 'POST')
      const hdrs = init.headers
      assert.equal(hdrs['x-brvis-request'], '1')
      assert.match(hdrs['content-type'], /^application\/json/)
      const callBody = JSON.parse(init.body)
      assert.deepStrictEqual(callBody, { path: 'hello' })
      return jsonResponse({ ok: true, data: { nodes: 3 } })
    })
    const data = await callRpc('brvis.snapshot', { path: 'hello' })
    assert.deepStrictEqual(data, { nodes: 3 })
  })

  it('fetchSnapshot 走 snapshot 路由并传 path（缺省 includeArchived=false）', async () => {
    mockFetch(async (url, init) => {
      assert.equal(url, '/brvis/api/snapshot')
      assert.deepStrictEqual(JSON.parse(init.body), { path: 'ws1', includeArchived: false })
      return jsonResponse({ ok: true, data: { ok: true } })
    })
    const data = await fetchSnapshot('ws1')
    assert.deepStrictEqual(data, { ok: true })
  })

  it('fetchSnapshot includeArchived=true 时透传 true', async () => {
    mockFetch(async (_url, init) => {
      assert.deepStrictEqual(JSON.parse(init.body), { path: 'ws1', includeArchived: true })
      return jsonResponse({ ok: true, data: { ok: true } })
    })
    await fetchSnapshot('ws1', { includeArchived: true })
  })

  it('归档快速显示显式透传 preferCached，不污染默认请求', async () => {
    mockFetch(async (_url, init) => {
      assert.deepStrictEqual(JSON.parse(init.body), { path: 'ws1', includeArchived: true, preferCached: true })
      return jsonResponse({ ok: true, data: { hydrating: true } })
    })
    await fetchSnapshot('ws1', { includeArchived: true, preferCached: true })
  })

  it('OPEN-02：显式 timeoutMs 优先于分级默认（旧实现固定 10s 覆盖调用方）', async () => {
    // 旧实现 `{ ...opts, timeoutMs: SNAPSHOT_TIMEOUT_MS }` 无条件覆盖调用方 timeoutMs；
    // 修复后显式 timeoutMs 生效 → 5ms 即超时（不等待 10s 默认）。
    const start = Date.now()
    mockFetch(async (_url, init) => {
      const { signal } = init
      return new Promise((_, reject) => {
        signal.addEventListener('abort', () => {
          const err = new Error('timeout')
          err.name = 'AbortError'
          reject(err)
        })
      })
    })
    await assert.rejects(
      fetchSnapshot('ws1', { includeArchived: true, timeoutMs: 5 }),
      (e) => e.code === 'NETWORK_TIMEOUT' && e.retryable === false,
    )
    assert.ok(Date.now() - start < 800, '5ms 超时应远快于默认 10s（证明显式 timeoutMs 生效）')
  })

  it('业务失败：ok:false + error → throw 带 code/retryable', async () => {
    mockFetch(async () => jsonResponse({ ok: false, error: { code: 'INVALID_TITLE', message: '标题非法', retryable: false } }))
    await assert.rejects(
      callRpc('brvis.rename', { sessionId: 'x', title: ' ' }),
      (e) => e.code === 'INVALID_TITLE' && e.retryable === false && /标题非法/.test(e.message),
    )
  })

  it('网络错误：fetch reject（非 abort）→ NETWORK_ERROR retryable:true', async () => {
    mockFetch(async () => { throw new Error('fetch failed: ECONNREFUSED') })
    await assert.rejects(
      callRpc('brvis.snapshot', {}),
      (e) => e.code === 'NETWORK_ERROR' && e.retryable === true && /网络请求失败/.test(e.message),
    )
  })

  it('中止（AbortError）→ NETWORK_TIMEOUT retryable:false', async () => {
    mockFetch(async (_url, init) => {
      // 模拟 fetch 对 signal 的响应：以 AbortError reject
      const { signal } = init
      return new Promise((_, reject) => {
        signal.addEventListener('abort', () => {
          const err = new Error('aborted')
          err.name = 'AbortError'
          reject(err)
        })
      })
    })
    await assert.rejects(
      callRpc('brvis.snapshot', {}, { timeoutMs: 5 }),
      (e) => e.code === 'NETWORK_TIMEOUT' && e.retryable === false,
    )
  })

  it('AUD-05：真实 fetch 语义（以 signal.reason reject）下超时 → NETWORK_TIMEOUT 而非 NETWORK_ERROR', async () => {
    // 真实 fetch 在 abort 时以 signal.reason reject。旧实现 reason = Error('timeout')
    //（name==='Error'）→ 落入 NETWORK_ERROR retryable:true（误报且客户端会重试已超时
    // 请求）；修复后 reason 为 TimeoutError DOMException → 正确归类 NETWORK_TIMEOUT。
    mockFetch(async (_url, init) => {
      const { signal } = init
      return new Promise((_, reject) => {
        signal.addEventListener('abort', () => reject(signal.reason))
      })
    })
    await assert.rejects(
      callRpc('brvis.snapshot', {}, { timeoutMs: 5 }),
      (e) => e.code === 'NETWORK_TIMEOUT' && e.retryable === false && /超时/.test(e.message),
    )
  })

  it('坏响应：非 JSON → BAD_RESPONSE retryable:true', async () => {
    mockFetch(async () => ({
      status: 500,
      json: async () => { throw new Error('not json') },
    }))
    await assert.rejects(
      callRpc('brvis.snapshot', {}),
      (e) => e.code === 'BAD_RESPONSE' && e.retryable === true,
    )
  })

  it('响应既非 ok 也无 error → BAD_RESPONSE', async () => {
    mockFetch(async () => jsonResponse({ unknown: true }))
    await assert.rejects(
      callRpc('brvis.snapshot', {}),
      (e) => e.code === 'BAD_RESPONSE',
    )
  })

  it('外部 signal 提前 abort → NETWORK_TIMEOUT（不额外等待超时）', async () => {
    const ctrl = new AbortController()
    mockFetch(async (_url, init) => {
      const { signal } = init
      return new Promise((_, reject) => {
        signal.addEventListener('abort', () => {
          const err = new Error('aborted by caller')
          err.name = 'AbortError'
          reject(err)
        })
      })
    })
    setTimeout(() => ctrl.abort(new Error('aborted by caller')), 5)
    await assert.rejects(
      callRpc('brvis.snapshot', {}, { signal: ctrl.signal, timeoutMs: 5000 }),
      (e) => e.code === 'NETWORK_TIMEOUT',
    )
  })
})
