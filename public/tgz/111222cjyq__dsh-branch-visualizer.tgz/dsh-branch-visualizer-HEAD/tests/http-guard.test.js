/**
 * http-guard.test.js — HTTP 安全边界与请求体读取（HTTP-01）。
 * 直接测试 src/host/http-guard.ts 编译产物（host 生产模块，TEST-01 同款策略）。
 * 覆盖：CSRF 边界（Sec-Fetch/Origin/自定义 header）、方法/媒体类型强制、body 上限。
 */

'use strict'
const { describe, it, before } = require('node:test')
const assert = require('node:assert/strict')
const path = require('node:path')
const { EventEmitter } = require('node:events')

const BUNDLE_LIB = path.join(__dirname, '..', 'lib')
const httpGuardUrl = require('node:url').pathToFileURL(path.join(BUNDLE_LIB, 'host', 'http-guard.js')).href

let checkHttpGuard, readBody, MAX_BODY_BYTES

before(async () => {
  const mod = await import(httpGuardUrl)
  checkHttpGuard = mod.checkHttpGuard
  readBody = mod.readBody
  MAX_BODY_BYTES = mod.MAX_BODY_BYTES
})

// 构造合法请求基线（除被测字段外全部合法）
function baseReq(overrides) {
  return {
    method: 'POST',
    url: '/brvis/api/snapshot',
    headers: {
      'content-type': 'application/json',
      'x-brvis-request': '1',
      'sec-fetch-site': 'same-origin',
      'origin': 'http://127.0.0.1:3080',
      'host': '127.0.0.1:3080',
    },
    ...(overrides || {}),
  }
}

describe('checkHttpGuard — 安全边界（HTTP-01）', () => {
  it('合法请求通过', () => {
    assert.deepStrictEqual(checkHttpGuard(baseReq()), { ok: true })
  })

  it('Sec-Fetch-Site: cross-site → 403 FORBIDDEN', () => {
    const r = checkHttpGuard(baseReq({ headers: { ...baseReq().headers, 'sec-fetch-site': 'cross-site' } }))
    assert.equal(r.ok, false)
    assert.equal(r.status, 403)
    assert.equal(r.code, 'FORBIDDEN')
  })

  it('数组形式的 Sec-Fetch-Site: cross-site 仍拒绝', () => {
    const r = checkHttpGuard(baseReq({ headers: { ...baseReq().headers, 'sec-fetch-site': ['cross-site'] } }))
    assert.equal(r.ok, false)
    assert.equal(r.status, 403)
  })

  it('Origin 不匹配 → 403', () => {
    const r = checkHttpGuard(baseReq({ headers: { ...baseReq().headers, origin: 'http://evil.example' } }))
    assert.equal(r.ok, false)
    assert.equal(r.status, 403)
  })

  it('Origin 匹配当前 host（含端口变化）→ 通过', () => {
    const r = checkHttpGuard(baseReq({ headers: { ...baseReq().headers, origin: 'http://127.0.0.1:4000', host: '127.0.0.1:4000' } }))
    assert.deepStrictEqual(r, { ok: true })
  })

  it('HTTPS Origin 与当前 host 匹配 → 通过', () => {
    const r = checkHttpGuard(baseReq({ headers: { ...baseReq().headers, origin: 'https://example.local:9443', host: 'example.local:9443' } }))
    assert.deepStrictEqual(r, { ok: true })
  })

  it('Origin 存在但 Host 缺失 → 403', () => {
    const headers = { ...baseReq().headers }
    delete headers.host
    const r = checkHttpGuard(baseReq({ headers }))
    assert.equal(r.ok, false)
    assert.equal(r.status, 403)
  })

  it('无 Origin 时按本机威胁模型放行', () => {
    const headers = { ...baseReq().headers }
    delete headers.origin
    assert.deepStrictEqual(checkHttpGuard(baseReq({ headers })), { ok: true })
  })

  it('非 POST → 405', () => {
    const r = checkHttpGuard(baseReq({ method: 'GET' }))
    assert.equal(r.ok, false)
    assert.equal(r.status, 405)
    assert.equal(r.code, 'METHOD_NOT_ALLOWED')
  })

  it('Content-Type 非 json → 415', () => {
    const r = checkHttpGuard(baseReq({ headers: { ...baseReq().headers, 'content-type': 'text/plain' } }))
    assert.equal(r.ok, false)
    assert.equal(r.status, 415)
    assert.equal(r.code, 'UNSUPPORTED_MEDIA_TYPE')
  })

  it('Content-Type 带 charset 参数仍接受（application/json; charset=utf-8）', () => {
    const r = checkHttpGuard(baseReq({ headers: { ...baseReq().headers, 'content-type': 'application/json; charset=utf-8' } }))
    assert.deepStrictEqual(r, { ok: true })
  })

  it('缺少 X-Brvis-Request → 403', () => {
    const headers = { ...baseReq().headers }
    delete headers['x-brvis-request']
    const r = checkHttpGuard(baseReq({ headers }))
    assert.equal(r.ok, false)
    assert.equal(r.status, 403)
  })

  it('headers 值为数组形式（http 库可能产生）→ 取首个元素', () => {
    const r = checkHttpGuard(baseReq({ headers: { ...baseReq().headers, origin: ['http://127.0.0.1:3080'], 'x-brvis-request': ['1'] } }))
    assert.deepStrictEqual(r, { ok: true })
  })
})

// ---- readBody：仿 http.IncomingMessage 事件流 ----
function fakeStream(chunks) {
  const em = new EventEmitter()
  em.destroyed = false
  em._chunks = chunks || []
  em.destroy = () => { em.destroyed = true }
  // 构造后自动发射（对 readBody 隐藏时序）
  setTimeout(() => {
    if (em.destroyed) return
    for (const c of em._chunks) em.emit('data', Buffer.from(c))
    em.emit('end')
  }, 1)
  return em
}

describe('readBody — 请求体读取（HTTP-01）', () => {
  it('正常读取 UTF-8 body', async () => {
    const stream = fakeStream(['{"a":', '"你好"}'])
    const s = await readBody(stream)
    assert.equal(s, '{"a":"你好"}')
  })

  it('空 body → 空字符串', async () => {
    const stream = fakeStream([])
    const s = await readBody(stream)
    assert.equal(s, '')
  })

  it('超过 64KiB 上限 → reject BODY_TOO_LARGE，且不 destroy socket（AUD-04：413 须可达）', async () => {
    const big = Buffer.alloc(MAX_BODY_BYTES + 1, 'x').toString()
    const stream = fakeStream([big])
    await assert.rejects(
      readBody(stream),
      (e) => e && e.code === 'BODY_TOO_LARGE',
    )
    // AUD-04：旧实现超限即 destroy socket → res 联动销毁 → 路由层 413 永远写不出去。
    // 现在必须保留连接，由 index.ts 发送 413 + connection: close 后再关闭。
    assert.equal(stream.destroyed, false, 'readBody 不得自行 destroy socket（否则 413 不可达）')
  })

  it('error 事件 → reject 原错误', async () => {
    const em = new EventEmitter()
    setTimeout(() => em.emit('error', new Error('socket hang up')), 0)
    await assert.rejects(readBody(em), /socket hang up/)
  })

  it('aborted → reject ABORTED', async () => {
    const em = new EventEmitter()
    setTimeout(() => em.emit('aborted'), 0)
    await assert.rejects(readBody(em), (e) => e && e.code === 'ABORTED')
  })

  it('自定义 maxBytes 生效（小于默认上限）', async () => {
    const stream = fakeStream(['abcde'])
    await assert.rejects(
      readBody(stream, 4),
      (e) => e && e.code === 'BODY_TOO_LARGE',
    )
  })
})
// ═══════════════════════════════════════════════════════════════════════════
// AUD-04（2026-08-18）— 路由接线级回归：超限 body 的 413 响应真实可达
// 旧实现 readBody 超限即 req.destroy() → Node 语义下 res 联动销毁 →
// index.ts send() 的 destroyed 守卫直接放弃 → 客户端只见 ECONNRESET，
// 且按 NETWORK_ERROR retryable 重试形成循环。本测试在 handler 层锁定：
// 413 状态码 + PAYLOAD_TOO_LARGE + connection: close + finish 后销毁 socket。
// ═══════════════════════════════════════════════════════════════════════════
describe('AUD-04 — 超限 body 的 413 响应真实可达（路由接线）', () => {
  it('超过 64KiB → 客户端收到 413 PAYLOAD_TOO_LARGE（而非连接重置）', async () => {
    const indexUrl = require('node:url').pathToFileURL(path.join(BUNDLE_LIB, 'index.js')).href
    const hostMod = await import(indexUrl)
    let handler = null
    const ctx = {
      get: () => undefined,
      on: () => () => {},
      webServer: { register: (opts) => { handler = opts.handler; return () => {} } },
      effect: () => {},
    }
    hostMod.apply(ctx)
    assert.equal(typeof handler, 'function', 'webServer.register 必须捕获到 handler')

    // 仿 Node http 语义的 req/res：destroy(req) 联动销毁 res（真实共享同一 socket）
    const req = new EventEmitter()
    req.method = 'POST'
    req.url = '/brvis/api/snapshot'
    req.headers = {
      'content-type': 'application/json',
      'x-brvis-request': '1',
      'host': '127.0.0.1:3080',
    }
    req.aborted = false
    req.readableAborted = false
    const res = new EventEmitter()
    res.destroyed = false
    res.writableEnded = false
    let status = 0
    let respHeaders = null
    let respBody = ''
    res.writeHead = (code, hdrs) => { status = code; respHeaders = hdrs }
    res.end = (chunk) => {
      respBody = chunk
      res.writableEnded = true
      setImmediate(() => res.emit('finish')) // 真实 finish 为异步
    }
    req.destroy = () => { res.destroyed = true } // Node：同一 socket 联动销毁

    const pending = handler(req, res)
    req.emit('data', Buffer.alloc(MAX_BODY_BYTES + 1, 'x'))
    await pending

    assert.equal(status, 413, '超限必须收到 413（旧实现响应被吞，status 停留在 0）')
    assert.equal(respHeaders['connection'], 'close')
    const parsed = JSON.parse(respBody)
    assert.equal(parsed.ok, false)
    assert.equal(parsed.error.code, 'PAYLOAD_TOO_LARGE')
    assert.equal(parsed.error.retryable, false, '413 不可重试（切断客户端重试循环）')
    // finish 后 socket 销毁兜底（连接不回 keep-alive 池）
    await new Promise((r) => setImmediate(r))
    assert.equal(res.destroyed, true, '响应刷出后应销毁 socket')
  })
})
