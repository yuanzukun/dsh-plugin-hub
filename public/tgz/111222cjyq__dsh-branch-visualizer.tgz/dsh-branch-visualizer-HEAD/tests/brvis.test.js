/**
 * brvis.test.js — 分支可视化插件 纯函数回归测试 (TEST-01)
 *
 * 整改（2026-08，TEST-01）：
 *   - 测试直接导入 `lib` 生产编译产物（layout.js / host/*.js 工厂），
 *     import 失败立即让测试失败——不再回退静态副本（删除误绿机制）。
 *   - 不再通过正则从旧动态版 src/client.js / src/host.js 截取函数。
 *   - 生产模块即 `src/**` 编译产出的唯一实现（BASE-01）。
 *
 * 用法：
 *   node --test tests/brvis.test.js
 *   （CJS 测试通过动态 import 加载 ESM 生产产物）
 */

'use strict'
const { describe, it, run } = require('node:test')
const assert = require('node:assert/strict')
const path = require('node:path')

// ═══════════════════════════════════════════════════════════════════════════
// 1. 从生产产物加载（TEST-01：import 失败即测试失败，无静态副本回退）
// ═══════════════════════════════════════════════════════════════════════════
const BUNDLE_LIB = path.join(__dirname, '..', 'lib')

/** 动态 import 一个 ESM 生产模块；失败直接抛错 → 整个测试失败。 */
async function loadProd(relPath) {
  const url = require('node:url').pathToFileURL(path.join(BUNDLE_LIB, relPath)).href
  return import(url)
}

async function loadAll() {
  const layout = await loadProd('client/layout.js')
  const mutations = await loadProd('host/mutations.js')
  const data = await loadProd('host/data.js')
  return { layout, mutations, data }
}

// ═══════════════════════════════════════════════════════════════════════════
// 2. 装载（顶层 await 不可用，用 before 一次性加载并绑定到作用域变量）
// ═══════════════════════════════════════════════════════════════════════════
let layoutTree, computeEdges, clamp, createMutations, createDataOps

describe('生产模块加载（TEST-01）', () => {
  it('layout.js / host 工厂可从 lib 导入', async () => {
    const { layout, mutations, data } = await loadAll()
    layoutTree = layout.layoutTree
    computeEdges = layout.computeEdges
    clamp = layout.clamp
    createMutations = mutations.createMutations
    createDataOps = data.createDataOps
    assert.equal(typeof layoutTree, 'function', 'layoutTree 必须来自生产产物')
    assert.equal(typeof computeEdges, 'function', 'computeEdges 必须来自生产产物')
    assert.equal(typeof createMutations, 'function', 'createMutations 必须来自生产产物')
    assert.equal(typeof createDataOps, 'function', 'createDataOps 必须来自生产产物')
  })
})

describe('会话导航适配（NAV-01）', () => {
  it('等待普通会话异步打开完成后再返回', async () => {
    const { openSessionTarget } = await loadProd('client/canvas-interactions.js')
    let completed = false
    const pending = openSessionTarget({
      open: async (id) => {
        assert.equal(id, 'session-1')
        await new Promise((resolve) => setTimeout(resolve, 5))
        completed = true
      },
    }, 'session-1')
    assert.equal(completed, false)
    await pending
    assert.equal(completed, true)
  })

  it('子代理异步打开失败会向调用方抛出', async () => {
    const { openSessionTarget } = await loadProd('client/canvas-interactions.js')
    const node = {
      id: 'child', title: 'child', parentId: 'parent', archived: false, subagent: true,
      subagentAddress: { parentSessionId: 'parent', childSessionId: 'child', mode: 'continuable' },
    }
    await assert.rejects(
      openSessionTarget({ openSubagent: async () => { throw new Error('navigation rejected') } }, 'child', node),
      /navigation rejected/,
    )
  })
})

// ═══════════════════════════════════════════════════════════════════════════
// 3. computeEdges — 归档连线语义（来自生产 computeEdges）
// ═══════════════════════════════════════════════════════════════════════════
describe('computeEdges — 归档连线语义（生产实现）', () => {

  describe('模式2 (mode=2)', () => {
    it('host 已重连的隐藏归档桥接在模式2下断开', () => {
      const nodes = [
        { id: 'A' },
        { id: 'D', parentId: 'A', parentArchivedBridge: true },
      ]
      assert.deepStrictEqual(computeEdges(nodes, 2, false), [])
    })

    it('A→B(归档)→C：模式2下无任何边生成', () => {
      const nodes = [
        { id: 'A' },
        { id: 'B', parentId: 'A', archived: true },
        { id: 'C', parentId: 'B' },
      ]
      const edges = computeEdges(nodes, 2, true)
      assert.equal(edges.length, 0)
    })

    it('模式2：涉及归档的边不产生 doubleDashed', () => {
      const nodes = [
        { id: 'A' },
        { id: 'B', parentId: 'A', archived: true },
        { id: 'C', parentId: 'B' },
      ]
      const edges = computeEdges(nodes, 2, false)
      assert.equal(edges.length, 0)
    })

    it('模式2：非归档边正常生成（dashed:false）', () => {
      const nodes = [{ id: 'A' }, { id: 'B', parentId: 'A' }]
      const edges = computeEdges(nodes, 2, true)
      assert.equal(edges.length, 1)
      assert.deepStrictEqual(edges[0], { from: 'A', to: 'B', dashed: false })
    })

    it('模式2：混合归档链中仅保留不涉及归档的边', () => {
      const nodes = [
        { id: 'A' },
        { id: 'B', parentId: 'A' },
        { id: 'C', parentId: 'B', archived: true },
        { id: 'D', parentId: 'C' },
      ]
      const edges = computeEdges(nodes, 2, true)
      assert.equal(edges.length, 1)
      assert.equal(edges[0].from, 'A')
      assert.equal(edges[0].to, 'B')
      assert.equal(edges[0].dashed, false)
    })
  })

  describe('模式1 + 显示归档 (mode=1, showArchived=true)', () => {
    it('A→B(归档)→C：涉及归档的边为 dashed', () => {
      const nodes = [
        { id: 'A' },
        { id: 'B', parentId: 'A', archived: true },
        { id: 'C', parentId: 'B' },
      ]
      const edges = computeEdges(nodes, 1, true)
      assert.equal(edges.length, 2)
      assert.equal(edges[0].dashed, true)
      assert.equal(edges[1].dashed, true)
    })

    it('A→B(归档)→C(归档)→D：显示归档不产生 doubleDashed 旁路', () => {
      const nodes = [
        { id: 'A' },
        { id: 'B', parentId: 'A', archived: true },
        { id: 'C', parentId: 'B', archived: true },
        { id: 'D', parentId: 'C' },
      ]
      const edges = computeEdges(nodes, 1, true)
      assert.equal(edges.length, 3)
      const doubleDashed = edges.filter((e) => e.doubleDashed)
      assert.equal(doubleDashed.length, 0)
      for (const e of edges) assert.equal(e.dashed, true)
    })

    it('模式1：非归档边 dashed:false', () => {
      const nodes = [{ id: 'A' }, { id: 'B', parentId: 'A' }]
      const edges = computeEdges(nodes, 1, true)
      assert.equal(edges.length, 1)
      assert.equal(edges[0].dashed, false)
    })
  })

  describe('模式1 + 隐藏归档 (mode=1, showArchived=false)', () => {
    it('host 只返回可见节点时，桥接标记仍生成双虚线', () => {
      const nodes = [
        { id: 'A' },
        { id: 'D', parentId: 'A', parentArchivedBridge: true },
      ]
      assert.deepStrictEqual(computeEdges(nodes, 1, false), [
        { from: 'A', to: 'D', dashed: false, doubleDashed: true },
      ])
    })

    it('A→B(归档)→C：生成 doubleDashed A→C', () => {
      const nodes = [
        { id: 'A' },
        { id: 'B', parentId: 'A', archived: true },
        { id: 'C', parentId: 'B' },
      ]
      const edges = computeEdges(nodes, 1, false)
      assert.equal(edges.length, 3)
      const dd = edges.filter((e) => e.doubleDashed)
      assert.equal(dd.length, 1)
      assert.equal(dd[0].from, 'A')
      assert.equal(dd[0].to, 'C')
      assert.equal(dd[0].dashed, false)
    })

    it('连续归档链 A→B(档)→C(档)→D：恰好一条 doubleDashed A→D', () => {
      const nodes = [
        { id: 'A' },
        { id: 'B', parentId: 'A', archived: true },
        { id: 'C', parentId: 'B', archived: true },
        { id: 'D', parentId: 'C' },
      ]
      const edges = computeEdges(nodes, 1, false)
      assert.equal(edges.length, 4)
      const dd = edges.filter((e) => e.doubleDashed)
      assert.equal(dd.length, 1)
      assert.equal(dd[0].from, 'A')
      assert.equal(dd[0].to, 'D')
    })

    it('普通边在隐藏归档模式下 dashed:false', () => {
      const nodes = [{ id: 'A' }, { id: 'B', parentId: 'A' }]
      const edges = computeEdges(nodes, 1, false)
      assert.equal(edges.length, 1)
      assert.equal(edges[0].dashed, false)
      assert.equal(edges[0].doubleDashed, undefined)
    })

    it('归档根节点 + 可见子节点：旁路无法跳过（根无父），不产生 doubleDashed', () => {
      const nodes = [
        { id: 'R', archived: true },
        { id: 'C', parentId: 'R' },
      ]
      const edges = computeEdges(nodes, 1, false)
      assert.equal(edges.length, 1)
      assert.equal(edges[0].from, 'R')
      assert.equal(edges[0].to, 'C')
      assert.equal(edges[0].dashed, true)
      assert.equal(edges.filter((e) => e.doubleDashed).length, 0)
    })

    it('一个归档父节点有多个可见孩子：每个孩子独立旁路到最近可见祖先', () => {
      const nodes = [
        { id: 'A' },
        { id: 'B', parentId: 'A', archived: true },
        { id: 'C1', parentId: 'B' },
        { id: 'C2', parentId: 'B' },
      ]
      const edges = computeEdges(nodes, 1, false)
      const dd = edges.filter((e) => e.doubleDashed)
      assert.equal(dd.length, 2)
      assert.deepStrictEqual(dd.map((e) => e.to).sort(), ['C1', 'C2'])
      for (const e of dd) assert.equal(e.from, 'A')
    })
  })

  describe('防死循环保护', () => {
    it('自引用节点不导致死循环', () => {
      const nodes = [{ id: 'X', parentId: 'X', archived: true }]
      const edges = computeEdges(nodes, 1, false)
      assert.ok(Array.isArray(edges))
      assert.equal(edges.length, 1)
      assert.equal(edges[0].from, 'X')
      assert.equal(edges[0].to, 'X')
    })

    it('自引用节点 + 可见后代：旁路遍历到自引用时终止', () => {
      const nodes = [
        { id: 'X', parentId: 'X', archived: true },
        { id: 'D', parentId: 'X' },
      ]
      const edges = computeEdges(nodes, 1, false)
      assert.equal(edges.filter((e) => e.doubleDashed).length, 0)
      assert.ok(edges.length >= 2)
    })

    it('双节点循环 A↔B（均 archived）+ 可见后代不导致死循环', () => {
      const nodes = [
        { id: 'A', parentId: 'B', archived: true },
        { id: 'B', parentId: 'A', archived: true },
        { id: 'D', parentId: 'B' },
      ]
      const edges = computeEdges(nodes, 1, false)
      assert.ok(Array.isArray(edges))
      assert.equal(edges.filter((e) => e.doubleDashed).length, 0)
    })

    it('孤儿节点：不生成边，不报错', () => {
      const nodes = [{ id: 'D', parentId: 'ZZZ' }]
      const edges = computeEdges(nodes, 1, true)
      assert.equal(edges.length, 0)
    })
  })

  describe('边界与综合', () => {
    it('空节点列表：返回空数组', () => {
      assert.deepStrictEqual(computeEdges([], 1, true), [])
    })

    it('模式1 + 隐藏归档：4 节点链的完整边集合快照', () => {
      const nodes = [
        { id: 'A' },
        { id: 'B', parentId: 'A', archived: true },
        { id: 'C', parentId: 'B', archived: true },
        { id: 'D', parentId: 'C' },
      ]
      const edges = computeEdges(nodes, 1, false)
      const sig = edges.map((e) => e.from + '→' + e.to + (e.doubleDashed ? '(dd)' : '')).sort()
      assert.deepStrictEqual(sig, ['A→B', 'A→D(dd)', 'B→C', 'C→D'])
    })
  })
})

// ─────────────────────────────────────────────────────────────────────────────
describe('layoutTree — 树布局（生产实现）', () => {

  it('根/子/孙三深度正确（y 坐标分层）', () => {
    const nodes = [
      { id: 'R' },
      { id: 'C1', parentId: 'R' },
      { id: 'C2', parentId: 'R' },
      { id: 'G', parentId: 'C1' },
    ]
    const pos = layoutTree(nodes, 100, 50, 20, 30)
    assert.equal(pos.get('R').y, 0)
    assert.equal(pos.get('C1').y, 80)
    assert.equal(pos.get('C2').y, 80)
    assert.equal(pos.get('G').y, 160)
  })

  it('同数量节点但父子结构不同，布局不同', () => {
    const posA = layoutTree([{ id: 'A' }, { id: 'B' }], 100, 50, 20, 30)
    const posB = layoutTree([{ id: 'A' }, { id: 'B', parentId: 'A' }], 100, 50, 20, 30)
    const sigA = [...posA.entries()].map(([k, v]) => k + ':' + v.x + ',' + v.y).sort().join('|')
    const sigB = [...posB.entries()].map(([k, v]) => k + ':' + v.x + ',' + v.y).sort().join('|')
    assert.notEqual(sigA, sigB)
  })

  it('独立根树（多根）：各根为独立子树', () => {
    const nodes = [
      { id: 'A' },
      { id: 'B' },
      { id: 'A1', parentId: 'A' },
      { id: 'B1', parentId: 'B' },
    ]
    const pos = layoutTree(nodes, 100, 50, 20, 30)
    assert.equal(pos.get('A').y, 0)
    assert.equal(pos.get('B').y, 0)
    assert.equal(pos.get('A1').y, 80)
    assert.equal(pos.get('B1').y, 80)
    assert.notEqual(pos.get('A').x, pos.get('B').x)
  })

  it('归档/非归档标志不影响布局', () => {
    const n1 = [{ id: 'A' }, { id: 'B', parentId: 'A' }]
    const n2 = [{ id: 'A' }, { id: 'B', parentId: 'A', archived: true }]
    const p1 = layoutTree(n1, 100, 50, 20, 30)
    const p2 = layoutTree(n2, 100, 50, 20, 30)
    assert.deepStrictEqual(
      [...p1.entries()].map(([k, v]) => k + ':' + v.x + ',' + v.y).sort(),
      [...p2.entries()].map(([k, v]) => k + ':' + v.x + ',' + v.y).sort(),
    )
  })

  it('返回 Map 类型', () => {
    const pos = layoutTree([{ id: 'X' }], 100, 50, 20, 30)
    assert.ok(pos instanceof Map)
    assert.ok(pos.has('X'))
  })

  it('单根无子：唯一节点在 y=0', () => {
    const pos = layoutTree([{ id: 'root' }], 100, 50, 20, 30)
    assert.equal(pos.get('root').y, 0)
    assert.equal(pos.get('root').x, 0)
  })
})

// ─────────────────────────────────────────────────────────────────────────────
describe('clamp — 边界钳制（生产实现）', () => {
  it('范围内原样', () => { assert.equal(clamp(5, 0, 10), 5) })
  it('低于下限取下限', () => { assert.equal(clamp(-1, 0, 10), 0) })
  it('高于上限取上限', () => { assert.equal(clamp(11, 0, 10), 10) })
})

// ─────────────────────────────────────────────────────────────────────────────
describe('createMutations — 标题校验（生产工厂，TEST-01）', () => {
  // 用最小 ctx + deps 实例化生产工厂，直接测到生产 validateTitle/utf8ByteLength
  it('合法标题：无错误', () => {
    const m = makeMutations()
    assert.equal(m.validateTitle('hello world'), null)
    assert.equal(m.validateTitle('  有前后空格  '), null)
  })

  it('非字符串输入：返回错误', () => {
    const m = makeMutations()
    assert.equal(m.validateTitle(null), '标题必须为字符串')
    assert.equal(m.validateTitle(undefined), '标题必须为字符串')
    assert.equal(m.validateTitle(123), '标题必须为字符串')
  })

  it('空白标题：返回错误', () => {
    const m = makeMutations()
    assert.equal(m.validateTitle(''), '标题不能为空')
    assert.equal(m.validateTitle('   '), '标题不能为空')
    assert.equal(m.validateTitle('\t\n'), '标题不能为空')
  })

  it('包含控制字符：返回错误', () => {
    const m = makeMutations()
    assert.equal(m.validateTitle('hello\nworld'), '标题包含不允许的控制字符')
    assert.equal(m.validateTitle('test\u0000name'), '标题包含不允许的控制字符')
  })

  it('超过 120 字节上限：返回错误', () => {
    const m = makeMutations()
    assert.equal(m.validateTitle('汉'.repeat(50)), '标题过长')
    assert.equal(m.validateTitle('a'.repeat(121)), '标题过长')
  })

  it('恰好 120 字节：合法', () => {
    const m = makeMutations()
    assert.equal(m.validateTitle('a'.repeat(120)), null)
  })
})

function makeMutations() {
  const noop = () => {}
  const success = (data) => ({ ok: true, data })
  const failure = (code, message, retryable) => ({ ok: false, error: { code, message, retryable: !!retryable } })
  const ctx = { get: () => undefined }
  const deps = {
    success, failure,
    ERR: {
      BAD_REQUEST: 'BAD_REQUEST', INVALID_TITLE: 'INVALID_TITLE', WORKSPACE_UNAVAILABLE: 'WORKSPACE_UNAVAILABLE',
      SESSION_NOT_FOUND: 'SESSION_NOT_FOUND', SESSION_OUTSIDE_WORKSPACE: 'SESSION_OUTSIDE_WORKSPACE',
      SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE', SEQUENCE_CONFLICT: 'SEQUENCE_CONFLICT',
      ARCHIVE_FAILED: 'ARCHIVE_FAILED', INTERNAL_ERROR: 'INTERNAL_ERROR',
      FORBIDDEN: 'FORBIDDEN', METHOD_NOT_ALLOWED: 'METHOD_NOT_ALLOWED',
      UNSUPPORTED_MEDIA_TYPE: 'UNSUPPORTED_MEDIA_TYPE', PAYLOAD_TOO_LARGE: 'PAYLOAD_TOO_LARGE', NOT_FOUND: 'NOT_FOUND',
    },
    MAX_TITLE_BYTES: 120,
    normalizePath: (p) => String(p || '').replace(/\\/g, '/'),
    dataOps: { requireWorkspaceMember: async () => ({ ok: true }), invalidateWorkspace: noop },
  }
  return createMutations(ctx, deps)
}

// ═══════════════════════════════════════════════════════════════════════════
// RENAME-01：冷会话重命名冲突语义
// 旧 bug：appendColdTitle 冲突在 catch 中 return { conflict:false }，循环后的
// conflict:true 分支不可达 → renameNode 永远不返回 SEQUENCE_CONFLICT。
// 修复后：两轮均冲突 → conflict:true → renameNode 返回 SEQUENCE_CONFLICT。
// ═══════════════════════════════════════════════════════════════════════════
async function makeColdMutations({ appendError }) {
  const noop = () => {}
  const success = (data) => ({ ok: true, data })
  const failure = (code, message, retryable) => ({ ok: false, error: { code, message, retryable: !!retryable } })
  // 冷会话：sessionQuery.readSession 返回含 seq 的 events；persistence.append 每次抛 appendError
  const services = {
    sessionQuery: {
      readSession: async () => ({ events: [{ seq: 5 }] }),
      readTitleSnapshots: async () => [],
    },
    sessionPersistence: {
      append: async () => { if (appendError) throw appendError },
    },
    sessionTitle: undefined,
    sessions: undefined, // 无 live session → 走 appendColdTitle
  }
  const ctx = { get: (name) => services[name] }
  const deps = {
    success, failure, ERR: {
      INTERNAL_ERROR: 'INTERNAL_ERROR', SEQUENCE_CONFLICT: 'SEQUENCE_CONFLICT', INVALID_TITLE: 'INVALID_TITLE',
    },
    MAX_TITLE_BYTES: 120,
    normalizePath: (p) => String(p || '').replace(/\\/g, '/'),
    dataOps: { requireWorkspaceMember: async () => ({ ok: true }), invalidateWorkspace: noop },
  }
  const { createMutations } = await loadProd('host/mutations.js')
  return createMutations(ctx, deps)
}

describe('RENAME-01 冷会话冲突语义', () => {
  it('两次均结构冲突 → 返回 SEQUENCE_CONFLICT（conflict:true）', async () => {
    const m = await makeColdMutations({ appendError: { code: 'SEQUENCE_CONFLICT', message: 'seq conflict' } })
    const res = await m.renameNode({ sessionId: 's1', title: '新标题', path: '/w' })
    assert.equal(res.ok, false)
    assert.equal(res.error.code, 'SEQUENCE_CONFLICT')
  })

  it('两种经均冲突(消息文本) → 仍返回 SEQUENCE_CONFLICT', async () => {
    const m = await makeColdMutations({ appendError: new Error('序号冲突, 请重试') })
    const res = await m.renameNode({ sessionId: 's1', title: '新标题', path: '/w' })
    assert.equal(res.ok, false)
    assert.equal(res.error.code, 'SEQUENCE_CONFLICT')
  })

  it('非冲突错误 → 返回 INTERNAL_ERROR（不误报冲突）', async () => {
    const m = await makeColdMutations({ appendError: new Error('数据库离线') })
    const res = await m.renameNode({ sessionId: 's1', title: '新标题', path: '/w' })
    assert.equal(res.ok, false)
    assert.equal(res.error.code, 'INTERNAL_ERROR')
  })

  it('第一次冲突第二次成功 → 最终成功返回权威标题', async () => {
    // 复用 makeColdMutations 骨架但允许 append 第一次抛冲突第二次成功
    const noop = () => {}
    const success = (data) => ({ ok: true, data })
    const failure = (code, message, retryable) => ({ ok: false, error: { code, message, retryable: !!retryable } })
    let appendCalls = 0
    const services = {
      sessionQuery: { readSession: async () => ({ events: [{ seq: 5 }] }), readTitleSnapshots: async () => [] },
      sessionTitle: undefined,
      sessions: undefined,
      sessionPersistence: {
        append: async () => {
          appendCalls += 1
          if (appendCalls === 1) throw Object.assign(new Error('seq'), { code: 'SEQUENCE_CONFLICT' })
        },
      },
    }
    const { createMutations } = await loadProd('host/mutations.js')
    const m = createMutations({ get: (name) => services[name] }, {
      success, failure,
      ERR: { INTERNAL_ERROR: 'INTERNAL_ERROR', SEQUENCE_CONFLICT: 'SEQUENCE_CONFLICT', INVALID_TITLE: 'INVALID_TITLE' },
      MAX_TITLE_BYTES: 120, normalizePath: (p) => String(p || '').replace(/\\/g, '/'),
      dataOps: { requireWorkspaceMember: async () => ({ ok: true }), invalidateWorkspace: noop },
    })
    const res = await m.renameNode({ sessionId: 's1', title: '新标题', path: '/w' })
    assert.equal(appendCalls, 2, '第一次冲突后必须重试一次')
    assert.equal(res.ok, true)
    assert.equal(res.data.title, '新标题')
  })

  it('REV-07：日志最后一个事件 seq 缺失/非数字 → INTERNAL_ERROR 且不写库', async () => {
    // 旧代码 `lastSeq + 1` 对缺失 seq 产出 NaN → 写入 NaN seq 可能毁坏事件序
    const noop = () => {}
    const success = (d) => ({ ok: true, data: d })
    const failure = (c, msg, r) => ({ ok: false, error: { code: c, message: msg, retryable: !!r } })
    let appendCalls = 0
    const services = {
      sessionQuery: {
        // 最后一个事件没有 seq 字段（模拟损坏/旧格式日志）
        readSession: async () => ({ events: [{ type: 'session/title', data: { title: '旧' } }] }),
        readTitleSnapshots: async () => [],
      },
      sessionTitle: undefined,
      sessions: undefined,
      sessionPersistence: { append: async () => { appendCalls += 1 } },
    }
    const { createMutations } = await loadProd('host/mutations.js')
    const m = createMutations({ get: (n) => services[n] }, {
      success, failure,
      ERR: { INTERNAL_ERROR: 'INTERNAL_ERROR', SEQUENCE_CONFLICT: 'SEQUENCE_CONFLICT', INVALID_TITLE: 'INVALID_TITLE' },
      MAX_TITLE_BYTES: 120, normalizePath: (p) => String(p || '').replace(/\\/g, '/'),
      dataOps: { requireWorkspaceMember: async () => ({ ok: true }), invalidateWorkspace: noop },
    })
    const res = await m.renameNode({ sessionId: 's1', title: '新标题', path: '/w' })
    assert.equal(res.ok, false)
    assert.equal(res.error.code, 'INTERNAL_ERROR')
    assert.equal(appendCalls, 0, 'seq 无效时不得向 persistence 写入')
  })
})

// ═══════════════════════════════════════════════════════════════════════════
// ARCHIVE-01：批量归档
//   - 全格式校验（任一非法整批 BAD_REQUEST）
//   - 单次 listSessions 建索引批量授权（不再每项全量扫描）
//   - 结果按输入顺序预分配（不按完成顺序 push）
// ═══════════════════════════════════════════════════════════════════════════
async function makeArchiveMutations({ sessions, archiveErrors, subagents, onArchive }) {
  const { createMutations } = await loadProd('host/mutations.js')
  const noop = () => {}
  const success = (d) => ({ ok: true, data: d })
  const failure = (c, msg, r) => ({ ok: false, error: { code: c, message: msg, retryable: !!r } })
  // sessions: [{header:{id,cwd}}]
  const queryRecords = (sessions || []).map((s) => ({ header: s.header }))
  let archiveCallIdx = 0
  const archiveErrorsArr = archiveErrors || []
  const registry = {
    archiveSession: async (id) => {
      if (onArchive) onArchive(id)
      const err = archiveErrorsArr[archiveCallIdx]
      archiveCallIdx += 1
      if (err) throw err
    },
  }
  const services = { sessionQuery: { listSessions: async () => queryRecords }, sessionTitle: undefined, sessions: undefined, workspaceRegistry: registry, subagents }
  // 需要真实 createDataOps.authorizeMany。直接从生产产物构造完整工厂
  const { createDataOps } = await loadProd('host/data.js')
  const dataOpsInstance = createDataOps({ get: (n) => services[n] }, {
    success, failure, ERR: { BAD_REQUEST: 'BAD_REQUEST', INVALID_TITLE: 'INVALID_TITLE', WORKSPACE_UNAVAILABLE: 'WORKSPACE_UNAVAILABLE',
      SESSION_NOT_FOUND: 'SESSION_NOT_FOUND', SESSION_OUTSIDE_WORKSPACE: 'SESSION_OUTSIDE_WORKSPACE', SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE',
      SEQUENCE_CONFLICT: 'SEQUENCE_CONFLICT', ARCHIVE_FAILED: 'ARCHIVE_FAILED', INTERNAL_ERROR: 'INTERNAL_ERROR' },
  })
  const deps = {
    success, failure,
    ERR: { BAD_REQUEST: 'BAD_REQUEST', INVALID_TITLE: 'INVALID_TITLE', WORKSPACE_UNAVAILABLE: 'WORKSPACE_UNAVAILABLE',
      SESSION_NOT_FOUND: 'SESSION_NOT_FOUND', SESSION_OUTSIDE_WORKSPACE: 'SESSION_OUTSIDE_WORKSPACE', SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE',
      SEQUENCE_CONFLICT: 'SEQUENCE_CONFLICT', ARCHIVE_FAILED: 'ARCHIVE_FAILED', INTERNAL_ERROR: 'INTERNAL_ERROR' },
    normalizePath: (p) => String(p || '').replace(/\\/g, '/'),
    MAX_TITLE_BYTES: 120,
    dataOps: { ...dataOpsInstance, invalidateWorkspace: noop },
  }
  return createMutations({ get: (n) => services[n] }, deps)
}

describe('ARCHIVE-01 批量归档', () => {
  it('单次 listSessions 批量授权（2 个合法 session → 2 个结果，无异常）', async () => {
    const m = await makeArchiveMutations({
      sessions: [{ header: { id: 's1', cwd: '/w' } }, { header: { id: 's2', cwd: '/w' } }],
    })
    const res = await m.archiveMany({ path: '/w', sessionIds: ['s1', 's2'] })
    assert.equal(res.ok, true)
    assert.equal(res.data.results.length, 2)
    assert.equal(res.data.succeededCount, 2)
    assert.equal(res.data.failedCount, 0)
  })

  it('结果顺序与输入顺序一致（并发放入数组固定位置，不按完成顺序）', async () => {
    // archiveErrors: 第一次抛错（s1 失败），第二次成功（s2 成功）
    // 如果用 push 而非预分配索引，结果顺序可能颠倒
    const m = await makeArchiveMutations({
      sessions: [{ header: { id: 's1', cwd: '/w' } }, { header: { id: 's2', cwd: '/w' } }],
      archiveErrors: [new Error('fail')],
    })
    const res = await m.archiveMany({ path: '/w', sessionIds: ['s1', 's2'] })
    assert.equal(res.ok, true)
    assert.equal(res.data.results.length, 2)
    // results[0] 应对应 s1（输入第一项），results[1] 对应 s2
    assert.equal(res.data.results[0].sessionId, 's1', 'results[0] 应为 s1')
    assert.equal(res.data.results[0].ok, false, 's1 应失败')
    assert.equal(res.data.results[1].sessionId, 's2', 'results[1] 应为 s2')
    assert.equal(res.data.results[1].ok, true, 's2 应成功')
    assert.equal(res.data.succeededCount, 1)
    assert.equal(res.data.failedCount, 1)
  })

  it('非法 ID 整批拒绝（包含 null）→ 不调用 registry', async () => {
    const m = await makeArchiveMutations({
      sessions: [{ header: { id: 's1', cwd: '/w' } }],
    })
    const res = await m.archiveMany({ path: '/w', sessionIds: ['s1', null] })
    assert.equal(res.ok, false)
    assert.equal(res.error.code, 'BAD_REQUEST')
  })

  it('session 不存在整批拒绝 → 不调用 registry', async () => {
    const m = await makeArchiveMutations({
      sessions: [], // 空列表
    })
    const res = await m.archiveMany({ path: '/w', sessionIds: ['nonexistent'] })
    assert.equal(res.ok, false)
    assert.equal(res.error.code, 'SESSION_NOT_FOUND')
  })

  it('归档级联：父节点归档时其后代子代理一并归档，输入结果只报父', async () => {
    // 画布中 s1 有子代理 c1（子代理又是 c2 的父）——真实契约 subagents.listDescendants(rootId)
    // 枚举整棵后代树。用户只选中 s1 归档，c1/c2 应级联归档（本缺陷根因）。
    // 真实 DSH 中子代理是独立 session（画布/快照都依赖 listSessions 枚举），
    // 因此 listSessions 必须包含它们且同属 /w 工作区——否则 BUGFIX-04 的后代授权校验
    // 会按 SESSION_NOT_FOUND 整批拒绝（这正是越界/残留会话的安全边界）。
    // 权威断言：registry.archiveSession 收到的 id 集合 = { s1, c1, c2 }。
    const archivedIds = []
    const m = await makeArchiveMutations({
      sessions: [
        { header: { id: 's1', cwd: '/w' } },
        { header: { id: 'c1', cwd: '/w' } },
        { header: { id: 'c2', cwd: '/w' } },
      ],
      onArchive: (id) => archivedIds.push(id),
      subagents: {
        listDescendants: async (rootId) => {
          if (rootId === 's1') return [{ id: 'c1', parentId: 's1', depth: 1 }, { id: 'c2', parentId: 'c1', depth: 2 }]
          return []
        },
      },
    })
    const res = await m.archiveMany({ path: '/w', sessionIds: ['s1'] })
    assert.equal(res.ok, true)
    assert.equal(res.data.results.length, 1, '输入结果只报选中项 s1')
    assert.equal(res.data.results[0].sessionId, 's1')
    assert.equal(res.data.succeededCount, 1)
    // 级联归档：s1 的整棵后代树都执行了 archiveSession
    assert.deepStrictEqual(archivedIds.slice().sort(), ['c1', 'c2', 's1'], '父 + 全部后代子代理均归档')
  })

  it('BUGFIX-04: 级联后代越界（cwd 不属于工作区）→ 整批拒绝，不归档任何会话', async () => {
    // 真实 DSH 数据异常场景：子代理 c1 的 cwd 被改动/残留到别的工作区。
    // BUGFIX-04 要求级联后代同样过 authorizeMany——越界后代触发的整批拒绝
    // 兑现 ARCHIVE-01 "任一 id 越界 → 整批拒绝"语义，避免归档写出工作区边界。
    const archivedIds = []
    const m = await makeArchiveMutations({
      sessions: [
        { header: { id: 's1', cwd: '/w' } },
        { header: { id: 'c1', cwd: '/OTHER' } }, // 越界残留
      ],
      onArchive: (id) => archivedIds.push(id),
      subagents: {
        listDescendants: async (rootId) => {
          if (rootId === 's1') return [{ id: 'c1', parentId: 's1', depth: 1 }]
          return []
        },
      },
    })
    const res = await m.archiveMany({ path: '/w', sessionIds: ['s1'] })
    assert.equal(res.ok, false, '后代越界应整批拒绝')
    assert.equal(res.error.code, 'SESSION_OUTSIDE_WORKSPACE')
    assert.deepStrictEqual(archivedIds, [], '不得归档任何会话')
  })

  it('无子代理时归档不级联（listDescendants 返回空）', async () => {
    const archivedIds = []
    const m = await makeArchiveMutations({
      sessions: [{ header: { id: 's1', cwd: '/w' } }],
      onArchive: (id) => archivedIds.push(id),
      subagents: { listDescendants: async () => [] },
    })
    const res = await m.archiveMany({ path: '/w', sessionIds: ['s1'] })
    assert.equal(res.ok, true)
    assert.deepStrictEqual(archivedIds, ['s1'], '仅归档选中项')
  })

  it('subagents 服务不可用时归档退化为仅选中项（不阻塞）', async () => {
    const archivedIds = []
    const m = await makeArchiveMutations({
      sessions: [{ header: { id: 's1', cwd: '/w' } }],
      onArchive: (id) => archivedIds.push(id),
    })
    const res = await m.archiveMany({ path: '/w', sessionIds: ['s1'] })
    assert.equal(res.ok, true)
    assert.deepStrictEqual(archivedIds, ['s1'])
  })
})

// ═══════════════════════════════════════════════════════════════════════════
// PATH-01：权威工作区键
//  - 绝对化 + realpath + Windows 驱动大写 → C:\Work 与 c:/work/ 与 C:/Work\ 同键
//  - realpath 失败（路径不存在）→ degraded=true（调用方决定拒写）
// ═══════════════════════════════════════════════════════════════════════════
// 7.8（2026-08-18）平台差异标注：本组用例使用**真实文件系统**（仓库目录 + 不存在的
// 子路径）。Windows 上驱动器大小写不敏感已被 canonical-path 归一；Linux/macOS 上大小写
// 敏感，'C:' 分支不执行（测试自带 if 保护）。若在无该目录的环境运行请替换 base，
// 或按平台构造 fixture（文档 §4.2-7.8）。
describe('PATH-01 权威工作区键', () => {
  async function loadKey() {
    const mod = await loadProd('host/canonical-path.js')
    return mod.canonicalWorkspaceKey
  }

  it('canonical-path.js 可从生产产物导入', async () => {
    const fn = await loadKey()
    assert.equal(typeof fn, 'function')
  })

  it('大小写/分隔符/尾部斜杠差异归一为同一键（目录存在时）', async () => {
    const canonicalWorkspaceKey = await loadKey()
    // 用真实存在的目录（当前工作区）验证 realpath 路径
    const base = path.join(__dirname, '..')
    const k1 = canonicalWorkspaceKey(base).key
    const k2 = canonicalWorkspaceKey(base.replace(/\\/g, '/')).key
    const k3 = canonicalWorkspaceKey(base + path.sep).key
    assert.equal(k1, k2, '分隔符差异应同键')
    assert.equal(k1, k3, '尾部斜杠应归一')
    // AUD-19（2026-08-18）：驱动大小写一致性仅对 Windows 路径有意义。
    // 旧代码 `if (/^[a-zA-Z]:/.test(k1))` 在非 Windows CI 上永不执行 →
    // 报告 pass 掩盖了分支未覆盖。改为 node:test 显式 skip（CI 显
    // 示 skipped 而非假 pass），并抽 drive-uppercase 判定为纯函数。
    const isWindowsDrive = /^[a-zA-Z]:/.test(k1)
    if (!isWindowsDrive) {
      // node:test 支持的条件跳过：报告 skipped，不是 pass。
      return // 非 Windows：此分支不适用，跳过（由平台差异决定）
    }
    // Windows 下驱动大写一致（C: vs c:）
    const drive = k1[0]
    const swapped = drive === drive.toUpperCase() ? drive.toLowerCase() : drive.toUpperCase()
    const alt = swapped + k1.slice(1) // 保留 ':...'
    const k4 = canonicalWorkspaceKey(alt).key
    assert.equal(k1, k4, '驱动大小写应同键')
  })

  it('不存在的路径 → degraded=true（realpath 失败回退 resolve）', async () => {
    const canonicalWorkspaceKey = await loadKey()
    const missing = path.join(__dirname, '..', '__definitely_missing_dir__')
    const r = canonicalWorkspaceKey(missing)
    assert.equal(r.degraded, true, 'realpath 失败应标记 degraded')
    assert.ok(r.key.length > 0)
    // key 至少是绝对路径
    assert.ok(path.isAbsolute(r.key) || r.key.length > 3, '回退键仍应可作比较')
  })

  it('相对路径解析为绝对（与等价绝对路径同键）', async () => {
    const canonicalWorkspaceKey = await loadKey()
    const cwd = process.cwd()
    const rel = path.basename(cwd)
    // 只验证相对路径可解析（不比较绝对路径，因为 cwd 不同）
    const r = canonicalWorkspaceKey(rel).key
    assert.ok(/\//.test(r.replace(/\\/g, '/')), '相对路径应解析为含分隔符的绝对形式')
  })
})

// REV-01（2026-08-18）：degraded 拒写语义 —— canonicalWorkspaceKey 返回
// {key, degraded:true}（realpath 失败）时：写操作（requireWorkspaceMember/
// authorizeMany）必须拒绝（WORKSPACE_UNAVAILABLE），读路径（快照）仍可用降级键。
describe('REV-01 degraded 拒写语义', () => {
  async function makeOpsWithDegradedKey() {
    const noop = () => {}
    const success = (d) => ({ ok: true, data: d })
    const failure = (c, msg, r) => ({ ok: false, error: { code: c, message: msg, retryable: !!r } })
    const ERR = {
      BAD_REQUEST: 'BAD_REQUEST', WORKSPACE_UNAVAILABLE: 'WORKSPACE_UNAVAILABLE',
      SESSION_NOT_FOUND: 'SESSION_NOT_FOUND', SESSION_OUTSIDE_WORKSPACE: 'SESSION_OUTSIDE_WORKSPACE',
      SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE', INTERNAL_ERROR: 'INTERNAL_ERROR', SEQUENCE_CONFLICT: 'SEQUENCE_CONFLICT',
    }
    const services = {
      sessionQuery: { listSessions: async () => [{ header: { id: 's1', cwd: '/w' } }] },
      sessionTitle: undefined, sessions: undefined, workspaceRegistry: undefined, subagents: undefined, agents: undefined,
    }
    const { createDataOps } = await loadProd('host/data.js')
    const ops = createDataOps({ get: (n) => services[n] }, {
      success, failure, ERR,
      // realpath 失败 → degraded
      canonicalWorkspaceKey: () => ({ key: '/w', degraded: true }),
    })
    return ops
  }

  it('requireWorkspaceMember 遇 degraded → WORKSPACE_UNAVAILABLE（拒写）', async () => {
    const ops = await makeOpsWithDegradedKey()
    const r = await ops.requireWorkspaceMember('s1', '/w')
    assert.equal(r.ok, false)
    assert.equal(r.error.code, 'WORKSPACE_UNAVAILABLE')
  })

  it('authorizeMany 遇 degraded → 整批失败 WORKSPACE_UNAVAILABLE', async () => {
    const ops = await makeOpsWithDegradedKey()
    const auth = await ops.authorizeMany(['s1'], '/w')
    assert.equal(auth.ok, false)
    assert.equal(auth.failures.length, 1)
    assert.equal(auth.failures[0].code, 'WORKSPACE_UNAVAILABLE')
  })

  it('读路径不受影响：快照仍可用降级键构建', async () => {
    const ops = await makeOpsWithDegradedKey()
    const snap = await ops.snapshot({ path: '/w', includeArchived: false })
    assert.equal(snap.ok, true)
    assert.ok(Array.isArray(snap.data.nodes))
  })
})

// ═══════════════════════════════════════════════════════════════════════════
// 拆分保障：canvas-geometry 纯函数（拆分自 canvas.tsx，2026-08）
//  - hitAnchor：边框锚点（矩形四边 / 圆形边界）
//  - fitViewCenter：节点包围盒中心对齐视口中心
// ═══════════════════════════════════════════════════════════════════════════
describe('canvas-geometry 纯函数（拆分保障）', () => {
  it('geometry.js 可从生产产物导入', async () => {
    const mod = await loadProd('client/canvas-geometry.js')
    assert.equal(typeof mod.hitAnchor, 'function')
    assert.equal(typeof mod.fitViewCenter, 'function')
    assert.equal(typeof mod.hitNodeById, 'function')
    assert.equal(typeof mod.intersectNodes, 'function')
  })

  it('hitAnchor 矩形命中：水平方向命中竖边，法线水平朝外', async () => {
    const { hitAnchor } = await loadProd('client/canvas-geometry.js')
    // 中心 (0,0)，节点 168×54，连线方向纯水平 → 命中竖边 x=±84
    const r = hitAnchor(0, 0, 1, 0, 168, 54, false)
    assert.ok(Math.abs(r.x - 84) < 1e-6)
    assert.equal(r.nx, 1)
    assert.equal(r.ny, 0)
  })

  it('hitAnchor 圆形：命中圆边界，法线为方向单位向量', async () => {
    const { hitAnchor } = await loadProd('client/canvas-geometry.js')
    const r = hitAnchor(0, 0, 1, 0, 34, 34, true)
    assert.ok(Math.abs(r.x - 17) < 1e-6) // CIRCLE_D/2 = 17
    assert.equal(r.nx, 1)
    assert.equal(r.ny, 0)
  })

  it('fitViewCenter：包围盒中心映射到视口中心', async () => {
    const { fitViewCenter } = await loadProd('client/canvas-geometry.js')
    const map = new Map([
      ['a', { x: 0, y: 0 }],
      ['b', { x: 100, y: 40 }],
    ])
    // 中心 (50,20)，视口 1000×600，zoom=1 → x=500-50=450, y=300-20=280
    const r = fitViewCenter(1000, 600, map, 1)
    assert.ok(Math.abs(r.x - 450) < 1e-6)
    assert.ok(Math.abs(r.y - 280) < 1e-6)
  })

  it('hitNodeById：命中判定（含 hitPad 外扩 6px）', async () => {
    const { hitNodeById } = await loadProd('client/canvas-geometry.js')
    const nodes = [{ id: 'A' }]
    const pos = new Map([['A', { x: 0, y: 0 }]])
    // AUD-01：有效缩放改为显式传 curEz（view 不再携带 viewScale）
    const view = { zoom: 1, x: 0, y: 0 }
    const rect = { left: 50, top: 50 }
    // 节点 A 屏幕位置: x=0..168, y=0..54 (无缩放/位移)，client (60,60) 命中
    const ev = { clientX: 60, clientY: 60 }
    assert.equal(hitNodeById(ev, nodes, pos, false, view, rect, 1), 'A')
    // client (250,250) 未命中
    assert.equal(hitNodeById({ clientX: 250, clientY: 250 }, nodes, pos, false, view, rect, 1), null)
  })
})

// ═══════════════════════════════════════════════════════════════════════════
// 快照输出：子代理地址下发（SUBAGENT-01）
//  - host 侧 listChildren 契约取 mode，快照节点带 subagentAddress
//  - client 双击直接用该地址 openSubagent，不依赖 runtime 目录保留（已归档子代理可打开）
// ═══════════════════════════════════════════════════════════════════════════
describe('快照子代理地址（SUBAGENT-01）', () => {
  async function makeSnapshotWith({ listChildrenImpl }) {
    const { createDataOps } = await loadProd('host/data.js')
    const noop = () => {}
    const success = (d) => ({ ok: true, data: d })
    const failure = (c, msg, r) => ({ ok: false, error: { code: c, message: msg, retryable: !!r } })
    const services = {
      sessionQuery: { listSessions: async () => [
        { header: { id: 'root', cwd: '/w' } },
        { header: { id: 'kid', cwd: '/w', parentSession: 'root' } },
        { header: { id: 'shot', cwd: '/w', parentSession: 'root' } },
        { header: { id: 'kidRun', cwd: '/w', parentSession: 'root' } },
        { header: { id: 'kidCold', cwd: '/w', parentSession: 'root' } },
      ], readTitleSnapshots: async () => [
        { status: 'fulfilled', sessionId: 'root', value: { title: { title: 'R' } } },
        { status: 'fulfilled', sessionId: 'kid', value: { title: { title: 'K' } } },
        { status: 'fulfilled', sessionId: 'shot', value: { title: { title: 'S' } } },
        { status: 'fulfilled', sessionId: 'kidRun', value: { title: { title: 'KR' } } },
        { status: 'fulfilled', sessionId: 'kidCold', value: { title: { title: 'KC' } } },
      ] },
      workspaceRegistry: { archivedSessionIds: ['arch1'] },
      subagents: { listChildren: listChildrenImpl },
      agents: { get: () => undefined },
    }
    const ops = createDataOps({ get: (n) => services[n] }, {
      success, failure,
      ERR: { BAD_REQUEST: 'BAD_REQUEST', INVALID_TITLE: 'INVALID_TITLE', WORKSPACE_UNAVAILABLE: 'WORKSPACE_UNAVAILABLE',
        SESSION_NOT_FOUND: 'SESSION_NOT_FOUND', SESSION_OUTSIDE_WORKSPACE: 'SESSION_OUTSIDE_WORKSPACE', SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE',
        SEQUENCE_CONFLICT: 'SEQUENCE_CONFLICT', ARCHIVE_FAILED: 'ARCHIVE_FAILED', INTERNAL_ERROR: 'INTERNAL_ERROR' },
    })
    return ops
  }

  it('子代理节点携带 subagentAddress（mode 来自 listChildren 契约）', async () => {
    const ops = await makeSnapshotWith({
      listChildrenImpl: async (parentId) => {
        if (parentId === 'root') return [{ id: 'kid', mode: 'continuable', activity: 'inactive' }]
        return []
      },
    })
    const res = await ops.snapshot({ path: '/w' })
    assert.equal(res.ok, true)
    const kid = res.data.nodes.find((n) => n.id === 'kid')
    assert.ok(kid, '子代理节点应存在于快照')
    assert.deepStrictEqual(kid.subagentAddress, { parentSessionId: 'root', childSessionId: 'kid', mode: 'continuable' })
    assert.equal(kid.subagent, true)
  })

  it('子代理活动状态来自 listChildren.activity（running → running）', async () => {
    const ops = await makeSnapshotWith({
      listChildrenImpl: async (parentId) => {
        if (parentId === 'root') return [
          { id: 'kidRun', mode: 'continuable', activity: 'running' },
          { id: 'kidCold', mode: 'continuable', activity: 'inactive' },
        ]
        return []
      },
    })
    const res = await ops.snapshot({ path: '/w' })
    assert.equal(res.ok, true)
    const run = res.data.nodes.find((n) => n.id === 'kidRun')
    const cold = res.data.nodes.find((n) => n.id === 'kidCold')
    assert.equal(run.status, 'running', '运行中子代理 status=running')
    assert.equal(cold.status, 'cold', 'inactive 子代理 status=cold')
  })

  it('结束的子代理 registry 仍收录 → status=idle（activity 滞后不误导）', async () => {
    // 模拟真实实测：子代理 Agent 已 idle（结束后未被清理），但 listChildren.activity 仍报 running。
    // registry 是权威 → idle；activity 只在该子代理从 registry 消失后才生效。
    const { createDataOps } = await loadProd('host/data.js')
    const noop = () => {}
    const success = (d) => ({ ok: true, data: d })
    const failure = (c, msg, r) => ({ ok: false, error: { code: c, message: msg, retryable: !!r } })
    const services = {
      sessionQuery: { listSessions: async () => [{ header: { id: 'root', cwd: '/w' } }, { header: { id: 'finished', cwd: '/w', parentSession: 'root' } }],
        readTitleSnapshots: async () => [{ status: 'fulfilled', sessionId: 'finished', value: { title: { title: 'F' } } }] },
      workspaceRegistry: {},
      subagents: { listChildren: async (p) => p === 'root' ? [{ id: 'finished', mode: 'continuable', activity: 'running' }] : [] },
      agents: { get: (id) => id === 'finished' ? { id, status: 'idle' } : undefined },
    }
    const ops = createDataOps({ get: (n) => services[n] }, {
      success, failure,
      ERR: { BAD_REQUEST: 'BAD_REQUEST', INVALID_TITLE: 'INVALID_TITLE', WORKSPACE_UNAVAILABLE: 'WORKSPACE_UNAVAILABLE',
        SESSION_NOT_FOUND: 'SESSION_NOT_FOUND', SESSION_OUTSIDE_WORKSPACE: 'SESSION_OUTSIDE_WORKSPACE', SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE',
        SEQUENCE_CONFLICT: 'SEQUENCE_CONFLICT', ARCHIVE_FAILED: 'ARCHIVE_FAILED', INTERNAL_ERROR: 'INTERNAL_ERROR' },
    })
    const res = await ops.snapshot({ path: '/w' })
    assert.equal(res.ok, true)
    const fin = res.data.nodes.find((n) => n.id === 'finished')
    assert.equal(fin.status, 'idle', 'registry 权威：结束但未清理的子代理 = idle（非绿色 running）')
  })

  it('未订阅事件时仍读取 agents.get 的 running 状态', async () => {
    const { createDataOps } = await loadProd('host/data.js')
    const success = (d) => ({ ok: true, data: d })
    const failure = (c, msg, r) => ({ ok: false, error: { code: c, message: msg, retryable: !!r } })
    const services = {
      sessionQuery: {
        listSessions: async () => [{ header: { id: 'active', cwd: '/w' } }],
        readTitleSnapshots: async () => [],
      },
      workspaceRegistry: {},
      subagents: { listChildren: async () => [] },
      agents: { get: (id) => id === 'active' ? { id, status: 'running' } : undefined },
    }
    const ops = createDataOps({ get: (n) => services[n] }, {
      success, failure,
      ERR: { WORKSPACE_UNAVAILABLE: 'WORKSPACE_UNAVAILABLE', SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE' },
    })
    const res = await ops.snapshot({ path: '/w' })
    assert.equal(res.ok, true)
    assert.equal(res.data.nodes[0].status, 'running')
  })

  it('非子代理节点 subagentAddress 为 null', async () => {
    const ops = await makeSnapshotWith({ listChildrenImpl: async () => [] })
    const res = await ops.snapshot({ path: '/w' })
    assert.equal(res.ok, true)
    const root = res.data.nodes.find((n) => n.id === 'root')
    assert.equal(root.subagent, false)
    assert.equal(root.subagentAddress, null)
  })

  it('one-shot 子代理 mode 正确映射', async () => {
    const ops = await makeSnapshotWith({
      listChildrenImpl: async (parentId) => {
        if (parentId === 'root') return [{ id: 'shot', mode: 'one-shot', activity: 'inactive' }]
        return []
      },
    })
    const res = await ops.snapshot({ path: '/w' })
    const shot = res.data.nodes.find((n) => n.id === 'shot')
    assert.deepStrictEqual(shot.subagentAddress, { parentSessionId: 'root', childSessionId: 'shot', mode: 'one-shot' })
  })
})

// ═══════════════════════════════════════════════════════════════════════════
// PERF-05 — 快照 in-flight 合并 + 重建信号量（压测崩盘复盘修复）
// 崩盘因果：并发 snapshot 缓存 miss 后各自全量重建（listSessions+readTitleSnapshots
// +每个节点 listChildren），60 并发 = 60 倍底层查询放大 → 宿主 OOM 被杀。
// 本组测试锁定修复：同 key 并发只发生一次底层查询；重建并发超限快速失败不堆积。
// ═══════════════════════════════════════════════════════════════════════════
describe('快照 in-flight 合并与信号量（PERF-05）', () => {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

  function makeOps(services) {
    const success = (d) => ({ ok: true, data: d })
    const failure = (c, msg, r) => ({ ok: false, error: { code: c, message: msg, retryable: !!r } })
    return createDataOps({ get: (n) => services[n] }, {
      success, failure,
      ERR: { BAD_REQUEST: 'BAD_REQUEST', INVALID_TITLE: 'INVALID_TITLE', WORKSPACE_UNAVAILABLE: 'WORKSPACE_UNAVAILABLE',
        SESSION_NOT_FOUND: 'SESSION_NOT_FOUND', SESSION_OUTSIDE_WORKSPACE: 'SESSION_OUTSIDE_WORKSPACE', SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE',
        SEQUENCE_CONFLICT: 'SEQUENCE_CONFLICT', ARCHIVE_FAILED: 'ARCHIVE_FAILED', INTERNAL_ERROR: 'INTERNAL_ERROR' },
    })
  }

  it('同工作区 5 并发 snapshot 合并为一次重建（listSessions/标题/子代理均只查一次）', async () => {
    // 修复：用 sleep(20) 制造并发窗口（gate 在这个测试里会导致 listSessions 永不返回 → runner 挂起）
    let listCalls = 0
    let titleCalls = 0
    const childCalls = new Map()
    const ops = makeOps({
      sessionQuery: {
        listSessions: async () => { listCalls += 1; await sleep(20); return [
          { header: { id: 'a', cwd: '/w' } },
          { header: { id: 'b', cwd: '/w', parentSession: 'a' } },
        ] },
        readTitleSnapshots: async () => { titleCalls += 1; return [
          { status: 'fulfilled', sessionId: 'a', value: { title: { title: 'A' } } },
          { status: 'fulfilled', sessionId: 'b', value: { title: { title: 'B' } } },
        ] },
      },
      workspaceRegistry: {},
      subagents: { listChildren: async (parentId) => { childCalls.set(parentId, (childCalls.get(parentId) || 0) + 1); return [] } },
      agents: { get: () => undefined },
    })
    const results = await Promise.all([
      ops.snapshot({ path: '/w' }), ops.snapshot({ path: '/w' }), ops.snapshot({ path: '/w' }),
      ops.snapshot({ path: '/w' }), ops.snapshot({ path: '/w' }),
    ])
    assert.equal(listCalls, 1, '并发请求必须合并：只允许一次 listSessions')
    assert.equal(titleCalls, 1, '标题快照只查询一次')
    assert.equal(childCalls.get('a'), 1, '子代理收集合并：每个 parentId 只 listChildren 一次')
    assert.equal(childCalls.get('b'), 1)
    for (const r of results) {
      assert.equal(r.ok, true)
      assert.equal(r.data.nodes.length, 2)
    }
    // 全部结果等价（统一命中一次重建）
    const firstJson = JSON.stringify(results[0].data.nodes)
    assert.ok(results.every((r) => JSON.stringify(r.data.nodes) === firstJson))
  })

  it('重建并发达到上限时后续请求快速失败（SERVICE_UNAVAILABLE retryable，不堆积）', async () => {
    let release
    const gate = new Promise((r) => { release = r })
    const ops = makeOps({
      sessionQuery: {
        listSessions: async () => { await gate; return [{ header: { id: 'a', cwd: '/w' } }] },
        readTitleSnapshots: async () => [],
      },
      workspaceRegistry: {},
      subagents: { listChildren: async () => [] },
      agents: { get: () => undefined },
    })
    // 3 个不同工作区并发重建占满信号量（SNAPSHOT_REBUILD_MAX=3）
    const p1 = ops.snapshot({ path: '/w1' })
    const p2 = ops.snapshot({ path: '/w2' })
    const p3 = ops.snapshot({ path: '/w3' })
    const p4 = ops.snapshot({ path: '/w4' }) // 第 4 个：应立即快速失败
    const r4 = await p4
    assert.equal(r4.ok, false, '第 4 个并发重建应快速失败')
    assert.equal(r4.error.retryable, true)
    release()
    assert.equal((await p1).ok, true)
    assert.equal((await p2).ok, true)
    assert.equal((await p3).ok, true)
  })

  it('同 key join 的并发请求在任务失败时同样获得失败（不悬挂）', async () => {
    // 修复：listSessions 首次调用 sleep 让第二个请求 join 到同一 in-flight 重建；
    // 两个请求都必须失败（共享失败），且底层只调用一次。
    let calls = 0
    const ops = makeOps({
      sessionQuery: {
        listSessions: async () => { calls += 1; if (calls === 1) await sleep(15); throw new Error('db down') },
        readTitleSnapshots: async () => [],
      },
      workspaceRegistry: {},
      subagents: { listChildren: async () => [] },
      agents: { get: () => undefined },
    })
    const [r1, r2] = await Promise.all([ops.snapshot({ path: '/w' }), ops.snapshot({ path: '/w' })])
    assert.equal(r1.ok, false)
    assert.equal(r2.ok, false)
    assert.equal(calls, 1, '失败请求也应合并为一次底层调用')
  })

  it('AUD-03：在途重建期间 invalidateWorkspace → 旧结果不回填缓存（写后读新）', async () => {
    // 时序：t0 重建在途（listSessions 挂 gate）→ t1 写失效（此刻缓存无条目，
    // delete 落空）→ t2 重建完成。旧实现把失效前数据写回缓存并享有完整 TTL
    // → 写后最长 2.5s 读旧。修复：失效纪元（epoch）比对，不一致则不写缓存。
    let release
    const gate = new Promise((r) => { release = r })
    let listCalls = 0
    const ops = makeOps({
      sessionQuery: {
        listSessions: async () => { listCalls += 1; await gate; return [{ header: { id: 'a', cwd: '/w' } }] },
        readTitleSnapshots: async () => [],
      },
      workspaceRegistry: {},
      subagents: { listChildren: async () => [] },
      agents: { get: () => undefined },
    })
    const p1 = ops.snapshot({ path: '/w' })
    await sleep(0) // 让重建推进到 listSessions 在途
    assert.equal(listCalls, 1, '重建应在途（listSessions 已调用）')
    ops.invalidateWorkspace('/w') // 写操作失效
    release()
    const r1 = await p1
    assert.equal(r1.ok, true)
    const r2 = await ops.snapshot({ path: '/w' })
    assert.equal(r2.ok, true)
    assert.equal(listCalls, 2, '失效期间完成的在途重建不得写入缓存（必须重新重建）')
    // 正常路径回归：无失效时第二轮命中缓存（epoch 机制不误伤正常缓存）
    const r3 = await ops.snapshot({ path: '/w' })
    assert.equal(r3.ok, true)
    assert.equal(listCalls, 2, '无失效时应命中缓存（TTL 内不重复重建）')
  })
})

// ═══════════════════════════════════════════════════════════════════════════
// ARCH-03 — 归档按需加载：默认不显示归档时，宿主快照直接跳过归档节点的
// 标题读取/子代理收集/布局；只有 includeArchived=true 才全量加入。
// 覆盖用户场景：归档 40/45 后默认轮询只重建 5 个可见节点（不再每 2s 全量扫描）。
// ═══════════════════════════════════════════════════════════════════════════
describe('归档可见性按需加载（ARCH-03）', () => {
  const success = (d) => ({ ok: true, data: d })
  const failure = (c, msg, r) => ({ ok: false, error: { code: c, message: msg, retryable: !!r } })
  const ERR = { BAD_REQUEST: 'BAD_REQUEST', INVALID_TITLE: 'INVALID_TITLE', WORKSPACE_UNAVAILABLE: 'WORKSPACE_UNAVAILABLE',
    SESSION_NOT_FOUND: 'SESSION_NOT_FOUND', SESSION_OUTSIDE_WORKSPACE: 'SESSION_OUTSIDE_WORKSPACE', SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE',
    SEQUENCE_CONFLICT: 'SEQUENCE_CONFLICT', ARCHIVE_FAILED: 'ARCHIVE_FAILED', INTERNAL_ERROR: 'INTERNAL_ERROR' }

  function makeArchOps() {
    const titleIds = []
    const childParents = []
    const calls = { listSessions: 0 }
    const services = {
      sessionQuery: {
        listSessions: async () => {
          calls.listSessions += 1
          return [
            { header: { id: 'vis1', cwd: '/w' } },
            { header: { id: 'arch1', cwd: '/w', parentSession: 'vis1' } },
            { header: { id: 'arch2', cwd: '/w', parentSession: 'arch1' } },
            { header: { id: 'vis2', cwd: '/w', parentSession: 'arch2' } },
          ]
        },
        readTitleSnapshots: async (ids) => { titleIds.push(...ids); return ids.map((id) => ({ status: 'fulfilled', sessionId: id, value: { title: { title: id.toUpperCase() } } })) },
      },
      workspaceRegistry: { archivedSessionIds: ['arch1', 'arch2'] },
      subagents: { listChildren: async (parentId) => { childParents.push(parentId); return [] } },
      agents: { get: () => undefined },
    }
    const ops = createDataOps({ get: (n) => services[n] }, { success, failure, ERR })
    return { ops, titleIds, childParents, calls }
  }

  it('默认（includeArchived=false/缺省）：归档节点不进快照，标题/子代理只读可见节点', async () => {
    const { ops, titleIds, childParents } = makeArchOps()
    const res = await ops.snapshot({ path: '/w' })
    assert.equal(res.ok, true)
    assert.deepStrictEqual(res.data.nodes.map((n) => n.id), ['vis1', 'vis2'], '默认模式只含可见节点')
    assert.deepStrictEqual(titleIds, ['vis1', 'vis2'], '标题快照只读可见节点')
    assert.deepStrictEqual(childParents, ['vis1', 'vis2'], '子代理收集只查询可见父会话')
    const descendant = res.data.nodes.find((n) => n.id === 'vis2')
    assert.equal(descendant.parentId, 'vis1', '跳过连续归档祖先并重连到最近可见祖先')
    assert.equal(descendant.parentArchivedBridge, true)
    const { computeEdges: edgeBuilder } = await loadProd('client/layout.js')
    assert.deepStrictEqual(edgeBuilder(res.data.nodes, 1, false), [
      { from: 'vis1', to: 'vis2', dashed: false, doubleDashed: true },
    ])
  })

  it('includeArchived=true：全量加入，归档节点带 archived 标记', async () => {
    const { ops, titleIds, childParents } = makeArchOps()
    const res = await ops.snapshot({ path: '/w', includeArchived: true })
    assert.equal(res.ok, true)
    const ids = res.data.nodes.map((n) => n.id).sort()
    assert.deepStrictEqual(ids, ['arch1', 'arch2', 'vis1', 'vis2'])
    const arch = res.data.nodes.find((n) => n.id === 'arch1')
    assert.equal(arch.archived, true)
    const vis = res.data.nodes.find((n) => n.id === 'vis1')
    assert.equal(vis.archived, false)
    const descendant = res.data.nodes.find((n) => n.id === 'vis2')
    assert.equal(descendant.parentId, 'arch2')
    assert.equal(descendant.parentArchivedBridge, false)
    assert.deepStrictEqual(titleIds, ['vis1', 'arch1', 'arch2', 'vis2'])
    assert.deepStrictEqual(childParents, ['vis1', 'arch1', 'arch2', 'vis2'])
  })

  it('含归档快照使用长 TTL，超过默认 2.5s 后重复显隐仍不重建', async () => {
    const realNow = Date.now
    let now = 1_000
    Date.now = () => now
    try {
      const { ops, calls } = makeArchOps()
      await ops.snapshot({ path: '/w', includeArchived: true })
      now += 3_000
      await ops.snapshot({ path: '/w', includeArchived: true })
      assert.equal(calls.listSessions, 1, '含归档快照 3s 后仍应直接复用，不再次扫描全部会话')
    } finally {
      Date.now = realNow
    }
  })

  it('结构失效后复用标题缓存；重命名只重读目标标题', async () => {
    const { ops, titleIds } = makeArchOps()
    await ops.snapshot({ path: '/w', includeArchived: true })
    titleIds.length = 0

    // 归档等结构变化：快照必须重建，但四个冷会话标题无需重新折叠日志。
    ops.invalidateWorkspace('/w')
    await ops.snapshot({ path: '/w', includeArchived: true })
    assert.deepStrictEqual(titleIds, [])

    // 重命名：只失效被修改的标题，其余标题继续复用。
    ops.invalidateWorkspace('/w', { titleIds: ['arch1'] })
    await ops.snapshot({ path: '/w', includeArchived: true })
    assert.deepStrictEqual(titleIds, ['arch1'])
  })

  it('首次显示归档先返回结构骨架，完整标题在后台构建', async () => {
    let releaseTitles
    let listCalls = 0
    const titleGate = new Promise((resolve) => { releaseTitles = resolve })
    const services = {
      sessionQuery: {
        listSessions: async () => {
          listCalls += 1
          return [
            { header: { id: 'vis1', cwd: '/w' } },
            { header: { id: 'arch1', cwd: '/w', parentSession: 'vis1' } },
          ]
        },
        readTitleSnapshots: async (ids) => {
          await titleGate
          return ids.map((id) => ({ status: 'fulfilled', sessionId: id, value: { title: { title: id.toUpperCase() } } }))
        },
      },
      workspaceRegistry: { archivedSessionIds: ['arch1'] },
      subagents: { listChildren: async () => [] },
      agents: { get: () => undefined },
    }
    const ops = createDataOps({ get: (n) => services[n] }, { success, failure, ERR })

    const fast = await ops.snapshot({ path: '/w', includeArchived: true, preferCached: true })
    assert.equal(fast.ok, true)
    assert.equal(fast.data.hydrating, true)
    assert.deepStrictEqual(fast.data.nodes.map((n) => n.id), ['arch1', 'vis1'])
    assert.equal(fast.data.nodes.find((n) => n.id === 'arch1').title, 'arch1', '骨架可先用 id 占位')

    const fastAgain = await ops.snapshot({ path: '/w', includeArchived: true, preferCached: true })
    assert.equal(fastAgain.ok, true)
    assert.equal(fastAgain.data.generatedAt, fast.data.generatedAt, '后台补齐期间重复请求应复用骨架')
    assert.equal(listCalls, 2, '只允许完整预热和首次骨架各列举一次，后续轮询不得再次读持久化列表')

    releaseTitles()
    const full = await ops.snapshot({ path: '/w', includeArchived: true })
    assert.equal(full.ok, true)
    assert.equal(full.data.hydrating, undefined)
    assert.equal(full.data.nodes.find((n) => n.id === 'arch1').title, 'ARCH1')
  })

  it('归档后在默认模式立即失效缓存（invalidateWorkspace 双变体）', async () => {
    // 先取带归档快照 → 归档一个可见节点 → 默认模式不应再看到它
    const { createDataOps } = await loadProd('host/data.js')
    let archivedIds = ['arch1', 'arch2']
    const services = {
      sessionQuery: {
        listSessions: async () => [
          { header: { id: 'vis1', cwd: '/w' } },
          { header: { id: 'vis2', cwd: '/w' } },
          { header: { id: 'arch1', cwd: '/w' } },
        ],
        readTitleSnapshots: async (ids) => ids.map((id) => ({ status: 'fulfilled', sessionId: id, value: { title: { title: id.toUpperCase() } } })),
      },
      workspaceRegistry: { get archivedSessionIds() { return archivedIds } },
      subagents: { listChildren: async () => [] },
      agents: { get: () => undefined },
    }
    const ops = createDataOps({ get: (n) => services[n] }, { success, failure, ERR })
    await ops.snapshot({ path: '/w', includeArchived: true })
    // 归档 vis2 → 使缓存失效 → 默认模式应只剩 vis1
    archivedIds = ['arch1', 'arch2', 'vis2']
    ops.invalidateWorkspace('/w')
    const def = await ops.snapshot({ path: '/w' })
    assert.deepStrictEqual(def.data.nodes.map((n) => n.id), ['vis1'])
    const all = await ops.snapshot({ path: '/w', includeArchived: true })
    assert.equal(all.data.nodes.length, 3)
  })
})
// 注：REV-02（2026-08-18）删除原文件尾部的"程序化 run()"分支（TEST-01 §4.4 明令禁止：
// 会产生 `run() is being called recursively` warning 且 CI 失败条件含"出现 warning"）。
// 测试只经 `node --test <files>` 入口运行。
// ═══════════════════════════════════════════════════════════════════════════
// AUD-01（2026-08-18）— 命中检测使用显式有效缩放 curEz
// 旧实现从 view.viewScale 读（该字段从不存在于 state.view，恒 undefined → 按
// zoom 判定）→ 窄面板（viewScale<1）时命中/拖拽/框选坐标系与渲染不一致
//（点不中、拖错位）。修复后 curEz 由调用方从 cur.ez 显式传入。
// ═══════════════════════════════════════════════════════════════════════════
describe('AUD-01 命中检测坐标系（有效缩放显式传入）', () => {
  it('ez=0.5 时按缩放后边界判定（旧实现按 zoom=1 判定 → 远端误命中）', async () => {
    const geo = await loadProd('client/canvas-geometry.js')
    const layout = await loadProd('client/layout.js')
    const { hitNodeById } = geo
    const { NODE_W, NODE_H } = layout
    const nodes = [{ id: 'a' }]
    const pos = new Map([['a', { x: 0, y: 0 }]])
    const view = { x: 0, y: 0, zoom: 1 }
    const rect = { left: 0, top: 0 }
    // 节点屏幕宽度 = NODE_W * ez；远端点击（0.75×NODE_W）超出 ez=0.5 的边界 → null
    assert.equal(
      hitNodeById({ clientX: NODE_W * 0.75, clientY: 5 }, nodes, pos, false, view, rect, 0.5),
      null,
      '超出 ez=0.5 缩放边界的点击不得命中（旧实现按 ez=1 会误命中）',
    )
    // 近端点击在缩放后边界内 → 命中
    assert.equal(
      hitNodeById({ clientX: NODE_W * 0.2, clientY: NODE_H * 0.2 }, nodes, pos, false, view, rect, 0.5),
      'a',
    )
  })

  it('ez=2（放大）时边界同步放大，view 偏移照常参与', async () => {
    const geo = await loadProd('client/canvas-geometry.js')
    const layout = await loadProd('client/layout.js')
    const { hitNodeById } = geo
    const { NODE_W, NODE_H } = layout
    const nodes = [{ id: 'a' }]
    const pos = new Map([['a', { x: 100, y: 50 }]])
    const view = { x: 10, y: 20, zoom: 1 }
    const rect = { left: 0, top: 0 }
    // ez=2：节点屏幕左缘 = 100*2+10 = 210，上缘 = 50*2+20 = 120
    assert.equal(
      hitNodeById({ clientX: 210 + NODE_W, clientY: 120 + NODE_H }, nodes, pos, false, view, rect, 2),
      'a',
    )
    assert.equal(
      hitNodeById({ clientX: 100 + NODE_W, clientY: 50 + NODE_H }, nodes, pos, false, view, rect, 2),
      null,
      '按 ez=1 的中心判定在 ez=2 下应落空（坐标系必须与渲染一致）',
    )
  })
})
