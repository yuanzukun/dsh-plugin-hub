/**
 * contract.test.js — 共享契约工厂函数（src/shared/contract.ts 生产产物）。
 * 覆盖 makeNode / makeSnapshotPayload / makeArchiveResult 的默认值与编组逻辑，
 * 以及 BrvisErrorCode 常量与 RpcResult 形状约定（CONTRACT-01）。
 */

'use strict'
const { describe, it, before } = require('node:test')
const assert = require('node:assert/strict')
const path = require('node:path')

const BUNDLE_LIB = path.join(__dirname, '..', 'lib')
const contractUrl = require('node:url').pathToFileURL(
  path.join(BUNDLE_LIB, 'shared', 'contract.js'),
).href

let mod
before(async () => {
  mod = await import(contractUrl)
})

describe('contract — 工厂函数（CONTRACT-01）', () => {
  it('makeNode：最小输入产出完整默认节点', () => {
    const n = mod.makeNode({ id: 'node-1' })
    assert.equal(n.id, 'node-1')
    assert.equal(n.title, '')
    assert.equal(n.parentId, null)
    assert.equal(n.parentArchivedBridge, false)
    assert.equal(n.archived, false)
    assert.equal(n.subagent, false)
    assert.equal(n.subagentAddress, null)
    assert.equal(n.status, 'cold')
    assert.equal(n.createdAt, 0)
  })

  it('makeNode：显式字段覆盖默认值', () => {
    const n = mod.makeNode({
      id: 'n2',
      parentId: 'p1',
      parentArchivedBridge: true,
      title: '标题T',
      archived: true,
      subagent: true,
      subagentAddress: { parentSessionId: 'p1', childSessionId: 'c1', mode: 'continuable' },
      status: 'running',
      createdAt: 12345,
    })
    assert.equal(n.parentId, 'p1')
    assert.equal(n.parentArchivedBridge, true)
    assert.equal(n.title, '标题T')
    assert.equal(n.archived, true)
    assert.equal(n.subagent, true)
    assert.equal(n.subagentAddress.mode, 'continuable')
    assert.equal(n.subagentAddress.childSessionId, 'c1')
    assert.equal(n.status, 'running')
    assert.equal(n.createdAt, 12345)
  })

  it('makeNode：parentId 为 null 的根节点保持 null', () => {
    const n = mod.makeNode({ id: 'root', parentId: null })
    assert.equal(n.parentId, null)
  })

  it('makeSnapshotPayload：空输入产出含默认值的快照', () => {
    const s = mod.makeSnapshotPayload({})
    assert.equal(s.workspace, '')
    assert.equal(s.generatedAt, 0)
    assert.deepStrictEqual(s.nodes, [])
  })

  it('makeSnapshotPayload：显式字段透传（未知字段保留）', () => {
    const s = mod.makeSnapshotPayload({
      workspace: 'ws1',
      nodes: [{ id: 'a' }],
      edges: [{ from: 'a', to: 'b', dashed: false }],
      subagentList: [{ childId: 'c1' }],
      agentStatus: { a: 'running' },
      generatedAt: 999,
    })
    assert.equal(s.workspace, 'ws1')
    assert.equal(s.nodes.length, 1)
    assert.equal(s.edges.length, 1)
    assert.equal(s.subagentList.length, 1)
    assert.deepStrictEqual(s.agentStatus, { a: 'running' })
    assert.equal(s.generatedAt, 999)
  })

  it('makeArchiveResult：成功编组 ok:true', () => {
    const r = mod.makeArchiveResult({
      sessionId: 's1',
      ok: true,
      code: null,
      archived: true,
      message: undefined,
    })
    assert.equal(r.sessionId, 's1')
    assert.equal(r.ok, true)
    assert.equal(r.code, null)
    assert.equal(r.archived, true)
    assert.equal(r.message, undefined)
  })

  it('makeArchiveResult：失败编组 code/message 透传', () => {
    const r = mod.makeArchiveResult({
      sessionId: 's2',
      ok: false,
      code: 'SERVICE_UNAVAILABLE',
      message: '查询失败',
      archived: false,
    })
    assert.equal(r.ok, false)
    assert.equal(r.code, 'SERVICE_UNAVAILABLE')
    assert.equal(r.message, '查询失败')
    assert.equal(r.archived, false)
  })

  it('BrvisErrorCode：关键错误码存在且为字符串', () => {
    for (const key of ['INVALID_TITLE', 'SEQUENCE_CONFLICT', 'FORBIDDEN', 'NOT_FOUND', 'INTERNAL_ERROR', 'BAD_REQUEST', 'PAYLOAD_TOO_LARGE']) {
      assert.equal(typeof mod.BrvisErrorCode[key], 'string', key + ' 必须是字符串')
    }
  })

  it('BrvisErrorCode：错误码无重复值（唯一性）', () => {
    const values = Object.values(mod.BrvisErrorCode)
    assert.equal(new Set(values).size, values.length, '错误码值必须唯一')
  })
})
