/**
 * dsh-brvis 压测脚本（手动基准脚本，非 npm test / CI 成员——AUD-17 定位）。
 * 注意：P2/P3/P4 是**写操作压测**（真实 DSH 端点改名/归档），归档目标优先
 * 已归档会话（幂等无害），但仍会写会话标题。只在开发/测试环境执行。
 *
 * 参数化（AUD-17）：不再写死个人路径/会话 UUID，全部可注入：
 *   BRVIS_BASE     端点前缀（默认 http://127.0.0.1:3080/brvis/api）
 *   BRVIS_WS       工作区路径（默认 process.cwd()）
 *   BRVIS_TEST_ID  终态验证的目标会话 id（默认取快照首个节点）
 * 示例：BRVIS_WS=./fixture BRVIS_TEST_ID=example-id node tests/stress-load.js
 *
 * 维度：
 *   P1 快照并发吞吐（模拟客户端 2s 轮询 + 多标签页并发）
 *   P2 rename 并发冲突（多客户端同时改名同一会话 → SEQUENCE_CONFLICT 重试路径）
 *   P3 archiveMany 大列表（边界 100 项 / 全量 40 项）
 *   P4 读写混合（读 80% + 写 20%）
 *   P5 连接稳定性（长连接风暴 + 短超时请求）
 */
const BRVIS_BASE = process.env.BRVIS_BASE || 'http://127.0.0.1:3080/brvis/api'
const WS = process.env.BRVIS_WS || process.cwd()

function rpc(method, args, timeoutMs = 15000, externalSignal = null) {
  const ctrl = new AbortController()
  const t = setTimeout(() => ctrl.abort(), timeoutMs)
  if (externalSignal) {
    if (externalSignal.aborted) ctrl.abort()
    else externalSignal.addEventListener('abort', () => ctrl.abort(), { once: true })
  }
  return fetch(BRVIS_BASE + '/' + method, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-brvis-request': '1' },
    body: JSON.stringify(args || {}),
    signal: ctrl.signal,
  }).then(async (res) => {
    const body = await res.json()
    return { status: res.status, body }
  }).catch((e) => {
    return { status: 0, body: { error: { code: e.name === 'AbortError' ? 'TIMEOUT' : 'NETWORK', message: e.message } } }
  }).finally(() => clearTimeout(t))
}

async function snapshot() {
  return rpc('snapshot', { path: WS })
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

function stats(name, results, keys) {
  const total = results.length
  const ok = results.filter((r) => r.body && r.body.ok).length
  const fail = total - ok
  const times = results.map((r) => r.ms).sort((a, b) => a - b)
  const avg = times.reduce((a, b) => a + b, 0) / total
  const p50 = times[Math.floor(total * 0.5)]
  const p95 = times[Math.floor(total * 0.95)]
  const p99 = times[Math.floor(total * 0.99)]
  const max = times[total - 1]
  const errCodes = {}
  for (const r of results) {
    if (!r.body.ok && r.body.error) errCodes[r.body.error.code] = (errCodes[r.body.error.code] || 0) + 1
  }
  console.log(`\n━━━ ${name} ━━━`)
  console.log(`  请求: ${total}  成功: ${ok}  失败: ${fail}`)
  console.log(`  延迟: avg=${avg.toFixed(1)}ms p50=${p50}ms p95=${p95}ms p99=${p99}ms max=${max}ms`)
  if (Object.keys(errCodes).length) console.log(`  错误码: ${JSON.stringify(errCodes)}`)
  return { total, ok, fail, avg, p95, errCodes }
}

async function runConcurrent(name, count, concurrency, fn) {
  const queue = [...Array(count).keys()]
  let idx = 0
  const results = []
  async function worker() {
    while (true) {
      const i = idx++
      if (i >= queue.length) return
      const t0 = Date.now()
      const r = await fn()
      r.ms = Date.now() - t0
      results[i] = r
    }
  }
  const workers = []
  for (let i = 0; i < concurrency; i++) workers.push(worker())
  await Promise.all(workers)
  return stats(name, results)
}

async function main() {
  console.log('════════════════════════════════════════════════')
  console.log(' dsh-brvis 压力测试（真实 DSH 端点）')
  console.log(' 目标: ' + BRVIS_BASE)
  console.log('════════════════════════════════════════════════')

  // 先取基线快照 + 目标会话
  const base = await snapshot()
  if (!base.body.ok) { console.error('基线快照失败，终止'); return }
  const nodes = base.body.data.nodes
  console.log(`基线: ${nodes.length} 节点`)
  const archId = nodes.find((n) => n.archived)?.id || nodes[0].id
  // AUD-17：testId 不再写死个人 UUID，由 BRVIS_TEST_ID 或快照首个节点决定
  const testId = process.env.BRVIS_TEST_ID || nodes[0].id

  // ── P1 快照并发吞吐 ──
  console.log('\n[P1] 快照并发吞吐（60 并发 × 各 5 次 = 300 请求）')
  const p1 = await runConcurrent('P1 快照并发', 300, 60, snapshot)

  // ── P2 rename 并发冲突 ──
  // 5 个并发对同一会话改名 → 冲突检测/重试路径；用已归档会话（无害）
  console.log('\n[P2] rename 并发冲突（10 并发 × 同一已归档会话，各改名）')
  let seqConflicts = 0
  const p2Results = []
  const p2Workers = []
  const titles = ['压测A', '压测B', '压测C', '压测D', '压测E', '压测F', '压测G', '压测H', '压测I', '压测J']
  for (let i = 0; i < 10; i++) {
    p2Workers.push((async () => {
      const t0 = Date.now()
      const r = await rpc('rename', { sessionId: archId, title: titles[i] + '-' + Date.now(), path: WS })
      if (!r.body.ok && r.body.error && r.body.error.code === 'SEQUENCE_CONFLICT') seqConflicts++
      return { ...r, ms: Date.now() - t0 }
    })())
  }
  const p2 = await Promise.all(p2Workers)
  stats('P2 rename 并发', p2)
  console.log(`  SEQUENCE_CONFLICT 命中: ${seqConflicts}（重试/冲突路径被锻炼）`)

  // ── P3 archiveMany 大列表 ──
  console.log('\n[P3] archiveMany 批量（全量 40 项 + 边界 100 项 + 重复项）')
  const allIds = nodes.map((n) => n.id)
  const p3a = await runConcurrent('P3a archiveMany 全量40项', 5, 1, () => rpc('archiveMany', { path: WS, sessionIds: allIds }))
  const p3b = await runConcurrent('P3b archiveMany 100项(含重复)', 3, 1, () => {
    const ids = [...allIds]
    while (ids.length < 100) ids.push(allIds[ids.length % allIds.length])
    return rpc('archiveMany', { path: WS, sessionIds: ids })
  })

  // ── P4 读写混合 ──
  console.log('\n[P4] 读写混合（80% 快照 + 20% 归档幂等，60 并发 × 200）')
  const p4 = await runConcurrent('P4 混合负载', 200, 60, async () => {
    const r = Math.random()
    if (r < 0.8) return snapshot()
    return rpc('archive', { sessionId: archId, path: WS }) // 已归档 → 幂等
  })

  // ── P5 连接稳定性（短超时 + 立即断开） ──
  console.log('\n[P5] 连接稳定性（50 个超短超时请求 + 50 个立即 aborted）')
  const p5Results = []
  for (let i = 0; i < 50; i++) {
    p5Results.push((async () => {
      const t0 = Date.now()
      const r = await rpc('snapshot', { path: WS }, 1) // 1ms 超时 → 必然 abort
      return { ...r, ms: Date.now() - t0 }
    })())
  }
  const abortResults = []
  for (let i = 0; i < 50; i++) {
    abortResults.push((async () => {
      const ctrl = new AbortController()
      ctrl.abort() // 立即 abort
      const t0 = Date.now()
      const r = await rpc('snapshot', { path: WS }, 15000, ctrl.signal)
      return { ...r, ms: Date.now() - t0 }
    })())
  }
  const p5 = await Promise.all([...p5Results, ...abortResults])
  stats('P5 连接风暴', p5)

  // ── 终态验证 ──
  console.log('\n[FINAL] 压测后终态快照')
  await sleep(500)
  const fin = await snapshot()
  if (fin.body.ok) {
    const fn = fin.body.data.nodes
    console.log(`  节点: ${fn.length}（基线 ${nodes.length}）`)
    console.log(`  running=${fn.filter((n) => n.status === 'running').length} idle=${fn.filter((n) => n.status === 'idle').length} archived=${fn.filter((n) => n.archived).length}`)
    const t = fn.find((n) => n.id === testId)
    console.log(`  测试会话标题: ${t ? t.title : '???'}`)
    console.log('  ✅ 服务稳定，状态一致')
  } else {
    console.log('  ❌ 终态快照失败: ' + JSON.stringify(fin.body.error))
  }
  console.log('\n════════ 压测结束 ════════')
}

main().catch((e) => { console.error('压测脚本异常', e); process.exit(1) })
