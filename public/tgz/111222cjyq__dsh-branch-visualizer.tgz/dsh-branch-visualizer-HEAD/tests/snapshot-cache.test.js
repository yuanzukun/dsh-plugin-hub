'use strict'
const assert = require('node:assert/strict')
const { before, describe, it } = require('node:test')
const path = require('node:path')
const { pathToFileURL } = require('node:url')

let canvasSnapshotSignature
let readCanvasSnapshot
let writeCanvasSnapshot

before(async () => {
  const url = pathToFileURL(path.join(__dirname, '..', 'lib', 'client', 'snapshot-cache.js')).href
  const mod = await import(url)
  canvasSnapshotSignature = mod.canvasSnapshotSignature
  readCanvasSnapshot = mod.readCanvasSnapshot
  writeCanvasSnapshot = mod.writeCanvasSnapshot
})

function node(id, archived = false) {
  return {
    id,
    title: id.toUpperCase(),
    parentId: null,
    parentArchivedBridge: false,
    archived,
    subagent: false,
    subagentAddress: null,
    status: 'cold',
    createdAt: 1,
  }
}

describe('归档显隐双快照缓存（ARCH-PERF-03）', () => {
  it('精简快照更新不会覆盖已加载的含归档快照', () => {
    const variants = {}
    const full = [node('visible'), node('archived', true)]
    const visible = [node('visible')]

    writeCanvasSnapshot(variants, 'D:/work', true, full, 10)
    writeCanvasSnapshot(variants, 'D:/work', false, visible, 20)

    assert.deepStrictEqual(readCanvasSnapshot(variants, 'D:/work', true)?.nodes, full)
    assert.deepStrictEqual(readCanvasSnapshot(variants, 'D:/work', false)?.nodes, visible)
  })

  it('切回显示归档可同步读出旧快照，路径变化不会串用缓存', () => {
    const variants = {}
    const full = [node('a'), node('b', true)]
    writeCanvasSnapshot(variants, 'D:/work', true, full, 10)

    assert.equal(readCanvasSnapshot(variants, 'D:/other', true), null)
    assert.equal(readCanvasSnapshot(variants, 'D:/work', true)?.generatedAt, 10)
    assert.equal(readCanvasSnapshot(variants, 'D:/work', true)?.signature, canvasSnapshotSignature(full))
  })
})
