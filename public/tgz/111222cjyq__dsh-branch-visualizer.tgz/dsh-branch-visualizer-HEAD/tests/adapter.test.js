'use strict'
const { describe, it } = require('node:test')
const assert = require('node:assert/strict')
const path = require('node:path')
const { pathToFileURL } = require('node:url')

const lib = path.join(__dirname, '..', 'lib')
const load = (relativePath) => import(pathToFileURL(path.join(lib, relativePath)).href)

describe('DeepSeek Harness compatibility adapters', () => {
  it('host service names are resolved by the host adapter', async () => {
    const { createDshHostServices, ADAPTER_ID } = await load('platform/adapters/dsh-preview-2026-08/host.js')
    const requested = []
    const services = createDshHostServices({
      get(name) { requested.push(name); return { service: name } },
      on() { return () => {} },
    })
    assert.equal(ADAPTER_ID, 'dsh-preview-2026-08')
    assert.equal(services.sessionQuery.service, 'sessionQuery')
    assert.equal(services.workspaceRegistry.service, 'workspaceRegistry')
    assert.deepStrictEqual(requested, ['sessionQuery', 'workspaceRegistry'])
  })

  it('client service and slot names are resolved by the client adapter', async () => {
    const { createDshClientServices, CLIENT_ADAPTER_ID, DSH_CLIENT_SLOTS } = await load('platform/adapters/dsh-preview-2026-08/client.js')
    const requested = []
    const services = createDshClientServices({ get(name) { requested.push(name); return { service: name } } })
    assert.equal(CLIENT_ADAPTER_ID, 'dsh-preview-2026-08')
    assert.equal(services.slots.service, 'slots')
    assert.equal(services.sessions.service, 'sessions')
    assert.deepStrictEqual(requested, ['slots', 'sessions'])
    assert.deepStrictEqual(DSH_CLIENT_SLOTS, {
      overlay: 'shell.overlay',
      sessionUtilities: 'conversation.session.header.utilities',
    })
  })

  it('adapter 将缺失服务抛错收敛为 undefined', async () => {
    const { createDshHostServices } = await load('platform/adapters/dsh-preview-2026-08/host.js')
    const { createDshClientServices } = await load('platform/adapters/dsh-preview-2026-08/client.js')
    const throwing = { get() { throw new Error('service missing') } }
    assert.equal(createDshHostServices(throwing).sessionQuery, undefined)
    assert.equal(createDshClientServices(throwing).slots, undefined)
  })

  it('capability probe consumes adapter output instead of a raw Cordis context', async () => {
    const { probeHostCapabilities } = await load('platform/capabilities.js')
    const caps = probeHostCapabilities({
      sessionQuery: { listSessions() {}, readTitleSnapshots() {} },
      sessionTitle: { rename() {} },
      sessionPersistence: { append() {} },
      workspaceRegistry: { archiveSession() {}, resolveByPath() {}, list() {} },
      agents: { list() {}, get() {} },
      subagents: { listChildren() {} },
      on() {},
    })
    assert.equal(caps.sessionRead, 'available')
    assert.equal(caps.titleRead, 'available')
    assert.equal(caps.liveRename, 'available')
    assert.equal(caps.coldRename, 'available')
    assert.equal(caps.archive, 'available')
    assert.equal(caps.agentStatus, 'events')
    assert.equal(caps.subagents, 'available')
    assert.equal(caps.workspaceIdentity, 'id')
  })
})
