# 修改与发布指南

## 日常开发基线

```bash
npm ci --ignore-scripts
npm run typecheck
npm run lint
npm run build
npm test
npm run privacy:check
npm run pack:check
```

也可以直接运行 `npm run verify`。测试依赖刚构建的 `lib`，不要在跳过构建的情况下把旧产物测试结果当成当前源码结果。

## 修改不同功能

### 布局或连线

1. 修改 `src/client/layout.ts` 的纯函数。
2. 在 `tests/brvis.test.js` 增加图结构快照。
3. 覆盖循环、孤儿节点、归档链、空数组和多根。
4. 在 Harness 中检查真实边锚点和缩放后的可读性。

### 画布交互

1. 几何算法放 `canvas-geometry.ts`。
2. 动作和手势放 `canvas-interactions.ts`。
3. 展示元素放 `canvas-elements.tsx`。
4. React effect、轮询和组装留在 `canvas.tsx`。
5. 异步 DSH 方法必须 `await` 后再更新本地成功状态。

### 快照与缓存

1. 先定义 wire 字段和默认值。
2. 快照签名必须包含所有影响视觉/交互的字段。
3. 新缓存必须有 TTL、容量上限、失效和并发合并策略。
4. mutation 成功后同时失效默认/含归档变体。
5. 测试写入与在途重建的竞态。

### 改名或归档

1. 所有 ID 和工作区路径先授权，后写入。
2. 路径权威解析退化时拒绝写。
3. 批量输入先完整校验，不允许一边校验一边写。
4. 部分成功必须逐项可见。
5. 不要用内部文件写入模拟尚不存在的官方取消归档。

### Harness 适配

1. 先查当前官方源码/文档，不凭旧记忆改接口。
2. service、event、slot 或导航形状变化只改版本化 adapter。
3. 外部 DTO 变化在 adapter 转换为稳定 contract。
4. 不确定的写能力默认关闭。
5. 执行 [DSH_COMPATIBILITY_STRATEGY.md](./DSH_COMPATIBILITY_STRATEGY.md) 的完整升级清单。

## 新增 wire 字段的顺序

1. `src/shared/contract.ts` 增加类型和安全默认值。
2. Host 快照构建赋值。
3. Client `CanvasNode`/布局/展示按需消费。
4. 轮询内容签名与图结构签名纳入字段。
5. contract、Host→Client 集成和 UI 行为测试。
6. 若旧 Host 可能省略字段，Client 类型和逻辑应有兼容默认。

## 安全与隐私检查

提交前确认：

- 源码、README、示例中没有真实用户目录或工作区绝对路径；
- 没有真实会话 ID、标题、消息内容、邮箱、token、cookie 或私钥；
- 日志不输出工作区路径或会话 ID；
- 诊断保持去敏；
- 新 HTTP 路由继续走统一 guard；
- 新 mutation 继续走工作区授权；
- `npm run privacy:check` 通过；
- 公共 Git 历史本身不包含旧的私人审查文档或作者身份泄漏。

## 版本和兼容声明

- patch：内部修复，不改变 contract；
- minor：新增兼容功能或 wire 可选字段；
- major：公开 contract 或安装方式不兼容。

Harness 兼容日期、adapter ID 和已知限制必须随 release 更新。不要使用“完全兼容所有未来版本”之类无法验证的表述。

## 打包

`package.json` 必须保留：

- 根包身份与 GitHub repository；
- `main` / `types` / `exports`；
- `dsh.bundle.patch`；
- `dsh.client`；
- `prepare`；
- 与当前 Harness 一致的 Node engine；
- 精确的 `files` 白名单。

执行：

```bash
npm run verify
npm pack --json --ignore-scripts
```

检查 tarball 只包含运行产物、manifest、许可证和公开文档，不包含测试日志、本机审查报告、依赖目录或工作区数据。

## GitHub 发布

1. 在功能分支完成改动。
2. 检查 `git diff` 和所有未跟踪文件。
3. 只暂存明确的发布文件，不使用笼统的全仓暂存。
4. 对公开仓库执行隐私扫描和历史检查。
5. 推送到非默认分支并通过 CI；首次正式版本再合并 `main`/打 tag。
6. Release notes 必须包含功能、兼容基准、安装方法、修复和已知限制。
7. 从 GitHub 地址在全新临时目录安装一次，证明 `prepare` 和根 manifest 可用。

## 发布完成标准

- 类型、lint、构建、测试、隐私、pack 全绿；
- Node 22.19 与 24 CI 全绿；
- 干净 checkout/Git 安装成功；
- profile 中能识别 bundle patch；
- Harness 重启后 Host/Client 均激活；
- UI 冒烟完成；
- README 与已知限制没有夸大成熟度；
- GitHub 公共树和历史没有私人信息。
