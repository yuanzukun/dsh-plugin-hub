/**
 * ESLint flat config（ESM）— dsh-branch-visualizer
 *
 * 基调：实用而非教条。
 *   - 基础层（eslint:recommended + 显式兜底）：杜绝明显错误（no-undef / no-var /
 *     no-constant-condition 等），风格问题一律不判；
 *   - TypeScript 层（typescript-eslint recommended，保守）：no-unused-vars 交由
 *     @typescript-eslint/no-unused-vars 接管，不启用 type-checked 重规则；
 *   - 收尾 eslint-config-prettier：关闭与 Prettier 冲突的格式规则，风格唯一权威是
 *     .prettierrc.json。
 *
 * @ts-nocheck 是 TypeScript 编译器指令，ESLint 本身不因此报错（默认容忍，无需处理）；
 * src/index.ts 与 client 文件保留 @ts-nocheck 期间照常 lint 语法与业务规则。
 */
import js from '@eslint/js'
import tseslint from 'typescript-eslint'
import prettier from 'eslint-config-prettier'
import globals from 'globals'

export default tseslint.config(
  {
    // 产物 / 依赖 / 构建缓存一律不 lint
    ignores: [
      'lib/**',
      'node_modules/**',
      '.buildtools/**',
      'dist/**',
      'coverage/**',
      '*.tsbuildinfo',
      '**/*.d.ts',
    ],
  },
  {
    name: 'dsh-brvis/language',
    languageOptions: {
      ecmaVersion: 2023,
      sourceType: 'module',
      // host 侧用 node: 模块，client 侧用浏览器 API；两者叠加即可覆盖全部源码
      globals: {
        ...globals.node,
        ...globals.browser,
      },
    },
  },
  // 显式 lint 范围：src 源码 + 本配置文件自身
  {
    name: 'dsh-brvis/files',
    files: ['src/**/*.{ts,tsx}', 'eslint.config.js'],
  },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  {
    name: 'dsh-brvis/rules',
    files: ['src/**/*.{ts,tsx}', 'eslint.config.js'],
    rules: {
      // —— 杜绝明显错误（eslint:recommended 已含，这里显式声明兜底）——
      // no-undef：tseslint 的 eslint-recommended 对 TS 文件默认关闭（交给 TS 编译器），
      // 这里显式重开为 error —— host/client 两侧 globals 已在 language 层声明
      'no-undef': 'error',
      'no-var': 'error',
      'no-constant-condition': 'error',
      // 基础 no-unused-vars 交由 TS 规则接管（兼容类型声明/接口用途，避免误报）
      'no-unused-vars': 'off',
      // TS 保守：仅未使用变量/参数报错；下划线前缀视为有意忽略
      '@typescript-eslint/no-unused-vars': [
        'error',
        { argsIgnorePattern: '^_', varsIgnorePattern: '^_', caughtErrors: 'none' },
      ],
      // 项目明确保留 @ts-nocheck（src/index.ts 及并行清理前的 client 文件），
      // 不因 @ts-nocheck 存在而报错；ts-expect-error/ts-ignore 要求带说明
      '@typescript-eslint/ban-ts-comment': [
        'error',
        {
          'ts-expect-error': 'allow-with-description',
          'ts-ignore': 'allow-with-description',
          'ts-nocheck': false,
          minimumDescriptionLength: 3,
        },
      ],
    },
  },
  // 最后收尾：关闭与 Prettier 冲突的格式规则
  prettier,
)
