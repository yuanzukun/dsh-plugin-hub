import { spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, rmSync, copyFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const outputDir = resolve(root, 'lib')
const require = createRequire(import.meta.url)

if (dirname(outputDir) !== root) throw new Error('Refusing to clean an output path outside the package root')

function packageRoot(specifier) {
  let cursor = dirname(require.resolve(specifier))
  while (cursor !== dirname(cursor)) {
    const manifestPath = join(cursor, 'package.json')
    if (existsSync(manifestPath)) {
      const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
      if (manifest.name === specifier) return { root: cursor, manifest }
    }
    cursor = dirname(cursor)
  }
  throw new Error(`Cannot locate package root for ${specifier}`)
}

function runNode(script, args, label) {
  const result = spawnSync(process.execPath, [script, ...args], {
    cwd: root,
    stdio: 'inherit',
    env: { ...process.env, NODE_ENV: process.env.NODE_ENV || 'production' },
  })
  if (result.error) throw result.error
  if (result.status !== 0) throw new Error(`${label} failed with exit code ${result.status}`)
}

rmSync(outputDir, { recursive: true, force: true })

const typescript = packageRoot('typescript')
runNode(join(typescript.root, typescript.manifest.bin.tsc), ['-p', 'tsconfig.json'], 'Host build')

const tsdown = packageRoot('tsdown')
const tsdownBin = typeof tsdown.manifest.bin === 'string' ? tsdown.manifest.bin : tsdown.manifest.bin.tsdown
runNode(join(tsdown.root, tsdownBin), [], 'Client build')

const clientTypesDir = join(outputDir, 'types', 'client')
mkdirSync(clientTypesDir, { recursive: true })
copyFileSync(join(root, 'src', 'types', 'client.d.ts'), join(clientTypesDir, 'index.d.ts'))

for (const artifact of ['lib/index.js', 'lib/client.js', 'lib/types/index.d.ts', 'lib/types/client/index.d.ts']) {
  if (!existsSync(join(root, artifact))) throw new Error(`Missing build artifact: ${artifact}`)
}

console.log('Build complete: host, client bundle, and declarations are ready.')
