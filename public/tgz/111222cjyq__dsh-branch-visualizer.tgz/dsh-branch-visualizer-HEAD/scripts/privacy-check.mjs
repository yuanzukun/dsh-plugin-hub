import { readdirSync, readFileSync, statSync } from 'node:fs'
import { extname, join, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(fileURLToPath(new URL('..', import.meta.url)))
const ignoredDirectories = new Set(['.git', '.bundle', 'node_modules', 'lib', 'coverage', 'logs'])
const ignoredFiles = new Set(['package-lock.json'])
const ignoredNamePatterns = [/审查报告.*\.md$/u, /修改指南.*\.md$/u]
const textExtensions = new Set(['.cjs', '.css', '.html', '.js', '.json', '.jsx', '.md', '.mjs', '.ts', '.tsx', '.txt', '.yml', '.yaml'])
const checks = [
  ['Windows user profile path', /[A-Za-z]:[\\/]Users[\\/][^\\/\s]+/i],
  ['macOS user profile path', /\/Users\/[^/\s]+/],
  ['Linux user profile path', /\/home\/[^/\s]+/],
  ['private key material', /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/],
  ['common API token assignment', /(?:api[_-]?key|access[_-]?token|secret)\s*[:=]\s*["'][^"']{12,}["']/i],
]

const findings = []

function visit(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    if (entry.isDirectory() && ignoredDirectories.has(entry.name)) continue
    const absolute = join(directory, entry.name)
    if (entry.isDirectory()) {
      visit(absolute)
      continue
    }
    if (!entry.isFile() || ignoredFiles.has(entry.name) || ignoredNamePatterns.some((pattern) => pattern.test(entry.name)) || !textExtensions.has(extname(entry.name).toLowerCase())) continue
    if (statSync(absolute).size > 2 * 1024 * 1024) continue
    const content = readFileSync(absolute, 'utf8')
    for (const [label, pattern] of checks) {
      if (pattern.test(content)) findings.push(`${relative(root, absolute)}: ${label}`)
    }
  }
}

visit(root)

if (findings.length) {
  console.error('Privacy check failed:')
  for (const finding of findings) console.error(`- ${finding}`)
  process.exit(1)
}

console.log('Privacy check passed: no local profile paths, private keys, or obvious embedded tokens found.')
