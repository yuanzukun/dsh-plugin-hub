# Security Policy

## Supported version

安全修复只针对当前主分支和最新发布版本。该插件与实验版 DeepSeek Harness 绑定，旧版本不会无限期维护。

## 数据处理

插件不发送遥测或第三方网络请求。它在本地 Harness 进程中读取会话元数据，并在用户明确操作时调用改名或归档能力。兼容诊断不包含工作区路径、会话 ID、标题或消息内容。

## HTTP 威胁模型

`/brvis/api` 是 Harness 同源本地路由，使用以下保护：

- 仅接受 `POST`；
- 仅接受 `application/json`；
- 要求 `X-Brvis-Request: 1`；
- 拒绝 `Sec-Fetch-Site: cross-site`；
- Origin 存在时必须与请求 Host 的 HTTP/HTTPS origin 一致；
- 请求体上限 64 KiB；
- 响应使用 `Cache-Control: no-store` 和 `X-Content-Type-Options: nosniff`。

这些措施用于缓解浏览器跨站请求，不用于抵御可直接连接本机端口并伪造 Host/header 的恶意进程。插件不实现用户身份、TLS 或远程访问控制。不要把 Harness webserver 直接暴露到不可信网络。

## 工作区授权边界

改名和归档前会重新读取会话 header，并用规范化工作区键核对归属。路径无法权威解析时，写操作拒绝执行。批量归档在任何输入 ID 非法、缺失或越界时整批拒绝授权。

## 报告问题

请通过仓库的 GitHub Security Advisory 私下报告潜在漏洞。报告中不要粘贴真实会话内容、工作区路径、访问令牌或其他个人数据；可提供最小化的复现结构和已去敏诊断结果。
