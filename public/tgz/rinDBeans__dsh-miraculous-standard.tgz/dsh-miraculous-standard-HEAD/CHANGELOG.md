# Changelog

All notable changes to Miraculous Standard are documented in this file.

## [2.0.0] - 2026-08-17

### 重大变更

- 预设从 `apex-standard` 更名为 **Miraculous Standard**
- GitHub 仓库保留 `dsh-` 前缀：`dsh-miraculous-standard`
- 文件不再保留 `apex` 命名：`preset/apex-bootstrap.mjs` → `preset/miraculous-bootstrap.mjs`，代码内不再残留 `apex` 引用
- 本地预设 ID/目录改为 `miraculous-standard`

### dsh rc7 适配

- 全局 dsh 升级到 `0.1.0-rc.7`
- subagent 配置从旧字段 `enableRunInBackground: false` 改为 rc7 的 `backgroundMode: one-shot`
- POSIX 持久 bash 增加 adaptive `shellPath`，兼容 NixOS 等无 `/bin/bash` 环境
- 受益于 rc7 官方持久 Bash 延迟修复与 max-token replay 修复

### 新增

- `preset/context-gate.mjs`：统一注入门；未晋升时默认剥离未知第三方注入，只保留用户消息与用户技能手势
- `residentTools` 配置项：可自定义 Pro / Flash resident 模式的常驻工具集
- `includeSubagents` 默认开启：子代理首请求也走锚定阶段
- `instruction-hint.mjs` 重写：
  - 改为中性 / 建议式措辞，避免“read first and follow them”把锚定轨迹打回 `let me`
  - 支持 cwd → 项目根全链探测 AGENTS.md / CLAUDE.md
  - 增加 durable 去重，防止 resume/reload 后重复注入
- `custom-bash.mjs` 增强：
  - Git Bash 路径 `/e/foo` → `E:\foo` 归一化
  - workdir ENOENT 时回退 session cwd
  - 更好的 Git for Windows 安装位置推断

### 文档与工程化

- README 重构：标题改为 **Miraculous Standard**，新增“独特性”和“主要作用”章节，并重写安装、配置、设计原理、测试、已知限制
- `preset.yml` / `package.json` / `index.js` / `cordis.patch.yml` / `NOTICE` 全部同步为新名称与版本
- 测试新增 context-gate 与 durable hint 覆盖

### 兼容性说明

- 推荐 dsh `0.1.0-rc.7`（rc.5 / rc.6 可运行，但不保证全部行为）
- Windows 仍使用 `custom-bash`：rc7 的 node-pty 升级不改变 Windows process inspector 缺失问题
