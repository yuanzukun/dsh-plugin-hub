/**
 * dsh-prompt-enhancer — browser half (v3).
 *
 * - Icon-only button next to the send button; native tooltip: 提示词增强.
 * - Button is disabled while the composer is empty or a request is running.
 * - Clicking shows an immediate buffering modal, then a comparison modal:
 *   增强前 (top) / 增强后 (bottom) with 采用 / 拒绝.
 * - Document-level pointer/click delegation + polling keep the button
 *   responsive across React re-renders and new conversations.
 *
 * Optional overrides (set before the plugin loads):
 *   window.__dshPromptEnhancer = {
 *     composerSelector: "...",
 *     inputSelector: "...",
 *     sendButtonSelector: "...",
 *   };
 */
window.__ModuleLoader__.load({
  id: "dsh-prompt-enhancer",
  factory: () => {
    "use strict";
    var module = { exports: {} };
    var exports = module.exports;

    var CONFIG = window.__dshPromptEnhancer || {};
    var COMPOSER_SELECTOR = CONFIG.composerSelector || '[data-slot="conversation.composer.bar"]';
    var INPUT_SELECTORS = CONFIG.inputSelector
      ? [CONFIG.inputSelector]
      : ["textarea", '[contenteditable="true"]', '[role="textbox"]', 'input[type="text"]'];
    var SEND_BUTTON_SELECTOR = CONFIG.sendButtonSelector || "";

    var BUTTON_ID = "__dsh_prompt_enhance_btn__";
    var PANEL_ID = "__dsh_prompt_enhance_panel__";
    var CSS_TAG = "dsh-prompt-enhancer/main.css";
    var API_PATH = "/api/dsh-prompt-enhancer/enhance";

    var state = {
      original: "",
      optimized: "",
      input: null,
      bar: null,
      busy: false,
      lastPointerTs: 0,
      controller: null,
      cancelled: false,
    };

    // ── CSS ──────────────────────────────────────────────────────────────────
    var CSS = [
      "#" + BUTTON_ID + "{display:inline-flex;flex:none;align-items:center;justify-content:center;width:32px;height:32px;",
      "margin:0;padding:0;align-self:center;position:relative;z-index:5;border:1px solid var(--dsw-alias-border-l2,rgba(255,255,255,.14));",
      "border-radius:10px;background:var(--dsw-alias-bg-layer-3,rgba(255,255,255,.04));",
      "color:var(--dsw-alias-label-primary,#e6ecff);cursor:pointer;",
      "transition:border-color .12s,background .12s,color .12s,opacity .12s}",
      "#" + BUTTON_ID + ":hover:not(:disabled){border-color:var(--dsw-alias-state-business-primary,#4d6bfe);",
      "background:var(--dsw-alias-interactive-bg-hover,rgba(255,255,255,.08));color:var(--dsw-alias-label-primary,#eef2ff)}",
      "#" + BUTTON_ID + ":disabled{opacity:.38;cursor:not-allowed}",
      "#" + BUTTON_ID + ".dsh-pe-busy{color:var(--dsw-alias-state-business-primary,#7d97ff)}",
      "@keyframes dsh-pe-spin{to{transform:rotate(360deg)}}",
      "#" + BUTTON_ID + " .dsh-pe-spin{animation:dsh-pe-spin .9s linear infinite}",
      "#" + PANEL_ID + "{position:fixed;inset:0;z-index:2147482990;display:flex;align-items:center;justify-content:center;",
      "padding:16px;box-sizing:border-box;background:rgba(3,7,18,.55);backdrop-filter:blur(4px);",
      "-webkit-backdrop-filter:blur(4px);font-family:var(--dsw-font-family,\"Segoe UI\",\"Microsoft YaHei\",system-ui,sans-serif)}",
      "#" + PANEL_ID + "[hidden]{display:none!important}",
      "#" + PANEL_ID + " .dsh-pe-card{display:flex;flex-direction:column;width:min(760px,100%);max-height:82vh;",
      "box-sizing:border-box;padding:14px;border:1px solid var(--dsw-alias-border-l1,rgba(255,255,255,.12));",
      "border-radius:16px;background:var(--dsw-alias-bg-layer-2,#121a2e);color:var(--dsw-alias-label-primary,#e6ecff);",
      "box-shadow:0 18px 60px rgba(0,0,0,.55),0 2px 8px rgba(0,0,0,.35)}",
      "#" + PANEL_ID + " .dsh-pe-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;flex:none}",
      "#" + PANEL_ID + " .dsh-pe-title{font-size:13px;font-weight:600}",
      "#" + PANEL_ID + " .dsh-pe-close{border:none;background:transparent;color:var(--dsw-alias-label-tertiary,#93a5d8);",
      "font-size:14px;cursor:pointer;line-height:1;padding:4px 6px;border-radius:6px}",
      "#" + PANEL_ID + " .dsh-pe-close:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(255,255,255,.08))}",
      "#" + PANEL_ID + " .dsh-pe-body{display:flex;flex-direction:column;gap:12px;min-height:0;overflow:auto}",
      "#" + PANEL_ID + " .dsh-pe-section{display:flex;flex-direction:column;min-width:0}",
      "#" + PANEL_ID + " .dsh-pe-label{font-size:11px;color:var(--dsw-alias-label-tertiary,#8b9ac4);margin-bottom:5px}",
      "#" + PANEL_ID + " .dsh-pe-box{white-space:pre-wrap;overflow:auto;max-height:24vh;min-height:64px;padding:8px 10px;",
      "border:1px solid var(--dsw-alias-border-l2,rgba(255,255,255,.1));border-radius:10px;background:var(--dsw-alias-bg-layer-3,rgba(255,255,255,.03));",
      "font-size:12.5px;line-height:1.6;color:var(--dsw-alias-label-secondary,#b8c5ea)}",
      "#" + PANEL_ID + " .dsh-pe-box.dsh-pe-new{max-height:36vh;border-color:var(--dsw-alias-state-business-primary,#4d6bfe);",
      "color:var(--dsw-alias-label-primary,#eef2ff)}",
      "#" + PANEL_ID + " .dsh-pe-actions{display:flex;align-items:center;justify-content:flex-end;gap:8px;margin-top:12px;flex:none}",
      "#" + PANEL_ID + " .dsh-pe-btn{border:1px solid var(--dsw-alias-border-l2,rgba(255,255,255,.14));",
      "background:var(--dsw-alias-bg-layer-3,rgba(255,255,255,.04));color:var(--dsw-alias-label-primary,#e6ecff);",
      "border-radius:9px;padding:6px 14px;font:inherit;font-size:12.5px;cursor:pointer}",
      "#" + PANEL_ID + " .dsh-pe-btn:hover:not(:disabled){border-color:var(--dsw-alias-state-business-primary,#4d6bfe);background:rgba(255,255,255,.08)}",
      "#" + PANEL_ID + " .dsh-pe-btn:disabled{opacity:.5;cursor:default}",
      "#" + PANEL_ID + " .dsh-pe-accept{border-color:var(--dsw-alias-state-business-primary,#4d6bfe);",
      "background:var(--dsw-alias-state-business-primary,#4d6bfe);color:var(--dsw-alias-label-on-accent,#fff)}",
      "#" + PANEL_ID + " .dsh-pe-error{color:var(--dsw-alias-state-error-primary,#ff7a85);font-size:12px;white-space:pre-wrap;",
      "max-height:50vh;overflow:auto}",
      "#" + PANEL_ID + " .dsh-pe-loading{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;",
      "padding:34px 16px;color:var(--dsw-alias-label-secondary,#b8c5ea)}",
        "#" + PANEL_ID + " .dsh-pe-loading[hidden]{display:none!important}",
      "#" + PANEL_ID + " .dsh-pe-ring{width:38px;height:38px;border-radius:50%;box-sizing:border-box;",
      "border:3px solid rgba(125,151,255,.22);border-top-color:var(--dsw-alias-state-business-primary,#4d6bfe);",
      "animation:dsh-pe-spin .8s linear infinite}",
      "#" + PANEL_ID + " .dsh-pe-loading-text{font-size:12.5px;animation:dsh-pe-pulse 1.2s ease-in-out infinite}",
      "@keyframes dsh-pe-pulse{0%,100%{opacity:.45}50%{opacity:1}}",
    ].join("\n");

    var ICON_SVG =
      '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3z"></path>' +
      '<path d="M19 15l.7 1.8 1.8.7-1.8.7L19 21l-.7-1.8-1.8-.7 1.8-.7L19 15z"></path></svg>';
    var SPINNER_SVG =
      '<svg class="dsh-pe-spin" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">' +
      '<path d="M21 12a9 9 0 1 1-6.2-8.56"></path></svg>';

    // ── dom helpers ──────────────────────────────────────────────────────────
    function injectCss() {
      if (document.querySelector('style[data-plugin-css="' + CSS_TAG + '"]')) return;
      var tag = document.createElement("style");
      tag.dataset.plugin = "dsh-prompt-enhancer";
      tag.dataset.pluginCss = CSS_TAG;
      tag.textContent = CSS;
      document.head.appendChild(tag);
    }

    function isVisible(el) {
      if (!el || !el.isConnected) return false;
      var r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    }

    function computedDisplay(el) {
      if (!el || !el.isConnected) return "";
      try {
        return window.getComputedStyle(el).display || "";
      } catch (e) {
        return "";
      }
    }

    function firstBoxRect(el) {
      if (!el || !el.isConnected) return null;
      var r = el.getBoundingClientRect();
      if (r.width > 0 || r.height > 0) return r;
      if (computedDisplay(el) === "contents") {
        var children = el.children;
        for (var i = 0; i < children.length; i += 1) {
          var childRect = firstBoxRect(children[i]);
          if (childRect) return childRect;
        }
      }
      return null;
    }

    /**
     * DSH renders every slot outlet as a wrapper with `display: contents`,
     * which generates no box of its own (getBoundingClientRect() is 0×0).
     * Such a slot must still count as usable while one rendered descendant
     * has a box; otherwise the model-slot placement branch is unreachable
     * and the button falls back to the send-button heuristic.
     */
    function isSlotVisible(el) {
      if (!el || !el.isConnected) return false;
      var r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) return true;
      if (computedDisplay(el) !== "contents") return false;
      var descendants = el.querySelectorAll("*");
      for (var i = 0; i < descendants.length; i += 1) {
        var dr = descendants[i].getBoundingClientRect();
        if (dr.width > 0 && dr.height > 0) return true;
      }
      return false;
    }

    function composerBars() {
      var bars = [];
      try {
        bars = Array.prototype.slice.call(document.querySelectorAll(COMPOSER_SELECTOR));
      } catch (e) {
        bars = [];
      }
      bars = bars.filter(isVisible);
      if (bars.length === 0) {
        var ta =
          document.querySelector('[data-slot*="composer"] textarea') ||
          document.querySelector('[data-slot*="conversation"] textarea') ||
          document.querySelector('textarea[placeholder*="输入"], textarea[placeholder*="消息"], textarea[placeholder*="Message"], textarea[placeholder*="Ask"]');
        if (ta && isVisible(ta)) {
          var el = ta;
          while (el && el !== document.body) {
            el = el.parentElement;
            if (el && el.querySelectorAll("button").length > 0) {
              bars.push(el);
              break;
            }
          }
        }
      }
      return bars;
    }

    /** Bottom-most visible composer that has an input. */
    function pickComposerBar() {
      var bars = composerBars();
      if (bars.length === 0) return null;
      var withInput = bars.filter(function (bar) {
        return !!findInput(bar);
      });
      if (withInput.length > 0) bars = withInput;
      bars.sort(function (a, b) {
        return b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom;
      });
      return bars[0] || null;
    }

    function findInput(bar) {
      if (!bar) return null;
      for (var i = 0; i < INPUT_SELECTORS.length; i += 1) {
        var els;
        try {
          els = bar.querySelectorAll(INPUT_SELECTORS[i]);
        } catch (e) {
          continue;
        }
        for (var j = 0; j < els.length; j += 1) {
          if (isVisible(els[j])) return els[j];
        }
      }
      return null;
    }

    function allInputCandidates() {
      var list = [];
      try {
        list = Array.prototype.slice.call(document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]'));
      } catch (e) {
        list = [];
      }
      return list.filter(isVisible);
    }

    /** Current draft: prefer the active composer; fall back to any visible non-empty editor. */
    function currentDraftInfo() {
      var bar = pickComposerBar();
      var input = bar ? findInput(bar) : null;
      var text = input ? readDraft(input) : "";
      if (text.trim()) return { bar: bar, input: input, text: text };
      var candidates = allInputCandidates();
      for (var i = 0; i < candidates.length; i += 1) {
        var candidateText = readDraft(candidates[i]);
        if (candidateText.trim()) {
          return { bar: bar, input: candidates[i], text: candidateText };
        }
      }
      return { bar: bar, input: input, text: "" };
    }

    function labelOf(btn) {
      return [
        btn.getAttribute("aria-label") || "",
        btn.getAttribute("title") || "",
        btn.textContent || "",
      ].join(" ").toLowerCase();
    }

    function findSendButton(bar) {
      if (SEND_BUTTON_SELECTOR) {
        var explicit;
        try {
          explicit = bar.querySelector(SEND_BUTTON_SELECTOR);
        } catch (e) {
          explicit = null;
        }
        if (explicit && explicit.id !== BUTTON_ID) return explicit;
      }
      var buttons = Array.prototype.slice.call(bar.querySelectorAll("button")).filter(function (btn) {
        return btn.id !== BUTTON_ID && isVisible(btn) && !btn.disabled;
      });
      if (buttons.length === 0) return null;
      var barRect = bar.getBoundingClientRect();
      var input = findInput(bar);
      var inputRect = input ? input.getBoundingClientRect() : null;
      var best = null;
      var bestScore = -Infinity;
      for (var i = 0; i < buttons.length; i += 1) {
        var btn = buttons[i];
        var rect = btn.getBoundingClientRect();
        var label = labelOf(btn);
        var score = 0;
        if (btn.type === "submit") score += 100;
        if (/发送|提交|send|submit|ask|生成|提问/i.test(label)) score += 80;
        if (rect.right >= barRect.right - 96) score += 40;
        if (inputRect && Math.abs(rect.bottom - inputRect.bottom) < 32) score += 20;
        score += i * 0.01;
        if (score > bestScore) {
          bestScore = score;
          best = btn;
        }
      }
      return best;
    }

    function readDraft(input) {
      if (!input) return "";
      if (input.tagName === "TEXTAREA" || input.tagName === "INPUT") {
        return input.value || "";
      }
      if (input.isContentEditable || input.getAttribute("contenteditable") === "true") {
        return input.innerText || input.textContent || "";
      }
      return input.value || input.textContent || "";
    }

    function writeDraft(input, text) {
      if (!input) return;
      if (input.tagName === "TEXTAREA" || input.tagName === "INPUT") {
        var proto = input.tagName === "TEXTAREA" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
        var desc = Object.getOwnPropertyDescriptor(proto, "value");
        if (desc && desc.set) desc.set.call(input, text);
        else input.value = text;
      } else if (input.isContentEditable || input.getAttribute("contenteditable") === "true") {
        input.focus();
        input.textContent = text;
      } else {
        try {
          input.value = text;
        } catch (e) {
          input.textContent = text;
        }
      }
      try {
        input.dispatchEvent(new Event("input", { bubbles: true }));
        input.dispatchEvent(new Event("change", { bubbles: true }));
      } catch (e) {
        /* ignore */
      }
    }

    // ── injected button ──────────────────────────────────────────────────────
    function syncButtonSize(btn, anchor) {
      if (!btn || !anchor) return;
      var r = firstBoxRect(anchor);
      var h = Math.max(28, Math.min(44, Math.round(r ? r.height : 32)));
      btn.style.height = h + "px";
      btn.style.width = h + "px";
    }

      function findModelSlot(bar) {
        try {
          var slot = null;
            try {
              slot = bar.querySelector('[data-slot="conversation.input.model"], [data-slot*="model"]');
            } catch (e) {
              slot = null;
            }
            if (slot) return slot;
            try {
              var globalSlot = document.querySelector('[data-slot="conversation.input.model"], [data-slot*="model"]');
                if (globalSlot && isSlotVisible(globalSlot)) return globalSlot;
                var modelButtons = document.querySelectorAll('button[aria-haspopup="menu"]');
                for (var bi = 0; bi < modelButtons.length; bi += 1) {
                  var mb = modelButtons[bi];
                  var label = ((mb.getAttribute('aria-label') || '') + ' ' + (mb.getAttribute('title') || '') + ' ' + (mb.textContent || '')).toLowerCase();
                  if (isVisible(mb) && /选择模型|select model|deepseek|模型/.test(label)) {
                    return mb.parentElement || mb;
                  }
                }
                return null;
            } catch (e2) {
              return null;
            }
        } catch (e) {
          return null;
        }
      }

    function ensureButton(bar) {
      if (!bar || !bar.isConnected) return null;
      var btn = document.getElementById(BUTTON_ID);
      if (!btn) {
        btn = document.createElement("button");
        btn.type = "button";
        btn.id = BUTTON_ID;
        btn.dataset.plugin = "dsh-prompt-enhancer";
        btn.setAttribute("aria-label", "提示词增强");
      }
        var visibleModelSlot = findModelSlot(bar);
        
        var canShow = !!(visibleModelSlot && visibleModelSlot.isConnected && isVisible(visibleModelSlot));
        btn.style.display = canShow ? "" : "none";
        if (!canShow) {
          refreshButtonState(btn, bar);
          return btn;
        }
        if (visibleModelSlot.nextElementSibling !== btn) visibleModelSlot.after(btn);
        syncButtonSize(btn, visibleModelSlot);
        refreshButtonState(btn, bar);
        return btn;
      var modelSlot = findModelSlot(bar);
        if (modelSlot && modelSlot.isConnected && isVisible(modelSlot)) {
          if (modelSlot.nextElementSibling !== btn) modelSlot.after(btn);
          syncButtonSize(btn, modelSlot);
        } else if (!bar.contains(btn)) {
        var anchor = findSendButton(bar);
        if (anchor && anchor.isConnected) {
          anchor.before(btn);
          syncButtonSize(btn, anchor);
        } else {
          bar.appendChild(btn);
        }
      } else {
        var send = findSendButton(bar);
        if (send && send.isConnected) {
          syncButtonSize(btn, send);
          if (send.previousElementSibling !== btn) send.before(btn);
        }
      }
      refreshButtonState(btn, bar);
      return btn;
    }

      function isAnyMenuOpen() {
        var nodes = document.querySelectorAll('[role="menu"], [role="dialog"], [role="listbox"]');
        for (var i = 0; i < nodes.length; i += 1) {
          if (isVisible(nodes[i])) return true;
        }
        return false;
      }

      function ensureButtonV2(bar) {
        var btn = document.getElementById(BUTTON_ID);
        if (!btn) {
          btn = document.createElement("button");
          btn.type = "button";
          btn.id = BUTTON_ID;
          btn.dataset.plugin = "dsh-prompt-enhancer";
          btn.setAttribute("aria-label", "提示词增强");
        }
        var modelSlot = findModelSlot(bar);
          var menuOpen = isAnyMenuOpen();
          var send = bar ? findSendButton(bar) : null;
        var canShow = !menuOpen && ((modelSlot && modelSlot.isConnected && isSlotVisible(modelSlot)) || (send && send.isConnected));
        btn.style.display = canShow ? "" : "none";
        if (!canShow) {
          refreshButtonState(btn, bar);
          return btn;
        }
          if (modelSlot && modelSlot.isConnected && isSlotVisible(modelSlot)) {
            if (modelSlot.nextElementSibling !== btn) modelSlot.after(btn);
            syncButtonSize(btn, modelSlot);
          } else if (send && send.isConnected) {
            if (send.previousElementSibling !== btn) send.before(btn);
            syncButtonSize(btn, send);
          } else if (bar && bar.isConnected && !bar.contains(btn)) {
            bar.appendChild(btn);
          }
          refreshButtonState(btn, bar);
          return btn;
        if (modelSlot.nextElementSibling !== btn) modelSlot.after(btn);
        syncButtonSize(btn, modelSlot);
        var anchorBar = (bar && bar.isConnected) ? bar : ((modelSlot.closest && modelSlot.closest(COMPOSER_SELECTOR)) || modelSlot.parentElement);
        refreshButtonState(btn, anchorBar);
        return btn;
      }

    function refreshButtonState(btn, bar) {
      if (!btn || btn instanceof Event) btn = document.getElementById(BUTTON_ID);
      if (!btn) return;
      var info = currentDraftInfo();
      bar = bar || info.bar || (btn.closest ? btn.closest(COMPOSER_SELECTOR) : null) || btn.parentElement;
      btn.disabled = state.busy || !info.text.trim();
      btn.title = state.busy ? "提示词增强中…" : info.text.trim() ? "提示词增强" : "提示词增强（请先输入内容）";
      btn.setAttribute("aria-label", btn.title);
      btn.innerHTML = state.busy ? SPINNER_SVG : ICON_SVG;
      if (state.busy) btn.classList.add("dsh-pe-busy");
      else btn.classList.remove("dsh-pe-busy");
    }

    // ── centered modal ───────────────────────────────────────────────────────
    function panel() {
      var el = document.getElementById(PANEL_ID);
      if (el) return el;
      el = document.createElement("div");
      el.id = PANEL_ID;
      el.hidden = true;
      el.style.cssText =
        "position:fixed;inset:0;z-index:2147482990;display:none;align-items:center;justify-content:center;padding:16px;box-sizing:border-box;background:rgba(3,7,18,.55);font-family:var(--dsw-font-family,\"Segoe UI\",\"Microsoft YaHei\",system-ui,sans-serif)";
      el.innerHTML =
        '<div class="dsh-pe-card">' +
        '<div class="dsh-pe-head">' +
        '<span class="dsh-pe-title">提示词增强</span>' +
        '<button type="button" class="dsh-pe-close" title="关闭（Esc）" data-act="reject">✕</button>' +
        "</div>" +
        '<div class="dsh-pe-loading" hidden>' +
        '<div class="dsh-pe-ring"></div>' +
        '<div class="dsh-pe-loading-text">正在优化提示词，请稍候…</div>' +
        "</div>" +
        '<div class="dsh-pe-body">' +
        '<div class="dsh-pe-section">' +
        '<div class="dsh-pe-label">增强前</div>' +
        '<div class="dsh-pe-box dsh-pe-original"></div>' +
        "</div>" +
        '<div class="dsh-pe-section">' +
        '<div class="dsh-pe-label">增强后</div>' +
        '<div class="dsh-pe-box dsh-pe-new"></div>' +
        "</div>" +
        '<div class="dsh-pe-error" hidden></div>' +
        "</div>" +
        '<div class="dsh-pe-actions">' +
        '<button type="button" class="dsh-pe-btn" data-act="reject">拒绝</button>' +
        '<button type="button" class="dsh-pe-btn dsh-pe-accept" data-act="accept">采用</button>' +
        "</div>" +
        "</div>";
      var card = el.querySelector(".dsh-pe-card");
      if (card) {
        card.style.cssText =
          "display:flex;flex-direction:column;width:min(760px,100%);max-height:82vh;box-sizing:border-box;padding:14px;border:1px solid rgba(255,255,255,.12);border-radius:16px;background:#121a2e;color:#e6ecff;box-shadow:0 18px 60px rgba(0,0,0,.55)";
      }
      el.querySelector('[data-act="accept"]').addEventListener("click", onAccept);
      el.querySelectorAll('[data-act="reject"]').forEach(function (b) {
        b.addEventListener("click", onReject);
      });
      document.body.appendChild(el);
      return el;
    }

    function showLoading() {
      var el = panel();
      var loading = el.querySelector(".dsh-pe-loading");
        loading.hidden = false;
        loading.style.display = "flex";
      el.querySelector(".dsh-pe-body").style.display = "none";
      el.querySelector(".dsh-pe-actions").style.display = "none";
      el.querySelector(".dsh-pe-error").hidden = true;
      el.hidden = false;
      el.style.display = "flex";
    }

    function showCompare(original, optimized) {
      var el = panel();
      el.querySelector(".dsh-pe-loading").hidden = true;
      el.querySelector(".dsh-pe-error").hidden = true;
      el.querySelector(".dsh-pe-body").style.display = "";
      el.querySelector(".dsh-pe-actions").style.display = "";
      el.querySelector(".dsh-pe-original").textContent = original;
      el.querySelector(".dsh-pe-new").textContent = optimized;
      el.hidden = false;
      el.style.display = "flex";
      window.setTimeout(function () {
        var accept = el.querySelector(".dsh-pe-accept");
        if (accept) accept.focus();
      }, 0);
    }

    function showPanelMessage(message) {
      var el = panel();
      el.querySelector(".dsh-pe-loading").hidden = true;
      el.querySelector(".dsh-pe-body").style.display = "none";
      el.querySelector(".dsh-pe-actions").style.display = "none";
      var err = el.querySelector(".dsh-pe-error");
      err.hidden = false;
      err.textContent = message || "未知错误";
      el.hidden = false;
      el.style.display = "flex";
      window.setTimeout(function () {
        var close = el.querySelector(".dsh-pe-close");
        if (close) close.focus();
      }, 0);
    }

    function showError(message) {
      showPanelMessage("增强失败：" + (message || "未知错误"));
    }

    function hidePanel() {
      var el = document.getElementById(PANEL_ID);
      if (el) {
        el.hidden = true;
        el.style.display = "none";
      }
      state.original = "";
      state.optimized = "";
      state.input = null;
      state.bar = null;
    }

    function currentInput() {
      if (state.input && state.input.isConnected && isVisible(state.input)) return state.input;
      var info = currentDraftInfo();
      return info.input;
    }

    function onAccept() {
        if (state.busy) return;
      var input = currentInput();
      if (input && state.optimized) {
        writeDraft(input, state.optimized);
        input.focus();
      }
      hidePanel();
      refreshButtonState();
    }

    function onReject() {
        if (state.busy) {
          state.cancelled = true;
          state.busy = false;
          if (state.controller) {
            try { state.controller.abort(); } catch (e) { /* ignore */ }
          }
          state.controller = null;
          hidePanel();
          refreshButtonState();
          return;
        }
      var input = currentInput();
      if (input && state.original) {
        writeDraft(input, state.original);
        input.focus();
      }
      hidePanel();
      refreshButtonState();
    }

    function onKeydown(e) {
      var el = document.getElementById(PANEL_ID);
      if (!el || el.hidden) return;
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        onReject();
      } else if (e.key === "Enter") {
          if (state.busy) return;
        e.preventDefault();
        e.stopPropagation();
        onAccept();
      }
    }

    // ── reliable button activation ──────────────────────────────────────────
    function eventTargetsButton(e) {
      var node = e.target;
      while (node && node !== document) {
        if (node.id === BUTTON_ID) return true;
        node = node.parentElement;
      }
      return false;
    }

    function onDocumentPointerDown(e) {
        var targetBtn = document.getElementById(BUTTON_ID);
        if (!targetBtn || targetBtn.disabled) return;
      if (!eventTargetsButton(e)) return;
      state.lastPointerTs = Date.now();
      e.stopPropagation();
      onEnhanceClick();
    }

    function onDocumentClick(e) {
        var targetBtn = document.getElementById(BUTTON_ID);
        if (!targetBtn || targetBtn.disabled) return;
      if (!eventTargetsButton(e)) return;
      e.stopPropagation();
      // pointerdown already handled this activation; avoid a duplicate request.
      if (Date.now() - state.lastPointerTs < 700) return;
      onEnhanceClick();
    }

    // ── enhancement flow ────────────────────────────────────────────────────
    function onEnhanceClick() {
      if (state.busy) return;
      var info = currentDraftInfo();
      var draft = info.text || "";
      if (!draft.trim()) {
        refreshButtonState();
        return;
      }

      state.original = draft;
      state.optimized = "";
      state.input = info.input;
      state.bar = info.bar;
      state.busy = true;
      refreshButtonState();
      showLoading();

      var controller = new AbortController();
        state.controller = controller;
        state.cancelled = false;
      var timer = setTimeout(function () {
        controller.abort();
      }, 185000);

      fetch(API_PATH, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ text: draft }),
        signal: controller.signal,
      })
        .then(function (res) {
          return res.json().catch(function () {
            return { ok: false, error: "HTTP " + res.status };
          });
        })
        .then(function (data) {
          clearTimeout(timer);
            if (state.cancelled) { state.cancelled = false; state.controller = null; return; }
          state.busy = false;
          refreshButtonState();
          if (!data || data.ok !== true || typeof data.text !== "string" || !data.text.trim()) {
            showError((data && data.error) || "服务端返回了空结果");
            return;
          }
          state.optimized = data.text;
          var suffix = data.truncated ? "\n\n（服务端按 maxTokens 截断）" : "";
          showCompare(state.original, state.optimized + suffix);
        })
        .catch(function (err) {
          clearTimeout(timer);
            if (state.cancelled) { state.cancelled = false; state.controller = null; return; }
          state.busy = false;
          refreshButtonState();
          showError(err && err.name === "AbortError" ? "请求超时" : (err && err.message) || String(err));
        });
    }

    // ── keep-alive ───────────────────────────────────────────────────────────
    function scan() {
      var bar = pickComposerBar();
      if (bar) ensureButtonV2(bar);
      else ensureButtonV2(null);
    }

    function apply(ctx) {
      injectCss();
      var scheduled = false;
      var mo;
      var schedule = function () {
        if (scheduled) return;
        scheduled = true;
        window.requestAnimationFrame(function () {
          scheduled = false;
          scan();
        });
      };
      scan();
      mo = new MutationObserver(schedule);
      mo.observe(document.body, { childList: true, subtree: true });
      document.addEventListener("input", refreshButtonState, true);
      document.addEventListener("focusin", refreshButtonState, true);
      document.addEventListener("keydown", onKeydown, true);
      document.addEventListener("pointerdown", onDocumentPointerDown, true);
      document.addEventListener("click", onDocumentClick, true);
      var poll = window.setInterval(function () {
        scan();
      }, 600);
      ctx.effect(function () {
        return function () {
          window.clearInterval(poll);
          if (mo) mo.disconnect();
          document.removeEventListener("input", refreshButtonState, true);
          document.removeEventListener("focusin", refreshButtonState, true);
          document.removeEventListener("keydown", onKeydown, true);
          document.removeEventListener("pointerdown", onDocumentPointerDown, true);
          document.removeEventListener("click", onDocumentClick, true);
          var btn = document.getElementById(BUTTON_ID);
          if (btn) btn.remove();
          var p = document.getElementById(PANEL_ID);
          if (p) p.remove();
          var tag = document.querySelector('style[data-plugin-css="' + CSS_TAG + '"]');
          if (tag) tag.remove();
        };
      });
    }

    exports.apply = apply;
    return module.exports;
  },
});
