$ErrorActionPreference = "Stop"
$root = $PSScriptRoot

$patterns = @(
  '(?i)sk-[A-Za-z0-9]{20,}',
  '(?i)ghp_[A-Za-z0-9]{20,}',
  '(?i)AKIA[0-9A-Z]{16}',
  '-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----',
  '(?i)(api[_-]?key|apikey)\s*[:=]\s*["''][A-Za-z0-9_\-]{16,}["'']',
  '(?i)(password|passwd)\s*[:=]\s*["''][^"'']+["'']',
  '(?i)(secret|token)\s*[:=]\s*["''][A-Za-z0-9_\-]{16,}["'']'
)

$files = Get-ChildItem -Path $root -Recurse -File |
  Where-Object {
    $_.FullName -notmatch '\\.git\\' -and
    $_.FullName -notmatch '\\node_modules\\' -and
    $_.Extension -in @('.js', '.json', '.md', '.cmd', '.ps1', '.yml', '.yaml')
  }

$found = @()
foreach ($file in $files) {
  $text = Get-Content -Path $file.FullName -Raw
  foreach ($pattern in $patterns) {
    if ($text -match $pattern) {
      $found += "$($file.FullName): $pattern"
    }
  }
}

if ($found.Count -gt 0) {
  Write-Output "SECRET SCAN FAILED"
  $found | ForEach-Object { Write-Output $_ }
  exit 1
}

Write-Output "SECRET SCAN OK"
exit 0
