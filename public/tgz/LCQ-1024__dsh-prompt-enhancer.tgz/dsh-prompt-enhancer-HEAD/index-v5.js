/**
 * dsh-prompt-enhancer — server half (v5).
 *
 * Intent-aware rewrite instruction. The model is told to first classify the
 * user's real intent and then pick the matching structure, instead of copying
 * one fixed template. It must never answer the user's question.
 *
 * Fast path: reasoningEffort "off", maxTokens 4096.
 *
 * POST /api/dsh-prompt-enhancer/enhance
 * body: { "text": "<draft from the composer>" }
 * reply: { "ok": true, "text": "<optimized prompt>" } | { "ok": false, "error": "..." }
 */
import { readFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import z from "@deepseek-ai/schemastery";
import { BlockAssembler, createUserMessage, deepFreeze } from "@deepseek-ai/dsh-llm";

const name = "dsh-prompt-enhancer";
const inject = ["llm", "webServer"];

/**
 * Internal rewrite instruction. The output is a prompt addressed to an agent.
 */
const DEFAULT_SYSTEM_PROMPT = [
  "你是一个意图重写器。你的任务是把用户随手输入的一段话，改写成一条可以直接交给 AI Agent 执行的高质量提示词。你永远不回答用户的问题本身。",
  "",
  "第一步，判断用户真实意图属于哪一类，并按对应方式组织，不要套用固定模板：",
  "- 排查/为什么类：说明运行环境与上下文 → 描述实际现象 → 说明预期行为 → 列出需要重点核查的方向 → 要求给出根本原因和可执行的修复步骤。",
  "- 实现/帮我做类：明确目标与交付物 → 技术栈与约束 → 执行步骤 → 验收标准 → 输出格式。",
  "- 解释/比较/方案类：界定话题范围与目标读者 → 明确需要覆盖的维度 → 要求给出依据、例子或对比。",
  "- 简单问答/闲聊类：尽量保留原意，只做必要澄清，不要过度膨胀。",
  "",
  "第二步，重写时遵守：",
  "1. 完整保留用户提供的事实：文件名、报错、环境、版本、约束、技术栈、URL、代码等；绝不编造。",
  "2. 把“弄一下 / 优化一下 / 帮我看看 / 为什么没反应”等模糊表达，替换成具体动作、对象和可验证的结果。",
  "3. 如果用户没提供关键背景，不要发明事实，可写成“结合项目代码/日志确认……”，让 Agent 自行核实。",
  "4. 如果一句话里包含多个问题，拆成编号子问题，让 Agent 逐项回答。",
  "5. 使用与用户输入相同的语言。",
  "6. 长度与复杂度匹配：简单问题保持简短；复杂问题可以结构化，但不堆砌空话。",
  "7. 如果原话已经是一条完整清晰的提示词，只做最小必要改写，不要为改而改。",
  "",
  "示例：",
  "用户输入：为什么我一发送图片，界面闪一下就没反应了，不是已经接了视觉模型吗？",
  "输出：我正在使用一个接入了视觉模型的聊天应用。发送图片后界面会闪一下，但既没有回复也没有报错。请帮我排查：1）视觉模型是否真的被调用，请求里是否携带图片；2）图片消息的传递格式是否正确；3）当前模型是否支持图片输入，是否被静默拒绝；4）界面是否吞掉了异常。请结合配置和日志定位根本原因，并给出修复步骤。",
  "",
  "最终只输出重写后的提示词本身。不要解释、不要评价、不要加引号，也不要给整段输出套 Markdown 代码围栏。",
].join("\n");

const Config = z.object({
  /** LLM provider route. Empty = auto-detect from settings.yaml / first adapter. */
  provider: z.string().default(""),
  /** Model id. Empty = auto-detect from settings.yaml, fallback "deepseek-chat". */
  model: z.string().default(""),
  /** System prompt used for the enhancement call. */
  systemPrompt: z.string().default(DEFAULT_SYSTEM_PROMPT),
  /** Reasoning effort. "off" = fast and cheap; "high"/"max" if quality matters more than speed. Empty = provider default. */
  reasoningEffort: z.string().default("off"),
  /** Maximum output tokens for one enhancement call. */
  maxTokens: z.number().min(128).max(32768).default(4096),
  /** Per-request timeout in milliseconds. */
  timeoutMs: z.number().min(1000).max(600000).default(120000),
  /** Largest draft accepted by the HTTP endpoint, in characters. */
  maxInputChars: z.number().min(1).max(1000000).default(200000),
});

const ROUTE = "/api/dsh-prompt-enhancer/enhance";
const MAX_BODY_BYTES = 2 * 1024 * 1024;

/** Defensive merge: keep working even if the loader passes an incomplete config. */
function effectiveConfig(config) {
  return {
    provider: "",
    model: "",
    systemPrompt: DEFAULT_SYSTEM_PROMPT,
    reasoningEffort: "off",
    maxTokens: 4096,
    timeoutMs: 120000,
    maxInputChars: 200000,
    ...(config || {}),
  };
}

function dshHome() {
  return process.env.DSH_HOME || path.join(os.homedir(), ".dsh");
}

/** Best-effort read of `agent-default-model` from the DSH settings.yaml. */
function readAgentDefaultRoute() {
  const file = path.join(dshHome(), "settings.yaml");
  let text;
  try {
    text = readFileSync(file, "utf8");
  } catch {
    return {};
  }
  const out = {};
  let section = "";
  for (const line of text.split(/\r?\n/)) {
    if (!line.startsWith(" ") && !line.startsWith("\t")) {
      section = line.trim().replace(/:$/, "").trim();
      continue;
    }
    if (section !== "agent-default-model") continue;
    const provider = line.match(/^\s+provider:\s*["']?([^"'#\n]+)/);
    if (provider) out.provider = provider[1].trim();
    const model = line.match(/^\s+model:\s*["']?([^"'#\n]+)/);
    if (model) out.model = model[1].trim();
  }
  return out;
}

function firstProvider(ctx) {
  try {
    return ctx.llm.adapters?.keys?.().next?.().value ?? "";
  } catch {
    return "";
  }
}

function resolveRoute(ctx, config) {
  const auto = readAgentDefaultRoute();
  const provider = String(config.provider || "").trim() || auto.provider || firstProvider(ctx) || "deepseek-official";
  const model = String(config.model || "").trim() || auto.model || "deepseek-chat";
  if (!provider || !model) {
    throw new Error("dsh-prompt-enhancer: unable to resolve provider/model; configure provider and model in the plugin patch row");
  }
  return { provider, model };
}

/** Remove an occasional ```...``` wrapper or "优化后的提示词：" prefix. */
function stripWrapper(text) {
  let out = String(text || "").trim();
  const fenced = out.match(/^```[a-zA-Z]*[\s\S]*?```$/);
  if (fenced) {
    out = out.replace(/^```[a-zA-Z]*\s*/, "").replace(/\s*```$/, "").trim();
  }
  out = out.replace(/^(?:优化(?:后)?(?:的)?(?:提示词|提示|prompt)[:：]\s*)+/i, "");
  return out.trim();
}

async function enhancePrompt(ctx, config, draft) {
  const route = resolveRoute(ctx, config);
  const messages = [
    createUserMessage({
      content: [{ type: "text", text: draft }],
      source: { kind: "plugin", plugin: name },
    }),
  ];
  const options = deepFreeze({
    provider: route.provider,
    model: route.model,
    messages,
    system: config.systemPrompt || DEFAULT_SYSTEM_PROMPT,
    maxTokens: config.maxTokens,
    ...(config.reasoningEffort ? { reasoningEffort: config.reasoningEffort } : {}),
    purpose: "prompt-enhance",
    signal: AbortSignal.timeout(config.timeoutMs),
  });

  const assembler = new BlockAssembler();
  try {
    for await (const chunk of ctx.llm.stream(options)) {
      assembler.push(chunk);
    }
  } catch (error) {
    throw new Error("dsh-prompt-enhancer: LLM stream failed: " + ((error && error.message) || error));
  }

  const finish = assembler.finish;
  if (finish.kind === "error" || finish.kind === "aborted") {
    const message = finish.failure && finish.failure.message ? finish.failure.message : finish.kind;
    throw new Error("dsh-prompt-enhancer: LLM call failed: " + message);
  }

  const blocks = assembler.blocks();
  const text = stripWrapper(blocks.filter((block) => block.type === "text").map((block) => block.text).join(""));
  if (!text) throw new Error("dsh-prompt-enhancer: model returned no text");
  return { text, truncated: finish.kind === "max-tokens" };
}

function isLoopback(req) {
  const ra = req.socket && req.socket.remoteAddress;
  return ra === "127.0.0.1" || ra === "::1" || ra === "::ffff:127.0.0.1";
}

function sendJson(res, status, body) {
  const data = Buffer.from(JSON.stringify(body), "utf8");
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "content-length": String(data.length),
  });
  res.end(data);
}

async function readJsonBody(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) throw new Error("request body too large");
    chunks.push(chunk);
  }
  if (chunks.length === 0) throw new Error("empty request body");
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw new Error("invalid JSON body");
  }
}

async function handleEnhanceRoute(ctx, config, req, res) {
  if (req.method !== "POST") {
    res.writeHead(405, { allow: "POST" });
    res.end();
    return;
  }
  if (!isLoopback(req)) {
    sendJson(res, 403, { ok: false, error: "loopback requests only" });
    return;
  }
  try {
    const body = await readJsonBody(req);
    const draft = typeof body?.text === "string" ? body.text : "";
    if (!draft.trim()) {
      sendJson(res, 400, { ok: false, error: "text is empty" });
      return;
    }
    if (draft.length > config.maxInputChars) {
      sendJson(res, 400, { ok: false, error: `text exceeds maxInputChars (${config.maxInputChars})` });
      return;
    }
    const result = await enhancePrompt(ctx, config, draft);
    sendJson(res, 200, { ok: true, ...result });
  } catch (error) {
    ctx.logger.warn(`[dsh-prompt-enhancer] enhance failed: ${(error && error.message) || error}`);
    sendJson(res, 500, { ok: false, error: (error && error.message) || String(error) });
  }
}

function apply(ctx, config) {
  const cfg = effectiveConfig(config);
  ctx.logger.info(`[dsh-prompt-enhancer] registering route ${ROUTE}`);
  const dispose = ctx.webServer.register({
    kind: "exact",
    path: ROUTE,
    handler: (req, res) => handleEnhanceRoute(ctx, cfg, req, res),
  });
  return () => dispose();
}

export { Config, DEFAULT_SYSTEM_PROMPT, apply, inject, name };
