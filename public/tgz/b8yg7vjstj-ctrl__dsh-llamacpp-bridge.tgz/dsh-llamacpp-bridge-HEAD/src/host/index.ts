/**
 * llama.cpp Bridge —— host 端入口（cordis apply）。
 *
 * 0.2.x 装载契约（0.2.0-rc.2 与 0.2.1-rc.2 实测一致，务必保持）：
 *  - 入口命名空间导出 `name` / `inject` / `apply` / **`Config`**；
 *    cordis-plugin-loader 的 `unwrapExports` 无 default 时保留命名导出命名空间，
 *    `registry.plugin(ns, config)` 读 `ns.Config` 作为配置 schema。
 *  - `Config`（schemastery）的字段决定设置页可见性与热更新能力：
 *    只有 `.volatile()` 字段会出现在「设置 → llama.cpp」并可热改。
 *  - `apply(ctx, config)` 的第二个参数是 **resolveConfig 之后的值**：
 *    volatile 字段是 `{ get(): T }`，读要 `.get()`。
 *  - 用户保存设置时 loader 走 `_commitVolatile()`：**不重跑 apply**，而是
 *    把新值写进已持有的引用并发 `loader/volatile-update` 事件 → 我们监听该
 *    事件做热更新（重扫目录 / 换传输参数时停服）。
 *
 * P0 映射：
 *  ① 后端模型切换：模型目录 = model-store（modelsDir 全量），
 *     已加载模型 = LlamaServerManager 运行态，二者分离，不依赖启动脚本。
 *  ③ 自动启动：adapter.stream() → ensure() → 未运行则启动并等待就绪。
 *  ④ 热切换：ensure() 在“请求到达 OpenAI 端口前”执行卸载→加载。
 *  ⑤ 隔离：只拥有 `llamacpp` 路由与自有命名空间，不挂钩其他 provider。
 *  ⑥ 安装即用：安装后无需手改 YAML —— host 自动发现 llama.cpp 可执行文件与
 *     模型目录（~/llama.cpp 下 build/、build/bin/、build/bin/release/ 的
 *     llama-server / llama.exe / llama-server.exe，以及 PATH），空值时作为
 *     兜底默认；浏览器端设置页（settings.section）提供图形化引导，
 *     用户保存的值写入 user 层并永远优先。
 * P1：model-store 扫描 + mmproj 配对；目录变更自动重扫，设置页保存后热生效。
 * P2：autoContext 启发式（model-store.pickContextLength）。
 */

import type { Context } from '@deepseek-ai/cordis';
import { PROVIDER_ID } from '../shared.js';
import { LlamaCppAdapter } from './adapter.js';
import {
  BridgeCfg,
  BridgeConfig,
  Config,
  configurableProviderEntry,
  defaultConfig,
  normalizeStrategy,
} from './config.js';
import { bestExecutable, bestModelsDir, discoverEnvironmentSafe } from './discover.js';
import { LlamaServerManager } from './llama-server.js';
import { ModelStore, listProjectors } from './model-store.js';
import { makeTerminalRoutes, purposeLines } from './terminal-routes.js';
import type { DiscoveryReport } from './discover.js';

/** 插件入口（与 DSH 内置 host 包同形）。 */
export const name = 'dsh-llamacpp-bridge';
export const inject = ['llm', 'subprocess', 'webServer'];
export { Config };

/**
 * 从 resolveConfig 后的 config 读出桥接配置。
 * volatile 字段是 `{ get(): T }`；自动发现结果只在「字段为空」时兜底。
 */
function readBridgeCfg(raw: Record<string, unknown>, discovered: Partial<BridgeCfg>): BridgeCfg {
  const val = (key: string): unknown => {
    const v = raw[key];
    if (v && typeof v === 'object' && 'get' in v && typeof (v as { get: unknown }).get === 'function') {
      return (v as { get(): unknown }).get();
    }
    return v;
  };
  const num = (key: string, fallback: number): number => {
    const v = Number(val(key));
    return Number.isFinite(v) ? v : fallback;
  };
  const str = (key: string, fallback: string): string => {
    const v = val(key);
    return typeof v === 'string' ? v : fallback;
  };
  const bool = (key: string, fallback: boolean): boolean => {
    const v = val(key);
    return typeof v === 'boolean' ? v : fallback;
  };
  const dict = (key: string): Record<string, string> => {
    const v = val(key);
    if (!v || typeof v !== 'object' || Array.isArray(v)) return {};
    return { ...(v as Record<string, string>) };
  };
  const arr = (key: string): string[] => {
    const v = val(key);
    return Array.isArray(v) ? (v as unknown[]).filter((x): x is string => typeof x === 'string') : [];
  };

  const base = defaultConfig();
  const cfg: BridgeCfg = {
    displayName: str('displayName', base.displayName),
    // 空值 = 自动发现兜底（安装后零配置即可用）
    executable: str('executable', '') || discovered.executable || base.executable,
    modelsDir: str('modelsDir', '') || discovered.modelsDir || base.modelsDir,
    host: str('host', base.host),
    port: num('port', base.port),
    strategy: normalizeStrategy(str('strategy', base.strategy)),
    contextLength: num('contextLength', base.contextLength),
    autoContext: bool('autoContext', base.autoContext),
    gpuLayers: num('gpuLayers', base.gpuLayers),
    mmprojSuffix: str('mmprojSuffix', base.mmprojSuffix),
    mmprojOverrides: dict('mmprojOverrides'),
    additionalArgs: arr('additionalArgs'),
    startTimeoutMs: num('startTimeoutMs', base.startTimeoutMs),
    debug: bool('debug', base.debug),
  };
  return cfg;
}

/** 从 config 读出「自动发现结果」字段组（供设置页渲染候选）。 */
function readDiscovery(raw: Record<string, unknown>): DiscoveryReport {
  const group = raw['discovery'];
  const g =
    group && typeof group === 'object' && 'get' in group && typeof (group as { get: unknown }).get === 'function'
      ? ((group as { get(): unknown }).get() as Record<string, unknown> | undefined)
      : (group as Record<string, unknown> | undefined);
  const empty: DiscoveryReport = {
    executables: [],
    modelsDirs: [],
    models: [],
    projectors: [],
    updatedAt: '',
  };
  if (!g || typeof g !== 'object') return empty;
  const arr = (key: string): unknown[] => (Array.isArray(g[key]) ? (g[key] as unknown[]) : []);
  return {
    executables: arr('executables') as DiscoveryReport['executables'],
    modelsDirs: arr('modelsDirs') as DiscoveryReport['modelsDirs'],
    models: arr('models').filter((x): x is string => typeof x === 'string'),
    projectors: arr('projectors') as DiscoveryReport['projectors'],
    updatedAt: typeof g['updatedAt'] === 'string' ? (g['updatedAt'] as string) : '',
  };
}

/** 插件入口（与 DSH 内置 host 包同形；async：先做环境自动发现）。 */
export async function apply(ctx: Context, entryConfig?: Record<string, unknown>): Promise<void> {
  const log = (...a: unknown[]) => console.log('[llamacpp-bridge]', ...a);
  log('initializing');

  const raw = (entryConfig ?? {}) as Record<string, unknown>;

  // —— 环境自动发现：可执行文件 + 模型目录候选（只作兜底默认值）——
  const report = await discoverEnvironmentSafe(3000);
  const foundExe = bestExecutable(report);
  const foundModels = bestModelsDir(report);

  log(
    `detected ${report.executables.length} executable candidate(s), ` +
      `${report.modelsDirs.length} models dir candidate(s)`,
  );
  for (const exe of report.executables.slice(0, 5)) log(`  exe: ${exe.path}  [${exe.source}]`);
  for (const dir of report.modelsDirs.slice(0, 5)) log(`  models: ${dir.dir}  (${dir.ggufCount} gguf)`);

  const discovered: Partial<BridgeCfg> = {};
  if (foundExe) discovered.executable = foundExe;
  if (foundModels) discovered.modelsDir = foundModels;

  // 探测候选（只读路由 /api/llamacpp-bridge/discovery 的数据源）。
  // 不写回 config —— 0.2.x 里 host 无法注册第二个 settings 命名空间，
  // 而探测结果是运行期产物、不应持久化进用户配置。
  const discoveryReport = (): DiscoveryReport => ({
    executables: report.executables,
    modelsDirs: report.modelsDirs,
    models: store.models().map((m) => m.id),
    projectors: store
      .models()
      .filter((m) => m.mmproj)
      .map((m) => ({ file: m.mmproj as string, modelId: m.id })),
    updatedAt: new Date().toISOString(),
  });

  // 配置 = cordis Config 解析值（volatile → .get()），空值回落到自动发现。
  let cfg = readBridgeCfg(raw, discovered);
  const cfgNow = () => cfg;

  if (!cfg.executable) {
    log('未找到 llama-server/llama.exe：请在 DSH「设置 → llama.cpp」中图形化选择可执行文件');
  }
  if (!cfg.modelsDir) {
    log('未找到模型目录：请在 DSH「设置 → llama.cpp」中图形化选择模型目录（.gguf 所在文件夹）');
  }

  // —— 模型目录（P1 扫描 + mmproj + watch）——
  const store = new ModelStore({
    modelsDir: cfg.modelsDir || '.',
    mmprojSuffix: cfg.mmprojSuffix,
    mmprojOverrides: cfg.mmprojOverrides,
  });
  // 每次启动都全量重扫（并建立监听 + 兜底轮询），确保 models 文件夹的变动即时反映。
  void store
    .refresh()
    .then(async (m) => {
      log(`scanned ${m.length} model(s) from ${store.dir} (startup rescan)`);
      // 视觉投影文件（mmproj）配对情况：配上的与被排除的都明确打印，便于排查。
      const vision = m.filter((x) => x.mmproj);
      for (const v of vision) {
        log(`  vision: ${v.id}  ←  ${v.mmproj?.split('/').pop() ?? ''}`);
      }
      const projectors = await listProjectors(store.dir, cfg.mmprojSuffix);
      const used = new Set(vision.map((v) => v.mmproj?.split('/').pop()));
      const unmatched = projectors.filter((f) => !used.has(f));
      if (unmatched.length > 0) {
        log(
          `  unmatched mmproj: ${unmatched.join(', ')}` +
            '（可在 设置 → llama.cpp 手动绑定到某个模型）',
        );
      }
    });
  store.watch();

  // —— llama.cpp 进程管理器 ——
  const server = new LlamaServerManager({
    ctx,
    cfg: cfgNow,
    resolve: (id) => store.get(id),
  });

  /* ---------- 配置热更新（设置页保存即时生效） ----------
   * 0.2.x 的 loader 在「只有 volatile 字段变化」时不会重跑 apply，而是
   * updateVolatile 把新值写进我们已持有的引用，并发 `loader/volatile-update`。
   * 因此这里按事件重读配置（不是按 watch 回调）。 */
  const onVolatileUpdate = () => {
    const next = readBridgeCfg(raw, discovered);
    const prev = cfg;
    cfg = next;
    log(
      `settings updated: modelsDir=${next.modelsDir || '(auto)'} port=${next.port} ` +
        `strategy=${next.strategy}`,
    );
    const dirChanged = next.modelsDir !== prev.modelsDir || next.mmprojSuffix !== prev.mmprojSuffix;
    const overridesChanged =
      JSON.stringify(next.mmprojOverrides ?? {}) !== JSON.stringify(prev.mmprojOverrides ?? {});
    if (dirChanged || overridesChanged) {
      store.reconfigure({
        modelsDir: next.modelsDir,
        mmprojSuffix: next.mmprojSuffix,
        mmprojOverrides: next.mmprojOverrides,
      });
    } else {
      void store.refresh();
    }
    const transportChanged =
      next.port !== prev.port || next.host !== prev.host || next.executable !== prev.executable;
    if (transportChanged) {
      void server.stop().catch((e) => log('stop after transport change failed:', e));
    }
  };
  // `loader/volatile-update` 是 cordis-plugin-loader 在「仅 volatile 字段变化」时
  // 发出的事件（_commitVolatile），未在 Events 类型表中声明 → 这里用
  // 字符串中转，避免为一条事件把整个 ctx 降级成 any。
  (ctx.on as (key: string, cb: () => void) => void)('loader/volatile-update', onVolatileUpdate);

  // —— 注册 LlmAdapter（P0⑤：仅路由 llamacpp）——
  const llm = ctx.llm;
  const adapter = new LlamaCppAdapter({
    cfg: () => cfgNow(),
    models: () => store.models(),
    refreshModels: () => store.refreshIfStale(),
    ensure: (modelId) => server.ensure(modelId),
  });
  try {
    llm.registerAdapter([PROVIDER_ID], adapter);
    log(`registered provider route ${PROVIDER_ID}`);
  } catch (err) {
    // 典型冲突：用户在 llm-pi-ai settings 里也配了 llamacpp profile。
    log(
      `failed to register route ${PROVIDER_ID}: ${String(err)} ` +
        '(remove any "llamacpp" profile under llm-pi-ai settings, then reload)',
    );
  }
  try {
    llm.registerConfigurableProviders([configurableProviderEntry(name)]);
  } catch (err) {
    // 目录注册冲突可容忍：路由本身已注册。但不能静默——配置面看不到本 provider 时要能查。
    log('registerConfigurableProviders failed (route still registered):', err);
  }

  // P0⑤：不订阅/不改写其它 provider —— llm 拓扑事件不挂钩任何行为。

  // —— 「llama.cpp 终端输出监控」同源数据面（HTTP + SSE）——
  //   参考 @linxin666/dsh-client-ui-task-board：官方 ctx.webServer.register 挂路由，
  //   SSE 推送日志/状态，loopback + Host + 同源标记三重栅栏。
  const webServer = (ctx as unknown as Record<string, unknown>).webServer as
    | {
        register(route: {
          kind: 'exact' | 'prefix';
          path: string;
          handler: (req: unknown, res: unknown) => void;
        }): () => void;
      }
    | undefined;
  if (webServer) {
    try {
      for (const route of makeTerminalRoutes({
        logs: server.logs,
        source: {
          status: () => server.getStatus(),
          purpose: () => purposeLines(),
          models: () => store.models().map((m) => ({ id: m.id, name: m.name, mmproj: m.mmproj })),
          // 探测候选走只读路由（不写 config）；运行期探测会随 modelsDir 变化而刷新。
          discovery: discoveryReport,
        },
        actions: {
          // 面板「优雅退出」按钮：Ctrl+C（SIGINT）→ Y 确认 → 等退出；不直杀。
          gracefulStop: () => server.gracefulStop(),
        },
      })) {
        ctx.effect(() => webServer.register(route as never));
      }
      log('terminal monitor routes registered: /api/llamacpp-bridge/{state,events}');
    } catch (err) {
      log('terminal monitor route registration failed:', err);
    }
  } else {
    log('webServer service unavailable: terminal monitor panel disabled (host-only mode)');
  }

  // 卸载：释放进程与监听
  ctx.effect(() => () => {
    log('disposing');
    server.dispose();
    store.dispose();
  });
}

/** 兼容：外部若 import 完整入口 Config。 */
export { BridgeConfig };
