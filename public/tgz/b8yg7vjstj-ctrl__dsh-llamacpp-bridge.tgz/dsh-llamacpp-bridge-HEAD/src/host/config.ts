/**
 * 配置模型（schemastery schema + cordis 入口 Config）。
 *
 * 0.2.x 的正确接法（0.2.0-rc.2 与 0.2.1-rc.2 实测一致）：
 *  - `@deepseek-ai/dsh-settings` **没有 register()**（方法只有
 *    configure/invalidate/prepareDocument/describe/schema）。旧代码里的
 *    `settings.register(ns, schema, {base})` 在 0.2.x 上直接抛
 *    `TypeError: settings.register is not a function`，导致整个 host 半包
 *    不激活（"1 entry did not activate"）。
 *  - 正确做法：插件入口命名空间导出 `Config`（schemastery schema），cordis
 *    的 `resolveConfig(runtime, config)`（cordis/lib/index.js:957）会用
 *    `runtime.Config['~standard'].validate(config)` 校验并填充默认值，
 *    结果作为 `apply(ctx, config)` 的第二个参数。
 *  - **希望设置页可改 + 热更新的字段必须标 `.volatile()`**：
 *      · volatile 字段在 config 里是 `{ get(): T }`（cosmokit createVolatile），
 *        读取要 `.get()`；
 *      · `dsh-settings.describe()` 只对含 volatile 字段的 schema 生成表单
 *        （volatileForm），且写入要求路径 isVolatilePath，否则报
 *        `Config field "x" is not volatile`；
 *      · 用户保存后 loader 走 `_commitVolatile()`：**不重跑 apply**，而是
 *        updateVolatile 把新值写进已持有的引用，并发 `loader/volatile-update`
 *        事件 —— 我们用这个事件做热更新（重扫目录 / 停服）。
 *  - 命名空间 = **entry id**（cordis.patch.yml 里的 `id:`），不是包名也不是
 *    旧的 'llamacpp-bridge'。本插件的 entry id 是 'dsh-llamacpp-bridge'。
 */

import Schema from '@deepseek-ai/schemastery';
import { DEFAULT_HOST, DEFAULT_MMPROJ_SUFFIX, DEFAULT_PORT, PROVIDER_ID } from '../shared.js';

/** 插件配置（解析后的值形态，所有字段有默认值）。 */
export interface BridgeCfg {
  displayName: string;
  executable: string;
  modelsDir: string;
  host: string;
  port: number;
  strategy: 'restart' | 'api';
  contextLength: number;
  autoContext: boolean;
  gpuLayers: number;
  mmprojSuffix: string;
  /** 视觉投影文件手动绑定：{ 模型id: 投影文件名 }（优先级最高）。 */
  mmprojOverrides: Record<string, string>;
  additionalArgs: string[];
  startTimeoutMs: number;
  debug: boolean;
}

export type LlamaCppBridgeConfig = BridgeCfg;

/** JS 默认值（与 schema 默认一致，供自动发现结果兜底）。 */
export function defaultConfig(): BridgeCfg {
  return {
    displayName: 'Local llama.cpp',
    // 空 = 交给 host 自动发现；用户保存的值永远优先。
    executable: '',
    modelsDir: '',
    host: DEFAULT_HOST,
    port: DEFAULT_PORT,
    strategy: 'restart',
    contextLength: 0,
    autoContext: false,
    gpuLayers: -1,
    mmprojSuffix: DEFAULT_MMPROJ_SUFFIX,
    mmprojOverrides: {},
    additionalArgs: [],
    startTimeoutMs: 120_000,
    debug: false,
  };
}

/**
 * 插件入口 Config（schemastery）。
 *
 * 全部字段标 `.volatile()`：设置页（settings ns = entry id）可改，且保存后
 * 热生效（loader/volatile-update），无需重启 DSH。
 *
 * `discovery` 字段组（host 自动发现结果）也在这里：0.2.x 一个 entry 只有一份
 * Config，无法再注册第二个命名空间，所以它和 13 个桥接字段共用同一节。
 * 浏览器端设置页从 `value.discovery` 读候选（exe / modelsDir / mmproj）。
 *
 * 注意嵌套限制：schemastery 禁止 volatile 套 volatile，因此 dict/array 的
 * 内层不能再标 volatile。
 */
export const Config = Schema.object({
  displayName: Schema.string().default('Local llama.cpp').volatile(),
  executable: Schema.string().default('').volatile(),
  modelsDir: Schema.string().default('').volatile(),
  host: Schema.string().default(DEFAULT_HOST).volatile(),
  port: Schema.number().default(DEFAULT_PORT).volatile(),
  strategy: Schema.string().default('restart').volatile(),
  contextLength: Schema.number().default(0).volatile(),
  autoContext: Schema.boolean().default(false).volatile(),
  gpuLayers: Schema.number().default(-1).volatile(),
  mmprojSuffix: Schema.string().default(DEFAULT_MMPROJ_SUFFIX).volatile(),
  mmprojOverrides: Schema.dict(Schema.string()).default({}).volatile(),
  additionalArgs: Schema.array(Schema.string()).default([]).volatile(),
  startTimeoutMs: Schema.number().default(120_000).volatile(),
  debug: Schema.boolean().default(false).volatile(),
  discovery: (buildDiscoverySchema() as unknown as Schema).volatile(),
});

/** 旧名兼容（历史代码引用）。 */
export const buildBridgeSchema = (): unknown => Config;

/**
 * “自动发现结果”字段组（`Config.discovery` 的内层 schema）。
 *
 * 0.2.x 一个 entry 只有一份 Config，无法再注册第二个命名空间，因此把发现结果
 * 作为 Config 的一个字段组（volatile 化），host 每次 apply 时写入、配置变更
 * 时刷新，浏览器端设置页据此做图形化引导。
 */
export function buildDiscoverySchema(): unknown {
  return Schema.object({
    executables: Schema.array(
      Schema.object({
        path: Schema.string().default(''),
        source: Schema.string().default(''),
      }),
    ).default([]),
    modelsDirs: Schema.array(
      Schema.object({
        dir: Schema.string().default(''),
        ggufCount: Schema.number().default(0),
      }),
    ).default([]),
    models: Schema.array(Schema.string()).default([]),
    projectors: Schema.array(
      Schema.object({
        file: Schema.string().default(''),
        modelId: Schema.string().default(''),
      }),
    ).default([]),
    updatedAt: Schema.string().default(''),
  });
}

/** 旧名兼容：等价于入口 Config（含 discovery 字段组）。 */
export const BridgeConfig = Config;

/** 把解析出的策略字符串规整为合法值。 */
export function normalizeStrategy(value: string): 'restart' | 'api' {
  return value === 'api' ? 'api' : 'restart';
}

/** 供 ctx.llm.registerConfigurableProviders 使用的目录项。 */
export function configurableProviderEntry(settingsNs: string) {
  return {
    provider: PROVIDER_ID,
    displayName: 'Local llama.cpp (bridge)',
    // 配置面指向本插件的命名空间（= entry id）；profile 即该节整体（无子路径前缀）。
    settingsNs,
    settingsPath: [] as readonly string[],
    declared: true,
  };
}
