import fs from 'node:fs'
const nodes=[{
id:'exp-fail-001',kind:'number',confidence:0.95,topic:'rsi',
title:'A landed promotion costs 3.97 attempts, and 47% of all attempts are thrown away: 127 errors, 87 aborts, 233 verifier failures out of 452',
body:'Counted every attempt.finished in the ledger against every promoted round. 452 attempts over 231 rounds (always two per round when the round runs at all: 225 of 231 rounds proposed exactly 2), 114 promoted rounds, so 3.965 attempts per landed promotion.\n\nOutcome mix: completed 238 (53%), aborted 87 (19%), error 127 (28%). Verifier mix: pass 219 (48%), fail 233 (52%). So roughly half of all work is discarded at the verifier, and more than a quarter is discarded before the verifier ever sees it because the attempt itself errored.\n\nThe 28% error share is the number worth attacking first, because it is not a quality signal at all — an errored attempt is pure loss, and the w1 evidence says agent errors are dominated by transport and truncation rather than by task difficulty (truncation and empty responses hurt more than 500s, retries amplify cost 4.24x). A retry inside the same round, reusing the worktree and the brief, would convert some of that 127 into verifier-tested attempts at near-zero orchestrator cost; the current code discards the worktree instead.\n\nCaveat on the multiplier: at ~7 min per attempt and 2 attempts in parallel, 3.97 attempts per promotion is about 14 minutes of serialised wall clock per landed change, which is consistent with the measured 6-min median round when both attempts run concurrently.',
source:null}]
fs.writeFileSync('research/exp/e12.json',JSON.stringify({nodes,edges:[
{from:'exp-fail-001',rel:'supports',to:'exp-wall-001',note:'Turns round wall clock into cost per landed promotion: 3.97 attempts each.'},
{from:'exp-fail-001',rel:'refines',to:'gap-w1-001',note:'Supplies the per-promotion multiplier a cost-per-promotion number needs.'},
{from:'exp-fail-001',rel:'applies-to',to:'orch-retry-amplifies-cost',note:'The 28% errored attempts are the population where retry policy decides cost.'},
{from:'exp-fail-001',rel:'supports',to:'ana-005',note:'Gives the token denominator of quality per (tokens + human minutes).'},
]}))
console.log('ok')
