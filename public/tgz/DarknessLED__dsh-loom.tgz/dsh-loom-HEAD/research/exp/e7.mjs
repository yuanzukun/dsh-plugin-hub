import fs from 'node:fs'
const N=(id,kind,title,body,source,confidence,topic,tags)=>({id,kind,title,body,source:source??null,confidence,topic,tags})
const nodes=[
N('exp-score-003','number','The graded-score path already works: a declared metric turns a 2-valued score into a 5-valued one, with no code change',
'Wired a verify spec that declares metrics:{quality:{pattern,group}} through the real runVerifier and scored it with the real scoreAttempt. At quality 0, 0.25, 0.5, 0.75 and 1 the recorded attempt scores were 0.30, 0.475, 0.65, 0.825 and 1.00 (0.7*quality + 0.3*pass), against a flat 1.00 for the same passing patch with no metric declared. The verifier returned exit 0 in every case, so the hard precondition still holds; only the grade changed.\n\nWhy this matters: the binary-score defect is a task-declaration gap, not a missing feature. runVerifier.parseMetrics, the tasks[].verify.metrics plumbing and scoreAttempt\'s 0.7/0.3 blend are all present and tested at unit level (tests/gate.test.mjs, tests/exec.test.mjs) and unused at campaign level — no campaign in the ledger declares a metric, so every score is 0 or 1.\n\nLimitation: 0.7 weight on a self-reported or weakly-asserted number is a large amount of trust, and the blend is only meaningful if quality is monotone with real quality. A coverage percentage is the safest first metric because it is measured by the test runner rather than by the patch, but coverage rises when tests are deleted, which is exactly the reward hacking SpecBench measures (+27pp per tenfold LOC). The metric must therefore be paired with the existing no-test-edit check rather than trusted alone.',
null,0.95,'rsi',['gate','score','experiment','fix']),
]
fs.writeFileSync('research/exp/e7.json',JSON.stringify({nodes,
edges:[
{from:'exp-score-003',rel:'supports',to:'exp-score-001',note:'Confirms the defect is declaration-level: the graded path exists and works.'},
{from:'exp-score-003',rel:'requires',to:'ver-003',note:'A graded metric is only safe with a no-test-edit guard, because coverage rises when tests are removed.'},
{from:'exp-score-003',rel:'applies-to',to:'tri-specbench-gap',note:'Self-reported metrics are the surface reward hacking attacks first.'},
]}))
console.log('ok')
