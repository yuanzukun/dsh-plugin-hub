// Render the sidebar panel to a static HTML file, so the design can be looked
// at without opening DeepSeek Harness.
//
// The panel is a React component, and this script does not run React: it
// replays the bundle's own factory with a four-function React shim, feeds the
// real component the state a loaded panel would hold, and serialises the
// resulting node tree. So what you see is the markup and stylesheet the app
// ships — not a mock-up that can drift away from it.
//
//   node scripts/panel-preview.mjs [out.html]
//
// The preview stacks the panel on a dark canvas and on a light one: the
// palette is `currentColor` at fixed opacities, and that claim is only worth
// anything if both canvases are shown.
import { readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const root = join(here, '..')

/** Load client/index.js exactly the way the browser loader does. */
function loadClient() {
  const source = readFileSync(join(root, 'client', 'index.js'), 'utf8')
  let captured = null
  const window = {
    __ModuleLoader__: {
      load({ id, factory }) {
        captured = { id, exports: factory(() => ({ createElement: () => null })) }
      },
    },
  }
  new Function('window', source)(window)
  if (!captured) throw new Error('the bundle did not register')
  return captured.exports
}

function shimReact(states, index = { at: 0 }) {
  const next = () => (index.at < states.length ? states[index.at++] : undefined)
  const react = {
    createElement(type, props, ...children) {
      return { type, props: props || {}, children: children.flat(Infinity).filter((c) => c !== null && c !== undefined && c !== false) }
    },
    useState() {
      return [next(), () => {}]
    },
    useEffect() {},
    useCallback(fn) {
      return fn
    },
  }
  return react
}

function camelToCss(key) {
  return key.replace(/[A-Z]/g, (m) => '-' + m.toLowerCase())
}

function styleOf(style) {
  if (!style || typeof style !== 'object') return ''
  return Object.entries(style)
    .filter(([, v]) => v !== null && v !== undefined && v !== '')
    .map(([k, v]) => `${camelToCss(k)}:${typeof v === 'number' && !/^(opacity|zIndex|flex|flexGrow|flexShrink|order|lineHeight|WebkitLineClamp|fontWeight)$/.test(k) ? v + 'px' : v}`)
    .join(';')
}

function escape(value) {
  return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

function html(node) {
  if (node === null || node === undefined || node === false) return ''
  if (typeof node === 'string' || typeof node === 'number') return escape(node)
  if (Array.isArray(node)) return node.map(html).join('')
  const { type, props, children } = node
  // A component, not a tag: React would call it, so the preview must too. This
  // used to be the bug that made the preview emptier than the real panel — the
  // campaign body is rendered by a component, so serialising it as a <div>
  // measured a page with no campaigns on it.
  if (typeof type === 'function') {
    const kids = children.length === 0 ? undefined : children.length === 1 ? children[0] : children
    return html(type({ ...props, children: kids }))
  }
  // Everything the panel actually sets has to survive into the preview, or the
  // audit is measuring a page that no browser would ever serve. The old list was
  // class/title/data-*/style/disabled, so every aria-*, role and tabIndex was
  // dropped — which meant the accessibility work could never be audited at all,
  // and a regression in it could never fail this script.
  const attrs = []
  if (props.className) attrs.push(`class="${escape(props.className)}"`)
  if (props.title) attrs.push(`title="${escape(props.title)}"`)
  if (props.style) attrs.push(`style="${styleOf(props.style)}"`)
  if (props.disabled) attrs.push('disabled')
  for (const key of Object.keys(props)) {
    if (key === 'className' || key === 'title' || key === 'style' || key === 'disabled') continue
    if (key === 'children' || key === 'key' || key === 'ref') continue
    if (!(key.startsWith('aria-') || key.startsWith('data-') || key === 'role' || key === 'tabIndex' || key === 'type')) continue
    const value = props[key]
    if (value === undefined || value === null || value === false) continue
    const name = key === 'tabIndex' ? 'tabindex' : key
    // aria-checked is a string in the DOM ("true"/"false"), never a bare
    // attribute — React does the same. Only real boolean attributes are bare.
    if (value === true && !key.startsWith('aria-')) attrs.push(name)
    else attrs.push(`${name}="${escape(String(value))}"`)
  }
  const tag = type === 'code' ? 'code' : type === 'button' ? 'button' : type === 'span' ? 'span' : type === 'b' ? 'b' : 'div'
  return `<${tag}${attrs.length ? ' ' + attrs.join(' ') : ''}>${html(children)}</${tag}>`
}

const now = Date.now()
const LIVE = process.env.LOOM_PANEL_URL || ''
let payload = {
  campaigns: [
    {
      id: 'loom-self15',
      status: 'running',
      rounds: 7,
      spendUsd: 0.41,
      // Attempts are what the spend rows read: the per-model figure is summed
      // here, and the tokens/usd totals agree with the triangle below so the
      // preview does not show two numbers that cannot both be true.
      attempts: [
        { id: 'r6a1', model: 'deepseek-flash', costUsd: 0.26, tokens: 9_900 },
        { id: 'r6a2', model: 'kimi-k2', costUsd: 0.11, tokens: 6_100 },
        { id: 'r7a1', model: 'deepseek-flash', costUsd: 0.04, tokens: 2_432 },
      ],
      open: 1,
      lessons: 6,
      quarantined: 1,
      ageMs: 42_000,
      objective:
        'make the loop survive a hostile host: dead child sessions, drifting ledgers, exhausted model budgets — without ever believing a round landed when it did not',
      chainVersion: 2,
      chain: {
        version: 2,
        nodes: [{ type: 'agent', name: 'worker' }, { type: 'map', name: 'candidates' }, { type: 'verifier', name: 'tests' }, { type: 'human' }],
      },
      incumbent: { score: 1 },
      holdout: 2,
      quality: { verdict: 'healthy', promotions: 5, rounds: 7, avgRoundMs: 96_000 },
      // Lessons are filed by file: that is the axis a reader can use, and this
      // fixture carries it so the preview shows the grouping the panel ships.
      lessonsAll: [
        { id: 'l1', claim: 'a child that died mid-turn can still pass the verifier on an unchanged tree', kind: 'hazard', score: 0.7, files: ['src/runtime/round.js'], createdRound: 7 },
        { id: 'l2', claim: 'an `autopilot.applied` with no commit is not a landing', kind: 'hazard', score: 0.5, files: ['src/runtime/recovery.js'], createdRound: 6 },
        { id: 'l3', claim: 'regenerate the brief at half length once the context blows', kind: 'recipe', score: 0.3, files: ['src/dispatch/brief.js'], createdRound: 5 },
        { id: 'l9', claim: 'the panel reads one state object, never a campaign file', kind: 'fact', score: 0.2, files: ['src/panel/api.js'], createdRound: 4 },
        { id: 'l10', claim: 'a demoted provider must not keep planning', kind: 'fact', score: 0.1, files: ['src/runtime/round.js'], createdRound: 3 },
      ],
      lessonsTop: [
        { id: 'l1', claim: 'a child that died mid-turn can still pass the verifier on an unchanged tree', kind: 'hazard', score: 0.7, files: ['src/runtime/round.js'] },
        { id: 'l2', claim: 'an `autopilot.applied` with no commit is not a landing', kind: 'hazard', score: 0.5, files: ['src/runtime/recovery.js'] },
        { id: 'l3', claim: 'regenerate the brief at half length once the context blows', kind: 'recipe', score: 0.3, files: ['src/dispatch/brief.js'] },
      ],
      openCheckpoints: [{ id: 'cp-9f21', kind: 'gate', payload: { verdict: 'improved', delta: 0.12 } }],
      reviews: [{ id: 'cp-9f21', kind: 'gate', risk: 'normal', summary: 'promote r7a2 (score 0.94, Δ0.12)' }],
      // measured by the host (src/runtime/triangle.js); the panel only formats
      triangle: {
        rounds: 7,
        timedRounds: 7,
        durationMs: 672_000,
        attemptMs: 1_545_600,
        verifierMs: 255_360,
        secondsPerRound: 96,
        parallelFactor: 2.3,
        verifierShare: 0.38,
        promotionRate: 5 / 7,
        noGainRate: 2 / 7,
        attemptsPerRound: 2.1,
        tokens: 18_432,
        usd: 0.41,
        tokensPerRound: 2_633,
        usdPerPromotion: 0.082,
        measured: true,
      },
      budget: { usd: 1, rounds: 12, spentUsd: 0.41, roundsUsed: 7, minutes: 240 },
      trend: [
        { n: 1, status: 'no-gain', score: 0.62 },
        { n: 2, status: 'promoted', score: 0.71 },
        { n: 3, status: 'no-gain', score: 0.66 },
        { n: 4, status: 'promoted', score: 0.8 },
        { n: 5, status: 'holdout-failed', score: 0.83 },
        { n: 6, status: 'promoted', score: 0.9 },
        { n: 7, status: 'promoted', score: 0.94 },
      ],
      lastRound: {
        n: 7,
        status: 'promoted',
        promoted: true,
        score: 0.94,
        attempts: [
          { id: 'r7a1', score: 0.88, verifierOk: true },
          { id: 'r7a2', score: 0.94, verifierOk: true },
          { id: 'r7a3', score: null, verifierOk: false, screenedOut: true },
        ],
      },
    },
    {
      id: 'loom-chaos',
      status: 'paused',
      rounds: 6,
      spendUsd: 0.29,
      open: 0,
      lessons: 3,
      quarantined: 0,
      ageMs: 5_400_000,
      objective: 'the panel must degrade instead of 500 when a campaign cannot be read',
      chainVersion: 1,
      chain: { version: 1, nodes: [{ type: 'agent' }, { type: 'verifier' }, { type: 'human' }] },
      incumbent: { score: 1 },
      quality: { verdict: 'stalled', promotions: 2, rounds: 6, avgRoundMs: 143_000 },
      lessonsAll: [
        { id: 'l4', claim: 'wrap every per-campaign read, not just the loop', kind: 'fact', score: 0.2, files: ['src/panel/api.js'], createdRound: 2 },
      ],
      lessonsTop: [{ id: 'l4', claim: 'wrap every per-campaign read, not just the loop', kind: 'fact', score: 0.2, files: ['src/panel/api.js'] }],
      openCheckpoints: [],
      reviews: [],
      triangle: {
        rounds: 6,
        timedRounds: 6,
        durationMs: 858_000,
        attemptMs: 1_372_800,
        verifierMs: 446_160,
        secondsPerRound: 143,
        parallelFactor: 1.6,
        verifierShare: 0.52,
        promotionRate: 2 / 6,
        noGainRate: 3 / 6,
        attemptsPerRound: 1.6,
        tokens: 9_120,
        usd: 0.29,
        tokensPerRound: 1_520,
        usdPerPromotion: 0.145,
        measured: true,
      },
      // six of six rounds and two thirds of the money already gone: the meters
      // have to read as spent, not as a third of an abstract bar
      budget: { usd: 1, rounds: 6, spentUsd: 0.29, roundsUsed: 6, minutes: 240 },
      trend: [
        { n: 1, status: 'no-gain', score: 0.5 },
        { n: 2, status: 'promoted', score: 0.6 },
        { n: 3, status: 'no-gain', score: 0.55 },
        { n: 4, status: 'no-gain', score: 0.58 },
        { n: 5, status: 'crashed', score: 0.4 },
        { n: 6, status: 'promoted', score: 1 },
      ],
      lastRound: { attempts: [{ id: 'r6a1', score: 1, verifierOk: true }] },
    },
    {
      id: 'loom-self3',
      status: 'done',
      rounds: 11,
      spendUsd: 0.66,
      open: 0,
      lessons: 9,
      quarantined: 2,
      ageMs: 86_400_000,
      objective: 'cost per round, a round table, a policy diff and lesson exposure',
      chainVersion: 1,
      incumbent: { score: 1, round: 11 },
      quality: { verdict: 'healthy', promotions: 4, rounds: 11 },
      // `src/panel/api.js` ships `end: describeEnd(state)`, so a finished
      // campaign always reaches the card with the report's own verdict; the
      // preview fixture carries one so the closing line is visible here too.
      end: { status: 'done', cause: 'all-tasks-solved', headline: 'done · all-tasks-solved · best round 11 at 1' },
      lessonsAll: [
        { id: 'l5', claim: 'holdout tasks must rotate, or exposure becomes the lesson', kind: 'fact', score: 0.4, files: ['src/runtime/exposure.js'], createdRound: 9 },
        { id: 'l6', claim: 'a verifier that always fails is a gate nobody can reach', kind: 'hazard', score: 0.35, files: ['src/runtime/round.js'], createdRound: 4 },
        { id: 'l7', claim: 'raise one checkpoint per stuck signature, not one per round', kind: 'recipe', score: 0.1, files: ['src/runtime/ids.js'], createdRound: 3 },
        { id: 'l8', claim: 'a claim that announces nothing was done is not knowledge', kind: 'hazard', score: 0.05, files: [], createdRound: 2 },
      ],
      lessonsTop: [
        { id: 'l5', claim: 'holdout tasks must rotate, or exposure becomes the lesson', kind: 'fact', score: 0.4, files: ['src/runtime/exposure.js'] },
        { id: 'l6', claim: 'a verifier that always fails is a gate nobody can reach', kind: 'hazard', score: 0.35, files: ['src/runtime/round.js'] },
        { id: 'l7', claim: 'raise one checkpoint per stuck signature, not one per round', kind: 'recipe', score: 0.1, files: ['src/runtime/ids.js'] },
      ],
      openCheckpoints: [],
      reviews: [],
      triangle: {
        rounds: 11,
        timedRounds: 11,
        durationMs: 1_452_000,
        attemptMs: 2_758_800,
        verifierMs: 638_880,
        secondsPerRound: 132,
        parallelFactor: 1.9,
        verifierShare: 0.44,
        promotionRate: 4 / 11,
        noGainRate: 5 / 11,
        attemptsPerRound: 1.9,
        tokens: 22_000,
        usd: 0.66,
        tokensPerRound: 2_000,
        usdPerPromotion: 0.165,
        measured: true,
      },
      // eleven rounds, so the sparkline shows the last eight — the window is
      // fixed on purpose: a sidebar is a glance, not a chart
      budget: { usd: 1, rounds: 12, spentUsd: 0.66, roundsUsed: 11, minutes: 240 },
      trend: [
        { n: 1, status: 'no-gain', score: 0.55 },
        { n: 2, status: 'promoted', score: 0.62 },
        { n: 3, status: 'no-gain', score: 0.6 },
        { n: 4, status: 'promoted', score: 0.7 },
        { n: 5, status: 'no-gain', score: 0.68 },
        { n: 6, status: 'promoted', score: 0.75 },
        { n: 7, status: 'no-gain', score: 0.72 },
        { n: 8, status: 'promoted', score: 0.8 },
        { n: 9, status: 'no-gain', score: 0.78 },
        { n: 10, status: 'promoted', score: 0.85 },
        { n: 11, status: 'promoted', score: 0.9 },
      ],
    },
    {
      // the honest absence: the loop ran, the host recorded no wall-clock and
      // no tokens, so the strip says 未测量 instead of inventing five zeros
      id: 'loom-triangle',
      status: 'running',
      rounds: 2,
      spendUsd: 0,
      open: 0,
      lessons: 0,
      quarantined: 0,
      ageMs: 8_000,
      objective: 'a campaign that ran before the triangle existed: two rounds, no wall-clock, no token accounting',
      chainVersion: 3,
      chain: { version: 3, nodes: [{ type: 'agent' }, { type: 'human' }] },
      budget: { usd: 25, rounds: 24, spentUsd: 0, roundsUsed: 2, minutes: 240 },
      triangle: {
        rounds: 2,
        timedRounds: 0,
        durationMs: 0,
        attemptMs: 0,
        verifierMs: 0,
        secondsPerRound: null,
        parallelFactor: null,
        verifierShare: null,
        promotionRate: null,
        noGainRate: null,
        attemptsPerRound: null,
        tokens: 0,
        usd: 0,
        tokensPerRound: null,
        usdPerPromotion: null,
        measured: false,
      },
      trend: [{ n: 1, status: 'no-gain' }, { n: 2, status: 'running' }],
      openCheckpoints: [],
      reviews: [],
      lastRound: { n: 2, status: 'running', attempts: [{ id: 'r2a1', score: null, verifierOk: false }] },
    },
    {
      // nothing has run yet: no sparkline, meters at zero. The empty trend is
      // the correct picture of a new campaign, not an error to be hidden
      id: 'loom-fresh',
      status: 'planning',
      rounds: 0,
      spendUsd: 0,
      open: 0,
      lessons: 0,
      quarantined: 0,
      ageMs: 3_000,
      objective: '还没跑过一轮：面板应该显示空趋势和零预算，而不是把空数组当成错误',
      budget: { usd: 5, rounds: 12, spentUsd: 0, roundsUsed: 0, minutes: 240 },
      openCheckpoints: [],
      reviews: [],
    },
  ],
  live: [{ attemptId: 'r8a1', campaign: 'loom-self15', idleMs: 31_000 }],
  rsi: { enabled: true, at: now - 60_000, by: 'human' },
  ownership: { owner: 8123, mine: true },
  lean: { available: true },
  now,
}

// A fixture proves the component renders; it cannot prove the component
// renders *the campaign you are looking at*. Point LOOM_PANEL_URL at a running
// host and the same code draws the live payload — the tree, the numbers and all.
if (LIVE) {
  const res = await fetch(LIVE)
  if (!res.ok) throw new Error(`live payload ${res.status} from ${LIVE}`)
  const live = await res.json()
  payload = { ...live, now: live.now ?? now }
}

// The panel's resting state is a queue with nothing in it -- that is the whole
// point of a loop that runs while a person does something else. LOOM_PENDING=0
// renders that state so it gets looked at as often as the busy one.
const NO_PENDING = process.env.LOOM_PENDING === '0'

const emptyPayload = NO_PENDING
  ? { ...payload, campaigns: payload.campaigns.map((c) => ({ ...c, open: 0, openCheckpoints: [], reviews: [] })) }
  : null

const pendingPayload = LIVE || NO_PENDING ? (emptyPayload || payload) : {
  ...payload,
  campaigns: [
    {
      ...payload.campaigns[0],
      openCheckpoints: [
        // a real gate checkpoint carries the patch it would land: rounding it
        // off here made every row look like "carry on", which is the one thing
        // the row must not say
        {
          id: 'cp-9f21',
          kind: 'gate',
          payload: { patch: 'artifacts/r7a2.patch', attempt: 'r7a2', score: 0.94, delta: 0.12 },
        },
        { id: 'cp-a01c', kind: 'stuck', payload: {} },
        { id: 'cp-b77e', kind: 'holdout', payload: { verdict: 'regressed' } },
      ],
      reviews: [
        { id: 'cp-9f21', kind: 'gate', risk: 'normal', summary: 'promote r7a2 (score 0.94, Δ0.12)' },
        { id: 'cp-a01c', kind: 'stuck', risk: 'high', summary: 'same verifier signature for 3 rounds — the gate cannot be reached' },
        { id: 'cp-b77e', kind: 'holdout', risk: 'normal', summary: 'holdout regressed by 0.04' },
      ],
      open: 3,
    },
    payload.campaigns[1],
    payload.campaigns[2],
    payload.campaigns[3],
    payload.campaigns[4],
  ],
}

const client = loadClient()
const { Panel, Card, CSS } = client.__panel
const react = shimReact([{ loading: false, data: pendingPayload, error: null, busy: null }, {}, null])
const CardView = Card(react)
const PanelView = Panel(react, CardView)
const tree = PanelView()
const panelHtml = html(tree)

const page = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>dsh-loom sidebar panel — preview</title>
<style>
  html,body{margin:0;padding:0;background:#101113;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
  .wrap{display:flex;gap:0;align-items:stretch;min-height:100vh}
  /* the widths the sidebar is asked to live in: 320 is the cramped case,
     400 is comfortable, 720 is what the same component must do when the host
     gives it half a window -- the grids are supposed to fill that extra room */
  .canvas{display:flex;flex-direction:column}
  .dark{flex:0 0 320px;width:320px}
  .light{flex:0 0 400px;width:400px}
  .wide{flex:0 0 720px;width:720px}
  .label{font:11px/1 ui-monospace,monospace;letter-spacing:.14em;text-transform:uppercase;padding:10px 12px;color:#6b7078}
  .slot{flex:1 1 auto;min-height:0;display:flex;flex-direction:column;overflow:hidden}
  .dark{background:#08090a;color:#f7f8f8}
  .light{background:#ffffff;color:#08090a;border-left:1px solid #e5e7eb}
  /* the component pins this at mount from the host theme's computed colour;
     a static page has to state it, and these are the same two inks */
  /* the panel writes both of these at mount from the host theme: the ink it
     found, and the canvas colour that ink sits on (what a solid button fills
     with the ink and writes its label in) */
  .dark .loom{--loom-ink-base:#f7f8f8;--loom-ink-canvas:#08090a}
  .light .loom{--loom-ink-base:#08090a;--loom-ink-canvas:#ffffff}
  .wide{background:#08090a;color:#f7f8f8;border-left:1px solid #23262b}
  .wide .loom{--loom-ink-base:#f7f8f8;--loom-ink-canvas:#08090a}
  .dark .label{color:#62666d}
  .light .label{color:#8a8f98}
  .wide .label{color:#62666d}
${CSS}
  /* a panel pinned to a real sidebar height is the only way to see what the
     top of it does while the reader is somewhere else in the list */
  ${process.env.LOOM_VIEWPORT ? `.canvas{height:${Number(process.env.LOOM_VIEWPORT)}px;min-height:0}` : ''}
</style>
</head>
<body>
<div class="wrap">
  <div class="canvas dark"><div class="label">dark · #08090a · 320px</div><div class="slot">${panelHtml}</div></div>
  <div class="canvas light"><div class="label">light · #ffffff · 400px</div><div class="slot">${panelHtml}</div></div>
  <div class="canvas dark wide"><div class="label">dark · 720px · the same component, more room</div><div class="slot">${panelHtml}</div></div>
</div>
${process.env.LOOM_SCROLL ? `<script>
  // scroll every canvas to the same place, the way a reader would
  addEventListener('load', function () {
    document.querySelectorAll('.loom-scroll').forEach(function (sc) {
      sc.scrollTop = ${Number(process.env.LOOM_SCROLL)}
    })
  })
</script>` : ''}
</body>
</html>
`

const out = process.argv[2] ? process.argv[2] : join(root, 'docs', 'panel-preview.html')
writeFileSync(out, page)
console.log('wrote ' + out + ' (' + page.length + ' bytes)')
console.log('campaigns: ' + payload.campaigns.length + ' · pending: ' + client.__panel.pending(pendingPayload).length)
