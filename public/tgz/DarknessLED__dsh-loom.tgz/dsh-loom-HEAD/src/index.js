import { randomUUID } from 'node:crypto'
import { appendFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { normalizeConfig } from './core/config.js'
import { loomHome } from './core/paths.js'
import { claimOwnership, releaseLock } from './core/lock.js'
import { Runtime } from './runtime/runtime.js'
import { svc } from './core/services.js'
import { registerTools } from './tools/index.js'
import { panelSource, actionHandler } from './panel/api.js'
import { panelRoute } from './panel/route.js'
import { loadConfigSchema, mergeConfigValues } from './config-schema.js'

export const name = 'dsh-loom'

/**
 * The settings form, built from the same field list the code reads.
 *
 * The host learns a plugin's config shape only through this export; without it
 * the plugin row reads `status: "absent"` and every knob has to be edited by hand
 * in the profile's patch document, where a typo fails at load instead of at the
 * field. It degrades to `undefined` when the schema library is not resolvable --
 * an absent form is a far smaller loss than a failed host entry.
 */
export const Config = await loadConfigSchema()
/** Hard dependency: `ctx.tools` exists by the time apply() runs. */
export const inject = ['tools']

function traceLine(stage, err) {
  try {
    const home = process.env.LOOM_HOME || join(process.env.USERPROFILE || process.env.HOME || '.', '.dsh', 'loom')
    mkdirSync(home, { recursive: true })
    appendFileSync(
      join(home, 'apply.log'),
      `${new Date().toISOString()} pid=${process.pid} ${stage}${err ? ` :: ${err?.stack || err}` : ''}
`,
    )
  } catch {
    /* tracing must never throw */
  }
}

export function apply(ctx, config) {
  try {
    return applyInner(ctx, config)
  } catch (err) {
    // A throw here would otherwise be a single warning inside a packaged host.
    traceLine('apply:threw', err)
    throw err
  }
}

function applyInner(ctx, config) {
  let cfg
  try {
    // The form writes only the fields it owns; anything else is already in the
    // patch document and must survive a hot update untouched.
    cfg = normalizeConfig(mergeConfigValues({}, config))
  } catch (err) {
    ctx.logger?.warn?.(`[loom] bad config: ${err?.message ?? err}`)
    return
  }
  const home = loomHome(cfg)

  const trace = traceLine
  trace('apply:start')
  trace('apply:config')

  const log = (...args) => {
    try {
      ctx.logger?.info?.('[loom]', ...args)
    } catch {
      /* logging must never throw */
    }
  }

  // Newest instance wins the loop. A restarted window must never end up as a
  // silent no-op because an abandoned process still holds a pid lock.
  const claim = claimOwnership(home, { instance: randomUUID().slice(0, 8) })
  if (claim.previous && claim.previous.pid !== process.pid) {
    log(`took the loop over from pid ${claim.previous.pid}`)
  }

  trace(`apply:claimed owner=${claim.ok} instance=${claim.record?.instance}`)

  const runtime = new Runtime({ ctx, home, config: cfg, log, lockFile: claim.file })

  // Anything a previous host left "running" is a lie: close it before ticking.
  try {
    const recovered = runtime.recover()
    if (recovered.abandonedAttempts.length || recovered.interruptedRounds.length) {
      log(
        `recovered after restart: ${recovered.abandonedAttempts.length} attempt(s), ${recovered.interruptedRounds.length} round(s)`,
      )
    }
  } catch (err) {
    log('recovery failed:', err?.message ?? err)
  }

  // Tools are registered whatever the ownership state: a second window should
  // still be able to look, and say clearly that another window is driving.
  try {
    registerTools(ctx, { runtime, config: cfg })
    trace('apply:tools')
  } catch (err) {
    trace('apply:tools-failed', err)
    log('tool registration failed:', err?.message ?? err)
  }

  // The panel's only data source. `ctx.get('webServer')` at apply time is a
  // trap: services appear later, so the check is false on a real boot and the
  // route silently never exists (the panel then shows HTTP 404). `inject`
  // runs the closure when the service shows up, and never runs on a headless
  // host that has no webServer at all.
  //
  // The handler comes from `./panel/route.js` -- the exact module the panel
  // route spec exercises -- so a spec can never pass against a handler the
  // host does not serve.
  if (typeof ctx.inject === 'function') {
    ctx.inject(['webServer'], (scope) => {
      try {
        const webServer = svc(scope, 'webServer')
        const route = panelRoute(panelSource({ runtime, config: cfg }), {
          write: actionHandler({ runtime, config: cfg }),
        })
        scope.effect(() => webServer.register(route), 'dsh-loom: panel route')
      } catch (err) {
        log('panel route failed:', err?.message ?? err)
      }
    })
  }

  // Keep the human-facing agent aware of running campaigns without waking it.
  // Same late-service rule as the panel route: inject, do not `ctx.get` once.
  if (typeof ctx.inject === 'function') {
    ctx.inject(['systemPrompt'], (scope) => {
      try {
        const systemPrompt = svc(scope, 'systemPrompt')
        scope.effect(() =>
          systemPrompt.section({
            name: 'dsh-loom:campaigns',
            order: 118,
            text: () => {
              try {
                return runtime.briefForPrompt()
              } catch (err) {
                log('campaign brief failed:', err?.message ?? err)
                return ''
              }
            },
          }),
        )
      } catch (err) {
        log('campaign brief failed:', err?.message ?? err)
      }
    })
  }

  // Single timer owns all scheduling. Callbacks must never throw: an uncaught
  // throw here is fatal to the host process.
  ctx.effect(() => {
    const tick = () => {
      try {
        runtime.tick()
      } catch (err) {
        log('tick failed:', err?.stack ?? err)
      }
    }
    const handle = setInterval(tick, Math.max(1000, Number(cfg.tickMs) || 20_000))
    if (typeof handle.unref === 'function') handle.unref()
    const warm = setTimeout(tick, 250)
    if (typeof warm.unref === 'function') warm.unref()
    return () => {
      clearInterval(handle)
      clearTimeout(warm)
      runtime.dispose()
    }
  }, 'dsh-loom: scheduler')

  trace('apply:panel+prompt')
  ctx.effect(() => () => releaseLock(claim.file), 'dsh-loom: lock')

  trace(`apply:done tools=${svc(ctx, 'tools')?.schemas?.()?.length ?? '?'}`)
  log(`ready at ${home} (pid ${process.pid}, instance ${claim.record.instance})`)
}

// The loader normalizes module shapes with `exports = exports.default ?? exports`
// before it reads `plugin.Config` / `plugin.inject` (cordis-plugin-loader
// `unwrapExports`). A bare `export default apply` therefore hands the host the
// *function*, and a function carries no `.Config` -- which is exactly why the
// plugin row read `status: "absent"` for a week while `Config` sat right there
// in the module namespace. Attaching the metadata to the default export keeps
// both module shapes usable: `import loom from` and `import * as loom`.
apply.Config = Config
apply.inject = inject
// `name` is a read-only own property on a function, so it cannot be assigned;
// the namespace export already carries it for `import * as`, and the loader only
// needs `Config` and `inject` off the unwrapped value.
export default apply

// touch: 2026-11-06T17:08:36Z
