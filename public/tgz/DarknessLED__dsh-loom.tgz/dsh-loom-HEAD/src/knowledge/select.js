// Lesson selection policy for a campaign.
//
// A round may show a worker only a few prior `Lesson` records; showing too
// many (or showing them during exploration) suppresses exploration. This
// module is the policy: pure functions, no dependencies, no side effects.
//
// Lesson shape:
//   { id, family, taskIds, tags, kind, claim, evidence, confidence, status,
//     createdRound, ttlRounds, useCount, gainSum, harmCount, lastUsedRound }
//
// Ranking formula (also see scoreLesson):
//   score = confidence
//         + gainSum / (useCount + 1)
//         - 0.5 * harmCount
//         - 0.15 * max(0, round - createdRound) / 12
// The final score is forced finite (non-finite terms become 0, the result is
// clamped to +/-1e9) and rounded to 6 decimals so ranking is reproducible.

import { isNoWorkClaim } from './impact.js'
import { transferRoute, trialVerdict } from './cross.js'

const DEFAULT_TTL = 12
const DEFAULT_LIMIT = 3
const DEFAULT_MAX = 200
const SCORE_CLAMP = 1e9

function toObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) ? value : {}
}

function finiteNumber(value, fallback = 0) {
  const number = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(number) ? number : fallback
}

function optionValue(options, key, fallback) {
  const source = toObject(options)
  return source[key] === undefined ? fallback : source[key]
}

// The shared shape requires a non-empty string id; entries without one are
// malformed and are skipped by the selectors below.
function lessonId(lesson) {
  if (lesson === null || typeof lesson !== 'object' || Array.isArray(lesson)) return null
  return typeof lesson.id === 'string' && lesson.id.length > 0 ? lesson.id : null
}

function copyLesson(lesson, round) {
  return {
    ...lesson,
    // Arrays are copied too so callers mutating a returned lesson cannot
    // reach back into the campaign store.
    taskIds: Array.isArray(lesson.taskIds) ? [...lesson.taskIds] : lesson.taskIds,
    tags: Array.isArray(lesson.tags) ? [...lesson.tags] : lesson.tags,
    score: scoreLesson(lesson, { round }),
  }
}

/**
 * true when the lesson's TTL has elapsed: round > createdRound + ttlRounds.
 * A missing ttlRounds means 12; a missing createdRound behaves as 0, so the
 * comparison stays well defined and never throws.
 */
export function isExpired(lesson, options) {
  const entry = toObject(lesson)
  const round = finiteNumber(optionValue(options, 'round', 0), 0)
  const createdRound = finiteNumber(entry.createdRound, 0)
  const ttlRounds = finiteNumber(entry.ttlRounds, DEFAULT_TTL)
  return round > createdRound + ttlRounds
}

/**
 * Why this lesson applies to this task, in priority order:
 * 'family' | 'task' | 'tag' | 'wildcard' | null.
 */
export function matchReason(lesson, task) {
  const entry = toObject(lesson)
  const target = toObject(task)
  const lessonTags = Array.isArray(entry.tags) ? entry.tags : []
  const taskTags = Array.isArray(target.tags) ? target.tags : []

  if (typeof entry.family === 'string' && entry.family === target.family) return 'family'

  const taskIds = Array.isArray(entry.taskIds) ? entry.taskIds : []
  if (target.id !== undefined && taskIds.includes(target.id)) return 'task'

  if (lessonTags.some((tag) => taskTags.includes(tag))) return 'tag'

  if (entry.family === '*') return 'wildcard'

  return null
}

/**
 * Deterministic relevance score; see the formula at the top of this file.
 * Non-finite inputs are ignored and the result is always a finite number
 * rounded to 6 decimals.
 */
export function scoreLesson(lesson, options) {
  const entry = toObject(lesson)
  const round = finiteNumber(optionValue(options, 'round', 0), 0)

  const confidence = finiteNumber(entry.confidence, 0)
  const gainSum = finiteNumber(entry.gainSum, 0)
  const useCount = Math.max(0, finiteNumber(entry.useCount, 0))
  const harmCount = Math.max(0, finiteNumber(entry.harmCount, 0))
  const createdRound = finiteNumber(entry.createdRound, 0)

  const denominator = useCount + 1
  const gainTerm = Number.isFinite(gainSum / denominator) ? gainSum / denominator : 0
  const staleness = (0.15 * Math.max(0, round - createdRound)) / 12

  let score = confidence + gainTerm - 0.5 * harmCount - staleness
  if (!Number.isFinite(score)) {
    score = Number.isNaN(score) ? 0 : Math.sign(score) * SCORE_CLAMP
  }
  score = Math.max(-SCORE_CLAMP, Math.min(SCORE_CLAMP, score))

  const rounded = Math.round(score * 1e6) / 1e6
  return rounded === 0 ? 0 : rounded
}

function compareRanked(left, right) {
  if (right.score !== left.score) return right.score - left.score
  const leftCreated = finiteNumber(left.createdRound, 0)
  const rightCreated = finiteNumber(right.createdRound, 0)
  if (rightCreated !== leftCreated) return rightCreated - leftCreated
  if (left.id < right.id) return -1
  if (left.id > right.id) return 1
  return 0
}

// Everything a `notWhen` condition is checked against: the task's own words,
// its family, tags and difficulty shape. A condition that matches any of them
// means "this lesson has been wrong in this situation before", and the lesson
// does not get a slot. Negative transfer is the most consistent warning in the
// transfer literature; this is the one place that warning can be acted on.
function haystackOf(task) {
  const t = toObject(task)
  const parts = []
  for (const key of ['text', 'prompt', 'description', 'id', 'family']) {
    if (typeof t[key] === 'string') parts.push(t[key])
  }
  for (const key of ['tags', 'shape', 'signature']) {
    if (Array.isArray(t[key])) parts.push(...t[key].filter((x) => typeof x === 'string'))
  }
  return parts.join(' ').toLowerCase()
}

function blockedByNotWhen(lesson, haystack) {
  const conditions = toObject(lesson).notWhen
  if (!Array.isArray(conditions) || !haystack) return false
  return conditions.some(
    (c) => typeof c === 'string' && c.trim() && haystack.includes(c.trim().toLowerCase()),
  )
}

/**
 * Pick at most `limit` active lessons for this round/task/phase.
 * Exploration never receives prior guidance, so it always returns [].
 * Excluded: non-active, expired, holdout families, recipe lessons during
 * repair, and anything that does not match the task.
 */
export function selectLessons(lessons, options) {
  if (!Array.isArray(lessons)) return []

  const phase = optionValue(options, 'phase', undefined)
  if (phase === 'explore') return []

  const round = finiteNumber(optionValue(options, 'round', 0), 0)
  const task = toObject(optionValue(options, 'task', {}))
  const rawLimit = optionValue(options, 'limit', DEFAULT_LIMIT)
  const limit = Number.isFinite(Number(rawLimit))
    ? Math.max(0, Math.floor(Number(rawLimit)))
    : DEFAULT_LIMIT

  const rawExcluded = optionValue(options, 'excludeFamilies', [])
  const excludedFamilies = new Set(Array.isArray(rawExcluded) ? rawExcluded : [])
  // Cross-domain material is opt-in: a caller that has not thought about
  // analogies must not start receiving them. Procedures are scarce for the same
  // reason -- one SOP is a hypothesis, three in one brief are noise.
  const allowAnalogies = optionValue(options, 'allowAnalogies', false) === true
  const allowProcedures = optionValue(options, 'allowProcedures', false) === true
  const procedureLimitRaw = Number(optionValue(options, 'procedureLimit', 1))
  const procedureLimit = Number.isFinite(procedureLimitRaw) ? Math.max(0, Math.floor(procedureLimitRaw)) : 1
  const haystack = haystackOf(task)

  const selected = []
  for (const lesson of lessons) {
    if (lessonId(lesson) === null) continue
    if (lesson.status !== 'active') continue
    if (isExpired(lesson, { round })) continue
    if (excludedFamilies.has(lesson.family)) continue
    // Twenty showings that lost more often than they won is a verdict. It is
    // enforced here, where the brief is built, not left in a status field.
    if (trialVerdict(lesson) === 'drop') continue
    if (phase === 'repair' && (lesson.kind === 'recipe' || lesson.kind === 'procedure')) continue
    if (lesson.kind === 'procedure' && !allowProcedures) continue
    const route = transferRoute(lesson, task)
    if (route.route === 'none') continue
    // Inspiration never enters a repair brief: repairs need deterministic
    // guidance, and an analogy is a question, not an instruction.
    if (route.route === 'analogy' && (!allowAnalogies || phase === 'repair')) continue
    if (blockedByNotWhen(lesson, haystack)) continue
    // A claim that announces "nothing was needed" teaches the next worker
    // nothing, and it occupies one of the few slots a brief has.
    if (isNoWorkClaim(lesson.claim)) continue
    selected.push({ ...copyLesson(lesson, round), route: route.route, analogy: route.route === 'analogy' })
  }

  selected.sort(compareRanked)
  const out = []
  let procedures = 0
  for (const lesson of selected) {
    if (out.length >= limit) break
    if (lesson.kind === 'procedure') {
      if (procedures >= procedureLimit) continue
      procedures += 1
    }
    out.push(lesson)
  }
  return out
}

/**
 * Drop expired lessons and "used at least 5 times but never gained" ones,
 * then keep the newest `max` of the rest by createdRound (then id).
 * Returns original lesson objects, never mutates the input array, and skips
 * malformed entries. `retired` holds only the ids dropped by the retirement
 * rules above; entries falling outside `max` are simply not kept.
 */
export function pruneLessons(lessons, options) {
  if (!Array.isArray(lessons)) return { kept: [], retired: [] }

  const round = finiteNumber(optionValue(options, 'round', 0), 0)
  const rawMax = optionValue(options, 'max', DEFAULT_MAX)
  const max = Number.isFinite(Number(rawMax))
    ? Math.max(0, Math.floor(Number(rawMax)))
    : DEFAULT_MAX

  const surviving = []
  const retired = []

  for (const lesson of lessons) {
    const id = lessonId(lesson)
    if (id === null) continue
    const useCount = Math.max(0, finiteNumber(lesson.useCount, 0))
    const gainSum = finiteNumber(lesson.gainSum, 0)
    // A lesson under an open trial has its own retirement rule: the trial's
    // verdict. The old "used five times, never gained" rule would retire it
    // exactly when it started accumulating evidence, at 5 of the 20 showings
    // the verdict needs.
    const verdict = lesson.trials && typeof lesson.trials === 'object' ? trialVerdict(lesson) : null
    const neverUseful =
      verdict === 'drop' || (verdict === null && useCount >= 5 && gainSum <= 0)
    // Retire claims that announce nothing was done. They were written by an
    // older producer; leaving them active means every brief keeps spending a
    // slot to say so.
    const noWork = isNoWorkClaim(lesson.claim)
    if (isExpired(lesson, { round }) || neverUseful || noWork) {
      retired.push(id)
      continue
    }
    surviving.push(lesson)
  }

  surviving.sort((left, right) => {
    const leftCreated = finiteNumber(left.createdRound, 0)
    const rightCreated = finiteNumber(right.createdRound, 0)
    if (rightCreated !== leftCreated) return rightCreated - leftCreated
    if (left.id < right.id) return -1
    if (left.id > right.id) return 1
    return 0
  })

  retired.sort()
  return { kept: surviving.slice(0, max), retired }
}
