// Matched-budget comparison of two loop policies.
//
// The loop has been comparing policies badly for its whole life. Every earlier
// comparison held the *round* fixed, i.e. it decided round 3 under policy A and
// round 7 under policy B, and the rounds are not exchangeable: a task is easier
// before anyone has solved it, and the selector prefers unsolved tasks. That is
// why the recorded effect sizes kept landing on "no difference" even where the
// two arms disagreed on a third of the rounds -- the comparison was measuring
// round difficulty, not the policy.
//
// The pair is the unit here, so the comparison is paired: the same round, the
// same attempts, the same scores, decided twice. Nothing about the candidates can
// differ between the arms, which is the strongest form of budget matching there
// is -- there is no second budget at all.
//
// Everything this module reports is deliberately unresolved about "no effect":
// with n pairs it can only detect a difference of `mde` points, and a result
// smaller than that is reported as "cannot distinguish", never as "no effect".

/** Two-sided normal quantile for a confidence level. Fixed table: no dependency. */
const Z = { 0.9: 1.6449, 0.95: 1.9600, 0.98: 2.3263, 0.99: 2.5758 }

function zFor(alpha) {
  const key = Number((1 - alpha).toFixed(2))
  return Z[key] ?? 1.96
}

/** Power -> one-sided quantile, i.e. the multiplier for beta. */
const POWER_Z = { 0.5: 0, 0.8: 0.8416, 0.9: 1.2816, 0.95: 1.6449 }

function powerZ(power) {
  const key = Number(power.toFixed(2))
  return POWER_Z[key] ?? 0.8416
}

function pct(n) {
  return `${(n * 100).toFixed(1)} points`
}

/**
 * Wilson score interval for a binomial proportion.
 *
 * Chosen over the normal approximation because the promotion rates here live
 * near 0.25 with n in the tens: the normal interval runs below zero and reports
 * a lower bound that cannot exist, which reads as more certainty than the data.
 *
 * @param {number} k successes
 * @param {number} n trials
 * @param {number} [alpha]
 * @returns {{low:number, high:number, p:number}}
 */
export function wilsonInterval(k, n, alpha = 0.05) {
  if (!Number.isFinite(n) || n <= 0) return { low: 0, high: 1, p: 0 }
  const p = k / n
  const z = zFor(alpha)
  const z2 = z * z
  const denom = 1 + z2 / n
  const centre = (p + z2 / (2 * n)) / denom
  const half = (z * Math.sqrt((p * (1 - p)) / n + z2 / (4 * n * n))) / denom
  return { low: Math.max(0, centre - half), high: Math.min(1, centre + half), p }
}

/** Exact two-sided McNemar p-value for `b` discordant pairs one way, `c` the other. */
export function mcnemarExact({ onlyA = 0, onlyB = 0 } = {}) {
  const n = onlyA + onlyB
  if (n === 0) return 1
  const k = Math.min(onlyA, onlyB)
  // P(X <= k) for X ~ Bin(n, 0.5), doubled and capped at 1.
  let tail = 0
  let choose = 1
  for (let i = 0; i <= k; i += 1) {
    if (i > 0) choose = (choose * (n - i + 1)) / i
    tail += choose
  }
  const p = (tail / 2 ** n) * 2
  return Math.min(1, p)
}

/**
 * The smallest difference in promotion rate this design could have detected.
 *
 * Paired design: the test's power comes from the discordant pairs, so what makes
 * a comparison sharp is not n but how often the two arms disagree. Returns a
 * proportion (0.125 = 12.5 percentage points).
 *
 * @param {{n:number, discordance?:number, alpha?:number, power?:number}} input
 * @returns {number}
 */
export function mdePaired({ n, discordance = 0.25, alpha = 0.05, power = 0.8 } = {}) {
  if (!Number.isFinite(n) || n <= 0) return 1
  const z = zFor(alpha) + powerZ(power)
  return Math.min(1, z * Math.sqrt(discordance / n))
}

/**
 * The smallest difference two independent arms could detect.
 *
 * Kept because the loop also runs independent arms -- two campaigns, one policy
 * each -- and that design is much weaker for the same money: it pays for the
 * between-round variance instead of differencing it out.
 *
 * @param {{n:number, p?:number, alpha?:number, power?:number}} input
 * @returns {number}
 */
export function mdeIndependent({ n, p = 0.5, alpha = 0.05, power = 0.8 } = {}) {
  if (!Number.isFinite(n) || n <= 0) return 1
  const z = zFor(alpha) + powerZ(power)
  return Math.min(1, z * Math.sqrt((2 * p * (1 - p)) / n))
}

/**
 * Compare two policies on the same rounds.
 *
 * @param {object} input
 * @param {Array<object>} input.rounds one entry per round, in any order
 * @param {(round: object) => boolean} input.decideA would policy A promote this round?
 * @param {(round: object) => boolean} input.decideB would policy B promote this round?
 * @param {number} [input.alpha]
 * @returns {{n:number, both:number, onlyA:number, onlyB:number, neither:number,
 *            rateA:number, rateB:number, delta:number, mde:number,
 *            interval:{low:number, high:number}, p:number,
 *            verdict:'a-better'|'b-better'|'cannot-distinguish', sentence:string}}
 */
export function comparePolicies({ rounds, decideA, decideB, alpha = 0.05 } = {}) {
  const list = Array.isArray(rounds) ? rounds : []
  let both = 0
  let onlyA = 0
  let onlyB = 0
  let neither = 0
  for (const round of list) {
    const a = Boolean(decideA(round))
    const b = Boolean(decideB(round))
    if (a && b) both += 1
    else if (a) onlyA += 1
    else if (b) onlyB += 1
    else neither += 1
  }
  const n = list.length
  const rateA = n ? (both + onlyA) / n : 0
  const rateB = n ? (both + onlyB) / n : 0
  const delta = rateA - rateB
  const discordance = n ? (onlyA + onlyB) / n : 0
  // With zero discordant pairs the paired formula returns an MDE of zero, which
  // reads as "infinitely sensitive" -- the exact opposite of the truth: the arms
  // never disagreed, so the comparison carries no information about which is
  // better. Report the planning figure at the worst-case discordance instead and
  // let the verdict stay unresolved.
  const agreed = onlyA + onlyB === 0
  const mde = mdePaired({ n, discordance: agreed ? 0.5 : discordance, alpha })
  const p = mcnemarExact({ onlyA, onlyB })
  // The interval is on the difference of two paired proportions: the discordant
  // pairs carry the uncertainty, the concordant ones cancel.
  const se = n ? Math.sqrt((onlyA + onlyB - (delta * n) ** 2 / n) / (n * n)) : 0
  const z = zFor(alpha)
  const interval = { low: Math.max(-1, delta - z * se), high: Math.min(1, delta + z * se) }

  let verdict = 'cannot-distinguish'
  if (n === 0 || agreed) verdict = 'cannot-distinguish'
  else if (Math.abs(delta) >= mde && p < alpha) verdict = delta > 0 ? 'a-better' : 'b-better'

  const sentence =
    n > 0 && agreed
      ? `the two policies agreed on all ${n} rounds: on this corpus they decide identically, so no effect size can be estimated (a comparison that never disagrees cannot rank). This is a statement about the two policies being the same function here, not evidence they are equally good.`
      : verdict === 'cannot-distinguish'
      ? `${n} paired rounds with ${(discordance * 100).toFixed(1)}% discordant: this sample cannot distinguish a difference below ${pct(mde)} in promotion rate (measured ${pct(delta)}, p=${p.toFixed(3)}). Not "no effect".`
      : `${verdict === 'a-better' ? 'A' : 'B'} promotes ${pct(Math.abs(delta))} more often over ${n} paired rounds (${onlyA} vs ${onlyB} discordant, p=${p.toFixed(3)}, detactable floor ${pct(mde)}).`

  return { n, both, onlyA, onlyB, neither, rateA, rateB, delta, mde, interval, p, verdict, sentence, agreed }
}

/**
 * Paired comparison of a *continuous* endpoint (a metric, a kill rate, a round
 * duration).
 *
 * The promotion-rate comparison above throws away almost everything: on this
 * corpus each task yields one 0/1 outcome, so a sample of six tasks can only
 * resolve differences of tens of points. A graded task yields a number per
 * task, and the paired differences of those numbers are far more informative --
 * which is the whole reason the graded corpus exists.
 *
 * Same discipline as the binary case: report the effect, its interval, and the
 * smallest effect this sample could have detected; refuse to call anything
 * "no effect".
 *
 * @param {object} opts
 * @param {Array<{base: number, candidate: number}>} opts.pairs one entry per task
 * @param {number} [opts.alpha=0.05] two-sided
 * @param {number} [opts.power=0.8]
 */
export function compareMeans({ pairs, alpha = 0.05, power = 0.8 } = {}) {
  const list = (pairs || []).filter((p) => Number.isFinite(p?.base) && Number.isFinite(p?.candidate))
  const n = list.length
  const deltas = list.map((p) => p.candidate - p.base)
  const mean = (xs) => (xs.length ? xs.reduce((s, x) => s + x, 0) / xs.length : 0)
  const delta = mean(deltas)
  // One pair gives no variance estimate, so it cannot support an interval at all.
  // Saying so is the point: the alternative is a zero-width interval around one
  // observation, which reads as certainty.
  if (n < 2) {
    return {
      n,
      delta: n ? round6(delta) : 0,
      sd: null,
      se: null,
      interval: null,
      mde: null,
      verdict: 'cannot-distinguish',
      sentence: n === 0
        ? 'no paired tasks: nothing to compare.'
        : 'one paired task cannot estimate variance, so no interval and no detectable floor exist: this is not evidence of an effect.',
    }
  }
  const sd = Math.sqrt(deltas.reduce((s, d) => s + (d - delta) ** 2, 0) / (n - 1))
  // Every pair moved by the same amount, or by nothing at all. A zero standard
  // deviation puts a zero width on the interval and a zero floor under the MDE,
  // which reads as infinite sensitivity -- the same lie the binary comparison
  // refuses to tell when the arms never disagree. Say what happened instead.
  // Floating-point summation leaves ~1e-17 of noise on identical deltas, so the
  // test is a tolerance rather than `=== 0`; 1e-12 is far below any endpoint the
  // loop scores in.
  if (!(sd > 1e-12)) {
    const moved = delta !== 0
    return {
      n,
      delta: round6(delta),
      sd: 0,
      se: 0,
      interval: { low: round6(delta), high: round6(delta) },
      mde: round6(Math.abs(delta)),
      verdict: moved ? (delta > 0 ? 'candidate-better' : 'base-better') : 'cannot-distinguish',
      sentence: moved
        ? `all ${n} paired tasks moved by exactly ${round6(delta)}: the sign is consistent across every task, but with no spread there is no interval to report and the detectable floor is the effect itself.`
        : `all ${n} paired tasks produced the same number on both arms: the endpoint did not move at all, so there is no effect size to estimate. This is a statement about the endpoint, not evidence that the two arms are equally good.`,
    }
  }
  const se = sd / Math.sqrt(n)
  const z = zFor(alpha)
  const mde = (z + powerZ(power)) * se
  const interval = { low: delta - z * se, high: delta + z * se }
  let verdict = 'cannot-distinguish'
  if (interval.low > 0) verdict = 'candidate-better'
  else if (interval.high < 0) verdict = 'base-better'
  const sentence =
    verdict === 'cannot-distinguish'
      ? `${n} paired tasks: mean difference ${round6(delta)}, 95% interval [${round6(interval.low)}, ${round6(interval.high)}] includes zero; this sample cannot distinguish a difference below ${round6(mde)} at 80% power. Not "no effect".`
      : `${n} paired tasks: mean difference ${round6(delta)} (95% interval [${round6(interval.low)}, ${round6(interval.high)}]), detectable floor ${round6(mde)} at 80% power.`
  return { n, delta: round6(delta), sd: round6(sd), se: round6(se), interval: { low: round6(interval.low), high: round6(interval.high) }, mde: round6(mde), verdict, sentence }
}

function round6(x) {
  const n = Number(x)
  return Number.isFinite(n) ? Math.round(n * 1e6) / 1e6 : 0
}

/**
 * The pre-registered screen for "one task got worse": is the dip attributable to
 * the change, or is it the size of the endpoint's own movement?
 *
 * Three states, and the middle one is the point. A dip that is smaller than the
 * arm's measured repeat spread is not attributable, so it passes. A dip with no
 * spread measured is `null` — unresolved: not a pass, because nothing says the
 * change is innocent; not a fail, because nothing says it is guilty. Without this
 * state the strictest rule in the protocol would be decided by the noisiest
 * measurement in it, and "it got worse" would mean "one run landed low".
 *
 * @param {object} opts
 * @param {string[]} [opts.lostTasks] tasks the candidate lost entirely (missing data)
 * @param {number} opts.worstDrop largest per-task drop (base - candidate), >= 0
 * @param {number|null} [opts.noiseSpread] measured spread of the same config on an
 *   unchanged tree, or null when it was never measured
 * @param {number|null} [opts.resolution] the sample's own resolution (MDE), or null
 *   when the endpoint did not move at all
 * @returns {{pass: boolean|null, attributable: boolean, unresolved: boolean,
 *   dipWithin: boolean, reason: string}}
 */
export function screenDip({ lostTasks = [], worstDrop = 0, noiseSpread = null, resolution = null } = {}) {
  const lost = Array.isArray(lostTasks) ? lostTasks.filter(Boolean) : []
  const drop = Number.isFinite(worstDrop) && worstDrop > 0 ? worstDrop : 0
  const spread = Number.isFinite(noiseSpread) && noiseSpread >= 0 ? noiseSpread : null
  const res = Number.isFinite(resolution) && resolution > 0 ? resolution : null
  const attributable = drop > 0 && spread !== null && drop > spread
  const unresolved = drop > 0 && spread === null
  const dipWithin = res !== null && drop <= res
  let pass
  if (lost.length > 0) pass = false
  else if (drop === 0) pass = true
  else if (unresolved) pass = null
  else pass = !attributable
  const reason = lost.length > 0
    ? `lost task(s): ${lost.join(', ')}`
    : drop === 0
      ? 'no task got worse'
      : unresolved
        ? `a ${drop.toFixed(3)} dip cannot be attributed: the arm's own repeat spread was never measured`
        : attributable
          ? `a ${drop.toFixed(3)} dip is wider than the arm's own spread of ${spread.toFixed(3)}`
          : `a ${drop.toFixed(3)} dip is within the arm's own spread of ${spread.toFixed(3)}`
  return { pass, attributable, unresolved, dipWithin, reason }
}
