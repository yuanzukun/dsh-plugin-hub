# Where L2 stands (2026-11-14)

The loop can now change its own chain and say what the change did. This page is the
handover: what is adopted, what is held, what is waiting for a person, and how to
reproduce any of it.

## What was measured

| question | answer | evidence |
|---|---|---|
| Does a graded score exist at all? | yes: a mutant-kill-rate verifier over 22 modules, mean 0.3114, 5pp resolution per 20-mutant sample (≈3.5pp of score) | `research/mutants/tasks-base.json` |
| Does the same task give different numbers at different repair levels? | yes, on four modules: triangle 0.00 → 0.85 → 0.95, round 0.00 → 0.10 → 0.05, cost 0.20 → 0.85 → 0.85, policy 0.70 → 1.00 | `research/mutants/dose-*.json` |
| How much does a number move with nothing changed? | 0.100 on one of four tasks, 0.000 on the other three (pooled sd 0.029) | `research/ab/noise.json` |
| Can two chains be compared at matched budget? | yes: paired by task, same rounds, tokens and round clock recorded, MDE printed, "cannot distinguish" reported as such | `src/loop/ab.js`, `research/ab/chain-ab.mjs`, `research/ab/decide.mjs` |

## What L2 decided

1. **Adopted (`adopt:saving`): remove the planner leg.** `code-fix` v2 drops the
   `recon` node. On four mutation tasks the endpoint did not move at all, the planner
   cost 580 s of 2,289 s round clock (25.3%), and it ran four times in four rounds.
   Replaces: the planner before the map.
2. **Held (`hold:not-distinguishable`): one candidate instead of two.** Half the
   tokens (0.51×) and a third less round clock (0.67×), but one of four tasks moved
   by 0.100 — the arm's own repeat spread — so the sample cannot exclude a loss.
   Under the rules a hold is the honest label: adoption would be a bet, rejection a
   claim of harm the data never showed. Replaces: the second parallel candidate.
3. **Rejected (`reject:budget-mismatch`): three candidates instead of two.** Tokens
   14,486 → 30,254 (**2.09×**), round clock 1.45×, endpoint −0.025 with an interval
   that includes zero. The cost is read off the ledger, not off a test. Replaces:
   nothing — the two-candidate map stays.

Both are recorded in `research/ab/decisions.md` with the five rule readings, the
number that decided each one, and what would change the verdict. The protocol and its
three amendments are in `research/ab/README.md`.

## Who decides, now

Three things changed so that a person stands at the L2 decision and nowhere else:

- **The per-round gate no longer asks.** `loopPolicy.autoApply` defaults to true, so a
  round that clears the gate lands without a checkpoint. `chain` nodes that say
  `when: "always"` still stop, and `when: "never"` keeps an unattended campaign
  unattended (`tests/l1-unattended.test.mjs`).
- **A card that does reach a person carries the four facts**: which task, what the diff
  does, what the verifier said, what could break — plus a `missing:` line naming
  whatever could not be produced (`src/runtime/review-card.js`,
  `tests/balance/card-evidence.test.mjs`).
- **A chain change waits for a person.** `rsi_chain(action:"activate")` on a different
  version above 1 raises a `chain` checkpoint and leaves the active version alone;
  approving it activates, `confirm:true` is the explicit shortcut, and the first
  version needs no permission (`tests/l2-requires-human.test.mjs`). Verified in the
  live host on 2026-11-14: activating v2 returned `pending: cp-mwfg81uq000013` with
  `active: 1`, and rejecting it left `activeVersion` at 1 with the checkpoint answered.

## What the loop can propose, and what it may not re-propose

`rsi_chain(action:"auto")` is the only place the loop invents a change to itself. Until
2026-11-14 it was a fixed menu of four kinds and read nothing: it offered
`candidates+1` two days after the paired A/B had rejected exactly that change, and it
offered `no-test-edits` to a campaign whose tasks deliver test edits — an instruction
that makes those tasks impossible.

It now reads two things it already had: the verdicts recorded in
`<home>/decisions.json` (written by `research/ab/decide.mjs --kind=<mutation>`) and each
task's `verify.scope.editable`. A measured kind comes back `already-decided` with the
verdict in the note; a kind the tasks cannot obey comes back `conflicts-with-scope`.
Blocked kinds are reported in the tool result and are not written as new versions, so a
refuted hypothesis costs nothing to re-ask and nothing is silently hidden
(`tests/chain-propose-guard.test.mjs`). Live check: the same call now returns
`proposed: [minimal-change, state-your-uncertainty]` and
`blocked: [candidates+1 already-decided, no-test-edits conflicts-with-scope]`.

The other two kinds remain untested hypotheses. Measuring either needs a paired A/B on
the same tasks (about 25 minutes per arm at four tasks), and at n=4 the floor is a
0.070 quality difference — a prompt-level change is unlikely to clear it.

## Planning is optional, and off by default

The planner leg (`recon`) is the one part of the chain that a person turns on and off
while the loop runs. It is off by default because its product is "where to look", and
the measured tasks already hand that to the worker: on four mutation tasks it moved no
endpoint and spent 580 s of 2,289 s of round clock (25.3%), and 36 of 195 planner runs
across the corpus aborted having returned nothing.

Three ways to ask for it, weakest first:

| where | what it writes | scope |
|---|---|---|
| `loopPolicy.planMode` in the config file | `'full'` / `'off'` / `'auto'` | the install, overridden below |
| workbench toggle (panel header) or `rsi_control(action:"plan")` without an id | `<home>/settings.json` (`plan: true/false`) + an audit line in `settings.jsonl` | every campaign that did not name its own |
| `rsi_control(action:"plan", id:"<campaign>")` — what "add planning" in a conversation writes | one `campaign.policy` event with `planMode` | that campaign |

The planner node stays in `code-fix`. A node that was deleted cannot be switched back
on by a setting, and the toggle is the point. `'auto'` is still supported for an install
that would rather let the ledger decide (`planModeFor`: stop planning after two
promoted-but-wasted rounds, resume after one unplanned loss).

Turning planning on is a policy, not a chain change: no checkpoint, no version, and it
takes effect on the next round (`tests/plan-default.test.mjs`).
## What is waiting for a person

**The adoption is not global.** `loom-v2check` ran chain v2 and converged 3/3 with no
regression on the tasks it ran, but the *default* template is still v1 and every new
campaign still plans first. Making v2 the default is an L2 decision, so it is left
open:

- to accept: `rsi_chain(action:"propose", spec:<v2>)` on the template campaigns, or
  edit `src/chain/templates.js` (or wherever `code-fix` is seeded) to drop `recon`;
- to refuse: nothing to do — v1 stays.

The second candidate is not adopted, so nothing changes for it.

## Reproducing

```
node research/ab/noise.mjs --campaigns=ab-cand1b,ab-cand2b,ab-cand3b,loom-v2check
node research/ab/chain-ab.mjs --base=ab-cand1b --cand=ab-cand2b
node research/ab/decide.mjs --base=ab-cand1b --cand=ab-cand2b --noise-spread=0.100
node research/mutants/dose.mjs --module=src/runtime/triangle.js --patch=<file>
```

Each script reads the campaign ledger under `~/.dsh/loom/campaigns/` and writes JSON
next to itself. `decide.mjs` exits with the decision on stdout; it never edits a
campaign.

## 2026-11-15: the proposal now carries a forecast, and a live round settled it

The card that reached a person on 2026-11-14 named what each proposal would
replace, but not what it was expected to buy. Three modules close that gap
(`f9fcd7e`):

- `src/chain/predict.js` — `predictGain` gives a point estimate and an
  interval from the rounds that actually ran on the chain (`candidates+1` reads
  the measured gap between verified attempts; the prompt kinds read the win
  rate × median win, Wilson-bounded). With no measured history it falls back to
  a `prior` built from the headroom left over the per-task best, and says
  `basis: "prior"` in the card. `regressionRisk` names the reasons (flat
  window, cost of the extra candidate, too little history).
- `src/chain/spec-diff.js` — the exact JSON-path diff between the active chain
  and the proposal, including prompt appends, so the card shows what changes
  rather than describing it.
- `src/chain/evidence-card.js` — rounds on the chain, spend, promotions, then
  per proposal: predicted gain with interval, risk with reasons, diff lines, and
  a `missing:` list for what could not be produced.

Adoption is one click on either door (`src/chain/adopt.js`, called from
`rsi_decide` and the panel): approving a `chain` or `plateau` checkpoint appends
`chain.activated` with the prediction, and `reduce.js` remembers a
`chain.pending`. The next round finished on the new version appends
`chain.measured` with `realized = actual − baseline` and `met | exceeded |
missed`.

### The live measurement

Campaign `l2live` (workspace `C:/Projects/RSI-live/l2`, one task whose verifier
prints `KILLRATE=0.000`). Three flat rounds raised the plateau checkpoint
`cp-mwhsj21m00000q` on its own: it proposed v3 `minimal-change`, v4
`no-test-edits`, v5 `state-your-uncertainty`, with v2 `candidates+1` blocked as
`already-decided`. The card carried `$0.0862` spent, 3 rounds measured, 0
promoted, prediction `0.25 (0 .. 1)`, basis `prior`, risk `high` with the reason
"all 3 of the last rounds promoted nothing", and each spec diff. Approving it
appended `chain.activated` v3; round 4 ran on v3 and
`chain.measured` recorded `realized 0`, `predicted 0.25`, verdict `missed`.

That is the honest result. The forecast was a prior because the chain had never
measured a change of that kind; the card said so in its `missing:` line. A
proposal whose `basis` is `rounds` is the case the interval is actually worth
something — none exists in the corpus yet, and that is what the next campaign
has to produce.

## 2026-11-15: what halving saved, measured on both sides

`loopPolicy.halving` was already wired; it is now billed correctly and
measured. `6ee13d4` charges a survivor for the screen that bought it
(`attemptCostUsd` + `screenCostUsd` = `costUsd`), because before that fix a
halving round looked cheaper than it was: the screen was kept on the record but
never added to the round. `tests/self22/halving-round.test.mjs` pins the split
and pins that `halving:false` runs zero screens and all four candidates —
the off path is unchanged.

Two regimes, same instrument family (real failing suite, verifier prints
`KILLRATE`), four candidates, one round per arm:

| regime | halving on | halving off | score |
|---|---|---|---|
| solvable suite, sibling early stop (`halving-on5` / `off5`) | **$0.035567** | **$0.029309** | 1.0 vs 1.0 |
| no candidate can win, so all four run (`halving-nw-on` / `off`) | **$0.040280** | **$0.064829** | 0 vs 0 |

In the second regime halving saved **37.9%** with the same score: four screens
plus two full attempts cost less than four full attempts. That is the regime it
was designed for — a round where the suite stays red.

In the first regime it cost **21% more**, and the reason is mechanical: a
sibling that solves the task already stops the other attempts after ~30 s
(`solved-by-sibling`), so the control arm pays for one and a bit attempts, not
four; and one screen ignored "do not read files" and burned 42k tokens, roughly
a full attempt by itself. An earlier constant-verifier pair
(`halving-on3` / `off3`) showed the same sign: $0.051336 vs $0.046454.

So the honest summary is not "halving saves money". It is: halving saves money
when the round would otherwise search without a winner; it loses when a sibling
wins early and when screens cost as much as attempts. Both numbers are in the
campaign ledgers under `~/.dsh/loom/campaigns/halving-{on5,off5,nw-on,nw-off}`.

## What this does not claim

- Kill rate is a property of a test suite and a mutation operator, not of the code
  being correct. A high number means the suite notices one-token changes; it says
  nothing about behaviour nobody wrote a mutant for.
- The four tasks in the A/B are the ones with headroom, chosen before the run. They
  are not a random sample of the corpus, and one of them is the least stable.
- A hold is not evidence of equality. It is the statement that this sample cannot
  tell, with the number it cannot resolve.

## 2026-11-15 (second pass): propose, grade, revert — and what it costs

The first pass proved that L2 can propose a chain with a forecast and that a
round can carry a kill rate. This pass closed the six holes a market scan named
(DGM's reward-hacking failure, SICA/Live-SWE-agent per-task cost reporting,
SWE-bench Verified's held-out-test lesson, successive halving's evaluation-cost
caveat) plus two the code was hiding. Commit `1c56c97`.

| # | Hole | Change | Proof |
|---|---|---|---|
| 20 | A screen could burn 42k tokens reading the repo | `halving.screenModel`, a 60 s / 3-tool budget in the brief, and a one-line `VERDICT:` parsed into rank 2/1/0 | `tests/self23/screen-budget.test.mjs`; live: screens fell to ~4k tokens |
| 21 | Survivors were bought in parallel, so an early win did not stop the spend | screened candidates run serially, highest verdict first, and the loop stops at the first win | `tests/self23/sequential-screened.test.mjs`; bench-opt bought 1 full attempt instead of 2 |
| 22 | A failed verifier collapsed the round to score 0 and hid a 0.9 kill rate | attempt/round carry `progress` (kill rate) beside `score` and `promotable` | `tests/self23/progress-split.test.mjs` |
| 23 | Forecasts were never graded, so nobody knew the intervals held | every `chain.measured` also lands in `decisions.json` as `{kind:"prediction",predicted,realized,verdict}`; `summarizeCalibration` reports coverage and MAE | `tests/self23/calibration.test.mjs`; live `v7-r7` predicted 0.25, realized 0, missed |
| 24 | `candidates+1` read a single top-two gap as the value of one more draw | probability-weighted: P(second beats first) × median winning gap, Wilson interval | `tests/self23/estimator.test.mjs` |
| 25 | A stall asked once per campaign and never again; burn/near-miss looked identical | the card asks once per *window*, names its trigger (burn / near-miss / flat), and a missed negative forecast raises `chain-revert` | `tests/self23/stall-signals.test.mjs`; live second card `cp-mwhu7q2300000r` on rounds 4–6 |
| 26 | The revert card was inert: `adoptFromCheckpoint` accepted only chain/plateau | `chain-revert` is on the same one-click path | `tests/self22/l2-adopt-measure.test.mjs`; live approve activated v3 |
| 27 | The forecast ledger was displayed but never read by the next card | a prior with a miss record is stated as risk; the card prints graded / missed / coverage / MAE | `tests/self23/card-calibration.test.mjs`; `d48f08c` |
| 28 | The `burn` trigger shipped unreachable: `checkpoint.burnUsd` had no default | default 0.12 USD, `stallTrigger` extracted and tested; burn outranks near-miss, `0` disables it | `tests/self23/burn-default.test.mjs` |

### Live run (`l2live`, the instrument always prints `KILLRATE=0.000`)

1. Round 6 ended flat. The loop raised its **second** plateau card
   `cp-mwhu7q2300000r` for window 4–6 (`trigger:"flat"`, prediction 0.25 prior,
   $0.036528 spent in the window) and proposed v7 minimal-change, v8, v9, v6.
2. One approve → `chain.activated v7` with the prediction attached.
3. Round 7 ran under v7 and ended no-gain. `chain.measured` recorded
   `realized 0` against `predicted 0.25` → `missed`; `decisions.json` gained
   `v7-r7`.
4. The miss raised `chain-revert cp-mwhu8t6h00000s` proposing v3. One approve
   → `chain.activated v3` (the forecast the reverted-to chain had is carried on
   the record).

So the loop now proposes on a trigger it only fires once per window, grades its
own forecast, and offers the undo — all without a person writing a spec.

The ledger is not decoration: the next card reads it. When the proposal's
forecast is a `prior`, the card prints `past forecasts: N graded, M missed,
coverage C, MAE E`, and if more priors missed than held, the risk line says so
("treat this interval as weak"). A loop that has been wrong about its own
guesses says that on the card it is asking a person to trust.

### Benchmark: same score, 38% cheaper over three seeds

Three independent pairs of fresh clones of the same 7-failing-case repo
(seed `f1e1288`, `KILLRATE=0.364`), candidates 4, one round per arm, each pair
sequenced (base then opt). Every round in both arms promoted at score 1.0:

| seed | arm | policy | score | round cost | tokens | full attempts |
|---|---|---|---|---|---|---|
| 1 | `bench-base` | `halving:false` | 1.0 | $0.059771 | 105,694 | 2 |
| 1 | `bench-opt` | `halving:true` | 1.0 | **$0.025992** | 29,807 | 1 |
| 2 | `bench2-base` | `halving:false` | 1.0 | $0.046489 | 96,302 | 2 |
| 2 | `bench2-opt` | `halving:true` | 1.0 | **$0.034623** | 33,722 | 1 |
| 3 | `bench3-base` | `halving:false` | 1.0 | $0.021880 | 22,646 | 2 |
| 3 | `bench3-opt` | `halving:true` | 1.0 | **$0.018743** | 21,596 | 1 |
| — | **total base** | | 1.0 | **$0.128140** | 224,642 | 6 |
| — | **total opt** | | 1.0 | **$0.079358** | 85,125 | 3 |

Aggregate: **38.1% cheaper and 62.1% fewer tokens at identical scores**; the
per-pair saving is 56.5%, 25.5%, 14.3% — wide variance, because the base arm
often wins on its first attempt anyway and then pays for one or two more full
attempts, while the opt arm stops after the survivor it bought first. In seed
3 the base arm wasted $0.008588 on a second full attempt that scored 0; the
opt arm never bought it, because its screen ranked it below the winner.

The saving is not the screen itself (each screen ≈ $0.0022, two per opt round);
it is that the best-ranked survivor is bought first and its win stops the
remaining attempts. That is the mechanism the earlier 21%-more result exposed
as missing.

### What this still does not claim

- n = 3 rounds per arm, one round per campaign, one seed repo. It is a
  replicated demonstration, not a distribution; the halving-on/off pair on a
  *different* repo still showed halving costing more when a sibling wins early
  without screens.
- Screens cost ~4k tokens because they are told to answer in one line. A model
  that ignores the budget will move the number back up; the cap is a
  prompt-level instruction, not a hard API limit.
- "Better than most of the market" is a protocol claim, not a ranking: the
  plugin now reports resolved score, per-round and per-attempt spend, held-out
  checks and a graded forecast ledger — the things the published agents report.
  No cross-product benchmark was run, so no ranking is asserted.
- `tests/self2/plateau.test.mjs` had been red and outside the standing list
  (the scan skips `tests/self*`). Its malformed-round case disagreed with the
  predicate; the predicate now counts a missing record as flat, and the spec is
  pinned in `scripts/test-all.mjs`.
