const fs = require('fs')
const path = require('path')
const root = process.argv[2] || '.'
const yaml = require('C:/Users/Administrator/AppData/Roaming/npm/node_modules/@deepseek-ai/dsh/node_modules/js-yaml')

const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'))
const checks = []
checks.push(['name', typeof pkg.name === 'string'])
checks.push(['main', pkg.main === 'lib/index.js'])
checks.push(['type module', pkg.type === 'module'])
checks.push(['dsh.bundle.patch', pkg.dsh && pkg.dsh.bundle && pkg.dsh.bundle.patch === './cordis.patch.yml'])
checks.push(['dsh.client.platform', pkg.dsh && pkg.dsh.client && pkg.dsh.client.platform === 'web'])
checks.push(['exports ./client', !!(pkg.exports && pkg.exports['./client'] && pkg.exports['./client'].default === './lib/client.js')])
checks.push(['exports ./cordis.patch.yml', pkg.exports && pkg.exports['./cordis.patch.yml'] === './cordis.patch.yml'])
checks.push(['main file exists', fs.existsSync(path.join(root, 'lib', 'index.js'))])
checks.push(['client file exists', fs.existsSync(path.join(root, 'lib', 'client.js'))])

const patch = yaml.load(fs.readFileSync(path.join(root, 'cordis.patch.yml'), 'utf8'))
checks.push(['patch is array', Array.isArray(patch)])
const ins = patch && patch[0] && patch[0].insert
checks.push(['patch insert present', Array.isArray(ins)])
checks.push(['patch row id', ins && ins[0] && ins[0].id === 'dsh-macos-desktop'])
checks.push(['patch row name', ins && ins[0] && ins[0].name === 'dsh-macos-desktop'])

let ok = true
for (const [label, pass] of checks) {
  console.log((pass ? 'PASS ' : 'FAIL ') + label)
  if (!pass) ok = false
}
process.exit(ok ? 0 : 1)
