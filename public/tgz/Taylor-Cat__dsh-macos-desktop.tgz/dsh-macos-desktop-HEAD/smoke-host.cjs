// Runtime smoke test for the host half: imports lib/index.js, calls apply()
// with a mock ctx, and asserts the routes register and teardown is reversible.
// Resolves lib/index.js relative to this script so the folder can live anywhere.
const { pathToFileURL } = require('node:url')
const { join } = require('node:path')
const entry = pathToFileURL(join(__dirname, 'lib', 'index.js')).href
import(entry)
  .then(({ name, inject, apply }) => {
    const registered = []
    const mock = {
      webServer: { register: (route) => { registered.push(route.path); return () => {} } },
      fs: {},
      shell: {},
      subprocess: {},
      get: () => undefined,
      effect: (cb) => { const disposer = cb(); return () => { if (typeof disposer === 'function') disposer() } },
    }
    apply(mock)
    const expected = [
      '/dsh-macos-desktop/api/list', '/dsh-macos-desktop/api/read', '/dsh-macos-desktop/api/write', '/dsh-macos-desktop/api/upload',
      '/dsh-macos-desktop/api/mkdir', '/dsh-macos-desktop/api/rename', '/dsh-macos-desktop/api/delete',
      '/dsh-macos-desktop/api/desktop',
      '/dsh-macos-desktop/api/trash/list', '/dsh-macos-desktop/api/trash/restore', '/dsh-macos-desktop/api/trash/empty',
      '/dsh-macos-desktop/file',
      '/dsh-macos-desktop/api/doc/read-docx', '/dsh-macos-desktop/api/doc/read-docx-html', '/dsh-macos-desktop/api/doc/read-pdf',
      '/dsh-macos-desktop/api/doc/create-docx', '/dsh-macos-desktop/api/doc/create-pdf', '/dsh-macos-desktop/api/doc/create-pptx',
      '/dsh-macos-desktop/api/vision', '/dsh-macos-desktop/api/gen-image',
      '/dsh-macos-desktop/api/stats', '/dsh-macos-desktop/api/search',
      '/dsh-macos-desktop/api/balance', '/dsh-macos-desktop/api/about',
      '/dsh-macos-desktop/api/kb/list', '/dsh-macos-desktop/api/kb/create',
      '/dsh-macos-desktop/api/kb/delete', '/dsh-macos-desktop/api/kb/rename',
      '/dsh-macos-desktop/api/terminal/spawn', '/dsh-macos-desktop/api/terminal/stream',
      '/dsh-macos-desktop/api/terminal/input', '/dsh-macos-desktop/api/terminal/signal',
      '/dsh-macos-desktop/api/terminal/kill',
    ]
    const missing = expected.filter((p) => registered.indexOf(p) < 0)
    const extra = registered.filter((p) => expected.indexOf(p) < 0)
    console.log('name:', name)
    console.log('inject:', JSON.stringify(inject))
    console.log('routes registered:', registered.length)
    console.log('missing:', JSON.stringify(missing))
    console.log('extra:', JSON.stringify(extra))
    if (missing.length || extra.length || registered.length !== expected.length) {
      console.log('FAIL')
      process.exit(1)
    }
    console.log('PASS apply() registered exactly ' + expected.length + ' routes with no throw')
  })
  .catch((e) => { console.error('FAIL', e); process.exit(1) })
