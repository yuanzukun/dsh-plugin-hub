# dsh-git-sidebar

🌐 **English** | [简体中文](./README.md)

> 🧭 **A "uncommitted changes" sidebar for the DSH conversation page**: extracted from `dsh-git-studio`, keeping only the conversation sidebar part and removing the Git graph features (commit history graph, branch filtering, commit details, etc.).

An embedded Git workspace changes sidebar plugin for the DeepSeek Harness (DSH) Web GUI.

It docks a VSCode-style uncommitted changes panel on the right side of the conversation page: three file groups (Staged / Changes / Untracked), status badges, per-file `+/−` line counts, click-to-expand single-file diff, renames as `old → new`, direct content preview for untracked files, and the ability to open a file with the system default application.

## 📸 Screenshot

![dsh-git-sidebar screenshot](./screenshot.png)

## ✨ Features

- **Follows the current conversation**: shows the Git repository of whichever conversation workspace is open, and automatically follows conversation switches; non-Git conversations show an empty state
- **Uncommitted changes (VSCode style)**: three file groups — Staged / Changes / Untracked — with status badges (A/M/D/R/U/?), per-file `+/−` line counts, click-to-expand single-file diff, renames as `old → new`, and direct content preview for untracked files
- **☑ Group toggles**: hide any group independently; both the panel and groups can be collapsed by clicking
- **Right-side docked module**: draggable width, with width and collapsed state persisted; when collapsed, only a narrow handle is shown — content is not rendered and no requests are made; it automatically yields when the host tool detail panel opens
- **Open file**: after expanding a file row, open that file with the system default application
- **Light/dark theme**: automatically follows the harness UI theme

## 📦 Installation

### 1. Add the plugin to your profile

Edit your DSH web profile's `package.json` and add the dependency:

```json
{
  "dependencies": {
    "dsh-git-sidebar": "file:./plugins/git-sidebar"
  }
}
```

(`plugins/git-sidebar` is the directory containing this plugin's source; adjust it to your actual path.)

### 2. Mount the bundle

Add the following to your profile's `cordis.patch.yml`:

```yaml
- insert:
    - id: git-sidebar
      name: dsh-git-sidebar
      config:
        repo: "C:/path/to/your/repo"
```

> `config.repo` / `config.repos` is the initial allowlist of accessible repositories; repositories discovered from session workspaces at runtime are also added to the accessible set automatically.

### 3. Install and restart

```bash
pnpm install
# then restart dsh web
```

Open http://127.0.0.1:3080 and you will see the "Uncommitted Changes" sidebar on the right side of any conversation page.

## 🛠️ Development

```
git-sidebar/
├── index.js          # Server: git API (repos/workstatus/workfile/openfile)
├── client.js         # Client plugin: "Uncommitted Changes" sidebar on the conversation page
├── package.json      # Plugin manifest (dsh.client.inject + bundle patch)
├── dsh.plugin.json   # Official DSH plugin manifest
└── cordis.patch.yml  # Profile mount point
```

After modifying the server (`index.js`) or client (`client.js`), restart dsh web.

## 📄 License

[MIT](./LICENSE)
