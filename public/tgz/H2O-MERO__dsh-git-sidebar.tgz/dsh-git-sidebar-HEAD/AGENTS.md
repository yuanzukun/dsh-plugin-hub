# AGENTS.md — dsh-git-sidebar 开发指南

本文件面向在本仓库中工作的 AI 代理与人类开发者，说明项目结构、开发流程与约定。

## 项目是什么

dsh-git-sidebar 是从 `dsh-git-studio` 提取出的「对话侧边栏」插件：

- **对话页右侧「未提交改动」模块**：注册到 `shell.overlay` 插槽，VSCode 风格分组文件列表 + 按需加载单文件 diff，可拖宽、折叠态不渲染不请求
- **服务端只读 git API**：`execFile` 固定参数执行（无 shell），仓库路径白名单 + 会话工作区发现
- **不含 Git 图谱**：没有 `conversation.view` 标签、没有 `web/index.html`、没有 graph/branches/show/diff/filediff 等图谱 API

## 目录结构

```
├── index.js          # 服务端（Host 半）：注册 /git-sidebar 前缀路由
├── client.js         # 客户端（浏览器半）：注册 shell.overlay 右侧未提交改动模块
├── package.json      # npm 清单（dsh.client.inject + dsh.bundle.patch）
├── dsh.plugin.json   # DSH 官方插件清单（id: dsh-external/dsh-git-sidebar）
├── cordis.patch.yml  # profile 挂载点（config.repo 为仓库白名单，示例路径）
├── README.md
└── LICENSE           # MIT
```

## 服务端 API（index.js）

`GET /git-sidebar/api?op=<op>&repo=<path>[&...]`，op 列表：

| op | 用途 | 关键参数 |
| --- | --- | --- |
| `repos` | 会话工作区向上定位 git 根 + 白名单兜底 | `ws` |
| `workstatus` | 未提交改动分组列表（porcelain -z + numstat -z） | — |
| `workfile` | 单文件 diff / 未跟踪内容 | `file`、`staged`(`0`\|`1`\|`untracked`)、`old`(重命名旧路径) |
| `openfile` | 用系统默认应用打开工作区文件 | `file` |

## 关键约定

- **安全**：git 一律 `execFile` 固定参数数组，绝不拼接 shell；`workfile` 用 `path.resolve` + `startsWith` 防路径穿越；长输出截断（`MAX_DIFF_CHARS`）
- **客户端**：纯 JS + `React.createElement`（无 JSX/TSX 转换）；Slot 注册用 `ctx.slots.register`；`inject` 只声明实际使用的服务
- **未提交改动**：分组（staged 按 X 码、unstaged 按 Y 码、`??` 为未跟踪、冲突码 `U`）；`workfile` 按需加载 + 客户端缓存（`diffCache`）；无改动时显示「✓ 工作区干净」；分组显隐由 `show` 状态控制（顶栏 ☑ 分组菜单），面板/分组折叠用 `userFolded` / `groupFolded`；折叠时内容组件不挂载，不发请求
- **解析细节**：`porcelain -z` 重命名两条记录（`XY <新路径>` + `<旧路径>`）；`numstat -z` 重命名为 `n\tn` + 旧路径 + 新路径；Windows 路径先 `replace(/\\/g,'/')` 再比较

## 开发与验证流程

1. 修改源码（`index.js` / `client.js`）
2. 语法校验：`node --check index.js client.js`
3. 同步到部署目录（按你的 DSH profile 实际路径）
4. `index.js` / `client.js` 改动需重启 dsh web
5. 服务端功能测试：构造场景仓库（staged / unstaged / untracked / rename / MM / 删除），用 mock `webServer` 直接调 handler 断言 JSON；页面级用临时 http server + 浏览器验证
6. 版本节奏：功能迭代 → `package.json` / `dsh.plugin.json` version 同步 → `git commit` → `git tag vX.Y`

## 注意

- 提交前检查：不要把本地绝对路径（如 `D:/...`、`C:\Users\<用户名>\...`）写进 `cordis.patch.yml` / README —— 开源仓库使用示例路径占位
- `.gitignore` 已排除 `node_modules/`、`*.log`、`.DS_Store`、`.playwright-mcp/`（浏览器测试残留）
