/**
 * dsh-cue-plugin — node half.
 *
 * An `agent/pre-step` listener (prepend: true) that parses `dsh-cue:` mentions
 * from the incoming prompt, rewrites them to an explicit reference marker the
 * model can read, and injects the captured node context as a
 * `session-reference` recall message the transcript renders as a distinct
 * "Session recall" row — the model and the user can both tell referenced
 * context apart from native conversation.
 *
 * Extraction is capture-time: the browser builds the context snapshot the
 * moment the user confirms a cue and ships it inside the mention payload, so
 * this half never re-reads a source session and the model never has to search
 * for the referenced content itself.
 */

import type { PreStepDecision } from '@deepseek-ai/dsh-agent'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'

declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    /**
     * Cross-session reference material (the cue plugin): the transcript
     * renders it under "Session recall" with one reference row per source.
     */
    'session-reference': {
      readonly kind: 'session-reference'
      readonly form: 'recall'
      readonly references: readonly {
        readonly label: string
        readonly retainedMessages: number
        readonly omittedMessages: number
        readonly truncated: boolean
      }[]
    }
  }
}

export const name = 'dsh-cue'
export const inject: string[] = []

/**
 * Structural stand-in for the cordis Context the Loader hands to apply()
 * (`@deepseek-ai/cordis` is a private vendored package, not installable here).
 */
export interface CueContext {
  on(
    event: 'agent/pre-step',
    listener: (payload: PreStepPayload, next: () => Promise<PreStepDecision>) => Promise<PreStepDecision>,
    options?: { prepend?: boolean },
  ): unknown
}

/** Subset of the `agent/pre-step` payload this plugin reads. */
export interface PreStepPayload {
  readonly agent: { readonly session: { readonly id: string } }
  readonly messages: readonly { readonly content: readonly ContentBlock[] }[]
  readonly signal: AbortSignal
}

/** One captured context row shipped inside the mention payload. */
interface CueContextEntry {
  readonly seq: number
  readonly role: 'user' | 'assistant'
  readonly text: string
}

/** One decoded mention payload. */
interface CueMention {
  readonly sourceSessionId: string
  readonly label: string
  readonly seqs: number[]
  readonly context: CueContextEntry[]
}

/** Joined text of every text block in a content array. */
function textOf(content: readonly ContentBlock[]): string {
  return content.flatMap(block => block.type === 'text' ? [block.text] : []).join('\n')
}

/** Full marker form: `[cue 引用：@label #1 #2](dsh-cue:<token>)`. */
const FULL_MENTION = /\[cue 引用：([^\n\]]*)\]\(dsh-cue:([A-Za-z0-9%._~-]+)\)/g

/** Legacy forms: `@[label](dsh-cue:<token>)` and bare `dsh-cue:<token>`. */
const PARTIAL_MENTION = /(?:@\[([^\]\n]+)\]\()?dsh-cue:([A-Za-z0-9%._~-]+)\)?/g

/** Decode one prompt string into structured cue mentions (both forms, deduped). */
function parseMentions(text: string): CueMention[] {
  const mentions: CueMention[] = []
  const seen = new Set<string>()
  for (const pattern of [FULL_MENTION, PARTIAL_MENTION]) {
    for (const match of text.matchAll(pattern)) {
      const label = match[1]
      const token = match[2]
      if (token === undefined || seen.has(token)) continue
      seen.add(token)
      try {
        const parsed = JSON.parse(decodeURIComponent(token)) as Partial<CueMention>
        if (typeof parsed.sourceSessionId !== 'string' || parsed.sourceSessionId === '') continue
        if (!Array.isArray(parsed.seqs) || parsed.seqs.length === 0) continue
        if (!Array.isArray(parsed.context)) continue
        const context = parsed.context.filter((entry): entry is CueContextEntry => {
          if (typeof entry !== 'object' || entry === null) return false
          const candidate = entry as Partial<CueContextEntry>
          return Number.isSafeInteger(candidate.seq)
            && (candidate.role === 'user' || candidate.role === 'assistant')
            && typeof candidate.text === 'string'
        })
        if (context.length === 0) continue
        mentions.push({
          sourceSessionId: parsed.sourceSessionId,
          label: typeof parsed.label === 'string' && parsed.label !== '' ? parsed.label : label ?? parsed.sourceSessionId,
          seqs: parsed.seqs.filter(Number.isSafeInteger),
          context,
        })
      } catch {
        // Malformed token: treat as ordinary text.
      }
    }
  }
  return mentions
}

/** Read the label/seqs out of one mention token, with a fallback label. */
function mentionFacts(token: string, fallbackLabel: string): { label: string; seqs: number[] } {
  let label = fallbackLabel
  let seqs: number[] = []
  try {
    const parsed = JSON.parse(decodeURIComponent(token)) as { label?: string; seqs?: number[] }
    label = parsed.label ?? label
    seqs = parsed.seqs ?? []
  } catch {
    // Malformed token: keep the fallback label.
  }
  return { label, seqs }
}

/**
 * Rewrite machine-readable mentions into an explicit reference marker so the
 * model knows a cue happened: `[cue 引用：@label #1 #2](dsh-cue:…)` (and the
 * legacy `@[label](dsh-cue:…)` form) → `[cue 引用：@label #1 #2]`.
 * @param text - one prompt text block.
 * @returns the rewritten text.
 */
function rewriteMentions(text: string): string {
  const full = text.replace(FULL_MENTION, (_match, inlineLabel: string, token: string) => {
    const { label, seqs } = mentionFacts(token, inlineLabel)
    return seqs.length === 0 ? `[cue 引用：@${label}]` : `[cue 引用：@${label} #${seqs.join(' #')}]`
  })
  return full.replace(PARTIAL_MENTION, (_match, label: string | undefined, token: string) => {
    const { label: resolvedLabel, seqs } = mentionFacts(token, label ?? 'cue')
    return seqs.length === 0 ? `[cue 引用：@${resolvedLabel}]` : `[cue 引用：@${resolvedLabel} #${seqs.join(' #')}]`
  })
}

/** Register the pre-step listener. */
export function apply(ctx: CueContext): void {
  ctx.on('agent/pre-step', async ({ agent, messages, signal }, next): Promise<PreStepDecision> => {
    const decision = await next()
    if (decision.kind === 'reject' || signal.aborted) return decision

    const mentions: CueMention[] = []
    for (const message of messages) {
      mentions.push(...parseMentions(textOf(message.content)))
    }
    if (mentions.length === 0) return decision

    // One chip per node run → group by source session so each source
    // contributes one deduped recall message.
    const grouped = new Map<string, { label: string; seqs: number[]; context: CueContextEntry[] }>()
    for (const mention of mentions) {
      const entry = grouped.get(mention.sourceSessionId)
      if (entry === undefined) {
        grouped.set(mention.sourceSessionId, { label: mention.label, seqs: [...mention.seqs], context: [...mention.context] })
      } else {
        entry.seqs.push(...mention.seqs)
        entry.context.push(...mention.context)
      }
    }

    const additional = []
    for (const [sourceId, group] of grouped) {
      if (sourceId === agent.session.id) continue
      const seqs = [...new Set(group.seqs)].sort((a, b) => a - b)
      const contextById = new Map<number, CueContextEntry>()
      for (const entry of group.context) {
        if (!contextById.has(entry.seq)) contextById.set(entry.seq, entry)
      }
      const context = [...contextById.values()].sort((a, b) => a.seq - b.seq)
      if (context.length === 0) continue
      const detailed = context.map(entry => `${entry.role === 'user' ? '用户' : 'agent'} #${entry.seq}: ${entry.text}`).join('\n')
      additional.push(createUserMessage({
        content: [{ type: 'text', text: `## Cued nodes from ${group.label}\n\n用户 cue 引用了以下结点，请把它们作为跨会话参考上下文阅读：\n\n${detailed}` }],
        source: {
          kind: 'session-reference',
          form: 'recall',
          references: [{ label: group.label, retainedMessages: context.length, omittedMessages: 0, truncated: false }],
        },
      }))
    }
    if (additional.length === 0) return decision
    // The model never sees the machine-readable URI: rewrite the direct
    // messages to readable cue markers before the step processes them.
    const rewritten = decision.messages.map(message => ({
      ...message,
      content: message.content.map(block =>
        block.type === 'text' ? { ...block, text: rewriteMentions(block.text) } : block,
      ),
    }))
    return { kind: 'enter', messages: [...additional, ...rewritten] }
  }, { prepend: true })
}
