/**
 * Composer tool-row trigger plus the two-level node picker. The button lives
 * in `conversation.input.left`; clicking it opens a bounded modal (portaled to
 * body) that lists sessions by title, then their USER nodes (click to toggle,
 * drag to box-select, 全选/清空 for batch), and confirms by inserting one
 * wrapped `dsh-cue:` chip per consecutive run — the context snapshot is
 * captured right here at cue time and shipped inside the chip payload, so the
 * host never re-reads the source session and the model never searches for the
 * content itself.
 *
 * Standalone bundle: styles are inline (no CSS module build step).
 */

import { createElement, useEffect, useRef, useState } from 'react'
import type { MouseEvent, ReactElement } from 'react'
import { createPortal } from 'react-dom'
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { IApiClient, SessionSummary } from '@deepseek-ai/dsh-client-connection/client'
import type { ReferenceInsert } from '@deepseek-ai/dsh-client-ui-input-trigger/client'

/** Narrow inject face threaded into the button. */
export interface CueButtonInject {
  readonly api: IApiClient
  readonly insert: (refs: readonly ReferenceInsert[]) => void
}

/** One conversation node (user prompt or assistant answer). */
interface CueNode {
  readonly seq: number
  readonly role: 'user' | 'assistant'
  readonly text: string
}

/** Context window width before each selected node. */
const CONTEXT_WIDTH = 3

/** Inline styles for the picker (local coordinates, no design tokens). */
const styles = {
  root: { position: 'relative', display: 'inline-flex' },
  trigger: {
    border: '1px solid rgba(127, 127, 127, .35)', borderRadius: 6, background: 'transparent',
    color: 'inherit', padding: '4px 12px', cursor: 'pointer', fontSize: 13,
  },
  backdrop: {
    position: 'fixed', inset: 0, background: 'rgba(0, 0, 0, .35)', display: 'flex',
    alignItems: 'center', justifyContent: 'center', zIndex: 1000,
  },
  panel: {
    background: '#fff', color: '#111', borderRadius: 10, width: 520, maxWidth: '92vw',
    maxHeight: '72vh', display: 'flex', flexDirection: 'column', overflow: 'hidden', boxShadow: '0 12px 40px rgba(0, 0, 0, .25)',
  },
  head: { display: 'flex', alignItems: 'center', gap: 8, padding: '10px 12px', borderBottom: '1px solid #e5e5e5' },
  title: { flex: 1, fontWeight: 600, fontSize: 14, textAlign: 'center' },
  headBtn: { border: '1px solid rgba(127, 127, 127, .35)', borderRadius: 6, background: 'transparent', color: '#111', padding: '4px 10px', cursor: 'pointer', fontSize: 13 },
  primary: { border: '1px solid transparent', borderRadius: 6, background: '#3b82f6', color: '#fff', padding: '4px 12px', cursor: 'pointer', fontSize: 13 },
  list: { flex: 1, overflowY: 'auto', padding: 8, display: 'flex', flexDirection: 'column', gap: 4, userSelect: 'none' },
  opt: { textAlign: 'left', border: 'none', background: 'transparent', color: '#111', borderRadius: 6, padding: '8px 10px', cursor: 'pointer', fontSize: 13 },
  optHover: { background: '#f2f4f7' },
  body: { display: 'flex', flexDirection: 'column', minHeight: 0, flex: 1 },
  tools: { display: 'flex', gap: 8, padding: '8px 12px 0' },
  toolBtn: { border: '1px solid rgba(127, 127, 127, .35)', borderRadius: 6, background: 'transparent', color: '#111', padding: '4px 10px', cursor: 'pointer', fontSize: 13 },
  error: { padding: 16, fontSize: 13, color: '#b91c1c' },
  node: { textAlign: 'left', border: 'none', background: 'transparent', color: '#111', borderRadius: 6, padding: '6px 8px', cursor: 'pointer', fontSize: 13, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  nodeSel: { background: '#dbeafe', color: '#1d4ed8' },
  marquee: { position: 'fixed', border: '1px dashed #3b82f6', background: 'rgba(59, 130, 246, .08)', pointerEvents: 'none', zIndex: 1001 },
  selectedPane: { borderTop: '1px solid #e5e5e5', maxHeight: 160, display: 'flex', flexDirection: 'column', minHeight: 0 },
  selectedHead: { padding: '6px 12px', fontSize: 12, color: '#666' },
  selectedList: { overflowY: 'auto', padding: '0 12px 8px', display: 'flex', flexDirection: 'column', gap: 2 },
  selectedRow: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, padding: '2px 0' },
  selectedText: { flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  xbtn: { border: 'none', background: 'transparent', color: '#666', cursor: 'pointer', fontSize: 14, padding: '0 4px' },
} as const

function textOf(blocks: readonly { type: string; text?: string }[]): string {
  return blocks.flatMap(block => block.type === 'text' && typeof block.text === 'string' ? [block.text] : []).join('\n')
}

/** Project raw history events into user/assistant nodes. */
function projectNodes(events: readonly { event: { seq: number; type: string; data: unknown } }[]): CueNode[] {
  const nodes: CueNode[] = []
  for (const entry of events) {
    const event = entry.event as {
      seq: number
      type: string
      data: {
        source?: { kind?: string }
        content?: readonly { type: string; text?: string }[]
        message?: { content?: readonly { type: string; text?: string }[] }
      }
    }
    if (event.type === 'user/message') {
      if (event.data.source?.kind !== 'user') continue
      const text = textOf(event.data.content ?? [])
      if (text !== '') nodes.push({ seq: event.seq, role: 'user', text })
    } else if (event.type === 'assistant/message') {
      const text = textOf(event.data.message?.content ?? [])
      if (text !== '') nodes.push({ seq: event.seq, role: 'assistant', text })
    }
  }
  return nodes
}

/** Readable title for one session summary: title → sessionId fallback. */
function titleOf(item: SessionSummary): string {
  const values = item.projections?.values as { title?: string | null } | undefined
  return values?.title ?? item.sessionId
}

/** Fetch every history page of a session and project its nodes. */
async function loadAllNodes(
  api: IApiClient,
  sessionId: SessionSummary['sessionId'],
): Promise<{ nodes: CueNode[]; error: boolean }> {
  const pages: { event: { seq: number; type: string; data: unknown } }[][] = []
  let beforeSeq: number | undefined
  let failed = false
  for (;;) {
    const response = await api.sessions.history({
      sessionId,
      ...(beforeSeq === undefined ? {} : { beforeSeq }),
      maxMessages: 200,
    })
    if (!response.result.ok) {
      failed = true
      break
    }
    const page = response.result.value.events
    pages.unshift(page)
    if (!response.result.value.hasMore || page.length === 0) break
    const first = page[0]
    if (first === undefined) break
    beforeSeq = first.event.seq
  }
  return { nodes: projectNodes(pages.flat()), error: failed }
}

/** Merge selected USER nodes that are adjacent in the list into runs. */
function mergeRuns(userNodes: readonly CueNode[], selected: ReadonlySet<number>): CueNode[][] {
  const runs: CueNode[][] = []
  for (const node of userNodes) {
    if (!selected.has(node.seq)) continue
    const last = runs[runs.length - 1]
    if (last === undefined) runs.push([node])
    else last.push(node)
  }
  return runs
}

/** Deduped context window (user commands + agent answers) before a run's seqs. */
function buildWindow(nodes: readonly CueNode[], seqs: readonly number[], width: number): CueNode[] {
  const indexOf = new Map(nodes.map((node, index) => [node.seq, index]))
  const windows = seqs.map(seq => {
    const index = indexOf.get(seq) ?? -1
    return { lo: Math.max(0, index - width + 1), hi: index }
  }).sort((a, b) => a.lo - b.lo)
  const merged: { lo: number; hi: number }[] = []
  for (const window of windows) {
    const last = merged[merged.length - 1]
    if (last !== undefined && window.lo <= last.hi + 1) last.hi = Math.max(last.hi, window.hi)
    else merged.push({ lo: window.lo, hi: window.hi })
  }
  const out: CueNode[] = []
  for (const range of merged) {
    for (let index = range.lo; index <= range.hi; index += 1) {
      const node = nodes[index]
      if (node !== undefined) out.push(node)
    }
  }
  return out
}

/** Tool-row button + picker modal. */
export function CueButton({ sessionId, api, insert }: PropsRuntime<'conversation.input.left'> & CueButtonInject): ReactElement {
  const [open, setOpen] = useState(false)
  const [sessions, setSessions] = useState<readonly SessionSummary[]>([])
  const [source, setSource] = useState<SessionSummary | null>(null)
  const [nodes, setNodes] = useState<readonly CueNode[]>([])
  const [selected, setSelected] = useState<ReadonlySet<number>>(new Set())
  const [marquee, setMarquee] = useState<{ x1: number; y1: number; x2: number; y2: number } | null>(null)
  const [loadError, setLoadError] = useState(false)
  const nodeRefs = useRef(new Map<number, HTMLButtonElement>())

  const userNodes = nodes.filter(node => node.role === 'user')

  useEffect(() => {
    if (!open) return
    void api.sessions.list({}).then(response => {
      if (response.result.ok) setSessions(response.result.value.items.filter(item => item.sessionId !== sessionId))
    })
  }, [api, open, sessionId])

  useEffect(() => {
    if (source === null) return
    setNodes([])
    setSelected(new Set())
    setLoadError(false)
    void loadAllNodes(api, source.sessionId).then(result => {
      setNodes(result.nodes)
      setLoadError(result.error)
    })
  }, [api, source])

  const toggle = (seq: number): void => {
    const next = new Set(selected)
    if (next.has(seq)) next.delete(seq)
    else next.add(seq)
    setSelected(next)
  }

  const confirm = (): void => {
    if (source === null || selected.size === 0) return
    const label = titleOf(source)
    const refs: ReferenceInsert[] = mergeRuns(userNodes, selected).map(run => {
      const seqs = run.map(node => node.seq)
      const context = buildWindow(nodes, seqs, CONTEXT_WIDTH)
      const payload = JSON.stringify({
        sourceSessionId: source.sessionId,
        label,
        seqs,
        context: context.map(node => ({ seq: node.seq, role: node.role, text: node.text })),
      })
      const chipLabel = run.length === 1
        ? `#${run[0]?.seq ?? ''} ${run[0]?.text ?? ''}`
        : `#${run[0]?.seq ?? ''}–#${run[run.length - 1]?.seq ?? ''} · ${run.length} 个结点`
      return {
        source: 'cue',
        ref: payload,
        label: chipLabel,
        clipboardText: `@${label} #${seqs.join(',')}`,
      }
    })
    insert(refs)
    setOpen(false)
    setSource(null)
    setSelected(new Set())
  }

  const onListMouseDown = (event: MouseEvent): void => {
    if ((event.target as HTMLElement).closest('button') !== null) return
    setMarquee({ x1: event.clientX, y1: event.clientY, x2: event.clientX, y2: event.clientY })
  }
  const onListMouseMove = (event: MouseEvent): void => {
    if (marquee !== null) setMarquee({ ...marquee, x2: event.clientX, y2: event.clientY })
  }
  const onListMouseUp = (): void => {
    if (marquee === null) return
    const rect = {
      l: Math.min(marquee.x1, marquee.x2), r: Math.max(marquee.x1, marquee.x2),
      t: Math.min(marquee.y1, marquee.y2), b: Math.max(marquee.y1, marquee.y2),
    }
    const hits = new Set<number>()
    nodeRefs.current.forEach((element, seq) => {
      const bounds = element.getBoundingClientRect()
      if (bounds.left < rect.r && bounds.right > rect.l && bounds.top < rect.b && bounds.bottom > rect.t) hits.add(seq)
    })
    setMarquee(null)
    if (hits.size > 0) setSelected(new Set([...selected, ...hits]))
  }

  const modal = open ? createPortal(
    createElement('div', { style: styles.backdrop, onClick: () => { setOpen(false); setSource(null) } },
      createElement('div', { style: styles.panel, onClick: (event: MouseEvent) => event.stopPropagation() },
        createElement('div', { style: styles.head },
          createElement('button', { type: 'button', style: styles.headBtn, onClick: () => { if (source === null) setOpen(false); else setSource(null) } }, source === null ? '取消' : '← 返回'),
          createElement('span', { style: styles.title }, source === null ? '选择目标对话' : `选择结点 · 已选 ${selected.size}`),
          source === null ? null : createElement('button', { type: 'button', style: styles.primary, onClick: confirm }, 'cue 这些结点'),
        ),
        source === null
          ? createElement('div', { style: styles.list },
            sessions.map(item => createElement('button', { key: item.sessionId, style: styles.opt, type: 'button', onClick: () => setSource(item) }, titleOf(item))),
          )
          : createElement('div', { style: styles.body },
            createElement('div', { style: styles.tools },
              createElement('button', { type: 'button', style: styles.toolBtn, onClick: () => setSelected(new Set(userNodes.map(node => node.seq))) }, '全选'),
              createElement('button', { type: 'button', style: styles.toolBtn, onClick: () => setSelected(new Set()) }, '清空'),
            ),
            loadError
              ? createElement('div', { style: styles.error }, '历史加载失败：该会话可能是由其它版本的 harness 写入的，无法读取其结点。请选择其它会话。')
              : createElement('div', { style: styles.list, onMouseDown: onListMouseDown, onMouseMove: onListMouseMove, onMouseUp: onListMouseUp },
                userNodes.map(node => createElement('button', {
                  key: node.seq,
                  ref: (element: HTMLButtonElement | null): void => { if (element !== null) nodeRefs.current.set(node.seq, element) },
                  style: selected.has(node.seq) ? { ...styles.node, ...styles.nodeSel } : styles.node,
                  type: 'button',
                  onClick: () => toggle(node.seq),
                }, `#${node.seq} ${node.text.slice(0, 40)}`)),
                marquee === null ? null : createElement('div', {
                  style: {
                    ...styles.marquee,
                    left: Math.min(marquee.x1, marquee.x2),
                    top: Math.min(marquee.y1, marquee.y2),
                    width: Math.abs(marquee.x2 - marquee.x1),
                    height: Math.abs(marquee.y2 - marquee.y1),
                  },
                }),
              ),
            createElement('div', { style: styles.selectedPane },
              createElement('div', { style: styles.selectedHead }, `已选 ${selected.size} 个结点`),
              createElement('div', { style: styles.selectedList },
                userNodes.filter(node => selected.has(node.seq)).map(node => createElement('div', { style: styles.selectedRow, key: node.seq },
                  createElement('span', { style: styles.selectedText }, `#${node.seq} ${node.text}`),
                  createElement('button', { type: 'button', style: styles.xbtn, onClick: () => toggle(node.seq) }, '×'),
                )),
              ),
            ),
          ),
      ),
    ),
    document.body,
  ) : null

  return createElement('div', { style: styles.root },
    createElement('button', { style: styles.trigger, type: 'button', onClick: () => setOpen(true) }, 'cue'),
    modal,
  )
}
