/**
 * dsh-cue-plugin — browser half.
 *
 * Registers the composer tool-row trigger plus the '@' cue reference source
 * whose codec serializes chips to `dsh-cue:` mentions. The context snapshot is
 * captured at cue time inside the chip payload, so the node half never
 * re-reads the source session.
 */

import type { ClientContext, ISessions, SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type {
  InputTriggerServiceContract, InputTriggerSource, ReferenceInsert,
} from '@deepseek-ai/dsh-client-ui-input-trigger/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import { CueButton } from './CueButton.tsx'
import type { CueButtonInject } from './CueButton.tsx'

export const inject = ['connection', 'slots', 'inputTriggers', 'sessions']

/**
 * URI-escape one mention payload for embedding into the serialized marker.
 * encodeURIComponent leaves `()` `'` `!` `*` unescaped; the host token
 * scanner stops at a literal `(`, so escape them here.
 */
function escapeToken(ref: string): string {
  return encodeURIComponent(ref).replace(/[()'!*]/g, c => `%${c.charCodeAt(0).toString(16).toUpperCase()}`)
}

/**
 * The '@' cue source: registered for its codec (chip serialization on
 * submit). The menu itself advertises no candidates — cue is button-driven.
 */
const cueSource: InputTriggerSource = {
  trigger: '@',
  name: 'cue',
  order: 10,
  async candidates() {
    return []
  },
  onPick() {
    return undefined
  },
  codec: {
    clipboardText(ref) {
      try {
        const parsed = JSON.parse(ref) as { label?: string; seqs?: number[] }
        return `@${parsed.label ?? 'cue'} #${(parsed.seqs ?? []).join(',')}`
      } catch {
        return ref
      }
    },
    async serialize(ref, _signal) {
      let label = 'cue'
      try {
        label = (JSON.parse(ref) as { label?: string }).label ?? 'cue'
      } catch {
        // Malformed ref: keep the fallback label.
      }
      const seqs = (() => {
        try {
          const parsed = JSON.parse(ref) as { seqs?: number[] }
          return Array.isArray(parsed.seqs) ? parsed.seqs : []
        } catch {
          return []
        }
      })()
      const marker = seqs.length === 0 ? `@${label}` : `@${label} #${seqs.join(' #')}`
      return `[cue 引用：${marker}](dsh-cue:${escapeToken(ref)})`
    },
  },
}

/** Per-session input facade surface: draft read + reference insertion. */
interface InputFace {
  readonly state: { getSnapshot(): { draft: string; draftRev: number } }
  insertReference(ref: ReferenceInsert, span: { start: number; end: number; draftRev: number }): boolean
}

/** Insert one chip per reference at the end of the composer draft. */
function insertReferences(ctx: ClientContext, sessionId: SessionId, refs: readonly ReferenceInsert[]): void {
  const sessions = ctx.get('sessions') as unknown as ISessions | undefined
  if (sessions === undefined) {
    console.error('[cue] insert: no sessions service')
    return
  }
  const actx = sessions.scope(sessionId)
  if (actx === undefined) {
    console.error('[cue] insert: no session scope for', String(sessionId))
    return
  }
  const conversation = ctx.get('conversation') as { input: { for(actx: ClientContext): InputFace } } | undefined
  const input = conversation?.input.for(actx)
  if (input === undefined) {
    console.error('[cue] insert: no input facade for', String(sessionId))
    return
  }
  for (const reference of refs) {
    const state = input.state.getSnapshot()
    const applied = input.insertReference(reference, {
      start: state.draft.length,
      end: state.draft.length,
      draftRev: state.draftRev,
    })
    if (!applied) console.error('[cue] insertReference not applied:', reference.label)
  }
}

/** Inject face for the trigger button: the shared api client plus chip insert. */
function cueInject(ctx: ClientContext, sessionId: SessionId): CueButtonInject {
  const handle = ctx.get('connection') as ConnectionHandle | undefined
  if (handle === undefined) throw new Error('[cue] connection service unavailable')
  return { api: handle.api, insert: refs => insertReferences(ctx, sessionId, refs) }
}

/** Client plugin body: source and composer trigger. */
export function apply(ctx: ClientContext): void {
  const inputTriggers = ctx.get('inputTriggers') as InputTriggerServiceContract | undefined
  ctx.effect(() => {
    if (inputTriggers === undefined) {
      console.error('[cue] inputTriggers service unavailable')
      return () => {}
    }
    return inputTriggers.registerSource(cueSource)
  }, 'dsh-cue: source')
  ctx.slots.inject('conversation.input.left', () => ctx.slots.register(
    { name: 'conversation.input.left', id: 'cue', inject: sessionId => cueInject(ctx, sessionId) }, CueButton))
}
