import { describe, expect, it, vi } from 'vitest'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { createAutoModeEscalation, createPermissionBridge, mapApprovalOutcome, permissionReason, planText } from '../src/permission.ts'
import { normalizeActivity } from '../src/events.ts'
import { PlanFeedbackGate } from '../src/plan-feedback.ts'

function active(policy?: 'ask' | 'never') {
  const events: Array<{ type: string; data: unknown }> = []
  const sessionEvents: Array<{ type: string; data: unknown }> = policy === undefined
    ? []
    : [{ type: 'approval/policy', data: { policy } }]
  const agent = {
    session: {
      snapshotEvents: () => Object.freeze([...sessionEvents]),
      append: async (type: string, data: unknown) => { sessionEvents.push({ type, data }) },
    },
  } as unknown as Agent
  return {
    agent,
    cursor: { turn: 1, step: 1, nextOrdinal: 0 },
    events,
    sessionEvents,
    appendActivity: async (data: unknown) => { events.push({ type: 'activity', data }) },
  }
}

/** The `approval/policy` values a session log carries, in order. */
function policies(sessionEvents: ReadonlyArray<{ type: string; data: unknown }>): string[] {
  return sessionEvents
    .filter(event => event.type === 'approval/policy')
    .map(event => String((event.data as { policy?: unknown }).policy))
}

const toolOptions = (signal = new AbortController().signal) => ({
  signal,
  toolUseID: 'tool-1',
  requestId: 'request-1',
  title: 'Claude wants to edit a file',
})

describe('permission result mapping', () => {
  it('grants only allowed-once with unchanged input', () => {
    const input = { file: 'a.txt' }
    expect(mapApprovalOutcome('allowed-once', input, 'tool-1')).toMatchObject({
      behavior: 'allow',
      updatedInput: input,
      decisionClassification: 'user_temporary',
    })
    for (const outcome of ['rejected', 'cancelled', 'unavailable'] as const) {
      expect(mapApprovalOutcome(outcome, input, 'tool-1').behavior).toBe('deny')
    }
  })

  it('redacts secrets from approval reasons', () => {
    const reason = permissionReason('Bash', { command: 'echo ok', api_key: 'nope' }, toolOptions())
    expect(reason).toContain('echo ok')
    expect(reason).toContain('[REDACTED]')
    expect(reason).not.toContain('nope')
  })

  it('puts the reason an auto-mode ask escalated under the title', () => {
    const escalated = permissionReason('Bash', { command: 'rm -rf build' }, { ...toolOptions(), decisionReason: 'Safety check: recursive delete outside the workspace' })
    expect(escalated.startsWith('Claude wants to edit a file\nSafety check: recursive delete outside the workspace')).toBe(true)
    // A reason that merely repeats the title is not said twice.
    expect(permissionReason('Bash', { command: 'ls' }, { ...toolOptions(), decisionReason: 'Claude wants to edit a file' })).not.toContain('file\nClaude')
    // Without a title the reason is the prompt, as before.
    const { title: _title, ...untitled } = toolOptions()
    expect(permissionReason('Bash', { command: 'ls' }, { ...untitled, decisionReason: 'Rule: ask for Bash' }).startsWith('Rule: ask for Bash')).toBe(true)
  })

  it('points the approval dialog at the plan panel instead of pasting the plan', () => {
    const plan = `## Plan\n\n1. Read ${'the supervisor '.repeat(200)}\n2. Ship it`
    const reason = permissionReason('ExitPlanMode', { plan }, toolOptions())
    // The dialog renders its reason as plain text in a cramped modal, so it
    // says what is being decided and where to read it; the plan itself goes to
    // the panel that can render Markdown.
    expect(reason).toContain('Plan panel')
    expect(reason).not.toContain('the supervisor')
    expect(reason).not.toContain('Input: ')
    // An empty or missing plan falls back to the ordinary prompt.
    expect(permissionReason('ExitPlanMode', { plan: '' }, toolOptions())).toContain('Input: ')
  })

  it('carries the plan on the activity field wide enough to hold it', () => {
    // `summary` caps at 1k and `detail` at 4k; only `text` (64k) survives a
    // real plan intact.
    const plan = `## Plan\n\n${'step '.repeat(2_000)}`
    expect(plan.length).toBeGreaterThan(4_000)
    expect(planText('ExitPlanMode', { plan })).toBe(plan)
    expect(normalizeActivity({ turn: 1, step: 0, ordinal: 0, kind: 'permission', text: plan }).text).toBe(plan)
    // Nothing else routes through the plan panel.
    expect(planText('Bash', { plan })).toBeUndefined()
    expect(planText('ExitPlanMode', { plan: '' })).toBeUndefined()
    expect(planText('ExitPlanMode', {})).toBeUndefined()
  })
})

describe('DSH approval bridge', () => {
  it('audits pending and allowed decisions', async () => {
    const state = active()
    const request = vi.fn(async () => 'allowed-once' as const)
    const markActivity = vi.fn()
    const canUseTool = createPermissionBridge({ request }, () => ({ ...state, markActivity }))
    await expect(canUseTool('Edit', { file_path: 'a.txt' }, toolOptions())).resolves.toMatchObject({
      behavior: 'allow',
      toolUseID: 'tool-1',
    })
    expect(markActivity).toHaveBeenCalledOnce()
    expect(request).toHaveBeenCalledWith(expect.objectContaining({
      agent: state.agent,
      toolName: 'Edit',
    }))
    expect(state.events.map(event => (event.data as { phase: string }).phase)).toEqual(['started', 'completed'])
  })

  it('fails closed when no turn owns the request', async () => {
    const request = vi.fn(async () => 'allowed-once' as const)
    const canUseTool = createPermissionBridge({ request }, () => undefined)
    await expect(canUseTool('Bash', {}, toolOptions())).resolves.toMatchObject({ behavior: 'deny' })
    expect(request).not.toHaveBeenCalled()
  })

  it('routes AskUserQuestion before Full access and never opens approval', async () => {
    const state = active()
    const request = vi.fn(async () => 'allowed-once' as const)
    const userQuestion = vi.fn(async () => ({
      behavior: 'allow' as const,
      updatedInput: { questions: [], answers: {} },
    }))
    const hasFullAccess = vi.fn(async () => true)
    const canUseTool = createPermissionBridge({ request }, () => ({
      ...state,
      hasFullAccess,
    }), userQuestion)

    await expect(canUseTool('AskUserQuestion', { questions: [] }, toolOptions())).resolves.toMatchObject({ behavior: 'allow' })
    expect(userQuestion).toHaveBeenCalledOnce()
    expect(hasFullAccess).not.toHaveBeenCalled()
    expect(request).not.toHaveBeenCalled()
  })

  it('honors Full access selected while an approval request is pending', async () => {
    const state = active()
    let fullAccess = false
    const request = vi.fn(async () => {
      fullAccess = true
      return 'rejected' as const
    })
    const canUseTool = createPermissionBridge({ request }, () => ({
      ...state,
      hasFullAccess: async () => fullAccess,
    }))

    await expect(canUseTool('Bash', { command: 'git pull --ff-only' }, toolOptions())).resolves.toMatchObject({
      behavior: 'allow',
      toolUseID: 'tool-1',
    })
    expect(state.events.at(-1)?.data).toMatchObject({ phase: 'completed', summary: 'Allowed by Full access in DeepSeek Harness' })
  })

  it('asks for a plan even under Full access', async () => {
    // Full access, so DSH has silenced approvals with `policy: never`.
    const state = active('never')
    const request = vi.fn(async () => 'allowed-once' as const)
    const hasFullAccess = vi.fn(async () => true)
    const canUseTool = createPermissionBridge({ request }, () => ({ ...state, hasFullAccess }))

    await expect(canUseTool('ExitPlanMode', { plan: '# Plan' }, toolOptions())).resolves.toMatchObject({ behavior: 'allow' })
    // A plan is the decision the user asked for; Full access waives actions,
    // not decisions. Under `never` the service answers `rejected` before any
    // answerer runs, so the ask has to be un-silenced while it is open.
    expect(request).toHaveBeenCalledOnce()
    expect(policies(state.sessionEvents)).toEqual(['never', 'ask', 'never'])
    expect(state.events.at(-1)?.data).toMatchObject({ phase: 'completed', summary: 'Allowed once in DeepSeek Harness' })
    // Everything else still short-circuits, and leaves the policy alone.
    request.mockClear()
    await expect(canUseTool('Bash', { command: 'ls' }, toolOptions())).resolves.toMatchObject({ behavior: 'allow' })
    expect(request).not.toHaveBeenCalled()
    expect(policies(state.sessionEvents)).toEqual(['never', 'ask', 'never'])
  })

  it('leaves an already-asking policy untouched', async () => {
    const state = active('ask')
    const request = vi.fn(async () => 'allowed-once' as const)
    const canUseTool = createPermissionBridge({ request }, () => state)

    await expect(canUseTool('ExitPlanMode', { plan: '# Plan' }, toolOptions())).resolves.toMatchObject({ behavior: 'allow' })
    // Nothing to lift, so nothing is written — and nothing to put back.
    expect(policies(state.sessionEvents)).toEqual(['ask'])
  })

  it('restores the silent policy when the approval throws', async () => {
    const state = active('never')
    const request = vi.fn(async () => { throw new Error('surface exploded') })
    const canUseTool = createPermissionBridge({ request }, () => state)

    await expect(canUseTool('ExitPlanMode', { plan: '# Plan' }, toolOptions())).resolves.toMatchObject({ behavior: 'deny' })
    // A failed ask must not leave the session asking about everything else.
    expect(policies(state.sessionEvents)).toEqual(['never', 'ask', 'never'])
  })

  it('keeps a rejected plan rejected when Full access lands mid-read', async () => {
    const state = active('never')
    let fullAccess = false
    // The user switches to Full access while the plan is on screen, then
    // rejects it. The rejection is the answer; the switch is not.
    const request = vi.fn(async () => {
      fullAccess = true
      return 'rejected' as const
    })
    const canUseTool = createPermissionBridge({ request }, () => ({
      ...state,
      hasFullAccess: async () => fullAccess,
    }))

    await expect(canUseTool('ExitPlanMode', { plan: '# Plan' }, toolOptions())).resolves.toMatchObject({ behavior: 'deny' })
    expect(state.events.at(-1)?.data).toMatchObject({ phase: 'denied' })
  })

  it('lets the panel answer a plan with revisions and closes the dialog', async () => {
    const state = active('never')
    const gate = new PlanFeedbackGate()
    // The dialog never answers; the reviewer sends notes from the panel.
    const request = vi.fn((options: { signal?: AbortSignal }) => new Promise<'allowed-once'>((_, reject) => {
      options.signal?.addEventListener('abort', () => { reject(new Error('aborted')) }, { once: true })
    }))
    const canUseTool = createPermissionBridge({ request } as never, () => state, undefined, gate)

    const decision = canUseTool('ExitPlanMode', { plan: '# Plan' }, toolOptions())
    // Wait for the bridge to reach the race before answering it.
    await vi.waitFor(() => { expect(gate.pending('tool-1')).toBe(true) })
    expect(gate.submit('tool-1', [{ quote: '# Plan', text: 'add a rollback step' }])).toBe(true)

    const result = await decision
    expect(result).toMatchObject({ behavior: 'deny' })
    // Claude is told what to change, not merely that it was refused.
    expect((result as { message: string }).message).toContain('add a rollback step')
    expect((result as { message: string }).message).toContain('> # Plan')
    expect(state.events.at(-2)?.data).toMatchObject({ phase: 'denied', summary: 'Sent back for changes in DeepSeek Harness' })
    // The reader's own notes land in the chat, not only in Claude's message.
    expect(state.events.at(-1)?.data).toMatchObject({ kind: 'steering', title: 'Plan sent back for changes', summary: '> # Plan\nadd a rollback step' })
    // The lifted policy goes back even though the dialog never answered.
    expect(policies(state.sessionEvents)).toEqual(['never', 'ask', 'never'])
  })

  it('leaves an answered plan for the dialog, not the panel', async () => {
    const state = active('never')
    const gate = new PlanFeedbackGate()
    const request = vi.fn(async () => 'allowed-once' as const)
    const canUseTool = createPermissionBridge({ request }, () => state, undefined, gate)

    await expect(canUseTool('ExitPlanMode', { plan: '# Plan' }, toolOptions())).resolves.toMatchObject({ behavior: 'allow' })
    // The wait is abandoned once the dialog decides, so late notes are refused
    // rather than reopening a settled plan.
    expect(gate.pending('tool-1')).toBe(false)
    expect(gate.submit('tool-1', [{ text: 'too late' }])).toBe(false)
  })

  it('never races an ordinary tool against the panel', async () => {
    const state = active('ask')
    const gate = new PlanFeedbackGate()
    const request = vi.fn(async () => 'allowed-once' as const)
    const canUseTool = createPermissionBridge({ request }, () => state, undefined, gate)

    await expect(canUseTool('Bash', { command: 'ls' }, toolOptions())).resolves.toMatchObject({ behavior: 'allow' })
    expect(gate.pending('tool-1')).toBe(false)
  })

  it('fails closed when the approval service rejects', async () => {
    const state = active()
    const canUseTool = createPermissionBridge({ request: async () => { throw new Error('audit failed') } }, () => state)
    await expect(canUseTool('Bash', {}, toolOptions())).resolves.toMatchObject({ behavior: 'deny' })
    expect(state.events.at(-1)?.data).toMatchObject({ phase: 'failed', isError: true })
  })
})

describe('auto-mode escalation', () => {
  const signal = new AbortController().signal
  const base = { session_id: 's', transcript_path: 't', cwd: '/w' }
  const call = { tool_name: 'Bash', tool_input: { command: 'gh pr merge 1' }, tool_use_id: 'tool-1' }

  it('lets Claude retry a blocked call and routes that retry to the DSH approval', async () => {
    const hooks = createAutoModeEscalation()
    const denied = hooks.PermissionDenied![0]!.hooks[0]!
    const preToolUse = hooks.PreToolUse![0]!.hooks[0]!
    const before = { ...base, ...call, hook_event_name: 'PreToolUse' as const }

    expect(await preToolUse(before, 'tool-1', { signal })).toEqual({})
    expect(await denied({ ...base, ...call, hook_event_name: 'PermissionDenied', reason: '[Merge Without Review]' }, 'tool-1', { signal }))
      .toEqual({ hookSpecificOutput: { hookEventName: 'PermissionDenied', retry: true } })
    // Another call is not the blocked one.
    expect(await preToolUse({ ...before, tool_input: { command: 'ls' } }, 'tool-2', { signal })).toEqual({})
    expect(await preToolUse({ ...before, tool_use_id: 'tool-3' }, 'tool-3', { signal })).toEqual({
      hookSpecificOutput: {
        hookEventName: 'PreToolUse',
        permissionDecision: 'ask',
        permissionDecisionReason: 'Auto mode blocked this action ([Merge Without Review]). Approve to run it anyway.',
      },
    })
    // One retry per block: the next identical call goes back to the classifier.
    expect(await preToolUse({ ...before, tool_use_id: 'tool-4' }, 'tool-4', { signal })).toEqual({})
  })
})
