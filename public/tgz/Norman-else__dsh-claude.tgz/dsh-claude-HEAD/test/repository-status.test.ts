import { mkdir, mkdtemp, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { describe, expect, it, vi } from 'vitest'
import type { SubprocessHandle, SubprocessSpawnSpec } from '@deepseek-ai/dsh-subprocess'
import { DSHWEB_FUNCNAME } from '../src/diff-funcname.ts'
import {
  RepositoryStatusService,
  aggregateChecks,
  parseDiffNumstat,
  parseGitHubRemote,
  parseGitStatus,
  parsePullRequest,
  detectRepositoryOperation, packPatchByFile } from '../src/repository-status.ts'

function handle(stdout: string, exitCode = 0, lossy = false): SubprocessHandle {
  return {
    pid: 1,
    stdin: undefined,
    stdout: undefined,
    stderr: undefined,
    collected: {
      stdout: { readFrom: () => ({ text: stdout, nextOffset: stdout.length, lossy }) },
      stderr: { readFrom: () => ({ text: '', nextOffset: 0, lossy: false }) },
    },
    done: Promise.resolve({ exitCode, signal: null }),
    terminate: vi.fn(),
    waitForExit: async () => true,
  }
}

function runtime(results: Array<{ stdout: string; exitCode?: number; lossy?: boolean }>) {
  const spawn = vi.fn((_spec: SubprocessSpawnSpec) => {
    const result = results.shift()
    if (result === undefined) throw new Error('unexpected command')
    return handle(result.stdout, result.exitCode, result.lossy)
  })
  const resolveExecutable = vi.fn(async (name: string) => `/bin/${name}`)
  return { spawn, resolveExecutable }
}

describe('repository status parsing', () => {
  it('parses branches, detached heads, and tracked or untracked changes', () => {
    expect(parseGitStatus('# branch.head feature/status\n1 .M N... file.ts\n')).toEqual({
      branch: 'feature/status',
      detached: false,
      dirty: true,
      upstream: false,
    })
    expect(parseGitStatus('# branch.head (detached)\n')).toEqual({ detached: true, dirty: false, upstream: false })
    expect(parseGitStatus('# branch.head main\n? untracked.txt\n')).toEqual({
      branch: 'main',
      detached: false,
      dirty: true,
      upstream: false,
    })
    expect(parseGitStatus('# branch.head main\n# branch.upstream origin/main\n# branch.ab +2 -1\n')).toEqual({
      branch: 'main',
      detached: false,
      dirty: false,
      upstream: true,
      ahead: 2,
      behind: 1,
    })
  })

  it('collects the unmerged paths a stopped operation is waiting on', () => {
    expect(parseGitStatus([
      '# branch.head (detached)',
      'u UU N... 100644 100644 100644 100644 1111111 2222222 3333333 src/conflict.ts',
      'u UU N... 100644 100644 100644 100644 1111111 2222222 3333333 src/with space.ts',
      '',
    ].join('\n'))).toEqual({
      detached: true,
      // Unmerged paths are changes too: the tree belongs to the merge.
      dirty: true,
      upstream: false,
      conflicts: ['src/conflict.ts', 'src/with space.ts'],
    })
  })

  it('parses bounded tracked diff statistics', () => {
    expect(parseDiffNumstat('2\t1\tsrc/a.ts\n-\t-\timage.png\n')).toEqual({ additions: 2, deletions: 1, files: 2 })
  })

  it('accepts only recognizable GitHub remotes', () => {
    expect(parseGitHubRemote('https://github.com/owner/repo.git\n')).toBe('owner/repo')
    expect(parseGitHubRemote('git@github.com:owner/repo.git')).toBe('owner/repo')
    expect(parseGitHubRemote('ssh://git@github.com/owner/repo')).toBe('owner/repo')
    expect(parseGitHubRemote('https://example.com/owner/repo.git')).toBeUndefined()
  })

  it('aggregates checks and strictly normalizes pull requests', () => {
    expect(aggregateChecks([{ status: 'COMPLETED', conclusion: 'SUCCESS' }])).toBe('passing')
    expect(aggregateChecks([{ status: 'IN_PROGRESS' }])).toBe('pending')
    expect(aggregateChecks([{ status: 'COMPLETED', conclusion: 'FAILURE' }])).toBe('failing')
    expect(parsePullRequest({
      number: 12,
      title: 'Repository status',
      url: 'https://github.com/owner/repo/pull/12',
      state: 'OPEN',
      isDraft: false,
      reviewDecision: 'APPROVED',
      mergeStateStatus: 'CLEAN',
      statusCheckRollup: [{ status: 'COMPLETED', conclusion: 'SUCCESS' }],
    })).toMatchObject({ number: 12, state: 'open', review: 'approved', checks: 'passing' })
    expect(parsePullRequest({
      number: 13,
      title: 'Merged repository status',
      url: 'https://github.com/owner/repo/pull/13',
      state: 'CLOSED',
      mergedAt: '2026-08-22T08:00:00Z',
      baseRefName: 'master',
    })).toMatchObject({
      number: 13,
      state: 'merged',
      mergedAt: '2026-08-22T08:00:00.000Z',
      baseBranch: 'master',
    })
    expect(parsePullRequest({ number: 1, title: 'bad', url: 'http://github.com/x/y/pull/1', state: 'OPEN' })).toBeUndefined()
  })
})

describe('repository status service', () => {
  it('returns Git and PR state through bounded explicit argv probes', async () => {
    const fake = runtime([
      { stdout: 'C:/repo\nC:/repo/.git/worktrees/status\nC:/repo/.git\n' },
      { stdout: '# branch.head feature/status\n' },
      { stdout: 'git@github.com:owner/repo.git\n' },
      { stdout: JSON.stringify({
        number: 12,
        title: 'Repository status',
        url: 'https://github.com/owner/repo/pull/12',
        state: 'OPEN',
        isDraft: false,
        reviewDecision: 'REVIEW_REQUIRED',
        mergeStateStatus: 'BLOCKED',
        statusCheckRollup: [{ status: 'IN_PROGRESS' }],
        author: { login: 'norman-else' },
        createdAt: '2026-08-21T13:00:00Z',
        baseRefName: 'master',
      }) },
      { stdout: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n' },
      { stdout: '2\t1\tsrc/file.ts\n' },
      { stdout: 'diff --git a/src/file.ts b/src/file.ts\n@@ -1 +1 @@\n-old\n+new\n+more\n' },
      { stdout: '' },
      { stdout: '3\n' },
    ])
    const service = new RepositoryStatusService(fake, 60_000)
    await expect(service.inspect('C:/repo')).resolves.toEqual({
      status: 'ready',
      cwd: 'C:/repo',
      root: 'C:/repo',
      branch: 'feature/status',
      detached: false,
      worktree: true,
      dirty: false,
      upstream: false,
      remote: 'owner/repo',
      pullRequest: {
        number: 12,
        title: 'Repository status',
        url: 'https://github.com/owner/repo/pull/12',
        state: 'open',
        draft: false,
        review: 'review-required',
        checks: 'pending',
        mergeState: 'BLOCKED',
        author: 'norman-else',
        createdAt: '2026-08-21T13:00:00.000Z',
        baseBranch: 'master',
      },
      diff: {
        additions: 2,
        deletions: 1,
        files: 1,
        patch: 'diff --git a/src/file.ts b/src/file.ts\n@@ -1 +1 @@\n-old\n+new\n+more\n',
        truncated: false,
      },
      baseBehind: 3,
    })
    await service.inspect('C:/repo')
    expect(fake.spawn).toHaveBeenCalledTimes(9)
    expect(fake.spawn.mock.calls[0]?.[0]).toMatchObject({
      argv: ['/bin/git', 'rev-parse', '--path-format=absolute', '--show-toplevel', '--absolute-git-dir', '--git-common-dir'],
      cwd: 'C:/repo',
      stdio: { stdin: 'ignore', stdout: { maxBytes: 65_536 }, stderr: { maxBytes: 65_536 } },
    })
    expect(fake.spawn.mock.calls[1]?.[0].argv).toEqual([
      '/bin/git', 'status', '--porcelain=v2', '--branch', '--untracked-files=normal',
    ])
    expect(fake.spawn.mock.calls[3]?.[0].argv).toEqual([
      '/bin/gh', 'pr', 'view', 'feature/status', '--repo', 'owner/repo', '--json',
      'number,title,url,state,isDraft,reviewDecision,mergeStateStatus,mergedAt,statusCheckRollup,author,createdAt,baseRefName,headRefName,additions,deletions,changedFiles',
    ])
    expect(fake.spawn.mock.calls[4]?.[0].argv).toEqual(['/bin/git', 'merge-base', 'HEAD', 'refs/remotes/origin/master'])
    expect(fake.spawn.mock.calls[5]?.[0].argv).toEqual(['/bin/git', 'diff', '--no-ext-diff', '--numstat', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '--'])
    // The funcname overrides run ahead of the subcommand, so hunk headers name
    // the method a change sits in rather than the enclosing class.
    expect(fake.spawn.mock.calls[6]?.[0]).toMatchObject({
      argv: [
        '/bin/git',
        '-c', expect.stringMatching(/^core\.attributesFile=.+diff-attributes$/u),
        '-c', `diff.dshweb.xfuncname=${DSHWEB_FUNCNAME}`,
        'diff', '--no-ext-diff', '--no-color', '--unified=3', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '--',
      ],
      stdio: { stdout: { maxBytes: 8_388_608 } },
    })
    expect(fake.spawn.mock.calls[7]?.[0].argv).toEqual(['/bin/git', 'ls-files', '--others', '--exclude-standard', '-z'])
  })

  it('keeps the last PR and its diff when a later gh probe is temporarily unavailable', async () => {
    const fake = runtime([
      { stdout: '/repo\n/repo/.git\n/repo/.git\n' },
      { stdout: '# branch.head feature/status\n' },
      { stdout: 'https://github.com/owner/repo.git\n' },
      { stdout: JSON.stringify({
        number: 12,
        title: 'Repository status',
        url: 'https://github.com/owner/repo/pull/12',
        state: 'OPEN',
        isDraft: false,
        reviewDecision: 'APPROVED',
        statusCheckRollup: [{ status: 'COMPLETED', conclusion: 'SUCCESS' }],
        baseRefName: 'master',
      }) },
      { stdout: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n' },
      { stdout: '2\t1\tsrc/file.ts\n' },
      { stdout: 'diff --git a/src/file.ts b/src/file.ts\n@@ -1 +1 @@\n-old\n+new\n' },
      { stdout: '' },
      { stdout: '/repo\n/repo/.git\n/repo/.git\n' },
      { stdout: '# branch.head feature/status\n' },
      { stdout: 'https://github.com/owner/repo.git\n' },
      { stdout: '', exitCode: 1 },
    ])
    const service = new RepositoryStatusService(fake, 0)
    const first = await service.inspect('/repo')
    const second = await service.inspect('/repo')
    expect(second.pullRequest).toEqual(first.pullRequest)
    expect(second.diff).toEqual(first.diff)
  })

  it('keeps every file that fits and names the ones that do not', () => {
    const small = (path: string) => `diff --git a/${path} b/${path}\n--- a/${path}\n+++ b/${path}\n@@ -1 +1 @@\n-old\n+new\n`
    const huge = `diff --git a/pnpm-lock.yaml b/pnpm-lock.yaml\n--- a/pnpm-lock.yaml\n+++ b/pnpm-lock.yaml\n@@ -1 +1 @@\n${'-x\n+y\n'.repeat(200)}`
    const packed = packPatchByFile(`${small('a.ts')}${huge}${small('b.ts')}`, 10_000, 500)
    expect(packed.patch).toBe(`${small('a.ts')}${small('b.ts')}`)
    expect(packed.elided).toEqual(['pnpm-lock.yaml'])
    // The total budget also elides, in file order, so the panel never shows a torn file.
    const tight = packPatchByFile(`${small('a.ts')}${small('b.ts')}${small('c.ts')}`, small('a.ts').length + small('b.ts').length, 500)
    expect(tight.patch).toBe(`${small('a.ts')}${small('b.ts')}`)
    expect(tight.elided).toEqual(['c.ts'])
    expect(packPatchByFile('', 100, 50)).toEqual({ patch: '', elided: [] })
  })

  it('skips an oversized file instead of blanking the whole diff', async () => {
    const small = 'diff --git a/file.ts b/file.ts\n--- a/file.ts\n+++ b/file.ts\n@@ -1 +1 @@\n-old\n+new\n'
    const huge = `diff --git a/pnpm-lock.yaml b/pnpm-lock.yaml\n--- a/pnpm-lock.yaml\n+++ b/pnpm-lock.yaml\n@@ -1 +1 @@\n${'-x\n+y\n'.repeat(40_000)}`
    const fake = runtime([
      { stdout: '/repo\n/repo/.git\n/repo/.git\n' },
      { stdout: '# branch.head main\n1 .M N... file.ts\n1 .M N... pnpm-lock.yaml\n' },
      { stdout: '', exitCode: 2 },
      { stdout: '1\t1\tfile.ts\n40000\t40000\tpnpm-lock.yaml\n' },
      { stdout: `${small}${huge}` },
      { stdout: '' },
    ])
    const result = await new RepositoryStatusService(fake).inspect('/repo')
    expect(result.diff).toMatchObject({ additions: 40_001, deletions: 40_001, files: 2, truncated: false, patch: small, elided: ['pnpm-lock.yaml'] })
  })

  it('omits a truncated patch while preserving bounded diff statistics', async () => {
    const fake = runtime([
      { stdout: '/repo\n/repo/.git\n/repo/.git\n' },
      { stdout: '# branch.head main\n1 .M N... file.ts\n' },
      { stdout: '', exitCode: 2 },
      { stdout: '4\t3\tfile.ts\n' },
      { stdout: 'partial patch', lossy: true },
      { stdout: '' },
    ])
    await expect(new RepositoryStatusService(fake).inspect('/repo')).resolves.toMatchObject({
      status: 'ready',
      diff: { additions: 4, deletions: 3, files: 1, truncated: true },
    })
    const result = await new RepositoryStatusService(runtime([
      { stdout: '/repo\n/repo/.git\n/repo/.git\n' },
      { stdout: '# branch.head main\n1 .M N... file.ts\n' },
      { stdout: '', exitCode: 2 },
      { stdout: '4\t3\tfile.ts\n' },
      { stdout: 'partial patch', lossy: true },
      { stdout: '' },
    ])).inspect('/repo')
    expect(result.diff).not.toHaveProperty('patch')
  })

  it('counts untracked files and their lines in the working tree diff', async () => {
    const fake = runtime([
      { stdout: '/repo\n/repo/.git\n/repo/.git\n' },
      { stdout: '# branch.head main\n1 .M N... file.ts\n? new.ts\n' },
      { stdout: '', exitCode: 2 },
      { stdout: '2\t1\tfile.ts\n' },
      { stdout: 'diff --git a/file.ts b/file.ts\n@@ -1 +1 @@\n-old\n+new\n+more\n' },
      { stdout: 'new.ts\0empty.ts\0' },
      { stdout: '3\t0\tnul => new.ts\ndiff --git a/new.ts b/new.ts\nnew file mode 100644\n--- /dev/null\n+++ b/new.ts\n@@ -0,0 +1,3 @@\n+a\n+b\n+c\n', exitCode: 1 },
      { stdout: '' },
    ])
    const status = await new RepositoryStatusService(fake).inspect('/repo')
    expect(status.diff).toMatchObject({ additions: 5, deletions: 1, files: 3, truncated: false })
    expect(status.diff?.patch).toContain('diff --git a/file.ts b/file.ts')
    expect(status.diff?.patch).toContain('diff --git a/new.ts b/new.ts')
    expect(fake.spawn.mock.calls[5]?.[0].argv).toEqual(['/bin/git', 'ls-files', '--others', '--exclude-standard', '-z'])
    expect(fake.spawn.mock.calls[6]?.[0].argv).toEqual([
      '/bin/git', 'diff', '--no-ext-diff', '--no-color', '--unified=3', '--numstat', '--patch', '--no-index', '--', '/dev/null', 'new.ts',
    ])
  })

  it('degrades for non-repositories and unavailable executables without leaking errors', async () => {
    const notRepo = runtime([{ stdout: 'fatal details', exitCode: 128 }])
    await expect(new RepositoryStatusService(notRepo).inspect('/tmp')).resolves.toEqual({
      status: 'not-repository',
      cwd: '/tmp',
    })
    const unavailable = runtime([])
    unavailable.resolveExecutable.mockRejectedValueOnce(new Error('secret executable failure'))
    await expect(new RepositoryStatusService(unavailable).inspect('/private')).resolves.toEqual({
      status: 'unavailable',
      cwd: '/private',
    })
  })

  it('keeps Git state when gh is unavailable', async () => {
    const fake = runtime([
      { stdout: '/repo\n/repo/.git\n/repo/.git\n' },
      { stdout: '# branch.head main\n' },
      { stdout: 'https://github.com/owner/repo.git\n' },
    ])
    fake.resolveExecutable.mockImplementation(async (name: string) => {
      if (name === 'gh') throw new Error('not installed')
      return '/bin/git'
    })
    await expect(new RepositoryStatusService(fake).inspect('/repo')).resolves.toMatchObject({
      status: 'ready', branch: 'main', worktree: false, dirty: false, remote: 'owner/repo',
    })
  })
})

describe('in-progress operations', () => {
  it('names the stopped operation and the branch a rebase parked', async () => {
    const gitDir = await mkdtemp(join(tmpdir(), 'dsh-claude-gitdir-'))
    expect(await detectRepositoryOperation(gitDir)).toBeUndefined()
    await mkdir(join(gitDir, 'rebase-merge'))
    await writeFile(join(gitDir, 'rebase-merge', 'head-name'), 'refs/heads/feature/status\n', 'utf8')
    expect(await detectRepositoryOperation(gitDir)).toEqual({ operation: 'rebase', branch: 'feature/status' })
  })

  it('reports a merge without inventing a branch for it', async () => {
    const gitDir = await mkdtemp(join(tmpdir(), 'dsh-claude-gitdir-'))
    await writeFile(join(gitDir, 'MERGE_HEAD'), 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n', 'utf8')
    expect(await detectRepositoryOperation(gitDir)).toEqual({ operation: 'merge' })
  })

  it('keeps the branch and its pull request through a conflicted rebase', async () => {
    const gitDir = await mkdtemp(join(tmpdir(), 'dsh-claude-gitdir-'))
    await mkdir(join(gitDir, 'rebase-merge'))
    await writeFile(join(gitDir, 'rebase-merge', 'head-name'), 'refs/heads/feature/status\n', 'utf8')
    const fake = runtime([
      { stdout: `/repo\n${gitDir}\n${gitDir}\n` },
      { stdout: '# branch.head (detached)\nu UU N... 100644 100644 100644 100644 1 2 3 src/a.ts\n' },
      { stdout: 'git@github.com:owner/repo.git\n' },
      { stdout: JSON.stringify({
        number: 12,
        title: 'Repository status',
        url: 'https://github.com/owner/repo/pull/12',
        state: 'OPEN',
        baseRefName: 'master',
      }) },
      { stdout: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n' },
      { stdout: '' },
      { stdout: '' },
      { stdout: '' },
      { stdout: '0\n' },
    ])
    const status = await new RepositoryStatusService(fake, 60_000).inspect('/repo')
    // Git only says `(detached)` while it replays, so the bar would otherwise
    // lose the branch, its pull request and every control keyed on them.
    expect(status).toMatchObject({
      branch: 'feature/status',
      detached: true,
      operation: 'rebase',
      conflicts: ['src/a.ts'],
      pullRequest: { number: 12, baseBranch: 'master' },
    })
    expect(fake.spawn.mock.calls[3]?.[0].argv).toContain('feature/status')
  })
})

describe('repository file lines', () => {
  it('slices working-tree files inside the repository and refuses escapes', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dsh-claude-file-'))
    await writeFile(join(root, 'a.txt'), 'l1\nl2\nl3\nl4\n')
    const service = new RepositoryStatusService(runtime([{ stdout: `${root}\n` }, { stdout: `${root}\n` }]))
    await expect(service.fileLines(root, 'a.txt', 2, 3)).resolves.toEqual({ lines: ['l2', 'l3'], total: 4 })
    await expect(service.fileLines(root, 'a.txt', 4, 10)).resolves.toEqual({ lines: ['l4'], total: 4 })
    await expect(service.fileLines(root, '../a.txt', 1, 2)).rejects.toMatchObject({ code: 'invalid-request' })
    await expect(service.fileLines(root, 'a.txt', 3, 2)).rejects.toMatchObject({ code: 'invalid-request' })
  })
})

describe('repository root lookup', () => {
  it('answers the toplevel for a directory inside a repository, undefined outside, and caches both', async () => {
    const fake = runtime([
      { stdout: '/repo\n' },
      { stdout: '', exitCode: 128 },
    ])
    const service = new RepositoryStatusService(fake, 60_000)
    // git prints the toplevel in its own form (forward slashes on Windows
    // too); the answer is the platform's resolved path, so it compares equal
    // to the session cwd the Host hands over.
    await expect(service.rootOf('/repo/src')).resolves.toBe(resolve('/repo'))
    await expect(service.rootOf('/tmp')).resolves.toBeUndefined()
    await expect(service.rootOf('/repo/src')).resolves.toBe(resolve('/repo'))
    await expect(service.rootOf('/tmp')).resolves.toBeUndefined()
    expect(fake.spawn).toHaveBeenCalledTimes(2)
    expect(fake.spawn.mock.calls[0]?.[0]).toMatchObject({ cwd: '/repo/src', argv: ['/bin/git', 'rev-parse', '--path-format=absolute', '--show-toplevel'] })
  })

  it('does not cache a probe that failed to run', async () => {
    const spawn = vi.fn()
      .mockImplementationOnce(() => { throw new Error('spawn failed') })
      .mockImplementationOnce(() => handle('/repo\n'))
    const service = new RepositoryStatusService({ spawn, resolveExecutable: async (name: string) => `/bin/${name}` }, 60_000)
    await expect(service.rootOf('/repo/src')).resolves.toBeUndefined()
    await expect(service.rootOf('/repo/src')).resolves.toBe(resolve('/repo'))
  })
})

describe('pull request lookup by number', () => {
  it('reads one pull request through gh, presents it as a ready checkout, and caches it', async () => {
    const patch = 'diff --git a/src/a.ts b/src/a.ts\n@@ -1 +1,2 @@\n a\n+b\n'
    const fake = runtime([
      { stdout: JSON.stringify({
        number: 2086, title: 'Pick columns', url: 'https://github.com/org/repo-b/pull/2086', state: 'OPEN', isDraft: false,
        reviewDecision: 'APPROVED', statusCheckRollup: [{ status: 'COMPLETED', conclusion: 'SUCCESS' }], headRefName: 'PSOS-5567', baseRefName: 'master',
        additions: 5, deletions: 2, changedFiles: 3,
      }) },
      { stdout: patch },
    ])
    const service = new RepositoryStatusService(fake, 60_000)
    const status = await service.inspectPullRequest('/session', 'org/repo-b', 2086)
    expect(status).toMatchObject({
      status: 'ready', cwd: '/session', remote: 'org/repo-b', branch: 'PSOS-5567', dirty: false, pullRequestOnly: true,
      pullRequest: { number: 2086, state: 'open', review: 'approved', checks: 'passing', headBranch: 'PSOS-5567', baseBranch: 'master' },
      // The pull request's own diff stands in for a working tree it no longer has.
      diff: { additions: 5, deletions: 2, files: 3, patch, truncated: false },
    })
    expect(status.root).toBeUndefined()
    await service.inspectPullRequest('/session', 'org/repo-b', 2086)
    expect(fake.spawn).toHaveBeenCalledTimes(2)
    expect(fake.spawn.mock.calls[0]?.[0]).toMatchObject({ cwd: '/session', argv: ['/bin/gh', 'pr', 'view', '2086', '--repo', 'org/repo-b', '--json', expect.stringContaining('changedFiles')] })
    expect(fake.spawn.mock.calls[1]?.[0]).toMatchObject({ cwd: '/session', argv: ['/bin/gh', 'pr', 'diff', '2086', '--repo', 'org/repo-b'] })
    // A merge through a clone invalidates that clone, and the pull request read
    // by number has to be asked again rather than wait out its minute.
    service.invalidate('/clone')
    await service.inspectPullRequest('/session', 'org/repo-b', 2086)
    expect(fake.spawn).toHaveBeenCalledTimes(3)
  })

  it('keeps the counts and marks the diff truncated when gh cannot produce the patch', async () => {
    const fake = runtime([
      { stdout: JSON.stringify({ number: 1, title: 't', url: 'https://github.com/o/r/pull/1', state: 'OPEN', additions: 1, deletions: 0, changedFiles: 1 }) },
      { stdout: '', exitCode: 1 },
    ])
    await expect(new RepositoryStatusService(fake, 60_000).inspectPullRequest('/s', 'o/r', 1)).resolves.toMatchObject({
      diff: { additions: 1, deletions: 0, files: 1, truncated: true },
    })
  })

  it('answers unavailable when gh cannot show the pull request', async () => {
    const service = new RepositoryStatusService(runtime([{ stdout: '', exitCode: 1 }]), 60_000)
    await expect(service.inspectPullRequest('/session', 'org/repo-b', 1)).resolves.toEqual({ status: 'unavailable', cwd: '/session' })
  })
})
