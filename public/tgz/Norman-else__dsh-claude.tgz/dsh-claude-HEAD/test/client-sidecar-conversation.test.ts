import { createElement } from 'react'
import { renderToStaticMarkup } from 'react-dom/server'
import { describe, expect, it } from 'vitest'
import type { ChatConversationViewNode } from '@deepseek-ai/dsh-client-ui-chat/client'
import type {
  ConversationNodeAssembler as ConversationNodeAssemblerType,
  ConversationNodeDefinition,
  ConversationTimelineSnapshot,
  ConversationViewDefinition,
} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { ClaudeActivityEvent, ClaudeTaskInfo } from '../src/events.ts'
import type { ClaudeActivityChatData } from '../src/client/conversation-sidecar.ts'
import {
  claudeActivityStepDefinition,
  claudeTurnDefinition,
  nativelyRenderedStep,
  selectClaudeTurn,
  transcriptItemsForStep,
} from '../src/client/conversation-sidecar.ts'
import {
  ClaudeActivityNode,
  ClaudeCompactionDivider,
  ClaudeTranscriptToolGroup,
  ClaudeTranscriptToolItem,
} from '../src/client/ClaudeActivityNode.tsx'

const taskCall: ClaudeActivityEvent = {
  turn: 2, step: 1, ordinal: 1, kind: 'tool-call', phase: 'started',
  toolUseId: 'task-1', toolName: 'Task', title: 'Task', summary: 'Explore module',
}
const nestedStarted: ClaudeActivityEvent = {
  turn: 2, step: 1, ordinal: 2, kind: 'subagent', phase: 'started',
  toolUseId: 'sub-1', parentToolUseId: 'task-1', toolName: 'Read', summary: 'Reading',
}
const nestedDone: ClaudeActivityEvent = { ...nestedStarted, ordinal: 3, phase: 'completed' }
const taskDone: ClaudeActivityEvent = {
  turn: 2, step: 1, ordinal: 4, kind: 'tool-result', phase: 'completed',
  toolUseId: 'task-1', title: 'Tool completed',
}

/** `transcriptItemsForStep` is the only path the chat actually renders, so
 *  lifecycle folding has to be asserted through it rather than through a
 *  helper the UI never calls. */
function lifecycleRows(
  activities: readonly ClaudeActivityEvent[],
  turn: number,
  step: number,
  tasks: readonly ClaudeTaskInfo[] = [],
): readonly ClaudeActivityChatData[] {
  return transcriptItemsForStep(activities, turn, step, tasks)
    .flatMap(item => item.kind === 'activity' ? [item.row] : [])
}

let loadedConversationNodeAssembler: typeof ConversationNodeAssemblerType | undefined

async function loadConversationNodeAssembler(): Promise<typeof ConversationNodeAssemblerType> {
  if (loadedConversationNodeAssembler !== undefined) return loadedConversationNodeAssembler
  let clientExports: { ConversationNodeAssembler?: typeof ConversationNodeAssemblerType } | undefined
  class EmptyService {}
  class EmptyContext {}
  class EmptySlotCore {}
  // Host 0.1.7 ships the assembler inside the conversation client bundle, whose
  // components touch React and the store while the module loads.
  const dependencies: Record<string, unknown> = {
    '@deepseek-ai/cordis': { Service: EmptyService, Context: EmptyContext },
    '@deepseek-ai/dsh-client-ui-slots': { SlotCore: EmptySlotCore },
    'react': await import('react'),
    'react-dom': await import('react-dom'),
    'react/jsx-runtime': await import('react/jsx-runtime'),
    '@deepseek-ai/dsh-client-store': await import('@deepseek-ai/dsh-client-store'),
    '@deepseek-ai/dsh-client-ui-primitives': await import('@deepseek-ai/dsh-client-ui-primitives'),
  }
  Object.assign(globalThis, {
    window: {
      __ModuleLoader__: {
        load(definition: { factory(require: (id: string) => unknown): unknown }) {
          clientExports = definition.factory(id => dependencies[id]) as typeof clientExports
        },
      },
    },
  })
  await import('@deepseek-ai/dsh-client-ui-conversation/client')
  if (clientExports?.ConversationNodeAssembler === undefined) throw new Error('Conversation client did not export ConversationNodeAssembler')
  loadedConversationNodeAssembler = clientExports.ConversationNodeAssembler
  return loadedConversationNodeAssembler
}

const userTestDefinition: ConversationNodeDefinition<{ readonly seq: number }> = {
  kind: 'test-user',
  target: 'chat',
  match(event) {
    if (event.type !== 'user/message' || event.data.source.kind !== 'user') return null
    return { id: String(event.data.id), role: 'start' }
  },
  start(_context, match) {
    return { seq: match.event.seq }
  },
  update(context) {
    return context.state
  },
  buildViewNode(context): ChatConversationViewNode | null {
    if (context.state === undefined) return null
    return {
      key: context.key,
      kind: 'test-user',
      id: context.id,
      target: 'chat',
      anchorSeq: context.state.seq,
      location: context.start?.location ?? { kind: 'unresolved' },
      visibility: 'visible',
      data: {},
    }
  },
}

const assistantTestDefinition: ConversationNodeDefinition<{ readonly seq: number; readonly turn: number; readonly step: number }> = {
  kind: 'test-assistant',
  target: 'chat',
  match(event) {
    if (event.type !== 'assistant/message') return null
    return { id: `${event.data.turn}:${event.data.step}`, role: 'start' }
  },
  start(_context, match) {
    if (match.event.type !== 'assistant/message') throw new Error('Test assistant requires assistant/message')
    return { seq: match.event.seq, turn: match.event.data.turn, step: match.event.data.step }
  },
  update(context) {
    return context.state
  },
  buildViewNode(context): ChatConversationViewNode | null {
    if (context.state === undefined) return null
    return {
      key: context.key,
      kind: 'test-assistant',
      id: context.id,
      target: 'chat',
      anchorSeq: context.state.seq,
      location: context.start?.location ?? { kind: 'unresolved' },
      visibility: 'visible',
      data: { turn: context.state.turn, step: context.state.step },
    }
  },
}

interface TestProjection {
  readonly timeline: ConversationTimelineSnapshot
  readonly chat: readonly ChatConversationViewNode[]
}

async function conversationAssembler(): Promise<InstanceType<typeof ConversationNodeAssemblerType>> {
  const ConversationNodeAssembler = await loadConversationNodeAssembler()
  const timelineView: ConversationViewDefinition = {
    target: 'test-timeline',
    create() {
      const empty: ConversationTimelineSnapshot = { turnOrder: [], turns: new Map() }
      return {
        empty,
        replace: input => input.timeline,
        apply: input => input.timeline,
      }
    },
  }
  const chatView: ConversationViewDefinition<ChatConversationViewNode, readonly ChatConversationViewNode[]> = {
    target: 'chat',
    create() {
      let current: readonly ChatConversationViewNode[] = []
      const visible = (nodes: readonly ChatConversationViewNode[]) => nodes
        .filter(node => node.visibility !== 'hidden')
        .sort((left, right) => left.anchorSeq - right.anchorSeq)
      return {
        empty: [],
        replace: input => {
          current = input.nodes
          return visible(current)
        },
        apply: input => {
          const upserts = new Map(input.upserts.map(node => [node.key, node]))
          current = [
            ...current.map(node => upserts.get(node.key) ?? node),
            ...input.upserts.filter(node => !current.some(existing => existing.key === node.key)),
          ]
          return visible(current)
        },
      }
    },
  }
  const assembler = new ConversationNodeAssembler(
    {
      entries: () => [claudeTurnDefinition, claudeActivityStepDefinition, userTestDefinition, assistantTestDefinition],
      fallbackEntry: () => undefined,
    },
    { entries: () => [timelineView, chatView] },
  )
  // Host 0.1.7 materializes only targets a reader has activated.
  assembler.activateTarget('test-timeline')
  assembler.activateTarget('chat')
  return assembler
}

async function projectConversation(events: readonly unknown[]): Promise<TestProjection> {
  const assembler = await conversationAssembler()
  assembler.replaceWindow(events.map(event => ({ event, view: undefined })) as never, false)
  assembler.flush()
  return {
    timeline: assembler.snapshot('test-timeline') as ConversationTimelineSnapshot,
    chat: assembler.snapshot('chat') as readonly ChatConversationViewNode[],
  }
}

describe('Claude sidecar conversation projection', () => {
  it('folds a task call, its nested subagent calls, and its result into one group entry', () => {
    const items = transcriptItemsForStep([taskCall, nestedStarted, nestedDone, taskDone], 2, 1)
    expect(items).toHaveLength(1)
    expect(items[0]).toMatchObject({
      kind: 'tools',
      tools: [{
        toolUseId: 'task-1',
        toolName: 'Task',
        phase: 'completed',
        subcalls: [{ toolUseId: 'sub-1', phase: 'completed', toolName: 'Read' }],
      }],
    })
    expect(transcriptItemsForStep([taskCall], 1, 1)).toEqual([])
    // The Host draws the answer segment natively; the transcript keeps the rest.
    expect(transcriptItemsForStep([
      { turn: 1, step: 1, ordinal: 0, kind: 'text', phase: 'updated', text: 'Looking.' },
      { turn: 1, step: 1, ordinal: 1, kind: 'text', phase: 'updated', text: 'Done.', answer: true },
    ], 1, 1)).toEqual([{ kind: 'text', ordinal: 0, text: 'Looking.' }])
    expect(transcriptItemsForStep([
      taskCall,
      { ...taskCall, step: 2, ordinal: 2, toolUseId: 'task-2' },
      { ...taskCall, turn: 3, ordinal: 3, toolUseId: 'task-3' },
    ], 2, 1)).toEqual([expect.objectContaining({
      kind: 'tools',
      tools: [expect.objectContaining({ toolUseId: 'task-1' })],
    })])
  })

  /** Regression: the CLI emits one task_progress per tool a subagent runs. The
   *  transcript used to fold activity one event at a time, so each of those
   *  pings became its own row that never stopped pulsing. */
  it('keeps a subagent to one live row no matter how many progress pings it sends', () => {
    const dispatch: ClaudeActivityEvent = {
      turn: 2, step: 1, ordinal: 1, kind: 'tool-call', phase: 'started',
      toolUseId: 'agent-call-1', toolName: 'Agent',
      detail: JSON.stringify({ description: 'Find model picker ordering' }),
    }
    const lifecycle: ClaudeActivityEvent[] = [
      { turn: 2, step: 1, ordinal: 2, kind: 'subagent', phase: 'started', taskId: 'agent-1', title: 'Find model picker ordering' },
      { turn: 2, step: 1, ordinal: 3, kind: 'subagent', phase: 'updated', taskId: 'agent-1', title: 'Running List DeepSeek packages' },
      { turn: 2, step: 1, ordinal: 4, kind: 'subagent', phase: 'updated', taskId: 'agent-1', title: 'Searching for LlmProviderInfo' },
      { turn: 2, step: 1, ordinal: 5, kind: 'subagent', phase: 'updated', taskId: 'agent-1', title: 'Running Show symlink targets' },
    ]
    const running: ClaudeTaskInfo[] = [
      { taskId: 'agent-1', description: 'Find model picker ordering', status: 'running', subagentType: 'Explore' },
    ]

    // One row, showing the newest ping rather than a stack of stale ones.
    expect(lifecycleRows([dispatch, ...lifecycle], 2, 1, running)).toEqual([expect.objectContaining({
      running: true,
      activity: expect.objectContaining({ taskId: 'agent-1', title: 'Running Show symlink targets' }),
    })])

    // ...and it settles once, instead of leaving four permanent checkmarks.
    expect(lifecycleRows([dispatch, ...lifecycle], 2, 1, [
      { ...running[0]!, status: 'completed' },
    ])).toEqual([expect.objectContaining({
      running: false,
      activity: expect.objectContaining({ phase: 'completed', title: 'Show symlink targets' }),
    })])
  })

  it('folds a run of API retries into one row showing the latest attempt', () => {
    const retries: ClaudeActivityEvent[] = [1, 2, 3].map(attempt => ({
      turn: 2, step: 1, ordinal: attempt, kind: 'warning', phase: 'completed',
      title: 'Claude API retry', summary: `attempt ${attempt} of 10 · HTTP 529`,
    }))
    const other: ClaudeActivityEvent = { turn: 2, step: 1, ordinal: 4, kind: 'warning', phase: 'completed', title: 'Hook warning' }

    expect(lifecycleRows([...retries, other], 2, 1)).toEqual([
      expect.objectContaining({ activity: expect.objectContaining({ summary: 'attempt 3 of 10 · HTTP 529' }) }),
      expect.objectContaining({ activity: expect.objectContaining({ title: 'Hook warning' }) }),
    ])
  })

  /** The row belongs where the work first appeared, even when later pings
   *  arrive after an unrelated tool group has opened. */
  it('anchors a folded lifecycle row at its first appearance', () => {
    const items = transcriptItemsForStep([
      { turn: 2, step: 1, ordinal: 1, kind: 'subagent', phase: 'started', taskId: 'agent-1', title: 'Explore code' },
      { turn: 2, step: 1, ordinal: 2, kind: 'text', text: 'Meanwhile:' },
      { turn: 2, step: 1, ordinal: 3, kind: 'tool-call', phase: 'started', toolUseId: 'read-1', toolName: 'Read', detail: JSON.stringify({ file_path: 'a.ts' }) },
      { turn: 2, step: 1, ordinal: 4, kind: 'subagent', phase: 'updated', taskId: 'agent-1', title: 'Running grep' },
    ], 2, 1, [
      { taskId: 'agent-1', description: 'Explore code', status: 'running', subagentType: 'Explore' },
    ])
    expect(items.map(item => item.kind)).toEqual(['activity', 'text', 'tools'])
  })

  it('interleaves text and consecutive folded tool groups by shared ordinal', () => {
    const activities: ClaudeActivityEvent[] = [
      { turn: 2, step: 1, ordinal: 0, kind: 'text', text: 'I will inspect this.' },
      { turn: 2, step: 1, ordinal: 1, kind: 'tool-call', phase: 'started', toolUseId: 'read-1', toolName: 'Read', detail: 'file.ts' },
      { turn: 2, step: 1, ordinal: 2, kind: 'tool-result', phase: 'completed', toolUseId: 'read-1', detail: 'contents' },
      { turn: 2, step: 1, ordinal: 3, kind: 'warning', phase: 'completed', title: 'Transient tool warning' },
      { turn: 2, step: 1, ordinal: 4, kind: 'tool-call', phase: 'started', toolUseId: 'grep-1', toolName: 'Grep', detail: 'symbol' },
      { turn: 2, step: 1, ordinal: 5, kind: 'tool-result', phase: 'failed', toolUseId: 'grep-1', detail: 'not found', isError: true },
      { turn: 2, step: 1, ordinal: 6, kind: 'text', text: 'I found the cause.' },
      { turn: 2, step: 1, ordinal: 7, kind: 'tool-call', phase: 'started', toolUseId: 'bash-1', toolName: 'Bash', detail: 'pnpm test' },
      { turn: 2, step: 1, ordinal: 8, kind: 'subagent', phase: 'completed', parentToolUseId: 'bash-1', toolUseId: 'nested-1', toolName: 'Read', summary: 'log' },
      { turn: 2, step: 1, ordinal: 9, kind: 'permission', phase: 'denied', toolUseId: 'bash-1', summary: 'rejected' },
      { turn: 2, step: 1, ordinal: 10, kind: 'text', text: 'I could not run it.' },
    ]

    expect(transcriptItemsForStep(activities.reverse(), 2, 1)).toEqual([
      { kind: 'text', ordinal: 0, text: 'I will inspect this.' },
      { kind: 'tools', ordinal: 1, tools: [
        expect.objectContaining({ toolUseId: 'read-1', toolName: 'Read', output: 'contents', phase: 'completed' }),
        expect.objectContaining({ toolUseId: 'grep-1', toolName: 'Grep', output: 'not found', phase: 'failed', isError: true }),
      ] },
      { kind: 'activity', ordinal: 3, row: expect.objectContaining({ running: false, activity: expect.objectContaining({ title: 'Transient tool warning' }) }) },
      { kind: 'text', ordinal: 6, text: 'I found the cause.' },
      { kind: 'tools', ordinal: 7, tools: [expect.objectContaining({
        toolUseId: 'bash-1', toolName: 'Bash', phase: 'denied', output: 'rejected', isError: true,
        subcalls: [expect.objectContaining({ toolUseId: 'nested-1', phase: 'completed' })],
      })] },
      { kind: 'text', ordinal: 10, text: 'I could not run it.' },
    ])
  })

  it('derives readable descriptions and successful edit diffs for one tool group', () => {
    const activities: ClaudeActivityEvent[] = [
      {
        turn: 2, step: 1, ordinal: 1, kind: 'tool-call', phase: 'started', toolUseId: 'grep-1', toolName: 'Grep',
        detail: JSON.stringify({ pattern: 'external payment', path: 'services/accounting-service' }),
      },
      { turn: 2, step: 1, ordinal: 2, kind: 'tool-result', phase: 'completed', toolUseId: 'grep-1', detail: 'match.ts' },
      {
        turn: 2, step: 1, ordinal: 3, kind: 'tool-call', phase: 'started', toolUseId: 'edit-1', toolName: 'Edit',
        detail: JSON.stringify({ file_path: 'src/ReceivableService.java', old_string: 'old line', new_string: 'new line\nsecond line' }),
      },
      { turn: 2, step: 1, ordinal: 4, kind: 'tool-result', phase: 'completed', toolUseId: 'edit-1', detail: 'updated' },
      {
        turn: 2, step: 1, ordinal: 5, kind: 'tool-call', phase: 'started', toolUseId: 'write-failed', toolName: 'Write',
        detail: JSON.stringify({ file_path: 'src/Failed.java', content: 'not applied' }),
      },
      { turn: 2, step: 1, ordinal: 6, kind: 'tool-result', phase: 'failed', toolUseId: 'write-failed', detail: 'denied', isError: true },
    ]

    const group = transcriptItemsForStep(activities, 2, 1)[0]
    expect(group).toMatchObject({
      kind: 'tools',
      additions: 2,
      deletions: 1,
      files: 1,
      tools: [
        { description: 'Searched services/accounting-service for external payment' },
        {
          description: 'Edited src/ReceivableService.java',
          additions: 2,
          deletions: 1,
          diffs: [{ path: 'src/ReceivableService.java', oldText: 'old line', newText: 'new line\nsecond line' }],
        },
        { description: 'Failed to write src/Failed.java' },
      ],
    })
    if (group?.kind !== 'tools') throw new Error('Expected a tool group')
    expect(group.tools[2]).not.toHaveProperty('diffs')
    expect(group.tools[2]).not.toHaveProperty('additions')
    expect(group.tools[2]).not.toHaveProperty('deletions')
  })

  it('renders the tool-group row without a background card and includes diff statistics', () => {
    const markup = renderToStaticMarkup(createElement(ClaudeTranscriptToolGroup, {
      tools: [{
        toolUseId: 'edit-1',
        toolName: 'Edit',
        description: 'Edited file.ts',
        phase: 'completed',
        additions: 2,
        deletions: 1,
        diffs: [{ path: 'file.ts', oldText: 'old', newText: 'new\nline' }],
        subcalls: [],
      }],
      additions: 2,
      deletions: 1,
      files: 1,
      t: ((key: string, params?: Record<string, unknown>) => `${key}:${JSON.stringify(params ?? {})}`) as never,
    }))

    expect(markup).toContain('dsh-claude-tool-group-native')
    expect(markup).not.toContain('dsh-claude-tool-group-card')
    expect(markup).toContain('+2')
    expect(markup).toContain('−1')
  })

  it('splits the transcript at a compaction boundary instead of dropping it', () => {
    const activities: ClaudeActivityEvent[] = [
      { turn: 2, step: 1, ordinal: 0, kind: 'text', text: 'Before compaction.' },
      { turn: 2, step: 1, ordinal: 1, kind: 'tool-call', phase: 'started', toolUseId: 'read-1', toolName: 'Read', detail: '{"file_path":"a.ts"}' },
      { turn: 2, step: 1, ordinal: 2, kind: 'tool-result', phase: 'completed', toolUseId: 'read-1', detail: 'contents' },
      {
        turn: 2, step: 1, ordinal: 3, kind: 'compaction', phase: 'completed',
        title: 'Claude compacted the conversation',
        detail: JSON.stringify({ trigger: 'manual', preTokens: 128_000, postTokens: 32_000, durationMs: 4_200 }),
      },
      { turn: 2, step: 1, ordinal: 4, kind: 'text', text: 'After compaction.' },
    ]

    // The boundary closes the open tool group: it separates prose rather than
    // reporting work, so it can never land inside one group.
    expect(transcriptItemsForStep(activities, 2, 1)).toEqual([
      { kind: 'text', ordinal: 0, text: 'Before compaction.' },
      { kind: 'tools', ordinal: 1, tools: [expect.objectContaining({ toolUseId: 'read-1' })] },
      { kind: 'compaction', ordinal: 3, compaction: { trigger: 'manual', preTokens: 128_000, postTokens: 32_000 } },
      { kind: 'text', ordinal: 4, text: 'After compaction.' },
    ])
  })

  it('reads a metadata-less compaction boundary without inventing figures', () => {
    const activities: ClaudeActivityEvent[] = [
      { turn: 2, step: 1, ordinal: 0, kind: 'compaction', phase: 'completed', detail: '{}' },
      { turn: 2, step: 1, ordinal: 1, kind: 'compaction', phase: 'completed' },
    ]

    expect(transcriptItemsForStep(activities, 2, 1)).toEqual([
      { kind: 'compaction', ordinal: 0, compaction: {} },
      { kind: 'compaction', ordinal: 1, compaction: {} },
    ])
  })

  it('renders the compaction divider with token figures only when both are known', () => {
    const render = (compaction: Parameters<typeof ClaudeCompactionDivider>[0]['compaction']) =>
      renderToStaticMarkup(createElement(ClaudeCompactionDivider, {
        compaction,
        t: ((key: string) => key) as never,
      }))

    expect(render({ trigger: 'manual', preTokens: 128_000, postTokens: 32_000 }))
      .toContain('compacted · 128K → 32K')
    expect(render({ trigger: 'auto', preTokens: 128_000, postTokens: 32_000 }))
      .toContain('compactedAuto · 128K → 32K')
    // A half-reported boundary still draws the rule; it just says less.
    const partial = render({ preTokens: 128_000 })
    expect(partial).toContain('compacted')
    expect(partial).not.toContain('→')
    expect(partial).toContain('role="separator"')
  })

  it('renders sidecar text and tools from the unified transcript', () => {
    const markup = renderToStaticMarkup(createElement(ClaudeActivityNode, {
      node: { data: { turn: 2, step: 1 } },
      t: ((key: string) => key) as never,
      useClaudeProjection: ((selector: (projection: unknown) => unknown) => selector({
        activities: [
          {
            turn: 2,
            step: 1,
            ordinal: 0,
            kind: 'text',
            text: '## Sidecar assistant text',
          },
          {
            turn: 2,
            step: 1,
            ordinal: 1,
            kind: 'tool-call',
            phase: 'started',
            toolUseId: 'read-1',
            toolName: 'Read',
            detail: JSON.stringify({ file_path: 'README.md' }),
          },
        ],
        tasks: { tasks: [] },
      })) as never,
    } as never))

    expect(markup).toContain('dsh-claude-tool-group-native')
    expect(markup).toContain('Sidecar assistant text')
    expect(markup).toContain('dsh-claude-transcript-text')
  })

  it('keeps each tool entry in an independent collapsed disclosure', () => {
    const markup = renderToStaticMarkup(createElement('div', null,
      createElement(ClaudeTranscriptToolItem, {
        tool: {
          toolUseId: 'glob-1',
          toolName: 'Glob',
          phase: 'completed',
          input: '{"pattern":"**/*.ts"}',
          output: 'file.ts',
          subcalls: [],
        },
        t: ((key: string) => key) as never,
      }),
      createElement(ClaudeTranscriptToolItem, {
        tool: {
          toolUseId: 'grep-1',
          toolName: 'Grep',
          phase: 'completed',
          input: '{"pattern":"external payment"}',
          output: 'match.ts',
          subcalls: [],
        },
        t: ((key: string) => key) as never,
      }),
    ))

    expect(markup.match(/<details/g)).toHaveLength(2)
    expect(markup).not.toContain('<details open=""')
    expect(markup).toContain('<summary')
    expect(markup).toContain('file.ts')
    expect(markup).toContain('match.ts')
    expect(markup).toContain('Glob')
    expect(markup).toContain('Grep')
  })

  describe('AskUserQuestion cards', () => {
    const askInput = (questions: readonly string[]) => JSON.stringify({
      questions: questions.map(question => ({ question, header: 'Pick', multiSelect: false, options: [{ label: 'A' }, { label: 'B' }] })),
    })
    const askCall = (questions: readonly string[]): ClaudeActivityEvent => ({
      turn: 3, step: 1, ordinal: 1, kind: 'tool-call', phase: 'started',
      toolUseId: 'ask-1', toolName: 'AskUserQuestion', title: 'AskUserQuestion', detail: askInput(questions),
    })
    const askTools = (activities: readonly ClaudeActivityEvent[]) => transcriptItemsForStep(activities, 3, 1, [])
      .flatMap(item => item.kind === 'tools' ? item.tools : [])

    it('names the answer on the card from the row the question bridge recorded', () => {
      // The bridge's row is the reliable copy: Claude's own result can be cut
      // before its answers when the options are long.
      const [tool] = askTools([
        askCall(['Which database?']),
        {
          turn: 3, step: 1, ordinal: 2, kind: 'question', phase: 'completed', toolUseId: 'ask-1',
          toolName: 'AskUserQuestion', title: 'Claude asked a question',
          summary: 'Answered in DeepSeek Harness · PostgreSQL',
          detail: JSON.stringify({ answers: { 'Which database?': 'PostgreSQL' } }),
        },
        {
          turn: 3, step: 1, ordinal: 3, kind: 'tool-result', phase: 'completed', toolUseId: 'ask-1',
          detail: '{"questions":[{"question":"Which database?","options":[{"label":"A","description":"a very long… [truncated]',
        },
      ])
      expect(tool?.answers).toEqual([{ question: 'Which database?', answer: 'PostgreSQL' }])
      expect(tool?.description).toBe('Which database? · PostgreSQL')
    })

    it('falls back to the answers inside Claude’s own result for older sessions', () => {
      const [tool] = askTools([
        askCall(['First?', 'Second?']),
        {
          turn: 3, step: 1, ordinal: 3, kind: 'tool-result', phase: 'completed', toolUseId: 'ask-1',
          detail: JSON.stringify({ questions: [], answers: { 'First?': 'Yes', 'Second?': 'Tests, Docs' } }),
        },
      ])
      expect(tool?.answers).toEqual([
        { question: 'First?', answer: 'Yes' },
        { question: 'Second?', answer: 'Tests, Docs' },
      ])
      expect(tool?.description).toBe('Answered 2 questions')
    })

    it('says what was asked while it waits, and shows no answer for a cancelled question', () => {
      expect(askTools([askCall(['Which database?'])])[0]?.description).toBe('Which database?')
      expect(askTools([askCall(['One?', 'Two?'])])[0]?.description).toBe('Asked 2 questions')
      const [cancelled] = askTools([
        askCall(['Which database?']),
        {
          turn: 3, step: 1, ordinal: 3, kind: 'tool-result', phase: 'completed', toolUseId: 'ask-1', isError: true,
          detail: 'Error: DeepSeek Harness could not collect an answer; the question was cancelled.',
        },
      ])
      expect(cancelled?.answers).toBeUndefined()
      expect(cancelled?.description).toBe('Failed to ask a question')
    })

    it('renders the answers as question and answer pairs instead of protocol JSON', () => {
      const markup = renderToStaticMarkup(createElement(ClaudeTranscriptToolItem, {
        tool: {
          toolUseId: 'ask-1', toolName: 'AskUserQuestion', description: 'Answered 2 questions', subcalls: [],
          input: askInput(['use_snake_case?', 'Second?']),
          output: JSON.stringify({ answers: { 'use_snake_case?': 'Yes', 'Second?': 'No' } }),
          answers: [{ question: 'use_snake_case?', answer: 'Yes' }, { question: 'Second?', answer: 'No' }],
        },
        t: ((key: string) => key) as never,
      }))
      expect(markup).toContain('toolAnswers')
      // The question is shown as written, underscores included.
      expect(markup).toContain('use_snake_case?')
      expect(markup).toContain('>Yes<')
      expect(markup).not.toContain('&quot;answers&quot;')
    })
  })

  it('renders semantic Read, search, terminal, diff, and unknown tool details without protocol JSON walls', () => {
    const render = (tool: Parameters<typeof ClaudeTranscriptToolItem>[0]['tool']) => renderToStaticMarkup(createElement(ClaudeTranscriptToolItem, {
      tool,
      t: ((key: string) => key) as never,
    }))

    const read = render({
      toolUseId: 'read-1', toolName: 'Read', description: 'Read src/example.ts', subcalls: [],
      input: JSON.stringify({ file_path: 'src/example.ts', offset: 10, limit: 2 }),
      output: JSON.stringify({ type: 'text', file: { filePath: 'src/example.ts', content: 'const one = 1\nconst two = 2' } }),
    })
    expect(read).toContain('src/example.ts')
    expect(read).toContain('<span class="dsh-claude-tool-line-number">10</span>')
    expect(read).toContain('const one = 1')
    expect(read).not.toContain('&quot;filePath&quot;')

    const grep = render({
      toolUseId: 'grep-1', toolName: 'Grep', description: 'Searched for symbol', subcalls: [],
      input: JSON.stringify({ pattern: 'symbol', output_mode: 'files_with_matches' }),
      output: JSON.stringify({ mode: 'files_with_matches', filenames: ['src/a.ts', 'src/b.ts'], numFiles: 2 }),
    })
    expect(grep).toContain('src/a.ts')
    expect(grep).toContain('src/b.ts')
    expect(grep).not.toContain('&quot;filenames&quot;')

    const bash = render({
      toolUseId: 'bash-1', toolName: 'Bash', description: 'Ran tests', subcalls: [],
      input: JSON.stringify({ command: 'pnpm test', description: 'Run tests' }),
      output: JSON.stringify({ stdout: '18 passed', stderr: '', interrupted: false }),
    })
    expect(bash).toContain('pnpm test')
    expect(bash).toContain('18 passed')
    expect(bash).not.toContain('&quot;stdout&quot;')

    const diff = render({
      toolUseId: 'edit-1', toolName: 'Edit', description: 'Edited src/a.ts', subcalls: [],
      diffs: [{ path: 'src/a.ts', oldText: 'old', newText: 'new' }],
      input: JSON.stringify({ file_path: 'src/a.ts', old_string: 'old', new_string: 'new' }),
      output: JSON.stringify({ success: true }),
    })
    expect(diff).toContain('src/a.ts')
    expect(diff).not.toContain('old_string')

    const unknown = render({
      toolUseId: 'mcp-1', toolName: 'mcp__service__lookup', description: 'Lookup item', subcalls: [],
      input: JSON.stringify({ item_id: 'item-1', include_history: true }),
      output: JSON.stringify({ status: 'found', count: 1 }),
    })
    expect(unknown).toContain('item id')
    expect(unknown).toContain('include history')
    expect(unknown).toContain('found')
    expect(unknown).not.toContain('&quot;item_id&quot;')
  })

  it('keeps foreground Bash only in its tool group while retaining background and subagent lifecycle rows', () => {
    const activities: ClaudeActivityEvent[] = [
      { turn: 2, step: 1, ordinal: 1, kind: 'tool-call', phase: 'started', toolUseId: 'bash-1', toolName: 'Bash', detail: JSON.stringify({ command: 'pnpm test' }) },
      { turn: 2, step: 1, ordinal: 2, kind: 'subagent', phase: 'started', taskId: 'foreground', title: 'Run tests' },
      { turn: 2, step: 1, ordinal: 3, kind: 'tool-result', phase: 'completed', toolUseId: 'bash-1', detail: 'passed' },
      { turn: 2, step: 1, ordinal: 4, kind: 'subagent', phase: 'started', taskId: 'background', title: 'Watch logs' },
      { turn: 2, step: 1, ordinal: 5, kind: 'subagent', phase: 'started', taskId: 'agent', title: 'Explore code' },
    ]
    const tasks = [
      { taskId: 'foreground', description: 'Run tests', status: 'completed' as const, taskType: 'local_bash' },
      { taskId: 'background', description: 'Watch logs', status: 'running' as const, taskType: 'local_bash', backgrounded: true },
      { taskId: 'agent', description: 'Explore code', status: 'running' as const, subagentType: 'Explore' },
    ]

    expect(transcriptItemsForStep(activities, 2, 1)).toEqual([
      expect.objectContaining({ kind: 'tools', tools: [expect.objectContaining({ toolUseId: 'bash-1' })] }),
    ])

    const items = transcriptItemsForStep(activities, 2, 1, tasks)
    expect(items).toHaveLength(3)
    expect(items[0]).toMatchObject({ kind: 'tools', tools: [{ toolUseId: 'bash-1', output: 'passed' }] })
    expect(items).not.toEqual(expect.arrayContaining([
      expect.objectContaining({ kind: 'activity', row: expect.objectContaining({ activity: expect.objectContaining({ taskId: 'foreground' }) }) }),
    ]))
    expect(items).toEqual(expect.arrayContaining([
      expect.objectContaining({ kind: 'activity', row: expect.objectContaining({ activity: expect.objectContaining({ taskId: 'background' }) }) }),
      expect.objectContaining({ kind: 'activity', row: expect.objectContaining({ activity: expect.objectContaining({ taskId: 'agent' }) }) }),
    ]))
  })

  it('hides uncorrelated lifecycle noise while keeping classified background work', () => {
    const uncorrelated: ClaudeActivityEvent = {
      turn: 2, step: 1, ordinal: 1, kind: 'subagent', phase: 'updated', title: 'Claude subagent update',
    }
    const unknownTask: ClaudeActivityEvent = {
      turn: 2, step: 1, ordinal: 2, kind: 'subagent', phase: 'started', taskId: 'unknown', title: 'Push branch',
    }
    const background: ClaudeActivityEvent = {
      turn: 2, step: 1, ordinal: 3, kind: 'subagent', phase: 'completed', taskId: 'background', title: 'Run full test suite',
    }
    expect(transcriptItemsForStep([uncorrelated, unknownTask, background], 2, 1, [
      { taskId: 'background', description: 'Run full test suite', status: 'completed', taskType: 'local_bash', backgrounded: true },
    ])).toEqual([
      expect.objectContaining({ kind: 'activity', row: expect.objectContaining({ activity: expect.objectContaining({ taskId: 'background' }) }) }),
    ])
  })

  it('folds task lifecycle messages sharing a taskId into one settled row', () => {
    const started: ClaudeActivityEvent = {
      turn: 2,
      step: 1,
      ordinal: 5,
      kind: 'subagent',
      phase: 'started',
      taskId: 'background-1',
      title: 'Inspect files',
    }
    const completed: ClaudeActivityEvent = {
      ...started,
      ordinal: 6,
      phase: 'completed',
      summary: 'Inspect files',
    }

    expect(lifecycleRows([started, completed], 2, 1, [
      { taskId: 'background-1', description: 'Inspect files', status: 'completed', backgrounded: true },
    ])).toEqual([expect.objectContaining({
      running: false,
      activity: expect.objectContaining({ taskId: 'background-1', phase: 'completed' }),
    })])
  })

  it('settles historical task progress from the authoritative task snapshot', () => {
    const progress: ClaudeActivityEvent = {
      turn: 2,
      step: 1,
      ordinal: 5,
      kind: 'subagent',
      phase: 'updated',
      taskId: 'subagent-1',
      title: 'Running inspect files',
    }
    expect(lifecycleRows([progress], 2, 1, [
      { taskId: 'subagent-1', description: 'inspect files', status: 'completed', subagentType: 'Explore' },
    ])).toEqual([expect.objectContaining({
      running: false,
      activity: expect.objectContaining({ phase: 'completed', title: 'inspect files' }),
    })])
    expect(lifecycleRows([progress], 2, 1, [
      { taskId: 'subagent-1', description: 'inspect files', status: 'running', subagentType: 'Explore' },
    ])).toEqual([expect.objectContaining({ running: true })])
    expect(lifecycleRows([progress], 2, 1, [
      { taskId: 'subagent-1', description: 'inspect files', status: 'failed', subagentType: 'Explore' },
    ])).toEqual([expect.objectContaining({
      running: false,
      activity: expect.objectContaining({ phase: 'failed', isError: true }),
    })])
  })

  it('mounts live Claude activity at step/start and keeps it after turn/end', async () => {
    const turnStart = { type: 'turn/start', seq: 1, time: 1, data: { turn: 2 } }
    const stepStart = { type: 'step/start', seq: 2, time: 2, data: { turn: 2, step: 1 } }
    const active = await projectConversation([turnStart, stepStart])
    expect(active.chat.map(node => [node.kind, node.data])).toEqual([
      ['claude-activity-step', { turn: 2, step: 1 }],
    ])

    const completed = await projectConversation([
      turnStart,
      stepStart,
      { type: 'turn/end', seq: 3, time: 3, data: { turn: 2 } },
    ])
    expect(completed.chat.map(node => [node.kind, node.data])).toEqual([
      ['claude-activity-step', { turn: 2, step: 1 }],
    ])
  })

  it('keeps cancelled partial Claude activity before the next user message', async () => {
    const projection = await projectConversation([
      { type: 'turn/start', seq: 1, time: 1, data: { turn: 1 } },
      { type: 'step/start', seq: 2, time: 2, data: { turn: 1, step: 1 } },
      { type: 'step/end', seq: 3, time: 3, data: { turn: 1, step: 1 } },
      { type: 'turn/end', seq: 4, time: 4, data: { turn: 1 } },
      {
        type: 'user/message',
        seq: 5,
        time: 5,
        data: {
          id: 'after-cancel',
          role: 'user',
          content: [{ type: 'text', text: 'Use a different approach' }],
          source: { kind: 'user' },
        },
      },
    ])

    expect(projection.chat.map(node => node.kind)).toEqual([
      'claude-activity-step',
      'test-user',
    ])
    expect(projection.chat[0]?.anchorSeq).toBeLessThan(projection.chat[1]?.anchorSeq ?? 0)
  })

  it('keeps incremental projection alive for a second turn after the first turn ends', async () => {
    const assembler = await conversationAssembler()
    const assistant = (seq: number, turn: number) => ({
      type: 'assistant/message',
      seq,
      time: seq,
      data: {
        turn,
        step: 1,
        message: { role: 'assistant', content: [], source: { provider: 'claude', model: 'default' } },
      },
    })
    const events = [
      { type: 'turn/start', seq: 1, time: 1, data: { turn: 1 } },
      { type: 'step/start', seq: 2, time: 2, data: { turn: 1, step: 1 } },
      assistant(3, 1),
      { type: 'step/end', seq: 4, time: 4, data: { turn: 1, step: 1 } },
      { type: 'turn/end', seq: 5, time: 5, data: { turn: 1 } },
      { type: 'turn/start', seq: 6, time: 6, data: { turn: 2 } },
      { type: 'step/start', seq: 7, time: 7, data: { turn: 2, step: 1 } },
      assistant(8, 2),
      { type: 'step/end', seq: 9, time: 9, data: { turn: 2, step: 1 } },
      { type: 'turn/end', seq: 10, time: 10, data: { turn: 2 } },
    ]

    for (const event of events) {
      assembler.append({ event, view: undefined } as never)
      expect(() => assembler.flush()).not.toThrow()
    }

    const timeline = assembler.snapshot('test-timeline') as ConversationTimelineSnapshot
    expect(timeline.turnOrder).toEqual([1, 2])
    expect(timeline.turns.get(1)?.data.get('claudeCode')).toEqual({ turn: 1 })
    expect(timeline.turns.get(2)?.data.get('claudeCode')).toEqual({ turn: 2 })
    const chat = assembler.snapshot('chat') as readonly ChatConversationViewNode[]
    expect(chat.filter(node => node.kind === 'test-assistant').map(node => node.data)).toEqual([
      { turn: 1, step: 1 },
      { turn: 2, step: 1 },
    ])
  })

  it('publishes one marker when a Claude turn contains multiple assistant steps', async () => {
    const turnStart = { type: 'turn/start', seq: 1, time: 1, data: { turn: 2 } }
    const assistant = (seq: number, step: number, provider = 'claude') => ({
      type: 'assistant/message',
      seq,
      time: seq,
      data: {
        turn: 2,
        step,
        message: { role: 'assistant', content: [], source: { provider, model: 'default' } },
      },
    })
    const projection = await projectConversation([
      turnStart,
      { type: 'step/start', seq: 2, time: 2, data: { turn: 2, step: 1 } },
      assistant(3, 1),
      { type: 'step/end', seq: 4, time: 4, data: { turn: 2, step: 1 } },
      { type: 'step/start', seq: 5, time: 5, data: { turn: 2, step: 2 } },
      assistant(6, 2),
      { type: 'step/end', seq: 7, time: 7, data: { turn: 2, step: 2 } },
      { type: 'turn/end', seq: 8, time: 8, data: { turn: 2 } },
    ])
    expect(claudeTurnDefinition.match(turnStart as never)).toEqual({ id: '2', role: 'start' })
    expect(claudeTurnDefinition.match(assistant(3, 1) as never)).toEqual({ id: '2', role: 'update' })
    expect(projection.timeline.turns.get(2)?.data.get('claudeCode')).toEqual({ turn: 2 })
    expect(projection.chat.map(node => [node.kind, node.data])).toEqual([
      ['claude-activity-step', { turn: 2, step: 1 }],
      ['test-assistant', { turn: 2, step: 1 }],
      ['claude-activity-step', { turn: 2, step: 2 }],
      ['test-assistant', { turn: 2, step: 2 }],
    ])
    expect(projection.chat[0]?.anchorSeq).toBeLessThan(projection.chat[1]?.anchorSeq ?? 0)
    expect(projection.chat[0]?.location.kind).toBe('step')
    expect(projection.chat[2]?.anchorSeq).toBeLessThan(projection.chat[3]?.anchorSeq ?? 0)

    const native = await projectConversation([
      turnStart,
      { type: 'step/start', seq: 2, time: 2, data: { turn: 2, step: 1 } },
      assistant(3, 1, 'native'),
    ])
    expect(native.timeline.turns.get(2)?.data.get('claudeCode')).toBeUndefined()
    // Generic live anchors exist, but their renderers stay null when a native
    // turn has no Claude sidecar activities or tasks.
    expect(native.chat.map(node => node.kind)).toEqual(['test-assistant', 'claude-activity-step'])
  })

  it('selects the turn tail from engine-owned turn data', () => {
    expect(selectClaudeTurn({
      turn: { data: { get: () => ({ turn: 2 }) } },
    } as never)).toEqual({ turn: 2 })
    expect(selectClaudeTurn({ turn: { data: { get: () => undefined } } } as never)).toBeNull()
  })
})

describe('renderer ownership per step', () => {
  const step = (overrides: Partial<ClaudeActivityEvent>[]): ClaudeActivityEvent[] =>
    overrides.map((item, index) => ({ turn: 1, step: 1, ordinal: index + 1, kind: 'text', ...item } as ClaudeActivityEvent))

  it('draws nothing for a step the Host recorded under the native renderer', () => {
    // The regression this guards: the Host switches renderer on the next turn
    // while a running Client keeps whatever it decided at boot. If the Client
    // decided from its own copy of the setting, the step would be drawn twice —
    // once as mirrored native tool cards and assistant text, once here.
    const native = step([
      { kind: 'text', text: 'Here is the plan.', renderer: 'native' },
      { kind: 'tool-call', ordinal: 2, toolUseId: 'tool-1', toolName: 'Bash', detail: '{"command":"ls"}', renderer: 'native' },
    ])
    expect(nativelyRenderedStep(native, 1, 1)).toBe(true)
    expect(transcriptItemsForStep(native, 1, 1)).toEqual([])
  })

  it('keeps drawing a step recorded before the stamp existed or under the plugin renderer', () => {
    const legacy = step([{ kind: 'text', text: 'Here is the plan.' }])
    expect(nativelyRenderedStep(legacy, 1, 1)).toBe(false)
    expect(transcriptItemsForStep(legacy, 1, 1)).toEqual([
      { kind: 'text', ordinal: 1, text: 'Here is the plan.' },
    ])
  })

  it('scopes the decision to the step, so history keeps the renderer it was recorded with', () => {
    const mixed = [
      ...step([{ kind: 'text', text: 'Older turn.' }]),
      { turn: 2, step: 1, ordinal: 1, kind: 'text', text: 'Newer turn.', renderer: 'native' } as ClaudeActivityEvent,
    ]
    expect(transcriptItemsForStep(mixed, 1, 1)).toHaveLength(1)
    expect(transcriptItemsForStep(mixed, 2, 1)).toEqual([])
  })
})
