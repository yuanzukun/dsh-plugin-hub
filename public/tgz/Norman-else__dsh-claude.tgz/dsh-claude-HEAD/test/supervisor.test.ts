import { randomUUID } from 'node:crypto'
import { PassThrough } from 'node:stream'
import { rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import type {
  Options as ClaudeOptions,
  ModelInfo,
  Query,
  SDKMessage,
  SDKUserMessage,
} from '@anthropic-ai/claude-agent-sdk'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { SubprocessHandle } from '@deepseek-ai/dsh-subprocess'
import { AsyncQueue } from '../src/async-queue.ts'
import { latestClaudeModels, resetClaudeModels } from '../src/model-catalog.ts'
import { ClaudeSidecarRepository } from '../src/sidecar.ts'
import type { ClaudeActivityInput } from '../src/events.ts'
import type { ClaudeRenderMode } from '../src/constants.ts'
import {
  CLAUDE_INTERRUPT_TIMEOUT_MS,
  CLAUDE_METADATA_TIMEOUT_MS,
  ClaudeOutcomeUnknownError,
  ClaudeProcessLimitError,
  ClaudeSupervisor,
  ClaudeTurnBusyError,
  PLAN_MODE_HANDOFF_PROMPT,
  SYSTEM_PROMPT_APPEND,
  claudePermissionMode,
  type ClaudeQueryFactory,
  type ClaudeTurnStreamEvent,
} from '../src/supervisor.ts'

class FakeQuery extends AsyncQueue<SDKMessage> {
  readonly interrupt = vi.fn(async () => undefined)
  readonly backgroundTasks = vi.fn(async (_toolUseId?: string) => true)
  readonly setModel = vi.fn(async () => undefined)
  readonly applyFlagSettings = vi.fn(async (_settings: unknown) => undefined)
  readonly setPermissionMode = vi.fn(async () => undefined)
  readonly initializationResult = vi.fn(async () => ({
    commands: [],
    agents: [],
    output_style: 'default',
    available_output_styles: [],
    models: this.models,
    account: {},
  }))
  readonly supportedCommands = vi.fn(async () => [
    { name: 'review', description: 'Review changes', argumentHint: '<path>' },
  ])
  readonly getContextUsage = vi.fn(async () => ({
    categories: [{ name: 'Messages', tokens: 120, color: '#3b82f6' }],
    totalTokens: 120,
    maxTokens: 200_000,
    rawMaxTokens: 200_000,
    percentage: 0,
    gridRows: [],
    model: 'claude-test',
    memoryFiles: [],
    mcpTools: [],
    agents: [],
    isAutoCompactEnabled: true,
    apiUsage: null,
  }))
  readonly options: ClaudeOptions
  readonly input: AsyncIterable<SDKUserMessage>

  constructor(input: AsyncIterable<SDKUserMessage>, options: ClaudeOptions, readonly models: ModelInfo[] = []) {
    super()
    this.input = input
    this.options = options
  }
}

function factory(models: ModelInfo[] = []) {
  const queries: FakeQuery[] = []
  const create: ClaudeQueryFactory = ({ prompt, options }) => {
    const fake = new FakeQuery(prompt, options, models)
    queries.push(fake)
    return fake as unknown as Query
  }
  return { create, queries }
}

function fakeAgent(id = 'dsh-session-1', cwd = '/workspace', onAppend?: (type: string, data: unknown) => void) {
  const events: Array<{ type: string; data: unknown; seq: number; time: number }> = [
    { type: 'turn/start', data: { turn: 1 }, seq: 0, time: 1 },
    { type: 'step/start', data: { turn: 1, step: 1 }, seq: 1, time: 2 },
  ]
  let appendError: unknown
  const session = {
    header: { cwd },
    // Host 0.1.2-rc.1: `Session.events` is gone; the snapshot is a method.
    snapshotEvents: () => Object.freeze([...events]),
    append: async (type: string, data: unknown) => {
      onAppend?.(type, data)
      if (appendError !== undefined) throw appendError
      const event = { type, data, seq: events.length, time: Date.now() }
      events.push(event)
      return event
    },
  }
  const registeredTools: string[] = []
  const agent = {
    id,
    session,
    ctx: {
      tools: {
        register: (definition: { name: string }) => {
          registeredTools.push(definition.name)
          return () => undefined
        },
      },
    },
    failAppend: (error: unknown) => { appendError = error },
  } as unknown as Agent & { failAppend(error: unknown): void }
  return { agent, events, registeredTools }
}

const sidecarRoots: string[] = []
const sidecars = new WeakMap<ClaudeSupervisor, ClaudeSidecarRepository>()
/** The live config object each supervisor reads, so a test can change a
 *  setting mid-turn the way the settings route does. */
const configs = new WeakMap<ClaudeSupervisor, { renderMode: ClaudeRenderMode; maxProcesses: number }>()

afterEach(async () => {
  resetClaudeModels()
  // Sidecar appends can still be landing when a test ends; let rm retry ENOTEMPTY.
  await Promise.all(sidecarRoots.splice(0).map(root => rm(root, { recursive: true, force: true, maxRetries: 5, retryDelay: 50 })))
})

function supervisor(
  create: ClaudeQueryFactory,
  maxProcesses = 4,
  idleTimeoutMs = 60_000,
  suppliedSidecar?: ClaudeSidecarRepository,
  renderMode: ClaudeRenderMode = 'plugin',
  warnings?: string[],
) {
  const root = join(tmpdir(), `dsh-claude-supervisor-${randomUUID()}`)
  sidecarRoots.push(root)
  const sidecar = suppliedSidecar ?? new ClaudeSidecarRepository({ root })
  const config = {
    executablePath: '/local/claude',
    idleTimeoutMs,
    maxProcesses,
    defaultModel: 'default',
    renderMode,
  }
  const runtime = new ClaudeSupervisor({
    runtime: { spawn: () => { throw new Error('fake query must not spawn') } },
    approval: { request: async () => 'rejected' },
    userQuestions: { ask: async () => ({ answers: [] }) },
    config,
    queryFactory: create,
    sidecar,
    ...(warnings === undefined ? {} : { logger: { warn: (message: string) => { warnings.push(message) } } }),
  })
  sidecars.set(runtime, sidecar)
  configs.set(runtime, config)
  return runtime
}

function projection(runtime: ClaudeSupervisor, sessionId = 'dsh-session-1') {
  return sidecars.get(runtime)!.read(sessionId)
}

class HookedSidecar extends ClaudeSidecarRepository {
  readonly #beforeAppend: (activity: ClaudeActivityInput) => void

  constructor(root: string, beforeAppend: (activity: ClaudeActivityInput) => void) {
    super({ root })
    this.#beforeAppend = beforeAppend
  }

  override appendActivity(sessionId: string, activity: ClaudeActivityInput & { turn: number; step: number; ordinal: number }) {
    this.#beforeAppend(activity)
    return super.appendActivity(sessionId, activity)
  }
}

class DeferredImportSidecar extends ClaudeSidecarRepository {
  readonly started: Promise<void>
  readonly #release: Promise<void>
  #markStarted: (() => void) | undefined
  release: (() => void) | undefined

  constructor(root: string) {
    super({ root })
    this.started = new Promise(resolve => { this.#markStarted = resolve })
    this.#release = new Promise(resolve => { this.release = resolve })
  }

  override async importLegacy(...args: Parameters<ClaudeSidecarRepository['importLegacy']>) {
    this.#markStarted?.()
    await this.#release
    return super.importLegacy(...args)
  }
}

const init = (sessionId = 'claude-session-1', cwd = '/workspace') => ({
  type: 'system',
  subtype: 'init',
  session_id: sessionId,
  claude_code_version: '2.1.233',
  cwd,
}) as SDKMessage

const delta = (text: string) => ({
  type: 'stream_event',
  event: { type: 'content_block_delta', delta: { type: 'text_delta', text } },
}) as SDKMessage

const result = (text = 'hello', sessionId = 'claude-session-1') => ({
  type: 'result',
  subtype: 'success',
  session_id: sessionId,
  result: text,
  total_cost_usd: 0.01,
  usage: { input_tokens: 4, output_tokens: 2 },
}) as SDKMessage

const toolCallMessage = {
  type: 'assistant',
  message: {
    role: 'assistant',
    content: [{ type: 'tool_use', id: 'tool-1', name: 'Bash', input: { command: 'ls -la' } }],
  },
} as SDKMessage

const toolResultMessage = {
  type: 'user',
  message: {
    role: 'user',
    content: [{ type: 'tool_result', tool_use_id: 'tool-1', content: 'listed' }],
  },
  tool_use_result: 'listed',
} as SDKMessage

async function collect(stream: AsyncIterable<ClaudeTurnStreamEvent>): Promise<ClaudeTurnStreamEvent[]> {
  const events: ClaudeTurnStreamEvent[] = []
  for await (const event of stream) events.push(event)
  return events
}

describe('DSH access mode mapping', () => {
  it.each([
    ['read-only', 'plan'],
    ['workspace-write', 'acceptEdits'],
    ['danger-full-access', 'bypassPermissions'],
  ] as const)('maps %s to Claude %s', (sandboxMode, permissionMode) => {
    expect(claudePermissionMode([
      { type: 'sandbox/mode', data: { mode: sandboxMode } },
    ])).toBe(permissionMode)
  })

  it('uses the newest sandbox event and fails safe to plan for missing or invalid state', () => {
    expect(claudePermissionMode([])).toBe('plan')
    expect(claudePermissionMode([
      { type: 'sandbox/mode', data: { mode: 'workspace-write' } },
      { type: 'sandbox/mode', data: { mode: 'invalid' } },
    ])).toBe('plan')
  })
})

describe('Claude supervisor', () => {
  it('passes Claude Code’s default alias explicitly when creating a Query', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const catalog = runtime.supportedCommands(owner.agent)
    await vi.waitFor(() => expect(transport.queries).toHaveLength(1))
    expect(transport.queries[0]?.options.model).toBe('default')
    transport.queries[0]!.push(init())
    await catalog
    await runtime.dispose()
  })

  it("counts a new process's first turn in full even when it outspends the previous process", async () => {
    // A drop in the counter is not the respawn signal: here the new process's
    // first reading is higher than the old process's whole run.
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const turn = async (cost: number) => {
      const output = await runtime.runTurn({ agent: owner.agent, prompt: 'work' })
      const query = transport.queries.at(-1)!
      query.push(init())
      query.push({ ...result('done') as object, total_cost_usd: cost } as SDKMessage)
      await collect(output)
    }
    await turn(0.1)
    await runtime.disposeSession(owner.agent.id as string)
    await turn(0.3)
    const rows = (await projection(runtime)).activities.filter(activity => activity.kind === 'usage')
    expect(rows.map(row => row.usage?.cumulativeCostUsd)).toEqual([0.1, 0.4])
    await runtime.dispose()
  })

  it("continues a session's cost from the sidecar after the supervisor restarts", async () => {
    const root = join(tmpdir(), `dsh-claude-supervisor-${randomUUID()}`)
    sidecarRoots.push(root)
    const owner = fakeAgent()
    const turn = async (runtime: ClaudeSupervisor, transport: ReturnType<typeof factory>, cost: number) => {
      const output = await runtime.runTurn({ agent: owner.agent, prompt: 'work' })
      const query = transport.queries.at(-1)!
      query.push(init())
      query.push({ ...result('done') as object, total_cost_usd: cost } as SDKMessage)
      await collect(output)
    }
    const firstTransport = factory()
    const first = supervisor(firstTransport.create, 4, 60_000, new ClaudeSidecarRepository({ root }))
    await turn(first, firstTransport, 0.25)
    await first.dispose()

    const secondTransport = factory()
    const second = supervisor(secondTransport.create, 4, 60_000, new ClaudeSidecarRepository({ root }))
    await turn(second, secondTransport, 0.1)
    const rows = (await projection(second)).activities.filter(activity => activity.kind === 'usage')
    expect(rows.map(row => row.usage?.cumulativeCostUsd)).toEqual([0.25, 0.35])
    await second.dispose()
  })

  it('keeps a session\'s cost whole across a respawn', async () => {
    // The CLI's cumulative cost is per query() call, so a respawned process
    // starts counting again from zero. The transcript is one session, and the
    // money it spent is the sum of what its processes spent.
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const turn = async (cost: number) => {
      const output = await runtime.runTurn({ agent: owner.agent, prompt: 'work' })
      const query = transport.queries.at(-1)!
      query.push(init())
      query.push({ ...result('done') as object, total_cost_usd: cost } as SDKMessage)
      await collect(output)
    }
    await turn(0.25)
    await turn(0.5)
    // The process was evicted and respawned: this counter is the new epoch's.
    await runtime.disposeSession(owner.agent.id as string)
    await turn(0.1)
    const rows = (await projection(runtime)).activities.filter(activity => activity.kind === 'usage')
    expect(rows.map(row => row.usage?.cumulativeCostUsd)).toEqual([0.25, 0.5, 0.6])
    expect(rows.map(row => row.summary)).toEqual([
      '4 input / 2 output tokens · $0.2500 cumulative',
      '4 input / 2 output tokens · $0.5000 cumulative',
      '4 input / 2 output tokens · $0.6000 cumulative',
    ])
    await runtime.dispose()
  })

  it('starts the Query in the Claude mode mapped from DSH access', async () => {
    const transport = factory()
    const owner = fakeAgent()
    owner.events.push({
      type: 'sandbox/mode',
      data: { mode: 'workspace-write' },
      seq: owner.events.length,
      time: Date.now(),
    })
    const runtime = supervisor(transport.create)
    const catalog = runtime.supportedCommands(owner.agent)
    await vi.waitFor(() => expect(transport.queries).toHaveLength(1))
    expect(transport.queries[0]?.options.permissionMode).toBe('acceptEdits')
    expect(transport.queries[0]?.options.allowDangerouslySkipPermissions).toBe(true)
    transport.queries[0]!.push(init())
    await catalog
    await runtime.dispose()
  })

  it('appends the plan-mode handoff and file-link rules to the Claude Code system prompt', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const catalog = runtime.supportedCommands(owner.agent)
    await vi.waitFor(() => expect(transport.queries).toHaveLength(1))
    expect(transport.queries[0]?.options.systemPrompt).toEqual({
      type: 'preset',
      preset: 'claude_code',
      append: SYSTEM_PROMPT_APPEND,
    })
    expect(SYSTEM_PROMPT_APPEND).toContain(PLAN_MODE_HANDOFF_PROMPT)
    expect(SYSTEM_PROMPT_APPEND).toContain('[name](<path>)')
    transport.queries[0]!.push(init())
    await catalog
    await runtime.dispose()
  })

  it('syncs a changed native DSH access mode before the next Query operation', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const first = runtime.supportedCommands(owner.agent)
    await vi.waitFor(() => expect(transport.queries).toHaveLength(1))
    const query = transport.queries[0]!
    query.push(init())
    await first

    owner.events.push({
      type: 'sandbox/mode',
      data: { mode: 'danger-full-access' },
      seq: owner.events.length,
      time: Date.now(),
    })
    await runtime.supportedCommands(owner.agent)
    expect(query.setPermissionMode).toHaveBeenCalledWith('bypassPermissions')
    expect(query.setPermissionMode.mock.invocationCallOrder[0])
      .toBeLessThan(query.supportedCommands.mock.invocationCallOrder.at(-1)!)
    await runtime.dispose()
  })

  it('does not execute the next Query operation when permission-mode synchronization fails', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const first = runtime.supportedCommands(owner.agent)
    await vi.waitFor(() => expect(transport.queries).toHaveLength(1))
    const query = transport.queries[0]!
    query.push(init())
    await first

    owner.events.push({
      type: 'sandbox/mode',
      data: { mode: 'workspace-write' },
      seq: owner.events.length,
      time: Date.now(),
    })
    query.setPermissionMode.mockRejectedValueOnce(new Error('switch failed'))
    await expect(runtime.supportedCommands(owner.agent)).rejects.toThrow('switch failed')
    expect(query.supportedCommands).toHaveBeenCalledTimes(1)
    await runtime.dispose()
  })

  it('discards a process whose metadata request never answers instead of stalling admission', async () => {
    vi.useFakeTimers()
    try {
      const transport = factory()
      const owner = fakeAgent()
      const runtime = supervisor(transport.create)
      await runtime.supportedCommands(owner.agent)
      const query = transport.queries[0]!

      query.supportedCommands.mockReturnValueOnce(new Promise<never>(() => {}))
      const wedged = runtime.supportedCommands(owner.agent)
      const settled = expect(wedged).rejects.toThrow('timed out')
      await vi.advanceTimersByTimeAsync(CLAUDE_METADATA_TIMEOUT_MS)
      await settled

      // Metadata shares turn admission's gate, so the wedged process must be
      // discarded and the gate released: the next request runs on a fresh one.
      expect(runtime.snapshots()).toHaveLength(0)
      await expect(runtime.supportedCommands(owner.agent)).resolves.toHaveLength(1)
      expect(transport.queries).toHaveLength(2)
      await runtime.dispose()
    } finally {
      vi.useRealTimers()
    }
  })

  it('discards a query that stops answering metadata instead of reusing it on the next request', async () => {
    vi.useFakeTimers()
    try {
      const transport = factory()
      const owner = fakeAgent()
      const runtime = supervisor(transport.create)
      await runtime.supportedCommands(owner.agent)
      const query = transport.queries[0]!

      // Bounding the request is only half the cure: keeping the wedged entry
      // makes every later request on the same model time out on it again.
      query.supportedCommands.mockReturnValueOnce(new Promise<never>(() => {}))
      const wedged = runtime.supportedCommands(owner.agent)
      const settled = expect(wedged).rejects.toThrow('timed out')
      await vi.advanceTimersByTimeAsync(CLAUDE_METADATA_TIMEOUT_MS)
      await settled

      expect(runtime.snapshots()).toHaveLength(0)
      await expect(runtime.supportedCommands(owner.agent)).resolves.toHaveLength(1)
      expect(transport.queries).toHaveLength(2)
      // Same model, so nothing would have forced a switch: only the discard
      // keeps the dead query from serving the next read.
      expect(query.supportedCommands).toHaveBeenCalledTimes(2)
      await runtime.dispose()
    } finally {
      vi.useRealTimers()
    }
  })

  it('reads the Claude command catalog without opening a DSH turn', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const catalog = runtime.supportedCommands(owner.agent)
    await vi.waitFor(() => expect(transport.queries).toHaveLength(1))
    transport.queries[0]!.push(init())
    await expect(catalog).resolves.toEqual([
      { name: 'review', description: 'Review changes', argumentHint: '<path>' },
    ])
    expect(transport.queries).toHaveLength(1)
    expect(owner.events.some(event => event.type === 'claude-code/activity')).toBe(false)
    await runtime.dispose()
  })


  it('rejects metadata reads while the session has an active turn', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
    await expect(runtime.supportedCommands(owner.agent)).rejects.toBeInstanceOf(ClaudeTurnBusyError)
    transport.queries[0]!.push(init())
    transport.queries[0]!.push(result())
    await collect(output)
    await runtime.dispose()
  })

  it('forwards structured multimodal content without changing block order', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const content = [
      { type: 'text' as const, text: 'inspect this' },
      {
        type: 'image' as const,
        source: { type: 'base64' as const, media_type: 'image/png' as const, data: 'AQID' },
      },
    ]
    const output = await runtime.runTurn({ agent: owner.agent, prompt: content })
    const query = transport.queries[0]!
    const input = await query.input[Symbol.asyncIterator]().next()
    expect(input.value?.message).toEqual({ role: 'user', content })
    query.push(init())
    query.push(result())
    await collect(output)
    await runtime.dispose()
  })

  it('streams one complete turn and persists the Claude session binding', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
    const query = transport.queries[0]!
    const input = await query.input[Symbol.asyncIterator]().next()
    expect(input.value?.message).toEqual({ role: 'user', content: 'hello' })
    query.push(init())
    query.push(delta('hel'))
    query.push(delta('lo'))
    query.push(result())
    await expect(collect(output)).resolves.toEqual([
      { type: 'text-delta', text: 'hel' },
      { type: 'text-delta', text: 'lo' },
      { type: 'usage', usage: { inputTokens: 4, outputTokens: 2, cumulativeCostUsd: 0.01 } },
      // The closing prose doubles as the Host's answer under the plugin renderer.
      { type: 'answer', text: 'hello' },
      { type: 'complete', text: 'hello' },
    ])
    const settled = await projection(runtime)
    expect(settled).toMatchObject({
      binding: { claudeSessionId: 'claude-session-1' },
    })
    expect(settled.activities.filter(activity => activity.kind === 'text')).toEqual([
      expect.objectContaining({ text: 'hello', answer: true }),
    ])
    expect(runtime.snapshots()[0]).toMatchObject({ state: 'idle', claudeSessionId: 'claude-session-1' })
    await runtime.dispose()
  })

  it('learns the context window of whichever model a finished turn ran on', async () => {
    // DSH hides its context meter unless the route publishes a capacity, and
    // only `opus[1m]` carries a static one — every other selector id has to be
    // learned from the CLI, or the meter never appears for it.
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    expect(runtime.contextWindow('sonnet')).toBeUndefined()

    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello', model: 'sonnet' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(result())
    await collect(output)

    // The probe deliberately runs after the turn's stream closes, so it never
    // delays the reply the user is waiting on.
    await vi.waitFor(() => expect(runtime.contextWindow('sonnet')).toBe(200_000))
    expect(runtime.contextWindow('claude-test')).toBe(200_000)
    expect(query.getContextUsage).toHaveBeenCalledTimes(1)

    // Once known, a later turn on the same model must not probe again.
    const second = await runtime.runTurn({ agent: owner.agent, prompt: 'again', model: 'sonnet' })
    query.push(result('again'))
    await collect(second)
    expect(query.getContextUsage).toHaveBeenCalledTimes(1)
    await runtime.dispose()
  })

  it('keeps a turn alive when the context window probe fails', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello', model: 'haiku' })
    const query = transport.queries[0]!
    query.getContextUsage.mockRejectedValueOnce(new Error('probe unavailable'))
    query.push(init())
    query.push(result())

    await expect(collect(output)).resolves.toContainEqual({ type: 'complete', text: 'hello' })
    expect(runtime.contextWindow('haiku')).toBeUndefined()
    await runtime.dispose()
  })

  it('keeps the real message_delta sample when a placeholder zero follows it', async () => {
    // Claude Code forwards zero usage on the assistant message and the real
    // per-request numbers on the partial stream's message_delta. Whichever
    // arrives last, a zero must never replace the real prompt sample.
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'stream_event',
      parent_tool_use_id: null,
      event: { type: 'message_delta', usage: { input_tokens: 4, output_tokens: 12, cache_read_input_tokens: 250_000, cache_creation_input_tokens: 300 } },
    } as unknown as SDKMessage)
    query.push({
      type: 'assistant',
      parent_tool_use_id: null,
      message: { content: [], usage: { input_tokens: 0, output_tokens: 0, cache_read_input_tokens: 0, cache_creation_input_tokens: 0 } },
    } as SDKMessage)
    query.push({
      type: 'result',
      subtype: 'success',
      session_id: 'claude-session-1',
      result: 'hello',
      total_cost_usd: 0.01,
      usage: { input_tokens: 4, output_tokens: 12, cache_read_input_tokens: 250_000, cache_creation_input_tokens: 300 },
    } as SDKMessage)

    const events = await collect(output)
    expect(events).toContainEqual({
      type: 'usage',
      usage: { inputTokens: 4, outputTokens: 12, cacheReadTokens: 250_000, cacheCreationTokens: 300 },
    })
    await runtime.dispose()
  })

  it('reports the newest call prompt-side and the whole turn output', async () => {
    // DSH divides the PROMPT side by the context window. The result usage sums
    // every call in the turn — here two calls that each re-read the same
    // prompt from cache — so reporting it would read as a context twice its
    // real size. Output is not part of that pressure sum, and the last call is
    // usually a short wrap-up, so the turn total is the honest number there.
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'assistant',
      parent_tool_use_id: null,
      message: { content: [], usage: { input_tokens: 1, output_tokens: 10, cache_read_input_tokens: 900 } },
    } as SDKMessage)
    query.push({
      type: 'assistant',
      parent_tool_use_id: 'task-1',
      message: { content: [], usage: { input_tokens: 7, output_tokens: 2, cache_read_input_tokens: 50 } },
    } as SDKMessage)
    query.push({
      type: 'assistant',
      parent_tool_use_id: null,
      message: { content: [], usage: { input_tokens: 2, output_tokens: 20, cache_read_input_tokens: 1_000 } },
    } as SDKMessage)
    query.push({
      type: 'result',
      subtype: 'success',
      session_id: 'claude-session-1',
      result: 'hello',
      total_cost_usd: 0.01,
      usage: { input_tokens: 3, output_tokens: 30, cache_read_input_tokens: 1_900 },
    } as SDKMessage)

    const events = await collect(output)
    expect(events).toContainEqual({
      type: 'usage',
      usage: { inputTokens: 2, outputTokens: 30, cacheReadTokens: 1_000 },
    })
    // The audit trail still records what the whole turn actually billed, now
    // with the wall clock the transcript footer has no other way to know.
    const snapshot = await projection(runtime)
    const recorded = snapshot.activities.filter(activity => activity.kind === 'usage')
    expect(recorded).toContainEqual(expect.objectContaining({
      usage: expect.objectContaining({
        inputTokens: 3,
        outputTokens: 30,
        cacheReadTokens: 1_900,
        cumulativeCostUsd: 0.01,
        durationMs: expect.any(Number),
      }),
    }))
    await runtime.dispose()
  })

  it('falls back to the turn total when no call reported its own usage', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(result())
    await expect(collect(output)).resolves.toContainEqual({
      type: 'usage',
      usage: { inputTokens: 4, outputTokens: 2, cumulativeCostUsd: 0.01 },
    })
    await runtime.dispose()
  })

  it('tolerates a repeated system/init across turns', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(delta('hi'))
    query.push(init()) // re-emitted by 2.1.233 in long-lived mode
    query.push(result('hi'))
    await expect(collect(output)).resolves.toContainEqual({ type: 'complete', text: 'hi' })
    expect(runtime.snapshots()[0]).toMatchObject({ state: 'idle', claudeSessionId: 'claude-session-1' })
    await runtime.dispose()
  })

  it('keeps the launch cwd while later turns and a respawn report Claude’s changed shell cwd', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const first = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
    const query = transport.queries[0]!
    expect(query.options).toMatchObject({ cwd: '/workspace' })
    expect(query.options.resume).toBeUndefined()
    query.push(init())
    query.push(result('hello'))
    await collect(first)

    owner.events.push(
      { type: 'turn/start', data: { turn: 2 }, seq: owner.events.length, time: 3 },
      { type: 'step/start', data: { turn: 2, step: 1 }, seq: owner.events.length + 1, time: 4 },
    )
    const second = await runtime.runTurn({ agent: owner.agent, prompt: 'inspect the service' })
    query.push(init())
    query.push({
      type: 'assistant',
      message: {
        role: 'assistant',
        content: [{ type: 'tool_use', id: 'cd-1', name: 'Bash', input: { command: 'cd /workspace/service && pwd' } }],
      },
    } as SDKMessage)
    query.push({
      type: 'user',
      message: {
        role: 'user',
        content: [{ type: 'tool_result', tool_use_id: 'cd-1', content: '/workspace/service' }],
      },
    } as SDKMessage)
    query.push(result('inspected'))
    await collect(second)

    owner.events.push(
      { type: 'turn/start', data: { turn: 3 }, seq: owner.events.length, time: 5 },
      { type: 'step/start', data: { turn: 3, step: 1 }, seq: owner.events.length + 1, time: 6 },
    )
    const third = await runtime.runTurn({ agent: owner.agent, prompt: 'continue' })
    query.push(init('claude-session-1', '/workspace/service'))
    query.push(result('continued'))
    await expect(collect(third)).resolves.toContainEqual({ type: 'complete', text: 'continued' })
    expect(transport.queries).toHaveLength(1)
    expect(runtime.snapshots()[0]).toMatchObject({ cwd: '/workspace', claudeSessionId: 'claude-session-1', state: 'idle' })
    expect(owner.agent.session.header.cwd).toBe('/workspace')
    const sidecar = sidecars.get(runtime)!
    expect((await sidecar.read(owner.agent.id as string)).binding).toMatchObject({ claudeSessionId: 'claude-session-1', cwd: '/workspace/service' })
    await runtime.dispose()

    const restarted = supervisor(transport.create, 4, 60_000, new ClaudeSidecarRepository({ root: sidecar.root }))
    try {
      const fourth = await restarted.runTurn({ agent: owner.agent, prompt: 'continue after restart' })
      const resumed = transport.queries[1]!
      expect(resumed.options).toMatchObject({ cwd: '/workspace', resume: 'claude-session-1' })
      resumed.push(init('claude-session-1', '/workspace/service'))
      resumed.push(result('resumed'))
      await expect(collect(fourth)).resolves.toContainEqual({ type: 'complete', text: 'resumed' })
      expect(restarted.snapshots()[0]).toMatchObject({ cwd: '/workspace', claudeSessionId: 'claude-session-1', state: 'idle' })
    } finally {
      await restarted.dispose()
    }
  })

  it.each(['fresh', 'resumed', 'rewound'] as const)('rejects a session identity change on repeated init in a %s query', async (mode) => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const sidecar = sidecars.get(runtime)!
    if (mode !== 'fresh') {
      await sidecar.writeBinding(owner.agent.id as string, { claudeSessionId: 'claude-session-1', cwd: '/workspace' })
    }
    if (mode === 'rewound') {
      await sidecar.writeRewind(owner.agent.id as string, {
        ranges: [], anchors: [], snapshots: [], pending: { resumeAt: 'kept-chain-uuid' },
      })
    }
    try {
      const first = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
      const query = transport.queries[0]!
      const acceptedId = mode === 'rewound' ? 'claude-rewound-session' : 'claude-session-1'
      query.push(init(acceptedId))
      query.push(result('hello', acceptedId))
      await collect(first)
      if (mode === 'rewound') expect((await projection(runtime)).rewind?.pending).toBeUndefined()

      const second = await runtime.runTurn({ agent: owner.agent, prompt: 'continue' })
      query.push(init('unrelated-session'))
      // Even a result matching the unexpected init must not authorize re-binding.
      query.push(result('wrong conversation', 'unrelated-session'))
      await expect(collect(second)).rejects.toThrow(/unexpected session/u)
      expect((await projection(runtime)).binding?.claudeSessionId).toBe(acceptedId)
    } finally {
      await runtime.dispose()
    }
  })

  it('rejects an unexpected session id on the first resumed init even with the launch cwd', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    await sidecars.get(runtime)!.writeBinding(owner.agent.id as string, { claudeSessionId: 'persisted-session', cwd: '/workspace' })
    try {
      const output = await runtime.runTurn({ agent: owner.agent, prompt: 'continue' })
      transport.queries[0]!.push(init('unrelated-session'))
      await expect(collect(output)).rejects.toThrow(/unexpected session/u)
      expect((await projection(runtime)).binding?.claudeSessionId).toBe('persisted-session')
    } finally {
      await runtime.dispose()
    }
  })

  it('preserves running tasks when the long-lived query re-emits system/init', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'deploy' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'system',
      subtype: 'task_started',
      task_id: 'task-1',
      description: 'Deploy service',
      task_type: 'local_bash',
      session_id: 'claude-session-1',
    } as SDKMessage)
    query.push(result('Deployment continues in the background'))
    await collect(output)

    const revisionBeforeInit = (await projection(runtime)).revision
    query.push(init()) // protocol refresh from the same Query, not a process restart
    await vi.waitFor(async () => {
      const current = await projection(runtime)
      expect(current.revision).toBeGreaterThan(revisionBeforeInit)
      expect(current).toMatchObject({
        tasks: { tasks: [{
          taskId: 'task-1',
          description: 'Deploy service',
          status: 'running',
          originTurn: 1,
          taskType: 'local_bash',
        }] },
      })
    })
    await runtime.dispose()
  })

  it('surfaces the terminal reason for an is_error failure result', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
    transport.queries[0]!.push(init())
    transport.queries[0]!.push({
      type: 'result',
      subtype: 'success',
      is_error: true,
      terminal_reason: 'api_error',
      session_id: 'claude-session-1',
      total_cost_usd: 0,
      usage: { input_tokens: 1, output_tokens: 0 },
    } as SDKMessage)
    await expect(collect(output)).rejects.toThrow(/api_error/)
    expect(runtime.snapshots()[0]).toMatchObject({ state: 'idle', claudeSessionId: 'claude-session-1' })
    await runtime.dispose()
  })

  it('tracks Claude tasks on the session board, including after the turn ends', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'system',
      subtype: 'task_started',
      task_id: 'task-1',
      description: 'Run deploy script',
      task_type: 'local_bash',
      session_id: 'claude-session-1',
    } as SDKMessage)
    query.push(result())
    await collect(output)
    await vi.waitFor(async () => {
      await expect(projection(runtime)).resolves.toMatchObject({
        tasks: { tasks: [{ taskId: 'task-1', description: 'Run deploy script', status: 'running', originTurn: 1, taskType: 'local_bash' }] },
      })
    })
    expect((await projection(runtime)).activities.some(activity => activity.taskId === 'task-1')).toBe(true)

    // The turn is over: background notifications must still reach the board.
    query.push({
      type: 'system',
      subtype: 'task_notification',
      task_id: 'task-1',
      status: 'completed',
      summary: 'deploy finished',
      usage: { total_tokens: 120, tool_uses: 2, duration_ms: 3_000 },
      session_id: 'claude-session-1',
    } as SDKMessage)
    await vi.waitFor(async () => {
      await expect(projection(runtime)).resolves.toMatchObject({
        tasks: { tasks: [{
          taskId: 'task-1',
          status: 'completed',
          summary: 'deploy finished',
          usage: { totalTokens: 120, toolUses: 2, durationMs: 3_000 },
        }] },
      })
    })
    await runtime.dispose()
  })

  it('keeps the turn open and asks Claude for one report after all background tasks settle', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'deploy both services' })
    const collected = collect(output)
    const query = transport.queries[0]!
    const input = query.input[Symbol.asyncIterator]()
    await input.next() // direct user prompt
    query.push(init())
    for (const taskId of ['task-1', 'task-2']) {
      query.push({
        type: 'system',
        subtype: 'task_started',
        task_id: taskId,
        description: `Deploy ${taskId}`,
        task_type: 'local_bash',
        session_id: 'claude-session-1',
      } as SDKMessage)
    }
    query.push({
      type: 'system',
      subtype: 'background_tasks_changed',
      tasks: [
        { task_id: 'task-1', task_type: 'local_bash', description: 'Deploy task-1' },
        { task_id: 'task-2', task_type: 'local_bash', description: 'Deploy task-2' },
      ],
      session_id: 'claude-session-1',
    } as SDKMessage)
    query.push(result('Both deployments are running in the background.'))
    await vi.waitFor(() => expect(runtime.snapshots()[0]?.state).toBe('running'))
    // The turn is still running, so it has no closing total to show yet.
    expect((await projection(runtime)).activities.filter(activity => activity.kind === 'usage')).toEqual([])

    query.push({
      type: 'system',
      subtype: 'task_notification',
      task_id: 'task-1',
      status: 'completed',
      summary: 'first deployed',
      session_id: 'claude-session-1',
    } as SDKMessage)
    let followUpReceived = false
    const followUpPromise = input.next().then(value => {
      followUpReceived = !value.done
      return value
    })
    await Promise.resolve()
    expect(followUpReceived).toBe(false)

    // Claude Code automatically reacts to task notifications and can emit an
    // uncorrelated top-level result while other background work is still
    // running. Publish it as progress without closing the original DSH turn.
    query.push(delta('First task settled; still waiting for the second.'))
    query.push(result('First task settled; still waiting for the second.'))
    await vi.waitFor(() => expect(runtime.snapshots()[0]).toMatchObject({ state: 'running' }))
    expect(followUpReceived).toBe(false)

    query.push({
      type: 'system',
      subtype: 'task_notification',
      task_id: 'task-2',
      status: 'failed',
      summary: 'second failed',
      session_id: 'claude-session-1',
    } as SDKMessage)
    const followUp = await followUpPromise
    expect(followUp.value?.message.content).toContain('all settled')
    expect(followUp.value?.message.content).toContain('completed or failed')
    query.push(result('Service one deployed; service two failed.'))

    await expect(collected).resolves.toEqual(expect.arrayContaining([
      { type: 'segment-complete', text: 'Both deployments are running in the background.' },
      { type: 'segment-complete', text: 'First task settled; still waiting for the second.' },
      { type: 'complete', text: 'Service one deployed; service two failed.' },
    ]))
    expect(runtime.snapshots()[0]).toMatchObject({ state: 'idle' })
    // ... and one once it is over, not one per settled segment.
    expect((await projection(runtime)).activities.filter(activity => activity.kind === 'usage')).toHaveLength(1)
    await runtime.dispose()
  })

  it('folds the background tasks level signal into the board', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'system',
      subtype: 'background_tasks_changed',
      tasks: [{ task_id: 'bg-1', task_type: 'local_bash', description: 'watch logs' }],
      session_id: 'claude-session-1',
    } as SDKMessage)
    await vi.waitFor(async () => {
      await expect(projection(runtime)).resolves.toMatchObject({
        tasks: { tasks: [{ taskId: 'bg-1', description: 'watch logs', status: 'running', originTurn: 1, backgrounded: true }] },
      })
    })
    query.push(result())
    const collected = collect(output)

    // Membership leaving the level marks the task settled (REPLACE semantics).
    query.push({
      type: 'system',
      subtype: 'background_tasks_changed',
      tasks: [],
      session_id: 'claude-session-1',
    } as SDKMessage)
    await vi.waitFor(async () => {
      await expect(projection(runtime)).resolves.toMatchObject({
        tasks: { tasks: [{ taskId: 'bg-1', status: 'completed' }] },
      })
    })
    query.push(result('Background task completed.'))
    await collected
    await runtime.dispose()
  })

  it('reports the latest cumulative cost without summing across turns', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const first = await runtime.runTurn({ agent: owner.agent, prompt: 'one' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(result('one'))
    await collect(first)

    owner.events.push(
      { type: 'turn/start', data: { turn: 2 }, seq: owner.events.length, time: 3 },
      { type: 'step/start', data: { turn: 2, step: 1 }, seq: owner.events.length + 1, time: 4 },
    )
    const second = await runtime.runTurn({ agent: owner.agent, prompt: 'two' })
    query.push({
      type: 'result',
      subtype: 'success',
      session_id: 'claude-session-1',
      result: 'two',
      total_cost_usd: 0.03,
      usage: { input_tokens: 6, output_tokens: 3 },
    } as SDKMessage)
    const secondEvents = await collect(second)
    // The SDK total_cost_usd is the running total; we must report 0.03, not 0.01 + 0.03.
    expect(secondEvents).toContainEqual({
      type: 'usage',
      usage: { inputTokens: 6, outputTokens: 3, cumulativeCostUsd: 0.03 },
    })
    await runtime.dispose()
  })

  it('settles a completed turn even when durable activity append fails', async () => {
    const transport = factory()
    let failAfterStart = false
    const owner = fakeAgent()
    const root = join(tmpdir(), `dsh-claude-hook-${randomUUID()}`)
    sidecarRoots.push(root)
    const sidecar = new HookedSidecar(root, activity => {
      if (failAfterStart && activity.phase === 'completed') throw new Error('storage unavailable')
    })
    const runtime = supervisor(transport.create, 4, 60_000, sidecar)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(delta('hel'))
    failAfterStart = true
    query.push(result('hel'))
    await expect(collect(output)).resolves.toContainEqual({ type: 'complete', text: 'hel' })
    expect(runtime.snapshots()[0]).toMatchObject({ state: 'idle', claudeSessionId: 'claude-session-1' })
    await runtime.dispose()
  })

  it('learns the model lineup from the CLI, so a model shipped after this release still reaches the selector', async () => {
    // The lineup rides on the initialize response every session already awaits;
    // nothing here enumerates model ids, which is the whole point.
    const transport = factory([
      { value: 'claude-nextthing-9[1m]', resolvedModel: 'claude-nextthing-9[1m]', displayName: 'Nextthing', description: 'Ships between plugin releases' },
    ])
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: fakeAgent().agent, prompt: 'hello' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(result())
    await collect(output)

    expect(latestClaudeModels()[0]).toEqual(
      { id: 'nextthing[1m]', value: 'claude-nextthing-9[1m]', name: 'Nextthing', description: 'Ships between plugin releases', contextWindow: 1_000_000 },
    )
    await runtime.dispose()
  })

  it('keeps the live model across metadata refreshes run with the plugin default', async () => {
    // The idle refresh (commands, context usage, plan usage) runs with the
    // plugin default model. It must observe the session, not re-model it:
    // switching here raced the turn's own switch and answered on Opus.
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const first = await runtime.runTurn({ agent: owner.agent, prompt: 'one', model: 'fable' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(result('one'))
    await collect(first)

    await runtime.supportedCommands(owner.agent)
    expect(query.setModel).not.toHaveBeenCalled()
    expect(runtime.snapshots()[0]?.model).toBe('fable')
    await vi.waitFor(() => expect(runtime.contextWindow('fable')).toBe(200_000))
    await runtime.dispose()
  })

  it('rebuilds the query when the model changes and resumes the bound session', async () => {
    // A live setModel would keep the CLI's frozen system prompt, so the turn
    // answers as the old model; only a fresh process picks the new one up.
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const first = await runtime.runTurn({ agent: owner.agent, prompt: 'one', model: 'fable' })
    const query = transport.queries[0]!
    expect(query.options.model).toBe('fable')
    query.push(init())
    query.push(result('one'))
    await collect(first)

    owner.events.push(
      { type: 'turn/start', data: { turn: 2 }, seq: owner.events.length, time: 3 },
      { type: 'step/start', data: { turn: 2, step: 1 }, seq: owner.events.length + 1, time: 4 },
    )
    const second = await runtime.runTurn({ agent: owner.agent, prompt: 'two', model: 'default' })
    expect(query.setModel).not.toHaveBeenCalled()
    const next = transport.queries[1]!
    expect(next.options).toMatchObject({ model: 'default', resume: 'claude-session-1' })
    next.push(init())
    next.push(result('two'))
    await collect(second)
    expect(runtime.snapshots()[0]).toMatchObject({ model: 'default' })
    await runtime.dispose()
  })

  it('reuses one streaming query for multiple turns', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const first = await runtime.runTurn({ agent: owner.agent, prompt: 'one' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(result('one'))
    await collect(first)

    owner.events.push(
      { type: 'turn/start', data: { turn: 2 }, seq: owner.events.length, time: 3 },
      { type: 'step/start', data: { turn: 2, step: 1 }, seq: owner.events.length + 1, time: 4 },
    )
    const second = await runtime.runTurn({ agent: owner.agent, prompt: 'two' })
    query.push(result('two'))
    await expect(collect(second)).resolves.toContainEqual({ type: 'complete', text: 'two' })
    expect(transport.queries).toHaveLength(1)
    await runtime.dispose()
  })

  it('resumes the newest persisted Claude session binding', async () => {
    const transport = factory()
    const owner = fakeAgent()
    owner.events.push({
      type: 'claude-code/session-bound',
      data: { claudeSessionId: 'persisted-claude-session', sdkVersion: '0.3.233', cwd: '/workspace' },
      seq: owner.events.length,
      time: 5,
    })
    const runtime = supervisor(transport.create)
    await sidecars.get(runtime)!.importLegacy(owner.agent.id as string, owner.agent.session.snapshotEvents())
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'continue' })
    expect(transport.queries[0]?.options.resume).toBe('persisted-claude-session')
    transport.queries[0]!.push(init('persisted-claude-session'))
    transport.queries[0]!.push(result('continued', 'persisted-claude-session'))
    await collect(output)
    await runtime.dispose()
  })

  it('accepts the restored shell cwd on resume but still rejects a fresh process elsewhere', async () => {
    const transport = factory()
    const owner = fakeAgent()
    owner.events.push({
      type: 'claude-code/session-bound',
      data: { claudeSessionId: 'persisted-claude-session', sdkVersion: '0.3.233', cwd: '/workspace' },
      seq: owner.events.length,
      time: 5,
    })
    const runtime = supervisor(transport.create)
    await sidecars.get(runtime)!.importLegacy(owner.agent.id as string, owner.agent.session.snapshotEvents())
    // The last turn's Bash `cd` is where Claude Code resumes its shell.
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'continue' })
    transport.queries[0]!.push(init('persisted-claude-session', '/workspace/services/accounting-service'))
    transport.queries[0]!.push(result('continued', 'persisted-claude-session'))
    await expect(collect(output)).resolves.toContainEqual(expect.objectContaining({ type: 'text-delta', text: 'continued' }))

    const fresh = fakeAgent('dsh-session-2')
    const wrong = await runtime.runTurn({ agent: fresh.agent, prompt: 'hello' })
    transport.queries[1]!.push(init('claude-session-2', '/elsewhere'))
    await expect(collect(wrong)).rejects.toThrow(/unexpected cwd/u)
    await runtime.dispose()
  })

  it('creates only one query for concurrent first turns in one session', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const [firstPromise, secondPromise] = [
      runtime.runTurn({ agent: owner.agent, prompt: 'one' }),
      runtime.runTurn({ agent: owner.agent, prompt: 'two' }),
    ]
    const first = await firstPromise
    await expect(secondPromise).rejects.toBeInstanceOf(ClaudeTurnBusyError)
    expect(transport.queries).toHaveLength(1)
    transport.queries[0]!.push(init())
    transport.queries[0]!.push(result('one'))
    await collect(first)
    await runtime.dispose()
  })

  it('waits for a busy process cap before admitting the next session', async () => {
    const transport = factory()
    const runtime = supervisor(transport.create, 1)
    const one = fakeAgent('one')
    const two = fakeAgent('two')
    const [firstPromise, secondPromise] = [
      runtime.runTurn({ agent: one.agent, prompt: 'one' }),
      runtime.runTurn({ agent: two.agent, prompt: 'two' }),
    ]
    const first = await firstPromise
    let secondState: 'pending' | 'resolved' | 'rejected' = 'pending'
    void secondPromise.then(
      () => { secondState = 'resolved' },
      () => { secondState = 'rejected' },
    )
    await new Promise(resolve => setImmediate(resolve))
    expect(secondState).toBe('pending')
    expect(transport.queries).toHaveLength(1)
    transport.queries[0]!.push(init())
    transport.queries[0]!.push(result('one'))
    await collect(first)

    const second = await secondPromise
    expect(transport.queries).toHaveLength(2)
    transport.queries[1]!.push(init('claude-session-2'))
    transport.queries[1]!.push(result('two', 'claude-session-2'))
    await collect(second)
    await runtime.dispose()
  })

  it('cancels a turn while it waits for process capacity without creating a query', async () => {
    const transport = factory()
    const runtime = supervisor(transport.create, 1)
    const first = await runtime.runTurn({ agent: fakeAgent('one').agent, prompt: 'one' })
    const controller = new AbortController()
    const waiting = runtime.runTurn({ agent: fakeAgent('two').agent, prompt: 'two', signal: controller.signal })
    const outcome = waiting.then(
      () => 'resolved',
      error => error instanceof Error ? error.name : 'rejected',
    )

    try {
      await new Promise(resolve => setImmediate(resolve))
      expect(transport.queries).toHaveLength(1)
      controller.abort()
      await expect(Promise.race([
        outcome,
        new Promise<string>(resolve => setImmediate(() => { resolve('pending') })),
      ])).resolves.toBe('AbortError')
      expect(transport.queries).toHaveLength(1)
    } finally {
      transport.queries[0]!.push(init())
      transport.queries[0]!.push(result('one'))
      await collect(first)
      await waiting.catch(() => undefined)
      await runtime.dispose()
    }
  })

  it('admits a waiting session when the occupied session is disposed', async () => {
    const transport = factory()
    const runtime = supervisor(transport.create, 1)
    const first = await runtime.runTurn({ agent: fakeAgent('one').agent, prompt: 'one' })
    const firstOutcome = collect(first).then(
      () => 'resolved',
      error => error instanceof Error ? error.name : 'rejected',
    )
    const waiting = runtime.runTurn({ agent: fakeAgent('two').agent, prompt: 'two' })
    const waitingOutcome = waiting.then(() => 'admitted', () => 'rejected')

    try {
      await new Promise(resolve => setImmediate(resolve))
      expect(transport.queries).toHaveLength(1)
      await runtime.disposeSession('one')
      await expect(firstOutcome).resolves.toBe('AbortError')
      await vi.waitFor(() => {
        expect(transport.queries).toHaveLength(2)
      })
      await expect(waitingOutcome).resolves.toBe('admitted')
    } finally {
      runtime.limitsChanged()
      await waiting.catch(() => undefined)
      await runtime.dispose()
    }
  })

  it('admits capacity waiters in request order', async () => {
    const transport = factory()
    const runtime = supervisor(transport.create, 1)
    const first = await runtime.runTurn({ agent: fakeAgent('one').agent, prompt: 'one' })
    const secondPromise = runtime.runTurn({ agent: fakeAgent('two').agent, prompt: 'two' })
    const thirdPromise = runtime.runTurn({ agent: fakeAgent('three').agent, prompt: 'three' })
    let thirdState: 'pending' | 'resolved' | 'rejected' = 'pending'
    void thirdPromise.then(
      () => { thirdState = 'resolved' },
      () => { thirdState = 'rejected' },
    )

    transport.queries[0]!.push(init('one-claude-session'))
    transport.queries[0]!.push(result('one', 'one-claude-session'))
    await collect(first)
    const second = await secondPromise
    expect(transport.queries).toHaveLength(2)
    expect(thirdState).toBe('pending')

    transport.queries[1]!.push(init('two-claude-session'))
    transport.queries[1]!.push(result('two', 'two-claude-session'))
    await collect(second)
    const third = await thirdPromise
    expect(transport.queries).toHaveLength(3)
    transport.queries[2]!.push(init('three-claude-session'))
    transport.queries[2]!.push(result('three', 'three-claude-session'))
    await collect(third)
    await runtime.dispose()
  })

  it('promptly cancels a later FIFO admission while the head remains capacity-blocked', async () => {
    const transport = factory()
    const runtime = supervisor(transport.create, 1)
    const first = await runtime.runTurn({ agent: fakeAgent('one').agent, prompt: 'one' })
    const secondPromise = runtime.runTurn({ agent: fakeAgent('two').agent, prompt: 'two' })
    const controller = new AbortController()
    const thirdPromise = runtime.runTurn({ agent: fakeAgent('three').agent, prompt: 'three', signal: controller.signal })
    const thirdOutcome = thirdPromise.then(
      () => 'resolved',
      error => error instanceof Error ? error.name : 'rejected',
    )

    try {
      await new Promise(resolve => setImmediate(resolve))
      controller.abort()
      await expect(Promise.race([
        thirdOutcome,
        new Promise<string>(resolve => setImmediate(() => { resolve('pending') })),
      ])).resolves.toBe('AbortError')
      expect(transport.queries).toHaveLength(1)

      transport.queries[0]!.push(init('one-claude-session'))
      transport.queries[0]!.push(result('one', 'one-claude-session'))
      await collect(first)
      const second = await secondPromise
      transport.queries[1]!.push(init('two-claude-session'))
      transport.queries[1]!.push(result('two', 'two-claude-session'))
      await collect(second)
      expect(transport.queries).toHaveLength(2)
    } finally {
      controller.abort()
      await runtime.dispose()
      await thirdPromise.catch(() => undefined)
    }
  })

  it('admits a capacity waiter when the process cap is raised', async () => {
    const transport = factory()
    const runtime = supervisor(transport.create, 1)
    const first = await runtime.runTurn({ agent: fakeAgent('one').agent, prompt: 'one' })
    const waiting = runtime.runTurn({ agent: fakeAgent('two').agent, prompt: 'two' })
    await new Promise(resolve => setImmediate(resolve))
    expect(transport.queries).toHaveLength(1)

    configs.get(runtime)!.maxProcesses = 2
    runtime.limitsChanged()
    const second = await waiting
    expect(transport.queries).toHaveLength(2)

    transport.queries[0]!.push(init('one-claude-session'))
    transport.queries[0]!.push(result('one', 'one-claude-session'))
    transport.queries[1]!.push(init('two-claude-session'))
    transport.queries[1]!.push(result('two', 'two-claude-session'))
    await Promise.all([collect(first), collect(second)])
    await runtime.dispose()
  })

  it('rejects capacity waiters when the supervisor is disposed', async () => {
    const transport = factory()
    const runtime = supervisor(transport.create, 1)
    const first = await runtime.runTurn({ agent: fakeAgent('one').agent, prompt: 'one' })
    const firstOutcome = collect(first).catch(() => [])
    const waiting = runtime.runTurn({ agent: fakeAgent('two').agent, prompt: 'two' })
    await new Promise(resolve => setImmediate(resolve))

    await runtime.dispose()

    await expect(waiting).rejects.toThrow('supervisor is disposed')
    await firstOutcome
    expect(transport.queries).toHaveLength(1)
  })

  it('cancels an admission still importing sidecar state when its session is disposed', async () => {
    const transport = factory()
    const root = join(tmpdir(), `dsh-claude-deferred-import-${randomUUID()}`)
    sidecarRoots.push(root)
    const sidecar = new DeferredImportSidecar(root)
    const runtime = supervisor(transport.create, 1, 60_000, sidecar)
    const waiting = runtime.runTurn({ agent: fakeAgent('one').agent, prompt: 'one' })

    await sidecar.started
    const disposing = runtime.disposeSession('one')
    const outcome = waiting.then(
      () => 'resolved',
      error => error instanceof Error ? error.name : 'rejected',
    )
    await expect(Promise.race([
      outcome,
      new Promise<string>(resolve => setImmediate(() => { resolve('pending') })),
    ])).resolves.toBe('AbortError')
    sidecar.release?.()
    await disposing

    expect(transport.queries).toHaveLength(0)
    expect(runtime.snapshots()).toHaveLength(0)
    await runtime.dispose()
  })

  it('awaits and cancels an admission still importing sidecar state during plugin disposal', async () => {
    const transport = factory()
    const root = join(tmpdir(), `dsh-claude-deferred-import-${randomUUID()}`)
    sidecarRoots.push(root)
    const sidecar = new DeferredImportSidecar(root)
    const runtime = supervisor(transport.create, 1, 60_000, sidecar)
    const waiting = runtime.runTurn({ agent: fakeAgent('one').agent, prompt: 'one' })

    await sidecar.started
    const disposing = runtime.dispose()
    const outcome = waiting.then(
      () => 'resolved',
      error => error instanceof Error ? error.message : 'rejected',
    )
    await expect(Promise.race([
      outcome,
      new Promise<string>(resolve => setImmediate(() => { resolve('pending') })),
    ])).resolves.toContain('supervisor is disposed')
    sidecar.release?.()
    await disposing

    expect(transport.queries).toHaveLength(0)
    expect(runtime.snapshots()).toHaveLength(0)
  })

  it('cancels metadata still importing sidecar state when its session is disposed', async () => {
    const transport = factory()
    const root = join(tmpdir(), `dsh-claude-deferred-metadata-${randomUUID()}`)
    sidecarRoots.push(root)
    const sidecar = new DeferredImportSidecar(root)
    const runtime = supervisor(transport.create, 1, 60_000, sidecar)
    const metadata = runtime.supportedCommands(fakeAgent('one').agent)
    let disposing: Promise<void> | undefined

    try {
      await sidecar.started
      disposing = runtime.disposeSession('one')
      const outcome = metadata.then(
        () => 'resolved',
        error => error instanceof Error ? error.name : 'rejected',
      )
      await expect(Promise.race([
        outcome,
        new Promise<string>(resolve => setImmediate(() => { resolve('pending') })),
      ])).resolves.toBe('AbortError')
      sidecar.release?.()
      await disposing

      expect(transport.queries).toHaveLength(0)
      expect(runtime.snapshots()).toHaveLength(0)
    } finally {
      sidecar.release?.()
      await disposing
      await metadata.catch(() => undefined)
      await runtime.dispose()
    }
  })

  it('awaits and cancels metadata still importing sidecar state during plugin disposal', async () => {
    const transport = factory()
    const root = join(tmpdir(), `dsh-claude-deferred-metadata-${randomUUID()}`)
    sidecarRoots.push(root)
    const sidecar = new DeferredImportSidecar(root)
    const runtime = supervisor(transport.create, 1, 60_000, sidecar)
    const metadata = runtime.supportedCommands(fakeAgent('one').agent)
    let disposing: Promise<void> | undefined

    try {
      await sidecar.started
      disposing = runtime.dispose()
      const outcome = metadata.then(
        () => 'resolved',
        error => error instanceof Error ? error.name : 'rejected',
      )
      await expect(Promise.race([
        outcome,
        new Promise<string>(resolve => setImmediate(() => { resolve('pending') })),
      ])).resolves.toBe('AbortError')
      sidecar.release?.()
      await disposing

      expect(transport.queries).toHaveLength(0)
      expect(runtime.snapshots()).toHaveLength(0)
    } finally {
      sidecar.release?.()
      await disposing
      await metadata.catch(() => undefined)
    }
  })

  it('does not queue metadata behind a user turn waiting on a busy process cap', async () => {
    const transport = factory()
    const runtime = supervisor(transport.create, 1)
    const first = await runtime.runTurn({ agent: fakeAgent('one').agent, prompt: 'one' })
    const controller = new AbortController()
    const waiting = runtime.runTurn({ agent: fakeAgent('two').agent, prompt: 'two', signal: controller.signal })
    const metadata = runtime.supportedCommands(fakeAgent('metadata').agent).then(
      () => 'resolved',
      error => error instanceof ClaudeProcessLimitError ? 'process-limit' : 'rejected',
    )

    try {
      await expect(Promise.race([
        metadata,
        new Promise<string>(resolve => setImmediate(() => { resolve('pending') })),
      ])).resolves.toBe('process-limit')
      expect(transport.queries).toHaveLength(1)
    } finally {
      controller.abort()
      await waiting.catch(() => undefined)
      await runtime.dispose()
      await expect(collect(first)).rejects.toMatchObject({ name: 'AbortError' })
    }
  })

  it('promptly cancels a woken capacity waiter while its replacement initializes', async () => {
    let releaseInitialization: (() => void) | undefined
    const delayedInitialization = new Promise<void>(resolve => { releaseInitialization = resolve })
    const transport = factory()
    const create: ClaudeQueryFactory = params => {
      const query = transport.create(params) as unknown as FakeQuery
      if (transport.queries.length === 2) {
        query.initializationResult.mockReturnValueOnce(delayedInitialization.then(() => ({
          commands: [],
          agents: [],
          output_style: 'default',
          available_output_styles: [],
          models: [],
          account: {},
        })))
      }
      return query as unknown as Query
    }
    const runtime = supervisor(create, 1)
    const first = await runtime.runTurn({ agent: fakeAgent('one').agent, prompt: 'one' })
    const controller = new AbortController()
    const waiting = runtime.runTurn({ agent: fakeAgent('two').agent, prompt: 'two', signal: controller.signal })
    const outcome = waiting.then(
      () => 'resolved',
      error => error instanceof Error ? error.name : 'rejected',
    )

    try {
      transport.queries[0]!.push(init('one-claude-session'))
      transport.queries[0]!.push(result('one', 'one-claude-session'))
      await collect(first)
      await vi.waitFor(() => {
        expect(transport.queries).toHaveLength(2)
      })
      const metadata = runtime.supportedCommands(fakeAgent('metadata').agent).then(
        () => 'resolved',
        error => error instanceof ClaudeProcessLimitError ? 'process-limit' : 'rejected',
      )
      await expect(Promise.race([
        metadata,
        new Promise<string>(resolve => setImmediate(() => { resolve('pending') })),
      ])).resolves.toBe('process-limit')

      controller.abort()
      await expect(Promise.race([
        outcome,
        new Promise<string>(resolve => setImmediate(() => { resolve('pending') })),
      ])).resolves.toBe('AbortError')
      releaseInitialization?.()
      await vi.waitFor(() => {
        expect(runtime.snapshots().some(snapshot => snapshot.sessionId === 'two')).toBe(false)
      })
      const submitted = transport.queries[1]!.input[Symbol.asyncIterator]().next().then(
        result => result.done ? 'closed' : 'submitted',
        error => error instanceof Error ? error.name : 'rejected',
      )
      await expect(submitted).resolves.not.toBe('submitted')
    } finally {
      releaseInitialization?.()
      await waiting.catch(() => undefined)
      await runtime.dispose()
    }
  })

  it('releases process capacity before the completed turn context probe settles', async () => {
    let releaseProbe: (() => void) | undefined
    const probe = new Promise<Awaited<ReturnType<FakeQuery['getContextUsage']>>>(resolve => {
      releaseProbe = () => {
        resolve({
          categories: [],
          totalTokens: 0,
          maxTokens: 200_000,
          rawMaxTokens: 200_000,
          percentage: 0,
          gridRows: [],
          model: 'claude-test',
          memoryFiles: [],
          mcpTools: [],
          agents: [],
          isAutoCompactEnabled: true,
          apiUsage: null,
        })
      }
    })
    const transport = factory()
    const runtime = supervisor(transport.create, 1)
    const first = await runtime.runTurn({ agent: fakeAgent('one').agent, prompt: 'one', model: 'sonnet' })
    transport.queries[0]!.getContextUsage.mockReturnValueOnce(probe)
    const waiting = runtime.runTurn({ agent: fakeAgent('two').agent, prompt: 'two' })

    try {
      transport.queries[0]!.push(init('one-claude-session'))
      transport.queries[0]!.push(result('one', 'one-claude-session'))
      await collect(first)
      await vi.waitFor(() => {
        expect(transport.queries).toHaveLength(2)
      })

      const second = await waiting
      transport.queries[1]!.push(init('two-claude-session'))
      transport.queries[1]!.push(result('two', 'two-claude-session'))
      await collect(second)
    } finally {
      releaseProbe?.()
      await waiting.catch(() => undefined)
      await runtime.dispose()
    }
  })

  it('evicts enough idle entries when a lower process cap admits the next session', async () => {
    const transport = factory()
    const runtime = supervisor(transport.create, 3)
    for (const id of ['one', 'two', 'three']) {
      const output = await runtime.runTurn({ agent: fakeAgent(id).agent, prompt: id })
      transport.queries.at(-1)!.push(init(`${id}-claude-session`))
      transport.queries.at(-1)!.push(result(id, `${id}-claude-session`))
      await collect(output)
    }
    expect(runtime.snapshots()).toHaveLength(3)

    configs.get(runtime)!.maxProcesses = 1
    const output = await runtime.runTurn({ agent: fakeAgent('four').agent, prompt: 'four' })

    expect(runtime.snapshots()).toEqual([
      expect.objectContaining({ sessionId: 'four', state: 'running' }),
    ])
    transport.queries.at(-1)!.push(init('four-claude-session'))
    transport.queries.at(-1)!.push(result('four', 'four-claude-session'))
    await collect(output)
    await runtime.dispose()
  })

  it('reclaims excess idle entries when the configured process cap changes', async () => {
    const transport = factory()
    const runtime = supervisor(transport.create, 3)
    for (const id of ['one', 'two', 'three']) {
      const output = await runtime.runTurn({ agent: fakeAgent(id).agent, prompt: id })
      transport.queries.at(-1)!.push(init(`${id}-claude-session`))
      transport.queries.at(-1)!.push(result(id, `${id}-claude-session`))
      await collect(output)
    }
    expect(runtime.snapshots()).toHaveLength(3)

    configs.get(runtime)!.maxProcesses = 1
    runtime.limitsChanged()
    await vi.waitFor(() => {
      expect(runtime.snapshots()).toHaveLength(1)
    })
    await runtime.dispose()
  })

  it('converges to a lower process cap as active turns finish without interrupting them', async () => {
    const transport = factory()
    const runtime = supervisor(transport.create, 3)
    const outputs = [] as AsyncIterable<ClaudeTurnStreamEvent>[]
    for (const id of ['one', 'two', 'three']) {
      outputs.push(await runtime.runTurn({ agent: fakeAgent(id).agent, prompt: id }))
    }
    expect(runtime.snapshots().map(snapshot => snapshot.state)).toEqual(['running', 'running', 'running'])

    configs.get(runtime)!.maxProcesses = 1
    runtime.limitsChanged()
    await new Promise(resolve => setImmediate(resolve))
    expect(runtime.snapshots()).toHaveLength(3)

    let completed = 0
    try {
      transport.queries[0]!.push(init('one-claude-session'))
      transport.queries[0]!.push(result('one', 'one-claude-session'))
      await collect(outputs[0]!)
      completed = 1
      await vi.waitFor(() => {
        expect(runtime.snapshots()).toHaveLength(2)
      })

      transport.queries[1]!.push(init('two-claude-session'))
      transport.queries[1]!.push(result('two', 'two-claude-session'))
      await collect(outputs[1]!)
      completed = 2
      await vi.waitFor(() => {
        expect(runtime.snapshots()).toEqual([
          expect.objectContaining({ sessionId: 'three', state: 'running' }),
        ])
      })
    } finally {
      for (let index = completed; index < outputs.length; index += 1) {
        transport.queries[index]!.push(init(`${index}-claude-session`))
        transport.queries[index]!.push(result(String(index), `${index}-claude-session`))
        await collect(outputs[index]!).catch(() => undefined)
      }
      await runtime.dispose()
    }
  })

  it('refuses concurrent top-level turns for one DSH session', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'one' })
    transport.queries[0]!.push(init())
    await expect(runtime.runTurn({ agent: owner.agent, prompt: 'two' })).rejects.toBeInstanceOf(ClaudeTurnBusyError)
    transport.queries[0]!.push(result('one'))
    await collect(output)
    await runtime.dispose()
  })

  it('classifies a disconnect before any Claude activity as retry-ineligible disconnect', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
    transport.queries[0]!.fail(new Error('startup failed'))
    await expect(collect(output)).rejects.not.toBeInstanceOf(ClaudeOutcomeUnknownError)
    expect(runtime.snapshots()).toHaveLength(0)
    await runtime.dispose()
  })

  it('classifies a disconnect after visible activity as outcome unknown', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'edit something' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(delta('working'))
    query.fail(new Error('process crashed'))
    await expect(collect(output)).rejects.toBeInstanceOf(ClaudeOutcomeUnknownError)
    expect(runtime.snapshots()).toHaveLength(0)
    await runtime.dispose()
  })

  it('says how the process ended, and logs it, when a turn dies with it', async () => {
    // "Outcome unknown" is the truth and tells a reader nothing: whether the
    // CLI exited on its own or something killed it, and whether a tool call was
    // still in flight, is what decides whether the work landed.
    const transport = factory()
    const owner = fakeAgent()
    const warnings: string[] = []
    const runtime = supervisor(transport.create, 4, 60_000, undefined, 'plugin', warnings)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'edit something' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(delta('working'))
    query.push(toolCallMessage)
    query.fail(new Error('process crashed'))
    const failure = await collect(output).then(() => undefined, (error: unknown) => error)
    expect(failure).toBeInstanceOf(ClaudeOutcomeUnknownError)
    expect((failure as Error).message).toContain('side-effect outcome is unknown')
    expect((failure as Error).message).toContain('1 tool call(s) were still unanswered')
    // The fake query has no process to watch, and the message says so rather
    // than leaving the reader to guess.
    expect((failure as Error).message).toContain('no process was running')
    expect(warnings).toHaveLength(1)
    expect(warnings[0]).toContain('mid-turn after activity')
    // The row keeps the same answer for a reader who was not watching the turn.
    const row = (await projection(runtime)).activities.find(activity => activity.title === 'Claude Code outcome unknown')
    expect(row?.summary).toContain('tool call(s) were still unanswered')
    await runtime.dispose()
  })

  it('reads the stderr a dying process wrote on its way out, and redacts it in the log', async () => {
    // The stream can end a moment before the process is reaped, and a crashing
    // CLI often writes its last words while it goes. The log line must carry
    // those words, and nothing credential-shaped from them.
    let stderrText = ''
    let exit!: (outcome: { exitCode: number | null; signal: NodeJS.Signals | null }) => void
    const done = new Promise<{ exitCode: number | null; signal: NodeJS.Signals | null }>(resolve => { exit = resolve })
    const handle = {
      pid: 42,
      stdin: new PassThrough(),
      stdout: new PassThrough(),
      stderr: undefined,
      collected: { stderr: { readFrom: () => ({ text: stderrText, nextOffset: stderrText.length, lossy: false }) } },
      done,
      terminate: () => {},
      waitForExit: async () => {
        stderrText = 'fatal: request failed with Authorization: Bearer sk-ant-abcdefghijklmnop'
        exit({ exitCode: null, signal: 'SIGKILL' })
        await done
        return true
      },
    } as unknown as SubprocessHandle
    const transport = factory()
    const warnings: string[] = []
    const root = join(tmpdir(), `dsh-claude-supervisor-${randomUUID()}`)
    sidecarRoots.push(root)
    const runtime = new ClaudeSupervisor({
      runtime: { spawn: () => handle },
      approval: { request: async () => 'rejected' },
      userQuestions: { ask: async () => ({ answers: [] }) },
      config: { executablePath: '/local/claude', idleTimeoutMs: 60_000, maxProcesses: 4, defaultModel: 'default', renderMode: 'plugin' },
      queryFactory: args => {
        args.options.spawnClaudeCodeProcess?.({ command: '/local/claude', args: [], cwd: '/workspace', env: {}, signal: new AbortController().signal })
        return transport.create(args)
      },
      sidecar: new ClaudeSidecarRepository({ root }),
      logger: { warn: message => { warnings.push(message) } },
    })
    const owner = fakeAgent()
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'edit something' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(delta('working'))
    query.fail(new Error('process crashed'))
    const failure = await collect(output).then(() => undefined, (error: unknown) => error)
    expect((failure as Error).message).toContain('killed by SIGKILL')
    expect(warnings).toHaveLength(1)
    expect(warnings[0]).toContain('killed by SIGKILL')
    expect(warnings[0]).toContain('fatal: request failed')
    expect(warnings[0]).not.toContain('sk-ant-abcdefghijklmnop')
    await runtime.dispose()
  })

  it('never submits a prompt cancelled while recording the turn start', async () => {
    const transport = factory()
    const controller = new AbortController()
    const owner = fakeAgent()
    const root = join(tmpdir(), `dsh-claude-hook-${randomUUID()}`)
    sidecarRoots.push(root)
    const sidecar = new HookedSidecar(root, activity => {
      if (activity.phase === 'started') controller.abort()
    })
    const runtime = supervisor(transport.create, 4, 60_000, sidecar)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'must not run', signal: controller.signal })
    await expect(collect(output)).rejects.toMatchObject({ name: 'AbortError' })
    const query = transport.queries[0]!
    const iterator = query.input[Symbol.asyncIterator]()
    let receivedPrompt = false
    void iterator.next().then(value => { receivedPrompt = !value.done })
    await Promise.resolve()
    expect(receivedPrompt).toBe(false)
    expect(query.interrupt).not.toHaveBeenCalled()
    expect(runtime.snapshots()[0]?.state).toBe('idle')
    await runtime.dispose()
  })

  it('submits no internal slash command before the direct user prompt', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: '/compact' })
    const query = transport.queries[0]!
    const input = query.input[Symbol.asyncIterator]()
    await expect(input.next()).resolves.toMatchObject({
      value: { message: { content: '/compact' } },
      done: false,
    })
    let receivedAnotherInput = false
    void input.next().then(value => { receivedAnotherInput = !value.done })
    await Promise.resolve()
    expect(receivedAnotherInput).toBe(false)
    query.push(init())
    query.push(result('Compacted'))
    await expect(collect(output)).resolves.toContainEqual({ type: 'complete', text: 'Compacted' })
    await runtime.dispose()
  })
  it('rejects an already-aborted request before allocating a query', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const controller = new AbortController()
    controller.abort()
    await expect(runtime.runTurn({ agent: owner.agent, prompt: 'must not run', signal: controller.signal })).rejects.toMatchObject({ name: 'AbortError' })
    expect(transport.queries).toHaveLength(0)
    await runtime.dispose()
  })

  it('classifies a disconnect after a permission callback as outcome unknown', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'read a file' })
    const query = transport.queries[0]!
    await query.options.canUseTool?.('Read', { file_path: 'README.md' }, {
      signal: new AbortController().signal,
      toolUseID: 'tool-1',
      requestId: 'request-1',
    })
    query.fail(new Error('process crashed after permission'))
    await expect(collect(output)).rejects.toBeInstanceOf(ClaudeOutcomeUnknownError)
    await runtime.dispose()
  })

  it('teardowns when the interrupt leaves the submitted prompt queued', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const controller = new AbortController()
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'long task', signal: controller.signal })
    const query = transport.queries[0]!
    const iterator = query.input[Symbol.asyncIterator]()
    const submitted = await iterator.next()
    const promptUuid = submitted.value?.uuid ?? ''
    query.interrupt.mockResolvedValue({ still_queued: [promptUuid] })
    controller.abort()
    await expect(collect(output)).rejects.toMatchObject({ name: 'AbortError' })
    await vi.waitFor(() => expect(runtime.snapshots()).toHaveLength(0))
    await runtime.dispose()
  })

  it('tears down a hung interrupt after the bounded wait', async () => {
    // Fake timers: the bounded wait is a real 5s otherwise, which made this
    // case flaky under full-suite load.
    vi.useFakeTimers()
    try {
      const transport = factory()
      const owner = fakeAgent()
      const runtime = supervisor(transport.create, 4, 60_000)
      const controller = new AbortController()
      const output = await runtime.runTurn({ agent: owner.agent, prompt: 'long task', signal: controller.signal })
      const query = transport.queries[0]!
      query.interrupt.mockImplementation(() => new Promise(() => {}))
      controller.abort()
      await expect(collect(output)).rejects.toMatchObject({ name: 'AbortError' })
      await vi.advanceTimersByTimeAsync(CLAUDE_INTERRUPT_TIMEOUT_MS)
      await vi.waitFor(() => expect(runtime.snapshots()).toHaveLength(0))
      await runtime.dispose()
    } finally {
      vi.useRealTimers()
    }
  })

  it('closes the turn on the CLI\'s own reaction to a stopped task once the report prompt was folded into it', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'start a ticker' })
    const collected = collect(output)
    const query = transport.queries[0]!
    const input = query.input[Symbol.asyncIterator]()
    await input.next()
    query.push(init())
    query.push({
      type: 'system',
      subtype: 'task_started',
      task_id: 'tick',
      description: 'Print a tick every 10s',
      task_type: 'local_bash',
      session_id: 'claude-session-1',
    } as SDKMessage)
    query.push({
      type: 'system',
      subtype: 'background_tasks_changed',
      tasks: [{ task_id: 'tick', task_type: 'local_bash', description: 'Print a tick every 10s' }],
      session_id: 'claude-session-1',
    } as SDKMessage)
    query.push(result('Ticker started in the background.'))
    await vi.waitFor(() => expect(runtime.snapshots()[0]?.state).toBe('running'))

    // The user stops it from the Host job list: the notification arrives, the
    // plugin sends its report prompt, and the CLI reacts to the notification
    // itself in the same breath, folding the prompt into that reaction turn.
    query.push({
      type: 'system',
      subtype: 'task_notification',
      task_id: 'tick',
      status: 'stopped',
      summary: 'Background command stopped',
      session_id: 'claude-session-1',
    } as SDKMessage)
    const followUp = await input.next()
    expect(followUp.value?.message.content).toContain('all settled')
    query.push(delta('The ticker was stopped before it finished.'))
    query.push({ ...result('The ticker was stopped before it finished.') as object, user_message_uuid: 'cli-task-reaction', queued_turn_count: 0 } as SDKMessage)

    await expect(collected).resolves.toEqual(expect.arrayContaining([
      { type: 'complete', text: 'The ticker was stopped before it finished.' },
    ]))
    expect(runtime.snapshots()[0]).toMatchObject({ state: 'idle' })
    await runtime.dispose()
  })

  it('rejects a result with the wrong user-message UUID', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello' })
    transport.queries[0]!.push(init())
    transport.queries[0]!.push({
      type: 'result',
      subtype: 'success',
      session_id: 'claude-session-1',
      user_message_uuid: 'stale-user-message',
      result: 'wrong request',
      total_cost_usd: 0,
      usage: { input_tokens: 1, output_tokens: 1 },
    } as SDKMessage)
    await expect(collect(output)).rejects.toThrow(/user message stale-user-message/)
    expect(runtime.snapshots()).toHaveLength(0)
    await runtime.dispose()
  })

  it('tears down the submitted turn when DSH aborts', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const controller = new AbortController()
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'long task', signal: controller.signal })
    const query = transport.queries[0]!
    controller.abort()
    await expect(collect(output)).rejects.toMatchObject({ name: 'AbortError' })
    expect(query.interrupt).toHaveBeenCalledOnce()
    await vi.waitFor(() => expect(runtime.snapshots()).toHaveLength(0))
    await runtime.dispose()
  })

  it('delivers a steered message into the turn that is already running', async () => {
    // Claude reads a message pushed into its input stream at the next model step
    // of the running turn, so steering is exactly that push. The turn owns one
    // more prompt uuid, and its result no longer ends the turn while the CLI
    // still reports the steered send as queued.
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'long task' })
    const query = transport.queries[0]!
    query.push(init())
    const input = query.input[Symbol.asyncIterator]()
    const opened = await input.next()
    expect(runtime.deliverSteering('dsh-session-1', 'change of plan')).toBe('delivered')
    const steered = await input.next()
    expect(steered.value?.message.content).toBe('change of plan')
    expect(steered.value?.uuid).not.toBe(opened.value?.uuid)

    const events = output[Symbol.asyncIterator]()
    query.push({ ...result('first') as object, user_message_uuid: opened.value?.uuid, queued_turn_count: 1 } as SDKMessage)
    // The first result publishes its prose and leaves the turn open.
    expect((await events.next()).value).toMatchObject({ type: 'text-delta', text: 'first' })
    expect((await events.next()).value).toMatchObject({ type: 'segment-complete' })
    query.push({ ...result('second') as object, user_message_uuid: steered.value?.uuid, queued_turn_count: 0 } as SDKMessage)
    const tail: ClaudeTurnStreamEvent[] = []
    for (;;) {
      const next = await events.next()
      if (next.done === true) break
      tail.push(next.value)
    }
    expect(tail.some(event => event.type === 'complete')).toBe(true)
    // Drawn where it arrived: the turn's prose settles as one node at the end,
    // so a row is the only place the reader's words land in their own position.
    const rows = (await projection(runtime)).activities.filter(activity => activity.kind === 'steering')
    expect(rows.map(row => row.summary)).toEqual(['change of plan'])
    await runtime.dispose()
  })

  it('reports steering unavailable when there is no running turn to steer', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    expect(runtime.canSteer('dsh-session-1')).toBe(false)
    expect(runtime.deliverSteering('dsh-session-1', 'anyone there')).toBe('unavailable')
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'long task' })
    const query = transport.queries[0]!
    query.push(init())
    expect(runtime.canSteer('dsh-session-1')).toBe(true)
    for (let index = 0; index < 15; index += 1) {
      expect(runtime.deliverSteering('dsh-session-1', `steer ${index}`)).toBe('delivered')
    }
    // The ownership set is bounded: past the cap the caller keeps its message.
    expect(runtime.canSteer('dsh-session-1')).toBe(false)
    expect(runtime.deliverSteering('dsh-session-1', 'one too many')).toBe('unavailable')
    query.push(result('done'))
    await collect(output)
    expect(runtime.deliverSteering('dsh-session-1', 'turn is over')).toBe('unavailable')
    await runtime.dispose()
  })

  it('records an unknown message type once per process, not once per frame', async () => {
    // A type this package does not handle arrives in batches of identical frames
    // (command_lifecycle did, five per turn, before it was handled). One row is
    // evidence; the rest are noise the transcript never draws. Tool-progress
    // heartbeats and command lifecycle transitions are telemetry, not unknown
    // types, and leave no row at all.
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'long task' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({ type: 'command_lifecycle', state: 'queued' } as unknown as SDKMessage)
    query.push({ type: 'command_lifecycle', state: 'running' } as unknown as SDKMessage)
    query.push({ type: 'tool_progress', tool_use_id: 'tool-1', elapsed_time_seconds: 3 } as unknown as SDKMessage)
    query.push({ type: 'future_message', value: 1 } as unknown as SDKMessage)
    query.push({ type: 'future_message', value: 2 } as unknown as SDKMessage)
    query.push(result('done'))
    await collect(output)
    const notices = (await projection(runtime)).activities
      .filter(activity => String(activity.title).startsWith('Unknown Claude SDK message:'))
    expect(notices.map(activity => activity.title)).toEqual([
      'Unknown Claude SDK message: future_message',
    ])
    await runtime.dispose()
  })

  it('settles the tool calls a cancelled turn left in flight', async () => {
    // Nothing will ever answer them: the turn is gone. Left open they render
    // as a tool that is still running, for the life of the transcript.
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const controller = new AbortController()
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'long task', signal: controller.signal })
    const query = transport.queries[0]!
    query.push(init())
    query.push(toolCallMessage)
    await vi.waitFor(async () => {
      expect((await projection(runtime)).activities.some(activity => activity.kind === 'tool-call')).toBe(true)
    })
    controller.abort()
    await expect(collect(output)).rejects.toMatchObject({ name: 'AbortError' })
    await vi.waitFor(async () => {
      expect((await projection(runtime)).activities).toContainEqual(expect.objectContaining({
        kind: 'tool-result',
        toolUseId: 'tool-1',
        phase: 'failed',
        isError: true,
      }))
    })
    await runtime.dispose()
  })

  it('leaves an answered tool call alone when the turn is cancelled after it', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const controller = new AbortController()
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'long task', signal: controller.signal })
    const query = transport.queries[0]!
    query.push(init())
    query.push(toolCallMessage)
    query.push(toolResultMessage)
    await vi.waitFor(async () => {
      expect((await projection(runtime)).activities.some(activity => activity.kind === 'tool-result')).toBe(true)
    })
    controller.abort()
    await expect(collect(output)).rejects.toMatchObject({ name: 'AbortError' })
    const results = (await projection(runtime)).activities.filter(activity => activity.kind === 'tool-result')
    expect(results).toHaveLength(1)
    expect(results[0]).toMatchObject({ phase: 'completed' })
    await runtime.dispose()
  })

  it('queues the next turn until cancellation cleanup finishes', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const controller = new AbortController()
    const first = await runtime.runTurn({ agent: owner.agent, prompt: 'long task', signal: controller.signal })
    const firstQuery = transport.queries[0]!
    firstQuery.push(init())
    await vi.waitFor(() => expect(runtime.snapshots()[0]?.claudeSessionId).toBe('claude-session-1'))

    let finishInterrupt!: () => void
    firstQuery.interrupt.mockImplementation(() => new Promise(resolve => {
      finishInterrupt = () => resolve(undefined)
    }))
    controller.abort()
    await expect(collect(first)).rejects.toMatchObject({ name: 'AbortError' })

    owner.events.push(
      { type: 'turn/end', data: { turn: 1 }, seq: owner.events.length, time: 3 },
      { type: 'turn/start', data: { turn: 2 }, seq: owner.events.length + 1, time: 4 },
      { type: 'step/start', data: { turn: 2, step: 1 }, seq: owner.events.length + 2, time: 5 },
    )
    const secondPromise = runtime.runTurn({ agent: owner.agent, prompt: 'use a different approach' })
    let secondState: 'pending' | 'resolved' | 'rejected' = 'pending'
    void secondPromise.then(
      () => { secondState = 'resolved' },
      () => { secondState = 'rejected' },
    )
    await new Promise(resolve => setImmediate(resolve))
    expect(secondState).toBe('pending')

    finishInterrupt()
    const second = await secondPromise
    const secondQuery = transport.queries[1]!
    expect(secondQuery.options.resume).toBe('claude-session-1')
    const input = secondQuery.input[Symbol.asyncIterator]()
    await expect(input.next()).resolves.toMatchObject({
      value: { message: { content: 'use a different approach' } },
      done: false,
    })
    secondQuery.push(init())
    secondQuery.push(result('changed direction'))
    await expect(collect(second)).resolves.toContainEqual({ type: 'complete', text: 'changed direction' })
    await runtime.dispose()
  })

  it('evicts an idle query after the configured timeout', async () => {
    vi.useFakeTimers()
    try {
      const transport = factory()
      const owner = fakeAgent()
      const runtime = supervisor(transport.create, 4, 25)
      const output = await runtime.runTurn({ agent: owner.agent, prompt: 'one' })
      transport.queries[0]!.push(init())
      transport.queries[0]!.push(result('one'))
      await collect(output)
      expect(runtime.snapshots()).toHaveLength(1)
      await vi.advanceTimersByTimeAsync(25)
      expect(runtime.snapshots()).toHaveLength(0)
      await runtime.dispose()
    } finally {
      vi.useRealTimers()
    }
  })

  it('upserts assistant deltas and orders consecutive tools between model text segments', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'inspect and explain' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(delta('I will '))
    await vi.waitFor(async () => {
      const texts = (await projection(runtime)).activities.filter(activity => activity.kind === 'text')
      expect(texts).toEqual([expect.objectContaining({ text: 'I will ' })])
    })
    query.push(delta('inspect.'))
    await vi.waitFor(async () => {
      const texts = (await projection(runtime)).activities.filter(activity => activity.kind === 'text')
      expect(texts).toEqual([expect.objectContaining({ text: 'I will inspect.' })])
    })
    query.push(toolCallMessage)
    query.push(toolResultMessage)
    query.push({
      type: 'assistant',
      message: {
        role: 'assistant',
        content: [{ type: 'tool_use', id: 'tool-2', name: 'Grep', input: { pattern: 'answer' } }],
      },
    } as SDKMessage)
    query.push({
      type: 'user',
      message: {
        role: 'user',
        content: [{ type: 'tool_result', tool_use_id: 'tool-2', content: 'matched' }],
      },
      tool_use_result: 'matched',
    } as SDKMessage)
    query.push(delta('The cause is clear.'))
    query.push(result('I will inspect.The cause is clear.'))
    await collect(output)

    const visible = (await projection(runtime)).activities.filter(activity => (
      activity.kind === 'text' || activity.kind === 'tool-call' || activity.kind === 'tool-result'
    ))
    expect(visible.map(activity => [activity.kind, activity.ordinal, activity.text ?? activity.toolUseId])).toEqual([
      ['text', 1, 'I will inspect.'],
      ['tool-call', 2, 'tool-1'],
      ['tool-result', 3, 'tool-1'],
      ['tool-call', 4, 'tool-2'],
      ['tool-result', 5, 'tool-2'],
      ['text', 6, 'The cause is clear.'],
    ])
    await runtime.dispose()
  })

  it('checkpoints the projection when a turn settles, so a lost delta cannot outlive the turn', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const seen: { kind: string; seq: number }[] = []
    const unsubscribe = sidecars.get(runtime)!.subscribe(owner.agent.id as string, delta => {
      seen.push({ kind: delta.kind, seq: delta.seq })
    })
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'look around' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(toolCallMessage)
    query.push(toolResultMessage)
    query.push(result('done'))
    await collect(output)
    // Last word of the turn, and it repeats the number of the delta before it:
    // a client that applied everything agrees, a client that missed the tool
    // result does not, and only the second one pays for a resync.
    // The turn settles after its output stream closes, so the checkpoint lands
    // just behind the last event `collect` saw.
    await vi.waitFor(() => expect(seen.at(-1)?.kind).toBe('checkpoint'))
    expect(seen.at(-1)?.seq).toBe(seen.at(-2)?.seq)
    unsubscribe()
    await runtime.dispose()
  })

  it('keeps root Claude tools exclusively in the ordered sidecar transcript', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'look around' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(toolCallMessage)
    query.push(toolResultMessage)
    query.push(result('done'))
    await collect(output)
    expect(owner.events.some(event => event.type === 'tool/call' || event.type === 'tool/result')).toBe(false)
    await expect(projection(runtime)).resolves.toMatchObject({
      activities: expect.arrayContaining([
        expect.objectContaining({ kind: 'tool-call', toolUseId: 'tool-1', toolName: 'Bash' }),
        expect.objectContaining({ kind: 'tool-result', toolUseId: 'tool-1', detail: 'listed' }),
      ]),
    })
    await runtime.dispose()
  })

  it('records permission denial in the sidecar without creating a native tool card', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'pull latest' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(toolCallMessage)
    query.push({
      type: 'system',
      subtype: 'permission_denied',
      tool_use_id: 'tool-1',
      tool_name: 'Bash',
      message: 'The user rejected this action in DeepSeek Harness.',
    } as SDKMessage)
    query.push(result('not pulled'))
    await collect(output)

    expect(owner.events.some(event => event.type === 'tool/call' || event.type === 'tool/result')).toBe(false)
    await expect(projection(runtime)).resolves.toMatchObject({
      activities: expect.arrayContaining([
        expect.objectContaining({ kind: 'permission', toolUseId: 'tool-1', phase: 'denied' }),
      ]),
    })
    await runtime.dispose()
  })

  it('records an API retry notice as a settled warning, not an activity still running', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'pull latest' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'system',
      subtype: 'api_retry',
      attempt: 1,
      max_retries: 10,
      retry_delay_ms: 1000,
      error_status: 529,
      error: 'overloaded_error',
    } as unknown as SDKMessage)
    query.push(result('pulled'))
    await collect(output)

    await expect(projection(runtime)).resolves.toMatchObject({
      activities: expect.arrayContaining([
        expect.objectContaining({ kind: 'warning', title: 'Claude API retry', summary: 'attempt 1 of 10 · HTTP 529', phase: 'completed' }),
      ]),
    })
    await runtime.dispose()
  })

  it('records subagent prose once under its parent call and keeps it off the turn text', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'delegate' })
    const query = transport.queries[0]!
    query.push(init())
    expect(query.options.forwardSubagentText).toBe(true)
    const nested = (text: string) => ({
      type: 'assistant',
      parent_tool_use_id: 'parent-call',
      message: { role: 'assistant', content: [{ type: 'text', text }] },
    } as SDKMessage)
    query.push(nested('Looking at the parser.'))
    // The CLI re-sends a message's blocks as each one completes.
    query.push(nested('Looking at the parser.'))
    query.push(nested('Done reading.'))
    query.push(delta('Lead answer.'))
    query.push(result('Lead answer.'))
    const events = await collect(output)
    expect(events).toContainEqual({ type: 'complete', text: 'Lead answer.' })
    const texts = (await projection(runtime)).activities.filter(activity => activity.kind === 'text')
    expect(texts.filter(activity => activity.parentToolUseId === 'parent-call').map(activity => activity.text)).toEqual(['Looking at the parser.', 'Done reading.'])
    expect(texts.filter(activity => activity.parentToolUseId === undefined).map(activity => activity.text)).toEqual(['Lead answer.'])
    await runtime.dispose()
  })

  it('moves a blocking Bash call to the background after the configured time, unless its result came first', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    // The live config object: a minute in production, a blink here.
    ;(configs.get(runtime) as unknown as { foregroundBashBackgroundMs?: number }).foregroundBashBackgroundMs = 120
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'deploy' })
    const collected = collect(output)
    const query = transport.queries[0]!
    query.push(init())
    const call = (id: string, input: Record<string, unknown>) => ({
      type: 'assistant',
      message: { role: 'assistant', content: [{ type: 'tool_use', id, name: 'Bash', input }] },
    } as SDKMessage)
    const answered = (id: string) => ({
      type: 'user',
      parent_tool_use_id: null,
      message: { role: 'user', content: [{ type: 'tool_result', tool_use_id: id, content: 'ok' }] },
    } as SDKMessage)
    query.push(call('quick', { command: 'ls' }))
    query.push(call('detached', { command: 'sleep 999', run_in_background: true }))
    query.push(call('slow', { command: './deploy.sh prod' }))
    query.push(answered('quick'))
    // Only the still-blocking foreground call is moved; the answered one and
    // the already-detached one are left alone.
    await vi.waitFor(() => expect(query.backgroundTasks).toHaveBeenCalled(), { timeout: 2_000 })
    await new Promise(resolve => setTimeout(resolve, 200))
    expect(query.backgroundTasks.mock.calls).toEqual([['slow']])
    await vi.waitFor(async () => {
      const statuses = (await projection(runtime)).activities.filter(activity => activity.kind === 'status' && activity.toolUseId === 'slow')
      expect(statuses).toEqual([expect.objectContaining({ phase: 'completed', title: 'Claude Code moved the command to the background', summary: 'ran longer than 120ms' })])
    })
    query.push(answered('slow'))
    query.push(result('done'))
    await expect(collected).resolves.toContainEqual({ type: 'complete', text: 'done' })
    await runtime.dispose()
  })

  it('moves a running Bash call to the background on request and refuses one that is not running', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'deploy' })
    const collected = collect(output)
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'assistant',
      message: { role: 'assistant', content: [{ type: 'tool_use', id: 'call-1', name: 'Bash', input: { command: 'sleep 5' } }] },
    } as SDKMessage)
    await vi.waitFor(() => expect(runtime.snapshots()[0]?.state).toBe('running'))
    await vi.waitFor(async () => expect((await projection(runtime)).activities.some(activity => activity.toolUseId === 'call-1')).toBe(true))
    await expect(runtime.backgroundToolCall(owner.agent.id as string, 'nope')).resolves.toBe('not-running')
    await expect(runtime.backgroundToolCall(owner.agent.id as string, 'call-1')).resolves.toBe('moved')
    expect(query.backgroundTasks).toHaveBeenCalledWith('call-1')
    query.backgroundTasks.mockResolvedValueOnce(false)
    await expect(runtime.backgroundToolCall(owner.agent.id as string, 'call-1')).resolves.toBe('unavailable')
    query.push(result('done'))
    await expect(collected).resolves.toContainEqual({ type: 'complete', text: 'done' })
    await runtime.dispose()
  })

  it('writes Claude\'s task list into the session log for the Host to-do dock, and carries it into the next turn', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const todoWrites = () => owner.events.filter(event => event.type === 'todo/write').map(event => (event.data as { todos: unknown }).todos)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'plan it' })
    const query = transport.queries[0]!
    query.push(init())
    const call = (id: string, name: string, input: unknown, parent?: string) => ({
      type: 'assistant',
      ...(parent === undefined ? {} : { parent_tool_use_id: parent }),
      message: { role: 'assistant', content: [{ type: 'tool_use', id, name, input }] },
    } as SDKMessage)
    query.push(call('t1', 'TodoWrite', { todos: [{ content: 'Read', status: 'in_progress', activeForm: 'Reading' }, { content: 'Fix', status: 'pending' }] }))
    // The same list again changes nothing in the log.
    query.push(call('t2', 'TodoWrite', { todos: [{ content: 'Read', status: 'in_progress' }, { content: 'Fix', status: 'pending' }] }))
    // A subagent's private TodoWrite is not the lead's list.
    query.push(call('t3', 'TodoWrite', { todos: [{ content: 'Sub', status: 'pending' }] }, 'agent-1'))
    query.push(result('done'))
    await collect(output)
    expect(todoWrites()).toEqual([[{ content: 'Read', status: 'in_progress' }, { content: 'Fix', status: 'pending' }]])

    owner.events.push({ type: 'turn/start', data: { turn: 2 }, seq: owner.events.length, time: Date.now() })
    const next = await runtime.runTurn({ agent: owner.agent, prompt: 'continue' })
    await vi.waitFor(() => expect(todoWrites()).toHaveLength(2))
    expect(todoWrites()[1]).toEqual(todoWrites()[0])
    query.push(result('ok'))
    await collect(next)
    await runtime.dispose()
  })

  it('does not mirror subagent-nested tool calls into the native tool channel', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'delegate' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'assistant',
      parent_tool_use_id: 'parent-call',
      message: {
        role: 'assistant',
        content: [{ type: 'tool_use', id: 'nested-1', name: 'Read', input: { file_path: 'README.md' } }],
      },
    } as SDKMessage)
    query.push(result('done'))
    await collect(output)
    expect(owner.events.some(event => event.type === 'tool/call')).toBe(false)
    expect(owner.registeredTools).toEqual([])
    await runtime.dispose()
  })

  it('does not register native presenters for Claude-owned tool names', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'search the vault' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'assistant',
      message: {
        role: 'assistant',
        content: [
          { type: 'tool_use', id: 'mcp-1', name: 'mcp__obsidian__search_simple', input: { query: 'Navi' } },
          { type: 'tool_use', id: 'mcp-2', name: 'mcp__obsidian__search_simple', input: { query: 'Slack' } },
          { type: 'tool_use', id: 'bash-1', name: 'Bash', input: { command: 'ls' } },
        ],
      },
    } as SDKMessage)
    query.push(result('done'))
    await collect(output)
    expect(owner.registeredTools).toEqual([])
    expect(owner.events.some(event => event.type === 'tool/call')).toBe(false)
    await runtime.dispose()
  })

  it('keeps Task dispatches out of the native channel and summarizes them by description', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'explore' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'assistant',
      message: {
        role: 'assistant',
        content: [{ type: 'tool_use', id: 'task-1', name: 'Task', input: { description: 'Explore Navi module', prompt: 'survey' } }],
      },
    } as SDKMessage)
    query.push({
      type: 'user',
      message: {
        role: 'user',
        content: [{ type: 'tool_result', tool_use_id: 'task-1', content: 'report' }],
      },
      tool_use_result: 'report',
    } as SDKMessage)
    query.push(result('done'))
    await collect(output)
    expect(owner.events.some(event => event.type === 'tool/call')).toBe(false)
    expect(owner.events.some(event => event.type === 'tool/result')).toBe(false)
    const activities = (await projection(runtime)).activities
    expect(activities.some(event => event.summary === 'Explore Navi module')).toBe(true)
    expect(activities.some(event => event.kind === 'tool-result')).toBe(true)
    await runtime.dispose()
  })

  it('evicts the least-recently-idle entry to respect the process cap', async () => {
    const transport = factory()
    const runtime = supervisor(transport.create, 1)
    const firstOwner = fakeAgent('one')
    const first = await runtime.runTurn({ agent: firstOwner.agent, prompt: 'one' })
    transport.queries[0]!.push(init('one-claude-session'))
    transport.queries[0]!.push(result('one', 'one-claude-session'))
    await collect(first)

    const secondOwner = fakeAgent('two')
    const second = await runtime.runTurn({ agent: secondOwner.agent, prompt: 'two' })
    expect(transport.queries).toHaveLength(2)
    transport.queries[1]!.push(init('two-claude-session'))
    transport.queries[1]!.push(result('two', 'two-claude-session'))
    await collect(second)
    await runtime.dispose()
  })

  it('passes the selected thinking mode into the Claude options', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello', thinkingMode: 'max' })
    expect(transport.queries[0]?.options.effort).toBe('max')
    expect(transport.queries[0]?.options.thinking).toBeUndefined()
    expect(transport.queries[0]?.options.settings).toEqual({ teammateMode: 'in-process' })
    transport.queries[0]!.push(init())
    transport.queries[0]!.push(result())
    await collect(output)
    expect(runtime.snapshots()[0]).toMatchObject({ thinkingMode: 'max' })
    await runtime.dispose()
  })

  it('disables extended thinking for the off mode', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello', thinkingMode: 'off' })
    expect(transport.queries[0]?.options.thinking).toEqual({ type: 'disabled' })
    expect(transport.queries[0]?.options.effort).toBeUndefined()
    transport.queries[0]!.push(init())
    transport.queries[0]!.push(result())
    await collect(output)
    await runtime.dispose()
  })

  it('enables ultracode through the flag settings layer', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'hello', thinkingMode: 'ultracode' })
    expect(transport.queries[0]?.options.settings).toEqual({ teammateMode: 'in-process', ultracode: true })
    expect(transport.queries[0]?.options.effort).toBeUndefined()
    transport.queries[0]!.push(init())
    transport.queries[0]!.push(result())
    await collect(output)
    await runtime.dispose()
  })

  it('moves effort on the running process instead of rebuilding it', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const first = await runtime.runTurn({ agent: owner.agent, prompt: 'one' })
    expect(transport.queries[0]?.options.effort).toBeUndefined()
    transport.queries[0]!.push(init())
    transport.queries[0]!.push(result('one'))
    await collect(first)

    owner.events.push(
      { type: 'turn/start', data: { turn: 2 }, seq: owner.events.length, time: 3 },
      { type: 'step/start', data: { turn: 2, step: 1 }, seq: owner.events.length + 1, time: 4 },
    )
    const second = await runtime.runTurn({ agent: owner.agent, prompt: 'two', thinkingMode: 'xhigh' })
    // One process, one context: effort moved through a control request rather
    // than a respawn and a resume from disk.
    expect(transport.queries).toHaveLength(1)
    expect(transport.queries[0]?.applyFlagSettings).toHaveBeenCalledWith({ effortLevel: 'xhigh' })
    expect(runtime.snapshots()[0]).toMatchObject({ thinkingMode: 'xhigh' })
    transport.queries[0]!.push(result('two'))
    await expect(collect(second)).resolves.toContainEqual({ type: 'complete', text: 'two' })
    await runtime.dispose()
  })

  it('rebuilds when the CLI refuses the live effort switch', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const first = await runtime.runTurn({ agent: owner.agent, prompt: 'one' })
    transport.queries[0]!.push(init())
    transport.queries[0]!.push(result('one'))
    await collect(first)

    owner.events.push(
      { type: 'turn/start', data: { turn: 2 }, seq: owner.events.length, time: 3 },
      { type: 'step/start', data: { turn: 2, step: 1 }, seq: owner.events.length + 1, time: 4 },
    )
    transport.queries[0]!.applyFlagSettings.mockRejectedValueOnce(new Error('unsupported control request'))
    const second = await runtime.runTurn({ agent: owner.agent, prompt: 'two', thinkingMode: 'low' })
    expect(transport.queries).toHaveLength(2)
    expect(transport.queries[1]?.options.effort).toBe('low')
    expect(transport.queries[1]?.options.resume).toBe('claude-session-1')
    transport.queries[1]!.push(init())
    transport.queries[1]!.push(result('two'))
    await collect(second)
    await runtime.dispose()
  })

  it('spends no control request when the model change will rebuild the process anyway', async () => {
    // Effort and model changed together: the process is torn down for the
    // model, so asking it to move effort first would be spent on a corpse.
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const first = await runtime.runTurn({ agent: owner.agent, prompt: 'one', model: 'default', thinkingMode: 'low' })
    transport.queries[0]!.push(init())
    transport.queries[0]!.push(result('one'))
    await collect(first)

    owner.events.push(
      { type: 'turn/start', data: { turn: 2 }, seq: owner.events.length, time: 3 },
      { type: 'step/start', data: { turn: 2, step: 1 }, seq: owner.events.length + 1, time: 4 },
    )
    const second = await runtime.runTurn({ agent: owner.agent, prompt: 'two', model: 'other', thinkingMode: 'high' })
    expect(transport.queries[0]?.applyFlagSettings).not.toHaveBeenCalled()
    expect(transport.queries).toHaveLength(2)
    expect(transport.queries[1]?.options.effort).toBe('high')
    transport.queries[1]!.push(init())
    transport.queries[1]!.push(result('two'))
    await collect(second)
    await runtime.dispose()
  })

  it('rebuilds for a thinking mode the CLI only takes at start', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const first = await runtime.runTurn({ agent: owner.agent, prompt: 'one', thinkingMode: 'xhigh' })
    transport.queries[0]!.push(init())
    transport.queries[0]!.push(result('one'))
    await collect(first)

    owner.events.push(
      { type: 'turn/start', data: { turn: 2 }, seq: owner.events.length, time: 3 },
      { type: 'step/start', data: { turn: 2, step: 1 }, seq: owner.events.length + 1, time: 4 },
    )
    const second = await runtime.runTurn({ agent: owner.agent, prompt: 'two', thinkingMode: 'off' })
    // `off` is a query option, not a setting: it still costs a respawn.
    expect(transport.queries).toHaveLength(2)
    expect(transport.queries[1]?.options.thinking).toEqual({ type: 'disabled' })
    transport.queries[1]!.push(init())
    transport.queries[1]!.push(result('two'))
    await collect(second)
    await runtime.dispose()
  })
})

describe('Claude native renderer mirroring', () => {
  const native = (create: ClaudeQueryFactory) => supervisor(create, 4, 60_000, undefined, 'native')

  it('mirrors root Claude tools into the native tool channel while keeping the sidecar transcript', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = native(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'look around' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(toolCallMessage)
    query.push(toolResultMessage)
    query.push(result('done'))
    await collect(output)

    const call = owner.events.find(event => event.type === 'tool/call')
    expect(call?.data).toMatchObject({ turn: 1, step: 1, callId: 'tool-1', name: 'Bash' })
    expect(JSON.parse((call?.data as { arguments: string }).arguments)).toEqual({ command: 'ls -la' })
    const settled = owner.events.find(event => event.type === 'tool/result')
    expect(settled).toBeDefined()
    expect(JSON.stringify(settled?.data)).toContain('listed')
    // The sidecar keeps its record either way: the diff column, tasks panel,
    // and rewind all read it regardless of who paints the transcript.
    await expect(projection(runtime)).resolves.toMatchObject({
      activities: expect.arrayContaining([
        expect.objectContaining({ kind: 'tool-call', toolUseId: 'tool-1', toolName: 'Bash' }),
      ]),
    })
    await runtime.dispose()
  })

  it('mirrors Task dispatches the plugin renderer would have grouped into its own card', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = native(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'explore' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'assistant',
      message: {
        role: 'assistant',
        content: [{ type: 'tool_use', id: 'task-1', name: 'Task', input: { description: 'Explore Navi module', prompt: 'survey' } }],
      },
    } as SDKMessage)
    query.push(result('done'))
    await collect(output)

    expect(owner.events.some(event => event.type === 'tool/call' && (event.data as { name: string }).name === 'Task')).toBe(true)
    await runtime.dispose()
  })

  it('settles a denied call as a failed native result instead of leaving the card pending', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = native(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'pull latest' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(toolCallMessage)
    query.push({
      type: 'system',
      subtype: 'permission_denied',
      tool_use_id: 'tool-1',
      tool_name: 'Bash',
      message: 'The user rejected this action in DeepSeek Harness.',
    } as SDKMessage)
    query.push(result('not pulled'))
    await collect(output)

    const settled = owner.events.find(event => event.type === 'tool/result')
    expect(settled).toBeDefined()
    expect(JSON.stringify(settled?.data)).toContain('rejected')
    await runtime.dispose()
  })

  it('registers dynamic presenters for runtime-discovered tool names and leaves nested calls alone', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = native(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'search the vault' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'assistant',
      message: {
        role: 'assistant',
        content: [
          { type: 'tool_use', id: 'mcp-1', name: 'mcp__obsidian__search_simple', input: { query: 'Navi' } },
          { type: 'tool_use', id: 'mcp-2', name: 'mcp__obsidian__search_simple', input: { query: 'Slack' } },
          { type: 'tool_use', id: 'bash-1', name: 'Bash', input: { command: 'ls' } },
        ],
      },
    } as SDKMessage)
    query.push({
      type: 'assistant',
      parent_tool_use_id: 'parent-call',
      message: {
        role: 'assistant',
        content: [{ type: 'tool_use', id: 'nested-1', name: 'Read', input: { file_path: 'README.md' } }],
      },
    } as SDKMessage)
    query.push(result('done'))
    await collect(output)

    // One mirror per unseen name; Bash is already in the static preset registry.
    expect(owner.registeredTools).toEqual(['mcp__obsidian__search_simple'])
    const mirrored = owner.events.filter(event => event.type === 'tool/call').map(event => (event.data as { callId: string }).callId)
    // A subagent's nested tool belongs to the Task card that dispatched it and
    // has nothing to nest under in the native channel.
    expect(mirrored).toEqual(['mcp-1', 'mcp-2', 'bash-1'])
    await runtime.dispose()
  })

  it('stamps every record it writes so the Client suppresses the plugin transcript per step', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = native(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'look around' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(delta('Checking.'))
    query.push(toolCallMessage)
    query.push(toolResultMessage)
    query.push(result('done'))
    await collect(output)

    const activities = (await projection(runtime)).activities
    // Prose included: a step whose only record is text must still declare its
    // renderer, or the plugin transcript would redraw the natively streamed answer.
    expect(activities.filter(activity => activity.kind === 'text').length).toBeGreaterThan(0)
    expect(activities.every(activity => activity.renderer === 'native')).toBe(true)
    await runtime.dispose()
  })

  it('keeps a running turn on the renderer it was admitted with when the setting flips', async () => {
    // The reported break: switching the renderer while a turn was streaming
    // left the step half-stamped. The Client reads one native record as "the
    // whole step is DSH's to draw" and folds the plugin transcript away, while
    // the adapter -- which froze its own answer at turn start -- had streamed
    // no native blocks. The turn finished with nothing on screen.
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'look around', renderMode: 'plugin' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(delta('Checking.'))
    configs.get(runtime)!.renderMode = 'native'
    query.push(toolCallMessage)
    query.push(toolResultMessage)
    query.push(result('done'))
    await collect(output)

    const activities = (await projection(runtime)).activities
    expect(activities.length).toBeGreaterThan(0)
    expect(activities.some(activity => activity.renderer !== undefined)).toBe(false)
    expect(owner.events.some(event => event.type === 'tool/call')).toBe(false)
    await runtime.dispose()
  })

  it('lands a switch on the next turn without restamping the turn before it', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const first = await runtime.runTurn({ agent: owner.agent, prompt: 'look around', renderMode: 'plugin' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(delta('Checking.'))
    query.push(toolCallMessage)
    query.push(result('done'))
    await collect(first)

    configs.get(runtime)!.renderMode = 'native'
    // The Host opens the next DSH step; the cursor a turn records under is read
    // back from it.
    await owner.agent.session.append('turn/start', { turn: 2 })
    await owner.agent.session.append('step/start', { turn: 2, step: 1 })
    const second = await runtime.runTurn({ agent: owner.agent, prompt: 'again', renderMode: 'native' })
    query.push(delta('Checked.'))
    query.push(result('done'))
    await collect(second)

    const activities = (await projection(runtime)).activities
    const turnOne = activities.filter(activity => activity.turn === 1)
    const turnTwo = activities.filter(activity => activity.turn === 2)
    expect(turnOne.length).toBeGreaterThan(0)
    expect(turnTwo.length).toBeGreaterThan(0)
    // The turn already on screen keeps the renderer that drew it, or the Client
    // would fold a step it had already painted; only the new turn switches.
    expect(turnOne.some(activity => activity.renderer !== undefined)).toBe(false)
    expect(turnTwo.every(activity => activity.renderer === 'native')).toBe(true)
    await runtime.dispose()
  })

  it('leaves records unstamped under the plugin renderer', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'look around' })
    const query = transport.queries[0]!
    query.push(init())
    query.push(delta('Checking.'))
    query.push(toolCallMessage)
    query.push(result('done'))
    await collect(output)

    const activities = (await projection(runtime)).activities
    expect(activities.length).toBeGreaterThan(0)
    expect(activities.some(activity => activity.renderer !== undefined)).toBe(false)
    await runtime.dispose()
  })

  it('forwards settled thinking on the stream so the native renderer can draw a reasoning block', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = native(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'plan it' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'assistant',
      message: { role: 'assistant', content: [{ type: 'thinking', thinking: 'Weighing the options.' }] },
    } as SDKMessage)
    query.push(result('done'))

    await expect(collect(output)).resolves.toContainEqual({ type: 'thinking', text: 'Weighing the options.' })
    await runtime.dispose()
  })

  it('keeps thinking off the stream for the plugin renderer, which reads it from the sidecar', async () => {
    const transport = factory()
    const owner = fakeAgent()
    const runtime = supervisor(transport.create)
    const output = await runtime.runTurn({ agent: owner.agent, prompt: 'plan it' })
    const query = transport.queries[0]!
    query.push(init())
    query.push({
      type: 'assistant',
      message: { role: 'assistant', content: [{ type: 'thinking', thinking: 'Weighing the options.' }] },
    } as SDKMessage)
    query.push(result('done'))

    const events = await collect(output)
    expect(events.some(event => event.type === 'thinking')).toBe(false)
    await expect(projection(runtime)).resolves.toMatchObject({
      activities: expect.arrayContaining([
        expect.objectContaining({ kind: 'thinking', summary: 'Weighing the options.' }),
      ]),
    })
    await runtime.dispose()
  })
})
