import { mkdir, mkdtemp, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it, vi } from 'vitest'
import type { SubprocessHandle, SubprocessSpawnSpec } from '@deepseek-ai/dsh-subprocess'
import {
  RepositoryActionError,
  RepositoryActionService,
  isProtectedWarpPath,
  parseRepositoryActionStatus,
} from '../src/repository-actions.ts'

interface Result { readonly stdout?: string; readonly stderr?: string; readonly exitCode?: number; readonly lossy?: boolean }

function handle(result: Result): SubprocessHandle {
  const stdout = result.stdout ?? ''
  const stderr = result.stderr ?? ''
  return {
    pid: 1,
    stdin: undefined,
    stdout: undefined,
    stderr: undefined,
    collected: {
      stdout: { readFrom: () => ({ text: stdout, nextOffset: stdout.length, lossy: result.lossy ?? false }) },
      stderr: { readFrom: () => ({ text: stderr, nextOffset: stderr.length, lossy: false }) },
    },
    done: Promise.resolve({ exitCode: result.exitCode ?? 0, signal: null }),
    terminate: vi.fn(),
    waitForExit: async () => true,
  }
}

function runtime(results: Result[]) {
  const spawn = vi.fn((_spec: SubprocessSpawnSpec) => {
    const result = results.shift()
    if (result === undefined) throw new Error('unexpected command')
    return handle(result)
  })
  return {
    spawn,
    resolveExecutable: vi.fn(async (name: string) => `C:/bin/${name}.exe`),
  }
}

const previewResults = (status = ' M src/a.ts\n?? src/new.ts\n?? nested/WARP.md\n'): Result[] => [
  { stdout: 'C:/repo\n' },
  { stdout: 'feature/actions\n' },
  { stdout: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n' },
  { stdout: status },
  { stdout: '' },
  { stdout: 'diff --git a/src/a.ts b/src/a.ts\n@@ -1 +1 @@\n-old\n+new\n' },
  { stdout: 'origin/feature/actions\n' },
  { stdout: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\tUpdate repository actions\n' },
]

describe('repository action parsing', () => {
  it('classifies staged, unstaged, untracked, renamed, and protected paths', () => {
    expect(parseRepositoryActionStatus([
      'M  staged.ts',
      ' M unstaged.ts',
      '?? new.ts',
      'R  old.ts -> renamed.ts',
      '?? nested/WARP.md',
      ' M nested\\warp.md',
    ].join('\n'))).toEqual([
      { path: 'new.ts', staged: false, unstaged: false, untracked: true },
      { path: 'renamed.ts', origPath: 'old.ts', staged: true, unstaged: false, untracked: false },
      { path: 'staged.ts', staged: true, unstaged: false, untracked: false },
      { path: 'unstaged.ts', staged: false, unstaged: true, untracked: false },
    ])
    expect(isProtectedWarpPath('WARP.md')).toBe(true)
    expect(isProtectedWarpPath('nested/warp.MD')).toBe(true)
    expect(isProtectedWarpPath('WARP.md.bak')).toBe(false)
    expect(parseRepositoryActionStatus('R  renamed.ts\0old.ts\0?? space name.ts\0')).toEqual([
      { path: 'renamed.ts', origPath: 'old.ts', staged: true, unstaged: false, untracked: false },
      { path: 'space name.ts', staged: false, unstaged: false, untracked: true },
    ])
  })
})

describe('repository action service', () => {
  it('generates a bounded message with an isolated tool-free Claude invocation', async () => {
    const fake = runtime([
      ...previewResults(), ...previewResults(),
      { stdout: 'Resolve auth settings for generated titles\nDrop the fold control\n' },
      { stdout: 'Update repository actions\n' },
    ])
    const service = new RepositoryActionService(fake, 'C:/bin/claude.exe')
    const preview = await service.preview('C:/repo/session')
    await expect(service.generateMessage('C:/repo/session', preview.fingerprint)).resolves.toBe('Update repository actions')
    const command = fake.spawn.mock.calls.at(-1)?.[0]
    // No MCP servers and no user hooks: a commit subject cannot use either, and
    // both are what makes the cold start of this one-shot run drag.
    expect(command).toMatchObject({
      cwd: 'C:/repo',
      // Sonnet with thinking off: the diff is the whole task, and thinking was
      // most of the wall time when the naming call in prompts.ts measured it.
      env: { MAX_THINKING_TOKENS: '0' },
      argv: [
        'C:/bin/claude.exe', '-p', '--model', 'sonnet',
        '--strict-mcp-config', '--mcp-config', '{"mcpServers":{}}',
        '--setting-sources', 'project,local',
        '--tools', '', '--output-format', 'text',
      ],
      // On stdin, not argv: a real diff is longer than Windows lets a command line be.
      stdio: { stdin: { data: expect.any(String) } },
    })
    const prompt = String((command.stdio.stdin as { data: string }).data)
    expect(prompt).not.toContain('WARP.md')
    // The diff is what the message describes; the recent subjects only set its style.
    expect(prompt).toContain('-old\n+new')
    expect(prompt).toContain('- Resolve auth settings for generated titles')
    expect(fake.spawn.mock.calls.at(-2)?.[0].argv).toEqual(['C:/bin/git.exe', 'log', '--no-merges', '--format=%s', '-n', '10', 'HEAD', '--'])
  })

  it('keeps a subject a little over 72 characters for the user to trim', async () => {
    const subject = 'Generate multi-change commit messages and describe pull requests from the branch'
    const fake = runtime([...previewResults(), ...previewResults(), { stdout: '' }, { stdout: `${subject}
` }])
    const service = new RepositoryActionService(fake, 'C:/bin/claude.exe')
    const preview = await service.preview('C:/repo/session')
    await expect(service.generateMessage('C:/repo/session', preview.fingerprint)).resolves.toBe(subject)
  })

  it('keeps a body that lists each independent change under the subject', async () => {
    const fake = runtime([
      ...previewResults(), ...previewResults(),
      { stdout: '' },
      { stdout: '```\n"Rename the queue dock and fix the token meter"\n\n- Rename ClaudeQueueDock props to match the Host slot.\n- Count cache reads once in the token meter.\n```\n' },
    ])
    const service = new RepositoryActionService(fake, 'C:/bin/claude.exe')
    const preview = await service.preview('C:/repo/session')
    await expect(service.generateMessage('C:/repo/session', preview.fingerprint)).resolves.toBe(
      'Rename the queue dock and fix the token meter\n\n- Rename ClaudeQueueDock props to match the Host slot.\n- Count cache reads once in the token meter.',
    )
  })

  it('keeps at most four bullets of body, whatever the model listed', async () => {
    const fake = runtime([
      ...previewResults(), ...previewResults(),
      { stdout: '' },
      { stdout: `Rework the access control\n\n${['- One.', '- Two.', '- Three.', '- Four.', '- Five.', '- Six.'].join('\n')}\n` },
    ])
    const service = new RepositoryActionService(fake, 'C:/bin/claude.exe')
    const preview = await service.preview('C:/repo/session')
    await expect(service.generateMessage('C:/repo/session', preview.fingerprint)).resolves.toBe(
      'Rework the access control\n\n- One.\n- Two.\n- Three.\n- Four.',
    )
    // The prompt says so too, so the model aims low rather than being cut.
    const prompt = String((fake.spawn.mock.calls.at(-1)?.[0].stdio.stdin as { data: string }).data)
    expect(prompt).toContain('Never more than 4 bullets')
    expect(prompt).toContain('Do not list tests, documentation')
  })

  it('falls back to a file-based subject when the generated subject is unusable', async () => {
    const fake = runtime([
      ...previewResults(), ...previewResults(),
      { stdout: '' },
      { stdout: `${'x'.repeat(130)}\n\n- body\n` },
    ])
    const service = new RepositoryActionService(fake, 'C:/bin/claude.exe')
    const preview = await service.preview('C:/repo/session')
    await expect(service.generateMessage('C:/repo/session', preview.fingerprint)).resolves.toBe('Update 2 repository files')
  })

  it('describes a pull request from the branch commits and diff against the base, plus the tree', async () => {
    const fake = runtime([
      ...previewResults(), ...previewResults(),
      { stdout: 'origin/main\n' },
      { stdout: 'Add the pull request generator\n\n\0Fix the fingerprint check\nIt compared the wrong hash.\n\0' },
      { stdout: 'diff --git a/src/pr.ts b/src/pr.ts\n@@ -0,0 +1 @@\n+export const pr = 1\n' },
      { stdout: 'Title: Generate pull request text from the branch diff\nSummary: Pull request titles and descriptions now come from the branch itself.\n\nChanges:\n- Add a generator that reads base..HEAD.\n- Fix the fingerprint check.\n' },
    ])
    const service = new RepositoryActionService(fake, 'C:/bin/claude.exe')
    const preview = await service.preview('C:/repo/session')
    await expect(service.generatePullRequest('C:/repo/session', preview.fingerprint)).resolves.toEqual({
      title: 'Generate pull request text from the branch diff',
      body: 'Summary: Pull request titles and descriptions now come from the branch itself.\n\nChanges:\n- Add a generator that reads base..HEAD.\n- Fix the fingerprint check.',
    })
    const argv = fake.spawn.mock.calls.map(call => call[0].argv)
    expect(argv).toContainEqual(['C:/bin/git.exe', 'symbolic-ref', '--quiet', '--short', 'refs/remotes/origin/HEAD'])
    expect(argv).toContainEqual(['C:/bin/git.exe', 'log', '--no-merges', '--format=%s%n%b%x00', '-n', '51', 'origin/main..HEAD', '--'])
    expect(argv.some(item => item.includes('diff') && item.includes('origin/main...HEAD'))).toBe(true)
    const prompt = String((fake.spawn.mock.calls.at(-1)?.[0].stdio.stdin as { data: string }).data)
    expect(prompt).toContain('Fix the fingerprint check\nIt compared the wrong hash.')
    expect(prompt).toContain('+export const pr = 1')
    // The uncommitted tree goes into the same commit the pull request is opened from.
    expect(prompt).toContain('-old\n+new')
  })

  it('uses the named base branch and falls back to the commits when the answer is malformed', async () => {
    const fake = runtime([
      ...previewResults(), ...previewResults(),
      { stdout: 'refs/remotes/origin/release\n' },
      { stdout: 'Add the pull request generator\n\n\0' },
      { stdout: '' },
      { stdout: 'Here is a title.\n' },
    ])
    const service = new RepositoryActionService(fake, 'C:/bin/claude.exe')
    const preview = await service.preview('C:/repo/session')
    await expect(service.generatePullRequest('C:/repo/session', preview.fingerprint, 'release')).resolves.toEqual({
      title: 'Add the pull request generator',
      body: 'Summary: Add the pull request generator\n\nChanges:\n- Add the pull request generator',
    })
    const argv = fake.spawn.mock.calls.map(call => call[0].argv)
    expect(argv).toContainEqual(['C:/bin/git.exe', 'rev-parse', '--verify', '--quiet', '--symbolic-full-name', 'refs/remotes/origin/release'])
    expect(argv).toContainEqual(['C:/bin/git.exe', 'log', '--no-merges', '--format=%s%n%b%x00', '-n', '51', 'origin/release..HEAD', '--'])
  })

  it('describes only the tree when no base can be resolved', async () => {
    const fake = runtime([
      ...previewResults(), ...previewResults(),
      { stdout: '', exitCode: 1 },
      { stdout: 'Title: Update src/a.ts\nSummary: One line.\n\nChanges:\n- Replace old with new.\n' },
    ])
    const service = new RepositoryActionService(fake, 'C:/bin/claude.exe')
    const preview = await service.preview('C:/repo/session')
    await expect(service.generatePullRequest('C:/repo/session', preview.fingerprint)).resolves.toEqual({
      title: 'Update src/a.ts',
      body: 'Summary: One line.\n\nChanges:\n- Replace old with new.',
    })
    const argv = fake.spawn.mock.calls.map(call => call[0].argv)
    expect(argv.some(item => item.includes('log') && item.includes('--no-merges'))).toBe(false)
  })

  it('rejects a stale fingerprint before staging anything', async () => {
    const fake = runtime(previewResults())
    const service = new RepositoryActionService(fake, 'claude')
    await expect(service.execute('C:/repo', {
      action: 'commit', fingerprint: 'stale', message: 'Update files', includeUnstaged: true,
    })).rejects.toMatchObject({ code: 'repository-changed' })
    expect(fake.spawn.mock.calls.some(call => call[0].argv.includes('add'))).toBe(false)
  })

  it('stages only confirmed non-protected paths and commits through explicit argv', async () => {
    const fake = runtime([
      ...previewResults(),
      ...previewResults(),
      { stdout: '' },
      { stdout: '' },
      { stdout: '' },
      { stdout: '', exitCode: 1 },
      { stdout: '[feature/actions bbbbbbb] Update files\n' },
      { stdout: 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n' },
    ])
    const invalidated = vi.fn()
    const service = new RepositoryActionService(fake, 'claude', invalidated)
    const initial = await service.preview('C:/repo')
    await expect(service.execute('C:/repo', {
      action: 'commit', fingerprint: initial.fingerprint, message: 'Update files', includeUnstaged: true,
    })).resolves.toEqual({ commit: 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb', pushed: false })
    const argv = fake.spawn.mock.calls.map(call => call[0].argv)
    expect(argv).toContainEqual(['C:/bin/git.exe', 'add', '--', 'src/a.ts', 'src/new.ts'])
    expect(argv).toContainEqual(['C:/bin/git.exe', 'commit', '-m', 'Update files', '--'])
    expect(argv.flat()).not.toContain('nested/WARP.md')
    expect(invalidated).toHaveBeenCalledWith('C:/repo')
  })

  it('reverts the named files: tracked ones and a rename source restored, untracked ones deleted, literally', async () => {
    const status = ' M src/a.ts\n?? src/new.ts\nR  src/moved.ts -> src/[x].ts\n M src/keep.ts\n'
    const fake = runtime([...previewResults(status), ...previewResults(status), { stdout: '' }, { stdout: '' }])
    const invalidated = vi.fn()
    const service = new RepositoryActionService(fake, 'claude', invalidated)
    const initial = await service.preview('C:/repo')
    await expect(service.execute('C:/repo', {
      action: 'revert', fingerprint: initial.fingerprint, message: '', includeUnstaged: true,
      paths: ['src/a.ts', 'src/new.ts', 'src/[x].ts', 'not-listed.ts'],
    })).resolves.toEqual({ commit: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', pushed: false, reverted: 3 })
    const argv = fake.spawn.mock.calls.map(call => call[0].argv)
    expect(argv).toContainEqual(['C:/bin/git.exe', '--literal-pathspecs', 'restore', '--source=HEAD', '--staged', '--worktree', '--', 'src/[x].ts', 'src/moved.ts', 'src/a.ts'])
    expect(argv).toContainEqual(['C:/bin/git.exe', '--literal-pathspecs', 'clean', '-f', '--', 'src/new.ts'])
    // An unlisted path and an unnamed listed file are left alone.
    expect(argv.flat()).not.toContain('not-listed.ts')
    expect(argv.flat()).not.toContain('src/keep.ts')
    expect(invalidated).toHaveBeenCalledWith('C:/repo')
  })

  it('refuses to revert when none of the named files has uncommitted changes', async () => {
    const fake = runtime([...previewResults(), ...previewResults()])
    const service = new RepositoryActionService(fake, 'claude')
    const initial = await service.preview('C:/repo')
    await expect(service.execute('C:/repo', {
      action: 'revert', fingerprint: initial.fingerprint, message: '', includeUnstaged: true, paths: ['committed-only.ts'],
    })).rejects.toMatchObject({ code: 'nothing-to-revert' })
  })

  it('refuses an already staged WARP.md', async () => {
    const fake = runtime([
      ...previewResults('M  src/a.ts\nM  WARP.md\n'),
      ...previewResults('M  src/a.ts\nM  WARP.md\n'),
      { stdout: 'WARP.md\n' },
    ])
    const service = new RepositoryActionService(fake, 'claude')
    const initial = await service.preview('C:/repo')
    await expect(service.execute('C:/repo', {
      action: 'commit', fingerprint: initial.fingerprint, message: 'Update files', includeUnstaged: false,
    })).rejects.toMatchObject({ code: 'protected-warp-file' })
  })

  it('exposes the upstream and unpushed commits in the preview', async () => {
    const fake = runtime(previewResults())
    const service = new RepositoryActionService(fake, 'claude')
    const preview = await service.preview('C:/repo')
    expect(preview.upstream).toBe('origin/feature/actions')
    expect(preview.unpushedCommits).toEqual([
      { hash: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', subject: 'Update repository actions' },
    ])
    expect(preview.unpushedTruncated).toBe(false)
    expect(fake.spawn.mock.calls.at(-1)?.[0].argv).toEqual([
      'C:/bin/git.exe', 'log', '--format=%H%x09%s', '-n', '21', '@{upstream}..HEAD', '--',
    ])
  })

  it('pushes existing commits without creating a new commit', async () => {
    const fake = runtime([
      ...previewResults(''),
      ...previewResults(''),
      { stdout: 'origin/feature/actions\n' },
      { stdout: '' },
    ])
    const invalidated = vi.fn()
    const service = new RepositoryActionService(fake, 'claude', invalidated)
    const initial = await service.preview('C:/repo')
    await expect(service.execute('C:/repo', {
      action: 'push', fingerprint: initial.fingerprint, message: '', includeUnstaged: false,
    })).resolves.toEqual({ commit: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', pushed: true })
    expect(fake.spawn.mock.calls.some(call => call[0].argv.includes('commit'))).toBe(false)
    expect(fake.spawn.mock.calls.at(-1)?.[0].argv).toEqual(['C:/bin/git.exe', 'push'])
    expect(invalidated).toHaveBeenCalledWith('C:/repo')
  })

  it('creates a PR from already committed work without a new commit', async () => {
    const fake = runtime([
      ...previewResults(''),
      ...previewResults(''),
      { stdout: 'origin/feature/actions\n' },
      { stdout: '' },
      { stdout: 'https://github.com/owner/repo/pull/7\n' },
    ])
    const service = new RepositoryActionService(fake, 'claude')
    const initial = await service.preview('C:/repo')
    await expect(service.execute('C:/repo', {
      action: 'create-pr', fingerprint: initial.fingerprint, message: 'Update files', includeUnstaged: false,
      prTitle: 'Update files', prBody: 'Summary: Update files\n\nChanges:\n- Updated files',
    })).resolves.toEqual({
      commit: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
      pushed: true,
      pullRequestUrl: 'https://github.com/owner/repo/pull/7',
    })
    expect(fake.spawn.mock.calls.some(call => call[0].argv.includes('commit'))).toBe(false)
  })

  it('preserves the completed commit when push fails', async () => {
    const fake = runtime([
      ...previewResults('M  src/a.ts\n'),
      ...previewResults('M  src/a.ts\n'),
      { stdout: '' },
      { stdout: '' },
      { stdout: '', exitCode: 1 },
      { stdout: '' },
      { stdout: 'cccccccccccccccccccccccccccccccccccccccc\n' },
      { stdout: '', exitCode: 1 },
      { stdout: '', stderr: 'private remote details', exitCode: 1 },
    ])
    const service = new RepositoryActionService(fake, 'claude')
    const initial = await service.preview('C:/repo')
    await expect(service.execute('C:/repo', {
      action: 'commit-push', fingerprint: initial.fingerprint, message: 'Update files', includeUnstaged: false,
    })).rejects.toEqual(expect.objectContaining({ code: 'push-failed', commit: 'cccccccccccccccccccccccccccccccccccccccc' }))
    const push = fake.spawn.mock.calls.at(-1)?.[0].argv
    expect(push).toEqual(['C:/bin/git.exe', 'push', '--set-upstream', 'origin', 'feature/actions'])
  })

  it('requires a PR description containing only Summary and Changes', async () => {
    const fake = runtime([
      ...previewResults('M  src/a.ts\n'),
      ...previewResults('M  src/a.ts\n'),
      { stdout: '' }, { stdout: '' }, { stdout: '', exitCode: 1 }, { stdout: '' },
      { stdout: 'dddddddddddddddddddddddddddddddddddddddd\n' },
      { stdout: 'origin/feature/actions\n' }, { stdout: '' },
    ])
    const service = new RepositoryActionService(fake, 'claude')
    const initial = await service.preview('C:/repo')
    const error = await service.execute('C:/repo', {
      action: 'create-pr', fingerprint: initial.fingerprint, message: 'Update files', includeUnstaged: false,
      prTitle: 'Update files', prBody: 'Summary: Update files\n\nChanges:\n- Updated files\n\nTesting:\n- Tests',
    }).catch(value => value)
    expect(error).toBeInstanceOf(RepositoryActionError)
    expect(error).toMatchObject({ code: 'invalid-pr-description', commit: 'dddddddddddddddddddddddddddddddddddddddd' })
    expect(fake.resolveExecutable).not.toHaveBeenCalledWith('gh')
  })
})

describe('repository pull request merge', () => {
  const head = 'a'.repeat(40)

  it('merges the branch PR through gh with the selected method', async () => {
    const fake = runtime([...previewResults(), ...previewResults(), { stdout: '' }])
    const invalidated = vi.fn()
    const service = new RepositoryActionService(fake, 'claude', invalidated)
    const preview = await service.preview('C:/repo')
    await expect(service.execute('C:/repo', {
      action: 'merge-pr', fingerprint: preview.fingerprint, message: '', includeUnstaged: false, mergeMethod: 'squash',
    })).resolves.toEqual({ commit: head, pushed: true })
    const command = fake.spawn.mock.calls.at(-1)?.[0]
    expect(command).toMatchObject({ cwd: 'C:/repo', argv: ['C:/bin/gh.exe', 'pr', 'merge', '--squash'] })
    expect(invalidated).toHaveBeenCalledWith('C:/repo')
  })

  it('merges as an administrator when asked, bypassing branch protection', async () => {
    const fake = runtime([...previewResults(), ...previewResults(), { stdout: '' }])
    const service = new RepositoryActionService(fake, 'claude', vi.fn())
    const preview = await service.preview('C:/repo')
    await service.execute('C:/repo', {
      action: 'merge-pr', fingerprint: preview.fingerprint, message: '', includeUnstaged: false, mergeMethod: 'merge', admin: true,
    })
    expect(fake.spawn.mock.calls.at(-1)?.[0]).toMatchObject({ argv: ['C:/bin/gh.exe', 'pr', 'merge', '--merge', '--admin'] })
  })

  it('merges a named pull request rather than the current branch when a number is given', async () => {
    const fake = runtime([...previewResults(), ...previewResults(), { stdout: '' }])
    const service = new RepositoryActionService(fake, 'claude', vi.fn())
    const preview = await service.preview('C:/repo')
    await service.execute('C:/repo', {
      action: 'merge-pr', fingerprint: preview.fingerprint, message: '', includeUnstaged: false, mergeMethod: 'squash', pullNumber: 2086,
    })
    expect(fake.spawn.mock.calls.at(-1)?.[0]).toMatchObject({ argv: ['C:/bin/gh.exe', 'pr', 'merge', '2086', '--squash'] })
  })

  it('rejects unknown merge methods before touching gh', async () => {
    const fake = runtime([...previewResults(), ...previewResults()])
    const service = new RepositoryActionService(fake, 'claude')
    const preview = await service.preview('C:/repo')
    await expect(service.execute('C:/repo', {
      action: 'merge-pr', fingerprint: preview.fingerprint, message: '', includeUnstaged: false,
    })).rejects.toMatchObject({ code: 'invalid-request' })
    expect(fake.spawn.mock.calls.every(call => !call[0].argv.includes('merge'))).toBe(true)
  })

  it('surfaces the gh failure reason when the merge is blocked', async () => {
    const fake = runtime([...previewResults(), ...previewResults(), {
      stderr: 'X Pull request #12 is not mergeable: the base branch policy prohibits the merge.\n',
      exitCode: 1,
    }])
    const service = new RepositoryActionService(fake, 'claude')
    const preview = await service.preview('C:/repo')
    await expect(service.execute('C:/repo', {
      action: 'merge-pr', fingerprint: preview.fingerprint, message: '', includeUnstaged: false, mergeMethod: 'merge',
    })).rejects.toMatchObject({
      code: 'merge-failed',
      message: 'X Pull request #12 is not mergeable: the base branch policy prohibits the merge.',
    })
  })
})

describe('repository branch update', () => {
  const head = 'a'.repeat(40)
  const merged = 'c'.repeat(40)

  const updateResults = () => [
    ...previewResults(''),
    ...previewResults(''),
    { stdout: '' },
    { stdout: '' },
    { stdout: `${merged}\n` },
    { stdout: 'origin/feature/actions\n' },
    { stdout: '' },
  ]

  it('rebases onto the base branch by default and pushes with --force-with-lease', async () => {
    const fake = runtime(updateResults())
    const service = new RepositoryActionService(fake, 'claude')
    const preview = await service.preview('C:/repo')
    await expect(service.execute('C:/repo', {
      action: 'update-branch', fingerprint: preview.fingerprint, message: '', includeUnstaged: false, baseBranch: 'master',
    })).resolves.toEqual({ commit: merged, pushed: true })
    const argv = fake.spawn.mock.calls.map(call => call[0].argv)
    expect(argv).toContainEqual(['C:/bin/git.exe', 'fetch', 'origin', '--', 'master'])
    expect(argv).toContainEqual(['C:/bin/git.exe', 'rebase', '--', 'origin/master'])
    expect(argv.at(-1)).toEqual(['C:/bin/git.exe', 'push', '--force-with-lease'])
  })

  it('merges the base branch and pushes the merge commit when asked to merge', async () => {
    const fake = runtime(updateResults())
    const service = new RepositoryActionService(fake, 'claude')
    const preview = await service.preview('C:/repo')
    await expect(service.execute('C:/repo', {
      action: 'update-branch', fingerprint: preview.fingerprint, message: '', includeUnstaged: false, baseBranch: 'master', mergeMethod: 'merge',
    })).resolves.toEqual({ commit: merged, pushed: true })
    const argv = fake.spawn.mock.calls.map(call => call[0].argv)
    expect(argv).toContainEqual(['C:/bin/git.exe', 'merge', '--no-edit', '--', 'origin/master'])
    expect(argv.at(-1)).toEqual(['C:/bin/git.exe', 'push'])
  })

  it('reports conflicted files and leaves the rebase in place', async () => {
    const fake = runtime([
      ...previewResults(''),
      ...previewResults(''),
      { stdout: '' },
      { stdout: '', exitCode: 1 },
      { stdout: 'src/a.ts\nsrc/b.ts\n' },
    ])
    const service = new RepositoryActionService(fake, 'claude')
    const preview = await service.preview('C:/repo')
    await expect(service.execute('C:/repo', {
      action: 'update-branch', fingerprint: preview.fingerprint, message: '', includeUnstaged: false, baseBranch: 'master',
    })).resolves.toEqual({ commit: head, pushed: false, conflicts: ['src/a.ts', 'src/b.ts'] })
    expect(fake.spawn.mock.calls.every(call => !call[0].argv.includes('--abort'))).toBe(true)
  })

  it('rejects dirty trees and missing base branches before merging', async () => {
    const dirty = runtime([...previewResults(), ...previewResults()])
    const dirtyService = new RepositoryActionService(dirty, 'claude')
    const dirtyPreview = await dirtyService.preview('C:/repo')
    await expect(dirtyService.execute('C:/repo', {
      action: 'update-branch', fingerprint: dirtyPreview.fingerprint, message: '', includeUnstaged: false, baseBranch: 'master',
    })).rejects.toMatchObject({ code: 'dirty-workspace' })
    expect(dirty.spawn.mock.calls.every(call => !call[0].argv.includes('fetch'))).toBe(true)

    const missing = runtime([...previewResults(''), ...previewResults('')])
    const missingService = new RepositoryActionService(missing, 'claude')
    const missingPreview = await missingService.preview('C:/repo')
    await expect(missingService.execute('C:/repo', {
      action: 'update-branch', fingerprint: missingPreview.fingerprint, message: '', includeUnstaged: false,
    })).rejects.toMatchObject({ code: 'invalid-request' })
  })
})

describe('stopped operation resolution', () => {
  const head = 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'

  async function rebaseDir(): Promise<string> {
    const gitDir = await mkdtemp(join(tmpdir(), 'dsh-claude-gitdir-'))
    await mkdir(join(gitDir, 'rebase-merge'))
    await writeFile(join(gitDir, 'rebase-merge', 'head-name'), 'refs/heads/feature/actions\n', 'utf8')
    return gitDir
  }

  it('continues the operation git is actually holding and pushes the rewritten branch', async () => {
    const gitDir = await rebaseDir()
    const fake = runtime([
      { stdout: `C:/repo\n${gitDir}\n` },
      { stdout: '' },
      { stdout: '' },
      { stdout: `${head}\n` },
      { stdout: 'feature/actions\n' },
      { stdout: 'origin/feature/actions\n' },
      { stdout: '' },
    ])
    const service = new RepositoryActionService(fake, 'claude')
    // No preview: a stopped rebase detaches HEAD, which the preview refuses.
    await expect(service.execute('C:/repo', {
      action: 'resolve-continue', fingerprint: '', message: '', includeUnstaged: false, push: true,
    })).resolves.toEqual({ commit: head, pushed: true })
    expect(fake.spawn.mock.calls[2]?.[0].argv).toEqual(['C:/bin/git.exe', '-c', 'core.editor=true', 'rebase', '--continue'])
    expect(fake.spawn.mock.calls[6]?.[0].argv).toEqual(['C:/bin/git.exe', 'push', '--force-with-lease'])
  })

  it('refuses to continue while paths are still unmerged', async () => {
    const gitDir = await rebaseDir()
    const fake = runtime([
      { stdout: `C:/repo\n${gitDir}\n` },
      { stdout: 'src/a.ts\n' },
    ])
    await expect(new RepositoryActionService(fake, 'claude').execute('C:/repo', {
      action: 'resolve-continue', fingerprint: '', message: '', includeUnstaged: false,
    })).rejects.toMatchObject({ code: 'unresolved-conflicts' })
  })

  it('reports the next commit that stops instead of failing the resume', async () => {
    const gitDir = await rebaseDir()
    const fake = runtime([
      { stdout: `C:/repo\n${gitDir}\n` },
      { stdout: '' },
      { stdout: '', exitCode: 1 },
      { stdout: 'src/b.ts\n' },
      { stdout: `${head}\n` },
    ])
    await expect(new RepositoryActionService(fake, 'claude').execute('C:/repo', {
      action: 'resolve-continue', fingerprint: '', message: '', includeUnstaged: false, push: true,
    })).resolves.toEqual({ commit: head, pushed: false, conflicts: ['src/b.ts'] })
  })

  it('aborts the operation and never pushes what it rolled back', async () => {
    const gitDir = await mkdtemp(join(tmpdir(), 'dsh-claude-gitdir-'))
    await writeFile(join(gitDir, 'MERGE_HEAD'), `${head}\n`, 'utf8')
    const fake = runtime([
      { stdout: `C:/repo\n${gitDir}\n` },
      { stdout: '' },
      { stdout: `${head}\n` },
    ])
    await expect(new RepositoryActionService(fake, 'claude').execute('C:/repo', {
      action: 'resolve-abort', fingerprint: '', message: '', includeUnstaged: false, push: true,
    })).resolves.toEqual({ commit: head, pushed: false })
    expect(fake.spawn.mock.calls[1]?.[0].argv).toEqual(['C:/bin/git.exe', 'merge', '--abort'])
    expect(fake.spawn.mock.calls.every(call => !call[0].argv.includes('push'))).toBe(true)
  })

  it('refuses when git is holding no operation at all', async () => {
    const gitDir = await mkdtemp(join(tmpdir(), 'dsh-claude-gitdir-'))
    const fake = runtime([{ stdout: `C:/repo\n${gitDir}\n` }])
    await expect(new RepositoryActionService(fake, 'claude').execute('C:/repo', {
      action: 'resolve-abort', fingerprint: '', message: '', includeUnstaged: false,
    })).rejects.toMatchObject({ code: 'no-operation' })
  })
})
