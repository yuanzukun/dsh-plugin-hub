import type { Context } from '@deepseek-ai/cordis'
import { dirname, join } from 'node:path'
import type {} from '@deepseek-ai/dsh-attachment'
import z from '@deepseek-ai/schemastery'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type {} from '@deepseek-ai/dsh-commands'
import type {} from '@deepseek-ai/dsh-agent-preset-registry'
import type {} from '@deepseek-ai/dsh-host-webserver'
import type {} from '@deepseek-ai/dsh-jobs'
import type {} from '@deepseek-ai/dsh-subprocess'
import type {} from '@deepseek-ai/dsh-user-approval'
import type {} from '@deepseek-ai/dsh-user-questions'
import { CLAUDE_CODE_PRESET_ID, CLAUDE_CODE_PROVIDER_IDS, CLAUDE_STEERING_SERVICE } from './constants.ts'
import { CLAUDE_COMMANDS_SERVICE, projectClaudeCommands, type ClaudeAgentCommandService, type ClaudeCommandView } from './command-bridge.ts'
import { ClaudeSidecarRepository } from './sidecar.ts'
import { resolveClaudeExecutable } from './executable.ts'
import { ClaudeProcessLimitError, ClaudeSupervisor, ClaudeTurnBusyError, type ClaudeSteeringOutcome, type ClaudeSteeringService } from './supervisor.ts'
import { mountClaudeSteering } from './steering.ts'
import { createClaudeCodeAdapter } from './adapter.ts'
import { claudeBridgeDiagnostics, registerClaudeDoctorRoutes, type ClaudeBridgeDiagnostic } from './doctor-routes.ts'
import { registerClaudeProjectionRoute } from './projection-routes.ts'
import { RepositoryStatusService, type RepositoryStatus } from './repository-status.ts'
import type { ClaudeActivityEvent } from './events.ts'
import { comparablePath, RepositorySetupService } from './repository-setup.ts'
import { summarizeBranchSlug } from './branch-name.ts'
import { summarizeSessionTitle } from './session-title.ts'
import { RepositoryActionService } from './repository-actions.ts'
import { registerRepositorySetupRoute } from './repository-setup-routes.ts'
import { registerRepositoryActionRoute } from './repository-action-routes.ts'
import { PromptAssistService, registerClaudePromptNameRoute, registerClaudePromptRefineRoute, registerClaudePromptsRoute } from './prompts.ts'
import { PullRequestFeedbackService } from './pr-feedback.ts'
import { registerPullRequestFeedbackRoute } from './pr-feedback-routes.ts'
import { registerRepositoryFileRoute } from './repository-file-routes.ts'
import { JiraService } from './jira.ts'
import { registerJiraRoute } from './jira-routes.ts'
import { AskService } from './ask.ts'
import { registerAskRoute } from './ask-routes.ts'
import { registerReviewCommentRoute } from './review-comment-routes.ts'
import { registerPlanFeedbackRoute } from './plan-feedback-routes.ts'
import { registerClaudeClientDiagnosticsRoute } from './client-diagnostics-routes.ts'
import { registerClaudeRewindRoute } from './rewind-routes.ts'
import { registerClaudeBackgroundTaskRoute } from './background-task-routes.ts'
import { registerClaudePermissionModeRoute } from './permission-mode-routes.ts'
import { claudePermissionMode, type ClaudePermissionModeView, type ClaudePermissionSelector } from './permission-mode.ts'
import { alignSessionWithDefault, applyHostPreset, type HostPermissionPresetService, type HostPresetAccess } from './permission-mode-host.ts'
import { restoreWorktreeTree } from './worktree-snapshot.ts'
import { linkedRepositoryShown, touchedFilePaths, touchedPullRequests, touchedRepositoryRoots, visitedPaths } from './touched-repositories.ts'
import { SessionRootLedger } from './session-root-ledger.ts'
import { ReviewCommentStore } from './review-comments.ts'
import { registerClaudeUpdateRoutes } from './update-routes.ts'
import { canonicalClaudeModelId, claudeModelRow, claudeModelValue, ensureClaudeModels, probeClaudeModels } from './model-catalog.ts'
import { withElectronNodeRunner } from './windows-job-runner.ts'
import { detectWindowsSystemProxy, withSystemProxy, type ProxyEnv } from './system-proxy.ts'
import { normalizePlanUsage, probePlanUsage, recordPlanUsage } from './plan-usage.ts'
import { registerPlanUsageRoute } from './plan-usage-routes.ts'
import { ClaudeHostJobs } from './host-jobs.ts'
import { readDefaultPermissionMode, readPermissionSelector, readRenderMode, readSupervisorLimitOverrides, readWorktreeBranchPrefix, registerClaudeGlobalSettingsRoute } from './global-settings.ts'

// The steering contract is published for a plugin that wants to reach a running
// Claude turn itself: the service name to look up, and the shape it can rely on.
export { CLAUDE_STEERING_SERVICE } from './constants.ts'
export type { ClaudeSteeringOutcome, ClaudeSteeringService } from './supervisor.ts'

export const name = 'llm-claude'
export const inject = ['llm', 'agents', 'agentPresets', 'commands', 'subprocess', 'approval', 'userQuestions', 'attachments']

export interface Config {
  executablePath?: string
  model?: string
  idleTimeoutMs?: number
  maxProcesses?: number
}

export const Config: z<Config> = z.object({
  executablePath: z.string().default(''),
  model: z.string().default('default'),
  idleTimeoutMs: z.number().min(1_000).max(2_147_483_647).default(30 * 60 * 1_000),
  maxProcesses: z.number().step(1).min(1).default(4),
})

const CLAUDE_SCOPE_UNAVAILABLE_MESSAGE = 'agent command scope unavailable (preset route not mounted?)'
const CATALOG_RETRY_MS = 5_000
const SCOPE_RETRY_MS = 500
const MAX_CATALOG_RETRIES = 3
/** Bounded: each extra checkout costs a git chain and a `gh pr view` per sweep.
 *  A fan-out over every backend service is the largest real case. */
const MAX_EXTRA_REPOSITORIES = 12
const MAX_SCOPE_RETRIES = 24

export function mountClaudeMetadata(
  ctx: Context,
  supervisor: ClaudeSupervisor,
  agent: Agent,
  model: string,
  publishCommands: (commands: readonly ClaudeCommandView[]) => void = () => {},
  // IMPORTANT: call through the injected agentPresets SERVICE, never an
  // imported serviceForAgent() — a linked plugin resolves peer packages from
  // its own node_modules, which creates a second module instance with empty
  // module-level mount state. The service method runs on the app's instance.
  resolveCommands: () => ClaudeAgentCommandService | undefined =
    () => ctx.agentPresets.serviceFor(agent, CLAUDE_COMMANDS_SERVICE),
): (() => Promise<void>) | undefined {
  if (ctx.agentPresets.composedPreset(agent.ctx) !== CLAUDE_CODE_PRESET_ID) return undefined

  let stopped = false
  let pending = Promise.resolve()
  let commandScope: ClaudeAgentCommandService | undefined

  // The commands service is unreachable from this host view of agent.ctx;
  // the preset route plugin provides it as an isolated per-session service.
  const scopedCommands = () => {
    const scoped = commandScope ?? resolveCommands()
    if (scoped === undefined) throw new Error(CLAUDE_SCOPE_UNAVAILABLE_MESSAGE)
    commandScope = scoped
    return scoped
  }

  const commandTarget = {
    list: () => scopedCommands().list(agent),
  }

  const warn = (area: string, error: unknown) => {
    ctx.logger.warn(`dsh-claude: ${area} refresh failed for ${String(agent.id)}: ${error instanceof Error ? error.message : String(error)}`)
  }

  /** A session that is mid-turn, or a process pool with no free slot, is not a
   *  failed refresh: it is one that has to wait. The metadata lane refuses to
   *  disturb a running turn by design, so warning about it filled the log for
   *  the whole length of every long turn. A busy session refreshes again on its
   *  own idle transition; a full pool is another session's turn, so the catalog
   *  keeps its bounded retry, just without the warning. */
  const deferrable = (error: unknown): boolean =>
    error instanceof ClaudeTurnBusyError || error instanceof ClaudeProcessLimitError

  const isScopeUnavailable = (error: unknown): boolean => {
    if (error instanceof Error) return error.message === CLAUDE_SCOPE_UNAVAILABLE_MESSAGE
    return String(error) === CLAUDE_SCOPE_UNAVAILABLE_MESSAGE
  }

  const diagnostic: ClaudeBridgeDiagnostic = claudeBridgeDiagnostics.get(agent) ?? { attempts: 0 }
  claudeBridgeDiagnostics.set(agent, diagnostic)

  // A fresh session's first catalog fetch races CLI startup (skills/plugins
  // can make init slow); retry with backoff so the command palette still
  // populates without waiting for the first completed turn.
  let catalogRetries = 0
  let scopeRetries = 0
  let retryTimer: ReturnType<typeof setTimeout> | undefined

  const scheduleRetry = (area: 'command catalog' | 'command scope', attempt: number) => {
    if (retryTimer !== undefined) clearTimeout(retryTimer)
    const delay = area === 'command catalog' ? CATALOG_RETRY_MS * attempt : Math.min(SCOPE_RETRY_MS * 2 ** attempt, 5_000)
    retryTimer = setTimeout(() => {
      if (!stopped) refresh()
    }, delay)
    retryTimer.unref?.()
  }

  const refresh = () => {
    pending = pending.then(async () => {
      if (stopped) return
      diagnostic.attempts += 1

      let catalog: Awaited<ReturnType<ClaudeSupervisor['supportedCommands']>> | undefined

      try {
        const result = await supervisor.supportedCommands(agent, model)
        catalog = result
        catalogRetries = 0
        scopeRetries = 0
        diagnostic.lastCatalog = catalog.length
        delete diagnostic.lastError
      } catch (error) {
        diagnostic.lastError = error instanceof Error ? error.message : String(error)
        if (!deferrable(error)) warn('command catalog', error)
        if (!stopped && !(error instanceof ClaudeTurnBusyError) && catalogRetries < MAX_CATALOG_RETRIES) {
          catalogRetries += 1
          scheduleRetry('command catalog', catalogRetries)
        }
      }

      if (stopped || catalog === undefined) return

      try {
        const commands = projectClaudeCommands(catalog, commandTarget)
        publishCommands(commands)
        diagnostic.registered = commands.map(view => view.publicName)
        if (!stopped) scopeRetries = 0
      } catch (error) {
        diagnostic.lastError = error instanceof Error ? error.message : String(error)
        warn('command catalog', error)
        if (!stopped && isScopeUnavailable(error) && scopeRetries < MAX_SCOPE_RETRIES) {
          scopeRetries += 1
          scheduleRetry('command scope', scopeRetries)
        }
      }

      if (stopped) return
      // Plan limits belong to the account, not the session, so any idle Claude
      // agent can refresh the cache the (session-less) settings page reads.
      try {
        const plan = await supervisor.planUsage(agent, model)
        if (!stopped) recordPlanUsage(normalizePlanUsage(plan, Date.now()))
      } catch (error) {
        if (!deferrable(error)) warn('plan usage', error)
      }
    })
  }

  return agent.ctx.effect(() => {
    const stopStatus = agent.ctx.on('agent/status', ({ status }) => {
      if (status === 'idle') refresh()
    })

    refresh()

    return async () => {
      stopped = true
      publishCommands([])
      if (retryTimer !== undefined) clearTimeout(retryTimer)
      stopStatus()
      await pending
    }
  }, 'dsh-claude: agent metadata bridge')
}

export async function apply(ctx: Context, config: Config): Promise<void> {
  // Every subprocess this plugin starts goes through one runtime so the
  // Desktop 2.0.7 Windows Job runner workaround applies to all of them, and so
  // each inherits the system proxy when the Host passes none (see
  // system-proxy.ts). Detection runs in the background: the first Claude turn
  // comes long after it settles, and boot is not held on the registry.
  const runner = withElectronNodeRunner(ctx.subprocess)
  let systemProxy: ProxyEnv | undefined
  const subprocess = withSystemProxy(runner, () => systemProxy)
  void detectWindowsSystemProxy(runner).then(proxy => {
    systemProxy = proxy
    if (proxy !== undefined) ctx.logger.info('dsh-claude: child processes use the Windows system proxy')
  })
  const defaultLimits = {
    idleTimeoutMs: config.idleTimeoutMs ?? 30 * 60 * 1_000,
    maxProcesses: config.maxProcesses ?? 4,
  }
  const supervisorConfig = {
    executablePath: '',
    defaultModel: config.model ?? 'default',
    ...defaultLimits,
  }
  // Settings overrides win over the plugin config; the supervisor reads the
  // shared config object on every admission and idle schedule, so updates take
  // effect without a restart. The renderer is not kept here: the adapter reads
  // its file at the start of each turn and pins the answer to that turn, so
  // both halves of a turn -- the records the supervisor stamps and the blocks
  // the adapter streams -- agree about who is drawing it, and a settings file
  // edited outside the Settings dialog lands on the next turn all the same.
  const applySettingsOverrides = async (): Promise<void> => {
    const overrides = await readSupervisorLimitOverrides()
    supervisorConfig.idleTimeoutMs = overrides.idleTimeoutMs ?? defaultLimits.idleTimeoutMs
    supervisorConfig.maxProcesses = overrides.maxProcesses ?? defaultLimits.maxProcesses
  }
  await applySettingsOverrides()
  // Cached so the projection can put it on the first snapshot line without a
  // file read; refreshed whenever the Settings panel writes.
  let permissionSelector: ClaudePermissionSelector = await readPermissionSelector()
  const sidecar = new ClaudeSidecarRepository()
  const repositoryStatus = new RepositoryStatusService(subprocess)
  const repositorySetup = new RepositorySetupService(subprocess, {
    branchPrefix: () => readWorktreeBranchPrefix(),
    // Read at call time: the executable is resolved after this service exists.
    summarizeBranch: intent => summarizeBranchSlug(supervisorConfig.executablePath, intent),
  })
  const reviewComments = new ReviewCommentStore()
  const commandCatalogs = new Map<string, readonly ClaudeCommandView[]>()
  /** The Host's access knobs, driven from a Claude mode; see permission-mode-host.ts. */
  const hostPresets: HostPresetAccess = {
    presets: () => ctx.get('permissionPresets') as HostPermissionPresetService | undefined,
    setPolicy: (agent, policy) => { ctx.approval.setPolicy(agent, policy as never) },
  }
  const supervisor = new ClaudeSupervisor({
    runtime: subprocess,
    approval: ctx.approval,
    userQuestions: ctx.userQuestions,
    config: supervisorConfig,
    runDetached: operation => ctx.agents.withoutInitiator(operation),
    sidecar,
    defaultPermissionMode: () => readDefaultPermissionMode(),
    permissionSelector: async () => permissionSelector,
    // A CLI that dies mid-turn is diagnosed from the log, not from the
    // conversation it was in the middle of.
    logger: { warn: message => { ctx.logger.warn(message) } },
    hostJobs: new ClaudeHostJobs(() => ctx.get('jobs'), message => { ctx.logger.warn(message) }),
  })
  let resolutionError: unknown
  try {
    const resolution = await resolveClaudeExecutable(
      subprocess,
      config.executablePath === undefined || config.executablePath.length === 0
        ? undefined
        : config.executablePath,
    )
    supervisorConfig.executablePath = resolution.path
    ctx.llm.registerAdapter(
      [...CLAUDE_CODE_PROVIDER_IDS],
      createClaudeCodeAdapter(supervisor, ctx.agents, ctx.attachments, agent => ctx.agentPresets.composedPreset(agent.ctx), sessionId => reviewComments.drain(sessionId), () => readRenderMode(), request => summarizeSessionTitle(supervisorConfig.executablePath, request), () => probeClaudeModels(supervisorConfig.executablePath)),
    )
    // The profile's default model is written by whatever the user last picked,
    // so it can hold a spelling a later lineup no longer lists -- every new
    // session then opens on it and the selector prints `claude/<id>`. Once
    // the lineup is known, a default the lineup maps is rewritten to its row.
    void ensureClaudeModels(() => probeClaudeModels(supervisorConfig.executablePath)).then(() => {
      const defaults = ctx.get('agentDefaultModel') as {
        currentSelection(): { provider: string; model: string; reasoningEffort?: string }
        saveSelection(next: { provider: string; model: string; reasoningEffort?: string }): Promise<void>
      } | undefined
      const current = defaults?.currentSelection()
      if (defaults === undefined || current === undefined || !(CLAUDE_CODE_PROVIDER_IDS as readonly string[]).includes(current.provider)) return
      const model = canonicalClaudeModelId(current.model)
      if (model === current.model) return
      return defaults.saveSelection({ ...current, model })
    }).catch((error: unknown) => {
      ctx.logger.warn(`dsh-claude: could not normalize the default model: ${error instanceof Error ? error.message : String(error)}`)
    })
    // Steering entry point. A message steered into a running Claude turn has to
    // pass through the supervisor that owns that turn's process; whoever takes
    // it out of the agent inbox calls this first, and `unavailable` tells them
    // to keep the message for a later turn instead of losing it.
    ctx.provide(CLAUDE_STEERING_SERVICE, {
      deliver: (sessionId, prompt): ClaudeSteeringOutcome => supervisor.deliverSteering(sessionId, prompt),
    } satisfies ClaudeSteeringService)
    // And the one caller that always exists: DSH's own Steer action, which puts
    // the message in the agent's next-step inbox. Nothing else would claim it
    // until this turn ended.
    ctx.effect(() => mountClaudeSteering(
      ctx,
      supervisor,
      ctx.attachments,
      async () => (await readRenderMode()) === 'native',
      message => { ctx.logger.warn(message) },
    ), 'dsh-claude: steering bridge')
    ctx.effect(() => {
      const mounted = new Map<Agent, () => Promise<void>>()
      const pending = new Set<Agent>()
      const MOUNT_RETRY_MS = 200
      const MOUNT_RETRY_LIMIT = 50
      /** A session this plugin just met (created, or switched to the Claude
       *  preset) is put on the sandbox its default mode needs, so a Host whose
       *  default preset is full access does not turn a configured `auto` into
       *  bypass. Sessions found on boot keep whatever they were on. */
      const align = async (agent: Agent): Promise<void> => {
        if (permissionSelector === 'native') return
        const sessionId = agent.id as string
        try {
          const [projection, defaultMode] = await Promise.all([sidecar.read(sessionId), readDefaultPermissionMode()])
          alignSessionWithDefault(hostPresets, agent, projection.permissionMode, defaultMode)
        } catch (error) {
          ctx.logger.warn(`dsh-claude: default permission mode not applied for ${sessionId}: ${error instanceof Error ? error.message : String(error)}`)
        }
      }
      const mount = (agent: Agent, fresh: boolean) => {
        if (mounted.has(agent)) return
        const sessionId = agent.id as string
        if (fresh) void align(agent)
        const dispose = mountClaudeMetadata(
          ctx,
          supervisor,
          agent,
          supervisorConfig.defaultModel,
          commands => {
            if (commands.length === 0) commandCatalogs.delete(sessionId)
            else commandCatalogs.set(sessionId, commands)
          },
        )
        if (dispose !== undefined) mounted.set(agent, dispose)
        pending.delete(agent)
      }
      // The standing preset mount lands AFTER agent/created (the PresetTree is
      // applied asynchronously), so composedPreset is still undefined at that
      // point. Poll briefly until the join settles, then decide.
      const mountWhenPresetSettles = (agent: Agent, fresh: boolean) => {
        if (mounted.has(agent) || pending.has(agent)) return
        if (ctx.agentPresets.composedPreset(agent.ctx) !== undefined) {
          mount(agent, fresh)
          return
        }
        pending.add(agent)
        let attempts = 0
        const retry = () => {
          if (mounted.has(agent) || !pending.has(agent)) return
          if (ctx.agentPresets.composedPreset(agent.ctx) !== undefined) {
            mount(agent, fresh)
            return
          }
          attempts += 1
          if (attempts >= MOUNT_RETRY_LIMIT) {
            pending.delete(agent)
            return
          }
          const timer = setTimeout(retry, MOUNT_RETRY_MS)
          timer.unref?.()
        }
        const timer = setTimeout(retry, MOUNT_RETRY_MS)
        timer.unref?.()
      }
      const stopCreated = ctx.on('agent/created', ({ agent }) => {
        mountWhenPresetSettles(agent, true)
        return undefined
      })
      // Belt and suspenders: the session records its preset selection as a
      // durable event, which agent-presets republishes as agent-preset/selected.
      // agent-preset/selected is emitted by dsh-agent-preset-registry but is not part
      // of the typed host event map yet; subscribe through a typed escape hatch.
      const onPresetSelected = ctx.on as (event: 'agent-preset/selected', handler: (sessionId: string, preset: string) => void) => () => void
      const stopSelected = onPresetSelected('agent-preset/selected', (sessionId, preset) => {
        if (preset !== CLAUDE_CODE_PRESET_ID) return
        const agent = ctx.agents.get(sessionId as never)
        if (agent !== undefined) mountWhenPresetSettles(agent, true)
      })
      for (const agent of ctx.agents.list()) mountWhenPresetSettles(agent, false)
      return async () => {
        stopCreated()
        stopSelected()
        pending.clear()
        await Promise.allSettled([...mounted.values()].map(dispose => dispose()))
        mounted.clear()
      }
    }, 'dsh-claude: metadata bridges')
  } catch (error) {
    resolutionError = error
  }
  ctx.on('agent/disposed', async ({ agent }) => {
    reviewComments.disposeSession(agent.id as string)
    await supervisor.disposeSession(agent.id as string, 'agent disposed by the Host')
  })
  // Set once the reconciliation below is wired; the Client's sweep route kicks
  // it so a deleted workspace does not wait out the interval.
  let sweepWorktrees: (() => void) | undefined
  // Deleting a workspace from the sidebar is a durable-registry mutation with
  // no agent lifecycle edge, so worktree cleanup reconciles leases against
  // the workspace registry instead: unreferenced clean worktrees are removed
  // on boot, on the Client's deletion kick, and on a slow interval.
  // workspaceRegistry is not part of this plugin's typed host surface yet;
  // inject through an untyped escape hatch so older Hosts without the service
  // simply never start the sweep.
  const injectWorkspaceRegistry = ctx.inject as unknown as (
    deps: readonly string[],
    callback: (sweepCtx: Context & {
      workspaceRegistry: {
        list(): readonly { readonly path: string }[]
        archiveSession(sessionId: string): Promise<void>
      }
    }) => void,
  ) => void
  injectWorkspaceRegistry(['workspaceRegistry'], sweepCtx => {
    // Deleting a workspace only drops its registration: the Host keeps every
    // session log, and rebuilds the workspace from those headers on the next
    // boot. Archiving the sessions that lived in the worktree is what makes
    // the deletion stick. Resolved per sweep rather than injected so a Host
    // without the service still gets worktree cleanup.
    const archiveSessions = async (worktreePath: string): Promise<void> => {
      const persistence = sweepCtx.get('sessionPersistence') as {
        list(): Promise<readonly { readonly id?: unknown; readonly cwd?: unknown }[]>
      } | undefined
      if (persistence === undefined) return
      const target = comparablePath(worktreePath)
      for (const header of await persistence.list()) {
        if (typeof header.id !== 'string' || typeof header.cwd !== 'string') continue
        if (comparablePath(header.cwd) !== target) continue
        await sweepCtx.workspaceRegistry.archiveSession(header.id).catch(() => undefined)
      }
    }
    const sweep = (): void => {
      try {
        const paths = sweepCtx.workspaceRegistry.list().map(workspace => workspace.path)
        void repositorySetup.cleanupOrphans(paths, archiveSessions).catch(() => undefined)
      } catch {
        // The registry can be mid-teardown; skip this pass.
      }
    }
    sweepCtx.effect(() => {
      sweep()
      sweepWorktrees = sweep
      // The kick covers the deletion the user is watching; this poll is the
      // backstop for a Client that never sent one. A pass with nothing to
      // reconcile is one small file read.
      const timer = setInterval(sweep, 60_000)
      timer.unref?.()
      return () => {
        sweepWorktrees = undefined
        clearInterval(timer)
      }
    }, 'dsh-claude: worktree reconciliation')
  })
  ctx.effect(() => () => reviewComments.dispose(), 'dsh-claude: review comments store')
  ctx.effect(() => () => supervisor.dispose(), 'dsh-claude: process supervisor')
  ctx.effect(() => () => repositoryStatus.dispose(), 'dsh-claude: repository status cache')
  ctx.inject(['webServer'], webCtx => {
    registerClaudeClientDiagnosticsRoute(webCtx)
    registerClaudeDoctorRoutes(webCtx, subprocess, supervisor, supervisorConfig, resolutionError)
    const desktopActions = webCtx.get('desktopActions') as { requestRestart?: () => void } | undefined
    registerClaudeUpdateRoutes(webCtx, subprocess, {
      ...(typeof desktopActions?.requestRestart === 'function'
        ? { requestRestart: desktopActions.requestRestart.bind(desktopActions) }
        : {}),
    })
    registerClaudeGlobalSettingsRoute(webCtx, {
      defaultLimits,
      onUpdated: async () => {
        await applySettingsOverrides()
        permissionSelector = await readPermissionSelector()
        supervisor.limitsChanged()
      },
    })
    /** Linked pull requests cleaned up, as `clone root + branch`: the log
     *  still names them, so the sweep has to be told to stop listing them. */
    const cleanedLinked = new Set<string>()
    registerRepositorySetupRoute(webCtx, repositorySetup, () => sweepWorktrees?.(), (path, branch) => {
      repositoryStatus.invalidate(path)
      if (branch !== undefined) cleanedLinked.add(`${path}\0${branch}`)
    })
    registerRepositoryFileRoute(webCtx, repositoryStatus)
    registerJiraRoute(webCtx, new JiraService())
    const repositoryActions = new RepositoryActionService(subprocess, supervisorConfig.executablePath, cwd => repositoryStatus.invalidate(cwd))
    /** Checkouts besides its own a session's routes may act on: every root a
     *  projection sweep has ever vouched for, so a transient probe failure in
     *  one sweep does not un-authorise a linked bar the client still shows. */
    const extraRoots = new SessionRootLedger(MAX_EXTRA_REPOSITORIES * 4)
    const cwdForClaudeSession = (sessionId: string, root?: string): string | undefined => {
      const agent = webCtx.agents.get(sessionId as never)
      if (agent === undefined || webCtx.agentPresets.composedPreset(agent.ctx) !== CLAUDE_CODE_PRESET_ID) return undefined
      if (root === undefined) return agent.session.header.cwd
      return extraRoots.allows(sessionId, root) ? root : undefined
    }
    const extraRepositoriesForClaudeSession = async (sessionId: string, activities: readonly ClaudeActivityEvent[]): Promise<readonly RepositoryStatus[]> => {
      const cwd = cwdForClaudeSession(sessionId)
      if (cwd === undefined) return []
      const [own, ownStatus] = await Promise.all([repositoryStatus.rootOf(cwd), repositoryStatus.inspect(cwd)])
      const roots = await touchedRepositoryRoots(touchedFilePaths(activities), own ?? cwd, directory => repositoryStatus.rootOf(directory), MAX_EXTRA_REPOSITORIES)
      const probed = await Promise.all(roots.map(root => repositoryStatus.inspect(root)))
      const checkouts = probed.filter(linkedRepositoryShown)
      // Pull requests the log names that no linked checkout is sitting on any
      // more: the checkout moved on, the pull request did not. A clone of the
      // same repository the session went through, even one back on its base
      // branch, is still where gh can merge it or read its checks from.
      const covered = new Set(checkouts.map(status => `${status.remote?.toLowerCase()}#${status.pullRequest?.number}`))
      const pullRequests = touchedPullRequests(activities, ownStatus.remote)
        .filter(item => !covered.has(`${item.repository}#${item.number}`))
        .slice(0, Math.max(0, MAX_EXTRA_REPOSITORIES - checkouts.length))
      // Clones stand side by side: the session's own next to the user's other
      // checkouts, a fan-out's under one scratch directory. A pull request the
      // log named but whose clone no command named by its full path is looked
      // for under those parents by its repository name.
      const parents = [...new Set([own ?? cwd, ...probed.flatMap(status => (status.root === undefined ? [] : [status.root]))].map(root => dirname(root)))]
      const visited = pullRequests.length === 0 ? [] : visitedPaths(activities)
      const cloneFor = async (item: { repository: string }): Promise<string | undefined> => {
        const named = probed.find(status => status.status === 'ready' && status.remote?.toLowerCase() === item.repository && status.root !== undefined)
        if (named?.root !== undefined) return named.root
        const name = item.repository.split('/').at(-1) ?? ''
        // A checkout the session went into, even only to read it, first.
        // ponytail: only paths naming the repository, so a long log costs no probes.
        const went = visited.filter(path => path.toLowerCase().includes(name.toLowerCase()))
        for (const candidate of [...went, ...parents.map(parent => join(parent, name))]) {
          const root = await repositoryStatus.rootOf(candidate)
          if (root === undefined) continue
          const status = await repositoryStatus.inspect(root)
          if (status.status === 'ready' && status.remote?.toLowerCase() === item.repository) return root
        }
        return undefined
      }
      const detached = (await Promise.all(pullRequests.map(async item => {
        const cloneRoot = await cloneFor(item)
        const status = await repositoryStatus.inspectPullRequest(cloneRoot ?? cwd, item.repository, item.number)
        if (cloneRoot === undefined || status.status !== 'ready') return status
        if (status.branch !== undefined && cleanedLinked.has(`${cloneRoot}\0${status.branch}`)) return { status: 'unavailable' as const, cwd }
        return { ...status, root: cloneRoot }
      }))).filter(linkedRepositoryShown)
      const linked = [...checkouts, ...detached]
      extraRoots.vouch(sessionId, linked.flatMap(status => (status.root === undefined ? [] : [status.root])))
      return linked
    }
    registerRepositoryActionRoute(webCtx, repositoryActions, cwdForClaudeSession)
    registerClaudePromptsRoute(webCtx)
    const promptAssist = new PromptAssistService(subprocess, () => supervisorConfig.executablePath)
    registerClaudePromptNameRoute(webCtx, promptAssist)
    registerClaudePromptRefineRoute(webCtx, promptAssist)
    registerPullRequestFeedbackRoute(webCtx, new PullRequestFeedbackService(subprocess), cwdForClaudeSession)
    registerAskRoute(webCtx, new AskService(subprocess, supervisorConfig.executablePath), cwdForClaudeSession, sessionId => {
      const snapshot = supervisor.snapshots().find(item => item.sessionId === sessionId)
      return snapshot === undefined ? undefined : { model: claudeModelValue(snapshot.model), ...(snapshot.thinkingMode === undefined ? {} : { thinkingMode: snapshot.thinkingMode }) }
    })
    const ownsClaudeSession = (sessionId: string): boolean => {
      const agent = webCtx.agents.get(sessionId as never)
      return agent !== undefined && webCtx.agentPresets.composedPreset(agent.ctx) === CLAUDE_CODE_PRESET_ID
    }
    registerReviewCommentRoute(webCtx, reviewComments, ownsClaudeSession)
    registerPlanFeedbackRoute(webCtx, supervisor.planFeedback, ownsClaudeSession)
    registerClaudeBackgroundTaskRoute(webCtx, { background: (sessionId, toolUseId) => supervisor.backgroundToolCall(sessionId, toolUseId) })
    registerClaudeRewindRoute(webCtx, sidecar, {
      eventsFor: sessionId => {
        const agent = webCtx.agents.get(sessionId as never)
        return agent === undefined || webCtx.agentPresets.composedPreset(agent.ctx) !== CLAUDE_CODE_PRESET_ID
          ? undefined
          : agent.session.snapshotEvents()
      },
      busy: sessionId => supervisor.snapshots().some(item => (
        item.sessionId === sessionId && (item.state === 'running' || item.state === 'interrupting')
      )),
      reset: sessionId => supervisor.disposeSession(sessionId, 'rewind reset'),
      restoreFiles: async (sessionId, tree) => {
        const agent = webCtx.agents.get(sessionId as never)
        const cwd = agent?.session.header.cwd
        return cwd === undefined ? false : restoreWorktreeTree(subprocess, cwd, tree)
      },
    })
    registerPlanUsageRoute(webCtx, fetchedAt => probePlanUsage(supervisorConfig.executablePath, fetchedAt))
    const claudeSessionBusy = (sessionId: string): boolean => supervisor.snapshots().some(item => (
      item.sessionId === sessionId && (item.state === 'running' || item.state === 'interrupting')
    ))
    registerClaudePermissionModeRoute(webCtx, sidecar, {
      ownsSession: ownsClaudeSession,
      busy: claudeSessionBusy,
      applyHostPreset: async (sessionId, sandbox) => {
        const agent = webCtx.agents.get(sessionId as never)
        return agent !== undefined && applyHostPreset(hostPresets, agent, sandbox)
      },
    })
    const permissionModeForClaudeSession = async (sessionId: string): Promise<ClaudePermissionModeView | undefined> => {
      const agent = webCtx.agents.get(sessionId as never)
      if (agent === undefined || webCtx.agentPresets.composedPreset(agent.ctx) !== CLAUDE_CODE_PRESET_ID) return undefined
      const projection = await sidecar.read(sessionId)
      const folded = claudePermissionMode(agent.session.snapshotEvents(), permissionSelector === 'native' ? undefined : projection.permissionMode ?? await readDefaultPermissionMode())
      // `auto` is per model. The model is only known here while a process is
      // live; a session between processes is offered the mode, and the CLI
      // answers for itself on the next spawn.
      const live = supervisor.snapshots().find(item => item.sessionId === sessionId)
      const autoSupported = live === undefined ? undefined : claudeModelRow(live.model)?.supportsAutoMode
      const mode = folded === 'auto' && autoSupported === false ? 'default' : folded
      return { mode, locked: claudeSessionBusy(sessionId), ...(autoSupported === undefined ? {} : { autoSupported }) }
    }
    registerClaudeProjectionRoute(webCtx, sidecar, ownsClaudeSession, sessionId => commandCatalogs.get(sessionId) ?? [], async sessionId => {
      const agent = webCtx.agents.get(sessionId as never)
      if (agent === undefined || webCtx.agentPresets.composedPreset(agent.ctx) !== CLAUDE_CODE_PRESET_ID) return undefined
      const cwd = agent.session.header.cwd
      return cwd === undefined ? undefined : repositoryStatus.inspect(cwd)
    }, sessionId => reviewComments.list(sessionId), extraRepositoriesForClaudeSession, permissionModeForClaudeSession, () => permissionSelector, (listener) => {
      // The selection event lands before the preset mount does (see the
      // metadata bridges), so wait for ownership to match the pick.
      const onPresetSelected = webCtx.on as (event: 'agent-preset/selected', handler: (sessionId: string, preset: string) => void) => () => void
      return onPresetSelected('agent-preset/selected', (sessionId, preset) => {
        let attempts = 0
        const check = (): void => {
          attempts += 1
          if (ownsClaudeSession(sessionId) === (preset === CLAUDE_CODE_PRESET_ID) || attempts >= 25) {
            listener(sessionId)
            return
          }
          setTimeout(check, 200).unref?.()
        }
        check()
      })
    })
  })
}
