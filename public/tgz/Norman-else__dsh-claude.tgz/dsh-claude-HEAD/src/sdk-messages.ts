import type { SDKMessage } from '@anthropic-ai/claude-agent-sdk'
import type { ClaudeUsage } from './events.ts'
import { API_RETRY_TITLE, CLAUDE_PROGRESS_SUBTYPES, CLAUDE_UNKNOWN_MESSAGE_PREFIX, claudeStatusTitle } from './constants.ts'

export type NormalizedSdkMessage =
  | { kind: 'init'; sessionId: string; cliVersion: string; cwd: string }
  | { kind: 'text-delta'; text: string; parentToolUseId?: string }
  | { kind: 'assistant-text'; text: string; parentToolUseId?: string }
  | { kind: 'thinking'; text: string; phase: 'updated' | 'completed'; parentToolUseId?: string }
  | { kind: 'tool-call'; toolUseId: string; toolName: string; input: unknown; parentToolUseId?: string }
  | {
    kind: 'tool-result'
    toolUseId: string
    /** The structured `tool_use_result` when the CLI sent one, else the block content. */
    output: unknown
    /** The model-facing block content when `output` is the structured result
     *  instead (a backgrounded Bash names its output file only here). */
    content?: unknown
    isError: boolean
    parentToolUseId?: string
  }
  | {
    kind: 'subagent'
    title: string
    summary?: string
    detail?: unknown
    phase: 'started' | 'updated' | 'completed' | 'failed'
    /** Structured task-board fields for task_started/progress/updated/notification. */
    taskId?: string
    /** The tool call that dispatched the task, when the CLI names it. */
    toolUseId?: string
    taskStatus?: 'running' | 'completed' | 'failed' | 'stopped' | 'killed'
    description?: string
    subagentType?: string
    taskType?: string
    lastToolName?: string
    usage?: { totalTokens?: number; toolUses?: number; durationMs?: number }
    /** Ambient/housekeeping task: hide from chat rows, keep on the task board. */
    skipTranscript?: boolean
    /** task_started: registered detached (true) or blocking its tool call (false). */
    backgrounded?: boolean
    /** Where the CLI wrote the settled task's output (task_notification). */
    outputFile?: string
  }
  | {
    /** Level signal: full live background-task set (REPLACE semantics). */
    kind: 'background-tasks'
    tasks: readonly { taskId: string; taskType?: string; description: string; ambient?: true }[]
  }
  | {
    /** Context compaction boundary. The CLI compacts locally without running a
     *  model turn, so this is the only evidence the conversation was rewritten;
     *  `trigger` stays absent when the CLI does not name one. */
    kind: 'compaction'
    trigger?: 'manual' | 'auto'
    preTokens?: number
    postTokens?: number
    durationMs?: number
  }
  | {
    /** Prompt-side accounting for ONE provider call, read off an assistant
     *  message. Distinct from the `result` usage, which sums every call the
     *  turn made — see `ClaudeSupervisor#reportedUsage`. */
    kind: 'request-usage'
    usage: ClaudeUsage
    parentToolUseId?: string
  }
  | { kind: 'status'; title: string; summary?: string; detail?: unknown }
  | { kind: 'warning'; title: string; summary?: string; detail?: unknown }
  | {
    /** Progress telemetry the CLI streams while it works (see
     *  {@link CLAUDE_PROGRESS_SUBTYPES}). It proves the turn is alive and
     *  nothing else: the activity log never keeps it. */
    kind: 'progress'
    subtype: string
  }
  | { kind: 'permission-denied'; toolUseId: string; toolName: string; summary: string }
  | { kind: 'result'; success: boolean; text?: string; errors?: readonly string[]; usage: ClaudeUsage; sessionId: string; userMessageUuid?: string; queuedTurnCount?: number; terminalReason?: string; permissionDenials?: readonly { toolName: string; toolUseId: string }[] }
  | { kind: 'protocol-error'; title: string; detail: unknown }
  /** Claude Code's guess at the user's next prompt; arrives after `result`. */
  | { kind: 'prompt-suggestion'; text: string }
  | {
    /** A message type this package does not handle yet. `type` is what the
     *  supervisor dedupes on: the CLI repeats these in batches, and one piece of
     *  evidence per type is worth keeping where a row per frame is not. */
    kind: 'unknown'
    type: string
    title: string
    detail: unknown
  }

function record(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === 'object' ? value as Record<string, unknown> : undefined
}

function string(value: unknown): string | undefined {
  return typeof value === 'string' ? value : undefined
}

function finiteNumber(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined
}

function contentText(content: unknown): string {
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return ''
  return content.map(item => {
    const block = record(item)
    if (block?.type === 'text') return string(block.text) ?? ''
    return ''
  }).join('')
}

function taskUsageOf(usage: Record<string, unknown> | undefined): { totalTokens?: number; toolUses?: number; durationMs?: number } | undefined {
  if (usage === undefined) return undefined
  const normalized: { totalTokens?: number; toolUses?: number; durationMs?: number } = {}
  if (typeof usage.total_tokens === 'number') normalized.totalTokens = usage.total_tokens
  if (typeof usage.tool_uses === 'number') normalized.toolUses = usage.tool_uses
  if (typeof usage.duration_ms === 'number') normalized.durationMs = usage.duration_ms
  return Object.keys(normalized).length === 0 ? undefined : normalized
}

/** Read one Anthropic `usage` envelope. Shared by the per-call sample on an
 *  assistant message and the turn total on a result message. */
function usageOf(usage: Record<string, unknown> | undefined): ClaudeUsage {
  const normalized: ClaudeUsage = {}
  if (usage === undefined) return normalized
  if (typeof usage.input_tokens === 'number') normalized.inputTokens = usage.input_tokens
  if (typeof usage.output_tokens === 'number') normalized.outputTokens = usage.output_tokens
  if (typeof usage.cache_read_input_tokens === 'number') normalized.cacheReadTokens = usage.cache_read_input_tokens
  if (typeof usage.cache_creation_input_tokens === 'number') normalized.cacheCreationTokens = usage.cache_creation_input_tokens
  return normalized
}

function hasUsageCounts(usage: ClaudeUsage): boolean {
  return usage.inputTokens !== undefined
    || usage.outputTokens !== undefined
    || usage.cacheReadTokens !== undefined
    || usage.cacheCreationTokens !== undefined
}

function resultUsage(message: Record<string, unknown>): ClaudeUsage {
  const normalized = usageOf(record(message.usage))
  if (typeof message.total_cost_usd === 'number') normalized.cumulativeCostUsd = message.total_cost_usd
  return normalized
}

function normalizeAssistant(message: Record<string, unknown>): NormalizedSdkMessage[] {
  const envelope = record(message.message)
  const content = envelope?.content
  if (!Array.isArray(content)) return [{ kind: 'protocol-error', title: 'Malformed Claude assistant message', detail: message }]
  const parentToolUseId = string(message.parent_tool_use_id)
  const normalized: NormalizedSdkMessage[] = []
  for (const item of content) {
    const block = record(item)
    if (block === undefined) continue
    if (block.type === 'text') {
      const text = string(block.text)
      if (text !== undefined && text.length > 0) normalized.push({ kind: 'assistant-text', text, ...(parentToolUseId === undefined ? {} : { parentToolUseId }) })
    } else if (block.type === 'thinking') {
      const text = string(block.thinking)
      if (text !== undefined && text.length > 0) normalized.push({ kind: 'thinking', text, phase: 'completed', ...(parentToolUseId === undefined ? {} : { parentToolUseId }) })
    } else if (block.type === 'tool_use') {
      const toolUseId = string(block.id)
      const toolName = string(block.name)
      if (toolUseId !== undefined && toolName !== undefined) {
        normalized.push({
          kind: 'tool-call',
          toolUseId,
          toolName,
          input: block.input,
          ...(parentToolUseId === undefined ? {} : { parentToolUseId }),
        })
      }
    }
  }
  const usage = usageOf(record(envelope?.usage))
  if (hasUsageCounts(usage)) {
    normalized.push({ kind: 'request-usage', usage, ...(parentToolUseId === undefined ? {} : { parentToolUseId }) })
  }
  return normalized
}

function normalizeUser(message: Record<string, unknown>): NormalizedSdkMessage[] {
  // CLI ≥ 2.1.238 replays prior user messages (including local-command output
  // echoes with plain string content) when resuming a session. Replays and
  // block-less string echoes carry no tool results; they are not protocol
  // failures and must never kill the session.
  if (message.isReplay === true) return []
  const envelope = record(message.message)
  const content = envelope?.content
  if (typeof content === 'string') return []
  if (!Array.isArray(content)) return [{ kind: 'protocol-error', title: 'Malformed Claude user message', detail: message }]
  const parentToolUseId = string(message.parent_tool_use_id)
  const normalized: NormalizedSdkMessage[] = []
  for (const item of content) {
    const block = record(item)
    if (block?.type !== 'tool_result') continue
    const toolUseId = string(block.tool_use_id)
    if (toolUseId === undefined) continue
    normalized.push({
      kind: 'tool-result',
      toolUseId,
      output: message.tool_use_result ?? block.content,
      ...(message.tool_use_result === undefined ? {} : { content: block.content }),
      isError: block.is_error === true,
      ...(parentToolUseId === undefined ? {} : { parentToolUseId }),
    })
  }
  return normalized
}

function normalizeSystem(message: Record<string, unknown>): NormalizedSdkMessage[] {
  const subtype = string(message.subtype)
  if (subtype === 'init') {
    const sessionId = string(message.session_id)
    const cliVersion = string(message.claude_code_version)
    const cwd = string(message.cwd)
    return sessionId !== undefined && cliVersion !== undefined && cwd !== undefined
      ? [{ kind: 'init', sessionId, cliVersion, cwd }]
      : [{ kind: 'protocol-error', title: 'Malformed Claude initialization message', detail: message }]
  }
  if (subtype === 'status') {
    const status = message.status
    if (status === null) return [{ kind: 'status', title: 'Claude Code is ready' }]
    return [{ kind: 'status', title: `Claude Code ${String(status)}`, detail: message }]
  }
  if (subtype === 'session_state_changed') {
    return [{ kind: 'status', title: `Claude session ${String(message.state)}` }]
  }
  if (subtype === 'permission_denied') {
    const toolUseId = string(message.tool_use_id)
    const toolName = string(message.tool_name)
    if (toolUseId !== undefined && toolName !== undefined) {
      return [{
        kind: 'permission-denied',
        toolUseId,
        toolName,
        summary: string(message.message) ?? 'Claude Code denied the action',
      }]
    }
  }
  if (subtype === 'task_started') {
    const taskId = string(message.task_id)
    const description = string(message.description)
    const subagentType = string(message.subagent_type)
    const taskType = string(message.task_type)
    const taskToolUseId = string(message.tool_use_id)
    return [{
      kind: 'subagent',
      title: description ?? taskId ?? 'Claude subagent started',
      phase: 'started',
      detail: message,
      ...(taskId === undefined ? {} : { taskId }),
      ...(taskToolUseId === undefined ? {} : { toolUseId: taskToolUseId }),
      taskStatus: 'running' as const,
      ...(description === undefined ? {} : { description }),
      ...(subagentType === undefined ? {} : { subagentType }),
      ...(taskType === undefined ? {} : { taskType }),
      ...(message.skip_transcript === true ? { skipTranscript: true } : {}),
      ...(typeof message.is_backgrounded === 'boolean' ? { backgrounded: message.is_backgrounded } : {}),
    }]
  }
  if (subtype === 'task_progress') {
    const taskId = string(message.task_id)
    const description = string(message.description)
    const summary = string(message.summary)
    const taskToolUseId = string(message.tool_use_id)
    const subagentType = string(message.subagent_type)
    const lastToolName = string(message.last_tool_name)
    const usage = taskUsageOf(record(message.usage))
    return [{
      kind: 'subagent',
      title: summary ?? description ?? 'Claude subagent update',
      phase: 'updated',
      detail: message,
      ...(taskId === undefined ? {} : { taskId }),
      ...(taskToolUseId === undefined ? {} : { toolUseId: taskToolUseId }),
      taskStatus: 'running' as const,
      // No `description`: here it is the live status line ("Running Read x"),
      // and folding it into the task board renamed the task on every step.
      // The board keeps what task_started named it; the status rides the title.
      ...(subagentType === undefined ? {} : { subagentType }),
      ...(lastToolName === undefined ? {} : { lastToolName }),
      ...(summary === undefined ? {} : { summary }),
      ...(usage === undefined ? {} : { usage }),
    }]
  }
  if (subtype === 'task_updated') {
    const patch = record(message.patch)
    const status = string(patch?.status)
    const taskId = string(message.task_id)
    const taskToolUseId = string(message.tool_use_id)
    const description = string(patch?.description)
    const error = string(patch?.error)
    const taskStatus = status === undefined
      ? undefined
      : status === 'killed'
        ? 'killed' as const
        : status === 'completed'
          ? 'completed' as const
          : status === 'failed'
            ? 'failed' as const
            : 'running' as const
    return [{
      kind: 'subagent',
      title: description ?? 'Claude subagent update',
      phase: status === 'failed' || status === 'killed' ? 'failed' : status === 'completed' ? 'completed' : 'updated',
      detail: message,
      ...(taskId === undefined ? {} : { taskId }),
      ...(taskToolUseId === undefined ? {} : { toolUseId: taskToolUseId }),
      ...(taskStatus === undefined ? {} : { taskStatus }),
      ...(description === undefined ? {} : { description }),
      ...(error === undefined ? {} : { summary: error }),
    }]
  }
  if (subtype === 'task_notification') {
    const failed = message.status === 'failed'
    const stopped = message.status === 'stopped' || message.status === 'cancelled'
    const taskId = string(message.task_id)
    const summary = string(message.summary)
    const taskToolUseId = string(message.tool_use_id)
    const taskStatus = failed ? 'failed' as const : stopped ? 'stopped' as const : 'completed' as const
    const usage = taskUsageOf(record(message.usage))
    const outputFile = string(message.output_file)
    return [{
      kind: 'subagent',
      title: summary ?? taskId ?? 'Claude subagent finished',
      phase: failed || stopped ? 'failed' : 'completed',
      detail: message,
      ...(taskId === undefined ? {} : { taskId }),
      ...(taskToolUseId === undefined ? {} : { toolUseId: taskToolUseId }),
      taskStatus,
      ...(summary === undefined ? {} : { summary }),
      ...(usage === undefined ? {} : { usage }),
      ...(outputFile === undefined ? {} : { outputFile }),
    }]
  }
  if (subtype === 'background_tasks_changed') {
    const tasks = Array.isArray(message.tasks) ? message.tasks : []
    return [{
      kind: 'background-tasks',
      tasks: tasks.flatMap(item => {
        const entry = record(item)
        const taskId = string(entry?.task_id)
        const description = string(entry?.description)
        const taskType = string(entry?.task_type)
        if (taskId === undefined || description === undefined) return []
        return [{
          taskId,
          description,
          ...(taskType === undefined ? {} : { taskType }),
          ...(entry?.ambient === true ? { ambient: true as const } : {}),
        }]
      }),
    }]
  }
  if (subtype === 'api_retry') {
    // The summary is the whole point of the row: without one the transcript
    // falls back to "Done", which says nothing about a request still failing.
    const attempt = finiteNumber(message.attempt)
    const maxRetries = finiteNumber(message.max_retries)
    const status = finiteNumber(message.error_status)
    const summary = [
      attempt === undefined ? undefined : maxRetries === undefined ? `attempt ${attempt}` : `attempt ${attempt} of ${maxRetries}`,
      status === undefined ? string(message.error) : `HTTP ${status}`,
    ].filter(part => part !== undefined).join(' · ')
    return [{ kind: 'warning', title: API_RETRY_TITLE, ...(summary === '' ? {} : { summary }), detail: message }]
  }
  if (subtype === 'compact_boundary') {
    // `/compact` runs entirely inside the CLI: no assistant turn, and the
    // `Compacted` echo arrives as a block-less user message that
    // `normalizeUser` drops. Without this branch the boundary fell through to
    // the generic fallback below and became audit-only 'status', so a
    // compacted conversation showed nothing at all.
    const metadata = record(message.compact_metadata)
    const trigger = metadata?.trigger === 'auto' || metadata?.trigger === 'manual' ? metadata.trigger : undefined
    const preTokens = finiteNumber(metadata?.pre_tokens)
    const postTokens = finiteNumber(metadata?.post_tokens)
    const durationMs = finiteNumber(metadata?.duration_ms)
    return [{
      kind: 'compaction',
      ...(trigger === undefined ? {} : { trigger }),
      ...(preTokens === undefined ? {} : { preTokens }),
      ...(postTokens === undefined ? {} : { postTokens }),
      ...(durationMs === undefined ? {} : { durationMs }),
    }]
  }
  if (subtype === 'informational' || subtype === 'notification' || subtype === 'local_command_output') {
    return [{
      kind: message.level === 'warning' ? 'warning' : 'status',
      title: string(message.content) ?? string(message.text) ?? 'Claude Code notice',
      detail: message,
    }]
  }
  if (subtype !== undefined && CLAUDE_PROGRESS_SUBTYPES.has(subtype)) {
    // Progress telemetry, not lifecycle evidence. Kept off the activity log
    // deliberately: the SDK emits these per estimated thinking-token chunk, so
    // one step can produce tens of thousands of durable rows — the transcript
    // renders none of them, and each one costs a full sidecar rewrite.
    return [{ kind: 'progress', subtype }]
  }
  if (subtype?.startsWith('hook_') === true || subtype === 'plugin_install') {
    return [{ kind: 'status', title: claudeStatusTitle(subtype), detail: message }]
  }
  if (subtype !== undefined) {
    // Preserve unknown system lifecycle evidence (background tasks, resets,
    // worker/mirror lifecycle) as a bounded activity instead of silently
    // dropping it; the activity layer redacts and bounds the detail.
    return [{ kind: 'status', title: claudeStatusTitle(subtype), detail: message }]
  }
  return []
}

const RESULT_ERROR_SUBTYPES = new Set([
  'error_during_execution',
  'error_max_turns',
  'error_max_budget_usd',
  'error_max_structured_output_retries',
])

export function normalizeSdkMessage(message: SDKMessage): NormalizedSdkMessage[] {
  const value = message as unknown as Record<string, unknown>
  if (value.type === 'stream_event') {
    const event = record(value.event)
    const parentToolUseId = string(value.parent_tool_use_id)
    if (event?.type === 'content_block_delta') {
      const delta = record(event.delta)
      if (delta?.type === 'text_delta') {
        const text = string(delta.text)
        return text === undefined ? [] : [{ kind: 'text-delta', text, ...(parentToolUseId === undefined ? {} : { parentToolUseId }) }]
      }
      if (delta?.type === 'thinking_delta') {
        const text = string(delta.thinking)
        return text === undefined ? [] : [{ kind: 'thinking', text, phase: 'updated', ...(parentToolUseId === undefined ? {} : { parentToolUseId }) }]
      }
    }
    if (event?.type === 'message_delta') {
      // The one place a single request's own usage survives. The assistant
      // message the CLI also emits for the same request carries zeros -- it is
      // the placeholder Claude Code forwards -- and the result reports the
      // turn's SUM over every request, which is not a size the Host can divide
      // by a context window. This frame is that request's prompt exactly.
      const usage = usageOf(record(event.usage))
      return hasUsageCounts(usage) ? [{ kind: 'request-usage', usage, ...(parentToolUseId === undefined ? {} : { parentToolUseId }) }] : []
    }
    return []
  }
  if (value.type === 'assistant') return normalizeAssistant(value)
  if (value.type === 'user') return normalizeUser(value)
  if (value.type === 'system') return normalizeSystem(value)
  if (value.type === 'result') {
    const sessionId = string(value.session_id)
    if (sessionId === undefined || (value.subtype !== 'success' && !RESULT_ERROR_SUBTYPES.has(String(value.subtype)))) {
      return [{ kind: 'protocol-error', title: 'Malformed Claude result message', detail: value }]
    }
    // A result is a success only when it is not flagged as an error. Local
    // 2.1.233 emits subtype:"success" with is_error:true for API/auth failures
    // (e.g. terminal_reason:"api_error"), so subtype alone is not authoritative.
    const success = value.subtype === 'success' && value.is_error !== true
    const errors = Array.isArray(value.errors)
      ? value.errors.filter((item): item is string => typeof item === 'string')
      : undefined
    const terminalReason = string(value.terminal_reason)
    const userMessageUuid = string(value.user_message_uuid)
    // User sends the CLI had not reached when it produced this result: non-zero
    // means at least one more turn follows without further input, so this result
    // is not the end of the turn.
    const queuedTurnCount = finiteNumber(value.queued_turn_count)
    const permissionDenials = Array.isArray(value.permission_denials)
      ? value.permission_denials
          .map(item => record(item))
          .filter((item): item is Record<string, unknown> => item !== undefined)
          .map(item => {
            const toolName = string(item.tool_name)
            const toolUseId = string(item.tool_use_id)
            return toolName === undefined || toolUseId === undefined ? undefined : { toolName, toolUseId }
          })
          .filter((item): item is { toolName: string; toolUseId: string } => item !== undefined)
          .slice(0, 40)
      : undefined
    return [{
      kind: 'result',
      success,
      ...(success && typeof value.result === 'string' ? { text: value.result } : {}),
      ...(errors === undefined ? {} : { errors }),
      ...(terminalReason === undefined ? {} : { terminalReason }),
      ...(permissionDenials === undefined || permissionDenials.length === 0 ? {} : { permissionDenials }),
      usage: resultUsage(value),
      sessionId,
      ...(userMessageUuid === undefined ? {} : { userMessageUuid }),
      ...(queuedTurnCount === undefined ? {} : { queuedTurnCount }),
    }]
  }
  if (value.type === 'prompt_suggestion') {
    const text = string((value as { suggestion?: unknown }).suggestion)?.trim()
    return text === undefined || text.length === 0 ? [] : [{ kind: 'prompt-suggestion', text }]
  }
  if (value.type === 'auth_status') {
    return [{
      kind: value.error === undefined ? 'status' : 'warning',
      title: value.error === undefined ? 'Claude authentication status changed' : 'Claude authentication failed',
      detail: value.error ?? value.output,
    }]
  }
  if (value.type === 'rate_limit_event') {
    // The CLI pushes subscription-quota status after API activity. Every
    // update stays audit-only ('status' never enters the conversation flow);
    // a blocking state surfaces through the repository status bar badge that
    // reads these titles from the projection instead.
    const info = record(value.rate_limit_info)
    const status = string(info?.status)
    const blocking = status !== undefined && status !== 'allowed'
    return [{
      kind: 'status',
      title: blocking ? 'Claude rate limit is blocking requests' : 'Claude rate limit status changed',
      detail: value.rate_limit_info,
    }]
  }
  if (value.type === 'tool_progress') {
    // Heartbeats the CLI emits while a tool runs (elapsed time, task id). Same
    // telemetry class as the thinking-token frames, and equally unrenderable:
    // see CLAUDE_PROGRESS_SUBTYPES.
    return [{ kind: 'progress', subtype: 'tool_progress' }]
  }
  if (value.type === 'command_lifecycle') {
    // CLI 2.1.259+ reports each queued prompt's queued → running → done
    // transitions. The turn lifecycle already tells the same story, so these
    // are telemetry too, not an unknown message worth a warning row.
    return [{ kind: 'progress', subtype: 'command_lifecycle' }]
  }
  const unknownType = String(value.type)
  return [{ kind: 'unknown', type: unknownType, title: `${CLAUDE_UNKNOWN_MESSAGE_PREFIX}${unknownType}`, detail: value }]
}

export function extractSdkContentText(content: unknown): string {
  return contentText(content)
}
