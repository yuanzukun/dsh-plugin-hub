import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type {} from '@deepseek-ai/dsh-agent-preset-registry'
import type {} from '@deepseek-ai/dsh-commands'
import type {} from '@deepseek-ai/dsh-host-webserver'
import { CLAUDE_DOCTOR_PATH } from './constants.ts'
import { runClaudeDoctor, type ExecutableRuntime } from './executable.ts'
import type { ClaudeSupervisor, ClaudeSupervisorConfig } from './supervisor.ts'
import { redactText } from './events.ts'
import { registerPluginRoute } from './http.ts'
import { CLAUDE_CODE_PROVIDER_IDS } from './constants.ts'
import { canonicalClaudeModelId, claudeLineupKnown, latestClaudeModels } from './model-catalog.ts'

export const CLAUDE_DOCTOR_PROBE_TIMEOUT_MS = 15_000

/** Live metadata-bridge state per agent, maintained by the host plugin. */
export interface ClaudeBridgeDiagnostic {
  attempts: number
  lastError?: string
  lastCatalog?: number
  registered?: string[]
}

export const claudeBridgeDiagnostics = new WeakMap<Agent, ClaudeBridgeDiagnostic>()

function safeMessage(error: unknown): string {
  return redactText(error instanceof Error ? error.message : String(error), 1_000)
}

/** Model selections the selector cannot name: the profile default and each
 *  live Claude session's persisted model (its latest request header), checked
 *  against the catalog. A stranded one shows as `claude/<id>` in the composer;
 *  `repairsTo` is the row the next request will record instead, when any. */
export function modelDiagnostics(ctx: Context): unknown {
  try {
    const listed = new Set(latestClaudeModels().map(row => row.id))
    const check = (model: string) => {
      const repairsTo = canonicalClaudeModelId(model)
      return listed.has(model) ? { model, listed: true } : { model, listed: false, ...(listed.has(repairsTo) ? { repairsTo } : {}) }
    }
    const defaults = (ctx.get('agentDefaultModel') as { currentSelection(): { provider: string; model: string } } | undefined)?.currentSelection()
    const stranded = ctx.agents.list().flatMap(agent => {
      const config = agent.session.requestHeader()?.config
      if (config === undefined || !(CLAUDE_CODE_PROVIDER_IDS as readonly string[]).includes(config.provider) || listed.has(config.model)) return []
      return [{ sessionId: String(agent.id), ...check(config.model) }]
    })
    return {
      source: claudeLineupKnown() ? 'cli' : 'seed',
      rows: listed.size,
      ...(defaults === undefined ? {} : {
        default: (CLAUDE_CODE_PROVIDER_IDS as readonly string[]).includes(defaults.provider)
          ? { provider: defaults.provider, ...check(defaults.model) }
          : { provider: defaults.provider, model: defaults.model },
      }),
      stranded,
    }
  } catch (error) {
    return { error: safeMessage(error) }
  }
}

/** Live command-bridge diagnostics: which agents exist, their presets, and how
 *  many slash commands each agent's registry layer resolves. */
function commandDiagnostics(ctx: Context): unknown {
  try {
    const agents = ctx.agents.list()
    return {
      total: agents.length,
      agents: agents.map(agent => {
        const info: { id: string; preset?: string; commandCount?: number; sample?: string[]; error?: string; bridge?: ClaudeBridgeDiagnostic } = { id: String(agent.id) }
        try {
          const preset = ctx.agentPresets.composedPreset(agent.ctx)
          if (preset !== undefined) info.preset = preset
        } catch (error) {
          info.error = safeMessage(error)
        }
        try {
          const list = ctx.commands.list(agent)
          info.commandCount = list.length
          info.sample = list.slice(0, 10).map(command => command.name)
        } catch (error) {
          info.error = info.error === undefined ? safeMessage(error) : `${info.error}; ${safeMessage(error)}`
        }
        const bridge = claudeBridgeDiagnostics.get(agent)
        if (bridge !== undefined) info.bridge = bridge
        return info
      }),
    }
  } catch (error) {
    return { error: safeMessage(error) }
  }
}

/** The boot step that threw, if any. `executable` means resolution failed;
 *  `initialization` means the executable was found and a later step failed. */
export interface ClaudeBootFailure {
  step: 'executable' | 'initialization'
  error: unknown
}

export function registerClaudeDoctorRoutes(
  ctx: Context,
  runtime: ExecutableRuntime,
  supervisor: ClaudeSupervisor,
  config: ClaudeSupervisorConfig,
  bootFailure?: ClaudeBootFailure,
): void {
  registerPluginRoute(ctx, {
    mode: 'unary',
    kind: 'exact',
    path: CLAUDE_DOCTOR_PATH,
    methods: ['GET'],
    budget: 'git',
    handler: async io => {
      try {
        if (bootFailure?.step === 'executable') {
          return { status: 200, value: {
            executable: {
              status: 'missing',
              searched: config.executablePath.length > 0 ? [config.executablePath] : ['claude', '~/.local/bin/claude', '/opt/homebrew/bin/claude', '/usr/local/bin/claude'],
            },
            version: { status: 'not-run' },
            authentication: { status: 'not-run' },
            handshake: 'not-run',
            message: safeMessage(bootFailure.error),
            limits: {
              idleTimeoutMs: config.idleTimeoutMs,
              maxProcesses: config.maxProcesses,
            },
            processes: { count: 0, active: 0 },
          } }
        }
        const report = await runClaudeDoctor(runtime, {
          configuredPath: config.executablePath,
          cwd: process.cwd(),
          // Threaded so freeing the socket also stops the probe, rather than
          // leaving a spawn nobody is waiting for; the ceiling stays its own.
          signal: AbortSignal.any([io.signal, AbortSignal.timeout(CLAUDE_DOCTOR_PROBE_TIMEOUT_MS)]),
        })
        const processes = supervisor.snapshots()
        if (processes.some(process => process.claudeSessionId !== undefined)) report.handshake = 'ok'
        return { status: 200, value: {
          ...report,
          ...(bootFailure === undefined ? {} : { initialization: { status: 'failed', message: safeMessage(bootFailure.error) } }),
          limits: {
            idleTimeoutMs: config.idleTimeoutMs,
            maxProcesses: config.maxProcesses,
          },
          processes: {
            count: processes.length,
            active: processes.filter(process => process.state === 'running' || process.state === 'starting').length,
          },
          commandBridge: commandDiagnostics(ctx),
          models: modelDiagnostics(ctx),
        } }
      } catch (error) {
        return { status: 500, value: { error: safeMessage(error) } }
      }
    },
  })
}
