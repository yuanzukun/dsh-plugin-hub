import { randomUUID } from 'node:crypto'
import {
  query as claudeQuery,
  type EffortLevel,
  type Options as ClaudeOptions,
  type PermissionMode,
  type Query,
  type SDKControlGetContextUsageResponse,
  type SDKMessage,
  type SDKUserMessage,
  type Settings as ClaudeSettings,
  type SlashCommand,
} from '@anthropic-ai/claude-agent-sdk'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { ApprovalService } from '@deepseek-ai/dsh-user-approval'
import type { UserQuestionService } from '@deepseek-ai/dsh-user-questions'
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess'
import { AsyncQueue } from './async-queue.ts'
import { DEFAULT_CLAUDE_RENDER_MODE, TASK_TOOL_NAMES, type ClaudeRenderMode } from './constants.ts'
import {
  currentClaudeActivityCursor,
  redactText,
  type ClaudeActivityCursor,
  type ClaudeActivityInput,
  type ClaudeTaskInfo,
  type ClaudeUsage,
} from './events.ts'
import { createAutoModeEscalation, createPermissionBridge } from './permission.ts'
import { PlanFeedbackGate } from './plan-feedback.ts'
import { createUserQuestionBridge } from './user-question.ts'
import { ClaudeSidecarRepository } from './sidecar.ts'
import { claudePermissionMode, type ClaudePermissionMode, type ClaudePermissionSelector } from './permission-mode.ts'
import { normalizeSdkMessage, type NormalizedSdkMessage } from './sdk-messages.ts'
import { claudeModelRow, claudeModelValue, recordClaudeModels } from './model-catalog.ts'
import { readPlanUsageFrom } from './plan-usage.ts'
import { createManagedClaudeSpawner, type ManagedClaudeProcess } from './spawn.ts'
import { captureWorktreeTree } from './worktree-snapshot.ts'
import { hostJobKind, hostJobProgress, type ClaudeHostJobs } from './host-jobs.ts'
import type {} from '@deepseek-ai/dsh-tool-todo'
import { ClaudeTaskBoard, carriedTodos, todosFromTodoWrite, type TodoItem } from './todo-bridge.ts'

export const CLAUDE_INITIALIZATION_TIMEOUT_MS = 30_000
export const CLAUDE_INTERRUPT_TIMEOUT_MS = 5_000
/** Control requests must settle; a wedged one must not clog the metadata chain. */
export const CLAUDE_METADATA_TIMEOUT_MS = 15_000
/** A blocking Bash call that runs this long is moved to the background on its
 *  own, where the Host job list can show and stop it. */
export const CLAUDE_FOREGROUND_BASH_BACKGROUND_MS = 60_000
/** Bound on steered messages one turn may own, so a misbehaving caller cannot
 *  grow the ownership set without limit. */
export const MAX_STEERED_PROMPTS_PER_TURN = 16

/** What {@link ClaudeSupervisor.deliverSteering} did with one steered message. */
export type ClaudeSteeringOutcome = 'delivered' | 'unavailable'

/** The steering entry point this package publishes on the Cordis service named
 *  by `CLAUDE_STEERING_SERVICE`. */
export interface ClaudeSteeringService {
  /**
   * Hand one user message to the turn `sessionId` is running.
   * @param sessionId - DSH session id whose Claude preset is running.
   * @param prompt - the message content, already the user's own.
   * @returns `delivered` once the running turn owns it, `unavailable` when there
   *   is no running turn to steer — keep the message for a later turn.
   */
  deliver(sessionId: string, prompt: SDKUserMessage['message']['content']): ClaudeSteeringOutcome
}
/** How long a disconnect waits for the dead process to be reaped, so the
 *  failure can say how it ended. A process that died for its own reasons
 *  resolves immediately; this only bounds the case where it has not died. */
export const DISCONNECT_EXIT_WAIT_MS = 1_000

export type ClaudeSupervisorState =
  | 'starting'
  | 'idle'
  | 'running'
  | 'interrupting'
  | 'disconnected'
  | 'outcome-unknown'
  | 'disposed'

export interface ClaudeSupervisorConfig {
  executablePath: string
  idleTimeoutMs: number
  maxProcesses: number
  defaultModel: string
  /** Which renderer the visible turn is produced for; read per message so a
   *  Settings change lands on the next turn without a Host restart. */
  renderMode?: ClaudeRenderMode
  /** After this long a blocking Bash call is moved to the background; 0 disables it. */
  foregroundBashBackgroundMs?: number
}

export type ClaudeTurnStreamEvent =
  | { type: 'text-delta'; text: string }
  /** One settled Claude thinking block, forwarded only for the native
   *  renderer, which draws it as a DSH reasoning block. */
  | { type: 'thinking'; text: string }
  | { type: 'usage'; usage: ClaudeUsage }
  | { type: 'segment-complete'; text: string }
  /** The turn's closing prose, sent under the plugin renderer just before
   *  `complete` so the Host has a final answer to keep outside its fold. */
  | { type: 'answer'; text: string }
  | { type: 'complete'; text: string }

export type ClaudeThinkingMode = 'off' | 'ultracode' | EffortLevel

export type { DshSandboxMode } from './permission-mode.ts'
export { claudePermissionMode } from './permission-mode.ts'

/** What a running process accepts as a live settings change. `effortLevel` here
 *  is the full {@link EffortLevel}: unlike the settings file, this request takes
 *  the session-scoped `max` too. */
type ClaudeFlagSettings = Parameters<Query['applyFlagSettings']>[0]

/** Appended to the Claude Code system prompt on every session.
 *
 *  The plan panel opens on exactly one signal: an `ExitPlanMode` call, whose
 *  argument is the plan (see `planText` in permission.ts). Claude Code's own
 *  plan mode says to make that call once the plan file is written, but
 *  user-installed skills routinely say the opposite — "confirm the design in
 *  prose before proceeding" — and a turn that ends on that question hands DSH
 *  nothing to show: no record, no button, no panel, until the user types
 *  "continue" and Claude makes the call it skipped. This line settles the
 *  conflict in favour of the handoff, so the plan reaches the panel the moment
 *  it is done rather than one message later. */
export const PLAN_MODE_HANDOFF_PROMPT =
  'When you are in plan mode and the plan is written, end the turn by calling ExitPlanMode with the plan. '
  + 'Do not end a plan-mode turn by asking the user for confirmation in prose: '
  + 'the user reads and approves the plan through ExitPlanMode, and a turn that stops short of that call shows them nothing.'

/** Appended alongside the plan-mode rule.
 *
 *  The Host's chat opens a Markdown file link in the right Sidebar preview,
 *  but an inline-code path stays inert unless a first-party DSH write tool or
 *  `present` produced it — Claude's tools are neither. The native agent is
 *  told to link files by the Host's `ui:deliverable-file-references` prompt
 *  section, which never reaches Claude; this is its equivalent, minus the
 *  `present` tool Claude does not have. */
export const FILE_LINK_PROMPT =
  'Outside commands, configuration expressions, and code blocks, write every mention of an existing file as a Markdown link, '
  + 'including repeats and tables, so the user can open it: [name](<path>), where path is relative to the working directory or absolute, '
  + 'enclosed in angle brackets. Append #L24 or #L24-L30 to the path for known lines. Use the filename as the label, '
  + 'adding only enough parent directories to distinguish files; keep full paths out of labels. Never write a file path as bare inline code.'

export const SYSTEM_PROMPT_APPEND = `${PLAN_MODE_HANDOFF_PROMPT}\n\n${FILE_LINK_PROMPT}`

/** The live equivalent of a thinking mode, or undefined when the mode is a
 *  start-time shape the CLI will not take later: `off` disables thinking through
 *  a query option, `ultracode` is a settings bundle, and "no explicit mode" is
 *  the CLI's own default. Those still rebuild the process. */
function liveEffortSettings(mode: ClaudeThinkingMode | undefined): ClaudeFlagSettings | undefined {
  switch (mode) {
    case 'low':
    case 'medium':
    case 'high':
    case 'xhigh':
    case 'max':
      return { effortLevel: mode }
    default:
      return undefined
  }
}

export interface ClaudeTurnRequest {
  agent: Agent
  prompt: SDKUserMessage['message']['content']
  model?: string
  thinkingMode?: ClaudeThinkingMode
  /** The renderer this turn is produced for, frozen by the caller before the
   *  turn starts. The setting is live, so reading it per record would let a
   *  mid-turn switch stamp one step's records with both renderers -- which the
   *  Client reads as "natively drawn" for the whole step, while the adapter,
   *  which froze its own answer at turn start, streamed nothing natively.
   *  Omitted falls back to the shared config. */
  renderMode?: ClaudeRenderMode
  signal?: AbortSignal
}

export interface ClaudeSupervisorSnapshot {
  sessionId: string
  claudeSessionId?: string
  state: ClaudeSupervisorState
  cwd: string
  model: string
  thinkingMode?: ClaudeThinkingMode
  lastUsedAt: number
}

export class ClaudeTurnBusyError extends Error {
  constructor(sessionId: string) {
    super(`Claude Code session ${sessionId} already has an active or interrupting turn`)
    this.name = 'ClaudeTurnBusyError'
  }
}

export class ClaudeOutcomeUnknownError extends Error {
  constructor(message = 'Claude Code exited after activity; side-effect outcome is unknown and the prompt was not replayed') {
    super(message)
    this.name = 'ClaudeOutcomeUnknownError'
  }
}

export class ClaudeProtocolError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'ClaudeProtocolError'
  }
}

export class ClaudeProcessLimitError extends Error {
  constructor(maxProcesses: number) {
    super(`Claude Code process limit reached (${maxProcesses}) and no idle session can be evicted`)
    this.name = 'ClaudeProcessLimitError'
  }
}

export type ClaudeQueryFactory = (params: {
  prompt: AsyncIterable<SDKUserMessage>
  options: ClaudeOptions
}) => Query

interface ActiveTurn {
  agent: Agent
  cursor: ClaudeActivityCursor
  /** Last complete text block recorded per subagent call: the CLI re-sends a
   *  message's blocks as each one completes, and one copy is enough. */
  subagentText: Map<string, string>
  /** Whether this turn is produced for DSH's own renderer. Frozen at admission
   *  so every record of the turn carries one answer. */
  native: boolean
  output: AsyncQueue<ClaudeTurnStreamEvent>
  promptUuid: ReturnType<typeof randomUUID>
  /** Every prompt this turn owns: the one that opened it, plus any steered
   *  message delivered into it while it ran. A result naming one of these is
   *  this turn's own; anything else is stale or a protocol violation. */
  ownedPromptUuids: Set<string>
  phase: 'primary' | 'waiting-tasks' | 'follow-up'
  sawActivity: boolean
  sawTextDelta: boolean
  text: string
  /** Visible prose for the current top-level assistant segment. */
  transcriptText: string
  /** Stable sidecar ordinal reused while the current assistant segment grows. */
  transcriptTextOrdinal: number | undefined
  thinking: string
  /** Newest single-call prompt accounting; what DSH's context meter divides. */
  requestUsage: ClaudeUsage | undefined
  /** When this turn was admitted, and when it first put a token on screen.
   *  The transcript has no other clock: activities carry no timestamps. */
  startedAt: number
  firstOutputAt: number | undefined
  aborted: boolean
  deniedToolUseIds: Set<string>
  /** Root tool calls still waiting for their result, by toolUseId, with the
   *  tool name a result carries none of. Emptied as results arrive, so what
   *  remains when a turn ends is exactly what never got an answer. */
  openCalls: Map<string, string>
  /** The last list written to the Host to-do dock, so an unchanged one is not rewritten. */
  todoSnapshot?: string
  /** Auto-background timers of the root Bash calls still running, by toolUseId. */
  backgroundTimers: Map<string, ReturnType<typeof setTimeout>>
  signal?: AbortSignal
  abortListener?: () => void
}

interface SupervisorEntry {
  sessionId: string
  ownerAgent: Agent
  /** Set when the plugin ends the process itself, naming the caller's cause. */
  disposeReason?: string
  cwd: string
  model: string
  thinkingMode: ClaudeThinkingMode | undefined
  permissionMode: PermissionMode
  state: ClaudeSupervisorState
  lastUsedAt: number
  input: AsyncQueue<SDKUserMessage>
  query: Query
  /** Official SDK initialization control request; no stdin nudge is required. */
  sdkInitialization: Promise<void>
  lifetime: AbortController
  process: ManagedClaudeProcess | undefined
  claudeSessionId: string | undefined
  active: ActiveTurn | undefined
  idleTimer: ReturnType<typeof setTimeout> | undefined
  /** Whether the message stream has emitted system/init for session binding. */
  initialized: boolean
  expectedResume: string | undefined
  /** Newest main-chain entry uuid Claude emitted; the anchor a rewind of the
   *  next turn forks at. Sidechain (subagent) entries are not chain entries. */
  lastChainUuid: string | undefined
  /** Whether this process consumed an armed rewind fork target at spawn. */
  consumedRewind: boolean
  /** SDK message types this process has already reported as unknown, so a type
   *  that arrives in a batch leaves one row of evidence instead of one per
   *  frame. A later process records its own first sighting. */
  reportedUnknownTypes: Set<string>
  /** Live Claude task board (subagents and background tasks), keyed by task id. */
  tasks: Map<string, ClaudeTaskInfo>
  /** Claude's task-tool list (TaskCreate / TaskUpdate), mirrored into the Host to-do dock. */
  taskBoard: ClaudeTaskBoard
  /** Last time a task snapshot was persisted (progress throttling). */
  taskSnapshotAt: number
  /** Pending throttled snapshot flush timer. */
  taskSnapshotTimer: ReturnType<typeof setTimeout> | undefined
  /** Newest `cumulativeCostUsd` this process reported. The counter belongs to
   *  one `query()` call, so each process starts its own from zero. */
  costReading: number
  pump: Promise<void>
}

function abortFailure(): Error {
  const error = new Error('Claude Code turn aborted')
  error.name = 'AbortError'
  return error
}

function signalAborted(signal: AbortSignal | undefined): boolean {
  return signal?.aborted === true
}

interface TurnAdmission {
  request: ClaudeTurnRequest
  resolve: (output: AsyncIterable<ClaudeTurnStreamEvent>) => void
  reject: (error: unknown) => void
  delivered: boolean
  admitting: boolean
  waitedForCapacity: boolean
  cancellation: AbortController
  completion: Promise<void>
  complete: () => void
  abortListener?: () => void
}

interface MetadataAdmission {
  sessionId: string
  cancellation: AbortController
  started: boolean
  completion: Promise<void>
  complete: () => void
}

async function withTimeout<T>(operation: Promise<T>, timeoutMs: number, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined
  try {
    return await Promise.race([
      operation,
      new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => reject(new Error(`${label} timed out after ${timeoutMs}ms`)), timeoutMs)
        timer.unref?.()
      }),
    ])
  } finally {
    if (timer !== undefined) clearTimeout(timer)
  }
}

async function withAbort<T>(operation: Promise<T>, signal: AbortSignal | undefined): Promise<T> {
  if (signal === undefined) return operation
  if (signal.aborted) throw abortFailure()
  let abortListener: (() => void) | undefined
  try {
    return await Promise.race([
      operation,
      new Promise<never>((_resolve, reject) => {
        abortListener = () => { reject(abortFailure()) }
        signal.addEventListener('abort', abortListener, { once: true })
      }),
    ])
  } finally {
    if (abortListener !== undefined) signal.removeEventListener('abort', abortListener)
  }
}

/** The uuid of one main-chain transcript entry, or undefined for anything a
 *  rewind must not fork at: stream partials, results, and sidechain traffic. */
function chainEntryUuid(message: SDKMessage): string | undefined {
  if (message.type !== 'assistant' && message.type !== 'user') return undefined
  const envelope = message as { uuid?: unknown; parent_tool_use_id?: unknown }
  if (typeof envelope.parent_tool_use_id === 'string') return undefined
  return typeof envelope.uuid === 'string' && envelope.uuid.length > 0 ? envelope.uuid : undefined
}

/** The reader's own words out of a steered prompt, for the row that shows it. */
function steeredText(prompt: SDKUserMessage['message']['content']): string {
  if (typeof prompt === 'string') return prompt
  return prompt
    .filter((block): block is Extract<typeof block, { type: 'text' }> => block.type === 'text')
    .map(block => block.text)
    .join('\n')
}

function sdkUserMessage(prompt: SDKUserMessage['message']['content'], uuid: ReturnType<typeof randomUUID>): SDKUserMessage {
  return {
    type: 'user',
    message: { role: 'user', content: prompt },
    parent_tool_use_id: null,
    uuid,
  }
}

const BACKGROUND_TASK_REPORT_PROMPT = [
  'The background tasks launched by your preceding response have now all settled.',
  'Report their final completed or failed outcomes concisely to the user.',
  'Do not start new tools or tasks, and do not repeat the earlier progress update.',
].join(' ')

function usageSummary(usage: ClaudeUsage): string {
  const input = usage.inputTokens ?? 0
  const output = usage.outputTokens ?? 0
  const cost = usage.cumulativeCostUsd === undefined
    ? ''
    : ` · $${usage.cumulativeCostUsd.toFixed(4)} cumulative`
  return `${input} input / ${output} output tokens${cost}`
}

function errorSummary(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

/** How the CLI process ended, in words a reader can act on.
 *
 *  Without this the transcript can only say that a turn's outcome is unknown,
 *  which is true and useless: an exit code is the CLI saying it finished, a
 *  signal is something else ending it, and `killedByPlugin` says whether that
 *  something was this plugin's own teardown. The status is captured by
 *  {@link ManagedClaudeProcess} either way — it was simply never read. */
function exitStatus(process: ManagedClaudeProcess | undefined, reason?: string): string {
  if (process === undefined) return 'no process was running'
  const signal = process.signalCode
  const code = process.exitCode
  const parts: string[] = []
  if (signal !== null) parts.push(`killed by ${signal}`)
  if (code !== null) parts.push(`exit code ${code}`)
  const requested = reason === undefined ? 'requested by this plugin' : `requested by this plugin: ${reason}`
  if (parts.length === 0) parts.push(process.killed ? requested.replace('requested', 'terminated') : 'no exit status was reported')
  else if (process.killed) parts.push(requested)
  return parts.join(', ')
}

/** Root-call activity summary; subagent dispatches lead with Claude's own task description. */
function rootCallSummary(toolName: string, input: unknown): string {
  if (TASK_TOOL_NAMES.has(toolName)) {
    const description = input !== null && typeof input === 'object'
      ? (input as Record<string, unknown>).description
      : undefined
    if (typeof description === 'string' && description.length > 0) return description
    return 'Claude dispatched a subagent'
  }
  return `Claude called ${toolName}`
}

/** Records the plugin draws even under the native renderer: Claude's root tool
 *  cards, their results and denials, and the subagent calls nested in them. */
function pluginDrawnUnderNative(activity: ClaudeActivityInput): boolean {
  return activity.kind === 'tool-call'
    || activity.kind === 'tool-result'
    || (activity.kind === 'permission' && activity.toolUseId !== undefined)
    || (activity.kind === 'subagent' && activity.parentToolUseId !== undefined)
}

export class ClaudeSupervisor {
  readonly #entries = new Map<string, SupervisorEntry>()
  readonly #interruptions = new Map<string, Promise<void>>()
  readonly #runtime: Pick<SubprocessRuntime, 'spawn' | 'resolveExecutable'>
  readonly #approval: Pick<ApprovalService, 'request'>
  readonly #userQuestions: Pick<UserQuestionService, 'ask'>
  /** Lets the plan panel answer a plan's approval with revisions. */
  readonly planFeedback = new PlanFeedbackGate()
  readonly #config: ClaudeSupervisorConfig
  readonly #queryFactory: ClaudeQueryFactory
  readonly #runDetached: <T>(operation: () => T) => T
  readonly #sidecar: ClaudeSidecarRepository
  readonly #defaultPermissionMode: () => Promise<ClaudePermissionMode | undefined>
  readonly #permissionSelector: () => Promise<ClaudePermissionSelector>
  /** Where a process death is reported. The transcript keeps the failure; this
   *  is what makes it findable afterwards. */
  readonly #logger: { warn(message: string): void } | undefined
  readonly #hostJobs: ClaudeHostJobs | undefined
  readonly #contextWindows = new Map<string, number>()
  #disposed = false
  #admissionGate: Promise<void> = Promise.resolve()
  /** FIFO user turns live outside the gate while capacity-blocked, so
   *  best-effort metadata can still enter the serialized path and fail. */
  readonly #turnAdmissions: TurnAdmission[] = []
  readonly #metadataAdmissions = new Set<MetadataAdmission>()
  #admissionDrainScheduled = false
  /** Prevent a capacity change between a failed attempt and parking the head
   *  from becoming a lost wake-up. */
  #admissionRevision = 0
  #blockedAdmissionRevision: number | undefined

  constructor(dependencies: {
    runtime: Pick<SubprocessRuntime, 'spawn' | 'resolveExecutable'>
    approval: Pick<ApprovalService, 'request'>
    userQuestions: Pick<UserQuestionService, 'ask'>
    config: ClaudeSupervisorConfig
    queryFactory?: ClaudeQueryFactory
    runDetached?: <T>(operation: () => T) => T
    sidecar?: ClaudeSidecarRepository
    /** The mode a session runs under until it chooses one; absent, the DSH
     *  sandbox alone decides (see permission-mode.ts). */
    defaultPermissionMode?: () => Promise<ClaudePermissionMode | undefined>
    /** Which access control the session obeys; `native` ignores both the
     *  session's recorded choice and the default and reads the sandbox alone. */
    permissionSelector?: () => Promise<ClaudePermissionSelector>
    /** Where a process death is reported. The transcript keeps the failure;
     *  this is what makes it findable afterwards. */
    logger?: { warn(message: string): void }
    /** Mirror of detached tasks into the Host's background-job list. */
    hostJobs?: ClaudeHostJobs
  }) {
    this.#runtime = dependencies.runtime
    this.#approval = dependencies.approval
    this.#userQuestions = dependencies.userQuestions
    this.#config = dependencies.config
    this.#queryFactory = dependencies.queryFactory ?? (params => claudeQuery(params))
    this.#runDetached = dependencies.runDetached ?? (operation => operation())
    this.#sidecar = dependencies.sidecar ?? new ClaudeSidecarRepository()
    this.#defaultPermissionMode = dependencies.defaultPermissionMode ?? (async () => undefined)
    this.#permissionSelector = dependencies.permissionSelector ?? (async () => 'plugin')
    this.#logger = dependencies.logger
    this.#hostJobs = dependencies.hostJobs
  }

  snapshots(): ClaudeSupervisorSnapshot[] {
    return [...this.#entries.values()].map(entry => ({
      sessionId: entry.sessionId,
      ...(entry.claudeSessionId === undefined ? {} : { claudeSessionId: entry.claudeSessionId }),
      state: entry.state,
      cwd: entry.cwd,
      model: entry.model,
      ...(entry.thinkingMode === undefined ? {} : { thinkingMode: entry.thinkingMode }),
      lastUsedAt: entry.lastUsedAt,
    }))
  }

  supportedCommands(agent: Agent, model = this.#config.defaultModel): Promise<readonly SlashCommand[]> {
    return this.#runMetadata(agent, model, query => query.supportedCommands())
  }

  /** Cache a window under both the selector id the caller asked for and the
   *  concrete model the CLI reports, so either name resolves it later. */
  #recordContextWindow(model: string, usage: SDKControlGetContextUsageResponse): void {
    const contextWindow = usage.rawMaxTokens > 0 ? usage.rawMaxTokens : usage.maxTokens
    if (contextWindow <= 0) return
    this.#contextWindows.set(model, contextWindow)
    this.#contextWindows.set(usage.model, contextWindow)
  }

  /** Learn a model's context window the first time a turn finishes on it.
   *
   *  DSH hides its context meter entirely unless the route publishes a
   *  capacity, and these numbers move with Claude releases — so none are
   *  hardcoded; the CLI is asked over the session's own live process.
   *
   *  Turn completion is the earliest honest moment to ask. `entry.model` is
   *  already the model that just ran, so no model switch is provoked — which
   *  rules out asking from `resolveModel`, since DSH resolves every model in
   *  the catalog to build its picker and `#metadataEntry` would switch the live
   *  session once per entry. And nothing is lost by waiting: the meter needs a
   *  usage sample too, and no turn has reported one before the first turn ends.
   *
   *  Best-effort — a failure leaves the window unknown (the meter stays hidden,
   *  exactly as before) and the next completed turn tries again. */
  async #learnContextWindow(entry: SupervisorEntry): Promise<void> {
    if (this.#contextWindows.has(entry.model)) return
    try {
      const usage = await withTimeout(
        entry.query.getContextUsage(),
        CLAUDE_METADATA_TIMEOUT_MS,
        'Claude context window probe',
      )
      this.#recordContextWindow(entry.model, usage)
    } catch {
      // Intentionally silent: this is opportunistic chrome, never turn-critical.
    }
  }

  contextWindow(model: string): number | undefined {
    return this.#contextWindows.get(model)
  }

  /** Raw `/usage` payload, read over a session's existing process. Only the
   *  idle-time metadata bridge uses this; a user-triggered refresh runs
   *  probePlanUsage instead so it never waits on, or perturbs, a session. */
  planUsage(agent: Agent, model = this.#config.defaultModel): Promise<unknown> {
    return this.#runMetadata(agent, model, query => readPlanUsageFrom(query))
  }

  /** Whether a steered message can reach this session's turn right now.
   *
   *  Asked before the caller takes the message out of the agent inbox: a
   *  message removed for a turn that cannot take it would have to be put back,
   *  and a restored message has already lost the insertion that would wake an
   *  idle driver. */
  canSteer(sessionId: string): boolean {
    const entry = this.#entries.get(sessionId)
    const active = entry?.active
    if (entry === undefined || active === undefined || entry.state !== 'running' || active.aborted) return false
    return active.ownedPromptUuids.size < MAX_STEERED_PROMPTS_PER_TURN
  }

  /** Deliver one more user message into the turn a session is already running.
   *
   *  Claude Code reads a message pushed into its input stream at the next model
   *  step of the running turn, which is what steering means here: the turn is
   *  not restarted and its context is not reloaded. The turn then owns one more
   *  prompt uuid, so the result that answers the message it was already working
   *  on no longer looks like a protocol violation.
   *
   *  `unavailable` means there is no live turn to steer, and the caller must
   *  keep its message for a later turn rather than drop it. */
  deliverSteering(sessionId: string, prompt: SDKUserMessage['message']['content']): ClaudeSteeringOutcome {
    const entry = this.#entries.get(sessionId)
    const active = entry?.active
    if (entry === undefined || active === undefined || !this.canSteer(sessionId)) return 'unavailable'
    const uuid = randomUUID()
    active.ownedPromptUuids.add(uuid)
    entry.input.push(sdkUserMessage(prompt, uuid))
    // Drawn where it arrived. This turn's prose settles as one node when the
    // turn ends, so a message recorded on DSH's surface instead would sit above
    // everything the turn did — reading as the question the whole answer was
    // for. In the transcript it lands between the work before it and the work
    // after it, which is where the reader typed it.
    void this.#appendSafely(active, {
      kind: 'steering',
      phase: 'completed',
      title: 'Steered into the running turn',
      summary: steeredText(prompt),
    })
    return 'delivered'
  }

  runTurn(request: ClaudeTurnRequest): Promise<AsyncIterable<ClaudeTurnStreamEvent>> {
    const interruption = this.#interruptions.get(request.agent.id as string)
    if (interruption !== undefined) return interruption.then(() => this.runTurn(request))
    return new Promise((resolve, reject) => {
      let complete: (() => void) | undefined
      const completion = new Promise<void>(done => { complete = done })
      const admission: TurnAdmission = {
        request,
        resolve,
        reject,
        delivered: false,
        admitting: false,
        waitedForCapacity: false,
        cancellation: new AbortController(),
        completion,
        complete: () => { complete?.() },
      }
      if (request.signal !== undefined) {
        const abortListener = () => {
          if (!admission.admitting) {
            this.#finishTurnAdmission(admission, { error: abortFailure() })
          } else if (admission.waitedForCapacity && !admission.delivered) {
            admission.delivered = true
            admission.reject(abortFailure())
          }
          this.#admissionRevision += 1
          this.#blockedAdmissionRevision = undefined
          this.#scheduleTurnAdmissions()
        }
        admission.abortListener = abortListener
        request.signal.addEventListener('abort', abortListener, { once: true })
      }
      this.#turnAdmissions.push(admission)
      this.#scheduleTurnAdmissions()
    })
  }

  async #drainTurnAdmissions(): Promise<void> {
    while (this.#turnAdmissions.length > 0) {
      const admission = this.#turnAdmissions[0]!
      if (signalAborted(admission.request.signal)) {
        this.#finishTurnAdmission(admission, { error: abortFailure() })
        continue
      }
      const attemptedRevision = this.#admissionRevision
      admission.admitting = true
      try {
        const output = await this.#runTurnAdmitted(
          admission.request,
          admission.waitedForCapacity,
          admission.cancellation.signal,
        )
        this.#finishTurnAdmission(admission, { output })
      } catch (error) {
        if (
          error instanceof ClaudeProcessLimitError
          && !signalAborted(admission.request.signal)
          && !admission.cancellation.signal.aborted
          && !this.#disposed
        ) {
          admission.admitting = false
          admission.waitedForCapacity = true
          if (attemptedRevision === this.#admissionRevision) {
            this.#blockedAdmissionRevision = attemptedRevision
            return
          }
          continue
        }
        this.#finishTurnAdmission(admission, { error })
      }
    }
  }

  #finishTurnAdmission(
    admission: TurnAdmission,
    outcome: { output: AsyncIterable<ClaudeTurnStreamEvent> } | { error: unknown },
  ): void {
    if (this.#turnAdmissions[0] === admission) this.#turnAdmissions.shift()
    else {
      const index = this.#turnAdmissions.indexOf(admission)
      if (index >= 0) this.#turnAdmissions.splice(index, 1)
    }
    admission.admitting = false
    if (admission.request.signal !== undefined && admission.abortListener !== undefined) {
      admission.request.signal.removeEventListener('abort', admission.abortListener)
    }
    if (!admission.delivered) {
      admission.delivered = true
      if ('error' in outcome) admission.reject(outcome.error)
      else admission.resolve(outcome.output)
    }
    admission.complete()
  }

  #scheduleTurnAdmissions(): void {
    if (
      this.#admissionDrainScheduled
      || this.#turnAdmissions.length === 0
      || this.#blockedAdmissionRevision === this.#admissionRevision
    ) return
    this.#admissionDrainScheduled = true
    const operation = this.#admissionGate.then(() => this.#drainTurnAdmissions())
    this.#admissionGate = operation.then(() => undefined, () => undefined)
    const finished = () => {
      this.#admissionDrainScheduled = false
      this.#scheduleTurnAdmissions()
    }
    void operation.then(finished, finished)
  }

  async #runTurnAdmitted(
    request: ClaudeTurnRequest,
    abortDuringAdmission: boolean,
    cancellationSignal: AbortSignal,
  ): Promise<AsyncIterable<ClaudeTurnStreamEvent>> {
    if (this.#disposed) throw new Error('dsh-claude: supervisor is disposed')
    if (cancellationSignal.aborted) throw abortFailure()
    if (signalAborted(request.signal)) throw abortFailure()
    const sessionId = request.agent.id as string
    let entry = this.#entries.get(sessionId)
    let createdForRequest: SupervisorEntry | undefined
    const throwIfUnavailable = async (): Promise<void> => {
      const failure = this.#disposed
        ? new Error('dsh-claude: supervisor is disposed')
        : cancellationSignal.aborted || (abortDuringAdmission && signalAborted(request.signal))
          ? abortFailure()
          : undefined
      if (failure === undefined) return
      if (createdForRequest !== undefined) {
        if (this.#entries.get(sessionId) === createdForRequest) this.#entries.delete(sessionId)
        await this.#disposeEntry(createdForRequest, 'admission cancelled')
        createdForRequest = undefined
      }
      throw failure
    }
    if (entry?.state === 'disposed' || entry?.state === 'disconnected' || entry?.state === 'outcome-unknown') {
      this.#entries.delete(sessionId)
      await this.#disposeEntry(entry, 'stale process replaced')
      await throwIfUnavailable()
      entry = undefined
    }
    if (entry === undefined) {
      await this.#makeRoom()
      await throwIfUnavailable()
      try {
        entry = await this.#createEntry(
          request.agent,
          request.model ?? this.#config.defaultModel,
          request.thinkingMode,
          abortDuringAdmission ? request.signal : undefined,
          cancellationSignal,
        )
      } catch (error) {
        await throwIfUnavailable()
        throw error
      }
      createdForRequest = entry
      await throwIfUnavailable()
      this.#entries.set(sessionId, entry)
    }
    if (entry.ownerAgent !== request.agent) {
      throw new Error(`dsh-claude: live agent identity changed for session ${sessionId}`)
    }
    if (entry.active !== undefined || entry.state === 'interrupting') throw new ClaudeTurnBusyError(sessionId)
    try {
      const initialization = withAbort(entry.sdkInitialization, cancellationSignal)
      await (abortDuringAdmission ? withAbort(initialization, request.signal) : initialization)
    } catch (error) {
      await throwIfUnavailable()
      throw error
    }
    await throwIfUnavailable()

    if (entry.idleTimer !== undefined) {
      clearTimeout(entry.idleTimer)
      entry.idleTimer = undefined
    }
    const model = request.model ?? this.#config.defaultModel
    const mode = request.thinkingMode
    const effort = liveEffortSettings(mode)
    // Moving between effort levels is one control request, so the process — and
    // the context it holds — survives a change of effort. Everything else is a
    // start-time shape the SDK will not take later, and a live setModel is not
    // enough for the model either: the CLI freezes its system prompt (including
    // the "you are powered by" line) at the first context-usage request, which
    // the context-window probe issues after a process's first turn, so a switched session
    // answers as the old model. Those rebuild the query; the persisted Claude
    // session binding keeps the context.
    // A changed model rebuilds the process regardless, so the control request
    // would be spent on a process that is about to be torn down.
    const switchedLive = mode !== entry.thinkingMode && mode !== undefined && effort !== undefined && model === entry.model
      ? await this.#switchEffort(entry, mode, effort)
      : false
    if (model !== entry.model || (mode !== entry.thinkingMode && !switchedLive)) {
      this.#entries.delete(sessionId)
      await this.#disposeEntry(entry, 'model or effort switch')
      if (createdForRequest === entry) createdForRequest = undefined
      await throwIfUnavailable()
      try {
        entry = await this.#createEntry(
          request.agent,
          model,
          request.thinkingMode,
          abortDuringAdmission ? request.signal : undefined,
          cancellationSignal,
        )
      } catch (error) {
        await throwIfUnavailable()
        throw error
      }
      createdForRequest = entry
      await throwIfUnavailable()
      this.#entries.set(sessionId, entry)
      try {
        const initialization = withAbort(entry.sdkInitialization, cancellationSignal)
        await (abortDuringAdmission ? withAbort(initialization, request.signal) : initialization)
      } catch (error) {
        await throwIfUnavailable()
        throw error
      }
    } else {
      await this.#syncPermissionMode(entry)
    }
    await throwIfUnavailable()

    const promptUuid = randomUUID()
    const cursor = currentClaudeActivityCursor(request.agent.session.snapshotEvents())
    const projection = await this.#sidecar.read(sessionId)
    await throwIfUnavailable()
    cursor.nextOrdinal = projection.activities.reduce((next, activity) => (
      activity.turn === cursor.turn && activity.step === cursor.step
        ? Math.max(next, activity.ordinal + 1)
        : next
    ), 0)
    const active: ActiveTurn = {
      agent: request.agent,
      cursor,
      native: (request.renderMode ?? this.#config.renderMode ?? DEFAULT_CLAUDE_RENDER_MODE) === 'native',
      output: new AsyncQueue<ClaudeTurnStreamEvent>(),
      promptUuid,
      ownedPromptUuids: new Set([promptUuid]),
      phase: 'primary',
      sawActivity: false,
      sawTextDelta: false,
      subagentText: new Map(),
      text: '',
      transcriptText: '',
      transcriptTextOrdinal: undefined,
      thinking: '',
      requestUsage: undefined,
      startedAt: Date.now(),
      firstOutputAt: undefined,
      aborted: false,
      deniedToolUseIds: new Set(),
      openCalls: new Map(),
      backgroundTimers: new Map(),
      ...(request.signal === undefined ? {} : { signal: request.signal }),
    }
    entry.active = active
    entry.state = 'running'
    entry.lastUsedAt = Date.now()
    // The guess was at this prompt; it has been answered.
    await this.#sidecar.writePromptSuggestion(sessionId, undefined).catch(() => undefined)
    await this.#captureWorktree(entry, cursor.turn)
    try {
      await this.#appendActivity(active, {
        kind: 'status',
        phase: 'started',
        title: 'Claude Code turn started',
      })
    } catch (error) {
      active.output.fail(error)
      entry.active = undefined
      if (this.#entries.get(sessionId) === entry) this.#entries.delete(sessionId)
      await this.#disposeEntry(entry, 'turn start failed')
      throw error
    }
    // The Host's to-do projection empties at every turn/start; a list Claude is
    // still working through carries over rather than vanishing until its next
    // update.
    const carried = carriedTodos(request.agent.session.snapshotEvents())
    if (carried !== undefined) await this.#writeTodos(active, carried)
    if (signalAborted(request.signal)) {
      active.aborted = true
      active.output.fail(abortFailure())
      await this.#appendActivity(active, {
        kind: 'status',
        phase: 'failed',
        title: 'Claude Code turn cancelled before submission',
      })
      entry.active = undefined
      if (!abortDuringAdmission || createdForRequest === undefined) {
        entry.state = 'idle'
        entry.lastUsedAt = Date.now()
        this.#armIdleTimer(entry)
      }
      await throwIfUnavailable()
      return active.output
    }
    if (request.signal !== undefined) {
      const abortListener = () => { void this.#startInterrupt(entry as SupervisorEntry) }
      active.abortListener = abortListener
      request.signal.addEventListener('abort', abortListener, { once: true })
    }
    entry.input.push(sdkUserMessage(request.prompt, promptUuid))
    return active.output
  }

  #runMetadata<T>(
    agent: Agent,
    model: string,
    operation: (query: Query, entry: SupervisorEntry) => Promise<T>,
  ): Promise<T> {
    if (this.#turnAdmissions.some(admission => admission.waitedForCapacity)) {
      return Promise.reject(new ClaudeProcessLimitError(this.#config.maxProcesses))
    }
    let complete: (() => void) | undefined
    const admission: MetadataAdmission = {
      sessionId: agent.id as string,
      cancellation: new AbortController(),
      started: false,
      completion: new Promise<void>(done => { complete = done }),
      complete: () => { complete?.() },
    }
    this.#metadataAdmissions.add(admission)
    const admitted = this.#admissionGate.then(async () => {
      admission.started = true
      if (this.#disposed) throw new Error('dsh-claude: supervisor is disposed')
      if (admission.cancellation.signal.aborted) throw abortFailure()
      if (this.#turnAdmissions.some(admission => admission.waitedForCapacity)) {
        throw new ClaudeProcessLimitError(this.#config.maxProcesses)
      }
      const entry = await this.#metadataEntry(agent, model, admission.cancellation.signal)
      try {
        // Use the SDK's initialize control request. system/init is emitted only
        // after the first real stdin message and is reserved for session binding.
        await withAbort(entry.sdkInitialization, admission.cancellation.signal)
        return await withAbort(
          this.#control(entry, operation(entry.query, entry), 'Claude metadata request'),
          admission.cancellation.signal,
        )
      } finally {
        entry.lastUsedAt = Date.now()
        if (entry.active === undefined && entry.state === 'idle') this.#armIdleTimer(entry)
      }
    }).finally(() => { this.#finishMetadataAdmission(admission) })
    this.#admissionGate = admitted.then(() => undefined, () => undefined)
    return withAbort(admitted, admission.cancellation.signal)
  }

  async #metadataEntry(
    agent: Agent,
    model: string,
    cancellationSignal: AbortSignal,
  ): Promise<SupervisorEntry> {
    if (cancellationSignal.aborted) throw abortFailure()
    const sessionId = agent.id as string
    let entry = this.#entries.get(sessionId)
    if (entry?.state === 'disposed' || entry?.state === 'disconnected' || entry?.state === 'outcome-unknown') {
      this.#entries.delete(sessionId)
      await this.#disposeEntry(entry, 'stale process replaced')
      if (cancellationSignal.aborted) throw abortFailure()
      entry = undefined
    }
    if (entry === undefined) {
      await this.#makeRoom()
      if (cancellationSignal.aborted) throw abortFailure()
      entry = await this.#createEntry(agent, model, undefined, undefined, cancellationSignal)
      if (cancellationSignal.aborted) {
        await this.#disposeEntry(entry, 'metadata request cancelled')
        throw abortFailure()
      }
      this.#entries.set(sessionId, entry)
    }
    if (entry.ownerAgent !== agent) {
      throw new Error(`dsh-claude: live agent identity changed for session ${sessionId}`)
    }
    if (entry.active !== undefined || entry.state === 'interrupting') throw new ClaudeTurnBusyError(sessionId)
    if (entry.idleTimer !== undefined) {
      clearTimeout(entry.idleTimer)
      entry.idleTimer = undefined
    }
    await withAbort(this.#syncPermissionMode(entry), cancellationSignal)
    if (cancellationSignal.aborted) throw abortFailure()
    // Never switch a live entry here: `model` is only the seed for a fresh
    // process. The idle metadata refresh runs with the plugin default, and
    // letting it call setModel raced runTurn's own switch -- a session the user
    // set to Fable answered on Opus whenever the refresh landed last.
    return entry
  }

  /** Run one SDK control request against a live entry, and discard the entry if
   *  it does not answer.
   *
   *  Turn admission attempts and metadata reads share one process-wide gate,
   *  so an unbounded control request stalls every session until the Host restarts.
   *  Bounding it is only half the cure: a timeout also proves this query has
   *  stopped answering, and keeping the entry means the next caller reuses the
   *  same dead process — timing out again, forever. Discarding it lets the next
   *  attempt spawn a fresh one. Every control request goes through here so a
   *  new call site cannot quietly reintroduce either half. */
  async #control<T>(
    entry: SupervisorEntry,
    operation: Promise<T>,
    label: string,
    timeoutMs = CLAUDE_METADATA_TIMEOUT_MS,
  ): Promise<T> {
    try {
      return await withTimeout(operation, timeoutMs, label)
    } catch (error) {
      // A turn in flight is the one thing the discard must not take with it:
      // a metadata refresh that lands while the CLI is busy (hooks, MCP
      // start-up) times out without meaning the process is dead. Only an
      // idle process that stopped answering is thrown away; a live turn's
      // wedge still ends through the composer's own Stop.
      if (entry.active === undefined) {
        if (this.#entries.get(entry.sessionId) === entry) this.#entries.delete(entry.sessionId)
        await this.#disposeEntry(entry, 'control request timed out')
      } else {
        this.#logger?.warn(`dsh-claude: ${label} timed out during a live turn on session ${entry.sessionId}; keeping the process`)
      }
      throw error
    }
  }

  /** The mode a turn runs under: the session's choice, else the configured
   *  default, folded against the DSH sandbox; and `auto` only on a model the
   *  catalog does not rule out, since the CLI refuses it elsewhere. */
  async #permissionModeFor(
    events: readonly { type: string; data: unknown }[],
    chosen: ClaudePermissionMode | undefined,
    model: string,
  ): Promise<ClaudePermissionMode> {
    const native = (await this.#permissionSelector()) === 'native'
    const mode = claudePermissionMode(events, native ? undefined : chosen ?? await this.#defaultPermissionMode())
    return mode === 'auto' && claudeModelRow(model)?.supportsAutoMode === false ? 'default' : mode
  }

  async #syncPermissionMode(entry: SupervisorEntry): Promise<void> {
    const projection = await this.#sidecar.read(entry.sessionId)
    const mode = await this.#permissionModeFor(entry.ownerAgent.session.snapshotEvents(), projection.permissionMode, entry.model)
    if (mode === entry.permissionMode) return
    await this.#control(entry, entry.query.setPermissionMode(mode), 'Claude Code permission mode switch')
    entry.permissionMode = mode
  }

  /** Move a running process to another effort level.
   *
   *  Returns false when the CLI would not take the change — the caller then
   *  rebuilds the process, which is what every mode change did before this.
   *  A failed control request has already discarded the entry. */
  async #switchEffort(entry: SupervisorEntry, mode: ClaudeThinkingMode, settings: ClaudeFlagSettings): Promise<boolean> {
    try {
      await this.#control(entry, entry.query.applyFlagSettings(settings), 'Claude effort switch')
      entry.thinkingMode = mode
      return true
    } catch {
      return false
    }
  }

  #finishMetadataAdmission(admission: MetadataAdmission): void {
    this.#metadataAdmissions.delete(admission)
    admission.complete()
  }

  #cancelMetadataAdmissions(
    predicate: (admission: MetadataAdmission) => boolean,
  ): Promise<void>[] {
    const cancelled = [...this.#metadataAdmissions].filter(predicate)
    for (const admission of cancelled) {
      admission.cancellation.abort()
      if (!admission.started) this.#finishMetadataAdmission(admission)
    }
    return cancelled.map(admission => admission.completion)
  }

  #cancelTurnAdmissions(
    predicate: (admission: TurnAdmission) => boolean,
    error: Error,
  ): Promise<void>[] {
    const cancelled = this.#turnAdmissions.filter(predicate)
    for (const admission of cancelled) {
      admission.cancellation.abort()
      if (!admission.delivered) {
        admission.delivered = true
        admission.reject(error)
      }
      if (!admission.admitting) this.#finishTurnAdmission(admission, { error })
    }
    if (cancelled.length > 0) {
      this.#admissionRevision += 1
      this.#blockedAdmissionRevision = undefined
      this.#scheduleTurnAdmissions()
    }
    return cancelled.map(admission => admission.completion)
  }

  limitsChanged(): void {
    if (this.#disposed) return
    this.#notifyCapacityChange()
    this.#scheduleLimitReconciliation()
  }

  async disposeSession(sessionId: string, reason = 'session reset'): Promise<void> {
    const pendingAdmissions = this.#cancelTurnAdmissions(
      admission => (admission.request.agent.id as string) === sessionId,
      abortFailure(),
    )
    const pendingMetadata = this.#cancelMetadataAdmissions(
      admission => admission.sessionId === sessionId,
    )
    const entry = this.#entries.get(sessionId)
    if (entry !== undefined) this.#entries.delete(sessionId)
    await Promise.allSettled([
      ...pendingAdmissions,
      ...pendingMetadata,
      ...(entry === undefined ? [] : [this.#disposeEntry(entry, reason)]),
    ])
  }

  async dispose(): Promise<void> {
    if (this.#disposed) return
    this.#disposed = true
    const pendingAdmissions = this.#cancelTurnAdmissions(
      () => true,
      new Error('dsh-claude: supervisor is disposed'),
    )
    const pendingMetadata = this.#cancelMetadataAdmissions(() => true)
    const entries = [...this.#entries.values()]
    this.#entries.clear()
    this.#notifyCapacityChange()
    await Promise.allSettled([
      ...pendingAdmissions,
      ...pendingMetadata,
      ...entries.map(entry => this.#disposeEntry(entry, 'plugin unloaded')),
    ])
  }

  async #makeRoom(): Promise<void> {
    while (this.#entries.size >= this.#config.maxProcesses) {
      const idle = [...this.#entries.values()]
        .filter(entry => entry.active === undefined && entry.state === 'idle')
        .sort((left, right) => left.lastUsedAt - right.lastUsedAt)[0]
      if (idle === undefined) throw new ClaudeProcessLimitError(this.#config.maxProcesses)
      this.#entries.delete(idle.sessionId)
      await this.#disposeEntry(idle, 'process limit reached')
    }
  }

  async #trimExcessIdle(): Promise<void> {
    while (this.#entries.size > this.#config.maxProcesses) {
      const idle = [...this.#entries.values()]
        .filter(entry => entry.active === undefined && entry.state === 'idle')
        .sort((left, right) => left.lastUsedAt - right.lastUsedAt)[0]
      if (idle === undefined) return
      this.#entries.delete(idle.sessionId)
      await this.#disposeEntry(idle, 'process limit lowered')
    }
  }

  #notifyCapacityChange(): void {
    this.#admissionRevision += 1
    this.#blockedAdmissionRevision = undefined
    this.#scheduleTurnAdmissions()
  }

  #scheduleLimitReconciliation(): void {
    const operation = this.#admissionGate.then(() => this.#trimExcessIdle())
    this.#admissionGate = operation.then(() => undefined, () => undefined)
  }

  async #createEntry(
    agent: Agent,
    model: string,
    thinkingMode?: ClaudeThinkingMode,
    signal?: AbortSignal,
    cancellationSignal?: AbortSignal,
  ): Promise<SupervisorEntry> {
    const sessionId = agent.id as string
    const cwd = agent.session.header.cwd ?? process.cwd()
    const input = new AsyncQueue<SDKUserMessage>()
    const lifetime = new AbortController()
    const projection = await this.#sidecar.importLegacy(sessionId, agent.session.snapshotEvents())
    if (signalAborted(signal) || signalAborted(cancellationSignal)) throw abortFailure()
    const binding = projection.binding
    // A rewound session resumes at the kept turn's chain anchor, or drops its
    // binding entirely when the rewind discarded every turn. The truncating
    // resume may land in a different Claude session id, so the identity guard
    // stands down for exactly this spawn and re-binds from system/init.
    const pendingRewind = projection.rewind?.pending
    const forkAt = pendingRewind !== undefined && 'resumeAt' in pendingRewind ? pendingRewind.resumeAt : undefined
    const startFresh = pendingRewind !== undefined && 'fresh' in pendingRewind
    const permissionMode = await this.#permissionModeFor(agent.session.snapshotEvents(), projection.permissionMode, model)
    const entry = {
      sessionId,
      ownerAgent: agent,
      cwd,
      model,
      thinkingMode,
      permissionMode,
      state: 'starting' as ClaudeSupervisorState,
      lastUsedAt: Date.now(),
      input,
      lifetime,
      claudeSessionId: startFresh ? undefined : binding?.claudeSessionId,
      expectedResume: startFresh || forkAt !== undefined ? undefined : binding?.claudeSessionId,
      lastChainUuid: undefined,
      consumedRewind: pendingRewind !== undefined,
      reportedUnknownTypes: new Set<string>(),
      initialized: false,
      idleTimer: undefined,
      tasks: new Map<string, ClaudeTaskInfo>(),
      taskBoard: new ClaudeTaskBoard(),
      taskSnapshotAt: 0,
      taskSnapshotTimer: undefined,
      costReading: 0,
    } as SupervisorEntry

    const activeInteraction = () => {
      const active = entry.active
      return active === undefined ? undefined : {
        agent: active.agent,
        cursor: active.cursor,
        markActivity: () => { active.sawActivity = true },
        recordDenial: (toolUseId: string) => { active.deniedToolUseIds.add(toolUseId) },
        hasFullAccess: async () => {
          await this.#syncPermissionMode(entry)
          return entry.permissionMode === 'bypassPermissions'
        },
        appendActivity: (activity: ClaudeActivityInput) => this.#appendActivity(active, activity),
      }
    }
    const userQuestion = createUserQuestionBridge(this.#userQuestions, activeInteraction)
    const canUseTool = createPermissionBridge(this.#approval, activeInteraction, userQuestion, this.planFeedback)
    const options: ClaudeOptions = {
      pathToClaudeCodeExecutable: this.#config.executablePath,
      cwd,
      settingSources: ['user', 'project', 'local'],
      systemPrompt: { type: 'preset', preset: 'claude_code', append: SYSTEM_PROMPT_APPEND },
      tools: { type: 'preset', preset: 'claude_code' },
      includePartialMessages: true,
      // The Host job list renders a per-task stop control (see host-jobs.ts).
      perTaskStopAffordance: true,
      // Subagent prose reaches the sidecar under its parent call, so a teammate
      // tab can draw the conversation, not just the tool cards.
      forwardSubagentText: true,
      // The composer offers the CLI's guess at the next prompt as ghost text.
      promptSuggestions: true,
      permissionMode,
      allowDangerouslySkipPermissions: true,
      canUseTool,
      hooks: createAutoModeEscalation(),
      abortController: lifetime,
      spawnClaudeCodeProcess: createManagedClaudeSpawner(this.#runtime, this.#config.executablePath, process => {
        entry.process = process
      }),
      ...(binding === undefined || startFresh ? {} : {
        resume: binding.claudeSessionId,
        ...(forkAt === undefined ? {} : { resumeSessionAt: forkAt }),
      }),
      // `model` is the selector alias DSH persists; the CLI is given the id
      // that alias currently stands for.
      model: claudeModelValue(model),
      ...(thinkingMode === undefined
        ? {}
        : thinkingMode === 'off'
          ? { thinking: { type: 'disabled' } as const }
          : thinkingMode === 'ultracode'
            ? {}
            : { effort: thinkingMode }),
      // Teammates run inside the CLI process: Desktop has no terminal to put
      // them in, and the team UI reads them off the task stream.
      settings: { teammateMode: 'in-process', ...(thinkingMode === 'ultracode' ? { ultracode: true } : {}) } satisfies ClaudeSettings,
    }
    entry.query = this.#queryFactory({ prompt: input, options })
    entry.pump = this.#runDetached(() => this.#pump(entry))
    entry.sdkInitialization = withTimeout(
      entry.query.initializationResult(),
      CLAUDE_INITIALIZATION_TIMEOUT_MS,
      'Claude SDK initialization',
    ).then((initialization) => {
      // The CLI's own /model lineup rides along on initialize, so the selector
      // tracks whatever Claude Code ships without a table in this plugin and
      // without a control request of its own.
      recordClaudeModels(initialization.models)
      if (entry.state === 'starting') entry.state = 'idle'
    })
    void entry.sdkInitialization.catch(error => this.#handleDisconnect(entry, error))
    return entry
  }

  async #pump(entry: SupervisorEntry): Promise<void> {
    try {
      for await (const sdkMessage of entry.query) {
        const chainUuid = chainEntryUuid(sdkMessage as SDKMessage)
        if (chainUuid !== undefined) entry.lastChainUuid = chainUuid
        for (const message of normalizeSdkMessage(sdkMessage as SDKMessage)) {
          await this.#handleMessage(entry, message)
        }
      }
      if (entry.state !== 'disposed') await this.#handleDisconnect(entry, new Error('Claude Code stream ended'))
    } catch (error) {
      if (entry.state !== 'disposed') await this.#handleDisconnect(entry, error)
    }
  }

  async #handleMessage(entry: SupervisorEntry, message: NormalizedSdkMessage): Promise<void> {
    if (message.kind === 'init') {
      // system/init is per-turn metadata in streaming-input mode. After the
      // first init binds this Query, refreshes must retain that session identity,
      // including when a rewind allowed the first init to establish a new id.
      const firstInitialization = !entry.initialized
      const expectedSessionId = firstInitialization ? entry.expectedResume : entry.claudeSessionId
      if (expectedSessionId !== undefined && message.sessionId !== expectedSessionId) {
        throw new ClaudeProtocolError(`Claude Code initialized unexpected session ${message.sessionId}; expected ${expectedSessionId}`)
      }
      // Only the first fresh init validates the launch cwd. Later turns and
      // ordinary resumes report Claude's current shell cwd after Bash `cd`,
      // not the immutable DSH launch directory; their identity is checked above.
      if (firstInitialization && entry.expectedResume === undefined && message.cwd !== entry.cwd) {
        throw new ClaudeProtocolError(`Claude Code initialized in unexpected cwd ${message.cwd}; expected ${entry.cwd}`)
      }
      entry.initialized = true
      entry.claudeSessionId = message.sessionId
      entry.state = entry.active === undefined ? 'idle' : 'running'
      // A newly created Query cannot retain tasks from the previous process,
      // but repeated init messages from this same long-lived Query are only
      // protocol refreshes and must not erase background work still running.
      if (firstInitialization && entry.tasks.size > 0) {
        entry.tasks.clear()
        await this.#flushTasksSnapshot(entry)
      }
      await this.#sidecar.writeBinding(entry.sessionId, {
        claudeSessionId: message.sessionId,
        cliVersion: message.cliVersion,
        cwd: message.cwd,
      })
      // The fork target is spent the moment Claude resumes at it; leaving it
      // armed would re-truncate the session on the next respawn.
      if (entry.consumedRewind) {
        entry.consumedRewind = false
        await this.#sidecar.clearRewindPending(entry.sessionId)
      }
      return
    }

    // Task lifecycle is session-scoped, not turn-scoped: background tasks and
    // subagents settle while no DSH turn is active, and their notifications
    // must still reach the task board instead of being dropped with turn-less
    // messages below.
    const taskId = message.kind === 'subagent' ? message.taskId : undefined
    if (message.kind === 'tool-result') this.#hostJobs?.noteOutput(entry.sessionId, [message.output, message.content])
    if (message.kind === 'subagent' && taskId !== undefined) {
      await this.#trackTask(entry, message, taskId, entry.active?.cursor.turn)
    } else if (message.kind === 'background-tasks') {
      await this.#trackBackgroundLevel(entry, message.tasks, entry.active?.cursor.turn)
    }

    // Arrives after `result`, once the turn has closed. One that lands after
    // the next turn already started guessed at a prompt the user has sent.
    if (message.kind === 'prompt-suggestion') {
      if (entry.active === undefined) await this.#sidecar.writePromptSuggestion(entry.sessionId, message.text).catch(() => undefined)
      return
    }

    const active = entry.active
    if (active === undefined) return
    if (message.kind === 'result') {
      if (entry.claudeSessionId === undefined) {
        throw new ClaudeProtocolError('Claude Code sent a result before initialization')
      }
      if (message.sessionId !== entry.claudeSessionId) {
        throw new ClaudeProtocolError(`Claude Code result session ${message.sessionId} does not match ${entry.claudeSessionId}`)
      }
      if (active.phase === 'waiting-tasks') {
        // The CLI may automatically react to each completed background task and
        // emit a top-level result, correlated or not. Publish that prose as a
        // completed progress block, but keep the original DSH turn open until
        // every owned task settles and the explicit final report returns.
        await this.#completeProgressSegment(active, message)
        return
      }
      if (message.userMessageUuid !== undefined && !active.ownedPromptUuids.has(message.userMessageUuid)) {
        if (active.phase === 'follow-up') {
          // The CLI reacts to the last task notification on its own, and a
          // report prompt that lands mid-reaction is folded into that turn
          // (stream-json steering), so this foreign result carries the report.
          // Only a send the CLI still has queued means another result follows.
          // ponytail: a prompt the CLI had not read yet runs an orphan turn
          // whose text is dropped; pull it back if that ever shows up.
          if ((message.queuedTurnCount ?? 0) > 0) {
            await this.#completeProgressSegment(active, message)
            return
          }
          await this.#completeTurn(entry, active, message)
          return
        }
        // Primary-turn mismatches remain protocol failures.
        throw new ClaudeProtocolError(`Claude Code result for user message ${message.userMessageUuid} does not match active request ${active.promptUuid}`)
      }
      // A steered send the CLI had not reached when it produced this result is
      // still to come. Publish what this result said and keep the turn open:
      // the queued send's own result ends it.
      if ((message.queuedTurnCount ?? 0) > 0) {
        await this.#completeProgressSegment(active, message)
        return
      }
      await this.#completeTurn(entry, active, message)
      return
    }
    if (message.kind === 'protocol-error') {
      throw new ClaudeProtocolError(`${message.title}: ${JSON.stringify(message.detail).slice(0, 1_000)}`)
    }
    active.sawActivity = true

    switch (message.kind) {
      case 'text-delta':
        if (message.parentToolUseId !== undefined) return
        active.sawTextDelta = true
        active.text += message.text
        active.transcriptText += message.text
        await this.#upsertTranscriptText(active)
        active.firstOutputAt ??= Date.now()
        active.output.push({ type: 'text-delta', text: message.text })
        return
      case 'assistant-text':
        if (message.parentToolUseId !== undefined) {
          if (active.subagentText.get(message.parentToolUseId) === message.text) return
          active.subagentText.set(message.parentToolUseId, message.text)
          await this.#appendActivity(active, {
            kind: 'text',
            phase: 'completed',
            parentToolUseId: message.parentToolUseId,
            text: message.text,
          })
          return
        }
        if (!active.sawTextDelta) {
          // Complete assistant text is the fallback when no partial text delta
          // streamed. Mark text-delta seen so that additional complete
          // assistant records sharing the same message.id (one per completed
          // content block) do not duplicate the text.
          active.sawTextDelta = true
          active.text += message.text
          active.transcriptText += message.text
          await this.#upsertTranscriptText(active)
          active.firstOutputAt ??= Date.now()
        active.output.push({ type: 'text-delta', text: message.text })
        }
        return
      case 'thinking':
        if (message.parentToolUseId !== undefined) return
        if (message.phase === 'updated') {
          active.thinking += message.text
          return
        }
        active.thinking = message.text
        await this.#appendActivity(active, {
          kind: 'thinking',
          phase: 'completed',
          title: 'Claude thinking',
          summary: message.text,
        })
        // The plugin transcript reads thinking off the sidecar; the native
        // renderer needs it on the stream to build a reasoning block.
        if (active.native) active.output.push({ type: 'thinking', text: message.text })
        return
      case 'tool-call':
        if (message.parentToolUseId === undefined) this.#closeTranscriptTextSegment(active)
        await this.#appendActivity(active, {
          kind: message.parentToolUseId === undefined ? 'tool-call' : 'subagent',
          phase: 'started',
          toolUseId: message.toolUseId,
          ...(message.parentToolUseId === undefined ? {} : { parentToolUseId: message.parentToolUseId }),
          toolName: message.toolName,
          title: message.toolName,
          summary: message.parentToolUseId === undefined ? rootCallSummary(message.toolName, message.input) : `Subagent called ${message.toolName}`,
          detail: message.input,
        })
        // The lead's own list, or the task board every member shares.
        if (message.toolName === 'TodoWrite' && message.parentToolUseId === undefined) {
          const todos = todosFromTodoWrite(message.input)
          if (todos !== undefined) await this.#writeTodos(active, todos)
        } else if (entry.taskBoard.call(message.toolName, message.toolUseId, message.input)) {
          await this.#writeTodos(active, entry.taskBoard.todos())
        }
        if (message.parentToolUseId === undefined) {
          active.openCalls.set(message.toolUseId, message.toolName)
          this.#armAutoBackground(entry, active, message.toolUseId, message.toolName, message.input)
        }
        return
      case 'tool-result':
        active.openCalls.delete(message.toolUseId)
        this.#disarmAutoBackground(active, message.toolUseId)
        if (entry.taskBoard.result(message.toolUseId, [message.output, message.content], message.isError)) {
          await this.#writeTodos(active, entry.taskBoard.todos())
        }
        await this.#appendActivity(active, {
          kind: message.parentToolUseId === undefined ? 'tool-result' : 'subagent',
          phase: message.isError ? 'failed' : 'completed',
          toolUseId: message.toolUseId,
          ...(message.parentToolUseId === undefined ? {} : { parentToolUseId: message.parentToolUseId }),
          title: message.isError ? 'Tool failed' : 'Tool completed',
          detail: message.output,
          isError: message.isError,
        })
        return
      case 'subagent':
        await this.#appendActivity(active, {
          kind: 'subagent',
          phase: message.phase,
          ...(message.taskId === undefined ? {} : { taskId: message.taskId }),
          title: message.title,
          summary: message.summary,
          detail: message.detail,
          isError: message.phase === 'failed',
        })
        return
      case 'request-usage': {
        // A subagent call bills against its own context, so it never stands in
        // for the main conversation's size.
        if (message.parentToolUseId !== undefined) return
        // A sample with no prompt is not a measurement: the CLI forwards
        // placeholder usage on assistant messages, and letting one land here
        // would replace the last real request with a zero. The newest real
        // sample is the prompt the Host divides by the window.
        const prompt = (message.usage.inputTokens ?? 0)
          + (message.usage.cacheReadTokens ?? 0)
          + (message.usage.cacheCreationTokens ?? 0)
        if (prompt > 0) active.requestUsage = message.usage
        return
      }
      case 'compaction':
        // Close the open prose span first: compaction sits *between* what was
        // said before and after it, never inside one text segment.
        this.#closeTranscriptTextSegment(active)
        await this.#appendActivity(active, {
          kind: 'compaction',
          phase: 'completed',
          title: 'Claude compacted the conversation',
          detail: {
            ...(message.trigger === undefined ? {} : { trigger: message.trigger }),
            ...(message.preTokens === undefined ? {} : { preTokens: message.preTokens }),
            ...(message.postTokens === undefined ? {} : { postTokens: message.postTokens }),
            ...(message.durationMs === undefined ? {} : { durationMs: message.durationMs }),
          },
        })
        return
      case 'unknown':
        // The CLI grows message types steadily, and a new one arrives in batches
        // of identical frames. One row per type is the evidence worth keeping;
        // the repetitions are noise the transcript never draws anyway.
        if (entry.reportedUnknownTypes.has(message.type)) return
        entry.reportedUnknownTypes.add(message.type)
        await this.#appendActivity(active, {
          kind: 'warning',
          phase: 'completed',
          title: message.title,
          detail: message.detail,
        })
        return
      case 'status':
      case 'warning':
        // One-shot notices (an API retry, a hook echo) have no later event to
        // close them, so they must land settled: an 'updated' phase reads as
        // still running in the transcript forever.
        await this.#appendActivity(active, {
          kind: message.kind === 'status' ? 'status' : 'warning',
          phase: 'completed',
          title: message.title,
          ...('summary' in message ? { summary: message.summary } : {}),
          ...('detail' in message ? { detail: message.detail } : {}),
        })
        return
      case 'permission-denied':
        await this.#appendActivity(active, {
          kind: 'permission',
          phase: 'denied',
          toolUseId: message.toolUseId,
          toolName: message.toolName,
          title: message.toolName,
          summary: message.summary,
        })
        return
    }
  }

  /** The turn's accounting with its wall clock attached. The transcript draws
   *  this line itself under the plugin renderer: activities carry no
   *  timestamps, so a duration it did not measure is a duration nobody has. */
  #timedUsage(active: ActiveTurn, usage: ClaudeUsage): ClaudeUsage {
    const now = Date.now()
    return {
      ...usage,
      durationMs: Math.max(0, now - active.startedAt),
      ...(active.firstOutputAt === undefined ? {} : { ttftMs: Math.max(0, active.firstOutputAt - active.startedAt) }),
    }
  }

  /** Merge one task lifecycle message into the session's task board. */
  async #trackTask(
    entry: SupervisorEntry,
    message: Extract<NormalizedSdkMessage, { kind: 'subagent' }>,
    taskId: string,
    originTurn: number | undefined,
  ): Promise<void> {
    const previous = entry.tasks.get(taskId)
    const next: ClaudeTaskInfo = {
      taskId,
      description: message.description ?? previous?.description ?? message.title,
      status: message.taskStatus ?? previous?.status ?? 'running',
    }
    const resolvedOriginTurn = previous?.originTurn ?? originTurn
    if (resolvedOriginTurn !== undefined) next.originTurn = resolvedOriginTurn
    const toolUseId = message.toolUseId ?? previous?.toolUseId
    if (toolUseId !== undefined) next.toolUseId = toolUseId
    const subagentType = message.subagentType ?? previous?.subagentType
    if (subagentType !== undefined) next.subagentType = subagentType
    const taskType = message.taskType ?? previous?.taskType
    if (taskType !== undefined) next.taskType = taskType
    const lastToolName = message.lastToolName ?? previous?.lastToolName
    if (lastToolName !== undefined) next.lastToolName = lastToolName
    const summary = message.summary ?? previous?.summary
    if (summary !== undefined) next.summary = summary
    const usage = message.usage ?? previous?.usage
    if (usage !== undefined) next.usage = usage
    if (previous?.backgrounded === true) next.backgrounded = true
    entry.tasks.set(taskId, next)
    const settled = next.status !== 'running'
    if (next.status !== 'running') {
      this.#hostJobs?.settled(entry.sessionId, taskId, next.status, message.summary, message.outputFile)
    } else if (message.phase === 'started') {
      // Detached work and subagents (long-running even in the foreground) go
      // to the Host job list; a blocking Bash call stays a tool card.
      if ((message.backgrounded === true || hostJobKind(next.taskType) === 'subagent') && message.skipTranscript !== true) {
        this.#hostJobs?.started(entry.sessionId, taskId, hostJobKind(next.taskType), next.description, () => entry.query.stopTask(taskId))
      }
    } else {
      const line = hostJobProgress(message)
      if (line !== undefined) this.#hostJobs?.progress(entry.sessionId, taskId, line)
    }
    await this.#scheduleTasksSnapshot(entry, settled)
    if (settled) await this.#continueAfterTasks(entry)
  }

  /** Fold the background-task level signal into the board (REPLACE semantics
   *  for the backgrounded flag: only the listed tasks are detached). */
  async #trackBackgroundLevel(
    entry: SupervisorEntry,
    tasks: readonly { taskId: string; taskType?: string; description: string; ambient?: true }[],
    originTurn: number | undefined,
  ): Promise<void> {
    const live = new Set(tasks.map(task => task.taskId))
    let changed = false
    for (const task of tasks) {
      if (task.ambient !== true) {
        this.#hostJobs?.started(entry.sessionId, task.taskId, hostJobKind(task.taskType), task.description, () => entry.query.stopTask(task.taskId))
      }
      const existing = entry.tasks.get(task.taskId)
      if (existing === undefined) {
        entry.tasks.set(task.taskId, {
          taskId: task.taskId,
          description: task.description,
          status: 'running',
          ...(originTurn === undefined ? {} : { originTurn }),
          ...(task.taskType === undefined ? {} : { taskType: task.taskType }),
          backgrounded: true,
        })
        changed = true
      } else if (existing.backgrounded !== true || existing.status !== 'running') {
        entry.tasks.set(task.taskId, { ...existing, status: 'running', backgrounded: true })
        changed = true
      }
    }
    for (const task of entry.tasks.values()) {
      if (task.backgrounded === true && task.status === 'running' && !live.has(task.taskId)) {
        this.#hostJobs?.removed(entry.sessionId, task.taskId)
        entry.tasks.set(task.taskId, { ...task, status: 'completed' })
        changed = true
      }
    }
    if (changed) {
      await this.#scheduleTasksSnapshot(entry, true)
      await this.#continueAfterTasks(entry)
    }
  }

  #hasRunningTasks(entry: SupervisorEntry, active: ActiveTurn): boolean {
    return [...entry.tasks.values()].some(task => (
      task.originTurn === active.cursor.turn && task.backgrounded === true && task.status === 'running'
    ))
  }

  async #continueAfterTasks(entry: SupervisorEntry): Promise<void> {
    const active = entry.active
    if (active === undefined || active.phase !== 'waiting-tasks' || this.#hasRunningTasks(entry, active)) return
    active.phase = 'follow-up'
    active.promptUuid = randomUUID()
    active.sawTextDelta = false
    active.text = ''
    this.#closeTranscriptTextSegment(active)
    active.thinking = ''
    await this.#appendSafely(active, {
      kind: 'status',
      phase: 'updated',
      title: 'Claude Code is reporting background task results',
    })
    entry.input.push(sdkUserMessage(BACKGROUND_TASK_REPORT_PROMPT, active.promptUuid))
  }

  /** Persist the task board. Settled transitions flush immediately; progress
   *  ticks throttle to one snapshot per second to bound log volume. */
  async #scheduleTasksSnapshot(entry: SupervisorEntry, immediate: boolean): Promise<void> {
    const THROTTLE_MS = 1_000
    const elapsed = Date.now() - entry.taskSnapshotAt
    if (!immediate && elapsed < THROTTLE_MS) {
      if (entry.taskSnapshotTimer === undefined) {
        entry.taskSnapshotTimer = setTimeout(() => {
          entry.taskSnapshotTimer = undefined
          void this.#flushTasksSnapshot(entry)
        }, THROTTLE_MS - elapsed)
        entry.taskSnapshotTimer.unref?.()
      }
      return
    }
    await this.#flushTasksSnapshot(entry)
  }

  async #flushTasksSnapshot(entry: SupervisorEntry): Promise<void> {
    if (entry.taskSnapshotTimer !== undefined) {
      clearTimeout(entry.taskSnapshotTimer)
      entry.taskSnapshotTimer = undefined
    }
    entry.taskSnapshotAt = Date.now()
    // Snapshot persistence is best-effort: the in-memory board stays
    // authoritative and the next change re-flushes.
    await this.#sidecar.writeTasks(entry.sessionId, [...entry.tasks.values()]).catch(() => undefined)
  }

  /** What DSH is told about token usage: newest call's prompt, whole turn's output.
   *
   *  `TokenUsage` is documented as "token accounting for ONE model call", and
   *  DSH's token meter divides `uncachedInput + cacheRead + cacheWrite` by the
   *  context window to draw context pressure. One Claude turn makes many calls
   *  and the CLI's result usage sums all of them, so reporting that sum pinned
   *  the meter at 100%: a 35-call turn reads the same prompt from cache 35
   *  times, which sums past the window without the conversation ever growing.
   *  The newest single call answers "how big is this conversation now".
   *
   *  Output is deliberately excluded from that pressure sum, so the same
   *  argument never applied to it — and taking it from the newest call reported
   *  whatever the wrap-up message happened to cost, which is a couple of tokens
   *  after a turn that wrote thousands. The turn total is the honest figure.
   *
   *  The sidecar activity keeps the whole turn total for both — that is the
   *  audit and cost record, and nothing divides it by a window. */
  #reportedUsage(
    active: ActiveTurn,
    result: Extract<NormalizedSdkMessage, { kind: 'result' }>,
  ): ClaudeUsage {
    const prompt = active.requestUsage
    if (prompt === undefined) return result.usage
    return {
      ...prompt,
      ...(result.usage.outputTokens === undefined ? {} : { outputTokens: result.usage.outputTokens }),
    }
  }

  async #completeProgressSegment(
    active: ActiveTurn,
    result: Extract<NormalizedSdkMessage, { kind: 'result' }>,
  ): Promise<void> {
    if (!active.sawTextDelta && active.text.length === 0 && result.text !== undefined) {
      active.text = result.text
      active.transcriptText = result.text
      await this.#upsertTranscriptText(active)
      active.output.push({ type: 'text-delta', text: result.text })
    }
    await this.#upsertTranscriptText(active)
    active.output.push({ type: 'segment-complete', text: active.text })
    active.sawTextDelta = false
    active.text = ''
    this.#closeTranscriptTextSegment(active)
    active.thinking = ''
  }

  /** The turn's accounting, recorded once the turn is actually over.
   *
   *  A turn that hands off to background tasks passes through the same result
   *  handling on its way to `waiting-tasks`, and recording there drew a closing
   *  total under a turn that was still running. */
  async #recordTurnUsage(
    entry: SupervisorEntry,
    active: ActiveTurn,
    result: Extract<NormalizedSdkMessage, { kind: 'result' }>,
  ): Promise<void> {
    if (result.usage.inputTokens === undefined && result.usage.outputTokens === undefined && result.usage.cumulativeCostUsd === undefined) return
    // `cumulativeCostUsd` is per query() call, and a respawned Claude process
    // starts a new one, so a session that respawned mid-conversation would
    // show a total that goes DOWN. What the session has spent is the sum of
    // what each of its processes spent.
    const cumulative = await this.#sessionCost(entry, result.usage.cumulativeCostUsd)
    const usage = cumulative === undefined ? result.usage : { ...result.usage, cumulativeCostUsd: cumulative }
    await this.#appendSafely(active, {
      kind: 'usage',
      phase: 'completed',
      title: 'Claude usage',
      summary: usageSummary(usage),
      usage: this.#timedUsage(active, usage),
    })
    active.output.push({ type: 'usage', usage: this.#reportedUsage(active, result) })
  }

  /** What each session has spent across every process it has used. */
  readonly #sessionCostTotals = new Map<string, number>()

  /** Add what this process spent since its last reading to the session total.
   *
   *  The reading is tracked per process rather than inferred from a drop in the
   *  counter, so a new process whose first turn costs more than the previous
   *  process's whole run is still counted in full. The first reading after this
   *  supervisor starts continues from the last total the sidecar recorded, so a
   *  Host restart does not reset the session either. */
  async #sessionCost(entry: SupervisorEntry, reported: number | undefined): Promise<number | undefined> {
    if (reported === undefined) return undefined
    const sessionId = entry.sessionId
    let total = this.#sessionCostTotals.get(sessionId)
    if (total === undefined) total = await this.#persistedSessionCost(sessionId)
    total += Math.max(0, reported - entry.costReading)
    entry.costReading = reported
    this.#sessionCostTotals.set(sessionId, total)
    return total
  }

  async #persistedSessionCost(sessionId: string): Promise<number> {
    try {
      const { activities } = await this.#sidecar.read(sessionId)
      for (let index = activities.length - 1; index >= 0; index -= 1) {
        const cost = activities[index]!.usage?.cumulativeCostUsd
        if (activities[index]!.kind === 'usage' && typeof cost === 'number' && Number.isFinite(cost)) return cost
      }
    } catch {
      // An unreadable projection starts the count at this process.
    }
    return 0
  }

  async #completeTurn(
    entry: SupervisorEntry,
    active: ActiveTurn,
    result: Extract<NormalizedSdkMessage, { kind: 'result' }>,
  ): Promise<void> {
    if (entry.active !== active) return
    if (active.aborted) {
      await this.#upsertTranscriptText(active)
      await this.#flushTranscript(active)
      await this.#settleOpenCalls(active, 'Cancelled with the turn')
      await this.#appendSafely(active, {
        kind: 'status',
        phase: 'failed',
        title: 'Claude Code turn cancelled',
      })
      entry.active = undefined
      entry.state = 'idle'
      entry.lastUsedAt = Date.now()
      await this.#recordChainAnchor(entry, active)
      this.#checkpointProjection(entry)
      this.#armIdleTimer(entry)
      this.#notifyCapacityChange()
      this.#scheduleLimitReconciliation()
      return
    }
    const unmatchedDenials = (result.permissionDenials ?? [])
      .filter(denial => !active.deniedToolUseIds.has(denial.toolUseId))
    if (unmatchedDenials.length > 0) {
      await this.#appendSafely(active, {
        kind: 'permission',
        phase: 'denied',
        title: 'Claude Code auto-denied tool calls',
        summary: unmatchedDenials.map(denial => denial.toolName).join(', '),
      })
    }
    if (!result.success) {
      await this.#recordTurnUsage(entry, active, result)
      if (!active.sawTextDelta && active.text.length === 0 && result.text !== undefined) {
        active.text = result.text
        active.transcriptText = result.text
        await this.#upsertTranscriptText(active)
        active.output.push({ type: 'text-delta', text: result.text })
      }
      await this.#upsertTranscriptText(active)
      await this.#flushTranscript(active)
      const message = result.errors?.join('\n')
        ?? (result.terminalReason !== undefined ? `Claude Code failed the turn (${result.terminalReason})` : 'Claude Code failed the turn')
      await this.#appendSafely(active, {
        kind: 'error',
        phase: 'failed',
        title: 'Claude Code turn failed',
        summary: message,
        isError: true,
      })
      active.output.fail(new Error(message))
    } else {
      if (!active.sawTextDelta && active.text.length === 0 && result.text !== undefined) {
        active.text = result.text
        active.transcriptText = result.text
        await this.#upsertTranscriptText(active)
        active.output.push({ type: 'text-delta', text: result.text })
      }
      await this.#upsertTranscriptText(active)
      if (active.phase === 'primary' && this.#hasRunningTasks(entry, active)) {
        active.phase = 'waiting-tasks'
        await this.#appendSafely(active, {
          kind: 'status',
          phase: 'updated',
          title: 'Claude Code is waiting for background tasks',
        })
        await this.#completeProgressSegment(active, result)
        return
      }
      await this.#recordTurnUsage(entry, active, result)
      await this.#appendSafely(active, {
        kind: 'status',
        phase: 'completed',
        title: 'Claude Code turn completed',
      })
      this.#markAnswer(active)
      await this.#flushTranscript(active)
      active.output.push({ type: 'complete', text: active.text })
      active.output.close()
    }
    if (active.signal !== undefined && active.abortListener !== undefined) {
      active.signal.removeEventListener('abort', active.abortListener)
    }
    entry.active = undefined
    entry.state = 'idle'
    entry.lastUsedAt = Date.now()
    await this.#recordChainAnchor(entry, active)
    this.#checkpointProjection(entry)
    this.#armIdleTimer(entry)
    this.#notifyCapacityChange()
    this.#scheduleLimitReconciliation()
    await this.#learnContextWindow(entry)
  }

  /** Tell every reader where this session's delta stream ended.
   *
   *  A reader that lost the turn's last delta has nothing later to reveal the
   *  hole, and a settled turn produces nothing further -- so a finished tool
   *  group would keep pulsing until the session was reopened by hand. Last
   *  line of the turn, best effort: presentation must never unsettle it. */
  #checkpointProjection(entry: SupervisorEntry): void {
    try {
      this.#sidecar.checkpoint(entry.sessionId)
    } catch {
      // A reader that misses the checkpoint is no worse off than before it.
    }
  }

  /** Pin the working tree this turn is about to change, so a rewind of it can
   *  put the checkout back where the turn found it.
   *
   *  Awaited, and deliberately: a snapshot taken after Claude's first edit
   *  would restore to a state that never existed. It costs one `git add -A`
   *  against a throwaway index per turn, and best effort throughout -- a
   *  session with no repository simply never offers a file rewind. */
  async #captureWorktree(entry: SupervisorEntry, turn: number): Promise<void> {
    try {
      const tree = await captureWorktreeTree(this.#runtime, entry.cwd)
      if (tree === undefined) return
      await this.#sidecar.recordRewindSnapshot(entry.sessionId, turn, tree)
    } catch {
      // The snapshot is advisory; a failed capture never fails the turn.
    }
  }

  /** Pin where Claude's chain ended for the DSH turn that just settled, so a
   *  later rewind of the following turn can fork exactly here. Best effort:
   *  a missing anchor only makes a rewind fall back to an earlier turn. */
  async #recordChainAnchor(entry: SupervisorEntry, active: ActiveTurn): Promise<void> {
    const uuid = entry.lastChainUuid
    if (uuid === undefined) return
    try {
      await this.#sidecar.recordRewindAnchor(entry.sessionId, active.cursor.turn, uuid)
    } catch {
      // The sidecar is advisory; a failed anchor never fails the turn.
    }
  }

  async #upsertTranscriptText(active: ActiveTurn): Promise<void> {
    if (active.transcriptText.length === 0) return
    const ordinal = active.transcriptTextOrdinal ?? active.cursor.nextOrdinal++
    active.transcriptTextOrdinal = ordinal
    try {
      // Hot path: notify live subscribers synchronously; disk persistence is
      // coalesced inside the repository and flushed at segment/turn edges.
      this.#sidecar.appendTranscriptText(active.agent.id as string, {
        text: active.transcriptText,
        ...(active.native ? { renderer: 'native' as const } : {}),
        turn: active.cursor.turn,
        step: active.cursor.step,
        ordinal,
      })
    } catch {
      // Transcript persistence is presentational and must not change a Claude outcome.
    }
  }

  async #flushTranscript(active: ActiveTurn): Promise<void> {
    await this.#sidecar.flushTranscriptText(active.agent.id as string).catch(() => undefined)
  }

  /** Hand the closing prose segment to the Host as the turn's answer.
   *
   *  Host 0.1.7 folds a finished turn behind a disclosure and keeps only the
   *  final assistant answer outside it. Under the plugin renderer the answer
   *  would otherwise be empty, folding Claude's reply away with the rest of
   *  the turn. The segment is re-stamped so the plugin transcript stops
   *  drawing it; a turn that ended on a tool call has no closing prose and
   *  hands nothing over. */
  #markAnswer(active: ActiveTurn): void {
    if (active.native || active.transcriptText.trim().length === 0 || active.transcriptTextOrdinal === undefined) return
    try {
      this.#sidecar.appendTranscriptText(active.agent.id as string, {
        text: active.transcriptText,
        answer: true,
        turn: active.cursor.turn,
        step: active.cursor.step,
        ordinal: active.transcriptTextOrdinal,
      })
    } catch {
      // Transcript persistence is presentational and must not change a Claude outcome.
    }
    active.output.push({ type: 'answer', text: active.transcriptText })
  }

  #closeTranscriptTextSegment(active: ActiveTurn): void {
    void this.#flushTranscript(active)
    active.transcriptText = ''
    active.transcriptTextOrdinal = undefined
  }

  async #appendActivity(active: ActiveTurn, activity: ClaudeActivityInput): Promise<void> {
    const ordinal = active.cursor.nextOrdinal++
    await this.#sidecar.appendActivity(active.agent.id as string, {
      ...activity,
      // Stamp the renderer this record was produced for. The Client reads it
      // back per record, so what DSH draws natively is never also drawn by the
      // plugin transcript -- and history keeps whichever renderer produced it.
      // Tool records stay unstamped: the v4 session format only accepts a
      // `tool/call` its own assistant message advertised (issue #57), so the
      // plugin draws Claude's tool cards under both renderers.
      ...(active.native && !pluginDrawnUnderNative(activity) ? { renderer: 'native' as const } : {}),
      turn: active.cursor.turn,
      step: active.cursor.step,
      ordinal,
    })
  }

  /** Persist durable activity without letting a storage failure unsettle the
   * in-memory turn or leak process ownership. Audit failure is best-effort. */
  async #appendSafely(active: ActiveTurn, activity: ClaudeActivityInput): Promise<void> {
    await this.#appendActivity(active, activity).catch(() => undefined)
  }

  #startInterrupt(entry: SupervisorEntry): Promise<void> {
    const existing = this.#interruptions.get(entry.sessionId)
    if (existing !== undefined) return existing
    const interruption = this.#interrupt(entry).finally(() => {
      this.#interruptions.delete(entry.sessionId)
    })
    this.#interruptions.set(entry.sessionId, interruption)
    return interruption
  }

  /** Put Claude's list in the session log as the `todo/write` snapshot the
   *  Host's to-do dock reads. Presentation only: a failed append never
   *  unsettles the turn. */
  async #writeTodos(active: ActiveTurn, todos: readonly TodoItem[]): Promise<void> {
    const snapshot = JSON.stringify(todos)
    if (snapshot === active.todoSnapshot) return
    active.todoSnapshot = snapshot
    try {
      await active.agent.session.append('todo/write', { todos: todos.map(item => ({ ...item })) })
    } catch {
      // The dock is a view; the transcript still has the tool call.
    }
  }

  /** Move one running root tool call to the background: the terminal's Ctrl+B
   *  for a single call. Claude receives a "running in the background" result
   *  at once and the command joins the Host job list with a stop control. */
  async backgroundToolCall(sessionId: string, toolUseId: string): Promise<'moved' | 'not-running' | 'unavailable'> {
    const entry = this.#entries.get(sessionId)
    const active = entry?.active
    if (entry === undefined || active === undefined || !active.openCalls.has(toolUseId)) return 'not-running'
    return await this.#backgroundCall(entry, active, toolUseId, 'requested by the user') ? 'moved' : 'unavailable'
  }

  /** A blocking Bash call gets one timer; the timer's firing is the auto-move,
   *  which the call's own result disarms. `run_in_background` calls are
   *  already detached and need none. */
  #armAutoBackground(entry: SupervisorEntry, active: ActiveTurn, toolUseId: string, toolName: string, input: unknown): void {
    const afterMs = this.#config.foregroundBashBackgroundMs ?? CLAUDE_FOREGROUND_BASH_BACKGROUND_MS
    if (toolName !== 'Bash' || afterMs <= 0) return
    const arguments_ = input !== null && typeof input === 'object' ? input as { run_in_background?: unknown } : undefined
    if (arguments_?.run_in_background === true) return
    const timer = setTimeout(() => {
      active.backgroundTimers.delete(toolUseId)
      if (entry.active !== active || !active.openCalls.has(toolUseId)) return
      void this.#backgroundCall(entry, active, toolUseId, `ran longer than ${afterMs >= 1_000 ? `${Math.round(afterMs / 1000)}s` : `${afterMs}ms`}`)
    }, afterMs)
    timer.unref?.()
    active.backgroundTimers.set(toolUseId, timer)
  }

  #disarmAutoBackground(active: ActiveTurn, toolUseId: string): void {
    const timer = active.backgroundTimers.get(toolUseId)
    if (timer === undefined) return
    clearTimeout(timer)
    active.backgroundTimers.delete(toolUseId)
  }

  async #backgroundCall(entry: SupervisorEntry, active: ActiveTurn, toolUseId: string, reason: string): Promise<boolean> {
    this.#disarmAutoBackground(active, toolUseId)
    let moved = false
    try {
      moved = await entry.query.backgroundTasks(toolUseId)
    } catch (error) {
      this.#logger?.warn(`dsh-claude: moving tool call ${toolUseId} to the background failed: ${error instanceof Error ? error.message : String(error)}`)
    }
    await this.#appendSafely(active, {
      kind: 'status',
      phase: moved ? 'completed' : 'failed',
      toolUseId,
      title: moved ? 'Claude Code moved the command to the background' : 'Claude Code could not move the command to the background',
      summary: reason,
    })
    return moved
  }

  /** Close out the root tool calls a turn is ending without answers for.
   *
   *  A tool result is the only thing that ever settles a call, and a turn that
   *  is cancelled or disconnected produces none: the transcript would keep
   *  drawing those calls as running for as long as the session lives, and no
   *  later event would ever correct it. Written as the failures they are. */
  async #settleOpenCalls(active: ActiveTurn, summary: string): Promise<void> {
    const open = [...active.openCalls]
    active.openCalls.clear()
    for (const toolUseId of [...active.backgroundTimers.keys()]) this.#disarmAutoBackground(active, toolUseId)
    for (const [toolUseId, toolName] of open) {
      await this.#appendSafely(active, {
        kind: 'tool-result',
        phase: 'failed',
        toolUseId,
        toolName,
        title: 'Tool cancelled',
        summary,
        isError: true,
      })
    }
  }

  async #interrupt(entry: SupervisorEntry): Promise<void> {
    const active = entry.active
    if (active === undefined || entry.state === 'interrupting') return
    entry.state = 'interrupting'
    active.aborted = true
    active.output.fail(abortFailure())
    await this.#upsertTranscriptText(active)
    let interruptError: unknown
    try {
      const receipt = await withTimeout(entry.query.interrupt(), CLAUDE_INTERRUPT_TIMEOUT_MS, 'Claude Code interrupt')
      const queued = receipt?.still_queued ?? []
      if (queued.includes(active.promptUuid)) {
        throw new Error(`Claude Code interrupt left submitted prompt ${active.promptUuid} queued`)
      }
    } catch (error) {
      interruptError = error
    }
    await this.#settleOpenCalls(active, 'Cancelled with the turn').catch(() => undefined)
    try {
      await this.#appendActivity(active, {
        kind: 'status',
        phase: 'failed',
        title: interruptError === undefined ? 'Claude Code turn cancelled' : 'Claude Code cancelled; process entry reset',
        ...(interruptError === undefined ? {} : { summary: errorSummary(interruptError) }),
      })
    } catch {
      // The active output is already aborted; process cleanup cannot wait for audit availability.
    }
    if (this.#entries.get(entry.sessionId) === entry) this.#entries.delete(entry.sessionId)
    await this.#disposeEntry(entry, 'turn interrupt cleanup')
  }

  async #handleDisconnect(entry: SupervisorEntry, error: unknown): Promise<void> {
    const active = entry.active
    // The stream can end a moment before the process is reaped, and the exit
    // status is the whole point of this message — a stream that ended because
    // the process died resolves here immediately, and one that ended while the
    // process lives costs a bounded wait rather than a wrong answer.
    const process = entry.process
    if (process !== undefined && process.exitCode === null && process.signalCode === null) {
      await process.handle.waitForExit(AbortSignal.timeout(DISCONNECT_EXIT_WAIT_MS)).catch(() => undefined)
    }
    const status = exitStatus(process, entry.disposeReason)
    // Read after the wait: a crashing CLI often writes its last words on the way out.
    const stderr = process?.stderrTail()
    // The transcript is the record, but a process dying mid-turn is the kind of
    // thing that is looked for in a log rather than in a conversation.
    this.#logger?.warn?.(
      `dsh-claude: Claude Code for ${entry.sessionId} stopped (${status})${active === undefined ? ' with no turn running' : active.sawActivity ? ' mid-turn after activity' : ' before the turn produced anything'}${stderr === undefined || stderr.length === 0 ? '' : `; stderr: ${redactText(stderr.slice(-400))}`}`,
    )
    if (active !== undefined) {
      await this.#upsertTranscriptText(active)
      await this.#flushTranscript(active)
      if (active.signal !== undefined && active.abortListener !== undefined) {
        active.signal.removeEventListener('abort', active.abortListener)
      }
      const unknown = active.sawActivity
      entry.state = unknown ? 'outcome-unknown' : 'disconnected'
      // What the process was still holding when it went away is part of the
      // same answer: an unanswered tool call is work that may or may not have
      // landed, and it is what makes the difference between "unknown" and
      // "probably finished".
      const open = active.openCalls.size === 0 ? '' : `; ${active.openCalls.size} tool call(s) were still unanswered`
      const failure = unknown
        ? new ClaudeOutcomeUnknownError(`Claude Code exited after activity; side-effect outcome is unknown and the prompt was not replayed (${status}${open})${stderr === undefined || stderr.length === 0 ? '' : `. ${stderr}`}`)
        : new Error(`${stderr === undefined || stderr.length === 0 ? errorSummary(error) : stderr} (${status}${open})`)
      await this.#settleOpenCalls(active, 'Claude Code stopped before the tool answered').catch(() => undefined)
      await this.#appendSafely(active, {
        kind: 'error',
        phase: 'failed',
        title: unknown ? 'Claude Code outcome unknown' : 'Claude Code disconnected',
        summary: failure.message,
        isError: true,
        detail: error,
      })
      active.output.fail(failure)
      entry.active = undefined
    } else {
      entry.state = 'disconnected'
    }
    this.#entries.delete(entry.sessionId)
    await this.#disposeEntry(entry, 'process stream ended')
  }

  #armIdleTimer(entry: SupervisorEntry): void {
    if (this.#config.idleTimeoutMs <= 0) return
    const timer = setTimeout(() => {
      if (entry.active !== undefined || entry.state !== 'idle') return
      this.#entries.delete(entry.sessionId)
      void this.#disposeEntry(entry, 'idle timeout')
    }, this.#config.idleTimeoutMs)
    timer.unref?.()
    entry.idleTimer = timer
  }

  /** @param reason - why the plugin is ending this process; it travels into the
   *  turn's failure text, so a kill the plugin asked for names its cause. */
  async #disposeEntry(entry: SupervisorEntry, reason: string): Promise<void> {
    if (entry.state === 'disposed') return
    entry.disposeReason = reason
    if (entry.idleTimer !== undefined) clearTimeout(entry.idleTimer)
    entry.state = 'disposed'
    this.#hostJobs?.abandon(entry.sessionId)
    entry.input.discard(abortFailure())
    entry.query.close()
    entry.lifetime.abort()
    if (entry.active !== undefined) {
      for (const toolUseId of [...entry.active.backgroundTimers.keys()]) this.#disarmAutoBackground(entry.active, toolUseId)
      entry.active.output.fail(abortFailure())
    }
    entry.process?.kill('SIGTERM')
    if (entry.process !== undefined) {
      try {
        await entry.process.handle.waitForExit(AbortSignal.timeout(5_000))
      } catch {
        // The DSH subprocess owner still holds the tree and will finish escalation.
      }
    }
    this.#notifyCapacityChange()
  }
}
