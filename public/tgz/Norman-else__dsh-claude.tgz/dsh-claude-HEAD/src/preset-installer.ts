import { randomUUID } from 'node:crypto'
import { link, lstat, mkdir, readFile, readdir, rm, rmdir, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { dshHomePath } from '@deepseek-ai/dsh-home-paths'
import { CLAUDE_CODE_PRESET_ID } from './constants.ts'

export const MANAGED_PRESET_FILES = ['agent.cordis.yml', 'preset.yml'] as const

/** Package specifier kept in the installed template. DSH Desktop 2.0.4 resolves
 * it through the active profile package factory, so the preset route and client
 * module share one Loader source. An absolute built entry would register a
 * second source and make the Desktop renderer reject the plugin graph. */
const PRESET_ROUTE_PACKAGE_SPECIFIER = '@norman-else/dsh-claude/preset-route'

export class ManagedPresetConflictError extends Error {
  readonly path: string

  constructor(path: string) {
    super(`dsh-claude: refusing to overwrite user-modified preset file ${path}`)
    this.name = 'ManagedPresetConflictError'
    this.path = path
  }
}

export interface ManagedPresetPaths {
  sourceDir: string
  targetDir: string
}

export function defaultManagedPresetPaths(dshHome?: string): ManagedPresetPaths {
  const packageRoot = fileURLToPath(new URL('../', import.meta.url))
  return {
    sourceDir: join(packageRoot, 'legacy-preset'),
    targetDir: dshHome === undefined
      ? dshHomePath('.agent-presets', CLAUDE_CODE_PRESET_ID)
      : join(dshHome, '.agent-presets', CLAUDE_CODE_PRESET_ID),
  }
}

interface ManagedContent {
  file: string
  /** Content this installer version writes. */
  content: string
  /** Older installer-written contents that may be silently upgraded/removed. */
  legacy: readonly string[]
  /** Legacy detection for contents that predate the current template. */
  isLegacy(current: string): boolean
}

async function managedContents(paths: ManagedPresetPaths): Promise<ManagedContent[]> {
  return await Promise.all(MANAGED_PRESET_FILES.map(async (file): Promise<ManagedContent> => {
    const source = await readFile(join(paths.sourceDir, file), 'utf8')
    const nameRow = `name: '${PRESET_ROUTE_PACKAGE_SPECIFIER}'`
    const legacyNameRow = `name: ${PRESET_ROUTE_PACKAGE_SPECIFIER}`
    if (file !== 'agent.cordis.yml' || !source.includes(nameRow)) {
      return { file, content: source, legacy: [], isLegacy: () => false }
    }
    return {
      file,
      content: source,
      legacy: [],
      // Earlier installers wrote either an unquoted specifier or an absolute
      // built-module path. Both are installer-owned and safe to converge to the
      // single profile package source used by Desktop 2.0.4.
      // Older installers wrote the route as an absolute path; on Windows that
      // path carries backslashes, so compare with separators normalized.
      isLegacy: current =>
        current.includes('id: claude-code-route')
        && (current.includes(legacyNameRow)
          || current.replaceAll('\\', '/').includes('lib/preset-route.mjs')),
    }
  }))
}

async function readIfPresent(path: string): Promise<string | undefined> {
  try {
    return await readFile(path, 'utf8')
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return undefined
    throw error
  }
}

async function atomicWrite(path: string, content: string): Promise<boolean> {
  await mkdir(dirname(path), { recursive: true })
  const temporary = `${path}.${randomUUID()}.tmp`
  try {
    await writeFile(temporary, content, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    try {
      await link(temporary, path)
      return true
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'EEXIST') throw error
      if (await readIfPresent(path) === content) return false
      throw new ManagedPresetConflictError(path)
    }
  } finally {
    await rm(temporary, { force: true })
  }
}

export async function ensureManagedPreset(paths = defaultManagedPresetPaths()): Promise<'installed' | 'unchanged'> {
  await assertSafeTargetDirectory(paths.targetDir)
  const expected = await managedContents(paths)
  let changed = false
  for (const { file, content, legacy, isLegacy } of expected) {
    const target = join(paths.targetDir, file)
    const current = await readIfPresent(target)
    if (current === content) continue
    if (current !== undefined) {
      // Upgrade installer-written legacy content in place; never touch user edits.
      if (!legacy.includes(current) && !isLegacy(current)) throw new ManagedPresetConflictError(target)
      await rm(target)
    }
    changed = await atomicWrite(target, content) || changed
  }
  return changed ? 'installed' : 'unchanged'
}

/** Reject a target directory that is a symlink (or occupies the path as a file)
 *  so the managed preset never writes through an attacker-controlled link. */
async function assertSafeTargetDirectory(targetDir: string): Promise<void> {
  try {
    const stat = await lstat(targetDir)
    if (!stat.isDirectory() || stat.isSymbolicLink()) {
      throw new ManagedPresetConflictError(targetDir)
    }
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return
    throw error
  }
}

export async function removeManagedPreset(paths = defaultManagedPresetPaths()): Promise<'removed' | 'absent'> {
  await assertSafeTargetDirectory(paths.targetDir)
  const expected = await managedContents(paths)
  const managedTargets: string[] = []
  for (const { file, content, legacy, isLegacy } of expected) {
    const target = join(paths.targetDir, file)
    const current = await readIfPresent(target)
    if (current === undefined) continue
    if (current !== content && !legacy.includes(current) && !isLegacy(current)) throw new ManagedPresetConflictError(target)
    managedTargets.push(target)
  }
  for (const target of managedTargets) await rm(target)
  try {
    if ((await readdir(paths.targetDir)).length === 0) await rmdir(paths.targetDir)
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error
  }
  return managedTargets.length > 0 ? 'removed' : 'absent'
}
