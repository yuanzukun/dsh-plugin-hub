import { Fragment, useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import {
  IconChevronDownOutlineRegular,
  IconChevronRightOutlineRegular,
  IconChevronUpOutlineRegular,
  IconCloseOutlineRegular,
  Menu,
  Modal,
  Tooltip,
  type MenuEntry,
} from '@deepseek-ai/dsh-client-ui-primitives'
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots'
import type { RepositoryActionKind, RepositoryActionPreview } from '../repository-actions.ts'
import type { RepositoryStatus } from '../repository-status.ts'
import type { ReviewComment, ReviewCommentSide } from '../review-comments.ts'
import { branchLabel, repositoryLabel } from './branch-label.ts'
import type { ClaudeCodeSettingsKey } from './locales.ts'
import type { ClaudeClientProjection } from './projection.ts'
import { useActionToast } from './action-toast.tsx'
import { executeRepositoryAction, generateCommitMessage, generatePullRequestText, loadRepositoryActionPreview } from './repository-action-api.ts'
import {
  composeCommentsPrompt,
  loadMentionableUsers,
  loadPullRequestThreads,
  replyToReviewThread,
  setReviewThreadResolved,
  type MentionableUser,
  type PullRequestReviewThread,
} from './pr-feedback-api.ts'
import { addReviewComment, removeReviewComment } from './review-comment-api.ts'
import { loadRepositoryFileLines } from './repository-setup-api.ts'
import { ReviewThreadCard } from './ReviewThreadCard.tsx'
import { menuNavigationIndex } from './menu-navigation.ts'
import { commentLineLabel } from './ClaudeReviewComments.tsx'
import * as styles from './styles.ts'

export interface ClaudeDiffPanelInjected {
  t: (key: ClaudeCodeSettingsKey, params?: Record<string, unknown>) => string
  sessionId: string
  closeDetails: () => void
  /** Submit the composer, seeding the given draft text when it is empty. */
  submitPrompt?: (draft: string, mode?: 'append' | 'idle') => boolean
  /** Open on this checkout rather than the session's own (see `repositories`). */
  initialRoot?: string
}

export interface ClaudeDiffPanelProps extends ClaudeDiffPanelInjected {
  useClaudeProjection: SnapshotSelectorHook<ClaudeClientProjection>
}

export interface DiffFile {
  readonly path: string
  readonly additions: number
  readonly deletions: number
  readonly lines: readonly string[]
}

function pathFromHeader(line: string): string | undefined {
  const match = /^diff --git a\/(.+) b\/(.+)$/u.exec(line)
  return match?.[2]
}

export function parseUnifiedDiff(patch: string): readonly DiffFile[] {
  const files: DiffFile[] = []
  let path: string | undefined
  let lines: string[] = []
  const flush = (): void => {
    if (path === undefined) return
    const content = lines.filter(line => !line.startsWith('diff --git ') && !line.startsWith('index ') && !line.startsWith('--- ') && !line.startsWith('+++ '))
    files.push({
      path,
      additions: content.filter(line => line.startsWith('+')).length,
      deletions: content.filter(line => line.startsWith('-')).length,
      lines: content,
    })
  }
  for (const line of patch.split(/\r?\n/u)) {
    const nextPath = pathFromHeader(line)
    if (nextPath !== undefined) {
      flush()
      path = nextPath
      lines = [line]
    } else if (path !== undefined) lines.push(line)
  }
  flush()
  return files
}

/** A run of unmodified lines the unified diff left out; `count` is unknown for the tail of the file. */
export interface DiffGap {
  readonly oldStart: number
  readonly newStart: number
  readonly count?: number
  readonly position: 'top' | 'middle' | 'bottom'
}

export interface NumberedDiffLine {
  readonly line: string
  readonly kind: 'add' | 'delete' | 'hunk' | 'context' | 'collapsed'
  readonly oldLine?: number
  readonly newLine?: number
  readonly gap?: DiffGap
}

/** How many unmodified lines one click on an expander reveals. */
export const DIFF_EXPAND_STEP = 20

export function numberDiffLines(lines: readonly string[]): readonly NumberedDiffLine[] {
  const numbered: NumberedDiffLine[] = []
  let oldLine = 0
  let newLine = 0
  let previousOldEnd: number | undefined
  let previousNewEnd = 0
  // New and deleted files have no unmodified lines around their single hunk.
  let expandable = false
  for (const line of lines) {
    const hunk = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/u.exec(line)
    if (hunk !== null) {
      const nextOld = Number(hunk[1])
      const nextNew = Number(hunk[3])
      const oldCount = Number(hunk[2] ?? 1)
      const newCount = Number(hunk[4] ?? 1)
      if (previousOldEnd === undefined) {
        expandable = oldCount > 0 && newCount > 0
        if (expandable && nextOld > 1) numbered.push({ line: '', kind: 'collapsed', gap: { oldStart: 1, newStart: 1, count: nextOld - 1, position: 'top' } })
      } else if (nextOld > previousOldEnd) {
        numbered.push({ line: '', kind: 'collapsed', gap: { oldStart: previousOldEnd, newStart: previousNewEnd, count: nextOld - previousOldEnd, position: 'middle' } })
      }
      oldLine = nextOld
      newLine = nextNew
      previousOldEnd = nextOld + oldCount
      previousNewEnd = nextNew + newCount
      numbered.push({ line, kind: 'hunk' })
      continue
    }
    if (line.startsWith('+')) {
      numbered.push({ line, kind: 'add', newLine })
      newLine += 1
    } else if (line.startsWith('-')) {
      numbered.push({ line, kind: 'delete', oldLine })
      oldLine += 1
    } else {
      numbered.push({ line, kind: 'context', oldLine, newLine })
      oldLine += 1
      newLine += 1
    }
  }
  if (expandable && previousOldEnd !== undefined) {
    numbered.push({ line: '', kind: 'collapsed', gap: { oldStart: previousOldEnd, newStart: previousNewEnd, position: 'bottom' } })
  }
  return numbered
}

/**
 * Splice revealed working-tree lines (keyed by new-side line number) into the
 * collapsed gaps. Expansion only ever grows a gap's edges, so each gap is a
 * top run + remaining gap + bottom run; `total` (file line count) turns the
 * open-ended tail gap into a bounded one.
 */
export function expandDiffRows(rows: readonly NumberedDiffLine[], revealed: ReadonlyMap<number, string>, total?: number): readonly NumberedDiffLine[] {
  const out: NumberedDiffLine[] = []
  for (const row of rows) {
    const gap = row.gap
    if (row.kind !== 'collapsed' || gap === undefined) {
      out.push(row)
      continue
    }
    const count = gap.count ?? (total === undefined ? undefined : Math.max(0, total - gap.newStart + 1))
    const context = (offset: number): NumberedDiffLine => ({
      line: ` ${revealed.get(gap.newStart + offset) ?? ''}`,
      kind: 'context',
      oldLine: gap.oldStart + offset,
      newLine: gap.newStart + offset,
    })
    let top = 0
    while ((count === undefined || top < count) && revealed.has(gap.newStart + top)) top += 1
    let bottom = 0
    if (count !== undefined) while (bottom < count - top && revealed.has(gap.newStart + count - 1 - bottom)) bottom += 1
    for (let offset = 0; offset < top; offset += 1) out.push(context(offset))
    const remaining = count === undefined ? undefined : count - top - bottom
    if (remaining === undefined || remaining > 0) {
      out.push({ ...row, gap: { ...gap, oldStart: gap.oldStart + top, newStart: gap.newStart + top, ...(remaining === undefined ? {} : { count: remaining }) } })
    }
    if (count !== undefined) for (let offset = count - bottom; offset < count; offset += 1) out.push(context(offset))
  }
  return out
}

/** One stop for the panel's prev/next comment walk. */
export interface ReviewTarget {
  readonly key: string
  readonly path: string
  readonly line: number
  readonly side: ReviewCommentSide
}

/** Everything in this diff still waiting on the reader, in reading order:
 *  files as the panel lists them, lines as the file reads. Resolved threads are
 *  collapsed by design, and a comment on a file this diff does not render has
 *  nowhere to scroll to, so neither is a stop. */
export function reviewTargets(
  files: readonly DiffFile[],
  comments: readonly ReviewComment[],
  threads: readonly PullRequestReviewThread[],
): readonly ReviewTarget[] {
  const targets: ReviewTarget[] = []
  for (const file of files) {
    const inFile: ReviewTarget[] = [
      ...threads
        .filter(thread => thread.path === file.path && !thread.resolved && thread.line !== undefined)
        .map(thread => ({ key: `thread:${thread.id}`, path: thread.path, line: thread.line ?? 0, side: thread.side })),
      ...comments
        .filter(comment => comment.path === file.path)
        .map(comment => ({ key: `comment:${comment.id}`, path: comment.path, line: comment.line, side: comment.side })),
    ]
    targets.push(...inFile.sort((left, right) => left.line - right.line || left.side.localeCompare(right.side)))
  }
  return targets
}

export interface ReviewCommentAnchor {
  /** Last (anchor) line; the editor and saved comment attach here. */
  readonly line: number
  readonly side: ReviewCommentSide
  /** First line of a multi-line selection. */
  readonly startLine?: number
}

/**
 * Anchor for a drag from row `from` to row `to`: every commentable row in
 * between on the same side as the first row, collapsed to its first/last line.
 */
export function rangeCommentAnchor(anchors: readonly (ReviewCommentAnchor | undefined)[], from: number, to: number): ReviewCommentAnchor | undefined {
  const side = anchors[from]?.side
  if (side === undefined) return undefined
  const lines = anchors
    .slice(Math.min(from, to), Math.max(from, to) + 1)
    .flatMap(anchor => (anchor?.side === side ? [anchor.line] : []))
  const line = Math.max(...lines)
  const startLine = Math.min(...lines)
  return startLine < line ? { line, side, startLine } : { line, side }
}

/** Which working-tree line a comment on this rendered diff row refers to. */
export function commentAnchorForLine(entry: NumberedDiffLine): ReviewCommentAnchor | undefined {
  if (entry.kind === 'add' || entry.kind === 'context') {
    return entry.newLine === undefined ? undefined : { line: entry.newLine, side: 'new' }
  }
  if (entry.kind === 'delete') {
    return entry.oldLine === undefined ? undefined : { line: entry.oldLine, side: 'old' }
  }
  return undefined
}

function DiffLine({ entry, addLabel, selected, onComment, onDragStart, onDragEnter }: {
  entry: NumberedDiffLine
  addLabel: string
  selected: boolean
  onComment?: (() => void) | undefined
  onDragStart?: (() => void) | undefined
  onDragEnter?: (() => void) | undefined
}) {
  const style = entry.kind === 'add'
    ? styles.diffLineAdd
    : entry.kind === 'delete' ? styles.diffLineDelete : entry.kind === 'hunk' ? styles.diffLineHunk : styles.diffLineContext
  const lineNumber = entry.oldLine === undefined && entry.newLine === undefined
    ? ''
    : entry.oldLine === undefined ? String(entry.newLine) : entry.newLine === undefined ? String(entry.oldLine) : String(entry.newLine)
  return (
    <div className={styles.diffLineRowClass} style={{ ...styles.diffLine, ...style, ...(selected ? styles.diffLineSelected : {}) }} onPointerEnter={onDragEnter}>
      <button
        type="button"
        className={styles.diffCommentButtonClass}
        disabled={onComment === undefined}
        aria-label={addLabel}
        onPointerDown={event => {
          if (event.button !== 0 || onDragStart === undefined) return
          // Keep the pointer free to enter the rows below/above while dragging, and stop text selection.
          event.preventDefault()
          if (event.currentTarget.hasPointerCapture?.(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId)
          onDragStart()
        }}
        onClick={event => { if (event.detail === 0) onComment?.() }}
      >+</button>
      <span style={styles.diffLineNumber}>{lineNumber}</span>
      <span style={styles.diffLineMarker}>{entry.kind === 'add' ? '+' : entry.kind === 'delete' ? '−' : ' '}</span>
      <span style={styles.diffLineText}>{entry.line.slice(entry.kind === 'hunk' ? 0 : 1)}</span>
    </div>
  )
}

function ChevronGlyph({ direction }: { direction: 'up' | 'down' }) {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={direction === 'up' ? 'M3 8.5l4-4 4 4' : 'M3 5.5l4 4 4-4'} />
    </svg>
  )
}

/** "N unmodified lines" separator with GitHub-style expanders: ↑ above the first hunk, ↑↓ between hunks, ↓ after the last. */
function DiffGapRow({ gap, t, busy, onExpand }: { gap: DiffGap; t: ClaudeDiffPanelInjected['t']; busy: boolean; onExpand?: ((gap: DiffGap, direction: 'up' | 'down') => void) | undefined }) {
  const button = (direction: 'up' | 'down'): ReactNode => (
    <button type="button" style={styles.diffGapButton} disabled={busy || onExpand === undefined} aria-label={t(direction === 'up' ? 'diffExpandUp' : 'diffExpandDown')} title={t(direction === 'up' ? 'diffExpandUp' : 'diffExpandDown')} onClick={() => onExpand?.(gap, direction)}><ChevronGlyph direction={direction} /></button>
  )
  return (
    <div style={{ ...styles.diffLine, ...styles.diffLineHunk }}>
      <span style={styles.diffGapControls}>
        {gap.position === 'bottom' ? null : button('up')}
        {gap.position === 'top' ? null : button('down')}
      </span>
      <span style={styles.diffLineText}>{gap.count === undefined ? t('diffUnmodifiedTail') : t('diffUnmodifiedLines', { count: gap.count })}</span>
    </div>
  )
}

function CommentGlyph() {
  return (
    <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M14 9.5a2 2 0 0 1-2 2H6l-3.5 2.5V4a2 2 0 0 1 2-2h7.5a2 2 0 0 1 2 2z" />
    </svg>
  )
}

/** The undo arrow: a hook bending back to the left. Drawn inline because the
 *  primitives icon set has no undo icon, and its refresh circle reads as
 *  "reload" rather than "discard these changes". */
function RevertGlyph() {
  return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true" focusable="false">
      <path d="M5.5 3.5 2.5 6.5l3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M2.75 6.5h6.75a3.75 3.75 0 0 1 0 7.5H7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

interface DiffFileSectionProps {
  readonly file: DiffFile
  /** Repository root the working tree lives in; without it unmodified lines cannot be expanded. */
  readonly root: string | undefined
  readonly open: boolean
  readonly t: ClaudeDiffPanelInjected['t']
  readonly comments: readonly ReviewComment[]
  readonly ghThreads: readonly PullRequestReviewThread[]
  readonly suggestMention: (query: string) => Promise<readonly MentionableUser[]>
  /** Clock the comment ages render against, refreshed with the thread load. */
  readonly now: number
  readonly onReplyToThread: (thread: PullRequestReviewThread, body: string) => Promise<void>
  readonly onThreadResolvedChange: (thread: PullRequestReviewThread, resolved: boolean) => Promise<void>
  /** Undefined when the session has no composer to submit a fix request into. */
  readonly onSendThreadToAi: ((thread: PullRequestReviewThread) => void) | undefined
  readonly editorAnchor: ReviewCommentAnchor | undefined
  readonly editorNode: ReactNode
  readonly activeTargetKey: string | undefined
  readonly onOpenChange: (open: boolean) => void
  /** Put this file's uncommitted changes back; undefined when nothing may be reverted. */
  readonly onRevert: (() => void) | undefined
  readonly onOpenEditor: (anchor: ReviewCommentAnchor) => void
  readonly onRemoveComment: (id: string) => void
}

function DiffFileSection({
  file, root, open, t, comments, ghThreads, editorAnchor, editorNode, now,
  activeTargetKey,
  suggestMention, onOpenEditor, onOpenChange, onRevert, onRemoveComment, onReplyToThread, onThreadResolvedChange, onSendThreadToAi,
}: DiffFileSectionProps) {
  const [revealed, setRevealed] = useState<ReadonlyMap<number, string>>(() => new Map())
  const [total, setTotal] = useState<number>()
  const [expanding, setExpanding] = useState(false)
  const [drag, setDrag] = useState<{ start: number; end: number }>()
  const rows = useMemo(() => expandDiffRows(numberDiffLines(file.lines), revealed, total), [file.lines, revealed, total])
  const anchors = useMemo(() => rows.map(commentAnchorForLine), [rows])
  const name = file.path.slice(file.path.lastIndexOf('/') + 1)
  // Collapsed sections hide their comments, so the header carries the count.
  const commentCount = comments.length + ghThreads.reduce((total, thread) => total + thread.comments.length, 0)
  const expand = (gap: DiffGap, direction: 'up' | 'down'): void => {
    if (root === undefined || expanding) return
    const span = gap.count ?? DIFF_EXPAND_STEP
    const size = Math.min(DIFF_EXPAND_STEP, span)
    const from = direction === 'down' ? gap.newStart : gap.newStart + span - size
    setExpanding(true)
    void loadRepositoryFileLines(root, file.path, from, from + size - 1).then(result => {
      setRevealed(previous => {
        const next = new Map(previous)
        result.lines.forEach((text, offset) => next.set(from + offset, text))
        return next
      })
      setTotal(result.total)
    }, () => undefined).finally(() => setExpanding(false))
  }
  useEffect(() => {
    if (drag === undefined) return
    const finish = (): void => {
      setDrag(undefined)
      const anchor = rangeCommentAnchor(anchors, drag.start, drag.end)
      if (anchor !== undefined) onOpenEditor(anchor)
    }
    window.addEventListener('pointerup', finish)
    window.addEventListener('pointercancel', finish)
    return () => {
      window.removeEventListener('pointerup', finish)
      window.removeEventListener('pointercancel', finish)
    }
  }, [anchors, drag, onOpenEditor])
  const dragLow = drag === undefined ? undefined : Math.min(drag.start, drag.end)
  const dragHigh = drag === undefined ? undefined : Math.max(drag.start, drag.end)
  const dragSide = drag === undefined ? undefined : anchors[drag.start]?.side
  return (
    <section style={styles.diffFile}>
      {/* The header row, not the toggle, is sticky: the revert control sits
          beside the toggle rather than inside it, where a nested button would
          be invalid markup. */}
      <div className={styles.diffFileHeaderClass} style={styles.diffFileHeaderRow}>
      <button type="button" style={styles.diffFileHeaderToggle} aria-expanded={open} onClick={() => onOpenChange(!open)}>
        <span data-diff-file-chevron="" style={{ ...styles.diffFileChevron, ...(open ? styles.chevronOpen : {}) }} aria-hidden="true">
          <IconChevronRightOutlineRegular size={14} />
        </span>
        <span style={styles.diffFilePath}>
          <Tooltip label={file.path} side="bottom" delayMs={300} maxWidth={520}>
            <span style={styles.diffFileName} aria-label={file.path}>{name}</span>
          </Tooltip>
        </span>
        {commentCount === 0 ? null : (
          <span style={styles.diffFileComments} aria-label={t('diffFileComments', { count: commentCount })}>
            <CommentGlyph />{commentCount}
          </span>
        )}
        <span style={styles.diffFileStats}><span style={styles.diffAdd}>+{file.additions}</span><span style={styles.diffDelete}>−{file.deletions}</span></span>
      </button>
      {onRevert === undefined ? null : (
        <Tooltip label={t('diffRevertFile')} side="bottom" delayMs={300}>
          <button type="button" className={styles.panelIconButtonClass} style={styles.diffFileRevert} aria-label={t('diffRevertFileNamed', { path: file.path })} onClick={onRevert}>
            <RevertGlyph />
          </button>
        </Tooltip>
      )}
      </div>
      {open ? <div style={styles.diffCode}>{rows.map((entry, index) => {
        if (entry.kind === 'collapsed' && entry.gap !== undefined) {
          return <DiffGapRow key={`gap:${entry.gap.newStart}`} gap={entry.gap} t={t} busy={expanding} onExpand={root === undefined ? undefined : expand} />
        }
        const anchor = anchors[index]
        const lineComments = anchor === undefined ? [] : comments.filter(comment => comment.line === anchor.line && comment.side === anchor.side)
        const lineThreads = anchor === undefined ? [] : ghThreads.filter(thread => thread.line === anchor.line && thread.side === anchor.side)
        const editorOpen = anchor !== undefined && editorAnchor !== undefined && editorAnchor.line === anchor.line && editorAnchor.side === anchor.side
        const inDrag = dragLow !== undefined && dragHigh !== undefined && index >= dragLow && index <= dragHigh && anchor?.side === dragSide
        const inEditorRange = anchor !== undefined && editorAnchor !== undefined && editorAnchor.side === anchor.side
          && anchor.line <= editorAnchor.line && anchor.line >= (editorAnchor.startLine ?? editorAnchor.line)
        return (
          <Fragment key={`${index}:${entry.line}`}>
            <DiffLine
              entry={entry}
              addLabel={t('reviewCommentAdd')}
              selected={inDrag || inEditorRange}
              onComment={anchor === undefined ? undefined : () => onOpenEditor(anchor)}
              onDragStart={anchor === undefined ? undefined : () => setDrag({ start: index, end: index })}
              onDragEnter={drag === undefined ? undefined : () => setDrag(current => (current === undefined ? current : { ...current, end: index }))}
            />
            {lineComments.map(comment => (
              <div
                key={comment.id}
                data-review-target={`comment:${comment.id}`}
                data-review-active={activeTargetKey === `comment:${comment.id}` ? 'true' : undefined}
                style={{ ...styles.diffCommentBlock, ...(activeTargetKey === `comment:${comment.id}` ? styles.diffCommentBlockActive : {}) }}
              >
                <div style={styles.diffCommentCardMeta}>
                  <span>{commentLineLabel(comment, t)}</span>
                  <button type="button" style={styles.reviewCommentChipRemove} aria-label={t('reviewCommentRemove')} onClick={() => onRemoveComment(comment.id)}>×</button>
                </div>
                <p style={styles.diffCommentCardText}>{comment.text}</p>
              </div>
            ))}
            {lineThreads.map(thread => (
              <ReviewThreadCard
                key={thread.id}
                thread={thread}
                anchorKey={`thread:${thread.id}`}
                active={activeTargetKey === `thread:${thread.id}`}
                t={t}
                suggest={suggestMention}
                now={now}
                onReply={body => onReplyToThread(thread, body)}
                onResolvedChange={resolved => onThreadResolvedChange(thread, resolved)}
                onSendToAi={onSendThreadToAi === undefined ? undefined : () => { onSendThreadToAi(thread) }}
              />
            ))}
            {editorOpen ? editorNode : null}
          </Fragment>
        )
      })}</div> : null}
    </section>
  )
}

interface ActionDialogState {
  readonly action: RepositoryActionKind
  readonly preview?: RepositoryActionPreview
  readonly loading: boolean
  readonly submitting: boolean
  readonly error?: string
  /** Only set on failure: a commit that survived a failed push keeps its hash
   *  next to the error so the retry is not blind. */
  readonly commit?: string
}

export function actionLabel(action: RepositoryActionKind, t: ClaudeDiffPanelInjected['t']): string {
  const label = action === 'commit'
    ? t('diffCommit')
    : action === 'commit-push' ? t('diffCommitPush') : action === 'push' ? t('diffPush') : action === 'merge-pr' ? t('diffMergePr') : action === 'update-branch' ? t('diffUpdateBranch') : t('diffCreatePr')
  return label.replace(/[….]+$/u, '')
}

/** The panel's own menu. Resuming a stopped merge or rebase belongs to the
 *  repository bar, which is the surface that can still be reached from one. */
export type PanelActionKind = Exclude<RepositoryActionKind, 'resolve-continue' | 'resolve-abort' | 'revert'>
export type RepositoryActionAvailability = Readonly<Record<PanelActionKind, boolean>>

export function repositoryActionAvailability(
  repository: Pick<RepositoryStatus, 'status' | 'dirty' | 'detached' | 'remote' | 'pullRequest' | 'upstream' | 'ahead' | 'baseBehind' | 'conflicts'> | undefined,
): RepositoryActionAvailability {
  // Unmerged paths read as dirty, and a conflicted merge keeps HEAD attached:
  // without this every commit button would offer work git is going to refuse.
  const ready = repository?.status === 'ready' && repository.detached !== true
    && (repository.conflicts ?? []).length === 0
  const committable = ready && repository.dirty === true
  const hasRemote = repository?.remote !== undefined
  const hasOpenPullRequest = repository?.pullRequest?.state === 'open'
  const pushable = ready && hasRemote && (repository.upstream === false || (repository.ahead ?? 0) > 0)
  return {
    'commit': committable,
    'commit-push': committable && hasRemote,
    'push': pushable,
    'create-pr': (committable || pushable) && hasRemote && !hasOpenPullRequest,
    'merge-pr': ready && hasOpenPullRequest && repository?.pullRequest?.draft !== true,
    'update-branch': ready && hasOpenPullRequest && repository?.dirty !== true && (repository?.baseBehind ?? 0) > 0,
  }
}

function hasChanges(repository: RepositoryStatus | undefined): boolean {
  return (repository?.diff?.additions ?? 0) > 0 || (repository?.diff?.deletions ?? 0) > 0
}

/** The checkouts a session can show: its own first, then the ones it wrote
 *  into. A linked pull request with no local checkout has no diff to show. */
export function panelRepositories(projection: Pick<ClaudeClientProjection, 'repository' | 'repositories'>): readonly RepositoryStatus[] {
  return [projection.repository, ...(projection.repositories ?? []).filter(item => item.diff !== undefined)]
    .filter((item): item is RepositoryStatus => item !== undefined)
}

export function ClaudeDiffPanel({ useClaudeProjection, t, sessionId, closeDetails, submitPrompt, initialRoot }: ClaudeDiffPanelProps) {
  const projection = useClaudeProjection(value => value)
  const repositories = useMemo(() => panelRepositories(projection), [projection])
  // Opened without a target, the panel lands on the session's own checkout --
  // unless that one is clean and a linked one is not, in which case the
  // header button that opened it was lit by the linked one.
  const [selectedRoot, setSelectedRoot] = useState(() => initialRoot ?? (
    hasChanges(projection.repository) ? undefined : repositories.find(hasChanges)?.root
  ))
  const repository = repositories.find(item => item.root === selectedRoot) ?? projection.repository
  // Undefined for the session's own checkout, so its requests keep their shape;
  // the Host only honours roots the projection has vouched for.
  const root = repository === projection.repository ? undefined : repository?.root
  const diff = repository?.diff
  const files = useMemo(() => parseUnifiedDiff(diff?.patch ?? ''), [diff?.patch])
  const [menuOpen, setMenuOpen] = useState(false)
  const [repositoryMenuOpen, setRepositoryMenuOpen] = useState(false)
  // Each row carries its own counts, so both changes are visible at once.
  const repositoryItems = useMemo((): readonly MenuEntry[] => repositories.map(item => ({
    id: item.root ?? item.cwd,
    label: <span style={styles.diffRepositoryRow}>
      <span style={styles.diffRepositoryRowName}>{repositoryLabel(item)}</span>
      {' '}
      <span style={styles.diffRepositoryRowCounts}>
        <span style={styles.diffAdd}>+{item.diff?.additions ?? 0}</span>
        {' '}
        <span style={styles.diffDelete}>−{item.diff?.deletions ?? 0}</span>
      </span>
    </span>,
  })), [repositories])
  const { toast, report } = useActionToast()
  const [dialog, setDialog] = useState<ActionDialogState>()
  const [message, setMessage] = useState('')
  const [includeUnstaged, setIncludeUnstaged] = useState(true)
  const [prTitle, setPrTitle] = useState('')
  const [prBody, setPrBody] = useState('')
  const [baseBranch, setBaseBranch] = useState('')
  const [draft, setDraft] = useState(true)
  const [commentEditor, setCommentEditor] = useState<{ path: string } & ReviewCommentAnchor>()
  const [commentDraft, setCommentDraft] = useState('')
  const [commentBusy, setCommentBusy] = useState(false)
  const [commentError, setCommentError] = useState<string>()
  const [localComments, setLocalComments] = useState<readonly ReviewComment[]>([])
  const [removedCommentIds, setRemovedCommentIds] = useState<ReadonlySet<string>>(() => new Set())
  const actionController = useRef<AbortController>()
  const [ghThreads, setGhThreads] = useState<readonly PullRequestReviewThread[]>([])
  // Comment ages read against the moment the threads arrived, so every card in
  // one render agrees on "now" instead of drifting per re-render.
  const [threadsLoadedAt, setThreadsLoadedAt] = useState(() => Date.now())
  const pullNumber = repository?.pullRequest?.state === 'open' ? repository.pullRequest.number : undefined
  useEffect(() => {
    setGhThreads([])
    if (pullNumber === undefined) return
    const controller = new AbortController()
    void loadPullRequestThreads(sessionId, pullNumber, controller.signal, root).then((threads) => {
      setGhThreads(threads)
      setThreadsLoadedAt(Date.now())
    }, () => undefined)
    return () => { controller.abort() }
  }, [pullNumber, root, sessionId])
  // The count on the "hand the review to Claude" button counts what is still
  // open, matching what that button would actually forward.
  const openThreadCount = ghThreads.filter(thread => !thread.resolved).length
  const bodyRef = useRef<HTMLDivElement | null>(null)
  const [targetIndex, setTargetIndex] = useState(0)
  const [activeTargetKey, setActiveTargetKey] = useState<string>()
  const [pendingScrollKey, setPendingScrollKey] = useState<string>()
  // Explicit choices only; a file the reader has not touched follows the
  // default (the first file opens, the rest stay out of the way).
  const [openFiles, setOpenFiles] = useState<ReadonlyMap<string, boolean>>(() => new Map())
  const fileOpen = useCallback((path: string, index: number): boolean => openFiles.get(path) ?? index === 0, [openFiles])
  const setFileOpen = useCallback((path: string, open: boolean): void => {
    setOpenFiles(current => new Map(current).set(path, open))
  }, [])
  const suggestMention = useCallback(async (query: string): Promise<readonly MentionableUser[]> => (
    pullNumber === undefined ? [] : loadMentionableUsers(sessionId, pullNumber, query, undefined, root).catch((): readonly MentionableUser[] => [])
  ), [pullNumber, root, sessionId])
  // GitHub is the record; the local copy just spares the panel a full reload
  // between one reply and the next.
  const replyToThread = useCallback(async (thread: PullRequestReviewThread, body: string): Promise<void> => {
    if (pullNumber === undefined) return
    const anchor = thread.comments[0]
    if (anchor === undefined) return
    const posted = await replyToReviewThread(sessionId, pullNumber, anchor.id, body, root)
    setGhThreads(list => list.map(item => (item.id === thread.id
      ? { ...item, comments: [...item.comments, posted] }
      : item)))
  }, [pullNumber, root, sessionId])
  const changeThreadResolved = useCallback(async (thread: PullRequestReviewThread, resolved: boolean): Promise<void> => {
    if (pullNumber === undefined) return
    const state = await setReviewThreadResolved(sessionId, pullNumber, thread.id, resolved, root)
    setGhThreads(list => list.map(item => (item.id === thread.id ? { ...item, resolved: state } : item)))
  }, [pullNumber, root, sessionId])
  // The code container is max-content wide for horizontal scrolling; comment
  // editors size against the visible width published through this variable.
  const diffViewportObserver = useRef<ResizeObserver>()
  const diffBodyRef = useCallback((element: HTMLDivElement | null) => {
    diffViewportObserver.current?.disconnect()
    diffViewportObserver.current = undefined
    bodyRef.current = element
    if (element === null || typeof ResizeObserver === 'undefined') return
    const update = (): void => element.style.setProperty('--dsh-claude-diff-viewport', `${element.clientWidth}px`)
    update()
    const observer = new ResizeObserver(update)
    observer.observe(element)
    diffViewportObserver.current = observer
  }, [])
  useEffect(() => () => diffViewportObserver.current?.disconnect(), [])
  const closeDialog = useCallback(() => {
    if (dialog?.submitting === true) return
    actionController.current?.abort()
    actionController.current = undefined
    setDialog(undefined)
  }, [dialog?.submitting])
  const openAction = useCallback((action: RepositoryActionKind) => {
    actionController.current?.abort()
    setMenuOpen(false)
    setDialog({ action, loading: true, submitting: false })
    setMessage('')
    setPrTitle('')
    setPrBody('')
    setBaseBranch('')
    setDraft(true)
    const controller = new AbortController()
    actionController.current = controller
    void loadRepositoryActionPreview(sessionId, controller.signal, root).then(async preview => {
      setIncludeUnstaged(preview.hasUnstaged || preview.hasUntracked)
      if (action === 'push') {
        setDialog({ action, preview, loading: false, submitting: false })
        return
      }
      setDialog({ action, preview, loading: true, submitting: false })
      // The dialog is usable while the text is being written, so the
      // generated text only fills fields nobody has typed into, and lands on
      // whatever state the dialog reached in the meantime.
      if (action === 'create-pr') {
        // The pull request is described from the branch, not the tree: its
        // commits and diff against the base, plus what the commit before it
        // will add. The commit message covers the tree alone, when there is one.
        const [pullRequest, generated] = await Promise.all([
          generatePullRequestText(sessionId, preview.fingerprint, undefined, controller.signal, root),
          preview.files.length > 0 ? generateCommitMessage(sessionId, preview.fingerprint, controller.signal, root) : Promise.resolve(undefined),
        ])
        setMessage(current => (current.trim() === '' ? generated ?? pullRequest.title : current))
        setPrTitle(current => (current.trim() === '' ? pullRequest.title : current))
        setPrBody(current => (current.trim() === '' ? pullRequest.body : current))
      } else {
        const generated = await generateCommitMessage(sessionId, preview.fingerprint, controller.signal, root)
        setMessage(current => (current.trim() === '' ? generated : current))
      }
      setDialog(current => (current === undefined ? current : { ...current, loading: false }))
    }).catch(error => {
      if (!controller.signal.aborted) setDialog({ action, loading: false, submitting: false, error: error instanceof Error ? error.message : t('diffActionFailed') })
    })
  }, [root, sessionId, t])
  const confirm = useCallback(async () => {
    if (dialog?.preview === undefined || (dialog.action !== 'push' && message.trim().length === 0)) return
    const { error: _error, ...pending } = dialog
    setDialog({ ...pending, submitting: true })
    try {
      const result = await executeRepositoryAction(sessionId, {
        action: dialog.action,
        fingerprint: dialog.preview.fingerprint,
        message,
        includeUnstaged,
        ...(dialog.action === 'create-pr' ? { prTitle, prBody, ...(baseBranch.trim() === '' ? {} : { baseBranch }), draft } : {}),
      }, root)
      report(result.pullRequestUrl === undefined
        ? t(dialog.action === 'push' ? 'diffPushCompleted' : 'diffCommitCompleted', { commit: result.commit.slice(0, 8) })
        : t('diffPrCompleted'))
      setDialog(undefined)
    } catch (error) {
      const completedCommit = typeof error === 'object' && error !== null && 'commit' in error && typeof error.commit === 'string' ? error.commit : undefined
      setDialog({ ...dialog, submitting: false, error: error instanceof Error ? error.message : t('diffActionFailed'), ...(completedCommit === undefined ? {} : { commit: completedCommit }) })
    }
  }, [baseBranch, dialog, draft, includeUnstaged, message, prBody, prTitle, report, root, sessionId, t])
  // Discarding work cannot be undone, so the file count comes from a fresh
  // preview, the reader confirms it in the panel's own dialog, and the revert
  // runs against that exact fingerprint: a tree that moved in between is
  // refused, not half-reverted.
  const [revertDialog, setRevertDialog] = useState<{
    readonly paths?: readonly string[]
    readonly preview?: RepositoryActionPreview
    readonly count: number
    readonly submitting: boolean
    readonly error?: string
  }>()
  const requestRevert = useCallback((paths?: readonly string[]) => {
    setRevertDialog({ ...(paths === undefined ? {} : { paths }), count: 0, submitting: false })
    void loadRepositoryActionPreview(sessionId, undefined, root).then(preview => {
      const count = paths === undefined ? preview.files.length : preview.files.filter(file => paths.includes(file.path)).length
      if (count === 0) {
        setRevertDialog(undefined)
        report(t('diffRevertNothing'))
        return
      }
      setRevertDialog(current => (current === undefined ? current : { ...current, preview, count }))
    }, error => {
      setRevertDialog(current => (current === undefined ? current : { ...current, error: error instanceof Error ? error.message : t('diffActionFailed') }))
    })
  }, [report, root, sessionId, t])
  const confirmRevert = useCallback(async () => {
    if (revertDialog?.preview === undefined || revertDialog.submitting) return
    const { error: _error, ...pending } = revertDialog
    setRevertDialog({ ...pending, submitting: true })
    try {
      const result = await executeRepositoryAction(sessionId, {
        action: 'revert',
        fingerprint: revertDialog.preview.fingerprint,
        message: '',
        includeUnstaged: true,
        ...(revertDialog.paths === undefined ? {} : { paths: revertDialog.paths }),
      }, root)
      setRevertDialog(undefined)
      report(t('diffRevertCompleted', { count: result.reverted ?? revertDialog.count }))
    } catch (error) {
      setRevertDialog({ ...pending, submitting: false, error: error instanceof Error ? error.message : t('diffActionFailed') })
    }
  }, [report, revertDialog, root, sessionId, t])
  const reverting = revertDialog !== undefined
  const openCommentEditor = useCallback((path: string, anchor: ReviewCommentAnchor) => {
    setCommentEditor({ path, ...anchor })
    setCommentDraft('')
    setCommentError(undefined)
  }, [])
  const closeCommentEditor = useCallback(() => {
    setCommentEditor(undefined)
    setCommentDraft('')
    setCommentError(undefined)
  }, [])
  const submitComment = useCallback(async () => {
    if (commentEditor === undefined || commentDraft.trim().length === 0 || commentBusy) return
    setCommentBusy(true)
    setCommentError(undefined)
    try {
      const created = await addReviewComment(sessionId, {
        path: commentEditor.path,
        line: commentEditor.line,
        ...(commentEditor.startLine === undefined ? {} : { startLine: commentEditor.startLine }),
        side: commentEditor.side,
        text: commentDraft.trim(),
      })
      setLocalComments(list => [...list, created])
      closeCommentEditor()
    } catch (error) {
      setCommentError(error instanceof Error ? error.message : t('reviewCommentFailed'))
    } finally {
      setCommentBusy(false)
    }
  }, [closeCommentEditor, commentBusy, commentDraft, commentEditor, sessionId, t])
  const removeComment = useCallback((id: string) => {
    setRemovedCommentIds(previous => new Set([...previous, id]))
    void removeReviewComment(sessionId, id).catch(() => {
      setRemovedCommentIds(previous => {
        const next = new Set(previous)
        next.delete(id)
        return next
      })
    })
  }, [sessionId])
  // Locally added comments only bridge the polling gap: once the projection
  // reports an id, the server copy is authoritative — dropping the local copy
  // lets removals made elsewhere (e.g. the composer chips) disappear here too.
  useEffect(() => {
    const projected = new Set((projection.reviewComments ?? []).map(comment => comment.id))
    setLocalComments(list => (list.some(comment => projected.has(comment.id))
      ? list.filter(comment => !projected.has(comment.id))
      : list))
    setRemovedCommentIds(previous => {
      const kept = [...previous].filter(id => projected.has(id))
      return kept.length === previous.size ? previous : new Set(kept)
    })
  }, [projection.reviewComments])
  const reviewComments = useMemo(() => {
    const merged = new Map<string, ReviewComment>()
    for (const comment of projection.reviewComments ?? []) merged.set(comment.id, comment)
    for (const comment of localComments) merged.set(comment.id, comment)
    for (const id of removedCommentIds) merged.delete(id)
    return [...merged.values()]
  }, [localComments, projection.reviewComments, removedCommentIds])
  const targets = useMemo(() => reviewTargets(files, reviewComments, ghThreads), [files, ghThreads, reviewComments])
  // Comments come and go while the panel is open; a cursor past the end would
  // otherwise report "5/3".
  useEffect(() => {
    setTargetIndex(index => (index < targets.length ? index : 0))
  }, [targets.length])
  const goToComment = useCallback((direction: 'ArrowDown' | 'ArrowUp'): void => {
    setTargetIndex((current) => {
      if (targets.length === 0) return current
      const next = menuNavigationIndex(current, targets.length, direction)
      const target = targets[next]
      if (target !== undefined) {
        setActiveTargetKey(target.key)
        setPendingScrollKey(target.key)
        // Opening in the same commit as the scroll request keeps the anchor in
        // the DOM by the time the effect below looks for it.
        setFileOpen(target.path, true)
      }
      return next
    })
  }, [setFileOpen, targets])
  // The file section opens in the same render as the reveal, so by the time
  // this effect runs the anchor is in the DOM.
  useEffect(() => {
    if (pendingScrollKey === undefined) return
    bodyRef.current?.querySelector(`[data-review-target="${pendingScrollKey}"]`)?.scrollIntoView({ block: 'center' })
    setPendingScrollKey(undefined)
  }, [pendingScrollKey])
  useEffect(() => {
    if (targets.length === 0) return
    const shortcut = (event: KeyboardEvent): void => {
      if (event.ctrlKey || event.metaKey || event.altKey) return
      // A composer owns its letters; only a reader outside one is navigating.
      const origin = event.target
      if (origin instanceof HTMLElement
        && (origin.isContentEditable || origin.tagName === 'INPUT' || origin.tagName === 'TEXTAREA' || origin.tagName === 'SELECT')) return
      if (event.key !== 'n' && event.key !== 'p') return
      event.preventDefault()
      goToComment(event.key === 'n' ? 'ArrowDown' : 'ArrowUp')
    }
    document.addEventListener('keydown', shortcut)
    return () => { document.removeEventListener('keydown', shortcut) }
  }, [goToComment, targets.length])
  useEffect(() => () => actionController.current?.abort(), [])
  useEffect(() => {
    if (!projection.owned || repository?.status !== 'ready' || diff === undefined) closeDetails()
  }, [closeDetails, diff, projection.owned, repository?.status])
  if (!projection.owned || repository?.status !== 'ready' || diff === undefined) return null
  const branch = branchLabel(repository, t)
  const availability = repositoryActionAvailability(repository)
  const anyActionAvailable = availability['commit'] || availability['commit-push'] || availability['push'] || availability['create-pr']
  const menuItems: readonly MenuEntry[] = [
    { id: 'commit', label: t('diffCommit'), disabled: !availability['commit'] },
    { id: 'commit-push', label: t('diffCommitPush'), disabled: !availability['commit-push'] },
    { id: 'push', label: t('diffPush'), disabled: !availability['push'] },
    { id: 'create-pr', label: t('diffCreatePr'), disabled: !availability['create-pr'] },
  ]
  const allFilesOpen = files.every((file, index) => fileOpen(file.path, index))
  const commentEditorNode: ReactNode = commentEditor === undefined ? null : (
    <div style={styles.diffCommentBlock}>
      <div style={styles.diffCommentRange}>{commentLineLabel(commentEditor, t)}</div>
      <textarea
        className={styles.diffCommentTextareaClass}
        style={styles.diffCommentTextarea}
        value={commentDraft}
        maxLength={2000}
        placeholder={t('reviewCommentPlaceholder')}
        autoFocus
        onChange={event => setCommentDraft(event.currentTarget.value)}
      />
      {commentError !== undefined ? <p style={styles.diffCommentError}>{commentError}</p> : null}
      <div style={styles.diffCommentActions}>
        <button type="button" style={styles.diffCommentActionButton} onClick={closeCommentEditor}>{t('reviewCommentCancel')}</button>
        <button type="button" style={{ ...styles.diffCommentActionButton, ...styles.diffCommentSubmitButton }} disabled={commentBusy || commentDraft.trim().length === 0} onClick={() => void submitComment()}>{t('reviewCommentSubmit')}</button>
      </div>
    </div>
  )
  return (
    <>
      {toast}
      <style data-dsh-claude-repository-modal-styles>{styles.detailsCardCss}{styles.diffModalCss}{styles.panelIconButtonCss}{styles.diffCommentCss}{styles.diffCommentMarkdownCss}{styles.diffRepositoryCss}</style>
      <div className={styles.detailsCardClass} style={styles.diffPanel}>
        <header style={styles.diffHeader}>
          <div style={styles.diffHeaderTitle}>
            {repositories.length < 2 ? null : <>
              <Menu open={repositoryMenuOpen} items={repositoryItems} selectedId={repository.root ?? repository.cwd} onSelect={(id: string) => { setSelectedRoot(id); setRepositoryMenuOpen(false) }} onClose={() => setRepositoryMenuOpen(false)} portal compact anchor={
                <button type="button" className={styles.diffRepositoryTriggerClass} aria-label={t('diffRepository')} aria-haspopup="menu" aria-expanded={repositoryMenuOpen} onClick={() => setRepositoryMenuOpen(value => !value)}>
                  <span>{repositoryLabel(repository)}</span><IconChevronDownOutlineRegular />
                </button>
              } />
              <span aria-hidden="true">›</span>
            </>}
            <span style={styles.diffHeaderBranch} title={branch}>{branch}</span>
          </div>
          <div style={styles.diffHeaderActions}>
            {files.length === 0 || !availability['commit'] ? null : (
              <button type="button" style={{ ...styles.button, ...styles.diffRevertAllButton }} disabled={reverting} onClick={() => requestRevert()}>{t('diffRevertAll')}</button>
            )}
            <div style={styles.diffSplitButton}>
              <button type="button" style={{ ...styles.diffCommitButton, ...(availability['commit'] ? {} : styles.diffActionDisabled) }} disabled={!availability['commit']} onClick={() => openAction('commit')}>{t('diffCommit')}</button>
              <Menu open={menuOpen} items={menuItems} onSelect={(id: string) => { if (availability[id as PanelActionKind]) openAction(id as PanelActionKind) }} onClose={() => setMenuOpen(false)} align="end" portal anchor={
                <button type="button" style={{ ...styles.diffCommitMenuButton, ...(anyActionAvailable ? {} : styles.diffActionDisabled) }} disabled={!anyActionAvailable} aria-label={t('diffCommitMenu')} aria-expanded={menuOpen} onClick={() => setMenuOpen(value => !value)}><IconChevronDownOutlineRegular /></button>
              } />
            </div>
            {targets.length === 0 ? null : (
              <div style={styles.diffCommentNav}>
                <button
                  type="button"
                  className={styles.panelIconButtonClass}
                  aria-label={t('diffCommentPrevious')}
                  title={t('diffCommentPosition', { index: targetIndex + 1, total: targets.length })}
                  onClick={() => goToComment('ArrowUp')}
                >
                  <IconChevronUpOutlineRegular />
                </button>
                <span style={styles.diffCommentNavCount}>{t('diffCommentCounter', { index: targetIndex + 1, total: targets.length })}</span>
                <button
                  type="button"
                  className={styles.panelIconButtonClass}
                  aria-label={t('diffCommentNext')}
                  title={t('diffCommentPosition', { index: targetIndex + 1, total: targets.length })}
                  onClick={() => goToComment('ArrowDown')}
                >
                  <IconChevronDownOutlineRegular />
                </button>
              </div>
            )}
            {openThreadCount > 0 && submitPrompt !== undefined ? (
              <button type="button" style={styles.diffPrCommentsButton} title={t('prCommentsSend')} aria-label={t('prCommentsButton', { count: openThreadCount })} onClick={() => submitPrompt(composeCommentsPrompt(ghThreads))}>
                <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M2.75 2.75h10.5a1 1 0 0 1 1 1v6.5a1 1 0 0 1-1 1H8.2l-3.2 2.9v-2.9H2.75a1 1 0 0 1-1-1v-6.5a1 1 0 0 1 1-1Z" />
                </svg>
                {openThreadCount}
              </button>
            ) : null}
            <button type="button" className={styles.panelIconButtonClass} aria-label={t('diffClose')} onClick={closeDetails}><IconCloseOutlineRegular /></button>
          </div>
        </header>
        <div style={styles.diffSummary}>
          <span>{t('diffFiles', { count: diff.files })}</span>
          <span style={styles.diffAdd}>+{diff.additions}</span>
          <span style={styles.diffDelete}>−{diff.deletions}</span>
          {files.length === 0 ? null : (
            <Tooltip label={allFilesOpen ? t('diffCollapseAll') : t('diffExpandAll')} side="bottom" delayMs={250}>
              <button
                type="button"
                className={styles.panelIconButtonClass}
                style={styles.diffSummaryAction}
                aria-label={allFilesOpen ? t('diffCollapseAll') : t('diffExpandAll')}
                onClick={() => { setOpenFiles(new Map(files.map(file => [file.path, !allFilesOpen]))) }}
              >
                {allFilesOpen ? <IconChevronDownOutlineRegular /> : <IconChevronRightOutlineRegular />}
              </button>
            </Tooltip>
          )}
        </div>
        <div ref={diffBodyRef} style={styles.diffBody}>
          {diff.truncated ? <p style={styles.diffNotice}>{t('diffTruncated')}</p> : null}
          {diff.elided !== undefined && diff.elided.length > 0
            ? <p style={styles.diffNotice}>{t('diffElided', { count: diff.elided.length, files: diff.elided.join(', ') })}</p>
            : null}
          {files.length === 0 ? <p style={styles.diffEmpty}>{t('diffEmpty')}</p> : files.map((file, index) => (
            <DiffFileSection
              key={file.path}
              file={file}
              root={repository.pullRequestOnly === true ? undefined : repository.root}
              open={fileOpen(file.path, index)}
              onOpenChange={open => { setFileOpen(file.path, open) }}
              onRevert={availability['commit'] ? () => { if (!reverting) requestRevert([file.path]) } : undefined}
              t={t}
              comments={reviewComments.filter(comment => comment.path === file.path)}
              ghThreads={ghThreads.filter(thread => thread.path === file.path)}
              suggestMention={suggestMention}
              now={threadsLoadedAt}
              activeTargetKey={activeTargetKey}
              onReplyToThread={replyToThread}
              onThreadResolvedChange={changeThreadResolved}
              onSendThreadToAi={submitPrompt === undefined ? undefined : thread => { submitPrompt(composeCommentsPrompt([thread])) }}
              editorAnchor={commentEditor !== undefined && commentEditor.path === file.path ? commentEditor : undefined}
              editorNode={commentEditorNode}
              onOpenEditor={anchor => openCommentEditor(file.path, anchor)}
              onRemoveComment={removeComment}
            />
          ))}
        </div>
      </div>
      <Modal className="dshClaudeRepositoryActionModal" contentClassName="dshClaudeRepositoryActionModalContent" open={revertDialog !== undefined} onClose={() => { if (revertDialog?.submitting !== true) setRevertDialog(undefined) }} title={revertDialog?.paths?.length === 1 ? t('diffRevertFile') : t('diffRevertAll')} closeLabel={t('diffCancel')} footer={
        <div style={styles.diffModalFooter}>
          <button type="button" style={{ ...styles.button, ...styles.diffModalButton }} disabled={revertDialog?.submitting === true} onClick={() => setRevertDialog(undefined)}>{t('diffCancel')}</button>
          <button type="button" style={{ ...styles.primaryButton, ...styles.diffModalButton, ...styles.diffDangerButton }} disabled={revertDialog?.preview === undefined || revertDialog.submitting} onClick={() => void confirmRevert()}>{revertDialog?.submitting === true ? t('diffSubmitting') : t('diffRevertConfirmAction')}</button>
        </div>
      }>
        <div style={styles.diffModalBody}>
          {revertDialog?.preview === undefined && revertDialog?.error === undefined
            ? <p className="dshClaudeCommitProgress" role="status">{t('diffLoadingPreview')}</p>
            : revertDialog?.preview === undefined ? null
            : <p style={styles.diffRevertQuestion}>{revertDialog.paths?.length === 1
              ? t('diffRevertFileConfirm', { path: revertDialog.paths[0] ?? '' })
              : t('diffRevertAllConfirm', { count: revertDialog.count })}</p>}
          {revertDialog?.error === undefined ? null : <p style={styles.diffModalError} role="alert">{revertDialog.error}</p>}
        </div>
      </Modal>
      <Modal className="dshClaudeRepositoryActionModal dshClaudeCommitDialog" contentClassName="dshClaudeRepositoryActionModalContent dshClaudeCommitContent" open={dialog !== undefined} onClose={closeDialog} title={dialog === undefined ? t('diffCommit') : actionLabel(dialog.action, t)} closeLabel={t('diffCancel')} footer={
        <div style={styles.diffModalFooter}>
          <button type="button" style={{ ...styles.button, ...styles.diffModalButton }} disabled={dialog?.submitting === true} onClick={closeDialog}>{t('diffCancel')}</button>
          <button type="button" style={{ ...styles.primaryButton, ...styles.diffModalButton }} disabled={dialog?.submitting === true || dialog?.preview === undefined || (dialog.action !== 'push' && message.trim() === '')} onClick={() => void confirm()}>{dialog?.submitting === true ? t('diffSubmitting') : dialog === undefined ? t('diffCommit') : actionLabel(dialog.action, t)}</button>
        </div>
      }>
        {dialog?.loading === true ? <p className="dshClaudeCommitProgress" role="status">{t(dialog.preview === undefined ? 'diffLoadingPreview' : 'diffGeneratingMessage')}</p> : null}
        {dialog?.preview !== undefined ? <div style={styles.diffModalBody}>
          <div className="dshClaudeCommitContext">
            <strong title={dialog.preview.root}>{repositoryLabel({ root: dialog.preview.root, cwd: dialog.preview.root })}</strong>
            <span className="dshClaudeCommitBranch">{dialog.preview.branch}</span>
            {dialog.action === 'push' || dialog.action === 'commit-push' ? <><span aria-hidden="true">→</span><span className="dshClaudeCommitBranch">{dialog.preview.upstream ?? `origin/${dialog.preview.branch}`}</span></> : null}
          </div>
          {dialog.action === 'push' ? <>
            <section className="dshClaudeCommitSection">
              <h3>{t('diffPushAhead', { count: dialog.preview.unpushedTruncated ? `${dialog.preview.unpushedCommits.length}+` : dialog.preview.unpushedCommits.length })}</h3>
              <div className="dshClaudeCommitFiles">{dialog.preview.unpushedCommits.map(commit => <div key={commit.hash} className="dshClaudeCommitFile"><code className="dshClaudeCommitHash">{commit.hash.slice(0, 8)}</code><span className="dshClaudeCommitPath" title={commit.subject}>{commit.subject}</span></div>)}</div>
            </section>
            <p style={styles.diffModalStatus}>{t('diffPushDescription')}</p>
          </> : <div className="dshClaudeCommitGrid">
            <section className="dshClaudeCommitSection dshClaudeCommitChanges">
              <h3>{t('diffFilesShort', { count: dialog.preview.files.length })}</h3>
              <div className="dshClaudeCommitFiles">{dialog.preview.files.map(file => <div key={file.path} className="dshClaudeCommitFile"><span className="dshClaudeCommitPath" title={file.path}>{file.path}</span><span className="dshClaudeCommitState" data-staged={file.staged && !file.unstaged && !file.untracked}>{file.untracked ? t('diffUntracked') : file.staged && file.unstaged ? t('diffStagedUnstaged') : file.staged ? t('diffStaged') : t('diffUnstaged')}</span></div>)}</div>
              <label style={styles.diffModalCheckbox}><input type="checkbox" checked={includeUnstaged} disabled={!dialog.preview.hasUnstaged && !dialog.preview.hasUntracked} onChange={event => setIncludeUnstaged(event.currentTarget.checked)} />{t('diffIncludeUnstaged')}</label>
            </section>
            <div className="dshClaudeCommitEditor">
              {dialog.action === 'create-pr' ? <>
                <label style={styles.diffModalField}>{t('diffPrTitle')}<input style={{ ...styles.diffModalTextInput, fontWeight: 400 }} value={prTitle} maxLength={256} onChange={event => setPrTitle(event.currentTarget.value)} /></label>
                <label style={styles.diffModalField}>{t('diffPrBase')}<input style={{ ...styles.diffModalTextInput, fontWeight: 400 }} value={baseBranch} maxLength={512} placeholder={t('diffPrBaseDefault')} onChange={event => setBaseBranch(event.currentTarget.value)} /></label>
                <label style={styles.diffModalField}>{t('diffPrDescription')}<textarea style={{ ...styles.diffModalTextarea, fontWeight: 400, minHeight: 180 }} value={prBody} maxLength={8192} onChange={event => setPrBody(event.currentTarget.value)} /></label>
                <label style={styles.diffModalCheckbox}><input type="checkbox" checked={draft} onChange={event => setDraft(event.currentTarget.checked)} />{t('diffPrDraft')}</label>
              </> : null}
              <label style={styles.diffModalField}>{t('diffCommitMessage')}<textarea style={{ ...styles.diffModalTextarea, fontWeight: 400, minHeight: dialog.action === 'create-pr' ? 100 : 220 }} value={message} maxLength={2048} placeholder={t('diffCommitMessagePlaceholder')} onChange={event => setMessage(event.currentTarget.value)} /></label>
              <p className="dshClaudeCommitHint">{t('diffCommitMessageHint')}</p>
            </div>
          </div>}
        </div> : null}
        {dialog?.error !== undefined ? <p role="alert" style={styles.diffModalError}>{dialog.error}{dialog.commit === undefined ? '' : ` ${t('diffCommitPreserved', { commit: dialog.commit.slice(0, 8) })}`}</p> : null}
      </Modal>
    </>
  )
}
