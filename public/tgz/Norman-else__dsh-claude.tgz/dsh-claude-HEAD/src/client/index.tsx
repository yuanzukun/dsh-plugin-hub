import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type { Context } from '@deepseek-ai/cordis'
import type { SessionId } from '@deepseek-ai/dsh-client-connection/client'
import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client'
import type { IWorkspaces } from '@deepseek-ai/dsh-api-workspace-controller/client'
import type { SessionInput } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { IConversation } from '@deepseek-ai/dsh-client-ui-conversation/client'

/** What `sessions.scope()` hands back; see {@link sessionInput}. */
type SessionScope = NonNullable<ReturnType<ISessions['scope']>>
import type {} from '@deepseek-ai/dsh-client-ui-chat/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-session/client'
import type {} from '@deepseek-ai/dsh-client-ui-input-trigger/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-ui-slots'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import { claudeActivityStepDefinition, claudeTurnDefinition } from './conversation-sidecar.ts'
import { ClaudeActivityTail, type ClaudeActivityTailInjected } from './ClaudeActivityTail.tsx'
import { ClaudeActivityNode, type ClaudeActivityNodeInjected } from './ClaudeActivityNode.tsx'
import { backgroundToolCall } from './background-task-api.ts'
import { cachedExists, sessionFileAddress, type FileMentionSource } from './file-mentions.ts'
import { ClaudeCodeSettings, isGlobalSettingsView, proseModeOf, type ClaudeCodeSettingsInjected } from './ClaudeCodeSettings.tsx'
import { applyClaudeMarkdownTheme } from './markdown-theme.ts'
import { pluginRead } from './plugin-transport.ts'
import { CLAUDE_GLOBAL_SETTINGS_PATH } from '../constants.ts'
import { ClaudePlanHeaderAction, type ClaudePlanHeaderActionInjected } from './ClaudePlanHeaderAction.tsx'
import { ClaudeRepositoryStatus, type ClaudeRepositoryStatusInjected } from './ClaudeRepositoryStatus.tsx'
import { ClaudeReviewComments, type ClaudeReviewCommentsInjected } from './ClaudeReviewComments.tsx'
import { CLAUDE_TAB_KINDS, registerClaudeSidebarTabs } from './sidebar-tabs.tsx'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar-right/client'
import { ClaudeSelectionAsk } from './ClaudeSelectionAsk.tsx'
import { claudeBootCheckFindings } from './boot-check.ts'
import { watchClaudeComposerBar } from './composer-style-probe.ts'
import { createClaudeDiagnosticsReporter } from './client-diagnostics.ts'
import { ClaudeRewind, EMPTY_CHAT_VIEW, type ClaudeChatSource, type ClaudeChatView, type ClaudeRewindInjected } from './ClaudeRewind.tsx'
import { ClaudeHeroRepositoryControls, type ClaudeHeroRepositoryControlsInjected } from './ClaudeHeroRepositoryControls.tsx'
import { ClaudeDiffHeaderAction, type ClaudeDiffHeaderActionInjected } from './ClaudeDiffHeaderAction.tsx'
import { ClaudeTeamHeaderAction, type ClaudeTeamHeaderActionInjected } from './ClaudeTeamHeaderAction.tsx'
import { ClaudeAgentPresetLabel, type ClaudeAgentPresetLabelInjected } from './ClaudeAgentPresetLabel.tsx'
import { AgentPresetRoster, type AgentPresetRosterApi } from './agent-preset-roster.ts'
import { ClaudeProjectionStore, type ClaudeProjectionSource } from './projection.ts'
import { createClaudeCommandSource } from './claude-command-source.ts'
import { ClaudePromptSaveAction, type ClaudePromptSaveActionInjected } from './ClaudePromptSaveAction.tsx'
import { ClaudePermissionSelect, type ClaudePermissionSelectInjected } from './ClaudePermissionSelect.tsx'
import { setClaudePermissionMode } from './permission-mode-api.ts'
import { ClaudePromptRefineAction, type ClaudePromptRefineActionInjected } from './ClaudePromptRefineAction.tsx'
import { ClaudePromptSuggestion, type ClaudePromptSuggestionInjected } from './ClaudePromptSuggestion.tsx'
import { createClaudePromptSource } from './claude-prompt-source.ts'
import { restyleHostChrome } from './host-chrome.ts'
import { bindRepositoryLease, prepareRepository, sweepWorktrees, type RepositoryPreparationStage } from './repository-setup-api.ts'
import { assignJiraTicket, ticketContext, ticketPrompt } from './jira-api.ts'
import { en, zh, type ClaudeCodeSettingsKey } from './locales.ts'
import { mainSessionId } from './main-session.ts'
import { releaseAfterSubmission, retainForHandoff } from './session-handoff.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface SlotMap {
    'shell.overlay': { kind: 'list'; scope: 'root' }
  }
}

interface UiSessionFace {
  provide(descriptor: {
    hooks: string[]
    resolve(binding: { sessionId: string }): { hooks: { claudeProjection: ClaudeProjectionSource } }
  }): () => void
}

interface UiConversationFace {
  events: {
    register(definition: unknown): () => void
  }
  /** Throws for a session the Controller does not hold, so callers must guard. */
  binding(sessionId: string): {
    target(target: string): { subscribe(listener: () => void): () => void; getSnapshot(): unknown }
  }
}

interface UiWorkspaceFace {
  connectWorkspace?(workspaceId: string): Promise<SessionId>
  openSession?(sessionId: SessionId): void
}

interface AgentPresetRemote {
  list(): Promise<{ ok: true; value: { presets: readonly import('./agent-preset-roster.ts').AgentPresetRow[] } } | { ok: false }>
  select(sessionId: string, agentPreset: string): Promise<{ ok: true; value: string } | { ok: false; error: { message: string } }>
}

interface RemoteFace {
  agentPresets: AgentPresetRemote
  /** Host `dsh-api-workspace-files`; absent when the bundle leaves it out. */
  workspaceFiles?: { stat(sessionId: string, path: string, signal?: AbortSignal): Promise<{ ok: boolean }> }
}

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    'settings.claude-code': ClaudeCodeSettingsKey
  }
}

export const name = 'dsh-claude-client'

export const inject = ['slots', 'locale', 'remote', 'remote.agentPresets', 'remote.workspaceFiles', 'sessions', 'uiSession', 'uiConversation', 'workspaces', 'inputTriggers', 'conversation', 'connection', 'sidebarRight', 'sidebarRightTabs']

/** Resolve one session's composer facade.
 *
 *  `sessions.scope()` returns the client runtime's AgentContext, and the
 *  conversation package -- a release ahead of the runtime in the graph the Host
 *  itself ships -- types `input.for` against a Context whose `remote` has since
 *  gained `$stream` and `$host`. It is the same object at runtime; only the two
 *  declarations disagree, and they disagree inside the Host too, so the cast
 *  lives here once instead of at all nine call sites. */
function sessionInput(conversation: IConversation, scope: SessionScope): SessionInput {
  return conversation.input.for(scope as never)
}

export function apply(ctx: Context): void {
  const namespace = 'settings.claude-code'
  const diagnostics = createClaudeDiagnosticsReporter()
  // Assert the Host still matches this package's assumptions. The Desktop build
  // ships no type declarations, so tsc validates against whatever @deepseek-ai/*
  // happens to be installed rather than the Host this runs inside; drift is
  // invisible until a feature silently stops appearing.
  for (const finding of claudeBootCheckFindings({
    services: [...inject, 'uiWorkspace'],
    resolve: name => ctx.get(name),
  })) diagnostics.report('boot-check', finding)
  // The scoped custom properties cannot be read here: the Host publishes them
  // onto the composer subtree, and inheritance means only an element inside it
  // sees one. Probe the plugin's own bar once it mounts instead.
  ctx.effect(() => watchClaudeComposerBar(finding => {
    diagnostics.report('boot-check', finding)
  }), 'dsh-claude: composer style drift probe')
  ctx.effect(() => ctx.locale.register(namespace, { zh, en }), 'dsh-claude: client copy')
  const t = ctx.locale.bind(namespace) as ClaudeCodeSettingsInjected['t']
  ctx.effect(() => restyleHostChrome(() => t('presetClaudeDescription')), 'dsh-claude: Host chrome restyling')
  // The prose palette is a Client-side setting the Settings panel may never be
  // opened to deliver, so read it once at boot. Deliberately unawaited and
  // silently swallowed: a Host that cannot answer leaves the sheet on its
  // default rather than blocking the rest of `apply`.
  void pluginRead(CLAUDE_GLOBAL_SETTINGS_PATH, 'fast')
    .then(payload => {
      if (!isGlobalSettingsView(payload)) return
      applyClaudeMarkdownTheme(proseModeOf(payload.settings))
    })
    .catch(() => {})
  // A carrier that loses a line leaves the projection quietly behind the
  // server; the store resyncs itself, and says so here rather than letting a
  // finished tool group pulse forever with a clean log.
  const projections = new ClaudeProjectionStore({
    report: (kind, detail) => { diagnostics.report(kind, detail) },
  })
  ctx.effect(() => ctx.inputTriggers.registerSource(createClaudeCommandSource(ctx, projections)), 'dsh-claude: Claude slash source')
  // ponytail: the group title is fixed at registration, so a language switch
  // needs a reload to relabel it; subscribe to the locale if anyone minds.
  ctx.effect(() => ctx.inputTriggers.registerSource(createClaudePromptSource(t('promptSource'))), 'dsh-claude: Claude prompt source')
  const sessions = ctx.get('sessions') as ISessions | undefined
  const workspaces = ctx.get('workspaces') as IWorkspaces | undefined
  // Desktop 0.1.2 split the Workspace runtime in two: the `workspaces`
  // controller kept create/delete/list, while `connectWorkspace` moved to a
  // new `uiWorkspace` service. Host 0.1.7 also moved opening a Session there
  // (`sessions.open` is gone). The package ships no client declarations, so
  // this seat is typed locally.
  const uiWorkspace = ctx.get('uiWorkspace') as UiWorkspaceFace | undefined
  const connectWorkspace = uiWorkspace?.connectWorkspace?.bind(uiWorkspace)
  const openSession = (id: SessionId): void => { uiWorkspace?.openSession?.(id) }
  // Deleting a workspace only mutates the durable registry -- no agent edge,
  // no server-side event -- so the Host would never tell the plugin its
  // worktree is now unclaimed. Watching the list here is the only place that
  // knows, and the kick spares the user the sweep interval.
  if (workspaces !== undefined) {
    ctx.effect(() => {
      let known = new Set(workspaces.list.getSnapshot().items.map(item => item.workspaceId))
      return workspaces.list.subscribe(() => {
        const next = new Set(workspaces.list.getSnapshot().items.map(item => item.workspaceId))
        const removed = [...known].some(id => !next.has(id))
        known = next
        if (removed) void sweepWorktrees().catch(() => undefined)
      })
    }, 'dsh-claude: worktree sweep on workspace deletion')
  }
  const conversation = ctx.get('conversation') as IConversation | undefined
  const connection = ctx.get('connection') as ConnectionHandle | undefined
  const remote = ctx.get('remote') as RemoteFace | undefined
  /** Composer submit hook shared by the repository feedback affordances.
   *  'append' keeps any user draft and adds the prompt below it; 'idle'
   *  submits only when the composer is empty and reports false otherwise. */
  const submitPromptFor = (sessionId: string): ((draft: string, mode?: 'append' | 'idle') => boolean) | undefined => {
    if (sessions === undefined || conversation === undefined) return undefined
    return (draft, mode = 'append') => {
      const scope = sessions.scope(sessionId as SessionId)
      if (scope === undefined) return false
      const input = sessionInput(conversation, scope)
      const current = input.state.getSnapshot().draft
      if (current.trim() === '') input.setDraft(draft)
      else if (mode === 'append') input.setDraft(`${current}\n\n${draft}`)
      else return false
      input.submit()
      return true
    }
  }
  const uiSession = ctx.get('uiSession') as UiSessionFace | undefined
  if (uiSession !== undefined) {
    ctx.effect(() => uiSession.provide({
      hooks: ['claudeProjection'],
      resolve: binding => ({ hooks: { claudeProjection: projections.source(binding.sessionId) } }),
    }), 'dsh-claude: sidecar projection provider')
  }
  ctx.effect(() => () => projections.dispose(), 'dsh-claude: sidecar projection lifecycle')
  // Desktop 2.0 publishes the target-neutral Conversation registry through
  // uiConversation. Registering against the removed conversationEvents service
  // never fires, leaving a live sidecar projection with no custom Chat nodes.
  const uiConversation = ctx.get('uiConversation') as UiConversationFace | undefined
  if (uiConversation !== undefined) {
    ctx.effect(() => uiConversation.events.register(claudeTurnDefinition), 'dsh-claude: Claude turn marker')
    ctx.effect(() => uiConversation.events.register(claudeActivityStepDefinition), 'dsh-claude: Claude activity flow node')
  }
  // The transcript node is always registered. Which renderer actually draws a
  // step is decided from the step's own records, not from a Client-side copy
  // of the setting: the Host switches on the next turn while a running Client
  // would keep a boot-time decision, and disagreeing draws everything twice.
  // A step the Host drew natively folds to no items and the node renders null.
  // One source per Session: its identity keys every message's lookups, and
  // its cache spares re-asking the Host about a path each render.
  const fileSources = new Map<string, FileMentionSource>()
  const filesFor = (sessionId: string): FileMentionSource | undefined => {
    const workspaceFiles = remote?.workspaceFiles
    if (workspaceFiles === undefined) return undefined
    let source = fileSources.get(sessionId)
    if (source === undefined) {
      source = {
        exists: cachedExists(async path => (await workspaceFiles.stat(sessionId, path)).ok),
        open: (path, line) => ctx.sidebarRight.openResourceIn(
          sessionId as SessionId,
          sessionFileAddress(sessionId, path),
          line === undefined ? undefined : { params: { line } as never },
        ),
      }
      fileSources.set(sessionId, source)
    }
    return source
  }
  ctx.slots.inject('conversation.chat.node', () => ctx.slots.register({
    name: 'conversation.chat.node',
    key: 'claude-activity-step',
    locale: namespace,
    // A running root Bash card offers the terminal's Ctrl+B.
    inject: (sessionId: string): ClaudeActivityNodeInjected => {
      const files = filesFor(sessionId)
      return {
        backgroundCall: toolUseId => backgroundToolCall(sessionId, toolUseId),
        ...(files === undefined ? {} : { files }),
      }
    },
  }, ClaudeActivityNode))
  // Host 0.1.5 has no details column: the panels are tab types of the
  // right sidebar, declared once here and opened per session below.
  const sidebarTabs = registerClaudeSidebarTabs(ctx, {
    t,
    namespace,
    diffFace: sessionId => {
      const submitPrompt = submitPromptFor(sessionId)
      return submitPrompt === undefined ? {} : { submitPrompt }
    },
  })
  const openDiffPanel = (sessionId: string, initialRoot?: string): void => {
    sidebarTabs.open(CLAUDE_TAB_KINDS.diff, sessionId, initialRoot === undefined ? {} : { initialRoot })
  }
  // Every Slot entry crash, not just the one this package knows how to recover.
  // The Host catches these and drops the entry, so an untold crash reads as
  // "the feature quietly vanished" — which is how each Desktop 2.0 breakage in
  // this package presented, with a clean Host log and a healthy boot report.
  ctx.effect(() => ctx.slots.onEntryError((key, entry, error) => {
    // Host 0.1.7 also reports Factory definitions, which carry a name, not options.
    const label = 'options' in entry ? entry.options.id : entry.name
    const id = label === undefined ? '' : ` id="${String(label)}"`
    const message = error instanceof Error
      ? `${error.message}
${error.stack ?? ''}`
      : String(error)
    diagnostics.report('slot-entry-crashed', `slot "${key}"${id}: ${message}`)
  }), 'dsh-claude: Slot entry failure reporting')
  ctx.slots.inject('conversation.chat.turnTail', () => ctx.slots.register({
    name: 'conversation.chat.turnTail',
    id: 'claude-activity-tail',
    inject: (): ClaudeActivityTailInjected => ({ t }),
  }, ClaudeActivityTail))
  // Icon-only diff trigger in the Session header's right-aligned utility
  // group. The action row next to the title is left-aligned (it rides inside
  // the flex:1 title cluster), so the utilities group is the actual top-right
  // corner — the seat the Host's hidden Session log capsule used to hold.
  // Shadow the Host's header preset label: same slot id, lower priority, so
  // one cell renders and it is this one. Only two things change — the native
  // `title` popup becomes the DSH tooltip bubble, and the Claude preset gets
  // its own mark instead of the generic preset glyph. Everything else is
  // reproduced, because this entry renders in every Session, not only
  // plugin-owned ones.
  if (remote !== undefined) {
    const roster = new AgentPresetRoster(remote.agentPresets as AgentPresetRosterApi)
    const hostT = ctx.locale.bind('settings.agentPreset')
    ctx.slots.inject('conversation.session.header.actions', () => ctx.slots.register({
      name: 'conversation.session.header.actions',
      id: 'agent-preset',
      order: -10,
      priority: -10,
      locale: namespace,
      inject: (): ClaudeAgentPresetLabelInjected => ({
        t,
        hostT: key => hostT(key as never),
        roster: { subscribe: roster.subscribe, getSnapshot: roster.getSnapshot, load: () => roster.load() },
      }),
    }, ClaudeAgentPresetLabel))
  }
  // Claude Code's own Agent Team in the Host roster's seat (its `agent-team`
  // entry sits at order -20 in this row and is hidden for Claude sessions by
  // host-chrome.ts): members, the shared task list, and mail, with a teammate
  // tab per member.
  ctx.slots.inject('conversation.session.header.actions', () => ctx.slots.register({
    name: 'conversation.session.header.actions',
    id: 'claude-team',
    order: -19,
    locale: namespace,
    inject: (sessionId: string): ClaudeTeamHeaderActionInjected => ({
      t,
      openTeammate: taskId => { sidebarTabs.open(CLAUDE_TAB_KINDS.teammate, sessionId, { teammate: taskId }) },
    }),
  }, ClaudeTeamHeaderAction))
  ctx.slots.inject('conversation.session.header.utilities', () => ctx.slots.register({
    name: 'conversation.session.header.utilities',
    id: 'claude-plan',
    order: 29,
    locale: namespace,
    inject: (sessionId: string): ClaudePlanHeaderActionInjected => ({
      t,
      togglePlan: () => { sidebarTabs.toggle(CLAUDE_TAB_KINDS.plan, sessionId, {}) },
      planOpen: sidebarTabs.sourceFor(CLAUDE_TAB_KINDS.plan, sessionId),
    }),
  }, ClaudePlanHeaderAction))
  ctx.slots.inject('conversation.session.header.utilities', () => ctx.slots.register({
    name: 'conversation.session.header.utilities',
    id: 'claude-diff',
    order: 30,
    locale: namespace,
    inject: (sessionId: string): ClaudeDiffHeaderActionInjected => ({
      t,
      toggleDiff: () => { sidebarTabs.toggle(CLAUDE_TAB_KINDS.diff, sessionId, {}) },
      diffOpen: sidebarTabs.sourceFor(CLAUDE_TAB_KINDS.diff, sessionId),
    }),
  }, ClaudeDiffHeaderAction))
  // In the composer's own tool row beside the attach and access controls: the
  // owner hands this slot the live draft, and an icon there costs the layout
  // nothing, where a docked row would move the composer on every keystroke.
  // Claude Code's own permission modes, in the seat the Host's three-mode
  // access selector holds for other presets (host-chrome.ts hides that one
  // for Claude sessions). First in the row, where the access control was.
  ctx.slots.inject('conversation.input.left', () => ctx.slots.register({
    name: 'conversation.input.left',
    id: 'claude-permission-mode',
    order: 30,
    locale: namespace,
    inject: (sessionId: string): ClaudePermissionSelectInjected => {
      const scope = sessions?.scope(sessionId as SessionId)
      return {
        t,
        setMode: mode => setClaudePermissionMode(sessionId, mode),
        ...(scope === undefined || conversation === undefined
          ? {}
          : { notify: (level, text) => { sessionInput(conversation, scope).notify(level, text) } }),
      }
    },
  }, ClaudePermissionSelect))
  // Draws nothing in the row: it only needs a seat inside the composer card
  // to find the editor it ghosts the next-prompt suggestion into.
  ctx.slots.inject('conversation.input.left', () => ctx.slots.register({
    name: 'conversation.input.left',
    id: 'claude-prompt-suggestion',
    order: 90,
    locale: namespace,
    inject: (sessionId: string): ClaudePromptSuggestionInjected => {
      const report = (detail: string): void => { diagnostics.report('prompt-suggestion', detail) }
      const scope = sessions?.scope(sessionId as SessionId)
      if (scope === undefined || conversation === undefined) return { report }
      const facade = sessionInput(conversation, scope)
      return { report, acceptDraft: text => { facade.setDraft(text) } }
    },
  }, ClaudePromptSuggestion))
  ctx.slots.inject('conversation.input.left', () => ctx.slots.register({
    name: 'conversation.input.left',
    id: 'claude-prompt-save',
    order: 40,
    locale: namespace,
    inject: (): ClaudePromptSaveActionInjected => ({ t }),
  }, ClaudePromptSaveAction))
  ctx.slots.inject('conversation.input.left', () => ctx.slots.register({
    name: 'conversation.input.left',
    id: 'claude-prompt-refine',
    order: 41,
    locale: namespace,
    inject: (sessionId: string): ClaudePromptRefineActionInjected => {
      if (sessions === undefined || conversation === undefined) return { t }
      const scope = sessions.scope(sessionId as SessionId)
      if (scope === undefined) return { t }
      const facade = sessionInput(conversation, scope)
      return {
        t,
        replaceDraft: text => { facade.setDraft(text) },
        notify: (level, text) => { facade.notify(level, text) },
      }
    },
  }, ClaudePromptRefineAction))
  ctx.slots.inject('conversation.input.dock', () => ctx.slots.register({
    name: 'conversation.input.dock',
    id: 'claude-review-comments',
    // Topmost dock row: pending comments render above DSH's QueueDock (20)
    // and the repository status readout (20.5).
    order: 18,
    locale: namespace,
    inject: (sessionId: string): ClaudeReviewCommentsInjected => ({
      t,
      sessionId,
      ...(sessions === undefined || conversation === undefined ? {} : {
        submitWith: (fallbackDraft: string) => {
          const scope = sessions.scope(sessionId as SessionId)
          if (scope === undefined) return
          const input = sessionInput(conversation, scope)
          if (input.state.getSnapshot().draft.trim() === '') input.setDraft(fallbackDraft)
          input.submit()
        },
      }),
    }),
  }, ClaudeReviewComments))
  ctx.slots.inject('conversation.input.dock', () => ctx.slots.register({
    name: 'conversation.input.dock',
    id: 'claude-repository-status',
    // Below DSH's QueueDock (20) and above the hero controls (21), so the
    // dock stacks comments (18) → queue (20) → repository readout.
    order: 20.5,
    locale: namespace,
    inject: (sessionId: string): ClaudeRepositoryStatusInjected => {
      const submitPrompt = submitPromptFor(sessionId)
      return {
        t,
        openDiff: root => openDiffPanel(sessionId, root),
        ...(submitPrompt === undefined ? {} : { submitPrompt }),
        ...(workspaces === undefined ? {} : {
          deleteWorkspace: async () => {
            const workspace = workspaces.list.getSnapshot().items.find(item => item.sessionIds.includes(sessionId as SessionId))
            if (workspace === undefined) return
            // Deleting a workspace drops its sessions into the unaccounted
            // group, so archive them first -- DSH's "delete session" is an
            // archive, and the worktree they point at is already gone.
            for (const id of workspace.sessionIds) await workspaces.archiveSession(id)
            await workspaces.delete(workspace.workspaceId)
          },
        }),
      }
    },
  }, ClaudeRepositoryStatus))
  // Selection toolbar over assistant replies (copy / ask a follow-up). Root
  // scoped: it resolves the on-screen session itself and only arms inside
  // sessions this plugin owns.
  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay',
    id: 'claude-selection-ask',
    locale: namespace,
  }, () => <ClaudeSelectionAsk
    t={t}
    currentSessionId={() => sessions === undefined ? undefined : mainSessionId(sessions.list.getSnapshot())}
    ownsSession={sessionId => projections.source(sessionId).getSnapshot().owned}
    {...(sessions === undefined || conversation === undefined ? {} : {
      insertIntoChat: (sessionId: string, text: string) => {
        const scope = sessions.scope(sessionId as SessionId)
        if (scope === undefined) return
        const input = sessionInput(conversation, scope)
        const current = input.state.getSnapshot().draft
        input.setDraft(current.trim() === '' ? text : `${current}\n\n${text}`)
      },
    })}
  />))
  /** Compose the chat view the rewind control reads.
   *
   *  Desktop 2.0 split what used to be one Session snapshot: the Controller's
   *  `binding.session` kept `running`, while the assembled Chat nodes moved to
   *  the Conversation binding's 'chat' target. Reading the old combined shape
   *  threw on `snapshot.chat.order` and took the whole overlay entry down. */
  const chatSourceCache = new Map<string, ClaudeChatSource>()
  const claudeChatSource = (sessionId: string): ClaudeChatSource | undefined => {
    const cached = chatSourceCache.get(sessionId)
    if (cached !== undefined) return cached
    if (sessions === undefined || uiConversation === undefined) return undefined
    const session = sessions.binding(sessionId as SessionId)?.session as unknown as {
      subscribe(listener: () => void): () => void
      getSnapshot(): { running?: boolean }
    } | undefined
    if (session === undefined) return undefined
    let chatTarget
    try {
      chatTarget = uiConversation.binding(sessionId).target('chat')
    } catch {
      return undefined
    }
    // useSyncExternalStore compares by identity, so the composed view must stay
    // the same object until one of its two inputs actually moves.
    let lastChat: unknown
    let lastRunning: boolean | undefined
    let view: ClaudeChatView = EMPTY_CHAT_VIEW
    const source: ClaudeChatSource = {
      subscribe(listener) {
        const dropChat = chatTarget.subscribe(listener)
        const dropSession = session.subscribe(listener)
        return () => { dropChat(); dropSession() }
      },
      getSnapshot() {
        const chat = chatTarget.getSnapshot()
        const running = session.getSnapshot().running === true
        if (chat === lastChat && running === lastRunning) return view
        lastChat = chat
        lastRunning = running
        view = chat === undefined
          ? EMPTY_CHAT_VIEW
          : { chat: chat as ClaudeChatView['chat'], running }
        return view
      },
    }
    chatSourceCache.set(sessionId, source)
    return source
  }
  // "Rewind to here" beside the copy action of every user message. Root
  // scoped like the selection toolbar: it resolves the on-screen session
  // itself and only arms inside sessions this plugin owns.
  if (sessions !== undefined) {
    // Stable prop identities: the control subscribes to them, so a re-render
    // of the seat must not tear down and rebuild every subscription.
    const rewind: ClaudeRewindInjected = {
      t,
      currentSessionId: () => mainSessionId(sessions.list.getSnapshot()),
      subscribeSessions: listener => sessions.list.subscribe(listener),
      chatOf: sessionId => claudeChatSource(sessionId),
      projectionOf: sessionId => projections.source(sessionId),
      ...(conversation === undefined ? {} : {
        setDraft: (sessionId: string, text: string) => {
          const scope = sessions.scope(sessionId as SessionId)
          if (scope === undefined) return
          sessionInput(conversation, scope).setDraft(text)
        },
      }),
    }
    ctx.slots.inject('shell.overlay', () => ctx.slots.register({
      name: 'shell.overlay',
      id: 'claude-rewind',
      locale: namespace,
    }, () => <ClaudeRewind {...rewind} />))
  }

  if (sessions !== undefined && workspaces !== undefined && connectWorkspace !== undefined && conversation !== undefined && connection !== undefined && remote !== undefined) {
    /** Attach a prepared worktree to its session without blocking the flow. */
    const bindLease = (leaseId: string | undefined, targetSessionId: SessionId): void => {
      if (leaseId === undefined) return
      void bindRepositoryLease(leaseId, targetSessionId).catch((reason: unknown) => {
        console.warn(`dsh-claude: could not bind the worktree lease: ${reason instanceof Error ? reason.message : String(reason)}`)
      })
    }
    /** The mode picked on the hero was recorded on the hero's session; a
     *  worktree session is a new one and would otherwise start on the default. */
    const carryPermissionMode = async (sourceSessionId: SessionId, targetSessionId: SessionId): Promise<void> => {
      const mode = projections.source(sourceSessionId).getSnapshot().permissionMode?.mode
      if (mode !== undefined) await setClaudePermissionMode(targetSessionId, mode)
    }
    ctx.slots.inject('conversation.input.dock', () => ctx.slots.register({
      name: 'conversation.input.dock',
      id: 'claude-hero-repository-controls',
      order: 21,
      locale: namespace,
      inject: (sourceSessionId: SessionId): ClaudeHeroRepositoryControlsInjected => ({
        t,
        prepare: async (cwd, branch, useWorktree, onProgress, ticket) => {
          const sourceScope = sessions.scope(sourceSessionId)
          if (sourceScope === undefined) throw new Error(t('repositorySessionUnavailable'))
          const sourceInput = sessionInput(conversation, sourceScope)
          const rawDraft = sourceInput.state.getSnapshot().draft
          // Starting from a ticket seeds an empty composer with the ticket
          // brief; a written draft keeps the user's words and gets the ticket
          // appended as context so the session always knows its ticket.
          const draft = ticket === undefined
            ? rawDraft
            : rawDraft.trim() === '' ? ticketPrompt(ticket) : `${rawDraft.trimEnd()}\n\n${ticketContext(ticket)}`
          const imageIds = sourceInput.state.getSnapshot().attachmentIds
          // No ticket to name the branch after: let the draft name it instead.
          const prepared = await prepareRepository(cwd, branch, useWorktree, ticket?.key, onProgress, ticket === undefined ? draft : undefined)
          // The workspace is ready: take the ticket. Best-effort so a Jira
          // hiccup never blocks the session from starting.
          if (ticket !== undefined) {
            void assignJiraTicket(ticket.key).catch((reason: unknown) => {
              console.warn(`dsh-claude: could not assign ${ticket.key}: ${reason instanceof Error ? reason.message : String(reason)}`)
            })
          }
          if (prepared.mode === 'checkout') {
            if (draft !== rawDraft) sourceInput.setDraft(draft)
            sourceInput.submit()
            return
          }
          onProgress('creating-workspace')
          const workspace = await workspaces.create({ path: prepared.path })
          onProgress('starting-session')
          const targetSessionId = await connectWorkspace(workspace.workspaceId)
          const reference = await retainForHandoff(sessions, targetSessionId)
          try {
            const targetScope = sessions.scope(targetSessionId)
            if (targetScope === undefined) throw new Error(t('repositorySessionUnavailable'))
            const presetResponse = await remote.agentPresets.select(targetSessionId, 'claude')
            if (!presetResponse.ok) throw new Error(presetResponse.error.message)
            await carryPermissionMode(sourceSessionId, targetSessionId)
            const targetInput = sessionInput(conversation, targetScope)
            onProgress('transferring-draft')
            if (imageIds.length > 0 && !targetInput.addAttachments(imageIds)) throw new Error(t('repositoryDraftTransferFailed'))
            if (draft !== '') targetInput.setDraft(draft)
            // Lease bookkeeping only matters at cleanup time, so it rides
            // alongside the submit the way the ticket assignment does. Awaiting
            // it here once left the prepared worktree holding the user's typed
            // message with no way to send it when the route was slow.
            bindLease(prepared.leaseId, targetSessionId)
            openSession(targetSessionId)
            onProgress('submitting')
            targetInput.submit()
          } catch (error) {
            reference.release()
            throw error
          }
          releaseAfterSubmission(reference)
          sourceInput.setDraft('')
          for (const imageId of imageIds) sourceInput.removeAttachment(imageId)
        },
        prepareMany: async (cwd, branch, tickets, onProgress) => {
          const sourceScope = sessions.scope(sourceSessionId)
          if (sourceScope === undefined) throw new Error(t('repositorySessionUnavailable'))
          const sourceInput = sessionInput(conversation, sourceScope)
          // One shared draft applies to every ticket; images stay behind
          // because a single attachment cannot be split across sessions.
          const rawDraft = sourceInput.state.getSnapshot().draft
          const failures: string[] = []
          for (const [index, ticket] of tickets.entries()) {
            const report = (stage: RepositoryPreparationStage): void => {
              onProgress({ ticketKey: ticket.key, index, total: tickets.length, stage })
            }
            try {
              report('inspecting')
              const prepared = await prepareRepository(cwd, branch, true, ticket.key, report)
              void assignJiraTicket(ticket.key).catch((reason: unknown) => {
                console.warn(`dsh-claude: could not assign ${ticket.key}: ${reason instanceof Error ? reason.message : String(reason)}`)
              })
              report('creating-workspace')
              const workspace = await workspaces.create({ path: prepared.path })
              report('starting-session')
              const targetSessionId = await connectWorkspace(workspace.workspaceId)
              const reference = await retainForHandoff(sessions, targetSessionId)
              try {
                const targetScope = sessions.scope(targetSessionId)
                if (targetScope === undefined) throw new Error(t('repositorySessionUnavailable'))
                const presetResponse = await remote.agentPresets.select(targetSessionId, 'claude')
                if (!presetResponse.ok) throw new Error(presetResponse.error.message)
                await carryPermissionMode(sourceSessionId, targetSessionId)
                const targetInput = sessionInput(conversation, targetScope)
                report('transferring-draft')
                targetInput.setDraft(rawDraft.trim() === '' ? ticketPrompt(ticket) : `${rawDraft.trimEnd()}\n\n${ticketContext(ticket)}`)
                bindLease(prepared.leaseId, targetSessionId)
                report('submitting')
                targetInput.submit()
              } catch (error) {
                reference.release()
                throw error
              }
              // None of these Sessions is opened, so this hold is the only one
              // keeping each submission alive until the Host takes it.
              releaseAfterSubmission(reference)
            } catch (cause) {
              failures.push(`${ticket.key}: ${cause instanceof Error ? cause.message : String(cause)}`)
            }
          }
          if (failures.length < tickets.length) sourceInput.setDraft('')
          if (failures.length > 0) throw new Error(failures.join(' · '))
        },
      }),
    }, ClaudeHeroRepositoryControls))
  }
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'claude-code',
    order: 16,
    label: () => t('nav'),
    inject: (): ClaudeCodeSettingsInjected => ({ t }),
  }, ClaudeCodeSettings))
}
