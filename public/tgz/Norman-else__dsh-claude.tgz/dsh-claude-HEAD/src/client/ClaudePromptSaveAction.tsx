import { useCallback, useEffect, useLayoutEffect, useRef, useState, type CSSProperties, type RefObject } from 'react'
import { createPortal } from 'react-dom'
import { Button, IconListPenOutlineRegular, IconTrashOutlineRegular, Tooltip } from '@deepseek-ai/dsh-client-ui-primitives'
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots'
import type { ClaudePromptView } from '../prompts.ts'
import type { ClaudeClientProjection } from './projection.ts'
import type { ClaudeCodeSettingsKey } from './locales.ts'
import { PluginRequestError } from './plugin-transport.ts'
import { claudePrompts, defaultPromptName, deleteClaudePrompt, invalidateClaudePrompts, saveClaudePrompt, suggestClaudePromptName } from './prompt-api.ts'
import * as styles from './styles.ts'

export interface ClaudePromptSaveActionInjected {
  t: (key: ClaudeCodeSettingsKey, params?: Record<string, unknown>) => string
}

export interface ClaudePromptSaveActionProps extends ClaudePromptSaveActionInjected {
  useClaudeProjection: SnapshotSelectorHook<ClaudeClientProjection>
  /** Standard session-scoped hook over the composer state; `draft` is the
   *  text on screen. Host 0.1.2-rc.1 renders `conversation.input.left` with no
   *  owner props, so the draft is only reachable through this hook. */
  useInput: SnapshotSelectorHook<{ readonly draft: string }>
  /** Seam for tests; defaults to the host route that writes the prompt file. */
  savePrompt?: (name: string, body: string) => Promise<ClaudePromptView>
  /** Seam for tests; defaults to the host route that asks Claude for a name. */
  suggestName?: (draft: string, cancel?: AbortSignal) => Promise<string | undefined>
  /** Seam for tests; defaults to a fresh read of the prompt directory. */
  loadPrompts?: () => Promise<readonly ClaudePromptView[]>
  /** Seam for tests; defaults to the host route that deletes the prompt file. */
  deletePrompt?: (name: string) => Promise<void>
}

function freshPrompts(): Promise<readonly ClaudePromptView[]> {
  // The menu's five-second cache could still hold a file removed outside DSH.
  invalidateClaudePrompts()
  return claudePrompts()
}


const CARD_GAP = 8
const CARD_MARGIN = 12

/**
 * Place the card above its trigger, clamped into the viewport, and dismiss it
 * on a pointer that lands outside both.
 *
 * The primitives ship `useAnchoredPosition` and `useDismissOnOutsidePointer`
 * for exactly this, and both are used here through their published types —
 * but the Host's build of that package predates the `side` option of one and
 * the portal argument of the other. Neither omission is visible to `tsc`,
 * which reads this checkout's newer copy, and both are silent at runtime: the
 * card hangs below a composer pinned to the bottom of the window, and every
 * pointer landing in the naming field counts as outside and closes it. Owning
 * twenty lines beats behaviour that depends on which Desktop the plugin was
 * installed into.
 */
function useAnchoredCard(
  open: boolean,
  anchor: RefObject<HTMLElement | null>,
  card: RefObject<HTMLElement | null>,
  onDismiss: () => void,
): CSSProperties | undefined {
  const [position, setPosition] = useState<CSSProperties>()
  useLayoutEffect(() => {
    if (!open) {
      setPosition(undefined)
      return undefined
    }
    const place = (): void => {
      const trigger = anchor.current?.getBoundingClientRect()
      const panel = card.current?.getBoundingClientRect()
      if (trigger === undefined || panel === undefined) return
      const above = trigger.top - CARD_GAP - panel.height
      setPosition({
        left: Math.max(CARD_MARGIN, Math.min(trigger.left, window.innerWidth - panel.width - CARD_MARGIN)),
        // Below only when there is genuinely no room above, which for this
        // trigger means a window shorter than the card.
        top: above >= CARD_MARGIN ? above : Math.min(trigger.bottom + CARD_GAP, window.innerHeight - panel.height - CARD_MARGIN),
      })
    }
    place()
    // The card grows after opening (a list that loads, an error line), and a
    // position taken at the first frame would leave it hanging off-screen.
    const resize = typeof ResizeObserver === 'undefined' ? undefined : new ResizeObserver(place)
    if (card.current !== null) resize?.observe(card.current)
    window.addEventListener('resize', place)
    // Capture, so scrollers nested inside the page are caught too.
    window.addEventListener('scroll', place, true)
    return () => {
      resize?.disconnect()
      window.removeEventListener('resize', place)
      window.removeEventListener('scroll', place, true)
    }
  }, [open, anchor, card])
  useEffect(() => {
    if (!open) return undefined
    const dismiss = (event: PointerEvent): void => {
      const target = event.target
      if (!(target instanceof Node)) return
      if (anchor.current?.contains(target) === true || card.current?.contains(target) === true) return
      onDismiss()
    }
    document.addEventListener('pointerdown', dismiss)
    return () => { document.removeEventListener('pointerdown', dismiss) }
  }, [open, anchor, card, onDismiss])
  return position
}

type Panel =
  | {
      readonly kind: 'naming'
      readonly name: string
      /** The user has taken the field over; a late suggestion must not
       *  overwrite what they are typing. */
      readonly touched: boolean
      readonly suggesting: boolean
      readonly failure?: string
    }
  | { readonly kind: 'saved'; readonly prompt: ClaudePromptView }
  | {
      readonly kind: 'manage'
      /** Undefined while the directory is being read. */
      readonly prompts?: readonly ClaudePromptView[] | undefined
      /** The row asking "delete this?" — a deleted file is not coming back. */
      readonly confirming?: string | undefined
      readonly failure?: string | undefined
    }

/**
 * Keep the draft you just wrote, from the composer's own tool row.
 *
 * It sits beside the attach and access controls rather than in a row of its
 * own: a band above the composer moves the repository bar and the composer
 * itself every time a draft appears, and this is a once-in-a-while action that
 * has not earned that. The naming card is portaled and anchored, so opening it
 * displaces nothing either.
 *
 * The field opens on a name derived from the draft's first line, which costs
 * nothing and is there instantly, and a Claude-written name replaces it when
 * one arrives. That ordering is the whole naming design: the suggestion is an
 * improvement on a working answer, never something the user waits for.
 *
 * With no draft there is nothing to keep, so the same control opens the list
 * of saved prompts instead, where each can be deleted.
 */
export function ClaudePromptSaveAction({
  t, useClaudeProjection, useInput, savePrompt = saveClaudePrompt, suggestName = suggestClaudePromptName,
  loadPrompts = freshPrompts, deletePrompt = deleteClaudePrompt,
}: ClaudePromptSaveActionProps) {
  const owned = useClaudeProjection(projection => projection.owned)
  const anchor = useRef<HTMLSpanElement>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const suggestion = useRef<AbortController | undefined>(undefined)
  const [panel, setPanel] = useState<Panel>()
  const [saving, setSaving] = useState(false)
  const close = useCallback((): void => {
    suggestion.current?.abort()
    suggestion.current = undefined
    setPanel(undefined)
  }, [])
  const position = useAnchoredCard(panel !== undefined, anchor, panelRef, close)
  useEffect(() => () => { suggestion.current?.abort() }, [])

  // Hooks stay above the early return: the inert composer still renders this
  // entry, just with nothing to offer.
  const draft = useInput(state => state.draft)
  if (!owned) return null
  const managing = draft.trim() === ''
  const label = managing ? t('promptManage') : t('promptSave')
  const openManage = (): void => {
    setPanel({ kind: 'manage' })
    void loadPrompts().then((prompts) => {
      setPanel(current => current?.kind === 'manage' ? { ...current, prompts } : current)
    })
  }
  const remove = (name: string): void => {
    if (saving) return
    setSaving(true)
    deletePrompt(name).then(() => {
      setPanel(current => current?.kind !== 'manage' ? current : {
        kind: 'manage',
        prompts: current.prompts?.filter(prompt => prompt.name !== name),
      })
    }, (error: unknown) => {
      setPanel(current => current?.kind !== 'manage' ? current : {
        ...current,
        confirming: undefined,
        failure: t('promptDeleteFailed', { message: error instanceof Error ? error.message : String(error) }),
      })
    }).finally(() => { setSaving(false) })
  }
  const open = (): void => {
    setPanel({ kind: 'naming', name: defaultPromptName(draft), touched: false, suggesting: true })
    const attempt = new AbortController()
    suggestion.current = attempt
    void suggestName(draft, attempt.signal).then((suggested) => {
      if (attempt.signal.aborted) return
      setPanel(current => current?.kind !== 'naming'
        ? current
        : { ...current, suggesting: false, ...(suggested === undefined || current.touched ? {} : { name: suggested }) })
    })
  }
  const save = (): void => {
    const name = panel?.kind === 'naming' ? panel.name.trim() : ''
    if (saving || name === '' || draft.trim() === '') return
    setSaving(true)
    savePrompt(name, draft).then((prompt) => {
      setPanel({ kind: 'saved', prompt })
    }, (error: unknown) => {
      // A name collision is the one failure the user fixes right here, so the
      // card stays open holding what they typed.
      setPanel({
        kind: 'naming',
        name,
        touched: true,
        suggesting: false,
        failure: error instanceof PluginRequestError && error.code === 'name-taken'
          ? t('promptSaveExists')
          : t('promptSaveFailed', { message: error instanceof Error ? error.message : String(error) }),
      })
    }).finally(() => { setSaving(false) })
  }

  return (
    <span ref={anchor} style={{ position: 'relative', display: 'inline-flex' }}>
      <style data-dsh-claude-prompt-save-styles>{styles.promptSaveTriggerCss}</style>
      <Tooltip label={label} side="top" delayMs={250} disabled={panel !== undefined}>
        <button
          type="button"
          className={styles.promptSaveTriggerClass}
          aria-label={label}
          aria-haspopup="dialog"
          aria-expanded={panel !== undefined}
          onClick={() => { if (panel !== undefined) close(); else if (managing) openManage(); else open() }}
        ><IconListPenOutlineRegular size={14} /></button>
      </Tooltip>
      {panel === undefined || typeof document === 'undefined' ? null : createPortal(
        <div ref={panelRef} style={{ ...styles.promptSaveCard, ...(panel.kind === 'manage' ? styles.promptManageCard : {}), ...position }} role="dialog" aria-label={label}>
          {panel.kind === 'manage' ? (
            <>
              <span style={styles.promptSaveHeading}>{label}</span>
              {panel.prompts === undefined
                ? <span role="status" style={styles.repositoryChecksHint}>{t('promptManageLoading')}</span>
                : panel.prompts.length === 0
                  ? <span style={styles.repositoryChecksHint}>{t('promptManageEmpty')}</span>
                  : (
                    <ul style={styles.promptManageList}>
                      {panel.prompts.map(prompt => (
                        <li key={prompt.name} style={styles.promptManageRow}>
                          {panel.confirming === prompt.name ? (
                            <>
                              <span style={styles.promptManageName}>{t('promptDeleteConfirm', { name: prompt.name })}</span>
                              <Button variant="ghost" size="sm" disabled={saving} onClick={() => setPanel({ ...panel, confirming: undefined })}>{t('promptSaveCancel')}</Button>
                              <Button variant="primary" size="sm" disabled={saving} onClick={() => remove(prompt.name)}>{t('promptDelete')}</Button>
                            </>
                          ) : (
                            <>
                              <span style={styles.promptManageText} title={prompt.body}>
                                <span style={styles.promptManageName}>{prompt.name}</span>
                                <span style={styles.promptManageDescription}>{prompt.description}</span>
                              </span>
                              <button
                                type="button"
                                className={styles.promptSaveTriggerClass}
                                aria-label={t('promptDeleteNamed', { name: prompt.name })}
                                disabled={saving}
                                onClick={() => setPanel({ ...panel, confirming: prompt.name, failure: undefined })}
                              ><IconTrashOutlineRegular size={14} /></button>
                            </>
                          )}
                        </li>
                      ))}
                    </ul>
                  )}
              {panel.failure === undefined ? null : <span style={styles.promptSaveError}>{panel.failure}</span>}
              <span style={styles.promptSaveActions}>
                <Button variant="primary" size="sm" onClick={close}>{t('promptSaveDone')}</Button>
              </span>
            </>
          ) : panel.kind === 'saved' ? (
            <>
              <span style={styles.promptSaveHeading}>{t('promptSaved', { name: panel.prompt.name })}</span>
              <span style={styles.promptSaveLocation}>{panel.prompt.location}</span>
              <span style={styles.promptSaveActions}>
                <Button variant="primary" size="sm" onClick={close}>{t('promptSaveDone')}</Button>
              </span>
            </>
          ) : (
            <form style={{ display: 'contents' }} onSubmit={(event) => { event.preventDefault(); save() }}>
              <span style={styles.promptSaveHeading}>{label}</span>
              {panel.suggesting ? <span role="status" style={styles.repositoryChecksHint}>{t('promptSaveNaming')}</span> : null}
              <input
                className={styles.promptSaveFieldClass}
                aria-label={t('promptSaveName')}
                placeholder={t('promptSaveName')}
                value={panel.name}
                maxLength={128}
                autoFocus
                disabled={saving}
                onChange={event => setPanel({ ...panel, name: event.currentTarget.value, touched: true })}
                onKeyDown={(event) => { if (event.key === 'Escape') close() }}
              />
              {panel.failure === undefined ? null : <span style={styles.promptSaveError}>{panel.failure}</span>}
              <span style={styles.promptSaveActions}>
                <Button variant="ghost" size="sm" type="button" disabled={saving} onClick={close}>{t('promptSaveCancel')}</Button>
                <Button variant="primary" size="sm" type="submit" disabled={saving}>{t('promptSaveConfirm')}</Button>
              </span>
            </form>
          )}
        </div>,
        document.body,
      )}
    </span>
  )
}
