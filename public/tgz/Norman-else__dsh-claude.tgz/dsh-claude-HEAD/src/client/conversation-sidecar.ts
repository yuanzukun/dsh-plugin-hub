import type { ChatConversationViewNode } from '@deepseek-ai/dsh-client-ui-chat/client'
import type { ConversationNodeDefinition } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { TurnTailOwnerProps } from '@deepseek-ai/dsh-client-ui-chat/client'
import type { ClaudeActivityEvent, ClaudeActivityPhase, ClaudeTaskInfo, ClaudeTaskStatus, ClaudeUsage } from '../events.ts'
import { API_RETRY_TITLE, CLAUDE_CODE_PROVIDER, TASK_TOOL_NAMES } from '../constants.ts'
import { isProjectedTaskActivity } from './task-projection.ts'

export interface ClaudeSubcall {
  toolUseId: string
  toolName?: string
  phase?: ClaudeActivityPhase
  summary?: string
  isError?: boolean
}

export interface ClaudeActivityChatData {
  activity: ClaudeActivityEvent
  running: boolean
  subcalls: readonly ClaudeSubcall[]
}

export interface ClaudeTranscriptDiff {
  path: string
  oldText: string | null
  newText: string
}

/** One question Claude asked through AskUserQuestion, with what was chosen. */
export interface ClaudeQuestionAnswer {
  readonly question: string
  readonly answer: string
}

export interface ClaudeTranscriptTool {
  toolUseId: string
  toolName: string
  description: string
  summary?: string
  /** For AskUserQuestion: the answers given, in the order Claude asked. */
  answers?: readonly ClaudeQuestionAnswer[]
  input?: string
  output?: string
  phase?: ClaudeActivityPhase
  isError?: boolean
  additions?: number
  deletions?: number
  diffs?: readonly ClaudeTranscriptDiff[]
  subcalls: readonly ClaudeSubcall[]
}

export interface ClaudeCompaction {
  trigger?: 'manual' | 'auto'
  preTokens?: number
  postTokens?: number
}

export type ClaudeTranscriptItem =
  | { kind: 'text'; ordinal: number; text: string }
  | { kind: 'tools'; ordinal: number; tools: readonly ClaudeTranscriptTool[]; additions?: number; deletions?: number; files?: number }
  | { kind: 'activity'; ordinal: number; row: ClaudeActivityChatData }
  | { kind: 'compaction'; ordinal: number; compaction: ClaudeCompaction }

export interface ClaudeTurnMarker {
  readonly turn: number
}

export interface ClaudeActivityStepMarker {
  readonly turn: number
  readonly step: number
}

interface ClaudeTurnProjectionState extends ClaudeTurnMarker {
  readonly claude: boolean
}

declare module '@deepseek-ai/dsh-client-ui-conversation/client' {
  interface ConversationTurnDataMap {
    claudeCode: ClaudeTurnMarker
  }
}

declare module '@deepseek-ai/dsh-client-ui-chat/client' {
  interface ChatNodeDataMap {
    'claude-activity-step': ClaudeActivityStepMarker
  }
}

function isTaskActivity(value: ClaudeActivityEvent): boolean {
  return (value.kind === 'tool-call' || value.kind === 'tool-result')
    && value.toolName !== undefined
    && TASK_TOOL_NAMES.has(value.toolName)
}

export function presentable(activity: ClaudeActivityEvent): boolean {
  if (isTaskActivity(activity)) return true
  if (activity.kind === 'tool-call' || activity.kind === 'tool-result') return false
  if (activity.isError === true) return true
  if (activity.title?.startsWith('Unknown Claude SDK message') === true) return false
  switch (activity.kind) {
    case 'subagent':
    case 'permission':
    case 'warning':
    case 'error':
      return true
    case 'steering':
      // The reader's own message, drawn where it reached the turn.
      return activity.summary !== undefined && activity.summary.length > 0
    case 'thinking':
      return activity.summary !== undefined && activity.summary.length > 0
    default:
      // 'compaction' stays out of the disclosure rows on purpose: the
      // transcript draws it as a divider instead, in `transcriptItemsForStep`.
      return false
  }
}

function running(activity: ClaudeActivityEvent): boolean {
  return activity.phase === 'started' || activity.phase === 'updated'
}

function subcallOf(value: ClaudeActivityEvent): ClaudeSubcall | undefined {
  if (value.kind !== 'subagent' || value.toolUseId === undefined) return undefined
  return {
    toolUseId: value.toolUseId,
    ...(value.toolName === undefined ? {} : { toolName: value.toolName }),
    ...(value.phase === undefined ? {} : { phase: value.phase }),
    ...(value.summary === undefined ? {} : { summary: value.summary }),
    ...(value.isError === undefined ? {} : { isError: value.isError }),
  }
}

/** Row identity for lifecycle folding. A subagent reports progress once per
 *  tool it runs, so its dispatch, every one of those pings, and its terminal
 *  notification all address the SAME row — they are one piece of work being
 *  re-described, not a queue of separate steps.
 *
 *  `known` reports whether a row already exists under a candidate id, which is
 *  what lets a Task tool-result land on the row its tool-call opened. */
function foldKey(
  value: ClaudeActivityEvent,
  known: (id: string) => boolean,
): string | undefined {
  const taskCallId = value.toolUseId === undefined ? undefined : `task-${value.toolUseId}`
  const updatesExistingTask = value.kind === 'tool-result'
    && taskCallId !== undefined
    && known(taskCallId)
  if (!presentable(value) && !updatesExistingTask) return undefined
  if ((isTaskActivity(value) || updatesExistingTask) && taskCallId !== undefined) return taskCallId
  if (value.kind === 'subagent' && value.parentToolUseId !== undefined) return `task-${value.parentToolUseId}`
  if (value.kind === 'subagent' && value.taskId !== undefined) return `subagent-task-${value.taskId}`
  if (value.kind === 'subagent' && value.toolUseId !== undefined) return `call-${value.toolUseId}`
  // The CLI announces every retry of one failing request, up to ten of them.
  // They are one request being re-described, so they share a row and the
  // latest attempt count replaces the last instead of stacking underneath it.
  if (value.kind === 'warning' && value.title === API_RETRY_TITLE) return `api-retry-${value.turn}-${value.step}`
  return `act-${value.turn}-${value.step}-${value.ordinal}`
}

/** The task snapshot is authoritative over the lifecycle stream: a row whose
 *  task already settled must not keep pulsing just because the last ping it
 *  received said 'updated'. */
function settled(
  row: ClaudeActivityChatData,
  taskStatus: ReadonlyMap<string, ClaudeTaskStatus>,
): ClaudeActivityChatData {
  const taskId = row.activity.taskId
  const status = taskId === undefined ? undefined : taskStatus.get(taskId)
  if (status === undefined || status === 'running') return row
  const failed = status === 'failed' || status === 'stopped' || status === 'killed'
  const settledTitle = row.activity.title?.replace(/^Running\s+/u, '')
  return {
    ...row,
    running: false,
    activity: {
      ...row.activity,
      phase: failed ? 'failed' : 'completed',
      ...(settledTitle === undefined ? {} : { title: settledTitle }),
      ...(failed ? { isError: true } : {}),
    },
  }
}

/** Fold raw sidecar activity into the same lifecycle cards the old event
 *  projection rendered, keyed so a caller that interleaves these rows with
 *  other transcript items can look one up instead of re-folding per activity. */
function foldedRows(
  activities: readonly ClaudeActivityEvent[],
  tasks: readonly ClaudeTaskInfo[],
): ReadonlyMap<string, ClaudeActivityChatData> {
  const rows = new Map<string, ClaudeActivityChatData>()
  for (const value of activities) {
    const id = foldKey(value, candidate => rows.has(candidate))
    if (id === undefined) continue
    const previous = rows.get(id)
    if (previous === undefined) {
      rows.set(id, { activity: value, running: running(value), subcalls: [] })
      continue
    }
    if (value.kind === 'subagent' && value.parentToolUseId !== undefined) {
      const nested = subcallOf(value)
      if (nested === undefined) continue
      const nestedIndex = previous.subcalls.findIndex(item => item.toolUseId === nested.toolUseId)
      const subcalls = nestedIndex === -1
        ? [...previous.subcalls, nested]
        : previous.subcalls.map((item, position) => position === nestedIndex ? { ...item, ...nested } : item)
      rows.set(id, { ...previous, subcalls })
      continue
    }
    rows.set(id, {
      activity: {
        ...value,
        ...(value.toolName === undefined && previous.activity.toolName !== undefined
          ? { toolName: previous.activity.toolName }
          : {}),
      },
      running: running(value),
      subcalls: previous.subcalls,
    })
  }
  const taskStatus = new Map(tasks.map(task => [task.taskId, task.status]))
  return new Map([...rows].map(([id, row]) => [id, settled(row, taskStatus)]))
}

function inputRecord(detail: string | undefined): Record<string, unknown> | undefined {
  if (detail === undefined) return undefined
  try {
    const value: unknown = JSON.parse(detail)
    return value !== null && typeof value === 'object' && !Array.isArray(value)
      ? value as Record<string, unknown>
      : undefined
  } catch {
    return undefined
  }
}

const ASK_USER_QUESTION = 'AskUserQuestion'

/** Question and answer pairs from a record's `answers` map.
 *
 *  Both sources share the shape: the bridge's completed question row stores
 *  `{ answers }`, and Claude's own AskUserQuestion result echoes its input
 *  with `answers` filled in. The map is keyed by the question text. */
function questionAnswers(detail: string | undefined): readonly ClaudeQuestionAnswer[] | undefined {
  const answers = inputRecord(detail)?.answers
  if (answers === null || typeof answers !== 'object' || Array.isArray(answers)) return undefined
  const pairs = Object.entries(answers as Record<string, unknown>)
    .filter((entry): entry is [string, string] => typeof entry[1] === 'string' && entry[1].length > 0)
    .map(([question, answer]) => ({ question, answer }))
  return pairs.length === 0 ? undefined : pairs
}

/** Answers the question bridge recorded, by the tool call they belong to.
 *
 *  The bridge's row is the reliable copy: Claude's tool result carries the
 *  same answers only at the end of a bounded blob, which a long question can
 *  push past the cut. */
function answeredQuestions(activities: readonly ClaudeActivityEvent[]): ReadonlyMap<string, readonly ClaudeQuestionAnswer[]> {
  const answered = new Map<string, readonly ClaudeQuestionAnswer[]>()
  for (const activity of activities) {
    if (activity.kind !== 'question' || activity.phase !== 'completed' || activity.toolUseId === undefined) continue
    const pairs = questionAnswers(activity.detail)
    if (pairs !== undefined) answered.set(activity.toolUseId, pairs)
  }
  return answered
}

/** The answers a finished AskUserQuestion card shows: the bridge's copy first,
 *  then the one inside Claude's own result, for sessions recorded before the
 *  bridge kept it. A failed or cancelled call shows none. */
function cardAnswers(
  previous: ClaudeTranscriptTool,
  resultDetail: string | undefined,
  failed: boolean,
): readonly ClaudeQuestionAnswer[] | undefined {
  if (previous.toolName !== ASK_USER_QUESTION || failed) return undefined
  return previous.answers ?? questionAnswers(resultDetail)
}

function inputString(input: Record<string, unknown> | undefined, key: string): string | undefined {
  const value = input?.[key]
  return typeof value === 'string' && value.length > 0 ? value : undefined
}

/** Read the compaction figures the supervisor stored as redacted JSON detail.
 *  Every field is optional: an older CLI reports the boundary without metadata,
 *  and the divider still renders — just without the token counts. */
function compactionOf(activity: ClaudeActivityEvent): ClaudeCompaction {
  const detail = inputRecord(activity.detail)
  const trigger = detail?.trigger
  const preTokens = detail?.preTokens
  const postTokens = detail?.postTokens
  return {
    ...(trigger === 'manual' || trigger === 'auto' ? { trigger } : {}),
    ...(typeof preTokens === 'number' ? { preTokens } : {}),
    ...(typeof postTokens === 'number' ? { postTokens } : {}),
  }
}

function lineCount(text: string): number {
  return text.length === 0 ? 0 : text.split(/\r?\n/u).length
}

function editDiffs(toolName: string, input: Record<string, unknown> | undefined): readonly ClaudeTranscriptDiff[] | undefined {
  const path = inputString(input, 'file_path')
  if (path === undefined) return undefined
  if (toolName === 'MultiEdit' && Array.isArray(input?.edits)) {
    const diffs = input.edits.flatMap(edit => {
      if (edit === null || typeof edit !== 'object' || Array.isArray(edit)) return []
      const item = edit as Record<string, unknown>
      const newText = inputString(item, 'new_string')
      if (newText === undefined) return []
      return [{ path, oldText: inputString(item, 'old_string') ?? null, newText }]
    })
    return diffs.length === 0 ? undefined : diffs
  }
  if (toolName === 'Edit') {
    const newText = inputString(input, 'new_string')
    return newText === undefined ? undefined : [{ path, oldText: inputString(input, 'old_string') ?? null, newText }]
  }
  if (toolName === 'Write') {
    const content = inputString(input, 'content')
    return content === undefined ? undefined : [{ path, oldText: null, newText: content }]
  }
  return undefined
}

function askedQuestions(input: Record<string, unknown> | undefined): readonly string[] {
  const questions = input?.questions
  if (!Array.isArray(questions)) return []
  return questions
    .map(item => (item !== null && typeof item === 'object' ? (item as Record<string, unknown>).question : undefined))
    .filter((question): question is string => typeof question === 'string' && question.length > 0)
}

function toolDescription(
  toolName: string,
  input: Record<string, unknown> | undefined,
  failed = false,
  answers?: readonly ClaudeQuestionAnswer[],
): string {
  const path = inputString(input, 'file_path') ?? inputString(input, 'path')
  const pattern = inputString(input, 'pattern') ?? inputString(input, 'query')
  const description = inputString(input, 'description')
  const target = path ?? pattern
  let completed: string
  let failedAction: string
  switch (toolName) {
    case 'Grep':
      completed = path === undefined ? `Searched for ${pattern ?? 'matches'}` : `Searched ${path} for ${pattern ?? 'matches'}`
      failedAction = path === undefined ? `search for ${pattern ?? 'matches'}` : `search ${path} for ${pattern ?? 'matches'}`
      break
    case 'Glob':
      completed = `Searched for ${pattern ?? 'files'}`
      failedAction = `search for ${pattern ?? 'files'}`
      break
    case 'Read':
      completed = `Read ${path ?? 'a file'}`
      failedAction = `read ${path ?? 'a file'}`
      break
    case 'WebFetch': {
      const url = inputString(input, 'url') ?? 'a web page'
      completed = `Fetched ${url}`
      failedAction = `load ${url}`
      break
    }
    case 'WebSearch':
      completed = `Searched the web for ${pattern ?? 'results'}`
      failedAction = `search the web for ${pattern ?? 'results'}`
      break
    case 'Edit': case 'MultiEdit':
      completed = `Edited ${path ?? 'a file'}`
      failedAction = `edit ${path ?? 'a file'}`
      break
    case 'Write':
      completed = `Wrote ${path ?? 'a file'}`
      failedAction = `write ${path ?? 'a file'}`
      break
    case 'Bash': {
      const command = inputString(input, 'command') ?? 'a command'
      completed = description ?? `Ran ${command}`
      failedAction = description === undefined ? `run ${command}` : description
      break
    }
    // Leaving plan mode is Claude handing over a plan for approval, not a tool
    // acting on anything; the raw name says neither.
    case 'ExitPlanMode':
      completed = 'Proposed a plan'
      failedAction = 'propose a plan'
      break
    case ASK_USER_QUESTION: {
      // The row a reader scans should say what was decided, not the tool name
      // twice: one answered question reads as the question and its answer.
      const asked = askedQuestions(input)
      const single = answers?.length === 1 ? answers[0] : undefined
      if (single !== undefined) completed = `${single.question} · ${single.answer}`
      else if (answers !== undefined) completed = `Answered ${answers.length} questions`
      else if (asked.length === 1) completed = asked[0]!
      else completed = asked.length > 1 ? `Asked ${asked.length} questions` : 'Asked a question'
      failedAction = 'ask a question'
      break
    }
    default:
      completed = description ?? `${toolName}${target === undefined ? '' : ` ${target}`}`
      failedAction = completed.charAt(0).toLowerCase() + completed.slice(1)
  }
  return failed ? `Failed to ${failedAction}` : completed
}


/** The call id a task's own lifecycle pings were dispatched from. */
function taskParentToolUseId(activities: readonly ClaudeActivityEvent[], taskId: string): string | undefined {
  for (const activity of activities) {
    if (activity.taskId !== taskId) continue
    const detail = inputRecord(activity.detail)
    const id = detail?.tool_use_id
    if (typeof id === 'string' && id.length > 0) return id
  }
  return undefined
}

/**
 * The tools one task ran, in the shape the transcript's tool cards take.
 *
 * The task's own activities are lifecycle pings whose detail is the raw
 * protocol message -- useful to nobody reading a panel. The work is in the
 * activities addressed to the call that dispatched the task: a subagent's
 * nested calls carry it as `parentToolUseId`, and a backgrounded command IS
 * that call. Both are folded here the way {@link transcriptItemsForStep} folds
 * a step, so one card renderer serves the transcript and the task panel.
 */
export function taskTools(
  activities: readonly ClaudeActivityEvent[],
  taskId: string,
  dispatchedBy?: string,
): readonly ClaudeTranscriptTool[] {
  const parent = dispatchedBy ?? taskParentToolUseId(activities, taskId)
  if (parent === undefined) return []
  const tools = new Map<string, ClaudeTranscriptTool>()
  const answered = answeredQuestions(activities)
  const ordered = [...activities].sort((left, right) => left.ordinal - right.ordinal)
  for (const activity of ordered) {
    const own = activity.parentToolUseId === parent
    const isRoot = activity.parentToolUseId === undefined && activity.toolUseId === parent
    if (!own && !isRoot) continue
    const toolUseId = activity.toolUseId
    if (toolUseId === undefined) continue
    const previous = tools.get(toolUseId)
    // The opening record is the one that names the tool; everything after it
    // is that call being answered.
    if (previous === undefined) {
      if (activity.toolName === undefined) continue
      const input = inputRecord(activity.detail)
      const recorded = activity.toolName === ASK_USER_QUESTION ? answered.get(toolUseId) : undefined
      tools.set(toolUseId, {
        toolUseId,
        toolName: activity.toolName,
        description: toolDescription(activity.toolName, input, false, recorded),
        ...(recorded === undefined ? {} : { answers: recorded }),
        ...(activity.summary === undefined ? {} : { summary: activity.summary }),
        ...(activity.detail === undefined ? {} : { input: activity.detail }),
        ...(activity.phase === undefined ? {} : { phase: activity.phase }),
        ...(activity.isError === undefined ? {} : { isError: activity.isError }),
        subcalls: [],
      })
      continue
    }
    const failed = activity.isError === true || activity.phase === 'failed'
    const answers = cardAnswers(previous, activity.detail, failed)
    tools.set(toolUseId, {
      ...previous,
      description: toolDescription(previous.toolName, inputRecord(previous.input), failed, answers),
      ...(answers === undefined ? {} : { answers }),
      ...(activity.detail === undefined ? {} : { output: activity.detail }),
      ...(activity.phase === undefined ? {} : { phase: activity.phase }),
      ...(activity.isError === undefined ? {} : { isError: activity.isError }),
    })
  }
  return [...tools.values()]
}

/**
 * One task's conversation as transcript items: the prose it wrote and the
 * tools it ran, in order, folded the way {@link transcriptItemsForStep} folds
 * a step. Only records addressed to the dispatching call take part; the
 * call itself and the task's lifecycle pings do not.
 */
export function teammateTranscript(
  activities: readonly ClaudeActivityEvent[],
  taskId: string,
  dispatchedBy?: string,
): readonly ClaudeTranscriptItem[] {
  const parent = dispatchedBy ?? taskParentToolUseId(activities, taskId)
  if (parent === undefined) return []
  const tools = new Map(taskTools(activities, taskId, parent).map(tool => [tool.toolUseId, tool] as const))
  const items: ClaudeTranscriptItem[] = []
  let group: { ordinal: number; tools: ClaudeTranscriptTool[] } | undefined
  const flush = (): void => {
    if (group !== undefined && group.tools.length > 0) items.push({ kind: 'tools', ordinal: group.ordinal, tools: group.tools })
    group = undefined
  }
  const own = activities.filter(activity => activity.parentToolUseId === parent).sort((left, right) => left.ordinal - right.ordinal)
  for (const activity of own) {
    if (activity.kind === 'text') {
      flush()
      if (activity.text !== undefined && activity.text.length > 0) items.push({ kind: 'text', ordinal: activity.ordinal, text: activity.text })
      continue
    }
    if (activity.toolUseId === undefined || activity.toolName === undefined) continue
    const tool = tools.get(activity.toolUseId)
    if (tool === undefined) continue
    group ??= { ordinal: activity.ordinal, tools: [] }
    group.tools.push(tool)
  }
  flush()
  return items
}

/** The turn's own accounting, drawn as a footer.
 *
 *  It hangs off the turn rather than the step that reported it: a turn waiting
 *  on background tasks reports usage per settled segment, and the task badge
 *  the plugin draws at the turn's foot would otherwise sit *under* a line that
 *  reads as a closing total. Every report is cumulative, so the newest one
 *  supersedes the ones before it. Natively drawn steps keep the Host's footer.
 */
export function latestTurnUsage(
  activities: readonly ClaudeActivityEvent[],
  turn: number,
): ClaudeUsage | undefined {
  let latest: ClaudeUsage | undefined
  for (const activity of activities) {
    if (activity.turn !== turn || activity.kind !== 'usage' || activity.renderer === 'native') continue
    if (activity.usage !== undefined) latest = activity.usage
  }
  return latest
}

/** Fold one step's shared ordinal stream into Claude Code-style prose and tool groups. */
export function transcriptItemsForStep(
  activities: readonly ClaudeActivityEvent[],
  turn: number,
  step: number,
  tasks: readonly ClaudeTaskInfo[] = [],
): readonly ClaudeTranscriptItem[] {
  // A natively stamped record is DSH's to paint: prose arrived as an assistant
  // text block, thinking as a reasoning block. Tool records under the native
  // renderer are unstamped and drawn here; older native steps stamped their
  // tools too, because the Host drew them from mirrored `tool/call` events.
  const ordered = activities
    .filter(activity => activity.turn === turn
      && activity.step === step
      && activity.renderer !== 'native'
      && isProjectedTaskActivity(activity, tasks))
    .slice()
    .sort((left, right) => left.ordinal - right.ordinal)
  const answered = answeredQuestions(activities.filter(activity => activity.turn === turn && activity.step === step))
  // Fold the whole step at once. Folding per activity would give every task
  // progress ping its own private row, so a single subagent would paint one
  // permanently-running line per tool it happened to use.
  const rows = foldedRows(ordered, tasks)
  const placed = new Set<string>()
  const items: ClaudeTranscriptItem[] = []
  let group: {
    ordinal: number
    tools: ClaudeTranscriptTool[]
    byId: Map<string, number>
    trailingActivities: ClaudeActivityEvent[]
  } | undefined
  /** Emit an activity's folded row where it first appears; later pings that
   *  fold onto the same row update it in place rather than stacking up. */
  const emitRow = (activity: ClaudeActivityEvent): void => {
    const id = foldKey(activity, candidate => rows.has(candidate))
    if (id === undefined || placed.has(id)) return
    const row = rows.get(id)
    if (row === undefined) return
    placed.add(id)
    items.push({ kind: 'activity', ordinal: activity.ordinal, row })
  }
  const flushGroup = (): void => {
    if (group === undefined || group.tools.length === 0) return
    const current = group
    const diffs = current.tools.flatMap(tool => tool.diffs ?? [])
    const additions = diffs.reduce((total, diff) => total + lineCount(diff.newText), 0)
    const deletions = diffs.reduce((total, diff) => total + (diff.oldText === null ? 0 : lineCount(diff.oldText)), 0)
    const files = new Set(diffs.map(diff => diff.path)).size
    items.push({
      kind: 'tools',
      ordinal: current.ordinal,
      tools: current.tools,
      ...(diffs.length === 0 ? {} : { additions, deletions, files }),
    })
    group = undefined
    for (const activity of current.trailingActivities) emitRow(activity)
  }
  for (const activity of ordered) {
    if (activity.kind === 'text') {
      // A subagent's prose belongs to its own transcript (teammateTranscript).
      if (activity.parentToolUseId !== undefined) continue
      flushGroup()
      // The closing prose the Host now draws as the turn's native answer.
      if (activity.answer === true) continue
      if (activity.text !== undefined && activity.text.length > 0) {
        items.push({ kind: 'text', ordinal: activity.ordinal, text: activity.text })
      }
      continue
    }
    if (activity.kind === 'compaction') {
      flushGroup()
      items.push({ kind: 'compaction', ordinal: activity.ordinal, compaction: compactionOf(activity) })
      continue
    }
    if (activity.kind === 'tool-call' && activity.toolUseId !== undefined && activity.toolName !== undefined) {
      group ??= { ordinal: activity.ordinal, tools: [], byId: new Map(), trailingActivities: [] }
      group.byId.set(activity.toolUseId, group.tools.length)
      const input = inputRecord(activity.detail)
      const recorded = activity.toolName === ASK_USER_QUESTION ? answered.get(activity.toolUseId) : undefined
      group.tools.push({
        toolUseId: activity.toolUseId,
        toolName: activity.toolName,
        description: toolDescription(activity.toolName, input, false, recorded),
        ...(recorded === undefined ? {} : { answers: recorded }),
        ...(activity.summary === undefined ? {} : { summary: activity.summary }),
        ...(activity.detail === undefined ? {} : { input: activity.detail }),
        ...(activity.phase === undefined ? {} : { phase: activity.phase }),
        ...(activity.isError === undefined ? {} : { isError: activity.isError }),
        subcalls: [],
      })
      continue
    }
    if ((activity.kind === 'tool-result' || activity.kind === 'permission') && activity.toolUseId !== undefined && group !== undefined) {
      const index = group.byId.get(activity.toolUseId)
      const previous = index === undefined ? undefined : group.tools[index]
      if (index !== undefined && previous !== undefined) {
        const failed = activity.isError === true || activity.phase === 'failed' || activity.kind === 'permission'
        const diffs = failed ? undefined : editDiffs(previous.toolName, inputRecord(previous.input))
        const additions = diffs?.reduce((total, diff) => total + lineCount(diff.newText), 0)
        const deletions = diffs?.reduce((total, diff) => total + (diff.oldText === null ? 0 : lineCount(diff.oldText)), 0)
        const answers = activity.kind === 'permission' ? undefined : cardAnswers(previous, activity.detail, failed)
        group.tools[index] = {
          ...previous,
          description: toolDescription(previous.toolName, inputRecord(previous.input), failed, answers),
          ...(answers === undefined ? {} : { answers }),
          ...(activity.detail === undefined ? {} : { output: activity.detail }),
          ...(activity.phase === undefined ? {} : { phase: activity.phase }),
          ...(activity.isError === undefined ? {} : { isError: activity.isError }),
          ...(diffs === undefined ? {} : { diffs, additions: additions ?? 0, deletions: deletions ?? 0 }),
          ...(activity.kind === 'permission' ? { output: activity.summary, isError: true } : {}),
        }
      }
      continue
    }
    if (activity.kind === 'subagent' && activity.parentToolUseId !== undefined && group !== undefined) {
      const index = group.byId.get(activity.parentToolUseId)
      const previous = index === undefined ? undefined : group.tools[index]
      const nested = subcallOf(activity)
      if (index !== undefined && previous !== undefined && nested !== undefined) {
        const nestedIndex = previous.subcalls.findIndex(item => item.toolUseId === nested.toolUseId)
        const subcalls = nestedIndex === -1
          ? [...previous.subcalls, nested]
          : previous.subcalls.map((item, position) => position === nestedIndex ? { ...item, ...nested } : item)
        group.tools[index] = { ...previous, subcalls }
      }
      continue
    }
    if (!presentable(activity)) continue
    if (group !== undefined) {
      // Only the next top-level assistant prose closes a tool group. Keep any
      // presentable task/warning metadata after that group without splitting
      // consecutive root tools that occurred between the same two prose spans.
      group.trailingActivities.push(activity)
      continue
    }
    emitRow(activity)
  }
  flushGroup()
  return items
}

interface ClaudeActivityStepState extends ClaudeActivityStepMarker {
  readonly anchorSeq: number
  readonly assistantSeq?: number
}

/** Keep one sidecar-backed activity group at the live chat tail, then anchor it
 * before the native assistant message or at step settlement when none appears. */
export const claudeActivityStepDefinition: ConversationNodeDefinition<ClaudeActivityStepState> = {
  kind: 'claude-activity-step',
  target: 'chat',
  match(event) {
    if (event.type === 'step/start') return { id: `${event.data.turn}:${event.data.step}`, role: 'start' }
    if (event.type === 'step/end') return { id: `${event.data.turn}:${event.data.step}`, role: 'update' }
    if (event.type !== 'assistant/message' || event.data.message.source.provider !== CLAUDE_CODE_PROVIDER) return null
    return { id: `${event.data.turn}:${event.data.step}`, role: 'update' }
  },
  start(_context, match) {
    if (match.event.type !== 'step/start') throw new Error('Claude activity step requires step/start')
    return {
      turn: match.event.data.turn,
      step: match.event.data.step,
      anchorSeq: Number.MAX_SAFE_INTEGER - 1,
    }
  },
  update(context, match) {
    if (match.event.type === 'assistant/message') {
      return { ...context.state, assistantSeq: match.event.seq, anchorSeq: match.event.seq - 0.1 }
    }
    if (match.event.type === 'step/end') {
      return context.state.assistantSeq === undefined
        ? { ...context.state, anchorSeq: match.event.seq - 0.1 }
        : context.state
    }
    throw new Error('Claude activity step update requires assistant/message or step/end')
  },
  buildViewNode(context): ChatConversationViewNode | null {
    const state = context.state
    if (state === undefined) return null
    return {
      key: context.key,
      kind: 'claude-activity-step',
      id: context.id,
      target: 'chat',
      anchorSeq: state.anchorSeq,
      location: context.start?.location ?? { kind: 'unresolved' },
      visibility: 'visible',
      data: { turn: state.turn, step: state.step },
    }
  },
}

/** Publish a marker for turns containing standard assistant output from the Claude adapter. */
export const claudeTurnDefinition: ConversationNodeDefinition<ClaudeTurnProjectionState> = {
  kind: 'claudeCode',
  match(event) {
    if (event.type === 'turn/start') return { id: String(event.data.turn), role: 'start' }
    if (event.type !== 'assistant/message' || event.data.message.source.provider !== CLAUDE_CODE_PROVIDER) return null
    return { id: String(event.data.turn), role: 'update' }
  },
  start(_context, match) {
    if (match.event.type !== 'turn/start') throw new Error('Claude turn marker requires turn/start')
    return { turn: match.event.data.turn, claude: false }
  },
  update(context, match) {
    if (match.event.type !== 'assistant/message') throw new Error('Claude turn marker update requires assistant/message')
    return context.state.claude ? context.state : { turn: context.state.turn, claude: true }
  },
  buildLocationData(context, scope) {
    if (scope !== 'turn' || context.state?.claude !== true) return null
    const value: ClaudeTurnMarker = { turn: context.state.turn }
    return { kind: 'turn', turn: context.state.turn, key: 'claudeCode', value }
  },
}

/** Only Claude-produced turns render the sidecar-backed tail. The turn tail is
 *  a list Slot since Host 0.1.7, so every entry sees every turn and filters here. */
export function selectClaudeTurn(owner: Pick<TurnTailOwnerProps, 'turn'>): ClaudeTurnMarker | null {
  return owner.turn.data.get('claudeCode') ?? null
}
