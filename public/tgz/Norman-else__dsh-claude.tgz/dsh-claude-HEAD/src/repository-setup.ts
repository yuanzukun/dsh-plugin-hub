import { randomUUID } from 'node:crypto'
import { mkdir, readdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises'
import { basename, isAbsolute, join, resolve } from 'node:path'
import { dshHomePath } from '@deepseek-ai/dsh-home-paths'
import type { SubprocessHandle, SubprocessRuntime } from '@deepseek-ai/dsh-subprocess'
import { uniqueBranchName } from './branch-name.ts'
import { toolPathEnv } from './spawn.ts'

const MAX_OUTPUT_BYTES = 128 * 1024
const GIT_TIMEOUT_MS = 10_000
const GIT_FETCH_TIMEOUT_MS = 60_000
const MAX_PATH_CHARS = 4_096
const MAX_BRANCH_CHARS = 512
const LEASE_SCHEMA_VERSION = 1
// ponytail: grace only needs to outlive the worktree-create -> workspace-register
// hop (seconds); two minutes keeps deletion feeling prompt while staying safe.
const CLEANUP_GRACE_MS = 2 * 60_000

type RepositorySetupRuntime = Pick<SubprocessRuntime, 'resolveExecutable' | 'spawn'>

interface CommandResult {
  readonly exitCode: number | null
  readonly stdout: string
  readonly stderr: string
  readonly lossy: boolean
}

export interface RepositoryBranchList {
  readonly root: string
  readonly current?: string
  readonly dirty: boolean
  readonly branches: readonly string[]
  readonly remoteBranches: readonly string[]
}

export type RepositorySetupStage = 'inspecting' | 'fetching' | 'summarizing' | 'creating-worktree' | 'saving-worktree' | 'switching-branch'
export type RepositorySetupProgress = (stage: RepositorySetupStage) => void

export interface RepositorySetupResult {
  readonly mode: 'checkout' | 'worktree'
  readonly root: string
  readonly path: string
  readonly branch: string
  readonly leaseId?: string
}

export interface RepositoryCleanupResult {
  readonly mode: 'checkout' | 'worktree'
  readonly root: string
  readonly branch: string
}

interface WorktreeLease {
  readonly id: string
  readonly root: string
  readonly path: string
  readonly branch: string
  readonly createdAt: string
  readonly pluginGeneratedBranch: boolean
  readonly sessionId?: string
}

interface LeaseDocument {
  readonly schemaVersion: typeof LEASE_SCHEMA_VERSION
  readonly leases: readonly WorktreeLease[]
}

export interface RepositorySetupServiceOptions {
  readonly leasePath?: string
  /** One fixed directory for every new worktree. Unset, each worktree goes
   *  under its repository's {@link IN_REPOSITORY_WORKTREE_DIR}. */
  readonly worktreeRoot?: string
  /** Where worktrees created before they moved into the repository live; the
   *  only directory the orphan sweep lists. Defaults to `worktreeRoot`, then
   *  to the plugin's own directory under `$DSH_HOME`. */
  readonly legacyWorktreeRoot?: string
  readonly branchPrefix?: () => Promise<string>
  readonly cleanupGraceMs?: number
  /** Compress the composer draft into a branch slug; `undefined` result (or an
   *  omitted option) falls back to the timestamped name. */
  readonly summarizeBranch?: (intent: string) => Promise<string | undefined>
}

export class RepositorySetupError extends Error {
  readonly code: string

  constructor(code: string, message: string) {
    super(message)
    this.name = 'RepositorySetupError'
    this.code = code
  }
}

async function collect(handle: SubprocessHandle): Promise<CommandResult> {
  const outcome = await handle.done
  const stdout = handle.collected.stdout?.readFrom(0)
  const stderr = handle.collected.stderr?.readFrom(0)
  return {
    exitCode: outcome.exitCode,
    stdout: stdout?.text ?? '',
    stderr: stderr?.text ?? '',
    lossy: stdout?.lossy === true || stderr?.lossy === true,
  }
}

function safePath(value: string): string {
  if (value.length === 0 || value.length > MAX_PATH_CHARS || !isAbsolute(value) || value.includes('\0')) {
    throw new RepositorySetupError('invalid-path', 'The workspace path is invalid.')
  }
  return resolve(value)
}

function safeBranch(value: string): string {
  if (value.length === 0 || value.length > MAX_BRANCH_CHARS || value.trim() !== value || /[\0\r\n]/u.test(value)) {
    throw new RepositorySetupError('invalid-branch', 'The branch name is invalid.')
  }
  return value
}

function parseCurrentBranch(value: string): string | undefined {
  const branch = value.trim()
  return branch.length === 0 || branch === 'HEAD' ? undefined : branch
}

export function parseWorktreeBranches(value: string): ReadonlyMap<string, string> {
  const occupied = new Map<string, string>()
  let path: string | undefined
  for (const line of `${value}\n`.split(/\r?\n/u)) {
    if (line.startsWith('worktree ')) path = line.slice('worktree '.length)
    else if (line.startsWith('branch refs/heads/') && path !== undefined) {
      occupied.set(line.slice('branch refs/heads/'.length), path)
    } else if (line.length === 0) path = undefined
  }
  return occupied
}

function slug(value: string, fallback: string): string {
  const normalized = value.toLocaleLowerCase('en-US').replace(/[^a-z0-9._-]+/gu, '-').replace(/^-+|-+$/gu, '')
  return normalized.slice(0, 48) || fallback
}

/** A branch name as one path segment: `/` and anything else unsafe folds to
 *  `-`, case is kept so a ticket key stays scannable (`PSOS-5683`, not
 *  `psos-5683`). Flattened rather than nested on purpose -- see
 *  {@link worktreeDirectoryName}. */
function branchSegment(branch: string): string {
  const flattened = branch.replace(/[^A-Za-z0-9._-]+/gu, '-').replace(/^[-.]+/u, '').replace(/-+$/u, '')
  return flattened.slice(0, 48).replace(/-+$/u, '') || 'branch'
}

/** Name a worktree directory after the repository and the branch it holds, so
 *  the workspace list reads without opening a session.
 *
 *  One flat segment, never a `feature/x` subdirectory: the orphan sweep lists
 *  this root one level deep, and a prefix directory holds no lease of its own,
 *  so it would be removed along with every live worktree inside it. */
export function worktreeDirectoryName(root: string, branch: string): string {
  return `${slug(basename(root), 'repository')}-${branchSegment(branch)}`
}

/** Where new worktrees go, relative to the repository's main checkout.
 *
 *  Inside the repository, not under `$DSH_HOME`: the Host only groups a
 *  Session under a Workspace whose path equals its cwd, so a worktree is always
 *  a Workspace of its own, and only its path decides whether the sidebar's
 *  Workspace tree can nest it under the repository it came from. It is the
 *  directory Claude Code's own `--worktree` uses, so one exclude line keeps
 *  both out of `git status`. */
export const IN_REPOSITORY_WORKTREE_DIR = join('.claude', 'worktrees')

/** The line that keeps {@link IN_REPOSITORY_WORKTREE_DIR} out of the main
 *  checkout's status; written to the local `info/exclude`, never to a tracked
 *  `.gitignore`. */
const WORKTREE_EXCLUDE_LINE = '/.claude/worktrees/'

/** Comparable form for path identity: resolved, forward slashes, case-folded
 *  so Windows drive-letter or case spelling differences cannot hide a match. */
export function comparablePath(value: string): string {
  return resolve(value).replaceAll('\\', '/').toLocaleLowerCase('en-US')
}

function pathExists(value: string): Promise<boolean> {
  return stat(value).then(() => true, () => false)
}

function lease(value: unknown): WorktreeLease | undefined {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return undefined
  const input = value as Record<string, unknown>
  if (typeof input.id !== 'string' || typeof input.root !== 'string' || typeof input.path !== 'string'
    || typeof input.branch !== 'string' || typeof input.createdAt !== 'string'
    || (input.pluginGeneratedBranch !== undefined && typeof input.pluginGeneratedBranch !== 'boolean')
    || (input.sessionId !== undefined && typeof input.sessionId !== 'string')) return undefined
  return {
    id: input.id,
    root: input.root,
    path: input.path,
    branch: input.branch,
    createdAt: input.createdAt,
    pluginGeneratedBranch: input.pluginGeneratedBranch === true,
    ...(input.sessionId === undefined ? {} : { sessionId: input.sessionId }),
  }
}

export class RepositorySetupService {
  readonly #runtime: RepositorySetupRuntime
  readonly #leasePath: string
  readonly #worktreeRoot: string | undefined
  readonly #legacyWorktreeRoot: string
  readonly #branchPrefix: () => Promise<string>
  readonly #summarizeBranch: (intent: string) => Promise<string | undefined>
  readonly #cleanupGraceMs: number
  #gitPath: Promise<string> | undefined
  #pending: Promise<unknown> = Promise.resolve()

  constructor(runtime: RepositorySetupRuntime, options: RepositorySetupServiceOptions = {}) {
    this.#runtime = runtime
    this.#leasePath = options.leasePath ?? dshHomePath('plugins', 'dsh-claude', 'worktrees.json')
    this.#worktreeRoot = options.worktreeRoot
    this.#legacyWorktreeRoot = options.legacyWorktreeRoot ?? options.worktreeRoot ?? dshHomePath('plugins', 'dsh-claude', 'worktrees')
    this.#branchPrefix = options.branchPrefix ?? (async () => 'claude')
    this.#summarizeBranch = options.summarizeBranch ?? (async () => undefined)
    this.#cleanupGraceMs = options.cleanupGraceMs ?? CLEANUP_GRACE_MS
  }

  async listBranches(cwd: string): Promise<RepositoryBranchList> {
    const git = await this.#git()
    return this.#listBranches(git, await this.#repositoryRoot(git, safePath(cwd)))
  }

  /** Refresh remote-tracking refs before listing: a branch pushed after this
   *  checkout last fetched has no local ref, so the picker cannot offer it. */
  async refreshBranches(cwd: string): Promise<RepositoryBranchList> {
    const git = await this.#git()
    const root = await this.#repositoryRoot(git, safePath(cwd))
    await this.#fetchRemotes(git, root)
    return this.#listBranches(git, root)
  }

  async #listBranches(git: string, root: string): Promise<RepositoryBranchList> {
    const [status, refs, remoteRefs] = await Promise.all([
      this.#run(git, ['status', '--porcelain=v2', '--branch', '--untracked-files=normal'], root),
      this.#run(git, ['for-each-ref', '--format=%(refname:short)', 'refs/heads'], root),
      this.#run(git, ['for-each-ref', '--format=%(refname:short) %(symref)', 'refs/remotes'], root),
    ])
    if (status.exitCode !== 0 || status.lossy || refs.exitCode !== 0 || refs.lossy
      || remoteRefs.exitCode !== 0 || remoteRefs.lossy) {
      throw new RepositorySetupError('repository-unavailable', 'The repository state is unavailable.')
    }
    const current = status.stdout.split(/\r?\n/u)
      .find(line => line.startsWith('# branch.head '))
      ?.slice('# branch.head '.length)
    const branches = refs.stdout.split(/\r?\n/u).filter(Boolean).sort((left, right) => left.localeCompare(right))
    const remoteBranches = remoteRefs.stdout.split(/\r?\n/u)
      .map(line => line.trim().split(/\s+/u))
      .filter(parts => parts[0] !== undefined && parts[0].length > 0 && parts.length === 1)
      .map(parts => parts[0]!)
      .sort((left, right) => left.localeCompare(right))
    const currentBranch = current === undefined ? undefined : parseCurrentBranch(current)
    return {
      root,
      ...(currentBranch === undefined ? {} : { current: currentBranch }),
      dirty: status.stdout.split(/\r?\n/u).some(line => line.length > 0 && !line.startsWith('# ')),
      branches,
      remoteBranches,
    }
  }

  async setup(
    cwd: string,
    branchValue: string,
    useWorktree: boolean,
    explicitBranchName?: string,
    progress: RepositorySetupProgress = () => {},
    intent?: string,
  ): Promise<RepositorySetupResult> {
    progress('inspecting')
    const branch = safeBranch(branchValue)
    const info = await this.listBranches(cwd)
    const local = info.branches.includes(branch)
    const remote = info.remoteBranches.includes(branch)
    if (!local && !remote) {
      throw new RepositorySetupError('branch-not-found', 'The selected local or remote-tracking branch does not exist.')
    }
    const requestedBranch = explicitBranchName === undefined ? undefined : safeBranch(explicitBranchName)
    if (useWorktree) {
      return this.#createWorktree(
        info,
        branch,
        local ? `refs/heads/${branch}` : `refs/remotes/${branch}`,
        requestedBranch,
        requestedBranch !== undefined && info.branches.includes(requestedBranch),
        progress,
        intent,
      )
    }
    progress('switching-branch')
    return !local && remote ? this.#checkoutRemote(info, branch) : this.#checkout(info, branch)
  }

  /** Tear down a merged branch: remove a worktree (a plugin one with its
   *  lease, or one another tool added) and its branch, or switch a plain
   *  checkout back to the base branch and delete the merged branch. Refuses
   *  dirty trees. */
  /** `branch` names the merged branch when the checkout is no longer on it:
   *  a session that opened a pull request in another clone switched that
   *  clone back to base itself, and only the local branch is left to delete.
   *  `requirePushed` is for a branch no pull request vouches for: it is only
   *  removed once every commit on it is reachable from some remote, so a
   *  worktree that never got as far as a pull request cannot take work with it. */
  async cleanupMerged(pathValue: string, baseBranch?: string, branch?: string, requirePushed = false): Promise<RepositoryCleanupResult> {
    const path = safePath(pathValue)
    const base = baseBranch === undefined ? undefined : safeBranch(baseBranch)
    const named = branch === undefined ? undefined : safeBranch(branch)
    const git = await this.#git()
    const status = await this.#run(git, ['status', '--porcelain=v1', '--untracked-files=normal'], path)
    if (status.exitCode !== 0 || status.lossy) throw new RepositorySetupError('repository-unavailable', 'The repository state is unavailable.')
    if (status.stdout.trim().length > 0) throw new RepositorySetupError('dirty-workspace', 'Commit or stash workspace changes before cleaning up.')
    const lease = (await this.#readLeases()).find(item => comparablePath(item.path) === comparablePath(path))
    if (lease !== undefined) {
      if (requirePushed) await this.#requirePushed(git, lease.root, lease.branch)
      return this.#serialize(async () => {
        const removed = await this.#run(git, ['worktree', 'remove', '--', lease.path], lease.root)
        if (removed.exitCode !== 0) throw new RepositorySetupError('worktree-remove-failed', 'Git could not remove the worktree.')
        await this.#run(git, ['branch', '-D', '--', lease.branch], lease.root).catch(() => undefined)
        const current = await this.#readLeases()
        await this.#writeLeases(current.filter(item => item.id !== lease.id))
        return { mode: 'worktree' as const, root: lease.root, branch: lease.branch }
      })
    }
    // A linked worktree without a lease -- Claude Code's own `.claude/worktrees`,
    // a hand-run `git worktree add` -- cannot be treated as a plain checkout:
    // base is checked out in the main worktree, so `git switch` would refuse.
    const dirs = await this.#run(git, ['rev-parse', '--path-format=absolute', '--git-dir', '--git-common-dir'], path)
    const [gitDir = '', commonDir = ''] = dirs.exitCode === 0 ? dirs.stdout.trim().split(/\r?\n/u) : []
    if (gitDir.length > 0 && comparablePath(gitDir) !== comparablePath(commonDir)) {
      // ponytail: the main checkout is taken as the parent of the common dir, which holds for any `<root>/.git`; a bare or GIT_DIR-relocated repository is not handled.
      const mainRoot = resolve(commonDir, '..')
      const head = named === undefined ? await this.#run(git, ['symbolic-ref', '--quiet', '--short', 'HEAD'], path) : undefined
      const branch = named ?? (head?.exitCode === 0 ? head.stdout.trim() : '')
      if (branch.length === 0) throw new RepositorySetupError('nothing-to-clean', 'The worktree is not on a branch.')
      if (requirePushed) await this.#requirePushed(git, mainRoot, branch)
      const removed = await this.#run(git, ['worktree', 'remove', '--', path], mainRoot)
      if (removed.exitCode !== 0) throw new RepositorySetupError('worktree-remove-failed', 'Git could not remove the worktree.')
      await this.#run(git, ['branch', '-D', '--', branch], mainRoot).catch(() => undefined)
      return { mode: 'worktree', root: mainRoot, branch }
    }
    const root = await this.#repositoryRoot(git, path)
    if (base === undefined) throw new RepositorySetupError('nothing-to-clean', 'A plain checkout needs the base branch to return to.')
    const head = await this.#run(git, ['symbolic-ref', '--quiet', '--short', 'HEAD'], root)
    const current = head.exitCode === 0 ? head.stdout.trim() : ''
    if (current.length === 0 || current === base) {
      if (named === undefined || named === base) throw new RepositorySetupError('nothing-to-clean', 'The checkout is already on the base branch.')
      if (requirePushed) await this.#requirePushed(git, root, named)
      await this.#run(git, ['branch', '-D', '--', named], root).catch(() => undefined)
      await this.#run(git, ['pull', '--ff-only'], root, GIT_FETCH_TIMEOUT_MS).catch(() => undefined)
      return { mode: 'checkout', root, branch: named }
    }
    if (requirePushed) await this.#requirePushed(git, root, current)
    const switched = await this.#run(git, ['switch', '--', base], root)
    if (switched.exitCode !== 0) throw new RepositorySetupError('checkout-failed', 'Git could not switch to the base branch.')
    await this.#run(git, ['branch', '-D', '--', current], root).catch(() => undefined)
    await this.#run(git, ['pull', '--ff-only'], root, GIT_FETCH_TIMEOUT_MS).catch(() => undefined)
    return { mode: 'checkout', root, branch: current }
  }

  bindLease(leaseId: string, sessionId: string): Promise<void> {
    if (leaseId.length === 0 || leaseId.length > 128 || sessionId.length === 0 || sessionId.length > 1_024) {
      return Promise.reject(new RepositorySetupError('invalid-lease', 'The worktree lease is invalid.'))
    }
    return this.#serialize(async () => {
      const leases = await this.#readLeases()
      const index = leases.findIndex(item => item.id === leaseId)
      if (index < 0) throw new RepositorySetupError('lease-not-found', 'The worktree lease no longer exists.')
      const existing = leases[index]
      if (existing === undefined) throw new RepositorySetupError('lease-not-found', 'The worktree lease no longer exists.')
      leases[index] = { ...existing, sessionId }
      await this.#writeLeases(leases)
    })
  }

  /** Reconcile leases against the set of directories still referenced by a
   *  workspace. Deleting a workspace is the user saying they are done with it,
   *  so an unreferenced worktree goes even with uncommitted changes; its
   *  sessions are archived first, through `archiveSessions`, or the Host
   *  rebuilds the deleted workspace from their headers on the next boot.
   *  Fresh leases are retained for a grace period so a worktree created
   *  moments ago cannot be swept before its workspace registration lands.
   *
   *  Every command runs from the repository root, never from the worktree
   *  being removed: spawning in a directory that is already gone throws
   *  ENOENT, which used to strand the lease forever. */
  cleanupOrphans(
    activePaths: readonly string[],
    archiveSessions?: (worktreePath: string) => Promise<void>,
  ): Promise<void> {
    const active = new Set(activePaths.map(comparablePath))
    return this.#serialize(async () => {
      const leases = await this.#readLeases()
      const retained: WorktreeLease[] = []
      let changed = false
      const git = await this.#git()
      const now = Date.now()
      for (const item of leases) {
        const age = now - Date.parse(item.createdAt)
        if (active.has(comparablePath(item.path)) || !(age >= this.#cleanupGraceMs)) {
          retained.push(item)
          continue
        }
        try {
          // Best effort: a Host that cannot archive must not strand the lease,
          // and the worktree removal below is what the user asked for.
          await archiveSessions?.(item.path).catch(() => undefined)
          if (await pathExists(item.path)) {
            const removed = await this.#run(git, ['worktree', 'remove', '--force', '--', item.path], item.root)
            if (removed.exitCode !== 0) {
              retained.push(item)
              continue
            }
          } else {
            // The directory is already gone; let Git forget the stale
            // worktree registration before the lease follows it.
            await this.#run(git, ['worktree', 'prune'], item.root).catch(() => undefined)
          }
          if (item.pluginGeneratedBranch) {
            await this.#run(git, ['branch', '-D', '--', item.branch], item.root).catch(() => undefined)
          }
          changed = true
        } catch {
          if (await pathExists(item.root)) retained.push(item)
          else changed = true // the repository itself is gone; the lease is dead weight
        }
      }
      if (changed) await this.#writeLeases(retained)
      await this.#removeUnleasedDirectories(retained, active, now, archiveSessions)
    })
  }

  /** Remove leftover directories under the plugin's own worktree root that no
   *  lease and no workspace claims and that are no longer checkouts (an IDE
   *  folder outliving its worktree); otherwise nothing would ever sweep them.
   *  The grace period covers the gap between `worktree add` and the lease
   *  write, so a worktree being created right now is never taken. */
  async #removeUnleasedDirectories(
    retained: readonly WorktreeLease[],
    active: ReadonlySet<string>,
    now: number,
    archiveSessions?: (worktreePath: string) => Promise<void>,
  ): Promise<void> {
    const leased = new Set(retained.map(item => comparablePath(item.path)))
    let entries: string[]
    try {
      entries = await readdir(this.#legacyWorktreeRoot)
    } catch {
      return // no worktree root yet, or it is unreadable; nothing to sweep
    }
    for (const entry of entries) {
      const path = join(this.#legacyWorktreeRoot, entry)
      const key = comparablePath(path)
      if (leased.has(key) || active.has(key)) continue
      try {
        const info = await stat(path)
        if (!info.isDirectory()) continue
        const created = info.birthtimeMs > 0 ? info.birthtimeMs : info.mtimeMs
        // Date.now() truncates to whole milliseconds while birthtime carries a
        // fraction, so a directory created moments ago can read as newer than
        // the clock; clamp rather than let that skip a sweep.
        if (Math.max(0, now - created) < this.#cleanupGraceMs) continue
        // A live checkout no lease claims is Claude's own `git worktree add`
        // next to the session's, with its pull request and maybe unpushed work.
        // ponytail: a lease lost to a crash now leaks its worktree; `git worktree list` still names it.
        if (await pathExists(join(path, '.git'))) continue
        // A lost lease is still the user's deleted workspace: its sessions
        // have to be archived here too, or the Host rebuilds the workspace
        // from their headers on the next boot.
        await archiveSessions?.(path).catch(() => undefined)
        await rm(path, { recursive: true, force: true })
      } catch {
        // A directory that vanished under us, or one we may not remove; the
        // next pass sees it again.
      }
    }
  }

  async #checkoutRemote(info: RepositoryBranchList, remoteBranch: string): Promise<RepositorySetupResult> {
    const separator = remoteBranch.indexOf('/')
    if (separator <= 0 || separator === remoteBranch.length - 1) {
      throw new RepositorySetupError('invalid-branch', 'The remote-tracking branch name is invalid.')
    }
    const localBranch = safeBranch(remoteBranch.slice(separator + 1))
    if (info.branches.includes(localBranch)) {
      const git = await this.#git()
      const upstream = await this.#run(git, ['for-each-ref', '--format=%(upstream:short)', `refs/heads/${localBranch}`], info.root)
      if (upstream.exitCode !== 0 || upstream.lossy) {
        throw new RepositorySetupError('repository-unavailable', 'The local branch tracking state is unavailable.')
      }
      if (upstream.stdout.trim() !== remoteBranch) {
        throw new RepositorySetupError('branch-tracking-conflict', `The local branch ${localBranch} does not track ${remoteBranch}.`)
      }
      return this.#checkout(info, localBranch)
    }
    if (info.dirty) throw new RepositorySetupError('dirty-workspace', 'Commit or stash workspace changes before switching branches.')
    const git = await this.#git()
    const switched = await this.#run(git, ['switch', '--track', '-c', localBranch, `refs/remotes/${remoteBranch}`], info.root)
    if (switched.exitCode !== 0) throw new RepositorySetupError('checkout-failed', 'Git could not create the local tracking branch.')
    return { mode: 'checkout', root: info.root, path: info.root, branch: localBranch }
  }

  async #fetchRemotes(git: string, root: string): Promise<void> {
    const fetched = await this.#run(
      git,
      ['-c', 'credential.interactive=never', 'fetch', '--all', '--prune'],
      root,
      GIT_FETCH_TIMEOUT_MS,
    )
    // Two remote branches differing only in case cannot both be refs on a
    // case-insensitive filesystem: git updates every other ref, then exits 1.
    // That one ref is not the base being branched from, so it does not block.
    const refClashOnly = !fetched.lossy && /unable to update local ref/u.test(fetched.stderr) && !/^fatal:/mu.test(fetched.stderr)
    if ((fetched.exitCode !== 0 && !refClashOnly) || fetched.lossy) {
      throw new RepositorySetupError('fetch-failed', 'Git could not refresh remote references.')
    }
  }

  /** The remote-tracking ref a local base branch follows, when that ref still
   *  exists. Falls back to the local branch for a branch with no upstream. */
  async #upstreamRef(git: string, info: RepositoryBranchList, branch: string): Promise<string | undefined> {
    const upstream = await this.#run(git, ['for-each-ref', '--format=%(upstream:short)', `refs/heads/${branch}`], info.root)
    if (upstream.exitCode !== 0 || upstream.lossy) return undefined
    const name = upstream.stdout.trim()
    return name.length > 0 && info.remoteBranches.includes(name) ? `refs/remotes/${name}` : undefined
  }

  async #checkout(info: RepositoryBranchList, branch: string): Promise<RepositorySetupResult> {
    if (info.current !== branch) {
      if (info.dirty) throw new RepositorySetupError('dirty-workspace', 'Commit or stash workspace changes before switching branches.')
      const git = await this.#git()
      const worktrees = await this.#run(git, ['worktree', 'list', '--porcelain'], info.root)
      if (worktrees.exitCode !== 0 || worktrees.lossy) throw new RepositorySetupError('repository-unavailable', 'Worktree state is unavailable.')
      const occupiedPath = parseWorktreeBranches(worktrees.stdout).get(branch)
      if (occupiedPath !== undefined && resolve(occupiedPath) !== info.root) {
        throw new RepositorySetupError('branch-occupied', 'The selected branch is already checked out in another worktree.')
      }
      const switched = await this.#run(git, ['switch', '--', branch], info.root)
      if (switched.exitCode !== 0) throw new RepositorySetupError('checkout-failed', 'Git could not switch to the selected branch.')
    }
    return { mode: 'checkout', root: info.root, path: info.root, branch }
  }

  async #createWorktree(
    info: RepositoryBranchList,
    baseBranch: string,
    baseRef: string,
    explicitBranchName: string | undefined,
    reuseExistingBranch: boolean,
    progress: RepositorySetupProgress,
    intent: string | undefined,
  ): Promise<RepositorySetupResult> {
    const { root } = info
    const git = await this.#git()
    progress('fetching')
    await this.#fetchRemotes(git, root)
    // A fresh worktree is meant to start from the remote tip the fetch just
    // refreshed, not from whatever the local base branch last pulled.
    const startRef = reuseExistingBranch ? baseRef : (await this.#upstreamRef(git, info, baseBranch)) ?? baseRef
    const suffix = randomUUID().slice(0, 8)
    const stamp = new Date().toISOString().replace(/[-:]/gu, '').replace(/\.\d{3}Z$/u, 'Z')
    const branch = explicitBranchName ?? await this.#generatedBranch(info, baseBranch, intent, stamp, suffix, progress)
    const directory = this.#worktreeRoot ?? await this.#inRepositoryWorktreeRoot(git, root)
    const path = join(directory, await this.#freeDirectoryName(directory, root, branch))
    progress('creating-worktree')
    await mkdir(directory, { recursive: true })
    // A stale registration from a deleted worktree directory would keep the
    // existing branch "checked out" and block reusing it.
    if (reuseExistingBranch) await this.#run(git, ['worktree', 'prune'], root).catch(() => undefined)
    const created = await this.#run(
      git,
      reuseExistingBranch ? ['worktree', 'add', '--', path, branch] : ['worktree', 'add', '-b', branch, path, startRef],
      root,
    )
    if (created.exitCode !== 0) {
      const detail = created.stderr.split(/\r?\n/u).map(line => line.trim()).filter(line => line.length > 0).at(-1)
      throw new RepositorySetupError('worktree-failed', detail === undefined ? 'Git could not create the worktree.' : `Git could not create the worktree: ${detail}`)
    }
    const item: WorktreeLease = {
      id: randomUUID(),
      root,
      path,
      branch,
      createdAt: new Date().toISOString(),
      pluginGeneratedBranch: explicitBranchName === undefined,
    }
    progress('saving-worktree')
    try {
      await this.#serialize(async () => {
        const leases = await this.#readLeases()
        await this.#writeLeases([...leases, item])
      })
    } catch (error) {
      await this.#run(git, ['worktree', 'remove', '--force', '--', path], root).catch(() => undefined)
      if (!reuseExistingBranch) await this.#run(git, ['branch', '-D', '--', branch], root).catch(() => undefined)
      throw error
    }
    return { mode: 'worktree', root, path, branch, leaseId: item.id }
  }

  /** `<prefix>/<what the draft is about>`, falling back to
   *  `<prefix>/<base branch>-<stamp>-<random>` whenever the summary is missing
   *  or unusable. The prefix and the fallback shape are unchanged. */
  /** The branch-named directory, or the first `-2`, `-3`, ... spelling free of
   *  anything already on disk. Names no longer carry a timestamp, so a stale
   *  directory a crash left behind -- or two branches that fold to the same
   *  segment -- would otherwise fail `worktree add` outright. Compared
   *  case-folded, since a case-insensitive filesystem would collide anyway. */
  /** `<main checkout>/.claude/worktrees`, excluded from that checkout's status.
   *  Anchored at the main checkout rather than `root`, so a worktree prepared
   *  from inside another worktree does not nest in it. The exclude is
   *  best-effort: failing to write it only leaves the directory visible as
   *  untracked. */
  async #inRepositoryWorktreeRoot(git: string, root: string): Promise<string> {
    const dirs = await this.#run(git, ['rev-parse', '--path-format=absolute', '--git-common-dir', '--git-path', 'info/exclude'], root)
    const [commonDir = '', excludePath = ''] = dirs.exitCode === 0 ? dirs.stdout.trim().split(/\r?\n/u) : []
    // ponytail: the main checkout is the parent of the common dir, which holds for any `<root>/.git`; a bare or GIT_DIR-relocated repository falls back to `root`.
    const mainRoot = commonDir.length > 0 && basename(commonDir) === '.git' ? resolve(commonDir, '..') : root
    if (excludePath.length > 0) {
      try {
        const current = await readFile(excludePath, 'utf8').catch(() => '')
        if (!current.split(/\r?\n/u).some(line => line.trim() === WORKTREE_EXCLUDE_LINE)) {
          await mkdir(resolve(excludePath, '..'), { recursive: true })
          const separator = current.length === 0 || current.endsWith('\n') ? '' : '\n'
          await writeFile(excludePath, `${current}${separator}${WORKTREE_EXCLUDE_LINE}\n`, 'utf8')
        }
      } catch {
        // An unwritable exclude file leaves the worktrees untracked but usable.
      }
    }
    return join(mainRoot, IN_REPOSITORY_WORKTREE_DIR)
  }

  async #freeDirectoryName(directory: string, root: string, branch: string): Promise<string> {
    const base = worktreeDirectoryName(root, branch)
    const taken = await readdir(directory).then(
      entries => new Set(entries.map(entry => entry.toLocaleLowerCase('en-US'))),
      () => new Set<string>(),
    )
    if (!taken.has(base.toLocaleLowerCase('en-US'))) return base
    for (let index = 2; index < 100; index += 1) {
      const candidate = `${base}-${index}`
      if (!taken.has(candidate.toLocaleLowerCase('en-US'))) return candidate
    }
    return base
  }

  async #generatedBranch(
    info: RepositoryBranchList,
    baseBranch: string,
    intent: string | undefined,
    stamp: string,
    suffix: string,
    progress: RepositorySetupProgress,
  ): Promise<string> {
    const prefix = safeBranch(await this.#branchPrefix())
    if (intent !== undefined && intent.trim().length > 0) {
      progress('summarizing')
      // The summary is a convenience, never a reason to fail the worktree.
      const summary = await this.#summarizeBranch(intent).catch(() => undefined)
      if (summary !== undefined) return uniqueBranchName(`${prefix}/${summary}`, info.branches)
    }
    return `${prefix}/${slug(baseBranch, 'branch')}-${stamp}-${suffix}`
  }

  /** Refuse to delete a branch holding commits no remote has. */
  async #requirePushed(git: string, root: string, branch: string): Promise<void> {
    const count = await this.#run(git, ['rev-list', '--count', branch, '--not', '--remotes'], root)
    if (count.exitCode !== 0 || Number(count.stdout.trim()) > 0) {
      throw new RepositorySetupError('unpushed-commits', 'The branch has commits that are not on any remote; push or discard them first.')
    }
  }

  async #repositoryRoot(git: string, cwd: string): Promise<string> {
    const result = await this.#run(git, ['rev-parse', '--path-format=absolute', '--show-toplevel'], cwd)
    const root = result.stdout.trim()
    if (result.exitCode !== 0 || result.lossy || root.length === 0 || !isAbsolute(root)) {
      throw new RepositorySetupError('not-repository', 'The workspace is not a Git repository.')
    }
    return resolve(root)
  }

  #git(): Promise<string> {
    // A cached pending or rejected lookup would wedge every later request, so
    // bound it and drop the cache on failure.
    this.#gitPath ??= this.#runtime.resolveExecutable('git', toolPathEnv(), AbortSignal.timeout(GIT_TIMEOUT_MS))
      .catch((error: unknown) => {
        this.#gitPath = undefined
        throw error
      })
    return this.#gitPath
  }


  async #run(executable: string, args: readonly string[], cwd: string, timeoutMs = GIT_TIMEOUT_MS): Promise<CommandResult> {
    return collect(this.#runtime.spawn({
      argv: [executable, ...args],
      cwd,
      stdio: {
        stdin: 'ignore',
        stdout: { maxBytes: MAX_OUTPUT_BYTES },
        stderr: { maxBytes: MAX_OUTPUT_BYTES },
      },
      graceMs: 1_000,
      signal: AbortSignal.timeout(timeoutMs),
      env: {},
    }))
  }

  async #readLeases(): Promise<WorktreeLease[]> {
    try {
      const parsed = JSON.parse(await readFile(this.#leasePath, 'utf8')) as unknown
      if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) return []
      const input = parsed as Record<string, unknown>
      if (input.schemaVersion !== LEASE_SCHEMA_VERSION || !Array.isArray(input.leases)) return []
      return input.leases.map(lease).filter((item): item is WorktreeLease => item !== undefined)
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return []
      throw error
    }
  }

  async #writeLeases(leases: readonly WorktreeLease[]): Promise<void> {
    await mkdir(resolve(this.#leasePath, '..'), { recursive: true })
    const temporary = `${this.#leasePath}.${process.pid}.${randomUUID()}.tmp`
    const document: LeaseDocument = { schemaVersion: LEASE_SCHEMA_VERSION, leases }
    try {
      await writeFile(temporary, `${JSON.stringify(document, null, 2)}\n`, { mode: 0o600 })
      await rename(temporary, this.#leasePath)
    } finally {
      await rm(temporary, { force: true }).catch(() => undefined)
    }
  }

  #serialize<T>(operation: () => Promise<T>): Promise<T> {
    const result = this.#pending.then(operation, operation)
    this.#pending = result.then(() => undefined, () => undefined)
    return result
  }
}
