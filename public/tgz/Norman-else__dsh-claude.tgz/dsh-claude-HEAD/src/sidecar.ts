import { randomUUID } from 'node:crypto'
import { isClaudePermissionMode, type ClaudePermissionMode } from './permission-mode.ts'
import { chmod, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { dshHomePath } from '@deepseek-ai/dsh-home-paths'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import {
  latestClaudeSessionBinding,
  latestClaudeTasks,
  normalizeActivity,
  normalizeTasksEvent,
  redactText,
  type ClaudeActivityEvent,
  type ClaudeActivityInput,
  type ClaudeActivityKind,
  type ClaudeSessionBoundEvent,
  type ClaudeTaskInfo,
  type ClaudeTasksEvent,
} from './events.ts'
import { CLAUDE_ACTIVITY_EVENT, CLAUDE_PROGRESS_SUBTYPES, CLAUDE_UNKNOWN_MESSAGE_PREFIX, SDK_VERSION, claudeStatusTitle, type ClaudeRenderMode } from './constants.ts'
import {
  EMPTY_REWIND_STATE,
  MAX_REWIND_ANCHORS,
  MAX_REWIND_RANGES,
  MAX_REWIND_SNAPSHOTS,
  recordRewindAnchor,
  recordRewindSnapshot,
  type ClaudeRewindAnchor,
  type ClaudeRewindRange,
  type ClaudeRewindSnapshot,
  type ClaudeRewindState,
} from './rewind.ts'

const SIDECAR_SCHEMA_VERSION = 1
const MAX_ACTIVITIES = 10_000
/** Trailing window that coalesces per-token transcript persistence into one
 *  atomic disk write; live subscribers are notified synchronously regardless. */
const TEXT_FLUSH_MS = 150
/** A suggestion is one short prompt; anything longer is not worth ghosting. */
const MAX_PROMPT_SUGGESTION_CHARS = 1_000

export interface ClaudeSidecarProjection {
  readonly schemaVersion: typeof SIDECAR_SCHEMA_VERSION
  readonly revision: number
  readonly binding?: ClaudeSessionBoundEvent
  readonly activities: readonly ClaudeActivityEvent[]
  readonly tasks?: ClaudeTasksEvent
  readonly rewind?: ClaudeRewindState
  /** The Claude permission mode the user picked in this plugin's selector;
   *  see permission-mode.ts for how it folds with the Host's sandbox mode. */
  readonly permissionMode?: ClaudePermissionMode
  /** Claude Code's guess at the user's next prompt, offered as ghost text in
   *  the composer until the next turn starts. */
  readonly promptSuggestion?: string
}

/** Change notification published to live subscribers after each accepted write.
 *
 *  `checkpoint` is the one kind that carries no change: it restates where the
 *  stream stands so a reader can notice it is behind. See {@link ClaudeSidecarRepository.checkpoint}. */
export type ClaudeSidecarDelta =
  | { kind: 'text'; turn: number; step: number; ordinal: number; append?: string; text?: string; renderer?: ClaudeRenderMode; answer?: true }
  | { kind: 'activity'; activity: ClaudeActivityEvent }
  | { kind: 'tasks'; value: ClaudeTasksEvent }
  | { kind: 'promptSuggestion'; value?: string }
  | { kind: 'sync' }
  | { kind: 'checkpoint' }

/** One delta as subscribers see it: numbered, so a reader that applies them in
 *  order can tell a missing one from a slow one.
 *
 *  The projection's own `revision` cannot do this job. Streaming prose notifies
 *  subscribers without touching disk (see {@link ClaudeSidecarRepository.appendTranscriptText}),
 *  so revisions and notifications advance on different clocks; this counter
 *  advances once per notification and nothing else reads it. */
export type ClaudeSidecarNotification = ClaudeSidecarDelta & { readonly seq: number }

export interface ClaudeSidecarRepositoryOptions {
  readonly root?: string
  readonly legacyRoot?: string
}

function emptyProjection(): ClaudeSidecarProjection {
  return { schemaVersion: SIDECAR_SCHEMA_VERSION, revision: 0, activities: [] }
}

function record(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function finiteInteger(value: unknown): value is number {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0
}

function string(value: unknown, max: number): value is string {
  return typeof value === 'string' && value.length > 0 && value.length <= max
}

function binding(value: unknown): ClaudeSessionBoundEvent | undefined {
  const input = record(value)
  if (input === undefined
    || !string(input.claudeSessionId, 512)
    || !string(input.sdkVersion, 128)
    || !string(input.cwd, 4_096)
    || (input.cliVersion !== undefined && !string(input.cliVersion, 128))) return undefined
  return {
    claudeSessionId: input.claudeSessionId,
    sdkVersion: input.sdkVersion,
    cwd: input.cwd,
    ...(input.cliVersion === undefined ? {} : { cliVersion: input.cliVersion }),
  }
}

// Keyed by the type so a new kind cannot be written without being readable:
// a hand-kept list missed `steering`, and one such row failed the whole document.
const ACTIVITY_KIND_RECORD: Readonly<Record<ClaudeActivityKind, true>> = {
  'text': true, 'steering': true, 'status': true, 'compaction': true, 'thinking': true, 'tool-call': true,
  'tool-result': true, 'permission': true, 'question': true, 'subagent': true, 'usage': true, 'warning': true, 'error': true,
}
const ACTIVITY_KINDS: ReadonlySet<string> = new Set(Object.keys(ACTIVITY_KIND_RECORD))
const ACTIVITY_PHASES = new Set(['started', 'updated', 'completed', 'denied', 'failed'])

function activity(value: unknown): ClaudeActivityEvent | undefined {
  const input = record(value)
  if (input === undefined
    || !finiteInteger(input.turn)
    || !finiteInteger(input.step)
    || !finiteInteger(input.ordinal)
    || typeof input.kind !== 'string'
    || !ACTIVITY_KINDS.has(input.kind)
    || (input.phase !== undefined && (typeof input.phase !== 'string' || !ACTIVITY_PHASES.has(input.phase)))) return undefined
  return normalizeActivity(input as unknown as ClaudeActivityEvent)
}

function rewind(value: unknown): ClaudeRewindState | undefined {
  const input = record(value)
  if (input === undefined
    || !Array.isArray(input.ranges) || input.ranges.length > MAX_REWIND_RANGES
    || !Array.isArray(input.anchors) || input.anchors.length > MAX_REWIND_ANCHORS) return undefined
  const ranges: ClaudeRewindRange[] = []
  for (const item of input.ranges) {
    const range = record(item)
    if (range === undefined || !finiteInteger(range.start) || !finiteInteger(range.end) || range.end < range.start) return undefined
    ranges.push({ start: range.start, end: range.end })
  }
  const anchors: ClaudeRewindAnchor[] = []
  for (const item of input.anchors) {
    const anchor = record(item)
    if (anchor === undefined || !finiteInteger(anchor.turn) || !string(anchor.uuid, 128)) return undefined
    anchors.push({ turn: anchor.turn, uuid: anchor.uuid })
  }
  // Documents written before working-tree snapshots existed carry no list;
  // they read as a session that simply has no tree to restore.
  const snapshots: ClaudeRewindSnapshot[] = []
  if (input.snapshots !== undefined) {
    if (!Array.isArray(input.snapshots) || input.snapshots.length > MAX_REWIND_SNAPSHOTS) return undefined
    for (const item of input.snapshots) {
      const snapshot = record(item)
      if (snapshot === undefined || !finiteInteger(snapshot.turn) || !string(snapshot.tree, 64)) return undefined
      snapshots.push({ turn: snapshot.turn, tree: snapshot.tree })
    }
  }
  const pending = record(input.pending)
  if (input.pending !== undefined && pending === undefined) return undefined
  if (pending === undefined) return { ranges, anchors, snapshots }
  if (pending.fresh === true) return { ranges, anchors, snapshots, pending: { fresh: true } }
  if (!string(pending.resumeAt, 128)) return undefined
  return { ranges, anchors, snapshots, pending: { resumeAt: pending.resumeAt } }
}

function tasks(value: unknown): ClaudeTasksEvent | undefined {
  const input = record(value)
  if (input === undefined || !Array.isArray(input.tasks)) return undefined
  return normalizeTasksEvent(input.tasks as ClaudeTaskInfo[])
}

export function parseClaudeSidecar(value: unknown): ClaudeSidecarProjection {
  const input = record(value)
  if (input === undefined
    || input.schemaVersion !== SIDECAR_SCHEMA_VERSION
    || !finiteInteger(input.revision)
    || !Array.isArray(input.activities)
    || input.activities.length > MAX_ACTIVITIES) {
    throw new Error('dsh-claude: invalid sidecar document')
  }
  const activities = input.activities.map(activity)
  if (activities.some(item => item === undefined)) throw new Error('dsh-claude: invalid sidecar activity')
  // Pruned of progress telemetry on the way in — a projection written before the
  // plugin stopped recording it still carries up to a full window of those rows —
  // and put in canonical order, which is the invariant the append fast path in
  // mergeActivities relies on. Both happen once per document read, not once per
  // write: `#update` no longer re-parses the projection it already holds.
  // An unknown-type notice is evidence worth one row per type rather than the
  // batch the CLI sends, so its repetitions are pruned here as well.
  const retained: ClaudeActivityEvent[] = []
  const reportedUnknownTitles = new Set<string>()
  for (const item of activities as ClaudeActivityEvent[]) {
    if (isProgressActivity(item)) continue
    if (item.kind === 'warning' && item.title?.startsWith(CLAUDE_UNKNOWN_MESSAGE_PREFIX) === true) {
      if (reportedUnknownTitles.has(item.title)) continue
      reportedUnknownTitles.add(item.title)
    }
    retained.push(item)
  }
  retained.sort(compareActivity)
  const parsedBinding = input.binding === undefined ? undefined : binding(input.binding)
  const parsedTasks = input.tasks === undefined ? undefined : tasks(input.tasks)
  const parsedRewind = input.rewind === undefined ? undefined : rewind(input.rewind)
  if (input.permissionMode !== undefined && !isClaudePermissionMode(input.permissionMode)) {
    throw new Error('dsh-claude: invalid sidecar permission mode')
  }
  if (input.promptSuggestion !== undefined && typeof input.promptSuggestion !== 'string') {
    throw new Error('dsh-claude: invalid sidecar prompt suggestion')
  }
  if ((input.binding !== undefined && parsedBinding === undefined)
    || (input.tasks !== undefined && parsedTasks === undefined)
    || (input.rewind !== undefined && parsedRewind === undefined)) {
    throw new Error('dsh-claude: invalid sidecar projection')
  }
  return {
    schemaVersion: SIDECAR_SCHEMA_VERSION,
    revision: input.revision,
    activities: retained,
    ...(parsedBinding === undefined ? {} : { binding: parsedBinding }),
    ...(parsedTasks === undefined ? {} : { tasks: parsedTasks }),
    ...(parsedRewind === undefined ? {} : { rewind: parsedRewind }),
    ...(input.permissionMode === undefined ? {} : { permissionMode: input.permissionMode }),
    ...(input.promptSuggestion === undefined ? {} : { promptSuggestion: input.promptSuggestion }),
  }
}

function compareActivity(left: ClaudeActivityEvent, right: ClaudeActivityEvent): number {
  return left.turn - right.turn || left.step - right.step || left.ordinal - right.ordinal
}

function activityKey(value: ClaudeActivityEvent): string {
  return `${value.turn}:${value.step}:${value.ordinal}`
}

/** Durable titles of the progress frames {@link CLAUDE_PROGRESS_SUBTYPES} names.
 *
 *  A projection written before the plugin stopped recording that telemetry still
 *  carries up to a full window of those rows. Dropping them on the way in is what
 *  makes them stop costing anything: every later write rebuilds only the real
 *  activity, so the first write after the upgrade sheds the backlog instead of
 *  rebuilding ten thousand rows forever. */
const PROGRESS_STATUS_TITLES: ReadonlySet<string> = new Set(
  [...CLAUDE_PROGRESS_SUBTYPES].map(subtype => claudeStatusTitle(subtype)),
)

/** The same telemetry under the title it carried before it was classified as
 *  progress: the unknown-type fallback named those rows after the message type
 *  and filed them as warnings. */
const LEGACY_PROGRESS_TITLES: ReadonlySet<string> = new Set([
  `${CLAUDE_UNKNOWN_MESSAGE_PREFIX}tool_progress`,
])

function isProgressActivity(activity: ClaudeActivityEvent): boolean {
  if (activity.title === undefined) return false
  if (LEGACY_PROGRESS_TITLES.has(activity.title)) return true
  return activity.kind === 'status' && PROGRESS_STATUS_TITLES.has(activity.title)
}

function mergeActivities(
  existing: readonly ClaudeActivityEvent[],
  additions: readonly ClaudeActivityEvent[],
): ClaudeActivityEvent[] {
  // Progress telemetry never enters the projection, whoever offers it: a document
  // read off disk is pruned in `parseClaudeSidecar`, and this is the one door
  // every later activity comes through.
  const appended = additions.length === 1 ? additions[0] : undefined
  if (appended !== undefined && isProgressActivity(appended)) return existing as ClaudeActivityEvent[]
  // Appending one activity is the hot path: it runs once per SDK message inside
  // the streaming pump. `existing` is kept in canonical order (parse sorts, and
  // every branch below sorts), so an addition whose key sorts after the last
  // retained one is appended directly instead of rebuilding a Map and sorting
  // the whole window.
  const last = existing[existing.length - 1]
  if (appended !== undefined && (last === undefined || compareActivity(last, appended) < 0)) {
    return existing.length < MAX_ACTIVITIES
      ? [...existing, appended]
      : [...existing.slice(1), appended]
  }
  const merged = new Map(existing.map(item => [activityKey(item), item]))
  for (const item of additions) {
    if (!isProgressActivity(item)) merged.set(activityKey(item), item)
  }
  return [...merged.values()].sort(compareActivity).slice(-MAX_ACTIVITIES)
}

function normalizeBinding(
  input: Omit<ClaudeSessionBoundEvent, 'sdkVersion'> & { sdkVersion?: string },
): ClaudeSessionBoundEvent {
  return {
    claudeSessionId: redactText(input.claudeSessionId, 512),
    sdkVersion: redactText(input.sdkVersion ?? SDK_VERSION, 128),
    cwd: redactText(input.cwd, 4_096),
    ...(input.cliVersion === undefined ? {} : { cliVersion: redactText(input.cliVersion, 128) }),
  }
}

export class ClaudeSidecarRepository {
  readonly root: string
  readonly legacyRoot: string | undefined
  readonly #pending = new Map<string, Promise<unknown>>()
  /** Latest durable projection per session; disk is read once and written through. */
  readonly #latest = new Map<string, ClaudeSidecarProjection>()
  readonly #listeners = new Map<string, Set<(delta: ClaudeSidecarNotification) => void>>()
  /** Notifications published per session, so a reader can spot a hole. */
  readonly #seq = new Map<string, number>()
  /** Streaming transcript segments not yet persisted, keyed by activity key. */
  readonly #live = new Map<string, Map<string, ClaudeActivityEvent>>()
  /** Monotonic revision boost so merged reads advance while text stays in memory. */
  readonly #boost = new Map<string, number>()
  readonly #flushTimers = new Map<string, ReturnType<typeof setTimeout>>()

  constructor(options: ClaudeSidecarRepositoryOptions = {}) {
    this.root = options.root ?? dshHomePath('plugins', 'dsh-claude', 'sessions')
    this.legacyRoot = options.legacyRoot
      ?? (options.root === undefined ? dshHomePath('plugins', 'dsh-claude-code', 'sessions') : undefined)
  }

  async read(sessionId: string): Promise<ClaudeSidecarProjection> {
    await this.#pending.get(sessionId)?.catch(() => undefined)
    return this.#merged(sessionId, await this.#base(sessionId))
  }

  /** Observe accepted changes for one session; returns the unsubscriber. */
  subscribe(sessionId: string, listener: (delta: ClaudeSidecarNotification) => void): () => void {
    let set = this.#listeners.get(sessionId)
    if (set === undefined) {
      set = new Set()
      this.#listeners.set(sessionId, set)
    }
    set.add(listener)
    return () => {
      set.delete(listener)
      if (set.size === 0) this.#listeners.delete(sessionId)
    }
  }

  /** Record streaming assistant prose without touching the disk on the hot
   *  path: subscribers are notified synchronously (as an append when the
   *  redacted text grows in place) and persistence is coalesced. */
  appendTranscriptText(
    sessionId: string,
    value: { turn: number; step: number; ordinal: number; text: string; renderer?: ClaudeRenderMode; answer?: true },
  ): void {
    const normalized = normalizeActivity({ kind: 'text', phase: 'updated', ...value })
    const key = activityKey(normalized)
    let overlay = this.#live.get(sessionId)
    if (overlay === undefined) {
      overlay = new Map()
      this.#live.set(sessionId, overlay)
    }
    const previous = overlay.get(key)
    overlay.set(key, normalized)
    this.#boost.set(sessionId, (this.#boost.get(sessionId) ?? 0) + 1)
    const text = normalized.text ?? ''
    const base = {
      turn: normalized.turn,
      step: normalized.step,
      ordinal: normalized.ordinal,
      ...(normalized.renderer === undefined ? {} : { renderer: normalized.renderer }),
      ...(normalized.answer === true ? { answer: true as const } : {}),
    }
    // Redaction may rewrite earlier characters once a secret completes, so a
    // non-prefix update falls back to a full-text replacement.
    // Becoming the answer changes no text, so it is always sent in full.
    this.#notify(sessionId, previous?.text !== undefined && text.startsWith(previous.text) && (normalized.answer === true) === (previous.answer === true)
      ? { kind: 'text', ...base, append: text.slice(previous.text.length) }
      : { kind: 'text', ...base, text })
    this.#scheduleTextFlush(sessionId)
  }

  /** Persist any pending streaming transcript now (segment close, turn end). */
  flushTranscriptText(sessionId: string): Promise<void> {
    const timer = this.#flushTimers.get(sessionId)
    if (timer !== undefined) {
      clearTimeout(timer)
      this.#flushTimers.delete(sessionId)
    }
    return this.#flushLive(sessionId)
  }

  /** How many notifications this session has published. */
  sequence(sessionId: string): number {
    return this.#seq.get(sessionId) ?? 0
  }

  /** Restate where the stream stands without changing anything.
   *
   *  A reader detects a lost delta from the hole the NEXT one leaves, which
   *  never comes when the lost delta was the last of a turn -- exactly the
   *  case that leaves a finished tool group pulsing forever. Called at turn
   *  settlement, this gives that reader the one line it needs to disagree. */
  checkpoint(sessionId: string): void {
    this.#deliver(sessionId, { kind: 'checkpoint', seq: this.sequence(sessionId) })
  }

  #notify(sessionId: string, delta: ClaudeSidecarDelta): void {
    const seq = this.sequence(sessionId) + 1
    this.#seq.set(sessionId, seq)
    this.#deliver(sessionId, { ...delta, seq } as ClaudeSidecarNotification)
  }

  #deliver(sessionId: string, notification: ClaudeSidecarNotification): void {
    const set = this.#listeners.get(sessionId)
    if (set === undefined) return
    for (const listener of [...set]) {
      try {
        listener(notification)
      } catch {
        // A subscriber failure must never affect durable state.
      }
    }
  }

  #merged(sessionId: string, base: ClaudeSidecarProjection): ClaudeSidecarProjection {
    const overlay = this.#live.get(sessionId)
    const boost = this.#boost.get(sessionId) ?? 0
    if ((overlay === undefined || overlay.size === 0) && boost === 0) return base
    return {
      ...base,
      revision: base.revision + boost,
      ...(overlay === undefined || overlay.size === 0
        ? {}
        : { activities: mergeActivities(base.activities, [...overlay.values()]) }),
    }
  }

  async #base(sessionId: string): Promise<ClaudeSidecarProjection> {
    const cached = this.#latest.get(sessionId)
    if (cached !== undefined) return cached
    const loaded = await this.#readNow(sessionId)
    this.#latest.set(sessionId, loaded)
    return loaded
  }

  #scheduleTextFlush(sessionId: string): void {
    if (this.#flushTimers.has(sessionId)) return
    const timer = setTimeout(() => {
      this.#flushTimers.delete(sessionId)
      void this.#flushLive(sessionId)
    }, TEXT_FLUSH_MS)
    timer.unref?.()
    this.#flushTimers.set(sessionId, timer)
  }

  async #flushLive(sessionId: string): Promise<void> {
    const overlay = this.#live.get(sessionId)
    if (overlay === undefined || overlay.size === 0) return
    const entries = [...overlay.entries()]
    try {
      await this.#update(sessionId, current => ({
        ...current,
        activities: mergeActivities(current.activities, entries.map(([, value]) => value)),
      }))
    } catch {
      // Keep the overlay; the next append or flush retries persistence.
      return
    }
    for (const [key, value] of entries) {
      if (overlay.get(key) === value) overlay.delete(key)
    }
    if (overlay.size === 0) this.#live.delete(sessionId)
  }

  writeBinding(
    sessionId: string,
    value: Omit<ClaudeSessionBoundEvent, 'sdkVersion'> & { sdkVersion?: string },
  ): Promise<ClaudeSidecarProjection> {
    const normalized = normalizeBinding(value)
    return this.#update(sessionId, current => ({ ...current, binding: normalized }))
  }

  appendActivity(
    sessionId: string,
    value: ClaudeActivityInput & { turn: number; step: number; ordinal: number },
  ): Promise<ClaudeSidecarProjection> {
    const normalized = normalizeActivity(value)
    return this.#update(sessionId, current => ({
      ...current,
      activities: mergeActivities(current.activities, [normalized]),
    }), false, { kind: 'activity', activity: normalized })
  }

  /** Record the mode the selector picked. No delta: the projection carries
   *  it as metadata, which the carrier refreshes on its own cadence. */
  writePermissionMode(sessionId: string, mode: ClaudePermissionMode): Promise<ClaudeSidecarProjection> {
    return this.#update(sessionId, current => ({ ...current, permissionMode: mode }), true)
  }

  /** Offer (or, with undefined, withdraw) the next-prompt suggestion. A write
   *  that changes nothing is skipped, so clearing at every turn start is free. */
  writePromptSuggestion(sessionId: string, value: string | undefined): Promise<ClaudeSidecarProjection> {
    const text = value === undefined ? undefined : redactText(value, MAX_PROMPT_SUGGESTION_CHARS)
    return this.#update(sessionId, ({ promptSuggestion: _previous, ...current }) => ({
      ...current,
      ...(text === undefined ? {} : { promptSuggestion: text }),
    }), true, text === undefined ? { kind: 'promptSuggestion' } : { kind: 'promptSuggestion', value: text })
  }

  writeTasks(sessionId: string, value: readonly ClaudeTaskInfo[]): Promise<ClaudeSidecarProjection> {
    const normalized = normalizeTasksEvent(value)
    return this.#update(sessionId, current => ({ ...current, tasks: normalized }), false, { kind: 'tasks', value: normalized })
  }

  /** Land one planned rewind: hidden ranges, surviving anchors, and the fork
   *  target the next Claude spawn consumes.
   *
   *  `droppedFromTurn` also drops the discarded turns' activity. The hidden
   *  ranges are surface seqs and activity records carry none, so a reader that
   *  works in turns — the plan panel, the task board — has nothing to filter
   *  on and would go on showing a plan the session no longer contains. This
   *  projection is rebuildable from the session log, so trimming it is not
   *  losing anything the log still holds. */
  writeRewind(sessionId: string, value: ClaudeRewindState, droppedFromTurn?: number): Promise<ClaudeSidecarProjection> {
    return this.#update(sessionId, current => ({
      ...current,
      rewind: value,
      ...(droppedFromTurn === undefined ? {} : {
        activities: current.activities.filter(activity => activity.turn < droppedFromTurn),
      }),
    }), false, { kind: 'sync' })
  }

  /** Remember where Claude's chain ended for one completed DSH turn. */
  recordRewindAnchor(sessionId: string, turn: number, uuid: string): Promise<ClaudeSidecarProjection> {
    return this.#update(sessionId, current => ({
      ...current,
      rewind: recordRewindAnchor(current.rewind ?? EMPTY_REWIND_STATE, { turn, uuid }),
    }))
  }

  /** Remember the working tree one DSH turn was admitted against. */
  recordRewindSnapshot(sessionId: string, turn: number, tree: string): Promise<ClaudeSidecarProjection> {
    return this.#update(sessionId, current => ({
      ...current,
      rewind: recordRewindSnapshot(current.rewind ?? EMPTY_REWIND_STATE, { turn, tree }),
    }))
  }

  /** Disarm the fork target once a Claude process has resumed at it, so a
   *  later respawn continues the rewound session instead of re-truncating it. */
  clearRewindPending(sessionId: string): Promise<ClaudeSidecarProjection> {
    return this.#update(sessionId, current => (current.rewind?.pending === undefined ? current : {
      ...current,
      rewind: { ranges: current.rewind.ranges, anchors: current.rewind.anchors, snapshots: current.rewind.snapshots },
    }))
  }

  importLegacy(sessionId: string, events: readonly SessionEvent[]): Promise<ClaudeSidecarProjection> {
    const importedActivities = events
      .filter(event => event.type === CLAUDE_ACTIVITY_EVENT)
      .map(event => activity(event.data))
      .filter((item): item is ClaudeActivityEvent => item !== undefined)
    const importedBinding = latestClaudeSessionBinding(events)
    const importedTasks = latestClaudeTasks(events)
    return this.#update(sessionId, current => ({
      ...current,
      activities: mergeActivities(importedActivities, current.activities),
      ...(current.binding !== undefined || importedBinding === undefined ? {} : { binding: normalizeBinding(importedBinding) }),
      ...(current.tasks !== undefined || importedTasks === undefined ? {} : { tasks: normalizeTasksEvent(importedTasks.tasks) }),
    }), true, { kind: 'sync' })
  }

  #path(sessionId: string, root = this.root): string {
    if (sessionId.length === 0 || sessionId.length > 1_024) throw new Error('dsh-claude: invalid session id')
    return join(root, `${Buffer.from(sessionId).toString('base64url')}.json`)
  }

  /** Apply one change to the in-memory projection and persist it.
   *
   *  Every change below is built from values the matching normalizer already
   *  produced — the very ones `parseClaudeSidecar` would run again — so
   *  re-parsing the document here re-redacted and re-bounded every retained
   *  activity on every write. On a session holding a full activity window that
   *  was tens of milliseconds per SDK message, inside the streaming pump.
   *  Untrusted data still enters through exactly one door: `#readNow` parses the
   *  document that comes off disk. What is left to check here are the invariants
   *  a change itself could break. */
  #update(
    sessionId: string,
    change: (current: ClaudeSidecarProjection) => Omit<ClaudeSidecarProjection, 'revision' | 'schemaVersion'> & Partial<Pick<ClaudeSidecarProjection, 'revision' | 'schemaVersion'>>,
    skipUnchanged = false,
    delta?: ClaudeSidecarDelta,
  ): Promise<ClaudeSidecarProjection> {
    const previous = this.#pending.get(sessionId) ?? Promise.resolve()
    const operation = previous.catch(() => undefined).then(async () => {
      const current = await this.#base(sessionId)
      const changed = change(current)
      if (changed.activities.length > MAX_ACTIVITIES) {
        throw new Error('dsh-claude: activity window overflow')
      }
      if (skipUnchanged && JSON.stringify(changed) === JSON.stringify(current)) return current
      const next: ClaudeSidecarProjection = {
        ...changed,
        schemaVersion: SIDECAR_SCHEMA_VERSION,
        revision: current.revision + 1,
      }
      await this.#writeNow(sessionId, next)
      this.#latest.set(sessionId, next)
      if (delta !== undefined) this.#notify(sessionId, delta)
      return next
    })
    this.#pending.set(sessionId, operation)
    void operation.finally(() => {
      if (this.#pending.get(sessionId) === operation) this.#pending.delete(sessionId)
    }).catch(() => undefined)
    return operation
  }

  async #readNow(sessionId: string): Promise<ClaudeSidecarProjection> {
    try {
      return parseClaudeSidecar(JSON.parse(await readFile(this.#path(sessionId), 'utf8')))
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error
    }
    if (this.legacyRoot === undefined) return emptyProjection()
    try {
      return parseClaudeSidecar(JSON.parse(await readFile(this.#path(sessionId, this.legacyRoot), 'utf8')))
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return emptyProjection()
      throw error
    }
  }

  async #writeNow(sessionId: string, projection: ClaudeSidecarProjection): Promise<void> {
    await mkdir(this.root, { recursive: true, mode: 0o700 })
    await chmod(this.root, 0o700)
    const target = this.#path(sessionId)
    const temporary = `${target}.${process.pid}.${randomUUID()}.tmp`
    try {
      await writeFile(temporary, `${JSON.stringify(projection)}\n`, { mode: 0o600, flag: 'wx' })
      await chmod(temporary, 0o600)
      await rename(temporary, target)
      await chmod(target, 0o600)
    } finally {
      await rm(temporary, { force: true }).catch(() => undefined)
    }
  }
}
