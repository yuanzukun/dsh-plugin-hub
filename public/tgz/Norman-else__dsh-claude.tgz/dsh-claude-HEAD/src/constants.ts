export const CLAUDE_CODE_PROVIDER = 'claude'
export const CLAUDE_CODE_PRESET_ID = 'claude'
/** The preset description cordis.patch.yml publishes. The Host renders a
 *  third-party preset's description verbatim, so the client swaps this exact
 *  text for its own translation (see preset-seat-mark.ts). */
export const CLAUDE_PRESET_DESCRIPTION = 'Use the local Claude Code as the complete agent runtime inside DSH.'
export const CLAUDE_CODE_PROVIDER_IDS = [CLAUDE_CODE_PROVIDER] as const
export const CLAUDE_SESSION_BOUND_EVENT = 'claude-code/session-bound'
export const CLAUDE_ACTIVITY_EVENT = 'claude-code/activity'
export const CLAUDE_TASKS_EVENT = 'claude-code/tasks'
/** Claude's subagent dispatch tools; rendered as plugin-owned group cards
 *  gathering subagent activity instead of native tool cards. */
export const TASK_TOOL_NAMES: ReadonlySet<string> = new Set(['Task', 'Agent'])
export const SDK_VERSION = '0.3.247'

/** System-message subtypes the CLI streams as progress telemetry rather than
 *  lifecycle evidence.
 *
 *  `thinking_tokens` arrives once per estimated thinking-token chunk — the SDK
 *  documents it as "approximate progress for spinners/pills, not the
 *  authoritative billed output_tokens" — so one extended-thinking step emits
 *  tens of thousands of them. The transcript never draws a plain status row,
 *  and each durable row costs a full sidecar rewrite, so these are consumed as
 *  progress and kept out of the activity log. */
export const CLAUDE_PROGRESS_SUBTYPES: ReadonlySet<string> = new Set(['thinking_tokens'])

/** Durable status title this package writes for a system subtype. Shared by the
 *  writer and by the filter that drops a progress subtype's rows, so the two can
 *  never drift apart. */
export function claudeStatusTitle(subtype: string): string {
  return `Claude Code ${subtype.replaceAll('_', ' ')}`
}

/** Title prefix this package gives a message type it does not handle yet. Shared
 *  by the writer and by the projection prune, so a notice row can be recognized
 *  without re-deriving the template. */
export const CLAUDE_UNKNOWN_MESSAGE_PREFIX = 'Unknown Claude SDK message: '
/** Cordis service this package publishes so a steered message can reach the
 *  turn a Claude session is running. That turn owns the only process that can
 *  read it into Claude at the next model step. */
export const CLAUDE_STEERING_SERVICE = 'claudeSteering'

export const CLAUDE_DOCTOR_PATH = '/plugins/dsh-claude/doctor'
export const CLAUDE_CLIENT_DIAGNOSTICS_PATH = '/plugins/dsh-claude/client-diagnostics'
export const CLAUDE_UPDATE_CHECK_PATH = '/plugins/dsh-claude/update/check'
export const CLAUDE_USAGE_PATH = '/plugins/dsh-claude/usage'
export const CLAUDE_UPDATE_PATH = '/plugins/dsh-claude/update'
export const CLAUDE_PROJECTION_PATH = '/plugins/dsh-claude/projection'
export const CLAUDE_GLOBAL_SETTINGS_PATH = '/plugins/dsh-claude/settings/global'
export const CLAUDE_REPOSITORY_SETUP_PATH = '/plugins/dsh-claude/repository/setup'
export const CLAUDE_REPOSITORY_ACTION_PATH = '/plugins/dsh-claude/repository/action'
export const CLAUDE_REVIEW_COMMENT_PATH = '/plugins/dsh-claude/review-comments'
export const CLAUDE_REPOSITORY_FEEDBACK_PATH = '/plugins/dsh-claude/repository/feedback'
export const CLAUDE_REPOSITORY_FILE_PATH = '/plugins/dsh-claude/repository/file'
export const CLAUDE_JIRA_PATH = '/plugins/dsh-claude/jira'
export const CLAUDE_ASK_PATH = '/plugins/dsh-claude/ask'
export const CLAUDE_REWIND_PATH = '/plugins/dsh-claude/rewind'
export const CLAUDE_BACKGROUND_TASK_PATH = '/plugins/dsh-claude/background-task'
export const CLAUDE_PERMISSION_MODE_PATH = '/plugins/dsh-claude/permission-mode'
export const CLAUDE_PLAN_FEEDBACK_PATH = '/plugins/dsh-claude/plan/feedback'
/** Title of the transcript row that shows the reviewer's own plan notes; the
 *  renderer keys its label on it. */
export const PLAN_FEEDBACK_TITLE = 'Plan sent back for changes'
export const CLAUDE_PROMPTS_PATH = '/plugins/dsh-claude/prompts'
export const CLAUDE_PROMPT_NAME_PATH = '/plugins/dsh-claude/prompts/name'
export const CLAUDE_PROMPT_REFINE_PATH = '/plugins/dsh-claude/prompts/refine'

/** Which renderer draws Claude's visible output.
 *
 *  'plugin' keeps the sidecar-backed transcript this package owns (interleaved
 *  prose, grouped tool cards, activity rows). 'native' hands the same turn to
 *  DSH's own conversation renderer: prose streams as ordinary assistant text
 *  blocks, thinking as reasoning blocks, and root Claude tools are mirrored
 *  into the durable `tool/call`/`tool/result` channel so the Host's tool
 *  presentation pipeline draws them exactly like DSH-executed calls. */
export type ClaudeRenderMode = 'plugin' | 'native'
export const CLAUDE_RENDER_MODES = ['plugin', 'native'] as const
export const DEFAULT_CLAUDE_RENDER_MODE: ClaudeRenderMode = 'plugin'

export function isClaudeRenderMode(value: unknown): value is ClaudeRenderMode {
  return value === 'plugin' || value === 'native'
}

/** How this package paints the PROSE of a Claude answer.
 *
 *  'plain' is Claude's own presentation: body text in the Host's text colour,
 *  colour reserved for code. 'enhanced' gives headings, emphasis, list markers,
 *  quotes and links their own hues and darkens the code surface — the way a
 *  Markdown-highlighting editor shows a document rather than the way Claude
 *  desktop shows an answer. It is opt-in because it deliberately breaks the
 *  parity the rest of `markdown-theme.ts` exists to hold.
 *
 *  Only meaningful under {@link ClaudeRenderMode} 'plugin': the stylesheet is
 *  scoped to markup this package renders, and 'native' turns are drawn by the
 *  Host, where it has no reach. */
export type ClaudeProseMode = 'plain' | 'enhanced'
export const CLAUDE_PROSE_MODES = ['plain', 'enhanced'] as const
export const DEFAULT_CLAUDE_PROSE_MODE: ClaudeProseMode = 'plain'

export function isClaudeProseMode(value: unknown): value is ClaudeProseMode {
  return value === 'plain' || value === 'enhanced'
}

/** Title of the activity an SDK `api_retry` notice becomes. Shared because the
 *  Client folds a run of them into one row and has only the title to go on. */
export const API_RETRY_TITLE = 'Claude API retry'
