# dsh-claude Product and Architecture Spec

Status: current architecture and behavior reference
Originally created: 2026-08-15
Reviewed against code: 2026-09-26 (plugin 0.1.57, SDK 0.3.247, DSH development graph 0.1.7-rc.2)

The dated filename is retained for existing links. Dated plans and evidence are
historical, not additional current requirements. This describes implemented
behavior; the verification section is a checklist, not a claim that every
scenario has passed on every platform. See [the index](../INDEX.md).

## 1. Product / Requirement Baseline

### 1.1 Problem

DeepSeek Harness (DSH) can run its native agent loop and can expose external coding agents as delegated subagents, but it does not provide a first-class main-conversation experience backed by the user's already-installed local Claude Code CLI. The user wants to stay in the existing DSH profile, choose Claude Code for a new conversation, and retain Claude Code's own agent loop, tools, CLAUDE.md discovery, Skills, Hooks, Plugins, MCP configuration, authentication, and session behavior.

### 1.2 Goal

Ship an out-of-tree DSH bundle named `dsh-claude` that adds a `Claude Code CLI` Agent Preset to the current DSH profile. A session using that preset routes each outer DSH model step into a complete Claude Code turn driven by the user's local CLI. DSH remains the conversation UI, durable presentation mirror, permission UI, process owner, and cancellation surface.

### 1.3 Required experience

1. Install the bundle into the active DSH profile (`desktop` for the audited Desktop installation).
2. Create a blank DSH conversation and select the `Claude` preset.
3. Send ordinary messages through the DSH composer.
4. Claude Code owns its internal agent loop and built-in tools.
5. DSH streams final user-visible text and renders complete Claude activity cards for thinking summaries, tool calls/results, subagents, permissions, usage, status, and failures.
6. Tool permission requests appear in the existing DSH approval flow.
7. A live Claude process remains attached to an active DSH session and is reclaimed after an idle limit.
8. DSH refresh/restart can resume the Claude session through its persisted Claude session id.
9. Existing non-Claude DSH presets and sessions keep their current behavior.

### 1.4 Non-negotiables

- Use the local Claude Code executable; do not call the Anthropic Messages API directly.
- Reuse the user's existing Claude authentication and `~/.claude` configuration.
- Do not store or return Claude credentials.
- Do not expose DSH tools to Claude as a second agent loop.
- Do not represent Claude-owned tool calls as DSH-owned tool execution.
- Do not automatically replay a prompt whose side-effect outcome is unknown.
- macOS was the initial validation platform. Current code also includes Windows executable and runner compatibility; platform-specific verification must be recorded separately.

### 1.5 Current non-goals

- Managing Claude login or credentials inside DSH.
- Switching a non-empty conversation between native DSH and Claude Code presets.
- Plugin-owned background-agent execution. Claude Code owns background execution; when tasks outlive the primary result, the plugin keeps that DSH turn open and asks the same Claude session for one final report after all tasks settle.
- Treating an npm release or a successful build as proof of live Host compatibility.
- Modifying DeepSeek Harness core APIs.

## 2. Architecture / Runtime Boundary Baseline

### 2.1 Integration shape

The plugin does not replace the process-global DSH `AgentFactory`. The active profile keeps the native `dsh-agent-loop`. A plugin-provided Agent Preset contributes an `agent/request` waterfall listener that replaces the request route with the plugin's `claude` provider. The provider's adapter turns one DSH model request into one complete Claude Code agent turn and maps output according to the per-turn renderer described in section 3.4.

This is an agent bridge at the LLM seam, not a claim that Claude Code is a stateless LLM provider.

### 2.2 Canonical owners

| Surface | Canonical owner |
| --- | --- |
| DSH conversation identity, turn boundaries, standard assistant text | DSH session and native agent loop |
| Claude context, internal agent loop, tool selection/execution | Claude Code CLI |
| Local Claude auth, settings, CLAUDE.md, Skills, Hooks, Plugins, MCP | Existing Claude Code installation and `~/.claude` |
| Claude process lifetime and whole-turn cancellation | Plugin process supervisor over DSH managed subprocess |
| Claude background task execution and per-task lifecycle | Claude Code CLI; plugin observes SDK lifecycle only |
| Tool permission decision UI and audit | DSH approval service |
| Claude-to-DSH session binding | Plugin-owned sidecar keyed by DSH session id |
| Claude internal activity presentation | Redacted sidecar data exposed through a trusted Host projection |

### 2.3 Agent SDK amendment

Use `@anthropic-ai/claude-agent-sdk` only as the supported typed protocol/process adapter for the local CLI. Configure `pathToClaudeCodeExecutable` with the resolved absolute user executable and set `spawnClaudeCodeProcess` to a wrapper backed by `ctx.subprocess`. The SDK must not choose its optional bundled binary and must not authenticate independently.

The main conversation Query options include:

- `pathToClaudeCodeExecutable`: resolved local CLI path
- `systemPrompt: { type: 'preset', preset: 'claude_code', append: PLAN_MODE_HANDOFF_PROMPT }`
- `settingSources: ['user', 'project', 'local']`
- `includePartialMessages: true`
- `permissionMode`: mapped from the session's durable DSH sandbox mode (`read-only` → `plan`, `workspace-write` → `acceptEdits`, `danger-full-access` → `bypassPermissions`)
- `allowDangerouslySkipPermissions: true`: enables the explicitly confirmed DSH Full access mapping without activating it in other modes
- `canUseTool`: DSH approval bridge for modes where Claude still requests approval
- `hooks`: auto-mode escalation (`PermissionDenied` + `PreToolUse`, see §4)
- `cwd`: immutable DSH session cwd
- `resume`: persisted Claude session id when present
- explicit model only when the selected alias is not `default`
- `spawnClaudeCodeProcess`: DSH-managed process adapter

The pinned SDK is `@anthropic-ai/claude-agent-sdk@0.3.247`; the executable is resolved from the local installation. Auxiliary query helpers have their own options and lifetime; the supervisor options above do not apply wholesale to them. Runtime compatibility is feature-detected and diagnosed rather than inferred only from a version string.

### 2.4 Sandbox boundary amendment

The plugin reuses the DSH permission UI and maps its three durable sandbox modes into Claude permission behavior, but v0.1 does not claim kernel-level workspace confinement.

Reason: DSH's current process sandbox permits writes only to the workspace and temporary roots, while full Claude Code semantics and durable resume require writes under `~/.claude`. The public sandbox contract has no additional technical-state-root vocabulary. Silently bypassing `~/.claude`, copying credentials, or widening the workspace root would each violate a more important boundary.

The process still runs through `ctx.subprocess` for explicit argv, credential-shaped ambient environment scrubbing, cancellation, and whole-process-tree cleanup. A future DSH core extension may add explicit runtime state roots; that is outside this plugin.

### 2.5 Same-profile routing

The bundle adds:

- one host adapter route: `claude`
- one preset-scoped route plugin that overrides `agent/request` to `{ provider: 'claude', model: <alias> }`
- one user-visible preset: `claude`, declared by the bundle patch as an `@deepseek-ai/dsh-agent-preset` row registered with `agent-preset-registry`; its route uses the profile package source. Removing the dependency removes the declaration. Copies left under `$DSH_HOME/.agent-presets/claude` by plugin 0.1.57 and earlier are no longer read; `dsh-claude remove-preset` deletes installer-written ones

The preset contains no DSH model-facing filesystem, shell, skill, web, goal, todo, workflow, or subagent tools. Claude Code owns those capabilities. It may include only the route plugin and a minimal persona/presentation contribution needed by DSH.

## 3. Host Components

### 3.1 Executable resolver and Doctor

Resolution order:

1. configured absolute `executablePath`
2. `ctx.subprocess.resolveExecutable('claude')`
3. macOS fallback `$HOME/.local/bin/claude`
4. macOS fallback `/opt/homebrew/bin/claude`
5. macOS fallback `/usr/local/bin/claude`

The executable Doctor reports:

- resolved path
- CLI version
- authentication status category when the CLI exposes it safely
- process handshake status

Doctor never returns token values, environment secrets, keychain data, or complete settings files. The Host route additionally reports coarse supervisor and command-bridge diagnostics. The standalone CLI leaves handshake `not-run` and its exit code checks version detection, not successful authentication. Windows Host discovery resolves supported npm shims to a native executable; standalone CLI discovery is simpler.

### 3.2 Process supervisor

The supervisor is keyed by DSH session id and owns at most one live query/process per session.

Responsibilities:

- lazy start on the first bridged turn or metadata request (command discovery, plan usage)
- maintain a streaming-input Claude query while the DSH session is active
- expose serialized, non-turn metadata reads for the current command catalog and plan usage
- serialize one active DSH request per session
- record the Claude session id from initialization/result messages
- route SDK messages to the active request
- interrupt and terminate the owned process tree on DSH cancellation
- idle eviction (default 30 minutes)
- bounded live process count (default 4), evicting enough least-recently-idle entries to honor a lowered limit and waiting FIFO for user-turn capacity when every entry is busy
- dispose all processes during plugin shutdown
- restart with `resume` after normal eviction or host restart
- never automatically replay an in-flight prompt after an ambiguous crash

The Query launch cwd remains the immutable DSH session cwd. Claude Code's
`system/init` is per-turn metadata, not just a process-start handshake: its cwd
can change after a foreground Bash `cd`, including when the session is resumed.
The supervisor checks the cwd on the first fresh initialization and checks an
ordinary resume against the persisted Claude session id. Every subsequent init
must keep the session id accepted by that Query's first init; a rewind's initial
re-binding exception does not permit later identity changes. Reported CLI cwd
stays binding metadata, never a replacement launch cwd or permission root. See
[the SDK session reference](https://code.claude.com/docs/en/agent-sdk/sessions)
and the pinned SDK's `SDKSystemMessage` documentation.

A crash before the request is accepted may fail normally. A crash after any Claude activity or permission/tool evidence marks the run `outcome-unknown` and requires a new human prompt.

### 3.3 Prompt mapping

For ordinary conversation calls, extract the newest direct DSH user message that entered the current step. Do not resend the whole DSH history because Claude's session is the context source of truth. Text-only input retains the existing string prompt path. Messages containing images become ordered Anthropic content blocks so pure-image, mixed text/image, and multiple-image input preserve the DSH block order.

DSH image blocks contain immutable attachment references, not paths or URLs. Resolve them only through the injected public `ctx.attachments.readImage(ref, signal)` service, which verifies stored bytes against the durable reference. Apply the deployment's authoritative `imageLimits` before and after reads: supported raster media types, per-image bytes, images per message, aggregate bytes, pixels, and dimensions where exposed by the compatible Host. Cancellation must settle promptly during resolution. Missing, unreadable, corrupt, unsupported, or over-limit images fail with bounded actionable errors that contain no attachment identity, path, raw bytes, base64, or underlying sensitive diagnostics.

DSH system prompts and tool schemas are not forwarded. Claude Code receives its own `claude_code` system prompt preset and local configuration. Image bytes exist only in the transient SDK input message; they are never written to sidecars, activity records, or logs.

DSH `session-title` requests are handled by `src/session-title.ts` through a
separate single-turn Haiku query; DSH's title instructions are carried in its
prompt. `compaction` remains rejected by the adapter because Claude owns its
context loop. `src/branch-name.ts` similarly summarizes worktree intent in a
separate query. Both naming helpers use `settingSources: ['user', 'project',
'local']`, `maxTurns: 1`, and `cwd: process.cwd()`. They inherit settings-based
authentication and behavior settings without borrowing the main session.
A success subtype with `is_error: true` is still an error: title generation
rejects so DSH keeps its fallback, and branch naming returns `undefined` so
worktree preparation keeps its timestamped fallback. Title and branch budgets
are 60 seconds and 15 seconds respectively.

### 3.4 Output mapping

One `renderer` setting selects who draws a Claude turn. It is plugin state, not
Claude Code state, and defaults to `plugin` so an install that never touches it
behaves exactly as before. The Host reads it per message and stamps every
sidecar record it writes — prose included — with the renderer that produced it.
The Client reads that stamp back per step rather than holding its own copy of
the setting: the Host switches on the next turn while a running Client would
keep a boot-time decision, and the failure mode of disagreeing is drawing every
step twice. Reading it per step also keeps history honest in both directions —
a turn recorded under one renderer keeps it after the setting changes, and is
never redrawn under the other.

Under `plugin`, the sidecar owns the complete visible transcript so prose and
Claude tool groups share one exact ordinal stream, and DSH receives only an
empty assistant completion anchor plus usage and lifecycle metadata.

Under `native`, map Claude partial output to DSH `StreamChunk`:

- visible text delta -> buffered, then settled per Claude result as one
  `block-start` / `text-delta` / `block-end` text block
- settled thinking block -> `block-start` / `reasoning-delta` / `block-end`
  reasoning block, emitted ahead of the prose it precedes
- Claude result usage -> DSH `usage`
- successful result -> `finish: stop`
- cancellation -> the delivered prefix settles, then `finish: aborted`
- normalized failure -> throw/finish through DSH LLM error normalization

Claude internal tool calls are never emitted as DSH `tool-call` chunks in
either mode: Claude Code owns execution. Under `native` each ROOT Claude tool
call and result is instead mirrored into the durable `tool/call` /
`tool/result` channel, and a denied call is settled there as a failed result so
its card cannot stay pending. A subagent's nested calls are not mirrored: they
belong to the Task card that dispatched them and have nothing to nest under.
Tool names outside the static presenter registry (MCP tools, new built-ins) get
an agent-scoped presenter mirror registered on first sight. Mirroring is
best-effort and never unsettles a Claude turn.

The sidecar is written identically in both modes: the diff column, task board,
rewind, and side queries read it regardless of who paints the transcript.

### 3.5 Plugin-owned sidecar

DSH session logs contain only DSH-supported event types. The plugin must not mutate `KNOWN_SESSION_EVENT_TYPES` or append `claude-code/*` events: Desktop validates persisted vocabulary before plugin activation, so runtime registration cannot make custom events cold-load compatible.

The canonical plugin state is a schema-versioned JSON sidecar keyed by the DSH session id under `$DSH_HOME/plugins/dsh-claude/sessions`. It stores the Claude resume binding, ordered activity records, and latest task snapshot. Writes are serialized per session and published with same-directory atomic rename; the directory is mode `0700` and documents are mode `0600`. Revisions increase monotonically, activities are capped, and every read is strictly validated. Streaming assistant prose is additionally held in an in-memory overlay that notifies live projection subscribers synchronously and coalesces its disk persistence within a short trailing window; segment close and turn settlement force a durable flush, so a hard Host crash can lose at most the trailing sub-second of visible prose and never a Claude outcome.

Each ordinary DSH turn maps to one user-initiated Claude turn. If that Claude result leaves background tasks running, the DSH turn remains open: its primary text is emitted as one completed text block, all task settlements are coalesced, and one plugin-authored hidden follow-up input asks the same Claude session to report final outcomes as a second text block before the single terminal DSH finish. The plugin never fabricates assistant text. Sidecar activities retain `turn`, `step`, and `ordinal` so the Client can place them immediately before the corresponding standard Claude assistant message in the chat flow. SDK `total_cost_usd` is cumulative across streaming-input turns and is retained as the latest cumulative value rather than summed.

Context usage samples are not collected or persisted; the SDK `getContextUsage()` response is read only for a model's context window (see 5.4). All sidecar payloads are bounded and secret-aware: environment maps, credential-shaped keys, and known token fields are redacted before persistence.

For migration only, readable historical `claude-code/session-bound`, `claude-code/activity`, and `claude-code/tasks` events are imported (historical `claude-code/context-usage` events are ignored) idempotently into an absent or incomplete sidecar. They are decode-only legacy formats and are never appended by current runtime code.

### 3.6 Claude command bridge

For agents composed with the Claude preset, initialize the owned Query on the first metadata or turn request and read its authoritative `supportedCommands()` catalog. Project the bounded per-session catalog to the Client whenever it is first loaded or refreshed. The Client registers a public `/` input-trigger source rather than Host commands.

- A non-conflicting Claude command keeps its native name and argument hint.
- Existing effective DSH commands and known Client contributions remain authoritative. A colliding Claude command is exposed as `claude-<name>`; a further collision excludes that entry rather than replacing another owner.
- Claude aliases follow the same rules and never replace DSH commands.
- Selecting or entering a Claude command creates a composer command claim whose submit callback sends the exact Claude slash-command line through the session-scoped `conversation.send()` service. This is an ordinary user message and turn, so status, cancellation, persistence, approval, and adapter behavior remain unchanged.
- Claude catalog entries are never registered with the Host command executor. Therefore Skill submission emits no standalone `command/run` or `command/done` lifecycle node and cannot attach a completion row to the preceding response.
- Invalid command names are excluded with a bounded diagnostic; command metadata is never treated as trusted HTML.
- Catalog discovery failure is non-fatal to ordinary prompts and is retried on the next metadata refresh.

The plugin may provide a plugin-owned context refresh command, but must not shadow an existing DSH command. Claude commands that are local-only or produce no assistant text still complete through the ordinary turn boundary without synthesizing model output.

### 3.7 Additional implemented workflows

- `repository-setup.ts`: branch selection, generated branch names, worktree/workspace leases and cleanup. Deleted-workspace reconciliation can force-remove dirty managed worktrees; explicit merged-branch cleanup requires a clean tree and guards unpushed commits. New worktrees go under the main checkout's `.claude/worktrees` (excluded through the local `info/exclude`): the Host groups a Session only under a Workspace whose path equals its cwd, so a worktree is always its own Workspace, and only a path inside the repository lets the sidebar's Workspace tree nest it there. The orphan sweep lists only the former `$DSH_HOME/plugins/dsh-claude/worktrees` root; in-repository worktrees are cleaned through their leases, since that directory also holds Claude Code's own. A live checkout that no lease claims is never swept.
- Repository status, action and review routes: Git/PR state, commit/push/merge, base updates, review comments, and auto-fix handoff. These use the managed subprocess runtime and trusted bounded routes.
- Jira routes: ticket lookup, assignment, and ticket-based worktree/session preparation.
- Prompt routes: Markdown snippets under `~/.claude/prompts`, naming and draft refinement. Selection questions use a separate read-only query. These are auxiliary helpers, not another main conversation loop.
- Prompt suggestion: the spawn sets `promptSuggestions: true`; the CLI's `prompt_suggestion` (after `result`, never mid-turn) is stored as sidecar `promptSuggestion` and published as a `promptSuggestion` carrier line, and cleared when the next turn starts. The client draws the part the draft has not typed yet as ghost text through its own attribute and custom property on the Host editor's wrapper (trailing the last paragraph, or in the placeholder seat for an empty draft); Tab, or → with the caret at the end, replaces the draft with it via `setDraft`. A `/` draft is left to the command menu.
- Rewind: transcript anchoring and optional checkout restoration while retaining append-only DSH history. Stop cleanup is serialized with the next same-session turn; do not remove resume state to handle cancellation.

## 4. Permission Contract

`canUseTool(toolName, input, context)` performs:

1. write permission-pending sidecar activity with a stable tool-use id
2. derive a bounded human-readable reason and activity detail
3. call `ctx.approval.request({ agent, toolName, callId?, reason, signal })`
4. map `allowed-once` to `{ behavior: 'allow', updatedInput: input }`
5. map rejected/cancelled/unavailable to `{ behavior: 'deny', message }`
6. write the resulting sidecar permission activity

The native DSH access selector remains the sole write path and its `sandbox/mode` event is the sole durable source of truth. The supervisor folds that event at Query creation, before every turn or metadata operation, and before and after each approval request, mapping `read-only` to Claude `plan`, `workspace-write` to `acceptEdits`, and `danger-full-access` to `bypassPermissions`. If the user explicitly selects Full access while an approval request is open, the newest durable mode overrides the stale request being closed as rejected or cancelled. The native UI already requires explicit risk acknowledgement before Full access.

The plugin keeps `canUseTool` active for modes where Claude requests approval. `bypassPermissions` skips those SDK requests only after the user selects DSH Full access. A missing or invalid sandbox event fails safe to `plan`. This is Claude behavior mapping, not kernel confinement of the Claude subprocess.

Under `auto`, a classifier block never reaches `canUseTool`. A `PermissionDenied` hook tells Claude it may retry, and a `PreToolUse` hook forces that exact retry (same tool and input, once) to `ask`, so it reaches the DSH approval above. This stands in for the CLI's `/permissions` Recently denied retry, which DSH has no surface for.

### 4.1 User-question contract

Claude `AskUserQuestion` is an interaction, not an approval. `canUseTool` must route it before approval or Full access handling, map its bounded `questions` array to `ctx.userQuestions.ask({ questions, agent, signal })`, wait for the native DSH answer, and return an SDK allow result whose `updatedInput` preserves the original questions and adds Claude's required `answers` object keyed by question text. Multi-select values are comma-separated labels; DSH custom text replaces a single-select choice and supplements multi-select labels.

Full access never bypasses a user question. Missing active-turn ownership, malformed or duplicate questions, native provider failure, cancellation, and abort all fail closed with an SDK deny result. Sidecar activity records pending/completed/cancelled state and bounded question prompts. The completed row also keeps the answers (selected labels and custom text) in its summary and as `detail.answers` keyed by question text, redacted and bounded like any activity, so the transcript's `AskUserQuestion` card can show what was decided. Claude's own tool result already carries the same answers, and the sidecar is a local, owner-only file; the row exists because that result is a bounded blob whose answers come last and can be cut. Ordinary tools continue through `ctx.approval` unchanged.

## 5. Client Components

### 5.1 Conversation projection

Register one session-scoped projection source through the public Client session provider. The source opens the same-origin trusted Host NDJSON stream immediately when its first subscriber mounts and only while subscribed: the first line is a validated full snapshot and subsequent lines are validated incremental deltas (transcript text appends, activity upserts, tasks) plus slow-moving metadata and heartbeat lines. Publication to React is coalesced to at most one notification per animation frame, and per-step activity slices keep referential identity so only the streaming step re-renders. A dropped stream reconnects with a fresh snapshot after a bounded delay; the source aborts requests and timers when the session unmounts. Failures degrade to the last verified snapshot and never block the conversation.

The Host endpoint accepts trusted loopback/same-origin GET requests with a bounded encoded session id. It returns schema version, revision, activities, and tasks with non-cacheable headers. It never exposes the sidecar binding or Claude resume identity.

A lightweight `ConversationNodeDefinition` starts exactly once at each standard `turn/start` and marks that turn through updates from standard `assistant/message` events whose provider is `claude`. This keeps multi-step turns replay-safe while publishing location data only for Claude-owned turns. A second step-scoped Definition materializes one keyed `chat` node for each Claude assistant step, anchored immediately before that assistant message; its public `conversation.chat.node` renderer folds only the matching sidecar `turn` and `step` into ordered DSH `DisclosureRow` activity rows. A third Definition mounts a plugin-owned active-turn task node from `turn/start`, keeps its anchor near the latest step or assistant event, and removes it at `turn/end`; its renderer stays null until the sidecar owns tasks for that origin turn and then updates the running, completed, or failed launcher without waiting for the turn to close. The completed-only `conversation.chat.turnTail` contribution uses the same launcher after `turn/end`, so active and historical launchers never overlap. Tasks without a known origin turn are not given a detached global UI entry.

### 5.2 Activity card

The activity card is the `plugin` renderer's contribution. Its chat node is
registered unconditionally; a step whose records carry the `native` stamp folds
to no items and the node renders null, so DSH's assistant message, reasoning,
and mirrored tool cards are the only thing drawn for it. The turn marker and
every other control surface this package contributes stay mounted under both
renderers because they have no native counterpart.
Compaction boundaries and non-tool activity rows (status, warning) have no
native equivalent either and remain sidecar-only under `native`.

The activity card shows:

- running/completed/error status
- thinking summary when supplied by Claude
- tool name and bounded input summary
- permission pending/allowed/denied state
- bounded result summary and error state
- subagent activity when represented in SDK messages
- tokens and cost when supplied

Do not render raw JSON by default. An expand control may show already-redacted detail. Use DSH theme tokens and existing primitive styles; no private shell modification.

### 5.3 Background tasks

The plugin draws no tasks launcher, tasks tab, or per-task Stop control of its own; whole-turn cancellation remains the native DSH composer Stop action. The Host's session-header background-job list is the one surface for Claude's detached work.

Tasks are mirrored into the Host job registry (`ctx.jobs`) under the DSH session: detached tasks from the `background_tasks_changed` level signal and every `local_agent` subagent from `task_started` (ambient tasks excluded), with kind `bash`, `subagent`, or `claude` by task type. The plugin settles on the task notification (or, after a short grace, on the task leaving the live set), publishes `task_progress` as the progress line (the CLI summary, else last tool, tool-use count, and tokens), and relays the Host's kill to the SDK `stop_task` request, declaring `perTaskStopAffordance` so a turn interrupt spares background work. Live output is read from the `<taskId>.output` path the CLI names in the backgrounding tool result's block content; when none was seen, the notification's `output_file` is drained at settlement. The preset route attaches a job controller for its agents because the Claude preset does not load `dsh-tool-jobs`; a Host without a job registry runs unchanged.

A blocking root `Bash` call can be moved to the background — the terminal's Ctrl+B for one call, the SDK `backgroundTasks(toolUseId)` request: Claude receives a "running in the background" result at once and the command joins the Host job list. The running card offers it as a control (`POST` the background-task route with `{ sessionId, toolUseId }`), and the supervisor does it on its own once a foreground `Bash` call has run for one minute (`CLAUDE_FOREGROUND_BASH_BACKGROUND_MS`); a call that was already `run_in_background` is left alone. Either move leaves a status row naming why.

The sidecar still records the task board (`tasks` snapshot): the supervisor holds a DSH turn open until that turn's detached tasks settle, and activity folding uses it to classify lifecycle rows. Each task also records the `toolUseId` of the call that dispatched it.

Claude's own task list reaches the Host's to-do dock above the composer. Claude Code turns its task tools off by default for every model newer than its legacy list (Opus 4.8+, Opus 5.x, Fable, Sonnet 5), so the spawn environment sets `CLAUDE_CODE_ENABLE_TODO_TOOLS=1`; a value the user sets still wins. The dock reads the process-wide `todos` session projection, which `dsh-tool-todo` folds from `todo/write` whole-list events, so the supervisor appends one whenever the list changes: the lead's `TodoWrite` input as given, or the board the task tools build (`TaskCreate` results name the id, `TaskUpdate` patches status and subject, `deleted` removes; any member's calls count). An unchanged list is not rewritten. The projection empties at every `turn/start`, so a list with open items is re-appended when the next turn starts. The event is presentation only and a failed append never affects the turn.

### 5.3.1 Agent Team

Claude Code's native Agent Team is rendered by the plugin in the seat the Host gives its own team roster: a `conversation.session.header.actions` entry beside the title, drawn like the Host's (`IconUsersOutlineRegular` trigger, fixed panel with member and task cards), that appears once the session has a teammate or a shared task, and a `claude-teammate` right-sidebar tab per member. The Host's experimental `agent-team` entry can only ever show the Lead for a Claude session, so host-chrome.ts hides it in any header where the plugin roster mounted. Every subagent is a member: an `in_process_teammate` task or any `Agent` call running as a `local_agent` task, named or not (the CLI (2.1.x) initializes a session team only for interactive launches, so over the SDK even a named agent runs as `local_agent`). Members are joined to the spawning call on `toolUseId` for the name, falling back to its description; only named ones are addressable through `SendMessage`. The flag (`CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` in the spawn environment) and `teammateMode: 'in-process'` stay set so a CLI that lifts that restriction upgrades in place. Nothing is projected server-side for it: the client derives the team from the sidecar. the shared task list is folded from `TaskCreate` results and `TaskUpdate` patches; mail is every `SendMessage` call, attributed to the member whose call it ran under, else the Lead. The teammate tab draws the member as a conversation: the Lead's brief (the spawning call's prompt) as the opening turn, then the member's own prose and tool cards in order (`forwardSubagentText` is on, and subagent text blocks are recorded as `text` activities under their `parentToolUseId`, one copy per block; the lead step's transcript skips them), then its report (the task's settlement summary). Mail appears there as the `SendMessage` tool cards it is. Teammates also register in the Host job list as `subagent`, which carries the stop control; the plugin adds no messaging or task-editing controls of its own.

### 5.4 Context meter

The plugin does not collect context usage samples and registers no
`conversation.input.right` context-meter slot. After a process's first
completed turn on a model, the supervisor probes `getContextUsage()` once to
learn that model's context window, so the model route can publish a capacity
for DSH's own meter. The probe is best-effort and must never block prompting.

Diff, plan, and teammate tabs are registered through `sidebarRightTabs` and
`sidebar.right.pane.tab`; `sidebarRight.openTabIn` opens them per session.
The Host owns fullscreen and close. Composer bars use `conversation.input.dock`,
and prompt save/refine actions use `conversation.input.left` with standard input
hooks. Host DOM bridges use local class names and data attributes, not build hashes.

### 5.5 Settings, Doctor, and updates

Add a settings section with:

- executable path
- default model alias (`default`, `opus[1m]`, `fable`, `sonnet`, `haiku`)
- idle timeout
- maximum live processes
- redacted Doctor output and rerun action
- npm release discovery and an in-place update action for uniquely identified registry installations

Bundle configuration supplies the executable and default supervisor configuration. `src/global-settings.ts` stores plugin overrides under `$DSH_HOME/plugins/dsh-claude/settings.json`: renderer, prose style, worktree prefix, maximum processes, and idle timeout. Selected Claude settings such as output style are merged into Claude's own settings file. Do not invent a credentials file. The settings menu may expose selected Claude Code user settings through one extensible global-settings registry and a trusted same-origin API. Every field requires an explicit descriptor, validation, effect scope, and bounded public metadata; the browser must never receive or write arbitrary settings JSON.

The `renderer` field selects the AI output renderer (`plugin` or `native`, see
3.4). It is stored in the plugin's own settings document, never in
`~/.claude/settings.json`, and an unknown or malformed value reads back as
`plugin`. Its effect scope is `next-turn`: the Host applies it to the next turn
it runs, and the Client needs no copy of it because the renderer travels with
each record.

The initial global field is `outputStyle`. Read its current value from `~/.claude/settings.json`, enumerate built-in styles plus bounded names from `~/.claude/output-styles/*.md`, and update only that field while preserving all unknown settings. Selecting Default removes the override. Serialize updates, reject malformed or unlisted values, limit settings/style/request sizes, and replace the settings file atomically with user-only permissions. Never return style prompt bodies or unrelated settings. Output-style changes apply only to newly created Claude sessions.

Plugin updates must install the registry's validated latest version explicitly rather than relying on the profile's existing semver range, then verify both the profile dependency and installed package manifests before reporting success. When the public Desktop actions service is available, a verified update schedules a controlled Desktop restart so both Host and Client reload the installed package; other Hosts require a manual restart. Linked, ambiguous, and unsupported sources remain non-updatable.

## 6. Failure and Recovery

| Failure | Required behavior |
| --- | --- |
| executable missing | Doctor and request fail with searched paths and repair instruction |
| CLI not authenticated | fail with `claude auth login` instruction; no browser auth proxy |
| initialization timeout | terminate tree; report handshake timeout |
| malformed SDK/CLI message | preserve bounded diagnostic, terminate affected process, fail turn |
| permission answer unavailable | deny action and continue Claude turn where possible |
| user cancels | call query interrupt, then terminate tree if not quiescent |
| process exits while idle | mark disconnected; resume on next prompt |
| process exits mid-turn after activity | persist a sidecar outcome-unknown error; never replay prompt automatically |
| persisted Claude session missing | fail explicitly with option to start a new DSH conversation; no silent context reset |
| process limit reached | evict enough least-recently-idle entries; if every entry is busy, wait FIFO before prompt submission until capacity changes or the user cancels; metadata reads remain best-effort and do not wait |
| plugin unload | terminate and await all owned trees |

## 7. Compatibility

- Develop against DSH `0.1.7-rc.2` (Desktop 2.0.15), which is also the runtime peer floor: 0.1.7 replaced directory-scanned presets with declared rows, renamed the shared primitive icons, and removed `sessions.open`. Client types come from the split controllers and UI packages; the unpublished `dsh-client-runtime` and `dsh-host-apiproxy` are no longer used. A 0.1.5 Host must stay on plugin 0.1.57.
- Keep peer dependency ranges broad enough for compatible rc updates but test against the installed host.
- Never import DSH internal source paths or copy `dsh-agent-loop` implementation.
- Use public agent request waterfall, LLM adapter, subprocess, approval, Web prefix route, per-agent command registry, session provider, client conversation projection, and additive input-slot APIs.
- Never depend on runtime mutation of DSH's persisted event vocabulary.
- Boot checks report missing declared client services/methods and the scoped composer CSS property. Slot failures are reported separately. These checks do not guarantee that every possible Host incompatibility fails at activation; follow the installed-source audit in `docs/upgrading-dsh-desktop.md`.

## 8. Verification and Acceptance

### 8.1 Automated

- executable resolution and version parsing
- exact-version plugin updates, post-install manifest verification, and no-op update rejection
- global-settings registry validation, bounded output-style discovery, atomic merge writes, malformed input, and concurrent updates
- newest-direct-message resolution for text-only, pure-image, interleaved text/image, and multiple-image input
- attachment media/count/byte/pixel/dimension limits, verified reads, bounded errors, and cancellation
- stream mapping without duplicate text
- activity normalization, truncation, and redaction
- sidecar binding persistence, legacy-event import, and resume selection
- permission allow/deny/cancel/unavailable mapping
- process supervisor serialization, cancellation, idle eviction, process cap, crash classification, and disposal
- SDK message fixtures for init, partial text, tool use/result, permission, usage, success, failure, and malformed input
- command catalog projection, aliases, DSH/Client-name collision prefixing, ordinary-message delivery, and absence of Host command lifecycle events
- context-window probe after a completed turn, cached per model, never blocking the turn
- trusted projection route, Client initial stream/reconnect/cleanup/failure degradation, per-step chat-node ordering, active task-node lifecycle, and completed turn-tail handoff
- Desktop cold-load of a newly produced session with no `claude-code/*` events
- typecheck Host and Client builds
- bundle build and package contents check

### 8.2 Local integration

- link-install into the current DSH profile
- verify existing native preset session still works
- create a Claude preset session
- run text-only, pure-image, interleaved text/image, and multiple-image prompts
- reject one unreadable or over-limit image without starting a Claude turn or exposing attachment data
- run a file-edit prompt and approve once in DSH
- deny a Bash prompt and confirm Claude receives the denial
- cancel a running prompt and confirm no orphan process
- refresh the page and continue the same live session
- restart DSH and resume the persisted Claude session
- idle-evict and resume
- type `/` and verify Claude Skills/Commands are discoverable with DSH collisions prefixed
- execute one Claude Skill and confirm it runs as an ordinary DSH turn with activity and approval behavior intact, with no command status row under the preceding response
- run Doctor with the actual resolved local executable; do not assume a macOS path

### 8.3 Completion evidence

The plugin is complete only when automated checks pass and the local linked profile demonstrates native/Claude coexistence, streaming, approval, cancellation, and resume without leaked processes or credentials.

## 9. Retirement / Future Work

Future work may:

- replace the LLM-seam bridge with a keyed DSH AgentFactory if DSH adds that public contract
- add explicit runtime state roots to DSH sandbox policy and enable kernel confinement
- complete and record platform-specific smoke coverage, including Linux and Windows
- continue publishing validated releases; the package is already distributed through npm

No compatibility fallback should copy the native DSH agent loop or silently downgrade Claude sessions to the native model route.
