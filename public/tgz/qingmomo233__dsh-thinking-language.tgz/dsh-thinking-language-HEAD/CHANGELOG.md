# Changelog

## 2.0.1

下拉选择框改为 **DeepSeek Harness 原生控件**，并完成浅色 / 深色主题适配。

### 变更

- **选择器改用 Harness 的 `Menu` 原语。** 设置页现在与内置「设置 → 通用 → 语言」行
  完全一致：`button.dshtl_selector`（左侧当前语言 + 右侧 `IconChevronDownOutlineRegular`）
  作为锚点，点击后由 `@deepseek-ai/dsh-client-ui-primitives` 的 `Menu` 渲染弹层
  （`align: "end"`、`portal: true`、选中态与键盘/焦点行为均由 shell 提供），
  不再使用原生 `<select>`。
- **浅色 / 深色主题跟随。** pill 使用与 `LanguageRow` 相同的 token：
  `--dsw-alias-bg-module-platform`（底色）、`--dsw-alias-label-primary`（文字）、
  `--dsw-alias-interactive-bg-hover`（hover）、`--dsw-radius-md`（圆角）；
  弹层配色、阴影与选中勾选由 shell 的 `Menu` 负责，因此切换主题时无需任何插件代码。
- **修正 2.0.0 的判断。** 0.2.2 并未移除 `@deepseek-ai/dsh-client-ui-primitives`：
  宿主自带的 `dsh-client-locale`、`dsh-client-ui-settings-general` 等客户端包都
  直接 require 它（由 web shell 提供）。本轮恢复对它的使用，控件规格直接对照
  `dsh-client-locale/lib/client.js` 的 `LanguageRow` 与它的 `LanguageRow.module.css`。

### 修复

- 选择器 pill 的尺寸与内置行对齐：高度 36px、`gap: 12px`、`padding: 0 14px`、
  圆角 `--dsw-radius-md`（原实现为 18px 圆角和自绘 SVG，看起来略偏圆、图标偏小）。

### 测试

- `smoke-test.mjs` 的 client 部分改为断言 `primitives.Menu` 的锚点、`selectedId`、
  `align` / `portal`、chevron 图标来源，以及 pill 的 token 规格；
  `cordis-check.mjs` 的 client stub 同步提供 primitives。两套测试均通过。

## 2.0.0

适配 **DSH 0.2.2-rc.1**（不再兼容 0.1.x），并修复「跟随系统」在中文系统上误判为英文的问题。

### 破坏性变更

- **仅支持 DSH 0.2.2-rc.1 及同系列版本。** `package.json` 新增
  `engines.dsh: ">=0.2.2-rc.1 <0.3.0-0"`；Harness 的兼容性校验在存在该字段时只读它，
  不再看 `peerDependencies`，因此旧版 DSH（含 0.1.x、0.2.0）会跳过本插件并在日志中写
  `is incompatible with dsh …`。
- **移除 `@deepseek-ai/dsh-client-ui-primitives` 依赖。** 该包在 0.2.2 已不存在；
  设置页改为插件自带的原生 `<select>` 与内联 chevron SVG，外观（pill、间距、hover、
  焦点环）与原先一致，不再 require 任何 Harness 客户端包。

### 修复

- **「跟随系统（自动）」在中文系统上回退英文。** 之前只读取设置文档里的
  `locale.preference`，而该字段**只有用户显式在「设置 → 通用 → 语言」里选过**才存在，
  于是候选列表里只剩 `undefined` 与 `"en"`，中文系统也落到英文。现在按序解析：
  已存储的界面语言偏好 → 调用方提供的系统语言 → **宿主检测到的操作系统区域**
  （`Intl.DateTimeFormat().resolvedOptions().locale`，再叠加
  `LC_ALL` / `LC_MESSAGES` / `LANG` / `LANGUAGE`）→ 英文。
  `zh`、`zh-Hans`、`zh-CN` 映射简体中文，`zh-Hant`、`zh-TW`、`zh-HK`、`zh-MO` 映射
  繁体中文；`C` / `POSIX`、未知标签才回退英文。
- 语言标签匹配更健壮：忽略扩展子标签（`zh-CN-u-nu-hanidec`）、POSIX 修饰
  （`de_DE.UTF-8@euro`）与大小写/下划线差异；`normalizeLocale` 统一清洗。
- 同一轮提示词组装的 section 与 reminder 现在**只读取一次**语言偏好
  （`resolveLanguagePreference`），避免两次求值之间设置变动造成指令与提醒语言不一致。

### 新增

- **插件图标 `dshlatking.png`。** 351×351 方图（142 KB，低于 Harness 的 256 KiB 上限），
  通过 `exports["./icon"]` 暴露，插件管理与设置界面都会显示。
- **`locale/en.json`、`locale/zh.json`。** 提供插件管理器的标题与说明；
  这两个文件在插件**未启用**时也会被读取，因此不再依赖 `package.json` 的 name 兜底。
- `exports` 增加 `./locale/*.json` 与 `./icon`；`files` 补上 `dshlatking.png` 与
  `locale/`，保证从 git 安装时资源不丢。

### 变更

- `lib/client.js`：去掉对 primitives 的探测与回退分支，选择器改由插件自己的
  `span.dshtl_select > select.dshtl_selector + svg.dshtl_chevron` 组成；
  写入逻辑（`auto` → `unset`，其余 → `set`）与 `thinking-language` 命名空间保持不变。
- `lib/index.js`：宿主侧缓存一次系统语言检测结果（`detectedSystemLocales`），
  提示词 section（order 85）与 reminder（order 1000）仍是函数式 `text`，
  每次组装提示词时求值。
- 测试同步更新：固定 `Intl` 与清空 `LC_*`/`LANG`，新增系统语言探测、中文端到端
  注入、清单元数据（`engines.dsh`、`exports["./icon"]`、图标尺寸与体积、locale 文件）
  等断言；`smoke-test.mjs` 与 `cordis-check.mjs` 全部通过。

## 1.5.2

### Changed

- **The page is one row.** The title and its hint now sit on the left of the
  selector instead of stacked above it, so 设置 → 思考语言 reads exactly like the
  built-in Language / Permission rows (`.dshtl_row` / `.dshtl_rowText` /
  `.dshtl_title` / `.dshtl_desc` replace the page-wide heading, intro and field
  rules). Pure client change: refresh the window to pick up the new bundle.

## 1.5.1

### Fixed

- **The settings page really appears on every install now.** DSH 0.2.x serves a
  settings namespace only when the plugin's exported `Config` declares a
  volatile field (`volatileForm()`), and applies a write in place only when the
  running config holds a
  [cosmokit](https://www.npmjs.com/package/@deepseek-ai/cosmokit) reference
  (`volatileEntries()` / `updateVolatile()`). Both used to depend on the
  installed schemastery having the `.volatile()` decorator (3.18.4), so a
  profile whose lockfile had pinned an older 3.18.x got neither: the namespace
  was never served, `settings/describe` never listed it, and the page stayed
  invisible with no error anywhere. The field is now marked volatile directly
  and resolved into a reference built on cosmokit's shared `Symbol.for`
  protocol, so any 3.18.x schemastery works; a schemastery that does have the
  decorator keeps its own reference, which passes through untouched. The
  dependency range stays `^3.18.1` on purpose — nothing to fetch, nothing to
  fail.
- Covered by two new smoke-test checks plus a decorator-less schema scenario
  (the decorator is hidden for one import, reproducing the old install), and
  verified against the actual 3.18.2 copy that a stale profile lockfile had
  installed: `volatileForm(Config)` is served, `isVolatilePath()` allows the
  field, `plainConfig()` unwraps it for the UI, and the Loader's in-place
  update reaches the prompt surfaces.

## 1.5.0

### Changed

- **The picker is a settings page of its own.** Settings → **思考语言 / Thinking
  language** (a `settings.section` entry, order 25) replaces the row that used
  to sit under Settings → General. The shell renders a section cell with no
  label of its own, so the page draws its own heading, hint and selector — the
  same pill the built-in Language / Permission rows use. The nav label is bound
  through the entry's `locale` face (the existing `title` key), and the entry
  keeps the same store, `inject` write face and namespace, so nothing about the
  read/write path changed.
- The plugin's general-section footprint is gone: no `settings.general.item`
  registration, no row markup, and the CSS block is renamed
  `dsh-thinking-language/page.css` (`dshtl_page` / `dshtl_heading` /
  `dshtl_intro` / `dshtl_field` / `dshtl_selector` / `dshtl_chevron`).

  Both suites cover the new surface: the section registration and its
  dictionary-bound label, the page's own heading/intro/selector tree, the
  active-language label inside the pill, and the deferred "no settings
  transport" warning.

## 1.4.3

### Fixed

- **The settings row is served on dsh 0.2.x at last.** 1.4.2 fixed the browser
  transport, but the row still could not appear, because the *host* half never
  made `thinking-language` a settings namespace: 0.2.x dropped
  `settings.register(ns, schema)` (the call threw, was logged, and was
  swallowed), and it derives the served namespace list from the profile's
  plugin entries instead — keyed by the entry id, with the schema taken from
  the plugin's own exported `Config`, and **only for entries that declare a
  volatile field** (`volatileForm()`). An unmarked schema is a namespace the
  Settings UI can neither list nor write, which is exactly why the row stayed
  invisible however correct the client was.

  The field is now marked `.volatile()` (feature-detected, so a harness whose
  schemastery predates the decorator keeps the 0.1.x `register()` path), and
  `apply` declares the instance's page policy through
  `settings.configure({ auto: false }, ctx.fiber)` the way the built-in locale
  plugin does — the namespace draws its own row instead of an auto-generated
  page.

  The preference read follows the same split: the registered namespace scope on
  0.1.x, and this plugin's own resolved config on 0.2.x, where a volatile field
  is a `createVolatile()` reference the owning runtime updates in place — so a
  language switch still needs no restart. `auto` resolves the system locale
  through `settings.describe()` on 0.2.x, which no longer exposes `get(ns)`.

  Covered by new checks in both suites: the schema's volatile marker, a live
  field reference, a plain config section, a `describe()` projection, and a
  0.2.x `apply` that must claim the row policy once, for its own fiber, while
  the instruction follows the live reference.

## 1.4.2

### Fixed

- **The settings row now appears on dsh 0.2.x.** The 1.4.1 chevron fix was real
  but unreachable: the row was still waiting for the `settingsScope` service,
  which dsh 0.2.x renamed to `configForms` (a scan of the shipped core finds the
  old name in 104 files of the 0.1.x runtime and in **none** of the 0.2.0-rc.2
  tree). A `ctx.inject` branch waiting for a service that no longer exists never
  runs and never fails, so nothing registered, nothing was logged as an error,
  and the setting was simply absent from an otherwise healthy Settings panel.

  The plugin now installs a branch per transport generation and mounts the row
  through whichever one the harness serves: `configForms` on 0.2.x, where the
  form is fetched per namespace and the row is registered while
  `whileServed([...])` reports the Host serving it; the legacy `settingsScope`
  (form bound per namespace) before that. A harness serves exactly one
  generation, so the mount is latched and the row can never register twice. The
  availability warning after boot now distinguishes "no transport at all", "no
  `locale`", and "transport present but the row never mounted".

  Both suites cover the split: `smoke-test.mjs` exercises every generation with
  a hand-built schema (proving the catalog is read through the `configForms`
  describe *mirror*, not the fallback table), and `cordis-check.mjs` boots the
  real container against `configForms` to keep the late-`locale` guard.

## 1.4.1

### Fixed

- **The settings row disappeared on dsh 0.2.x — the real cause of "installed but
  not showing".** The row asked the primitives package for
  `IconChevronDownOutline14`. dsh 0.1.x named its icons by size, dsh 0.2.x names
  them by weight, so on 0.2.x that lookup was `undefined` and the row rendered
  `undefined` as a component. React then throws *while rendering* ("Element type
  is invalid… expected a string or a class/function but got: undefined"), the
  slot renderer drops the row, and the setting vanishes from an otherwise
  perfectly healthy Settings panel — no plugin error, no failed fiber, nothing
  in the UI to point at it.

  The chevron is now resolved through the names the shipped packages actually
  use, newest first (`IconChevronDownOutlineRegular` → `IconChevronDownOutline`
  → `IconChevronDownOutline14`), and an absent icon degrades to no icon instead
  of a failed row. `smoke-test.mjs` now fails when the bundle names a primitives
  export outside that tolerated set, so the next rename cannot repeat this.

## 1.4.0

### Removed

- **The `/thinking-language` chat command.** The Settings → General row is the
  only surface now: the command duplicated it and was rarely used. Gone with it
  are its pure helpers (`describeLanguage`, `usageLine`, `parseCommandArgument`)
  from `lib/languages.js`, the host's `commands` injection branch, the exported
  type declarations, and both suites' command coverage.

### Changed

- The host entry no longer acquires the `commands` service, so one less
  degradation path is needed. Reads and writes still go through the same
  `thinking-language` namespace, and the stored value is untouched.
- **The catalog is down to ten entries**: `zh-CN`, `zh-TW`, `en`, `ru`, `fr`,
  `de`, `es`, `ar`, `pt`, `ja` (plus `auto`). Italian, Korean, Hindi, Turkish,
  Vietnamese, Thai, Polish, Ukrainian, Dutch, Swedish, Indonesian and Czech are
  gone from the picker and the settings schema. A session that stored one of the
  removed ids keeps the value verbatim (the plugin never rewrites user data) and
  simply produces no thinking instruction, exactly like any other unknown id.
- The row's own dictionaries now match that set: Arabic and Portuguese were
  added, Korean removed.

## 1.3.0

Desktop-app (dsh 0.2.0-rc.2) alignment. No settings migration: the
`thinking-language` namespace, its `language` field, the plugin name and the
`/thinking-language` command are unchanged.

### Fixed

- **The settings row could be dropped silently.** The browser half aborted its
  whole `apply` — logging "the platform UI primitives module is unavailable;
  the settings row is disabled" — whenever `@deepseek-ai/dsh-client-ui-primitives`
  was absent from the harness's static module table. A missing row is
  indistinguishable from "the plugin is not installed". The row is now always
  registered: when the primitives module (or just its `Menu`) is unavailable it
  falls back to a native `<select>` built from the React seat the slot renderer
  already owns, so the preference stays reachable on every harness generation.

### Changed

- `dsh.client` now follows the shape the shipped client plugins actually use:
  `inject` names the **package rows** whose services the row waits for
  (`@deepseek-ai/dsh-client-locale` for `locale`,
  `@deepseek-ai/dsh-client-ui-settings` for `settingsScope`,
  `@deepseek-ai/dsh-client-ui-settings-general` for the
  `settings.general.item` slot) so the module graph orders them before this
  row.
- Dropped the non-standard `dsh.client.external` array (`react` and
  `@deepseek-ai/dsh-client-ui-primitives` are platform **seed words**, not
  graph rows, so the array could never add an edge) and the `immediately: true`
  bootstrap-tier flag, which is reserved for bundles that must activate before
  the shell's own providers (this row consumes them instead).
- Added `dsh.compatibility` (`dsh` range plus a per-release `dshReleases`
  table) so the desktop app's and the CLI's compatibility gates can accept the
  release instead of skipping the bundle.
- `exports` now publishes `./cordis.patch.yml`, matching `dsh-base` and the
  other published bundles.
- The `@deepseek-ai/dsh-client-ui-primitives` peer range is bounded
  (`>=0.1.0-rc.5 <0.3.0-0`) so a future 0.3.x generation is not silently
  claimed as compatible.

## 1.2.0

Compatibility-focused refactor. No settings migration is required: the
`thinking-language` namespace, its `language` field, its stored values, the
plugin name (`thinking-language`), and the `/thinking-language` command all
keep working exactly as before.

### Fixed

- **The settings row rendered its raw keys (`title`, `hint`, `lang.auto`).**
  A regression introduced while making the browser half's service set optional:
  the dictionaries were registered behind a one-shot `ctx.get("locale")` check
  while the plugin only requires `slots`. `slots` becomes available before
  `settingsScope`, so apply could run while the locale plugin was still
  starting, the check found nothing, and the registration was skipped for the
  whole session — the renderer's `t` seat then fell back to the key itself. The
  dictionaries now register on a `ctx.inject(["locale"])` branch that **waits**
  for the service, and the row waits for it as well (the slot renderer treats a
  declared `locale` namespace with no installed locale face as a fatal assembly
  error). `cordis-check.mjs` reproduces the late-locale boot and fails if the
  registration stops waiting.
- **"Follow the system (auto)" only knew about English.** Every locale except
  `en` — including `zh-TW`, `ja`, `ko`, and `de` — resolved to Simplified
  Chinese. The locale tag is now matched hierarchically over the whole catalog
  (exact id → region → language), with the Chinese entries decided by
  script/region (`zh`/`zh-Hans`/`zh-CN` → Simplified,
  `zh-Hant`/`zh-TW`/`zh-HK`/`zh-MO` → Traditional), and an unrecognised locale
  falls back to English, matching the shell locale plugin's own fallback.
- **The schema default was applied on every write.** Selecting "auto" now
  clears the stored field (leaving the schema default in charge) instead of
  writing the literal `"auto"`.
- **The `auto` command reply is byte-identical.** `describeLanguage` still
  answers `auto (follow the system)`.
- **No user-visible copy changed.** The row's hint and the usage step still
  describe the system-prompt instruction, which is evaluated per prompt assembly
  and therefore applies to new sessions. A separately registered prompt context
  additionally restates the choice on every model call, but the copy was left
  untouched rather than "corrected" — see *Unchanged* below.

### Compatibility

- **Host**: each service is acquired through its own `ctx.inject` branch, so a
  harness without `commands` (or without `systemPrompt`) keeps the other
  surfaces. A refused `settings.register()` is logged once and the plugin keeps
  working through the settings service.
- **Reads** accept both handle shapes (`settings.get(ns)` and the namespace
  scope `settings.register()` returns) and treat any refusal as "absent"
  instead of throwing; a malformed stored section degrades to `auto`.
- **Browser bundle**: hard-requires only `slots`. The platform UI primitives
  module and React are resolved through a tolerant `require` helper, so a
  bundle never dies at materialization on a missing seed word; without
  `settingsScope` the row is skipped and reported once after boot; without
  `locale` the row uses its own copy.
- **No React peer dependency**: elements are built with the platform
  `React.createElement` when available, so `react/jsx-runtime` is no longer
  required by the bundle.
- **The picker can no longer drift from the host catalog**: the settings schema
  carries a label per enum value (the endonym, e.g. `简体中文`) and the row
  derives its entries from `settingsScope.describe()`, with a bundled fallback
  and a test that fails on drift. The rendered labels are byte-for-byte what
  the hard-coded table used to show.
- `settings.register()` failures, `describe()` failures, refused writes, and a
  missing settings transport are now reported through the harness logger.
- `scripts/patch-apiproxy.mjs` is a **dry run by default** (`--write` to
  apply), backs the file up before editing, and reports "exposure is automatic"
  on harnesses that no longer carry the `WEB_SETTINGS_NAMESPACES` allowlist
  (DSH ≥ 0.2.6).

### Added

- `lib/languages.js`: the pure core (catalog, locale matching, instruction and
  reminder copy, command parsing) — no cordis and no browser globals, so it is
  directly unit-testable.
- Command arguments accept unique prefixes (`/thinking-language japan`).
- `smoke-test.mjs` now covers the locale matrix, both settings-handle shapes, a
  refused registration, the client bundle's degradation paths, and host/client
  catalog drift.

### Changed

- `lib/types/*.d.ts` describe the full exported surface.
- The package declares `npm test`, and `@deepseek-ai/cordis` is a devDependency,
  so a fresh `pnpm install` is enough to run the checks.
- The READMEs no longer embed a machine-specific absolute path in the local
  install example; they use a `<plugin-dir>` placeholder instead.

### Unchanged (deliberately)

- Every user-visible string: the row's title/hint and the `lang.auto` label in
  all eight dictionaries, and the endonym shown for each entry in the dropdown.
  This release only touches compatibility, robustness, and the `auto` locale
  mapping.

## 1.1.0

- Renamed the package from `dsh-plugin-thinking-language` to
  `dsh-thinking-language`.
- Made the browser bundle independent of `@deepseek-ai/dsh-client-store` by
  inlining the small `defineStore` shim it needs.

## 1.0.0

- First release: settings row, system-prompt instruction, per-step reminder,
  and the `/thinking-language` command.
