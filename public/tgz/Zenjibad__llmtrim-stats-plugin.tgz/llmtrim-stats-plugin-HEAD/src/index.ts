/**
 * llmtrim-stats-plugin — host half.
 *
 * Reads the llmtrim interceptor's live ledger by running `llmtrim status --json`
 * (the same command the CLI dashboard uses) through the `subprocess` service,
 * reshapes it into a clean snapshot, and serves it to the client bundle over an
 * HTTP route (`GET /llmtrim-stats/api`).
 *
 * Also owns the `llmtrim-stats` settings namespace (carousel mode + which stats
 * to show), exposed via `PUT /llmtrim-stats/config` and embedded in the
 * snapshot so the client gets it in one poll.
 *
 * Runtime note: packaged profile plugins are real Node modules, so Date works;
 * external commands go through the `subprocess` service (same pattern as
 * headroom-stats-plugin / deepseek-cost-usage-status-plugin).
 */
import z from '@deepseek-ai/schemastery'
import type { Context } from '@deepseek-ai/cordis'

export const name = 'llmtrim-stats-plugin'

// Hard dependencies: webServer (serves the routes), subprocess (runs
// `llmtrim status --json`), settings (persists the carousel config).
export const inject = ['webServer', 'subprocess', 'settings']

export const NAMESPACE = 'llmtrim-stats'

/** Carousel configuration persisted in the settings namespace. */
export interface LlmtrimConfig {
  mode: 'rotating' | 'static'
  staticStats: string[]
}

/** All carousel slide keys (also the static-mode stat list). */
export const STAT_KEYS = [
  'savedToday',
  'savedTotal',
  'youPaid',
  'wouldHave',
  'savedWeek',
  'tokensTrimmed',
  'requests',
  'inputSavedPct',
  'roundTripPct',
] as const

/** Default carousel config: rotating, all stats. */
const BASE_CONFIG: LlmtrimConfig = { mode: 'rotating', staticStats: [...STAT_KEYS] }

/**
 * The plugin's Config — under DSH >= 0.2 a plugin's settings ARE its Loader
 * entry Config, so this schema replaces the removed
 * `settings.register(ns, schema, { base })` namespace. The Loader validates it
 * through cordis's Standard-Schema probe and hands the result to `apply()`.
 *
 * Both fields are `.volatile()` for two independent reasons: `settings.update()`
 * REFUSES a non-volatile field, and the Loader only commits a volatile-only
 * change in place (swapping the references and emitting
 * `loader/volatile-update`) instead of reloading the entry — which is what lets
 * a Save take effect without losing the route registrations or the snapshot.
 */
export const Config = z.object({
  mode: z.union([z.const('rotating'), z.const('static')]).default(BASE_CONFIG.mode).volatile(),
  staticStats: z.array(z.string()).default([...BASE_CONFIG.staticStats]).volatile(),
})

/** A schemastery `.volatile()` output: a stable reference whose value is read live. */
interface VolatileValue<T> {
  get(): T
}

/** The resolved Config object the Loader hands to `apply()`. */
interface PluginConfig {
  mode?: VolatileValue<string> | string
  staticStats?: VolatileValue<string[]> | string[]
}

/** Unwrap a volatile reference, tolerating a plain value (older hosts, tests). */
function readLive<T>(value: VolatileValue<T> | T | undefined, fallback: T): T {
  if (value !== null && typeof value === 'object' && typeof (value as VolatileValue<T>).get === 'function') {
    const live = (value as VolatileValue<T>).get()
    return live === undefined ? fallback : live
  }
  return (value as T | undefined) ?? fallback
}

/** A plain JSON snapshot returned to the client. */
export interface LlmtrimSnapshot {
  ok: boolean
  error?: string
  command?: string
  config?: LlmtrimConfig
  daemon?: {
    running: boolean
    health: string | null
    version: string | null
    autostart: boolean
    uptimeSecs: number | null
  }
  totals?: {
    requests: number
    tokensTrimmed: number
    inputBefore: number
    inputAfter: number
    inputSavedPct: number | null
    outputBefore: number
    outputAfter: number
    outputSavedPct: number | null
    cacheReadTokens: number
    addedLatencyMs: number | null
  }
  money?: {
    savedUsd: number
    savedTodayUsd: number
    paidUsd: number
    wouldHaveUsd: number
    savedWeekUsd: number
    turns: number
  }
  cost?: {
    savedUsd: number
    spendUsd: number
    netSavedUsd: number
    roundTripPct: number
  }
  byModel?: Array<{
    model: string
    requests: number
    savedPct: number | null
    costSavedUsd: number
  }>
  meta?: {
    fetchedAt: string
    schemaVersion: number
  }
}

/** Minimal subprocess service surface (typed loosely to avoid a hard dep). */
interface SubprocessLike {
  resolveExecutable(command: string): Promise<string>
  spawn(spec: {
    argv: readonly string[]
    cwd: string
    stdio: { stdin: string; stdout: { maxBytes: number }; stderr: string }
    graceMs?: number
  }): {
    done: Promise<{ exitCode: number | null; signal: unknown }>
    collected: { stdout: { readFrom(offset: number): { text: string } } }
  }
}

interface WebServerLike {
  register(route: {
    kind: 'exact' | 'prefix'
    path: string
    handler: (req: unknown, res: any) => void | Promise<void>
  }): () => void
}

interface SettingsLike {
  /** DSH >= 0.2: merge fields into the Loader entry's Config (the removed
   *  `register`/`get` namespace API has no replacement). */
  update(ns: string, patch: object, expectedRevision?: number): Promise<void>
  /** DSH >= 0.2: opt out of the schema-generated page (the bundle ships its own). */
  configure?(presentation: { auto?: boolean }): () => void
}

/** The Loader's view of one entry, read only to learn this plugin's entry id. */
interface LoaderLike {
  entries?: () => Array<{ options?: { id?: string; name?: string } }>
}

function json(res: any, status: number, body: unknown): void {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
  res.end(JSON.stringify(body))
}

/** Coerce an unknown value to a finite number, or null. */
export function num(v: unknown): number | null {
  return typeof v === 'number' && Number.isFinite(v) ? v : null
}

function num0(v: unknown): number {
  const n = num(v)
  return n === null ? 0 : n
}

/** Resolve the llmtrim executable via the subprocess service. */
async function resolveLlmtrim(sub: SubprocessLike): Promise<string> {
  try {
    // Resolve the real executable, NOT the bare name: on Windows, bare
    // `llmtrim` resolves to npm's `.cmd` shim (PATHEXT walks `.CMD` before
    // reaching `%LOCALAPPDATA%\llmtrim\bin\llmtrim.exe`), and spawning a `.cmd`
    // without a shell throws EINVAL. `llmtrim.exe` forces the exe extension.
    const name = process.platform === 'win32' ? 'llmtrim.exe' : 'llmtrim'
    return await sub.resolveExecutable(name)
  } catch {
    // Fall back to a known npm-managed location if PATH resolution failed.
    const candidates = [
      process.env.LLMTRIM_BIN,
      'C:\\Users\\Administrator\\AppData\\Roaming\\npm\\node_modules\\@llmtrim\\win32-x64\\bin\\llmtrim.exe',
    ]
    for (const c of candidates) if (c) return c
    throw new Error('llmtrim executable not found on PATH (run `npm i -g @llmtrim/cli`)')
  }
}

/** Run `llmtrim status --json` and capture stdout. */
async function fetchLlmtrimStatus(sub: SubprocessLike, exe: string): Promise<any> {
  const handle = sub.spawn({
    argv: [exe, 'status', '--json'],
    cwd: process.env.USERPROFILE ?? '.',
    stdio: { stdin: 'ignore', stdout: { maxBytes: 512 * 1024 }, stderr: 'ignore' },
    graceMs: 15000,
  })
  const result = await handle.done
  if (result.exitCode !== 0) throw new Error(`llmtrim status exited ${String(result.exitCode)}`)
  const out = handle.collected.stdout.readFrom(0).text
  return JSON.parse(out)
}

/**
 * llmtrim's `by_period` rows carry tokens but no money; `money` is always
 * lifetime. "Saved this week" is therefore prorated: the current-week token
 * share × lifetime saved.
 *
 * Period keys are LOCAL dates (`2026-08-19`) by default (the `--daily` /
 * `--weekly` flags only re-bucket `by_period`; the plugin never passes them),
 * so we sum the keys falling inside the current Monday-start week.
 */
function computeSavedWeekUsd(raw: any): number {
  const periods = Array.isArray(raw?.by_period) ? raw.by_period : []
  const totalInput = num0(raw?.input?.before)
  if (totalInput <= 0 || periods.length === 0) return 0
  const now = new Date()
  const day = (now.getDay() + 6) % 7 // 0 = Monday
  const monday = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() - day))
  const nextMonday = new Date(monday.getTime() + 7 * 86400000)
  const weekInput = periods.reduce((sum: number, p: any) => {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(p?.period ?? ''))
    if (!m) return sum
    const t = Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]))
    if (t >= monday.getTime() && t < nextMonday.getTime()) return sum + num0(p?.input_before)
    return sum
  }, 0)
  if (weekInput <= 0) return 0
  return (weekInput / totalInput) * num0(raw?.money?.saved_usd)
}

export function apply(ctx: Context, pluginConfig?: PluginConfig): void {
  const webServer = (ctx as unknown as { webServer: WebServerLike }).webServer
  const sub = ctx.get('subprocess') as SubprocessLike | undefined
  const settings = ctx.get('settings') as SettingsLike | undefined

  /** This plugin's profile entry id, which is what `settings.update` addresses. */
  const ENTRY_ID = ((): string => {
    try {
      const rows = (ctx.get('loader') as LoaderLike | undefined)?.entries?.() ?? []
      const own = rows.find((row) => row.options?.name === 'llmtrim-stats-plugin' && typeof row.options.id === 'string')
      return own?.options?.id ?? NAMESPACE
    } catch {
      return NAMESPACE
    }
  })()

  // The bundle ships its own settings page, so the schema-generated one would be
  // a duplicate. Guarded: `configure` is newer than the Config model itself.
  if (settings !== undefined && typeof settings.configure === 'function') {
    try {
      ctx.effect(() => settings.configure?.({ auto: false }) as () => void)
    } catch {
      // contained: a host that refuses the policy still gets the custom page
    }
  }

  /** The live carousel config, normalized from the volatile Config refs. */
  const getConfig = (): LlmtrimConfig => {
    const mode = readLive(pluginConfig?.mode, BASE_CONFIG.mode)
    const staticStats = readLive(pluginConfig?.staticStats, BASE_CONFIG.staticStats)
    if (mode === 'static') {
      const valid = Array.isArray(staticStats)
        ? staticStats.filter((s) => (STAT_KEYS as readonly string[]).includes(s))
        : []
      return { mode: 'static', staticStats: valid.length > 0 ? valid : [...STAT_KEYS] }
    }
    return { mode: 'rotating', staticStats: [...STAT_KEYS] }
  }

  ctx.effect(() =>
    webServer.register({
      kind: 'exact',
      path: '/llmtrim-stats/api',
      handler: async (_req, res) => {
        try {
          if (sub === undefined) {
            json(res, 503, { ok: false, error: 'subprocess service unavailable' })
            return
          }
          const exe = await resolveLlmtrim(sub)
          const raw = await fetchLlmtrimStatus(sub, exe)
          const snapshot: Omit<LlmtrimSnapshot, 'ok' | 'error'> = {
            command: exe,
            config: getConfig(),
            daemon: {
              running: !!raw?.daemon?.running,
              health: typeof raw?.daemon?.health === 'string' ? raw.daemon.health : null,
              version: typeof raw?.daemon?.version === 'string' ? raw.daemon.version : null,
              autostart: !!raw?.daemon?.autostart,
              uptimeSecs: num(raw?.daemon?.uptime_secs),
            },
            totals: {
              requests: num0(raw?.requests),
              tokensTrimmed: Math.max(0, num0(raw?.input?.before) - num0(raw?.input?.after)),
              inputBefore: num0(raw?.input?.before),
              inputAfter: num0(raw?.input?.after),
              inputSavedPct: num(raw?.input?.saved_pct),
              outputBefore: num0(raw?.output?.before),
              outputAfter: num0(raw?.output?.after),
              outputSavedPct: num(raw?.output?.saved_pct),
              cacheReadTokens: num0(raw?.cache_read_tokens),
              addedLatencyMs: num(raw?.added_latency_ms),
            },
            money: {
              savedUsd: num0(raw?.money?.saved_usd),
              savedTodayUsd: num0(raw?.money?.saved_today_usd),
              paidUsd: num0(raw?.money?.paid_usd),
              wouldHaveUsd: num0(raw?.money?.would_have_usd),
              savedWeekUsd: computeSavedWeekUsd(raw),
              turns: num0(raw?.money?.turns),
            },
            cost: {
              savedUsd: num0(raw?.cost?.saved_usd),
              spendUsd: num0(raw?.cost?.spend_usd),
              netSavedUsd: num0(raw?.cost?.net_saved_usd),
              roundTripPct: num(raw?.cost?.round_trip_pct) ?? 0,
            },
            byModel: Array.isArray(raw?.by_model)
              ? raw.by_model.map((m: any) => ({
                  model: String(m?.model ?? 'unknown'),
                  requests: num0(m?.requests),
                  savedPct: num(m?.saved_pct),
                  costSavedUsd: num0(m?.cost_saved_usd),
                }))
              : [],
            meta: { fetchedAt: new Date().toISOString(), schemaVersion: 2 },
          }
          json(res, 200, { ok: true, ...snapshot })
        } catch (e) {
          json(res, 200, { ok: false, error: String((e as Error)?.message ?? e) })
        }
      },
    }),
  )

  // Config update route: PUT { mode, staticStats } → persisted via settings.
  ctx.effect(() =>
    webServer.register({
      kind: 'exact',
      path: '/llmtrim-stats/config',
      handler: async (req: any, res) => {
        try {
          if (settings === undefined) {
            json(res, 503, { ok: false, error: 'settings service unavailable' })
            return
          }
          const body = await new Promise<string>((resolve, reject) => {
            let data = ''
            req.on('data', (c: Buffer) => {
              data += c.toString('utf8')
              if (data.length > 65536) {
                reject(new Error('config payload too large'))
                req.destroy()
              }
            })
            req.on('end', () => resolve(data))
            req.on('error', reject)
          })
          const parsed = JSON.parse(body) as { mode?: string; staticStats?: unknown }
          const mode = parsed.mode === 'static' ? 'static' : 'rotating'
          const stats = Array.isArray(parsed.staticStats)
            ? parsed.staticStats.filter((s): s is string => typeof s === 'string' && (STAT_KEYS as readonly string[]).includes(s))
            : [...STAT_KEYS]
          const next: LlmtrimConfig = { mode, staticStats: mode === 'static' ? stats : [...STAT_KEYS] }
          // Persist as this entry's Config. Both fields are volatile, so the
          // Loader commits them into the live refs instead of reloading the
          // entry; echo what was written so the response is deterministic.
          await settings.update(ENTRY_ID, next)
          json(res, 200, { ok: true, config: next })
        } catch (e) {
          json(res, 400, { ok: false, error: String((e as Error)?.message ?? e) })
        }
      },
    }),
  )
}
