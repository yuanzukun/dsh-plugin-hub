#!/usr/bin/env node
/**
 * dsh-win-bash-fix — one-shot installer (copy-based, no npm needed).
 *
 * Usage:
 *   node install.mjs                 # install into the default "web" profile
 *   node install.mjs --profile web  # explicit profile name
 *   node install.mjs --home C:\...  # explicit dsh home (default ~/.dsh)
 *
 * What it does (idempotent — safe to run again):
 *   1. Copies lib/index.js + preset-files into <profile>/win-bash-fix/
 *   2. Appends the `insert` patch entry to the profile's cordis.patch.yml
 *   3. Syncs the bundled minimal-win preset into ~/.dsh/.agent-presets/minimal-win
 *      (only when the directory does not already exist, so local edits survive)
 *
 * After install: restart `dsh web` and hard-refresh the browser (Ctrl+Shift+R).
 *
 * Prefer the bundle route when you use npm/pnpm (README "Install via bundle"):
 *   add "@jyleaves/dsh-win-bash-fix": "github:Jyleaves/dsh-win-bash-fix"
 *   to the profile package.json dependencies, the package name to
 *   dsh.profile.bundles, then `pnpm install` + restart.
 */
import { cpSync, existsSync, mkdirSync, readFileSync, writeFileSync, copyFileSync, readdirSync, statSync } from "node:fs";
import { join, dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const profile = args.indexOf("--profile") >= 0 ? args[args.indexOf("--profile") + 1] : "web";
const homeArg = args.indexOf("--home") >= 0 ? args[args.indexOf("--home") + 1] : undefined;
const home = resolve(homeArg ?? process.env.DSH_HOME ?? join(process.env.USERPROFILE ?? process.cwd(), ".dsh"));
const profileDir = join(home, "profiles", profile);
const pluginDir = join(profileDir, "win-bash-fix");
const patchPath = join(profileDir, "cordis.patch.yml");
const presetDst = join(home, ".agent-presets", "minimal-win");

const PATCH_BLOCK = `# --- dsh-win-bash-fix (Windows Git Bash fix + minimal-win preset) ---
- insert:
    - id: win-bash-fix
      name: ./win-bash-fix/index.js
# --- end dsh-win-bash-fix ---
`;

function fail(msg) {
	console.error(`[install] ERROR: ${msg}`);
	process.exit(1);
}

console.log(`[install] profile dir : ${profileDir}`);
console.log(`[install] preset target: ${presetDst}`);

// 1. Plugin + preset files into the profile directory.
if (!existsSync(profileDir)) fail(`profile directory not found: ${profileDir}`);
mkdirSync(pluginDir, { recursive: true });
cpSync(join(here, "lib", "index.js"), join(pluginDir, "index.js"), { force: true });
cpSync(join(here, "preset-files"), join(pluginDir, "preset-files"), { recursive: true, force: true });
console.log("[install] plugin copied -> " + pluginDir);

// 2. cordis.patch.yml insert (idempotent).
let patch = existsSync(patchPath) ? readFileSync(patchPath, "utf8") : "";
if (patch.includes("win-bash-fix")) {
	console.log("[install] cordis.patch.yml already patched (skipped)");
} else {
	writeFileSync(patchPath, patch.trimEnd() + (patch.trimEnd() ? "\n" : "") + PATCH_BLOCK, "utf8");
	console.log("[install] cordis.patch.yml patched");
}

// 3. Presets sync (only if absent; keeps local edits).
const presetRoot = join(here, "preset-files");
if (!existsSync(presetRoot)) {
	console.log("[install] preset-files not found (skipped)");
} else {
	for (const name of readdirSync(presetRoot)) {
		const src = join(presetRoot, name);
		if (!statSync(src).isDirectory()) continue;
		const dst = join(home, ".agent-presets", name);
		if (existsSync(dst)) {
			console.log(`[install] preset ~/.dsh/.agent-presets/${name} already exists (kept as-is)`);
			continue;
		}
		mkdirSync(dst, { recursive: true });
		for (const f of ["agent.cordis.yml", "preset.yml", "NOTICE", "tool-bootstrap.mjs"]) {
			const s = join(src, f);
			if (existsSync(s)) copyFileSync(s, join(dst, f));
		}
		console.log(`[install] preset ${name} installed`);
	}
}

console.log("\n[install] done. Restart dsh web and hard-refresh the browser (Ctrl+Shift+R).");
