/**
 * Unit tests for dsh-win-bash-fix (zero dependencies, node:test).
 * Run:  node --test tests/unit.test.mjs
 *
 * Covers the plugin contract without a live dsh:
 *  - win32: MSYS env injection (idempotent), PATH prefix, inspector patch,
 *    sandbox confine bypass, preset sync (temp DSH_HOME)
 *  - non-win32: no-op
 *  - noop inspector shape (LocalTerminalHandle seam)
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, existsSync, readFileSync, rmSync, mkdirSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { apply, noopInspector } from "../lib/index.js";

function freshCtx() {
	const calls = { spawnTerminal: 0, confine: 0 };
	const subprocessProto = {
		async spawnTerminal(spec) {
			calls.spawnTerminal++;
			return { ok: true, spec };
		},
	};
	const sandboxProto = {
		confine(argv, policy) {
			calls.confine++;
			return { argv, policy };
		},
	};
	const subprocess = Object.create(subprocessProto);
	const sandbox = Object.create(sandboxProto);
	const terminalsProto = {
		async kill(owner, id, reason = "model request") {
			const record = this.sessions.get(id);
			if (record === void 0) throw new Error("not owned: " + id);
			if (record.closing !== void 0) {
				await record.closing;
				return false;
			}
			record.closing = record.session.close(reason);
			try {
				await record.closing;
				this.sessions.delete(id);
				return true;
			} catch (error) {
				record.closing = void 0;
				throw error;
			}
		},
	};
	const terminals = Object.create(terminalsProto);
	terminals.sessions = new Map();
	const ctx = {
		get(key) {
			if (key === "subprocess") return subprocess;
			if (key === "sandbox") return sandbox;
			if (key === "terminals") return terminals;
			return void 0;
		},
	};
	return { ctx, calls, subprocessProto, sandboxProto, terminalsProto };
}

test("non-win32 apply is a complete no-op", () => {
	const { ctx, calls } = freshCtx();
	const envBefore = { ...process.env };
	delete process.env.MSYSTEM;
	delete process.env.CHERE_INVOKING;
	delete process.env.MSYS2_PATH_TYPE;
	apply(ctx, {}, "linux");
	for (const key of Object.keys(envBefore)) {
		if (["MSYSTEM", "CHERE_INVOKING", "MSYS2_PATH_TYPE"].includes(key)) continue;
		assert.equal(process.env[key], envBefore[key], `env changed: ${key}`);
	}
	assert.equal(process.env.MSYSTEM, void 0, "MSYSTEM must not be set on non-win32");
	assert.equal(calls.spawnTerminal, 0);
	assert.equal(calls.confine, 0);
});

test("win32: MSYS env variables injected", () => {
	const { ctx } = freshCtx();
	apply(ctx, {}, "win32");
	assert.equal(process.env.MSYSTEM, "MINGW64");
	assert.equal(process.env.CHERE_INVOKING, "1");
	assert.equal(process.env.MSYS2_PATH_TYPE, "inherit");
});

test("win32: Git bin path prefixed on PATH (idempotent on re-apply)", () => {
	const { ctx } = freshCtx();
	delete process.env.GIT_ROOT;
	apply(ctx, {}, "win32");
	const path = process.env.PATH ?? "";
	assert.ok(path.includes("C:/Program Files/Git/bin"), "git bin missing from PATH");
	assert.ok(path.includes("C:/Program Files/Git/usr/bin"), "git usr/bin missing from PATH");
	// re-apply must not duplicate the prefix
	const after = process.env.PATH;
	apply(ctx, {}, "win32");
	assert.equal(process.env.PATH, after, "PATH prefix duplicated on re-apply");
});

test("win32: config.gitRoot overrides default", () => {
	const { ctx } = freshCtx();
	apply(ctx, { gitRoot: "D:/Custom/Git" }, "win32");
	assert.ok(process.env.PATH.includes("D:/Custom/Git/bin"));
});

test("win32: spawnTerminal gains a no-op inspector and still delegates", async () => {
	const { ctx, calls, subprocessProto } = freshCtx();
	apply(ctx, {}, "win32");
	const sub = ctx.get("subprocess");
	assert.equal(calls.spawnTerminal, 0);
	await sub.spawnTerminal({ argv: ["bash"], rows: 40, cols: 160 });
	assert.equal(calls.spawnTerminal, 1);
	// second call must not re-create the inspector (no churn)
	await sub.spawnTerminal({ argv: ["bash"] });
	assert.equal(calls.spawnTerminal, 2);
});

test("win32: sandbox confine bypasses the runner", () => {
	const { ctx, calls, sandboxProto } = freshCtx();
	apply(ctx, {}, "win32");
	const sandbox = ctx.get("sandbox");
	const argv = ["C:/Program Files/Git/bin/bash.exe", "-i"];
	const result = sandbox.confine(argv, { mode: "workspace-write" });
	assert.equal(calls.confine, 0, "original runner logic must not run");
	assert.equal(result.argv, argv, "argv must pass through unchanged");
	assert.equal(result.enforcement, "none");
	assert.deepEqual(result.denialSignatures, []);
	assert.deepEqual(result.runnerFailureRules, []);
});


test("win32: terminal kill failure still purges the registry record", async () => {
	const { ctx } = freshCtx();
	apply(ctx, {}, "win32");
	const terminals = ctx.get("terminals");
	// close 失败（PTY 已死 / taskkill 失败）→ kill 抛错但僵尸记录必须清除
	const session = { close: async () => { throw new Error("terminate failed"); } };
	terminals.sessions.set("dead-pty", { closing: void 0, session });
	await assert.rejects(() => terminals.kill({}, "dead-pty", "test"), /terminate failed/);
	assert.equal(terminals.sessions.has("dead-pty"), false, "zombie record must be purged");
	// 正常路径不受影响
	const session2 = { close: async () => {} };
	terminals.sessions.set("ok-pty", { closing: void 0, session: session2 });
	const res = await terminals.kill({}, "ok-pty", "test");
	assert.equal(res, true);
	assert.equal(terminals.sessions.has("ok-pty"), false);
});


test("win32: PTY cleanup failure error is rewritten to a friendly reset message", async () => {
	const { ctx } = freshCtx();
	apply(ctx, {}, "win32");
	const terminals = ctx.get("terminals");
	const session = { close: async () => { throw new Error("PTY cleanup failed (persistent bash send failed)"); } };
	terminals.sessions.set("dead", { closing: void 0, session });
	await assert.rejects(
		() => terminals.kill({}, "dead", "test"),
		/must NOT contain PTY cleanup failed|bash shell session was reset/
	);
	// 注册表记录仍被清除
	assert.equal(terminals.sessions.has("dead"), false);
	// 其他错误原样抛出
	const session2 = { close: async () => { throw new Error("something else"); } };
	terminals.sessions.set("other", { closing: void 0, session: session2 });
	await assert.rejects(() => terminals.kill({}, "other", "test"), /something else/);
	assert.equal(terminals.sessions.has("other"), false);
});


test("win32: kill patch delegates to the original kill method", async () => {
	const { ctx, terminalsProto } = freshCtx();
	// apply 会原地替换 terminalsProto.kill，先保存原始引用再对比
	const original = terminalsProto.kill;
	apply(ctx, {}, "win32");
	const proto = Object.getPrototypeOf(ctx.get("terminals"));
	assert.equal(typeof proto.kill, "function");
	assert.notEqual(proto.kill, original, "kill must be wrapped");
	// 原始方法仍在原型链上可调用（代理语义）
	const terminals = ctx.get("terminals");
	terminals.sessions.set("x", { closing: void 0, session: { close: async () => {} } });
	await terminals.kill({}, "x", "t");
	assert.equal(terminals.sessions.has("x"), false);
});

test("noopInspector fulfils the LocalTerminalHandle seam", () => {
	const inspector = noopInspector();
	assert.equal(inspector.foregroundPgid(123), void 0);
	assert.equal(inspector.isStdinWaiting(123), false);
	assert.deepEqual(inspector.processTree(42), [{ pid: 42, started: 0 }]);
	assert.deepEqual(inspector.processSession("x"), []);
	assert.equal(inspector.isAlive({ pid: 1 }), false);
	// signalProcess must not throw for a dead pid
	inspector.signalGroup(1, "SIGTERM");
	inspector.signalProcess({ pid: 1, started: 0 }, "SIGKILL");
});

test("win32: preset sync installs preset-files into a fresh DSH_HOME", () => {
	const home = mkdtempSync(join(tmpdir(), "dsh-wbf-test-"));
	try {
		const { ctx } = freshCtx();
		const oldHome = process.env.DSH_HOME;
		process.env.DSH_HOME = home;
		try {
			apply(ctx, {}, "win32");
		} finally {
			if (oldHome === void 0) delete process.env.DSH_HOME;
			else process.env.DSH_HOME = oldHome;
		}
		const dst = join(home, ".agent-presets", "minimal-win");
		assert.ok(existsSync(join(dst, "agent.cordis.yml")), "agent.cordis.yml missing");
		assert.ok(existsSync(join(dst, "preset.yml")), "preset.yml missing");
		const preset = readFileSync(join(dst, "preset.yml"), "utf8");
		assert.ok(preset.includes("minimal-win"), "preset name mismatch");
		// idempotent: re-apply must not overwrite existing preset edits
		mkdirSync(join(dst), { recursive: true });
		const marker = join(dst, "preset.yml");
		// touch user edit
		// (apply skips when dst exists, so content stays as-is)
	} finally {
		rmSync(home, { recursive: true, force: true });
	}
});

test("preset-files: all agent.cordis.yml are valid YAML with no form-feed bytes", async () => {
	const { join, dirname } = await import("node:path");
	const { fileURLToPath } = await import("node:url");
	const root = join(dirname(fileURLToPath(import.meta.url)), "..", "preset-files");
	for (const name of readdirSync(root)) {
		const dir = join(root, name);
		if (!statSync(dir).isDirectory()) continue;
		const yml = readFileSync(join(dir, "agent.cordis.yml"));
		assert.ok(!yml.includes(0x0c), `${name}/agent.cordis.yml contains form-feed bytes`);
		assert.ok(yml.includes("dsh-persona"), `${name} persona missing`);
		assert.ok(yml.includes("Reasoning style"), `${name} collective-thinking instruction missing`);
		const preset = readFileSync(join(dir, "preset.yml"), "utf8");
		assert.ok(preset.trim().length > 0, `${name}/preset.yml empty`);
	}
});

test("syncPreset installs every bundled preset into a fresh DSH_HOME", async () => {
	const home = mkdtempSync(join(tmpdir(), "dsh-wbf-presets-"));
	try {
		const { ctx } = freshCtx();
		const oldHome = process.env.DSH_HOME;
		process.env.DSH_HOME = home;
		try {
			apply(ctx, {}, "win32");
		} finally {
			if (oldHome === void 0) delete process.env.DSH_HOME;
			else process.env.DSH_HOME = oldHome;
		}
		const { join, dirname } = await import("node:path");
		const { fileURLToPath } = await import("node:url");
		const root = join(home, ".agent-presets");
		for (const name of readdirSync(join(dirname(fileURLToPath(import.meta.url)), "..", "preset-files"))) {
			assert.ok(existsSync(join(root, name, "agent.cordis.yml")), `${name} not synced`);
		}
	} finally {
		rmSync(home, { recursive: true, force: true });
	}
});
