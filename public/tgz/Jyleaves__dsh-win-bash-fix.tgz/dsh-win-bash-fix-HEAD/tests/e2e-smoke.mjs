#!/usr/bin/env node
/**
 * dsh-win-bash-fix — end-to-end smoke test (requires a running dsh web + model).
 *
 * Usage:
 *   node tests/e2e-smoke.mjs                    # uses http://127.0.0.1:3080
 *   DSH_BASE=http://127.0.0.1:3080 node tests/e2e-smoke.mjs
 *   MODEL=deepseek-v4-pro EFFORT=high node tests/e2e-smoke.mjs
 *
 * Asserts (after the model actually runs bash):
 *   1. at least one SUCCESSFUL bash tool result containing the workspace path
 *   2. zero PTY / terminal-inspection errors
 *   3. reasoning chain: let me < 3 (collective-thinking health check)
 * Exits non-zero on failure.
 */
import { join } from "node:path";

const BASE = process.env.DSH_BASE ?? "http://127.0.0.1:3080";
const MODEL = process.env.MODEL ?? "deepseek-v4-pro";
const EFFORT = process.env.EFFORT ?? "high";
const CWD = process.env.TEST_CWD ?? "D:\\WordPDFPPT\\科研\\EnzGFM";
const PRESET = "minimal-win";
const TASK = "先运行 pwd 和 ls 看看当前目录内容，然后简单总结你看到了什么";
const POLL_MS = 5000;
const MAX_WAIT_MS = 120000;

let rpcSeq = 0;
async function rpc(method, payload) {
	const body = JSON.stringify({ type: "client-request", rpcId: `e2e${rpcSeq++}`, method, payload });
	const res = await fetch(BASE + "/api/" + method, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body,
	});
	if (!res.ok) throw new Error(`${method}: HTTP ${res.status}`);
	return res.json();
}

function assert(cond, msg) {
	if (!cond) throw new Error(`ASSERT FAILED: ${msg}`);
}

async function main() {
	console.log(`[e2e] base=${BASE} model=${MODEL} effort=${EFFORT} preset=${PRESET}`);
	const created = await rpc("session.create", { agentPreset: PRESET, cwd: CWD });
	if (!created.result?.ok) throw new Error(`session.create failed: ${JSON.stringify(created.result?.error)}`);
	const sid = created.result.value.sessionId;
	console.log(`[e2e] session ${sid}`);
	try {
		const sel = await rpc("session.selectModel", {
			sessionId: sid, provider: "deepseek-official", model: MODEL, reasoningEffort: EFFORT,
		});
		if (!sel.result?.ok) throw new Error(`selectModel failed: ${JSON.stringify(sel.result?.error)}`);
		const prompt = await rpc("session.prompt", {
			sessionId: sid, mode: "steer", content: [{ type: "text", text: TASK }],
		});
		assert(prompt.result?.value?.accepted === true, "prompt not accepted");

		// Poll until the session finishes or timeout.
		const deadline = Date.now() + MAX_WAIT_MS;
		let running = true;
		while (running && Date.now() < deadline) {
			await new Promise((r) => setTimeout(r, POLL_MS));
			const list = await rpc("session.list", {});
			const item = list.result.value.items.find((x) => x.sessionId === sid);
			running = item?.running ?? false;
		}
		assert(!running, `session still running after ${MAX_WAIT_MS / 1000}s`);

		const hist = await rpc("session.history", { sessionId: sid });
		const events = hist.result.value.events;
		let bashOk = 0;
		let ptyErrors = 0;
		let reasoning = "";
		for (const e of events) {
			const d = e.event?.data;
			if (e.event?.type === "tool/result") {
				const c = JSON.stringify(d?.message?.content ?? "");
				const isErr = c.includes('"isError": true') || c.includes('"isError":true');
				if (isErr) {
					if (c.includes("PTY") || c.includes("terminal inspection")) ptyErrors++;
				} else if (c.includes("/d/") || c.includes("EnzGFM") || c.includes("WordPDFPPT")) {
					bashOk++;
				}
			}
			if (e.event?.type === "reasoning-chunks") {
				reasoning += (d?.texts ?? []).join("");
			}
			if (d?.chunk?.type === "reasoning-delta") reasoning += d.chunk.text ?? "";
		}
		const letMe = (reasoning.match(/let me/gi) ?? []).length;

		console.log(`[e2e] bash ok=${bashOk} pty/terminal errors=${ptyErrors} let_me=${letMe} reasoning_len=${reasoning.length}`);
		assert(bashOk >= 1, "no successful bash result with workspace output");
		assert(ptyErrors === 0, `${ptyErrors} PTY/terminal-inspection errors`);
		assert(letMe < 3, `reasoning has ${letMe} "let me" (>= 3)`);
		console.log("[e2e] PASS");
	} finally {
		try { await rpc("session.cancel", { sessionId: sid }); } catch { /* ignore */ }
	}
}

main().then(() => process.exit(0)).catch((err) => {
	console.error(`[e2e] FAIL: ${err.message}`);
	process.exit(1);
});
