# Changelog

## [1.0.6] - 2026-08-15

### Changed
- **PTY cleanup 错误消息友好化**：v1.0.5 已清理僵尸 registry 记录，但模型仍会看到
  误导性的 `PTY cleanup failed (persistent bash send failed)`（模型会误判
  "bash died permanently"，实测 PE998 评测推理原话）。v1.0.6 在 win32 kill 补丁中
  将该错误改写为明确提示：`bash shell session was reset (PTY cleanup); retry the
  command — a fresh shell starts automatically on the next call`
  - 其他错误原样抛出；错误堆栈保留（替换 message 部分）
- 单元测试 +1 用例（错误改写 + 其他错误不受影响 + 记录仍清除）= 共 13 用例

## [1.0.5] - 2026-08-15

### Added
- **第 4 个补丁：TerminalRegistry.kill 容错**（win32）——PTY close 失败（bash 已死 /
  taskkill 杀不掉 MSYS 进程树 / 超时打断）时仍从 registry 删除记录：
  - 消除僵尸 terminal 记录（否则后续操作持续碰死 PTY）
  - 消除链式误报 `PTY cleanup failed (persistent bash send failed)`——模型看到的是
    原始超时/终止原因，不会再误判 "bash died permanently"
  - 实测背景：PE998 评测中长命令（>300s 超时）触发 send failed → reset → close 失败
    → 错误激增；补丁让 reset 干净完成，下次调用自动新建 shell
- 单元测试 +2 用例（kill 失败仍清记录 / patch 委托语义）= 共 12 用例

### Changed
- README：测试矩阵 aw 行注明 PTY 超时场景、Known Limitations 更新

## [1.0.4] - 2026-08-15

### Added
- **anchored-win 预设**（全功能 Standard + 集体思维）：首轮 bash+edit 锚定（借鉴
  xiaobright/dsh-anchored-standard），首个工具调用后恢复全量 Standard 目录；
  Windows 下 pwsh 禁用、bash 唯一 shell。preset.yml 显示名统一为 `anchored-win`
- preset-files 重构为子目录结构（minimal-win/ + anchored-win/），插件/install.mjs
  自动同步两套预设（含 tool-bootstrap.mjs）
- 单元测试新增 2 用例：preset-files YAML 合法性（form-feed 检测 + persona 指令
  存在性）、双预设同步（共 10 用例）

### Changed
- README：双预设说明、借鉴声明、使用建议（high vs max、开放 vs 具体任务）、
  测试矩阵更新（v1.0.3 强化后）

## [1.0.3] - 2026-08-15

### Changed
- minimal-win / anchored-win persona 强化：few-shot 正反例（"Let me check" → "Let's check"）
  + 团队框架指令（explore/understand/investigate = team effort）
  - 效果：max + 开放探索任务从"必然 let me"提升为约 2/3 全绿 we/let's
  - 剩余 let me 均为行动句（非挣扎/降智），high 下 100% 全绿

## [1.0.2] - 2026-08-15

### Changed
- minimal-win 预设：bash 工具描述与 persona 增加 Windows 路径规则
  （MSYS 路径 /d/foo = D:oo；str_replace_editor 必须用 Windows 绝对路径
  且先 view 再 edit）——减少模型在混合路径环境下的工具错误

## [1.0.1] - 2026-08-15

### Added
- 单元测试套件（node:test，8 用例：MSYS env 注入幂等性、PATH 前置、no-op inspector、沙箱 bypass、预设同步、非 win32 no-op）
- E2E 冒烟测试（真实 dsh 会话：bash 成功执行、0 PTY 错误、let_me < 3）
- GitHub Actions CI（ubuntu + windows 单元测试）
- README 补齐官方规范章节（Compatibility/Uninstall/Configuration/Permissions/Troubleshooting/Development）
- 官方安装命令支持验证：`dsh plugin --profile web add github:Jyleaves/dsh-win-bash-fix`
- `apply(ctx, config, platform)` 支持 platform 注入（便于 CI 测试）

## [1.0.0] - 2026-08-15
## [1.0.0] - 2026-08-15

### Added
- `@jyleaves/dsh-win-bash-fix` 标准插件包结构（`package.json` + `dsh.bundle.patch` + `lib/index.js`），支持两种安装方式：
  - **bundle 安装**：加入 profile `package.json` 依赖 + `dsh.profile.bundles`，`pnpm install` 即用
  - **一键复制安装**：`node install.mjs`（幂等，无需 npm）
- `minimal-win` 预设（`preset-files/`）：双工具编码 Agent + 英文集体思维 persona，插件首次加载自动同步到 `~/.dsh/.agent-presets/`
- 完整 README：根因分析、测试矩阵、Known Limitations

### Fixed
- **Windows 上 bash 工具 100% 启动失败**（`PTY shell exited during startup`）：
  - `dsh-subprocess-local` win32 进程检查器缺失 → 插件挂载 no-op inspector
  - MSYS 环境变量缺失 → 插件进程级注入（`MSYSTEM`/`CHERE_INVOKING`/`MSYS2_PATH_TYPE`/Git PATH）
  - **核心**：`dsh-sandbox-windows-acl` 的 restricted-token runner 与 MSYS2 冲突（`CreateFileMapping` 被拒）→ 插件在 win32 让沙箱 confine 直接放行
- 思维链 `let me` 泛滥问题（工具恢复后自然消失，实测 `let me` 归零）

### Notes
- 补丁为运行时 prototype patch，dsh 升级后插件自动重新生效，无需重装
- Windows 上 shell 工具不再走文件沙箱（fs 工具沙箱独立不受影响）
