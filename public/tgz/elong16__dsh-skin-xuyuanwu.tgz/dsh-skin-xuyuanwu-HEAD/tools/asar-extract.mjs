/**
 * asar-extract.mjs — 解析 Electron app.asar 归档头，按关键词定位/抽取文件。
 * 用法：
 *   node tools/asar-extract.mjs list <关键词>       列出路径含关键词的文件（限 200 条）
 *   node tools/asar-extract.mjs grep <关键词> <文本> 在路径含关键词的文件里 grep 文本（输出命中行，限 40 条）
 *   node tools/asar-extract.mjs extract <路径> <输出文件> 抽出单个文件
 */
import { readFileSync, writeFileSync } from 'node:fs'
import { openSync, readSync, fstatSync, readSync as _r } from 'node:fs'

const ASAR = 'D:/KFTools/DSH Desktop/resources/app.asar'
const fd = openSync(ASAR, 'r')
const head = Buffer.alloc(16)
readSync(fd, head, 0, 16, 0)
/* asar 头：[0]=pickle1 载荷长(4) [4]=header pickle 总长 [8]=其载荷长 [12]=json 串长 [16..]=json */
const headerSize = head.readUInt32LE(4)
const jsonLen = head.readUInt32LE(12)
const jsonBuf = Buffer.alloc(jsonLen)
readSync(fd, jsonBuf, 0, jsonLen, 16)
const header = JSON.parse(jsonBuf.toString('utf8'))
const dataBase = 8 + headerSize

/** 递归遍历 asar 头，产出 { path, size, offset } */
function* walk(node, prefix) {
	for (const [name, entry] of Object.entries(node.files ?? {})) {
		const p = prefix ? `${prefix}/${name}` : name
		if (entry.files) yield* walk(entry, p)
		else yield { path: p, size: entry.size, offset: entry.offset, unpacked: entry.unpacked }
	}
}

const [,, cmd, ...rest] = process.argv
if (cmd === 'list') {
	const kw = rest[0] ?? ''
	let n = 0
	for (const f of walk(header, '')) {
		if (!kw || f.path.toLowerCase().includes(kw.toLowerCase())) {
			console.log(`${f.size}\t${f.path}${f.unpacked ? ' (unpacked)' : ''}`)
			if (++n >= 200) { console.log('... (capped at 200)'); break }
		}
	}
	console.error(`total files scanned: ${[...walk(header, '')].length}`)
} else if (cmd === 'grep') {
	const [kw, text] = rest
	let hits = 0
	for (const f of walk(header, '')) {
		if (!f.path.toLowerCase().includes(kw.toLowerCase())) continue
		if (f.size > 30 * 1024 * 1024) continue
		const buf = Buffer.alloc(f.size)
		readSync(fd, buf, 0, f.size, dataBase + Number(f.offset))
		const content = buf.toString('utf8')
		let idx = 0
		while (hits < 40) {
			const at = content.indexOf(text, idx)
			if (at === -1) break
			console.log(`--- ${f.path} @${at}`)
			console.log(content.slice(Math.max(0, at - 200), at + 300).replaceAll('\n', '\\n'))
			idx = at + text.length
			hits++
		}
		if (hits >= 40) break
	}
	console.error(`hits: ${hits}`)
} else if (cmd === 'extract') {
	const [p, out] = rest
	for (const f of walk(header, '')) {
		if (f.path === p) {
			const buf = Buffer.alloc(f.size)
			readSync(fd, buf, 0, f.size, dataBase + Number(f.offset))
			writeFileSync(out, buf)
			console.log(`✓ extracted ${f.path} (${f.size} bytes) → ${out}`)
			process.exit(0)
		}
	}
	console.error(`not found: ${p}`)
	process.exit(1)
} else {
	console.error('用法: node asar-extract.mjs list|grep|extract ...')
}
