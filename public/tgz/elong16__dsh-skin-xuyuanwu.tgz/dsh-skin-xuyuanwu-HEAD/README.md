# dsh-skin-xuyuanwu 🏮

许愿屋主题皮肤插件 for [DeepSeek Harness](https://registry.npmjs.org/@deepseek-ai/dsh)（DSH）。

> 深夜里，一间永远亮着暖灯的小屋。你对屋里的 AI 许愿，灯就会亮起、
> 星就会回应 —— **有求必应**。

自绘原创 SVG（月洞窗夜景：新月、星群、暖橘小屋、琥珀窗灯、檐下灯笼、
「有求必应」木牌），通过官方皮肤扩展点覆盖 Web 客户端外观，
**卸载即 100% 还原官方外观，零残留**。

本地对照检查造型：`node scripts/preview.mjs` 生成 `assets/preview.html`
（含暖纸/靛夜两套主题底色模拟与色板）。

## 效果

| 视觉面 | 变化 |
|---|---|
| 侧栏 logo | 官方鲸鱼 → 许愿屋小屋（暖橘屋顶 + 亮着的琥珀窗 + 许愿星） |
| 侧栏品牌名 | DeepSeek Harness 字标 → 「许愿屋 ✦ 有求必应」 |
| 首屏徽章 | 动画鲸鱼 → 月洞窗夜景徽章（漂浮 + 星光闪烁 + 窗灯呼吸 + 灯笼摇曳） |
| 首屏大标题 | 「探索未至之境」→「请许下你的愿望」（**楷体**许愿签手写感 + 琥珀渐变文字 + 柔光辉晕 + 入场「**逐字点亮**」wipe（clip-path 从左向右揭开，像一笔一笔写下愿望）+ **流光扫过**：4.6s 周期、近白金亮带从左掠到右并伴随辉光脉冲，可配置、可关闭） |
| 全局主色 | 蓝 → 灯火琥珀（按钮/链接/焦点/选中态，亮暗自适应） |
| 背景 | 亮色「暖纸」奶油纸色 / 暗色「靛夜」缀星靛蓝（全套语义令牌） |
| 滚动条 / 气泡 / 侧栏 | 暖金 / 杏仁气泡 / 暖纸·靛夜侧栏填充 |
| 全局背景 | 纯色 → 许愿星空氛围贴片 + 顶部灯晕纵深（480px 平铺：亮=暖墨星辰、暗=暖金星辰，低透明度，弹层保持干净） |
| 背景月 | 右上一轮**按今日真实农历月相**绘制的月（朔望月公式：新月细成一线、满月滚圆、上弦右亮、下弦左亮；**亮度随圆缺**；刷新即更新）；**月相呼吸**：今日月每约 96s 缓缓盈到满月、再缓缓亏回今日月相（余弦节奏两端自然驻留，盈的方向顺着今日盈亏侧——月亮是活的）；**月亮轨迹**：月相画布沿上空规律摆动（水平 ±100px + 轻上下 18px，约 180s 一轮，正弦两端驻留；点月亮彩蛋的命中/光环/柔光跟着月亮走） |
| 背景动效 | 星空缓漂（480px/480s 无缝循环）+ 双流星错峰划过（13s/19s 周期，一右下一左下、朝向严格对齐；**3px 光带 + 10px 辉光**，第二颗换色：亮=琥珀橙、暗=星银）+ **随机天降流星**（JS 生成，起点/朝向/长度/时长/配色全随机，12-30s 一颗） |
| 闪烁星群 | 近景随机撒星（远景组小而密 + 近景组大而亮，各自随机周期闪烁）+ **鼠标视差**（远近两组反向微移、近组位移约两倍，星空有纵深） |
| 鼠标拖尾 | 移动落许愿星（≥28px 一颗、飘散消逝、双色随机、池上限 24，reduced-motion 自动关闭） |
| 回车许愿流星 | 输入框里敲下回车（许愿！）即有一颗流星划过——「有求必应」的具象化（170×3px 光带 + 辉光 + **每颗随机配色**：亮=暖墨金/琥珀橙/暖银棕、暗=暖金/星银/暖橙/冰蓝星辉；输入法组词/Shift+Enter 不误触；1.8s 冷却 + 同时最多 2 颗） |
| UI 细节与信笺墨金 | **选区高亮**（选中文字铺暖金）+ **表单点缀色**（checkbox/radio/range/progress 灯火琥珀）+ **滚动条**（细圆暖金条、悬停增亮）+ **输入聚焦星环**（textarea/文本输入聚焦泛暖光）+ **按钮手感**（悬浮微抬 1px + 暖影、按压回落）+ **信笺墨金质感**（代码块暖金微光边框、引用块琥珀手札竖线、思考折叠区温润微光；全部走通用选择器） |
| 挑灯织光态 | AI 思考与流式生成时，小屋窗灯进入快频明亮呼吸与灯笼微摆共鸣；生成完毕轻弹散开一颗小星芒达成愿望（MutationObserver 智能感知） |
| 字落生辉 | 输入框敲击打字时冒出微小金色萤火微尘，向上飘散 450ms 淡出（90ms 节流 + 12 颗上限，组词与 reduced-motion 不误触） |
| 纯原生空灵音效 | Web Audio API 纯程序合成零外部资源：点月亮轻扬水晶风铃音（E6/G6/B6/E7 空灵五度）、回车流星微风掠鸣，开箱即听 |
| 现实时辰昼夜联动 | 深夜（23-05 点）窗灯辉光自动增强 15%、灯笼光晕更温存；傍晚薄暮（17-19 点）夜空叠染薄霞光晕 |
| 小屋彩蛋每日许愿签 | 点击「有求必应」木牌或双击首屏徽章，弹出手作宣纸签语 Toast（内置 16 条治愈古风诗句，3.8s 自动淡出或点击收起） |
| 掌中微光快捷手札 | 侧栏字标星标或三击月亮即可唤出设置抽屉面板，8 项核心视觉与动效开关随心勾选，实时同步持久化至 localStorage |
| 智能低电量节能 | Battery API 感知未插电且电量 ≤25% 时自动降频，精简动画负荷，随手环保节电 |
| 点击星芒 / 按钮碰星 | 任何点击在指针处**炸开一颗四角星**（放大旋转消散）；**划过按钮**（含 role=button）在指针旁碰出小星（同一按钮 600ms 内不重复）；事件委托定位，池上限 + 节流防刷屏 |
| 启动开幕动画 | 约 1.3s「揭幕仪式」：暖纸/靛夜幕布上**小屋徽记回弹浮现** →「许愿屋」楷体字标上浮 +「有求必应 · 请许下你的愿望」副标 → 三颗星错峰闪现 + **一道流星划过** → 幕布淡出，**首屏徽章浮现、标题逐字点亮**接棒登场（每页面会话一次，HMR 不重演；pointer-events none 零交互，reduced-motion 跳过） |
| 点月亮许愿 | 右上今日月**可点击**（悬停浮现光环；**零占位命中测试**：页面上不叠任何可交互元素，绝不遮挡/吞掉任何按钮，点到真实控件一律让路）：点一下**月心爆柔光 + 落一场流星雨**（5 颗错峰、随机配色；2.5s 冷却）——「有求必应」的隐藏彩蛋 |
| 可触摸的徽记 | 悬停侧栏小屋 logo / 首屏月洞窗徽章：**辉光增强、许愿窗点亮**（琥珀窗变亮金）、**灯笼与许愿星更亮**——徽记是活的，摸得到回应 |

主题令牌层覆盖品牌主色、背景层级、文字标签、描边、交互态、按钮、
Markdown、滚动条与具体组件面（气泡/输入/菜单/侧栏），全部带
`{ light, dark }` 双值随官方亮暗模式自动切换；语义状态色（成功/错误/警告）
沿用官方，保证语义不被皮肤吞掉。

## 安装（本地目录）

```sh
dsh plugin --profile desktop add D:\workProject\dsh-skin-xuyuanwu
# 或装进 web profile：
dsh plugin --profile web add D:\workProject\dsh-skin-xuyuanwu
```

安装后**重启 DSH Desktop**（新增 bundle 需要重载 profile；之后改
`cordis.patch.yml` 或热重载不需要重启）。

## 卸载 / 开关

- 完整卸载：`dsh plugin --profile desktop remove dsh-skin-xuyuanwu`
- 临时关闭某层：改 `cordis.patch.yml` 里对应开关（`brand` / `theme` /
  `heroAnimation` / `background` / `bgAnimation` / `bgMoon` / `starTrail` /
  `starField` / `wishMeteor` / `uiPolish` / `clickStar` / `bootAnimation` /
  `moonWish` / `heroStyle` / `heroHeadline` 置空），保存即热生效
- 整体禁用：Desktop 的插件管理页禁用本插件，或 profile 的
  `cordis.patch.yml` 里写 `- id: skin-xuyuanwu` + `disabled: true`

## 多皮肤叠加

`ctx.theme.overrideTokens` 的多个来源会**叠加**（后者胜出）。与其他
换肤插件（如 dsh-qq-skin、dsh-theme-cyberpunk2077、dsh-skin-ggbond）
同时启用时会互相覆盖成混合泥。切换皮肤时请在 profile 的
`cordis.patch.yml` 里用 `disabled: true` 关掉其他皮肤，一次只留一个。

## 工作原理

双半结构（DSH 插件标准形态）：

```
package.json      dsh.bundle.patch + dsh.client(platform: web) 双声明
cordis.patch.yml  配置树挂载行（含十七个开关 + 标题文案）
lib/index.js      node 半部：空 Loader 座位（无宿主侧行为）
lib/client.js     浏览器半部：ModuleLoader bundle（真正干活）
```

浏览器半部二十一层实现（按 apply 顺序）：

1. **主题令牌层** — `ctx.theme.overrideTokens(source, tokens)`：约 90 个
   语义令牌的 `{ light, dark }` 双值覆盖（品牌/背景/文字/描边/交互/按钮/
   Markdown/滚动条/具体组件面 + deepseek→琥珀阶、blue→靛夜阶两组静态
   色阶），自动跟随亮暗模式，返回 remove 函数。
2. **布局 CSS 层** — `<style data-plugin-css="dsh-skin-xuyuanwu/layout">`
   按开关拼装注入：首屏徽章动画（漂浮/星光/呼吸/摇曳）、背景与月相与
   流星动效、标题场景化、拖尾星样式、闪烁星群样式、许愿流星样式、
   UI 细节打磨、点击星芒样式、开幕动画、点月亮样式，全部尊重
   `prefers-reduced-motion`。首屏徽章/侧栏 logo 悬停点灯（窗灯/灯笼/
   许愿星更亮 + 辉光增强）。
3. **启动开幕动画层**（`bootAnimation`）— 约 1.3s「揭幕仪式」：暖纸/
   靛夜幕布上小屋徽记回弹浮现（0.06s）→「许愿屋」楷体字标上浮
   （0.34s）+ 副标「有求必应 · 请许下你的愿望」（0.5s）→ 三颗星错峰
   闪现（0.28-0.52s）+ 一道流星划过（0.58s）→ 幕布淡出（0.98s）。
   幕布在场期间 body 挂 `xyw-booting` 协调类：首屏徽章推迟到揭幕时
   浮现（只动 opacity 避开漂浮动画的 transform）、标题 wipe 推迟到
   1.12s；2.35s 摘类（入场已完成，float 按动画名保留不重启、shimmer
   时延不动，无相位跳变）。每页面会话只演一次（HMR 重放不重演）；
   pointer-events: none 零交互、淡出 forwards 收在 opacity 0（即使
   移除失败也不可见）+ animationend 自移除 + 2.6s 超时兜底；
   reduced-motion 整层跳过。
4. **全局背景层** — 固定全窗的许愿星空贴片（自绘 SVG data URI，
   480px 无缝平铺）+ 顶部灯晕 radial-gradient（暖光纵深）+ 今日月相月
   （`bgMoon`；`moonCycle` 开时静态月让位给月相呼吸层）：亮色「暖纸 ·
   暖墨星辰」、暗色「靛夜 · 暖金星辰」，经官方
   主题引导写入的 `body[data-ds-dark-theme]` 属性自动切换。月相由朔望月
   公式（2000-01-06 新月纪元 + 29.53 天周期）算出，双弧构造绘制亮面
   （盈月亮右、亏月亮左），新月缩成一线仍有极淡轮廓；**亮度随今日照亮
   比例缩放**（月随圆缺明暗）。背景动效（`bgAnimation`）：贴片层以
   480px/480s 缓漂（无缝循环，灯晕/月相层坐标钉死）+ 两条流星错峰划过
   （划动向量与流星朝向严格对齐）。元素挂在 `body` 尾部、
   `pointer-events: none` 零交互，`z-index: 0` 让模态/下拉/浮层（均带
   更高 z-index）保持干净；卸载即移除元素。
5. **月相呼吸层**（`moonCycle`，需 `background` + `bgMoon`）— 今日月
   是活的：相位以余弦节奏在「今日真实月相 ↔ 满月」之间往返
   （w = (1-cos(2πt/T))/2，两端导数为零——在今日月相与满月处自然
   驻留；盈的方向顺着今日的盈亏侧，盈月从右侧长满、亏月从左侧长满，
   回到满月都是「变满」），约 96s 一轮（48s 盈 + 48s 亏）。实现为
   今日月专属画布（`moonCycle` 开时背景层不再叠静态月，由本层 120ms
   一拍重绘 data URI；位置与原 background-position 86% 9% / 220px
   数学上严格一致，点月亮彩蛋坐标照旧对齐）；照亮比例随相位实时变化
   （月随圆缺明暗），亮暗配色每拍读取 body 属性（切主题 ≤120ms 内
   换月色）；页面隐藏时跳过重绘、URL 未变不写样式（reduced-motion
   驻留今日月相时零抖动）。`moonOrbit` 开时叠加**月亮轨迹**：正弦摆动（水平 ±100px + 轻上下 18px，180s 一轮，两端驻留），每拍把偏移写进共享 `XYW_MOON_POS`——点月亮彩蛋的命中圆/光环/柔光读它跟随，月亮走到哪、彩蛋跟到哪；reduced-motion 位置也驻留原位。
6. **近景闪烁星群层**（`starField`）— 随机撒 13-17 颗小星（四角星/圆点
   两种，远景组 8-10 颗小而密、近景组 5-7 颗大而亮），各自以随机周期/
   相位闪烁（透明度 + 微缩放；动画名 `xyw-field-twinkle` 避开首屏徽章
   的 `xyw-twinkle`）；两组随鼠标**反向微移视差**（近组位移约为远组
   两倍，CSS transition 平滑跟随）营造纵深。reduced-motion 整层隐藏。
7. **鼠标许愿星拖尾层** — `mousemove` 被动监听按移动距离节流
   （≥28px 落一颗小四角许愿星，随机 7-13px），CSS 动画上浮旋转飘散
   0.72s 消逝、animationend 自移除；双色随机（30% 深琥珀/淡金 alt）；
   池上限 24 颗防滥用；`prefers-reduced-motion` 时整层退化关闭。
8. **回车许愿流星层** — 输入场景（INPUT/TEXTAREA/contenteditable）的
   裸回车 = 许愿，落一颗随机起点/朝向（26°-38°）/配色的流星
   （170×3px 光带 + 10px 辉光），沿自身朝向划过 1.1s 消逝（transform
   里 rotate 前置、translate 在旋转坐标系内发生，天然对齐）；配色从
   流星配色库随机取（亮=暖墨金/琥珀橙/暖银棕，暗=暖金/星银/暖橙/冰蓝
   星辉；生成时读取当前亮暗模式，切主题后下一颗即对色）。输入法组词
   回车（isComposing/keyCode 229）、Shift+Enter 不误触；1.8s 冷却 +
   同时最多 2 颗防刷屏；animationend 自移除 + 2s 超时兜底防泄漏。
9. **天降流星层**（需 `background` + `bgAnimation`）— 在两条 CSS 定档
   流星之外，JS 以 12-30s 随机节奏再造一颗：起点、朝向（24°-38° 向
   右下坠）、长度（120-220px）、时长（0.9-1.6s）、配色全随机，沿自身
   朝向坠落；页面隐藏时跳过生成但保持节奏；卸载停节奏并清场。
10. **点月亮许愿层**（`moonWish`，需 `background` + `bgMoon`）— **零占位
   命中测试**：不在页面上叠任何可交互元素（v1.8 曾用固定命中区 div，
   实测会压住设置面板按钮，v1.8.1 起彻底移除），改由 document 级捕获
   监听按几何计算：命中圆与绘制月（background-position 86% 9% / 220px、
   圆心 (110,110) r=100）严格对齐、随窗口尺寸实时计算，`moonOrbit` 开时再叠加共享偏移（月亮轨迹走到哪、命中圆跟到哪）。悬停月轮空白处
   → 光环淡入（纯装饰 `pointer-events: none`）+ 手型光标；点击月轮
   空白处 → 月心爆一圈柔光 + 5 颗流星错峰坠落（流星雨样式自包含，
   不依赖 `bgAnimation` 开关；配色读当前亮暗模式）。**点到任何真实
   控件（按钮/输入/菜单/对话框等）一律让路、绝不触发**；2.5s 冷却 +
   池上限 10 颗；animationend 自移除 + 3s 超时兜底；reduced-motion
   连监听都不挂。
11. **点击星芒层**（`clickStar`）— pointerdown（任何点击）在指针处炸开
   一颗四角许愿星（放大旋转消散）；划过按钮（`button`/`[role=button]`，
   事件委托 `closest` 定位，不依赖官方哈希类名）在指针旁碰出小星，
   同一按钮 600ms 内重进不重复；池上限 8 颗 + 120ms 节流防拖拽刷屏；
   reduced-motion 整层退化关闭。
12. **UI 细节与信笺质感层**（`uiPolish`，纯 CSS 无副作用）— 作用于官方控件的
   通用标签/伪类选择器：`::selection` 选区暖金高亮；checkbox/radio/
   range/progress 的 `accent-color` 灯火琥珀；`::-webkit-scrollbar`
   细圆暖金滚动条（透明轨道、悬停增亮）；textarea/文本输入 `:focus`
   聚焦星环（许愿时刻泛暖光）；`button:not(:disabled)` 悬浮微抬 1px +
   暖影、按压回落；**信笺墨金质感**：代码块（`pre, code`）暖金微光边框、
   引用手札（`blockquote`）琥珀渐变竖线与暖纸底色、思考折叠区（`details[open]`）
   温润微光（reduced-motion 关按钮位移）。
13. **品牌槽位层** — 占据 `sidebar.brand.mark`、`sidebar.brand.name`、
    `conversation.hero.brand.mark` 三个 UI 槽位。单槽位"最低优先级者渲染"：
    以 `-100` 优先级盖过官方品牌（默认 0）；本插件卸载后官方品牌自动回位。
    注册采用声明感知模式（`ctx.slots.inject`）：槽位声明出现即注册、消失
    一并撤回，HMR 不留残迹；同优先级冲突（如另一个皮肤同占 -100）时优雅
    降级为警告，不炸插件。
14. **首屏标题改写层** — 官方没有标题槽位（`hero.headline` 是 locale
    词条，同命名空间同语言不可重复注册），皮肤用 MutationObserver DOM
    补丁接管：以「CSS module 类名后缀 `_headlineText` + 官方中英文案」
    双保险定位标题 span，替换为 `heroHeadline` 配置文案并挂
    `xyw-headline` 场景化 class（`heroStyle` 开时：楷体字体栈 +
    琥珀渐变文字 background-clip + 柔光辉晕 + 入场「逐字点亮」wipe
    （clip-path 从左向右揭开 + 字距收拢）+ 流光扫过
    ——200% 宽渐变 + background-position 往返，4.6s 周期、扫过占近半
    周期，近白金亮带从左掠到右并在经过时叠加辉光脉冲（filter 走
    弱/强两级 CSS 变量），两端停在渐变同色区、循环无跳变）；
    React 重渲染恢复官方文案后即时改回（rAF 合并去抖）。
    卸载/关闭时摘 class 并还原官方原文，零残留。留空字符串即完全关闭、
    保持官方文案。
15. **挑灯织光层**（`weavingLight`）— MutationObserver 监听文档流式生成与思考节点（`data-is-streaming`、停止生成按钮等），AI 思考与输出时挂载 `xyw-ai-weaving` 激活窗灯快频明亮呼吸与灯笼微摆；输出完毕轻弹一颗金色达成小星芒（`xyw-star-fulfilled`）达成愿望。
16. **字落生辉层**（`typingSparks`）— 监听文本框 `input` 输入事件，在光标位置附近随机冒出 `xyw-typing-spark` 金色萤火微尘并带横向随机偏移，向上飘散淡出；90ms 节流 + 12 颗池上限，组词与 reduced-motion 不误触。
17. **纯原生合成音效层**（`sound`）— 基于 Web Audio API 纯算法合成空灵音效，0KB 外部资源依赖：4 组五声音阶正弦波振荡器（E6/G6/B6/E7）合成空灵水晶风铃音，三角波带微升微降频移合成微风掠鸣，开箱即听，随用户交互按需懒加载并优雅捕获异常。
18. **现实时辰昼夜联动层**（`timeAmbience`）— 60s 轮询真实时辰：深夜（23-05 点）挂载 `xyw-deep-night` 类增强窗灯与灯笼辉光 15%；傍晚薄暮（17-19 点）挂载 `xyw-dusk` 类为夜空背景增加暖霞色温滤镜。
19. **每日许愿签彩蛋层**（`wishFortune`）— 捕获点击侧栏字标/首屏「有求必应」木牌或双击首屏徽章，弹出手作宣纸签语 Toast，内置 16 条治愈古风签语并伴随风铃音，支持 1.2s 防刷节流与点击离场。
20. **掌中微光快捷手札面板层**（`quickPanel`）— 侧栏字标星标或 `xyw-open-panel` 自定义事件唤出手札模态卡片，内置 8 项核心功能实时开关与重置，配置自动同步保存至 `localStorage`。
21. **智能低电量节能感知层**（`ecoMode`）— `navigator.getBattery` 感知设备电源状态，未连接电源且电量 ≤25% 时激活 `xyw-eco-mode` 降频月相至 360ms 并关闭滤镜动画，插电后自动恢复。

所有副作用走 `ctx.effect`，插件卸载/热重载时逆序清理。

## 配置（cordis.patch.yml）

| 字段 | 默认 | 说明 |
|---|---|---|
| `brand` | `true` | 品牌槽位（logo/字标/首屏徽章） |
| `theme` | `true` | 灯火琥珀主题令牌（主色/背景/文字/滚动条全套） |
| `heroAnimation` | `true` | 首屏动画（漂浮/星光/窗灯/灯笼） |
| `background` | `true` | 全局背景氛围层（星空贴片 + 灯晕，亮暗两版） |
| `bgAnimation` | `true` | 背景动效：星空缓漂 + 流星（需 `background` 开） |
| `bgMoon` | `true` | 今日月相月（朔望月公式，亮度随圆缺，随刷新更新；需 `background` 开） |
| `moonCycle` | `true` | 月相呼吸（今日月每约 96s 缓缓盈到满月再亏回；需 `background` + `bgMoon` 开） |
| `moonOrbit` | `true` | 月亮轨迹（月相画布沿上空规律摆动，约 180s 一轮；需 `bgMoon` + `moonCycle` 开） |
| `starTrail` | `true` | 鼠标许愿星拖尾（移动落星、飘散消逝、双色随机、池上限） |
| `starField` | `true` | 近景闪烁星群 + 鼠标视差（随机撒星、远近两组纵深微移） |
| `wishMeteor` | `true` | 回车许愿流星（输入框裸回车触发；组词/Shift 不误触；冷却 + 池上限） |
| `uiPolish` | `true` | UI 细节与信笺质感（选区高亮/表单点缀色/滚动条/输入聚焦星环/按钮手感/代码块边框/引用手札/思考折叠微光） |
| `weavingLight` | `true` | 挑灯织光（AI 思考与流式生成时窗灯快频明亮呼吸，结束弹散达成星芒） |
| `typingSparks` | `true` | 字落生辉（输入框打字金色萤火微尘，向上飘散） |
| `sound` | `true` | 纯原生空灵合成音效（Web Audio 算法水晶风铃与微风掠鸣，零外部依赖） |
| `timeAmbience` | `true` | 现实时辰昼夜联动（深夜 23-05 点增强辉光，薄暮 17-19 点暖霞光晕） |
| `wishFortune` | `true` | 小屋彩蛋每日许愿签（点击木牌或双击徽章弹出手作宣纸诗词 Toast） |
| `quickPanel` | `true` | 掌中微光快捷手札面板（侧栏字标星标唤出设置抽屉，实时保存） |
| `ecoMode` | `true` | 智能低电量节能感知（未充电且电量 ≤25% 时环保降频） |
| `clickStar` | `true` | 点击星芒 + 按钮碰星（点击炸四角星；划过按钮碰小星） |
| `bootAnimation` | `true` | 启动开幕动画（幕布徽记 → 字标 + 三星连闪 + 流星 → 淡出揭幕；每会话一次） |
| `moonWish` | `true` | 点月亮许愿（悬停现光环；点一下月心爆柔光 + 一场流星雨；零占位命中测试，绝不遮挡按钮；需 `background` + `bgMoon` 开） |
| `heroStyle` | `true` | 首屏标题场景化（楷体 + 渐变文字 + 辉晕 + 入场「逐字点亮」wipe + 流光扫过） |
| `heroHeadline` | `"请许下你的愿望"` | 首屏大标题文案；空字符串 = 保持官方「探索未至之境」 |

## 迭代开发

本机以 `dsh plugin --profile desktop add <本地目录>` 安装时 pnpm 建立的是
**链接**（`link:D:/workProject/dsh-skin-xuyuanwu`）：改 `lib/client.js`
后**无需重装**，浏览器刷新（F5）即生效。若你的安装是快照形态（依赖列表
显示具体版本号而非 `link:`），改码后需重新安装：

```sh
dsh plugin --profile desktop update dsh-skin-xuyuanwu
```

改 `cordis.patch.yml` 保存即热生效，无需重装。
无浏览器的结构校验：`node test/smoke.mjs`（31 组断言）。

## License

MIT
