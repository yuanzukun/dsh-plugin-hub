/** debug-moon.mjs — 打印今日月相（与 lib/client.js 同一公式），用于核对背景月方向。 */
const SYNODIC = 29.53058867
const EPOCH = Date.UTC(2000, 0, 6, 18, 14)
const days = (Date.now() - EPOCH) / 86400000
const phase = (((days % SYNODIC) + SYNODIC) % SYNODIC) / SYNODIC
const k = Math.cos(2 * Math.PI * phase)
const illum = (1 - k) / 2
const name = phase < 0.03 || phase > 0.97 ? '新月'
	: phase < 0.22 ? '娥眉月（盈，亮右）'
	: phase < 0.28 ? '上弦月（右半亮）'
	: phase < 0.47 ? '盈凸月（亮右偏多）'
	: phase < 0.53 ? '满月'
	: phase < 0.72 ? '亏凸月（亮左偏多）'
	: phase < 0.78 ? '下弦月（左半亮）'
	: '残月（亏，亮左）'
console.log(`phase=${phase.toFixed(4)}  illumination=${(illum * 100).toFixed(1)}%  ${name}`)
