/** 调试：从 preview.html 提取亮/暗贴片 data URI，解码回 SVG 文件检查。 */
import { readFileSync, writeFileSync } from 'node:fs'

const html = readFileSync(new URL('../assets/preview.html', import.meta.url), 'utf8')
for (const [name, cls] of [['light', 'bg-demo-light'], ['dark', 'bg-demo-dark']]) {
	const re = new RegExp(`\\.${cls} \\{ background-image: url\\("data:image/svg\\+xml,([^"]+)"\\); \\}`)
	const m = html.match(re)
	if (!m) {
		console.log(`${name}: NOT FOUND in preview.html`)
		continue
	}
	const svg = decodeURIComponent(m[1])
	writeFileSync(new URL(`../assets/bg-tile-${name}.svg`, import.meta.url), svg)
	console.log(`--- ${name} (${svg.length} chars) ---`)
	console.log(svg)
	console.log()
}
