/**
 * dsh-skin-xuyuanwu — 本地预览生成器。
 *
 * 用真实 bundle（lib/client.js）+ SVG 序列化 stub 渲染三个组件的静态 SVG，
 * 叠上暖纸/靛夜两套主题底色写进 assets/preview.html —— 不开 DSH 也能
 * 对照检查造型、明暗两版对比度与动画细节。
 * 运行：node scripts/preview.mjs
 */
import { readFileSync, writeFileSync } from 'node:fs'
import { runInNewContext } from 'node:vm'

/* 1. 加载 bundle（同冒烟测试；记录 style 标签内容以提取背景贴片 data URI，收集 body 元素以复用星群） */
let registered = null
const bodyEls = []
const window = {
	__ModuleLoader__: { load: (mod) => { registered = mod } },
	addEventListener: () => {},
	removeEventListener: () => {},
	setTimeout: () => 0,
	clearTimeout: () => {},
}
const styleTags = []
const document = {
	head: { querySelector: () => null, appendChild: (tag) => styleTags.push(tag) },
	body: { querySelector: () => null, appendChild: (el) => bodyEls.push(el) },
	createElement: (tag) => ({
		tag,
		children: [],
		appendChild(child) { this.children.push(child) },
		setAttribute(key, value) { this[key] = value },
		remove() { this.removed = true },
	}),
	querySelectorAll: () => [],
}
runInNewContext(readFileSync(new URL('../lib/client.js', import.meta.url), 'utf8'), { window, document }, { filename: 'client.js' })

/* 2. jsx stub：返回 { type, props } 树（供序列化器消费） */
const jsx = (type, props) => ({ type, props, children: props?.children })
const jsxs = jsx
const exports = registered.factory(() => ({ jsx, jsxs, Fragment: 'Fragment' }))

/* 3. SVG 序列化器（camelCase 属性 → SVG 连字符形式 + style 对象支持） */
const KEEP_CAMEL = new Set(['viewBox'])
const attr = (key, value) => {
	if (value === undefined || value === null || value === false) return ''
	let name = key === 'className' ? 'class' : key
	if (!KEEP_CAMEL.has(name) && !name.includes('-')) name = name.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`)
	let text = String(value)
	if (typeof value === 'object' && !Array.isArray(value)) {
		text = Object.entries(value).map(([k, v]) => `${k.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`)}:${v}`).join(';')
	}
	return ` ${name}="${text.replaceAll('&', '&amp;').replaceAll('"', '&quot;')}"`
}
const selfClosing = new Set(['circle', 'ellipse', 'path', 'stop', 'rect', 'line', 'use'])
const serialize = (node) => {
	if (node === undefined || node === null || node === false) return ''
	if (Array.isArray(node)) return node.map(serialize).join('')
	if (typeof node !== 'object') return String(node)
	const { type, props } = node
	const attrs = Object.entries(props ?? {}).filter(([k]) => k !== 'children' && k !== 'key').map(([k, v]) => attr(k, v)).join('')
	const inner = serialize(props?.children)
	return selfClosing.has(type) ? `<${type}${attrs} />` : `<${type}${attrs}>${inner}</${type}>`
}

/* 4. 渲染三个组件（直接调槽位组件；generator 回调需迭代驱动） */
const driveInject = (callback) => {
	const result = callback()
	if (result && typeof result[Symbol.iterator] === 'function') { for (const _ of result) {} }
	return () => {}
}
const state = { byName: {} }
const ctx = {
	theme: { overrideTokens: () => () => {} },
	slots: {
		inject: (name, cb) => driveInject(cb),
		register: (options, component) => { state.byName[options.name] = component; return () => {} },
	},
	effect: (execute) => { execute() },
}
exports.apply(ctx, { brand: true, theme: true, heroAnimation: true, background: true, bgAnimation: true, bgMoon: true, moonCycle: false, starTrail: true, starField: true, wishMeteor: true, heroStyle: true, heroHeadline: '' })
const mark = serialize(state.byName['sidebar.brand.mark']({ size: 48 }))
const hero = serialize(state.byName['conversation.hero.brand.mark']({ size: 96, className: '' }))
const wordmark = serialize(state.byName['sidebar.brand.name']())

/* 5. 主题底色模拟（与 XYW_TOKENS 的核心值一致） */
const PAPER = { base: '#FAF6EC', layer: '#FFFDF6', sidebar: '#F3EDDC', primary: '#B8740F', label: '#2E2A20', sub: '#6E6753' }
const NIGHT = { base: '#111426', layer: '#171B33', sidebar: '#0D1021', primary: '#FFC65C', label: '#F2EFE4', sub: '#ABAEC8' }
const paletteStrip = (t) => `
	<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:10px;justify-content:center">
		${[t.base, t.layer, t.sidebar, t.primary, t.label, t.sub, '#D2623A', '#3A4380', '#FFE9B8', '#E85D3A'].map((c) => `<span title="${c}" style="width:26px;height:26px;border-radius:7px;background:${c};border:1px solid rgba(128,128,128,.35);display:inline-block"></span>`).join('')}
	</div>`
/* 侧栏品牌位模拟：直接复用真实字标序列化结果，用容器上的主题 CSS 变量驱动字标颜色 */
const sidebarSim = (t) => `
	<div style="background:${t.sidebar};border:1px solid rgba(128,128,128,.2);border-radius:12px;padding:14px 16px;display:inline-flex;align-items:center;gap:10px;--dsw-alias-state-business-primary:${t.primary};color:${t.label}">
		${mark.replaceAll('width="48" height="48"', 'width="30" height="30"')}
		${wordmark}
	</div>`

/* 6. 写预览页（布局动画/背景/月相/流星/拖尾/标题场景化 CSS 全量来自 apply 捕获的 style 标签） */
const fullCss = styleTags.map((t) => t.textContent ?? '').join('\n')
/* 从捕获 CSS 里提取亮暗两版的贴片 + 月相 data URI（运行时插值，源码正则拿不到） */
const urlsOf = (rule) => rule.match(/url\("data:image\/svg\+xml,[^"]+"\)/g) ?? []
const lightUrls = urlsOf(fullCss.match(/body:not\(\[data-ds-dark-theme\]\) \.xyw-bg-layer \{\s*background-image: ([^;]+);/)?.[1] ?? '')
const darkUrls = urlsOf(fullCss.match(/body\[data-ds-dark-theme\] \.xyw-bg-layer \{\s*background-image: ([^;]+);/)?.[1] ?? '')
if (lightUrls.length < 2 || darkUrls.length < 2) throw new Error('未能从 apply 捕获贴片 + 月相 data URI')
const bgLightUrl = lightUrls[0]
const bgDarkUrl = darkUrls[0]
const moonLightUrl = lightUrls[1]
const moonDarkUrl = darkUrls[1]
/* 复用真实星群元素树（createStarField 撒的随机星）做静态缩样：桩元素 → HTML */
const fieldEl = bodyEls.find((el) => el.className === 'xyw-star-field')
if (!fieldEl) throw new Error('未能从 apply 捕获星群元素')
const elHtml = (el) => {
	if (!el || typeof el !== 'object') return ''
	const skip = new Set(['tag', 'children', 'appendChild', 'setAttribute', 'remove', 'removed'])
	const attrs = Object.entries(el)
		.filter(([k, v]) => !skip.has(k) && (typeof v === 'string' || typeof v === 'number'))
		.map(([k, v]) => ` ${k === 'className' ? 'class' : k}="${String(v)}"`)
		.join('')
	const kids = (el.children ?? []).map(elHtml).join('')
	return `<${el.tag}${attrs}>${kids}</${el.tag}>`
}
const fieldHtml = elHtml(fieldEl)
const html = `<!doctype html>
<meta charset="utf-8">
<title>dsh-skin-xuyuanwu 预览</title>
<style>
	body { font-family: "PingFang SC", "Microsoft YaHei", system-ui, sans-serif; background: #f0ede6; margin: 0; padding: 32px; color: #333; }
	h1 { font-size: 18px; } h2 { font-size: 14px; margin: 24px 0 8px; color: #666; }
	.row { display: flex; align-items: center; gap: 24px; border-radius: 12px; padding: 20px 24px; flex-wrap: wrap; }
	.row.paper { background: ${PAPER.base}; border: 1px solid #E3D7B8; }
	.row.night { background: ${NIGHT.base}; border: 1px solid #333A62; }
	.card { text-align: center; } .card .label { font-size: 12px; margin-top: 8px; }
	.paper .label { color: #8D8672; } .night .label { color: #8186AB; }
	.bg-demo { height: 260px; border-radius: 12px; }
	.bg-demo-light {
		background-color: ${PAPER.base};
		background-image: ${bgLightUrl}, radial-gradient(1100px 520px at 50% -8%, rgba(232, 163, 61, 0.05), rgba(232, 163, 61, 0) 70%), ${moonLightUrl};
		background-size: 480px 480px, 100% 100%, 220px 220px;
		background-position: 0 0, 0 0, 86% 9%;
		background-repeat: repeat, no-repeat, no-repeat;
		border: 1px solid #E3D7B8;
	}
	.bg-demo-dark {
		background-color: ${NIGHT.base};
		background-image: ${bgDarkUrl}, radial-gradient(1100px 520px at 50% -8%, rgba(255, 198, 92, 0.07), rgba(255, 198, 92, 0) 70%), ${moonDarkUrl};
		background-size: 480px 480px, 100% 100%, 220px 220px;
		background-position: 0 0, 0 0, 86% 9%;
		background-repeat: repeat, no-repeat, no-repeat;
		border: 1px solid #333A62;
	}
	.headline-demo { font-size: 26px; font-weight: 600; }
	.starfield-demo {
		position: relative;
		height: 220px;
		border-radius: 12px;
		border: 1px solid #333A62;
		background: ${NIGHT.base};
		overflow: hidden;
	}
	.starfield-demo .xyw-star-field { position: absolute; inset: 0; }
	.starfield-demo .xyw-field-group { transition: none; }
	${fullCss}
</style>
<h1>🏮 dsh-skin-xuyuanwu 许愿屋 · 有求必应 — 预览（暖纸昼色 / 靛夜夜色）</h1>
<h2>侧栏品牌位模拟（logo 30px + 字标，左：亮色「暖纸」，右：暗色「靛夜」）</h2>
<div class="row paper" style="gap:32px">
	${sidebarSim(PAPER)}
	<div style="flex:1"></div>
	${sidebarSim(NIGHT)}
	${paletteStrip(PAPER)}
</div>
<h2>首屏月洞窗徽章（160px / 96px / 34px，带漂浮/星光/窗灯/灯笼动画）</h2>
<div class="row night">
	<div class="card">${hero.replaceAll('width="96" height="96"', 'width="160" height="160"')}<div class="label">放大 160px</div></div>
	<div class="card">${hero}<div class="label">96px</div></div>
	<div class="card">${hero.replaceAll('width="96" height="96"', 'width="34" height="34"')}<div class="label">34px（实际默认尺寸）</div></div>
	${paletteStrip(NIGHT)}
</div>
<h2>侧栏小屋 logo（48px / 24px）</h2>
<div class="row paper">
	<div class="card">${mark}<div class="label">48px</div></div>
	<div class="card">${mark.replaceAll('width="48" height="48"', 'width="24" height="24"')}<div class="label">24px（实际尺寸）</div></div>
	<div class="card">${mark.replaceAll('width="48" height="48"', 'width="16" height="16"')}<div class="label">16px（极限小）</div></div>
</div>
<h2>首屏标题场景化（楷体 + 琥珀渐变文字 + 柔光辉晕 + 入场「逐字点亮」wipe + 周期流光扫过；上亮下暗）</h2>
<div class="row paper">
	<span class="xyw-headline headline-demo">请许下你的愿望</span>
	<span style="font-size:12px;color:#8D8672">亮色 · 楷体暖墨琥珀渐变 + 流光</span>
</div>
<div class="row night" style="margin-top:12px">
	<span class="xyw-headline headline-demo">请许下你的愿望</span>
	<span style="font-size:12px;color:#8186AB">暗色 · 楷体暖金渐变 + 流光</span>
</div>
<h2>启动开幕动画分镜（实机启动播放约 1.3s，每会话一次：幕布徽记浮现 →「许愿屋」字标 + 三星连闪 + 一道流星 → 幕布淡出、首屏徽章浮现、标题逐字点亮）</h2>
<div class="row paper" style="gap:18px">
	<div class="card" style="width:300px;height:170px;background:radial-gradient(300px 220px at 50% 42%, #FCF8EF, #F0E5C9);display:flex;align-items:center;justify-content:center">
		<div style="width:72px;height:72px;opacity:.95">${mark.replaceAll('width="48" height="48"', 'width="72" height="72"')}</div>
		<div class="label" style="position:absolute;bottom:6px;left:0;right:0">t≈0.1s · 徽记回弹浮现</div>
	</div>
	<div class="card" style="width:300px;height:170px;background:radial-gradient(300px 220px at 50% 42%, #FCF8EF, #F0E5C9);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;position:relative">
		<span style="position:absolute;left:16%;top:28%;width:80px;height:2px;background:linear-gradient(90deg,transparent,#C77E14);transform:rotate(24deg)"></span>
		<span style="font-family:KaiTi,楷体,serif;font-size:20px;font-weight:700;letter-spacing:.34em;margin-left:.34em;color:#8F5B0A">许愿屋</span>
		<span style="font-size:10px;letter-spacing:.3em;margin-left:.3em;color:rgba(184,116,15,.8)">有求必应 · 请许下你的愿望</span>
		<div class="label" style="position:absolute;bottom:6px;left:0;right:0">t≈0.4s · 字标上浮 + 流星</div>
	</div>
	<div class="card" style="width:300px;height:170px;background:radial-gradient(300px 220px at 50% 42%, #FCF8EF, #F0E5C9);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;opacity:.55">
		<span style="font-family:KaiTi,楷体,serif;font-size:20px;font-weight:700;letter-spacing:.34em;margin-left:.34em;color:#8F5B0A">许愿屋</span>
		<span style="font-size:10px;letter-spacing:.3em;margin-left:.3em;color:rgba(184,116,15,.8)">幕布淡出 · 首屏登场</span>
		<div class="label" style="position:absolute;bottom:6px;left:0;right:0">t≈1.0s · 淡出揭幕</div>
	</div>
</div>
<h2>近景闪烁星群（真实随机撒星缩样：远景组小而密、近景组大而亮，各自随机周期闪烁；实机另有远近两组鼠标视差纵深）</h2>
<div class="starfield-demo">${fieldHtml}</div>
<h2>UI 细节打磨（实机全局生效，此为样例：按钮悬浮微抬 + 暖影、按压回落；复选框/单选/进度条灯火琥珀点缀；文本选区暖金高亮；滚动条细圆暖金）</h2>
<div class="row paper" style="gap:18px">
	<button style="padding:8px 18px;border:1px solid #D8C9A4;border-radius:8px;background:#FFFDF6;color:#6E4A0F;font-size:14px;cursor:pointer">悬浮 / 按压试试</button>
	<label style="display:flex;align-items:center;gap:6px;font-size:14px;color:#6E6753"><input type="checkbox" checked />许个小愿</label>
	<label style="display:flex;align-items:center;gap:6px;font-size:14px;color:#6E6753"><input type="radio" name="wish" checked />有求必应</label>
	<span style="font-size:14px;color:#6E6753;user-select:all">选中这段文字看看高亮</span>
</div>
<div class="row night" style="margin-top:12px;gap:18px">
	<button style="padding:8px 18px;border:1px solid #3A4266;border-radius:8px;background:#171B33;color:#FFD98F;font-size:14px;cursor:pointer">暗色按钮</button>
	<label style="display:flex;align-items:center;gap:6px;font-size:14px;color:#ABAEC8"><input type="checkbox" checked />许个小愿</label>
	<span style="font-size:14px;color:#ABAEC8;user-select:all">选中这段文字看看高亮</span>
</div>
<h2>全局背景：星空贴片 + 顶部灯晕 + 今日月相月（右上；480px 平铺；上：亮色「暖纸 · 暖墨星辰」/ 下：暗色「靛夜 · 暖金星辰」）</h2>
<div class="bg-demo bg-demo-light"></div>
<div class="bg-demo bg-demo-dark" style="margin-top:12px"></div>
<p style="font-size:12px;color:#999;margin-top:16px">注：右上月轮按<b>今日真实农历月相</b>绘制（朔望月公式，亮度随圆缺，随刷新更新）；实机还有<b>月相呼吸</b>——今日月每约 96s 缓缓盈到满月、再缓缓亏回今日月相，且<b>月亮沿上空规律移动</b>（约 3 分钟一圈，点月亮彩蛋跟着月亮走）（月亮是活的）；<b>启动开幕动画</b>每会话只在实机启动播放一次；星空缓漂、错峰流星、随机天降流星、鼠标许愿星拖尾、星群鼠标视差、输入框回车许愿流星、点击星芒/按钮碰星为运行时动效，静态预览不呈现 —— F5 刷新 DSH Desktop 实机体验。彩蛋：右上<b>月亮可点击</b>（悬停现光环；零占位命中测试——页面上不叠任何可交互元素，绝不遮挡按钮，点到真实控件一律让路），点一下落一场流星雨；徽章/侧栏 logo <b>悬停点灯</b>（窗灯与灯笼更亮）。</p>
`
writeFileSync(new URL('../assets/preview.html', import.meta.url), html)
console.log('✓ 已生成 assets/preview.html')
