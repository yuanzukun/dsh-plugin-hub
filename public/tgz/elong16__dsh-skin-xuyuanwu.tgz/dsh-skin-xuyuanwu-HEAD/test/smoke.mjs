/**
 * dsh-skin-xuyuanwu — 冒烟测试（无浏览器）。
 *
 * 用 stub 的 window/__ModuleLoader__/require/document/MutationObserver 完整
 * 物化 lib/client.js 的 factory，驱动 apply() 走完四层皮肤逻辑，
 * 校验导出面、槽位注册、令牌覆盖、组件树结构与首屏标题改写。
 *
 * 运行：node test/smoke.mjs（零依赖，node >=22）
 */
import { readFileSync } from 'node:fs'
import { runInNewContext } from 'node:vm'
import assert from 'node:assert/strict'

const source = readFileSync(new URL('../lib/client.js', import.meta.url), 'utf8')

/* 1. 加载 bundle：必须以包名注册进 __ModuleLoader__（document/window/observer stub 一并注入 VM 上下文） */
const styleTags = []
const bgLayers = []
const windowListeners = []
const documentListeners = []
const timers = []
const bodyClasses = new Set()
const document = {
	head: {
		querySelector: () => null,
		appendChild: (tag) => styleTags.push(tag),
	},
	createElement: (tag) => {
		const classes = new Set()
		const el = {
			tag,
			children: [],
			listeners: [],
			parentNode: null,
			classList: {
				add: (...cs) => { for (const c of cs) classes.add(c) },
				remove: (...cs) => { for (const c of cs) classes.delete(c) },
				toggle: (c, force) => {
					const on = force === undefined ? !classes.has(c) : Boolean(force)
					if (on) classes.add(c)
					else classes.delete(c)
				},
				contains: (c) => classes.has(c),
			},
			appendChild(child) { if (child) child.parentNode = this; this.children.push(child) },
			setAttribute(key, value) { this[key] = value },
			getAttribute(key) { return this[key] ?? null },
			addEventListener(type, handler, options) { this.listeners.push({ type, handler, options }) },
			removeEventListener(type, handler) {
				const i = this.listeners.findIndex((l) => l.type === type && l.handler === handler)
				if (i >= 0) this.listeners.splice(i, 1)
			},
			querySelector(sel) {
				if (sel.includes('close')) return this._closeBtn || (this._closeBtn = { listeners: [], addEventListener(type, handler) { this.listeners.push({ type, handler }) } })
				if (sel.includes('reset')) return this._resetBtn || (this._resetBtn = { listeners: [], addEventListener(type, handler) { this.listeners.push({ type, handler }) } })
				return null
			},
			querySelectorAll(sel) {
				if (sel.includes('checkbox')) {
					if (!this._checkboxes) {
						const keys = ['sound', 'moonCycle', 'moonOrbit', 'typingSparks', 'weavingLight', 'wishFortune', 'timeAmbience', 'ecoMode']
						this._checkboxes = keys.map((k) => ({
							getAttribute: (attr) => attr === 'data-key' ? k : null,
							checked: true,
							listeners: [],
							addEventListener(type, handler) { this.listeners.push({ type, handler }) },
						}))
					}
					return this._checkboxes
				}
				return []
			},
			remove() { this.removed = true; this.parentNode = null },
		}
		return el
	},
	body: {
		querySelector: () => null,
		appendChild: (el) => { if (el) el.parentNode = document.body; bgLayers.push(el) },
		classList: {
			add: (c) => bodyClasses.add(c),
			remove: (c) => bodyClasses.delete(c),
			contains: (c) => bodyClasses.has(c),
			toggle: (c, force) => {
				const on = force === undefined ? !bodyClasses.has(c) : Boolean(force)
				if (on) bodyClasses.add(c)
				else bodyClasses.delete(c)
			},
		},
	},
	addEventListener: (type, handler, options) => documentListeners.push({ type, handler, options }),
	removeEventListener: (type, handler) => {
		const i = documentListeners.findIndex((l) => l.type === type && l.handler === handler)
		if (i >= 0) documentListeners.splice(i, 1)
	},
	querySelector: () => null,
	querySelectorAll: () => [],
}
/* MutationObserver stub：记录实例与 observe/disconnect 调用 */
const observers = []
class MutationObserverStub {
	constructor(callback) { this.callback = callback; observers.push(this) }
	observe(target, options) { this.observed = { target, options } }
	disconnect() { this.disconnected = true }
}
/* rAF stub：帧回调进队列，测试手动放行 */
const rafQueue = []
const requestAnimationFrame = (fn) => (rafQueue.push(fn), rafQueue.length)
const cancelAnimationFrame = () => {}
/* FakeDate：可控时钟（月相呼吸层的时间轴驱动），默认冻结在真实当前时刻（不破坏既有冷却逻辑），测试内拨快 */
let fakeNowMs = Date.now()
class FakeDate extends Date {
	constructor(...args) { super(...(args.length ? args : [fakeNowMs])) }
	static now() { return fakeNowMs }
}
let registered = null
const window = {
	__ModuleLoader__: { load: (mod) => { registered = mod } },
	matchMedia: () => ({ matches: false }),
	innerWidth: 1280,
	innerHeight: 800,
	addEventListener: (type, handler, options) => { windowListeners.push({ type, handler, options }) },
	removeEventListener: (type, handler) => {
		const i = windowListeners.findIndex((l) => l.type === type && l.handler === handler)
		if (i >= 0) windowListeners.splice(i, 1)
	},
	/* setTimeout 队列桩：只排队不执行（测试手动放行，避免自旋递归） */
	setTimeout: (fn) => { timers.push(fn); return timers.length },
	clearTimeout: () => {},
}
/* setInterval 队列桩：记录回调与周期间隔（月相呼吸 120ms 一拍，测试手动放行拨快时钟） */
const intervals = []
window.setInterval = (fn, ms) => { const rec = { fn, ms, cleared: false }; intervals.push(rec); return intervals.length }
window.clearInterval = (id) => { const rec = intervals[id - 1]; if (rec) rec.cleared = true }
const navigator = {}
window.navigator = navigator
runInNewContext(source, { window, document, MutationObserver: MutationObserverStub, requestAnimationFrame, cancelAnimationFrame, Date: FakeDate, navigator }, { filename: 'client.js' })
assert.ok(registered, 'bundle 未注册进 __ModuleLoader__')
assert.equal(registered.id, 'dsh-skin-xuyuanwu', '注册 id 必须是包名')

/* 2. 物化 factory：只允许 require 平台基座的 react/jsx-runtime */
const jsx = (type, props) => ({ type, props, children: props?.children })
const jsxs = jsx
const exports = registered.factory((id) => {
	assert.equal(id, 'react/jsx-runtime', `意外的依赖请求: ${id}`)
	return { jsx, jsxs, Fragment: 'Fragment' }
})
assert.equal(typeof exports.apply, 'function', '缺少 apply 导出')
/* 注意：bundle 在独立 VM 上下文执行，数组原型不同 —— 展开成本地数组再比较 */
assert.deepEqual([...exports.inject], ['theme', 'slots'], 'inject 导出不符')

/* 3. 驱动 apply：全开配置 */
const tokenCalls = []
const slotRegistrations = []
const effects = []
/* 真实 slots.inject 会驱动 generator 回调（迭代收集 yield 的清理函数） */
const driveInject = (callback) => {
	const result = callback()
	const disposers = []
	if (result && typeof result[Symbol.iterator] === 'function') {
		for (const dispose of result) disposers.push(dispose)
	}
	return () => disposers.forEach((dispose) => dispose())
}

const ALL_OFF = {
	brand: false,
	theme: false,
	heroAnimation: false,
	background: false,
	bgAnimation: false,
	bgMoon: false,
	moonCycle: false,
	moonOrbit: false,
	starTrail: false,
	starField: false,
	wishMeteor: false,
	uiPolish: false,
	clickStar: false,
	bootAnimation: false,
	moonWish: false,
	heroStyle: false,
	heroHeadline: '',
	weavingLight: false,
	typingSparks: false,
	sound: false,
	timeAmbience: false,
	wishFortune: false,
	quickPanel: false,
	ecoMode: false,
}

const ctx = {
	theme: { overrideTokens: (sourceId, tokens) => { tokenCalls.push({ sourceId, tokens }); return () => {} } },
	slots: {
		inject: (name, callback) => driveInject(callback),
		register: (options, component) => { slotRegistrations.push({ options, component }); return () => {} },
	},
	effect: (execute, label) => { effects.push({ label, dispose: execute() }) },
	logger: () => ({ warn: () => {} }),
}
exports.apply(ctx, { ...ALL_OFF, brand: true, theme: true, heroAnimation: true })

/* 4. 断言：主题令牌层（灯火琥珀主色 + 暖纸/靛夜背景 + 静态色阶） */
assert.equal(tokenCalls.length, 1, 'overrideTokens 应调用一次')
assert.equal(tokenCalls[0].sourceId, 'dsh-skin-xuyuanwu')
const tokens = tokenCalls[0].tokens
assert.equal(tokens['--dsw-alias-state-business-primary'].light, '#B8740F', '亮色主色应为灯火琥珀')
assert.equal(tokens['--dsw-alias-state-business-primary'].dark, '#FFC65C', '暗色主色应为灯笼亮金')
assert.equal(tokens['--dsw-alias-bg-base'].light, '#FAF6EC', '亮色背景应为暖纸')
assert.equal(tokens['--dsw-alias-bg-base'].dark, '#111426', '暗色背景应为靛夜')
assert.ok(tokens['--dsw-static-blue-500'], '缺少靛夜静态色阶')
assert.ok(tokens['--dsw-specific-bubble'], '缺少气泡令牌')
assert.ok(Object.values(tokens).every((v) => v && typeof v.light === 'string' && typeof v.dark === 'string'), '所有令牌必须带 light/dark 双值')

/* 5. 断言：三个品牌槽位，全部 -100 阴影优先级 */
const byName = Object.fromEntries(slotRegistrations.map((r) => [r.options.name, r]))
assert.equal(slotRegistrations.length, 3, `应注册 3 个槽位，实际 ${slotRegistrations.length}`)
for (const name of ['sidebar.brand.mark', 'sidebar.brand.name', 'conversation.hero.brand.mark']) {
	assert.ok(byName[name], `缺少槽位 ${name}`)
	assert.equal(byName[name].options.priority, -100, `${name} 优先级应为 -100`)
}

/* 6. 断言：布局动画层（漂浮/星光/窗灯呼吸/灯笼摇曳 + 减少动效回退） */
assert.equal(styleTags.length, 1, '应注入一个 <style> 标签')
assert.equal(styleTags[0]['data-plugin-css'], 'dsh-skin-xuyuanwu/layout')
assert.ok(styleTags[0].textContent.includes('xyw-hero-float'), '缺少漂浮动画')
assert.ok(styleTags[0].textContent.includes('xyw-twinkle'), '缺少星光动画')
assert.ok(styleTags[0].textContent.includes('xyw-breath'), '缺少窗灯呼吸动画')
assert.ok(styleTags[0].textContent.includes('xyw-sway'), '缺少灯笼摇曳动画')
assert.ok(styleTags[0].textContent.includes('prefers-reduced-motion'), '缺少减少动效回退')

/* 7. 组件树结构：小屋 logo（48 系） */
const mark = byName['sidebar.brand.mark'].component({ size: 24 })
assert.equal(mark.type, 'svg')
assert.equal(mark.props.viewBox, '0 0 48 48')
assert.equal(mark.props.width, 24)
assert.ok(Array.isArray(mark.children) && mark.children.length >= 12, '小屋形状组不完整')

/* 8. 组件树结构：月洞窗徽章（96 系，透传宿主 className + 动画类） */
const hero = byName['conversation.hero.brand.mark'].component({ size: 34, className: 'host-fish' })
assert.equal(hero.type, 'svg')
assert.equal(hero.props.viewBox, '0 0 96 96')
assert.ok(hero.props.className.includes('xyw-hero-root'), 'hero 缺少动画类')
assert.ok(hero.props.className.includes('host-fish'), 'hero 应透传宿主 className')
assert.ok(Array.isArray(hero.children) && hero.children.length >= 20, '徽章场景不完整')
const plaqueText = hero.children.find((child) => child?.type === 'text')
assert.equal(plaqueText?.props?.children, '有求必应', '木牌应写「有求必应」')

/* 9. 组件树结构：字标（许愿屋 + 小星 + 有求必应） */
const wordmark = byName['sidebar.brand.name'].component()
assert.equal(wordmark.type, 'span')
assert.equal(wordmark.children[0].children, '许愿屋')
assert.equal(wordmark.children[2].children, '有求必应')

/* 10. 开关语义：全关（含标题改写关）时不产生任何副作用 */
{
	const slotRegs = []
	const tokensCalled = []
	const observersBefore = observers.length
	const offCtx = {
		theme: { overrideTokens: (s) => { tokensCalled.push(s); return () => {} } },
		slots: {
			inject: (name, cb) => driveInject(cb),
			register: (o) => { slotRegs.push(o); return () => {} },
		},
		effect: (execute) => { const d = execute(); if (typeof d === 'function') styleTags.push({ disposed: true }) },
	}
	styleTags.length = 0
	bgLayers.length = 0
	windowListeners.length = 0
	exports.apply(offCtx, ALL_OFF)
	assert.deepEqual([slotRegs.length, tokensCalled.length, styleTags.length], [0, 0, 0], '全关时不应有任何副作用')
	assert.equal(observers.length, observersBefore, '标题改写关时不应挂 observer')
	assert.equal(bgLayers.length, 0, '背景关时不应注入背景层')
	assert.equal(windowListeners.length, 0, '拖尾/星群/流星关时不应挂 mousemove/keydown 监听')
}

/* 11. 畸形配置回落默认（heroHeadline 缺省回落默认文案并挂 observer） */
{
	const slotRegs = []
	const observersBefore = observers.length
	const resilientCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: {
			inject: (name, cb) => driveInject(cb),
			register: (o) => { slotRegs.push(o); return () => {} },
		},
		effect: (execute) => { execute() },
	}
	styleTags.length = 0
	exports.apply(resilientCtx, undefined)
	exports.apply(resilientCtx, { brand: 'yes' })
	assert.equal(slotRegs.length, 6, '畸形/缺省配置都应回落默认（3 槽位 × 2 次）')
	assert.equal(observers.length, observersBefore + 4, '缺省配置应各挂标题与挑灯织光 observer（共 4 个）')
}

/* 12. 槽位注册冲突优雅降级（同优先级抛错不炸皮肤） */
{
	const conflictCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: {
			inject: (name, cb) => driveInject(cb),
			register: () => { throw new Error('slot priority conflict') },
		},
		effect: (execute) => { execute() },
		logger: () => ({ warn: () => {} }),
	}
	styleTags.length = 0
	exports.apply(conflictCtx, { ...ALL_OFF, brand: true })
	assert.equal(styleTags.length, 0, '冲突场景不应注入布局层（heroAnimation/background/拖尾/星群/流星/标题关）')
}

/* 13. 首屏标题改写 + 场景化：中英文案 → 许愿文案并挂 class；无关文案不动；重渲染恢复后再改回；清理还原 */
{
	const makeSpan = (text) => {
		const classes = new Set()
		return {
			className: 'zNic4G_headlineText',
			textContent: text,
			classList: {
				add: (c) => classes.add(c),
				remove: (c) => classes.delete(c),
				contains: (c) => classes.has(c),
			},
		}
	}
	const spans = [makeSpan(' 探索未至之境 '), makeSpan('Into the Unknown'), makeSpan('别的标题')]
	const originalQuerySelectorAll = document.querySelectorAll
	document.querySelectorAll = (sel) => sel.includes('_headlineText') ? spans : []
	const observersBefore = observers.length
	const disposers = []
	const headlineCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { const dispose = execute(); if (label === 'dsh-skin-xuyuanwu: hero headline') disposers.push(dispose) },
	}
	try {
		exports.apply(headlineCtx, { ...ALL_OFF, heroStyle: true, heroHeadline: '请许下你的愿望' })
		/* 生效即改写：中英官方文案都换，带空白先 trim；无关文案不动；场景化挂 class */
		assert.equal(spans[0].textContent, '请许下你的愿望', '中文官方标题应被改写（含首尾空白）')
		assert.equal(spans[1].textContent, '请许下你的愿望', '英文官方标题应被改写')
		assert.equal(spans[2].textContent, '别的标题', '无关文案不应被动')
		assert.ok(spans[0].classList.contains('xyw-headline'), 'heroStyle 开应挂场景化 class')
		assert.ok(spans[1].classList.contains('xyw-headline'), '英文标题同样挂场景化 class')
		/* 场景化 CSS：渐变文字裁切 + 辉晕 + 入场浮现 + 流光扫过（亮带 + 辉光脉冲）+ 亮暗两版 */
		const css = styleTags[styleTags.length - 1]?.textContent ?? ''
		assert.ok(css.includes('.xyw-headline'), '缺少场景化标题规则')
		assert.ok(css.includes('background-clip: text'), '缺少渐变文字裁切')
		assert.ok(css.slice(css.indexOf('body[data-ds-dark-theme] .xyw-headline')).includes('background-image:'), '暗色标题渐变必须用 background-image（background 简写会重置文字裁切）')
		assert.ok(css.includes('drop-shadow'), '缺少柔光辉晕')
		assert.ok(css.includes('xyw-headline-in'), '缺少入场浮现动画')
		assert.ok(css.includes('xyw-headline-shimmer 4.6s'), '流光应为 4.6s 周期')
		assert.ok(css.includes('#FFF3D6'), '亮色流光带应有近白金核心')
		assert.ok(css.includes('--xyw-head-glow-strong'), '流光应带辉光脉冲（强辉光变量）')
		/* observer 挂在 body 上，监听子树 + 字符变更 */
		const observer = observers[observers.length - 1]
		assert.equal(observers.length, observersBefore + 1, '应挂一个 MutationObserver')
		assert.equal(observer.observed.target, document.body, 'observer 应挂在 document.body')
		assert.equal(observer.observed.options.subtree, true, '应监听子树')
		assert.equal(observer.observed.options.characterData, true, '应监听字符变更')
		/* 模拟 React 重渲染恢复官方文案 → observer 回调 → rAF 合并 → 再次改写 */
		spans[0].textContent = '探索未至之境'
		spans[0].classList.remove('xyw-headline')
		observer.callback()
		assert.equal(rafQueue.length, 1, '变更应调度一帧（rAF 合并）')
		observer.callback()
		assert.equal(rafQueue.length, 1, '重复变更应合并到同一帧')
		rafQueue.splice(0).forEach((fn) => fn())
		assert.equal(spans[0].textContent, '请许下你的愿望', '重渲染恢复后应再次改写')
		assert.ok(spans[0].classList.contains('xyw-headline'), '重渲染后场景化 class 应补挂')
		/* 清理：断开监听 + 摘 class + 还原官方文案 */
		assert.ok(disposers.length === 1 && typeof disposers[0] === 'function', '标题层应返回清理函数')
		disposers[0]()
		assert.equal(observer.disconnected, true, '清理应断开 observer')
		assert.ok(!spans[0].classList.contains('xyw-headline'), '清理应摘掉场景化 class')
		assert.equal(spans[0].textContent, '探索未至之境', '清理应还原中文官方文案')
		assert.equal(spans[1].textContent, 'Into the Unknown', '清理应还原英文官方文案')
		/* heroStyle 关：只改文案不上妆 */
		exports.apply(headlineCtx, { ...ALL_OFF, heroStyle: false, heroHeadline: '请许下你的愿望' })
		assert.equal(spans[0].textContent, '请许下你的愿望', 'heroStyle 关仍应改写文案')
		assert.ok(!spans[0].classList.contains('xyw-headline'), 'heroStyle 关不应挂 class')
		disposers[disposers.length - 1]()
	} finally {
		document.querySelectorAll = originalQuerySelectorAll
	}
}

/* 14. 全局背景层：贴片 + 灯晕 + 今日月相月 CSS（缓漂/流星动效）+ 固定全窗零交互元素 + 清理移除 */
{
	styleTags.length = 0
	bgLayers.length = 0
	const disposers = []
	const bgCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(bgCtx, { ...ALL_OFF, background: true, bgAnimation: true, bgMoon: true })
	/* CSS：.xyw-bg-layer 固定全窗 + 零交互 + 亮暗两版贴片/月相 data URI + 灯晕纵深 */
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(css.includes('.xyw-bg-layer'), '缺少背景层规则')
	assert.ok(css.includes('position: fixed'), '背景层应固定全窗')
	assert.ok(css.includes('pointer-events: none'), '背景层应零交互')
	assert.ok(css.includes('body:not([data-ds-dark-theme]) .xyw-bg-layer'), '缺少亮色版贴片选择器')
	assert.ok(css.includes('body[data-ds-dark-theme] .xyw-bg-layer'), '缺少暗色版贴片选择器')
	const urls = css.match(/url\("data:image\/svg\+xml,[^"]+"\)/g) ?? []
	assert.equal(urls.length, 4, '应有贴片 + 月相各两版共 4 个 data URI')
	assert.ok(urls.every((u) => u.includes('%3Csvg')), '贴片/月相应是 URL 编码的 SVG')
	assert.ok(css.includes('radial-gradient'), '缺少顶部灯晕纵深')
	/* 月相月：右上独立背景层，不随贴片漂移 */
	assert.ok(css.includes('86% 9%'), '月相应固定在右上')
	assert.ok(css.includes('220px 220px'), '月相层应有独立尺寸')
	/* 动效：星空缓漂（贴片层平移一个周期、灯晕/月相钉死）+ 双流星错峰且方向对齐 */
	assert.ok(css.includes('@keyframes xyw-bg-drift'), '缺少星空缓漂动画')
	assert.ok(css.includes('background-position: 480px 480px, 0 0, 86% 9%'), '缓漂应只平移贴片层、灯晕/月相钉死')
	assert.ok(css.includes('@keyframes xyw-meteor-a') && css.includes('@keyframes xyw-meteor-b'), '缺少两条流星动画')
	assert.ok(css.includes('rotate(40deg)') && css.includes('rotate(-38deg)'), '流星朝向应随划动方向区分')
	/* 流星加大加彩：3px 光带 + 辉光 + 第二颗定档流星换色 */
	assert.ok(css.includes('height: 3px'), '流星应为 3px 粗光带')
	assert.ok(css.includes('box-shadow: 0 0 10px'), '流星应带辉光')
	assert.ok(css.includes('width: 150px') && css.includes('width: 190px'), '定档流星应加长（150/190px）')
	assert.ok(css.includes('body:not([data-ds-dark-theme]) .xyw-bg-layer::after'), '第二颗定档流星应有亮色换色规则')
	/* 元素：挂 body、带归属标记、aria-hidden、类名正确 */
	assert.equal(bgLayers.length, 1, '应注入一个背景层元素')
	const layer = bgLayers[0]
	assert.equal(layer.className, 'xyw-bg-layer', '背景层类名不符')
	assert.equal(layer['data-plugin-css'], 'dsh-skin-xuyuanwu/background', '背景层缺少归属标记')
	assert.equal(layer['aria-hidden'], 'true', '背景层应对读屏隐藏')
	/* 清理：三个 effect（CSS 标签 + 背景元素 + 天降流星节奏）都返回清理函数 */
	const bgDisposers = disposers.filter((d) => d.label.startsWith('dsh-skin-xuyuanwu:'))
	assert.equal(bgDisposers.length, 3, '背景开时应有三个布局层 effect')
	assert.ok(bgDisposers.every((d) => typeof d.dispose === 'function'), '布局层 effect 都应返回清理函数')
	/* bgMoon 关：回到两层背景、无月相 data URI */
	styleTags.length = 0
	exports.apply(bgCtx, { ...ALL_OFF, background: true, bgAnimation: true, bgMoon: false })
	const noMoonCss = styleTags[0]?.textContent ?? ''
	const noMoonUrls = noMoonCss.match(/url\("data:image\/svg\+xml,[^"]+"\)/g) ?? []
	assert.equal(noMoonUrls.length, 2, 'bgMoon 关应只剩两版贴片 data URI')
	assert.ok(!noMoonCss.includes('86% 9%'), 'bgMoon 关不应有月相层坐标')
}

/* 15. 鼠标许愿星拖尾：距离节流落星 + 池上限 + 被动监听 + 清理摘监听清星 */
{
	styleTags.length = 0
	bgLayers.length = 0
	windowListeners.length = 0
	const disposers = []
	const trailCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(trailCtx, { ...ALL_OFF, starTrail: true })
	/* CSS：拖尾星规则 + 亮暗两版星形 + 消逝动画 + reduced-motion 隐藏 */
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(css.includes('.xyw-trail-star'), '缺少拖尾星规则')
	assert.ok(css.includes('@keyframes xyw-trail'), '缺少拖尾消逝动画')
	assert.ok(css.includes('prefers-reduced-motion'), '缺少减少动效回退')
	const urls = css.match(/url\("data:image\/svg\+xml,[^"]+"\)/g) ?? []
	assert.equal(urls.length, 4, '拖尾星应有两主色 + 两 alt 色共 4 个 data URI')
	/* 监听：单个被动 mousemove */
	const mousemoves = windowListeners.filter((l) => l.type === 'mousemove')
	assert.equal(mousemoves.length, 1, '应挂一个 mousemove 监听')
	assert.equal(mousemoves[0].options?.passive, true, 'mousemove 应为被动监听')
	const handler = mousemoves[0].handler
	/* 落星：每 30px 移动一颗，60 次只出 24 颗（池上限） */
	for (let i = 0; i < 60; i++) handler({ clientX: i * 30, clientY: 0 })
	assert.equal(bgLayers.length, 24, '拖尾星应封顶 24 颗')
	for (const el of bgLayers) {
		assert.ok(/^xyw-trail-star( alt)?$/.test(el.className), `拖尾星类名不符: ${el.className}`)
		assert.ok(/left:\d+(\.\d+)?px/.test(el.style ?? ''), '拖尾星缺定位样式')
		assert.ok(/width:\d+(\.\d+)?px/.test(el.style ?? ''), '拖尾星缺尺寸样式')
	}
	/* 小于步距（28px）的移动不落星 */
	handler({ clientX: 59 * 30 + 10, clientY: 0 })
	assert.equal(bgLayers.length, 24, '小于步距不应落星')
	/* 清理：摘监听 + 移除全部现存星 */
	const trailDisposers = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: star trail')
	assert.equal(trailDisposers.length, 1, '应有一个拖尾层 effect')
	trailDisposers[0].dispose()
	assert.equal(windowListeners.filter((l) => l.type === 'mousemove').length, 0, '清理应摘掉 mousemove 监听')
	assert.ok(bgLayers.every((el) => el.removed), '清理应移除全部拖尾星')
}

/* 16. 回车许愿流星：输入框裸回车触发 + 组词/Shift/非输入场景不误触 + 冷却上限 + 清理摘监听清流星 */
{
	styleTags.length = 0
	bgLayers.length = 0
	windowListeners.length = 0
	const disposers = []
	const wishCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(wishCtx, { ...ALL_OFF, wishMeteor: true })
	/* CSS：流星规则 + 沿自身朝向飞行 + reduced-motion 隐藏 */
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(css.includes('.xyw-wish-meteor'), '缺少许愿流星规则')
	assert.ok(css.includes('@keyframes xyw-wish-fly'), '缺少流星飞行动画')
	assert.ok(css.includes('--xyw-wish-rot'), '缺少随机朝向变量')
	assert.ok(css.includes('width: 170px') && css.includes('height: 3px'), '许愿流星应为 170×3px 加粗光带')
	assert.ok(css.includes('box-shadow: 0 0 10px'), '许愿流星应带辉光')
	assert.ok(css.includes('prefers-reduced-motion'), '缺少减少动效回退')
	/* 监听：单个被动 keydown */
	const keydowns = windowListeners.filter((l) => l.type === 'keydown')
	assert.equal(keydowns.length, 1, '应挂一个 keydown 监听')
	assert.equal(keydowns[0].options?.passive, true, 'keydown 应为被动监听')
	const handler = keydowns[0].handler
	const textarea = { tagName: 'TEXTAREA' }
	/* 裸回车（输入框内）→ 流星 */
	handler({ key: 'Enter', target: textarea })
	assert.equal(bgLayers.length, 1, '输入框回车应落一颗流星')
	const meteor = bgLayers[0]
	assert.equal(meteor.className, 'xyw-wish-meteor', '流星类名不符')
	assert.ok(/top:\d+(\.\d+)?%/.test(meteor.style ?? ''), '流星缺纵向定位')
	assert.ok(/--xyw-wish-rot:\d+(\.\d+)?deg/.test(meteor.style ?? ''), '流星缺随机朝向变量')
	assert.ok(/--xyw-meteor-head:rgba\(/.test(meteor.style ?? ''), '流星缺随机配色变量（head）')
	assert.ok(/--xyw-meteor-glow:rgba\(/.test(meteor.style ?? ''), '流星缺随机配色变量（glow）')
	/* 冷却期内第二颗不触发 */
	handler({ key: 'Enter', target: textarea })
	assert.equal(bgLayers.length, 1, '冷却期内不应再落流星')
	/* Shift+Enter / 输入法组词 / 非回车 / 非输入场景 → 不触发 */
	handler({ key: 'Enter', shiftKey: true, target: textarea })
	handler({ key: 'Enter', isComposing: true, target: textarea })
	handler({ key: 'Enter', keyCode: 229, target: textarea })
	handler({ key: 'a', target: textarea })
	handler({ key: 'Enter', target: { tagName: 'DIV' } })
	assert.equal(bgLayers.length, 1, 'Shift/组词/非回车/非输入场景不应落流星')
	/* 清理：摘监听 + 移除现存流星 */
	const wishDisposers = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: wish meteor')
	assert.equal(wishDisposers.length, 1, '应有一个许愿流星层 effect')
	wishDisposers[0].dispose()
	assert.equal(windowListeners.filter((l) => l.type === 'keydown').length, 0, '清理应摘掉 keydown 监听')
	assert.ok(bgLayers.every((el) => el.removed), '清理应移除全部流星')
}

/* 17. 近景闪烁星群：远近两组随机撒星 + twinkle 样式 + 视差监听 + 清理摘监听移除星群 */
{
	styleTags.length = 0
	bgLayers.length = 0
	windowListeners.length = 0
	const disposers = []
	const fieldCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(fieldCtx, { ...ALL_OFF, starField: true })
	/* CSS：星群/分组/闪烁规则（动画名避开首屏徽章的 xyw-twinkle）+ reduced-motion 隐藏 */
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(css.includes('.xyw-star-field'), '缺少星群容器规则')
	assert.ok(css.includes('.xyw-field-group'), '缺少远近分组规则')
	assert.ok(css.includes('.xyw-field-star'), '缺少星点规则')
	assert.ok(css.includes('@keyframes xyw-field-twinkle'), '缺少星点闪烁动画')
	assert.ok(!css.includes('@keyframes xyw-twinkle'), '星群动画不应占用首屏徽章的 xyw-twinkle 名')
	assert.ok(css.includes('prefers-reduced-motion'), '缺少减少动效回退')
	/* 元素：一个星群 + 两组（far 8-10 颗、near 5-7 颗），星点带定位/尺寸/随机周期 */
	assert.equal(bgLayers.length, 1, '应注入一个星群容器')
	const field = bgLayers[0]
	assert.equal(field.className, 'xyw-star-field', '星群容器类名不符')
	assert.equal(field['aria-hidden'], 'true', '星群应对读屏隐藏')
	assert.equal(field.children.length, 2, '星群应分远近两组')
	const counts = field.children.map((g) => g.children.length)
	assert.ok(counts[0] >= 8 && counts[0] <= 10, `远景组应 8-10 颗，实际 ${counts[0]}`)
	assert.ok(counts[1] >= 5 && counts[1] <= 7, `近景组应 5-7 颗，实际 ${counts[1]}`)
	for (const group of field.children) {
		for (const star of group.children) {
			assert.ok(/^xyw-field-star( star)?$/.test(star.className), `星点类名不符: ${star.className}`)
			assert.ok(/left:\d+(\.\d+)?%/.test(star.style ?? ''), '星点缺横向定位')
			assert.ok(/--xyw-twinkle-d:\d+(\.\d+)?s/.test(star.style ?? ''), '星点缺随机闪烁周期')
		}
	}
	/* 监听：单个被动 mousemove（视差） */
	const mousemoves = windowListeners.filter((l) => l.type === 'mousemove')
	assert.equal(mousemoves.length, 1, '应挂一个视差 mousemove 监听')
	assert.equal(mousemoves[0].options?.passive, true, '视差应为被动监听')
	/* 视差：反向微移，近组位移大于远组（元素桩无 style，验证回调不炸即可） */
	mousemoves[0].handler({ clientX: 1200, clientY: 400 })
	/* 清理：摘监听 + 移除星群 */
	const fieldDisposers = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: star field')
	assert.equal(fieldDisposers.length, 1, '应有一个星群层 effect')
	fieldDisposers[0].dispose()
	assert.equal(windowListeners.filter((l) => l.type === 'mousemove').length, 0, '清理应摘掉视差监听')
	assert.ok(field.removed, '清理应移除星群容器')
}

/* 18. 天降流星：随机节奏排队 + 定时器驱动落星 + 样式随机参 + 清理停节奏清流星 */
{
	styleTags.length = 0
	bgLayers.length = 0
	timers.length = 0
	const disposers = []
	const skyCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(skyCtx, { ...ALL_OFF, background: true, bgAnimation: true })
	/* CSS：天降流星规则挂在背景动效层，沿自身朝向坠落 */
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(css.includes('.xyw-sky-meteor'), '缺少天降流星规则')
	assert.ok(css.includes('@keyframes xyw-sky-fly'), '缺少天降流星动画')
	assert.ok(css.includes('height: 3px') && css.includes('box-shadow: 0 0 10px'), '天降流星应为 3px 光带 + 辉光')
	/* 节奏：初始定时器已排队；驱动一次 → 落一颗 + 再排下一个 */
	assert.equal(timers.length, 1, '应排一个初始落星定时器')
	const skyDisposers = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: sky meteor')
	assert.equal(skyDisposers.length, 1, '应有一个天降流星层 effect')
	timers.pop()()
	assert.equal(bgLayers.length, 2, '定时器触发应在背景层之外再落一颗天降流星')
	assert.equal(bgLayers[0].className, 'xyw-bg-layer', '首个元素应为背景层')
	const meteor = bgLayers[1]
	assert.equal(meteor.className, 'xyw-sky-meteor', '天降流星类名不符')
	assert.ok(/--xyw-sky-rot:\d+(\.\d+)?deg/.test(meteor.style ?? ''), '天降流星缺随机朝向')
	assert.ok(/--xyw-sky-d:\d+(\.\d+)?s/.test(meteor.style ?? ''), '天降流星缺随机时长')
	assert.ok(/width:(1[2-9]\d|2[0-1]\d)px/.test(meteor.style ?? ''), '天降流星长度应在 120-220px')
	assert.ok(/--xyw-meteor-head:rgba\(/.test(meteor.style ?? ''), '天降流星缺随机配色变量（head）')
	assert.ok(/--xyw-meteor-tail:rgba\(/.test(meteor.style ?? ''), '天降流星缺随机配色变量（tail）')
	assert.equal(timers.length, 1, '落星后应再排下一个定时器（保持节奏）')
	/* 清理：停节奏 + 移除现存流星 */
	skyDisposers[0].dispose()
	assert.ok(meteor.removed, '清理应移除现存天降流星')
	timers.pop?.()
}

/* 19. UI 细节打磨：选区高亮/表单点缀色/滚动条/输入聚焦星环/按钮手感（纯 CSS、零 effect 副作用） */
{
	styleTags.length = 0
	windowListeners.length = 0
	bgLayers.length = 0
	const disposers = []
	const polishCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(polishCtx, { ...ALL_OFF, uiPolish: true })
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(css.includes('::selection'), '缺少选区高亮')
	assert.ok(css.includes('accent-color: #B8740F'), '缺少表单点缀色（亮色）')
	assert.ok(css.includes('accent-color: #FFC65C'), '缺少表单点缀色（暗色）')
	assert.ok(css.includes('::-webkit-scrollbar-thumb'), '缺少滚动条精修')
	assert.ok(css.includes('box-shadow: 0 0 0 1px'), '缺少输入聚焦星环')
	assert.ok(css.includes('button:not(:disabled):hover'), '缺少按钮悬浮手感')
	assert.ok(css.includes('translateY(-1px)'), '按钮悬浮应微抬 1px')
	assert.ok(css.includes('button:not(:disabled):active'), '按钮按压应回落')
	assert.ok(css.includes('prefers-reduced-motion'), '缺少减少动效回退')
	assert.ok(css.includes('pre, code'), '缺少代码块边框微光')
	assert.ok(css.includes('blockquote'), '缺少引用块琥珀渐变手札竖线')
	assert.ok(css.includes('details[open]'), '缺少思考折叠区温润微光')
	assert.equal(windowListeners.length, 0, 'UI 细节为纯 CSS，不应挂任何监听')
	assert.equal(bgLayers.length, 0, 'UI 细节不应注入任何元素')
	assert.equal(disposers.length, 1, '应只有布局 CSS 一个 effect')
	assert.equal(disposers[0].label, 'dsh-skin-xuyuanwu: layout css', 'effect 归属应为布局 CSS 层')
}

/* 20. 点击星芒 + 按钮碰星：pointerdown 炸星 + 节流 + 按钮委托碰星 + 非按钮不碰 + 清理摘监听清星 */
{
	styleTags.length = 0
	windowListeners.length = 0
	bgLayers.length = 0
	const disposers = []
	const clickCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(clickCtx, { ...ALL_OFF, clickStar: true })
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(css.includes('.xyw-click-star') && css.includes('.xyw-hover-star'), '缺少点击星芒/按钮碰星规则')
	assert.ok(css.includes('@keyframes xyw-click-pop') && css.includes('@keyframes xyw-hover-pop'), '缺少星芒动画')
	assert.ok(css.includes('prefers-reduced-motion'), '缺少减少动效回退')
	const downs = windowListeners.filter((l) => l.type === 'pointerdown')
	const overs = windowListeners.filter((l) => l.type === 'mouseover')
	assert.equal(downs.length, 1, '应挂一个 pointerdown 监听')
	assert.equal(overs.length, 1, '应挂一个 mouseover 监听')
	assert.ok(downs[0].options?.passive && overs[0].options?.passive, '两个监听都应为被动')
	const onDown = downs[0].handler
	const onOver = overs[0].handler
	/* 点击炸星：落在指针处；节流期内连点不刷屏 */
	onDown({ clientX: 100, clientY: 200 })
	assert.equal(bgLayers.length, 1, '点击应在指针处炸开一颗星')
	const star = bgLayers[0]
	assert.equal(star.className, 'xyw-click-star', '点击星类名不符')
	assert.ok(/left:100px/.test(star.style ?? ''), '点击星应落在指针横坐标')
	assert.ok(/width:(1[4-9]|2[0-2])px/.test(star.style ?? ''), '点击星应为 14-22px 随机尺寸')
	onDown({ clientX: 300, clientY: 400 })
	assert.equal(bgLayers.length, 1, '节流期内连点不应再炸星')
	/* 按钮碰星：mouseover 事件委托 closest 定位按钮；同一按钮短时间重进不重复 */
	bgLayers.length = 0
	const btn = { tagName: 'BUTTON' }
	onOver({ target: { closest: () => btn }, clientX: 40, clientY: 50 })
	assert.equal(bgLayers.length, 1, '划过按钮应碰出一颗小星')
	assert.equal(bgLayers[0].className, 'xyw-hover-star', '碰星类名不符')
	onOver({ target: { closest: () => btn }, clientX: 45, clientY: 55 })
	assert.equal(bgLayers.length, 1, '同一按钮 600ms 内重进不应再碰星')
	onOver({ target: { closest: () => null }, clientX: 60, clientY: 70 })
	onOver({ target: { tagName: 'DIV' }, clientX: 60, clientY: 70 })
	assert.equal(bgLayers.length, 1, '非按钮目标不应碰星')
	/* 清理：摘掉两个监听 + 移除全部星芒 */
	const clickDisposers = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: click star')
	assert.equal(clickDisposers.length, 1, '应有一个点击星芒层 effect')
	clickDisposers[0].dispose()
	assert.equal(windowListeners.filter((l) => l.type === 'pointerdown' || l.type === 'mouseover').length, 0, '清理应摘掉 pointerdown/mouseover 监听')
	assert.ok(bgLayers.every((el) => el.removed), '清理应移除全部星芒')
}

/* 21. 开幕动画：幕布结构 + body 协调类 + animationend 自移除 + 每会话一次 + 清理（独立 VM 实例：会话标记不被前组默认配置消费） */
{
	styleTags.length = 0
	windowListeners.length = 0
	bgLayers.length = 0
	timers.length = 0
	bodyClasses.clear()
	/* 前面的韧性组用 undefined 配置走过默认 bootAnimation: true（会话标记已消费），这里换一个全新 bundle 实例专测开幕 */
	let registeredBoot = null
	const windowBoot = { ...window, __ModuleLoader__: { load: (mod) => { registeredBoot = mod } } }
	runInNewContext(source, { window: windowBoot, document, MutationObserver: MutationObserverStub, requestAnimationFrame, cancelAnimationFrame }, { filename: 'client.js' })
	assert.ok(registeredBoot, 'bundle（开幕实例）未注册进 __ModuleLoader__')
	const exportsBoot = registeredBoot.factory(() => ({ jsx, jsxs, Fragment: 'Fragment' }))
	const disposers = []
	const bootCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exportsBoot.apply(bootCtx, { ...ALL_OFF, bootAnimation: true })
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(css.includes('.xyw-boot'), '缺少幕布规则')
	assert.ok(css.includes('@keyframes xyw-boot-pop') && css.includes('@keyframes xyw-boot-out'), '缺少幕布动画')
	assert.ok(css.includes('@keyframes xyw-boot-streak'), '缺少开幕流星')
	assert.ok(css.includes('body.xyw-booting .xyw-headline'), '缺少揭幕协调（标题推迟）')
	assert.ok(css.includes('body.xyw-booting .xyw-hero-root'), '缺少揭幕协调（徽章推迟）')
	assert.ok(css.includes('prefers-reduced-motion'), '缺少减少动效回退')
	const boot = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: boot sequence')
	assert.equal(boot.length, 1, '应有一个开幕动画层 effect')
	assert.equal(bgLayers.length, 1, '应注入一个幕布元素')
	const veil = bgLayers[0]
	assert.equal(veil.className, 'xyw-boot', '幕布类名不符')
	const veilChildren = veil.children.map((c) => c.className)
	assert.deepEqual(veilChildren, ['xyw-boot-emblem', 'xyw-boot-word', 'xyw-boot-sub', 'xyw-boot-star s1', 'xyw-boot-star s2', 'xyw-boot-star s3', 'xyw-boot-streak'], '幕布分镜结构不符')
	assert.ok(bodyClasses.has('xyw-booting'), '幕布在场应挂 xyw-booting 协调类')
	/* 幕布自身 animationend → 自移除 */
	const veilAnims = veil.listeners.filter((l) => l.type === 'animationend')
	assert.equal(veilAnims.length, 1, '幕布应挂一个 animationend 监听')
	veilAnims[0].handler()
	assert.equal(veil.removed, true, 'animationend 后幕布应自移除')
	/* 每页面会话只演一次：重放 apply 不再有幕布 */
	bgLayers.length = 0
	exportsBoot.apply(bootCtx, { ...ALL_OFF, bootAnimation: true })
	assert.equal(bgLayers.length, 0, '同一会话重放 apply 不应再演开幕')
	/* 清理：摘协调类（含 2.35s 协调定时器兜底） */
	boot[0].dispose()
	assert.equal(bodyClasses.has('xyw-booting'), false, '清理应摘掉 xyw-booting 协调类')
}

/* 22. 点月亮许愿：月轮命中区对齐 + 悬停光环 + 点击流星雨 + 冷却 + 清理 */
{
	styleTags.length = 0
	windowListeners.length = 0
	documentListeners.length = 0
	bgLayers.length = 0
	timers.length = 0
	bodyClasses.clear()
	const disposers = []
	const moonCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(moonCtx, { ...ALL_OFF, background: true, bgMoon: true, moonWish: true })
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(!css.includes('.xyw-moon-hit'), 'v1.8.1 起不允许出现可交互命中区（遮挡按钮的根因）')
	assert.ok(css.includes('.xyw-moon-ring'), '缺少月轮光环（纯装饰）')
	assert.ok(css.includes('pointer-events: none'), '光环必须 pointer-events: none（零占位）')
	assert.ok(css.includes('calc(86% - 189.2px)'), '光环应与绘制月对齐')
	assert.ok(css.includes('.xyw-moon-ring.is-on::after'), '缺少悬停光环点亮规则')
	assert.ok(css.includes('body.xyw-moon-hot'), '缺少手型光标类')
	assert.ok(css.includes('.xyw-rain-meteor') && css.includes('@keyframes xyw-rain-fly'), '缺少流星雨样式')
	assert.ok(css.includes('.xyw-moon-flare') && css.includes('@keyframes xyw-moon-flare'), '缺少月心柔光')
	assert.ok(css.includes('prefers-reduced-motion'), '缺少减少动效回退')
	const moon = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: moon wish')
	assert.equal(moon.length, 1, '应有一个点月亮许愿层 effect')
	/* 零占位：页面上只有背景层 + 纯装饰光环，没有任何可交互元素 */
	assert.equal(bgLayers.length, 2, '应有背景层 + 月轮光环两个元素')
	const ring = bgLayers[1]
	assert.equal(ring.className, 'xyw-moon-ring', '光环类名不符')
	assert.equal(ring['aria-hidden'], 'true', '光环应 aria-hidden')
	/* document 级监听（捕获 click + mousemove + mouseleave） */
	const docClicks = documentListeners.filter((l) => l.type === 'click')
	const docMoves = documentListeners.filter((l) => l.type === 'mousemove')
	const docLeaves = documentListeners.filter((l) => l.type === 'mouseleave')
	assert.equal(docClicks.length, 1, '应挂一个 document click 捕获监听')
	assert.equal(docClicks[0].options, true, 'click 应走捕获阶段（先于应用内 stopPropagation）')
	assert.equal(docMoves.length, 1, '应挂一个 mousemove 监听')
	assert.equal(docLeaves.length, 1, '应挂一个 mouseleave 清场监听')
	const onClick = docClicks[0].handler
	const onMove = docMoves[0].handler
	/* 窗口 1280×800：月心 = (1280×0.86 - 79.2, 800×0.09 + 90.2) = (1021.6, 162.2)，r=102 */
	const plain = { closest: () => null }
	const button = { closest: () => ({ tag: 'button' }) }
	/* 点到真实按钮（即使在月轮内）→ 彩蛋一律让路，按钮照常工作 */
	onClick({ clientX: 1020, clientY: 162, target: button })
	assert.equal(timers.length, 0, '点到真实按钮时绝不触发彩蛋')
	/* 月轮空白处点击 → 月心柔光立即爆 + 5 颗流星错峰排队 */
	onClick({ clientX: 1020, clientY: 162, target: plain })
	const flare = bgLayers.find((el) => el.className === 'xyw-moon-flare')
	assert.ok(flare, '点击月轮应立即爆一圈月心柔光')
	assert.equal(timers.length, 5, '应为 5 颗流星排错峰定时器')
	for (const fn of [...timers]) fn()
	const meteors = bgLayers.filter((el) => el.className === 'xyw-rain-meteor')
	assert.equal(meteors.length, 5, '放行定时器应落 5 颗流星雨')
	assert.ok(meteors.every((el) => /--xyw-meteor-head:/.test(el.style ?? '')), '流星雨应带随机配色变量')
	/* 月轮外空白点击 → 不触发 */
	timers.length = 0
	onClick({ clientX: 300, clientY: 500, target: plain })
	assert.equal(timers.length, 0, '月轮外点击不应触发')
	/* 冷却期内连点不再落雨 */
	onClick({ clientX: 1020, clientY: 162, target: plain })
	assert.equal(timers.length, 0, '2.5s 冷却期内连点不应再落雨')
	/* 悬停月轮空白 → 光环点亮 + 手型光标；悬停按钮 → 让路 */
	onMove({ clientX: 1020, clientY: 162, target: plain })
	assert.ok(ring.classList.contains('is-on'), '悬停月轮应点亮光环')
	assert.ok(bodyClasses.has('xyw-moon-hot'), '悬停月轮应挂手型光标类')
	onMove({ clientX: 1020, clientY: 162, target: button })
	assert.equal(bodyClasses.has('xyw-moon-hot'), false, '悬停真实按钮应摘掉手型光标类')
	onMove({ clientX: 300, clientY: 500, target: plain })
	assert.equal(bodyClasses.has('xyw-moon-hot'), false, '离开月轮应摘掉手型光标类')
	/* 清理：摘监听 + 摘光环 + 清流星 */
	const listenerCount = documentListeners.length
	moon[0].dispose()
	assert.equal(documentListeners.length, listenerCount - 3, '清理应摘掉三个 document 监听')
	assert.equal(ring.removed, true, '清理应移除光环')
	assert.ok(meteors.every((el) => el.removed), '清理应移除全部流星雨')
	assert.equal(bodyClasses.has('xyw-moon-hot'), false, '清理应摘掉手型光标类')
}

/* 23. 月相呼吸：静态月让位 + 专属画布 + 余弦往返盈亏（拨钟驱动）+ 页面隐藏跳过 + 清理 */
{
	styleTags.length = 0
	bgLayers.length = 0
	intervals.length = 0
	const disposers = []
	const cycleCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(cycleCtx, { ...ALL_OFF, background: true, bgMoon: true, moonCycle: true })
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(css.includes('.xyw-moon-cycle'), '缺少月相呼吸画布规则')
	assert.ok(css.includes('calc(86% - 189.2px)'), '月画布应与原静态月位置严格对齐')
	assert.ok(css.includes('pointer-events: none'), '月画布应零交互')
	assert.ok(css.includes('220px 220px'), '月画布应有月相尺寸')
	/* 静态月让位：背景层不再叠第三层月相 data URI（月由专属画布逐帧重绘） */
	assert.ok(!css.includes('r%3D%22100%22'), 'moonCycle 开时背景层不应再叠静态月')
	assert.ok(!css.includes('background-position: 480px 480px, 0 0, 86% 9%'), '缓漂关键帧不应带月相层坐标')
	/* 元素：背景层 + 月画布；节拍 ≤250ms 平滑重绘 */
	assert.equal(bgLayers.length, 2, '应有背景层 + 月画布两个元素')
	const moonEl = bgLayers[1]
	assert.equal(moonEl.className, 'xyw-moon-cycle', '月画布类名不符')
	assert.equal(intervals.length, 1, '应有一个重绘节拍')
	assert.ok(intervals[0].ms <= 250, '重绘节拍应足够平滑（≤250ms）')
	assert.ok((moonEl.style ?? '').includes('url("data:image/svg+xml,'), '初始应绘出今日月')
	const firstStyle = moonEl.style
	/* 拨快时钟：1/4 轮 → 盈月途中；半轮 → 满月；整轮 → 亏回今日月相 */
	const tick = () => intervals[0].fn()
	fakeNowMs += 24000
	tick()
	const quarterStyle = moonEl.style
	assert.notEqual(quarterStyle, firstStyle, '盈月途中月相应变化')
	fakeNowMs += 24000
	tick()
	assert.notEqual(moonEl.style, quarterStyle, '满月月相应再变化')
	fakeNowMs += 48000
	tick()
	assert.equal(moonEl.style, firstStyle, '一轮后应亏回今日月相（与起点同图）')
	/* 页面隐藏时跳过重绘 */
	document.hidden = true
	fakeNowMs += 24000
	tick()
	assert.equal(moonEl.style, firstStyle, '页面隐藏时应跳过重绘')
	document.hidden = false
	/* 清理：停节拍 + 移除月画布 */
	const cycle = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: moon cycle')
	assert.equal(cycle.length, 1, '应有一个月相呼吸层 effect')
	cycle[0].dispose()
	assert.ok(intervals[0].cleared, '清理应停掉重绘节拍')
	assert.equal(moonEl.removed, true, '清理应移除月画布')
}

/* 24. 月亮轨迹：正弦摆动（起点零偏移 → 1/4 轮有界非零 → 整轮归零）+ 清理 */
{
	styleTags.length = 0
	bgLayers.length = 0
	intervals.length = 0
	const disposers = []
	const orbitCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(orbitCtx, { ...ALL_OFF, background: true, bgMoon: true, moonCycle: true, moonOrbit: true })
	const moonEl = bgLayers.find((el) => el.className === 'xyw-moon-cycle')
	assert.ok(moonEl, '月亮轨迹需要月相画布')
	assert.ok((moonEl.style ?? '').includes('transform:translate(0px, 0px)'), '轨迹起点偏移应为零')
	const tick = () => intervals[intervals.length - 1].fn()
	fakeNowMs += 45000
	tick()
	const quarter = moonEl.style
	assert.ok(quarter.includes('transform:translate(') && !quarter.includes('translate(0px, 0px)'), '1/4 轮时偏移应非零')
	const m = quarter.match(/translate\((-?[\d.]+)px, (-?[\d.]+)px\)/)
	assert.ok(m, '轨迹偏移应可解析')
	assert.ok(Math.abs(parseFloat(m[1])) <= 100.01 && Math.abs(parseFloat(m[2])) <= 18.01, '轨迹振幅应有界（水平 ±100px / 垂直 ±18px）')
	fakeNowMs += 135000
	tick()
	assert.ok(moonEl.style.includes('transform:translate(0px, 0px)'), '整轮后应回到起点偏移')
	const orbit = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: moon cycle')
	assert.equal(orbit.length, 1, '应有一个月相层 effect')
	orbit[0].dispose()
	assert.equal(moonEl.removed, true, '清理应移除月画布')
	assert.ok(intervals[intervals.length - 1].cleared, '清理应停掉重绘节拍')
}

/* 25. 挑灯织光：AI 思考流式窗灯快频呼吸 + 结束散开达成星芒 + 清理 */
{
	styleTags.length = 0
	bgLayers.length = 0
	bodyClasses.clear()
	const disposers = []
	const observersBefore = observers.length
	const weaveCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(weaveCtx, { ...ALL_OFF, weavingLight: true })
	/* CSS：织光窗灯呼吸规则 + 星芒达成动画 */
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(css.includes('body.xyw-ai-weaving .xyw-hero-window'), '缺少挑灯织光窗灯呼吸规则')
	assert.ok(css.includes('@keyframes xyw-weaving-window'), '缺少挑灯织光窗灯动画')
	assert.ok(css.includes('.xyw-star-fulfilled'), '缺少愿望达成星芒样式')
	assert.ok(css.includes('@keyframes xyw-star-fulfill'), '缺少愿望达成星芒动画')
	const weave = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: weaving light')
	assert.equal(weave.length, 1, '应有一个挑灯织光层 effect')
	assert.equal(observers.length, observersBefore + 1, '应挂一个 MutationObserver 监听流式状态')
	const observer = observers[observers.length - 1]
	/* 模拟流式生成开始：document.querySelector 命中 streaming/stopBtn */
	const origQuerySelector = document.querySelector
	document.querySelector = (sel) => sel.includes('streaming') ? { streaming: true } : null
	observer.callback()
	assert.equal(rafQueue.length, 1, '状态检测应调度一帧')
	rafQueue.pop()()
	assert.ok(bodyClasses.has('xyw-ai-weaving'), '流式生成时应挂 xyw-ai-weaving 呼吸类')
	/* 模拟流式生成结束：解除命中 → 摘呼吸类 + 散开达成星芒 */
	document.querySelector = () => null
	observer.callback()
	rafQueue.pop()()
	assert.equal(bodyClasses.has('xyw-ai-weaving'), false, '流式结束应摘掉 xyw-ai-weaving 类')
	const fulfilled = bgLayers.find((el) => el.className === 'xyw-star-fulfilled')
	assert.ok(fulfilled, '流式结束应弹散一颗达成星芒')
	assert.ok(fulfilled.innerHTML.includes('<svg'), '达成星芒应包含 SVG 辉光星点')
	document.querySelector = origQuerySelector
	/* 清理：断开 observer + 摘呼吸类 + 移除星芒 */
	weave[0].dispose()
	assert.equal(observer.disconnected, true, '清理应断开 observer')
	assert.equal(bodyClasses.has('xyw-ai-weaving'), false, '清理应摘掉呼吸类')
	assert.equal(fulfilled.removed, true, '清理应移除达成星芒')
}

/* 26. 字落生辉：输入打字金色萤火微尘 + 节流与池上限 + 非输入不误触 + reduced-motion 回退 + 清理 */
{
	styleTags.length = 0
	bgLayers.length = 0
	documentListeners.length = 0
	const disposers = []
	const typingCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(typingCtx, { ...ALL_OFF, typingSparks: true })
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(css.includes('.xyw-typing-spark'), '缺少打字萤火微尘规则')
	assert.ok(css.includes('@keyframes xyw-typing-spark-drift'), '缺少萤火飘散动画')
	assert.ok(css.includes('prefers-reduced-motion'), '缺少减少动效回退')
	const typing = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: typing sparks')
	assert.equal(typing.length, 1, '应有一个字落生辉层 effect')
	const inputListeners = documentListeners.filter((l) => l.type === 'input')
	assert.equal(inputListeners.length, 1, '应挂一个 document input 被动监听')
	assert.equal(inputListeners[0].options?.passive, true, 'input 应为被动监听')
	const onInput = inputListeners[0].handler
	const textarea = { tagName: 'TEXTAREA', getBoundingClientRect: () => ({ left: 200, top: 400, width: 400, height: 60 }) }
	/* 输入框打字 → 冒出金色萤火微尘 */
	onInput({ target: textarea })
	assert.equal(bgLayers.length, 1, '输入打字应冒出一颗萤火微尘')
	const spark = bgLayers[0]
	assert.equal(spark.className, 'xyw-typing-spark', '萤火类名不符')
	assert.ok((spark.style ?? '').includes('--xyw-spark-dx:'), '萤火微尘缺微移变量')
	/* 90ms 节流期内连续输入不重复刷屏 */
	onInput({ target: textarea })
	assert.equal(bgLayers.length, 1, '90ms 节流期内不应连发萤火')
	/* 输入法组词 / 非输入框不触发 */
	fakeNowMs += 100
	onInput({ target: textarea, isComposing: true })
	assert.equal(bgLayers.length, 1, '输入法组词中不应冒萤火')
	onInput({ target: { tagName: 'DIV' } })
	assert.equal(bgLayers.length, 1, '非输入元素不应冒萤火')
	/* 清理：摘监听 + 移除现存萤火 */
	typing[0].dispose()
	assert.equal(documentListeners.filter((l) => l.type === 'input').length, 0, '清理应摘掉 input 监听')
	assert.equal(spark.removed, true, '清理应移除现存萤火微尘')
}

/* 27. 纯原生合成音效：Web Audio 纯算法生成（零外部资源）+ 容错不崩 + 清理 */
{
	const disposers = []
	const soundCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	/* 1. Node.js 无 AudioContext 环境下安全无害 */
	exports.apply(soundCtx, { ...ALL_OFF, sound: true })
	const sound = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: sound system')
	assert.equal(sound.length, 1, '应有一个音效系统 effect')
	/* 2. 模拟真实浏览器 Web Audio 环境验证音色与和弦参数 */
	let closed = false
	const oscs = []
	class MockOscillator {
		constructor() {
			this.type = ''
			this.frequency = {
				setValueAtTime: (f) => { this.freq = f },
				exponentialRampToValueAtTime: () => {},
			}
		}
		connect() {}
		start() {}
		stop() {}
	}
	class MockGain {
		constructor() {
			this.gain = {
				setValueAtTime: () => {},
				linearRampToValueAtTime: () => {},
				exponentialRampToValueAtTime: () => {},
			}
		}
		connect() {}
	}
	const origAudio = window.AudioContext
	window.AudioContext = class {
		constructor() {
			this.state = 'suspended'
			this.currentTime = 0
			this.destination = {}
		}
		async resume() { this.state = 'running' }
		createOscillator() { const o = new MockOscillator(); oscs.push(o); return o }
		createGain() { return new MockGain() }
		close() { closed = true }
	}
	try {
		sound[0].dispose()
		/* 重新 apply 挂载并触发风铃音效 */
		const disposers2 = []
		soundCtx.effect = (execute, label) => { disposers2.push({ label, dispose: execute() }) }
		exports.apply(soundCtx, { ...ALL_OFF, sound: true, moonWish: true, background: true, bgMoon: true })
		/* 模拟点月亮触发 playChime */
		const docClicks = documentListeners.filter((l) => l.type === 'click')
		if (docClicks.length > 0) {
			docClicks[0].handler({ clientX: 1020, clientY: 162, target: { closest: () => null } })
			assert.ok(oscs.length >= 4, '水晶风铃音应由 4 个五声音阶正弦波振荡器叠泛音合成')
			const freqs = oscs.map((o) => o.freq)
			assert.deepEqual(freqs, [1318.51, 1567.98, 1975.53, 2637.02], '风铃和弦音高应为 E6/G6/B6/E7 空灵五度')
		}
		disposers2.forEach((d) => d.dispose?.())
		assert.equal(closed, true, '清理应关闭 AudioContext')
	} finally {
		delete window.AudioContext
		if (origAudio) window.AudioContext = origAudio
	}
}

/* 28. 现实时辰昼夜联动：深夜（23-05点）增强辉光 + 薄暮（17-19点）暖霞光晕 + 定时轮询 + 清理 */
{
	styleTags.length = 0
	bodyClasses.clear()
	intervals.length = 0
	const disposers = []
	const timeCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(timeCtx, { ...ALL_OFF, timeAmbience: true })
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(css.includes('body.xyw-deep-night .xyw-hero-window'), '缺少深夜窗灯增强辉光规则')
	assert.ok(css.includes('body.xyw-deep-night .xyw-hero-lantern-glow'), '缺少深夜灯笼光晕增强规则')
	assert.ok(css.includes('body.xyw-dusk .xyw-bg-layer'), '缺少薄暮晚霞色温滤镜规则')
	const timeEffect = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: time ambience')
	assert.equal(timeEffect.length, 1, '应有一个时辰氛围 effect')
	assert.equal(intervals.length, 1, '应有一个 60s 轮询定时器')
	assert.equal(intervals[0].ms, 60000, '轮询间隔应为 60000ms')
	const tick = intervals[0].fn
	const origFakeNow = fakeNowMs
	try {
		/* 拨时钟到深夜 23:30 */
		fakeNowMs = new Date('2026-09-15T23:30:00').getTime()
		tick()
		assert.ok(bodyClasses.has('xyw-deep-night'), '深夜时辰应挂 xyw-deep-night 类')
		assert.equal(bodyClasses.has('xyw-dusk'), false, '深夜不应挂薄暮类')
		/* 拨到傍晚薄暮 17:30 */
		fakeNowMs = new Date('2026-09-15T17:30:00').getTime()
		tick()
		assert.equal(bodyClasses.has('xyw-deep-night'), false, '薄暮不应挂深夜类')
		assert.ok(bodyClasses.has('xyw-dusk'), '薄暮时辰应挂 xyw-dusk 类')
		/* 拨到正午 12:00 */
		fakeNowMs = new Date('2026-09-15T12:00:00').getTime()
		tick()
		assert.equal(bodyClasses.has('xyw-deep-night'), false, '白天不应挂深夜类')
		assert.equal(bodyClasses.has('xyw-dusk'), false, '白天不应挂薄暮类')
	} finally {
		fakeNowMs = origFakeNow
	}
	/* 清理：停定时器 + 摘时辰类 */
	timeEffect[0].dispose()
	assert.ok(intervals[0].cleared, '清理应停掉轮询定时器')
	assert.equal(bodyClasses.has('xyw-deep-night'), false, '清理应摘掉深夜类')
	assert.equal(bodyClasses.has('xyw-dusk'), false, '清理应摘掉薄暮类')
}

/* 29. 小屋彩蛋每日许愿签：点击木牌/双击徽章弹签 + 宣纸古风 Toast + 点击收起 + 冷却 + 清理 */
{
	styleTags.length = 0
	bgLayers.length = 0
	documentListeners.length = 0
	timers.length = 0
	const disposers = []
	const fortuneCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	exports.apply(fortuneCtx, { ...ALL_OFF, wishFortune: true })
	const css = styleTags[0]?.textContent ?? ''
	assert.ok(css.includes('.xyw-fortune-toast'), '缺少许愿签 Toast 样式')
	assert.ok(css.includes('@keyframes xyw-fortune-in'), '缺少签语入场动画')
	assert.ok(css.includes('@keyframes xyw-fortune-out'), '缺少签语离场动画')
	assert.ok(css.includes('STKaiti'), '许愿签应使用传统手札楷体')
	const fortuneEffect = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: wish fortune')
	assert.equal(fortuneEffect.length, 1, '应有一个每日许愿签 effect')
	const clicks = documentListeners.filter((l) => l.type === 'click')
	const dblclicks = documentListeners.filter((l) => l.type === 'dblclick')
	assert.equal(clicks.length, 1, '应挂一个 click 捕获监听')
	assert.equal(dblclicks.length, 1, '应挂一个 dblclick 捕获监听')
	/* 点击「有求必应」木牌 → 弹出手作宣纸签语 Toast */
	const onClick = clicks[0].handler
	const brandSubTarget = {
		closest: (sel) => sel === '.xyw-brand-sub' ? { className: 'xyw-brand-sub' } : null,
	}
	onClick({ target: brandSubTarget })
	assert.equal(bgLayers.length, 1, '点击木牌应弹出一个许愿签 Toast')
	const toast = bgLayers[0]
	assert.equal(toast.className, 'xyw-fortune-toast', '签语 Toast 类名不符')
	assert.ok(toast.innerHTML.includes('许 愿 签'), 'Toast 必须有「许 愿 签」眉题')
	assert.ok(toast.innerHTML.includes('xyw-fortune-text'), 'Toast 必须包含签语诗句正文')
	/* 1.2s 冷却防连点刷屏 */
	onClick({ target: brandSubTarget })
	assert.equal(bgLayers.length, 1, '冷却期内连点不应重复刷签')
	/* 模拟点击 Toast 手动收起 */
	const toastClickListeners = toast.listeners.filter((l) => l.type === 'click')
	assert.equal(toastClickListeners.length, 1, 'Toast 应挂 click 点击收起监听')
	toastClickListeners[0].handler()
	assert.ok(toast.classList.contains('is-leaving'), '点击 Toast 应播放离场动画 is-leaving')
	/* 双击徽章亦可抽签 */
	bgLayers.length = 0
	fakeNowMs += 2000
	const onDblClick = dblclicks[0].handler
	const heroTarget = { closest: (sel) => sel === '.xyw-hero-root' ? { className: 'xyw-hero-root' } : null }
	onDblClick({ target: heroTarget })
	assert.equal(bgLayers.length, 1, '双击首屏徽章亦应弹出许愿签')
	/* 清理：摘监听 + 移除现存 Toast */
	fortuneEffect[0].dispose()
	assert.equal(documentListeners.filter((l) => l.type === 'click' || l.type === 'dblclick').length, 0, '清理应摘掉 click/dblclick 监听')
	assert.equal(bgLayers[0].removed, true, '清理应移除现存 Toast')
}

/* 30. 快捷手札面板：触发打开 + 8项开关控制 + 实时持久化 localStorage + 重置 + 清理 */
{
	styleTags.length = 0
	bgLayers.length = 0
	documentListeners.length = 0
	const disposers = []
	const panelCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	/* 模拟 localStorage */
	const storage = {}
	window.localStorage = {
		getItem: (k) => storage[k] ?? null,
		setItem: (k, v) => { storage[k] = String(v) },
		removeItem: (k) => { delete storage[k] },
	}
	try {
		exports.apply(panelCtx, { ...ALL_OFF, quickPanel: true })
		const css = styleTags[0]?.textContent ?? ''
		assert.ok(css.includes('.xyw-panel-overlay'), '缺少手札面板遮罩样式')
		assert.ok(css.includes('.xyw-panel-modal'), '缺少手札面板卡片样式')
		assert.ok(css.includes('@keyframes xyw-panel-fadein'), '缺少手札遮罩动画')
		assert.ok(css.includes('@keyframes xyw-panel-scalein'), '缺少手札卡片动画')
		const panelEffect = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: quick panel')
		assert.equal(panelEffect.length, 1, '应有一个快捷手札面板 effect')
		const clicks = documentListeners.filter((l) => l.type === 'click')
		const customOpens = documentListeners.filter((l) => l.type === 'xyw-open-panel')
		assert.equal(clicks.length, 1, '应挂一个 click 捕获监听用于唤出面板')
		assert.equal(customOpens.length, 1, '应挂一个 xyw-open-panel 自定义事件')
		/* 点击侧栏字标星标触发 openPanel */
		const onClick = clicks[0].handler
		const triggerTarget = {
			closest: (sel) => sel === '.xyw-settings-trigger' ? { className: 'xyw-settings-trigger' } : null,
		}
		onClick({ target: triggerTarget, preventDefault: () => {}, stopPropagation: () => {} })
		assert.equal(bgLayers.length, 1, '点击设置触发区应打开手札面板')
		const overlay = bgLayers[0]
		assert.equal(overlay.className, 'xyw-panel-overlay', '面板遮罩类名不符')
		assert.ok(overlay.innerHTML.includes('许愿屋手札'), '面板应有「许愿屋手札」标题')
		/* 检查 8 个功能开关复选框 */
		const boxes = overlay.querySelectorAll('input[type="checkbox"]')
		assert.equal(boxes.length, 8, '手札面板应提供 8 个核心功能实时开关')
		/* 修改音效开关 → 实时保存到 localStorage */
		const soundBox = boxes.find((b) => b.getAttribute('data-key') === 'sound')
		assert.ok(soundBox, '缺少 sound 复选框')
		soundBox.checked = true
		const changeListener = soundBox.listeners.find((l) => l.type === 'change')
		assert.ok(changeListener, '复选框应绑定 change 监听')
		changeListener.handler({ target: soundBox })
		assert.ok(storage['dsh_skin_xuyuanwu_config'], '勾选应立刻写进 localStorage')
		const savedCfg = JSON.parse(storage['dsh_skin_xuyuanwu_config'])
		assert.equal(savedCfg.sound, true, 'localStorage 中的 sound 配置应为 true')
		/* 点击重置按钮 → 清空 localStorage */
		const resetBtn = overlay.querySelector('.xyw-panel-reset')
		assert.ok(resetBtn, '面板应有重置按钮')
		const resetListener = resetBtn.listeners.find((l) => l.type === 'click')
		assert.ok(resetListener, '重置按钮应绑定 click 监听')
		resetListener.handler()
		assert.equal(storage['dsh_skin_xuyuanwu_config'], undefined, '重置按钮应清除 localStorage 存储')
		/* 清理：摘监听 + 移除面板 */
		panelEffect[0].dispose()
		assert.equal(documentListeners.filter((l) => l.type === 'click' || l.type === 'xyw-open-panel').length, 0, '清理应摘掉监听')
	} finally {
		delete window.localStorage
	}
}

/* 31. 智能低电量节能：Battery API 状态监听 + 未插电低电量环保降频 + 状态恢复 + 清理 */
{
	styleTags.length = 0
	bodyClasses.clear()
	const disposers = []
	const ecoCtx = {
		theme: { overrideTokens: () => () => {} },
		slots: { inject: () => () => {}, register: () => () => {} },
		effect: (execute, label) => { disposers.push({ label, dispose: execute() }) },
	}
	let batteryListeners = []
	const batteryMock = {
		charging: false,
		level: 0.18,
		addEventListener: (type, handler) => batteryListeners.push({ type, handler }),
	}
	navigator.getBattery = () => Promise.resolve(batteryMock)
	try {
		exports.apply(ecoCtx, { ...ALL_OFF, ecoMode: true })
		const css = styleTags[0]?.textContent ?? ''
		assert.ok(css.includes('body.xyw-eco-mode .xyw-hero-root'), '缺少节能模式徽章滤镜降耗规则')
		assert.ok(css.includes('body.xyw-eco-mode .xyw-field-star'), '缺少节能模式星点动画停用规则')
		const ecoEffect = disposers.filter((d) => d.label === 'dsh-skin-xuyuanwu: eco mode')
		assert.equal(ecoEffect.length, 1, '应有一个节能感知 effect')
		/* 等待 Promise.resolve 微任务完成电池状态读取 */
		await Promise.resolve()
		assert.ok(bodyClasses.has('xyw-eco-mode'), '未接电源且电量 ≤25% 应激活 xyw-eco-mode')
		/* 插上电源 → 退出节能模式 */
		batteryMock.charging = true
		const chargingHandler = batteryListeners.find((l) => l.type === 'chargingchange')?.handler
		chargingHandler?.()
		assert.equal(bodyClasses.has('xyw-eco-mode'), false, '接入电源应退出 xyw-eco-mode')
		/* 拔掉电源且电量充足（80%）→ 保持普通模式 */
		batteryMock.charging = false
		batteryMock.level = 0.8
		chargingHandler?.()
		assert.equal(bodyClasses.has('xyw-eco-mode'), false, '电量充足时不应激活节能模式')
		/* 清理：移除 xyw-eco-mode 类名 */
		ecoEffect[0].dispose()
		assert.equal(bodyClasses.has('xyw-eco-mode'), false, '清理应摘掉 xyw-eco-mode 类')
	} finally {
		delete navigator.getBattery
	}
}

console.log('✓ smoke: 31 组断言全部通过')
