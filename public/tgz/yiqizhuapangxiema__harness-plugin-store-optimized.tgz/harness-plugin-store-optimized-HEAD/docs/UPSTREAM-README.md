# 原始 README（上游 dsh-plugin-hub 0.1.6）

# dsh-plugin-hub — DeepSeek Harness 插件商店

一个深度集成于 **Harness Web UI** 的图形化插件商店：在原生界面中浏览、搜索、一键安装
GitHub 上的 DSH 插件（来源限定为标记 `topic: dsh-plugin` 或 `#dsh-plugin` 的仓库），
并内置本地评分评论、依赖拓扑评估、操作审计日志与插件开发脚手架引导。

## 预览

**商店主界面**：12 类分类筛选、卡片式列表、信任徽章、下载来源标注、一键安装
![商店主界面](./docs/screenshots/01-discover.jpg)

**健康度排行榜**：Top 20 健康指数每日随镜像同步更新，前三名金/银/铜
![健康度排行榜](./docs/screenshots/02-health-leaderboard.jpg)

**详情页健康度 + 动态趋势图**：评分构成条 + 金色版本发布线 + 蓝色 npm 每日真实下载量折线
![详情页健康度与趋势图](./docs/screenshots/03-detail-health-trend.jpg)

**GitHub 讨论区**：只读展示该插件仓库的 issue 讨论，一键跳转参与
![GitHub 讨论区](./docs/screenshots/04-github-discussions.jpg)

## 功能总览

| 功能 | 说明 |
| --- | --- |
| 主界面入口按钮 | 侧边栏底部「插件商店」按钮，与常规功能按钮同尺寸（宽 34px / 窄栏 36px 圆形） |
| 图形化商店 | 卡片式列表：图标、名称、简介、开发者、评分、下载量；支持按 工具 / Agent / UI / 数据处理 分类筛选，按名称或描述关键词搜索，按评分 / 下载量 / 最近更新排序 |
| 插件详情页 | 完整 README、使用说明、版本历史（GitHub Releases）、依赖信息、截图；一键安装 / 卸载 / 启用 / 禁用，全程无需命令行 |
| GitHub Token 配置 | 设置页提供私人 Token 配置入口，缓解 GitHub API 限频（匿名搜索 10/min → 30/min，核心 60/h → 5000/h） |
| 定时镜像同步 | 定期将 `topic:dsh-plugin` / `#dsh-plugin` 仓库元数据同步至本地 SQLite 数据库（`$DSH_HOME/storages/plugin-store/`），搜索加载不受网络与限频影响；支持手动「立即同步」 |
| 本地评分与评论 | 企业内部用户可对插件 1-5 星打分并撰写使用反馈，与 GitHub 数据互补形成内部口碑（仅本机/本企业可见） |
| 依赖拓扑图 | 详情页可视化展示该插件依赖的底层库（红色入边）与被哪些上层插件依赖（蓝色出边），辅助卸载前评估影响范围 |
| 操作审计日志 | 完整记录谁在什么时间执行了安装、卸载、启用、禁用、评分、Token 配置、镜像同步等操作，可筛选查询，满足企业合规要求 |
| 插件开发脚手架 | 商店内置开发引导入口：插件结构说明、模板与官方文档链接、脚手架命令一键复制，鼓励内部开发者创建插件并打上 `dsh-plugin` 标签回馈生态 |
| 已安装插件管理 | 「已安装插件」页全新管理界面：系统插件 / 下载插件 / 自创作插件 三大分类，子分组折叠，switch 开关一键启用/禁用（无需卸载），分类级「全部启用 / 全部禁用」，核心组件（18 项基础设施）锁定保护防止误操作 |
| 自创作插件识别 | 本地安装（`file:` / `link:` / `workspace:`）的插件自动归入「自创作插件」分类（含改造他人的插件），显示本地源码路径与发布状态徽章（📦 已发布可跳转 npm/仓库 / 📝 未发布）；商店自身同样可在此管理并卸载 |
| 质量门（Quality Gate） | 安装前两道静态检查，从源头防止"装上就崩"：① 依赖完整性——扫描入口代码引用的外部模块，未声明且非平台提供（node: / @deepseek-ai/* 白名单）则拦截并自动回滚；② 目录需求——识别插件启动时读取的目录（如 `~/.codex/pets`），缺失则安装但保持禁用并明确提示创建目录 |
| 一键发布插件 | 「发布」页一键将本地自创作插件发布到 GitHub 仓库（建仓 + 推送代码 + topics + Release）与 / 或 npm：Markdown 图文介绍、公开 / 私人、标签选择，全程进度条；令牌会话级使用不落盘 |
| 发布安全扫描 | 发布前静态扫描生命周期脚本与源码：远程下载执行、环境变量外传、恶意依赖等 8 类高风险直接驳回，可疑项标注警告，杜绝恶意插件上线 |
| 下载来源标注 | 卡片与详情页显示「npm 直装」（绿）或「GitHub 源码」（红）徽标，明确告知安装是否需要代理 |
| 插件百科库 | 「百科」页 + 详情页百科 tab：自动提炼"能干什么 / 价值在哪 / 怎么用 / 最佳实践"，回答"这个插件有什么用"；接入 Blue-Whale 目录后覆盖 1900+ 条目；安装交给商店一键完成 |
| 健康度排行榜 | Top 20 插件健康指数（活跃度 / 发布渠道 / Bug 信号 / 社区规模 / 版本节奏），每日随镜像同步更新；详情页附评分构成与版本 / 下载 / 提交 / 加星动态趋势图（SVG 可缩放拖拽） |
| 信任徽章 | 对接 dsh-hub-index：🏅 官方 / ✅ 认证 / 👥 社区 / ⚪ 未审核 四层信任标记，数据落库缓存、源不可用自动降级 |
| 安装安全与性能 | 装前质量门（依赖完整性）+ 冲突检查（槽位 / 激活补丁 / 依赖版本，被拦自动回滚）+ 已安装列表缓存与评分批量查询（L1 性能优化）；版本更新检测 + 已安装归属校验 |

## 架构

- **Host 端**（Node / Cordis）：`lib/host/` — `PluginStoreService` 以
  Typert Remote（`pluginStore` 命名空间）暴露 17 个远程方法；`store-db.ts` 使用
  `node:sqlite` 持久化；`github.ts` 负责 GitHub 搜索与镜像同步；`installer.ts`
  通过 pnpm 完成安装/卸载，并写入 profile 的 `cordis.patch.yml`，由 Cordis HMR
  热加载生效（无需重启）。
- **Client 端**（React / 浏览器）：`lib/client.js` — 单文件 bundle，注册
  `sidebar.footer.action` 入口按钮与 `settings.section` 设置页，商店主体为
  portal 覆盖层，视觉与原生设置对话框一致（复用 `--dsw-*` 主题变量）。
- **契约**：`lib/contracts/remote.js` — zod v4 共享 wire 契约，同时导出
  `TYPERT_REMOTE`（客户端挂载）与 `TYPERT`（host 端注册）。

## 安装

```bash
# 方式一：npm 已发布，直接安装（推荐）
dsh plugin --profile web add dsh-plugin-hub

# 方式二：本地构建后安装（开发调试用，需要 node >= 22.19 与 pnpm）
pnpm install
pnpm build        # 产出 lib/host/*.js 与 lib/client.js
dsh plugin --profile web add <本包目录>
```

安装后侧边栏底部会出现「插件商店」按钮。首次使用请先在商店「设置」页点击
「立即同步」，将 GitHub 上的 dsh-plugin 仓库镜像到本地数据库。

## 开发

```bash
pnpm build:host   # tsc 编译 host 端
pnpm build:client # esbuild 打包 client bundle
pnpm typecheck
```

## 目录

```
src/
  contracts/remote.ts   # zod 共享契约（TYPERT_REMOTE / TYPERT）
  host/
    index.ts            # PluginStoreService（Typert Remote 服务 + 定时同步）
    store-db.ts         # SQLite 本地数据库（镜像缓存 / 评分 / 审计）
    github.ts           # GitHub 搜索 + 镜像同步管道
    installer.ts        # pnpm 安装/卸载 + profile 补丁热加载
    quality-gate.ts     # 质量门：依赖完整性 + 启动目录需求检查
  client/
    index.tsx           # 入口注册（按钮 / 设置页 / locale）
    StoreApp.tsx        # 商店模态框外壳
    views.tsx           # 发现 / 详情 / 已安装 / 设置 / 审计 / 脚手架
    graph.tsx           # 依赖拓扑 SVG
    markdown.tsx        # 轻量 markdown 渲染
    settings-section.tsx# 原生设置页（Token / 镜像）
    store.css           # 样式（--dsw-* 主题变量）
```

## 许可

MIT
