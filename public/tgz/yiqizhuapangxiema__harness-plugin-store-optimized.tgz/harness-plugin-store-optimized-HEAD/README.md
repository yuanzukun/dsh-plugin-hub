# Harness Plugin Store Optimized

**简介**：本仓库是 [dsh-plugin-hub](https://github.com/yunhuantian/dsh-plugin-hub) 0.1.6 的定制优化版。

- **继承原版全部功能**：深度集成 Harness Web UI 的图形化插件商店 —— 浏览 / 搜索 / 一键安装、本地评分评论、依赖拓扑图、操作审计日志、插件开发脚手架、安装前质量门与安全扫描、健康度排行榜、信任徽章
- **本 fork 的修改优化**：插件下载目录可配置（默认 `<DSH_HOME>/plugins`，插件以源码文件夹落盘并自动注册部署）、bundle 层入口 id 冲突检测（安装前拦截会导致整树崩溃的插件）、pnpm 自动寻路（任意终端可用）、准确的"重启生效"提示、启用超时透传真实错误、scoped 包支持，以及 3 项上游 bug 修复

## 下载与安装

**前置条件**：官方 `dsh` CLI（`npm install -g @deepseek-ai/dsh`）、`pnpm` 10+（不在 PATH 上也没关系，商店安装插件时会自动寻找 harness 本地的 pnpm shim）。

### 方式一：克隆本仓库安装（推荐，替换 registry 版）

```bash
git clone https://github.com/yiqizhuapangxiema/harness-plugin-store-optimized.git
cd harness-plugin-store-optimized
dsh plugin --profile web add file:<本仓库绝对路径>
```

profile 的依赖规格会变成 `file:` 指向本仓库，重启 dsh web 后生效（浏览器 Ctrl+F5 刷新）。

### 方式二：npm 安装（发布后可用）

```bash
dsh plugin --profile web add dsh-plugin-store-optimized
```

> npm 包 `dsh-plugin-store-optimized` 尚未发布；发布后此命令即可用。

### 方式三：给已装的 registry 版打补丁

```bash
cd <DSH_HOME>/profiles/web/node_modules/dsh-plugin-hub
git apply --ignore-whitespace <本仓库>/patches/installer.js.patch
# 其余 4 个补丁同法：index.js / conflict-check.js / remote.js / client.js
```

上游（原作者）发布新版本后，升级并重新打补丁即可。

**注意**：不要与 registry 版的 `dsh-plugin-hub` 同时安装 —— 两者插入相同的 loader 入口 id 会导致插件树崩溃。安装前先卸载旧版：`dsh plugin --profile web remove dsh-plugin-hub`。

## 本 fork 新增的功能

| 功能 | 说明 |
| --- | --- |
| **可配置插件下载目录** | 设置页（商店内设置 + 全局 DSH 设置）新增「插件安装目录」项。默认 `<DSH_HOME>/plugins`；留空保存 = 恢复默认。商店初始化时自动创建该目录。 |
| **插件源码目录管理** | 商店安装的每个插件都会以真实包文件夹形式落到配置目录（如 `plugins/<名称>/`，作用域包为 `plugins/@scope/名称/`），再通过 `file:` 依赖 + bundles/补丁激活自动注册进 profile。卸载时同步删除文件夹（及空的 scope 父目录）。 |
| **bundle 层冲突检测（第 4 项检查）** | 激活前将新插件 bundle 补丁中 `insert` 的入口 id 与现有所有 bundle 层逐一比对，重复即拦截并列出冲突 id（如把 TUI 插件装进 web profile 的场景）—— 防止整树启动崩溃（`duplicate loader entry id`）。 |
| **pnpm 自动寻路** | 先搜 `PATH` 中的 pnpm，找不到则回退到 harness 本地 shim（`<harness 根目录>/.dsh-tools/pnpm.cmd`、`<harness 根目录>/.bin/pnpm.cmd`）。任意终端启动都能正常安装插件，即使 pnpm 不在 PATH 上。 |
| **准确的重启提示** | bundles 层插件只在启动时组合，安装回执现在明确提示「重启 dsh 后生效」（`restartRequired: true`），不再谎称热加载；对"已安装但未加载"的插件执行启用/禁用也会返回同样的明确提示。 |
| **启用超时透传真实错误** | 插件启用超时时的报错会附上条目真实的初始化失败原因（如 `no pet packages found in ~/.codex/pets`），不再只有干巴巴的「超时」。 |
| **作用域包支持** | `@scope/name` 包可正确暂存（自动创建 scope 父目录、暂存目录名扁平化）。 |
| **上游 bug 修复** | ① yaml 的 `map.get('insert')` 返回 YAMLSeq 节点，原代码用 `Array.isArray` 误判导致 owned 补丁行卸载时永远删不掉；② 补丁完整性检查用正则扫原始文本（引号不剥离、注释碎片被当成包名）→ 平台包（`@deepseek-ai/*`）被误拦，已改为结构化 YAML 解析；③ 容忍 pnpm 卸载后置失败（已删除但退出码 1），不再留下半卸载状态。 |

## 更新日志

### 0.2.0（2026-08-17）

- **可配置插件下载目录**：设置页新增「插件安装目录」（默认 `<DSH_HOME>/plugins`，留空恢复默认），商店初始化自动创建；插件以源码文件夹落盘并自动注册部署，卸载同步清理
- **bundle 层冲突检测（第 4 项检查）**：安装前比对新插件与现有 bundle 层的 `insert` 入口 id，重复即拦截并列出冲突 id，防止整树启动崩溃
- **pnpm 自动寻路**：PATH 无 pnpm 时自动回退 harness 本地 shim，任意终端可用
- **准确的提示**：bundles 插件安装回执明确「重启 dsh 后生效」；启用/禁用超时附上条目真实初始化错误
- **scoped 包支持**：`@scope/name` 包正确暂存与卸载（scope 父目录自动创建/回收）
- **上游 bug 修复**：① yaml YAMLSeq 误判导致 owned 补丁行无法卸载清理；② 补丁完整性检查正则误报（引号/注释）→ 改为结构化 YAML 解析；③ 容忍 pnpm 卸载后置失败（已删除但退出码 1）

## 回归测试

| 脚本 | 覆盖 |
| --- | --- |
| `tests/verify-install.mjs` | 完整安装/卸载链路 10 项检查（假插件，含无 pnpm PATH 场景） |
| `tests/verify-scoped.mjs` | scoped 包名（@scope/name）安装/卸载回归 |
| `tests/install-pet.mjs` | 宠物包下载 + 用插件自身 loader 验证 |

运行：`node tests/verify-install.mjs`（Windows 上建议带 `PATH=...\.dsh-tools` 前缀以保证 pnpm 可用；无 pnpm 时脚本会走 shim 回退）。

## 其他文档

- [FORK-README.md](./FORK-README.md) —— 改动清单、部署方法、基线提交
- [docs/UPSTREAM-README.md](./docs/UPSTREAM-README.md) —— 原始 README 存档（原版功能总览与更新日志）

上游许可见 `LICENSE`（二次开发需保留原作者版权声明）。
