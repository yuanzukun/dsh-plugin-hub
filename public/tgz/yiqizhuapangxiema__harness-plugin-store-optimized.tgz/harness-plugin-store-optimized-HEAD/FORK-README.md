# Harness Plugin Store Optimized（dsh-plugin-hub 定制版）

> 基线：`dsh-plugin-hub@0.1.6`，原作者 [yunhuantian/dsh-plugin-hub](https://github.com/yunhuantian/dsh-plugin-hub)（npm registry）
> 定制：yiqizhuapangxiema（2026-08-17），Windows 环境实测通过

## 改动清单（5 个文件，+553/-78 行）

| 文件 | 改动 |
|---|---|
| `lib/host/installer.js` | 可配置插件下载目录（pluginsDir）完整管线；npm pack / git clone 暂存；`file:` 依赖自动注册；scoped 包名支持；卸载清理增强（按 id/name/insert 四路匹配 + scope 空目录回收）；pnpm 自动寻路（PATH → DSH_HOME 旁 shim 回退）；卸载容忍 pnpm 事后 exit 1；bundles 插件 receipt 明确提示需重启 |
| `lib/host/index.js` | 新 RPC `setPluginsDir`（含装饰器管道）；构造器自动创建插件目录；settings() 暴露 pluginsDir/defaultPluginsDir/pluginsDirError；setEnabled 对"已装未加载"的 bundles 插件返回明确提示；waitForEntry 超时附带条目真实初始化错误 |
| `lib/host/conflict-check.js` | 补丁完整性检查改为结构化 YAML 解析（修复引号/注释误报）；新增第 4 项检查：bundle 层 loader 入口 id 重复检测（防 dsh-tui 类整树崩溃） |
| `lib/contracts/remote.js` | storeSettings schema 加 3 字段；setPluginsDir 描述符 |
| `lib/client.js` | schema 打包副本同步；RPC shim；两个设置表单新增"插件安装目录"区；中英文案 |

## 修复的上游 bug

1. yaml `map.get('insert')` 返回 YAMLSeq 节点被 `Array.isArray` 误判 → owned patch 行卸载时永远删不掉
2. 补丁完整性检查用正则扫原始文本：引号不剥离、注释碎片误判为包名 → 平台包（`@deepseek-ai/*`）被误拦
3. 卸载时 pnpm 已应用删除但退出码 1 → 被当作失败，留下半卸载状态

## 部署方法（三选一）

**A. 直接以本仓库安装（推荐，替换 registry 版）：**
```bash
dsh plugin --profile web add file:E:/deepseek-harness/harness-plugin-store-optimized
```
（profile 依赖规格会变成 `file:` 指向本仓库，升级上游需重新 add）

**B. 打补丁到已装的 registry 版：**
```bash
cd E:/deepseek-harness/.dsh/profiles/web/node_modules/dsh-plugin-hub
git apply --ignore-whitespace <补丁文件>   # 或: patch -p1 -i patches/xxx.patch
```
上游升级后按同法重新打补丁。

**C. 直接覆盖文件：** 将本仓库 `lib/` 下 5 个文件复制到已装目录同名位置，重启 dsh web。

## 回归测试

| 脚本 | 覆盖 |
|---|---|
| `tests/verify-install.mjs` | 完整安装/卸载链路 10 项检查（假插件，含无 pnpm PATH 场景） |
| `tests/verify-scoped.mjs` | scoped 包名（@scope/name）安装/卸载回归 |
| `tests/install-pet.mjs` | 宠物包下载 + 用插件自身 loader 验证 |

运行：`node tests/verify-install.mjs`（Windows 上建议带 `PATH=...\.dsh-tools` 前缀以保证 pnpm 可用；无 pnpm 时脚本会走 shim 回退）。

## 基线提交

```
vendor: dsh-plugin-hub 0.1.6 (yunhuantian, npm registry)
```

上游许可见 `LICENSE`（二次开发需保留原作者版权声明）。
