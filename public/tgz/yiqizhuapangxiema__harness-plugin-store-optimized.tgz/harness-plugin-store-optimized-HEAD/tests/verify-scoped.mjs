// Scoped-package regression: @scope/name plugins must stage + register + uninstall.
import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { resolveProfile, installPlugin, uninstallPlugin } from 'file:///E:/deepseek-harness/.dsh/profiles/web/node_modules/dsh-plugin-hub/lib/host/installer.js';

const profile = resolveProfile('file:///E:/deepseek-harness/.dsh/profiles/web/');
const pluginsDir = 'E:/deepseek-harness/.dsh/plugins';
const spec = 'E:/deepseek-harness/dev-tests/@test-scope/dsh-test-scoped';
const name = '@test-scope/dsh-test-scoped';
let failures = 0;
const check = (label, ok, extra = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${extra ? '  [' + extra + ']' : ''}`);
  if (!ok) failures++;
};

console.log('== scoped install ==');
const r = await installPlugin(profile, spec, name, 'verifier', undefined, pluginsDir);
console.log('receipt ok:', r.ok, '|', r.message ?? r.detail);
check('install ok', r.ok === true);
check('scoped folder exists', existsSync(join(pluginsDir, name)));
const pkg = JSON.parse(readFileSync(profile.packageJsonFile, 'utf8'));
check('profile dep is file: spec', String(pkg.dependencies?.[name] ?? '').startsWith('file:'), pkg.dependencies?.[name]);
check('patch row written', readFileSync(profile.patchFile, 'utf8').includes(name));

await new Promise((res) => setTimeout(res, 4000));
const web = await fetch('http://127.0.0.1:3080/', { signal: AbortSignal.timeout(8000) });
check('web still 200', web.status === 200);

console.log('== scoped uninstall ==');
const u = await uninstallPlugin(profile, name, name, 'verifier', pluginsDir);
console.log('receipt ok:', u.ok, '|', u.message ?? u.detail);
check('uninstall ok', u.ok === true);
check('scoped folder removed', !existsSync(join(pluginsDir, name)));
const pkg2 = JSON.parse(readFileSync(profile.packageJsonFile, 'utf8'));
check('profile dep removed', !(name in (pkg2.dependencies ?? {})));
check('patch row removed', !readFileSync(profile.patchFile, 'utf8').includes(name));

console.log(failures === 0 ? 'ALL SCOPED CHECKS PASSED' : `${failures} CHECK(S) FAILED`);
process.exitCode = failures === 0 ? 0 : 1;
