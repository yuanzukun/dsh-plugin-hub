// Download a Code Pet package (DeepSeek娘) into ~/.codex/pets and validate it
// with deepseek-pet's own loader.
import { mkdirSync, writeFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const PETS_DIR = join(process.env.USERPROFILE ?? process.env.HOME, '.codex', 'pets');
const target = join(PETS_DIR, 'deepseek-girl');
mkdirSync(target, { recursive: true });

const BASE = 'https://raw.githubusercontent.com/xpy12367/codex-pet-DeepSeek-girl/main';
const files = ['pet.json', 'spritesheet.webp'];
for (const f of files) {
    const res = await fetch(`${BASE}/${f}`, { signal: AbortSignal.timeout(60000) });
    if (!res.ok) throw new Error(`download ${f}: HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    writeFileSync(join(target, f), buf);
    console.log(`downloaded ${f}: ${buf.length} bytes`);
}

// Validate with the plugin's own loader (the profile-hoisted copy).
const { loadPetPackage } = await import('file:///E:/deepseek-harness/.dsh/profiles/web/node_modules/deepseek-pet/lib/index.js');
const result = await loadPetPackage({
    pet: 'deepseek-girl',
    petsDir: '',
    size: 112,
    position: 'bottom-right',
    offsetX: 28,
    offsetY: 20,
    enableLook: true,
    draggable: true,
});
console.log('VALIDATE OK:', JSON.stringify({ id: result.manifest.id, displayName: result.manifest.displayName, spriteVersionNumber: result.manifest.spriteVersionNumber, imageType: result.imageType, bytes: result.image.length }, null, 2));
