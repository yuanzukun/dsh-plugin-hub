// End-to-end verification of the dsh-plugin-hub pluginsDir pipeline.
// Runs installer.js functions directly against the live web profile.
import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { resolveProfile, installPlugin, uninstallPlugin } from 'file:///E:/deepseek-harness/.dsh/profiles/web/node_modules/dsh-plugin-hub/lib/host/installer.js';

const profile = resolveProfile('file:///E:/deepseek-harness/.dsh/profiles/web/');
const pluginsDir = 'E:/deepseek-harness/.dsh/plugins';
const spec = 'E:/deepseek-harness/dev-tests/dsh-test-probe'; // npm pack accepts a folder
const name = 'dsh-test-probe';
let failures = 0;
const check = (label, ok, extra = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${extra ? '  [' + extra + ']' : ''}`);
  if (!ok) failures++;
};

console.log('== install ==');
const r = await installPlugin(profile, spec, name, 'verifier', (p) => console.log('  progress:', p.phase, p.detail ?? ''), pluginsDir);
console.log('receipt:', JSON.stringify(r, null, 2).slice(0, 600));
check('install ok', r.ok === true, r.message ?? '');
check('staged folder exists', existsSync(join(pluginsDir, name)));
const pkg = JSON.parse(readFileSync(profile.packageJsonFile, 'utf8'));
check('profile dep is file: spec', String(pkg.dependencies?.[name] ?? '').startsWith('file:'), pkg.dependencies?.[name]);
const patch = readFileSync(profile.patchFile, 'utf8');
check('patch file has owned row', patch.includes(name));

// HMR settle, then web check
await new Promise((res) => setTimeout(res, 4000));
const web = await fetch('http://127.0.0.1:3080/', { signal: AbortSignal.timeout(8000) });
check('dsh web still serves 200', web.status === 200, `status ${web.status}`);

console.log('== uninstall ==');
const u = await uninstallPlugin(profile, name, name, 'verifier', pluginsDir);
console.log('receipt:', JSON.stringify(u, null, 2).slice(0, 400));
check('uninstall ok', u.ok === true, u.message ?? '');
check('staged folder removed', !existsSync(join(pluginsDir, name)));
const pkg2 = JSON.parse(readFileSync(profile.packageJsonFile, 'utf8'));
check('profile dep removed', !(name in (pkg2.dependencies ?? {})));
const patch2 = readFileSync(profile.patchFile, 'utf8');
check('patch owned row removed', !patch2.includes(name));

await new Promise((res) => setTimeout(res, 2000));
const web2 = await fetch('http://127.0.0.1:3080/', { signal: AbortSignal.timeout(8000) });
check('dsh web still serves 200 after uninstall', web2.status === 200, `status ${web2.status}`);

console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);
