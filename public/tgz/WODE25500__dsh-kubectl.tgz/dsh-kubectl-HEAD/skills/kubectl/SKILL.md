---
name: kubectl
description: "Use when the user wants to inspect or manage a Kubernetes cluster: 'what pods are running', 'check deployment status', 'read pod logs', 'describe this service', 'apply this manifest', 'delete this resource', 'run a command in the pod', 'port-forward to a service'. Drives the kubectl CLI through the kubectl_* tools."
---

# kubectl：Kubernetes 集群操作

通过 kubectl 检查和管理 Kubernetes 集群。本技能通过 dsh-kubectl 插件暴露的 8 个 `kubectl_*` 工具驱动。

## 什么时候用

- 查看集群资源（pods/deployments/services/nodes/events）
- 排障：describe、日志、进容器执行命令
- 部署：apply 清单、查看 rollout 状态
- 访问：port-forward 到 pod/服务

## 工具速查

| 工具 | 行为 | 安全级别 |
|---|---|---|
| `kubectl_get` | 查资源（JSON 输出，模型易读） | 🔵 只读 |
| `kubectl_describe` | 资源详情（事件/状态/条件） | 🔵 只读 |
| `kubectl_logs` | 读 pod 日志 | 🔵 只读 |
| `kubectl_status` | 版本/上下文/集群信息 | 🔵 只读 |
| `kubectl_exec` | 进容器跑命令 | 🟡 执行（先确认） |
| `kubectl_apply` | 应用清单 | 🔴 改集群（必须确认） |
| `kubectl_delete` | 删除资源 | 🔴 销毁（必须确认） |
| `kubectl_port_forward` | 端口转发 | 🟡 常驻（注意停止） |

## 常用流程

```text
# 1. 看状态
kubectl_status
kubectl_get resource=nodes

# 2. 查工作负载
kubectl_get resource=pods namespace=prod
kubectl_get resource=deployments selector=app=nginx

# 3. 排障
kubectl_describe resource=pod name=web-abc123 namespace=prod
kubectl_logs pod=web-abc123 tail=200 namespace=prod
kubectl_logs pod=web-abc123 previous=true          # 崩溃前的日志

# 4. 访问服务（不暴露公网）
kubectl_port_forward pod=db-0 remotePort=5432 localPort=5433
# -> 本机 127.0.0.1:5433 访问数据库

# 5. 部署（先确认）
kubectl_apply file=./deploy.yaml
```

## 注意事项

- **JSON 输出**：`kubectl_get` 默认 `-o json`，模型可直接读结构化数据；需要表格时用 `wide=true`。
- **命名空间**：未指定时用配置的 `namespace` 或 default；跨命名空间用 `allNamespaces=true`。
- **写操作红线**：`kubectl_apply` / `kubectl_delete` / `kubectl_exec` 改变集群状态——**执行前必须向用户确认**，特别是 delete。
- **port-forward 是常驻进程**：转发后会持续占用，完成任务应提示用户（当前版本不自动停止）。
- **上下文**：多集群环境用 `context` 参数；误操作风险高时先 `kubectl_status` 确认当前上下文。
- 错误输出（连接拒绝等）会原样返回，包含集群地址信息。

## 配置（cordis.yml）

```yaml
- insert:
    - id: kubectl
      name: './src/index.js'
      config:
        kubectlPath: kubectl
        context: my-cluster
        namespace: default
        timeoutMs: 60000
```
