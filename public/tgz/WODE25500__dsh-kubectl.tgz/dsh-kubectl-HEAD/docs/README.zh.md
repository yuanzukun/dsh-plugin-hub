# dsh-kubectl 文档

## 快速上手

1. 确认 kubectl 可用：`kubectl version --client`；确认上下文：`kubectl config get-contexts`
2. 安装插件（见根 README）
3. 问 agent："kubectl_get resource=pods namespace=prod" 或 "kubectl_logs pod=xxx tail=100"

## 工具与命令对照

| dsh 工具 | kubectl 命令 |
|---|---|
| `kubectl_get` | `kubectl get <res> [-l sel] [-A] -o json` |
| `kubectl_describe` | `kubectl describe <res> <name>` |
| `kubectl_logs` | `kubectl logs <pod> [-c ct] [--tail N] [--previous]` |
| `kubectl_status` | `kubectl version --client -o json` |
| `kubectl_exec` | `kubectl exec <pod> [-it] [-c ct] -- <cmd>` |
| `kubectl_apply` | `kubectl apply -f <file>` |
| `kubectl_delete` | `kubectl delete <res> <name>` |
| `kubectl_port_forward` | `kubectl port-forward <pod> <local>:<remote>` |

## 常见场景

### 排障

```text
kubectl_get resource=pods namespace=prod
kubectl_describe resource=pod name=web-abc123
kubectl_logs pod=web-abc123 tail=200 previous=true
kubectl_exec pod=web-abc123 command="df -h" 
```

### 部署验证

```text
kubectl_get resource=deployments selector=app=nginx
kubectl_apply file=./deploy.yaml        # 需确认
kubectl_get resource=rollout status     # 查看滚动
```

### 访问集群内服务

```text
kubectl_port_forward pod=db-0 remotePort=5432 localPort=5433
# 然后 127.0.0.1:5433 就是数据库
```

## 常见问题

- **连接拒绝**：本机 kubeconfig 无可用集群。检查 `kubectl config get-contexts` 与集群地址。
- **权限不足**：当前 kubeconfig 用户无权访问该资源/命名空间，报 Forbidden。
- **port-forward 停不下来**：当前版本不自动停止，完成访问后提示用户手动结束会话。
