// dsh-kubectl — Kubernetes (kubectl) integration for DeepSeek Harness.
//
// Exposes kubectl to the dsh agent as native tools. Every read-only command
// uses `-o json` so the model gets structured data instead of tables; writes
// (apply/delete) are explicit tools that must be confirmed by the user. All
// calls run through the dsh shell executor so sandbox/approval policies apply.

import Schema from '@deepseek-ai/schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'kubectl'

export const inject = ['tools', 'shell']

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

export const Config = Schema.object({
  kubectlPath: Schema.string()
    .default('kubectl')
    .description('Path to kubectl (default: kubectl on PATH)'),
  context: Schema.string()
    .description('Default kubeconfig context to use'),
  namespace: Schema.string()
    .description('Default namespace for namespaced commands'),
  timeoutMs: Schema.number()
    .default(60_000)
    .description('Per-call timeout in ms'),
})

// ---------------------------------------------------------------------------
// Command builder
// ---------------------------------------------------------------------------

function buildCommand(config, args, extraFlags = []) {
  const parts = [config.kubectlPath || 'kubectl']
  if (args.context || config.context) parts.push('--context', args.context || config.context)
  if (args.namespace || config.namespace) parts.push('--namespace', args.namespace || config.namespace)
  parts.push(...extraFlags)
  return parts.join(' ')
}

function renderOutput(_args, value) {
  return [{ type: 'text', text: value }]
}

// ---------------------------------------------------------------------------
// Plugin entry
// ---------------------------------------------------------------------------

export function apply(ctx, config = {}) {
  const shell = ctx.shell

  const tools = [
    {
      name: 'kubectl_get',
      description:
        'Get Kubernetes resources as JSON. Returns structured data the model can read (names, statuses, IPs, images). Read-only.',
      parameters: {
        resource: { type: 'string', description: 'Resource type (pods, deployments, services, nodes, namespaces, events, ...)', required: true },
        name: { type: 'string', description: 'Resource name (omit for all)' },
        namespace: { type: 'string', description: 'Namespace (default: config or "default")' },
        context: { type: 'string', description: 'kubeconfig context' },
        selector: { type: 'string', description: 'Label selector, e.g. app=nginx' },
        allNamespaces: { type: 'boolean', description: 'Search all namespaces (-A)' },
        wide: { type: 'boolean', description: 'Include extra columns' },
      },
      build: (a) => {
        const extra = ['get', a.resource]
        if (a.name) extra.push(a.name)
        if (a.selector) extra.push('-l', a.selector)
        if (a.allNamespaces) extra.push('-A')
        extra.push('-o', a.wide ? 'wide' : 'json')
        return buildCommand(config, a, extra)
      },
    },
    {
      name: 'kubectl_describe',
      description:
        'Describe a Kubernetes resource with full details (events, conditions, labels). Read-only, human-oriented text output.',
      parameters: {
        resource: { type: 'string', description: 'Resource type', required: true },
        name: { type: 'string', description: 'Resource name', required: true },
        namespace: { type: 'string', description: 'Namespace' },
        context: { type: 'string', description: 'kubeconfig context' },
      },
      build: (a) => buildCommand(config, a, ['describe', a.resource, a.name]),
    },
    {
      name: 'kubectl_logs',
      description:
        'Read pod logs (last N lines, optionally from a specific container). Read-only.',
      parameters: {
        pod: { type: 'string', description: 'Pod name', required: true },
        container: { type: 'string', description: 'Container name (multi-container pods)' },
        namespace: { type: 'string', description: 'Namespace' },
        context: { type: 'string', description: 'kubeconfig context' },
        tail: { type: 'number', description: 'Last N lines (default 200)' },
        follow: { type: 'boolean', description: 'Follow logs (use with care, may not terminate)' },
        previous: { type: 'boolean', description: 'Logs from the previous (crashed) container instance' },
      },
      build: (a) => {
        const extra = ['logs', a.pod]
        if (a.container) extra.push('-c', a.container)
        if (a.tail !== undefined) extra.push('--tail', String(a.tail))
        if (a.previous) extra.push('--previous')
        if (a.follow) extra.push('--follow')
        return buildCommand(config, a, extra)
      },
    },
    {
      name: 'kubectl_exec',
      description:
        'Run a command inside a running pod container. This executes code in your cluster — confirm with the user first.',
      parameters: {
        pod: { type: 'string', description: 'Pod name', required: true },
        command: { type: 'string', description: 'Command to run inside the container, e.g. "ls -la /app"', required: true },
        container: { type: 'string', description: 'Container name' },
        namespace: { type: 'string', description: 'Namespace' },
        context: { type: 'string', description: 'kubeconfig context' },
        interactive: { type: 'boolean', description: 'Interactive mode (-it)' },
      },
      build: (a) => {
        const extra = ['exec']
        if (a.interactive) extra.push('-it')
        extra.push(a.pod)
        if (a.container) extra.push('-c', a.container)
        extra.push('--', ...a.command.split(/\s+/))
        return buildCommand(config, a, extra)
      },
    },
    {
      name: 'kubectl_apply',
      description:
        'Apply a Kubernetes manifest from a file or stdin. This CHANGES the cluster — confirm with the user first.',
      parameters: {
        file: { type: 'string', description: 'Path to the manifest YAML/JSON', required: true },
        context: { type: 'string', description: 'kubeconfig context' },
        namespace: { type: 'string', description: 'Namespace' },
      },
      build: (a) => buildCommand(config, a, ['apply', '-f', a.file]),
    },
    {
      name: 'kubectl_delete',
      description:
        'Delete Kubernetes resources. This DESTROYS resources — always confirm with the user first.',
      parameters: {
        resource: { type: 'string', description: 'Resource type', required: true },
        name: { type: 'string', description: 'Resource name', required: true },
        namespace: { type: 'string', description: 'Namespace' },
        context: { type: 'string', description: 'kubeconfig context' },
        ignoreNotFound: { type: 'boolean', description: 'Do not error if the resource is missing' },
      },
      build: (a) => {
        const extra = ['delete', a.resource, a.name]
        if (a.ignoreNotFound) extra.push('--ignore-not-found=true')
        return buildCommand(config, a, extra)
      },
    },
    {
      name: 'kubectl_port_forward',
      description:
        'Forward a local port to a pod (e.g. access a database or web UI without exposing it). Runs until stopped; returns the local endpoint.',
      parameters: {
        pod: { type: 'string', description: 'Pod name', required: true },
        localPort: { type: 'number', description: 'Local port' },
        remotePort: { type: 'number', description: 'Remote (pod) port', required: true },
        namespace: { type: 'string', description: 'Namespace' },
        context: { type: 'string', description: 'kubeconfig context' },
      },
      build: (a) => {
        const extra = ['port-forward', a.pod]
        const local = a.localPort ? `${a.localPort}:` : ''
        extra.push(`${local}${a.remotePort}`)
        return buildCommand(config, a, extra)
      },
    },
    {
      name: 'kubectl_status',
      description:
        'Show kubectl client/server versions, the current context, and cluster info. Read-only.',
      parameters: {
        context: { type: 'string', description: 'kubeconfig context' },
      },
      build: (a) => {
        const parts = [config.kubectlPath || 'kubectl']
        if (a.context || config.context) parts.push('--context', a.context || config.context)
        parts.push('version', '--client', '-o', 'json')
        return parts.join(' ')
      },
    },
  ]

  for (const t of tools) {
    ctx.tools.register(
      defineTool({
        name: t.name,
        description: t.description,
        parameters: t.parameters,
        output: { schema: { type: 'string' }, render: renderOutput },
        async execute(args, exec) {
          const command = t.build(args || {})
          try {
            const result = await shell.run({
              command,
              timeoutMs: config.timeoutMs,
              signal: exec?.signal,
            })
            const status = result?.exitCode ?? 'signal'
            const stdout = typeof result?.stdout === 'string' ? result.stdout : ''
            const stderr = typeof result?.stderr === 'string' ? result.stderr : ''
            const tail = [stdout, stderr].filter(Boolean).join('\n').trim()
            return [`[kubectl ${t.name}] exit=${status}`, tail ? tail.slice(0, 60_000) : '(no output)'].join('\n')
          } catch (err) {
            return `[kubectl ${t.name}] command failed: ${err?.message || String(err)}`
          }
        },
      }),
    )
  }

  ctx.logger?.info?.('[dsh-kubectl] registered 8 kubectl tools (get/describe/logs/exec/apply/delete/port-forward/status)')
}
