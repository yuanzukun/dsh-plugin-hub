# dsh-kubectl

**Kubernetes (kubectl) integration for DeepSeek Harness (dsh)** — let the dsh
agent inspect clusters, get resources, read logs, port-forward, and run
one-off commands. Read-only commands emit **structured JSON** (reliable for the
model); write operations require explicit confirmation.

> Independent community project, not official. Based on
> [kubernetes/kubectl](https://github.com/kubernetes/kubectl) (Apache-2.0).

## Why

Kubernetes (40k+ stars) has **no DSH adaptation plugin yet**. kubectl's `-o json`
structured output is ideal for agents — far better than table output:

| Capability | Notes |
|---|---|
| `kubectl_get` | get resources, `-o json` structured output |
| `kubectl_describe` / `kubectl_logs` | the troubleshooting trio |
| `kubectl_status` | version/context/cluster info |
| `kubectl_exec` / `kubectl_apply` / `kubectl_delete` | exec/deploy/delete (confirm first) |
| `kubectl_port_forward` | local access to cluster services |

## Prerequisites

- DeepSeek Harness (dsh)
- kubectl installed with a configured kubeconfig (`kubectl config get-contexts`)

## Install

```yaml
- insert:
    - id: kubectl
      name: './src/index.js'
      config:
        kubectlPath: kubectl
        context: my-cluster
        namespace: default
```

```bash
pnpm dsh web --patch ./dsh-kubectl/cordis.patch.yml
```

## Tools

| Tool | Behavior | Safety |
|---|---|---|
| `kubectl_get` | get resources (JSON) | 🔵 read-only |
| `kubectl_describe` | resource details | 🔵 read-only |
| `kubectl_logs` | pod logs (tail/previous/container) | 🔵 read-only |
| `kubectl_status` | version/context | 🔵 read-only |
| `kubectl_exec` | run command in container | 🟡 confirm |
| `kubectl_apply` | apply manifest | 🔴 confirm |
| `kubectl_delete` | delete resources | 🔴 confirm |
| `kubectl_port_forward` | port forwarding | 🟡 long-running |

## Config

| Key | Default | Purpose |
|---|---|---|
| `kubectlPath` | `kubectl` | kubectl path |
| `context` | — | default context |
| `namespace` | — | default namespace |
| `timeoutMs` | `60000` | per-call timeout |

## Known limitations

- Without a cluster, commands return connection-refused errors (stderr verbatim)
- `port-forward` is long-running; this version does not auto-stop it
- Write operations rely on user confirmation; SKILL.md marks the red lines

## Layout

```
dsh-kubectl/
  src/index.js            # 8 tools + config
  skills/kubectl/SKILL.md
  docs/
  cordis.patch.yml
```

## License

MIT.
