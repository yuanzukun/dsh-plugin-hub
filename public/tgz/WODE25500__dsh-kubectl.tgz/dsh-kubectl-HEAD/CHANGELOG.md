# Changelog

## 0.1.0 (2026-08-19)

- Initial release: dsh-kubectl for DeepSeek Harness.
