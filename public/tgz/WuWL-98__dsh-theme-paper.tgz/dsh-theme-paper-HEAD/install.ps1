﻿# dsh-theme-paper 一键安装脚本
# 用法：git clone 本仓库后，在仓库目录运行：
#   powershell -ExecutionPolicy Bypass -File .\install.ps1
# 然后重启 dsh web 生效。
param(
    [string]$ProfileName = "web"
)

$ErrorActionPreference = "Stop"

$PackageName = "dsh-theme-paper"
$RepoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

# DSH home（默认 ~/.dsh，可用 DSH_HOME 覆盖）
$DshHome = if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $HOME ".dsh" }
$ProfileDir = Join-Path $DshHome ("profiles\" + $ProfileName)
$ManifestPath = Join-Path $ProfileDir "package.json"

if (-not (Test-Path $ManifestPath)) {
    Write-Host "错误：找不到 profile：$ProfileDir" -ForegroundColor Red
    Write-Host "请先至少运行过一次 `dsh $ProfileName`（会自动初始化 profile），再运行本脚本。"
    exit 1
}

# 1) 把本仓库链接进 profile 的 node_modules（junction，免拷贝，git pull 即更新）
$NMDir = Join-Path $ProfileDir "node_modules"
New-Item -ItemType Directory -Path $NMDir -Force | Out-Null
$Link = Join-Path $NMDir $PackageName
if (Test-Path $Link) {
    Write-Host "链接已存在：$Link"
} else {
    New-Item -ItemType Junction -Path $Link -Target $RepoRoot | Out-Null
    Write-Host "已创建链接：$Link"
    Write-Host "              → $RepoRoot"
}

# 2) 注册为 profile 的 bundle 层（dsh.profile.bundles）
$manifest = Get-Content $ManifestPath -Raw | ConvertFrom-Json
if ($null -eq $manifest.dsh.profile.bundles) { $manifest.dsh.profile.bundles = @() }
if (@($manifest.dsh.profile.bundles) -contains $PackageName) {
    Write-Host "bundle 层已包含 $PackageName"
} else {
    $manifest.dsh.profile.bundles = @($manifest.dsh.profile.bundles) + $PackageName
    $json = $manifest | ConvertTo-Json -Depth 12
    # 无 BOM 的 UTF-8 写入（带 BOM 的 JSON 会被 Node 解析失败）
    [System.IO.File]::WriteAllText($ManifestPath, $json, (New-Object System.Text.UTF8Encoding $false))
    Write-Host "已把 $PackageName 加入 profile bundle 层（$ManifestPath）"
}

Write-Host ""
Write-Host "==================================================" -ForegroundColor Green
Write-Host "  ✅ 安装完成！重启 dsh web 生效：" -ForegroundColor Green
Write-Host "     dsh web" -ForegroundColor Cyan
Write-Host "  然后：设置 → 常规 → 外观 → 纸质" -ForegroundColor Green
Write-Host "  更新插件：在仓库目录 git pull 后重启 dsh web" -ForegroundColor Green
Write-Host "  卸载插件：dsh plugin --profile web remove dsh-theme-paper" -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Green
