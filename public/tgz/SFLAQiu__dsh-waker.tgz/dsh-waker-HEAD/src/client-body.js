    var React = require('react');
return {
  inject: ['slots', 'timer', 'sessions'],
  apply(ctx) {
    function api(method, args) {
      return fetch('/dsh-waker/api/rpc', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ method: method, args: args || {} })
      }).then(function (res) {
        return res.json().catch(function () { throw new Error('HTTP ' + res.status); }).then(function (data) {
          if (!data || data.ok !== true) throw new Error((data && data.error) || ('HTTP ' + res.status));
          return data.result;
        });
      });
    }
    function noteClass(kind) { return kind === 'error' ? 'dswk-noteError' : kind === 'warn' ? 'dswk-noteWarn' : 'dswk-noteOk'; }
    function imgUrl(file) {
      if (!file) return '';
      return '/dsh-waker/img/' + encodeURIComponent(file);
    }
    // 弹出系统文件夹选择器(host 复用 directoryPicker 原生能力)。
    // 返回 {path} | {canceled:true} | {unsupported:true};异常上抛由调用方提示。
    function pickFolder() {
      return api('waker.projects.pickFolder', {}).then(function (r) {
        if (r && r.unsupported) throw Object.assign(new Error('当前环境不支持系统文件夹选择，请手动输入路径'), { unsupported: true });
        return r || {};
      });
    }
    // 定位任务会话: 委托宿主客户端 sessions 服务(sessions.open),失败给可读提示。
    // onNote: ({kind,text}) => void
    function locateSession(t, onNote) {
      if (!t.sessionId) { onNote({ kind: 'warn', text: '任务尚未开始执行（排队/等待中），暂无会话可定位' }); return; }
      if (ctx.sessions && typeof ctx.sessions.open === 'function') {
        try { ctx.sessions.open(t.sessionId); onNote({ kind: 'ok', text: '已在会话列表定位该任务' }); }
        catch (e) { onNote({ kind: 'warn', text: '定位失败（会话可能已归档）: ' + t.sessionId }); }
      } else {
        onNote({ kind: 'warn', text: '无法跳转，会话 ID: ' + t.sessionId });
      }
    }

    // 模型选择下拉(单选,按 provider 分组 + 搜索): 对齐 DSH 输入框模型选择器的交互。
    // props: {value: {provider,model}|null, onChange, groups: [{id,name,models:[{id,name}]}],
    //         noneLabel, noneHint}
    // 交互: 空间不足自动上翻; ↑↓ 移动高亮、Enter 选中、Esc 关闭; 高亮项滚动跟随; 分组带数量。
    function ModelSelect(props) {
      var openS = React.useState(false);
      var open = openS[0], setOpen = openS[1];
      var qS = React.useState('');
      var q = qS[0], setQ = qS[1];
      var upS = React.useState(false);
      var up = upS[0], setUp = upS[1];
      var activeS = React.useState(0);
      var active = activeS[0], setActive = activeS[1];
      var boxRef = React.useRef(null);
      var listRef = React.useRef(null);
      var value = props.value || null;
      // 触发框两段式: 主行=模型显示名,右侧=提供方显示名(分组数据里解析,失败回退原始 id)
      var label = props.noneLabel;
      var provName = null;
      if (value) {
        var pg = (props.groups || []).filter(function (g) { return g.id === value.provider; })[0] || null;
        var pm = pg ? pg.models.filter(function (m) { return m.id === value.model; })[0] : null;
        label = pm && pm.name ? pm.name : value.model;
        provName = pg ? (pg.name || pg.id) : value.provider;
      }
      var groups = (props.groups || []).map(function (g) {
        var qq = String(q || '').trim().toLowerCase();
        var models = !qq ? g.models : g.models.filter(function (m) {
          return String(m.name || '').toLowerCase().indexOf(qq) !== -1 ||
            String(m.id || '').toLowerCase().indexOf(qq) !== -1 ||
            String(g.name || '').toLowerCase().indexOf(qq) !== -1;
        });
        return { id: g.id, name: g.name, models: models };
      }).filter(function (g) { return g.models.length > 0; });
      // 扁平选项序与渲染顺序一致: [跟随项, ...各分组模型],供键盘上下移动
      var flat = [{ kind: 'none' }];
      var idxOf = {};
      groups.forEach(function (g) {
        g.models.forEach(function (m) {
          idxOf[g.id + '/' + m.id] = flat.length;
          flat.push({ kind: 'model', g: g, m: m });
        });
      });
      var pickOpt = function (opt) {
        if (opt.kind === 'none') props.onChange(null);
        else props.onChange({ provider: opt.g.id, model: opt.m.id });
        setOpen(false);
      };
      var toggle = function () {
        if (open) { setOpen(false); return; }
        var r = boxRef.current ? boxRef.current.getBoundingClientRect() : null;
        // 下方放不下完整下拉(搜索框+列表+内边距≈340px)且上方足够时向上翻
        setUp(!!r && (window.innerHeight - r.bottom) < 340 && r.top > 340);
        setActive(0); setQ(''); setOpen(true);
      };
      React.useEffect(function () {
        if (!open || !listRef.current) return;
        var opts = listRef.current.querySelectorAll('.dswk-mopt');
        var el = opts[active];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
      }, [active, open, q]);
      return React.createElement('div', { className: 'dswk-modelWrap' },
        React.createElement('button', { type: 'button', className: 'dswk-modelBox', ref: boxRef, onClick: toggle },
          React.createElement('span', { className: 'dswk-modelLabel' + (value ? '' : ' dswk-modelLabelNone') }, label),
          value ? React.createElement('span', { className: 'dswk-modelBoxProv' }, provName) : null,
          React.createElement('span', { className: 'dswk-modelChevron' }, open ? '▲' : '▼')),
        open ? React.createElement('div', { className: 'dswk-popMask', onClick: function () { setOpen(false); } }) : null,
        open ? React.createElement('div', { className: 'dswk-modelDrop' + (up ? ' dswk-modelDropUp' : '') },
          React.createElement('input', {
            className: 'dswk-multiSearch', autoFocus: true, placeholder: '搜索模型…', value: q,
            onChange: function (e) { setQ(e.target.value); setActive(0); },
            onKeyDown: function (e) {
              if (e.key === 'ArrowDown') { e.preventDefault(); setActive(function (a) { return Math.min(a + 1, flat.length - 1); }); }
              else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(function (a) { return Math.max(a - 1, 0); }); }
              else if (e.key === 'Enter') { e.preventDefault(); if (flat[active]) pickOpt(flat[active]); }
              else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); setOpen(false); }
            }
          }),
          React.createElement('div', { className: 'dswk-modelList', ref: listRef },
            React.createElement('div', {
              className: 'dswk-mopt' + (active === 0 ? ' dswk-moptActive' : '') + (!value ? ' dswk-moptOn' : ''),
              onClick: function () { props.onChange(null); setOpen(false); }
            },
              React.createElement('span', { className: 'dswk-moptName' }, props.noneLabel),
              props.noneHint ? React.createElement('span', { className: 'dswk-moptSub' }, props.noneHint) : null,
              !value ? React.createElement('span', { className: 'dswk-multiOptTick dswk-multiOptTickOn' }, '✓') : null),
            groups.length ? groups.map(function (g) {
              return React.createElement('div', { key: g.id },
                React.createElement('div', { className: 'dswk-mgroupTitle' }, g.name + '(' + g.models.length + ')'),
                g.models.map(function (m) {
                  var on = !!(value && value.provider === g.id && value.model === m.id);
                  var idx = idxOf[g.id + '/' + m.id];
                  return React.createElement('div', {
                    className: 'dswk-mopt' + (on ? ' dswk-moptOn' : '') + (idx === active ? ' dswk-moptActive' : ''),
                    key: g.id + '/' + m.id, title: g.id + '/' + m.id,
                    onClick: function () { props.onChange({ provider: g.id, model: m.id }); setOpen(false); }
                  },
                  React.createElement('span', { className: 'dswk-moptName' }, m.name || m.id),
                  React.createElement('span', { className: 'dswk-moptSub' }, m.id),
                  on ? React.createElement('span', { className: 'dswk-multiOptTick dswk-multiOptTickOn' }, '✓') : null);
                }));
            }) : React.createElement('div', { className: 'dswk-multiEmpty' }, '无匹配模型'))) : null);
    }

    var cssText = [
      '.dswk{display:flex;flex-direction:column;gap:16px;padding:4px 0 32px;max-width:640px;}',
      '.dswk-card{box-sizing:border-box;display:flex;flex-direction:column;gap:12px;padding:16px;border:1px solid var(--dsw-alias-border-l2);border-radius:14px;background:var(--dsw-alias-bg-layer-1);}',
      '.dswk-cardTitle{margin:0;font-size:13px;font-weight:500;color:var(--dsw-alias-label-primary);}',
      // 分区头: 标题 + 主操作按钮右对齐(按钮统一样式, 高度一致)
      '.dswk-secHead{display:flex;align-items:center;gap:8px;}',
      '.dswk-secHead .dswk-cardTitle{flex:1;min-width:0;}',
      // 分区体: 标题行与其下内容的纵向间距(与抽屉整体 12px 节奏一致)
      '.dswk-secGroup{display:flex;flex-direction:column;gap:12px;}',
      '.dswk-secGroup > .dswk-details{margin-top:0;}',
      '.dswk-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}',
      '.dswk-field{display:flex;flex-direction:column;gap:4px;flex:1;min-width:220px;}',
      '.dswk-pathRow{display:flex;align-items:center;gap:8px;}',
      '.dswk-pathRow .dswk-input{flex:1;min-width:0;}',
      '.dswk-pathRow .dswk-btn{flex:none;white-space:nowrap;}',
      '.dswk-label{font-size:12px;color:var(--dsw-alias-label-secondary);}',
      '.dswk-input{box-sizing:border-box;width:100%;height:32px;padding:0 10px;font:inherit;font-size:13px;color:var(--dsw-alias-label-primary);background:var(--dsw-specific-input-major);border:1px solid var(--dsw-alias-border-l2);border-radius:8px;outline:none;}',
      '.dswk-input:focus{border-color:var(--dsw-alias-border-l4);}',
      // 徽章: dswk-badge 通用 · dswk-badgeMuted 用于「预置/自定义」等弱化信息(次色文字, 与状态徽章区分)
      '.dswk-badge{display:inline-flex;align-items:center;gap:6px;height:22px;padding:0 9px;border-radius:11px;font-size:12px;line-height:22px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-module-platform);border:1px solid var(--dsw-alias-border-l1);}',
      '.dswk-badgeMuted{color:var(--dsw-alias-label-secondary);}',
      '.dswk-dot{width:6px;height:6px;border-radius:50%;flex:none;background:var(--dsw-alias-label-tertiary);transition:background-color .15s ease;}',
      '@keyframes dswkPulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.75)}}',
      '.dswk-dotLoading{animation:dswkPulse 1.1s ease-in-out infinite;}',
      '.dswk-btn{height:30px;padding:0 14px;font:inherit;font-size:13px;color:var(--dsw-alias-label-primary);background:transparent;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;cursor:pointer;transition:background .12s ease;}',
      '.dswk-btn:hover{background:var(--dsw-alias-interactive-bg-hover);}',
      '.dswk-btn:disabled{opacity:.5;cursor:default;}',
      '.dswk-btnPrimary{background:var(--dsw-alias-button-info-fill);border-color:transparent;color:var(--dsw-alias-label-primary-foreground);}',
      '.dswk-btnPrimary:hover{background:var(--dsw-alias-button-info-hover);}',
      '.dswk-btnMini{height:24px;padding:0 10px;font-size:12px;border-radius:6px;}',
      // 危险操作(删除/解绑): 危险色文字 + 悬停浅红底, 与主/次按钮同构
      '.dswk-btnDanger{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary);}',
      '.dswk-btnDanger:hover{background:var(--dsw-alias-state-error-primary);color:var(--dsw-alias-label-primary-foreground);}',
      // 按钮层级规则: btnPrimary=主操作 · btn=次操作 · btnDanger=删除/解绑等破坏性操作; 行内一律加 btnMini 保持 24px 高一致
      '.dswk-kv{font-size:12px;color:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums;}',
      '.dswk-mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11px;line-height:17px;color:var(--dsw-alias-label-tertiary);word-break:break-all;margin:0;}',
      '.dswk-check{display:inline-flex;align-items:center;gap:6px;font-size:13px;color:var(--dsw-alias-label-primary);cursor:pointer;}',
      '.dswk-multi{position:relative;}',
      '.dswk-multiBox{display:flex;align-items:center;gap:4px;flex-wrap:wrap;min-height:32px;box-sizing:border-box;width:100%;padding:3px 8px;font-size:13px;color:var(--dsw-alias-label-primary);background:var(--dsw-specific-input-major);border:1px solid var(--dsw-alias-border-l2);border-radius:8px;cursor:text;}',
      '.dswk-multiChip{display:inline-flex;align-items:center;gap:5px;height:24px;padding:0 4px 0 3px;border-radius:12px;font-size:12px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-module-platform);border:1px solid var(--dsw-alias-border-l1);}',
      '.dswk-multiChip img{width:17px;height:17px;border-radius:50%;object-fit:cover;flex:none;}',
      '.dswk-multiChipX{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;margin-left:2px;border:none;border-radius:50%;background:transparent;color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:1;cursor:pointer;}',
      '.dswk-multiChipX:hover{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-hover);}',
      '.dswk-multiChipSt{display:inline-flex;align-items:center;justify-content:center;min-width:17px;height:17px;padding:0 4px;border-radius:9px;font-size:10px;line-height:17px;color:var(--dsw-alias-label-tertiary);background:var(--dsw-alias-bg-module-platform);border:1px solid var(--dsw-alias-border-l1);}',
      '.dswk-multiOffTag{display:inline-block;margin-left:6px;font-size:11px;color:var(--dsw-alias-label-tertiary);}',
      '.dswk-multiPlaceholder{font-size:13px;color:var(--dsw-alias-label-tertiary);padding:2px 0;}',
      '.dswk-multiDrop{position:absolute;left:0;right:0;top:100%;margin-top:4px;max-height:264px;overflow:auto;box-sizing:border-box;padding:4px;border:1px solid var(--dsw-alias-border-l2);border-radius:10px;background:var(--dsw-alias-bg-layer-1);box-shadow:0 8px 22px rgba(0,0,0,.14);z-index:70;}',
      '.dswk-multiDropUp{top:auto;bottom:calc(100% + 4px);margin-top:0;}',
      '.dswk-multiSearch{box-sizing:border-box;width:100%;height:30px;padding:0 10px;margin-bottom:4px;font:inherit;font-size:13px;color:var(--dsw-alias-label-primary);background:var(--dsw-specific-input-major);border:1px solid var(--dsw-alias-border-l2);border-radius:8px;outline:none;}',
      // 模型选择下拉(单选,provider 分组)
      '.dswk-modelWrap{position:relative;min-width:0;}',
      '.dswk-modelBox{display:flex;align-items:center;gap:6px;box-sizing:border-box;width:100%;height:32px;padding:0 8px 0 10px;font:inherit;font-size:13px;text-align:left;color:var(--dsw-alias-label-primary);background:var(--dsw-specific-input-major);border:1px solid var(--dsw-alias-border-l2);border-radius:8px;cursor:pointer;outline:none;}',
      '.dswk-modelBox:hover{border-color:var(--dsw-alias-border-l3);background:var(--dsw-alias-interactive-bg-hover);}',
      '.dswk-modelLabel{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
      '.dswk-modelLabelNone{color:var(--dsw-alias-label-tertiary);}',
      '.dswk-modelChevron{flex:none;font-size:10px;color:var(--dsw-alias-label-tertiary);}',
      '.dswk-popMask{position:fixed;inset:0;z-index:60;background:transparent;border:none;cursor:default;}',
      '.dswk-modelDrop{position:absolute;left:0;right:0;top:calc(100% + 4px);z-index:61;box-sizing:border-box;padding:4px;border:1px solid var(--dsw-alias-border-l2);border-radius:10px;background:var(--dsw-alias-bg-layer-1);box-shadow:0 8px 22px rgba(0,0,0,.14);}',
      '.dswk-modelDropUp{top:auto;bottom:calc(100% + 4px);}',
      '.dswk-modelList{max-height:320px;overflow-y:auto;}',
      '.dswk-mgroupTitle{position:sticky;top:0;margin:0 2px 2px;padding:5px 8px 3px;font-size:12px;font-weight:500;line-height:18px;color:var(--dsw-alias-label-tertiary);background:var(--dsw-alias-bg-layer-2);border-radius:6px;}',
      '.dswk-mopt{display:flex;align-items:center;gap:8px;min-height:34px;padding:5px 8px;border-radius:8px;cursor:pointer;}',
      '.dswk-mopt:hover{background:var(--dsw-alias-interactive-bg-hover);}',
      '.dswk-moptActive{background:var(--dsw-alias-interactive-bg-hover);}',
      '.dswk-moptOn{background:var(--dsw-alias-bg-module-platform);}',
      '.dswk-moptName{flex:none;max-width:55%;font-size:13px;color:var(--dsw-alias-label-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
      '.dswk-moptSub{flex:1;min-width:0;font-size:11px;color:var(--dsw-alias-label-tertiary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:right;}',
      '.dswk-multiOpt{display:flex;align-items:center;gap:8px;height:34px;padding:0 8px;border-radius:8px;cursor:pointer;user-select:none;}',
      '.dswk-multiOpt:hover{background:var(--dsw-alias-interactive-bg-hover);}',
      '.dswk-multiOptImg{width:24px;height:24px;border-radius:50%;object-fit:cover;flex:none;border:1px solid var(--dsw-alias-border-l1);}',
      '.dswk-multiOptEmoji{width:24px;flex:none;display:inline-flex;align-items:center;justify-content:center;font-size:15px;line-height:1;}',
      '.dswk-multiOptName{flex:1;min-width:0;font-size:13px;color:var(--dsw-alias-label-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
      '.dswk-multiOptTick{width:18px;height:18px;flex:none;display:inline-flex;align-items:center;justify-content:center;border:1px solid var(--dsw-alias-border-l2);border-radius:6px;font-size:12px;color:transparent;}',
      '.dswk-multiOptTickOn{background:var(--dsw-alias-button-info-fill);border-color:transparent;color:var(--dsw-alias-label-primary-foreground);}',
      '.dswk-multiOptActive{background:var(--dsw-alias-interactive-bg-hover);}',
      '.dswk-multiOptNameFix{flex:0 1 auto;max-width:45%;}',
      '.dswk-multiOptRole{flex:1;min-width:0;font-size:11px;line-height:16px;color:var(--dsw-alias-label-tertiary);text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
      '.dswk-multiFoot{position:sticky;bottom:0;display:flex;align-items:center;gap:8px;margin:2px -4px -4px;padding:6px 8px 4px;background:var(--dsw-alias-bg-layer-1);border-top:1px solid var(--dsw-alias-border-l1);border-radius:0 0 10px 10px;}',
      '.dswk-multiFootText{flex:1;min-width:0;font-size:12px;color:var(--dsw-alias-label-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
      '.dswk-modelBoxProv{flex:none;max-width:42%;font-size:11px;line-height:16px;color:var(--dsw-alias-label-tertiary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
      '.dswk-multiEmpty{height:34px;display:flex;align-items:center;padding:0 8px;font-size:13px;color:var(--dsw-alias-label-tertiary);}',
      '.dswk-note{font-size:12px;color:var(--dsw-alias-label-secondary);}',
      '.dswk-noteOk{color:var(--dsw-alias-state-success-primary);}',
      '.dswk-noteWarn{color:var(--dsw-alias-state-warn-primary);}',
      '.dswk-noteError{color:var(--dsw-alias-state-error-primary);}',
      // 能力页签: 勾选行/分组/折叠
      '.dswk-capHeading{margin:6px 0 0;font-size:13px;font-weight:600;color:var(--dsw-alias-label-primary);}',
      '.dswk-capList{display:flex;flex-direction:column;border:1px solid var(--dsw-alias-border-l1);border-radius:10px;overflow:hidden;}',
      '.dswk-capRow{display:flex;align-items:center;gap:10px;padding:9px 12px;border-top:1px solid var(--dsw-alias-border-l1);cursor:pointer;}',
      '.dswk-capRow:first-child{border-top:none;}',
      '.dswk-capRow:hover{background:var(--dsw-alias-interactive-bg-hover);}',
      '.dswk-capRow input[type=checkbox]{margin:0;flex:none;accent-color:var(--dsw-alias-button-info-fill);}',
      '.dswk-capRow input[type=checkbox]:disabled{cursor:default;}',
      '.dswk-capMain{display:flex;flex-direction:column;gap:2px;flex:1;min-width:0;}',
      '.dswk-capLabel{font-size:13px;color:var(--dsw-alias-label-primary);}',
      '.dswk-capSub{font-size:12px;color:var(--dsw-alias-label-tertiary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
      '.dswk-capLocked{cursor:default;}',
      '.dswk-capLocked:hover{background:transparent;}',
      '.dswk-capLocked .dswk-capLabel{color:var(--dsw-alias-label-secondary);}',
      '.dswk-capSrv{border-top:1px solid var(--dsw-alias-border-l1);}',
      '.dswk-capSrv:first-child{border-top:none;}',
      '.dswk-capSrvHead{display:flex;align-items:center;gap:8px;padding-right:12px;}',
      '.dswk-capSrvHead .dswk-capRow{flex:1;border-top:none;}',
      '.dswk-capTools{margin:0 12px 10px 32px;}',
      '.dswk-capTools .dswk-capRow{background:var(--dsw-alias-bg-module-platform);border-radius:8px;border-top:none;margin-top:2px;}',
      // 能力区工具栏: 搜索 + 状态 + 批量按钮
      '.dswk-capBar{display:flex;align-items:center;gap:8px;margin:6px 0;}',
      '.dswk-capBar .dswk-capSearch{height:28px;flex:1;min-width:120px;max-width:280px;}',
      '.dswk-capBar .dswk-btn{flex:none;}',
      '.dswk-capStatus{font-size:12px;color:var(--dsw-alias-label-tertiary);white-space:nowrap;flex:1;text-align:right;}',
      '.dswk-tabs{display:flex;gap:2px;padding:2px;border-radius:10px;background:var(--dsw-alias-bg-module-platform);width:fit-content;margin:0 0 4px;}',
      '.dswk-tab{height:28px;padding:0 14px;font:inherit;font-size:13px;color:var(--dsw-alias-label-secondary);background:transparent;border:none;border-radius:8px;cursor:pointer;}',
      '.dswk-tab:hover{color:var(--dsw-alias-label-primary);}',
      '.dswk-tabActive{background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);box-shadow:0 1px 2px rgba(0,0,0,.08);}',
      '.dswk-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px;}',
      '.dswk-wkCard{display:flex;flex-direction:column;gap:6px;padding:12px;border:1px solid var(--dsw-alias-border-l1);border-radius:12px;background:var(--dsw-alias-bg-layer-1);}',
      '.dswk-wkHead{display:flex;align-items:center;gap:8px;}',
      '.dswk-wkEmoji{font-size:20px;line-height:1;}',
      '.dswk-wkAvatar{width:28px;height:28px;border-radius:50%;object-fit:cover;flex:none;border:1px solid var(--dsw-alias-border-l1);}',
      '.dswk-avatarGrid{display:grid;grid-template-columns:repeat(6,1fr);gap:8px;margin-top:6px;}',
      '.dswk-avatarOpt{border:2px solid transparent;border-radius:10px;padding:2px;cursor:pointer;background:none;}',
      '.dswk-avatarOpt img{width:44px;height:44px;border-radius:8px;object-fit:cover;display:block;}',
      '.dswk-avatarOpt.dswk-avatarOn{border-color:var(--dsw-alias-accent,#4f7cff);}',
      '.dswk-avatarOptNew{grid-column:1/-1;display:flex;align-items:center;gap:8px;flex-wrap:wrap;}',
      '.dswk-wkName{font-size:13px;font-weight:500;color:var(--dsw-alias-label-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;flex:0 1 auto;}',
      '.dswk-wkHead > .dswk-wkName{flex:1 1 auto;}',
      '.dswk-wkRole{font-size:12px;color:var(--dsw-alias-label-tertiary);line-height:16px;}',
      '.dswk-wkMeta{font-size:11px;color:var(--dsw-alias-label-tertiary);}',
      // 绑定卡片候选池: 头像 + 名称只读小 chip(与表单内可编辑 chip 同一视觉语言)
      '.dswk-poolRow{display:flex;flex-wrap:wrap;align-items:center;gap:4px;margin-top:2px;}',
      '.dswk-poolLabel{flex:none;font-size:11px;color:var(--dsw-alias-label-tertiary);}',
      '.dswk-poolChip{display:inline-flex;align-items:center;gap:5px;max-width:150px;height:22px;padding:0 8px 0 3px;border-radius:11px;font-size:12px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-module-platform);border:1px solid var(--dsw-alias-border-l1);}',
      '.dswk-poolChip img{width:16px;height:16px;border-radius:50%;object-fit:cover;flex:none;}',
      '.dswk-poolChipEmoji{width:16px;flex:none;display:inline-flex;align-items:center;justify-content:center;font-size:11px;line-height:1;}',
      '.dswk-poolChipName{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
      '.dswk-poolChipTag{flex:none;font-size:10px;color:var(--dsw-alias-label-tertiary);}',
      '.dswk-poolChipOff{opacity:.55;}',
      '.dswk-poolNone{font-size:11px;color:var(--dsw-alias-label-tertiary);}',
      // Waker 头像化展示: 看板行小头像 / 复选框小头像(无头像回退 emoji)
      '.dswk-taskWkImg{width:18px;height:18px;border-radius:50%;object-fit:cover;flex:none;margin-right:5px;vertical-align:-4px;}',
      '.dswk-taskWkEmoji{font-size:13px;margin-right:4px;}',
      '.dswk-checkImg{width:20px;height:20px;border-radius:50%;object-fit:cover;flex:none;}',
      '.dswk-checkEmoji{font-size:14px;line-height:1;}',
      '.dswk-wkOff{opacity:.55;}',
      '.dswk-textarea{box-sizing:border-box;width:100%;min-height:56px;padding:8px 10px;font:inherit;font-size:13px;color:var(--dsw-alias-label-primary);background:var(--dsw-specific-input-major);border:1px solid var(--dsw-alias-border-l2);border-radius:8px;outline:none;resize:vertical;}',
      '.dswk-overlay{position:fixed;inset:0;display:flex;overflow:auto;padding:16px;background:rgba(0,0,0,.35);z-index:60;}',
      '.dswk-details{display:flex;flex-direction:column;gap:4px;margin-top:4px;}',
      '.dswk-details summary{cursor:pointer;}',
      '.dswk-details summary:hover{color:var(--dsw-alias-label-primary);}',
      // 弹窗自身不裁剪(overlay 负责滚动): 下拉/浮层可溢出弹窗盒展开,不再被 max-height 截断
      '.dswk-modal{width:520px;max-width:92vw;margin:auto;display:flex;flex-direction:column;gap:12px;padding:18px;border-radius:14px;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l2);}',
      // 绑定弹窗: 宽 640;高度随内容(字段在纵向容器里禁止拉伸,见下一行),下拉浮层可溢出弹窗展开
      '.dswk-modalBind{width:640px;gap:14px;padding:20px;}',
      '.dswk-modalBind > .dswk-field{flex:0 0 auto;}',
      '.dswk-detailOverlay{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.35);z-index:60;}',
      '.dswk-detailModal{display:flex;gap:16px;width:720px;max-width:94vw;height:560px;max-height:84vh;padding:18px;border-radius:14px;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l2);}',
      '.dswk-detailHead{display:flex;align-items:center;gap:10px;}',
      '.dswk-detailHero{flex:1;min-width:0;display:flex;align-items:center;gap:12px;}',
      '.dswk-detailClose{width:28px;height:28px;flex:none;display:flex;align-items:center;justify-content:center;border:none;border-radius:8px;background:transparent;color:var(--dsw-alias-label-tertiary);font-size:15px;cursor:pointer;}',
      '.dswk-detailClose:hover{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-module-platform);}',
      '.dswk-detailTip{font-size:12px;color:var(--dsw-alias-label-tertiary);line-height:20px;}',
      '.dswk-detailSide{width:168px;flex:none;display:flex;flex-direction:column;gap:2px;border-right:1px solid var(--dsw-alias-border-l1);padding-right:14px;}',
      '.dswk-detailSideTitle{font-size:12px;color:var(--dsw-alias-label-tertiary);padding:4px 10px 8px;}',
      '.dswk-detailSideItem{text-align:left;height:34px;padding:0 10px;font:inherit;font-size:13px;color:var(--dsw-alias-label-secondary);background:transparent;border:none;border-radius:8px;cursor:pointer;display:flex;align-items:center;gap:6px;}',
      '.dswk-detailSideItem:hover{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-module-platform);}',
      '.dswk-detailSideItem.dswk-detailOn{background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font-weight:500;}',
      '.dswk-detailBody{flex:1;min-width:0;overflow:auto;display:flex;flex-direction:column;gap:12px;}',
      '.dswk-detailHero{display:flex;align-items:center;gap:12px;}',
      '.dswk-detailAvatar{width:48px;height:48px;border-radius:50%;object-fit:cover;flex:none;border:1px solid var(--dsw-alias-border-l1);}',
      // 档案定义表: 行间 1px 分隔线, 标签列定宽弱化色, 值列可含语义状态点
      '.dswk-def{display:flex;flex-direction:column;padding:2px 14px 0;border:1px solid var(--dsw-alias-border-l2);border-radius:12px;}',
      '.dswk-defRow{display:flex;align-items:baseline;gap:16px;padding:11px 0;border-top:1px solid var(--dsw-alias-border-l1);}',
      '.dswk-defRow:first-child{border-top:none;}',
      '.dswk-defK{width:64px;flex:none;font-size:13px;color:var(--dsw-alias-label-tertiary);}',
      '.dswk-defV{flex:1;min-width:0;font-size:13px;line-height:21px;color:var(--dsw-alias-label-primary);word-break:break-word;}',
      '.dswk-statusVal{display:inline-flex;align-items:center;gap:6px;}',
      '.dswk-taskRow{display:flex;align-items:center;gap:8px;padding:8px;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;}',
      '.dswk-projRow{display:flex;flex-direction:column;gap:3px;padding:8px;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;}',
      '.dswk-projRowHead{display:flex;align-items:center;gap:8px;min-width:0;}',
      '.dswk-projMeta{font-size:12px;line-height:17px;color:var(--dsw-alias-label-tertiary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
      '.dswk-select{box-sizing:border-box;width:100%;height:32px;padding:0 8px;font:inherit;font-size:13px;color:var(--dsw-alias-label-primary);background:var(--dsw-specific-input-major);border:1px solid var(--dsw-alias-border-l2);border-radius:8px;outline:none;}',
      '.dswk-seg{display:flex;gap:2px;padding:2px;border-radius:8px;background:var(--dsw-alias-bg-module-platform);width:fit-content;}',
      '.dswk-segBtn{height:24px;padding:0 10px;font:inherit;font-size:12px;color:var(--dsw-alias-label-secondary);background:transparent;border:none;border-radius:6px;cursor:pointer;}',
      '.dswk-segBtn:hover{color:var(--dsw-alias-label-primary);}',
      '.dswk-segBtnActive{background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);box-shadow:0 1px 2px rgba(0,0,0,.08);}',
      '.dswk-tasks{display:flex;flex-direction:column;margin:0 -4px;}',
      '.dswk-task{display:flex;align-items:center;gap:10px;padding:9px 4px;border-top:1px solid var(--dsw-alias-border-l1);cursor:pointer;border-radius:6px;transition:background .12s ease;}',
      '.dswk-task:first-child{border-top:none;}',
      '.dswk-task:hover{background:var(--dsw-alias-interactive-bg-hover);}',
      '.dswk-taskMain{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px;}',
      '.dswk-taskTitle{display:flex;align-items:center;gap:0;font-size:13px;color:var(--dsw-alias-label-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
      '.dswk-taskSub{font-size:11px;color:var(--dsw-alias-label-tertiary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
      '.dswk-taskOps{display:flex;gap:4px;opacity:0;transition:opacity .15s ease;}',
      '.dswk-task:hover .dswk-taskOps{opacity:1;}',
      '.dswk-pager{display:flex;align-items:center;gap:4px;margin-top:10px;flex-wrap:wrap;}',
      '.dswk-pgBtn{min-width:24px;height:24px;padding:0 6px;font:inherit;font-size:12px;color:var(--dsw-alias-label-secondary);background:transparent;border:1px solid transparent;border-radius:6px;cursor:pointer;}',
      '.dswk-pgBtn:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover);}',
      '.dswk-pgBtnActive{background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);border-color:var(--dsw-alias-border-l1);font-weight:600;}',
      '.dswk-pgBtnDis{opacity:.4;cursor:default;}',
      '.dswk-skel{height:38px;border-radius:6px;background:var(--dsw-alias-bg-module-platform);margin:4px 0;}',
      '@media (prefers-reduced-motion: reduce){.dswk *{transition:none!important;animation:none!important}}'
    ].join('\n');

    var styleEl = typeof document !== 'undefined' ? document.createElement('style') : null;
    if (styleEl) {
      styleEl.setAttribute('data-dsh-waker', '');
      styleEl.textContent = cssText;
      document.head.appendChild(styleEl);
    }
    if (ctx.effect) ctx.effect(function () {
      return function () { if (styleEl && styleEl.parentNode) styleEl.parentNode.removeChild(styleEl); };
    }, 'dsh-waker styles');

    var DOT = {
      ok: 'var(--dsw-alias-state-success-primary)',
      warn: 'var(--dsw-alias-state-warn-primary)',
      error: 'var(--dsw-alias-state-error-primary)',
      neutral: 'var(--dsw-alias-label-tertiary)',
      info: 'var(--dsw-alias-button-info-fill)'
    };
    var PHASE_LABEL = {
      starting: '启动中', running: '运行中', exited: '已退出', stopped: '已停止', error: '错误',
      'no-credentials': '未配置', connecting: '连接中', connected: '已连接', disconnected: '已断开', stopping: '停止中'
    };
    var TASK_META = {
      queued: { dot: 'neutral', label: '排队中' },
      running: { dot: 'info', label: '运行中' },
      'needs-input': { dot: 'warn', label: '需要操作' },
      failed: { dot: 'error', label: '失败' },
      cancelled: { dot: 'neutral', label: '已取消' },
      done: { dot: 'ok', label: '已完成' }
    };
    var FILTERS = [
      { id: 'all', label: '全部' },
      { id: 'needs-input', label: '需要操作' },
      { id: 'running', label: '运行中' },
      { id: 'queued', label: '排队中' },
      { id: 'failed', label: '失败' },
      { id: 'done', label: '完成' }
    ];

    function phaseTone(p) {
      if (p === 'running' || p === 'connected') return 'ok';
      if (p === 'starting' || p === 'connecting' || p === 'disconnected') return 'warn';
      if (p === 'error' || p === 'exited') return 'error';
      return 'neutral';
    }
    function Badge(props) {
      return React.createElement('span', { className: 'dswk-badge' },
        React.createElement('span', { className: 'dswk-dot', style: { background: DOT[phaseTone(props.phase)] } }),
        PHASE_LABEL[props.phase] || (props.phase || '未知'));
    }
    function fmtTime(t) { return t ? new Date(t).toLocaleTimeString() : '-'; }

    function BoardSection() {
      var data = React.useState(null);
      var board = data[0], setBoard = data[1];
      var err = React.useState(null);
      var loadErr = err[0], setLoadErr = err[1];
      var loaded = React.useState(false);
      var onceLoaded = loaded[0], setOnceLoaded = loaded[1];
      var filter = React.useState('all');
      var curFilter = filter[0], setFilter = filter[1];
      var actNote = React.useState(null);
      var note = actNote[0], setNote = actNote[1];
      var pageS = React.useState(0);
      var page = pageS[0], setPage = pageS[1];
      var PAGE_SIZE = 12;

      // 翻页/切筛选时回到第一页
      var changeFilter = function (fid) { setFilter(fid); setPage(0); };
      var changePage = function (p) { setPage(p); document.querySelector('.dswk-card') && document.querySelector('.dswk-card').scrollIntoView({ block: 'start', behavior: 'smooth' }); };

      var refresh = React.useCallback(function () {
        return api('waker.getBoardData').then(function (d) {
          setBoard(d); setLoadErr(null); setOnceLoaded(true);
        }).catch(function (e) { setLoadErr(String((e && e.message) || e)); });
      }, []);
      React.useEffect(function () {
        refresh();
        var stop = ctx.timer.interval(refresh, 3000);
        return function () { if (stop) stop(); };
      }, [refresh]);

      var act = function (rpc, conv, label) {
        return function (ev) {
          ev.stopPropagation();
          setNote({ kind: 'ok', text: label + '…' });
          api(rpc, { conversationId: conv }).then(function () {
            setNote({ kind: 'ok', text: label + '完成' });
            refresh();
          }).catch(function (e) {
            setNote({ kind: 'error', text: label + '失败: ' + String((e && e.message) || e) });
          });
        };
      };

      var openTask = function (t) {
        locateSession(t, setNote);
      };

      var stats = board && board.stats ? board.stats : null;
      var tasks = board && board.tasks ? board.tasks : [];
      var filtered = curFilter === 'all' ? tasks : tasks.filter(function (t) { return t.state === curFilter; });
      // 分页: 每页 PAGE_SIZE,翻页越界自动回退到最后一页
      var totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
      var curPage = Math.min(page, totalPages - 1);
      var pageTasks = filtered.slice(curPage * PAGE_SIZE, curPage * PAGE_SIZE + PAGE_SIZE);

      var pager = null;
      if (totalPages > 1) {
        var pgBtns = [];
        for (var p = 0; p < totalPages; p++) {
          (function (pi) {
            pgBtns.push(React.createElement('button', {
              key: pi,
              className: 'dswk-pgBtn' + (curPage === pi ? ' dswk-pgBtnActive' : ''),
              onClick: function () { changePage(pi); }
            }, String(pi + 1)));
          })(p);
        }
        pager = React.createElement('div', { className: 'dswk-pager' },
          React.createElement('button', {
            className: 'dswk-pgBtn' + (curPage === 0 ? ' dswk-pgBtnDis' : ''),
            disabled: curPage === 0,
            onClick: function () { changePage(curPage - 1); }
          }, '‹'),
          pgBtns,
          React.createElement('button', {
            className: 'dswk-pgBtn' + (curPage >= totalPages - 1 ? ' dswk-pgBtnDis' : ''),
            disabled: curPage >= totalPages - 1,
            onClick: function () { changePage(curPage + 1); }
          }, '›'),
          React.createElement('span', { className: 'dswk-kv' }, (curPage * PAGE_SIZE + 1) + '-' + Math.min(filtered.length, (curPage + 1) * PAGE_SIZE) + ' / ' + filtered.length));
      }

      var statLine = null;
      if (stats) {
        statLine = '排队 ' + (stats.queued || 0) + ' · 运行 ' + (stats.running || 0) + ' · 需要操作 ' + (stats.needsInput || 0) +
          ' · 失败 ' + (stats.failed || 0) + ' · 取消 ' + (stats.cancelled || 0) + ' · 完成 ' + (stats.done || 0);
      }

      var rows;
      if (!onceLoaded && !loadErr) {
        rows = React.createElement('div', null,
          React.createElement('div', { className: 'dswk-skel' }),
          React.createElement('div', { className: 'dswk-skel' }),
          React.createElement('div', { className: 'dswk-skel' }));
      } else if (loadErr && !board) {
        rows = React.createElement('div', { className: 'dswk-row' },
          React.createElement('span', { className: 'dswk-note dswk-noteError' }, '加载失败: ' + loadErr),
          React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: refresh }, '重试'));
      } else if (filtered.length === 0) {
        rows = React.createElement('p', { className: 'dswk-note' },
          curFilter === 'all' ? '暂无任务。在钉钉群里 @机器人 发送消息即可创建任务。' : '该状态下暂无任务。');
      } else {
        rows = React.createElement('div', { className: 'dswk-tasks' }, pageTasks.map(function (t, i) {
          var meta = TASK_META[t.state] || TASK_META.queued;
          var ops = [];
          if (t.state === 'queued' || t.state === 'running' || t.state === 'needs-input') {
            ops.push(React.createElement('button', { className: 'dswk-btn dswk-btnMini', key: 'c', onClick: act('waker.taskCancel', t.conversationId, '取消') }, '取消'));
          }
          if (t.state === 'failed' || t.state === 'cancelled') {
            ops.push(React.createElement('button', { className: 'dswk-btn dswk-btnMini', key: 'r', onClick: act('waker.taskRetry', t.conversationId, '重试') }, '重试'));
          }
          var sub = t.stateMsg ? t.stateMsg : ('会话 ' + (t.sessionId || '').replace('waker-conv-', '') + ' · ' + (t.turnCount || 0) + ' 轮');
          var wkrLead = t.wakerAvatar
            ? React.createElement('img', { className: 'dswk-taskWkImg', src: imgUrl(t.wakerAvatar), alt: '' })
            : (t.wakerEmoji ? React.createElement('span', { className: 'dswk-taskWkEmoji' }, t.wakerEmoji) : null);
          return React.createElement('div', { className: 'dswk-task', key: i, onClick: function () { openTask(t); } },
            React.createElement('span', { className: 'dswk-dot', style: { background: DOT[meta.dot] } }),
            React.createElement('div', { className: 'dswk-taskMain' },
              React.createElement('div', { className: 'dswk-taskTitle' },
                wkrLead,
                t.title || (t.conversationId || '').slice(-10)),
              React.createElement('div', { className: 'dswk-taskSub' }, (t.wakerName ? t.wakerName + ' · ' : '') + meta.label + ' · ' + sub +
                (t.sender ? ' · ' + t.sender : ''))),
            React.createElement('span', { className: 'dswk-kv' }, fmtTime(t.updatedAt)),
            ops.length ? React.createElement('div', { className: 'dswk-taskOps' }, ops) : null);
        }));
      }

      return React.createElement('section', { className: 'dswk-card' },
        React.createElement('h3', { className: 'dswk-cardTitle' }, '任务看板'),
        statLine ? React.createElement('span', { className: 'dswk-kv' }, statLine) : null,
        React.createElement('div', { className: 'dswk-seg' }, FILTERS.map(function (f) {
          var count = 0;
          if (f.id === 'all') count = tasks.length;
          else if (stats) count = stats[f.id === 'needs-input' ? 'needsInput' : f.id] || 0;
          return React.createElement('button', {
            key: f.id,
            className: 'dswk-segBtn' + (curFilter === f.id ? ' dswk-segBtnActive' : ''),
            onClick: function () { changeFilter(f.id); }
          }, f.label + ' ' + count);
        })),
        rows,
        pager,
        board && typeof board.queueLen === 'number' && board.cap ?
          React.createElement('span', { className: 'dswk-kv' }, '并发上限 ' + board.cap + ' · 队列 ' + board.queueLen + ' 条待执行') : null,
        note ? React.createElement('p', { className: 'dswk-note ' + (note.kind === 'error' ? 'dswk-noteError' : note.kind === 'warn' ? 'dswk-noteWarn' : 'dswk-noteOk') }, note.text) : null
      );
    }


    // ---- R2: IM 机器人管理 ----
    function ImSection() {
      // 集成模块: 钉钉机器人 = 凭据 + 连接 + 会话映射 全在一处(每机器人一张卡)
      var robotsS = React.useState(null);
      var robots = robotsS[0], setRobots = robotsS[1];
      var errS = React.useState(null);
      var loadErr = errS[0], setLoadErr = errS[1];
      var noteS = React.useState(null);
      var noteVal = noteS[0], setNote = noteS[1];
      var modalS = React.useState(null);
      var form = modalS[0], setForm = modalS[1];
      var busyS = React.useState(false);
      var isBusy = busyS[0], setBusy = busyS[1];
      var pipeS = React.useState(null);
      var pipe = pipeS[0], setPipe = pipeS[1];
      var statusS = React.useState(null);
      var st = statusS[0], setStatus = statusS[1];
      // 运行详情弹窗: 显示某机器人的最近消息 / 会话映射 / 管道遥测(日志调试类信息,卡片只留计数)
      var pipeDetailS = React.useState(null);
      var pipeDetail = pipeDetailS[0], setPipeDetail = pipeDetailS[1];
      var refresh = React.useCallback(function () {
        return api('waker.robots.get').then(function (d) { setRobots(d.robots || []); setLoadErr(null); })
          .catch(function (e) { setLoadErr(String((e && e.message) || e)); });
      }, []);
      var refreshPipeline = function () {
        api('waker.pipelineStatus').then(function (s2) { setPipe(s2); })
          .catch(function (e) { setLoadErr(String((e && e.message) || e)); });
      };
      var refreshStatus = function () {
        api('waker.status').then(function (s3) { setStatus(s3); }).catch(function () {});
      };
      React.useEffect(function () {
        refresh(); refreshPipeline(); refreshStatus();
        var st1 = ctx.timer.interval(refresh, 5000);
        var st2 = ctx.timer.interval(refreshPipeline, 5000);
        var st3 = ctx.timer.interval(refreshStatus, 5000);
        return function () { [st1, st2, st3].forEach(function (f) { if (f) f(); }); };
      }, [refresh]);

      var openNew = function () {
        setForm({ id: '', name: '', clientId: '', secret: '', scopeMode: 'all', scopeConvs: '', enabled: true });
      };
      var openEdit = function (r) {
        setForm({ id: r.id, name: r.name, clientId: r.clientId, secret: '', scopeMode: r.scope && r.scope.mode === 'whitelist' ? 'whitelist' : 'all', scopeConvs: ((r.scope && r.scope.convs) || []).join('\n'), enabled: r.enabled !== false });
      };
      var saveForm = function () {
        if (!form) return;
        setBusy(true); setNote(null);
        var args = {
          id: form.id || undefined, name: form.name, clientId: form.clientId,
          scope: { mode: form.scopeMode, convs: form.scopeConvs.split('\n').map(function (x) { return x.trim(); }).filter(Boolean) },
          enabled: form.enabled
        };
        if (form.secret) args.secret = form.secret;
        api('waker.robots.save', args).then(function (r) {
          setForm(null); setNote({ kind: r.pushNote ? 'warn' : 'ok', text: r.pushNote ? '已保存；应用提示: ' + r.pushNote : '已保存并应用' });
          return refresh();
        }).catch(function (e) { setNote({ kind: 'error', text: String((e && e.message) || e) }); })
          .then(function () { setBusy(false); });
      };
      var toggle = function (r) {
        api('waker.robots.toggle', { id: r.id, enabled: r.enabled === false }).then(refresh)
          .catch(function (e) { setNote({ kind: 'error', text: String((e && e.message) || e) }); });
      };
      var del = function (r) {
        if (!window.confirm('删除机器人 ' + r.name + '？其会话映射将保留为只读。')) return;
        api('waker.robots.delete', { id: r.id }).then(function () {
          setNote({ kind: 'ok', text: '已删除' }); return refresh();
        }).catch(function (e) { setNote({ kind: 'error', text: String((e && e.message) || e) }); });
      };
      var reconnectOne = function (r) {
        setNote({ kind: 'ok', text: '重连 ' + r.name + ' …' });
        api('waker.robots.reconnect', { id: r.id }).then(function () {
          setNote({ kind: 'ok', text: '已发送重连指令' }); return refresh();
        }).catch(function (e) { setNote({ kind: 'error', text: String((e && e.message) || e) }); });
      };
      var diagOne = function (r) {
        setNote({ kind: 'ok', text: '诊断 ' + r.name + ' …（约 4 秒）' });
        api('waker.robots.diag', { id: r.id }).then(function (res) {
          var lines = (res && res.steps || []).map(function (sx) {
            return (sx.ok ? '✅' : '❌') + ' ' + sx.step + '：' + sx.msg;
          });
          setNote({ kind: res && res.phase === 'connected' ? 'ok' : 'error', text: r.name + ' 诊断：\n' + lines.join('\n') });
          return refresh();
        }).catch(function (e) { setNote({ kind: 'error', text: '诊断失败: ' + String((e && e.message) || e) }); });
      };
      var unbind = function (conv) {
        setNote({ kind: 'ok', text: '解绑 ' + conv + ' …' });
        api('waker.mappingUnbind', { conversationId: conv }).then(function () {
          refreshPipeline(); setNote({ kind: 'ok', text: '已解绑' });
        }).catch(function (e) { setNote({ kind: 'error', text: String((e && e.message) || e) }); });
      };
      var phaseLabel = function (p) {
        return p === 'connected' ? '已连接' : p === 'connecting' ? '连接中' : p === 'error' ? '错误' : p === 'absent' ? '未下发' : '断开';
      };
      var dotColor = function (br) {
        if (br.phase === 'connected') return 'var(--dsw-alias-state-success-primary)';
        if (br.phase === 'error') return 'var(--dsw-alias-state-error-primary)';
        return 'var(--dsw-alias-label-tertiary)';
      };
      var rows = robots || [];
      var mappings = (pipe && pipe.mappings) || [];
      var tele = (pipe && pipe.telemetry) || {};
      // 默认机器人兜底: 早期(未带 robotId)的映射挂到 robot-default
      var mapsOf = function (rid) {
        return mappings.filter(function (m) {
          return m.robotId === rid || (rid === 'robot-default' && !m.robotId);
        });
      };
      var bridgeAll = st && st.bridge ? st.bridge : null;

      return React.createElement('div', { className: 'dswk' },
        React.createElement('section', { className: 'dswk-card' },
          React.createElement('div', { className: 'dswk-secHead' },
            React.createElement('h3', { className: 'dswk-cardTitle' }, '钉钉机器人'),
            React.createElement('button', { className: 'dswk-btn dswk-btnPrimary dswk-btnMini', onClick: openNew }, '＋ 新建机器人')),
          React.createElement('div', { className: 'dswk-row' },
            React.createElement('span', { className: 'dswk-kv' },
              '桥接进程 ' + (st ? (st.phase === 'running' ? '运行中' : st.phase) : '…') +
              (bridgeAll ? ' · 全局重连 ' + (bridgeAll.reconnectAttempts || 0) + ' 次' : '') +
              (st && st.lastError ? ' · ' + st.lastError : ''))),
          loadErr ? React.createElement('p', { className: 'dswk-note dswk-noteError' }, loadErr) : null,
          rows.length ? React.createElement('div', null,
            rows.map(function (r) {
              var br = r.bridge || {};
              var ev = r.ev || { seen: 0, lastAt: null, recent: [] };
              var maps = mapsOf(r.id);
              return React.createElement('div', { className: 'dswk-wkCard' + (r.enabled === false ? ' dswk-wkOff' : ''), key: r.id },
                React.createElement('div', { className: 'dswk-wkHead' },
                  React.createElement('span', { className: 'dswk-dot' + (br.phase === 'connecting' ? ' dswk-dotLoading' : ''), style: { background: dotColor(br) } }),
                  React.createElement('span', { className: 'dswk-wkName' }, r.name),
                  React.createElement('span', { className: 'dswk-kv' }, phaseLabel(br.phase)),
                  React.createElement('span', { style: { flex: 1 } }),
                  React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: function () { toggle(r); } }, r.enabled === false ? '启用' : '停用')),
                React.createElement('div', { className: 'dswk-wkMeta' },
                  'ID: ' + r.id + ' · ClientID: ' + String(r.clientId || '未设置').slice(0, 14) +
                  ' · 密钥 ' + (r.hasSecret ? '已设置' : '未设置') +
                  (r.scope && r.scope.mode === 'whitelist' ? ' · 白名单 ' + (r.scope.convs || []).length + ' 会话' : ' · 全部会话')),
                React.createElement('div', { className: 'dswk-wkMeta' },
                  '连接: ' + phaseLabel(br.phase) +
                  (br.reconnectAttempts ? ' · 已重连 ' + br.reconnectAttempts + ' 次' : '') +
                  ' · 收到消息 ' + (ev.seen || 0) + ' 条 · 最近 ' + fmtTime(ev.lastAt) +
                  ' · 会话映射 ' + maps.length + ' 条'),
                br.lastError ? React.createElement('p', { className: 'dswk-wkRole dswk-noteError' }, br.lastError) : null,
                React.createElement('div', { className: 'dswk-row' },
                  React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: function () { openEdit(r); } }, '编辑凭据/范围'),
                  React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: function () { diagOne(r); } }, '诊断'),
                  React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: function () { reconnectOne(r); } }, '重连'),
                  React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: function () { setPipeDetail(r.id); } }, '运行详情'),
                  r.id === 'robot-default' ? null : React.createElement('button', { className: 'dswk-btn dswk-btnDanger dswk-btnMini', onClick: function () { del(r); } }, '删除')));
            })) : React.createElement('p', { className: 'dswk-note' }, '暂无机器人。点击「＋ 新建机器人」填入钉钉应用的 Client ID / Secret 即可连接。'),
          noteVal ? React.createElement('p', { className: 'dswk-note ' + noteClass(noteVal.kind) }, noteVal.text) : null),
        form ? React.createElement('div', { className: 'dswk-overlay', onClick: function (e) { if (e.target === e.currentTarget) setForm(null); } },
          React.createElement('div', { className: 'dswk-modal' },
            React.createElement('div', { className: 'dswk-row', style: { justifyContent: 'space-between' } },
              React.createElement('h3', { className: 'dswk-cardTitle', style: { margin: 0 } }, form.id ? '编辑机器人' : '新建机器人'),
              React.createElement('button', { className: 'dswk-detailClose', title: '关闭', onClick: function () { setForm(null); } }, '✕')),
            React.createElement('div', { className: 'dswk-row' },
              React.createElement('div', { className: 'dswk-field' },
                React.createElement('label', { className: 'dswk-label' }, '名称'),
                React.createElement('input', { className: 'dswk-input', value: form.name, placeholder: '如 客服机器人', onChange: function (e) { setForm(Object.assign({}, form, { name: e.target.value })); } })),
              React.createElement('div', { className: 'dswk-field' },
                React.createElement('label', { className: 'dswk-label' }, 'Client ID（AppKey）'),
                React.createElement('input', { className: 'dswk-input', value: form.clientId, disabled: !!form.id, placeholder: 'ding…', onChange: function (e) { setForm(Object.assign({}, form, { clientId: e.target.value })); } }))),
            React.createElement('div', { className: 'dswk-field' },
              React.createElement('label', { className: 'dswk-label' }, 'Client Secret（AppSecret，' + (form.id ? '留空保持不变' : '必填') + '）'),
              React.createElement('input', { className: 'dswk-input', type: 'password', value: form.secret, placeholder: form.id ? '已设置，留空保持不变' : 'AppSecret', onChange: function (e) { setForm(Object.assign({}, form, { secret: e.target.value })); } })),
            React.createElement('div', { className: 'dswk-row' },
              React.createElement('div', { className: 'dswk-field', style: { maxWidth: 140 } },
                React.createElement('label', { className: 'dswk-label' }, '监听范围'),
                React.createElement('select', { className: 'dswk-select', value: form.scopeMode, onChange: function (e) { setForm(Object.assign({}, form, { scopeMode: e.target.value })); } },
                  React.createElement('option', { value: 'all' }, '全部会话'),
                  React.createElement('option', { value: 'whitelist' }, '白名单')))),
            form.scopeMode === 'whitelist' ? React.createElement('div', { className: 'dswk-field' },
              React.createElement('label', { className: 'dswk-label' }, '会话白名单（每行一个 conversationId）'),
              React.createElement('textarea', { className: 'dswk-textarea', value: form.scopeConvs, onChange: function (e) { setForm(Object.assign({}, form, { scopeConvs: e.target.value })); } })) : null,
            React.createElement('div', { className: 'dswk-row' },
              React.createElement('button', { className: 'dswk-btn dswk-btnPrimary', disabled: isBusy, onClick: saveForm }, '保存'),
              React.createElement('button', { className: 'dswk-btn', onClick: function () { setForm(null); } }, '取消')))) : null,
        pipeDetail ? (function () {
          var dr = rows.filter(function (x) { return x.id === pipeDetail; })[0];
          if (!dr) return null;
          var dev = dr.ev || { seen: 0, lastAt: null, recent: [] };
          var dmaps = mapsOf(dr.id);
          var dbr = dr.bridge || {};
          return React.createElement('div', { className: 'dswk-overlay', onClick: function (e) { if (e.target === e.currentTarget) setPipeDetail(null); } },
            React.createElement('div', { className: 'dswk-modal dswk-modalBind', style: { maxHeight: '86vh', overflowY: 'auto' } },
              React.createElement('div', { className: 'dswk-row', style: { justifyContent: 'space-between' } },
                React.createElement('h3', { className: 'dswk-cardTitle', style: { margin: 0 } }, dr.name + ' · 运行详情'),
                React.createElement('button', { className: 'dswk-detailClose', title: '关闭', onClick: function () { setPipeDetail(null); } }, '✕')),
              React.createElement('div', { className: 'dswk-field' },
                React.createElement('label', { className: 'dswk-label' }, '最近消息（近 ' + Math.min(dev.recent ? dev.recent.length : 0, 5) + ' 条 / 累计 ' + (dev.seen || 0) + '）'),
                dev.recent && dev.recent.length ? dev.recent.slice(-5).reverse().map(function (e2, i2) {
                  return React.createElement('p', { className: 'dswk-mono', key: i2, style: { margin: '0 0 2px' } },
                    fmtTime(e2.t) + (e2.sender ? ' ' + e2.sender : '') + (e2.text ? ' · ' + e2.text : ''));
                }) : React.createElement('p', { className: 'dswk-note' }, '暂无消息。钉钉 @机器人 发送一条消息即可看到。')),
              React.createElement('div', { className: 'dswk-field' },
                React.createElement('label', { className: 'dswk-label' }, '会话映射（' + dmaps.length + ' 条）'),
                dmaps.length ? dmaps.map(function (m, i3) {
                  return React.createElement('div', { className: 'dswk-row', key: i3, style: { alignItems: 'center' } },
                    React.createElement('span', { className: 'dswk-kv', style: { flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } },
                      (m.conversationId || '?').slice(0, 16) + ' → ' + (m.title || String(m.sessionId || '?').replace('waker-conv-', '').slice(0, 10)) +
                      ' · ' + (m.turnCount || 0) + ' 轮 · ' + (m.state || '')),
                    React.createElement('button', { className: 'dswk-btn dswk-btnDanger dswk-btnMini', onClick: function () { unbind(m.conversationId); } }, '解绑'));
                }) : React.createElement('p', { className: 'dswk-note' }, '暂无映射（钉钉发一条消息即可建立）')),
              React.createElement('div', { className: 'dswk-field' },
                React.createElement('label', { className: 'dswk-label' }, '管道遥测'),
                React.createElement('p', { className: 'dswk-wkMeta', style: { margin: '4px 0 0' } },
                  '桥接 ' + phaseLabel(dbr.phase) + (dbr.reconnectAttempts ? '（已重连 ' + dbr.reconnectAttempts + ' 次）' : '') +
                  ' · 静默遥测：@过滤 ' + (tele.atFiltered || 0) +
                  ' · 判定讨论 ' + (tele.judgeSilent || 0) + ' / 判定调用 ' + (tele.judgeCalls || 0) + '（异常 ' + (tele.judgeErrors || 0) + '）' +
                  (st ? ' · 全局事件 ' + (st.eventsSeen || 0) + ' 条' : '')),
                dbr.lastError ? React.createElement('p', { className: 'dswk-wkRole dswk-noteError', style: { margin: '4px 0 0' } }, dbr.lastError) : null)));
        })() : null);
    }

    // ---- R2.5: 项目(来源)模块 ----
    function ProjectsSection() {
      var dataS = React.useState(null);
      var data = dataS[0], setData = dataS[1];
      var noteS = React.useState(null);
      var noteVal = noteS[0], setNote = noteS[1];
      var modalS = React.useState(null);
      var form = modalS[0], setForm = modalS[1];
      var busyS = React.useState(false);
      var isBusy = busyS[0], setBusy = busyS[1];

      var refresh = React.useCallback(function () {
        return api('waker.projects.get').then(function (d) { setData(d); setLoadErr(null); })
          .catch(function (e) { setLoadErr(String((e && e.message) || e)); });
      }, []);
      var errS = React.useState(null);
      var loadErr = errS[0], setLoadErr = errS[1];
      React.useEffect(function () {
        refresh();
        var stop = ctx.timer.interval(refresh, 6000);
        return function () { if (stop) stop(); };
      }, [refresh]);

      var projs = (data && data.projects) || [];
      var wakers = (data && data.wakers) || [];
      var wakerName = function (id) {
        for (var i = 0; i < wakers.length; i++) if (wakers[i].id === id) return wakers[i].name;
        return id;
      };
      var ownerNames = function (p) {
        var ids = (p.ownerWakerIds || []).length ? p.ownerWakerIds : (p.ownerWakerId ? [p.ownerWakerId] : []);
        return ids.map(function (id) { return wakerName(id); });
      };
      var openNew = function () {
        setForm({ id: '', name: '', scope: 'public', ownerWakerIds: [], kind: 'local', path: '', gitUrl: '', branch: 'main' });
        setNote(null);
      };
      // 编辑项目: 预填表单(save 为 upsert,带 id 即更新;git 改地址/分支会重新 clone)
      var openProj = function (p) {
        setForm({
          id: p.id, name: p.name, scope: p.scope || 'public',
          ownerWakerIds: (p.ownerWakerIds || (p.ownerWakerId ? [p.ownerWakerId] : [])).slice(),
          kind: p.kind || 'local', path: p.path || '', gitUrl: p.gitUrl || '', branch: p.branch || 'main'
        });
        setNote(null);
      };
      var pickingS = React.useState(false);
      var picking = pickingS[0], setPicking = pickingS[1];
      var chooseFolder = function () {
        if (picking) return;
        setPicking(true); setNote(null);
        pickFolder().then(function (r) {
          if (r.path) {
            setForm(function (f) { return f ? Object.assign({}, f, { path: r.path }) : f; });
            setNote({ kind: 'ok', text: '已选择: ' + r.path });
          } else if (r.canceled) {
            setNote({ kind: 'warn', text: '已取消选择' });
          }
        }).catch(function (e) {
          setNote({ kind: e && e.unsupported ? 'warn' : 'error', text: String((e && e.message) || e) });
        }).then(function () { setPicking(false); });
      };
      var toggleOwner = function (id) {
        var ids = form.ownerWakerIds.slice();
        var i = ids.indexOf(id);
        if (i === -1) ids.push(id); else ids.splice(i, 1);
        setForm(Object.assign({}, form, { ownerWakerIds: ids }));
      };
      var saveForm = function () {
        if (!form) return;
        setBusy(true); setNote(null);
        var payload = Object.assign({}, form);
        delete payload.ownerWakerId;
        if (form.scope !== 'waker') payload.ownerWakerIds = [];
        api('waker.projects.save', payload).then(function (r) {
          var pr = r && r.project;
          setForm(null);
          if (pr && pr.status === 'error') setNote({ kind: 'error', text: '已保存，但项目不可用: ' + (pr.lastError || '') });
          else setNote({ kind: 'ok', text: '已保存项目' });
          return refresh();
        }).catch(function (e) { setNote({ kind: 'error', text: String((e && e.message) || e) }); })
          .then(function () { setBusy(false); });
      };
      var del = function (p) {
        if (!window.confirm('删除项目 ' + p.name + '？（Git 项目保留本地克隆目录，仅删除登记）')) return;
        api('waker.projects.delete', { id: p.id }).then(function () {
          setNote({ kind: 'ok', text: '已删除' }); return refresh();
        }).catch(function (e) { setNote({ kind: 'error', text: String((e && e.message) || e) }); });
      };
      var refreshOne = function (p) {
        setNote({ kind: 'ok', text: '拉取 ' + p.name + ' …' });
        api('waker.projects.refresh', { id: p.id }).then(function (r) {
          setNote({ kind: (r && r.project && r.project.status === 'error') ? 'error' : 'ok', text: (r && r.note) ? r.note : '已更新' });
          return refresh();
        }).catch(function (e) { setNote({ kind: 'error', text: String((e && e.message) || e) }); });
      };

      return React.createElement('section', { className: 'dswk-card' },
        React.createElement('div', { className: 'dswk-secHead' },
          React.createElement('h3', { className: 'dswk-cardTitle' }, '项目（代码来源）'),
          React.createElement('button', { className: 'dswk-btn dswk-btnPrimary dswk-btnMini', onClick: openNew }, '＋ 添加项目')),
        loadErr ? React.createElement('p', { className: 'dswk-note dswk-noteError' }, loadErr) : null,
        projs.length ? React.createElement('div', null,
          projs.map(function (p) {
            var dot = p.status === 'error' ? 'var(--dsw-alias-state-error-primary)' : p.kind === 'git' ? 'var(--dsw-alias-state-warn-primary)' : 'var(--dsw-alias-state-success-primary)';
            return React.createElement('div', { className: 'dswk-wkCard', key: p.id },
              React.createElement('div', { className: 'dswk-wkHead' },
                React.createElement('span', { className: 'dswk-dot', style: { background: dot } }),
                React.createElement('span', { className: 'dswk-wkName' }, p.name),
                React.createElement('span', { className: 'dswk-badge' }, p.kind === 'git' ? 'Git 仓库' : '本地路径'),
                React.createElement('span', { className: 'dswk-badge' }, p.scope === 'waker' ? ('Waker: ' + ownerNames(p).join('、')) : '公开'),
                React.createElement('span', { style: { flex: 1 } })),
              p.kind === 'git'
                ? React.createElement('div', { className: 'dswk-wkRole' }, p.gitUrl + (p.branch ? ' @ ' + p.branch : '') + ' → ' + (p.localPath || ''))
                : React.createElement('div', { className: 'dswk-wkRole' }, p.path || ''),
              p.status === 'error' ? React.createElement('p', { className: 'dswk-wkRole dswk-noteError' }, '不可用: ' + (p.lastError || '')) : null,
              React.createElement('div', { className: 'dswk-row' },
                React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: function () { openProj(p); } }, '编辑'),
                React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: function () { refreshOne(p); } }, '拉取最新'),
                React.createElement('button', { className: 'dswk-btn dswk-btnDanger dswk-btnMini', onClick: function () { del(p); } }, '删除')));
          })) : React.createElement('p', { className: 'dswk-note' }, '暂无项目。点击「＋ 添加项目」登记本地路径或 Git 仓库。'),
        noteVal ? React.createElement('p', { className: 'dswk-note ' + noteClass(noteVal.kind) }, noteVal.text) : null,
        form ? React.createElement('div', { className: 'dswk-overlay', onClick: function (e) { if (e.target === e.currentTarget) setForm(null); } },
          React.createElement('div', { className: 'dswk-modal' },
            React.createElement('div', { className: 'dswk-row', style: { justifyContent: 'space-between' } },
              React.createElement('h3', { className: 'dswk-cardTitle', style: { margin: 0 } }, form.id ? '编辑项目' : '添加项目'),
              React.createElement('button', { className: 'dswk-detailClose', title: '关闭', onClick: function () { setForm(null); } }, '✕')),
            React.createElement('div', { className: 'dswk-row' },
              React.createElement('div', { className: 'dswk-field', style: { maxWidth: 100 } },
                React.createElement('label', { className: 'dswk-label' }, '类型'),
                React.createElement('select', { className: 'dswk-select', value: form.kind, onChange: function (e) { setForm(Object.assign({}, form, { kind: e.target.value })); } },
                  React.createElement('option', { value: 'local' }, '本地路径'),
                  React.createElement('option', { value: 'git' }, 'Git 仓库'))),
              React.createElement('div', { className: 'dswk-field' },
                React.createElement('label', { className: 'dswk-label' }, '名称'),
                React.createElement('input', { className: 'dswk-input', value: form.name, placeholder: '如 dsh-waker 主仓库', onChange: function (e) { setForm(Object.assign({}, form, { name: e.target.value })); } }))),
            React.createElement('div', { className: 'dswk-row' },
              React.createElement('div', { className: 'dswk-field', style: { maxWidth: 160 } },
                React.createElement('label', { className: 'dswk-label' }, '可见范围'),
                React.createElement('select', { className: 'dswk-select', value: form.scope, onChange: function (e) { setForm(Object.assign({}, form, { scope: e.target.value })); } },
                  React.createElement('option', { value: 'public' }, '公开（所有 Waker）'),
                  React.createElement('option', { value: 'waker' }, '仅指定 Waker'))),
              form.scope === 'waker' ? React.createElement('div', { className: 'dswk-field' },
                React.createElement('label', { className: 'dswk-label' }, '可用 Waker（可多选）'),
                React.createElement('div', { className: 'dswk-row' },
                  wakers.map(function (w) {
                    var on = form.ownerWakerIds.indexOf(w.id) !== -1;
                    return React.createElement('label', { className: 'dswk-check', key: w.id },
                      React.createElement('input', { type: 'checkbox', checked: on, onChange: function () { toggleOwner(w.id); } }),
                      w.avatar ? React.createElement('img', { className: 'dswk-checkImg', src: imgUrl(w.avatar), alt: '' }) : React.createElement('span', { className: 'dswk-checkEmoji' }, w.emoji || '🤖'),
                      w.name);
                  }))) : null),
            form.kind === 'local'
              ? React.createElement('div', { className: 'dswk-field' },
                React.createElement('label', { className: 'dswk-label' }, '本地路径（已存在目录）'),
                React.createElement('div', { className: 'dswk-pathRow' },
                  React.createElement('input', { className: 'dswk-input', value: form.path, placeholder: '/Users/me/projects/xxx', onChange: function (e) { setForm(Object.assign({}, form, { path: e.target.value })); } }),
                  React.createElement('button', { className: 'dswk-btn dswk-btnMini', disabled: picking, title: '弹出系统文件夹选择', onClick: chooseFolder }, picking ? '选择中…' : '选择…')))
              : React.createElement('div', { className: 'dswk-row' },
                React.createElement('div', { className: 'dswk-field' },
                  React.createElement('label', { className: 'dswk-label' }, 'Git 仓库地址'),
                  React.createElement('input', { className: 'dswk-input', value: form.gitUrl, placeholder: 'git@… 或 https://…', onChange: function (e) { setForm(Object.assign({}, form, { gitUrl: e.target.value })); } })),
                React.createElement('div', { className: 'dswk-field', style: { maxWidth: 150 } },
                  React.createElement('label', { className: 'dswk-label' }, '分支'),
                  React.createElement('input', { className: 'dswk-input', value: form.branch, placeholder: 'main', onChange: function (e) { setForm(Object.assign({}, form, { branch: e.target.value })); } }))),
            React.createElement('div', { className: 'dswk-row' },
              React.createElement('button', { className: 'dswk-btn dswk-btnPrimary', disabled: isBusy, onClick: saveForm }, '保存'),
              React.createElement('button', { className: 'dswk-btn', onClick: function () { setForm(null); } }, '取消')))) : null);
    }

    // ---- Waker 详情(左侧类目 + 档案/项目/任务看板) ----
    function WakerDetail(props) {
      var w = props.waker;
      var projects = props.projects || [];
      var wakers = props.wakers || [];
      var catS = React.useState('profile');
      var cat = catS[0], setCat = catS[1];
      var bdS = React.useState(null);
      var board = bdS[0], setBoard = bdS[1];
      var pmS = React.useState(null);
      var pform = pmS[0], setPform = pmS[1];
      var pbusyS = React.useState(false);
      var pbusy = pbusyS[0], setPbusy = pbusyS[1];
      var pnoteS = React.useState(null);
      var pnote = pnoteS[0], setPnote = pnoteS[1];
      var wakerName = function (id) {
        for (var i = 0; i < wakers.length; i++) if (wakers[i].id === id) return wakers[i].name;
        return id;
      };
      var projName = function (id) {
        for (var i = 0; i < projects.length; i++) if (projects[i].id === id) return projects[i].name;
        return id || '';
      };
      // 该 Waker 可见/所属项目(公开 或 属主含本 waker)
      var owned = projects.filter(function (pr) {
        if (pr.scope !== 'waker') return true;
        var ids = pr.ownerWakerIds || (pr.ownerWakerId ? [pr.ownerWakerId] : []);
        return ids.indexOf(w.id) !== -1;
      });
      // 任务看板: 只拉一次, 按 wakerId 过滤
      React.useEffect(function () {
        if (cat !== 'tasks') return;
        api('waker.getBoardData').then(function (d) { setBoard(d); }).catch(function () {});
      }, [cat]);
      var SIDE = [
        { id: 'profile', label: '档案' },
        { id: 'projects', label: '项目' },
        { id: 'caps', label: '能力' },
        { id: 'tasks', label: '任务看板' }
      ];
      // ---- 项目 新增/编辑/删除(同步 waker.projects.*, 与项目管理共用存储;save 为 upsert,带 id 即更新) ----
      var openProject = function (pr) {
        setPform(pr ? {
          id: pr.id, name: pr.name, scope: pr.scope || 'public',
          ownerWakerIds: (pr.ownerWakerIds || (pr.ownerWakerId ? [pr.ownerWakerId] : [])).slice(),
          kind: pr.kind || 'local', path: pr.path || '', gitUrl: pr.gitUrl || '', branch: pr.branch || 'main'
        } : { id: '', name: '', scope: 'public', ownerWakerIds: [], kind: 'local', path: '', gitUrl: '', branch: 'main' });
        setPnote(null);
      };
      var pPickingS = React.useState(false);
      var pPicking = pPickingS[0], setPPicking = pPickingS[1];
      var chooseFolderP = function () {
        if (pPicking) return;
        setPPicking(true); setPnote(null);
        pickFolder().then(function (r) {
          if (r.path) {
            setPform(function (f) { return f ? Object.assign({}, f, { path: r.path }) : f; });
            setPnote({ kind: 'ok', text: '已选择: ' + r.path });
          } else if (r.canceled) {
            setPnote({ kind: 'warn', text: '已取消选择' });
          }
        }).catch(function (e) {
          setPnote({ kind: e && e.unsupported ? 'warn' : 'error', text: String((e && e.message) || e) });
        }).then(function () { setPPicking(false); });
      };
      var togglePOwner = function (id) {
        var ids = pform.ownerWakerIds.slice();
        var i = ids.indexOf(id);
        if (i === -1) ids.push(id); else ids.splice(i, 1);
        setPform(Object.assign({}, pform, { ownerWakerIds: ids }));
      };
      var saveProject = function () {
        if (!pform) return;
        setPbusy(true); setPnote(null);
        var payload = Object.assign({}, pform);
        delete payload.ownerWakerId;
        if (pform.scope !== 'waker') payload.ownerWakerIds = [];
        api('waker.projects.save', payload).then(function (r) {
          var pr = r && r.project;
          setPform(null);
          setPnote({ kind: (pr && pr.status === 'error') ? 'error' : 'ok', text: (pr && pr.status === 'error') ? ('已保存，但项目不可用: ' + (pr.lastError || '')) : ((pform && pform.id) ? '已更新项目' : '已新增项目') });
          props.onProjectsChanged();
        }).catch(function (e) { setPnote({ kind: 'error', text: String((e && e.message) || e) }); })
          .then(function () { setPbusy(false); });
      };
      var removeProject = function (pr) {
        if (!window.confirm('删除项目 ' + pr.name + '？（Git 项目保留本地克隆目录，仅删除登记）')) return;
        api('waker.projects.delete', { id: pr.id }).then(function () {
          setPnote({ kind: 'ok', text: '已删除项目' });
          props.onProjectsChanged();
        }).catch(function (e) { setPnote({ kind: 'error', text: String((e && e.message) || e) }); });
      };
      var ownerNames = function (pr) {
        var ids = (pr.ownerWakerIds || []).length ? pr.ownerWakerIds : (pr.ownerWakerId ? [pr.ownerWakerId] : []);
        return ids.map(function (id) { return wakerName(id); });
      };
      // ---- 能力页签: 从 DSH 全局目录选用(引用式,不安装);null=继承 standard 全量 ----
      var capsCatS = React.useState(null); // catalog 数据 {builtinGroups, mcpServers, skills}
      var capsCat = capsCatS[0], setCapsCat = capsCatS[1];
      var capsEditS = React.useState(null); // 编辑态 {builtinGroups|null, mcpServers|null, mcpTools|null, skills|null}
      var capsEdit = capsEditS[0], setCapsEdit = capsEditS[1];
      var capsBusyS = React.useState(false);
      var capsBusy = capsBusyS[0], setCapsBusy = capsBusyS[1];
      var capsNoteS = React.useState(null);
      var capsNote = capsNoteS[0], setCapsNote = capsNoteS[1];
      var capsOpenS = React.useState({}); // server 折叠态
      var capsOpen = capsOpenS[0], setCapsOpen = capsOpenS[1];
      var capsQueryS = React.useState({ mcp: '', skills: '' }); // 搜索过滤(MCP/技能)
      var capsQuery = capsQueryS[0], setCapsQuery = capsQueryS[1];
      React.useEffect(function () {
        if (cat !== 'caps') return;
        setCapsNote(null);
        api('waker.capabilities.catalog').then(function (d) { setCapsCat(d || {}); }).catch(function (e) {
          setCapsCat({}); setCapsNote({ kind: 'error', text: '能力目录加载失败: ' + String((e && e.message) || e) });
        });
      }, [cat, w.id]);
      var capsToggleList = function (key, val) {
        var cur = capsEdit[key];
        var next = cur === null ? [val] : (cur.indexOf(val) === -1 ? cur.concat([val]) : cur.filter(function (x) { return x !== val; }));
        var upd = Object.assign({}, capsEdit);
        upd[key] = next;
        // 联动: 全量(null) ↔ 任意勾选进入白名单态
        setCapsEdit(upd);
      };
      var capsGroupOn = function (gid) {
        if (!capsEdit || capsEdit.builtinGroups === null) return true; // 全量
        return capsEdit.builtinGroups.indexOf(gid) !== -1;
      };
      var capsServerOn = function (sname) {
        if (!capsEdit) return false;
        if (capsEdit.mcpServers === null && capsEdit.mcpTools === null) return true;
        var srv = capsEdit.mcpServers === null ? [] : capsEdit.mcpServers;
        if (srv.indexOf(sname) !== -1) return true;
        var tools = capsEdit.mcpTools || [];
        var any = false;
        (capsCat && capsCat.mcpServers || []).forEach(function (s) {
          if (s.name !== sname) return;
          s.tools.forEach(function (t) { if (tools.indexOf(t.name) !== -1) any = true; });
        });
        return any;
      };
      var capsToolOn = function (toolName, sname) {
        if (!capsEdit) return false;
        if (capsEdit.mcpServers !== null && capsEdit.mcpServers.indexOf(sname) !== -1) return true;
        if (capsEdit.mcpTools === null) return capsEdit.mcpServers === null;
        return capsEdit.mcpTools.indexOf(toolName) !== -1;
      };
      var capsToggleServer = function (sname) {
        var srv = capsEdit.mcpServers === null ? [] : capsEdit.mcpServers.slice();
        var tools = capsEdit.mcpTools === null ? null : capsEdit.mcpTools.slice();
        var on = capsServerOn(sname);
        if (on) {
          // 关: 移除 server 级白名单;若原本 mcpTools=null(全量),该 server 下工具以「排除名单」方式留在工具级,
          // 即从全量中仅摘掉该 server —— 其余 server 工具以 mcpTools=null 保持全量
          var i = srv.indexOf(sname);
          if (i !== -1) srv.splice(i, 1);
          if (tools !== null) {
            (capsCat && capsCat.mcpServers || []).forEach(function (s) {
              if (s.name !== sname) return;
              s.tools.forEach(function (t) { var ti = tools.indexOf(t.name); if (ti !== -1) tools.splice(ti, 1); });
            });
          }
        } else {
          // 开: server 级整开;该 server 下的工具级残留移除(server 级优先)
          srv.push(sname);
          if (tools !== null) {
            (capsCat && capsCat.mcpServers || []).forEach(function (s) {
              if (s.name !== sname) return;
              s.tools.forEach(function (t) { var ti = tools.indexOf(t.name); if (ti !== -1) tools.splice(ti, 1); });
            });
          }
        }
        var upd = Object.assign({}, capsEdit, { mcpServers: srv, mcpTools: tools });
        // 空数组 = 白名单清空(全部关闭), 语义保留;回到全量须用「全量」按钮(置 null)
        setCapsEdit(upd);
      };
      var capsToggleTool = function (toolName, sname) {
        var tools = capsEdit.mcpTools === null ? [] : capsEdit.mcpTools.slice();
        var srv = capsEdit.mcpServers === null ? [] : capsEdit.mcpServers.slice();
        var on = capsToolOn(toolName, sname);
        if (on) {
          if (capsEdit.mcpServers !== null && capsEdit.mcpServers.indexOf(sname) !== -1) {
            // 从「server 整开」转「工具级白名单」: 该 server 其余工具逐个列入工具级
            var si = srv.indexOf(sname);
            if (si !== -1) srv.splice(si, 1);
            (capsCat && capsCat.mcpServers || []).forEach(function (s) {
              if (s.name !== sname) return;
              s.tools.forEach(function (t) { if (t.name !== toolName && tools.indexOf(t.name) === -1) tools.push(t.name); });
            });
          } else {
            var ti = tools.indexOf(toolName);
            if (ti !== -1) tools.splice(ti, 1);
          }
        } else {
          tools.push(toolName);
        }
        var upd = Object.assign({}, capsEdit, { mcpServers: srv, mcpTools: tools });
        // 空数组语义保留(全部关闭);回全量走「全量」按钮
        setCapsEdit(upd);
      };
      var capsSkillOn = function (name) {
        if (!capsEdit) return false;
        if (capsEdit.skills === null) return true;
        return capsEdit.skills.indexOf(name) !== -1;
      };
      // ---- 批量操作与搜索(量大后逐个勾选不可操作) ----
      var capsSetQuery = function (key, val) { setCapsQuery(Object.assign({}, capsQuery, (function () { var o = {}; o[key] = val; return o; })())); };
      var capsMatch = function (q, s) { return !q || String(s || '').toLowerCase().indexOf(String(q).toLowerCase()) !== -1; };
      var capsFilteredServers = function () {
        var q = capsQuery.mcp || '';
        return (capsCat && capsCat.mcpServers || []).filter(function (s) {
          if (capsMatch(q, s.name)) return true;
          return (s.tools || []).some(function (t) { return capsMatch(q, t.tool) || capsMatch(q, t.description); });
        });
      };
      var capsFilteredSkills = function () {
        var q = capsQuery.skills || '';
        return (capsCat && capsCat.skills || []).filter(function (sk) {
          return capsMatch(q, sk.name) || capsMatch(q, sk.displayName) || capsMatch(q, sk.description);
        });
      };
      var capsSectionStatus = function (uiKey) {
        var key = uiKey === 'mcp' ? 'mcpServers' : (uiKey === 'groups' ? 'builtinGroups' : uiKey);
        var v = capsEdit ? capsEdit[key] : null;
        if (v === null) return '全量（未限制）';
        if (!v.length) return '已全部关闭';
        return '白名单 ' + v.length + ' 项';
      };
      // mode: 'all'=筛选结果全选(白名单态下并入) | 'none'=筛选结果清空(白名单态下剔除;全量态下物化为补集)
      //       | 'full'=整区回全量(null)
      var capsBatchList = function (key, filteredNames) {
        var upd = Object.assign({}, capsEdit);
        return function (mode) {
          if (mode === 'full') { upd[key] = null; setCapsEdit(Object.assign({}, upd)); return; }
          var cur = capsEdit[key];
          if (mode === 'all') {
            if (cur === null) return; // 本就全量, 全选为空操作
            var next = cur.slice();
            filteredNames.forEach(function (n) { if (next.indexOf(n) === -1) next.push(n); });
            upd[key] = next;
          } else {
            if (cur === null) {
              // 全量 → 物化为补集(未被筛掉的保持启用), 被筛掉的关闭
              var all = [];
              if (key === 'skills') all = (capsCat && capsCat.skills || []).map(function (s) { return s.name; });
              else all = (capsCat && capsCat.mcpServers || []).map(function (s) { return s.name; });
              upd[key] = all.filter(function (n) { return filteredNames.indexOf(n) === -1; });
            } else {
              upd[key] = cur.filter(function (n) { return filteredNames.indexOf(n) === -1; });
            }
          }
          setCapsEdit(Object.assign({}, upd));
        };
      };
      var capsBatchSkills = function (mode) {
        capsBatchList('skills', capsFilteredSkills().map(function (s) { return s.name; }))(mode);
      };
      var capsBatchMcp = function (mode) {
        var filtered = capsFilteredServers().map(function (s) { return s.name; });
        if (mode === 'full') {
          setCapsEdit(Object.assign({}, capsEdit, { mcpServers: null, mcpTools: null }));
          return;
        }
        var srvBatch = capsBatchList('mcpServers', filtered);
        srvBatch(mode);
        // 清空筛选掉的 server 时, 同步剔除其工具级白名单(避免残留不可见引用)
        if (mode === 'none') {
          setCapsEdit(function (prev) {
            var tools = prev.mcpTools === null ? null : prev.mcpTools.slice();
            if (tools !== null) {
              (capsCat && capsCat.mcpServers || []).forEach(function (s) {
                if (filtered.indexOf(s.name) === -1) return;
                s.tools.forEach(function (t) { var i = tools.indexOf(t.name); if (i !== -1) tools.splice(i, 1); });
              });
            }
            return Object.assign({}, prev, { mcpTools: tools });
          });
        }
      };
      var capsBatchGroups = function (mode) {
        // 与其它区同模式: 'all'=显式全选(含锁定组,恒装不受影响) | 'none'=仅必选 | 'full'=回全量
        if (mode === 'full') { setCapsEdit(Object.assign({}, capsEdit, { builtinGroups: null })); return; }
        if (mode === 'none') { setCapsEdit(Object.assign({}, capsEdit, { builtinGroups: [] })); return; }
        var all = groups.map(function (g) { return g.id; });
        setCapsEdit(Object.assign({}, capsEdit, { builtinGroups: all }));
      };
      var openCapsEdit = function () {
        setCapsEdit({
          builtinGroups: w.capabilities ? (w.capabilities.builtinGroups === null ? null : (w.capabilities.builtinGroups || []).slice()) : null,
          mcpServers: w.capabilities ? (w.capabilities.mcpServers === null ? null : (w.capabilities.mcpServers || []).slice()) : null,
          mcpTools: w.capabilities ? (w.capabilities.mcpTools === null ? null : (w.capabilities.mcpTools || []).slice()) : null,
          skills: w.capabilities ? (w.capabilities.skills === null ? null : (w.capabilities.skills || []).slice()) : null
        });
        setCapsQuery({ mcp: '', skills: '' });
        setCapsNote(null);
      };
      var saveCaps = function () {
        if (!capsEdit) return;
        setCapsBusy(true); setCapsNote(null);
        api('waker.wakers.save', Object.assign({}, w, { capabilities: capsEdit })).then(function (r) {
          setCapsEdit(null);
          setCapsNote({ kind: 'ok', text: '能力配置已保存，对新建会话生效' });
          if (props.onWakerChanged) props.onWakerChanged(r && r.waker);
          if (r && r.waker && props.onWakerUpdated) props.onWakerUpdated(r.waker);
        }).catch(function (e) { setCapsNote({ kind: 'error', text: String((e && e.message) || e) }); })
          .then(function () { setCapsBusy(false); });
      };
      var capsBody = null;
      if (!capsCat) {
        capsBody = React.createElement('p', { className: 'dswk-note' }, '加载中…');
      } else {
        var groups = capsCat.builtinGroups || [];
        var mcpSrvs = capsCat.mcpServers || [];
        var skills = capsCat.skills || [];
        var capRow = function (on, label, sub, locked, onToggle) {
          return React.createElement('label', { className: 'dswk-capRow' + (locked ? ' dswk-capLocked' : ''), key: label },
            React.createElement('input', { type: 'checkbox', checked: on, disabled: locked || !capsEdit, onChange: onToggle }),
            React.createElement('span', { className: 'dswk-capMain' },
              React.createElement('span', { className: 'dswk-capLabel' }, label),
              sub ? React.createElement('span', { className: 'dswk-capSub' }, sub) : null),
            locked ? React.createElement('span', { className: 'dswk-badge' }, '必选') : null);
        };
        // 区工具栏: 状态 + 搜索(可选) + 批量按钮(作用于当前筛选结果)
        var capBar = function (key, placeholder, withSearch, batch) {
          var q = capsQuery[key] || '';
          return React.createElement('div', { className: 'dswk-capBar', key: key },
            withSearch ? React.createElement('input', {
              className: 'dswk-input dswk-capSearch', placeholder: placeholder, value: q,
              onChange: function (e) { capsSetQuery(key, e.target.value); }
            }) : null,
            React.createElement('span', { className: 'dswk-capStatus' }, capsSectionStatus(key)),
            React.createElement('button', { className: 'dswk-btn dswk-btnMini', title: '将当前筛选结果全部加入白名单', onClick: function () { batch('all'); } }, '全选'),
            React.createElement('button', { className: 'dswk-btn dswk-btnMini', title: '将当前筛选结果从白名单移除', onClick: function () { batch('none'); } }, '清空'),
            React.createElement('button', { className: 'dswk-btn dswk-btnMini', title: '本区恢复不限制（继承全量）', onClick: function () { batch('full'); } }, '全量'));
        };
        var capEmptyNote = function (kind) {
          var q = capsQuery[kind.key] || '';
          if (!kind.total) return React.createElement('p', { className: 'dswk-note', key: kind.key }, kind.noneText);
          return React.createElement('p', { className: 'dswk-note', key: kind.key }, '无匹配项（共 ' + kind.total + ' 项）。');
        };
        capsBody = React.createElement('div', { className: 'dswk-secGroup' },
          React.createElement('p', { className: 'dswk-note' },
            '能力安装统一在 DSH 全局完成（Skills 目录 / MCP 设置），此处仅管理本 Waker 启用哪些。不配置 = 继承 standard 全量；配置后仅白名单进入会话上下文。修改对新建会话生效，运行中会话不受影响。'),
          React.createElement('div', { className: 'dswk-secHead' },
            React.createElement('h3', { className: 'dswk-cardTitle' }, '能力配置'),
            capsEdit === null
              ? React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: openCapsEdit }, '配置')
              : [
                React.createElement('button', { className: 'dswk-btn dswk-btnPrimary dswk-btnMini', key: 'save', disabled: capsBusy, onClick: saveCaps }, capsBusy ? '保存中…' : '保存'),
                React.createElement('button', { className: 'dswk-btn dswk-btnMini', key: 'cancel', disabled: capsBusy, onClick: function () { setCapsEdit(null); } }, '取消')
              ]),
          capsNote ? React.createElement('p', { className: 'dswk-note ' + noteClass(capsNote.kind) }, capsNote.text) : null,
          !capsEdit && (w.capabilities
            ? React.createElement('p', { className: 'dswk-note dswk-noteOk' }, '已启用专属能力白名单')
            : React.createElement('p', { className: 'dswk-note' }, '当前继承 standard 全量，未做裁剪')),
          capsEdit ? React.createElement(React.Fragment, null,
            React.createElement('h4', { className: 'dswk-capHeading' }, '内置能力组'),
            capBar('groups', '', false, capsBatchGroups),
            React.createElement('div', { className: 'dswk-capList' },
              groups.map(function (g) {
                return capRow(capsGroupOn(g.id), g.label, g.desc, g.locked, function () { capsToggleList('builtinGroups', g.id); });
              })),
            React.createElement('h4', { className: 'dswk-capHeading' }, 'MCP 工具'),
            capBar('mcp', '搜索 server / 工具 / 描述', true, capsBatchMcp),
            mcpSrvs.length ? (capsFilteredServers().length ? React.createElement('div', { className: 'dswk-capList' },
              capsFilteredServers().map(function (s) {
                var open = !!capsOpen[s.name];
                var toggleOpen = function () {
                  var nextOpen = Object.assign({}, capsOpen);
                  nextOpen[s.name] = !open;
                  setCapsOpen(nextOpen);
                };
                return React.createElement('div', { key: s.name, className: 'dswk-capSrv' },
                  React.createElement('div', { className: 'dswk-capSrvHead' },
                    capRow(capsServerOn(s.name), s.name, s.tools.length + ' 个工具', false, function () { capsToggleServer(s.name); }),
                    React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: toggleOpen }, open ? '收起' : '展开')),
                  open ? React.createElement('div', { className: 'dswk-capList dswk-capTools' },
                    s.tools.map(function (t) {
                      return capRow(capsToolOn(t.name, s.name), t.tool, t.description, false, function () { capsToggleTool(t.name, s.name); });
                    })) : null);
              })) : capEmptyNote({ key: 'mcp', total: mcpSrvs.length })) : React.createElement('p', { className: 'dswk-note' }, '全局尚未安装 MCP server。请在 DSH 全局设置中添加后再到这里选用。'),
            React.createElement('h4', { className: 'dswk-capHeading' }, '技能'),
            capBar('skills', '搜索技能（名称 / 描述）', true, capsBatchSkills),
            skills.length ? (capsFilteredSkills().length ? React.createElement('div', { className: 'dswk-capList' },
              capsFilteredSkills().map(function (sk) {
                return capRow(capsSkillOn(sk.name), sk.name, sk.description, false, function () { capsToggleList('skills', sk.name); });
              })) : capEmptyNote({ key: 'skills', total: skills.length })) : React.createElement('p', { className: 'dswk-note' }, '全局暂无已安装技能。请在 DSH 全局技能目录安装后再到这里选用。'),
            React.createElement('p', { className: 'dswk-note' }, '项目级技能随任务项目自动可用，无需在此配置。')) : null);
      }
      var body = null;
      if (cat === 'profile') {
        var kvRow = function (k, v) {
          return React.createElement('div', { className: 'dswk-defRow' },
            React.createElement('span', { className: 'dswk-defK' }, k),
            React.createElement('span', { className: 'dswk-defV' }, v));
        };
        var kvRowNode = function (k, vnode) {
          return React.createElement('div', { className: 'dswk-defRow' },
            React.createElement('span', { className: 'dswk-defK' }, k),
            React.createElement('span', { className: 'dswk-defV' }, vnode));
        };
        var stateDot = w.enabled === false ? 'var(--dsw-alias-label-tertiary)' : 'var(--dsw-alias-state-success-primary)';
        body = React.createElement('div', { className: 'dswk-secGroup' },
          React.createElement('div', { className: 'dswk-secHead' },
            React.createElement('h3', { className: 'dswk-cardTitle' }, '档案'),
            React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: props.onEdit }, '编辑')),
          React.createElement('div', { className: 'dswk-def' },
            kvRow('身份', w.builtin ? '预置 Waker' : '自定义 Waker'),
            kvRow('职能', w.role || '-'),
            kvRow('预设', w.presetId || '(default)'),
            kvRow('触发词', (w.triggers || []).join('、') || '无'),
            kvRow('并发', String(w.concurrencyShare || 1) + ' / 5'),
            kvRowNode('状态', React.createElement('span', { className: 'dswk-statusVal' },
              React.createElement('span', { className: 'dswk-dot', style: { background: stateDot } }),
              w.enabled === false ? '已停用' : '启用中')),
            kvRow('系统补充', w.systemExtra || '无')));
      } else if (cat === 'caps') {
        body = capsBody;
      } else if (cat === 'projects') {
        body = React.createElement('div', { className: 'dswk-secGroup' },
          React.createElement('div', { className: 'dswk-secHead' },
            React.createElement('h3', { className: 'dswk-cardTitle' }, '可见项目'),
            React.createElement('button', { className: 'dswk-btn dswk-btnPrimary dswk-btnMini', onClick: function () { openProject(null); } }, '新增')),
          pnote ? React.createElement('p', { className: 'dswk-note ' + (pnote.kind === 'error' ? 'dswk-noteError' : '') }, pnote.text) : null,
          owned.length ? React.createElement('div', { className: 'dswk-details' },
            owned.map(function (pr) {
              var ids = pr.ownerWakerIds || (pr.ownerWakerId ? [pr.ownerWakerId] : []);
              var meta = pr.kind === 'git'
                ? (pr.gitUrl || '') + (pr.branch ? ' @ ' + pr.branch : '') + (pr.localPath ? ' → ' + pr.localPath : '')
                : (pr.path || '(未填写路径)');
              return React.createElement('div', { key: pr.id, className: 'dswk-projRow' },
                React.createElement('div', { className: 'dswk-projRowHead' },
                  React.createElement('span', { className: 'dswk-wkName' }, pr.name),
                  React.createElement('span', { className: 'dswk-badge' }, pr.kind === 'git' ? 'Git 仓库' : '本地路径'),
                  React.createElement('span', { className: 'dswk-badge' }, pr.scope === 'waker' ? ('Waker: ' + ids.map(wakerName).join('、')) : '公开'),
                  pr.status === 'error' ? React.createElement('span', { className: 'dswk-badge', style: { color: 'var(--dsw-alias-state-error-primary)' } }, '不可用') : null,
                  React.createElement('span', { style: { flex: 1 } }),
                  React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: function () { openProject(pr); } }, '编辑'),
                  React.createElement('button', { className: 'dswk-btn dswk-btnDanger dswk-btnMini', onClick: function () { removeProject(pr); } }, '删除')),
                React.createElement('div', { className: 'dswk-projMeta' + (pr.status === 'error' ? ' dswk-noteError' : ''), title: meta }, meta),
                pr.status === 'error' && pr.lastError ? React.createElement('div', { className: 'dswk-projMeta dswk-noteError', title: pr.lastError }, pr.lastError) : null);
            })) : React.createElement('p', { className: 'dswk-note' }, '暂无可见项目。可点击「新增」登记本地路径或 Git 仓库。'));
      } else {
        var tasks = (board && board.tasks) ? board.tasks.filter(function (t) { return t.wakerId === w.id; }) : null;
        var locateRow = function (t) {
          locateSession(t, setPnote);
        };
        body = tasks === null ? React.createElement('p', { className: 'dswk-note' }, '加载中…')
          : tasks.length ? React.createElement('div', { className: 'dswk-details' },
            tasks.map(function (t) {
              return React.createElement('div', { key: t.conversationId, className: 'dswk-taskRow', style: { cursor: 'pointer' }, title: '点击定位到该任务的会话', onClick: function () { locateRow(t); } },
                React.createElement('span', { className: 'dswk-wkName' }, t.title || '(未命名任务)'),
                React.createElement('span', { className: 'dswk-kv' }, t.state + ' · ' + t.turnCount + ' 轮'),
                React.createElement('span', { style: { flex: 1 } }),
                React.createElement('span', { className: 'dswk-kv' }, fmtTime(t.updatedAt)));
            })) : React.createElement('p', { className: 'dswk-note' }, '该 Waker 暂无任务记录');
      }
      return React.createElement('div', { className: 'dswk-detailOverlay', onClick: function (e) { if (e.target === e.currentTarget) props.onClose(); } },
        React.createElement('div', { className: 'dswk-detailModal' },
          React.createElement('div', { className: 'dswk-detailSide' },
            React.createElement('div', { className: 'dswk-detailSideTitle' }, 'Waker 详情'),
            SIDE.map(function (it) {
              return React.createElement('button', { key: it.id, className: 'dswk-detailSideItem' + (cat === it.id ? ' dswk-detailOn' : ''), onClick: function () { setCat(it.id); } }, it.label);
            })),
          React.createElement('div', { className: 'dswk-detailBody' },
            React.createElement('div', { className: 'dswk-detailHead' },
              React.createElement('div', { className: 'dswk-detailHero' },
                w.avatar ? React.createElement('img', { className: 'dswk-detailAvatar', src: imgUrl(w.avatar), alt: w.name }) : React.createElement('span', { className: 'dswk-wkEmoji' }, w.emoji || '🤖'),
                React.createElement('span', { className: 'dswk-wkName', style: { fontSize: 16, fontWeight: 600 } }, w.name)),
              React.createElement('button', { className: 'dswk-detailClose', title: '关闭', onClick: props.onClose }, '✕')),
            body,
            pform ? React.createElement('div', { className: 'dswk-overlay', onClick: function (e) { if (e.target === e.currentTarget) setPform(null); } },
              React.createElement('div', { className: 'dswk-modal' },
                React.createElement('div', { className: 'dswk-row', style: { justifyContent: 'space-between' } },
                  React.createElement('h3', { className: 'dswk-cardTitle', style: { margin: 0 } }, pform.id ? '编辑项目' : '新增项目'),
                  React.createElement('button', { className: 'dswk-detailClose', title: '关闭', onClick: function () { setPform(null); } }, '✕')),
                React.createElement('div', { className: 'dswk-row' },
                  React.createElement('div', { className: 'dswk-field', style: { maxWidth: 100 } },
                    React.createElement('label', { className: 'dswk-label' }, '类型'),
                    React.createElement('select', { className: 'dswk-select', value: pform.kind, onChange: function (e) { setPform(Object.assign({}, pform, { kind: e.target.value })); } },
                      React.createElement('option', { value: 'local' }, '本地路径'),
                      React.createElement('option', { value: 'git' }, 'Git 仓库'))),
                  React.createElement('div', { className: 'dswk-field' },
                    React.createElement('label', { className: 'dswk-label' }, '名称'),
                    React.createElement('input', { className: 'dswk-input', value: pform.name, placeholder: '如 dsh-waker 主仓库', onChange: function (e) { setPform(Object.assign({}, pform, { name: e.target.value })); } }))),
                React.createElement('div', { className: 'dswk-row' },
                  React.createElement('div', { className: 'dswk-field', style: { maxWidth: 160 } },
                    React.createElement('label', { className: 'dswk-label' }, '可见范围'),
                    React.createElement('select', { className: 'dswk-select', value: pform.scope, onChange: function (e) { setPform(Object.assign({}, pform, { scope: e.target.value })); } },
                      React.createElement('option', { value: 'public' }, '公开（所有 Waker）'),
                      React.createElement('option', { value: 'waker' }, '仅指定 Waker'))),
                  pform.scope === 'waker' ? React.createElement('div', { className: 'dswk-field' },
                    React.createElement('label', { className: 'dswk-label' }, '可用 Waker（可多选）'),
                    React.createElement('div', { className: 'dswk-row' },
                      wakers.map(function (wk) {
                        var on = pform.ownerWakerIds.indexOf(wk.id) !== -1;
                        return React.createElement('label', { className: 'dswk-check', key: wk.id },
                          React.createElement('input', { type: 'checkbox', checked: on, onChange: function () { togglePOwner(wk.id); } }),
                          wk.avatar ? React.createElement('img', { className: 'dswk-checkImg', src: imgUrl(wk.avatar), alt: '' }) : React.createElement('span', { className: 'dswk-checkEmoji' }, wk.emoji || '🤖'),
                          wk.name);
                      }))) : null),
                pform.kind === 'local'
                  ? React.createElement('div', { className: 'dswk-field' },
                    React.createElement('label', { className: 'dswk-label' }, '本地路径（已存在目录）'),
                    React.createElement('div', { className: 'dswk-pathRow' },
                      React.createElement('input', { className: 'dswk-input', value: pform.path, placeholder: '/Users/me/projects/xxx', onChange: function (e) { setPform(Object.assign({}, pform, { path: e.target.value })); } }),
                      React.createElement('button', { className: 'dswk-btn dswk-btnMini', disabled: pPicking, title: '弹出系统文件夹选择', onClick: chooseFolderP }, pPicking ? '选择中…' : '选择…')))
                  : React.createElement('div', { className: 'dswk-row' },
                    React.createElement('div', { className: 'dswk-field' },
                      React.createElement('label', { className: 'dswk-label' }, 'Git 仓库地址'),
                      React.createElement('input', { className: 'dswk-input', value: pform.gitUrl, placeholder: 'git@… 或 https://…', onChange: function (e) { setPform(Object.assign({}, pform, { gitUrl: e.target.value })); } })),
                    React.createElement('div', { className: 'dswk-field', style: { maxWidth: 150 } },
                      React.createElement('label', { className: 'dswk-label' }, '分支'),
                      React.createElement('input', { className: 'dswk-input', value: pform.branch, placeholder: 'main', onChange: function (e) { setPform(Object.assign({}, pform, { branch: e.target.value })); } }))),
                React.createElement('div', { className: 'dswk-row' },
                  React.createElement('button', { className: 'dswk-btn dswk-btnPrimary', disabled: pbusy, onClick: saveProject }, '保存'),
                  React.createElement('button', { className: 'dswk-btn', onClick: function () { setPform(null); } }, '取消')))) : null)));
    }
    // ---- R2: Waker 管理分区 ----
    function WakersSection() {
      var wakersS = React.useState(null);
      var wakers = wakersS[0], setWakers = wakersS[1];
      var presetsS = React.useState([]);
      var presets = presetsS[0], setPresets = presetsS[1];
      var errS = React.useState(null);
      var loadErr = errS[0], setLoadErr = errS[1];
      var noteS = React.useState(null);
      var noteVal = noteS[0], setNote = noteS[1];
      var modalS = React.useState(null); // null | {id?, name, emoji, role, presetId, systemExtra, triggers, concurrencyShare, avatar}
      var form = modalS[0], setForm = modalS[1];
      var busyS = React.useState(false);
      var isBusy = busyS[0], setBusy = busyS[1];
      var projS = React.useState([]);
      var projects = projS[0], setProjects = projS[1];
      var avS = React.useState([]);
      var avatars = avS[0], setAvatars = avS[1];
      var upS = React.useState(false);
      var uploading = upS[0], setUploading = upS[1];
      var upNoteS = React.useState(null);
      var uploadNote = upNoteS[0], setUploadNote = upNoteS[1];
      var detailS = React.useState(null);
      var detail = detailS[0], setDetail = detailS[1];

      var refresh = React.useCallback(function () {
        return api('waker.wakers.get', { includeDisabled: true }).then(function (d) {
          setWakers(d.wakers || []); setLoadErr(null);
        }).catch(function (e) { setLoadErr(String((e && e.message) || e)); });
      }, []);
      var refreshProjects = function () {
        api('waker.projects.get').then(function (d) { setProjects((d && d.projects) || []); }).catch(function () {});
      };
      React.useEffect(function () {
        refresh();
        refreshProjects();
        api('waker.presets.list').then(function (d) { setPresets(d.presets || []); }).catch(function () {});
        var loadAv = function () {
          api('waker.avatars.list').then(function (d) { setAvatars((d && d.avatars) || []); }).catch(function () {});
        };
        loadAv();
        var stop = ctx.timer.interval(refresh, 5000);
        var stop2 = ctx.timer.interval(refreshProjects, 15000);
        var stop3 = ctx.timer.interval(loadAv, 20000);
        return function () { if (stop) stop(); if (stop2) stop2(); if (stop3) stop3(); };
      }, [refresh]);

      var openNew = function () {
        var def = presets.filter(function (p) { return p.isDefault; })[0];
        setForm({ id: '', name: '', emoji: '', role: '', presetId: def ? def.id : (presets[0] ? presets[0].id : ''), systemExtra: '', triggers: '', concurrencyShare: 1, avatar: '' });
      };
      var openEdit = function (w) {
        setForm({ id: w.id, name: w.name, emoji: w.emoji || '', role: w.role, presetId: w.presetId, systemExtra: w.systemExtra || '', triggers: (w.triggers || []).join(','), concurrencyShare: w.concurrencyShare || 1, avatar: w.avatar || '' });
      };
      var saveForm = function () {
        if (!form) return;
        setBusy(true); setNote(null);
        api('waker.wakers.save', {
          id: form.id || undefined, name: form.name, emoji: form.emoji, role: form.role,
          presetId: form.presetId, systemExtra: form.systemExtra,
          triggers: form.triggers.split(/[,，]/).map(function (s) { return s.trim(); }).filter(Boolean),
          concurrencyShare: Number(form.concurrencyShare) || 1,
          cwdPolicy: { mode: 'follow', path: '' },
          avatar: form.avatar || ''
        }).then(function () {
          setForm(null); setNote({ kind: 'ok', text: '已保存 Waker' }); return refresh();
        }).catch(function (e) {
          setNote({ kind: 'error', text: String((e && e.message) || e) });
        }).then(function () { setBusy(false); });
      };
      var openDetail = function (w) {
        setDetail(w);
      };
      var toggle = function (w) {
        api('waker.wakers.toggle', { id: w.id, enabled: w.enabled === false }).then(refresh)
          .catch(function (e) { setNote({ kind: 'error', text: String((e && e.message) || e) }); });
      };
      var del = function (w, confirm) {
        api('waker.wakers.delete', { id: w.id, confirm: !!confirm }).then(function () {
          setNote({ kind: 'ok', text: '已删除' }); return refresh();
        }).catch(function (e) {
          if (e && e.code === 'NEEDS_CONFIRM') {
            if (window.confirm(String(e.message) + '，确认删除？')) del(w, true);
          } else setNote({ kind: 'error', text: String((e && e.message) || e) });
        });
      };
      var resetBuiltins = function () {
        api('waker.wakers.resetBuiltins').then(function () {
          setNote({ kind: 'ok', text: '预置 Waker 已恢复默认' }); return refresh();
        }).catch(function (e) { setNote({ kind: 'error', text: String((e && e.message) || e) }); });
      };

      var rows = wakers || [];
      var detailEl = detail ? React.createElement(WakerDetail, { waker: detail, projects: projects, wakers: wakers, onClose: function () { setDetail(null); }, onEdit: function () { setDetail(null); openEdit(detail); }, onProjectsChanged: function () { refreshProjects(); refresh(); }, onWakerUpdated: function (rec) { setDetail(rec); refresh(); } }) : null;
      return React.createElement('section', { className: 'dswk-card' },
        React.createElement('div', { className: 'dswk-secHead' },
          React.createElement('h3', { className: 'dswk-cardTitle' }, 'Waker 管理（数字员工）'),
          React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: resetBuiltins }, '恢复预置默认'),
          React.createElement('button', { className: 'dswk-btn dswk-btnPrimary dswk-btnMini', onClick: openNew }, '＋ 新建 Waker')),
        loadErr ? React.createElement('p', { className: 'dswk-note dswk-noteError' }, loadErr) : null,
        rows.length ? React.createElement('div', { className: 'dswk-grid' },
          rows.map(function (w) {
            return React.createElement('div', { className: 'dswk-wkCard' + (w.enabled === false ? ' dswk-wkOff' : ''), key: w.id },
              React.createElement('div', { className: 'dswk-wkHead' },
                w.avatar ? React.createElement('img', { className: 'dswk-wkAvatar', src: imgUrl(w.avatar), alt: w.name }) : React.createElement('span', { className: 'dswk-wkEmoji' }, w.emoji || '🤖'),
                React.createElement('span', { className: 'dswk-wkName', style: { flex: '1 1 auto' } }, w.name),
                w.builtin ? React.createElement('span', { className: 'dswk-badge dswk-badgeMuted' }, '预置') : React.createElement('span', { className: 'dswk-badge dswk-badgeMuted' }, '自定义')),
              w.role ? React.createElement('div', { className: 'dswk-wkRole' }, w.role) : null,
              React.createElement('div', { className: 'dswk-wkMeta' },
                'preset: ' + (w.presetId || '(默认)') + ' · 并发 ' + (w.concurrencyShare || 1) +
                ((w.triggers || []).length ? ' · 触发: ' + w.triggers.join(' ') : '')),
              React.createElement('div', { className: 'dswk-row dswk-wkFoot' },
                React.createElement('span', { style: { flex: 1 } }),
                React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: function () { openDetail(w); } }, '查看详情'),
                React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: function () { toggle(w); } }, w.enabled === false ? '启用' : '停用'),
                w.builtin ? null : React.createElement('button', { className: 'dswk-btn dswk-btnDanger dswk-btnMini', onClick: function () { del(w, false); } }, '删除')));
          })) : React.createElement('p', { className: 'dswk-note' }, '暂无 Waker'),
        noteVal ? React.createElement('p', { className: 'dswk-note ' + noteClass(noteVal.kind) }, noteVal.text) : null,
        detailEl,
        form ? React.createElement('div', { className: 'dswk-overlay', onClick: function (e) { if (e.target === e.currentTarget) setForm(null); } },
          React.createElement('div', { className: 'dswk-modal' },
            React.createElement('div', { className: 'dswk-row', style: { justifyContent: 'space-between' } },
              React.createElement('h3', { className: 'dswk-cardTitle', style: { margin: 0 } }, form.id ? '编辑 Waker' : '新建 Waker'),
              React.createElement('button', { className: 'dswk-detailClose', title: '关闭', onClick: function () { setForm(null); } }, '✕')),
            React.createElement('div', { className: 'dswk-field' },
              React.createElement('label', { className: 'dswk-label' }, '头像（点击选择，或上传自定义图片到 resource/img）'),
              React.createElement('div', { className: 'dswk-avatarGrid' },
                avatars.map(function (a) {
                  return React.createElement('button', { type: 'button', key: a.file, className: 'dswk-avatarOpt' + (form.avatar === a.file ? ' dswk-avatarOn' : ''), onClick: function () { setForm(Object.assign({}, form, { avatar: form.avatar === a.file ? '' : a.file })); }, title: a.file },
                    React.createElement('img', { src: imgUrl(a.file), alt: a.file }));
                }),
                React.createElement('div', { className: 'dswk-avatarOptNew' },
                  React.createElement('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp,image/gif', onChange: function (ev) {
                    var f = ev.target.files && ev.target.files[0];
                    if (!f) return;
                    if (f.size > 3 * 1024 * 1024) { alert('图片不能超过 3MB'); return; }
                    var rd = new FileReader();
                    rd.onload = function () {
                      setUploading(true);
                      api('waker.avatars.upload', { name: f.name, data: rd.result }).then(function (d) {
                        var file = d && d.file;
                        setForm(Object.assign({}, form, { avatar: file || form.avatar }));
                        if (d && d.avatars) setAvatars(d.avatars);
                        setUploadNote(null);
                      }).catch(function (e) { setUploadNote(String((e && e.message) || e)); })
                        .then(function () { setUploading(false); });
                    };
                    rd.readAsDataURL(f);
                    ev.target.value = '';
                  } }),
                  React.createElement('span', { className: 'dswk-label' }, uploading ? '上传中…' : '上传新头像'),
                  uploadNote ? React.createElement('span', { className: 'dswk-label', style: { color: 'var(--dsw-alias-danger,#d33)' } }, uploadNote) : null))),
            React.createElement('div', { className: 'dswk-row' },
              React.createElement('div', { className: 'dswk-field', style: { maxWidth: 80 } },
                React.createElement('label', { className: 'dswk-label' }, 'Emoji（兜底）'),
                React.createElement('input', { className: 'dswk-input', value: form.emoji, onChange: function (e) { setForm(Object.assign({}, form, { emoji: e.target.value })); } })),
              React.createElement('div', { className: 'dswk-field' },
                React.createElement('label', { className: 'dswk-label' }, '名称'),
                React.createElement('input', { className: 'dswk-input', value: form.name, placeholder: '如 前端开发', onChange: function (e) { setForm(Object.assign({}, form, { name: e.target.value })); } }))),
            React.createElement('div', { className: 'dswk-field' },
              React.createElement('label', { className: 'dswk-label' }, '职能一句话'),
              React.createElement('input', { className: 'dswk-input', value: form.role, placeholder: '负责什么、擅长什么', onChange: function (e) { setForm(Object.assign({}, form, { role: e.target.value })); } })),
            React.createElement('div', { className: 'dswk-field' },
              React.createElement('label', { className: 'dswk-label' }, '基础 preset（继承其工具与权限骨架）'),
              React.createElement('select', { className: 'dswk-select', value: form.presetId || '', onChange: function (e) { setForm(Object.assign({}, form, { presetId: e.target.value })); } },
                presets.map(function (p) {
                  return React.createElement('option', { value: p.id, key: p.id }, p.name + (p.isDefault ? '（默认）' : '') + (p.broken ? '（损坏）' : ''));
                }))),
            React.createElement('div', { className: 'dswk-field' },
              React.createElement('label', { className: 'dswk-label' }, '叠加系统提示（可空，叠加在 preset 之上）'),
              React.createElement('textarea', { className: 'dswk-textarea', value: form.systemExtra, placeholder: '该岗位的额外要求与约束', onChange: function (e) { setForm(Object.assign({}, form, { systemExtra: e.target.value })); } })),
            React.createElement('div', { className: 'dswk-field' },
              React.createElement('label', { className: 'dswk-label' }, '前缀触发词（逗号分隔，如 开发:,Dev:）'),
              React.createElement('input', { className: 'dswk-input', value: form.triggers, placeholder: '开发:,Dev:', onChange: function (e) { setForm(Object.assign({}, form, { triggers: e.target.value })); } })),
            React.createElement('div', { className: 'dswk-field' },
              React.createElement('label', { className: 'dswk-label' }, '并发占比(1-5)'),
              React.createElement('input', { className: 'dswk-input', type: 'number', min: 1, max: 5, value: form.concurrencyShare, onChange: function (e) { setForm(Object.assign({}, form, { concurrencyShare: e.target.value })); } })),
            React.createElement('div', { className: 'dswk-row' },
              React.createElement('button', { className: 'dswk-btn dswk-btnPrimary', disabled: isBusy, onClick: saveForm }, '保存'),
              React.createElement('button', { className: 'dswk-btn', onClick: function () { setForm(null); } }, '取消')))) : null);
    }

    // ---- R2: @Waker 管理分区(绑定) ----
    function BindingsSection() {
      var dataS = React.useState(null);
      var data = dataS[0], setData = dataS[1];
      var errS = React.useState(null);
      var loadErr = errS[0], setLoadErr = errS[1];
      var noteS = React.useState(null);
      var noteVal = noteS[0], setNote = noteS[1];
      var modalS = React.useState(null);
      var form = modalS[0], setForm = modalS[1];
      var busyS = React.useState(false);
      var isBusy = busyS[0], setBusy = busyS[1];
      var poolOpenS = React.useState(false);
      var poolOpen = poolOpenS[0], setPoolOpen = poolOpenS[1];
      var poolQ = React.useState('');
      var poolQuery = poolQ[0], setPoolQuery = poolQ[1];
      var poolUpS = React.useState(false);
      var poolUp = poolUpS[0], setPoolUp = poolUpS[1];
      var poolActS = React.useState(0);
      var poolAct = poolActS[0], setPoolAct = poolActS[1];
      var poolBoxRef = React.useRef(null);
      var poolDropRef = React.useRef(null);
      var mcS = React.useState({ groups: [], default: null });
      var mc = mcS[0], setMc = mcS[1];

      var refresh = React.useCallback(function () {
        return api('waker.bindings.get').then(function (d) {
          setData(d); setLoadErr(null);
        }).catch(function (e) { setLoadErr(String((e && e.message) || e)); });
      }, []);
      React.useEffect(function () {
        refresh();
        api('waker.models.list').then(function (d) { setMc({ groups: d.groups || [], default: d.default || null }); }).catch(function () {});
        var stop = ctx.timer.interval(refresh, 5000);
        return function () { if (stop) stop(); };
      }, [refresh]);
      // 键盘高亮项滚动到可见范围(须在 early-return 之前声明,保证 hooks 顺序稳定)
      React.useEffect(function () {
        if (!poolOpen || !poolDropRef.current) return;
        var el = poolDropRef.current.querySelector('.dswk-multiOpt.dswk-multiOptActive');
        if (el && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
      }, [poolAct, poolOpen, poolQuery]);

      if (!data) return React.createElement('section', { className: 'dswk-card' }, React.createElement('h3', { className: 'dswk-cardTitle' }, '@Waker 管理'), React.createElement('div', { className: 'dswk-skel' }), React.createElement('div', { className: 'dswk-skel' }));
      var bindings = data.bindings || [];
      var robots = data.robots || [];
      var wakers = data.wakers || [];
      var wakerName = function (id) {
        var w = wakers.filter(function (x) { return x.id === id; })[0];
        return w ? w.name : (id || '(空)');
      };
      var robotName = function (id) {
        var r = robots.filter(function (x) { return x.id === id; })[0];
        return r ? r.name : (id || '?');
      };

      var openNew = function () {
        setForm({ id: '', robotId: robots[0] ? robots[0].id : '', scopeMode: 'all', scopeConvs: '', wakerPool: wakers.filter(function (w) { return w.enabled !== false; }).map(function (w) { return w.id; }), taskModel: null, assistModel: null, judgeMode: 'on', enabled: true });
        setPoolQuery(''); setPoolOpen(false);
      };
      var openEdit = function (b) {
        setForm({
          id: b.id, robotId: b.robotId,
          scopeMode: b.scope && b.scope.mode === 'whitelist' ? 'whitelist' : 'all',
          scopeConvs: ((b.scope && b.scope.convs) || []).join('\n'),
          wakerPool: (b.wakerPool || []).slice(),
          taskModel: b.taskModel ? { provider: b.taskModel.provider, model: b.taskModel.model } : null,
          assistModel: b.assistModel ? { provider: b.assistModel.provider, model: b.assistModel.model } : null,
          judgeMode: b.judgeMode || 'on', enabled: b.enabled !== false
        });
        setPoolQuery(''); setPoolOpen(false);
      };
      var saveForm = function () {
        if (!form) return;
        // 真实业务校验: 候选池至少 1 个;池内成员若全部停用则无法路由
        var pool = form.wakerPool || [];
        if (!pool.length) { setNote({ kind: 'error', text: '请至少选择 1 个 Waker 加入候选池' }); return; }
        var anyOn = pool.some(function (id) {
          var w = wakers.filter(function (x) { return x.id === id; })[0];
          return !w || w.enabled !== false;
        });
        if (!anyOn) { setNote({ kind: 'error', text: '候选池内 Waker 均已停用，无法路由任务，请先启用或改选' }); return; }
        setBusy(true); setNote(null);
        api('waker.bindings.save', {
          id: form.id || undefined, robotId: form.robotId,
          scope: { mode: form.scopeMode, convs: form.scopeConvs.split('\n').map(function (s) { return s.trim(); }).filter(Boolean) },
          wakerPool: pool,
          taskModel: form.taskModel || null, assistModel: form.assistModel || null,
          judgeMode: form.judgeMode, enabled: form.enabled
        }).then(function () {
          setForm(null); setNote({ kind: 'ok', text: '已保存绑定' }); return refresh();
        }).catch(function (e) { setNote({ kind: 'error', text: String((e && e.message) || e) }); })
          .then(function () { setBusy(false); });
      };
      var togglePool = function (wid) {
        var pool = form.wakerPool.slice();
        var i = pool.indexOf(wid);
        if (i === -1) pool.push(wid); else pool.splice(i, 1);
        setForm(Object.assign({}, form, { wakerPool: pool }));
      };
      var wkOption = function (id) {
        var w = wakers.filter(function (x) { return x.id === id; })[0];
        return w ? (w.avatar ? React.createElement('img', { className: 'dswk-multiOptImg', src: imgUrl(w.avatar), alt: '' }) : React.createElement('span', { className: 'dswk-multiOptEmoji' }, w.emoji || '🤖')) : null;
      };
      var wkOff = function (w) { return w.enabled === false; };
      var wkChip = function (id) {
        var w = wakers.filter(function (x) { return x.id === id; })[0];
        var lead = null;
        if (w && w.enabled === false) {
          lead = React.createElement('span', { className: 'dswk-multiChipSt', title: '已停用：路由匹配与兜底会跳过，请先启用' }, '停');
        } else if (w && w.avatar) {
          lead = React.createElement('img', { src: imgUrl(w.avatar), alt: '' });
        } else {
          lead = React.createElement('span', { className: 'dswk-multiOptEmoji' }, w ? (w.emoji || '🤖') : '🤖');
        }
        return React.createElement('span', { className: 'dswk-multiChip', key: id },
          lead,
          React.createElement('span', null, w ? w.name : id),
          React.createElement('button', { type: 'button', className: 'dswk-multiChipX', title: '移除', onClick: function (e) { e.stopPropagation(); togglePool(id); } }, '✕'));
      };
      var poolCandidates = wakers.filter(function (w) {
        var q = String(poolQuery || '').trim().toLowerCase();
        if (!q) return true;
        return String(w.name || '').toLowerCase().indexOf(q) !== -1 || String(w.role || '').toLowerCase().indexOf(q) !== -1;
      });
      // 打开候选池: 量视口决定向下/向上翻(搜索框+列表+footer≈330px),并重置键盘高亮
      var openPool = function () {
        if (poolOpen) { setPoolOpen(false); return; }
        var r = poolBoxRef.current ? poolBoxRef.current.getBoundingClientRect() : null;
        setPoolUp(!!r && (window.innerHeight - r.bottom) < 330 && r.top > 330);
        setPoolAct(0); setPoolOpen(true);
      };
      var optName = function (w) {
        return React.createElement('span', { className: 'dswk-multiOptName dswk-multiOptNameFix', style: w.enabled === false ? { color: 'var(--dsw-alias-label-tertiary)' } : undefined },
          w.name,
          w.enabled === false ? React.createElement('span', { className: 'dswk-multiOffTag' }, '已停用') : null);
      };
      var selNames = function () {
        return (form.wakerPool || []).map(function (id) { return wakerName(id); }).join('、');
      };
      // 绑定卡片上的候选池只读 chip: 头像(无头像回退 emoji) + 名称,停用成员带「停」标
      var poolChip = function (id) {
        var w = wakers.filter(function (x) { return x.id === id; })[0];
        var off = w && w.enabled === false;
        return React.createElement('span', { className: 'dswk-poolChip' + (off ? ' dswk-poolChipOff' : ''), key: id, title: w ? (w.name + (w.role ? ' · ' + w.role : '') + (off ? '（已停用）' : '')) : id },
          w && w.avatar ? React.createElement('img', { src: imgUrl(w.avatar), alt: '' }) : React.createElement('span', { className: 'dswk-poolChipEmoji' }, w ? (w.emoji || '🤖') : '🤖'),
          React.createElement('span', { className: 'dswk-poolChipName' }, w ? w.name : id),
          off ? React.createElement('span', { className: 'dswk-poolChipTag' }, '停') : null);
      };

      var toggle = function (b) {
        api('waker.bindings.toggle', { id: b.id, enabled: b.enabled === false }).then(refresh)
          .catch(function (e) { setNote({ kind: 'error', text: String((e && e.message) || e) }); });
      };
      var del = function (b) {
        api('waker.bindings.delete', { id: b.id }).then(function () {
          setNote({ kind: 'ok', text: '已删除绑定' }); return refresh();
        }).catch(function (e) { setNote({ kind: 'error', text: String((e && e.message) || e) }); });
      };

      return React.createElement('section', { className: 'dswk-card' },
        React.createElement('div', { className: 'dswk-secHead' },
          React.createElement('h3', { className: 'dswk-cardTitle' }, '@Waker 管理（IM × Waker 绑定）'),
          React.createElement('button', { className: 'dswk-btn dswk-btnPrimary dswk-btnMini', onClick: openNew }, '＋ 新建绑定')),
        loadErr ? React.createElement('p', { className: 'dswk-note dswk-noteError' }, loadErr) : null,
        bindings.length ? React.createElement('div', null,
          bindings.map(function (b) {
            return React.createElement('div', { className: 'dswk-wkCard' + (b.enabled === false ? ' dswk-wkOff' : ''), key: b.id },
              React.createElement('div', { className: 'dswk-wkHead' },
                React.createElement('span', { className: 'dswk-wkName' }, '🤖 ' + robotName(b.robotId) + ' → AI 路由 ' + ((b.wakerPool || []).length) + ' 个 Waker'),
                React.createElement('span', { style: { flex: 1 } }),
                React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: function () { toggle(b); } }, b.enabled === false ? '启用' : '停用')),
              React.createElement('div', { className: 'dswk-poolRow' },
                React.createElement('span', { className: 'dswk-poolLabel' }, '候选'),
                (b.wakerPool || []).length ? (b.wakerPool || []).map(poolChip) : React.createElement('span', { className: 'dswk-poolNone' }, '未选择，无法路由')),
              React.createElement('div', { className: 'dswk-wkMeta' },
                '模型 ' + (b.taskModel ? b.taskModel.model : '全局默认') +
                ' · 判定模型 ' + (b.assistModel ? b.assistModel.model : '全局轻量档') +
                (b.scope && b.scope.mode === 'whitelist' ? ' · 白名单 ' + (b.scope.convs || []).length + ' 会话' : ' · 全部会话')),
              React.createElement('div', { className: 'dswk-row' },
                React.createElement('button', { className: 'dswk-btn dswk-btnMini', onClick: function () { openEdit(b); } }, '编辑'),
                React.createElement('button', { className: 'dswk-btn dswk-btnDanger dswk-btnMini', onClick: function () { del(b); } }, '删除')));
          })) : React.createElement('p', { className: 'dswk-note' }, '暂无绑定'),
        noteVal ? React.createElement('p', { className: 'dswk-note ' + noteClass(noteVal.kind) }, noteVal.text) : null,
        form ? React.createElement('div', { className: 'dswk-overlay', onClick: function (e) { if (e.target === e.currentTarget) setForm(null); } },
          React.createElement('div', { className: 'dswk-modal dswk-modalBind' },
            React.createElement('div', { className: 'dswk-row', style: { justifyContent: 'space-between' } },
              React.createElement('h3', { className: 'dswk-cardTitle', style: { margin: 0 } }, form.id ? '编辑绑定' : '新建绑定'),
              React.createElement('button', { className: 'dswk-detailClose', title: '关闭', onClick: function () { setForm(null); } }, '✕')),
            React.createElement('div', { className: 'dswk-row' },
              React.createElement('div', { className: 'dswk-field', style: { flex: '1 1 auto', minWidth: 200 } },
                React.createElement('label', { className: 'dswk-label' }, '来源机器人'),
                React.createElement('select', { className: 'dswk-select', value: form.robotId, onChange: function (e) { setForm(Object.assign({}, form, { robotId: e.target.value })); } },
                  robots.map(function (r) { return React.createElement('option', { value: r.id, key: r.id }, r.name); }))),
              React.createElement('div', { className: 'dswk-field', style: { flex: '0 0 150px', minWidth: 150 } },
                React.createElement('label', { className: 'dswk-label' }, '监听范围'),
                React.createElement('select', { className: 'dswk-select', value: form.scopeMode, onChange: function (e) { setForm(Object.assign({}, form, { scopeMode: e.target.value })); } },
                  React.createElement('option', { value: 'all' }, '全部会话'),
                  React.createElement('option', { value: 'whitelist' }, '白名单'))),
              React.createElement('div', { className: 'dswk-field', style: { flex: '0 0 170px', minWidth: 170 } },
                React.createElement('label', { className: 'dswk-label' }, '任务化判定'),
                React.createElement('select', { className: 'dswk-select', value: form.judgeMode, onChange: function (e) { setForm(Object.assign({}, form, { judgeMode: e.target.value })); } },
                  React.createElement('option', { value: 'on' }, '开启（讨论静默）'),
                  React.createElement('option', { value: 'off' }, '关闭（全部建任务）')))),
            form.scopeMode === 'whitelist' ? React.createElement('div', { className: 'dswk-field' },
              React.createElement('label', { className: 'dswk-label' }, '会话白名单（每行一个 conversationId）'),
              React.createElement('textarea', { className: 'dswk-textarea', value: form.scopeConvs, onChange: function (e) { setForm(Object.assign({}, form, { scopeConvs: e.target.value })); } })) : null,
            React.createElement('div', { className: 'dswk-field' },
              React.createElement('label', { className: 'dswk-label' }, 'Waker 候选池（可搜索、多选；AI 根据任务自动匹配最合适的 Waker）'),
              React.createElement('div', { className: 'dswk-multi' },
                React.createElement('div', {
                  className: 'dswk-multiBox', ref: poolBoxRef, role: 'button', tabIndex: 0,
                  onClick: openPool,
                  onKeyDown: function (e) {
                    if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') { e.preventDefault(); openPool(); }
                  }
                },
                  (form.wakerPool || []).map(wkChip),
                  React.createElement('span', { className: 'dswk-multiPlaceholder' }, (form.wakerPool || []).length ? '' : '点击选择（如：开发、测试、文档…）')),
                poolOpen ? React.createElement('div', { className: 'dswk-popMask', onClick: function () { setPoolOpen(false); } }) : null,
                poolOpen ? React.createElement('div', { className: 'dswk-multiDrop' + (poolUp ? ' dswk-multiDropUp' : ''), ref: poolDropRef },
                  React.createElement('input', {
                    className: 'dswk-multiSearch', placeholder: '搜索名称或职能…', value: poolQuery, autoFocus: true, onClick: function (e) { e.stopPropagation(); },
                    onChange: function (e) { setPoolQuery(e.target.value); setPoolAct(0); },
                    onKeyDown: function (e) {
                      if (e.key === 'ArrowDown') { e.preventDefault(); setPoolAct(function (a) { return Math.max(0, Math.min(a + 1, poolCandidates.length - 1)); }); }
                      else if (e.key === 'ArrowUp') { e.preventDefault(); setPoolAct(function (a) { return Math.max(a - 1, 0); }); }
                      else if (e.key === 'Enter') { e.preventDefault(); if (poolCandidates[poolAct]) togglePool(poolCandidates[poolAct].id); }
                      else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); setPoolOpen(false); }
                    }
                  }),
                  poolCandidates.length ? poolCandidates.map(function (w, i) {
                    var on = form.wakerPool.indexOf(w.id) !== -1;
                    return React.createElement('div', {
                      className: 'dswk-multiOpt' + (poolAct === i ? ' dswk-multiOptActive' : ''), key: w.id, title: w.role || '',
                      onClick: function (e) { e.stopPropagation(); togglePool(w.id); },
                      onMouseEnter: function () { setPoolAct(i); }
                    },
                      w.avatar ? React.createElement('img', { className: 'dswk-multiOptImg', src: imgUrl(w.avatar), alt: '' }) : React.createElement('span', { className: 'dswk-multiOptEmoji' }, w.emoji || '🤖'),
                      optName(w),
                      w.role ? React.createElement('span', { className: 'dswk-multiOptRole' }, w.role) : null,
                      React.createElement('span', { className: 'dswk-multiOptTick' + (on ? ' dswk-multiOptTickOn' : '') }, '✓'));
                  }) : React.createElement('div', { className: 'dswk-multiEmpty' }, '无匹配 Waker'),
                  React.createElement('div', { className: 'dswk-multiFoot' },
                    React.createElement('span', { className: 'dswk-multiFootText' }, '已选 ' + (form.wakerPool || []).length + ' 个：' + (selNames() || '无')),
                    React.createElement('button', { type: 'button', className: 'dswk-btn dswk-btnMini', onClick: function (e) { e.stopPropagation(); setPoolOpen(false); } }, '完成'))) : null)),
            React.createElement('div', { className: 'dswk-field' },
              React.createElement('label', { className: 'dswk-label' }, '任务执行模型（不选 = 全局默认）'),
              React.createElement(ModelSelect, {
                value: form.taskModel, groups: mc.groups,
                noneLabel: '全局默认',
                noneHint: mc.default ? (mc.default.provider + '/' + mc.default.model) : '跟随全局设置',
                onChange: function (v) { setForm(function (f) { return f ? Object.assign({}, f, { taskModel: v }) : f; }); }
              })),
            React.createElement('div', { className: 'dswk-field' },
              React.createElement('label', { className: 'dswk-label' }, '判定/路由轻量模型（不选 = 全局轻量档）'),
              React.createElement(ModelSelect, {
                value: form.assistModel, groups: mc.groups,
                noneLabel: '全局轻量档',
                noneHint: mc.default ? (mc.default.provider + '/' + mc.default.model) : '跟随全局设置',
                onChange: function (v) { setForm(function (f) { return f ? Object.assign({}, f, { assistModel: v }) : f; }); }
              })),
            React.createElement('div', { className: 'dswk-row' },
              React.createElement('button', { className: 'dswk-btn dswk-btnPrimary', disabled: isBusy, onClick: saveForm }, '保存'),
              React.createElement('button', { className: 'dswk-btn', onClick: function () { setForm(null); } }, '取消')))) : null);
    }

    // ---- Tab 容器 ----
    function WakerTabbed() {
      var tabS = React.useState('board');
      var tab = tabS[0], setTab = tabS[1];
      var TABS = [
        { id: 'board', label: '任务看板' },
        { id: 'im', label: 'IM 管理' },
        { id: 'projects', label: '项目管理' },
        { id: 'wakers', label: 'Waker 管理' },
        { id: 'bindings', label: '@Waker 管理' }
      ];
      return React.createElement('div', { className: 'dswk' },
        React.createElement('div', { className: 'dswk-tabs' },
          TABS.map(function (t) {
            return React.createElement('button', { className: 'dswk-tab' + (tab === t.id ? ' dswk-tabActive' : ''), key: t.id, onClick: function () { setTab(t.id); } }, t.label);
          })),
        tab === 'board' ? React.createElement(BoardSection, null) : null,
        tab === 'im' ? React.createElement(ImSection, null) : null,
        tab === 'projects' ? React.createElement(ProjectsSection, null) : null,
        tab === 'wakers' ? React.createElement(WakersSection, null) : null,
        tab === 'bindings' ? React.createElement(BindingsSection, null) : null);
    }

    var retireSection = null;
    ctx.slots.inject('settings.section', function () {
      var off = ctx.slots.register({ name: 'settings.section', id: 'waker', order: 20, label: 'Waker' }, WakerTabbed);
      retireSection = off;
      return off;
    });

    // ---- 设置导航 Waker 图标: 替换 fallback 齿轮为项目 icon(随主题切换,挂 effect 卸载可逆) ----
    // 宿主 settings-general 的 navIcon(id) 为硬编码映射,slot 协议不接 icon;此处 DOM 后处理:
    // 定位 label 为 Waker 的导航行,把行内 svg 换成双 <img>。语义: 深色模式用 light icon(浅色图形,
    // 暗底可见),浅色模式用 dark icon(深色图形,亮底可见);选中态不换图。
    // React 重渲染导航行会清掉外来节点,故用 per-cell 存活校验代替一次性 WeakSet 标记。
    ctx.effect(function () {
      if (typeof MutationObserver === 'undefined' || !document || !document.body) return;
      var style = document.createElement('style');
      style.textContent =
        '.dswk-navIconOnDark,.dswk-navIconOnLight{width:16px;height:16px;flex:none;border-radius:4px;object-fit:cover;display:block;}' +
        '.dswk-navIconOnLight{display:block;}' +
        '.dswk-navIconOnDark{display:none;}' +
        'body[data-ds-dark-theme] .dswk-navIconOnDark{display:block;}' +
        'body[data-ds-dark-theme] .dswk-navIconOnLight{display:none;}';
      document.head.appendChild(style);
      function markSwap(cell) { cell.setAttribute('data-dswk-icon', '1'); }
      function trySwap() {
        var cells = document.querySelectorAll('button[class*="_navCell"]');
        for (var i = 0; i < cells.length; i++) {
          var cell = cells[i];
          var label = cell.querySelector('[class*="_navLabel"]');
          if (!label || (label.textContent || '').trim() !== 'Waker') continue;
          if (cell.querySelector('.dswk-navIconOnDark') && cell.querySelector('.dswk-navIconOnLight')) continue; // 双图都在,已换
          var svg = cell.querySelector('svg');
          if (!svg) continue; // 尚无可替换的齿轮,等下一轮回调
          var onDark = document.createElement('img');
          onDark.className = 'dswk-navIconOnDark';
          onDark.src = imgUrl('icon-light.png'); // 深色模式 → light icon
          onDark.alt = '';
          var onLight = document.createElement('img');
          onLight.className = 'dswk-navIconOnLight';
          onLight.src = imgUrl('icon-dark.png'); // 浅色模式 → dark icon
          onLight.alt = '';
          if (svg.parentNode) svg.parentNode.replaceChild(onLight, svg);
          cell.insertBefore(onDark, onLight.nextSibling);
        }
      }
      var mo = new MutationObserver(function () { trySwap(); });
      mo.observe(document.body, { childList: true, subtree: true });
      trySwap();
      return function () {
        mo.disconnect();
        try { style.parentNode && style.parentNode.removeChild(style); } catch (e) {}
      };
    });
  }
};