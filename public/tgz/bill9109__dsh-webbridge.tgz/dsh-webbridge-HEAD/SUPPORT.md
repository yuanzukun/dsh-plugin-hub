# Support

## Start here

- Read the [README](README.md) for installation, configuration, usage, and troubleshooting.
- Search existing [issues](https://github.com/omdsh-dev/dsh-webbridge/issues) and [pull requests](https://github.com/omdsh-dev/dsh-webbridge/pulls) before opening a duplicate.

## Where to ask

- Reproducible defect: open a bug report.
- Installation, configuration, or usage question: open a question.
- Focused product improvement: open a feature request.
- Security concern: follow [SECURITY.md](SECURITY.md) and report it privately.
- Code contribution: read [CONTRIBUTING.md](CONTRIBUTING.md) before opening a pull request.

## Information to include

Provide the DSH snapshot and profile, plugin version, browser and OS versions, whether the Kimi WebBridge daemon was running and what `kimi-webbridge status` reported, the exact `webbridge_*` tool and arguments used, minimal reproduction steps, expected behavior, and sanitized output. Remove API keys, authorization headers, complete prompts or conversations, and unrelated workspace paths.
