/**
 * WebBridge client + tool tests. The daemon client is tested against a mock
 * HTTP server so tests run anywhere; a separate integration test (skipped
 * unless KIMI_WEBBRIDGE_IT=1) exercises the real local daemon.
 */

import { createServer } from 'node:http'
import type { AddressInfo } from 'node:net'
import { afterEach, describe, expect, it } from 'vitest'
import { WebBridgeError, webbridgeCommand } from '../src/client.ts'
import { webbridgeTools } from '../src/tools.ts'

/** One fake daemon server; records the last request body. */
let server: ReturnType<typeof createServer>
let baseUrl = ''
let lastBody: { action: string; args: Record<string, unknown>; session: string } | null = null
let respondWith: { ok: boolean; data?: Record<string, unknown>; error?: { code: string; message: string } } = { ok: true, data: {} }

async function startFakeDaemon(): Promise<void> {
  server = createServer((req, res) => {
    const chunks: Buffer[] = []
    req.on('data', (c: Buffer) => chunks.push(c))
    req.on('end', () => {
      lastBody = JSON.parse(Buffer.concat(chunks).toString('utf8'))
      res.writeHead(200, { 'content-type': 'application/json' })
      res.end(JSON.stringify(respondWith))
    })
  })
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  baseUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`
}

afterEach(async () => {
  lastBody = null
  respondWith = { ok: true, data: {} }
  if (server !== undefined) await new Promise<void>(resolve => server.close(() =>{  resolve(); }))
})

const exec = (sessionId = 's1') => ({
  callId: 'c1' as never,
  name: 'x',
  arguments: {},
  agent: { session: { id: sessionId } },
  signal: new AbortController().signal,
})

describe('webbridgeCommand', () => {
  it('posts action/args/session and returns the data payload', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, url: 'https://x.dev', tabId: 7 } }
    const result = await webbridgeCommand('navigate', { url: 'https://x.dev' }, 'task-a', baseUrl)
    expect(result).toEqual({ ok: true, data: { success: true, url: 'https://x.dev', tabId: 7 } })
    expect(lastBody).toEqual({ action: 'navigate', args: { url: 'https://x.dev' }, session: 'task-a' })
  })

  it('throws WebBridgeError on daemon rejection', async () => {
    await startFakeDaemon()
    respondWith = { ok: false, error: { code: 'tool_error', message: 'no extension connected' } }
    await expect(webbridgeCommand('snapshot', {}, 't', baseUrl)).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'tool_error',
      action: 'snapshot',
    })
  })

  it('throws WebBridgeError when the daemon is unreachable', async () => {
    await expect(webbridgeCommand('snapshot', {}, 't', 'http://127.0.0.1:1')).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'daemon_unreachable',
    })
  })

  it('throws on non-200 responses', async () => {
    await startFakeDaemon()
    server.removeAllListeners('request')
    server.on('request', (_req, res) => { res.writeHead(500); res.end('boom') })
    await expect(webbridgeCommand('click', { selector: '@e1' }, 't', baseUrl)).rejects.toMatchObject({
      code: 'http_error',
    })
  })
})

describe('webbridge tools', () => {
  it('navigate passes url/newTab/group_title and session', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, url: 'https://a.dev', tabId: 3 } }
    const tools = webbridgeTools(baseUrl)
    const value = await tools.navigate.execute(
      { url: 'https://a.dev', newTab: true, group_title: '研究', session: 'research' },
      exec() as never,
    )
    expect(value.ok).toBe(true)
    expect(value.summary).toContain('tabId=3')
    expect(lastBody?.args).toEqual({ url: 'https://a.dev', newTab: true, group_title: '研究' })
    expect(lastBody?.session).toBe('research')
  })

  it('navigate omits optional args when absent', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, url: 'https://a.dev' } }
    const tools = webbridgeTools(baseUrl)
    await tools.navigate.execute({ url: 'https://a.dev', session: 's' }, exec() as never)
    expect(lastBody?.args).toEqual({ url: 'https://a.dev' })
  })

  it('snapshot folds the accessibility tree into detail', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { url: 'https://a.dev', title: 'A', tree: [{ role: 'heading', name: 'Hi' }] } }
    const tools = webbridgeTools(baseUrl)
    const value = await tools.snapshot.execute({ session: 's' }, exec() as never)
    expect(value.detail).toMatchObject({ title: 'A' })
  })

  it('click forwards the selector', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, tag: 'button', text: 'Go' } }
    const tools = webbridgeTools(baseUrl)
    const value = await tools.click.execute({ selector: '@e12', session: 's' }, exec() as never)
    expect(value.ok).toBe(true)
    expect(lastBody?.args).toEqual({ selector: '@e12' })
  })

  it('fill forwards selector + value', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, mode: 'contenteditable' } }
    const tools = webbridgeTools(baseUrl)
    const value = await tools.fill.execute({ selector: '@e5', value: '你好', session: 's' }, exec() as never)
    expect(value.ok).toBe(true)
    expect(lastBody?.args).toEqual({ selector: '@e5', value: '你好' })
  })

  it('evaluate forwards code', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { type: 'string', value: 'hi' } }
    const tools = webbridgeTools(baseUrl)
    const value = await tools.evaluate.execute({ code: 'document.title', session: 's' }, exec() as never)
    expect(value.detail).toEqual({ type: 'string', value: 'hi' })
  })

  it('tool errors surface as WebBridgeError', async () => {
    await startFakeDaemon()
    respondWith = { ok: false, error: { code: 'tool_error', message: 'no extension connected' } }
    const tools = webbridgeTools(baseUrl)
    await expect(tools.navigate.execute({ url: 'https://a.dev', session: 's' }, exec() as never)).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'tool_error',
    })
  })

  it('registers every tool with a name/parameters/output contract', () => {
    const tools = webbridgeTools(baseUrl)
    const names = Object.values(tools).map(tool => tool.name)
    expect(names).toEqual([
      'webbridge_navigate',
      'webbridge_find_tab',
      'webbridge_snapshot',
      'webbridge_click',
      'webbridge_fill',
      'webbridge_evaluate',
      'webbridge_screenshot',
      'webbridge_list_tabs',
      'webbridge_network',
      'webbridge_close_tab',
      'webbridge_close_session',
    ])
    for (const tool of Object.values(tools)) {
      expect(typeof tool.execute).toBe('function')
      expect(tool.output).toBeDefined()
    }
  })

  it('navigate output schema validates', async () => {
    const tools = webbridgeTools(baseUrl)
    // The output schema is a JSON schema node; spot-check it compiles to an object root.
    expect(tools.navigate.output.schema).toMatchObject({ type: 'object' })
  })
})

/** Throw when the WebBridgeError is not the expected shape (type guard helper). */
function expectWebBridgeError(error: unknown): asserts error is WebBridgeError {
  expect(error).toBeInstanceOf(WebBridgeError)
}
