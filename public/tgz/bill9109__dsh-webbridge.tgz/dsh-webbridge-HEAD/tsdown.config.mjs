// tsdown config as a plain object (no `import 'tsdown'`): the tsdown binary
// comes from the DSH checkout / peer root, but the tsdown package itself is
// not part of the flat peer link, so importing it here would fail.
export default {
  entry: ['lib/types/index.js', 'lib/types/invariant.js'],
  outDir: 'lib',
  format: ['esm'],
  platform: 'node',
  target: 'es2024',
  fixedExtension: false,
  dts: false,
  clean: false,
}
