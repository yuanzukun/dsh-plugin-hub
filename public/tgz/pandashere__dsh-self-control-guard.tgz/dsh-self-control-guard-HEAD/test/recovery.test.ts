import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { readRestartManifest, writeRestartManifest } from '../src/recovery.ts'

function tempDir(): string {
  return mkdtempSync(join(tmpdir(), 'scg-recovery-'))
}

test('writes an atomic, shape-valid manifest', () => {
  const dir = tempDir()
  try {
    const path = join(dir, 'restart-recovery.json')
    const written = writeRestartManifest(path, [{ sessionId: 's1' }, { sessionId: 's2' }], 1_700_000_000_000, () => 'fixed-restart-id')
    assert.deepEqual(written, {
      version: 0,
      restartId: 'fixed-restart-id',
      createdAt: 1_700_000_000_000,
      sessions: [{ sessionId: 's1' }, { sessionId: 's2' }],
    })
    assert.ok(readFileSync(path, 'utf8').includes('"restartId": "fixed-restart-id"'))
    assert.throws(() => readFileSync(`${path}.${process.pid}.tmp`))
    assert.deepEqual(readRestartManifest(path), written)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('returns undefined for a missing manifest', () => {
  const dir = tempDir()
  try {
    assert.equal(readRestartManifest(join(dir, 'absent.json')), undefined)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('returns undefined for malformed content', () => {
  const dir = tempDir()
  try {
    const path = join(dir, 'bad.json')
    for (const content of ['not json', '[]', '{}', '{"version":1}', '{"version":0,"restartId":"","createdAt":0,"sessions":[]}', '{"version":0,"restartId":"x","createdAt":0,"sessions":[42]}', '{"version":0,"restartId":"x","createdAt":"nope","sessions":[]}', '{"version":0,"restartId":"x","createdAt":0,"sessions":[{"sessionId":""}]}', '{"version":0,"restartId":"x","createdAt":0,"sessions":[{"wasRunning":true}]}']) {
      writeRestartManifest(path, [])
      writeFileSync(path, content)
      assert.equal(readRestartManifest(path), undefined)
    }
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('writes the manifest with owner-only mode and no leftover tmp files', () => {
  const dir = tempDir()
  try {
    const path = join(dir, 'restart-recovery.json')
    writeRestartManifest(path, [{ sessionId: 's1' }], 0, () => 'r', () => 'fixedtmp')
    assert.equal(statSync(path).mode & 0o777, 0o600)
    assert.equal(readdirSync(dir).filter(name => name.endsWith('.tmp')).length, 0)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('cleans up the tmp file and rethrows when the rename fails', () => {
  const dir = tempDir()
  try {
    const destinationDir = join(dir, 'dest-dir')
    mkdirSync(destinationDir)
    assert.throws(() => writeRestartManifest(destinationDir, [{ sessionId: 's1' }], 0, () => 'r', () => 'failing'))
    assert.equal(readdirSync(dir).filter(name => name.endsWith('.tmp')).length, 0)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('handles an exclusive-create failure before any fd exists', () => {
  const dir = tempDir()
  try {
    const occupied = join(dir, `.${process.pid}.fixed.tmp`)
    writeFileSync(occupied, 'occupied')
    assert.throws(() => writeRestartManifest(join(dir, 'restart-recovery.json'), [{ sessionId: 's1' }], 0, () => 'r', () => 'fixed'))
    assert.throws(() => readFileSync(occupied))
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})
