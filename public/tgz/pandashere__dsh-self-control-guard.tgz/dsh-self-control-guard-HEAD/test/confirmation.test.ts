import { test } from 'node:test'
import assert from 'node:assert/strict'
import { setTimeout as sleep } from 'node:timers/promises'
import { ConfirmationStore, type ConfirmationConfig } from '../src/confirmation.ts'

/** A bare agent stub; only identity matters to the WeakMap-keyed store. */
function fakeAgent(id: string): { id: string } {
  return { id }
}

const config: ConfirmationConfig = { confirmationCalls: 2, confirmationTtlMs: 60_000, retryCooldownMs: 10_000 }

test('arms a fresh token and verifies the final call only with the presented token, action, and reason', async () => {
  const store = new ConfirmationStore()
  const agent = fakeAgent('a1') as never
  const { token, expiresAt } = store.arm(agent, 'exit', 'user-request', config)
  assert.equal(token.length, 43)
  assert.ok(expiresAt > Date.now())

  // A wrong token is rejected and does not consume the slot, but the failed
  // attempt at the 2-call ceiling arms the cooldown.
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', 'not-the-token', config), { verdict: 'invalid' })
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', token, config), { verdict: 'cooldown' })
  await sleep(config.retryCooldownMs + 5)
  const verdict = store.verify(agent, 'exit', 'user-request', token, config)
  assert.equal(verdict.verdict, 'ok')
  if (verdict.verdict === 'ok') {
    assert.equal(verdict.remaining, 0)
    assert.equal(verdict.token, token)
  }
  // The slot is consumed: a replay is invalid.
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', token, config), { verdict: 'invalid' })
})

test('rejects a wrong action, a wrong reason, and an unknown agent', () => {
  const store = new ConfirmationStore()
  const agent = fakeAgent('a1') as never
  const { token } = store.arm(agent, 'exit', 'user-request', config)
  assert.deepEqual(store.verify(agent, 'restart', 'user-request', token, config), { verdict: 'wrong-action' })
  assert.deepEqual(store.verify(agent, 'exit', 'task-complete', token, config), { verdict: 'reason-mismatch' })
  assert.deepEqual(store.verify(fakeAgent('a2') as never, 'exit', 'user-request', token, config), { verdict: 'invalid' })
  // A rejected attempt does not consume the slot: the correct call still works.
  const retry = store.verify(agent, 'exit', 'user-request', token, config)
  assert.equal(retry.verdict, 'ok')
  if (retry.verdict === 'ok') {
    assert.equal(retry.remaining, 0)
    assert.equal(retry.token, token)
  }
})

test('expires tokens after the TTL and consumes the slot on expiry', async () => {
  const store = new ConfirmationStore()
  const agent = fakeAgent('a1') as never
  const short: ConfirmationConfig = { confirmationCalls: 2, confirmationTtlMs: 20, retryCooldownMs: 10 }
  const { token } = store.arm(agent, 'exit', 'user-request', short)
  await sleep(30)
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', token, short), { verdict: 'expired' })
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', token, short), { verdict: 'invalid' })
})

test('counts failed attempts separately from correct presentations', async () => {
  const store = new ConfirmationStore()
  const agent = fakeAgent('a1') as never
  store.arm(agent, 'exit', 'user-request', config)
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', 'guess-1', config), { verdict: 'invalid' })
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', 'guess-2', config), { verdict: 'cooldown' })
  await sleep(config.retryCooldownMs + 5)
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', 'guess-3', config), { verdict: 'invalid' })
})

test('requires only correct presentations to advance a multi-round flow', async () => {
  const store = new ConfirmationStore()
  const agent = fakeAgent('a1') as never
  const multi: ConfirmationConfig = { confirmationCalls: 3, confirmationTtlMs: 60_000, retryCooldownMs: 10_000 }
  const first = store.arm(agent, 'exit', 'user-request', multi)
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', 'guess-1', multi), { verdict: 'invalid' })
  const second = store.verify(agent, 'exit', 'user-request', first.token, multi)
  assert.equal(second.verdict, 'ok')
  if (second.verdict === 'ok') {
    assert.equal(second.remaining, 1)
    assert.notEqual(second.token, first.token)
    assert.deepEqual(store.verify(agent, 'exit', 'user-request', 'guess-2', multi), { verdict: 'invalid' })
    assert.deepEqual(store.verify(agent, 'exit', 'user-request', second.token, multi), { verdict: 'cooldown' })
    await sleep(multi.retryCooldownMs + 5)
    const third = store.verify(agent, 'exit', 'user-request', second.token, multi)
    assert.equal(third.verdict, 'ok')
    if (third.verdict === 'ok') {
      assert.equal(third.remaining, 0)
      assert.equal(third.token, second.token)
    }
  }
})

test('arms cooldown only when failed attempts exhaust the confirmation chances', () => {
  const store = new ConfirmationStore()
  const agent = fakeAgent('a1') as never
  const multi: ConfirmationConfig = { confirmationCalls: 4, confirmationTtlMs: 60_000, retryCooldownMs: 10_000 }
  store.arm(agent, 'exit', 'user-request', multi)
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', 'g1', multi), { verdict: 'invalid' })
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', 'g2', multi), { verdict: 'invalid' })
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', 'g3', multi), { verdict: 'invalid' })
  assert.equal(store.inCooldown(agent), true)
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', 'g4', multi), { verdict: 'cooldown' })
})

test('clears a slot on clear()', () => {
  const store = new ConfirmationStore()
  const agent = fakeAgent('a1') as never
  const { token } = store.arm(agent, 'exit', 'user-request', config)
  store.clear(agent)
  assert.deepEqual(store.verify(agent, 'exit', 'user-request', token, config), { verdict: 'invalid' })
})

test('keys slots per agent: arming one agent never affects another', () => {
  const store = new ConfirmationStore()
  const a1 = fakeAgent('a1') as never
  const a2 = fakeAgent('a2') as never
  const { token } = store.arm(a1, 'exit', 'user-request', config)
  assert.deepEqual(store.verify(a2, 'exit', 'user-request', token, config), { verdict: 'invalid' })
})

test('arms with a fingerprint and returns it through every ok verdict', () => {
  const store = new ConfirmationStore()
  const agent = fakeAgent('a1') as never
  const { token } = store.arm(agent, 'self-bash', 'privileged-command', config, 'fp-1')
  const final = store.verify(agent, 'self-bash', 'privileged-command', token, config)
  assert.equal(final.verdict, 'ok')
  if (final.verdict === 'ok') assert.equal(final.fingerprint, 'fp-1')
  assert.deepEqual(store.verify(agent, 'self-bash', 'privileged-command', token, config), { verdict: 'invalid' })
})

test('returns the fingerprint on intermediate ok verdicts and keeps it across rotations', () => {
  const multi = { ...config, confirmationCalls: 3 }
  const store = new ConfirmationStore()
  const agent = fakeAgent('a1') as never
  const { token } = store.arm(agent, 'self-bash', 'privileged-command', multi, 'fp-2')
  const mid = store.verify(agent, 'self-bash', 'privileged-command', token, multi)
  assert.equal(mid.verdict, 'ok')
  if (mid.verdict !== 'ok') return
  assert.equal(mid.fingerprint, 'fp-2')
  const final = store.verify(agent, 'self-bash', 'privileged-command', mid.token, multi)
  assert.equal(final.verdict, 'ok')
  if (final.verdict === 'ok') assert.equal(final.fingerprint, 'fp-2')
})

test('omits the fingerprint for the exit tools', () => {
  const store = new ConfirmationStore()
  const agent = fakeAgent('a1') as never
  const { token } = store.arm(agent, 'exit', 'user-request', config)
  const verdict = store.verify(agent, 'exit', 'user-request', token, config)
  assert.equal(verdict.verdict, 'ok')
  if (verdict.verdict === 'ok') assert.equal('fingerprint' in verdict, false)
})
