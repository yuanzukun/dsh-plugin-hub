import { test } from 'node:test'
import assert from 'node:assert/strict'
import { matchHostKill, MAX_COMMAND_BYTES, MAX_NESTING } from '../src/matcher.ts'

const PID = 4242

const table: ReadonlyArray<readonly [command: string, expected: string | undefined]> = [
  // ── exact canonical forms (unchanged contract) ──────────────────────────
  ['kill 4242', 'kill-host-pid'],
  ['kill -9 4242', 'kill-host-pid'],
  ['kill -KILL 4242', 'kill-host-pid'],
  ['kill -SIGKILL 4242', 'kill-host-pid'],
  ['kill -TERM 4242', 'kill-host-pid'],
  ['kill -15 4242', 'kill-host-pid'],
  ['kill -- 4242', 'kill-host-pid'],
  ['/bin/kill 4242', 'kill-host-pid'],
  ['  kill  4242  ', 'kill-host-pid'],
  ['kill $PPID', 'kill-parent'],
  ['kill -9 $PPID', 'kill-parent'],
  ['pkill dsh', 'pkill-dsh'],
  ['pkill -f dsh', 'pkill-dsh'],
  ['pkill -9 dsh', 'pkill-dsh'],
  ['pkill -9 -f dsh', 'pkill-dsh'],
  ['killall dsh', 'killall-dsh'],
  ['killall -9 dsh', 'killall-dsh'],

  // ── compound commands now MATCH (the enhancement) ───────────────────────
  ['kill -9 4242; echo "exit=$?"', 'kill-host-pid'],
  ['kill -9 4242; echo done', 'kill-host-pid'],
  ['kill 4242; echo done', 'kill-host-pid'],
  ['kill -9 4242 && echo done', 'kill-host-pid'],
  ['kill -9 4242 || recover', 'kill-host-pid'],
  ['kill -9 4242 | tee result', 'kill-host-pid'],
  ['kill -9 4242 |& tee', 'kill-host-pid'],
  ['kill -9 4242 & echo done', 'kill-host-pid'],
  ['kill -9 4242;', 'kill-host-pid'],
  ['kill -9 4242 &', 'kill-host-pid'],
  ['echo before; kill -9 4242; echo after', 'kill-host-pid'],
  ['echo x | kill -9 4242', 'kill-host-pid'],
  ['false && kill -9 4242', 'kill-host-pid'],
  ['true || kill -9 4242', 'kill-host-pid'],
  ['kill -9 4242 > /dev/null 2>&1', 'kill-host-pid'],
  ['>/dev/null kill -9 4242', 'kill-host-pid'],
  ['kill -9 4242 2>/dev/null', 'kill-host-pid'],
  ['(kill -9 4242)', 'kill-host-pid'],
  ['( kill -9 4242 )', 'kill-host-pid'],
  ['( (kill -9 4242) )', 'kill-host-pid'],
  ['{ kill -9 4242; }', 'kill-host-pid'],
  ['kill -9 4242 # comment', 'kill-host-pid'],
  ['echo ok # kill 4242\nkill -9 4242', 'kill-host-pid'],
  ['kill -9 4242\n\n', 'kill-host-pid'],
  ['pkill dsh; echo x', 'pkill-dsh'],
  ['killall -9 dsh && echo', 'killall-dsh'],
  ['echo x | kill $PPID', 'kill-parent'],
  ['kill -9 $PPID; echo x', 'kill-parent'],

  // ── compound commands that MUST abstain ─────────────────────────────────
  ['echo kill -9 4242', undefined],
  ['echo "kill -9 4242"', undefined],
  ["'kill -9 4242'", undefined],
  ['echo kill\\ -9\\ 4242', undefined],
  ["K='kill -9 4242'; $K", undefined],
  ['kill -9 "$PPID"', undefined],
  ['${PPID}', undefined],
  ['kill ${PPID}', undefined],
  ['kill -9 $(pgrep -f dsh)', undefined],
  ['echo $(kill -9 4242)', undefined],
  ['echo `kill -9 4242`', undefined],
  ['echo x # kill -9 4242', undefined],
  ['X=1 kill -9 4242', undefined],
  ['PATH=/tmp kill -9 4242', undefined],
  ['kill -9 4243', undefined],
  ['kill -9 42424', undefined],
  ['kill -9 4242x', undefined],
  ['kill -9 $PPID_extra', undefined],

  // ── regression: multi-pid kill lists must match (round 7) ───────────────
  ['kill -TERM 4242 1494987', 'kill-host-pid'], // host pid first in the list
  ['kill -TERM 1000 4242 2000', 'kill-host-pid'], // host pid in the middle
  ['kill -TERM 1000 2000 4242', 'kill-host-pid'], // host pid last in the list
  ['kill 4242 1494987 2>&1; sleep 2; ps aux | grep dsh', 'kill-host-pid'], // real escape shape: multi-pid in a compound
  ['/bin/kill -9 4242 1494987', 'kill-host-pid'], // absolute-path multi-pid
  ['kill -- 4242 1494987', 'kill-host-pid'], // -- separator with a pid list
  ['kill $PPID 1494987', 'kill-parent'], // $PPID mixed into a numeric list
  ['kill -9 4243 4242', 'kill-host-pid'], // host pid anywhere in the list
  ['kill -9 42424', undefined], // pid is a full token: 42424 never matches host 4242
  ['kill -9 4242x', undefined], // pid token with a suffix never matches
  ['kill -9 4243', undefined], // host pid absent
  ['kill -9 4242 4243 4244 4245 4246', 'kill-host-pid'], // long list containing the host

  // ── regression: pid list + $PPID mixed (round 8: Codex must-fix) ────────
  ['kill 4242 $PPID', 'kill-host-pid'], // literal host pid takes precedence over $PPID
  ['kill $PPID 4242', 'kill-host-pid'], // same, reversed order
  ['kill -9 4242 $PPID 1494987', 'kill-host-pid'], // host + $PPID + other pids
  ['kill -s TERM 4242 $PPID', 'kill-host-pid'], // -s flag + mixed list

  // ── regression: Bash-accepted signal spellings (round 8) ────────────────
  ['kill -s TERM 4242', 'kill-host-pid'], // -s sigspec form
  ['kill -s SIGTERM 4242', 'kill-host-pid'],
  ['kill -n 15 4242', 'kill-host-pid'], // -n signum form
  ['kill -TERM -- 4242', 'kill-host-pid'], // signal flag then -- terminator
  ['kill -HUP 4242', 'kill-host-pid'], // other terminating signals
  ['kill -INT 4242', 'kill-host-pid'],
  ['kill -15 4242', 'kill-host-pid'], // numeric signal flag
  ['kill -1 4242', 'kill-host-pid'],
  ['kill -s TERM 1000 4242 2000', 'kill-host-pid'], // -s + multi-pid list containing host
  ['kill -l', undefined], // -l lists signals, never kills
  ['kill -L', undefined],
  ['kill -s TERM', undefined], // -s with no pid list
  ['kill -n 15', undefined],
  ['kill -- -4242', undefined], // negative pid = process group, out of scope

  // ── regression: invocation prefixes (round 8) ───────────────────────────
  ['command kill 4242', 'kill-host-pid'], // bash builtin prefix
  ['builtin kill 4242', 'kill-host-pid'],
  ['exec kill 4242', 'kill-host-pid'], // exec replaces the shell with kill
  ['env kill 4242', 'kill-host-pid'], // external kill via env/nice
  ['nice kill 4242', 'kill-host-pid'],
  ['command kill $PPID', 'kill-parent'], // prefix + $PPID

  // ── regression: quoted/escaped literals (round 8) ───────────────────────
  ["'kill' 4242", 'kill-host-pid'], // quoted command name is literal
  ['k\\ill 4242', 'kill-host-pid'], // escaped command name is literal
  ['kill "4242"', 'kill-host-pid'], // quoted pid is literal
  ['kill \\4242', 'kill-host-pid'], // escaped pid is literal

  // ── regression: pid token canonicalization (round 8) ────────────────────
  ['kill 0004242', 'kill-host-pid'], // leading zeros address the same pid
  ['kill +4242', 'kill-host-pid'], // explicit + sign addresses the same pid

  // ── regression: more absolute paths and pkill/killall variants (round 8) ─
  ['/usr/bin/kill 4242', 'kill-host-pid'], // distro /usr/bin/kill path
  ["pkill -f 'dsh'", 'pkill-dsh'], // quoted process name is literal
  ['pkill -x dsh', 'pkill-dsh'], // exact-match pkill
  ['pkill -P 1 dsh', 'pkill-dsh'], // parent-pid pkill
  ['killall -r dsh', 'killall-dsh'], // regex killall

  // ── regression: round 9 (Codex re-review) ───────────────────────────────
  // Non-pid operands do not erase a host-pid hit (Bash still delivers).
  ['kill -TERM 4242 definitely-not-a-pid', 'kill-host-pid'],
  ['kill definitely-not-a-pid 4242', 'kill-host-pid'],
  ['kill definitely-not-a-pid', undefined],
  // Prefix options resolve to the kill command.
  ['env -i kill 4242', 'kill-host-pid'],
  ['env -u HOME kill 4242', 'kill-host-pid'],
  ['env FOO=1 kill 4242', 'kill-host-pid'],
  ['nice -n 10 kill 4242', 'kill-host-pid'],
  ['nice --adjustment=5 kill 4242', 'kill-host-pid'],
  // Prefix + pkill/killall (external binaries; `builtin` is not valid).
  ['command pkill dsh', 'pkill-dsh'],
  ['exec pkill dsh', 'pkill-dsh'],
  ['env pkill dsh', 'pkill-dsh'],
  ['nice killall dsh', 'killall-dsh'],
  ['builtin pkill dsh', undefined], // pkill is not a builtin
  // Quoted/escaped literals compose with paths, signs, and flags.
  ['"/usr/bin/kill" 4242', 'kill-host-pid'],
  ['kill "+4242"', 'kill-host-pid'],
  ['kill "-TERM" 4242', 'kill-host-pid'],
  // Signal specs are validated: numbers within 1..64, known names only.
  ['kill -s 4242 4242', undefined], // 4242 is not a valid signal number
  ['kill -n 4242 4242', undefined],
  ['kill -s -- 4242', undefined],
  ['kill -s -TERM 4242', undefined],
  ['kill -s 9 4242', 'kill-host-pid'],
  ['kill -n 64 4242', 'kill-host-pid'],
  ['kill -n 65 4242', undefined],
  ['kill -65 4242', undefined],
  ['kill -FOOBAR 4242', undefined],
  ['kill -SIGFOO 4242', undefined],
  ['kill -0 4242', undefined], // signal 0 probes, never terminates
  ['kill -SIGTERM 4242', 'kill-host-pid'], // SIG-prefixed names
  ['kill -s SIGTERM 4242', 'kill-host-pid'],
  // Prefix parser edge branches.
  ['command', undefined], // prefix with no command
  ['builtin', undefined],
  ['exec', undefined],
  ['command -v kill 4242', undefined], // -v introspects, does not run kill
  ['command -V kill 4242', undefined], // -V introspects too
  ['command echo 4242', undefined], // prefix + non-kill command
  ['env', undefined], // env with no command
  ['nice', undefined],
  ['env -i', undefined], // env options but no command
  ['nice -n 10', undefined],
  ['env -i -u HOME FOO=1', undefined], // all options/assignments, no command
  ['command kill 4242 4243', 'kill-host-pid'], // prefix + multi-pid

  // ── regression: round 10 (Codex re-review) ───────────────────────────────
  // Option parsing ends at the first operand: a `-<flag>` after a pid is a
  // bad operand (Bash still delivers the signal), not a fatal option error.
  ['kill 4242 -FOOBAR', 'kill-host-pid'],
  ['kill -- 4242 -FOOBAR', 'kill-host-pid'],
  ['kill 4242 -0', 'kill-host-pid'], // -0 after a pid is a bad operand
  ['kill 4242 -l', 'kill-host-pid'], // -l after a pid is a bad operand
  ['kill -FOOBAR 4242', undefined], // unknown flag BEFORE any operand: Bash rejects
  ['kill -9.5 4242', undefined], // malformed signal (non-integer) before any operand
  ['kill -0 4242', undefined], // -0 as a signal probes, never terminates
  // Signal names are case-insensitive; real-time offsets accepted.
  ['kill -term 4242', 'kill-host-pid'],
  ['kill -SigTerm 4242', 'kill-host-pid'],
  ['kill -s term 4242', 'kill-host-pid'],
  ['kill -RTMIN+1 4242', 'kill-host-pid'],
  ['kill -RTMAX-1 4242', 'kill-host-pid'],
  // External kill (procps) accepts IOT/CLD/POLL aliases; the builtin does not.
  ['kill -IOT 4242', undefined], // bash builtin rejects IOT
  ['/bin/kill -IOT 4242', 'kill-host-pid'], // external accepts it
  ['exec kill -CLD 4242', 'kill-host-pid'],
  ['env kill -POLL 4242', 'kill-host-pid'],
  ['nice kill -IOT 4242', 'kill-host-pid'],
  // Quoted/escaped ordinary literal operands stay skipped, not opaque.
  ['kill 4242 "bad_arg"', 'kill-host-pid'], // quoted bad operand still killed
  ['kill "bad.arg" 4242', 'kill-host-pid'],
  ['kill 4242 "x_y"', 'kill-host-pid'],
  // Prefix introspection vs execution.
  ['command -v kill 4242', undefined], // -v introspects, does not run kill
  ['command -V kill 4242', undefined], // -V introspects too
  ['command -p kill 4242', 'kill-host-pid'], // -p uses default PATH, runs kill
  ['command -p -v kill 4242', undefined], // -p then -v still introspects
  ['command command kill 4242', 'kill-host-pid'], // nested command prefix
  ['builtin exec kill 4242', 'kill-host-pid'], // builtin exec runs kill

  // ── regression: round 11 (Codex re-review: builtin vs procps) ───────────
  // Prefix chain is a state machine: command -p does NOT bypass the builtin.
  ['command -p -p kill 4242', 'kill-host-pid'], // repeated -p, builtin kill
  ['command -p kill 4242', 'kill-host-pid'], // -p uses default PATH, still builtin
  ['command -p /bin/kill 4242', 'kill-host-pid'], // -p + absolute path: external
  ['command command kill 4242', 'kill-host-pid'], // nested command
  ['builtin builtin kill 4242', 'kill-host-pid'], // nested builtin
  ['builtin exec kill 4242', 'kill-host-pid'], // builtin exec replaces shell: external
  ['exec env kill 4242', 'kill-host-pid'], // exec → env → kill, all external
  ['env exec kill 4242', undefined], // env: exec: No such file — invalid
  ['nice command kill 4242', undefined], // nice: command: No such file — invalid
  ['exec command kill 4242', undefined], // exec: command: not found — invalid
  ['builtin env kill 4242', undefined], // env is not a builtin — invalid
  ['command -p kill -IOT 4242', undefined], // -p still builtin: IOT rejected
  // External procps resolves options ANYWHERE first (getopt-style), then
  // operands in order; a bad operand stops delivery.
  ['/bin/kill 4242 -0', undefined], // probe, never terminates
  ['/bin/kill 4242 -l', undefined], // list signals
  ['exec kill 4242 -0', undefined],
  ['/bin/kill 4242 bad -0', undefined], // -0 probe applies to 4242 too
  ['/bin/kill 4242 bad -l', undefined], // -l list applies regardless of bad
  ['/bin/kill 4242 bad -s 0', undefined], // -s 0 probe
  ['/bin/kill -- 4242 bad -0', undefined], // -- + bad operand, -0 still probe
  ['/bin/kill bad 4242', undefined], // bad operand first: nothing delivered
  ['/bin/kill 4242 bad', 'kill-host-pid'], // 4242 delivered before the error
  // After `--` only `-0` stays a probe; other `-<flag>` words are bad
  // operands and the pids before them were already sent (procps verified).
  ['/bin/kill -- 4242 -0', undefined], // probe
  ['/bin/kill -- 4242 -l', 'kill-host-pid'], // -l is a bad operand; 4242 sent
  ['/bin/kill -- 4242 -FOOBAR', 'kill-host-pid'], // unknown flag: bad operand; 4242 sent
  ['/bin/kill -- 4242 -s 0', 'kill-host-pid'], // -s 0 after --: bad operand; 4242 sent
  ['/bin/kill -- 4242 -9', 'kill-host-pid'], // 4242 sent with default TERM
  ['/bin/kill -- 4242 -TERM', 'kill-host-pid'],
  // RT signals: builtin RTMIN+0..30 / RTMAX-1..14; procps only RTMIN+n.
  ['kill -RTMIN+1 4242', 'kill-host-pid'],
  ['kill -RTMIN+30 4242', 'kill-host-pid'],
  ['kill -RTMAX-1 4242', 'kill-host-pid'],
  ['kill -RTMAX-14 4242', 'kill-host-pid'],
  ['kill -RTMIN-1 4242', undefined], // negative offset invalid
  ['kill -RTMAX-0 4242', undefined], // zero offset invalid
  ['kill -RTMAX-15 4242', undefined], // beyond builtin's 14
  ['kill -RTMAX-30 4242', undefined],
  ['kill -rtmin+1 4242', 'kill-host-pid'], // case-insensitive RT
  ['kill -RTMIN+100 4242', undefined],
  ['/bin/kill -RTMIN+1 4242', 'kill-host-pid'], // procps accepts RTMIN+n
  ['/bin/kill -RTMAX-1 4242', undefined], // procps rejects RTMAX-n
  // SIG-prefixed real-time offsets (round 12: bare is used for RT regex).
  ['kill -SIGRTMIN+1 4242', 'kill-host-pid'],
  ['kill -s SIGRTMIN+1 4242', 'kill-host-pid'],
  ['kill -SIGRTMAX-1 4242', 'kill-host-pid'],
  ['/bin/kill -SIGRTMIN+5 4242', 'kill-host-pid'],
  ['/bin/kill -s SIGRTMIN+5 4242', 'kill-host-pid'],
  // procps has no `-n`; the builtin does.
  ['/bin/kill -n 15 4242', undefined], // procps: invalid argument n
  ['/bin/kill 4242 -n 15', undefined],
  ['kill -n 15 4242', 'kill-host-pid'], // builtin supports -n
  ['/bin/kill -s', undefined], // -s with no signal argument
  ['/bin/kill -s 4242', undefined], // -s with a non-signal number
  ['/bin/kill -s 0', undefined], // -s 0 probe with no pid
  ['/bin/kill -65 4242', undefined], // signal number beyond range
  ['/bin/kill -999 4242', undefined], // procps rejects unknown numeric signal
  ['/bin/kill 4243', undefined], // external pid that is not the host

  // ── regression: round 13 (Codex re-review: signal precedence, long opts) ─
  // procps signal precedence: the last `-s`/`--signal` wins; `-0` without an
  // explicit signal probes the first operand and exits (abstain), while an
  // explicit signal has already been delivered to preceding pids (match).
  ['/bin/kill -s TERM 4242 -0', 'kill-host-pid'], // TERM already sent to 4242
  ['/bin/kill -s TERM 4242 bad -0', 'kill-host-pid'],
  ['/bin/kill -s 0 4242 -s TERM', 'kill-host-pid'], // last -s TERM wins
  ['/bin/kill -s TERM 4242 -s 0', undefined], // last -s 0 probes
  ['/bin/kill -0 4242', undefined], // -0 alone probes
  ['/bin/kill 4242 -0', undefined], // probe regardless of position
  ['/bin/kill 4242 bad -0', undefined], // probe; bad operand irrelevant
  ['/bin/kill -s 0 4242 -s 0', undefined], // double probe
  // procps long options: --signal works, --help/--version/--list abort.
  ['/bin/kill --signal TERM 4242', 'kill-host-pid'],
  ['/bin/kill 4242 --signal TERM', 'kill-host-pid'], // --signal anywhere
  ['/bin/kill 4242 --help', undefined],
  ['/bin/kill 4242 --version', undefined],
  ['/bin/kill 4242 --list', undefined],
  ['/bin/kill --signal', undefined], // --signal with no argument
  ['/bin/kill --unknown 4242', undefined], // unknown long option
  // Prefix-chain edge branches.
  ['command -p', undefined], // -p with no command after it
  ['command -p -p', undefined], // repeated -p with no command
  ['exec builtin kill 4242', undefined], // exec: builtin: not found — invalid
  ['env builtin kill 4242', undefined], // env: builtin: No such file — invalid
  ['/bin/kill $PPID', 'kill-parent'], // external $PPID: options stay open
  ['/bin/kill $PPID 4242', 'kill-host-pid'], // external $PPID + host pid

  // ── regression: round 14 (Codex re-review: procps precedence/attached) ──
  // Bare `-<sig>` may appear only ONCE; a second one makes procps print
  // usage and abort without delivering (verified against procps 3.3.17).
  ['/bin/kill -9 4242 -TERM', undefined],
  ['/bin/kill -TERM 4242 -9', undefined],
  ['/bin/kill -9 -TERM 4242', undefined],
  // `-s`/`--signal` may repeat, the last one wins (overwrites bare `-<sig>`).
  ['/bin/kill -s TERM 4242 --signal 9', 'kill-host-pid'],
  ['/bin/kill -s 0 -s 0 4242', undefined], // double probe
  // `-0` is procps's negative-PID branch: with an explicit signal the pids
  // still receive it; without one it probes/aborts (abstain).
  ['/bin/kill -0 -s TERM 4242', 'kill-host-pid'],
  ['/bin/kill -s TERM -0 4242', 'kill-host-pid'],
  ['/bin/kill -s TERM 4242 -0', 'kill-host-pid'],
  ['/bin/kill 1000 -0 4242', undefined], // no explicit signal: probe
  // `--` ends getopt parsing but skill_sig_option still sees bare `-<sig>`;
  // other flags become bad operands (pids before them were already sent).
  ['/bin/kill -- -0 4242', undefined], // probe
  ['/bin/kill -s TERM -- -0 4242', 'kill-host-pid'], // external: -0 is first bare, -s TERM overwrites
  ['/bin/kill --signal TERM -- -0 4242', 'kill-host-pid'],
  ['/bin/kill -s 0 -- -0 4242', undefined], // probe
  ['/bin/kill -- -TERM 4242', 'kill-host-pid'], // skill_sig_option still sees it
  ['/bin/kill -- -9 4242', 'kill-host-pid'],
  ['/bin/kill -- -l 4242', undefined], // -l bad operand before pid: nothing sent
  // Attached signal forms are accepted by procps.
  ['/bin/kill --signal=TERM 4242', 'kill-host-pid'],
  ['/bin/kill -sTERM 4242', 'kill-host-pid'],
  ['/bin/kill --signal=FOOBAR 4242', undefined], // invalid attached signal
  ['/bin/kill -sFOOBAR 4242', undefined],
  ['/bin/kill -- -FOOBAR 4242', undefined], // bad flag operand before pid
  ['/bin/kill 4242 -- -FOOBAR', 'kill-host-pid'], // pid sent before bad operand
  ['/bin/kill 4242 -- -.', 'kill-host-pid'], // generic -flag operand after pid
  // `-q`/`--queue` consume a value and send a queued signal.
  ['/bin/kill -q 7 -s TERM 4242', 'kill-host-pid'],
  ['/bin/kill --queue 7 --signal TERM 4242', 'kill-host-pid'],
  ['/bin/kill --queue=7 --signal=TERM 4242', 'kill-host-pid'],
  ['/bin/kill -q 7 4242', 'kill-host-pid'], // queue alone still sends
  ['/bin/kill -q +7 -s TERM 4242', 'kill-host-pid'], // + sign accepted
  ['/bin/kill --queue=-7 -s TERM 4242', 'kill-host-pid'], // attached - sign
  // Missing / non-numeric / overflowing queue value: procps aborts.
  ['/bin/kill 4242 -q', undefined],
  ['/bin/kill 4242 --queue', undefined],
  ['/bin/kill -q TERM 4242', undefined],
  ['/bin/kill --queue=x --signal=TERM 4242', undefined],
  ['/bin/kill --queue= --signal=TERM 4242', undefined],
  ['/bin/kill -q -7 -s TERM 4242', undefined], // -7 treated as an option
  ['/bin/kill -q 999999999999999999999 -s TERM 4242', undefined], // overflow
  ['/bin/kill --queue=999999999999999999999 --signal=TERM 4242', undefined], // attached overflow

  // ── regression: round 16 (Codex re-review: long range, double --) ───────
  // procps parses the queue value as a C `long`: on 64-bit the valid range
  // exceeds JS safe integers (verified: `-q 9007199254740992` kills the
  // target) while the 64-bit overflow `-q 9223372036854775808` aborts.
  ['/bin/kill -q 9007199254740991 -s TERM 4242', 'kill-host-pid'],
  ['/bin/kill -q 9007199254740992 -s TERM 4242', 'kill-host-pid'], // > MAX_SAFE, still valid
  ['/bin/kill -q 9223372036854775807 -s TERM 4242', 'kill-host-pid'], // LONG_MAX
  ['/bin/kill --queue=-9223372036854775808 -s TERM 4242', 'kill-host-pid'], // LONG_MIN
  ['/bin/kill -q 9223372036854775808 -s TERM 4242', undefined], // 64-bit overflow
  // getopt treats only the FIRST `--` as the terminator; a second `--` is a
  // bad operand that stops delivery (verified: `-q 7 -- -- PID` rc=1 alive).
  ['/bin/kill -q 7 -- -- 4242', undefined],
  ['/bin/kill -- -- 4242', undefined],
  ['/bin/kill -- -- -TERM 4242', undefined],
  // Queue payload 0 is not signal 0; without a signal the default TERM is
  // still sent (verified).
  ['/bin/kill -q 0 4242', 'kill-host-pid'],
  ['/bin/kill -q 0 -s TERM 4242', 'kill-host-pid'],
  ['/bin/kill -q 7 -s 0 4242', undefined], // probe signal wins
  ['/bin/kill -q 7 -- -TERM 4242', 'kill-host-pid'], // queue + -- then signal

  // ── regression: round 17 (Codex re-review: -- + second negative token) ──
  // After `--`, a NUMERIC negative token with an existing bare signal is a
  // process-group operand procps delivers past (`-TERM PID -- -9` sends TERM
  // to PID then ESRCH for group 9); a NAMED one is a bad operand that stops.
  ['/bin/kill -TERM 4242 -- -9', 'kill-host-pid'],
  ['/bin/kill -TERM -- -9 4242', 'kill-host-pid'],
  ['/bin/kill -TERM 4242 -- -- -9', 'kill-host-pid'], // second --, then -9
  ['/bin/kill -TERM -- -TERM 4242', undefined], // named negative: bad operand
  ['/bin/kill -TERM -- -- 4242', undefined], // second -- stops
  ['/bin/kill -TERM -- -TERM 4242', undefined], // named negative stops

  // ── regression: round 18 (Codex re-review: two-phase bare vs -s) ────────
  // procps is TWO-PHASE: skill_sig_option takes the FIRST bare `-<sig>`,
  // then getopt `-s`/`--signal` overwrites it (last wins) regardless of argv
  // order. So `-s 0 -9 PID` ends as a signal-0 probe (alive) — abstain.
  ['/bin/kill -s 0 -- -9 4242', undefined],
  ['/bin/kill -s 0 -- -TERM 4242', undefined],
  ['/bin/kill -s 0 -9 4242', undefined],
  ['/bin/kill -s 0 -TERM 4242', undefined],
  ['/bin/kill -s 0 4242 -TERM', undefined],
  ['/bin/kill -s TERM -- -9 4242', 'kill-host-pid'], // TERM wins over bare -9
  ['/bin/kill -s TERM -9 4242', 'kill-host-pid'],
  ['/bin/kill -9 -s TERM 4242', 'kill-host-pid'], // -s TERM overwrites bare -9
  // `-0` after `--` is a process-group operand: procps does kill(0, signo) —
  // the UTILITY dies, the target survives (verified rc=143 with target
  // alive) — abstain.
  ['/bin/kill -- -0 -9 4242', undefined],
  ['/bin/kill -0 -- -9 4242', undefined],
  ['/bin/kill -- -9 -0 4242', undefined],
  ['/bin/kill -TERM -- -0 4242', undefined],
  ['/bin/kill -- -0 4242', undefined],
  ['/bin/kill -0 4242', undefined], // bare -0 probes
  ['/bin/kill -TERM -0 4242', undefined], // -0 after bare signal: kill(0) kills utility
  ['/bin/kill -0 -TERM 4242', undefined], // probe then second bare → abort
  ['/bin/kill -TERM 4242 -0', undefined], // bare -TERM + -0: kill(0) exits, PID never sent
  ['/bin/kill -s TERM 4242 -0', 'kill-host-pid'], // -s TERM not bare; PID sent, -0 probe

  // ── regression: round 19 (Codex re-review: -0 after -- is positional) ───
  // A second `-0` AFTER `--` is an operand processed in order (strace:
  // `-TERM PID -- -0` first kill(PID) then kill(0)); a host pid before it
  // was already delivered — match. Without `--`, the second `-0` is a getopt
  // case-'?' that exits before any operand — abstain.
  ['/bin/kill -s TERM -- -0 4242', 'kill-host-pid'], // -0 is first bare, -s TERM overwrites
  ['/bin/kill -s TERM -- 4242 -0', 'kill-host-pid'],
  ['/bin/kill -TERM -- 4242 -0', 'kill-host-pid'], // PID sent before -0 operand
  ['/bin/kill -TERM 4242 -- -0', 'kill-host-pid'], // PID sent before -0
  ['/bin/kill -TERM -- -0 4242', undefined], // -0 operand before PID: utility dies first
  ['/bin/kill -- -0 4242', undefined], // first bare -0 probes

  // ── regression: round 20 (Codex re-review: builtin -- + -0) ─────────────
  // The bash BUILTIN's `-0` after `--` is a group-0 operand: it does
  // kill(0, signo), killing the UTILITY before any later pid is processed
  // (verified rc=143 with the target alive) — abstain. The EXTERNAL
  // `/bin/kill -s TERM -- -0 PID` differs (round 19: first bare -0
  // overwritten by -s TERM) and matches.
  ['kill -s TERM -- -0 4242', undefined],
  ['kill -TERM -- -0 4242', undefined],
  ['kill -- -0 4242', undefined],
  ['kill -s TERM -- 4242 -0', 'kill-host-pid'], // PID sent before -0
  ['kill -TERM -- 4242 -0', 'kill-host-pid'],
  ['kill -s TERM -0 4242', undefined], // builtin -0 before --: probe
  ['kill -0 4242', undefined],
  // Round-21 optional additions (verified behaviors).
  ['kill -TERM 4242 -0', 'kill-host-pid'], // builtin: PID sent before -0
  ['kill -s TERM 4242 -0', 'kill-host-pid'], // builtin: PID sent before -0
  ['kill -s 0 4242', undefined], // builtin -s 0 probes
  ['pkill dshx', undefined],
  ['killall dshd', undefined],
  ['kill 4242 > /dev/null | echo', 'kill-host-pid'],

  // ── unsupported syntax abstains ─────────────────────────────────────────
  ['kill -9 4242 << EOF\nkill -9 4242\nEOF', undefined],
  ['kill -9 4242 <<< hi', undefined],
  ['(( kill -9 4242 ))', undefined],
  ['if true; then kill -9 4242; fi', undefined],
  ['kill -9 4242 |', undefined],
  ['kill -9 4242 &&', undefined],
  ['kill -9 4242; | echo', undefined],
  ['kill -9 4242; & echo', undefined],
  ['echo "unclosed', undefined],
  ['kill -9 4242 \\', undefined],
  ['(kill -9 4242', undefined],
  ['kill -9 4242)', undefined],
  ['{ kill -9 4242;', undefined],
  ['kill -9 4242; }', undefined],

  // ── tokenizer edge branches ────────────────────────────────────────────
  ["'unclosed", undefined],
  ["echo 'x; kill -9 4242", undefined],
  ['echo "x\\"y; kill -9 4242', undefined],
  ['kill -9 \\\n4242', 'kill-host-pid'],
  ['kill $((1+1))', undefined],
  ['${abc', undefined],
  ['`abc', undefined],
  ['$(pgrep', undefined],
  ['kill ${PPID', undefined],
  ['echo x\nkill -9 4242 # comment\necho y', 'kill-host-pid'],
  ['kill -9 4242 \\\\&& echo done', undefined],
  ['2>err kill -9 4242', 'kill-host-pid'],
  ["echo 'abc", undefined],
  ['echo "a\\$b; kill -9 4242', undefined],
  ['kill -9 4242;;', undefined],
  ['echo 123; kill -9 4242', 'kill-host-pid'],
  ['{ kill -9 4242 }', undefined],
  ['{ { kill -9 4242; } ; }', 'kill-host-pid'],
  ['{ kill -9 4242\n}', 'kill-host-pid'],
  ['(echo x) # comment\nkill -9 4242', 'kill-host-pid'],
  ['{ echo y; } # c\nkill -9 4242', 'kill-host-pid'],
  ['(echo x)# c\nkill -9 4242', 'kill-host-pid'],
  ['{ echo y; }# c\nkill -9 4242', 'kill-host-pid'],
  ['> /dev/null; kill -9 4242', 'kill-host-pid'],
  ['echo x#kill -9 4242', undefined],
  ['case a;; kill -9 4242', undefined],
  ['# comment only\nkill -9 4242', 'kill-host-pid'],
  ['{ (kill -9 4242; }', undefined],
  ['echo a'.repeat(4500) + '; kill -9 4242', undefined],
  ['kill -9 4242 2<< EOF\nbody\nEOF', undefined],

  // ── empty / whitespace ──────────────────────────────────────────────────
  ['', undefined],
  ['   ', undefined],
  ['\n', undefined],
  [';', undefined],
  ['|', undefined],

  // ── regression: parser-syntax errors must abstain (Codex review round 2) ─
  ['kill2>/dev/null 4242', undefined], // IO-number needs a fresh word; `kill2` is a command name
  ['/bin/kill2>/dev/null 4242', undefined],
  ['kill -9 4242 >', undefined], // redirect with no target
  ['kill -9 4242 2>&', undefined],
  ['kill -9 4242 > >', undefined],
  ['echo (kill -9 4242)', undefined], // `(` after a word is a syntax error
  ['(echo)kill -9 4242', undefined], // word directly after `)` is a syntax error
  ['(); kill -9 4242', undefined], // empty `()` is a syntax error
  ['f() { kill -9 4242; }', undefined], // function definition, body not executed
  ['f() (kill -9 4242)', undefined],
  ['function f { kill -9 4242; }', undefined],
  ['kill\u00a04242', undefined], // NBSP is a Bash word char, not a blank
  ['kill 4242\r', undefined], // CR is a Bash word char, not a blank
  ['echo &>out kill -9 4242', undefined], // `&>` redirect; kill is an echo arg
  ['kill -9 4242;\0', undefined], // NUL is not a Bash word char

  // ── regression: previously-abstaining forms now MATCH (round 2) ─────────
  ['echo {x,y}; kill -9 4242', 'kill-host-pid'], // `{x,y}` is brace expansion, not a group
  ['echo $(echo $(x)) ; kill -9 4242', 'kill-host-pid'], // nested `$()` balance-scans
  ['kill -9 4242 &> /dev/null', 'kill-host-pid'], // `&>` is one redirect token
  ['kill -9 4242 &>> log', 'kill-host-pid'],
  ['echo hi &>out; kill -9 4242', 'kill-host-pid'],
  ['{ kill -9 4242 & }', 'kill-host-pid'], // `&` is a valid brace terminator (Bash)
  ['(echo x) # comment\nkill -9 4242', 'kill-host-pid'], // newline after `)` is a separator
  ['{ echo y; } # c\nkill -9 4242', 'kill-host-pid'],
  ['(echo x)# c\nkill -9 4242', 'kill-host-pid'],
  ['{ echo y; }# c\nkill -9 4242', 'kill-host-pid'],
  ['echo 123; kill -9 4242', 'kill-host-pid'], // retained from earlier

  // ── regression: exact token cap (4096 accepted, 4097 abstains) ─────────
  ['x;'.repeat(2046) + ' kill -9 4242', 'kill-host-pid'], // 4095 tokens
  ['x;'.repeat(2047) + ' kill -9 4242', undefined], // 4097 tokens

  // ── regression: tokenizer edge branches (round 3 coverage) ─────────────
  ['echo $(echo a\\ b) ; kill -9 4242', 'kill-host-pid'], // backslash inside $()
  ['echo $(echo x\\', undefined], // trailing backslash inside unclosed $(
  ['{\nkill -9 4242; }', 'kill-host-pid'], // `{` followed by newline is a brace group
  ['x; {', undefined], // `{` at very end of input
  ['{ echo y; }kill -9 4242', undefined], // word directly after `}` group
  ['echo `date`; kill -9 4242', 'kill-host-pid'], // backtick expansion + compound

  // ── regression: round 2 Codex review (syntax errors must abstain) ──────
  ['kill -9 4242 > ; echo x', undefined], // redirect target must be next token
  ['kill -9 4242 >\necho x', undefined],
  ['(\n); kill -9 4242', undefined], // empty paren group (newline only)
  ['{\n}; kill -9 4242', undefined], // empty brace group (newline only)
  ['kill -9 4242; echo )', undefined], // bare `)` is a syntax error
  ['function f\n{ kill -9 4242; }', undefined], // function def, newline form
  ['function f\n( kill -9 4242 )', undefined],
  ['if false; then\nkill -9 4242\nfi', undefined], // if-block body
  ['while false; do\nkill -9 4242\ndone', undefined], // while-loop body
  ['for x in 1 2; do\nkill -9 4242\ndone', undefined], // for-loop body
  ['echo $( (echo); kill -9 4242; echo x )', undefined], // subshell inside $()
  ['echo $(echo ")") ; kill -9 4242', 'kill-host-pid'], // quoted closer inside $()
  ['echo $(echo "x") ; kill -9 4242', 'kill-host-pid'],
  ["echo $(echo 'x)') ; kill -9 4242", 'kill-host-pid'], // single-quote inside $()
  ['echo $(echo "a\\\\b)") ; kill -9 4242', 'kill-host-pid'], // backslash inside double-quote
  ['echo $(echo "x\\', undefined], // trailing backslash at end inside double-quote

  // ── regression: compound keywords abstain (whole-scan) ─────────────────
  ['if true; then kill -9 4242; fi', undefined],
  ['echo if; kill -9 4242', 'kill-host-pid'], // `if` as an argument is fine
  ['kill -9 4242; echo done', 'kill-host-pid'], // sanity: plain compound still matches

  // ── regression: round 3 Codex review ───────────────────────────────────
  ['echo "$(echo "; kill -9 4242;")"', undefined], // $() inside double quotes is opaque
  ['echo "`echo "; kill -9 4242;"`"', undefined], // backtick inside double quotes is opaque
  ['echo "${x:-"; kill -9 4242;}"', undefined], // ${} inside double quotes is opaque
  ['echo "${x}" ; kill -9 4242', 'kill-host-pid'], // opaque ${} then real command
  ['echo "$(echo x)" ; kill -9 4242', 'kill-host-pid'], // opaque $() then real command
  ['{ kill -9 4242; } > /dev/null', 'kill-host-pid'], // redirect after } group
  ['(kill -9 4242) > /dev/null', 'kill-host-pid'], // redirect after ) group
  ['{ kill -9 4242; } 2>&1 | cat', 'kill-host-pid'], // multiple redirects + pipe
  ['(echo) > /dev/null; kill -9 4242', 'kill-host-pid'], // redirect then control then kill
  ['{ echo x; } > /dev/null; kill -9 4242', 'kill-host-pid'],
  ['{ kill -9 4242; } >', undefined], // redirect after } group with no target
  ['(kill -9 4242) > >', undefined], // redirect after ) group with redirect target
  ['echo "$(echo x" ; kill -9 4242', undefined], // unclosed $() inside double quotes
  ['echo "${x" ; kill -9 4242', undefined], // unclosed ${} inside double quotes
  ['echo "`echo x" ; kill -9 4242', undefined], // unclosed backtick inside double quotes
  ['echo "$((1+1))" ; kill -9 4242', undefined], // arithmetic inside double quotes

  // ── regression: round 4 Codex review (recursive nested expansions) ─────
  ['echo "$(echo "$(printf ")")")" ; kill -9 4242', 'kill-host-pid'], // nested $() with quoted closer
  ['echo "$(echo "nested")" ; kill -9 4242', 'kill-host-pid'], // $() inside double quotes
  ['echo "$(echo `x`)" ; kill -9 4242', 'kill-host-pid'], // backtick inside $() inside quotes
  ['echo "`echo "$x"`" ; kill -9 4242', 'kill-host-pid'], // double quotes inside backtick
  ['(kill -9 4242) > /dev/null 2>&1', 'kill-host-pid'], // multiple redirects after group
  ['{ kill -9 4242; } > /dev/null | cat', 'kill-host-pid'], // redirect + pipe after group
  ['echo x "$(echo "; kill -9 4242")"', undefined], // expansion mid-word stays opaque
  ['kill -9 4242 >"$file"', 'kill-host-pid'], // quoted redirect target
  ['echo "$((1+1))" ; kill -9 4242', undefined], // arithmetic inside quotes (dup of above)
  ['echo "function" ; kill -9 4242', 'kill-host-pid'], // keyword as quoted argument
  ['if x; then echo "$(kill -9 4242)"; fi', undefined], // expansion inside if body
  ['echo a # $(kill -9 4242)\nkill -9 4242', 'kill-host-pid'], // expansion in comment then kill
  ['echo "$(echo "${x}")" ; kill -9 4242', 'kill-host-pid'], // ${} nested in $() in quotes
  ['echo "$(echo "`x`")" ; kill -9 4242', 'kill-host-pid'], // backtick nested in $() in quotes
  ['echo "$(echo "${x" )" ; kill -9 4242', undefined], // unclosed ${} nested in quotes
  ['echo "$(echo "`x" )" ; kill -9 4242', undefined], // unclosed backtick nested in quotes
  ['echo "$(echo "$((1+1))")" ; kill -9 4242', undefined], // arithmetic nested in $() in quotes
  ['echo "$(echo "$(echo" ; kill -9 4242', undefined], // unclosed nested $() in quotes

  // ── regression: round 5 Codex review (heterogeneous nesting + depth) ───
  ['echo $(echo ${x:-) ; kill -9 4242', undefined], // Bash syntax error: mismatched )}
  ['echo ${x:-$(echo } ; kill -9 4242', undefined], // Bash syntax error: mismatched })
  ['echo $(echo ${x:-)}) ; kill -9 4242', 'kill-host-pid'], // valid heterogeneous nesting
  ['echo ${x:-$(echo })} ; kill -9 4242', 'kill-host-pid'], // valid heterogeneous nesting
  ['echo $(echo $(echo $(echo x))) ; kill -9 4242', 'kill-host-pid'], // deep nesting still parses
  ['echo "$(echo "$(printf ")")")" ; kill -9 4242', 'kill-host-pid'], // nested $() with quoted closer
  ['echo "$(echo "${x}")" ; kill -9 4242', 'kill-host-pid'], // ${} nested in $() in quotes
  ['echo "$(echo "`x`")" ; kill -9 4242', 'kill-host-pid'], // backtick nested in $() in quotes
  ['echo "`echo "$x"`" ; kill -9 4242', 'kill-host-pid'], // double quotes inside backtick
  ["echo \"$(echo 'single')\" ; kill -9 4242", 'kill-host-pid'], // single quotes in $()
  ['echo "$(echo "escaped \\" quote")" ; kill -9 4242', 'kill-host-pid'], // escaped quote in $()
  ['x="$(echo "; kill -9 4242")"; kill -9 4242', 'kill-host-pid'], // assignment + expansion + kill
  ['kill -9 4242 2>&1 >/dev/null', 'kill-host-pid'], // redirect ordering
  ['echo ${x:-$(kill -9 4242)}', undefined], // ${} containing $() with kill
  ['for f in $(ls); do echo $f; done; kill -9 4242', undefined], // for keyword: whole scan abstains
  ['echo "' + '$(echo "'.repeat(5000) + 'x' + '")'.repeat(5000) + '"; kill -9 4242', undefined], // deep nesting abstains, no stack overflow
  ['echo $(echo $((1+1))); kill -9 4242', undefined], // arithmetic $(( in plain-mode expansion
  ['echo ' + '$(echo '.repeat(70) + 'x' + ')'.repeat(70) + '; kill -9 4242', undefined], // plain-mode depth cap

  // ── regression: round 6 Codex review (approve; suggested test additions) ─
  ['x;'.repeat(2046) + ' kill -9 4242;', 'kill-host-pid'], // exactly 4096 tokens
  ['echo ' + '$(echo '.repeat(64) + 'x' + ')'.repeat(64) + '; kill -9 4242', 'kill-host-pid'], // 64 expansion layers
  ['echo ' + '$(echo '.repeat(65) + 'x' + ')'.repeat(65) + '; kill -9 4242', undefined], // 65 layers
  ['echo "`echo \\`x\\``" ; kill -9 4242', 'kill-host-pid'], // escaped backtick inside backtick
  ['echo a$()b ; kill -9 4242', 'kill-host-pid'], // empty $() in word
  ['{ echo x; } ; { kill -9 4242; }', 'kill-host-pid'], // parallel brace groups
  ['echo $((1+1)); kill -9 4242', undefined], // top-level arithmetic then kill
  ['echo $(echo $(echo $(echo x))) ; kill -9 4242', 'kill-host-pid'], // four-level $()
  ['echo ${x:-$(echo ${y:-z})} ; kill -9 4242', 'kill-host-pid'], // ${} in ${} in $()
]

test('matchHostKill matches or abstains per the command-list contract', () => {
  for (const [command, expected] of table) {
    assert.equal(matchHostKill(command, PID), expected, `command: ${JSON.stringify(command)}`)
  }
})

test('matchHostKill honors the enabled matcher set: first enabled hit in source order wins', () => {
  const all = new Set(['kill-host-pid', 'kill-parent', 'pkill-dsh', 'killall-dsh'] as const)
  assert.equal(matchHostKill('pkill dsh; kill -9 4242', PID, all), 'pkill-dsh')
  const killOnly = new Set(['kill-host-pid'] as const)
  assert.equal(matchHostKill('pkill dsh; kill -9 4242', PID, killOnly), 'kill-host-pid')
  const none = new Set<string>() as Set<never>
  assert.equal(matchHostKill('kill -9 4242', PID, none), undefined)
})

test('matchHostKill abstains beyond the resource bounds', () => {
  assert.equal(matchHostKill('kill -9 '.padEnd(MAX_COMMAND_BYTES + 1, 'x'), PID), undefined)
  const deep = '( '.repeat(MAX_NESTING + 1) + `kill -9 ${PID}` + ' )'.repeat(MAX_NESTING + 1)
  assert.equal(matchHostKill(deep, PID), undefined)
})
