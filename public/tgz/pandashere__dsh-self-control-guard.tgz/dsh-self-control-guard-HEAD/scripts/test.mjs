/**
 * Tool-template test runner.
 *
 * The tool template imports @deepseek-ai/dsh-tools, which is NOT published on
 * the public npm registry — it resolves only inside the harness (via the
 * harness's tsx tsconfig-paths hook, e.g. when running under `dsh web`).
 *
 * Behavior:
 *   - inside the harness environment: run the real test suite (real
 *     defineTool, real schema normalization)
 *   - standalone: print an explanation and skip (exit 0), so `npm run check`
 *     stays green without the harness
 */

import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

// Probe with the tsx loader, which is the resolver that knows the harness's
// tsconfig paths (TSX_TSCONFIG_PATH / the checkout's paths mapping).
const probe = spawnSync(
  process.execPath,
  [
    '--import', 'tsx',
    '--eval',
    "import('@deepseek-ai/dsh-tools').then(() => process.exit(0)).catch(() => process.exit(1))",
  ],
  { stdio: 'ignore' },
)

if (probe.status !== 0) {
  console.log(
    '[test] @deepseek-ai/dsh-tools is not resolvable outside the harness — ' +
      'skipping runtime tests (typecheck and compliance checks still run).\n' +
      '[test] Run them inside the harness: dsh web --patch ./cordis.patch.yml',
  )
  process.exit(0)
}

const projectRoot = fileURLToPath(new URL('..', import.meta.url))
const result = spawnSync(
  process.execPath,
  ['--import', 'tsx', '--test', 'test/*.test.ts'],
  { stdio: 'inherit', cwd: projectRoot },
)
process.exit(result.status ?? 1)
