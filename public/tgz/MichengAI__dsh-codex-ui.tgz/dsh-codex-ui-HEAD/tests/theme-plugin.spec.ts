import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import { mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { CODEX_UI_API_ENDPOINTS } from '../src/business-api.ts'
import { apply, isSubPluginDisabledOnDisk, name } from '../src/theme-plugin.ts'
import {
  ALL_BUILTIN_THEMES,
  applyGlassSettings,
  applyThemeToDocument,
  changeGlass,
  changeTheme,
  checkThemeEnabled,
  CLAUDE_DARK_THEME,
  CLAUDE_DARK_THEME_ID,
  CLAUDE_LIGHT_THEME,
  CLAUDE_LIGHT_THEME_ID,
  CODEX_DARK_THEME,
  CODEX_DARK_THEME_ID,
  CODEX_LIGHT_THEME,
  CODEX_LIGHT_THEME_ID,
  CYBERPUNK_THEME,
  CYBERPUNK_THEME_ID,
  DRACULA_THEME,
  DRACULA_THEME_ID,
  SOLARIZED_DARK_THEME,
  SOLARIZED_DARK_THEME_ID,
  SOLARIZED_LIGHT_THEME,
  SOLARIZED_LIGHT_THEME_ID,
  GRUVBOX_DARK_THEME,
  GRUVBOX_DARK_THEME_ID,
  GRUVBOX_LIGHT_THEME,
  GRUVBOX_LIGHT_THEME_ID,
  disposeGlassMode,
  GLASS_ATTRIBUTE,
  GLASS_COMPAT_ATTRIBUTE,
  GLASS_FLOAT_ATTRIBUTE,
  GLASS_PRESETS,
  getThemeSettingsState,
  refreshThemeSettingsSnapshot,
  restoreNativeThemePresentation,
  setThemeSubPluginEnabled,
  observeTheme,
  setGlassEnabled,
  setGlassGlow,
  setGlassMode,
  setGlassPreset,
  setThemeOption,
  STORAGE_KEYS,
  subscribeThemeSettings,
} from '../src/client/theme/index.ts'
import { ThemeSettingsCard } from '../src/client/theme/ThemeSettingsCard.tsx'
import React from 'react'
import { renderToString } from 'react-dom/server'

describe('codex-ui-theme 子模块与主题换肤', () => {
  const originalFetch = globalThis.fetch

  beforeEach(() => {
    localStorage.clear()
    disposeGlassMode()
    setThemeSubPluginEnabled(true)
    globalThis.fetch = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ enabled: true }),
    })
  })

  afterEach(() => {
    globalThis.fetch = originalFetch
    localStorage.clear()
    disposeGlassMode()
    setThemeSubPluginEnabled(true)
  })

  it('子插件元数据命名必须是 codex-ui-theme', () => {
    expect(name).toBe('codex-ui-theme')
  })

  it('宿主插件正确向 webServer 注册 /api/michengai/dsh-codex-ui/theme 端点', () => {
    const ctx = new Context()
    let registeredPath = ''
    let handlerFn:
      | ((
          req: unknown,
          res: {
            writeHead: (status: number, headers?: Record<string, string>) => void
            end: (body?: string) => void
          },
        ) => void)
      | undefined

    ctx.provide('webServer', {
      register: (options: { kind: 'exact'; path: string; handler: typeof handlerFn }) => {
        registeredPath = options.path
        handlerFn = options.handler
        return () => {
          registeredPath = ''
          handlerFn = undefined
        }
      },
    } as never)

    apply(ctx)

    expect(registeredPath).toBe(CODEX_UI_API_ENDPOINTS.theme)
    expect(handlerFn).toBeDefined()

    let responseStatus = 0
    let responseBody = ''
    handlerFn!(
      {},
      {
        writeHead: (status) => {
          responseStatus = status
        },
        end: (body) => {
          responseBody = body ?? ''
        },
      },
    )

    expect(responseStatus).toBe(200)
    expect(typeof JSON.parse(responseBody).enabled).toBe('boolean')
  })

  it('isSubPluginDisabledOnDisk 能准确识别 cordis.patch.yml 中的 disabled 配置', () => {
    const testDir = join(tmpdir(), `dcu-theme-test-${Date.now()}`)
    const desktopProfile = join(testDir, 'profiles', 'desktop')
    mkdirSync(desktopProfile, { recursive: true })
    const ctx = {
      get: (k: string) => (k === 'profileContext' ? { name: 'desktop', dir: desktopProfile } : undefined),
    } as never

    try {
      // 1. 无 disabled 配置
      writeFileSync(join(desktopProfile, 'cordis.patch.yml'), '- id: other\n  config: {}\n', 'utf8')
      expect(isSubPluginDisabledOnDisk('codex-ui-theme', testDir, ctx)).toBe(false)

      // 2. 显式配置 disabled: true
      writeFileSync(
        join(desktopProfile, 'cordis.patch.yml'),
        '- id: codex-ui-theme\n  disabled: true\n',
        'utf8',
      )
      expect(isSubPluginDisabledOnDisk('codex-ui-theme', testDir, ctx)).toBe(true)
    } finally {
      rmSync(testDir, { recursive: true, force: true })
    }
  })

  it('checkThemeEnabled 能正确通过 HTTP 端点探测子插件启用状态', async () => {
    // 成功响应
    globalThis.fetch = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ enabled: true }),
    } as Response)
    expect(await checkThemeEnabled()).toBe(true)

    // 显式禁用响应
    globalThis.fetch = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ enabled: false }),
    } as Response)
    expect(await checkThemeEnabled()).toBe(false)

    // 404 响应（子插件在 profile 中被停用，端点不存在）
    globalThis.fetch = vi.fn().mockResolvedValue({
      ok: false,
      status: 404,
    } as Response)
    expect(await checkThemeEnabled()).toBe(false)

    // 网络异常时遵循 fail-closed 契约回退官方原生
    globalThis.fetch = vi.fn().mockRejectedValue(new Error('Network error'))
    expect(await checkThemeEnabled()).toBe(false)
  })

  it('内置色盘包含完整的 14 套主题（4套Catppuccin + 2套Codex + 2套Claude + 1套Dracula + 2套Solarized + 2套Gruvbox + 1套Cyberpunk），均覆盖全套 190 个 --dsw-* 设计变量与 11 个 --shiki-* 代码高亮 Token', () => {
    expect(ALL_BUILTIN_THEMES.length).toBe(14)

    expect(CODEX_DARK_THEME.id).toBe(CODEX_DARK_THEME_ID)
    expect(CODEX_DARK_THEME.colorScheme).toBe('dark')
    expect(Object.keys(CODEX_DARK_THEME.tokens).length).toBe(201)

    expect(CODEX_LIGHT_THEME.id).toBe(CODEX_LIGHT_THEME_ID)
    expect(CODEX_LIGHT_THEME.colorScheme).toBe('light')
    expect(Object.keys(CODEX_LIGHT_THEME.tokens).length).toBe(201)

    expect(CLAUDE_DARK_THEME.id).toBe(CLAUDE_DARK_THEME_ID)
    expect(CLAUDE_DARK_THEME.colorScheme).toBe('dark')
    expect(Object.keys(CLAUDE_DARK_THEME.tokens).length).toBe(201)

    expect(CLAUDE_LIGHT_THEME.id).toBe(CLAUDE_LIGHT_THEME_ID)
    expect(CLAUDE_LIGHT_THEME.colorScheme).toBe('light')
    expect(Object.keys(CLAUDE_LIGHT_THEME.tokens).length).toBe(201)

    expect(DRACULA_THEME.id).toBe(DRACULA_THEME_ID)
    expect(DRACULA_THEME.colorScheme).toBe('dark')
    expect(Object.keys(DRACULA_THEME.tokens).length).toBe(201)

    expect(CYBERPUNK_THEME.id).toBe(CYBERPUNK_THEME_ID)
    expect(CYBERPUNK_THEME.colorScheme).toBe('dark')
    expect(Object.keys(CYBERPUNK_THEME.tokens).length).toBe(201)

    expect(SOLARIZED_DARK_THEME.id).toBe(SOLARIZED_DARK_THEME_ID)
    expect(SOLARIZED_DARK_THEME.colorScheme).toBe('dark')
    expect(Object.keys(SOLARIZED_DARK_THEME.tokens).length).toBe(201)

    expect(SOLARIZED_LIGHT_THEME.id).toBe(SOLARIZED_LIGHT_THEME_ID)
    expect(SOLARIZED_LIGHT_THEME.colorScheme).toBe('light')
    expect(Object.keys(SOLARIZED_LIGHT_THEME.tokens).length).toBe(201)

    expect(GRUVBOX_DARK_THEME.id).toBe(GRUVBOX_DARK_THEME_ID)
    expect(GRUVBOX_DARK_THEME.colorScheme).toBe('dark')
    expect(Object.keys(GRUVBOX_DARK_THEME.tokens).length).toBe(201)

    expect(GRUVBOX_LIGHT_THEME.id).toBe(GRUVBOX_LIGHT_THEME_ID)
    expect(GRUVBOX_LIGHT_THEME.colorScheme).toBe('light')
    expect(Object.keys(GRUVBOX_LIGHT_THEME.tokens).length).toBe(201)

    // 验证核心底色、强调色与高对比度文字
    expect(CODEX_DARK_THEME.tokens['--dsw-static-neutral-bluish-950']).toBe('#09090b')
    expect(CODEX_LIGHT_THEME.tokens['--dsw-static-neutral-bluish-00']).toBe('#ffffff')
    expect(CLAUDE_DARK_THEME.tokens['--dsw-alias-brand-primary']).toBe('#d97757')
    expect(CLAUDE_LIGHT_THEME.tokens['--dsw-alias-brand-primary']).toBe('#d97757')
    expect(DRACULA_THEME.tokens['--dsw-alias-brand-primary-new-colorprimary-new-color']).toBe('#ff79c6')
    expect(DRACULA_THEME.tokens['--dsw-static-neutral-bluish-950']).toBe('#191a21')
    expect(CYBERPUNK_THEME.tokens['--dsw-alias-brand-primary-new-colorprimary-new-color']).toBe('#00ff41')
    expect(CYBERPUNK_THEME.tokens['--dsw-static-neutral-bluish-950']).toBe('#000a00')
    expect(CYBERPUNK_THEME.tokens['--dsw-static-neutral-bluish-900']).toBe('#000600')
    expect(CYBERPUNK_THEME.tokens['--dsw-static-red-500']).toBe('#ff003c')
    expect(SOLARIZED_DARK_THEME.tokens['--dsw-static-neutral-bluish-950']).toBe('#002b36')
    expect(SOLARIZED_LIGHT_THEME.tokens['--dsw-static-neutral-bluish-00']).toBe('#fdf6e3')
    expect(GRUVBOX_DARK_THEME.tokens['--dsw-alias-brand-primary-new-colorprimary-new-color']).toBe('#fabd2f')
    expect(GRUVBOX_DARK_THEME.tokens['--dsw-static-neutral-bluish-950']).toBe('#282828')
    expect(GRUVBOX_LIGHT_THEME.tokens['--dsw-static-neutral-bluish-00']).toBe('#fbf1c7')

    // 验证全套主题的 Shiki 语法高亮覆盖
    expect(CODEX_DARK_THEME.tokens['--shiki-token-keyword']).toBe('#339cff')
    expect(CODEX_LIGHT_THEME.tokens['--shiki-token-keyword']).toBe('#0169cc')
    expect(CLAUDE_DARK_THEME.tokens['--shiki-token-keyword']).toBe('#d97757')
    expect(CLAUDE_LIGHT_THEME.tokens['--shiki-token-keyword']).toBe('#b53a1a')
    expect(DRACULA_THEME.tokens['--shiki-token-keyword']).toBe('#ff79c6')
    expect(DRACULA_THEME.tokens['--shiki-token-string']).toBe('#f1fa8c')
    expect(CYBERPUNK_THEME.tokens['--shiki-token-keyword']).toBe('#00ff41')
    expect(CYBERPUNK_THEME.tokens['--shiki-token-string']).toBe('#8cffb0')
    expect(SOLARIZED_DARK_THEME.tokens['--shiki-token-keyword']).toBe('#859900')
    expect(SOLARIZED_LIGHT_THEME.tokens['--shiki-token-keyword']).toBe('#859900')
    expect(GRUVBOX_DARK_THEME.tokens['--shiki-token-keyword']).toBe('#fb4934')
    expect(GRUVBOX_LIGHT_THEME.tokens['--shiki-token-keyword']).toBe('#9d0006')

    // 验证包含全部 14 套内置主题
    const themeIds = ALL_BUILTIN_THEMES.map((t) => t.id)
    expect(themeIds).toContain('catppuccin-mocha')
    expect(themeIds).toContain('catppuccin-macchiato')
    expect(themeIds).toContain('catppuccin-frappe')
    expect(themeIds).toContain('catppuccin-latte')
    expect(themeIds).toContain('claude-dark')
    expect(themeIds).toContain('claude-light')
    expect(themeIds).toContain('dracula')
    expect(themeIds).toContain('cyberpunk')
    expect(themeIds).toContain('solarized-dark')
    expect(themeIds).toContain('solarized-light')
    expect(themeIds).toContain('gruvbox-dark')
    expect(themeIds).toContain('gruvbox-light')
  })

  it('主题状态读写、持久化与广播订阅工作正常', () => {
    const initialState = getThemeSettingsState()
    expect(initialState.themeOption).toBe('stock')
    expect(initialState.glassEnabled).toBe(true)
    expect(initialState.glassMode).toBe('mica')
    expect(initialState.glassPreset).toBe('standard')

    const listener = vi.fn()
    const unsubscribe = subscribeThemeSettings(listener)

    setThemeOption('codex-dark')
    expect(localStorage.getItem(STORAGE_KEYS.themeOption)).toBe('codex-dark')
    expect(getThemeSettingsState().themeOption).toBe('codex-dark')
    expect(listener).toHaveBeenCalledTimes(1)

    setGlassEnabled(false)
    expect(localStorage.getItem(STORAGE_KEYS.glassEnabled)).toBe('false')
    expect(getThemeSettingsState().glassEnabled).toBe(false)
    expect(listener).toHaveBeenCalledTimes(2)

    setGlassMode('compat')
    expect(localStorage.getItem(STORAGE_KEYS.glassMode)).toBe('compat')
    expect(getThemeSettingsState().glassMode).toBe('compat')
    expect(listener).toHaveBeenCalledTimes(3)

    setGlassPreset('frosted')
    expect(localStorage.getItem(STORAGE_KEYS.glassPreset)).toBe('frosted')
    expect(getThemeSettingsState().glassPreset).toBe('frosted')
    expect(listener).toHaveBeenCalledTimes(4)

    setGlassGlow(true)
    expect(localStorage.getItem(STORAGE_KEYS.glassGlow)).toBe('true')
    expect(getThemeSettingsState().glassGlow).toBe(true)
    expect(listener).toHaveBeenCalledTimes(5)

    unsubscribe()
    setThemeOption('codex-light')
    expect(listener).toHaveBeenCalledTimes(5)
  })

  it('玻璃质感、云母/兼容排版模式与预设正确操作 DOM 与样式标签', () => {
    const root = document.documentElement

    // 1. 初始关闭
    applyGlassSettings({ enabled: false })
    expect(root.hasAttribute(GLASS_ATTRIBUTE)).toBe(false)
    expect(document.getElementById('dsh-codex-ui-glass-style')).toBeNull()

    // 2. 开启并选用云母模式 (mica) + clear 预设 + glow: true
    applyGlassSettings({ enabled: true, mode: 'mica', preset: 'clear', glow: true })
    expect(root.hasAttribute(GLASS_ATTRIBUTE)).toBe(true)
    expect(root.hasAttribute(GLASS_FLOAT_ATTRIBUTE)).toBe(true)
    expect(root.hasAttribute(GLASS_COMPAT_ATTRIBUTE)).toBe(false)
    expect(root.style.getPropertyValue('--dsh-glass-blur')).toBe(`${GLASS_PRESETS.clear.blur}px`)
    expect(root.style.getPropertyValue('--dsh-glass-glow')).toBe('1')
    expect(document.getElementById('dsh-codex-ui-glass-style')).not.toBeNull()

    // 3. 切换至原版兼容排版模式 (compat) + frosted 预设 + glow: false
    applyGlassSettings({ enabled: true, mode: 'compat', preset: 'frosted', glow: false })
    expect(root.hasAttribute(GLASS_ATTRIBUTE)).toBe(true)
    expect(root.hasAttribute(GLASS_FLOAT_ATTRIBUTE)).toBe(false)
    expect(root.hasAttribute(GLASS_COMPAT_ATTRIBUTE)).toBe(true)
    expect(root.style.getPropertyValue('--dsh-glass-blur')).toBe(`${GLASS_PRESETS.frosted.blur}px`)
    expect(root.style.getPropertyValue('--dsh-glass-glow')).toBe('0')

    // 4. 清理还原
    disposeGlassMode()
    expect(root.hasAttribute(GLASS_ATTRIBUTE)).toBe(false)
    expect(root.hasAttribute(GLASS_FLOAT_ATTRIBUTE)).toBe(false)
    expect(root.hasAttribute(GLASS_COMPAT_ATTRIBUTE)).toBe(false)
    expect(document.getElementById('dsh-codex-ui-glass-style')).toBeNull()
  })

  it('observeTheme 生命周期正常：注册全部 9 套主题，直通 changeTheme/changeGlass，卸载时纯净还原', () => {
    const registeredThemes: string[] = []
    let currentPreference = 'system'

    const fakeThemeRuntime = {
      register: vi.fn((def: { id: string }) => {
        registeredThemes.push(def.id)
        return () => {
          const idx = registeredThemes.indexOf(def.id)
          if (idx >= 0) registeredThemes.splice(idx, 1)
        }
      }),
      setTheme: vi.fn((id: string) => {
        currentPreference = id
      }),
      getTheme: vi.fn(() => ({
        preference: currentPreference,
        active: { id: currentPreference },
      })),
    }

    const ctx = new Context()
    ctx.provide('theme', fakeThemeRuntime as never)

    const dispose = observeTheme(ctx)

    // 验证注册了全部 14 套主题
    expect(fakeThemeRuntime.register).toHaveBeenCalledTimes(14)
    expect(registeredThemes).toContain(CODEX_DARK_THEME_ID)
    expect(registeredThemes).toContain(CODEX_LIGHT_THEME_ID)
    expect(registeredThemes).toContain(CLAUDE_DARK_THEME_ID)
    expect(registeredThemes).toContain(CLAUDE_LIGHT_THEME_ID)
    expect(registeredThemes).toContain(DRACULA_THEME_ID)
    expect(registeredThemes).toContain(CYBERPUNK_THEME_ID)
    expect(registeredThemes).toContain(SOLARIZED_DARK_THEME_ID)
    expect(registeredThemes).toContain(SOLARIZED_LIGHT_THEME_ID)
    expect(registeredThemes).toContain(GRUVBOX_DARK_THEME_ID)
    expect(registeredThemes).toContain(GRUVBOX_LIGHT_THEME_ID)
    expect(registeredThemes).toContain('catppuccin-mocha')
    expect(registeredThemes).toContain('catppuccin-latte')

    // 用户通过 UI 调用 changeTheme 切换至 gruvbox-dark
    changeTheme('gruvbox-dark')
    expect(fakeThemeRuntime.setTheme).toHaveBeenCalledWith('gruvbox-dark')
    expect(getThemeSettingsState().themeOption).toBe('gruvbox-dark')

    // 切换至 gruvbox-light
    changeTheme('gruvbox-light')
    expect(fakeThemeRuntime.setTheme).toHaveBeenCalledWith('gruvbox-light')
    expect(getThemeSettingsState().themeOption).toBe('gruvbox-light')

    // 用户通过 UI 调用 changeTheme 切换至 solarized-dark
    changeTheme('solarized-dark')
    expect(fakeThemeRuntime.setTheme).toHaveBeenCalledWith('solarized-dark')
    expect(getThemeSettingsState().themeOption).toBe('solarized-dark')

    // 切换至 solarized-light
    changeTheme('solarized-light')
    expect(fakeThemeRuntime.setTheme).toHaveBeenCalledWith('solarized-light')
    expect(getThemeSettingsState().themeOption).toBe('solarized-light')

    // 用户通过 UI 调用 changeTheme 切换至 dracula
    changeTheme('dracula')
    expect(fakeThemeRuntime.setTheme).toHaveBeenCalledWith('dracula')
    expect(getThemeSettingsState().themeOption).toBe('dracula')

    // 用户通过 UI 调用 changeTheme 切换至 claude-dark
    changeTheme('claude-dark')
    expect(fakeThemeRuntime.setTheme).toHaveBeenCalledWith('claude-dark')
    expect(getThemeSettingsState().themeOption).toBe('claude-dark')

    // 切换至 claude-light
    changeTheme('claude-light')
    expect(fakeThemeRuntime.setTheme).toHaveBeenCalledWith('claude-light')
    expect(getThemeSettingsState().themeOption).toBe('claude-light')

    // 用户通过 UI 调用 changeTheme 切换至 codex-dark
    changeTheme('codex-dark')
    expect(fakeThemeRuntime.setTheme).toHaveBeenCalledWith('codex-dark')
    expect(getThemeSettingsState().themeOption).toBe('codex-dark')

    // 切换至 catppuccin-mocha
    changeTheme('catppuccin-mocha')
    expect(fakeThemeRuntime.setTheme).toHaveBeenCalledWith('catppuccin-mocha')
    expect(getThemeSettingsState().themeOption).toBe('catppuccin-mocha')

    // 切换至 stock
    changeTheme('stock')
    expect(fakeThemeRuntime.setTheme).toHaveBeenCalledWith('system')

    // 用户通过 UI 调用 changeGlass
    changeGlass({ enabled: true, mode: 'mica', preset: 'standard' })
    expect(document.documentElement.hasAttribute(GLASS_ATTRIBUTE)).toBe(true)
    expect(document.documentElement.hasAttribute(GLASS_FLOAT_ATTRIBUTE)).toBe(true)

    // 用户在原版排版模式下切换预设
    changeGlass({ mode: 'compat', preset: 'frosted' })
    expect(document.documentElement.hasAttribute(GLASS_COMPAT_ATTRIBUTE)).toBe(true)
    expect(document.documentElement.style.getPropertyValue('--dsh-glass-blur')).toBe(
      `${GLASS_PRESETS.frosted.blur}px`,
    )

    // 卸载
    dispose()
    expect(document.documentElement.hasAttribute(GLASS_ATTRIBUTE)).toBe(false)
    expect(registeredThemes.length).toBe(0)
  })

  it('启动时对齐宿主 ThemeRuntime：当本地已保存自定义主题（如 catppuccin-latte）时，首帧必须调用 setTheme 对齐', async () => {
    localStorage.setItem(STORAGE_KEYS.themeOption, 'catppuccin-latte')
    refreshThemeSettingsSnapshot()

    let currentPreference = 'dark'
    const fakeThemeRuntime = {
      register: vi.fn(),
      setTheme: vi.fn((id: string) => {
        currentPreference = id
      }),
      getTheme: vi.fn(() => ({
        preference: currentPreference,
        active: { id: currentPreference },
      })),
    }

    const ctx = new Context()
    ctx.provide('theme', fakeThemeRuntime as never)

    const dispose = observeTheme(ctx)

    try {
      await vi.waitFor(() => {
        expect(fakeThemeRuntime.setTheme).toHaveBeenCalledWith('catppuccin-latte')
      })
      expect(document.documentElement.style.colorScheme).toBe('light')
      expect(document.body.hasAttribute('data-ds-dark-theme')).toBe(false)
    } finally {
      dispose()
      localStorage.removeItem(STORAGE_KEYS.themeOption)
      refreshThemeSettingsSnapshot()
    }
  })

  it('宿主触发 theme/change 时：浅色主题必须强制纠正 data-ds-dark-theme 与 colorScheme，防止黑字压黑底', () => {
    localStorage.setItem(STORAGE_KEYS.themeOption, 'catppuccin-latte')
    refreshThemeSettingsSnapshot()

    const fakeThemeRuntime = {
      register: vi.fn(),
      setTheme: vi.fn(),
      getTheme: vi.fn(() => ({
        preference: 'catppuccin-latte',
        active: { id: 'catppuccin-latte', colorScheme: 'light' },
      })),
    }

    const ctx = new Context()
    ctx.provide('theme', fakeThemeRuntime as never)

    const dispose = observeTheme(ctx)

    try {
      // 模拟宿主 ui-layout 呈现器在接收到系统事件后，误将 body 标为 dark 态
      document.body.setAttribute('data-ds-dark-theme', '')
      document.documentElement.style.colorScheme = 'dark'

      // 宿主触发 theme/change
      ctx.emit('theme/change', {
        preference: 'system',
        active: { id: 'dark', colorScheme: 'dark', tokens: {} },
      } as never)

      // 验证 observeTheme 拦截 theme/change 并强制同步为用户的浅色主题属性，绝不允许残留 data-ds-dark-theme
      expect(document.body.hasAttribute('data-ds-dark-theme')).toBe(false)
      expect(document.documentElement.style.colorScheme).toBe('light')
    } finally {
      dispose()
      localStorage.removeItem(STORAGE_KEYS.themeOption)
      refreshThemeSettingsSnapshot()
    }
  })

  it('stock 分支安全守卫：宿主运行原生主题时不调用 setTheme，且彻底清理 DOM 根属性残留', () => {
    let hostTheme = 'dark'
    const fakeRuntime = {
      register: vi.fn(),
      getTheme: vi.fn(() => ({
        preference: hostTheme,
        active: { id: hostTheme },
      })),
      setTheme: vi.fn((id: string) => {
        hostTheme = id
      }),
    }

    // 1. 模拟用户先选了 codex-dark 自定义主题
    applyThemeToDocument('codex-dark', fakeRuntime as never)
    expect(document.documentElement.style.colorScheme).toBe('dark')
    expect(document.documentElement.getAttribute('data-ds-theme-source')).toBe('dark')
    expect(document.body.hasAttribute('data-ds-dark-theme')).toBe(true)
    expect(fakeRuntime.setTheme).toHaveBeenCalledWith('codex-dark')

    // 2. 切回 stock：因为当前 active 是 codex-dark（属于自定义主题），正常还给 system，并恢复原生呈现
    fakeRuntime.setTheme.mockClear()
    applyThemeToDocument('stock', fakeRuntime as never)
    expect(fakeRuntime.setTheme).toHaveBeenCalledWith('system')
    expect(document.documentElement.dataset.dsThemeSource).toBe('system')

    // 3. 关键场景（P1 回归防线）：宿主此时明确运行官方 dark，宿主自行挂载了 dark 根属性，
    // 在 stock 状态下无论拨动几次开关或刷新，绝对不能重置为 system，且绝对不能删除宿主的 dark 属性！
    hostTheme = 'dark'
    document.documentElement.style.colorScheme = 'dark'
    document.documentElement.setAttribute('data-ds-theme-source', 'dark')
    document.body.setAttribute('data-ds-dark-theme', '')

    fakeRuntime.setTheme.mockClear()
    applyThemeToDocument('stock', fakeRuntime as never)
    expect(fakeRuntime.setTheme).not.toHaveBeenCalled()
    expect(document.documentElement.style.colorScheme).toBe('dark')
    expect(document.documentElement.getAttribute('data-ds-theme-source')).toBe('dark')
    expect(document.body.hasAttribute('data-ds-dark-theme')).toBe(true)
  })

  it('restoreNativeThemePresentation 契约防护：当宿主偏好为自定义深色主题（如 codex-dark）时，必须按 active.colorScheme 恢复且属性值合法', () => {
    const fakeRuntime = {
      register: vi.fn(),
      getTheme: vi.fn(() => ({
        preference: 'codex-dark',
        active: { id: 'codex-dark', colorScheme: 'dark' as const },
      })),
      setTheme: vi.fn(),
    }

    restoreNativeThemePresentation(fakeRuntime as never)
    expect(document.documentElement.dataset.dsThemeSource).toBe('dark')
    expect(document.documentElement.style.colorScheme).toBe('dark')
    expect(document.body.hasAttribute('data-ds-dark-theme')).toBe(true)
  })

  it('新装用户默认开箱即用：未持久化 glassEnabled 时默认随排版模式激活 (true)', () => {
    setGlassEnabled(false)
    expect(getThemeSettingsState().glassEnabled).toBe(false)

    localStorage.removeItem(STORAGE_KEYS.glassEnabled)
    refreshThemeSettingsSnapshot()
    expect(getThemeSettingsState().glassEnabled).toBe(true)
  })

  it('主题探活具备自愈机制：初次失败降级后，端点恢复时能够自动重新激活', async () => {
    const root = document.documentElement
    root.removeAttribute(GLASS_ATTRIBUTE)

    // 1. 初次探活失败（模拟网关未就绪 404）
    globalThis.fetch = vi.fn().mockResolvedValue({
      ok: false,
      status: 404,
    } as Response)

    const ctx = {
      on: vi.fn(),
      get: vi.fn().mockReturnValue(undefined),
    }

    const dispose = observeTheme(ctx as never)
    // 等待首帧探活执行
    await new Promise((r) => setTimeout(r, 50))
    expect(root.hasAttribute(GLASS_ATTRIBUTE)).toBe(false)

    // 2. 服务恢复 200 { enabled: true }，触发 focus 事件自愈
    globalThis.fetch = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ enabled: true }),
    } as Response)

    window.dispatchEvent(new Event('focus'))
    await new Promise((r) => setTimeout(r, 50))

    // 自愈成功，毛玻璃重新挂载
    expect(root.hasAttribute(GLASS_ATTRIBUTE)).toBe(true)

    dispose()
  })

  it('当主题子插件被停用（fail-closed）时，所有切主题与事件回填入口全部物理熔断，0 个 Token 被写入 DOM', () => {
    try {
      setThemeSubPluginEnabled(false)
      document.body.removeAttribute('style')

      const fakeRuntime = {
        setTheme: vi.fn(),
        getTheme: () => ({ active: { id: 'dark' } }),
      }

      // 1. 尝试直接调用 changeTheme
      changeTheme('codex-dark')
      expect(document.body.style.length).toBe(0)
      expect(fakeRuntime.setTheme).not.toHaveBeenCalled()

      // 2. 尝试调用 applyThemeToDocument
      applyThemeToDocument('codex-dark', fakeRuntime as never)
      expect(document.body.style.length).toBe(0)
      expect(fakeRuntime.setTheme).not.toHaveBeenCalled()
    } finally {
      setThemeSubPluginEnabled(true)
    }
  })

  it('当主题子插件被停用时，ThemeSettingsCard 换肤内容直接全部隐藏 (返回 null)', () => {
    try {
      setThemeSubPluginEnabled(false)
      expect(getThemeSettingsState().subPluginEnabled).toBe(false)
      const htmlDisabled = renderToString(React.createElement(ThemeSettingsCard, { t: (k: string) => k }))
      expect(htmlDisabled).toBe('')

      setThemeSubPluginEnabled(true)
      expect(getThemeSettingsState().subPluginEnabled).toBe(true)
      const htmlEnabled = renderToString(React.createElement(ThemeSettingsCard, { t: (k: string) => k }))
      expect(htmlEnabled).toContain('dcu-theme-settings')
    } finally {
      setThemeSubPluginEnabled(true)
    }
  })

  it('确保注入并清理消除插件页顶栏色差的全局表面样式', () => {
    applyThemeToDocument('codex-dark')
    const tag = document.getElementById('dsh-codex-ui-theme-surface-style')
    expect(tag).not.toBeNull()
    expect(tag?.textContent).toContain('[data-plugin-bar]:before')
    expect(tag?.textContent).toContain('background: transparent !important')

    applyThemeToDocument('stock')
    expect(document.getElementById('dsh-codex-ui-theme-surface-style')).toBeNull()
  })

  it('代码高亮预览样式必须精准使用宿主字体族变量 --dsw-font-markdown-code-block-font-family，严禁使用简写变量', () => {
    const html = renderToString(React.createElement(ThemeSettingsCard, { t: (k: string) => k }))
    expect(html).toContain('dcu-theme-code-sample')
    expect(html).toContain('--dsw-font-markdown-code-block-font-family')
    expect(html).not.toMatch(/font-family:[^;]*var\(--dsw-font-markdown-code-block,/)
  })

  it('全套 14 款内置主题不得包含跨主题脏残留，且 Cyberpunk 严格对齐 Hermes Agent 矩阵终端色阶与对比度', () => {
    const resolveHex = (tokens: Record<string, string>, raw: string | undefined, depth = 0): string => {
      if (!raw || depth > 6) return ''
      const m = raw.trim().match(/^var\((--[a-z0-9-]+)\)$/i)
      if (!m) return raw.trim()
      return resolveHex(tokens, tokens[m[1]], depth + 1)
    }
    const luminance = (hex: string): number => {
      const clean = hex.replace('#', '')
      const [r, g, b] = [0, 2, 4]
        .map((i) => parseInt(clean.slice(i, i + 2), 16) / 255)
        .map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4))
      return 0.2126 * r + 0.7152 * g + 0.0722 * b
    }
    const contrast = (a: string, b: string): number => {
      const la = luminance(a)
      const lb = luminance(b)
      return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05)
    }

    // 1. 跨主题特征残留扫描（任何非 Dracula 主题不得混入 Dracula 粉/紫蓝残留，非对应家族不得泄漏品牌主色）
    const crossSignatures: Record<string, readonly string[]> = {
      dracula: ['#ff79c6', '#ff92d0', '255, 121, 198', '98, 114, 164', '#bd93f9', '#8be9fd', '#282a36'],
      claude: ['#d97757', '#c46343', '#bf6446', '246, 136, 98'],
      codex: ['#339cff', '#0169cc'],
      solarized: ['#2aa198', '#268bd2', '#002b36', '#fdf6e3'],
      gruvbox: ['#fabd2f', '#b57614', '#fbf1c7'],
      catppuccin: ['#cba6f7', '#89b4fa', '#1e1e2e', '#eff1f5'],
      cyberpunk: ['#00ff41', '#000a00', '#000600'],
    }
    for (const theme of ALL_BUILTIN_THEMES) {
      const family = theme.id.split('-')[0]
      for (const [key, value] of Object.entries(theme.tokens)) {
        for (const [sigFamily, patterns] of Object.entries(crossSignatures)) {
          if (sigFamily === family) continue
          for (const pattern of patterns) {
            expect(
              value.toLowerCase(),
              `${theme.id} 的 ${key} 疑似包含 ${sigFamily} 残留 (${pattern})`,
            ).not.toContain(pattern)
          }
        }
      }
    }

    // 2. Cyberpunk 对齐 Hermes Agent 矩阵终端规范（表面递增、文字梯度单调、无亮青辅助字乱窜、注释清晰）
    const t = CYBERPUNK_THEME.tokens
    const base = resolveHex(t, t['--dsw-alias-bg-base'])
    const sidebar = resolveHex(t, t['--dsw-specific-sidebar-fill'])
    const l1 = resolveHex(t, t['--dsw-alias-bg-layer-1'])
    const l2 = resolveHex(t, t['--dsw-alias-bg-layer-2'])
    const l3 = resolveHex(t, t['--dsw-alias-bg-layer-3'])
    const codeBg = resolveHex(t, t['--dsw-alias-markdown-code-block'])

    expect(base).toBe('#000a00')
    expect(sidebar).toBe('#000600')
    expect(luminance(l1)).toBeGreaterThan(luminance(base))
    expect(luminance(l2)).toBeGreaterThan(luminance(l1))
    expect(luminance(l3)).toBeGreaterThan(luminance(l2))

    const pri = resolveHex(t, t['--dsw-alias-label-primary'])
    const sec = resolveHex(t, t['--dsw-alias-label-secondary'])
    const ter = resolveHex(t, t['--dsw-alias-label-tertiary'])
    const cap = resolveHex(t, t['--dsw-alias-label-caption'])

    expect(pri).toBe('#00ff41')
    expect(sec).toBe('#00cc34')
    expect(ter).not.toBe('#00c8d6')
    expect(cap).toBe('#1a8a30')
    expect(contrast(pri, base)).toBeGreaterThanOrEqual(contrast(sec, base))
    expect(contrast(sec, base)).toBeGreaterThanOrEqual(contrast(ter, base))
    expect(contrast(ter, base)).toBeGreaterThanOrEqual(contrast(cap, base))
    expect(contrast(ter, base)).toBeGreaterThanOrEqual(4.5)
    expect(contrast(cap, base)).toBeGreaterThanOrEqual(4.5)
    expect(contrast(t['--shiki-token-comment'], codeBg)).toBeGreaterThanOrEqual(4.5)

    // 3. 设置卡色块强调色同步为 #00ff41
    const html = renderToString(React.createElement(ThemeSettingsCard, { t: (k: string) => k }))
    expect(html).toContain('--cube-accent:#00ff41')
  })
})
