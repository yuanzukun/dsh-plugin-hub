// @vitest-environment jsdom
import { act, createElement } from 'react'
import { createRoot } from 'react-dom/client'
import { expect, test, vi } from 'vitest'
import { GlobalPanelButtons, createGlobalPanelSource } from '../src/client/global-panels.tsx'

test('官方插件面板不进入侧栏顶栏，扩展管理已有自己的入口', () => {
  const entries = [
    { options: { id: 'plugins', order: 0, label: () => '插件' } },
    { options: { id: 'files', order: 2, label: () => '文件' } },
  ]
  const source = createGlobalPanelSource({ entriesOfSlot: () => entries, subscribe: () => () => {} }, { subscribe: () => () => {} })
  expect(source.getSnapshot().map(panel => panel.id)).toEqual(['files'])
})

test('面板注册、重命名、移除和语言更新实时同步并释放订阅', () => {
  let entries = [{ options: { id: 'files', order: 2, label: () => '文件' } }]
  const listeners = new Set<() => void>()
  const subscribe = (_name: unknown, fn?: () => void) => { const listener = fn ?? _name as () => void; listeners.add(listener); return () => { listeners.delete(listener) } }
  const source = createGlobalPanelSource({ entriesOfSlot: () => entries, subscribe }, { subscribe: listener => subscribe(listener) })
  const changed = vi.fn()
  const off = source.subscribe(changed)
  expect(source.getSnapshot().map(p => p.label)).toEqual(['文件'])
  const first = source.getSnapshot()
  expect(source.getSnapshot()).toBe(first)
  listeners.forEach(fn => fn())
  expect(source.getSnapshot()).toBe(first)
  entries = [{ options: { id: 'files', order: 2, label: () => 'Files' } }]
  listeners.forEach(fn => fn())
  expect(source.getSnapshot()[0]?.label).toBe('Files')
  entries = []
  listeners.forEach(fn => fn())
  expect(source.getSnapshot()).toEqual([])
  off()
  expect(listeners.size).toBe(0)
})

test.each([true, false])('全局面板不再额外插入返回会话的任务入口；展开=%s', async wide => {
  const mount = document.createElement('div'); document.body.append(mount)
  const root = createRoot(mount), select = vi.fn()
  try {
    await act(async () => root.render(createElement(GlobalPanelButtons, {
      panels: [{ id: 'schedules', label: '自动化任务', order: 1 }], activeId: 'schedules', wide,
      selectPanel: select, renderIcon: (_id, active) => active ? '●' : '○',
    })))
    expect(mount.querySelector('[aria-label="任务"]')).toBeNull()
    const panel = mount.querySelector<HTMLButtonElement>('[aria-label="自动化任务"]')!
    expect(panel.getAttribute('aria-current')).toBe('page')
    panel.click()
    expect(select.mock.calls).toEqual([['schedules']])
  } finally { await act(async () => root.unmount()); mount.remove() }
})
