import { createRequire } from 'node:module'
import { act, createElement, type ReactNode } from 'react'
import { expect, test } from 'vitest'
import { legacyPendingInteraction, pendingInteractionForSession, visiblePendingKind } from '../src/client/session-pending.ts'
import { SessionRow } from '../src/client/session-tree.tsx'

const createRoot = (createRequire(import.meta.url)('react-dom/client') as {
  createRoot: (container: Element) => { render: (node: ReactNode) => void; unmount: () => void }
}).createRoot

test('只显示官方 SessionSummary 支持的待处理交互字符串', () => {
  expect(visiblePendingKind('question')).toBe('question')
  expect(visiblePendingKind('approval')).toBe('approval')
  expect(visiblePendingKind('plan-review')).toBe('plan-review')
  expect(visiblePendingKind('custom')).toBeUndefined()
  expect(visiblePendingKind({ kind: 'question' })).toBeUndefined()
  expect(visiblePendingKind(undefined)).toBeUndefined()
})

test('会话快照优先并在缺失时回退到待处理交互 Store', () => {
  const pendingInteractions = new Map([
    ['session-approval', { kind: 'approval' }],
    ['session-invalid', { kind: 'custom' }],
  ])

  expect(pendingInteractionForSession('session-approval', pendingInteractions)).toBe('approval')
  expect(pendingInteractionForSession('session-approval', pendingInteractions, 'question')).toBe('question')
  expect(pendingInteractionForSession('session-approval', pendingInteractions, 'custom')).toBe('approval')
  expect(pendingInteractionForSession('session-invalid', pendingInteractions)).toBeUndefined()
  expect(pendingInteractionForSession('session-missing', pendingInteractions)).toBeUndefined()
})

test('仅从旧版会话快照读取待处理交互字段', () => {
  expect(legacyPendingInteraction({ pendingInteraction: 'question' })).toBe('question')
  expect(legacyPendingInteraction({ running: true })).toBeUndefined()
  expect(legacyPendingInteraction(null)).toBeUndefined()
})

test('待处理交互覆盖未读点和运行中状态', async () => {
  const container = document.createElement('div')
  const root = createRoot(container)
  try {
    await act(async () => {
      root.render(createElement(SessionRow, {
        id: 'session-question',
        title: '需要确认的任务',
        selected: false,
        menuOpen: false,
        unread: true,
        running: true,
        pendingInteraction: 'question',
        t: (key: string) => key === 'sessions.waitingAnswer' ? '等待回答' : key,
        menuItems: [],
        onOpen: () => {},
        onMenuChange: () => {},
        onSelectAction: () => {},
        onArchive: () => {},
        onHover: () => {},
        onLeave: () => {},
        onContextMenu: () => {},
      } as never))
    })

    const pending = container.querySelector('[data-state="warning"]')
    expect(pending?.textContent).toBe('等待回答')
    expect(container.querySelector('.dcu-wb-unread')).toBeNull()
    expect(container.querySelector('.dcu-wb-running')).toBeNull()
  } finally {
    await act(async () => { root.unmount() })
  }
})

test('会话行右侧显示相对时间，待处理时仍渲染但由样式隐藏', async () => {
  const container = document.createElement('div')
  const root = createRoot(container)
  try {
    await act(async () => {
      root.render(createElement(SessionRow, {
        id: 'session-time',
        title: '带时间的任务',
        selected: false,
        menuOpen: false,
        unread: false,
        running: false,
        time: '3小时',
        t: (key: string) => key,
        menuItems: [],
        onOpen: () => {},
        onMenuChange: () => {},
        onSelectAction: () => {},
        onArchive: () => {},
        onHover: () => {},
        onLeave: () => {},
        onContextMenu: () => {},
      } as never))
    })
    expect(container.querySelector('.dcu-wb-session-time')?.textContent).toBe('3小时')

    await act(async () => {
      root.render(createElement(SessionRow, {
        id: 'session-time-pending',
        title: '带时间的任务',
        selected: false,
        menuOpen: false,
        unread: false,
        running: false,
        pendingInteraction: 'question',
        time: '3小时',
        t: (key: string) => key === 'sessions.waitingAnswer' ? '等待回答' : key,
        menuItems: [],
        onOpen: () => {},
        onMenuChange: () => {},
        onSelectAction: () => {},
        onArchive: () => {},
        onHover: () => {},
        onLeave: () => {},
        onContextMenu: () => {},
      } as never))
    })
    expect(container.querySelector('.dcu-wb-pending')?.textContent).toBe('等待回答')
    expect(container.querySelector('.dcu-wb-session-time')?.textContent).toBe('3小时')
  } finally {
    await act(async () => { root.unmount() })
  }
})
