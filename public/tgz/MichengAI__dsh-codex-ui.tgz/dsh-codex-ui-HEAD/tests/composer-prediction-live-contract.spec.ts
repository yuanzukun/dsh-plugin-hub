import { describe, expect, it, vi } from 'vitest'
import { apply as applyPredictions } from '../src/composer-prediction.ts'
import { CODEX_UI_API_ENDPOINTS } from '../src/business-api.ts'

describe('composer-prediction: 真实宿主契约与防御回归', () => {
  it('正确解析 DSH 真实 tool-call 与 tool-result 结构并注入 prompt', async () => {
    let streamHandler: any = null
    const webServer = {
      register: (options: any) => {
        if (options.path === CODEX_UI_API_ENDPOINTS.composerPredictionStream) {
          streamHandler = options.handler
        }
        return () => {}
      },
    }

    let capturedSystemPrompt = ''
    let capturedUserPrompt = ''
    let capturedConfig: any = null

    const mockLlm = {
      prepareCall: vi.fn(async (config, signal) => {
        capturedConfig = config
        return {
          config,
          stream: async function* () {
            yield { type: 'text-delta', text: 'dsh-pua 目录下的代码是否有问题' }
            yield { type: 'finish', reason: { kind: 'stop' } }
          },
        }
      }),
    }

    const mockSession = {
      seq: 1,
      deriveMessages: () => [
        {
          role: 'user',
          content: [{ type: 'text', text: '请帮我跑一下测试' }],
        },
        {
          role: 'assistant',
          content: [
            { type: 'text', text: '正在运行测试...' },
            { type: 'tool-call', id: 'call_1', name: 'terminal', arguments: 'pnpm test' },
          ],
        },
        {
          role: 'user',
          source: { kind: 'tool' },
          content: [
            {
              type: 'tool-result',
              toolCallId: 'call_1',
              content: [{ type: 'text', text: 'Tests passed: 319' }],
              isError: false,
            },
          ],
        },
        {
          role: 'assistant',
          content: [{ type: 'text', text: '测试已全绿，还有其他任务吗？' }],
        },
      ],
      requestHeader: () => ({
        config: { provider: 'deepseek-official', model: 'deepseek-flash' },
      }),
    }

    const mockCtx = {
      webServer,
      connection: { admit: vi.fn(() => ({ peer: { principal: { kind: 'owner' } } })) },
      llm: mockLlm,
      sessions: { get: vi.fn((id) => (id === 'sess_1' ? mockSession : undefined)) },
      effect: (fn: any) => fn(),
    } as any

    applyPredictions(mockCtx)

    const response = {
      writeHead: vi.fn(),
      write: vi.fn(),
      end: vi.fn(),
      on: vi.fn(),
    }

    await streamHandler(
      {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        [Symbol.asyncIterator]: async function* () {
          yield Buffer.from(JSON.stringify({ sessionId: 'sess_1', mode: 'continue', draft: '请帮我检查' }))
        },
      },
      response,
    )

    // 当模型通过 resolveModelInfo 声明支持 off 时，带入 reasoningEffort
    expect(mockLlm.prepareCall).toHaveBeenCalled()
    expect(capturedConfig.maxTokens).toBe(1024)

    // 验证 SSE 流式发送了 meta 和 delta
    expect(response.writeHead).toHaveBeenCalledWith(200, expect.objectContaining({
      'content-type': 'text/event-stream; charset=utf-8',
    }))
  })

  it('当模型不支持 reasoningEffort 或抛出 UNSUPPORTED_REASONING_EFFORT 时，平滑降级剥离参数重试', async () => {
    let jsonHandler: any = null
    const webServer = {
      register: (options: any) => {
        if (options.path === CODEX_UI_API_ENDPOINTS.composerPrediction) {
          jsonHandler = options.handler
        }
        return () => {}
      },
    }

    const configsReceived: any[] = []
    const mockLlm = {
      // 模拟模型未声明 reasoning 或 resolveModelInfo 抛错
      resolveModelInfo: vi.fn(async () => ({ id: 'probe-model', reasoning: undefined })),
      prepareCall: vi.fn(async (config: any) => {
        configsReceived.push(config)
        if (config.reasoningEffort !== undefined) {
          const err = new Error('provider "probe" model "probe-model" does not support reasoning effort "off"')
          ;(err as any).code = 'UNSUPPORTED_REASONING_EFFORT'
          throw err
        }
        return {
          config,
          stream: async function* () {
            yield { type: 'text-delta', text: '继续进行下一步重构' }
            yield { type: 'finish', reason: { kind: 'stop' } }
          },
        }
      }),
    }

    const mockSession = {
      seq: 3,
      deriveMessages: () => [
        { role: 'user', content: [{ type: 'text', text: '你好' }] },
        { role: 'assistant', content: [{ type: 'text', text: '请问有什么任务？' }] },
      ],
      requestHeader: () => ({ config: { provider: 'probe', model: 'probe-model' } }),
    }

    const mockCtx = {
      webServer,
      connection: { admit: vi.fn(() => ({ peer: { principal: { kind: 'owner' } } })) },
      llm: mockLlm,
      sessions: { get: vi.fn(() => mockSession) },
      effect: (fn: any) => fn(),
    } as any

    applyPredictions(mockCtx)

    let writtenBody = ''
    const response = {
      writeHead: vi.fn(),
      end: vi.fn((body) => { writtenBody = body }),
      on: vi.fn(),
    }

    await jsonHandler(
      {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        [Symbol.asyncIterator]: async function* () {
          yield Buffer.from(JSON.stringify({ sessionId: 'sess_fallback', mode: 'next', draft: '' }))
        },
      },
      response,
    )

    // 验证调用了 resolveModelInfo，且由于不支持 reasoning，最终下发的配置绝对不含 reasoningEffort
    expect(mockLlm.resolveModelInfo).toHaveBeenCalled()
    expect(configsReceived[0].reasoningEffort).toBeUndefined()
    const parsed = JSON.parse(writtenBody)
    expect(parsed.suggestions).toEqual(['继续进行下一步重构'])
  })

  it('辅助模型调用必须携带 sessionId：OpenCode 网关按 x-opencode-session 头路由，缺失即 400', async () => {
    let streamHandler: any = null
    const webServer = {
      register: (options: any) => {
        if (options.path === CODEX_UI_API_ENDPOINTS.composerPredictionStream) {
          streamHandler = options.handler
        }
        return () => {}
      },
    }

    let capturedStreamOptions: any = null
    const mockLlm = {
      prepareCall: vi.fn(async (config: any) => ({
        config,
        stream: async function* (options: any) {
          capturedStreamOptions = options
          yield { type: 'text-delta', text: '继续检查参数校验' }
          yield { type: 'finish', reason: { kind: 'stop' } }
        },
      })),
    }

    const mockSession = {
      seq: 4,
      deriveMessages: () => [
        { role: 'user', content: [{ type: 'text', text: '你好' }] },
        { role: 'assistant', content: [{ type: 'text', text: '请问有什么任务？' }] },
      ],
      requestHeader: () => ({ config: { provider: 'opencode-go', model: 'deepseek-v4.1-flash' } }),
    }

    const mockCtx = {
      webServer,
      connection: { admit: vi.fn(() => ({ peer: { principal: { kind: 'owner' } } })) },
      llm: mockLlm,
      sessions: { get: vi.fn(() => mockSession) },
      effect: (fn: any) => fn(),
    } as any

    applyPredictions(mockCtx)

    const response = { writeHead: vi.fn(), write: vi.fn(), end: vi.fn(), on: vi.fn() }

    await streamHandler(
      {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        [Symbol.asyncIterator]: async function* () {
          yield Buffer.from(JSON.stringify({ sessionId: 'sess_opencode', mode: 'continue', draft: '请帮我检查' }))
        },
      },
      response,
    )

    expect(capturedStreamOptions).not.toBeNull()
    expect(capturedStreamOptions.sessionId).toBe('sess_opencode')
    expect(capturedStreamOptions.purpose).toBe('composer-prediction')
  })

  it.each([
    { name: '限长时保留没有尾换行的单行预测', draft: '', text: '继续核对结果', finish: 'max-tokens', items: ['继续核对结果'] },
    { name: '限长时保留单行续写的前导空格', draft: '请检查', text: ' 这段代码', finish: 'max-tokens', items: [' 这段代码'] },
    { name: '限长时跳过前导空行并回收唯一候选', draft: '', text: '\r\n继续核对结果', finish: 'max-tokens', items: ['继续核对结果'] },
    { name: '限长时完整行都被过滤则回收可用续写', draft: '请检查', text: 'Write only the continuation text.\nDraft text ending at the caret:\n请检查 这段代码', finish: 'max-tokens', items: [' 这段代码'] },
    { name: '限长时明确无候选后不回收残片', draft: '', text: 'NONE\r\n我', finish: 'max-tokens', items: [] },
    { name: '提示词回声后的无候选标记仍终止续写', draft: '请检查', text: 'Write only the continuation text.\n"NONE"\n请检查 这段代码是', finish: 'max-tokens', items: [] },
    { name: '正常结束时无候选标记后不返回多余文本', draft: '', text: 'NONE\n多余文本', finish: 'stop', items: [] },
    { name: '限长时仍保留没有无候选标记的有效短建议', draft: '', text: '好的', finish: 'max-tokens', items: ['好的'] },
    { name: '限长时不把半截提示词回声作为候选', draft: '请检查', text: 'Write only the cont', finish: 'max-tokens', items: [] },
    { name: '带冒号和正文的标签回声不出现在最终候选中', draft: '请检查', text: 'Draft text ending at the caret: "请检查"\n请检查 这段代码', finish: 'stop', items: [' 这段代码'] },
    { name: '限长时已有完整候选则舍弃不完整末行', draft: '', text: '继续核对结果\n再看看不完整的', finish: 'max-tokens', items: ['继续核对结果'] },
    { name: '正常结束时保留没有尾换行的最后一个候选', draft: '', text: '继续核对结果\n运行测试', finish: 'stop', items: ['继续核对结果', '运行测试'] },
    { name: '限长但没有任何可用正文时仍返回空结果', draft: '', text: 'none\n', finish: 'max-tokens', items: [] },
  ])('$name', async ({ draft, text, finish, items }) => {
    const request = {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      async *[Symbol.asyncIterator]() {
        yield Buffer.from(JSON.stringify({ sessionId: 'sess_truncated', mode: draft ? 'continue' : 'next', draft }))
      },
    }
    const response = { writeHead: vi.fn(), write: vi.fn<(frame: string) => void>(), end: vi.fn(), on: vi.fn() }
    const register = vi.fn((_route: { path: string; handler: (req: typeof request, res: typeof response) => Promise<void> }) => () => {})
    const mockSession = {
      seq: 1,
      deriveMessages: () => [
        { role: 'user', content: [{ type: 'text', text: '请帮我跑一下测试' }] },
        { role: 'assistant', content: [{ type: 'text', text: '测试已完成' }] },
      ],
      requestHeader: () => ({ config: { provider: 'test', model: 'test' } }),
    }
    applyPredictions({
      webServer: { register },
      llm: {
        prepareCall: async (config: unknown) => ({
          config,
          stream: async function* () {
            yield { type: 'text-delta', text }
            yield { type: 'finish', reason: { kind: finish } }
          },
        }),
      },
      sessions: { get: () => mockSession },
      effect: (fn: () => unknown) => fn(),
    } as any)

    const stream = register.mock.calls.find(([route]) => route.path === CODEX_UI_API_ENDPOINTS.composerPredictionStream)?.[0]
    if (stream === undefined) throw new Error('预测流端点未注册')
    await stream.handler(request, response)

    const events = response.write.mock.calls.map(([frame]) => JSON.parse(frame.slice('data: '.length)))
    expect(events.at(-1)).toEqual(items.length > 0
      ? { type: 'done', items, cached: false }
      : { type: 'error', reason: 'empty' })
  })

  it('大模型复述草稿时，前缀被干净剥离，绝不传出重复文本', async () => {
    let jsonHandler: any = null
    const webServer = {
      register: (options: any) => {
        if (options.path === CODEX_UI_API_ENDPOINTS.composerPrediction) {
          jsonHandler = options.handler
        }
        return () => {}
      },
    }

    const mockLlm = {
      prepareCall: vi.fn(async (config) => ({
        config,
        stream: async function* () {
          // 模拟大模型复述了草稿“请帮我检查”
          yield { type: 'text-delta', text: '请帮我检查 dsh-pua 目录下的代码是否有问题' }
          yield { type: 'finish', reason: { kind: 'stop' } }
        },
      })),
    }

    const mockSession = {
      seq: 2,
      deriveMessages: () => [
        { role: 'user', content: [{ type: 'text', text: '你好' }] },
        { role: 'assistant', content: [{ type: 'text', text: '你好！有什么需要帮你的？' }] },
      ],
      requestHeader: () => ({ config: { provider: 'test', model: 'test' } }),
    }

    const mockCtx = {
      webServer,
      connection: { admit: vi.fn(() => ({ peer: { principal: { kind: 'owner' } } })) },
      llm: mockLlm,
      sessions: { get: vi.fn(() => mockSession) },
      effect: (fn: any) => fn(),
    } as any

    applyPredictions(mockCtx)

    let writtenBody = ''
    const response = {
      writeHead: vi.fn(),
      end: vi.fn((body) => { writtenBody = body }),
      on: vi.fn(),
    }

    await jsonHandler(
      {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        [Symbol.asyncIterator]: async function* () {
          yield Buffer.from(JSON.stringify({ sessionId: 'sess_1', mode: 'continue', draft: '请帮我检查' }))
        },
      },
      response,
    )

    const parsed = JSON.parse(writtenBody)
    // 候选文本必须已经被切掉前缀“请帮我检查”，只剩下增量续写！
    expect(parsed.candidates).toBeDefined()
    expect(parsed.candidates[0]).not.toMatch(/^请帮我检查/)
    expect(parsed.candidates[0].trim()).toBe('dsh-pua 目录下的代码是否有问题')
  })
})
