import type { GlassMode, GlassPreset } from './glass.ts'

export type ThemeOption =
  | 'stock'
  | 'codex-dark'
  | 'codex-light'
  | 'claude-dark'
  | 'claude-light'
  | 'dracula'
  | 'solarized-dark'
  | 'solarized-light'
  | 'gruvbox-dark'
  | 'gruvbox-light'
  | 'catppuccin-mocha'
  | 'catppuccin-macchiato'
  | 'catppuccin-frappe'
  | 'catppuccin-latte'
  | 'cyberpunk'

export interface ThemeSettingsState {
  readonly themeOption: ThemeOption
  readonly glassEnabled: boolean
  readonly glassMode: GlassMode
  readonly glassPreset: GlassPreset
  readonly glassGlow: boolean
  readonly subPluginEnabled: boolean
}

export const STORAGE_KEYS = Object.freeze({
  themeOption: 'codex-ui.theme.option',
  glassEnabled: 'codex-ui.glass.enabled',
  glassMode: 'codex-ui.glass.mode',
  glassPreset: 'codex-ui.glass.preset',
  glassGlow: 'codex-ui.glass.glow',
})

const listeners = new Set<() => void>()

const VALID_THEMES: readonly ThemeOption[] = [
  'stock',
  'codex-dark',
  'codex-light',
  'claude-dark',
  'claude-light',
  'dracula',
  'solarized-dark',
  'solarized-light',
  'gruvbox-dark',
  'gruvbox-light',
  'catppuccin-mocha',
  'catppuccin-macchiato',
  'catppuccin-frappe',
  'catppuccin-latte',
  'cyberpunk',
]

function safeGetItem(key: string): string | null {
  try {
    if (typeof localStorage !== 'undefined') {
      return localStorage.getItem(key)
    }
  } catch {
    // 降级容错
  }
  return null
}

function safeSetItem(key: string, value: string): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(key, value)
    }
  } catch {
    // 降级容错
  }
}

function computeSnapshot(): ThemeSettingsState {
  const rawTheme = safeGetItem(STORAGE_KEYS.themeOption)
  const themeOption: ThemeOption =
    rawTheme && (VALID_THEMES as readonly string[]).includes(rawTheme)
      ? (rawTheme as ThemeOption)
      : 'stock'

  const rawGlass = safeGetItem(STORAGE_KEYS.glassEnabled)
  const glassEnabled = rawGlass !== 'false'

  const rawMode = safeGetItem(STORAGE_KEYS.glassMode)
  const glassMode: GlassMode = rawMode === 'compat' ? 'compat' : 'mica'

  const rawPreset = safeGetItem(STORAGE_KEYS.glassPreset)
  const glassPreset: GlassPreset =
    rawPreset === 'clear' || rawPreset === 'frosted' ? rawPreset : 'standard'

  const rawGlow = safeGetItem(STORAGE_KEYS.glassGlow)
  const glassGlow = rawGlow === 'true'

  return Object.freeze({
    themeOption,
    glassEnabled,
    glassMode,
    glassPreset,
    glassGlow,
    subPluginEnabled: currentSubPluginEnabled,
  })
}

let currentSubPluginEnabled = true

/** 检查当前主题子插件是否在 Host 侧处于激活启用状态 */
export function isThemeSubPluginEnabled(): boolean {
  return currentSubPluginEnabled
}

/** 供状态机与测试更新主题子插件启用标记，并广播触发响应式重渲染 */
export function setThemeSubPluginEnabled(enabled: boolean): void {
  if (currentSubPluginEnabled !== enabled) {
    currentSubPluginEnabled = enabled
    notify()
  }
}

let currentSnapshot: ThemeSettingsState = computeSnapshot()

/** 强制重算并刷新主题与云母外观配置快照（测试用例或外部直接写入 localStorage 时使用） */
export function refreshThemeSettingsSnapshot(): ThemeSettingsState {
  currentSnapshot = computeSnapshot()
  return currentSnapshot
}

/** 获取当前主题与云母外观配置快照（通过事件驱动同步，避免高频无谓读盘） */
export function getThemeSettingsState(): ThemeSettingsState {
  return currentSnapshot
}

function notify(): void {
  currentSnapshot = computeSnapshot()
  for (const listener of listeners) {
    try {
      listener()
    } catch (e) {
      console.warn('[codex-ui:theme] listener error:', e)
    }
  }
}

export function setThemeOption(themeOption: ThemeOption): void {
  safeSetItem(STORAGE_KEYS.themeOption, themeOption)
  notify()
}

export function setGlassEnabled(enabled: boolean): void {
  safeSetItem(STORAGE_KEYS.glassEnabled, String(enabled))
  notify()
}

export function setGlassMode(mode: GlassMode): void {
  safeSetItem(STORAGE_KEYS.glassMode, mode)
  notify()
}

export function setGlassPreset(preset: GlassPreset): void {
  safeSetItem(STORAGE_KEYS.glassPreset, preset)
  notify()
}

export function setGlassGlow(glow: boolean): void {
  safeSetItem(STORAGE_KEYS.glassGlow, String(glow))
  notify()
}

export function subscribeThemeSettings(listener: () => void): () => void {
  listeners.add(listener)
  return () => {
    listeners.delete(listener)
  }
}

// 绑定全局 storage 事件（跨 tab 自动同步）
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (event) => {
    if (
      event.key === STORAGE_KEYS.themeOption ||
      event.key === STORAGE_KEYS.glassEnabled ||
      event.key === STORAGE_KEYS.glassMode ||
      event.key === STORAGE_KEYS.glassPreset ||
      event.key === STORAGE_KEYS.glassGlow
    ) {
      notify()
    }
  })
}
