import type { Context } from '@deepseek-ai/cordis'
import React from 'react'
import { render, unmountComponentAtNode } from 'react-dom'
import { classifySettingsButton, SETTINGS_NAV_GROUPS } from './model.ts'
import { getNavSearchQuery, setNavSearchQuery, subscribeNavSearch, setSkinEnabledState, SettingsNavHeader } from './SettingsNavHeader.tsx'
import { en, zh, NS } from '../locales.ts'

export const SETTINGS_SKIN_STYLE_ID = 'dcu-official-settings-skin'

export const SETTINGS_SKIN_CSS = `
/* 全屏工作台 Presentation 遮罩层铺满
   选择器必须精确落到“装着设置面板的那一层遮罩”：宿主所有 Modal（含确认框、插件弹窗）的
   root 都是 body 直属的 role="presentation"，用 body:has(...) > [role="presentation"]
   会把同时打开的其它模态窗一起改成 stretch 靠左上角。 */
body > [role="presentation"]:has(> [data-shortcut-modal="settings"]) {
  position: fixed !important;
  inset: 0 !important;
  z-index: 1000 !important;
  display: flex !important;
  align-items: stretch !important;
  justify-content: stretch !important;
  padding: 0 !important;
  background-color: transparent !important;
}

/* 模态框外壳：全屏 100vw x 100vh 工作台形态 */
[data-shortcut-modal="settings"] {
  box-sizing: border-box !important;
  position: fixed !important;
  inset: 0 !important;
  width: 100vw !important;
  height: 100vh !important;
  max-width: none !important;
  max-height: none !important;
  border-radius: 0 !important;
  border: none !important;
  background: var(--dsw-alias-bg-layer-2, #18181b) !important;
  box-shadow: none !important;
  overflow: hidden !important;
  display: flex !important;
  flex-direction: row !important;
}

/* 桌面平台窗口标题栏避让：在具有 Windows/macOS 顶栏的环境下平滑下移，绝不遮盖或截断内容与操作区 */
html[data-platform="darwin"] body > [role="presentation"]:not(#root) {
  -webkit-app-region: initial;
}

/* 桌面平台窗口标题栏避让：单点锁定在 [data-shortcut-modal="settings"]，绝无重复，也绝不冲顶 */
html[data-windows-titlebar]:not([data-fullscreen]) [data-shortcut-modal="settings"] {
  top: var(--dsh-windows-titlebar-height, var(--dsh-frame-chrome-top, 40px)) !important;
  height: calc(100vh - var(--dsh-windows-titlebar-height, var(--dsh-frame-chrome-top, 40px))) !important;
}

html[data-platform="darwin"]:not([data-fullscreen]) [data-shortcut-modal="settings"] {
  top: var(--dsh-frame-top-clearance, 38px) !important;
  height: calc(100vh - var(--dsh-frame-top-clearance, 38px)) !important;
}

/* 左侧整列侧栏：与首页侧栏严格等宽，底色统合对齐 --dsw-alias-bg-layer-2，杜绝与右侧工作区产生色差断层 */
[data-shortcut-modal="settings"] > nav {
  box-sizing: border-box !important;
  width: var(--dcu-settings-nav-width, 280px) !important;
  min-width: var(--dcu-settings-nav-width, 280px) !important;
  max-width: var(--dcu-settings-nav-width, 280px) !important;
  flex-shrink: 0 !important;
  gap: 0 !important;
  padding: 16px 12px 24px !important;
  border-right: 1px solid var(--dsw-alias-border-l1, rgba(255, 255, 255, 0.08)) !important;
  background: var(--dsw-alias-bg-layer-2, #18181b) !important;
  overflow: hidden !important;
  display: flex !important;
  flex-direction: column !important;
}

/* 设置工作台必须使用实色不透明底板，左右两栏整体浑然一体 */
[data-shortcut-modal="settings"] {
  background: var(--dsw-alias-bg-layer-2, #18181b) !important;
}

[data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) {
  background: var(--dsw-alias-bg-layer-2, #18181b) !important;
}

/* 浅色模式全局兜底：浅底高对比度规范，绝不允许残留或回退暗黑色 */
body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"],
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"] {
  background: var(--dsw-alias-bg-base, var(--dsw-static-neutral-bluish-00, #ffffff)) !important;
}

body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav),
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) {
  background: var(--dsw-alias-bg-layer-1, var(--dsw-static-neutral-bluish-00, #ffffff)) !important;
}

/* 玻璃质感/原版兼容排版模式（Compat） */
html[data-dsh-glass]:not([data-dsh-glass-float]) [data-shortcut-modal="settings"] {
  background: var(--dsw-alias-bg-base, #151517) !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
}

html[data-dsh-glass]:not([data-dsh-glass-float]) [data-shortcut-modal="settings"] > nav,
html[data-dsh-glass]:not([data-dsh-glass-float]) [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="navTitle"] {
  background: color-mix(
    in srgb,
    var(--dsw-specific-sidebar-fill, #181825) 85%,
    var(--dsw-alias-bg-base, #09090b)
  ) !important;
  backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
  -webkit-backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
  border-right: 1px solid var(--dsw-alias-border-l1, rgba(255, 255, 255, 0.08)) !important;
  box-shadow: inset -1px 0 0 rgba(255, 255, 255, 0.05) !important;
}

html[data-dsh-glass]:not([data-dsh-glass-float]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) {
  background: var(--dsw-alias-bg-base, #151517) !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
}

/* 云母悬浮模式（Mica Mode）：设置面板全面升华为与首页一致的悬浮双岛体系 */
html[data-dsh-glass-float] body > [role="presentation"]:has(> [data-shortcut-modal="settings"]) {
  background-color: transparent !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
}

/* 卡片背后的全局画布：完全对齐首页的漫反射温润云母底板（Glow 1 + Glow 2 + Wash 深度渐变） */
html[data-dsh-glass-float] [data-shortcut-modal="settings"] {
  background:
    radial-gradient(58% 46% at 18% 6%,
      color-mix(in srgb, var(--dsw-alias-brand-primary-new-colorprimary-new-color, #0169cc)
        calc(12% * var(--dsh-glass-ambience, 1) * var(--dsh-glass-glow, 0)), transparent), transparent 68%),
    radial-gradient(48% 42% at 86% 14%,
      color-mix(in srgb, var(--dsw-alias-brand-primary, #339cff)
        calc(10% * var(--dsh-glass-ambience, 1) * var(--dsh-glass-glow, 0)), transparent), transparent 62%),
    linear-gradient(165deg,
      color-mix(in srgb, var(--dsh-glass-ground, var(--dsw-alias-bg-base)), var(--dsh-glass-wash-tint, #ffffff)
        calc(var(--dsh-glass-wash-mix, 22%) * var(--dsh-glass-ambience, 1))) 0%,
      var(--dsh-glass-ground, var(--dsw-alias-bg-base)) 55%,
      color-mix(in srgb, var(--dsh-glass-ground, var(--dsw-alias-bg-base)), #000000 calc(5% * var(--dsh-glass-ambience, 1))) 100%) !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
}

/* 左侧导航悬浮岛：与首页侧边栏严格对齐几何形态、12px外边距、16px圆角与微高光 */
html[data-dsh-glass-float] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > nav {
  box-sizing: border-box !important;
  width: calc(var(--dcu-settings-nav-width, 280px) - 24px) !important;
  min-width: calc(var(--dcu-settings-nav-width, 280px) - 24px) !important;
  max-width: calc(var(--dcu-settings-nav-width, 280px) - 24px) !important;
  margin: 8px 12px 12px 12px !important;
  height: calc(100% - 20px) !important;
  max-height: calc(100% - 20px) !important;
  border-radius: 16px !important;
  border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)), inset 0 1px 0 rgba(255, 255, 255, 0.6) !important;
  background: var(--dsw-alias-bg-layer-2, var(--dsh-glass-card, #18181b)) !important;
  backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
  -webkit-backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
  overflow: hidden !important;
}

/* 右侧工作台悬浮岛：独立大圆角卡片，浅色为纯净微光白，深色为深邃灰，与首页悬浮实体完全一致 */
html[data-dsh-glass-float] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) {
  margin: 8px 12px 12px 0 !important;
  height: calc(100% - 20px) !important;
  max-height: calc(100% - 20px) !important;
  border-radius: 16px !important;
  border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)), inset 0 1px 0 rgba(255, 255, 255, 0.6) !important;
  background: var(--dsw-alias-bg-layer-2, var(--dsw-alias-bg-layer-1, #18181b)) !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
  overflow: hidden !important;
}

/* 云母模式下收敛顶部工具栏与内容区 padding，消除脱节大空隙 */
html[data-dsh-glass-float] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child {
  height: 48px !important;
  min-height: 48px !important;
  padding: 0 24px !important;
  background: var(--dsw-alias-bg-layer-2, var(--dsw-alias-bg-layer-1, #18181b)) !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :nth-child(2) {
  padding: 16px 32px 48px !important;
  background: var(--dsw-alias-bg-layer-2, var(--dsw-alias-bg-layer-1, #18181b)) !important;
}

html[data-platform="darwin"] [data-shortcut-modal="settings"] > nav {
  background: var(--dsw-specific-sidebar-fill, transparent) !important;
}

/* 顶部标题与搜索区插槽容器 */
[data-shortcut-modal="settings"] > nav > :first-child {
  padding: 0 !important;
  display: flex !important;
  flex-direction: column !important;
  gap: 14px !important;
  flex: none !important;
}

/* 彻底隐藏宿主原生的 settings.header 插槽内容，杜绝原生“设置”文本复活并被挤到右边竖排折行 */
[data-shortcut-modal="settings"] [data-slot="settings.header"],
[data-shortcut-modal="settings"] [class*="navTitle"] > :not(.dcu-settings-nav-header-root) {
  display: none !important;
}

.dcu-settings-nav-header-root {
  display: flex !important;
  flex-direction: column !important;
  gap: 14px !important;
  width: 100% !important;
}

/* 顶部标题与返回栏：拉平左对齐基线，垂直水平对齐 */
.dcu-settings-nav-header-top {
  display: flex !important;
  align-items: center !important;
  gap: 10px !important;
  height: 28px !important;
  padding: 0 !important;
  width: 100% !important;
}

.dcu-settings-back-btn,
button.dcu-settings-back-btn,
[data-shortcut-modal="settings"] > nav button.dcu-settings-back-btn {
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  width: 28px !important;
  min-width: 28px !important;
  max-width: 28px !important;
  height: 28px !important;
  min-height: 28px !important;
  max-height: 28px !important;
  flex: none !important;
  border-radius: var(--dsw-radius-sm, 6px) !important;
  background: transparent !important;
  border: none !important;
  color: var(--dsw-alias-label-secondary, #a1a1aa) !important;
  cursor: pointer !important;
  padding: 0 !important;
  transition: color 0.12s ease, background 0.12s ease !important;
}

.dcu-settings-back-btn:hover,
button.dcu-settings-back-btn:hover,
[data-shortcut-modal="settings"] > nav button.dcu-settings-back-btn:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(255, 255, 255, 0.06)) !important;
  color: var(--dsw-alias-label-primary, #ffffff) !important;
}

.dcu-settings-nav-header-title {
  font-size: 16px !important;
  font-weight: 600 !important;
  line-height: 28px !important;
  color: var(--dsw-alias-label-primary, #ffffff) !important;
  letter-spacing: -0.01em !important;
  user-select: none !important;
  white-space: nowrap !important;
  flex: 1 1 auto !important;
}

/* 搜索框容器与宿主原生 Input 规范对齐 */
.dcu-settings-search-wrapper {
  position: relative !important;
  display: flex !important;
  align-items: center !important;
  width: 100% !important;
}

.dcu-settings-search-icon {
  width: 14px !important;
  height: 14px !important;
  color: var(--dsw-alias-label-tertiary, #8e8e8e) !important;
  pointer-events: none !important;
}

/* 宿主原生 Input 组件全宽容器与 Token 规范 */
.dcu-settings-search-input {
  box-sizing: border-box !important;
  display: inline-flex !important;
  width: 100% !important;
  height: 32px !important;
  border-radius: var(--dsw-radius-md, 8px) !important;
  background: var(--dsw-alias-bg-layer-2, rgba(255, 255, 255, 0.05)) !important;
  border: 0.5px solid var(--dsw-alias-border-l4, rgba(255, 255, 255, 0.08)) !important;
  transition: border-color 0.12s ease, background-color 0.12s ease !important;
}

.dcu-settings-search-input:focus-within {
  border-color: var(--dsw-alias-state-business-primary, var(--dsw-static-deepseek-500, #4176e6)) !important;
  background: var(--dsw-alias-bg-layer-2, rgba(255, 255, 255, 0.08)) !important;
}

.dcu-settings-search-input input {
  font-size: 13px !important;
  line-height: 20px !important;
  color: var(--dsw-alias-label-primary, #ffffff) !important;
}

.dcu-settings-search-input input::placeholder {
  color: var(--dsw-alias-label-tertiary, #8e8e8e) !important;
  font-size: 13px !important;
}

/* 导航项列表容器 */
[data-shortcut-modal="settings"] > nav [class*="navList"],
[data-shortcut-modal="settings"] > nav > :nth-child(2) {
  display: flex !important;
  flex-direction: column !important;
  gap: 2px !important;
  flex: 1 1 auto !important;
  min-height: 0 !important;
  overflow-y: auto !important;
  padding: 4px 0 32px !important;
}

/* 分组小标题：字号12px、中灰、标准大小写、呼吸留白 */
.dcu-settings-nav-group-header {
  box-sizing: border-box !important;
  font-size: 12px !important;
  font-weight: 500 !important;
  color: var(--dsw-alias-label-tertiary, #8e8e8e) !important;
  letter-spacing: normal !important;
  text-transform: none !important;
  padding: 16px 10px 6px !important;
  user-select: none !important;
}

.dcu-settings-nav-group-header:first-of-type {
  padding-top: 6px !important;
}

/* 空搜索提示 */
.dcu-settings-nav-empty {
  padding: 24px 10px;
  font-size: 13px;
  color: var(--dsw-alias-label-tertiary, #71717a);
  text-align: center;
  user-select: none;
}

/* 导航项按钮：Codex 原生胶囊形态（Capsule） */
[data-shortcut-modal="settings"] > nav button,
[data-shortcut-modal="settings"] > nav > :nth-child(2) > button {
  box-sizing: border-box !important;
  display: flex !important;
  align-items: center !important;
  gap: 10px !important;
  height: 32px !important;
  min-height: 32px !important;
  padding-inline: 10px !important;
  border-radius: var(--dsw-radius-sm, 6px) !important;
  font-size: 13px !important;
  font-weight: 400 !important;
  color: var(--dsw-alias-label-secondary, #d4d4d8) !important;
  background: transparent !important;
  border: none !important;
  cursor: pointer !important;
  transition: background 0.12s ease, color 0.12s ease !important;
  text-align: left !important;
  width: 100% !important;
}

[data-shortcut-modal="settings"] > nav button svg,
[data-shortcut-modal="settings"] > nav > :nth-child(2) > button svg {
  width: 16px !important;
  height: 16px !important;
  flex-shrink: 0 !important;
  color: var(--dsw-alias-label-secondary, #a1a1aa) !important;
  stroke-width: 1.5 !important;
  transition: color 0.12s ease !important;
}

[data-shortcut-modal="settings"] > nav button:hover,
[data-shortcut-modal="settings"] > nav > :nth-child(2) > button:hover {
  background: var(--dsw-specific-sidebar-nav-item-hover, var(--dsw-alias-interactive-bg-hover, rgba(255, 255, 255, 0.05))) !important;
  color: var(--dsw-alias-label-primary, #ffffff) !important;
}

[data-shortcut-modal="settings"] > nav button:hover svg,
[data-shortcut-modal="settings"] > nav > :nth-child(2) > button:hover svg {
  color: var(--dsw-alias-label-primary, #ffffff) !important;
}

/* 选中菜单项：纯正 Codex 胶囊激活态（Capsule Pill） */
[data-shortcut-modal="settings"] > nav button[aria-current="true"],
[data-shortcut-modal="settings"] > nav button[class*="active"],
[data-shortcut-modal="settings"] > nav [class*="navCell"][class*="active"],
[data-shortcut-modal="settings"] > nav > :nth-child(2) > button[aria-current="true"],
[data-shortcut-modal="settings"] > nav > :nth-child(2) > button[class*="active"] {
  background: var(--dsw-specific-sidebar-nav-item-active, var(--dsw-alias-interactive-bg-selected, rgba(255, 255, 255, 0.10))) !important;
  color: var(--dsw-alias-label-primary, #ffffff) !important;
  font-weight: 500 !important;
}

[data-shortcut-modal="settings"] > nav button[aria-current="true"] svg,
[data-shortcut-modal="settings"] > nav button[class*="active"] svg,
[data-shortcut-modal="settings"] > nav [class*="navCell"][class*="active"] svg,
[data-shortcut-modal="settings"] > nav > :nth-child(2) > button[aria-current="true"] svg,
[data-shortcut-modal="settings"] > nav > :nth-child(2) > button[class*="active"] svg {
  color: var(--dsw-alias-label-primary, #ffffff) !important;
}

[data-shortcut-modal="settings"] > nav button:focus-visible,
[data-shortcut-modal="settings"] > nav > :nth-child(2) > button:focus-visible {
  outline: 2px solid var(--dsw-alias-state-focus-ring, var(--dsw-static-deepseek-500, #4176e6)) !important;
  outline-offset: 1px !important;
}

/* 右侧内容工作区 */
[data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) {
  display: flex !important;
  min-width: 0 !important;
  flex: 1 1 auto !important;
  flex-direction: column !important;
  background: var(--dsw-alias-bg-layer-2, #18181b) !important;
  height: 100% !important;
}

[data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child {
  box-sizing: border-box !important;
  height: 56px !important;
  min-height: 56px !important;
  padding: 0 32px !important;
  border-bottom: 1px solid var(--dsw-alias-border-l1, rgba(255, 255, 255, 0.07)) !important;
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  background: var(--dsw-alias-bg-layer-2, #18181b) !important;
}

[data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child h2,
[data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child span {
  font-size: 16px;
  font-weight: 600;
  color: var(--dsw-alias-label-primary, #f4f4f5) !important;
  letter-spacing: -0.01em;
}

[data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child button,
[data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child a {
  color: var(--dsw-alias-label-secondary, #a1a1aa) !important;
  transition: color 0.15s ease;
}

[data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child button:hover,
[data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child a:hover {
  color: var(--dsw-alias-label-primary, #f4f4f5) !important;
}

[data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :nth-child(2) {
  box-sizing: border-box !important;
  min-height: 0 !important;
  flex: 1 1 auto !important;
  overflow-y: auto !important;
  padding: 24px 32px 48px !important;
  background: var(--dsw-alias-bg-layer-2, #18181b) !important;
  display: flex !important;
  flex-direction: column !important;
  align-items: stretch !important;
}

/* 浅色模式右侧内容区实色与文字按钮高对比度兜底 */
body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child,
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child {
  background: var(--dsw-alias-bg-layer-1, #ffffff) !important;
  border-bottom: 1px solid var(--dsw-alias-border-l1, rgba(0, 0, 0, 0.08)) !important;
}

body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child h2,
body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child span,
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child h2,
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child span {
  color: var(--dsw-alias-label-primary, #18181b) !important;
}

body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child button,
body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child a,
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child button,
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child a {
  color: var(--dsw-alias-label-secondary, #52525b) !important;
}

body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child button:hover,
body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child a:hover,
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child button:hover,
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child a:hover {
  color: var(--dsw-alias-label-primary, #18181b) !important;
}

body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :nth-child(2),
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :nth-child(2) {
  background: var(--dsw-alias-bg-layer-1, #ffffff) !important;
}

/* 右侧设置区固定宽度规范：卡片先吃满列宽、再被 800px 夹住，左右留白相等（不会出现单侧空洞）。
   实测（scripts/verify-settings-geometry.mjs，1400px 面板）：卡片宽 800px、左右各 260px —
   即「居中收束」而不是贴左；若要改成贴左，需同时去掉下面的 margin-inline: auto。 */
[data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :nth-child(2) > * {
  width: 100% !important;
  max-width: 800px !important;
  margin-inline: auto !important;
  box-sizing: border-box !important;
}

[data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :nth-child(2) > * > * {
  width: 100% !important;
  max-width: 800px !important;
  margin-inline: auto !important;
  box-sizing: border-box !important;
}

[data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :nth-child(2) [class*="section"] {
  width: 100% !important;
  max-width: 800px !important;
  margin-inline: auto !important;
}

/* 新版宿主平铺 4 块 Grid 布局映射（0.2.1-alpha.3+），杜绝 4 列横向撕裂与多余空条 */
[data-shortcut-modal="settings"]:has(> [class*="options"]) {
  display: grid !important;
  grid-template-columns: var(--dcu-settings-nav-width, 280px) minmax(0, 1fr) !important;
  grid-template-rows: auto minmax(0, 1fr) !important;
  flex-direction: unset !important;
  position: fixed !important;
}

[data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="navTitle"] {
  grid-column: 1 !important;
  grid-row: 1 !important;
  box-sizing: border-box !important;
  width: var(--dcu-settings-nav-width, 280px) !important;
  min-width: var(--dcu-settings-nav-width, 280px) !important;
  max-width: var(--dcu-settings-nav-width, 280px) !important;
  background: var(--dsw-alias-bg-layer-2, #18181b) !important;
  border-right: 1px solid var(--dsw-alias-border-l1, rgba(255, 255, 255, 0.08)) !important;
  border-bottom: none !important;
  padding: 16px 12px 8px 12px !important;
  margin: 0 !important;
  height: auto !important;
  flex: none !important;
}

[data-shortcut-modal="settings"]:has(> [class*="options"]) > nav {
  grid-column: 1 !important;
  grid-row: 2 !important;
  box-sizing: border-box !important;
  width: var(--dcu-settings-nav-width, 280px) !important;
  min-width: var(--dcu-settings-nav-width, 280px) !important;
  max-width: var(--dcu-settings-nav-width, 280px) !important;
  background: var(--dsw-alias-bg-layer-2, #18181b) !important;
  border-right: 1px solid var(--dsw-alias-border-l1, rgba(255, 255, 255, 0.08)) !important;
  border-top: none !important;
  padding: 0 12px 24px 12px !important;
  margin: 0 !important;
  overflow-y: auto !important;
  height: 100% !important;
  flex: none !important;
}

/* 顶部操作区（打开配置文件 + 关闭按钮）：普通模式下透明浮动，无实体白条与下边框，绝不硬切出第二层顶部 */
[data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="header"] {
  grid-column: 2 !important;
  grid-row: 1 / -1 !important;
  position: absolute !important;
  top: 0 !important;
  left: 0 !important;
  right: 0 !important;
  height: 56px !important;
  min-height: 56px !important;
  box-sizing: border-box !important;
  padding: 0 32px !important;
  border: none !important;
  border-bottom: none !important;
  display: flex !important;
  align-items: center !important;
  justify-content: flex-end !important;
  gap: 12px !important;
  background: transparent !important;
  z-index: 10 !important;
  margin: 0 !important;
  pointer-events: none !important;
}

[data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="header"] > * {
  pointer-events: auto !important;
}

/* 右侧内容工作区：独占右侧整列（Row 1 至 Row 2 全高一体），首屏内容自 56px 顶栏下方舒展排列 */
[data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"] {
  grid-column: 2 !important;
  grid-row: 1 / -1 !important;
  box-sizing: border-box !important;
  min-height: 0 !important;
  overflow-y: auto !important;
  padding-top: calc(56px + 20px) !important;
  padding-bottom: 48px !important;
  padding-inline: 32px !important;
  background: var(--dsw-alias-bg-layer-2, #18181b) !important;
  display: flex !important;
  flex-direction: column !important;
  align-items: stretch !important;
  margin: 0 !important;
  height: 100% !important;
  flex: none !important;
}

[data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"] > *,
[data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"] > * > *,
[data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"] [class*="section"],
[data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"] [class*="card"] {
  box-sizing: border-box !important;
}

[data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"] > :not([style*="display: contents"]):not([data-slot]),
[data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"] > * > *,
[data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"] [class*="section"] {
  width: 100% !important;
  max-width: 800px !important;
  margin-inline: auto !important;
}

/* 浅色模式新版 Grid 兜底 */
body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="navTitle"],
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="navTitle"] {
  background: var(--dsw-specific-sidebar-fill, var(--dsw-alias-bg-layer-1, #ffffff)) !important;
  border-right: 1px solid var(--dsw-alias-border-l1, rgba(0, 0, 0, 0.08)) !important;
}

body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:has(> [class*="options"]) > nav,
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:has(> [class*="options"]) > nav {
  background: var(--dsw-specific-sidebar-fill, var(--dsw-alias-bg-layer-1, #ffffff)) !important;
  border-right: 1px solid var(--dsw-alias-border-l1, rgba(0, 0, 0, 0.08)) !important;
}

body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="header"],
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="header"] {
  background: transparent !important;
  border: none !important;
  border-bottom: none !important;
}

body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"],
html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"] {
  background: var(--dsw-alias-bg-layer-1, #ffffff) !important;
}

/* 云母悬浮双岛（Mica Mode）新版 Grid 适配：右侧整列为标准 56px 顶栏 + 16px 圆角大卡片 */
html[data-dsh-glass-float] [data-shortcut-modal="settings"]:has(> [class*="options"]) {
  grid-template-columns: calc(var(--dcu-settings-nav-width, 280px) - 24px) minmax(0, 1fr) !important;
  gap: 0 12px !important;
  padding: 8px 12px 12px 12px !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="navTitle"] {
  width: 100% !important;
  min-width: 0 !important;
  max-width: none !important;
  margin: 0 !important;
  padding: 16px 12px 8px 12px !important;
  border-right: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  border-left: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  border-top: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  border-bottom: none !important;
  border-radius: 16px 16px 0 0 !important;
  background: var(--dsw-alias-bg-layer-2, #18181b) !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
  box-shadow: none !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"]:has(> [class*="options"]) > nav {
  width: 100% !important;
  min-width: 0 !important;
  max-width: none !important;
  margin: 0 !important;
  padding: 0 12px 24px 12px !important;
  border-right: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  border-left: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  border-bottom: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  border-top: none !important;
  border-radius: 0 0 16px 16px !important;
  background: var(--dsw-alias-bg-layer-2, #18181b) !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
  box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)) !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="header"] {
  grid-column: 2 !important;
  grid-row: 1 / -1 !important;
  position: absolute !important;
  top: 0 !important;
  left: 0 !important;
  right: 12px !important;
  margin: 0 !important;
  height: 56px !important;
  min-height: 56px !important;
  box-sizing: border-box !important;
  padding: 0 32px !important;
  border: none !important;
  border-radius: 0 !important;
  background: transparent !important;
  display: flex !important;
  align-items: center !important;
  justify-content: flex-end !important;
  gap: 12px !important;
  z-index: 10 !important;
  pointer-events: none !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="header"] > * {
  pointer-events: auto !important;
}

html[data-dsh-glass-float] body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="header"],
html[data-dsh-glass-float] html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="header"] {
  background: transparent !important;
  border: none !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"] {
  margin: 0 !important;
  border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  border-radius: 16px !important;
  background: var(--dsw-alias-bg-layer-2, var(--dsw-alias-bg-layer-1, #18181b)) !important;
  box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)), inset 0 1px 0 rgba(255, 255, 255, 0.6) !important;
  padding-top: calc(56px + 20px) !important;
  padding-bottom: 48px !important;
  padding-inline: 32px !important;
}

/* 无论窗口 <=768px 还是处于收起态 [data-sidebar-collapsed]，结构尺寸均收敛为 56px 导轨 */
[data-shortcut-modal="settings"][data-sidebar-collapsed],
html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed],
html[data-dsh-glass] [data-shortcut-modal="settings"][data-sidebar-collapsed] {
  --dcu-settings-nav-width: 56px !important;
}

[data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) {
  grid-template-columns: 56px minmax(0, 1fr) !important;
}

/* --- 普通纯色原生模式（未开启云母）下的收起态：与普通展开态完全一致，平铺紧贴，0 外边距、0 圆角、0 磨砂、0 阴影 --- */
html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) {
  gap: 0 !important;
  padding: 0 !important;
  background: var(--dsw-alias-bg-base, #151517) !important;
}

html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="navTitle"] {
  grid-column: 1 !important;
  grid-row: 1 !important;
  box-sizing: border-box !important;
  width: 56px !important;
  min-width: 56px !important;
  max-width: 56px !important;
  padding: 14px 0 10px 0 !important;
  margin: 0 !important;
  align-items: center !important;
  justify-content: center !important;
  border-radius: 0 !important;
  border: none !important;
  border-right: 1px solid var(--dsw-alias-border-l1, rgba(255, 255, 255, 0.08)) !important;
  border-bottom: none !important;
  background: var(--dsw-specific-sidebar-fill, var(--dsw-alias-bg-layer-1, #18181b)) !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
  box-shadow: none !important;
  flex: none !important;
}

html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"][data-sidebar-collapsed] > nav {
  box-sizing: border-box !important;
  width: 56px !important;
  min-width: 56px !important;
  max-width: 56px !important;
  margin: 0 !important;
  padding: 12px 0 16px !important;
  border-radius: 0 !important;
  border: none !important;
  border-right: 1px solid var(--dsw-alias-border-l1, rgba(255, 255, 255, 0.08)) !important;
  background: var(--dsw-specific-sidebar-fill, var(--dsw-alias-bg-layer-1, #18181b)) !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
  box-shadow: none !important;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  scrollbar-width: none !important;
  -ms-overflow-style: none !important;
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  gap: 0 !important;
}

html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"][data-sidebar-collapsed]:not(:has(> [class*="options"])) > div:not(nav) {
  margin: 0 !important;
  border-radius: 0 !important;
  border: none !important;
  box-shadow: none !important;
  background: var(--dsw-alias-bg-base, #151517) !important;
  height: 100% !important;
  max-height: 100% !important;
  overflow: hidden !important;
  display: flex !important;
  flex-direction: column !important;
}

html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"][data-sidebar-collapsed]:not(:has(> [class*="options"])) > div:not(nav) > :first-child {
  background: transparent !important;
  border: none !important;
  border-bottom: none !important;
  flex: none !important;
}

html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"][data-sidebar-collapsed]:not(:has(> [class*="options"])) > div:not(nav) > :nth-child(2) {
  margin: 0 !important;
  border-radius: 0 !important;
  border: none !important;
  box-shadow: none !important;
  background: transparent !important;
  overflow-y: auto !important;
  flex: 1 1 auto !important;
  min-height: 0 !important;
  padding-top: 28px !important;
  padding-bottom: 64px !important;
  padding-inline: 48px !important;
  box-sizing: border-box !important;
}

html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="options"] {
  margin: 0 !important;
  border-radius: 0 !important;
  border: none !important;
  box-shadow: none !important;
  background: var(--dsw-alias-bg-base, #151517) !important;
  overflow-y: auto !important;
  height: 100% !important;
  max-height: 100% !important;
  padding-top: calc(56px + 28px) !important;
  padding-bottom: 64px !important;
  padding-inline: 48px !important;
  box-sizing: border-box !important;
}

/* 浅色普通模式下的收起态高对比度平铺底板 */
html:not([data-dsh-glass-float]) body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"][data-sidebar-collapsed] > nav,
html:not([data-dsh-glass-float]) html[data-ds-theme-source="light"] [data-shortcut-modal="settings"][data-sidebar-collapsed] > nav,
html:not([data-dsh-glass-float]) body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="navTitle"],
html:not([data-dsh-glass-float]) html[data-ds-theme-source="light"] [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="navTitle"] {
  background: var(--dsw-specific-sidebar-fill, var(--dsw-alias-bg-layer-1, #f3f3f4)) !important;
  border-right: 1px solid var(--dsw-alias-border-l1, rgba(0, 0, 0, 0.08)) !important;
}

html:not([data-dsh-glass-float]) body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"][data-sidebar-collapsed]:not(:has(> [class*="options"])) > div:not(nav),
html:not([data-dsh-glass-float]) html[data-ds-theme-source="light"] [data-shortcut-modal="settings"][data-sidebar-collapsed]:not(:has(> [class*="options"])) > div:not(nav),
html:not([data-dsh-glass-float]) body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="options"],
html:not([data-dsh-glass-float]) html[data-ds-theme-source="light"] [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="options"] {
  background: var(--dsw-alias-bg-base, #ffffff) !important;
}

/* --- 仅在开启云母悬浮模式（html[data-dsh-glass-float]）下，才启用 12px 悬浮双岛、16px 圆角大卡片与磨砂投影 --- */
html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) {
  grid-template-columns: 56px minmax(0, 1fr) !important;
  gap: 0 12px !important;
  padding: 8px 12px 12px 12px !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="navTitle"] {
  grid-column: 1 !important;
  grid-row: 1 !important;
  box-sizing: border-box !important;
  width: 56px !important;
  min-width: 56px !important;
  max-width: 56px !important;
  padding: 14px 0 10px 0 !important;
  margin: 0 !important;
  align-items: center !important;
  justify-content: center !important;
  border-radius: 16px 16px 0 0 !important;
  border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  border-bottom: none !important;
  background: var(--dsh-glass-card, var(--dsw-specific-sidebar-fill, #18181b)) !important;
  backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
  -webkit-backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
  flex: none !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed]:not(:has(> [class*="options"])) > nav {
  box-sizing: border-box !important;
  width: 56px !important;
  min-width: 56px !important;
  max-width: 56px !important;
  margin: 8px 12px 12px 12px !important;
  padding: 12px 0 16px !important;
  border-radius: 16px !important;
  border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)), inset 0 1px 0 rgba(255, 255, 255, 0.6) !important;
  background: var(--dsh-glass-card, var(--dsw-alias-bg-layer-1)) !important;
  backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
  -webkit-backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  scrollbar-width: none !important;
  -ms-overflow-style: none !important;
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  gap: 0 !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > nav {
  grid-column: 1 !important;
  grid-row: 2 !important;
  box-sizing: border-box !important;
  width: 56px !important;
  min-width: 56px !important;
  max-width: 56px !important;
  height: 100% !important;
  max-height: 100% !important;
  margin: 0 !important;
  padding: 0 0 16px !important;
  flex: none !important;
  border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  border-top: none !important;
  border-radius: 0 0 16px 16px !important;
  box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)) !important;
  background: var(--dsh-glass-card, var(--dsw-specific-sidebar-fill, #18181b)) !important;
  backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
  -webkit-backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  scrollbar-width: none !important;
  -ms-overflow-style: none !important;
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed]:not(:has(> [class*="options"])) > div:not(nav) {
  margin: 8px 12px 12px 0 !important;
  border-radius: 16px !important;
  border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)), inset 0 1px 0 rgba(255, 255, 255, 0.6) !important;
  background: var(--dsw-alias-bg-layer-1) !important;
  overflow-y: auto !important;
  height: calc(100% - 20px) !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="options"] {
  grid-column: 2 !important;
  grid-row: 1 / -1 !important;
  box-sizing: border-box !important;
  flex: 1 1 auto !important;
  min-width: 0 !important;
  min-height: 0 !important;
  overflow-y: auto !important;
  padding-top: calc(52px + 20px) !important;
  padding-bottom: 40px !important;
  padding-inline: 20px !important;
  margin: 0 !important;
  border-radius: 16px !important;
  border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)), inset 0 1px 0 rgba(255, 255, 255, 0.6) !important;
  background: var(--dsw-alias-bg-layer-1) !important;
  height: 100% !important;
  max-height: 100% !important;
}

[data-shortcut-modal="settings"][data-sidebar-collapsed] > nav::-webkit-scrollbar,
[data-shortcut-modal="settings"][data-sidebar-collapsed] [class*="navList"]::-webkit-scrollbar {
  display: none !important;
  width: 0 !important;
  height: 0 !important;
}

/* 旧版嵌套结构下的返回标题栏，平铺 Grid 宿主下不命中了 nav > :first-child，避免把 navList 错误当成标题 */
[data-shortcut-modal="settings"][data-sidebar-collapsed]:not(:has(> [class*="options"])) > nav > :first-child {
  border: none !important;
  border-radius: 0 !important;
  background: transparent !important;
  box-shadow: none !important;
  padding: 0 !important;
  margin: 0 auto 10px auto !important;
  width: 100% !important;
  display: flex !important;
  justify-content: center !important;
  align-items: center !important;
}

[data-shortcut-modal="settings"][data-sidebar-collapsed]:not(:has(> [class*="options"])) > nav [class*="navList"],
[data-shortcut-modal="settings"][data-sidebar-collapsed]:not(:has(> [class*="options"])) > nav > :nth-child(2) {
  border: none !important;
  background: transparent !important;
  box-shadow: none !important;
  margin: 0 !important;
  padding: 0 !important;
  width: 100% !important;
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  gap: 4px !important;
  scrollbar-width: none !important;
  -ms-overflow-style: none !important;
}

[data-shortcut-modal="settings"][data-sidebar-collapsed] .dcu-settings-nav-header-root,
[data-shortcut-modal="settings"][data-sidebar-collapsed] .dcu-settings-nav-header-top {
  align-items: center !important;
  justify-content: center !important;
  width: 100% !important;
  max-width: 100% !important;
  padding: 0 !important;
  margin: 0 auto !important;
  gap: 0 !important;
}

[data-shortcut-modal="settings"][data-sidebar-collapsed] .dcu-settings-back-btn,
[data-shortcut-modal="settings"][data-sidebar-collapsed] button.dcu-settings-back-btn {
  margin: 0 auto !important;
}

[data-shortcut-modal="settings"][data-sidebar-collapsed] .dcu-settings-nav-header-title,
[data-shortcut-modal="settings"][data-sidebar-collapsed] .dcu-settings-search-wrapper,
[data-shortcut-modal="settings"][data-sidebar-collapsed] .dcu-settings-nav-group-header,
[data-shortcut-modal="settings"][data-sidebar-collapsed] .dcu-settings-nav-empty {
  display: none !important;
}

[data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > nav,
html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > nav {
  grid-column: 1 !important;
  grid-row: 2 !important;
  box-sizing: border-box !important;
  width: 56px !important;
  min-width: 56px !important;
  max-width: 56px !important;
  height: 100% !important;
  max-height: 100% !important;
  margin: 0 !important;
  padding: 0 0 16px !important;
  flex: none !important;
  border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  border-top: none !important;
  border-radius: 0 0 16px 16px !important;
  box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)) !important;
  background: var(--dsh-glass-card, var(--dsw-specific-sidebar-fill, #18181b)) !important;
  backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
  -webkit-backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  scrollbar-width: none !important;
  -ms-overflow-style: none !important;
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
}

/* 导航项按钮：纯图标居中方块，对齐宿主官方首页折叠 36x36px panelRow，绝对居中无偏移 */
[data-shortcut-modal="settings"][data-sidebar-collapsed] > nav button,
[data-shortcut-modal="settings"][data-sidebar-collapsed] > nav > :nth-child(2) > button,
[data-shortcut-modal="settings"][data-sidebar-collapsed] > nav [class*="navCell"] {
  box-sizing: border-box !important;
  width: 36px !important;
  height: 36px !important;
  min-width: 36px !important;
  min-height: 36px !important;
  max-width: 36px !important;
  max-height: 36px !important;
  padding: 0 !important;
  margin: 2px auto !important;
  gap: 0 !important;
  justify-content: center !important;
  align-items: center !important;
  text-align: center !important;
  border-radius: var(--dsw-radius-md, 8px) !important;
  flex: 0 0 36px !important;
}

/* 仅隐藏设置菜单列表中的文字标签，绝不干涉任何图标的显示规则，100%继承展开态既定图标状态！ */
[data-shortcut-modal="settings"][data-sidebar-collapsed] > nav [class*="navList"] button [class*="navLabel"],
[data-shortcut-modal="settings"][data-sidebar-collapsed] > nav button:not(.dcu-settings-back-btn) [class*="navLabel"] {
  display: none !important;
}

/* 保护并确保返回按钮完整显示，包含其内部由宿主 Button 原语包裹的 span 图标 */
[data-shortcut-modal="settings"][data-sidebar-collapsed] .dcu-settings-back-btn,
[data-shortcut-modal="settings"][data-sidebar-collapsed] button.dcu-settings-back-btn {
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  width: 32px !important;
  height: 32px !important;
  min-width: 32px !important;
  min-height: 32px !important;
  margin: 0 auto 6px auto !important;
  padding: 0 !important;
  border-radius: var(--dsw-radius-md, 8px) !important;
  opacity: 1 !important;
  visibility: visible !important;
}

[data-shortcut-modal="settings"][data-sidebar-collapsed] .dcu-settings-back-btn span,
[data-shortcut-modal="settings"][data-sidebar-collapsed] .dcu-settings-back-btn svg {
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  opacity: 1 !important;
  visibility: visible !important;
}

/* 无论官方项目还是第三方插件，每个按钮在折叠态均保持唯一的视觉中心，不强行干涉内部已隐藏的备用 svg */
[data-shortcut-modal="settings"][data-sidebar-collapsed] > nav [class*="navList"] button svg,
[data-shortcut-modal="settings"][data-sidebar-collapsed] > nav [class*="navIcon"] svg {
  margin: 0 !important;
  padding: 0 !important;
  width: 18px !important;
  height: 18px !important;
  flex: none !important;
}

/* 顶栏操作区（配置文件与关闭按钮）：普通模式下透明浮动，无实体白条与下边框，绝不硬切出第二层顶部 */
html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="header"] {
  grid-column: 2 !important;
  grid-row: 1 / -1 !important;
  position: absolute !important;
  top: 0 !important;
  left: 0 !important;
  right: 0 !important;
  height: 56px !important;
  min-height: 56px !important;
  padding: 0 20px !important;
  border-radius: 0 !important;
  border: none !important;
  border-bottom: none !important;
  background: transparent !important;
  z-index: 10 !important;
  pointer-events: none !important;
}

html:not([data-dsh-glass-float]) body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="header"],
html:not([data-dsh-glass-float]) html[data-ds-theme-source="light"] [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="header"] {
  background: transparent !important;
  border: none !important;
  border-bottom: none !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="header"] {
  grid-column: 2 !important;
  grid-row: 1 / -1 !important;
  position: absolute !important;
  top: 8px !important;
  left: 0 !important;
  right: 12px !important;
  height: 52px !important;
  min-height: 52px !important;
  padding: 0 20px !important;
  border: none !important;
  border-radius: 0 !important;
  background: transparent !important;
  z-index: 10 !important;
  pointer-events: none !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="header"] > * {
  pointer-events: auto !important;
}

html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed]:not(:has(> [class*="options"])) > div:not(nav) {
  margin: 8px 12px 12px 0 !important;
  border-radius: 16px !important;
  border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)), inset 0 1px 0 rgba(255, 255, 255, 0.6) !important;
  background: var(--dsw-alias-bg-layer-1) !important;
  overflow-y: auto !important;
  height: calc(100% - 20px) !important;
}

[data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="options"],
html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="options"] {
  grid-column: 2 !important;
  grid-row: 1 / -1 !important;
  box-sizing: border-box !important;
  flex: 1 1 auto !important;
  min-width: 0 !important;
  min-height: 0 !important;
  overflow-y: auto !important;
  padding-top: calc(52px + 20px) !important;
  padding-bottom: 40px !important;
  padding-inline: 20px !important;
  margin: 0 !important;
  border-radius: 16px !important;
  border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
  box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)), inset 0 1px 0 rgba(255, 255, 255, 0.6) !important;
  background: var(--dsw-alias-bg-layer-1) !important;
  height: 100% !important;
  max-height: 100% !important;
}

/* 移动端与极窄视口响应式规范：对齐宿主官方首页 56px 图标导轨（Icon Rail）模式 */
@media (max-width: 768px) {
  body > [role="presentation"]:has(> [data-shortcut-modal="settings"]) {
    padding: 0 !important;
  }

  /* 强行压制 JS 写入的行内 --dcu-settings-nav-width 变量，并将所有云母/经典模式的基准锁死为 56px */
  [data-shortcut-modal="settings"],
  html[data-dsh-glass-float] [data-shortcut-modal="settings"],
  html[data-dsh-glass] [data-shortcut-modal="settings"] {
    --dcu-settings-nav-width: 56px !important;
    position: fixed !important;
    inset: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    max-width: none !important;
    max-height: none !important;
    border-radius: 0 !important;
    border: none !important;
    display: flex !important;
    flex-direction: row !important;
    padding-top: env(safe-area-inset-top, 0px) !important;
    padding-bottom: env(safe-area-inset-bottom, 0px) !important;
    padding-left: env(safe-area-inset-left, 0px) !important;
    padding-right: env(safe-area-inset-right, 0px) !important;
    box-sizing: border-box !important;
  }

  /* 4 块 Grid 布局映射：普通模式紧贴平铺，仅在云母模式下启用悬浮双岛与外层边距 */
  html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"]:has(> [class*="options"]) {
    display: grid !important;
    grid-template-columns: 56px minmax(0, 1fr) !important;
    grid-template-rows: auto minmax(0, 1fr) !important;
    position: fixed !important;
    inset: 0 !important;
    gap: 0 !important;
    padding: 0 !important;
    background: var(--dsw-alias-bg-base, #151517) !important;
  }

  html[data-dsh-glass-float] [data-shortcut-modal="settings"]:has(> [class*="options"]),
  html[data-dsh-glass] [data-shortcut-modal="settings"]:has(> [class*="options"]) {
    display: grid !important;
    grid-template-columns: 56px minmax(0, 1fr) !important;
    grid-template-rows: auto minmax(0, 1fr) !important;
    position: fixed !important;
    inset: 0 !important;
    gap: 0 12px !important;
    padding: 8px 12px 12px 12px !important;
  }

  /* 左侧顶部区：普通模式下平铺实色无圆角，云母模式下为圆角磨砂卡片 */
  html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="navTitle"] {
    grid-column: 1 !important;
    grid-row: 1 !important;
    box-sizing: border-box !important;
    width: 56px !important;
    min-width: 56px !important;
    max-width: 56px !important;
    padding: 14px 0 10px 0 !important;
    margin: 0 !important;
    align-items: center !important;
    justify-content: center !important;
    border-radius: 0 !important;
    border: none !important;
    border-right: 1px solid var(--dsw-alias-border-l1, rgba(255, 255, 255, 0.08)) !important;
    border-bottom: none !important;
    background: var(--dsw-specific-sidebar-fill, var(--dsw-alias-bg-layer-1, #18181b)) !important;
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
    box-shadow: none !important;
    flex: none !important;
  }

  html[data-dsh-glass-float] [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="navTitle"] {
    grid-column: 1 !important;
    grid-row: 1 !important;
    box-sizing: border-box !important;
    width: 56px !important;
    min-width: 56px !important;
    max-width: 56px !important;
    padding: 14px 0 10px 0 !important;
    margin: 0 !important;
    align-items: center !important;
    justify-content: center !important;
    border-radius: 16px 16px 0 0 !important;
    border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
    border-bottom: none !important;
    background: var(--dsh-glass-card, var(--dsw-specific-sidebar-fill, #18181b)) !important;
    backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
    -webkit-backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
    flex: none !important;
  }

  /* 旧版嵌套宿主在 <=768px 下的 nav 单岛体系，与折叠块完全对齐 */
  [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > nav,
  html[data-dsh-glass-float] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > nav {
    box-sizing: border-box !important;
    width: 56px !important;
    min-width: 56px !important;
    max-width: 56px !important;
    margin: 8px 12px 12px 12px !important;
    padding: 12px 0 16px !important;
    border-radius: 16px !important;
    border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
    box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)), inset 0 1px 0 rgba(255, 255, 255, 0.6) !important;
    background: var(--dsh-glass-card, var(--dsw-alias-bg-layer-1)) !important;
    backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
    -webkit-backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    scrollbar-width: none !important;
    -ms-overflow-style: none !important;
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
    gap: 0 !important;
  }

  [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > nav > :first-child {
    border: none !important;
    border-radius: 0 !important;
    background: transparent !important;
    box-shadow: none !important;
    padding: 0 !important;
    margin: 0 auto 10px auto !important;
    width: 100% !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
  }

  [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > nav [class*="navList"],
  [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > nav > :nth-child(2) {
    border: none !important;
    background: transparent !important;
    box-shadow: none !important;
    margin: 0 !important;
    padding: 0 !important;
    width: 100% !important;
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
    gap: 4px !important;
    scrollbar-width: none !important;
    -ms-overflow-style: none !important;
  }

  .dcu-settings-nav-header-root {
    align-items: center !important;
    justify-content: center !important;
    width: 56px !important;
    max-width: 56px !important;
  }

  .dcu-settings-nav-header-top {
    justify-content: center !important;
    padding: 0 !important;
    width: 56px !important;
    max-width: 56px !important;
  }

  .dcu-settings-nav-header-title,
  .dcu-settings-search-wrapper,
  .dcu-settings-nav-group-header,
  .dcu-settings-nav-empty {
    display: none !important;
  }

  /* 左侧导航栏：普通模式下平铺实色无圆角无投影，云母模式下完整对齐首页云母磨砂圆角与下投影 */
  html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"] > nav,
  html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"]:has(> [class*="options"]) > nav {
    grid-column: 1 !important;
    grid-row: 2 !important;
    box-sizing: border-box !important;
    width: 56px !important;
    min-width: 56px !important;
    max-width: 56px !important;
    height: 100% !important;
    max-height: 100% !important;
    margin: 0 !important;
    padding: 0 0 16px !important;
    flex: none !important;
    border: none !important;
    border-right: 1px solid var(--dsw-alias-border-l1, rgba(255, 255, 255, 0.08)) !important;
    border-radius: 0 !important;
    box-shadow: none !important;
    background: var(--dsw-specific-sidebar-fill, var(--dsw-alias-bg-layer-1, #18181b)) !important;
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    scrollbar-width: none !important;
    -ms-overflow-style: none !important;
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
  }

  html[data-dsh-glass-float] [data-shortcut-modal="settings"] > nav,
  html[data-dsh-glass-float] [data-shortcut-modal="settings"]:has(> [class*="options"]) > nav,
  html[data-dsh-glass-float] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > nav {
    grid-column: 1 !important;
    grid-row: 2 !important;
    box-sizing: border-box !important;
    width: 56px !important;
    min-width: 56px !important;
    max-width: 56px !important;
    height: 100% !important;
    max-height: 100% !important;
    margin: 0 !important;
    padding: 0 8px 16px !important;
    flex: none !important;
    border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
    border-top: none !important;
    border-radius: 0 0 16px 16px !important;
    box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)) !important;
    background: var(--dsh-glass-card, var(--dsw-specific-sidebar-fill, #18181b)) !important;
    backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
    -webkit-backdrop-filter: blur(var(--dsh-glass-blur, 16px)) !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    scrollbar-width: none !important;
    -ms-overflow-style: none !important;
  }

  [data-shortcut-modal="settings"] > nav::-webkit-scrollbar,
  [data-shortcut-modal="settings"] [class*="navList"]::-webkit-scrollbar {
    display: none !important;
    width: 0 !important;
    height: 0 !important;
  }

  /* 导航项按钮：纯图标正方形居中卡片，尺寸统一为 36x36px 图标导轨 */
  [data-shortcut-modal="settings"] > nav button,
  [data-shortcut-modal="settings"] > nav > :nth-child(2) > button,
  [data-shortcut-modal="settings"] > nav [class*="navCell"] {
    width: 36px !important;
    height: 36px !important;
    min-width: 36px !important;
    min-height: 36px !important;
    max-width: 36px !important;
    max-height: 36px !important;
    padding: 0 !important;
    margin: 2px auto !important;
    justify-content: center !important;
    align-items: center !important;
    border-radius: var(--dsw-radius-md, 8px) !important;
  }

  /* 隐藏菜单项文字标签，保留居中图标，保护返回按钮 */
  [data-shortcut-modal="settings"] > nav [class*="navList"] button [class*="navLabel"],
  [data-shortcut-modal="settings"] > nav button:not(.dcu-settings-back-btn) [class*="navLabel"] {
    display: none !important;
  }

  /* 移动端媒体查询下同样仅隐藏文字，不干涉图标 */
  [data-shortcut-modal="settings"] > nav [class*="navList"] button svg,
  [data-shortcut-modal="settings"] > nav [class*="navIcon"] svg {
    margin: 0 !important;
    width: 18px !important;
    height: 18px !important;
  }

  /* 顶部操作区（配置文件与关闭按钮）：对齐首页悬浮大卡片的 52px 顶栏，左边缘与右侧卡片完全对齐 */
  [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="header"],
  html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="header"] {
    grid-column: 2 !important;
    grid-row: 1 / -1 !important;
    position: absolute !important;
    top: 8px !important;
    left: 0 !important;
    right: 12px !important;
    height: 52px !important;
    min-height: 52px !important;
    padding: 0 20px !important;
    border: none !important;
    border-radius: 0 !important;
    background: transparent !important;
    z-index: 10 !important;
    pointer-events: none !important;
  }

  html[data-dsh-glass-float] [data-shortcut-modal="settings"][data-sidebar-collapsed]:has(> [class*="options"]) > [class*="header"] > * {
    pointer-events: auto !important;
  }

  html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) {
    margin: 0 !important;
    border-radius: 0 !important;
    border: none !important;
    box-shadow: none !important;
    background: var(--dsw-alias-bg-base, #151517) !important;
    height: 100% !important;
    max-height: 100% !important;
    overflow: hidden !important;
    display: flex !important;
    flex-direction: column !important;
  }

  html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :first-child {
    background: transparent !important;
    border: none !important;
    border-bottom: none !important;
    flex: none !important;
  }

  /* 右侧设置内容区：普通模式平铺紧贴，云母模式下复刻首页右侧 16px 圆角大卡片独立悬浮岛 */
  html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) > :nth-child(2) {
    margin: 0 !important;
    border-radius: 0 !important;
    border: none !important;
    box-shadow: none !important;
    background: transparent !important;
    overflow-y: auto !important;
    flex: 1 1 auto !important;
    min-height: 0 !important;
    padding-top: 28px !important;
    padding-bottom: 40px !important;
    padding-inline: 20px !important;
    box-sizing: border-box !important;
  }

  html:not([data-dsh-glass-float]) [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"] {
    margin: 0 !important;
    border-radius: 0 !important;
    border: none !important;
    box-shadow: none !important;
    background: var(--dsw-alias-bg-base, #151517) !important;
    overflow-y: auto !important;
    height: 100% !important;
    max-height: 100% !important;
    padding-top: calc(56px + 28px) !important;
    padding-bottom: 40px !important;
    padding-inline: 20px !important;
    box-sizing: border-box !important;
  }

  html:not([data-dsh-glass-float]) body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav),
  html:not([data-dsh-glass-float]) html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav),
  html:not([data-dsh-glass-float]) body:not([data-ds-dark-theme]) [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"],
  html:not([data-dsh-glass-float]) html[data-ds-theme-source="light"] [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"] {
    background: var(--dsw-alias-bg-base, #ffffff) !important;
  }

  html[data-dsh-glass-float] [data-shortcut-modal="settings"]:not(:has(> [class*="options"])) > div:not(nav) {
    margin: 8px 12px 12px 0 !important;
    border-radius: 16px !important;
    border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
    box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)), inset 0 1px 0 rgba(255, 255, 255, 0.6) !important;
    background: var(--dsw-alias-bg-layer-1) !important;
    overflow-y: auto !important;
    height: calc(100% - 20px) !important;
  }

  [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"],
  html[data-dsh-glass-float] [data-shortcut-modal="settings"]:has(> [class*="options"]) > [class*="options"] {
    grid-column: 2 !important;
    grid-row: 1 / -1 !important;
    box-sizing: border-box !important;
    flex: 1 1 auto !important;
    min-width: 0 !important;
    min-height: 0 !important;
    overflow-y: auto !important;
    padding-top: calc(52px + 20px) !important;
    padding-bottom: 40px !important;
    padding-inline: 20px !important;
    margin: 0 !important;
    border-radius: 16px !important;
    border: 1px solid var(--dsh-glass-rim-soft, rgba(0, 0, 0, 0.08)) !important;
    box-shadow: var(--dsh-glass-drop, 0 8px 24px rgba(0, 0, 0, 0.08)), inset 0 1px 0 rgba(255, 255, 255, 0.6) !important;
    background: var(--dsw-alias-bg-layer-1) !important;
    height: 100% !important;
    max-height: 100% !important;
  }

  [data-shortcut-modal="settings"] [class*="section"],
  [data-shortcut-modal="settings"] [class*="card"] {
    width: 100% !important;
    max-width: 100% !important;
  }
}
`

let lastSkinCheckTime = 0
let cachedSkinEnabledResult: boolean | null = null

/** 探测宿主 settings-skin 子组件是否处于激活状态（含 5 秒 TTL 缓存，避免频繁打开弹层连续网络开销） */
export async function checkSettingsSkinEnabled(force = false): Promise<boolean> {
  const now = Date.now()
  if (!force && cachedSkinEnabledResult !== null && now - lastSkinCheckTime < 5000) {
    return cachedSkinEnabledResult
  }
  try {
    const response = await fetch('/api/michengai/dsh-codex-ui/settings-skin', {
      headers: { Accept: 'application/json' },
      cache: 'no-store',
    })
    if (!response.ok) {
      cachedSkinEnabledResult = false
      lastSkinCheckTime = now
      return false
    }
    const data = await response.json()
    cachedSkinEnabledResult = data?.enabled === true
    lastSkinCheckTime = now
    return cachedSkinEnabledResult
  } catch {
    // 无法连通 /api/michengai/dsh-codex-ui/settings-skin（例如子组件被停用导致端点不存在、或网络断开），坚决返回 false！
    cachedSkinEnabledResult = false
    lastSkinCheckTime = now
    return false
  }
}

/** 重置 settings-skin 探测缓存（用于测试或强制重新探测） */
export function refreshSettingsSkinCache(): void {
  lastSkinCheckTime = 0
  cachedSkinEnabledResult = null
}

/** 注入 Codex 1:1 设置皮肤样式 */
export function installSettingsSkin(doc: Document = document): () => void {
  const existing = doc.getElementById(SETTINGS_SKIN_STYLE_ID)
  if (existing !== null) {
    // 若已存在但样式内容有变动，热更新其 textContent，绝不锁死旧样式
    if (existing.textContent !== SETTINGS_SKIN_CSS) {
      existing.textContent = SETTINGS_SKIN_CSS
    }
    return () => { existing.remove() }
  }
  const style = doc.createElement('style')
  style.id = SETTINGS_SKIN_STYLE_ID
  style.textContent = SETTINGS_SKIN_CSS
  ;(doc.head ?? doc.documentElement).appendChild(style)
  return () => { if (style.parentNode !== null) style.remove() }
}

/** 彻底卸载 Codex 设置皮肤并清理 DOM 样式节点 */
export function uninstallSettingsSkin(doc: Document = document): void {
  const existing = doc.getElementById(SETTINGS_SKIN_STYLE_ID)
  if (existing !== null) {
    existing.remove()
  }
}

/** 宿主官方侧栏标准默认展开宽度为 280px，可拖拽下限为 264px */
export const DEFAULT_SIDEBAR_WIDTH = 280
export const MIN_SIDEBAR_WIDTH = 264

/**
 * 探测宿主首页主侧栏的展开宽度（默认 280px，最小 264px）
 * 1. 优先解析 AppFrame 上的 gridTemplateColumns（如 280px minmax(...) ...）；
 * 2. 其次读取宿主 Windows 标题栏或侧栏 CSS 变量；
 * 3. 再次直接测量宿主侧栏 DOM 容器元素的实际宽度；
 * 4. 若侧栏处于折叠状态（56px / 0px）或未找到，则安全回退至宿主官方标准默认宽度 280px。
 */
export function getHostSidebarExpandedWidth(doc: Document = document): number {
  if (!doc) return DEFAULT_SIDEBAR_WIDTH

  // 1. 尝试从 AppFrame 元素行内 gridTemplateColumns 解析
  try {
    for (const node of doc.querySelectorAll<HTMLElement>('div')) {
      const grid = node.style?.gridTemplateColumns
      if (grid && grid.includes('minmax')) {
        const match = /^(\d+(?:\.\d+)?)px\s+/.exec(grid.trim())
        if (match) {
          const parsed = Number(match[1])
          if (Number.isFinite(parsed) && parsed >= MIN_SIDEBAR_WIDTH) {
            return parsed
          }
        }
      }
    }
  } catch {
    // 忽略异常
  }

  // 2. 尝试从宿主 CSS 变量读取
  try {
    const rootStyle = doc.documentElement ? getComputedStyle(doc.documentElement) : null
    if (rootStyle) {
      const winWidth = Number.parseFloat(rootStyle.getPropertyValue('--dsh-windows-sidebar-width'))
      if (Number.isFinite(winWidth) && winWidth >= MIN_SIDEBAR_WIDTH) return winWidth
      const hostWidth = Number.parseFloat(rootStyle.getPropertyValue('--dsh-sidebar-width'))
      if (Number.isFinite(hostWidth) && hostWidth >= MIN_SIDEBAR_WIDTH) return hostWidth
    }
  } catch {
    // 忽略异常
  }

  // 3. 尝试直接测量 DOM 侧栏容器
  try {
    const sidebarEl = doc.querySelector<HTMLElement>('[data-slot="sidebar"]')
      ?? doc.querySelector<HTMLElement>('div[class*="sidebarCol"]')
      ?? doc.querySelector<HTMLElement>('div[class*="hHd-Xa_root"]')
    if (sidebarEl) {
      const measured = sidebarEl.getBoundingClientRect?.().width
      if (typeof measured === 'number' && Number.isFinite(measured) && measured >= MIN_SIDEBAR_WIDTH) {
        return measured
      }
    }
  } catch {
    // 忽略异常
  }

  return DEFAULT_SIDEBAR_WIDTH
}

/** 探测宿主首页侧栏是否处于折叠状态（56px 导轨或窄屏自动收起） */
export function isHostSidebarCollapsed(doc: Document = document): boolean {
  if (!doc) return false
  try {
    if (doc.querySelector('[data-sidebar-collapsed="true"], [data-sidebar-collapsed]') !== null) {
      return true
    }
    const sidebarEl = doc.querySelector<HTMLElement>('[data-slot="sidebar"]')
      ?? doc.querySelector<HTMLElement>('div[class*="sidebarCol"]')
      ?? doc.querySelector<HTMLElement>('div[class*="hHd-Xa_root"]')
    if (sidebarEl) {
      const measured = sidebarEl.getBoundingClientRect?.().width
      if (typeof measured === 'number' && Number.isFinite(measured) && measured > 0 && measured <= 64) {
        return true
      }
    }
  } catch {
    // 忽略
  }
  return false
}

/**
 * 对宿主动态生成的菜单按钮执行无侵入的已知项分组与搜索过滤
 */
export function decorateSettingsNav(panelEl: HTMLElement): () => void {
  // 同步主侧栏展开/收起状态至模态框，确保与首页侧栏严格 1:1 对齐
  const isCollapsed = isHostSidebarCollapsed(panelEl.ownerDocument || document)
  if (isCollapsed) {
    panelEl.setAttribute('data-sidebar-collapsed', 'true')
    panelEl.style.setProperty('--dcu-settings-nav-width', '56px')
  } else {
    panelEl.removeAttribute('data-sidebar-collapsed')
    const sidebarWidth = getHostSidebarExpandedWidth(panelEl.ownerDocument || document)
    panelEl.style.setProperty('--dcu-settings-nav-width', `${sidebarWidth}px`)
  }

  // 兼容新旧两版宿主结构：新版（0.2.1-alpha.3+）navTitle 与 nav 为同级兄弟节点；旧版 navTitle 是 nav 的首个子元素
  const navHeader = panelEl.querySelector<HTMLElement>(':scope > [class*="navTitle"]')
    ?? panelEl.querySelector<HTMLElement>('nav > :first-child')
  const navList = panelEl.querySelector<HTMLElement>('nav [class*="navList"]')
    ?? panelEl.querySelector<HTMLElement>('nav > :nth-child(2)')
    ?? panelEl.querySelector<HTMLElement>('nav > :first-child')
  if (!navList) return () => {}

  const isZh = (document.documentElement.lang || 'zh').startsWith('zh')

  // 1. 装饰顶部 Header（返回箭头 + 搜索框，挂载 React 宿主原生 Input 原语）
  let cleanHeader = () => {}
  if (navHeader && !navHeader.querySelector('.dcu-settings-nav-header-root')) {
    const originalChildren = Array.from(navHeader.childNodes)
    originalChildren.forEach(child => {
      if (child instanceof HTMLElement) {
        child.style.display = 'none'
      } else if (child.nodeType === 3) {
        child.textContent = ''
      }
    })

    const headerRoot = document.createElement('div')
    headerRoot.className = 'dcu-settings-nav-header-root'

    render(React.createElement(SettingsNavHeader), headerRoot)
    navHeader.appendChild(headerRoot)

    cleanHeader = () => {
      unmountComponentAtNode(headerRoot)
      headerRoot.remove()
      originalChildren.forEach(child => {
        if (child instanceof HTMLElement) child.style.removeProperty('display')
      })
    }
  }

  // 2. 注入三组分组小标题（若不存在）
  for (const group of SETTINGS_NAV_GROUPS) {
    if (!navList.querySelector(`[data-dcu-group-header="${group.id}"]`)) {
      const header = document.createElement('div')
      header.className = 'dcu-settings-nav-group-header'
      header.setAttribute('data-dcu-group-header', group.id)
      header.style.setProperty('order', String(group.order))
      header.textContent = isZh ? group.defaultZh : group.defaultEn
      navList.appendChild(header)
    }
  }

  // 3. 注入空状态提示（若不存在）
  let emptyTip = navList.querySelector<HTMLElement>('[data-dcu-group-empty]')
  if (!emptyTip) {
    emptyTip = document.createElement('div')
    emptyTip.className = 'dcu-settings-nav-empty'
    emptyTip.setAttribute('data-dcu-group-empty', '')
    emptyTip.style.setProperty('order', '999')
    emptyTip.style.display = 'none'
    emptyTip.textContent = isZh ? zh['settings.noResults'] : en['settings.noResults']
    navList.appendChild(emptyTip)
  }

  // 安全提取设置按钮正文文本（兼容老版单 span 与新版 navIcon + navLabel 双 span 结构）
  const getNavButtonLabel = (btn: HTMLButtonElement): string => {
    const labelEl = btn.querySelector<HTMLElement>('[class*="navLabel"]')
    if (labelEl && labelEl.textContent?.trim()) {
      return labelEl.textContent.trim()
    }
    const textSpan = btn.querySelector<HTMLElement>('span:not([class*="navIcon"])')
    if (textSpan && textSpan.textContent?.trim()) {
      return textSpan.textContent.trim()
    }
    const allSpans = btn.querySelectorAll<HTMLElement>('span')
    for (const s of allSpans) {
      if (s.textContent?.trim() && !s.className?.includes('navIcon')) {
        return s.textContent.trim()
      }
    }
    return btn.textContent?.trim() ?? ''
  }

  // 4. 归类并赋 order 给宿主生成的每个 button，纯通用布局
  const classifyButtons = () => {
    const buttons = navList.querySelectorAll<HTMLButtonElement>(':scope > button')
    buttons.forEach((btn, index) => {
      const label = getNavButtonLabel(btn)
      const group = classifySettingsButton(label)
      const baseOrder = group === 'personal' ? 100 : group === 'records' ? 300 : 200
      btn.style.setProperty('order', String(baseOrder + 1 + index))
      btn.setAttribute('data-dcu-group', group)
    })
  }
  classifyButtons()

  // 5. 搜索过滤联动与空分组小标题动态自愈隐藏
  const applyFilter = (query: string) => {
    const trimmed = query.trim().toLowerCase()
    const buttons = navList.querySelectorAll<HTMLButtonElement>(':scope > button')
    let totalVisible = 0

    for (const btn of buttons) {
      const label = getNavButtonLabel(btn).toLowerCase()
      if (trimmed === '') {
        btn.style.removeProperty('display')
        totalVisible += 1
      } else {
        const matches = label.includes(trimmed)
        if (matches) {
          btn.style.removeProperty('display')
          totalVisible += 1
        } else {
          btn.style.setProperty('display', 'none', 'important')
        }
      }
    }

    for (const group of SETTINGS_NAV_GROUPS) {
      const header = navList.querySelector<HTMLElement>(`[data-dcu-group-header="${group.id}"]`)
      if (header) {
        const visibleCount = [...navList.querySelectorAll<HTMLButtonElement>(`button[data-dcu-group="${group.id}"]`)]
          .filter(b => b.style.display !== 'none').length
        if (visibleCount > 0) {
          header.style.removeProperty('display')
        } else {
          header.style.setProperty('display', 'none', 'important')
        }
      }
    }

    if (emptyTip) {
      emptyTip.style.setProperty('display', totalVisible === 0 ? 'block' : 'none', 'important')
    }
  }

  applyFilter(getNavSearchQuery())
  const unsubSearch = subscribeNavSearch(applyFilter)

  // 6. 监听宿主后续异步动态追加的 button
  const navObserver = new MutationObserver(() => {
    classifyButtons()
    applyFilter(getNavSearchQuery())
  })
  navObserver.observe(navList, { childList: true })

  return () => {
    cleanHeader()
    unsubSearch()
    navObserver.disconnect()
    navList.querySelectorAll('[data-dcu-group-header], [data-dcu-group-empty]').forEach(el => el.remove())
    navList.querySelectorAll<HTMLButtonElement>(':scope > button').forEach(btn => {
      btn.style.removeProperty('order')
      btn.style.display = ''
      btn.removeAttribute('data-dcu-group')
    })
  }
}

/**
 * 观察设置弹层的挂载并与子组件生命周期同步
 * 返回 Disposer，卸载时彻底移除 Observer、装饰器与注入样式
 */
export function observeSettingsSkin(_ctx?: Context): () => void {
  let disposed = false
  let cleanDecorator: (() => void) | undefined

  const sync = async (): Promise<void> => {
    if (disposed) return
    const enabled = await checkSettingsSkinEnabled()
    if (disposed) return
    setSkinEnabledState(enabled)
    if (enabled) {
      installSettingsSkin(document)
      const modal = document.querySelector<HTMLElement>('[data-shortcut-modal="settings"]')
      if (modal) {
        cleanDecorator?.()
        cleanDecorator = decorateSettingsNav(modal)
      }
    } else {
      cleanDecorator?.()
      cleanDecorator = undefined
      uninstallSettingsSkin(document)
    }
  }

  // 1. 启动时异步同步状态（受启用门控保护，停用态绝不预先注入样式或装饰 DOM）
  if (typeof document !== 'undefined') {
    void sync()
  }

  const observer = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node instanceof HTMLElement) {
          const modal = node.getAttribute('data-shortcut-modal') === 'settings'
            ? node
            : node.querySelector<HTMLElement>('[data-shortcut-modal="settings"]')
          if (modal) {
            // 严格受启用状态门控：仅在已确认启用时才预装并装饰，停用态绝不提前注入样式
            if (cachedSkinEnabledResult === true) {
              installSettingsSkin(document)
              cleanDecorator?.()
              cleanDecorator = decorateSettingsNav(modal)
            }
            void sync()
            return
          }
        }
      }
      for (const node of mutation.removedNodes) {
        if (node instanceof HTMLElement) {
          if (node.getAttribute('data-shortcut-modal') === 'settings' || node.querySelector('[data-shortcut-modal="settings"]')) {
            cleanDecorator?.()
            cleanDecorator = undefined
          }
        }
      }
    }
  })

  observer.observe(document.body, { childList: true, subtree: true })

  return () => {
    disposed = true
    observer.disconnect()
    cleanDecorator?.()
    setSkinEnabledState(false)
    uninstallSettingsSkin(document)
  }
}
