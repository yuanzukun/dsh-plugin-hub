# Changelog

## [2.4.2] - 2026-11-21

- **Fix Prediction Candidates Display and Control Text Filtering with Reasoning Models (Issue #108, PR #109)**:
  - Increased default prediction token budget to provide ample reasoning headroom, resolving the issue where ghost suggestions never appeared with certain reasoning models;
  - Improved prediction truncation and candidate recovery to retain usable whole candidates when length limits are reached, preventing single-line completions from being accidentally cleared;
  - Enhanced streaming preview by filtering out prompt echoes and control text, immediately halting when no prediction is available to keep ghost suggestions crisp and accurate.

## [2.4.1] - 2026-11-20

- **Fix Network Noise and Continuous Error Logs When Theme Feature is Disabled (Issue #107)**:
  - Fixed an issue where disabling the theme feature in configuration caused the client to continuously request theme status and log 404 network errors in DevTools;
  - Improved the status probing behavior so failed probes back off and stop polling indefinitely, keeping the network panel and error count clean without background noise.

## [2.4.0] - 2026-11-20

- **Searchable, keyboard-friendly workspace menu on the new-session page (PR #106)**:
  - The hero workspace menu is now a Codex-style project picker: type to filter by project name or path, move with the arrow keys, pick with Enter, dismiss with Escape;
  - The keyboard highlight keeps itself scrolled into view, and closing the picker returns focus to the workspace chip;
  - Same-named projects show the shortest path suffix that tells them apart;
  - The current workspace carries a check mark, so the project in use is obvious at a glance;
  - A "New project" row at the bottom picks a directory, registers it as a workspace and switches to it;
  - While the system directory dialog is open the row stays disabled, so a double click cannot open two dialogs;
  - Note: creating a project now opens the system directory dialog; the hero no longer offers the in-app directory browsing flow, and hosts without a native directory dialog (remote connections, SSH launches, non-loopback binds) hide the "New project" row.

## [2.3.0] - 2026-11-19

- **Host Compatibility Baseline Upgraded to DeepSeek Harness 0.2.2 Series**:
  - Fully adapted to the latest DeepSeek Harness 0.2.2 versions (0.2.2-rc.1 through 0.2.2-rc.5), aligning with the newest host full-screen settings workbench and native sidebar right-click menu experiences;
  - Raised minimum supported host version to 0.2.2-rc.1, dropping legacy support for 0.2.0, 0.2.1, and older versions; removed outdated fallback logic to optimize startup and rendering performance on modern hosts.

## [2.2.7] - 2026-11-17

- **Workspace Header Create Section Button & Inline Insertion (Issue #105)**:
  - Added a dedicated "Create section" button to the workspace header in the sidebar, allowing new sections to be created instantly with an inline name input;
  - Added a "Create section" option to the `···` more actions menu on existing section headers, making it easy to create peer sections directly at the desired location;
  - Pressing Enter creates the section while Escape cancels it, seamlessly updating the layout without manual page refreshing.
- **Empty Section Creation & Sidebar Rail Interaction Safeguards (Issue #105)**:
  - Fixed an issue where creating a new section directly below an empty section could cause the input box to lose focus prematurely;
  - Ensured smooth section creation and positioning across both expanded and collapsed sidebar layouts, preventing input disruptions.
- **Third-Party Plugin Menu & Popover Theme Isolation (Issue #104)**:
  - Refined theme scope selectors so that only the outermost popovers and dropdown wrappers carry plugin styles, preventing nested menus and native third-party plugin panels from unintended dark styling or clipped borders.

## [2.2.6] - 2026-11-16

- **Default "Projects" Section Supports Reordering Up and Down (Issue #103)**:
  - Added a `···` more actions menu to the default "Projects" workspace section header with "Move up" and "Move down" options, allowing it to be repositioned freely among workspace sections;
  - Boundary positions and fold states are automatically handled, instantly updating the sidebar and persisting across restarts.
- **Section Collapse Icons and Header Polish Aligned with Codex (Issue #103)**:
  - Replaced the solid triangle collapse indicator with a subtle outlined Chevron icon with smooth rotation on toggle;
  - Section header titles now feature medium font weight (500) and smooth 150ms hover transitions for background and text colors, improving visual hierarchy.
- **Light Theme Settings Card Fill Fix (Issue #102)**:
  - Fixed an issue where settings cards would turn into a translucent dark gray when dialogs were open under light theme, keeping card backgrounds crisp white.

## [2.2.5] - 2026-11-15

- **Longer Generated Titles Are Kept Instead of Discarded (Issue #101)**:
  - A generated title whose theme carried a plugin name, a file path or a long identifier used to be thrown away as a whole, so the session fell back to the clipped first message; the title now keeps its `✨ Type｜theme` shape and only the part that does not fit is trimmed;
  - The title still respects the host's byte budget, and the type prefix stays intact in every case, so a new session no longer loses its smart title when the subject happens to be long.

## [2.2.4] - 2026-11-15

- **Section Headers Stay Pinned While Scrolling (Issue #100)**:
  - Scrolling the sidebar list no longer pushes the current section header (Pinned, Projects or a custom section) out of view: the header of the section you are reading sticks to the top of the list and hands the spot over to the next section as it comes up;
  - Section headers no longer disappear together with the workspace rows, so it stays clear which group the visible rows belong to.

## [2.2.3] - 2026-11-14

- **Custom Workspace Section Reordering via Actions Menu (Issue #99)**:
  - Added "Move up" and "Move down" actions to the `···` more actions menu on custom section headers, enabling easy manual reordering of workspace sections;
  - Boundary positions are handled automatically (topmost custom sections omit "Move up", and bottommost custom sections omit "Move down");
  - Moving a section immediately updates the visual layout and automatically synchronizes the physical order of enclosed workspaces in the host tree, persisting across restarts.

## [2.2.2] - 2026-11-14

- **Dedicated Model Selection & Automatic Low Reasoning for Prediction (Issue #98)**:
  - Added a "Prediction model" selector in Settings → Codex UI → Composer Enhancements, matching the single-field experience of the native chat interface;
  - Follows the active conversation's model by default, with the ability to choose any enabled fast model for completions to significantly reduce latency and token consumption;
  - Supports choosing reasoning effort levels for reasoning-capable models, automatically defaulting to the lowest available effort to avoid full-depth thinking during inline typing completions.
- **Fixed Prediction Route & Configuration Passthrough (Issue #98)**:
  - Fixed an issue where model routing, token bounds, and timeout options specified in Profile configs (`cordis.patch.yml`) were not applied to the prediction engine.

## [2.2.1] - 2026-11-13

- **Sidebar New Session & Navigation Visibility Fix (Issue #96)**: Fixed an issue where the "New Session" button and custom sidebar navigation items (Tasks, Channels, Scheduled, etc.) disappeared and left a blank area on DeepSeek Harness `0.2.2-rc.3`; added fallback safeguards to ensure native sidebar controls remain visible and functional in all conditions.
- **Host Compatibility & Support Matrix Alignment**: Verified full compatibility with DeepSeek Harness `0.2.2-rc.3` (covering all `0.2.x` RC hosts from `0.2.0-rc.1` through `0.2.2-rc.3`), aligned development dependencies with `0.2.2-rc.3`, and updated verified host lists across all documentation.

## [2.2.0] - 2026-11-13

- **Mobile Web & Touch Experience Upgrade (PR #93)**:
  - **Visual Viewport & Keyboard Panning**: On mobile browsers, the composer and trigger menus dynamically pan above the software keyboard, keeping active drafts comfortably visible; input font sizes scale to 16px to prevent iOS Safari from unwanted auto-zooming.
  - **44px Touch Targets**: Sidebar session actions, workspace buttons, search clear controls, and popup menu items adopt standard 44px touch targets for effortless fingertip tapping.
  - **Horizontal Tabs Settings Layout**: In narrow screens, the fullscreen settings modal transforms its left vertical navigation into a sleek top horizontal scrolling tab bar with full-width options, eliminating horizontal overflow and cramped columns.
- **Unified Settings Header & Action Alignment**: Standardized the About section title to 24px and aligned GitHub and feedback button layouts across all devices, removing redundant version labels.

## [2.1.1] - 2026-11-12

- **Compatibility & Dependencies**: Verified full compatibility with DeepSeek Harness `0.2.2-rc.2` (covering all `0.2.x` RC hosts from `0.2.0-rc.1` through `0.2.2-rc.2`), aligned development dependencies with `0.2.2-rc.2` and Cordis `4.1.0`, and updated verified host lists across all README manuals.

## [2.1.0] - 2026-11-12

- **Conversation-Scoped Input History by Default with Workspace Toggle (PR #91)**: `↑` / `↓` input history now defaults to **This conversation**, keeping prompt history cleanly separated between conversations. If you prefer sharing history across every conversation in the same directory, switch **History scope** back to **Workspace** in **Settings → Codex UI → Composer Enhancements** (existing workspace history remains preserved and becomes visible again when switching back, provided it has not been evicted by the 100-scope retention limit). Also fixed an issue where reloading could drop stored history beyond 20 scopes.
- **Direct "Add Workspace" Shortcut on Sidebar Section Headers (Issue #90)**: Added a host-native **Add workspace** icon button next to `···` on every sidebar section header (Pinned, Projects, and custom sections; revealed on hover or keyboard focus and shown automatically when the host directory-picking capability is available). Workspaces added from a section are automatically placed at the top of that section and expanded smoothly without shifting other sections.
- **Built-in "Cyberpunk" Theme Palette (14 Themes in Total)**: Added the **Cyberpunk** neon-green-on-black matrix terminal palette (bringing the built-in collection to 14 themes), complete with matching syntax highlighting and live Appearance code preview.

## [2.0.22] - 2026-11-11

- **Three-Way Input Prediction Control and Placeholder Overlap Fix (Issue #87)**: Upgraded prediction preferences to a 3-way segmented control supporting "Off", "Continue Only", and "Guess & Continue". In "Continue Only" mode, empty input boxes no longer show proactive question guesses, offering ghost completions solely while typing; completely fixed ghost text overlapping with native placeholder prompts when the input box is empty.
- **4 Classic Built-in Theme Palettes (13 Themes in Total)**:
  - **Claude Light & Dark**: Anthropic aesthetic featuring warm paper and warm evening backgrounds accented with terracotta clay;
  - **Dracula**: Vampire slate-purple background with vibrant cyber pink and cyan accents;
  - **Solarized Dark & Light**: Iconic deep teal dark background paired with classic parchment light tone;
  - **Gruvbox Dark & Light**: Vintage earthy dark brown and retro kraft paper light twins with warm gold accents.
- **Deep Syntax Highlighting Theme Adaptation with Live Code Preview**: Code syntax tokens now match the official color scales for all built-in themes. Added a real-time syntax highlighted code preview block directly in the Appearance settings card that updates immediately when switching themes.

## [2.0.21] - 2026-11-10

- **Native Companion Plugin Installation and Updates**: The About section's companion plugin list now delegates directly to host native plugin management, enabling seamless in-place installation, version upgrades, and batch synchronization for all companion extensions with real-time progress indicators.
- **Precise Diagnostic Feedback Across All 8 Languages**: When network timeouts, missing packages, or build blocks occur, error prompts clearly specify the underlying cause and actionable recommendations. Concurrent installation attempts and special plugin states present clear, localized guidance across all 8 supported languages.
- **Immediate State Synchronization During Batch Updates**: Batch update operations now immediately reflect installed extensions in the UI as they finish, ensuring completed updates are visible right away without requiring a page reload.

## [2.0.20] - 2026-11-09

- **Full Support for All 8 Official DeepSeek Harness Languages**: Seamlessly integrated with the official localization system, providing native translations for Chinese, English, Japanese, Spanish, French, German, Russian, and Portuguese (`zh`, `en`, `ja`, `es`, `fr`, `de`, `ru`, `pt`). All starter suggestions, fullscreen settings workbench, sidebar partitions, context menus, and desktop window controls adapt immediately when switching languages.
- **Multilingual Semantic Session Titles**: Auto-generated session titles now fully support all 8 official languages. Starting a conversation in Japanese, Russian, German, or other supported languages produces natural, consistent category tags and themes tailored to the selected language.

## [2.0.19] - 2026-11-05

- **Mark Sessions as Unread / Read from Row Menu**: Right-click any conversation row or open its action menu to toggle sessions between "Mark as unread" and "Mark as read". Marked unread conversations instantly restore native green status dots and update the sidebar unread counter badge; opening or remarking clears them cleanly. The action item is neatly placed directly after "Pin session" and works consistently across all host versions.

## [2.0.18] - 2026-11-05

- **Decoupled Composer Glass Layer to Prevent Decorative Skin Collisions (Issue #83)**: Migrated the composer card's frosted glass background and backdrop filters from the shared `[data-composer-card]::before` pseudo-element to a dedicated, scoped surface element (`[data-dcu-glass-composer-surface]`). When third-party skins use `::before` to draw expanded frames, borders, or ribbons outside the input box, the decorative layer is no longer contaminated with dark background tints or blur filters, completely eliminating unwanted frosted rectangles and text occlusion.

## [2.0.17] - 2026-11-04

### Compatibility & Dependencies

- Align with official DSH `0.2.2-rc.1` release; upgrade development dependencies to `0.2.2-rc.1`.
- Clean up obsolete alpha versions from the host compatibility matrix; support all `0.2.x` RC hosts (`0.2.0-rc.1` through `0.2.2-rc.1`).
- Update documentation badges and verified build ranges.


## 2.0.16 (2026-11-04)

- **Scoped Settings Sidebar Styles to Direct Children**: Restricted capsule navigation styles strictly to the direct left sidebar container of the settings workbench, completely preventing style bleed into the right-hand options content area. Third-party plugins with internal tabs or button navigations now preserve their native button dimensions and flex layout without being stretched to 100% full-width rows.
- **Added an inline-prediction switch**: a new "Composer Enhancements" card in settings toggles inline suggestions on and off. Turning it off takes effect immediately, clears the current ghost, and **issues no further requests at all**, so no model tokens are spent. `↑`/`↓` history recall, width handles, and starter suggestion cards are unaffected.
- **Added a site-level config flag**: a Profile can set `config.prediction: false` on `codex-ui-composer` in `cordis.patch.yml` to disable predictions wholesale. The Host then does not register the prediction routes (direct hits return 404), and the settings switch is locked off with an explanatory hint.

## 2.0.15 (2026-11-04)

- **Fixed Input Prediction & Inline Continuation Never Appearing**: The auxiliary model call was issued without a session id, so OpenCode-compatible gateways — which route on the `x-opencode-session` header — rejected every prediction request with `400 MissingSessionID` and no suggestion ever appeared at the caret. The owning session id is now forwarded with the prepared call, restoring the inline suggestion together with `Tab` acceptance, `Alt + ↓/↑` candidate cycling and `Esc` dismissal.

## 2.0.14 (2026-11-04)

- **Enhanced Sidebar Section Submenu Stability & Hover Transitions**: Resolved an issue where moving the pointer onto the "Partition" submenu could unexpectedly close the menu chain. Seamlessly supports hover transitions and click expansions across both expanded and collapsed sidebar states, ensuring the flyout menu layer always renders above sidebar rows without clipping.
- **Full Keyboard Accessibility for Flyout Menus**: Comprehensive keyboard navigation within the section flyout menu. Press `Home` / `End` to jump directly to the first and last menu items, navigate with `Up` / `Down` arrow keys without focus escaping back to the parent menu, and press `Escape` to cleanly dismiss and reset menu state.
- **Host-Native Menu Surface & Precision Anchor Matching**: Reused host-native glass materials and button primitives for the section flyout menu, aligning 100% with native context menus; accurately detects row action triggers and prevents misplaced menu anchors on ungrouped rows.
- **Composer & Dock Mica Backdrop Masking Refinement**: Eliminated scroller mask conflicts to restore glass backdrop blurring across the bottom of the transcript. Solidified the composer card and dock surface to stop ghost text leakage when scrolling long sessions, and scoped the bottom blur mask strictly to the centered dock area.
- **Adaptive Multi-Host Settings Layout & Icon Alignment**: Seamlessly adapted settings layout across different host generations, standardizing the left rail to 280px and centering options cards at 800px max width without stretched horizontal layouts. Enhanced icon slot detection to prevent missing or duplicate navigation icons.

## 2.0.13 (2026-11-03)

- **Smart Input Prediction & Inline Continuation**: Automatically displays high-confidence follow-up suggestions directly behind the caret when pausing mid-draft; press `Tab` to accept seamlessly without re-typing.
- **Effortless Candidate Cycling**: Press `Alt + Down` / `Alt + Up` to cycle through multiple predictive recommendations, or press `Escape` anytime to dismiss.
- **Turn-Aware Activity Gating**: Automatically pauses suggestions while the agent is running or executing tools to prevent distractions, instantly resuming smart recommendations once the turn settles.
- **Universal Model Compatibility & Clean Insertion**: Intelligently adapts across diverse conversation models, stripping duplicate draft prefixes upon acceptance to deliver clean, natural prompt continuations.

## 2.0.12 (2026-11-02)

- **Add Desktop App Titlebar Menu**: Injected a clean "Help" menu into the official Windows desktop titlebar, providing instant page reload and seamless application restart capabilities.
- **Reliable App & Host Restart Engine**: Resolved the Windows issue where closing the desktop app only minimized it to the system tray without exiting, cleanly terminating the old instance and relaunching cleanly with live progress toast feedback.
- **Full WAI-ARIA Accessible Keyboard Navigation**: Comprehensive keyboard support across menubar buttons with seamless arrow-key roving tab loops and accurate focus restoration upon pressing Escape.
- **Complete Sub-Plugin Metadata & Feature Descriptions**: Displayed localized names and descriptions for "Codex Desktop Menu" in the DSH plugin manager, aligning feature summaries across the About workbench.

## 2.0.11 (2026-11-01)

- **Decouple plain flat settings mode from mica float mode**: When mica glass is disabled, the settings modal (both expanded and collapsed) renders with seamless flat backgrounds, aligning perfectly with the home view and eliminating redundant margins, border-radius, and shadows.
- **Eliminate duplicate top bars and parallel curved borders**: Integrated standalone about header and actions into the first feature card header, and made the host titlebar borderless and transparent, resolving button overlap and dual parallel border strokes.
- **Normalize vertical card offsets across host architectures**: Handled both tiled Grid host (0.2.2-alpha.2+) and legacy nested Flex host (0.2.1-rc.5) geometries, harmonizing the first card baseline (y=84px) in collapsed mode and eliminating stray divider lines inside the 56px icon rail.
- **Auto-hide empty pinned section in sidebar (#76)**: Automatically hide the pinned header when no workspaces are pinned, and reset collapsed state when all workspaces are removed.

## 2.0.10 (2026-11-01)

- **Align Collapsed Settings Sidebar with Homepage 56px Icon Rail**: Replicate the host homepage collapsed sidebar design language inside the settings modal. Replace the cramped narrow view with a clean 56px floating Mica icon rail, centering icons along the vertical axis with hidden scrollbars and seamlessly integrating the back button.
- **Fix Mobile and Narrow Viewport Settings Distortion**: Adapt settings layout across responsive viewports (<=768px), eliminating character-wrapping and horizontal tearing while restoring comfortable spacing across form controls and theme segmented pickers.
- **Pure Generic Single-Icon Rule for Third-Party Plugins**: Eliminate duplicate icon collisions (custom icon + host fallback gear) in collapsed state by isolating text labels and respecting plugin-native icon visibility without hardcoding plugin attributes.
- **Fix Settings Header Alignment in Grid Layouts**: Align the absolute settings header with the options card container across host grid variations, removing the 80px horizontal gap and preventing nested double frosted cards.
- **Eliminate Nested Rightbar Backdrop Filter in Glass Mode**: Remove redundant background blur from the right sidebar container in compatible glass layout, preventing background bleed-through when expanding and collapsing panels.

## 2.0.9 (2026-10-31)

- **Fix Conversation Blank Screen on Model Switch (#74)**: Resolved an issue where switching models on a new conversation welcome screen crashed the conversation view into a permanent blank screen. Safely delegate suggestion card lifecycle to React portal unmounting rather than directly removing the DOM node.

## 2.0.8 (2026-10-31)

- **Align Sidebar Menu Item Cursor Interaction (#73)**: Removed the default `grab` hand cursor on draggable sidebar items to match the host application's standard click pointer (`pointer`), displaying the grabbing cursor only during active drag-and-drop reordering.

## 2.0.7 (2026-10-31)

- **Fix Slash Command Palette Ghost Text Transparency (#72)**: Enhanced surface opacity to 88% and applied 24px backdrop blur to the slash trigger command palette (`[data-trigger-menu]`), eliminating overlapping ghost text and visual clutter when selecting commands over long conversation text.
- **Restore Glassmorphism Master Switch**: Restored the master toggle for "Glassmorphism & Mica" in Appearance Settings, allowing users to fold all frosted glass decorations and cleanly fall back to native solid colors when preferred.

## 2.0.6 (2026-10-30)

- **Workspace Pinning and Custom Sections (#70)**:
  - Add "Pin" and "Section" options to the workspace context menu, allowing you to keep key projects at the top of the sidebar or organize them into custom sections;
  - Support creating, renaming, and removing custom sections directly from section headers;
  - Fully preserve native drag-and-drop reordering within each section.

## 2.0.5 (2026-10-29)

- **Fix Chat History Bleeding Through Composer (#69)**: Restore an opaque ground-aligned occlusion base and smooth top fade for the composer seat in glass and mica modes, eliminating text overlap and visual clutter where scrolled messages bled through the input card and status dock, while ensuring the last message remains fully legible when scrolled to the bottom.
- **Eliminate Scrolled Content Bleeding Under Floating Mica Header**: Prevent conversation messages and pills from bleeding through the floating header, top margin, and rounded corners during scroll, gracefully fading out overlapped content while keeping the header's native border, drop shadow, and frosted glass texture intact.

## 2.0.4 (2026-10-29)

- **Support Latest Host Versions**: Expand the host support matrix to officially support DeepSeek Harness latest RC (`0.2.1-rc.4`) and alpha (`0.2.2-alpha.2`).
- **Fix Settings Layout Fragmentation (#68)**: Adapt to the latest host settings structure, eliminating horizontal multi-column tearing, content width overflow, and title overlap to restore clean two-column layout and header bar.
- **Protect Theme Preferences & Dark Mode**: Prevent the UI from inadvertently reverting to a white/light theme when disabling theme enhancements or switching to default under "Follow System (Dark)" or custom dark palettes.
- **Eliminate Settings Modal Resize Flicker**: Ensure settings skin does not cause modal expand/shrink resize flickers when the skin is disabled.
- **Refine Visual Details & Layout Polishing**:
  - Fix float mode right header alignment with content cards;
  - Remove dirty gray smudges behind composer bottom stats pills;
  - Restore trajectory view to full-bleed width in mica mode;
  - Eliminate the sticky header color seam in the plugin manager.

## 2.0.3 (2026-10-28)

- **Support iOS Safe Area Insets and Mobile Layout**: Introduce W3C standard `env(safe-area-inset-*)` safe-area padding into mobile settings skin overrides (`@media (max-width: 640px)`) and enforce single-column layout priorities. This eliminates the collision where the "← Back to app" button was covered by iPhone notches and the Dynamic Island (#61).

## 2.0.2 (2026-10-28)

- **Fix Modal Overlay Selector Pollution**: Scope the fullscreen settings workbench overlay selector to target only the settings panel's own presentation layer. This eliminates CSS bleed where quota queries, confirmation dialogs, and other modal windows were inadvertently stretched and pinned to the top-left corner while settings were open.
- **Tolerate CI Virtualization in Theme Perf Regression**: Relax the consecutive theme switch timeout budget to 1000ms to eliminate false positive failures caused by shared VM CPU jitter.
- **Optimize Documentation Screenshots**: Compress and streamline live captures across light and dark themes, reducing visual asset footprint by 52% for faster README and registry loads.

## 2.0.0 (2026-10-28)

- **Architecture Rebuilt**: Codex UI is officially upgraded into a modular multi-subplugin architecture, structured into 6 core modules: `composer` (input enhancement), `settings-skin` (settings skin), `session-title` (smart conversation titles), `sidebar` (modular sidebar), `theme` (themes and mica skinning), and `dependencies` (ecosystem plugin management).
- **Native Mica & Palette Rectification**: Restores authentic Codex tech-blue and monochrome palettes by eliminating green tints; supports Stock and Mica layout modes, introduces independent ground-glow switch, and enables glass by default for new installs.
- **Native 56px Collapsed Rail**: Strictly falls back to the host's native 56px icon rail during sidebar collapse, preserving official tooltips and high-contrast new session indicators.
- **Redesigned About & Settings View**: Aligns header layout with companion plugin standards, introducing a structured sub-plugin capability list and a unified three-card section layout.

## 1.1.49 (2026-10-24)

- Upgrade host admission policy: Declare `engines.dsh: ">=0.2.0-rc.1 <0.3.0-0"` to support the entire DeepSeek Harness `0.2.x` line (including `0.2.0-rc.1` onwards, future alphas, RCs, and stable releases) without requiring routine plugin version bumps.
- Decouple peerDependencies locks: Broaden all `@deepseek-ai/dsh-*` peer dependencies to the `0.2.x` generation range.
- Upgrade build-time development dependencies: Synchronize all `@deepseek-ai/dsh-*` devDependencies to latest `0.2.1-rc.3`.

## 1.1.48 (2026-10-24)

- Support DeepSeek Harness `0.2.1-rc.3` while retaining all existing supported versions.

## 1.1.47 (2026-10-22)

- Prevent interaction lockup during sidebar collapse by removing blocking `pointer-events: none` and settling state on `transitionend` with a timeout fallback (#57).
- Support async `startSession` return handling and add a pending state guard to prevent silent no-ops when host RPC is busy during streaming (#57).
- Optimize streaming performance: lazily mount and subscribe search store snapshots only when the search modal is open, wrap `SessionRow` and `GroupHead` in `React.memo` to isolate tree item re-renders, and throttle tool menu DOM geometry syncs into animation frames (#57).

## 1.1.46 (2026-10-21)

- Restore window dragging on the Settings page in the Windows desktop app: the full-screen Settings overlay now reserves the native caption band and declares it as a drag region again (#56).
- Paint that band with the host's own `--dsw-specific-sidebar-fill` (the token the desktop app uses for the native title bar), so the caption stays one continuous colour across both columns instead of breaking into sidebar/content/native strips.
- Move the Settings navigation below the native window buttons on Windows, so Back and Search no longer sit in the same band as the minimize/maximize/close controls.
- Keep the Windows desktop menu (Application/Edit) visible on the Settings page and align it to the left edge while the session navigation arrows remain exclusive to the main workspace. Hide the desktop menu in fullscreen mode to prevent overlap, and include its items in keyboard Tab navigation.
- Extend the drag-region browser regression to cover the Windows caption, fullscreen, and hosts without a titlebar.

## 1.1.45 (2026-10-20)

- Restore macOS window-drag regions in the sidebar header and the top safe area of Settings, while keeping buttons and inputs interactive (#46).
- Remove the full-window no-drag region applied to the Settings overlay by the host. Add browser regression coverage for the drag-region styles, fullscreen transitions, and other platforms. Native macOS window movement has not been tested on hardware.

## 1.1.44 (2026-10-20)

- Keep the settings navigation's Back and Search controls visible while the section list scrolls (#53).
- Prevent client initialization from failing when mirrored slot registrations have no component (#54).
- Keep the collapsed-sidebar conversation header clear of macOS window controls and prevent title controls and tabs from overflowing in narrow columns (#55).

## 1.1.43 (2026-10-19)

- Guard archived and released session references before opening, so clicking an archived conversation no longer blanks the renderer or triggers a reload loop. Archived deep links are cleaned up before they can be retried.
- Forward the official `plugins.tab` and `plugins.add.actions` slots so the plugin market's Discover page and add-plugin actions render in the copied Plugin manager section.
- Render settings navigation icons with standalone mask elements instead of rewriting the host svg, and only decorate buttons with a direct host icon.
- Add icons and shorter labels to the schedule view tabs.
- Remove the injected navigation icon stylesheet when the observer is disposed.

## 1.1.42 (2026-10-18)

- **Support DSH 0.2.1-rc.2**: Adapt to the latest official DeepSeek Harness host, pinning dev dependencies to `0.2.1-rc.2` and Cordis to `4.0.5`.
- **Drop obsolete pre-0.2.0 & alpha hosts**: Align with in-house plugin standards, dropping 0.1.x and alpha versions, focusing on DSH `0.2.0-rc.1`, `0.2.0-rc.2`, `0.2.1-rc.1`, and `0.2.1-rc.2`.
- **Clean legacy compat shims**: Remove 0.1.5 onboarding settings schema fallbacks and `settingsScope` branches.
- **Plugin Manager navigation in sidebar**: Clicking the plugin entry in the sidebar now opens the official Plugin Management section in Settings directly instead of taking over the main workspace.
- **Sidebar SegmentedTabs unification**: Unify both primary (Tasks/Channels/Schedule) and secondary (Runs/Overview) tabs to official `SegmentedTabs` with transparent containers and subtle pill indicators; resolve tablist suppression bugs.
- **About page alignment**: Adopt standard trio actions (GitHub, Feedback, Check Updates) and aligned typography.

[简体中文](CHANGELOG.zh-CN.md)

This changelog records recent releases of DSH Codex UI. Earlier changes remain available in the [Git history](https://github.com/MichengAI/dsh-codex-ui/commits/main).

## 1.1.41 - 2026-10-17

- Support DSH `0.2.1-rc.1` and `0.2.1-rc.2` while retaining all existing supported versions. Development dependencies are pinned to host `0.2.1-rc.2`.
- The sidebar Extensions plugin entry is now Plugin manager and opens the official plugin manager instead of the plugin market.
- The settings entry formerly called Plugin configuration is now Plugin manager. Built-in plugins remains the read-only list.

## 1.1.40 - 2026-10-15

- The Tasks tab shows workspace projects again. Channel conversations stay on the Channels tab.
- Settings keeps a stable section order: Account, General; Models, Agent presets, Built-in plugins, Plugin configuration, Experts, Skills, Pet, Connectors, Scheduled tasks, IM assistant; Archive, About. Unknown sections follow the known items in the same group.

## 1.1.39 - 2026-10-15

- Plugin sidebar panels now appear inside Extensions, after Experts, Skills, Plugins, Connectors, Scheduled tasks, and the IM assistant. They keep each plugin's own order, including on the compact rail. Unknown panels are no longer dropped, and they no longer sit above New task (#44).
- The footer still skips dsh-context's old `context-overview` button. The per-session Context tab is unchanged. The official Plugins panel stays hidden because Extensions already has Plugins. Context Insights from dsh-context 0.64.0 or newer shows up in Extensions.

## 1.1.38 - 2026-10-15

- Support DSH `0.2.1-alpha.3` while retaining all existing supported versions; pin development `@deepseek-ai/dsh*` dependencies to host `0.2.1-alpha.3` and Cordis to `4.0.5-alpha.2`.

## 1.1.37 - 2026-10-13

- Add an Add workspace button to the Projects header, reusing the official directory picker and shortcuts (#42).
- Restore the official sidebar, settings, and automatic titles when Codex UI is disabled; handle repeated toggles and delayed official UI loading without conflicting shared slots (#42).
- Improve automatic session-title generation and recovery, and remove the routine provider-takeover warning.
- Restore standard context-menu text size, use an opaque global-search background, and correct the Connectors settings order.
- Document that Codex UI and `ds-bot` are mutually exclusive full-interface skins (#43).

## 1.1.36 - 2026-10-13

- Restored the "Show Code Workspace" (`developerTools`) setting toggle in General Settings and aligned its Switch control with native specifications (#41).
- Maintained a compact single-line layout for the conversation header when "Show Code Workspace" is disabled (single view without inline tabs).

## 1.1.35 - 2026-10-12

- Support DSH `0.2.1-alpha.2` while retaining all existing supported versions.

## 1.1.34 - 2026-10-10

- Enabling official Automation tasks no longer adds an extra Tasks item above New task (#39).
- Automation tasks, Scheduled tasks, and the IM assistant now sit inside Extensions. Extensions start collapsed, and each item keeps its icon.

## 1.1.33 - 2026-10-08

- Discord and Slack groups in the sidebar now show their brand marks instead of a gray placeholder.

## 1.1.32 - 2026-10-08

- Creating a session from the sidebar returns to the Tasks tab first. This covers a new task, search, and adding a workspace, so Channels and Schedule no longer stay selected.

## 1.1.31 - 2026-10-08

- On macOS, the main sidebar stays below the traffic lights in a normal window, including the brand, search, collapse controls, and the compact rail (#38). Fullscreen, Windows, and the browser are unchanged.

## 1.1.30 - 2026-10-07

- On macOS, the settings Back button and search stay below the traffic lights in a normal window (#37). Fullscreen, Windows, and the browser are unchanged.
- The Model Pro settings page uses the available column width instead of the 864px reading width. Other settings pages stay the same. Model Pro's own cards still have a width limit until that plugin is updated.

## 1.1.29 - 2026-10-06

- Account-launcher settings navigation reports missing sections immediately, supports late launcher registration, and reads Settings shortcut hints when the shortcuts service becomes ready.
- Desktop settings shortcuts open the requested section directly while keeping the official account launcher. Closing Settings restores keyboard focus.
- Installing from GitHub now includes the compiled runtime, so no manual build is required.
- The installed-plugin list shows “Codex UI” and a localized description instead of only the package name. The session-title component shows “Codex session titles”. Titles and descriptions come from `meta.title` and `meta.description` in `locale/zh.json`, `locale/en.json`, and `locale/session-title/`.
- Desktop keeps the official avatar and sign-in control at the bottom of the sidebar. Web still uses the plugin settings button when that account launcher is absent.
- While this plugin is installed, the patch disables official `ui-sidebar` and `ui-settings-general` so Desktop 0.2 does not fail activation on duplicate child slots. Disabling or uninstalling drops those rows with the bundle and restores the official shells. Official `session-title-llm` stays disabled while this plugin is composed, because the host accepts only one title provider. Remove leftover `disabled: true` rows for those ids from the profile `cordis.patch.yml`, then reload.
- Disabling or uninstalling restores the host sidebar column width. The official sidebar is no longer left at 240px, and the plugin removes its width variables and conversation-header style.

## 1.1.28 - 2026-10-05

- Restore the official session-search and add-workspace shortcuts when Codex replaces the workspace sidebar (#35). Preserve command IDs and custom key bindings, reuse the host directory picker, and keep both actions available in the collapsed rail.
- Keep the same 56px icon rail on Desktop and Web when the sidebar collapses, with back/forward session navigation in the Windows caption instead of duplicate sidebar/new-task controls.

## 1.1.27 - 2026-10-05

- Retain glass styling for the wallpaper plugin. The wallpaper plugin enables and configures this effect; it does not activate independently in Codex UI.
- Match the settings navigation width to the expanded main sidebar, including after resizing the sidebar.
- Align the sidebar and conversation header on a shared 34px control band. Use a 28px expand button at the top of the compact rail, retaining its center alignment during collapse transitions and keeping other rail navigation buttons at 36px.
- Fix the missing expand button after collapsing the desktop sidebar (#34). Windows retains a titlebar entry through the host overlay, and macOS uses the host window leading slot. Both work on settings pages while preserving the Web icon rail.
- Supply the required unique ID for the window overlay registration to prevent client activation failure. Add startup and disposal checks using the real host slot registry.

## 1.1.26 - 2026-10-04

- Fix the invisible send arrow when wallpapers or skins make surface color tokens transparent. Preserve the Codex monochrome style: black with a white arrow in light mode, white with a dark arrow in dark mode, with matching hover states.
- Add send-button regression checks for light/dark themes and skin color-token overrides.

## 1.1.25 - 2026-09-30

- Official Desktop no longer fails to start when an old `dsh-client-ui-settings-general` package remains above the profile. The plugin no longer imports that package by name.

## 1.1.24 - 2026-09-30

- About-page installs on official Desktop now use the host's bundled pnpm instead of launching the dsh command inside the app archive.
- Host support includes DSH `0.2.0-rc.2`. The sidebar, layout, and slot contracts match `0.2.0-rc.1`; without this declaration the new Desktop disables the plugin. Development dependencies are pinned to `0.2.0-rc.2`.

## 1.1.23 - 2026-09-29

- Installing or updating other plugins from the About page in official DeepSeek Harness Desktop no longer crashes the desktop host.
- Those installs are written to the current desktop profile. Restart the app once afterward so the new plugin can load.

## 1.1.22 - 2026-09-29

- Host support now starts at DSH `0.1.2-rc.1` and lists every release candidate through `0.2.0-rc.1`: `0.1.2-rc.1`, `0.1.5-rc.1`, `0.1.5-rc.2`, `0.1.5-rc.3`, `0.1.7-rc.1`, `0.1.7-rc.2`, and `0.2.0-rc.1`. This adds the previously missing `0.1.5-rc.3` and matches the other first-party plugins; `0.1.0-rc.8` and `0.1.1-rc.2` are no longer declared.
- Development dependencies are pinned to DSH `0.2.0-rc.1`, so the plugin installs on the newest release candidate instead of being disabled by the host compatibility check.
- Dropped the abandoned `@deepseek-ai/dsh-client-runtime` development dependency. The settings lifecycle spec now mounts the production `SlotRegistry` from the official `@deepseek-ai/dsh-client-ui-renderer/client` bundle, so the package is gone from peers, client inject, and tests alike.

## 1.1.21 - 2026-09-27

- Updating or installing on DSH `0.1.7-rc.2` is no longer rejected by the compatibility check.

## 1.1.20 - 2026-09-27

- Opening Plugin configuration in Settings no longer removes that sidebar item, and the official plugin manager page opens.

## 1.1.19 - 2026-09-27

- Lists supported DSH release candidates explicitly, including `0.1.7-rc.2`.

## 1.1.18 - 2026-09-25

- Aligns development and documentation with the current DSH `0.1.7-rc.2`. Installation requirements are unchanged.

## 1.1.17 - 2026-09-24

- Adds support for DSH `0.1.7-rc.1` and no longer includes `0.1.6-alpha`.
- Settings no longer includes a billing panel. The billing button at the bottom of the sidebar opens the billing plugin's own window.

## 1.1.16 - 2026-09-22

- Follow the host `--dsw-font-family` in the sidebar, settings page, workspace tree, and composer filter instead of a hardcoded Inter stack.

## 1.1.15 - 2026-09-22

- Cap project session lists at 5 items like Codex Desktop. Show more reveals 10 more at a time, and collapsing the folder restores the 5-item window.
- Paint only the hovered session's after-line when the next insert anchor is folded.

## 1.1.14 - 2026-09-19

- Keep official header actions beside the session title and conversation tabs on the right. Long titles stay on one 34px row instead of wrapping the corner slot down.
- Settings isolation leaves official body-level plugin toasts visible and inside the focus trap. Only `body > [role=alert]` skips isolation.

## 1.1.13 - 2026-09-18

- Adapt sessions, settings, and connector prompts to DSH 0.1.6-alpha.2 dual-path hosts. Older hosts stay supported. Peer range now includes alpha.2.
- Settings keeps official Built-in plugins and adds Plugin configuration that forwards the official manager cards.
- Running and completion-unread indicators prefer host SessionStatus. A selected row still shows a user-toggled unread mark.
- Connector example prompts open a workspace once so they do not leave a leftover blank session.
- Pinned drop lines stay between rows and no longer shove the Projects heading down.

## 1.1.12 - 2026-09-17

- Session rows show compact relative time on the right (now, minutes, hours, days, weeks, months, years). Hover or the action menu yields to the archive shortcut; a pending label hides the inline time.
- Truncated session titles scroll on hover or when the menu is open. Reduced motion keeps the ellipsis.
- Relative times refresh every minute. Inline English uses now; hover cards use Just now.

## 1.1.11 - 2026-09-16

- Open the settings page (and usage statistics) through a `document.body` portal so a collapsed 56px rail cannot trap the overlay in a transform containing block.
- Skip the dsh-context `context-overview` footer action by slot id and render the remaining footer actions one by one. Usage statistics stays visible. Footer actions without an id are dropped. The per-session Context tab is unchanged.
- Pin a dragged project into an empty pinned section even when dragleave clears the insertion target.

## 1.1.10 - 2026-09-16

- Cold start registers session titles through a dedicated `@michengai/dsh-codex-ui/session-title` plugin after `sessionTitle` and `llm` are ready, and recycles the provider on unload.
- Type words follow the host settings locale. The theme follows the user message; a language mismatch falls back to the message text.
- Peer range now includes DSH `0.1.6-alpha.1`. Development dependencies are pinned to that host, except `dsh-client-runtime`, which stays on `0.1.1-rc.2`.

## 1.1.9 - 2026-09-16

- Session title type words follow the Chinese or English UI locale.
- Hide Delete conversation when archive delete is unavailable.
- Changing the current session expands its project folder or Recent.
- The workspace tree uses official open and closed folder glyphs, and the running indicator aligns with project titles.
- Moving a session to another project works on DSH 0.1.6. A missing artifact is reported as not found, and leftover generation files get their working directory rewritten.

## 1.1.8 - 2026-09-15

- After the first user message, new chats are titled once as emoji, type, and theme, for example `⚡ 优化｜批次文字显示`. Dates are not written.
- A manual rename is pinned by the host and later messages do not overwrite it.

## 1.1.7 - 2026-09-14

- Restore the billing plugin's native sidebar entry styles by removing Codex UI overrides for its card, icons, text, and expanded/collapsed appearance. Clicking the entry still opens the existing usage statistics settings page.

## 1.1.6 - 2026-09-14

- Fix the Web page freezing on initial load or refresh in a narrow window when the sidebar starts collapsed.

## 1.1.5 - 2026-09-14

- Click a plugin title or full package name on the About page to open its project homepage in a new tab; App Market opens its official website.

## 1.1.4 - 2026-09-14

- Manage companion plugins in Settings → About, with PUA, Code Review, and Codex Pet included in a consistent order.
- Show total npm downloads beside each plugin name using a compact icon and text.

## 1.1.3 - 2026-09-12

- With Pet 0.1.5 or later, keep the pet visible and accessible by mouse and keyboard on settings pages while other background content remains isolated.

## 1.1.2 - 2026-09-11

- Support attachment drafts and global panels in DSH 0.1.5-rc.1 / rc.2, fix prefill and history recall, and support compact-sidebar navigation and returning to existing conversations. Later release candidates still require separate validation.
- Preserve Codex menu styling with native adaptive widths, correct attachment spacing and left-side turn previews, and restore native message bubbles, Session log controls, and translations. Untranslated text on older hosts remains in English.
- Unify connector pages with a neutral palette while preserving warning and error colors, and align usage statistics with the standard 864px settings width.
- Hide archived channel conversations immediately and prevent stale polling responses from restoring them; failed archival keeps the conversation visible and shows an error.

## 1.1.1 - 2026-09-09

- Add Codex Pet below scheduled tasks in About, with version checks and installation/update actions.
- Enlarge the welcome logo to 46px and the headline to 34px.
- Hide descendants of isolated branches beneath transparent Desktop settings, preventing explicit `visibility:visible` rules from showing conversation text through the page. Restore normal visibility when settings close.
- Hide background portals explicitly isolated by settings, including those mounted under body, and restore their original isolation state on exit while preserving onboarding dialogs.

## 1.1.0 - 2026-09-09

- Update product screenshots and remove temporary design previews and QA records; settings exit checks now target an actual DSH host via `test:host`.

- Preserve billing failure feedback after a ready dashboard crashes, until the user retries.

- Embed the original billing component in a same-origin usage statistics frame, preserving its statistics and configuration behavior.
- Rework the new conversation page with centered branding and task suggestions above a separate bottom toolbar and composer, preserving drafts and footer metrics.
- Refine composer corners, shadows, spacing, and controls; unify settings headings and spacing, move the configuration action into General advanced settings, and fill host localization gaps.
- Add companion Desktop material support with an opaque browser fallback; full Desktop material combinations still require acceptance testing.
- Harden the production billing frame with post-handshake loading, immediate resource errors, separate panel and settings close semantics, and layered Escape and cross-frame Tab handling.
- Scope text translation observers to settings and menus and verify mirrored width constants against the host.
- Add draggable width handles to new conversations with shared width preferences and a 640px default; keep guide cards independent of composer resizing.
- Hide the task sidebar scrollbar while preserving scrolling, and fix downward Git menus and first-frame style changes.

## 1.0.0 - 2026-09-08

- Release 1.0.0, bringing project and conversation navigation, plugin entry points, and standalone settings together in a cohesive Codex-style experience.
- Fix flashing when returning to the app or pressing Escape; let menus handle Escape first and preserve the current settings form while filtering navigation.
- Upgrade notes: the standalone settings view requires the bundle patch that disables ui-settings-general. If an existing settings shell is detected, its entry is retained. Replacing client files alone is not a complete upgrade; reload DSH after upgrading. Existing business configuration and conversations require no migration.
- Fix global settings search, onboarding and keyboard focus isolation, Escape handling for hidden dialogs, and configuration-file error feedback; retain the host settings shell when it is already active.
- Replace the settings dialog with a Codex-style standalone view, category search, grouped preferences, and focus restoration when returning to the app.
- Fix duplicate settings-shell registration, settings entry alignment and transitions, search focus, repeated headings, and content spacing.
- Give the plugin marketplace and side cards distinct store and sidebar-layout icons instead of the generic box.
- Preserve host configuration, onboarding, connection recovery, and installed plugin functionality; community plugin internal styling remains outside this change.

## 0.2.113 - 2026-09-08

### Fixed

- Fixed Chinese text wrapping into vertical columns and misaligned menu and footer text while collapsing the sidebar.
- Restored sidebar expand and collapse transitions when used alongside `dsh-better-sidebar`, while preserving right-panel animations.
- Synchronized sidebar width and content fades, removed redundant width updates, and kept rapid toggling and dragging responsive.

## 0.2.112 - 2026-09-08

### Release automation

- Fixed Chromium installation steps in release workflows and added YAML structure and prerequisite validation.
- Installer releases now generate and commit bilingual CHANGELOG entries before extracting release notes; missing either language blocks publication.

### Breaking changes

- Removed the public `crossSiteRequest` export. Consumers must use the host connection’s `requestRejection()` contract. Business GET routes now require authentication, including loopback requests (401 when signed out); missing authentication services return 503. The old REST paths have no compatibility aliases. Requires `@deepseek-ai/dsh-client-connection >=0.1.2-rc.1` and Cordis `>=4.0.2`.

### Fixed

- Added localized 401/403/503 feedback for business requests and an explicit local-cache notice when workspace preferences cannot sync.
- Consolidated empty-chat padding and ignored stale invisible drop markers; conflicting distinct drop positions now emit a deduplicated diagnostic.

- Stopped applying custom-group spacing between projects in an ungrouped project list, keeping the empty-conversation label vertically centered between project rows.
- Centered empty-group text between adjacent group headers, accounting for the external group gap, and unified both empty-state labels at 13px/18px with the same muted color.
- Standardized the Chinese empty-conversation label to "暂无聊天".
- Aligned empty-group text with the group title without changing project or conversation indentation.
- Matched the Codex sidebar reorder marker's 8px hollow ring and 2px rounded stroke, extending the line toward its start and removing the ring-to-line gap.
- Unified group, project, and conversation reorder indicators around the midpoint between visible rows, including scrolling and collapsed content, instead of fixed offsets from wrapper elements.
- Added 4px below each project's conversation list, matching its top gap so the last conversation no longer touches the next project row; the spacing collapses with the list.
- Prevented the group reorder indicator above the first sidebar group from being clipped by the expanded Projects section.

### Changed

- Increased group labels to 14px/600 with 32px rows and 12px spacing; project folders now switch between equally sized open and closed icons according to expansion state.
- Strengthened sidebar groups with persistent disclosure indicators, medium-weight labels, subtle backgrounds, and spacing while preserving existing project and conversation indentation and row widths. Expansion uses the arrow state without resembling a selected conversation; improved group touch targets and keyboard focus styling.
- Moved Codex UI's business REST routes from `/api/michengai/codex-ui/*` to `/api/dsh-codex-ui/*`, aligning their naming with the Skills Manager and IM Connect business endpoints; the old routes are no longer registered. The host baseline now requires `@deepseek-ai/dsh-client-connection >=0.1.2-rc.1` and Cordis `>=4.0.2`.

### Security

- Delegated all five business REST routes to the DSH host's `requestRejection()` checks for trusted hosts, origins, and login cookies. Requests now fail closed when authentication is unavailable without blocking legitimate reverse-proxy origins through a loopback-only check.

### Tests

- Run Chromium layout checks in `pnpm test` and CI without screenshots, including exact tertiary colors and empty-state padding. Added cross-section drag cleanup and pinned-host-package trust-boundary regression coverage with login stubbed as authenticated.

- Added business-route registration and authentication regression coverage for the new and removed paths, 401, 403, unavailable authentication, unchanged request-header forwarding, and an external-origin write authorized by the host boundary.

## 0.2.111 - 2026-09-08

### Fixed

- Updated the channel sidebar to use `/api/dsh-im-connect/channels`, matching IM Connect `0.1.38` after removal of the old management endpoint.

## 0.2.110 - 2026-09-08

### Fixed

- Distinguished standalone DSH Web installation failures from Desktop errors, directing users to stop and restart the current Web host instead of quitting DSH Desktop.
- Added localized recovery guidance for locked plugin files, pnpm store conflicts, and otherwise unrecognized DSH Web installation failures.

### Tests

- Added regression coverage for Web-specific installer errors and their Simplified Chinese and English localization.

## 0.2.108 - 2026-09-07

- Added rename and delete actions to each custom workspace group; the Projects header now keeps only the create-group button. Renaming preserves group membership, ordering, and expansion.
- Aligned custom-group and Ungrouped counts, kept long names from crowding menu buttons, and improved keyboard focus recovery after renaming.
- Prevented IME confirmation from submitting new groups and kept rejected names from interfering with preference synchronization.
- Made case-insensitive name checks independent of system locale while preserving legacy stored group names and memberships.

## 0.2.107 - 2026-09-07

- Displayed the running Codex UI version beside the About title and aligned Channel and Schedule session-group layout with Tasks.
- Restricted dependency update requests to loopback same-origin callers and avoided redundant Desktop reload IPC while preserving independent Web reloads.
- Standardized the package contract on Node.js 22.19.0+ and pnpm 11.22.0.

## 0.2.106 — 2026-09-07

- Added Wallpaper Engine sidebar glass support while keeping settings and search dialogs correctly positioned and clickable.
- Integrated the billing plugin entry into the sidebar, aligning icon size, colors, typography, and spacing with Settings while preserving billing details and the collapsed entry.

## 0.2.105 — 2026-09-06

- Added Simplify directly below BTW on the About page, with version status, install, update, and bulk-update support.

## 0.2.104 — 2026-09-06

- Added input history: press Up/Down in an empty composer to recall previously sent text. Each project keeps its own history.
- Added BTW to the About page, with version information and install/update actions.
- Shortened the archive plugin label to "Archived conversations".

## 0.2.103 — 2026-09-04

### Fixed

- Limited conversation DOM processing to affected message roots during streaming updates, avoiding repeated full-document decoration scans.
- Corrected blank-language fallback, cyclic remote-error handling, workspace-preference response versioning, About-page refresh warnings, and connector marketplace probing compatibility.
- Hardened Suite Installer YAML build-policy normalization across indentation styles and rejected Windows command-expansion characters.
- Preserved existing third-party bundle order during Suite migration, expanded managed members at the prior Suite anchor, and rejected profiles with missing or reversed base/web prerequisites instead of silently rewriting them.

### Tests

- Added behavior coverage for cross-site dependency-route rejection, error redaction, localized refresh failures, connector probing, observer scope, cyclic errors, installer ordering, invalid bundle baselines, and Windows command quoting.

## 0.2.102 — 2026-09-03

### Added

- Added persistent, reorderable workspace groups with a collapsible ungrouped collection, while preserving the flat project list when no custom groups exist.
- Added Codex-style session and project menus, project-wide session archiving, and confirmed cross-project session moves that migrate the session working directory with rollback protection.
- Added Codex-aligned drag previews, exact insertion indicators, group ordering, project-to-group movement, and session movement between projects.
- Added GitHub and Issues actions to the Codex UI settings page.

### Changed

- Removed session pinning and kept project pinning as the single pinning model.
- Published runtime files from `lib` and aligned the client bundle contract with the current DSH module loader.
- Upgraded supported DSH development dependencies to `0.1.2-rc.1`; `dsh-client-runtime` remains on its highest published version, `0.1.1-rc.2`.

### Fixed

- Matched Codex sidebar spacing, typography, controls, hover cards, folder treatments, animations, and drag feedback across pinned, project, recent, channel, schedule, and extension sections.
- Stabilized sidebar resizing at a 240px minimum without persisting width, retained the 50% collapse threshold, and removed the initial resize animation and first-drag rebound.
- Hardened workspace-group hydration and persistence, host compatibility fallbacks, structured user-facing errors, unread state updates, and move rollback failure messaging.
- Completed Simplified Chinese and English coverage for the updated sidebar, menus, confirmations, errors, and settings actions.

## 0.2.101 — 2026-09-01

### Fixed

- Restored the host pending-interaction store as a fallback for workspace, channel, and scheduled-task trees when `SessionSummary.pendingInteraction` is absent, so approvals, questions, and plan reviews remain visible in Web and Desktop sidebars.
- Kept valid `SessionSummary.pendingInteraction` values authoritative while preserving a stable empty-store fallback for older hosts that do not inject the hook.

### Tests

- Added DOM integration coverage for all three trees using the real pending-interaction store path, alongside the existing `SessionSummary` snapshot coverage.

## 0.2.100 — 2026-09-01

### Fixed

- Added pending-interaction indicators to workspace, channel, and scheduled-task trees for questions, approvals, and plan reviews, with the warning state taking precedence over unread and running indicators.
- Aligned all three trees with the official `SessionSummary.pendingInteraction` contract, removed the unused host-store abstraction, and matched the official English status labels.
- Removed the package release-age guard from About-page companion installs and updates so explicitly requested versions can be installed immediately.

### Tests

- Added DOM rendering coverage for pending-interaction states in all three trees using fully typed `SessionListState` and `SessionSummary` snapshots.

## 0.2.99 — 2026-09-01

### Fixed

- Restored full rendering for user question bubbles in the main conversation body so long prompts are not hidden by overflow, max-height, or multi-line clamp rules.
- Kept the official DSH user bubble DOM intact while applying a stable compatibility marker to newly mounted user bubbles.

## 0.2.98 — 2026-09-01

### Fixed

- Kept the segmented conversation-tab slider aligned with the host-selected view by recognizing the tab list itself as a synchronization root, preventing the highlight from remaining on Chat after selecting Trace or Context.

## 0.2.97 — 2026-09-01

### Compatibility

- Adopted the official DSH alpha turn navigator while preserving the legacy navigator on older runtimes, with runtime capability gating and resilient left-side mirroring that no longer depends on private stylesheet names or host DOM nesting.
- Preserved upstream conversation width dragging, adaptive transcript sizing, and turn navigation while retaining the Codex composer treatment.

### Fixed

- Reworked About-page companion installs with live pnpm progress, accurate Profile mount verification, bulk installation of missing or outdated plugins, stale junction cleanup, and correct Desktop versus standalone Web restart guidance.
- Hardened pnpm discovery for GUI environments without trusting unrelated package-manager entry points or leaking the inferred entry into later child processes.
- Added strict progress payload validation and extended slow Desktop bundle reconciliation tolerance.
- Filtered and frame-coalesced navigator DOM observation so streaming responses do not trigger repeated document-wide scans.

## 0.2.96 — 2026-09-01

### Fixed

- Opened About immediately when the IM companion is not installed instead of showing General settings while waiting for a missing section to time out; the installed IM settings route is unchanged.
- Predeclared the nonessential `protobufjs` and `koffi` install scripts as disabled before About-page plugin installs, preventing pnpm's ignored-build placeholder from blocking an otherwise safe install.

## 0.2.95 — 2026-09-01

### Fixed

- Matched the sidebar background to the Host workspace background in both light and dark themes.
- Replaced the clipped white-tile WeCom channel icon with a compact multicolor brand mark that remains legible at sidebar size.

## 0.2.94 — 2026-08-30

### Safety

- Completed symmetric validation of the public Desktop services: if either `desktopProfiles` or `desktopPnpm` is exposed without the other, dependency management now fails safely instead of falling back to an ambient CLI that could mutate another profile.

## 0.2.93 — 2026-08-30

### Compatibility

- Resolved the active DSH Desktop profile through the public `desktopProfiles` service and delegated installs and updates to the public `desktopPnpm` package manager instead of hard-coding the `web` profile.
- Preserved the ordinary Web/CLI profile fallback while recognizing Desktop-provided runtime and companion-package state across restarts.
- Routed new-session actions through Archive Manager's optional `uiWorkspace.startSession()` service, with the standard workspace service retained as the fallback.

### Safety

- Removed the dependency on the launcher-private `desktopPnpmBootstrap` implementation detail.
- Failed safely when a Desktop generation exposes incomplete public services instead of falling back to an ambient CLI that could mutate another profile.
- Reported the running Desktop DSH runtime as installed without fabricating a version or update when the Host exposes no supported runtime path.

## 0.2.92 — 2026-08-28

### Security

- Updated the legacy Suite and its installer manifest to `@michengai/dsh-im-connect@0.1.26`.
- Pinned the workspace dependency graph to the compatible patched `ansi-regex@5.0.1`, resolving CVE-2021-3807 in both the Suite and test dependency paths.

## 0.2.91 — 2026-08-28

### Release process

- Replaced manual npm publication with tag-triggered GitHub Actions npm Trusted Publishing (OIDC).
- Added a full-test and tag/package-version gate before `npm publish`; npm credentials are no longer stored in the repository or Actions secrets.

## 0.2.90 — 2026-08-27

### Changed

- Matched the expandable sidebar to the installed Codex desktop client: 275px default width, 240px minimum, and 520px maximum, capped by available viewport width.
- Mapped the DSH host's narrower persisted drag range to the Codex visual range while preserving the 275px default anchor.

### Fixed

- Replaced the previous coordinate-based collapse gesture with Codex behavior: dragging below 240px collapses the sidebar.
- Prevented the DOM width adapter from reapplying its own mapped output during host drag and rerender cycles.

## 0.2.89 — 2026-08-27

### Added

- Persisted workspace, channel, and scheduled-task folder expansion independently across refreshes with versioned, failure-safe browser storage.
- Added scheduled-task list/overview switching, direct task-settings navigation, and group archive actions.
- Added Node.js 22/24 CI for pushes and pull requests, and made the tag Release workflow run the full test suite before creating a release.

### Fixed

- Stopped classifying ordinary conversations as scheduled tasks from an editable timestamp-shaped title; automation ownership now requires the stable session ID prefix.
- Made group archive continue after individual failures, clean local pin/unread state only for successful items, and leave failures selected for retry.
- Validated scheduled-task settings requests at runtime, guarded browser storage access, and extended lazy Settings navigation to four seconds.
- Restricted the Windows Explorer Host endpoint to exact registered workspace roots, rejecting drive roots, UNC paths, relative paths, children, and unrelated absolute paths.
- Reduced compatibility observer work by filtering unrelated conversation, permission, and Settings DOM mutations before scheduling scans.

### Release process

- Aligned the root package, lightweight installer, private legacy Suite snapshot, member pins, and version-contract assertions; the aggregate Suite remains retired.
- Corrected the installer command and executable name in local-verification help and READMEs, and added a build contract for the client bundle's static runtime modules.
- Tracked and refreshed the current handoff documentation under `docs/00-交接入口/` while leaving historical documentation ignored.
- Hardened the Windows installer against shell metacharacters in `DSH_BIN`.

## 0.2.88 — 2026-08-26

### Changed

- Replaced the lightweight **Settings → Connectors** tool list with the complete `dsh-mcp-connector` marketplace and connection manager whenever that optional external plugin is installed.
- Kept the existing **Connectors** home/sidebar action as the single entry point and suppressed the external plugin's separate launcher in both expanded and compact Codex sidebar layouts.
- Preserved the original current-session MCP tool directory as an automatic fallback when `dsh-mcp-connector` is absent or its Web UI is unavailable.

### Compatibility

- Added a same-origin, source-validated Prompt bridge that creates or reuses a workspace session and places the selected marketplace Prompt into its draft.
- Synchronized the embedded marketplace with the DSH-selected light or dark theme without modifying the externally maintained plugin or making it a required dependency.
- Updated the lightweight installer to pin Codex UI `0.2.88`; the legacy aggregate Suite remains private and unpublished.

Published packages: [`@michengai/dsh-codex-ui@0.2.88`](https://www.npmjs.com/package/@michengai/dsh-codex-ui/v/0.2.88).

## 0.2.87 — 2026-08-26

### Fixed

- Restored Chinese labels for the built-in permission presets in Settings and Chat with an exact-match compatibility adapter that leaves custom presets, prose, icons, and Host menu layout untouched.
- Made **Open in File Explorer** bypass in-app file previews, close its menu immediately, and open Windows Explorer in the foreground and maximized.
- Restyled conversation and workspace rename fields to match the native settings form, including helper copy, accessible labels, and a visible focus state.
- Kept the Codex UI **About** section at the bottom of Settings even when third-party plugins add later sections.

### Compatibility

- Updated the lightweight installer to pin Codex UI `0.2.87`, IM Connect `0.1.24`, and Automation `0.1.15`; the legacy aggregate Suite remains private and unpublished.

Published packages: [`@michengai/dsh-codex-ui@0.2.87`](https://www.npmjs.com/package/@michengai/dsh-codex-ui/v/0.2.87).

## 0.2.86 — 2026-08-25

### Changed

- Reworked **Conversation / Trajectory / Context** into a compact three-part segmented control while preserving the Host-managed tab DOM and behavior.
- Replaced the wide **Session log** capsule with an accessible 28 px download icon that retains its original text for assistive technology.
- Removed the conversation-header divider and placed all controls in a compact 34 px band with symmetric 3 px spacing.

### Compatibility

- Aligned the 28 px mode and utility controls with `DSH-better-sidebar` in both expanded and collapsed layouts without moving the external plugin's persistent buttons.
- Added regression coverage for stable DOM ownership, exact border-box sizing, accessible labels, and header spacing.
- Updated the lightweight installer to pin Codex UI `0.2.86`; the legacy aggregate Suite remains private and is not released.

Published packages: [`@michengai/dsh-codex-ui@0.2.86`](https://www.npmjs.com/package/@michengai/dsh-codex-ui/v/0.2.86).

## 0.2.85 — 2026-08-25

### Changed

- Removed the poorly performing `dsh-find-plugin` integration from **Settings → About → Companion management plugins**, including its status, install, and update entry points.
- Removed the related bilingual copy, README guidance, and regression assertions.

### Release process

- Made `@michengai/dsh-codex-suite-installer` the only supported one-click installation path. The legacy `@michengai/dsh-codex-suite` workspace package is now private and retained only as migration source; it will no longer be packed or released.

Published packages: [`@michengai/dsh-codex-ui@0.2.85`](https://www.npmjs.com/package/@michengai/dsh-codex-ui/v/0.2.85).

## 0.2.84 — 2026-08-25

### Added

- Added `dsh-find-plugin` to **Settings → About → Companion management plugins** as **Plugin Discovery**, with independent status checks, installation, updates, and **Update all** support.

### Documentation

- Clarified that `dshmarket` and `dsh-find-plugin` are optional standalone plugins outside the Suite and can be installed or updated separately from About.

Published packages: [`@michengai/dsh-codex-ui@0.2.84`](https://www.npmjs.com/package/@michengai/dsh-codex-ui/v/0.2.84).

## 0.2.83 — 2026-08-24

### Fixed

- Split the direct-member CLI into a dependency-free installer package so `npx` does not resolve the aggregate Suite's full DSH runtime tree before it can start.
- Kept `@michengai/dsh-codex-suite` as the compatibility package for the old `dsh plugin add` path, while all recommended commands now use `@michengai/dsh-codex-suite-installer`.

Published packages: [`@michengai/dsh-codex-ui@0.2.83`](https://www.npmjs.com/package/@michengai/dsh-codex-ui/v/0.2.83).

## 0.2.82 — 2026-08-24

### Fixed

- Replaced the Suite's recommended aggregate install with an installer that records all six members as direct profile dependencies, allowing **Settings → About** to detect and update each plugin independently.
- Made clean custom Web profiles reuse the same `DSH_HOME` while placing DSH's built-in `dsh-web-app` before the member bundles.
- When About encounters a legacy aggregate Suite, it now promotes all six members before removing the aggregate package instead of retaining only the clicked plugin.

## 0.2.81 — 2026-08-24

### Added

- Added an **Update all** action beside Companion management plugins whenever installed plugins have updates available.
- Kept missing plugins on their existing per-row install path instead of installing them implicitly during a bulk update.

### Reliability and accessibility

- Staged every selected package in one Host request and sent a single Desktop hot-update signal after the complete batch, so updating several plugins now reloads the window only once.
- Preserved individual install and update actions while preventing overlapping requests.
- Added visible loading feedback, keyboard focus treatment, accessible busy/status announcements, bilingual copy, and regression coverage for the batch selection and endpoint contract.

## 0.2.80 — 2026-08-23

### Documentation

- Added bilingual changelogs covering the five most recent UI releases.
- Linked the release history from both README editions and included it in the npm package.

## 0.2.79 — 2026-08-23

### Fixed

- Removed the delayed expanded state that could stretch compact navigation icons across an already-wide sidebar.
- Made expansion reveal the fixed-width wide layout immediately while the host column clips it during motion.
- Made collapse fade the wide layout for 140 ms before switching to the compact rail.
- Anchored the 56 px compact rail to the left so its icons no longer drift while the host column changes width.

### Performance and accessibility

- Kept the workspace tree at its target width during the host transition, avoiding per-frame list reflow or remounting.
- Preserved the reduced-motion path for users who disable interface motion.
- Added regression coverage for both collapse and re-expansion without workspace-tree rerenders.

## 0.2.78 — 2026-08-23

### Changed

- Restored the host sidebar-width transition after the performance hardening in `0.2.77`.
- Added compositor-only reveal motion for expanded and compact shells, search, and workspace sections.
- Kept the large workspace tree mounted while switching sidebar modes.

## 0.2.77 — 2026-08-23

### Added

- Persisted pinned workspaces in the DSH Host profile so they survive Desktop tray reloads and dynamic-port changes.
- Added safe client hydration, legacy local-storage migration, serialized writes, and protection against clearing pins from incomplete startup data.

### Fixed

- Improved workspace and session drag-and-drop reliability and drop-target handling.
- Isolated search state and deferred filtering so typing does not rerender the workspace tree.
- Kept the workspace slot mounted across compact and expanded sidebar modes.

Release commit: [`b96d5a8`](https://github.com/MichengAI/dsh-codex-ui/commit/b96d5a8).
