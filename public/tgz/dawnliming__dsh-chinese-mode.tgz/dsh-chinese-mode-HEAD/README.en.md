# dsh-chinese-mode

A global Simplified-Chinese mode plugin for DeepSeek Harness Web: a compact **Chinese Mode** pill beside the permission selector in the input box, which injects language requirements into the system prompt of **any preset** when enabled.

> Simplified Chinese is the default documentation language; this is the English translation.

## Features

- **Global and persistent**: the switch lives in host-side settings (the `dsh-chinese-mode` namespace) and applies to every session.
- **Unconditional injection**: injecting when enabled, with no "already has Chinese" detection; inserted before the persona.
- **Per-region language switches**: reply / thinking / tools can each be toggled — ON = Chinese, OFF = English (positive instructions, verified effective).
- **Settings page**: a "Chinese Mode" config page in dsh settings (master switch, region switches, anchored keywords & behavior). Wording is managed by built-in defaults to avoid polluting the system prompt via manual editing.
- **Input-box pill switch**: a compact persistent **Chinese Mode** control sits beside the input box; its label and micro switch remove the ambiguity of a single character. It uses a light-blue selected state, remains neutral when disabled, and can re-enable the feature in one click. Its visibility is independently configurable in settings.
- **Applies to any preset** (except the complete persona — a DSH mechanism limitation, see "How it works").
- **Anchored compatibility**: off by default; when enabled, anchored presets use English thinking after promotion while reply/tools follow the settings (the preset's tool-bootstrap handles anchoring on the first round and filters this section). When off, anchored presets are ignored and regular settings apply.
- **Removal on disable**: turning the master switch off removes the section from later assemblies; it never translates history or inserts visible chat content.

## Install

Install from the plugin marketplace, or via CLI:

```bash
dsh plugin --profile web add github:dawnliming/dsh-chinese-mode
```

Restart `dsh web`; the **Chinese Mode** pill beside the input box directly toggles language injection, and its visibility is controlled from settings.

## Settings

| Field | Default | Description |
| --- | --- | --- |
| `enabled` | `false` | Master switch; when off, nothing is injected and the input-box status key remains in its disabled state. |
| `showInputSwitch` | `true` | Whether to show the **Chinese Mode** pill beside the input box; independent from the master switch. |
| `replyChinese` | `true` | Reply language: ON = Chinese, OFF = English. |
| `thinkingChinese` | `true` | Thinking language: ON = Chinese, OFF = English. |
| `toolsChinese` | `true` | Tools/UI wording: ON = Chinese, OFF = English. |
| `textReply` / `textThinking` / `textTools` | per-region default Chinese wording | Built-in Chinese wording (English wording is built in as the OFF counterpart); not editable in the settings page to avoid pollution. |
| `anchoredPresetKeywords` | `liangshen, 梁神, anchored, 锚定` | Preset-name keywords treated as anchored mode (comma-separated; editable in the settings page). |
| `anchoredMode` | `false` | Off by default; when enabled, anchored presets get English thinking while reply/tools follow the settings. |

> A legacy single `text` field is kept as the reply wording after upgrade.

## How it works

The host half registers `dsh-chinese-mode:language` as a system-prompt section via the official `systemPrompt.section()` API (negative `order`, so it renders before the persona). Its `text` is a function evaluated per assembly: it returns an empty string when the master switch is off (dropped at render time). Anchored detection uses DSH `resolveSessionPreset(session)` to read the newest `agent-preset/selected` event rather than only the creation-time header, so a blank-session preset switch takes effect immediately. Anchored presets have the section stripped by their `tool-bootstrap` during phase 1 and restored after promotion, so the plugin is naturally anchor-compatible. **Limitation**: DSH force-restores a complete persona as the sole section after the waterfall, so this plugin does not apply to complete personas (a DSH mechanism limitation, not a plugin defect). The client half renders the **Chinese Mode** pill bound to the `dsh-chinese-mode` settings namespace.

## Development

- Host side: `lib/index.js`
- Client side: `lib/client.js` (ModuleLoader bundle, requires rebuild after edits)

To install the local checkout into a profile as a `file:` dependency:

```bash
cd ~/.dsh/profiles/web
pnpm add file:../../plugins/dsh-chinese-mode
# also add "dsh-chinese-mode" to dsh.profile.bundles in package.json (or let dsh reconcile)
```

## License

MIT
