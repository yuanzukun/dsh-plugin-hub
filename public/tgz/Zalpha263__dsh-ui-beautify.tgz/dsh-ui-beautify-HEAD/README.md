# dsh-ui-beautify

给 DSH 的 Web 界面换一套更顺眼的外观：配色预设、整页背景图。所有改动都存在浏览器本地，随时可以一键还原。

## 能做什么

- **配色预设**：内置四套（默认 / 深海蓝 / 暖沙 / 松石绿），浅色与深色各有适配。切换时不只是换背景和气泡，DSH 界面里的蓝色强调元素（文件夹图标、加载动画、标签高亮、链接等）也会一起换成预设色。
- **整页背景图**：上传一张本地图片，插件自动压缩到最长边 2560px 以内，并给上层文字加可读遮罩；侧边栏与主区都会显示。
- **随时还原**：配色与背景图存在浏览器 `localStorage`，刷新或重启 DSH 都会自动恢复；「重置全部」回到出厂状态，卸载插件后注入的样式会被移除。

## 使用说明

所有开关都在 **设置 → UI设置**：

| 区域 | 控件 | 作用 |
| --- | --- | --- |
| 外观美化 | 配色预设 | 一键切换整套配色；点「默认」还原 DSH 原生蓝 |
| 外观美化 | 选择图片 / 清除 | 上传本地图片作为全页背景，或移除背景图 |
| 外观美化 | 重置全部 | 恢复默认外观并清除已保存的设置 |

> 3.0.0 起移除了卡片布局引擎，所以「UI设置」里只剩外观美化，布局模式、恢复默认布局这类控件随之消失。

## 安装

要求：DSH `0.1.7` 系列或 `0.2.0` 系列（已在 `0.1.7-rc.2` 与 `0.2.0-rc.1` 上实测；本插件不声明 `peerDependencies`，宿主的兼容检查对没有该字段的插件直接放行，因此两个宿主都不存在「被静默跳过」的问题）与 [pnpm](https://pnpm.io/zh/)。

```bash
# 发布态：钉死提交，最稳定
dsh plugin --profile web add github:Zalpha263/dsh-ui-beautify#<40位commit>

# 开发态：裸目录路径 = link:（源码即部署，改完不用重装）
dsh plugin --profile web add D:/path/to/dsh-ui-beautify

# 升级与卸载
dsh plugin --profile web install
dsh plugin --profile web remove dsh-ui-beautify
```

装完**重启 DSH**，打开「设置 → UI设置」即可。改完源码只需刷新页面（本插件全部逻辑在浏览器侧，无构建步骤）。

**桌面版（DeepSeek Harness 桌面应用）**：`desktop` profile 由桌面应用独占，`dsh plugin --profile desktop ...` 会被 CLI 直接拒绝（`profile "desktop" is managed exclusively by the Electron application`）。请在桌面应用侧边栏的**插件**页里用**绝对路径**添加本插件目录（或 GitHub 仓库地址），装完重启应用生效。桌面应用自带 Node / pnpm 运行时并走应用内更新（不依赖 npm 全局安装），它的 DSH 版本可能与全局 CLI 不同（实测桌面 `0.2.0-rc.1`、全局 CLI `0.1.7-rc.2`），本插件对两者都通过兼容检查。

## 常见问题

| 问题 | 原因与解决 |
| --- | --- |
| 「设置」里没有「UI设置」 | 安装后没有重启 DSH；重启后再看 |
| 卡片布局 / 布局模式去哪了？ | 3.0.0 起整体移除：拖卡片要改写官方 AppFrame 的列宽，而那正是官方右侧栏申领的资源，两边互相覆盖就是过去「面板与侧边栏冲突」的根因 |
| `sidebarPanel` 服务去哪了？ | 4.0.0 起整体移除。插件面板本来就注册在**官方**右侧栏上（`sidebarRightTabs` + `sidebar.right.pane.tab`），中间那层适配只会造成「关掉本插件，别的插件就没右侧栏入口」。第三方插件请直接对接官方服务，见 `@deepseek-ai/dsh-client-ui-sidebar-right` 的 README「扩展席位」 |
| 换浏览器 / 清缓存后设置不见了 | 设置存在浏览器 `localStorage`，属预期行为 |
| 卸载后还有样式残留 | 先硬刷新（Ctrl+F5） |
| 其他插件热重载后界面异常 | 引擎会自动重新接管，最迟 1 秒恢复；仍异常请硬刷新并反馈 |

## 兼容性

面向 DSH `0.1.7` / `0.2.0` 系列的 Web 界面编写，**4.0.0 起不再触碰右侧栏**（面板注册服务已移除，本插件只做配色与背景图）。用户气泡走宿主 token `--dsw-specific-bubble`；只有会话发送按钮和侧边栏淡出层仍按客户端产物的哈希类名覆盖：`.uV2eYG_primary` 出自 `@deepseek-ai/dsh-client-ui-conversation` 的客户端产物，`.bhn1Oq_fade` 出自 `@deepseek-ai/dsh-client-ui-workspace` 的客户端产物。这两处**已实测**：在 `0.2.0-rc.1` 宿主上抓取 boot manifest 广告的全部 83 个客户端产物，两个类名均仍存在（产物 rev `cf69ca49decf` / `1a8f018dea37`），`--dsw-specific-bubble` 也仍在 `dsh-client-ui-theme` 产物中。**DSH 大版本升级后建议在「外观美化」里复核这两处**。背景图以压缩后的 data URL 存在 `localStorage`（约 5MB 配额内）。

## 开发者

单文件实现：Host 半区 `lib/index.js` 是空壳（仅用于注册），全部逻辑在 `lib/client.js`。这是手写的 `__ModuleLoader__.load` 格式、不是构建产物，改完刷新页面即可生效。调色板在 `PRESETS` 常量里；effect 只剩一个外观清理（CSS disposer + 背景图 + 设置恢复），不再有任何跨插件服务。

## 更新日志

### v4.0.0
- **破坏性变更：移除 `sidebarPanel` 服务与整套面板宿主机制** —— `registerPanel` / `has` / `openPanel` / `focusPanel` / `closePanel` / `isOpen`，面板正文的 CSS 契约（`.dsh-sidebar-panel-host` 与 `@container dshpanel`），标签类型绑定与重绑（`bindPanelToHost` / `syncPanels` / `panelSeatAlive` / `internal/service` 监听 + 1s 轮询），以及 `ctx.provide('sidebarPanel')`。
- 原因：这一层适配把「插件面板」和「ui-beautify 是否安装」绑在了一起 —— 关掉本插件，其他插件的面板就没有右侧栏入口。官方服务由 `@deepseek-ai/dsh-web-app` 的 `ui-sidebar-right` 行**始终提供**，中间层没有存在价值；消费方请改为直接调 `ctx.sidebarRightTabs.register({...})` + `ctx.slots.register({ name: 'sidebar.right.pane.tab', key: id }, Body)`。
- 本插件现在**只保留配色预设与整页背景图**：不再触碰右侧栏、不再提供任何跨插件服务。
- 删除文档：`docs/plugin-panel-integration.md`（`sidebarPanel` 契约）。

### v3.0.4
- **适配桌面版（文档级，无代码改动）**：本插件**不声明 `peerDependencies`**，而桌面版的兼容检查（`evaluatePluginCompatibility`）在没有该字段时直接返回 undefined → 两个宿主（web `0.1.7-rc.2`、桌面 `0.2.0-rc.1`）都通过，不存在「静默跳过」问题。
- 走廊核对（`0.1.7-rc.1 → 0.1.7-rc.2 → 0.2.0-rc.1`）：`theme` 服务的成员集未变（仅注入的 CSS 文本有增补，含 `html[data-platform=darwin]` 的桌面菜单色）；`slots.inject` / `slots.register` 未变；`sidebarRight` / `sidebarRightTabs` 的提供方 `dsh-client-ui-sidebar-right` 的 `lib/index.js` 逐字节相同、无公开成员被移除；本插件自提供的 `sidebarPanel` 插件间契约不受宿主影响。
- 哈希类名覆盖改为**实测取证**（先前草案里写的「本走廊内未失效」是错误措辞：走廊比对集只含 20 个包，而这两个类名所属的 `dsh-client-ui-conversation` / `dsh-client-ui-workspace` **不在其中**，无法从比对结果推断）：在 `0.2.0-rc.1` 宿主上抓取 boot manifest 广告的全部 83 个客户端产物，`.uV2eYG_primary` 仍出现在 `dsh-client-ui-conversation` 的产物（rev `cf69ca49decf`）、`.bhn1Oq_fade` 仍出现在 `dsh-client-ui-workspace` 的产物（rev `1a8f018dea37`）。
- 桌面版安装方式：`desktop` profile 由桌面应用独占，`dsh plugin --profile desktop ...` 会被 CLI 拒绝；请在桌面应用的**插件**页用**绝对路径**添加本插件目录。

### v3.0.3
- 迁移：对齐 DSH `0.1.7-rc.1`（自 `0.1.7-alpha.2`）。纯客户端插件，逐项复核 rc.1 产物：`slots.inject` / `slots.register`、`theme` 服务未变；`sidebarRight` / `sidebarRightTabs`（**是服务不是 slot**，由官方 `dsh-client-ui-sidebar-right` 提供）未变；本插件自己 `ctx.provide('sidebarPanel')` 的插件间契约不受宿主影响。
- 复核哈希类名覆盖：`.uV2eYG_primary`（官方 `dsh-client-ui-conversation`）与 `.bhn1Oq_fade`（官方 `dsh-client-ui-workspace`）在 **rc.1 产物中仍然存在**，发送按钮与侧栏淡出层两处覆盖继续有效；`--dsw-specific-bubble` 同样仍在。
- 未采用：rc.1 新增的 12 个 `--dsw-alias-file-diff-*` CSS 变量（纯加法，与本插件无关）。
- 验证：隔离 `DSH_HOME` 冷启动 rc.1 → 模块已注册、客户端产物 HTTP 200 且含 `__ModuleLoader__.load`。

### v3.0.2
- 修复：DSH 0.1.7 新增的「插件」管理页整页没有底色，铺了背景图时卡片与文字直接压在原图上、无法辨读。宿主的中列（`.pI_x6G_centerCol`）不画底，每个 `main` 槽页面需自绘，而该页（`PluginManagerPage` 的 `.X_2TxG_page`）没有任何 `background`。现按对话页同一个 token 给它补面（`[data-plugin-panel]{background:var(--dsw-alias-bg-base)}`），随背景图一起注入与卸载。

### v3.0.1
- 修复：目标面板里的用户气泡不跟随配色预设（改用宿主 token `--dsw-specific-bubble`，chat 与 goal 共用），并去掉一处会在宿主重建后失效的哈希类名依赖。
- 修复：`SHEET` 样式在卸载 / 热重载后残留；背景图超出 `localStorage` 配额时的回退路径不再自相矛盾（过去会把旧背景写回存储、屏幕与存储长期不一致）。

### v3.0.0
- 破坏性变更：卡片布局引擎整体移除（侧栏 / 对话区 / 停靠卡的拖动、吸附、浮动、缩放与布局模式开关全部删除），`lib/client.js` 从 117KB 降到 32KB；设置里只剩外观美化。

### v2.x 及更早
- **v2.0.2**：修复卡片模式拖不动 / 界面卡死（`beginDrag` / `endDrag` 被误删导致 `ReferenceError`，且发生在 `preventDefault` 之前）。
- **v2.0.1**：插件面板挂到官方右侧栏后的布局错乱（宿主统一给出 `.dsh-sidebar-panel-host` 布局契约）；按面板自身宽度做响应式。
- **v2.0.0**：`dock`（v2）与自研面板宿主整体移除，改为注册成官方右侧栏标签页（新服务 `sidebarPanel`，`apiVersion = 1`）；修复与官方侧边栏的列宽冲突。
- **v1.15.1**：修复宿主热重载后布局引擎失效（表现为「更新任意插件后 ui-beautify 整体消失」）。
- **v1.14–v1.15**：插件面板标签按打开顺序排列、横向滚动标签条；`dock` API 升 v2。
- **v1.13.x**：改用正式契约 `ctx.provide` 对外提供面板服务；修复热重载后的面板消失与拖拽状态残留。
- **v1.12.x**：卡片布局引擎的几何打磨（列宽保底、缩放下限、溢出与回位）。
- **v1.8–v1.11**：统一的插件面板（启动器 + 标签页宿主）、五区域吸附、界面归一化到 DSH 设计系统与 Apple HIG。
- **v1.4–v1.7**：卡片布局引擎上线、接缝线体系、停靠位置白名单与框架重挂载自愈。
- **v1.0–v1.3**：配色预设 + 整页背景图（自动压缩、持久化）+ 官方 bundle 安装支持。

## License

MIT
