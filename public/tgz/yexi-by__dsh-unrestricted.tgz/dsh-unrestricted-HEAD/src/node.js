/**
 * dsh-unrestricted host half: fuses the unrestricted execution mode into each
 * preset's ORIGINAL system prompt at assembly time and exposes read-only previews.
 *
 * Mechanism (public interfaces only):
 * - A root `system-prompt/assemble` waterfall listener receives every agent's
 *   assembly (unscoped listeners pass the dsh-scope filter). When enabled, it
 *   fuses the preset's sections structurally: extending `deployment:persona-prefix`
 *   in place, inserting the `unrestricted:execution-mode` section right after the
 *   persona, and appending boundary notes to any present `plan:policy`,
 *   `tools:ptc-only`, or `tool:structured_output` sections. Tools, contexts,
 *   and variables pass through untouched; when disabled the listener returns
 *   `next()` verbatim, so the prompt is byte-identical to the unmodified harness.
 * - `minimal` registers its persona with `complete: true`, which the registry
 *   restores AFTER the waterfall, so waterfall edits cannot reach it. For
 *   minimal agents (joined, switched via `agent-preset/selected`, or later
 *   created) the plugin shadows `deployment:persona-prefix` at agent scope with
 *   a complete section carrying the fused minimal prompt, and disposes that
 *   shadow immediately if the blank session switches away to another preset.
 * - Rosterless profiles (such as `headless`, `acp`, or `sdk`) mount no
 *   `agentPresets` service; the plugin detects the active host composition
 *   (`ptc` when `tools:ptc-only` is present, otherwise `standard`) and fuses
 *   their assemblies directly.
 */
import z from '@deepseek-ai/schemastery'
import { renderPrompt } from '@deepseek-ai/dsh-system-prompt'
import {
  ANCHORS,
  EXECUTION_MODE_BLOCK,
  PRESETS,
  PRESET_RULES,
  fuseSections,
  fusedMinimalPrompt,
  normalizePromptText,
  renderPreview,
  resolveExecutionModeBlock,
  stripHostIdentityFromAssembly,
} from './rules.js'
import { registerRpcRoutes } from './rpc.js'

/** Cordis plugin name used by Loader diagnostics. */
export const name = 'dsh-unrestricted'

/** Current plugin package version. */
export const PLUGIN_VERSION = '0.2.17'

/** Services required by this plugin (all base-backed profiles provide these). */
export const inject = ['settings', 'systemPrompt', 'loader']

export const Config = z.object({
  enabled: z.boolean().default(false),
  stripHostIdentity: z.boolean().default(false),
  customPrompt: z.string().default(''),
  extraPresets: z.array(z.string()).default([]),
}).default({ enabled: false, stripHostIdentity: false, customPrompt: '', extraPresets: [] }).volatile()

/** Human-readable error text for diagnostics and RPC error branches. */
function messageOf(error) {
  return error instanceof Error ? error.message : String(error)
}

/** RpcResult success branch. */
function ok(value) {
  return { ok: true, value }
}

/**
 * @param ctx - plugin context carrying settings, systemPrompt, loader, and
 *   optional agentPresets / connection services.
 */
export function apply(ctx, config) {
  ctx.effect(() => ctx.settings.configure({ auto: false }, ctx.fiber))

  const initialConfig = config.get()
  const initialCustomPrompt = normalizePromptText(initialConfig.customPrompt)
  const initialPromptBlock = resolveExecutionModeBlock(initialCustomPrompt)
  const state = {
    active: true,
    enabled: Boolean(initialConfig.enabled),
    stripHostIdentity: Boolean(initialConfig.stripHostIdentity),
    customPrompt: initialCustomPrompt,
    promptBlock: initialPromptBlock,
    extraPresets: new Set(initialConfig.extraPresets ?? []),
    /** presetId -> issue codes observed on live assemblies. */
    runtime: new Map(),
    /** Agent -> section disposer for minimal persona shadows. */
    shadows: new Map(),
    /** Minimal agents whose persona was already registered at agent scope by caller. */
    customMinimal: new WeakSet(),
    /** Minimal agents currently being probed for complete-section ownership. */
    probingMinimal: new WeakSet(),
    /** Agents already disposed, guarding async shadow probes against late writes. */
    disposed: new WeakSet(),
    /** Precomputed fused minimal prompt for the active prompt block. */
    fusedMinimal: fusedMinimalPrompt('', initialPromptBlock),
  }

  function isCustomPromptActive() {
    return state.customPrompt.trim() !== '' && state.promptBlock !== EXECUTION_MODE_BLOCK
  }

  function isSupportedPreset(presetId) {
    return Boolean(PRESET_RULES[presetId]) || state.extraPresets.has(presetId)
  }

  /**
   * Read the standing assembly of a preset using the registry's scope lease
   * (DSH >= 0.2.1) or scope helper fallback (DSH 0.2.0-rc.2).
   * In rosterless profiles, assemble the global host layer directly.
   */
  async function presetAssembly(presetId) {
    await ctx.loader.await()
    const presets = ctx.get('agentPresets')
    if (presets === undefined) {
      return await ctx.systemPrompt.assemble({})
    }
    if (typeof presets.acquireScope === 'function') {
      const lease = await presets.acquireScope(presetId)
      try {
        return await ctx.systemPrompt.assemble({ scope: lease.key })
      } finally {
        await lease[Symbol.asyncDispose]()
      }
    }
    if (typeof presets.get === 'function') {
      const { createScope } = await import('@deepseek-ai/dsh-scope')
      const preset = presets.get(presetId)
      const { ctx: scopeCtx, key, dispose } = await createScope(
        ctx,
        'agent-preset',
        presetId,
        preset.plugin,
        preset.config,
      )
      try {
        await scopeCtx.loader.await()
        return await ctx.systemPrompt.assemble({ scope: key })
      } finally {
        await dispose()
      }
    }
    return await ctx.systemPrompt.assemble({})
  }

  /**
   * Remove a minimal persona shadow from an agent when it switches preset, is
   * disposed, or unrestricted mode turns off.
   */
  function unshadowMinimal(agent) {
    const dispose = state.shadows.get(agent)
    if (dispose === undefined) return
    state.shadows.delete(agent)
    dispose()
  }

  /**
   * Resolve the composed preset id for a live agent, or infer `ptc`/`standard`
   * when running in a rosterless profile (e.g. headless / sdk).
   */
  function resolveAgentPreset(agent, sections) {
    const presets = ctx.get('agentPresets')
    if (presets !== undefined) {
      try {
        return presets.composedPreset(agent.ctx)
      } catch {
        return undefined
      }
    }
    if (sections !== undefined) {
      return sections.some(s => s.name === 'tools:ptc-only' && s.text.trim() !== '')
        ? 'ptc'
        : 'standard'
    }
    return undefined
  }

  /**
   * Determine whether a post-assembly section list belongs to a stock
   * complete-persona minimal agent rather than a custom-persona child override.
   * On DSH >= 0.2.3, `AssembledSection` exposes `order` and `complete`; on
   * DSH <= 0.2.2, a complete assembly restores a single `deployment:persona-prefix`
   * section without `order`.
   */
  function isCompleteMinimalAssembly(sections) {
    const persona = sections.find(section => section.name === 'deployment:persona-prefix')
    if (persona === undefined) return false
    if (typeof persona.order === 'number') return persona.complete === true
    return sections.length === 1
  }

  /**
   * Register the fused complete persona shadow directly on a stock minimal
   * agent. Still handles the duplicate-section error thrown by DSH <= 0.2.2 if
   * a caller registered a persona in the same scope before probing completed.
   */
  function installMinimalShadow(agent) {
    if (!state.active || !state.enabled || state.disposed.has(agent)) return
    if (resolveAgentPreset(agent) !== 'minimal') return
    if (state.shadows.has(agent) || state.customMinimal.has(agent)) return
    let dispose
    try {
      dispose = agent.ctx.systemPrompt.section({
        name: 'deployment:persona-prefix',
        order: 0,
        complete: true,
        interpolate: false,
        text: (context) => {
          const hasStructured = context?.agent?.ctx?.tools
            ?.schemas?.(context.agent)
            ?.some(tool => tool.name === 'structured_output') === true
          return hasStructured
            ? fusedMinimalPrompt(ANCHORS.structuredOutputFull, state.promptBlock)
            : state.fusedMinimal
        },
      })
    } catch (error) {
      if (messageOf(error) !== 'prompt section "deployment:persona-prefix" is already registered in this scope') throw error
      state.customMinimal.add(agent)
      return
    }
    state.shadows.set(agent, dispose)
  }

  /**
   * Synchronize a minimal agent's complete persona shadow with its current
   * preset and toggle state. Probes the scope read-only (no `agent`/`session`)
   * before installing a shadow so DSH >= 0.2.3's latest-registration-wins rule
   * never overwrites a child subagent's custom non-complete persona.
   */
  function syncMinimalShadow(agent) {
    if (!state.active || !state.enabled || state.disposed.has(agent)) {
      unshadowMinimal(agent)
      return
    }
    const presetId = resolveAgentPreset(agent)
    if (presetId !== 'minimal') {
      unshadowMinimal(agent)
      return
    }
    if (state.shadows.has(agent) || state.customMinimal.has(agent) || state.probingMinimal.has(agent)) return
    state.probingMinimal.add(agent)
    void ctx.systemPrompt.assemble({ scope: agent }).then((assembly) => {
      if (!state.active || !state.enabled || state.disposed.has(agent)) return
      if (resolveAgentPreset(agent) !== 'minimal') return
      if (isCompleteMinimalAssembly(assembly.sections)) {
        installMinimalShadow(agent)
      } else {
        state.customMinimal.add(agent)
      }
    }).catch(() => {
      // Agent or scope disposed while probing; ignore transient error.
    }).finally(() => {
      state.probingMinimal.delete(agent)
    })
  }

  /** Synchronize minimal persona shadows across all live agents. */
  function sweepAgents() {
    const agents = ctx.get('agents')
    if (agents === undefined) return
    for (const agent of agents.list()) syncMinimalShadow(agent)
  }

  /** Drop every persona shadow (toggle off or plugin disposal). */
  function clearShadows() {
    for (const [, dispose] of state.shadows) dispose()
    state.shadows.clear()
  }

  function onEnable() {
    state.runtime.clear()
    sweepAgents()
    void ctx.loader.await().then(() => {
      if (state.enabled) sweepAgents()
    })
  }

  function onDisable() {
    clearShadows()
    state.runtime.clear()
  }

  /** Current card view: toggle, stripHostIdentity flag, version, and per-preset state. */
  function statusPayload() {
    const modes = {}
    for (const presetId of PRESETS) {
      const issues = state.runtime.get(presetId) ?? []
      modes[presetId] = {
        state: !state.enabled
          ? 'off'
          : issues.length > 0 ? 'failed' : 'active',
        issues,
      }
    }
    return {
      enabled: state.enabled,
      stripHostIdentity: state.stripHostIdentity,
      customPrompt: state.customPrompt,
      defaultPrompt: EXECUTION_MODE_BLOCK,
      isCustomPrompt: isCustomPromptActive(),
      version: PLUGIN_VERSION,
      modes,
    }
  }

  /** One line-count/byte summary so the preview reports size metadata. */
  function summarize(text) {
    return {
      text,
      bytes: Buffer.byteLength(text, 'utf8'),
      lines: text.split('\n').length,
    }
  }

  /**
   * Variables to bind in a standing-scope preview. When a live agent exists,
   * borrow its route and working directory so the card reads a realistic
   * prompt instead of raw slots.
   */
  function previewVariables() {
    const variables = {}
    try {
      const agents = ctx.get('agents')
      const agent = agents?.list?.()[0]
      if (agent !== undefined) {
        variables.provider = agent.options.provider
        variables.model = agent.options.model
        variables.cwd = agent.session.header.cwd
      }
    } catch {
      // No agent service or an unreadable session: literal slots are fine.
    }
    return variables
  }

  /**
   * Build the deploy preview for ONE preset from the same assembly path the
   * live fusion uses. Read-only — never mutates prompt state.
   */
  async function previewFor(presetId) {
    if (!isSupportedPreset(presetId)) {
      return {
        presetId,
        available: false,
        errorCode: 'unsupported-preset',
        reason: `unknown preset "${presetId}"`,
      }
    }
    try {
      const assembly = await presetAssembly(presetId)
      let previewAssembly
      if (presetId === 'minimal') {
        previewAssembly = {
          ...assembly,
          sections: [{
            name: 'deployment:persona-prefix',
            order: 0,
            interpolate: false,
            text: fusedMinimalPrompt('', state.promptBlock),
          }],
        }
      } else {
        const fused = fuseSections(assembly.sections, presetId, {
          allowDynamicPreset: state.extraPresets.has(presetId),
          customPrompt: state.promptBlock,
        })
        if (fused.issues !== undefined) {
          return {
            presetId,
            available: false,
            errorCode: 'missing-persona',
            reason: fused.issues.join('; '),
          }
        }
        previewAssembly = { ...assembly, sections: fused.sections }
      }
      if (state.stripHostIdentity) {
        previewAssembly = stripHostIdentityFromAssembly(previewAssembly)
      }
      const variables = { ...previewAssembly.variables, ...previewVariables() }
      const text = renderPreview({ ...previewAssembly, variables }, renderPrompt)
      return { presetId, available: true, source: 'standing', ...summarize(text) }
    } catch (error) {
      return {
        presetId,
        available: false,
        errorCode: 'preview-failed',
        reason: messageOf(error),
      }
    }
  }

  /** RPC endpoint handler for the settings card. */
  async function handleRpc(endpoint, payload) {
    switch (endpoint) {
      case 'status': {
        return ok(statusPayload())
      }
      case 'preview': {
        const presetId = payload?.presetId ?? payload?.args?.presetId
        return ok(await previewFor(presetId))
      }
      case 'recheck': {
        state.runtime.clear()
        if (state.enabled) sweepAgents()
        return ok(statusPayload())
      }
      default:
        return {
          ok: false,
          error: {
            code: 'internal',
            message: `dsh-unrestricted: unknown endpoint ${JSON.stringify(endpoint)}`,
            details: {},
          },
        }
    }
  }

  ctx.on('system-prompt/assemble', async (assembly, context, next) => {
    const original = await next()
    if (!state.enabled && !state.stripHostIdentity) return original
    const agent = context.agent
    if (agent === undefined) return original
    const presetId = resolveAgentPreset(agent, original.sections)
    if (presetId === undefined || !isSupportedPreset(presetId)) {
      unshadowMinimal(agent)
      return original
    }

    let current = original

    if (presetId === 'minimal') {
      if (state.enabled) {
        if (!state.shadows.has(agent) && !state.customMinimal.has(agent)) {
          const persona = current.sections.find(section => section.name === 'deployment:persona-prefix')
          if (persona !== undefined && typeof persona.order === 'number') {
            if (persona.complete === true) installMinimalShadow(agent)
            else state.customMinimal.add(agent)
          } else {
            installMinimalShadow(agent)
          }
        }
        if (state.customMinimal.has(agent)) {
          const fused = fuseSections(current.sections, 'minimal', {
            isSubagent: true,
            customPrompt: state.promptBlock,
          })
          if (fused.issues !== undefined) {
            state.runtime.set('minimal', fused.issues)
            return state.stripHostIdentity ? stripHostIdentityFromAssembly(current) : current
          }
          state.runtime.delete('minimal')
          current = { ...current, sections: fused.sections }
        }
      } else if (state.shadows.has(agent)) {
        unshadowMinimal(agent)
      }
      return state.stripHostIdentity ? stripHostIdentityFromAssembly(current) : current
    }

    if (state.shadows.has(agent)) {
      unshadowMinimal(agent)
    }

    if (state.enabled) {
      const isSubagent = current.contexts.some(entry => entry.name === 'subagent:delegation')
      const fused = fuseSections(current.sections, presetId, {
        isSubagent,
        allowDynamicPreset: state.extraPresets.has(presetId),
        customPrompt: state.promptBlock,
      })
      if (fused.issues !== undefined) {
        state.runtime.set(presetId, fused.issues)
        return state.stripHostIdentity ? stripHostIdentityFromAssembly(current) : current
      }
      state.runtime.delete(presetId)
      current = { ...current, sections: fused.sections }
    }

    return state.stripHostIdentity ? stripHostIdentityFromAssembly(current) : current
  })

  ctx.on('agent/created', ({ agent }) => {
    if (!state.enabled) return
    syncMinimalShadow(agent)
  })

  ctx.on('agent-preset/selected', (sessionId) => {
    const agent = ctx.get('agents')?.get?.(sessionId)
    if (agent === undefined) return
    state.customMinimal.delete(agent)
    if (!state.enabled) {
      unshadowMinimal(agent)
      return
    }
    syncMinimalShadow(agent)
  })

  ctx.on('agent/disposed', ({ agent }) => {
    state.disposed.add(agent)
    state.customMinimal.delete(agent)
    unshadowMinimal(agent)
  })

  ctx.effect(() => {
    const unwatch = ctx.on('loader/volatile-update', () => {
      const nextConfig = config.get()
      const enabled = Boolean(nextConfig.enabled)
      const nextCustomPrompt = normalizePromptText(nextConfig.customPrompt)
      state.stripHostIdentity = Boolean(nextConfig.stripHostIdentity)
      state.customPrompt = nextCustomPrompt
      state.promptBlock = resolveExecutionModeBlock(nextCustomPrompt)
      state.fusedMinimal = fusedMinimalPrompt('', state.promptBlock)
      state.extraPresets = new Set(nextConfig.extraPresets ?? [])
      if (enabled === state.enabled) return
      state.enabled = enabled
      if (enabled) onEnable()
      else onDisable()
    })
    if (state.enabled) onEnable()
    return () => {
      state.active = false
      state.enabled = false
      unwatch()
      clearShadows()
    }
  }, 'dsh-unrestricted: toggle lifecycle')

  // 挂载到 Connection 自有的 /api 共享通道下，无需依赖 connection 自身注入 webServer。
  ctx.inject(['connection'], (connectionCtx) => {
    return registerRpcRoutes(connectionCtx.connection, handleRpc)
  })
}
