[English](README.md) | 中文

# DSH 任务看板插件（dsh-task-board）

把 CodexFF 的项目任务看板移植为 **DeepSeek Harness（DSH）** 正式插件：会话内新增
`对话 → 轨迹 → 任务看板` 三个 tab，看板为画布式面板（拖拽 / 层级 / 折叠），配套
模型工具与同步技能，数据落在本地 JSON，无需任何外部服务。

## 功能特性

- **会话视图 tab**：`对话 → 轨迹 → 任务看板`（`conversation.view`，order 20）。
- **画布式看板**：每主任务一个子任务面板，面板可拖拽、磁吸对齐（25px 基准间距、
  顶部行对齐、纵向堆叠自动水平居中）、折叠/展开；临时任务与业务任务分色标记。
- **任务模型**：父子任务树、任务边界（目标/包含/不包含/验收）、勾选完成、
  子任务全部完成时自动收口父任务；新增未完成子任务会级联重开祖先任务。
- **模型工具**（与 CodexFF MCP 同名语义）：
  - `board_get` / `board_revision`：读看板与修订号
  - `board_sync`：批量创建/更新任务（一次调用内支持 `key` 引用）
  - `task_create` / `task_update` / `task_delete`：单任务操作
- **技能**：`dsh-task-board`（任务拆分与同步纪律），模型会自动加载。
- **存储**：`<项目目录>/.dsh-taskboard/board.json` —— 看板随项目走（可提交进版本库）。
  每次变更前会把上一版快照到 `<项目>/.dsh-taskboard/backups/`（保留最近 10 份，自动生成
  `.gitignore` 忽略），同时写入全局镜像
  `$DSH_HOME/taskboards/<sha256(项目路径)>.json`。读取链：项目主文件 → 最新备份 →
  全局镜像 → 空看板（走兜底时会自动回写主文件），所有写入均为原子写。格式与 CodexFF
  一致；项目目录只读时自动退化为仅写全局镜像。

![会话视图：对话 → 轨迹 → 任务看板 tab](https://cdn.jsdelivr.net/gh/etony668/dsh-task-board@main/images/taskboard-tab.png)

![画布式看板：主任务与子任务面板布局](https://cdn.jsdelivr.net/gh/etony668/dsh-task-board@main/images/taskboard-canvas.png)

## 安装

> ⚠️ **请一律通过插件管理器安装与更新**（插件面板，或 `dsh plugin add <路径或包名>`）。
> **不要**手工编辑 profile 的 `package.json` 去添加 `link:` 依赖：当插件同时出现在
> `dsh.profile.bundles` 与 `dependencies` 里时，插件管理器会以 `ambiguous-install`
> 拒绝更新（DSH 0.20+）。若已手工加过，删掉那条手工声明后重装一次即可——管理器会
> 自己写入正确的依赖。

### 方式一：一条命令安装（推荐）

```sh
dsh plugin --profile web add @etony668/dsh-task-board
```

然后打开或刷新 DSH 网页界面，「任务看板」tab 出现在「轨迹」之后。
插件也已收录至插件市场（workflow 分类）。

### 方式二：从 GitHub 克隆（备选）

**macOS / Linux（bash）**

```bash
git clone https://github.com/etony668/dsh-task-board.git
cd dsh-task-board
./install.sh
```

**Windows（PowerShell）**

```powershell
git clone https://github.com/etony668/dsh-task-board.git
cd dsh-task-board
.\install.ps1
```

> Windows 用户也可以在 Git Bash 中运行 `./install.sh`（效果相同）。

然后**刷新 DSH 页面**（或重启 DSH）即可看到「任务看板」tab。
页面无变化时重启一次 DSH —— 补丁在启动时必然生效。

### 方式一b：插件市场一键安装

本插件已提交 [awesome-dsh-plugin](https://awesome-dsh-plugin.com) 收录（`workflow`
分类，合并后生效）。装有 [dsh-market](https://github.com/dsh-market/dsh-market)
插件市场后，打开 DSH **设置 → 插件市场**，搜索 `task-board` 即可一键安装，无需
手动克隆。

### 方式二：手动安装

1. 把本仓库内容放到 `~/.dsh/plugins/dsh-task-board/`（或任意目录）。
2. 运行 `./reinstall.sh` —— 它会把包复制进当前运行时
   `node_modules/@etony668/dsh-task-board/` 并建立 profile 回退符号链接。
3. 确认 `~/.dsh/cordis.patch.yml` 包含（不存在则创建）：

   ```yaml
   - insert:
       - id: task-board
         name: '@etony668/dsh-task-board'
   ```

> `reinstall.sh` / `reinstall.ps1` 会自动探测 macOS / Windows / Linux 常见 DSH 运行时目录；
> 探测不到时用 `DSH_TASK_BOARD_RUNTIME`（bash）或 `-RuntimeRoot`（PowerShell）指定：
> - bash：`DSH_TASK_BOARD_RUNTIME="/path/to/runtime" ./reinstall.sh`
> - PowerShell：`.\reinstall.ps1 -RuntimeRoot "C:\path\to\runtime"`

## 使用

- 顶部 tab 切换到「任务看板」；看板内**无返回按钮**，返回对话用顶部「对话」tab，
  键盘 `Tab` / `Esc` 也可返回（输入框聚焦时不劫持）。
- 看板视图下底部消息框自动隐藏，避免遮挡。
- 模型完成任务变更后会给出可点击的「查看任务看板」链接，点击即切换 tab。

## 升级

DSH 升级会生成新的运行时版本目录，`node_modules` 与 profile 符号链接需要重建：

```bash
cd ~/.dsh/plugins/dsh-task-board && ./reinstall.sh
```

Windows：

```powershell
cd $env:USERPROFILE\.dsh\plugins\dsh-task-board
.\reinstall.ps1
```

`cordis.patch.yml` 位于 `~/.dsh`，不受升级影响。

## 卸载

```bash
# 官方桌面版：在「设置 → 插件」里卸载，或调用
#   plugin_manager remove_bundle @etony668/dsh-task-board

# 旧版（复制进 runtime 版本目录）安装方式卸载：
# 1) 从补丁中删除插件行（编辑 ~/.dsh/cordis.patch.yml，移除 - insert: 部分）
rm -rf ~/.dsh/plugins/dsh-task-board
rm -rf <runtime>/versions/*/node_modules/@etony668/dsh-task-board
rm -f  ~/.dsh/profiles/node_modules/@etony668/dsh-task-board
# 2) 数据（可选）：<项目>/.dsh-taskboard/ 与 ~/.dsh/taskboards/*.json
```

## 目录结构

```
index.js        包根入口（loader 以 <pkg>/index.js 解析；re-export lib/index.js）
lib/index.js    host 插件（node ESM）：存储 + 工具 + 技能 + /api/task-board 路由
lib/client.js   web 插件 bundle（__ModuleLoader__ 手工构建，仅依赖 react）
package.json    dsh.client: { platform: web }，exports ./client
install.sh      一键安装（复制 + 安装 + patch 写入，macOS/Linux bash）
install.ps1     一键安装（Windows PowerShell）
reinstall.sh    重装到当前运行时 node_modules + profile 回退符号链接（bash）
reinstall.ps1   重装（Windows PowerShell）
```

## 开发

插件遵循 DSH 双端插件结构：host 端（Node ESM）提供存储/工具/技能/路由，
client 端（浏览器 bundle）注册 `conversation.view` tab 并渲染看板。
修改后 `./install.sh` 重装并刷新页面即可；host 端改动需重启 DSH。

## 许可证

[MIT](./LICENSE)
