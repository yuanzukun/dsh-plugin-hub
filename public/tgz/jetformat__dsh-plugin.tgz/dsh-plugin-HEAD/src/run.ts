import { spawn } from 'node:child_process'

export type RunResult = {
  code: number
  stdout: string
  stderr: string
  command: string
}

export function resolveBinary(): string {
  return process.env.JETFORMAT_BIN?.trim() || 'jetformat'
}

export function assertSafePath(input: string): string {
  const value = input.trim()
  if (!value) {
    throw new Error('path is required')
  }
  if (value.startsWith('-')) {
    throw new Error('path must not start with -')
  }
  return value
}

function spawnOnce(command: string, args: string[], cwd?: string): Promise<RunResult> {
  return new Promise((resolve, reject) => {
    // JETFORMAT_CLIENT names this host in the CLI's anonymous usage ping (never a file).
    const child = spawn(command, args, { cwd, env: { JETFORMAT_CLIENT: 'deepseek-harness', ...process.env } })
    let stdout = ''
    let stderr = ''
    child.stdout.on('data', (chunk) => {
      stdout += String(chunk)
    })
    child.stderr.on('data', (chunk) => {
      stderr += String(chunk)
    })
    child.on('error', reject)
    child.on('close', (code) => {
      resolve({ code: code ?? 1, stdout, stderr, command: [command, ...args].join(' ') })
    })
  })
}

export async function runJetformat(args: string[], options: { cwd?: string } = {}): Promise<RunResult> {
  return spawnOnce(resolveBinary(), args, options.cwd)
}
