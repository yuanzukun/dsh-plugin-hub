import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { assertSafePath, runJetformat } from './run.ts'

export const name = 'jetformat'
export const inject = ['tools']

async function runOrThrow(args: string[]) {
  const result = await runJetformat(args)
  if (result.code !== 0) {
    throw new Error(result.stderr.trim() || result.stdout.trim() || `jetformat exited ${result.code}`)
  }
  return {
    command: result.command,
    stdout: result.stdout.trim(),
    stderr: result.stderr.trim(),
  }
}

// Every tool returns the command it ran and the CLI's trimmed stdout and stderr.
const output = {
  schema: {
    type: 'object',
    additionalProperties: false,
    properties: {
      command: { type: 'string', required: true },
      stdout: { type: 'string', required: true },
      stderr: { type: 'string', required: true },
    },
  },
  render: (_args: unknown, value: unknown) => [{ type: 'text', text: JSON.stringify(value) }],
} as const

const officeKinds: Record<string, string> = { '.docx': 'word', '.xlsx': 'excel', '.pptx': 'ppt' }

function officeKind(input: string) {
  const dot = input.lastIndexOf('.')
  const kind = dot < 0 ? undefined : officeKinds[input.slice(dot).toLowerCase()]
  if (!kind) {
    throw new Error(`input must be .docx, .xlsx, or .pptx: ${input}`)
  }
  return kind
}

export function apply(ctx: Context) {
  ctx.tools.register(defineTool({
    name: 'jetformat_to_pdf',
    description: 'Convert a DOCX, XLSX, or PPTX file to PDF with the local Jetformat engine (word, excel, or ppt to-pdf). Do not use for .doc/.xls/.ppt.',
    parameters: {
      input: { type: 'string', required: true, description: 'Path to a .docx, .xlsx, or .pptx file' },
      output: { type: 'string', description: 'Output PDF path. Defaults beside the input file.' },
      force: { type: 'boolean', description: 'Overwrite an existing PDF' },
    },
    output,
    async execute(args: { input: string; output?: string; force?: boolean }) {
      const input = assertSafePath(args.input)
      const kind = officeKind(input)
      const argv = [kind, 'to-pdf', input]
      if (args.output) {
        argv.push('-o', assertSafePath(args.output))
      }
      if (args.force) {
        argv.push('--force')
      }
      return runOrThrow(argv)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'jetformat_text',
    description: 'Extract existing text from DOCX, XLSX, PPTX, or PDF. Not OCR.',
    parameters: {
      input: { type: 'string', required: true, description: 'Path to the input file' },
      output: { type: 'string', description: 'Optional text file path. Omit to return stdout.' },
    },
    output,
    async execute(args: { input: string; output?: string }) {
      const argv = ['text', assertSafePath(args.input)]
      if (args.output) {
        argv.push('-o', assertSafePath(args.output))
      }
      return runOrThrow(argv)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'jetformat_validate',
    description: 'Validate an Office, PDF, font, EMF, or XMP file with Jetformat.',
    parameters: {
      input: { type: 'string', required: true, description: 'Path to the file to validate' },
    },
    output,
    async execute(args: { input: string }) {
      return runOrThrow(['validate', assertSafePath(args.input)])
    },
  }))

  ctx.tools.register(defineTool({
    name: 'jetformat_pdf',
    description: 'Inspect, merge, extract contiguous pages, or render PDF pages to PNG/JPEG.',
    parameters: {
      action: { type: 'string', required: true, description: 'info, merge, extract, or render' },
      input: { type: 'string', description: 'Input PDF for info, extract, or render' },
      inputs: { type: 'string', description: 'Comma-separated PDFs for merge, in order' },
      output: { type: 'string', description: 'Output PDF or render directory' },
      pages: { type: 'string', description: 'Page range such as 1-3, 2-last, or 1,last' },
      width: { type: 'number', description: 'Render width in pixels' },
    },
    output,
    async execute(args: {
      action: string
      input?: string
      inputs?: string
      output?: string
      pages?: string
      width?: number
    }) {
      const action = args.action.trim().toLowerCase()
      if (action === 'info') {
        return runOrThrow(['pdf', 'info', assertSafePath(args.input ?? ''), '--json'])
      }
      if (action === 'merge') {
        const files = (args.inputs ?? '').split(',').map((item) => assertSafePath(item)).filter(Boolean)
        if (files.length < 2) {
          throw new Error('merge requires at least two comma-separated input PDFs')
        }
        const argv = ['pdf', 'merge', ...files]
        if (args.output) {
          argv.push('-o', assertSafePath(args.output))
        }
        return runOrThrow(argv)
      }
      if (action === 'extract') {
        const argv = ['pdf', 'extract', assertSafePath(args.input ?? '')]
        if (args.pages) {
          argv.push('--pages', args.pages)
        }
        if (args.output) {
          argv.push('-o', assertSafePath(args.output))
        }
        return runOrThrow(argv)
      }
      if (action === 'render') {
        const argv = ['pdf', 'render', assertSafePath(args.input ?? '')]
        if (args.pages) {
          argv.push('--pages', args.pages)
        }
        if (args.width) {
          argv.push('--width', String(args.width))
        }
        if (args.output) {
          argv.push('-o', assertSafePath(args.output))
        }
        return runOrThrow(argv)
      }
      throw new Error('action must be info, merge, extract, or render')
    },
  }))
}
