# Jetformat for DeepSeek Harness

Registers four tools that run the local Jetformat CLI: Word, Excel, and PowerPoint to PDF, text extraction, file validation, and PDF info, merge, extract, and render. No MCP server; files stay on your machine.

## Install

Install the CLI and sign in first:

    npm install -g jetformat
    jetformat login

Then add the plugin:

    dsh plugin --profile web add @jetformat/dsh-plugin
    # or from GitHub
    dsh plugin --profile web add github:jetformat/dsh-plugin

## Tools

| Tool | Runs |
| --- | --- |
| `jetformat_to_pdf` | `word` / `excel` / `ppt to-pdf`, picked by file extension |
| `jetformat_text` | `text` (no OCR) |
| `jetformat_validate` | `validate` |
| `jetformat_pdf` | `pdf info`, `merge`, `extract`, `render` |

## Permissions and network

The plugin spawns the `jetformat` binary (set `JETFORMAT_BIN` to override). The CLI contacts jetformat.com to sign in, to deduct credits for paid commands, and to send an anonymous usage ping (`jetformat telemetry off` to stop). It never uploads files.

## Compatibility

Tested with DeepSeek Harness (`@deepseek-ai/dsh`) 0.1.5-rc.3.

## License

MIT for this plugin. The Jetformat CLI is closed-source: https://jetformat.com/terms
