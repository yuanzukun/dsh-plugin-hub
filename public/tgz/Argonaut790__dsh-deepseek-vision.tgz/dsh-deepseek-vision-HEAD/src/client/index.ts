/**
 * DeepSeek vision Web plugin: global image-model picker plus conversation
 * evidence card and read-only Evidence workspace.
 *
 * @module dsh-deepseek-vision/client
 */

import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client'
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment'
import type { ClientContext, SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type { ChatNodeViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { ReactNode } from 'react'
import type {} from '@deepseek-ai/dsh-client-connection/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-slots'
import { EvidenceView, SeeImageEvidenceCard } from './EvidenceWorkspace.tsx'
import { VisionModelSelect } from './VisionModelSelect.tsx'
import { visionUserMessageView } from './VisionUserMessage.tsx'
import type { EvidenceImageInjected, VisionModelSelectInjected } from './slots.ts'
import { en, zh, type VisionKey } from './locales.ts'
import { installStyles } from './styles.ts'
import { installVisionSendHook } from './send-hook.ts'
import { VisionModelDirectory } from './vision-directory.ts'
import { SEE_IMAGE_MODEL_SETTINGS_NAME, visionMediaRawPath } from '../shared.ts'

export {
  evidenceFromResult, evidenceMeta, foldEvidenceNodes,
} from './evidence.ts'
export type { SeeImageEvidence, SeeImageEvidenceMeta } from './evidence.ts'
export { EvidenceRecord, EvidenceView, SeeImageEvidenceCard } from './EvidenceWorkspace.tsx'
export { VisionModelDirectory, imageModelGroups } from './vision-directory.ts'
export type { VisionModelDirectoryState } from './vision-directory.ts'
export type {
  EvidenceImageInjected, EvidenceViewProps, LoadEvidenceImage, SeeImageCardProps,
  VisionModelSelectInjected,
} from './slots.ts'
export type { VisionKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** Copy for the global picker and conversation Evidence surfaces. */
    deepseekVision: VisionKey
  }
}

export const inject = ['locale', 'connection', 'conversation', 'slots', 'remote']

/** Register the picker, structured Tool card, and read-only Evidence view. */
export function apply(ctx: ClientContext): void {
  ctx.effect(installStyles, 'dsh-deepseek-vision: styles')
  ctx.effect(
    () => ctx.locale.register('deepseekVision', { zh, en }),
    'dsh-deepseek-vision: dictionaries',
  )
  const t = ctx.locale.bind('deepseekVision')

  const connection = ctx.get('connection') as ConnectionHandle
  const visionDirectory = new VisionModelDirectory(connection.api)
  const injected: VisionModelSelectInjected = {
    directory: visionDirectory.store,
    load: () => { void visionDirectory.load().catch(() => undefined) },
    select: selection => visionDirectory.select(selection).then(() => true, () => false),
  }

  ctx.effect(() => {
    const settingsMoved = ctx.remote.$on('settings/document-updated', (namespace) => {
      if (namespace === SEE_IMAGE_MODEL_SETTINGS_NAME) injected.load()
    })
    const adaptersMoved = ctx.remote.$on('llm/adapters-updated', injected.load)
    const connectionReset = ctx.on('connection/reset', () => { visionDirectory.resetConnected() })
    injected.load()
    return () => {
      settingsMoved()
      adaptersMoved()
      connectionReset()
      visionDirectory.dispose()
    }
  }, 'dsh-deepseek-vision: global directory')

  ctx.inject(['slots'], (scope: ClientContext) => {
    scope.effect(
      () => installVisionSendHook(scope.get('conversation')),
      'dsh-deepseek-vision: image send hook',
    )
    scope.slots.inject('conversation.chat.node', () => {
      let activeStock: unknown
      let disposeProjection: (() => void) | undefined
      const syncProjection = () => {
        const stock = scope.slots.entries('conversation.chat.node')
          .find(entry => entry.options.key === 'user' && (entry.options.priority ?? 0) === 0)
          ?.component as ((props: ChatNodeViewProps<'user'>) => ReactNode) | undefined
        if (stock === activeStock) return
        disposeProjection?.()
        disposeProjection = undefined
        activeStock = stock
        if (stock !== undefined) {
          disposeProjection = scope.slots.register({
            name: 'conversation.chat.node',
            key: 'user',
            priority: -100,
            locale: 'conversation',
          }, visionUserMessageView(stock))
        }
      }
      syncProjection()
      const unsubscribe = scope.slots.subscribe('conversation.chat.node', syncProjection)
      return () => {
        unsubscribe()
        disposeProjection?.()
      }
    })
    const evidenceInject = (sessionId: SessionId): EvidenceImageInjected => ({
      loadImage: (attachment: ImageAttachmentRef) => Promise.resolve(
        visionMediaRawPath(String(sessionId), String(attachment.attachmentId)),
      ),
    })
    scope.slots.inject('tool.call.toolview', () => scope.slots.register({
      name: 'tool.call.toolview',
      key: 'see_image',
      locale: 'deepseekVision',
      inject: evidenceInject,
    }, SeeImageEvidenceCard))
    scope.slots.inject('conversation.view', () => scope.slots.register({
      name: 'conversation.view',
      id: 'evidence',
      order: 20,
      label: () => t('evidence.view.label'),
      locale: 'deepseekVision',
      inject: evidenceInject,
    }, EvidenceView))
    scope.slots.inject('conversation.input.right', () => scope.slots.register({
      name: 'conversation.input.right',
      id: 'deepseek-vision-model',
      order: 100,
      locale: 'deepseekVision',
      inject: (): VisionModelSelectInjected => injected,
    }, VisionModelSelect))
  })
}
