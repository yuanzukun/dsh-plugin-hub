# 第三方内容与授权声明 / Third-Party Notices

## 一句话概括

- **本仓库的代码**（`index.js`、`worldbook/`、`cordis.patch.yml`、`scripts/`、`package.json` 等）：MIT，本项目作者原创。
- **两套预设（`preset/chat/`、`preset/cyrene-work/`）的 `agent.cordis.yml` 内的人设文本** 与 **`worldbook/data/` 内的世界书数据**：来自开源项目 **Cyrene-Agent**，MIT，`Copyright (c) 2026 Playa`；**已取得原作者同意**（2026-10-03，见第 1 节「授权确认」与「世界书数据」）。
- **角色 IP**（昔涟 / Cyrene 及《崩坏：星穹铁道》相关内容）：归 **HoYoverse / 米哈游** 所有。
- **禁止商业使用**：含角色 IP 的衍生物不得用于售卖、付费社群、广告变现、打包销售等。

---

## 1. 人设文本与世界书数据的来源与授权

本仓库随包发运**两套预设**，各自取用上游**不同模式**的提示词组。上游把它们按模式拆开
（`src/main/orchestrator/mode-prompt-profile.ts` 的 `MODE_FILES`），本仓库照搬其组合与顺序，
**两套的正文都一字未改**：

| 本仓库 | 取自上游 |
|---|---|
| `preset/chat/agent.cordis.yml` | `chat_system.md` + `chat_identity.md` + `soul.md` + `canon_quotes.md` |
| `preset/cyrene-work/agent.cordis.yml` | `work_system.md` + `work_identity.md` + `work_remark.md` + `canon_quotes_lite.md`，另接 `tool_usage.md` |

> `tool_usage.md` 在上游不属于人设正文，而是「工具系统内容」，且**只在非 chat 模式**拼入
> （`prompt-builder.ts`：`if (options.conversationMode !== "chat")`）。本仓库把它接在工作模式
> 人设之后 —— 顺序等价，正文未改。
>
> ⚠️ 上游在 work 模式里**刻意不用 `soul.md`**，改用 `canon_quotes_lite.md`。
> 这是上游自己的取舍，本仓库不代为更改。

### 对话模式预设（`preset/chat/`）

内容整理自：

- 项目：**Cyrene-Agent** — <https://github.com/Playa-Cyrene/Cyrene-Agent>
- 原作者：Playa
- 源文件：`prompts/chat_system.md`、`prompts/chat_identity.md`、`prompts/soul.md`、`prompts/canon_quotes.md`
- 语气规则：预设中「## 语气规则」那一段（句式禁止 / 语气参考 / 回复边界）来自上游
  `src/main/orchestrator/tone-injector.ts` 的 `DEFAULT_RULES` —— 即上游
  `prompts/tone-rules.md` 缺失时的内置兜底值。这一段在原应用里是**每轮随请求尾部注入**的，
  不是人设文件的一部分；本仓库把它并入预设正文，位置与上游的注入顺序一致（人设之后）。
- **本仓库新增的一句说明**：「## 语气规则」开头那段引用块（覆盖关系 + 一处例外 + 意象
  澄清）是**本项目自己写的**，不在上游任何文件里。加它的原因见下。

  上游靠**注入时序**（语气规则在请求尾部、距离最近）让这一段压过正文里较早的
  「§语言与句式」；本仓库合并成静态正文后那个时序机制消失，于是上游文本里
  「这些词语和结构并非绝对禁止」与「不可以使用……」会直接打架。项目选择**用一句显式
  声明把覆盖语义写回正文**，而不是去修改上游文本 —— 因此这里新增的是说明，不是改动。
- **本仓库删除的两处零信息残留**（同样在此明示）：上游 `canon_quotes.md` 的台词列表末尾有
  一条**空台词行**；同一个文件里还有一整段与 `chat_system.md` **逐字重复**的
  `## 知识性回复`（本地核对：两段只差一个结尾空行）。上游的 `buildModePrompt` 是四份文件
  直接拼接，所以它自己的 chat 模式里也带着这两处。本项目删掉了它们 ——
  **删的是零信息内容，未改动任何一句设定文本**。上游文件的 `#` 级标题（如 `# 昔涟 · Soul`）
  保留原样，作为来源锚点。
- 上游许可证：MIT License，`Copyright (c) 2026 Playa`
- 许可证副本：见 [`LICENSES/Cyrene-Agent-LICENSE.txt`](./LICENSES/Cyrene-Agent-LICENSE.txt)

### 工作模式预设（`preset/cyrene-work/`）

- 源文件：`prompts/work_system.md`、`work_identity.md`、`work_remark.md`、
  `canon_quotes_lite.md`，另接 `tool_usage.md`（上游把它拼进"工具系统内容"，chat 模式不拼）。
- **语气规则**：与对话模式同样来自上游 `tone-injector.ts` 的 `DEFAULT_RULES`（原文照搬）。
  上游这份规则是**每轮请求尾部注入、所有模式都吃**的（`build-options.ts` 无条件调用），
  所以工作模式本来就该有这一层；本仓库把它并入静态正文。
- **本仓库新增**：该段开头的覆盖说明，以及「### 工作场景的三处例外」三小节
  （结尾反问 / 先回应情绪 / 不说教在工作场景里要收窄或反过来）。这三条是**本项目自己写的**，
  不在上游任何文件里 —— 上游靠注入时序、我们靠显式声明；起因是静态正文后
  这三条会与 `work_system` 的评审要求、以及本仓库的「## 追问节制」直接打架。
- 「## 追问节制」同样是本项目补充（非上游正文），理由见预设文件头注释。

### 风格档位文件（`styles/`）

表达风格插件的五份风格文件是上游 `prompts/styles/` 的**原文**，一字未改：

| 本仓库 | 取自上游 |
|---|---|
| `styles/01_default.md` | `prompts/styles/01_default.md` |
| `styles/02_lively.md` | `prompts/styles/02_lively.md` |
| `styles/03_healing.md` | `prompts/styles/03_healing.md` |
| `styles/04_focused.md` | `prompts/styles/04_focused.md` |
| `styles/05_sweet.md` | `prompts/styles/05_sweet.md` |

档位与温度的对应关系来自上游 `src/shared/style-sampling.ts` 的 `BUILT_IN_STYLE_PRESETS`
（lively 0.90 / healing 0.55 / focused 0.40 / sweet 0.82；`default` 在代码里不设采样）。
注入块的外壳（`[表达风格]` 那三行）逐字取自上游 `buildStylePromptBlock()`。

**本仓库改了的只有"怎么接"**：上游把这些文件在请求尾部注入、并同时设置采样参数；
本仓库改为 DSH 的 `systemPrompt.context()`（尾部，order 130）+ `agent/request` 里的
`temperature` 写入。上游的重复惩罚（OpenAI `frequency_penalty` / Qwen `repetition_penalty`）
在 DSH 的 `LlmCallConfig` 里**没有对应字段**，因此未移植 —— 这是能力边界，不是遗漏。

- 上游许可证：MIT License，`Copyright (c) 2026 Playa`
- 许可证副本：见 [`LICENSES/Cyrene-Agent-LICENSE.txt`](./LICENSES/Cyrene-Agent-LICENSE.txt)

### 世界书数据

`worldbook/data/` 下的 5 个文件（61 条设定条目）同样整理自 **Cyrene-Agent**
（原作者 Playa，MIT License，`Copyright (c) 2026 Playa`），来源为上游戏的
`prompts/worldbook/` 目录。许可与 IP 声明的范围与上一条完全一致。

其中 `_glossary.md` 经过**改写**：上游原文件未带「触发词」「常驻」这类元数据字段，
在本项目的匹配器下会导致该文件的所有条目永远不触发。改写只是补齐这些字段并统一为
标准条目格式，设定文本本身未作改动。这属于 MIT 允许的修改，在此明示以便追溯。

#### 条目格式与字段语义的来源

`worldbook/data/` 里条目的**格式**（`## 标题 / 别名` 加 `- 触发词:` / `- 常驻:` /
`- 内在价值:` / `- 优先级:` / `- 连带触发词:` 以及正文）和这些字段的**含义**，
都来自上游的 `src/main/rag/worldbook.ts`，**不是本项目发明的**：

- `触发词`（keywords）—— 命中检测的依据
- `常驻`（permanent）—— 始终注入，不参与打分，也不占注入上限
- `优先级`（priority）—— 上游仅作排序 tiebreaker（真正的排序键是 activation 分数）
- `内在价值`（intrinsicValue）—— 上游只在 DMAE 的 Floor（首次激活基线）与
  Resistance（遗忘抵抗）里消费它
- `连带触发词`（linkTriggers）—— 上游定义为 **One-Shot 一次性**：本条目被用户命中时，
  连带触发这些关键词对应的条目，只本轮有效、不进状态表

本项目的 `worldbook/match.mjs` 是这套语义的**等效简化实现**：去掉了 DMAE 的激活
状态机与内在价值衰减。因此有两处刻意的行为差异，都写在模块头部注释里：

1. **`内在价值` 在本实现里不起作用** —— 没有状态机就没有落脚点，只解析保留以便数据无损；
2. **`优先级` 从 tiebreaker 变成主排序键** —— 因为没有 activation 分数。

MIT License 允许使用、复制、修改、合并、发布与再分发，条件是在副本中保留上述版权声明
与许可证全文。本仓库已履行该条件。

上游在 README 中对其自身许可范围的说明（转述）：源代码采用 MIT；
角色 IP、Live2D 模型与美术资产不属于 MIT 授权范围，分别遵循其模型授权文件与米哈游同人创作规范处理。

### 授权确认

除上述 MIT 许可外，本项目在公开发布前已征询原作者并取得同意：

- **授权时间**：`2026-10-03`
- **公开回复（主要凭据）**：原作者在
  <https://github.com/Playa-Cyrene/Cyrene-Agent/issues/137#issuecomment-5969268084>
  公开回复「拿就行，除了 live2D 模型，模型需要去找原作者」，
  并将该 issue 以 **closed as completed** 结案（同日 12:42 UTC）。
- **另经私信确认**：同日经 B 站私信沟通，作者亦回复同意使用。

> **许可范围说明**：
>
> 1. 该确认覆盖的是**提示词文本本身**（`prompts/` 下那四篇的整理与再分发）。
> 2. 作者明确**排除 Live2D 模型**——模型不在本确认范围内，其授权需另行向
>    模型原作者取得。**本仓库本就不包含**任何 Live2D 模型、立绘、美术资源或
>    音频，因此不受该排除影响；但**日后若有人要加入模型，必须自行取得授权**，
>    不得援引本确认。
> 3. 该确认**不覆盖角色 IP**——角色、世界观与美术的权利归 HoYoverse / 米哈游
>    所有，原作者无权代为授权该部分。因此本文件第 2 节（角色 IP 声明）与
>    第 3 节（非商业使用条款）**继续完整适用**。

## 2. 角色 IP 声明

Cyrene（昔涟）以及《崩坏：星穹铁道》相关的角色、世界观、名称与美术，
其知识产权归 **HoYoverse / 米哈游** 所有。

本项目为**非官方同人周边工具**，与 HoYoverse / 米哈游**无任何关联、背书或赞助关系**。
本项目不主张对上述 IP 的任何权利。

## 3. 非商业使用条款

承袭上游的同一立场：**因底层角色 IP 涉及米哈游同人创作规范，本仓库中
包含角色 IP 的衍生物禁止商业使用。**

明确禁止的情形包括但不限于：

- 售卖本插件或其修改版
- 放入付费社群、付费内容作为权益发放
- 通过广告、赞助等方式直接变现
- 与其他商品打包销售

## 4. 本仓库不包含什么

为避免扩大授权风险，本仓库**不包含**以下内容，请使用者自行解决：

- ❌ Live2D 模型文件（`.moc3` / `.motion3.json` / `.physics3.json` / 纹理等）
- ❌ 角色立绘、美术资源、音频、语音
- ❌ 游戏内文本的成段收录（预设 `agent.cordis.yml` 中引用的原作台词摘录，
  其内容版权归 HoYoverse / 米哈游所有，仅作语气参考用途）

## 5. 可选依赖（第三方插件）

以下插件**不在本仓库内**，请各自从原始仓库安装。本仓库不捆绑、不再分发它们：

| 插件 | 作者 | 授权 | 必要性 |
|---|---|---|---|
| [dsh-meme](https://github.com/yyh-001/dsh-meme) | yyh-001 | MIT | 可选（只影响表情包规则是否生效） |
| [dsh-dream-skin](https://github.com/RevolutionLA/dsh-dream-skin) | RevolutionLA | MIT | 常用 |
| [dsh-ui-boost](https://github.com/DoshinJiu/dsh-ui-boost) | DoshinJiu | MIT | 可选 |
| [dsh-anime-theme](https://github.com/zxr2115-1/dsh-anime-theme) | zxr2115-1 | MIT | **非必要**（纯外观，与 dsh-dream-skin 壁纸功能重叠） |

上表"必要性"一列描述的只是**本仓库对它们的依赖程度**：本仓库的两套预设、人设、
世界书与记忆**一个都不依赖**，全部零依赖运行；列在这里仅因为使用者常把它们搭配使用。

表情图库与壁纸图片的版权归各自作者所有。

## 6. 使用者的责任

1. 若你**不再需要**人设文本，可以直接删除预设 `agent.cordis.yml` 中的相关内容，
   或改用空白模板——本插件的装配机制不依赖具体人设。
2. 若你在其基础上**继续创作**并公开分发，请保留本文件与许可证副本，
   并同样声明角色 IP 归属与禁止商业使用。
3. 请勿声称本插件是官方作品，或暗示得到 IP 方授权。

## 7. 设计与参考实现

这一节不涉及第三方内容授权，而是说明**本项目的设计站在谁的肩膀上**。

### 世界书条目的格式与字段语义

条目格式与字段含义来自 Cyrene-Agent 的 `src/main/rag/worldbook.ts`，不是本项目发明的
（详见第 1 节「条目格式与字段语义的来源」）。

### 注入通道的做法参考了谁

「命中块挂在 `agent/pre-step` 上」这个做法**不是本项目想出来的**，而是参考了两个
社区插件（代码一行未抄，两者的实现思路与代码结构都不同）：

- [dsh-local-vector-memory](https://github.com/liangxiaobing520/dsh-local-vector-memory)
  —— 用 `agent/pre-step`，本轮输入就是它的 `messages` 参数
- [dsh-universal-worldbook](https://github.com/TritiumWang/dsh-universal-worldbook)
  —— 用 `llm/stream` 改写出站请求

本项目在这条路上的额外工作是**把「为什么只能这么做」挖清楚并写下来**：

- 装配（`assemble()`）跑在用户消息落库（`session.append`）**之前**，所以任何在装配期
  求值的 provider 读会话都拿不到本轮消息 —— 而空文本的 section 会被静默过滤掉，
  表现是"什么都没有发生"；
- `options.messages` 是**冻结**的，所以 `llm/stream` 那套「重建请求对象 + 重调
  `llm.stream()` + 重入守卫」是被 API 逼出来的唯一做法，不是偷懒；
- 预设作用域内调用 `ctx.provide()` 会被 `leakedServices` 校验判为污染进程全局，
  导致**整个预设挂载失败**（连新建会话都会出问题）。

### 消息编辑的语义参考了谁

「只换这一条 / 连同后续一起撤回」这两种保存语义**不是本项目想出来的**，参考了两个社区插件
（0.2.x 生态，代码一行未抄；它们依赖 DSH 0.2.x 的接口，本项目的实现只依赖 0.1.5 就有的事件日志）：

- [sh1robana/dsh-plugin-message-edit](https://github.com/sh1robana/dsh-plugin-message-edit)
  —— 「保存」（保留后续回复）与「保存并发送」（分支重发）两档，另有附件编辑与版本时间线。
- [Moeblack/dsh-message-edit](https://github.com/Moeblack/dsh-message-edit) —— 上面那个项目的上游。

两者的实现都用会话的**表面替换**（`surfaceOp: replace`），与本项目一致：只替换用户消息节点
（保留后续）或替换到末尾（撤回后续），旧事件仍留在 append-only 日志里。
区别于它们的是：本项目只做「最后一条用户消息」，不做附件编辑、分支会话与版本时间线。

### 预设与装配格式

`agent.cordis.yml` 的格式、`complete: true` 的语义、`systemPrompt.context()` 与
`agent/pre-step` 这些扩展点，都是 DeepSeek Harness 提供的，非本项目发明。

### 记忆的三层结构参考了谁

「四问锚点 / 归档 / 扉页」这套结构**不是本项目发明的**，思路来自两个社区项目
（代码一行未抄，实现方式、存储格式、工具面都不同）：

- [YOGEMOW/dsh-cyrene-eternal-page-remembrance](https://github.com/YOGEMOW/dsh-cyrene-eternal-page-remembrance)
  —— 「一页永恒·记忆」：四问锚点、按 锚/日/月/年 分层归档、独立的「余页」纸页、
  配额管理，以及「写进记忆不向对方汇报」这条边界。本项目借的是**这几个概念**
  （「四问」「余页」都是该项目 README 名字表里列在自己名下的东西）。
  **本项目把「余页」改称「扉页」**（标题页：翻开记忆先看到的那一页）——
  改名只是为了贴合我们自己的说法，不表示抹掉出处；对应物是 `cyrene-page.md`。
  实现也不同：锚点固定四节、归档是文件里的一段标记而不是目录树、
  扉页是单个 md 文件（64 KB 上限）。没有引入它的 11 个 `memory_*` 工具、
  思源镜像与夜间调度器。
- [feverZHONG/liya-sillytavern-worldbook](https://github.com/feverZHONG/liya-sillytavern-worldbook)
  —— SillyTavern 世界书写法的方法论。本项目借的是**判断口径**（首句自报家门、
  只留事实、单条要短），不是它的具体数值；`scripts/worldbook-audit.mjs` 按这套口径
  给自己打分（见第 1 节「世界书数据」与 README 的体检一节）。

两份参考资料都没有被复制进本仓库，也不构成对本仓库的授权约束；它们的许可证归各自作者。

### 本项目自己写的部分

`index.js`、`memory.js`、`nickname.js`、`worldbook/` 下的全部代码，以及 `scripts/`、
预设的组装方式。这些是原创代码，未复制任何上游或社区插件的实现。

## 8. 遇到异议时

本项目已就提示词文本的整理与再分发取得原作者同意（见第 1 节「授权确认」）。
但若日后 **IP 方（HoYoverse / 米哈游）** 或任何相关方对本仓库的分发提出异议，
维护者应配合下架相关内容，或改为「只分发插件骨架、由使用者自备人设」的形式。
