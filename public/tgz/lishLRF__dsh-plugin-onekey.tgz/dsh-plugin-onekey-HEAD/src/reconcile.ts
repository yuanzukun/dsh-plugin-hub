/**
 * Reconcile `dsh.profile.bundles` against the installed dependency state —
 * the same semantics as the `dsh plugin` CLI (apps/cli/src/plugin.ts):
 * a dependency resolving to a `dsh.bundle`-declaring package joins the layer
 * stack; a dependency-managed entry that no longer does leaves it. Template
 * bundles are not dependencies and are never touched.
 */

export interface ReconcileResult {
  bundles: string[]
  changed: boolean
}

/**
 * @param beforeDeps - dependency names before the pnpm operation.
 * @param dependencies - the installed dependency map after the operation.
 * @param bundles - the current `dsh.profile.bundles` list.
 * @param isBundle - verdict over the INSTALLED package (true when its
 *   manifest declares `dsh.bundle.patch`).
 */
export function reconcileBundles(
  beforeDeps: ReadonlySet<string>,
  dependencies: Readonly<Record<string, string>>,
  bundles: readonly string[],
  isBundle: (name: string) => boolean,
): ReconcileResult {
  const next = [...bundles]
  const dependencySet = new Set(Object.keys(dependencies))
  let changed = false
  for (const name of Object.keys(dependencies)) {
    if (isBundle(name) && !next.includes(name)) {
      next.push(name)
      changed = true
    }
  }
  for (const name of [...next]) {
    const wasDependency = beforeDeps.has(name) || dependencySet.has(name)
    const stillBundle = dependencySet.has(name) && isBundle(name)
    if (wasDependency && !stillBundle) {
      next.splice(next.indexOf(name), 1)
      changed = true
    }
  }
  return { bundles: next, changed }
}
