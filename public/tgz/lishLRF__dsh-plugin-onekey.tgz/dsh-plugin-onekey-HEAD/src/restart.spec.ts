import { describe, expect, it } from 'vitest'
import { buildRelauncherScript, type RelaunchSnapshot } from './restart'

const snapshot: RelaunchSnapshot = {
  execPath: 'C:\\node\\node.exe',
  execArgv: [],
  args: ['C:\\npm\\dsh\\bin\\dsh.js', 'web'],
  cwd: 'C:\\Users\\me\\project',
  env: { DSH_HOME: 'C:\\Users\\me\\.dsh' },
}

describe('buildRelauncherScript', () => {
  it('generates a script that polls the old pid until it is gone', () => {
    const script = buildRelauncherScript(12345, snapshot)
    expect(script).toContain('process.kill')
    expect(script).toContain('12345')
    expect(script).toContain('spawn')
  })

  it('re-spawns the exact recorded command without a shell', () => {
    const script = buildRelauncherScript(12345, snapshot)
    const marker = 'C:\\\\npm\\\\dsh\\\\bin\\\\dsh.js'
    expect(script).toContain(marker)
    expect(script).toContain('detached: true')
    expect(script).toContain('shell: false')
  })

  it('serializes env and cwd of the original launch', () => {
    const script = buildRelauncherScript(12345, snapshot)
    expect(script).toContain('C:\\\\Users\\\\me\\\\.dsh')
    expect(script).toContain('C:\\\\Users\\\\me\\\\project')
  })

  it('bounds the wait with a timeout and exits anyway', () => {
    const script = buildRelauncherScript(12345, snapshot, { timeoutMs: 5000, pollMs: 100 })
    expect(script).toContain('5000')
    expect(script).toContain('100')
    expect(script).toContain('process.exit')
  })

  it('writes a step log so relaunch failures are diagnosable', () => {
    const script = buildRelauncherScript(12345, snapshot, { logPath: 'C:\\tmp\\relaunch.log' })
    expect(script).toContain('C:\\\\tmp\\\\relaunch.log')
    expect(script).toContain('appendFileSync')
  })

  it('settles after the old pid dies before spawning (socket teardown safety)', () => {
    const script = buildRelauncherScript(12345, snapshot, { settleMs: 1500 })
    expect(script).toContain('1500')
    expect(script).toContain('settle')
  })

  it('retries the spawn when the child crashes quickly', () => {
    const script = buildRelauncherScript(12345, snapshot, { retries: 5, backoffMs: 2000 })
    expect(script).toContain('retries')
    expect(script).toContain('5')
    expect(script).toContain('2000')
    expect(script).toContain('attempt')
  })

  it('replays the node exec flags before the script args (loader flags survive)', () => {
    const script = buildRelauncherScript(12345, {
      ...snapshot,
      execArgv: ['--import', 'tsx/esm'],
      args: ['apps\\cli\\src\\bin.ts', 'web'],
    })
    expect(script).toContain('snapshot.execArgv')
    expect(script).toContain('"tsx/esm"')
    expect(script).toContain('...snapshot.execArgv')
    expect(script).toContain('apps\\\\cli\\\\src\\\\bin.ts')
  })
})
