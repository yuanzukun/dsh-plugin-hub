/**
 * dsh-plugin-onekey host entry.
 *
 * Assembles the auto-detected environment (profile from ctx.baseUrl, pnpm
 * from PATH, relaunch snapshot from process argv), the permission-gated
 * OneKeyService, the `/plugins/onekey` HTTP routes, and the settings
 * namespace whose live value gates everything. Every registration is an
 * effect: disable or uninstall the plugin and all of it disappears.
 */
import { spawn, spawnSync } from 'node:child_process'
import { randomUUID } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { createRequire } from 'node:module'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { clipboardReadCommand } from './clipboard.ts'
import { Config, DEFAULT_CONFIG, NS, type Config as ConfigEntry } from './config.ts'
import { captureRelaunchSnapshot, pnpmAvailable, profileFromBaseUrl } from './detect.ts'
import { buildRelauncherScript } from './restart.ts'
import { registerRoutes, type WebServerLike } from './routes.ts'
import { OneKeyService, type ProfileManifest, type ServiceIO } from './service.ts'

export const name = 'dsh-plugin-onekey'

/** The services this plugin needs; it stays pending until they exist. */
export const inject = ['webServer']

/** Structural slice of the cordis context this plugin touches. */
interface HostContext {
  baseUrl?: string
  get<T = unknown>(serviceName: string): T | undefined
  inject(services: string[], callback: (ctx: HostContext) => void): void
  effect(callback: () => (() => void) | void, label?: string): void
  logger?: { warn(message: unknown, ...args: unknown[]): void }
}

/** Structural slice of the settings service (SettingsProvider). */
interface SettingsServiceLike {
  register<T>(
    ns: string,
    schema: unknown,
    options?: { base?: Partial<T>; applies?: 'live' | 'restart' },
  ): { get(): T; watch(callback: (next: T, prev: T) => void): () => void }
}

export { Config, NS, DEFAULT_CONFIG } from './config.ts'
export type { Config as ConfigEntry } from './config.ts'
export { buildRelauncherScript } from './restart.ts'
export type { RelaunchSnapshot, RelauncherOptions } from './restart.ts'

/**
 * @param ctx - plugin context.
 * @param entry - composition config (the cordis.patch row); absent = defaults.
 */
export function apply(ctx: HostContext, entry?: Partial<ConfigEntry>): void {
  const baseConfig: ConfigEntry = { ...DEFAULT_CONFIG, ...(entry ?? {}) }
  let live: ConfigEntry = baseConfig

  const profile = profileFromBaseUrl(ctx.baseUrl)
  const pnpm = pnpmAvailable(process.env.PATH, process.platform, existsSync)
  const restartSnapshot = captureRelaunchSnapshot({
    execPath: process.execPath,
    execArgv: process.execArgv,
    argv: process.argv,
    cwd: process.cwd(),
    env: process.env,
  })

  const io: ServiceIO = {
    profileDir: profile?.dir ?? '',
    profileName: profile?.name ?? 'unknown',
    platform: process.platform,
    pnpmAvailable: pnpm !== null,
    restartSnapshot,
    selfName: name,
    hubName: 'dsh-plugin',
    readClipboard: () => {
      const command = clipboardReadCommand(process.platform)
      if (command === null) return null
      try {
        const result = spawnSync(command.cmd, command.args, {
          encoding: 'utf8',
          timeout: 5000,
          windowsHide: true,
          stdio: ['ignore', 'pipe', 'pipe'],
        })
        if (result.status !== 0 || result.error !== undefined) return null
        return result.stdout ?? null
      } catch {
        return null
      }
    },
    runPnpm: async (args, onOutput) => {
      if (pnpm === null || profile === null) {
        onOutput('pnpm not found on PATH — install pnpm (or enable corepack) and retry')
        return 127
      }
      return await new Promise<number>((resolve) => {
        const child = spawn(pnpm.cmd, [...pnpm.prefixArgs, ...args], {
          cwd: profile.dir,
          shell: pnpm.shell,
          env: process.env,
          windowsHide: true,
          stdio: ['ignore', 'pipe', 'pipe'],
        })
        let buffer = ''
        const drain = (chunk: Buffer) => {
          buffer += chunk.toString('utf8')
          const lines = buffer.split(/\r?\n/u)
          buffer = lines.pop() ?? ''
          for (const line of lines) onOutput(line)
        }
        child.stdout?.on('data', drain)
        child.stderr?.on('data', drain)
        child.on('error', (error) => {
          onOutput(String(error))
          resolve(-1)
        })
        child.on('close', (code) => {
          if (buffer.trim() !== '') onOutput(buffer)
          resolve(code ?? -1)
        })
      })
    },
    readManifest: (): ProfileManifest => {
      if (profile === null) return {}
      try {
        return JSON.parse(readFileSync(join(profile.dir, 'package.json'), 'utf8')) as ProfileManifest
      } catch {
        return {}
      }
    },
    writeManifest: (manifest) => {
      if (profile === null) return
      writeFileSync(join(profile.dir, 'package.json'), `${JSON.stringify(manifest, null, 2)}\n`)
    },
    isBundle: (packageName) => {
      if (profile === null) return false
      try {
        const require = createRequire(join(profile.dir, 'package.json'))
        const packagePath = require.resolve(`${packageName}/package.json`)
        const pkg = JSON.parse(readFileSync(packagePath, 'utf8')) as { dsh?: { bundle?: { patch?: unknown } } }
        return pkg.dsh?.bundle?.patch !== undefined
      } catch {
        return false
      }
    },
    spawnRelauncher: (oldPid, snapshot) => {
      try {
        const dir = join(tmpdir(), 'dsh-plugin-onekey')
        mkdirSync(dir, { recursive: true })
        const scriptPath = join(dir, 'relaunch.cjs')
        const logPath = join(dir, 'relaunch.log')
        const outputPath = join(dir, 'relaunch-dsh.log')
        const script = buildRelauncherScript(oldPid, snapshot, {
          logPath,
          outPath: outputPath,
          errPath: outputPath,
        })
        writeFileSync(scriptPath, script, 'utf8')
        const child = spawn(process.execPath, [scriptPath], {
          detached: true,
          stdio: 'ignore',
          windowsHide: true,
        })
        child.on('error', (error) => {
          console.error('[dsh-plugin-onekey] relauncher spawn failed:', error)
        })
        child.unref()
      } catch (error) {
        console.error('[dsh-plugin-onekey] relauncher setup failed:', error)
      }
    },
    exit: (code) => {
      setTimeout(() => process.exit(code), 400)
    },
    makeId: () => randomUUID(),
  }

  const service = new OneKeyService(io, () => live)

  ctx.inject(['webServer'], (sctx) => {
    const webServer = sctx.get<WebServerLike>('webServer')
    if (webServer === undefined) return
    sctx.effect(
      () => registerRoutes(webServer, service, (error) => {
        sctx.logger?.warn('dsh-plugin-onekey: route error', error)
      }),
      'dsh-plugin-onekey: routes',
    )
  })

  // Live configuration: Settings → Plugins → Plugin configuration edits this
  // namespace; every committed change re-gates the service immediately.
  ctx.inject(['settings'], (sctx) => {
    const settings = sctx.get<SettingsServiceLike>('settings')
    if (settings === undefined) return
    const scope = settings.register<ConfigEntry>(NS, Config, { base: baseConfig, applies: 'live' })
    live = scope.get()
    sctx.effect(() => () => {
      live = baseConfig
    }, 'dsh-plugin-onekey: settings detach')
    scope.watch(() => {
      live = scope.get()
    })
  })
}
