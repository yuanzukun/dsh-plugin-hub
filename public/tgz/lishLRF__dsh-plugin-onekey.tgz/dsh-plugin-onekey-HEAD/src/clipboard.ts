/**
 * Platform clipboard read command (host side). The backend reads the OS
 * clipboard after the client signals that the user clicked "copy install
 * command" in the plugin hub.
 */

export interface ClipboardCommand {
  cmd: string
  args: string[]
}

export function clipboardReadCommand(platform: NodeJS.Platform): ClipboardCommand | null {
  if (platform === 'win32') {
    return { cmd: 'powershell', args: ['-NoProfile', '-Command', 'Get-Clipboard -Raw'] }
  }
  if (platform === 'darwin') {
    return { cmd: 'pbpaste', args: [] }
  }
  if (platform === 'linux') {
    return { cmd: 'xclip', args: ['-selection', 'clipboard', '-o'] }
  }
  return null
}
