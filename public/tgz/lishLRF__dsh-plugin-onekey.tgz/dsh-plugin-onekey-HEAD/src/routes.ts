/**
 * HTTP route adapter: exposes the OneKeyService under `/plugins/onekey/*`.
 * Thin glue over the DSH webserver prefix registry — all logic lives in the
 * service, which stays fully unit-tested.
 */
import type { IncomingMessage, ServerResponse } from 'node:http'
import type { OneKeyService } from './service.ts'

/** The slice of the DSH webserver service this plugin registers against. */
export interface WebServerLike {
  register(route: {
    kind: 'prefix'
    path: string
    handler: (req: IncomingMessage, res: ServerResponse) => Promise<void>
  }): () => void
}

const PREFIX = '/plugins/onekey'
const MAX_BODY_BYTES = 64 * 1024

function writeJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
  res.end(payload)
}

/** Read a JSON body with a size cap; resolves null for an empty body. */
function readJsonBody(req: IncomingMessage): Promise<{ ok: true; value: unknown } | { ok: false; status: number }> {
  return new Promise((resolve) => {
    const chunks: Buffer[] = []
    let size = 0
    req.on('data', (chunk: Buffer | string) => {
      const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
      size += buffer.length
      if (size > MAX_BODY_BYTES) {
        resolve({ ok: false, status: 413 })
        req.destroy()
        return
      }
      chunks.push(buffer)
    })
    req.on('end', () => {
      const text = Buffer.concat(chunks).toString('utf8')
      if (text.trim() === '') {
        resolve({ ok: true, value: {} })
        return
      }
      try {
        resolve({ ok: true, value: JSON.parse(text) as unknown })
      } catch {
        resolve({ ok: false, status: 400 })
      }
    })
    req.on('error', () => resolve({ ok: false, status: 400 }))
  })
}

/** Narrow an unknown JSON value to a record. */
function asRecord(value: unknown): Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {}
}

/** One request's resolved verb + target (unused targets are null). */
interface Route {
  method: 'GET' | 'POST'
  target: 'ping' | 'state' | 'removable' | 'install' | 'uninstall' | 'restart' | 'job'
  jobId?: string
}

function routeOf(method: string | undefined, pathname: string): Route | null {
  const suffix = pathname.startsWith(PREFIX) ? pathname.slice(PREFIX.length) : null
  if (suffix === null) return null
  const normalized = suffix === '' ? '/' : suffix
  if (normalized === '/ping') return { method: 'GET', target: 'ping' }
  if (normalized === '/state') return { method: 'GET', target: 'state' }
  if (normalized === '/removable') return { method: 'GET', target: 'removable' }
  if (normalized === '/install') return { method: 'POST', target: 'install' }
  if (normalized === '/uninstall') return { method: 'POST', target: 'uninstall' }
  if (normalized === '/restart') return { method: 'POST', target: 'restart' }
  const jobMatch = /^\/jobs\/([^/]+)$/u.exec(normalized)
  if (jobMatch !== null) {
    return { method: 'GET', target: 'job', jobId: decodeURIComponent(jobMatch[1] as string) }
  }
  return null
}

/**
 * Register the plugin's routes on the webserver. The returned disposer
 * removes them again — capability rides the plugin fiber.
 */
export function registerRoutes(
  webServer: WebServerLike,
  service: OneKeyService,
  onError: (error: unknown) => void = (error) => console.error('[dsh-plugin-onekey] route error:', error),
): () => void {
  return webServer.register({
    kind: 'prefix',
    path: PREFIX,
    handler: async (req, res) => {
      try {
        const pathname = decodeURIComponent(new URL(req.url ?? '/', 'http://x').pathname)
        const route = routeOf(req.method, pathname)
        if (route === null) {
          writeJson(res, 404, { error: 'not-found' })
          return
        }
        if (req.method !== route.method) {
          writeJson(res, 405, { error: 'method-not-allowed' })
          return
        }
        if (route.target === 'ping') {
          writeJson(res, 200, { ok: true })
          return
        }
        if (route.target === 'job' && route.jobId !== undefined) {
          const result = service.job(route.jobId)
          writeJson(res, result.status, result.body)
          return
        }
        const result = await (async () => {
          switch (route.target) {
            case 'state': return service.state()
            case 'removable': return service.removable()
            case 'install': {
              const body = await readJsonBody(req)
              if (!body.ok) return { status: body.status, body: { error: 'bad-request' } }
              return service.install(asRecord(body.value)['text'] as string | undefined)
            }
            case 'uninstall': {
              const body = await readJsonBody(req)
              if (!body.ok) return { status: body.status, body: { error: 'bad-request' } }
              const name = asRecord(body.value)['name']
              return service.uninstall(typeof name === 'string' ? name : '')
            }
            case 'restart': return service.restart()
            default: return { status: 404, body: { error: 'not-found' } }
          }
        })()
        writeJson(res, result.status, result.body)
      } catch (error) {
        onError(error)
        if (!res.headersSent) writeJson(res, 500, { error: 'internal-error' })
        else res.end()
      }
    },
  })
}
