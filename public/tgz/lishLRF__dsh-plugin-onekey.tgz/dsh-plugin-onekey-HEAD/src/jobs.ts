/**
 * Install-job state machine (host side, pure). One job per install request;
 * the HTTP layer polls the registry this state feeds.
 */

export type JobPhase = 'parsing' | 'validating' | 'running' | 'reconciling' | 'done' | 'failed'

export interface Job {
  id: string
  command: string
  phase: JobPhase
  percent: number
  log: string[]
  error?: string
  done: boolean
}

export type JobEvent =
  | { type: 'phase'; phase: JobPhase; percent?: number }
  | { type: 'log'; line: string }
  | { type: 'fail'; error: string }
  | { type: 'done' }

const MAX_LOG_LINES = 200

const clamp = (value: number): number => Math.min(100, Math.max(0, value))

export function createJob(id: string, command: string): Job {
  return { id, command, phase: 'parsing', percent: 5, log: [], done: false }
}

/** Apply one event; settled jobs (done/failed) ignore every later event. */
export function applyJob(job: Job, event: JobEvent): Job {
  if (job.done) return job
  if (event.type === 'log') {
    return { ...job, log: [...job.log, event.line].slice(-MAX_LOG_LINES) }
  }
  if (event.type === 'fail') {
    return { ...job, phase: 'failed', done: true, error: event.error }
  }
  if (event.type === 'done') {
    return { ...job, phase: 'done', percent: 100, done: true }
  }
  const percent = event.percent === undefined ? job.percent : clamp(event.percent)
  return { ...job, phase: event.phase, percent: Math.max(job.percent, percent) }
}
