import { describe, expect, it } from 'vitest'
import { clipboardReadCommand } from './clipboard'

describe('clipboardReadCommand', () => {
  it('uses Get-Clipboard on Windows', () => {
    const cmd = clipboardReadCommand('win32')
    expect(cmd).toEqual({ cmd: 'powershell', args: ['-NoProfile', '-Command', 'Get-Clipboard -Raw'] })
  })

  it('uses pbpaste on macOS', () => {
    expect(clipboardReadCommand('darwin')).toEqual({ cmd: 'pbpaste', args: [] })
  })

  it('uses xclip on Linux', () => {
    expect(clipboardReadCommand('linux')).toEqual({ cmd: 'xclip', args: ['-selection', 'clipboard', '-o'] })
  })

  it('returns null on unsupported platforms', () => {
    expect(clipboardReadCommand('freebsd' as NodeJS.Platform)).toBeNull()
  })
})
