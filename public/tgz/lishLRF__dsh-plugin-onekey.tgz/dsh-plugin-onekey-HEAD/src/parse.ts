/**
 * Strict whitelist parser for the clipboard payload the plugin hub copies
 * (`dsh plugin add <spec>`). Security core: anything that is not a plain
 * install command is rejected before it can reach a child process.
 */

/** A validated install request ready for execution. */
export interface ParsedInstall {
  /** pnpm-acceptable spec (a bare `owner/repo` is mapped to `github:owner/repo`). */
  spec: string
  /** The spec exactly as the user copied it. */
  display: string
  /** `--profile` value when present. */
  profile?: string
  /** Canonical command line for display (never executed). */
  command: string
}

export type ParseResult = { ok: true; parsed: ParsedInstall } | { ok: false; reason: string }

const MAX_LENGTH = 500

/** `dsh plugin [--profile X] (add|install) <spec>` — one line, nothing else. */
const COMMAND_PATTERN = /^dsh\s+plugin\s+(?:--profile\s+(\S+)\s+)?(?:add|install)\s+(\S+)$/u

const PROFILE_PATTERN = /^[A-Za-z0-9._-]+$/u

/** `github:owner/repo[#ref]` — owner and repo must start with an alphanumeric (`.`/`..` paths excluded). */
const GITHUB_PATTERN = /^github:[A-Za-z0-9][A-Za-z0-9._-]*\/[A-Za-z0-9][A-Za-z0-9._-]*(?:#[A-Za-z0-9._-]+)?$/u

/** bare `owner/repo[#ref]` — the exact format the plugin hub copies; same leading-char rule. */
const BARE_REPO_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]*\/[A-Za-z0-9][A-Za-z0-9._-]*(?:#[A-Za-z0-9._-]+)?$/u

/** scoped npm name `@scope/name` (no version — the hub never copies one for scoped). */
const SCOPED_NPM_PATTERN = /^@[a-z0-9][a-z0-9._-]*\/[a-z0-9][a-z0-9._-]*$/u

/** unscoped npm name, optional `@tag`/`@version`. */
const NPM_PATTERN = /^[a-z0-9][a-z0-9._-]*(?:@[a-z0-9][a-z0-9._-]*)?$/u

/** `git+https://…` / `git+http://…` */
const GIT_URL_PATTERN = /^git\+https?:\/\/\S+$/u

/** https/http tarball URLs only. */
const TARBALL_PATTERN = /^https?:\/\/\S+\.tgz(?:#\S+)?$/u

/**
 * Parse one clipboard payload into a validated install request.
 * @param text - raw clipboard text (may carry trailing whitespace/newline).
 * @returns the parsed request, or a machine-readable rejection reason.
 */
export function parseInstallCommand(text: string): ParseResult {
  const line = text.trim()
  if (line.length === 0) return { ok: false, reason: 'empty' }
  if (line.length > MAX_LENGTH) return { ok: false, reason: 'too-long' }
  // A trimmed payload must still be a single line: embedded newlines mean a
  // multi-command paste.
  if (/[\r\n]/u.test(line)) return { ok: false, reason: 'multiline' }
  const match = COMMAND_PATTERN.exec(line)
  if (match === null) return { ok: false, reason: 'not-a-command' }
  const profile = match[1]
  const display = match[2] as string
  if (profile !== undefined && !PROFILE_PATTERN.test(profile)) return { ok: false, reason: 'bad-profile' }
  const spec = normalizeSpec(display)
  if (spec === null) return { ok: false, reason: 'unsafe-spec' }
  const command = `dsh plugin${profile === undefined ? '' : ` --profile ${profile}`} add ${display}`
  return {
    ok: true,
    parsed: { spec, display, ...(profile === undefined ? {} : { profile }), command },
  }
}

/** Map an accepted display spec to its pnpm form; null = rejected. */
function normalizeSpec(display: string): string | null {
  if (GITHUB_PATTERN.test(display) || BARE_REPO_PATTERN.test(display)) {
    return display.startsWith('github:') ? display : `github:${display}`
  }
  if (SCOPED_NPM_PATTERN.test(display) || NPM_PATTERN.test(display)) return display
  if (GIT_URL_PATTERN.test(display) || TARBALL_PATTERN.test(display)) return display
  return null
}
