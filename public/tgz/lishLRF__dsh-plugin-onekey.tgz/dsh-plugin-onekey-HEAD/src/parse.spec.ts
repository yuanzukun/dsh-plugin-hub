import { describe, expect, it } from 'vitest'
import { parseInstallCommand } from './parse'

const ok = (text: string) => expect(parseInstallCommand(text).ok).toBe(true)
const err = (text: string) => {
  const result = parseInstallCommand(text)
  expect(result.ok).toBe(false)
  return result
}

describe('parseInstallCommand', () => {
  describe('accepts the forms the plugin hub and the dsh CLI produce', () => {
    it('accepts the bare owner/repo form the hub copies and maps it to github:', () => {
      const result = parseInstallCommand('dsh plugin add liustack/modlens')
      expect(result).toEqual({
        ok: true,
        parsed: {
          spec: 'github:liustack/modlens',
          display: 'liustack/modlens',
          command: 'dsh plugin add liustack/modlens',
        },
      })
    })

    it('accepts a github: spec verbatim', () => {
      const result = parseInstallCommand('dsh plugin add github:dshplugin/dsh-plugin-hub')
      expect(result.ok && result.parsed.spec).toBe('github:dshplugin/dsh-plugin-hub')
    })

    it('accepts a github: spec with a ref', () => {
      const result = parseInstallCommand('dsh plugin add github:some/repo#main')
      expect(result.ok && result.parsed.spec).toBe('github:some/repo#main')
    })

    it('accepts a bare owner/repo with a ref', () => {
      const result = parseInstallCommand('dsh plugin add some/repo#v1.2.3')
      expect(result.ok && result.parsed.spec).toBe('github:some/repo#v1.2.3')
    })

    it('accepts the --profile form and records the profile', () => {
      const result = parseInstallCommand('dsh plugin --profile web add liustack/modlens')
      expect(result).toMatchObject({ ok: true, parsed: { profile: 'web', spec: 'github:liustack/modlens' } })
    })

    it('accepts an unscoped npm name', () => {
      const result = parseInstallCommand('dsh plugin add dsh-plugin')
      expect(result.ok && result.parsed.spec).toBe('dsh-plugin')
    })

    it('accepts a scoped npm name', () => {
      const result = parseInstallCommand('dsh plugin add @scope/pkg')
      expect(result.ok && result.parsed.spec).toBe('@scope/pkg')
    })

    it('accepts an npm name with a version tag', () => {
      const result = parseInstallCommand('dsh plugin add lodash@4.17.21')
      expect(result.ok && result.parsed.spec).toBe('lodash@4.17.21')
    })

    it('accepts a git+https URL', () => {
      const result = parseInstallCommand('dsh plugin add git+https://github.com/a/b.git')
      expect(result.ok && result.parsed.spec).toBe('git+https://github.com/a/b.git')
    })

    it('accepts an https tarball URL', () => {
      const result = parseInstallCommand('dsh plugin add https://example.com/pkg.tgz')
      expect(result.ok && result.parsed.spec).toBe('https://example.com/pkg.tgz')
    })

    it('accepts the install alias verb', () => {
      ok('dsh plugin install dsh-plugin')
    })

    it('tolerates surrounding whitespace and a single trailing newline', () => {
      const result = parseInstallCommand('  dsh plugin add dsh-plugin  \n')
      expect(result.ok && result.parsed.spec).toBe('dsh-plugin')
    })
  })

  describe('rejects anything that is not a plain install command', () => {
    it('rejects empty input', () => {
      err('')
    })

    it('rejects non-dsh commands', () => {
      err('pnpm add dsh-plugin')
      err('npm install dsh-plugin')
      err('echo hello')
    })

    it('rejects dsh plugin remove (uninstall is a separate flow)', () => {
      err('dsh plugin remove dsh-plugin')
    })

    it('rejects trailing extra tokens', () => {
      err('dsh plugin add dsh-plugin && echo pwned')
      err('dsh plugin add dsh-plugin; rm -rf /')
      err('dsh plugin add dsh-plugin | cat')
    })

    it('rejects file: and link: specs', () => {
      err('dsh plugin add file:../evil')
      err('dsh plugin add link:C:\\evil')
    })

    it('rejects relative and absolute path specs', () => {
      err('dsh plugin add ./pkg')
      err('dsh plugin add ../pkg')
      err('dsh plugin add /etc/pkg')
      err('dsh plugin add C:\\pkg')
    })

    it('rejects quoted specs', () => {
      err('dsh plugin add "dsh-plugin"')
    })

    it('rejects multiline payloads', () => {
      err('dsh plugin add dsh-plugin\nrm -rf /')
    })

    it('rejects shell metacharacters anywhere', () => {
      err('dsh plugin add $(touch pwned)')
      err('dsh plugin add `touch pwned`')
      err('dsh plugin add dsh-plugin&')
      err('dsh plugin add a>b')
    })

    it('rejects overlong input', () => {
      err(`dsh plugin add ${'a'.repeat(600)}`)
    })

    it('rejects a spec that is only scheme garbage', () => {
      err('dsh plugin add github:')
      err('dsh plugin add /')
      err('dsh plugin add a/')
    })
  })
})
