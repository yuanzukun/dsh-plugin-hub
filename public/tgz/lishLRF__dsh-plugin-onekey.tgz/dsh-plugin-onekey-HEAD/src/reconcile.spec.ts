import { describe, expect, it } from 'vitest'
import { reconcileBundles } from './reconcile'

/** isBundle over a fixed name set — mirrors the CLI's exportsPatch verdict. */
const bundlesOf = (...names: string[]) => (name: string) => names.includes(name)

describe('reconcileBundles', () => {
  it('appends a newly installed bundle dependency to the layer stack', () => {
    const result = reconcileBundles(
      new Set(['dsh-plugin']),
      { 'dsh-plugin': '0.1.1', 'dsh-plugin-onekey': '0.1.0' },
      ['@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app', 'dsh-plugin'],
      bundlesOf('dsh-plugin', 'dsh-plugin-onekey'),
    )
    expect(result.changed).toBe(true)
    expect(result.bundles).toEqual([
      '@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app', 'dsh-plugin', 'dsh-plugin-onekey',
    ])
  })

  it('removes a dependency that is no longer installed from the stack', () => {
    const result = reconcileBundles(
      new Set(['dsh-plugin', 'gone-plugin']),
      { 'dsh-plugin': '0.1.1' },
      ['@deepseek-ai/dsh-base', 'dsh-plugin', 'gone-plugin'],
      bundlesOf('dsh-plugin', 'gone-plugin'),
    )
    expect(result.changed).toBe(true)
    expect(result.bundles).toEqual(['@deepseek-ai/dsh-base', 'dsh-plugin'])
  })

  it('removes a dependency whose installed version dropped the dsh.bundle declaration', () => {
    const result = reconcileBundles(
      new Set(['dsh-plugin', 'drifted']),
      { 'dsh-plugin': '0.1.1', 'drifted': '2.0.0' },
      ['dsh-plugin', 'drifted'],
      bundlesOf('dsh-plugin'),
    )
    expect(result.changed).toBe(true)
    expect(result.bundles).toEqual(['dsh-plugin'])
  })

  it('activates a dependency that gained a bundle declaration in a newer version', () => {
    const result = reconcileBundles(
      new Set(['plain']),
      { plain: '2.0.0' },
      [],
      bundlesOf('plain'),
    )
    expect(result.changed).toBe(true)
    expect(result.bundles).toEqual(['plain'])
  })

  it('leaves a plain (bundle-less) new dependency out of the stack', () => {
    const result = reconcileBundles(
      new Set([]),
      { somelib: '1.0.0' },
      [],
      bundlesOf(),
    )
    expect(result.changed).toBe(false)
    expect(result.bundles).toEqual([])
  })

  it('never touches template bundles that are not dependencies', () => {
    const result = reconcileBundles(
      new Set([]),
      {},
      ['@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app'],
      bundlesOf(),
    )
    expect(result.changed).toBe(false)
    expect(result.bundles).toEqual(['@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app'])
  })

  it('reports unchanged when nothing moved', () => {
    const result = reconcileBundles(
      new Set(['dsh-plugin']),
      { 'dsh-plugin': '0.1.1' },
      ['dsh-plugin'],
      bundlesOf('dsh-plugin'),
    )
    expect(result.changed).toBe(false)
    expect(result.bundles).toEqual(['dsh-plugin'])
  })
})
