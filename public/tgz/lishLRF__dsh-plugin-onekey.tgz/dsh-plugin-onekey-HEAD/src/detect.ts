/**
 * Environment auto-detection (requirement: first deploy finds DSH itself —
 * no user configuration): profile directory from the config-tree anchor,
 * pnpm resolution from PATH with a corepack fallback, and the relaunch
 * snapshot covering every DSH install method.
 */
import { delimiter, join, basename } from 'node:path'
import { fileURLToPath } from 'node:url'
import type { RelaunchSnapshot } from './restart.ts'

/** Resolved profile location (the directory the profile package.json lives in). */
export interface ProfileInfo {
  dir: string
  name: string
}

/**
 * Resolve the profile from the cordis config-tree anchor. The DSH launcher
 * sets `ctx.baseUrl` to a file:// URL of the directory containing cordis.yml
 * (packages/boot/app-boot sets it to dirname(configPath) + '/'), which is
 * exactly the profile directory.
 */
export function profileFromBaseUrl(baseUrl: string | undefined): ProfileInfo | null {
  if (baseUrl === undefined) return null
  let url: URL
  try {
    url = new URL(baseUrl)
  } catch {
    return null
  }
  if (url.protocol !== 'file:') return null
  const dir = fileURLToPath(url)
  return { dir, name: basename(dir) }
}

/** How to invoke pnpm: direct, or through corepack, with or without a shell. */
export interface PnpmResolution {
  cmd: string
  /** Extra arguments inserted before the pnpm args (corepack: ['pnpm']). */
  prefixArgs: string[]
  /** Windows requires the .cmd shim, which node refuses to spawn without a shell. */
  shell: boolean
}

const WINDOWS_CANDIDATES = ['pnpm.CMD', 'pnpm.cmd', 'pnpm.exe', 'pnpm.BAT', 'pnpm'] as const
const POSIX_CANDIDATES = ['pnpm'] as const
const COREPACK_CANDIDATES = ['corepack.CMD', 'corepack.cmd', 'corepack.exe', 'corepack'] as const

/**
 * Decide how to invoke pnpm given the PATH and a file-existence predicate.
 * Mirrors the official `dsh plugin` CLI's trust boundary: on Windows the
 * .cmd shim needs `shell: true` (CVE-2024-27980 hardening); the args we pass
 * are whitelist-validated before they ever reach it.
 */
export function pnpmAvailable(
  pathEnv: string | undefined,
  platform: NodeJS.Platform,
  exists: (file: string) => boolean,
  pathDelimiter: string = delimiter,
): PnpmResolution | null {
  const dirs = (pathEnv ?? '').split(pathDelimiter).filter(dir => dir.length > 0)
  const candidates = platform === 'win32' ? WINDOWS_CANDIDATES : POSIX_CANDIDATES
  for (const dir of dirs) {
    for (const candidate of candidates) {
      if (exists(join(dir, candidate))) {
        return { cmd: 'pnpm', prefixArgs: [], shell: platform === 'win32' }
      }
    }
  }
  for (const dir of dirs) {
    for (const candidate of COREPACK_CANDIDATES) {
      if (exists(join(dir, candidate))) {
        return { cmd: 'corepack', prefixArgs: ['pnpm'], shell: platform === 'win32' }
      }
    }
  }
  return null
}

/** Process-shaped input for the relaunch snapshot capture. */
export interface ProcessLike {
  execPath: string
  /** Node execution flags — kept separate from the script args by node itself. */
  execArgv: string[]
  argv: string[]
  cwd: string
  env: NodeJS.ProcessEnv
}

/**
 * Record the exact launch command so a restart re-launches DSH the way it
 * was started. `execArgv` carries the loader flags (`--import tsx/esm` etc.)
 * that node strips out of `argv` — replaying both verbatim reproduces the
 * original process byte-for-byte, covering npm global, source checkout via
 * tsx, pnpm run-script and built binaries alike.
 */
export function captureRelaunchSnapshot(processLike: ProcessLike): RelaunchSnapshot {
  return {
    execPath: processLike.execPath,
    execArgv: [...processLike.execArgv],
    args: processLike.argv.slice(1),
    cwd: processLike.cwd,
    env: processLike.env,
  }
}
