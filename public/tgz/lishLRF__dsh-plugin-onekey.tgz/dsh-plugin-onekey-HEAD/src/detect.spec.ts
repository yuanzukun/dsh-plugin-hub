import { basename, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { describe, expect, it } from 'vitest'
import { captureRelaunchSnapshot, pnpmAvailable, profileFromBaseUrl } from './detect'

describe('profileFromBaseUrl', () => {
  it('resolves the profile directory and name from the config-tree anchor', () => {
    const profile = profileFromBaseUrl('file:///C:/Users/me/.dsh/profiles/web/')
    expect(profile).not.toBeNull()
    expect(profile!.name).toBe('web')
    expect(profile!.dir).toBe(fileURLToPath('file:///C:/Users/me/.dsh/profiles/web/'))
  })

  it('accepts a URL without the trailing slash', () => {
    const url = pathToFileURL(join('C:', 'x', 'tui')).href
    const profile = profileFromBaseUrl(url)
    expect(profile!.name).toBe('tui')
    expect(basename(profile!.dir)).toBe('tui')
  })

  it('returns null when the anchor is missing or not a file URL', () => {
    expect(profileFromBaseUrl(undefined)).toBeNull()
    expect(profileFromBaseUrl('http://example.com/profiles/web/')).toBeNull()
  })
})

describe('pnpmAvailable', () => {
  const fakeExists = (files: string[]) => (p: string) => files.includes(p)

  it('finds pnpm.CMD on Windows PATH', () => {
    const dir = 'C:\\tools\\pnpm'
    const available = pnpmAvailable(`C:\\Windows;${dir};C:\\node`, 'win32', fakeExists([join(dir, 'pnpm.CMD')]), ';')
    expect(available).toEqual({ cmd: 'pnpm', prefixArgs: [], shell: true })
  })

  it('falls back to pnpm.cmd casing on Windows', () => {
    const dir = 'C:\\tools\\pnpm'
    const available = pnpmAvailable(`${dir}`, 'win32', fakeExists([join(dir, 'pnpm.cmd')]), ';')
    expect(available).toEqual({ cmd: 'pnpm', prefixArgs: [], shell: true })
  })

  it('finds bare pnpm on POSIX PATH', () => {
    const dir = '/usr/local/bin'
    const available = pnpmAvailable(`/usr/bin:${dir}`, 'linux', fakeExists([join(dir, 'pnpm')]), ':')
    expect(available).toEqual({ cmd: 'pnpm', prefixArgs: [], shell: false })
  })

  it('falls back to corepack when pnpm is not on PATH', () => {
    const dir = 'C:\\node'
    const available = pnpmAvailable(`${dir}`, 'win32', fakeExists([join(dir, 'corepack.CMD')]), ';')
    expect(available).toEqual({ cmd: 'corepack', prefixArgs: ['pnpm'], shell: true })
  })

  it('returns null when neither pnpm nor corepack exists', () => {
    expect(pnpmAvailable('C:\\node', 'win32', fakeExists([]), ';')).toBeNull()
    expect(pnpmAvailable(undefined, 'linux', fakeExists([]))).toBeNull()
  })
})

describe('captureRelaunchSnapshot', () => {
  it('records execPath, execArgv, args, cwd and env verbatim', () => {
    const snapshot = captureRelaunchSnapshot({
      execPath: '/node/bin/node',
      execArgv: ['--import', 'tsx/esm'],
      argv: ['/node/bin/node', '/npm/dsh/bin/dsh.js', 'web'],
      cwd: '/home/me/project',
      env: { DSH_HOME: '/home/me/.dsh' },
    })
    expect(snapshot).toEqual({
      execPath: '/node/bin/node',
      execArgv: ['--import', 'tsx/esm'],
      args: ['/npm/dsh/bin/dsh.js', 'web'],
      cwd: '/home/me/project',
      env: { DSH_HOME: '/home/me/.dsh' },
    })
  })

  it('keeps the loader flags separate from the script args (node execArgv semantics)', () => {
    // Real pnpm run dsh web: node receives `--import tsx/esm` in execArgv and
    // the entry + CLI args in argv — replaying both verbatim reproduces the
    // exact original process without the package-manager wrapper.
    const snapshot = captureRelaunchSnapshot({
      execPath: 'C:\\node\\node.exe',
      execArgv: ['--import', 'tsx/esm'],
      argv: ['C:\\node\\node.exe', 'apps\\cli\\src\\bin.ts', 'web'],
      cwd: 'Z:\\harness',
      env: { npm_command: 'run-script' },
    })
    expect(snapshot.execArgv).toEqual(['--import', 'tsx/esm'])
    expect(snapshot.args).toEqual(['apps\\cli\\src\\bin.ts', 'web'])
  })

  it('records an empty execArgv for plain launches (npm global, direct node, …)', () => {
    const snapshot = captureRelaunchSnapshot({
      execPath: '/node/bin/node',
      execArgv: [],
      argv: ['/node/bin/node', '/npm/dsh/bin/dsh.js', 'web'],
      cwd: '/home/me/project',
      env: { npm_command: 'run-script' },
    })
    expect(snapshot.execArgv).toEqual([])
  })
})
