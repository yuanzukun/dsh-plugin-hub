import { describe, expect, it } from 'vitest'
import { listRemovable } from './removable'

describe('listRemovable', () => {
  const SELF = 'dsh-plugin-onekey'
  const HUB = 'dsh-plugin'

  it('lists every dependency except the plugin itself and the plugin hub, sorted', () => {
    const entries = listRemovable(
      { 'dsh-3d-model-viewer': '0.1.1', 'dsh-plugin': '0.1.1', 'dsh-plugin-onekey': '0.1.0', 'zeta': '1.0.0', 'alpha': '2.0.0' },
      { self: SELF, hub: HUB },
    )
    expect(entries).toEqual([
      { name: 'alpha', version: '2.0.0' },
      { name: 'dsh-3d-model-viewer', version: '0.1.1' },
      { name: 'zeta', version: '1.0.0' },
    ])
  })

  it('returns an empty list for a profile with no user dependencies', () => {
    expect(listRemovable({}, { self: SELF, hub: HUB })).toEqual([])
  })

  it('excludes template bundles even if they somehow appear as dependencies', () => {
    const entries = listRemovable(
      { '@deepseek-ai/dsh-base': '1.0.0', '@deepseek-ai/dsh-web-app': '1.0.0' },
      { self: SELF, hub: HUB, exclude: ['@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app'] },
    )
    expect(entries).toEqual([])
  })
})
