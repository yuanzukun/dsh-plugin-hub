import { describe, expect, it } from 'vitest'
import { applyJob, createJob, type Job } from './jobs'

describe('jobs', () => {
  it('starts in the parsing phase at 5%', () => {
    const job = createJob('j1', 'github:a/b')
    expect(job).toMatchObject({ id: 'j1', phase: 'parsing', percent: 5, log: [], done: false })
  })

  it('advances monotonically through the install phases and settles at 100', () => {
    let job = createJob('j1', 'github:a/b')
    job = applyJob(job, { type: 'phase', phase: 'validating', percent: 15 })
    job = applyJob(job, { type: 'phase', phase: 'running', percent: 30 })
    job = applyJob(job, { type: 'log', line: 'Progress: resolved 1' })
    job = applyJob(job, { type: 'phase', phase: 'reconciling', percent: 90 })
    job = applyJob(job, { type: 'done' })
    expect(job).toMatchObject({ phase: 'done', percent: 100, done: true })
    expect(job.log).toContain('Progress: resolved 1')
  })

  it('never moves a settled job backwards', () => {
    const job = applyJob(createJob('j1', 'x'), { type: 'done' })
    const later = applyJob(job, { type: 'phase', phase: 'running', percent: 30 })
    expect(later.phase).toBe('done')
    expect(later.percent).toBe(100)
  })

  it('fails loudly with the captured error and keeps the last progress', () => {
    let job = createJob('j1', 'github:a/b')
    job = applyJob(job, { type: 'phase', phase: 'running', percent: 45 })
    job = applyJob(job, { type: 'fail', error: 'pnpm: EPERM' })
    expect(job).toMatchObject({ phase: 'failed', percent: 45, done: true, error: 'pnpm: EPERM' })
  })

  it('caps log lines so a chatty pnpm cannot balloon memory', () => {
    let job = createJob('j1', 'x')
    for (let i = 0; i < 300; i++) job = applyJob(job, { type: 'log', line: `line ${i}` })
    expect(job.log.length).toBeLessThanOrEqual(200)
  })
})
