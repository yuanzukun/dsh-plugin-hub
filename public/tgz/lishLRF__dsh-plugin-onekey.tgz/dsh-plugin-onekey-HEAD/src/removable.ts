/**
 * The removable-plugin list for the `/卸载` slash menu: every profile
 * dependency except this plugin and the plugin hub. Profile dependencies are
 * exactly the user-installed plugins — DSH's own in-box bundles are not
 * dependencies, so they can never appear here.
 */

export interface RemovableEntry {
  name: string
  version: string
}

export interface RemovableOptions {
  /** This plugin's own package name (never uninstall yourself). */
  self: string
  /** The plugin hub package name (the user explicitly wants it kept). */
  hub: string
  /** Extra names to protect (e.g. in-box bundles). */
  exclude?: readonly string[]
}

export function listRemovable(
  dependencies: Readonly<Record<string, string>>,
  options: RemovableOptions,
): RemovableEntry[] {
  const protectedNames = new Set([options.self, options.hub, ...(options.exclude ?? [])])
  return Object.entries(dependencies)
    .filter(([name]) => !protectedNames.has(name))
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([name, version]) => ({ name, version }))
}
