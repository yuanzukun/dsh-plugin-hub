import { describe, expect, it } from 'vitest'
import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Writable } from 'node:stream'
import { registerRoutes, type WebServerLike } from './routes'
import type { OneKeyService, ServiceResult } from './service'

/** Minimal fake of the DSH web server route registry. */
class FakeServer implements WebServerLike {
  handler: ((req: IncomingMessage, res: ServerResponse) => Promise<void>) | null = null
  path: string | null = null
  register(route: { kind: 'prefix'; path: string; handler: (req: IncomingMessage, res: ServerResponse) => Promise<void> }): () => void {
    this.path = route.path
    this.handler = route.handler
    return () => { this.handler = null }
  }
}

class FakeService {
  calls: { method: string; args: unknown[] }[] = []
  results: Record<string, ServiceResult> = {
    'GET /state': { status: 200, body: { enabled: true } },
    'GET /removable': { status: 200, body: [{ name: 'a', version: '1' }] },
    'POST /install': { status: 202, body: { jobId: 'j1' } },
    'POST /uninstall': { status: 202, body: { jobId: 'j2' } },
    'POST /restart': { status: 200, body: { ok: true } },
    'GET /jobs/j1': { status: 200, body: { phase: 'done' } },
  }
  state(): ServiceResult { return this.results['GET /state']! }
  removable(): ServiceResult { return this.results['GET /removable']! }
  install(text: unknown): Promise<ServiceResult> { this.calls.push({ method: 'install', args: [text] }); return Promise.resolve(this.results['POST /install']!) }
  uninstall(name: unknown): Promise<ServiceResult> { this.calls.push({ method: 'uninstall', args: [name] }); return Promise.resolve(this.results['POST /uninstall']!) }
  restart(): Promise<ServiceResult> { this.calls.push({ method: 'restart', args: [] }); return Promise.resolve(this.results['POST /restart']!) }
  job(id: unknown): ServiceResult { this.calls.push({ method: 'job', args: [id] }); return this.results['GET /jobs/j1']! }
}

interface FakeResponse extends ServerResponse {
  chunks: string[]
  written: { status: number; headers: Record<string, string | number | readonly string[]> }
  ended: boolean
}

function fakeRequest(method: string, path: string, body?: string): IncomingMessage {
  const req = {
    method,
    url: path,
    on: (event: string, cb: (chunk?: string) => void) => {
      if (event === 'data' && body !== undefined) cb(body)
      if (event === 'end' && body !== undefined) cb()
    },
  }
  return req as unknown as IncomingMessage
}

function fakeResponse(): FakeResponse {
  const res = {
    chunks: [] as string[],
    written: { status: 200, headers: {} },
    ended: false,
    writeHead(status: number, headers?: Record<string, string | number | readonly string[]>) {
      this.written.status = status
      if (headers) this.written.headers = headers
    },
    end(chunk?: string) {
      if (chunk !== undefined) this.chunks.push(chunk)
      this.ended = true
    },
  }
  return res as unknown as FakeResponse
}

const invoke = async (server: FakeServer, method: string, path: string, body?: string) => {
  const res = fakeResponse()
  await server.handler!(fakeRequest(method, path, body), res as unknown as ServerResponse)
  return { res, json: JSON.parse(res.chunks.join('') || 'null') }
}

describe('registerRoutes', () => {
  it('registers under the /plugins/onekey prefix', () => {
    const server = new FakeServer()
    registerRoutes(server, new FakeService() as unknown as OneKeyService)
    expect(server.path).toBe('/plugins/onekey')
  })

  it('answers the ping probe', async () => {
    const server = new FakeServer()
    registerRoutes(server, new FakeService() as unknown as OneKeyService)
    const { res, json } = await invoke(server, 'GET', '/plugins/onekey/ping')
    expect(res.written.status).toBe(200)
    expect(json).toEqual({ ok: true })
  })

  it('serves state and removable reads', async () => {
    const server = new FakeServer()
    registerRoutes(server, new FakeService() as unknown as OneKeyService)
    expect((await invoke(server, 'GET', '/plugins/onekey/state')).json.enabled).toBe(true)
    expect((await invoke(server, 'GET', '/plugins/onekey/removable')).json).toEqual([{ name: 'a', version: '1' }])
  })

  it('parses the install body and forwards it', async () => {
    const server = new FakeServer()
    const service = new FakeService()
    registerRoutes(server, service as unknown as OneKeyService)
    const { res, json } = await invoke(server, 'POST', '/plugins/onekey/install', JSON.stringify({ text: 'dsh plugin add a/b' }))
    expect(res.written.status).toBe(202)
    expect(json.jobId).toBe('j1')
    expect(service.calls[0]).toEqual({ method: 'install', args: ['dsh plugin add a/b'] })
  })

  it('parses the uninstall body and forwards the name', async () => {
    const server = new FakeServer()
    const service = new FakeService()
    registerRoutes(server, service as unknown as OneKeyService)
    await invoke(server, 'POST', '/plugins/onekey/uninstall', JSON.stringify({ name: 'dsh-x' }))
    expect(service.calls[0]).toEqual({ method: 'uninstall', args: ['dsh-x'] })
  })

  it('rejects malformed JSON bodies with 400', async () => {
    const server = new FakeServer()
    registerRoutes(server, new FakeService() as unknown as OneKeyService)
    const { res } = await invoke(server, 'POST', '/plugins/onekey/install', '{not json')
    expect(res.written.status).toBe(400)
  })

  it('rejects unknown paths with 404 and unknown methods with 405', async () => {
    const server = new FakeServer()
    registerRoutes(server, new FakeService() as unknown as OneKeyService)
    expect((await invoke(server, 'GET', '/plugins/onekey/nope')).res.written.status).toBe(404)
    expect((await invoke(server, 'DELETE', '/plugins/onekey/state')).res.written.status).toBe(405)
  })

  it('routes job polling by id', async () => {
    const server = new FakeServer()
    const service = new FakeService()
    registerRoutes(server, service as unknown as OneKeyService)
    const { json } = await invoke(server, 'GET', '/plugins/onekey/jobs/j1')
    expect(json.phase).toBe('done')
    expect(service.calls[0]).toEqual({ method: 'job', args: ['j1'] })
  })

  it('answers ping even when the service would deny everything', async () => {
    const server = new FakeServer()
    const service = new FakeService()
    service.results['GET /state'] = { status: 403, body: { error: 'disabled' } }
    registerRoutes(server, service as unknown as OneKeyService)
    expect((await invoke(server, 'GET', '/plugins/onekey/ping')).json).toEqual({ ok: true })
  })

  it('caps the request body size', async () => {
    const server = new FakeServer()
    registerRoutes(server, new FakeService() as unknown as OneKeyService)
    const big = JSON.stringify({ text: 'x'.repeat(70000) })
    const { res } = await invoke(server, 'POST', '/plugins/onekey/install', big)
    expect(res.written.status).toBe(413)
  })
})
