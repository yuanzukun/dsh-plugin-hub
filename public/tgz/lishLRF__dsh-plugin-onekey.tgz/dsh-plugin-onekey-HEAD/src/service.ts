/**
 * OneKeyService — the host-side brain: permission-gated install / uninstall /
 * restart orchestration over injected IO, with a pure test surface. Every
 * mutating operation double-checks the live permission snapshot before it
 * touches pnpm, the profile manifest, or the process itself.
 */
import type { RelaunchSnapshot } from './restart.ts'
import type { Job } from './jobs.ts'
import { applyJob, createJob } from './jobs.ts'
import { parseInstallCommand } from './parse.ts'
import { reconcileBundles } from './reconcile.ts'
import { listRemovable, type RemovableEntry } from './removable.ts'

/** Live permission snapshot; refreshed from settings on every change. */
export interface Permissions {
  enabled: boolean
  allowInstall: boolean
  allowUninstall: boolean
  allowRestart: boolean
  allowClipboard: boolean
}

/** The profile manifest subset this service reads and writes. */
export interface ProfileManifest {
  dependencies?: Record<string, string>
  dsh?: { profile?: { bundles?: string[] } }
}

/** Everything the service needs from the outside world (fakeable in tests). */
export interface ServiceIO {
  profileDir: string
  profileName: string
  platform: NodeJS.Platform
  pnpmAvailable: boolean
  restartSnapshot: RelaunchSnapshot
  selfName: string
  hubName: string
  readClipboard(): string | null
  /** Run pnpm with whitelisted args in the profile directory; resolves the exit code. */
  runPnpm(args: string[], onOutput: (chunk: string) => void): Promise<number>
  readManifest(): ProfileManifest
  writeManifest(manifest: ProfileManifest): void
  /** Verdict over the INSTALLED package: does its manifest declare `dsh.bundle.patch`? */
  isBundle(name: string): boolean
  /** Spawn the detached relauncher for the current process. */
  spawnRelauncher(oldPid: number, snapshot: RelaunchSnapshot): void
  /** Terminate the current DSH process. */
  exit(code: number): void
  makeId(): string
}

export interface ServiceResult {
  status: number
  body: unknown
}

interface LiveJob {
  state: Job
  settled: Promise<void>
}

const deny = (error: string): ServiceResult => ({ status: 403, body: { error } })
const reject = (status: number, error: string): ServiceResult => ({ status, body: { error } })

/** Count active (unsettled) jobs, used by the state report. */
function countActive(jobs: ReadonlyMap<string, LiveJob>): number {
  let count = 0
  for (const entry of jobs.values()) if (!entry.state.done) count += 1
  return count
}

export class OneKeyService {
  private readonly jobs = new Map<string, LiveJob>()

  constructor(
    private readonly io: ServiceIO,
    private readonly getPermissions: () => Permissions,
  ) {}

  /** Environment + permission report the client gates its UI on. */
  state(): ServiceResult {
    const permissions = this.getPermissions()
    const snapshot = this.io.restartSnapshot
    return {
      status: 200,
      body: {
        enabled: permissions.enabled,
        permissions,
        profile: { name: this.io.profileName, dir: this.io.profileDir },
        pnpm: { available: this.io.pnpmAvailable },
        restart: { command: `${snapshot.execPath} ${snapshot.args.join(' ')}`.trim(), cwd: snapshot.cwd },
        activeJobs: countActive(this.jobs),
      },
    }
  }

  /** The `/卸载` candidate list: profile dependencies minus self and the hub. */
  removable(): ServiceResult {
    const permissions = this.getPermissions()
    if (!permissions.enabled) return { status: 200, body: [] }
    return { status: 200, body: this.removableCandidates() }
  }

  /**
   * Compute the removable list. Only dependencies are candidates (in-box
   * bundles are never dependencies); the `exclude` set protects ONLY bundle
   * entries that are not installed as dependencies — user plugins legitimately
   * appear in BOTH lists, so the whole bundles layer must never be excluded.
   */
  private removableCandidates(): RemovableEntry[] {
    const manifest = this.io.readManifest()
    const dependencies = manifest.dependencies ?? {}
    const bundles = manifest.dsh?.profile?.bundles ?? []
    return listRemovable(dependencies, {
      self: this.io.selfName,
      hub: this.io.hubName,
      exclude: bundles.filter(name => dependencies[name] === undefined),
    })
  }

  /**
   * Start an install job from posted text or the OS clipboard.
   * The async continuation owns the job state; the client polls it.
   */
  install(text: string | undefined): Promise<ServiceResult> {
    return this.guarded('install', async (permissions) => {
      let payload: string | undefined = text
      if (payload === undefined) {
        if (!permissions.allowClipboard) return reject(403, 'clipboard-not-allowed')
        const clipboard = this.io.readClipboard()
        if (clipboard === null || clipboard.trim() === '') return reject(400, 'empty-clipboard')
        payload = clipboard
      }
      const parsed = parseInstallCommand(payload)
      if (!parsed.ok) return reject(400, parsed.reason)
      const job = this.startJob(parsed.parsed.command)
      const entry: LiveJob = { state: job.state, settled: Promise.resolve() }
      this.jobs.set(job.state.id, entry)
      entry.settled = (async () => {
          this.update(job.state.id, { type: 'phase', phase: 'validating', percent: 15 })
          this.update(job.state.id, { type: 'phase', phase: 'running', percent: 30 })
          const before = this.io.readManifest()
          const code = await this.io.runPnpm(['add', parsed.parsed.spec], (chunk) => {
            for (const line of chunk.split(/\r?\n/u)) {
              if (line.trim() !== '') this.update(job.state.id, { type: 'log', line })
            }
          })
          if (code !== 0) {
            const current = this.jobs.get(job.state.id)?.state
            const tail = (current?.log ?? []).slice(-30).join('\n')
            this.update(job.state.id, { type: 'fail', error: tail || `pnpm exited with code ${code}` })
            return
          }
          this.update(job.state.id, { type: 'phase', phase: 'reconciling', percent: 90 })
          this.reconcile(before)
          this.update(job.state.id, { type: 'done' })
        })()
      return { status: 202, body: { jobId: job.state.id } }
    })
  }

  /**
   * Start an uninstall job; on success the backend relaunches itself and the
   * client takes over the "restarting, please wait" UI.
   */
  uninstall(name: string): Promise<ServiceResult> {
    return this.guarded('uninstall', async () => {
      const candidates = this.removableCandidates()
      if (!candidates.some(entry => entry.name === name)) return reject(400, 'not-removable')
      const job = this.startJob(`dsh plugin remove ${name}`)
      const entry: LiveJob = { state: job.state, settled: Promise.resolve() }
      this.jobs.set(job.state.id, entry)
      entry.settled = (async () => {
          this.update(job.state.id, { type: 'phase', phase: 'validating', percent: 15 })
          this.update(job.state.id, { type: 'phase', phase: 'running', percent: 30 })
          const before = this.io.readManifest()
          const code = await this.io.runPnpm(['remove', name], (chunk) => {
            for (const line of chunk.split(/\r?\n/u)) {
              if (line.trim() !== '') this.update(job.state.id, { type: 'log', line })
            }
          })
          if (code !== 0) {
            const current = this.jobs.get(job.state.id)?.state
            const tail = (current?.log ?? []).slice(-30).join('\n')
            this.update(job.state.id, { type: 'fail', error: tail || `pnpm exited with code ${code}` })
            return
          }
          this.update(job.state.id, { type: 'phase', phase: 'reconciling', percent: 90 })
          this.reconcile(before)
          this.update(job.state.id, { type: 'done' })
          // Uninstall always restarts the backend: the frontend breaks on the
          // removed plugin, so we take over with the relauncher + reload loop.
          this.io.spawnRelauncher(process.pid, this.io.restartSnapshot)
          this.io.exit(0)
        })()
      return { status: 202, body: { jobId: job.state.id, restarting: true } }
    })
  }

  /** Restart the backend immediately (relauncher + self-exit). */
  restart(): Promise<ServiceResult> {
    return this.guarded('restart', async () => {
      this.io.spawnRelauncher(process.pid, this.io.restartSnapshot)
      this.io.exit(0)
      return { status: 200, body: { ok: true } }
    })
  }

  /** Poll one job's state. */
  job(id: string): ServiceResult {
    const entry = this.jobs.get(id)
    if (entry === undefined) return { status: 404, body: { error: 'not-found' } }
    return { status: 200, body: entry.state }
  }

  /** Resolve when a job settles (used by tests and the uninstall flow). */
  async settled(id: string): Promise<void> {
    await this.jobs.get(id)?.settled
  }

  /** Read one job's state directly (test convenience). */
  jobState(id: string): Job | undefined {
    return this.jobs.get(id)?.state
  }

  /** Permission gate shared by every mutating operation. */
  private async guarded(
    op: 'install' | 'uninstall' | 'restart',
    run: (permissions: Permissions) => Promise<ServiceResult>,
  ): Promise<ServiceResult> {
    const permissions = this.getPermissions()
    if (!permissions.enabled) return deny('disabled')
    const gate: Record<typeof op, keyof Permissions> = {
      install: 'allowInstall',
      uninstall: 'allowUninstall',
      restart: 'allowRestart',
    }
    if (!permissions[gate[op]]) return deny(`${op}-not-allowed`)
    return run(permissions)
  }

  /** Create a job in the parsing phase and return its live handle. */
  private startJob(command: string): LiveJob {
    const state = createJob(this.io.makeId(), command)
    return { state, settled: Promise.resolve() }
  }

  private update(id: string, event: Parameters<typeof applyJob>[1]): void {
    const entry = this.jobs.get(id)
    if (entry === undefined) return
    entry.state = applyJob(entry.state, event)
  }

  /** Reconcile `dsh.profile.bundles` against the installed state after pnpm. */
  private reconcile(before: ProfileManifest): void {
    const after = this.io.readManifest()
    const result = reconcileBundles(
      new Set(Object.keys(before.dependencies ?? {})),
      after.dependencies ?? {},
      after.dsh?.profile?.bundles ?? [],
      name => this.io.isBundle(name),
    )
    if (!result.changed) return
    this.io.writeManifest({
      ...after,
      dsh: { ...after.dsh, profile: { ...after.dsh?.profile, bundles: result.bundles } },
    })
  }
}
