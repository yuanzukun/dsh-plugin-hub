/**
 * Backend-restart machinery: the relauncher script generator (pure, tested)
 * and the detached spawn (side-effect shell).
 *
 * Model: the plugin records the exact launch command at startup
 * (`process.execPath` + `argv.slice(1)` + cwd + env), which covers every way
 * DSH can be installed (npm global, source checkout via tsx, built binary).
 * On restart it writes a relauncher module to a temp file (never `node -e`
 * — keeps argv tiny and everything inspectable) that:
 *   1. logs every step to a log file,
 *   2. waits for the old pid to die (bounded),
 *   3. settles a moment for socket teardown,
 *   4. spawns the recorded command verbatim (no shell) with its stdio
 *      redirected to log files,
 *   5. retries with backoff when the child crashes within the survival window.
 * The old process exits after acknowledging the request.
 */

export interface RelaunchSnapshot {
  execPath: string
  /**
   * Node execution flags (`--import tsx/esm`, `--loader`, …). Node keeps
   * these SEPARATE from the script args (`process.execArgv`), and a replay
   * that drops them produces a broken process — this was the exact failure
   * mode of the first restart implementation.
   */
  execArgv: string[]
  /** Script entry + CLI args (the `web` profile argument included). */
  args: string[]
  cwd: string
  env: NodeJS.ProcessEnv
}

export interface RelauncherOptions {
  /** How long to wait for the old process to die before relaunching anyway. */
  timeoutMs?: number
  /** Poll interval for the old-pid liveness check. */
  pollMs?: number
  /** Extra delay after the old pid dies, letting the OS release the listen socket. */
  settleMs?: number
  /** Spawn attempts when the child crashes quickly. */
  retries?: number
  /** Delay between retries. */
  backoffMs?: number
  /** A child alive this long counts as a successful relaunch. */
  surviveMs?: number
  /** Step-log path (undefined = no log). */
  logPath?: string
  /** The relaunched process's stdout/stderr capture paths. */
  outPath?: string
  errPath?: string
}

/**
 * Build the relauncher module source (CommonJS, run with `node <file>`).
 * @param oldPid - the pid of the process that must exit first.
 * @param snapshot - the recorded launch command.
 */
export function buildRelauncherScript(
  oldPid: number,
  snapshot: RelaunchSnapshot,
  options: RelauncherOptions = {},
): string {
  const timeoutMs = options.timeoutMs ?? 30000
  const pollMs = options.pollMs ?? 200
  const settleMs = options.settleMs ?? 1500
  const retries = options.retries ?? 5
  const backoffMs = options.backoffMs ?? 2000
  // DSH (tsx cold start) can take well over 10s from spawn to port bind, so
  // the survival window must cover the whole boot — a child that dies at bind
  // time (e.g. a port race) is still caught and retried.
  const surviveMs = options.surviveMs ?? 15000
  const logPath = options.logPath ?? null
  const outPath = options.outPath ?? null
  const errPath = options.errPath ?? null
  const serialized = JSON.stringify(snapshot)
  return [
    'const fs = require("node:fs");',
    'const { spawn } = require("node:child_process");',
    `const oldPid = ${JSON.stringify(oldPid)};`,
    `const snapshot = ${serialized};`,
    `const timeoutMs = ${timeoutMs};`,
    `const pollMs = ${pollMs};`,
    `const settleMs = ${settleMs};`,
    `const retries = ${retries};`,
    `const backoffMs = ${backoffMs};`,
    `const surviveMs = ${surviveMs};`,
    `const logPath = ${JSON.stringify(logPath)};`,
    `const outPath = ${JSON.stringify(outPath)};`,
    `const errPath = ${JSON.stringify(errPath)};`,
    'const log = (line) => {',
    '  if (logPath === null) return;',
    '  try { fs.appendFileSync(logPath, new Date().toISOString() + " " + line + "\\n"); } catch {}',
    '};',
    'const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));',
    'const alive = () => {',
    '  try { process.kill(oldPid, 0); return true; }',
    '  catch (error) { log("old pid gone (" + String(error.code) + ")"); return false; }',
    '};',
    'const launch = (attempt) => {',
    '  let outFd = "ignore";',
    '  let errFd = "ignore";',
    '  if (outPath !== null) outFd = fs.openSync(outPath, "a");',
    '  if (errPath !== null) errFd = fs.openSync(errPath, "a");',
    '  log("attempt " + attempt + ": spawning " + snapshot.execPath + " " + [...snapshot.execArgv, ...snapshot.args].join(" "));',
    '  const child = spawn(snapshot.execPath, [...snapshot.execArgv, ...snapshot.args], {',
    '    cwd: snapshot.cwd,',
    '    env: snapshot.env,',
    '    detached: true,',
    '    stdio: ["ignore", outFd, errFd],',
    '    shell: false,',
    '    windowsHide: true,',
    '  });',
    '  if (outFd !== "ignore") fs.closeSync(outFd);',
    '  if (errFd !== "ignore") fs.closeSync(errFd);',
    '  return child;',
    '};',
    '(async () => {',
    '  log("relauncher up; waiting for pid " + oldPid);',
    '  const started = Date.now();',
    '  while (alive() && Date.now() - started < timeoutMs) await sleep(pollMs);',
    `  log("wait finished; settling ${settleMs}ms for socket teardown");`,
    '  await sleep(settleMs);',
    '  for (let attempt = 1; attempt <= retries; attempt++) {',
    '    let child = null;',
    '    try { child = launch(attempt); } catch (error) { log("spawn failed: " + String(error)); }',
    '    if (child !== null) {',
    '      const verdict = await new Promise((resolve) => {',
    '        const timer = setTimeout(() => resolve("survived"), surviveMs);',
    '        child.on("error", (error) => { clearTimeout(timer); log("child error: " + String(error)); resolve("crashed"); });',
    '        child.on("exit", (code, signal) => { clearTimeout(timer); log("child exited early code=" + code + " signal=" + signal); resolve("crashed"); });',
    '      });',
    '      if (verdict === "survived") {',
    '        log("child " + child.pid + " survived; relaunch complete");',
    '        child.unref();',
    '        process.exit(0);',
    '        return;',
    '      }',
    '    }',
    '    if (attempt < retries) {',
    `      log("retrying in ${backoffMs}ms");`,
    '      await sleep(backoffMs);',
    '    }',
    '  }',
    `  log("gave up after ${retries} attempts");`,
    '  process.exit(1);',
    '})().catch((error) => { log("relauncher crashed: " + String(error)); process.exit(1); });',
  ].join('\n')
}
