/**
 * Plugin configuration schema: the enable switch plus the four permission
 * gates. The same schema backs both the loader entry config and the settings
 * namespace, so Settings → Plugins → Plugin configuration edits it live.
 */
import z from '@deepseek-ai/schemastery'

export interface Config {
  /** Master switch — off gates every capability (slash menu, popups, routes). */
  enabled: boolean
  /** Allow one-click install through pnpm in the profile directory. */
  allowInstall: boolean
  /** Allow uninstalling user plugins (followed by an automatic backend restart). */
  allowUninstall: boolean
  /** Allow the backend to restart itself after install/uninstall. */
  allowRestart: boolean
  /** Allow the backend to read the OS clipboard for install commands. */
  allowClipboard: boolean
}

export const Config: z<Config> = z.object({
  enabled: z.boolean().default(true),
  allowInstall: z.boolean().default(true),
  allowUninstall: z.boolean().default(true),
  allowRestart: z.boolean().default(true),
  allowClipboard: z.boolean().default(true),
})

export const DEFAULT_CONFIG: Config = {
  enabled: true,
  allowInstall: true,
  allowUninstall: true,
  allowRestart: true,
  allowClipboard: true,
}

/** Settings namespace — also the key of the plugin configuration card. */
export const NS = 'dsh-plugin-onekey'
