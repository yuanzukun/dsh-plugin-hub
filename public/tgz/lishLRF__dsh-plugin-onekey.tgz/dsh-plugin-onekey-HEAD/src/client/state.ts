/**
 * Client dialog state machine (pure): confirm → running → success | failed,
 * success → restarting → (reload), anything → closed/idle. Illegal events are
 * ignored by returning the previous state unchanged.
 */

export type DialogStatus =
  | 'idle'
  | 'confirm-install'
  | 'confirm-uninstall'
  | 'running'
  | 'success'
  | 'failed'
  | 'restarting'
  | 'notice'

export interface DialogState {
  status: DialogStatus
  /** Install flow: parsed spec display + canonical command. */
  spec?: string
  command?: string
  /** Uninstall flow: the target package name. */
  uninstallTarget?: string
  /** Install job id while polling progress. */
  jobId?: string
  /** 0–100, monotonic. */
  progress?: number
  logTail?: string[]
  error?: string
  restart?: { attempts: number }
  /** Lightweight guidance notice text. */
  notice?: string
}

export type DialogEvent =
  | { type: 'show-confirm-install'; spec: string; command: string }
  | { type: 'show-confirm-uninstall'; target: string }
  | { type: 'start'; jobId: string }
  | { type: 'progress'; percent: number; log: string[] }
  | { type: 'success' }
  | { type: 'fail'; error: string }
  | { type: 'restarting' }
  | { type: 'restart-tick' }
  | { type: 'show-notice'; text: string }
  | { type: 'close' }

export const initialDialog: DialogState = { status: 'idle' }

const clamp = (value: number): number => Math.min(100, Math.max(0, value))

export function dialogReducer(state: DialogState, event: DialogEvent): DialogState {
  switch (event.type) {
    case 'close':
      return initialDialog
    case 'show-confirm-install':
      if (state.status !== 'idle' && state.status !== 'failed') return state
      return { status: 'confirm-install', spec: event.spec, command: event.command }
    case 'show-confirm-uninstall':
      if (state.status !== 'idle' && state.status !== 'failed') return state
      return { status: 'confirm-uninstall', uninstallTarget: event.target }
    case 'start':
      if (state.status !== 'confirm-install' && state.status !== 'confirm-uninstall') return state
      return { ...state, status: 'running', jobId: event.jobId, progress: 0, logTail: [], error: undefined }
    case 'progress': {
      if (state.status !== 'running') return state
      const progress = clamp(event.percent)
      return {
        ...state,
        progress: Math.max(state.progress ?? 0, progress),
        logTail: event.log.slice(-200),
      }
    }
    case 'success':
      if (state.status !== 'running') return state
      return { ...state, status: 'success', progress: 100 }
    case 'fail':
      if (state.status !== 'running') return state
      return { ...state, status: 'failed', error: event.error }
    case 'restarting':
      if (state.status !== 'success' && state.status !== 'confirm-uninstall') return state
      return { ...state, status: 'restarting', restart: { attempts: 0 } }
    case 'restart-tick':
      if (state.status !== 'restarting') return state
      return { ...state, restart: { attempts: (state.restart?.attempts ?? 0) + 1 } }
    case 'show-notice':
      if (state.status === 'running' || state.status === 'restarting') return state
      if (state.status === 'confirm-install' || state.status === 'confirm-uninstall') return state
      return { status: 'notice', notice: event.text }
    default:
      return state
  }
}
