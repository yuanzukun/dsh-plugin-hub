/**
 * Dialog controller: the polling choreography behind the modal — confirm →
 * job polling → success/fail, uninstall auto-restart, restart ping loop,
 * and the "copy to workspace and ask the LLM" hand-off. Pure orchestration
 * over injected IO (fakeable without a browser).
 */
import type { DialogEvent, DialogState } from './state.ts'

export interface JobBody {
  id?: string
  command?: string
  phase: string
  percent: number
  log: string[]
  error?: string
  done: boolean
}

export interface Api {
  install(text?: string): Promise<{ status: number; body: unknown }>
  uninstall(name: string): Promise<{ status: number; body: unknown }>
  restart(): Promise<{ status: number; body: unknown }>
  job(id: string): Promise<{ status: number; body: JobBody }>
  ping(): Promise<boolean>
}

/** Live composer hand-off (filled by the input-overlay bridge entry). */
export interface ComposerBridge {
  current: { getDraft(): string; setDraft(text: string): void } | null
}

export interface ControllerDeps {
  api: Api
  dispatch(event: DialogEvent): void
  state(): DialogState
  prompt(input: { profileName?: string; command: string; error: string }): string
  bridge: ComposerBridge
  reload(): void
  sleep(ms: number): Promise<void>
}

export interface OneKeyActions {
  confirmInstall(): Promise<void>
  confirmUninstall(): Promise<void>
  restartNow(): Promise<void>
  askLlm(): void
  cancel(): void
  manualReload(): void
}

const POLL_INTERVAL_MS = 800
const RESTART_POLL_MS = 1500
const RESTART_MAX_ATTEMPTS = 80

/** Human-readable Chinese message for the backend's machine rejection codes. */
function describeRejection(status: number, body: unknown): string {
  const error = (body as { error?: unknown } | null | undefined)?.error
  const code = typeof error === 'string' ? error : ''
  const messages: Record<string, string> = {
    disabled: '插件已在“设置 → 插件 → 插件配置”中被禁用，请先启用',
    'install-not-allowed': '一键安装权限未开启（设置 → 插件 → 插件配置）',
    'uninstall-not-allowed': '卸载插件权限未开启（设置 → 插件 → 插件配置）',
    'restart-not-allowed': '自动重启后端权限未开启（设置 → 插件 → 插件配置）',
    'clipboard-not-allowed': '读取剪贴板权限未开启（设置 → 插件 → 插件配置）',
    'empty-clipboard': '剪贴板为空：请先在插件中心点击插件的“复制安装命令”按钮',
    'not-a-command': '剪贴板内容不是 dsh plugin add 安装命令',
    'unsafe-spec': '安装目标未通过安全校验，已拒绝执行',
    'not-removable': '该插件不在可卸载列表中（仅限 profile 中用户自装的插件）',
    'bad-request': '请求无效',
    'internal-error': '后端内部错误',
  }
  return messages[code] ?? (code !== '' ? code : `请求失败（HTTP ${status}）`)
}

export function createController(deps: ControllerDeps): OneKeyActions {
  const { api, dispatch, state, bridge, reload } = deps

  async function pollJob(jobId: string, afterSuccess: 'install' | 'uninstall'): Promise<void> {
    for (;;) {
      await deps.sleep(POLL_INTERVAL_MS)
      let result: { status: number; body: JobBody }
      try {
        result = await api.job(jobId)
      } catch {
        // The backend may die mid-poll. For an uninstall that is EXPECTED —
        // pnpm finished and the relauncher took the process down: take over
        // with the restart loop. For an install it is a real failure.
        if (afterSuccess === 'uninstall') {
          dispatch({ type: 'success' })
          await beginRestart()
        } else {
          dispatch({ type: 'fail', error: '后端连接中断：安装可能未完成，请检查后重试' })
        }
        return
      }
      if (result.status !== 200) {
        dispatch({ type: 'fail', error: '进度查询失败（后端连接中断）' })
        return
      }
      const job = result.body
      if (job.done && job.phase === 'failed') {
        dispatch({ type: 'fail', error: job.error ?? '任务失败' })
        return
      }
      if (job.done) {
        dispatch({ type: 'success' })
        if (afterSuccess === 'uninstall') await beginRestart()
        return
      }
      dispatch({ type: 'progress', percent: job.percent, log: job.log })
    }
  }

  async function beginRestart(): Promise<void> {
    dispatch({ type: 'restarting' })
    for (let attempt = 0; attempt < RESTART_MAX_ATTEMPTS; attempt++) {
      await deps.sleep(RESTART_POLL_MS)
      dispatch({ type: 'restart-tick' })
      if (await api.ping()) {
        reload()
        return
      }
    }
    // The dialog stays open; its restart view offers a manual refresh button.
  }

  return {
    async confirmInstall() {
      const current = state()
      if (current.status !== 'confirm-install') return
      const text = current.command === '' ? undefined : current.command
      const result = await api.install(text)
      if (result.status !== 202) {
        dispatch({ type: 'fail', error: describeRejection(result.status, result.body) })
        return
      }
      const jobId = (result.body as { jobId?: unknown } | null | undefined)?.jobId
      if (typeof jobId !== 'string') {
        dispatch({ type: 'fail', error: '后端响应缺少 jobId' })
        return
      }
      dispatch({ type: 'start', jobId })
      await pollJob(jobId, 'install')
    },
    async confirmUninstall() {
      const current = state()
      if (current.status !== 'confirm-uninstall' || current.uninstallTarget === undefined) return
      const name = current.uninstallTarget
      const result = await api.uninstall(name)
      if (result.status !== 202) {
        dispatch({ type: 'fail', error: describeRejection(result.status, result.body) })
        return
      }
      const jobId = (result.body as { jobId?: unknown } | null | undefined)?.jobId
      if (typeof jobId !== 'string') {
        dispatch({ type: 'fail', error: '后端响应缺少 jobId' })
        return
      }
      dispatch({ type: 'start', jobId })
      await pollJob(jobId, 'uninstall')
    },
    async restartNow() {
      if (state().status !== 'success') return
      let result: { status: number; body: unknown }
      try {
        result = await api.restart()
      } catch {
        // The backend may die before answering — the ping loop decides.
        await beginRestart()
        return
      }
      if (result.status !== 200) {
        // The install itself succeeded — only the restart was refused, so a
        // guidance notice fits better than the red failure bar.
        dispatch({ type: 'show-notice', text: describeRejection(result.status, result.body) })
        return
      }
      await beginRestart()
    },
    askLlm() {
      const current = state()
      if (current.status !== 'failed') return
      const text = deps.prompt({ command: current.command ?? '', error: current.error ?? '' })
      const composer = bridge.current
      if (composer !== null) {
        const draft = composer.getDraft()
        composer.setDraft(draft === '' ? text : `${draft}\n\n${text}`)
      } else {
        void navigator.clipboard?.writeText(text).catch(() => {})
      }
      dispatch({ type: 'close' })
    },
    cancel() {
      dispatch({ type: 'close' })
    },
    manualReload() {
      reload()
    },
  }
}
