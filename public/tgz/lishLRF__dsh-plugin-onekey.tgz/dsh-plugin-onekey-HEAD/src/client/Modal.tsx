/**
 * The global modal: five live views (confirm install / confirm uninstall /
 * running / success / failed / restarting / notice) rendered through the
 * `shell.overlay` slot into a portal.
 */
import { createPortal } from 'react-dom'
import type { ReactNode } from 'react'
import type { OneKeyActions } from './controller.ts'
import type { DialogState } from './state.ts'
import css from './styles.module.css'

export type Translate = (key: string, params?: Record<string, string | number>) => string

export interface ModalProps {
  state: DialogState
  actions: OneKeyActions
  t: Translate
}

function ProgressBar({ state }: { state: DialogState }) {
  const failed = state.status === 'failed'
  const percent = state.progress ?? 0
  return (
    <div className={css.progressTrack}>
      <div
        className={failed ? css.progressFillFailed : css.progressFill}
        style={{ width: `${String(percent)}%` }}
      />
    </div>
  )
}

function LogTail({ state }: { state: DialogState }) {
  const lines = state.logTail ?? []
  if (lines.length === 0) return null
  return <pre className={css.log}>{lines.slice(-5).join('\n')}</pre>
}

export function OneKeyModal({ state, actions, t }: ModalProps) {
  if (state.status === 'idle') return null

  let body: ReactNode
  switch (state.status) {
    case 'notice':
      body = (
        <div>
          <div className={css.noticeText}>{state.notice ?? ''}</div>
          <div className={css.buttons}>
            <button className={css.primary} onClick={actions.cancel}>{t('notice.ok')}</button>
          </div>
        </div>
      )
      break
    case 'confirm-install':
      body = (
        <div>
          <h2 className={css.title}>{t('confirm.install.title')}</h2>
          <div className={css.fieldLabel}>{t('confirm.install.command')}</div>
          <pre className={css.command}>
            {state.command === '' ? t('confirm.install.clipboard') : state.command}
          </pre>
          <div className={css.warning}>{t('confirm.install.notice')}</div>
          <div className={css.buttons}>
            <button className={css.primary} onClick={() => void actions.confirmInstall()}>{t('confirm.install.ok')}</button>
            <button className={css.secondary} onClick={actions.cancel}>{t('cancel')}</button>
          </div>
        </div>
      )
      break
    case 'confirm-uninstall':
      body = (
        <div>
          <h2 className={css.title}>{t('confirm.uninstall.title')}</h2>
          <div className={css.target}>📦 {state.uninstallTarget ?? ''}</div>
          <div className={css.warning}>{t('confirm.uninstall.text')}</div>
          <div className={css.buttons}>
            <button className={css.danger} onClick={() => void actions.confirmUninstall()}>{t('confirm.uninstall.ok')}</button>
            <button className={css.secondary} onClick={actions.cancel}>{t('cancel')}</button>
          </div>
        </div>
      )
      break
    case 'running':
      body = (
        <div>
          <h2 className={css.title}>{state.uninstallTarget === undefined ? t('running.title') : t('running.uninstall')}</h2>
          <ProgressBar state={state} />
          <div className={css.percent}>{String(state.progress ?? 0)}%</div>
          <div className={css.hint}>{t('running.hint')}</div>
          <LogTail state={state} />
        </div>
      )
      break
    case 'success':
      body = (
        <div>
          <h2 className={css.title}>{t('success.title')}</h2>
          <div className={css.check}>✔</div>
          <div className={css.buttons}>
            <button className={css.primary} onClick={() => void actions.restartNow()}>{t('success.restartNow')}</button>
            <button className={css.secondary} onClick={actions.cancel}>{t('success.restartLater')}</button>
          </div>
        </div>
      )
      break
    case 'failed':
      body = (
        <div>
          <h2 className={css.title}>{t('failed.title')}</h2>
          <ProgressBar state={state} />
          <pre className={css.error}>{state.error ?? ''}</pre>
          <div className={css.buttons}>
            <button className={css.primary} onClick={actions.askLlm}>{t('failed.askLlm')}</button>
            <button className={css.secondary} onClick={actions.cancel}>{t('close')}</button>
          </div>
        </div>
      )
      break
    case 'restarting':
      body = (
        <div>
          <h2 className={css.title}>{t('restarting.title')}</h2>
          <div className={css.spinner} />
          <div className={css.hint}>{t('restarting.hint')}</div>
          <div className={css.hint}>{t('restarting.attempts', { seconds: String(Math.round((state.restart?.attempts ?? 0) * 1.5)) })}</div>
          <div className={css.hint}>{t('restarting.log')}</div>
          <div className={css.buttons}>
            <button className={css.secondary} onClick={actions.manualReload}>{t('restarting.manual')}</button>
          </div>
        </div>
      )
      break
    default:
      body = null
  }

  return createPortal(
    <div className={css.backdrop} role="presentation">
      <div className={css.modal} role="dialog" aria-modal="true">
        {body}
      </div>
    </div>,
    document.body,
  )
}
