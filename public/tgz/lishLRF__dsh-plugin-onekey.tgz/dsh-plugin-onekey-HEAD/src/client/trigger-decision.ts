/**
 * Copy-signal decision: does a clipboard/copy-event signal open the install
 * confirmation? Pure and strict — only an exact single-line install command
 * opens; everything else (arbitrary conversation text, multiline payloads,
 * signals without text) is ignored. This is the false-positive gate.
 */
import { parseInstallCommand } from '../parse.ts'

export type CopyDecision =
  | { action: 'open'; spec: string; command: string }
  | { action: 'ignore' }

export function decideCopySignal(text: string | null): CopyDecision {
  if (text === null || text.trim() === '') return { action: 'ignore' }
  const parsed = parseInstallCommand(text)
  if (!parsed.ok) return { action: 'ignore' }
  return { action: 'open', spec: parsed.parsed.display, command: parsed.parsed.command }
}
