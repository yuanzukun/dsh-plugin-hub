import { describe, expect, it, vi } from 'vitest'
import { dedupeSignal, extractCopyText, installClipboardIntercept, type InterceptHost } from './trigger'

function fakeHost(overrides: Partial<InterceptHost> = {}): InterceptHost & { copyListeners: Map<string, (e: unknown) => void> } {
  const copyListeners = new Map<string, (e: unknown) => void>()
  const navigatorClipboard = { writeText: vi.fn(async (_t: string) => {}) }
  return {
    navigatorClipboard,
    protoDesc: { get: () => navigatorClipboard, configurable: true },
    navigator: {},
    document: {
      addEventListener: (type: string, fn: (e: unknown) => void) => copyListeners.set(type, fn),
      removeEventListener: (type: string) => copyListeners.delete(type),
    },
    onSignal: vi.fn(),
    ...overrides,
    copyListeners,
  }
}

describe('extractCopyText', () => {
  it('reads the text/plain payload of a copy event', () => {
    expect(extractCopyText({ clipboardData: { getData: (t: string) => (t === 'text/plain' ? 'dsh plugin add a/b' : '') } })).toBe('dsh plugin add a/b')
  })

  it('returns null without clipboard data', () => {
    expect(extractCopyText({ clipboardData: null })).toBeNull()
  })
})

describe('installClipboardIntercept', () => {
  it('signals through the wrapped writeText and restores the original on dispose', async () => {
    const host = fakeHost()
    const dispose = installClipboardIntercept(host)
    const wrapped = (host.navigator as { clipboard: { writeText(t: string): Promise<void> } }).clipboard
    await wrapped.writeText('dsh plugin add a/b')
    expect(host.onSignal).toHaveBeenCalledWith('dsh plugin add a/b')
    dispose()
    // After dispose the own property is gone: the original clipboard no longer signals.
    await host.navigatorClipboard!.writeText('x')
    expect(host.onSignal).toHaveBeenCalledTimes(1)
  })

  it('signals through document copy events', () => {
    const host = fakeHost()
    installClipboardIntercept(host)
    host.copyListeners.get('copy')!({ clipboardData: { getData: () => 'dsh plugin add c/d' } })
    expect(host.onSignal).toHaveBeenCalledWith('dsh plugin add c/d')
  })

  it('removes the copy listener on dispose', () => {
    const host = fakeHost()
    const dispose = installClipboardIntercept(host)
    dispose()
    expect(host.copyListeners.size).toBe(0)
  })

  it('installs nothing when there is no clipboard to wrap', () => {
    const host = fakeHost({ navigatorClipboard: null, protoDesc: null })
    const dispose = installClipboardIntercept(host)
    expect(host.onSignal).not.toHaveBeenCalled()
    dispose()
  })
})

describe('dedupeSignal', () => {
  it('collapses rapid duplicate signals into one', () => {
    const fn = vi.fn()
    const signal = dedupeSignal(fn, 100)
    signal('dsh plugin add a/b')
    signal('dsh plugin add a/b')
    expect(fn).toHaveBeenCalledTimes(1)
  })

  it('lets a distinct signal through', () => {
    const fn = vi.fn()
    const signal = dedupeSignal(fn, 100)
    signal('a')
    signal('b')
    expect(fn).toHaveBeenCalledTimes(2)
  })
})
