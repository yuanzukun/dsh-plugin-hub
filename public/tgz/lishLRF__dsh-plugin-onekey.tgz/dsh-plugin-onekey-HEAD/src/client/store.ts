/**
 * A minimal observable cell: identity-compared value + subscriber roster.
 * The React binding (`useCell`) sits in the UI layer; the cell itself stays
 * framework-free so tests need no DOM.
 */

export interface Cell<T> {
  get(): T
  set(next: T): void
  subscribe(listener: () => void): () => void
}

export function createCell<T>(initial: T): Cell<T> {
  let value = initial
  const listeners = new Set<() => void>()
  return {
    get: () => value,
    set: (next) => {
      if (next === value) return
      value = next
      for (const listener of [...listeners]) listener()
    },
    subscribe: (listener) => {
      listeners.add(listener)
      return () => { listeners.delete(listener) }
    },
  }
}
