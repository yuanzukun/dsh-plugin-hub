/**
 * Clipboard interception layer (client side, reversible).
 *
 * The plugin hub's "copy install command" writes through
 * `navigator.clipboard.writeText` (primary) or `document.execCommand('copy')`
 * on a hidden textarea (fallback — which fires a document `copy` event).
 * We wrap the former and capture the latter as a SIGNAL ONLY; the backend
 * then reads the OS clipboard itself. Both hooks are removed on dispose, so
 * the capability exists exactly as long as the plugin is enabled.
 */

export interface ClipboardLike {
  writeText(text: string): Promise<void>
}

export interface CopyEventLike {
  clipboardData?: { getData(type: string): string } | null
}

export interface InterceptHost {
  /** The real clipboard object to wrap. */
  navigatorClipboard?: ClipboardLike | null
  /** The prototype descriptor, used to decide whether wrapping is possible. */
  protoDesc?: { get?: () => ClipboardLike; configurable?: boolean } | null
  /** The navigator instance to patch (own `clipboard` property, deleted on dispose). */
  navigator: Record<string, unknown>
  /** The document for the capture-phase `copy` listener; null in non-DOM tests. */
  document?: {
    addEventListener(type: string, fn: (event: unknown) => void): void
    removeEventListener(type: string, fn: (event: unknown) => void): void
  } | null
  /** Signal sink: the captured text, or null when only the event was seen. */
  onSignal(text: string | null): void
}

/** Extract the plain-text payload of a copy event, or null. */
export function extractCopyText(event: CopyEventLike): string | null {
  const data = event.clipboardData?.getData('text/plain')
  return typeof data === 'string' && data.length > 0 ? data : null
}

const CLIPBOARD_KEY = 'clipboard'

/**
 * Install the interception hooks; returns the disposer that restores the
 * original behavior. Safe to call when wrapping is impossible (no clipboard
 * API) — it then only observes copy events.
 */
export function installClipboardIntercept(host: InterceptHost): () => void {
  const copyHandler = (event: unknown) => {
    host.onSignal(extractCopyText(event as CopyEventLike))
  }
  const disposers: Array<() => void> = []

  if (host.document) {
    host.document.addEventListener('copy', copyHandler)
    disposers.push(() => host.document!.removeEventListener('copy', copyHandler))
  }

  const original = host.navigatorClipboard
  if (original) {
    const wrapped: ClipboardLike = {
      writeText: async (text: string) => {
        await original.writeText(text)
        host.onSignal(text)
      },
    }
    // Shadow `navigator.clipboard` with an own property; browsers expose it as
    // a configurable prototype getter. When shadowing is impossible we simply
    // skip the wrap — the copy-event path still observes the fallback path.
    try {
      Object.defineProperty(host.navigator, CLIPBOARD_KEY, {
        configurable: true,
        enumerable: true,
        get: () => wrapped,
      })
      disposers.push(() => {
        delete host.navigator[CLIPBOARD_KEY]
      })
    } catch {
      // non-configurable clipboard surface — nothing to restore
    }
  }

  return () => {
    for (const dispose of disposers) dispose()
  }
}

/** Collapse rapid duplicate signals (same text) into a single call. */
export function dedupeSignal(fn: (text: string | null) => void, windowMs: number): (text: string | null) => void {
  let lastText: string | null | undefined
  let lastAt = 0
  return (text) => {
    const now = Date.now()
    if (text === lastText && now - lastAt < windowMs) return
    lastText = text
    lastAt = now
    fn(text)
  }
}
