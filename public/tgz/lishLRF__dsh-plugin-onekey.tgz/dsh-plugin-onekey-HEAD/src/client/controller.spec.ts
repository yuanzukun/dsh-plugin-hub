import { describe, expect, it, vi } from 'vitest'
import { createController, type ControllerDeps } from './controller'
import type { DialogEvent, DialogState } from './state'
import { dialogReducer, initialDialog } from './state'

interface JobBody {
  phase: string
  percent: number
  log: string[]
  error?: string
  done: boolean
}

function setup(overrides: Partial<ControllerDeps> = {}) {
  const dispatched: DialogEvent[] = []
  const state: { current: DialogState } = { current: initialDialog }
  const dispatch = (event: DialogEvent) => {
    dispatched.push(event)
    state.current = dialogReducer(state.current, event)
  }
  const deps: ControllerDeps = {
    api: {
      install: vi.fn(async () => ({ status: 202, body: { jobId: 'j1' } })),
      uninstall: vi.fn(async () => ({ status: 202, body: { jobId: 'j2', restarting: true } })),
      restart: vi.fn(async () => ({ status: 200, body: { ok: true } })),
      job: vi.fn(async () => ({ status: 200, body: { phase: 'done', percent: 100, log: ['ok'], done: true } })),
      ping: vi.fn(async () => true),
    },
    dispatch,
    state: () => state.current,
    prompt: () => 'ASK',
    bridge: { current: null },
    reload: vi.fn(),
    sleep: async () => {},
    ...overrides,
  }
  const controller = createController(deps)
  return { controller, dispatched, dispatch, state, deps }
}

const enterConfirmInstall = (setupResult: ReturnType<typeof setup>) => {
  setupResult.dispatch({ type: 'show-confirm-install', spec: 'a/b', command: 'dsh plugin add a/b' })
}

describe('createController', () => {
  it('posts the command on confirm and drives the dialog to success', async () => {
    const s = setup()
    enterConfirmInstall(s)
    await s.controller.confirmInstall()
    expect(s.deps.api.install).toHaveBeenCalledWith('dsh plugin add a/b')
    expect(s.deps.api.job).toHaveBeenCalledWith('j1')
    expect(s.state.current.status).toBe('success')
  })

  it('posts nothing when the command is unknown so the backend reads the clipboard', async () => {
    const s = setup()
    s.dispatch({ type: 'show-confirm-install', spec: '', command: '' })
    await s.controller.confirmInstall()
    expect(s.deps.api.install).toHaveBeenCalledWith(undefined)
  })

  it('fails the dialog with the job error', async () => {
    const s = setup()
    enterConfirmInstall(s)
    s.deps.api.job = vi.fn(async () => ({ status: 200, body: { phase: 'failed', percent: 40, log: ['ERR'], error: 'pnpm exploded', done: true } }))
    await s.controller.confirmInstall()
    expect(s.state.current.status).toBe('failed')
    expect(s.state.current.error).toBe('pnpm exploded')
  })

  it('ignores confirm when the dialog is not in a confirm state', async () => {
    const s = setup()
    await s.controller.confirmInstall()
    expect(s.deps.api.install).not.toHaveBeenCalled()
  })

  it('uninstall confirm drives uninstall → success → restarting with ping + reload', async () => {
    const s = setup()
    s.dispatch({ type: 'show-confirm-uninstall', target: 'dsh-x' })
    await s.controller.confirmUninstall()
    expect(s.deps.api.uninstall).toHaveBeenCalledWith('dsh-x')
    expect(s.deps.api.ping).toHaveBeenCalled()
    expect(s.deps.reload).toHaveBeenCalled()
  })

  it('uninstall survives a dying backend during job polling and goes to restarting', async () => {
    const s = setup()
    s.dispatch({ type: 'show-confirm-uninstall', target: 'dsh-x' })
    s.deps.api.job = vi.fn(async () => { throw new Error('ECONNREFUSED') })
    await s.controller.confirmUninstall()
    expect(s.deps.api.ping).toHaveBeenCalled()
    expect(s.deps.reload).toHaveBeenCalled()
    expect(s.state.current.status).not.toBe('failed')
  })

  it('install treats a dying backend as a real failure', async () => {
    const s = setup()
    enterConfirmInstall(s)
    s.deps.api.job = vi.fn(async () => { throw new Error('ECONNREFUSED') })
    await s.controller.confirmInstall()
    expect(s.state.current.status).toBe('failed')
    expect(s.deps.api.ping).not.toHaveBeenCalled()
  })

  it('restartNow pings and reloads once the backend answers', async () => {
    const s = setup()
    s.dispatch({ type: 'show-confirm-install', spec: 'x', command: 'y' })
    s.dispatch({ type: 'start', jobId: 'j1' })
    s.dispatch({ type: 'success' })
    await s.controller.restartNow()
    expect(s.deps.api.restart).toHaveBeenCalled()
    expect(s.deps.reload).toHaveBeenCalled()
  })

  it('restartNow surfaces a permission rejection instead of restarting', async () => {
    const s = setup()
    s.dispatch({ type: 'show-confirm-install', spec: 'x', command: 'y' })
    s.dispatch({ type: 'start', jobId: 'j1' })
    s.dispatch({ type: 'success' })
    s.deps.api.restart = vi.fn(async () => ({ status: 403, body: { error: 'restart-not-allowed' } }))
    await s.controller.restartNow()
    expect(s.state.current.status).toBe('notice')
    expect(s.state.current.notice).toContain('自动重启后端权限未开启')
    expect(s.deps.api.ping).not.toHaveBeenCalled()
    expect(s.deps.reload).not.toHaveBeenCalled()
  })

  it('askLlm pastes the prompt and closes the dialog', async () => {
    const s = setup()
    s.dispatch({ type: 'show-confirm-install', spec: 'x', command: 'y' })
    s.dispatch({ type: 'start', jobId: 'j1' })
    s.dispatch({ type: 'fail', error: 'boom' })
    const setDraft = vi.fn()
    s.deps.bridge.current = { getDraft: () => '', setDraft }
    s.controller.askLlm()
    expect(setDraft).toHaveBeenCalledWith('ASK')
    expect(s.state.current.status).toBe('idle')
  })

  it('askLlm appends below an existing draft', async () => {
    const s = setup()
    s.dispatch({ type: 'show-confirm-install', spec: 'x', command: 'y' })
    s.dispatch({ type: 'start', jobId: 'j1' })
    s.dispatch({ type: 'fail', error: 'boom' })
    const setDraft = vi.fn()
    s.deps.bridge.current = { getDraft: () => '你好', setDraft }
    s.controller.askLlm()
    expect(setDraft).toHaveBeenCalledWith('你好\n\nASK')
  })
})
