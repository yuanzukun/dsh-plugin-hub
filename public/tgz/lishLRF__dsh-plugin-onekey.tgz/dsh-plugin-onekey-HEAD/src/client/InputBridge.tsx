/**
 * The `conversation.input.overlay` entry: a zero-pixel bridge that holds the
 * current session's `inputActions` + draft hook so the modal can hand the
 * error text to the composer ("copy to workspace and ask the LLM").
 */
import { useEffect } from 'react'
import type { ComposerBridge } from './controller.ts'

export interface InputBridgeProps {
  bridge: ComposerBridge
  useInput?: () => { draft: string } | undefined
  inputActions?: { setDraft(text: string): void }
}

export function InputBridgeView({ bridge, useInput, inputActions }: InputBridgeProps) {
  useEffect(() => {
    bridge.current = {
      getDraft: () => useInput?.()?.draft ?? '',
      setDraft: (text) => { inputActions?.setDraft(text) },
    }
    return () => {
      bridge.current = null
    }
  }, [bridge, useInput, inputActions])
  return null
}
