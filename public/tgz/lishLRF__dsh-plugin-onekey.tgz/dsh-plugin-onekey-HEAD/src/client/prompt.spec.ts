import { describe, expect, it } from 'vitest'
import { buildAskLlmPrompt } from './prompt'

describe('buildAskLlmPrompt', () => {
  it('renders the environment, command and error sections in order', () => {
    const text = buildAskLlmPrompt({
      profileName: 'web',
      command: 'dsh plugin add liustack/modlens',
      error: 'pnpm: EPERM',
    })
    expect(text).toContain('DSH 插件一键安装失败')
    const profileAt = text.indexOf('profile：web')
    const commandAt = text.indexOf('dsh plugin add liustack/modlens')
    const errorAt = text.indexOf('pnpm: EPERM')
    expect(profileAt).toBeGreaterThanOrEqual(0)
    expect(commandAt).toBeGreaterThan(profileAt)
    expect(errorAt).toBeGreaterThan(commandAt)
  })

  it('omits the profile line when none is known', () => {
    const text = buildAskLlmPrompt({ command: 'cmd', error: 'err' })
    expect(text).not.toContain('profile：')
  })

  it('trims the error block but keeps its inner structure', () => {
    const text = buildAskLlmPrompt({ command: 'cmd', error: '  line1\nline2\n  ' })
    expect(text).toContain('line1\nline2\n要求：')
    expect(text).not.toContain('line2\n  \n要求')
  })

  it('asks for a Chinese answer with copy-pasteable commands', () => {
    const text = buildAskLlmPrompt({ command: 'cmd', error: 'err' })
    expect(text).toContain('用中文回答')
    expect(text).toContain('可直接执行')
  })
})
