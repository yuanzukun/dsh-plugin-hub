/**
 * The "copy to workspace and ask the LLM" prompt template. Pure — the error
 * text is inserted verbatim so the model sees the real diagnostics.
 */

export interface AskLlmInput {
  /** The DSH profile the failure happened in (omitted from the prompt when unknown). */
  profileName?: string
  /** The canonical install command that failed. */
  command: string
  /** The captured error output. */
  error: string
}

export function buildAskLlmPrompt(input: AskLlmInput): string {
  const error = input.error.trim()
  const profileLine = input.profileName === undefined ? '' : `- profile：${input.profileName}\n`
  return [
    '【DSH 插件一键安装失败，请帮我诊断修复】',
    '我在 DeepSeek Harness 插件中心安装插件时，后端自动安装报错。请先解释失败原因，再给出分步修复方案（含可直接执行的命令）。',
    profileLine + `- 安装命令：${input.command}`,
    '- 错误输出：',
    error,
    '要求：1) 用中文回答；2) 涉及 pnpm 时说明版本与 allowBuilds 配置；3) 修复步骤给出可复制粘贴的命令。',
  ].join('\n')
}
