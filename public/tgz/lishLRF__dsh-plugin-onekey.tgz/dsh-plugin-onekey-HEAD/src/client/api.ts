/**
 * Thin fetch client for the host's `/plugins/onekey` routes.
 */
import type { JobBody } from './controller.ts'

export interface HostPermissions {
  enabled: boolean
  allowInstall: boolean
  allowUninstall: boolean
  allowRestart: boolean
  allowClipboard: boolean
}

export interface HostState {
  enabled: boolean
  permissions: HostPermissions
  profile: { name: string; dir: string }
  pnpm: { available: boolean }
  restart: { command: string; cwd: string }
  activeJobs: number
}

export interface RemovableView {
  name: string
  version: string
}

export interface Api {
  state(): Promise<{ status: number; body: unknown }>
  removable(): Promise<{ status: number; body: unknown }>
  install(text?: string): Promise<{ status: number; body: unknown }>
  uninstall(name: string): Promise<{ status: number; body: unknown }>
  restart(): Promise<{ status: number; body: unknown }>
  job(id: string): Promise<{ status: number; body: JobBody }>
  ping(): Promise<boolean>
}

async function request<T = unknown>(path: string, init?: RequestInit): Promise<{ status: number; body: T }> {
  const response = await fetch(path, init)
  let body: unknown = {}
  try {
    body = await response.json()
  } catch {
    // empty body
  }
  return { status: response.status, body: body as T }
}

const POST_JSON: RequestInit = {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
}

export function createApi(): Api {
  return {
    state: () => request('/plugins/onekey/state'),
    removable: () => request('/plugins/onekey/removable'),
    install: (text) => request('/plugins/onekey/install', {
      ...POST_JSON,
      body: JSON.stringify(text === undefined ? {} : { text }),
    }),
    uninstall: (name) => request('/plugins/onekey/uninstall', {
      ...POST_JSON,
      body: JSON.stringify({ name }),
    }),
    restart: () => request('/plugins/onekey/restart', { ...POST_JSON, body: '{}' }),
    job: (id) => request<JobBody>(`/plugins/onekey/jobs/${encodeURIComponent(id)}`),
    ping: async () => {
      try {
        const response = await fetch('/plugins/onekey/ping', { cache: 'no-store' })
        return response.ok
      } catch {
        return false
      }
    },
  }
}
