import { describe, expect, it } from 'vitest'
import { dialogReducer, initialDialog, type DialogEvent, type DialogState } from './state'

const reduce = (events: DialogEvent[], from: DialogState = initialDialog): DialogState =>
  events.reduce(dialogReducer, from)

describe('dialog state machine', () => {
  it('opens an install confirmation from idle', () => {
    const state = reduce([{ type: 'show-confirm-install', spec: 'github:a/b', command: 'dsh plugin add a/b' }])
    expect(state).toMatchObject({ status: 'confirm-install', spec: 'github:a/b', command: 'dsh plugin add a/b' })
  })

  it('opens an uninstall confirmation from idle', () => {
    const state = reduce([{ type: 'show-confirm-uninstall', target: 'dsh-3d-model-viewer' }])
    expect(state).toMatchObject({ status: 'confirm-uninstall', uninstallTarget: 'dsh-3d-model-viewer' })
  })

  it('moves confirm → running with the job id', () => {
    const state = reduce([
      { type: 'show-confirm-install', spec: 'x', command: 'y' },
      { type: 'start', jobId: 'j1' },
    ])
    expect(state).toMatchObject({ status: 'running', jobId: 'j1', progress: 0 })
  })

  it('applies monotonic progress while running', () => {
    const state = reduce([
      { type: 'show-confirm-install', spec: 'x', command: 'y' },
      { type: 'start', jobId: 'j1' },
      { type: 'progress', percent: 30, log: ['a'] },
      { type: 'progress', percent: 90, log: ['a', 'b'] },
    ])
    expect(state.progress).toBe(90)
    expect(state.logTail).toEqual(['a', 'b'])
  })

  it('never moves progress backwards', () => {
    const state = reduce([
      { type: 'show-confirm-install', spec: 'x', command: 'y' },
      { type: 'start', jobId: 'j1' },
      { type: 'progress', percent: 90, log: [] },
      { type: 'progress', percent: 10, log: [] },
    ])
    expect(state.progress).toBe(90)
  })

  it('reaches success from running', () => {
    const state = reduce([
      { type: 'show-confirm-install', spec: 'x', command: 'y' },
      { type: 'start', jobId: 'j1' },
      { type: 'success' },
    ])
    expect(state.status).toBe('success')
  })

  it('fails with the captured error', () => {
    const state = reduce([
      { type: 'show-confirm-install', spec: 'x', command: 'y' },
      { type: 'start', jobId: 'j1' },
      { type: 'fail', error: 'pnpm: EPERM' },
    ])
    expect(state).toMatchObject({ status: 'failed', error: 'pnpm: EPERM' })
  })

  it('enters restarting from success and counts ticks', () => {
    const state = reduce([
      { type: 'show-confirm-install', spec: 'x', command: 'y' },
      { type: 'start', jobId: 'j1' },
      { type: 'success' },
      { type: 'restarting' },
      { type: 'restart-tick' },
      { type: 'restart-tick' },
    ])
    expect(state.status).toBe('restarting')
    expect(state.restart).toMatchObject({ attempts: 2 })
  })

  it('closes back to idle from any state', () => {
    const failed = reduce([
      { type: 'show-confirm-install', spec: 'x', command: 'y' },
      { type: 'start', jobId: 'j1' },
      { type: 'fail', error: 'x' },
      { type: 'close' },
    ])
    expect(failed).toEqual(initialDialog)
  })

  it('ignores progress events outside the running state', () => {
    const state = reduce([{ type: 'progress', percent: 50, log: [] }])
    expect(state).toEqual(initialDialog)
  })

  it('ignores restart ticks outside the restarting state', () => {
    const state = reduce([{ type: 'restart-tick' }])
    expect(state).toEqual(initialDialog)
  })

  it('shows a notice from idle and any settled state', () => {
    const state = reduce([{ type: 'show-notice', text: '请从候选列表选择' }])
    expect(state).toMatchObject({ status: 'notice', notice: '请从候选列表选择' })
  })

  it('does not interrupt a running job with a notice', () => {
    const state = reduce([
      { type: 'show-confirm-install', spec: 'x', command: 'y' },
      { type: 'start', jobId: 'j1' },
      { type: 'show-notice', text: 'nope' },
    ])
    expect(state.status).toBe('running')
  })
})
