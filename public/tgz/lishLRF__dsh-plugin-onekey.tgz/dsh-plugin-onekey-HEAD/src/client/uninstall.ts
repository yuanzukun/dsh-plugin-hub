/**
 * The `/卸载` slash-command source (pure helpers + the source factory).
 * Registered into `ctx.inputTriggers`; picking a candidate is `'handled'` —
 * the flow never reaches the model. The backend then uninstalls and restarts.
 */
import type { InputTriggerCandidate, InputTriggerPick, InputTriggerSource } from './input-trigger-types.ts'
import type { RemovableEntry } from '../removable.ts'

/** Filter the removable list against the menu query (case-insensitive). */
export function filterCandidates(entries: readonly RemovableEntry[], query: string): RemovableEntry[] {
  const needle = query.trim().toLowerCase()
  if (needle === '') return [...entries]
  return entries.filter(entry => entry.name.toLowerCase().includes(needle))
}

/**
 * Interpret the trigger query for this source. The pipeline hands every `/`
 * source the full text after the slash, so the source must recognize its own
 * command name inside it:
 *  - ''            → bare slash: show the whole group;
 *  - '卸载'         → exact command name: show everything;
 *  - '卸载 <arg>'   → filter by the argument;
 *  - anything else  → not this command: stay hidden.
 */
export function parseUninstallQuery(query: string): { ok: true; arg: string } | { ok: false } {
  const trimmed = query.trim()
  if (trimmed === '') return { ok: true, arg: '' }
  if (trimmed === '卸载') return { ok: true, arg: '' }
  if (trimmed.startsWith('卸载')) return { ok: true, arg: trimmed.slice('卸载'.length).trim() }
  return { ok: false }
}

/** Whether a full submitted line is a `/卸载` command (bare or with one argument). */
export function matchesUninstallLine(line: string): boolean {
  const trimmed = line.trim()
  if (trimmed === '/卸载') return true
  return /^\/卸载\s+\S+$/u.test(trimmed)
}

export interface UninstallSourceHooks {
  /** Gate: the plugin must be enabled and uninstall permitted. */
  canRun(): boolean
  /** Fetch the removable list (backend route, cached by the caller). */
  list(): Promise<readonly RemovableEntry[]>
  /** A candidate was picked — open the confirmation popup. */
  onPickPlugin(name: string): void
  /** The command line was submitted without a pick — show guidance. */
  onBareCommand(): void
  /** Label of the explanatory row shown when nothing is removable. */
  emptyLabel?: string
}

/** Sentinel candidate value: picking it never targets a plugin. */
export const NONE_VALUE = '__none__'

/**
 * Build the `/` trigger source. Every path ends in `'handled'`, so nothing
 * this command does ever enters the model pipeline. An empty removable list
 * yields one explanatory row (instead of an empty group, which the menu
 * auto-closes into the “flash and disappear” the user sees).
 */
export function createUninstallSource(hooks: UninstallSourceHooks): InputTriggerSource {
  return {
    trigger: '/',
    name: '卸载',
    order: 90,
    async candidates(_session, request) {
      if (!hooks.canRun()) return []
      const parsed = parseUninstallQuery(request.query)
      if (!parsed.ok) return []
      const entries = await hooks.list()
      const candidates = filterCandidates(entries, parsed.arg).map((entry): InputTriggerCandidate => ({
        name: entry.name,
        description: `v${entry.version}`,
        value: entry.name,
      }))
      if (candidates.length === 0 && hooks.emptyLabel !== undefined) {
        return [{ name: hooks.emptyLabel, value: NONE_VALUE }]
      }
      return candidates
    },
    onPick(pick: InputTriggerPick) {
      if (!hooks.canRun()) return undefined
      const name = pick.candidate.value
      if (typeof name !== 'string' || name === '') return undefined
      if (name === NONE_VALUE) {
        hooks.onBareCommand()
        return 'handled'
      }
      hooks.onPickPlugin(name)
      return 'handled'
    },
    async matchEnter(_session, line) {
      if (!hooks.canRun()) return undefined
      if (matchesUninstallLine(line)) {
        hooks.onBareCommand()
        return 'handled'
      }
      return undefined
    },
  }
}
