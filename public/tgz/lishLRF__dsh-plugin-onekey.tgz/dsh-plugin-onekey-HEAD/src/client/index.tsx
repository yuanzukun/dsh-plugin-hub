/**
 * dsh-plugin-onekey client entry.
 *
 * Wires, all reversible through ctx.effect:
 *  - the clipboard interception layer (install trigger signal)
 *  - the global modal via `shell.overlay`
 *  - the `/卸载` slash source via `inputTriggers`
 *  - the composer bridge via `conversation.input.overlay`
 *  - the configuration card via `settings.plugin.item`
 * Every registration dies with the plugin fiber, so disabling the plugin
 * removes the capabilities; re-enabling restores them.
 */
import { buildAskLlmPrompt } from './prompt.ts'
import { installClipboardIntercept, dedupeSignal, type InterceptHost } from './trigger.ts'
import { decideCopySignal } from './trigger-decision.ts'
import { dialogReducer, initialDialog, type DialogEvent } from './state.ts'
import { createCell } from './store.ts'
import { createApi, type HostState, type RemovableView } from './api.ts'
import { createController, type ComposerBridge } from './controller.ts'
import { createUninstallSource } from './uninstall.ts'
import { OneKeyOverlay } from './Overlay.tsx'
import { InputBridgeView } from './InputBridge.tsx'
import { SettingsCardView } from './SettingsCard.tsx'
import { zh, en } from './locales.ts'
import type { ClientContext } from './dsh.ts'

/** Settings namespace / slot keys (kept literal here to avoid pulling the host schema bundle into the client). */
const NS = 'dsh-plugin-onekey'

export const name = NS

/** Cordis client services this plugin needs before its apply runs. */
export const inject = ['slots', 'locale', 'inputTriggers']

export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'onekey: dictionaries')
  const t = ctx.locale.bind(NS)

  const api = createApi()
  const hostCell = createCell<HostState | null>(null)
  const dialog = createCell(initialDialog)
  const bridge: ComposerBridge = { current: null }

  const dispatch = (event: DialogEvent): void => {
    dialog.set(dialogReducer(dialog.get(), event))
  }

  const refreshHost = async (): Promise<void> => {
    const result = await api.state()
    if (result.status === 200) hostCell.set(result.body as HostState)
  }
  void refreshHost()

  const controller = createController({
    api,
    dispatch,
    state: () => dialog.get(),
    prompt: (input) => buildAskLlmPrompt({
      ...(hostCell.get() === null ? {} : { profileName: hostCell.get()!.profile.name }),
      command: input.command,
      error: input.error,
    }),
    bridge,
    reload: () => { window.location.reload() },
    sleep: (ms) => new Promise<void>((resolve) => setTimeout(resolve, ms)),
  })

  // ——— Clipboard interception: the install-trigger signal. ———
  const onCopySignal = dedupeSignal((text) => {
    void (async () => {
      const decision = decideCopySignal(text)
      if (decision.action === 'ignore') return
      if (hostCell.get() === null) await refreshHost()
      const host = hostCell.get()
      if (host === null || !host.enabled) return
      dispatch({ type: 'show-confirm-install', spec: decision.spec, command: decision.command })
    })()
  }, 300)

  const interceptHost: InterceptHost = {
    navigatorClipboard: navigator.clipboard ?? null,
    navigator: navigator as unknown as Record<string, unknown>,
    document: document as unknown as NonNullable<InterceptHost['document']>,
    onSignal: (text) => onCopySignal(text),
  }
  ctx.effect(() => installClipboardIntercept(interceptHost), 'onekey: clipboard intercept')

  // ——— Global modal. ———
  ctx.inject(['slots'], (sctx) => {
    sctx.slots.inject('shell.overlay', () => sctx.slots.register({
      name: 'shell.overlay',
      id: 'onekey-modal',
      order: 50,
      inject: () => ({ dialog, actions: controller, t }),
    }, OneKeyOverlay))
  })

  // ——— Composer bridge ("copy to workspace and ask the LLM"). ———
  ctx.inject(['slots'], (sctx) => {
    sctx.slots.inject('conversation.input.overlay', () => sctx.slots.register({
      name: 'conversation.input.overlay',
      id: 'onekey-input',
      order: 99,
      inject: () => ({ bridge }),
    }, InputBridgeView))
  })

  // ——— /卸载 slash source. ———
  ctx.inject(['inputTriggers'], (sctx) => {
    const source = createUninstallSource({
      canRun: () => {
        const host = hostCell.get()
        return host !== null && host.enabled && host.permissions.allowUninstall
      },
      list: async () => {
        // First menu open right after a page load may race the host-state
        // fetch — refresh it once before asking the backend for the list.
        if (hostCell.get() === null) await refreshHost()
        const result = await api.removable()
        return result.status === 200 ? (result.body as RemovableView[]) : []
      },
      onPickPlugin: (target) => dispatch({ type: 'show-confirm-uninstall', target }),
      onBareCommand: () => dispatch({ type: 'show-notice', text: t('notice.pickFromMenu') }),
      emptyLabel: t('uninstall.empty'),
    })
    sctx.effect(() => sctx.inputTriggers.registerSource(source), 'onekey: /卸载')
  })

  // ——— Settings → Plugins → Plugin configuration card. ———
  ctx.inject(['slots', 'settingsScope'], (sctx) => {
    const scope = sctx.settingsScope.bind({ namespace: NS })
    sctx.slots.inject('settings.plugin.item', () => sctx.slots.register({
      name: 'settings.plugin.item',
      key: NS,
      locale: NS,
      inject: () => ({ scope, hostCell, t, refreshHost }),
    }, SettingsCardView))
  })
}
