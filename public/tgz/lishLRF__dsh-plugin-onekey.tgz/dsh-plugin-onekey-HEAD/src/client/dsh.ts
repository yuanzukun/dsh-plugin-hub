/**
 * Minimal structural types for the DSH client runtime services this plugin
 * consumes. Declared locally (not imported from `@deepseek-ai/*` at runtime)
 * so the browser bundle has no cross-plugin value imports — the real
 * services satisfy these shapes at runtime. Same approach as the reference
 * dsh-3d-model-viewer plugin.
 */

export interface LocaleService {
  register(namespace: string, dicts: { zh: Record<string, string>; en: Record<string, string> }): unknown
  bind(namespace: string): (key: string, params?: Record<string, string | number>) => string
}

export interface SlotsService {
  inject(slot: string, register: () => unknown): void
  register(meta: Record<string, unknown>, component: unknown): unknown
}

export interface SessionsService {
  scope(id: string): ClientContext | undefined
}

export interface InputTriggerRegistry {
  registerSource(source: unknown): () => void
}

export interface SettingsScope<T> {
  getSnapshot(): {
    status: 'loading' | 'ready' | 'unavailable'
    value: T | undefined
    base: unknown
    user: unknown
    revision: number | undefined
    writable: boolean
    mode: 'host' | 'memory'
  }
  subscribe(listener: () => void): () => void
  set(field: string, value: unknown): Promise<void>
  unset(field: string): Promise<void>
}

export interface SettingsScopeService {
  bind(spec: { namespace: string }): SettingsScope<unknown>
}

export interface ClientContext {
  slots: SlotsService
  locale: LocaleService
  sessions: SessionsService
  inputTriggers: InputTriggerRegistry
  settingsScope: SettingsScopeService
  get<T = unknown>(name: string): T | undefined
  effect(callback: () => unknown, label?: string): void
  inject(services: string[], callback: (ctx: ClientContext) => void): void
}
