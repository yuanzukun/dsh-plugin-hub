/**
 * Structural subset of the DSH input-trigger pipeline contract
 * (packages/client/ui-input-trigger) — the exact shapes a trigger source
 * must satisfy at runtime. Type-only: no cross-plugin value imports.
 */

export interface ClientSessionContext {
  readonly sessionId: string
}

export interface InputTriggerCandidate {
  readonly name: string
  readonly description?: string
  readonly icon?: string
  readonly hint?: string
  readonly section?: string
  readonly value?: string
}

export interface TokenSpan {
  readonly start: number
  readonly end: number
  readonly draftRev: number
}

export interface InputTriggerPick {
  readonly candidate: InputTriggerCandidate
  readonly session: ClientSessionContext
  readonly position: 'leading' | 'inline'
  readonly via: 'menu' | 'space' | 'enter'
  readonly span: TokenSpan
}

export interface CandidateRequest {
  readonly query: string
  readonly quoted?: boolean
  readonly position: 'leading' | 'inline'
  readonly signal: AbortSignal
}

export interface SubmitEnvelope {
  readonly images: number
}

/** PickOutcome subset this plugin produces ('handled' / undefined). */
export type PickOutcome = 'handled' | undefined

export interface InputTriggerSource {
  readonly trigger: '/' | '@'
  readonly name: string
  readonly order?: number
  readonly showGroupTitle?: boolean
  candidates(session: ClientSessionContext, req: CandidateRequest): Promise<readonly InputTriggerCandidate[]>
  onPick(pick: InputTriggerPick): PickOutcome
  matchEnter?(
    session: ClientSessionContext,
    line: string,
    signal: AbortSignal,
    envelope: SubmitEnvelope,
  ): Promise<PickOutcome>
  warm?(session: ClientSessionContext): void
}
