import { describe, expect, it } from 'vitest'
import { decideCopySignal } from './trigger-decision'

describe('decideCopySignal', () => {
  it('ignores a signal without text (native copies with empty payloads)', () => {
    expect(decideCopySignal(null)).toEqual({ action: 'ignore' })
  })

  it('ignores arbitrary copied conversation text', () => {
    expect(decideCopySignal('今天天气不错')).toEqual({ action: 'ignore' })
    expect(decideCopySignal('请帮我看看这个插件怎么装')).toEqual({ action: 'ignore' })
  })

  it('ignores multiline payloads that merely contain a command line', () => {
    const text = '我的安装记录如下：\ndsh plugin add liustack/modlens\n谢谢！'
    expect(decideCopySignal(text)).toEqual({ action: 'ignore' })
  })

  it('opens only for an exact install command line', () => {
    expect(decideCopySignal('dsh plugin add liustack/modlens')).toEqual({
      action: 'open',
      spec: 'liustack/modlens',
      command: 'dsh plugin add liustack/modlens',
    })
  })

  it('still opens for the --profile form copied from chat', () => {
    const decision = decideCopySignal('dsh plugin --profile web add dsh-plugin-onekey')
    expect(decision).toMatchObject({ action: 'open', command: 'dsh plugin --profile web add dsh-plugin-onekey' })
  })
})
