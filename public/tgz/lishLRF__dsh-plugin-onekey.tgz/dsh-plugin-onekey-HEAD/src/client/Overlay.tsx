/**
 * The `shell.overlay` slot entry: subscribes the dialog cell and renders the
 * global modal. Registered from the client apply; unmounts with the plugin.
 */
import { useSyncExternalStore } from 'react'
import type { OneKeyActions } from './controller.ts'
import { OneKeyModal, type Translate } from './Modal.tsx'
import type { Cell } from './store.ts'
import type { DialogState } from './state.ts'

export interface OverlayInjected {
  dialog: Cell<DialogState>
  actions: OneKeyActions
  t: Translate
}

export function OneKeyOverlay({ dialog, actions, t }: OverlayInjected) {
  const state = useSyncExternalStore(dialog.subscribe, dialog.get)
  return <OneKeyModal state={state} actions={actions} t={t} />
}
