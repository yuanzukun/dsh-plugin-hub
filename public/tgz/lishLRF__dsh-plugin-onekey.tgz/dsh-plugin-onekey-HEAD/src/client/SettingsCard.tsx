/**
 * `settings.plugin.item` card (Settings → Plugins → Plugin configuration):
 * the enable switch, the four permission checkboxes, and the auto-detected
 * environment report. Writes go through the official settingsScope (revision
 * fenced by the settings service).
 */
import { useSyncExternalStore } from 'react'
import type { HostState } from './api.ts'
import type { Config } from '../config.ts'
import type { SettingsScope } from './dsh.ts'
import type { Cell } from './store.ts'
import css from './styles.module.css'
import type { Translate } from './Modal.tsx'

export interface SettingsCardInjected {
  scope: SettingsScope<Config>
  hostCell: Cell<HostState | null>
  t: Translate
  refreshHost(): void
}

const FIELDS: { key: keyof Config; label: string; hint?: string }[] = [
  { key: 'enabled', label: 'settings.enabled', hint: 'settings.enabledHint' },
  { key: 'allowInstall', label: 'settings.allowInstall' },
  { key: 'allowUninstall', label: 'settings.allowUninstall' },
  { key: 'allowRestart', label: 'settings.allowRestart' },
  { key: 'allowClipboard', label: 'settings.allowClipboard' },
]

export function SettingsCardView({ scope, hostCell, t, refreshHost }: SettingsCardInjected) {
  const snapshot = useSyncExternalStore(scope.subscribe, scope.getSnapshot)
  const host = useSyncExternalStore(hostCell.subscribe, hostCell.get)
  const value = snapshot.value
  const ready = snapshot.status === 'ready'
  const writable = snapshot.writable

  return (
    <div className={css.card}>
      <div className={css.cardHead}>
        <div className={css.cardTitle}>{t('settings.title')}</div>
        <div className={css.cardDesc}>{t('settings.desc')}</div>
      </div>
      {FIELDS.map((field) => (
        <label key={field.key} className={css.row}>
          <input
            type="checkbox"
            checked={value?.[field.key] ?? false}
            disabled={!ready || !writable}
            onChange={(event) => {
              void scope.set(field.key, event.target.checked).then(() => refreshHost())
            }}
          />
          <span className={css.rowLabel}>{t(field.label)}</span>
          {field.hint !== undefined && <span className={css.rowHint}>{t(field.hint)}</span>}
        </label>
      ))}
      {!ready && <div className={css.rowHint}>{t('settings.unavailable')}</div>}
      {ready && !writable && <div className={css.rowHint}>{t('settings.readonly')}</div>}
      {host !== null && (
        <div className={css.detect}>
          <div className={css.detectTitle}>{t('settings.detected')}</div>
          <div className={css.detectRow}>
            {t('settings.profile')}：{host.profile.name} <span className={css.path}>{host.profile.dir}</span>
          </div>
          <div className={css.detectRow}>
            {t('settings.pnpm')}：{host.pnpm.available ? t('settings.pnpm.ok') : t('settings.pnpm.missing')}
          </div>
          <div className={css.detectRow}>
            {t('settings.restart')}：<span className={css.path}>{host.restart.command}</span>
          </div>
        </div>
      )}
    </div>
  )
}
