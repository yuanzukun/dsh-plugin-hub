import { describe, expect, it, vi } from 'vitest'
import { createCell } from './store'

describe('createCell', () => {
  it('starts with the initial value', () => {
    const cell = createCell(0)
    expect(cell.get()).toBe(0)
  })

  it('publishes replacements to subscribers', () => {
    const cell = createCell(0)
    const listener = vi.fn()
    cell.subscribe(listener)
    cell.set(1)
    expect(listener).toHaveBeenCalledTimes(1)
    expect(cell.get()).toBe(1)
  })

  it('does not notify when the value is unchanged by identity', () => {
    const cell = createCell({ a: 1 })
    const listener = vi.fn()
    cell.subscribe(listener)
    const same = cell.get()
    cell.set(same)
    expect(listener).not.toHaveBeenCalled()
  })

  it('stops notifying after unsubscribe', () => {
    const cell = createCell(0)
    const listener = vi.fn()
    const dispose = cell.subscribe(listener)
    dispose()
    cell.set(2)
    expect(listener).not.toHaveBeenCalled()
  })
})
