import { describe, expect, it, vi } from 'vitest'
import { createUninstallSource, filterCandidates, matchesUninstallLine, NONE_VALUE, parseUninstallQuery } from './uninstall'

const entries = [
  { name: 'dsh-3d-model-viewer', version: '0.1.1' },
  { name: 'dsh-better-sidebar', version: '2.0.0' },
  { name: 'zeta', version: '1.0.0' },
]

const pick = (value: string | undefined) => ({
  candidate: { name: 'x', value },
  session: { sessionId: 's' },
  position: 'leading' as const,
  via: 'menu' as const,
  span: { start: 0, end: 2, draftRev: 1 },
})

describe('filterCandidates', () => {
  it('returns everything for an empty query', () => {
    expect(filterCandidates(entries, '')).toEqual(entries)
  })

  it('filters by name substring, case-insensitively', () => {
    expect(filterCandidates(entries, 'DSH-BETTER')).toEqual([entries[1]])
    expect(filterCandidates(entries, 'zeta')).toEqual([entries[2]])
  })

  it('returns an empty list when nothing matches', () => {
    expect(filterCandidates(entries, 'nope')).toEqual([])
  })
})

describe('parseUninstallQuery', () => {
  it('shows everything for a bare slash (query empty)', () => {
    expect(parseUninstallQuery('')).toEqual({ ok: true, arg: '' })
  })

  it('shows everything for the exact command name', () => {
    expect(parseUninstallQuery('卸载')).toEqual({ ok: true, arg: '' })
    expect(parseUninstallQuery(' 卸载 ')).toEqual({ ok: true, arg: '' })
  })

  it('strips the command name and filters by the argument', () => {
    expect(parseUninstallQuery('卸载 dsh-better')).toEqual({ ok: true, arg: 'dsh-better' })
    expect(parseUninstallQuery('卸载dsh-better')).toEqual({ ok: true, arg: 'dsh-better' })
  })

  it('hides the group for queries that are not this command', () => {
    expect(parseUninstallQuery('goal')).toEqual({ ok: false })
    expect(parseUninstallQuery('file x')).toEqual({ ok: false })
  })
})

describe('matchesUninstallLine', () => {
  it('matches the bare command', () => {
    expect(matchesUninstallLine('/卸载')).toBe(true)
  })

  it('matches the command with an argument', () => {
    expect(matchesUninstallLine('/卸载 dsh-better-sidebar')).toBe(true)
  })

  it('tolerates surrounding whitespace', () => {
    expect(matchesUninstallLine('  /卸载  ')).toBe(true)
  })

  it('ignores unrelated text', () => {
    expect(matchesUninstallLine('帮我卸载 x')).toBe(false)
    expect(matchesUninstallLine('/卸载')).toBe(true)
    expect(matchesUninstallLine('/卸载前请先看')).toBe(false)
  })
})

describe('createUninstallSource', () => {
  const request = { query: '卸载', position: 'leading' as const, signal: new AbortController().signal }
  const session = { sessionId: 's' }

  it('shows an explanatory row instead of an empty group when nothing is removable', async () => {
    const source = createUninstallSource({
      canRun: () => true,
      list: async () => [],
      onPickPlugin: vi.fn(),
      onBareCommand: vi.fn(),
      emptyLabel: '没有可卸载的插件',
    })
    const candidates = await source.candidates(session, request)
    expect(candidates).toEqual([{ name: '没有可卸载的插件', value: NONE_VALUE }])
  })

  it('keeps an empty group when no explanatory label is configured', async () => {
    const source = createUninstallSource({
      canRun: () => true,
      list: async () => [],
      onPickPlugin: vi.fn(),
      onBareCommand: vi.fn(),
    })
    expect(await source.candidates(session, request)).toEqual([])
  })

  it('picking the explanatory row is handled and shows the guidance notice', () => {
    const onBareCommand = vi.fn()
    const onPickPlugin = vi.fn()
    const source = createUninstallSource({ canRun: () => true, list: async () => [], onPickPlugin, onBareCommand })
    const outcome = source.onPick(pick(NONE_VALUE))
    expect(outcome).toBe('handled')
    expect(onBareCommand).toHaveBeenCalledTimes(1)
    expect(onPickPlugin).not.toHaveBeenCalled()
  })

  it('picking a real plugin still routes to the confirmation popup', () => {
    const onPickPlugin = vi.fn()
    const source = createUninstallSource({
      canRun: () => true,
      list: async () => entries,
      onPickPlugin,
      onBareCommand: vi.fn(),
    })
    const outcome = source.onPick(pick('dsh-3d-model-viewer'))
    expect(outcome).toBe('handled')
    expect(onPickPlugin).toHaveBeenCalledWith('dsh-3d-model-viewer')
  })

  it('returns nothing when the plugin is gated off', async () => {
    const source = createUninstallSource({
      canRun: () => false,
      list: async () => entries,
      onPickPlugin: vi.fn(),
      onBareCommand: vi.fn(),
    })
    expect(await source.candidates(session, request)).toEqual([])
    expect(source.onPick(pick('dsh-3d-model-viewer'))).toBeUndefined()
  })
})
