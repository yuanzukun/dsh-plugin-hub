import { describe, expect, it } from 'vitest'
import { OneKeyService, type Permissions, type ProfileManifest, type ServiceIO } from './service'
import type { Job } from './jobs'

class FakeIO implements ServiceIO {
  profileDir = 'C:\\Users\\me\\.dsh\\profiles\\web'
  profileName = 'web'
  platform: NodeJS.Platform = 'win32'
  restartSnapshot = { execPath: 'node.exe', execArgv: ['--import', 'tsx/esm'], args: ['dsh.js', 'web'], cwd: 'C:\\p', env: {} }
  selfName = 'dsh-plugin-onekey'
  hubName = 'dsh-plugin'
  clipboard = 'dsh plugin add liustack/modlens'
  pnpmExitCode = 0
  pnpmAvailable = true
  pnpmCalls: { args: string[] }[] = []
  pnpmOutput = 'Progress: resolved 1\n'
  manifest: ProfileManifest = {
    dependencies: { 'dsh-plugin': '0.1.1', 'dsh-3d-model-viewer': '0.1.1', 'dsh-plugin-onekey': '0.1.0' },
    dsh: { profile: { bundles: ['@deepseek-ai/dsh-base', 'dsh-plugin'] } },
  }
  bundles: Record<string, boolean> = { 'dsh-plugin': true, 'dsh-3d-model-viewer': true, 'dsh-plugin-onekey': true }
  written: ProfileManifest[] = []
  relaunched = 0
  relaunchCalls: { oldPid: number; snapshot: ServiceIO['restartSnapshot'] }[] = []
  exited = 0
  idCounter = 0

  readClipboard(): string | null { return this.clipboard }
  async runPnpm(args: string[], onOutput: (chunk: string) => void): Promise<number> {
    this.pnpmCalls.push({ args: [...args] })
    onOutput(this.pnpmOutput)
    return this.pnpmExitCode
  }
  readManifest(): ProfileManifest { return structuredClone(this.manifest) }
  writeManifest(manifest: ProfileManifest): void { this.written.push(structuredClone(manifest)) }
  isBundle(name: string): boolean { return this.bundles[name] === true }
  spawnRelauncher(oldPid: number, snapshot: ServiceIO['restartSnapshot']): void {
    this.relaunched += 1
    this.relaunchCalls.push({ oldPid, snapshot })
  }
  exit(): void { this.exited += 1 }
  makeId(): string { this.idCounter += 1; return `job-${this.idCounter}` }
}

const perms = (overrides: Partial<Permissions> = {}): Permissions => ({
  enabled: true,
  allowInstall: true,
  allowUninstall: true,
  allowRestart: true,
  allowClipboard: true,
  ...overrides,
})

const setup = (overrides: Partial<Permissions> = {}) => {
  const io = new FakeIO()
  const service = new OneKeyService(io, () => perms(overrides))
  return { io, service }
}

describe('OneKeyService', () => {
  describe('install', () => {
    it('installs from the clipboard when no text is posted and reconciles the bundle list', async () => {
      const { io, service } = setup()
      const result = await service.install(undefined)
      expect(result.status).toBe(202)
      const jobId = (result.body as { jobId: string }).jobId
      await service.settled(jobId)
      expect(io.pnpmCalls).toEqual([{ args: ['add', 'github:liustack/modlens'] }])
      const job = service.jobState(jobId) as Job
      expect(job.phase).toBe('done')
      expect(job.percent).toBe(100)
      expect(io.written.length).toBeGreaterThan(0)
      expect(io.written[io.written.length - 1]!.dsh!.profile!.bundles).toContain('dsh-plugin-onekey')
    })

    it('prefers the posted text over the clipboard', async () => {
      const { io, service } = setup()
      const result = await service.install('dsh plugin add github:some/repo')
      const jobId = (result.body as { jobId: string }).jobId
      await service.settled(jobId)
      expect(io.pnpmCalls[0]).toEqual({ args: ['add', 'github:some/repo'] })
    })

    it('rejects when the plugin is disabled', async () => {
      const { service } = setup({ enabled: false })
      const result = await service.install('dsh plugin add x')
      expect(result.status).toBe(403)
    })

    it('rejects install when the permission is off', async () => {
      const { service } = setup({ allowInstall: false })
      const result = await service.install('dsh plugin add x')
      expect(result.status).toBe(403)
    })

    it('rejects clipboard use when the permission is off and no text is posted', async () => {
      const { service } = setup({ allowClipboard: false })
      const result = await service.install(undefined)
      expect(result.status).toBe(403)
    })

    it('rejects an empty clipboard', async () => {
      const { io, service } = setup()
      io.clipboard = ''
      const result = await service.install(undefined)
      expect(result.status).toBe(400)
    })

    it('rejects a payload that is not an install command', async () => {
      const { io, service } = setup()
      io.clipboard = 'rm -rf /'
      const result = await service.install(undefined)
      expect(result.status).toBe(400)
    })

    it('fails the job with the pnpm output when pnpm exits non-zero', async () => {
      const { io, service } = setup()
      io.pnpmExitCode = 1
      io.pnpmOutput = 'ERR_PNPM_FETCH_404 not found'
      const result = await service.install(undefined)
      const jobId = (result.body as { jobId: string }).jobId
      await service.settled(jobId)
      const job = service.jobState(jobId) as Job
      expect(job.phase).toBe('failed')
      expect(job.error).toContain('ERR_PNPM_FETCH_404')
    })
  })

  describe('uninstall', () => {
    it('uninstalls a removable plugin, reconciles, then relaunches and exits', async () => {
      const { io, service } = setup()
      const result = await service.uninstall('dsh-3d-model-viewer')
      expect(result.status).toBe(202)
      const jobId = (result.body as { jobId: string }).jobId
      await service.settled(jobId)
      expect(io.pnpmCalls).toEqual([{ args: ['remove', 'dsh-3d-model-viewer'] }])
      expect(io.relaunched).toBe(1)
      expect(io.exited).toBe(1)
    })

    it('uninstall relaunches with the captured snapshot including the execArgv loader flags', async () => {
      const { io, service } = setup()
      const result = await service.uninstall('dsh-3d-model-viewer')
      const jobId = (result.body as { jobId: string }).jobId
      await service.settled(jobId)
      expect(io.relaunchCalls).toHaveLength(1)
      expect(io.relaunchCalls[0]!.snapshot.execArgv).toEqual(['--import', 'tsx/esm'])
      expect(io.relaunchCalls[0]!.snapshot.args).toEqual(['dsh.js', 'web'])
    })

    it('does not restart when pnpm remove fails', async () => {
      const { io, service } = setup()
      io.pnpmExitCode = 1
      const result = await service.uninstall('dsh-3d-model-viewer')
      const jobId = (result.body as { jobId: string }).jobId
      await service.settled(jobId)
      expect(io.relaunched).toBe(0)
      expect(io.exited).toBe(0)
      expect(service.jobState(jobId)!.phase).toBe('failed')
    })

    it('refuses to uninstall a name that is not in the removable list', async () => {
      const { io, service } = setup()
      const result = await service.uninstall('dsh-plugin')
      expect(result.status).toBe(400)
      expect(io.pnpmCalls.length).toBe(0)
    })

    it('uninstalls a user plugin even when it sits in the bundles layer', async () => {
      const { io, service } = setup()
      io.manifest = {
        dependencies: {
          'dsh-plugin': '0.1.1',
          'dsh-3d-model-viewer': '0.1.1',
          'dsh-plugin-onekey': '0.1.0',
        },
        dsh: {
          profile: {
            bundles: [
              '@deepseek-ai/dsh-base',
              '@deepseek-ai/dsh-web-app',
              'dsh-plugin',
              'dsh-3d-model-viewer',
              'dsh-plugin-onekey',
            ],
          },
        },
      }
      const result = await service.uninstall('dsh-3d-model-viewer')
      expect(result.status).toBe(202)
      expect(io.pnpmCalls).toEqual([{ args: ['remove', 'dsh-3d-model-viewer'] }])
    })

    it('refuses arbitrary names that never came from the manifest', async () => {
      const { io, service } = setup()
      const result = await service.uninstall('../../etc/passwd')
      expect(result.status).toBe(400)
      expect(io.pnpmCalls.length).toBe(0)
    })

    it('rejects when disabled or the permission is off', async () => {
      const { service } = setup({ enabled: false })
      expect((await service.uninstall('dsh-3d-model-viewer')).status).toBe(403)
      const { service: service2 } = setup({ allowUninstall: false })
      expect((await service2.uninstall('dsh-3d-model-viewer')).status).toBe(403)
    })
  })

  describe('restart', () => {
    it('relaunches and exits when permitted', async () => {
      const { io, service } = setup()
      const result = await service.restart()
      expect(result.status).toBe(200)
      expect(io.relaunched).toBe(1)
      expect(io.exited).toBe(1)
    })

    it('rejects when disabled or the permission is off', async () => {
      const { service } = setup({ enabled: false })
      expect((await service.restart()).status).toBe(403)
      const { service: service2 } = setup({ allowRestart: false })
      expect((await service2.restart()).status).toBe(403)
    })
  })

  describe('removable', () => {
    it('lists dependencies minus self and hub', async () => {
      const { service } = setup()
      const result = await service.removable()
      expect(result.status).toBe(200)
      expect(result.body).toEqual([{ name: 'dsh-3d-model-viewer', version: '0.1.1' }])
    })

    it('still lists user plugins that appear in the bundles layer (real profiles)', async () => {
      const { io, service } = setup()
      io.manifest = {
        dependencies: {
          'dsh-plugin': '0.1.1',
          'dsh-3d-model-viewer': '0.1.1',
          'dsh-plugin-onekey': '0.1.0',
        },
        dsh: {
          profile: {
            bundles: [
              '@deepseek-ai/dsh-base',
              '@deepseek-ai/dsh-web-app',
              'dsh-plugin',
              'dsh-3d-model-viewer',
              'dsh-plugin-onekey',
            ],
          },
        },
      }
      const result = await service.removable()
      expect(result.status).toBe(200)
      expect(result.body).toEqual([{ name: 'dsh-3d-model-viewer', version: '0.1.1' }])
    })

    it('still protects in-box template bundles that are not dependencies', async () => {
      const { io, service } = setup()
      io.manifest = {
        dependencies: { 'dsh-3d-model-viewer': '0.1.1' },
        dsh: { profile: { bundles: ['@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app', 'dsh-3d-model-viewer'] } },
      }
      const result = await service.removable()
      expect(result.body).toEqual([{ name: 'dsh-3d-model-viewer', version: '0.1.1' }])
    })

    it('returns an empty list when disabled', async () => {
      const { service } = setup({ enabled: false })
      const result = await service.removable()
      expect(result.body).toEqual([])
    })
  })

  describe('state', () => {
    it('reports permissions and detected environment', async () => {
      const { io, service } = setup({ allowRestart: false })
      const result = await service.state()
      expect(result.status).toBe(200)
      expect(result.body).toMatchObject({
        enabled: true,
        permissions: { enabled: true, allowInstall: true, allowUninstall: true, allowRestart: false, allowClipboard: true },
        profile: { name: 'web', dir: io.profileDir },
      })
    })
  })

  describe('jobs', () => {
    it('returns 404 for an unknown job id', async () => {
      const { service } = setup()
      expect(await service.job('nope')).toEqual({ status: 404, body: { error: 'not-found' } })
    })
  })
})
