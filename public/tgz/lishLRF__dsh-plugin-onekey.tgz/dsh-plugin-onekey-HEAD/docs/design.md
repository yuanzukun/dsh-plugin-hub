# dsh-plugin-onekey 设计文档

> 「真正一键安装/卸载」—— DeepSeek Harness 插件中心补完计划。
> 状态：已获用户确认（触发方式=运行时拦截；重启=程序自动重启；启用开关=配置级网关）。

## 1. 目标与范围

在 DSH Web 设置 → 插件中心里，把"复制安装命令"升级为**真正的一键安装**；在会话输入框里，用 `/卸载` 斜杠命令**真正一键卸载**任意用户自装插件。全程代码实现、不调用 LLM、不改动 DSH 与其他插件的源码；所有能力随插件启用/禁用而增减。

- 包名：`dsh-plugin-onekey`（npm / GitHub 同名仓库，topic `dsh-plugin`）
- 宿主半侧 + 客户端半侧单包结构，参照 `dsh-3d-model-viewer`
- 平台要求：DSH web profile（当前支持 Windows / macOS / Linux 的剪贴板读取）

## 2. 需求映射

| # | 需求 | 实现 |
|---|------|------|
| 1 | 点击"复制安装命令"→ 确认弹窗 → 进度条 → 后端执行 | 客户端运行时拦截（包裹 `navigator.clipboard.writeText` + document `copy` 捕获）作信号；后端读系统剪贴板解析执行；进度条轮询 `/plugins/onekey/jobs/:id` |
| 2 | 失败红条 + 复制到工作区询问LLM / 关闭 | 失败状态渲染错误详情；"复制到工作区询问LLM"通过 `conversation.input.overlay` 插槽拿 `inputActions.setDraft` 写入预置中文提示词 + 错误 |
| 3 | 成功 → 立即重启后端 / 暂不重启 | 成功视图两个按钮；立即重启 = 后端 detached 重启动器 + 老进程退出 + 前端轮询 `ping` 恢复后 `location.reload()` |
| 4 | `/卸载` 斜杠命令 → 选项框 → 确认 → 卸载 → 自动重启 | `inputTriggers.registerSource` 注册 `/` 触发源；候选 = profile `dependencies`（排除自身、插件中心、DSH 内置包）；`onPick` 返回 `'handled'`（不走 LLM）；卸载成功后自动重启，弹窗切"正在重启请稍后"直至恢复 |
| 5 | 安全防护、权限提醒 | 严格白名单解析、参数数组 spawn（无 shell）、每次操作先过权限配置 + 确认弹窗展示将执行的命令 |
| 6 | 设置 → 插件 → 插件配置：启用 + 权限勾选 | 注册 settings 命名空间 `dsh-plugin-onekey`；`settings.plugin.item` 卡片（key=命名空间）提供 5 个开关 |
| 7 | 首次部署自动探测 DSH 位置与配置路径 | profile 目录 = `ctx.baseUrl`；pnpm 走 PATH/corepack 探测；重启命令 = 记录 `process.execPath + argv.slice(1) + cwd + env`（适配官网所有安装方式） |
| 8 | 能力随启用/禁用增减，不改他人代码 | 全部通过公开扩展点；禁用 = 配置级网关（斜杠候选、弹窗、后端路由全部失效） |
| 9 | git/文档规范 + 红绿测试 | vitest TDD（先红后绿）；conventional commits；README 功能清单 |

## 3. 架构

### 3.1 宿主半侧（Node）

```
src/
  index.ts      # 插件入口：inject ['webServer']，settings 命名空间注册，路由挂载
  config.ts     # Config（schemastery schema）+ 权限网关状态
  detect.ts     # profileDir（ctx.baseUrl）、pnpm 探测、重启命令快照
  parse.ts      # parseInstallCommand：严格白名单解析（纯函数）
  clipboard.ts  # 按平台读系统剪贴板（Get-Clipboard / pbpaste / xclip，带超时）
  reconcile.ts  # bundles reconcile（复刻 CLI 语义，纯函数）
  restart.ts    # 重启动器脚本生成 + detached spawn（纯函数 + 副作用壳）
  jobs.ts       # 安装任务状态机（纯 reducer + 内存注册表）
  removable.ts  # 可卸载列表（纯函数）
  routes.ts     # HTTP 路由处理器
```

- 路由（`ctx.webServer.register({kind:'prefix', path:'/plugins/onekey', handler})`）：
  - `GET /ping` — 存活探针（重启轮询用）
  - `GET /state` — 探测结果 + 权限 + 运行中任务
  - `GET /removable` — 可卸载插件列表
  - `POST /install` `{text?}` — 后端读剪贴板（或 fallback 用 text）→ 解析 → 权限检查 → pnpm 执行 → reconcile
  - `POST /uninstall` `{name}` — 校验 name ∈ removable → pnpm remove → reconcile → 自动重启
  - `POST /restart` — 权限检查 → 重启动器 spawn → 老进程退出
  - `GET /jobs/:id` — 任务进度轮询
- 全部路由先过权限网关：`enabled=false` → 403；各操作再查对应 `allowX` 权限。

### 3.2 命令解析白名单（安全核心）

只接受形如 `dsh plugin [--profile X] add <spec>` 的剪贴板内容；`<spec>` 白名单：

- npm 包名（含 scope、可选 `@version`）
- **裸 `owner/repo`（映射为 `github:owner/repo`，插件中心复制的就是这种格式）**
- `github:owner/repo[#ref]`
- `git+https://…`、`https://…`

拒绝：`file:`/`link:`、相对或绝对路径、任何 shell 元字符（`; & | \` $ ( ) < > " '` 等）、换行、超长输入。pnpm 以参数数组 spawn，不经 shell。

### 3.3 重启机制

1. 宿主 `apply` 时记录快照 `{ execPath, args: argv.slice(1), cwd, env }`；
2. `POST /restart`（或卸载完成后）→ 生成重启动器脚本（字符串，node -e 执行）→ `spawn(execPath, ['-e', script, oldPid, JSON.stringify(snapshot)], {detached, stdio:'ignore'}).unref()`；
3. 响应请求后 `setTimeout(() => process.exit(0), 500)`；
4. 重启动器轮询 `process.kill(oldPid, 0)` 直到老进程退出（上限 30s）→ 按快照原样 spawn 新进程 → 退出；
5. 前端进入"正在重启请稍后"，每 2s 探测 `/plugins/onekey/ping`，200 后 `location.reload()`；120s 超时给出手动刷新按钮。

### 3.4 客户端半侧（浏览器）

```
src/client/
  index.tsx      # apply：locale 注册、状态中心、拦截器安装、各插槽注册
  dsh.ts         # 本地结构类型（不 import @deepseek-ai 运行时值，同 3D 插件）
  api.ts         # fetch 封装（state/install/uninstall/restart/jobs/ping）
  state.ts       # 弹窗/进度/重启状态机（纯 reducer，可测试）
  trigger.ts     # writeText 包裹 + copy 事件捕获（信号 + 文本 fallback，可测试）
  prompt.ts      # “复制到工作区询问LLM”提示词模板（纯函数，可测试）
  Overlay.tsx    # shell.overlay 全局弹窗入口（portal）
  Modal.tsx      # 确认/进度/错误/成功/重启中五种视图
  SettingsCard.tsx  # settings.plugin.item 卡片（启用 + 权限 + 探测信息）
  InputBridge.tsx  # conversation.input.overlay 入口（持有当前会话 inputActions）
  locales.ts     # zh/en 文案
  styles.module.css
```

- 拦截器安装于 `apply`，卸载（dispose）时恢复原状 —— 能力随插件生命周期走。
- 弹窗状态机（纯 reducer）：
  `idle → confirm → running → success | failed → (success) restarting | closed`
  动作：SHOW_CONFIRM / CONFIRM_START / PROGRESS / SUCCESS / FAIL / START_RESTART / RESTART_TICK / RESTART_TIMEOUT / CLOSE / ASK_LLM。
- 卸载流复用同一状态机：确认（显示将被卸载的插件名与命令）→ running → success → 自动 restarting → 刷新。

### 3.5 斜杠命令

- `ctx.inputTriggers.registerSource({ trigger: '/', name: '卸载', candidates, onPick, matchEnter })`，用 `ctx.effect` 包裹；
- `candidates(session, {query})` → `GET /removable` 缓存 + 过滤；禁用时返回空；
- `onPick` → 返回 `'handled'`（**完全不进入 LLM 管线**），打开确认弹窗；
- `matchEnter`：整行以 `/卸载` 开头且未被 pick 时返回 `'handled'` 并提示"请从候选列表选择要卸载的插件"，防止把 `/卸载` 文本发给模型。

### 3.6 设置卡与权限

schemastery 配置：

```
enabled: boolean = true          # 总开关（配置级网关）
allowInstall: boolean = true     # 允许一键安装
allowUninstall: boolean = true   # 允许卸载插件
allowRestart: boolean = true     # 允许自动重启后端
allowClipboard: boolean = true   # 允许读取剪贴板
```

宿主侧注册 settings 命名空间（复刻 `installSettingsSection` 的少量逻辑，避免依赖 rc 包），`watch` 变更即更新权限状态；客户端卡片经 `ctx.settingsScope` 读写；卡片同时展示探测信息（profile 目录、pnpm、重启命令）。

### 3.7 “复制到工作区询问LLM”提示词模板（草案）

```
【DSH 插件一键安装失败，请帮我诊断修复】
我在 DeepSeek Harness 插件中心安装插件时，后端自动安装报错。请阅读下面的环境与错误信息，先解释失败原因，再给出分步修复方案（含可直接执行的命令）。
- profile：{profileName}
- 安装命令：{command}
- 错误输出：
{error}
要求：1) 用中文回答；2) 涉及 pnpm 时说明版本与 allowBuilds 配置；3) 修复步骤给出可复制粘贴的命令。
```

写入方式：当前会话的 `inputActions.setDraft(文本)`；无会话时回退 `navigator.clipboard.writeText` 并提示。

## 4. 数据流

### 安装流
```
用户点插件中心“复制” → writeText 包裹/copy 事件捕获（信号，含文本）
  → 客户端校验 /state（enabled && allowInstall && allowClipboard，否则静默不打扰）
  → SHOW_CONFIRM 弹窗（展示解析出的 spec 与将要执行的命令 + 权限提醒）
  → 用户确认 → POST /install → 后端读剪贴板 → 解析 → 权限复核
  → 创建 job（parsing 5% → validate 15% → pnpm 30–80% → reconcile 90% → done 100%）
  → 客户端轮询 jobs/:id 渲染进度条（绿色）
  → 失败：进度条变红 + 错误详情 + [复制到工作区询问LLM] [关闭]
  → 成功：成功文案 + [立即重启后端] [暂不重启，关闭弹窗]
  → 立即重启：POST /restart → restarting 状态 → 轮询 ping → reload
```

### 卸载流
```
输入框输入 /卸载 → 菜单显示可卸载插件（来自 /removable，随输入过滤）
  → 选中 → onPick 'handled' → 确认弹窗（"是否卸载 xx 插件" + 权限提醒）
  → 确认 → POST /uninstall → pnpm remove + reconcile → 自动重启后端
  → 弹窗切“正在重启请稍后”（持续轮询 ping）→ 新后端就绪 → 自动刷新前端
```

## 5. 安全模型

1. **命令白名单**：见 3.2，正则 + 字符级拒绝双保险；
2. **无 shell spawn**：pnpm/重启动器全部参数数组；
3. **权限网关**：每次操作前后双重检查配置权限；
4. **确认弹窗**：执行前展示将执行的命令与涉及对象；
5. **仅自己声明能力的资源**：路由前缀 `/plugins/onekey`、settings 命名空间 `dsh-plugin-onekey`、插槽 id `onekey-*`，全部随 fiber 卸载；
6. **拦截器可逆**：禁用/卸载后剪贴板行为恢复原状。

## 6. 测试策略（TDD 红绿）

宿主纯逻辑（vitest，先红后绿）：
- `parse.spec.ts` — 接受/拒绝矩阵（裸 owner/repo、github:、npm 名、file: 拒绝、元字符拒绝…）
- `reconcile.spec.ts` — add/remove/无 bundle 声明/模板包不动
- `removable.spec.ts` — 排除自身与插件中心、内置包不进列表
- `restart.spec.ts` — 脚本字符串生成（含 PID 轮询、超时、argv 序列化）
- `clipboard.spec.ts` — 平台命令构造
- `jobs.spec.ts` — 阶段推进、错误落定
- `routes.spec.ts` — 权限网关 403 / 禁用 / 未解析命令拒绝（用内存假 webServer）

客户端纯逻辑：
- `state.spec.ts` — 弹窗状态机全部转移与非法转移
- `prompt.spec.ts` — 模板渲染（含错误转义）
- `trigger.spec.ts` — 拦截/恢复/去抖/文本提取

构建：tsdown 双产物（host esm + client CJS 工厂 banner），CSS Modules 内联插件（同 3D 插件）。

## 7. 实施计划

1. 脚手架：package.json / tsconfig×2 / tsdown.config / vitest.config / cordis.patch.yml / .gitignore / LICENSE / git init
2. 宿主纯逻辑 TDD（parse → reconcile → removable → restart → jobs → clipboard）
3. 宿主服务（routes/detect/settings 注册）＋ 宿主集成测试
4. 客户端纯逻辑 TDD（state → prompt → trigger）
5. 客户端 UI（Overlay/Modal/SettingsCard/InputBridge/斜杠源）
6. README（功能清单）/ docs / GitHub Actions CI
7. 构建产物 + 安装/验证指引（最终重启需用户手动执行，见下）

## 8. 验证限制（重要）

本插件的开发会话运行在**当前 dsh web 后端进程内**：

- 插件装入 profile 后，宿主/客户端半侧均需**重启后端**才生效；
- 插件自身的"立即重启后端"会终止当前后端（含本开发会话）；
- 因此：单测 + 构建 + 类型检查在本会话内完成闭环；最终"装入 profile + 重启验证"由用户在结束前手动执行一次（文档给出精确步骤：`dsh plugin --profile web add link:<本目录>` → 重启 `dsh web` → 打开 设置 → 插件 → 插件配置 验证开关与权限卡）。
