
// src/client/index.ts
var index_exports = {};
__export(index_exports, {
  PackerSettingsPage: () => PackerSettingsPage,
  apply: () => apply,
  inject: () => inject
});
module.exports = __toCommonJS(index_exports);
