#!/usr/bin/env bash
# Mini attach e2e: dsh --profile oc --mini boots the real opencode TUI in
# minimal mode, renders a recognizable prompt and exits with either a graceful
# status or the expected SIGINT status after triple C-c.
set -euo pipefail
cd "$(dirname "$0")/.."
source tests/e2e/common.sh

SCRIPT_START=$SECONDS
cleanup() {
  local code=$?
  tmux kill-session -t "$E2E_TUI_SESSION" 2>/dev/null || true
  if [[ -n "$E2E_RUNID" ]]; then
    node "$E2E_ENV_JS" stop "$E2E_RUNID" >/dev/null 2>&1 || true
  fi
  exit "$code"
}
trap cleanup EXIT

export DSH_OC_E2E_CHUNK_DELAY_MS=40
export DSH_OC_E2E_CHUNK_SIZE=4
e2e_new_run "tui-mini" "danger-full-access" "success" "1"

echo "== boot real opencode attach with --mini =="
e2e_tui_start "--mini"
e2e_tui_wait_attach

MINI_HINT=""
deadline=$((SECONDS + 45))
while (( SECONDS < deadline )); do
  e2e_tui_capture "$E2E_RUN_DIR/tui-mini.txt"
  # The DSH OC brand (printed before --mini) contains "OpenCode" in its
  # subtitle; only "Ask anything" proves the mini interface is ready for
  # keyboard input.
  for pattern in "Ask anything" "1.18.18" "DSH OC"; do
    if grep -qa "$pattern" "$E2E_RUN_DIR/tui-mini.txt"; then
      MINI_HINT="$pattern"
      break 2
    fi
  done
  if [[ -s "$E2E_RUN_DIR/dsh-exit.txt" ]]; then
    echo "e2e: dsh exited while waiting for mini TUI: $(cat "$E2E_RUN_DIR/dsh-exit.txt")" >&2
    tmux capture-pane -p -S -200 -t "$E2E_TUI_SESSION" >&2 2>/dev/null || true
    exit 1
  fi
  sleep 1
done
if [[ -z "$MINI_HINT" ]]; then
  echo "e2e: no recognizable mini TUI text in pane" >&2
  tail -60 "$E2E_RUN_DIR/tui-mini.txt" >&2 || true
  exit 1
fi
echo "  mini TUI visible hint: \"$MINI_HINT\""

echo "== type a prompt and verify a model reply =="
tmux send-keys -t "$E2E_TUI_SESSION" "mini reply test" Enter

REPLY_HINT=""
deadline=$((SECONDS + 60))
while (( SECONDS < deadline )); do
  for sid in $(curl -s "$E2E_BRIDGE_URL/session" | jq -r '.[].id'); do
    local_text="$(curl -s "$E2E_BRIDGE_URL/session/$sid/message" | jq -r '[.. | objects | select(has("text")) | .text] | join(" ")' 2>/dev/null || true)"
    if [[ "$local_text" == *"mini reply test"* && "$local_text" == *"mock response recovered"* ]]; then
      REPLY_HINT="mini reply + mock response"
      break 2
    fi
  done
  if [[ -s "$E2E_RUN_DIR/dsh-exit.txt" ]]; then
    echo "e2e: dsh exited while waiting for mini reply: $(cat "$E2E_RUN_DIR/dsh-exit.txt")" >&2
    tmux capture-pane -p -S -200 -t "$E2E_TUI_SESSION" >&2 2>/dev/null || true
    exit 1
  fi
  sleep 1
done
if [[ -z "$REPLY_HINT" ]]; then
  echo "e2e: --mini did not produce a model reply" >&2
  exit 1
fi
echo "  mini model reply visible: $REPLY_HINT"

e2e_tui_capture "$E2E_RUN_DIR/tui-mini-reply.txt"
REPLY_COUNT="$(grep -o 'mock response recovered' "$E2E_RUN_DIR/tui-mini-reply.txt" | wc -l)"
if [[ "$REPLY_COUNT" != "1" ]]; then
  echo "e2e: --mini rendered the reply $REPLY_COUNT times (expected 1)" >&2
  exit 1
fi
echo "  mini reply rendered once ($REPLY_COUNT)"

echo "== exit the mini TUI and verify the dsh-oc exit note =="
tmux send-keys -t "$E2E_TUI_SESSION" C-c
sleep 1
tmux send-keys -t "$E2E_TUI_SESSION" C-c
sleep 1
tmux send-keys -t "$E2E_TUI_SESSION" C-c
deadline=$((SECONDS + 20))
while (( SECONDS < deadline )); do
  if [[ -s "$E2E_RUN_DIR/dsh-exit.txt" ]]; then break; fi
  sleep 1
done
if [[ ! -s "$E2E_RUN_DIR/dsh-exit.txt" ]]; then
  echo "e2e: mini TUI did not exit after triple C-c" >&2
  e2e_tui_capture "$E2E_RUN_DIR/tui-mini-stuck.txt"
  exit 1
fi
if ! grep -Eq '^DSH_EXIT=(0|130)$' "$E2E_RUN_DIR/dsh-exit.txt"; then
  echo "e2e: unexpected mini exit status: $(cat "$E2E_RUN_DIR/dsh-exit.txt")" >&2
  exit 1
fi
sleep 1
e2e_tui_capture "$E2E_RUN_DIR/tui-mini-exit.txt"
tmux capture-pane -p -S -300 -t "$E2E_TUI_SESSION" > "$E2E_RUN_DIR/tui-mini-exit-scrollback.txt" 2>/dev/null || true
if ! grep -qa '\[dsh-oc\] 上面是 opencode 的退出提示' "$E2E_RUN_DIR/tui-mini-exit.txt" \
  && ! grep -qa '\[dsh-oc\] 上面是 opencode 的退出提示' "$E2E_RUN_DIR/tui-mini-exit-scrollback.txt"; then
  echo "e2e: mini exit note missing after graceful exit" >&2
  tail -40 "$E2E_RUN_DIR/tui-mini-exit.txt" >&2 || true
  exit 1
fi
echo "  mini exit note visible"

e2e_stop_dsh "$E2E_TUI_SESSION"
node "$E2E_ENV_JS" stop "$E2E_RUNID" >/dev/null

echo "e2e-tui-mini: PASSED in $((SECONDS - SCRIPT_START))s"
