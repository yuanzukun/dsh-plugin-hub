#!/usr/bin/env bash
# Release artifact audit (rc.2 gate, round-0002 recommendation):
#  1. rebuild lib/ from the committed sources in a pristine archive and
#     require zero diff against the committed lib/;
#  2. pack the npm tarball and scan it for machine absolute paths;
#  3. record package version, tarball sha256 and a package-tree hash so a
#     release commit can be referenced immutably.
set -euo pipefail
cd "$(dirname "$0")/.."

REPO_ROOT="$(pwd)"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/dsh-oc-artifacts.XXXXXX")"
cleanup() {
  rm -rf "$TMP"
}
trap cleanup EXIT

echo "== release artifact audit (HEAD=$(git rev-parse HEAD)) =="
mkdir -p "$TMP/pristine" "$TMP/build" "$TMP/unpack" "$TMP/pack"

git archive --format=tar HEAD | tar -x -C "$TMP/pristine"
git archive --format=tar HEAD | tar -x -C "$TMP/build"
# Reuse the current install so the audit does not re-resolve dependencies;
# the archive's own node_modules is excluded from the tarball by `files`.
ln -s "$REPO_ROOT/node_modules" "$TMP/build/node_modules"

echo "-- clean rebuild --"
# Invoke the workspace's own tsdown binary directly: `pnpm build` runs pnpm's
# verify-deps-before-run check, which sees the symlinked node_modules metadata
# as a foreign workspace and prompts to reinstall. The build still uses the
# committed config and committed sources.
(cd "$TMP/build" && ./node_modules/.bin/tsdown >/dev/null)
# tsdown emits `//#region <path>` comments in .d.ts files; the temp build
# resolves node_modules through an absolute symlink while the committed lib
# uses repo-relative paths. Normalize the region prefix before diffing.
for side in pristine build; do
  while IFS= read -r -d '' file; do
    sed -i -E 's|(//#region )[^ ]*node_modules/|\1node_modules/|' "$file"
  done < <(find "$TMP/$side/lib" -name '*.d.ts' -print0)
done
if ! diff -r "$TMP/pristine/lib" "$TMP/build/lib" > "$TMP/lib.diff" 2>&1; then
  echo "FAIL: committed lib/ differs from a clean rebuild of HEAD src" >&2
  sed -n '1,80p' "$TMP/lib.diff" >&2
  exit 1
fi
echo "  committed lib/ matches clean rebuild (zero diff)"

VERSION="$(node -p "require('$TMP/build/package.json').version")"
echo "  package version: $VERSION"

echo "-- pack audit --"
(cd "$TMP/build" && pnpm pack --pack-destination "$TMP/pack" >/dev/null)
TARBALL="$(ls "$TMP/pack"/*.tgz | head -1)"
tar -xzf "$TARBALL" -C "$TMP/unpack"

if [[ -d "$TMP/unpack/package/src" ]]; then
  echo "FAIL: packed tarball contains src/ (source leak)" >&2
  exit 1
fi
for required in \
  package/bin/dsh-oc.mjs \
  package/lib/index.js \
  package/lib/bridge/router-entry.js \
  package/opencode-version.json \
  package/cordis.patch.yml; do
  if [[ ! -f "$TMP/unpack/$required" ]]; then
    echo "FAIL: packed tarball missing $required" >&2
    exit 1
  fi
done
echo "  packed tarball contains required files and no src/"

set +e
bash "$REPO_ROOT/scripts/scan-release-artifact-paths.sh" \
  "$TMP/unpack" "$TMP/paths.txt"
PATH_SCAN_RC=$?
set -e
case "$PATH_SCAN_RC" in
  0)
    echo "  packed tarball free of machine absolute paths"
    ;;
  1)
    echo "FAIL: packed artifacts contain machine absolute paths" >&2
    sed -n '1,40p' "$TMP/paths.txt" >&2
    exit 1
    ;;
  *)
    echo "FAIL: machine-path scanner failed (rc=$PATH_SCAN_RC)" >&2
    exit 2
    ;;
esac

TARBALL_HASH="$(sha256sum "$TARBALL" | awk '{print $1}')"
TREE_HASH="$(cd "$TMP/unpack" && find . -type f | sort | xargs sha256sum | sha256sum | awk '{print $1}')"
echo "  tarball: $TARBALL_HASH"
echo "  package tree: $TREE_HASH"

echo "verify-release-artifacts: PASSED"
