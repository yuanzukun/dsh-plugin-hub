export * from './types.js'

/** dsh-oc bundle version (keep in sync with package.json). */
export const DSH_OC_VERSION = '0.2.0-rc.4'

export const OPENCODE_VERSION = '1.18.18'
export const OPENCODE_COMMIT = '4643e65'
