import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const PLUGIN_VERSION = require('./package.json').version

const ID = '@bananasoldier01/dsh-tidychat'
// 客户端 bundle 允许 external 的宿主模块（由 loader 的 require 提供）。
const EXTERNALS = ['react', 'react/jsx-runtime']

const libConfig = {
  name: ID,
  entry: ['src/index.ts'],
  outDir: 'lib',
  format: ['esm'],
  platform: 'node',
  fixedExtension: false,
  dts: false,
  clean: false,
  deps: {
    neverBundle: ['@deepseek-ai/dsh-settings', '@deepseek-ai/schemastery'],
  },
}

const clientConfig = {
  name: `${ID}/client`,
  entry: { client: 'src/client/index.ts' },
  outDir: 'lib',
  format: 'cjs',
  platform: 'browser',
  dts: false,
  minify: false,
  sourcemap: false,
  clean: false,
  deps: {
    neverBundle: [...EXTERNALS],
    alwaysBundle: (id) => !EXTERNALS.includes(id),
  },
  outputOptions: {
    entryFileNames: 'client.js',
    banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify(ID)}, factory: (require) => {`,
    footer: 'return module.exports; } });',
    intro: 'var module = { exports: {} }; var exports = module.exports;',
  },
  define: {
    __PLUGIN_VERSION__: JSON.stringify(PLUGIN_VERSION),
  },
}

export default [libConfig, clientConfig]
