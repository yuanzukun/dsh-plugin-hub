/**
 * AgentSoul for DeepSeek Harness — core + adapter wiring tests (node:test).
 *
 * Core engines are host-agnostic and tested directly. The apply() suite
 * drives the adapter with a mock cordis context to verify section orders,
 * runtime-context registration, capture filtering, and tool registration
 * without booting a real harness.
 */

import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { resolveConfig, DEFAULT_CONTEXT_MAX_CHARS, DEFAULT_RECENT_LIMIT, DEFAULT_MAX_CHARS_PER_MEMORY, DEFAULT_DISTILL_THRESHOLD } from '../lib/config.js'
import { createPersonalityEngine } from '../lib/personality.js'
import { createMemoryEngine } from '../lib/memory.js'
import { createContextBuilder, CONTEXT_OPEN, CONTEXT_CLOSE, STATE_OPEN, STATE_CLOSE, MEMORY_OPEN, MEMORY_CLOSE, MEMORY_WARNING, textOfContent } from '../lib/context.js'
import { createDistillationEngine, parseDistillationResult, buildUserPrompt } from '../lib/distill.js'
import { apply, createHttpModelCaller, createModelCaller } from '../lib/index.js'

const silentLogger = { debug() {}, info() {}, warn() {}, error() {} }

function tempDir(label) {
  return mkdtempSync(join(tmpdir(), 'agentsoul-dsh-' + label + '-'))
}

function engineFor(dir, config) {
  const resolved = resolveConfig({ ...(config ?? {}), path: dir })
  return { dir, resolved, personality: createPersonalityEngine({ config: resolved, logger: silentLogger }), memory: createMemoryEngine({ config: resolved, logger: silentLogger }) }
}

// ─────────────────────────────── config ─────────────────────────────────────

test('resolveConfig fills every default', () => {
  const c = resolveConfig({})
  assert.equal(c.enabled, true)
  assert.equal(c.path, undefined)
  assert.deepEqual(c.personality, { enabled: true, soul: true, identity: true, user: true, state: true })
  assert.equal(c.memory.backend, 'sqlite')
  assert.equal(c.memory.recentLimit, DEFAULT_RECENT_LIMIT)
  assert.equal(c.memory.maxCharsPerMemory, DEFAULT_MAX_CHARS_PER_MEMORY)
  assert.equal(c.memory.excludeCurrentSession, true)
  assert.equal(c.context.maxChars, DEFAULT_CONTEXT_MAX_CHARS)
  assert.equal(c.debug, false)
})

test('resolveConfig clamps out-of-range limits', () => {
  const c = resolveConfig({ memory: { recentLimit: 99999 }, context: { maxChars: 1 } })
  assert.equal(c.memory.recentLimit, 100)
  assert.equal(c.context.maxChars, 1000)
})

// ─────────────────────────────── personality ────────────────────────────────

test('personality: missing files load as null, present files load as text', () => {
  const dir = tempDir('personality-1')
  const engine = createPersonalityEngine({ config: resolveConfig({ path: dir }), logger: silentLogger })
  assert.equal(engine.load('SOUL.md'), null)
  writeFileSync(join(dir, 'SOUL.md'), 'soul content')
  assert.equal(engine.load('SOUL.md'), 'soul content')
})

async function waitFor(predicate, timeoutMs = 3000) {
  const start = Date.now()
  while (!(await predicate())) {
    if (Date.now() - start > timeoutMs) throw new Error('waitFor timed out')
    await new Promise((resolve) => setTimeout(resolve, 10))
  }
}

test('personality: watcher invalidates cache on rewrite, reload forces re-read', async () => {
  const dir = tempDir('personality-2')
  const engine = createPersonalityEngine({ config: resolveConfig({ path: dir }), logger: silentLogger })
  const path = join(dir, 'IDENTITY.md')
  writeFileSync(path, 'v1')
  assert.equal(engine.load('IDENTITY.md'), 'v1')
  const first = engine.load('IDENTITY.md')
  assert.equal(first, 'v1')
  // Same-size rewrite inside one millisecond: the watcher must invalidate.
  writeFileSync(path, 'v2')
  await waitFor(() => engine.load('IDENTITY.md') === 'v2')
  engine.reload()
  assert.equal(engine.load('IDENTITY.md'), 'v2')
  engine.closeWatchers()
})

test('personality: legacy soul/ subdirectory layout still resolves', () => {
  const dir = tempDir('personality-3')
  mkdirSync(join(dir, 'soul'), { recursive: true })
  writeFileSync(join(dir, 'soul', 'SOUL.md'), 'legacy soul')
  const engine = createPersonalityEngine({ config: resolveConfig({ path: dir }), logger: silentLogger })
  assert.equal(engine.load('SOUL.md'), 'legacy soul')
})

test('personality: ensureFiles seeds only missing files, never overwrites', () => {
  const dir = tempDir('personality-4')
  const engine = createPersonalityEngine({ config: resolveConfig({ path: dir }), logger: silentLogger })
  engine.ensureFiles()
  assert.ok(existsSync(join(dir, 'SOUL.md')))
  assert.ok(existsSync(join(dir, 'TUNING.md')))
  writeFileSync(join(dir, 'SOUL.md'), 'mine')
  engine.ensureFiles()
  assert.equal(readFileSync(join(dir, 'SOUL.md'), 'utf8'), 'mine')
})

// ─────────────────────────────── memory ─────────────────────────────────────

test('memory: sqlite capture dedupes by message id and orders recent first', () => {
  const dir = tempDir('memory-1')
  const { memory } = engineFor(dir)
  assert.equal(memory.capture({ sessionId: 's1', messageId: 'm1', role: 'user', content: 'first' }), 1)
  // A duplicate message id must never create a second record.
  memory.capture({ sessionId: 's1', messageId: 'm1', role: 'user', content: 'first again' })
  memory.capture({ sessionId: 's1', messageId: 'm2', role: 'assistant', content: 'second' })
  const rows = memory.recent(10, undefined)
  assert.equal(rows.length, 2)
  assert.equal(rows[0].content, 'second')
  assert.equal(memory.stats().backend, 'sqlite')
  assert.equal(memory.stats().count, 2)
})

test('memory: recent excludes one session, search escapes LIKE wildcards', () => {
  const dir = tempDir('memory-2')
  const { memory } = engineFor(dir)
  memory.capture({ sessionId: 's1', messageId: 'a1', role: 'user', content: 'alpha 100%' })
  memory.capture({ sessionId: 's2', messageId: 'a2', role: 'user', content: 'beta under_score' })
  const excluded = memory.recent(10, 's1')
  assert.equal(excluded.length, 1)
  assert.equal(excluded[0].content, 'beta under_score')
  assert.equal(memory.search('100%', 10).length, 1)
  assert.equal(memory.search('under_score', 10).length, 1)
  assert.equal(memory.search('nomatch', 10).length, 0)
})

test('memory: clear removes records and reports the count', () => {
  const dir = tempDir('memory-3')
  const { memory } = engineFor(dir)
  memory.capture({ sessionId: 's1', messageId: 'c1', role: 'user', content: 'x' })
  memory.capture({ sessionId: 's1', messageId: 'c2', role: 'assistant', content: 'y' })
  assert.equal(memory.clear(), 2)
  assert.equal(memory.recent(10, undefined).length, 0)
})

test('memory: json backend works with atomic persistence', () => {
  const dir = tempDir('memory-4')
  const { memory, resolved } = engineFor(dir, { memory: { backend: 'json' } })
  memory.capture({ sessionId: 's1', messageId: 'j1', role: 'user', content: 'json record' })
  assert.equal(memory.stats().backend, 'json')
  assert.equal(memory.stats().count, 1)
  const file = join(resolved.path, 'memory', 'fallback.json')
  assert.ok(existsSync(file))
  const parsed = JSON.parse(readFileSync(file, 'utf8'))
  assert.equal(parsed.memories.length, 1)
  assert.equal(memory.clear(), 1)
  assert.equal(memory.stats().count, 0)
})

// ─────────────────────────────── context builder ────────────────────────────

function builderFor(dir, config) {
  const { resolved, personality, memory } = engineFor(dir, config)
  const builder = createContextBuilder({ personality, memory, config: resolved, logger: silentLogger })
  return { resolved, personality, memory, builder }
}

test('context: empty inputs render nothing', () => {
  const { builder } = builderFor(tempDir('context-1'))
  assert.equal(builder.stableSection(), '')
  assert.equal(builder.stateSection(), '')
  assert.equal(builder.memorySnapshot(undefined), '')
})

test('context: stable section carries markers, headings and bounded content', () => {
  const dir = tempDir('context-2')
  writeFileSync(join(dir, 'SOUL.md'), 'be honest')
  writeFileSync(join(dir, 'IDENTITY.md'), 'the agent')
  writeFileSync(join(dir, 'USER.md'), 'likes tea')
  const { builder } = builderFor(dir)
  const text = builder.stableSection()
  assert.ok(text.startsWith(CONTEXT_OPEN))
  assert.ok(text.endsWith(CONTEXT_CLOSE))
  assert.ok(text.includes('## Identity'))
  assert.ok(text.includes('## Core Behavior'))
  assert.ok(text.includes('## User Preferences'))
  assert.ok(text.includes('be honest'))
})

test('context: state section and markers', () => {
  const dir = tempDir('context-3')
  writeFileSync(join(dir, 'STATE.md'), 'working on the plugin')
  const { builder } = builderFor(dir)
  const text = builder.stateSection()
  assert.ok(text.startsWith(STATE_OPEN))
  assert.ok(text.endsWith(STATE_CLOSE))
  assert.ok(text.includes('working on the plugin'))
})

test('context: memory snapshot is bounded, marked untrusted, excludes current session', () => {
  const dir = tempDir('context-4')
  const { memory, builder } = builderFor(dir)
  memory.capture({ sessionId: 'old', messageId: 'o1', role: 'user', content: 'past project' })
  const text = builder.memorySnapshot('now')
  assert.ok(text.startsWith(MEMORY_OPEN))
  assert.ok(text.endsWith(MEMORY_CLOSE))
  assert.ok(text.includes(MEMORY_WARNING))
  assert.ok(text.includes('past project'))
  assert.equal(builder.memorySnapshot('old'), '')
})

test('context: maxChars truncation keeps markers', () => {
  const dir = tempDir('context-5')
  writeFileSync(join(dir, 'SOUL.md'), 'x'.repeat(5000))
  const { builder } = builderFor(dir, { context: { maxChars: 1500 } })
  const text = builder.stableSection()
  assert.ok(text.length <= 1500)
  assert.ok(text.includes('[truncated by AgentSoul]'))
})

test('context: textOfContent joins text blocks and skips tool calls', () => {
  assert.equal(textOfContent([{ type: 'text', text: 'a' }, { type: 'tool-call' }, { type: 'text', text: 'b' }]), 'a\nb')
  assert.equal(textOfContent([{ type: 'tool-call' }]), undefined)
})

// ─────────────────────────────── adapter wiring ─────────────────────────────

function mockContext() {
  const sections = []
  const contexts = []
  const tools = []
  const listeners = {}
  return {
    sections, contexts, tools, listeners,
    ctx: {
      logger: () => silentLogger,
      systemPrompt: {
        section: (entry) => { sections.push(entry) },
        context: (entry) => { contexts.push(entry) },
      },
      tools: { register: (definition) => { tools.push(definition) } },
      on: (event, handler) => { listeners[event] = handler },
    },
  }
}

test('apply: registers ordered sections, memory context, capture and five tools', () => {
  const dir = tempDir('apply-1')
  writeFileSync(join(dir, 'SOUL.md'), 'soul')
  const { sections, contexts, tools, listeners, ctx } = mockContext()
  apply(ctx, { path: dir })

  const personality = sections.find((s) => s.name === 'agentsoul:personality')
  assert.ok(personality !== undefined)
  assert.ok(personality.order < 0)
  assert.ok(personality.text().includes('soul'))
  // STATE.md must NOT be a system-prompt section (it would bust the prefix
  // cache on every edit) — it rides the runtime-context snapshot instead.
  assert.equal(sections.find((s) => s.name === 'agentsoul:state'), undefined)

  const stateContext = contexts.find((c) => c.name === 'agentsoul:state')
  const memoryContext = contexts.find((c) => c.name === 'agentsoul:memory')
  assert.ok(stateContext !== undefined)
  assert.ok(memoryContext !== undefined)
  assert.ok(stateContext.order < memoryContext.order)

  const names = tools.map((t) => t.name).sort()
  assert.deepEqual(names, [
    'agentsoul_memory_clear',
    'agentsoul_memory_distill',
    'agentsoul_memory_list',
    'agentsoul_memory_search',
    'agentsoul_personality_reload',
    'agentsoul_status',
  ])

  // capture: user text is recorded, plugin-sourced messages are not
  const onEvent = listeners['session/event']
  assert.equal(typeof onEvent, 'function')
  onEvent({ id: 's1' }, { type: 'user/message', data: { id: 'u1', content: [{ type: 'text', text: 'hello master' }], source: { kind: 'user' } } })
  onEvent({ id: 's1' }, { type: 'user/message', data: { id: 'p1', content: [{ type: 'text', text: 'plugin snapshot' }], source: { kind: 'plugin' } } })
  onEvent({ id: 's1' }, { type: 'assistant/message', data: { message: { id: 'a1', content: [{ type: 'text', text: 'hi!' }] } } })

  const snapshot = memoryContext.text({ agent: { session: { id: 's1' } } })
  assert.ok(snapshot === '')
  const other = memoryContext.text({ agent: { session: { id: 's2' } } })
  assert.ok(other.includes('hello master'))
  assert.ok(other.includes('hi!'))
  assert.ok(!other.includes('plugin snapshot'))
})

test('apply: status tool reports live engine state', async () => {
  const dir = tempDir('apply-2')
  writeFileSync(join(dir, 'IDENTITY.md'), 'who i am')
  const { tools, listeners, ctx } = mockContext()
  apply(ctx, { path: dir })
  const onEvent = listeners['session/event']
  onEvent({ id: 's1' }, { type: 'user/message', data: { id: 'u1', content: [{ type: 'text', text: 'remember me' }], source: { kind: 'user' } } })

  const statusTool = tools.find((t) => t.name === 'agentsoul_status')
  const value = await statusTool.execute({}, {})
  assert.equal(value.enabled, true)
  assert.equal(value.personalityLoaded, true)
  assert.equal(value.files['IDENTITY.md'], 'loaded')
  assert.equal(value.memoryBackend, 'sqlite')
  assert.equal(value.memoryCount, 1)
  assert.ok(value.contextChars > 0)
})

test('apply: disabled by config registers nothing', () => {
  const { sections, contexts, tools, ctx } = mockContext()
  apply(ctx, { enabled: false })
  assert.equal(sections.length, 0)
  assert.equal(contexts.length, 0)
  assert.equal(tools.length, 0)
})

// ─────────────────────────────── distillation ───────────────────────────────

const VALID_REPLY = '{"memories":[{"content":"用户喜欢咖啡","type":"persona","priority":80,"action":"new","target_id":null}]}'

test('distill: parse handles raw, fenced and prose-wrapped JSON; garbage is empty', () => {
  assert.equal(parseDistillationResult(VALID_REPLY).length, 1)
  const fenced = parseDistillationResult('好的，以下是结果：\n```json\n' + VALID_REPLY + '\n```\n完毕')
  assert.equal(fenced.length, 1)
  assert.equal(fenced[0].content, '用户喜欢咖啡')
  assert.equal(fenced[0].type, 'persona')
  assert.equal(fenced[0].priority, 80)
  assert.equal(fenced[0].action, 'new')
  assert.deepEqual(parseDistillationResult('not json at all'), [])
  assert.deepEqual(parseDistillationResult(''), [])
  assert.deepEqual(parseDistillationResult('{"memories": "nope"}'), [])
})

test('distill: user prompt carries new messages and the existing memory list', () => {
  const messages = [{ id: 1, role: 'user', content: '我喜欢咖啡', created_at: 1700000000 }]
  const existing = [{ id: 9, type: 'persona', priority: 80, content: '用户喜欢茶' }]
  const prompt = buildUserPrompt(messages, existing)
  assert.ok(prompt.includes('我喜欢咖啡'))
  assert.ok(prompt.includes('[9] (persona, priority=80) 用户喜欢茶'))
})

test('memory: distilled layer saves, clamps, updates, lists by priority and clears', () => {
  const dir = tempDir('distill-mem-1')
  const { memory } = engineFor(dir)
  const stored = memory.saveDistilled([
    { type: 'persona', content: '用户喜欢咖啡', priority: 80, sessionId: 's1' },
    { type: 'bad-type', content: '类型不合法', priority: 999, sessionId: 's1' },
  ])
  assert.equal(stored, 2)
  const list = memory.listDistilled(10)
  assert.equal(list.length, 2)
  assert.equal(list[0].content, '类型不合法') // clamped priority 100 sorts first
  assert.equal(list[0].type, 'persona') // whitelisted
  assert.equal(list[0].priority, 100) // clamped
  assert.equal(list[1].content, '用户喜欢咖啡')
  assert.equal(memory.updateDistilled(list[0].id, { type: 'episodic', content: '用户开始喝手冲', priority: 90 }), true)
  const updated = memory.listDistilled(10)
  assert.equal(updated[0].content, '用户开始喝手冲')
  assert.equal(updated[0].type, 'episodic')
  assert.equal(memory.clearDistilled(), 2)
  assert.equal(memory.distilledCount(), 0)
})

test('memory: undistilled tracking respects batch and char budget', () => {
  const dir = tempDir('distill-mem-2')
  const { memory } = engineFor(dir)
  for (let i = 0; i < 5; i++) memory.capture({ sessionId: 's', messageId: 'm' + i, role: 'user', content: '消息' + i })
  assert.equal(memory.getUndistilledCount(), 5)
  const batch = memory.getUndistilledMessages(3, 1000)
  assert.equal(batch.length, 3)
  assert.equal(memory.markDistilled([batch[0].id, batch[1].id]), 2)
  assert.equal(memory.getUndistilledCount(), 3)
  const stats = memory.stats()
  assert.equal(stats.count, 5)
  assert.equal(stats.undistilledCount, 3)
})

test('memory: json backend supports the distilled layer', () => {
  const dir = tempDir('distill-mem-3')
  const { memory } = engineFor(dir, { memory: { backend: 'json' } })
  memory.capture({ sessionId: 's', messageId: 'm1', role: 'user', content: 'raw' })
  memory.saveDistilled([{ type: 'persona', content: '用户喜欢茶', priority: 70, sessionId: 's' }])
  assert.equal(memory.distilledCount(), 1)
  assert.equal(memory.getUndistilledCount(), 1)
  assert.equal(memory.searchDistilled('喜欢茶', 10).length, 1)
  memory.markDistilled([1])
  assert.equal(memory.getUndistilledCount(), 0)
})

test('distill: engine skips below threshold, runs at threshold, applies updates', async () => {
  const dir = tempDir('distill-1')
  const { memory } = engineFor(dir)
  const calls = []
  const engine = createDistillationEngine({
    memory,
    config: resolveConfig({ path: dir }).distill,
    callModel: async (system, user) => {
      calls.push({ system, user })
      if (calls.length === 1) return VALID_REPLY
      return '{"memories":[{"content":"用户现在喜欢手冲","type":"persona","priority":90,"action":"update","target_id":1}]}'
    },
    logger: silentLogger,
  })
  // below threshold: no model call
  for (let i = 0; i < DEFAULT_DISTILL_THRESHOLD - 1; i++) memory.capture({ sessionId: 's', messageId: 'n' + i, role: 'user', content: '内容' + i })
  const skipped = await engine.maybeDistill()
  assert.equal(skipped.skipped, 'below-threshold')
  assert.equal(calls.length, 0)

  // at threshold: one pass stores and marks
  memory.capture({ sessionId: 's', messageId: 'nX', role: 'user', content: '触发蒸馏' })
  const result = await engine.maybeDistill()
  assert.equal(result.messages, DEFAULT_DISTILL_THRESHOLD)
  assert.equal(result.stored, 1)
  assert.equal(calls.length, 1)
  assert.equal(memory.getUndistilledCount(), 0)
  assert.equal(memory.distilledCount(), 1)

  // second pass: update path works against the stored target
  for (let i = 0; i < DEFAULT_DISTILL_THRESHOLD; i++) memory.capture({ sessionId: 's', messageId: 'u' + i, role: 'user', content: '更新内容' + i })
  const second = await engine.maybeDistill()
  assert.equal(second.updated, 1)
  const list = memory.listDistilled(10)
  assert.equal(list[0].content, '用户现在喜欢手冲')
  assert.equal(list[0].priority, 90)
})

test('distill: engine cools down after a failure and never throws', async () => {
  const dir = tempDir('distill-2')
  const { memory } = engineFor(dir)
  let attempts = 0
  const engine = createDistillationEngine({
    memory,
    config: { ...resolveConfig({ path: dir }).distill, threshold: 2, cooldownMs: 60000 },
    callModel: async () => { attempts++; throw new Error('provider down') },
    logger: silentLogger,
  })
  memory.capture({ sessionId: 's', messageId: 'f1', role: 'user', content: '一' })
  memory.capture({ sessionId: 's', messageId: 'f2', role: 'user', content: '二' })
  const first = await engine.maybeDistill()
  assert.equal(first.skipped, 'error')
  assert.equal(attempts, 1)
  const second = await engine.maybeDistill()
  assert.equal(second.skipped, 'cooldown')
  assert.equal(attempts, 1)
})

test('distill: single-flight mutex prevents concurrent passes', async () => {
  const dir = tempDir('distill-3')
  const { memory } = engineFor(dir)
  let resolveCall
  const gate = new Promise((resolve) => { resolveCall = resolve })
  let calls = 0
  const engine = createDistillationEngine({
    memory,
    config: { ...resolveConfig({ path: dir }).distill, threshold: 2 },
    callModel: async () => { calls++; await gate; return VALID_REPLY },
    logger: silentLogger,
  })
  memory.capture({ sessionId: 's', messageId: 'c1', role: 'user', content: '一' })
  memory.capture({ sessionId: 's', messageId: 'c2', role: 'user', content: '二' })
  const firstRun = engine.maybeDistill()
  const secondRun = await engine.maybeDistill()
  assert.equal(secondRun.skipped, 'busy')
  resolveCall()
  await firstRun
  assert.equal(calls, 1)
})

// ─────────────────── adapter wiring with a fake harness LLM ─────────────────

function fakeLlm(text) {
  return {
    stream: async function* () {
      yield { type: 'text-delta', index: 0, text }
      yield { type: 'finish', reason: { kind: 'stop' } }
    },
  }
}

test('apply: distillation triggers through the harness llm after threshold', async () => {
  const dir = tempDir('apply-distill')
  writeFileSync(join(dir, 'IDENTITY.md'), 'who i am')
  const { sections, contexts, tools, listeners } = mockContext()
  const ctx = {
    logger: () => silentLogger,
    systemPrompt: { section: (e) => { sections.push(e) }, context: (e) => { contexts.push(e) } },
    tools: { register: (d) => { tools.push(d) } },
    on: (event, handler) => { listeners[event] = handler },
    llm: fakeLlm('{"memories":[{"content":"用户在做插件移植","type":"episodic","priority":85,"action":"new","target_id":null}]}'),
    agentDefaultModel: { currentSelection: () => ({ provider: 'test', model: 'test-model' }) },
  }
  apply(ctx, { path: dir, distill: { threshold: 3 } })
  const onEvent = listeners['session/event']
  for (let i = 0; i < 3; i++) {
    onEvent({ id: 's1' }, { type: 'user/message', data: { id: 'd' + i, content: [{ type: 'text', text: '内容' + i }], source: { kind: 'user' } } })
  }
  const statusTool = tools.find((t) => t.name === 'agentsoul_status')
  await waitFor(async () => {
    const value = await statusTool.execute({}, {})
    return value.distilledCount === 1 && value.undistilledCount === 0
  })
  const value = await statusTool.execute({}, {})
  assert.equal(value.distilledCount, 1)
  assert.equal(value.memoryCount, 3)
  const memoryContext = contexts.find((c) => c.name === 'agentsoul:memory')
  const stateContext = contexts.find((c) => c.name === 'agentsoul:state')
  const other = memoryContext.text({ agent: { session: { id: 's9' } } })
  assert.ok(other.includes('## Consolidated Memories'))
  assert.ok(other.includes('用户在做插件移植'))
  // distilled memories from the calling session are excluded (cache stability)
  const own = memoryContext.text({ agent: { session: { id: 's1' } } })
  assert.ok(!own.includes('用户在做插件移植'))
  // STATE.md rides the runtime-context snapshot, wrapped in its own marker
  const stateText = stateContext.text({ agent: { session: { id: 's9' } } })
  assert.ok(stateText.includes('[AGENTSOUL_STATE]'))
  assert.ok(stateText.includes('## Current State'))
})

test('distill: direct HTTP caller posts an OpenAI-compatible body and parses the reply', async () => {
  const originalFetch = globalThis.fetch
  let captured
  globalThis.fetch = async (url, options) => {
    captured = { url, options }
    return { ok: true, status: 200, text: async () => JSON.stringify({ choices: [{ message: { content: '{"memories":[]}' } }] }) }
  }
  try {
    const caller = createHttpModelCaller(resolveConfig({ distill: { apiKey: 'k', baseURL: 'https://x/v4', model: 'glm-4.7-flash' } }), silentLogger)
    const text = await caller('sys', 'user')
    assert.equal(text, '{"memories":[]}')
    assert.equal(captured.url, 'https://x/v4/chat/completions')
    assert.equal(captured.options.headers.Authorization, 'Bearer k')
    const body = JSON.parse(captured.options.body)
    assert.equal(body.model, 'glm-4.7-flash')
    assert.equal(body.messages.length, 2)
    assert.equal(body.messages[0].role, 'system')
  } finally {
    globalThis.fetch = originalFetch
  }
})

test('distill: direct HTTP caller rejects non-OK responses loudly', async () => {
  const originalFetch = globalThis.fetch
  globalThis.fetch = async () => ({ ok: false, status: 401, text: async () => 'bad key' })
  try {
    const caller = createHttpModelCaller(resolveConfig({ distill: { apiKey: 'k', baseURL: 'https://x', model: 'm' } }), silentLogger)
    await assert.rejects(() => caller('s', 'u'), /401/)
  } finally {
    globalThis.fetch = originalFetch
  }
})

test('distill: HTTP caller retries a 429 once then succeeds', async () => {
  const originalFetch = globalThis.fetch
  let calls = 0
  globalThis.fetch = async () => {
    calls++
    if (calls === 1) return { ok: false, status: 429, text: async () => 'busy' }
    return { ok: true, status: 200, text: async () => JSON.stringify({ choices: [{ message: { content: 'done' } }] }) }
  }
  try {
    const caller = createHttpModelCaller(resolveConfig({ distill: { apiKey: 'k', baseURL: 'https://x', model: 'm' } }), silentLogger)
    const text = await caller('s', 'u', undefined)
    assert.equal(text, 'done')
    assert.equal(calls, 2)
  } finally {
    globalThis.fetch = originalFetch
  }
})

test('distill: HTTP caller reports thinking-model token exhaustion', async () => {
  const originalFetch = globalThis.fetch
  globalThis.fetch = async () => ({
    ok: true, status: 200,
    text: async () => JSON.stringify({ choices: [{ message: { content: '', reasoning_content: 'thinking...' } }] }),
  })
  try {
    const caller = createHttpModelCaller(resolveConfig({ distill: { apiKey: 'k', baseURL: 'https://x', model: 'm' } }), silentLogger)
    await assert.rejects(() => caller('s', 'u'), /reasoning content/)
  } finally {
    globalThis.fetch = originalFetch
  }
})

test('distill: falls back to the harness LLM when the primary HTTP model fails', async () => {
  const originalFetch = globalThis.fetch
  globalThis.fetch = async () => ({ ok: false, status: 500, text: async () => 'primary down' })
  let llmCalls = 0
  const ctx = {
    llm: {
      stream: async function* () {
        llmCalls++
        yield { type: 'text-delta', index: 0, text: VALID_REPLY }
        yield { type: 'finish', reason: { kind: 'stop' } }
      },
    },
    agentDefaultModel: { currentSelection: () => ({ provider: 'deepseek-official', model: 'deepseek-v4-flash' }) },
  }
  try {
    const caller = createModelCaller(ctx, resolveConfig({ distill: { apiKey: 'k', baseURL: 'https://x', model: 'glm-4.7-flash' } }), silentLogger)
    const text = await caller('s', 'u', undefined)
    assert.equal(text, VALID_REPLY)
    assert.equal(llmCalls, 1)
  } finally {
    globalThis.fetch = originalFetch
  }
})

test('distill: no fallback when disabled — primary failure propagates', async () => {
  const originalFetch = globalThis.fetch
  globalThis.fetch = async () => ({ ok: false, status: 500, text: async () => 'primary down' })
  const ctx = { llm: { stream: async function* () { yield { type: 'finish', reason: { kind: 'stop' } } } } }
  try {
    const caller = createModelCaller(ctx, resolveConfig({ distill: { apiKey: 'k', baseURL: 'https://x', model: 'm', fallback: false } }), silentLogger)
    await assert.rejects(() => caller('s', 'u'), /primary down/)
  } finally {
    globalThis.fetch = originalFetch
  }
})

test('apply: manual distill tool runs one pass and reports counts', async () => {
  const dir = tempDir('apply-distill-2')
  const { tools, listeners } = mockContext()
  const ctx = {
    logger: () => silentLogger,
    systemPrompt: { section: () => {}, context: () => {} },
    tools: { register: (d) => { tools.push(d) } },
    on: (event, handler) => { listeners[event] = handler },
    llm: fakeLlm(VALID_REPLY),
  }
  apply(ctx, { path: dir })
  const onEvent = listeners['session/event']
  for (let i = 0; i < 4; i++) {
    onEvent({ id: 's1' }, { type: 'user/message', data: { id: 'm' + i, content: [{ type: 'text', text: '手动' + i }], source: { kind: 'user' } } })
  }
  const distillTool = tools.find((t) => t.name === 'agentsoul_memory_distill')
  const result = await distillTool.execute({}, {})
  assert.equal(result.messages, 4)
  assert.equal(result.stored, 1)
  const statusTool = tools.find((t) => t.name === 'agentsoul_status')
  const value = await statusTool.execute({}, {})
  assert.equal(value.distilledCount, 1)
})
