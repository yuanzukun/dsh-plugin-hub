import * as React from 'react'
import {
  IconPlusOutlineMedium,
  IconRefreshOutlineMedium,
  IconLoadingOutlineMedium,
  IconDownloadOutlineMedium,
  IconCodeOutlineMedium,
} from '@deepseek-ai/dsh-client-ui-primitives'
import {
  type McpSettingsProps,
  type GlobalMcpServerConfig,
  type EnvEntry,
  API_ENDPOINTS,
  API_METHODS,
} from '../types/index.ts'
import { EmptyState } from '../components/index.ts'
import { useMcpServers } from './hooks/useMcpServers.ts'
import { McpServerCard } from './components/McpServerCard.ts'
import { McpServerFormModal } from './components/McpServerFormModal.ts'
import { McpToolsModal } from './components/McpToolsModal.ts'
import { McpResourcePanel } from './components/McpResourcePanel.ts'
import { McpPromptPanel } from './components/McpPromptPanel.ts'
import type { McpPrimitiveTab } from './components/McpPrimitivesTabs.ts'
import { useMcpPrimitives } from './hooks/useMcpPrimitives.ts'
import type { McpDiscovery } from './hooks/useMcpPrimitives.ts'
import { useCopyFeedback } from './hooks/useCopyFeedback.ts'
import { McpImportExportModal } from './components/McpImportExportModal.ts'
import { McpSaveConfirmModal } from './components/McpSaveConfirmModal.ts'

const e = React.createElement

export function McpServersSettingsTab({ t, close: _close }: McpSettingsProps) {
  const {
    servers,
    setServers,
    loading,
    error,
    successMsg,
    setSuccessMsg,
    loadServers,
    handleDelete,
    handleTest,
    testingId,
    testResults,
    executeSave,
  } = useMcpServers(t)

  // Form modal state
  const [formOpen, setFormOpen] = React.useState<boolean>(false)
  const [isEditing, setIsEditing] = React.useState<boolean>(false)
  const [editingOriginalId, setEditingOriginalId] = React.useState<
    string | null
  >(null)
  const [formServer, setFormServer] = React.useState<
    Partial<GlobalMcpServerConfig>
  >({
    transport: 'stdio',
  })
  const [envEntries, setEnvEntries] = React.useState<EnvEntry[]>([])
  const [headerEntries, setHeaderEntries] = React.useState<EnvEntry[]>([])
  const [formSaving, setFormSaving] = React.useState<boolean>(false)
  const [formTesting, setFormTesting] = React.useState<boolean>(false)
  const [formError, setFormError] = React.useState<string>('')
  const [showAdvanced, setShowAdvanced] = React.useState<boolean>(false)
  const [formTestResult, setFormTestResult] = React.useState<{
    ok: boolean
    message: string
  } | null>(null)

  // Save confirmation modal state (for pre-save test failures)
  const [saveConfirm, setSaveConfirm] = React.useState<{
    open: boolean
    message: string
    payload: GlobalMcpServerConfig
  } | null>(null)

  // Import modal state
  const [importOpen, setImportOpen] = React.useState<boolean>(false)
  const [importText, setImportText] = React.useState<string>('')
  const [importing, setImporting] = React.useState<boolean>(false)
  const [importError, setImportError] = React.useState<string>('')

  // Tools modal state
  const [toolsModalOpen, setToolsModalOpen] = React.useState<boolean>(false)
  const [primitiveTab, setPrimitiveTab] =
    React.useState<McpPrimitiveTab>('tools')
  const [toolsTargetServer, setToolsTargetServer] =
    React.useState<Partial<GlobalMcpServerConfig> | null>(null)
  const [toolsSource, setToolsSource] = React.useState<'card' | 'form'>('card')
  const [toolsDisabledSet, setToolsDisabledSet] = React.useState<Set<string>>(
    new Set(),
  )
  const [toolsSaving, setToolsSaving] = React.useState<boolean>(false)
  /**
   * Failure from writing tool enablement, kept apart from discovery errors: the
   * two have different causes and different fixes, and the discovery error is
   * owned by the shared hook. Both surface through the modal's one notice slot.
   */
  const [toolsSaveError, setToolsSaveError] = React.useState<string>('')

  // Open add form
  const handleOpenAdd = () => {
    setIsEditing(false)
    setEditingOriginalId(null)
    setShowAdvanced(false)
    setFormServer({
      id: '',
      name: '',
      description: '',
      transport: 'stdio',
      command: '',
      args: [],
      cwd: '',
      url: '',
      toolCallTimeoutMs: undefined,
      failOnStartupError: false,
      reconnect: {
        enabled: true,
        initialDelayMs: undefined,
        maxDelayMs: undefined,
        maxAttempts: undefined,
      },
      disabledTools: [],
    })
    setEnvEntries([])
    setHeaderEntries([])
    setFormError('')
    setFormTestResult(null)
    setFormOpen(true)
  }

  // Open edit form
  const handleOpenEdit = (server: GlobalMcpServerConfig) => {
    setIsEditing(true)
    setEditingOriginalId(server.id)
    setShowAdvanced(
      Boolean(
        server.toolCallTimeoutMs ||
        server.failOnStartupError ||
        (server.reconnect &&
          (server.reconnect.enabled === false ||
            server.reconnect.initialDelayMs !== undefined ||
            server.reconnect.maxDelayMs !== undefined ||
            server.reconnect.maxAttempts !== undefined)),
      ),
    )
    setFormServer({
      ...server,
      reconnect: {
        enabled: server.reconnect?.enabled !== false,
        initialDelayMs: server.reconnect?.initialDelayMs,
        maxDelayMs: server.reconnect?.maxDelayMs,
        maxAttempts: server.reconnect?.maxAttempts,
      },
      disabledTools: Array.isArray(server.disabledTools)
        ? [...server.disabledTools]
        : [],
    })
    setEnvEntries(
      server.env
        ? Object.entries(server.env).map(([key, value]) => ({ key, value }))
        : [],
    )
    setHeaderEntries(
      server.headers
        ? Object.entries(server.headers).map(([key, value]) => ({ key, value }))
        : [],
    )
    setFormError('')
    setFormTestResult(null)
    setFormOpen(true)
  }

  // Test connection from inside add/edit modal
  const handleFormTest = async () => {
    setFormError('')
    setFormTestResult(null)
    if (formServer.transport === 'stdio' && !formServer.command?.trim()) {
      setFormError(t('mcpServers.form.command') + ' is required for stdio')
      return
    }
    if (formServer.transport !== 'stdio' && !formServer.url?.trim()) {
      setFormError(t('mcpServers.form.url') + ' is required for HTTP/SSE')
      return
    }

    const envMap: Record<string, string> = {}
    for (const item of envEntries) {
      if (item.key.trim()) envMap[item.key.trim()] = item.value
    }
    const headerMap: Record<string, string> = {}
    for (const item of headerEntries) {
      if (item.key.trim()) headerMap[item.key.trim()] = item.value
    }

    const serverObj: Partial<GlobalMcpServerConfig> = {
      id: formServer.id?.trim() || 'modal_test',
      transport: formServer.transport,
      command: formServer.command?.trim(),
      args: formServer.args || [],
      cwd: formServer.cwd?.trim() || undefined,
      env: Object.keys(envMap).length > 0 ? envMap : undefined,
      url: formServer.url?.trim(),
      headers: Object.keys(headerMap).length > 0 ? headerMap : undefined,
      toolCallTimeoutMs:
        formServer.toolCallTimeoutMs && formServer.toolCallTimeoutMs > 0
          ? Number(formServer.toolCallTimeoutMs)
          : undefined,
      failOnStartupError: Boolean(formServer.failOnStartupError),
      reconnect: formServer.reconnect,
    }

    setFormTesting(true)
    try {
      const res = await fetch(API_ENDPOINTS.mcpServersProbe, {
        method: API_METHODS.mcpServersProbe,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ server: serverObj }),
      })
      const data = await res.json()
      setFormTestResult({
        ok: Boolean(data.ok),
        message: data.message || (data.ok ? 'Connection OK' : 'Failed'),
      })
      if (data.ok) {
        setFormServer((prev) => {
          const updated = {
            ...prev,
            detectedTransport: data.detectedTransport || prev.detectedTransport,
            serverInfo: data.serverInfo || prev.serverInfo,
            lastTestedAt: Date.now(),
          }

          // If in "add server" mode, automatically populate empty fields
          if (!isEditing) {
            const detectedId = data.serverInfo?.name
              ? data.serverInfo.name
                  .toLowerCase()
                  .replace(/[^a-zA-Z0-9_-]/g, '_')
                  .slice(0, 64)
              : ''
            const detectedName =
              data.serverInfo?.title || data.serverInfo?.name || ''
            const detectedDesc = data.serverInfo?.description || ''

            if (!updated.id?.trim() && detectedId) {
              updated.id = detectedId
            }
            if (!updated.name?.trim() && detectedName) {
              updated.name = detectedName
            }
            if (!updated.description?.trim() && detectedDesc) {
              updated.description = detectedDesc
            }
          }

          return updated
        })
      }
    } catch (err: unknown) {
      setFormTestResult({
        ok: false,
        message: err instanceof Error ? err.message : String(err),
      })
    } finally {
      setFormTesting(false)
    }
  }

  // Publish a completed discovery to the server list and the modal's own copy.
  //
  // One probe (or cache read) yields tools, resources, templates, prompts,
  // serverInfo, and transport together. Writing them all here is what lets the
  // three tabs share one request, and patching the modal's target object is what
  // lets the discovery hook seed from it on the next render.
  const applyDiscovery = React.useCallback(
    (discovery: McpDiscovery, serverId?: string) => {
      const id = serverId ?? toolsTargetServer?.id
      if (!id) return
      const { lists } = discovery
      const patch: Partial<GlobalMcpServerConfig> = {
        toolDetails: discovery.tools,
        tools: discovery.tools.length,
        resourceDetails: lists.resources,
        resourceTemplateDetails: lists.resourceTemplates,
        promptDetails: lists.prompts,
        capabilities: lists.capabilities,
        resourceCount: lists.resources.length,
        resourceTemplateCount: lists.resourceTemplates.length,
        promptCount: lists.prompts.length,
        ...(discovery.serverInfo ? { serverInfo: discovery.serverInfo } : {}),
        ...(discovery.detectedTransport
          ? { detectedTransport: discovery.detectedTransport }
          : {}),
        lastTestedAt: Date.now(),
      }
      setServers((prev) =>
        prev.map((entry) => (entry.id === id ? { ...entry, ...patch } : entry)),
      )
      setToolsTargetServer((prev) => (prev ? { ...prev, ...patch } : prev))
    },
    [toolsTargetServer?.id],
  )

  // Open Tools modal from card or form
  const handleOpenTools = (
    server: Partial<GlobalMcpServerConfig>,
    source: 'card' | 'form' = 'card',
  ) => {
    setToolsTargetServer(server)
    setToolsSource(source)
    setToolsDisabledSet(
      new Set(Array.isArray(server.disabledTools) ? server.disabledTools : []),
    )
    setToolsModalOpen(true)
    setPrimitiveTab('tools')
    setToolsSaveError('')
  }

  const handleFormOpenTools = () => {
    if (formServer.transport === 'stdio' && !formServer.command?.trim()) {
      setFormError(t('mcpServers.form.command') + ' is required for stdio')
      return
    }
    if (formServer.transport !== 'stdio' && !formServer.url?.trim()) {
      setFormError(t('mcpServers.form.url') + ' is required for HTTP/SSE')
      return
    }

    const envMap: Record<string, string> = {}
    for (const item of envEntries) {
      if (item.key.trim()) envMap[item.key.trim()] = item.value
    }
    const headerMap: Record<string, string> = {}
    for (const item of headerEntries) {
      if (item.key.trim()) headerMap[item.key.trim()] = item.value
    }

    const serverObj: Partial<GlobalMcpServerConfig> = {
      id: formServer.id?.trim() || 'modal_tools',
      name: formServer.name?.trim() || 'MCP Server',
      description: formServer.description?.trim(),
      transport: formServer.transport,
      command: formServer.command?.trim(),
      args: formServer.args || [],
      cwd: formServer.cwd?.trim() || undefined,
      env: Object.keys(envMap).length > 0 ? envMap : undefined,
      url: formServer.url?.trim(),
      headers: Object.keys(headerMap).length > 0 ? headerMap : undefined,
      toolCallTimeoutMs:
        formServer.toolCallTimeoutMs && formServer.toolCallTimeoutMs > 0
          ? Number(formServer.toolCallTimeoutMs)
          : undefined,
      failOnStartupError: Boolean(formServer.failOnStartupError),
      reconnect: formServer.reconnect,
      disabledTools: formServer.disabledTools || [],
    }

    handleOpenTools(serverObj, 'form')
  }

  // All three tabs are views of ONE discovery, so a single hook owns the
  // request. It is cache-first, and resource/prompt CONTENT is never persisted.
  const discovery = useMcpPrimitives({
    server: toolsTargetServer,
    onDiscovery: applyDiscovery,
    t,
  })
  const { copiedKey, copy } = useCopyFeedback()

  const handleCopyPrimitive = React.useCallback(
    (text: string, key: string) => {
      copy(text, key)
    },
    [copy],
  )

  const handleToggleTool = (toolName: string) => {
    setToolsDisabledSet((prev) => {
      const next = new Set(prev)
      if (next.has(toolName)) next.delete(toolName)
      else next.add(toolName)
      return next
    })
  }

  const handleToggleAllTools = (enableAll: boolean) => {
    if (enableAll) setToolsDisabledSet(new Set())
    else setToolsDisabledSet(new Set(discovery.tools.map((t) => t.name)))
  }

  const handleSaveToolsModal = async () => {
    const disabledArray = Array.from(toolsDisabledSet)
    if (toolsSource === 'form') {
      setFormServer((prev) => ({ ...prev, disabledTools: disabledArray }))
      setToolsModalOpen(false)
      setSuccessMsg(t('mcpServers.toolsModal.saveSuccess'))
      setTimeout(() => setSuccessMsg(''), 3000)
      return
    }

    if (!toolsTargetServer?.id) {
      setToolsModalOpen(false)
      return
    }

    setToolsSaving(true)
    try {
      const targetServer =
        servers.find((s) => s.id === toolsTargetServer.id) || toolsTargetServer
      const updatedServer: GlobalMcpServerConfig = {
        ...targetServer,
        disabledTools: disabledArray,
      } as GlobalMcpServerConfig

      const res = await fetch(API_ENDPOINTS.mcpServersEdit, {
        method: API_METHODS.mcpServersEdit,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ server: updatedServer }),
      })
      const data = await res.json()
      if (res.ok && data.ok) {
        setServers((prev) =>
          prev.map((s) =>
            s.id === updatedServer.id ? data.server || updatedServer : s,
          ),
        )
        setToolsModalOpen(false)
        setSuccessMsg(t('mcpServers.toolsModal.saveSuccess'))
        setTimeout(() => setSuccessMsg(''), 3000)
      } else {
        setToolsSaveError(data.error || 'Failed to save tool settings')
      }
    } catch (err: unknown) {
      setToolsSaveError(err instanceof Error ? err.message : String(err))
    } finally {
      setToolsSaving(false)
    }
  }

  // Submit save from add/edit modal
  const handleSaveForm = async () => {
    setFormError('')
    if (!formServer.id?.trim()) {
      setFormError(t('mcpServers.form.id') + ' is required')
      return
    }
    if (!/^[a-zA-Z0-9_-]+$/.test(formServer.id.trim())) {
      setFormError(
        'ID can only contain letters, numbers, underscores, and hyphens',
      )
      return
    }
    const conflict = servers.some(
      (s) =>
        s.id.toLowerCase() === formServer.id?.trim().toLowerCase() &&
        (!isEditing || s.id.toLowerCase() !== editingOriginalId?.toLowerCase()),
    )
    if (conflict) {
      setFormError(`Server ID "${formServer.id}" already exists`)
      return
    }
    if (formServer.transport === 'stdio' && !formServer.command?.trim()) {
      setFormError(t('mcpServers.form.command') + ' is required for stdio')
      return
    }
    if (formServer.transport !== 'stdio' && !formServer.url?.trim()) {
      setFormError(t('mcpServers.form.url') + ' is required for HTTP/SSE')
      return
    }

    const envMap: Record<string, string> = {}
    for (const item of envEntries) {
      if (item.key.trim()) envMap[item.key.trim()] = item.value
    }
    const headerMap: Record<string, string> = {}
    for (const item of headerEntries) {
      if (item.key.trim()) headerMap[item.key.trim()] = item.value
    }

    const payload: GlobalMcpServerConfig = {
      id: formServer.id.trim(),
      name: formServer.name?.trim() || formServer.id.trim(),
      description: formServer.description?.trim() || undefined,
      transport: formServer.transport || 'stdio',
      command:
        formServer.transport === 'stdio'
          ? formServer.command?.trim()
          : undefined,
      args:
        formServer.transport === 'stdio' ? formServer.args || [] : undefined,
      cwd:
        formServer.transport === 'stdio'
          ? formServer.cwd?.trim() || undefined
          : undefined,
      env:
        formServer.transport === 'stdio' && Object.keys(envMap).length > 0
          ? envMap
          : undefined,
      url:
        formServer.transport !== 'stdio' ? formServer.url?.trim() : undefined,
      headers:
        formServer.transport !== 'stdio' && Object.keys(headerMap).length > 0
          ? headerMap
          : undefined,
      toolCallTimeoutMs:
        formServer.toolCallTimeoutMs && formServer.toolCallTimeoutMs > 0
          ? Number(formServer.toolCallTimeoutMs)
          : undefined,
      failOnStartupError: Boolean(formServer.failOnStartupError),
      reconnect: formServer.reconnect,
      disabledTools: formServer.disabledTools || [],
      detectedTransport: formServer.detectedTransport,
      serverInfo: formServer.serverInfo,
    }

    // Pre-save test connection check
    setFormSaving(true)
    try {
      const testRes = await fetch(API_ENDPOINTS.mcpServersProbe, {
        method: API_METHODS.mcpServersProbe,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ server: payload }),
      })
      const testData = await testRes.json()
      if (testData && testData.ok) {
        payload.detectedTransport =
          testData.detectedTransport || payload.detectedTransport
        payload.serverInfo = testData.serverInfo || payload.serverInfo
        payload.lastTestedAt = Date.now()
        const saveRes = await executeSave(
          payload,
          isEditing && editingOriginalId ? editingOriginalId : undefined,
        )
        if (saveRes.ok) setFormOpen(false)
        else setFormError(saveRes.error || 'Failed to save server')
      } else {
        setSaveConfirm({
          open: true,
          message:
            testData?.message ||
            'Failed to establish connection to the MCP server.',
          payload,
        })
      }
    } catch {
      setSaveConfirm({
        open: true,
        message: 'Network request failed while testing connection.',
        payload,
      })
    } finally {
      setFormSaving(false)
    }
  }

  const handleConfirmSave = async (payload: GlobalMcpServerConfig) => {
    setFormSaving(true)
    setSaveConfirm(null)
    const saveRes = await executeSave(
      payload,
      isEditing && editingOriginalId ? editingOriginalId : undefined,
    )
    setFormSaving(false)
    if (saveRes.ok) setFormOpen(false)
    else setFormError(saveRes.error || 'Failed to save server')
  }

  // Export JSON configuration
  const handleExport = () => {
    const mcpServersMap: Record<string, Record<string, unknown>> = {}
    for (const s of servers) {
      if (s.transport === 'stdio') {
        mcpServersMap[s.id] = {
          command: s.command,
          args: s.args,
          cwd: s.cwd,
          env: s.env,
        }
      } else {
        mcpServersMap[s.id] = {
          url: s.url,
          headers: s.headers,
        }
      }
    }
    const jsonStr = JSON.stringify({ mcpServers: mcpServersMap }, null, 2)
    const blob = new Blob([jsonStr], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'mcp-servers.json'
    a.click()
    URL.revokeObjectURL(url)
  }

  // Import JSON configuration
  const handleImportSubmit = async () => {
    setImportError('')
    setImporting(true)
    try {
      const parsed = JSON.parse(importText)
      const res = await fetch(API_ENDPOINTS.mcpServersImport, {
        method: API_METHODS.mcpServersImport,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: parsed }),
      })
      const data = await res.json()
      if (res.ok && data.ok) {
        setServers(data.servers || [])
        setImportOpen(false)
        setSuccessMsg(
          t('mcpServers.importModal.success', { count: data.count || 0 }),
        )
        setTimeout(() => setSuccessMsg(''), 3000)
      } else {
        setImportError(data.message || t('mcpServers.importModal.error'))
      }
    } catch (err: unknown) {
      setImportError(
        t('mcpServers.importModal.error') +
          ': ' +
          (err instanceof Error ? err.message : String(err)),
      )
    } finally {
      setImporting(false)
    }
  }

  return e(
    'div',
    { className: 'dsh-mcp-settings-page' },
    // Header Card
    e(
      'div',
      { className: 'dsh-mcp-header-card' },
      e(
        'div',
        { className: 'dsh-mcp-header-title-row' },
        e(
          'div',
          null,
          e('h2', { className: 'dsh-mcp-page-title' }, t('mcpServers.title')),
          e('p', { className: 'dsh-mcp-page-desc' }, t('mcpServers.desc')),
        ),
        e(
          'div',
          { className: 'dsh-mcp-header-actions' },
          e(
            'button',
            {
              type: 'button',
              className: 'dsh-sam-btn primary',
              onClick: handleOpenAdd,
            },
            e(IconPlusOutlineMedium, { size: 14 }),
            t('mcpServers.actions.add'),
          ),
          e(
            'button',
            {
              type: 'button',
              className: 'dsh-sam-btn secondary',
              onClick: () => {
                setImportText('')
                setImportError('')
                setImportOpen(true)
              },
            },
            e(IconCodeOutlineMedium, { size: 14 }),
            t('mcpServers.actions.import'),
          ),
          e(
            'button',
            {
              type: 'button',
              className: 'dsh-sam-btn secondary',
              disabled: servers.length === 0,
              onClick: handleExport,
            },
            e(IconDownloadOutlineMedium, { size: 14 }),
            t('mcpServers.actions.export'),
          ),
          e(
            'button',
            {
              type: 'button',
              className: 'dsh-sam-btn secondary dsh-mcp-refresh-btn',
              onClick: loadServers,
              title: t('mcpServers.actions.refresh'),
            },
            e(IconRefreshOutlineMedium, { size: 14 }),
          ),
        ),
      ),
    ),

    // Notifications
    successMsg
      ? e('div', { className: 'dsh-sam-notice success' }, successMsg)
      : null,
    error ? e('div', { className: 'dsh-sam-notice error' }, error) : null,

    // Server Cards List
    loading
      ? e(
          'div',
          {
            // Was the undefined `dsh-sam-loading`; this class carries the
            // intended secondary-text styling.
            className: 'dsh-sam-desc',
            style: { padding: '48px 0', textAlign: 'center' },
          },
          e(IconLoadingOutlineMedium, { size: 24, className: 'dsh-spin' }),
        )
      : servers.length === 0
        ? e(EmptyState, {
            message: t('mcpServers.table.empty'),
            action: e(
              'button',
              {
                type: 'button',
                className: 'dsh-sam-btn primary',
                onClick: handleOpenAdd,
              },
              t('mcpServers.actions.add'),
            ),
          })
        : e(
            'div',
            { className: 'dsh-mcp-server-list' },
            servers.map((server) =>
              e(McpServerCard, {
                key: server.id,
                server,
                isTesting: testingId === server.id,
                testResult: testResults[server.id],
                onTest: handleTest,
                onOpenTools: handleOpenTools,
                onOpenEdit: handleOpenEdit,
                onDelete: handleDelete,
                t,
              }),
            ),
          ),

    // Form Modal
    e(McpServerFormModal, {
      open: formOpen,
      isEditing,
      server: formServer,
      onChange: setFormServer,
      envEntries,
      onEnvChange: setEnvEntries,
      headerEntries,
      onHeaderChange: setHeaderEntries,
      saving: formSaving,
      testing: formTesting,
      error: formError,
      testResult: formTestResult,
      showAdvanced,
      onToggleAdvanced: () => setShowAdvanced((prev) => !prev),
      onTest: handleFormTest,
      onOpenTools: handleFormOpenTools,
      onClose: () => setFormOpen(false),
      onSave: handleSaveForm,
      t,
    }),

    // Tools Modal (also hosts the read-only resource and prompt tabs)
    e(McpToolsModal, {
      open: toolsModalOpen,
      server: toolsTargetServer,
      loading: discovery.loading,
      error: discovery.error || toolsSaveError,
      toolsList: discovery.tools,
      disabledToolsSet: toolsDisabledSet,
      serverInfo: discovery.serverInfo,
      detectedTransport: discovery.detectedTransport,
      saving: toolsSaving,
      activeTab: primitiveTab,
      onTabChange: setPrimitiveTab,
      tabCounts: {
        tools: discovery.tools.length,
        resources:
          discovery.lists.resources.length +
          discovery.lists.resourceTemplates.length,
        prompts: discovery.lists.prompts.length,
      },
      resourcePanel: e(McpResourcePanel, {
        resources: discovery.lists.resources,
        resourceTemplates: discovery.lists.resourceTemplates,
        capabilities: discovery.lists.capabilities,
        loading: discovery.loading,
        error: discovery.error,
        loaded: discovery.loaded,
        read: discovery.resourceRead,
        onRefresh: discovery.refresh,
        onRead: discovery.readResource,
        onCopy: handleCopyPrimitive,
        copiedKey,
        t,
      }),
      promptPanel: e(McpPromptPanel, {
        prompts: discovery.lists.prompts,
        capabilities: discovery.lists.capabilities,
        loading: discovery.loading,
        error: discovery.error,
        loaded: discovery.loaded,
        result: discovery.promptGet,
        onRefresh: discovery.refresh,
        onGet: discovery.getPrompt,
        onCopy: handleCopyPrimitive,
        copiedKey,
        t,
      }),
      onToggleTool: handleToggleTool,
      onToggleAllTools: handleToggleAllTools,
      onRefresh: discovery.refresh,
      onClose: () => setToolsModalOpen(false),
      onSave: handleSaveToolsModal,
      t,
    }),

    // Import Modal
    e(McpImportExportModal, {
      open: importOpen,
      text: importText,
      onChange: setImportText,
      importing,
      error: importError,
      onSubmit: handleImportSubmit,
      onClose: () => setImportOpen(false),
      t,
    }),

    // Save Confirmation Modal
    e(McpSaveConfirmModal, {
      confirmState: saveConfirm,
      onCancel: () => setSaveConfirm(null),
      onConfirm: handleConfirmSave,
      t,
    }),
  )
}

export default McpServersSettingsTab
