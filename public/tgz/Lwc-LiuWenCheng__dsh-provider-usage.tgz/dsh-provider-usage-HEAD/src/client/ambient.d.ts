declare module 'react' {
  const React: any
  export = React
}

/** Minimal surface of the cordis client context this plugin uses. */
interface ProviderUsageClientCtx {
  get(name: string): any
  on(name: string, listener: (...args: any[]) => void): () => void
  provide(name: string, value: unknown): () => void
  effect(callback: () => unknown, label?: string): () => void
  timeout(callback: () => void, delay: number): () => void
  interval(callback: () => void, delay: number): () => void
}
