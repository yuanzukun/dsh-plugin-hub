/**
 * dsh-provider-usage — client half (TypeScript, React via createElement).
 *
 * Compiled by tsc to CommonJS and wrapped by scripts/build.mjs into the
 * ModuleLoader bundle format the dsh web client runtime consumes; inside the
 * factory `require('react')` resolves through the runtime's module table.
 *
 * Registers:
 *  - a bottom-right usage bubble (`shell.overlay`): a minimal pill showing
 *    the worst usage percent, expanding into per-provider detail on hover.
 *    The pill and popover share one hover container so the pointer can travel
 *    between them; styling follows the app theme through `--dsw-alias-*`
 *    tokens; times are rendered in device-local time (resets as month+day).
 *  - a settings page (`settings.section`) to pick the update policy and its
 *    parameters (steps / interval).
 *
 * Update policies:
 *  - `on-request` (default): refresh when the user sends a request.
 *  - `steps`: refresh every N conversation steps.
 *  - `interval`: fixed interval.
 *  - `reset`: right after the earliest usage-window reset.
 *  - `hover`: only when viewed / refreshed manually.
 */
import React = require('react')

const plugin: {
  name: string
  inject: string[]
  apply(ctx: ProviderUsageClientCtx): void
} = {
  name: 'dsh-provider-usage',
  inject: ['timer'],
  apply(ctx) {
    const slots = ctx.get('slots')
    const locale = ctx.get('locale')
    if (slots === undefined) return

    let t = (key: string): string => key
    if (locale !== undefined) {
      try {
        const offZh = locale.register('provider-usage', 'zh', {
          bubbleTitle: '提供商用量', refresh: '刷新', loadFailed: '加载失败', error: '错误', raw: '原始',
          noProviders: '未配置提供商', noUsageData: '无用量数据', resets: '重置', stale: '上次数据（刷新失败）',
          usedUsd: '已用 (USD)', limitUsd: '限额 (USD)', softLimitUsd: '软限额 (USD)', grantedUsd: '赠送 (USD)',
          currency: '货币', totalBalance: '总余额', grantedBalance: '赠送余额', toppedUp: '充值', accessUntil: '有效期至', freeTier: '免费档',
          settingsTitle: '提供商用量', settingsDesc: '右下角用量小气泡与自动刷新策略。',
          policyLabel: '更新策略', policyHint: '决定小气泡何时自动获取最新用量（悬浮查看时总是会刷新）。',
          policyOnRequest: '用户发起请求时', policySteps: '每隔 N 步', policyInterval: '定时刷新', policyReset: '窗口重置时（智能）', policyHover: '仅查看时',
          stepsLabel: '步数间隔', stepsHint: '选择“每隔 N 步”时，每 N 个消息步（用户消息或模型回复）更新一次，范围 1–100。',
          intervalLabel: '刷新间隔（秒）', intervalHint: '选择“定时刷新”时的间隔，范围 10–3600。',
          saveHint: '更改立即生效。',
          w5h: '5h 用量', w7d: '7d 用量', w30d: '30d 用量',
          wRolling: '滚动', wWeekly: '本周', wMonthly: '本月', wUsage: '用量', wBilling: '计费',
        })
        const offEn = locale.register('provider-usage', 'en', {
          bubbleTitle: 'Provider usage', refresh: 'Refresh', loadFailed: 'Load failed', error: 'Error', raw: 'raw',
          noProviders: 'No providers configured', noUsageData: 'No usage data', resets: 'resets', stale: 'stale data (refresh failed)',
          usedUsd: 'used (USD)', limitUsd: 'limit (USD)', softLimitUsd: 'soft limit (USD)', grantedUsd: 'granted (USD)',
          currency: 'currency', totalBalance: 'total balance', grantedBalance: 'granted balance', toppedUp: 'topped-up', accessUntil: 'access until', freeTier: 'free tier',
          settingsTitle: 'Provider usage', settingsDesc: 'Usage bubble in the bottom-right corner and its refresh policy.',
          policyLabel: 'Update policy', policyHint: 'When the bubble fetches fresh usage automatically (hovering always refreshes).',
          policyOnRequest: 'On user request', policySteps: 'Every N steps', policyInterval: 'Fixed interval', policyReset: 'On window reset (smart)', policyHover: 'On view only',
          stepsLabel: 'Step interval', stepsHint: 'With “Every N steps”, refresh every N conversation steps (user message or model reply); range 1–100.',
          intervalLabel: 'Interval (seconds)', intervalHint: 'Used with “Fixed interval”; range 10–3600.',
          saveHint: 'Changes apply immediately.',
          w5h: '5h usage', w7d: '7d usage', w30d: '30d usage',
          wRolling: 'Rolling', wWeekly: 'Weekly', wMonthly: 'Monthly', wUsage: 'Usage', wBilling: 'Billing',
        })
        // Register synchronously (so t works immediately) but dispose the
        // registrations when this fiber unloads — otherwise a package update
        // re-registers the same (ns, locale) pair and the duplicate throws,
        // silently degrading t to raw keys (titles stop following the locale).
        ctx.effect(() => () => { offZh(); offEn() })
        t = locale.bind('provider-usage')
      } catch { t = (key: string): string => key }
    }

    const TOK = {
      bg: 'var(--dsw-alias-bg-base)',
      surface: 'var(--dsw-alias-bg-layer-1)',
      surface2: 'var(--dsw-alias-bg-layer-2)',
      overlay: 'var(--dsw-alias-bg-overlay)',
      border: 'var(--dsw-alias-border-l1)',
      text: 'var(--dsw-alias-label-primary)',
      text2: 'var(--dsw-alias-label-secondary)',
      brand: 'var(--dsw-alias-brand-primary)',
      error: 'var(--dsw-alias-state-error-primary)',
      ok: 'var(--dsw-alias-state-success-primary)',
      warn: 'var(--dsw-alias-state-warn-primary)',
    }

    const config: { policy: string; refreshSeconds: number; everySteps: number } = { policy: 'on-request', refreshSeconds: 60, everySteps: 1 }
    const listeners = new Set<() => void>()
    function setConfig(next: any): void {
      if (next && typeof next === 'object') {
        if (typeof next.policy === 'string') config.policy = next.policy
        if (typeof next.refreshSeconds === 'number') config.refreshSeconds = next.refreshSeconds
        if (typeof next.everySteps === 'number') config.everySteps = next.everySteps
      }
      listeners.forEach((fn) => fn())
    }
    function useConfig(): { policy: string; refreshSeconds: number; everySteps: number } {
      const [c, setC] = React.useState({ policy: config.policy, refreshSeconds: config.refreshSeconds, everySteps: config.everySteps })
      React.useEffect(() => {
        const fn = () => setC({ policy: config.policy, refreshSeconds: config.refreshSeconds, everySteps: config.everySteps })
        listeners.add(fn)
        return () => { listeners.delete(fn) }
      }, [])
      return c
    }
    function useLocaleTick(): void {
      const [, force] = React.useState(0)
      React.useEffect(() => {
        if (locale === undefined) return undefined
        return locale.subscribe(() => force((x: number) => x + 1))
      }, [])
    }
    function isZh(): boolean {
      try { return locale !== undefined && locale.getLocale().active === 'zh' } catch { return false }
    }
    function fetchJson(path: string, init?: RequestInit): Promise<any> {
      return fetch(path, init).then((r) => r.json()).catch((e) => ({ ok: false, error: String((e && e.message) || e) }))
    }
    function fetchUsage(): Promise<any> {
      return fetchJson('/provider-usage/query', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ force: true }),
      })
    }
    function fetchConfig(): Promise<any> {
      return fetchJson('/provider-usage/config', { method: 'GET' })
    }
    function saveConfig(patch: Record<string, unknown>): Promise<any> {
      return fetchJson('/provider-usage/config', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(patch),
      }).then((v) => { if (v && v.ok !== false) setConfig(v); return v })
    }
    function syncConfig(): void {
      fetchConfig().then((v) => { if (v && v.ok !== false) setConfig(v) })
    }

    function pad2(n: number): string { return String(n).padStart(2, '0') }
    function fmtLocal(iso: string): string {
      const d = new Date(iso)
      if (Number.isNaN(d.getTime())) return iso || ''
      return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`
    }
    function fmtMonthDay(iso: string): string {
      const d = new Date(iso)
      if (Number.isNaN(d.getTime())) return iso ? String(iso).slice(5, 10) : ''
      const m = d.getMonth() + 1
      const day = d.getDate()
      return isZh() ? `${m}月${day}日` : `${pad2(m)}-${pad2(day)}`
    }
    function fmtResetTime(iso: string): string {
      const d = new Date(iso)
      if (Number.isNaN(d.getTime())) return iso ? String(iso).slice(11, 16) : ''
      return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`
    }
    function fmtResetDayTime(iso: string): string {
      const d = new Date(iso)
      if (Number.isNaN(d.getTime())) return iso ? String(iso).slice(11, 16) : ''
      return `${pad2(d.getDate())} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`
    }
    function fmtReset(iso: string, fmt: string): string {
      if (fmt === 'time') return fmtResetTime(iso)
      if (fmt === 'daytime') return fmtResetDayTime(iso)
      return fmtMonthDay(iso)
    }

    // Per-window display profile: labels and reset-time formats. OpenCodeGo's
    // windows are named 5h / 7d / 30d with matching reset formats (HH:mm /
    // DD HH:mm / MM:DD); other providers keep the API labels and a month-day
    // reset format designed from what their endpoint returns.
    const WINDOW_PROFILES: Record<string, Record<string, { labelKey: string | null; reset: string }>> = {
      'opencode-go': {
        rolling: { labelKey: 'w5h', reset: 'time' },
        weekly: { labelKey: 'w7d', reset: 'daytime' },
        monthly: { labelKey: 'w30d', reset: 'monthday' },
      },
    }
    const DEFAULT_WINDOW_PROFILE: Record<string, { labelKey: string | null; reset: string }> = {
      rolling: { labelKey: 'wRolling', reset: 'monthday' },
      weekly: { labelKey: 'wWeekly', reset: 'monthday' },
      monthly: { labelKey: 'wMonthly', reset: 'monthday' },
      usage: { labelKey: 'wUsage', reset: 'daytime' },
      billing: { labelKey: 'wBilling', reset: 'monthday' },
    }
    function windowDisplay(route: string, label: string): { labelKey: string | null; reset: string } {
      const profile = WINDOW_PROFILES[route] || DEFAULT_WINDOW_PROFILE
      return profile[label] || { labelKey: null, reset: 'monthday' }
    }

    function worstPercent(report: any): number | null {
      let w: number | null = null
      if (report && report.ok !== false) {
        const providers = Array.isArray(report.providers) ? report.providers : []
        for (const p of providers) {
          if (p && p.ok === false) continue
          const windows = Array.isArray(p.windows) ? p.windows : []
          for (const win of windows) {
            if (win && typeof win.percent === 'number' && (w === null || win.percent > w)) w = win.percent
          }
        }
      }
      return w
    }
    function windowLabel(label: string): string {
      const map: Record<string, string> = { rolling: 'wRolling', weekly: 'wWeekly', monthly: 'wMonthly', usage: 'wUsage', billing: 'wBilling' }
      const k = map[label]
      return k ? t(k) : (label || '')
    }
    function valueLabel(vv: any): string {
      if (vv && typeof vv.labelKey === 'string' && vv.labelKey) return t(vv.labelKey)
      return (vv && vv.label) || ''
    }
    function statusColor(percent: number | null): string {
      if (percent === null) return TOK.text2
      return percent >= 90 ? TOK.error : percent >= 60 ? TOK.warn : TOK.ok
    }
    function earliestResetTs(report: any): number | null {
      let next: number | null = null
      const now = Date.now()
      const providers = report && Array.isArray(report.providers) ? report.providers : []
      for (const p of providers) {
        const windows = Array.isArray(p.windows) ? p.windows : []
        for (const win of windows) {
          if (win && typeof win.resetsAt === 'string' && win.resetsAt) {
            const ts = Date.parse(win.resetsAt)
            if (Number.isFinite(ts) && ts > now && (next === null || ts < next)) next = ts
          }
        }
      }
      return next
    }
    function nextRefreshDelay(report: any, c: { policy: string; refreshSeconds: number }): number | null {
      if (c.policy !== 'interval' && c.policy !== 'reset') return null
      if (c.policy === 'interval') return c.refreshSeconds * 1000
      if (!report || report.ok === false) return 300000
      const next = earliestResetTs(report)
      return next !== null ? Math.max(5000, next - Date.now()) : 300000
    }

    function Bubble(): any {
      const c = useConfig()
      useLocaleTick()
      const [report, setReport] = React.useState(null)
      const [loading, setLoading] = React.useState(false)
      const [lastError, setLastError] = React.useState(null)
      const [hover, setHover] = React.useState(false)
      const [tick, setTick] = React.useState(0)
      const lastSeenRef = React.useRef(null)

      React.useEffect(() => { syncConfig() }, [])

      // Async refresh: keep the previous report visible until the new one
      // arrives; only a failure marks the state red (old content is kept).
      React.useEffect(() => {
        let alive = true
        setLoading(true)
        fetchUsage().then((v) => {
          if (!alive) return
          setLoading(false)
          if (v && v.ok === false) {
            setLastError(v.error || t('loadFailed'))
          } else {
            setReport(v)
            setLastError(v && v.error ? v.error : null)
          }
        })
        return () => { alive = false }
      }, [tick])

      // activity policies: poll the host counters cheaply and refresh when due
      React.useEffect(() => {
        if (c.policy !== 'on-request' && c.policy !== 'steps') { lastSeenRef.current = null; return undefined }
        return ctx.interval(() => {
          fetchJson('/provider-usage/activity', { method: 'GET' }).then((a) => {
            if (!a || typeof a !== 'object') return
            const ls = lastSeenRef.current
            const cur = { steps: a.steps || 0, userRequests: a.userRequests || 0 }
            if (ls === null) { lastSeenRef.current = cur; return }
            let due = false
            if (c.policy === 'on-request') due = cur.userRequests > ls.userRequests
            else due = cur.steps - ls.steps >= c.everySteps
            lastSeenRef.current = cur
            if (due) setTick((x: number) => x + 1)
          })
        }, 1500)
      }, [c.policy, c.everySteps])

      // interval / reset policies: one-shot scheduling after each fetch
      React.useEffect(() => {
        if (c.policy !== 'interval' && c.policy !== 'reset') return undefined
        if (loading) return undefined
        const delay = nextRefreshDelay(report, c)
        if (delay === null) return undefined
        return ctx.timeout(() => setTick((x: number) => x + 1), delay)
      }, [report, c.policy, c.refreshSeconds, loading])

      const worst = worstPercent(report)
      const err = lastError !== null
      // Color by usage percentage (green/amber/red); abnormal (refresh failed)
      // overrides to red while the previous content stays visible.
      const color = err ? TOK.error : statusColor(worst)

      const containerStyle = {
        position: 'fixed', right: 16, bottom: 16, zIndex: 2147483000,
        display: 'flex', flexDirection: 'column', alignItems: 'flex-end',
        pointerEvents: 'auto', maxWidth: 'calc(100vw - 32px)',
      }
      const pillStyle = {
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
        minWidth: 76, padding: '4px 12px', borderRadius: 999,
        background: TOK.surface, border: `1px solid ${TOK.border}`,
        cursor: 'pointer', fontSize: 12, fontWeight: 600, color,
        boxShadow: '0 2px 10px rgba(0,0,0,0.22)', userSelect: 'none', whiteSpace: 'nowrap',
      }
      const dotStyle = {
        width: 7, height: 7, borderRadius: '50%', background: color, flex: 'none',
        animation: loading ? 'providerUsagePulse 1s ease-in-out infinite' : undefined,
      }
      const popoverStyle = {
        width: 320, maxWidth: 'calc(100vw - 32px)', maxHeight: 'min(70vh, 480px)',
        overflowY: 'auto', background: TOK.overlay, color: TOK.text,
        border: `1px solid ${TOK.border}`, borderRadius: 10, padding: 10,
        boxShadow: '0 8px 28px rgba(0,0,0,0.32)', fontSize: 12, lineHeight: 1.5,
        textAlign: 'left', marginBottom: 8,
      }
      const barOuter = { width: 120, height: 8, borderRadius: 4, background: TOK.surface2, overflow: 'hidden', flex: 'none' }
      const barInner = (pct: number) => ({ width: `${Math.max(0, Math.min(100, pct))}%`, height: '100%', background: statusColor(pct) })
      const btnStyle = { fontSize: 11, padding: '2px 10px', cursor: 'pointer', borderRadius: 6, border: `1px solid ${TOK.border}`, background: 'transparent', color: TOK.text }
      const subStyle = { fontSize: 11, color: TOK.text2 }

      const popoverChildren: any[] = []
      const providers = report && Array.isArray(report.providers) ? report.providers : []
      if (providers.length === 0) {
        popoverChildren.push(React.createElement('div', { key: 'empty', style: subStyle }, err ? (report.error || t('loadFailed')) : t('noProviders')))
      } else {
        providers.forEach((p: any) => {
          const children: any[] = []
          const title = (p.displayName || p.route) + (p.route ? ` · ${p.route}` : '')
          if (p.ok === false || p.error) {
            children.push(React.createElement('div', { key: 'err', style: { color: TOK.error } }, `${t('error')}: ${p.error}`))
          } else {
            const windows = Array.isArray(p.windows) ? p.windows : []
            windows.forEach((w: any) => {
              const pct = typeof w.percent === 'number' ? w.percent : 0
              const disp = windowDisplay(p.route, w.label)
              const label = disp.labelKey ? t(disp.labelKey) : windowLabel(w.label)
              const sub = w.resetsAt ? fmtReset(w.resetsAt, disp.reset) : (w.status || '')
              children.push(React.createElement('div', { key: w.label, style: { display: 'flex', alignItems: 'center', gap: 8, margin: '3px 0' } },
                React.createElement('span', { style: { width: 64, flex: 'none', color: TOK.text2 } }, label),
                React.createElement('div', { style: barOuter }, React.createElement('div', { style: barInner(pct) })),
                React.createElement('span', { style: { width: 40, flex: 'none', textAlign: 'right', fontWeight: 600 } }, `${typeof w.percent === 'number' ? w.percent : '?'}%`),
                React.createElement('span', { style: subStyle }, sub)
              ))
            })
            const values = Array.isArray(p.values) ? p.values : []
            values.forEach((vv: any) => {
              children.push(React.createElement('div', { key: vv.labelKey || vv.label, style: { display: 'flex', gap: 8, margin: '1px 0' } },
                React.createElement('span', { style: { width: 140, flex: 'none', color: TOK.text2 } }, valueLabel(vv)),
                React.createElement('span', null, vv.value)
              ))
            })
            if (typeof p.raw === 'string' && p.raw) children.push(React.createElement('div', { key: 'raw', style: { fontSize: 11, color: TOK.text2, wordBreak: 'break-all', marginTop: 2 } }, `${t('raw')}: ${p.raw}`))
            if (windows.length === 0 && values.length === 0 && !p.raw) children.push(React.createElement('div', { key: 'none', style: subStyle }, t('noUsageData')))
          }
          popoverChildren.push(React.createElement('div', { key: p.route, style: { borderBottom: `1px solid ${TOK.border}`, padding: '5px 0' } },
            React.createElement('div', { style: { fontWeight: 600, marginBottom: 2 } }, title),
            ...children
          ))
        })
      }

      return React.createElement('div', {
        style: containerStyle,
        onMouseEnter: () => { setHover(true); setTick((x: number) => x + 1) },
        onMouseLeave: () => { setHover(false) },
      },
        hover ? React.createElement('div', { style: popoverStyle },
          React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 } },
            React.createElement('span', { style: { fontWeight: 700 } }, t('bubbleTitle')),
            React.createElement('button', { style: btnStyle, onClick: () => setTick((x: number) => x + 1) }, t('refresh'))
          ),
          err ? React.createElement('div', { key: 'errbar', style: { color: TOK.error, marginBottom: 6 } },
            `${t('stale')}${lastError ? `: ${lastError}` : ''}`
          ) : null,
          ...popoverChildren
        ) : null,
        React.createElement('div', { style: pillStyle, title: t('bubbleTitle') },
          React.createElement('div', { style: dotStyle }),
          React.createElement('span', null, loading && !report ? '…' : err && !report ? '!' : (worst !== null ? `${worst}%` : '—'))
        )
      )
    }

    function SettingsPage(): any {
      const c = useConfig()
      useLocaleTick()
      const [policy, setPolicy] = React.useState(c.policy)
      const [seconds, setSeconds] = React.useState(String(c.refreshSeconds))
      const [steps, setSteps] = React.useState(String(c.everySteps))
      React.useEffect(() => { syncConfig() }, [])
      React.useEffect(() => {
        setPolicy(c.policy)
        setSeconds(String(c.refreshSeconds))
        setSteps(String(c.everySteps))
      }, [c.policy, c.refreshSeconds, c.everySteps])

      const rowStyle = { display: 'flex', alignItems: 'center', gap: 12, margin: '10px 0' }
      const labelStyle = { width: 180, flex: 'none', fontWeight: 600 }
      const selectStyle = { padding: '4px 8px', borderRadius: 6, border: `1px solid ${TOK.border}`, background: 'transparent', color: 'inherit' }
      const inputStyle = { width: 120, padding: '4px 8px', borderRadius: 6, border: `1px solid ${TOK.border}`, background: 'transparent', color: 'inherit' }
      const hintStyle = { color: TOK.text2, fontSize: 12 }

      return React.createElement('div', { style: { padding: '4px 2px', maxWidth: 560 } },
        React.createElement('h3', { style: { margin: '0 0 4px' } }, t('settingsTitle')),
        React.createElement('p', { style: hintStyle }, t('settingsDesc')),
        React.createElement('div', { style: rowStyle },
          React.createElement('span', { style: labelStyle }, t('policyLabel')),
          React.createElement('select', {
            value: policy, style: selectStyle,
            onChange: (ev: any) => { const v = ev.target.value; setPolicy(v); saveConfig({ policy: v }) },
          },
            React.createElement('option', { value: 'on-request' }, t('policyOnRequest')),
            React.createElement('option', { value: 'steps' }, t('policySteps')),
            React.createElement('option', { value: 'interval' }, t('policyInterval')),
            React.createElement('option', { value: 'reset' }, t('policyReset')),
            React.createElement('option', { value: 'hover' }, t('policyHover'))
          )
        ),
        policy === 'steps' ? React.createElement('div', { style: rowStyle },
          React.createElement('span', { style: labelStyle }, t('stepsLabel')),
          React.createElement('input', {
            type: 'number', min: 1, max: 100, value: steps, style: inputStyle,
            onChange: (ev: any) => {
              const raw = ev.target.value
              setSteps(raw)
              const n = Number(raw)
              if (Number.isFinite(n) && n >= 1 && n <= 100) saveConfig({ everySteps: Math.round(n) })
            },
          })
        ) : null,
        policy === 'interval' ? React.createElement('div', { style: rowStyle },
          React.createElement('span', { style: labelStyle }, t('intervalLabel')),
          React.createElement('input', {
            type: 'number', min: 10, max: 3600, value: seconds, style: inputStyle,
            onChange: (ev: any) => {
              const raw = ev.target.value
              setSeconds(raw)
              const n = Number(raw)
              if (Number.isFinite(n) && n >= 10 && n <= 3600) saveConfig({ refreshSeconds: Math.round(n) })
            },
          })
        ) : null,
        React.createElement('div', { style: hintStyle }, t('policyHint')),
        policy === 'steps' ? React.createElement('div', { style: hintStyle }, t('stepsHint')) : null,
        policy === 'interval' ? React.createElement('div', { style: hintStyle }, t('intervalHint')) : null,
        React.createElement('div', { style: hintStyle }, t('saveHint'))
      )
    }

    slots.inject('shell.overlay', () => slots.register(
      { name: 'shell.overlay', id: 'provider-usage-bubble', order: 200, label: () => t('bubbleTitle') },
      () => React.createElement(Bubble, null)
    ))
    slots.inject('settings.section', () => slots.register(
      { name: 'settings.section', id: 'provider-usage', order: 30, label: () => t('settingsTitle') },
      () => React.createElement(SettingsPage, null)
    ))
  },
}

export = plugin
