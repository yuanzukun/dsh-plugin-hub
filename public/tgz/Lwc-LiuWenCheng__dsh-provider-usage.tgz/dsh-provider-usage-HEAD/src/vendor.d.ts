/**
 * Ambient module stubs so the plugin type-checks and builds without the full
 * peer-dependency tree installed (a bare `tsc` run in CI/offline). In a full
 * dev install the real package types take over at the runtime boundary; the
 * plugin only exercises a tiny surface of each dependency anyway.
 */
declare module '@deepseek-ai/schemastery' {
  const z: any
  export = z
}

declare module '@deepseek-ai/dsh-tools' {
  export function defineTool(options: any): any
}

declare module '@deepseek-ai/cordis' {
  const cordis: any
  export = cordis
}

/** Minimal Node globals used by the host (stubbed for bare tsc runs). */
declare const Buffer: any
