/**
 * dsh-provider-usage — host half (TypeScript).
 *
 * A cordis plugin row (`cordis.patch.yml`) that:
 *  - serves JSON routes for the browser client:
 *      POST /provider-usage/query     → `{ ok, fetchedAt, providers }`
 *      GET  /provider-usage/config    → current update policy
 *      POST /provider-usage/config    → merge a policy change
 *      GET  /provider-usage/activity  → conversation step counters
 *  - counts conversation activity from the `session/event` feed so the
 *    client can implement the "on user request" / "every N steps" policies
 *    without polling the provider APIs;
 *  - registers the `provider_usage` model tool.
 *
 * The usage engine itself lives in ./usage-core.ts.
 */
import z from '@deepseek-ai/schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { refreshUsage } from './usage-core.js'

/* eslint-disable @typescript-eslint/no-explicit-any */

/** Plugin identity for cordis.yml rows. */
export const name = 'dsh-provider-usage'

/** Services required before mounting. */
export const inject = ['webServer', 'tools']

/** Composition-level configuration with defaults (see README). */
export const Config = z.object({
  updatePolicy: z.union(['on-request', 'steps', 'interval', 'reset', 'hover']).default('on-request'),
  updateIntervalSeconds: z.number().step(1).min(10).max(3600).default(60),
  updateEverySteps: z.number().step(1).min(1).max(100).default(1),
})

/** In-memory override of the composition config (updated via the web route). */
const runtimeConfig: { policy: string | null; refreshSeconds: number | null; everySteps: number | null } = {
  policy: null,
  refreshSeconds: null,
  everySteps: null,
}

function effectiveConfig(config: any) {
  return {
    policy: runtimeConfig.policy ?? config.updatePolicy,
    refreshSeconds: runtimeConfig.refreshSeconds ?? config.updateIntervalSeconds,
    everySteps: runtimeConfig.everySteps ?? config.updateEverySteps,
  }
}

function writeJson(res: any, status: number, payload: unknown): void {
  const body = JSON.stringify(payload)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'content-length': Buffer.byteLength(body),
  })
  res.end(body)
}

function readJsonBody(req: any): Promise<any> {
  return new Promise((resolve) => {
    const chunks: any[] = []
    req.on('data', (chunk: any) => { chunks.push(chunk) })
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8')
      if (raw.length === 0) { resolve({}); return }
      try { resolve(JSON.parse(raw)) } catch { resolve(null) }
    })
    req.on('error', () => resolve(null))
  })
}

export function apply(ctx: any, config: any = {}): void {
  // Conversation activity counters for the "on user request" / "every N steps"
  // policies. A step = one conversation message (user or assistant).
  const activity = { steps: 0, userRequests: 0 }
  try {
    ctx.on('session/event', (session: any, event: any) => {
      if (event && typeof event.type === 'string') {
        if (event.type === 'user/message' || event.type === 'assistant/message') activity.steps += 1
        if (event.type === 'user/message') activity.userRequests += 1
      }
    })
  } catch { /* session/event unavailable; activity policies degrade to no-op */ }

  // Per-provider model call counts (every streaming model call, by provider).
  const callCounts: Record<string, number> = {}
  try {
    ctx.on('llm/stream', (options: any, next: () => unknown) => {
      const p = options && options.provider
      if (typeof p === 'string' && p) callCounts[p] = (callCounts[p] || 0) + 1
      return next()
    })
  } catch { /* llm/stream unavailable; call counts stay zero */ }

  // Global per-provider cache shared by every session: one fetch serves all
  // clients; concurrent requests share the in-flight batch; a cooldown
  // prevents endless re-fetches when several sessions trigger at once.
  const MIN_REFRESH_GAP_MS = 5000
  const cache: { report: any | null } = { report: null }
  let lastBatchFetchAt = 0
  let batchPromise: Promise<any> | null = null

  function countsArray() {
    return Object.keys(callCounts).map((route) => ({ route, calls: callCounts[route] }))
  }

  async function queryUsage(signal: AbortSignal | undefined, force: boolean): Promise<any> {
    const now = Date.now()
    const wantFetch = force ? now - lastBatchFetchAt >= MIN_REFRESH_GAP_MS : cache.report === null
    if (wantFetch) {
      if (batchPromise === null) {
        batchPromise = refreshUsage(ctx, signal).then((r: any) => {
          batchPromise = null
          if (r.ok) {
            r.providers = (r.providers || []).map((p: any) => ({ ...p, calls: callCounts[p.route] || 0 }))
            cache.report = r
            lastBatchFetchAt = Date.now()
          }
          return r
        }, (e: any) => {
          batchPromise = null
          throw e
        })
      }
      let result: any = null
      try { result = await batchPromise } catch (e: any) { result = { ok: false, error: String((e && e.message) || e) } }
      if (result.ok) {
        return { ok: true, fresh: true, fetchedAt: result.fetchedAt, providers: result.providers, callCounts: countsArray() }
      }
      if (cache.report) {
        return { ok: true, error: result.error || 'refresh failed', fresh: false, fetchedAt: cache.report.fetchedAt, providers: cache.report.providers, callCounts: countsArray() }
      }
      return { ok: false, error: result.error || 'fetch failed', providers: [] }
    }
    if (cache.report) {
      return { ok: true, fresh: false, fetchedAt: cache.report.fetchedAt, providers: cache.report.providers, callCounts: countsArray() }
    }
    return { ok: false, error: 'no data yet', providers: [] }
  }

  // Usage query route.
  ctx.webServer.register({
    kind: 'exact',
    path: '/provider-usage/query',
    handler: async (req: any, res: any) => {
      if (req.method !== 'POST') { writeJson(res, 405, { ok: false, error: 'method not allowed' }); return }
      try {
        const body = await readJsonBody(req)
        writeJson(res, 200, await queryUsage(undefined, !!(body && body.force)))
      } catch (e: any) {
        writeJson(res, 500, { ok: false, error: `usage query failed: ${String((e && e.message) || e)}` })
      }
    },
  })

  // Config route (GET reads, POST merges a patch).
  ctx.webServer.register({
    kind: 'exact',
    path: '/provider-usage/config',
    handler: async (req: any, res: any) => {
      try {
        if (req.method === 'GET' || req.method === 'HEAD') {
          writeJson(res, 200, effectiveConfig(config))
          return
        }
        if (req.method !== 'POST') { writeJson(res, 405, { ok: false, error: 'method not allowed' }); return }
        const patch = await readJsonBody(req)
        if (patch === null || typeof patch !== 'object') {
          writeJson(res, 400, { ok: false, error: 'invalid json body' })
          return
        }
        if (typeof patch.policy === 'string' && ['on-request', 'steps', 'interval', 'reset', 'hover'].includes(patch.policy)) {
          runtimeConfig.policy = patch.policy
        }
        if (typeof patch.refreshSeconds === 'number' && Number.isFinite(patch.refreshSeconds)) {
          runtimeConfig.refreshSeconds = Math.min(3600, Math.max(10, Math.round(patch.refreshSeconds)))
        }
        if (typeof patch.everySteps === 'number' && Number.isFinite(patch.everySteps)) {
          runtimeConfig.everySteps = Math.min(100, Math.max(1, Math.round(patch.everySteps)))
        }
        writeJson(res, 200, effectiveConfig(config))
      } catch (e: any) {
        writeJson(res, 500, { ok: false, error: `config update failed: ${String((e && e.message) || e)}` })
      }
    },
  })

  // Activity counters route (cheap local read).
  ctx.webServer.register({
    kind: 'exact',
    path: '/provider-usage/activity',
    handler: async (req: any, res: any) => {
      try {
        writeJson(res, 200, { steps: activity.steps, userRequests: activity.userRequests })
      } catch (e: any) {
        writeJson(res, 500, { ok: false, error: String((e && e.message) || e) })
      }
    },
  })

  // Model tool: usage questions in conversation.
  const tool = defineTool({
    name: 'provider_usage',
    description: 'Query the current usage/quota of every configured LLM model provider (from the llm-pi-ai / llm-deepseek settings): OpenCodeGo rolling/weekly/monthly percent usage with reset times, OpenRouter usage/limit, OpenAI billing usage, DeepSeek balance, and a generic probe fallback for other providers. Returns one entry per provider. Call it whenever the user asks about provider usage, quota, remaining balance, or consumption.',
    parameters: {},
    output: {
      schema: { type: 'object', properties: {}, additionalProperties: true },
      render(args: unknown, value: any) {
        const v = value || {}
        const lines: string[] = []
        if (v.ok === false) {
          lines.push(`Provider usage query failed: ${v.error || 'unknown'}`)
          return [{ type: 'text', text: lines.join('\n') }]
        }
        lines.push(`Model provider usage · fetched ${typeof v.fetchedAt === 'string' ? v.fetchedAt.replace('T', ' ').slice(0, 19) : 'unknown'}`)
        const providers = Array.isArray(v.providers) ? v.providers : []
        if (providers.length === 0) lines.push('No configured providers found (llm-pi-ai / llm-deepseek settings).')
        for (const p of providers) {
          const title = `${p.displayName || p.route} (${p.route || '?'})`
          if (p.ok === false || p.error) {
            lines.push(`• ${title} — error: ${p.error}`)
            continue
          }
          lines.push(`• ${title}`)
          const windows = Array.isArray(p.windows) ? p.windows : []
          for (const w of windows) {
            let s = `  - ${w.label}: ${typeof w.percent === 'number' ? w.percent : '?'}%`
            if (typeof w.resetsAt === 'string' && w.resetsAt) s += ` (resets ${w.resetsAt.replace('T', ' ').slice(0, 16)})`
            if (typeof w.status === 'string' && w.status) s += ` [${w.status}]`
            lines.push(s)
          }
          const values = Array.isArray(p.values) ? p.values : []
          for (const vv of values) lines.push(`  - ${vv.label}: ${vv.value}`)
          if (typeof p.raw === 'string' && p.raw) lines.push(`  - raw: ${p.raw}`)
          if (windows.length === 0 && values.length === 0 && !p.raw) lines.push('  - no usage data returned')
        }
        return [{ type: 'text', text: lines.join('\n') }]
      },
    },
    timeoutMs: 60000,
    execute: async (args: unknown, exec: any) => queryUsage(exec.signal, true),
  })
  ctx.tools.register(tool)
}
