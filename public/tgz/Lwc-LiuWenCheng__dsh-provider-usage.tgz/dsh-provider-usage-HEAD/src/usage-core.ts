/**
 * dsh-provider-usage — host fetch core (TypeScript).
 *
 * Enumerates configured providers from the `llm-pi-ai` / `llm-deepseek`
 * settings namespaces, resolves each API key through the credentials service,
 * then runs one `node -e` helper (spawned through the mounted shell executor,
 * confined under the calling session's sandbox policy) that fetches each
 * provider's usage endpoint. Responses are normalized into a portable report
 * (percent windows + numeric values).
 *
 * The node helper is deliberately single-quoted only and receives its plan
 * through an environment variable: the pwsh-local executor passes the whole
 * command string as ONE argv element to `pwsh -Command`, so double quotes in
 * an embedded script would be mangled by PowerShell's parser.
 */

/* eslint-disable @typescript-eslint/no-explicit-any */

export interface Candidate { path: string; probe?: boolean }
export interface PlanEntry {
  route: string
  displayName: string
  apiKeyEnv: string
  base: string
  candidates: Candidate[]
  probe: boolean
}
export interface PlanError { route: string; displayName: string; ok: false; error: string }
export interface UsageWindow {
  label: string
  percent: number | null
  resetsAt: string | null
  status: string | null
}
export interface UsageValue { labelKey?: string; label: string; value: string }
export interface ProviderReport {
  route: string
  displayName: string
  ok: boolean
  error: string | null
  windows: UsageWindow[]
  values: UsageValue[]
  raw: string | null
}
export interface UsageReport {
  ok: boolean
  error?: string
  fetchedAt?: string
  providers: ProviderReport[]
}

const KNOWN: Record<string, { base: string; name: string; candidates: Candidate[] | null }> = {
  'opencode-go': { base: 'https://opencode.ai/zen/go/v1', name: 'OpenCodeGo', candidates: [{ path: '/usage', probe: true }] },
  'openrouter': { base: 'https://openrouter.ai/api/v1', name: 'OpenRouter', candidates: [{ path: '/auth/key', probe: true }] },
  'openai': { base: 'https://api.openai.com/v1', name: 'OpenAI', candidates: null },
  'deepseek': { base: 'https://api.deepseek.com', name: 'DeepSeek', candidates: [{ path: '/user/balance', probe: true }] },
}

const GENERIC_CANDIDATES: Candidate[] = [
  { path: '/usage', probe: true },
  { path: '/user/balance', probe: true },
  { path: '/dashboard/billing/subscription', probe: true },
]

function ymd(d: Date): string {
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${d.getFullYear()}-${m}-${day}`
}

function openaiCandidates(): Candidate[] {
  const now = new Date()
  const start = new Date(now.getFullYear(), now.getMonth(), 1)
  return [
    { path: '/dashboard/billing/subscription' },
    { path: `/dashboard/billing/usage?start_date=${ymd(start)}&end_date=${ymd(now)}` },
  ]
}

function scrub(text: string | null, key: string | null): string | null {
  if (typeof text !== 'string' || text.length === 0 || !key) return text
  return text.split(key).join('***')
}

function parseJson(body: string): any {
  if (typeof body !== 'string') return null
  const t = body.trim()
  if (t.length === 0 || (t[0] !== '{' && t[0] !== '[')) return null
  try { return JSON.parse(t) } catch { return null }
}

/**
 * The `node -e` helper. Single quotes only; no backticks, no `${`, no double
 * quotes — it is embedded into `node -e "<script>"` and reparsed by
 * PowerShell. Reads the plan from USAGE_PLAN_JSON and prints one JSON object
 * to stdout.
 */
export const FETCH_SCRIPT = `(function () {
  var plan;
  try { plan = JSON.parse(process.env.USAGE_PLAN_JSON || '{}'); } catch (e) { console.log(JSON.stringify({ ok: false, error: 'bad plan: ' + e.message })); return; }
  var groups = Array.isArray(plan.groups) ? plan.groups : [];
  function fetchOne(g, c) {
    var ctrl = new AbortController();
    var t = setTimeout(function () { ctrl.abort(); }, 12000);
    return fetch(g.base + c.path, {
      headers: { authorization: 'Bearer ' + g.key, accept: 'application/json' },
      signal: ctrl.signal
    }).then(function (res) {
      clearTimeout(t);
      return res.text().then(function (text) {
        return { name: g.name, path: c.path, status: res.status, contentType: res.headers.get('content-type') || '', body: text.slice(0, 100000) };
      });
    }).catch(function (e) {
      clearTimeout(t);
      return { name: g.name, path: c.path, error: String((e && e.message) || e) };
    });
  }
  function fetchGroup(g) {
    var candidates = Array.isArray(g.candidates) && g.candidates.length > 0 ? g.candidates : [{ path: '/' }];
    if (g.probe) {
      var found = [];
      var last = null;
      var step = function (i) {
        if (found.length > 0 || i >= candidates.length) return Promise.resolve();
        return fetchOne(g, candidates[i]).then(function (r) {
          last = r;
          if (!r.error && r.status >= 200 && r.status < 300) { found.push(r); return; }
          return step(i + 1);
        });
      };
      return step(0).then(function () {
        if (found.length > 0) return found;
        return last ? [last] : [{ name: g.name, error: 'no response' }];
      });
    }
    return Promise.all(candidates.map(function (c) { return fetchOne(g, c); }));
  }
  Promise.all(groups.map(fetchGroup)).then(function (all) {
    var flat = [];
    all.forEach(function (arr) { arr.forEach(function (r) { flat.push(r); }); });
    console.log(JSON.stringify({ ok: true, results: flat }));
  }).catch(function (e) {
    console.log(JSON.stringify({ ok: false, error: String((e && e.message) || e) }));
  });
})();`

export function userLayerConfigured(settings: any, ns: string): boolean {
  if (settings === undefined) return false
  try {
    const descs = settings.describe()
    if (!Array.isArray(descs)) return false
    const found = descs.find((d: any) => d && d.ns === ns)
    return !!(found && found.user && typeof found.user === 'object' && Object.keys(found.user).length > 0)
  } catch {
    return false
  }
}

export function buildPlan(settings: any): { entries: PlanEntry[]; errors: PlanError[] } {
  const entries: PlanEntry[] = []
  const errors: PlanError[] = []
  let ns: any = null
  try { ns = settings ? settings.get('llm-pi-ai') : null } catch { ns = null }
  const providers = (ns && typeof ns === 'object' && ns.providers && typeof ns.providers === 'object') ? ns.providers : {}
  for (const route of Object.keys(providers)) {
    const entry = (providers[route] && typeof providers[route] === 'object') ? providers[route] : {}
    const known = KNOWN[route]
    const displayName = (typeof entry.displayName === 'string' && entry.displayName.length > 0) ? entry.displayName : (known ? known.name : route)
    const apiKeyEnv = (typeof entry.apiKeyEnv === 'string' && entry.apiKeyEnv.length > 0) ? entry.apiKeyEnv : null
    if (!apiKeyEnv) { errors.push({ route, displayName, ok: false, error: 'provider entry has no apiKeyEnv' }); continue }
    const base = (typeof entry.baseURL === 'string' && entry.baseURL.length > 0) ? entry.baseURL : (known ? known.base : null)
    if (!base) { errors.push({ route, displayName, ok: false, error: `no base URL for provider "${route}" (set baseURL in llm-pi-ai settings)` }); continue }
    const candidates = known ? (known.candidates || openaiCandidates()) : GENERIC_CANDIDATES
    entries.push({ route, displayName, apiKeyEnv, base, candidates, probe: true })
  }
  if (userLayerConfigured(settings, 'llm-deepseek')) {
    let ns2: any = null
    try { ns2 = settings.get('llm-deepseek') } catch { ns2 = null }
    if (ns2 && typeof ns2 === 'object') {
      const apiKeyEnv = (typeof ns2.apiKeyEnv === 'string' && ns2.apiKeyEnv.length > 0) ? ns2.apiKeyEnv : 'DEEPSEEK_API_KEY'
      const base = (typeof ns2.baseURL === 'string' && ns2.baseURL.length > 0) ? ns2.baseURL : 'https://api.deepseek.com'
      entries.push({ route: 'deepseek-official', displayName: 'DeepSeek', apiKeyEnv, base, candidates: [{ path: '/user/balance', probe: true }], probe: true })
    }
  }
  return { entries, errors }
}

export function normalizeUsage(results: any[], key: string | null): Omit<ProviderReport, 'route' | 'displayName'> {
  const out: Omit<ProviderReport, 'route' | 'displayName'> = { ok: true, windows: [], values: [], raw: null, error: null }
  const okResults = results.filter((r: any) => r && !r.error && r.status >= 200 && r.status < 300)
  if (okResults.length === 0) {
    const last = results[results.length - 1]
    if (last && last.error) return { ok: false, error: scrub(last.error, key), windows: [], values: [], raw: null }
    if (last) return { ok: false, error: `HTTP ${last.status}`, windows: [], values: [], raw: null }
    return { ok: false, error: 'no response', windows: [], values: [], raw: null }
  }
  let used: number | null = null
  let limit: number | null = null
  let granted: number | null = null
  for (const r of okResults) {
    const body = parseJson(r.body)
    if (!body) continue
    if (typeof body.total_usage === 'number') used = body.total_usage / 100
    if (typeof body.total_granted === 'number') granted = body.total_granted / 100
    if (body.usage && typeof body.usage === 'object' && !Array.isArray(body.usage)) {
      for (const label of ['rolling', 'weekly', 'monthly']) {
        const w = body.usage[label]
        if (w && typeof w === 'object' && typeof w.percent === 'number') {
          out.windows.push({ label, percent: w.percent, resetsAt: typeof w.resetsAt === 'string' ? w.resetsAt : null, status: typeof w.status === 'string' ? w.status : null })
        }
      }
      continue
    }
    if (body.data && typeof body.data === 'object' && typeof body.data.usage_ratio === 'number') {
      out.windows.push({ label: 'usage', percent: Math.round(body.data.usage_ratio * 1000) / 10, resetsAt: null, status: null })
      if (typeof body.data.usage === 'number') out.values.push({ labelKey: 'usedUsd', label: 'used (USD)', value: `$${body.data.usage}` })
      if (typeof body.data.limit === 'number') out.values.push({ labelKey: 'limitUsd', label: 'limit (USD)', value: `$${body.data.limit}` })
      if (typeof body.data.is_free_tier === 'boolean') out.values.push({ labelKey: 'freeTier', label: 'free tier', value: String(body.data.is_free_tier) })
      continue
    }
    if (typeof body.hard_limit_usd === 'number') {
      limit = body.hard_limit_usd
      if (typeof body.soft_limit_usd === 'number') out.values.push({ labelKey: 'softLimitUsd', label: 'soft limit (USD)', value: `$${body.soft_limit_usd}` })
      if (body.access_until !== undefined && body.access_until !== null) out.values.push({ labelKey: 'accessUntil', label: 'access until', value: String(body.access_until) })
      continue
    }
    if (Array.isArray(body.balance_infos) && body.balance_infos.length > 0) {
      const bi = body.balance_infos[0]
      if (bi && typeof bi === 'object') {
        if (bi.currency !== undefined) out.values.push({ labelKey: 'currency', label: 'currency', value: String(bi.currency) })
        if (bi.total_balance !== undefined) out.values.push({ labelKey: 'totalBalance', label: 'total balance', value: String(bi.total_balance) })
        if (bi.granted_balance !== undefined) out.values.push({ labelKey: 'grantedBalance', label: 'granted balance', value: String(bi.granted_balance) })
        if (bi.topped_up_balance !== undefined) out.values.push({ labelKey: 'toppedUp', label: 'topped-up', value: String(bi.topped_up_balance) })
        continue
      }
    }
    if (out.raw === null) out.raw = JSON.stringify(body).slice(0, 600)
  }
  if (limit !== null && used !== null && limit > 0) {
    out.windows.push({ label: 'billing', percent: Math.round((used / limit) * 1000) / 10, resetsAt: null, status: null })
  }
  if (limit !== null) out.values.push({ labelKey: 'limitUsd', label: 'limit (USD)', value: `$${limit}` })
  if (used !== null) out.values.push({ labelKey: 'usedUsd', label: 'used (USD)', value: `$${used}` })
  if (granted !== null) out.values.push({ labelKey: 'grantedUsd', label: 'granted (USD)', value: `$${granted}` })
  if (out.windows.length === 0 && out.values.length === 0 && out.raw === null) {
    const first = okResults[0]
    out.raw = scrub((first.body || '').slice(0, 600), key)
  }
  if (out.raw !== null) out.raw = scrub(out.raw, key)
  return out
}

function resolvePolicyFor(sandboxPolicy: any, session: any): any {
  if (sandboxPolicy === undefined) return undefined
  try {
    return session ? sandboxPolicy.resolve({ session }) : sandboxPolicy.resolve({})
  } catch {
    return undefined
  }
}

function findSession(agents: any, sessions: any): any {
  if (agents !== undefined) {
    try {
      const a = agents.currentInitiator()
      if (a && a.session) return a.session
    } catch { /* ignore */ }
  }
  if (sessions !== undefined) {
    try {
      const all = sessions.list()
      if (Array.isArray(all) && all.length > 0) return all[0]
    } catch { /* ignore */ }
  }
  return undefined
}

/**
 * Fetch and normalize the full usage report.
 * @param ctx - the plugin context (services read through ctx.get).
 * @param signal - optional AbortSignal forwarded to the shell execution.
 * @returns a lossless-JSON report: `{ ok, fetchedAt, providers }`.
 */
export async function refreshUsage(ctx: any, signal?: AbortSignal): Promise<UsageReport> {
  const settings = ctx.get('settings')
  const credentials = ctx.get('credentials')
  const shell = ctx.get('shell')
  if (settings === undefined || credentials === undefined) {
    return { ok: false, error: 'settings or credentials service is unavailable', providers: [] }
  }
  if (shell === undefined) {
    return { ok: false, error: 'shell service is unavailable', providers: [] }
  }
  const built = buildPlan(settings)
  const report: ProviderReport[] = []
  const groups: any[] = []
  for (const e of built.entries) {
    let resolved: any = null
    try { resolved = await credentials.resolve(e.apiKeyEnv) } catch { resolved = null }
    if (!resolved || !resolved.value) {
      report.push({ route: e.route, displayName: e.displayName, ok: false, error: `credential ${e.apiKeyEnv} is not configured`, windows: [], values: [], raw: null })
      continue
    }
    groups.push({ name: e.route, displayName: e.displayName, key: resolved.value, base: e.base, candidates: e.candidates, probe: e.probe })
  }
  for (const err of built.errors) report.push({ ...err, windows: [], values: [], raw: null })
  if (groups.length > 0) {
    const session = findSession(ctx.get('agents'), ctx.get('sessions'))
    const policy = resolvePolicyFor(ctx.get('sandboxPolicy'), session)
    let text = ''
    let exitCode: number | null = null
    let stderr = ''
    try {
      const spec = shell.resolve({
        command: `node -e "${FETCH_SCRIPT}"`,
        env: { USAGE_PLAN_JSON: JSON.stringify({ groups }) },
        timeoutMs: 60000,
        stdoutMaxBytes: 1048576,
        signal,
        sandboxPolicy: policy,
      })
      const result = await shell.run(spec)
      exitCode = result.exitCode
      text = (result.stdout && result.stdout.text) || ''
      stderr = (result.stderr && result.stderr.text) || ''
    } catch (e: any) {
      return { ok: false, error: `usage fetch failed: ${String((e && e.message) || e)}`, providers: [] }
    }
    if (exitCode !== 0) {
      return { ok: false, error: `fetch helper exited with code ${exitCode}; stderr: ${stderr.slice(0, 800)}; stdout: ${text.slice(0, 300)}`, providers: [] }
    }
    let parsed: any = null
    try { parsed = JSON.parse(text) } catch { parsed = null }
    if (!parsed || parsed.ok !== true) {
      return { ok: false, error: `fetch helper returned no usable result: ${text.slice(0, 300)}`, providers: [] }
    }
    const results = Array.isArray(parsed.results) ? parsed.results : []
    for (const g of groups) {
      const rs = results.filter((r: any) => r && r.name === g.name)
      report.push({ route: g.name, displayName: g.displayName, ...normalizeUsage(rs, g.key) })
    }
  }
  return { ok: true, fetchedAt: new Date().toISOString(), providers: report }
}
