#!/usr/bin/env bash
# =============================================================================
# dsh-provider-usage 一键安装脚本（bash / POSIX）
#
# 两种安装来源：
#   1. 本地源码（默认）：构建（lib/ 缺失时）-> pnpm pack -> 官方 CLI 安装 tarball
#   2. 已发布 registry（-v <version>）：dsh plugin --profile web add dsh-provider-usage@<v>
#
# 用法：
#   ./scripts/install.sh                 # 本地源码一键安装（默认 web profile）
#   ./scripts/install.sh -p web -v 0.2.0 # registry 模式
#   ./scripts/install.sh -r              # 装完尝试 pm2 restart dsh-web
#   ./scripts/install.sh -n              # dry-run
#
# 环境变量：DSH_HOME（默认 $HOME/.dsh）、DSH_CMD（默认 PATH 上的 dsh）
# =============================================================================
set -euo pipefail

PKG='dsh-provider-usage'
PROFILE='web'
VERSION=''
RESTART=0
DRY=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    -p|--profile) PROFILE="$2"; shift 2 ;;
    -v|--version) VERSION="$2"; shift 2 ;;
    -r|--restart) RESTART=1; shift ;;
    -n|--dry-run) DRY=1; shift ;;
    -h|--help) sed -n '1,24p' "$0"; exit 0 ;;
    *) echo "[error] unknown arg: $1" >&2; exit 1 ;;
  esac
done

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DSH_HOME="${DSH_HOME:-$HOME/.dsh}"
PROFILE_DIR="$DSH_HOME/profiles/$PROFILE"
WS_YML="$PROFILE_DIR/pnpm-workspace.yaml"

say() { printf '[install] %s\n' "$*"; }
warn() { printf '[warn] %s\n' "$*" >&2; }
die()  { printf '[error] %s\n' "$*" >&2; exit 1; }

command -v node >/dev/null || die '未找到 node（需要 Node.js >= 20）'
command -v pnpm >/dev/null || die '未找到 pnpm'
[[ -d "$PROFILE_DIR" ]] || die "找不到 profile 目录：$PROFILE_DIR"
[[ -f "$WS_YML" ]] || die "找不到 $WS_YML"
CLI="${DSH_CMD:-}"
if [[ -z "$CLI" ]]; then
  if command -v dsh >/dev/null; then CLI='dsh'
  elif command -v npx >/dev/null; then CLI='npx'
  else die '未找到 dsh 或 npx（或用 DSH_CMD 指定）'; fi
fi

if [[ $DRY -eq 1 ]]; then
  if [[ -n "$VERSION" ]]; then
    say "[dry-run] registry: $CLI plugin --profile $PROFILE add $PKG@$VERSION"
  else
    say "[dry-run] local: build(if needed) -> pnpm pack -> $CLI plugin --profile $PROFILE add <tarball>"
  fi
  say "[dry-run] verify bundles contains $PKG"
  say "[dry-run] $([ $RESTART -eq 1 ] && echo 'pm2 restart dsh-web' || echo 'prompt manual restart')"
  exit 0
fi

if [[ -n "$VERSION" ]]; then
  # ---- registry 模式 ----
  if ! grep -qE '^\s*-\s+dsh-provider-usage\s*$' "$WS_YML"; then
    if grep -qE '^\s*minimumReleaseAgeExclude:\s*$' "$WS_YML"; then
      sed -i.bak -E '/^\s*minimumReleaseAgeExclude:\s*$/a\  - dsh-provider-usage' "$WS_YML" && rm -f "$WS_YML.bak"
    else
      printf '\nminimumReleaseAgeExclude:\n  - dsh-provider-usage\n' >> "$WS_YML"
    fi
    say '已放行 minimumReleaseAgeExclude（dsh-provider-usage）'
  fi
  if [[ "$CLI" == 'dsh' ]]; then
    "$CLI" plugin --profile "$PROFILE" add "$PKG@$VERSION"
  else
    "$CLI" -y --package '@deepseek-ai/dsh' dsh plugin --profile "$PROFILE" add "$PKG@$VERSION"
  fi
else
  # ---- 本地源码模式 ----
  PKG_VERSION="$(node -e 'console.log(require(process.argv[1]).version)' "$ROOT/package.json")"
  TARBALL="$ROOT/$PKG-$PKG_VERSION.tgz"

  if [[ ! -f "$ROOT/lib/index.js" || ! -f "$ROOT/lib/client.js" ]]; then
    say 'lib/ 缺失，开始构建...'
    if [[ ! -d "$ROOT/node_modules/typescript" ]]; then
      say '安装 typescript（临时）...'
      (cd "$ROOT" && npm install --no-save --no-package-lock typescript@5)
    fi
    node "$ROOT/scripts/build.mjs"
    rm -rf "$ROOT/node_modules" "$ROOT/.npm-cache" 2>/dev/null || true
  else
    say 'lib/ 已存在，跳过构建'
  fi

  [[ -f "$TARBALL" ]] && rm -f "$TARBALL"
  say 'pnpm pack ...'
  (cd "$ROOT" && pnpm pack)
  [[ -f "$TARBALL" ]] || die "未生成 tarball：$TARBALL"
  say "tarball：$TARBALL"

  if [[ "$CLI" == 'dsh' ]]; then
    "$CLI" plugin --profile "$PROFILE" add "$TARBALL"
  else
    "$CLI" -y --package '@deepseek-ai/dsh' dsh plugin --profile "$PROFILE" add "$TARBALL"
  fi
fi

# 校验 bundle 注册
if ! node -e 'const p=require(process.argv[1]); const b=p.dsh?.profile?.bundles??[]; process.exit(b.includes(process.argv[2])?0:1)' "$PROFILE_DIR/package.json" "$PKG"; then
  warn "$PKG 未出现在 dsh.profile.bundles 中——挂载未注册。"
  exit 1
fi
say "bundle 已注册：dsh.profile.bundles 包含 $PKG（下次启动自动挂载）"
say "安装完成：$PKG"

if [[ $RESTART -eq 1 ]]; then
  if command -v pm2 >/dev/null; then
    say '重启 dsh-web（pm2）...'
    pm2 restart dsh-web || warn 'pm2 restart 失败，请手动重启 DSH'
  else
    warn '未找到 pm2，请手动重启 DSH'
  fi
else
  say '下一步：重启 DSH 并硬刷新（Ctrl+Shift+R / Cmd+Shift+R）使新副本生效。'
  say '若当前会话仍运行着动态版插件，重启前两个气泡会并存，重启后动态版自动消失。'
fi
