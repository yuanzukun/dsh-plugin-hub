# =============================================================================
# dsh-provider-usage 一键安装脚本（Windows PowerShell 5.1+ / pwsh）
#
# 两种安装来源：
#   1. 本地源码（默认）：自动构建（lib/ 缺失时）、pnpm pack 打包、通过官方
#      CLI 安装 tarball 并注册 bundle：
#        dsh plugin --profile web add <dsh-provider-usage-<ver>.tgz>
#      包内声明了 dsh.bundle.patch（cordis.patch.yml），CLI 的 bundle 协调会
#      自动把它加入 profile 的 dsh.profile.bundles，下次启动即挂载。
#   2. 已发布 registry（-Version）：安装 npm 包，如
#        dsh plugin --profile web add dsh-provider-usage@<version>
#
# 用法（任选其一）：
#   # 本地源码一键安装（默认 web profile）
#   powershell -ExecutionPolicy Bypass -File scripts\install.ps1
#   # 指定 profile / 装完重启 / 只预览
#   powershell -ExecutionPolicy Bypass -File scripts\install.ps1 -Profile web -Restart -DryRun
#   # 已发布版本（registry 模式）
#   powershell -ExecutionPolicy Bypass -File scripts\install.ps1 -Version 0.2.0
#
# 参数：
#   -Profile    目标 profile 名，缺省 web。
#   -Version    已发布版本号/范围（registry 模式）；缺省走本地源码打包安装。
#   -Restart    装完后尝试 `pm2 restart dsh-web`（无 pm2 时仅提示）。
#   -DryRun     只打印将要执行的操作，不写任何文件。
#
# 环境变量（均可省略）：
#   DSH_HOME    默认 %USERPROFILE%\.dsh
#   DSH_CMD     默认优先 PATH 上的 dsh，缺省回退 npx -y --package @deepseek-ai/dsh
#
# 说明：
# - pnpm 11 的 minimumReleaseAge 会拒绝发布 <24h 的新版本（registry 模式）。
#   脚本会幂等预写 minimumReleaseAgeExclude 放行本插件。
# - 本包无原生依赖（无 node-pty/protobufjs），无需 allowBuilds 许可。
# - 安装完成后需要重启 DSH 使新 bundle 生效；若当前会话还在跑本插件的
#   动态版（usag-1），重启前两个气泡会并存，重启后动态版自动消失。
# =============================================================================
param(
  [string]$Profile = 'web',
  [string]$Version = '',
  [switch]$Restart,
  [switch]$DryRun
)

$PKG = 'dsh-provider-usage'
$ROOT = Split-Path -Parent $MyInvocation.MyCommand.Definition   # scripts/
$ROOT = Split-Path -Parent $ROOT                                # package root

if ($env:DSH_HOME) {
  $DSH_HOME = $env:DSH_HOME
} elseif ($env:USERPROFILE) {
  $DSH_HOME = Join-Path $env:USERPROFILE '.dsh'
} else {
  $DSH_HOME = Join-Path $HOME '.dsh'
}
$PROFILE_DIR = Join-Path $DSH_HOME "profiles\$Profile"
$WS_YML = Join-Path $PROFILE_DIR 'pnpm-workspace.yaml'

function Say([string]$m)  { Write-Host "[install] $m" -ForegroundColor Green }
function Warn([string]$m) { Write-Host "[warn] $m" -ForegroundColor Yellow }
function Die([string]$m)  { Write-Host "[error] $m" -ForegroundColor Red; exit 1 }

function Get-DshCli {
  if ($env:DSH_CMD) { return $env:DSH_CMD }
  if (Get-Command dsh -ErrorAction SilentlyContinue) { return 'dsh' }
  if (Get-Command npx -ErrorAction SilentlyContinue) { return 'npx' }
  return $null
}

# 前置校验
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Die '未找到 node（DSH 运行需要 Node.js >= 20），请先安装 Node.js 并加入 PATH。'
}
if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) {
  Die '未找到 pnpm（dsh plugin 依赖 pnpm），请先安装 pnpm。'
}
if (-not (Test-Path $PROFILE_DIR)) {
  Die "找不到 profile 目录：$PROFILE_DIR（请先安装并运行过一次 dsh web）"
}
if (-not (Test-Path $WS_YML)) {
  Die "找不到 $WS_YML（请先初始化 $Profile profile）"
}
$CLI = Get-DshCli
if (-not $CLI) {
  Die '未找到 dsh 或 npx。请先安装 DSH（并确保 Node/npm 可用），或用 DSH_CMD 指定。'
}

$REGISTRY_MODE = -not [string]::IsNullOrWhiteSpace($Version)

if ($DryRun) {
  if ($REGISTRY_MODE) {
    Say "[dry-run] registry 模式：$CLI plugin --profile $Profile add $PKG@$Version"
    Say '[dry-run] 预写 minimumReleaseAgeExclude（$PKG）到 pnpm-workspace.yaml（幂等）'
  } else {
    Say "[dry-run] 本地模式：构建（如 lib/ 缺失）-> pnpm pack -> $CLI plugin --profile $Profile add <tarball>"
  }
  Say "[dry-run] 校验 dsh.profile.bundles 含 $PKG"
  if ($Restart) { Say '[dry-run] pm2 restart dsh-web' } else { Say '[dry-run] 提示手动重启 DSH' }
  exit 0
}

if ($REGISTRY_MODE) {
  # ---------- registry 模式 ----------
  $wsScript = @'
const fs = require("fs");
const p = process.argv[1];
let t = fs.readFileSync(p, "utf8");
const before = t;
if (!/^\s*-\s+dsh-provider-usage\s*$/m.test(t)) {
  if (/^\s*minimumReleaseAgeExclude:\s*$/m.test(t)) {
    t = t.replace(/^(\s*minimumReleaseAgeExclude:\s*)$/m, "$1\n  - dsh-provider-usage");
  } else {
    t += "\nminimumReleaseAgeExclude:\n  - dsh-provider-usage\n";
  }
}
if (t !== before) fs.writeFileSync(p, t);
console.log(t === before ? "unchanged" : "updated");
'@
  $wsOut = node -e $wsScript "$WS_YML" 2>&1
  if ($LASTEXITCODE -ne 0) { Die "处理 $WS_YML 失败（node 退出码 $LASTEXITCODE）：$wsOut" }
  if (($wsOut | Out-String).Trim() -eq 'updated') {
    Say "已放行 minimumReleaseAgeExclude（$PKG）"
  }
  if ($CLI -eq 'dsh') {
    $cliArgs = @('plugin', '--profile', $Profile, 'add', "$PKG@$Version")
  } else {
    $cliArgs = @('-y', '--package', '@deepseek-ai/dsh', 'dsh', 'plugin', '--profile', $Profile, 'add', "$PKG@$Version")
  }
  Say "执行 $CLI plugin --profile $Profile add $PKG@$Version ..."
  & $CLI @cliArgs 2>&1 | ForEach-Object { $_ }
  if ($LASTEXITCODE -ne 0) { Die 'dsh plugin add 失败（见上方输出）' }
} else {
  # ---------- 本地源码模式 ----------
  $pkgJson = Get-Content -Raw (Join-Path $ROOT 'package.json') | ConvertFrom-Json
  $PKG_VERSION = [string]$pkgJson.version
  $TARBALL = Join-Path $ROOT "$PKG-$PKG_VERSION.tgz"

  # 1. 构建（lib/ 缺失时）
  if (-not (Test-Path (Join-Path $ROOT 'lib\index.js')) -or -not (Test-Path (Join-Path $ROOT 'lib\client.js'))) {
    Say 'lib/ 缺失，开始构建（需要 typescript）...'
    if (-not (Test-Path (Join-Path $ROOT 'node_modules\typescript'))) {
      Say '安装 typescript（临时，构建后清理）...'
      Push-Location $ROOT
      try {
        $env:npm_config_cache = Join-Path $ROOT '.npm-cache'
        npm install --no-save --no-package-lock --cache $env:npm_config_cache typescript@5
        if ($LASTEXITCODE -ne 0) { Die 'typescript 安装失败，请先在包目录执行 npm install 后重试' }
      } finally { Pop-Location }
    }
    node (Join-Path $ROOT 'scripts\build.mjs')
    if ($LASTEXITCODE -ne 0) { Die '构建失败（node scripts/build.mjs）' }
    Remove-Item (Join-Path $ROOT 'node_modules') -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $ROOT '.npm-cache') -Recurse -Force -ErrorAction SilentlyContinue
  } else {
    Say 'lib/ 已存在，跳过构建'
  }

  # 2. 打包
  if (Test-Path $TARBALL) { Remove-Item $TARBALL -Force }
  Say 'pnpm pack ...'
  Push-Location $ROOT
  try {
    pnpm pack 2>&1 | ForEach-Object { $_ }
    if ($LASTEXITCODE -ne 0) { Die 'pnpm pack 失败' }
  } finally { Pop-Location }
  if (-not (Test-Path $TARBALL)) { Die "未生成 tarball：$TARBALL" }
  Say "tarball：$TARBALL"

  # 3. 安装
  # 升级到新版本 tarball 前，先移除旧的 file: tarball 依赖——旧 tarball 文件
  # 通常已被删除，pnpm add 会因引用已删除的文件而 ENOENT 失败。
  $curPkg = Get-Content -Raw (Join-Path $PROFILE_DIR 'package.json') | ConvertFrom-Json
  $curDep = $curPkg.dependencies.$PKG
  if ($curDep -and $curDep -like 'file:*' -and $curDep -notlike "*$PKG-$PKG_VERSION.tgz") {
    Say "检测到旧 tarball 依赖：$curDep，先移除再安装新版本"
    if ($CLI -eq 'dsh') {
      & $CLI plugin --profile $Profile remove $PKG 2>&1 | ForEach-Object { $_ }
    } else {
      & $CLI -y --package '@deepseek-ai/dsh' dsh plugin --profile $Profile remove $PKG 2>&1 | ForEach-Object { $_ }
    }
    if ($LASTEXITCODE -ne 0) { Die '移除旧依赖失败（见上方输出）' }
  }
  if ($CLI -eq 'dsh') {
    $cliArgs = @('plugin', '--profile', $Profile, 'add', $TARBALL)
  } else {
    $cliArgs = @('-y', '--package', '@deepseek-ai/dsh', 'dsh', 'plugin', '--profile', $Profile, 'add', $TARBALL)
  }
  Say "执行 $CLI plugin --profile $Profile add <tarball> ..."
  & $CLI @cliArgs 2>&1 | ForEach-Object { $_ }
  if ($LASTEXITCODE -ne 0) { Die 'dsh plugin add 失败（见上方输出）' }
}

# 校验 bundle 已注册
$pkgJson2 = Get-Content -Raw (Join-Path $PROFILE_DIR 'package.json') | ConvertFrom-Json
$bundles = $pkgJson2.dsh.profile.bundles
if ($bundles -notcontains $PKG) {
  Warn "$PKG 未出现在 dsh.profile.bundles 中——挂载未注册。"
  Warn '请检查上方 pnpm 输出后重试本脚本。'
  exit 1
}
Say "bundle 已注册：dsh.profile.bundles 包含 $PKG（下次启动自动挂载）"

Say "安装完成：$PKG"
if ($Restart) {
  if (Get-Command pm2 -ErrorAction SilentlyContinue) {
    Say '重启 dsh-web（pm2）...'
    pm2 restart dsh-web
    if ($LASTEXITCODE -ne 0) { Warn 'pm2 restart 失败，请手动重启 DSH' }
  } else {
    Warn '未找到 pm2，请手动重启 DSH（如：pm2 restart dsh-web 或 dsh web）'
  }
} else {
  Say '下一步：重启 DSH 并硬刷新（Ctrl+Shift+R）使新副本生效。'
  Say '若当前会话仍运行着动态版插件，重启前两个气泡会并存，重启后动态版自动消失。'
}
