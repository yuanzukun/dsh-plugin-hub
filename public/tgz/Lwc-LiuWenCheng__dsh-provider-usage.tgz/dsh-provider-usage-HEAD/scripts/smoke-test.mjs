// Smoke-test the built client bundle by emulating the runtime ModuleLoader
// (which uses the factory RETURN value). Run: node scripts/smoke-test.mjs
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

globalThis.window = {}
const modules = { react: { createElement: () => ({}), useState: () => [null, () => {}], useEffect: () => {} } }
let loaded = null
globalThis.window.__ModuleLoader__ = {
  load(spec) {
    // The runtime consumes the factory's return value (module.exports).
    loaded = spec.factory((name) => modules[name])
  },
}
const bundle = readFileSync(join(dirname(fileURLToPath(import.meta.url)), '..', 'lib', 'client.js'), 'utf8')
eval(bundle)
if (!loaded || loaded.name !== 'dsh-provider-usage') throw new Error(`bad bundle exports: ${JSON.stringify(loaded)}`)
if (!Array.isArray(loaded.inject)) throw new Error('missing inject')
if (typeof loaded.apply !== 'function') throw new Error('missing apply')
loaded.apply({ get: () => undefined })
loaded.apply({ get: (n) => (n === 'slots' ? { inject: () => {} } : undefined) })
console.log('client bundle smoke test OK:', loaded.name, JSON.stringify(loaded.inject))
