/**
 * Build dsh-provider-usage (no shell spawning — uses the TypeScript compiler
 * API directly, so it works even in sandboxed environments).
 *
 *   node scripts/build.mjs
 *
 * Steps:
 *  1. compile the host with tsconfig.host.json  → lib/index.js + lib/usage-core.js (ESM)
 *  2. compile the client with tsconfig.client.json → .tmp/client/index.js (CommonJS)
 *  3. wrap the client output into the ModuleLoader bundle format the dsh web
 *     client runtime consumes → lib/client.js
 *  4. clean .tmp
 *
 * Only `typescript` is required (declared in devDependencies).
 */
import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import ts from 'typescript'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))

function compileProject(configPath) {
  const configFile = ts.readConfigFile(join(root, configPath), ts.sys.readFile)
  if (configFile.error) {
    console.error(ts.formatDiagnostics([configFile.error], { getCanonicalFileName: (f) => f, getCurrentDirectory: () => root, getNewLine: () => '\n' }))
    process.exit(1)
  }
  const parsed = ts.parseJsonConfigFileContent(configFile.config, ts.sys, root)
  const program = ts.createProgram(parsed.fileNames, parsed.options)
  const emitResult = program.emit()
  const diagnostics = ts.getPreEmitDiagnostics(program).concat(emitResult.diagnostics)
  if (diagnostics.length > 0) {
    console.error(ts.formatDiagnostics(diagnostics, { getCanonicalFileName: (f) => f, getCurrentDirectory: () => root, getNewLine: () => '\n' }))
    if (emitResult.emitSkipped) process.exit(1)
  }
  console.log(`tsc ${configPath} OK`)
}

compileProject('tsconfig.host.json')
compileProject('tsconfig.client.json')

// Wrap the compiled client into the ModuleLoader format.
const source = readFileSync(join(root, '.tmp', 'client', 'index.js'), 'utf8')
const bundle = `window.__ModuleLoader__.load({
\tid: ${JSON.stringify(pkg.name)},
\tfactory: (require) => {
\t\tvar module = { exports: {} };
\t\tvar exports = module.exports;
${source
  .split('\n')
  .map((line) => `\t\t${line}`)
  .join('\n')}
\t\treturn module.exports;
\t}
});
`
mkdirSync(join(root, 'lib'), { recursive: true })
writeFileSync(join(root, 'lib', 'client.js'), bundle)
console.log(`built lib/client.js (${bundle.length} bytes) for ${pkg.name}@${pkg.version}`)

rmSync(join(root, '.tmp'), { recursive: true, force: true })
console.log('build complete')
