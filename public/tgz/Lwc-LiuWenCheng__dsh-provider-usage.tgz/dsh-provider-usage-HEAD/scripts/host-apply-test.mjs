/**
 * Host apply simulation: imports the INSTALLED copy (resolves peer deps from
 * the profile tree) and runs `apply` against mocked webServer / tools / on to
 * prove the plugin boots without throwing and registers its routes + tool.
 * Run from the package scripts dir: node scripts/host-apply-test.mjs
 */
import { pathToFileURL } from 'node:url'
import { join } from 'node:path'

const profile = process.env.DSH_PROFILE_DIR || 'D:/AIAgent/dsh/profiles/web'
const modPath = join(profile, 'node_modules', 'dsh-provider-usage', 'lib', 'index.js')
const mod = await import(pathToFileURL(modPath).href)
console.log('loaded:', Object.keys(mod).sort().join(', '))
console.log('inject:', JSON.stringify(mod.inject))
if (!mod.inject.includes('webServer') || !mod.inject.includes('tools')) {
  console.error('FAIL: inject must include webServer and tools (ctx.tools.register needs tools injected)')
  process.exit(1)
}

const routes = []
const tools = []
const listeners = new Map()
const ctx = {
  get: () => undefined,
  on: (name, fn) => { listeners.set(name, fn); return () => {} },
  webServer: { register: (r) => { routes.push(r); return () => {} } },
  tools: { register: (t) => { tools.push(t); return () => {} } },
}
const cfg = mod.Config({})
mod.apply(ctx, cfg)

const paths = routes.map((r) => `${r.kind}:${r.path}`)
console.log('routes:', paths.join(', '))
console.log('tools:', tools.map((t) => t.name).join(', '))
if (!paths.includes('exact:/provider-usage/query')) throw new Error('missing query route')
if (!paths.includes('exact:/provider-usage/config')) throw new Error('missing config route')
if (!paths.includes('exact:/provider-usage/activity')) throw new Error('missing activity route')
if (tools.length === 0) throw new Error('no tool registered')
console.log('host apply simulation OK')
