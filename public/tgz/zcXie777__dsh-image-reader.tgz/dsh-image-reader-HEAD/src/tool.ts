/**
 * The `read_image` model-facing tool: reads an image from a workspace path and
 * asks a configured OpenAI-compatible vision endpoint a question about it.
 * @module dsh-image-reader/tool
 */

import { readFile } from 'node:fs/promises'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ResolvedConfig } from './config.js'
import { resolveImagePath, type PathPolicy } from './paths.js'

const IMAGE_MIME: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
}

export interface ReadImageResult {
  answer: string
  model: string
}

function dataUrl(mime: string, base64: string): string {
  return `data:${mime};base64,${base64}`
}

export function createImageReaderTool(
  getConfig: () => ResolvedConfig,
  getPolicy: () => Promise<PathPolicy>,
): ReturnType<typeof defineTool> {
  return defineTool({
    name: 'read_image',
    description:
      'Read an image file and answer a question about it. Use this to understand screenshots, ' +
      'diagrams, photographs, or any visual content the user points at by path. ' +
      'Pass a workspace-relative or workspace-absolute path.',
    parameters: {
      image: {
        type: 'string',
        required: true,
        description: 'Path to the image (workspace-relative, or absolute inside the workspace).',
      },
      query: {
        type: 'string',
        description: 'What to ask about the image. Omit for a general description.',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          answer: { type: 'string', required: true },
          model: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: value.answer }],
    },
    async execute(args, exec): Promise<ReadImageResult> {
      const config = getConfig()
      const policy = await getPolicy()
      const file = await resolveImagePath(args.image, policy)
      if (file.bytes > config.maxImageBytes) {
        throw new Error(
          `image-reader: image is ${file.bytes} bytes, over the ${config.maxImageBytes}-byte limit`,
        )
      }
      const key = process.env[config.provider.apiKeyEnv]
      if (key === undefined || key.length === 0) {
        throw new Error(`image-reader: API key not found; set the ${config.provider.apiKeyEnv} environment variable`)
      }
      const extension = file.path.slice(file.path.lastIndexOf('.')).toLowerCase()
      const mime = IMAGE_MIME[extension] ?? 'application/octet-stream'
      const encoded = (await readFile(file.path)).toString('base64')
      const lang = config.lang === 'zh' ? 'Chinese' : 'English'
      const prompt = args.query && args.query.trim().length > 0
        ? `${args.query.trim()}\n\nReply in ${lang}.`
        : `Describe this image in detail. Reply in ${lang}.`

      const signal = AbortSignal.any([exec.signal, AbortSignal.timeout(config.timeoutMs)])
      const response = await fetch(`${config.provider.baseUrl}/chat/completions`, {
        method: 'POST',
        signal,
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${key}`,
        },
        body: JSON.stringify({
          model: config.provider.model,
          max_tokens: 1024,
          messages: [
            {
              role: 'user',
              content: [
                { type: 'image_url', image_url: { url: dataUrl(mime, encoded) } },
                { type: 'text', text: prompt },
              ],
            },
          ],
        }),
      })
      if (!response.ok) {
        const body = await response.text().catch(() => '')
        throw new Error(`image-reader: vision endpoint returned ${response.status}: ${body.slice(0, 500)}`)
      }
      const data = (await response.json()) as {
        choices?: Array<{ message?: { content?: string } }>
      }
      const answer = data.choices?.[0]?.message?.content?.trim()
      if (answer === undefined || answer.length === 0) {
        throw new Error('image-reader: vision endpoint returned no text')
      }
      return { answer, model: config.provider.model }
    },
  })
}
