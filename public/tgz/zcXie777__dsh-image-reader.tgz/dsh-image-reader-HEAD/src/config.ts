/**
 * Plugin configuration. `provider.baseUrl` and `provider.model` are required on
 * purpose: the plugin never assumes a vendor, so a misconfigured endpoint fails
 * loud instead of silently sending images to a hardcoded third party. The API
 * key is read per call from the environment variable named by `apiKeyEnv`.
 * @module dsh-image-reader/config
 */

export interface ImageReaderConfig {
  provider?: {
    /** OpenAI-compatible chat/completions base URL, e.g. https://api.openai.com/v1 */
    baseUrl?: string
    /** Multimodal model name to send images to. */
    model?: string
    /** Environment variable name that holds the API key. */
    apiKeyEnv?: string
  }
  /** Answer language. */
  lang?: 'zh' | 'en'
  /** Whole-request deadline in milliseconds. */
  timeoutMs?: number
  /** Maximum accepted image size in bytes. */
  maxImageBytes?: number
  /** Extra directories (besides the workspace) images may come from. */
  allowedDirs?: string[]
}

export interface ResolvedConfig {
  provider: {
    baseUrl: string
    model: string
    apiKeyEnv: string
  }
  lang: 'zh' | 'en'
  timeoutMs: number
  maxImageBytes: number
  allowedDirs: string[]
}

const MAX_TIMEOUT_MS = 600000
const MAX_IMAGE_BYTES = 32 * 1024 * 1024

export function resolveConfig(config: ImageReaderConfig = {}): ResolvedConfig {
  const baseUrl = (config.provider?.baseUrl ?? '').trim().replace(/\/+$/, '')
  if (!/^https?:\/\//i.test(baseUrl)) {
    throw new Error('image-reader: provider.baseUrl must be an http(s) URL')
  }
  const model = (config.provider?.model ?? '').trim()
  if (model.length === 0) {
    throw new Error('image-reader: provider.model must not be empty')
  }
  const apiKeyEnv = (config.provider?.apiKeyEnv ?? 'VISION_API_KEY').trim()
  if (apiKeyEnv.length === 0) {
    throw new Error('image-reader: provider.apiKeyEnv must not be empty')
  }
  const lang = config.lang ?? 'zh'
  if (lang !== 'zh' && lang !== 'en') {
    throw new Error('image-reader: lang must be "zh" or "en"')
  }
  const timeoutMs = config.timeoutMs ?? 60000
  if (!Number.isInteger(timeoutMs) || timeoutMs < 1000 || timeoutMs > MAX_TIMEOUT_MS) {
    throw new Error(`image-reader: timeoutMs must be an integer between 1000 and ${MAX_TIMEOUT_MS}`)
  }
  const maxImageBytes = config.maxImageBytes ?? 10485760
  if (!Number.isInteger(maxImageBytes) || maxImageBytes < 1024 || maxImageBytes > MAX_IMAGE_BYTES) {
    throw new Error(`image-reader: maxImageBytes must be an integer between 1024 and ${MAX_IMAGE_BYTES}`)
  }
  const allowedDirs = (config.allowedDirs ?? []).map(d => d.trim()).filter(d => d.length > 0)
  return { provider: { baseUrl, model, apiKeyEnv }, lang, timeoutMs, maxImageBytes, allowedDirs }
}
