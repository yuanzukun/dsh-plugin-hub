/**
 * Image path fence: an input must be a regular file under the workspace or an
 * explicitly authorized directory, resolved through realpath so a symlink
 * cannot escape the fence. This keeps the model from exfiltrating arbitrary
 * local files to a remote vision endpoint.
 * @module dsh-image-reader/paths
 */

import { realpath, stat } from 'node:fs/promises'
import { homedir } from 'node:os'
import { isAbsolute, join, relative, resolve, sep } from 'node:path'

export const SUPPORTED_IMAGE_EXTENSIONS = ['.png', '.jpg', '.jpeg', '.gif', '.webp'] as const

/** Whether `child` equals or lies under `parent` on the same path root. */
export function isWithin(parent: string, child: string): boolean {
  const rel = relative(parent, child)
  return rel === '' || (rel !== '..' && !rel.startsWith(`..${sep}`) && !isAbsolute(rel))
}

function expandUserHome(raw: string): string {
  if (raw === '~') return homedir()
  if (raw.startsWith('~/') || raw.startsWith(`~${sep}`)) return join(homedir(), raw.slice(2))
  return raw
}

export interface PathPolicy {
  workspace: string
  allowedDirs: string[]
}

/** Resolve and realpath the workspace plus any configured allowed roots. */
export async function createPathPolicy(
  workspaceRaw: string,
  allowedDirs: readonly string[],
): Promise<PathPolicy> {
  const workspace = await realpath(expandUserHome(workspaceRaw))
  const roots = [workspace]
  for (const raw of allowedDirs) {
    const candidate = expandUserHome(raw)
    const target = isAbsolute(candidate) ? candidate : resolve(workspace, candidate)
    roots.push(await realpath(target))
  }
  return { workspace, allowedDirs: roots }
}

/** Validate one image path and return its fence-checked absolute path and size. */
export async function resolveImagePath(
  raw: string,
  policy: PathPolicy,
): Promise<{ path: string; bytes: number }> {
  const candidate = expandUserHome(raw)
  const target = isAbsolute(candidate) ? candidate : resolve(policy.workspace, candidate)
  const real = await realpath(target).catch((error: unknown) => {
    throw new Error(`image-reader: image not found: ${raw}`, { cause: error })
  })
  if (!policy.allowedDirs.some(root => isWithin(root, real))) {
    throw new Error(`image-reader: image escapes the allowed directories: ${raw}`)
  }
  const info = await stat(real).catch((error: unknown) => {
    throw new Error(`image-reader: image is not readable: ${raw}`, { cause: error })
  })
  if (!info.isFile()) throw new Error(`image-reader: image is not a regular file: ${raw}`)
  const extension = real.slice(real.lastIndexOf('.')).toLowerCase()
  if (!SUPPORTED_IMAGE_EXTENSIONS.includes(extension as never)) {
    throw new Error(
      `image-reader: unsupported image format "${extension || '(none)'}"; supported: ${SUPPORTED_IMAGE_EXTENSIONS.join(', ')}`,
    )
  }
  return { path: real, bytes: info.size }
}
