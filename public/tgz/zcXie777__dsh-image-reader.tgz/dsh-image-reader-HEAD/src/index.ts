/**
 * dsh-image-reader profile bundle: a single model-facing `read_image` tool that
 * lets a text-only DeepSeek Harness agent read images through any
 * OpenAI-compatible vision endpoint.
 * @module dsh-image-reader
 */

import type { Context } from '@deepseek-ai/cordis'
import { resolveConfig, type ImageReaderConfig } from './config.js'
import { createPathPolicy, type PathPolicy } from './paths.js'
import { createImageReaderTool } from './tool.js'
import { PLUGIN_VERSION } from './version.js'

export const name = 'image-reader'
export const inject = ['tools']

export async function apply(ctx: Context, config: ImageReaderConfig = {}): Promise<() => void> {
  const resolved = resolveConfig(config)
  let policy: PathPolicy | undefined

  const getPolicy = async (): Promise<PathPolicy> => {
    policy ??= await createPathPolicy(process.cwd(), resolved.allowedDirs)
    return policy
  }

  const dispose = ctx.tools.register(createImageReaderTool(() => resolved, getPolicy))
  ctx.logger.info(
    'image-reader %s ready (model %s via %s)',
    PLUGIN_VERSION,
    resolved.provider.model,
    resolved.provider.baseUrl,
  )

  return () => {
    dispose()
  }
}
