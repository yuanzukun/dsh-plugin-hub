import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest'
import { resolveConfig } from '../src/config.js'
import { createPathPolicy, type PathPolicy } from '../src/paths.js'
import { createImageReaderTool, type ReadImageResult } from '../src/tool.js'

let root: string
let policy: PathPolicy
const config = resolveConfig({ provider: { baseUrl: 'https://api.test/v1', model: 'test-vision' } })

beforeAll(async () => {
  root = await mkdtemp(join(tmpdir(), 'image-reader-tool-'))
  await writeFile(join(root, 'img.png'), Buffer.from([0x89, 0x50, 0x4e, 0x47]))
  policy = await createPathPolicy(root, [])
})

afterAll(async () => {
  await rm(root, { recursive: true, force: true })
})

beforeEach(() => {
  vi.unstubAllEnvs()
  vi.unstubAllGlobals()
})

function exec(): never {
  return { signal: new AbortController().signal } as never
}

describe('read_image execute', () => {
  it('sends the image and returns the answer', async () => {
    vi.stubEnv('VISION_API_KEY', 'sk-test')
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ choices: [{ message: { content: 'A red square.' } }] }),
    })
    vi.stubGlobal('fetch', fetchMock)

    const tool = createImageReaderTool(() => config, async () => policy)
    const result = (await tool.execute({ image: 'img.png', query: 'what color?' }, exec())) as ReadImageResult

    expect(result.answer).toBe('A red square.')
    expect(result.model).toBe('test-vision')

    const [url, init] = fetchMock.mock.calls[0] as [string, { headers: Record<string, string>; body: string }]
    expect(url).toBe('https://api.test/v1/chat/completions')
    expect(init.headers.authorization).toBe('Bearer sk-test')

    const body = JSON.parse(init.body)
    expect(body.model).toBe('test-vision')
    const content = body.messages[0].content
    expect(content[0].type).toBe('image_url')
    expect(content[0].image_url.url).toMatch(/^data:image\/png;base64,/)
    expect(content[1].text).toContain('what color?')
  })

  it('throws when the key is missing', async () => {
    vi.stubEnv('VISION_API_KEY', '')
    const tool = createImageReaderTool(() => config, async () => policy)
    await expect(tool.execute({ image: 'img.png' }, exec())).rejects.toThrow(/API key/)
  })

  it('throws on a non-2xx response', async () => {
    vi.stubEnv('VISION_API_KEY', 'sk-test')
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: false, status: 401, text: async () => 'unauthorized' }))
    const tool = createImageReaderTool(() => config, async () => policy)
    await expect(tool.execute({ image: 'img.png' }, exec())).rejects.toThrow(/401/)
  })
})
