import { describe, expect, it } from 'vitest'
import { resolveConfig, type ImageReaderConfig } from '../src/config.js'

const provider = { baseUrl: 'https://api.openai.com/v1', model: 'gpt-4o-mini' }

describe('resolveConfig', () => {
  it('applies defaults and strips a trailing slash', () => {
    const c = resolveConfig({ provider: { ...provider, baseUrl: 'https://api.openai.com/v1/' } })
    expect(c.provider.baseUrl).toBe('https://api.openai.com/v1')
    expect(c.provider.apiKeyEnv).toBe('VISION_API_KEY')
    expect(c.lang).toBe('zh')
    expect(c.timeoutMs).toBe(60000)
    expect(c.maxImageBytes).toBe(10485760)
    expect(c.allowedDirs).toEqual([])
  })

  it('requires baseUrl', () => {
    expect(() => resolveConfig({ provider: { model: 'gpt-4o-mini' } })).toThrow(/baseUrl/)
  })

  it('requires model', () => {
    expect(() => resolveConfig({ provider: { baseUrl: 'https://x' } })).toThrow(/model/)
  })

  it('rejects an invalid lang', () => {
    const bad = { provider, lang: 'fr' } as unknown as ImageReaderConfig
    expect(() => resolveConfig(bad)).toThrow(/lang/)
  })

  it('rejects an out-of-range timeout', () => {
    expect(() => resolveConfig({ provider, timeoutMs: 10 })).toThrow(/timeoutMs/)
  })

  it('rejects an over-limit image size', () => {
    expect(() => resolveConfig({ provider, maxImageBytes: 999999999 })).toThrow(/maxImageBytes/)
  })

  it('trims and drops empty allowedDirs', () => {
    const c = resolveConfig({ provider, allowedDirs: [' /tmp/a ', '  '] })
    expect(c.allowedDirs).toEqual(['/tmp/a'])
  })
})
