import { mkdir, mkdtemp, rm, symlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import { createPathPolicy, isWithin, resolveImagePath } from '../src/paths.js'

let root: string
let workspace: string

beforeAll(async () => {
  root = await mkdtemp(join(tmpdir(), 'image-reader-'))
  workspace = join(root, 'ws')
  await mkdir(workspace)
  await writeFile(join(workspace, 'ok.png'), Buffer.from('fake'))
  await writeFile(join(root, 'outside.png'), Buffer.from('fake'))
  await mkdir(join(workspace, 'dir.png'))
})

afterAll(async () => {
  await rm(root, { recursive: true, force: true })
})

describe('isWithin', () => {
  it('accepts self and children', () => {
    expect(isWithin('/a/b', '/a/b')).toBe(true)
    expect(isWithin('/a/b', '/a/b/c')).toBe(true)
  })

  it('rejects escape and parent', () => {
    expect(isWithin('/a/b', '/a/c')).toBe(false)
    expect(isWithin('/a/b', '/a')).toBe(false)
  })
})

describe('resolveImagePath', () => {
  it('resolves a valid image in the workspace', async () => {
    const policy = await createPathPolicy(workspace, [])
    const file = await resolveImagePath('ok.png', policy)
    expect(file.bytes).toBe(4)
  })

  it('rejects a file outside the workspace', async () => {
    const policy = await createPathPolicy(workspace, [])
    await expect(resolveImagePath(join(root, 'outside.png'), policy)).rejects.toThrow(/escapes/)
  })

  it('rejects an unsupported extension', async () => {
    const policy = await createPathPolicy(workspace, [])
    await writeFile(join(workspace, 'note.txt'), 'x')
    await expect(resolveImagePath('note.txt', policy)).rejects.toThrow(/unsupported/)
  })

  it('rejects a directory', async () => {
    const policy = await createPathPolicy(workspace, [])
    await expect(resolveImagePath('dir.png', policy)).rejects.toThrow(/not a regular file/)
  })

  it.skipIf(process.platform === 'win32')('rejects a symlink that escapes the workspace', async () => {
    const policy = await createPathPolicy(workspace, [])
    await symlink(join(root, 'outside.png'), join(workspace, 'link.png'))
    await expect(resolveImagePath('link.png', policy)).rejects.toThrow(/escapes/)
  })
})
