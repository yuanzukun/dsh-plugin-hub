// DSH host half: completion notifications for conversation / task events.
// Provides a JSON poll endpoint under /dsh-notification-center/ that the
// browser client fetches. Install as a host composition plugin (cordis.yml).
export default {
  name: 'dsh-notification-center',
  inject: ['webServer'],
  apply(ctx) {
    // ---- in-memory completion queue (JSON-safe records only) ----
    let seq = 0
    const queue = []
    const MAX_QUEUE = 100
    const push = (sessionId, kind, title, body, extra) => {
      seq += 1
      const rec = { id: seq, sessionId: sessionId || '', kind, title, body, at: Date.now() }
      if (extra && typeof extra === 'object') {
        for (const k of Object.keys(extra)) rec[k] = extra[k]
      }
      queue.push(rec)
      if (queue.length > MAX_QUEUE) queue.shift()
    }

    // Turn ended: carry the durable stop reason so the client can decide
    // whether to notify (manual stop / interrupt are silent by default;
    // completion / error / max-tokens / blocked notify).
    const TURN_TITLES = {
      completed: '对话完成',
      error: '对话因错误停止',
      'max-tokens': '对话超长截断',
      blocked: '对话被阻塞',
      aborted: '对话已停止',
      interrupted: '对话已停止'
    }
    ctx.on('session/event', (session, event) => {
      if (!session || !event) return
      const sid = session.id ? String(session.id) : ''

      // The model calls ask_user_question → it blocks until the user answers.
      // Notify immediately so the user knows a question is waiting.
      if (event.type === 'tool/call' && event.data && event.data.name === 'ask_user_question') {
        let body = '模型正在向你提问'
        try {
          const args = JSON.parse(event.data.arguments || '{}')
          if (args && Array.isArray(args.questions) && args.questions.length) {
            const q = args.questions[0]
            body = String(q.question || q.header || '模型正在向你提问')
          }
        } catch (_) { /* keep fallback */ }
        push(sid, 'approval', '需要你的回答', body)
        return
      }

      if (event.type !== 'turn/end') return
      const data = event.data || {}
      const reason = data.reason || {}
      const rk = reason.kind ? String(reason.kind) : 'other'
      let abortCause = ''
      if (rk === 'aborted') {
        abortCause = reason.reason && reason.reason.kind ? String(reason.reason.kind) : ''
      }
      const title = TURN_TITLES[rk] || '对话已停止'
      let sessionTitle = ''
      try {
        const st = ctx.get('sessionTitle')
        if (st && session) {
          const snap = st.get(session)
          if (snap && typeof snap.title === 'string' && snap.title) sessionTitle = String(snap.title)
        }
      } catch (_) { /* keep empty */ }
      // Title the notification by the session (so you know which conversation),
      // and put the event description in the body.
      if (sessionTitle) push(sid, 'turn', sessionTitle, title, { reason: rk, abortCause })
      else push(sid, 'turn', title, sid, { reason: rk, abortCause })
    })

    // The model asks for permission / approval — the user needs to act now.
    // Waterfall: observe, record, and ALWAYS continue the chain.
    ctx.on('approval/request', (req, next) => {
      try {
        let sid = ''
        let body = '模型正在等待你的批准'
        if (req) {
          if (req.agent && req.agent.id) sid = String(req.agent.id)
          const parts = []
          if (req.toolName) parts.push(String(req.toolName))
          if (req.reason) parts.push(String(req.reason))
          if (parts.length) body = '等待批准: ' + parts.join(' · ')
        }
        push(sid, 'approval', '需要你的批准', body)
      } catch (_) { /* never break the approval chain */ }
      return next()
    })

    // Subagent (subtask) lifecycle. The parent session id must be captured at
    // `subagent/start`, while the child is guaranteed live: by the time
    // `subagent/end` fires the child may already be disposed (continuable
    // children settle after ownership release), so resolving it then fails.
    // Correlate start → end by the shared `runId`, mirroring the subagent
    // service's own start/end pairing. The correct parent link is the child
    // session header (`session.header.parentSession`), not `session.meta`.
    const subagentParents = new Map()
    ctx.on('subagent/start', (info) => {
      if (!info || !info.runId) return
      let sid = ''
      try {
        const agents = ctx.get('agents')
        if (agents) {
          // Local child: read the child session's parent link. The child is
          // guaranteed live here — subagent/start fires synchronously inside
          // the parent's delegation, before any disposal.
          if (typeof agents.get === 'function' && info.id) {
            const child = agents.get(info.id)
            if (child && child.session && child.session.header && child.session.header.parentSession) {
              sid = String(child.session.header.parentSession)
            }
          }
          // Remote child (local: false): its id is a parent-namespaced run id,
          // not a session in this process, so agents.get() misses. Fall back to
          // the initiating (parent) agent, which is the agent currently running
          // the delegation that just published this start.
          if (!sid && typeof agents.currentInitiator === 'function') {
            const initiator = agents.currentInitiator()
            if (initiator && initiator.id) sid = String(initiator.id)
          }
        }
      } catch (_) { /* keep fallback */ }
      if (sid) subagentParents.set(info.runId, sid)
    })
    ctx.on('subagent/end', (info) => {
      if (!info) return
      let sid = ''
      if (info.runId && subagentParents.has(info.runId)) {
        sid = subagentParents.get(info.runId)
        subagentParents.delete(info.runId)
      }
      if (!sid) return
      const reason = info.stopReason || 'settled'
      push(sid, 'subagent', '子任务完成', '子代理 ' + String(info.provider || 'subagent') + ' · ' + String(reason))
    })

    // Workflow run settled — attribute to the initiating (parent) agent when one
    // is live; otherwise drop it (covered by the subsequent turn/end completion).
    ctx.on('workflow/end', (info, result) => {
      if (!info) return
      let sid = ''
      try {
        const agents = ctx.get('agents')
        if (agents && typeof agents.currentInitiator === 'function') {
          const initiator = agents.currentInitiator()
          if (initiator && initiator.id) sid = String(initiator.id)
        }
      } catch (_) { /* keep fallback */ }
      if (!sid) return
      const name = info.meta && info.meta.name ? String(info.meta.name) : 'workflow'
      const reason = result && result.stopReason ? String(result.stopReason) : 'settled'
      push(sid, 'workflow', '任务完成 · Workflow', name + ' · ' + reason)
    })

    // Background job settled.
    const jobs = ctx.get('jobs')
    if (jobs && typeof jobs.onJobDone === 'function') {
      ctx.effect(() => jobs.onJobDone((snapshot, owner) => {
        if (!snapshot) return
        const ownerSid = owner && owner.id ? String(owner.id) : ''
        const snapSid = snapshot.ownerSession ? String(snapshot.ownerSession) : ''
        push(ownerSid || snapSid, 'job', '后台任务完成', snapshot.label || String(snapshot.id))
      }))
    }

    // JSON poll endpoint the browser client fetches every ~1.5s, plus a native
    // notification endpoint the client calls when it runs inside a packaged
    // shell (Electron/Tauri) where the HTML5 Notification permission is denied.
    // GET /dsh-notification-center/poll?session=<sessionId>&after=<lastId>
    // GET /dsh-notification-center/notify?title=<title>&body=<body>
    ctx.effect(() => ctx.webServer.register({
      kind: 'prefix',
      path: '/dsh-notification-center',
      handler: async (req, res) => {
        try {
          const url = new URL(req.url || '/', 'http://localhost')
          const pathname = url.pathname

          if (pathname === '/dsh-notification-center/notify') {
            const title = url.searchParams.get('title') || '通知中心'
            const body = url.searchParams.get('body') || ''
            try {
              // Native OS notification from the host process, unified across
              // Windows (SnoreToast), macOS (terminal-notifier) and Linux
              // (notify-send); appName sets the displayed app name on all three.
              const mod = await import('node-notifier')
              const notifier = mod.default || mod
              notifier.notify({ title, message: body, sound: false, appName: 'DeepSeek Harness' })
              res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
              res.end(JSON.stringify({ ok: true }))
            } catch (e) {
              res.writeHead(500, { 'content-type': 'application/json; charset=utf-8' })
              res.end(JSON.stringify({ ok: false, error: String(e && e.message ? e.message : e) }))
            }
            return
          }

          const session = url.searchParams.get('session') || ''
          const after = Number(url.searchParams.get('after')) || 0
          const items = []
          for (const q of queue) {
            if (q.id > after && (!session || q.sessionId === session)) items.push(q)
          }
          const lastId = items.length ? items[items.length - 1].id : after
          res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
          res.end(JSON.stringify({ items, lastId }))
        } catch (e) {
          res.writeHead(500, { 'content-type': 'application/json; charset=utf-8' })
          res.end(JSON.stringify({ error: String(e && e.message ? e.message : e) }))
        }
      }
    }))
  }
}
