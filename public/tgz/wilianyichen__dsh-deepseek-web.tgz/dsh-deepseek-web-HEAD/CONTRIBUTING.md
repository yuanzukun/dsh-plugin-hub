# Contributing

感谢你考虑为 dsh-deepseek-web 做贡献！

## 开发

```sh
pnpm install
pnpm build     # tsc → lib/
pnpm test      # vitest
```

## 提 PR 前检查

- [ ] `pnpm build` 无错误
- [ ] `pnpm test` 全绿
- [ ] 新工具在 README 工具表中有记录
- [ ] 涉及 CLI 参数变化时同步更新 README 配置示例

## 前置依赖说明

本插件通过子进程调用 deepseek-ops 的 Python 脚本（`deepseek_client.py` 等）。
贡献时请保持脚本路径可配置（`scriptDir`），不要硬编码。

## 发布

```sh
pnpm build
npm publish    # 需 npm 登录
```

## 许可证

MIT — 见 [LICENSE](./LICENSE)
