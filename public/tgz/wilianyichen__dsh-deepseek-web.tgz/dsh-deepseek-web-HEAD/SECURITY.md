# Security Policy

## 报告漏洞

不要公开报告安全问题。请通过 GitHub 私信或 issue（标注 security）联系维护者。

## 已知边界

- 插件只做子进程转发，不收集遥测
- DeepSeek 网页版 token 存本地文件（`_deepseek_token.json`），权限应设为仅本人可读
- 写操作（chat / share）走系统 curl 子进程，与 deepseek-ops 一致
- 请勿在日志或提交中泄露 token 文件内容

## 依赖

- 构建依赖固定于 pnpm-lock.yaml
- 发布前运行 `npm audit`
