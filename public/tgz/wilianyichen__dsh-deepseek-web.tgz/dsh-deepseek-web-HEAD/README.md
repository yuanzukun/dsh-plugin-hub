# dsh-deepseek-web

把 DeepSeek 网页版（chat.deepseek.com）的**会话归档**变成可编程的读取与摘要工具：
在 DSH 内直接列会话、下载全文、搜索索引、生成高密度摘要。

> **设计说明**：本插件只提供**只读**能力（列表/读取/搜索/摘要/分享列表）。
> 写操作（发消息、创建分享）被 DeepSeek 网页版服务端限流（Cloudflare WAF），
> 因此刻意不暴露——读功能不受影响且已完整验证。

Read your DeepSeek web session archive as a programmable agent from inside DeepSeek Harness — read-only, fully verified.

## 能力 / Tools

| 工具 | 功能 |
|---|---|
| `deepseek_web_list` | 列会话（100 段历史，可按标题过滤） |
| `deepseek_web_recent` | 最近 N 个会话速览（轻量） |
| `deepseek_web_get` | 下载指定会话全文到本地归档 |
| `deepseek_web_sync` | 增量同步新会话到本地（L0 存档） |
| `deepseek_web_search` | 重建并搜索本地会话索引（需 deepseek_index.py） |
| `deepseek_web_digest` | **100 会话 → 一页高密度摘要**：按日活跃度直方图 + 主题聚类 + 全列表 + token 估算 |
| `deepseek_web_share_list` | 列出我的分享（只读） |

## 前置依赖（deepseek-ops 脚本）

本插件通过子进程调用 [deepseek-ops](https://github.com/Panniantong/deepseek-ops) 的
Python 脚本（`deepseek_client.py` / `deepseek_index.py` / `deepseek_auth.py`），
复用其已验证的认证（扫码 + Bearer token）。

- 首次使用先跑 `python deepseek_auth.py` 扫码登录（生成 `_deepseek_token.json`）
- 在插件配置里指定 `scriptDir` 指向脚本目录

## 安装 / Install

```sh
dsh plugin --profile web add @yichenwilian/dsh-deepseek-web
```

## 配置 / Config

```yaml
- id: dsh-deepseek-web
  name: '@yichenwilian/dsh-deepseek-web'
  config:
    pythonPath: python
    scriptDir: D:/data/BaiduSyncdisk/knowledge-lab/生产管线/scripts
```

## digest 输出示例

```
# DeepSeek Web Digest (last 30d, 10 sessions)

## Activity by day
- 2026-08-22: 3 ████████████████████
- 2026-08-21: 2 ██████████████
- 2026-08-18: 2 ██████████████

## Topic clusters
### claude (2)
- [2026-08-21] Claude Code Mac订阅流程
- [2026-08-20] Claude Code 迁移记录

## All sessions
### 2026-08-22 (3)
- [abc123] 会话标题

> ~350 tokens (CJK-aware estimate)
```

## 安全

- Token 存本地文件（`_deepseek_token.json`），插件不落日志
- 只读工具，无写操作暴露
- 插件本身只做子进程转发，不收集任何遥测

## 开发 / Development

```sh
pnpm install
pnpm build     # tsc → lib/
pnpm test      # vitest (15 tests)
```

## License

MIT
