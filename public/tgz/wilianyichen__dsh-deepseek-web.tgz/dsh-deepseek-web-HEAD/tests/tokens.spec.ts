import { describe, expect, it } from 'vitest'
import { estimateTokens } from '../src/index.js'

describe('estimateTokens (exported)', () => {
  it('estimates English text at ~4 chars/token', () => {
    const text = 'hello world this is a test'
    expect(estimateTokens(text)).toBe(Math.ceil(text.length / 4))
  })

  it('weights CJK at ~1.5 chars/token', () => {
    const text = '你好世界这是一个测试'
    expect(estimateTokens(text)).toBe(Math.ceil(text.length / 1.5))
  })

  it('mixes CJK and ASCII correctly', () => {
    const text = '你好 world 测试'
    const cjk = 4 // 你好测试
    const other = text.length - cjk
    expect(estimateTokens(text)).toBe(Math.ceil(cjk / 1.5 + other / 4))
  })

  it('empty text is zero tokens', () => {
    expect(estimateTokens('')).toBe(0)
  })
})
