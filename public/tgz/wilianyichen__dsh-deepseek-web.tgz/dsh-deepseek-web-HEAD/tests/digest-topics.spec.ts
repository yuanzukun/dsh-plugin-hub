import { describe, expect, it } from 'vitest'

// Topic clustering logic from the digest tool — inline mirror for unit testing.
const STOP = new Set(['deepseek', 'dsh', 'plugin', '使用', '如何', '一个', '这个', '相关', '安装', '配置', '实现', '问题', '代码', '插件', '工具', '分析', '解决', '介绍', '功能', '我们'])

function extractTopic(title: string): string | null {
  const enWords = title.match(/[a-zA-Z][a-zA-Z0-9-]{2,}/g) ?? []
  const cnBlocks = title.match(/[\u4e00-\u9fff]{2,}/g) ?? []
  let topic: string | null = enWords.map((w) => w.toLowerCase()).find((w) => !STOP.has(w)) ?? null
  if (!topic) {
    for (const block of cnBlocks) {
      for (const w of STOP) {
        if (block.includes(w)) {
          const cleaned = block.replace(new RegExp(w, 'g'), '').trim()
          if (cleaned.length >= 2) { topic = cleaned; break }
        }
      }
      if (topic) break
    }
  }
  return topic
}

describe('digest topic clustering', () => {
  it('extracts an English topic from a session title', () => {
    expect(extractTopic('Claude Code Mac订阅流程')).toBe('claude')
  })

  it('extracts a Chinese topic after removing stop words', () => {
    const topic = extractTopic('代码结构可视化工具推荐')
    // 代码/工具/推荐 在停用词表；剩余部分长度 >= 2 即作为主题
    expect(topic).toBeTruthy()
    expect(topic!.length).toBeGreaterThanOrEqual(2)
  })

  it('returns null when title is only stop words', () => {
    expect(extractTopic('deepseek plugin')).toBeNull()
  })

  it('groups sessions by shared English topic', () => {
    const titles = ['Claude Code 配置', 'Claude Code 迁移', 'MCP 服务器设置']
    const groups = new Map<string, number>()
    for (const t of titles) {
      const topic = extractTopic(t)
      if (topic) groups.set(topic, (groups.get(topic) ?? 0) + 1)
    }
    expect(groups.get('claude')).toBe(2)
  })
})
