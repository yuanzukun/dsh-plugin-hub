import { describe, expect, it } from 'vitest'
import { parseListRows } from '../src/index.js'

const SAMPLE = [
  'Total: 3',
  '',
  '[ ] [2026-08-21] [dcd3e074-624] Claude Code Mac订阅流程',
  '[ ] [2026-08-20] [ca1d4529-274] 鲸鱼少女撒娇日常',
  '[ ] [2026-08-18] [6e35e3e7-6db] 代码结构可视化工具推荐',
].join('\n')

describe('parseListRows (exported from plugin)', () => {
  it('parses the CLI list output into rows', () => {
    const rows = parseListRows(SAMPLE)
    expect(rows).toHaveLength(3)
    expect(rows[0]).toMatchObject({ date: '2026-08-21', id: 'dcd3e074-624' })
    expect(rows[0]!.title).toBe('Claude Code Mac订阅流程')
  })

  it('ignores non-row lines (header, blank)', () => {
    expect(parseListRows('Total: 3\n\n')).toHaveLength(0)
  })

  it('handles titles with spaces and CJK', () => {
    const rows = parseListRows('[ ] [2026-08-20] [ca1d4529-274] 鲸鱼少女撒娇日常')
    expect(rows[0]!.title).toBe('鲸鱼少女撒娇日常')
  })

  it('supports keyword filtering used by the list tool', () => {
    const rows = parseListRows(SAMPLE)
    const kw = 'claude'
    const filtered = rows.filter((r) => r.title.toLowerCase().includes(kw))
    expect(filtered).toHaveLength(1)
    expect(filtered[0]!.title).toContain('Claude')
  })
})
