import { describe, expect, it } from 'vitest'
import * as plugin from '../src/index.js'

describe('dsh-deepseek-web', () => {
  it('exports plugin metadata', () => {
    expect(plugin.name).toBe('dsh-deepseek-web')
    expect(plugin.inject).toContain('tools')
  })

  it('has a config schema with defaults', () => {
    const config = plugin.Config({})
    expect(config.pythonPath).toBe('python')
    expect(config.sectionOrder).toBe(10)
  })

  it('accepts explicit config', () => {
    const config = plugin.Config({
      pythonPath: 'python3',
      scriptDir: '/tmp/scripts',
    })
    expect(config.pythonPath).toBe('python3')
    expect(config.scriptDir).toBe('/tmp/scripts')
  })
})
