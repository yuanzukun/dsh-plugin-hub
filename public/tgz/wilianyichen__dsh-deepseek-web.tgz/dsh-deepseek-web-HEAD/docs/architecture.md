# 架构说明

## 总览

```
DSH 内模型调用 deepseek_web_* 工具
  → 插件 spawn python deepseek_client.py <子命令>（子进程）
  → deepseek-ops 脚本（已验证）：urllib 读 / system curl 写 + POW + Cloudflare 退避
  → chat.deepseek.com 私有 API
```

## 关键设计决策

| 决策 | 理由 |
|---|---|
| 子进程调用 Python 而非 TS 重写 | deepseek-ops 的认证（扫码 + Bearer + POW 求解）已实战验证；TS 重写 POW 成本高且易碎 |
| `scriptDir` 可配置 | 不硬编码路径；用户可指向自己的 deepseek-ops 安装 |
| 工具薄封装 | 每个工具 = CLI 参数拼接 + 输出裁剪，DSH 侧零业务逻辑，脚本升级即插件升级 |
| digest 在插件内聚合 | 纯本地文本处理（解析 list 输出按日期分组），无需额外脚本 |

## 工具与 CLI 映射

| 工具 | CLI 调用 |
|---|---|
| deepseek_web_list | `list` + 客户端关键词过滤 |
| deepseek_web_get | `get <sid>` |
| deepseek_web_chat | `chat <target> <prompt> [--no-think] [--search]` |
| deepseek_web_sync | `sync` |
| deepseek_web_search | `deepseek_index.py --query <q>` |
| deepseek_web_digest | `list` + 本地聚合 |
| deepseek_web_share_* | `share create/fork/list` |

## 扩展方向

- qa 工具：对历史会话追问（带上下文）
- daemon 定时 sync + 新会话提醒
- 配置面板（token 状态可视化）
