/**
 * `dsh-deepseek-web`: operate chat.deepseek.com as a programmable agent from
 * inside DeepSeek Harness.
 *
 * Registers tools that drive the battle-tested `deepseek-ops` python client
 * (`deepseek_client.py`) through child-process calls: list/get/chat sessions,
 * share create/fork/list, plus a high-density digest (L1 information density)
 * and index search via `deepseek_index.py`.
 *
 * ```yaml
 * - id: dsh-deepseek-web
 *   name: 'dsh-deepseek-web'
 *   config:
 *     pythonPath: python
 *     scriptDir: D:/data/BaiduSyncdisk/knowledge-lab/生产管线/scripts
 *     defaultThink: true
 *     defaultSearch: false
 * ```
 *
 * @module dsh-deepseek-web
 */

import { spawn } from 'node:child_process'
import z from '@deepseek-ai/schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'

/** Cordis plugin name. */
export const name = 'dsh-deepseek-web'

/** Services this plugin must resolve before it applies. */
export const inject = ['tools', 'systemPrompt']

/** Composition-row configuration. */
export const Config = z.object({
  /** Python executable used to run the deepseek-ops client. */
  pythonPath: z.string().default('python'),
  /** Directory containing deepseek_client.py (the deepseek-ops scripts). */
  scriptDir: z.string().default(''),
  /** Prompt section order. */
  sectionOrder: z.number().default(10),
})

const SECTION_TEXT = 'The `deepseek_web_*` tools read your DeepSeek web archive as a programmable agent: `deepseek_web_list` lists your session history, `deepseek_web_get` downloads a full conversation to local storage, `deepseek_web_sync` archives new conversations, `deepseek_web_search` searches the local session index, `deepseek_web_digest` compresses the whole history into one high-density page with activity bars and topic clusters, `deepseek_web_recent` shows the newest sessions, and `deepseek_web_share_list` lists your share links. Use them when the user wants to revisit, search, summarize, or digest their DeepSeek web conversations. Note: write operations (chat, share creation) are intentionally not exposed — the web client rate-limits them.'

/** Run one deepseek-ops CLI invocation and return its stdout. */
function runClient(
  config: { pythonPath: string; scriptDir: string },
  args: string[],
  signal?: AbortSignal,
): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = spawn(config.pythonPath, args, {
      cwd: config.scriptDir || undefined,
      windowsHide: true,
      signal,
      stdio: ['ignore', 'pipe', 'pipe'],
    })
    let stdout = ''
    let stderr = ''
    child.stdout.on('data', (chunk: Buffer) => { stdout += chunk.toString() })
    child.stderr.on('data', (chunk: Buffer) => { stderr += chunk.toString() })
    child.on('error', (error) => {
      reject(new Error(`deepseek-web: failed to launch python: ${error.message}`))
    })
    child.on('close', (code) => {
      if (code === 0) {
        resolve(stdout)
      } else {
        reject(new Error(`deepseek-web: client exited ${code}: ${stderr.slice(0, 500)}`))
      }
    })
  })
}

/** Helper: build a deepseek-ops CLI invocation. */
function cli(config: { scriptDir: string }, ...args: string[]): string[] {
  return [config.scriptDir ? `${config.scriptDir}/deepseek_client.py` : 'deepseek_client.py', ...args]
}

/** Parse the `list` output format into rows: "[ ] [date] [id12] title". */
export function parseListRows(out: string): { date: string; id: string; title: string }[] {
  const rows: { date: string; id: string; title: string }[] = []
  for (const line of out.split('\n')) {
    const m = line.match(/\[\s*\]\s+\[(\d{4}-\d{2}-\d{2})\]\s+\[([^\]]+)\]\s+(.+)/)
    if (m) rows.push({ date: m[1]!, id: m[2]!, title: m[3]!.trim() })
  }
  return rows
}

/** Rough token estimate: 1 token ≈ 4 chars (en) / ≈ 1.5 chars (CJK). */
export function estimateTokens(text: string): number {
  const cjk = (text.match(/[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]/g) ?? []).length
  const other = text.length - cjk
  return Math.ceil(cjk / 1.5 + other / 4)
}

/**
 * Register the deepseek_web_* tools and the guidance section.
 * @param ctx - registrant context carrying `tools`, `systemPrompt`.
 * @param config - validated plugin configuration.
 */
export function apply(ctx: {
  tools: { register(definition: unknown): unknown }
  systemPrompt?: { addSection(section: { order: number; text: string }): unknown }
}, config: {
  pythonPath: string
  scriptDir: string
  sectionOrder: number
}): void {
  const run = (args: string[], signal?: AbortSignal) =>
    runClient(config, args, signal)

  ctx.tools.register(defineTool({
    name: 'deepseek_web_list',
    description: 'List DeepSeek web sessions (up to 100): title, date, short id. Optional keyword filter applied client-side on title.',
    parameters: {
      keyword: { type: 'string', description: 'Optional keyword to filter sessions by title.' },
      limit: { type: 'integer', description: 'Max rows to show (default 30).' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          text: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: value.text }],
    },
    execute: async (args: { keyword?: string; limit?: number }, exec) => {
      const out = await run(cli(config, 'list'), exec.signal)
      let rows = parseListRows(out)
      if (args.keyword) {
        const kw = args.keyword.toLowerCase()
        rows = rows.filter((r) => r.title.toLowerCase().includes(kw))
      }
      const shown = args.limit && args.limit > 0 ? rows.slice(0, args.limit) : rows
      const blocks = [`Total: ${rows.length}`, '']
      for (const r of shown) blocks.push(`[${r.date}] [${r.id}] ${r.title}`)
      if (rows.length > shown.length) blocks.push(`... and ${rows.length - shown.length} more (raise limit)`)
      return { text: blocks.join('\n') }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'deepseek_web_get',
    description: 'Fetch one DeepSeek web session: downloads the full conversation to local storage (Inbox/deepseek-auto) and returns the sync result. Pass the short session id from deepseek_web_list.',
    parameters: {
      sid: { type: 'string', description: 'Session id (short form from list, e.g. ca732350-584).' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          text: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: value.text }],
    },
    execute: async (args: { sid: string }, exec) => {
      const out = await run(cli(config, 'get', args.sid), exec.signal)
      return { text: out.slice(0, 10_000) }
    },
  }))

  

  ctx.tools.register(defineTool({
    name: 'deepseek_web_sync',
    description: 'Incrementally sync new DeepSeek web conversations to local storage (L0 archive). Run periodically to keep the archive fresh before digest/search.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          text: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: value.text }],
    },
    execute: async (_args, exec) => {
      const out = await run(cli(config, 'sync'), exec.signal)
      return { text: out.slice(0, 10_000) }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'deepseek_web_search',
    description: 'Rebuild then search the local DeepSeek session index by keyword. Returns matching sessions with one-line previews. Requires the deepseek_index.py script in the same directory.',
    parameters: {
      query: { type: 'string', description: 'Search keyword or topic.', required: true },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          text: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: value.text }],
    },
    execute: async (args: { query: string }, exec) => {
      const out = await runClient(config, [
        config.scriptDir ? `${config.scriptDir}/deepseek_index.py` : 'deepseek_index.py',
        '--query', args.query,
      ], exec.signal)
      return { text: out.slice(0, 20_000) }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'deepseek_web_digest',
    description: 'Compress the full DeepSeek web session history into one high-density page: sessions grouped by date, topic titles, and a pick-list of what to revisit. The L1 information-density layer for the 100-session archive.',
    parameters: {
      days: { type: 'integer', description: 'Only sessions updated within the last N days (default 30).' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          text: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: value.text }],
    },
    execute: async (args: { days?: number }, exec) => {
      const out = await run(cli(config, 'list'), exec.signal)
      const rows = parseListRows(out)
      const cutoff = args.days && args.days > 0 ? args.days : 30
      const today = new Date()
      const recent = rows.filter((r) => {
        const diff = (today.getTime() - new Date(r.date).getTime()) / 86_400_000
        return diff <= cutoff
      })
      const byDate = new Map<string, string[]>()
      for (const r of recent) {
        const list = byDate.get(r.date) ?? []
        list.push(`[${r.id}] ${r.title}`)
        byDate.set(r.date, list)
      }
      const dates = [...byDate.keys()].sort().reverse()
      const blocks: string[] = [`# DeepSeek Web Digest (last ${cutoff}d, ${recent.length} sessions)`, '']
      // 活跃度统计：每天会话数直方图
      const maxDay = Math.max(1, ...dates.map((d) => byDate.get(d)!.length))
      blocks.push('## Activity by day')
      for (const date of dates) {
        const count = byDate.get(date)!.length
        const bar = '█'.repeat(Math.max(1, Math.round((count / maxDay) * 20)))
        blocks.push(`- ${date}: ${count} ${bar}`)
      }
      blocks.push('')
      // 主题聚类：从标题提取高频词（英文词 / 中文词组），归并同主题会话
      const topicMap = new Map<string, string[]>()
      const stop = new Set(['deepseek', 'dsh', 'plugin', '使用', '如何', '一个', '这个', '相关', '安装', '配置', '实现', '问题', '代码', '插件', '工具', '分析', '解决', '介绍', '功能', '我们'])
      for (const r of recent) {
        // 英文词逐个提取；中文整串去停用词后作为主题
        const enWords = r.title.match(/[a-zA-Z][a-zA-Z0-9-]{2,}/g) ?? []
        const cnBlocks = r.title.match(/[\u4e00-\u9fff]{2,}/g) ?? []
        let topic: string | null = enWords.map((w) => w.toLowerCase()).find((w) => !stop.has(w)) ?? null
        if (!topic) {
          for (const block of cnBlocks) {
            for (const w of stop) {
              if (block.includes(w)) {
                const cleaned = block.replace(new RegExp(w, 'g'), '').trim()
                if (cleaned.length >= 2) { topic = cleaned; break }
              }
            }
            if (topic) break
          }
        }
        if (topic) {
          const list = topicMap.get(topic) ?? []
          list.push(`[${r.date}] ${r.title}`)
          topicMap.set(topic, list)
        }
      }
      if (topicMap.size > 0) {
        blocks.push('## Topic clusters')
        const topTopics = [...topicMap.entries()].sort((a, b) => b[1].length - a[1].length).slice(0, 10)
        for (const [topic, sessions] of topTopics) {
          blocks.push(`### ${topic} (${sessions.length})`)
          for (const s of sessions.slice(0, 5)) blocks.push(`- ${s}`)
          if (sessions.length > 5) blocks.push(`  ... +${sessions.length - 5} more`)
        }
        blocks.push('')
      }
      // 按日期列出全部会话
      blocks.push('## All sessions')
      for (const date of dates) {
        blocks.push(`### ${date} (${byDate.get(date)!.length})`)
        for (const item of byDate.get(date)!) blocks.push(`- ${item}`)
        blocks.push('')
      }
      blocks.push('## Notes', '- Full content: deepseek_web_get <id>.', '- Keep archive fresh: deepseek_web_sync.')
      const digest = blocks.join('\n')
      return { text: `${digest}\n> ~${estimateTokens(digest)} tokens (CJK-aware estimate)` }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'deepseek_web_recent',
    description: 'Show the N most recently updated DeepSeek web sessions with dates and one-line titles. Lighter than digest for a quick look.',
    parameters: {
      limit: { type: 'integer', description: 'Number of recent sessions to show (default 10).' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          text: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: value.text }],
    },
    execute: async (args: { limit?: number }, exec) => {
      const out = await run(cli(config, 'list'), exec.signal)
      const rows = parseListRows(out)
      const limit = args.limit && args.limit > 0 ? args.limit : 10
      const shown = rows.slice(0, limit)
      const blocks = [`Recent ${shown.length} sessions:`, '']
      for (const r of shown) blocks.push(`[${r.date}] [${r.id}] ${r.title}`)
      return { text: blocks.join('\n') }
    },
  }))

  

  

  ctx.tools.register(defineTool({
    name: 'deepseek_web_share_list',
    description: 'List your DeepSeek web share links with ids and titles.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          text: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: value.text }],
    },
    execute: async (_args, exec) => {
      const out = await run(cli(config, 'share', 'list'), exec.signal)
      return { text: out.slice(0, 10_000) }
    },
  }))

  ctx.systemPrompt?.addSection({ order: config.sectionOrder, text: SECTION_TEXT })
}



