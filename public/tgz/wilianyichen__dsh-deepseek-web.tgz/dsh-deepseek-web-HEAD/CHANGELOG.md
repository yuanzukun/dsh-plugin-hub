# Changelog

## [0.1.0] - 2026-08-21

### Added

- 9 个 `deepseek_web_*` 工具：
  - `deepseek_web_list`：列会话（标题关键词过滤）
  - `deepseek_web_get`：下载会话全文到本地归档
  - `deepseek_web_chat`：发消息（deep-think / web-search 开关）
  - `deepseek_web_sync`：增量同步新会话（L0 存档）
  - `deepseek_web_search`：重建并搜索本地会话索引
  - `deepseek_web_digest`：100 会话 → 一页高密度摘要（信息密度 L1）
  - `deepseek_web_share_create` / `share_fork` / `share_list`
- 通过子进程复用 deepseek-ops Python 脚本（认证 / POW / Cloudflare 保护）
- CI：GitHub Actions build + test
- 测试：配置 schema、CLI 列表解析（7 个）
