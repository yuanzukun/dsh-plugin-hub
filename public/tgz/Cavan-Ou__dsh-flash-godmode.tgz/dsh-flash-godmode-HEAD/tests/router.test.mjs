/**
 * router-core unit tests (node:test, zero deps).
 * Run: node --test tests/router.test.mjs
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'

import {
  bandOf, personaFor, classifyTask, isComplexTask, extractText,
  applyPersona, isFlashModel, GUIDE_DEEP, GUIDE_FAST,
} from '../lib/router-core.mjs'

test('bandOf quantizes to measured bands', () => {
  assert.equal(bandOf(0), 'spec')
  assert.equal(bandOf(0.15), 'spec')
  assert.equal(bandOf(0.2), 'transition')
  assert.equal(bandOf(0.45), 'transition')
  assert.equal(bandOf(0.5), 'react')
  assert.equal(bandOf(1), 'react')
  assert.equal(bandOf('weak'), 'weak')
  assert.equal(bandOf(NaN), 'spec') // clamp to 0
})

test('personaFor weak picks w7 for Flash, w6c for Pro', () => {
  const flash = personaFor('weak', 'deepseek-v4-flash')
  const pro = personaFor('weak', 'deepseek-v4-pro')
  assert.match(flash, /helpful assistant/i)
  assert.match(flash, /decide the task type \(build or fix\)/)
  assert.match(flash, /do not run environment checks/i)
  assert.match(flash, /do not repeat completed steps/i)
  // v0.2: 深度引导句已移出 persona（分派到 guidance section）
  assert.doesNotMatch(flash, /Think deeply about the architecture/)
  assert.match(pro, /software engineer assistant/)
  assert.doesNotMatch(pro, /do not run environment checks/)
})

test('personaFor strong bands', () => {
  assert.equal(personaFor(0, 'x'), 'You are a helpful software engineer assistant.')
  assert.match(personaFor(1, 'x'), /delivers working output fast/)
  assert.match(personaFor(0.3, 'x'), /prefer writing or editing code/)
})

test('classifyTask: react / spec / weak by keywords', () => {
  assert.equal(classifyTask('写一个 Python 脚本'), 1)
  assert.equal(classifyTask('创建新项目'), 1)
  assert.equal(classifyTask('修复这个 bug 并调试'), 0)
  assert.equal(classifyTask('重构并优化模块'), 0)
  assert.equal(classifyTask('你好'), 'weak')
  assert.equal(classifyTask(''), 'weak')
})

test('isComplexTask: length or architecture keywords (author heuristic)', () => {
  assert.equal(isComplexTask('a'.repeat(121)), true)
  assert.equal(isComplexTask('短任务'), false)
  assert.equal(isComplexTask('重构项目架构并全面分析'), true)
  assert.equal(isComplexTask('write analyze.py and run it'), true) // 已知边角：文件名命中 analyze
  assert.equal(isComplexTask(''), false)
  assert.equal(isComplexTask(undefined), false)
})

test('extractText: plain, nested message, empty', () => {
  assert.equal(extractText({ content: [{ type: 'text', text: 'hi' }] }), 'hi')
  assert.equal(extractText({ message: { content: [{ type: 'text', text: 'nested' }] } }), 'nested')
  assert.equal(extractText({ content: [{ type: 'text' }] }), '')
  assert.equal(extractText(null), '')
})

test('applyPersona replaces only persona sections, keeps plan section', () => {
  const sections = [
    { name: 'persona', text: 'old', order: 0 },
    { name: 'plan-mode', text: 'plan rules', order: 5 },
    { name: 'rules', text: 'rules', order: 10 },
  ]
  const out = applyPersona(sections, 'new persona')
  const names = out.map((s) => s.name)
  assert.ok(names.includes('router-persona'))
  assert.ok(names.includes('plan-mode'))
  assert.ok(names.includes('rules'))
  assert.ok(!names.includes('persona'))
  const persona = out.find((s) => s.name === 'router-persona')
  assert.equal(persona.text, 'new persona')
  assert.equal(persona.order, 0)
})

test('isFlashModel detection', () => {
  assert.equal(isFlashModel('deepseek-v4-flash'), true)
  assert.equal(isFlashModel('deepseek-v4-pro'), false)
  assert.equal(isFlashModel(undefined), false)
})

test('guidance variants exist and differ', () => {
  assert.notEqual(GUIDE_DEEP, GUIDE_FAST)
  assert.match(GUIDE_DEEP, /decision or an information need/)
  assert.match(GUIDE_FAST, /commit and act/)
})
