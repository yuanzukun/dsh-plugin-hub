# dsh-flash-godmode

**DeepSeek Harness 的 V4 Flash「神模式」：w7 persona 锚定 + 首轮工具锚定 + 按任务复杂度分派的引导——把 Flash 不稳定的思维链变成可复现的能力。**

![MIT](https://img.shields.io/badge/license-MIT-green)
![DSH](https://img.shields.io/badge/DSH-0.1.0--rc.6-orange)
[![dsh-plugin](https://img.shields.io/badge/GitHub-dsh--plugin-0969da?style=flat-square)](https://github.com/topics/dsh-plugin)

V4 Flash 在 `reasoning: max` 下很强但不稳定：简单任务过度思考、复杂任务思考不足、中途行为飘忽。这个插件把不稳定变成可路由的能力，基于 [dsh-router-standard](https://github.com/yjh051108/dsh-router-standard) 实测的 persona 行为带：

- **w7 persona**（作者实测的 Flash 最优解）——中性身份 + 「先分类再行动」指令 + 回顾/反跑题锚。深度思考句不常驻 persona（作者勘误：相关任务链上逐条深引导是负收益，P21）
- **按复杂度分派的引导**——复杂任务注入决策闭环深引导，简单任务注入快速收敛引导。**首轮请求就生效**，靠一条 headless 可用的捕获路径（见下）
- **首轮工具锚定**——首个请求只见核心工具集（read/write/edit + shell），首次工具调用后放开全目录

**依赖：** DSH 0.1.x（headless profile）+ 任意 `openai-completions` 通道（用 opencode-go 通道 + `deepseek-v4-flash` + `reasoning: max` 构建并实测）。

---

## 为什么捕获路径重要

作者自己的 router 靠 `user/message` 事件读首个用户消息。但在 **headless** 上，这个事件落在首次 prompt 组装**之后**——对路径锁定的首轮请求来说太晚了。本插件改监听 `agent/inbox/spliced` 事件，它在首次组装**之前**就携带任务全文（rc.6 headless 实测）。结果：引导决策在请求 #1 就位——这正是它该在的位置。

## 快速开始

```bash
# bundle 安装（推荐）
dsh plugin --profile headless add github:Cavan-Ou/dsh-flash-godmode

# 验证：跑任意任务，stderr 会打印分派决策
dsh --profile headless "简单任务：运行 python3 -c 'print(1+1)' 并报告输出" 2>&1 | grep godmode
# → [godmode] taskLen=NN complex=false guide=fast mode=weak
```

Flash 模型自动路由到 `weak` 模式（模型 id 检测）；非 Flash 模型回退到关键词任务分类（react/spec/weak）。

## 里面有什么

```
lib/
├── router-core.mjs        # 纯路由逻辑：persona、行为带、复杂度判据、任务分类（零依赖）
└── router-bootstrap.mjs   # Cordis 插件：任务文本捕获、引导分派、工具锚定
tests/
└── router.test.mjs        # node:test 单元测试（11 例）
```

## 实测结果

| 结果 | 证据 |
|---|---|
| **headless 上复杂度分派端到端可用** | 2026-08-18 三个实跑：简单任务 → `guide=fast`（1 步收敛）；重构/架构任务 → `guide=deep`（决策闭环引导，深度分析正常推进）；多轮写+跑任务 → 正确完成且工具锚定未破坏。3/3 通过 |
| **环境检查类空转被抑制** | 2026-08-15 五锚实验：`echo/whoami/uname/node --version/date` 被识别为浪费轮次并抑制（反跑题锚，现已成为工作区 `~/.dsh/AGENTS.md` 全局规则） |
| **真实会话零工具失败** | 观察日志 2026-08-15/16：8 会话、129 次工具调用、0 失败 |
| w7 是实测的 Flash 最优 persona（作者数据） | [dsh-router-standard](https://github.com/yjh051108/dsh-router-standard)：区分度 +5.67（P11）、单任务完成率 100%（P23）、决策闭环深引导深度 +12% 且收敛更快 8.0 vs 8.3 步（P30） |

## 已知边界

- 复杂度判据（文本 >120 字符或架构关键词）是作者原版——`analyze.py` 这类文件名会误判为复杂。误判方向是**安全**的（多给深引导，不是不给）
- 未来 DSH 版本若 `agent/inbox/spliced` 捕获失效，插件回退为裸 w7 persona（无引导）——按 P23 安全，任务照常跑
- 上表作者数据全部来自 DeepSeek 官方 API；本插件在 opencode-go 通道实测（同权重不同 serving）——见表格里的本地实跑

## 与 dsh-routing-suite 的关系

[dsh-routing-suite](https://github.com/yjh051108/dsh-routing-suite) 是作者的完整套装（运行时注入器 + 路由预设），面向 **web profile**（PowerShell 安装器、每会话手动选预设）。本插件是 **headless 原生**的单插件形态：`dsh plugin add` 直接装、无安装脚本、headless 首轮引导生效（套装自己的 issue 里也记录了 rc.6 上逐条引导不生效）。

## 贡献

这个插件靠真实使用长大。遇到清单里没有的边界？开 issue 带上事故现场（症状 → 根因 → 对策）。中英文 PR 都欢迎。

## License

MIT——致谢 [dsh-router-standard](https://github.com/yjh051108/dsh-router-standard)（MIT），本插件构建在其实测 persona 行为带与引导文本之上。

---

*不是读文档写出来的，是在 headless 上跑真实任务跑出来的。*
