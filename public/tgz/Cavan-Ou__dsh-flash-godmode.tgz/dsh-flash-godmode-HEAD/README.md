# dsh-flash-godmode

**V4 Flash "god mode" for DeepSeek Harness: w7 persona anchoring + first-turn tool anchoring + complexity-dispatched guidance — turn Flash's unstable thinking into reproducible capability.**

![MIT](https://img.shields.io/badge/license-MIT-green)
![DSH](https://img.shields.io/badge/DSH-0.1.0--rc.6-orange)
[![dsh-plugin](https://img.shields.io/badge/GitHub-dsh--plugin-0969da?style=flat-square)](https://github.com/topics/dsh-plugin)

> 简体中文版见 [README.zh.md](README.zh.md)

V4 Flash on `reasoning: max` is powerful but unstable: it over-thinks simple tasks, under-thinks complex ones, and drifts mid-session. This plugin turns that instability into a routed capability, using the measured persona bands from [dsh-router-standard](https://github.com/yjh051108/dsh-router-standard):

- **w7 persona** (author-measured Flash optimum) — neutral identity + classify-then-act instruction + recall/anti-runaway anchors. No deep-thinking sentence baked in (author's correction: per-message guidance is negative on related-task chains, P21).
- **Complexity-dispatched guidance** — complex tasks get the decision-closure deep guide, simple tasks get the fast-convergence guide. Dispatched **on the very first request**, thanks to a capture path that works on headless (see below).
- **First-turn tool anchoring** — the first request sees only the core tool set (read/write/edit + shell); after the first durable tool call the full catalog is exposed.

**Dependencies:** DSH 0.1.x (headless profile) + any `openai-completions` provider (built and tested with the opencode-go channel, `deepseek-v4-flash`, `reasoning: max`).

---

## Why the capture path matters

The author's own router reads the first user message via `user/message` events. On **headless**, that event lands *after* the first prompt assembly — too late for the path-committing first request. This plugin listens for `agent/inbox/spliced` instead, which carries the task text **before** the first assembly (verified on rc.6 headless). Result: the guidance decision is present on request #1, where it counts.

## Quick start

```bash
# bundle install (recommended)
dsh plugin --profile headless add github:Cavan-Ou/dsh-flash-godmode

# verify: run any task; stderr shows the dispatch decision
dsh --profile headless "简单任务：运行 python3 -c 'print(1+1)' 并报告输出" 2>&1 | grep godmode
# → [godmode] taskLen=NN complex=false guide=fast mode=weak
```

Flash models are routed to `weak` mode automatically (model-id detection). Non-Flash models fall back to keyword task classification (react/spec/weak).

## What's inside

```
lib/
├── router-core.mjs        # pure routing logic: personas, bands, complexity heuristic, task classification (zero deps)
└── router-bootstrap.mjs   # Cordis plugin: task-text capture, guidance dispatch, tool anchoring
tests/
└── router.test.mjs        # node:test unit tests (11 cases)
```

## Observed results

| Result | Evidence |
|---|---|
| **Complexity dispatch works end-to-end on headless** | 2026-08-18, three real runs: simple task → `guide=fast` (1-step convergence); refactor/architecture task → `guide=deep` (decision-closure guide, deep analysis proceeded); multi-turn write+run task → completed correctly with tool anchoring intact. 3/3 passed |
| **Environment-check rumination suppressed** | 2026-08-15 five-anchor experiment: `echo/whoami/uname/node --version/date` calls recognized as wasted turns and suppressed via the anti-runaway anchor (now also a global rule in the workspace's `~/.dsh/AGENTS.md`) |
| **Zero tool failures across real sessions** | Observation journal, 2026-08-15/16: 8 sessions, 129 tool calls, 0 failures |
| w7 persona is the measured Flash optimum (author-published) | [dsh-router-standard](https://github.com/yjh051108/dsh-router-standard): discrimination +5.67 (P11), single-task completion 100% (P23), decision-closure deep guide: depth +12% with faster convergence 8.0 vs 8.3 steps (P30) |

## Known edges

- The complexity heuristic (`text.length > 120` or architecture keywords) is the author's original — a filename like `analyze.py` counts as complex. False positives lean toward the *safe* direction (deep guide, not no guide).
- If the `agent/inbox/spliced` capture fails on a future DSH version, the plugin falls back to the bare w7 persona (no guidance) — safe per P23, and the task still runs.
- All author-measured numbers above come from the official DeepSeek API; this plugin was verified on the opencode-go channel (same weights, different serving) — see the local runs in the table.

## Relationship to dsh-routing-suite

[dsh-routing-suite](https://github.com/yjh051108/dsh-routing-suite) is the author's full kit (runtime injector + router presets) aimed at the **web profile** (PowerShell installer, preset selection per session). This plugin is the **headless-native** single-plugin form: installable via `dsh plugin add`, no installer script, first-request guidance on headless (which the suite's own issue tracker flags as not taking effect on rc.6).

## Contributing

This plugin grows from real use. Hit an edge not listed here? Open an issue with the incident (symptom → root cause → fix). PRs welcome in Chinese or English.

## License

MIT — with attribution to [dsh-router-standard](https://github.com/yjh051108/dsh-router-standard) (MIT), whose measured persona bands and guidance texts this plugin builds on.

---

*Built by running real tasks on headless, not by reading docs.*
