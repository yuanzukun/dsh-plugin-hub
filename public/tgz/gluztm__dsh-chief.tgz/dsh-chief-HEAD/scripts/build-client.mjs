#!/usr/bin/env node
/**
 * Zero-dependency deterministic ES-module bundler for `pkg/src/client/`.
 *
 * Collects modules starting from `src/client/entry.js`, verifies syntax via
 * `node --check`, enforces strict acyclic imports and unique top-level symbols,
 * and emits `pkg/client.js` wrapped in `window.__ModuleLoader__.load`.
 */
import { execFileSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const PKG_DIR = path.resolve(__dirname, '..')
const SRC_ROOT = path.join(PKG_DIR, 'src', 'client')
const ENTRY_FILE = path.join(SRC_ROOT, 'entry.js')
const OUT_FILE = path.join(PKG_DIR, 'client.js')
const CHECK_ONLY = process.argv.includes('--check')

function fail(msg) {
  console.error('[build-client] ERROR:', msg)
  process.exit(1)
}

if (!fs.existsSync(ENTRY_FILE)) {
  fail(`Entry file not found: ${ENTRY_FILE}`)
}

function parseModule(filePath) {
  execFileSync(process.execPath, ['--check', filePath], { stdio: 'pipe' })
  const src = fs.readFileSync(filePath, 'utf8').replace(/\r\n/g, '\n')
  const relDir = path.dirname(filePath)
  const imports = []
  const importedFromMap = []

  // Match static ESM import declarations (single or multi-line)
  const importRe = /(?:^|\n)import\s*\{([\s\S]*?)\}\s*from\s*['"](\.[^'"]+)['"][ \t]*;?[ \t]*(?=\n|$)/g
  let m
  while ((m = importRe.exec(src)) !== null) {
    const names = m[1]
      .split(',')
      .map(s => s.trim())
      .filter(Boolean)
      .map(s => s.split(/\s+as\s+/)[0].trim())
    const target = path.resolve(relDir, m[2])
    imports.push({ raw: m[0], target, names })
    importedFromMap.push({ target, names })
  }

  // Track exported symbols from this module
  const exportsSet = new Set()
  const exportDeclRe = /(?:^|\n)export\s+(?:async\s+)?(?:function|const|let|var|class)\s+([A-Za-z0-9_$]+)/g
  while ((m = exportDeclRe.exec(src)) !== null) {
    exportsSet.add(m[1])
  }
  const exportListRe = /(?:^|\n)export\s*\{([\s\S]*?)\}[ \t]*;?[ \t]*(?=\n|$)/g
  while ((m = exportListRe.exec(src)) !== null) {
    for (const part of m[1].split(',')) {
      const clean = part.trim()
      if (!clean) continue
      const alias = clean.split(/\s+as\s+/).pop().trim()
      exportsSet.add(alias)
    }
  }

  // Strip import / export syntax for bundling inside factory(require)
  let body = src
  body = body.replace(/(?:^|\n)import\s*\{[\s\S]*?\}\s*from\s*['"]\.[^'"]+['"][ \t]*;?[ \t]*(?=\n|$)/g, '')
  body = body.replace(/(?:^|\n)export\s*\{[\s\S]*?\}[ \t]*;?[ \t]*(?=\n|$)/g, '')
  body = body.replace(/(^|\n)export\s+(?=(?:async\s+)?(?:function|const|let|var|class)\s+)/g, '$1')
  // Trim leading header JSDoc if present at very start, keep inner comments
  body = body.replace(/^\n+/, '').replace(/\n+$/, '')

  return {
    filePath,
    relName: path.relative(SRC_ROOT, filePath).replace(/\\/g, '/'),
    src,
    imports: importedFromMap,
    exportsSet,
    body,
  }
}

const modules = new Map()
const topoOrder = []
const visitState = new Map() // 0/undef=unvisited, 1=visiting, 2=done

function visit(filePath, stack = []) {
  const norm = path.resolve(filePath)
  const st = visitState.get(norm) || 0
  if (st === 1) {
    const cycle = [...stack, path.relative(SRC_ROOT, norm)].join(' -> ')
    fail(`Circular dependency in src/client: ${cycle}`)
  }
  if (st === 2) return
  if (!fs.existsSync(norm)) {
    fail(`Missing imported module: ${norm} (from ${stack[stack.length - 1] || 'root'})`)
  }
  visitState.set(norm, 1)
  const mod = parseModule(norm)
  modules.set(norm, mod)
  for (const imp of mod.imports) {
    visit(imp.target, [...stack, mod.relName])
    const targetMod = modules.get(path.resolve(imp.target))
    for (const sym of imp.names) {
      if (!targetMod.exportsSet.has(sym)) {
        fail(`Module ${mod.relName} imports missing export "${sym}" from ${targetMod.relName}`)
      }
    }
  }
  visitState.set(norm, 2)
  topoOrder.push(norm)
}

visit(ENTRY_FILE, [])

// Verify zero duplicate top-level declarations across all bundled modules
const declOwners = new Map()
for (const modPath of topoOrder) {
  const mod = modules.get(modPath)
  if (mod.relName === 'react-runtime.js') continue
  const lines = mod.body.split('\n')
  for (let i = 0; i < lines.length; i += 1) {
    const dm = lines[i].match(/^(?:async\s+)?(?:function|const|let|var|class)\s+([A-Za-z0-9_$]+)/)
    if (!dm) continue
    const sym = dm[1]
    if (declOwners.has(sym)) {
      fail(`Duplicate client top-level symbol "${sym}" in ${mod.relName} (already declared in ${declOwners.get(sym)})`)
    }
    declOwners.set(sym, mod.relName)
  }
}

// Enforce synchronized backend & client version constants
const schemaPath = path.join(PKG_DIR, 'board-schema.js')
const constPath = path.join(SRC_ROOT, 'constants.js')
const backendBuildMatch = fs.readFileSync(schemaPath, 'utf8').match(/export\s+const\s+BACKEND_BUILD\s*=\s*['"]([^'"]+)['"]/)
const frontendBuildMatch = fs.readFileSync(constPath, 'utf8').match(/export\s+const\s+EXPECTED_BACKEND_BUILD\s*=\s*['"]([^'"]+)['"]/)
const backendBuildVal = backendBuildMatch ? backendBuildMatch[1].trim() : ''
const frontendBuildVal = frontendBuildMatch ? frontendBuildMatch[1].trim() : ''
if (!backendBuildVal || !frontendBuildVal) {
  fail(`Missing version constant: BACKEND_BUILD=${backendBuildVal || '(empty)'} EXPECTED_BACKEND_BUILD=${frontendBuildVal || '(empty)'}`)
}
if (backendBuildVal !== frontendBuildVal) {
  fail(`Version mismatch: board-schema.js BACKEND_BUILD="${backendBuildVal}" !== src/client/constants.js EXPECTED_BACKEND_BUILD="${frontendBuildVal}"`)
}

const parts = []
parts.push(
  '/**',
  ` * Client half of dsh-chief — 「DSH 参谋长」 (DSH Chief v${backendBuildVal})`,
  ' * Auto-generated by `pkg/scripts/build-client.mjs` from `pkg/src/client/`.',
  ' * Do not hand-edit this generated bundle; edit source modules under `pkg/src/client/` and rebuild.',
  ' *',
  ' * Surfaces:',
  ' *   1. `sidebar.right.pane.tab` (docked right-hand sidebar tab — primary)',
  ' *   2. `main` + `sidebar.panellist` (full-page fallback)',
  ' *   3. `shell.overlay` (floating sheet fallback)',
  ' */',
  'window.__ModuleLoader__.load({',
  "  id: 'dsh-chief',",
  '  factory(require) {',
)

const hasReactRuntime = topoOrder.some(p => modules.get(p).relName === 'react-runtime.js')
if (hasReactRuntime) {
  parts.push("    const React = require('react')")
  parts.push('    const h = React.createElement')
  parts.push('')
}

for (const modPath of topoOrder) {
  const mod = modules.get(modPath)
  if (mod.relName === 'react-runtime.js') continue
  parts.push(`    // === [module: src/client/${mod.relName}] ===`)
  for (const line of mod.body.split('\n')) {
    parts.push(line === '' ? '' : `    ${line}`)
  }
  parts.push('')
}

parts.push('    return createClientPlugin()')
parts.push('  },')
parts.push('})')

const built = parts.join('\n') + '\n'

if (CHECK_ONLY) {
  if (!fs.existsSync(OUT_FILE)) {
    fail(`Output file ${OUT_FILE} does not exist`)
  }
  const onDisk = fs.readFileSync(OUT_FILE, 'utf8').replace(/\r\n/g, '\n')
  if (onDisk !== built) {
    fail(`pkg/client.js is out of sync with pkg/src/client/ (run \`node pkg/scripts/build-client.mjs\`)`)
  }
  console.log(`CLIENT_BUILD_CHECK OK (modules=${topoOrder.length}, decls=${declOwners.size}, bytes=${Buffer.byteLength(built, 'utf8')})`)
} else {
  fs.writeFileSync(OUT_FILE, built, 'utf8')
  execFileSync(process.execPath, ['--check', OUT_FILE], { stdio: 'pipe' })
  console.log(`Built pkg/client.js from ${topoOrder.length} modules (${built.split('\n').length} lines, ${Buffer.byteLength(built, 'utf8')} bytes)`)
}
