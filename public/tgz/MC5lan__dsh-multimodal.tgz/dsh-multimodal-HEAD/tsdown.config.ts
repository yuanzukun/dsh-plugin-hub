import { defineConfig } from 'tsdown'

// Browser client bundle for the "Multimodal" settings section. The artifact
// registers itself through window.__ModuleLoader__.load({id, factory}), the
// format dsh-client-modules serves from /plugins/<id>/client.js. React and
// the cordis runtime come from the platform module table (external); our
// client code imports nothing else at runtime (types are erased).
export default defineConfig({
  name: 'dsh-multimodal/client',
  entry: { client: 'src/client/index.tsx' },
  outDir: 'lib',
  format: 'cjs',
  platform: 'browser',
  dts: false,
  sourcemap: true,
  clean: false,
  external: ['react', 'react/jsx-runtime', '@deepseek-ai/cordis'],
  outputOptions: {
    entryFileNames: 'client.js',
    banner: 'window.__ModuleLoader__.load({ id: "dsh-multimodal", factory: (require) => {',
    footer: 'return module.exports; } });',
    intro: 'var module = { exports: {} }; var exports = module.exports;',
  },
})
