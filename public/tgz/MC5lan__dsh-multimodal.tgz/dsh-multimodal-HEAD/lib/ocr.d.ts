/**
 * `extract_text` — explicit OCR/transcription tool. Reads the most recent
 * image in the current conversation and extracts its text through a
 * configurable OCR/vision provider (any user-declared endpoint), returning
 * Markdown / plain text / JSON.
 *
 * Complements the automatic pre-step transcription: use it when you want the
 * raw text of a document, screenshot, table, or form, or a structured
 * extraction — without routing the whole step through the vision engine.
 */
import type { Context } from '@deepseek-ai/cordis';
export interface OcrSettings {
    provider: string;
    model: string;
    timeoutMs: number;
}
export declare function registerOcrTool(ctx: Context, settings: () => OcrSettings, resolveKey: (ref: string) => Promise<string>): void;
