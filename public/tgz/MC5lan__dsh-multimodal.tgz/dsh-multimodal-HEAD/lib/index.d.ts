/**
 * dsh-multimodal — multimodal eyes and hands for DeepSeek Harness.
 *
 * - `deepseek-vision`: same DeepSeek API, models advertised with image
 *   modality so the host allows attachments; images never reach DeepSeek.
 * - `extraProviders`: any OpenAI-compatible vision endpoint the user declares
 *   (Xfyun MaaS, ModelScope, SiliconFlow, ...) — dynamically registered.
 * - The eye: `agent/pre-step` transcribes image-carrying inputs through the
 *   configured vision provider, then DeepSeek keeps processing the problem.
 * - `generate_image`: text-to-image through a configurable backend
 *   (DashScope async protocol, or OpenAI-compatible /images/generations).
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "dsh-multimodal";
export declare const inject: string[];
export declare const NS: import("@deepseek-ai/dsh-settings").SettingsNamespace;
export declare const DEEPSEEK_PROVIDER = "deepseek-vision";
export interface ExtraProviderConfig {
    displayName: string;
    baseURL: string;
    apiKeyEnv: string;
    reasoning: 'deepseek' | 'glm';
    models: Array<{
        id: string;
        name?: string;
        description?: string;
        contextWindow?: number;
    }>;
}
/** A user-declared vision model on one of the built-in route slots. */
export interface VisionModelConfig {
    id: string;
    name?: string;
    description?: string;
    contextWindow?: number;
    maxTokens?: number;
}
export interface ImageBackendConfig {
    kind: 'dashscope' | 'dashscope-v2' | 'openai-images' | 'custom';
    baseURL: string;
    apiKeyEnv: string;
    model: string;
    defaultSize: string;
    /** Custom adapter file (.mjs) for kind: 'custom' (feature 2026-08-16). */
    adapterFile?: string;
    /** Polling tuning for async-task backends (default 2000ms / 120000ms). */
    pollIntervalMs?: number;
    pollTimeoutMs?: number;
}
export interface Config {
    providers: {
        deepseek: {
            baseURL: string;
            apiKeyEnv: string;
            models: VisionModelConfig[];
        };
        glm: {
            baseURL: string;
            apiKeyEnv: string;
            model: string;
            models: VisionModelConfig[];
        };
        dashscope: {
            baseURL: string;
            apiKeyEnv: string;
        };
    };
    extraProviders: Record<string, ExtraProviderConfig>;
    /** Audit fix (2026-08-15): only these env/credential names may be read as an API key. */
    allowedApiKeyEnvs: string[];
    /** Audit fix (2026-08-15): extra hosts (besides known official ones) allowed to receive credentials. */
    trustedBaseUrls: string[];
    vision: {
        /** Provider route whose sessions get the eye (blank-slate: point it at any provider you configure). */
        watchProvider: string;
        transcribeProvider: string;
        transcribeModel?: string;
        /** Fallback vision providers tried in order when the primary fails. */
        fallbackProviders?: string[];
        /** 'auto' (route by image type) or a fixed verbatim/structured/ocr/describe/scene mode. */
        transcribeMode?: 'auto' | 'verbatim' | 'structured' | 'ocr' | 'describe' | 'error-fix' | 'chart-sql' | 'design-code';
        /** Custom mode name → prompt pairs (transcriber plugin-in, feature 2026-08-16). */
        customModes?: Record<string, string>;
        /** Transcribe each image in its own parallel call (feature 2026-08-16). */
        parallelImages?: boolean;
        /** Cheap provider for small images (cost routing). */
        costProvider?: string;
        costModel?: string;
        costMaxPixels?: number;
        /** Append a scene hint to screenshots. */
        sceneHints?: boolean;
        /** Mask phone/id/email in transcription output. */
        redactSensitive?: boolean;
        /** Log an audit line per transcription. */
        auditLog?: boolean;
        transcribePrompt: string;
        transcribeTimeoutMs: number;
    };
    ocr: {
        provider: string;
        model: string;
    };
    image: {
        backends: Record<string, ImageBackendConfig>;
        activeBackend: string;
        /** Backend keys tried in order when the active backend request fails (feature 2026-08-16). */
        failoverOrder: string[];
        /** Verify Chinese text in generated images via a vision model (feature 2026-08-16). */
        verifyChineseText: boolean;
        verifyProvider: string;
        verifyModel: string;
    };
    streamIdleTimeoutMs: number;
}
export declare const Config: z<Config>;
/** Whether an extra-provider baseURL may receive credentials. */
export declare function isAllowedExtraBaseUrl(baseURL: string, trusted: string[]): boolean;
/**
 * Lightweight structural validation of the runtime config. The schemastery
 * defaults catch most issues at write time; this guards the fields that a
 * malicious settings payload could otherwise bend.
 */
export declare function validateConfig(raw: Config): void;
/** Empty by design (v0.3.1): the plugin is a blank slate — models are declared
 * by the user through `providers.*.models` or `extraProviders`, not baked in. */
export declare function apply(ctx: Context, config: Config): void;
