/**
 * `generate_image` — text-to-image via Aliyun Bailian (DashScope) wanx
 * models. The tool submits an async synthesis task, polls it to completion,
 * downloads the result bytes into the durable attachment store, and injects
 * the image into the session so the user sees it in the conversation.
 */
import type { Context } from '@deepseek-ai/cordis';
export interface ImageBackendSettings {
    /** DashScope async-task protocol, DashScope multimodal-generation sync, OpenAI-compatible /images/generations, or a custom adapter file. */
    kind: 'dashscope' | 'dashscope-v2' | 'openai-images' | 'custom';
    baseURL: string;
    apiKeyEnv: string;
    model: string;
    defaultSize: string;
    pollIntervalMs: number;
    pollTimeoutMs: number;
    /** Adapter file path for kind: 'custom'. */
    adapterFile?: string;
}
/**
 * Contract for a user-supplied custom image backend (feature 2026-08-16).
 * Write an ES module (.mjs) exporting a default object with `generate()`.
 * Only load files you trust — the adapter runs with full process privileges.
 */
export interface CustomImageBackendAdapter {
    generate(req: {
        prompt: string;
        size: string;
        n: number;
        negative_prompt?: string;
        /** Reference image for image-to-image: http(s) URL or base64 data URL. */
        reference_image?: string;
        apiKey: string;
        baseURL: string;
        model: string;
        signal: AbortSignal;
        fetch: typeof fetch;
        log: (message: string) => void;
    }): Promise<{
        urls?: string[];
        b64s?: string[];
    }>;
}
export interface ImageGenSettings {
    backend: ImageBackendSettings;
    /** Key of the active backend (for error/labels). */
    activeBackendKey?: string;
    /** Fallback backends tried in order when the primary backend request fails (feature 2026-08-16). */
    failovers?: ImageBackendSettings[];
    /** Chinese-text garbling verification after generation (feature 2026-08-16). */
    verify?: {
        enabled: boolean;
        provider: string;
        model: string;
    };
}
export declare const DEFAULT_IMAGE_GEN_PROMPT_HINT = "\u751F\u6210\u56FE\u7247\u65F6\u8BF7\u628A\u7528\u6237\u610F\u56FE\u7FFB\u8BD1\u4E3A\u8BE6\u7EC6\u3001\u5177\u4F53\u7684\u753B\u9762\u63CF\u8FF0(prompt),\u5305\u542B\u4E3B\u4F53\u3001\u573A\u666F\u3001\u98CE\u683C\u3001\u5149\u7EBF\u7B49\u8981\u7D20\u3002";
declare function isPublicHttpUrl(url: string): boolean;
/** Exported for unit tests. */
export { isPublicHttpUrl };
export declare function registerImageGenTool(ctx: Context, settings: () => ImageGenSettings, resolveKey: (ref: string, route: string) => Promise<string>): void;
interface ImageGenImageValue {
    attachmentId: string;
    mediaType: 'image/png' | 'image/jpeg' | 'image/webp';
    bytes: number;
    width: number;
    height: number;
    name?: string;
}
export type { ImageGenImageValue };
