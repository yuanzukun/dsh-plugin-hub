/**
 * Wire serialization and SSE translation for OpenAI-compatible chat
 * completions endpoints (DeepSeek public API and Zhipu GLM).
 *
 * Image blocks become inline base64 `image_url` parts; the DeepSeek route
 * skips them instead (vision content is transcribed to text before that
 * route is ever asked, so any image seen here is history replay residue).
 */
import type { ContentBlock, GenerateOptions, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
/** Read the durable bytes behind one image reference. */
export type ReadImage = (ref: ImageAttachmentRef, signal?: AbortSignal) => Promise<Uint8Array>;
export type ImageMode = 'data-url' | 'skip';
export interface ReasoningWire {
    /** DeepSeek wire pair: `thinking` + `reasoning_effort`. */
    deepseek?: {
        thinking: 'enabled' | 'disabled';
        effort?: 'high' | 'max';
    };
    /** GLM wire switch: `thinking: { type: 'enabled' }`. */
    glmEnabled?: boolean;
}
export declare function hasImage(blocks: readonly ContentBlock[]): boolean;
export declare function countImages(blocks: readonly ContentBlock[]): number;
interface WireMessage {
    role: string;
    content: unknown;
    [key: string]: unknown;
}
/** Serialize the harness conversation into OpenAI-compatible wire messages. */
export declare function serializeMessages(messages: readonly GenerateOptions['messages'][number][], mode: ImageMode, readImage: ReadImage, signal?: AbortSignal): Promise<WireMessage[]>;
/** Resolve the reasoning wire fields for one route family. */
export declare function resolveReasoning(options: GenerateOptions, family: 'deepseek' | 'glm'): ReasoningWire;
/** Build the full wire request body. Always streaming with usage on. */
export declare function serializeRequest(options: GenerateOptions, opts: {
    imageMode: ImageMode;
    reasoning: ReasoningWire;
    readImage: ReadImage;
}, signal?: AbortSignal): Promise<Record<string, unknown>>;
/**
 * Consume SSE data payloads (`[DONE]`-terminated) and yield StreamChunks.
 * Block-ends, usage, and finish are deferred until the sentinel, so usage
 * always precedes the terminal finish.
 */
export declare function translate(payloads: AsyncIterable<string>): AsyncIterable<StreamChunk>;
export {};
