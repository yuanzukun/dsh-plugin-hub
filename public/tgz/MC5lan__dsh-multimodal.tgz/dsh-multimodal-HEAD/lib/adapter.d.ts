/**
 * One OpenAI-compatible chat-completions adapter, parameterized per route.
 * Used for both `deepseek-vision` (text wire, images skipped defensively)
 * and `glm-vision` (images inline as base64 data URLs).
 */
import { LlmAdapter, type GenerateOptions, type LlmModelInfo, type LlmProviderInfo, type LlmResolvedModelInfo, type StreamChunk } from '@deepseek-ai/dsh-llm';
import { type ReadImage } from './wire.js';
export interface VisionModelSpec {
    id: string;
    name?: string;
    description?: string;
    contextWindow?: number;
    maxTokens?: number;
}
export interface RouteSpec {
    provider: string;
    displayName: string;
    /** Endpoint root; `/chat/completions` is appended. */
    baseURL: string;
    apiKeyEnv: string;
    /** Which reasoning family the wire speaks. */
    reasoning: 'deepseek' | 'glm';
    /** Images inline (glm) or skipped (deepseek defensive). */
    imageMode: 'data-url' | 'skip';
    streamIdleTimeoutMs: number;
    models: VisionModelSpec[];
    /** Durable image byte source (attachment service). */
    readImage: ReadImage;
}
export declare function httpErrorCode(status: number): string;
export declare class OpenAICompatibleAdapter extends LlmAdapter {
    private readonly route;
    private readonly resolveKey;
    private readonly resolveUserId;
    constructor(route: RouteSpec, resolveKey: (ref: string) => Promise<string>, resolveUserId: () => string);
    providerInfo(provider: string): LlmProviderInfo;
    providerRetryPolicy(): undefined;
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string): Promise<LlmResolvedModelInfo>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
    private request;
}
