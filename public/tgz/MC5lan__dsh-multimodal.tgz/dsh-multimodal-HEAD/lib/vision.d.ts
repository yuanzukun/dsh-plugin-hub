/**
 * The all-seeing eye: when a step's input carries images on the
 * `watchProvider` route, transcribe them through the configured vision route
 * into exact text, then hand the rewritten (image-free) input to the main
 * provider so it keeps doing the actual work. The transcription is
 * model-visible and lands in the durable session log through the loop's
 * normal entered-message path.
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ContentBlock } from '@deepseek-ai/dsh-llm';
export interface VisionSettings {
    /** Provider route whose sessions get the eye (blank-slate: any provider the user configures). */
    watchProvider: string;
    /** Route that does the seeing (must be a provider the user has registered). */
    transcribeProvider: string;
    /** Model id used for transcription; falls back to the route default. */
    transcribeModel?: string;
    /** Fallback vision providers tried in order when the primary fails/rate-limits. */
    fallbackProviders?: string[];
    /** How to transcribe: fixed mode, or 'auto' (route by image type). */
    transcribeMode?: TranscribeMode;
    /** Custom (plugin-in) mode name → prompt pairs (feature 2026-08-16). */
    customModes?: Record<string, string>;
    /** Transcribe each image in its own parallel call instead of one batch (feature 2026-08-16). */
    parallelImages?: boolean;
    /** Cheap provider used for small images when cost routing is enabled. */
    costProvider?: string;
    /** Model id on the cheap provider (defaults to its route default). */
    costModel?: string;
    /** Images at or below this many pixels use the cheap provider. */
    costMaxPixels?: number;
    /** Append a scene hint line to screenshots (feature 2026-08-16). */
    sceneHints?: boolean;
    /** Transcription instruction shown to the vision model. */
    transcribePrompt: string;
    /** Redact phone/id/email in transcription output (feature 2026-08-16). */
    redactSensitive?: boolean;
    /** Log an audit line for every transcription (feature 2026-08-16). */
    auditLog?: boolean;
    /** Abort transcription after this many ms. */
    transcribeTimeoutMs: number;
}
/** Mask mainland phone numbers, 18-digit IDs, and email addresses in text. */
export declare function redactSensitiveText(text: string): string;
export declare const TRANSCRIBE_MODES: readonly ["auto", "verbatim", "structured", "ocr", "describe", "error-fix", "chart-sql", "design-code"];
export type TranscribeMode = (typeof TRANSCRIBE_MODES)[number];
export declare const DEFAULT_TRANSCRIBE_PROMPT: string;
export declare const STRUCTURED_TRANSCRIBE_PROMPT: string;
export declare const OCR_TRANSCRIBE_PROMPT: string;
export declare const DESCRIBE_TRANSCRIBE_PROMPT: string;
export declare const ERROR_FIX_PROMPT: string;
export declare const CHART_SQL_PROMPT: string;
export declare const DESIGN_CODE_PROMPT: string;
export declare const MODE_PROMPTS: Record<Exclude<TranscribeMode, 'auto'>, string>;
/**
 * Lightweight image-type classifier (feature 2026-08-16): picks the
 * transcription strategy for `transcribeMode: 'auto'`. Heuristics only — no
 * pixel decoding; good enough to route screenshots vs documents vs photos.
 */
export type ImageKind = 'screenshot' | 'document' | 'photo';
export declare function classifyImage(width: number, height: number): ImageKind;
type ImageBlock = Extract<ContentBlock, {
    type: 'image';
}>;
export declare function recentImagesFor(sessionId: string): readonly ImageBlock[];
export declare function recordKindForSession(sessionId: string, kind: ImageKind): void;
export declare function sessionKindStatsFor(sessionId: string): Readonly<Record<ImageKind, number>>;
export declare function installVision(ctx: Context, settings: () => VisionSettings): void;
export {};
