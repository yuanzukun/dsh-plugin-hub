import { describe, expect, it } from 'vitest'
import { isPublicHttpUrl } from '../src/image-gen.ts'
import { isAllowedExtraBaseUrl, validateConfig } from '../src/index.ts'
import { classifyImage, redactSensitiveText } from '../src/vision.ts'

describe('isPublicHttpUrl (SSRF guard)', () => {
  it('allows public hosts', () => {
    expect(isPublicHttpUrl('https://dashscope.aliyuncs.com/x.png')).toBe(true)
    expect(isPublicHttpUrl('http://example.com/a.jpg')).toBe(true)
    expect(isPublicHttpUrl('https://cdn.example.com/path/img.webp?x=1')).toBe(true)
  })

  it('rejects loopback hosts', () => {
    expect(isPublicHttpUrl('http://localhost:8000/x.png')).toBe(false)
    expect(isPublicHttpUrl('http://127.0.0.1/x.png')).toBe(false)
    expect(isPublicHttpUrl('http://0.0.0.0/x.png')).toBe(false)
    expect(isPublicHttpUrl('http://[::1]/x.png')).toBe(false)
  })

  it('rejects private RFC1918 ranges', () => {
    expect(isPublicHttpUrl('http://10.0.0.1/x.png')).toBe(false)
    expect(isPublicHttpUrl('http://192.168.1.1/x.png')).toBe(false)
    expect(isPublicHttpUrl('http://172.16.0.1/x.png')).toBe(false)
    expect(isPublicHttpUrl('http://172.20.5.5/x.png')).toBe(false)
    expect(isPublicHttpUrl('http://172.31.255.255/x.png')).toBe(false)
    expect(isPublicHttpUrl('http://172.32.0.1/x.png')).toBe(true)
  })

  it('rejects link-local and unique-local addresses', () => {
    expect(isPublicHttpUrl('http://169.254.1.1/x.png')).toBe(false)
    expect(isPublicHttpUrl('http://fe80::1/x.png')).toBe(false)
    expect(isPublicHttpUrl('http://fc00::1/x.png')).toBe(false)
    expect(isPublicHttpUrl('http://fd12:3456::1/x.png')).toBe(false)
  })

  it('rejects non-http(s) protocols and malformed input', () => {
    expect(isPublicHttpUrl('file:///etc/passwd')).toBe(false)
    expect(isPublicHttpUrl('ftp://example.com/x.png')).toBe(false)
    expect(isPublicHttpUrl('javascript:alert(1)')).toBe(false)
    expect(isPublicHttpUrl('not a url')).toBe(false)
    expect(isPublicHttpUrl('')).toBe(false)
  })

  it('rejects invalid IPv4 octets', () => {
    expect(isPublicHttpUrl('http://999.1.1.1/x.png')).toBe(false)
    expect(isPublicHttpUrl('http://256.0.0.1/x.png')).toBe(false)
  })
})

describe('isAllowedExtraBaseUrl (trusted base URL guard)', () => {
  it('allows known official hosts without trusted list', () => {
    expect(isAllowedExtraBaseUrl('https://open.bigmodel.cn/api/paas/v4', [])).toBe(true)
    expect(isAllowedExtraBaseUrl('https://dashscope.aliyuncs.com', [])).toBe(true)
    expect(isAllowedExtraBaseUrl('https://api.deepseek.com', [])).toBe(true)
  })

  it('rejects unknown https hosts without trusted list', () => {
    expect(isAllowedExtraBaseUrl('https://evil.example.com/v1', [])).toBe(false)
    expect(isAllowedExtraBaseUrl('https://localhost:8000/v1', [])).toBe(false)
  })

  it('allows hosts listed in trustedBaseUrls by exact URL or hostname', () => {
    expect(isAllowedExtraBaseUrl('https://evil.example.com/v1', ['https://evil.example.com/v1'])).toBe(true)
    expect(isAllowedExtraBaseUrl('https://evil.example.com/other', ['https://evil.example.com/'])).toBe(true)
  })

  it('rejects non-https and malformed URLs', () => {
    expect(isAllowedExtraBaseUrl('http://api.deepseek.com/v1', [])).toBe(false)
    expect(isAllowedExtraBaseUrl('file:///etc/passwd', [])).toBe(false)
    expect(isAllowedExtraBaseUrl('not a url', [])).toBe(false)
  })

  it('allows explicitly trusted local endpoints over http (local Ollama)', () => {
    expect(isAllowedExtraBaseUrl('http://localhost:11434/v1', [])).toBe(false)
    expect(isAllowedExtraBaseUrl('http://localhost:11434/v1', ['http://localhost:11434/v1'])).toBe(true)
    expect(isAllowedExtraBaseUrl('http://127.0.0.1:11434/v1', ['http://localhost:11434/v1'])).toBe(false)
    expect(isAllowedExtraBaseUrl('http://127.0.0.1:11434/v1', ['http://127.0.0.1:11434/v1'])).toBe(true)
  })
})

describe('redactSensitiveText', () => {
  it('masks mainland phone numbers', () => {
    expect(redactSensitiveText('联系 13812345678')).toBe('联系 1**********')
  })

  it('masks 18-digit IDs fully', () => {
    const id = '110101199001011234'
    expect(redactSensitiveText(id)).toBe('*'.repeat(18))
  })

  it('masks email addresses partially', () => {
    expect(redactSensitiveText('mail: alice@example.com')).toBe('mail: a***@example.com')
  })

  it('leaves ordinary text untouched', () => {
    expect(redactSensitiveText('错误码 404,行号 42')).toBe('错误码 404,行号 42')
  })
})

describe('validateConfig (runtime config guard)', () => {
  const base = {
    providers: {
      deepseek: { baseURL: 'https://api.deepseek.com', apiKeyEnv: 'DEEPSEEK_API_KEY' },
      glm: { baseURL: 'https://open.bigmodel.cn/api/paas/v4', apiKeyEnv: 'GLM_VISION_API_KEY', model: 'x' },
      dashscope: { baseURL: 'https://dashscope.aliyuncs.com', apiKeyEnv: 'DASHSCOPE_API_KEY' },
    },
    extraProviders: {},
  } as never

  it('accepts a valid config', () => {
    expect(() => validateConfig(base)).not.toThrow()
  })

  it('rejects a provider baseURL that is not http(s)', () => {
    expect(() =>
      validateConfig({
        ...base,
        providers: { ...base.providers, glm: { baseURL: 'ftp://x', apiKeyEnv: 'K', model: 'm' } },
      } as never),
    ).toThrow(/must be http\(s\)/)
  })

  it('rejects an invalid provider URL', () => {
    expect(() =>
      validateConfig({
        ...base,
        providers: { ...base.providers, deepseek: { baseURL: '::not-a-url::', apiKeyEnv: 'K' } },
      } as never),
    ).toThrow(/not a valid URL/)
  })

  it('rejects extraProviders keys with invalid characters', () => {
    expect(() =>
      validateConfig({ ...base, extraProviders: { 'bad key!': { baseURL: 'https://x.com' } } } as never),
    ).toThrow(/invalid characters/)
  })

  it('rejects extra provider baseURL that is not https', () => {
    expect(() =>
      validateConfig({
        ...base,
        extraProviders: { x: { baseURL: 'http://x.com/v1', apiKeyEnv: 'K', displayName: '', models: [] } },
      } as never),
    ).toThrow(/must be https/)
  })

  it('accepts an explicitly local http extra provider (local Ollama)', () => {
    expect(() =>
      validateConfig({
        ...base,
        extraProviders: {
          ollama: { baseURL: 'http://localhost:11434/v1', apiKeyEnv: 'OLLAMA_API_KEY', displayName: '', models: [] },
        },
      } as never),
    ).not.toThrow()
  })
})

describe('classifyImage (auto-mode routing)', () => {
  it('classifies A4-ish pages as documents (landscape and portrait)', () => {
    expect(classifyImage(1240, 1754)).toBe('document')
    expect(classifyImage(1754, 1240)).toBe('document')
  })

  it('classifies extreme aspect ratios as screenshots', () => {
    expect(classifyImage(1920, 1080)).toBe('screenshot')
    expect(classifyImage(1080, 1920)).toBe('screenshot')
    expect(classifyImage(2560, 720)).toBe('screenshot')
  })

  it('classifies large uniform areas as screenshots', () => {
    expect(classifyImage(1600, 900)).toBe('screenshot')
  })

  it('classifies typical photos as photos', () => {
    expect(classifyImage(800, 600)).toBe('photo')
    expect(classifyImage(4032, 3024)).toBe('photo')
  })

  it('handles degenerate input', () => {
    expect(classifyImage(0, 0)).toBe('photo')
    expect(classifyImage(-1, 100)).toBe('photo')
  })
})
