/**
 * One OpenAI-compatible chat-completions adapter, parameterized per route.
 * Used for both `deepseek-vision` (text wire, images skipped defensively)
 * and `glm-vision` (images inline as base64 data URLs).
 */
import {
  LlmAdapter,
  LlmError,
  type GenerateOptions,
  type LlmModelInfo,
  type LlmProviderInfo,
  type LlmResolvedModelInfo,
  type StreamChunk,
} from '@deepseek-ai/dsh-llm'
import { idleWatchdog, timeoutOf } from '@deepseek-ai/dsh-timeout'
import { EventSourceParserStream } from 'eventsource-parser/stream'
import type { EventSourceMessage } from 'eventsource-parser'
import { resolveReasoning, serializeRequest, type ReadImage, translate } from './wire.js'

export interface VisionModelSpec {
  id: string
  name?: string
  description?: string
  contextWindow?: number
  maxTokens?: number
}

export interface RouteSpec {
  provider: string
  displayName: string
  /** Endpoint root; `/chat/completions` is appended. */
  baseURL: string
  apiKeyEnv: string
  /** Which reasoning family the wire speaks. */
  reasoning: 'deepseek' | 'glm'
  /** Images inline (glm) or skipped (deepseek defensive). */
  imageMode: 'data-url' | 'skip'
  streamIdleTimeoutMs: number
  models: VisionModelSpec[]
  /** Durable image byte source (attachment service). */
  readImage: ReadImage
}

const INPUT_MODALITIES = ['text', 'image'] as const
const STREAM_IDLE_TIMEOUT_CODE = 'STREAM_IDLE_TIMEOUT'

export function httpErrorCode(status: number): string {
  if (status === 401 || status === 403) return 'AUTH'
  if (status === 404) return 'NOT_FOUND'
  if (status === 429) return 'RATE_LIMIT'
  if (status >= 500) return 'SERVER'
  return 'TRANSPORT'
}

function providerRetryAfterMs(value: string | null): number | undefined {
  if (value === null) return undefined
  if (/^\d+$/.test(value)) {
    const delay = Number(value) * 1000
    return Number.isFinite(delay) && delay > 0 ? delay : undefined
  }
  const delay = Date.parse(value) - Date.now()
  return Number.isFinite(delay) && delay > 0 ? delay : undefined
}

export class OpenAICompatibleAdapter extends LlmAdapter {
  constructor(
    private readonly route: RouteSpec,
    private readonly resolveKey: (ref: string) => Promise<string>,
    private readonly resolveUserId: () => string,
  ) {
    super()
  }

  providerInfo(provider: string): LlmProviderInfo {
    return { id: provider, name: this.route.displayName }
  }

  providerRetryPolicy(): undefined {
    return undefined
  }

  async listModels(provider: string): Promise<readonly LlmModelInfo[]> {
    return this.route.models.map((model) => ({
      provider,
      id: model.id,
      name: model.name ?? model.id,
      ...(model.description !== undefined ? { description: model.description } : {}),
      inputModalities: INPUT_MODALITIES,
    }))
  }

  async resolveModel(
    provider: string,
    model: string,
  ): Promise<LlmResolvedModelInfo> {
    const entry = this.route.models.find((m) => m.id === model)
    return {
      provider,
      id: model,
      name: entry?.name ?? model,
      // Unknown ids stay conservative; picker models always carry the declared
      // modalities above.
      inputModalities: entry !== undefined ? INPUT_MODALITIES : ['text'],
      ...(entry?.contextWindow !== undefined
        ? { context: { contextWindow: entry.contextWindow } }
        : {}),
      ...(entry?.maxTokens !== undefined
        ? { defaultMaxTokens: entry.maxTokens }
        : {}),
    }
  }

  async *stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    const apiKey = await this.resolveKey(this.route.apiKeyEnv)
    const consumer = new AbortController()
    const watchdog = idleWatchdog(
      options.signal === undefined
        ? consumer.signal
        : AbortSignal.any([options.signal, consumer.signal]),
      this.route.streamIdleTimeoutMs,
      STREAM_IDLE_TIMEOUT_CODE,
    )
    const iterator = this.request(options, watchdog.signal, apiKey, () => {
      watchdog.pulse()
    })[Symbol.asyncIterator]()
    let exhausted = false
    try {
      while (true) {
        const result = await watchdog.next(iterator)
        if (result.done) {
          exhausted = true
          return
        }
        yield result.value
      }
    } catch (error) {
      if (timeoutOf(watchdog.signal, STREAM_IDLE_TIMEOUT_CODE) !== undefined) {
        throw new LlmError(
          `stream idle timeout after ${this.route.streamIdleTimeoutMs}ms`,
          'TIMEOUT',
          { cause: error },
        )
      }
      if (options.signal?.aborted) {
        throw new LlmError('request aborted by caller', 'ABORTED', { cause: error })
      }
      if (error instanceof LlmError) throw error
      throw new LlmError(`provider stream from ${this.route.baseURL} failed`, 'TRANSPORT', {
        cause: error,
      })
    } finally {
      consumer.abort('stream consumer stopped')
      if (!exhausted && iterator.return !== undefined) {
        try {
          await iterator.return()
        } catch {
          // transport teardown
        }
      }
    }
  }

  private async *request(
    options: GenerateOptions,
    signal: AbortSignal,
    apiKey: string,
    onComment: () => void,
  ): AsyncIterable<StreamChunk> {
    const body = JSON.stringify(
      await serializeRequest(
        options,
        {
          imageMode: this.route.imageMode,
          reasoning: resolveReasoning(options, this.route.reasoning),
          readImage: this.route.readImage,
        },
        signal,
      ),
    )
    const headers: Record<string, string> = {
      authorization: `Bearer ${apiKey}`,
      'content-type': 'application/json',
      accept: 'text/event-stream',
    }
    // Audit fix (2026-08-15): do NOT forward the real sessionId to the
    // third-party vision API. It is internal harness state and leaking it
    // to an external endpoint is an unnecessary information disclosure.
    // If a per-request correlation id is ever needed, mint an ephemeral
    // random one here instead of reusing the real sessionId.

    let response: Response
    try {
      response = await fetch(`${this.route.baseURL}/chat/completions`, {
        method: 'POST',
        headers,
        body,
        signal,
      })
    } catch (error) {
      if (signal.aborted) throw error
      throw new LlmError(
        `request to ${this.route.baseURL} failed`,
        'TRANSPORT',
        { cause: error },
      )
    }

    if (!response.ok) {
      let message = `provider error (HTTP ${response.status})`
      try {
        const data = (await response.json()) as { error?: { message?: string } }
        if (data.error?.message) message = data.error.message
      } catch {
        // keep the status-based message
      }
      const retryAfter = providerRetryAfterMs(response.headers.get('retry-after'))
      throw new LlmError(message, httpErrorCode(response.status), {
        status: response.status,
        ...(retryAfter !== undefined ? { providerRetryAfterMs: retryAfter } : {}),
      })
    }

    if (response.body === null) {
      throw new LlmError('provider returned no response body', 'EMPTY_RESPONSE')
    }

    const sse = response.body
      .pipeThrough(new TextDecoderStream())
      .pipeThrough(new EventSourceParserStream())
    yield* translate(parseSse(sse, onComment))
  }
}

/**
 * Extract SSE `data:` payloads from the parser event stream, rearming the
 * watchdog on comments. `EventSourceParserStream` already folds multi-line
 * data into one event, so each event yields exactly one payload.
 */
async function* parseSse(
  stream: ReadableStream<EventSourceMessage>,
  onComment: () => void,
): AsyncIterable<string> {
  for await (const event of stream) {
    if (event.data === undefined) {
      onComment()
      continue
    }
    yield event.data
  }
}
