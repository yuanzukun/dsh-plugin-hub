/**
 * "Multimodal" settings section (Settings → 多模态).
 *
 * One place to configure every multimodal capability of dsh-multimodal:
 *  - GLM vision key (see images)
 *  - DashScope / Aliyun key (text-to-image)
 *  - active image backend (dashscope / glm-cogview / custom)
 *  - extra OpenAI-compatible vision providers (Xfyun, ModelScope, SiliconFlow, ...)
 *
 * Layout follows the official Models settings section: same design tokens,
 * capsule buttons, 32px fields, row cards. Keys go through the credentials
 * service; provider configuration through settings.mutate.
 */
import { useEffect, useRef, useState } from 'react'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type { SettingsSectionOwnerProps } from '@deepseek-ai/dsh-client-ui-settings/client'
// Pull in the `tool.call.toolview` SlotMap declaration (declare-module merge)
// so registering the generate_image tool card type-checks.
import type {} from '@deepseek-ai/dsh-client-ui-tool/client'

export const inject = ['slots', 'connection', 'conversation']

export const MULTIMODAL_CSS = `

.dsmm-section {
  display: flex;
  flex-direction: column;
  gap: 16px;
  max-width: 720px;
  color: var(--dsw-alias-label-primary);
}

.dsmm-title {
  margin: 0;
  font-size: 17px;
  line-height: 24px;
  font-weight: 500;
  color: var(--dsw-alias-label-primary);
}

.dsmm-intro {
  margin: -8px 0 0;
  font-size: 13px;
  line-height: 20px;
  color: var(--dsw-alias-label-tertiary);
}

.dsmm-savedNotice {
  margin: 0;
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-state-success-primary);
}

.dsmm-error {
  margin: 0;
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-state-error-primary);
}

.dsmm-banner {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 14px;
  border-radius: 8px;
  font-size: 13px;
  line-height: 20px;
}
.dsmm-bannerOk {
  background: var(--dsw-alias-state-success-tertiary, rgba(34, 197, 94, 0.12));
  border: 1px solid var(--dsw-alias-state-success-secondary, rgba(34, 197, 94, 0.3));
  color: var(--dsw-alias-state-success-primary);
}
.dsmm-bannerErr {
  background: var(--dsw-alias-state-error-secondary, rgba(239, 68, 68, 0.08));
  border: 1px solid var(--dsw-alias-state-error-primary, rgba(239, 68, 68, 0.3));
  color: var(--dsw-alias-state-error-primary);
}
.dsmm-bannerDot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: currentColor;
  flex-shrink: 0;
  display: inline-block;
}

.dsmm-sectionHead {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding: 12px 2px;
  background: transparent;
  border: none;
  border-bottom: 1px solid var(--dsw-alias-border-l2);
  cursor: pointer;
  font: inherit;
  color: var(--dsw-alias-label-primary);
}
.dsmm-sectionTitle {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  font-weight: 500;
}
.dsmm-sectionArrow {
  font-size: 16px;
  color: var(--dsw-alias-label-tertiary);
  transition: transform 0.15s;
  display: inline-block;
}
.dsmm-sectionArrowOpen {
  transform: rotate(90deg);
}
.dsmm-sectionBody {
  padding: 2px 2px 14px;
}
.dsmm-rowName {
  font-size: 14px;
  line-height: 22px;
  font-weight: 500;
  color: var(--dsw-alias-label-primary);
}
.dsmm-rowTag {
  flex: none;
  padding: 1px 8px;
  border-radius: 99px;
  background: var(--dsw-alias-bg-layer-2);
  font-size: 11px;
  line-height: 18px;
  color: var(--dsw-alias-label-tertiary);
}

.dsmm-kindBadge {
  display: inline-flex;
  align-items: center;
  height: 22px;
  padding: 0 8px;
  border-radius: 6px;
  font-size: 11px;
  background: var(--dsw-alias-bg-layer-2);
  color: var(--dsw-alias-label-secondary);
}
.dsmm-badgeRow {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 8px;
}

.dsmm-cardRow {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 10px 2px;
  border-bottom: 1px solid var(--dsw-alias-border-l2);
}
.dsmm-cardRow:last-child {
  border-bottom: none;
}
.dsmm-cardTitle {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  font-weight: 500;
  color: var(--dsw-alias-label-primary);
}
.dsmm-cardMeta {
  margin-top: 3px;
  font-size: 12px;
  color: var(--dsw-alias-label-secondary);
}
.dsmm-cardActions {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}
.dsmm-cardMain {
  flex: 1;
  min-width: 0;
}
.dsmm-selectMode {
  width: 160px;
}
.dsmm-toggleGroup {
  margin-top: 8px;
}
.dsmm-sectionNote {
  margin-top: 10px;
}
.dsmm-listGroup {
  margin-top: 12px;
}
.dsmm-presetRow {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 12px;
}
.dsmm-cardRowTop {
  align-items: flex-start;
}
.dsmm-fieldFull {
  grid-column: 1 / -1;
}
.dsmm-formActions {
  margin-top: 6px;
}
.dsmm-modelInput {
  width: 200px;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
}
.dsmm-modelAddBtn {
  height: 26px;
  font-size: 12px;
}
.dsmm-genDownloadLabel {
  cursor: pointer;
}
.dsmm-hiddenFile {
  display: none;
}
.dsmm-advancedNote {
  margin-top: 8px;
}

.dsmm-toggleBtn {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  height: 32px;
  padding: 0 12px;
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 8px;
  background: transparent;
  color: var(--dsw-alias-label-secondary);
  font: inherit;
  font-size: 13px;
  cursor: pointer;
}
.dsmm-toggleBtn:hover {
  border-color: var(--dsw-alias-border-l3);
  color: var(--dsw-alias-label-primary);
  background: var(--dsw-alias-interactive-bg-hover);
}
.dsmm-formBody {
  margin-top: 12px;
  border-top: 1px solid var(--dsw-alias-border-l2);
  padding-top: 14px;
}

.dsmm-badge {
  display: inline-flex;
  align-items: center;
  height: 20px;
  padding: 0 8px;
  border-radius: 99px;
  font-size: 11px;
  line-height: 20px;
  font-weight: 400;
}
.dsmm-badgeOk {
  background: var(--dsw-alias-state-success-tertiary, rgba(34, 197, 94, 0.12));
  color: var(--dsw-alias-state-success-primary, #16a34a);
}
.dsmm-badgeMuted {
  background: var(--dsw-alias-bg-layer-2);
  color: var(--dsw-alias-label-tertiary);
}
.dsmm-badgeInfo {
  background: var(--dsw-alias-bg-layer-2);
  color: var(--dsw-alias-label-secondary);
}

.dsmm-keyIcon {
  width: 34px;
  height: 34px;
  border-radius: 9px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 500;
  background: var(--dsw-alias-bg-layer-2);
  color: var(--dsw-alias-label-primary);
  flex-shrink: 0;
}
.dsmm-keyIconAlt {
  background: var(--dsw-alias-bg-layer-3);
}
.dsmm-keyBody {
  flex: 1;
  min-width: 0;
}
.dsmm-keyField {
  margin-top: 8px;
}
.dsmm-keyActions {
  margin-top: 6px;
}
.dsmm-keyActions .dsmm-savedNotice,
.dsmm-keyActions .dsmm-error {
  margin-right: auto;
  align-self: center;
  font-size: 12px;
}

.dsmm-modelChip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 24px;
  padding: 0 6px 0 10px;
  border-radius: 12px;
  background: var(--dsw-alias-bg-layer-2);
  color: var(--dsw-alias-label-primary);
  font-size: 12px;
  line-height: 24px;
}
.dsmm-modelChipX {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border: none;
  border-radius: 50%;
  background: transparent;
  color: var(--dsw-alias-label-tertiary);
  font-size: 13px;
  line-height: 1;
  cursor: pointer;
  padding: 0;
}
.dsmm-modelChipX:hover {
  background: var(--dsw-alias-state-error-primary, #ef4444);
  color: #fff;
}
.dsmm-modelAdd {
  display: flex;
  align-items: center;
  gap: 6px;
}

.dsmm-switch {
  position: relative;
  display: inline-block;
  width: 36px;
  height: 20px;
  flex-shrink: 0;
}
.dsmm-switch input {
  opacity: 0;
  width: 0;
  height: 0;
}
.dsmm-switchTrack {
  position: absolute;
  inset: 0;
  border-radius: 10px;
  background: var(--dsw-alias-border-l2);
  transition: background 0.15s;
  cursor: pointer;
}
.dsmm-switchTrack::before {
  content: '';
  position: absolute;
  top: 2px;
  left: 2px;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: var(--dsw-alias-label-primary-foreground, #fff);
  transition: transform 0.15s;
}
.dsmm-switch input:checked + .dsmm-switchTrack {
  background: var(--dsw-alias-brand-primary, #378add);
}
.dsmm-switch input:checked + .dsmm-switchTrack::before {
  transform: translateX(16px);
}
.dsmm-switch input:disabled + .dsmm-switchTrack {
  opacity: 0.5;
  cursor: not-allowed;
}

.dsmm-editorActions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

.dsmm-field {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.dsmm-fieldLabel {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  font-size: 12px;
  line-height: 18px;
  font-weight: 500;
  color: var(--dsw-alias-label-secondary);
}

.dsmm-primaryButton,
.dsmm-secondaryButton,
.dsmm-dangerButton {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  height: 32px;
  padding: 0 14px;
  border: none;
  border-radius: 8px;
  font: inherit;
  font-size: 13px;
  line-height: 20px;
  cursor: pointer;
}
.dsmm-primaryButton {
  background: var(--dsw-alias-button-primary-fill);
  color: var(--dsw-alias-label-primary-foreground);
}
.dsmm-primaryButton:hover:not(:disabled) {
  background: var(--dsw-alias-button-primary-hover);
}
.dsmm-secondaryButton {
  border: 1px solid var(--dsw-alias-border-l2);
  background: transparent;
  color: var(--dsw-alias-label-primary);
}
.dsmm-secondaryButton:hover:not(:disabled) {
  background: var(--dsw-alias-interactive-bg-hover-solid);
}
.dsmm-dangerButton {
  background: transparent;
  color: var(--dsw-alias-state-error-primary);
}
.dsmm-dangerButton:hover:not(:disabled) {
  background: var(--dsw-alias-interactive-bg-hover-danger);
}
.dsmm-primaryButton:disabled,
.dsmm-secondaryButton:disabled,
.dsmm-dangerButton:disabled {
  opacity: 0.4;
  cursor: default;
}
.dsmm-primaryButton:focus-visible,
.dsmm-secondaryButton:focus-visible,
.dsmm-dangerButton:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px var(--dsw-alias-border-l3);
}

.dsmm-input {
  box-sizing: border-box;
  width: 100%;
  height: 32px;
  padding: 0 10px;
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 8px;
  font: inherit;
  font-size: 13px;
  line-height: 32px;
  background: var(--dsw-alias-bg-layer-1);
  color: var(--dsw-alias-label-primary);
}
select.dsmm-input {
  max-width: 240px;
  cursor: pointer;
}
.dsmm-input:focus {
  outline: none;
  border-color: var(--dsw-alias-brand-primary);
}
.dsmm-input::placeholder {
  color: var(--dsw-alias-label-dimmed);
}
.dsmm-input:disabled {
  opacity: 0.6;
  cursor: default;
}
.dsmm-selectInput {
  appearance: none;
  padding-right: 32px;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12' fill='none'%3E%3Cpath d='M3 4.5L6 7.5L9 4.5' stroke='%2381858C' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 12px center;
  background-size: 12px 12px;
}

.dsmm-grid2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}
.dsmm-grid2 .dsmm-field:nth-child(2n + 1):last-child {
  grid-column: 1 / -1;
}

.dsmm-platformMeta {
  margin: 0;
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-label-tertiary);
}
.dsmm-presetButton {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  height: 28px;
  padding: 0 10px;
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 14px;
  background: transparent;
  color: var(--dsw-alias-label-secondary);
  font: inherit;
  font-size: 12px;
  cursor: pointer;
}
.dsmm-presetButton:hover {
  border-color: var(--dsw-alias-border-l3);
  background: var(--dsw-alias-interactive-bg-hover);
  color: var(--dsw-alias-label-primary);
}
.dsmm-presetGrid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: 8px;
  margin-bottom: 12px;
}
.dsmm-presetCard {
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 10px;
  overflow: hidden;
  background: var(--dsw-alias-bg-layer-1);
}
.dsmm-presetCardOn {
  border-color: var(--dsw-alias-state-success-secondary, rgba(34, 197, 94, 0.4));
  background: var(--dsw-alias-state-success-tertiary, rgba(34, 197, 94, 0.06));
}
.dsmm-presetCardActive {
  border-color: var(--dsw-alias-brand-primary);
  box-shadow: 0 0 0 1px var(--dsw-alias-brand-primary);
}
.dsmm-presetCardBody {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 2px;
  width: 100%;
  padding: 12px 14px;
  border: none;
  background: transparent;
  font: inherit;
  cursor: pointer;
  text-align: left;
}
.dsmm-presetCardBody:hover {
  background: var(--dsw-alias-interactive-bg-hover);
}
.dsmm-presetCardName {
  font-size: 13px;
  font-weight: 500;
  color: var(--dsw-alias-label-primary);
}
.dsmm-presetCardMeta {
  font-size: 11px;
  color: var(--dsw-alias-label-tertiary);
}
.dsmm-presetConnect {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 12px 14px;
}
.dsmm-presetConnectHead {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.dsmm-presetConnectActions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.dsmm-presetHint {
  font-size: 11px;
  color: var(--dsw-alias-label-tertiary);
}
.dsmm-statusbar {
  display: flex;
  align-items: center;
  gap: 10px;
  background: var(--dsw-alias-bg-layer-2);
  border-radius: 10px;
  padding: 10px 14px;
  margin-bottom: 12px;
  flex-wrap: wrap;
}
.dsmm-statusItem {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12.5px;
  color: var(--dsw-alias-label-secondary);
}
.dsmm-statusDivider {
  color: var(--dsw-alias-label-dimmed);
}
.dsmm-statusBadge {
  font-size: 11px;
  padding: 1px 8px;
  border-radius: 99px;
}
.dsmm-statusOk {
  background: var(--dsw-alias-state-success-tertiary, rgba(34, 197, 94, 0.12));
  color: var(--dsw-alias-state-success-primary, #16a34a);
}
.dsmm-statusErr {
  background: var(--dsw-alias-state-error-secondary, rgba(239, 68, 68, 0.08));
  color: var(--dsw-alias-state-error-primary, #ef4444);
}
.dsmm-statusReady {
  font-size: 12px;
  color: var(--dsw-alias-state-success-primary, #16a34a);
}
.dsmm-quickadd {
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 12px;
  background: var(--dsw-alias-bg-layer-1);
  padding: 14px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 12px;
}
.dsmm-quickaddHead {
  display: flex;
  align-items: baseline;
  gap: 8px;
}
.dsmm-quickaddTitle {
  font-size: 14px;
  font-weight: 500;
  color: var(--dsw-alias-label-primary);
}
.dsmm-quickaddHint {
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary);
}
.dsmm-quickaddBtn {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 36px;
  padding: 0 16px;
  border: 1px solid var(--dsw-alias-brand-primary, #378add);
  border-radius: 8px;
  background: transparent;
  color: var(--dsw-alias-brand-primary, #378add);
  font: inherit;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
}
.dsmm-quickaddBtn:hover {
  background: var(--dsw-alias-interactive-bg-hover);
}
.dsmm-autoconnect {
  display: flex;
  gap: 8px;
}
.dsmm-autoconnectBtn {
  flex: none;
}
.dsmm-autoconnectHint {
  margin: 0;
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-label-secondary);
}
`
const CSS_TAG_ID = 'dsh-multimodal/settings.css'

function ensureStyles(): void {
  if (typeof document === 'undefined') return
  if (document.querySelector(`style[data-plugin-css="${CSS_TAG_ID}"]`) !== null) return
  const tag = document.createElement('style')
  tag.dataset.pluginCss = CSS_TAG_ID
  tag.textContent = MULTIMODAL_CSS
  document.head.appendChild(tag)
}

/**
 * generate_image tool card — a dedicated in-conversation view for the
 * plugin's text-to-image tool. Renders the generated images as a responsive
 * thumbnail grid with a click-to-zoom lightbox and per-image download, plus
 * the prompt/model metadata. Registered into the keyed `tool.call.toolview`
 * slot under the `generate_image` key, so it REPLACES the generic tool row
 * for this tool and nothing in the shell had to change.
 */
const GEN_IMAGE_CSS = `
.dsmm-genCard {
  box-sizing: border-box;
  border: 1px solid var(--dsw-alias-border-l1);
  border-radius: 12px;
  background: var(--dsw-alias-bg-module-platform);
  padding: 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  max-width: 720px;
}

.dsmm-genHead {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 10px;
}

.dsmm-genTitle {
  margin: 0;
  font-size: 14px;
  line-height: 22px;
  font-weight: 500;
  color: var(--dsw-alias-label-primary);
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.dsmm-genMeta {
  flex: none;
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-label-tertiary);
  white-space: nowrap;
}

.dsmm-genPrompt {
  margin: 0;
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-label-secondary);
  word-break: break-word;
  max-height: 54px;
  overflow: hidden;
}

.dsmm-genGrid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(132px, 1fr));
  gap: 8px;
}

.dsmm-genCell {
  position: relative;
  border-radius: 8px;
  overflow: hidden;
  background: var(--dsw-alias-bg-layer-1);
  border: 1px solid var(--dsw-alias-border-l1);
}

.dsmm-genThumb {
  display: block;
  width: 100%;
  aspect-ratio: 1 / 1;
  object-fit: cover;
  cursor: zoom-in;
}

.dsmm-genLoading,
.dsmm-genCellError {
  aspect-ratio: 1 / 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 8px;
  box-sizing: border-box;
  font-size: 12px;
  line-height: 18px;
  text-align: center;
  color: var(--dsw-alias-label-dimmed);
}

.dsmm-genCellError {
  color: var(--dsw-alias-state-error-primary);
}

.dsmm-genError {
  margin: 0;
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-state-error-primary);
  word-break: break-word;
}

.dsmm-genRunning {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin: 0;
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-label-tertiary);
}

.dsmm-genSpinner {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  border: 2px solid var(--dsw-alias-border-l3);
  border-top-color: var(--dsw-alias-brand-primary);
  animation: dsmm-genSpin 0.9s linear infinite;
}

@keyframes dsmm-genSpin {
  to { transform: rotate(360deg); }
}

.dsmm-genActions {
  display: flex;
  align-items: center;
  gap: 6px;
}

.dsmm-genDownload {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  height: 26px;
  padding: 0 10px;
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 13px;
  background: transparent;
  color: var(--dsw-alias-label-primary);
  font: inherit;
  font-size: 12px;
  line-height: 18px;
  text-decoration: none;
  cursor: pointer;
}

.dsmm-genDownload:hover:not(:disabled) {
  background: var(--dsw-alias-interactive-bg-hover-solid);
}

.dsmm-genRetry {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  height: 26px;
  padding: 0 12px;
  border: 1px solid var(--dsw-alias-state-error-primary);
  border-radius: 13px;
  background: transparent;
  color: var(--dsw-alias-state-error-primary);
  font: inherit;
  font-size: 12px;
  line-height: 18px;
  cursor: pointer;
}

.dsmm-genRetry:hover:not(:disabled) {
  background: var(--dsw-alias-state-error-primary);
  color: #fff;
}

.dsmm-presetButton {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 24px;
  padding: 0 10px;
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 12px;
  background: transparent;
  color: var(--dsw-alias-label-primary);
  font: inherit;
  font-size: 12px;
  line-height: 18px;
  cursor: pointer;
}

.dsmm-presetButton:hover:not(:disabled) {
  background: var(--dsw-alias-interactive-bg-hover-solid);
}

.dsmm-cropRoot {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  max-width: 86vw;
}

.dsmm-cropStage {
  position: relative;
  cursor: crosshair;
  user-select: none;
  -webkit-user-select: none;
  max-width: 86vw;
  max-height: 70vh;
}

.dsmm-cropImg {
  display: block;
  max-width: 86vw;
  max-height: 70vh;
  object-fit: contain;
  border-radius: 8px;
}

.dsmm-cropRect,
.dsmm-cropRectDrag {
  position: absolute;
  border: 2px solid var(--dsw-alias-state-info-primary, #378add);
  background: rgba(55, 138, 221, 0.18);
  pointer-events: none;
}

.dsmm-cropRectDrag {
  border-style: dashed;
}

.dsmm-cropBar {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
}

.dsmm-cropInput {
  flex: 1;
  min-width: 0;
  height: 30px;
  box-sizing: border-box;
  padding: 0 10px;
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 8px;
  background: var(--dsw-alias-bg-module-field);
  color: var(--dsw-alias-label-primary);
  font: inherit;
  font-size: 13px;
}

.dsmm-cropSend {
  box-sizing: border-box;
  height: 30px;
  padding: 0 14px;
  border: 1px solid var(--dsw-alias-state-info-primary, #378add);
  border-radius: 15px;
  background: var(--dsw-alias-state-info-primary, #378add);
  color: #fff;
  font: inherit;
  font-size: 13px;
  cursor: pointer;
}

.dsmm-cropSend:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.dsmm-cropCancel {
  box-sizing: border-box;
  height: 30px;
  padding: 0 12px;
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 15px;
  background: transparent;
  color: var(--dsw-alias-label-primary);
  font: inherit;
  font-size: 13px;
  cursor: pointer;
}

.dsmm-genOverlay {
  position: fixed;
  inset: 0;
  z-index: 1000;
  background: rgba(8, 10, 16, 0.78);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 32px;
  cursor: zoom-out;
}

.dsmm-genOverlayImg {
  max-width: 92vw;
  max-height: 86vh;
  border-radius: 10px;
  box-shadow: 0 12px 48px rgba(0, 0, 0, 0.5);
}

.dsmm-genOverlayClose {
  position: absolute;
  top: 16px;
  right: 20px;
  width: 32px;
  height: 32px;
  border: none;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.14);
  color: #fff;
  font-size: 18px;
  line-height: 1;
  cursor: pointer;
}

.dsmm-genOverlayClose:hover {
  background: rgba(255, 255, 255, 0.26);
}
`

const GEN_IMAGE_CSS_TAG_ID = 'dsh-multimodal/gen-image.css'

function ensureGenImageStyles(): void {
  if (typeof document === 'undefined') return
  if (document.querySelector(`style[data-plugin-css="${GEN_IMAGE_CSS_TAG_ID}"]`) !== null) return
  const tag = document.createElement('style')
  tag.dataset.pluginCss = GEN_IMAGE_CSS_TAG_ID
  tag.textContent = GEN_IMAGE_CSS
  document.head.appendChild(tag)
}

type ApiResult<T> = { result: { ok: true; value: T } } | { result: { ok: false; error: { message: string; code?: string } } }

interface CredentialState {
  configured: boolean
  writable: boolean
  source?: string
}

interface SettingsView {
  ns: string
  revision: number
  value?: Record<string, unknown>
}

interface MinimalApi {
  credentials: {
    describe(req: { refs: string[] }): Promise<ApiResult<{ credentials: Record<string, CredentialState> }>>
    set(req: { ref: string; value: string }): Promise<ApiResult<Record<string, never>>>
    unset(req: { ref: string }): Promise<ApiResult<Record<string, never>>>
  }
  settings: {
    describe(req: Record<string, never>): Promise<ApiResult<{ writable: boolean; namespaces: SettingsView[] }>>
    mutate(req: {
      ns: string
      ops: Array<{ op: 'set' | 'unset'; path: string[]; value?: unknown }>
      expectedRevision?: number
    }): Promise<ApiResult<SettingsView>>
  }
  llm: {
    /** Ask a draft endpoint what models it serves (one-shot key, never stored). */
    discoverModels(req: {
      settingsNs: string
      provider?: string
      baseURL?: string
      api?: string
      apiKey?: string
    }): Promise<ApiResult<{ models: Array<{ id: string; name?: string }> }>>
  }
}

interface ExtraProviderSpec {
  displayName: string
  baseURL: string
  apiKeyEnv: string
  models: Array<{ id: string; name?: string }>
}

const REF_VISION = 'VISION_API_KEY'
const REF_IMAGE = 'IMAGE_API_KEY'
const NS = 'dsh-multimodal'
/** Protocol-level labels only — no model names (blank-slate, v0.3.2). */
const BACKEND_LABELS: Record<string, string> = {
  dashscope: 'DashScope 异步轮询',
  'glm-cogview': 'OpenAI 兼容端点',
  'z-image': 'DashScope 同步',
}

/**
 * One-click platform templates (endpoint only — blank-slate: NO model names
 * baked in; models come from the /models discovery layer or manual input).
 */
interface ExtraPreset {
  key: string
  label: string
  displayName: string
  baseURL: string
  apiKeyEnv: string
  /** What the platform is useful for, shown as a small hint on the card. */
  purpose: 'vision' | 'image' | 'both'
  /** Optional fingerprint: regex the pasted key is tested against first
   *  (cheap, no network) before falling back to /models probing. */
  keyHint?: RegExp
  /** When set, the preset connects as a text-to-image BACKEND (image.backends)
   *  instead of an extra chat provider. Used for platforms whose API is not
   *  an OpenAI-compatible chat endpoint (e.g. DashScope Z-Image). */
  backendSpec?: {
    kind: string
    baseURL: string
    apiKeyEnv: string
    model: string
    defaultSize: string
  }
}

/** Hosts the host side trusts without an explicit trustedBaseUrls entry
 *  (mirrors KNOWN_VISION_HOSTS in the host plugin's src/index.ts). */
const KNOWN_HOSTS = ['api.deepseek.com', 'open.bigmodel.cn', 'dashscope.aliyuncs.com']

function hostOf(baseURL: string): string {
  try {
    return new URL(baseURL).hostname.toLowerCase()
  } catch {
    return ''
  }
}

function isLocalHost(baseURL: string): boolean {
  return /localhost|127\.0\.0\.1|\[::1\]/i.test(baseURL)
}

/** Whether the host side accepts this provider without a trustedBaseUrls entry. */
function isKnownHost(baseURL: string): boolean {
  return KNOWN_HOSTS.includes(hostOf(baseURL))
}
const EXTRA_PRESETS: ExtraPreset[] = [
  {
    key: 'zhipu-vision',
    label: '智谱 GLM',
    displayName: '智谱视觉',
    baseURL: 'https://open.bigmodel.cn/api/paas/v4',
    apiKeyEnv: 'GLM_API_KEY',
    purpose: 'both',
    // Zhipu keys look like "<32hex>.<32hex>" (id.secret).
    keyHint: /^[a-f0-9]{32}\.[a-f0-9]{32}$/i,
  },
  {
    key: 'dashscope-image',
    label: '阿里百炼',
    displayName: '阿里云百炼',
    baseURL: 'https://dashscope.aliyuncs.com',
    apiKeyEnv: 'DASHSCOPE_API_KEY',
    purpose: 'image',
    // Bailian business-space keys start with sk-ws-.
    keyHint: /^sk-ws-/,
    // DashScope is NOT an OpenAI-compatible chat endpoint — registering it as
    // an extra chat provider would be useless. It connects as a Z-Image
    // text-to-image backend (dashscope-v2 sync protocol) instead, so the card
    // actually makes "画图" work.
    backendSpec: {
      kind: 'dashscope-v2',
      baseURL: 'https://dashscope.aliyuncs.com',
      apiKeyEnv: 'DASHSCOPE_API_KEY',
      model: 'z-image-turbo',
      defaultSize: '1024*1024',
    },
  },
  {
    key: 'xfyun-vision',
    label: '讯飞星辰',
    displayName: '讯飞星辰视觉',
    baseURL: 'https://maas-api.cn-huabei-1.xf-yun.com/v2',
    apiKeyEnv: 'XFYUN_API_KEY',
    purpose: 'vision',
  },
  {
    key: 'modelscope-vision',
    label: '魔搭 ModelScope',
    displayName: '魔搭视觉',
    baseURL: 'https://api-inference.modelscope.cn/v1',
    apiKeyEnv: 'MODELSCOPE_API_TOKEN',
    purpose: 'vision',
  },
  {
    key: 'siliconflow-vision',
    label: '硅基流动',
    displayName: '硅基流动视觉',
    baseURL: 'https://api.siliconflow.cn/v1',
    apiKeyEnv: 'SILICONFLOW_API_KEY',
    purpose: 'both',
  },
  {
    key: 'qianfan-vision',
    label: '百度千帆',
    displayName: '千帆视觉',
    baseURL: 'https://qianfan.baidubce.com/v2',
    apiKeyEnv: 'QIANFAN_API_KEY',
    purpose: 'vision',
  },
  {
    key: 'local-ollama',
    label: '本地 Ollama',
    displayName: '本地 Ollama 视觉',
    baseURL: 'http://localhost:11434/v1',
    apiKeyEnv: 'OLLAMA_API_KEY',
    purpose: 'vision',
  },
]

function unwrap<T>(res: ApiResult<T>): T {
  if (res.result.ok) return res.result.value
  throw new Error(res.result.error.message)
}

/** Collapsible settings section (v0.4: flat divider style). */
function Section(props: {
  title: string
  tag: string
  open: boolean
  onToggle: () => void
  children: React.ReactNode
}): React.ReactElement {
  const { title, tag, open, onToggle, children } = props
  return (
    <section className="dsmm-section">
      <button
        type="button"
        className="dsmm-sectionHead"
        onClick={onToggle}
        aria-expanded={open}
      >
        <span className="dsmm-sectionTitle">
          <span className="dsmm-rowName">{title}</span>
          <span className="dsmm-rowTag">{tag}</span>
        </span>
        <span className={`dsmm-sectionArrow${open ? ' dsmm-sectionArrowOpen' : ''}`} aria-hidden="true">
          ›
        </span>
      </button>
      {open && <div className="dsmm-sectionBody">{children}</div>}
    </section>
  )
}

/** A label + switch row used inside sections (v0.3 UI redesign). */
function ToggleRow(props: {
  label: string
  hint: string
  checked: boolean
  disabled: boolean
  onChange: (value: boolean) => void
}): React.ReactElement {
  const { label, hint, checked, disabled, onChange } = props
  return (
    <div className="dsmm-cardRow">
      <div className="dsmm-cardMain">
        <div className="dsmm-cardTitle">{label}</div>
        <p className="dsmm-cardMeta">{hint}</p>
      </div>
      <div className="dsmm-cardActions">
        <label className="dsmm-switch">
          <input type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
          <span className="dsmm-switchTrack" />
        </label>
      </div>
    </div>
  )
}

/**
 * Text input that commits on Enter / blur instead of on every keystroke —
 * avoids a settings.mutate per character and the reload interrupting typing.
 */
function CommitInput(props: {
  value: string
  placeholder?: string
  disabled?: boolean
  width?: number
  onSubmit: (value: string) => void
}): React.ReactElement {
  const { value, placeholder, disabled, width, onSubmit } = props
  const [draft, setDraft] = useState(value)
  useEffect(() => setDraft(value), [value])
  const commit = (): void => {
    const next = draft.trim()
    if (next !== value) onSubmit(next)
  }
  return (
    <input
      className="dsmm-input"
      style={{ width: width ?? 200 }}
      placeholder={placeholder}
      value={draft}
      disabled={disabled}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === 'Enter') (e.target as HTMLInputElement).blur()
      }}
    />
  )
}

function KeyCard(props: {
  api: MinimalApi
  name: string
  tag: string
  refName: string
  placeholder: string
  hint: string
  onSaved?: () => void
}): React.ReactElement {
  const { api, name, tag, refName, placeholder, hint, onSaved } = props
  const [state, setState] = useState<CredentialState | undefined>(undefined)
  const [value, setValue] = useState('')
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')

  useEffect(() => {
    api.credentials
      .describe({ refs: [refName] })
      .then((res) => {
        if (res.result.ok) setState(res.result.value.credentials[refName])
      })
      .catch(() => undefined)
  }, [api, refName])

  const refresh = async (): Promise<void> => {
    const res = await api.credentials.describe({ refs: [refName] })
    if (res.result.ok) setState(res.result.value.credentials[refName])
  }

  const save = async (): Promise<void> => {
    if (value.trim().length === 0) return
    setSaving(true)
    setMsg('')
    try {
      unwrap(await api.credentials.set({ ref: refName, value: value.trim() }))
      setValue('')
      setMsg('已保存')
      await refresh()
      onSaved?.()
    } catch (error) {
      setMsg(`保存失败: ${error instanceof Error ? error.message : String(error)}`)
    } finally {
      setSaving(false)
    }
  }

  const configured = state?.configured === true
  const initials = refName.slice(0, 2).toUpperCase()
  const alt = refName === REF_IMAGE
  return (
    <div className="dsmm-cardRow dsmm-cardRowTop">
      <div className={`dsmm-keyIcon${alt ? ' dsmm-keyIconAlt' : ''}`}>{initials}</div>
      <div className="dsmm-keyBody">
        <div className="dsmm-cardTitle">
          {name}
          <span className={configured ? 'dsmm-badge dsmm-badgeOk' : 'dsmm-badge dsmm-badgeMuted'}>
            {configured ? '已配置' : '未配置'}
          </span>
        </div>
        <p className="dsmm-cardMeta">{hint}</p>
        <div className="dsmm-field dsmm-keyField">
          <input
            className="dsmm-input"
            type="password"
            placeholder={configured ? '已配置 · 输入新值可覆盖' : placeholder}
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
        </div>
        <div className="dsmm-editorActions dsmm-keyActions">
          <span
            className={msg.startsWith('保存失败') ? 'dsmm-error' : 'dsmm-savedNotice'}
          >
            {msg}
          </span>
          <button className="dsmm-primaryButton" disabled={saving || value.trim().length === 0} onClick={() => void save()}>
            {saving ? '保存中…' : '保存'}
          </button>
        </div>
      </div>
    </div>
  )
}

function MultimodalPanel(props: { api: MinimalApi }): React.ReactElement {
  const { api } = props
  const [activeBackend, setActiveBackend] = useState<string>('')
  const [backends, setBackends] = useState<
    Record<string, { model: string; baseURL?: string; apiKeyEnv?: string; kind?: string; adapterFile?: string }>
  >({})
  const [nbName, setNbName] = useState('')
  const [nbKind, setNbKind] = useState('dashscope')
  const [nbBaseURL, setNbBaseURL] = useState('')
  const [nbKeyEnv, setNbKeyEnv] = useState('')
  const [nbModel, setNbModel] = useState('')
  const [nbSize, setNbSize] = useState('1024*1024')
  const [nbAdapter, setNbAdapter] = useState('')
  const [extras, setExtras] = useState<Record<string, ExtraProviderSpec>>({})
  const [trustedBaseUrls, setTrustedBaseUrls] = useState<string[]>([])
  const [allowedApiKeyEnvs, setAllowedApiKeyEnvs] = useState<string[]>([])
  const [writable, setWritable] = useState(true)
  const [revision, setRevision] = useState<number | undefined>(undefined)
  const [msg, setMsg] = useState('')

  // New extra provider form.
  const [npName, setNpName] = useState('')
  const [npDisplay, setNpDisplay] = useState('')
  const [npBaseURL, setNpBaseURL] = useState('')
  const [npKeyEnv, setNpKeyEnv] = useState('')
  const [npModel, setNpModel] = useState('')
  const [npKey, setNpKey] = useState('')

  // v0.3 UI redesign state.
  const [openSections, setOpenSections] = useState<Set<string>>(() => new Set(['connected']))
  const [backendFormOpen, setBackendFormOpen] = useState(false)
  const [extraFormOpen, setExtraFormOpen] = useState(false)
  /** Quick-add panel open (v0.6 minimal UI). */
  const [quickAddOpen, setQuickAddOpen] = useState(false)
  /** Preset currently being connected (key input open). */
  const [connectingPreset, setConnectingPreset] = useState<ExtraPreset | null>(null)
  const [connectingKey, setConnectingKey] = useState('')
  const [connectingBusy, setConnectingBusy] = useState(false)
  /** Auto-detect flow (v0.7): paste any key, plugin figures out the platform. */
  const [autoKey, setAutoKey] = useState('')
  const [autoBusy, setAutoBusy] = useState(false)
  const [autoHint, setAutoHint] = useState('')
  const [addModelTarget, setAddModelTarget] = useState('')
  const [addModelId, setAddModelId] = useState('')
  const [keyStatus, setKeyStatus] = useState<Record<string, boolean>>({})
  const [visionSummary, setVisionSummary] = useState({
    watchProvider: 'deepseek-vision',
    provider: '',
    mode: 'auto',
    parallel: false,
    sceneHints: true,
    redact: false,
    audit: false,
  })
  const toggleSection = (key: string): void => {
    setOpenSections((prev) => {
      const next = new Set(prev)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })
  }

  const reload = (): void => {
    api.settings
      .describe({})
      .then((res) => {
        if (!res.result.ok) return
        const view = res.result.value.namespaces.find((n) => n.ns === NS)
        setWritable(res.result.value.writable)
        setRevision(view?.revision)
        const value = view?.value ?? {}
        const image = (value.image ?? {}) as Record<string, unknown>
        setActiveBackend(typeof image.activeBackend === 'string' ? image.activeBackend : '')
        setBackends(
          (image.backends ?? {}) as Record<string, { model: string; baseURL?: string; apiKeyEnv?: string; kind?: string; adapterFile?: string }>,
        )
        setExtras((value.extraProviders ?? {}) as Record<string, ExtraProviderSpec>)
        setTrustedBaseUrls(Array.isArray(value.trustedBaseUrls) ? value.trustedBaseUrls : [])
        setAllowedApiKeyEnvs(Array.isArray(value.allowedApiKeyEnvs) ? value.allowedApiKeyEnvs : [])
        const vision = (value.vision ?? {}) as Record<string, unknown>
        setVisionSummary({
          watchProvider: typeof vision.watchProvider === 'string' ? vision.watchProvider : 'deepseek-vision',
          provider: typeof vision.transcribeProvider === 'string' ? vision.transcribeProvider : '',
          mode: typeof vision.transcribeMode === 'string' ? vision.transcribeMode : 'auto',
          parallel: vision.parallelImages === true,
          sceneHints: vision.sceneHints !== false,
          redact: vision.redactSensitive === true,
          audit: vision.auditLog === true,
        })
      })
      .catch(() => undefined)
    api.credentials
      .describe({ refs: [REF_VISION, REF_IMAGE] })
      .then((res) => {
        if (!res.result.ok) return
        const creds = res.result.value.credentials
        setKeyStatus({
          [REF_VISION]: creds[REF_VISION]?.configured === true,
          [REF_IMAGE]: creds[REF_IMAGE]?.configured === true,
        })
      })
      .catch(() => undefined)
  }

  useEffect(reload, [api])

  const switchBackend = async (backend: string): Promise<void> => {
    setActiveBackend(backend)
    try {
      const res = await api.settings.mutate({
        ns: NS,
        ops: [{ op: 'set', path: ['image', 'activeBackend'], value: backend }],
        expectedRevision: revision,
      })
      if (res.result.ok) setRevision(res.result.value.revision)
      else throw new Error(res.result.error.message)
    } catch (error) {
      setMsg(`切换后端失败: ${error instanceof Error ? error.message : String(error)}`)
      // Revert the optimistic selection to the actual persisted value.
      reload()
    }
  }

  const addBackend = async (): Promise<void> => {
    setMsg('')
    const name = nbName.trim()
    if (name.length === 0 || nbBaseURL.trim().length === 0 || nbKeyEnv.trim().length === 0 || nbModel.trim().length === 0) {
      setMsg('请填写:名称、Base URL、Key 引用名、模型 ID')
      return
    }
    if (nbKind === 'custom' && nbAdapter.trim().length === 0) {
      setMsg('自定义后端需要填写适配器文件路径 (adapterFile)')
      return
    }
    const spec: Record<string, unknown> = {
      kind: nbKind,
      baseURL: nbBaseURL.trim(),
      apiKeyEnv: nbKeyEnv.trim(),
      model: nbModel.trim(),
      defaultSize: nbSize.trim() || '1024*1024',
      ...(nbKind === 'custom' ? { adapterFile: nbAdapter.trim() } : {}),
    }
    try {
      const ops: Array<{ op: 'set' | 'unset'; path: string[]; value?: unknown }> = [
        { op: 'set', path: ['image', 'backends', name], value: spec },
      ]
      if (activeBackend === '') ops.push({ op: 'set', path: ['image', 'activeBackend'], value: name })
      const res = await api.settings.mutate({ ns: NS, ops, expectedRevision: revision })
      if (res.result.ok) {
        setRevision(res.result.value.revision)
        setNbName('')
        setNbBaseURL('')
        setNbKeyEnv('')
        setNbModel('')
        setNbAdapter('')
        setMsg(`已添加生图后端「${name}」`)
        reload()
      }
    } catch (error) {
      setMsg(`添加失败: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  const removeBackend = async (key: string): Promise<void> => {
    setMsg('')
    try {
      const ops: Array<{ op: 'set' | 'unset'; path: string[]; value?: unknown }> = [
        { op: 'unset', path: ['image', 'backends', key] },
      ]
      if (activeBackend === key) ops.push({ op: 'set', path: ['image', 'activeBackend'], value: '' })
      const res = await api.settings.mutate({ ns: NS, ops, expectedRevision: revision })
      if (res.result.ok) {
        setRevision(res.result.value.revision)
        setMsg(`已移除后端「${key}」`)
        reload()
      }
    } catch (error) {
      setMsg(`移除失败: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  /** Update one vision.* setting (v0.3 UI redesign). */
  const setVisionField = async (path: string[], value: unknown): Promise<void> => {
    setMsg('')
    try {
      const res = await api.settings.mutate({
        ns: NS,
        ops: [{ op: 'set', path, value }],
        expectedRevision: revision,
      })
      if (res.result.ok) {
        setRevision(res.result.value.revision)
        setMsg('已更新,即时生效')
        reload()
      }
    } catch (error) {
      setMsg(`更新失败: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  const addExtra = async (): Promise<void> => {
    setMsg('')
    if (npName.trim().length === 0 || npBaseURL.trim().length === 0 || npKeyEnv.trim().length === 0 || npModel.trim().length === 0) {
      setMsg('请填写:名称、Base URL、Key 引用名、模型 ID')
      return
    }
    const keyEnv = npKeyEnv.trim()
    const baseURL = npBaseURL.trim()
    try {
      if (npKey.trim().length > 0) {
        unwrap(await api.credentials.set({ ref: keyEnv, value: npKey.trim() }))
      }
      const spec: ExtraProviderSpec = {
        displayName: npDisplay.trim() || npName.trim(),
        baseURL,
        apiKeyEnv: keyEnv,
        models: [{ id: npModel.trim() }],
      }
      const ops: Array<{ op: 'set' | 'unset'; path: string[]; value?: unknown }> = [
        { op: 'set', path: ['extraProviders', npName.trim()], value: spec },
      ]
      // The host side refuses providers whose base URL is neither a known host
      // nor explicitly trusted, and refuses to read any key not on the
      // allow-list. Wire both up on explicit user action so the custom form
      // never silently no-ops.
      if (!isLocalHost(baseURL) && !isKnownHost(baseURL) && !trustedBaseUrls.includes(baseURL)) {
        ops.push({ op: 'set', path: ['trustedBaseUrls'], value: [...trustedBaseUrls, baseURL] })
      }
      if (!allowedApiKeyEnvs.includes(keyEnv)) {
        ops.push({ op: 'set', path: ['allowedApiKeyEnvs'], value: [...allowedApiKeyEnvs, keyEnv] })
      }
      const res = await api.settings.mutate({ ns: NS, ops, expectedRevision: revision })
      if (res.result.ok) {
        setRevision(res.result.value.revision)
        setNpName('')
        setNpDisplay('')
        setNpBaseURL('')
        setNpKeyEnv('')
        setNpModel('')
        setNpKey('')
        setMsg('已添加,重新打开会话后出现在模型选择器')
        reload()
      }
    } catch (error) {
      setMsg(`添加失败: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  /** Config export/import (feature 2026-08-16, K2). */
  const IMPORT_KEYS = [
    'providers',
    'extraProviders',
    'vision',
    'ocr',
    'image',
    'allowedApiKeyEnvs',
    'trustedBaseUrls',
    'streamIdleTimeoutMs',
  ]

  const exportConfig = (): void => {
    setMsg('')
    api.settings
      .describe({})
      .then((res) => {
        if (!res.result.ok) {
          setMsg(`导出失败: ${res.result.error.message}`)
          return
        }
        const ns = res.result.value.namespaces.find((n) => n.ns === NS)
        const value = ns?.value ?? {}
        const blob = new Blob([JSON.stringify(value, null, 2)], { type: 'application/json' })
        const url = URL.createObjectURL(blob)
        const link = document.createElement('a')
        link.href = url
        link.download = 'dsh-multimodal-config.json'
        link.click()
        URL.revokeObjectURL(url)
        setMsg('配置已导出')
      })
      .catch(() => setMsg('导出失败'))
  }

  const importConfig = async (raw: string): Promise<void> => {
    setMsg('')
    let parsed: Record<string, unknown>
    try {
      parsed = JSON.parse(raw) as Record<string, unknown>
    } catch {
      setMsg('导入失败: JSON 解析错误')
      return
    }
    const ops: Array<{ op: 'set' | 'unset'; path: string[]; value?: unknown }> = []
    for (const key of IMPORT_KEYS) {
      if (key in parsed) ops.push({ op: 'set', path: [key], value: parsed[key] })
    }
    if (ops.length === 0) {
      setMsg('导入失败: 未包含允许的配置字段')
      return
    }
    try {
      const res = await api.settings.mutate({ ns: NS, ops, expectedRevision: revision })
      if (res.result.ok) {
        setRevision(res.result.value.revision)
        setMsg('配置已导入,重启会话生效')
        reload()
      }
    } catch (error) {
      setMsg(`导入失败: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  /**
   * One-click add of a platform template. When a key is provided it is
   * stored in the credentials service and the provider is fully usable
   * right away (fool-proof flow: pick platform → paste key → done).
   */
  const addPreset = async (preset: ExtraPreset, keyValue?: string): Promise<void> => {
    setMsg('')
    const spec: ExtraProviderSpec = {
      displayName: preset.displayName,
      baseURL: preset.baseURL,
      apiKeyEnv: preset.apiKeyEnv,
      models: [],
    }
    const isLocal = isLocalHost(preset.baseURL)
    try {
      const ops: Array<{ op: 'set' | 'unset'; path: string[]; value?: unknown }> = []
      if (preset.backendSpec !== undefined) {
        // Image-backend preset (e.g. 阿里百炼 Z-Image): register the backend
        // and make it active when nothing is active yet.
        ops.push({ op: 'set', path: ['image', 'backends', preset.key], value: preset.backendSpec })
        if (activeBackend === '') ops.push({ op: 'set', path: ['image', 'activeBackend'], value: preset.key })
      } else {
        ops.push({ op: 'set', path: ['extraProviders', preset.key], value: spec })
      }
      if (isLocal && !trustedBaseUrls.includes(preset.baseURL)) {
        ops.push({
          op: 'set',
          path: ['trustedBaseUrls'],
          value: [...trustedBaseUrls, preset.baseURL],
        })
      } else if (!isLocal && !isKnownHost(preset.baseURL) && !trustedBaseUrls.includes(preset.baseURL)) {
        // The host side skips extra providers whose base URL is neither a known
        // host nor explicitly trusted. Auto-trust on explicit user action so
        // the "add platform" flow never silently no-ops.
        ops.push({
          op: 'set',
          path: ['trustedBaseUrls'],
          value: [...trustedBaseUrls, preset.baseURL],
        })
      }
      if (!allowedApiKeyEnvs.includes(preset.apiKeyEnv)) {
        ops.push({
          op: 'set',
          path: ['allowedApiKeyEnvs'],
          value: [...allowedApiKeyEnvs, preset.apiKeyEnv],
        })
      }
      const res = await api.settings.mutate({ ns: NS, ops, expectedRevision: revision })
      if (res.result.ok) {
        setRevision(res.result.value.revision)
        // Persist the key right after the provider is registered so the
        // credentials service accepts the ref (some hosts validate refs).
        if (keyValue !== undefined && keyValue.trim().length > 0) {
          await api.credentials.set({ ref: preset.apiKeyEnv, value: keyValue.trim() }).catch(() => undefined)
        }
        setMsg(
          preset.backendSpec !== undefined
            ? `已接入生图后端「${preset.label}」(${preset.backendSpec.model})✓ 说"画一张"即可出图`
            : keyValue !== undefined && keyValue.trim().length > 0
              ? `已接入「${preset.label}」并保存 Key ✓ 打开会话即可在模型选择器中使用`
              : isLocal
                ? `已添加本地端点「${preset.label}」;在列表中补充模型 ID 后重启会话生效`
                : `已添加端点「${preset.label}」;在列表中补充模型 ID 并填写 ${preset.apiKeyEnv} 后重启会话生效`,
        )
        reload()
      }
    } catch (error) {
      setMsg(`添加失败: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  /** Confirm the in-card preset connect flow (fool-proof: pick → paste key → done). */
  const confirmPreset = async (preset: ExtraPreset): Promise<void> => {
    if (connectingBusy) return
    setConnectingBusy(true)
    try {
      await addPreset(preset, connectingKey)
      if (preset.backendSpec === undefined) {
        // Enable the eye for vision-capable presets when nothing is set yet —
        // otherwise "已接入" would show while 发图自动看 stays off.
        if (preset.purpose !== 'image' && visionSummary.provider === '') {
          await api.settings
            .mutate({
              ns: NS,
              ops: [{ op: 'set', path: ['vision', 'transcribeProvider'], value: preset.key }],
              expectedRevision: revision,
            })
            .catch(() => undefined)
        }
        // Auto-discover models the endpoint advertises and pre-fill the list
        // (v0.5, fool-proof): the key travels one-shot and is never stored.
        if (connectingKey.trim().length > 0) {
          try {
            const res = await api.llm.discoverModels({
              settingsNs: NS,
              baseURL: preset.baseURL,
              api: 'openai',
              apiKey: connectingKey.trim(),
            })
            const models = res.result.ok ? res.result.value.models : []
            if (models.length > 0) {
              await api.settings.mutate({
                ns: NS,
                ops: [
                  {
                    op: 'set',
                    path: ['extraProviders', preset.key, 'models'],
                    value: models.map((m) => ({ id: m.id, ...(m.name !== undefined && m.name.length > 0 ? { name: m.name } : {}) })),
                  },
                ],
                expectedRevision: revision,
              }).catch(() => undefined)
            }
          } catch {
            // discovery is best-effort; the user can add model ids manually
          }
        }
      }
      setConnectingPreset(null)
      setConnectingKey('')
      reload()
    } finally {
      setConnectingBusy(false)
    }
  }

  /**
   * Auto-detect (v0.7): paste ANY API key — the plugin figures out which
   * platform it belongs to. Strategy: (1) cheap key-fingerprint match against
   * known platforms, (2) else probe every known endpoint's /models with the
   * one-shot key (never stored); the first endpoint that authenticates wins.
   * Falls back to "unknown platform" prompting the user to pick a card.
   */
  const autoConnect = async (): Promise<void> => {
    const key = autoKey.trim()
    if (key.length === 0) return
    if (autoBusy) return
    setAutoBusy(true)
    setAutoHint('正在识别 Key…')
    try {
      // (1) fingerprint match first (no network)
      const fingerMatched = EXTRA_PRESETS.find((p) => p.keyHint !== undefined && p.keyHint.test(key))
      if (fingerMatched !== undefined) {
        setAutoHint(`检测到 Key 格式匹配「${fingerMatched.label}」,正在验证…`)
        await connectDetected(fingerMatched, key)
        return
      }
      // (2) probe endpoints in likelihood order (fingerprint already covered
      // Zhipu/Bailian). Only OpenAI-compatible chat endpoints are probed —
      // image-backend presets (dashscope-image) are not chat APIs. The key is
      // transmitted only to these known public endpoints, one at a time, and
      // never stored; the first endpoint that authenticates wins.
      const probeOrder = ['siliconflow-vision', 'modelscope-vision', 'xfyun-vision', 'qianfan-vision']
      const candidates = probeOrder
        .map((key) => EXTRA_PRESETS.find((p) => p.key === key))
        .filter((p): p is ExtraPreset => p !== undefined && p.backendSpec === undefined && !isLocalHost(p.baseURL))
      const failures: string[] = []
      if (candidates.length > 0) setAutoHint('未匹配到已知 Key 指纹,将依次探测常见平台以定位…')
      for (const preset of candidates) {
        setAutoHint(`正在探测「${preset.label}」…`)
        try {
          const res = await api.llm.discoverModels({
            settingsNs: NS,
            baseURL: preset.baseURL,
            api: 'openai',
            apiKey: key,
          })
          if (res.result.ok) {
            await connectDetected(preset, key, res.result.value.models)
            return
          }
          failures.push(`${preset.label}(认证失败)`)
        } catch {
          failures.push(`${preset.label}(不可达)`)
        }
      }
      setAutoHint(`未能自动识别:${failures.join(', ')}。请在下方手动选择平台,或使用「自定义端点」。`)
      setMsg('未能自动识别该 Key,请在下方点选平台卡片')
    } catch (error) {
      setAutoHint(`自动接入失败: ${error instanceof Error ? error.message : String(error)}`)
    } finally {
      setAutoBusy(false)
    }
  }

  /** Register a detected platform + persist key + prefill discovered models. */
  const connectDetected = async (preset: ExtraPreset, key: string, discovered?: Array<{ id: string; name?: string }>): Promise<void> => {
    await addPreset(preset, key)
    if (preset.backendSpec !== undefined) {
      // Image-backend preset: nothing else to wire up — addPreset registered
      // the backend and made it active.
      setAutoKey('')
      setAutoHint(`已识别并接入「${preset.label}」✓ Z-Image 生图后端已激活,说"画一张"即可出图。`)
      setMsg(`已接入「${preset.label}」生图后端`)
      reload()
      return
    }
    // Vision-capable preset: enable the eye when nothing is set yet, so
    // "已接入" really means "发图会自动看".
    if (preset.purpose !== 'image' && visionSummary.provider === '') {
      await api.settings
        .mutate({
          ns: NS,
          ops: [{ op: 'set', path: ['vision', 'transcribeProvider'], value: preset.key }],
          expectedRevision: revision,
        })
        .catch(() => undefined)
    }
    const models = discovered ?? []
    if (models.length > 0) {
      await api.settings.mutate({
        ns: NS,
        ops: [
          {
            op: 'set',
            path: ['extraProviders', preset.key, 'models'],
            value: models.map((m) => ({ id: m.id, ...(m.name !== undefined && m.name.length > 0 ? { name: m.name } : {}) })),
          },
        ],
        expectedRevision: revision,
      }).catch(() => undefined)
    }
    setAutoKey('')
    setAutoHint(
      `已识别并接入「${preset.label}」✓ 模型列表已自动填充;识图已启用——在模型选择器选 DeepSeek (Vision) 模型后发图自动转写。`,
    )
    setMsg(`已接入「${preset.label}」`)
    reload()
  }

  const removeExtra = async (name: string): Promise<void> => {
    try {
      const res = await api.settings.mutate({
        ns: NS,
        ops: [{ op: 'unset', path: ['extraProviders', name] }],
        expectedRevision: revision,
      })
      if (res.result.ok) {
        setRevision(res.result.value.revision)
        setMsg(`已移除 ${name}`)
        reload()
      }
    } catch (error) {
      setMsg(`移除失败: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  /** Add a model to an existing platform (model management, v0.3.3). */
  const addModelToExtra = async (name: string, modelId: string): Promise<void> => {
    setMsg('')
    const id = modelId.trim()
    if (id.length === 0) return
    const spec = extras[name]
    if (spec === undefined) return
    if (spec.models.some((m) => m.id === id)) {
      setMsg('该模型已存在')
      return
    }
    try {
      const res = await api.settings.mutate({
        ns: NS,
        ops: [
          {
            op: 'set',
            path: ['extraProviders', name, 'models'],
            value: [...spec.models.map((m) => ({ id: m.id, ...(m.name !== undefined ? { name: m.name } : {}) })), { id }],
          },
        ],
        expectedRevision: revision,
      })
      if (res.result.ok) {
        setRevision(res.result.value.revision)
        setMsg(`已为「${spec.displayName || name}」添加模型 ${id}`)
        reload()
      }
    } catch (error) {
      setMsg(`添加模型失败: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  /** Remove a single model from a platform (model management, v0.3.3). */
  const removeModelFromExtra = async (name: string, modelId: string): Promise<void> => {
    setMsg('')
    const spec = extras[name]
    if (spec === undefined) return
    const remaining = spec.models.filter((m) => m.id !== modelId)
    try {
      const res = await api.settings.mutate({
        ns: NS,
        ops: [
          {
            op: 'set',
            path: ['extraProviders', name, 'models'],
            value: remaining.map((m) => ({ id: m.id, ...(m.name !== undefined ? { name: m.name } : {}) })),
          },
        ],
        expectedRevision: revision,
      })
      if (res.result.ok) {
        setRevision(res.result.value.revision)
        setMsg(`已从「${spec.displayName || name}」删除模型 ${modelId}`)
        reload()
      }
    } catch (error) {
      setMsg(`删除模型失败: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  const backendOptions = Object.keys(backends)

  // Onboarding state (v0.5 fool-proof): readiness must reflect what actually
  // works, not just "something was registered".
  //  - 识图 works only when a transcription provider is set AND that provider
  //    is actually registered (deepseek-vision or an extra provider).
  //  - 画图 works only when a backend is active AND that backend exists.
  const hasVisionProvider =
    visionSummary.provider !== '' &&
    (visionSummary.provider === 'deepseek-vision' || extras[visionSummary.provider] !== undefined)
  const hasImageBackend = activeBackend !== '' && backends[activeBackend] !== undefined

  return (
    <section className="dsmm-section">
      <h2 className="dsmm-title">多模态</h2>
      <p className="dsmm-intro">
        配置 DeepSeek 的眼睛与画笔:视觉模型负责"看"图片,图像生成后端负责"画"。全部配置即时生效。
      </p>

      {msg.length > 0 && (
        <div
          className={
            msg.startsWith('失败') || msg.startsWith('请填写') || msg.startsWith('添加失败') || msg.startsWith('移除失败') || msg.startsWith('导入失败') || msg.startsWith('切换后端失败')
              ? 'dsmm-banner dsmm-bannerErr'
              : 'dsmm-banner dsmm-bannerOk'
          }
        >
          {msg}
        </div>
      )}

      <div className="dsmm-statusbar">
        <span className="dsmm-statusItem">
          识图
          <span className={hasVisionProvider ? 'dsmm-statusBadge dsmm-statusOk' : 'dsmm-statusBadge dsmm-statusErr'}>
            {hasVisionProvider ? '已配置' : '未配置'}
          </span>
        </span>
        <span className="dsmm-statusDivider">·</span>
        <span className="dsmm-statusItem">
          画图
          <span className={hasImageBackend ? 'dsmm-statusBadge dsmm-statusOk' : 'dsmm-statusBadge dsmm-statusErr'}>
            {hasImageBackend ? '已配置' : '未配置'}
          </span>
        </span>
        {hasVisionProvider && hasImageBackend && (
          <span className="dsmm-statusReady">✓ 全部就绪,发图自动看、说画就画</span>
        )}
      </div>

      <div className="dsmm-quickadd">
        <div className="dsmm-quickaddHead">
          <span className="dsmm-quickaddTitle">快速接入</span>
          <span className="dsmm-quickaddHint">粘贴 Key 自动识别 · 或选平台手动接入</span>
        </div>
        <div className="dsmm-autoconnect">
          <input
            className="dsmm-input"
            type="password"
            placeholder="粘贴任意 API Key,自动识别平台并接入"
            value={autoKey}
            disabled={autoBusy}
            onChange={(e) => { setAutoKey(e.target.value); setAutoHint('') }}
            onKeyDown={(e) => {
              if (e.key === 'Enter') void autoConnect()
            }}
          />
          <button className="dsmm-primaryButton dsmm-autoconnectBtn" type="button" onClick={() => void autoConnect()} disabled={autoBusy || autoKey.trim().length === 0}>
            {autoBusy ? '识别中…' : '自动识别'}
          </button>
        </div>
        {autoHint.length > 0 && <p className="dsmm-autoconnectHint">{autoHint}</p>}
        {quickAddOpen ? (
          <>
            <div className="dsmm-presetGrid">
              {EXTRA_PRESETS.map((preset) => {
                const active = connectingPreset?.key === preset.key
                const connected =
                  preset.backendSpec !== undefined
                    ? backends[preset.key] !== undefined
                    : extras[preset.key] !== undefined
                return (
                  <div key={preset.key} className={`dsmm-presetCard${connected ? ' dsmm-presetCardOn' : ''}${active ? ' dsmm-presetCardActive' : ''}`}>
                    {active ? (
                      <div className="dsmm-presetConnect">
                        <div className="dsmm-presetConnectHead">
                          <span className="dsmm-cardTitle">{preset.label}</span>
                          <span className="dsmm-kindBadge">{preset.purpose === 'vision' ? '看图' : preset.purpose === 'image' ? '画图' : '看图+画图'}</span>
                        </div>
                        <input
                          className="dsmm-input"
                          type="password"
                          placeholder={`粘贴 ${preset.apiKeyEnv} (留空稍后填)`}
                          value={connectingKey}
                          autoFocus
                          onChange={(e) => setConnectingKey(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') void confirmPreset(preset)
                          }}
                        />
                        <div className="dsmm-presetConnectActions">
                          <span className="dsmm-presetHint">仅存凭据,不写入配置明文</span>
                          <div style={{ display: 'flex', gap: 6 }}>
                            <button className="dsmm-secondaryButton" onClick={() => { setConnectingPreset(null); setConnectingKey('') }} disabled={connectingBusy}>
                              取消
                            </button>
                            <button className="dsmm-primaryButton" onClick={() => void confirmPreset(preset)} disabled={connectingBusy}>
                              {connectingBusy ? '接入中…' : '接入'}
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <button
                        type="button"
                        className="dsmm-presetCardBody"
                        onClick={() => { setConnectingPreset(preset); setConnectingKey(''); setExtraFormOpen(false) }}
                      >
                        <span className="dsmm-presetCardName">{preset.label}</span>
                        <span className="dsmm-presetCardMeta">{connected ? '已接入 ✓' : '点击接入'}</span>
                      </button>
                    )}
                  </div>
                )
              })}
              <div className="dsmm-presetCard">
                <button
                  type="button"
                  className="dsmm-presetCardBody"
                  onClick={() => { setExtraFormOpen((v) => !v); setConnectingPreset(null) }}
                >
                  <span className="dsmm-presetCardName">自定义端点</span>
                  <span className="dsmm-presetCardMeta">任意 OpenAI 兼容</span>
                </button>
              </div>
            </div>
            {extraFormOpen && (
              <div className="dsmm-formBody">
                <div className="dsmm-grid2">
                  <div className="dsmm-field">
                    <label className="dsmm-fieldLabel">名称</label>
                    <input className="dsmm-input" placeholder="如 xfyun-vision" value={npName} onChange={(e) => setNpName(e.target.value)} />
                  </div>
                  <div className="dsmm-field">
                    <label className="dsmm-fieldLabel">显示名(可选)</label>
                    <input className="dsmm-input" placeholder="如 讯飞星辰视觉" value={npDisplay} onChange={(e) => setNpDisplay(e.target.value)} />
                  </div>
                  <div className="dsmm-field">
                    <label className="dsmm-fieldLabel">Base URL</label>
                    <input className="dsmm-input" placeholder="https://api.siliconflow.cn/v1" value={npBaseURL} onChange={(e) => setNpBaseURL(e.target.value)} />
                  </div>
                  <div className="dsmm-field">
                    <label className="dsmm-fieldLabel">Key 引用名</label>
                    <input className="dsmm-input" placeholder="如 SILICONFLOW_API_KEY" value={npKeyEnv} onChange={(e) => setNpKeyEnv(e.target.value)} />
                  </div>
                  <div className="dsmm-field">
                    <label className="dsmm-fieldLabel">模型 ID</label>
                    <input className="dsmm-input" placeholder="如 你的模型 ID" value={npModel} onChange={(e) => setNpModel(e.target.value)} />
                  </div>
                  <div className="dsmm-field">
                    <label className="dsmm-fieldLabel">API Key(可选,留空稍后填)</label>
                    <input className="dsmm-input" type="password" placeholder="粘贴平台 Key" value={npKey} onChange={(e) => setNpKey(e.target.value)} />
                  </div>
                </div>
                <div className="dsmm-editorActions dsmm-formActions">
                  <button className="dsmm-primaryButton" onClick={() => void addExtra()}>
                    添加平台
                  </button>
                </div>
              </div>
            )}
          </>
        ) : (
          <button className="dsmm-quickaddBtn" type="button" onClick={() => setQuickAddOpen(true)}>
            ＋ 选择平台并接入
          </button>
        )}
      </div>

      <Section title="已接入" tag={Object.keys(extras).length + Object.keys(backends).length > 0 ? `${Object.keys(extras).length} 平台 · ${Object.keys(backends).length} 后端` : '暂无'} open={openSections.has('connected')} onToggle={() => toggleSection('connected')}>
        {Object.keys(extras).length === 0 && Object.keys(backends).length === 0 && (
          <p className="dsmm-platformMeta">还没有接入任何平台或后端 —— 用上方「快速接入」添加。</p>
        )}

        {Object.entries(extras).map(([name, spec]) => (
          <div key={name} className="dsmm-cardRow dsmm-cardRowTop">
            <div className="dsmm-cardMain">
              <div className="dsmm-cardTitle">
                {spec.displayName || name}
                <span className="dsmm-kindBadge">看图</span>
              </div>
              <p className="dsmm-cardMeta">
                {spec.baseURL} · Key: {spec.apiKeyEnv}
              </p>
              <div className="dsmm-badgeRow">
                {spec.models.length === 0 && <span className="dsmm-cardMeta">未添加模型</span>}
                {spec.models.map((m) => (
                  <span key={m.id} className="dsmm-modelChip">
                    {m.id}
                    <button
                      type="button"
                      className="dsmm-modelChipX"
                      aria-label={`删除模型 ${m.id}`}
                      onClick={() => void removeModelFromExtra(name, m.id)}
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
              <div className="dsmm-modelAdd">
                <input
                  className="dsmm-input dsmm-modelInput"
                  placeholder="模型 ID,回车添加"
                  value={addModelTarget === name ? addModelId : ''}
                  onChange={(e) => {
                    setAddModelTarget(name)
                    setAddModelId(e.target.value)
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      void addModelToExtra(name, addModelId)
                      setAddModelId('')
                      setAddModelTarget('')
                    }
                  }}
                />
                <button
                  type="button"
                  className="dsmm-toggleBtn dsmm-modelAddBtn"
                  onClick={() => {
                    void addModelToExtra(name, addModelId)
                    setAddModelId('')
                    setAddModelTarget('')
                  }}
                >
                  + 添加模型
                </button>
              </div>
            </div>
            <div className="dsmm-cardActions">
              <button className="dsmm-dangerButton" onClick={() => void removeExtra(name)}>
                移除
              </button>
            </div>
          </div>
        ))}

        {Object.keys(backends).length > 0 && (
          <>
            <div className="dsmm-field" style={{ marginTop: 8 }}>
              <label className="dsmm-fieldLabel">当前后端</label>
              <select
                className="dsmm-input dsmm-selectInput"
                value={activeBackend}
                onChange={(e) => void switchBackend(e.target.value)}
                disabled={!writable}
              >
                <option value="">(未配置)</option>
                {backendOptions.map((key) => (
                  <option key={key} value={key}>
                    {BACKEND_LABELS[key] ?? `${key} (${backends[key]?.model ?? ''})`}
                  </option>
                ))}
              </select>
            </div>
            <div className="dsmm-listGroup">
              {Object.entries(backends).map(([key, spec]) => (
                <div key={key} className="dsmm-cardRow">
                  <div className="dsmm-cardMain">
                    <div className="dsmm-cardTitle">
                      {BACKEND_LABELS[key] ?? key}
                      {key === activeBackend && <span className="dsmm-kindBadge">当前</span>}
                    </div>
                    <p className="dsmm-cardMeta">
                      {spec.kind ?? 'dashscope'} · {spec.model} · Key: {spec.apiKeyEnv}
                      {spec.adapterFile !== undefined ? ` · 适配器: ${spec.adapterFile}` : ''}
                    </p>
                  </div>
                  <div className="dsmm-cardActions">
                    <button className="dsmm-dangerButton" onClick={() => void removeBackend(key)}>
                      移除
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        <div className="dsmm-listGroup">
          <button className="dsmm-toggleBtn" type="button" onClick={() => setBackendFormOpen((v) => !v)}>
            {backendFormOpen ? '收起添加表单' : '+ 添加生图后端'}
          </button>
          {backendFormOpen && (
            <div className="dsmm-formBody">
              <div className="dsmm-grid2">
                <div className="dsmm-field">
                  <label className="dsmm-fieldLabel">新后端名称</label>
                  <input className="dsmm-input" placeholder="如 my-api" value={nbName} onChange={(e) => setNbName(e.target.value)} />
                </div>
                <div className="dsmm-field">
                  <label className="dsmm-fieldLabel">协议</label>
                  <select className="dsmm-input dsmm-selectInput" value={nbKind} onChange={(e) => setNbKind(e.target.value)}>
                    <option value="dashscope">DashScope 异步轮询</option>
                    <option value="dashscope-v2">DashScope 同步</option>
                    <option value="openai-images">OpenAI 兼容 /images/generations</option>
                    <option value="custom">自定义适配器文件</option>
                  </select>
                </div>
                <div className="dsmm-field">
                  <label className="dsmm-fieldLabel">Base URL</label>
                  <input className="dsmm-input" placeholder="https://api.example.com/v1" value={nbBaseURL} onChange={(e) => setNbBaseURL(e.target.value)} />
                </div>
                <div className="dsmm-field">
                  <label className="dsmm-fieldLabel">Key 引用名</label>
                  <input className="dsmm-input" placeholder="如 MY_API_KEY" value={nbKeyEnv} onChange={(e) => setNbKeyEnv(e.target.value)} />
                </div>
                <div className="dsmm-field">
                  <label className="dsmm-fieldLabel">模型 ID</label>
                  <input className="dsmm-input" placeholder="如 my-image-model" value={nbModel} onChange={(e) => setNbModel(e.target.value)} />
                </div>
                <div className="dsmm-field">
                  <label className="dsmm-fieldLabel">默认尺寸</label>
                  <input className="dsmm-input" placeholder="1024*1024" value={nbSize} onChange={(e) => setNbSize(e.target.value)} />
                </div>
                {nbKind === 'custom' && (
                  <div className="dsmm-field dsmm-fieldFull">
                    <label className="dsmm-fieldLabel">适配器文件路径</label>
                    <input className="dsmm-input" placeholder="D:/my-adapters/my-api.mjs" value={nbAdapter} onChange={(e) => setNbAdapter(e.target.value)} />
                    <p className="dsmm-platformMeta">仅加载你信任的文件 —— 适配器拥有完整进程权限。</p>
                  </div>
                )}
              </div>
              <div className="dsmm-editorActions dsmm-formActions">
                <button className="dsmm-primaryButton" onClick={() => void addBackend()}>
                  添加后端
                </button>
              </div>
            </div>
          )}
        </div>
      </Section>

      <Section title="高级" tag="细节" open={openSections.has('advanced')} onToggle={() => toggleSection('advanced')}>
        <KeyCard
          api={api}
          name="视觉转写 Key"
          tag="看图"
          refName={REF_VISION}
          placeholder="粘贴视觉 API Key (任意 OpenAI 兼容端点)"
          hint="发截图/图片时由该视觉端点转述内容给主模型"
          onSaved={reload}
        />

        <KeyCard
          api={api}
          name="图像生成 Key"
          tag="画图"
          refName={REF_IMAGE}
          placeholder="粘贴图像生成 API Key"
          hint="生图后端使用的密钥"
          onSaved={reload}
        />

        <div className="dsmm-cardRow">
          <div className="dsmm-cardMain">
            <div className="dsmm-cardTitle">观看路由</div>
            <p className="dsmm-cardMeta">使用该 provider 的会话会触发图片转写(可指向任意你配置的 provider)</p>
          </div>
          <div className="dsmm-cardActions">
            <CommitInput
              value={visionSummary.watchProvider}
              placeholder="如 deepseek-vision 或你的 provider"
              disabled={!writable}
              width={200}
              onSubmit={(v) => void setVisionField(['vision', 'watchProvider'], v)}
            />
          </div>
        </div>
        <div className="dsmm-cardRow">
          <div className="dsmm-cardMain">
            <div className="dsmm-cardTitle">转写提供商</div>
            <p className="dsmm-cardMeta">负责"看"图的视觉模型端点(任意 OpenAI 兼容)</p>
          </div>
          <div className="dsmm-cardActions">
            <CommitInput
              value={visionSummary.provider}
              placeholder="留空表示关闭转写;填你在「模型」页里添加的 provider 名"
              disabled={!writable}
              width={200}
              onSubmit={(v) => void setVisionField(['vision', 'transcribeProvider'], v)}
            />
          </div>
        </div>
        <div className="dsmm-cardRow">
          <div className="dsmm-cardMain">
            <div className="dsmm-cardTitle">转写模式</div>
            <p className="dsmm-cardMeta">auto 按图片类型路由;或固定 verbatim / structured / ocr / describe / error-fix / chart-sql / design-code</p>
          </div>
          <div className="dsmm-cardActions">
            <select
              className="dsmm-input dsmm-selectInput dsmm-selectMode"
              value={visionSummary.mode}
              disabled={!writable}
              onChange={(e) => void setVisionField(['vision', 'transcribeMode'], e.target.value)}
            >
              {['auto', 'verbatim', 'structured', 'ocr', 'describe', 'error-fix', 'chart-sql', 'design-code'].map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="dsmm-toggleGroup">
          <ToggleRow
            label="多图并行转写"
            hint="每张图独立并发调用(上限 3),多图轮次提速"
            checked={visionSummary.parallel}
            disabled={!writable}
            onChange={(v) => void setVisionField(['vision', 'parallelImages'], v)}
          />
          <ToggleRow
            label="截图场景提示"
            hint="截图转写后自动附加诊断与修复建议提示"
            checked={visionSummary.sceneHints}
            disabled={!writable}
            onChange={(v) => void setVisionField(['vision', 'sceneHints'], v)}
          />
          <ToggleRow
            label="敏感信息脱敏"
            hint="转写文本打码手机号 / 身份证 / 邮箱"
            checked={visionSummary.redact}
            disabled={!writable}
            onChange={(v) => void setVisionField(['vision', 'redactSensitive'], v)}
          />
          <ToggleRow
            label="审计日志"
            hint="每次转写记录时间 / 图片数 / 字节数 / 耗时 / 提供商"
            checked={visionSummary.audit}
            disabled={!writable}
            onChange={(v) => void setVisionField(['vision', 'auditLog'], v)}
          />
        </div>
        <p className="dsmm-platformMeta dsmm-sectionNote">
          降级链(fallbackProviders)、成本路由(costProvider)、自定义模式(customModes)等高级项通过 settings.yaml 配置。
        </p>

        <div className="dsmm-genActions">
          <button className="dsmm-genDownload" type="button" onClick={exportConfig}>
            导出配置 (JSON)
          </button>
          <label className="dsmm-genDownload dsmm-genDownloadLabel">
            导入配置
            <input
              type="file"
              accept="application/json,.json"
              className="dsmm-hiddenFile"
              onChange={(event) => {
                const file = event.target.files?.[0]
                if (file !== undefined) void file.text().then(importConfig).catch(() => setMsg('导入失败: 无法读取文件'))
                event.target.value = ''
              }}
            />
          </label>
        </div>
        <p className="dsmm-platformMeta dsmm-advancedNote">
          导出当前全部配置为 JSON;导入时仅接受允许的字段(providers / extraProviders / vision / ocr / image / allowedApiKeyEnvs / trustedBaseUrls),Key 本身不包含在配置中。
        </p>
      </Section>

      <p className="dsmm-intro">
        说明:Key 只存入凭据服务,不写入配置文件明文;模型选择器里的 DeepSeek (Vision) 即"带眼睛的 DeepSeek"。
      </p>
    </section>
  )
}

function MultimodalSection(props: SettingsSectionOwnerProps & { api?: MinimalApi }): React.ReactElement | null {
  const { api } = props
  if (api === undefined) return null
  return <MultimodalPanel api={api} />
}

// ---------------------------------------------------------------------------
// generate_image tool card
// ---------------------------------------------------------------------------

/** Minimal durable image reference shape (matches the host attachment ref). */
interface GenImageAttachment {
  attachmentId: string
  mediaType?: string
  bytes?: number
  width?: number
  height?: number
  name?: string
}

/** Minimal conversation service face we consume (`ctx.get('conversation')`). */
interface ConversationLike {
  resolveImage(sessionId: string, attachment: GenImageAttachment): Promise<string>
  /** Runtime-probed draft-image send path (feature 2026-08-16, crop-to-ask). */
  requireSessions?(): {
    binding(id: string): {
      session: {
        prompt(content: unknown[], mode: string): Promise<{ ok: boolean; error?: { code?: string; message?: string } }>
      }
    } | undefined
  }
  serializeImages?(files: File[]): Promise<Array<{ type: 'image'; mediaType: string; data: string; name?: string }>>
}

/**
 * Send a cropped image region + question into the session through the
 * conversation draft-image channel. Returns false when the channel is
 * unavailable — the caller then falls back to a download/copy affordance.
 */
async function sendCropQuestion(
  conversation: ConversationLike,
  sessionId: string,
  cropFile: File,
  question: string,
): Promise<boolean> {
  try {
    const sessions = conversation.requireSessions?.()
    const session = sessions?.binding?.(sessionId)?.session
    if (session === undefined || conversation.serializeImages === undefined) return false
    const content = [
      ...(await conversation.serializeImages([cropFile])),
      { type: 'text', text: question },
    ]
    const result = await session.prompt(content, 'queue')
    return result.ok
  } catch {
    return false
  }
}

interface GenImageContentBlock {
  type: string
  text?: string
  attachment?: GenImageAttachment
}

/** Loose ToolCallBlock shape: settled (`kind`) or running. */
interface GenImageBlock {
  kind?: string
  content?: readonly GenImageContentBlock[]
  isError?: boolean
  error?: { code?: string }
  argsRaw?: string
  call?: { argsRaw?: string } | null
}

interface GenImageArgs {
  prompt?: string
  refine?: string
  size?: string
  n?: number
  negative_prompt?: string
}

function parseGenImageArgs(raw: string | undefined): GenImageArgs {
  if (raw === undefined || raw === '') return {}
  try {
    const parsed = JSON.parse(raw) as Record<string, unknown>
    return {
      prompt: typeof parsed.prompt === 'string' ? parsed.prompt : undefined,
      refine: typeof parsed.refine === 'string' ? parsed.refine : undefined,
      size: typeof parsed.size === 'string' ? parsed.size : undefined,
      n: typeof parsed.n === 'number' ? parsed.n : undefined,
      negative_prompt: typeof parsed.negative_prompt === 'string' ? parsed.negative_prompt : undefined,
    }
  } catch {
    return {}
  }
}

function mediaExtension(mediaType: string | undefined): string {
  if (mediaType === undefined) return 'png'
  if (mediaType.includes('jpeg') || mediaType.includes('jpg')) return 'jpg'
  if (mediaType.includes('webp')) return 'webp'
  return 'png'
}

interface GenImageCell {
  url?: string
  error?: string
}

/**
 * The dedicated generate_image tool card: metadata row (model · count · size),
 * prompt line, thumbnail grid with click-to-zoom lightbox, and a per-image
 * download button. Falls back gracefully when the conversation image service
 * is unavailable (e.g. toolview mounting outside a live session) or a
 * thumbnail fails to load.
 */

/** Drag-to-select region over the lightbox image, then ask about that crop. */
function CropAskLayer(props: {
  url: string
  sending: boolean
  failMessage: string
  onCancel: () => void
  onCrop: (file: File, question: string) => void
}): React.ReactElement {
  const { url, sending, failMessage, onCancel, onCrop } = props
  const wrapRef = useRef<HTMLDivElement>(null)
  const imgRef = useRef<HTMLImageElement>(null)
  const [rect, setRect] = useState<{ x: number; y: number; w: number; h: number } | null>(null)
  const [drag, setDrag] = useState<{ sx: number; sy: number; cx: number; cy: number } | null>(null)
  const [question, setQuestion] = useState('')

  const overlayPoint = (event: React.MouseEvent): { x: number; y: number } => {
    const box = wrapRef.current?.getBoundingClientRect()
    if (box === undefined) return { x: 0, y: 0 }
    return { x: event.clientX - box.left, y: event.clientY - box.top }
  }

  const onMouseDown = (event: React.MouseEvent): void => {
    if (sending) return
    const p = overlayPoint(event)
    setDrag({ sx: p.x, sy: p.y, cx: p.x, cy: p.y })
    setRect(null)
  }
  const onMouseMove = (event: React.MouseEvent): void => {
    if (drag === null) return
    const p = overlayPoint(event)
    setDrag({ ...drag, cx: p.x, cy: p.y })
  }
  const onMouseUp = (): void => {
    if (drag === null) return
    const { sx, sy, cx, cy } = drag
    const x = Math.min(sx, cx)
    const y = Math.min(sy, cy)
    const w = Math.abs(cx - sx)
    const h = Math.abs(cy - sy)
    setRect(w > 8 && h > 8 ? { x, y, w, h } : null)
    setDrag(null)
  }

  const confirm = (): void => {
    const img = imgRef.current
    if (rect === null || img === null) return
    const scaleX = img.naturalWidth / img.clientWidth
    const scaleY = img.naturalHeight / img.clientHeight
    const canvas = document.createElement('canvas')
    canvas.width = Math.max(1, Math.round(rect.w * scaleX))
    canvas.height = Math.max(1, Math.round(rect.h * scaleY))
    const painter = canvas.getContext('2d')
    if (painter === null) return
    painter.drawImage(
      img,
      rect.x * scaleX,
      rect.y * scaleY,
      rect.w * scaleX,
      rect.h * scaleY,
      0,
      0,
      canvas.width,
      canvas.height,
    )
    canvas.toBlob((blob) => {
      if (blob === null) return
      onCrop(new File([blob], 'crop.png', { type: 'image/png' }), question.trim() || '请仔细查看圈选区域并回答')
    }, 'image/png')
  }

  return (
    <div className="dsmm-cropRoot">
      <div
        className="dsmm-cropStage"
        ref={wrapRef}
        onMouseDown={onMouseDown}
        onMouseMove={onMouseMove}
        onMouseUp={onMouseUp}
        onMouseLeave={onMouseUp}
      >
        <img ref={imgRef} className="dsmm-cropImg" src={url} alt="圈选区域" draggable={false} />
        {rect !== null && (
          <div
            className="dsmm-cropRect"
            style={{ left: rect.x, top: rect.y, width: rect.w, height: rect.h }}
          />
        )}
        {drag !== null && (
          <div
            className="dsmm-cropRect dsmm-cropRectDrag"
            style={{
              left: Math.min(drag.sx, drag.cx),
              top: Math.min(drag.sy, drag.cy),
              width: Math.abs(drag.cx - drag.sx),
              height: Math.abs(drag.cy - drag.sy),
            }}
          />
        )}
      </div>
      <div className="dsmm-cropBar">
        <input
          className="dsmm-cropInput"
          type="text"
          placeholder="在图上拖拽选择区域,输入你的问题(默认:请仔细查看圈选区域并回答)"
          value={question}
          onChange={(event) => setQuestion(event.target.value)}
          disabled={sending}
        />
        <button className="dsmm-cropSend" type="button" onClick={() => void confirm()} disabled={sending || rect === null}>
          {sending ? '发送中…' : '发送提问'}
        </button>
        <button className="dsmm-cropCancel" type="button" onClick={onCancel} disabled={sending}>
          取消
        </button>
      </div>
      {failMessage.length > 0 && <p className="dsmm-genError">{failMessage}</p>}
    </div>
  )
}
function GenerateImageToolView(props: {
  toolName?: string
  block: GenImageBlock
  sessionId?: string
  resolveImage?: (attachment: GenImageAttachment) => Promise<string>
  conversation?: ConversationLike
}): React.ReactElement | null {
  const { block, sessionId, resolveImage, conversation } = props
  const done = block.kind !== undefined

  const [cells, setCells] = useState<GenImageCell[]>([])
  const [lightbox, setLightbox] = useState<number | null>(null)
  const [retryCopied, setRetryCopied] = useState(false)
  const [cropActive, setCropActive] = useState(false)
  const [cropSending, setCropSending] = useState(false)
  const [cropFail, setCropFail] = useState('')

  // Load thumbnail URLs for the settled result's image blocks.
  useEffect(() => {
    if (!done || sessionId === undefined || resolveImage === undefined) {
      setCells([])
      return
    }
    const attachments: GenImageAttachment[] = []
    for (const content of block.content ?? []) {
      if (content.type === 'image' && content.attachment !== undefined) {
        attachments.push(content.attachment)
      }
    }
    setCells(attachments.map(() => ({})))
    let cancelled = false
    attachments.forEach((attachment, index) => {
      resolveImage(attachment)
        .then((url) => {
          if (cancelled) return
          setCells((prev) => {
            const next = prev.slice()
            next[index] = { url }
            return next
          })
        })
        .catch((error: unknown) => {
          if (cancelled) return
          setCells((prev) => {
            const next = prev.slice()
            next[index] = { error: error instanceof Error ? error.message : String(error) }
            return next
          })
        })
    })
    return () => {
      cancelled = true
    }
  }, [done, sessionId, resolveImage, block])

  // Close the lightbox on Escape.
  useEffect(() => {
    if (lightbox === null) return
    const onKey = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') setLightbox(null)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [lightbox])

  // Running state: show the prompt from the call arguments.
  if (!done) {
    const args = parseGenImageArgs(block.argsRaw)
    return (
      <div className="dsmm-genCard">
        <div className="dsmm-genHead">
          <h3 className="dsmm-genTitle">🎨 生成图片</h3>
          <span className="dsmm-genMeta">进行中…</span>
        </div>
        {args.prompt !== undefined && args.prompt.length > 0 && <p className="dsmm-genPrompt">{args.prompt}</p>}
        <p className="dsmm-genRunning">
          <span className="dsmm-genSpinner" aria-hidden="true" />
          正在调用文生图模型,请稍候
        </p>
      </div>
    )
  }

  // Settled state.
  const attachments: GenImageAttachment[] = []
  const textLines: string[] = []
  for (const content of block.content ?? []) {
    if (content.type === 'image' && content.attachment !== undefined) attachments.push(content.attachment)
    else if (content.type === 'text' && content.text !== undefined && content.text.length > 0) textLines.push(content.text)
  }

  // Failures carry no images: show the error summary.
  if (attachments.length === 0) {
    const failedArgs = parseGenImageArgs(block.call?.argsRaw ?? block.argsRaw)
    const retryText =
      failedArgs.prompt !== undefined && failedArgs.prompt.length > 0
        ? `重新生成图片: ${failedArgs.prompt}`
        : failedArgs.refine !== undefined && failedArgs.refine.length > 0
          ? `重新生成图片: ${failedArgs.refine}`
          : ''
    return (
      <div className="dsmm-genCard">
        <div className="dsmm-genHead">
          <h3 className="dsmm-genTitle">🎨 生成图片</h3>
          <span className="dsmm-genMeta">{block.isError ? '失败' : '未返回图片'}</span>
        </div>
        <p className="dsmm-genError">{textLines[textLines.length - 1] ?? (block.error?.code ?? '未返回任何图片')}</p>
        {retryText.length > 0 && (
          <div className="dsmm-genActions">
            <button
              className="dsmm-genRetry"
              type="button"
              onClick={() => {
                void navigator.clipboard
                  ?.writeText(retryText)
                  .then(() => setRetryCopied(true))
                  .catch(() => setRetryCopied(false))
              }}
            >
              {retryCopied ? '已复制，粘贴到输入框发送即可' : '复制重试指令'}
            </button>
          </div>
        )}
      </div>
    )
  }

  const args = parseGenImageArgs(block.call?.argsRaw ?? block.argsRaw)
  const metaParts: string[] = []
  for (const line of textLines) {
    const trimmed = line.trim()
    if (trimmed.length > 0) {
      const firstLine = trimmed.split('\n', 1)[0] ?? trimmed
      metaParts.push(firstLine.replace(/^【生图完成】/, ''))
      break
    }
  }
  if (args.size !== undefined) metaParts.push(args.size)
  const meta = metaParts.join(' · ')

  const downloadName = (attachment: GenImageAttachment, index: number): string =>
    attachment.name !== undefined && attachment.name.length > 0
      ? attachment.name
      : `gen-${attachment.attachmentId ?? index}.${mediaExtension(attachment.mediaType)}`

  const overlayImage = lightbox !== null ? cells[lightbox] : undefined

  return (
    <div className="dsmm-genCard">
      <div className="dsmm-genHead">
        <h3 className="dsmm-genTitle">🎨 生成图片</h3>
        {meta.length > 0 && <span className="dsmm-genMeta">{meta}</span>}
      </div>
      {args.prompt !== undefined && args.prompt.length > 0 && <p className="dsmm-genPrompt">提示词: {args.prompt}</p>}
      <div className="dsmm-genGrid">
        {attachments.map((attachment, index) => {
          const cell = cells[index]
          if (cell?.url !== undefined) {
            return (
              <div className="dsmm-genCell" key={`${attachment.attachmentId ?? index}`}>
                <img
                  className="dsmm-genThumb"
                  src={cell.url}
                  alt={args.prompt ?? `生成图片 ${index + 1}`}
                  onClick={() => setLightbox(index)}
                />
              </div>
            )
          }
          if (cell?.error !== undefined) {
            return (
              <div className="dsmm-genCell dsmm-genCellError" key={`${attachment.attachmentId ?? index}`}>
                加载失败
              </div>
            )
          }
          return (
            <div className="dsmm-genCell dsmm-genLoading" key={`${attachment.attachmentId ?? index}`}>
              加载中…
            </div>
          )
        })}
      </div>
      {resolveImage !== undefined && (
        <div className="dsmm-genActions">
          {attachments.map((attachment, index) => {
            const cell = cells[index]
            if (cell?.url === undefined) return null
            return (
              <a
                className="dsmm-genDownload"
                key={`dl-${attachment.attachmentId ?? index}`}
                href={cell.url}
                download={downloadName(attachment, index)}
              >
                保存图片 {attachments.length > 1 ? index + 1 : ''}
              </a>
            )
          })}
          {conversation !== undefined && sessionId !== undefined && (
            <button
              className="dsmm-genDownload"
              type="button"
              onClick={() => {
                setCropFail('')
                setCropActive(true)
              }}
            >
              圈选提问
            </button>
          )}
          <button
            className="dsmm-genDownload"
            type="button"
            onClick={() => {
              void navigator.clipboard?.writeText(
                JSON.stringify(
                  {
                    ...(args.prompt !== undefined ? { prompt: args.prompt } : {}),
                    ...(args.refine !== undefined ? { refine: args.refine } : {}),
                    ...(args.size !== undefined ? { size: args.size } : {}),
                    ...(args.n !== undefined ? { n: args.n } : {}),
                    ...(args.negative_prompt !== undefined ? { negative_prompt: args.negative_prompt } : {}),
                  },
                  null,
                  2,
                ),
              )
            }}
          >
            复制参数
          </button>
        </div>
      )}
      {overlayImage?.url !== undefined && lightbox !== null && (
        <div
          className="dsmm-genOverlay"
          role="dialog"
          aria-modal="true"
          aria-label={args.prompt ?? '生成图片'}
          onClick={() => {
            if (cropActive) return
            setLightbox(null)
            setCropActive(false)
          }}
        >
          <button
            className="dsmm-genOverlayClose"
            aria-label="关闭"
            onClick={(event) => {
              event.stopPropagation()
              setLightbox(null)
              setCropActive(false)
            }}
          >
            ✕
          </button>
          {cropActive && conversation !== undefined && sessionId !== undefined ? (
            <CropAskLayer
              url={overlayImage.url}
              sending={cropSending}
              failMessage={cropFail}
              onCancel={() => setCropActive(false)}
              onCrop={(file, question) => {
                setCropSending(true)
                void sendCropQuestion(conversation, sessionId, file, question)
                  .then((sent) => {
                    setCropSending(false)
                    if (sent) {
                      setLightbox(null)
                      setCropActive(false)
                    } else {
                      // Fallback: let the user save the crop and paste it manually.
                      const link = document.createElement('a')
                      link.href = URL.createObjectURL(file)
                      link.download = 'crop.png'
                      link.click()
                      URL.revokeObjectURL(link.href)
                      setCropFail('发送通道不可用 — 已下载裁剪图,请手动拖入会话提问')
                    }
                  })
                  .catch(() => {
                    setCropSending(false)
                    setCropFail('发送失败,请重试')
                  })
              }}
            />
          ) : (
            <img className="dsmm-genOverlayImg" src={overlayImage.url} alt={args.prompt ?? `生成图片 ${lightbox + 1}`} />
          )}
        </div>
      )}
    </div>
  )
}

function registerGenerateImageToolView(ctx: ClientContext): void {
  ensureGenImageStyles()
  const conversation = ctx.get('conversation') as ConversationLike | undefined
  ctx.slots.inject('tool.call.toolview', () =>
    ctx.slots.register(
      {
        name: 'tool.call.toolview',
        key: 'generate_image',
        inject: (sessionId: string) => ({
          resolveImage:
            conversation === undefined
              ? undefined
              : (attachment: GenImageAttachment) => conversation.resolveImage(sessionId, attachment),
          conversation,
        }),
      },
      GenerateImageToolView,
    ),
  )
}

export function apply(ctx: ClientContext): void {
  ensureStyles()
  const connection = ctx.get('connection')
  if (connection === undefined) return
  const api = connection.api as MinimalApi
  ctx.slots.inject('settings.section', () =>
    ctx.slots.register(
      {
        name: 'settings.section',
        id: 'multimodal',
        order: 30,
        label: () => '多模态',
        inject: () => ({ api }),
      },
      MultimodalSection,
    ),
  )
  registerGenerateImageToolView(ctx)
}
