/**
 * `generate_image` — text-to-image via Aliyun Bailian (DashScope) wanx
 * models. The tool submits an async synthesis task, polls it to completion,
 * downloads the result bytes into the durable attachment store, and injects
 * the image into the session so the user sees it in the conversation.
 */
import type { Context } from '@deepseek-ai/cordis'
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import {
  LlmError,
  MessageId,
  type ContentBlock,
  type LlmRuntime,
  type Message,
} from '@deepseek-ai/dsh-llm'

export interface ImageBackendSettings {
  /** DashScope async-task protocol, DashScope multimodal-generation sync, OpenAI-compatible /images/generations, or a custom adapter file. */
  kind: 'dashscope' | 'dashscope-v2' | 'openai-images' | 'custom'
  baseURL: string
  apiKeyEnv: string
  model: string
  defaultSize: string
  pollIntervalMs: number
  pollTimeoutMs: number
  /** Adapter file path for kind: 'custom'. */
  adapterFile?: string
}

/**
 * Contract for a user-supplied custom image backend (feature 2026-08-16).
 * Write an ES module (.mjs) exporting a default object with `generate()`.
 * Only load files you trust — the adapter runs with full process privileges.
 */
export interface CustomImageBackendAdapter {
  generate(req: {
    prompt: string
    size: string
    n: number
    negative_prompt?: string
    /** Reference image for image-to-image: http(s) URL or base64 data URL. */
    reference_image?: string
    apiKey: string
    baseURL: string
    model: string
    signal: AbortSignal
    fetch: typeof fetch
    log: (message: string) => void
  }): Promise<{ urls?: string[]; b64s?: string[] }>
}

const customAdapterCache = new Map<string, CustomImageBackendAdapter>()

async function loadCustomAdapter(filePath: string): Promise<CustomImageBackendAdapter> {
  const cached = customAdapterCache.get(filePath)
  if (cached !== undefined) return cached
  const absolute = resolve(filePath)
  const mod = (await import(pathToFileURL(absolute).href)) as {
    default?: { generate?: unknown }
    generate?: unknown
  }
  const adapter = (mod.default ?? mod) as Partial<CustomImageBackendAdapter>
  if (typeof adapter.generate !== 'function') {
    throw new Error(
      `custom image adapter "${filePath}" must export a default object with a generate() function`,
    )
  }
  customAdapterCache.set(filePath, adapter as CustomImageBackendAdapter)
  return adapter as CustomImageBackendAdapter
}

export interface ImageGenSettings {
  backend: ImageBackendSettings
  /** Key of the active backend (for error/labels). */
  activeBackendKey?: string
  /** Fallback backends tried in order when the primary backend request fails (feature 2026-08-16). */
  failovers?: ImageBackendSettings[]
  /** Chinese-text garbling verification after generation (feature 2026-08-16). */
  verify?: {
    enabled: boolean
    provider: string
    model: string
  }
}

export const DEFAULT_IMAGE_GEN_PROMPT_HINT =
  '生成图片时请把用户意图翻译为详细、具体的画面描述(prompt),包含主体、场景、风格、光线等要素。'

const SIZE_PATTERN = /^(\d{3,4})\*(\d{3,4})$/

function validateSize(size: string, maxSide = 1440): string {
  const match = SIZE_PATTERN.exec(size)
  if (match === null) throw new Error(`size must be WxH like "1024*1024"; got "${size}"`)
  const w = Number(match[1])
  const h = Number(match[2])
  if (w < 512 || w > maxSide || h < 512 || h > maxSide || w * h > maxSide * maxSide) {
    throw new Error(`size ${size} out of range: each side 512..${maxSide} and total pixels <= ${maxSide}*${maxSide}`)
  }
  return `${w}*${h}`
}

interface DashScopeTask {
  task_id: string
  task_status: string
}

interface DashScopeError {
  code?: string
  message?: string
}

async function dashscopeJson(
  url: string,
  init: RequestInit,
  signal: AbortSignal,
): Promise<{ status: number; body: Record<string, unknown> }> {
  let response: Response
  try {
    response = await fetch(url, { ...init, signal })
  } catch (error) {
    if (signal.aborted) throw new LlmError('image generation aborted by caller', 'ABORTED', { cause: error })
    throw new Error(`DashScope request failed: ${String(error)}`)
  }
  let body: Record<string, unknown> = {}
  try {
    body = (await response.json()) as Record<string, unknown>
  } catch {
    // keep empty body
  }
  if (!response.ok) {
    // DashScope errors live under `output`; OpenAI-compatible backends use
    // `error`. Parse both so the real reason surfaces instead of a generic
    // "DashScope HTTP xxx".
    const oai = (body.error ?? {}) as { code?: string; message?: string }
    const err = (body.output ?? {}) as DashScopeError
    const code = (err.code ?? oai.code ?? body.code ?? `HTTP_${response.status}`) as string
    const message = (err.message ?? oai.message ?? body.message ?? `HTTP ${response.status}`) as string
    if (code === 'Throttling' || response.status === 429) {
      throw new LlmError(`DashScope throttled: ${message}`, 'RATE_LIMIT', { status: response.status })
    }
    if (code === 'InvalidApiKey' || code === 'invalid_api_key') {
      throw new LlmError(`DashScope invalid API key: ${message}`, 'AUTH', { status: response.status })
    }
    throw new Error(`DashScope error ${code}: ${message}`)
  }
  return { status: response.status, body }
}

function sleep(ms: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      signal.removeEventListener('abort', onAbort)
      resolve()
    }, ms)
    const onAbort = () => {
      clearTimeout(timer)
      reject(new LlmError('image generation aborted by caller', 'ABORTED'))
    }
    signal.addEventListener('abort', onAbort, { once: true })
  })
}

async function waitForTask(
  baseURL: string,
  apiKey: string,
  taskId: string,
  settings: ImageBackendSettings,
  signal: AbortSignal,
): Promise<Record<string, unknown>> {
  const deadline = Date.now() + settings.pollTimeoutMs
  let attempt = 0
  while (Date.now() < deadline) {
    if (signal.aborted) throw new LlmError('image generation aborted by caller', 'ABORTED')
    const { body } = await dashscopeJson(
      `${baseURL}/api/v1/tasks/${taskId}`,
      { headers: { authorization: `Bearer ${apiKey}` } },
      signal,
    )
    const output = (body.output ?? {}) as DashScopeTask
    if (output.task_status === 'SUCCEEDED') return body
    if (output.task_status === 'FAILED' || output.task_status === 'CANCELED' || output.task_status === 'UNKNOWN') {
      const err = body as { code?: string; message?: string }
      throw new Error(`image task ${output.task_status}: ${err.message ?? err.code ?? 'unknown task failure'}`)
    }
    attempt += 1
    const interval = settings.pollIntervalMs * (attempt > 10 ? 2 : 1)
    await sleep(Math.min(interval, 5000), signal)
  }
  throw new Error(`image task timed out after ${settings.pollTimeoutMs}ms`)
}

function mediaTypeFor(url: string, contentType: string | null): 'image/png' | 'image/jpeg' | 'image/webp' {
  if (contentType !== null) {
    if (contentType.includes('png')) return 'image/png'
    if (contentType.includes('jpeg') || contentType.includes('jpg')) return 'image/jpeg'
    if (contentType.includes('webp')) return 'image/webp'
  }
  const lower = url.toLowerCase()
  if (lower.endsWith('.png')) return 'image/png'
  if (lower.endsWith('.webp')) return 'image/webp'
  return 'image/jpeg'
}

/**
 * Iterative generation context (feature 2026-08-16): remembers each session's
 * last successful generation so a follow-up call can pass `refine` ("make the
 * background darker") instead of re-specifying the full prompt. LRU-bounded.
 */
interface GenSessionState {
  prompt: string
  size?: string
  model: string
  at: number
}
const MAX_GEN_SESSIONS = 200
const lastGenBySession = new Map<string, GenSessionState>()
const genSessionOrder: string[] = []

function rememberGen(sessionKey: string, state: GenSessionState): void {
  if (!lastGenBySession.has(sessionKey)) genSessionOrder.push(sessionKey)
  lastGenBySession.set(sessionKey, state)
  while (lastGenBySession.size > MAX_GEN_SESSIONS) {
    const oldest = genSessionOrder.shift()
    if (oldest !== undefined) lastGenBySession.delete(oldest)
  }
}

/** Compose the effective prompt: an explicit prompt wins, else refine on top of the last one. */
function effectivePrompt(sessionKey: string, prompt: string | undefined, refine: string | undefined): string {
  if (prompt !== undefined && prompt.trim().length > 0) return prompt.trim()
  if (refine !== undefined && refine.trim().length > 0) {
    const prev = lastGenBySession.get(sessionKey)
    if (prev !== undefined) return `${prev.prompt}。调整要求: ${refine.trim()}`
    // No prior generation in this session: silently using the refine text as a
    // full prompt would produce confusing images. Surface a clear error so the
    // model retries with a complete `prompt` instead.
    throw new Error(
      'generate_image: refine requires a previous generation in this session (no prior image found) — provide a full `prompt` instead',
    )
  }
  return ''
}

// Audit fix (2026-08-15): SSRF guard. The image URL is returned by the image
// backend (or a MITM), so a malicious/compromised backend could point it at an
// internal or loopback address to make dsh fetch internal resources. Only allow
// public http(s) hosts; reject loopback, private RFC1918, link-local, and
// unique-local addresses.
const BLOCKED_HOST_PATTERNS: RegExp[] = [
  /^localhost$/i,
  /^127\./,
  /^0\.0\.0\.0$/,
  /^10\./,
  /^192\.168\./,
  /^172\.(1[6-9]|2\d|3[01])\./,
  /^169\.254\./,
  /^\[?::1\]?$/i,
  /^fe80:/i,
  /^fc00:/i,
  /^fd[0-9a-f]{0,2}:/i,
]

function isPublicHttpUrl(url: string): boolean {
  let parsed: URL
  try {
    parsed = new URL(url)
  } catch {
    return false
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false
  const host = parsed.hostname
  if (host === '') return false
  if (BLOCKED_HOST_PATTERNS.some((re) => re.test(host))) return false
  // Explicit IPv4 private-range check (covers mapped/edge cases).
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) {
    const parts = host.split('.').map(Number)
    if (parts.some((p) => Number.isNaN(p) || p > 255)) return false
    if (parts[0] === 0 || parts[0] === 10 || parts[0] === 127) return false
    if (parts[0] === 169 && parts[1] === 254) return false
    if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return false
    if (parts[0] === 192 && parts[1] === 168) return false
  }
  return true
}
/** Exported for unit tests. */
export { isPublicHttpUrl }

async function downloadImage(url: string, signal: AbortSignal): Promise<{ data: Uint8Array; mediaType: 'image/png' | 'image/jpeg' | 'image/webp' }> {
  if (!isPublicHttpUrl(url)) {
    throw new Error(`refusing to download image from non-public URL (possible SSRF): ${url}`)
  }
  const response = await fetch(url, { signal })
  if (!response.ok) throw new Error(`failed to download generated image (HTTP ${response.status})`)
  const data = new Uint8Array(await response.arrayBuffer())
  if (data.byteLength === 0) throw new Error('downloaded generated image is empty')
  return { data, mediaType: mediaTypeFor(url, response.headers.get('content-type')) }
}

/** One automatic retry for transient download failures (feature 2026-08-16). */
async function downloadImageWithRetry(
  url: string,
  signal: AbortSignal,
): Promise<{ data: Uint8Array; mediaType: 'image/png' | 'image/jpeg' | 'image/webp' }> {
  try {
    return await downloadImage(url, signal)
  } catch (error) {
    if (signal.aborted) throw error
    return await downloadImage(url, signal)
  }
}

/**
 * Call one image backend and collect result URLs / base64 payloads.
 * Throws on backend request failure so a caller can fail over to the next one.
 */
async function collectFromBackend(
  ctx: Context,
  backend: ImageBackendSettings,
  resolveKey: (ref: string, route: string) => Promise<string>,
  backendKey: string,
  effective: string,
  size: string,
  n: number,
  negativePrompt: string | undefined,
  referenceImage: string | undefined,
  signal: AbortSignal,
): Promise<{ urls: string[]; b64s: string[] }> {
  if (referenceImage !== undefined && backend.kind !== 'dashscope-v2' && backend.kind !== 'custom') {
    throw new Error(`generate_image: reference_image is only supported by dashscope-v2/custom backends (current: ${backend.kind})`)
  }
  // Explicit size-cap check per backend so a 2048 size from a dashscope-v2
  // primary fails fast on a 1440-max failover instead of hitting the API.
  const backendMaxSide = backend.kind === 'dashscope-v2' ? 2048 : 1440
  const [w, h] = size.split('*').map(Number)
  if (w > backendMaxSide || h > backendMaxSide) {
    throw new Error(`image backend "${backendKey}" does not support size ${size} (max side ${backendMaxSide})`)
  }
  const apiKey = await resolveKey(backend.apiKeyEnv, `image-${backendKey}`)
  if (backend.kind === 'custom') {
    return collectFromCustom(
      backend,
      backendKey,
      effective,
      size,
      n,
      negativePrompt,
      referenceImage,
      apiKey,
      signal,
      ctx,
    )
  }
  const urls: string[] = []
  const b64s: string[] = []
  if (backend.kind === 'dashscope' || backend.kind === 'dashscope-v2') {
    if (backend.kind === 'dashscope-v2') {
      // Z-Image / multimodal-generation sync protocol (business-space
      // friendly): POST .../services/aigc/multimodal-generation/generation
      const userContent: Array<Record<string, unknown>> = []
      if (referenceImage !== undefined) userContent.push({ image: referenceImage })
      userContent.push({ text: effective })
      const body = {
        model: backend.model,
        input: {
          messages: [{ role: 'user', content: userContent }],
        },
        parameters: {
          prompt_extend: false,
          size,
          // Pass through when provided; a backend that does not support them
          // returns a visible error instead of silently ignoring the args.
          ...(n > 1 ? { n } : {}),
          ...(negativePrompt !== undefined && negativePrompt.trim().length > 0
            ? { negative_prompt: negativePrompt.trim() }
            : {}),
        },
      }
      const { body: res } = await dashscopeJson(
        `${backend.baseURL}/api/v1/services/aigc/multimodal-generation/generation`,
        {
          method: 'POST',
          headers: {
            authorization: `Bearer ${apiKey}`,
            'content-type': 'application/json',
          },
          body: JSON.stringify(body),
        },
        signal,
      )
      const choices = ((res.output as { choices?: Array<{ message?: { content?: Array<{ image?: string }> } }> })?.choices ?? [])
      for (const choice of choices) {
        for (const item of choice.message?.content ?? []) {
          if (typeof item.image === 'string') urls.push(item.image)
        }
      }
    } else {
      const body = {
        model: backend.model,
        input: {
          prompt: effective,
          ...(negativePrompt !== undefined && negativePrompt.trim().length > 0
            ? { negative_prompt: negativePrompt.trim() }
            : {}),
        },
        parameters: {
          size,
          n,
          prompt_extend: true,
        },
      }
      const { body: created } = await dashscopeJson(
        `${backend.baseURL}/api/v1/services/aigc/text2image/image-synthesis`,
        {
          method: 'POST',
          headers: {
            authorization: `Bearer ${apiKey}`,
            'content-type': 'application/json',
            'x-dashscope-async': 'enable',
          },
          body: JSON.stringify(body),
        },
        signal,
      )
      const task = (created.output ?? {}) as DashScopeTask
      if (task.task_id === undefined) {
        throw new Error(`image task was not created: ${JSON.stringify(created).slice(0, 200)}`)
      }
      const done = await waitForTask(backend.baseURL, apiKey, task.task_id, backend, signal)
      const output = (done.output ?? {}) as {
        results?: Array<{ url?: string; code?: string; message?: string }>
      }
      for (const item of output.results ?? []) {
        if (item.url !== undefined) urls.push(item.url)
      }
    }
  } else {
    // OpenAI-compatible /images/generations (Zhipu cogview, ModelScope, ...).
    const wireSize = size.replace('*', 'x')
    const { body } = await dashscopeJson(
      `${backend.baseURL}/images/generations`,
      {
        method: 'POST',
        headers: {
          authorization: `Bearer ${apiKey}`,
          'content-type': 'application/json',
        },
        body: JSON.stringify({
          model: backend.model,
          prompt: effective,
          size: wireSize,
          n,
          ...(negativePrompt !== undefined && negativePrompt.trim().length > 0
            ? { negative_prompt: negativePrompt.trim() }
            : {}),
        }),
      },
      signal,
    )
    const out = body as {
      images?: Array<{ url?: string; b64_json?: string }>
      data?: Array<{ url?: string; b64_json?: string }>
    }
    // OpenAI-compatible endpoints use `data`; ModelScope uses `images`.
    const items = out.images ?? out.data ?? []
    for (const item of items) {
      if (item.url !== undefined) urls.push(item.url)
      else if (item.b64_json !== undefined) b64s.push(item.b64_json)
    }
  }
  if (urls.length === 0 && b64s.length === 0) {
    throw new Error(`image backend "${backendKey}" returned no results`)
  }
  return { urls, b64s }
}

/**
 * Route to a user-supplied custom adapter (kind: 'custom').
 * The adapter file decides the protocol, request shape, and response parsing —
 * so any API can be plugged in without touching plugin code.
 */
async function collectFromCustom(
  backend: ImageBackendSettings,
  backendKey: string,
  effective: string,
  size: string,
  n: number,
  negativePrompt: string | undefined,
  referenceImage: string | undefined,
  apiKey: string,
  signal: AbortSignal,
  ctx: Context,
): Promise<{ urls: string[]; b64s: string[] }> {
  if (backend.adapterFile === undefined || backend.adapterFile.length === 0) {
    throw new Error(`custom image backend "${backendKey}" has no adapterFile`)
  }
  const adapter = await loadCustomAdapter(backend.adapterFile)
  const result = await adapter.generate({
    prompt: effective,
    size,
    n,
    ...(negativePrompt !== undefined && negativePrompt.trim().length > 0
      ? { negative_prompt: negativePrompt.trim() }
      : {}),
    ...(referenceImage !== undefined ? { reference_image: referenceImage } : {}),
    apiKey,
    baseURL: backend.baseURL,
    model: backend.model,
    signal,
    fetch,
    log: (message) => ctx.logger.info(`dsh-multimodal[custom:${backendKey}] ${message}`),
  })
  const urls = result.urls ?? []
  const b64s = result.b64s ?? []
  if (urls.length === 0 && b64s.length === 0) {
    throw new Error(`custom image backend "${backendKey}" produced no images`)
  }
  return { urls, b64s }
}

const CHINESE_TEXT_VERIFY_PROMPT =
  '检查这张图片中的中文文字是否正常(无乱码、无错字、无缺字、无方块)。' +
  '如果文字正常或图中没有中文,只回复: OK\n' +
  '如果存在乱码/缺字/错字,只回复: GARBLED: 简要原因\n' +
  '不要输出任何其他内容。'

/** Returns true when the generated image's Chinese text looks garbled. */
async function verifyChineseText(
  ctx: Context,
  images: ImageGenImageValue[],
  verify: { provider: string; model: string },
  signal: AbortSignal,
): Promise<boolean> {
  const llm = ctx.get('llm') as LlmRuntime | undefined
  if (llm === undefined || images.length === 0) return false
  const first = images[0]
  const ref: ImageAttachmentRef = {
    attachmentId: first.attachmentId as ImageAttachmentRef['attachmentId'],
    mediaType: first.mediaType,
    bytes: first.bytes,
    width: first.width,
    height: first.height,
  }
  const content: ContentBlock[] = [
    { type: 'image', attachment: ref },
    { type: 'text', text: CHINESE_TEXT_VERIFY_PROMPT },
  ]
  const messages: Message[] = [
    {
      id: MessageId(`dsh-multimodal-verify:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`),
      role: 'user',
      content,
      source: { kind: 'plugin', plugin: 'dsh-multimodal' },
    },
  ]
  const parts: string[] = []
  try {
    if (signal.aborted) return false
    for await (const chunk of llm.stream({
      provider: verify.provider,
      model: verify.model,
      messages,
      // Node 18 compatible: no AbortSignal.any (Node 20.3+). Verification is
      // best-effort, so a standalone timeout is enough. Kept short (15s) so a
      // slow verify model does not stall the tool result for long.
      signal: AbortSignal.timeout(15_000),
    })) {
      if (chunk.type === 'text-delta') parts.push(chunk.text)
    }
  } catch {
    return false // verification failure is not a generation failure
  }
  const verdict = parts.join('').trim().toUpperCase()
  return verdict.startsWith('GARBLED')
}

export function registerImageGenTool(ctx: Context, settings: () => ImageGenSettings, resolveKey: (ref: string, route: string) => Promise<string>): void {
  ctx.tools.register(defineTool({
    name: 'generate_image',
    description:
      'Generate an image from a text prompt using the Aliyun wanx text-to-image model. ' +
      'Returns the generated image(s) into the conversation. The prompt should be a detailed visual description. ' +
      'When the user asks to modify a previously generated image (e.g. "make it darker", "move it left"), ' +
      'pass the change request in `refine` and omit `prompt` — the tool composes the new prompt from the ' +
      'session\'s last generation automatically.',
    parameters: {
      prompt: {
        type: 'string',
        description: 'Detailed visual description of the image to generate (subject, scene, style, lighting). Omit when refining the last image.',
      },
      refine: {
        type: 'string',
        description: 'Change request applied on top of the session\'s last generation (e.g. "darker background", "zoom out"). Requires a previous generation in this session.',
      },
      size: {
        type: 'string',
        description:
          'Output size as WxH, e.g. "1024*1024" (default), "720*1280", "1280*720". Each side 512..1440; dashscope-v2 backends (z-image) allow up to 2048.',
      },
      n: {
        type: 'number',
        description: 'Number of images to generate (1..4, default 1; billed per image).',
      },
      negative_prompt: {
        type: 'string',
        description: 'Optional negative prompt describing what to avoid in the image.',
      },
      reference_image: {
        type: 'string',
        description:
          'Optional reference image for image-to-image edits (dashscope-v2 backends only): ' +
          'an http(s) URL or an attachment id from the conversation. The backend uses it as style/content reference.',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          prompt: { type: 'string', required: true },
          model: { type: 'string', required: true },
          images: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                attachmentId: { type: 'string', required: true },
                mediaType: {
                  type: 'string',
                  enum: ['image/png', 'image/jpeg', 'image/webp'],
                  required: true,
                },
                bytes: { type: 'integer', required: true },
                width: { type: 'integer', required: true },
                height: { type: 'integer', required: true },
                name: { type: 'string' },
              },
            },
          },
          failures: {
            type: 'array',
            items: { type: 'string' },
          },
        },
      },
      render: (_args, value) => {
        const blocks: ContentBlock[] = [
          {
            type: 'text',
            text:
              value.images.length > 0
                ? `已生成 ${value.images.length} 张图片(模型 ${value.model})。\n图片描述: ${value.prompt}`
                : `图片生成失败: 未返回任何图片(模型 ${value.model})`,
          },
          ...value.images.map((image: ImageGenImageValue): ContentBlock => {
            const ref: ImageAttachmentRef = {
              attachmentId: image.attachmentId as ImageAttachmentRef['attachmentId'],
              mediaType: image.mediaType,
              bytes: image.bytes,
              width: image.width,
              height: image.height,
              ...(image.name !== undefined ? { name: image.name } : {}),
            }
            return { type: 'image', attachment: ref }
          }),
        ]
        return blocks
      },
    },
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const sessionKey = exec.agent?.id ?? 'default'
      const effective = effectivePrompt(sessionKey, args.prompt, args.refine)
      if (effective.length === 0) {
        throw new Error('prompt must be a non-empty string (or provide refine after a previous generation in this session)')
      }
      const genSettings = settings()
      const current = genSettings.backend
      const activeBackendKey = genSettings.activeBackendKey ?? 'active'
      const maxSide = current.kind === 'dashscope-v2' ? 2048 : 1440
      const size = args.size === undefined ? current.defaultSize : validateSize(args.size, maxSide)
      const n = Math.min(4, Math.max(1, Math.floor(args.n ?? 1)))
      const attachments = ctx.get('attachments')
      if (attachments === undefined) throw new Error('generate_image: no attachment service is mounted')

      // Reference image for image-to-image: an http(s) URL (SSRF-checked) or a
      // conversation attachment id resolved to a base64 data URL.
      let referenceImage: string | undefined
      if (args.reference_image !== undefined && args.reference_image.trim().length > 0) {
        const raw = args.reference_image.trim()
        if (/^https?:\/\//i.test(raw)) {
          if (!isPublicHttpUrl(raw)) throw new Error(`generate_image: refusing reference image from non-public URL (possible SSRF): ${raw}`)
          referenceImage = raw
        } else {
          try {
            const stored = await attachments.readImage({
              attachmentId: raw as ImageAttachmentRef['attachmentId'],
              mediaType: 'image/png',
              bytes: 0,
              width: 0,
              height: 0,
            } as ImageAttachmentRef)
            referenceImage = `data:${stored.ref.mediaType};base64,${Buffer.from(stored.data).toString('base64')}`
          } catch (error) {
            throw new Error(`generate_image: cannot read reference_image attachment "${raw}": ${String(error)}`)
          }
        }
      }

      if (referenceImage !== undefined && current.kind !== 'dashscope-v2' && current.kind !== 'custom') {
        throw new Error(`generate_image: reference_image is only supported by dashscope-v2/custom backends (current: ${current.kind})`)
      }

      // Backend failover chain: primary first, then configured failovers.
      const chain: Array<{ key: string; backend: ImageBackendSettings }> = [
        { key: activeBackendKey, backend: current },
        ...(genSettings.failovers ?? []).map((backend, i) => ({ key: `failover-${i + 1}`, backend })),
      ]
      let urls: string[] = []
      let b64s: string[] = []
      let lastBackendError = ''
      let usedBackend: ImageBackendSettings = current
      let usedBackendKey = activeBackendKey
      for (const item of chain) {
        try {
          const collected = await collectFromBackend(
            ctx,
            item.backend,
            resolveKey,
            item.key,
            effective,
            size,
            n,
            args.negative_prompt,
            referenceImage,
            exec.signal,
          )
          urls = collected.urls
          b64s = collected.b64s
          usedBackend = item.backend
          usedBackendKey = item.key
          if (item.backend !== current) {
            ctx.logger.warn(
              `dsh-multimodal: image backend "${activeBackendKey}" failed, generated via failover "${item.key}" (${item.backend.model})`,
            )
          }
          break
        } catch (error) {
          // Auth failures and caller aborts are config/user problems, not
          // backend availability problems: failover cannot help, so surface
          // them immediately instead of burning failover quota.
          if (error instanceof LlmError && (error.code === 'AUTH' || error.code === 'ABORTED')) throw error
          lastBackendError = error instanceof Error ? error.message : String(error)
          if (item.backend !== current) {
            ctx.logger.warn(`dsh-multimodal: failover backend "${item.key}" also failed: ${lastBackendError}`)
          }
        }
      }
      if (urls.length === 0 && b64s.length === 0) {
        throw new Error(`all image backends failed (${chain.length} tried): ${lastBackendError}`)
      }

      const images: ImageGenImageValue[] = []
      const failures: string[] = []
      const taskId = String(Math.random()).slice(2, 10)
      for (const item of urls) {
        try {
          const { data, mediaType } = await downloadImageWithRetry(item, exec.signal)
          if (data.byteLength > attachments.imageLimits.maxImageBytes) {
            failures.push(`image exceeds deployment byte limit (${data.byteLength} > ${attachments.imageLimits.maxImageBytes})`)
            continue
          }
          const ref = await attachments.saveImage({ data, mediaType, name: `gen-${taskId.slice(2, 10)}` })
          images.push({
            attachmentId: String(ref.attachmentId),
            mediaType: ref.mediaType as 'image/png' | 'image/jpeg' | 'image/webp',
            bytes: ref.bytes,
            width: ref.width,
            height: ref.height,
            ...(ref.name !== undefined ? { name: ref.name } : {}),
          })
        } catch (error) {
          failures.push(error instanceof Error ? error.message : String(error))
        }
      }
      for (const b64 of b64s) {
        try {
          const data = new Uint8Array(Buffer.from(b64, 'base64'))
          if (data.byteLength > attachments.imageLimits.maxImageBytes) {
            failures.push(`image exceeds deployment byte limit (${data.byteLength} > ${attachments.imageLimits.maxImageBytes})`)
            continue
          }
          const ref = await attachments.saveImage({ data, mediaType: 'image/png', name: 'gen-b64' })
          images.push({
            attachmentId: String(ref.attachmentId),
            mediaType: 'image/png',
            bytes: ref.bytes,
            width: ref.width,
            height: ref.height,
            ...(ref.name !== undefined ? { name: ref.name } : {}),
          })
        } catch (error) {
          failures.push(error instanceof Error ? error.message : String(error))
        }
      }

      // Chinese-text garbling check: warn (or record) without burning another
      // generation. Verification failures never fail the generation itself.
      const verify = genSettings.verify
      if (
        verify?.enabled === true &&
        verify.provider.length > 0 &&
        verify.model.length > 0 &&
        images.length > 0 &&
        /[\u4e00-\u9fff]/.test(effective) &&
        !failures.some((f) => f.includes('乱码'))
      ) {
        try {
          const garbled = await verifyChineseText(ctx, images, verify, exec.signal)
          if (garbled) {
            failures.push('检测到图片中的中文文字可能损坏(乱码/缺字),建议回复「重新生成」')
          }
        } catch {
          // verification is best-effort
        }
      }

      const value = {
        prompt: effective,
        model: usedBackend.model,
        images,
        ...(failures.length > 0 ? { failures } : {}),
      }

      // Remember this generation so a later `refine` call can build on it.
      if (images.length > 0) {
        rememberGen(sessionKey, { prompt: effective, size, model: usedBackend.model, at: Date.now() })
      }

      // The generated image is already visible through the tool-result card:
      // `output.render` carries the image blocks, and the client's
      // `tool.call.toolview` card renders them as thumbnails with a lightbox.
      // No extra user-message injection — injecting the same image as a user
      // message would (a) display it twice in the conversation and (b) insert
      // an out-of-order user turn into the wire history mid tool loop.

      return value
    },
    presentCall(args) {
      const shown = (args.prompt ?? args.refine ?? '').trim()
      return {
        card: 'generic',
        title: '生成图片',
        kind: 'other',
        content: [
          { type: 'text', text: shown.length > 60 ? `${shown.slice(0, 60)}…` : shown },
        ],
      }
    },
  }))
}

interface ImageGenImageValue {
  attachmentId: string
  mediaType: 'image/png' | 'image/jpeg' | 'image/webp'
  bytes: number
  width: number
  height: number
  name?: string
}

export type { ImageGenImageValue }
