/**
 * Wire serialization and SSE translation for OpenAI-compatible chat
 * completions endpoints (DeepSeek public API and Zhipu GLM).
 *
 * Image blocks become inline base64 `image_url` parts; the DeepSeek route
 * skips them instead (vision content is transcribed to text before that
 * route is ever asked, so any image seen here is history replay residue).
 */
import type {
  ContentBlock,
  GenerateOptions,
  StreamChunk,
  TokenUsage,
} from '@deepseek-ai/dsh-llm'
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment'
import { CallId, LlmError } from '@deepseek-ai/dsh-llm'

/** Read the durable bytes behind one image reference. */
export type ReadImage = (
  ref: ImageAttachmentRef,
  signal?: AbortSignal,
) => Promise<Uint8Array>

export type ImageMode = 'data-url' | 'skip'

export interface ReasoningWire {
  /** DeepSeek wire pair: `thinking` + `reasoning_effort`. */
  deepseek?: { thinking: 'enabled' | 'disabled'; effort?: 'high' | 'max' }
  /** GLM wire switch: `thinking: { type: 'enabled' }`. */
  glmEnabled?: boolean
}

export function hasImage(blocks: readonly ContentBlock[]): boolean {
  return blocks.some((block) => block.type === 'image')
}

export function countImages(blocks: readonly ContentBlock[]): number {
  return blocks.reduce((n, b) => n + (b.type === 'image' ? 1 : 0), 0)
}

async function imageToDataUrl(
  block: Extract<ContentBlock, { type: 'image' }>,
  readImage: ReadImage,
  signal?: AbortSignal,
): Promise<string> {
  const bytes = await readImage(block.attachment, signal)
  return `data:${block.attachment.mediaType};base64,${Buffer.from(bytes).toString('base64')}`
}

function flattenText(blocks: readonly ContentBlock[]): string {
  return blocks
    .filter((block) => block.type === 'text')
    .map((block) => (block as { text: string }).text)
    .join('')
}

interface WireMessage {
  role: string
  content: unknown
  [key: string]: unknown
}

/** Serialize one user-role message; images inline as data URLs (or skipped). */
async function serializeUserMessage(
  blocks: readonly ContentBlock[],
  mode: ImageMode,
  readImage: ReadImage,
  signal?: AbortSignal,
): Promise<WireMessage | null> {
  const toolResults = blocks.filter((b) => b.type === 'tool-result') as Extract<
    ContentBlock,
    { type: 'tool-result' }
  >[]
  const hasImages = mode === 'data-url' && hasImage(blocks)

  if (hasImages) {
    const parts: unknown[] = []
    for (const block of blocks) {
      if (block.type === 'text') {
        if (block.text.length > 0) parts.push({ type: 'text', text: block.text })
      } else if (block.type === 'image') {
        parts.push({
          type: 'image_url',
          image_url: { url: await imageToDataUrl(block, readImage, signal) },
        })
      }
    }
    if (parts.length === 0) return null
    return { role: 'user', content: parts }
  }

  const text = flattenText(blocks)
  if (text.length > 0 || toolResults.length === 0) {
    return { role: 'user', content: text }
  }
  return null
}

/** Serialize one assistant-role message (text, reasoning, tool calls). */
function serializeAssistantMessage(blocks: readonly ContentBlock[]): WireMessage {
  const text = flattenText(blocks)
  const reasoning = blocks
    .filter((b) => b.type === 'reasoning')
    .map((b) => (b as { text: string }).text)
    .join('')
  const toolCalls = blocks
    .filter((b) => b.type === 'tool-call')
    .map((b) => {
      const call = b as {
        id: string
        name: string
        arguments: string
      }
      return {
        id: call.id,
        type: 'function',
        function: { name: call.name, arguments: call.arguments },
      }
    })
  const wire: WireMessage = { role: 'assistant', content: text }
  if (reasoning.length > 0) wire.reasoning_content = reasoning
  if (toolCalls.length > 0) wire.tool_calls = toolCalls
  return wire
}

/** Serialize the harness conversation into OpenAI-compatible wire messages. */
export async function serializeMessages(
  messages: readonly GenerateOptions['messages'][number][],
  mode: ImageMode,
  readImage: ReadImage,
  signal?: AbortSignal,
): Promise<WireMessage[]> {
  const wire: WireMessage[] = []
  for (const message of messages) {
    if (message.role === 'system') {
      wire.push({ role: 'system', content: flattenText(message.content) })
      continue
    }
    if (message.role === 'assistant') {
      wire.push(serializeAssistantMessage(message.content))
      continue
    }
    const user = await serializeUserMessage(message.content, mode, readImage, signal)
    if (user !== null) wire.push(user)
    for (const result of message.content.filter((b) => b.type === 'tool-result')) {
      const r = result as { toolCallId: string; content: readonly ContentBlock[] }
      wire.push({
        role: 'tool',
        tool_call_id: r.toolCallId,
        content: flattenText(r.content) || '(no output)',
      })
    }
  }
  return wire
}

/** Resolve the reasoning wire fields for one route family. */
export function resolveReasoning(
  options: GenerateOptions,
  family: 'deepseek' | 'glm',
): ReasoningWire {
  if (options.purpose === 'session-title') return {}
  const effort = options.reasoningEffort
  const deepseekEffort: 'high' | 'max' | undefined =
    effort === 'high' ? 'high' : effort === 'max' ? 'max' : undefined
  if (family === 'deepseek') {
    if (effort === 'off') return { deepseek: { thinking: 'disabled' } }
    if (deepseekEffort !== undefined) {
      return { deepseek: { thinking: 'enabled', effort: deepseekEffort } }
    }
    return {}
  }
  // GLM: high/max enable its thinking switch; off/absent leave provider default.
  if (deepseekEffort !== undefined) return { glmEnabled: true }
  return {}
}

/** Build the full wire request body. Always streaming with usage on. */
export async function serializeRequest(
  options: GenerateOptions,
  opts: {
    imageMode: ImageMode
    reasoning: ReasoningWire
    readImage: ReadImage
  },
  signal?: AbortSignal,
): Promise<Record<string, unknown>> {
  const messages: WireMessage[] = []
  if (options.system !== undefined) {
    messages.push({ role: 'system', content: options.system })
  }
  messages.push(...(await serializeMessages(options.messages, opts.imageMode, opts.readImage, signal)))

  const tools = options.tools?.map((tool) => ({
    type: 'function',
    function: {
      name: tool.name,
      description: tool.description,
      parameters: tool.parameters,
    },
  }))

  const body: Record<string, unknown> = {
    model: options.model,
    messages,
    stream: true,
    stream_options: { include_usage: true },
  }
  if (opts.reasoning.deepseek !== undefined) {
    body.thinking = { type: opts.reasoning.deepseek.thinking }
    if (opts.reasoning.deepseek.effort !== undefined) {
      body.reasoning_effort = opts.reasoning.deepseek.effort
    }
  } else if (opts.reasoning.glmEnabled === true) {
    body.thinking = { type: 'enabled' }
  }
  if (tools !== undefined && tools.length > 0) body.tools = tools
  if (options.temperature !== undefined) body.temperature = options.temperature
  if (options.maxTokens !== undefined) body.max_tokens = options.maxTokens
  if (options.stop !== undefined && options.stop.length > 0) body.stop = options.stop
  return body
}

function mapFinishReason(
  reason: string,
): Extract<StreamChunk, { type: 'finish' }>['reason'] {
  switch (reason) {
    case 'stop':
      return { kind: 'stop' }
    case 'length':
    case 'max_tokens':
      return { kind: 'max-tokens' }
    case 'tool_calls':
      return { kind: 'tool-calls' }
    case 'content_filter':
      return {
        kind: 'error',
        failure: { message: 'content filter', code: 'CONTENT_FILTER' },
      }
    default:
      return { kind: 'stop' }
  }
}

function mapUsage(usage: Record<string, unknown>): TokenUsage {
  const details = usage.prompt_tokens_details as Record<string, unknown> | undefined
  const completion = usage.completion_tokens_details as Record<string, unknown> | undefined
  const cacheRead =
    typeof details?.cached_tokens === 'number'
      ? details.cached_tokens
      : undefined
  const reasoning =
    typeof completion?.reasoning_tokens === 'number'
      ? completion.reasoning_tokens
      : undefined
  return {
    inputTokens: Math.max(0, Number(usage.prompt_tokens ?? 0) - (cacheRead ?? 0)),
    outputTokens: Number(usage.completion_tokens ?? 0),
    ...(cacheRead !== undefined ? { cacheReadTokens: cacheRead } : {}),
    ...(reasoning !== undefined ? { reasoningTokens: reasoning } : {}),
  }
}

interface OpenBlock {
  index: number
  kind: 'text' | 'reasoning' | 'tool-call'
  text: string
  callId?: string
  name?: string
}

function closeBlock(block: OpenBlock): ContentBlock {
  switch (block.kind) {
    case 'text':
      return { type: 'text', text: block.text }
    case 'reasoning':
      return { type: 'reasoning', text: block.text }
    case 'tool-call':
      return {
        type: 'tool-call',
        id: CallId(block.callId ?? ''),
        name: block.name ?? '',
        arguments: block.text,
      }
  }
}

/**
 * Consume SSE data payloads (`[DONE]`-terminated) and yield StreamChunks.
 * Block-ends, usage, and finish are deferred until the sentinel, so usage
 * always precedes the terminal finish.
 */
export async function* translate(
  payloads: AsyncIterable<string>,
): AsyncIterable<StreamChunk> {
  let nextIndex = 0
  let textBlock: OpenBlock | undefined
  let reasoningBlock: OpenBlock | undefined
  const toolBlocks = new Map<number, OpenBlock>()
  const order: OpenBlock[] = []
  let pendingFinish: Extract<StreamChunk, { type: 'finish' }>['reason'] | undefined
  let pendingUsage: TokenUsage | undefined

  function open(kind: OpenBlock['kind']): OpenBlock {
    const block: OpenBlock = { index: nextIndex++, kind, text: '' }
    order.push(block)
    return block
  }

  for await (const payload of payloads) {
    if (payload === '[DONE]') {
      for (const block of order) {
        yield { type: 'block-end', index: block.index, block: closeBlock(block) }
      }
      if (pendingUsage !== undefined) yield { type: 'usage', usage: pendingUsage }
      const reason = pendingFinish ?? { kind: 'stop' }
      yield {
        type: 'finish',
        reason:
          reason.kind === 'stop' && order.length === 0
            ? {
                kind: 'error',
                failure: {
                  message: 'model returned a completed response with no content',
                  code: 'EMPTY_RESPONSE',
                },
              }
            : reason,
      }
      return
    }
    let chunk: Record<string, unknown>
    try {
      chunk = JSON.parse(payload)
    } catch {
      throw new LlmError(
        `malformed SSE payload: ${payload.slice(0, 120)}`,
        'MALFORMED_RESPONSE',
      )
    }
    for (const choice of (chunk.choices ?? []) as Record<string, unknown>[]) {
      const delta = (choice.delta ?? {}) as Record<string, unknown>
      const reasoning = delta.reasoning_content
      if (typeof reasoning === 'string' && reasoning.length > 0) {
        if (reasoningBlock === undefined) {
          reasoningBlock = open('reasoning')
          yield { type: 'block-start', index: reasoningBlock.index, blockType: 'reasoning' }
        }
        reasoningBlock.text += reasoning
        yield { type: 'reasoning-delta', index: reasoningBlock.index, text: reasoning }
      }
      const content = delta.content
      if (typeof content === 'string' && content.length > 0) {
        if (textBlock === undefined) {
          textBlock = open('text')
          yield { type: 'block-start', index: textBlock.index, blockType: 'text' }
        }
        textBlock.text += content
        yield { type: 'text-delta', index: textBlock.index, text: content }
      }
      for (const call of (delta.tool_calls ?? []) as Record<string, unknown>[]) {
        const callIndex = Number(call.index ?? 0)
        let block = toolBlocks.get(callIndex)
        if (block === undefined) {
          block = open('tool-call')
          toolBlocks.set(callIndex, block)
          yield { type: 'block-start', index: block.index, blockType: 'tool-call' }
        }
        if (call.id !== undefined) block.callId = String(call.id)
        const fn = (call.function ?? {}) as Record<string, unknown>
        if (fn.name !== undefined) block.name = String(fn.name)
        const fragment = fn.arguments !== undefined ? String(fn.arguments) : ''
        block.text += fragment
        yield {
          type: 'tool-call-delta',
          index: block.index,
          id: CallId(block.callId ?? ''),
          ...(block.name !== undefined ? { name: block.name } : {}),
          argumentsDelta: fragment,
        }
      }
      if (typeof choice.finish_reason === 'string') {
        pendingFinish = mapFinishReason(choice.finish_reason)
      }
    }
    if (chunk.usage !== undefined && chunk.usage !== null) {
      pendingUsage = mapUsage(chunk.usage as Record<string, unknown>)
    }
  }
  throw new LlmError('SSE payload stream ended without [DONE]', 'STREAM_CLOSED')
}
