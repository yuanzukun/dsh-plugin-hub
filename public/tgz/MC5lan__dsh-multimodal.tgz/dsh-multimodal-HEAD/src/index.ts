/**
 * dsh-multimodal — multimodal eyes and hands for DeepSeek Harness.
 *
 * - `deepseek-vision`: same DeepSeek API, models advertised with image
 *   modality so the host allows attachments; images never reach DeepSeek.
 * - `extraProviders`: any OpenAI-compatible vision endpoint the user declares
 *   (Xfyun MaaS, ModelScope, SiliconFlow, ...) — dynamically registered.
 * - The eye: `agent/pre-step` transcribes image-carrying inputs through the
 *   configured vision provider, then DeepSeek keeps processing the problem.
 * - `generate_image`: text-to-image through a configurable backend
 *   (DashScope async protocol, or OpenAI-compatible /images/generations).
 */
import type { Context } from '@deepseek-ai/cordis'
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment'
import { LlmError, type LlmConfigurableProvider } from '@deepseek-ai/dsh-llm'
import { installSettingsSection, settingsNamespace } from '@deepseek-ai/dsh-settings'
import z from '@deepseek-ai/schemastery'
import { OpenAICompatibleAdapter } from './adapter.js'
import { registerImageGenTool, type ImageBackendSettings } from './image-gen.js'
import { registerOcrTool } from './ocr.js'
import { DEFAULT_TRANSCRIBE_PROMPT, installVision } from './vision.js'

export const name = 'dsh-multimodal'
export const inject = ['llm', 'tools']

export const NS = settingsNamespace('dsh-multimodal')
export const DEEPSEEK_PROVIDER = 'deepseek-vision'

const DEFAULT_DEEPSEEK_BASE_URL = 'https://api.deepseek.com'

export interface ExtraProviderConfig {
  displayName: string
  baseURL: string
  apiKeyEnv: string
  reasoning: 'deepseek' | 'glm'
  models: Array<{
    id: string
    name?: string
    description?: string
    contextWindow?: number
  }>
}

/** A user-declared vision model on one of the built-in route slots. */
export interface VisionModelConfig {
  id: string
  name?: string
  description?: string
  contextWindow?: number
  maxTokens?: number
}

export interface ImageBackendConfig {
  kind: 'dashscope' | 'dashscope-v2' | 'openai-images' | 'custom'
  baseURL: string
  apiKeyEnv: string
  model: string
  defaultSize: string
  /** Custom adapter file (.mjs) for kind: 'custom' (feature 2026-08-16). */
  adapterFile?: string
  /** Polling tuning for async-task backends (default 2000ms / 120000ms). */
  pollIntervalMs?: number
  pollTimeoutMs?: number
}

export interface Config {
  providers: {
    deepseek: { baseURL: string; apiKeyEnv: string; models: VisionModelConfig[] }
    glm: { baseURL: string; apiKeyEnv: string; model: string; models: VisionModelConfig[] }
    dashscope: { baseURL: string; apiKeyEnv: string }
  }
  extraProviders: Record<string, ExtraProviderConfig>
  /** Audit fix (2026-08-15): only these env/credential names may be read as an API key. */
  allowedApiKeyEnvs: string[]
  /** Audit fix (2026-08-15): extra hosts (besides known official ones) allowed to receive credentials. */
  trustedBaseUrls: string[]
  vision: {
    /** Provider route whose sessions get the eye (blank-slate: point it at any provider you configure). */
    watchProvider: string
    transcribeProvider: string
    transcribeModel?: string
    /** Fallback vision providers tried in order when the primary fails. */
    fallbackProviders?: string[]
    /** 'auto' (route by image type) or a fixed verbatim/structured/ocr/describe/scene mode. */
    transcribeMode?:
      | 'auto'
      | 'verbatim'
      | 'structured'
      | 'ocr'
      | 'describe'
      | 'error-fix'
      | 'chart-sql'
      | 'design-code'
    /** Custom mode name → prompt pairs (transcriber plugin-in, feature 2026-08-16). */
    customModes?: Record<string, string>
    /** Transcribe each image in its own parallel call (feature 2026-08-16). */
    parallelImages?: boolean
    /** Cheap provider for small images (cost routing). */
    costProvider?: string
    costModel?: string
    costMaxPixels?: number
    /** Append a scene hint to screenshots. */
    sceneHints?: boolean
    /** Mask phone/id/email in transcription output. */
    redactSensitive?: boolean
    /** Log an audit line per transcription. */
    auditLog?: boolean
    transcribePrompt: string
    transcribeTimeoutMs: number
  }
  ocr: {
    provider: string
    model: string
  }
  image: {
    backends: Record<string, ImageBackendConfig>
    activeBackend: string
    /** Backend keys tried in order when the active backend request fails (feature 2026-08-16). */
    failoverOrder: string[]
    /** Verify Chinese text in generated images via a vision model (feature 2026-08-16). */
    verifyChineseText: boolean
    verifyProvider: string
    verifyModel: string
  }
  streamIdleTimeoutMs: number
}

const visionModelSchema = z.object({
  id: z.string(),
  name: z.string().default(''),
  description: z.string().default(''),
  contextWindow: z.number().default(128_000),
  // No default: 0 would be treated as a real (invalid) value by adapters that
  // gate on `!== undefined` and by dsh-llm's catalog validation (needs >0).
  // Without a default, schemastery leaves it undefined when absent.
  maxTokens: z.number(),
})

const extraProviderSchema = z.object({
  displayName: z.string().default(''),
  baseURL: z.string(),
  apiKeyEnv: z.string(),
  reasoning: z.union([z.const('deepseek'), z.const('glm')]).default('glm'),
  models: z
    .array(
      z.object({
        id: z.string(),
        name: z.string().default(''),
        description: z.string().default(''),
        contextWindow: z.number().default(128_000),
      }),
    )
    .default([]),
})

const imageBackendSchema = z.object({
  kind: z.union([z.const('dashscope'), z.const('dashscope-v2'), z.const('openai-images'), z.const('custom')]),
  baseURL: z.string(),
  apiKeyEnv: z.string(),
  model: z.string(),
  defaultSize: z.string().default('1024*1024'),
  adapterFile: z.string().default(''),
  pollIntervalMs: z.number().default(2_000),
  pollTimeoutMs: z.number().default(120_000),
})

export const Config: z<Config> = z.object({
  providers: z.object({
    deepseek: z.object({
      baseURL: z.string().default(DEFAULT_DEEPSEEK_BASE_URL),
      apiKeyEnv: z.string().default('DEEPSEEK_API_KEY'),
      models: z.array(visionModelSchema).default([]),
    }),
  }),
  extraProviders: z.dict(extraProviderSchema).default({}),
  // Audit fix (2026-08-15): only environment variables in this allow-list may
  // be read as an API key and sent to a provider. This blocks an attacker who
  // supplies a malicious config (e.g. apiKeyEnv: "GITHUB_TOKEN" + an evil
  // baseURL) from exfiltrating arbitrary process environment secrets.
  allowedApiKeyEnvs: z.array(z.string()).default([
    'DEEPSEEK_API_KEY',
  ]),
  // Audit fix (2026-08-15): extra (user-added) providers must target a
  // trusted base URL. Known official hosts are allowed automatically; any
  // other https host must be listed here explicitly, so a malicious config
  // cannot silently redirect credentials to an attacker endpoint.
  trustedBaseUrls: z.array(z.string()).default([]),
  vision: z.object({
    watchProvider: z.string().default(DEEPSEEK_PROVIDER),
    transcribeProvider: z.string().default(''),
    transcribeModel: z.string().default(''),
    fallbackProviders: z.array(z.string()).default([]),
    transcribeMode: z
      .union([
        z.const('auto'),
        z.const('verbatim'),
        z.const('structured'),
        z.const('ocr'),
        z.const('describe'),
        z.const('error-fix'),
        z.const('chart-sql'),
        z.const('design-code'),
      ])
      .default('auto'),
    customModes: z.dict(z.string()).default({}),
    parallelImages: z.boolean().default(false),
    costProvider: z.string().default(''),
    costModel: z.string().default(''),
    costMaxPixels: z.number().default(1_000_000),
    sceneHints: z.boolean().default(true),
    redactSensitive: z.boolean().default(false),
    auditLog: z.boolean().default(false),
    transcribePrompt: z.string().default(DEFAULT_TRANSCRIBE_PROMPT),
    transcribeTimeoutMs: z.number().default(90_000),
  }),
  ocr: z.object({
    provider: z.string().default(''),
    model: z.string().default(''),
  }),
  image: z.object({
    // Blank-slate (v0.3.2): no backends preloaded — users declare their own.
    backends: z.dict(imageBackendSchema).default({}),
    activeBackend: z.string().default(''),
    failoverOrder: z.array(z.string()).default([]),
    verifyChineseText: z.boolean().default(false),
    verifyProvider: z.string().default(''),
    verifyModel: z.string().default(''),
  }),
  streamIdleTimeoutMs: z.number().default(300_000),
}) as unknown as z<Config>

/**
 * Official vision API hosts that extra providers are allowed to target by
 * default. Anything else must be explicitly added to `trustedBaseUrls`.
 */
const KNOWN_VISION_HOSTS = [
  'api.deepseek.com',
  'open.bigmodel.cn',
  'dashscope.aliyuncs.com',
]

/** Whether an extra-provider baseURL may receive credentials. */
export function isAllowedExtraBaseUrl(baseURL: string, trusted: string[]): boolean {
  let parsed: URL
  try {
    parsed = new URL(baseURL)
  } catch {
    return false
  }
  const host = parsed.hostname.toLowerCase()
  if (host === '') return false
  // Explicitly trusted local endpoints (e.g. a local Ollama vision model) are
  // allowed over plain http — the user listed them, so this is an informed
  // choice; remote endpoints must still be https.
  const isLocal = host === 'localhost' || host === '127.0.0.1' || host === '[::1]'
  if (isLocal) {
    return trusted.some((t) => {
      try {
        return new URL(t).hostname.toLowerCase() === host
      } catch {
        return false
      }
    })
  }
  if (parsed.protocol !== 'https:') return false
  if (KNOWN_VISION_HOSTS.includes(host)) return true
  if (trusted.includes(baseURL)) return true
  return trusted.some((t) => {
    try {
      return new URL(t).hostname.toLowerCase() === host
    } catch {
      return false
    }
  })
}

/**
 * Lightweight structural validation of the runtime config. The schemastery
 * defaults catch most issues at write time; this guards the fields that a
 * malicious settings payload could otherwise bend.
 */
export function validateConfig(raw: Config): void {
  if (raw === undefined || raw === null) return
  const providers = raw.providers
  if (providers !== undefined) {
    for (const name of ['deepseek', 'glm', 'dashscope'] as const) {
      const p = providers[name]
      if (p !== undefined && p.baseURL !== undefined) {
        let u: URL
        try {
          u = new URL(p.baseURL)
        } catch {
          throw new Error(`dsh-multimodal: providers.${name}.baseURL is not a valid URL: ${p.baseURL}`)
        }
        if (u.protocol !== 'https:' && u.protocol !== 'http:') {
          throw new Error(`dsh-multimodal: providers.${name}.baseURL must be http(s): ${p.baseURL}`)
        }
      }
    }
  }
  const extra = raw.extraProviders
  if (extra !== undefined) {
    for (const [key, spec] of Object.entries(extra)) {
      if (!/^[A-Za-z0-9_.-]+$/.test(key)) {
        throw new Error(`dsh-multimodal: extraProviders key "${key}" contains invalid characters`)
      }
      if (spec?.baseURL !== undefined) {
        let u: URL
        try {
          u = new URL(spec.baseURL)
        } catch {
          throw new Error(`dsh-multimodal: extraProviders.${key}.baseURL is not a valid URL: ${spec.baseURL}`)
        }
        // Local endpoints (localhost / loopback) may use plain http — the
        // local-Ollama preset depends on it. Anything else must be https.
        const host = u.hostname.toLowerCase()
        const isLocal = host === 'localhost' || host === '127.0.0.1' || host === '[::1]'
        if (u.protocol !== 'https:' && !isLocal) {
          throw new Error(`dsh-multimodal: extraProviders.${key}.baseURL must be https: ${spec.baseURL}`)
        }
      }
    }
  }
  // Custom image backends must declare an adapter file.
  const backends = raw.image?.backends
  if (backends !== undefined) {
    for (const [key, b] of Object.entries(backends)) {
      if (b?.kind === 'custom' && (b.adapterFile === undefined || b.adapterFile.length === 0)) {
        throw new Error(`dsh-multimodal: image backend "${key}" is kind "custom" but has no adapterFile`)
      }
    }
  }
}

/** Empty by design (v0.3.1): the plugin is a blank slate — models are declared
 * by the user through `providers.*.models` or `extraProviders`, not baked in. */

export function apply(ctx: Context, config: Config): void {
  let current = () => config
  let lastRaw: Config | undefined
  let lastGood: Config | undefined
  const options = (): Config => {
    const raw = current()
    if (raw === lastRaw && lastGood !== undefined) return lastGood
    try {
      validateConfig(raw)
      lastRaw = raw
      lastGood = raw
      return lastGood
    } catch (error) {
      if (lastGood === undefined) throw error
      ctx.logger.error('dsh-multimodal: keeping the last good configuration after an invalid settings section')
      ctx.logger.error(error)
      return lastGood
    }
  }
  options()

  const resolveKey = async (ref: string, route: string): Promise<string> => {
    // Audit fix (2026-08-15): never resolve an arbitrary env/credential name
    // as an API key unless it is explicitly on the allow-list. This blocks a
    // malicious config from exfiltrating unrelated secrets (e.g. GITHUB_TOKEN)
    // by naming them as apiKeyEnv.
    // Local endpoints (e.g. a trusted local Ollama) need no key at all.
    const routeSpec = options().extraProviders[route]
    const isLocalRoute =
      routeSpec !== undefined && /localhost|127\.0\.0\.1|\[::1\]/i.test(routeSpec.baseURL)
    if (isLocalRoute) return ''
    const allowed = options().allowedApiKeyEnvs ?? []
    if (!allowed.includes(ref)) {
      throw new LlmError(
        `dsh-multimodal: refused to use "${ref}" as an API key — it is not in the allowed list (dsh-multimodal.allowedApiKeyEnvs). Add it explicitly if you trust this provider.`,
        'MISSING_CREDENTIAL',
      )
    }
    const credentials = ctx.get('credentials')
    if (credentials !== undefined) {
      const hit = await credentials.resolve(ref)
      if (hit !== undefined && hit.value.length > 0) return hit.value
    } else {
      const ambient = process.env[ref]
      if (ambient !== undefined && ambient.length > 0) return ambient
    }
    throw new LlmError(
      `dsh-multimodal: no API key for provider route "${route}"; store ${ref} through the credentials service (the web Models page writes it), or export ${ref} in the launching environment`,
      'MISSING_CREDENTIAL',
    )
  }

  const readImage = async (
    ref: ImageAttachmentRef,
    signal?: AbortSignal,
  ): Promise<Uint8Array> => {
    const attachments = ctx.get('attachments')
    if (attachments === undefined) {
      throw new LlmError(
        'dsh-multimodal: attachment service unavailable; cannot read image bytes',
        'TRANSPORT',
      )
    }
    const stored = await attachments.readImage(ref, signal)
    return stored.data
  }

  const userId = () => 'dsh-multimodal'

  // Fixed routes (blank-slate: model lists come from user config). The
  // DeepSeek adapter is REBUILT on every settings change (like extras below):
  // an apply-time snapshot would freeze an empty models list and the model
  // picker would silently drop the whole deepseek-vision group.
  const baseEntries: LlmConfigurableProvider[] = [
    {
      provider: DEEPSEEK_PROVIDER,
      displayName: 'DeepSeek (Vision)',
      settingsNs: NS,
      settingsPath: ['providers', 'deepseek'],
      declared: true,
    },
  ]
  const directory = ctx.llm.registerConfigurableProviders([...baseEntries])
  const adapterRegistrations: Array<() => void> = []
  const disposeAdapters = (): void => {
    for (const dispose of adapterRegistrations) {
      try {
        dispose()
      } catch {
        // already released
      }
    }
    adapterRegistrations.length = 0
  }
  const registerDeepseekAdapter = (): void => {
    const adapter = new OpenAICompatibleAdapter(
      {
        provider: DEEPSEEK_PROVIDER,
        displayName: 'DeepSeek (Vision)',
        baseURL: options().providers.deepseek.baseURL,
        apiKeyEnv: options().providers.deepseek.apiKeyEnv,
        reasoning: 'deepseek',
        imageMode: 'skip',
        streamIdleTimeoutMs: options().streamIdleTimeoutMs,
        models: options().providers.deepseek.models,
        readImage,
      },
      (ref) => resolveKey(ref, DEEPSEEK_PROVIDER),
      userId,
    )
    const reg = ctx.llm.registerAdapter([DEEPSEEK_PROVIDER], adapter)
    adapterRegistrations.push(() => {
      try {
        reg()
      } catch {
        // already released
      }
    })
  }

  // Extra OpenAI-compatible vision providers (dynamic).
  const rewireExtras = (): void => {
    disposeAdapters()
    registerDeepseekAdapter()
    const entries = [...baseEntries]
    const trusted = options().trustedBaseUrls ?? []
    for (const [key, spec] of Object.entries(options().extraProviders)) {
      // Audit fix (2026-08-15): refuse to register an extra provider whose
      // baseURL is not trusted, so a malicious config cannot redirect the
      // allow-listed API key to an attacker endpoint.
      if (!isAllowedExtraBaseUrl(spec.baseURL, trusted)) {
        ctx.logger.warn(
          `dsh-multimodal: skipping extra provider "${key}" — baseURL "${spec.baseURL}" is not trusted (known hosts or dsh-multimodal.trustedBaseUrls). Refusing to send credentials there.`,
        )
        continue
      }
      const provider = key
      const extraAdapter = new OpenAICompatibleAdapter(
        {
          provider,
          displayName: spec.displayName || key,
          baseURL: spec.baseURL,
          apiKeyEnv: spec.apiKeyEnv,
          reasoning: spec.reasoning,
          imageMode: 'data-url',
          streamIdleTimeoutMs: options().streamIdleTimeoutMs,
          models: spec.models.map((m) => ({
            id: m.id,
            ...(m.name !== '' ? { name: m.name } : {}),
            ...(m.description !== '' ? { description: m.description } : {}),
            ...(m.contextWindow !== undefined ? { contextWindow: m.contextWindow } : {}),
          })),
          readImage,
        },
        (ref) => resolveKey(ref, provider),
        userId,
      )
      const reg = ctx.llm.registerAdapter([provider], extraAdapter)
      adapterRegistrations.push(() => {
        try {
          reg()
        } catch {
          // already released
        }
      })
      entries.push({
        provider,
        displayName: spec.displayName || key,
        settingsNs: NS,
        settingsPath: ['extraProviders', key],
        declared: true,
      })
    }
    directory.replace(entries)
  }
  rewireExtras()

  installSettingsSection(ctx, NS, Config, config, {
    setSource: (source) => {
      current = source
    },
    onChange: () => {
      rewireExtras()
    },
  })

  // Model discovery (v0.5): the settings UI asks a draft endpoint "what models
  // do you serve?" before the provider is stored. OpenAI-compatible /models is
  // the common wire format; the key travels one-shot and is never stored.
  ctx.llm.registerModelDiscovery(NS, async (request) => {
    const baseURL = (request.baseURL ?? '').replace(/\/+$/, '')
    if (baseURL.length === 0) return []
    const url = `${baseURL}/models`
    const headers: Record<string, string> = { accept: 'application/json' }
    if (request.apiKey !== undefined && request.apiKey.length > 0) {
      headers.authorization = `Bearer ${request.apiKey}`
    }
    const res = await fetch(url, {
      headers,
      signal: request.signal,
      redirect: 'error',
    })
    if (!res.ok) {
      throw new LlmError(`model discovery failed: ${res.status} ${res.statusText}`, 'DISCOVERY_FAILED')
    }
    const body = (await res.json()) as { data?: Array<{ id?: unknown; object?: unknown }> }
    const raw = Array.isArray(body.data) ? body.data : []
    const models: Array<{ id: string; name?: string; contextWindow?: number; maxTokens?: number }> = []
    for (const item of raw) {
      if (typeof item?.id !== 'string' || item.id.length === 0) continue
      const entry: { id: string } = { id: item.id }
      const rec = item as Record<string, unknown>
      if (typeof rec.name === 'string' && rec.name.length > 0) {
        ;(entry as { name?: string }).name = rec.name
      }
      models.push(entry)
    }
    return models
  })

  // The eye: configurable transcription engine.
  installVision(ctx, () => {
    const v = options().vision
    return {
      watchProvider: v.watchProvider,
      transcribeProvider: v.transcribeProvider,
      transcribeModel:
        v.transcribeModel !== undefined && v.transcribeModel.length > 0
          ? v.transcribeModel
          : undefined,
      fallbackProviders: v.fallbackProviders ?? [],
      transcribeMode: v.transcribeMode ?? 'auto',
      customModes: v.customModes ?? {},
      parallelImages: v.parallelImages === true,
      costProvider: v.costProvider ?? '',
      costModel: v.costModel ?? '',
      costMaxPixels: v.costMaxPixels ?? 1_000_000,
      sceneHints: v.sceneHints !== false,
      redactSensitive: v.redactSensitive === true,
      auditLog: v.auditLog === true,
      transcribePrompt: v.transcribePrompt,
      transcribeTimeoutMs: v.transcribeTimeoutMs,
    }
  })

  // Explicit OCR tool (extract_text).
  registerOcrTool(
    ctx,
    () => ({
      provider: options().ocr.provider,
      model: options().ocr.model,
      timeoutMs: 120_000,
    }),
    (ref) => resolveKey(ref, `ocr-${options().ocr.provider}`),
  )

  // Text-to-image with configurable backends.
  registerImageGenTool(
    ctx,
    () => {
      const active = options().image.activeBackend
      const backend = options().image.backends[active]
      if (backend === undefined) {
        throw new Error(`dsh-multimodal: image backend "${active}" is not configured`)
      }
      const img = options().image
      const pollDefaults = { pollIntervalMs: 2_000, pollTimeoutMs: 120_000 }
      const poll = (b: ImageBackendConfig) => ({
        ...pollDefaults,
        ...(b.pollIntervalMs !== undefined ? { pollIntervalMs: b.pollIntervalMs } : {}),
        ...(b.pollTimeoutMs !== undefined ? { pollTimeoutMs: b.pollTimeoutMs } : {}),
      })
      const failovers: ImageBackendSettings[] = []
      for (const key of img.failoverOrder ?? []) {
        const b = img.backends[key]
        if (b === undefined) {
          ctx.logger.warn(`dsh-multimodal: image failoverOrder key "${key}" is not a configured backend — skipped`)
          continue
        }
        failovers.push({ ...b, ...poll(b) })
      }
      return {
        backend: { ...backend, ...poll(backend) },
        activeBackendKey: active,
        failovers,
        verify: {
          enabled: img.verifyChineseText,
          provider: img.verifyProvider,
          model: img.verifyModel,
        },
      }
    },
    (ref, route) => resolveKey(ref, route),
  )
}
