#!/usr/bin/env node
/**
 * Vision provider benchmark (feature 2026-08-16, I2).
 *
 * Sends one image to several OpenAI-compatible vision endpoints and reports
 * latency + output length per provider, so you can compare local Ollama
 * models against cloud GLM etc. before wiring them into dsh-multimodal.
 *
 * Usage:
 *   node scripts/benchmark-vision.mjs <image-path> <provider>=<baseURL>,<model>,<envKey> ...
 *
 * Example:
 *   node scripts/benchmark-vision.mjs shot.png \
 *     glm=https://open.bigmodel.cn/api/paas/v4,glm-4v-flash,GLM_VISION_API_KEY \
 *     ollama=http://localhost:11434/v1,llava,SKIP
 *
 * SKIP as envKey means the provider needs no key (local endpoints).
 */
import { readFileSync } from 'node:fs'
import { extname } from 'node:path'

const PROMPT =
  '你是视觉转写引擎,逐字转写图片中的文字(报错、日志、代码、UI 文案),代码用```围栏包裹,多图按【图1】【图2】标注。只转写与提取,不要建议。'

function mediaTypeOf(path) {
  const ext = extname(path).toLowerCase()
  if (ext === '.png') return 'image/png'
  if (ext === '.jpg' || ext === '.jpeg') return 'image/jpeg'
  if (ext === '.webp') return 'image/webp'
  return 'image/png'
}

async function runOne(name, baseURL, model, envKey, dataUrl) {
  const apiKey = envKey === 'SKIP' ? 'local' : process.env[envKey]
  if (envKey !== 'SKIP' && (apiKey === undefined || apiKey.length === 0)) {
    console.log(`  [${name}] SKIP: env ${envKey} not set`)
    return
  }
  const startedAt = Date.now()
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 120_000)
  try {
    const res = await fetch(`${baseURL.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        ...(envKey === 'SKIP' ? {} : { authorization: `Bearer ${apiKey}` }),
      },
      body: JSON.stringify({
        model,
        stream: false,
        messages: [
          {
            role: 'user',
            content: [{ type: 'image_url', image_url: { url: dataUrl } }, { type: 'text', text: PROMPT }],
          },
        ],
      }),
      signal: controller.signal,
    })
    if (!res.ok) {
      const body = await res.text().catch(() => '')
      console.log(`  [${name}] FAIL HTTP ${res.status}: ${body.slice(0, 200)}`)
      return
    }
    const data = await res.json()
    const text = data.choices?.[0]?.message?.content ?? ''
    console.log(`  [${name}] OK ${Date.now() - startedAt}ms, ${text.length} chars`)
    console.log(`    preview: ${text.slice(0, 120).replace(/\n/g, ' ')}`)
  } catch (error) {
    console.log(`  [${name}] ERROR: ${error instanceof Error ? error.message : String(error)}`)
  } finally {
    clearTimeout(timer)
  }
}

const [imagePath, ...providers] = process.argv.slice(2)
if (imagePath === undefined || providers.length === 0) {
  console.log('Usage: node scripts/benchmark-vision.mjs <image> <name=baseURL,model,envKey> ...')
  process.exit(1)
}

const dataUrl = `data:${mediaTypeOf(imagePath)};base64,${readFileSync(imagePath).toString('base64')}`
console.log(`Benchmarking ${imagePath} (${(dataUrl.length / 1024).toFixed(0)} KB base64) across ${providers.length} provider(s):`)

for (const spec of providers) {
  const eq = spec.indexOf('=')
  if (eq === -1) continue
  const name = spec.slice(0, eq)
  const [baseURL, model, envKey] = spec.slice(eq + 1).split(',')
  if (baseURL === undefined || model === undefined) {
    console.log(`  [${name}] SKIP: need baseURL,model[,envKey]`)
    continue
  }
  await runOne(name, baseURL, model, envKey ?? 'SKIP', dataUrl)
}
