# Changelog

All notable changes to this project are documented in this file.

## [0.7.2] - 2026-08-16

交互逻辑修复轮:修掉「配置了但功能不生效」与状态误导的断点。

### Fixed

- **「阿里百炼」卡片现在真的能画图**:`dashscope-image` 预设改为生图后端接入
  (`image.backends.z-image`,dashscope-v2 同步协议 + z-image-turbo),不再错误地
  注册成 OpenAI 兼容聊天端点(此前接入后既不能画图也不能看图)
- **自动接入现在会启用功能**:识别/接入视觉类平台后自动把 `vision.transcribeProvider`
  设为该平台(此前只注册端点,识图实际关闭);生图后端预设接入后自动设为 active
- **状态栏按真实功能条件计算**:识图 = 转写提供商已设置且已注册;画图 = 后端存在且已激活。
  不再"注册过任意平台就显示已配置"
- **`extract_text`(OCR)与眼睛路由解耦**:图片记忆移到 watchProvider 守卫之前,
  OCR 工具不再依赖会话是否在 watch 路由上
- **生图结果不再重复显示**:去掉 `agent.inject` 的图片 user 消息(图片只经工具卡片
  展示),同时消除了 wire 历史里插入乱序 user 回合的问题
- **转写可取消**:`agent/pre-step` 的回合取消信号与转写超时合并,用户点"停止"后
  视觉调用立即中止,不再烧额度直到超时
- **自定义端点/预设接入自动补白名单**:非已知主机的 baseURL 自动写入
  `trustedBaseUrls`(此前讯飞/魔搭/硅基/千帆预设接入后被 host 端静默跳过);
  自定义端点的 Key 自动加入 `allowedApiKeyEnvs`(此前必然被拒)
- **自动识别探测优化**:按可能性排序(siliconflow → modelscope → xfyun → qianfan),
  排除非聊天 API 的端点;失败提示列出已尝试平台
- **OpenAI 兼容后端错误信息不再丢失**:错误解析同时识别 `body.error`(OpenAI 形状)
- **`refine` 无前次生成时显式报错**而非把调整文本当完整 prompt
- **failover 不再浪费配额**:AUTH / 已取消 直接抛出,不尝试备用后端
- **中文乱码校验超时 30s → 15s**,生图卡片等待更短
- 失败卡片「复制重试指令」支持 refine 调用(无 prompt 时);「复制参数」含 refine
- `switchBackend` 失败时回滚下拉选择到实际持久化值

## [0.7.0] - 2026-08-16

Key 自动识别:粘贴任意 API Key,插件自动判断平台并接入。

### Added

- **自动识别输入框** (`dsmm-autoconnect`):快速接入面板顶部"粘贴任意 API Key",
  回车或点「自动识别」即触发
- **识别策略** (`autoConnect`):
  1. Key 指纹匹配(零网络):智谱 `id.secret` 格式、阿里百炼 `sk-ws-` 前缀
     等 → 直接锁定平台
  2. 无指纹 → 遍历所有已知端点逐个调 `/models` 探测(Key 一次性传输、
     不落盘),第一个认证成功的端点即该 Key 所属平台
  3. 全部失败 → 提示失败原因,引导手动点选平台卡片或自定义端点
- **自动接入** (`connectDetected`):识别成功后一步完成 —— 注册端点 +
  白名单 Key 环境变量 + 写入凭据 + 自动发现并预填模型列表
- 预设库新增智谱 GLM(看图+画图)、阿里百炼(画图),带 keyHint 指纹
- `ExtraPreset` 增加可选 `keyHint` 正则字段

### Changed

- 快速接入副标题改为"粘贴 Key 自动识别 · 或选平台手动接入"

## [0.6.0] - 2026-08-16

极简 UI:设置页从"5 个分区平铺"收敛为「一行状态 + 快速接入 + 2 组折叠」。

### Changed

- **一行状态条** (`dsmm-statusbar`):替代 4 张状态总览卡 + 快速开始引导卡
  —— 识图 ✓/✗ · 画图 ✓/✗,全部就绪时显示"发图自动看、说画就画"
- **快速接入主卡** (`dsmm-quickadd`):平台预设卡片网格 + 自定义端点表单
  收进一个折叠面板,默认收起只显示「＋ 选择平台并接入」按钮
- **5 个 Section → 2 个**:
  - 「已接入」:平台列表(模型 chips)+ 后端管理(切换/移除/添加)
  - 「高级」:密钥 KeyCard × 2 + 视觉转写细节(观看路由/转写提供商/
    转写模式/4 开关)+ 导入导出
- 删除死 CSS:`dsmm-overview/statCard/dot/onboard` 系列
- 默认展开「已接入」,其余全折叠 —— 首次进入只看到状态 + 一个按钮

## [0.5.0] - 2026-08-16

傻瓜式交互 (fool-proof):三层引导,配置从"填 7 个技术字段"变为"选平台 → 粘贴 Key"。

### Added

- **平台预设库 (第 1 层)**:平台接入改为卡片式点选
  (`presetGrid` / `presetCard` / `presetConnect`),每张卡片带用途徽标
  (看图/画图/看图+画图),点开即内联粘贴 Key,「接入」一步完成
  (端点 + 白名单 + Key 一次写入);自定义端点表单保留在卡片尾部
- **首次引导向导 (第 3 层)**:未配置识图/生图时,设置页顶部显示
  「快速开始」卡 (`dsmm-onboard`),两步引导(看图 → 选平台 → 填 Key /
  画图 → 添加后端),按钮直达对应分区,配置完自动消失
- **模型自动发现 (第 2 层)**:host 注册 `registerModelDiscovery(NS, ...)`,
  走 OpenAI 兼容 `GET /models`;接入平台粘贴 Key 后自动拉取真实模型
  列表并预填 (Key 一次性传输,harness 不存储);发现失败回退手动添加
- client `MinimalApi` 扩展 `llm.discoverModels` 调用

### Changed

- `addPreset` 支持可选的 `keyValue` 参数:填 Key 则一步完成接入
- 自定义平台表单从「+ 添加平台」按钮改为卡片触发

## [0.4.0] - 2026-08-16

设置页 UI 全面重构:单一 token 体系、扁平层级、消灭内联样式。

### Changed

- **CSS 三套体系合并为单一 token 体系**:删除 v0.2 遗留类
  (rows/rowCard/addCard/editor/platformRow/credentialDot/mask) 及
  重复定义(section/banner/sectionHead 各 2 次 → 1 次)
- **扁平层级**:分区从嵌套边框卡改为分隔线样式;cardRow 改用
  底部边框分隔,去掉框套框的视觉噪音
- **消灭内联样式**:30+ 处 `style={{...}}` 收敛为 class
  (cardMain/selectMode/toggleGroup/sectionNote/listGroup/presetRow/
  cardRowTop/fieldFull/formActions/modelInput/modelAddBtn/keyBody/
  keyField/keyActions/genDownloadLabel/hiddenFile/advancedNote)
- **颜色全走主题变量**:rgba 硬编码替换为 dsw alias 变量 + fallback
  (success-tertiary / success-secondary / error-secondary 等)
- **尺寸统一**:输入框 32px、按钮 32px、圆角 8px、标签徽章 20px、
  kindBadge 22px、modelChip 24px、toggleBtn 28-32px
- **状态总览空状态优化**:"未配置"替代空白;"密钥"卡改为
  "已就绪/待配置"整体状态
- Section 箭头旋转用 class(`dsmm-sectionArrowOpen`)替代内联 transform

## [0.3.5] - 2026-08-16

交互细节修复:provider 输入失焦/回车提交、密钥保存后总览刷新。

### Fixed

- 「观看路由」「转写提供商」输入框从每击键一次 `settings.mutate` 改为
  `CommitInput`(Enter/失焦才提交),不再因 reload 打断输入过程
- KeyCard 保存后触发父级 reload,状态总览密钥红绿点即时刷新

## [0.3.4] - 2026-08-16

密钥管理 KeyCard 视觉精简。

### Changed

- 去掉右侧冗余的 "••••••••" 掩码 span(已配置时与输入框并存导致视觉杂乱)
- 去掉已配置状态下的 "点击输入框可更换 Key" 提示语(多余,input 默认可编辑)
- placeholder 文案调整:已配置时为 "已配置 · 输入新值可覆盖" (与中文标点一致)

## [0.3.3] - 2026-08-16

密钥管理中立化、模型增删管理。

### Changed

- **密钥管理去服务商名**:「GLM 视觉 / 阿里云百炼」改为「视觉转写 Key / 图像生成 Key」,凭据按用途而非厂商命名;状态总览密钥卡同步改「视觉 / 画图」
- **平台模型管理**:每个平台卡片内显示模型 chips(可单独删除,×按钮),支持行内「+ 添加模型」(输入模型 ID 回车/点按钮);不再只能"添加时填一个、之后不能动"
- 移除平台按钮文案区分「移除平台」,避免与删模型混淆

## [0.3.2] - 2026-08-16

UI 与默认值彻底去模型名:插件与界面均不预置任何具体模型。

### Changed

- **UI 去模型名**:后端标签改为协议级描述(DashScope 异步 / DashScope 同步 / OpenAI 兼容);平台预设只填端点(名称/BaseURL/Key 引用),模型 ID 留给用户;添加表单 placeholder 中立化
- **生图后端默认空白**:`image.backends` 默认 `{}`,不再预置任何后端,`activeBackend` 默认空 —— 用户自行添加
- **OCR/校验默认空白**:`ocr.provider/model`、`verifyProvider/verifyModel` 默认空字符串;中文乱字校验仅在配置了提供商与模型时启用
- **平台预设添加后提示**补充模型 ID 与 Key,不再自带模型
- 高保真 UI 视觉重构(本版本内):徽章、首字母图标、掩码密钥、分区分隔线、横幅圆点

## [0.3.1] - 2026-08-16

插件空白化:不再内置任何模型,用户想用什么模型就用什么模型。

### Changed

- **移除内置模型清单**:`deepseek-v4-flash / deepseek-v4-pro / glm-4.6v-flash / glm-4.1v-thinking-flash / glm-4v-flash / glm-ocr` 全部不再预置
- **模型由用户声明**:`providers.deepseek.models` / `providers.glm.models`(内建路由槽位)或 `extraProviders`(任意 OpenAI 兼容端点,默认空)
- **识图路由可指向任意 provider**:新增 `vision.watchProvider`(默认 `deepseek-vision`),把"带眼睛的会话"绑定到用户自己的主模型路由
- **UI 同步**:视觉转写分区新增「观看路由」与「转写提供商」输入框,状态总览识图卡显示"看 provider · 转写 provider · 模式";README 使用说明改为"先声明你的模型"

## [0.3.0] - 2026-08-16

设置页 UI 重构:分区折叠、状态总览、卡片化列表、视觉转写图形化配置。

### Changed (UI redesign)

- **折叠分区结构**:密钥管理 / 视觉转写 / 生图后端 / 平台接入 / 高级 五个可折叠分区,告别单列堆叠的信息过载
- **顶部状态总览**:四张状态卡(识图模型+模式 / 当前生图后端+协议 / 平台接入数 / 密钥配置状态),Key 未配置时红点提示
- **操作消息横幅**:成功绿色 / 失败红色,醒目提示不再是一行小字
- **列表卡片化**:生图后端与平台以卡片行展示(协议徽标 + 当前标记 + 移除按钮),替代朴素行
- **添加表单折叠**:点「+ 添加」展开、再点收起,降低默认信息密度
- **视觉转写分区(新增)**:转写模式下拉(auto/verbatim/structured/ocr/describe/error-fix/chart-sql/design-code)+ 并行转写 / 场景提示 / 脱敏 / 审计 四个开关,即时生效
- 新增 Switch 开关组件、协议徽标、折叠分区等样式

## [0.2.6] - 2026-08-16

生图后端适配器化:任意 API 均可通过适配器文件接入,不再写死三种协议。

### Added

- **自定义生图后端**(`kind: custom` + `adapterFile`):任意非 OpenAI/DashScope 协议的文生图 API,写一个 ES 模块(默认导出带 `generate()` 的对象)即可接入;适配器收到 prompt/size/n/negative_prompt/reference_image/apiKey/baseURL/model/signal/fetch/log,返回 urls[] 或 b64s[];按路径缓存加载,加载失败报错并走 failover 链
- **逐后端轮询参数**(`pollIntervalMs` / `pollTimeoutMs`):异步任务类后端可单独调优
- 示例适配器模板:`scripts/adapters/example-custom.mjs` + README 双语文档(含"只加载信任文件"安全警告)
- `validateConfig` 校验 custom 后端必须声明 `adapterFile`

### Fixed

- dashscope-v2 分支**透传** `n` 与 `negative_prompt`(此前静默忽略 —— 用 z-image 时"生成 2 张"实际只得 1 张)
- 工具参数 `size` 描述覆盖两种上限(普通 1440 / dashscope-v2 2048)
- README z-image 默认尺寸注释与代码统一(1024*1024)

## [0.2.5] - 2026-08-16

第二轮能力:并行转写、成本路由、生图后端 failover、垂直场景包、配置迁移、Benchmark。

### Added

- **多图并行转写**(`vision.parallelImages`):每张图独立并发转写后按序拼接,多图场景大幅提速(并行路径跳过缓存)
- **成本路由**(`vision.costProvider` / `costModel` / `costMaxPixels`):小图(默认 ≤100 万像素)自动走廉价提供商,大图走主提供商
- **截图场景提示**(`vision.sceneHints`,默认开):截图转写后自动附加"请优先给出诊断与修复建议"提示
- **生图后端 failover**(`image.failoverOrder`):主后端请求失败时按顺序尝试备用后端(配置中的其他 backends),全部失败才报错
- **垂直场景包**:`transcribeMode` 新增 `error-fix`(报错截图诊疗)/ `chart-sql`(图表→SQL+Pandas)/ `design-code`(设计稿→HTML+CSS)三个内置场景模式
- **配置导入/导出**:设置页导出全部配置为 JSON、导入时仅接受白名单字段
- **生图参数复现**:生图卡片「复制参数」按钮,一键复制 prompt/size/n/negative_prompt JSON
- **视觉会话记忆**:模块级统计每会话转写过的图片类型频率(截图/文档/照片,LRU 有界)
- **延迟统计**:审计日志增加耗时字段(ms)
- **Benchmark 脚本**(`scripts/benchmark-vision.mjs`):同一张图对比多个视觉提供商(本地 Ollama vs 云端 GLM)的延迟与输出
- **本地模型矩阵文档**:README 新增 Ollama 视觉模型选型表(llava / qwen2.5vl / minicpm-v …)

### Fixed

- 代码审计修复(0.2.4 内,随本版发布):缓存命中绕过脱敏、预设未同步密钥白名单、本地端点免 key、OCR 输出边界标记、reference_image 错误提示
- **终审修复(0.2.5 内)**:并行转写并发上限 3(防限流);`AbortSignal.any` 替换为 Node 18 兼容写法;failover 成功后元信息改用实际后端模型;failover 切换与失败日志;failover 后端 size 上限显式校验;`validateConfig` 放行本地 http 端点(修复本地 Ollama 预设被配置校验拒绝的问题);`failoverOrder` 无效 key 告警

## [0.2.4] - 2026-08-16

P2 能力:图生图/编辑、敏感脱敏与审计、transcriber 插件化、本地视觉优先。

### Added

- **图生图/图像编辑**:`generate_image` 新增 `reference_image` 参数(会话内图片 attachmentId 或 http(s) URL),`dashscope-v2` 后端(Z-Image)按参考图生成;URL 同样过 SSRF 校验;非 dashscope-v2 后端调用时报错提示
- **敏感信息脱敏**(`vision.redactSensitive`,默认关):转写文本自动打码大陆手机号、18 位身份证、邮箱
- **转写审计日志**(`vision.auditLog`,默认关):每次转写记录 时间/图片数/字节数/提供商,经 harness 日志通道输出
- **transcriber 插件化**(`vision.customModes`):自定义转写模式名 → prompt 映射,`transcribeMode` 可引用任意自定义模式
- **本地视觉优先**:`isAllowedExtraBaseUrl` 放行显式加入 `trustedBaseUrls` 的本地端点(http://localhost/127.0.0.1);设置页新增「本地 Ollama」一键预设(自动写入信任域名),配合本地 VLM(llava 等)实现敏感图不出内网
- 单测扩至 25 例(本地端点信任、脱敏规则)

### Notes

- PDF/视频/音频 文件级处理受 DeepSeek Harness 架构限制暂缓:附件系统仅接受图片(png/jpeg/webp/gif)、host 附件准入无插件钩子、附件 rail 无注入槽位。URL 版文档读取工具记录为后续可选方向

## [0.2.3] - 2026-08-16

P1 核心体验:结构化提取、图片类型路由、生图迭代、圈选提问、中文乱字自检、安全单测。

### Added

- **结构化提取模式**(`vision.transcribeMode`):`auto`(按图片类型自动路由,默认)/ `verbatim` / `structured`(报错→JSON)/ `ocr`(纯文字 Markdown)/ `describe`(画面描述)五档;自定义 `transcribePrompt` 始终优先
- **图片类型自动路由**:轻量启发式分类(截图 / 文档 / 照片),`auto` 模式下截图→结构化提取、文档→OCR、照片→画面描述
- **生图迭代上下文**:`generate_image` 新增 `refine` 参数,无需重复完整 prompt 即可微调上次生成("背景调暗一点");会话级状态 LRU 有界
- **圈选提问**:生图卡片新增「圈选提问」— 大图上拖拽选择区域、输入问题,裁剪图通过会话图片通道发送给 DeepSeek(通道不可用时自动降级为下载裁剪图)
- **中文乱字自检**(`image.verifyChineseText`,默认开):含中文的生图生成后用视觉模型检查乱码,检测到在 failures 中提示
- **单元测试(vitest)**:SSRF 防护、API key 白名单、trustedBaseUrls、validateConfig、图片分类 20 个用例全绿;`npm test` 接入 CI

### Changed

- `classifyImage` 启发式区分显示器比例(截图)与相机比例(照片),A4 页(横/竖)判文档
- 视觉转写缓存 key 纳入实际生效的转写提示词(auto 模式下按类型变化)

## [0.2.2] - 2026-08-16

P0 能力升级:转写缓存、视觉降级链、生图失败重试、常用平台预设、CI。

### Added

- **转写缓存**(内容寻址):相同图片字节 + 相同提供商/模型/提示词复用上次转写结果,不再重复消耗视觉模型额度;LRU 上限 200 条,按会话隔离
- **视觉降级链**(`vision.fallbackProviders`):主视觉提供商限流/失败时按优先级自动切换备用提供商,全部失败才降级为占位文本(错误信息标注已尝试的提供商数量)
- **生图失败重试**:host 端单图下载失败自动重试一次;client 失败卡片新增「复制重试指令」按钮,一键复制 `重新生成图片: <prompt>` 到剪贴板
- **常用平台一键预设**:设置页「自定义视觉平台」新增讯飞星辰 / 魔搭 / 硅基流动 / 百度千帆 四个一键添加模板(可再编辑)
- **GitHub Actions CI**:Node 18/20/22 矩阵,typecheck + build + 校验 `lib/` 产物与源码同步

### Fixed

- `downloadImage` 瞬时网络错误导致整批生图失败的问题(自动重试一次)

## [0.2.1] - 2026-08-15

安全审计修复:阻止恶意配置窃取环境变量密钥、SSRF 图片下载、跨会话图片串读、prompt injection 与内部状态泄露。

### Security

- **API key 白名单**(`allowedApiKeyEnvs`):`resolveKey` 只允许读取白名单内的环境变量/凭据名作为 API key,阻止恶意配置(如 `apiKeyEnv: "GITHUB_TOKEN"` + 恶意 `baseURL`)窃取任意进程环境密钥
- **信任域名列表**(`trustedBaseUrls`):自定义视觉平台必须指向可信 baseURL(官方主机自动放行,其余须显式加入白名单),防止凭据被静默重定向到攻击者端点;`extraProviders` key 增加字符白名单校验
- **SSRF 防护**:`generate_image` 下载结果图片时拒绝回环 / 内网(RFC1918)/ 链路本地 / 唯一本地地址
- **不再转发真实 sessionId** 到第三方视觉 API,避免内部状态信息泄露
- **转写文本边界标记**:视觉模型输出属不可信输入,用显式标记包裹,防止图片内嵌 prompt injection 指令被执行
- **内存有界**:`recentImagesBySession` 按会话隔离,每会话最多 3 组、全局最多 200 会话 LRU 淘汰,防止无界内存泄漏

### Changed

- 新增 `z-image` 默认图像后端(阿里云 Z-Image-Turbo,`dashscope-v2` 协议)
- 多模态设置页显示当前后端的地址 / Key 环境变量 / 模型信息
- `ImageBackendConfig.kind` 类型补齐 `dashscope-v2`

## [0.2.0] - 2026-08-14

适配 DeepSeek Harness `0.1.0-rc.6`,并新增会话内生图卡片。

### Added

- **`generate_image` 专属图片卡片**(client 插件,经 `tool.call.toolview` 槽位注入,不改官方前端):
  - 缩略图网格(1~4 张自适应)
  - 点击放大 Lightbox(`Esc` / 点击关闭)
  - 一键保存图片到本地
  - 显示模型、尺寸、提示词等元信息
  - 生成中(运行态)与失败态展示
- **阿里云 Z-Image-Turbo 后端**(`kind: dashscope-v2`,multimodal-generation 同步协议,支持 512×512 ~ 2048×2048)
- 工具输出新增 `failures` 数组(部分图片失败时逐条上报,不影响成功图片展示)

### Fixed

- **生图结果不再被视觉转写**:`agent/pre-step` 只转写用户自己发送的图片;插件注入的图片(如 `generate_image` 输出)原样透传,会话中直接显示图片而非转写文本
- 尺寸校验按后端区分上限(普通 DashScope / OpenAI 兼容 1440,`dashscope-v2` 2048)

### Changed

- client 插件服务依赖增加 `conversation`(保证图片 URL 解析服务就绪后再激活)
- 开发依赖增加 `@deepseek-ai/dsh-client-ui-tool`(仅用于 `tool.call.toolview` 槽位类型检查)

## [0.1.0] - 2026-08-14

初始版本:GLM 视觉转写、OCR、DashScope / OpenAI 兼容文生图后端、多模态设置页。
