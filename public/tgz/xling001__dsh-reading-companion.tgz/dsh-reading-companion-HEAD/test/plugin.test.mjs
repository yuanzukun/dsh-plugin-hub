/**
 * 宿主半边的结构性契约与装配检查。
 *
 * 浏览器半边的契约在 test/client.test.mjs；这里只钉宿主这一侧：
 *  1. 导出符合 cordis 契约，且 patch 行 id 与 name 一致；
 *  2. package.json 的 `dsh` 字段是宿主发现插件的方式，不能被改坏；
 *  3. 路由以 prefix 形态注册、错误语义正确、config 覆盖真的生效。
 *
 * 任何一条被后续改动破坏，都会在这里当场炸掉，而不是等到真机上
 * "页签不见了"或"patch 里的配置被静默忽略"。
 */

import { test } from 'node:test'
import { tmpdir } from 'node:os'
import assert from 'node:assert/strict'
import { readFileSync, readdirSync, rmSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { after } from 'node:test'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
/** 测试期落盘根目录：必须在工作区内，否则会被文件沙箱拒绝。 */
const TMP = join(tmpdir(), 'drc-plugin')
const API_ROOT = '/dsh-reading-companion/api'
const PLUGIN_NAME = 'dsh-reading-companion'

/**
 * 本文件的两个临时目录是**字面名**（不是 `makeDir()` 那种带进程号+时间戳的），
 * 所以它们既不会被 helper 的退出清理覆盖，也会**跨轮复用同一个路径** ——
 * 上一轮的残留能被这一轮读到（正是 CONTRIBUTING 里「与改动无关的红」那一节讲的东西）。
 * 这里在文件跑完时删掉它们：既回收磁盘，也让每一次运行都从干净状态开始。
 */
after(() => {
  for (const name of ['custom-books', PLUGIN_NAME]) {
    rmSync(join(TMP, name), { recursive: true, force: true })
  }
})

/** 每次带不同的 query，绕开 ESM 模块缓存。 */
let loadSeq = 0
function freshUrl(rel) {
  loadSeq += 1
  return `${pathToFileURL(join(ROOT, rel)).href}?t=${loadSeq}`
}

function makeFakeResponse() {
  return {
    status: null,
    headers: null,
    body: '',
    writeHead(status, headers) {
      this.status = status
      this.headers = headers
    },
    end(chunk) {
      if (chunk !== undefined) this.body += chunk.toString('utf8')
    },
  }
}

/** 记录路由注册与服务发布的宿主上下文替身。 */
function makeFakeHostContext() {
  const routes = []
  const services = {}
  const effects = []
  const sections = []
  const guards = []
  /** `ctx.on` 注册的监听器：卸载断言靠它证明订阅被摘掉了。 */
  const events = new Map()
  const ctx = {
    // 让 dshHomePath 指向测试目录：真实的默认值是 $DSH_HOME，
    // 那是工作区之外，测试既不该也无法在那里写。
    get: (name) => (name === 'dshHomePath' ? (...parts) => join(TMP, ...parts) : undefined),
    /**
     * 宿主事件订阅（背景更新 T1-② 的唯一入口）。
     *
     * 与 systemPrompt / tools 一样返回**真的会摘掉自己**的 disposer——否则
     * 「卸载是否干净」那条断言会漏掉本插件新开的这一条订阅。
     */
    on(event, listener) {
      if (!events.has(event)) events.set(event, new Set())
      events.get(event).add(listener)
      return () => {
        events.get(event)?.delete(listener)
      }
    },
    effect(fn, label) {
      const dispose = fn()
      effects.push({ label, dispose })
      return () => dispose?.()
    },
    provide(name, value) {
      services[name] = value
      return () => {
        delete services[name]
      }
    },
    webServer: {
      register(route) {
        routes.push(route)
        return () => {}
      },
    },
    // P2 的两个防剧透挂点。真实宿主会返回 disposer，这里同样返回，
    // 否则「卸载是否干净」这条断言就测不到东西。
    systemPrompt: {
      section(spec) {
        sections.push(spec)
        return () => {
          const at = sections.indexOf(spec)
          if (at !== -1) sections.splice(at, 1)
        }
      },
    },
    tools: {
      guard(guard) {
        guards.push(guard)
        return () => {
          const at = guards.indexOf(guard)
          if (at !== -1) guards.splice(at, 1)
        }
      },
    },
    logger: {},
  }
  return { ctx, routes, services, effects, sections, guards, events }
}

test('宿主半边：导出符合 cordis 契约，且插件名与 patch 行 id 一致', async () => {
  const host = await import(freshUrl('lib/index.js'))

  assert.equal(host.name, PLUGIN_NAME, 'name 必须与 cordis.patch.yml 的行 id 一致')
  assert.ok(Array.isArray(host.inject), 'inject 必须是数组')
  assert.ok(host.inject.includes('webServer'), '宿主半边需要 webServer')
  // 这两个是 P2 的防剧透挂点：少任何一个，插件应当等待而不是静默失去防护。
  assert.ok(host.inject.includes('systemPrompt'), '防剧透正向：按进度投喂')
  assert.ok(host.inject.includes('tools'), '防剧透反向：工具闸')
  assert.equal(typeof host.apply, 'function')

  // patch 行 id 必须等于 name，否则装配出的行解析不到实现。
  const patch = readFileSync(join(ROOT, 'cordis.patch.yml'), 'utf8')
  assert.match(patch, new RegExp(`id:\\s*'${PLUGIN_NAME}'`))
  assert.match(patch, new RegExp(`name:\\s*'${PLUGIN_NAME}'`))
})

test('配置：cordis.patch.yml 里显式写的值必须与代码默认值一致（否则"改了默认值"是个空动作）', async () => {
  // ⚠️ 这条是 2026-10-01 抓到的**真事故**：`memoryTimeoutMs` 从 2 分钟提到 5 分钟时
  //    **只改了代码里的默认值**，而 patch 里那份显式写着 120000 —— YAML 优先，
  //    所以读者那边一直是 2 分钟（"子代理又停了"）。同一套默认值写在两处、只改一处，
  //    等于改了没用。这里把"两处一致"变成一条**会被执行**的断言。
  const host = await import(freshUrl('lib/index.js'))
  const patch = readFileSync(join(ROOT, 'cordis.patch.yml'), 'utf8')

  // 把代码默认值摊平成"键 → 值"。这套 YAML 的键在整份文件里**唯一**，所以不必真解析 YAML。
  const flat = {}
  const walk = (node) => {
    for (const [key, value] of Object.entries(node ?? {})) {
      if (value !== null && typeof value === 'object' && !Array.isArray(value)) walk(value)
      else flat[key] = value
    }
  }
  walk(host.CONFIG_DEFAULTS)

  const seen = []
  for (const line of patch.split('\n')) {
    const matched = /^\s+([a-zA-Z][a-zA-Z0-9]*):\s*(.+?)\s*$/.exec(line)
    if (matched === null) continue
    const key = matched[1]
    if (!Object.hasOwn(flat, key)) continue
    seen.push(key)
    const raw = matched[2].replace(/\s+#.*$/, '') // 行内注释不算值
    const expected = flat[key]
    const actual = typeof expected === 'boolean'
      ? raw === 'true'
      : Array.isArray(expected)
        ? JSON.parse(raw)
        : typeof expected === 'number'
          ? Number(raw)
          : raw.replace(/^'|'$/g, '')
    assert.deepEqual(
      actual,
      expected,
      `cordis.patch.yml 里的 ${key} 与代码默认值不一致 —— 只改了一处，等于没改`,
    )
  }

  assert.ok(seen.length >= 15, `只对上了 ${seen.length} 个键 —— 提取逻辑可疑（YAML 结构变了？）`)
})

test('宿主半边：package.json 的 dsh 字段是宿主发现插件的方式', async () => {
  const pkg = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'))
  assert.equal(pkg.name, PLUGIN_NAME, '包名必须与插件名一致')
  assert.equal(pkg.dsh.bundle.patch, './cordis.patch.yml')
  assert.equal(pkg.dsh.client.platform, 'web')
  assert.equal(pkg.exports['./client'], './lib/client.js')
  assert.equal(pkg.main, './lib/index.js')
  // 浏览器半边的模块 id 必须等于包名，否则 <pkg> 与 <pkg>/client 不会归一。
  assert.ok(pkg.files.includes('lib'), 'lib 必须随包发布')
})

test('发行包：`scripts/` 按**文件白名单**发布，只发读者面那一个', () => {
  // ⚠️ 从前这里是**整目录发布**（`"scripts"`）⇒ 读者拿到 6 个纯开发工具（合并背景史 /
  //    归档背景 / 改主体名 / 清背景笔记 / 重建索引 / 挂进 profile）+ 2 个普查工具。
  //    其中只有 `reindex-books.mjs` 是**读者面**的：升级后书库索引要重建一次。
  //    ⇒ 改成按文件白名单。这条守卫钉的是**分类纪律**，不是那一个文件名。
  //
  // 可证伪：① 把 `files` 改回 `"scripts"` ⇒ 第一条红；② 从 `files` 里删掉
  //    `scripts/reindex-books.mjs` ⇒ 第二条红；③ 新建一个 `scripts/foo.mjs` 而不表态
  //    ⇒ 第三条红（它逼你**做一次决定**：发还是不发）。
  const pkg = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'))
  const published = pkg.files.filter((entry) => entry === 'scripts' || entry.startsWith('scripts/'))

  assert.ok(
    !published.includes('scripts'),
    '不许再整目录发布 scripts/ —— 那等于"默认把开发工具也发给读者"',
  )
  assert.ok(
    published.includes('scripts/reindex-books.mjs'),
    'reindex-books 是读者升级时要跑的，必须随包发布',
  )

  // ⚠️ **派生**而不是把清单抄一遍：目录里**每一个** `scripts/*.mjs` 都必须被明确分类 ——
  //    要么随包发布、要么显式列进 DEV_ONLY。新增脚本时这条会红，逼你表态，
  //    而不是让它**悄悄跟着发出去**（"默认发布"正是这条要治的病）。
  const DEV_ONLY = [
    'archive-background.mjs',
    'clean-background-note.mjs',
    'guard-census.mjs',
    'guard-classify.mjs',
    'link-into-profile.mjs',
    'merge-background-history.mjs',
    'merge-background-subjects.mjs',
    'rebuild-library-index.mjs',
  ]
  const all = readdirSync(join(ROOT, 'scripts')).filter((name) => name.endsWith('.mjs'))
  assert.ok(all.length >= 8, `只扫到 ${all.length} 个脚本 —— 扫描逻辑可疑`)

  const unclassified = all.filter((name) => !published.includes(`scripts/${name}`) && !DEV_ONLY.includes(name))
  assert.deepEqual(
    unclassified,
    [],
    `这些脚本没被分类（要么随包发布、要么加进 DEV_ONLY）：${unclassified.join(' / ')}`,
  )
  // 反向也要成立：DEV_ONLY 里写的必须真的存在 —— 别留一份过期的排除名单。
  const stale = DEV_ONLY.filter((name) => !all.includes(name))
  assert.deepEqual(stale, [], `DEV_ONLY 里有已经不存在的脚本：${stale.join(' / ')}`)
  // 而且被排除的那些**真的**不在发布清单里（防"名单写了、files 忘了"）。
  for (const name of DEV_ONLY) {
    assert.ok(!published.includes(`scripts/${name}`), `${name} 是开发侧工具，不该随包发布`)
  }
})

test('宿主半边：客户端半边真的依赖谁，就在 dsh.client.inject 里声明谁', () => {
  const pkg = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'))
  const clientSource = readFileSync(join(ROOT, 'lib', 'client.js'), 'utf8')

  const declared = pkg.dsh.client.inject
  assert.ok(Array.isArray(declared), 'inject 必须是数组（缺省的空数组也是数组）')

  // 为什么这条不是"把清单抄一遍"：清单是**从源码用法推出来的**。
  //
  // 客户端插件的加载顺序由 profile 的 `dsh.profile.bundles` 与各插件自己的
  // `inject` 决定 —— 本仓库真出过这个事故：读者装了新插件之后，我们排在宿主
  // ui-sidebar-right 之后才装配，`ctx.get('sessions')` 拿到 undefined，书架那行
  // 的「跳过去」**永久**退化成不可点静态标（v1.68 docs/design-v1-archive.md §392–395）。惰性取用能让功能
  // 不消失，但**声明**才是"让宿主知道我们依赖谁、按序装配"的那一半。
  const REQUIRED = [
    ['ctx.slots', '@deepseek-ai/dsh-client-ui-slots'],
    ['ctx.sidebarRightTabs', '@deepseek-ai/dsh-client-ui-sidebar-right'],
  ]
  for (const [usage, packageName] of REQUIRED) {
    if (!clientSource.includes(usage)) continue
    assert.ok(declared.includes(packageName), `客户端用了 ${usage} 就必须声明 ${packageName}`)
  }

  // 反向：声明了却在源码里一个字节都找不到，是**僵尸依赖** —— 它只会让装配
  // 多等一个（或永远等一个）包。新增声明时请把上表一起补上"它对应哪一处用法"。
  for (const packageName of declared) {
    const hit = REQUIRED.find(([, name]) => name === packageName)
    assert.ok(hit !== undefined, `声明了 ${packageName}，但上表里没有它：请补上它对应源码里的哪一处用法`)
    assert.ok(clientSource.includes(hit[0]), `声明了 ${packageName} 却没用过 ${hit[0]}`)
  }
})

test('宿主半边：注册 prefix 路由并正确响应 /health', async () => {
  const host = await import(freshUrl('lib/index.js'))
  const { ctx, routes } = makeFakeHostContext()

  host.apply(ctx, {})

  assert.equal(routes.length, 1, '只注册一条 prefix 路由')
  assert.equal(routes[0].kind, 'prefix')
  assert.equal(routes[0].path, API_ROOT)
  assert.equal(typeof routes[0].handler, 'function')

  const res = makeFakeResponse()
  await routes[0].handler({ url: `${API_ROOT}/health`, method: 'GET' }, res)

  assert.equal(res.status, 200)
  assert.match(res.headers['content-type'], /application\/json/)
  const body = JSON.parse(res.body)
  assert.equal(body.ok, true)
  assert.equal(body.name, PLUGIN_NAME)
  // 曾经断言 `body.phase === 'P2'`（开发阶段标签，早已过期）。改成版本一致性契约。
  const pkg = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'))
  assert.equal(body.version, pkg.version, '版本必须与 package.json 一致')
  assert.equal(typeof body.storageDir, 'string')
  // 收件箱位置也回给客户端：面板要显示**宿主真正在扫的那个目录**，不能自己拼
  // （拼的话 `inboxDir` 配置一改，界面指的与真被扫的就是两个地方 —— 读者照面板
  // 提示放书、然后「扫描」什么也没有，看起来像插件的错）。
  assert.equal(body.inboxDir, join(body.storageDir, 'inbox'), '默认收件箱必须落在 storageDir 下')
})

test('宿主半边：inboxDir 配置真的生效（v1.71 之前它写在 schema 里却从未被用）', async () => {
  const host = await import(freshUrl('lib/index.js'))
  const { ctx, routes, services } = makeFakeHostContext()

  host.apply(ctx, { inboxDir: 'custom-inbox' })

  const res = makeFakeResponse()
  await routes[0].handler({ url: `${API_ROOT}/health`, method: 'GET' }, res)
  const body = JSON.parse(res.body)
  assert.equal(body.inboxDir, join(body.storageDir, 'custom-inbox'), '相对名要相对 storageDir 解析')
  assert.equal(
    services.readingCompanion.library.paths.inbox,
    body.inboxDir,
    '服务与 /health 必须是同一个值 —— 两处各算一遍就会漂',
  )
})

test('宿主半边：apply 会发布 readingCompanion 服务并建好书库目录', async () => {
  const host = await import(freshUrl('lib/index.js'))
  const { ctx, services, effects, sections, guards } = makeFakeHostContext()

  host.apply(ctx, {})

  assert.ok(services.readingCompanion, '未来的子插件与脚本要靠它')
  const { library } = services.readingCompanion
  assert.equal(typeof library.bookForSession, 'function', '防剧透链路的入口')
  assert.equal(typeof library.collectReadWindow, 'function', '正向投喂的唯一来源')
  assert.equal(typeof library.importBook, 'function')

  // 两个防剧透挂点都必须真的挂上。
  assert.equal(sections.length, 1, '必须注册且只注册一个 system 段落')
  assert.equal(sections[0].name, 'dsh-reading-companion:companion')
  assert.equal(typeof sections[0].text, 'function')
  assert.equal(guards.length, 1, '必须注册且只注册一个工具闸')

  // 路由 + 服务 + 段落 + 工具闸 + 背景更新订阅，五个 effect 都必须可卸载。
  assert.equal(effects.length, 5)
  for (const entry of effects) {
    assert.equal(typeof entry.dispose, 'function', `effect「${entry.label}」必须可卸载`)
  }
})

test('宿主半边：非陪读会话拿到空段落（全局注册必须自我否决）', async () => {
  const host = await import(freshUrl('lib/index.js'))
  const { ctx, sections } = makeFakeHostContext()
  host.apply(ctx, {})

  const text = sections[0].text
  // 没有 agent、agent 无 session、会话未绑定 —— 三种都必须回空串，
  // 否则全局注册的段落会污染用户所有正常会话。
  assert.equal(text({}), '')
  assert.equal(text({ agent: {} }), '')
  assert.equal(text({ agent: { id: 'not-bound-session' } }), '')
  assert.equal(text({ agent: { session: { id: 'not-bound-session' } } }), '')
})

test('宿主半边：段落回调永不抛错（抛错会毁掉整次 prompt 装配）', async () => {
  const host = await import(freshUrl('lib/index.js'))
  const { ctx, sections, services } = makeFakeHostContext()
  host.apply(ctx, {})

  // 强行让书库查询爆炸，段落回调必须吞掉异常并退回空串。
  services.readingCompanion.library.bookForSession = () => {
    throw new Error('boom')
  }
  assert.equal(sections[0].text({ agent: { session: { id: 'x' } } }), '')
})

test('宿主半边：未知路由回 404，且不泄漏内部细节', async () => {
  const host = await import(freshUrl('lib/index.js'))
  const { ctx, routes } = makeFakeHostContext()
  host.apply(ctx, {})

  const res = makeFakeResponse()
  await routes[0].handler({ url: `${API_ROOT}/nope`, method: 'GET' }, res)
  assert.equal(res.status, 404)
  assert.equal(JSON.parse(res.body).error, 'NOT_FOUND')
})

test('宿主半边：config 覆盖生效（patch 里的值不会被静默忽略）', async () => {
  const host = await import(freshUrl('lib/index.js'))
  const { ctx, routes } = makeFakeHostContext()
  const customDir = join(TMP, 'custom-books')
  host.apply(ctx, { storageDir: customDir, fallbackBlockChars: 1234 })

  const res = makeFakeResponse()
  await routes[0].handler({ url: `${API_ROOT}/health`, method: 'GET' }, res)
  const body = JSON.parse(res.body)

  assert.equal(body.storageDir, customDir)
  assert.equal(body.config.fallbackBlockChars, 1234)
  // 未覆盖的键要回落到默认值。
  assert.equal(body.config.inboxDir, 'inbox')
})

test('宿主半边：卸载后路由与服务都摘掉（低破坏性）', async () => {
  const host = await import(freshUrl('lib/index.js'))
  const { ctx, services, effects, events } = makeFakeHostContext()
  host.apply(ctx, {})

  assert.ok(services.readingCompanion)
  assert.ok((events.get('session/event')?.size ?? 0) > 0, '背景更新订阅必须挂上')
  for (const entry of effects) entry.dispose()
  assert.equal(services.readingCompanion, undefined, '卸载必须摘掉服务，不能留悬挂引用')
  // 订阅也要摘干净：留下悬挂监听器意味着插件停用之后仍在吃每一条会话事件。
  assert.equal(events.get('session/event')?.size ?? 0, 0, '卸载必须摘掉 session/event 订阅')
})
