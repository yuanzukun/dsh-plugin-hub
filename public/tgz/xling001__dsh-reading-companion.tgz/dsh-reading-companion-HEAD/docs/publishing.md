# 打包契约：一个 DSH 插件在磁盘上必须长什么样

> **这份文件是从 DSH 的运行时代码里读出来的，不是从文档抄的。**
>
> 截至本仓库发布时，DSH 安装包内**没有任何插件开发文档**——整个 `resources/app`
> 目录（除 `node_modules`）里一个 `.md` / `.txt` 都找不到。所以"发布规范"没有
> 权威出处，只能以**加载器的实际行为**为准。
>
> 下面每条都标了**证据位置**（`文件:行号`），方便 DSH 升级后回来复核。

---

## 1. 三个字段决定一切

`package.json` 里只有三个字段参与插件装配：

| 字段 | 作用 | 证据 |
|---|---|---|
| `exports["./client"]` | **浏览器半边**的入口，宿主唯一会读的客户端文件 | `@deepseek-ai/dsh-client-modules/lib/index.js:158` |
| `dsh.client` | 声明这是个 Web 客户端插件 | 同上 `:649-655` |
| `dsh.bundle.patch` | 宿主半边要应用的 cordis patch 文件 | `resources/app/lib/profile-39RdjuE6.js:448` |

### `exports["./client"]`

```jsonc
"exports": {
  ".": "./lib/index.js",         // 宿主半边（ESM，可以 import）
  "./client": "./lib/client.js", // 浏览器半边
  "./package.json": "./package.json"
}
```

接受**两种形状**：字符串，或带 `default` 的一层条件对象
（`:155` 的注释：*accepting the string and one-level conditional forms*）。

> ⚠️ **声明了 `dsh.client` 却没有 `exports["./client"]` = 启动即抛错**，不是静默忽略：
>
> ```
> client-modules: <pkg> declares dsh.client but exports no "./client" bundle
> ```
>
> 证据：`:655`。

### `dsh.client`

```jsonc
"dsh": {
  "client": {
    "platform": "web",   // 必填且必须是字符串；只有 "web" 会被装配
    "inject": []         // 可选：声明需要先物化的其他客户端包
  }
}
```

- `platform` 不是字符串 → **抛错**（`:144`）。
- `platform` 不等于 `"web"` → **静默跳过**（`:650-653` 直接 `return null`）：
  这个包不会进客户端图，**也不会报错**。这个失效方向很容易让人白查半天。
- `inject` 必须是字符串数组（`:145`）。
- 还有两个字段在代码里被读取，但没有出现在任何说明里：
  `external`（默认 `[]`，`:661`）与 `immediately`（默认 `false`，`:662`）。

### `dsh.bundle.patch`

```jsonc
"dsh": { "bundle": { "patch": "./cordis.patch.yml" } }
```

宿主启动时按这个路径读 patch，把插件那一行 `insert` 进 cordis 组合
（`resources/app/lib/profile-39RdjuE6.js:448`）。

---

## 2. 客户端半边是**普通脚本**，不是 ESM

这条最容易搞错，也是本仓库"`lib/client.js` 不拆文件"这个结论的根据。

- `lib/client.js` 被 **`readFileSync` 读成字符串**，与其它插件的 bundle 用 `;`
  拼接成一个 combo 脚本注入页面。
- 所以它**不能**用 `import` / `export`，也不能用 JSX——**没有转译步骤**。
- 它调 `window.__ModuleLoader__.load({ id, factory })` 登记一个工厂；
  **所有副作用（包括 CSS 注入）必须留在工厂闭包内**
  （`dsh-client-modules/lib/client.js:18`）。
- 客户端 `require()` 只认三样东西：platform seed 词（如 `react`）、已物化的模块、
  已登记的工厂。**三样都不是就大声抛错**（`client.js:308`）——
  它不会静默返回 `undefined`，这是好事。

**推论**：`lib/client.js` 是一个约 4000 行的单文件。这不是没整理，
而是**这个环境的形状**——拆成多文件需要打包器（就是构建步骤）
或拆成多个包（会把 profile 的单行开关变成多行必须同时正确）。
详见 `design-v1-archive.md` 里关于拆分的那一节。

---

## 3. profile 侧的三个键

profile 的 `package.json` 里：

```jsonc
{
  "dependencies": { "dsh-reading-companion": "..." },
  "dsh": {
    "profile": {
      "bundles": [ /* ... */ "dsh-reading-companion" ],
      "patchReload": "live"
    }
  }
}
```

| 键 | 约束 | 证据 |
|---|---|---|
| `dsh.profile.bundles` | 字符串数组；**`desktopBundle` 是启动器私有的，不许出现在这里** | `lib/profile-39RdjuE6.js:321`、`lib/profile-manager-B1i2uYdj.js:75` |
| `dsh.profile.patchReload` | 只能是 `"live"` 或 `"startup"` | `lib/profile-39RdjuE6.js:427` |

> ⚠️ **`bundles` 只在启动时读一次。** `patchReload: "live"` 只覆盖
> `cordis.patch.yml` 的**内容**改动，覆盖不了"新增一个 bundle"。
> 所以装完插件**必须重启 DSH Desktop**，刷新页面不够。

### 3.1 profile 叫什么，以及 `dsh plugin` 究竟做了什么

**profile 名因平台而异，而且 Desktop 那个不是 DSH 自带的模板。**

| 你用的面 | profile 名 | 是自带模板吗 | profile 目录 |
|---|---|---|---|
| DSH Desktop | `desktop` | **否**，应用自有 | `$DSH_HOME/profiles/desktop` |
| DSH Web（`dsh web`） | `web` | 是 | `$DSH_HOME/profiles/web` |

证据：`@deepseek-ai/dsh-app-boot/lib/index.js:327-349` 的 `PROFILE_TEMPLATES` 只有
`acp` / `web` / `headless` / `sdk` / `sdk-minimal` **五个，没有 `desktop`**。
`desktop` 是**应用自有 profile**，走 `loadProfileDirectory()`（`:833-843`），
其注释原文是 *used by application-owned profiles whose package project and lifecycle
belong to that application*——所以它不走共享 Harness home 的模板初始化。

`dsh web` 就是 `--profile web` 的别名（`dsh-cmdline/lib/index.js:100`）。
目录解析见 `resolveProfileDir()`（`dsh-app-boot/lib/index.js:323-326`）：
一切都在 `$DSH_HOME/profiles/<name>` 下。

**`dsh plugin` 自己不实现安装**——它把剩余参数**原样转发给 profile 目录里的 pnpm**
（`@deepseek-ai/dsh-cmdline/lib/index.js:105`）。但 pnpm 结束后 DSH 会做一次调和
（`@deepseek-ai/dsh/lib/plugin-*.js:11-77`，函数注释以 *Reconcile `dsh.profile.bundles`
against the installed state* 开头）：

- 依赖里**声明了** `dsh.bundle` 的包 → **自动补进** `dsh.profile.bundles`；
- 已列入 `bundles`、但依赖里没有（或新版本不再声明 `dsh.bundle`）的 → **保留不动**。

所以 `dsh plugin add` 之后**不需要手动改 `bundles`**——前提是本包确实声明了
`dsh.bundle.patch`（§1）。反过来，一条列进 `bundles` 的包若**没有** `dsh.bundle`，
是**启动即抛错**（`dsh-app-boot/lib/index.js:851-852`），不是"这个包没有 patch"。

> 从 git 源安装时 pnpm 会**拦截构建脚本**（`prepare`）。DSH 会把提示写到 stderr，
> 让你把 pnpm 打印出的 key 加进 profile 的 `pnpm-workspace.yaml` 的 `allowBuilds`
> 后重跑（`plugin-*.js:126`）。本插件**没有构建步骤**，正常不会遇到。

---

### 3.2 前置依赖：注册到**DSH 本体**的侧边栏

本插件**自己不画侧边栏**：它往 DSH 提供的右侧栏里注册一个页签。
**它不依赖任何第三方插件** —— `dependencies` 与 `peerDependencies` 都是空的。
这条声明方式值得单独记一笔，因为最容易写错地方。

| 写法 | 管什么 | 用在这里 |
|---|---|---|
| `dsh.client.inject` | **客户端模块之间的物化顺序** | ✅ 两个官方客户端模块 |
| cordis 的 `inject` | **服务是否就绪** | ✅ `['sidebarRightTabs', 'slots']` |
| `peerDependencies` | npm 层面的依赖 | ❌ **没有可声明的包**（见下） |

**那个服务是谁发布的（2026-10-04 实测更正）。** 这份文档从前写着"`sidebarRightTabs`
是 `dsh-better-sidebar` 发布的服务名"，并据此在 `package.json` 里声明了一条 optional peer。
**两句都是错的：**

- `dsh-better-sidebar` 自己发布的服务叫 **`betterSidebar`**（`ctx.provide("betterSidebar", …)`），
  而它**也是** `sidebarRightTabs` 的**消费方**（`ctx.inject(["sidebarRightTabs"], …)`）；
- 这个服务来自 **DSH 本体**的客户端模块 `@deepseek-ai/dsh-client-ui-sidebar-right`
  （同类插件 `dsh-image-gen` 的注释写着"DSH 0.1.5 `sidebarRightTabs`"）。它在 profile 的
  `node_modules` 里**根本不存在**（壳在运行期提供）⇒ **没有 npm 包可以声明**。

⇒ 3.1.11 把那条 `peerDependencies` / `peerDependenciesMeta` 连同 README 的"前置"说法一起删掉了。
判据还有一条旁证：本机 node_modules 里 8 个同类插件**没有一个**声明 `dsh-better-sidebar`；
而本仓库封存件里早就写着"**不依赖**，主路径 native 三件套"。

**`dsh.client.inject` 声明的是"壳要加载哪些客户端模块"**：本插件写的是
`["@deepseek-ai/dsh-client-ui-slots", "@deepseek-ai/dsh-client-ui-sidebar-right"]`
（`package.json` 的 `dsh.client` 字段）。它**不是** npm 依赖 —— 那两个包不随包安装，
所以**不能**、也不必写成 `peerDependencies`。

**真正决定"装配等不等"的是 cordis 级 `inject`**：`lib/client.js`
`const inject = ['sidebarRightTabs', 'slots']`。服务不出现 → cordis **不执行 `apply`、
不报错、一直等** —— 这正是"缺服务时界面完全没有、控制台也没有任何错误"的确切来源。
所以 README 把**版本要求**写成了前置：`sidebarRightTabs` 是 DSH `0.1.5` 起才有的服务。

---

## 4. 本仓库怎么用这份契约

### 4.1 **发行包 = `package.json` 的 `files` 白名单子集**

> ⚠️ 这条契约从前**只写在封存件里**（`design-v1-archive.md` §245 那一行），而它是
> "为什么改工作区不生效"的答案 —— 关键契约不该埋在 380 KB 的历史流水第 444 行。
> 2026-10-02 代码健康度评审 #5 把它上移到这里。

- 装到 profile 里的那份（`<profile>/node_modules/dsh-reading-companion`）**不是**
  指向工作区的 junction，而是**打包产物**：文件清单**正好等于** `package.json` 的
  `files` 白名单（本仓库现在是 `lib/` + **显式的两份文档** `docs/design.md` /
  `docs/publishing.md` + **一个脚本** `scripts/reindex-books.mjs` + 4 个根文件；
  2026-10-03 实测 **27 个文件 / 未打包 1.2 MB / 压缩后 440.6 kB**；工作区那份有 102 个）。
  所以**改工作区不会让运行副本生效** —— 必须重新同步/安装。
- 反过来也要知道：profile 的依赖写的是 `file:` 指向工作区那份，所以**只更新运行副本、
  不同步工作区**的话，下次 `pnpm install` / `dsh plugin add` 会把运行副本**静默回退**。
  两棵树必须一起动。同步脚本是 `drc-sync.ps1`（**在工作区根目录、不在仓库里**，
  也不随包发布）：默认干跑、`-Apply` 才写、每步先备份、可 `-Rollback`，
  且 LIVE 的白名单**从 `package.json` 的 `files` 派生**（打包规则改了它自动跟上）。
- 推论：`files` 白名单**就是**"读者会拿到什么"的口径。**内部记录不要进白名单**；
  反过来，读者需要的文件若不在白名单里，等于没发布。
- ⚠️ **2026-10-03 起 `docs/` 不再用 `docs/*.md` 通配**，改成**逐个点名**。原因是那次实测：
  `docs/*.md` 会把**两份修订史（合计 543 KB）+ `manual-testing.md`** 一起打进包里，
  而 `lib/` 只在**注释**里引用它们、**运行时零读取** —— 那些 `docs/… §N` 引用在**仓库**
  里解析就够了（读代码的人本来就在仓库里）。通配的坏处是**新增一份内部文档会自动随包发布**，
  而没人会注意到；点名之后，多一份文档进包必须**有人动手改 `files`**，这件事才会被看见。
  判据：**读者需要的（`design.md` / `publishing.md`）点名进白名单；其余留在仓库里。**
- ⚠️ **2026-10-03：`scripts/` 也从整目录改成逐个点名。** 同一个理由（通配 = 新增的东西
  **自动随包发布**，而没人会注意到）：整目录发布会让读者拿到 **8 个开发脚本**（合并背景史 /
  归档背景 / 改主体名 / 清背景笔记 / 重建索引 / 挂进 profile + 2 个普查工具），而其中只有
  `reindex-books.mjs` 是**读者面**的（升级后书库索引要重建一次）。
  ⚠️ 与 `docs/` 那条**不同**的是：这里还配了一条**派生守卫**（`test/plugin.test.mjs`）——
  目录里**每一个** `scripts/*.mjs` 都必须被明确分类（随包发布 / 显式排除进 `DEV_ONLY`），
  新增脚本时它会红，**逼你表态**，而不是靠"记得改 `files`"。判据同上：
  **读者需要的点名进白名单；其余留在仓库里。**

### 4.2 装配行的两处硬约束

- `cordis.patch.yml` 里的行 `id` **必须**等于宿主半边导出的 cordis `name`，
  否则加载器会挂上一行名字解析不到任何东西的 row。
  `test/plugin.test.mjs` 会校验这条一致性。
- patch 是**纯加法**（一个 `insert`），所以禁用/删除它就是这个插件的
  完整、无副作用的关闭开关。

---

## 5. DSH 升级后怎么复核

```bash
DSH_APP="/path/to/DSH/resources/app"

# 证据点 1：客户端半边的入口与 dsh.client 解析
grep -n 'exports\["./client"\]\|dsh\.client\|must be a string' \
  "$DSH_APP/node_modules/@deepseek-ai/dsh-client-modules/lib/index.js"

# 证据点 2：宿主半边读 patch 的地方
grep -n 'bundle?.patch' "$DSH_APP/lib/profile-"*.js
```

如果这两条的输出形态变了，本文件就需要更新——
同时 `test/plugin.test.mjs` 大概率会先变红。
