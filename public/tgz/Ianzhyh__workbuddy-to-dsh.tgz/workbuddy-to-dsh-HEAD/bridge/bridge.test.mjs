/**
 * 本地桥的**合约测试**：起一个真实桥进程，用真实 HTTP 打它。
 *
 *   node --test bridge/
 *
 * 为什么这么测：`bridge/workbuddy-bridge.mjs` 是"启动即监听"的脚本，没有导出
 * 可直接单测的单元；而它对外的东西恰恰是**HTTP 契约**（面板、控制台、dsh 插件
 * 都按这些端点对接）。所以这里起真进程、打真请求 —— 验的是别人实际依赖的那层。
 *
 * 隔离措施（绝不碰使用者的真实凭据与额度）：
 *   - 临时目录里放一份**假的登录文件**，用 WORKBUDDY_AUTH_FILE 指过去；
 *   - 端口用 0 让内核分配，避免和正在跑的 8790 撞车；
 *   - 临时目录里的 usage.jsonl 是独立账本，不写使用者的那份；
 *   - 不触达上游：这里只验"不需要上游就能答"的契约（鉴权、/、模型目录形状、
 *     计数类端点），需要真实额度的 /v1/chat/completions 由 dsh-plugin 的
 *     adapter 测试用打桩上游覆盖。
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createCipheriv, createHash, randomBytes } from 'node:crypto';
import { spawn } from 'node:child_process';
import { createServer, request as httpRequest, Agent as HttpAgent } from 'node:http';
import { mkdtempSync, mkdirSync, rmSync, writeFileSync, existsSync, readFileSync, readdirSync, utimesSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { pickBridgePort, isPortInUseError } from '../tools/dev/bridge-ports.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const REPO = dirname(HERE);
const BRIDGE = join(REPO, 'bridge', 'workbuddy-bridge.mjs');
const TOKEN = 'test-token-abc';

/**
 * 一份"看起来像登录文件"的假凭据：桥能读结构，但拿不到真实令牌。
 *
 * 注意这里是**扁平**的（没有 `auth` 包裹层）。这不是笔误，而是刻意保留的：
 * 桥读的是 `raw.auth.accessToken`，扁平文件会让 `readStoredAuth()` 抛
 * 「login file has no accessToken」—— 正好被 `/health` 那条用例用来复现
 * 「凭据异常」。
 */
const FAKE_AUTH = {
  userId: 'test-account-000000',
  accessToken: 'fake-access-token',
  refreshToken: 'fake-refresh-token',
  endpoint: 'https://example.invalid',
  domain: 'example.invalid',
  expiresAt: Date.now() + 30 * 86_400_000,
};

/**
 * 一份**结构正确**的假登录文件：`auth` 包裹层齐全，`readStoredAuth()` 能读通。
 *
 * 需要它的场景（如 D3 的模型预校验）必须先让桥成功读到凭据，否则抓目录那步
 * 直接抛异常、`catalogCache` 永远是空的，预校验按设计放行就测不到。
 * 令牌本身仍是假的 —— 断言的是「桥怎么处理目录」，不是「能不能打通上游」。
 */
const READABLE_FAKE_AUTH = {
  auth: {
    accessToken: 'fake-access-token',
    refreshToken: 'fake-refresh-token',
    domain: 'example.invalid',
    expiresAt: Date.now() + 30 * 86_400_000,
  },
};

/** 可解码的假 JWT（默认只带 sub/exp，可选补充 claims）—— 账号跟随用例靠 sub 区分身份。 */
function fakeJwt(sub, claims = {}) {
  const body = Buffer.from(JSON.stringify({ sub, ...claims, exp: Math.floor(Date.now() / 1000) + 86_400 }), 'utf8').toString('base64url');
  return `e30.${body}.sig`;
}

/** 一份可被桥解密的登录文件内容（纯文本字段，不走 at-rest 信封）。 */
function authFileFor(sub, domain = 'example.invalid', claims = {}) {
  return {
    auth: {
      accessToken: fakeJwt(sub, claims),
      refreshToken: 'fake-refresh-token',
      domain,
      expiresAt: Date.now() + 30 * 86_400_000,
    },
  };
}

/**
 * 起一个隔离的桥实例。
 *
 * ## 端口为什么不用 `listen(0)`，也不用 20000–40000 的"随机"
 *
 * 桥是**独立进程**，它自己 listen：测试进程这边没法把"内核分配的那个端口"
 * 读回来交给子进程。能做的只有"挑一个、撞了再换"。
 *
 * 旧写法的两个问题（2026-10-27 实测，v1.17.0 发版门禁 ubuntu-latest）：
 *
 *   1. 区间 20000–39999 **横跨 Linux 的临时端口段**（默认 32768–60999）。
 *      打桩上游都走 `listen(0)`，内核会把它们分到同一段里 —— 于是迟早撞上。
 *      实测就是 `listen EADDRINUSE ... 127.0.0.1:39846`。
 *   2. 撞了就直接抛错，**打桩上游没关**，用例的 `finally` 根本没轮到执行。
 *      那个 listen socket 挂在测试进程上，`node --test` 等不到事件循环清空，
 *      跑完全部用例后**进程不退** —— CI 上表现为 20 分钟后 job 被 cancel，
 *      而不是一条"端口撞了"的失败。
 *
 * 现在：端口从 `bridge-ports.mjs` 取（12000–19999，在临时端口段之外），
 * 撞上了**换端口重试**（最多 5 次），重试用尽才把原始失败抛出去。
 *
 * @param {object} [env] 额外环境变量
 * @param {object} [opts]
 * @param {object} [opts.auth] 写入登录文件的凭据（默认 FAKE_AUTH）。
 *   `readStoredAuth()` 要求 `auth.accessToken` 存在；传 READABLE_FAKE_AUTH
 *   可让桥"读得到凭据"，从而走到抓目录 / 打上游那几步。
 * @returns {Promise<{baseUrl: string, dir: string, out: () => string, stop: () => Promise<void>}>}
 */
async function startBridge(env = {}, opts = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'wb-bridge-test-'));
  const authFile = join(dir, 'fake-auth.info');
  writeFileSync(authFile, JSON.stringify(opts.auth || FAKE_AUTH));

  /*
   * 最多试 5 次端口。撞车时**必须**把上一个子进程收干净再重试 —— 否则
   * 重试只是在制造新的僵尸进程，问题从"起不来"变成"越跑越慢"。
   */
  const attempts = 5;
  let lastError = null;
  /*
   * 继承宿主环境时先摘掉会改变桥行为的变量：开发者本机若有真实的
   * WORKBUDDY_CREDENTIAL_KEY / CODEBUDDY_API_KEY / 限流窗口等，用例会
   * 在本机红、CI 绿（或反过来）。每个用例都能通过 `env` 显式覆盖。
   */
  const inherited = { ...process.env };
  for (const key of [
    'CODEBUDDY_API_KEY',
    'WORKBUDDY_CREDENTIAL_KEY',
    'WORKBUDDY_CREDENTIAL_SOURCE',
    'WORKBUDDY_CREDENTIAL_STORE',
    'WORKBUDDY_ACCOUNT_FAILOVER_AFTER',
    'WORKBUDDY_RATE_LIMIT_WINDOW_MS',
    'WORKBUDDY_CATALOG_RETRY_MS',
    'WORKBUDDY_429_WAITS',
    // 出站身份：用例要能断言默认/覆盖两种形状，不能被开发者本机 env 污染。
    'WORKBUDDY_APP_VERSION',
    'WORKBUDDY_CLI_VERSION',
    'WORKBUDDY_IDE_NAME',
    'WORKBUDDY_IDE_VERSION',
    'WORKBUDDY_IDENTITY',
    'WORKBUDDY_PLUGIN_IDENTITY',
    'WORKBUDDY_APP_EXECUTABLE',
  ]) delete inherited[key];
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    lastError = null;
    const port = pickBridgePort();
    const child = spawn(process.execPath, [BRIDGE], {
      cwd: dir, // 工作目录放在临时目录：账本/日志都落在里面
      stdio: ['ignore', 'pipe', 'pipe'],
      env: {
        ...inherited,
        WORKBUDDY_HOST: '127.0.0.1',
        WORKBUDDY_PORT: String(port),
        WORKBUDDY_LOCAL_TOKEN: TOKEN,
        WORKBUDDY_AUTH_FILE: authFile,
        // 凭据库必须隔离：否则测试会读到本机真实的插件登录凭据（/health 不再是 503）。
        WORKBUDDY_CREDENTIAL_DIR: join(dir, 'credentials'),
        WORKBUDDY_USAGE_FILE: join(dir, 'usage.jsonl'),
        WORKBUDDY_MEDIA_STORE_FILE: join(dir, 'media-tasks.json'),
        // 面板保存的「默认视图规模」也必须隔离：它与 .state.json 不同，
        // 之前漏了这一条 → 测试把 `value: "4"` 写进了用户真实的
        // `~/.workbuddy-bridge/models-default.json`，跑完测试后真实桥就少列模型，
        // 而测试自己是"通过"的（最坏的一类污染：改的是用户数据、症状隔一轮才现形）。
        WORKBUDDY_MODELS_DEFAULT_FILE: join(dir, 'models-default.json'),
        WORKBUDDY_AUTO_CHECKIN: '0', // 别在测试里触发签到
        WORKBUDDY_LOG: '0',
        ...env,
      },
    });

    let output = '';
    child.stdout.on('data', (d) => { output += d; });
    child.stderr.on('data', (d) => { output += d; });

    const baseUrl = `http://127.0.0.1:${port}`;
    const deadline = Date.now() + 20_000;
    while (Date.now() < deadline) {
      if (child.exitCode !== null) {
        // 端口撞了才值得重试；配置写错 / 依赖缺失换端口也没用，直接抛出。
        lastError = new Error(`桥提前退出（code ${child.exitCode}）：\n${output}`);
        break;
      }
      try {
        /*
         * 就绪判据必须证明「端口上应答的就是我 spawn 的这个 pid」。
         *
         * 原先只看 `res.status > 0`——任何 HTTP 响应都认领。端口上若是本机别的
         * 服务（或另一个测试文件起的桥），它会被当成自己的桥，后续请求全部打到
         * 别人身上，失败原因看起来毫无道理（实测过一次：count_tokens 用例拿到
         * 403，而它期望 413）。
         *
         * 令牌可能被用例显式覆盖成空串（那是「让桥自动生成」的场景），此时从
         * 子进程输出里取它打印的真实值 —— 桥在 listen 之前就会打印这一行。
         */
        const probeToken = (typeof env.WORKBUDDY_LOCAL_TOKEN === 'string' && env.WORKBUDDY_LOCAL_TOKEN)
          ? env.WORKBUDDY_LOCAL_TOKEN
          : (output.match(/WORKBUDDY_LOCAL_TOKEN=([A-Za-z0-9._-]{16,})/)?.[1] || TOKEN);
        const res = await fetch(baseUrl + '/v1/identity', {
          headers: { authorization: `Bearer ${probeToken}` },
          signal: AbortSignal.timeout(1500),
        });
        const body = await res.json().catch(() => null);
        // `/v1/identity` 在凭据读不出时回 503，但 body 里同样带 pid —— 只要 pid 相符就认。
        if (body && Number(body.pid) === Number(child.pid)) {
          return {
            baseUrl,
            dir,
            out: () => output,
            stop: () => new Promise((resolve) => {
              child.once('exit', resolve);
              child.kill();
              setTimeout(resolve, 3000);
            }),
          };
        }
      } catch { /* 还没起来 */ }
      await new Promise((r) => setTimeout(r, 200));
    }

    if (!lastError) lastError = new Error(`桥未在 20 秒内就绪：\n${output}`);
    child.kill();
    await new Promise((resolve) => {
      if (child.exitCode !== null || child.signalCode) { resolve(); return; }
      child.once('exit', resolve);
      setTimeout(resolve, 3000);
    });
    if (!isPortInUseError(output)) break;
  }

  /*
   * 收尾要**尽力而为**：这里已经在失败路径上了，再让 `rmSync` 抛一个
   * （Windows 上桥刚被 kill、句柄还没释放就是 EPERM）会把真正的病因盖掉 ——
   * 用户看到的是"临时目录删不掉"，而不是"端口撞了 / 桥起不来"。
   */
  try { rmSync(dir, { recursive: true, force: true }); } catch { /* 留给系统清理 */ }
  throw lastError;
}

/**
 * 用**原始 socket** 发一个请求，返回状态码。
 *
 * 为什么不用 `fetch`：**Fetch 规范把 `Host` 列为禁止头**，用它根本发不出去 ——
 * 排查「畸形 Host」时用 `fetch` 只会得到假阴性（第一次就是这么误判的）。
 */
function rawStatus(port, path, headers = {}) {
  return new Promise((resolve, reject) => {
    const req = httpRequest(
      { host: '127.0.0.1', port, path, method: 'GET', headers: { authorization: `Bearer ${TOKEN}`, ...headers } },
      (res) => { res.resume(); res.on('end', () => resolve(res.statusCode)); },
    );
    req.on('error', reject);
    req.end();
  });
}

/**
 * 用 keep-alive agent 发一个请求，返回状态、正文与「是否复用了已有 socket」。
 *
 * `fetch` 走 undici 连接池，无法稳定断言「下一条请求落在同一条 socket 上」；
 * 而 413 漏 `req.resume()` 的故障恰恰只在这条路径上出现。
 */
function agentRequest(agent, port, path, { method = 'POST', body = '' } = {}) {
  return new Promise((resolve, reject) => {
    const req = httpRequest({
      host: '127.0.0.1',
      port,
      path,
      method,
      agent,
      headers: {
        authorization: `Bearer ${TOKEN}`,
        ...(body ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(body) } : {}),
      },
    }, (res) => {
      let text = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => { text += chunk; });
      res.on('end', () => resolve({ status: res.statusCode, body: text, reusedSocket: req.reusedSocket }));
    });
    req.on('error', reject);
    req.end(body);
  });
}

// ── 打桩上游：验证「桥实际发了什么出去」─────────────────────────────────
/**
 * 还没被 `close()` 掉的打桩上游。
 *
 * **这不是洁癖，是防"没有报错的失败"**：用例里普遍是
 *
 *     const stub = await startStubUpstream(...);
 *     const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, ...);
 *     try { ... } finally { await bridge.stop(); await stub.close(); }
 *
 * `startBridge` 在 `try` **之外** —— 它一抛错（实测：端口撞车 EADDRINUSE），
 * `finally` 永远不执行，stub 的 listen socket 就留在测试进程上。
 * `node --test` 会等事件循环清空才退出，于是**全部用例跑完后进程不退**：
 * CI 上表现为 job 跑满 `timeout-minutes` 被 cancel（2026-10-27 实测 20 分钟），
 * 而日志里只有一条早已打印过的失败——看起来像"卡死"，其实是收尾没做。
 *
 * 文件级的 `test.after` 一定会在最后执行（哪怕有模块级异常），兜住这条路。
 */
const openStubs = new Set();

/**
 * 记录收到的每个请求（headers/body），回最小 SSE。
 *
 * 配合 `CODEBUDDY_ENDPOINT` 把桥的出站流量全部导向这里 —— 审计模板改写、
 * 出站身份指纹、限流计数之类的断言都靠它（不触真上游、不耗额度）。
 *
 * @param {string[]} [models] `/v2/enterprises/personal/models` 返回的模型 id
 */
async function startStubUpstream(models = ['stub-model'], opts = {}) {
  const seen = [];
  /** 目录端点收到的请求头（出站身份断言用）。 */
  const catalogSeen = [];
  /** `/v2/plugin/auth/token/refresh` 被调了几次 —— 「并发只刷一次」的用例靠它判定。 */
  let refreshCalls = 0;
  const srv = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      catalogSeen.push({ path, headers: req.headers });
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: {
          models: (opts.emptyModels ? [] : models).map((id) => ({
            id,
            maxInputTokens: 128000,
            maxOutputTokens: 4096,
            ...(Array.isArray(opts.visionModels) && opts.visionModels.includes(id)
              ? { supportsImages: true }
              : {}),
            ...(Array.isArray(opts.nonVisionModels) && opts.nonVisionModels.includes(id)
              ? { supportsImages: false }
              : {}),
          })),
        },
      }));
    }
    /*
     * 刷新端点：给「并发只刷一次」的用例用。
     *
     * **故意慢**（默认 200ms）—— 否则并发请求可能前后错开：第一个刷新完，
     * 第二个才发现令牌已经新鲜，于是「没做单飞」也能凑出 1 次，用例就测不出差异。
     * 慢一点才能让 N 个请求真的同时在飞。
     */
    if (path === '/v2/plugin/auth/token/refresh') {
      refreshCalls += 1;
      const n = refreshCalls;
      setTimeout(() => {
        res.writeHead(200, { 'content-type': 'application/json' });
        res.end(JSON.stringify({
          code: 0,
          data: {
            accessToken: `refreshed-${n}`,
            refreshToken: `rotated-${n}`,
            ...(opts.refreshOmitExpiresIn ? {} : { expiresIn: 3600, refreshExpiresIn: 86400 }),
          },
        }));
      }, opts.refreshDelayMs ?? 200);
      return;
    }
    if (path === '/v3/config') {
      catalogSeen.push({ path, headers: req.headers });
      res.writeHead(200, { 'content-type': 'application/json' });
      /*
       * 默认回空数组：早期用例要的是"v3 空 → 退到 v2"这条路径。
       * `opts.v3Models` 显式给了就照给 —— 「点名清单里有已下架模型」那条
       * 用例需要一份**非空**目录，否则连"在不在目录里"都判断不了。
       */
      const v3Models = Array.isArray(opts.v3Models) && !opts.emptyModels ? opts.v3Models : [];
      return res.end(JSON.stringify({
        code: 0,
        data: {
          models: v3Models.map((id) => ({
            id,
            maxInputTokens: 128000,
            maxOutputTokens: 4096,
          })),
        },
      }));
    }
    if (path === '/v2/chat/completions') {
      let body = '';
      req.on('data', (c) => { body += c; });
      req.on('end', () => {
        seen.push({ headers: req.headers, body });
        /*
         * `opts.chatRaw`：模拟「上游 HTTP 200，但返回的不是 SSE」。
         * 网关把错误包成 200 的 HTML 是真实会发生的（见 BUG-2 的用例）。
         */
        if (opts.chatRaw !== undefined) {
          res.writeHead(opts.chatStatus || 200, { 'content-type': opts.chatType || 'text/html' });
          return res.end(opts.chatRaw);
        }
        /*
         * `chatHang`：只回响应头，永远不写 body、不 end —— 模拟“连接建立了但
         * 上游一直不说话”。首字节超时用例靠它验证不会永久 loading。
         */
        if (opts.chatHang) {
          res.writeHead(200, { 'content-type': 'text/event-stream' });
          res.flushHeaders();
          return;
        }
        /*
         * `opts.chatSequence`：按顺序返回**不同**的响应，用于测「重试若干次后成功」。
         * 每项 `{ status, type, raw }`；用完最后一项后**一直重复它**。
         *
         * 为什么需要它：`chatRaw` 是恒定响应，只能表达「永远失败」，无法表达
         * 「前 2 次 400、第 3 次 200」—— 而后者才是「重试确实救回了请求」的证据。
         */
        if (Array.isArray(opts.chatSequence) && opts.chatSequence.length) {
          const idx = Math.min(seen.length - 1, opts.chatSequence.length - 1);
          const step = opts.chatSequence[idx];
          res.writeHead(step.status || 200, { 'content-type': step.type || 'application/json' });
          return res.end(step.raw ?? '{}');
        }
        /*
         * `opts.chatSse`：按顺序逐条写出给定的 SSE 原始块（每项已含 `data: ...\n\n`）。
         * 用于验证「桥对流式帧做了什么改写」—— 例如逐字符 reasoning 的分片下发。
         */
        if (Array.isArray(opts.chatSse)) {
          res.writeHead(200, { 'content-type': 'text/event-stream' });
          for (const block of opts.chatSse) res.write(block);
          return res.end();
        }
        res.writeHead(200, { 'content-type': 'text/event-stream' });
        res.write('data: {"choices":[{"delta":{"content":"ok"}}]}\n\n');
        res.write('data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4}}\n\n');
        res.end('data: [DONE]\n\n');
      });
      return;
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  /*
   * `close()` 必须自己收尾干净：`srv.close()` 只是"不再接受新连接"，
   * 已有 keep-alive 连接上的桥进程（失败路径里它可能还活着）会让回调**永远不来**。
   * 那等于把"进程不退"从一个地方挪到另一个地方。所以先掐连接，再带超时兜底。
   */
  const close = () => new Promise((r) => {
    const done = () => { clearTimeout(timer); r(); };
    const timer = setTimeout(done, 3000);
    if (typeof srv.closeAllConnections === 'function') srv.closeAllConnections();
    srv.close(done);
  });
  openStubs.add(close);
  return {
    base: `http://127.0.0.1:${srv.address().port}`,
    seen,
    catalogSeen,
    opts,
    get refreshCalls() { return refreshCalls; },
    close: async () => { openStubs.delete(close); await close(); },
  };
}

/*
 * 收尾兜底：把没关掉的打桩上游关掉。
 *
 * 正常情况下每个用例的 finally 已经关干净了，这里是 0 成本的空转；
 * 只有当某个用例在 `try` 之前就抛错（startBridge 起不来、断言写在 try 外）
 * 时才会真正动起来。见 `openStubs` 的注释：没有这一步，漏掉的 listen socket
 * 会让 `node --test` 跑完不退出，CI 上表现为 20 分钟后 job 被 cancel。
 */
test.after(async () => {
  for (const close of openStubs) {
    try { await close(); } catch { /* 已经关掉了 */ }
  }
  openStubs.clear();
});

const auth = { authorization: `Bearer ${TOKEN}` };

test('桥：端点契约 —— 鉴权、身份、模型目录形状', { timeout: 90_000 }, async () => {
  const bridge = await startBridge();
  try {
    // ① 无令牌 → 401（本地端口默认要求令牌）
    const noAuth = await fetch(bridge.baseUrl + '/v1/models');
    assert.equal(noAuth.status, 401, '没有 Authorization 时必须是 401');

    // ② 错令牌 → 401
    const badAuth = await fetch(bridge.baseUrl + '/v1/models', { headers: { authorization: 'Bearer wrong' } });
    assert.equal(badAuth.status, 401);

    // ③ 身份端点：给插件/控制台用来确认"端口上的确实是我们"
    const root = await (await fetch(bridge.baseUrl + '/', { headers: auth })).json();
    assert.ok(root.name || root.service || root.version, 'GET / 必须能自报名号');
    assert.match(JSON.stringify(root), /workbuddy/i, '身份信息里应当有 workbuddy 字样');

    // ④ 模型目录：OpenAI 兼容形状（object/data + 每项 id）
    const modelsRes = await fetch(bridge.baseUrl + '/v1/models', { headers: auth });
    assert.equal(modelsRes.status, 200);
    const models = await modelsRes.json();
    assert.ok(Array.isArray(models.data), '/v1/models 必须返回 {data: [...]}（OpenAI 兼容）');
    assert.ok(models.data.length > 0, '假凭据下也应当有内置的模型目录（不依赖上游）');
    for (const m of models.data) {
      assert.equal(typeof m.id, 'string', '每个模型必须有字符串 id');
      assert.ok(m.id.length > 0);
    }

    // ⑤ 计数类端点必须是"不需要上游就能答"的：不能挂
    for (const endpoint of ['/v1/usage', '/v1/requests']) {
      const res = await fetch(bridge.baseUrl + endpoint, { headers: auth, signal: AbortSignal.timeout(8000) });
      assert.equal(res.status, 200, `${endpoint} 应当直接 200（本地账本，不需要上游）`);
      const body = await res.json();
      assert.equal(typeof body, 'object');
    }

    // ⑥ 未知路径 → 404，且是 JSON（不是 HTML 错误页）
    const missing = await fetch(bridge.baseUrl + '/nope', { headers: auth });
    assert.equal(missing.status, 404);
    assert.match(missing.headers.get('content-type') || '', /json/, '错误也必须是 JSON，调用方才能解析');
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：账本是本地文件，且不写使用者的那份', { timeout: 90_000 }, async () => {
  const bridge = await startBridge();
  try {
    const usage = await (await fetch(bridge.baseUrl + '/v1/usage', { headers: auth })).json();
    assert.equal(typeof usage, 'object');
    // 临时目录里应当出现（或可创建）账本文件；关键是**工作目录隔离**
    const localLedger = join(bridge.dir, 'usage.jsonl');
    const repoLedger = join(REPO, 'bridge', 'usage.jsonl');
    /*
     * ⚠️ 判据不能是「仓库账本字节数前后相等」。
     *
     * 那份账本属于**正在运行的真实桥**：开发者本机跑用例时，任何并发请求
     * （控制台轮询、另一个终端里的对话、甚至 CI 之外的实测脚本）都会往里追加一行，
     * 于是这条断言会**误报**成"测试改到了使用者的账本"。
     * 实测踩过：并发跑基准脚本时它报 `223443 !== 222905` —— 差的 538 字节
     * 正好是一条真实请求的账本行，与本次 DELETE 毫无关系。
     *
     * 换成对**本用例动作**真正敏感、且对并发追加免疫的判据：
     *   · DELETE 会把整份文件**清空**，所以"非空 → 空"是它造成的铁证；
     *   · 追加**永远不会改首行**，而清空/截断一定会 —— 所以首行是可靠指纹。
     * 这样"测试真的写坏了使用者账本"照旧会被抓住，并发流量则不再误报。
     */
    const repoLedgerBefore = existsSync(repoLedger) ? readFileSync(repoLedger, 'utf8') : '';
    const firstLineBefore = repoLedgerBefore.split('\n')[0] ?? '';

    // 触发一次"清空账本"（不需要上游）
    const cleared = await fetch(bridge.baseUrl + '/v1/usage', { method: 'DELETE', headers: auth });
    assert.ok([200, 204].includes(cleared.status), `清空账本应当成功，实际 ${cleared.status}`);

    const repoLedgerAfter = existsSync(repoLedger) ? readFileSync(repoLedger, 'utf8') : '';
    const firstLineAfter = repoLedgerAfter.split('\n')[0] ?? '';
    assert.ok(!(repoLedgerBefore.length > 0 && repoLedgerAfter.length === 0),
      '测试绝不能把使用者的真实账本清空');
    assert.equal(firstLineAfter, firstLineBefore,
      '测试绝不能改动使用者真实账本的内容（首行指纹变了 = 被清空/截断/重写了）');

    /*
     * 反证隔离真的生效：被清空的是**测试桥自己**那份（temp 目录里）。
     * 少了这一条，"两边都没动"也能让上面的断言通过 —— 那就成了空转用例。
     */
    assert.ok(existsSync(localLedger), `测试桥的账本应当落在临时目录：${localLedger}`);

    // 清空后仍可读，且是空账本
    const after = await (await fetch(bridge.baseUrl + '/v1/usage', { headers: auth })).json();
    const total = after.total || after.usage?.total || {};
    assert.ok((total.calls || 0) === 0, '清空后调用数应为 0');
    assert.ok(localLedger === join(bridge.dir, 'usage.jsonl'));
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：无凭据时 /health 如实报 503 并带上原因（插件据此判"凭据异常"）', { timeout: 90_000 }, async () => {
  // 故意指向一个不存在的登录文件：模拟"WorkBuddy 没登录/登录文件被删"
  const bridge = await startBridge({ WORKBUDDY_AUTH_FILE: 'C:\\definitely\\missing\\auth.info' });
  try {
    const res = await fetch(bridge.baseUrl + '/health', { headers: auth, signal: AbortSignal.timeout(8000) });
    assert.equal(res.status, 503, '读不出凭据时 /health 必须是 503（不是 200，也不能崩）');
    const body = await res.json();
    assert.equal(body.ok, false);
    assert.ok(body.error, '必须给出原因，调用方才能显示给用户');
    assert.ok(body.authFile, '必须回带它尝试读的登录文件路径（便于排查）');
    // 关键：进程还活着，且其它端点仍可用（不是整个桥挂掉）
    assert.equal((await fetch(bridge.baseUrl + '/', { headers: auth })).status, 200, '凭据坏了也应当能自报名号');
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：超大请求体必须是 413 JSON，且桥仍然可用（D2）', { timeout: 90_000 }, async () => {
  // 把上限压到 64KB，这样才能用一个几 MB 的 body 稳定触发它 —— 真按 32MB 默认值
  // 测，就得在测试里造 32MB 的字符串（慢、吃内存），而这里验的是**拒绝逻辑**，
  // 不是那个具体数值。上限可配正是为这种场景留的。
  const bridge = await startBridge({ WORKBUDDY_MAX_BODY_BYTES: String(64 * 1024) });
  try {
    // 一个远超上限的 body：桥会在读到 64KB 时就判定超限、停止消费，并回 413。
    // 注意这里**必须**断言拿到的是 413 而不仅仅是"连接断了" —— 早期实现在
    // readBody 里直接 req.destroy()，客户端只会收到 ECONNRESET，413 根本发不
    // 出来。这正是本用例要钉住的行为。
    const oversized = 'x'.repeat(256 * 1024);
    const body = JSON.stringify({ model: 'deepseek-v4.1-flash', messages: [{ role: 'user', content: oversized }] });

    let status = 0;
    let payload = null;
    let contentType = '';
    try {
      const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
        method: 'POST',
        headers: { ...auth, 'content-type': 'application/json' },
        body,
        signal: AbortSignal.timeout(15000),
      });
      status = res.status;
      contentType = res.headers.get('content-type') || '';
      payload = await res.json().catch(() => null);
    } catch (e) {
      // 连接被掐断（ECONNRESET）说明 413 没发出来 —— 契约要求的是明确的
      // 413 JSON，所以这里直接判失败，而不是"连接异常也算过"。
      assert.fail(`超大 body 应当拿到 413 JSON 响应，实际连接异常：${e.message}`);
    }

    assert.equal(status, 413, `超大 body 必须是 413，实际 ${status}`);
    assert.match(contentType, /json/, '413 也必须是 JSON（调用方才能解析）');
    assert.ok(payload?.error?.message, '413 必须带可读的错误说明');
    assert.match(payload.error.message, /too large|limit/i, '错误信息要说明是"太大"而不是别的');

    // 关键：拒绝一次超大请求之后，桥自己必须还活着（不是被那个 body 打崩）
    const stillUp = await fetch(bridge.baseUrl + '/', { headers: auth, signal: AbortSignal.timeout(8000) });
    assert.equal(stillUp.status, 200, '拒绝超大 body 之后桥必须仍然可用');

    // 回归：**大 body 下的 413 不能变成 ECONNRESET**。
    // 早期实现在 413 分支里 destroy()，客户端还没读到响应就被 RST 掉 ——
    // 实测 8MB 时 10/10 丢失。修法是回完 413 后 req.resume() 把剩余字节读掉。
    // 这里用 8MB（远超 64KB 上限）连打 3 次，每次都必须拿到 413。
    const big = JSON.stringify({
      model: 'deepseek-v4.1-flash',
      messages: [{ role: 'user', content: 'y'.repeat(8 * 1024 * 1024) }],
    });
    for (let i = 0; i < 3; i += 1) {
      let bigStatus = 0;
      try {
        const r = await fetch(bridge.baseUrl + '/v1/chat/completions', {
          method: 'POST',
          headers: { ...auth, 'content-type': 'application/json' },
          body: big,
          signal: AbortSignal.timeout(20000),
        });
        bigStatus = r.status;
        await r.arrayBuffer().catch(() => {});
      } catch (e) {
        assert.fail(`第 ${i + 1} 次 8MB 请求应当拿到 413，实际连接异常：${e.message}`);
      }
      assert.equal(bigStatus, 413, `第 ${i + 1} 次 8MB 请求必须是 413（不能被 RST 吞掉）`);
    }
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：413 后同一条 keep-alive 连接仍可复用（count_tokens / responses）', { timeout: 60_000 }, async () => {
  /*
   * 回归背景：`readBody` 超限时只 pause、不丢字节；413 写完后漏掉
   * `req.resume()` 的端点会让 socket 停在暂停状态。下一条复用同一连接的
   * 请求要么挂住、要么 ECONNRESET。`/v1/responses` 与
   * `/v1/messages/count_tokens` 都曾漏过这一行。
   */
  const bridge = await startBridge({ WORKBUDDY_MAX_BODY_BYTES: String(64 * 1024) });
  const agent = new HttpAgent({ keepAlive: true, maxSockets: 1 });
  try {
    const port = Number(new URL(bridge.baseUrl).port);
    const big = JSON.stringify({
      model: 'x',
      messages: [{ role: 'user', content: 'z'.repeat(256 * 1024) }],
    });
    const cases = [
      ['/v1/messages/count_tokens', 'request_too_large'],
      ['/v1/responses', 'payload_too_large'],
    ];
    for (const [path, errorType] of cases) {
      const first = await agentRequest(agent, port, path, { body: big });
      assert.equal(first.status, 413, `${path} 超限必须是 413`);
      const payload = JSON.parse(first.body);
      assert.equal(payload?.error?.type, errorType, `${path} 的错误形状必须符合协议`);
      const second = await agentRequest(agent, port, '/', { method: 'GET' });
      assert.equal(second.status, 200, `${path} 拒绝后桥必须仍可用`);
      assert.equal(second.reusedSocket, true, `${path} 的 413 必须让同一条 socket 可复用`);
    }
  } finally {
    agent.destroy();
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('目录补全：国际版漏列的模型必须带上**实测过的**视觉 / 推理标记（2026-10-12 用户反馈）', { timeout: 90_000 }, async () => {
  /*
   * 现场：国际版网关能调 `deepseek-v4.1-flash`，但**任何一个目录端点里都没有它**
   * → 桥用 FEATURED 补全 → 补全项原先不带任何能力字段 → dsh 把它显示成
   * 「纯文本、不支持推理」，用户点思考强度直接被拒：
   *   session/model-unavailable: model "deepseek-v4.1-flash" does not support reasoning effort "high"
   *
   * 真实能力是**实测过**的（1×1 红点图答出颜色；reasoning_effort 五档全 200，
   * 见 tools/dev/probe-capability.mjs / probe-effort.mjs），所以补全必须把它们带上。
   *
   * 同时钉住区域过滤：`deepseek-v4-pro` 在国际版实测 400
   * （`model [...] service info not found`），不能补进去当死条目。
   */
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      // 故意只给 glm-5.3：两个 deepseek 都不在目录里（国际版的真实形状）
      return res.end(JSON.stringify({
        code: 0,
        data: {
          models: [{
            id: 'glm-5.3', name: 'GLM-5.3', maxInputTokens: 1000000, maxOutputTokens: 48000,
            supportsImages: true, supportsReasoning: true, credits: 'x0.79',
          }],
        },
      }));
    }
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;

  // 国际版凭据：域名为 workbuddy.ai（区域判定看**登录域名**，不看 endpoint —— 
  // CODEBUDDY_ENDPOINT 只是把出站流量导向桩）
  const intlAuth = {
    auth: {
      accessToken: 'fake-access-token',
      refreshToken: 'fake-refresh-token',
      domain: 'workbuddy.ai',
      expiresAt: Date.now() + 30 * 86_400_000,
    },
  };
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: upstreamBase }, { auth: intlAuth });
  try {
    const models = await (await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth })).json();
    const flash = models.data.find((m) => m.id === 'deepseek-v4.1-flash');
    assert.ok(flash, `国际版目录缺它时，精选补全必须列出来。实际：${models.data.map((m) => m.id).join(',')}`);
    assert.equal(flash.supports_images, true, '实测视觉可用 → 补全项必须声明 supports_images');
    assert.equal(flash.supports_reasoning, true, '实测接受 reasoning_effort → 补全项必须声明 supports_reasoning');
    assert.equal(flash.context_window, 1000000, '上下文窗口照精选定义（1M）');

    // 上游真给了的模型：能力标记用上游的（不被精选定义覆盖）
    const glm = models.data.find((m) => m.id === 'glm-5.3');
    assert.equal(glm.supports_reasoning, true, '目录里有的模型，标记来自上游');

    // 区域过滤：国际版不提供 v4-pro（实测 400），不能出现在列表里
    assert.ok(
      !models.data.some((m) => m.id === 'deepseek-v4-pro'),
      '国际版不得补出 deepseek-v4-pro —— 那个区域实测 400（service info not found）',
    );

    // 默认视图（不带 all=1）走的是 pickFeatured 那条路，同样要带能力标记
    const def = await (await fetch(bridge.baseUrl + '/v1/models', { headers: auth })).json();
    const flashDef = def.data.find((m) => m.id === 'deepseek-v4.1-flash');
    assert.ok(flashDef, '默认视图也要列出精选模型');
    assert.equal(flashDef.supports_images, true, '默认视图同样要带视觉标记（原先只在补全路径里修是不够的）');
    assert.equal(flashDef.supports_reasoning, true, '默认视图同样要带推理标记');
    assert.ok(
      !def.data.some((m) => m.id === 'deepseek-v4-pro'),
      '默认视图同样要过区域过滤：国际版不该出现 v4-pro',
    );
  } finally { await bridge.stop(); upstream.close(); }
});

test('/v1/models：默认视图的规模可由面板保存（改完立即生效，不需要重启桥）', { timeout: 90_000 }, async () => {
  /*
   * 2026-10-26 反馈：「为什么只出现三个？」
   *
   * 客户端的「获取模型列表 / 一键同步」按钮打的是**不带参数**的 `/v1/models`，
   * 而那里默认只回精选。这条用例钉四件事：
   *   1. 默认仍是精选（老行为不变 —— 不能因为加开关就悄悄改默认）；
   *   2. 面板保存 `all` → 同一个地址立刻回全量（**不重启桥**）；
   *   3. 保存数字 N → 精选在前、补齐到 N；
   *   4. `?limit=N` 是请求级覆盖，不需要保存任何东西。
   */
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: {
          models: [
            { id: 'glm-5.3', name: 'GLM-5.3', maxInputTokens: 1000000, maxOutputTokens: 48000 },
            { id: 'm-only-a', name: 'A', maxInputTokens: 1000, maxOutputTokens: 100 },
            { id: 'm-only-b', name: 'B', maxInputTokens: 1000, maxOutputTokens: 100 },
            { id: 'm-only-c', name: 'C', maxInputTokens: 1000, maxOutputTokens: 100 },
            { id: 'm-only-d', name: 'D', maxInputTokens: 1000, maxOutputTokens: 100 },
          ],
        },
      }));
    }
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;

  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: upstreamBase }, { auth: READABLE_FAKE_AUTH });
  const getModels = async (qs = '') => (await fetch(`${bridge.baseUrl}/v1/models${qs}`, { headers: auth })).json();
  // 传对象 = 直接当请求体（`{ ids: [...] }`）；其余 = `{ value }`
  const saveDefault = async (value) => {
    const r = await fetch(`${bridge.baseUrl}/v1/models/default`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify(value && typeof value === 'object' ? value : { value }),
    });
    return { status: r.status, body: await r.json() };
  };
  try {
    // ① 默认不变：还是精选那几个
    const before = await getModels();
    assert.deepEqual(
      before.data.map((m) => m.id).sort(),
      ['deepseek-v4-pro', 'deepseek-v4.1-flash', 'glm-5.3'],
      '不配置时默认视图必须仍是 3 个精选（这是既有行为，不能被开关改掉）',
    );

    // ② 保存 all → 立即全量
    const allSaved = await saveDefault('all');
    assert.equal(allSaved.status, 200, `保存 all 应当成功：${JSON.stringify(allSaved.body)}`);
    assert.equal(allSaved.body.mode, 'all');
    const afterAll = await getModels();
    assert.ok(
      afterAll.data.length > before.data.length,
      `保存 all 后默认视图必须放大（之前 ${before.data.length} 个，现在 ${afterAll.data.length} 个）`,
    );
    assert.ok(
      afterAll.data.some((m) => m.id === 'm-only-a'),
      '保存 all 后，只在上游目录里的模型也必须出现在默认视图',
    );

    // ③ 保存数字 N → 精选在前，补齐到 N
    const nSaved = await saveDefault(4);
    assert.equal(nSaved.status, 200);
    const afterN = await getModels();
    assert.equal(afterN.data.length, 4, '保存 4 之后默认视图就给 4 个');
    assert.equal(afterN.data[0].id, 'deepseek-v4.1-flash', '精选排在前面（顺序不能被打乱）');

    // ④ ?limit=N 是请求级覆盖：不用保存、也不改已保存的值
    const limited = await getModels('?limit=2');
    assert.equal(limited.data.length, 2, '?limit=2 必须只回 2 个');
    assert.equal((await getModels()).data.length, 4, '请求级 limit 不能污染已保存的默认值');

    // ⑤ 清掉保存的偏好 → 回落到内建精选
    const cleared = await saveDefault(null);
    assert.equal(cleared.status, 200);
    assert.equal(cleared.body.mode, 'curated', '清空后必须回落到 curated');
    assert.equal((await getModels()).data.length, 3, '清空后默认视图回到 3 个精选');

    // ⑥ 非法值明确拒绝，而不是静默回退
    const bad = await saveDefault('十几个');
    assert.equal(bad.status, 400, '不认识的取值必须 400（静默回退会让面板显示与实际不符）');

    // ⑦ 「只给这几个」：按名字点名，顺序按提交顺序（也就是客户端列表的顺序）
    const idsSaved = await saveDefault({ ids: ['m-only-c', 'glm-5.3'] });
    assert.equal(idsSaved.status, 200, `保存 ids 应当成功：${JSON.stringify(idsSaved.body)}`);
    const afterIds = await getModels();
    assert.deepEqual(
      afterIds.data.map((m) => m.id),
      ['m-only-c', 'glm-5.3'],
      'ids 模式必须**只**给点名的那几个，且保持提交顺序',
    );

    // ⑧ 点名清单与目录求交集：下架的模型不该继续冒充可用
    await saveDefault({ ids: ['m-only-c', 'no-such-model'] });
    const intersect = await getModels();
    assert.deepEqual(intersect.data.map((m) => m.id), ['m-only-c'], '不在目录里的 id 不下发');

    // ⑨ 空清单 / 全是非法 id → 400（否则会存出一份"什么都拉不到"的设置）
    assert.equal((await saveDefault({ ids: [] })).status, 400, '空 ids 必须 400');
    assert.equal((await saveDefault({ ids: ['模型-中文名'] })).status, 400, '非 ASCII 的 id 必须 400');
  } finally { await bridge.stop(); upstream.close(); }
});

test('目录补全：国内版仍会补 deepseek-v4-pro（region 过滤只挡"该区域不提供"的）', { timeout: 90_000 }, async () => {
  // 与上一条互补：区域过滤不能把国内版的兜底一起挡掉。
  // 凭据用默认的 example.invalid 域 → pickUpstream 落到国内端点。
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [{ id: 'cn-model', maxInputTokens: 1000, maxOutputTokens: 100 }] } }));
    }
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;

  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: upstreamBase }, { auth: READABLE_FAKE_AUTH });
  try {
    const models = await (await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth })).json();
    const ids = models.data.map((m) => m.id);
    assert.ok(ids.includes('deepseek-v4-pro'), `国内版应当照旧补出 deepseek-v4-pro。实际：${ids.join(',')}`);
    assert.ok(ids.includes('deepseek-v4.1-flash'), '精选里的全区域模型照旧补出');
  } finally { await bridge.stop(); upstream.close(); }
});

test('/v1/models：每模型给出**实测过**的 reasoning_efforts 档位（写死三档的旧做法）', { timeout: 90_000 }, async () => {
  /*
   * 2026-10-12 用户反馈："每个模型只有三个档"，而上游对支持推理的模型其实收
   * minimal/low/medium/high（多数模型还收 xhigh/max，少数连 minimal/max 都不收）。
   * 目录里没有任何字段说"接受哪几档"，所以桥按**实测表**（REASONING_EFFORTS_BY_MODEL）给。
   *
   * 这条用例钉五件事：
   *   1. 有实测覆盖的模型给覆盖表里的档位（含 xhigh）；
   *   2. 没有覆盖的模型给默认三档（**不含 xhigh/minimal/max** —— 实测里这三个
   *      都有模型不收，未测模型不能赌）；
   *   3. 目录没说支持推理的模型**完全没有** reasoning_efforts 字段；
   *   4. 显式空数组（实测一个档都不收，如网关暂时不接的 claude-* / glm-5.0）
   *      → 同样不出字段，插件会因此不声明推理；
   *   5. 国内版 2026-10-12 实测并进来的 id 同样按表给（auto 全档 / glm-5.0 空数组）。
   */
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: {
          models: [
            { id: 'glm-5.3', name: 'GLM-5.3', maxInputTokens: 1000000, maxOutputTokens: 48000, supportsReasoning: true, supportsImages: true },
            { id: 'gemini-3.5-flash', name: 'Gemini 3.5 Flash', maxInputTokens: 1000000, maxOutputTokens: 65536, supportsReasoning: true, supportsImages: true },
            { id: 'claude-haiku-4.5', name: 'Claude Haiku 4.5', maxInputTokens: 176000, maxOutputTokens: 24000, supportsReasoning: true, supportsImages: true },
            { id: 'auto', name: 'Auto', maxInputTokens: 1000000, maxOutputTokens: 48000, supportsReasoning: true },
            { id: 'glm-5.0', name: 'GLM-5.0', maxInputTokens: 1000000, maxOutputTokens: 48000, supportsReasoning: true },
            { id: 'stub-reasoner', name: 'Stub Reasoner', maxInputTokens: 1000, maxOutputTokens: 100, supportsReasoning: true },
            { id: 'plain-1', name: 'Plain', maxInputTokens: 1000, maxOutputTokens: 100 },
          ],
        },
      }));
    }
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;

  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: upstreamBase }, { auth: READABLE_FAKE_AUTH });
  try {
    const models = await (await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth })).json();
    const byId = new Map(models.data.map((m) => [m.id, m]));

    // ① 实测覆盖表里的模型：连 xhigh 一起给
    assert.deepEqual(
      byId.get('glm-5.3').reasoning_efforts,
      ['minimal', 'low', 'medium', 'high', 'xhigh', 'max'],
      'glm-5.3 实测连 xhigh 都收 —— 档位必须按实测表给，不能写死三档',
    );
    // ② 没有覆盖的模型：默认三档，**不含** xhigh/minimal/max（实测都有模型不收）
    assert.deepEqual(
      byId.get('stub-reasoner').reasoning_efforts,
      ['low', 'medium', 'high'],
      '没有实测覆盖的模型用默认三档；未测的档不能赌',
    );
    // ②b 国内版实测并进来的 id：auto 全档 / glm-5.0 对照 400 → 显式空数组
    assert.deepEqual(
      byId.get('auto').reasoning_efforts,
      ['minimal', 'low', 'medium', 'high', 'xhigh', 'max'],
      '国内版实测全档的模型（auto）必须给全 6 档',
    );
    assert.deepEqual(
      byId.get('glm-5.0').reasoning_efforts,
      [],
      '国内版目录在列但网关不接（glm-5.0 对照 400 service info not found）→ 空数组',
    );
    // ③ 目录没说支持推理的模型：一个档位字段都不该有
    assert.equal(byId.get('plain-1').supports_reasoning, undefined, 'plain-1 不声明推理');
    assert.equal(byId.get('plain-1').reasoning_efforts, undefined, '不声明推理就没有档位字段');
    // ④ 显式空数组（实测一个档都不收）→ 同样不出字段
    assert.deepEqual(
      byId.get('claude-haiku-4.5').reasoning_efforts,
      [],
      'claude-* 网关当前不接，实测表里是显式空数组',
    );

    // ④b 客户端字段别名与能力：不同客户端读不同名字，值必须同源。
    const glm = byId.get('glm-5.3');
    assert.equal(glm.context_length, 1000000, 'context_length 必须与 context_window 同源');
    assert.equal(glm.max_input_tokens, 1000000);
    assert.equal(glm.max_tokens, 48000);
    assert.deepEqual(glm.capabilities, { vision: true, tools: true, reasoning: true });
    assert.deepEqual(glm.architecture, { input_modalities: ['text', 'image'] });
    const plain = byId.get('plain-1');
    assert.deepEqual(plain.capabilities, { vision: false, tools: true, reasoning: false });
    assert.deepEqual(plain.architecture, { input_modalities: ['text'] });

    // ⑤ 补全进来的模型同样要有档位（FEATURED 的 deepseek-v4.1-flash 实测过）
    const flash = models.data.find((m) => m.id === 'deepseek-v4.1-flash');
    assert.ok(flash, '补全模型要在列表里');
    assert.deepEqual(
      flash.reasoning_efforts,
      ['minimal', 'low', 'medium', 'high', 'xhigh', 'max'],
      '补全进来的模型也要带档位 —— 否则 dsh 里它还是没有思考强度可选',
    );
  } finally { await bridge.stop(); upstream.close(); }
});

test('/v1/models：对齐官方 GUI 清单，并直取 supportedEfforts / contextWindow', { timeout: 90_000 }, async () => {
  /*
   * issue #5：插件列表比 WorkBuddy 官方多、档位也比官方多。
   * 根因是桥只读 `/v2/.../models` 全量并把档位写死在本地实测表；官方 GUI
   * 用的是 `/v3/config` 的 models + agents[]，且目录本身就带
   * `reasoning.supportedEfforts` 与 `contextWindow.supportedLengths`。
   * 本用例钉住：官方清单标注、档位来源、上下文档位、以及显式覆盖。
   */
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: {
          models: [
            // v2 的薄条目：档位表在 v3，但 defaultEffort/canDisableThinking 只在这里
            {
              id: 'glm-5.3', name: 'GLM 5.3', maxInputTokens: 1000000, maxOutputTokens: 64000,
              supportsReasoning: true, supportsToolCall: true,
              reasoning: { defaultEffort: 'high', canDisableThinking: true },
              contextWindow: { defaultLength: 300000 },
            },
            // 只在 v2 出现 = 官方目录外
            { id: 'old-model', name: 'Old Model', maxInputTokens: 64000, maxOutputTokens: 8192, supportsReasoning: true, supportsToolCall: true, reasoning: { supportedEfforts: ['low', 'high'] } },
            // v2 单独挂 chat 标签：官方 GUI 也认，必须算 official
            { id: 'chat-only', name: 'Chat Only', maxInputTokens: 64000, maxOutputTokens: 8192, supportsToolCall: true, tags: ['chat'] },
            // 支持推理但上游没给档位表、也没有实测记录 → 默认三档，来源必须标 fallback
            { id: 'fallback-efforts', name: 'Fallback Efforts', maxInputTokens: 64000, maxOutputTokens: 8192, supportsReasoning: true, supportsToolCall: true },
          ],
        },
      }));
    }
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: {
          models: [
            {
              id: 'glm-5.3', name: 'GLM-5.3', maxInputTokens: 1000000, maxOutputTokens: 131072,
              supportsReasoning: true, onlyReasoning: true, supportsToolCall: true, tags: ['craft'],
              temperature: 0.7,
              reasoning: { supportedEfforts: ['low', 'high', 'max'] },
              contextWindow: { supportedLengths: [1000000, 300000, 600000] },
            },
            // 产品目录里有、但不在会话 agent 的 models 里 = 官方选择器不列
            {
              id: 'memory-model', name: 'Memory Model', maxInputTokens: 128000, maxOutputTokens: 8192,
              supportsToolCall: true,
            },
          ],
          agents: [{ name: 'craft', models: ['glm-5.3'] }],
        },
      }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;

  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: upstreamBase, WORKBUDDY_CONTEXT_WINDOW: '600000' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const payload = await (await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth })).json();
    const byId = new Map(payload.data.map((m) => [m.id, m]));
    const glm = byId.get('glm-5.3');
    assert.equal(glm.official, true, '官方 craft agent 的模型必须标 official=true');
    assert.deepEqual(glm.reasoning_efforts, ['low', 'high', 'max'], '档位必须直取上游 supportedEfforts（低/高/极致）');
    assert.equal(glm.default_reasoning_effort, 'high');
    assert.equal(glm.reasoning_efforts_source, 'upstream');
    assert.equal(glm.context_window, 600000, 'WORKBUDDY_CONTEXT_WINDOW 显式覆盖生效，且不能超过模型上限');
    assert.equal(glm.context_window_default, 300000);
    assert.deepEqual(glm.context_window_options, [300000, 600000, 1000000], '上下文档位排序去重后原样给出');
    assert.equal(glm.context_window_max, 1000000);
    assert.equal(glm.default_temperature, 0.7, '官方目录里的 temperature 必须原样透出，供面板显示默认值');
    assert.equal(glm.can_disable_thinking, true);

    const fallbackEfforts = byId.get('fallback-efforts');
    assert.deepEqual(fallbackEfforts.reasoning_efforts, ['low', 'medium', 'high'],
      '上游没给档位表、也没实测记录时用默认三档');
    assert.equal(fallbackEfforts.reasoning_efforts_source, 'fallback',
      '默认三档不能冒充"实测"；来源必须可分辨');

    const old = byId.get('old-model');
    assert.equal(old.official, false, '只在 /v2 出现的模型必须标 official=false');
    assert.deepEqual(old.reasoning_efforts, ['low', 'high'], 'v2 自带 supportedEfforts 时同样优先采用');

    const chatOnly = byId.get('chat-only');
    assert.equal(chatOnly.official, true, 'v2 单独带 chat 标签的模型也算官方可选');

    const mem = byId.get('memory-model');
    assert.equal(mem.official, false, '产品目录里但不在会话 agent 清单里的模型不算官方可选');
  } finally { await bridge.stop(); upstream.close(); }
});

test('目录：上游返回空数组时不能顶掉已有目录（否则模型只剩精选几条）', { timeout: 60_000 }, async () => {
  const stub = await startStubUpstream(['stub-model']);
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    const first = await (await fetch(`${bridge.baseUrl}/v1/models?all=1&refresh=1`, { headers: auth })).json();
    assert.ok(first.data.some((m) => m.id === 'stub-model'), '第一次刷新应拿到上游目录');

    // 上游这次两个端点都回 200 + models: []（区域故障/灰度期会出现）
    stub.opts.emptyModels = true;
    const second = await (await fetch(`${bridge.baseUrl}/v1/models?all=1&refresh=1`, { headers: auth })).json();
    assert.ok(second.data.some((m) => m.id === 'stub-model'),
      '空数组是"这次没给"，不能当成成功并顶掉已有目录');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('目录：v3 成功后 v2 的单端点 401 不得触发刷新/换号（否则目录永远建不起来）', { timeout: 90_000 }, async () => {
  let refreshCalls = 0;
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: {
          models: [{ id: 'workbuddy-cn-model', name: 'CN', maxInputTokens: 300000, maxOutputTokens: 64000, supportsToolCall: true }],
          agents: [{ name: 'craft', models: ['workbuddy-cn-model'] }],
        },
      }));
    }
    if (path === '/v2/enterprises/personal/models') {
      // 部分 workbuddy.cn 账号这个端点单独 401，但 v3 正常
      res.writeHead(401, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 401, msg: 'unauthorized' }));
    }
    if (path === '/v2/plugin/auth/token/refresh') {
      refreshCalls += 1;
      res.writeHead(400, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 10001, msg: 'refreshToken is empty' }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: upstreamBase }, { auth: READABLE_FAKE_AUTH });
  try {
    const models = await (await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth })).json();
    assert.ok(models.data.some((m) => m.id === 'workbuddy-cn-model'), 'v3 目录必须保留');
    assert.equal(refreshCalls, 0, '已有端点成功时不得因为另一端点 401 去刷新令牌');
    const health = await (await fetch(bridge.baseUrl + '/health', { headers: auth })).json();
    assert.match(String(health.upstreamShape?.sources?.['/v2/enterprises/personal/models']), /ignored/,
      '诊断里要能看出 v2 的 401 被跳过，而不是被当成令牌过期');
  } finally { await bridge.stop(); upstream.close(); }
});

test('用量：days 窗口按本地零点对齐（不能多算半截"昨天"）', { timeout: 60_000 }, async () => {
  const bridge = await startBridge({}, { auth: READABLE_FAKE_AUTH });
  try {
    const now = Date.now();
    const startOfToday = (() => { const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); })();
    const yesterdayLate = startOfToday - 30 * 60 * 1000; // 昨天 23:30
    const todayEarly = Math.min(startOfToday + 1000, now);
    const row = (t, model, ok = true) => JSON.stringify({
      t, model, ok, promptTokens: 1, completionTokens: 1, ms: 5, status: ok ? 200 : 500,
      ...(ok ? {} : { error: 'boom' }),
    });
    writeFileSync(join(bridge.dir, 'usage.jsonl'), [
      row(yesterdayLate, 'yesterday-model'),
      // 失败行在成功行之前：旧实现会把它丢掉，模型 failed 显示 0
      row(todayEarly, 'today-model', false),
      row(todayEarly + 1, 'today-model'),
    ].join('\n') + '\n');

    const usage = await (await fetch(`${bridge.baseUrl}/v1/usage?days=1`, { headers: auth })).json();
    assert.equal(usage.total.calls, 1, 'days=1 只能统计今天，昨天 23:30 的尾巴不能算进来');
    assert.equal(usage.days.length, 1, `days=1 只能有一个日桶，实际 ${JSON.stringify(usage.days.map((d) => d.day))}`);
    assert.equal(usage.days[0].calls, 1);
    const todayModel = usage.models.find((m) => m.model === 'today-model');
    assert.equal(todayModel.calls, 1);
    assert.equal(todayModel.failed, 1, '失败早于成功时也必须计数（否则成功率虚高）');
    const d = new Date(todayEarly);
    const p = (n) => String(n).padStart(2, '0');
    assert.equal(usage.days[0].day, `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`,
      '桶必须是本地日期');
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('账本：体检请求要标 probe，面板不再把它算进“最近失败”待办', { timeout: 90_000 }, async () => {
  const upstream = await startStubUpstream(['stub-model']);
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: upstream.base }, { auth: READABLE_FAKE_AUTH });
  try {
    const call = (probe) => fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: {
        authorization: `Bearer ${TOKEN}`,
        'content-type': 'application/json',
        ...(probe ? { 'x-workbuddy-probe': '1' } : {}),
      },
      body: JSON.stringify({
        model: 'stub-model', stream: true, max_tokens: 64,
        messages: [{ role: 'system', content: 'You are a helpful assistant.' }, { role: 'user', content: 'hi' }],
      }),
    }).then((res) => res.text());
    await call(true);
    await call(false);
    const ledger = await (await fetch(bridge.baseUrl + '/v1/requests?limit=5', { headers: auth })).json();
    const rows = ledger.requests.filter((r) => r.model === 'stub-model');
    assert.equal(rows.length, 2);
    assert.equal(rows[1].probe, true, '体检请求必须带 probe 标记');
    assert.equal(rows[0].probe, undefined, '普通对话不能被误标成体检');
  } finally { await bridge.stop(); upstream.close(); }
});

test('目录：一个端点 5xx 不能吞掉另一个端点已成功的目录', { timeout: 90_000 }, async () => {
  /*
   * 旧逻辑用全局 hardError：v3 500 + v2 200 时整份结果被丢弃，模型只剩
   * FEATURED。现在只有“没有任何端点成功”才保留旧缓存。
   */
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v3/config') {
      res.writeHead(500, { 'content-type': 'text/html' });
      return res.end('<html>gateway error</html>');
    }
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: { models: [{ id: 'v2-survivor', name: 'V2 Survivor', maxInputTokens: 128000, maxOutputTokens: 8192, supportsToolCall: true }] },
      }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: upstreamBase }, { auth: READABLE_FAKE_AUTH });
  try {
    const models = await (await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth })).json();
    assert.ok(models.data.some((m) => m.id === 'v2-survivor'), 'v2 成功的目录必须保留');
    const health = await (await fetch(bridge.baseUrl + '/health', { headers: auth })).json();
    assert.match(String(health.upstreamShape?.sources?.['/v3/config']), /500/, 'v3 的 5xx 仍要记进诊断');
  } finally { await bridge.stop(); upstream.close(); }
});

test('刷新竞态：刷新期间桌面换号，旧令牌不得写回 memoryAuth', { timeout: 90_000 }, async () => {
  /*
   * 401 → refresh 请求在飞时，桌面端完成了换号。旧实现会在刷新返回后把
   * **旧账号的 userId** 和**新文件的 mtime/size** 一起写进 memoryAuth，
   * 于是桥一直用旧账号令牌（#6 的复发形态）。修复后这次刷新结果必须丢弃，
   * 下一次 readStoredAuth 读到新文件。
   */
  let refreshStarted = false;
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/plugin/auth/token/refresh') {
      refreshStarted = true;
      setTimeout(() => {
        res.writeHead(200, { 'content-type': 'application/json' });
        res.end(JSON.stringify({ code: 0, data: { accessToken: 'refreshed-old', refreshToken: 'rotated', expiresIn: 3600, refreshExpiresIn: 86400 } }));
      }, 700);
      return;
    }
    if (path === '/v2/chat/completions') {
      res.writeHead(401, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 401, msg: 'expired' }));
    }
    if (path === '/v3/config' || path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: upstreamBase, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: authFileFor('account-a') },
  );
  try {
    const chat = fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { authorization: `Bearer ${TOKEN}`, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'stub-model', stream: false, max_tokens: 8,
        messages: [{ role: 'user', content: 'hi' }],
      }),
    }).then((res) => res.text());
    for (let i = 0; i < 40 && !refreshStarted; i += 1) await new Promise((r) => setTimeout(r, 50));
    assert.equal(refreshStarted, true, '请求 401 后必须触发一次 refresh');
    writeFileSync(join(bridge.dir, 'fake-auth.info'), JSON.stringify(authFileFor('account-b')));
    await chat;
    await new Promise((r) => setTimeout(r, 300));
    const h = await (await fetch(bridge.baseUrl + '/health', { headers: auth })).json();
    assert.equal(h.auth?.userId, 'account-b', '刷新期间换号后不能把旧账号令牌写回；health 必须读新文件');
  } finally { await bridge.stop(); upstream.close(); }
});

test('账号跟随：桌面端换号后桥自动改读桌面登录文件；换回则恢复钉住的快照', { timeout: 90_000 }, async () => {
  /*
   * issue #6：面板切换账号把桥钉在快照上，用户随后在 WorkBuddy 客户端换号，
   * 客户端覆盖的是它自己的默认登录文件 —— 桥必须能发现并跟随。
   */
  const pinSub = 'account-pinned';
  const desktopAtPin = 'account-desktop';
  const desktopAfterSwitch = 'account-switched';
  const aux = mkdtempSync(join(tmpdir(), 'wb-bridge-follow-'));
  const followPath = join(aux, 'workbuddy-desktop.info');
  writeFileSync(followPath, JSON.stringify(authFileFor(desktopAtPin)));

  const bridge = await startBridge(
    {
      WORKBUDDY_AUTH_FILE_FOLLOW: followPath,
      WORKBUDDY_AUTH_FOLLOW_UID: desktopAtPin,
    },
    { auth: authFileFor(pinSub) },
  );
  const health = async () => (await (await fetch(bridge.baseUrl + '/health', { headers: auth })).json());
  const waitForUid = async (uid) => {
    const deadline = Date.now() + 10_000;
    while (Date.now() < deadline) {
      const h = await health().catch(() => null);
      if (h?.auth?.userId === uid) return h;
      await new Promise((r) => setTimeout(r, 150));
    }
    throw new Error(`10 秒内没有切换到 ${uid}；最后一次 health=${JSON.stringify(await health().catch(() => null))}`);
  };
  try {
    const before = await waitForUid(pinSub);
    assert.equal(before.authFollow, undefined, '桌面账号未变时必须继续用用户钉住的快照');

    // 模拟用户在 WorkBuddy 客户端换号：客户端覆盖自己的默认登录文件
    writeFileSync(followPath, JSON.stringify(authFileFor(desktopAfterSwitch)));
    const after = await waitForUid(desktopAfterSwitch);
    assert.equal(after.authFilePinned, join(bridge.dir, 'fake-auth.info'), '健康信息里要能看出钉住的是哪份文件');
    assert.equal(after.authFollow, true, '跟随桌面后必须如实报告');

    // 用户在客户端换回原账号：钉住仍然有效，桥回到快照
    writeFileSync(followPath, JSON.stringify(authFileFor(desktopAtPin)));
    const restored = await waitForUid(pinSub);
    assert.equal(restored.authFollow, undefined, '桌面账号恢复后应回到钉住的快照');
  } finally { await bridge.stop(); rmSync(aux, { recursive: true, force: true }); }
});

test('账号跟随：没有 uid 元数据的旧钉住按“快照账号 ≠ 桌面账号”迁移一次', { timeout: 90_000 }, async () => {
  const aux = mkdtempSync(join(tmpdir(), 'wb-bridge-follow-legacy-'));
  const followPath = join(aux, 'workbuddy-desktop.info');
  writeFileSync(followPath, JSON.stringify(authFileFor('desktop-current')));
  const bridge = await startBridge(
    { WORKBUDDY_AUTH_FILE_FOLLOW: followPath },
    { auth: authFileFor('snapshot-old') },
  );
  try {
    const deadline = Date.now() + 10_000;
    let h = null;
    while (Date.now() < deadline) {
      h = await (await fetch(bridge.baseUrl + '/health', { headers: auth })).json().catch(() => null);
      if (h?.auth?.userId === 'desktop-current') break;
      await new Promise((r) => setTimeout(r, 150));
    }
    assert.equal(h?.auth?.userId, 'desktop-current', '旧状态必须跟随桌面当前账号，而不是继续用过期快照');
    assert.equal(h?.authFollow, true);
  } finally { await bridge.stop(); rmSync(aux, { recursive: true, force: true }); }
});

test('/v1/quota：余额必须带上归属账号，供面板按身份作废缓存', { timeout: 90_000 }, async () => {
  /*
   * issue #6 的第二段现象：「账号显示新、积分还是旧的」。控制台/插件各自
   * 有积分缓存；桌面端在客户端里换号时没有任何东西通知它们。只有让余额
   * 自带 account，才能在下一次读取时发现「这份缓存不属于当前账号」。
   */
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/billing/meter/get-user-resource') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: {
          Response: {
            Data: {
              Accounts: [{
                PackageName: 'stub-package',
                CapacityType: 4,
                CycleCapacitySize: 100,
                CycleCapacityRemain: 42,
              }],
            },
          },
        },
      }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    return res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const quotaDir = mkdtempSync(join(tmpdir(), 'wb-quota-history-'));
  const quotaFile = join(quotaDir, 'quota-history.jsonl');
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: `http://127.0.0.1:${upstream.address().port}`,
      WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${upstream.address().port}`,
      WORKBUDDY_QUOTA_SNAPSHOT_MS: '0',
      WORKBUDDY_QUOTA_HISTORY_FILE: quotaFile,
    },
    { auth: authFileFor('quota-account') },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/quota', { headers: auth, signal: AbortSignal.timeout(15000) });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.ok, true);
    assert.equal(body.total, 42);
    assert.equal(body.account, 'quota-account', '/v1/quota 必须说明这份余额属于哪个账号');
    assert.equal(body.source, 'desktop', '来源也要一并带回，面板才能解释账号与桌面文件为何不同');
    assert.equal(body.snapshotIntervalMs, 0, '测试把快照间隔压到 0，便于验证历史');

    // 账实核对：再取一次余额，应当留下两条快照；不足两条时页面必须显示“—”。
    const res2 = await fetch(bridge.baseUrl + '/v1/quota', { headers: auth, signal: AbortSignal.timeout(15000) });
    const body2 = await res2.json();
    assert.ok(Array.isArray(body2.history) && body2.history.length >= 2,
      `连续两次余额查询应留下至少两条快照，实际 ${JSON.stringify(body2.history)}`);
    assert.equal(body2.history.at(-1).total, 42);
    assert.equal(body2.history.at(-1).account, 'quota-account');
    assert.ok(existsSync(quotaFile), '快照必须落盘，桥重启后仍可核对');

    const health = await (await fetch(bridge.baseUrl + '/health', { headers: auth })).json();
    assert.match(String(health.build || ''), /^[0-9a-f]{16}$/, '/health 必须带构建指纹（启动方据此重启旧桥）');
  } finally {
    await bridge.stop();
    upstream.close();
    rmSync(quotaDir, { recursive: true, force: true });
  }
});

test('/v1/quota：企业/教育账号走企业配额，不能把可用余额显示成 0', { timeout: 90_000 }, async () => {
  /*
   * WorkBuddy 教育公益版（以及企业号）的登录凭据带 enterprise_id。上游把额度
   * 放在 get-enterprise-user-usage（limitNum 总额、credit 已用），个人套餐端点
   * 对它返回 Accounts=null。旧实现只查个人端点 → 面板恒显示 0。
   */
  let personalCalls = 0;
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/billing/meter/get-enterprise-user-usage') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: {
          limitNum: 2000,
          credit: 37.5,
          cycleStartTime: '2026-11-01 00:00:00',
          cycleEndTime: '2026-11-30 23:59:59',
          cycleResetTime: '2026-12-01 00:00:00',
        },
      }));
    }
    if (path === '/v2/billing/meter/get-user-resource') {
      personalCalls += 1;
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { Response: { Data: { Accounts: null } } } }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    return res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const quotaDir = mkdtempSync(join(tmpdir(), 'wb-quota-enterprise-'));
  const quotaFile = join(quotaDir, 'quota-history.jsonl');
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: `http://127.0.0.1:${upstream.address().port}`,
      WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${upstream.address().port}`,
      WORKBUDDY_QUOTA_SNAPSHOT_MS: '0',
      WORKBUDDY_QUOTA_HISTORY_FILE: quotaFile,
    },
    { auth: authFileFor('quota-enterprise', 'example.invalid', { enterprise_id: 'ent-stub' }) },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/quota', { headers: auth, signal: AbortSignal.timeout(15000) });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.ok, true);
    assert.equal(body.total, 1962.5, '企业额度必须按 limitNum - credit 折算剩余，而不是套餐端点的 0');
    assert.equal(body.used, 37.5);
    assert.equal(body.productCode, 'enterprise');
    assert.equal(body.packages?.[0]?.size, 2000);
    assert.equal(body.packages?.[0]?.remain, 1962.5);
    assert.equal(body.packages?.[0]?.monthly, true);
    assert.equal(personalCalls, 0, '企业号不应再回退到个人套餐端点');
  } finally {
    await bridge.stop();
    upstream.close();
    rmSync(quotaDir, { recursive: true, force: true });
  }
});


/*
 * 企业配额超时预算（code review 反馈）。
 *
 * 企业接口与个人套餐回退是**同一次余额读取**的两条路径，只能共用一份预算。
 * 旧写法给每个端点各 15s，接口卡住时一次读取就能占掉 30s；经 `quotaBalance`
 * 变成媒体提交路径上 2×(15+15)=60s 的隐性等待。
 *
 * 两条用例分别覆盖：
 *   1. 回退仍要工作 —— 企业接口快速失败时，个人套餐必须照常返回（不能因为
 *      收紧预算把回退逻辑写死）；
 *   2. 回退吃同一份预算 —— 企业接口把预算耗光后，个人套餐端点连一个请求都
 *      不该收到，整次读取要在预算附近结束，而不是再等一个完整超时。
 */

/** 起一个"企业接口必失败 + 个人端点计数"的打桩上游。 */
async function startEnterpriseFallbackUpstream({
  enterpriseDelayMs = 0,
  personalTotal = 42,
  enterpriseBody = undefined,
  personalEmpty = false,
} = {}) {
  const hits = { enterprise: 0, personal: 0 };
  const server = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/billing/meter/get-enterprise-user-usage') {
      hits.enterprise += 1;
      // 显式给 body：用于「企业接口成功但字段异常 / 不限量」的用例。
      if (enterpriseBody !== undefined) {
        res.writeHead(200, { 'content-type': 'application/json' });
        return res.end(JSON.stringify(enterpriseBody));
      }
      // 慢路径：不主动回包，让客户端自己 abort —— 模拟"企业接口无响应"。
      if (enterpriseDelayMs > 0) {
        const timer = setTimeout(() => {
          res.writeHead(200, { 'content-type': 'application/json' });
          res.end(JSON.stringify({ code: 0, data: { limitNum: 2000, credit: 1 } }));
        }, enterpriseDelayMs);
        res.on('close', () => clearTimeout(timer));
        return undefined;
      }
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 500, msg: 'enterprise endpoint down' }));
    }
    if (path === '/v2/billing/meter/get-user-resource') {
      hits.personal += 1;
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: {
          Response: {
            Data: {
              Accounts: personalEmpty ? null : [{
                PackageName: 'stub-package',
                CapacityType: 4,
                CycleCapacitySize: 100,
                CycleCapacityRemain: personalTotal,
              }],
            },
          },
        },
      }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    return res.end('{}');
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  return { server, hits, port: server.address().port };
}

test('/v1/quota：企业接口快速失败时仍要回退到个人套餐', { timeout: 90_000 }, async () => {
  const { server, hits, port } = await startEnterpriseFallbackUpstream({ personalTotal: 77 });
  const quotaDir = mkdtempSync(join(tmpdir(), 'wb-quota-fallback-'));
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: `http://127.0.0.1:${port}`,
      WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${port}`,
      WORKBUDDY_QUOTA_SNAPSHOT_MS: '0',
      WORKBUDDY_QUOTA_HISTORY_FILE: join(quotaDir, 'quota-history.jsonl'),
      // 收紧预算也不能影响"快速失败即可回退"这条主路径。
      WORKBUDDY_QUOTA_TIMEOUT_MS: '1500',
    },
    { auth: authFileFor('quota-fallback', 'example.invalid', { enterprise_id: 'ent-stub' }) },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/quota', { headers: auth, signal: AbortSignal.timeout(15000) });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.ok, true);
    assert.equal(body.total, 77, '企业接口失败后必须回退到个人套餐，不能把余额报成 0');
    assert.equal(body.productCode, 'p_tcaca');
    assert.equal(hits.enterprise, 1, '企业接口应当只被调用一次');
    assert.equal(hits.personal, 1, '快速失败后必须走一次个人套餐端点');
  } finally {
    await bridge.stop();
    server.close();
    rmSync(quotaDir, { recursive: true, force: true });
  }
});

test('/v1/quota：企业接口耗光预算后不再另开一份超时给个人套餐', { timeout: 90_000 }, async () => {
  /*
   * 企业接口不响应时，回退必须落在**同一份**预算里：总耗时应当贴近
   * QUOTA_TIMEOUT_MS（这里压到 800ms），而不是 2×预算。个人端点连请求都不该收到。
   */
  const BUDGET_MS = 800;
  const { server, hits, port } = await startEnterpriseFallbackUpstream({
    enterpriseDelayMs: 30_000,   // 远大于预算：一定被 abort
    personalTotal: 77,
  });
  const quotaDir = mkdtempSync(join(tmpdir(), 'wb-quota-budget-'));
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: `http://127.0.0.1:${port}`,
      WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${port}`,
      WORKBUDDY_QUOTA_SNAPSHOT_MS: '0',
      WORKBUDDY_QUOTA_HISTORY_FILE: join(quotaDir, 'quota-history.jsonl'),
      WORKBUDDY_QUOTA_TIMEOUT_MS: String(BUDGET_MS),
    },
    { auth: authFileFor('quota-budget', 'example.invalid', { enterprise_id: 'ent-stub' }) },
  );
  try {
    const startedAt = Date.now();
    const res = await fetch(bridge.baseUrl + '/v1/quota', { headers: auth, signal: AbortSignal.timeout(20000) });
    const elapsed = Date.now() - startedAt;
    const body = await res.json();
    assert.equal(res.status, 502, '两条路径都拿不到余额时应当如实报错，而不是编一个 0');
    assert.equal(body.ok, false);
    assert.equal(hits.personal, 0, '预算已耗尽时不该再向个人套餐端点发一个注定被 abort 的请求');
    assert.ok(
      elapsed < BUDGET_MS * 2,
      `整次余额读取必须共用一份预算（${BUDGET_MS}ms），实际耗时 ${elapsed}ms —— 企业接口与回退各自计时的老问题回来了`,
    );
  } finally {
    await bridge.stop();
    server.close();
    rmSync(quotaDir, { recursive: true, force: true });
  }
});

test('/v1/quota：不限量企业账号返回 unlimited，且不写负余额快照', { timeout: 90_000 }, async () => {
  /*
   * 企业接口用 limitNum < 0 表示不限量。桥保留这个语义（total = -1），
   * 但绝不能把它写进余额快照：两个 -1 相减得到 0，账实核对会误报「余额没动」。
   */
  const { server, hits, port } = await startEnterpriseFallbackUpstream({
    enterpriseBody: {
      code: 0,
      data: { limitNum: -1, credit: 5, cycleEndTime: '2026-11-30 23:59:59' },
    },
  });
  const quotaDir = mkdtempSync(join(tmpdir(), 'wb-quota-unlimited-'));
  const quotaFile = join(quotaDir, 'quota-history.jsonl');
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: `http://127.0.0.1:${port}`,
      WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${port}`,
      WORKBUDDY_QUOTA_SNAPSHOT_MS: '0',
      WORKBUDDY_QUOTA_HISTORY_FILE: quotaFile,
    },
    { auth: authFileFor('quota-unlimited', 'example.invalid', { enterprise_id: 'ent-stub' }) },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/quota', { headers: auth, signal: AbortSignal.timeout(15000) });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.ok, true);
    assert.equal(body.total, -1, '不限量必须保留 total = -1，供消费端识别');
    assert.equal(body.unlimited, true);
    assert.deepEqual(body.packages, [], '不限量账号没有可展示的套餐余量');
    assert.equal(body.used, 5);
    assert.equal(hits.personal, 0, '企业接口成功时不应回退个人套餐端点');
    assert.equal(existsSync(quotaFile), false, '不限量账号的 -1 不应写进余额快照');
  } finally {
    await bridge.stop();
    server.close();
    rmSync(quotaDir, { recursive: true, force: true });
  }
});

test('/v1/quota：企业接口 limitNum 为空时必须回退个人套餐', { timeout: 90_000 }, async () => {
  /*
   * `Number(null)` 是 0：上游把 limitNum 漏成空值时，旧写法会把它当成
   * 「额度 0」直接返回，又变成企业号恒显示 0。空值必须视为没有可用配额数据。
   */
  const { server, hits, port } = await startEnterpriseFallbackUpstream({
    enterpriseBody: { code: 0, data: { limitNum: null, credit: 1 } },
    personalTotal: 33,
  });
  const quotaDir = mkdtempSync(join(tmpdir(), 'wb-quota-null-limit-'));
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: `http://127.0.0.1:${port}`,
      WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${port}`,
      WORKBUDDY_QUOTA_SNAPSHOT_MS: '0',
      WORKBUDDY_QUOTA_HISTORY_FILE: join(quotaDir, 'quota-history.jsonl'),
    },
    { auth: authFileFor('quota-null-limit', 'example.invalid', { enterprise_id: 'ent-stub' }) },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/quota', { headers: auth, signal: AbortSignal.timeout(15000) });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.ok, true);
    assert.equal(body.total, 33, 'limitNum 为空必须回退个人套餐，不能把 null 折成 0');
    assert.equal(body.productCode, 'p_tcaca');
    assert.equal(hits.enterprise, 1);
    assert.equal(hits.personal, 1);
  } finally {
    await bridge.stop();
    server.close();
    rmSync(quotaDir, { recursive: true, force: true });
  }
});

test('/v1/quota：企业接口 credit 缺失时必须回退个人套餐', { timeout: 90_000 }, async () => {
  /*
   * credit 是已用量；缺失时按 0 处理会把「已用未知」报成「一分没用」，
   * 余额被高估。与 limitNum 一样，缺字段按「没有可用配额数据」处理。
   */
  const { server, hits, port } = await startEnterpriseFallbackUpstream({
    enterpriseBody: { code: 0, data: { limitNum: 2000 } },
    personalTotal: 44,
  });
  const quotaDir = mkdtempSync(join(tmpdir(), 'wb-quota-null-credit-'));
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: `http://127.0.0.1:${port}`,
      WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${port}`,
      WORKBUDDY_QUOTA_SNAPSHOT_MS: '0',
      WORKBUDDY_QUOTA_HISTORY_FILE: join(quotaDir, 'quota-history.jsonl'),
    },
    { auth: authFileFor('quota-null-credit', 'example.invalid', { enterprise_id: 'ent-stub' }) },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/quota', { headers: auth, signal: AbortSignal.timeout(15000) });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.ok, true);
    assert.equal(body.total, 44, 'credit 缺失时必须回退个人套餐，不能把余额高估成 2000');
    assert.equal(body.productCode, 'p_tcaca');
    assert.equal(hits.enterprise, 1);
    assert.equal(hits.personal, 1);
  } finally {
    await bridge.stop();
    server.close();
    rmSync(quotaDir, { recursive: true, force: true });
  }
});

test('/v1/quota：企业接口失败且个人套餐为空时要报错，不能假 0', { timeout: 90_000 }, async () => {
  /*
   * 企业接口故障时回退个人套餐；个人端点也返回空（Accounts=null）只说明
   * "那边也没有数据"，不代表企业额度是 0。把 0 当成功返回，面板会在故障
   * 期间显示一个假余额 —— 宁可报错让用户重试。
   */
  const { server, hits, port } = await startEnterpriseFallbackUpstream({ personalEmpty: true });
  const quotaDir = mkdtempSync(join(tmpdir(), 'wb-quota-fallback-empty-'));
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: `http://127.0.0.1:${port}`,
      WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${port}`,
      WORKBUDDY_QUOTA_SNAPSHOT_MS: '0',
      WORKBUDDY_QUOTA_HISTORY_FILE: join(quotaDir, 'quota-history.jsonl'),
    },
    { auth: authFileFor('quota-fallback-empty', 'example.invalid', { enterprise_id: 'ent-stub' }) },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/quota', { headers: auth, signal: AbortSignal.timeout(15000) });
    const body = await res.json();
    assert.equal(res.status, 502, '两条路径都没有数据时必须如实报错，而不是返回 total: 0');
    assert.equal(body.ok, false);
    assert.match(String(body.error), /enterprise endpoint down/);
    assert.equal(hits.enterprise, 1);
    assert.equal(hits.personal, 1, '回退仍要尝试一次个人端点，只是空结果不能当余额');
  } finally {
    await bridge.stop();
    server.close();
    rmSync(quotaDir, { recursive: true, force: true });
  }
});

test('/v1/quota：套餐按到期时间由近到远排序', { timeout: 90_000 }, async () => {
  /*
   * 同一档权益会被上游拆成多条，到期日可能不同；消费端先展示快过期的。
   * 没有到期日的一次性套餐排最后。
   */
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/billing/meter/get-user-resource') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: {
          Response: {
            Data: {
              Accounts: [
                { PackageName: '同名包', CapacityType: 4, CycleCapacitySize: 100, CycleCapacityRemain: 10, ExpiredTime: '2026-11-30 23:59:59' },
                { PackageName: '同名包', CapacityType: 4, CycleCapacitySize: 100, CycleCapacityRemain: 20, ExpiredTime: '2026-11-10 23:59:59' },
                { PackageName: '永久包', CapacityType: 1, CapacitySize: 50, CapacityRemain: 5 },
              ],
            },
          },
        },
      }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    return res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const quotaDir = mkdtempSync(join(tmpdir(), 'wb-quota-expiry-order-'));
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: `http://127.0.0.1:${upstream.address().port}`,
      WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${upstream.address().port}`,
      WORKBUDDY_QUOTA_SNAPSHOT_MS: '0',
      WORKBUDDY_QUOTA_HISTORY_FILE: join(quotaDir, 'quota-history.jsonl'),
    },
    { auth: authFileFor('quota-expiry-order') },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/quota', { headers: auth, signal: AbortSignal.timeout(15000) });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.total, 35);
    assert.deepEqual(body.packages.map((p) => p.expiresAt), [
      '2026-11-10 23:59:59',
      '2026-11-30 23:59:59',
      undefined,
    ]);
    assert.deepEqual(body.packages.map((p) => p.remain), [20, 10, 5]);
  } finally {
    await bridge.stop();
    upstream.close();
    rmSync(quotaDir, { recursive: true, force: true });
  }
});

test('/v1/quota：非月度包把 CycleEndTime 当作到期时间', { timeout: 90_000 }, async () => {
  /*
   * 实测上游的「裂变包」等非月度包 ExpiredTime 为空，真实到期写在 CycleEndTime。
   * 旧代码只对月度包读 CycleEndTime，面板因此只剩一个没有日期的 ×N 合并行。
   */
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/billing/meter/get-user-resource') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: {
          Response: {
            Data: {
              Accounts: [
                { PackageName: '裂变包', CapacityType: 1, CapacitySize: 100, CapacityRemain: 100, ExpiredTime: '', CycleEndTime: '2026-11-16 23:16:41' },
                { PackageName: '裂变包', CapacityType: 1, CapacitySize: 100, CapacityRemain: 80, CycleEndTime: '2026-11-12 09:00:00' },
                { PackageName: '月度包', CapacityType: 4, CycleCapacitySize: 500, CycleCapacityRemain: 500, ExpiredTime: '', CycleEndTime: '2026-11-30 23:59:59' },
              ],
            },
          },
        },
      }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    return res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const quotaDir = mkdtempSync(join(tmpdir(), 'wb-quota-cycle-end-'));
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: `http://127.0.0.1:${upstream.address().port}`,
      WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${upstream.address().port}`,
      WORKBUDDY_QUOTA_SNAPSHOT_MS: '0',
      WORKBUDDY_QUOTA_HISTORY_FILE: join(quotaDir, 'quota-history.jsonl'),
    },
    { auth: authFileFor('quota-cycle-end') },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/quota', { headers: auth, signal: AbortSignal.timeout(15000) });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.total, 680);
    assert.deepEqual(body.packages.map((p) => p.expiresAt), [
      '2026-11-12 09:00:00',
      '2026-11-16 23:16:41',
      '2026-11-30 23:59:59',
    ]);
  } finally {
    await bridge.stop();
    upstream.close();
    rmSync(quotaDir, { recursive: true, force: true });
  }
});

test('/v1/quota：插件登录的企业号从 JWT 的 enterprise_id 兜底', { timeout: 120_000 }, async () => {
  /*
   * 插件登录原先只认 /v2/plugin/login/account 返回的可选 enterpriseId；
   * 接口不返回时，凭据里就没有企业标识，/v1/quota 会退回个人端点、余额恒为 0。
   * 桌面凭据一直按 JWT 的 enterprise_id 判定，插件路径必须同口径兜底。
   */
  const credentialRoot = mkdtempSync(join(tmpdir(), 'wb-quota-plugin-cred-'));
  const quotaDir = mkdtempSync(join(tmpdir(), 'wb-quota-plugin-'));
  const accessToken = `e30.${Buffer.from(JSON.stringify({
    sub: 'uid-enterprise',
    enterprise_id: 'ent-from-jwt',
    exp: Math.floor(Date.now() / 1000) + 86_400,
  })).toString('base64url')}.sig`;
  const hits = { enterprise: 0, personal: 0, enterpriseHeader: '' };
  const send = (res, obj) => {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify(obj));
  };
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/plugin/auth/state') {
      return send(res, { code: 0, data: { state: 'state-ent', authUrl: 'http://127.0.0.1/login?state=state-ent' } });
    }
    if (path === '/v2/plugin/auth/token' && req.method === 'GET') {
      return send(res, {
        code: 0,
        data: { accessToken, refreshToken: 'refresh-ent', expiresIn: 86_400, domain: 'www.codebuddy.cn' },
      });
    }
    if (path === '/v2/plugin/login/account') {
      // 故意不返回 enterpriseId：兜底只能来自 JWT claims。
      return send(res, { code: 0, data: { uid: 'uid-enterprise' } });
    }
    if (path === '/v2/billing/meter/get-enterprise-user-usage') {
      hits.enterprise += 1;
      hits.enterpriseHeader = String(req.headers['x-enterprise-id'] || '');
      return send(res, { code: 0, data: { limitNum: 1000, credit: 2 } });
    }
    if (path === '/v2/billing/meter/get-user-resource') {
      hits.personal += 1;
      return send(res, { code: 0, data: { Response: { Data: { Accounts: null } } } });
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    return res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: upstreamBase,
    WORKBUDDY_BILLING_BASE: upstreamBase,
    WORKBUDDY_LOGIN_BASE: upstreamBase,
    WORKBUDDY_LOGIN_ORIGIN: 'http://127.0.0.1',
    WORKBUDDY_LOGIN_POLL_MIN_MS: '0',
    WORKBUDDY_CREDENTIAL_DIR: join(credentialRoot, 'credentials'),
    WORKBUDDY_CREDENTIAL_STORE: process.platform === 'win32' ? 'dpapi' : 'file',
    WORKBUDDY_CREDENTIAL_SOURCE: 'plugin',
    WORKBUDDY_QUOTA_SNAPSHOT_MS: '0',
    WORKBUDDY_QUOTA_HISTORY_FILE: join(quotaDir, 'quota-history.jsonl'),
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
  });
  try {
    const device = await (await fetch(`${bridge.baseUrl}/v1/auth/device`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ region: 'cn' }),
    })).json();
    assert.equal(device.ok, true);
    const poll = await (await fetch(
      `${bridge.baseUrl}/v1/auth/device?state=${encodeURIComponent(device.state)}`,
      { headers: auth },
    )).json();
    assert.equal(poll.status, 'ready');
    /*
     * 凭据清单也要显示企业身份：面板据此打「企业版」标记。
     * 老凭据没存 enterpriseId 时同样要能从 claims 补出来。
     */
    const credentials = await (await fetch(`${bridge.baseUrl}/v1/auth/credentials`, { headers: auth })).json();
    assert.equal(credentials.credentials?.[0]?.enterpriseId, 'ent-from-jwt');

    const res = await fetch(bridge.baseUrl + '/v1/quota', { headers: auth, signal: AbortSignal.timeout(15000) });
    const body = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.ok, true);
    assert.equal(body.total, 998);
    assert.equal(body.used, 2);
    assert.equal(body.productCode, 'enterprise');
    assert.equal(hits.enterprise, 1);
    assert.equal(hits.personal, 0, '插件凭据补到 enterprise_id 后不应再查个人端点');
    assert.equal(hits.enterpriseHeader, 'ent-from-jwt', '企业配额请求必须带 X-Enterprise-Id');
  } finally {
    await bridge.stop();
    upstream.close();
    rmSync(credentialRoot, { recursive: true, force: true });
    rmSync(quotaDir, { recursive: true, force: true });
  }
});

test('目录缓存：桌面换号后必须作废上一个账号的模型目录', { timeout: 90_000 }, async () => {
  /*
   * 目录属于账号。若只在“切换路径”时作废，同路径原地换号（或来源自动回退
   * 到另一条凭据）会让 /v1/models 继续返回上一个账号的模型/倍率，而 /health
   * 已经是新账号 —— 面板与 dsh 选择器各说一套。
   */
  const stubModels = ['model-a'];
  const stub = await startStubUpstream(stubModels);
  const aux = mkdtempSync(join(tmpdir(), 'wb-catalog-account-'));
  const followPath = join(aux, 'workbuddy-desktop.info');
  writeFileSync(followPath, JSON.stringify(authFileFor('catalog-a')));
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: stub.base,
      WORKBUDDY_AUTH_FILE_FOLLOW: followPath,
      WORKBUDDY_AUTH_FOLLOW_UID: 'catalog-a',
      WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    },
    { auth: authFileFor('catalog-a') },
  );
  const health = async () => (await fetch(`${bridge.baseUrl}/health`, { headers: auth })).json();
  const waitUid = async (uid) => {
    const deadline = Date.now() + 10_000;
    while (Date.now() < deadline) {
      const h = await health().catch(() => null);
      if (h?.auth?.userId === uid) return h;
      await new Promise((r) => setTimeout(r, 100));
    }
    throw new Error(`10 秒内没有切换到 ${uid}`);
  };
  try {
    const first = await (await fetch(`${bridge.baseUrl}/v1/models?all=1`, { headers: auth })).json();
    assert.ok(first.data.some((m) => m.id === 'model-a'), '初始目录必须来自账号 A');
    const identityA = await (await fetch(`${bridge.baseUrl}/v1/identity`, { headers: auth })).json();
    assert.equal(identityA.auth?.userId, 'catalog-a');
    assert.ok(identityA.build, '/v1/identity 必须带构建指纹，供前端识别桥换代');
    assert.ok(identityA.auth?.changedAt, '/v1/identity 必须带身份版本时间');

    stubModels.splice(0, stubModels.length, 'model-b');
    writeFileSync(followPath, JSON.stringify(authFileFor('catalog-b')));
    await waitUid('catalog-b');

    const identityB = await (await fetch(`${bridge.baseUrl}/v1/identity`, { headers: auth })).json();
    assert.equal(identityB.auth?.userId, 'catalog-b');
    assert.notEqual(identityB.auth?.changedAt, identityA.auth?.changedAt, '换号后身份版本必须变化');

    const second = await (await fetch(`${bridge.baseUrl}/v1/models?all=1`, { headers: auth })).json();
    const ids = second.data.map((m) => m.id);
    assert.ok(ids.includes('model-b'), `换号后必须重取目录，实际：${ids.join(',')}`);
    assert.ok(!ids.includes('model-a'), '不能把上一个账号的模型继续留在目录里');
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(aux, { recursive: true, force: true });
  }
});

test('目录：上游 401 时必须刷新令牌后重试（不能把目录缩成 2-3 个精选模型）', { timeout: 90_000 }, async () => {
  /*
   * 凭据过期时目录端点回 401。旧实现把 401 当成「这个区域没有这个端点」跳过，
   * 于是一条上游模型都拿不到，FEATURED 补出 2-3 个精选后照样写进 5 分钟缓存 ——
   * 用户看到"模型只剩几个"，得等 TTL 过期才恢复。聊天路径早就会 refresh+retry，
   * 目录这条路必须一致。
   */
  let refreshed = 0;
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/plugin/auth/token/refresh') {
      refreshed += 1;
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { accessToken: 'fresh-token', refreshToken: 'rotated', expiresIn: 3600, refreshExpiresIn: 86400 } }));
    }
    if (path === '/v2/enterprises/personal/models') {
      const tokenOk = /fresh-token/.test(String(req.headers.authorization || ''));
      if (!tokenOk) {
        res.writeHead(401, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ code: 401, msg: 'token expired' }));
      }
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: { models: [{ id: 'fresh-model', maxInputTokens: 128000, maxOutputTokens: 4096 }] },
      }));
    }
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ code: 0, data: { models: [] } }));
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));

  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: `http://127.0.0.1:${upstream.address().port}`,
    WORKBUDDY_TRANSPORT_RETRY_MS: '0',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/models?all=1&refresh=1`, { headers: auth, signal: AbortSignal.timeout(20_000) });
    assert.equal(res.status, 200);
    const body = await res.json();
    assert.ok(refreshed >= 1, '401 之后必须尝试刷新令牌');
    assert.ok((body.data || []).some((m) => m.id === 'fresh-model'),
      `刷新令牌后必须拿到上游目录，而不是只剩精选模型。实际：${JSON.stringify((body.data || []).map((m) => m.id))}`);
  } finally {
    await bridge.stop();
    await new Promise((r) => upstream.close(r));
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：目录非空时拒绝未知模型，且不打上游（D3）', { timeout: 90_000 }, async () => {
  // 起一个**打桩上游**：它按上游的目录形状回模型清单，并记录 chat 有没有被调过。
  // 为什么必须打桩、不能沿用 example.invalid：预校验只在「目录已知」时生效，
  // 而目录只有在真正抓到上游之后才会被填上（FEATURED 补全也在那之后）。
  // 用假域名的话缓存永远是空的，预校验按设计放行，这个用例就白测了。
  const calls = { chat: 0 };
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: {
          models: [
            { id: 'stub-known', name: 'Stub Known', maxInputTokens: 128000, maxOutputTokens: 8192 },
            { id: 'stub-other', name: 'Stub Other', maxInputTokens: 32000, maxOutputTokens: 4096 },
          ],
        },
      }));
    }
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    if (path === '/v2/chat/completions') {
      calls.chat += 1;
      res.writeHead(200, { 'content-type': 'text/event-stream' });
      return res.end('data: {"choices":[{"delta":{"content":"ok"}}]}\n\ndata: [DONE]\n\n');
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;

  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: upstreamBase }, { auth: READABLE_FAKE_AUTH });
  try {
    // 先打一次 /v1/models?all=1：这一步会把上游目录真的抓进 catalogCache，
    // 从而让预校验进入「目录非空」这条分支。
    const models = await (await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth })).json();
    const ids = models.data.map((m) => m.id);
    assert.ok(ids.includes('stub-known'), `前置条件：目录里应当有 stub-known，实际 ${ids.join(',')}`);

    const chatCallsBefore = calls.chat;

    // ① 未知模型 → 404（OpenAI/Anthropic 客户端据此切模型），且**上游 chat 一次都没被打**
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'definitely-not-a-real-model-id',
        messages: [{ role: 'user', content: 'hi' }],
      }),
      signal: AbortSignal.timeout(15000),
    });

    assert.equal(res.status, 404, '未知模型必须被本地拦成 404（不是打一次上游再报错）');
    assert.equal(calls.chat, chatCallsBefore, '预校验必须在**打上游之前**拦下，上游 chat 不能被调过');
    const body = await res.json();
    const message = body?.error?.message || '';
    assert.match(message, /not in the current catalog/i, '错误信息必须说明"不在当前目录中"');
    assert.match(message, /\/v1\/models/, '必须给出可操作提示（怎么看到完整目录）');
    assert.match(message, /WORKBUDDY_SKIP_MODEL_PREFLIGHT/, '必须告诉用户逃生开关，目录滞后时能放行');

    // ② 必须落账：否则这次拒绝在控制台"最近请求"里看不见（D3 的初衷之一）
    const requests = await (await fetch(bridge.baseUrl + '/v1/requests', { headers: auth })).json();
    const rejected = (requests.requests || []).find((r) => r.model === 'definitely-not-a-real-model-id');
    assert.ok(rejected, '被拒的请求必须记进账本，否则控制台看不到这次拒绝');
    assert.equal(rejected.ok, false, '这条账必须是失败态');
    assert.equal(rejected.status, 404, '账上要能看出是 404');

    // ③ 目录里的模型必须放行（不能把合法模型一起误杀）
    const known = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-known', messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(known.status, 200, '目录里确实存在的模型必须放行到上游');
    assert.equal(calls.chat, chatCallsBefore + 1, '放行的模型应当真的打了一次上游');

    // ④ 桥**对外承诺过**的精选模型也不能被否掉：/v1/models 在目录为空时回退到
    //    FEATURED 定义，客户端可能正拿着这些 id 来调。预校验只查 catalogCache
    //    的话，就会出现「桥让你选，转头又说不在目录里」的自相矛盾。
    const featured = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'deepseek-v4.1-flash', messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(featured.status, 200, 'FEATURED 里的模型必须放行（桥自己列出来过它们）');

    // ⑤ 逃生开关：关掉预校验后，同一个未知模型不能再被本地拦下
    const bridge2 = await startBridge(
      { CODEBUDDY_ENDPOINT: upstreamBase, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
      { auth: READABLE_FAKE_AUTH },
    );
    try {
      await fetch(bridge2.baseUrl + '/v1/models?all=1', { headers: auth });
      const res2 = await fetch(bridge2.baseUrl + '/v1/chat/completions', {
        method: 'POST',
        headers: { ...auth, 'content-type': 'application/json' },
        body: JSON.stringify({ model: 'still-not-real', messages: [{ role: 'user', content: 'hi' }] }),
        signal: AbortSignal.timeout(15000),
      });
      assert.notEqual(res2.status, 400, '逃生开关打开时，未知模型不能再被预校验拦下');
    } finally {
      await bridge2.stop();
      rmSync(bridge2.dir, { recursive: true, force: true });
    }
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
    await new Promise((r) => upstream.close(r));
  }
});

test('桥：上游目录拿不到模型时，未知模型必须放行（D3 不能误杀）', { timeout: 120_000 }, async () => {
  // 这条用例钉住 D3 最容易写错的地方，也是 verifier 报出的**真实误杀**。
  //
  // 背景：fetchCatalog 末尾会用 FEATURED **无条件**补全，所以只要目录端点不返回
  // 5xx，catalogCache.models 就至少躺着 3 个精选模型 —— 但那**不代表桥认识目录**。
  // 若预校验拿 "models.length > 0" 当启用条件，下面这些常见故障下所有不在
  // FEATURED 里的真实可用模型都会被本地 400 拦下、一次上游都不打。
  //
  // 场景全部取自 verifier 的 probe-d3-realistic.mjs，都是上游**真实可能**出现的
  // 非 5xx 失败：代理没放通目录端点（404）、字段改名、返回空数组、模型全被过滤。
  const CASES = [
    ['目录端点 404（代理/WAF 未放通）', 404, () => ({ code: 404, message: 'not found' })],
    ['目录 200 但 models 是空数组', 200, () => ({ code: 0, data: { models: [] } })],
    ['目录 200 但没有 models 字段（上游改名）', 200, () => ({ code: 0, data: { agents: [], other: 1 } })],
    ['目录 200 但模型全被 supportsToolCall:false 挡掉', 200, () => ({
      code: 0,
      data: { models: [{ id: 'no-tools-a', maxInputTokens: 1000, maxOutputTokens: 100, supportsToolCall: false }] },
    })],
  ];

  for (const [label, status, bodyFn] of CASES) {
    const hits = { chat: 0 };
    const upstream = createServer((req, res) => {
      const path = new URL(req.url, 'http://127.0.0.1').pathname;
      if (path === '/v2/chat/completions') {
        hits.chat += 1;
        res.writeHead(200, { 'content-type': 'text/event-stream' });
        return res.end('data: {"choices":[{"delta":{"content":"ok"}}]}\n\ndata: [DONE]\n\n');
      }
      if (path === '/v3/config') {
        // /v3/config 给 200 空表：贴近真实（它通常不是主目录端点）
        res.writeHead(200, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
      }
      if (path === '/v2/enterprises/personal/models') {
        res.writeHead(status, { 'content-type': 'application/json' });
        return res.end(JSON.stringify(bodyFn()));
      }
      res.writeHead(404, { 'content-type': 'application/json' });
      res.end('{}');
    });
    await new Promise((r) => upstream.listen(0, '127.0.0.1', r));

    const bridge = await startBridge(
      { CODEBUDDY_ENDPOINT: `http://127.0.0.1:${upstream.address().port}` },
      { auth: READABLE_FAKE_AUTH },
    );
    try {
      // 触发一次目录抓取（会失败/落空），再给后台刷新一点时间
      await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth, signal: AbortSignal.timeout(15000) }).catch(() => {});
      await new Promise((r) => setTimeout(r, 600));

      // 这个 id 上游 chat 完全能答（stub 对任何 model 都回 200），只是目录里没有。
      // 桥对目录一无所知时必须**原样转发**，而不是自作聪明地 400。
      const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
        method: 'POST',
        headers: { ...auth, 'content-type': 'application/json' },
        body: JSON.stringify({ model: 'available-but-unlisted-model', messages: [{ role: 'user', content: 'hi' }] }),
        signal: AbortSignal.timeout(15000),
      });

      assert.notEqual(res.status, 400, `${label}：目录未知时绝不能 400 误杀（实际 ${res.status}）`);
      assert.equal(hits.chat, 1, `${label}：目录未知时必须把请求原样转发给上游（chat 被调 ${hits.chat} 次）`);
    } finally {
      await bridge.stop();
      rmSync(bridge.dir, { recursive: true, force: true });
      await new Promise((r) => upstream.close(r));
    }
  }
});

test('桥：账本改用内存镜像后，/v1/usage 与 /v1/requests 的形状不变（D4）', { timeout: 90_000 }, async () => {
  const bridge = await startBridge();
  try {
    // 先在**桥外面**写一份账本，模拟"上次运行留下的真实历史"。
    // 关键是这份文件必须在桥读过它之前就存在，从而同时覆盖两条路径：
    //   - 冷启动时 usageLines === null，必须先初始化镜像
    //   - 镜像建起来之后，后续读取应当与直接解析文件逐字段一致
    const now = Date.now();
    const rows = [
      { t: now - 3600_000, model: 'deepseek-v4.1-flash', stream: false, ms: 120, ok: true, promptTokens: 10, completionTokens: 20, credit: 0.11 },
      { t: now - 1800_000, model: 'deepseek-v4-pro', stream: true, ms: 900, ok: true, promptTokens: 5, completionTokens: 7 },
      { t: now - 600_000, model: 'glm-5.3', stream: false, ms: 300, ok: false, status: 429, code: 11133, error: 'rate limited' },
    ];
    writeFileSync(join(bridge.dir, 'usage.jsonl'), `${rows.map((r) => JSON.stringify(r)).join('\n')}\n`);

    const usage = await (await fetch(bridge.baseUrl + '/v1/usage', { headers: auth })).json();
    assert.equal(usage.ok, true);
    assert.equal(usage.windowDays, 7, '默认窗口 7 天');

    // 形状断言：这些字段是控制台/插件实际读的，一个都不能少
    assert.equal(typeof usage.total, 'object');
    assert.ok(Array.isArray(usage.models), 'models 必须是数组');
    assert.ok(Array.isArray(usage.days), 'days 必须是数组');
    assert.ok(Array.isArray(usage.failures), 'failures 必须是数组');

    // 语义断言：成功的 2 条计入 total，失败的第 3 条单独归类
    assert.equal(usage.total.calls, 2, '成功调用数应为 2（失败那条不算）');
    assert.equal(usage.total.failed, 1, '失败数应为 1');
    assert.equal(usage.total.promptTokens, 15);
    assert.equal(usage.total.completionTokens, 27);
    // creditCalls 只数"上游真的回报了 credit"的那条（第 1 条），第 2 条没报
    assert.equal(usage.total.creditCalls, 1, '只有回报了 credit 的调用才算 creditCalls');
    assert.equal(usage.total.credit, 0.11);

    // 逐字段核对：内存镜像解析出来的模型聚合必须与直接解析文件得到的完全一致
    const expectedModels = rows.filter((r) => r.ok !== false).map((r) => r.model).sort();
    assert.deepEqual(
      usage.models.map((m) => m.model).sort(),
      expectedModels,
      '按模型聚合的结果必须与账本文件一致（镜像不能丢行、不能重复）',
    );

    // 失败明细：字段名与内容必须与写进去的一致
    assert.equal(usage.failures.length, 1);
    assert.equal(usage.failures[0].model, 'glm-5.3');
    assert.equal(usage.failures[0].status, 429);
    assert.equal(usage.failures[0].code, 11133);
    assert.equal(usage.failures[0].error, 'rate limited');

    // /v1/requests：新的在前，且元数据白名单字段齐全
    const requests = await (await fetch(bridge.baseUrl + '/v1/requests', { headers: auth })).json();
    assert.equal(requests.ok, true);
    assert.ok(Array.isArray(requests.requests));
    assert.equal(requests.requests.length, 3, '三条账都应当出现在最近请求里');
    assert.deepEqual(
      requests.requests.map((r) => r.model),
      ['glm-5.3', 'deepseek-v4-pro', 'deepseek-v4.1-flash'],
      '最近请求必须新的在前',
    );
    const failed = requests.requests[0];
    assert.equal(failed.ok, false);
    assert.equal(failed.status, 429);
    assert.equal(failed.code, 11133);
    // 白名单：不能带出账本里的其它字段（这里本来也没有，但形状要固定）
    assert.deepEqual(
      Object.keys(failed).sort(),
      ['code', 'error', 'model', 'ms', 'ok', 'status', 'stream', 't'],
      '/v1/requests 的字段集必须稳定（只回元数据白名单）',
    );

    // 小时视图：只有 ?hours=1 才带 hours 字段，且必须是补齐的 24 个桶
    const hourly = await (await fetch(bridge.baseUrl + '/v1/usage?days=1&hours=1', { headers: auth })).json();
    assert.ok(Array.isArray(hourly.hours), 'hours=1 时必须带 hours 数组');
    assert.equal(hourly.hours.length, 24, '小时桶必须补齐到 24 个');
    const plain = await (await fetch(bridge.baseUrl + '/v1/usage', { headers: auth })).json();
    assert.equal(plain.hours, undefined, '不带 hours=1 时不能出现 hours 字段');

    // 外部清空账本：内存镜像必须跟着作废（syncUsageMirror 的语义，不能被 D4 丢掉）
    writeFileSync(join(bridge.dir, 'usage.jsonl'), '');
    const after = await (await fetch(bridge.baseUrl + '/v1/usage', { headers: auth })).json();
    assert.equal(after.total.calls, 0, '文件被外部清空后，镜像必须一起作废（不能读回旧数据）');
    assert.equal(after.failures.length, 0);

    // 回归：外部**删除**账本文件、再换入一个**非空**文件时，镜像必须重新加载。
    //
    // 这条钉住一个真实踩过的坑：最初的重载判据是 `size < usageBytes`，而文件被
    // 删除后 usageBytes 归 0 —— `size < 0` 恒不成立，于是此后外部写进来的任何
    // 账本都读不到，镜像永久性地读成空。改成"指纹（字节数 + mtime）不一致就重载"
    // 之后才正确。先删再写，正是让 usageBytes 归零的最短路径。
    const ledger = join(bridge.dir, 'usage.jsonl');
    const externalRows = [
      { t: now - 60_000, model: 'external-a', stream: false, ms: 11, ok: true, promptTokens: 1, completionTokens: 2 },
      { t: now - 30_000, model: 'external-b', stream: false, ms: 22, ok: true, promptTokens: 3, completionTokens: 4 },
    ];
    rmSync(ledger, { force: true });
    const afterDelete = await (await fetch(bridge.baseUrl + '/v1/requests', { headers: auth })).json();
    assert.equal(afterDelete.requests.length, 0, '文件被删除后不得复活旧记录');

    writeFileSync(ledger, `${externalRows.map((r) => JSON.stringify(r)).join('\n')}\n`);
    const afterExternal = await (await fetch(bridge.baseUrl + '/v1/requests', { headers: auth })).json();
    assert.deepEqual(
      afterExternal.requests.map((r) => r.model),
      ['external-b', 'external-a'],
      '删除后外部换入的新账本必须被读到（只比大小的判据会在这里永久读成空）',
    );
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：上游流中途断开必须记成失败（与非流式路径一致）', { timeout: 90_000 }, async () => {
  // 打桩上游：发一帧正文后**掐断连接**，模拟"回答到一半上游断了"。
  // 这是真实会出现的情况（网络抖动 / 上游重启），而客户端只会看到回答被截断。
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [{ id: 'stub-stream', name: 'Stub', maxInputTokens: 128000, maxOutputTokens: 4096 }] } }));
    }
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    if (path === '/v2/chat/completions') {
      res.writeHead(200, { 'content-type': 'text/event-stream' });
      res.write('data: {"choices":[{"delta":{"content":"部分"}}]}\n\n');
      setTimeout(() => { try { res.socket.destroy(); } catch { /* 已断 */ } }, 50);
      return;
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;

  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: upstreamBase }, { auth: READABLE_FAKE_AUTH });
  try {
    // 先抓一次目录：让模型预校验认识 stub-stream（否则会被本地 400 拦下）
    await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth });

    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-stream', stream: true, messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(15000),
    });
    // 流已经以 200 开始，错误无法再改 HTTP 状态 —— 只能反映在账本里
    assert.equal(res.status, 200, '流已开始后状态只能是 200');
    try {
      const reader = res.body.getReader();
      for (;;) { const { done } = await reader.read(); if (done) break; }
    } catch { /* 上游被掐断，客户端读流异常属预期 */ }

    await new Promise((r) => setTimeout(r, 300)); // 等落账（异步写文件）
    const requests = await (await fetch(bridge.baseUrl + '/v1/requests', { headers: auth })).json();
    const row = (requests.requests || []).find((r) => r.model === 'stub-stream');
    assert.ok(row, '这次调用必须落账');
    assert.equal(row.ok, false, '上游流中断不是成功：必须记失败（曾长期被错记为 ok:true）');
    assert.ok(row.error, '失败行必须带错误原文，控制台才能显示"为什么被截断"');

    // 对照：账本的失败汇总也要能看到它（否则"失败数"统计漏报）
    const usage = await (await fetch(bridge.baseUrl + '/v1/usage?days=1', { headers: auth })).json();
    assert.equal(usage.total.failed, 1, '失败数必须把这笔算进去');
  } finally {
    await bridge.stop();
    try { upstream.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：拒绝外来 Origin（DNS rebinding 防线），且不误伤本机调用', { timeout: 90_000 }, async () => {
  // 刻意用**空令牌**启动 —— 那是桥自身的默认（`WORKBUDDY_LOCAL_TOKEN` 缺省为空），
  // 也是 Origin 这道防线真正要覆盖的场景：没有令牌时，如果连 Origin 都不看，
  // 一个恶意网页就能靠 DNS rebinding 把浏览器指向 127.0.0.1 来消耗账号配额。
  const calls = { chat: 0 };
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [{ id: 'origin-model', maxInputTokens: 128000, maxOutputTokens: 4096 }] } }));
    }
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    if (path === '/v2/chat/completions') {
      calls.chat += 1;
      res.writeHead(200, { 'content-type': 'text/event-stream' });
      return res.end('data: {"choices":[{"delta":{"content":"ok"}}]}\n\ndata: [DONE]\n\n');
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;

  /*
   * 用自动生成的令牌（传空 = 让桥自己生成），再从启动日志里取出来。
   *
   * 注意这里**不能在 `WORKBUDDY_LOCAL_TOKEN: ''` 下裸跑请求** —— 那正是
   * 「未配置即放行」的旧契约，已被「不得静默放行」用例推翻。本用例要验的是
   * **Origin 这道防线**，所以必须在一个合法令牌之上比对，否则 403 会被 401 抢先。
   */
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: upstreamBase, WORKBUDDY_LOCAL_TOKEN: '' },
    { auth: READABLE_FAKE_AUTH },
  );
  const autoToken = bridge.out().match(/WORKBUDDY_LOCAL_TOKEN=([A-Za-z0-9._-]{16,})/)?.[1];
  assert.ok(autoToken, '本用例依赖桥自动生成令牌（启动日志里应有 WORKBUDDY_LOCAL_TOKEN=…）');
  const bearer = { authorization: `Bearer ${autoToken}` };
  const body = JSON.stringify({ model: 'origin-model', messages: [{ role: 'user', content: 'hi' }] });
  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: bearer }); // 预热目录，让预校验认识该模型

    // ① 外来 Origin（跨站形状：text/plain 简单请求）→ 403，且**一次上游都不打**
    const before = calls.chat;
    const cross = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...bearer, Origin: 'https://evil.example', 'Content-Type': 'text/plain' },
      body,
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(cross.status, 403, '外来 Origin 必须被 403 拒绝');
    await cross.text();
    assert.equal(calls.chat, before, '被拒的请求绝不能打到上游（副作用必须为零）');

    // ② 回环 Origin 放行（本机网页版客户端仍然可用）
    const loop = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...bearer, Origin: 'http://127.0.0.1:9999', 'Content-Type': 'application/json' },
      body,
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(loop.status, 200, '回环 Origin 必须放行');
    await loop.text();

    // ③ 无 Origin（curl / dsh 插件 / 控制台内部代理）放行
    const none = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...bearer, 'Content-Type': 'application/json' },
      body,
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(none.status, 200, '无 Origin 必须放行（本机 CLI/SDK 不发这个头）');
    await none.text();

    // ④ 基础安全响应头
    const models = await fetch(bridge.baseUrl + '/v1/models', { headers: bearer });
    assert.equal(models.headers.get('x-content-type-options'), 'nosniff');
    assert.match(models.headers.get('content-security-policy') || '', /frame-ancestors 'none'/);
    await models.text();
  } finally {
    await bridge.stop();
    try { upstream.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：客户端可控的 model 必须收敛类型与长度（账本/日志/回显都不能被撑爆）', { timeout: 90_000 }, async () => {
  const calls = { chat: 0 };
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [{ id: 'len-model', maxInputTokens: 128000, maxOutputTokens: 4096 }] } }));
    }
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    if (path === '/v2/chat/completions') {
      calls.chat += 1;
      res.writeHead(200, { 'content-type': 'text/event-stream' });
      return res.end('data: {"choices":[{"delta":{"content":"ok"}}]}\n\ndata: [DONE]\n\n');
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;

  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: upstreamBase }, { auth: READABLE_FAKE_AUTH });
  const post = (body) => fetch(bridge.baseUrl + '/v1/chat/completions', {
    method: 'POST',
    headers: { ...auth, 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(15000),
  });
  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth }); // 预热目录

    // ① 超长 model：本地 400，且响应体**不能**原样回显那 30 万字符
    const huge = 'x'.repeat(300000);
    const over = await post({ model: huge, messages: [{ role: 'user', content: 'hi' }] });
    assert.equal(over.status, 400, '超长 model 必须被本地拒绝');
    const overText = await over.text();
    assert.ok(overText.length < 1000, `400 响应体必须短（实际 ${overText.length} 字符）—— 不能回显客户端输入`);
    assert.ok(!overText.includes(huge), '响应体里不得原样回显超长 model');

    // ② 账本行必须有界，否则反复打就能把磁盘灌爆
    await new Promise((r) => setTimeout(r, 300));
    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8').trim().split('\n');
    const lastRow = JSON.parse(ledger[ledger.length - 1]);
    assert.ok(String(lastRow.model).length <= 210, `账本行 model 必须被截断（实际 ${String(lastRow.model).length} 字符）`);
    assert.equal(lastRow.ok, false);

    // ③ /v1/requests 回显也必须是有界的
    const reqs = await (await fetch(bridge.baseUrl + '/v1/requests', { headers: auth })).json();
    assert.ok(String(reqs.requests[0].model || '').length <= 210, '/v1/requests 的 model 不得原样回显超长串');

    // ④ model 不是字符串（数组/对象/数字/布尔）→ 类型混淆会让"长度"判断失效，必须拒
    for (const badModel of [['a', 'b'], { id: 'x' }, 123, true]) {
      const r = await post({ model: badModel, messages: [{ role: 'user', content: 'hi' }] });
      assert.equal(r.status, 400, `model=${JSON.stringify(badModel)} 必须被拒（必须是字符串）`);
      await r.text();
    }

    // ⑤ `null` / 缺省视同"没给" → 沿用原有的默认模型回落（不算类型错误）
    for (const missing of [null, undefined]) {
      const r = await post({ model: missing, messages: [{ role: 'user', content: 'hi' }] });
      assert.equal(r.status, 200, `model=${String(missing)} 应当回落到默认模型，而不是被拒`);
      await r.text();
    }

    // ⑥ 正常模型不受影响
    const before = calls.chat;
    const okModel = await post({ model: 'len-model', messages: [{ role: 'user', content: 'hi' }] });
    assert.equal(okModel.status, 200);
    await okModel.text();
    assert.equal(calls.chat, before + 1, '合法模型必须照常打到上游');
  } finally {
    await bridge.stop();
    try { upstream.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：刷新失败时不得把响应体写进日志（响应体可能带 accessToken）', { timeout: 90_000 }, async () => {
  const SENTINEL = 'SENTINEL-ACCESS-TOKEN-MUST-NOT-BE-LOGGED';
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/plugin/auth/token/refresh') {
      // 关键形状：**非 2xx，但响应体里带着 accessToken** —— 这正是"打印响应体"
      // 会把令牌落进 bridge.log 的场景（失败条件含 !res.ok）。
      res.writeHead(401, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { accessToken: SENTINEL, refreshToken: SENTINEL } }));
    }
    if (path === '/v2/chat/completions') {
      res.writeHead(200, { 'content-type': 'text/event-stream' });
      return res.end('data: {"choices":[{"delta":{"content":"ok"}}]}\n\ndata: [DONE]\n\n');
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;

  // expiresAt 只剩 60 秒（< 5 分钟 skew）→ 请求会先触发一次 token 刷新
  const nearExpiry = {
    auth: {
      accessToken: 'fake-access-token',
      refreshToken: 'fake-refresh-token',
      domain: 'example.invalid',
      expiresAt: Date.now() + 60_000,
    },
  };
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: upstreamBase, WORKBUDDY_LOG: '1' },
    { auth: nearExpiry },
  );
  try {
    const r = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'deepseek-v4.1-flash', messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(15000),
    });
    await r.text().catch(() => '');
    await new Promise((res) => setTimeout(res, 400));

    // 路径确实走到了（否则这条断言是空转）
    assert.match(bridge.out(), /refresh failed/, '应当记录了一次刷新失败（用例必须真的覆盖到目标路径）');
    assert.ok(!bridge.out().includes(SENTINEL), '日志里不得出现刷新响应体里的令牌（违反"不落盘令牌"）');
  } finally {
    await bridge.stop();
    try { upstream.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：keep-alive 连接被复用，且复用连接被掐断时自动换新连接重试', { timeout: 90_000 }, async () => {
  // 两个断言点：
  //  ① 复用：第二次对话请求命中上游**同一个** TCP socket（server 端连接计数不涨）；
  //  ② 稳定：上游把空闲 socket 掐断后，下一次请求必须成功（桥换新连接重试一次），
  //     客户端看到的是正常回答，而不是 ECONNRESET。
  let socketsOpened = 0;
  let chatCalls = 0;
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [{ id: 'ka-model', maxInputTokens: 128000, maxOutputTokens: 4096 }] } }));
    }
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    if (path === '/v2/chat/completions') {
      chatCalls += 1;
      res.writeHead(200, { 'content-type': 'text/event-stream' });
      res.end(`data: {"choices":[{"delta":{"content":"call${chatCalls}"}}]}\n\ndata: [DONE]\n\n`);
      if (chatCalls === 3) {
        // 第 3 次：应答完整返回**之后**掐掉底层 socket，
        // 让 Agent 池里留一条**服务端已关闭**的死连接给第 4 次。
        setTimeout(() => { try { res.socket.destroy(); } catch { /* 已断 */ } }, 30);
      }
      return;
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  upstream.on('connection', () => { socketsOpened += 1; });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;

  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: upstreamBase }, { auth: READABLE_FAKE_AUTH });
  const chat = () => fetch(bridge.baseUrl + '/v1/chat/completions', {
    method: 'POST',
    headers: { ...auth, 'content-type': 'application/json' },
    body: JSON.stringify({ model: 'ka-model', messages: [{ role: 'user', content: 'hi' }] }),
    signal: AbortSignal.timeout(15000),
  }).then((r) => r.text());
  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1'); // 预热目录，让预校验认识 ka-model

    const r1 = await chat();
    const socketsAfterFirst = socketsOpened;
    const r2 = await chat();
    assert.match(r1, /call1/);
    assert.match(r2, /call2/);
    assert.equal(socketsOpened, socketsAfterFirst, '第二次请求必须复用同一条 keep-alive 连接（不得新开 socket）');

    // 第 3 次：正常拿到回答，但上游随后掐掉 socket（池子里留下一条死连接）
    const r3 = await chat();
    assert.match(r3, /call3/);
    await new Promise((r) => setTimeout(r, 100)); // 等 socket 真正被掐断

    // 第 4 次：撞上死连接 → 桥自动换新连接重试并成功（对客户端透明）
    const r4 = await chat();
    assert.match(r4, /call4/, '复用连接被掐断后必须自动重试成功，客户端无感');
  } finally {
    await bridge.stop();
    try { upstream.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：出站 system 已做审计模板最小改写（黑名单原文不得出现在上游看到的请求里）', { timeout: 90_000 }, async () => {
  // 背景（2026-10-08 实测）：带 Claude Code 原文模板的请求被上游**逐字拉黑**
  // —— 400 `Illegal API invocation from an unapproved channel`；按报告
  // §8.7 #44 最小改写（CLI→CLI tool、Main branch→Default branch）后放行。
  // 本用例把「出站不含黑名单原文」钉死为回归（打桩上游直接审视桥发了什么）。
  const stub = await startStubUpstream(['audit-model']);
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1'); // 预热目录，让预校验认识 audit-model

    const res = await fetch(bridge.baseUrl + '/v1/messages', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'audit-model',
        max_tokens: 16,
        system: [
          { type: 'text', text: "You are Claude Code, Anthropic's official CLI for Claude." },
          { type: 'text', text: 'Main branch (you will usually use this for PRs)' },
        ],
        messages: [{ role: 'user', content: 'ping' }],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();

    assert.equal(stub.seen.length, 1, '桥应向上游发出恰好一条聊天请求');
    const outbound = JSON.parse(stub.seen[0].body);
    const sysText = outbound.messages
      .filter((m) => m.role === 'system')
      .map((m) => (typeof m.content === 'string' ? m.content : JSON.stringify(m.content)))
      .join('\n');
    assert.ok(!sysText.includes("Anthropic's official CLI for Claude."),
      '出站 system 不得含黑名单原文（…official CLI for Claude.）');
    assert.ok(!sysText.includes('Main branch (you will usually use this for PRs)'),
      '出站 system 不得含黑名单原文（Main branch …）');
    assert.ok(sysText.includes("Anthropic's official CLI tool for Claude."),
      '应含最小改写后的形态（CLI tool）');
    assert.ok(sysText.includes('Default branch (you will usually use this for PRs)'),
      '应含最小改写后的形态（Default branch）');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：出站身份指纹可用 env 覆盖（上游版本漂移时的逃生门）', { timeout: 90_000 }, async () => {
  // 上游按 UA / X-IDE-* / X-Product-Version 校验调用来源；官方客户端升级后
  // 旧指纹可能整体被拒。三个值必须能用 .env（→ bridgeEnv → 桥）覆盖，
  // 否则用户只能改源码 —— 这是报告 §8.6 风险 1 的最低成本逃生门。
  const stub = await startStubUpstream(['id-model']);
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: stub.base,
      WORKBUDDY_APP_VERSION: '9.9.9-test',
      WORKBUDDY_IDE_NAME: 'TestIDE',
      // IDE_VERSION 故意不覆盖 → 应保持默认
    },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1'); // 预热目录，让预校验认识 id-model
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'id-model', messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();

    assert.equal(stub.seen.length, 1);
    const h = stub.seen[0].headers;
    assert.equal(h['user-agent'], 'TestIDE/1.119.0 CodeBuddy/9.9.9-test',
      'UA 应由 env 覆盖的 IDE 名/版本与 App 版本拼出，未覆盖项保持默认');
    assert.equal(h['x-ide-name'], 'TestIDE');
    assert.equal(h['x-ide-version'], '1.119.0', '未设置的 IDE_VERSION 应保持默认值');
    assert.equal(h['x-product-version'], '9.9.9-test');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：上游 429（14003）在桥这层等待重试，客户端无感', { timeout: 90_000 }, async () => {
  /*
   * 现场（2026-10-13 16:0x 实测）：上游按账号限流回 429，桥原先原样甩给 Codex，
   * 它 1-30s 一条地重试（5 连 429），回合被砍成"说话说一半"。修法：桥按
   * WORKBUDDY_429_WAITS 的计划在本地等待并原样重发，成功后客户端完全无感。
   */
  let chatHits = 0;
  const seen = [];
  const srv = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: { models: [{ id: 'r429-model', maxInputTokens: 128000, maxOutputTokens: 4096 }] },
      }));
    }
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    if (path === '/v2/chat/completions') {
      let body = '';
      req.on('data', (c) => { body += c; });
      req.on('end', () => {
        seen.push(body);
        chatHits += 1;
        if (chatHits === 1) {
          res.writeHead(429, { 'content-type': 'application/json', 'retry-after': '1' });
          return res.end(JSON.stringify({ code: 14003, msg: 'too many requests', retry_policy: { retry: true } }));
        }
        res.writeHead(200, { 'content-type': 'text/event-stream' });
        res.write('data: {"choices":[{"delta":{"content":"ok-after-429"}}]}\n\n');
        res.write('data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4}}\n\n');
        res.end('data: [DONE]\n\n');
      });
      return;
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: `http://127.0.0.1:${srv.address().port}`,
      WORKBUDDY_429_WAITS: '200',
    },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1'); // 预热目录
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'r429-model', messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200, '上游 429 必须在桥这层重试掉 —— 客户端拿到 200，而不是失败');
    const j = await res.json();
    assert.equal(j.choices?.[0]?.message?.content, 'ok-after-429', '重试成功后的回答要原样到达客户端');
    assert.equal(chatHits, 2, '上游应被命中 2 次：第一次 429，桥等待后重试成功');
    assert.equal(seen.length, 2, '两次请求体应完全一致（原样重发，不是重新组装）');
    assert.equal(seen[0], seen[1]);
  } finally {
    await bridge.stop();
    try { await srv.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 自动切号的数据源：/health 必须能按「账号 + 模型」数出最近 10 分钟真正
 * 返回给客户端的 429。桥内等待重试成功的不算（否则会把偶发抖动误判成限流）。
 */
test('桥：持续 429 时 /health 按账号+模型计数（自动切号的数据源）', { timeout: 90_000 }, async () => {
  const srv = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({
        code: 0,
        data: { models: [{ id: 'rate-model', maxInputTokens: 128000, maxOutputTokens: 4096 }] },
      }));
    }
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    if (path === '/v2/chat/completions') {
      req.resume();
      res.writeHead(429, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 42901, msg: 'too many requests' }));
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: `http://127.0.0.1:${srv.address().port}`, WORKBUDDY_429_WAITS: '' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth }); // 预热目录
    for (let i = 0; i < 3; i += 1) {
      const r = await fetch(bridge.baseUrl + '/v1/chat/completions', {
        method: 'POST',
        headers: { ...auth, 'content-type': 'application/json' },
        body: JSON.stringify({ model: 'rate-model', messages: [{ role: 'user', content: 'hi' }] }),
        signal: AbortSignal.timeout(15_000),
      });
      assert.equal(r.status, 429);
      await r.text();
    }
    const health = await (await fetch(bridge.baseUrl + '/health', { headers: auth })).json();
    assert.equal(health.rateLimit?.count, 3, '/health 必须数到 3 次 429');
    assert.equal(health.rateLimit?.model, 'rate-model');
    assert.ok(health.rateLimit?.windowMs >= 60_000, '计数窗口必须是分钟级');
    assert.equal(health.rateLimit?.models?.[0]?.count, 3, '按模型明细要给出同一个计数');
  } finally {
    await bridge.stop();
    try { await srv.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 上游 5xx 重试：2026-10-15 的真实故障里，多数 500/502 在 1 秒后原样重发即可成功。
 * 桥不重试 = 用户丢掉一整轮已经发出去的上下文。
 */
test('桥：上游 502 在桥这层重试一次，客户端无感', { timeout: 90_000 }, async () => {
  const okRaw = 'data: {"choices":[{"delta":{"content":"ok-after-502"}}]}\n\n'
    + 'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4}}\n\n'
    + 'data: [DONE]\n\n';
  const stub = await startStubUpstream(['stub-model'], {
    chatSequence: [
      { status: 502, type: 'application/json', raw: JSON.stringify({ msg: 'upstream temporarily unavailable' }) },
      { status: 200, type: 'text/event-stream', raw: okRaw },
    ],
  });
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_5XX_RETRY_DELAY_MS: '10',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }], max_tokens: 8 }),
      signal: AbortSignal.timeout(20_000),
    });
    assert.equal(res.status, 200, '上游 502 必须在桥这层重试掉 —— 客户端拿到 200');
    const j = await res.json();
    assert.equal(j.choices?.[0]?.message?.content, 'ok-after-502');
    const calls = stub.seen.filter((s) => JSON.parse(s.body || '{}').model).length;
    assert.equal(calls, 2, '应恰好重试 1 次（共 2 次上游请求）');
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：WORKBUDDY_5XX_RETRY=0 时 502 不重试（快速失败）', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['stub-model'], {
    chatStatus: 502,
    chatType: 'application/json',
    chatRaw: JSON.stringify({ msg: 'upstream temporarily unavailable' }),
  });
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_5XX_RETRY: '0',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }], max_tokens: 8 }),
      signal: AbortSignal.timeout(20_000),
    });
    assert.equal(res.status, 502, '关闭重试后 502 原样返回');
    const calls = stub.seen.filter((s) => JSON.parse(s.body || '{}').model).length;
    assert.equal(calls, 1, '开关关闭时只许打上游 1 次');
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：501 不在 5xx 重试表内（重发也不会变）', { timeout: 90_000 }, async () => {
  const okRaw = 'data: {"choices":[{"delta":{"content":"should-not-arrive"}}]}\n\n'
    + 'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n';
  const stub = await startStubUpstream(['stub-model'], {
    chatSequence: [
      { status: 501, type: 'application/json', raw: JSON.stringify({ msg: 'not implemented' }) },
      { status: 200, type: 'text/event-stream', raw: okRaw },
    ],
  });
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_5XX_RETRY_DELAY_MS: '10',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }], max_tokens: 8 }),
      signal: AbortSignal.timeout(20_000),
    });
    assert.equal(res.status, 501, '501 不该被重试，原样返回');
    const calls = stub.seen.filter((s) => JSON.parse(s.body || '{}').model).length;
    assert.equal(calls, 1, '501 只许打上游 1 次');
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：6004 账号用量上限 —— 不等待重试、按 insufficient_quota 返回、账本归因 quota', { timeout: 90_000 }, async () => {
  /*
   * 现场（issue/讨论截图）：上游 429 `code 6004`，文案带“将在 <时刻> 重置，
   * 也可以切换其他模型”。重置时刻在数小时后，不属于可退避的瞬时限流。
   *
   * 旧行为：桥按 429 原样透传 `rate_limit_error`；若用户配了
   * `WORKBUDDY_429_WAITS`，桥还会对 6004 白等（最长 90s），dsh 再按
   * RATE_LIMIT 重试 2 次 —— 一次注定失败的请求被拖很久。
   */
  // 重置时刻按“现在 + 20 小时”动态生成，避免 UTC+8 日期硬编码在将来某天变成过去时。
  const resetAtMs = Math.floor((Date.now() + 20 * 3_600_000) / 1000) * 1000;
  const resetWall = new Date(resetAtMs + 8 * 3_600_000); // UTC+8 的挂钟读数
  const pad = (n) => String(n).padStart(2, '0');
  const resetStamp = `${resetWall.getUTCFullYear()}-${pad(resetWall.getUTCMonth() + 1)}-${pad(resetWall.getUTCDate())}`
    + ` ${pad(resetWall.getUTCHours())}:${pad(resetWall.getUTCMinutes())}:${pad(resetWall.getUTCSeconds())}`;
  const quotaRaw = JSON.stringify({
    code: 6004,
    msg: `usage exceeds frequency limit, but don't worry, your usage will reset at ${resetStamp} UTC+8, alternatively, you can switch to the other models to continue using it.`,
  });
  const stub = await startStubUpstream(['quota-model'], {
    chatSequence: [{ status: 429, type: 'application/json', raw: quotaRaw }],
  });
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    // 显式打开等待计划：6004 必须**绕过**它，否则这条断言会多等 5 秒。
    WORKBUDDY_429_WAITS: '5000',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const startedAt = Date.now();
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'quota-model', messages: [{ role: 'user', content: 'hi' }], max_tokens: 8 }),
      signal: AbortSignal.timeout(20_000),
    });
    const body = await res.json();
    const elapsed = Date.now() - startedAt;
    assert.equal(res.status, 429, '状态码仍如实回 429');
    assert.equal(body.error?.type, 'insufficient_quota',
      '6004 必须映射成 insufficient_quota，避免客户端按瞬时限流自动重试');
    assert.equal(body.error?.code, 6004, '上游 code 要保留，便于对照');
    assert.ok((body.error?.message || '').includes(resetStamp), '重置时刻不能被吞掉');
    assert.equal(stub.seen.filter((s) => JSON.parse(s.body || '{}').model).length, 1,
      '6004 不得触发桥侧等待重发');
    assert.ok(elapsed < 3000, `6004 不应等待 WORKBUDDY_429_WAITS（实际 ${elapsed}ms）`);

    await new Promise((r) => setTimeout(r, 100)); // 等账本落盘
    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8')
      .trim().split('\n').map((line) => JSON.parse(line));
    const last = ledger.at(-1);
    assert.equal(last.failureKind, 'quota', '账本必须按额度归因，而不是 rate_limit');
    assert.equal(last.retryable, false, '6004 不可重试');
    assert.equal(last.failureAction, 'wait-reset');
    assert.equal(last.quotaResetAt, new Date(resetAtMs).toISOString(),
      '账本要带上结构化重置时刻，面板/切号不用再解析文案');
    const health = await (await fetch(bridge.baseUrl + '/health', { headers: auth })).json();
    assert.equal(health.rateLimit?.quota?.resetAt, new Date(resetAtMs).toISOString(),
      '/health.rateLimit.quota 要给出重置时刻，供自动切号判断');
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：多个模型各自触顶时，/health 必须逐条列出（不能只剩一条）', { timeout: 90_000 }, async () => {
  /*
   * 用户反馈："我用别的不是 workbuddy 的用量上限怎么又只剩一个了"。
   *
   * 根因：`rateLimitSummary()` 把 `quotaResetStats` 压成了一个 `quota` ——
   * 只保留最新那条，其余仅累加 count，于是 `model` / `resetAt` 全丢。
   * 面板只能显示一条，看起来像"前一个被顶掉了"。
   *
   * 这里让两个不同模型各吃一次 6004（重置时刻故意不同），断言：
   *   - `quotaModels` 有两条，模型名都在；
   *   - 每条各自带自己的 resetAt，没有互相覆盖；
   *   - 老字段 `quota` 仍然保留（自动切号只认它，不能破坏兼容）。
   */
  const pad = (n) => String(n).padStart(2, '0');
  const wallOf = (offsetHours) => {
    const wall = new Date(Date.now() + offsetHours * 3_600_000 + 8 * 3_600_000);
    return `${wall.getUTCFullYear()}-${pad(wall.getUTCMonth() + 1)}-${pad(wall.getUTCDate())}`
      + ` ${pad(wall.getUTCHours())}:${pad(wall.getUTCMinutes())}:${pad(wall.getUTCSeconds())}`;
  };
  const stampA = wallOf(10);
  const stampB = wallOf(20);
  const mkQuota = (stamp) => JSON.stringify({
    code: 6004,
    msg: `usage exceeds frequency limit, your usage will reset at ${stamp} UTC+8`,
  });
  /* 两个模型各自一条 6004：按请求顺序依次消费 */
  const stub = await startStubUpstream(['quota-model-a', 'quota-model-b'], {
    chatSequence: [
      { status: 429, type: 'application/json', raw: mkQuota(stampA) },
      { status: 429, type: 'application/json', raw: mkQuota(stampB) },
    ],
  });
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_429_WAITS: '0',
  }, { auth: READABLE_FAKE_AUTH });
  const auth = { authorization: `Bearer ${TOKEN}` };
  try {
    for (const model of ['quota-model-a', 'quota-model-b']) {
      const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
        method: 'POST',
        headers: { ...auth, 'content-type': 'application/json' },
        body: JSON.stringify({ model, messages: [{ role: 'user', content: 'hi' }] }),
        signal: AbortSignal.timeout(20_000),
      });
      assert.equal(res.status, 429, `${model} 应回 429`);
      await res.text();
    }
    const health = await (await fetch(bridge.baseUrl + '/health', { headers: auth })).json();
    const list = health.rateLimit?.quotaModels;
    assert.ok(Array.isArray(list), '/health.rateLimit.quotaModels 必须是数组');
    assert.equal(list.length, 2, `两个模型触顶应各占一条，实际 ${list.length} 条`);
    assert.deepEqual(list.map((q) => q.model).sort(), ['quota-model-a', 'quota-model-b'],
      '两条的模型名都要在，不能只剩最新那条');
    for (const q of list) {
      assert.ok(q.resetAt, `${q.model} 必须各自带 resetAt，不能被别的模型覆盖`);
    }
    assert.notEqual(list[0].resetAt, list[1].resetAt,
      '两个模型的重置时刻不同，说明各自的 resetAt 没有互相覆盖');
    /* 兼容：老字段仍在，自动切号不受影响 */
    assert.ok(health.rateLimit?.quota, '单条 quota 必须保留，供自动切号使用');
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：点名清单里的模型被上游下架时，/health 要说出少了谁、为什么', { timeout: 90_000 }, async () => {
  /*
   * 实机（2026-11-07）：用户保存了 glm-5.1 / kimi-k3.1-pro / kimi-k3-1 三个，
   * 但 /v1/models 只回 2 个 —— glm-5.1 已不在上游目录里。
   *
   * 过滤本身是对的（下架还继续冒充"可用"，客户端拿去调必然 404）。
   * 问题是**静默**：/health 里 ids 有 3 个、count 是 2，线索都在，
   * 但必须自己比对两个数组才能发现，而且看不出少的是谁。
   *
   * 现在 modelsDefault.dropped 直接给出 { id, reason }。
   */
  const stub = await startStubUpstream(['present-model', 'another-model'], {
    v3Models: ['present-model', 'another-model'],
  });
  /*
   * 必须先于启动就位：桥把偏好缓存在内存里（`/v1/models` 是高频路径），
   * 起完再写文件不会生效。而 `startBridge` 会把
   * `WORKBUDDY_MODELS_DEFAULT_FILE` 钉到它的临时目录，所以只能写那里。
   */
  const seedDir = mkdtempSync(join(tmpdir(), 'wb-models-default-'));
  writeFileSync(join(seedDir, 'models-default.json'),
    JSON.stringify({ ids: ['present-model', 'gone-model', 'another-model'] }), 'utf8');
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_MODELS_DEFAULT_FILE: join(seedDir, 'models-default.json'),
  }, { auth: READABLE_FAKE_AUTH });
  try {
    /*
     * 先等目录就绪。`/health` 只读缓存、绝不 await 上游（它有 4 秒超时约束），
     * 所以冷启动第一次探测时 catalog 往往是空的 —— 那时"在不在目录里"
     * 无从判断，桥会刻意不报 dropped（见 droppedFromIds 的注释）。
     * `/v1/models` 会 await 目录，拿它当就绪信号最直接。
     */
    let catalogReady = false;
    for (let i = 0; i < 50; i += 1) {
      const m = await (await fetch(bridge.baseUrl + '/v1/models', { headers: auth })).json();
      if ((m.data || []).length > 0) { catalogReady = true; break; }
      await new Promise((r) => setTimeout(r, 100));
    }
    assert.ok(catalogReady, '目录必须能在 5 秒内就绪，否则这条用例测不到东西');
    const health = await (await fetch(bridge.baseUrl + '/health', { headers: auth })).json();
    const md = health.modelsDefault;
    assert.ok(md, '/health 必须有 modelsDefault 段');

    assert.deepEqual(md.ids, ['present-model', 'gone-model', 'another-model'],
      '要如实回显保存的点名清单');
    assert.equal(md.count, 2, '实际只给 2 个（gone-model 不在目录里）');

    assert.ok(Array.isArray(md.dropped), '必须带上 dropped，不能静默少给');
    assert.equal(md.dropped.length, 1, '只少了 1 个');
    assert.equal(md.dropped[0].id, 'gone-model', '要点名是哪一个');
    assert.equal(md.dropped[0].reason, 'not-in-catalog',
      'reason 要说清是"上游目录里没有"，而不是含糊的"没给"');
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
    rmSync(seedDir, { recursive: true, force: true });
  }
});

test('桥：清单全部命中时 /health 不出现恒为空的 dropped 字段', { timeout: 90_000 }, async () => {
  /*
   * 反向护栏：正常状态下不该多一个恒为空的字段。
   * 恒空字段的坏处是"看起来永远没问题"—— 用户和面板都会忽略它，
   * 于是真出问题时同样看不见。只在非空时出现，才有信号价值。
   */
  const stub = await startStubUpstream(['only-model'], { v3Models: ['only-model'] });
  const seedDir = mkdtempSync(join(tmpdir(), 'wb-models-default-ok-'));
  writeFileSync(join(seedDir, 'models-default.json'),
    JSON.stringify({ ids: ['only-model'] }), 'utf8');
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_MODELS_DEFAULT_FILE: join(seedDir, 'models-default.json'),
  }, { auth: READABLE_FAKE_AUTH });
  try {
    /*
     * 先等目录就绪。`/health` 只读缓存、绝不 await 上游（它有 4 秒超时约束），
     * 所以冷启动第一次探测时 catalog 往往是空的 —— 那时"在不在目录里"
     * 无从判断，桥会刻意不报 dropped（见 droppedFromIds 的注释）。
     * `/v1/models` 会 await 目录，拿它当就绪信号最直接。
     */
    let catalogReady = false;
    for (let i = 0; i < 50; i += 1) {
      const m = await (await fetch(bridge.baseUrl + '/v1/models', { headers: auth })).json();
      if ((m.data || []).length > 0) { catalogReady = true; break; }
      await new Promise((r) => setTimeout(r, 100));
    }
    assert.ok(catalogReady, '目录必须能在 5 秒内就绪，否则这条用例测不到东西');
    const health = await (await fetch(bridge.baseUrl + '/health', { headers: auth })).json();
    assert.equal(health.modelsDefault.count, 1);
    assert.equal(Object.prototype.hasOwnProperty.call(health.modelsDefault, 'dropped'), false,
      '没有缺失时不得出现 dropped 键');
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
    rmSync(seedDir, { recursive: true, force: true });
  }
});

test('桥：已知配额耗尽后，下一个请求不再白撞上游（快速拒绝）', { timeout: 90_000 }, async () => {
  /*
   * 实测缺口（2026-11-07，假上游）：第 1 次被 6004 拒，`/health` 立刻报出
   * resetAt（数小时后）。第 2 次请求仍被原样发往上游、又吃一次同样的 6004 ——
   * 那一个往返是**纯浪费**，因为结果在发出前就已经确定。
   *
   * 根因：桥把 6004 / 11140 记进内存表，但那些表**只被 `rateLimitSummary()` 读**
   * （供 /health 展示），请求路径从不看它们。
   *
   * 现在：命中「已知失败且有未来恢复时刻」就直接拒，不打上游。
   * 报文必须**明说自己没打上游** —— 不能让用户以为这是刚被上游拒的。
   */
  const resetAtMs = Math.floor((Date.now() + 20 * 3_600_000) / 1000) * 1000;
  const resetWall = new Date(resetAtMs + 8 * 3_600_000);
  const pad = (n) => String(n).padStart(2, '0');
  const resetStamp = `${resetWall.getUTCFullYear()}-${pad(resetWall.getUTCMonth() + 1)}-${pad(resetWall.getUTCDate())}`
    + ` ${pad(resetWall.getUTCHours())}:${pad(resetWall.getUTCMinutes())}:${pad(resetWall.getUTCSeconds())}`;
  const stub = await startStubUpstream(['known-model'], {
    chatSequence: [{
      status: 429,
      type: 'application/json',
      raw: JSON.stringify({
        code: 6004,
        msg: `usage exceeds frequency limit, your usage will reset at ${resetStamp} UTC+8`,
      }),
    }],
  });
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
  }, { auth: READABLE_FAKE_AUTH });
  const hits = () => stub.seen.filter((x) => JSON.parse(x.body || '{}').model === 'known-model').length;
  const send = () => fetch(bridge.baseUrl + '/v1/chat/completions', {
    method: 'POST',
    headers: { ...auth, 'content-type': 'application/json' },
    body: JSON.stringify({ model: 'known-model', messages: [{ role: 'user', content: 'hi' }], max_tokens: 8 }),
    signal: AbortSignal.timeout(20_000),
  });
  try {
    // ── 第 1 次：真的打上游，被 6004 拒 ──
    const first = await send();
    const firstBody = await first.json();
    assert.equal(first.status, 429);
    assert.equal(firstBody.error?.code, 6004);
    assert.equal(hits(), 1, '第 1 次必须真的打上游');

    // ── 第 2 次：同一账号同一模型，已确认不可用 ──
    const t0 = Date.now();
    const second = await send();
    const secondBody = await second.json();
    const elapsed = Date.now() - t0;

    assert.equal(hits(), 1, '★ 已知配额耗尽后不得再打上游');
    assert.equal(second.status, 429, '状态码仍如实反映"用不了"');
    assert.equal(secondBody.error?.type, 'insufficient_quota',
      '分类必须与真实拒绝一致，客户端才会按"等重置/换号"处理');
    assert.equal(secondBody.error?.code, 6004, 'code 也要一致，便于对照');
    assert.ok((secondBody.error?.message || '').includes('未发往上游'),
      `报文必须明说没打上游，否则用户会以为是刚被上游拒的：${secondBody.error?.message}`);
    assert.ok(elapsed < 2000, `快速拒绝不该慢（实际 ${elapsed}ms）`);

    /*
     * 账本必须把这次也记成"配额、不可重试、等重置" —— 与真实被上游拒绝时
     * **完全一致**。这证明快速拒绝只是省掉了网络往返，没有改变下游语义。
     */
    await new Promise((r) => setTimeout(r, 100));
    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8')
      .trim().split('\n').map((line) => JSON.parse(line));
    const last = ledger.at(-1);
    assert.equal(last.failureKind, 'quota', '账本仍按额度归因');
    assert.equal(last.retryable, false, '仍标记为不可重试');
    assert.equal(last.failureAction, 'wait-reset', '动作仍是等重置');
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：没有恢复时刻的瞬时 429 不能被"已知失败"拦下（否则一次抖动变成自我封锁）', { timeout: 90_000 }, async () => {
  /*
   * 这是上一条的**反向护栏**，比正例更重要。
   *
   * 「已知失败快速拒绝」只对"上游给了明确恢复时刻"的失败成立。
   * 若把无 resetAt 的瞬时 429 也拦下来，那么一次偶发限流会让桥在接下来
   * 一段时间里对**所有**同类请求直接拒 —— 用户明明额度充足却完全用不了，
   * 而且完全无法自行恢复。那是比"多一个往返"严重得多的故障。
   *
   * 判据 therefore 是 resetAt > now：解析不出时刻 ⇒ 不拒。
   */
  const stub = await startStubUpstream(['transient-model'], {
    chatSequence: [
      { status: 429, type: 'application/json', raw: JSON.stringify({ code: 14003, msg: 'too many requests' }) },
      {
        status: 200,
        type: 'text/event-stream',
        raw: 'data: {"id":"x","object":"chat.completion.chunk","created":1,"model":"transient-model","choices":[{"index":0,"delta":{"role":"assistant","content":"ok"},"finish_reason":null}]}\n\n'
          + 'data: {"id":"x","object":"chat.completion.chunk","created":1,"model":"transient-model","choices":[{"index":0,"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4}}\n\n'
          + 'data: [DONE]\n\n',
      },
    ],
  });
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
  }, { auth: READABLE_FAKE_AUTH });
  const hits = () => stub.seen.filter((x) => JSON.parse(x.body || '{}').model === 'transient-model').length;
  const send = () => fetch(bridge.baseUrl + '/v1/chat/completions', {
    method: 'POST',
    headers: { ...auth, 'content-type': 'application/json' },
    body: JSON.stringify({ model: 'transient-model', messages: [{ role: 'user', content: 'hi' }], max_tokens: 8 }),
    signal: AbortSignal.timeout(20_000),
  });
  try {
    const first = await send();
    await first.text();
    assert.equal(first.status, 429);
    assert.equal(hits(), 1);

    // 第 2 次必须**照常打上游**，并拿到那条 200
    const second = await send();
    const secondText = await second.text();
    assert.equal(hits(), 2, '★ 无 resetAt 的瞬时 429 不得触发快速拒绝');
    assert.equal(second.status, 200, `第 2 次应正常成功，实际 ${second.status}：${secondText.slice(0, 160)}`);
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：14018 积分耗尽也不能落成可重试的瞬时限流', { timeout: 90_000 }, async () => {
  /*
   * 14018（Credits exhausted）是**确定的账号额度耗尽**，与 6004 同一类：
   * 重试不会变，正确动作是换号/充值。同类反代项目把它排在通用 429 之前判，
   * 否则会被当成软限流冷却 12h 或白重试。
   */
  const stub = await startStubUpstream(['credit-model'], {
    chatSequence: [{
      status: 429,
      type: 'application/json',
      raw: JSON.stringify({ code: 14018, msg: 'Credits exhausted' }),
    }],
  });
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'credit-model', messages: [{ role: 'user', content: 'hi' }], max_tokens: 8 }),
      signal: AbortSignal.timeout(20_000),
    });
    const body = await res.json();
    assert.equal(res.status, 429);
    assert.equal(body.error?.type, 'insufficient_quota');
    assert.equal(body.error?.code, 14018);
    await new Promise((r) => setTimeout(r, 100));
    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8')
      .trim().split('\n').map((line) => JSON.parse(line));
    assert.equal(ledger.at(-1).failureKind, 'quota', '14018 必须归到 quota');
    assert.equal(ledger.at(-1).retryable, false);
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：错误分类矩阵 —— 模型繁忙/队列/上下文/11140/11102/402 的动作与 header', { timeout: 90_000 }, async () => {
  /*
   * 同类项目的核心经验：错误分类决定动作。
   *   · 14003 模型繁忙：可重试但不换号；
   *   · 6020 队列：不重试、不换号，给位次；
   *   · 11115 上下文（中文形态）：必须让宿主识别成 context_length_exceeded；
   *   · 11140 账号风控 vs 内容审核：动作相反（换号 vs 调内容）；
   *   · 11102 模型不存在：换模型，不是参数问题；
   *   · 402 积分耗尽：不可重试，可换号。
   */
  const scenarios = {
    'busy-model': { status: 429, body: { code: 14003, msg: 'too many requests' } },
    'queue-model': { status: 429, body: { code: 6020, data: { queue_position: 7, queue_size: 900, retry_after: 40 } } },
    'ctx-model': { status: 400, body: { code: 11115, msg: '本次输入加上历史对话超过了模型上限' } },
    'restricted-model': {
      status: 403,
      body: { code: 11140, msg: 'request illegal', displayMsg: { zh: '账号存在异常行为，已被限制使用' } },
    },
    'policy-model': {
      status: 403,
      body: { code: 11140, msg: 'request illegal', displayMsg: { zh: '内容未通过安全审核，请调整后重试' } },
    },
    'missing-model': { status: 400, body: { code: 11102, msg: 'model [missing-model] service info not found' } },
    'credit-model': { status: 402, body: { code: 402, msg: 'billing: credits exhausted' } },
  };
  const srv = createServer((req, res) => {
    if (new URL(req.url, 'http://127.0.0.1').pathname !== '/v2/chat/completions') {
      res.writeHead(404, { 'content-type': 'application/json' });
      return res.end('{}');
    }
    let raw = '';
    req.on('data', (c) => { raw += c; });
    req.on('end', () => {
      const model = JSON.parse(raw || '{}').model;
      const scenario = scenarios[model];
      res.writeHead(scenario?.status || 500, { 'content-type': 'application/json' });
      res.end(JSON.stringify(scenario?.body || { msg: 'unknown scenario' }));
    });
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: `http://127.0.0.1:${srv.address().port}`,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_429_WAITS: '',
  }, { auth: READABLE_FAKE_AUTH });
  const chat = async (model) => {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model, messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(15_000),
    });
    let body = null;
    const text = await res.text();
    try { body = JSON.parse(text); } catch { /* 非 JSON */ }
    return { status: res.status, body, headers: res.headers };
  };
  try {
    const busy = await chat('busy-model');
    assert.equal(busy.status, 429);
    assert.equal(busy.body.error.type, 'rate_limit_error');
    assert.equal(busy.body.error.code, 14003);

    const queue = await chat('queue-model');
    assert.equal(queue.status, 429);
    assert.equal(queue.body.error.type, 'model_queue');
    assert.equal(queue.body.error.code, 'MODEL_QUEUE');
    assert.match(queue.body.error.message, /第 7 位/);
    assert.equal(queue.headers.get('x-should-retry'), 'false');
    assert.equal(queue.headers.get('retry-after'), '40');

    const ctx = await chat('ctx-model');
    assert.equal(ctx.status, 400);
    assert.equal(ctx.body.error.type, 'invalid_request_error');
    assert.equal(ctx.body.error.code, 'context_length_exceeded');
    assert.match(ctx.body.error.message, /prompt is too long/);

    const restricted = await chat('restricted-model');
    assert.equal(restricted.status, 403);
    assert.equal(restricted.body.error.type, 'account_restricted');
    assert.equal(restricted.body.error.code, 11140);
    assert.equal(restricted.headers.get('x-should-retry'), 'false');

    const policy = await chat('policy-model');
    assert.equal(policy.body.error.type, 'content_policy_error');
    assert.equal(policy.body.error.code, 'CONTENT_POLICY');

    const missing = await chat('missing-model');
    assert.equal(missing.status, 400);
    assert.equal(missing.body.error.type, 'invalid_request_error');
    assert.equal(missing.body.error.code, 'model_not_found');

    const credit = await chat('credit-model');
    assert.equal(credit.status, 402);
    assert.equal(credit.body.error.type, 'insufficient_quota');
    assert.equal(credit.body.error.code, 402);

    const health = await (await fetch(bridge.baseUrl + '/health', { headers: auth })).json();
    assert.equal(health.rateLimit?.count, 0, '14003/队列/402 都不属于通用 429 计数');
    assert.equal(health.rateLimit?.modelBusy?.model, 'busy-model');
    assert.equal(health.rateLimit?.queue?.model, 'queue-model');
    assert.equal(health.rateLimit?.queue?.position, 7);
    assert.equal(health.rateLimit?.accountRestricted?.model, 'restricted-model');
    assert.equal(health.rateLimit?.quota?.model, 'credit-model');
  } finally {
    await bridge.stop();
    await new Promise((r) => srv.close(r));
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：assistant 历史带 reasoning 时出站前剥离（避免 11151）', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['reason-model']);
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'reason-model',
        messages: [
          { role: 'user', content: 'hi' },
          { role: 'assistant', content: 'previous answer', reasoning_content: 'chain of thought', reasoning: 'old' },
          { role: 'user', content: 'again' },
        ],
      }),
      signal: AbortSignal.timeout(15_000),
    });
    assert.equal(res.status, 200);
    await res.text();
    const outbound = JSON.parse(stub.seen.at(-1).body);
    const assistant = outbound.messages.find((m) => m.role === 'assistant');
    assert.equal(assistant.content, 'previous answer');
    assert.equal(assistant.reasoning_content, undefined, '出站 assistant 不得带 reasoning_content');
    assert.equal(assistant.reasoning, undefined, '出站 assistant 不得带 reasoning');
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：默认按本机桌面端版本伪装官方客户端（目录/聊天身份分开）', { timeout: 90_000 }, async () => {
  /*
   * 现场（2026-11-02 讨论）：桥写死 VSCode/4.9.x，桌面端是 5.9.x，模型列表对不上。
   * 本机只读 A/B：同一账号，VSCode/4.9 目录 31 个模型，WorkBuddy 桌面身份 48 个。
   *
   * 这里钉住两件事：
   *   ① 版本从本机安装目录读（install-manifest.json + 内置 CLI package.json），
   *      不写死；
   *   ② 目录走桌面 App 三段式 UA，聊天走内置 CLI 的 UA —— 官方桌面端就是这么分工的。
   */
  const installDir = mkdtempSync(join(tmpdir(), 'wb-install-'));
  const exe = join(installDir, 'WorkBuddy.exe');
  writeFileSync(exe, '');
  mkdirSync(join(installDir, 'resources', 'app.asar.unpacked', 'cli'), { recursive: true });
  writeFileSync(join(installDir, 'resources', 'install-manifest.json'), JSON.stringify({ appVersion: '7.8.9' }));
  writeFileSync(
    join(installDir, 'resources', 'app.asar.unpacked', 'cli', 'package.json'),
    JSON.stringify({ version: '1.2.3' }),
  );
  const stub = await startStubUpstream(['id-model']);
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: stub.base,
      WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
      WORKBUDDY_IDENTITY: 'official',
      WORKBUDDY_APP_EXECUTABLE: exe,
    },
    { auth: authFileFor('identity-account', 'www.codebuddy.cn') },
  );
  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth });
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'id-model', messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(15_000),
    });
    assert.equal(res.status, 200);
    await res.text();

    const chatHeaders = stub.seen.at(-1).headers;
    assert.equal(chatHeaders['user-agent'], 'CLI/1.2.3 CodeBuddy/1.2.3',
      '聊天通道应使用桌面端内置 CLI 的 UA 形状');
    assert.equal(chatHeaders['x-ide-name'], 'WorkBuddy');
    assert.equal(chatHeaders['x-ide-type'], 'WorkBuddy');
    assert.equal(chatHeaders['x-ide-version'], '7.8.9', '版本应来自 install-manifest.json');
    assert.equal(chatHeaders['x-product-version'], '7.8.9');
    assert.equal(chatHeaders['x-product'], 'WorkBuddy', 'Name/Type/Product 必须同值');
    assert.equal(chatHeaders['x-agent-purpose'], 'conversation');
    assert.equal(chatHeaders['accept-language'], 'zh-CN');

    const config = stub.catalogSeen.find((s) => s.path === '/v3/config');
    assert.ok(config, `目录请求必须打到 /v3/config；实际目录请求=${JSON.stringify(stub.catalogSeen.map((s) => s.path))}；桥输出=${bridge.out().slice(-800)}`);
    assert.equal(config.headers['user-agent'], 'WorkBuddy/7.8.9 WorkBuddy/7.8.9 CLI/1.2.3',
      '目录通道应使用官方桌面端的三段式 UA');
    assert.equal(config.headers['x-ide-name'], 'WorkBuddy');
    assert.equal(config.headers['x-product'], 'WorkBuddy');
    assert.equal(config.headers['x-agent-purpose'], 'conversation');
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
    rmSync(installDir, { recursive: true, force: true });
  }
});

test('桥：本地限流 reject 模式 —— 上限 N 时上游恰好收到 N 条，第 N+1 条 429 + Retry-After', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['rl-model']);
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: stub.base,
      WORKBUDDY_RATE_LIMIT_RPM: '2',
      WORKBUDDY_RATE_LIMIT_MODE: 'reject',
    },
    { auth: READABLE_FAKE_AUTH },
  );
  const chat = () => fetch(bridge.baseUrl + '/v1/chat/completions', {
    method: 'POST',
    headers: { ...auth, 'content-type': 'application/json' },
    body: JSON.stringify({ model: 'rl-model', messages: [{ role: 'user', content: 'hi' }] }),
    signal: AbortSignal.timeout(15000),
  });
  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1'); // 预热目录（不打 chat，不消耗许可）

    const r1 = await chat();
    const r2 = await chat();
    const r3 = await chat();
    await r1.text(); await r2.text(); await r3.text();

    assert.equal(r1.status, 200);
    assert.equal(r2.status, 200);
    assert.equal(r3.status, 429, '第 3 条必须被限流拒绝');
    assert.ok(Number(r3.headers.get('retry-after')) >= 1, 'Retry-After 头必须存在且 ≥1 秒');
    assert.equal(stub.seen.length, 2, '上游恰好收到 2 条 —— 被限流的请求不得打上游');

    // 账本归因：被限流的请求要留下 rate_limited 痕迹（控制台据此可见）
    await new Promise((r) => setTimeout(r, 100)); // 等账本落盘
    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8');
    assert.match(ledger, /rate_limited/, '账本必须记录限流归因');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：本地限流 queue 模式 —— 并发请求按最小间隔排队放行，不拒绝', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['rl2-model']);
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: stub.base,
      WORKBUDDY_RATE_LIMIT_MIN_INTERVAL_MS: '400',
      WORKBUDDY_RATE_LIMIT_MODE: 'queue',
    },
    { auth: READABLE_FAKE_AUTH },
  );
  const chat = () => fetch(bridge.baseUrl + '/v1/chat/completions', {
    method: 'POST',
    headers: { ...auth, 'content-type': 'application/json' },
    body: JSON.stringify({ model: 'rl2-model', messages: [{ role: 'user', content: 'hi' }] }),
    signal: AbortSignal.timeout(20000),
  });
  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1');

    const t0 = Date.now();
    const rs = await Promise.all([chat(), chat(), chat()]); // 并发：必须被串行化排队
    const elapsed = Date.now() - t0;
    for (const r of rs) {
      assert.equal(r.status, 200, 'queue 模式不得拒绝');
      await r.text();
    }
    assert.equal(stub.seen.length, 3, '三条最终都要发往上游');
    // 第 1 条立即、第 2 条等 ~400ms、第 3 条等 ~800ms —— 明显长于"无排队"的几十毫秒
    assert.ok(elapsed >= 700, `并发三条在 400ms 最小间隔下应排队 ≥700ms（实测 ${elapsed}ms）`);
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：开销头与进程计数 —— 响应带 X-WorkBuddy-Overhead-Ms，/health 报 process 段', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['ov-model']);
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    /*
     * 带鉴权：这里要的是"一次真实的 200 请求"，不是靠就绪探测顺带打的那一次。
     * 旧断言依赖了探测请求被计入进程计数（探测现在改用 /v1/identity，明确不计数）。
     */
    await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth });

    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'ov-model', messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    const raw = res.headers.get('x-workbuddy-overhead-ms');
    const overhead = Number(raw);
    assert.ok(raw !== null && Number.isFinite(overhead) && overhead >= 0,
      `对话响应必须带 ≥0 的开销头（实测 ${raw}）`);
    await res.text();

    // /health 的进程计数：真实请求入账、探活不入账
    const health = await fetch(bridge.baseUrl + '/health', { headers: auth, signal: AbortSignal.timeout(10000) }).then((r) => r.json());
    assert.equal(health.ok, true);
    assert.ok(health.process && typeof health.process.requests === 'number', '/health 必须带 process 段');
    assert.ok(health.process.requests >= 2, `进程计数应 ≥2（models 预热 + chat），实测 ${health.process.requests}`);
    assert.ok((health.process.byStatus['200'] || 0) >= 2, '状态码分布应含 200');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：在途请求可见 —— 成功 / 失败 / 客户端断开三条路径都正确登记与释放', { timeout: 120_000 }, async () => {
  // stub 上游可以"挂起"（等测试放行才响应），用来制造稳定的"进行中"观察窗口。
  let releaseHold = null;
  let holdGate = new Promise((r) => { releaseHold = r; });
  let mode = 'ok';
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [{ id: 'act-model', maxInputTokens: 128000, maxOutputTokens: 4096 }] } }));
    }
    if (path === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    if (path === '/v2/chat/completions') {
      req.resume();
      (async () => {
        await holdGate; // 「挂起」：模拟长回答 / 卡死中的上游
        if (mode === 'fail') {
          res.writeHead(500, { 'content-type': 'application/json' });
          return res.end(JSON.stringify({ code: 50000, msg: 'boom' }));
        }
        res.writeHead(200, { 'content-type': 'text/event-stream' });
        res.write('data: {"choices":[{"delta":{"content":"ok"}}]}\n\n');
        res.write('data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4}}\n\n');
        res.end('data: [DONE]\n\n');
      })();
      return;
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: `http://127.0.0.1:${upstream.address().port}` },
    { auth: READABLE_FAKE_AUTH },
  );

  const reqs = () => fetch(bridge.baseUrl + '/v1/requests', { headers: auth, signal: AbortSignal.timeout(5000) }).then((r) => r.json());
  const waitFor = async (pred, label) => {
    const deadline = Date.now() + 8000;
    while (Date.now() < deadline) {
      const d = await reqs();
      if (pred(d)) return d;
      await new Promise((r) => setTimeout(r, 100));
    }
    throw new Error(`等待超时：${label}`);
  };
  const resetGate = () => { holdGate = new Promise((r) => { releaseHold = r; }); };
  const chat = (signal) => fetch(bridge.baseUrl + '/v1/chat/completions', {
    method: 'POST',
    headers: { ...auth, 'content-type': 'application/json' },
    body: JSON.stringify({ model: 'act-model', messages: [{ role: 'user', content: 'hi' }] }),
    signal,
  });

  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1'); // 预热目录

    // ① 成功路径：登记 → 放行 → 释放
    mode = 'ok'; resetGate();
    const p1 = chat(AbortSignal.timeout(30000));
    const seen = await waitFor((d) => d.active.length === 1, '出现进行中条目');
    assert.equal(seen.active[0].model, 'act-model');
    assert.ok(seen.active[0].id, '进行中条目必须带 id');
    assert.ok(typeof seen.active[0].runningMs === 'number' && seen.active[0].runningMs >= 0,
      'runningMs 必须存在（UI 的「已运行」时长靠它）');
    assert.ok(typeof seen.activeAlertMs === 'number' && seen.activeAlertMs > 0,
      'activeAlertMs 必须随响应带回（阈值由桥单点定义）');
    releaseHold();
    const r1 = await p1; await r1.text();
    assert.equal(r1.status, 200);
    await waitFor((d) => d.active.length === 0, '成功后被释放');

    // ② 失败路径：上游 500 → 同样释放
    mode = 'fail'; resetGate();
    const p2 = chat(AbortSignal.timeout(30000));
    await waitFor((d) => d.active.length === 1, '失败场景出现进行中条目');
    releaseHold();
    const r2 = await p2; await r2.text();
    assert.equal(r2.status, 500);
    await waitFor((d) => d.active.length === 0, '失败后被释放');

    // ③ 客户端断开：abort → 同样释放（注册表不得泄漏），且必须留下账本记录
    mode = 'ok'; resetGate();
    const usageFile = join(bridge.dir, 'usage.jsonl');
    const usageCount = () => {
      try { return readFileSync(usageFile, 'utf8').split('\n').filter(Boolean).length; } catch { return 0; }
    };
    const usageBefore = usageCount();
    const ac = new AbortController();
    const p3 = chat(ac.signal).catch(() => null);
    await waitFor((d) => d.active.length === 1, '断开场景出现进行中条目');
    ac.abort();
    await p3;
    await waitFor((d) => d.active.length === 0, '客户端断开后被释放');
    const usageDeadline = Date.now() + 8000;
    while (usageCount() <= usageBefore && Date.now() < usageDeadline) {
      await new Promise((r) => setTimeout(r, 100));
    }
    assert.ok(usageCount() > usageBefore, '客户端断开后该请求仍必须记账（账本上不能静默消失）');
  } finally {
    try { releaseHold(); } catch { /* 忽略 */ }
    await bridge.stop();
    try { upstream.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：count_tokens —— 规范同形、纯本地估算（不打上游）、中文按字计', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['ct-model']);
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  const countTokens = (payload) => fetch(bridge.baseUrl + '/v1/messages/count_tokens', {
    method: 'POST',
    headers: { ...auth, 'content-type': 'application/json' },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(10000),
  });
  try {
    // 中文：每字 ≥ 1 token（旧的"字节/4"会把中文算少一半以上）
    const cn = await countTokens({ model: 'ct-model', messages: [{ role: 'user', content: '你好世界'.repeat(25) }] });
    assert.equal(cn.status, 200);
    const cnBody = await cn.json();
    assert.ok(typeof cnBody.input_tokens === 'number' && cnBody.input_tokens >= 100,
      `中文 100 字应估算 ≥100 token（实测 ${cnBody.input_tokens}）`);

    // ASCII：≈ 4 字符/token（400 字符的 system ≈ 100）
    const en = await countTokens({ model: 'ct-model', system: 'a'.repeat(400), messages: [{ role: 'user', content: 'hi' }] });
    const enBody = await en.json();
    assert.ok(enBody.input_tokens >= 100 && enBody.input_tokens <= 120,
      `400 个 ASCII 字符应估算 ≈100–120（实测 ${enBody.input_tokens}）`);

    // 纯本地：这个端点一条请求都不该打到上游
    assert.equal(stub.seen.length, 0, 'count_tokens 不得触达上游（没有 tokenizer 可打）');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：客户端凭据分层 —— key 鉴权、账本归因、独立限流桶', { timeout: 120_000 }, async () => {
  const stub = await startStubUpstream(['ck-model']);
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: stub.base,
      WORKBUDDY_CLIENT_KEYS: 'key-aaa,key-bbb',
      WORKBUDDY_RATE_LIMIT_RPM: '2',
      WORKBUDDY_RATE_LIMIT_MODE: 'reject',
    },
    { auth: READABLE_FAKE_AUTH },
  );
  const chat = (token) => fetch(bridge.baseUrl + '/v1/chat/completions', {
    method: 'POST',
    headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' },
    body: JSON.stringify({ model: 'ck-model', messages: [{ role: 'user', content: 'hi' }] }),
    signal: AbortSignal.timeout(15000),
  });
  try {
    // ① LOCAL_TOKEN 仍然万能（管理面 / 控制台用它）
    const rLocal = await chat(TOKEN);
    assert.equal(rLocal.status, 200, 'LOCAL_TOKEN 必须仍然可用');
    await rLocal.text();

    // ② client key 可用；未登记的 key 401
    const rA = await chat('key-aaa');
    assert.equal(rA.status, 200, '已登记的 client key 应被接受');
    await rA.text();
    const rBad = await chat('key-wrong');
    assert.equal(rBad.status, 401, '未登记的 key 必须 401');
    await rBad.text();

    // ③ per-key 限流：key-aaa 的桶打满 → 429；key-bbb 的桶独立不受影响
    const rA2 = await chat('key-aaa');
    assert.equal(rA2.status, 200);
    await rA2.text();
    const rA3 = await chat('key-aaa');
    assert.equal(rA3.status, 429, 'key-aaa 第 3 条应被自己的桶限流');
    await rA3.text();
    const rB1 = await chat('key-bbb');
    assert.equal(rB1.status, 200, 'key-bbb 的桶独立，不受 key-aaa 打满影响');
    await rB1.text();

    // ④ 账本归因：client key 的记录带「哈希前 8 位」，明文绝不落账
    await new Promise((r) => setTimeout(r, 100));
    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8')
      .split('\n').filter(Boolean).map((l) => JSON.parse(l));
    const expected = createHash('sha256').update('key-aaa').digest('hex').slice(0, 8);
    assert.ok(ledger.some((l) => l.client === expected), 'key-aaa 的记录必须带哈希前 8 位归因');
    assert.ok(ledger.some((l) => l.client === 'local'), 'LOCAL_TOKEN 的记录归因为 local');
    assert.ok(!ledger.some((l) => String(l.client || '').includes('key-aaa')), '明文 key 不得出现在账本');

    // ⑤ client key 只能聊天：管理面（切号 / 删凭据 / 清账本 / 登录 / 签到）必须 403
    const mgmt = (path, method, token) => fetch(bridge.baseUrl + path, {
      method,
      headers: { authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(10000),
    });
    for (const [path, method] of [
      ['/v1/auth/source', 'GET'],
      ['/v1/auth/credentials', 'GET'],
      ['/v1/auth/source', 'POST'],
      ['/v1/usage', 'DELETE'],
      ['/v1/checkin', 'POST'],
    ]) {
      const res = await mgmt(path, method, 'key-bbb');
      assert.equal(res.status, 403, `${method} ${path} 不应接受 client key`);
      await res.text();
    }
    // 改「客户端一键拉取给哪些模型」是持久化设置，不属于"聊天"能力。
    const setDefault = await fetch(bridge.baseUrl + '/v1/models/default', {
      method: 'POST',
      headers: { authorization: 'Bearer key-bbb', 'content-type': 'application/json' },
      body: JSON.stringify({ value: 'curated' }),
      signal: AbortSignal.timeout(10000),
    });
    assert.equal(setDefault.status, 403, 'client key 不能改桥的默认模型视图');
    await setDefault.text();

    const localSource = await mgmt('/v1/auth/source', 'GET', TOKEN);
    assert.equal(localSource.status, 200, 'LOCAL_TOKEN 仍必须能访问管理面');
    await localSource.text();

    /*
     * ⑥ `/health` 的账号明细必须按调用方分层（issue #32 后续发现的泄露）。
     *
     * `/health.autoCheckin.accounts[]` 里有本机每个已登录账号的 uid 与昵称 ——
     * 那是账号枚举能力，和 `/v1/checkin/accounts` 同一级别，而后者已经明确挡在
     * 管理面闸门后。可 `/health` 是**所有**调用方都能打的探活端点，于是只拿到
     * 一把 chat-only key 的人也能把本机账号列出来。
     *
     * 钉住：local 拿完整明细，client key 只拿"跑没跑 / 结果"这两项非身份字段。
     */
    const health = async (token) => (await fetch(`${bridge.baseUrl}/health`, {
      headers: { authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(8000),
    })).json();
    const healthLocal = await health(TOKEN);
    const healthClient = await health('key-bbb');

    /*
     * `credential` / `auth` 里的账号标识也属于管理面信息：
     *   · `desktopUserId` / `plugin.uids[]` / `plugin.activeUid` 能一次列出本机所有账号；
     *   · `auth.userId` 是当前号的 sub。
     * local 视图必须保留（面板要靠它显示"桌面 vs 桥"是否同一个钱包），
     * client key 一律看不到。
     */
    const asText = JSON.stringify(healthClient || {});
    for (const field of ['"uids"', '"activeUid"', '"userId"', '"desktopUserId"', '"storeDir"']) {
      assert.equal(asText.includes(field), false,
        `client key 的 /health 里不该出现 ${field}：${asText.slice(0, 400)}`);
    }
    /*
     * 本机绝对路径同样不该出现：`C:\Users\<系统用户名>\…` 本身就是身份信息，
     * 而 client key 只需要 `storeMode`（dpapi / file / memory）。
     */
    assert.doesNotMatch(asText, /[A-Za-z]:\\\\Users|[A-Za-z]:\\Users|\/Users\/|\/home\//,
      `client key 的 /health 里不该出现本机路径：${asText.slice(0, 400)}`);
    // 但"有没有可用凭据 / 是不是能登录"这类判断依据必须留着，否则客户端没法给对的引导
    assert.equal(typeof healthClient?.credential?.configured, 'string',
      'client 视图仍要告诉客户端凭据来源配置（引导登录要用）');
    assert.equal(typeof healthClient?.credential?.pluginCount, 'number',
      'client 视图仍要给出插件凭据数量（不含 uid）');
    assert.equal(typeof healthClient?.auth?.source, 'string', 'client 视图需要知道来源，才能说清是谁在供模型');
    // local 视图反过来必须有账号字段，证明不是"两处都剥光"
    assert.ok(Object.hasOwn(healthLocal?.credential || {}, 'desktopUserId'),
      'local 视图必须保留 desktopUserId（面板要对照桌面与桥是否同一个号）');
    assert.ok(Object.hasOwn(healthLocal?.auth || {}, 'userId'),
      'local 视图必须保留 auth.userId');

    const auto = healthClient?.autoCheckin;
    if (auto && typeof auto === 'object') {
      assert.equal(auto.accounts, undefined,
        `client key 不得从 /health 读到账号明细：${JSON.stringify(auto)}`);
      assert.equal(auto.key, undefined, 'client key 不应看到账号 key');
      assert.equal(auto.label, undefined, 'client key 不应看到账号昵称');
      assert.doesNotMatch(JSON.stringify(auto), /"label"|"key"\s*:/,
        `client 视图里不该出现任何账号标识：${JSON.stringify(auto)}`);
    }
    // 反过来：完整视图确实会带 accounts（有结果时），证明分层不是"两处都空"
    if (healthLocal?.autoCheckin?.accounts) {
      assert.ok(Array.isArray(healthLocal.autoCheckin.accounts),
        'local 视图的 accounts 必须是数组');
    }
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 畸形 `Host` 头必须回 400，**进程必须活着**。
 *
 * 踩过的坑：`handleRequest` 里 `new URL(req.url, 'http://' + req.headers.host)`
 * 原先在 `try` **之外**，而 Host 是客户端可控的 —— `new URL()` 对
 * `Host: bad host with spaces` 抛 `ERR_INVALID_URL`，异常没被捕获，
 * Node 直接退出进程（实测 exitCode=1）。也就是说**任何能访问本机端口的进程
 * 用一条请求就能把桥打死**，之后控制台/插件只会显示「桥未运行」。
 *
 * 用原始 socket 发：`fetch` 发不出自定义 Host（Fetch 规范把它列为禁止头），
 * 用它测这条只会得到假阴性。
 */
test('桥：畸形 Host 头回 400，且进程不被带走', { timeout: 30_000 }, async () => {
  const bridge = await startBridge();
  try {
    const port = Number(new URL(bridge.baseUrl).port);
    const status = await rawStatus(port, '/v1/models', { Host: 'bad host with spaces' });
    assert.equal(status, 400, '畸形 Host 应当按非法请求挡下（400）');

    await new Promise((r) => setTimeout(r, 300));
    const health = await fetch(`${bridge.baseUrl}/health`, {
      headers: { authorization: `Bearer ${TOKEN}` }, signal: AbortSignal.timeout(3000),
    });
    assert.ok(health.status > 0, '桥必须还活着 —— 畸形 Host 不该让进程退出');
    assert.ok(
      !/ERR_INVALID_URL|Unhandled/i.test(bridge.out()),
      `输出里不该有未捕获异常：\n${bridge.out().slice(-300)}`,
    );
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 上游回 **HTTP 200 但内容不是 SSE**（典型：网关把错误包成 200 的 HTML）时，
 * 桥必须**记失败**，不能回 200 + 空内容。
 *
 * 踩过的坑：非流式路径在 `aggregateStream()` 之后**无条件** `ok: true`，
 * 于是上游给一坨 HTML 时，客户端拿到的是「结构完整但 content 为空」的成功响应，
 * 账本记 `{"ok":true,"promptTokens":0,"completionTokens":0}` ——
 * 用户以为模型没说话，控制台的成功率还把它算作成功。**静默错数据**比报错更难查。
 *
 * `choices: []` 是同一类：一个 SSE 块都没解析出内容。
 */
test('桥：上游 200 但不是 SSE → 记失败，不回「空回答成功」', { timeout: 30_000 }, async () => {
  const stub = await startStubUpstream(['stub-model'], { chatRaw: '<html>gateway error</html>' });
  /*
   * **必须用 READABLE_FAKE_AUTH**：默认的 FAKE_AUTH 是扁平的（刻意用来复现
   * 「凭据异常」），桥读到它会直接 500 —— 那样断言会因为「请求压根没走到 chat
   * 路径」而变绿，是假绿。第一版就是这么写的，靠打印实际响应才发现。
   */
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
    });
    assert.ok(res.status >= 400, `上游返回非 SSE 时不能回 200（实际 ${res.status}）`);

    await new Promise((r) => setTimeout(r, 300));
    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8')
      .split('\n').filter(Boolean).map((l) => JSON.parse(l));
    const last = ledger[ledger.length - 1];
    assert.equal(last.ok, false, '账本必须记失败 —— 否则控制台把它算作成功（静默错数据）');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 账本超过 `MAX_USAGE_LINES`(2000) 时的**截断路径** —— 这条路径此前从未被执行过。
 *
 * 它做的是「重写整份文件」，而原来是直接 `writeFileSync` 覆盖：进程正好在这时
 * 被杀 / 断电就留下半份文件，丢的是用户自己的用量历史（项目里没有第二份副本）。
 * 现在改成「写临时文件 + rename」原子替换。
 *
 * 断言里那句「每一行都必须是合法 JSON」就是用来抓半截行的：
 * 非原子写入一旦发生，文件末尾会出现一行断掉的 JSON。
 */
test('桥：账本截断保留最近一半，且每行仍是合法 JSON（原子替换）', { timeout: 30_000 }, async () => {
  const stub = await startStubUpstream(['stub-model']);
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    const file = join(bridge.dir, 'usage.jsonl');
    const pre = Array.from({ length: 2001 }, (_, i) => JSON.stringify({
      t: Date.now() - (2001 - i) * 1000, model: 'pre', stream: false, ms: 1, ok: true,
    }));
    writeFileSync(file, `${pre.join('\n')}\n`);

    await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
    });
    await new Promise((r) => setTimeout(r, 400));

    const lines = readFileSync(file, 'utf8').trim().split('\n').filter(Boolean);
    assert.ok(lines.length <= 1002, `截断后应保留最近一半，实际 ${lines.length} 行`);
    assert.ok(lines.length >= 900, `不该把账本清空，实际 ${lines.length} 行`);
    for (const l of lines) JSON.parse(l); // 半截行会在这里抛
    assert.ok(!existsSync(`${file}.tmp`), '临时文件必须被 rename 掉，不该留在目录里');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * Anthropic 流式：上游把 `function.name` **分片**下发时，工具名必须拼完整。
 *
 * 踩过的坑：slot 建立时把首片写进了 `name`，追加的守卫却是 `!slot.name` ——
 * 首片非空，所以除首片外的分片全被丢掉，客户端拿到的是截断的名字（`get_`），
 * 工具调用必然失败。`+=` 本身就说明这里预期分片到达，两者自相矛盾。
 *
 * 附带一层：`content_block_start` 原先在**建槽时**就发出去了，里面带着当时那个
 * 半截名字 —— 所以光把守卫改掉不够，得把 start 推迟到名字收齐（参数开始到达）。
 */
test('桥：Anthropic 流式工具名分片必须拼完整（不能只留首片）', { timeout: 30_000 }, async () => {
  const sse = [
    'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"id":"call_1","type":"function","function":{"name":"get_"}}]}}]}',
    'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"name":"weather"}}]}}]}',
    'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{\\"city\\":"}}]}}]}',
    'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\"SF\\"}"}}]},"finish_reason":"tool_calls"}],"usage":{"prompt_tokens":5,"completion_tokens":6}}',
    'data: [DONE]',
    '',
  ].join('\n\n');
  const stub = await startStubUpstream(['stub-model'], { chatRaw: sse, chatType: 'text/event-stream' });
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/messages`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json', 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: 'stub-model', max_tokens: 64, stream: true,
        messages: [{ role: 'user', content: 'weather?' }],
      }),
    });
    const text = await res.text();
    assert.match(text, /"name":"get_weather"/, `工具名必须拼完整；实际输出里没有 get_weather：\n${text.slice(0, 400)}`);
    assert.ok(!/"name":"get_"/.test(text), '不能把首片当成完整名字发出去');
    assert.ok(text.includes('event: message_stop'), '流必须正常收尾');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：OpenAI 路径的超长 MCP 工具名必须缩短后转发（LiteLLM 会走这条）', { timeout: 30_000 }, async () => {
  const longName = 'mcp__agentflow_session__agentflow__project_business_domain_history';
  assert.ok(longName.length > 64);
  const stub = await startStubUpstream(['stub-model']);
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'stub-model',
        messages: [{ role: 'user', content: 'hi' }],
        tools: [{
          type: 'function',
          function: { name: longName, description: 'history', parameters: { type: 'object', properties: {} } },
        }],
      }),
    });
    assert.equal(res.status, 200, `桥不应再本地拒绝长工具名：${await res.clone().text()}`);
    assert.ok(stub.seen.length >= 1, '上游没收到请求');
    const upstreamBody = JSON.parse(stub.seen[0].body);
    const upstreamName = upstreamBody.tools?.[0]?.function?.name;
    assert.ok(upstreamName && upstreamName.length <= 64,
      `上游工具名必须 ≤64，实际 ${upstreamName} (${upstreamName?.length})`);
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * Anthropic `tool_result` 里的图片**不能静默丢掉**。
 *
 * Claude Code 的截图工具把图放在 `tool_result.content` 的 image 块里。
 * 桥原先只挑 `type:"text"` 的块（`anthropicToolResultText` 的 filter），
 * 于是图片**不报错地消失** —— 模型"看不见图"，排查时毫无线索。
 *
 * 与 Responses 侧同源的坑（那边是 `JSON.stringify` 成纯文本，代价 187 倍；
 * 这边是直接丢，代价是功能没了）。两处都已改成走内容块数组。
 */
test('桥：Anthropic tool_result 里的图片必须转发（不能静默丢）', { timeout: 30_000 }, async () => {
  const stub = await startStubUpstream(['stub-model'], { visionModels: ['stub-model'] });
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_ANTHROPIC_MODEL: 'deepseek-v4.1-flash' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const dataUri = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUg==';
    const res = await fetch(`${bridge.baseUrl}/v1/messages`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json', 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: 'stub-model',
        max_tokens: 64,
        stream: false,
        messages: [
          { role: 'user', content: 'screenshot it' },
          {
            role: 'assistant',
            content: [{ type: 'tool_use', id: 'toolu_1', name: 'screenshot', input: {} }],
          },
          {
            role: 'user',
            content: [
              {
                type: 'tool_result',
                tool_use_id: 'toolu_1',
                content: [
                  { type: 'text', text: 'captured' },
                  { type: 'image', source: { type: 'base64', media_type: 'image/png', data: 'iVBORw0KGgoAAAANSUhEUg==' } },
                ],
              },
            ],
          },
        ],
      }),
    });
    assert.equal(res.status, 200);

    const sent = stub.seen.find((s) => s.body.includes('toolu_1'));
    assert.ok(sent, '上游没收到带 tool_result 的请求');
    const body = JSON.parse(sent.body);
    const toolMsg = body.messages.find((m) => m.role === 'tool');
    assert.ok(toolMsg, '缺 role:"tool" 消息');

    assert.ok(Array.isArray(toolMsg.content),
      `tool_result 含图片时必须回内容块数组，实际是 ${typeof toolMsg.content}（图片被静默丢掉了）`);
    const img = toolMsg.content.find((p) => p.type === 'image_url');
    assert.ok(img, '图片丢了：tool_result 里的 image 块必须转成 image_url');
    assert.equal(img.image_url.url, dataUri, 'base64 图片要按 data URI 原样透传');
    assert.equal(toolMsg.content.find((p) => p.type === 'text')?.text, 'captured',
      '同一条 tool_result 里的文本块要保留');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 令牌过期瞬间的并发请求，**只该刷新一次**（单飞）。
 *
 * 为什么必须有：响应里可能带**轮换后的 refreshToken**，后到的请求拿的是已经
 * 作废的旧令牌 —— 必然失败，于是写 `lastRefreshFailedAt`，把接下来 15 秒内
 * **所有**刷新都挡住（包括本该成功的）。确定的代价是每次过期多打 N-1 次上游
 * 刷新；更坏的推测是上游对 refreshToken 做「重复使用即吊销」检测时会话被吊销。
 *
 * 限流**不**会替这里串行化（两个阈值默认都是 0，直接返回），所以并发是真的并行。
 *
 * 桩的刷新端点故意慢 200ms：否则并发请求会前后错开、第一个刷完第二个才发现
 * 令牌已新鲜，「没做单飞」也能凑出 1 次，用例就白写了。
 */
test('桥：令牌过期瞬间的 5 个并发请求只刷新一次', { timeout: 30_000 }, async () => {
  const stub = await startStubUpstream(['stub-model'], { refreshDelayMs: 200 });
  const nearExpiry = {
    auth: {
      accessToken: 'fake-access-token',
      refreshToken: 'fake-refresh-token',
      domain: 'example.invalid',
      expiresAt: Date.now() + 60_000, // < 5 分钟 skew → 每个请求都会先判过期
    },
  };
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: nearExpiry });
  try {
    const one = () => fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
    }).then((r) => r.text());
    /*
     * 先确认请求**真的成功了**再数刷新次数。
     *
     * 为什么：这条用例原本只断言「刷新 1 次」。如果因为环境原因（端口冲突、
     * 凭据没写进去、上游桩没起来）请求根本没走到刷新那一步，计数会是 **0** ——
     * 断言会红，但红的原因看不出是「设置坏了」还是「单飞坏了」。
     * 在门禁链里就遇到过 `实际 0 次`，单跑却 3/3 全过。把这一步显式断言出来，
     * 失败时能直接看到响应内容。
     */
    const bodies = await Promise.all([one(), one(), one(), one(), one()]);
    for (const b of bodies) {
      assert.ok(
        b.includes('"content"') || b.includes('"role"'),
        `每个请求都应当拿到正常的补全响应；实际是：${b.slice(0, 160)}`,
      );
    }
    await new Promise((r) => setTimeout(r, 300));

    assert.equal(stub.refreshCalls, 1, `5 个并发请求只该刷新一次，实际 ${stub.refreshCalls} 次`);
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 刷新响应**缺 expiresIn** 时也必须记住新令牌。
 *
 * 上游偶尔只回 accessToken、不回 expiresIn。旧实现把有效期算成 `now`，
 * `readStoredAuth` 下一秒就判定它已过期、回去读文件里的旧令牌 —— 于是每个
 * 请求都重新刷新一次（还会消耗/轮换 refreshToken），却仍然用旧令牌打上游。
 */
test('桥：刷新响应缺 expiresIn 时不能每请求重复刷新', { timeout: 30_000 }, async () => {
  const stub = await startStubUpstream(['stub-model'], { refreshOmitExpiresIn: true, refreshDelayMs: 0 });
  const nearExpiry = {
    auth: {
      accessToken: fakeJwt('same-sub'),
      refreshToken: 'fake-refresh-token',
      domain: 'example.invalid',
      expiresAt: Date.now() + 60_000, // < 5 分钟 skew → 请求前会先刷新
    },
  };
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: nearExpiry });
  try {
    const one = () => fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
    }).then((r) => r.text());
    const first = await one();
    assert.ok(first.includes('"content"'), `第一次请求应成功；实际：${first.slice(0, 160)}`);
    const second = await one();
    assert.ok(second.includes('"content"'), `第二次请求应成功；实际：${second.slice(0, 160)}`);
    assert.equal(stub.refreshCalls, 1,
      `刷新响应的有效期必须被记住，不能每个请求都刷；实际刷新 ${stub.refreshCalls} 次`);
    const seenAuth = stub.seen.map((s) => String(s.headers.authorization || ''));
    assert.ok(seenAuth.every((h) => h === 'Bearer refreshed-1'),
      `两次请求都应使用刷新后的令牌；实际 ${JSON.stringify(seenAuth)}`);
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 未配置本地令牌时，桥**不得**静默放行。
 *
 * 为什么必须钉住：`handleRequest` 的闸门写成
 * `if ((LOCAL_TOKEN || CLIENT_KEY_HASHES.size) && identifyClientId(req) === null)` ——
 * `LOCAL_TOKEN` 为空时整个 401 分支不执行，于是 `/health`、`/v1/chat/completions`
 * 等全部无鉴权可达。而夹具此前**永远**注入 `WORKBUDDY_LOCAL_TOKEN`（见 startBridge），
 * 这条默认路径从未被测过，所以漏洞能长期存在。
 *
 * 现场证据：用户直接 `node bridge/workbuddy-bridge.mjs`（不经控制台）时，
 * `config.mjs` 那份默认值不参与 —— 桥拿到的是空令牌，等于无鉴权。
 *
 * 断言的是**行为明确**：要么拒绝（401），要么启用了自动生成的替代令牌。
 * 唯一不允许的结果是「无令牌也 200」。
 */
test('桥：未配置 WORKBUDDY_LOCAL_TOKEN 时不得静默放行', { timeout: 30_000 }, async () => {
  const bridge = await startBridge({ WORKBUDDY_LOCAL_TOKEN: '' }, { auth: READABLE_FAKE_AUTH });
  try {
    // ① 不带任何凭据：绝不能 200
    const anon = await fetch(`${bridge.baseUrl}/v1/models`, { signal: AbortSignal.timeout(5000) });
    assert.notEqual(anon.status, 200,
      `未配置令牌时无凭据访问 /v1/models 不能成功（实际 ${anon.status}）—— 等于把账号对同机任意程序敞开`);

    // ② 不带凭据的对话请求更不能成功（这条会真的消耗上游额度）
    const anonChat = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(5000),
    });
    assert.notEqual(anonChat.status, 200,
      `未配置令牌时无凭据对话请求不能成功（实际 ${anonChat.status}）`);
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 自动生成的令牌必须**可见**（从启动日志里能读出来），否则用户配不上客户端。
 *
 * 「拒绝一切」是安全但不可用；「随机生成 + 打印出来」才是可用的安全。
 * 这条与上一条配对：一个管「不能放行」，一个管「不能把用户锁在门外」。
 */
test('桥：自动生成令牌时必须把值打印到启动日志（否则用户无法接入客户端）', { timeout: 30_000 }, async () => {
  const bridge = await startBridge({ WORKBUDDY_LOCAL_TOKEN: '' }, { auth: READABLE_FAKE_AUTH });
  try {
    // 生成出来的令牌必须能用于访问；并从启动输出里找得到，供用户复制
    const out = bridge.out();
    const m = out.match(/WORKBUDDY_LOCAL_TOKEN=([A-Za-z0-9._-]{16,})/);
    assert.ok(m, `启动日志里必须给出自动生成的令牌（实际输出：\n${out}\n）`);

    // 只验证令牌可用：`/` 是轻量身份端点，不抓目录、不打上游。
    // 原先进程会顺带请求 `/v1/models`，CI 上目录抓取可能超过 5 秒，导致
    // 这条**与目录无关**的用例被网络超时误伤。
    const ok = await fetch(`${bridge.baseUrl}/`, {
      headers: { authorization: `Bearer ${m[1]}` },
      signal: AbortSignal.timeout(5000),
    });
    assert.equal(ok.status, 200, '日志里打印的令牌必须真的能用');
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 账本的数值字段必须**永远是数字**，NaN / Infinity / 字符串都不能进磁盘。
 *
 * 为什么必须钉住：账本由控制台「用量统计」直接聚合。一个 NaN 进去，
 * `合计` 会变成 NaN 并让整张表显示成 NaN —— 用户看到的是"统计坏了"，
 * 而根因是上游回了脏 usage。`usageOf` 用 `Number(x) || 0` 兜底，这里把它钉死。
 *
 * 上游回 `"prompt_tokens": "abc"`（字符串）、`Infinity`、缺字段，都是真实可能
 * 出现的脏数据（网关版本漂移 / 代理改写）。
 */
test('桥：上游 usage 是脏数据（字符串 / NaN / 缺字段）时账本不得落 NaN', { timeout: 30_000 }, async () => {
  const stub = await startStubUpstream(['stub-model'], {
    // 一坨脏 usage：字符串、null、缺字段混在一起
    chatRaw: 'data: {"choices":[{"delta":{"content":"hi"}}]}\n\n'
      + 'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":"abc","completion_tokens":null,"total_tokens":1e999}}\n\n'
      + 'data: [DONE]\n\n',
    chatType: 'text/event-stream',
  });
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
    });
    await res.text();

    await new Promise((r) => setTimeout(r, 300));
    const rows = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8')
      .split('\n').filter(Boolean).map((l) => JSON.parse(l));
    assert.ok(rows.length > 0, '应当记了一条账');

    const last = rows[rows.length - 1];
    for (const k of ['promptTokens', 'completionTokens', 'ms']) {
      if (k in last) {
        assert.equal(typeof last[k], 'number', `${k} 必须是数字（实际 ${typeof last[k]}）`);
        assert.ok(Number.isFinite(last[k]), `${k} 不能是 NaN / Infinity（实际 ${last[k]}）`);
      }
    }
    // 原始 JSON 里也不能出现 NaN/Infinity 字面量（JSON.stringify 会把它们变成 null）
    assert.ok(!/NaN|Infinity/.test(JSON.stringify(last)), '账本行不得含 NaN/Infinity');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 提示缓存命中量必须记进账本。
 *
 * ## 为什么钉这条（2026-10-13 实测：26 倍的隐藏成本）
 *
 * 提示缓存是这条链路上**最大的单因素**，但它原先在账本里**完全不可见** ——
 * `usageOf()` 只记 promptTokens / completionTokens / credit，于是：
 *   · **成本**：同一批 >=40k 的请求里，未命中 **0.0142 积分/1k tokens**、
 *     已命中 **0.0005** —— 差 **26 倍**；93 条里 **6 条未命中就花掉 10.00 积分**，
 *     而 87 条命中合计才 10.20。这 10 个积分在控制台上与"正常用量"毫无区别。
 *   · **延迟**：实测冷缓存 TTFT 14.8s → 命中后 5.9s（2.5 倍）。
 *
 * 现在账本带 `cachedTokens` / `cacheMissTokens`，控制台就能把"贵且慢"的
 * 那几条单独标出来。
 *
 * ## 口径要点
 *
 * 上游对同一件事给了**多个别名**，且常与恒 0 的占位并存（实测 usage 里
 * `prompt_tokens_details.cached_tokens` 与顶层 `cached_tokens`、
 * `prompt_cache_hit_tokens` 同时存在）——所以取最大值，不是 `??` 链。
 * 这里就把"占位 0 不能挡住真实值"钉死。
 */
test('桥：提示缓存命中量必须记进账本（26 倍成本差异的来源）', { timeout: 30_000 }, async () => {
  const stub = await startStubUpstream(['stub-model'], {
    chatRaw: 'data: {"choices":[{"delta":{"content":"hi"}}]}\n\n'
      + 'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{'
      // 真实值藏在 details 里；顶层两个同义字段是**恒 0 的占位**（上游实测形状）
      + '"prompt_tokens":1000,"completion_tokens":5,"total_tokens":1005,'
      + '"cached_tokens":0,"prompt_cache_hit_tokens":0,'
      + '"prompt_cache_miss_tokens":120,'
      + '"prompt_tokens_details":{"cached_tokens":880}'
      + '}}\n\n'
      + 'data: [DONE]\n\n',
    chatType: 'text/event-stream',
  });
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
    });
    await res.text();

    await new Promise((r) => setTimeout(r, 300));
    const rows = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8')
      .split('\n').filter(Boolean).map((l) => JSON.parse(l));
    const last = rows[rows.length - 1];

    assert.equal(last.cachedTokens, 880,
      '必须取到 prompt_tokens_details.cached_tokens 的真实值，不能被顶层占位 0 挡住');
    assert.equal(last.cacheMissTokens, 120, '未命中计数要一并记下');
    assert.equal(last.promptTokens, 1000, '原有字段不受影响');
    assert.ok(!/NaN|Infinity/.test(JSON.stringify(last)), '账本行不得含 NaN/Infinity');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 上游**没报**缓存字段时，账本不得凭空写 0。
 *
 * 0 是"确实没命中"，缺字段是"上游没报"——两者混起来会让命中率统计失真
 * （拿"没报"当"未命中"会把命中率系统性压低）。所以缺失时字段应当**不出现**。
 */
test('桥：上游没报缓存字段时不得写 0（缺报 ≠ 未命中）', { timeout: 30_000 }, async () => {
  const stub = await startStubUpstream(['stub-model'], {
    chatRaw: 'data: {"choices":[{"delta":{"content":"hi"}}]}\n\n'
      + 'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":10,"completion_tokens":2,"total_tokens":12}}\n\n'
      + 'data: [DONE]\n\n',
    chatType: 'text/event-stream',
  });
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
    });
    await res.text();

    await new Promise((r) => setTimeout(r, 300));
    const rows = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8')
      .split('\n').filter(Boolean).map((l) => JSON.parse(l));
    const last = rows[rows.length - 1];

    assert.ok(!('cachedTokens' in last), '上游没报命中量时不该写 0');
    assert.ok(!('cacheMissTokens' in last), '上游没报未命中量时不该写 0');
    assert.equal(last.promptTokens, 10, '原有字段照常');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 超长错误原文必须被截断并压成单行。
 *
 * 上游的 401 会返回**整段 HTML**（APISIX 网关），若不截断：
 * ① 账本单行被撑到几十 KB；② 控制台「点失败标签复制错误详情」会复制出一坨 HTML。
 * `shortError` 同时做「压单行 + 截断 160」，这里双向钉住。
 */
test('桥：上游超长错误原文必须压成单行并截断（不得把整段 HTML 灌进账本）', { timeout: 120_000 }, async () => {
  /*
   * 超时给到 120 秒（而不是别的用例的 30 秒）：上游回 401 会**触发一次令牌刷新**，
   * 而刷新在测试桩上必然失败（桩没有 /v2/plugin/auth/token/refresh），
   * 走满 `refreshAuth` 的 8 秒超时 + 后续重试。这是**刻意保留的真实行为**
   * （生产里刷新成功就会重试），不该为了让测试快而去掉。
   */
  // 造一段带换行的长 HTML：既测截断，也测换行被压平
  const longHtml = '<html>\n  <head><title>401</title></head>\n  <body>\n'
    + 'x'.repeat(4000)
    + '\n  </body>\n</html>';
  const stub = await startStubUpstream(['stub-model'], { chatRaw: longHtml, chatStatus: 401, chatType: 'text/html' });
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
    });
    await res.text();
    assert.ok(res.status >= 400, '上游 401 时桥不能回 200');

    await new Promise((r) => setTimeout(r, 300));
    const rows = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8')
      .split('\n').filter(Boolean).map((l) => JSON.parse(l));
    const last = rows[rows.length - 1];
    assert.equal(last.ok, false, '必须记失败');
    assert.ok(typeof last.error === 'string' && last.error.length <= 201,
      `错误原文必须被截断到 160 字符左右（实际 ${last.error?.length}）`);
    assert.ok(!last.error.includes('\n'), '错误原文必须压成单行（换行会被账本/CSV 吃掉）');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/*
 * ── 401 的自诊断 ────────────────────────────────────────────────────────
 *
 * 背景：令牌默认值从固定串 `wb-local-bridge` 改成随机值之后，**所有老用户
 * 升级后都会撞 401** —— 他们的客户端配置里还存着旧口令。断得毫无预兆，
 * 且原响应体只有一句 `bad or missing token`，用户根本不知道该去哪找新值。
 *
 * 契约（三条同时成立）：
 *   ① 401 必须说明「可能是升级前的旧令牌」并指出去哪拿新值；
 *   ② **绝不能**把真实令牌写进响应体 —— 那等于给同机攻击者直接送答案；
 *   ③ 用对令牌的请求不受影响（提示只在失败路径上）。
 */
test('桥：401 必须自带排查指引（升级后旧令牌失效是高频场景）', { timeout: 30_000 }, async () => {
  const bridge = await startBridge();
  try {
    // 老用户升级后的典型状态：配置里还存着历史默认值
    const stale = await fetch(bridge.baseUrl + '/v1/models', {
      headers: { authorization: 'Bearer wb-local-bridge' },
    });
    assert.equal(stale.status, 401, '旧令牌必须被拒绝（这正是本次安全修复的目的）');

    const body = await stale.text();
    // ① 必须给出可操作指引
    assert.match(body, /bridge-token|-token|客户端接入|clients/,
      `401 响应体要指出去哪拿新令牌，实际是：${body.slice(0, 200)}`);
    assert.match(body, /upgrade|升级|旧|stale|changed|变/i,
      `401 响应体要说明「令牌可能变了」，实际是：${body.slice(0, 200)}`);
    /*
     * ③ 必须覆盖「填的就是文件里的新令牌、却仍然 401」这一种 ——
     * 它不是客户端填错，而是**在跑的桥**内存里还是升级前的旧令牌
     * （令牌文件可能由别的进程先创建：`config.mjs` 在模块求值时就会生成并落盘，
     * 跑测试/工具也会创建它）。只照「换客户端令牌」做会一直 401 转不出来，
     * 必须告诉用户「桥和控制台一起重启」。
     */
    assert.match(body, /重启/,
      `401 响应体要覆盖「令牌对但仍 401 → 重启桥与控制台」这一种，实际是：${body.slice(0, 300)}`);

    // ② 绝不能泄漏真实令牌。取启动日志里的自动生成值作为对照。
    const out = bridge.out();
    const real = out.match(/WORKBUDDY_LOCAL_TOKEN=([A-Za-z0-9._-]{16,})/)?.[1];
    if (real) {
      assert.ok(!body.includes(real), '401 响应体绝不能包含真实令牌（等于把答案送给攻击者）');
    }

    // ③ 用对令牌时正常，且提示不会污染成功响应
    const ok = await fetch(bridge.baseUrl + '/v1/models', { headers: auth });
    assert.equal(ok.status, 200, '正确令牌必须照常放行');
    const okBody = await ok.text();
    assert.ok(!/bridge-token|升级/.test(okBody), '成功响应里不该出现排查提示');
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：完全没带凭据时也要给指引（新用户第一次接入手忙脚乱）', { timeout: 30_000 }, async () => {
  const bridge = await startBridge();
  try {
    const res = await fetch(bridge.baseUrl + '/v1/models');
    assert.equal(res.status, 401);
    const body = await res.text();
    assert.match(body, /bridge-token|-token|客户端接入|clients/,
      `无凭据的 401 同样要指路，实际是：${body.slice(0, 200)}`);

    // 同样地，不许泄漏真实令牌
    const real = bridge.out().match(/WORKBUDDY_LOCAL_TOKEN=([A-Za-z0-9._-]{16,})/)?.[1];
    if (real) assert.ok(!body.includes(real), '401 响应体绝不能包含真实令牌');
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 确定性 400 必须**快速失败**，不许进退避重试。
 *
 * ## 为什么钉这条（2026-10-13 实测的 40 秒白等）
 *
 * 桥原先对所有 `400 code 11133` 一视同仁地跑 `TRANSIENT_400_DELAYS`
 * （1s+4s+10s+25s = **40 秒**）。但 11133 只是包装码，真因在 `extError.code`：
 * 日志取证显示 122 次 11133 **全是**确定性的
 * （`model_param_invalid` 116 + `invalid_reasoning_effort` 6），
 * 没有一次是瞬时故障 —— 109 个重试簇跑满 4 档后**照样**报错，
 * 纯等待累计 2460 秒（41 分钟）。用户感知就是「问一句，卡 40 秒，然后报错」。
 *
 * ## 口径
 *
 * 退避表被 `WORKBUDDY_TRANSIENT_400_DELAYS=30,30,30,30` 压到毫秒级：
 * 这样「不该重试」的用例能在 2 秒内证伪（真跑 40 秒的用例没人会保留）。
 * 断言不看耗时（CI 上机器慢会假红），而是看**打到上游的对话请求次数** ——
 * 确定性 400 必须**恰好 1 次**，一次都不许多打。
 */
test('桥：确定性 400（11133 + model_param_invalid）必须快速失败，不得退避重试 40 秒', { timeout: 60_000 }, async () => {
  const stub = await startStubUpstream(['stub-model'], {
    chatStatus: 400,
    chatType: 'application/json',
    chatRaw: JSON.stringify({
      code: 11133,
      msg: 'Invalid request parameters',
      extError: {
        code: 'model_param_invalid',
        message: 'the request parameters were rejected by the model provider',
        type: 'invalid_request_error',
      },
    }),
  });
  // 退避压到 30ms：若代码回退成"照旧重试"，本用例仍会重试 4 次，但只花 ~120ms，
  // 于是"上游命中次数"这条断言能在毫秒级抓住回归（不必等 40 秒）。
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_TRANSIENT_400_DELAYS: '30,30,30,30',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }], max_tokens: 8 }),
      signal: AbortSignal.timeout(20_000),
    });
    assert.equal(res.status, 400, '确定性 400 必须原样回给客户端');
    const text = await res.text();
    assert.match(text, /model_param_invalid/, '错误体要带上真因，便于用户改参数');

    const chatCalls = stub.seen.filter((s) => JSON.parse(s.body || '{}').model).length;
    assert.equal(chatCalls, 1,
      `确定性 400 只许打上游 1 次；实际 ${chatCalls} 次（重试回归了，用户会白等 40 秒）`);
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 真瞬时 400（11133 但**没有** extError 判据）必须**仍然重试**，并且能救回。
 *
 * 这条与上一条配对，缺一不可：
 *   · 上一条钉「不许对确定性错误瞎等」；
 *   · 这一条钉「不许矫枉过正，把真瞬时的也一并放弃」。
 *
 * 桩按 `chatSequence` 前 2 次回 400、第 3 次回正常 SSE —— 断言最终 200，
 * 证明重试链确实把请求救回来了（而不是只看日志里"有 retry"这种弱证据）。
 */
test('桥：真瞬时 400（11133 无 extError 判据）必须仍然重试并救回', { timeout: 60_000 }, async () => {
  const transient400 = JSON.stringify({ code: 11133, msg: 'Invalid request parameters' });
  const stub = await startStubUpstream(['stub-model'], {
    chatSequence: [
      { status: 400, type: 'application/json', raw: transient400 },
      { status: 400, type: 'application/json', raw: transient400 },
      {
        status: 200,
        type: 'text/event-stream',
        raw: 'data: {"choices":[{"delta":{"content":"ok"}}]}\n\n'
          + 'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4}}\n\n'
          + 'data: [DONE]\n\n',
      },
    ],
  });
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_TRANSIENT_400_DELAYS: '20,20,20,20',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }], max_tokens: 8 }),
      signal: AbortSignal.timeout(30_000),
    });
    assert.equal(res.status, 200, '瞬时 400 重试后必须成功');
    const body = await res.json();
    assert.equal(body.choices?.[0]?.message?.content, 'ok', '救回的响应内容要完整');

    const chatCalls = stub.seen.filter((s) => JSON.parse(s.body || '{}').model).length;
    assert.equal(chatCalls, 3, `应当恰好重试 2 次（共 3 次）；实际 ${chatCalls} 次`);
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * `WORKBUDDY_TRANSIENT_400_RETRY=0` 必须把 400 重试**整体**关掉（含真瞬时的）。
 *
 * 这是给"速度绝对优先"的用户留的出口：宁可立刻报错让客户端自己退避，
 * 也不要桥在这里替它等。默认开，所以必须有用例证明这个开关真的有效 ——
 * 否则它只是一个写在文档里、实际不生效的旋钮。
 */
test('桥：WORKBUDDY_TRANSIENT_400_RETRY=0 时连瞬时 400 也不重试', { timeout: 60_000 }, async () => {
  const stub = await startStubUpstream(['stub-model'], {
    chatStatus: 400,
    chatType: 'application/json',
    chatRaw: JSON.stringify({ code: 11133, msg: 'Invalid request parameters' }),
  });
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_TRANSIENT_400_DELAYS: '20,20,20,20',
    WORKBUDDY_TRANSIENT_400_RETRY: '0',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }], max_tokens: 8 }),
      signal: AbortSignal.timeout(20_000),
    });
    assert.equal(res.status, 400);
    const chatCalls = stub.seen.filter((s) => JSON.parse(s.body || '{}').model).length;
    assert.equal(chatCalls, 1, `开关关闭时必须一次就返回；实际打了 ${chatCalls} 次`);
  } finally {
    await bridge.stop();
    stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 瞬时 DNS / 建连失败必须**重试**，而不是直接 500。
 *
 * ## 为什么钉这条（2026-10-13 实测）
 *
 * 账本里有 20 条 `getaddrinfo ENOTFOUND www.workbuddy.ai`，其中 **17 条挤在同一个
 * 小时**——典型的解析器抖动（VPN/代理切换、DNS 缓存过期），不是域名不存在：
 * 同一台机器随后连测 12 次解析全部成功、中位 0.2ms。
 *
 * 桥原先的重试只认 `ECONNRESET|socket hang up|EPIPE`（keep-alive 复用被掐），
 * 对 DNS/建连这一族**一次都不重试**，直接把 500 丢给客户端。用户看到
 * 「本地桥连接失败」，实际只是抖了一下。
 *
 * ## 判据为什么看日志标记
 *
 * DNS 失败**没有外部可观测的"试了几次"**：两次尝试都解析不到同一个不存在的名字，
 * 客户端拿到的都是 500。所以判据取桥自己打的标记 ——
 * `transient transport failure` 只在**新加的那条重试分支**里出现，
 * 老代码（只认 ECONNRESET 那一族）永远不会打它。标记出现 = 这条分支真的生效了。
 *
 * 域名用 `.invalid`：RFC 2606 保留、**保证解析不了**，所以不依赖任何环境，
 * 也不会因为"碰巧解析成功"而假绿。
 */
test('桥：瞬时 DNS 失败必须走重试分支（不是直接 500）', { timeout: 60_000 }, async () => {
  const bridge = await startBridge({
    // RFC 2606 保留域名：保证 ENOTFOUND
    CODEBUDDY_ENDPOINT: 'http://workbuddy-bridge-test.invalid:8790',
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_TRANSPORT_RETRY_MS: '0',
    WORKBUDDY_LOG: '1',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }], max_tokens: 8 }),
      signal: AbortSignal.timeout(30_000),
    });
    // 域名确实不存在 → 最终仍然是失败（重试救不回来），但**必须**已经试过重试
    assert.ok(res.status >= 400, '解析不了的域名最终必须报错，不能假装成功');
    const out = bridge.out();
    assert.match(out, /transient transport failure/,
      `DNS 失败必须走重试分支（日志里应有 "transient transport failure"）。实际输出：\n${out.slice(-1500)}`);
    // 且错误原文要如实回给客户端，便于用户区分"域名配错"与"网络抖动"
    const text = await res.text();
    assert.match(text, /ENOTFOUND|getaddrinfo|EAI_AGAIN|ENOTFOUND/i,
      `错误体要带上真实原因，实际：${text.slice(0, 200)}`);
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 传输层瞬时失败**恢复后必须救回**（端到端）：第一次连接被粗暴断开、第二次正常。
 *
 * 与上一条互补：上一条证明"重试分支会被走到"，这一条证明"重试真的能救回请求"
 * （最终 200 + 正文完整，且上游恰好被打了 2 次）。
 *
 * 用 `req.socket.destroy()` 造错而不是"先关端口再抢时间起服务"：
 * 后者依赖时序，在 CI 上会随机红。
 */
test('桥：传输层瞬时失败重试后必须救回完整响应', { timeout: 60_000 }, async () => {
  let chatHits = 0;
  const srv = createServer((req, res) => {
    const p = new URL(req.url, 'http://127.0.0.1').pathname;
    if (p === '/v2/enterprises/personal/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [{ id: 'stub-model', maxInputTokens: 128000, maxOutputTokens: 4096 }] } }));
    }
    if (p === '/v3/config') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    if (p === '/v2/chat/completions') {
      req.resume();
      req.on('end', () => {
        chatHits += 1;
        if (chatHits === 1) { req.socket.destroy(); return; } // 第一次：粗暴断开
        res.writeHead(200, { 'content-type': 'text/event-stream' });
        res.write('data: {"choices":[{"delta":{"content":"recovered"}}]}\n\n');
        res.write('data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4}}\n\n');
        res.end('data: [DONE]\n\n');
      });
      return;
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));

  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: `http://127.0.0.1:${srv.address().port}`,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_TRANSPORT_RETRY_MS: '0',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }], max_tokens: 8 }),
      signal: AbortSignal.timeout(30_000),
    });
    assert.equal(res.status, 200, '瞬时传输失败重试后必须成功（而不是 500）');
    const body = await res.json();
    assert.equal(body.choices?.[0]?.message?.content, 'recovered', '救回的响应内容要完整');
    assert.equal(chatHits, 2, `应当恰好重试 1 次（共 2 次上游对话）；实际 ${chatHits} 次`);
  } finally {
    await bridge.stop();
    await new Promise((r) => srv.close(r));
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/*
 * ═══ 聊天路径的两条「不能把失败伪装成成功」═══════════════════════════════
 *
 * 另两条路径（Anthropic / Responses）早就修过同一类坑，只有 chat 这条漏了。
 * 日志取证：`stream interrupted` 在这条路径上有 21 条，另两条各 0 条 ——
 * 真实流量就在走这里。
 */

test('桥：流中途断掉时必须告诉客户端（不能只记一笔账就干净 EOF）', { timeout: 60_000 }, async () => {
  const srv = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path !== '/v2/chat/completions') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    res.writeHead(200, { 'content-type': 'text/event-stream' });
    res.write('data: {"id":"c1","model":"m","choices":[{"delta":{"content":"说到一半"}}]}\n\n');
    // 粗暴掐断：没有 finish_reason、没有 usage、没有 [DONE]
    setTimeout(() => res.destroy(), 30);
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));

  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: `http://127.0.0.1:${srv.address().port}`,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_TRANSPORT_RETRY_MS: '0',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }], stream: true }),
      signal: AbortSignal.timeout(30_000),
    });
    assert.equal(res.status, 200, '已经答应过是事件流，只能 200 + SSE');
    const text = await res.text();

    /*
     * 核心断言：客户端必须能看出"这一轮没跑完"。
     * 原先这条路径**一个字节都不写**就 res.end() —— 客户端在 200 事件流上看到
     * 一个干净的 EOF，dsh 的适配器把"有内容 + 无 finish_reason"判成
     * `{kind:'stop'}`，于是 agent 被告知"正常完成"，用户看到半句话就停、
     * 不报错也不重试。
     */
    assert.match(text, /"error"/,
      `流中途断了却没有任何错误信号（客户端只会看到一个干净的 EOF）。实际响应体：${JSON.stringify(text.slice(-300))}`);
    assert.match(text, /interrupted/i, '错误信息要说清是"上游流中途断了"');
    // 已收到的半截内容仍要带出去（便于排查）
    assert.match(text, /说到一半/, '已经收到的内容不该被丢掉');
    // 收尾信号：给了 error 之后补 [DONE]，客户端才好干净地结束解析
    assert.match(text, /\[DONE\]/, '错误之后要有 [DONE]，否则有的客户端会一直等');
  } finally {
    await bridge.stop();
    await new Promise((r) => srv.close(r));
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：流式遇到「有内容但干净半关」也必须报错（不能只修非流式）', { timeout: 60_000 }, async () => {
  /*
   * 与上一条（res.destroy 硬断）不同的失败形态：上游**正常收尾**，但既没有
   * finish_reason 也没有 [DONE]（代理超时后正常关闭、chunked 结束、网关漏发）。
   *
   * 旧实现只跟踪 `usage`，于是这条路径记 ok:true 且一个错误信号都不发；
   * dsh 的适配器看到干净 EOF + 有内容，判成 `stop` —— 用户看到半句话就停。
   * 非流式路径早就用 `completed === false` 修过，流式才是真实流量。
   */
  const srv = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path !== '/v2/chat/completions') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    res.writeHead(200, { 'content-type': 'text/event-stream' });
    res.write('data: {"id":"c1","model":"m","choices":[{"delta":{"content":"说到一半"}}]}\n\n');
    res.end(); // 干净半关：没有 finish_reason / usage / [DONE]
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));

  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: `http://127.0.0.1:${srv.address().port}`,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_TRANSPORT_RETRY_MS: '0',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }], stream: true }),
      signal: AbortSignal.timeout(30_000),
    });
    assert.equal(res.status, 200, '已经答应过是事件流，只能 200 + SSE');
    const text = await res.text();
    assert.match(text, /说到一半/, '已经收到的内容不该被丢掉');
    assert.match(text, /"error"/, '干净半关也必须补 error 帧，客户端才知道被截断');
    assert.match(text, /before completion/i, '错误信息要指出"流没跑完"');
    assert.match(text, /\[DONE\]/, 'error 之后要有 [DONE]，客户端才好干净地结束解析');

    // 账本同样要记失败：否则"回答为什么少了一半"在控制台上不可见
    const ledger = await (await fetch(`${bridge.baseUrl}/v1/requests?limit=5`, { headers: auth, signal: AbortSignal.timeout(8000) })).json();
    const last = (ledger.requests || [])[0];
    assert.equal(last?.ok, false, `流式截断必须记 ok:false。实际账本：${JSON.stringify(last)}`);
    assert.match(String(last?.error), /before completion/i);
  } finally {
    await bridge.stop();
    await new Promise((r) => srv.close(r));
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：非流式聚合遇到「有内容但没跑完」必须回 502，不能报成完整回答', { timeout: 60_000 }, async () => {
  const srv = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path !== '/v2/chat/completions') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
    }
    res.writeHead(200, { 'content-type': 'text/event-stream' });
    // **干净地**半关：有内容，但没有 finish_reason / usage / [DONE]
    res.end('data: {"id":"c1","model":"m","choices":[{"delta":{"content":"The answer is 4"}}]}\n\n');
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));

  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: `http://127.0.0.1:${srv.address().port}`,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_TRANSPORT_RETRY_MS: '0',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(30_000),
    });
    /*
     * 原先：`parsed > 0` 就放过 → 回 200 + `finish_reason:"stop"` + 半句内容，
     * 客户端以为回答说完了、不重试；账本还记成 ok:true 的 0/0 tokens 健康记录。
     */
    assert.equal(res.status, 502,
      '上游在吐了内容后干净地半关，必须按失败处理（回 200 会让客户端以为回答完整）');
    const j = await res.json();
    assert.match(JSON.stringify(j), /before completion|no parseable SSE data/i,
      `错误信息要指出"流没跑完"。实际：${JSON.stringify(j).slice(0, 300)}`);
  } finally {
    await bridge.stop();
    await new Promise((r) => srv.close(r));
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：max_completion_tokens 必须翻译成 max_tokens（不能静默丢掉输出上限）', { timeout: 60_000 }, async () => {
  let seen = null;
  const srv = createServer((req, res) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      const path = new URL(req.url, 'http://127.0.0.1').pathname;
      if (path !== '/v2/chat/completions') {
        res.writeHead(200, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
      }
      try { seen = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { seen = null; }
      res.writeHead(200, { 'content-type': 'text/event-stream' });
      res.end('data: {"id":"c1","model":"m","choices":[{"delta":{"content":"ok"}}]}\n\ndata: {"id":"c1","model":"m","choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n');
    });
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));

  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: `http://127.0.0.1:${srv.address().port}`,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_TRANSPORT_RETRY_MS: '0',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    // 只给新式字段：上限必须被翻译过去，而不是丢掉
    await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }], max_completion_tokens: 500 }),
      signal: AbortSignal.timeout(30_000),
    }).then((r) => r.text());
    assert.equal(seen?.max_tokens, 500,
      `max_completion_tokens=500 必须翻译成上游认的 max_tokens（否则输出上限静默消失，回合变成无上限）。实际 payload：${JSON.stringify(seen)?.slice(0, 200)}`);
    assert.equal('max_completion_tokens' in (seen || {}), false, '翻译后不该再把新式字段原样转发');

    // 两个都给时：以 max_tokens 为准（保留"避免语义冲突"的原意）
    await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }], max_tokens: 128, max_completion_tokens: 500 }),
      signal: AbortSignal.timeout(30_000),
    }).then((r) => r.text());
    assert.equal(seen?.max_tokens, 128, '两个都给时以 max_tokens 为准');
  } finally {
    await bridge.stop();
    await new Promise((r) => srv.close(r));
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});


test('桥：思考档位按实测表校验 —— 表外值剥掉、表内值保留', { timeout: 60_000 }, async () => {
  // deepseek-v4.1-flash 实测 6 档（不含 off，见 REASONING_EFFORTS_BY_MODEL）。
  // 客户端（老面板写死三档 / curl）发 off 会被上游确定性 400，桥应在出站前剥掉。
  const seen = [];
  const srv = createServer((req, res) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      const path = new URL(req.url, 'http://127.0.0.1').pathname;
      if (path !== '/v2/chat/completions') {
        res.writeHead(200, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ code: 0, data: { models: [] } }));
      }
      try { seen.push(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { seen.push(null); }
      res.writeHead(200, { 'content-type': 'text/event-stream' });
      res.end('data: {"id":"c1","model":"m","choices":[{"delta":{"content":"ok"}}]}\n\ndata: {"id":"c1","model":"m","choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n');
    });
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: `http://127.0.0.1:${srv.address().port}`,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_TRANSPORT_RETRY_MS: '0',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const call = (effort) => fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'deepseek-v4.1-flash', messages: [{ role: 'user', content: 'hi' }], reasoning_effort: effort }),
      signal: AbortSignal.timeout(30_000),
    }).then((r) => r.text());

    await call('off');
    assert.equal('reasoning_effort' in (seen.at(-1) || {}), false,
      '表外档位（off）必须在出站前剥掉，否则必然吃确定性 400');

    await call('high');
    assert.equal(seen.at(-1)?.reasoning_effort, 'high', '表内档位必须原样保留');
  } finally {
    await bridge.stop();
    await new Promise((r) => srv.close(r));
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：chat 错误体必须是 OpenAI 形状，且上游 401 不能被误认成本地令牌错', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['stub-model'], {
    chatRaw: JSON.stringify({ code: 11133, msg: 'the request parameters were rejected by the model provider', extError: { code: 'model_param_invalid' } }),
    chatStatus: 400,
    chatType: 'application/json',
  });
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(30_000),
    });
    assert.equal(res.status, 400);
    const body = await res.json();
    assert.ok(body.error?.message, '必须是 {error:{message}} 形状（客户端按 OpenAI 规范读）');
    assert.match(body.error.message, /rejected by the model provider/i);
    assert.equal(body.error.code, 'model_param_invalid', 'extError.code 要透出来，便于给出"换参数"而不是"重试"');
    assert.equal(body.error.type, 'invalid_request_error', '11133 是请求参数拒绝，不是上游 5xx');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }

  const stub401 = await startStubUpstream(['stub-model'], { chatRaw: '<html>401</html>', chatStatus: 401, chatType: 'text/html' });
  const bridge2 = await startBridge({ CODEBUDDY_ENDPOINT: stub401.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' }, { auth: READABLE_FAKE_AUTH });
  try {
    const res = await fetch(`${bridge2.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(60_000),
    });
    assert.equal(res.status, 502, '上游 401 不能原样回 401（那会被当成本地令牌错误）');
    const body = await res.json();
    assert.equal(body.error?.type, 'upstream_auth_error');
    assert.match(body.error?.message || '', /re-?login/i);
  } finally {
    await bridge2.stop();
    try { await stub401.close(); } catch { /* 忽略 */ }
    rmSync(bridge2.dir, { recursive: true, force: true });
  }
});
test('凭据缓存：登录文件改写后立即生效；上游请求带 Content-Length，账本记首字耗时', { timeout: 90_000 }, async () => {
  /*
   * readStoredAuth() 原先每个请求都读盘 + AES 解密 + JWT 解码。现在按
   * stat 指纹（mtime + size）缓存 —— 本用例钉住"缓存不能把换号/换令牌挡住"：
   * 用**同长度**的不同令牌改写文件，只靠 mtime 也必须立刻失效。
   */
  const stub = await startStubUpstream(['stub-model']);
  const authFileA = {
    auth: {
      accessToken: 'token-aaaaaaaa',
      refreshToken: 'refresh-token',
      domain: 'example.invalid',
      expiresAt: Date.now() + 30 * 86_400_000,
    },
  };
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: authFileA },
  );
  const chat = () => fetch(`${bridge.baseUrl}/v1/chat/completions`, {
    method: 'POST',
    headers: { ...auth, 'content-type': 'application/json' },
    body: JSON.stringify({ model: 'stub-model', stream: true, messages: [{ role: 'user', content: 'hi' }] }),
    signal: AbortSignal.timeout(30_000),
  });
  try {
    assert.equal((await chat()).status, 200);
    assert.equal(stub.seen.at(-1).headers.authorization, 'Bearer token-aaaaaaaa');
    // 未改写时连续请求：缓存命中也必须仍然是同一个令牌
    assert.equal((await chat()).status, 200);
    assert.equal(stub.seen.at(-1).headers.authorization, 'Bearer token-aaaaaaaa');

    const authFile = join(bridge.dir, 'fake-auth.info');
    writeFileSync(authFile, JSON.stringify({
      auth: {
        accessToken: 'token-bbbbbbbb',
        refreshToken: 'refresh-token',
        domain: 'example.invalid',
        expiresAt: Date.now() + 30 * 86_400_000,
      },
    }));
    // 强制把 mtime 推到未来：不依赖文件系统的毫秒精度，也避免同毫秒写入
    const future = new Date(Date.now() + 2000);
    utimesSync(authFile, future, future);

    assert.equal((await chat()).status, 200);
    assert.equal(stub.seen.at(-1).headers.authorization, 'Bearer token-bbbbbbbb',
      '登录文件改写后必须立刻重读 —— 缓存不能把换号/换令牌挡住');

    const { headers, body } = stub.seen.at(-1);
    assert.equal(Number(headers['content-length']), Buffer.byteLength(body),
      '发给上游的请求必须带 Content-Length（不再退回 chunked）');

    const requests = await (await fetch(bridge.baseUrl + '/v1/requests', { headers: auth })).json();
    const rec = (requests.requests || []).find((r) => r.model === 'stub-model' && r.ok);
    assert.ok(rec, '成功请求必须落账');
    assert.equal(typeof rec.overheadMs, 'number', '账本要能回答"桥自身花了多久"');
    assert.equal(typeof rec.ttfbMs, 'number', '账本要能回答"多久开始出字"');
  } finally {
    await bridge.stop();
    await stub.close();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('插件登录：设备码 → 加密落盘 → auto 回退 → 刷新轮换持久化', { timeout: 180_000 }, async () => {
  /*
   * 端到端验证第二条凭据来源：
   *   ① 没有桌面端登录文件时，设备码登录能把凭据写进插件自己的库；
   *   ② 密文里不出现令牌；
   *   ③ 令牌快过期时自动刷新，并把轮换后的 refresh token 持久化；
   *   ④ 桥重启后继续用刷新后的令牌（证明持久化有效）；
   *   ⑤ auto 在"桌面端可用"时仍然优先桌面端（老行为不变）。
   */
  const credRoot = mkdtempSync(join(tmpdir(), 'wb-cred-'));
  const credDir = join(credRoot, 'credentials');
  const missingAuth = join(credRoot, 'missing-auth.info');
  let tokenPolls = 0;
  let refreshes = 0;
  const chatAuths = [];
  const chatHeaders = [];
  const catalogAuths = [];
  const catalogConfigUAs = [];
  const refreshHeaders = [];
  // 与插件 uid-1 同一账号的桌面 JWT（readStoredAuth 只解码 payload，不验签）
  const desktopJwtForSameAccount = `e30.${Buffer.from(JSON.stringify({
    sub: 'uid-1',
    exp: Math.floor((Date.now() + 30 * 86_400_000) / 1000),
  })).toString('base64url')}.sig`;
  const desktopJwtOtherAccount = `e30.${Buffer.from(JSON.stringify({
    sub: 'uid-other',
    exp: Math.floor((Date.now() + 30 * 86_400_000) / 1000),
  })).toString('base64url')}.sig`;

  const stub = createServer((req, res) => {
    const u = new URL(req.url, 'http://127.0.0.1');
    const send = (status, obj) => {
      res.writeHead(status, { 'content-type': 'application/json' });
      res.end(JSON.stringify(obj));
    };
    if (u.pathname === '/v2/plugin/auth/state') {
      // http 桩 URL：open:true 必须被 https 校验挡住，避免测试真的弹出浏览器
      return send(200, { code: 0, data: { state: 'state-1', authUrl: 'http://127.0.0.1/login?state=state-1' } });
    }
    if (u.pathname === '/v2/plugin/auth/token' && req.method === 'GET') {
      tokenPolls += 1;
      if (tokenPolls === 1) return send(200, { code: 11217, msg: '11217:login ing' });
      return send(200, {
        code: 0,
        data: { accessToken: 'plugin-access-1', refreshToken: 'plugin-refresh-1', expiresIn: 60, domain: 'www.codebuddy.cn' },
      });
    }
    if (u.pathname === '/v2/plugin/login/account') {
      return send(200, { code: 0, data: { uid: 'uid-1', nickname: 'Tester' } });
    }
    if (u.pathname === '/v2/plugin/auth/token/refresh') {
      refreshes += 1;
      refreshHeaders.push(req.headers);
      return send(200, {
        code: 0,
        data: {
          accessToken: `plugin-access-${refreshes + 1}`,
          refreshToken: `plugin-refresh-${refreshes + 1}`,
          expiresIn: 3600,
        },
      });
    }
    if (u.pathname === '/v2/chat/completions') {
      chatAuths.push(req.headers.authorization);
      chatHeaders.push(req.headers);
      if (req.headers.authorization === `Bearer ${desktopJwtForSameAccount}`
        || req.headers.authorization === `Bearer ${desktopJwtOtherAccount}`) {
        res.writeHead(401, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ error: { message: 'desktop session expired' } }));
      }
      res.writeHead(200, { 'content-type': 'text/event-stream' });
      res.write('data: {"choices":[{"delta":{"content":"ok"}}]}\n\n');
      res.end('data: [DONE]\n\n');
      return;
    }
    if (u.pathname === '/v2/enterprises/personal/models') {
      catalogAuths.push(req.headers.authorization);
      return send(200, { code: 0, data: { models: [] } });
    }
    if (u.pathname === '/v3/config') {
      catalogConfigUAs.push(req.headers['user-agent']);
      // 桌面身份 = 官方 WorkBuddy 三段式 UA；插件身份 = 目录 UA（CN 为 CLI 两段）。
      const desktopIdentity = /^WorkBuddy\//i.test(String(req.headers['user-agent'] || ''));
      return send(200, {
        code: 0,
        data: {
          models: [
            { id: 'glm-5.3', maxInputTokens: 1000000, maxOutputTokens: 48000 },
            // 只在插件身份目录里出现的模型：补促销时不能把它弄丢。
            { id: 'plugin-only-model', maxInputTokens: 128000, maxOutputTokens: 4096 },
          ],
          ...(desktopIdentity ? {
            modelPromotions: [{
              modelIds: ['glm-5.3'],
              badge: { label: '夜间免费' },
              discount: { factor: 0 },
              schedule: { daily: [{ start: '23:00', end: '08:00' }], timezone: 'Asia/Shanghai' },
            }],
          } : {}),
        },
      });
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => stub.listen(0, '127.0.0.1', r));
  const stubBase = `http://127.0.0.1:${stub.address().port}`;

  const storeMode = process.platform === 'win32' ? 'dpapi' : 'file';
  const sharedEnv = {
    CODEBUDDY_ENDPOINT: stubBase,
    WORKBUDDY_LOGIN_BASE: stubBase,
    WORKBUDDY_LOGIN_ORIGIN: 'http://127.0.0.1',
    WORKBUDDY_LOGIN_POLL_MIN_MS: '0',
    WORKBUDDY_CREDENTIAL_DIR: credDir,
    WORKBUDDY_CREDENTIAL_STORE: storeMode,
    // 用户的真实场景：.env 里留着 auto。auto 是软默认，不应阻止登录后切到插件。
    WORKBUDDY_CREDENTIAL_SOURCE: 'auto',
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_5XX_RETRY: '0',
  };
  const chat = async (base) => {
    const r = await fetch(`${base}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
      signal: AbortSignal.timeout(30_000),
    });
    await r.text();
    return r;
  };

  const bridge1 = await startBridge({ ...sharedEnv, WORKBUDDY_AUTH_FILE: missingAuth }, { auth: READABLE_FAKE_AUTH });
  let bridge2 = null;
  let bridge3 = null;
  let bridge4 = null;
  let bridge5 = null;
  let bridge6 = null;
  let bridgeFollow = null;
  let bridgeLegacyFollow = null;
  try {
    // ① 设备码开始 → 第一次 poll 返回 pending → 第二次拿到令牌
    const device = await (await fetch(`${bridge1.baseUrl}/v1/auth/device`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ region: 'cn', open: true }),
    })).json();
    assert.equal(device.ok, true);
    assert.ok(device.state);
    assert.match(device.url, /loginSessionId=/);
    assert.equal(device.opened, false, '测试桩是 http URL：open 必须被 https 校验挡住，不能真弹浏览器');

    const poll1 = await (await fetch(`${bridge1.baseUrl}/v1/auth/device?state=${encodeURIComponent(device.state)}`, { headers: auth })).json();
    assert.equal(poll1.status, 'pending', '上游 code 11217 必须映射成 pending，而不是失败');
    const poll2 = await (await fetch(`${bridge1.baseUrl}/v1/auth/device?state=${encodeURIComponent(device.state)}`, { headers: auth })).json();
    assert.equal(poll2.status, 'ready');
    assert.equal(poll2.account.uid, 'uid-1');
    assert.equal(poll2.sourceSwitched, true, '登录是显式动作：成功后应把来源切到插件');
    assert.equal(poll2.effectiveSource, 'plugin', 'env=auto 是软默认，不能把插件登录锁成不生效');

    // ② 对外清单不能出现任何令牌
    const credRes = await fetch(`${bridge1.baseUrl}/v1/auth/credentials`, { headers: auth });
    const credText = await credRes.text();
    assert.ok(!credText.includes('plugin-access'), '凭据清单绝对不能回显 access token');
    assert.ok(!credText.includes('plugin-refresh'), '凭据清单绝对不能回显 refresh token');
    const creds = JSON.parse(credText);
    assert.equal(creds.credentials.length, 1);
    assert.equal(creds.credentials[0].uid, 'uid-1');

    // ③ 桌面端缺失 → auto 回退到插件凭据
    const source = await (await fetch(`${bridge1.baseUrl}/v1/auth/source`, { headers: auth })).json();
    assert.equal(source.configured, 'plugin', '登录成功后来源应切到插件');
    assert.equal(source.envPinned, false);
    assert.equal(source.effective.source, 'plugin');
    assert.equal(source.desktop.available, false);
    assert.equal(source.plugin.count, 1);
    assert.equal(source.loginRegion, 'cn', '登录区域建议应来自当前插件账号，而不是写死');

    // ④ 第一次 chat：令牌 60s 过期 < 5min 刷新余量 → 先刷新再请求
    assert.equal((await chat(bridge1.baseUrl)).status, 200);
    assert.deepEqual(chatAuths, ['Bearer plugin-access-2'], '刷新后的 access token 必须用于本次请求');
    const pluginHeaders = chatHeaders.at(-1);
    assert.equal(pluginHeaders['x-ide-type'], 'WorkBuddy', '插件来源必须用 WorkBuddy 身份，而不是 VSCode');
    assert.equal(pluginHeaders['x-ide-name'], 'WorkBuddy');
    assert.equal(pluginHeaders['x-user-id'], 'uid-1');
    assert.match(pluginHeaders['user-agent'], /^WorkBuddy\/5\.5\.6 WorkBuddy\/5\.5\.6/);
    assert.equal(pluginHeaders['x-product'], 'SaaS');
    // 目录请求必须带插件凭据的 Authorization（否则模型列表永远 401）
    const deadline = Date.now() + 2000;
    while (!catalogAuths.length && Date.now() < deadline) await new Promise((r) => setTimeout(r, 50));
    assert.ok(catalogAuths.some((a) => /^Bearer plugin-access-/.test(String(a || ''))),
      `插件来源的目录请求必须带 Authorization，实际：${catalogAuths.join(' / ') || '(无请求)'}`);
    /*
     * ④b 插件来源的促销补抓（issue #10）：模型清单用插件身份（含 v2 独有模型），
     * 促销规则额外用桌面身份抓一份 /v3/config 合并；不能为了促销整体切成
     * vscode 身份，否则会丢插件目录独有的模型。
     */
    const catalog = await (await fetch(`${bridge1.baseUrl}/v1/models?all=1&refresh=1`, { headers: auth })).json();
    const byId = new Map(catalog.data.map((m) => [m.id, m]));
    assert.ok(byId.has('plugin-only-model'), '补促销不能把插件身份目录里的 v2 模型弄丢');
    assert.ok(byId.has('glm-5.3'), '模型目录应包含插件身份返回的模型');
    assert.equal(byId.get('glm-5.3').badge, '夜间免费',
      '插件来源必须额外用桌面身份拿到 modelPromotions，否则夜间免费活动名会消失');
    assert.ok(catalogConfigUAs.some((ua) => /^WorkBuddy\//i.test(String(ua || ''))),
      '必须有一次桌面身份的 /v3/config 请求用于补促销');
    assert.ok(catalogConfigUAs.some((ua) => /^CLI\//i.test(String(ua || ''))),
      '模型清单仍应来自插件身份的目录请求');

    assert.equal(refreshes, 1);
    assert.equal(refreshHeaders[0]['x-refresh-token'], 'plugin-refresh-1');
    assert.equal(refreshHeaders[0]['x-auth-refresh-source'], 'workbuddy', '国内版刷新来源头必须是 workbuddy');
    assert.equal(refreshHeaders[0]['x-user-id'], 'uid-1');

    // ⑤ 落盘形态：只有密文，令牌不出现在文件里
    if (storeMode !== 'memory') {
      const files = readdirSync(credDir);
      assert.ok(files.includes('store.key'), 'DPAPI 密钥必须独立落在 store.key');
      const credFile = files.find((f) => f.endsWith('.cred'));
      assert.ok(credFile, '凭据必须写进 .cred 文件');
      const credCipher = readFileSync(join(credDir, credFile), 'utf8');
      assert.ok(!credCipher.includes('plugin-access-2'), '凭据文件里不能出现明文 access token');
      assert.ok(!credCipher.includes('plugin-refresh-2'), '凭据文件里不能出现明文 refresh token');
      const keyCipher = readFileSync(join(credDir, 'store.key'), 'utf8');
      assert.ok(!keyCipher.includes('plugin-'), 'store.key 里不能出现任何令牌');
    } else {
      assert.ok(!existsSync(credDir) || readdirSync(credDir).filter((f) => f.endsWith('.cred')).length === 0,
        'memory 模式不得把凭据写到磁盘');
    }

    // ⑥ 重启桥：必须用持久化后的 access token（证明轮换后的 refresh 也落盘了）
    if (storeMode !== 'memory') {
      await bridge1.stop();
      bridge2 = await startBridge({ ...sharedEnv, WORKBUDDY_AUTH_FILE: missingAuth }, { auth: READABLE_FAKE_AUTH });
      assert.equal((await chat(bridge2.baseUrl)).status, 200);
      assert.equal(chatAuths.at(-1), 'Bearer plugin-access-2', '重启后应继续使用刷新后的令牌');
      assert.equal(refreshes, 1, '1 小时有效期内不应再次刷新');
    }

    // ⑥b 来源=plugin，但用户在桌面客户端换号：桥必须跟随桌面（issue #6 的残留形态）
    if (storeMode !== 'memory') {
      const followPath = join(credRoot, 'desktop-follow.info');
      writeFileSync(followPath, JSON.stringify(authFileFor('uid-1')));
      // 模拟「用户在桌面文件最后一次写入之后才选择插件来源」：此刻不该抢桌面
      writeFileSync(join(credDir, 'source.json'), JSON.stringify({
        source: 'plugin',
        updatedAt: new Date(Date.now() + 60_000).toISOString(),
      }));
      bridgeFollow = await startBridge({
        ...sharedEnv,
        WORKBUDDY_AUTH_FILE_FOLLOW: followPath,
        WORKBUDDY_AUTH_FOLLOW_UID: 'uid-1',
      }, { auth: authFileFor('uid-1') });
      const health = async () => (await fetch(`${bridgeFollow.baseUrl}/health`, { headers: auth })).json();
      const before = await health();
      assert.equal(before.auth?.source, 'plugin', '来源偏好仍是 plugin（上一步登录造成）');
      assert.equal(before.auth?.userId, 'uid-1');

      writeFileSync(followPath, JSON.stringify(authFileFor('uid-new')));
      let after = null;
      const deadlineFollow = Date.now() + 10_000;
      while (Date.now() < deadlineFollow) {
        after = await health().catch(() => null);
        if (after?.auth?.userId === 'uid-new' && after?.auth?.source === 'desktop') break;
        await new Promise((r) => setTimeout(r, 150));
      }
      assert.equal(after?.auth?.userId, 'uid-new', '桌面换号后桥必须改读桌面，而不是继续用旧插件账号');
      assert.equal(after?.auth?.source, 'desktop', '桌面换号是更新的用户意图：来源应从 plugin 跟随到 desktop');
      assert.equal(after?.authFollow, true);
    }

    /*
     * ⑥c 旧 source.json（没有 desktopUid 基线）但桌面文件在选择之后被重写：
     * 升级后第一次就要跟上用户刚做的换号，不能要求再换一次。
     */
    if (storeMode !== 'memory') {
      const legacyFollow = join(credRoot, 'legacy-follow.info');
      writeFileSync(legacyFollow, JSON.stringify(authFileFor('legacy-desktop-new')));
      writeFileSync(join(credDir, 'source.json'), JSON.stringify({
        source: 'plugin',
        updatedAt: new Date(Date.now() - 3600_000).toISOString(),
      }));
      bridgeLegacyFollow = await startBridge({
        ...sharedEnv,
        WORKBUDDY_AUTH_FILE_FOLLOW: legacyFollow,
      }, { auth: authFileFor('legacy-desktop-old') });
      let legacy = null;
      const deadlineLegacy = Date.now() + 10_000;
      while (Date.now() < deadlineLegacy) {
        legacy = await (await fetch(`${bridgeLegacyFollow.baseUrl}/health`, { headers: auth })).json().catch(() => null);
        if (legacy?.auth?.userId === 'legacy-desktop-new' && legacy?.auth?.source === 'desktop') break;
        await new Promise((r) => setTimeout(r, 150));
      }
      assert.equal(legacy?.auth?.userId, 'legacy-desktop-new',
        '旧 source.json 没有基线时，桌面文件更新于选择时刻 → 应跟随桌面；输出：\n'
        + bridgeLegacyFollow.out()
        + '\nsource.json=' + readFileSync(join(credDir, 'source.json'), 'utf8'));
      assert.equal(legacy?.auth?.source, 'desktop');
    }

    // ⑦ auto：桌面端可用时仍然优先桌面端（老行为不变）
    // 先把来源偏好写回 auto —— 否则上一段的登录会把偏好留在 plugin。
    if (storeMode !== 'memory') {
      writeFileSync(join(credDir, 'source.json'), JSON.stringify({ source: 'auto' }));
    }
    bridge3 = await startBridge({ ...sharedEnv }, { auth: READABLE_FAKE_AUTH });
    const sourceBoth = await (await fetch(`${bridge3.baseUrl}/v1/auth/source`, { headers: auth })).json();
    assert.equal(sourceBoth.desktop.available, true);
    assert.equal(sourceBoth.plugin.count, storeMode !== 'memory' ? 1 : 0);
    assert.equal(sourceBoth.effective.source, 'desktop', 'auto 必须桌面端优先');
    assert.equal((await chat(bridge3.baseUrl)).status, 200);
    assert.equal(chatAuths.at(-1), 'Bearer fake-access-token', 'auto 下请求应使用桌面端令牌');
    assert.equal(chatHeaders.at(-1)['x-ide-type'], 'WorkBuddy', '桌面来源默认用官方 WorkBuddy 身份');
    assert.match(String(chatHeaders.at(-1)['user-agent'] || ''), /^CLI\/.* CodeBuddy\//,
      '桌面聊天默认走内置 CLI 的 UA 形状');

    // ⑧ 显式 desktop 是硬锁：envPinned 必须为 true，且桌面优先
    bridge4 = await startBridge({ ...sharedEnv, WORKBUDDY_CREDENTIAL_SOURCE: 'desktop' }, { auth: READABLE_FAKE_AUTH });
    const sourcePin = await (await fetch(`${bridge4.baseUrl}/v1/auth/source`, { headers: auth })).json();
    assert.equal(sourcePin.envPinned, true, '显式 desktop 必须锁定来源');
    assert.equal(sourcePin.effective.source, 'desktop');

    /*
     * ⑨ 同账号双凭据互通：桌面 JWT 的 sub = 插件 uid，桌面端 401 后必须自动
     * 接管到插件凭据，且请求身份切到 WorkBuddy。memory 模式下另一个进程没有
     * 插件凭据（设计如此），这条只在能落盘的 Windows 跑。
     */
    if (storeMode !== 'memory') {
      const sameAuth = {
        auth: {
          accessToken: desktopJwtForSameAccount,
          refreshToken: '',
          domain: 'example.invalid',
          expiresAt: Date.now() + 30 * 86_400_000,
        },
      };
      bridge5 = await startBridge({ ...sharedEnv }, { auth: sameAuth });
      const sourceSame = await (await fetch(`${bridge5.baseUrl}/v1/auth/source`, { headers: auth })).json();
      assert.equal(sourceSame.desktop.available, true);
      assert.equal(sourceSame.sameAccount, true, '桌面 JWT sub 与插件 uid 相同时必须识别为同一账号');
      assert.equal(sourceSame.effective.source, 'desktop', 'auto 仍先走桌面端');
      assert.equal((await chat(bridge5.baseUrl)).status, 200);
      assert.ok(chatAuths.some((a) => a === `Bearer ${desktopJwtForSameAccount}`), '必须先尝试桌面凭据');
      assert.match(String(chatAuths.at(-1) || ''), /^Bearer plugin-access-/, '桌面端 401 后必须自动接管到同账号插件凭据');
      assert.equal(chatHeaders.at(-1)['x-ide-type'], 'WorkBuddy', '接管后身份头要切到插件来源');
    }

    // ⑩ 不同账号：默认不接管（上一步已证）；显式 any 才允许跨账号接管
    if (storeMode !== 'memory') {
      const otherAuth = {
        auth: {
          accessToken: desktopJwtOtherAccount,
          refreshToken: '',
          domain: 'example.invalid',
          expiresAt: Date.now() + 30 * 86_400_000,
        },
      };
      bridge6 = await startBridge(
        { ...sharedEnv, WORKBUDDY_CREDENTIAL_FAILOVER: 'any' },
        { auth: otherAuth },
      );
      const sourceOther = await (await fetch(`${bridge6.baseUrl}/v1/auth/source`, { headers: auth })).json();
      assert.equal(sourceOther.sameAccount, false, '不同 uid 不能被识别成同一账号');
      assert.equal(sourceOther.failover, 'any');
      assert.equal((await chat(bridge6.baseUrl)).status, 200);
      assert.match(String(chatAuths.at(-1) || ''), /^Bearer plugin-access-/, 'any 模式下跨账号接管应成功');
      assert.equal(chatHeaders.at(-1)['x-ide-type'], 'WorkBuddy');
    }
  } finally {
    for (const b of [bridge1, bridge2, bridge3, bridge4, bridge5, bridge6, bridgeFollow, bridgeLegacyFollow]) {
      if (b) { try { await b.stop(); } catch { /* 忽略 */ } }
    }
    try { await stub.close(); } catch { /* 忽略 */ }
    for (const b of [bridge1, bridge2, bridge3, bridge4, bridge5, bridge6, bridgeFollow, bridgeLegacyFollow]) {
      if (b) { try { rmSync(b.dir, { recursive: true, force: true }); } catch { /* 忽略 */ } }
    }
    rmSync(credRoot, { recursive: true, force: true });
  }
});

/**
 * file 模式（非 Windows 默认）：`WORKBUDDY_CREDENTIAL_KEY` 让密钥不落盘，
 * 凭据仍是 AES-GCM 密文；模拟插件更新 / 服务重启后必须还能读出。
 */
test('插件登录：file 模式用环境变量密钥加密落盘，重启后仍可用', { timeout: 60_000 }, async () => {
  const key = Buffer.alloc(32, 0x5a);
  const uid = 'uid-file-mode';
  const credDir = mkdtempSync(join(tmpdir(), 'wb-file-store-'));
  const cred = {
    uid,
    accessToken: 'plugin-access-file',
    refreshToken: 'plugin-refresh-file',
    expiresAtMs: Date.now() + 3_600_000,
    region: 'cn',
    domain: 'www.codebuddy.cn',
    updatedAt: new Date().toISOString(),
  };
  const credFile = join(credDir, `${createHash('sha256').update(uid).digest('hex').slice(0, 24)}.cred`);
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  cipher.setAAD(Buffer.from(`workbuddy-credential\0${uid}\0v1`, 'utf8'));
  const data = Buffer.concat([cipher.update(JSON.stringify(cred), 'utf8'), cipher.final()]);
  writeFileSync(credFile, JSON.stringify({
    v: 1,
    alg: 'aes-256-gcm',
    uid,
    iv: iv.toString('base64'),
    tag: cipher.getAuthTag().toString('base64'),
    data: data.toString('base64'),
  }));
  writeFileSync(join(credDir, 'active.json'), JSON.stringify({ uid }));

  const env = {
    WORKBUDDY_CREDENTIAL_STORE: 'file',
    WORKBUDDY_CREDENTIAL_KEY: key.toString('hex'),
    WORKBUDDY_CREDENTIAL_DIR: credDir,
    WORKBUDDY_CREDENTIAL_SOURCE: 'plugin',
  };
  const readStatus = async (base) => {
    const res = await fetch(`${base}/v1/auth/source`, { headers: auth });
    assert.equal(res.status, 200);
    return res.json();
  };

  let bridge = await startBridge(env);
  try {
    const source = await readStatus(bridge.baseUrl);
    assert.equal(source.storeMode, 'file');
    assert.equal(source.storeKeySource, 'env');
    assert.equal(source.plugin.count, 1);
    assert.equal(source.plugin.activeUid, uid);
    assert.equal(source.effective.source, 'plugin');
    const text = await (await fetch(`${bridge.baseUrl}/v1/auth/credentials`, { headers: auth })).text();
    assert.ok(!text.includes('plugin-access-file'), '凭据清单不能回显 access token');
    assert.ok(!text.includes('plugin-refresh-file'), '凭据清单不能回显 refresh token');
    assert.ok(!existsSync(join(credDir, 'store.key')), '环境变量密钥不应落盘');
    assert.ok(!readFileSync(credFile, 'utf8').includes('plugin-access-file'), '凭据文件里不能有明文令牌');
  } finally {
    await bridge.stop();
  }

  // 模拟插件更新 / 服务重启：凭据仍能读出
  bridge = await startBridge({ ...env });
  try {
    const source = await readStatus(bridge.baseUrl);
    assert.equal(source.storeMode, 'file');
    assert.equal(source.plugin.count, 1);
    assert.equal(source.effective.source, 'plugin');
  } finally {
    await bridge.stop();
    rmSync(credDir, { recursive: true, force: true });
  }
});

test('插件登录：file 模式未设环境变量密钥时使用 store.key', { timeout: 60_000 }, async () => {
  const key = Buffer.alloc(32, 0x3c);
  const uid = 'uid-file-key';
  const credDir = mkdtempSync(join(tmpdir(), 'wb-file-key-'));
  writeFileSync(join(credDir, 'store.key'), key.toString('hex'), { mode: 0o600 });
  const cred = {
    uid,
    accessToken: 'plugin-access-keyfile',
    refreshToken: 'plugin-refresh-keyfile',
    expiresAtMs: Date.now() + 3_600_000,
    region: 'cn',
    domain: 'www.codebuddy.cn',
  };
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  cipher.setAAD(Buffer.from(`workbuddy-credential\0${uid}\0v1`, 'utf8'));
  const data = Buffer.concat([cipher.update(JSON.stringify(cred), 'utf8'), cipher.final()]);
  writeFileSync(join(credDir, `${createHash('sha256').update(uid).digest('hex').slice(0, 24)}.cred`), JSON.stringify({
    v: 1, alg: 'aes-256-gcm', uid,
    iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64'), data: data.toString('base64'),
  }));
  writeFileSync(join(credDir, 'active.json'), JSON.stringify({ uid }));

  const bridge = await startBridge({
    WORKBUDDY_CREDENTIAL_STORE: 'file',
    WORKBUDDY_CREDENTIAL_DIR: credDir,
    WORKBUDDY_CREDENTIAL_SOURCE: 'plugin',
  });
  try {
    const source = await (await fetch(`${bridge.baseUrl}/v1/auth/source`, { headers: auth })).json();
    assert.equal(source.storeMode, 'file');
    assert.equal(source.storeKeySource, 'file');
    assert.equal(source.plugin.count, 1);
    assert.equal(source.effective.source, 'plugin');
  } finally {
    await bridge.stop();
    rmSync(credDir, { recursive: true, force: true });
  }
});

test('目录刷新竞态：换来源后旧目录请求晚到，不能覆盖新一代结果', { timeout: 60_000 }, async () => {
  /*
   * 回归：invalidateCatalogCache() 以前只清缓存、再调 refreshCatalog()；
   * 若此刻已有一个目录请求在飞，refreshCatalog() 会把**旧请求**原样返回，
   * 于是换来源后既没有重新取目录，旧请求晚到的结果还会写回新缓存 ——
   * 新账号在最长 5 分钟内继续看到旧账号的模型。
   *
   * 用一个按请求次数变脸的假上游：第 2 次（换来源前触发的 refresh）故意慢，
   * 第 3 次（换来源后强制发起）返回 new-model。旧实现只有 2 次请求，
   * 最终目录仍是 old-model。
   */
  let personalCalls = 0;
  let slowNext = false;
  let slowStartedResolve;
  const slowStarted = new Promise((resolve) => { slowStartedResolve = resolve; });
  const stub = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    const send = (models) => {
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ code: 0, data: { models } }));
    };
    if (path === '/v2/enterprises/personal/models') {
      personalCalls += 1;
      const n = personalCalls;
      const model = n >= 3 ? 'new-model' : 'old-model';
      const payload = [{ id: model, maxInputTokens: 128000, maxOutputTokens: 4096 }];
      if (slowNext) {
        slowNext = false;
        slowStartedResolve();
        setTimeout(() => send(payload), 500);
        return;
      }
      return send(payload);
    }
    if (path === '/v3/config') return send([]);
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => stub.listen(0, '127.0.0.1', r));
  const stubBase = `http://127.0.0.1:${stub.address().port}`;
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stubBase,
    CODEBUDDY_API_KEY: 'api-key-race',
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_AUTO_CHECKIN: '0',
  });
  try {
    const warm = await (await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth })).json();
    assert.ok(warm.data.some((m) => m.id === 'old-model'), '先预热旧目录');

    // 让下一次目录请求变慢，并等它真的开始
    slowNext = true;
    const slowRefresh = fetch(bridge.baseUrl + '/v1/models?refresh=1', { headers: auth });
    await slowStarted;

    // 旧请求在飞时换来源 → 必须作废旧请求并发起新一代
    const switched = await fetch(bridge.baseUrl + '/v1/auth/source', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ source: 'api-key' }),
    });
    assert.equal(switched.status, 200);
    await slowRefresh; // 旧请求完成（可能写回）
    await new Promise((r) => setTimeout(r, 700)); // 给晚到的写回留出窗口

    const final = await (await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth })).json();
    const ids = final.data.map((m) => m.id);
    assert.ok(ids.includes('new-model'), `最终目录必须来自新一代请求：${ids}`);
    assert.ok(!ids.includes('old-model'), `旧请求晚到不能覆盖新目录：${ids}`);
    assert.ok(personalCalls >= 3, `换来源后必须重新打一次目录（实际 ${personalCalls} 次）`);
  } finally {
    await bridge.stop();
    await new Promise((r) => stub.close(r));
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('账本明细只解析尾部：大量历史 + 坏行仍返回最新 N 条', { timeout: 60_000 }, async () => {
  const bridge = await startBridge();
  try {
    const lines = [];
    for (let i = 1; i <= 5000; i += 1) {
      lines.push(JSON.stringify({
        t: i, model: `m${i}`, stream: false, ms: 1, ok: true, promptTokens: 1, completionTokens: 1,
      }));
    }
    lines.push('{broken-json');
    lines.push(JSON.stringify({ t: 999999, model: 'last', stream: false, ms: 2, ok: true }));
    writeFileSync(join(bridge.dir, 'usage.jsonl'), `${lines.join('\n')}\n`);

    const one = await (await fetch(`${bridge.baseUrl}/v1/requests?limit=1`, { headers: auth })).json();
    assert.equal(one.requests.length, 1);
    assert.equal(one.requests[0].model, 'last', 'limit=1 必须拿到最后一条，且坏行不能把结果挤掉');

    const fifty = await (await fetch(`${bridge.baseUrl}/v1/requests?limit=50`, { headers: auth })).json();
    assert.equal(fifty.requests.length, 50);
    assert.equal(fifty.requests[0].model, 'last');
    assert.equal(fifty.requests[49].model, 'm4952', '尾部 50 条按时间倒序，且不解析整本账');
  } finally {
    await bridge.stop();
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：dsh 宿主身份句被上游 11128 拉黑，出站 system 必须中和', { timeout: 90_000 }, async () => {
  // 2026-10-21 实测：system 开头是 "You are an AI agent powered by DeepSeek Harness."
  // 时上游直接 400 code 11128；换成中性表述后同样的 messages/tools 全部 200。
  // 品牌词单独出现不拦，所以只改这一句，system 的其余内容必须原样保留。
  const stub = await startStubUpstream(['identity-model']);
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1'); // 预热目录，避免预校验拦住测试模型
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'identity-model',
        stream: false,
        messages: [
          { role: 'system', content: 'You are an AI agent powered by DeepSeek Harness.\n\nExtra instructions.' },
          { role: 'user', content: 'hi' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();

    assert.equal(stub.seen.length, 1, '桥应向上游发出恰好一条聊天请求');
    const outbound = JSON.parse(stub.seen[0].body);
    const sysText = outbound.messages
      .filter((m) => m.role === 'system')
      .map((m) => (typeof m.content === 'string' ? m.content : JSON.stringify(m.content)))
      .join('\n');
    assert.ok(!sysText.includes('powered by DeepSeek Harness'),
      '出站 system 不得含被 11128 拦截的 dsh 身份句');
    assert.ok(sysText.includes("running inside the user's development environment"),
      '应替换成中性身份句');
    assert.ok(sysText.includes('Extra instructions'),
      '只改身份句，system 其余内容必须原样保留');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：未知 system 模板触发 11128 时，用中性 system 重试一次', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['fallback-model'], {
    chatSequence: [
      {
        status: 400,
        type: 'application/json',
        raw: JSON.stringify({ code: 11128, msg: 'Illegal API invocation from an unapproved channel' }),
      },
      {
        status: 200,
        type: 'text/event-stream',
        raw: 'data: {"choices":[{"delta":{"content":"ok"}}]}\n\ndata: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4}}\n\ndata: [DONE]\n\n',
      },
    ],
  });
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1'); // 预热目录
    const tool = { type: 'function', function: { name: 'foo', description: 'foo', parameters: { type: 'object', properties: {} } } };
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'fallback-model',
        stream: false,
        tools: [tool],
        messages: [
          { role: 'system', content: `You are a quirky host agent.

Keep this extra instruction.` },
          { role: 'user', content: 'hi' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();

    assert.equal(stub.seen.length, 2, '11128 后应只重试一次');
    const first = JSON.parse(stub.seen[0].body);
    const second = JSON.parse(stub.seen[1].body);
    assert.ok(first.messages.some((m) => m.role === 'system' && m.content.includes('quirky')),
      '第一次应保留原始 system');
    assert.ok(!second.messages.some((m) => m.role === 'system' && m.content.includes('quirky')),
      '重试必须去掉触发黑名单的 system 首段');
    assert.ok(second.messages.some((m) => m.role === 'system' && m.content.includes('Keep this extra instruction')),
      '渐进降级应保留 system 后面的 instructions，而不是整段丢掉');
    assert.equal(res.headers.get('x-workbuddy-11128-fallback'), 'drop-first-system-paragraph',
      '响应头必须标明本次用的是哪一级兜底');
    assert.ok(second.messages.some((m) => m.role === 'user' && m.content === 'hi'),
      'user 消息必须原样保留');
    assert.deepEqual(second.tools, first.tools, 'tools 必须原样保留');
    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8').trim().split(/\r?\n/).map((l) => JSON.parse(l));
    assert.equal(ledger.at(-1).fallback, 'drop-first-system-paragraph', '账本必须记下兜底策略');
    assert.equal(ledger.at(-1).fallbackOk, true, '账本必须能区分兜底是否成功');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：11128 连续命中时逐级降级，最后才换中性 system，且响应头/账本可见', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['fallback3-model'], {
    chatSequence: [
      {
        status: 400,
        type: 'application/json',
        raw: JSON.stringify({ code: 11128, msg: 'Illegal API invocation from an unapproved channel' }),
      },
      {
        status: 400,
        type: 'application/json',
        raw: JSON.stringify({ code: 11128, msg: 'Illegal API invocation from an unapproved channel' }),
      },
      {
        status: 200,
        type: 'text/event-stream',
        raw: 'data: {"choices":[{"delta":{"content":"ok"}}]}\n\ndata: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4}}\n\ndata: [DONE]\n\n',
      },
    ],
  });
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    await fetch(bridge.baseUrl + '/v1/models?all=1');
    const tool = { type: 'function', function: { name: 'foo', description: 'foo', parameters: { type: 'object', properties: {} } } };
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'fallback3-model',
        stream: false,
        tools: [tool],
        messages: [
          { role: 'system', content: 'First paragraph identity.\n\nSecond paragraph instructions.' },
          { role: 'user', content: 'hi' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();

    assert.equal(stub.seen.length, 3, '11128 连续命中时应依次尝试：删首段 → 中性 system');
    const second = JSON.parse(stub.seen[1].body);
    const third = JSON.parse(stub.seen[2].body);
    assert.ok(second.messages.some((m) => m.role === 'system' && m.content.includes('Second paragraph instructions')),
      '第二级应保留首段之后的 instructions');
    assert.ok(!third.messages.some((m) => m.role === 'system' && m.content.includes('Second paragraph instructions')),
      '最后一级才整段换中性 system');
    assert.ok(third.messages.some((m) => m.role === 'system' && m.content.includes('helpful AI assistant')));
    assert.deepEqual(third.tools, JSON.parse(stub.seen[0].body).tools, 'tools 必须始终原样保留');
    assert.equal(res.headers.get('x-workbuddy-11128-fallback'), 'neutral-system');
    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8').trim().split(/\r?\n/).map((l) => JSON.parse(l));
    assert.equal(ledger.at(-1).fallback, 'neutral-system');
    assert.equal(ledger.at(-1).fallbackOk, true);
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：system 首句之外的 DeepSeek Harness 品牌词也必须中和', { timeout: 60_000 }, async () => {
  // hub #570 实测：DSH developer 提示第 33/35 行还带品牌词，只洗首句仍 400。
  // 这里要求保留该行其余语义，只做品牌词替换，不删整行。
  const stub = await startStubUpstream(['brand-model']);
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'brand-model',
        stream: false,
        messages: [
          {
            role: 'system',
            content: [
              'You are an AI agent powered by DeepSeek Harness.',
              '',
              'The runtime context names the DeepSeek Harness implementation checkout.',
              'You are interacting with the user through the DeepSeek Harness Web GUI.',
              'Keep this rule.',
            ].join('\n'),
          },
          { role: 'user', content: 'hi' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();

    assert.equal(stub.seen.length, 1, '主动中和后不应再触发 11128 重试');
    const system = JSON.parse(stub.seen[0].body).messages.find((m) => m.role === 'system').content;
    assert.ok(!/DeepSeek\s+Harness/i.test(system), 'system 里不得残留任何品牌词');
    assert.ok(system.includes('implementation checkout'), '品牌词所在行的其余语义必须保留');
    assert.ok(system.includes('Web GUI'), '品牌词所在行的其余语义必须保留');
    assert.ok(system.includes('Keep this rule'), '后续指令必须保留');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：DSH 的 @ 路径说明两句共现时，出站 system 必须改写', { timeout: 60_000 }, async () => {
  // issue #25：这两句单独出现都通过，按固定先后共现会被上游当成通道指纹。
  // 只改第一句里的 `@`，第二句与后续指令必须原样保留。
  const stub = await startStubUpstream(['atpath-model']);
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  const first = 'Tokens prefixed with @ are paths the user explicitly referenced.';
  const second = 'Relative paths resolve from the workspace root; absolute paths identify files or directories on the host.';
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'atpath-model',
        stream: false,
        messages: [
          { role: 'system', content: [first, second, 'Keep this rule.'].join('\n') },
          { role: 'user', content: 'hi' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();

    assert.equal(stub.seen.length, 1, '主动改写后不应再触发 11128 重试');
    const system = JSON.parse(stub.seen[0].body).messages.find((m) => m.role === 'system').content;
    assert.ok(!system.includes(first), '出站 system 不得保留会触发指纹的原句');
    assert.ok(system.includes('prefixed with an at-sign'), '应改成 at-sign 表述');
    assert.ok(system.includes(second), '另一句必须原样保留');
    assert.ok(system.includes('Keep this rule.'), '后续指令必须保留');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：assistant 历史身份句必须中和，user 原文不得改', { timeout: 60_000 }, async () => {
  // hub #574：assistant 历史里出现同一句身份模板会让整条会话每轮 11128。
  // 只动 assistant 的两句精确模板；user 的同一句不能被改（上游允许 user 提）。
  const stub = await startStubUpstream(['assistant-model']);
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'assistant-model',
        stream: false,
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          { role: 'user', content: 'hi' },
          { role: 'assistant', content: 'You are an AI agent powered by DeepSeek Harness.' },
          { role: 'user', content: 'You are an AI agent powered by DeepSeek Harness.' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();

    assert.equal(stub.seen.length, 1);
    const outbound = JSON.parse(stub.seen[0].body);
    const assistant = outbound.messages.find((m) => m.role === 'assistant').content;
    const users = outbound.messages.filter((m) => m.role === 'user').map((m) => m.content);
    assert.ok(!/DeepSeek\s+Harness/i.test(assistant), 'assistant 历史身份句必须中和');
    assert.ok(assistant.includes('development environment'), '应替换成中性身份句');
    assert.deepEqual(users, [
      'hi',
      'You are an AI agent powered by DeepSeek Harness.',
    ], 'user 原文必须原样保留');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：assistant 历史品牌行触发 11128 时，走 remove-brand-lines-assistant 兜底', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['assistant-fallback-model'], {
    chatSequence: [
      {
        status: 400,
        type: 'application/json',
        raw: JSON.stringify({ code: 11128, msg: 'Illegal API invocation from an unapproved channel' }),
      },
      {
        status: 200,
        type: 'text/event-stream',
        raw: 'data: {"choices":[{"delta":{"content":"ok"}}]}\n\ndata: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4}}\n\ndata: [DONE]\n\n',
      },
    ],
  });
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'assistant-fallback-model',
        stream: false,
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          { role: 'user', content: 'hi' },
          { role: 'assistant', content: 'DeepSeek Harness is a project.\nKeep this answer.' },
          { role: 'user', content: 'ok' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();

    assert.equal(stub.seen.length, 2, '11128 后应只重试一次');
    const second = JSON.parse(stub.seen[1].body);
    const assistant = second.messages.find((m) => m.role === 'assistant').content;
    assert.equal(assistant, 'Keep this answer.', '只删品牌行，保留该条 assistant 的其余正文');
    assert.deepEqual(
      second.messages.filter((m) => m.role === 'user').map((m) => m.content),
      ['hi', 'ok'],
      'user 原文必须原样保留',
    );
    assert.equal(res.headers.get('x-workbuddy-11128-fallback'), 'remove-brand-lines-assistant');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：11128 所有降级都失败时回 CHANNEL_REJECTED，并停止重试', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['reject-model'], {
    chatStatus: 400,
    chatType: 'application/json',
    chatRaw: JSON.stringify({ code: 11128, msg: 'Illegal API invocation from an unapproved channel' }),
  });
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'reject-model',
        stream: false,
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          { role: 'user', content: 'hi' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 400);
    const j = await res.json();
    assert.equal(j.error.code, 'CHANNEL_REJECTED');
    assert.equal(j.error.type, 'upstream_channel_error');
    assert.match(j.error.message, /channel verification rejected/i);
    assert.match(j.error.message, /resending the same payload is unlikely to help/i);
    assert.equal(stub.seen.length, 2, '一次原始尝试 + 一个 neutral-system 候选后必须停下');

    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8').trim().split(/\r?\n/).map((l) => JSON.parse(l));
    assert.equal(ledger.at(-1).channelRejected, true, '账本必须标出通道拒绝，便于面板归因');
    assert.equal(ledger.at(-1).channelAttempts, 2);
    assert.equal(ledger.at(-1).failureKind, 'channel', '失败归因必须是通道校验');
    assert.equal(ledger.at(-1).retryable, false, '通道拒绝不能提示重试');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：同一会话 conversation_id 稳定，header/body 双写，缓存字段上屏', { timeout: 90_000 }, async () => {
  const cachedSse = 'data: {"choices":[{"delta":{"content":"ok"}}]}\n\n'
    + 'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{'
    + '"prompt_tokens":1000,"completion_tokens":1,"total_tokens":1001,'
    + '"prompt_tokens_details":{"cached_tokens":880},"prompt_cache_miss_tokens":120'
    + '}}\n\ndata: [DONE]\n\n';
  const stub = await startStubUpstream(['conv-model'], { chatRaw: cachedSse, chatType: 'text/event-stream' });
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const send = async (messages, extraHeaders = {}) => {
      const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
        method: 'POST',
        headers: { ...auth, 'content-type': 'application/json', ...extraHeaders },
        body: JSON.stringify({ model: 'conv-model', stream: false, messages }),
        signal: AbortSignal.timeout(15000),
      });
      assert.equal(res.status, 200);
      await res.text();
    };
    await send([
      { role: 'system', content: 'Stable system.' },
      { role: 'user', content: 'first question' },
    ]);
    await send([
      { role: 'system', content: 'Stable system.' },
      { role: 'user', content: 'first question' },
      { role: 'assistant', content: 'ok' },
      { role: 'user', content: 'second question' },
    ]);
    await send([
      { role: 'system', content: 'Stable system.' },
      { role: 'user', content: 'different conversation' },
    ]);
    await send([
      { role: 'system', content: 'Stable system.' },
      { role: 'user', content: 'first question' },
    ], { 'x-conversation-id': 'explicit-session-1' });

    assert.equal(stub.seen.length, 4);
    const ids = stub.seen.map((s) => JSON.parse(s.body).conversation_id);
    assert.ok(ids[0] && ids[0] === ids[1], '同一 system + 首条 user 的多轮请求必须复用同一个 body conversation_id');
    assert.equal(stub.seen[0].headers['x-conversation-id'], stub.seen[1].headers['x-conversation-id'],
      'header 也必须复用同一个 ID');
    assert.notEqual(ids[0], ids[2], '不同会话必须得到不同 ID');
    assert.equal(ids[3], 'explicit-session-1', '客户端显式 header 必须优先');
    assert.equal(stub.seen[3].headers['x-conversation-id'], 'explicit-session-1');

    const reqs = await (await fetch(bridge.baseUrl + '/v1/requests?limit=10', { headers: auth })).json();
    assert.equal(reqs.requests[0].cachedTokens, 880, '/v1/requests 必须透出 cachedTokens');
    assert.equal(reqs.requests[0].cacheMissTokens, 120, '/v1/requests 必须透出 cacheMissTokens');

    const usage = await (await fetch(bridge.baseUrl + '/v1/usage?days=1', { headers: auth })).json();
    assert.equal(usage.total.cachedTokens, 3520);
    assert.equal(usage.total.cacheMissTokens, 480);
    assert.equal(usage.total.cacheKnownCalls, 4);
    assert.equal(usage.total.cacheHitRate, 0.88, '命中率 = cachedTokens / promptTokens');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：上游拒绝 body conversation_id 时自动去掉并关闭注入', { timeout: 90_000 }, async () => {
  const okSse = 'data: {"choices":[{"delta":{"content":"ok"}}]}\n\n'
    + 'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4}}\n\ndata: [DONE]\n\n';
  const stub = await startStubUpstream(['conv-reject-model'], {
    chatSequence: [
      {
        status: 400,
        type: 'application/json',
        raw: JSON.stringify({ code: 400, msg: 'unknown field conversation_id' }),
      },
      { status: 200, type: 'text/event-stream', raw: okSse },
    ],
  });
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const send = async (extraHeaders = {}) => {
      const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
        method: 'POST',
        headers: { ...auth, 'content-type': 'application/json', ...extraHeaders },
        body: JSON.stringify({
          model: 'conv-reject-model',
          stream: false,
          messages: [
            { role: 'system', content: 'Stable system.' },
            { role: 'user', content: 'hi' },
          ],
        }),
        signal: AbortSignal.timeout(15000),
      });
      assert.equal(res.status, 200);
      await res.text();
    };
    await send();
    assert.equal(stub.seen.length, 2, '第一次 400 后应去掉字段重试一次');
    assert.ok(JSON.parse(stub.seen[0].body).conversation_id, '第一次必须带 body conversation_id');
    assert.ok(!JSON.parse(stub.seen[1].body).conversation_id, '重试必须去掉被拒绝的字段');

    await send();
    assert.equal(stub.seen.length, 3);
    assert.ok(!JSON.parse(stub.seen[2].body).conversation_id, '后续请求也不应再注入该字段');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：重复 tool_call id / 空 assistant / 孤儿 tool result 会被自愈', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['repair-model']);
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const toolCall = (id) => ({
      id,
      type: 'function',
      function: { name: 'bash', arguments: '{"cmd":"pwd"}' },
    });
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'repair-model',
        stream: false,
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          { role: 'user', content: 'first' },
          { role: 'assistant', content: null, tool_calls: [toolCall('Bash:0')] },
          { role: 'tool', tool_call_id: 'Bash:0', content: 'one' },
          { role: 'user', content: 'again' },
          { role: 'assistant', content: null, tool_calls: [toolCall('Bash:0')] },
          { role: 'tool', tool_call_id: 'Bash:0', content: 'two' },
          { role: 'assistant', content: '', reasoning_content: 'thinking only' },
          { role: 'assistant', content: 'final answer' },
          { role: 'tool', tool_call_id: 'orphan', content: 'orphan result' },
          { role: 'user', content: 'next' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();

    assert.equal(stub.seen.length, 1);
    const outbound = JSON.parse(stub.seen[0].body).messages;
    const assistantCalls = outbound.filter((m) => m.role === 'assistant' && m.tool_calls);
    const toolResults = outbound.filter((m) => m.role === 'tool');
    assert.equal(assistantCalls.length, 2);
    assert.equal(toolResults.length, 2, '孤儿 result 必须被丢掉');
    assert.equal(assistantCalls[0].tool_calls[0].id, 'Bash:0', '第一次出现的 id 保持原样');
    assert.notEqual(assistantCalls[1].tool_calls[0].id, 'Bash:0', '第二次重复的 id 必须改名');
    assert.equal(toolResults[1].tool_call_id, assistantCalls[1].tool_calls[0].id,
      'tool result 必须跟着改名后的 id 走');
    assert.ok(!outbound.some((m) => m.role === 'assistant' && !m.content && !m.tool_calls),
      '只有 reasoning 的空 assistant 必须被剔除');
    assert.ok(outbound.some((m) => m.role === 'assistant' && m.content === 'final answer'));
    assert.deepEqual(
      outbound.filter((m) => m.role === 'user').map((m) => m.content),
      ['first', 'again', 'next'],
      'user 消息必须原样保留',
    );

    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8').trim().split(/\r?\n/).map((l) => JSON.parse(l));
    assert.deepEqual(ledger.at(-1).toolRepair, { renames: 1, synthesized: 0, dropped: 2 });
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：assistant 发了 tool_calls 但缺 result 时自动补一条错误结果', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['repair-missing-model']);
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'repair-missing-model',
        stream: false,
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          { role: 'user', content: 'run it' },
          {
            role: 'assistant',
            content: null,
            tool_calls: [{ id: 'call_missing', type: 'function', function: { name: 'bash', arguments: '{}' } }],
          },
          { role: 'user', content: 'why did it stop?' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();

    const outbound = JSON.parse(stub.seen[0].body).messages;
    const tool = outbound.find((m) => m.role === 'tool');
    assert.ok(tool, '缺 result 时必须补一条 tool 消息');
    assert.equal(tool.tool_call_id, 'call_missing');
    assert.match(tool.content, /tool result unavailable/i);
    assert.ok(outbound.findIndex((m) => m.role === 'tool') < outbound.findIndex((m) => m.content === 'why did it stop?'),
      '补的 result 必须排在后续 user 之前');

    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8').trim().split(/\r?\n/).map((l) => JSON.parse(l));
    assert.deepEqual(ledger.at(-1).toolRepair, { renames: 0, synthesized: 1, dropped: 0 });
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：合法工具历史不被改写', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['repair-valid-model']);
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'repair-valid-model',
        stream: false,
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          { role: 'user', content: 'run it' },
          {
            role: 'assistant',
            content: null,
            tool_calls: [{ id: 'call_valid_1', type: 'function', function: { name: 'bash', arguments: '{}' } }],
          },
          { role: 'tool', tool_call_id: 'call_valid_1', content: 'ok' },
          { role: 'user', content: 'next' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();

    const outbound = JSON.parse(stub.seen[0].body).messages;
    assert.equal(outbound.find((m) => m.role === 'assistant').tool_calls[0].id, 'call_valid_1');
    assert.equal(outbound.find((m) => m.role === 'tool').tool_call_id, 'call_valid_1');
    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8').trim().split(/\r?\n/).map((l) => JSON.parse(l));
    assert.equal(ledger.at(-1).toolRepair, undefined, '合法历史不得写入修复标记');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：非视觉模型收到图片时降级为文本占位，不原样上行吃 400', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['no-vision-model'], { nonVisionModels: ['no-vision-model'] });
  const bridge = await startBridge({ CODEBUDDY_ENDPOINT: stub.base }, { auth: READABLE_FAKE_AUTH });
  try {
    const catalog = await (await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth })).json();
    const listed = catalog.data.find((m) => m.id === 'no-vision-model');
    assert.ok(listed, '前置条件：目录里必须有 no-vision-model');
    assert.equal(listed.supports_images, undefined, '前置条件：该模型在目录里没有视觉能力');
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'no-vision-model',
        stream: false,
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          {
            role: 'user',
            content: [
              { type: 'text', text: 'look at this' },
              { type: 'image_url', image_url: { url: 'data:image/png;base64,AAAA' } },
            ],
          },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();

    const outbound = JSON.parse(stub.seen[0].body);
    const user = outbound.messages.find((m) => m.role === 'user');
    assert.ok(Array.isArray(user.content));
    assert.ok(!user.content.some((p) => p.type === 'image_url'), '图片块不得原样上行');
    assert.ok(user.content.some((p) => p.type === 'text' && /image omitted/i.test(p.text)),
      '必须留下可见的降级占位');
    assert.ok(user.content.some((p) => p.type === 'text' && p.text === 'look at this'),
      '文本内容必须保留');

    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8').trim().split(/\r?\n/).map((l) => JSON.parse(l));
    assert.equal(ledger.at(-1).imageOmitted, 1, '账本必须记下被忽略的图片数');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：chat 流式把逐字符 reasoning 聚合，且每个 data 帧都有 delta', { timeout: 90_000 }, async () => {
  // 真实上游每帧都带空占位（issue #9 的探针形状）：空 content / tool_calls[] /
  // function_call:null / refusal:"" / extra_fields:null。
  const frame = (delta, extra = '') => 'data: {"id":"chatcmpl-r","object":"chat.completion.chunk","created":1,"model":"m","choices":[{"index":0,"delta":'
    + JSON.stringify(delta) + (extra ? `,${extra}` : '') + '}]}\n\n';
  const raw = frame({ content: '', reasoning_content: '你', function_call: null, refusal: '', tool_calls: [], extra_fields: null })
    + frame({ content: '', reasoning_content: '好', function_call: null, refusal: '', tool_calls: [], extra_fields: null })
    + frame({ content: '答', tool_calls: [] })
    + 'data: {"id":"chatcmpl-r","object":"chat.completion.chunk","created":1,"model":"m","choices":[{"index":0,"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4}}\n\n'
    + 'data: [DONE]\n\n';
  const stub = await startStubUpstream(['sse-normalize-model'], { chatRaw: raw, chatType: 'text/event-stream' });
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'sse-normalize-model',
        stream: true,
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          { role: 'user', content: 'hi' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    const text = await res.text();
    const events = text.split('\n\n').filter(Boolean).map((block) => {
      const line = block.split('\n').find((l) => l.startsWith('data:'));
      return line ? line.slice(5).trim() : '';
    }).filter(Boolean).map((rawLine) => (rawLine === '[DONE]' ? rawLine : JSON.parse(rawLine)));

    const reasoning = events.filter((e) => e !== '[DONE]')
      .flatMap((e) => e.choices || [])
      .map((c) => c.delta?.reasoning_content)
      .filter(Boolean)
      .join('');
    const content = events.filter((e) => e !== '[DONE]')
      .flatMap((e) => e.choices || [])
      .map((c) => c.delta?.content)
      .filter(Boolean)
      .join('');
    assert.equal(reasoning, '你好', '逐字符 reasoning 必须聚合成一段，而不是每个字符一帧');
    assert.equal(content, '答', '正文内容不受影响');
    assert.ok(events.filter((e) => e !== '[DONE]').every((e) => e.choices?.[0]?.delta),
      '每个 data 帧都必须有 choices[0].delta（Cline #939）');
    assert.equal(events.filter((e) => e === '[DONE]').length, 1, '[DONE] 只能出现一次');
    assert.ok(!JSON.stringify(events).includes('"tool_calls":[]'),
      '空 tool_calls 必须被剔掉（Cherry 会把它当成 reasoning 段结束）');
    const reasoningFrames = events.filter((e) => e !== '[DONE]')
      .flatMap((e) => e.choices || [])
      .filter((c) => typeof c.delta?.reasoning_content === 'string');
    assert.equal(reasoningFrames.length, 1, '短于分片阈值的 reasoning 仍合并成一帧（Cherry 场景：不能每字符一块）');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：chat 流式上游缺 delta 时补一个空 delta（不能把客户端弄崩）', { timeout: 90_000 }, async () => {
  const raw = 'data: {"choices":[{"content":"x"}]}\n\n'
    + 'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n';
  const stub = await startStubUpstream(['sse-delta-model'], { chatRaw: raw, chatType: 'text/event-stream' });
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'sse-delta-model',
        stream: true,
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          { role: 'user', content: 'hi' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    const text = await res.text();
    const first = text.split('\n\n').find((b) => b.startsWith('data:') && b.includes('"x"'));
    assert.ok(first, '正文帧必须存在');
    const j = JSON.parse(first.slice(5).trim());
    assert.equal(j.choices[0].delta.content, 'x', '缺 delta 时要把顶层 content 挪进 delta');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：11148 工具历史不配对归因为 tool_history，且标记不可重试', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['tool-history-model'], {
    chatStatus: 400,
    chatType: 'application/json',
    chatRaw: JSON.stringify({ code: 11148, msg: 'tool calls and tool results do not match' }),
  });
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'tool-history-model',
        stream: false,
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          { role: 'user', content: 'hi' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 400);
    await res.text();
    const ledger = readFileSync(join(bridge.dir, 'usage.jsonl'), 'utf8').trim().split(/\r?\n/).map((l) => JSON.parse(l));
    assert.equal(ledger.at(-1).failureKind, 'tool_history');
    assert.equal(ledger.at(-1).retryable, false);
    assert.equal(ledger.at(-1).failureAction, 'new-session');

    const usage = await (await fetch(bridge.baseUrl + '/v1/usage?days=1', { headers: auth })).json();
    assert.equal(usage.total.failureKinds.tool_history, 1, '失败归因要进用量汇总');    assert.equal(usage.failures.at(-1)?.failureAction, 'new-session',
      '用量页的失败条目也要带建议动作（面板悬停展示）');
    const modelRow = usage.failureByModel.find((m) => m.model === 'tool-history-model');
    assert.equal(modelRow?.failed, 1, '按模型也要能看到失败数');
    assert.equal(modelRow?.byKind?.tool_history, 1);
    assert.ok((usage.days.at(-1)?.failed || 0) >= 1, '按天也要能看到失败数');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：非法 tool name 本地 400，不调用上游', { timeout: 90_000 }, async () => {
  const stub = await startStubUpstream(['tool-model']);
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'tool-model',
        stream: false,
        messages: [{ role: 'system', content: 'You are a helpful assistant.' }, { role: 'user', content: 'hi' }],
        tools: [{ type: 'function', function: { name: 'bad.tool/name', description: 'x', parameters: { type: 'object', properties: {} } } }],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 400);
    const body = await res.json();
    assert.match(body.error.message, /tool name.*invalid/i);
    assert.equal(stub.seen.length, 0, '非法工具名必须在本地拦下，绝不能花一次上游往返');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：上游只回响应头不说话时，首字节超时返回 504（不能永久 loading）', { timeout: 30_000 }, async () => {
  const stub = await startStubUpstream(['hang-model'], { chatHang: true });
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: stub.base,
      WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
      WORKBUDDY_FIRST_BYTE_TIMEOUT_MS: '150',
    },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const startedAt = Date.now();
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'hang-model',
        stream: false,
        messages: [{ role: 'system', content: 'You are a helpful assistant.' }, { role: 'user', content: 'hi' }],
      }),
      signal: AbortSignal.timeout(10_000),
    });
    assert.equal(res.status, 504);
    const body = await res.json();
    assert.match(body.error.message, /first-byte timeout/i);
    assert.ok(Date.now() - startedAt < 5000, '首字节超时必须及时收尾，不能等客户端超时');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：桌面登录文件换号后，刷新出的 memoryAuth 不能继续压过新文件', { timeout: 60_000 }, async () => {
  const stub = await startStubUpstream(['switch-model'], {
    chatSequence: [
      {
        status: 401,
        type: 'application/json',
        raw: JSON.stringify({ code: 40101, msg: 'token expired' }),
      },
      {
        status: 200,
        type: 'text/event-stream',
        raw: 'data: {"choices":[{"delta":{"content":"ok"}}]}\n\ndata: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1,"total_tokens":4}}\n\ndata: [DONE]\n\n',
      },
    ],
  });
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    {
      auth: {
        auth: {
          accessToken: 'old-file-token',
          refreshToken: 'r1',
          domain: 'example.invalid',
          expiresAt: Date.now() + 3_600_000,
        },
      },
    },
  );
  try {
    const send = () => fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'switch-model',
        stream: false,
        messages: [{ role: 'system', content: 'You are a helpful assistant.' }, { role: 'user', content: 'hi' }],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal((await send()).status, 200, '第一次 401 应刷新后成功');
    assert.match(String(stub.seen.at(-1).headers.authorization), /refreshed-1/,
      '刷新后的令牌应被用于重试');

    // 模拟桌面端换号：原子替换登录文件（内容与尺寸都变）。
    writeFileSync(join(bridge.dir, 'fake-auth.info'), JSON.stringify({
      auth: {
        accessToken: 'new-file-token-after-switch',
        refreshToken: 'r2',
        domain: 'example.invalid',
        expiresAt: Date.now() + 3_600_000,
      },
    }));
    assert.equal((await send()).status, 200);
    assert.match(String(stub.seen.at(-1).headers.authorization), /new-file-token-after-switch/,
      '登录文件变了就必须丢弃 memoryAuth，不能继续用旧账号令牌');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：身份句带点号版本时只替换句子，不得吃掉后面的指令', { timeout: 60_000 }, async () => {
  const stub = await startStubUpstream(['version-model']);
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'version-model',
        stream: false,
        messages: [
          {
            role: 'system',
            content: 'You are an AI agent powered by DeepSeek Harness v5.8.3. Keep this rule.',
          },
          { role: 'user', content: 'hi' },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    assert.equal(res.status, 200);
    await res.text();
    const system = JSON.parse(stub.seen.at(-1).body).messages.find((m) => m.role === 'system').content;
    assert.ok(!system.includes('DeepSeek Harness'), '身份句必须被替换');
    assert.ok(!system.includes('NEUTRAL8.3'), '版本号的小数点不能被拆成残留碎片');
    assert.ok(system.includes('Keep this rule'), '身份句后面的指令必须保留');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

test('桥：连接池排队超过上限时按超时失败，不能无限挂着', { timeout: 30_000 }, async () => {
  const stub = await startStubUpstream(['queue-model'], { chatHang: true });
  const bridge = await startBridge(
    {
      CODEBUDDY_ENDPOINT: stub.base,
      WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
      WORKBUDDY_MAX_SOCKETS: '1',
      WORKBUDDY_QUEUE_TIMEOUT_MS: '200',
      WORKBUDDY_FIRST_BYTE_TIMEOUT_MS: '5000',
    },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const ac = new AbortController();
    const payload = JSON.stringify({
      model: 'queue-model',
      stream: false,
      messages: [{ role: 'system', content: 'You are a helpful assistant.' }, { role: 'user', content: 'hi' }],
    });
    const first = fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: payload,
      signal: ac.signal,
    }).catch(() => null);
    await new Promise((r) => setTimeout(r, 200)); // 让第一条占住唯一 socket
    const second = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: payload,
      signal: AbortSignal.timeout(5000),
    });
    assert.equal(second.status, 504);
    const body = await second.json();
    assert.match(body.error.message, /socket queue timeout/i);
    ac.abort();
    await first;
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 逐字符 reasoning 必须**分片下发**，不能攒到正文才发。
 *
 * 现场症状（2026-10-26）：dsh 的 sessionStats 把一轮 15.8 秒的思考算成
 * TTFT=15755ms、解码段只剩 1701ms，于是 2045 个输出 token 被显示成
 * 1202 tok/s（真实端到端约 130）。根因在桥的 SSE 归一：为了修 Cherry Studio
 * 的 issue #9（每字符一个思考块），旧实现把整段 `reasoning_content` 扣在
 * `reasoningBuf` 里，直到正文/工具/终止帧才一次性 flush —— 于是任何按
 * 「首 token 到达时间」测量 TTFT 的客户端都会把整段思考算进首字延迟。
 *
 * 断言用「≥2 帧」而不是「等于 64 字符一帧」：阈值是实现细节，可调；
 * 但不许无限期扣住。同时钉住两件不能坏的事：内容不丢字、顺序仍在正文之前。
 */
test('桥：逐字符 reasoning 分片下发（不能攒到正文帧才发，否则客户端 TTFT 失真）', { timeout: 60_000 }, async () => {
  const chars = '这是一个用来验证分片阈值的思考过程，长度必须超过阈值。'.repeat(8);
  assert.ok(chars.length > 128, `夹具要明显超过阈值（当前 ${chars.length} 字符）`);

  const chunk = (delta, finish) => `data: ${JSON.stringify({
    id: 'c1', object: 'chat.completion.chunk', created: 1, model: 'stub-model',
    choices: [{ index: 0, delta, finish_reason: finish ?? null }],
  })}\n\n`;

  const sse = [];
  for (const ch of chars) sse.push(chunk({ reasoning_content: ch }));
  sse.push(chunk({ content: '完成' }));
  sse.push(`data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":5,"total_tokens":8}}\n\n`);
  sse.push('data: [DONE]\n\n');

  const stub = await startStubUpstream(['stub-model'], { chatSse: sse });
  const bridge = await startBridge(
    { CODEBUDDY_ENDPOINT: stub.base, WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1' },
    { auth: READABLE_FAKE_AUTH },
  );
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', stream: true, messages: [{ role: 'user', content: 'hi' }] }),
    });
    assert.equal(res.status, 200);
    const text = await res.text();

    const frames = text.split('\n\n')
      .map((block) => block.split('\n').find((line) => line.startsWith('data:')))
      .filter(Boolean)
      .map((line) => line.slice(5).trim())
      .filter((raw) => raw && raw !== '[DONE]')
      .map((raw) => { try { return JSON.parse(raw); } catch { return null; } })
      .filter(Boolean);

    const reasoningIdx = [];
    let joined = '';
    frames.forEach((frame, i) => {
      const value = frame.choices?.[0]?.delta?.reasoning_content;
      if (typeof value === 'string' && value) { reasoningIdx.push(i); joined += value; }
    });

    assert.equal(joined, chars, '分片不能丢字或改序');
    assert.ok(
      reasoningIdx.length >= 2,
      `逐字符 reasoning 必须分片下发（实得 ${reasoningIdx.length} 帧）—— 攒到正文才发会让客户端把整段思考算进 TTFT`,
    );

    const firstContent = frames.findIndex((f) => {
      const value = f.choices?.[0]?.delta?.content;
      return typeof value === 'string' && value !== '';
    });
    assert.ok(firstContent > 0, '正文帧必须存在');
    assert.ok(reasoningIdx.at(-1) < firstContent, 'reasoning 必须全部在正文之前');
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 多账号签到：本机每个已登录账号各领各的。
 *
 * 钉住三件容易做错的事：
 *   1. **按 uid 去重** —— 客户端换号会留下带时间戳的旧快照，不去重就会重复领、
 *      并在面板里列出同一个人的好几行；
 *   2. **没有签到活动 ≠ 失败** —— 国际版网关没有积分活动，报成 failed 会让用户
 *      以为账号坏了（而且 `failed` 是要红的）；
 *   3. **响应里不能有令牌** —— 这个接口会一次列出本机所有账号。
 */
test('桥：多账号签到 —— 按 uid 去重、逐个领取、无活动不算失败', { timeout: 90_000 }, async () => {
  // 目录本身就是 auth 目录（mkdtemp 已建好），避免再依赖 mkdirSync
  const authDir = mkdtempSync(join(tmpdir(), 'wb-multi-checkin-'));
  const jwtFor = (uid) => 'x.' + Buffer.from(JSON.stringify({
    sub: uid,
    exp: Math.floor(Date.now() / 1000) + 3600,
  })).toString('base64url') + '.y';
  const writeInfo = (name, uid, domain, mtimeSec) => {
    const file = join(authDir, name);
    writeFileSync(file, JSON.stringify({
      auth: { accessToken: jwtFor(uid), refreshToken: 'r', domain, expiresAt: Date.now() + 86_400_000 },
      account: { uid, nickname: '昵称-' + uid, uin: '100' },
    }));
    if (mtimeSec) utimesSync(file, mtimeSec, mtimeSec);
  };
  // 同一 uid 的两个快照：旧的那个必须被丢掉（否则会重复出现在列表里）
  writeInfo('a-old.info', 'uid-a', 'www.workbuddy.cn', 1_700_000_000);
  writeInfo('a-new.info', 'uid-a', 'www.workbuddy.cn', 1_700_000_100);
  writeInfo('b.info', 'uid-b', 'www.workbuddy.ai', 1_700_000_200);

  const seen = [];
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    const uid = String(req.headers['x-user-id'] || '');
    seen.push(`${uid} ${path}`);
    res.writeHead(200, { 'content-type': 'application/json' });
    if (path === '/v2/billing/meter/daily-checkin') {
      if (uid === 'uid-b') return res.end(JSON.stringify({ code: 10086, msg: '签到活动未开启或已过期' }));
      return res.end(JSON.stringify({ code: 0, data: { credit: 100, streak_days: 3 } }));
    }
    if (path === '/v2/billing/meter/checkin-activity-status') {
      return res.end(JSON.stringify({
        code: 0,
        data: { active: uid !== 'uid-b', today_checked_in: false, daily_credit: 100 },
      }));
    }
    return res.end(JSON.stringify({ code: 0, data: {} }));
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));

  const bridge = await startBridge(
    {
      WORKBUDDY_AUTH_DIR: authDir,
      WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${upstream.address().port}`,
      WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    },
    { auth: authFileFor('uid-a') },
  );
  try {
    const list = await (await fetch(`${bridge.baseUrl}/v1/checkin/accounts`, {
      headers: auth, signal: AbortSignal.timeout(40000),
    })).json();
    assert.deepEqual(list.accounts.map((a) => a.userId).sort(), ['uid-a', 'uid-b'],
      `同一 uid 的多个快照必须去重，实得 ${JSON.stringify(list.accounts.map((a) => a.userId))}`);
    assert.ok(!JSON.stringify(list).includes('accessToken'), '响应里不能出现令牌字段');
    const rowA = list.accounts.find((x) => x.userId === 'uid-a');
    assert.equal(rowA.current, true, '当前正在跑模型的账号要打标记');
    assert.equal(rowA.region, 'cn');
    assert.equal(list.accounts.find((x) => x.userId === 'uid-b').region, 'intl', '国际版要看登录域名');
    // 只读路径也要标出「没有签到活动」：否则面板只能显示「未签」，像是漏签了
    assert.equal(list.accounts.find((x) => x.userId === 'uid-b').noActivity, true);
    assert.equal(list.totals.skipped, 1);

    const claim = await (await fetch(`${bridge.baseUrl}/v1/checkin/all`, {
      method: 'POST', headers: auth, signal: AbortSignal.timeout(60000),
    })).json();
    assert.equal(claim.totals.claimed, 1, 'uid-a 应当领到 1 次');
    assert.equal(claim.totals.failed, 0, `「没有签到活动」不能算失败，实得 ${JSON.stringify(claim.totals)}`);
    assert.equal(claim.totals.skipped, 1);
    const rowB = claim.accounts.find((x) => x.userId === 'uid-b');
    assert.equal(rowB.noActivity, true);
    assert.equal(rowB.error, undefined, '无活动不能同时写成错误');
    assert.ok(seen.some((c) => c.startsWith('uid-b /v2/billing/meter/daily-checkin')),
      'B 也必须真的问过上游（否则 skipped 是假的）');
  } finally {
    await bridge.stop();
    upstream.close();
    rmSync(authDir, { recursive: true, force: true });
  }
});

/**
 * 自动签到必须**按账号**判定（issue #32）。
 *
 * ## 现场
 *
 * 本机登录两个号：当前账号是国际版（`workbuddy.ai` 网关，没有积分活动），
 * 另一个是国内账号（有活动、没签）。自动签到跑完的结果是：国内账号一次都没被
 * 尝试过，当天也不会再被尝试 —— 因为「无活动」被写进了**全局**的
 * `autoCheckinDoneDay`，整轮直接收工。
 *
 * ## 这条用例钉住的行为
 *
 *   1. 当前账号（国际版）判 no-activity，且**只影响它自己**；
 *   2. 同一次自动签到里，国内账号必须真的被打到上游 `/daily-checkin` 并签到成功；
 *   3. `/health.autoCheckin` 要如实给出每个账号各自的结果（不能只报当前账号）。
 *
 * 为了让"自动签到"在测试里马上发生，用 `WORKBUDDY_CHECKIN_KICK_MS=0` +
 * 显式打开 `WORKBUDDY_AUTO_CHECKIN`（其余用例都把它关掉）。
 */
test('桥：自动签到按账号独立 —— 当前账号无活动不阻止其它账号（issue #32）', { timeout: 90_000 }, async () => {
  const authDir = mkdtempSync(join(tmpdir(), 'wb-auto-checkin-per-account-'));
  const jwtFor = (uid) => 'x.' + Buffer.from(JSON.stringify({
    sub: uid,
    exp: Math.floor(Date.now() / 1000) + 3600,
  })).toString('base64url') + '.y';
  const writeInfo = (name, uid, domain) => {
    writeFileSync(join(authDir, name), JSON.stringify({
      auth: { accessToken: jwtFor(uid), refreshToken: 'r', domain, expiresAt: Date.now() + 86_400_000 },
      account: { uid, nickname: '昵称-' + uid, uin: '100' },
    }));
  };
  // 当前账号（authFile 指的就是它）= 国际版，没有签到活动
  writeInfo('intl.info', 'uid-intl', 'www.workbuddy.ai');
  // 另一个账号 = 国内版，有活动且没签
  writeInfo('cn.info', 'uid-cn', 'www.workbuddy.cn');

  const seen = [];
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    const uid = String(req.headers['x-user-id'] || '');
    seen.push(`${uid} ${path}`);
    res.writeHead(200, { 'content-type': 'application/json' });
    if (path === '/v2/billing/meter/daily-checkin') {
      // 国际版网关：签到活动未开启
      if (uid === 'uid-intl') return res.end(JSON.stringify({ code: 10086, msg: '签到活动未开启或已过期' }));
      return res.end(JSON.stringify({ code: 0, data: { credit: 100, streak_days: 3 } }));
    }
    if (path === '/v2/billing/meter/checkin-activity-status') {
      return res.end(JSON.stringify({
        code: 0,
        data: { active: uid !== 'uid-intl', today_checked_in: false, daily_credit: 100 },
      }));
    }
    return res.end(JSON.stringify({ code: 0, data: {} }));
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));

  const bridge = await startBridge(
    {
      WORKBUDDY_AUTH_DIR: authDir,
      // 目录本身就是 auth 目录，当前账号由 authFile 指定（国际版那个）
      WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${upstream.address().port}`,
      WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
      WORKBUDDY_AUTO_CHECKIN: '1',
      WORKBUDDY_CHECKIN_KICK_MS: '0',
      WORKBUDDY_CHECKIN_COOLDOWN_MS: '0',
    },
    { auth: authFileFor('uid-intl', 'www.workbuddy.ai') },
  );
  try {
    // 等自动签到把两个账号都走完：判据是「国内账号真的被领过」
    const deadline = Date.now() + 60_000;
    let health = null;
    while (Date.now() < deadline) {
      health = await (await fetch(`${bridge.baseUrl}/health`, {
        headers: auth, signal: AbortSignal.timeout(8000),
      })).json();
      const claimedCn = seen.some((c) => c === 'uid-cn /v2/billing/meter/daily-checkin');
      if (claimedCn && health?.autoCheckin?.at) break;
      await new Promise((r) => setTimeout(r, 300));
    }

    assert.ok(seen.some((c) => c === 'uid-intl /v2/billing/meter/daily-checkin'),
      `当前账号（国际版）也该被尝试一次，实际请求：${JSON.stringify(seen)}`);
    assert.ok(seen.some((c) => c === 'uid-cn /v2/billing/meter/daily-checkin'),
      `国内账号必须被自动签到照顾到（这正是 issue #32 的缺陷），实际请求：${JSON.stringify(seen)}`);

    const auto = health?.autoCheckin;
    assert.ok(auto?.accounts?.length >= 2,
      `autoCheckin.accounts 必须逐账号给出结果，实得 ${JSON.stringify(auto)}`);
    const intl = auto.accounts.find((x) => x.key === 'uid-intl');
    const cn = auto.accounts.find((x) => x.key === 'uid-cn');
    assert.equal(intl?.result, 'no-activity', '国际版账号应判 no-activity');
    assert.equal(cn?.result, 'ok', `国内账号应签到成功，实得 ${JSON.stringify(cn)}`);
    assert.equal(cn?.credit, 100);
    // 顶层 result 仍是「当前账号」的结论（控制台/面板都读这个字段）
    assert.equal(auto.result, 'no-activity', '顶层 result 代表当前账号');

    /*
     * 再打一次会触发自动签到的入口：两个账号当天都已收工（国际版无活动、国内版已签），
     * 不该再对上游重复领。这条同时守住"按账号的 done 标记真的生效"——
     * 只改判断不记标记的话，定时器每轮都会重领一遍。
     */
    const before = seen.filter((c) => c.endsWith('/daily-checkin')).length;
    await fetch(`${bridge.baseUrl}/v1/checkin`, {
      method: 'POST', headers: auth, signal: AbortSignal.timeout(30000),
    });
    await new Promise((r) => setTimeout(r, 1500));
    const after = seen.filter((c) => c.endsWith('/daily-checkin')).length;
    // 手动 POST /v1/checkin 本来就只签当前账号一次（那是显式操作，不受自动签到的 done 影响）
    assert.ok(after - before <= 1,
      `自动签到不该重复领（${before} -> ${after}）`);
  } finally {
    await bridge.stop();
    upstream.close();
    rmSync(authDir, { recursive: true, force: true });
  }
});

/**
 * 自动签到的**热路径成本**（issue #32 的连带回归）。
 *
 * `maybeAutoCheckin()` 挂在三条协议入口上，每个 token 流都会碰一次。按账号独立
 * 之后它还要 `resolveAuth()` + `readLocalAccounts()`（扫目录 + 逐个解 at-rest
 * 信封）。如果每个请求都跑一遍，就是纯浪费 —— 而且症状极隐蔽：CPU/IO 升高、
 * 上游计费端点被打多次，但**功能看起来正常**。
 *
 * 钉住的契约：两个账号今天都结束后，继续打模型请求**不再**命中间计费端点。
 * 这条用真实的 chat 请求驱动（而不是直接调内部函数），因为要防的正是
 * "从请求路径进来"的那条路。
 */
test('桥：账号都签完之后，模型请求不再重复触发自动签到（热路径不许反复扫盘）', { timeout: 90_000 }, async () => {
  const authDir = mkdtempSync(join(tmpdir(), 'wb-checkin-hotonce-'));
  const jwtFor = (uid) => 'x.' + Buffer.from(JSON.stringify({
    sub: uid, exp: Math.floor(Date.now() / 1000) + 3600,
  })).toString('base64url') + '.y';
  const writeInfo = (name, uid, domain) => {
    writeFileSync(join(authDir, name), JSON.stringify({
      auth: { accessToken: jwtFor(uid), refreshToken: 'r', domain, expiresAt: Date.now() + 86_400_000 },
      account: { uid, nickname: '昵称-' + uid, uin: '100' },
    }));
  };
  writeInfo('a.info', 'uid-a', 'www.workbuddy.cn');
  writeInfo('b.info', 'uid-b', 'www.workbuddy.cn');

  const checkinHits = [];
  const billing = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v2/billing/meter/daily-checkin') {
      checkinHits.push(String(req.headers['x-user-id'] || ''));
    }
    res.writeHead(200, { 'content-type': 'application/json' });
    if (path === '/v2/billing/meter/daily-checkin') {
      return res.end(JSON.stringify({ code: 0, data: { credit: 50 } }));
    }
    if (path === '/v2/billing/meter/checkin-activity-status') {
      return res.end(JSON.stringify({ code: 0, data: { active: true, today_checked_in: false } }));
    }
    return res.end(JSON.stringify({ code: 0, data: {} }));
  });
  await new Promise((r) => billing.listen(0, '127.0.0.1', r));

  const stub = await startStubUpstream(['stub-model']);
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: stub.base,
    WORKBUDDY_AUTH_DIR: authDir,
    WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${billing.address().port}`,
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_AUTO_CHECKIN: '1',
    WORKBUDDY_CHECKIN_KICK_MS: '0',
    WORKBUDDY_CHECKIN_COOLDOWN_MS: '0',
  }, { auth: authFileFor('uid-a') });

  const chat = async () => {
    const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
      method: 'POST',
      headers: { ...auth, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }], stream: false }),
      signal: AbortSignal.timeout(20_000),
    });
    await res.text();
  };
  try {
    // 第一轮：等两个账号都被签完
    const deadline = Date.now() + 60_000;
    while (Date.now() < deadline) {
      const got = new Set(checkinHits);
      if (got.has('uid-a') && got.has('uid-b')) break;
      await new Promise((r) => setTimeout(r, 250));
    }
    const afterFirst = checkinHits.length;
    assert.ok(new Set(checkinHits).size >= 2,
      `两个账号都该被签到过，实际 ${JSON.stringify(checkinHits)}`);

    /*
     * 再打 5 次模型请求：每次都会进 maybeAutoCheckin()。今天都已结束，
     * 一条都不该再打到计费端点。
     */
    for (let i = 0; i < 5; i += 1) await chat();
    await new Promise((r) => setTimeout(r, 800));
    assert.equal(checkinHits.length, afterFirst,
      `都已签完却又打了 ${checkinHits.length - afterFirst} 次签到（热路径在重复扫盘）：${JSON.stringify(checkinHits)}`);
  } finally {
    await bridge.stop();
    try { await stub.close(); } catch { /* 忽略 */ }
    billing.close();
    rmSync(authDir, { recursive: true, force: true });
    rmSync(bridge.dir, { recursive: true, force: true });
  }
});

/**
 * 单账号签到的「没有活动」分支：必须是 200 + noActivity，而不是 502 失败。
 *
 * 现场症状（2026-10-26）：国际版账号的签到卡片上写着「领取失败：签到活动未开启
 * 或已过期」，用户以为账号坏了。实际是那个网关根本没有积分活动 —— 桥把它当异常
 * 抛出，界面就只能报错。这条用例把「没活动」钉成一种**正常状态**。
 */
test('桥：单账号签到「没有活动」回 200 + noActivity（不是失败）', { timeout: 60_000 }, async () => {
  const authDir = mkdtempSync(join(tmpdir(), 'wb-noactivity-'));
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    res.writeHead(200, { 'content-type': 'application/json' });
    if (path === '/v2/billing/meter/daily-checkin') {
      return res.end(JSON.stringify({ code: 10086, msg: '签到活动未开启或已过期' }));
    }
    if (path === '/v2/billing/meter/checkin-activity-status') {
      return res.end(JSON.stringify({ code: 0, data: { active: false, today_checked_in: false } }));
    }
    return res.end(JSON.stringify({ code: 0, data: {} }));
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));

  const bridge = await startBridge(
    {
      WORKBUDDY_AUTH_DIR: authDir,
      WORKBUDDY_BILLING_BASE: `http://127.0.0.1:${upstream.address().port}`,
      WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    },
    { auth: authFileFor('uid-intl', 'www.workbuddy.ai') },
  );
  try {
    const res = await fetch(`${bridge.baseUrl}/v1/checkin`, {
      method: 'POST', headers: auth, signal: AbortSignal.timeout(30000),
    });
    const body = await res.json();
    assert.equal(res.status, 200, '「没有签到活动」不是失败，不能回 502');
    assert.equal(body.ok, true);
    assert.equal(body.noActivity, true, '必须明确标出 noActivity，界面才不会写成「领取失败」');
    assert.equal(body.status?.active, false, '顺带把状态带回，界面可以显示「无签到活动」');
  } finally {
    await bridge.stop();
    upstream.close();
    rmSync(authDir, { recursive: true, force: true });
  }
});

test('限流统计：时间戳滑动窗口（窗口外的旧 429 不再计数）', { timeout: 90_000 }, async () => {
  /*
   * 旧实现是 `{count, lastAt}`：只要相邻两次 429 间隔不超过窗口，`count`
   * 就一直累加 —— 稀疏的偶发限流攒到阈值同样会触发自动切号（切钱包）。
   * 这里把窗口压到 1.2s：发一次 → 等它过期 → 再发一次，计数必须回到 1。
   */
  const upstream = await startStubUpstream(['stub-model'], {
    // 通用 429（没有 14003/6004 业务码）才计入账号切号的 10 分钟窗口；
    // 14003 是模型级繁忙，另有专门用例钉住“不计数”。
    chatSequence: [{ status: 429, type: 'application/json', raw: JSON.stringify({ code: 42901, msg: 'rate limited' }) }],
  });
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: upstream.base,
    WORKBUDDY_RATE_LIMIT_WINDOW_MS: '1200',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const chat = async () => {
      const res = await fetch(bridge.baseUrl + '/v1/chat/completions', {
        method: 'POST',
        headers: { ...auth, 'content-type': 'application/json' },
        body: JSON.stringify({ model: 'stub-model', messages: [{ role: 'user', content: 'hi' }] }),
        signal: AbortSignal.timeout(15_000),
      });
      await res.text();
      return res.status;
    };
    const health = async () => (await fetch(bridge.baseUrl + '/health', { headers: auth, signal: AbortSignal.timeout(8000) })).json();

    assert.equal(await chat(), 429, '上游 429 应当原样返回给客户端');
    let h = await health();
    assert.equal(h.rateLimit?.count, 1);
    assert.equal(h.rateLimit?.windowMs, 1200, '窗口要通过 /health 如实暴露');
    assert.equal(h.rateLimit?.model, 'stub-model');

    await new Promise((r) => setTimeout(r, 1500));
    h = await health();
    assert.equal(h.rateLimit?.count, 0, '窗口外的 429 必须过期，而不是永久累计');

    assert.equal(await chat(), 429);
    h = await health();
    assert.equal(h.rateLimit?.count, 1, '窗口内没再发生时不能累计成 2');
  } finally {
    await bridge.stop();
    await upstream.close();
  }
});

test('冷目录负缓存：上游目录持续失败时，连发请求不重复打上游（refresh 仍可强制）', { timeout: 90_000 }, async () => {
  let catalogHits = 0;
  const upstream = createServer((req, res) => {
    const path = new URL(req.url, 'http://127.0.0.1').pathname;
    if (path === '/v3/config' || path === '/v2/enterprises/personal/models') {
      catalogHits += 1;
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end('{"code":500,"msg":"boom"}');
    }
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end('{}');
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  const upstreamBase = `http://127.0.0.1:${upstream.address().port}`;
  const bridge = await startBridge({
    CODEBUDDY_ENDPOINT: upstreamBase,
    WORKBUDDY_CATALOG_RETRY_MS: '60000',
  }, { auth: READABLE_FAKE_AUTH });
  try {
    const first = await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth, signal: AbortSignal.timeout(20_000) });
    assert.equal(first.status, 200, '目录失败也要回兜底目录，而不是 5xx');
    await first.text();
    const afterFirst = catalogHits;
    assert.ok(afterFirst >= 1, '第一次必须真的尝试过上游');

    // 负缓存窗口内再来两次：不能再打上游
    for (let i = 0; i < 2; i += 1) {
      const res = await fetch(bridge.baseUrl + '/v1/models?all=1', { headers: auth, signal: AbortSignal.timeout(20_000) });
      await res.text();
    }
    assert.equal(catalogHits, afterFirst, '负缓存窗口内重复请求不得再打上游目录');

    // 手动刷新（?refresh=1）必须无视负缓存
    const refresh = await fetch(bridge.baseUrl + '/v1/models?all=1&refresh=1', { headers: auth, signal: AbortSignal.timeout(20_000) });
    await refresh.text();
    assert.ok(catalogHits > afterFirst, '用户点「刷新」必须真的重试上游');
  } finally {
    await bridge.stop();
    await new Promise((r) => upstream.close(r));
  }
});
