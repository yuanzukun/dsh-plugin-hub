/**
 * 前端验收骨架：无头 Chromium + CDP + `window.fetch` 打桩。
 *
 * 为什么不用真控制台：页面要的数据（目录 / 用量 / 体检结论 / 请求明细）都来自
 * 后端接口，靠真实实例构造「已知输入」既慢又会消耗上游额度。这里只起一个
 * **静态**文件服务，把 `/api/*` 全部打桩，让页面的渲染分支完全可控。
 *
 * 用法见 tools/dev/test-r9-scope.mjs。
 */
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { closeSync, existsSync, mkdtempSync, openSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const PUBLIC_DIR = join(root, 'dashboard', 'public');

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ── 静态服务（只服务 dashboard/public）──────────────────────────────────
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml' };

export async function startStaticServer(port) {
  const server = createServer((req, res) => {
    const path = (req.url || '/').split('?')[0];
    const file = path === '/' ? join(PUBLIC_DIR, 'index.html') : join(PUBLIC_DIR, path.replace(/^\/+/, ''));
    if (!file.startsWith(PUBLIC_DIR) || !existsSync(file)) { res.writeHead(404).end('not found'); return; }
    res.writeHead(200, {
      'Content-Type': MIME[extname(file)] || 'application/octet-stream',
      /*
       * 静态资源一律**不缓存**。
       *
       * 为什么必须显式写：openPage 会**复用**常驻的 headless 实例（多个脚本串跑时
       * 不必反复冷启动），而 Chrome 对没有缓存头的资源走启发式缓存。于是改完
       * `style.css` / `index.html` 再跑测试时，页面拿到的还是**上一次**的版本 ——
       * 表现是「改动明明落盘了，测试和截图却完全看不到」，而且不报任何错，
       * 极难排查（本项目实际踩到：给状态卡加语义色后截图里毫无变化）。
       */
      'Cache-Control': 'no-store',
    });
    res.end(readFileSync(file));
  });
  await new Promise((ok) => server.listen(port, '127.0.0.1', ok));
  return server;
}

// ── 无头 Chrome ─────────────────────────────────────────────────────────
function findChrome() {
  if (process.env.CHROME_PATH) return process.env.CHROME_PATH;
  const candidates = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    join(process.env.LOCALAPPDATA || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/usr/bin/google-chrome',
  ];
  return candidates.find((p) => p && existsSync(p));
}

/**
 * 探一个端口上到底是什么，**三态**（与 `probePortPid` 同一套纪律）：
 *
 *   `devtools` —— 是 Chrome DevTools（`/json/version` 给了 webSocketDebuggerUrl）
 *   `foreign`  —— 有 HTTP 服务在答，但不是 DevTools（或答了但不回话/超时）
 *   `absent`   —— 连不上（ECONNREFUSED 等），**可以放心在上面起实例**
 *
 * 为什么必须分开：早先 `devtoolsPages()` 只做"轮询 /json/list 直到有 page"，
 * 于是端口被**别的** HTTP 服务占着时，它会老老实实轮询满 60×250ms=15 秒再抛
 * 「无法连接 DevTools」—— 那句话把"端口冲突"说成了"浏览器起不来"，而且紧接着
 * 又在这个端口上 spawn 一个 Chrome（绑定必失败），再轮询 15 秒，共 31.5 秒，
 * 还把那个注定失败的 Chrome 进程留在后台（实测泄漏 3 个无头实例）。
 */
async function probeCdp(port, timeoutMs = 1200) {
  try {
    const res = await fetch(`http://127.0.0.1:${port}/json/version`, {
      signal: AbortSignal.timeout(timeoutMs),
    });
    const body = await res.json().catch(() => null);
    const ws = body && typeof body.webSocketDebuggerUrl === 'string' ? body.webSocketDebuggerUrl : '';
    return ws
      ? { state: 'devtools', detail: '', ws }
      : { state: 'foreign', detail: `HTTP ${res.status} 但不是 DevTools`, ws: '' };
  } catch (error) {
    const text = `${error?.cause?.code || ''} ${error?.code || ''} ${error?.message || ''}`;
    if (error?.name === 'TimeoutError' || error?.name === 'AbortError') {
      // 有人在听但不回话：同样不能当成"空着"
      return { state: 'foreign', detail: '端口无响应（可能被别的程序占用）', ws: '' };
    }
    if (/ECONNREFUSED|ECONNRESET|EAI_AGAIN|fetch failed|EPIPE/i.test(text)) {
      return { state: 'absent', detail: '', ws: '' };
    }
    return { state: 'absent', detail: String(error?.message || error), ws: '' };
  }
}

/**
 * 端口上的**全部** page 目标（含 ws），供 openPage 判断"实例是否已在跑"。
 *
 * 注意它只用来**判断实例存在**，不再拿它挑"第一张页面"来用 ——
 * 复用旧页面会把上一个脚本的注入脚本、localStorage、对话框处理器一起带过来
 * （详见 `openPage` 里 `newTarget` 的说明）。
 *
 * 端口被**别的程序**占着时立刻抛 `CDP_PORT_FOREIGN`，不要白等 15 秒：
 * 那不是"浏览器起不来"，换端口就能好（见 {@link openPage} 的自动改端口）。
 */
async function devtoolsPages(port) {
  const probe = await probeCdp(port);
  if (probe.state === 'foreign') {
    const err = new Error(`端口 ${port} 被别的程序占着（${probe.detail}），不能当 DevTools 端口`);
    err.code = 'CDP_PORT_FOREIGN';
    throw err;
  }
  return waitForPages(port);
}

/**
 * 单纯等端口上出现 page 目标（最多 15 秒），**不做** foreign 判定。
 *
 * ## 为什么必须与 {@link devtoolsPages} 分开（实测缺陷，CI run 42241477770）
 *
 * 冷启动有一个窗口：Chrome 的 DevTools HTTP 服务**已经开始监听**，但 `/json/version`
 * 还没准备好（返回 200 但没有 `webSocketDebuggerUrl`，或返回 404/500）。
 * 此时 `probeCdp` 会把它判成 `foreign`（"有 HTTP 服务但不是 DevTools"）——
 * 而那个服务正是**我们刚 spawn 的 Chrome 自己**。
 *
 * 于是 `coldStartOn` → `devtoolsPages` → 抛 `CDP_PORT_FOREIGN` → catch 里
 * 把自己刚拉起来的 Chrome **杀掉**，然后报「15 秒内没有出现任何 DevTools 页面」。
 * 症状是 CI 上第一次冷启动必挂、本地却常常能过（本地机器快，抢不进那个窗口）。
 *
 * 冷启动路径只该**等**，不该判"这是不是别人"。归属判定属于复用分支。
 */
async function waitForPages(port, timeoutMs = 15_000) {
  // 每 250ms 探一次；次数由超时预算决定（CI 上冷启动可能十几秒）
  const attempts = Math.max(1, Math.ceil(timeoutMs / 250));
  for (let i = 0; i < attempts; i += 1) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/json/list`);
      const targets = await res.json();
      const pages = targets.filter((t) => t.type === 'page' && t.webSocketDebuggerUrl);
      if (pages.length) return pages;
    } catch { /* 还没起来 */ }
    await sleep(250);
  }
  throw new Error(`端口 ${port} 上 ${Math.round(timeoutMs / 1000)} 秒内没有出现任何 DevTools 页面`);
}

/**
 * 让系统分配一个空闲端口。
 *
 * 只用于"端口冲突时换一个"这条兜底路径 —— 平时由调用方显式传端口，
 * 便于失败时按端口定位。
 *
 * ## 为什么优先从 20000–29999 里挑
 *
 * 本机 `netsh int ipv4 show dynamicport tcp` 是 **1024–15000**，而 `listen(0)`
 * 拿到的正是这一段。把它交给 Chrome 的 `--remote-debugging-port` 有 TOCTOU：
 * 我们 close 之后、Chrome bind 之前，任何一次出站连接都可能把它占走，于是
 * 「Chrome 起不来」以 15 秒超时的形式出现。项目里 `tools/dev/bridge-ports.mjs`
 * 早就为桥定下了这条规矩（20000–29999：高于 Windows 动态段、低于 Linux 临时段），
 * 这里对齐同一口径，先在这一段里试，全被占了才退回 `listen(0)`。
 *
 * @returns {Promise<number>}
 */
export async function freePort() {
  const { BRIDGE_PORT_MIN, BRIDGE_PORT_MAX } = await import('./bridge-ports.mjs');
  const tryBind = (port) => new Promise((resolve) => {
    const srv = createServer();
    srv.once('error', () => resolve(false));
    srv.listen(port, '127.0.0.1', () => srv.close(() => resolve(true)));
  });
  for (let i = 0; i < 40; i += 1) {
    const span = BRIDGE_PORT_MAX - BRIDGE_PORT_MIN + 1;
    const port = BRIDGE_PORT_MIN + Math.floor(Math.random() * span);
    if (await tryBind(port)) return port;
  }
  // 兜底：让系统给（可能落在动态段，但至少是当下真的空的）
  const srv = createServer();
  await new Promise((resolve, reject) => {
    srv.once('error', reject);
    srv.listen(0, '127.0.0.1', resolve);
  });
  const { port } = srv.address();
  await new Promise((resolve) => srv.close(resolve));
  return port;
}

/** 极简 CDP 客户端。 */
function connect(url) {
  const ws = new WebSocket(url);
  let id = 0;
  const pending = new Map();
  const listeners = new Map();

  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data);
    if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); return; }
    if (msg.method && listeners.has(msg.method)) for (const fn of listeners.get(msg.method)) fn(msg.params);
  });

  const ready = new Promise((ok, bad) => {
    ws.addEventListener('open', ok);
    ws.addEventListener('error', () => bad(new Error('WebSocket 连接失败')));
  });

  const send = (method, params = {}) => new Promise((ok) => {
    id += 1;
    pending.set(id, ok);
    ws.send(JSON.stringify({ id, method, params }));
  });

  const on = (method, fn) => {
    if (!listeners.has(method)) listeners.set(method, []);
    listeners.get(method).push(fn);
  };

  const evaluate = async (expression) => {
    const res = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
    if (res.result && res.result.exceptionDetails) {
      throw new Error(`页面求值异常：${res.result.exceptionDetails.text}\n${expression.slice(0, 300)}`);
    }
    return res.result && res.result.result ? res.result.result.value : undefined;
  };

  return { ready, send, on, evaluate, close: () => ws.close() };
}

let shapeCache = null;
/**
 * 按接口形状表（api-shape.json）生成"最小合法桩"：结构齐全、值全部是类型默认值。
 *
 * 验收脚本里凡是**值不重要、但字段名必须对**的接口，用它当底再按需覆盖 ——
 * 这是「桩数据不再骗人」纪律的低成本落地：形状永远跟随形状表，不靠手抄。
 * 重取形状：`node tools/dev/api-shape.mjs capture`。
 *
 * @param {string} path 例如 '/api/checkin'
 * @returns {object} 结构齐全的桩对象（空值）
 */
export function shapeStub(path) {
  if (!shapeCache) {
    try {
      shapeCache = JSON.parse(readFileSync(join(root, 'tools', 'dev', 'api-shape.json'), 'utf8')).routes || {};
    } catch {
      shapeCache = {};
    }
  }
  const shape = shapeCache[path];
  if (!shape) return {};
  const defVal = (t) => (t === 'object' ? {} : t === 'array' ? [] : t === 'string' ? '' : t === 'number' ? 0 : t === 'boolean' ? false : null);
  const out = {};
  for (const [key, meta] of Object.entries(shape)) {
    if (key === '$') continue;
    const segs = key.slice(2).split('.'); // "status.streakDays" → ['status','streakDays']
    if (segs.some((s) => s.endsWith('[]'))) continue; // 数组元素键：数组本身已是空 []
    let cur = out;
    for (let i = 0; i < segs.length - 1; i += 1) {
      if (typeof cur[segs[i]] !== 'object' || cur[segs[i]] === null) cur[segs[i]] = {};
      cur = cur[segs[i]];
    }
    cur[segs[segs.length - 1]] = defVal(meta.type);
  }
  return out;
}

/**
 * 把路由表序列化成**注入用的 JS 字面量**。
 *
 * 不能用 JSON.stringify：`body` 允许是函数（按查询串分流时必需），而
 * JSON.stringify 会把函数直接丢掉，页面拿到的是一个没有 body 的空路由。
 */
function serializeRoutes(routes) {  const parts = [];
  for (const [path, r] of Object.entries(routes)) {
    const body = typeof r.body === 'function'
      ? `(${r.body.toString()})`
      : JSON.stringify(r.body === undefined ? {} : r.body);
    parts.push(`${JSON.stringify(path)}: { status: ${Number(r.status) || 200}, hang: ${!!r.hang}, delay: ${Number(r.delay) || 0}, type: ${JSON.stringify(r.type || '')}, chunks: ${JSON.stringify(r.chunks || null)}, body: ${body} }`);
  }
  return `{ ${parts.join(', ')} }`;
}

/**
 * 打桩脚本：把 `/api/*` 的响应换成测试给定值，并记录所有被请求的路径。
 *
 * routes: { '/api/models': { status?, body } }；body 为对象 / 字符串 / 函数
 *         （函数收到完整 URL，用于按查询串分流）；未命中的路径一律返回 `{}`。
 */
export function fetchStubSource(routes) {
  return `(() => {
    const ROUTES = ${serializeRoutes(routes)};
    window.__calls = [];
    window.__setRoute = (path, route) => { ROUTES[path] = route; };
    const origFetch = window.fetch;
    window.__posts = []; // 记录带 JSON body 的请求（「本轮发送 N 条消息」这类断言要用）
    window.__reqs = [];  // 记录**所有**请求的 {path, method, body}——无 body 的 POST 只能靠它
    window.fetch = async function (input, init) {
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      const path = url.replace(/^https?:\\/\\/[^/]+/, '').split('?')[0];
      const method = (init && init.method) || 'GET';
      let parsed = null;
      if (init && typeof init.body === 'string') {
        try { parsed = JSON.parse(init.body); } catch (e) { parsed = null; }
      }
      window.__calls.push(path);
      window.__reqs.push({ path: path, method: method, body: parsed });
      if (parsed !== null) window.__posts.push({ path: path, method: method, body: parsed });
      const r = ROUTES[path];
      if (!r) return new Response('{}', { status: 200, headers: { 'Content-Type': 'application/json' } });
      if (r.hang) return new Promise(() => {});
      // delay 用来观察「进行中」状态（按钮禁用 / 文案变化）
      if (r.delay) await new Promise((res) => setTimeout(res, r.delay));
      // chunks 用来模拟 SSE 分块流（每块可带自己的 delay）——「停止但已有内容」要靠它。
      // 必须**自己接 signal**：这是打桩的 fetch，浏览器不会替我们把 abort 接到流上，
      // 不接的话页面调 abort() 完全无效，「手动停止」就没法验。
      if (r.chunks) {
        const enc = new TextEncoder();
        const signal = init && init.signal;
        const stream = new ReadableStream({
          async start(controller) {
            let done = false;
            const fail = () => {
              if (done) return;
              done = true;
              try { controller.error(new DOMException('The operation was aborted.', 'AbortError')); } catch (e) { /* 已关闭 */ }
            };
            if (signal) {
              if (signal.aborted) { fail(); return; }
              signal.addEventListener('abort', fail, { once: true });
            }
            for (const c of r.chunks) {
              if (c.delay) await new Promise((res) => setTimeout(res, c.delay));
              if (done || (signal && signal.aborted)) { fail(); return; }
              try { controller.enqueue(enc.encode(c.text)); } catch (e) { return; }
            }
            if (done) return;
            done = true;
            try { controller.close(); } catch (e) { /* 已关闭 */ }
          },
        });
        return new Response(stream, { status: r.status || 200, headers: { 'Content-Type': r.type || 'text/event-stream' } });
      }
      // body 传函数时把完整 URL（含查询串）交给它：同一路径下 days=7 与
      // days=1&hours=1 往往要返回不同的数据
      const body = typeof r.body === 'function' ? r.body(url) : r.body;
      const text = typeof body === 'string' ? body : JSON.stringify(body === undefined ? {} : body);
      return new Response(text, { status: r.status || 200, headers: { 'Content-Type': r.type || 'application/json' } });
    };
    window.__origFetch = origFetch;
  })();`;
}

/**
 * 在指定端口冷启动一个无头 Chrome 并等它出页面。
 *
 * ## 为什么单独抽出来，而不是内联在 `openPage` 的那段里
 *
 * 冷启动失败必须**能换端口重试**：探测到 `absent` 与 Chrome 真正 `bind` 之间有一个
 * 窗口（TOCTOU），端口可能刚被别的程序抢走。
 *
 * ## 三处「静默失效」一起修
 *
 *   ① **Chrome 的输出不能丢**。失败形态往往只有 Chrome 自己说得清：
 *      `bind() failed: Permission denied`、`Cannot create user data directory`、
 *      `DevToolsActivePort file doesn't exist`。
 *      ⚠️ 用 `stderr: 'pipe'` **在 detached + unref 下不可靠**：父进程 unref 之后
 *      管道可能拿不到数据（实测 CI 上收回来的是 0 字节，反而让真因更看不见）。
 *      改成重定向到**临时文件**，失败时读它 —— 文件不依赖父进程还持有句柄。
 *   ② **`error` 事件必须挂监听**。spawn 失败（ENOENT / EACCES / EMFILE）不抛异常，
 *      而是异步 emit —— 没监听就是未捕获异常，整个验收脚本被带走。
 *   ③ **失败信息不能自己套自己**。原先 `detail()` 为空时回退成 `error.message`，
 *      而 `error.message` 就是那句「15 秒内没有出现任何 DevTools 页面」——
 *      于是输出变成「没起来（15 秒内没有出现…），换端口重试」，看起来像有信息，
 *      实际什么都没说。现在分开：`detail` 只放 Chrome 自己说的话，没有就是空。
 *
 * @returns {Promise<{ok: true, wsUrl: string, chrome: any, profileDir: string}
 *   | {ok: false, detail: string, error?: any}>}
 */
async function coldStartOn(port, { width, height }) {
  const exe = findChrome();
  if (!exe) throw new Error('找不到 Chrome/Edge，请设置 CHROME_PATH');
  const profileDir = mkdtempSync(join(tmpdir(), 'wb-cdp-'));
  /*
   * Chrome 的 stdout/stderr 写进文件（不用 pipe）：见上面 ①。
   * 放在 profileDir 之外，因为失败时 profileDir 会被整个删掉。
   */
  const logFile = join(tmpdir(), `wb-cdp-chrome-${process.pid}-${port}.log`);
  let logFd = null;
  try {
    logFd = openSync(logFile, 'w');
  } catch { /* 打不开就退回 ignore：至少不影响启动 */ }

  const child = spawn(exe, [
    '--headless=new',
    `--remote-debugging-port=${port}`,
    `--user-data-dir=${profileDir}`,
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-gpu',
    `--window-size=${width},${height}`,
    'about:blank',
  ], {
    stdio: logFd === null ? 'ignore' : ['ignore', logFd, logFd],
    detached: true,
  });
  child.unref();
  let spawnError = null;
  child.on('error', (error) => { spawnError = String(error?.message || error); });
  if (logFd !== null) { try { closeSync(logFd); } catch { /* 忽略 */ } }

  /** 只收集 **Chrome 自己说的话**；拿不到就返回空串（不再用 error.message 冒充）。 */
  const chromeSays = () => {
    if (spawnError) return spawnError;
    try {
      const text = readFileSync(logFile, 'utf8').trim();
      if (!text) return '';
      return text.split('\n').filter(Boolean).slice(-5).join(' / ');
    } catch {
      return '';
    }
  };

  try {
    /*
     * 冷启动路径用 `waitForPages`（只等、不判定归属）：
     * 这个端口的 Chrome 是我们**刚 spawn 的**，窗口期里 probeCdp 会把它的
     * 未就绪响应误判成 foreign（详见 waitForPages 的注释）。
     *
     * 预算给到 30 秒：CI 的 windows-latest 上冷启动明显更慢（实测同一份代码
     * 本地 ~400ms、CI 要数秒到十几秒），15 秒不足以稳定通过。
     */
    const pages = await waitForPages(port, 30_000);
    // 起来了：Chrome 自己的日志已经没用了，清掉（保留 profileDir —— close() 还要清）
    try { rmSync(logFile, { force: true }); } catch { /* 忽略 */ }
    return { ok: true, wsUrl: pages[0].webSocketDebuggerUrl, chrome: child, profileDir };
  } catch (error) {
    /*
     * 收掉进程与临时 profile 再返回。不收的话它会在后台活着（bind 失败后未必
     * 立刻退出），下一个脚本又 spawn 一个 —— 实测泄漏到 3 个无头实例。
     * 顺序要紧：**先读日志再删**（删了就读不到真因了）。
     */
    const detail = chromeSays();
    try { child.kill(); } catch { /* 已经退出 */ }
    try { rmSync(profileDir, { recursive: true, force: true }); } catch { /* 忽略 */ }
    try { rmSync(logFile, { force: true }); } catch { /* 忽略 */ }
    return { ok: false, detail, error };
  }
}

/**
 * 启动（或复用）无头 Chrome，打开打桩后的页面。
 * 返回 { cdp, chrome, profileDir, close() }。
 *
 * `injectStub: false` 用于**页面内嵌 iframe** 的场景：打桩脚本是装在
 * 每个新文档上的（含 iframe），而未命中路径一律回 `{}` —— 内嵌的真实页面
 * 会因此拿不到自己的数据。此时由调用方自己在页面里做打桩。
 */
export async function openPage(url, routes, { cdpPort = 9333, width = 1440, height = 900, inject = '', injectStub = true, skipShapeCheck = false } = {}) {
  /*
   * 打桩前先校验形状。
   *
   * 桩数据的字段名一旦与真实接口不一致，页面**不会报错**，只会静默地不渲染 ——
   * 而页面看起来一切正常。这个坑一天里踩了三次（用量表整张没渲染、诊断面板
   * 渲染出 undefined、签到面板显示了一个无依据的结论），每次都是
   * 「以为发现了产品 bug，其实是自己的夹具错了」。
   *
   * 所以这里**默认拒绝形状不对的桩**，让问题在渲染前就暴露。
   * 形状来自 tools/dev/api-shape.json（只有键名与类型，不含真实数据）。
   */
  if (injectStub && !skipShapeCheck) {
    const { validateRoutes, loadShape } = await import('./api-shape.mjs');
    const shape = loadShape();
    if (shape) {
      /*
       * 先补**与用例无关的附加字段**，再做形状校验。
       *
       * 背景：`/api/models` 除了 `models` 还有 `modelsDefault`（面板「客户端一键
       * 拉取给」那一行要用）。十来个用例都是自己写 `{ body: { models: CATALOG } }`
       * —— 要求每个用例都记得带上这个跟它毫无关系的字段，只会变成长期负担：
       * 下次接口再加一个诊断字段，又得全仓库改一遍。
       *
       * 所以这里统一补齐：**用例没写该字段**时填夹具默认值；写了的（包括显式
       * 传 `false` 验「旧版桥没有这个字段」）一律尊重原值。补齐之后仍然要过
       * 形状校验 —— 这不是"跳过检查"，只是替用例省掉无关的样板。
       */
      const filled = { ...routes };
      const modelsRoute = filled['/api/models'];
      if (modelsRoute && modelsRoute.body && typeof modelsRoute.body === 'object'
        && modelsRoute.body.modelsDefault === undefined) {
        const { baseRoutes } = await import('./fixtures.mjs');
        const defaults = baseRoutes()['/api/models']?.body?.modelsDefault;
        if (defaults) {
          filled['/api/models'] = { ...modelsRoute, body: { ...modelsRoute.body, modelsDefault: defaults } };
        }
      }
      /*
       * 同上：`/api/usage` 的 `failureByModel` 是「按模型的失败统计」，与
       * `models` 是**两张表**（失败不混进成功排行）。少数用例自己拼了 usage 对象，
       * 这里补一个空数组 —— 空数组是真实语义（这批数据里没有失败），不掩盖问题。
       */
      const usageRoute = filled['/api/usage'];
      if (usageRoute && usageRoute.body && typeof usageRoute.body === 'object'
        && usageRoute.body.usage && typeof usageRoute.body.usage === 'object'
        && usageRoute.body.usage.failureByModel === undefined) {
        filled['/api/usage'] = {
          ...usageRoute,
          body: { ...usageRoute.body, usage: { ...usageRoute.body.usage, failureByModel: [] } },
        };
      }
      const problems = validateRoutes(filled, shape);
      /*
       * 把补齐结果**同步回真正要打给页面的那份**。
       *
       * 只在 `filled` 上补是不够的：校验过了、页面拿到的仍是缺字段的原对象，
       * 于是那一行在页面上不渲染，而**测试是绿的** —— 正是这套夹具要防的坑。
       */
      if (filled['/api/models'] !== routes['/api/models']) routes['/api/models'] = filled['/api/models'];
      if (filled['/api/usage'] !== routes['/api/usage']) routes['/api/usage'] = filled['/api/usage'];
      if (problems.length) {
        const detail = problems.map((p) => {
          const lines = [`  ${p.route}`];
          if (p.missing && p.missing.length) {
            lines.push(`    缺少：${p.missing.slice(0, 6).join(', ')}${p.missing.length > 6 ? ` …共 ${p.missing.length} 项` : ''}`);
          }
          if (p.unknown && p.unknown.length) {
            lines.push(`    真实接口没有这些键（多半是名字写错了）：${p.unknown.slice(0, 6).join(', ')}`);
          }
          return lines.join('\n');
        }).join('\n');
        throw new Error(
          '桩数据与真实接口形状不一致 —— 页面会静默地不渲染，先修夹具再跑：\n' + detail
          + '\n  形状来源：tools/dev/api-shape.json（重取：node tools/dev/api-shape.mjs capture）'
          + '\n  确实需要绕过时传 skipShapeCheck: true',
        );
      }
    }
  }

  let chrome = null;
  let profileDir = null;
  let wsUrl;
  /** 我们要在 close() 里关掉的那张页面（复用实例时才有值）。 */
  let createdTargetId = null;
  /**
   * 在已有实例上**新建一张干净页面**。
   *
   * 为什么要新建而不是复用现成的那张：`npm run test:ui` 串行跑 21 个脚本、
   * 共用 `cdpPort = 9333` 一个浏览器实例。上一个脚本留下的页面还在，
   * 它的 `addScriptToEvaluateOnNewDocument`（桩数据、`window.__X` 标记）、
   * localStorage、对话框处理器**全都还生效**。实测复现：新脚本拿到的状态是
   * `{"second":2,"stale":1}` —— 两轮注入叠加，断言于是在脏状态下跑。
   * 症状就是"随机红"：`test-r6-detail` 第一次点 ⓘ 没反应（`opened=0`）、
   * `test-r7-safety` 读到了上一个脚本的 confirm 文案。
   *
   * 注意**别顺手把旧页面都关掉**：全关掉会让 Chrome 因为"没有窗口"而退出，
   * 下一个脚本于是又冷启动一个新实例，越跑越多（实测泄漏到 14 个实例，
   * 而且后续脚本开始 180s 超时）。留着旧页面，只是多用几 MB 内存。
   */
  const newTarget = async (port) => {
    try {
      const r = await fetch(`http://127.0.0.1:${port}/json/new?about:blank`, { method: 'PUT' });
      if (!r.ok) return null;
      return await r.json();
    } catch {
      return null;
    }
  };

  /*
   * 起/复用实例。**端口冲突要立刻换端口**，不要在这个端口上白等两轮 15 秒。
   *
   * 早先的行为（实测 `.tmp-audit/probe-cdp-occupied.mjs`）：端口被别的 HTTP 服务
   * 占着 → `devtoolsPages()` 轮询 15 秒 → 抛「无法连接 DevTools」→ catch 里**照样**
   * 在这个端口 spawn 一个 Chrome（绑定必失败）→ 再轮询 15 秒 → 抛出。合计 31.5 秒，
   * 而且那个注定失败的 Chrome 进程被留在后台（本机实测残留 3 个无头实例，
   * 每个带着几十个 renderer —— 后续脚本于是越来越容易超时）。
   *
   * 现在：先探一次端口身份；`foreign` 直接换一个系统分配的端口，并且**只在
   * 真的需要冷启动时才 spawn**；spawn 之后如果连不上，把进程收掉再报错。
   */
  let usingPort = cdpPort;
  for (let attempt = 0; ; attempt += 1) {
    const probe = await probeCdp(usingPort);
    if (probe.state === 'devtools') {
      try {
        const fresh = await newTarget(usingPort);
        if (fresh && fresh.webSocketDebuggerUrl) {
          wsUrl = fresh.webSocketDebuggerUrl;
          createdTargetId = fresh.id || null;
        } else {
          /*
           * 拿不到 /json/new（老版本只认 GET、或发行版禁了该接口）时退回复用现有页面。
           * 这条路**可能带着上一轮的注入** —— 所以把话说明白，别让它以"随机红"的形式出现。
           */
          const left = await devtoolsPages(usingPort);
          wsUrl = left[0].webSocketDebuggerUrl;
          process.stderr.write('[ui-harness] 提示：/json/new 不可用，本次复用了已有页面；'
            + '若断言莫名其妙地失败，先怀疑跨脚本残留状态\n');
        }
        break;
      } catch (error) {
        // DevTools 在、但拿不到页面：当成冲突，换端口重来
        if (attempt >= 2) throw error;
        usingPort = await freePort();
        continue;
      }
    }
    if (probe.state === 'foreign') {
      if (attempt >= 2) {
        throw new Error(`连续 3 个端口都被别的程序占着，无法启动 DevTools（最后一个是 ${usingPort}：${probe.detail}）`);
      }
      const next = await freePort();
      process.stderr.write(`[ui-harness] 端口 ${usingPort} 被别的程序占着（${probe.detail}），改用 ${next}\n`);
      usingPort = next;
      continue;
    }
    /*
     * absent：这里才是"该冷启动"的时机。
     *
     * 冷启动也放进这个循环里，而不是循环外单独一段 —— 因为**bind 失败要继续换端口**：
     * 探测到 absent 与 Chrome 真正 bind 之间有一个窗口（TOCTOU），端口可能刚被
     * 别的程序抢走。
     *
     * ⚠️ 重试次数要数清楚：先判定"还能不能再试"，再用本次端口去试。
     * 原先写的是「if (attempt >= 2) throw」在调用**之前**，于是第 3 次
     * （attempt=2）根本没试就抛错 —— 报错里那个端口一次都没被真正使用过
     * （CI 日志里「最后一个是 29456」其实从未启动过 Chrome）。
     */
    const started = await coldStartOn(usingPort, { width, height });
    if (started.ok) {
      wsUrl = started.wsUrl;
      // 记住进程与 profile：`close()` 要按它们清理
      chrome = started.chrome;
      profileDir = started.profileDir;
      break;
    }
    process.stderr.write(`[ui-harness] Chrome 在端口 ${usingPort} 上没起来`
      + `${started.detail ? `：${started.detail}` : '（Chrome 没有输出，通常是启动即崩）'}`
      + `，换端口重试\n`);
    if (attempt >= 2) {
      throw new Error(`连续 ${attempt + 1} 个端口都起不来 Chrome`
        + `（最后一个是 ${usingPort}${started.detail ? `：${started.detail}` : ''}）`, { cause: started.error });
    }
    usingPort = await freePort();
  }
  /** 实际使用的调试端口（自动换过端口时与入参不同）。 */
  const debugPort = usingPort;

  const cdp = connect(wsUrl);
  await cdp.ready;
  await cdp.send('Page.enable');
  await cdp.send('Runtime.enable');
  await cdp.send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: false });

  /**
   * 授予剪贴板权限 —— 必须在页面里**真的去复制**之前。
   *
   * 为什么需要：页面里的「复制」按钮有两条路（`copyText`）：
   *   1. `navigator.clipboard.writeText`（要安全上下文 + 用户手势）；
   *   2. 退化到 `document.execCommand('copy')`。
   * 无头实例里第 1 条常常被拒，而第 2 条一旦也不可用，页面会**如实**显示
   * 「复制失败：xxx，请手动选择复制」—— 那是**正确的产品行为**。
   * 但 i18n 验收会把这句提示当成"漏翻的中文"抓出来（实测：
   * `span#actionMsg.msg | Copy failed: opencode.json，请手动选择复制` 连报十几条），
   * 于是失败原因看起来像翻译问题，其实是**测试环境的剪贴板权限**问题。
   *
   * 这里统一放行，让被测页面走正常路径；测的是"界面文案"而不是"无头浏览器的权限策略"。
   */
  try {
    await cdp.send('Browser.grantPermissions', {
      origin: new URL(url).origin,
      permissions: ['clipboardReadWrite', 'clipboardSanitizedWrite'],
    });
  } catch {
    /* 老版本没有这个命令时忽略：页面还有 execCommand 兜底 */
  }

  /**
   * 清空目标源的 local/sessionStorage —— 必须在**导航之前**。
   *
   * 为什么需要：openPage 会**复用**已在调试端口上的浏览器（为了多个脚本串跑
   * 时不必反复冷启动），而复用的页面带着上一次运行留下的存储。实测：重复跑
   * test-r3-alerts 时，上一轮点过的「知道了」把 `wb.muted.token=1` 留在了
   * localStorage 里，令牌提醒就不再出现 —— 断言全部以脏状态开跑，且看起来
   * 像产品坏了。测试脚本永远假设自己从干净状态开始，这里统一兑现这个前提。
   * （新起的 profile 本来就是干净的，这一步对它是无害的空操作。）
   */
  try {
    await cdp.send('Storage.clearDataForOrigin', {
      origin: new URL(url).origin,
      storageTypes: 'local_storage,session_storage',
    });
  } catch { /* 个别发行版没有该命令时忽略：新 profile 不受影响 */ }

  if (injectStub) await cdp.send('Page.addScriptToEvaluateOnNewDocument', { source: fetchStubSource(routes) });
  if (inject) await cdp.send('Page.addScriptToEvaluateOnNewDocument', { source: inject });

  // confirm() / alert() 会阻塞页面：必须始终接管，否则页面直接卡死。
  // 默认接受；测试可以用 setDialogHandler 改成拒绝，并读取 last 检查文案。
  const dialog = { last: null, handler: null };
  cdp.on('Page.javascriptDialogOpening', (p) => {
    dialog.last = p.message;
    const accept = dialog.handler ? dialog.handler(p.message) : true;
    cdp.send('Page.handleJavaScriptDialog', { accept: !!accept });
  });

  /*
   * 自绘确认框（`.modal-scrim`）的接管。
   *
   * 页面原先用原生 `confirm`，后来换成了自绘弹窗（原生框样式由浏览器决定、
   * 深色主题下是一片亮白，还阻塞主线程）。原生框由上面的
   * `Page.javascriptDialogOpening` 接管；自绘框在 DOM 里，**得自己盯**。
   *
   * 做法：页面侧装一个 MutationObserver，一出现 `.modal-scrim` 就通过 CDP binding
   * 把文案回传给 harness，由 harness 按 `setDialogHandler` 的决定点掉它。
   *
   * 为什么不让测试自己点：**「接受」是默认行为**（与原生框一致）—— 绝大多数用例
   * 只关心"动作做完了没有"，不关心弹窗长什么样。让每个用例各写一遍"如果弹了框就
   * 点确定"，迟早有人漏写，表现为"请求没发出去"这种**看起来像产品坏了**的失败。
   */
  try {
    await cdp.send('Runtime.addBinding', { name: '__askDialog' });
    await cdp.send('Page.addScriptToEvaluateOnNewDocument', {
      source: `(() => {
        if (window.__modalWatcher) return;
        window.__modalWatcher = true;
        const seen = new WeakSet();
        const check = () => {
          for (const s of document.querySelectorAll('.modal-scrim')) {
            if (seen.has(s)) continue;
            seen.add(s);
            const text = [...s.querySelectorAll('.modal-body p')].map((p) => p.textContent).join('\\n');
            try { window.__askDialog(JSON.stringify(text)); } catch { /* binding 未就绪时忽略 */ }
          }
        };
        /*
         * 观察 **document** 而不是 documentElement。
         *
         * 这段脚本在**文档解析之前**执行（addScriptToEvaluateOnNewDocument 的语义），
         * 那时 documentElement 还是 null —— observe(null) 会直接抛错，
         * 而标记已经置位，于是**看着像装好了、实际根本没观察**（实测踩到：
         * 弹窗明明在 DOM 里，lastDialog() 却是 null 且弹窗没人点）。
         */
        new MutationObserver(check).observe(document, { childList: true, subtree: true });
      })();`,
    });
    cdp.on('Runtime.bindingCalled', (p) => {
      if (p.name !== '__askDialog') return;
      let text = '';
      try { text = JSON.parse(p.payload); } catch { text = String(p.payload || ''); }
      dialog.last = text;
      /*
       * `setDialogAuto(false)` 时**只记录、不点掉** —— 给「要检查弹窗本身长什么样」
       * 的用例用（比如断言按钮文案在英文模式下翻了没有）。
       * 默认自动接管，与原生框的默认行为一致。
       */
      if (dialog.auto === false) return;
      const accept = dialog.handler ? dialog.handler(text) : true;
      cdp.send('Runtime.evaluate', {
        expression: `(() => {
          const s = document.querySelector('.modal-scrim');
          if (!s) return false;
          const b = s.querySelectorAll('.modal-actions button');
          const t = ${accept ? 'b[b.length - 1]' : 'b[0]'};
          if (t) t.click();
          return true;
        })()`,
      });
    });
  } catch { /* 个别发行版没有 Runtime.addBinding 时忽略：那时用 lastDialog() 显式回答 */ }

  /*
   * 等**这一次**导航的 load 事件。
   *
   * 注意这里**不能**像早先那样 `Promise.race([loaded, sleep(8000)])`：
   * 那等于"等 8 秒还没好就往下走"，而下面的断言会立刻对着一个**还没加载完**
   * 的页面开跑 —— 症状是"第一次点击完全没反应"（实测 `opened=0`），
   * 却看不出是加载问题。真等不到就**明确报错**，别让失败以随机断言的形式出现。
   *
   * 同时也不能只等一个可能来自**上一次**导航的 load：`cdp.on` 只追加不移除，
   * 所以这里先记下"注册之前的监听数"没有意义 —— 真正保证正确性的是上面
   * 每次都换成**全新的页面**（新页面的第一次 load 必然属于本次导航）。
   */
  const loaded = new Promise((ok) => cdp.on('Page.loadEventFired', ok));
  await cdp.send('Page.navigate', { url });
  const timedOut = await Promise.race([loaded.then(() => false), sleep(15000).then(() => true)]);
  if (timedOut) {
    // 兜底确认：有些页面（如纯静态、已缓存）可能不触发 loadEventFired 而只是 readyState=complete
    const ready = await cdp.evaluate('document.readyState').catch(() => null);
    if (ready !== 'complete') {
      throw new Error(`页面 15 秒内没有加载完成（readyState=${ready}）：${url}`);
    }
  }

  const close = () => {
    try { cdp.close(); } catch { /* 忽略 */ }
    /*
     * 复用实例时，把**我们新建的这张页面**关掉 —— 不清掉会越攒越多
     * （每个脚本一张，21 个脚本就是 21 张常驻页面）。
     * 只关自己建的：旧脚本留下的页面不归我们管，关它们会把浏览器窗口清空、
     * 导致 Chrome 退出、下一个脚本又冷启动（实测泄漏到 14 个实例）。
     */
    if (createdTargetId) {
      try {
        // 必须用**实际**调试端口：端口冲突时这里会自动换过（见上面的 usingPort）
        fetch(`http://127.0.0.1:${debugPort}/json/close/${createdTargetId}`).catch(() => {});
      } catch { /* 忽略 */ }
    }
    if (chrome) { try { chrome.kill(); } catch { /* 忽略 */ } }
    if (profileDir) { try { rmSync(profileDir, { recursive: true, force: true }); } catch { /* 忽略 */ } }
  };
  return {
    cdp,
    close,
    /** 实际使用的 CDP 端口（入参被占时会自动换一个）。 */
    cdpPort: debugPort,
    /**
     * 最近一次确认框的文案。**要 `await`。**
     *
     * 两种确认框都会被接管并自动回答（默认接受，`setDialogHandler` 可改成拒绝）：
     *
     * - **原生 `confirm`** → `Page.javascriptDialogOpening`；
     * - **自绘弹窗**（`.modal-scrim`）→ 页面侧 MutationObserver 经 CDP binding
     *   回传文案，harness 再点掉它。
     *
     * 所以这个函数**只负责读文案**，不需要（也不应该）由用例去点按钮 ——
     * 用例真正关心的是「这个确认框说了什么」，而不是它长什么样、由谁渲染。
     *
     * 时序上它是异步的：文案要等页面把弹窗挂上去、binding 回传之后才有。
     * 在触发动作的点击**之后**调，必要时先 `await sleep(200)`。
     */
    lastDialog: async () => dialog.last,
    /** 设置对话框处理：返回 true 接受，false 取消。 */
    setDialogHandler: (fn) => { dialog.handler = fn; },
    /**
     * 关掉自动接管（`setDialogAuto(false)`）—— 弹窗出现时**只记录、不点掉**。
     *
     * 给「要检查弹窗本身」的用例用（断言标题、按钮文案、焦点、Esc 行为……）。
     * 默认是开着的：绝大多数用例只关心"动作做完了没有"。
     */
    setDialogAuto: (on) => { dialog.auto = on !== false; },
  };
}

/** 等待页面条件成立。 */
export async function waitFor(cdp, expr, timeoutMs = 10000, label = expr) {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    let v;
    try { v = await cdp.evaluate(expr); } catch { v = false; }
    if (v) return v;
    if (Date.now() > deadline) throw new Error(`等待超时（${timeoutMs}ms）：${label}`);
    await sleep(150);
  }
}

export const click = (cdp, sel) => cdp.evaluate(
  `(() => { const el = document.querySelector(${JSON.stringify(sel)}); if (!el) return false; el.click(); return true; })()`,
);

export const q = (cdp, expr) => cdp.evaluate(expr);
