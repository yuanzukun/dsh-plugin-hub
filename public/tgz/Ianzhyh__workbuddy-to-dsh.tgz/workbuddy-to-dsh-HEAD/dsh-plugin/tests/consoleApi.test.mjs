/**
 * 控制台 API 透传（/workbuddy/console-api/*）的自测。
 *
 * 这一层是「两处同步、互不冲突」的关键：账号切换 / 自动签到开关 / 体检结果
 * 必须由控制台写（它的 lib/state.mjs 带进程内缓存），所以插件只做受控透传。
 * 这里把「白名单、方法、面板头、控制台不在跑」四条边界全钉住。
 *
 *   node --test dsh-plugin/tests/
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';

import { createConsoleApiHandler, CONSOLE_API_ALLOWLIST, CONSOLE_API_PREFIX } from '../lib/consoleApi.mjs';

/** 造一对最小的 req/res，驱动器只看这几个成员。 */
async function call(handler, { method = 'GET', path, headers = {}, body } = {}) {
  let status = 0;
  let payload = '';
  const res = {
    headersSent: false,
    writableEnded: false,
    writeHead(code) { status = code; this.headersSent = true; return this; },
    write(chunk) { payload += Buffer.from(chunk).toString('utf8'); return true; },
    end(chunk) { if (chunk) payload += Buffer.from(chunk).toString('utf8'); this.writableEnded = true; },
    on() {},
    off() {},
  };
  const req = {
    method,
    url: path,
    headers,
    async *[Symbol.asyncIterator]() { if (body) yield Buffer.from(body); },
  };
  await handler(req, res);
  let json;
  try { json = JSON.parse(payload); } catch { json = payload; }
  return { status, json };
}

/** 假控制台：原样回显收到的请求（含面板头 —— 控制台的写接口也要求它）。 */
async function startFakeConsole() {
  const server = createServer(async (req, res) => {
    const chunks = [];
    for await (const chunk of req) chunks.push(chunk);
    const body = Buffer.concat(chunks).toString('utf8');
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({
      echoed: true,
      method: req.method,
      url: req.url,
      panel: req.headers['x-workbuddy-panel'] || null,
      body: body ? JSON.parse(body) : null,
    }));
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  return { port: server.address().port, close: () => new Promise((r) => server.close(r)) };
}

test('console-api 透传：白名单 / 方法 / 面板头 / 控制台未运行', async () => {
  const fake = await startFakeConsole();
  const running = createConsoleApiHandler({
    consoleSupervisor: { url: `http://127.0.0.1:${fake.port}`, probe: async () => ({ state: 'running' }) },
    log: () => {},
  });
  const stopped = createConsoleApiHandler({
    consoleSupervisor: { url: `http://127.0.0.1:${fake.port}`, probe: async () => ({ state: 'stopped', error: '连接被拒绝' }) },
    log: () => {},
  });

  try {
    // 1) 允许的 GET：原样透传到控制台的 /api/*（含查询串）
    const overview = await call(running, { path: `${CONSOLE_API_PREFIX}/overview` });
    assert.equal(overview.status, 200);
    assert.equal(overview.json.echoed, true);
    assert.equal(overview.json.url, '/api/overview');

    const withQuery = await call(running, { path: `${CONSOLE_API_PREFIX}/probe-results?x=1` });
    assert.equal(withQuery.json.url, '/api/probe-results?x=1');

    // 2) 非白名单路径：404，且**不会**打到控制台（不做任意路径代理）
    const nope = await call(running, { path: `${CONSOLE_API_PREFIX}/secrets` });
    assert.equal(nope.status, 404);
    assert.match(nope.json.error, /未允许透传/);
    const traversal = await call(running, { path: `${CONSOLE_API_PREFIX}/../api/overview` });
    assert.ok([404, 200].includes(traversal.status));
    if (traversal.status === 200) assert.equal(traversal.json.echoed, true);
    assert.ok(Object.keys(CONSOLE_API_ALLOWLIST).includes('/account/switch'), '账号切换必须在白名单里');

    // 3) 方法不对：405
    const wrongMethod = await call(running, {
      method: 'POST', path: `${CONSOLE_API_PREFIX}/accounts`, headers: { 'x-workbuddy-panel': '1' }, body: '{}',
    });
    assert.equal(wrongMethod.status, 405);

    // 4) 写操作缺面板头：403（跨站简单请求打不进来）
    const denied = await call(running, {
      method: 'POST', path: `${CONSOLE_API_PREFIX}/account/switch`, body: JSON.stringify({ file: 'a.info' }),
    });
    assert.equal(denied.status, 403);

    // 5) 写操作带头：方法与 body 都忠实透传
    const switched = await call(running, {
      method: 'POST',
      path: `${CONSOLE_API_PREFIX}/account/switch`,
      headers: { 'x-workbuddy-panel': '1' },
      body: JSON.stringify({ file: 'a.info' }),
    });
    assert.equal(switched.status, 200);
    assert.equal(switched.json.method, 'POST');
    assert.deepEqual(switched.json.body, { file: 'a.info' });
    // 透传时也要替下游补上面板头：控制台自己的写接口同样拒绝缺头的请求
    // （它就是"浏览器打得到的本地服务"），漏了会 403、整条链路断掉。
    assert.equal(switched.json.panel, '1', '转发到控制台的请求必须带 x-workbuddy-panel');

    // 6) 删体检结论（DELETE）同样能透传
    const cleared = await call(running, { method: 'DELETE', path: `${CONSOLE_API_PREFIX}/probe-results`, headers: { 'x-workbuddy-panel': '1' } });
    assert.equal(cleared.status, 200);
    assert.equal(cleared.json.method, 'DELETE');

    // 7) 控制台没跑：503 + 可执行提示，而不是静默失败
    const down = await call(stopped, { path: `${CONSOLE_API_PREFIX}/diagnose` });
    assert.equal(down.status, 503);
    assert.equal(down.json.state, 'stopped');
    assert.match(down.json.hint, /控制台/);
  } finally { await fake.close(); }
});

test('console-api：控制台闲置退出后，首次取数自动拉起；foreign 不硬拉', async () => {
  const fake = await startFakeConsole();
  let running = false;
  let ensured = 0;
  const handler = createConsoleApiHandler({
    consoleSupervisor: {
      url: `http://127.0.0.1:${fake.port}`,
      probe: async () => (running ? { state: 'running' } : { state: 'stopped', error: '连接被拒绝' }),
      ensure: async () => {
        ensured += 1;
        running = true;
        return { ok: true, started: true };
      },
    },
    log: () => {},
  });

  try {
    // 面板第一次取数 → 顺手 ensure，请求本身照常成功（用户不用先点“启动控制台”）
    const res = await call(handler, { path: `${CONSOLE_API_PREFIX}/overview` });
    assert.equal(ensured, 1, '停机状态下应自动 ensure 一次');
    assert.equal(res.status, 200);
    assert.equal(res.json.echoed, true);

    // 第二次已经在跑 → 不再重复拉起
    const again = await call(handler, { path: `${CONSOLE_API_PREFIX}/overview` });
    assert.equal(again.status, 200);
    assert.equal(ensured, 1, '已在运行就不该再 ensure');
  } finally { await fake.close(); }

  // 端口被别的服务占着（foreign）：拉起来也是别人的 8792，直接 503 让人看清
  let foreignEnsured = 0;
  const foreign = createConsoleApiHandler({
    consoleSupervisor: {
      url: 'http://127.0.0.1:1',
      probe: async () => ({ state: 'foreign', error: '端口 8792 上有 HTTP 服务，但不是 WorkBuddy 控制台' }),
      ensure: async () => { foreignEnsured += 1; return { ok: true }; },
    },
    log: () => {},
  });
  const conflict = await call(foreign, { path: `${CONSOLE_API_PREFIX}/overview` });
  assert.equal(conflict.status, 503);
  assert.equal(foreignEnsured, 0, 'foreign 状态不应尝试拉起');

  // ensure 失败：把失败原因带给面板，而不是一句“没有在运行”
  const failing = createConsoleApiHandler({
    consoleSupervisor: {
      url: 'http://127.0.0.1:1',
      probe: async () => ({ state: 'stopped', error: '连接被拒绝' }),
      ensure: async () => ({ ok: false, state: 'stopped', error: '启动控制台失败：端口被占用' }),
    },
    log: () => {},
  });
  const down = await call(failing, { path: `${CONSOLE_API_PREFIX}/diagnose` });
  assert.equal(down.status, 503);
  assert.match(down.json.error, /端口被占用/);
});

test('console-api：控制台进程消失时给 502 而不是挂住', async () => {
  const dead = createConsoleApiHandler({
    consoleSupervisor: { url: 'http://127.0.0.1:1', probe: async () => ({ state: 'running' }) },
    log: () => {},
  });
  const res = await call(dead, { path: `${CONSOLE_API_PREFIX}/diagnose` });
  assert.ok([502, 503].includes(res.status), `实际 ${res.status}`);
  assert.match(String(res.json.hint || res.json.error), /控制台/);
});

test('console-api：改余额的透传成功后必须触发 onUpstreamMutation（缓存一致性）', async () => {
  const fake = await startFakeConsole();
  let mutations = 0;
  const handler = createConsoleApiHandler({
    consoleSupervisor: { url: `http://127.0.0.1:${fake.port}`, probe: async () => ({ state: 'running' }) },
    log: () => {},
    onUpstreamMutation: () => { mutations += 1; },
  });

  try {
    // 领签到（POST /checkin）成功 → 必须作废插件侧积分缓存
    await call(handler, {
      method: 'POST', path: `${CONSOLE_API_PREFIX}/checkin`,
      headers: { 'x-workbuddy-panel': '1' }, body: '{}',
    });
    assert.equal(mutations, 1, '领取签到成功后必须触发缓存作废');

    // 换号（POST /account/switch）成功 → 同样触发
    await call(handler, {
      method: 'POST', path: `${CONSOLE_API_PREFIX}/account/switch`,
      headers: { 'x-workbuddy-panel': '1' }, body: JSON.stringify({ file: 'b.info' }),
    });
    assert.equal(mutations, 2, '换号成功后必须触发缓存作废');

    // 读操作不触发
    await call(handler, { path: `${CONSOLE_API_PREFIX}/overview` });
    assert.equal(mutations, 2, 'GET overview 不应触发');

    // 写失败（上游 500）也不触发 —— 只有确认成功才作废
    const failing = createConsoleApiHandler({
      consoleSupervisor: {
        url: await (async () => {
          const server = createServer((req, res) => { res.writeHead(500, { 'content-type': 'application/json' }); res.end('{"ok":false}'); });
          await new Promise((r) => server.listen(0, '127.0.0.1', r));
          setImmediate(() => server.close());
          return `http://127.0.0.1:${server.address().port}`;
        })(),
        probe: async () => ({ state: 'running' }),
      },
      log: () => {},
      onUpstreamMutation: () => { mutations += 1; },
    });
    await call(failing, {
      method: 'POST', path: `${CONSOLE_API_PREFIX}/checkin`,
      headers: { 'x-workbuddy-panel': '1' }, body: '{}',
    });
    assert.equal(mutations, 2, '上游失败时不应作废缓存（余额没变）');
  } finally { await fake.close(); }
});
