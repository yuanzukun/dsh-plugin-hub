/**
 * 旧路由文本手术的自测 + 插件装配冒烟测试（都不碰真实文件、不启桥）。
 *
 *   node --test dsh-plugin/tests/
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import { locateProviderBlock, stripProviderBlock, cleanFile, detectInFile } from '../lib/legacy.mjs';
import {
  resolveConfig, detectProjectRoot, apply, readProjectEnv, DEFAULTS,
  collectBridgeExtraEnv, collectBridgeSecretEnv, BRIDGE_ENV_PASSTHROUGH, BRIDGE_SECRET_ENV,
  pickAccountFailoverTarget,
} from '../lib/index.js';
import { BridgeSupervisor, bridgeBuildHash } from '../lib/bridge.mjs';

/** 真实插件目录（测试里要用它当"源"来造分发布的副本）。 */
const PLUGIN_ROOT = fileURLToPath(new URL('..', import.meta.url));

/*
 * 运行期状态隔离：新版默认从 ~/.workbuddy-bridge/state.json 读账号钉住
 * （升级不丢数据的代价）。测试不能读使用者真实的那份，否则 .env 断言会
 * 被真实账号覆盖；显式指到临时文件。
 */
if (!process.env.WORKBUDDY_STATE_FILE) {
  process.env.WORKBUDDY_STATE_FILE = join(tmpdir(), `wb-plugin-test-state-${process.pid}.json`);
}
process.env.WORKBUDDY_DATA_DIR ||= mkdtempSync(join(tmpdir(), 'wb-plugin-test-data-'));

test('数据面的方法 / 权限矩阵：只读路由拒绝写方法，写路由要求面板头', async () => {
  const { createRouteTable } = await import('../lib/routes.mjs');
  const routes = createRouteTable({
    snapshot: async () => ({ bridge: { state: 'running' } }),
    supervisor: { readLog: () => ({ lines: [] }), probe: async () => ({ state: 'running' }), ensure: async () => ({ ok: true }), stop: async () => ({ ok: true }) },
    consoleSupervisor: { probe: async () => ({ state: 'running' }), ensure: async () => ({ ok: true }), stop: async () => ({ ok: true }), url: 'http://127.0.0.1:8792', spawnedPid: null },
    client: {
      checkin: async () => ({ status: {} }), clearUsage: async () => ({ ok: true }), usage: async () => ({}),
      requests: async () => ({}), quota: async () => ({}),
      authSource: async () => ({ ok: true, configured: 'auto', credentials: [] }),
      authCredentials: async () => ({ ok: true, configuredSource: 'auto', credentials: [] }),
      deviceLoginStart: async () => ({ ok: true, state: 's', url: 'https://example.invalid/login' }),
      deviceLoginPoll: async () => ({ ok: true, status: 'pending' }),
      deviceLoginCancel: async () => ({ ok: true }),
      authSetActive: async () => ({ ok: true }),
      authLogout: async () => ({ ok: true }),
      setAuthSource: async () => ({ ok: true }),
    },
    adapter: { catalogCache: { at: Date.now(), models: [] }, catalogError: '', catalog: async () => [], invalidate() {} },
    paths: { settingsPath: 'x', patchPath: 'y' },
    provider: 'workbuddy',
    log: () => {},
    enableWebSearch: async () => ({
      baseURL: 'http://127.0.0.1:8790/v1',
      provider: 'deepseek-official',
      apiKeyRef: 'WORKBUDDY_SEARCH_BRIDGE_KEY',
    }),
    verifyWebSearch: async () => ({ verified: true, sourceCount: 2 }),
    revertWebSearch: async () => ({ reverted: true, summary: { baseURL: 'https://api.deepseek.com/v1' } }),
  });
  const byPath = (p) => routes.find((r) => r.path === p);

  /** 跑一次路由，返回 {status, body}。url 允许带查询串（真实 req.url 就带）。 */
  const run = async (url, method, headers = {}) => {
    const route = byPath(url.split('?')[0]);
    assert.ok(route, `没有找到路由 ${url}`);
    let status = 0;
    let raw = '';
    const res = {
      writeHead(code) { status = code; },
      write(chunk) { raw += String(chunk); },
      end(body) { if (body) raw += String(body); },
      on() {}, off() {},
    };
    await route.handler({ url, method, headers }, res);
    let body = null;
    try { body = JSON.parse(raw); } catch { body = raw; }
    return { status, body };
  };

  // 只读路由：GET 正常，PUT/PATCH/DELETE 一律 405
  for (const path of ['/workbuddy/status', '/workbuddy/models', '/workbuddy/requests', '/workbuddy/migrate', '/workbuddy/console', '/workbuddy/quota', '/workbuddy/login']) {
    const get = await run(path, 'GET');
    assert.equal(get.status, 200, `${path} GET 应当 200`);
    for (const method of ['PUT', 'PATCH', 'DELETE']) {
      const res = await run(path, method);
      assert.equal(res.status, 405, `${path} ${method} 应当是 405（只读路由不接受写方法）`);
    }
  }
  // 积分接口必须带上桥状态：否则桥掉登录态、quota 还是旧缓存时，客户端分辨不出来
  {
    const quota = await run('/workbuddy/quota', 'GET');
    assert.equal(quota.body.bridgeState, 'running');
    assert.equal(quota.body.quotaAccount, null);
    assert.equal(quota.body.bridgeAccount, null);
  }

  // 写路由：没有面板头一律 403；带上正确头才放行
  const writes = [
    ['/workbuddy/bridge', 'POST'],
    ['/workbuddy/console', 'POST'],
    ['/workbuddy/migrate', 'POST'],
    ['/workbuddy/quota', 'POST'],
    ['/workbuddy/usage', 'DELETE'],
    ['/workbuddy/log', 'DELETE'],
    ['/workbuddy/login/start', 'POST'],
    ['/workbuddy/login/poll', 'POST'],
    ['/workbuddy/login/cancel', 'POST'],
    ['/workbuddy/login/active', 'POST'],
    ['/workbuddy/login/logout', 'POST'],
    ['/workbuddy/login/source', 'POST'],
    ['/workbuddy/web-search/enable', 'POST'],
    ['/workbuddy/web-search/verify', 'POST'],
    ['/workbuddy/web-search/revert', 'POST'],
  ];
  for (const [path, method] of writes) {
    const blocked = await run(path, method);
    assert.equal(blocked.status, 403, `${method} ${path} 缺面板头应当 403`);
    assert.match(String(blocked.body?.error || ''), /x-workbuddy-panel/);
  }
  // 头不对（值不是 1）同样拒绝
  const wrongHeader = await run('/workbuddy/bridge', 'POST', { 'x-workbuddy-panel': 'true' });
  assert.equal(wrongHeader.status, 403);

  // 签到：GET 读、POST 领取要走面板头、其它方法 405
  assert.equal((await run('/workbuddy/checkin', 'GET')).status, 200);
  assert.equal((await run('/workbuddy/checkin', 'DELETE')).status, 405);
  const claimWithoutHeader = await run('/workbuddy/checkin?claim=1', 'POST');
  assert.equal(claimWithoutHeader.status, 403, '领取是写操作，缺面板头必须拒绝');
  const claimWithHeader = await run('/workbuddy/checkin?claim=1', 'POST', { 'x-workbuddy-panel': '1' });
  assert.equal(claimWithHeader.status, 200);

  const webSearch = await run('/workbuddy/web-search/enable', 'POST', { 'x-workbuddy-panel': '1' });
  assert.equal(webSearch.status, 200);
  assert.equal(webSearch.body.baseURL, 'http://127.0.0.1:8790/v1');
  assert.equal(webSearch.body.apiKeyRef, 'WORKBUDDY_SEARCH_BRIDGE_KEY');

  const verify = await run('/workbuddy/web-search/verify', 'POST', { 'x-workbuddy-panel': '1' });
  assert.equal(verify.status, 200);
  assert.equal(verify.body.verified, true);
  assert.equal(verify.body.sourceCount, 2);

  const revert = await run('/workbuddy/web-search/revert', 'POST', { 'x-workbuddy-panel': '1' });
  assert.equal(revert.status, 200);
  assert.equal(revert.body.reverted, true);
  assert.equal(revert.body.summary.baseURL, 'https://api.deepseek.com/v1');
});

test('BridgeSupervisor：调用方 abort 不能被误报成桥已停止', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'wb-sup-abort-'));
  try {
    const sup = new BridgeSupervisor({
      projectRoot: dir,
      scriptPath: join(dir, 'nope.mjs'),
      logPath: join(dir, 'nope.log'),
      host: '127.0.0.1',
      port: 1,
      token: 't',
    });
    sup.client.health = async () => {
      const err = new Error('This operation was aborted');
      err.name = 'AbortError';
      throw err;
    };
    const ac = new AbortController();
    ac.abort();
    const probe = await sup.probe(ac.signal);
    assert.equal(probe.state, 'aborted', '取消不能映射成 stopped');
    const ensured = await sup.ensure({ signal: ac.signal });
    assert.equal(ensured.ok, false);
    assert.equal(ensured.state, 'aborted', 'ensure 不能在取消后继续拉起/复用桥');
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('readLog 只读日志尾部：大文件不吃满内存、截断的半行被丢掉', () => {
  const dir = mkdtempSync(join(tmpdir(), 'wb-log-'));
  try {
    const logPath = join(dir, 'bridge.log');
    // 造一个 > maxBytes 的日志：每行定长，方便断言首尾
    const line = (i) => `line-${String(i).padStart(6, '0')}-${'x'.repeat(40)}`;
    const total = 4000;
    writeFileSync(logPath, Array.from({ length: total }, (_, i) => line(i)).join('\n') + '\n');

    const supervisor = new BridgeSupervisor({ logPath, scriptPath: join(dir, 'nope.mjs'), projectRoot: dir });
    const tail = supervisor.readLog({ lines: 5, maxBytes: 2048 });
    assert.equal(tail.lines.length, 5, '行数应当被 lines 截断');
    assert.equal(tail.lines[4], line(total - 1), '最后一行必须是文件真正的最后一行');
    assert.deepEqual(tail.lines, [line(total - 5), line(total - 4), line(total - 3), line(total - 2), line(total - 1)]);
    assert.ok(!tail.lines.some((l) => l.includes('line-0000')), '不许把整个文件都读回来');
    assert.equal(tail.size, Buffer.byteLength(Array.from({ length: total }, (_, i) => line(i)).join('\n') + '\n'));

    // 单行超过 maxBytes：不该返回半行（宁可为空，也不给半个 JSON）
    const oneLong = join(dir, 'one.log');
    writeFileSync(oneLong, 'A'.repeat(5000) + '\n' + '短行\n');
    const tail2 = new BridgeSupervisor({ logPath: oneLong, scriptPath: 'x', projectRoot: dir }).readLog({ lines: 10, maxBytes: 1024 });
    assert.deepEqual(tail2.lines, ['短行'], '被截断的长行应当被丢弃，只留完整行');

    // 文件不存在：给空结果而不是抛
    const missing = new BridgeSupervisor({ logPath: join(dir, 'missing.log'), scriptPath: 'x', projectRoot: dir }).readLog({});
    assert.deepEqual(missing.lines, []);
    assert.equal(missing.size, 0);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

const SETTINGS = `# DeepSeek Harness 用户设置文档
llm-pi-ai:
  providers:
    workbuddy:
      displayName: WorkBuddy
      apiKeyEnv: WORKBUDDY_BRIDGE_KEY
      baseURL: http://127.0.0.1:8790/v1
      models:
        - id: hy3
          name: "Hy3"
    other-provider:
      displayName: Other
      baseURL: https://example.invalid/v1
`;

const PATCH = `- id: ui-theme
  name: "@deepseek-ai/dsh-client-ui-theme"
  config:
    preference: system
- id: llm-pi-ai
  name: "@deepseek-ai/dsh-llm-pi-ai"
  config:
    providers:
      workbuddy:
        displayName: WorkBuddy
        baseURL: http://127.0.0.1:8790/v1
      keep-me:
        displayName: Keep
- id: workbuddy
  name: dsh-plugin-workbuddy
`;

test('locateProviderBlock 只框住 providers.workbuddy 这一段', () => {
  const hit = locateProviderBlock(SETTINGS, 'workbuddy');
  assert.ok(hit);
  const lines = SETTINGS.split('\n');
  assert.match(lines[hit.start], /^\s{4}workbuddy:$/);
  assert.match(lines[hit.end], /^\s{4}other-provider:$/);
});

test('stripProviderBlock 删除 workbuddy，保留其它 provider 与注释', () => {
  const { changed, text } = stripProviderBlock(SETTINGS, 'workbuddy');
  assert.equal(changed, true);
  assert.doesNotMatch(text, /workbuddy:/);
  assert.match(text, /# DeepSeek Harness 用户设置文档/);
  assert.match(text, /other-provider:/);
  assert.match(text, /displayName: Other/);
  // 另一条 route 不受影响
  assert.match(text, /llm-pi-ai:/);
});

test('locateProviderBlock 支持 4 空格缩进的 YAML（不能写死 +2）', () => {
  const wide = `llm-pi-ai:\n    providers:\n        workbuddy:\n            displayName: WorkBuddy\n        other:\n            displayName: Other\n`;
  const hit = locateProviderBlock(wide, 'workbuddy');
  assert.ok(hit, '4 空格一级的 YAML 也必须能定位旧路由');
  assert.match(wide.split('\n')[hit.start], /^\s{8}workbuddy:$/);
  const { changed, text } = stripProviderBlock(wide, 'workbuddy');
  assert.equal(changed, true);
  assert.doesNotMatch(text, /workbuddy:/);
  assert.match(text, /other:/);
});

test('stripProviderBlock 处理 patch 层（列表条目缩进）', () => {
  const { changed, text } = stripProviderBlock(PATCH, 'workbuddy');
  assert.equal(changed, true);
  assert.doesNotMatch(text, /^\s+workbuddy:$/m);
  assert.match(text, /keep-me:/);
  assert.match(text, /- id: ui-theme/);
  assert.match(text, /- id: workbuddy\n  name: dsh-plugin-workbuddy/);
});

test('providers 被清空时改写成 providers: {}（避免 YAML null）', () => {
  const only = `llm-pi-ai:\n  providers:\n    workbuddy:\n      displayName: WorkBuddy\n`;
  const { text } = stripProviderBlock(only, 'workbuddy');
  assert.match(text, /providers: \{\}/);
  assert.doesNotMatch(text, /workbuddy/);
});

test('没有旧路由时不动文件，也不报"已改"', () => {
  const clean = `llm-pi-ai:\n  providers:\n    keep:\n      displayName: Keep\n`;
  const { changed, text } = stripProviderBlock(clean, 'workbuddy');
  assert.equal(changed, false);
  assert.equal(text, clean);
});

test('cleanFile 先备份再写，备份内容与原文一致', () => {
  const dir = mkdtempSync(join(tmpdir(), 'wb-legacy-'));
  try {
    const file = join(dir, 'settings.yaml');
    writeFileSync(file, SETTINGS, 'utf8');
    const result = cleanFile(file, { provider: 'workbuddy' });
    assert.equal(result.changed, true);
    assert.ok(existsSync(result.backup));
    assert.equal(readFileSync(result.backup, 'utf8'), SETTINGS);
    assert.doesNotMatch(readFileSync(file, 'utf8'), /workbuddy:/);
    // 再跑一次：已经干净，不应重复改动
    const again = cleanFile(file, { provider: 'workbuddy' });
    assert.equal(again.changed, false);
    assert.equal(again.reason, 'no-legacy-route');
    assert.equal(detectInFile(file, 'workbuddy').found, false);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('resolveConfig 合默认值并做类型收敛', () => {
  const cfg = resolveConfig({ bridgePort: '9999', autoStart: '0', modelAllow: 'a, b', migrateLegacy: false });
  assert.equal(cfg.bridgePort, 9999);
  assert.equal(cfg.autoStart, false);
  assert.deepEqual(cfg.modelAllow, ['a', 'b']);
  assert.equal(cfg.migrateLegacy, false);
  assert.equal(cfg.provider, DEFAULTS.provider);
  assert.equal(cfg.displayName, 'WorkBuddy');
  assert.equal(cfg.autoWebSearch, true, '网页搜索默认自动接入（issue #7）');
  assert.equal(resolveConfig({ autoWebSearch: false }).autoWebSearch, false);
  assert.equal(resolveConfig({ autoWebSearch: 'off' }).autoWebSearch, false);
});

test('detectProjectRoot 能从插件目录上溯找到项目根', () => {
  const root = detectProjectRoot('');
  assert.ok(root, '应该找到 workbuddy-to-dsh 检出目录');
  assert.ok(existsSync(join(root, 'bridge', 'workbuddy-bridge.mjs')));
});

/** 一个足够像 cordis 的假 ctx：记录注册了什么，验证装配而不需要真实 dsh。 */
function fakeCtx() {
  const calls = { adapters: [], tools: [], commands: [], routes: [], effects: [], provides: [] };
  const ctx = {
    logger: { info: () => {}, warn: () => {}, error: () => {} },
    llm: {
      registerAdapter(providers, adapter) {
        calls.adapters.push({ providers, adapter });
        const handle = () => {};
        handle.replace = () => {};
        return handle;
      },
    },
    get(name) {
      if (name === 'tools') return { register: (d) => { calls.tools.push(d); return () => {}; } };
      if (name === 'commands') return { register: (d) => { calls.commands.push(d); return () => {}; } };
      if (name === 'webServer') return { register: (r) => { calls.routes.push(r); return () => {}; } };
      return undefined;
    },
    effect(fn, label) { calls.effects.push(label); const dispose = fn(); return dispose; },
    provide(name, value) { calls.provides.push({ name, value }); return () => {}; },
  };
  return { ctx, calls };
}

test('换账号后积分/签到缓存必须作废（回归：面板把 A 账号积分挂在 B 账号头上）', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'wb-account-'));
  try {
    const { ctx } = fakeCtx();
    const result = apply(ctx, { projectRoot: dir, autoStart: false, consoleAutoStart: false, migrateLegacy: false });
    const { state, snapshot } = result;

    // 桩：probe 返回的 userId 由外部变量控制 —— **模拟真实换号**：
    // 桥重启后 health 报新 userId，插件靠自己对比发现"账号变了"。
    // （不许手动改 state.bridgeAccount —— 那等于替插件作弊，把变化掩盖了。）
    let currentAccount = 'A';
    result.supervisor.probe = async () => ({
      state: 'running',
      health: { auth: { userId: currentAccount, expiresAt: new Date(Date.now() + 864e5).toISOString() } },
    });

    // 桩：quota/checkin 也打桩 —— **不能依赖真实桥**（CI 上没有桥在跑，
    // 之前本地能过只是因为 8790 上恰好有一个）。返回值随账号变化，
    // 顺带验证"换号后必须重新调上游，不能吃旧缓存"。
    let quotaCalls = 0;
    let checkinCalls = 0;
    result.client.quota = async () => { quotaCalls += 1; return { ok: true, total: currentAccount === 'A' ? 111 : 222, packages: [] }; };
    result.client.checkin = async () => { checkinCalls += 1; return { ok: true, status: { todayCheckedIn: false, streakDays: 1 }, auto: { auto: false } }; };

    // ── 第一幕：账号 A，正常取一次积分与签到
    // 预置一份模型目录：第三幕要断言"换号后目录被作废"
    result.adapter.catalogCache = { at: Date.now(), models: [{ id: 'm-from-A' }] };
    const snapA = await snapshot({});
    assert.ok(snapA.quota, '账号 A 应当有积分缓存');
    assert.equal(state.quotaCache.account, 'A', '积分缓存必须打上账号 A 的标记');
    // 签到刷新是后台异步的：等它落盘再断言
    await state.checkinInflight;
    assert.equal(state.checkinCache.account, 'A', '签到缓存必须打上账号 A 的标记');
    const quotaA = snapA.quota;

    // ── 第二幕：切到账号 B（只改桥报告的身份，让插件自己发现变化）
    currentAccount = 'B';
    // TTL 内再取快照：换号后**不许**继续用 A 的缓存值
    const snapB = await snapshot({});
    await state.checkinInflight;
    assert.equal(snapB.quota?.total, 222, `换账号后积分必须换新（B=222），实际 ${snapB.quota?.total}`);
    assert.equal(state.quotaCache.account, 'B', '新缓存必须标记为账号 B');
    assert.equal(state.checkinCache.account, 'B', '签到缓存也必须换到账号 B 名下');

    // ── 第三幕：模型目录同样属于账号视角 —— reconcile 必须把目录作废
    // （adapter.invalidate 会把 catalogCache 清空，下一次目录读取自然从桥重取）
    assert.equal(result.adapter.catalogCache.models.length, 0, '换号后模型目录必须已作废（等下一次从桥重取）');

    // ── 第四幕：bridgeAccount 为 null（旧桥/探测不完整）时**不许**误清有效缓存
    result.supervisor.probe = async () => ({ state: 'running', health: { auth: {} } });
    const beforeNull = { quota: state.quotaCache.value, checkin: state.checkinCache.value };
    await snapshot({});
    assert.equal(state.quotaCache.value, beforeNull.quota, '拿不到账号身份时不能清掉积分缓存');
    assert.equal(state.checkinCache.value, beforeNull.checkin, '拿不到账号身份时不能清掉签到缓存');
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('web-search 就绪度必须核对真实令牌（回归：localToken 被同名变量遮蔽）', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'wb-search-status-'));
  try {
    const { ctx } = fakeCtx();
    const baseGet = ctx.get.bind(ctx);
    let expectedBaseURL = '';
    const settings = {
      describe: () => [
        {
          ns: 'web-search-deepseek',
          value: { baseURL: expectedBaseURL, apiKeyEnv: 'WORKBUDDY_SEARCH_BRIDGE_KEY' },
          user: { baseURL: expectedBaseURL, apiKeyEnv: 'WORKBUDDY_SEARCH_BRIDGE_KEY' },
        },
        {
          ns: 'web',
          value: { searchProvider: 'deepseek-official' },
          user: { searchProvider: 'deepseek-official' },
        },
      ],
      update: async () => {},
      replace: async () => {},
    };
    const credentials = {
      describe: async () => ({ configured: true }),
      // 配置里存的还是旧令牌：真实搜索会 401，就绪度必须说"不 ready"
      resolve: async () => ({ value: 'stale-token' }),
      set: async () => {},
      unset: async () => {},
    };
    ctx.get = (name) => {
      if (name === 'settings') return settings;
      if (name === 'credentials') return credentials;
      return baseGet(name);
    };
    const result = apply(ctx, {
      projectRoot: dir,
      autoStart: false,
      consoleAutoStart: false,
      migrateLegacy: false,
      localToken: 'real-token',
    });
    expectedBaseURL = `${result.supervisor.baseUrl}/v1`;
    result.supervisor.probe = async () => ({ state: 'running', health: { auth: { userId: 'u1' } } });
    result.consoleSupervisor.probe = async () => ({ state: 'stopped' });
    result.client.quota = async () => ({ ok: true, total: 0, packages: [] });
    result.client.checkin = async () => ({ ok: true, status: {} });
    result.client.requests = async () => ({ requests: [] });

    const snap = await result.snapshot({});
    assert.equal(snap.webSearch.configured, true, '配置本身正确');
    assert.equal(snap.webSearch.tokenMatches, false, '必须拿配置里的令牌与当前桥令牌比对');
    assert.equal(snap.webSearch.ready, false, '令牌过期时不能显示 ready');
    assert.equal(snap.webSearch.reason, 'token');
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('apply() 装配：注册 llm 路由、10 个工具、命令、HTTP 路由', () => {
  const dir = mkdtempSync(join(tmpdir(), 'wb-apply-'));
  try {
    const { ctx, calls } = fakeCtx();
    // 用一个空目录当 projectRoot（桥/控制台脚本都不存在）：不自动启任何进程，只验证装配
    const result = apply(ctx, { projectRoot: dir, autoStart: false, consoleAutoStart: false, migrateLegacy: false });
    assert.equal(calls.adapters.length, 1);
    assert.deepEqual(calls.adapters[0].providers, ['workbuddy']);
    assert.equal(calls.adapters[0].adapter.providerInfo('workbuddy').name, 'WorkBuddy');
    assert.equal(calls.tools.length, 10);
    assert.deepEqual(calls.tools.map((t) => t.name).sort(), [
      'workbuddy_bridge', 'workbuddy_checkin', 'workbuddy_generate_image', 'workbuddy_generate_video',
      'workbuddy_image_status', 'workbuddy_models', 'workbuddy_status', 'workbuddy_usage',
      'workbuddy_video_status', 'workbuddy_web_search',
    ]);
    for (const tool of calls.tools) {
      assert.equal(typeof tool.execute, 'function');
      assert.equal(typeof tool.output.render, 'function');
      assert.ok(tool.parameters && tool.parameters.type === 'object');
    }
    assert.equal(calls.commands.length, 1);
    assert.equal(calls.commands[0].name, 'workbuddy');
    assert.equal(calls.routes.length, 25, 'HTTP 数据面应有 25 条路由（24 条 exact + 1 条 console-api 前缀）');
    assert.deepEqual(calls.routes.map((r) => r.path).sort(), [
      '/workbuddy/bridge', '/workbuddy/checkin', '/workbuddy/checkin/accounts', '/workbuddy/checkin/all',
      '/workbuddy/console', '/workbuddy/console-api', '/workbuddy/identity', '/workbuddy/log',
      '/workbuddy/login', '/workbuddy/login/active', '/workbuddy/login/cancel', '/workbuddy/login/logout',
      '/workbuddy/login/poll', '/workbuddy/login/source', '/workbuddy/login/start',
      '/workbuddy/migrate', '/workbuddy/model-visibility', '/workbuddy/models', '/workbuddy/quota', '/workbuddy/requests', '/workbuddy/status', '/workbuddy/usage',
      '/workbuddy/web-search/enable', '/workbuddy/web-search/revert', '/workbuddy/web-search/verify',
    ]);
    const prefix = calls.routes.find((r) => r.path === '/workbuddy/console-api');
    assert.equal(prefix.kind, 'prefix', 'console-api 必须挂成前缀路由');
    assert.equal(typeof prefix.handler, 'function');
    assert.equal(result.state.route.registered, true);
    assert.ok(result.consoleSupervisor, 'apply() 必须返回控制台管理器');
    assert.equal(result.consoleSupervisor.url, 'http://127.0.0.1:8792');
    assert.equal(result.consoleSupervisor.idleExitMs, 600_000, '闲置退出默认值应传给控制台管理器');
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('apply() 遇到 DUPLICATE_ADAPTER 时退回兜底 provider', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'wb-fallback-'));
  try {
    const calls = { providers: [] };
    const ctx = {
      logger: { info: () => {}, warn: () => {}, error: () => {} },
      llm: {
        registerAdapter(providers) {
          calls.providers.push(providers[0]);
          if (providers[0] === 'workbuddy') {
            const error = new Error('an adapter for provider "workbuddy" is already registered');
            error.code = 'DUPLICATE_ADAPTER';
            throw error;
          }
          const handle = () => {};
          handle.replace = () => {};
          return handle;
        },
      },
      get() { return undefined; },
      effect(fn) { return fn(); },
    };
    const result = apply(ctx, { projectRoot: dir, autoStart: false, migrateLegacy: false, tools: false, commands: false, routes: false });
    await new Promise((r) => setTimeout(r, 3200));
    assert.ok(calls.providers.includes('workbuddy-native'), '应该用兜底 provider 再注册一次');
    assert.equal(result.state.route.registered, true);
    assert.equal(result.state.route.fallback, true);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('模型目录归一化：徽章从 tags 里拆出来（带颜色），厂商单字母保留为"标识"', async () => {
  const { toDirectory } = await import('../lib/models.mjs');
  const dir = toDirectory([
    {
      id: 'hy3', name: 'Hy3', context_window: 192000, max_output_tokens: 64000, supports_images: true,
      credits: 0, free: true, vendor: 'j', badge: '限时免费',
      tags: ['craft', 'badge:限时免费:#FF0000'], description_zh: '混元思考模型',
    },
    { id: 'glm-5.3', name: 'GLM-5.3', vendor: 'e', tags: ['craft'] },
  ]);
  const hy3 = dir.find((m) => m.id === 'hy3');
  assert.deepEqual(hy3.tags, ['craft'], 'tags 里不该再留着 badge: 规格（那是噪音）');
  assert.deepEqual(hy3.badges, [{ label: '限时免费', color: '#FF0000' }], '徽章要结构化并保住颜色');
  assert.equal(hy3.badge, '限时免费');
  assert.equal(hy3.vendor, 'j', '上游厂商代码原样保留（界面标注为"标识"）');
  assert.deepEqual(dir.find((m) => m.id === 'glm-5.3').badges, [], '没有徽章的模型给空数组而不是 undefined');
  assert.ok(!JSON.stringify(dir).includes('badge:'), '整个目录里都不该再出现 badge: 原始规格');
});

test('模型目录归一化：推理能力与档位必须映射出来（面板"看得见"的前提）', async () => {
  const { toDirectory } = await import('../lib/models.mjs');
  const dir = toDirectory([
    // 实测六档的全档模型
    {
      id: 'deepseek-v4.1-flash', name: 'DeepSeek-V4.1-Flash', supports_images: true,
      supports_reasoning: true, only_reasoning: true,
      reasoning_efforts: ['minimal', 'low', 'medium', 'high', 'xhigh', 'max'],
    },
    // 老桥：说支持推理但没有档位字段 → efforts 必须是 null（"未知"，不是"没有"）
    { id: 'legacy', name: 'Legacy', supports_reasoning: true },
    // 桥实测"一个档都不收" → efforts 必须是空数组（与 null 语义不同）
    { id: 'dead', name: 'Dead', supports_reasoning: true, reasoning_efforts: [] },
    // 档位表里有空白项 → 应被剔除（dsh 校验 id 非空）
    { id: 'dirty', name: 'Dirty', supports_reasoning: true, reasoning_efforts: ['low', '', '  ', 'high', 'low'] },
    // 不支持推理 → reasoning 必须是 false（不是 undefined）
    { id: 'plain', name: 'Plain', supports_images: true },
  ]);

  const flash = dir.find((m) => m.id === 'deepseek-v4.1-flash');
  assert.equal(flash.reasoning, true, '支持推理要说出来');
  assert.deepEqual(flash.efforts, ['minimal', 'low', 'medium', 'high', 'xhigh', 'max'], '六档照单映射');
  assert.equal(flash.onlyReasoning, true, '纯思考模型要标记（面板据此提示）');

  const legacy = dir.find((m) => m.id === 'legacy');
  assert.equal(legacy.reasoning, true);
  assert.equal(legacy.efforts, null, '没有档位字段 = null（未知），与空数组语义不同');

  const dead = dir.find((m) => m.id === 'dead');
  assert.deepEqual(dead.efforts, [], '空数组照实保留（面板据此提示"暂无可选档位"）');
  assert.notEqual(dead.efforts, null, '空数组不能被吞成 null');

  const dirty = dir.find((m) => m.id === 'dirty');
  assert.deepEqual(dirty.efforts, ['low', 'high'], '空串剔除、重复去重、保序');

  const plain = dir.find((m) => m.id === 'plain');
  assert.equal(plain.reasoning, false, '不支持推理给 false（不是 undefined）');
  assert.equal(plain.onlyReasoning, false);

  // 判据必须与 toAdapterModel 一致 —— 两处不一致会让"面板说的"与"dsh 能选的"对不上
  const { toAdapterModel } = await import('../lib/models.mjs');
  for (const raw of [
    { id: 'a', supports_reasoning: true, reasoning_efforts: ['low', 'high'] },
    { id: 'b', supports_reasoning: true },
    { id: 'c', supports_reasoning: true, reasoning_efforts: [] },
    { id: 'd', supports_reasoning: true, reasoning_efforts: ['low', '', 'low', 'xhigh'] },
  ]) {
    const dirOne = toDirectory([raw])[0];
    const adapted = toAdapterModel(raw);
    assert.equal(dirOne.reasoning, adapted.reasoning === true,
      `${raw.id}：目录的 reasoning 与适配器声明必须一致`);
    if (Array.isArray(dirOne.efforts)) {
      assert.deepEqual(dirOne.efforts, adapted.reasoningEfforts,
        `${raw.id}：目录的 efforts 与适配器给 dsh 的档位必须一致`);
    }
  }

  assert.ok(!JSON.stringify(dir).includes('badge:'), '整个目录里都不该再出现 badge: 原始规格');
});

test('桥的健康检查：503 要认领成「凭据异常」，不能误判成"端口上是别人的服务"', async () => {
  const { createServer } = await import('node:http');
  const { BridgeSupervisor } = await import('../lib/bridge.mjs');

  /** 起一个假服务：默认回我们桥那种 503（登录读不出来），可切换成"别人的服务"。 */
  const startFake = async (body, status = 503, contentType = 'application/json') => {
    const server = createServer((req, res) => {
      res.writeHead(status, { 'content-type': contentType });
      res.end(typeof body === 'string' ? body : JSON.stringify(body));
    });
    await new Promise((r) => server.listen(0, '127.0.0.1', r));
    return { port: server.address().port, close: () => new Promise((r) => server.close(r)) };
  };

  // ① 我们的桥 + 登录坏了：503 + {ok:false, error, authFile}
  const ours = await startFake({
    ok: false,
    error: 'login file has no accessToken; sign in to the WorkBuddy desktop app first',
    authFile: 'C:\\auth\\workbuddy-desktop.info',
  });
  try {
    const sup = new BridgeSupervisor({ host: '127.0.0.1', port: ours.port, token: 't', projectRoot: '.', logPath: 'x' });
    const probe = await sup.probe();
    assert.equal(probe.state, 'degraded', '带 authFile 的 503 必须认领成本项目的桥（凭据异常）');
    assert.match(probe.error, /login file|sign in/i, '要把桥给的原因原样带出来');
    // ensure() 必须复用而不是再拉一个（否则撞端口）
    const ensured = await sup.ensure({ readyTimeoutMs: 500 });
    assert.equal(ensured.reused, true, '凭据异常时要复用这个桥');
    assert.equal(ensured.started, false, '不许因为健康检查不绿就再拉一个');
    assert.equal(ensured.state, 'degraded');
  } finally { await ours.close(); }

  // ①b 从来没登录过：503 里带 credential（桌面端不可用、插件账号 0 个）→ 未登录
  const fresh = await startFake({
    ok: false,
    error: 'no usable credential (auto): desktop: login file not found; plugin: no plugin credential yet',
    authFile: 'C:\\auth\\workbuddy-desktop.info',
    credential: {
      configured: 'auto',
      desktop: { available: false, error: 'login file not found', userId: '' },
      plugin: { available: false, count: 0, activeUid: '', uids: [], error: '' },
    },
  });
  try {
    const sup = new BridgeSupervisor({ host: '127.0.0.1', port: fresh.port, token: 't', projectRoot: '.', logPath: 'x' });
    const probe = await sup.probe();
    assert.equal(probe.state, 'unauthenticated', '首次安装没登录必须是「未登录」，不是「凭据异常」');
    const ensured = await sup.ensure({ readyTimeoutMs: 500 });
    assert.equal(ensured.reused, true, '未登录时也复用桥');
    assert.equal(ensured.state, 'unauthenticated');
    const restarted = await sup.ensure({ restart: true, readyTimeoutMs: 500 });
    assert.equal(restarted.reused, true, '未登录时点重启不能再去起一个实例');
    assert.equal(restarted.started, false, '未登录时重启必须复用，否则会撞端口');
  } finally { await fresh.close(); }

  // ② 真的不是我们的服务：503 + HTML（比如某个反向代理）
  const foreign = await startFake('<html><body>503 Service Unavailable</body></html>', 503, 'text/html');
  try {
    const sup = new BridgeSupervisor({ host: '127.0.0.1', port: foreign.port, token: 't', projectRoot: '.', logPath: 'x' });
    const probe = await sup.probe();
    assert.equal(probe.state, 'foreign', 'HTML 503 不能被当成自己的桥');
  } finally { await foreign.close(); }

  // ③ 令牌不符：401 → unauthorized
  const wrongToken = await startFake({ error: { message: 'bad or missing local token' } }, 401);
  try {
    const sup = new BridgeSupervisor({ host: '127.0.0.1', port: wrongToken.port, token: 't', projectRoot: '.', logPath: 'x' });
    assert.equal((await sup.probe()).state, 'unauthorized');
  } finally { await wrongToken.close(); }
});

test('构建指纹：端口上的桥与当前脚本不一致（含旧桥没有 build）必须标记 staleBuild', async () => {
  /*
   * 升级只换磁盘脚本，旧桥进程不会自己退出。没有这个比对，插件会一直
   * 复用旧进程：思考档位、换号跟随、目录判定全是旧代码，而版本号看起来
   * 已经是最新（issue #5 / #6 的真实触发条件）。
   */
  const { createServer } = await import('node:http');
  const dir = mkdtempSync(join(tmpdir(), 'wb-build-'));
  const scriptPath = join(dir, 'bridge.mjs');
  writeFileSync(scriptPath, '// build under test\nexport const marker = 1;\n');
  const expected = bridgeBuildHash(scriptPath);
  assert.ok(expected, '临时脚本必须能算出指纹');

  const state = { build: 'old-build' };
  const server = createServer((req, res) => {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({
      ok: true,
      pid: 4242,
      authFile: join(dir, 'workbuddy-desktop.info'),
      ...(state.build === null ? {} : { build: state.build }),
    }));
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const sup = new BridgeSupervisor({
    host: '127.0.0.1',
    port: server.address().port,
    token: 't',
    projectRoot: dir,
    scriptPath,
    logPath: join(dir, 'bridge.log'),
  });
  try {
    const stale = await sup.probe();
    assert.equal(stale.state, 'running');
    assert.equal(stale.staleBuild, true, '旧 build 必须标记为需要重启');
    assert.equal(stale.expectedBuild, expected);
    assert.equal(stale.bridgeBuild, 'old-build');

    // 旧版桥根本没有 build 字段：同样要重启，否则永远升不上去
    state.build = null;
    const missing = await sup.probe();
    assert.equal(missing.staleBuild, true, '没有 build 字段的旧桥也必须标记');
    assert.equal(missing.bridgeBuild, '');

    // 与磁盘脚本一致：正常复用
    state.build = expected;
    const fresh = await sup.probe();
    assert.equal(fresh.staleBuild, false, 'build 一致时不应触发重启');
  } finally {
    await new Promise((r) => server.close(r));
    rmSync(dir, { recursive: true, force: true });
  }
});

test('ensure：旧构建 / 账号文件不一致时必须停掉旧桥并重新拉起', async () => {
  /*
   * 仅探测到 staleBuild 还不够 —— 真正加载新逻辑的动作是 ensure 里的
   * 「stop 旧进程 → start 新进程」。这里用桩把这条路径钉住，避免以后
   * 有人把判断加进了 probe 却忘记在 ensure 里执行。
   */
  const dir = mkdtempSync(join(tmpdir(), 'wb-ensure-build-'));
  const scriptPath = join(dir, 'bridge.mjs');
  writeFileSync(scriptPath, '// ensure-build test\nexport const marker = 1;\n');
  const expected = bridgeBuildHash(scriptPath);
  const makeStub = () => {
    const sup = new BridgeSupervisor({
      host: '127.0.0.1',
      port: 1,
      token: 't',
      projectRoot: dir,
      scriptPath,
      authFile: join(dir, 'wanted.info'),
      logPath: join(dir, 'bridge.log'),
    });
    let probes = 0;
    const calls = { stopped: 0, started: 0 };
    sup.stop = async () => { calls.stopped += 1; return { ok: true, stopped: true }; };
    sup.start = async () => { calls.started += 1; return { ok: true, pid: 2222 }; };
    return { sup, calls, nextProbe: () => { probes += 1; return probes; } };
  };

  try {
    // ① 旧构建：第一次探测是旧 build，重启后是当前磁盘脚本
    {
      const { sup, calls, nextProbe } = makeStub();
      sup.probe = async () => (nextProbe() === 1
        ? {
          state: 'running',
          health: { ok: true, pid: 1111, build: 'old-build', authFile: join(dir, 'wanted.info') },
          staleBuild: true,
          bridgeBuild: 'old-build',
          expectedBuild: expected,
        }
        : {
          state: 'running',
          health: { ok: true, pid: 2222, build: expected, authFile: join(dir, 'wanted.info') },
          staleBuild: false,
          bridgeBuild: expected,
          expectedBuild: expected,
        });
      const result = await sup.ensure({ readyTimeoutMs: 3000 });
      assert.equal(calls.stopped, 1, '旧构建必须先停掉旧进程');
      assert.equal(calls.started, 1, '必须重新拉起一次');
      assert.equal(result.started, true);
      assert.equal(result.reused, false);
    }

    // ② 构建一致但账号文件不同：同样必须重启，否则会继续服务另一个账号
    {
      const { sup, calls, nextProbe } = makeStub();
      sup.probe = async () => (nextProbe() === 1
        ? {
          state: 'running',
          health: { ok: true, pid: 1111, build: expected, authFile: join(dir, 'other.info') },
          staleBuild: false,
          bridgeBuild: expected,
          expectedBuild: expected,
        }
        : {
          state: 'running',
          health: { ok: true, pid: 2222, build: expected, authFile: join(dir, 'wanted.info') },
          staleBuild: false,
          bridgeBuild: expected,
          expectedBuild: expected,
        });
      const result = await sup.ensure({ readyTimeoutMs: 3000 });
      assert.equal(calls.stopped, 1, '账号文件不一致时必须重启');
      assert.equal(calls.started, 1);
      assert.equal(result.started, true);
    }
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('分发形态：只有插件文件夹（自带 vendor）时也能定位到运行目录', async () => {
  const { cpSync } = await import('node:fs');
  const { pathToFileURL } = await import('node:url');
  const sandbox = mkdtempSync(join(tmpdir(), 'wb-standalone-'));
  try {
    // 造一个"别人拿到的样子"：<sandbox>/dsh-plugin（含 lib + vendor），父目录里没有仓库
    const pluginDir = join(sandbox, 'dsh-plugin');
    mkdirSync(pluginDir, { recursive: true });
    cpSync(join(PLUGIN_ROOT, 'lib'), join(pluginDir, 'lib'), { recursive: true });
    cpSync(join(PLUGIN_ROOT, 'vendor'), join(pluginDir, 'vendor'), { recursive: true });
    assert.ok(existsSync(join(pluginDir, 'vendor', 'bridge', 'workbuddy-bridge.mjs')), 'vendor 里必须有桥脚本');
    assert.ok(existsSync(join(pluginDir, 'vendor', 'dashboard', 'server.mjs')), 'vendor 里必须有控制台脚本');

    // 动态 import 一个"副本插件"：它的 PLUGIN_DIR 就是临时目录，能真实检验解析顺序
    const prevRoot = process.env.WORKBUDDY_ROOT;
    delete process.env.WORKBUDDY_ROOT;
    try {
      const mod = await import(pathToFileURL(join(pluginDir, 'lib', 'index.js')).href);
      const detected = mod.detectProjectRoot();
      // macOS 的 tmpdir 在 /var/folders → ESM loader 会把模块路径 realpath 成
      // /private/var/folders —— 两侧都 realpath 归一后再比，断言语义不变
      const { realpathSync } = await import('node:fs');
      assert.equal(realpathSync(detected), realpathSync(join(pluginDir, 'vendor')), '没有仓库时必须回落到插件自带的 vendor/');
      // 候选顺序：仓库位置排在 vendor 前面（本机开发优先用仓库）
      const kinds = mod.projectRootCandidates('').map((c) => c.kind);
      assert.ok(kinds.indexOf('repo') < kinds.indexOf('vendor'), '仓库检出目录必须优先于 vendor');
    } finally {
      if (prevRoot !== undefined) process.env.WORKBUDDY_ROOT = prevRoot;
    }
  } finally { rmSync(sandbox, { recursive: true, force: true }); }
});

test('分发形态：仓库在旁边时优先用仓库（不会被 vendor 快照盖住）', async () => {
  const { cpSync } = await import('node:fs');
  const { pathToFileURL } = await import('node:url');
  const sandbox = mkdtempSync(join(tmpdir(), 'wb-repo-'));
  try {
    // <sandbox>/bridge/... + <sandbox>/dsh-plugin/{lib,vendor} —— 两边都有桥，
    // 必须选仓库那份（否则本机改了 bridge 却不生效）
    mkdirSync(join(sandbox, 'bridge'), { recursive: true });
    writeFileSync(join(sandbox, 'bridge', 'workbuddy-bridge.mjs'), '// repo copy\n');
    const pluginDir = join(sandbox, 'dsh-plugin');
    mkdirSync(pluginDir, { recursive: true });
    cpSync(join(PLUGIN_ROOT, 'lib'), join(pluginDir, 'lib'), { recursive: true });
    cpSync(join(PLUGIN_ROOT, 'vendor'), join(pluginDir, 'vendor'), { recursive: true });

    const prevRoot = process.env.WORKBUDDY_ROOT;
    delete process.env.WORKBUDDY_ROOT;
    try {
      const mod = await import(pathToFileURL(join(pluginDir, 'lib', 'index.js')).href);
      // 同上：macOS tmpdir 的 /var → /private/var 符号链接，realpath 归一后再比
      const { realpathSync } = await import('node:fs');
      assert.equal(realpathSync(mod.detectProjectRoot()), realpathSync(sandbox), '仓库检出目录优先于 vendor 快照');
    } finally {
      if (prevRoot !== undefined) process.env.WORKBUDDY_ROOT = prevRoot;
    }
  } finally { rmSync(sandbox, { recursive: true, force: true }); }
});

test('面板 /workbuddy/models 返回归一化目录（不是上游原始字段名）', async () => {
  const { createRouteTable } = await import('../lib/routes.mjs');
  const route = createRouteTable({
    snapshot: async () => ({}),
    supervisor: { readLog: () => ({ lines: [] }) },
    client: {},
    adapter: {
      catalogCache: { at: Date.now(), models: [] },
      catalogError: '',
      async catalog() {
        return [
          { id: 'm1', name: 'M One', context_window: 128000, max_output_tokens: 8192, credits: 0.5, supports_images: true, free: false },
        ];
      },
    },
    paths: { settingsPath: 'x', patchPath: 'y' },
    provider: 'workbuddy',
    log: () => {},
  }).find((r) => r.path === '/workbuddy/models');

  let payload;
  const res = {
    writeHead() {},
    end(body) { payload = JSON.parse(body); },
  };
  await route.handler({ url: '/workbuddy/models', method: 'GET' }, res);
  assert.equal(payload.ok, true);
  assert.equal(payload.models.length, 1);
  const [model] = payload.models;
  assert.equal(model.contextWindow, 128000, '必须是 contextWindow，而不是上游的 context_window');
  assert.equal(model.maxTokens, 8192);
  assert.equal(model.images, true);
  assert.equal(model.credits, 0.5);
});

test('登录完成后刷新模型目录并广播 adapters-updated', async () => {
  const { createRouteTable } = await import('../lib/routes.mjs');
  const calls = [];
  const route = createRouteTable({
    snapshot: async () => ({}),
    supervisor: { readLog: () => ({ lines: [] }) },
    client: { deviceLoginPoll: async () => ({ ok: true, status: 'ready', account: { uid: 'uid-1' } }) },
    adapter: {
      catalogCache: { at: 0, models: [] },
      catalogError: '',
      invalidate() { calls.push('invalidate'); },
      async warmup() { calls.push('warmup'); },
    },
    paths: { settingsPath: 'x', patchPath: 'y' },
    provider: 'workbuddy',
    log: () => {},
    onUpstreamMutation: () => calls.push('mutation'),
    notifyAdaptersUpdated: () => { calls.push('notify'); return true; },
  }).find((r) => r.path === '/workbuddy/login/poll');

  let payload;
  const req = {
    method: 'POST',
    headers: { 'x-workbuddy-panel': '1' },
    url: '/workbuddy/login/poll',
    async *[Symbol.asyncIterator]() { yield Buffer.from(JSON.stringify({ state: 's' })); },
  };
  const res = { writeHead() {}, end(body) { payload = JSON.parse(body); } };
  await route.handler(req, res);
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(payload.status, 'ready');
  assert.deepEqual(calls, ['invalidate', 'warmup', 'mutation', 'notify'],
    '登录成功后必须重取目录并通知 dsh，否则选择器还显示旧账号的模型');
});

test('面板写操作要求 x-workbuddy-panel 头（挡住跨站简单请求）', async () => {
  const { createRouteTable } = await import('../lib/routes.mjs');
  const calls = [];
  const route = createRouteTable({
    snapshot: async () => ({}),
    supervisor: {
      readLog: () => ({ lines: [] }),
      probe: async () => ({ state: 'stopped' }),
      ensure: async () => { calls.push('ensure'); return { ok: true, health: { pid: 1 } }; },
      stop: async () => ({ ok: true, stopped: true }),
    },
    client: {},
    adapter: { catalogCache: { at: 0, models: [] }, catalogError: '', invalidate() {} },
    paths: { settingsPath: 'x', patchPath: 'y' },
    provider: 'workbuddy',
    log: () => {},
  }).find((r) => r.path === '/workbuddy/bridge');

  const send = () => {
    let status = 0;
    let payload;
    const res = { writeHead(code) { status = code; }, end(body) { payload = body ? JSON.parse(body) : undefined; } };
    return { res, get: () => ({ status, payload }) };
  };

  const denied = send();
  await route.handler({ method: 'POST', headers: {}, url: '/workbuddy/bridge', async *[Symbol.asyncIterator]() {} }, denied.res);
  assert.equal(denied.get().status, 403);
  assert.equal(calls.length, 0, '没有头的请求不能触发任何桥操作');

  const allowed = send();
  const body = JSON.stringify({ action: 'start' });
  await route.handler({
    method: 'POST',
    headers: { 'x-workbuddy-panel': '1' },
    url: '/workbuddy/bridge',
    async *[Symbol.asyncIterator]() { yield Buffer.from(body); },
  }, allowed.res);
  assert.equal(allowed.get().status, 200);
  assert.equal(allowed.get().payload.ok, true);
  assert.deepEqual(calls, ['ensure']);
});

test('readProjectEnv 解析 .env，且只在 config 未显式指定时生效', () => {
  const dir = mkdtempSync(join(tmpdir(), 'wb-env-'));
  try {
    mkdirSync(join(dir, 'bridge'), { recursive: true });
    writeFileSync(join(dir, 'bridge', 'workbuddy-bridge.mjs'), '// stub\n', 'utf8');
    writeFileSync(join(dir, '.env'), [
      '# 注释',
      'WORKBUDDY_PORT=8899',
      'WORKBUDDY_LOCAL_TOKEN="tok-from-env"',
      'WORKBUDDY_AUTH_FILE=\'C:\\tmp\\custom.info\'',
      'WORKBUDDY_APP_VERSION=5.8.3',
      'WORKBUDDY_11128_FALLBACK=0',
      '',
    ].join('\n'), 'utf8');

    const parsed = readProjectEnv(dir);
    assert.equal(parsed.WORKBUDDY_PORT, '8899');
    assert.equal(parsed.WORKBUDDY_LOCAL_TOKEN, 'tok-from-env');
    assert.equal(parsed.WORKBUDDY_AUTH_FILE, 'C:\\tmp\\custom.info');

    const { ctx } = fakeCtx();
    // 不显式给端口 → 跟随 .env
    const fromEnv = apply(ctx, { projectRoot: dir, autoStart: false, tools: false, commands: false, routes: false, migrateLegacy: false });
    assert.equal(fromEnv.state.config.bridgePort, 8899, '.env 里的端口必须被采纳');
    assert.equal(fromEnv.state.config.localToken, 'tok-from-env');
    assert.equal(fromEnv.supervisor.authFile, 'C:\\tmp\\custom.info');
    assert.equal(fromEnv.supervisor.env.WORKBUDDY_APP_VERSION, '5.8.3',
      '版本逃生门必须从 .env 一路进到 BridgeSupervisor.env');
    assert.equal(fromEnv.supervisor.env.WORKBUDDY_11128_FALLBACK, '0');

    // 显式给了端口 → 以配置为准，不被 .env 覆盖
    const { ctx: ctx2 } = fakeCtx();
    const explicit = apply(ctx2, { projectRoot: dir, bridgePort: 9911, autoStart: false, tools: false, commands: false, routes: false, migrateLegacy: false });
    assert.equal(explicit.state.config.bridgePort, 9911, '显式配置优先于 .env');
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('插件自动签到：未显式配置时跟随 .state.json，显式配置优先', () => {
  const stateFile = process.env.WORKBUDDY_STATE_FILE;
  const backup = existsSync(stateFile) ? readFileSync(stateFile, 'utf8') : null;
  const dir = mkdtempSync(join(tmpdir(), 'wb-auto-checkin-'));
  try {
    writeFileSync(stateFile, JSON.stringify({ checkin: { auto: false } }), 'utf8');

    const { ctx } = fakeCtx();
    const off = apply(ctx, {
      projectRoot: dir, autoStart: false, tools: false, commands: false, routes: false, migrateLegacy: false,
    });
    assert.equal(off.supervisor.autoCheckin, false,
      '面板关了签到，插件拉起的桥也必须关，不能按默认值继续签');

    const { ctx: ctx2 } = fakeCtx();
    const on = apply(ctx2, {
      projectRoot: dir, autoStart: false, tools: false, commands: false, routes: false, migrateLegacy: false,
      autoCheckin: true,
    });
    assert.equal(on.supervisor.autoCheckin, true, '插件显式配置必须高于 .state.json');
  } finally {
    if (backup === null) rmSync(stateFile, { force: true });
    else writeFileSync(stateFile, backup, 'utf8');
    rmSync(dir, { recursive: true, force: true });
  }
});

test('probe-audit-template：桥不可达时必须退出码非 0（不能永远“通过”）', () => {
  const r = spawnSync(process.execPath, [join(PLUGIN_ROOT, '..', 'tools', 'dev', 'probe-audit-template.mjs')], {
    env: { ...process.env, WORKBUDDY_BRIDGE_URL: 'http://127.0.0.1:1' },
    timeout: 30_000,
    encoding: 'utf8',
  });
  assert.notEqual(r.status, 0, `桥不可达时探针仍返回 0：\n${r.stdout}\n${r.stderr}`);
  assert.match(String(r.stdout), /退出码 1/);
});

test('默认值：插件把空闲看门狗默认开到 5 分钟，显式 0 仍可关闭', () => {
  assert.equal(resolveConfig({}).streamIdleTimeoutMs, 300_000);
  assert.equal(resolveConfig({ streamIdleTimeoutMs: 0 }).streamIdleTimeoutMs, 0);
  assert.equal(resolveConfig({ streamIdleTimeoutMs: '120000' }).streamIdleTimeoutMs, 120_000);
});

test('默认值：控制台默认按需启动，不随 dsh 常驻', () => {
  assert.equal(resolveConfig({}).consoleAutoStart, false);
  assert.equal(resolveConfig({ consoleAutoStart: true }).consoleAutoStart, true);
});

test('默认值：插件拉起的控制台闲置 10 分钟退出，显式 0 仍可常驻', () => {
  assert.equal(resolveConfig({}).consoleIdleExitMs, 600_000);
  assert.equal(resolveConfig({ consoleIdleExitMs: 0 }).consoleIdleExitMs, 0);
  assert.equal(resolveConfig({ consoleIdleExitMs: '120000' }).consoleIdleExitMs, 120_000);
  assert.equal(resolveConfig({ consoleIdleExitMs: -1 }).consoleIdleExitMs, 600_000, '负数按非法值回默认');
  assert.equal(resolveConfig({ consoleIdleExitMs: 'abc' }).consoleIdleExitMs, 600_000, '非法值回默认');
});

test('默认值：限流自动切号默认关闭，显式配置才生效', () => {
  assert.equal(resolveConfig({}).accountFailoverAfter, 0);
  assert.equal(resolveConfig({ accountFailoverAfter: 3 }).accountFailoverAfter, 3);
  assert.equal(resolveConfig({ accountFailoverAfter: -2 }).accountFailoverAfter, 0);
  assert.equal(resolveConfig({ accountFailoverAfter: 'abc' }).accountFailoverAfter, 0);
});

test('限流自动切号：跳过当前 / 隐藏 / 不可用账号，按列表循环选下一个', () => {
  const accounts = [
    { name: 'a.info', active: true, usable: true, userId: 'u1' },
    { name: 'b.info', usable: false },
    { name: 'c.info', usable: true, hidden: true },
    { name: 'd.info', usable: true, userId: 'u4' },
  ];
  assert.equal(pickAccountFailoverTarget(accounts, 'u1')?.name, 'd.info');
  assert.equal(pickAccountFailoverTarget([{ name: 'a.info', active: true, usable: true }], 'u1'), null);
  assert.equal(pickAccountFailoverTarget([
    { name: 'x.info', usable: true },
    { name: 'y.info', usable: true },
  ], '')?.name, 'x.info', '没有 active 标记时从第一个可用账号开始');
  assert.equal(pickAccountFailoverTarget([
    { name: 'a.info', active: true, usable: true },
    { name: 'b.info', usable: true },
    { name: 'c.info', usable: true },
  ], 'u1')?.name, 'b.info', '按列表顺序循环，而不是随机');
});

test('collectBridgeExtraEnv：版本/11128/预检/超时真正透传给桥，且不泄露凭据', () => {
  const projectEnv = {
    WORKBUDDY_APP_VERSION: '5.8.3',
    WORKBUDDY_IDE_NAME: 'WorkBuddy',
    WORKBUDDY_11128_FALLBACK: '0',
    WORKBUDDY_SKIP_MODEL_PREFLIGHT: '1',
    WORKBUDDY_FIRST_BYTE_TIMEOUT_MS: '1000',
    WORKBUDDY_QUEUE_TIMEOUT_MS: '0',
    WORKBUDDY_MAX_SOCKETS: '64',
    WORKBUDDY_SEARCH_BASE: 'https://search.example',
    WORKBUDDY_SEARCH_TIMEOUT_MS: '5000',
    WORKBUDDY_SEARCH_MAX_RESULTS: '8',
    WORKBUDDY_MIORA_BASE: 'https://miora.example',
    WORKBUDDY_APP_EXECUTABLE: '/Applications/WorkBuddy.app/Contents/MacOS/Electron',
    // 下面两个是机密/连接参数，绝不能进“非机密透传”清单
    WORKBUDDY_LOCAL_TOKEN: 'must-not-leak',
    CODEBUDDY_API_KEY: 'must-not-leak',
    WORKBUDDY_CLIENT_KEYS: 'must-not-leak',
  };
  const out = collectBridgeExtraEnv(projectEnv, {});
  assert.equal(out.WORKBUDDY_APP_VERSION, '5.8.3');
  assert.equal(out.WORKBUDDY_IDE_NAME, 'WorkBuddy');
  assert.equal(out.WORKBUDDY_11128_FALLBACK, '0');
  assert.equal(out.WORKBUDDY_SKIP_MODEL_PREFLIGHT, '1');
  assert.equal(out.WORKBUDDY_FIRST_BYTE_TIMEOUT_MS, '1000');
  assert.equal(out.WORKBUDDY_QUEUE_TIMEOUT_MS, '0', '0 是合法值，不能被当成空值丢掉');
  assert.equal(out.WORKBUDDY_MAX_SOCKETS, '64');
  assert.equal(out.WORKBUDDY_SEARCH_BASE, 'https://search.example');
  assert.equal(out.WORKBUDDY_SEARCH_TIMEOUT_MS, '5000');
  assert.equal(out.WORKBUDDY_SEARCH_MAX_RESULTS, '8');
  assert.equal(out.WORKBUDDY_MIORA_BASE, 'https://miora.example');
  assert.equal(out.WORKBUDDY_APP_EXECUTABLE, '/Applications/WorkBuddy.app/Contents/MacOS/Electron',
    '.env 的客户端路径覆盖必须传到插件拉起的桥（macOS 自救路径）');
  assert.equal(out.WORKBUDDY_LOCAL_TOKEN, undefined);
  assert.equal(out.CODEBUDDY_API_KEY, undefined);
  assert.equal(out.WORKBUDDY_CLIENT_KEYS, undefined);
  assert.equal(BRIDGE_ENV_PASSTHROUGH.includes('WORKBUDDY_APP_VERSION'), true);
  assert.equal(BRIDGE_ENV_PASSTHROUGH.includes('WORKBUDDY_11128_FALLBACK'), true);

  // 进程环境是第二优先级；.env 的值优先
  const out2 = collectBridgeExtraEnv({}, {
    WORKBUDDY_IDE_NAME: 'FromProcess',
    WORKBUDDY_APP_VERSION: '1.0.0',
  });
  assert.equal(out2.WORKBUDDY_IDE_NAME, 'FromProcess');
  assert.equal(out2.WORKBUDDY_APP_VERSION, '1.0.0');
});

test('ConsoleSupervisor：靠首页结构标记识别控制台，认不出就报 foreign', async () => {
  const { ConsoleSupervisor, CONSOLE_MARKER } = await import('../lib/console.mjs');
  const { createServer } = await import('node:http');

  // 1) 真控制台（首页带我们的结构标记）
  const real = createServer((req, res) => {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    res.end(`<!doctype html><html><body><nav ${CONSOLE_MARKER}></nav>ok</body></html>`);
  });
  await new Promise((r) => real.listen(0, '127.0.0.1', r));
  const realPort = real.address().port;
  try {
    const sup = new ConsoleSupervisor({ projectRoot: 'x', port: realPort, cacheTtlMs: 0 });
    const probe = await sup.probe({ cached: false });
    assert.equal(probe.state, 'running');
    assert.equal(sup.url, `http://127.0.0.1:${realPort}`);
    const ensured = await sup.ensure({});
    assert.equal(ensured.ok, true);
    assert.equal(ensured.reused, true, '已在运行的控制台必须复用，不重复拉起');
    // 别人起的控制台（双击 启动.cmd）：插件不去停它
    const stopped = await sup.stop();
    assert.equal(stopped.ok, false);
    assert.match(stopped.error, /不是插件启动的/);
  } finally { await new Promise((r) => real.close(r)); }

  // 2) 端口被别的 HTTP 服务占着 → foreign，且不会去「拉起」
  const foreign = createServer((req, res) => { res.writeHead(200, { 'content-type': 'text/html' }); res.end('<title>别的服务</title>'); });
  await new Promise((r) => foreign.listen(0, '127.0.0.1', r));
  const foreignPort = foreign.address().port;
  try {
    const sup = new ConsoleSupervisor({ projectRoot: 'x', port: foreignPort, cacheTtlMs: 0 });
    assert.equal((await sup.probe({ cached: false })).state, 'foreign');
    const ensured = await sup.ensure({});
    assert.equal(ensured.ok, false);
    assert.equal(ensured.reused, false);
  } finally { await new Promise((r) => foreign.close(r)); }

  // 3) 没人监听 → stopped
  const sup = new ConsoleSupervisor({ projectRoot: 'x', port: 1, cacheTtlMs: 0 });
  assert.equal((await sup.probe({ cached: false })).state, 'stopped');
});

test('ConsoleSupervisor：页面构建指纹不一致或旧页面没有 meta → staleBuild', async () => {
  /*
   * 升级后 8792 上可能还是旧控制台。页面里嵌 `wb-console-build`，插件探活
   * 时对照当前磁盘代码；缺失（旧版页面）或不同都必须标记，才能自动重启。
   */
  const { ConsoleSupervisor, consoleBuildHash, CONSOLE_MARKER } = await import('../lib/console.mjs');
  const { createServer } = await import('node:http');
  const dir = mkdtempSync(join(tmpdir(), 'wb-console-build-'));
  mkdirSync(join(dir, 'dashboard', 'public'), { recursive: true });
  writeFileSync(join(dir, 'dashboard', 'server.mjs'), '// console under test\n');
  writeFileSync(join(dir, 'dashboard', 'public', 'index.html'), '<meta name="wb-console-build" content="__WB_BUILD__">\n');
  writeFileSync(join(dir, 'dashboard', 'public', 'style.css'), '/* style */\n');
  const expected = consoleBuildHash(dir);
  assert.ok(expected, '临时控制台文件必须能算出指纹');

  const state = { build: expected };
  const srv = createServer((req, res) => {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    res.end('<!doctype html><head>'
      + (state.build === null ? '' : `<meta name="wb-console-build" content="${state.build}">`)
      + `</head><body><nav ${CONSOLE_MARKER}></nav></body>`);
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const sup = new ConsoleSupervisor({ projectRoot: dir, port: srv.address().port, cacheTtlMs: 0 });
  try {
    const fresh = await sup.probe({ cached: false });
    assert.equal(fresh.state, 'running');
    assert.equal(fresh.staleBuild, false, '指纹一致时不应触发重启');
    assert.equal(fresh.build, expected);

    state.build = 'old-build';
    assert.equal((await sup.probe({ cached: false })).staleBuild, true, '旧构建必须标记');

    state.build = null;
    assert.equal((await sup.probe({ cached: false })).staleBuild, true, '旧版页面没有 meta 也必须标记');
  } finally {
    await new Promise((r) => srv.close(r));
    rmSync(dir, { recursive: true, force: true });
  }
});

test('probe() 有界读取：标记远在首个 chunk 之后也必须认出来（先红后绿，§7 P0-2）', async () => {
  const { ConsoleSupervisor, CONSOLE_MARKER } = await import('../lib/console.mjs');
  const { createServer } = await import('node:http');

  /**
   * 110KB 填充 + 标记放在最后，整页一次写出。
   *
   * 这正是原实现（只读"第一个 chunk"就判断）的失效场景 —— 报告 §6.0 实测
   * 30/30 全部误判：首块读到的只是开头一部分，永远到不了标记。修复后应逐块
   * 读到匹配或上限为止。
   */
  const pad = 'x'.repeat(110 * 1024);
  const srv = createServer((req, res) => {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    res.end(`<!doctype html><html><body>${pad}<nav ${CONSOLE_MARKER}></nav></body></html>`);
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const port = srv.address().port;
  try {
    const sup = new ConsoleSupervisor({ projectRoot: 'x', port, cacheTtlMs: 0 });
    const probe = await sup.probe({ cached: false });
    assert.equal(probe.state, 'running', '标记不在首块内时不得误判 foreign');
  } finally { await new Promise((r) => srv.close(r)); }
});

test('probe() 有界读取：超过上限也没有标记 → 判 foreign，不无限读', async () => {
  const { ConsoleSupervisor, CONSOLE_READ_CAP } = await import('../lib/console.mjs');
  const { createServer } = await import('node:http');

  // 上限之外**远超一个 chunk** 才放标记：读取必须在上限处停下（而非读完整个 body）。
  // 留 256KB 余量 —— 上限检查按 chunk 粒度，最后一个被读的块可能越过上限一点；
  // 若标记贴着上限放，可能恰好被那块覆盖，用例就测不到"停在边界"的语义了。
  const pad = 'x'.repeat(CONSOLE_READ_CAP + 256 * 1024);
  const srv = createServer((req, res) => {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    res.end(`<!doctype html><html><body>${pad}<nav id="navTabs"></nav></body></html>`);
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const port = srv.address().port;
  try {
    const sup = new ConsoleSupervisor({ projectRoot: 'x', port, cacheTtlMs: 0 });
    const probe = await sup.probe({ cached: false });
    assert.equal(probe.state, 'foreign');
  } finally { await new Promise((r) => srv.close(r)); }
});

test('交叉校验（§6.0 纪律）：真产物 index.html 的识别标记必须在 probe 读取上限之内', async () => {
  const { CONSOLE_MARKER, CONSOLE_READ_CAP } = await import('../lib/console.mjs');
  /**
   * 本文件其余用例都是「用被测常量造夹具」——它们只能证明"代码读得到自己写的
   * 常量"。这条不同：**直读 dashboard/public/index.html 真产物**。§6.0 的教训是
   * 「凡读外部资源做判断的常量，必须有一条对真实产物的断言」——页面的标记改名 /
   * 位置下移时，先红的就是这条，而不是等用户发现插件认不出控制台。
   */
  const htmlPath = join(PLUGIN_ROOT, '..', 'dashboard', 'public', 'index.html');
  const html = readFileSync(htmlPath, 'utf8');
  const at = html.indexOf(CONSOLE_MARKER);
  assert.ok(at >= 0, `真产物缺少识别标记 ${CONSOLE_MARKER}（控制台会被 probe() 判成 foreign）`);
  assert.ok(
    at < CONSOLE_READ_CAP,
    `识别标记位于第 ${at} 字节，超出 probe() 的读取上限 ${CONSOLE_READ_CAP}`,
  );
});

test('快照与控制台路由：状态里带 console，写操作同样要面板头', async () => {
  const { createRouteTable } = await import('../lib/routes.mjs');
  const consoleSupervisor = {
    url: 'http://127.0.0.1:8792',
    spawnedPid: null,
    async probe() { return { state: 'running', error: '' }; },
    async ensure() { return { ok: true, reused: true, url: this.url }; },
    async stop() { return { ok: false, error: '不是插件启动的' }; },
  };
  const routes = createRouteTable({
    snapshot: async () => ({ console: { state: 'running', url: consoleSupervisor.url } }),
    supervisor: { readLog: () => ({ lines: [] }), probe: async () => ({ state: 'running' }) },
    consoleSupervisor,
    client: {},
    adapter: { catalogCache: { at: 0, models: [] }, catalogError: '' },
    paths: { settingsPath: 'x', patchPath: 'y' },
    provider: 'workbuddy',
    log: () => {},
  });

  let statusPayload;
  await routes.find((r) => r.path === '/workbuddy/status').handler(
    { url: '/workbuddy/status', method: 'GET' },
    { writeHead() {}, end(b) { statusPayload = JSON.parse(b); } },
  );
  assert.equal(statusPayload.console.url, 'http://127.0.0.1:8792');
  assert.equal(statusPayload.console.state, 'running');

  const consoleRoute = routes.find((r) => r.path === '/workbuddy/console');
  assert.ok(consoleRoute, '必须挂上 /workbuddy/console');

  let getPayload;
  await consoleRoute.handler({ url: '/workbuddy/console', method: 'GET' }, { writeHead() {}, end(b) { getPayload = JSON.parse(b); } });
  assert.equal(getPayload.url, consoleSupervisor.url);
  assert.equal(getPayload.state, 'running');

  let denied = 0;
  await consoleRoute.handler({ method: 'POST', headers: {}, url: '/workbuddy/console', async *[Symbol.asyncIterator]() {} }, { writeHead(c) { denied = c; }, end() {} });
  assert.equal(denied, 403);

  let okStatus = 0;
  let okPayload;
  const body = JSON.stringify({ action: 'start' });
  await consoleRoute.handler({
    method: 'POST',
    headers: { 'x-workbuddy-panel': '1' },
    url: '/workbuddy/console',
    async *[Symbol.asyncIterator]() { yield Buffer.from(body); },
  }, { writeHead(c) { okStatus = c; }, end(b) { okPayload = JSON.parse(b); } });
  assert.equal(okStatus, 200);
  assert.equal(okPayload.ok, true);
  assert.equal(okPayload.action, 'start');
});

test('apply() 的 migrateLegacy 默认会清理指向的文件（用临时目录）', () => {
  const dir = mkdtempSync(join(tmpdir(), 'wb-migrate-'));
  const previous = { home: process.env.DSH_HOME, dir: process.env.DSH_PROFILE_DIR, profile: process.env.DSH_PROFILE };
  try {
    // 先把 dsh home **与 profile 目录**都指向临时目录。注意：DSH_PROFILE_DIR 的
    // 优先级高于 DSH_HOME，只改 DSH_HOME 会让 patchPath 落到真实 profile 上
    // （这正是本测试曾经误改真实文件的原因）。
    const profileDir = join(dir, 'profiles', 'test-profile');
    process.env.DSH_HOME = dir;
    process.env.DSH_PROFILE = 'test-profile';
    process.env.DSH_PROFILE_DIR = profileDir;
    mkdirSync(profileDir, { recursive: true });
    const settings = join(dir, 'settings.yaml');
    const patch = join(profileDir, 'cordis.patch.yml');
    writeFileSync(settings, SETTINGS, 'utf8');
    writeFileSync(patch, PATCH, 'utf8');

    const { ctx } = fakeCtx();
    const result = apply(ctx, { projectRoot: join(dir, 'nowhere'), autoStart: false, tools: false, commands: false, routes: false });
    // 语义：`cleaned` 记录这次删了什么，`found` 是**清理之后**是否还有残留
    assert.equal(result.state.legacy.cleaned.changed, true);
    assert.equal(result.state.legacy.found, false, '清理干净之后不应再报“检测到旧路由”');
    assert.ok(result.state.legacy.cleaned.files.some((f) => f.changed && f.backup), '必须有文件被改且留下备份');
    assert.equal(result.state.dshPaths.patchPath, patch, 'patchPath 必须落在临时目录里');
    assert.doesNotMatch(readFileSync(settings, 'utf8'), /workbuddy:/);
    assert.doesNotMatch(readFileSync(patch, 'utf8'), /^\s+workbuddy:$/m);
    // patch 里其它内容与插件自己的条目都不受影响
    assert.match(readFileSync(patch, 'utf8'), /- id: workbuddy\n  name: dsh-plugin-workbuddy/);
    assert.match(readFileSync(patch, 'utf8'), /keep-me:/);
  } finally {
    if (previous.home === undefined) delete process.env.DSH_HOME; else process.env.DSH_HOME = previous.home;
    if (previous.dir === undefined) delete process.env.DSH_PROFILE_DIR; else process.env.DSH_PROFILE_DIR = previous.dir;
    if (previous.profile === undefined) delete process.env.DSH_PROFILE; else process.env.DSH_PROFILE = previous.profile;
    rmSync(dir, { recursive: true, force: true });
  }
});

/**
 * 图片必须真的送达上游 —— 用**真实 apply()** 走完整条链路。
 *
 * ## 为什么必须钉这条（2026-10-13 用户报「读不了图」）
 *
 * 插件把 dsh 给的完整 `ImageAttachmentRef` **拆成两个字段**再调 readImage：
 *
 *   attachments.readImage({ attachmentId: ref.attachmentId, mediaType: ref.mediaType })
 *
 * 而 dsh 的 `readImage(ref)` 会做**元数据核对**
 * （`@deepseek-ai/dsh-attachment-local` 的 `readImageFile`）：
 *
 *   if (metadata.mediaType !== ref.mediaType || data.byteLength !== ref.bytes
 *    || metadata.width !== ref.width || metadata.height !== ref.height)
 *     throw new AttachmentError('...', 'ATTACHMENT_CORRUPT');
 *
 * 拆完 `ref.bytes/width/height` 全是 undefined → **每次都抛** → 被
 * `.catch(() => null)` 吞掉 → adapter 把图换成文字占位
 * `[图片：无法读取该附件]` → **模型完全看不到图，且全程不报错**。
 *
 * ## 这条用例为什么能抓住回归
 *
 * 桩里的 `readImage` **严格复刻 dsh 的核对逻辑**（缺字段就抛 ATTACHMENT_CORRUPT）。
 * 所以只要有人再把 ref 拆开，用例立刻变红 —— 而不是像原来那样静默降级。
 *
 * 走**真实 apply()** 而不是复刻：resolveImage 是 apply 的闭包，import 不到，
 * 只能装配完之后从注册的 adapter 上把它驱动起来。
 */
test('图片：插件必须把完整 ref 交给 dsh，否则图会被静默降级成文字', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'wb-img-'));
  try {
    // 一张 1×1 真 PNG（dsh 会核对 bytes/width/height，所以尺寸必须自洽）
    const png = Buffer.from(
      'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==',
      'base64',
    );
    const ref = {
      attachmentId: `sha256:${'a'.repeat(64)}`,
      mediaType: 'image/png',
      bytes: png.length,
      width: 1,
      height: 1,
      name: 'dot.png',
    };

    const seenRefs = [];
    /** 严格按 dsh 契约核对；缺字段即抛（= 生产里那次失败）。 */
    const attachments = {
      imageLimits: { mediaTypes: ['image/png', 'image/jpeg', 'image/webp', 'image/gif'], maxImageBytes: 4 * 1024 * 1024 },
      async readImage(got) {
        seenRefs.push(got);
        if (got?.bytes !== png.length || got?.width !== 1 || got?.height !== 1 || got?.mediaType !== 'image/png') {
          throw Object.assign(new Error('Stored attachment metadata does not match its reference.'), { code: 'ATTACHMENT_CORRUPT' });
        }
        return { ref: got, data: new Uint8Array(png) };
      },
    };

    const { ctx } = fakeCtx();
    const baseGet = ctx.get.bind(ctx);
    ctx.get = (name) => (name === 'attachments' ? attachments : baseGet(name));
    const baseInject = ctx.inject;
    ctx.inject = (names, cb) => {
      for (const n of names) {
        const s = ctx.get(n);
        if (s) cb({ [n]: s, get: (x) => ctx.get(x) });
      }
      if (typeof baseInject === 'function') baseInject.call(ctx, names, cb);
    };

    const result = apply(ctx, {
      projectRoot: 'E:/workbuddy-to-dsh',
      autoStart: false, consoleAutoStart: false, migrateLegacy: false,
      tools: false, commands: false, routes: false, panel: false,
    });
    const adapter = result.adapter;
    assert.ok(adapter, 'apply() 应当返回 adapter');

    /*
     * 只替换 `ensureReady`，**不能**只改 `adapter.client` ——
     * `stream()` 走的是 `await this.ensureReady()`，返回的是闭包里那个 client。
     * （验证脚本第一版就栽在这儿：sent 恒为 null。）
     */
    let sent = null;
    const fakeClient = {
      chat: async (payload) => {
        sent = payload;
        return new Response(
          'data: {"choices":[{"delta":{"content":"ok"}}]}\n\n'
          + 'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":1,"completion_tokens":1,"total_tokens":2}}\n\n'
          + 'data: [DONE]\n\n',
          { status: 200, headers: { 'content-type': 'text/event-stream' } },
        );
      },
      models: async () => ({ data: [] }),
    };
    adapter.ensureReady = async () => fakeClient;

    const message = { role: 'user', content: [{ type: 'text', text: '什么颜色？' }, { type: 'image', attachment: ref }] };
    for await (const _ of adapter.stream({ model: 'deepseek-v4.1-flash', messages: [message] })) { /* 跑完 */ }

    // ① ref 必须**原样**送达（这是修复的核心）
    assert.deepEqual(
      seenRefs[0],
      ref,
      'readImage 必须收到完整 ref（含 bytes/width/height）；拆字段会触发 dsh 的 ATTACHMENT_CORRUPT',
    );

    // ② 图必须以 image_url 形态出现在发给上游的 payload 里
    const content = sent?.messages?.[0]?.content;
    assert.ok(Array.isArray(content), '带图消息的 content 应当是数组');
    const img = content.find((p) => p.type === 'image_url');
    assert.ok(img, '必须发出 image_url 块 —— 否则图被降级成了文字，模型看不到');
    assert.match(img.image_url.url, /^data:image\/png;base64,/, '必须是 data URL');
    // ③ 绝不能出现"读不出附件"的占位
    assert.ok(
      !content.some((p) => typeof p.text === 'string' && p.text.includes('无法读取该附件')),
      '不该出现"无法读取该附件"占位（说明 readImage 失败了）',
    );
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

/*
 * ── 配置同源（1.20.0）───────────────────────────────────────────────────
 *
 * 插件与控制台是**两个进程**，各自读配置。它们必须落在同一个数据目录、
 * 同一套桥参数上；否则切号会去停"另一个桥"，或者桥的开关写了不生效。
 */

/** 临时把几个环境变量摘掉，跑完恢复 —— 用例结束后不留污染。 */
function withoutEnv(keys, fn) {
  const saved = new Map(keys.map((k) => [k, process.env[k]]));
  for (const k of keys) delete process.env[k];
  try {
    return fn();
  } finally {
    for (const [k, v] of saved) {
      if (v === undefined) delete process.env[k];
      else process.env[k] = v;
    }
  }
}

test('readProjectEnv 容忍 shell 风格的 `export KEY=VALUE`（与 config.mjs 同规则）', () => {
  const dir = mkdtempSync(join(tmpdir(), 'wb-env-export-'));
  try {
    writeFileSync(join(dir, '.env'), [
      'export WORKBUDDY_PORT=8899',
      'export WORKBUDDY_SSE_NORMALIZE=0',
      'WORKBUDDY_KEEPALIVE_MS=15000',
      '',
    ].join('\n'), 'utf8');
    const parsed = readProjectEnv(dir);
    assert.equal(parsed.WORKBUDDY_PORT, '8899');
    assert.equal(parsed.WORKBUDDY_SSE_NORMALIZE, '0');
    assert.equal(parsed.WORKBUDDY_KEEPALIVE_MS, '15000');
    assert.equal(parsed['export WORKBUDDY_PORT'], undefined, '不能把 "export " 当成键名的一部分');
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('.env 的 WORKBUDDY_DATA_DIR / WORKBUDDY_STATE_FILE：state、令牌、子进程 env 三者同源', () => {
  const dir = mkdtempSync(join(tmpdir(), 'wb-env-datadir-'));
  try {
    mkdirSync(join(dir, 'bridge'), { recursive: true });
    writeFileSync(join(dir, 'bridge', 'workbuddy-bridge.mjs'), '// stub\n', 'utf8');
    const pinned = join(dir, 'auth', 'pinned.info');
    mkdirSync(join(dir, 'run'), { recursive: true });
    writeFileSync(join(dir, 'run', 'state.json'), JSON.stringify({
      authFile: pinned,
      authFileDesktopUid: 'uid-pinned',
    }), 'utf8');
    writeFileSync(join(dir, '.env'), [
      'export WORKBUDDY_DATA_DIR=./data',
      'WORKBUDDY_STATE_FILE=./run/state.json',
      'WORKBUDDY_CREDENTIAL_KEY=from-env-file',
      '',
    ].join('\n'), 'utf8');

    withoutEnv(['WORKBUDDY_DATA_DIR', 'WORKBUDDY_STATE_FILE', 'WORKBUDDY_LOCAL_TOKEN', 'WORKBUDDY_CREDENTIAL_KEY'], () => {
      const { ctx } = fakeCtx();
      const result = apply(ctx, {
        projectRoot: dir, autoStart: false, consoleAutoStart: false,
        tools: false, commands: false, routes: false, migrateLegacy: false,
      });
      const dataDir = resolve(dir, 'data');
      assert.equal(result.supervisor.env.WORKBUDDY_DATA_DIR, dataDir,
        '桥子进程必须拿到 .env 指的数据目录（绝对路径）');
      assert.equal(result.consoleSupervisor.env.WORKBUDDY_DATA_DIR, dataDir,
        '插件拉起的控制台必须用同一个数据目录');
      assert.ok(existsSync(join(dataDir, 'bridge-token')),
        '本地令牌应当生成在 .env 指的数据目录里（而不是默认的 ~/.workbuddy-bridge）');
      assert.equal(result.supervisor.authFile, pinned,
        '插件必须读 .env 指定的 .state.json，跟随控制台写下的账号钉住');
      assert.equal(result.supervisor.followAuthFile, 'auto');
      assert.equal(result.supervisor.followUid, 'uid-pinned');
      assert.equal(result.supervisor.env.WORKBUDDY_CREDENTIAL_KEY, 'from-env-file',
        '密钥要真的到达桥子进程');
      assert.equal(process.env.WORKBUDDY_CREDENTIAL_KEY, undefined,
        '密钥绝不能进 dsh 进程自身的环境');
    });
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('插件拉起的控制台继承桥配置（端口 / 令牌 / 凭据来源 / 密钥）', () => {
  const dir = mkdtempSync(join(tmpdir(), 'wb-console-env-'));
  try {
    mkdirSync(join(dir, 'bridge'), { recursive: true });
    writeFileSync(join(dir, 'bridge', 'workbuddy-bridge.mjs'), '// stub\n', 'utf8');
    writeFileSync(join(dir, '.env'), 'WORKBUDDY_CREDENTIAL_KEY=secret-from-env\n', 'utf8');
    withoutEnv(['WORKBUDDY_CREDENTIAL_KEY'], () => {
      const { ctx } = fakeCtx();
      const result = apply(ctx, {
        projectRoot: dir, bridgeHost: '127.0.0.1', bridgePort: 9911,
        localToken: 'tok-patch', credentialSource: 'desktop', credentialStore: 'file',
        credentialDir: join(dir, 'creds'),
        autoStart: false, consoleAutoStart: false,
        tools: false, commands: false, routes: false, migrateLegacy: false,
      });
      const env = result.consoleSupervisor.env;
      assert.equal(env.WORKBUDDY_HOST, '127.0.0.1');
      assert.equal(env.WORKBUDDY_PORT, '9911', '控制台必须连插件配置的桥端口');
      assert.equal(env.WORKBUDDY_LOCAL_TOKEN, 'tok-patch', '控制台必须用同一把本地令牌');
      assert.equal(env.WORKBUDDY_CREDENTIAL_SOURCE, 'desktop');
      assert.equal(env.WORKBUDDY_CREDENTIAL_STORE, 'file');
      assert.equal(env.WORKBUDDY_CREDENTIAL_DIR, join(dir, 'creds'));
      assert.equal(env.WORKBUDDY_CREDENTIAL_KEY, 'secret-from-env',
        '控制台切号后要能重起同一个桥，因此也需要密钥');
    });
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('桥的环境变量清单：.env 开关真的透传，密钥单独收集且不进普通清单', () => {
  const projectEnv = {
    WORKBUDDY_SSE_NORMALIZE: '1',
    WORKBUDDY_REPAIR_TOOL_HISTORY: '0',
    WORKBUDDY_FORWARD_REASONING: '1',
    WORKBUDDY_MEDIA_STORE: 'files',
    WORKBUDDY_CLIENT_KEYS: 'key-a,key-b',
    WORKBUDDY_CREDENTIAL_KEY: 'secret-key',
    CODEBUDDY_API_KEY: 'upstream-key',
  };
  const extra = collectBridgeExtraEnv(projectEnv, {});
  for (const key of ['WORKBUDDY_SSE_NORMALIZE', 'WORKBUDDY_REPAIR_TOOL_HISTORY', 'WORKBUDDY_FORWARD_REASONING', 'WORKBUDDY_MEDIA_STORE']) {
    assert.equal(extra[key], projectEnv[key], `${key} 必须透传给桥`);
  }
  for (const key of BRIDGE_SECRET_ENV) {
    assert.equal(extra[key], undefined, `${key} 是密钥，不能出现在普通透传清单里`);
  }
  const secret = collectBridgeSecretEnv(projectEnv, {});
  assert.equal(secret.WORKBUDDY_CREDENTIAL_KEY, 'secret-key');
  assert.equal(secret.WORKBUDDY_CLIENT_KEYS, 'key-a,key-b');
  assert.equal(secret.CODEBUDDY_API_KEY, 'upstream-key');
});

test('桥源码里读取的每个 WORKBUDDY_*/CODEBUDDY_* 都在透传 / 密钥 / 受管清单里（防再漏）', () => {
  const bridgeSrc = readFileSync(join(PLUGIN_ROOT, '..', 'bridge', 'workbuddy-bridge.mjs'), 'utf8');
  const used = new Set([...bridgeSrc.matchAll(/process\.env\.((?:WORKBUDDY|CODEBUDDY)_[A-Z0-9_]+)/g)].map((m) => m[1]));
  const passthrough = new Set(BRIDGE_ENV_PASSTHROUGH);
  const secret = new Set(BRIDGE_SECRET_ENV);
  /*
   * 插件自己**显式注入**的受管键（值由插件计算，不走 .env 透传）：
   * 端口/令牌/登录文件/凭据来源/数据目录/开关。
   */
  const managed = new Set([
    'WORKBUDDY_HOST', 'WORKBUDDY_PORT', 'WORKBUDDY_LOCAL_TOKEN',
    'WORKBUDDY_AUTH_FILE', 'WORKBUDDY_AUTH_FILE_FOLLOW', 'WORKBUDDY_AUTH_FOLLOW_UID',
    'WORKBUDDY_CREDENTIAL_SOURCE', 'WORKBUDDY_CREDENTIAL_STORE', 'WORKBUDDY_CREDENTIAL_DIR',
    'WORKBUDDY_LOGIN_REGION', 'WORKBUDDY_AUTO_CHECKIN', 'WORKBUDDY_LOG',
  ]);
  const missing = [...used].filter((k) => !passthrough.has(k) && !secret.has(k) && !managed.has(k)).sort();
  assert.deepEqual(missing, [],
    `这些桥开关用户写在 .env 里也不会到达桥：${missing.join(', ')}`);
});

test('ensure({restart:true}) 遇到在途 ensure 时，必须等它结束后真的重启（不能假成功）', async () => {
  /*
   * 真实场景：身份轮询的 ensure() 正在慢慢探测/拉起桥，用户同时点了「重启桥」。
   * 原实现 `if (pendingEnsure) return pendingEnsure` 会让重启请求直接复用那次
   * 「不重启」的结果 —— 调用方以为重启了，桥其实没动。
   */
  const dir = mkdtempSync(join(tmpdir(), 'wb-ensure-restart-'));
  const scriptPath = join(dir, 'bridge.mjs');
  writeFileSync(scriptPath, '// restart test\nexport const marker = 1;\n');
  const started = [];
  let releaseStart;
  const gate = new Promise((r) => { releaseStart = r; });
  const sup = new BridgeSupervisor({
    host: '127.0.0.1', port: 1, token: 't', projectRoot: dir, scriptPath,
    logPath: join(dir, 'bridge.log'),
  });
  let probeCalls = 0;
  sup.probe = async () => {
    probeCalls += 1;
    // 第一次（在途 ensure 进来时）桥没跑；之后都在跑
    return probeCalls === 1
      ? { state: 'stopped', error: 'not running' }
      : {
        state: 'running',
        health: { ok: true, pid: 2222, build: bridgeBuildHash(scriptPath) },
        staleBuild: false,
        bridgeBuild: bridgeBuildHash(scriptPath),
        expectedBuild: bridgeBuildHash(scriptPath),
      };
  };
  sup.start = async () => {
    started.push('start');
    await gate; // 卡住第一次拉起，制造"在途"窗口
    return { ok: true, pid: 2222 };
  };
  sup.stop = async () => { started.push('stop'); return { ok: true, stopped: true }; };
  try {
    const first = sup.ensure({ readyTimeoutMs: 1000 });
    // 等第一次真正进入 start（在途已建立）
    for (let i = 0; i < 50 && !started.includes('start'); i += 1) await new Promise((r) => setTimeout(r, 5));
    assert.ok(started.includes('start'), '第一次 ensure 应当已经走到 start');
    const restart = sup.ensure({ restart: true, readyTimeoutMs: 1000 });
    releaseStart();
    const [a, b] = await Promise.all([first, restart]);
    assert.equal(a.ok, true);
    assert.equal(b.ok, true, '重启请求必须拿到真实重启后的结果');
    assert.deepEqual(started, ['start', 'stop', 'start'], '顺序必须是：首次拉起 → 停旧 → 再拉起');
  } finally { rmSync(dir, { recursive: true, force: true }); }
});
