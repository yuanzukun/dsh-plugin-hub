# 配置

## 优先级

```
进程环境变量  >  .env 文件  >  内置默认值
```

`.env` 由 `config.mjs` 在启动时读取，**不会覆盖已存在的环境变量**（便于临时用环境变量覆盖）。

```cmd
copy .env.example .env
```

`.env` 已在 `.gitignore` 中，但仍不建议在此填写任何真实凭据——本项目不需要。

数值 / 枚举 / 开关项写错（如端口写成 `879O`、结果数写 `50`）**不会阻止启动**，
而是静默回退默认值。诊断页的「配置取值」会列出哪一项没被采用、实际按什么运行；
命令行等价入口是 `node tools\doctor.mjs`。

---

## 全部变量

### 桥

| 变量 | 默认值 | 说明 |
|---|---|---|
| `WORKBUDDY_HOST` | `127.0.0.1` | 桥绑定地址。**不要改成 `0.0.0.0`** |
| `WORKBUDDY_PORT` | `8790` | 桥监听端口 |
| `WORKBUDDY_DATA_DIR` | `%USERPROFILE%\.workbuddy-bridge` | 运行期数据目录（state / usage / 本地令牌 / 媒体任务）。**不要放安装目录**：换 tgz / 重装会丢账号钉住、用量和令牌，旧客户端随之 401 |
| `WORKBUDDY_ACCOUNT_ARCHIVE_DIR` | `<数据目录>\account-archive` | 账号存档目录：每份能解开的桌面登录文件的**原始密文副本**，按账号（uid / uin）分目录。客户端「换号」是**原地覆盖**登录文件，只有存档能在覆盖前留一份 —— 见 `docs/TROUBLESHOOTING.md` 的「客户端账号不见了」 |
| `WORKBUDDY_ACCOUNT_ARCHIVE` | 启用 | `0` = 完全不写账号存档。不想保留第二份登录态副本时用它。登录目录位于系统临时目录时存档默认关闭（那是测试夹具） |
| `WORKBUDDY_LOCAL_TOKEN` | 首次启动随机生成 | 本地回环令牌。仅用于阻止同机其它程序误用该端口，**不是**上游凭据。留空即自动生成并落到 `<WORKBUDDY_DATA_DIR>/bridge-token`（控制台、插件与桥共用同一文件，保证一致）；需与 dsh 的 `WORKBUDDY_BRIDGE_KEY` 值一致 |
| `WORKBUDDY_TIMEOUT_MS` | `0` | 上游**总**超时（毫秒）。`0` = 不限——长回答需要保持 0；卡死由下面的首字节/排队超时兜底 |
| `WORKBUDDY_FIRST_BYTE_TIMEOUT_MS` | `120000` | 连接建立后多久没收到第一块响应体就放弃。只抓“上游不说话”，不限制长回答总时长；`0` = 关闭 |
| `WORKBUDDY_QUEUE_TIMEOUT_MS` | `120000` | 连接池被长流占满时的排队超时；`0` = 关闭 |
| `WORKBUDDY_MAX_SOCKETS` | `32` | 上游连接池上限。多会话 / 子 agent / 多客户端并发时调大 |
| `WORKBUDDY_11128_FALLBACK` | `1` | 上游 11128（来源/模板校验）时是否自动降级 system 重试。`0` = 关闭，直接把错误交给客户端 |
| `WORKBUDDY_SANITIZE_ASSISTANT_HISTORY` | `1` | assistant 历史里的 dsh 身份句也做精确中和。同类项目实测：assistant 历史里只要出现过同一句，之后每轮都会 11128；只改两句精确模板，不动普通正文 |
| `WORKBUDDY_REPAIR_TOOL_HISTORY` | `1` | 工具调用历史自愈：重复/空 `tool_call_id` 改名并同步 result、缺 result 合成 `is_error` 结果、孤儿 result 丢弃、空 assistant 剔除。`0` = 关闭 |
| `WORKBUDDY_STRIP_ASSISTANT_REASONING` | `1` | 出站前剥离 assistant 历史里的 `reasoning_content` / `reasoning`。上游对 assistant 带 reasoning 会回 400 code 11151；只动 assistant，user/tool 不变。`0` = 关闭 |
| `WORKBUDDY_CONVERSATION_ID_BODY` | `1` | 上游按 body 的 `conversation_id` 分前缀缓存槽。客户端没带时，桥用「首条 system + 首条 user + 模型」的指纹补稳定值；若上游把它当未知字段拒绝，会自动去掉并关闭本进程注入 |
| `WORKBUDDY_SSE_NORMALIZE` | `1` | chat 流式帧归一：补齐缺失的 `choices[0].delta`、把逐字符 `reasoning_content` 聚合成一段、`[DONE]` 只发一次。`0` = 原始字节透传（用于 A/B 或客户端特殊兼容） |
| `WORKBUDDY_SKIP_MODEL_PREFLIGHT` | 未设 | `1` = 跳过本地模型目录预校验，未知模型也转发给上游（目录漏列可用模型时用）。默认未知模型在本地回 **404**（OpenAI/Anthropic 客户端据此切模型） |
| 未知模型名 | 明确报 404 | Anthropic / Responses 路径遇到**目录里没有**的模型名时，默认**明确报 404**（不再悄悄换成默认模型 —— 那会让"以为在用 A、实际在用 B"）。客户端原生别名（`claude-*` / `gpt-*` / `codex-*`）照旧映射到默认/小快模型。逃生门仍是 `WORKBUDDY_SKIP_MODEL_PREFLIGHT=1`（放行未知 id 给上游） |
| `WORKBUDDY_MODELS_DEFAULT` | `curated` | `GET /v1/models`（**不带参数**，即客户端「获取模型列表」按钮打的那个地址）默认返回哪些模型：`curated` = 3 个精选（原行为）、`all` = 全量目录、正整数 N = 精选在前补到 N 个。面板「可用模型 → 客户端一键拉取给」保存的值**优先于**本变量且立即生效；请求级 `?limit=N` 再覆盖两者。`?all=1` 始终全量，不受影响 |
| `WORKBUDDY_SHAPE` | 未设 | `1` = 额外打印请求形状（角色计数、工具名、客户端头；仍不含对话内容），排查 11128 字段用 |
| `WORKBUDDY_LOG` | `1` | `1` 时打印每次请求的模型、消息数、工具数（**不含对话内容**） |
| `WORKBUDDY_SEARCH_BASE` | 按账号区域自动选择 | WorkBuddy 原生搜索网关（`/agenttool/v1/search`）。国际版默认 `https://www.workbuddy.ai`，国内版默认 `https://www.workbuddy.cn`；仅自建网关/A/B 时覆盖 |
| `WORKBUDDY_SEARCH_VERSION` | 桌面/插件版本 | 搜索端 `X-IDE-Version` / UA 声明的 WorkBuddy 版本 |
| `WORKBUDDY_SEARCH_TIMEOUT_MS` | `20000` | 单次网页搜索总超时（毫秒，含 401 刷新/5xx 重试） |
| `WORKBUDDY_SEARCH_MAX_RESULTS` | `8` | 原生搜索分支返回的结果上限（1-10）。与 Anthropic `max_uses`（服务端搜索执行次数）无关 |
| `WORKBUDDY_ANTHROPIC_MODEL` | `glm-5.3` | Claude Code 的模型名映射到哪个上游真实模型。可填任意 `/v1/models` 里的 id |
| `WORKBUDDY_ANTHROPIC_FAST_MODEL` | `glm-5.3-flash` | Claude Code 后台任务（标题生成、文件摘要）用的小快模型 |
| `WORKBUDDY_RESPONSES_MODEL` | `glm-5.3` | Codex（`/v1/responses`）的模型名映射。Codex 发的是它 config.toml 里的 `model`（如 `gpt-5.1-codex`），上游没有这些 id，必须映射到真实模型 |
| `WORKBUDDY_RESPONSES_FAST_MODEL` | `glm-5.3-flash` | Codex 的后台小快模型。**只有名字里带 mini / nano / flash 这类字样才会用到它** —— `gpt-5.1-codex` 是主力模型，刻意不匹配 "codex"，否则会把主任务降级 |
| `WORKBUDDY_FORWARD_REASONING` | `0` | `1` 时把上游的思维链（`reasoning_content`）按 `type: "reasoning"` 的 output item 转给 Codex。**默认关**：Codex 要求 reasoning 的 delta 到达时已有 active output item，这套事件顺序需要一次真机对照实验才能定论，所以默认保持"丢弃 + 记一条日志"。试法与判断标准见 [`TROUBLESHOOTING.md`](TROUBLESHOOTING.md) 里「Codex 里看不到思考过程」 |
| `WORKBUDDY_5XX_RETRY` | `1` | 上游 5xx（500/502/503/504）在桥侧重试几次。实测这类短时中断多数在原样重发后恢复；`0` = 关闭 |
| `WORKBUDDY_5XX_RETRY_DELAY_MS` | `500` | 5xx 重试前的等待（毫秒，按第几次线性递增）。测试会压到毫秒级 |

### 控制台

| 变量 | 默认值 | 说明 |
|---|---|---|
| `DASHBOARD_PORT` | `8792` | 控制台端口 |
| `DASHBOARD_AUTO_START_BRIDGE` | `1` | 控制台启动时自动拉起桥（"双击即用"的关键）。设为 `0` 则改为手动点「启动桥服务」 |
| `DASHBOARD_IDLE_EXIT_MS` | 插件拉起时 `600000`；手动启动 `0` | 控制台闲置多久自动退出（毫秒，`0` = 不退出）。计活动只看页面/数据请求：插件探活（`/`、`/api/version`）不算，页面打开期间每 2 秒的身份轮询会保活。闲置退出后，面板取数或 `workbuddy console` 会自动拉起 |
| `WORKBUDDY_ACCOUNT_FAILOVER_AFTER` | `0`（关闭） | Web 控制台的自动切号：开启后，账号用量上限（上游 `6004` / `14018`）**一次就切**（重置在数小时后，等 N 次没有意义）；其它瞬时 429 仍需同一账号同一模型在统计窗口内达到 N 次。按「账号」页顺序切到下一个可用桌面账号（写 `.state.json` 并重启桥）。只对桌面来源生效；同一账号的多份登录快照**不算**下一个账号。会切换钱包，默认关闭。dsh 插件用户请改用插件配置 `accountFailoverAfter`，不要两边同时开 |
| `WORKBUDDY_RATE_LIMIT_WINDOW_MS` | `600000` | 429 统计的**滑动窗口**（毫秒，最小 1000）。计数按时间戳过滤：窗口外的旧 429 会自动过期，不会无限累计。一般不用改；自动化测试会压到秒级 |
| `WORKBUDDY_QUOTA_TTL_MS` | `60000` | 积分余额的缓存时长。总览每 20 秒轮询一次，而积分要打上游计费网关；调小可更快反映余额变化（如签到后），代价是更频繁的上游查询 |
| `WORKBUDDY_QUOTA_SNAPSHOT_MS` | `3600000` | 余额快照采集间隔（毫秒）。用量页「账实差额」用首尾快照对比本地账本；`0` = 每次读到余额都记一条（只建议测试用） |
| `WORKBUDDY_IMAGE_SYNC_WAIT_S` | `90` | OpenAI Images 兼容端点提交后最多等待秒数；超时回 202 + job id |
| `WORKBUDDY_IMAGE_B64_MAX_BYTES` | `20971520` | `response_format=b64_json` 时单张产物上限（字节），超过回 502 |
| `WORKBUDDY_MEDIA_IDEMPOTENCY_MS` | `600000` | 媒体提交幂等窗口（毫秒）。带 `Idempotency-Key` 的重复请求只提交一次；`0` = 关闭 |
| `WORKBUDDY_MEDIA_STORE` | `1` | `1` = 媒体任务元数据落盘到 `<WORKBUDDY_DATA_DIR>/media-tasks.json`（同步任务重启可查）；`0` = 纯内存 |
| `WORKBUDDY_CATALOG_RETRY_MS` | `30000` | 模型目录抓取**硬失败**后的负缓存时长（毫秒）。冷目录时每个 `/v1/models` 原本都会重打两个上游端点（各 8 秒超时），上游故障期间会把客户端拖到超时；失败后先安静这么久再试。手动 `refresh=1` 与换号会无视它 |

> 插件侧默认 `consoleAutoStart: false`（控制台不随 dsh 启动，面板第一次取数时按需拉起）
> 与 `consoleIdleExitMs: 600000`（闲置 10 分钟退出）。插件拉起时会把后者注入成
> `DASHBOARD_IDLE_EXIT_MS`（**包括显式 0**，避免被 `.env` 反向覆盖）；`.env` 里的
> 同名变量会被插件当作默认值读入，但 patch 里显式配置优先。

### WorkBuddy 客户端

| 变量 | 默认值 | 说明 |
|---|---|---|
| `WORKBUDDY_APP_EXECUTABLE` | 自动探测 | 客户端可执行文件。探测顺序见下 |
| `WORKBUDDY_IDENTITY` | `auto` | 出站客户端身份。默认按本机桌面端自动探测版本并伪装官方桌面/CLI 形状（目录用桌面 App UA、聊天用内置 CLI UA）；`legacy` = 退回旧的 VSCode 形状（逃生门） |
| `WORKBUDDY_APP_VERSION` / `WORKBUDDY_CLI_VERSION` | 自动探测 | 手动覆盖桌面端 / 内置 CLI 版本；探测不到、或要做身份 A/B 时用 |
| `WORKBUDDY_AUTH_FILE` | 自动定位 | 登录文件绝对路径。**多账号时务必显式指定** |
| `WORKBUDDY_AUTH_DIR` | 平台默认 | 登录文件所在目录，仅在目录被移动时需要 |
| `WORKBUDDY_CONTEXT_WINDOW` | 官方默认（多为 300000） | dsh 的上下文容量按模型解析。**推荐在插件「模型 → 详情 → 上下文窗口（Token）」里按模型单独调**（输入/输出改完自动保存；保存后下一轮请求按新预算解析，用量分母可能显示上一轮，发一条消息刷新；切换模型用该模型自己的预算；留空 = 自动，优先于本变量）；本变量作为面板选择「自动」时的桥端默认值，也用于不使用面板的其它 OpenAI 客户端。可钉到 `600000` / `1000000`（不超过模型上限）；不设置则用 `/v3/config` 的 `contextWindow.defaultLength` |

### 插件登录（第二条凭据来源）

| 变量 | 默认值 | 说明 |
|---|---|---|
| `WORKBUDDY_CREDENTIAL_SOURCE` | 不设置（桥按 `auto`） | `auto` / `desktop` / `plugin` / `api-key`。`auto` 是**软默认**：允许面板/控制台切换，登录成功后照常切到插件；只有显式写 `desktop` / `plugin` / `api-key` 才**锁定**来源（UI 切换会被拒绝）。`auto` 的顺序 = API key → 桌面端 → 插件（仅**本地**不可用时回退）；上游 401 不会中途换号 |
| `WORKBUDDY_CREDENTIAL_STORE` | Windows `dpapi`，其他平台 `file` | `dpapi` = DPAPI(CurrentUser) 保护 `store.key` + AES-256-GCM 凭据；`file` = 文件密钥 + AES-256-GCM 落盘（桥重启 / 更新插件不用重登）；`memory` = 不落盘。密钥不可用时会退回 memory，**绝不写明文** |
| `WORKBUDDY_CREDENTIAL_KEY` | 不设置 | 仅 `file` 模式：字段密钥。推荐 Docker/NAS 用（不落盘）。支持 64 位 hex、base64 的 32 字节密钥，或任意口令（scrypt 派生）。不设置时自动生成 `credentials/store.key`（0600）；**更换密钥后旧凭据无法解密，需要重新登录** |

> **Docker / NAS 持久化**：把 `WORKBUDDY_CREDENTIAL_DIR` 指向持久卷（如 `/data/credentials`），
> 并设置一个固定的 `WORKBUDDY_CREDENTIAL_KEY`（生成：
> `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`）。
> 这样重启容器 / 更新插件都不需要重新登录；密钥不要和凭据放在同一个公开备份里，
> 至少按敏感文件保管。
| `WORKBUDDY_CREDENTIAL_DIR` | `%USERPROFILE%\.workbuddy-bridge\credentials` | 凭据目录（`store.key` / `*.cred` / `active.json` / `source.json`） |
| `WORKBUDDY_LOGIN_REGION` | 自动建议 | 设备码登录默认区域：`cn` / `global`。不设置时桥按「现有插件账号 → 桌面账号域名（`.ai` → global）→ cn」给出建议，面板/控制台随环境预选；用户手动选过之后不再覆盖 |
| `WORKBUDDY_LOGIN_UA` | `CLI/2.63.2 CodeBuddy/2.63.2` | 登录端点期望的 User-Agent；上游漂移时的逃生门 |
| `WORKBUDDY_LOGIN_BASE` / `WORKBUDDY_LOGIN_ORIGIN` | 按区域 | 仅测试 / 应急覆盖登录端点 |
| `WORKBUDDY_CREDENTIAL_FAILOVER` | `same-account` | 鉴权失败（401/403）时另一条凭据是否接管：`same-account` = 只在桌面端与插件端 **uid 相同**时接管（钱包不变）；`any` = 任意账号接管（会切换账号/钱包，显式 opt-in）；`off` = 不接管 |
| `WORKBUDDY_PLUGIN_IDENTITY` | `workbuddy` | 插件来源的 chat 身份：`workbuddy`（WorkBuddy 形状 UA / `X-IDE-*` / Origin，参考实现实测）/ `vscode`（退回旧头）。桌面来源不受影响 |
| `WORKBUDDY_PLUGIN_APP_VERSION_CN` / `_GLOBAL` | `5.5.6` / `5.5.2` | 插件身份声明的桌面版本（进 UA 与 `X-IDE-Version`）；非法值自动回退 |

> 未用环境变量锁定来源时，面板/控制台里的选择会持久化到 `source.json`；登录成功后
> 自动切到 `plugin` 并在界面明示，可随时切回 `desktop` / `auto`。

### 一键接入

「客户端接入」面板的「一键接入」与 `npm run connect` 会**写**客户端的配置文件。
这三个路径都有默认值（`~/.codex/config.toml`、`~/.claude/settings.json`、
`~/.config/opencode/opencode.json`），只在客户端装到非常规位置时才需要覆盖。
测试也是靠它们把目标挪到临时目录，**不会碰真实配置**。

**它对你的文件做了什么、不做什么**（这几条是踩过坑之后定下来的）：

| 情况 | 行为 |
|---|---|
| 别人的键 / 节 / 注释 / 顺序 | **一字不动**（TOML 走行级改写；`cc-switch` 那种 provider 节实测未动） |
| 带注释的 JSONC（opencode 官方支持） | **能接**：先试严格 JSON，再试剥注释的版本。注释会在重写后消失，界面提前提示"会重新排版" |
| 尾逗号 | **如实报错并停手**（不在 JSONC 规范里，不猜 —— 猜错就是改坏文件） |
| 字符串里的 `//`（如 URL） | 不会被当成注释（逐字符扫描 + 转义处理） |
| BOM / CRLF / 缩进风格 | 写入时会被规范化为 2 空格 + `\n`（JSON）或原样保留（TOML）；**BOM 保留** |
| 空文件 | 当成"还没有配置"，**能一键接上**（不是"格式不对"） |
| 中间层是数组 / null（如 `"env": []`） | **不覆盖你的数据**，并把没写进去的键**列出来**告诉你怎么修（把它改成对象后重试） |
| 语法确实坏了 | 报错并**绝不动文件** |

撤销的承诺是「还原到接入之前」：逐键还原**首次写入时记录的原值**（而不是拿备份整份盖回去
—— 那会连带丢掉用户在写入之后自己做的改动），BOM 一并还原，Codex 的模型目录文件
要么按备份还原、要么（我们建的）删掉。

**多模型（每个客户端可接多个，其中一个作主模型）各写在哪：**

| 客户端 | 写什么 | 怎么切换 |
|---|---|---|
| opencode | `provider.workbuddy.models` 里声明**勾选的每一个**；`model` 指向主模型 | TUI 里直接选 |
| Claude Code | `modelPicker.options` 列出勾选的模型（**只有一个也写**，`replaceBuiltInOptions: true`）+ `env.ANTHROPIC_MODEL` 指主模型 + `env.CLAUDE_CODE_MAX_CONTEXT_TOKENS`（上下文上限；多模型取所选模型的最小值；**目录冷启动、上限未知时不写**）+ `env.ANTHROPIC_DEFAULT_HAIKU_MODEL`（后台任务模型） | `/model` 选择器 |
| Codex | `model` 指主模型；勾选的模型写进 `model_catalog_json` 指向的**目录文件** | `-m <模型>` 或 Codex 的模型选择器 |

> Codex 的那份目录是**第二个文件**：默认写在 `config.toml` 同目录下的
> `workbuddy-model-catalog.json`。它**合并**而不是覆盖 —— 如果 `model_catalog_json`
> 已经指向别人的目录（本机 cc-switch 就是），原来那些条目一条不动地保留，
> 只补桥这边缺的。撤销时配置文件里的键还原、我们建的目录文件删掉、
> 改过的目录文件按备份还原。
>
> 目录条目是**克隆**现成模板再改 slug/名字/上下文（模板取自现有目录，或 Codex 自己
> 抓的 `models_cache.json`）—— 条目的字段有三十来个，少一个 Codex 可能整份解析失败。
> 两处模板都没有时**不生成目录**，界面与命令行都会如实说明「只能接一个模型」，
> 不硬编造条目。

**换一台电脑也能用**：目标路径**不写死**，而是按各家官方的约定现算。
别人的机器上如果改过这些（很常见 —— 同步盘、多账号、公司策略都会改），我们跟着走：

| 客户端 | 认哪个变量 | 依据 |
|---|---|---|
| Codex | `CODEX_HOME` | Codex 官方约定（本机用 `codex doctor` 实测：设了它，它自述的 config 路径就变成 `<CODEX_HOME>/config.toml`） |
| Claude Code | `CLAUDE_CONFIG_DIR` | [官方文档](https://code.claude.com/docs/en/settings)：*To keep the home-directory files somewhere else, set `CLAUDE_CONFIG_DIR`* |
| opencode | `XDG_CONFIG_HOME` | 全局层固定在 `~/.config/opencode/`（[官方文档](https://opencode.ai/docs/config/)，Windows 也走 `%USERPROFILE%\.config\`）。`OPENCODE_CONFIG` 是**另一层**（指定别的配置文件、优先级更高），不是同一件事，故不冒充 |

> 路径是怎么定下来的会**显示出来**（面板上标「按客户端的设置写入：CODEX_HOME」、
> 命令行标「路径来源: 跟随客户端的 CODEX_HOME」）—— 只给一个最终路径，
> 用户没法确认"它认没认对地方"，而认错的后果是把配置写进客户端根本不读的位置。

| 变量 | 默认值 | 说明 |
|---|---|---|
| `WORKBUDDY_CODEX_CONFIG` | `$CODEX_HOME/config.toml`，未设则 `~/.codex/config.toml` | Codex 的配置文件路径（目录文件写在它旁边）。**优先级高于** `CODEX_HOME` |
| `WORKBUDDY_CLAUDE_SETTINGS` | `$CLAUDE_CONFIG_DIR/settings.json`，未设则 `~/.claude/settings.json` | Claude Code 的设置文件路径。**优先级高于** `CLAUDE_CONFIG_DIR` |
| `WORKBUDDY_OPENCODE_CONFIG` | `$XDG_CONFIG_HOME/opencode/opencode.json`，未设则 `~/.config/opencode/opencode.json` | opencode 的**全局**配置路径 |
| `WORKBUDDY_CONNECT_BACKUP` | `<仓库>\.backup\client-configs\` | 写入前的备份与撤销记录放哪。仓库只读（如 vendor 分发）时退回 `~/.workbuddy-bridge\client-configs\` |

`WORKBUDDY_*` 三个是**本产品自己的**覆盖（测试、运维、非常规安装用），
优先级最高；没设时才看客户端自己的变量。

### 路径类配置都是「读取那一刻生效」

`DSH_HOME`、`CODEX_HOME`、`CLAUDE_CONFIG_DIR`、`XDG_CONFIG_HOME` 以及本产品的
`WORKBUDDY_*` 覆盖变量，全部**在读到它们的那一刻求值**，不是进程启动时就定死。
所以这几种写法都成立：

```js
import { config } from './config.mjs';
process.env.DSH_HOME = 'X:\\my-dsh';     // 之后再设，一样生效
config.dsh.settingsPath;                  // → X:\my-dsh\settings.yaml
```

> 为什么值得一提：`config.dsh` 的四个路径是 getter（不是普通属性）。
> 早期版本在 `import` 那一刻就把它们算成常量了，于是"先 import 再设 `DSH_HOME`"
> 这种最自然的写法会**静默失效** —— 用户以为 dsh 配置改到了别处，实际还在 `~/.dsh`，
> 而写 dsh 配置是会**动用户文件**的（往里加模型路由）。有单测钉住这条。
>
> 空白值（`DSH_HOME="   "`）不会被当成路径，会回落家目录 —— 否则会拼出一个
> 名字是空格的目录。

**备份目录**（`WORKBUDDY_CONNECT_BACKUP`，默认 `<仓库>\.backup\client-configs\`）
跟着**代码位置**走，不跟启动目录走 —— 换个启动方式（快捷方式、计划任务、
从别处 `node dashboard/server.mjs`）不会让上次的备份与撤销记录"消失"。

**可执行文件探测顺序**（客户端重装到任意目录后都会自动重新定位，无需配置）：

1. `WORKBUDDY_APP_EXECUTABLE`（显式覆盖，最高优先）
2. 默认安装位置：`%LOCALAPPDATA%\Programs`、`%ProgramFiles%`、`%ProgramFiles(x86)%` 下的
   `WorkBuddy` / `WorkBuddy AI` / `WorkBuddyAI` / `CodeBuddy` 目录（exe 名兼容
   `WorkBuddy.exe` / `WorkBuddyAI.exe` / `CodeBuddy.exe`），以及 `E:\App\WorkBuddy\` 等历史自定义位置
3. 磁盘浅扫描：每个盘符下常见父目录（`App` / `Program Files` / `Tencent` / `Software` / `Tools` 等）
   中名字含 `workbuddy` / `codebuddy` 的目录（深度最多 3 层）——覆盖
   `E:\App\WorkbuddyInternational\`、`C:\Program Files\Tencent\WorkBuddy\` 这类自定义安装
4. **系统信号兜底**（仅当前三层全部落空时执行，PowerShell 冷启动数秒）：
   - 运行中进程的镜像路径（客户端在用时即安装位置）；
   - 注册表安装记录：卸载项（`DisplayIcon` / `UninstallString`）、深链协议
     （`workbuddy://…`）、App Paths —— 官方安装器必写，**装到任何目录都有**。
5. macOS：`/Applications` 与 `~/Applications` 下的 `WorkBuddy.app` / `WorkBuddy AI.app`，
   以及名字含 `workbuddy` / `codebuddy` 的任意 `.app`（用户改过包名也能找到）。
   可执行文件名以 `Contents/Info.plist` 的 `CFBundleExecutable` 为准（腾讯 WorkBuddy
   5.8.x 是未改名的 `Electron`），读不出时兜底 `Electron`；Linux：`/opt/WorkBuddy/workbuddy`

前两层零成本；扫描只在前面落空时执行一次（带目录预算与缓存）；系统信号兜底最贵
（且失败后 2 分钟内不重试）。exe 被卸载或移动后会自动重探（重探有 5 秒防抖，避免在
"客户端正在重装"的窗口期内反复扫描）。桥的启动日志里 `client exe` 一行显示实际
使用的可执行文件。

> 机器上同时装着多个客户端（如国内版 + 国际版）时，以**登录文件里信封的 keyId**
> 为准挑选能解开它的那个 build —— 而不是盲取第一个找到的 exe。

**登录文件定位规则**：先找两个客户端自己的**活动**文件
（`workbuddy-desktop.info` = 国内版、`workbuddy-desktop-ai.info` = 国际版），
存在多个时在**启动时**取最近写入的那个（当前在用的客户端）；两个都没有时才取
目录下第一个 `.info`（登出留下的 `workbuddy-desktop.<时间>.info` 快照永远不优先）。
运行中不跟随另一个客户端的文件来回切（双方后台刷新会让 mtime 互相追超）；
同一文件内换号仍会实时跟随。auth 目录按平台为：

| 平台 | 路径 |
|---|---|
| Windows | `%LOCALAPPDATA%\CodeBuddyExtension\Data\Public\auth` |
| macOS | `~/Library/Application Support/CodeBuddyExtension/Data/Public/auth` |
| Linux | `~/.local/share/CodeBuddyExtension/Data/Public/auth` |

> ⚠️ 该目录下可能同时存在多个账号快照。仅按目录顺序取第一个会**选错账号**，
> 所以活动文件按 mtime 选、快照只在没有活动文件时兜底。
> 面板里显式切换账号仍以 `.state.json` 的钉住快照优先，并在客户端换号时自动跟随。

### DeepSeek Harness

| 变量 | 默认值 | 说明 |
|---|---|---|
| `DSH_HOME` | `%USERPROFILE%\.dsh` | dsh 配置根目录 |
| `DSH_RUNTIME` | 自动探测 | dsh 运行时。优先 DSH Desktop 的 bundled 运行时（`<安装目录>\resources\runtime`），回退到独立安装 `%USERPROFILE%\DeepSeek-Harness\runtime` |

> **本机可能同时存在多套 dsh，版本不同**（实测 0.2.0-rc.2 与 0.1.0-rc.6）。
> 采用哪一套会直接改变结论，因此自动探测优先取 DSH Desktop 的那一套，
> 并由 `tools/doctor.mjs` 打印出来。详见
> [`TROUBLESHOOTING.md`](TROUBLESHOOTING.md#本机有两套-dsh-运行时)。

---

## 派生值

`config.mjs` 由上述变量派生出，供代码引用：

```js
config.bridge.url             // http://127.0.0.1:8790
config.bridge.chatUrl         // .../v1/chat/completions
config.bridge.modelsUrl       // .../v1/models
config.bridge.healthUrl       // .../health
config.dashboard.url          // http://127.0.0.1:8792
config.workbuddy.exe
config.workbuddy.authFile
config.dsh.settingsPath       // <DSH_HOME>/settings.yaml
config.dsh.credentialsPath    // <DSH_HOME>/.credentials.yaml
config.dsh.profileDir         // <DSH_HOME>/profiles/desktop
config.paths.bridgeScript
config.paths.bridgeLog
```

---

## 改端口

控制台通过 `config.bridgeEnv()` 把配置注入桥进程，因此**只需改一处**：

```ini
WORKBUDDY_PORT=18890
DASHBOARD_PORT=18892
```

- 桥、控制台、诊断都会跟着变
- dsh 侧需同步：`settings.yaml` 里的 `baseURL` 会在下次「保存到 dsh 设置」时自动更新，
  或手工改这一行

**注意**：`WORKBUDDY_LOCAL_TOKEN` 改动后，dsh 的 `.credentials.yaml` 里的
`WORKBUDDY_BRIDGE_KEY` 也必须同步改成同样的值。

---

## 查看当前生效配置

```cmd
node tools\doctor.mjs
```

输出顶部会打印配置根、桥地址、控制台地址、登录文件与客户端路径。
