# dsh-roblox-studio

DeepSeek Harness 原生插件：为 `mcp-roblox-studio`（`@deepseek-ai/dsh-mcp-client` 桥接的 Roblox Studio MCP）补充一个人机界面。

## 功能

- **Settings → Roblox Studio** 设置分区：
  - 实时列出当前通过 Roblox Studio MCP 连接的 Studio 实例（`list_roblox_studios`，独立 MCP stdio 连接，不影响 Agent 的工具连接）
  - 一键**激活**某个实例、取消激活
  - 显示 MCP 桥状态、实例掉线（stale）标记
- 激活选择通过 `ctx.systemPrompt.context` 注入 Agent 运行时上下文：Agent 会被明确告知在所有 `mcp__roblox__*` 工具调用中使用该 `studio_id`，其他已连接实例不会被误操作；选择失效时会收到告警。
- 选择持久化在 Settings 提供方（`roblox-studio` 命名空间，通常为 `~/.dsh/settings.yaml`）。

> **关于脚本同步**：磁盘 ↔ Studio 的实时双向脚本同步请使用 Roblox Studio **官方 Script Sync**（资源管理器中右键服务或文件夹 → “Sync to…” 选择本地目录，重开工程自动恢复）。它没有 MCP 编程接口，无法由插件代为启动，因此本插件不重复实现单向快照式同步，而是围绕它做增值：

- **官方同步状态面板**：设置页通过 `InstanceFileSyncService`（MCP `execute_luau` 可达）实时显示激活实例上处于官方同步的服务/文件夹（同步根）、出错树与查询失败原因，45s 缓存 + 定时/事件刷新。
- **Agent 文件优先引导**：设置「本地同步目录」后，当激活实例存在同步根时，运行时上下文会告知 Agent——同步范围内的脚本优先直接编辑本地 Rojo 风格文件（`*.server/.client/.local/.legacy.luau`、`文件夹/init.*.luau`），磁盘变更由官方同步实时回写 Studio，比走 MCP 写入更快也更不易冲突。

## 安装

```sh
git clone https://gitee.com/nidiehhh/dsh-roblox-studio.git
dsh plugin --profile web add /path/to/dsh-roblox-studio
```

安装后重启 Web profile（宿主在进程启动时发现浏览器 bundle）。打开 GUI → 设置 → **Roblox Studio**。

## 深浅主题

界面全部走 DSH 设计系统 alias（`--dsw-alias-*`），跟随 `body[data-ds-dark-theme]` 自动切换深/浅色。

## 配置（Settings / profile patch）

| 字段 | 默认 | 说明 |
|---|---|---|
| `serverName` | `roblox` | 对应 mcp-client 条目的 serverName，用于工具名提示 |
| `launcherCommand` | 自动探测 | StudioMCP 启动命令；空 = `~/.dsh/roblox-studio-mcp.cmd` → 最新 `StudioMCP.exe` |
| `activeStudioId` / `activeStudioLabel` | 空 | 由设置界面维护 |
| `refreshTimeoutMs` | 20000 | 每次 MCP 请求超时 |
| `scriptSyncRoot` | 空 | 官方 Script Sync 的本地目录；设置后 Agent 会优先直接编辑同步范围内的本地文件 |

## 路线

- `/_dsh/roblox-studio/settings`：GET 快照（含 `scriptSync` 官方同步状态视图）；POST `{action:'refresh'}` / `{action:'activate', studioId, expectedRevision}` / `{action:'clear', expectedRevision}` / `{action:'saveScriptSyncRoot', scriptSyncRoot, expectedRevision}`（同源校验）。
