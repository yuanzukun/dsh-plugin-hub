// Prerequisite (outside a DSH host, peer deps are not resolvable from this checkout):
//   mkdir node_modules; mklink /J node_modules\@deepseek-ai <npx-cache>\node_modules\@deepseek-ai
// Full-chain runtime test with mocked cordis services and a REAL StudioBridge:
// settings route actions, activation, and runtime-context rendering.
import { Readable } from 'node:stream'
import { SettingsConflictError } from '@deepseek-ai/dsh-settings'
import { apply, ROBLOX_STUDIO_SETTINGS_NAMESPACE } from '../lib/index.js'
import { RobloxStudioWebBackend } from '../lib/web.js'
import { StudioBridge } from '../lib/studio-bridge.js'
import { ScriptSyncStatusCache, renderScriptSyncContext } from '../lib/script-sync-status.js'

const stored = {
  revision: 3,
  value: {
    serverName: 'roblox',
    launcherCommand: '',
    activeStudioId: '',
    activeStudioLabel: '',
    refreshTimeoutMs: 20000,
  },
}

const registered = { ns: undefined }
let contextSpec
const injected = []

const settingsService = {
  writable: true,
  register: (ns, schema) => {
    registered.ns = ns
    stored.value = schema(stored.value) // resolve through the real schemastery Config
    return { get: () => stored.value, watch: () => () => {} }
  },
  describe: () => [{ ns: ROBLOX_STUDIO_SETTINGS_NAMESPACE, value: stored.value, revision: stored.revision }],
  update: async (ns, patch, expectedRevision) => {
    if (expectedRevision !== undefined && expectedRevision !== stored.revision) {
      throw new SettingsConflictError(ns, expectedRevision, stored.revision)
    }
    Object.assign(stored.value, patch)
    stored.revision += 1
  },
}

const ctx = {
  settings: settingsService,
  systemPrompt: { context: (spec) => { contextSpec = spec; return () => {} } },
  logger: { info: () => {}, warn: (...args) => console.log('[warn]', ...args) },
  inject: (names, fn) => { injected.push(names) },
}

const dispose = apply(ctx, {})
console.log('[apply] ok; ns =', registered.ns, '; inject calls =', JSON.stringify(injected))

if (contextSpec.text().length !== 0) throw new Error('context should be empty with no active studio')
console.log('[context empty] ok')

function fakeRes() {
  const out = { statusCode: 0, headers: {}, body: '' }
  return {
    setHeader(k, v) { out.headers[k.toLowerCase()] = v },
    writeHead(status) { out.statusCode = status },
    end(chunk) { if (chunk) out.body += chunk.toString('utf8'); out.done = true },
    out,
  }
}

function fakeReq(method, body, headers = {}) {
  const stream = Readable.from(body === undefined ? [] : [Buffer.from(JSON.stringify(body))])
  stream.method = method
  stream.headers = Object.assign({ 'content-type': 'application/json', host: '127.0.0.1:3080', origin: 'http://127.0.0.1:3080' }, headers)
  return stream
}

const bridge = new StudioBridge({ timeoutMs: 30000 })
const scriptSyncCache = new ScriptSyncStatusCache(bridge)
const backend = new RobloxStudioWebBackend(ctx, ROBLOX_STUDIO_SETTINGS_NAMESPACE, bridge, '0.4.0-test', scriptSyncCache)

async function call(method, body) {
  const res = fakeRes()
  await backend.handle(fakeReq(method, body), res)
  return { status: res.out.statusCode, json: JSON.parse(res.out.body) }
}

// --- GET snapshot (real MCP bridge) ---
{
  const { status, json } = await call('GET')
  console.log('[GET]', status, 'studios =', JSON.stringify(json.value.studios), 'bridge =', json.value.bridge.state)
  if (!json.ok || json.value.studios.length === 0) throw new Error('expected live studios in snapshot')
}

let studioId
// --- POST activate (real studio id) ---
{
  const studios = bridge.snapshotStudios()
  studioId = studios[studios.length - 1].id
  const { status, json } = await call('POST', { action: 'activate', studioId, expectedRevision: stored.revision })
  console.log('[activate]', status, 'active =', JSON.stringify(json.value.active))
  if (json.value.active.studioId !== studioId) throw new Error('activation did not persist')
}

// --- runtime context now carries the selection ---
{
  const text = contextSpec.text()
  if (!text.includes(studioId)) throw new Error('runtime context missing active studio id')
  console.log('[context] ok')
}

// --- official Script Sync status rides along in the snapshot ---
{
  const { status, json } = await call('GET')
  const view = json.value.scriptSync
  console.log('[scriptSync view]', status, JSON.stringify(view))
  if (view.studioId !== studioId) throw new Error('scriptSync view does not track the active studio')
  if (!Array.isArray(view.roots) || !Array.isArray(view.errored)) throw new Error('scriptSync view missing roots/errored')
  // with no roots configured the agent context stays silent
  if (view.roots.length === 0 && view.error === undefined && renderScriptSyncContext(view, '').length !== 0) {
    throw new Error('context should be empty when no sync roots exist')
  }
  if (view.roots.length > 0) {
    const withRoot = renderScriptSyncContext(view, 'C:\\sync')
    if (!withRoot.includes(view.roots[0].path) || !withRoot.includes('C:\\sync')) throw new Error('context missing roots or local dir')
    console.log('[scriptSync context sample]', withRoot.split('\n')[0])
  }
}

// --- saveScriptSyncRoot persists and validates ---
{
  const { status, json } = await call('POST', { action: 'saveScriptSyncRoot', scriptSyncRoot: 'C:\\Users\\Admin\\Documents\\ROBLOX', expectedRevision: stored.revision })
  console.log('[saveScriptSyncRoot]', status, 'value =', JSON.stringify(json.value.settings.value.scriptSyncRoot))
  if (json.value.settings.value.scriptSyncRoot !== 'C:\\Users\\Admin\\Documents\\ROBLOX') throw new Error('scriptSyncRoot did not persist')
  const bad = await call('POST', { action: 'saveScriptSyncRoot', scriptSyncRoot: 'relative/path', expectedRevision: stored.revision })
  if (bad.json.error.code !== 'action-failed') throw new Error('expected rejection of relative path')
  console.log('[saveScriptSyncRoot invalid] ok (relative rejected)')
  await call('POST', { action: 'saveScriptSyncRoot', scriptSyncRoot: '', expectedRevision: stored.revision })
}

// --- removed sync actions are rejected → invalid-request ---
{
  const { status, json } = await call('POST', { action: 'sync' })
  console.log('[sync removed]', status, json.error.code)
  if (json.error.code !== 'invalid-request') throw new Error('expected invalid-request for removed sync action')
}

// --- clear the selection ---
{
  const { status, json } = await call('POST', { action: 'clear', expectedRevision: stored.revision })
  if (!json.ok || json.value.active.studioId !== '') throw new Error('clear did not reset the selection')
  console.log('[clear] ok')
}

// --- POST activate unknown studio → 400 studio-not-found ---
{
  const { status, json } = await call('POST', { action: 'activate', studioId: 'nope', expectedRevision: stored.revision })
  if (json.error.code !== 'studio-not-found') throw new Error('expected studio-not-found')
  console.log('[activate unknown] ok')
}

// --- POST with stale revision → 409 conflict ---
{
  const { status, json } = await call('POST', { action: 'activate', studioId, expectedRevision: 0 })
  if (json.error.code !== 'settings-conflict') throw new Error('expected settings-conflict')
  console.log('[stale revision] ok')
}

// --- cross-origin POST → 403 ---
{
  const res = fakeRes()
  await backend.handle(fakeReq('POST', { action: 'refresh' }, { origin: 'http://evil.example', host: '127.0.0.1:3080' }), res)
  const json = JSON.parse(res.out.body)
  if (json.error.code !== 'origin-rejected') throw new Error('expected origin-rejected')
  console.log('[cross-origin] ok')
}

// --- POST refresh (force re-list) ---
{
  const { status, json } = await call('POST', { action: 'refresh' })
  console.log('[refresh]', status, 'studios =', json.value.studios.length)
}

dispose()
bridge.dispose()
console.log('\nALL MOCK-CHAIN TESTS PASSED')
setTimeout(() => process.exit(0), 600)
