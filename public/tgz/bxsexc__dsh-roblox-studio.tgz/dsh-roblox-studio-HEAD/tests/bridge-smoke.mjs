// Smoke test: exercise the real StudioBridge class end to end.
import { StudioBridge, resolveLauncher } from '../lib/studio-bridge.js'

const launcher = resolveLauncher('')
console.log('[launcher]', launcher?.description ?? 'NOT FOUND')

const bridge = new StudioBridge({})
try {
  const studios = await bridge.list(true)
  console.log('[list]', JSON.stringify(studios))
  console.log('[cached]', JSON.stringify(await bridge.list()))
  console.log('[state]', bridge.state)
} catch (error) {
  console.log('[FAILED]', error.message)
  process.exitCode = 1
} finally {
  bridge.dispose()
  // give taskkill a moment so the process tree is gone before we assert exit
  setTimeout(() => process.exit(process.exitCode ?? 0), 800)
}
