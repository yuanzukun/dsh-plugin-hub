import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
/** Saved keys stay in page memory and never refill the password input. */
export declare function JevKeyEditor({ configured, onSave, t }: {
    configured: boolean;
    onSave: (key: string) => void;
    t: PropsLocale<'gomoku'>['t'];
}): import("react").JSX.Element;
