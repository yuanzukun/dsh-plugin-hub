# @gzmuldyxx/dsh-windows-tray

DeepSeek Harness 的 **Windows 系统托盘鲸鱼控制器**。在系统通知区域放一个托盘的鲸鱼图标，常驻后台，提供 **启动 / 停止 / 重启 / 打开界面 / 退出** 操作。

A system-tray whale controller for **DeepSeek Harness on Windows**. Adds a resident tray icon with **Open / Start / Stop / Restart / Exit** controls for the `dsh web` service.

## 功能 Features

- 🐳 系统托盘鲸鱼图标，后台常驻
- 🖱️ 左键单击：启动服务 + 打开 Web 界面
- 📋 右键菜单：
  - **打开界面** Open — 启动并打开浏览器
  - **启动服务** Start — 后台拉起 `dsh web`（未运行才启动）
  - **停止服务** Stop — 终止 DSH 服务进程（按端口 3080 定位）
  - **重启服务** Restart — 停止后再拉起
  - **退出托盘** Exit — 移除托盘图标
- 🔒 单实例保护：重复双击 / 重复安装不会叠加出多个托盘图标
- 托盘悬浮显示当前 **运行中 / 已停止** 状态

## 安装 Install

要求：**Windows** + 已安装的 DeepSeek Harness（`dsh`）。

```sh
# 从 npm 安装到你的 web profile 并激活（bundle 会自动加入配置层）
dsh plugin --profile web add @gzmuldyxx/dsh-windows-tray
```

安装后重启 `dsh web`，托盘图标会自动出现在系统通知区域。

### 配置（可选）

插件激活时会自动启动托盘。可用环境变量覆盖默认行为：

| 环境变量 | 默认值 | 说明 |
|---|---|---|
| `DSH_WEB_URL` | `http://127.0.0.1:3080` | 托盘打开的 Web 地址 |
| `DSH_NODE_EXE` | `process.execPath` | Node 可执行文件路径 |
| `DSH_RUNNER_ARG` | 当前 runner 参数 | 启动时的 entry 参数 |
| `DSH_CHECKOUT` | `process.cwd()` | 源码 checkout 目录（若非源码运行请设置） |
| `DSH_TRAY_NOOPEN` | *(空)* | 设置为任意值：启动托盘时不自动打开浏览器 |

## 开发 / 构建

```sh
npm run build   # 确保 PS1 带 UTF-8 BOM、校验 JS 语法
npm run check   # node --check
```

## 从源码本地安装（未发布 npm 时）

```sh
# 在本仓库目录内
dsh plugin --profile web add .
```

## 发布到 npm（维护者）

```sh
npm login                          # 需先登录官方 npm（当前 registry 记得切回 https://registry.npmjs.org/）
npm version patch                   # 或 manual
npm publish --access public
```

推送到 GitHub：

```sh
git init && git add -A
git commit -m "feat: windows tray controller bundle"
git remote add origin https://github.com/<你>/dsh-windows-tray.git
git push -u origin main
```

> 发布后，若需被社区插件市场收录，在仓库 / README 加上 `dsh-plugin` 话题即可。

## 许可 License

[MIT](LICENSE)
