﻿# ============================================================
#  DeepSeek Harness - Windows System Tray Controller (bundled)
#  Whales icon with: Open / Start / Stop / Restart / Exit.
#  Launched detached by the dsh-windows-tray plugin.
# ============================================================

# --- configuration (read from env provided by the host plugin) ---
$WebUrl   = if ($env:DSH_WEB_URL) { $env:DSH_WEB_URL } else { 'http://127.0.0.1:3080' }
$Port     = 3080
$NodeExe  = if ($env:DSH_NODE_EXE)   { $env:DSH_NODE_EXE   } else { 'C:\Program Files\nodejs\node.exe' }
# Runner entry (relative to checkout root). When empty, default to the web profile.
$Runner   = if ($env:DSH_RUNNER_ARG) { $env:DSH_RUNNER_ARG } else { 'apps/cli/src/bin.ts' }
$Checkout = if ($env:DSH_CHECKOUT)   { $env:DSH_CHECKOUT   } else { 'D:\DPHarness\deepseek-harness' }
$IconPath = Join-Path $PSScriptRoot '..\assets\icons\whale.ico'

# --- single-instance guard ---
$TrayMutexName = 'Global\DSH_WINDOWS_TRAY_' + [System.Environment]::UserName
$trayMutex = New-Object System.Threading.Mutex($false, $TrayMutexName)
if (-not $trayMutex.WaitOne(0)) { exit 0 }

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- helpers ---
function Test-PortOpen {
    $c = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    return ($null -ne $c)
}
function Get-DshProcessId {
    $c = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    if ($c) { return ($c | Select-Object -First 1 -ExpandProperty OwningProcess) }
    return $null
}
function Get-DshRunning {
    $pidNow = Get-DshProcessId
    if ($null -eq $pidNow) { return $false }
    return $null -ne (Get-Process -Id $pidNow -ErrorAction SilentlyContinue)
}
function Wait-ForService {
    for ($i = 0; $i -lt 120; $i++) {
        if (Test-PortOpen) { return $true }
        Start-Sleep -Milliseconds 500
    }
    return $false
}
function Start-DshService {
    if (Get-DshRunning) { return '已在运行' }
    $stdout = Join-Path $env:TEMP 'dsh-launch.out.log'
    $stderr = Join-Path $env:TEMP 'dsh-launch.err.log'
    try {
        # Best-effort: start the harness the same way most installs run it.
        # On a source checkout this launches the web profile directly.
        $startArgs = @('--import', 'tsx/esm', $Runner, '--profile', 'web')
        $ps = Start-Process -FilePath $NodeExe `
             -ArgumentList $startArgs `
             -WorkingDirectory $Checkout `
             -WindowStyle Hidden `
             -RedirectStandardOutput $stdout `
             -RedirectStandardError $stderr `
             -PassThru
        Wait-ForService | Out-Null
        return "已启动 (PID $($ps.Id))"
    } catch {
        return "启动失败: $_"
    }
}
function Stop-DshService {
    $pidNow = Get-DshProcessId
    if ($null -eq $pidNow) { return '未在运行' }
    Stop-Process -Id $pidNow -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    return '已停止'
}
function Restart-DshService {
    $out = Stop-DshService
    $out2 = Start-DshService
    return "$out ; $out2"
}
function Refresh-IconText {
    $text = "DeepSeek Harness`n状态: $(if (Get-DshRunning) { '运行中' } else { '已停止' })"
    if ($text.Length -gt 63) { $text = $text.Substring(0, 63) }
    $trayIcon.Text = $text
    $trayIcon.Visible = $true
}

# --- menu ---
$menuOpen     = New-Object System.Windows.Forms.ToolStripMenuItem('打开界面')
$menuStart    = New-Object System.Windows.Forms.ToolStripMenuItem('启动服务')
$menuStop     = New-Object System.Windows.Forms.ToolStripMenuItem('停止服务')
$menuRestart  = New-Object System.Windows.Forms.ToolStripMenuItem('重启服务')
$menuExit     = New-Object System.Windows.Forms.ToolStripMenuItem('退出托盘')

$contextMenu = New-Object System.Windows.Forms.ContextMenuStrip
$contextMenu.Items.Add($menuOpen)    | Out-Null
$contextMenu.Items.Add($menuStart)   | Out-Null
$contextMenu.Items.Add($menuStop)    | Out-Null
$contextMenu.Items.Add($menuRestart) | Out-Null
$contextMenu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null
$contextMenu.Items.Add($menuExit)    | Out-Null

$trayIcon = New-Object System.Windows.Forms.NotifyIcon
if (Test-Path $IconPath) { $trayIcon.Icon = [System.Drawing.Icon]::new($IconPath) }
$trayIcon.ContextMenuStrip = $contextMenu
$trayIcon.Visible = $true

$trayIcon.Add_MouseUp({
    param($sender, $e)
    if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Left) {
        $r = Start-DshService
        Refresh-IconText
        $trayIcon.ShowBalloonTip(2000, 'DeepSeek Harness', $r, [System.Windows.Forms.ToolTipIcon]::Info)
        Start-Process $WebUrl
    }
})
$menuOpen.Add_Click({ $r=Start-DshService; $trayIcon.ShowBalloonTip(2000,'DeepSeek Harness',$r,[System.Windows.Forms.ToolTipIcon]::Info); Start-Process $WebUrl })
$menuStart.Add_Click({ $r=Start-DshService; $trayIcon.ShowBalloonTip(2000,'DeepSeek Harness',$r,[System.Windows.Forms.ToolTipIcon]::Info); Refresh-IconText })
$menuStop.Add_Click({ $r=Stop-DshService; $trayIcon.ShowBalloonTip(2000,'DeepSeek Harness',$r,[System.Windows.Forms.ToolTipIcon]::Warning); Refresh-IconText })
$menuRestart.Add_Click({ $r=Restart-DshService; $trayIcon.ShowBalloonTip(2500,'DeepSeek Harness',$r,[System.Windows.Forms.ToolTipIcon]::Info); Refresh-IconText })
$menuExit.Add_Click({ $trayIcon.Visible=$false; $trayIcon.Dispose(); [System.Windows.Forms.Application]::Exit() })

# open once on first launch (unless suppressed)
if (-not $env:DSH_TRAY_NOOPEN) {
    $r = Start-DshService
    $trayIcon.ShowBalloonTip(2500, 'DeepSeek Harness', $r, [System.Windows.Forms.ToolTipIcon]::Info)
    Refresh-IconText
    Start-Process $WebUrl
}

Refresh-IconText
[System.Windows.Forms.Application]::Run()
