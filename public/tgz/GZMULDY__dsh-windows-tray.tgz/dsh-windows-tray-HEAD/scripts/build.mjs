// Rebuild/normalize step for the bundle. Ensures the bundled PowerShell
// script carries a UTF-8 BOM (Windows PowerShell 5.1 mis-parses BOM-less UTF-8
// with non-ASCII text) and runs a syntax sanity check on the JS entry.
import { readFileSync, writeFileSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const trayPs1 = join(root, 'lib', 'tray.ps1')

let raw = readFileSync(trayPs1, 'utf8')
if (!(raw.charCodeAt(0) === 0xfeff)) {
  raw = '\uFEFF' + raw
  writeFileSync(trayPs1, raw, { encoding: 'utf8' })
}

execFileSync(process.execPath, ['--check', join(root, 'lib', 'index.js')])
execFileSync(process.execPath, ['--check', join(root, 'lib', 'tray.js')])
console.log('[dsh-windows-tray] build ok (PS1 BOM ensured, JS syntax checked)')
