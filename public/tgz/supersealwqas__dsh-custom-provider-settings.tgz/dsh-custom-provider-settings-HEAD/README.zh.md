# 文档已移动 / Moved

中文文档现在就是仓库首页：[README.md](README.md)。

The English README moved to [README.en.md](README.en.md).

按包名安装的说明见 [README.md 的快速安装](README.md#快速安装推荐)：在桌面端选择官方 npm 安装源并输入 `dsh-custom-provider-settings`，安装成功后点击“立即启用”。自定义安装源必须是兼容 npm 的仓库，不能填 GitHub 仓库链接。

本文件只保留旧链接，完整说明在 README.md 中更新。 · This file keeps the old URL working; the full documentation is maintained in README.md.
