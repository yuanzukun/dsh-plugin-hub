import assert from 'node:assert/strict'
import test from 'node:test'

// A small DOM fixture for the actual inline manager. Selectors run against a
// tree, so changed labels or a missing mount cannot pass as an empty-page mock.
class Element {
  constructor(tagName, text = '', attributes = {}) {
    this.tagName = tagName
    this.text = text
    this.attributes = attributes
    this.children = []
    this.dataset = {}
    this.parentElement = null
    this.value = ''
    this.classList = { toggle() {} }
  }
  get textContent() { return this.text + this.children.map(child => child.textContent).join('') }
  set textContent(value) { this.text = value }
  get isConnected() { return this.tagName === 'body' || Boolean(this.parentElement?.isConnected) }
  get firstElementChild() { return this.children[0] ?? null }
  get nextElementSibling() {
    return this.parentElement?.children[this.parentElement.children.indexOf(this) + 1] ?? null
  }
  getAttribute(name) { return this.attributes[name] ?? null }
  setAttribute(name, value) { this.attributes[name] = value }
  appendChild(child) { return this.insertBefore(child, null) }
  insertBefore(child, before) {
    child.parentElement = this
    this.children.splice(before === null ? this.children.length : this.children.indexOf(before), 0, child)
    return child
  }
  remove() {
    this.parentElement?.children.splice(this.parentElement.children.indexOf(this), 1)
    this.parentElement = null
  }
  contains(node) { return this === node || this.children.some(child => child.contains(node)) }
  matches(selector) {
    if (selector === 'details > summary') return this.tagName === 'summary' && this.parentElement?.tagName === 'details'
    const match = /^([\w-]*)?(?:\[([\w-]+)(?:="([^"]*)")?\])?$/.exec(selector)
    if (match === null || (match[1] && this.tagName !== match[1])) return false
    if (!match[2]) return true
    const value = match[2].startsWith('data-')
      ? this.dataset[match[2].slice(5).replace(/-([a-z])/g, (_, letter) => letter.toUpperCase())]
      : this.getAttribute(match[2])
    return value !== null && value !== undefined && (match[3] === undefined || value === match[3])
  }
  querySelectorAll(selector) {
    return this.children.flatMap(child => [
      ...(selector.split(',').some(part => child.matches(part)) ? [child] : []),
      ...child.querySelectorAll(selector),
    ])
  }
  querySelector(selector) { return this.querySelectorAll(selector)[0] ?? null }
  closest(selector) { return this.matches(selector) ? this : this.parentElement?.closest(selector) ?? null }
  addEventListener() {}
  removeEventListener() {}
}

async function inlineFixture({ language = 'en', existing = false, accessor = false, globals = false, rpc } = {}) {
  const body = new Element('body')
  const listeners = new Map()
  const observers = new Set()
  const roots = []
  const document = {
    body,
    head: new Element('head'),
    createElement: tag => new Element(tag),
    querySelector: selector => body.querySelector(selector),
    querySelectorAll: selector => body.querySelectorAll(selector),
    addEventListener: (type, callback) => listeners.set(type, callback),
    removeEventListener: type => listeners.delete(type),
  }
  let definition
  globalThis.window = { __ModuleLoader__: { load: value => { definition = value } } }
  globalThis.document = document
  globalThis.MutationObserver = class {
    constructor(callback) { this.callback = callback }
    observe() { observers.add(this) }
    disconnect() { observers.delete(this) }
  }
  await import(`../client.js?fixture=${crypto.randomUUID()}`)
  const React = {
    Fragment: Symbol('Fragment'),
    createElement(type, props, ...children) {
      assert.notEqual(type, undefined, 'React received a component missing from the current primitives exports')
      return { type, props: { ...props, children } }
    },
    useState: value => [typeof value === 'function' ? value() : value, () => {}],
    useEffect() {},
  }
  // These are the actual names exported by Harness 0.2.1-rc.5. No wildcard Proxy.
  const primitives = Object.fromEntries(['Button', 'Tooltip', 'IconPlusOutlineRegular', 'IconTrashOutlineRegular']
    .map(name => [name, function Primitive() {}]))
  const plugin = definition.factory(id => {
    if (id === 'react') return React
    if (id === 'react-dom/client') return { createRoot: point => {
      const root = { point, render(element) { this.element = element }, unmount() {} }
      roots.push(root)
      return root
    } }
    if (id === '@deepseek-ai/dsh-client-ui-primitives') return primitives
    throw new Error(`unexpected dependency: ${id}`)
  })
  const section = body.appendChild(new Element('div'))
  section.appendChild(new Element('h2', language === 'zh' ? '模型' : 'Models'))
  const list = section.appendChild(new Element('ul'))
  const row = existing ? list.appendChild(new Element('li')) : section
  if (existing) {
    row.appendChild(new Element('span', 'Relay'))
    row.appendChild(new Element('span', language === 'zh' ? '自定义' : 'Custom'))
  }
  const form = row.appendChild(new Element('div'))
  let fields = form
  if (existing) {
    const details = form.appendChild(new Element('details'))
    details.appendChild(new Element('summary', language === 'zh' ? '自定义设置' : 'Customized settings'))
    fields = details.appendChild(new Element('div'))
  }
  for (const [label, value] of [
    ['Provider ID', 'relay'], ['Display name', 'Relay'], ['Base URL', 'https://relay.example/v1'],
    ['Model ID 1', 'alpha'], ['Display name 1', 'Alpha'],
  ]) {
    const input = fields.appendChild(new Element('input', '', { 'aria-label': label,
      ...label === 'Provider ID' && !existing ? { placeholder: 'acme-gateway' } : {},
    }))
    input.value = value
  }
  const protocol = fields.appendChild(new Element('select', '', { 'aria-label': 'API protocol' }))
  protocol.value = 'openai-completions'
  const button = form.appendChild(new Element('button', existing
    ? language === 'zh' ? '保存' : 'Apply'
    : language === 'zh' ? '创建提供商' : 'Create provider'))
  const model = { id: 'alpha', name: 'Alpha', input: ['text'], reasoningEfforts: { medium: 'medium' } }
  const profile = { displayName: 'Relay', api: 'openai-completions', models: [model] }
  const namespace = { ns: 'llm-pi-ai', revision: 1, user: { providers: { relay: profile } }, value: { providers: { relay: profile } } }
  const mutations = []
  const calls = []
  const llm = {
    caller: 'default',
    listConfigurableProviders: async () => ({ ok: true, value: [{ provider: 'relay', displayName: 'Relay', settingsNs: 'llm-pi-ai', declared: true }] }),
  }
  const original = function (...args) { calls.push({ caller: this.caller, args }); return Promise.resolve({ ok: true, value: [{ id: 'native' }] }) }
  if (accessor) Object.defineProperty(llm, 'discoverModels', {
    configurable: true, enumerable: true,
    get() { const receiver = this; return (...args) => original.apply(receiver, args) },
  })
  else llm.discoverModels = original
  const originalDescriptor = Object.getOwnPropertyDescriptor(llm, 'discoverModels')
  const remote = {
    llm,
    settings: {
      describe: async () => ({ ok: true, value: { writable: true, namespaces: [namespace,
        ...globals ? [{ ns: 'dsh-custom-provider-settings', revision: 2, value: { globalHeaders: {} } }] : [],
      ] } }),
      mutate: async (...args) => { mutations.push(args); return { ok: true, value: namespace } },
    },
    $on() { return () => {} },
  }
  const manager = plugin.__test.createInlineManager({ remote, connection: { rpc }, t: key => key })
  const flush = () => new Promise(resolve => setImmediate(resolve))
  return {
    helpers: plugin.__test, remote, namespace, profile, mutations, calls, roots, manager, originalDescriptor,
    flush,
    async start() { this.dispose = manager.start(); await flush(); return this },
    record() { return roots.find(root => root.element?.props.record)?.element.props.record },
    submit() { listeners.get('click')({ target: button, preventDefault() {}, stopImmediatePropagation() {} }) },
    detach() { form.remove(); for (const observer of [...observers]) observer.callback() },
  }
}

test('renders the header controls with the actual modern primitive names', async () => {
  const fixture = await inlineFixture()
  const provider = { id: 'relay', userAgent: '', headers: [{ id: 'a', name: 'X-Test', value: 'one' }] }
  assert.doesNotThrow(() => fixture.helpers.HeaderEditor({ provider, t: key => key, writable: true, busy: false, updateProvider() {} }))
  assert.doesNotThrow(() => fixture.helpers.GlobalHeaderEditor({ initial: provider, t: key => key, writable: true, busy: false, save() {} }))
})

test('mounts and saves a new provider with the current Chinese create label', async () => {
  const fixture = await inlineFixture({ language: 'zh' })
  try {
    await fixture.start()
    const record = fixture.record()
    assert.ok(record, 'current Chinese creation form should receive an inline editor')
    record.draft.userAgent = 'draft/1.0'
    record.dirty = true
    fixture.submit()
    await fixture.flush()
    assert.equal(fixture.mutations.length, 0, 'wait for the original form to save successfully')
    fixture.detach()
    await fixture.flush()
    assert.equal(fixture.mutations.length, 1)
    assert.deepEqual(fixture.mutations[0][1][0], { op: 'set', path: ['providers', 'relay', 'headers'], value: { 'User-Agent': 'draft/1.0' } })
  } finally { fixture.dispose?.() }
})

test('saving plugin headers preserves model capabilities changed in the native form', async () => {
  const fixture = await inlineFixture({ existing: true })
  try {
    await fixture.start()
    const record = fixture.record()
    record.draft.userAgent = 'headers-only/1.0'
    record.dirty = true
    fixture.profile.models = [{ id: 'alpha', name: 'Changed natively', input: ['text', 'image'], reasoningEfforts: { high: 'native-high' }, contextWindow: 9000 }]
    fixture.submit()
    fixture.detach()
    await fixture.flush()
    const modelsOp = fixture.mutations[0][1].find(op => op.path.at(-1) === 'models')
    assert.ok(modelsOp === undefined || JSON.stringify(modelsOp.value) === JSON.stringify(fixture.profile.models),
      'a header edit must not overwrite native input or reasoning changes')
  } finally { fixture.dispose?.() }
})

test('wraps getter-based Remote discovery, keeps the caller context, and restores the descriptor', async () => {
  const fixture = await inlineFixture({ existing: true, accessor: true })
  const nativeFetch = globalThis.fetch
  const requests = []
  globalThis.fetch = async (url, init) => {
    requests.push({ url, ...JSON.parse(init.body) })
    return new Response(JSON.stringify({ models: [{ id: 'draft-model' }] }))
  }
  try {
    await fixture.start()
    const caller = Object.assign(Object.create(fixture.remote.llm), { caller: 'models-page' })
    await caller.discoverModels('llm-pi-ai', { provider: 'untouched' })
    assert.equal(fixture.calls[0].caller, 'models-page')
    fixture.record().draft.userAgent = 'unsaved/2.0'
    const answer = await caller.discoverModels('llm-pi-ai', { provider: 'relay', baseURL: 'https://relay.example/v1', api: 'openai-completions' })
    assert.deepEqual(answer, { ok: true, value: [{ id: 'draft-model' }] })
    assert.equal(requests[0].headers['User-Agent'], 'unsaved/2.0')
    assert.equal(fixture.calls.length, 1, 'draft headers must use the plugin discovery route')
  } finally {
    fixture.dispose?.()
    globalThis.fetch = nativeFetch
  }
  assert.deepEqual(Object.getOwnPropertyDescriptor(fixture.remote.llm, 'discoverModels'), fixture.originalDescriptor)
})

test('desktop discovery uses the connection RPC for draft headers, clearing, cancellation, and failures', async () => {
  const requests = []
  let outcome = { ok: true, value: [{ id: 'ipc-model' }] }
  const rpc = { call: async (...args) => { requests.push(args); return outcome } }
  const fixture = await inlineFixture({ existing: true, accessor: true, rpc })
  const nativeFetch = globalThis.fetch
  globalThis.fetch = () => { assert.fail('desktop discovery must not use a relative HTTP URL') }
  try {
    await fixture.start()
    const signal = new AbortController().signal
    fixture.record().draft.userAgent = 'desktop/1.0'
    const request = { provider: 'relay', api: 'openai-completions', baseURL: 'https://relay.example/v1', apiKey: 'test-key' }
    assert.deepEqual(await fixture.remote.llm.discoverModels('llm-pi-ai', request, signal), outcome)
    assert.deepEqual(requests[0], ['/api', 'customProviderSettings/discoverModels', { args: { request: {
      ...request, headers: { 'User-Agent': 'desktop/1.0' },
    } } }, signal])
    fixture.record().draft.userAgent = ''
    await fixture.remote.llm.discoverModels('llm-pi-ai', request)
    assert.deepEqual(requests[1][2].args.request.headers, {}, 'clearing a draft must not restore saved local headers')
    outcome = { ok: false, error: { code: 'model-discovery-failed', message: 'model discovery failed' } }
    assert.deepEqual(await fixture.remote.llm.discoverModels('llm-pi-ai', request), outcome)
    assert.equal(fixture.calls.length, 0)
  } finally { fixture.dispose?.(); globalThis.fetch = nativeFetch }
})

test('plugin input and reasoning edits preserve each other and the native model fields', async () => {
  const fixture = await inlineFixture()
  const { helpers } = fixture
  const provider = helpers.providerDrafts(fixture.namespace)[0]
  const native = [{ id: 'alpha', input: ['text', 'image'], reasoningEfforts: { high: 'native-high' }, contextWindow: 9000 }]
  const input = helpers.patchModel(provider, 'alpha', model => ({ ...model, inputMode: 'inherit' }))
  assert.deepEqual(helpers.mergeModelSettings(native, input.models), [{ id: 'alpha', reasoningEfforts: { high: 'native-high' }, contextWindow: 9000 }])
  const reasoning = helpers.patchModel(provider, 'alpha', model => ({ ...model, mode: 'custom', efforts: { off: null, high: 'plugin-high' } }))
  assert.deepEqual(helpers.mergeModelSettings(native, reasoning.models), [{ ...native[0], reasoningEfforts: { off: null, high: 'plugin-high' } }])
  const disabled = helpers.patchModel(reasoning, 'alpha', model => ({ ...model, mode: 'disabled' }))
  assert.equal(helpers.mergeModelSettings(native, disabled.models)[0].reasoningEfforts, false)
})

test('global headers save and clear through the current settings mutation signature', async () => {
  const fixture = await inlineFixture({ globals: true })
  try {
    await fixture.start()
    const global = fixture.roots.find(root => root.element?.props.save)?.element.props
    assert.ok(global)
    await global.save({ userAgent: 'global/1.0', headers: [{ name: 'X-Global', value: 'yes' }] })
    assert.deepEqual(fixture.mutations[0], ['dsh-custom-provider-settings', [{ op: 'set', path: ['globalHeaders'], value: { 'User-Agent': 'global/1.0', 'X-Global': 'yes' } }], 2])
    await global.save({ userAgent: '', headers: [] })
    assert.deepEqual(fixture.mutations[1][1], [{ op: 'unset', path: ['globalHeaders'] }])
  } finally { fixture.dispose?.() }
})

test('removing an earlier native model keeps plugin edits attached to the remaining model', async () => {
  const { helpers } = await inlineFixture()
  const form = new Element('div')
  const id = form.appendChild(new Element('input', '', { 'aria-label': 'Model ID 1' }))
  id.value = 'beta'
  const original = { id: 'relay', name: 'Relay', api: 'openai-completions', defaultEffort: '', models: [
    helpers.modelState({ id: 'alpha', input: ['text'] }),
    helpers.modelState({ id: 'beta', input: ['text'] }),
  ] }
  const edited = helpers.patchModel(original, 'beta', model => ({ ...model, inputMode: 'image' }))
  const synced = helpers.syncFormProvider(edited, { kind: 'existing', entry: { provider: 'relay', displayName: 'Relay' }, form })
  assert.equal(synced.models[0].id, 'beta')
  assert.equal(synced.models[0].editedInput, true)
  assert.equal(synced.models[0].inputMode, 'image')
})

test('registers the Web client and builds provider settings without touching secrets', async () => {
  let definition
  globalThis.window = {
    __ModuleLoader__: {
      load(value) { definition = value },
    },
  }
  globalThis.document = {
    head: { appendChild() {} },
    createElement() { return { dataset: {}, textContent: '' } },
  }

  await import(`../client.js?test=${Date.now()}`)
  assert.equal(definition.id, 'dsh-custom-provider-settings')

  const React = {
    Fragment: Symbol('Fragment'),
    createElement() {},
    useCallback() {},
    useEffect() {},
    useRef() {},
    useState() {},
  }
  const primitives = new Proxy({}, { get: () => function Primitive() {} })
  const plugin = definition.factory((id) => {
    if (id === 'react') return React
    if (id === 'react-dom/client') return { createRoot() {} }
    if (id === '@deepseek-ai/dsh-client-ui-primitives') return primitives
    throw new Error(`unexpected dependency: ${id}`)
  })
  const helpers = plugin.__test
  assert.deepEqual(helpers.userAgentPresets, [
    'claude-cli/2.1.161 (external, cli)',
    'claude-cli/2.1.161',
    'claude-code/1.0.0',
    'claude-code/0.1.0',
    'Kilo-Code/1.0',
  ])
  const drafts = helpers.providerDrafts({
    revision: 4,
    value: {
      providers: {
        relay: {
          displayName: 'Relay',
          api: 'openai-completions',
          reasoning: 'high',
          models: [{ id: 'alpha', name: 'Alpha' }],
        },
      },
    },
    user: {
      providers: {
        relay: {
          apiKeyEnv: 'RELAY_API_KEY',
          headers: { 'User-Agent': 'relay/1.0', 'X-Tenant': 'demo' },
          compat: { supportsDeveloperRole: false },
          models: [{ id: 'alpha', name: 'Alpha', contextWindow: 1000, input: ['text', 'image'] }],
        },
      },
    },
  })
  assert.equal(drafts.length, 1)
  assert.equal(drafts[0].userAgent, 'relay/1.0')
  assert.deepEqual(drafts[0].headers.map(({ name, value }) => ({ name, value })), [
    { name: 'X-Tenant', value: 'demo' },
  ])
  assert.equal(drafts[0].defaultEffort, 'high')
  assert.equal(drafts[0].systemRole, true)
  assert.equal(drafts[0].models[0].inputMode, 'image')

  const configured = {
    ...drafts[0],
    models: [{
      ...drafts[0].models[0],
      mode: 'custom',
      efforts: { low: 'low', medium: 'medium', high: 'high' },
      editedInput: true,
      editedReasoning: true,
    }],
  }
  assert.equal(helpers.validateProvider(configured), undefined)
  assert.deepEqual(helpers.buildHeaders(configured), {
    'User-Agent': 'relay/1.0',
    'X-Tenant': 'demo',
  })
  assert.deepEqual(helpers.mergeModelSettings([{
    id: 'alpha', name: 'Renamed by the original form', contextWindow: 2000,
  }], configured.models), [{
    id: 'alpha', name: 'Renamed by the original form', contextWindow: 2000, input: ['text', 'image'],
    reasoningEfforts: { low: 'low', medium: 'medium', high: 'high' },
  }])
  assert.deepEqual(helpers.extensionOps(configured, {
    models: [{ id: 'alpha', contextWindow: 2000 }],
  }), [
    {
      op: 'set', path: ['providers', 'relay', 'headers'],
      value: { 'User-Agent': 'relay/1.0', 'X-Tenant': 'demo' },
    },
    {
      op: 'set', path: ['providers', 'relay', 'models'],
      value: [{
        id: 'alpha', contextWindow: 2000, input: ['text', 'image'],
        reasoningEfforts: { low: 'low', medium: 'medium', high: 'high' },
      }],
    },
    { op: 'set', path: ['providers', 'relay', 'reasoning'], value: 'high' },
    { op: 'unset', path: ['providers', 'relay', 'compat', 'thinkingFormat'] },
    { op: 'set', path: ['providers', 'relay', 'compat', 'supportsDeveloperRole'], value: false },
  ])
  assert.deepEqual(helpers.extensionOps({
    ...configured,
    api: 'openai-responses',
    systemRole: false,
  }, { models: [{ id: 'alpha', contextWindow: 2000 }] }).at(-1), {
    op: 'unset', path: ['providers', 'relay', 'compat', 'supportsDeveloperRole'],
  })

  const duplicate = {
    ...configured,
    headers: [
      { id: '1', name: 'X-Test', value: 'one' },
      { id: '2', name: 'x-test', value: 'two' },
    ],
  }
  assert.equal(helpers.validateProvider(duplicate).key, 'validationHeaderDuplicate')
  assert.equal(helpers.validateProvider({
    ...configured,
    headers: [{ id: '1', name: 'user-agent', value: 'duplicate' }],
  }).key, 'validationUserAgentDuplicate')
  assert.deepEqual(helpers.mergeModelSettings([
    { id: 'inherit' },
    { id: 'text' },
    { id: 'image' },
  ], [
    { ...helpers.modelState({ id: 'inherit' }), inputMode: 'inherit', editedInput: true },
    { ...helpers.modelState({ id: 'text' }), inputMode: 'text', editedInput: true },
    { ...helpers.modelState({ id: 'image' }), inputMode: 'image', editedInput: true },
  ]), [
    { id: 'inherit' },
    { id: 'text', input: ['text'] },
    { id: 'image', input: ['text', 'image'] },
  ])
  const globalDraft = helpers.globalHeaderDraft({
    globalHeaders: { 'User-Agent': 'global/1.0', 'X-Client': 'all' },
  })
  assert.deepEqual(helpers.globalHeaderDraft({
    globalHeaders: { 'User-Agent': 'global/1.0', 'X-Client': 'all' },
  }), globalDraft)
  assert.equal(globalDraft.userAgent, 'global/1.0')
  assert.deepEqual(globalDraft.headers.map(({ name, value }) => ({ name, value })), [
    { name: 'X-Client', value: 'all' },
  ])
  assert.deepEqual(helpers.buildGlobalHeaders(globalDraft), {
    'User-Agent': 'global/1.0',
    'X-Client': 'all',
  })
  const mixedCase = helpers.globalHeaderDraft({
    globalHeaders: {
      'user-agent': 'global/lower',
      'User-Agent': 'global/upper',
      'X-Client': 'first',
      'x-client': 'last',
    },
  })
  assert.equal(mixedCase.userAgent, 'global/upper')
  assert.deepEqual(mixedCase.headers.map(({ name, value }) => ({ name, value })), [
    { name: 'x-client', value: 'last' },
  ])

  const controls = {
    input: [
      { value: 'relay', getAttribute: name => name === 'aria-label' ? 'Provider ID' : null },
      { value: 'Relay', getAttribute: name => name === 'aria-label' ? 'Display name' : null },
    ],
    modelInputs: [],
    select: [
      { value: 'openai-completions', getAttribute: name => name === 'aria-label' ? 'API protocol' : null },
    ],
  }
  const listeners = new Map()
  const form = {
    addEventListener(type, listener) { listeners.set(type, listener) },
    removeEventListener(type, listener) {
      if (listeners.get(type) === listener) listeners.delete(type)
    },
    querySelectorAll(selector) {
      if (selector === 'input') return controls.input
      if (selector === 'input[aria-label]') return [...controls.input, ...controls.modelInputs]
      if (selector === 'select') return controls.select
      return []
    },
  }
  let mutationCallback
  let disconnected = false
  globalThis.MutationObserver = class MutationObserver {
    constructor(callback) { mutationCallback = callback }
    observe(target, options) {
      assert.equal(target, form)
      assert.deepEqual(options, { childList: true, subtree: true })
    }
    disconnect() { disconnected = true }
  }
  const record = {
    kind: 'new',
    entry: { provider: '', displayName: '' },
    form,
    initial: {
      id: '', name: '', api: '', defaultEffort: '', thinkingFormat: '',
      userAgent: '', headers: [], models: [],
    },
  }
  record.draft = record.initial
  const syncedModels = []
  const disposeSync = helpers.installFormSync(record, () => {
    record.draft = helpers.syncFormProvider(record.draft, record)
    syncedModels.push(record.draft.models.map(model => model.id))
  })
  assert.deepEqual(syncedModels, [[]])

  controls.modelInputs.push(
    { value: 'alpha', getAttribute: name => name === 'aria-label' ? 'Model ID 1' : null },
    { value: 'Alpha', getAttribute: name => name === 'aria-label' ? 'Display name 1' : null },
  )
  mutationCallback()
  assert.deepEqual(syncedModels, [[], ['alpha']])
  mutationCallback()
  assert.deepEqual(syncedModels, [[], ['alpha']])

  controls.modelInputs[0].value = 'beta'
  listeners.get('input')()
  assert.deepEqual(syncedModels, [[], ['alpha'], ['beta']])
  disposeSync()
  assert.equal(disconnected, true)
  assert.equal(listeners.size, 0)
})

test('plugin.apply safely loads when connection.api is undefined (Harness 0.1.5-rc remote architecture)', async () => {
  let definition
  globalThis.window = {
    __ModuleLoader__: {
      load(value) { definition = value },
    },
  }
  globalThis.document = {
    head: { appendChild() {} },
    body: {},
    createElement() { return { dataset: {}, textContent: '' } },
    addEventListener() {},
    removeEventListener() {},
    querySelectorAll() { return [] },
    querySelector() { return null },
  }
  globalThis.MutationObserver = class MockMutationObserver {
    observe() {}
    disconnect() {}
  }

  await import(`../client.js?test=${Date.now()}_apply`)

  const React = {
    Fragment: Symbol('Fragment'),
    createElement() {},
    useCallback() {},
    useEffect() {},
    useRef() {},
    useState() {},
  }
  const primitives = new Proxy({}, { get: () => function Primitive() {} })
  const plugin = definition.factory((id) => {
    if (id === 'react') return React
    if (id === 'react-dom/client') return { createRoot() {} }
    if (id === '@deepseek-ai/dsh-client-ui-primitives') return primitives
    throw new Error(`unexpected dependency: ${id}`)
  })

  assert.equal(typeof plugin.apply, 'function')
  assert.deepEqual(plugin.inject, ['locale', 'connection', 'remote', 'remote.llm', 'remote.settings'])

  const effects = []
  const baseCtx = {
    effect(fn) {
      const disposer = fn()
      effects.push(disposer)
      return disposer
    },
    locale: {
      register() {},
      bind() { return key => key },
    },
    // In Harness 0.1.5-rc, connection exists but has NO .api property
    connection: { isLoopback: true },
    get(name) {
      if (name === 'connection') return { isLoopback: true }
      return undefined
    },
    // Cordis exposes remote namespaces as tracked child services (e.g. remote.settings)
    remote: new Proxy({
      $on() { return () => {} },
    }, {
      get(target, prop) {
        if (typeof prop === 'string' && prop !== '$on') {
          const fullKey = `remote.${prop}`
          if (!plugin.inject.includes(fullKey)) {
            throw new Error(`cannot get property "${fullKey}" without inject`)
          }
        }
        if (prop === 'llm') return {
          listConfigurableProviders: async () => ({ ok: true, value: [] }),
          discoverModels: async () => ({ ok: true, value: [] }),
        }
        if (prop === 'settings') return {
          describe: async () => ({ ok: true, value: { writable: true, namespaces: [] } }),
          mutate: async () => ({ ok: true, value: {} }),
        }
        return target[prop]
      },
    }),
  }

  // Simulate Cordis proxy trap that enforces strict inject on ctx
  const cordisCtx = new Proxy(baseCtx, {
    get(target, prop) {
      if (typeof prop === 'string' && !['effect', 'get', ...plugin.inject].includes(prop)) {
        throw new Error(`cannot get property "${prop}" without inject`)
      }
      return target[prop]
    },
  })

  // MUST NOT throw 'cannot get property "remote.settings" without inject'
  assert.doesNotThrow(() => {
    plugin.apply(cordisCtx)
  })

  // Clean up all effects
  for (const disposer of effects) {
    if (typeof disposer === 'function') disposer()
  }
})
