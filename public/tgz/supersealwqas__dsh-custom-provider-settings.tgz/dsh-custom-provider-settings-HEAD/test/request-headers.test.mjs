import assert from 'node:assert/strict'
import test from 'node:test'
import {
  configuredHeaders,
  installRequestHeaderBridge,
  runWithRequestHeaders,
  withHeaderOverrides,
} from '../request-headers.js'

function settingsWith(headers) {
  return {
    describe(options) {
      assert.deepEqual(options, { redactSecrets: true })
      return [{
        ns: 'llm-pi-ai',
        user: { providers: { relay: { headers } } },
      }]
    },
  }
}

function settingsWithGlobal(globalHeaders, providerHeaders = undefined) {
  return {
    describe(options) {
      assert.deepEqual(options, { redactSecrets: true })
      return [
        {
          ns: 'llm-pi-ai',
          user: { providers: { relay: { headers: providerHeaders } } },
        },
        {
          ns: 'dsh-custom-provider-settings',
          value: { globalHeaders },
        },
      ]
    },
  }
}

test('reads only explicitly configured llm-pi-ai provider headers', () => {
  const settings = settingsWith({ 'User-Agent': 'custom/1.0', 'X-Route': 'relay' })
  assert.deepEqual(configuredHeaders(settings, 'relay'), {
    'User-Agent': 'custom/1.0',
    'X-Route': 'relay',
  })
  assert.equal(configuredHeaders(settings, 'missing'), undefined)
  assert.equal(configuredHeaders(undefined, 'relay'), undefined)
})

test('global headers apply to every provider while local headers have higher priority', () => {
  const settings = settingsWithGlobal({
    'User-Agent': 'global/1.0',
    'X-Global': 'all-models',
  }, {
    'user-agent': 'provider/1.0',
    'X-Route': 'relay',
  })
  assert.deepEqual(configuredHeaders(settings, 'relay'), {
    'user-agent': 'provider/1.0',
    'X-Route': 'relay',
    'X-Global': 'all-models',
  })
  assert.deepEqual(configuredHeaders(settings, 'deepseek-official'), {
    'User-Agent': 'global/1.0',
    'X-Global': 'all-models',
  })
})

test('merges Request and init headers before applying case-insensitive overrides', () => {
  const input = new Request('https://example.test/v1/chat', {
    headers: { 'user-agent': 'request-default', 'x-request': 'one' },
  })
  const result = withHeaderOverrides(input, {
    headers: { 'x-init': 'two', 'user-agent': 'init-default' },
  }, {
    'User-Agent': 'custom/2.0',
    'X-Route': 'relay',
  })
  const headers = Object.fromEntries(result.headers)
  assert.deepEqual(headers, {
    'user-agent': 'custom/2.0',
    'x-init': 'two',
    'x-request': 'one',
    'x-route': 'relay',
  })
})

test('scopes overrides to the selected provider for streams and model discovery', async () => {
  const nativeFetch = globalThis.fetch
  const calls = []
  globalThis.fetch = async (input, init) => {
    const headers = Object.fromEntries(new Headers(init?.headers))
    calls.push({ input: String(input), headers })
    return new Response(JSON.stringify(headers), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    })
  }

  const effects = []
  let streamListener
  const settings = settingsWith({
    'User-Agent': 'relay-client/3.0',
    'X-Route': 'relay',
  })
  const llm = {
    async discoverModels(settingsNs) {
      const response = await fetch(`https://example.test/${settingsNs}/models`, {
        headers: { 'user-agent': 'harness-default', accept: 'application/json' },
      })
      return response.json()
    },
  }
  const ctx = {
    llm,
    get(service) {
      return service === 'settings' ? settings : undefined
    },
    effect(callback) {
      effects.push(callback())
    },
    on(event, listener) {
      assert.equal(event, 'llm/stream')
      streamListener = listener
    },
  }

  try {
    installRequestHeaderBridge(ctx)

    await fetch('https://example.test/plain', {
      headers: { 'user-agent': 'outside-default' },
    })
    assert.equal(calls.at(-1).headers['user-agent'], 'outside-default')

    const thirdParty = streamListener({ provider: 'relay' }, () => (async function* () {
      const response = await fetch('https://example.test/v1/chat', {
        headers: { 'user-agent': 'harness-default', 'x-sdk': 'present' },
      })
      yield await response.json()
    })())
    const chunks = []
    for await (const chunk of thirdParty) chunks.push(chunk)
    assert.deepEqual(chunks, [{
      'user-agent': 'relay-client/3.0',
      'x-route': 'relay',
      'x-sdk': 'present',
    }])

    const official = streamListener({ provider: 'deepseek-official' }, () => (async function* () {
      const response = await fetch('https://example.test/deepseek/chat', {
        headers: { 'user-agent': 'harness-default' },
      })
      yield await response.json()
    })())
    const officialChunks = []
    for await (const chunk of official) officialChunks.push(chunk)
    assert.deepEqual(officialChunks, [{ 'user-agent': 'harness-default' }])

    assert.deepEqual(await llm.discoverModels('llm-pi-ai', { provider: 'relay' }), {
      accept: 'application/json',
      'user-agent': 'relay-client/3.0',
      'x-route': 'relay',
    })
    assert.deepEqual(await llm.discoverModels('other-adapter', { provider: 'relay' }), {
      accept: 'application/json',
      'user-agent': 'harness-default',
    })
  } finally {
    for (const dispose of effects.reverse()) dispose()
    globalThis.fetch = nativeFetch
  }
})


test('global headers scope every model stream including official providers', async () => {
  const nativeFetch = globalThis.fetch
  globalThis.fetch = async (_input, init) => new Response(JSON.stringify(
    Object.fromEntries(new Headers(init?.headers)),
  ), { status: 200, headers: { 'content-type': 'application/json' } })
  const effects = []
  let streamListener
  const settings = settingsWithGlobal({ 'User-Agent': 'global/2.0', 'X-Global': 'yes' })
  const ctx = {
    llm: { discoverModels: async () => [] },
    get(service) { return service === 'settings' ? settings : undefined },
    effect(callback) { effects.push(callback()) },
    on(event, listener) {
      assert.equal(event, 'llm/stream')
      streamListener = listener
    },
  }
  try {
    installRequestHeaderBridge(ctx)
    for (const provider of ['deepseek-official', 'openai-official', 'relay']) {
      const stream = streamListener({ provider }, () => (async function* () {
        const response = await fetch('https://example.test/chat', {
          headers: { 'user-agent': 'harness-default', accept: 'application/json' },
        })
        yield await response.json()
      })())
      const chunks = []
      for await (const chunk of stream) chunks.push(chunk)
      assert.deepEqual(chunks, [{
        accept: 'application/json',
        'user-agent': 'global/2.0',
        'x-global': 'yes',
      }])
    }
  } finally {
    for (const dispose of effects.reverse()) dispose()
    globalThis.fetch = nativeFetch
  }
})

test('does not restore another discoverModels wrapper during disposal', async () => {
  const nativeFetch = globalThis.fetch
  globalThis.fetch = nativeFetch
  const base = async () => []
  const llm = { discoverModels: base }
  const settings = settingsWithGlobal({ 'User-Agent': 'global/1.0' })
  const effects = []
  const ctx = {
    llm,
    get(service) { return service === 'settings' ? settings : undefined },
    effect(callback) { effects.push(callback()) },
    on() {},
  }
  try {
    installRequestHeaderBridge(ctx)
    const pluginWrapper = llm.discoverModels
    const laterWrapper = async (...args) => pluginWrapper(...args)
    llm.discoverModels = laterWrapper
    for (const dispose of effects.reverse()) dispose()
    assert.equal(llm.discoverModels, laterWrapper)
  } finally {
    globalThis.fetch = nativeFetch
  }
})

test('preserves discovery cancellation in plain, configured, and already scoped calls', async () => {
  for (const configured of [false, true]) {
    const effects = []
    const controller = new AbortController()
    const llm = {
      async discoverModels(ns, request, signal) {
        assert.equal(this, llm)
        assert.equal(ns, 'llm-pi-ai')
        assert.equal(request.provider, 'relay')
        assert.equal(signal, controller.signal)
        signal.throwIfAborted()
        return []
      },
    }
    const ctx = {
      llm,
      get: () => configured ? settingsWithGlobal({ 'User-Agent': 'global/1.0' }) : undefined,
      on() {},
      effect(callback) { effects.push(callback()) },
    }
    try {
      installRequestHeaderBridge(ctx)
      const discover = () => llm.discoverModels('llm-pi-ai', { provider: 'relay' }, controller.signal)
      await discover()
      await runWithRequestHeaders({ 'X-Draft': 'yes' }, discover)
      controller.abort()
      await assert.rejects(discover, { name: 'AbortError' })
    } finally {
      for (const dispose of effects.reverse()) dispose()
    }
  }
})

test('an unconfigured nested provider cannot inherit another provider headers', async () => {
  const nativeFetch = globalThis.fetch
  globalThis.fetch = async (_input, init) => new Response(JSON.stringify(Object.fromEntries(new Headers(init?.headers))))
  const effects = []
  let stream
  const ctx = {
    llm: { discoverModels: async () => [] },
    get: () => settingsWith({ 'X-Route': 'relay' }),
    on(_event, listener) { stream = listener },
    effect(callback) { effects.push(callback()) },
  }
  try {
    installRequestHeaderBridge(ctx)
    const inner = () => stream({ provider: 'other' }, () => (async function* () {
      yield await (await fetch('https://example.test/other')).json()
    })())
    const outer = stream({ provider: 'relay' }, () => (async function* () {
      for await (const headers of inner()) yield headers
    })())
    assert.deepEqual(await Array.fromAsync(outer), [{}])
  } finally {
    for (const dispose of effects.reverse()) dispose()
    globalThis.fetch = nativeFetch
  }
})

test('concurrent model streams remain isolated and clearing global headers restores defaults', async () => {
  const nativeFetch = globalThis.fetch
  globalThis.fetch = async (_input, init) => new Response(JSON.stringify(Object.fromEntries(new Headers(init?.headers))))
  const effects = []
  let stream
  let globalHeaders = { 'User-Agent': 'global/1.0', 'X-Global': 'yes' }
  const settings = {
    describe: () => [
      { ns: 'dsh-custom-provider-settings', value: { globalHeaders } },
      { ns: 'llm-pi-ai', user: { providers: { relay: { headers: { 'User-Agent': 'local/1.0', 'X-Local': 'yes' } } } } },
    ],
  }
  const ctx = {
    llm: { discoverModels: async () => [] },
    get: () => settings,
    on(_event, listener) { stream = listener },
    effect(callback) { effects.push(callback()) },
  }
  const read = provider => Array.fromAsync(stream({ provider }, () => (async function* () {
    await new Promise(resolve => setImmediate(resolve))
    yield await (await fetch('https://example.test/chat', { headers: { 'User-Agent': 'harness-default' } })).json()
  })()))
  try {
    installRequestHeaderBridge(ctx)
    const [local, official] = await Promise.all([read('relay'), read('deepseek-official')])
    assert.deepEqual(local, [{ 'user-agent': 'local/1.0', 'x-local': 'yes', 'x-global': 'yes' }])
    assert.deepEqual(official, [{ 'user-agent': 'global/1.0', 'x-global': 'yes' }])
    globalHeaders = {}
    assert.deepEqual(await read('deepseek-official'), [{ 'user-agent': 'harness-default' }])
    assert.deepEqual(await read('relay'), [{ 'user-agent': 'local/1.0', 'x-local': 'yes' }])
  } finally {
    for (const dispose of effects.reverse()) dispose()
    globalThis.fetch = nativeFetch
  }
})

test('cancelling stream iteration keeps headers scoped during upstream cleanup', async () => {
  const nativeFetch = globalThis.fetch
  let cleanupHeaders
  globalThis.fetch = async (_input, init) => {
    cleanupHeaders = Object.fromEntries(new Headers(init?.headers))
    return new Response('')
  }
  const effects = []
  let stream
  const ctx = {
    llm: { discoverModels: async () => [] },
    get: () => settingsWith({ 'X-Route': 'relay' }),
    on(_event, listener) { stream = listener },
    effect(callback) { effects.push(callback()) },
  }
  try {
    installRequestHeaderBridge(ctx)
    const output = stream({ provider: 'relay' }, () => (async function* () {
      try { yield 'first'; yield 'second' }
      finally { await fetch('https://example.test/cleanup') }
    })())
    for await (const chunk of output) {
      assert.equal(chunk, 'first')
      break
    }
    assert.deepEqual(cleanupHeaders, { 'x-route': 'relay' })
    await fetch('https://example.test/outside')
    assert.deepEqual(cleanupHeaders, {})
  } finally {
    for (const dispose of effects.reverse()) dispose()
    globalThis.fetch = nativeFetch
  }
})
