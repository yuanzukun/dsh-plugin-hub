import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'
import * as plugin from '../index.js'
import { Context } from '@deepseek-ai/cordis'
import { remoteMethods } from '@deepseek-ai/dsh-typert-protocol'

test('exports live global headers for Config-based Harness settings', async () => {
  assert.equal(typeof plugin.Config, 'function')
  assert.equal(plugin.Config.dict.globalHeaders.meta.volatile, true)
  assert.deepEqual(plugin.Config({}).globalHeaders.get(), {})
  assert.deepEqual(plugin.Config({
    globalHeaders: { 'User-Agent': 'client/1.0', 'X-Tenant': 'test' },
  }).globalHeaders.get(), { 'User-Agent': 'client/1.0', 'X-Tenant': 'test' })
  const patch = await readFile(new URL('../cordis.patch.yml', import.meta.url), 'utf8')
  assert.match(patch, new RegExp(`- id: ${plugin.SETTINGS_NAMESPACE}(?:\\r?\\n|$)`))
})

test('rejects invalid persisted global headers before they reach fetch', () => {
  assert.equal(typeof plugin.Config, 'function')
  for (const globalHeaders of [
    { 'Bad Header': 'value' },
    { '': 'value' },
    { 'X-Test': 'first\r\nInjected: value' },
    { 'X-Test': 'first\nsecond' },
    { 'X-Test': 12 },
    { 'X-Test': null },
  ]) assert.throws(() => plugin.Config({ globalHeaders }))
  assert.doesNotThrow(() => plugin.Config({ globalHeaders: { 'X-Empty': '' } }))
})

test('activates request-header support without an HTTP server on desktop', () => {
  assert.equal(plugin.inject.includes('webServer'), false)
  const effects = []
  const settings = { describe: () => [] }
  const ctx = {
    llm: { discoverModels: async () => [] },
    settings,
    get: service => service === 'settings' ? settings : undefined,
    inject(services, callback) {
      if (services.every(service => ctx[service] !== undefined)) callback(ctx)
    },
    on() {},
    effect(callback) { effects.push(callback()) },
  }
  try {
    assert.doesNotThrow(() => plugin.apply(ctx))
    assert.ok(effects.length > 0)
  } finally {
    for (const dispose of effects.reverse()) dispose?.()
  }
})

test('exposes draft model discovery through the transport-independent Remote service', async () => {
  assert.equal(typeof plugin.__test.DraftModelDiscovery, 'function')
  const ctx = new Context()
  const controller = new AbortController()
  ctx.provide('settings', { describe: () => [{
    ns: plugin.SETTINGS_NAMESPACE, value: { globalHeaders: { 'User-Agent': 'global/1.0', 'X-Global': 'yes' } },
  }] })
  ctx.provide('llm', {
    async discoverModels(ns, request, signal) {
      assert.equal(ns, 'llm-pi-ai')
      assert.equal(signal, controller.signal)
      assert.deepEqual(request.headers, { 'user-agent': 'draft/2.0', 'X-Global': 'yes' })
      return [{ id: 'test-model' }]
    },
  })
  try {
    const service = new plugin.__test.DraftModelDiscovery(ctx)
    assert.deepEqual(remoteMethods(service).map(({ method }) => method), ['discoverModels'])
    assert.deepEqual(await service.discoverModels({
      provider: 'relay', baseURL: 'https://example.test/v1', api: 'openai-completions',
      headers: { 'user-agent': 'draft/2.0' },
    }, controller.signal), [{ id: 'test-model' }])
  } finally {
    await ctx.fiber.dispose()
  }
})

test('Remote discovery validates payloads, hides upstream secrets, and preserves cancellation', async () => {
  const ctx = new Context()
  let called = false
  ctx.provide('settings', { describe: () => [] })
  ctx.provide('llm', { async discoverModels(_ns, _request, signal) {
    called = true
    signal?.throwIfAborted()
    throw new Error('upstream contains a private credential')
  } })
  const input = { provider: 'relay', baseURL: 'https://example.test/v1', api: 'openai-completions', headers: {} }
  try {
    const service = new plugin.__test.DraftModelDiscovery(ctx)
    await assert.rejects(service.discoverModels({ ...input, headers: { 'Bad Header': 'value' } }), /header name is invalid/)
    assert.equal(called, false)
    await assert.rejects(service.discoverModels({ ...input, headers: { 'X-Large': 'x'.repeat(plugin.__test.MAX_BODY_BYTES) } }), /too large/)
    assert.equal(called, false)
    await assert.rejects(service.discoverModels(input), { message: 'model discovery failed' })
    const controller = new AbortController()
    controller.abort()
    await assert.rejects(service.discoverModels(input, controller.signal), { name: 'AbortError' })
  } finally {
    await ctx.fiber.dispose()
  }
})
