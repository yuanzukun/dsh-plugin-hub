# DSH 自定义模型提供方设置插件

中文 | [English](README.en.md)

为 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 网页端和桌面端增加全局模型请求头，并为用户添加的自定义模型提供方补充局部请求头、图像输入、思考等级和原生 system 角色兼容设置。插件通过 DSH 插件机制加载，不修改 Harness 源代码。

当前版本为 **0.10.0**，适配 Harness **0.2.2-rc.1** 的设置接口、网页组件和桌面通信方式。安装时分别选择网页端的 `web` profile 或桌面端的 `desktop` profile。

[v0.10.0 发布说明](https://github.com/supersealwqas/dsh-custom-provider-settings/releases/tag/v0.10.0) · [下载 0.10.0 TGZ 安装包](https://github.com/supersealwqas/dsh-custom-provider-settings/releases/download/v0.10.0/dsh-custom-provider-settings-0.10.0.tgz)

> 全局请求头会作用于所有渠道和所有模型，包括 DeepSeek 官方、内置第三方和自定义提供方；局部请求头、模型能力和兼容性设置仍只显示在带“自定义”标记的提供方中。

## 功能

- 为每个自定义提供方配置 `User-Agent` 和其他 HTTP 请求头。
- 在网页端或桌面端配置全局 `User-Agent` 和其他请求头，作为所有模型 API 请求的通用请求头。
- 为全局和局部 `User-Agent` 提供常用预设，同时保留自由输入。
- 将同一组自定义请求头用于普通模型请求和“获取可用模型”。
- 将每个自定义模型声明为仅文本或支持文本与图像输入。
- 配置模型可选择的思考等级，并把每个等级映射为 API 实际接收的值。
- 设置提供方默认思考等级。
- 为 `openai-completions` 提供方配置思考参数格式。
- 按自定义提供方管理 DSH 原生的 `compat.supportsDeveloperRole`，兼容拒绝 `developer` 消息的 OpenAI 协议第三方接口。
- 清空全局请求头后恢复 Harness 原有请求头行为。

## 实机演示

### 自定义提供方设置

插件会在原有的自定义提供方表单中插入请求头和模型能力配置。以下为较早版本的功能示意图；新版 Harness 的按钮和布局有所调整。红框区域展示了 `User-Agent`、其他请求头、图像输入、默认思考等级以及每个模型的思考等级映射。

![自定义提供方的请求头、图像输入和思考等级设置](assets/img01.png)

### 思考等级选择器

启用的思考等级会出现在对话输入框中。图中提供 Default、Off、Low、Medium、High、Xhigh 和 Max，并选择了 Xhigh。

![DeepSeek Harness 对话输入框中的思考等级选择器](assets/img02.png)

## 安装

### 安装前准备

- DeepSeek Harness `0.2.2-rc.1`。网页端使用官方 CLI，桌面端使用同版本桌面程序附带的 CLI。
- 从源码打包或使用独立 CLI 时，需要 Node.js `^22.19.0` 或 `>=24.0.0`，建议 Node.js 24 LTS。
- 独立 CLI 的 `dsh plugin` 使用 pnpm 管理 profile 中的插件；桌面端请使用下文的内置 CLI。

可先在 PowerShell 中检查环境：

```powershell
node --version
npx --version
corepack enable
pnpm --version
```

如果 `corepack enable` 因权限不足失败，请使用管理员 PowerShell 再执行一次，或者按照 [pnpm 官方安装说明](https://pnpm.io/installation)安装。

安装、升级或卸载插件前，先退出对应的网页服务或桌面程序，操作完成后再重新启动。

### 下载 0.10.0 安装包（推荐）

从 [v0.10.0 Release](https://github.com/supersealwqas/dsh-custom-provider-settings/releases/tag/v0.10.0) 下载 `dsh-custom-provider-settings-0.10.0.tgz`，或在 PowerShell 中将它保存到当前目录的 `dist` 文件夹：

```powershell
New-Item -ItemType Directory -Force .\dist | Out-Null
Invoke-WebRequest -Uri 'https://github.com/supersealwqas/dsh-custom-provider-settings/releases/download/v0.10.0/dsh-custom-provider-settings-0.10.0.tgz' -OutFile .\dist\dsh-custom-provider-settings-0.10.0.tgz
```

下方两端的安装命令都使用这个文件。手动下载时，可将安装包放入 `dist`，或将命令中的路径改为实际文件位置。

### 从源码生成安装包（可选）

也可以在本仓库目录执行以下命令，从当前源码生成安装包：

```powershell
npm install
npm test
New-Item -ItemType Directory -Force .\dist | Out-Null
npm pack --pack-destination .\dist
```

已下载 Release 安装包时，无需重复打包。

### 安装到网页端

```powershell
npx --yes -p @deepseek-ai/dsh@0.2.2-rc.1 dsh plugin --profile web add .\dist\dsh-custom-provider-settings-0.10.0.tgz
npx --yes -p @deepseek-ai/dsh@0.2.2-rc.1 dsh web
```

WebUI 默认监听 `127.0.0.1:3080`；使用启动时输出的链接打开页面。如果全局 `dsh --version` 已显示 `0.2.2-rc.1`，可以使用更短的 `dsh plugin ...` 和 `dsh web`。

### 安装到 Windows 桌面端

使用桌面程序安装目录下的 `resources\runtime\cli\bin\dsh.cmd`。下面以安装在 `D:\App\DeepSeek Harness` 为例，路径不同请替换为实际目录：

```powershell
$desktopCli = 'D:\App\DeepSeek Harness\resources\runtime\cli\bin\dsh.cmd'
& $desktopCli --version
& $desktopCli plugin --profile desktop add (Resolve-Path .\dist\dsh-custom-provider-settings-0.10.0.tgz).Path
```

完成后通过桌面快捷方式重新打开 DeepSeek Harness。普通 npm CLI 不负责 `desktop` profile，不能用全局 `dsh` 代替这里的内置 CLI。

两个 profile 独立管理插件和配置。网页端安装成功后，桌面端仍需单独安装；反之亦然。若设置过自定义 `DSH_HOME`，命令与对应应用必须使用同一个目录。

`dist` 目录和 TGZ 文件已被 `.gitignore` 忽略，不随源码提交。

### 升级

退出对应应用后，使用更新后的 TGZ 再次执行该 profile 的 `add` 命令即可升级，不需要先卸载。重新打包源码后，也需要重新安装安装包，再启动应用。

同版本重新打包测试时，请先给 TGZ 换一个新文件名（例如加上内容哈希），再执行 `add`；否则 pnpm 可能沿用同路径安装包的缓存。

### 卸载

```powershell
# 网页端
npx --yes -p @deepseek-ai/dsh@0.2.2-rc.1 dsh plugin --profile web remove dsh-custom-provider-settings
# 桌面端，沿用上面的 $desktopCli
& $desktopCli plugin --profile desktop remove dsh-custom-provider-settings
```

重新启动对应应用后，插件加入的配置区域和全局请求头覆盖停止生效。图像输入、思考等级与 `compat` 属于 Harness 原生提供方配置，可在模型设置中继续管理。

## 使用方法

1. 打开“设置” > “模型”。
2. 在模型列表顶部的“全局模型请求头”区域填写 `User-Agent` 或其他请求头。留空表示继续使用 Harness 内置默认请求头。
3. 需要时编辑带“自定义”标记且已经包含模型的提供方，或者选择“添加模型提供商” > “自定义模型 API”并填写模型。
4. 在插件插入的“请求头”区域配置仅针对该自定义提供方的请求头；同名时由这个局部值覆盖全局值。
5. 如果兼容的 OpenAI 协议自定义提供方拒绝 `developer` 角色，请勾选“使用 system 角色发送系统提示词”。已有原生 `supportsDeveloperRole: false` 配置会自动显示为已勾选。
6. 在“模型能力”中选择每个模型的输入能力和思考能力。只有 API 和模型都支持图像输入时，才选择“文本与图像”。
7. 使用原表单的“保存”或“创建提供商”按钮。Harness 原表单保存成功后，插件会继续保存扩展字段。
8. 新建对话，选择模型；全局请求头会自动用于该模型请求。

“获取可用模型”会使用同一表单中当前填写的请求头，包括尚未保存的值。因此，必须依赖特定 `User-Agent` 或其他请求头的接口也可以正常获取模型列表。

清空尚未保存的局部请求头后再获取模型，会移除该提供方以前保存的额外头，并保留 Harness 的默认头及凭据。桌面端通过其原生通信通道完成发现，不要求启动额外网页服务。

全局请求头也会用于模型发现请求。请求头合并顺序为 Harness 默认值、全局请求头、自定义提供方局部请求头，因此局部同名字段的优先级最高。

全局和自定义提供方局部的 `User-Agent` 输入框都提供以下预设：

- `claude-cli/2.1.161 (external, cli)`
- `claude-cli/2.1.161`
- `claude-code/1.0.0`
- `claude-code/0.1.0`
- `Kilo-Code/1.0`

选择预设后会替换输入框当前内容；输入框仍然可以手动编辑，也可以填写列表之外的任意 `User-Agent`。

## 验证图像输入

1. 将模型的输入能力设为“文本与图像”，然后保存提供方。
2. 使用该模型新建对话。
3. 上传一张包含唯一字符串的 PNG 或 JPEG，例如 `VISION-7392`。
4. 要求模型只返回图片中看到的字符串。

模型正确返回字符串，说明 Harness 已接受附件，并且接口成功处理了图片。这个设置只是向 Harness 声明模型能力，无法让原本不支持视觉输入的 API 或模型获得图像识别能力。

## system 角色兼容

这个复选框只是 DSH 原生 pi-ai 兼容配置的 WebUI，不会由插件拦截或改写 JSON 请求体。

- 勾选：为当前自定义提供方写入 `compat.supportsDeveloperRole: false`。
- 取消勾选：只删除 `supportsDeveloperRole`，恢复 DSH/pi-ai 自动检测。
- 作用范围：影响当前提供方下面的所有模型，不影响其他提供方。
- 字段保留：不会删除同一 `compat` 下的 `thinkingFormat`、`supportsReasoningEffort` 等其他配置。

只有原生 pi-ai 兼容类型支持该字段的 OpenAI 协议自定义提供方才会显示此选项。

## 保存的配置

新版 Harness 将可编辑配置写入对应 profile 的 `cordis.patch.yml`。默认位置为：

- 网页端：`%USERPROFILE%\.dsh\profiles\web\cordis.patch.yml`
- 桌面端：`%USERPROFILE%\.dsh\profiles\desktop\cordis.patch.yml`

如果设置了 `DSH_HOME`，使用该目录下的 `profiles\<profile>\cordis.patch.yml`。也可以通过“设置”中的“打开配置文件”查看当前应用使用的文件。以下是配置层级示例：

```yaml
- id: dsh-custom-provider-settings
  name: dsh-custom-provider-settings
  config:
    globalHeaders:
      User-Agent: my-global-client/1.0
      X-Client-Name: all-models

- id: llm-pi-ai
  name: '@deepseek-ai/dsh-llm-pi-ai'
  config:
    providers:
      relay:
        headers:
          User-Agent: my-client/1.0
          X-Client-Name: my-client
        reasoning: high
        compat:
          thinkingFormat: deepseek
          supportsDeveloperRole: false
        models:
          - id: example-model
            input: [text, image]
            reasoningEfforts:
              low: low
              medium: medium
              high: high
```

请求头值以普通文本存入 profile 配置。API 密钥和其他秘密信息应放在 Harness 的凭据字段中，不要写进自定义请求头。旧版 `settings.yaml` 的迁移由 Harness 处理；它已不是新版的当前配置文件。

清空全局请求头会删除全局覆盖配置，并恢复 Harness 原有的请求头行为；清空某个提供方请求头只会清除该提供方的额外覆盖。

## 常见问题

### 启动时报错 `Cannot read properties of undefined (reading 'llm')`

建议将 Harness 升级到本次验证的 `0.2.2-rc.1`，按上方步骤安装插件 `0.10.0`，然后重启对应应用。插件 `0.5.0` 曾被报告在新版 Harness 中出现此错误；`0.10.0` 优先使用新版 Remote 接口，并处理旧 `connection.api` 缺失的情况，无需修改模型 JSON 或删除配置。原报告的完整旧环境尚未复现验证。参见 [Related issue #1](https://github.com/supersealwqas/dsh-custom-provider-settings/issues/1)。

### 页面没有显示插件配置

确认网页端安装到了 `web` profile，桌面端安装到了 `desktop` profile，并在安装后重启对应应用。全局请求头区域位于“模型”列表顶部；自定义提供方中没有模型时，不会出现可编辑的模型能力配置。旧版 0.9.0 在新版 Harness 中存在组件和设置接口不兼容，请安装 0.10.0。

### “获取可用模型”仍然失败

先确认 Base URL、API Key 和 API 协议正确，再检查接口要求的 `User-Agent` 或其他请求头是否已经填写。插件会把表单中尚未保存的请求头一起用于本次模型列表请求。

### 对话中没有思考等级或图像上传入口

保存提供方后新建对话并重新选择模型。思考等级必须在对应模型上启用；图像上传还要求该模型被声明为“文本与图像”。

### 第三方 DeepSeek 接口拒绝 developer 角色

编辑对应的兼容 OpenAI 协议自定义提供方，勾选“使用 system 角色发送系统提示词”并保存，然后新建对话。这个设置只作用于当前提供方，官方 DeepSeek 和其他自定义提供方的消息角色保持原样。

### 接口可以使用，但复选框显示未勾选

重新启动应用后再打开提供方编辑页面。复选框会读取原生 `llm-pi-ai.providers.<provider>.compat.supportsDeveloperRole` 的有效值。如果 profile 配置中已经是 `false`，界面仍未勾选，网页端可强制刷新页面；桌面端请完全退出后重启，确保加载当前插件版本。

## 验证结果

0.10.0 于 2026-11-04 完成以下验证。除旧版回归外，Harness 版本为 `0.2.2-rc.1`；不同测试组覆盖的范围如下：

| 测试组 | 结果 | 覆盖范围 |
| --- | --- | --- |
| 自动测试 | 30 项通过 | 客户端保存、设置接口、模型发现、请求头与包配置 |
| 真实 Harness 请求链 + 本地模拟 API | 20 项通过 | 多渠道请求头、system 角色、图像数据、7 个思考等级和 8 种参数格式 |
| 真实网页界面 + 本地模拟 API | 19 项通过 | 中英文界面、保存与清空、草稿模型发现、原生字段保留、模型重排/删除、刷新恢复 |
| Windows 桌面核心界面 | 10 项通过 | 表单显示、模型发现、请求头与 system 设置保存/重开/清空、原有配置保留和测试提供方删除 |
| Harness `0.2.1-rc.5` 后端回归 | 2 组各 9 项通过 | 原有 Schemastery 3.18.5，以及插件单独使用 3.19.0 的依赖组合；覆盖加载、原生 Config、无 HTTP 服务的 RPC 和请求头 |
| 真实 API 网页验证 | 15 项通过 | 实际模型发现、文本和图片对话、High 请求参数、请求头保存/清空、配置与会话刷新恢复 |
| 独立真实 API 验证 | 模型列表 + 3 次推理通过 | 文本流式回复、High 思考内容和合成图识别 |

真实网页和独立 API 验证使用 `gemini-3.5-flash-lite`。网页图片请求记录了 `reasoningEffort=high`，正确识别图形，但该次回复没有 `reasoning` 内容块；独立 API 思考测试另返回了 `reasoning_content`。桌面端验证限于表中核心设置流程，未覆盖真实模型推理或全部功能。

## 兼容性与限制

- 0.10.0 的本次适配与实机验证基线为 DeepSeek Harness `0.2.2-rc.1` 的网页端和 Windows 桌面端。
- 旧版回归覆盖后端兼容性，不等同于旧版桌面界面的全功能实测。
- 本地模拟 API 验证参数和数据的实际发送；真实 API 验证限于上述接口和模型能力，不代表任意第三方模型都支持这些能力。
- 全局请求头会注入所有模型渠道；自定义提供方专属的图像输入、思考等级、兼容性设置和请求头编辑器只挂载到 Harness 报告为 `declared: true` 的提供方。
- 插件不会修改 DeepSeek 官方和内置第三方提供方的模型配置，但全局请求头仍会作用于它们的 API 请求。
- 保存插件设置时，会保留原表单管理的模型名称、上下文窗口、最大输出值和其他字段。
- 本插件通过原页面的无障碍标签定位表单，并在运行时挂载 React 控件，因此 Harness 以后修改表单结构时可能需要更新插件。
- 插件不会修改 DeepSeek Harness 源代码文件。

## 开发与验证

```powershell
npm test
node --check client.js
npm pack --dry-run
```

## 致谢

思考等级客户端逻辑改编自 [JuneLearn/dsh-reasoning-settings](https://github.com/JuneLearn/dsh-reasoning-settings)，遵循 MIT License。

## 许可证

本项目使用 MIT License，详见 [LICENSE](LICENSE)。许可证同时保留本仓库和改编来源的版权声明。
