﻿param([switch]$DryRun)

$ErrorActionPreference = 'SilentlyContinue'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$configPath = Join-Path $scriptDir 'config.json'
$config = @{}

if (Test-Path -LiteralPath $configPath) {
  try {
    $json = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
    foreach ($p in $json.PSObject.Properties) { $config[$p.Name] = $p.Value }
  } catch {}
}

$defaultPort = 3080
if ($config.port -ne $null -and "$($config.port)" -match '^\d+$') {
  $defaultPort = [int]$config.port
}

$workspace = [string]$config.workspace
if ([string]::IsNullOrWhiteSpace($workspace) -or -not (Test-Path -LiteralPath $workspace)) {
  $workspace = $env:USERPROFILE
}

$dshCmd = [string]$config.dshCommand
if ([string]::IsNullOrWhiteSpace($dshCmd)) {
  $dshCmd = Join-Path $env:APPDATA 'npm\dsh.cmd'
}
if (-not (Test-Path -LiteralPath $dshCmd)) {
  $found = Get-Command dsh.cmd -ErrorAction SilentlyContinue
  if ($found) { $dshCmd = $found.Source }
}
if (-not (Test-Path -LiteralPath $dshCmd)) {
  $found = Get-Command dsh -ErrorAction SilentlyContinue
  if ($found) { $dshCmd = $found.Source }
}

function Get-DshPort {
  param([int]$ProcessId)
  $c = Get-NetTCPConnection -OwningProcess $ProcessId -State Listen -ErrorAction SilentlyContinue |
    Where-Object { $_.LocalAddress -eq '127.0.0.1' -or $_.LocalAddress -eq '::1' } |
    Select-Object -First 1
  if (-not $c) {
    $c = Get-NetTCPConnection -OwningProcess $ProcessId -State Listen -ErrorAction SilentlyContinue |
      Select-Object -First 1
  }
  if ($c) { return [int]$c.LocalPort }
  return $null
}

$dshProc = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
  $_.Name -eq 'node.exe' -and
  $_.CommandLine -match '(?i)@deepseek-ai[\\/]dsh[\\/]lib[\\/]bin\.js' -and
  $_.CommandLine -match '(?i)(^|\s)web(\s|$)'
} | Select-Object -First 1

if ($dshProc) {
  $port = Get-DshPort -ProcessId $dshProc.ProcessId
  for ($i = 0; $i -lt 20 -and -not $port; $i++) {
    Start-Sleep -Milliseconds 250
    $port = Get-DshPort -ProcessId $dshProc.ProcessId
  }
  if (-not $port) { $port = $defaultPort }
  $url = "http://127.0.0.1:$port/"
  if ($DryRun) { Write-Host "DSH Web is running. Open: $url"; exit 0 }
  Start-Process $url
  exit 0
}

if (-not (Test-Path -LiteralPath $dshCmd)) {
  if ($DryRun) { Write-Host 'dsh command was not found.'; exit 1 }
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show('未找到 dsh 命令，请先安装 DSH 并确保 dsh 在 PATH 中。', 'DSH Launcher') | Out-Null
  exit 1
}

if ($DryRun) { Write-Host "DSH Web is not running. Start from: $workspace"; exit 0 }
Start-Process -FilePath $dshCmd -ArgumentList 'web' -WorkingDirectory $workspace -WindowStyle Minimized