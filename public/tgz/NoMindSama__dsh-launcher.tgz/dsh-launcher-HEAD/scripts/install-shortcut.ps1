﻿param(
  [string]$LauncherScript = (Join-Path $PSScriptRoot 'launch-web.ps1'),
  [string]$IconPath = (Join-Path $PSScriptRoot 'icon.ico'),
  [string]$ShortcutName = 'DSH 工作台',
  [string]$WorkingDirectory = $env:USERPROFILE,
  [string]$DesktopPath = '',
  [switch]$DryRun
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path -LiteralPath $LauncherScript)) { throw "Launcher script not found: $LauncherScript" }
if (-not (Test-Path -LiteralPath $IconPath)) { throw "Icon not found: $IconPath" }
if ([string]::IsNullOrWhiteSpace($WorkingDirectory) -or -not (Test-Path -LiteralPath $WorkingDirectory)) {
  $WorkingDirectory = $env:USERPROFILE
}
if ([string]::IsNullOrWhiteSpace($DesktopPath) -or -not (Test-Path -LiteralPath $DesktopPath)) {
  $DesktopPath = [Environment]::GetFolderPath('Desktop')
}

$powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$lnkPath = Join-Path $DesktopPath ($ShortcutName + '.lnk')

if ($DryRun) {
  Write-Host "Shortcut: $lnkPath"
  Write-Host "Target: $powershell"
  Write-Host "Arguments: -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$LauncherScript`""
  Write-Host "Icon: $IconPath"
  Write-Host "WorkingDirectory: $WorkingDirectory"
  exit 0
}

$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut($lnkPath)
$sc.TargetPath = $powershell
$sc.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $LauncherScript + '"'
$sc.WorkingDirectory = $WorkingDirectory
$sc.IconLocation = "$IconPath,0"
$sc.Description = 'Launch DSH Web from the desktop'
$sc.WindowStyle = 1
$sc.Save()

Write-Host "Shortcut created: $lnkPath"