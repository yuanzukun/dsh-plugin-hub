import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
import { musicWidgetScript } from './widget-source.ts'

export const name = 'dsh-music-http'
export const inject = ['webServer', 'music']

const PREFIX = '/dsh-music'

function json(res: ServerResponse, status: number, body: unknown) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  })
  res.end(JSON.stringify(body))
}

async function readBody(req: IncomingMessage): Promise<Record<string, unknown>> {
  if (req.method !== 'POST') return {}
  const chunks: Buffer[] = []
  for await (const chunk of req) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
  }
  if (chunks.length === 0) return {}
  return JSON.parse(Buffer.concat(chunks).toString('utf8')) as Record<string, unknown>
}

function routePath(req: IncomingMessage): string {
  const url = new URL(req.url ?? PREFIX, 'http://127.0.0.1')
  return url.pathname.replace(/\/$/, '') || PREFIX
}

export function apply(ctx: Context) {
  ctx.effect(() => {
    const disposeRoute = ctx.webServer.register({
    kind: 'prefix',
    path: PREFIX,
    handler: async (req, res) => {
      try {
        const path = routePath(req)
        const body = await readBody(req)

        if (path === `${PREFIX}/widget.js` && req.method === 'GET') {
          res.writeHead(200, {
            'content-type': 'text/javascript; charset=utf-8',
            'cache-control': 'no-store',
          })
          res.end(musicWidgetScript)
          return
        }

        if (path === `${PREFIX}/status` && req.method === 'GET') {
          return json(res, 200, { ok: true, snapshot: ctx.music.status() })
        }

        if (path === `${PREFIX}/library` && req.method === 'GET') {
          const tracks = await ctx.music.list(200)
          return json(res, 200, { ok: true, tracks, snapshot: ctx.music.status() })
        }

        if (path === `${PREFIX}/play` && req.method === 'POST') {
          const query = typeof body.query === 'string' ? body.query : ''
          if (!query.trim()) return json(res, 400, { ok: false, error: 'query is required' })
          return json(res, 200, await ctx.music.play(query, 'now'))
        }

        if (path === `${PREFIX}/pause` && req.method === 'POST') {
          return json(res, 200, ctx.music.pause())
        }

        if (path === `${PREFIX}/resume` && req.method === 'POST') {
          return json(res, 200, ctx.music.resume())
        }

        if (path === `${PREFIX}/skip` && req.method === 'POST') {
          return json(res, 200, await ctx.music.skip())
        }

        json(res, 404, { ok: false, error: 'unknown music route' })
      } catch (error) {
        json(res, 500, { ok: false, error: error instanceof Error ? error.message : String(error) })
      }
    },
    })
    const disposeTap = ctx.webServer.tapIndex((html) => {
      if (html.includes('/dsh-music/widget.js')) return html
      return html.replace('</body>', '<script src="/dsh-music/widget.js" defer></script></body>')
    })
    return () => {
      disposeRoute()
      disposeTap()
    }
  })
}
