import { spawn, spawnSync, type ChildProcess } from 'node:child_process'
import { existsSync } from 'node:fs'
import { readdir, stat } from 'node:fs/promises'
import { homedir } from 'node:os'
import { basename, extname, isAbsolute, join, relative, resolve } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import { MusicService } from './service.ts'
import type {
  AudioBackend,
  BackendOption,
  CatalogEntry,
  MusicActionResult,
  MusicConfig,
  PlayerSnapshot,
  PlaybackState,
  Track,
} from './types.ts'

const DEFAULT_EXTENSIONS = ['mp3', 'flac', 'm4a', 'wav', 'aac', 'ogg']

export function expandHome(path: string): string {
  if (path === '~') return homedir()
  if (path.startsWith('~/')) return join(homedir(), path.slice(2))
  return path
}

function commandExists(command: string): boolean {
  const result = spawnSync('which', [command], { encoding: 'utf8' })
  return result.status === 0
}

export function resolveBackend(option: BackendOption): AudioBackend {
  if (option === 'afplay' || option === 'mpv') return option
  return commandExists('mpv') ? 'mpv' : 'afplay'
}

function isAudioFile(path: string, extensions: Set<string>): boolean {
  const ext = extname(path).slice(1).toLowerCase()
  return extensions.has(ext)
}

function trackFromFile(libraryDir: string, path: string): Track {
  return {
    title: basename(path, extname(path)),
    path,
    relative: relative(libraryDir, path) || basename(path),
  }
}

async function scanLibrary(libraryDir: string, extensions: Set<string>): Promise<Track[]> {
  const tracks: Track[] = []

  async function walk(dir: string) {
    let entries
    try {
      entries = await readdir(dir, { withFileTypes: true })
    } catch {
      return
    }

    for (const entry of entries) {
      if (entry.name.startsWith('.')) continue
      const full = join(dir, entry.name)
      if (entry.isDirectory()) {
        await walk(full)
      } else if (entry.isFile() && isAudioFile(full, extensions)) {
        tracks.push(trackFromFile(libraryDir, full))
      }
    }
  }

  await walk(libraryDir)
  tracks.sort((a, b) => a.relative.localeCompare(b.relative))
  return tracks
}

function youtubeIdFromQuery(query: string): string | null {
  const trimmed = query.trim()
  const prefixed = /^youtube:([A-Za-z0-9_-]{6,})$/.exec(trimmed)
  if (prefixed) return prefixed[1]
  try {
    const url = new URL(trimmed)
    if (!url.hostname.includes('youtube.com') && url.hostname !== 'youtu.be') return null
    if (url.hostname === 'youtu.be') return url.pathname.replace('/', '') || null
    return url.searchParams.get('v')
  } catch {
    return null
  }
}

function catalogTracks(entries: CatalogEntry[]): Track[] {
  return entries.map(entry => ({
    title: entry.title,
    path: `youtube:${entry.youtubeId}`,
    relative: 'YouTube',
    kind: 'youtube' as const,
    youtubeId: entry.youtubeId,
  }))
}

function resolveQuery(tracks: Track[], libraryDir: string, extensions: Set<string>, query: string): {
  kind: 'play' | 'not_found' | 'ambiguous'
  track?: Track
  matches?: Track[]
} {
  const q = query.trim()
  if (!q) return { kind: 'not_found', matches: [] }

  const youtubeId = youtubeIdFromQuery(q)
  if (youtubeId) {
    const existing = tracks.find(track => track.youtubeId === youtubeId)
    return { kind: 'play', track: existing ?? {
      title: 'YouTube',
      path: `youtube:${youtubeId}`,
      relative: 'YouTube',
      kind: 'youtube',
      youtubeId,
    } }
  }

  const byPath = tracks.find(track => track.path === q || track.relative === q)
  if (byPath) return { kind: 'play', track: byPath }

  if (isAbsolute(q) && existsSync(q) && isAudioFile(q, extensions)) {
    return { kind: 'play', track: trackFromFile(libraryDir, q) }
  }

  const needle = q.toLowerCase()
  const matches = tracks.filter(track =>
    track.title.toLowerCase().includes(needle)
    || track.relative.toLowerCase().includes(needle)
    || basename(track.path).toLowerCase().includes(needle),
  )

  if (matches.length === 0) return { kind: 'not_found' }
  if (matches.length === 1) return { kind: 'play', track: matches[0] }

  const exactTitle = matches.filter(track => track.title.toLowerCase() === needle)
  if (exactTitle.length === 1) return { kind: 'play', track: exactTitle[0] }

  return { kind: 'ambiguous', matches: matches.slice(0, 20) }
}

class AudioProcess {
  private child: ChildProcess | null = null
  private generation = 0
  private state: PlaybackState = 'idle'
  private current: Track | null = null
  private readonly queue: Track[] = []
  private readonly backend: AudioBackend
  private readonly onChange: () => void

  constructor(backend: AudioBackend, onChange: () => void) {
    this.backend = backend
    this.onChange = onChange
  }

  snapshot(libraryDir: string, libraryCount: number): PlayerSnapshot {
    return {
      state: this.state,
      current: this.current,
      queue: [...this.queue],
      backend: this.backend,
      libraryDir,
      libraryCount,
    }
  }

  get playing(): boolean {
    return this.state === 'playing'
  }

  enqueue(track: Track): void {
    this.queue.push(track)
    this.onChange()
  }

  async playNow(track: Track): Promise<void> {
    this.stopChild()
    this.current = track
    this.state = 'playing'
    if (track.kind !== 'youtube') this.startChild(track)
    this.onChange()
  }

  pause(): void {
    if (this.state !== 'playing') return
    if (this.current?.kind === 'youtube') {
      this.state = 'paused'
      this.onChange()
      return
    }
    if (!this.child?.pid) return
    try {
      process.kill(this.child.pid, 'SIGSTOP')
      this.state = 'paused'
      this.onChange()
    } catch {
      // Process already gone.
    }
  }

  resume(): void {
    if (this.state !== 'paused') return
    if (this.current?.kind === 'youtube') {
      this.state = 'playing'
      this.onChange()
      return
    }
    if (!this.child?.pid) return
    try {
      process.kill(this.child.pid, 'SIGCONT')
      this.state = 'playing'
      this.onChange()
    } catch {
      // Process already gone.
    }
  }

  async skip(): Promise<void> {
    const next = this.queue.shift() ?? null
    this.stopChild()
    if (next) {
      await this.playNow(next)
      return
    }
    this.current = null
    this.state = 'idle'
    this.onChange()
  }

  dispose(): void {
    this.queue.length = 0
    this.stopChild()
    this.current = null
    this.state = 'idle'
  }

  private startChild(track: Track) {
    const generation = ++this.generation
    const args = this.backend === 'mpv'
      ? ['--no-video', '--no-terminal', '--really-quiet', track.path]
      : [track.path]
    const child = spawn(this.backend, args, { stdio: 'ignore' })
    this.child = child

    const settleIdle = () => {
      if (generation !== this.generation) return
      this.generation += 1
      this.child = null
      const next = this.queue.shift() ?? null
      if (next) {
        void this.playNow(next)
        return
      }
      this.current = null
      this.state = 'idle'
      this.onChange()
    }

    child.on('error', settleIdle)
    child.on('exit', settleIdle)
  }

  private stopChild() {
    this.generation += 1
    const child = this.child
    this.child = null
    if (!child?.pid) return
    try {
      process.kill(child.pid, 'SIGCONT')
    } catch {
      // Not paused, or already gone.
    }
    try {
      child.kill('SIGTERM')
    } catch {
      // Already gone.
    }
  }
}

export class LocalMusic extends MusicService {
  static name = 'dsh-music-local'

  private readonly libraryDir: string
  private readonly extensions: Set<string>
  private readonly backend: AudioBackend
  private readonly audio: AudioProcess
  private readonly remoteTracks: Track[]
  private tracks: Track[] = []
  private refreshPromise: Promise<void> | null = null

  constructor(ctx: Context, config: MusicConfig) {
    super(ctx)
    this.remoteTracks = catalogTracks(config.catalog ?? [])
    this.libraryDir = resolve(expandHome(config.libraryDir))
    const extensionList = config.extensions?.length ? config.extensions : DEFAULT_EXTENSIONS
    this.extensions = new Set(extensionList.map(ext => ext.toLowerCase()))
    this.backend = resolveBackend(config.backend)
    this.audio = new AudioProcess(this.backend, () => this.emitState(this.status()))

    ctx.effect(() => {
      void this.refresh()
      return () => this.audio.dispose()
    })
  }

  private allTracks(): Track[] {
    return [...this.remoteTracks, ...this.tracks]
  }

  async search(query?: string): Promise<Track[]> {
    await this.refresh()
    const needle = query?.trim().toLowerCase()
    const tracks = this.allTracks()
    if (!needle) return tracks.slice(0, 30)
    return tracks.filter(track =>
      track.title.toLowerCase().includes(needle)
      || track.relative.toLowerCase().includes(needle),
    ).slice(0, 30)
  }

  async list(limit = 200): Promise<Track[]> {
    await this.refresh()
    return this.allTracks().slice(0, Math.max(0, limit))
  }

  async play(query: string, mode: 'now' | 'queue' = 'queue'): Promise<MusicActionResult> {
    await this.refresh()
    const resolved = resolveQuery(this.allTracks(), this.libraryDir, this.extensions, query)

    if (resolved.kind === 'not_found') {
      return this.result(false, 'not_found', `No matching track for "${query.trim()}". Library: ${this.libraryDir} (${this.tracks.length} files).`)
    }

    if (resolved.kind === 'ambiguous') {
      return {
        ...this.result(false, 'ambiguous', `Found ${resolved.matches?.length ?? 0} tracks. Call music_play with an exact path from this list.`),
        matches: resolved.matches,
      }
    }

    const track = resolved.track
    if (!track) {
      return this.result(false, 'error', 'Internal error: matched a track but it was missing.')
    }

    if (mode !== 'now' && this.audio.playing) {
      this.audio.enqueue(track)
      return this.result(true, 'queued', `Queued: ${track.relative}`)
    }

    await this.audio.playNow(track)
    const where = track.kind === 'youtube' ? 'YouTube' : this.backend
    return this.result(true, 'playing', `Playing: ${track.title} via ${where}`)
  }

  pause(): MusicActionResult {
    if (this.status().state !== 'playing') {
      return this.result(false, 'error', 'Nothing is playing.')
    }
    this.audio.pause()
    return this.result(true, 'paused', 'Paused.')
  }

  resume(): MusicActionResult {
    if (this.status().state !== 'paused') {
      return this.result(false, 'error', 'Nothing is paused.')
    }
    this.audio.resume()
    return this.result(true, 'resumed', 'Resumed.')
  }

  async skip(): Promise<MusicActionResult> {
    const before = this.status()
    if (!before.current && before.queue.length === 0) {
      return this.result(false, 'idle', 'Nothing to skip.')
    }
    await this.audio.skip()
    const after = this.status()
    if (after.current) {
      return this.result(true, 'skipped', `Skipped. Now playing: ${after.current.relative}`)
    }
    return this.result(true, 'idle', 'Skipped. Queue is empty.')
  }

  status(): PlayerSnapshot {
    return this.audio.snapshot(this.libraryDir, this.allTracks().length)
  }

  private refresh() {
    if (!this.refreshPromise) this.refreshPromise = this.scan()
    return this.refreshPromise
  }

  private async scan() {
    try {
      const info = await stat(this.libraryDir)
      if (!info.isDirectory()) {
        this.tracks = []
        return
      }
    } catch {
      this.tracks = []
      return
    }
    this.tracks = await scanLibrary(this.libraryDir, this.extensions)
  }

  private result(ok: boolean, action: MusicActionResult['action'], message: string): MusicActionResult {
    return {
      ok,
      action,
      message,
      snapshot: this.status(),
    }
  }
}
