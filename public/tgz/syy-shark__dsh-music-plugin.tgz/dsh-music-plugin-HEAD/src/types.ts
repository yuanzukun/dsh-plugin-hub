export type PlaybackState = 'idle' | 'playing' | 'paused'
export type AudioBackend = 'afplay' | 'mpv'
export type BackendOption = 'auto' | AudioBackend

export interface Track {
  title: string
  path: string
  relative: string
  kind?: 'file' | 'youtube'
  youtubeId?: string
}

export interface CatalogEntry {
  title: string
  youtubeId: string
}

export interface PlayerSnapshot {
  state: PlaybackState
  current: Track | null
  queue: Track[]
  backend: AudioBackend
  libraryDir: string
  libraryCount: number
}

export interface MusicActionResult {
  ok: boolean
  action: 'playing' | 'queued' | 'paused' | 'resumed' | 'skipped' | 'idle' | 'search' | 'status' | 'not_found' | 'ambiguous' | 'error'
  message: string
  snapshot: PlayerSnapshot
  matches?: Track[]
}

export interface MusicConfig {
  libraryDir: string
  backend: BackendOption
  extensions: string[]
  catalog: CatalogEntry[]
}
