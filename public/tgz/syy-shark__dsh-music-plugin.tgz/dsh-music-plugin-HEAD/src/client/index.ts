import { MusicPanel } from './panel.tsx'

export const name = 'dsh-music-client'
export const inject = ['slots']

interface SlotsContext {
  slots: {
    inject(name: string, factory: () => unknown): unknown
    register(spec: Record<string, unknown>, component: unknown): unknown
  }
}

export function apply(ctx: SlotsContext) {
  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay',
    key: 'dsh-music',
    id: 'dsh-music',
  }, MusicPanel))
}
