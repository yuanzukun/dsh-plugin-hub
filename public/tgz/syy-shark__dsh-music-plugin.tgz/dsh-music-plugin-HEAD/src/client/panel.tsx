import { useCallback, useEffect, useRef, useState, type CSSProperties } from 'react'
import type { PlayerSnapshot, Track } from '../types.ts'

interface LibraryResponse {
  ok: boolean
  tracks?: Track[]
  snapshot?: PlayerSnapshot
  error?: string
}

interface ActionResponse {
  ok: boolean
  message?: string
  snapshot?: PlayerSnapshot
  error?: string
}

const STORAGE_KEY = 'dsh-music-open'

const tab: CSSProperties = {
  pointerEvents: 'auto',
  position: 'fixed',
  top: '42%',
  right: 0,
  width: 40,
  height: 40,
  padding: 0,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  border: '1px solid var(--dsw-alias-border-l2, #333)',
  borderRight: 'none',
  borderRadius: '10px 0 0 10px',
  background: 'var(--dsw-alias-bg-base, #141414)',
  color: 'var(--dsw-alias-text-primary, #f2f2f2)',
  cursor: 'pointer',
  zIndex: 80,
}

function MusicNoteIcon() {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true">
      <path d="M9 3v12.55A4 4 0 1 0 11 19V7l10-2v10.55A4 4 0 1 0 23 19V3L9 6V3z" />
    </svg>
  )
}

const card: CSSProperties = {
  pointerEvents: 'auto',
  position: 'fixed',
  top: 72,
  right: 16,
  bottom: 24,
  width: 300,
  display: 'flex',
  flexDirection: 'column',
  background: 'var(--dsw-alias-bg-base, #141414)',
  color: 'var(--dsw-alias-text-primary, #f2f2f2)',
  border: '1px solid var(--dsw-alias-border-l2, #333)',
  borderRadius: 12,
  boxShadow: '0 12px 40px rgba(0,0,0,0.35)',
  overflow: 'hidden',
  zIndex: 40,
  fontFamily: 'inherit',
}

const header: CSSProperties = {
  padding: '12px 14px 10px',
  borderBottom: '1px solid var(--dsw-alias-border-l2, #333)',
}

const titleRow: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 8,
}

const titleStyle: CSSProperties = {
  margin: 0,
  fontSize: 14,
  fontWeight: 600,
}

const collapseBtn: CSSProperties = {
  height: 28,
  padding: '0 10px',
  border: '1px solid var(--dsw-alias-border-l2, #444)',
  borderRadius: 8,
  background: 'transparent',
  color: 'inherit',
  cursor: 'pointer',
  fontSize: 12,
}

const nowPlaying: CSSProperties = {
  margin: '8px 0 10px',
  fontSize: 12,
  lineHeight: 1.4,
  opacity: 0.85,
  wordBreak: 'break-all',
}

const frame: CSSProperties = {
  width: '100%',
  aspectRatio: '16 / 9',
  border: 'none',
  borderRadius: 8,
  marginBottom: 10,
  background: '#000',
}

function youtubeSrc(id: string, autoplay: boolean) {
  const params = new URLSearchParams({
    enablejsapi: '1',
    autoplay: autoplay ? '1' : '0',
    origin: window.location.origin,
  })
  return `https://www.youtube.com/embed/${id}?${params}`
}

function sendYoutube(iframe: HTMLIFrameElement | null, func: 'playVideo' | 'pauseVideo') {
  iframe?.contentWindow?.postMessage(JSON.stringify({ event: 'command', func, args: [] }), '*')
}

const row: CSSProperties = {
  display: 'flex',
  gap: 8,
}

const button: CSSProperties = {
  flex: 1,
  height: 32,
  border: '1px solid var(--dsw-alias-border-l2, #444)',
  borderRadius: 8,
  background: 'var(--dsw-alias-bg-elevated, #222)',
  color: 'inherit',
  cursor: 'pointer',
  fontSize: 13,
}

const listStyle: CSSProperties = {
  margin: 0,
  padding: 8,
  overflow: 'auto',
  listStyle: 'none',
  flex: 1,
}

const item: CSSProperties = {
  width: '100%',
  textAlign: 'left',
  padding: '8px 10px',
  marginBottom: 4,
  border: 'none',
  borderRadius: 8,
  background: 'transparent',
  color: 'inherit',
  cursor: 'pointer',
  fontSize: 13,
}

async function getJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, init)
  return await response.json() as T
}

function readOpen(): boolean {
  try {
    return window.localStorage.getItem(STORAGE_KEY) === '1'
  } catch {
    return false
  }
}

export function MusicPanel() {
  const [open, setOpen] = useState(readOpen)
  const [snapshot, setSnapshot] = useState<PlayerSnapshot | null>(null)
  const [tracks, setTracks] = useState<Track[]>([])
  const [error, setError] = useState('')

  const setOpenAndRemember = (next: boolean) => {
    setOpen(next)
    try {
      window.localStorage.setItem(STORAGE_KEY, next ? '1' : '0')
    } catch {
      // Ignore private-mode storage failures.
    }
  }

  const refresh = useCallback(async () => {
    try {
      const data = await getJson<LibraryResponse>('/dsh-music/library')
      if (!data.ok) {
        setError(data.error ?? '加载歌单失败')
        return
      }
      setTracks(data.tracks ?? [])
      if (data.snapshot) setSnapshot(data.snapshot)
      setError('')
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '无法连接音乐插件')
    }
  }, [])

  useEffect(() => {
    void refresh()
    const timer = window.setInterval(async () => {
      try {
        const data = await getJson<LibraryResponse>('/dsh-music/status')
        if (data.ok && data.snapshot) setSnapshot(data.snapshot)
      } catch {
        // Keep the last good snapshot while the host reloads.
      }
    }, 1000)
    return () => window.clearInterval(timer)
  }, [refresh])

  const post = async (path: string, body?: Record<string, string>) => {
    const data = await getJson<ActionResponse>(path, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body ?? {}),
    })
    if (data.snapshot) setSnapshot(data.snapshot)
    if (!data.ok) setError(data.error ?? data.message ?? '操作失败')
    else setError('')
  }

  const current = snapshot?.current
  const playing = snapshot?.state === 'playing'
  const paused = snapshot?.state === 'paused'
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const lastYoutubeId = useRef<string | null>(null)

  useEffect(() => {
    const id = current?.youtubeId ?? null
    if (!id) {
      lastYoutubeId.current = null
      return
    }
    if (lastYoutubeId.current === id) {
      sendYoutube(iframeRef.current, playing ? 'playVideo' : 'pauseVideo')
    }
    lastYoutubeId.current = id
  }, [current?.youtubeId, playing])

  const onPlayPause = () => {
    if (playing) return void post('/dsh-music/pause')
    if (paused) return void post('/dsh-music/resume')
    if (tracks[0]) return void post('/dsh-music/play', { query: tracks[0].path })
    setError('先在 ~/Music 里放几首歌')
  }

  return (
    <div data-dsh-music-panel="1">
      <button
        type="button"
        style={{ ...tab, display: open ? 'none' : 'flex' }}
        title="音乐"
        aria-label="打开音乐"
        onClick={() => setOpenAndRemember(true)}
      >
        <MusicNoteIcon />
      </button>
    <aside style={open ? card : { ...card, opacity: 0, pointerEvents: 'none', zIndex: 0 }}>
      <div style={header}>
        <div style={titleRow}>
          <h2 style={titleStyle}>音乐</h2>
          <button
            type="button"
            style={collapseBtn}
            onClick={event => {
              event.preventDefault()
              event.stopPropagation()
              setOpenAndRemember(false)
            }}
          >
            收起
          </button>
        </div>
        <p style={nowPlaying}>
          {current ? `${playing ? '正在播放' : paused ? '已暂停' : '已停止'}：${current.title}` : '还没在播。点下面一首歌。'}
        </p>
        {current?.youtubeId ? (
          <iframe
            ref={iframeRef}
            key={current.youtubeId}
            title={current.title}
            src={youtubeSrc(current.youtubeId, playing)}
            allow="autoplay; encrypted-media"
            style={frame}
          />
        ) : null}
        <div style={row}>
          <button type="button" style={button} onClick={onPlayPause}>
            {playing ? '暂停' : '播放'}
          </button>
          <button type="button" style={button} onClick={() => void post('/dsh-music/skip')}>
            下一首
          </button>
        </div>
        {error ? <p style={{ ...nowPlaying, color: '#f07178' }}>{error}</p> : null}
      </div>
      <ul style={listStyle}>
        {tracks.length === 0 ? (
          <li style={{ padding: 10, opacity: 0.7, fontSize: 13 }}>
            {snapshot ? `「${snapshot.libraryDir}」里还没有歌。把 mp3 放进去再刷新。` : '正在读取歌单…'}
          </li>
        ) : tracks.map(track => {
          const active = current?.path === track.path
          return (
            <li key={track.path}>
              <button
                type="button"
                style={{
                  ...item,
                  background: active ? 'var(--dsw-alias-bg-elevated, #2a2a2a)' : 'transparent',
                  fontWeight: active ? 600 : 400,
                }}
                onClick={() => void post('/dsh-music/play', { query: track.path })}
              >
                {track.title}
                <div style={{ opacity: 0.55, fontSize: 11, marginTop: 2 }}>{track.relative}</div>
              </button>
            </li>
          )
        })}
      </ul>
    </aside>
    </div>
  )
}
