import type { Context } from '@deepseek-ai/cordis'
import Schema from '@deepseek-ai/schemastery'
import { apply as applyMusicHttp, inject as musicHttpInject, name as musicHttpName } from './http.ts'
import { LocalMusic } from './local.ts'
import { apply as applyMusicTools, inject as musicToolsInject, name as musicToolsName } from './tools.ts'
import type { MusicConfig } from './types.ts'

export const name = 'dsh-music'

export type Config = MusicConfig

const DEFAULT_CATALOG = [{
  title: 'Focus playlist — Founder FM',
  youtubeId: '0o0ZdUTYZaY',
}]

export const Config: Schema<Config> = Schema.object({
  libraryDir: Schema.string().default('~/Music'),
  backend: Schema.union(['auto', 'afplay', 'mpv']).default('auto'),
  extensions: Schema.array(Schema.string()).default(['mp3', 'flac', 'm4a', 'wav', 'aac', 'ogg']),
  catalog: Schema.array(Schema.object({
    title: Schema.string().required(),
    youtubeId: Schema.string().required(),
  })).default(DEFAULT_CATALOG),
})

export function apply(ctx: Context, config: Config) {
  ctx.plugin(LocalMusic, config)
  ctx.plugin({
    name: musicToolsName,
    inject: musicToolsInject,
    apply: applyMusicTools,
  })
  ctx.plugin({
    name: musicHttpName,
    inject: musicHttpInject,
    apply: applyMusicHttp,
  })
}

export { MusicService } from './service.ts'
export type { MusicActionResult, PlayerSnapshot, Track } from './types.ts'
