import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { MusicActionResult, Track } from './types.ts'

export const name = 'dsh-music-tools'
export const inject = ['tools', 'music']

function formatTrack(track: Track): string {
  return `${track.title}  (${track.relative})`
}

function renderResult(value: MusicActionResult): [{ type: 'text'; text: string }] {
  const current = value.snapshot.current ? formatTrack(value.snapshot.current) : '(none)'
  const queued = value.snapshot.queue.length
    ? value.snapshot.queue.map((track, index) => `${index + 1}. ${formatTrack(track)}`).join('\n')
    : '(empty)'
  const matches = value.matches?.length
    ? value.matches.map((track, index) => `${index + 1}. ${track.path}`).join('\n')
    : ''

  const lines = [
    value.message,
    '',
    `state: ${value.snapshot.state}`,
    `backend: ${value.snapshot.backend}`,
    `library: ${value.snapshot.libraryDir} (${value.snapshot.libraryCount} files)`,
    `current: ${current}`,
    `queue (${value.snapshot.queue.length}):`,
    queued,
  ]

  if (matches) {
    lines.push('', 'matches:', matches)
  }

  return [{ type: 'text', text: lines.join('\n') }]
}

const resultSchema = { type: 'object' as const }

export function apply(ctx: Context) {
  ctx.tools.register(defineTool({
    name: 'music_search',
    description: 'Search the local music library by song or file name. Omit query to list a sample of the library.',
    parameters: {
      query: { type: 'string', description: 'Song title or file name fragment' },
    },
    output: {
      schema: resultSchema,
      render: (_args, value: MusicActionResult) => renderResult(value),
    },
    async execute(args) {
      const matches = await ctx.music.search(args.query)
      return {
        ok: true,
        action: 'search' as const,
        message: matches.length
          ? `Found ${matches.length} track(s). Play one with music_play using its exact path.`
          : `No tracks matched. Library: ${ctx.music.status().libraryDir}`,
        snapshot: ctx.music.status(),
        matches,
      }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'music_play',
    description: 'Play a local track by title, file name, or exact path. If something is already playing, the track is queued. If several files match, this returns the list instead of guessing.',
    parameters: {
      query: { type: 'string', required: true, description: 'Song title, file name, or exact path from music_search' },
    },
    output: {
      schema: resultSchema,
      render: (_args, value: MusicActionResult) => renderResult(value),
    },
    async execute(args) {
      return ctx.music.play(args.query)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'music_pause',
    description: 'Pause the current local track.',
    parameters: {},
    output: {
      schema: resultSchema,
      render: (_args, value: MusicActionResult) => renderResult(value),
    },
    async execute() {
      return ctx.music.pause()
    },
  }))

  ctx.tools.register(defineTool({
    name: 'music_resume',
    description: 'Resume a paused local track.',
    parameters: {},
    output: {
      schema: resultSchema,
      render: (_args, value: MusicActionResult) => renderResult(value),
    },
    async execute() {
      return ctx.music.resume()
    },
  }))

  ctx.tools.register(defineTool({
    name: 'music_skip',
    description: 'Skip to the next queued local track.',
    parameters: {},
    output: {
      schema: resultSchema,
      render: (_args, value: MusicActionResult) => renderResult(value),
    },
    async execute() {
      return ctx.music.skip()
    },
  }))

  ctx.tools.register(defineTool({
    name: 'music_status',
    description: 'Show what is playing, the queue, the audio backend, and the library folder.',
    parameters: {},
    output: {
      schema: resultSchema,
      render: (_args, value: MusicActionResult) => renderResult(value),
    },
    async execute() {
      const snapshot = ctx.music.status()
      return {
        ok: true,
        action: 'status' as const,
        message: snapshot.current
          ? `Now ${snapshot.state}: ${snapshot.current.relative}`
          : 'Nothing is playing.',
        snapshot,
      }
    },
  }))
}
