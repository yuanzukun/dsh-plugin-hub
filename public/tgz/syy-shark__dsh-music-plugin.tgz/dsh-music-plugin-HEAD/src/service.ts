import { Service, type Context } from '@deepseek-ai/cordis'
import type { MusicActionResult, PlayerSnapshot, Track } from './types.ts'

declare module '@deepseek-ai/cordis' {
  interface Context {
    music: MusicService
  }

  interface Events {
    'music/state'(snapshot: PlayerSnapshot): void
  }
}

/**
 * The music switch other plugins talk to.
 * Local files, and later streaming, all sit behind this.
 */
export abstract class MusicService extends Service {
  constructor(ctx: Context) {
    super(ctx, 'music')
  }

  abstract search(query?: string): Promise<Track[]>
  abstract list(limit?: number): Promise<Track[]>
  abstract play(query: string, mode?: 'now' | 'queue'): Promise<MusicActionResult>
  abstract pause(): MusicActionResult
  abstract resume(): MusicActionResult
  abstract skip(): Promise<MusicActionResult>
  abstract status(): PlayerSnapshot

  protected emitState(snapshot: PlayerSnapshot) {
    this.ctx.emit('music/state', snapshot)
  }
}
