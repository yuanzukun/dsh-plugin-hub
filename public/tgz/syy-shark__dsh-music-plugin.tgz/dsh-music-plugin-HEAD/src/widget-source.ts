export const musicWidgetScript = `
(() => {
  if (window.__dshMusicWidget) return;
  window.__dshMusicWidget = true;

  const STORAGE_KEY = 'dsh-music-open';
  const readOpen = () => {
    try { return localStorage.getItem(STORAGE_KEY) === '1'; } catch { return false; }
  };
  const writeOpen = (open) => {
    try { localStorage.setItem(STORAGE_KEY, open ? '1' : '0'); } catch {}
  };

  const tabCss = 'pointer-events:auto;position:fixed;top:42%;right:0;width:40px;height:40px;padding:0;display:flex;align-items:center;justify-content:center;border:1px solid var(--dsw-alias-border-l2,#333);border-right:none;border-radius:10px 0 0 10px;background:var(--dsw-alias-bg-base,#141414);color:var(--dsw-alias-text-primary,#f2f2f2);cursor:pointer;z-index:80;';
  const cardCss = 'pointer-events:auto;position:fixed;top:72px;right:16px;bottom:24px;width:300px;display:flex;flex-direction:column;background:var(--dsw-alias-bg-base,#141414);color:var(--dsw-alias-text-primary,#f2f2f2);border:1px solid var(--dsw-alias-border-l2,#333);border-radius:12px;box-shadow:0 12px 40px rgba(0,0,0,.35);overflow:hidden;z-index:80;font-family:inherit;';
  const cardHiddenCss = cardCss + 'opacity:0;pointer-events:none;z-index:0;';
  const iconSvg = '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M9 3v12.55A4 4 0 1 0 11 19V7l10-2v10.55A4 4 0 1 0 23 19V3L9 6V3z"/></svg>';

  const mount = () => {
    if (document.querySelector('[data-dsh-music-panel]')) return;
    const root = document.createElement('aside');
    root.dataset.dshMusicPanel = '1';
    document.body.appendChild(root);
    root.innerHTML = \`
      <button data-tab type="button" title="音乐" aria-label="打开音乐" style="\${tabCss}">\${iconSvg}</button>
      <div data-card>
        <div style="padding:12px 14px 10px;border-bottom:1px solid var(--dsw-alias-border-l2,#333)">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
            <h2 style="margin:0;font-size:14px;font-weight:600">音乐</h2>
            <button data-collapse type="button" style="height:28px;padding:0 10px;border:1px solid #444;border-radius:8px;background:transparent;color:inherit;cursor:pointer;font-size:12px">收起</button>
          </div>
          <p data-now style="margin:8px 0 10px;font-size:12px;line-height:1.4;opacity:.85;word-break:break-all">正在读取歌单…</p>
          <div data-yt></div>
          <div style="display:flex;gap:8px">
            <button data-toggle type="button" style="flex:1;height:32px;border:1px solid #444;border-radius:8px;background:#222;color:inherit;cursor:pointer;font-size:13px">播放</button>
            <button data-skip type="button" style="flex:1;height:32px;border:1px solid #444;border-radius:8px;background:#222;color:inherit;cursor:pointer;font-size:13px">下一首</button>
          </div>
          <p data-error style="margin:8px 0 0;font-size:12px;color:#f07178"></p>
        </div>
        <ul data-list style="margin:0;padding:8px;overflow:auto;list-style:none;flex:1"></ul>
      </div>
    \`;

    let snapshot = null;
    let tracks = [];
    let open = readOpen();
    let lastYoutubeId = null;
    const tab = root.querySelector('[data-tab]');
    const card = root.querySelector('[data-card]');

    const json = (url, init) => fetch(url, init).then((r) => r.json());

    const sendYoutube = (func) => {
      const iframe = root.querySelector('[data-yt] iframe');
      if (!iframe || !iframe.contentWindow) return;
      iframe.contentWindow.postMessage(JSON.stringify({ event: 'command', func, args: [] }), '*');
    };

    const paintYoutube = (current, playing) => {
      const holder = root.querySelector('[data-yt]');
      if (!holder) return;
      const id = current && current.youtubeId;
      if (!id) {
        holder.innerHTML = '';
        lastYoutubeId = null;
        return;
      }
      if (lastYoutubeId === id) {
        sendYoutube(playing ? 'playVideo' : 'pauseVideo');
        return;
      }
      lastYoutubeId = id;
      const origin = encodeURIComponent(location.origin);
      holder.innerHTML = '<iframe title="YouTube" allow="autoplay; encrypted-media" style="width:100%;aspect-ratio:16/9;border:none;border-radius:8px;margin-bottom:10px;background:#000" src="https://www.youtube.com/embed/' + id + '?enablejsapi=1&autoplay=' + (playing ? '1' : '0') + '&origin=' + origin + '"></iframe>';
    };

    const paint = (next) => {
      snapshot = next || snapshot;
      const now = root.querySelector('[data-now]');
      const toggle = root.querySelector('[data-toggle]');
      if (!now || !toggle) return;
      const current = snapshot && snapshot.current;
      const playing = snapshot && snapshot.state === 'playing';
      now.textContent = current
        ? (playing ? '正在播放：' : snapshot.state === 'paused' ? '已暂停：' : '已停止：') + current.title
        : '还没在播。点下面一首歌。';
      toggle.textContent = playing ? '暂停' : '播放';
      paintYoutube(current, playing);
    };

    const renderList = () => {
      const list = root.querySelector('[data-list]');
      if (!list) return;
      list.innerHTML = '';
      if (!tracks.length) {
        const empty = document.createElement('li');
        empty.style.cssText = 'padding:10px;opacity:.7;font-size:13px';
        empty.textContent = snapshot ? '「' + snapshot.libraryDir + '」里还没有歌。把 mp3 放进去再刷新。' : '正在读取歌单…';
        list.appendChild(empty);
        return;
      }
      for (const track of tracks) {
        const li = document.createElement('li');
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.style.cssText = 'width:100%;text-align:left;padding:8px 10px;margin-bottom:4px;border:none;border-radius:8px;background:transparent;color:inherit;cursor:pointer;font-size:13px';
        btn.innerHTML = track.title + '<div style="opacity:.55;font-size:11px;margin-top:2px"></div>';
        btn.lastChild.textContent = track.relative;
        btn.onclick = () => json('/dsh-music/play', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ query: track.path }) }).then((r) => {
          paint(r.snapshot);
          const err = root.querySelector('[data-error]');
          if (err) err.textContent = r.ok ? '' : (r.error || r.message || '操作失败');
        });
        li.appendChild(btn);
        list.appendChild(li);
      }
    };

    const applyOpen = () => {
      if (open) {
        tab.style.display = 'none';
        card.style.cssText = cardCss;
        return;
      }
      tab.style.cssText = tabCss;
      card.style.cssText = cardHiddenCss;
    };

    tab.onclick = (event) => {
      event.stopPropagation();
      open = true;
      writeOpen(true);
      applyOpen();
    };

    const err = root.querySelector('[data-error]');
    const toggle = root.querySelector('[data-toggle]');
    const skip = root.querySelector('[data-skip]');
    const collapse = root.querySelector('[data-collapse]');
    if (collapse) collapse.onclick = (event) => {
      event.preventDefault();
      event.stopPropagation();
      open = false;
      writeOpen(false);
      applyOpen();
    };
    if (toggle) toggle.onclick = () => {
      if (snapshot && snapshot.state === 'playing') {
        json('/dsh-music/pause', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' }).then((r) => { paint(r.snapshot); if (err) err.textContent = r.ok ? '' : (r.error || r.message || '操作失败'); });
        return;
      }
      if (snapshot && snapshot.state === 'paused') {
        json('/dsh-music/resume', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' }).then((r) => { paint(r.snapshot); if (err) err.textContent = r.ok ? '' : (r.error || r.message || '操作失败'); });
        return;
      }
      if (tracks[0]) {
        json('/dsh-music/play', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ query: tracks[0].path }) }).then((r) => { paint(r.snapshot); if (err) err.textContent = r.ok ? '' : (r.error || r.message || '操作失败'); });
        return;
      }
      if (err) err.textContent = '先在 ~/Music 里放几首歌';
    };
    if (skip) skip.onclick = () => json('/dsh-music/skip', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' }).then((r) => { paint(r.snapshot); if (err) err.textContent = r.ok ? '' : (r.error || r.message || '操作失败'); });

    const load = () => json('/dsh-music/library').then((data) => {
      if (!data.ok) { if (err) err.textContent = data.error || '加载歌单失败'; return; }
      if (err) err.textContent = '';
      tracks = data.tracks || [];
      paint(data.snapshot);
      renderList();
    }).catch((cause) => {
      if (err) err.textContent = cause.message || '无法连接音乐插件';
    });

    applyOpen();
    load();
    setInterval(() => json('/dsh-music/status').then((data) => { if (data.ok) paint(data.snapshot); }).catch(() => {}), 1000);
  };

  const start = () => setTimeout(mount, 2000);
  if (document.body) start();
  else document.addEventListener('DOMContentLoaded', start);
})();
`
